import { requireSharedAssembler } from './assembler-compatibility.js'
import {createRenderingCache} from '../../rendering-cache/store.js'
import {createRenderingCacheHandler,isRenderingCachePath} from '../../rendering-cache/http.js'
import {createRenderingAuthority,createRenderingAuthorityHandler,isRenderingAuthorityPath} from '../../rendering-authority/index.js'
import { createDraftPreviewContext } from './draft-preview-context.js'
import { PlayMaintenanceService } from '../../play/src/maintenance.js'
import { PlayCleanupService } from '../../play/src/cleanup.js'
import { installMaintenanceTools } from './maintenance-tools.js'
import { PlaythroughDrafts } from './playthrough-drafts.js'
import { OperationJournal } from '../../play/src/operation-journal.js'
import { createCharacterDiscovery } from '../../mvu-adapter/src/discovery.js'
import { installMvu } from '../../mvu-adapter/src/host.js'
import { commandHookSourceFromCharacter } from '../../mvu-adapter/src/command-hook-declaration.js'
import { createMvuApi, isMvuApiPath } from '../../mvu-adapter/src/http.js'
import { mvuResourceFromCharacter } from '../../mvu-adapter/src/character.js'
import { createContractOperation, recordDiagnosticFailure } from '../../play/src/operation-contract.js'
import { AssemblyStore } from '../../tavern-trace/src/assembly-store.js'
import { AssemblyRecorder } from '../../tavern-trace/src/assembly-recorder.js'
import { createNativeRequestReader } from '../../tavern-trace/src/native-request-reader.js'
import { createPromptTraceApi } from './prompt-trace-api.js'
import {
  PresetStore,
  createApiHandler as createPresetApiHandler,
} from '../../preset/src/index.js'
import { API_ROOT, API_V1, API_V3, PLUGIN_ID, PROFILE_SECTION } from '../../identity.js'
import { ChromeStore, PlayMembershipService, PlayWorkspaceStore, createChromeEventsHandler, createPlayApiHandler, isPlayApiPath } from '../../play/src/index.js'
import {
  CharacterStore,
  createCharacterAdapter,
  createCharacterApiHandler,
} from '../../character/src/index.js'
import { WorldBookStore, createWorldBookApiHandler } from '../../world-book-library/src/index.js'
import {
  UserStore,
  createUserAdapter,
  createUserApiHandler,
} from '../../user/src/index.js'
import { PresetParameterFallback } from './preset-parameter-fallback.js'
import { PresetRuntime } from './preset-runtime.js'
import { TavernProfileLoader, compileTavernProfile } from './profile-loader.js'
import { SessionSelectionStore } from './session-policy.js'
import { UserWorldBookBindingStore, composeWorldBookSelection } from './user-world-book-policy.js'
import { ResourceWorldBookBindingStore } from './resource-world-book-policy.js'
import { createWorldBookAdapter } from './world-book-adapter.js'
import { PendingInputProjection } from './pending-input-projection.js'
import { ImportContextRuntime } from './import-context-runtime.js'
import { createPlayHost } from './play-host.js'
import { secureTavernApi } from './api-security.js'
import {
  UiSettingsStore,
  createUiSettingsApiHandler,
  isUiSettingsApiPath,
} from './ui-settings.js'
import {
  ConversationSettingsStore,
  createConversationSettingsApiHandler,
  isConversationSettingsApiPath,
} from './conversation-settings.js'
import {
  TavernTraceRecorder,
  TavernTraceStore,
  createTavernTraceApiHandler,
  isTavernTraceApiPath,
} from '../../tavern-trace/src/index.js'
import {
  SessionConfigurationService,
  SessionTemplateStore,
  createSessionTemplateApiHandler,
  isSessionTemplateApiPath,
} from '../../session-template/src/index.js'
import {
  RpPolicyStore,
  createRpPolicyApiHandler,
  isRpPolicyApiPath,
} from './rp-policy-store.js'
import {
  RpModeController,
  createRpModeApiHandler,
  isRpModeApiPath,
  registerRpCommands,
  registerRpWriteGuard,
  resolveRpConfig,
  rpModeConstants,
} from './rp-mode.js'
import { prepareStorageDir } from './storage-location.js'
import { registerTavernSources, BUILTINS as ASSEMBLY_BUILTINS, NATIVE_BUILTINS as NATIVE_ASSEMBLY_BUILTINS, diagnoseTavernAssembly } from 'dsh-prompt-assembler/adapters/tavern'
import { createMemorySources, installMemorySources } from '../../memory-sources/index.js'
import { OpeningWorldBookService, OPENING_WORLD_BOOK_SERVICE, createOpeningWorldBookHandler, isOpeningWorldBookPath } from '../../opening-worldbook/index.js'
import { createScopeCatalog, installScopeCatalog } from '../../scope-catalog/index.js'
import { createSessionReadContext } from '../../request-assembler/session-read-context.js'
import { createAssemblyApi, isAssemblyApiPath } from '../../request-assembler/server.js'

export const name = PLUGIN_ID
export const inject = [
  'systemPrompt',
  'sessionController',
  'workspaceController',
  'directoryPickerController',
  'dshPromptAssembler',
]

function migrateCharacterSelections(characterStore, selections) {
  for (const [sessionId, legacy] of Object.entries(characterStore.state.selectedBySessionId)) {
    try {
      const current = selections.get(sessionId)
      if (current.characterCardId === null) {
        const normalized = characterStore.normalizeSelection(legacy.characterCardId, legacy)
        selections.set(sessionId, normalized)
      }
    } catch (error) {
      if (error?.code !== 'CHARACTER_NOT_FOUND' && !(error instanceof TypeError)) throw error
    } finally {
      // Migration is one-way. Clearing the legacy binding prevents a user who
      // later unbinds in SessionSelectionStore from being rebound on restart.
      characterStore.select(sessionId, null)
    }
  }
}

function isCharacterApiPath(url) {
  const path = new URL(url ?? '/', 'http://localhost').pathname
  return path === `${API_V1}/character-selection`
    || path === `${API_V1}/characters`
    || path.startsWith(`${API_V1}/characters/`)
}

function isWorldBookApiPath(url) {
  const path = new URL(url ?? '/', 'http://localhost').pathname
  return path === `${API_V1}/world-book-selection`
    || path === `${API_V1}/world-books`
    || path.startsWith(`${API_V1}/world-books/`)
}

function isUserApiPath(url) {
  const path = new URL(url ?? '/', 'http://localhost').pathname
  return path === `${API_V1}/user-selection`
    || path === `${API_V1}/users`
    || path.startsWith(`${API_V1}/users/`)
}

export function createCharacterSelectionPolicy(characterStore, selections, resourceWorldBooks = null) {
  return {
    selection(sessionId) {
      if (typeof sessionId !== 'string' || sessionId === '') return null
      const selected = selections.get(sessionId)
      if (selected.characterCardId === null) return null
      try {
        return characterStore.normalizeSelection(selected.characterCardId, selected)
      } catch (error) {
        if (error?.code !== 'CHARACTER_NOT_FOUND' && !(error instanceof TypeError)) throw error
        return null
      }
    },
    select(sessionId, patch) {
      if (patch === null || patch.characterCardId === null) {
        selections.set(sessionId, { characterCardId: null, character: {} })
        return null
      }
      const normalized = characterStore.normalizeSelection(patch.characterCardId, patch)
      selections.set(sessionId, normalized)
      return normalized
    },
    selectMany(sessionIds, patch) {
      if (patch === null || patch.characterCardId === null) {
        return selections.setMany(sessionIds, { characterCardId: null, character: {} })
      }
      const normalized = characterStore.normalizeSelection(patch.characterCardId, patch)
      return selections.setMany(sessionIds, normalized)
    },
    clearResource(kind, id) {
      const sessionChanged = selections.clearResource(kind, id)
      const bindingChanged = kind === 'character'
        ? resourceWorldBooks?.clearOwner('character', id) === true
        : kind === 'character-card'
          ? resourceWorldBooks?.clearOwner('character', id) === true
          : false
      return sessionChanged || bindingChanged
    },
  }
}

export function createWorldBookSelectionPolicy(
  worldBookStore,
  selections,
  userWorldBooks = null,
  resourceWorldBooks = null,
) {
  return {
    selection(sessionId) {
      if (typeof sessionId !== 'string' || sessionId === '') return []
      return selections.get(sessionId).worldBookIds
    },
    select(sessionId, worldBookIds) {
      if (!Array.isArray(worldBookIds)) throw new TypeError('worldBookIds must be an array')
      if (worldBookIds.length > 100) throw new TypeError('A session can bind at most 100 world books')
      const normalized = [...new Set(worldBookIds)]
      for (const id of normalized) {
        if (typeof id !== 'string' || id === '') throw new TypeError('Every worldBookId must be a non-empty string')
        worldBookStore.get(id)
      }
      selections.set(sessionId, { worldBookIds: normalized })
      return normalized
    },
    clearResource(kind, id) {
      const sessionChanged = selections.clearResource(kind, id)
      const userChanged = kind === 'world-book' ? userWorldBooks?.clearWorldBook(id) === true : false
      const resourceChanged = kind === 'world-book' ? resourceWorldBooks?.clearWorldBook(id) === true : false
      return sessionChanged || userChanged || resourceChanged
    },
  }
}

export function createUserSelectionPolicy(userStore, selections, userWorldBooks = null) {
  return {
    selection(sessionId) {
      if (typeof sessionId !== 'string' || sessionId === '') return null
      const selected = selections.get(sessionId)
      if (selected.userId === null) return null
      try {
        userStore.get(selected.userId)
        return { userId: selected.userId }
      } catch (error) {
        if (error?.code !== 'USER_NOT_FOUND' && !(error instanceof TypeError)) throw error
        return null
      }
    },
    select(sessionId, patch) {
      if (patch === null || patch.userId === null) {
        selections.set(sessionId, { userId: null })
        return null
      }
      userStore.get(patch.userId)
      selections.set(sessionId, { userId: patch.userId })
      return { userId: patch.userId }
    },
    clearResource(kind, id) {
      const sessionChanged = selections.clearResource(kind, id)
      const bindingChanged = kind === 'user' ? userWorldBooks?.clearUser(id) === true : false
      return sessionChanged || bindingChanged
    },
  }
}

export function createUserWorldBookBindingPolicy(userStore, worldBookStore, userWorldBooks) {
  if (typeof userWorldBooks?.get !== 'function' || typeof userWorldBooks?.set !== 'function') {
    throw new TypeError('User world-book policy requires a binding store')
  }
  return {
    selection(userId) {
      userStore.get(userId)
      return userWorldBooks.get(userId)
    },
    select(userId, worldBookIds) {
      userStore.get(userId)
      if (!Array.isArray(worldBookIds)) throw new TypeError('worldBookIds must be an array')
      if (worldBookIds.length > 100) throw new TypeError('A user can bind at most 100 world books')
      const normalized = [...new Set(worldBookIds)]
      for (const id of normalized) {
        if (typeof id !== 'string' || id === '') throw new TypeError('Every worldBookId must be a non-empty string')
        worldBookStore.get(id)
      }
      return userWorldBooks.set(userId, normalized)
    },
  }
}

export function createResourceWorldBookBindingPolicy(
  resourceStore,
  worldBookStore,
  resourceWorldBooks,
  kind,
) {
  if (kind !== 'preset' && kind !== 'character') throw new TypeError('Resource kind must be preset or character')
  if (typeof resourceWorldBooks?.get !== 'function' || typeof resourceWorldBooks?.set !== 'function') {
    throw new TypeError('Resource world-book policy requires a binding store')
  }
  const getResource = id => resourceStore.get(id)
  return {
    selection(resourceId) {
      getResource(resourceId)
      return resourceWorldBooks.get(kind, resourceId)
    },
    select(resourceId, worldBookIds) {
      getResource(resourceId)
      if (!Array.isArray(worldBookIds)) throw new TypeError('worldBookIds must be an array')
      if (worldBookIds.length > 100) throw new TypeError(`A ${kind} can bind at most 100 world books`)
      const normalized = [...new Set(worldBookIds)]
      for (const id of normalized) {
        if (typeof id !== 'string' || id === '') throw new TypeError('Every worldBookId must be a non-empty string')
        worldBookStore.get(id)
      }
      return resourceWorldBooks.set(kind, resourceId, normalized)
    },
  }
}

export function apply(ctx, config = {}) {
  const sharedAssembler = requireSharedAssembler(ctx.get('dshPromptAssembler'), config)
  const parameterFallback = new PresetParameterFallback()
  const { path: storageDir } = prepareStorageDir({
    storageDir: config.storageDir,
    logger: ctx.logger,
  })
  const operationJournal = new OperationJournal(storageDir, { enabled: config.operationLogs?.enabled !== false })
  const operationContext = (operation, meta) => createContractOperation({ logger: ctx.logger, journal: operationJournal, operation, meta })
  const startup = operationContext('plugin.start')
  startup.start()
  ctx.effect(() => () => {
    operationContext('plugin.stop').success('disposed')
    operationJournal.close()
  })
  const recordFailure = (operation, error, meta) => recordDiagnosticFailure({ logger: ctx.logger, journal: operationJournal, operation, meta }, error)
  const store = new PresetStore(storageDir)
  const characterStore = new CharacterStore(storageDir)
  const worldBookStore = new WorldBookStore(storageDir)
  const userStore = new UserStore(storageDir)
  const userWorldBooks = new UserWorldBookBindingStore(storageDir, config.userWorldBooks)
  const resourceWorldBooks = new ResourceWorldBookBindingStore(storageDir, config.resourceWorldBooks)
  const sessionTemplateStore = new SessionTemplateStore(storageDir, config.sessionTemplates)
  const uiSettingsStore = new UiSettingsStore(storageDir)
  const conversationSettingsStore = new ConversationSettingsStore(storageDir)
  const chromeStore = new ChromeStore(storageDir)
  const rpPolicyStore = new RpPolicyStore(storageDir, {
    defaultSection: resolveRpConfig(config.rpMode ?? {}).section,
  })
  const selections = new SessionSelectionStore(storageDir, {
    ...config.sessionSelections,
    defaultSelection: () => ({ presetId: store.state.selectedId }),
  })
  const sessionReads = createSessionReadContext(id => ctx.get('sessions')?.get?.(id))
  const withSessionRead = async ({ sessionId, signal } = {}, callback) => {
    signal?.throwIfAborted()
    if (!sessionId || sessionReads.getSession(sessionId)) return callback()
    const sessions = ctx.get('sessions'), controller = ctx.get('sessionController')
    if (!sessions || !controller) throw Object.assign(new Error('Session reader is not ready'), { code: 'SESSION_READER_NOT_READY' })
    let record
    try { record = await controller.inspect(sessionId) }
    catch (error) {
      if (error.code === 'session/not-found' || error.constructor?.name === 'ApiSessionNotFound') throw Object.assign(new Error('Session does not exist'), { code: 'SESSION_NOT_FOUND' })
      throw error
    }
    signal?.throwIfAborted()
    const session = sessions.get(sessionId) ?? sessions.prepare(sessionId, { seed: record.events, meta: record.meta, inheritedEventCount: record.inheritedEventCount, eventState: 'detached' })
    return sessionReads.run(session, callback)
  }
  ctx.effect(() => () => sessionReads.dispose())
  migrateCharacterSelections(characterStore, selections)
  const openingWorldBooks = new OpeningWorldBookService({ storageDir, characters: characterStore,
    getSelection: id => selections.get(id), getSelectionRevision: id => selections.selectionRevision(id),
    getSession: id => ctx.get('sessions')?.get?.(id), onChange: () => ctx.emit('system-prompt/change') })
  ctx.provide(OPENING_WORLD_BOOK_SERVICE, openingWorldBooks)
  ctx.effect(() => () => openingWorldBooks.dispose())
  installScopeCatalog(ctx, createScopeCatalog({ sources: { characterId: characterStore, presetId: store, userId: userStore },
    getSelection: id => selections.get(id), getSelectionRevision: id => `${selections.selectionRevision(id)}:${store.selectionEpoch}`,
    getSession: sessionReads.getSession }))
  const rpMode = new RpModeController({
    selections,
    uiSettings: uiSettingsStore,
    agents: () => ctx.get('agents'),
    sandboxDefault: () => ctx.get('sandboxPolicy')?.defaultMode,
    workspaceRoot: () => {
      const root = ctx.get('sandboxPolicy')?.workspaceRoot
      return typeof root === 'string' && root !== '' ? root : process.cwd()
    },
    logger: ctx.logger,
    policyStore: rpPolicyStore,
    section: rpPolicyStore.defaultSection,
  })
  const reconcileRpAfterSelection = (sessionId) => {
    const liveAgent = ctx.get('agents')?.get?.(sessionId)
    const session = liveAgent === undefined ? ctx.get('sessions')?.get?.(sessionId) : undefined
    const agent = liveAgent ?? (session === undefined ? { id: sessionId } : { id: sessionId, session })
    try {
      rpMode.onSessionStart(agent)
    } catch (error) {
      recordFailure('rp.policy', error, { sessionId })
    }
  }
  let importContexts = null
  let playthroughDrafts
  const draftPreview = createDraftPreviewContext()
  const draftMvu = { async resolvePromptDependency({ id, scope, event, signal } = {}) {
    const record = draftPreview.current()
    if (!record || id !== undefined || scope?.sessionId || event?.preview !== true || event?.usage !== 'world-book-variable') return null
    signal?.throwIfAborted()
    if (!record.variables) return null
    return { id: `mvu:draft-${record.id}`, adapterId: 'tavern.mvu', content: structuredClone(record.variables), revision: record.variableRevision, configRevision: null,
      checkCurrent: () => !signal?.aborted && draftPreview.current() === record && playthroughDrafts.record(record.id).revision === record.revision }
  } }
  const playHost = createPlayHost({
    sessionController: ctx.get('sessionController'),
    workspaceController: ctx.get('workspaceController'),
    directoryPickerController: ctx.get('directoryPickerController'),
    sessions: ctx.get('sessions'),
  }, {
    selections,
    characters: characterStore,
    importContexts: () => importContexts,
    stateSeeds: () => ctx.get('tavernMvu'),
    drafts: () => playthroughDrafts,
    onSelectionCopied: (sessionId, from) => { assemblyPresets.copySelection(from, sessionId); reconcileRpAfterSelection(sessionId) },
  })
  const playWorkspaceStore = new PlayWorkspaceStore(storageDir, { host: playHost })
  const playMemberships = new PlayMembershipService(playWorkspaceStore)
  importContexts = new ImportContextRuntime(storageDir, playWorkspaceStore)
  const runtime = new TavernProfileLoader({
    presetStore: store,
    selections,
    userWorldBooks,
    resourceWorldBooks,
    sessionWorldBooks: openingWorldBooks,
    maxProfileBytes: config.limits?.maxProfileBytes,
    previewSelection: ({ sessionId }) => !sessionId ? draftPreview.current()?.selection : undefined,
  })
  const pendingInput = new PendingInputProjection({
    maxScanCharacters: config.worldBook?.maxScanCharacters,
    maxScanMessages: config.worldBook?.maxScanMessages,
    maxQueuedCharacters: config.pendingInput?.maxQueuedCharacters,
    maxQueuedMessages: config.pendingInput?.maxQueuedMessages,
  })
  const assemblyPresets = sharedAssembler.store
  sharedAssembler.migrateLegacy(storageDir)
  const memorySources = createMemorySources({ storageDir, store: worldBookStore, characters: characterStore, sessionBooks: openingWorldBooks, resources: config.promptTemplates?.resources ?? [], withSessionRead,
    getSession: sessionReads.getSession, getMvu: () => draftPreview.current() ? draftMvu : ctx.get('tavernMvu'),
    resolveVariables: args => ctx.get('tavernMvu')?.resolvePromptDependency?.(args),
    getPreviewLease: () => {
      const record = draftPreview.current()
      return record ? { checkCurrent: () => draftPreview.current() === record
        && playthroughDrafts.record(record.id).phase === 'draft'
        && playthroughDrafts.record(record.id).revision === record.revision } : null
    },
    getSelection: sessionId => {
      const selected = (!sessionId ? draftPreview.current()?.selection : undefined) ?? selections.get(sessionId)
      const bound = composeWorldBookSelection([...selected.worldBookIds, ...openingWorldBooks.selectedIds(sessionId, selected)],
        selected.userId ? userWorldBooks.get(selected.userId) : [],
        selected.presetId ? resourceWorldBooks.get('preset', selected.presetId) : [],
        selected.characterCardId ? resourceWorldBooks.get('character', selected.characterCardId) : [])
      const worldBookBindings = Object.fromEntries(bound.effectiveIds.map(id => [id, [
        ...(bound.explicitIds.includes(id) ? ['session'] : []), ...(bound.userBoundIds.includes(id) ? ['user'] : []),
        ...(bound.presetBoundIds.includes(id) ? ['preset'] : []), ...(bound.characterBoundIds.includes(id) ? ['character'] : [])]]))
      return { worldBookIds: bound.effectiveIds, worldBookBindings, characterId: selected.characterCardId, presetId: selected.presetId, userId: selected.userId,
        selectionRevision: `${selections.selectionRevision(sessionId)}:${openingWorldBooks.revision()}` }
    } })
  const sourceOptions = { worldbookPolicy: (context, output) => memorySources.worldBooks.filter(context, output), worldbookValidateResolved: memorySources.worldBooks.validateResolved }
  const registry = sharedAssembler.registry
  const requestAssembler = sharedAssembler.runtime
  ctx.effect(() => registerTavernSources(registry, sourceOptions))
  ctx.effect(() => sharedAssembler.attachTavern({ resources: runtime, sessionReads, mode: () => chromeStore.get().mode, builtins: [...NATIVE_ASSEMBLY_BUILTINS, ...ASSEMBLY_BUILTINS], defaultPresetId: 'builtin-native-slots', readActual: id => nativeRequests.readActual(id), afterAssembly: diagnoseTavernAssembly,
      validateResult: (result, agent) => { const nativeContext = runtime.assembledFor(agent)?.memoryContext; if (nativeContext) memorySources.worldBooks.validateResolved(nativeContext); memorySources.validateAssembly(result.metadata?.assembly) } }))
  installMemorySources(ctx, memorySources, registry)
  store.assemblyPresets = assemblyPresets
  store.requestAssembler = requestAssembler
  ctx.provide('tavernRequestSources', requestAssembler.registry) // Protocol-1 compatibility alias.
  const renderingCacheApi=createRenderingCacheHandler(createRenderingCache(storageDir),{getConnection:()=>ctx.get('connection')})
  const renderingAuthority=createRenderingAuthority()
  ctx.provide('tavernRenderingAuthority',renderingAuthority)
  ctx.effect(()=>()=>renderingAuthority.dispose(),'dsh-tavern: rendering write authority')
  const renderingAuthorityApi=createRenderingAuthorityHandler(renderingAuthority,{getConnection:()=>ctx.get('connection')})
  const mvuResources = (config.mvu?.resources ?? []).map(resource => resource.characterId && resource.initial === undefined
    ? mvuResourceFromCharacter(characterStore.get(resource.characterId), resource) : resource)
  let mvu
  const refreshMvu = createCharacterDiscovery({ characters: characterStore, selections, service: () => mvu })
  mvu = installMvu(ctx, { storageDir, resources: mvuResources,
    getPreviewSession: sessionReads.getSession,
    isPreviewRead: sessionReads.isActive,
    resolveCommandHook: resource => {
      if (!resource.characterId) return null
      const metadata = characterStore.scopeMetadata()
      const source = commandHookSourceFromCharacter(characterStore.get(resource.characterId))
      if (metadata.checkCurrent() !== true) throw Object.assign(new Error('Command source changed'), { code: 'MVU_USAGE_CANCELLED' })
      return { source, checkCurrent: metadata.checkCurrent }
    }, sources: requestAssembler.registry, refresh: refreshMvu,
    isActive: (resource, sessionId) => selections.get(sessionId).characterCardId === resource.characterId,
    getSelection: sessionId => selections.get(sessionId), getSelectionToken: sessionId => selections.selectionRevision(sessionId),
    memberships: playMemberships, onError: error => recordFailure('mvu.update', error) })
  runtime.requestAssemblyEnabled = sessionId => {
    const selected = requestAssembler.selected(sessionId)
    if (selected) requestAssembler.requireAvailable(selected)
    return Boolean(selected)
  }
  const requestContexts = new WeakMap()
  ctx.on('agent/assemble-request', async (payload, next) => {
    requestContexts.set(payload.agent, payload)
    try {
      const result = await next()
      const nativeContext = runtime.assembledFor(payload.agent)?.memoryContext
      if (nativeContext) memorySources.worldBooks.validateResolved(nativeContext)
      memorySources.validateAssembly(result.metadata?.assembly)
      return result
    } finally { requestContexts.delete(payload.agent) }
  })
  runtime.registerActivationContextProvider(agent => pendingInput.activationContext(agent))
  const assemblyStore = new AssemblyStore(storageDir, config.traceAssemblies)
  const traceStore = new TavernTraceStore(storageDir, config.trace, assemblyStore)
  if (traceStore.resetOversizedFile) {
    recordFailure('trace.record', { code: 'TRACE_STORAGE_OVERSIZED' })
  }
  const nativeRequests = createNativeRequestReader({ assemblies: assemblyStore, sessionController: ctx.get('sessionController'), sessions: () => ctx.get('sessions'),
    resolveSourceName(source) {
      if (source.plugin !== 'pmp-dsh-tavern' || source.module !== 'preset' || !source.resourceId || !source.field) return null
      const matches = store.get(source.resourceId).prompts.filter(prompt => prompt.identifier === source.field)
      return matches.length === 1 ? matches[0].name : null
    } })
  const traceRecorder = new TavernTraceRecorder(traceStore)
  const assemblyRecorder = new AssemblyRecorder(assemblyStore, { requiresRequestAssembly: sessionId => requestAssembler.requestAssemblyAvailable(sessionId), requiresNativeRequest: sessionId => requestAssembler.selected(sessionId)?.backend === 'native' })
  runtime.registerCharacterAdapter(createCharacterAdapter(characterStore))
  runtime.registerUserAdapter(createUserAdapter(userStore))
  runtime.registerWorldBookAdapter(createWorldBookAdapter(worldBookStore, { ...config.worldBook,
    resolveDocument: (id, { sessionId }) => id.startsWith('session-opening-') ? openingWorldBooks.get(id, sessionId) : worldBookStore.get(id),
    allowResource: (id, context) => memorySources.worldBooks.allowNative(id, context.requestAssembly) }))
  const notifyChange = () => ctx.emit('system-prompt/change')
  const traceSafely = (callback) => {
    try {
      return callback()
    } catch (error) {
      recordFailure('trace.record', error)
      return undefined
    }
  }
  const characterSelectionPolicy = createCharacterSelectionPolicy(characterStore, selections, resourceWorldBooks)
  const worldBookSelectionPolicy = createWorldBookSelectionPolicy(
    worldBookStore,
    selections,
    userWorldBooks,
    resourceWorldBooks,
  )
  const userSelectionPolicy = createUserSelectionPolicy(userStore, selections, userWorldBooks)
  const userWorldBookBindingPolicy = createUserWorldBookBindingPolicy(userStore, worldBookStore, userWorldBooks)
  const presetWorldBookBindingPolicy = createResourceWorldBookBindingPolicy(
    store,
    worldBookStore,
    resourceWorldBooks,
    'preset',
  )
  const characterWorldBookBindingPolicy = createResourceWorldBookBindingPolicy(
    characterStore,
    worldBookStore,
    resourceWorldBooks,
    'character',
  )
  const selectCharacter = characterSelectionPolicy.select.bind(characterSelectionPolicy)
  const selectManyCharacters = characterSelectionPolicy.selectMany.bind(characterSelectionPolicy)
  characterSelectionPolicy.select = (sessionId, patch) => {
    const previousId = characterSelectionPolicy.selection(sessionId)?.characterCardId ?? null
    const result = selectCharacter(sessionId, patch)
    rpMode.followCharacterChange(sessionId, {
      previousId,
      nextId: result?.characterCardId ?? null,
    })
    return result
  }
  characterSelectionPolicy.selectMany = (sessionIds, patch) => {
    const previous = new Map(sessionIds.map(sessionId => [sessionId, characterSelectionPolicy.selection(sessionId)?.characterCardId ?? null]))
    const result = selectManyCharacters(sessionIds, patch)
    for (const sessionId of sessionIds) {
      rpMode.followCharacterChange(sessionId, {
        previousId: previous.get(sessionId) ?? null,
        nextId: result?.[sessionId]?.characterCardId ?? null,
      })
    }
    return result
  }
  const sessionConfigurations = new SessionConfigurationService({
    templates: sessionTemplateStore,
    selections,
    presets: store,
    characters: characterStore,
    users: userStore,
    worldBooks: worldBookStore,
  })
  playthroughDrafts = new PlaythroughDrafts({ storageDir, workspace: playWorkspaceStore, characters: characterStore, configurations: sessionConfigurations, selections, assembly: assemblyPresets, mvu,
    controller: ctx.get('sessionController'), workspaces: ctx.get('workspaceController'), agents: ctx.get('agents'), renderingAuthority, reconcileRp: reconcileRpAfterSelection,
    releaseRp: sessionId => rpMode.setBySessionId(sessionId, false, { followSuppressed: true }),
    previewAssembly: (record, preset) => draftPreview.run(record, () => {
      const model = ctx.get('agentDefaultModel')?.currentSelection?.()
      return requestAssembler.preview({ preset, nativeVariables: { cwd: record.rootPath, ...(model?.provider ? { provider: model.provider } : {}), ...(model?.model ? { model: model.model } : {}) } })
    }),
    onError: error => recordFailure('playthrough.draft', error) })
  playthroughDrafts.importContexts = importContexts
  const playMaintenance = new PlayMaintenanceService({
    workspaceStore: playWorkspaceStore,
    inspectSession: sessionId => playHost.inspectSession(sessionId),
    isDraftProtected: row => {
      const id = row.ext?.pmpDshTavern?.draftId
      if (id === undefined) return false
      const record = playthroughDrafts.state.records[id]
      return !record || record.phase !== 'started' || record.claim?.published !== true
        || playthroughDrafts.tasks.has(id) || playthroughDrafts.admissions.has(id) || playthroughDrafts.cancellations.has(id)
    },
  })
  const playCleanup = new PlayCleanupService({
    workspaceStore: playWorkspaceStore, maintenance: playMaintenance,
    protectedPaths: ({ playthrough, sessionIds }) => [
      ...Object.entries(importContexts.state.sessions)
        .filter(([id]) => !sessionIds.includes(id)).map(([, binding]) => binding.path),
      ...Object.values(playthroughDrafts.state.records)
        .filter(record => record.id !== playthrough.id && record.rootPath === playWorkspaceStore.get().rootPath)
        .map(record => record.importContextRef?.path).filter(Boolean),
    ],
  })
  if (config.maintenanceTools === true) installMaintenanceTools(ctx, {
    workspaceStore: playWorkspaceStore, maintenance: playMaintenance, cleanup: playCleanup,
    operationJournal, logger: ctx.logger,
  })
  ctx.on('session/event', (session, event) => playthroughDrafts.observe(session, event))
  // The public archive gate runs at pre-step. Publish an admitted first turn
  // before that gate evaluates; an unstarted preparation remains archived.
  ctx.on('agent/pre-step', async (payload, next) => {
    await playthroughDrafts.beforeStep(payload.agent)
    return next()
  }, { prepend: true })
  ctx.effect(() => () => playthroughDrafts.dispose(), 'dsh-tavern: playthrough drafts')

  const selectionPolicy = {
    selectedPresetId: (sessionId) => runtime.selection({ sessionId }).presetId,
    selectPreset: (id, sessionId) => {
      if (id !== null) store.get(id)
      if (sessionId === null) {
        store.select(id)
      } else {
        selections.set(sessionId, { presetId: id })
      }
      return id === null ? null : store.get(id)
    },
    beforeSelectionChange: ({ sessionId }) => {
      const agent = ctx.get('agents')?.get?.(sessionId)
      if (agent?.status === 'running') {
        const error = new Error('The session agent is running; change the preset after the current turn finishes.')
        error.code = 'PRESET_AGENT_RUNNING'
        error.status = 409
        throw error
      }
    },
    clearResource: (kind, id) => {
      const sessionChanged = selections.clearResource(kind, id)
      const bindingChanged = kind === 'preset' ? resourceWorldBooks.clearOwner('preset', id) : false
      return sessionChanged || bindingChanged
    },
    worldBookBindingPolicy: presetWorldBookBindingPolicy,
  }

  ctx.systemPrompt.section({
    name: PROFILE_SECTION,
    order: 10,
    text: (context) => {
      const snapshot = runtime.forAssembleContext(context)
      const claimMetadata = snapshot.audit?.activation ?? null
      snapshot.importedContext = importContexts.contextFor(context.agent?.id, claimMetadata, snapshot.macroContext, context.agent?.session)
      snapshot.registeredProfileText = [snapshot.systemText, snapshot.importedContext].filter(Boolean).join('\n\n')
      return snapshot.registeredProfileText
    },
  })
  ctx.systemPrompt.section({
    name: rpModeConstants.sectionName,
    order: rpModeConstants.sectionOrder,
    text: (context) => {
      if (context.tavernAssemblyPreview && draftPreview.current()) return rpMode.section
      if (context.agent === undefined) return ''
      return rpMode.isActive(context.agent) ? rpMode.section : ''
    },
  })

  ctx.on('agent/created', ({ agent }) => {
    const parentId = agent?.session?.header?.parentSession
    if (parentId) assemblyPresets.copySelection(parentId, agent.id)
    selections.ensureAgent(agent)
    pendingInput.ensureSession(agent?.session)
    // DSH awaits this serial lifecycle before exposing the Agent. A failed
    // policy initialization must fail registration, not permit an unguarded turn.
    rpMode.onSessionStart(agent)
  })

  ctx.on('agent/pre-step', async (payload, next) => {
    const decision = await next()
    if (decision?.kind === 'reject' || payload?.signal?.aborted) return decision
    try {
      rpMode.onBoundary(payload.agent)
      rpMode.enforceReadOnly(payload.agent?.session)
    } catch (error) {
      recordFailure('rp.policy', error, { sessionId: payload.agent?.id })
    }
    return decision
  })

  registerRpCommands(ctx, rpMode)
  registerRpWriteGuard(ctx, rpMode)

  ctx.on('agent/request', async (payload, next) => {
    traceSafely(() => assemblyRecorder.nextRequest(payload.agent?.id))
    const snapshot = runtime.assembledFor(payload.agent) ?? runtime.compile({ agent: payload.agent })
    const config = await parameterFallback.prepare(payload, await next(), snapshot.callConfig, ctx.get('llm'))
    let legacyRecord
    traceSafely(() => { legacyRecord = traceRecorder.begin({ ...payload, snapshot }) })
    traceSafely(() => assemblyRecorder.begin({ ...payload, snapshot, legacyRecord }))
    traceSafely(() => assemblyRecorder.parameters(payload.agent?.id, parameterFallback.snapshot(payload.agent)))
    return config
  })

  ctx.on('agent/assistant-stream', ({ agent, frame }) => parameterFallback.observeFrame(agent, frame))

  ctx.on('agent/error', payload => {
    traceSafely(() => assemblyRecorder.failure(payload))
  })

  ctx.on('llm/stream', async function* (options, next) {
    const agent = ctx.get('agents')?.get?.(options.sessionId)
    if (agent) traceSafely(() => assemblyRecorder.parameters(options.sessionId, parameterFallback.snapshot(agent, options)))
    traceSafely(() => assemblyRecorder.request(options, agent?.session, requestAssembler.observeNativeRequest(options, agent?.session)))
    yield* next()
  })
  ctx.effect(() => () => traceSafely(() => assemblyRecorder.dispose()))

  ctx.on('session/event', (session, event) => {
    pendingInput.observeSessionEvent(session, event)
    traceSafely(() => assemblyRecorder.observeSessionEvent(session, event))
    if (event?.type === 'turn/end') {
      traceSafely(() => assemblyRecorder.finish(session?.id, 'request-unconfirmed'))
      pendingInput.clearClaimed(session)
      importContexts.consumeAfterTurn(session?.id, event, session)
    }
    if (event?.type === 'sandbox/mode') {
      try { rpMode.enforceReadOnly(session) } catch (error) {
        recordFailure('rp.policy', error, { sessionId: session?.id })
      }
    }
    traceSafely(() => traceRecorder.observeSessionEvent(session, event))
  })

  ctx.on('agent/request-error', async (payload, next) => {
    const recovered = parameterFallback.recover(payload)
    if (recovered) traceSafely(() => assemblyRecorder.parameters(payload.agent?.id, parameterFallback.snapshot(payload.agent)))
    const result = recovered ? { kind: 'retry' } : await next()
    traceSafely(() => assemblyRecorder.finish(payload.agent?.id, 'request-failed-before-observation'))
    if (result?.kind === 'retry') traceSafely(() => assemblyRecorder.nextRequest(payload.agent?.id))
    traceSafely(() => traceRecorder.observeRequestError(payload.agent, payload.turn, payload.step))
    return result
  })

  ctx.on('system-prompt/assemble', async (assembly, context, next) => {
    const snapshot = runtime.forAssembleContext(context)
    let contributions = snapshot.sections
    if (!context.tavernAssemblyPreview && !runtime.requestAssemblyEnabled(snapshot.audit.sessionId) && assembly.sections.some(section => section.name === PROFILE_SECTION && section.text === snapshot.registeredProfileText)) {
      const request = context.agent && requestContexts.get(context.agent)
      const turn = context.agent?.session?.snapshotEvents?.().findLast(event => event.type === 'turn/start')?.data.turn
      const sourceContext = { sessionId: snapshot.audit.sessionId, assets: snapshot.assemblyInput, preview: context.tavernAssemblyPreview === true,
        turn: request?.turn ?? turn ?? null, step: request?.step ?? null, signal: request?.signal ?? context.signal }
      const loreEntries = await memorySources.worldBooks.prepareNative(sourceContext)
      const compiled = compileTavernProfile({ ...snapshot.assemblyInput, loreEntries })
      const literalEntries = new Set(loreEntries.filter(entry => entry.literalMacros).map(entry => entry.id))
      contributions = compiled.sections.map(section => ({ ...section,
        ...(section.sources?.some(source => source.kind === 'worldbook' && literalEntries.has(source.qualifiedEntryId)) ? { interpolate: false } : {}) }))
      snapshot.memoryContext = sourceContext
      memorySources.worldBooks.validateResolved(sourceContext)
    }
    const contexts = snapshot.runtimeContexts.length === 0
      ? assembly.contexts
      : [...assembly.contexts, ...snapshot.runtimeContexts]
    // Expand only our untouched contribution at its existing position. A third
    // party that already replaced it owns that replacement.
    const sections = assembly.sections.flatMap(section => {
      if (section.name !== PROFILE_SECTION) return [section]
      if (section.text !== snapshot.registeredProfileText) return [section]
      const imported = snapshot.importedContext
      return [...contributions.map(({ name, text, interpolate }) => ({ name, text, ...(interpolate === false ? { interpolate } : {}) })),
        ...(imported ? [{ name: PROFILE_SECTION, text: imported }] : [])]
    })
    const selected = snapshot.systemPromptMode === 'replace'
      ? sections.filter(s => s.name === PROFILE_SECTION || s.name.startsWith(`${PLUGIN_ID}:part:`) || s.name === rpModeConstants.sectionName)
      : sections
    // Publish our named contributions before downstream listeners execute.
    // Keep the official shared assembly object so later plugins can transform it.
    assembly.sections = selected
    assembly.contexts = contexts
    const result = await next()
    if (snapshot.memoryContext) memorySources.worldBooks.validateResolved(snapshot.memoryContext)
    // Ancestor transforms and complete-section enforcement may still follow.
    snapshot.officialAssembly = structuredClone(result)
    return result
  })

  const registerHttpApi = webCtx => {
    const mvuApi = createMvuApi(mvu, { drafts: playthroughDrafts })
    const assemblyApi = createAssemblyApi({ store: assemblyPresets, runtime: requestAssembler, agents: () => ctx.get('agents'), sessions: () => ctx.get('sessions'), inspect: id => ctx.get('sessionController').inspect(id), readActual: id => nativeRequests.readActual(id), notify: notifyChange })
    const promptTraceApi = createPromptTraceApi({ assemblies: assemblyStore, legacyStore: traceStore, requestAssembler,
      readBodies: nativeRequests.readBodies })
    const presetApi = createPresetApiHandler(
      store,
      notifyChange,
      (sessionId) => runtime.activeView(sessionId),
      selectionPolicy,
    )
    const characterApi = createCharacterApiHandler(characterStore, {
      onChange: notifyChange,
      logger: ctx.logger,
      selectionPolicy: characterSelectionPolicy,
      relinkCharacter: (previousCharacterId, character) => playMemberships.relinkCharacter(previousCharacterId, character, {
        selectionPolicy: characterSelectionPolicy,
      }),
      worldBookBindingPolicy: characterWorldBookBindingPolicy,
      beforeSelectionChange: ({ sessionId, characterCardId }) => {
        const agent = ctx.get('agents')?.get?.(sessionId)
        if (agent?.status === 'running') {
          const error = new Error('The session agent is running; change the character after the current turn finishes.')
          error.code = 'CHARACTER_AGENT_RUNNING'
          error.status = 409
          throw error
        }
        const conflicts = playMemberships.conflictsForSelection(sessionId, characterCardId)
        if (conflicts.length > 0) {
          const error = new Error('Changing this character will detach the session and its descendant branches from the playthrough.')
          error.code = 'CHARACTER_PLAYTHROUGH_DETACH_REQUIRED'
          error.status = 409
          error.details = { conflicts }
          throw error
        }
      },
    })
    const worldBookApi = createWorldBookApiHandler(worldBookStore, {
      onChange: notifyChange,
      selectionPolicy: worldBookSelectionPolicy,
      beforeSelectionChange: ({ sessionId }) => {
        const agent = ctx.get('agents')?.get?.(sessionId)
        if (agent?.status === 'running') {
          const error = new Error('The session agent is running; change world books after the current turn finishes.')
          error.code = 'WORLD_BOOK_AGENT_RUNNING'
          error.status = 409
          throw error
        }
      },
    })
    const userApi = createUserApiHandler(userStore, {
      onChange: notifyChange,
      selectionPolicy: userSelectionPolicy,
      worldBookBindingPolicy: userWorldBookBindingPolicy,
      beforeSelectionChange: ({ sessionId }) => {
        const agent = ctx.get('agents')?.get?.(sessionId)
        if (agent?.status === 'running') {
          const error = new Error('The session agent is running; change the user after the current turn finishes.')
          error.code = 'USER_AGENT_RUNNING'
          error.status = 409
          throw error
        }
      },
    })
    const traceApi = createTavernTraceApiHandler(traceStore)
    const sessionTemplateApi = createSessionTemplateApiHandler(sessionTemplateStore, sessionConfigurations, {
      onChange: change => {
        if (change.kind === 'session-configuration-applied') {
          notifyChange()
          reconcileRpAfterSelection(change.sessionId)
        }
      },
    })
    const uiSettingsApi = createUiSettingsApiHandler(uiSettingsStore)
    const conversationSettingsApi = createConversationSettingsApiHandler(conversationSettingsStore)
    const playApi = createPlayApiHandler({
      maintenanceService: playMaintenance,
      drafts: playthroughDrafts,
      chromeStore,
      workspaceStore: playWorkspaceStore,
      operationJournal,
      host: playHost,
      logger: ctx.logger,
      membershipService: playMemberships,
      resolveCharacter: characterId => characterStore.list().find(item => item.id === characterId) ?? null,
      relinkPlaythrough: (playthroughId, character, { operation }) => playMemberships.relinkPlaythrough(playthroughId, character, {
        operation,
        selectionPolicy: characterSelectionPolicy,
      }),
    })
    const rpPolicyApi = createRpPolicyApiHandler(rpPolicyStore, { onChange: notifyChange })
    const rpModeApi = createRpModeApiHandler(rpMode, {
      beforeChange: ({ sessionId, active }) => {
        notifyChange()
        if (typeof sessionId !== 'string' || typeof active !== 'boolean') return
      },
    })
    const openingWorldBookApi = createOpeningWorldBookHandler(openingWorldBooks, { getConnection: () => ctx.get('connection') })
    const api = secureTavernApi(
      (req, res) => isOpeningWorldBookPath(req.url)
        ? openingWorldBookApi(req, res)
        : isRenderingCachePath(req.url)
        ? renderingCacheApi(req, res)
        : isRenderingAuthorityPath(req.url)
        ? renderingAuthorityApi(req, res)
        : isMvuApiPath(req.url)
        ? mvuApi(req, res)
        : isAssemblyApiPath(req.url)
        ? assemblyApi(req, res)
        : new URL(req.url, 'http://localhost').pathname.startsWith(`${API_V3}/`)
        ? promptTraceApi(req, res)
        : isPlayApiPath(req.url)
        ? playApi(req, res)
        : isUiSettingsApiPath(req.url)
        ? uiSettingsApi(req, res)
        : isConversationSettingsApiPath(req.url)
          ? conversationSettingsApi(req, res)
        : isRpPolicyApiPath(req.url)
          ? rpPolicyApi(req, res)
        : isRpModeApiPath(req.url)
          ? rpModeApi(req, res)
        : isSessionTemplateApiPath(req.url)
          ? sessionTemplateApi(req, res)
        : isUserApiPath(req.url)
        ? userApi(req, res)
        : isTavernTraceApiPath(req.url)
          ? traceApi(req, res)
          : isCharacterApiPath(req.url)
            ? characterApi(req, res)
            : isWorldBookApiPath(req.url)
              ? worldBookApi(req, res)
              : presetApi(req, res),
      config.security,
    )
    ctx.effect(
      () => {
        const disposeRoute = webCtx.webServer.register({
          kind: 'prefix',
          path: API_ROOT,
          handler: api,
        })
        return () => {
          disposeRoute?.()
          chromeStore.dispose()
        }
      },
      'dsh-tavern: HTTP Tavern API',
    )
  }
  if (typeof ctx.inject === 'function') {
    ctx.inject(['webServer'], registerHttpApi)
  } else {
    const webServer = ctx.get('webServer')
    if (webServer !== undefined) registerHttpApi({ webServer })
  }

  startup.success('ready')
  Object.defineProperties(store, {
    operationJournal: { value: operationJournal, enumerable: false },
    profileLoader: { value: runtime, enumerable: false },
    sessionSelections: { value: selections, enumerable: false },
    characterStore: { value: characterStore, enumerable: false },
    worldBookStore: { value: worldBookStore, enumerable: false },
    userStore: { value: userStore, enumerable: false },
    userWorldBooks: { value: userWorldBooks, enumerable: false },
    resourceWorldBooks: { value: resourceWorldBooks, enumerable: false },
    sessionTemplateStore: { value: sessionTemplateStore, enumerable: false },
    sessionConfigurations: { value: sessionConfigurations, enumerable: false },
    uiSettingsStore: { value: uiSettingsStore, enumerable: false },
    conversationSettingsStore: { value: conversationSettingsStore, enumerable: false },
    chromeStore: { value: chromeStore, enumerable: false },
    playWorkspaceStore: { value: playWorkspaceStore, enumerable: false },
    playthroughDrafts: { value: playthroughDrafts, enumerable: false },
    playMaintenance: { value: playMaintenance, enumerable: false },
    playCleanup: { value: playCleanup, enumerable: false },
    rpPolicyStore: { value: rpPolicyStore, enumerable: false },
    assemblyStore: { value: assemblyStore, enumerable: false },
    traceStore: { value: traceStore, enumerable: false },
    traceRecorder: { value: traceRecorder, enumerable: false },
    pendingInputProjection: { value: pendingInput, enumerable: false },
    rpMode: { value: rpMode, enumerable: false },
  })
  return store
}

export function createApiHandler(store, onChange = () => {}) {
  const selections = new SessionSelectionStore(store.storageDir, {
    defaultSelection: () => ({ presetId: store.state.selectedId }),
  })
  const runtime = new TavernProfileLoader({ presetStore: store, selections })
  const selectionPolicy = {
    selectedPresetId: (sessionId) => runtime.selection({ sessionId }).presetId,
    selectPreset: (id, sessionId) => {
      if (id !== null) store.get(id)
      if (sessionId === null) store.select(id)
      else selections.set(sessionId, { presetId: id })
      return id === null ? null : store.get(id)
    },
    clearResource: (kind, id) => selections.clearResource(kind, id),
  }
  return createPresetApiHandler(store, onChange, (sessionId) => runtime.activeView(sessionId), selectionPolicy)
}

export { PresetRuntime } from './preset-runtime.js'
export { compilePresetForDsh, projectPresetCallConfig } from './profile-compiler.js'
export {
  TavernProfileLimitError,
  TavernProfileLoader,
  compileTavernProfile,
  conversationTextFromAgent,
  profileLoaderConstants,
} from './profile-loader.js'
export {
  SessionSelectionLimitError,
  SessionSelectionStore,
  normalizeSelection,
  sessionPolicyConstants,
} from './session-policy.js'
export {
  UserWorldBookBindingLimitError,
  UserWorldBookBindingStore,
  composeWorldBookSelection,
  userWorldBookPolicyConstants,
} from './user-world-book-policy.js'
export {
  ResourceWorldBookBindingLimitError,
  ResourceWorldBookBindingStore,
  resourceWorldBookPolicyConstants,
} from './resource-world-book-policy.js'
export { createWorldBookAdapter } from './world-book-adapter.js'
export { PendingInputProjection, pendingInputProjectionConstants } from './pending-input-projection.js'
export {
  RpPolicyStore,
  createRpPolicyApiHandler,
  isRpPolicyApiPath,
  normalizeRpPolicySection,
  rpPolicyStoreConstants,
} from './rp-policy-store.js'
export {
  DEFAULT_RP_SECTION,
  DEFAULT_RP_STATE,
  RpModeController,
  createRpModeApiHandler,
  foldSandboxMode,
  hasOpenTurn,
  isRpModeApiPath,
  normalizeRpState,
  registerRpCommands,
  registerRpWriteGuard,
  resolveRpConfig,
  RP_MUTATING_TOOL_NAMES,
  RP_WRITE_BLOCK_REASON,
  rpHighRiskGuardReason,
  rpModeConstants,
  rpWorkspaceReadGuardReason,
  rpWriteGuardReason,
} from './rp-mode.js'
export { createPlayHost } from './play-host.js'
export {
  ChromeStore,
  PlayWorkspaceStore,
  chromeConstants,
  createChromeEventsHandler,
  createPlayApiHandler,
  deriveFocus,
  isPlayApiPath,
  normalizeChrome,
  normalizeTimeline,
  playWorkspaceConstants,
  validatePlayDocument,
} from '../../play/src/index.js'
export { WorldBookStore, createWorldBookApiHandler } from '../../world-book-library/src/index.js'
export { secureTavernApi, apiSecurityConstants } from './api-security.js'
export {
  UiSettingsStore,
  createUiSettingsApiHandler,
  isUiSettingsApiPath,
  normalizeUiSettings,
  uiSettingsConstants,
} from './ui-settings.js'
export {
  ConversationSettingsStore,
  conversationSettingsConstants,
  createConversationSettingsApiHandler,
  isConversationSettingsApiPath,
  normalizeConversationSettings,
} from './conversation-settings.js'
export { TavernTraceRecorder, TavernTraceStore } from '../../tavern-trace/src/index.js'
export {
  SessionConfigurationError,
  SessionConfigurationService,
  SessionTemplateLimitError,
  SessionTemplateStore,
  createSessionTemplateApiHandler,
  sessionTemplateApiConstants,
  sessionTemplateStoreConstants,
} from '../../session-template/src/index.js'
export { PresetStore } from '../../preset/src/index.js'
export {
  API_ROOT,
  API_V1,
  API_V2,
  CLIENT_REFRESH_EVENT,
  CLIENT_UI_SETTINGS_EVENT,
  CLIENT_CONVERSATION_SETTINGS_EVENT,
  LEGACY_API_ROOT,
  PLUGIN_ID,
  PROFILE_SECTION,
  identityConstants,
} from '../../identity.js'
