import { installTavernStyle } from '../../../client-style.js'
import {OPENING_CARD_VIEWPORT_CSS} from './card-viewport.js'
import {createMvuCardBinding} from './mvu-bridge.js'
import {openingSourceIdentity} from './identity-opening-bridge.js'
import {initialCardScope,greetingCardScope} from './mvu-scope.js'
import {
  createElement,
  useEffect,
  useState,
} from 'react'
import { CLIENT_REFRESH_EVENT, PLUGIN_ID } from '../../../identity.js'
import {
  createLocalizedElement,
  rawText,
  uiMessage,
} from '../i18n.js'
import {
  ImportControls,
  installPlayChatStyles,
  loadChatState,
} from './chat.js'
import {
  adjacentGreetingIndex,
  loadCurrentPlaythrough,
} from './chat-model.js'
import { RichText } from './rich-text.js'
import {MessageContent} from './scripted-content.js'
import {useRestoredRenderingDisplay} from './rendering-display.js'
import { shouldShowUnboundNotice } from './sidebar-model.js'
import { conversationDisplayStyle, useConversationDisplaySettings } from './display-settings.js'
import { useClientUiSettings } from '../i18n/use-ui-settings.js'
import {useCardComposer} from './card-composer-hook.js'

const h = createLocalizedElement(createElement)

const css = `
${OPENING_CARD_VIEWPORT_CSS}
.dtv-play-unbound-notice{box-sizing:border-box;width:100%;max-width:var(--dsh-composer-card-max-width,100%);align-self:center;margin:0;padding:7px 10px;border:1px solid color-mix(in srgb,var(--dsw-alias-state-warning,#d79921) 34%,transparent);border-radius:10px;background:color-mix(in srgb,var(--dsw-alias-state-warning,#d79921) 8%,transparent);color:var(--dsw-alias-label-secondary);font-size:11px;line-height:1.45}
.dtv-play-opening-dock{box-sizing:border-box;width:100%;min-width:0;flex:none;display:flex;flex-direction:column;overflow:hidden;border:1px solid var(--dsw-alias-border-l2);border-radius:14px;background:var(--dsw-alias-bg-layer-2,var(--dsw-specific-block));color:var(--dsw-alias-label-primary);box-shadow:0 4px 18px color-mix(in srgb,var(--dsw-alias-label-primary) 7%,transparent)}
.dtv-play-opening-header{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:9px 12px;border-bottom:1px solid var(--dsw-alias-border-l2);font-size:12px}.dtv-play-opening-name{min-width:0;overflow:hidden;font-weight:650;text-overflow:ellipsis;white-space:nowrap}.dtv-play-opening-index{flex:none;color:var(--dsw-alias-label-tertiary);font-size:11px}
.dtv-play-opening-body{box-sizing:border-box;max-height:45dvh;overflow-x:hidden;overflow-y:auto;padding:13px 15px;font-size:calc(14px * var(--dtv-rp-text-scale,1));line-height:1.65;overflow-wrap:anywhere}.dtv-play-opening-body-empty{min-height:34px}.dtv-play-opening-body>:first-child{margin-top:0}.dtv-play-opening-body>:last-child{margin-bottom:0}.dtv-play-opening-body p,.dtv-play-opening-body ul,.dtv-play-opening-body ol,.dtv-play-opening-body blockquote,.dtv-play-opening-body pre,.dtv-play-opening-body table{margin:0 0 .85em}.dtv-play-opening-body ul,.dtv-play-opening-body ol{padding-left:1.5em}.dtv-play-opening-body pre,.dtv-play-opening-body table{max-width:100%;overflow:auto}.dtv-play-opening-body img,.dtv-play-opening-body video{max-width:100%;height:auto}
.dtv-play-opening-actions{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1fr);align-items:center;gap:8px;padding:8px 10px;border-top:1px solid var(--dsw-alias-border-l2)}.dtv-play-opening-actions>.dtv-play-opening-button:first-child{justify-self:start}.dtv-play-opening-actions>.dtv-play-opening-button:last-child{justify-self:end}.dtv-play-opening-actions>.dtv-play-import-controls{margin:0}.dtv-play-opening-button{min-width:0;padding:6px 10px;border:0;border-radius:9px;background:transparent;color:var(--dsw-alias-label-secondary);font:inherit;font-size:12px;cursor:pointer}.dtv-play-opening-button:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}.dtv-play-opening-button:disabled{opacity:.4;cursor:default}.dtv-play-opening-error{margin:0;padding:7px 12px;border-top:1px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-state-error);font-size:11px;line-height:1.45}
`

function installStyles() {
  installTavernStyle(`${PLUGIN_ID}-play-notice`, css)
}

export function PlaySessionDock({ session, useSessions, useConversation, useInput, inputActions, conversationPhase, playClient }) {
  useClientUiSettings()
  installStyles()
  installPlayChatStyles()
  const sessionId = session?.sessionId ?? null
  const sessionBlank = session?.blank === true
  const conversation = useConversation(state => state)
  const composerPhase = conversationPhase(session, conversation)
  const summary = useSessions(state => sessionId === null ? null : state.byId?.[sessionId] ?? null)
  const [revision, setRevision] = useState(0)
  const [content, setContent] = useState(null)
  const [greetingBusy, setGreetingBusy] = useState(false)
  const [error, setError] = useState('')
  const displaySettings = useConversationDisplaySettings()
  useRestoredRenderingDisplay(content?.sessionId===sessionId&&content?.kind==='opening'&&sessionBlank&&composerPhase==='blank'?content.display:null,displaySettings,setError)
  const composer=useCardComposer({sessionId,useInput,inputActions,active:content?.kind==='opening'&&content.sessionId===sessionId,blocked:!sessionBlank||greetingBusy||composerPhase!=='blank',send:(text,{signal}={})=>playClient.postUserMessage(sessionId,text,{signal})})

  useEffect(() => {
    const refresh = () => setRevision(value => value + 1)
    window.addEventListener(CLIENT_REFRESH_EVENT, refresh)
    return () => window.removeEventListener(CLIENT_REFRESH_EVENT, refresh)
  }, [])

  useEffect(() => {
    let active = true
    if(composer?.pending&&content?.kind==='opening'&&content.sessionId===sessionId)return()=>{active=false}
    setContent(null)
    setError('')
    if (sessionId === null || summary === null) return () => { active = false }
    Promise.all([
      playClient.getWorkspace(),
      playClient.getCharacterSelection(sessionId),
    ]).then(([workspace, selection]) => {
      if (!active) return
      if (shouldShowUnboundNotice({ workspace, session: summary, selection })) {
        setContent({ kind: 'unbound', sessionId })
        return
      }
      if (!sessionBlank || composerPhase !== 'blank') {
        setContent(null)
        return
      }
      loadCurrentPlaythrough(playClient, summary).then(binding => {
        if (!active) return
        if (binding === null || (binding.timeline?.nodes?.length ?? 0) !== 0) {
          setContent(null)
          return
        }
        loadChatState(playClient, sessionId, binding.playthrough).then(state => {
          if (!active) return
          setContent({
            kind: 'opening',
            greetingScope:greetingCardScope({playthrough:binding.playthrough,sessionId,characterId:state.display?.bindings?.characterId}),
            initialScope:initialCardScope({playthrough:binding.playthrough,sessionId,characterId:state.display?.bindings?.characterId,timeline:binding.timeline,turns:state.turns}),
            greeting: state.greeting,
            display: state.display,
            importBinding: state.importBinding,
            importMutable: state.importMutable,
            importTurns: state.turns
              .filter(turn => turn.imported === true && turn.id !== 'import-greeting')
              .slice(-3),
            playthrough: binding.playthrough,
            sessionId,
          })
        }, reason => {
          if (active) setError(reason instanceof Error ? reason.message : String(reason))
        })
      }, reason => {
        if (active) setError(reason instanceof Error ? reason.message : String(reason))
      })
    }, reason => {
      if (active) setError(reason instanceof Error ? reason.message : String(reason))
    })
    return () => { active = false }
  }, [composerPhase, playClient, revision, sessionBlank, sessionId, summary, composer?.pending])

  const changeGreeting = async direction => {
    if (content?.kind !== 'opening' || greetingBusy || sessionId === null) return
    const next = adjacentGreetingIndex(content.greeting, direction)
    if (next === null) return
    setGreetingBusy(true)
    setError('')
    try {
      await playClient.putGreetingIndex(sessionId, next)
      setRevision(value => value + 1)
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason))
    } finally {
      setGreetingBusy(false)
    }
  }

  if (content?.sessionId !== sessionId) return null
  if (content.kind === 'unbound') {
    return h('p', {
      className: 'dtv-play-unbound-notice',
      role: 'note',
    }, uiMessage('play.notice.unbound'))
  }
  if (content.kind !== 'opening' || ((!sessionBlank || composerPhase !== 'blank')&&!composer?.pending)) return null
  const greeting = content.greeting
  const importTurns = content.importTurns ?? []
  const options = greeting?.options ?? []
  const position = greeting === null ? 0 : Math.max(0, options.findIndex(option => option.index === greeting.index)) + 1
  const importControls = h(ImportControls, {
    playClient,
    playthrough: content.playthrough,
    binding: content.importBinding,
    locked: content.importMutable !== true,
    changed: () => setRevision(value => value + 1),
    onError: setError,
  })
  return h('section', {
    className: 'dtv-play-opening-dock',
    style: conversationDisplayStyle(displaySettings),
  },
  greeting === null ? null : h('header', { className: 'dtv-play-opening-header' },
    h('span', { className: 'dtv-play-opening-name' }, rawText(greeting.characterName)),
    h('span', { className: 'dtv-play-opening-index' }, rawText(`${position} / ${options.length}`)),
  ),
  importTurns.length > 0
    ? h('div', { className: 'dtv-play-opening-body dtv-play-chat-list' },
      ...importTurns.map(turn => h('div', { key: turn.id, className: 'dtv-play-chat-row' },
        turn.userText === '' ? null : h(RichText, {
          className: 'dtv-play-chat-bubble dtv-play-chat-user dtv-play-rich',
          text: turn.userText,
        }),
        turn.assistantText === '' ? null : h(RichText, {
          className: 'dtv-play-chat-bubble dtv-play-chat-assistant dtv-play-rich',
          text: turn.assistantText,
        }),
      )),
    )
    : greeting === null
      ? h('div', { className: 'dtv-play-opening-body dtv-play-opening-body-empty', 'aria-hidden': true })
      : h('div',{className:'dtv-play-opening-body','data-dtv-card-viewport-boundary':'opening'},h(MessageContent,{
        text:greeting.text,
        openingBinding:openingSourceIdentity({sessionId,greeting}),
        composer,
        writeScope:content.initialScope,
        createBinding:content.greetingScope?(signal,writeGrant)=>createMvuCardBinding({client:playClient,scope:writeGrant?content.initialScope:content.greetingScope,signal,writeGrant}):undefined,
        enabled:displaySettings.interactiveCards!==false,
        scopeKey:JSON.stringify([sessionId,content.playthrough.id,'greeting',greeting.index,content.greetingScope,content.initialScope]),
        owners:[content.display?.globalRenderingOwner,...Object.entries(content.display?.bindings??{}).filter(([,id])=>typeof id==='string'&&id).map(([kind,id])=>`${kind==='characterId'?'character':'preset'}:${id}`)].filter(Boolean),
        helpers:(content.display?.renderingSources??[]).filter(item=>item.kind==='helper'),
        context:{version:1,role:'assistant',userName:content.display?.macros?.user??'User',characterName:content.display?.macros?.character??'Assistant'},
        onSend:async text=>{await playClient.postUserMessage(sessionId,text);setRevision(value=>value+1)},
      })),
  error === '' ? null : h('p', { className: 'dtv-play-opening-error', role: 'alert' }, rawText(error)),
  h('footer', { className: 'dtv-play-opening-actions' },
    h('button', {
      type: 'button',
      className: 'dtv-play-opening-button',
      disabled: greetingBusy || adjacentGreetingIndex(greeting, 'previous') === null,
      onClick: () => changeGreeting('previous'),
    }, uiMessage('play.chat.previousGreeting')),
    importControls,
    h('button', {
      type: 'button',
      className: 'dtv-play-opening-button',
      disabled: greetingBusy || adjacentGreetingIndex(greeting, 'next') === null,
      onClick: () => changeGreeting('next'),
    }, uiMessage('play.chat.nextGreeting')),
  ))
}
