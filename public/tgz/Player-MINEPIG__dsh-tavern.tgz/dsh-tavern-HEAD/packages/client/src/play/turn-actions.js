import { installTavernStyle } from '../../../client-style.js'
import {
  createElement,
  useEffect,
  useState,
} from 'react'
import { CLIENT_REFRESH_EVENT, PLUGIN_ID } from '../../../identity.js'
import {
  createLocalizedElement,
  translate,
  uiMessage,
} from '../i18n.js'
import { createPlayNodeController } from './nodes.js'
import { pendingSwipe } from './pending-swipe.js'
import { queueSwipeTransition } from './swipe-transition.js'

const h = createLocalizedElement(createElement)
const controllers = new WeakMap()

const css = `
.dtv-play-turn-actions{display:flex;flex-wrap:wrap;align-items:center;gap:calc(2px * var(--dtv-rp-action-scale,1));min-height:calc(28px * var(--dtv-rp-action-scale,1))}.dtv-play-turn-action{flex-shrink:0;width:calc(28px * var(--dtv-rp-action-scale,1));height:calc(28px * var(--dtv-rp-action-scale,1));border:0;border-radius:calc(8px * var(--dtv-rp-action-scale,1));background:transparent;color:var(--dsw-alias-label-tertiary);font:inherit;font-size:calc(14px * var(--dtv-rp-action-scale,1));cursor:pointer;display:grid;place-items:center}.dtv-play-turn-action:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}.dtv-play-turn-action:disabled{cursor:default;opacity:.38}.dtv-play-turn-position{padding:0 calc(5px * var(--dtv-rp-action-scale,1));color:var(--dsw-alias-label-tertiary);font-size:calc(10px * var(--dtv-rp-action-scale,1))}
.dtv-play-display-editor{display:flex;flex-direction:column;align-self:stretch;gap:8px}.dtv-play-display-editor textarea{box-sizing:border-box;width:100%;min-height:180px;max-height:55vh;resize:vertical;padding:12px 14px;border:1px solid var(--dsw-alias-border-l2);border-radius:12px;background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);font:inherit;font-size:14px;line-height:1.65}.dtv-play-display-editor textarea:focus{outline:2px solid color-mix(in srgb,var(--dsw-alias-state-business-primary,#2677d9) 35%,transparent);border-color:var(--dsw-alias-state-business-primary,#2677d9)}.dtv-play-display-editor-actions{display:flex;justify-content:flex-end;gap:8px}.dtv-play-display-editor-button{min-width:76px;min-height:34px;padding:7px 12px;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;background:var(--dsw-alias-button-secondary-fill,var(--dsw-alias-bg-base));color:var(--dsw-alias-label-primary);font:inherit;cursor:pointer}.dtv-play-display-editor-button[data-primary=true]{border-color:transparent;background:var(--dsw-alias-state-business-primary,#2677d9);color:var(--dsw-alias-button-primary-label,#fff)}.dtv-play-display-editor-button:disabled{cursor:default;opacity:.45}
`

function installStyles() {
  installTavernStyle(`${PLUGIN_ID}-play-turn-actions`, css)
}

function controller(client) {
  let value = controllers.get(client)
  if (value === undefined) {
    value = createPlayNodeController(client)
    controllers.set(client, value)
  }
  return value
}

function Action({ icon, label, disabled = false, disabledLabel, onClick }) {
  return h('button', {
    type: 'button',
    className: 'dtv-play-turn-action',
    disabled,
    title: disabled ? (disabledLabel ?? uiMessage('play.chat.runningDisabled')) : label,
    'aria-label': label,
    onClick,
  }, icon)
}

export function PlayTurnActionsPreview({ scale = 1 }) {
  installStyles()
  return h('div', { className: 'dtv-play-turn-actions', role: 'group', 'aria-label': uiMessage('appearance.actionPreview'), style: { '--dtv-rp-action-scale': scale } },
    h(Action, { icon: '⧉', label: uiMessage('play.chat.copy') }),
    h(Action, { icon: '‹', label: uiMessage('play.chat.previousReply') }),
    h('span', { className: 'dtv-play-turn-position' }, '1/2'),
    h(Action, { icon: '›', label: uiMessage('play.chat.nextReply') }),
    h(Action, { icon: '⑂', label: uiMessage('play.chat.forkPlaythrough') }),
    h(Action, { icon: '↩', label: uiMessage('play.chat.rollbackPlaythrough') }),
    h(Action, { icon: '✎', label: uiMessage('play.chat.editDisplay') }),
  )
}

export function turnActionCapabilities(turn) {
  return {
    copy: true,
    variants: true,
    generateReply: true,
    fork: true,
    editDisplay: true,
  }
}

export function StoppedRequestActions({request,nodeId,playthrough,playClient,openSession,running,readOnly,onChanged,onError,onSwipePending}){
 installStyles()
 const [busy,setBusy]=useState(false),pending=pendingSwipe(playClient,playthrough)
 const disabled=readOnly||running||busy||(pending!==null&&pending.error===null)
 async function retry(){
  if(disabled)return
  setBusy(true);onError('');onSwipePending?.(nodeId,true)
  try{
   await controller(playClient).retryStoppedRequest(playthrough,request,{onStarted:value=>openSession(value.sessionId,playthrough)})
   window.dispatchEvent(new Event(CLIENT_REFRESH_EVENT));onChanged()
  }catch(error){onError(error instanceof Error?error.message:String(error))}
  finally{onSwipePending?.(nodeId,false);setBusy(false)}
 }
 return h('div',{className:'dtv-play-turn-actions'},
  h('span',{className:'dtv-play-turn-position'},uiMessage('play.chat.stoppedWithoutReply')),
  h(Action,{icon:'›',label:uiMessage('play.chat.retryStoppedRequest'),disabled,onClick:retry}))
}

export function PlayTurnActions({
  turn,
  playthrough,
  playClient,
  openSession,
  running,
  readOnly = false,
  onChanged,
  onError,
  onSwipePending,
  pendingVariant = false,
}) {
  installStyles()
  const [busy, setBusy] = useState(false)
  const [editor, setEditor] = useState(null)
  const [generating, setGenerating] = useState(false)
  const pending = pendingSwipe(playClient, playthrough)
  const pathLocked = running || generating || (pending !== null && pending.error === null)
  const displayDisabled = readOnly || busy
  const disabled = pathLocked || displayDisabled
  const position = Math.max(0, turn.variants.findIndex(item => item.id === turn.variant.id))
  const displayedPosition = pendingVariant ? turn.variants.length : position
  const displayedVariantCount = pendingVariant ? turn.variants.length + 1 : turn.variants.length
  const capabilities = turnActionCapabilities(turn)
  const hasPreviousVariant = position > 0
  const hasNextVariant = position + 1 < turn.variants.length
  useEffect(() => setEditor(null), [turn.id, turn.variant.id])

  const mutate = async (operation, displayOnly = false) => {
    if (displayOnly ? displayDisabled : disabled) return
    setBusy(true)
    onError('')
    try {
      await operation()
      onChanged()
    } catch (reason) {
      onError(reason instanceof Error ? reason.message : String(reason))
    } finally {
      setBusy(false)
    }
  }

  const adopt = targetPosition => mutate(async () => {
    const target = turn.variants[targetPosition]
    if (target === undefined) throw new TypeError('Reply variant does not exist')
    const result = await controller(playClient).adoptVariant(playthrough, turn.id, target.id)
    queueSwipeTransition(result.sessionId, targetPosition < position ? 'previous' : 'next', turn.id)
    openSession(result.sessionId, playthrough)
  })

  const generate = async () => {
    if (disabled) return
    setGenerating(true)
    onError('')
    onSwipePending?.(turn.id, true)
    try {
      await controller(playClient).createReplySwipe(playthrough, turn.id, {
        onStarted: result => {
          queueSwipeTransition(result.sessionId, 'next', result.nodeId ?? turn.id)
          openSession(result.sessionId, playthrough)
        },
      })
      window.dispatchEvent(new Event(CLIENT_REFRESH_EVENT))
      onChanged()
    } catch (reason) {
      onError(reason instanceof Error ? reason.message : String(reason))
    } finally {
      onSwipePending?.(turn.id, false)
      setGenerating(false)
    }
  }

  const copy = async () => {
    try {
      if (typeof navigator.clipboard?.writeText !== 'function') throw new Error(translate('play.chat.copyUnavailable'))
      await navigator.clipboard.writeText(turn.assistantText)
    } catch (reason) {
      onError(reason instanceof Error ? reason.message : String(reason))
    }
  }

  if (editor !== null) {
    return h('form', {
      className: 'dtv-play-display-editor',
      onSubmit: event => {
        event.preventDefault()
        const value = editor
        mutate(async () => {
          await controller(playClient).setDisplayOverride(playthrough, turn.id, value)
          setEditor(null)
        }, true)
      },
    },
    h('textarea', {
      value: editor,
      autoFocus: true,
      disabled: displayDisabled,
      'aria-label': uiMessage('play.chat.editDisplayPrompt'),
      onChange: event => setEditor(event.target.value),
      onKeyDown: event => {
        if (event.key === 'Escape' && !displayDisabled) setEditor(null)
      },
    }),
    h('div', { className: 'dtv-play-display-editor-actions' },
      h('button', {
        type: 'button',
        className: 'dtv-play-display-editor-button',
        disabled: displayDisabled,
        onClick: () => setEditor(null),
      }, uiMessage('common.cancel')),
      h('button', {
        type: 'submit',
        className: 'dtv-play-display-editor-button',
        'data-primary': true,
        disabled: displayDisabled,
      }, uiMessage('common.save')),
    ))
  }

  return h('div', { className: 'dtv-play-turn-actions' },
    h(Action, { icon: '⧉', label: uiMessage('play.chat.copy'), onClick: copy }),
    !capabilities.variants ? null : h(Action, {
      icon: '‹',
      label: uiMessage('play.chat.previousReply'),
      disabled: disabled || !hasPreviousVariant,
      disabledLabel: !pathLocked && !hasPreviousVariant ? uiMessage('play.chat.noOtherReply') : undefined,
      onClick: () => adopt(position - 1),
    }),
    !capabilities.variants ? null : h('span', { className: 'dtv-play-turn-position' }, `${displayedPosition + 1}/${displayedVariantCount}`),
    !capabilities.variants ? null : h(Action, {
      icon: '›',
      label: uiMessage(hasNextVariant ? 'play.chat.nextReply' : 'play.chat.generateReply'),
      disabled,
      onClick: hasNextVariant ? () => adopt(position + 1) : generate,
    }),
    h(Action, {
      icon: '⑂',
      label: uiMessage('play.chat.forkPlaythrough'),
      disabled,
      onClick: () => mutate(async () => {
        const result = await controller(playClient).forkPlaythrough(playthrough, turn.id)
        window.dispatchEvent(new Event(CLIENT_REFRESH_EVENT))
        openSession(result.sessionId, result.playthrough)
      }),
    }),
    h(Action, {
      icon: '↩',
      label: uiMessage('play.chat.rollbackPlaythrough'),
      disabled,
      onClick: () => mutate(async () => {
        const result = await controller(playClient).rollbackPlaythrough(playthrough, turn.id)
        openSession(result.sessionId, playthrough)
      }),
    }),
    h(Action, {
      icon: '✎',
      label: uiMessage('play.chat.editDisplay'),
      disabled: displayDisabled,
      onClick: () => setEditor(turn.assistantText),
    }),
    turn.displayOverridden ? h(Action, {
      icon: '↺',
      label: uiMessage('play.chat.restoreOriginal'),
      disabled: displayDisabled,
      onClick: () => mutate(() => controller(playClient).setDisplayOverride(playthrough, turn.id, null), true),
    }) : null,
  )
}
