# Project Guidelines

This file records project-specific guidance. General scope control, debugging, review, and skill maintenance belong to applicable global skills, used according to their own triggers. This project does not require installing or loading them for every task.

For project contracts, DSH version compatibility, or release evidence, use the topic links in the [development skill](.agents/skills/dsh-tavern-development/SKILL.md).

## Project Boundaries

- Preserve the current architecture during ordinary maintenance: DSH durable history is authoritative, integration uses public DSH extension points, and native DSH and original sessions remain usable after Tavern is removed. When changing these decisions, explain the external behavior, compatibility, and migration costs, then implement the user-approved decision.
- Keep public APIs as composable primitives. Before adding an endpoint, check existing Tavern APIs and public DSH extension points, identify the missing capability, and leave composition policy to callers. Use the [API scope](docs/API.md#api-scope) as the current boundary.
- Use branches, worktrees, and commits as requested by the user or required by the active project workflow. The maintainer has authorized directly pushing completed commits whenever the repository has a configured remote. Complete local validation first, then push the current intended branch without repeated confirmation; do not force-push or broaden the change scope. PR creation, tags, and releases also require explicit user authorization.
- Read private development plans only when explicitly provided as a workspace. Without explicit approval, do not copy private-plan content, repository coordinates, user data, or absolute local paths into the public repository.
- Installation, uninstallation, migration, and data writes against real DSH profiles must fall within the task's authorization. Ordinary code changes do not automatically authorize these operations.

## Documentation

Keep `docs/` for maintained project documentation: current contracts, architecture, integration, usage, and reusable verification procedures, with matching bilingual documents and diagrams. Replace obsolete prose instead of appending dated corrections or completed-stage ledgers. Release announcements, issue reply drafts, development plans, and run-specific acceptance records belong under Git-ignored `.local/`, not in the repository or installable package. Version history belongs in root `CHANGELOG.md`; readers can use the corresponding Git tag for older full documentation. Retain older-format details only where they explain a currently supported compatibility or migration path.

When asked to prepare a release, deliver a fully validated candidate that can be published immediately after review without another content-editing pass. Set the final version, changelog, bilingual documentation, and installation/tag examples to the intended release. Do not leave “preparing for release,” “unreleased,” or old-version installation placeholders in that candidate. Keep pending approval/publication status in the handoff and Git-ignored `.local/`, without claiming publication has occurred. If review finds issues, revise or roll back the candidate before publication; release preparation itself does not authorize a push, tag, or release.

## Validation by Change Scope

Local builds and tests using temporary directories and fixtures, including fixes and reruns for failures caused by the requested change, may proceed without step-by-step confirmation.

Complete affected Host, browser, and desktop checks that available tools and task-authorized environments permit before handing off manual acceptance. Reserve remaining items for maintainer judgment or unavailable environments and integrations, and state the specific gap; passing automated tests alone does not establish UI acceptance.

Command definitions live in [package.json](package.json). Select according to the affected behavior:

| Change scope | Validation |
| --- | --- |
| Documentation only | Check content, links, and diff; no build or test suite needed |
| Localized logic | `node --test test/<relevant-file>.test.mjs` |
| Cross-module behavior | `npm test` |
| Client bundle changes | Relevant tests and `npm run build`; `dist/client.js` is generated |
| Full build and test coverage needed | `npm run check` |
| Protocol, installation/package contents, or release preparation | `npm run verify:2.0`, plus runtime acceptance appropriate to the task |

For DSH integration changes, see the [compatibility reference](.agents/skills/dsh-tavern-development/references/dsh-compatibility.md) for real Host, browser, and migration checks and what they establish.

<!-- Rationale: https://x.com/pvncher/status/2095991462416490862. Keep persistent guidance concise and load topic-specific details on demand. -->
