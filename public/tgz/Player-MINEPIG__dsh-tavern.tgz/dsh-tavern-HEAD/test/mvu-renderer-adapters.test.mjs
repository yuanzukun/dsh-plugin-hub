import test from 'node:test'
import assert from 'node:assert/strict'
import {MVU_ADAPTERS,mvuAdapter,confirmMvuSchemas} from '../packages/client/src/play/mvu-builtins.js'
import {isSideEffectModuleReference} from '../packages/client/src/play/rendering-sources.js'
import {initialCardScope,greetingCardScope} from '../packages/client/src/play/mvu-scope.js'
test('local replacements require an exact alias, contract version and supported side-effect import',()=>{
 const entry=MVU_ADAPTERS[0]
 assert.equal(mvuAdapter(entry.url,entry.version),entry)
 assert.equal(mvuAdapter(entry.url+'?version=2',entry.version),null)
 assert.equal(mvuAdapter(entry.url,2),null)
 assert.equal(isSideEffectModuleReference(`import '${entry.url}';\nMvu.getMvuData()`,entry.url),true)
 for(const source of [`import {value} from '${entry.url}'`,`import('${entry.url}')`,`export * from '${entry.url}'`,`import '${entry.url}';import('${entry.url}')`])assert.equal(isSideEffectModuleReference(source,entry.url),false)
})
test('complete schema source confirmation requires backend authority and supported descriptor version',()=>{
 const declarations=[{source:'exact schema source',sha256:'fixture',owner:'fixture'}]
 const snapshot={status:'available',resourceId:'resource',revision:3,variables:{mvu_schema:{mvuSchema:1,interpreterVersion:1,source:declarations[0].source}}}
 assert.equal(confirmMvuSchemas(declarations,snapshot)[0].status,'source-registered')
 const v2={...snapshot,variables:{mvu_schema:{...snapshot.variables.mvu_schema,interpreterVersion:2}}}
 assert.equal(confirmMvuSchemas(declarations,v2)[0].interpreterVersion,2)
 for(const replacement of [undefined,{...snapshot,status:'unavailable'}])assert.throws(()=>confirmMvuSchemas(declarations,replacement),error=>error.code==='MVU_SNAPSHOT_UNAVAILABLE')
 for(const replacement of [{...snapshot,variables:{}}, {...snapshot,variables:{mvu_schema:{...snapshot.variables.mvu_schema,source:'different'}}}, {...snapshot,variables:{mvu_schema:{...snapshot.variables.mvu_schema,interpreterVersion:3}}}])assert.throws(()=>confirmMvuSchemas(declarations,replacement),error=>error.code==='MVU_SCHEMA_MISMATCH'&&/exact complete schema/.test(error.message))
})
test('initial coordinates require the resolved root and selected character with empty timeline',()=>{
 const input={playthrough:{id:'p',ext:{pmpDshTavern:{rootSessionId:'s',characterId:'c'}}},sessionId:'s',characterId:'c',timeline:{nodes:[]},turns:[]}
 assert.deepEqual(initialCardScope(input),{mode:'initial',playthroughId:'p',sessionId:'s',characterId:'c'})
 for(const patch of [{sessionId:'other'},{characterId:'other'},{timeline:null},{timeline:{nodes:[{}]}},{turns:[{}]}])assert.equal(initialCardScope({...input,...patch}),null)
})

test('greeting current read scope survives turns without granting an initial write scope',()=>{
 const input={playthrough:{id:'p',ext:{pmpDshTavern:{rootSessionId:'s',characterId:'c'}}},sessionId:'s',characterId:'c',timeline:{nodes:[{}]},turns:[{}]}
 assert.deepEqual(greetingCardScope(input),{mode:'greeting',playthroughId:'p',sessionId:'s',characterId:'c'})
 assert.equal(initialCardScope(input),null)
 for(const patch of [{sessionId:'other'},{characterId:'other'},{playthrough:null}])assert.equal(greetingCardScope({...input,...patch}),null)
 const branch={...input,sessionId:'child',timeline:{nodes:[{variants:[{sessionId:'child'}]}]}}
 assert.deepEqual(greetingCardScope(branch),{mode:'greeting',playthroughId:'p',sessionId:'child',characterId:'c'})
 assert.equal(initialCardScope(branch),null)
})
