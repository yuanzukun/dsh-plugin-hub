# dsh-tavern package architecture

[English](ARCHITECTURE_en.md)

必需的独立 [assembler 插件](ASSEMBLER_INTEGRATION.md)拥有 registry、策略存储与请求装配；标准版通过 DSH 公开接口排列官方 system 段落并贡献 user context/pre-step；只有显式安装可选 `dsh-prompt-assembler-core` 并准备配套核心时，进阶策略才启用完整请求排列。下文原有 loader 路径继续用于未应用装配预设的会话；两条路径都保留 DSH 对持久历史和 Provider 序列化的所有权。

DSH 破坏性更新评估：[原生依赖架构图与分级矩阵](assets/dsh-dependencies/README.md)（含交互 HTML、仓库相对源码链接和升级检查入口）。

当前合同面向本仓库源码（版本见 [package.json](../package.json)）与 DSH `0.2.1-rc.2`；安装标识为
`pmp-dsh-tavern`。HTTP 挂载 `/pmp-dsh-tavern/api`，资源走 `/v1`，扮演表面合同走
`/v2`，装配审计走 `/v3`。本文记录当前架构决策与发布审查门槛。

[Tavern 交互架构图](assets/architecture/tavern.zh-CN.html) · [三插件组合架构图](assets/architecture/ecosystem.zh-CN.html)。同目录 JSON 是可编辑的 Archify 规格。DSH durable history 为权威历史；Tavern 保存资源、状态、草稿、配置与有界 Trace 引用。

## 操作诊断与兼容边界

操作 journal 是 Tavern 自有的有界诊断存储，与当前问题投影、Prompt Trace 和 DSH 权威历史各自独立。API 路由声明拥有操作名和固定路径模板，统一边界负责开始／终态；业务与既有 `play-host.js` 适配器只报告少量已确认检查点。journal 不依赖 DSH 服务、事件或历史格式，不新增 DSH 监听器。DSH 升级优先只改已有兼容层；只有业务语义改变才调整事件合同。查询与 UI 依赖 [操作日志合同](OPERATION_LOGS.md)，不依赖内部函数阶段名。

## 目标 Host 与持久数据边界

3.0.4 合同面向 DSH 0.2.1-rc.2、Cordis 4.0.5 与 `dsh-util-crypto` 0.2.1-rc.2，不支持旧 Host 运行时。串行 `agent/created` listener 在首次使用前初始化选择、公开 pending-input 投影与 RP；初始化失败向外传播。

DSH V4 拥有 system/user/assistant/tool 历史与 producer source，包括 `runtime-context` snapshot 和原生 tool-role result。准备顺序为装配 → pre-step → request/config 准备 → 接纳消息写入 → request header 与冻结消息 → stream。Trace 捕获官方正文/错误引用及生效参数，不建立第二份历史。[单向坐标升级](DSH_0.1.7_MIGRATION.md) 使用已验证的官方迁移阶段，保留全部升级前插件备份，不改写 DSH 日志。V3 之前的 header-body Trace 引用明确拒绝转换，不提供回滚工具。

## 周目归档

Tavern 用 catalog 条目的 `ext.pmpDshTavern.archivedAt` 表示归档，通过现有文件 revision/CAS 更新。归档不拆除周目与会话关系，也不移动文件、清除 selection 或调用 DSH 的 `archiveSession`。侧边栏将归档周目投影到默认折叠的归档箱，保留成员归属以避免会话重新成为游离项；其他活动周目仍可显示共享会话。恢复只移除标记。读取 timeline 仍用于核对成员归属，归档不承诺减少磁盘占用或完整 catalog 的大小。旧版客户端忽略归档显示约定，旧 catalog 无需迁移。

## RP 错误提示

展示层通过 DSH `0.2.1-rc.2` 的公开 `useChat` timeline 读取最新回合的 `turn/end.reason.kind === 'error'`，并汇总 `useSession` 的 `promptError`、`lastAgentError` 和 `openError`。显示随 Tavern 语言变化的提示及公开错误中的 code/message（包括会话写锁错误），原生“对话”视图保留进一步诊断；不匹配提供方错误文本、不保存第二份错误历史。新提交和生成期间隐藏旧回合提示，后续回合开始、成功或主动取消不会继续显示历史失败；当前 Session 错误不被 busy 状态掩盖。浏览器崩溃和未到达这些公开入口的连接故障不属于此提示的保证范围。

## 当前工作区诊断

`packages/client` 组合根持有一个诊断 controller，侧栏与 **DT → 诊断** 共享工作区、catalog 和 timeline 读取结果；模式切换不会重新创建诊断状态。面板在 native/play 两种模式均可打开，提供原因、恢复建议、可展开的技术详情、重新检查及 JSON 报告复制。侧栏只显示可关闭摘要与逐周目的警告入口。

诊断同时覆盖文件读取失败和“timeline 可读但没有可用会话”：后者在官方 `useSessions` / `useWorkspaces` mirrors 均为 `ready` 后，复用侧栏的工作区归属与归档过滤投影。空 timeline 也要检查 root session，不能由行号或读取成功推断正常；尚未就绪的 mirror 不证明会话缺失。官方状态变化会重新计算，已解决的问题自动消失；新一轮读取使较早的异步结果失效。

这是当前问题投影，不是历史日志，也不新增 HTTP API。`sessionStorage` 只保存有界的摘要关闭身份（工作区、周目、错误码），不保存错误正文、资源或对话内容。关闭摘要不删除问题或警告按钮；同一问题在刷新和模式切换后仍保持关闭，确认解决后再出现才重新提醒。复制报告包含工作区路径、周目/会话标识及错误详情，分享前应检查这些信息。

## 前端产品范围

3.0.4 继续使用 DSH Web/Desktop 的公开扩展承载第一方 RP 前端，不另做独立 Web UI。导航、输入框和会话生命周期仍由 DSH 管理；Tavern 维护资源面板、RP 展示和诊断。第三方仍可通过现有可组合 API 开发自己的客户端。此决策不改变权威历史、原生会话或卸载行为，无需数据迁移。

公式渲染位于 `packages/client/src/play/math.js`，通过 Marked 公开 tokenizer/renderer 扩展接入共用富文本路径。KaTeX 只生成 MathML，随后与 HTML 一并净化；公式布局样式限定在 Tavern 内容与既有样式隔离边界内。RP、开场白和静态 HTML 导出复用此路径，不增加 Host seam、网络服务、全局渲染脚本、设置存储或消息副本。语法和安全界限见[显示合同](CONVERSATION_PRESENTATION.md#数学公式)。

## 决策结论

Tavern 是包含内部资源层的独立 DSH 插件，单向依赖另行启用的 `dsh-prompt-assembler` Host bundle。Memory Manager 为可选扩展。assembler 中的 adapter 读取来源公开服务，不读取来源私有文件。

```text
SillyTavern JSON
       │
       ▼
packages/tavern-format
解析、校验、归一化、未知字段保留、ST macro
       │
       ▼
packages/preset  packages/character  packages/user  packages/world-book-library
预设用例          角色卡资源/UI        用户资源/UI    独立世界书资源/API/UI
          \              |              |              /
           \             |              |       packages/world-book
            \            |              |       世界书纯格式、匹配与投影
             \           |              |             /
       │
       ▼
packages/play
chrome / 扮演工作区 files / timeline 校验 / focus 派生（纯逻辑+HTTP）
       │
       ▼
packages/tavern-loader ◄── DSH session/event（PendingInputProjection）
资源编译、session/request 策略、Host hooks、v1/v2/v3 HTTP；装配委托独立 assembler
        │
        ├── packages/session-template（由 loader 组合）
        │   干净会话配置投影、原子存储/API（不含历史）
        │
        ├── packages/tavern-trace
        │   审计 metadata + 官方历史引用、有界存储/API、conversation.view
        │
        ▼
DSH system prompt + agent request
```

依赖只能向下：`tavern-loader → play/preset/character/user/world-book-library/world-book/tavern-trace → tavern-format`。格式层和 `world-book` 纯库不能导入 DSH、文件系统或 UI；preset、character、user、world-book-library 和 `play` 用例层不能注册 `systemPrompt`、`agent/request` 等 Host seam；只有 loader 是根 `main` 入口并允许依赖 DSH 运行时。`tavern-trace` 接受 loader 传入的普通 snapshot/session event 数据，但不导入 DSH、不 append Session；它只拥有最小化审计格式、有界插件存储、只读 API 和浏览器 view。浏览器侧由 `packages/client` 组合各用例 UI，它不是 Host loader。

loader 在任何 Store 构造前解析统一 `storageDir`。默认 bundle 通过 DSH 的 `dshHomePath()` 把它设为 `<DSH_HOME>/pmp-dsh-tavern/`，不直接占用由 `dsh-storage-json` 管理的 `<DSH_HOME>/storages/`，也不把用户内容留在可被 pnpm 替换的 `node_modules` 内。显式 `storageDir` 仍具有最高优先级。旧版包内 `data/` 只在目标为空时通过同父目录临时副本迁移并原子发布；源副本保留，非空目标不覆盖。该目录保存 Tavern 资源、设置和绑定；DSH durable session 与所选 RP workspace 继续由各自 Host 合同拥有。

## 各层职责

| 层 | 回答的问题 | 当前内容 | 明确不负责 |
| --- | --- | --- | --- |
| `tavern-format` | “这个 ST 文件表达了什么？” | preset 识别、顺序和启用状态归一化、原字段保留、编辑模型、macro 解释 | session 选择、DSH system 段、模型调用参数、HTTP、磁盘 |
| `preset` | “用户如何管理预设？” | 原子文件存储、导入/创建/修改/删除/选择、API、侧边栏源代码 | 决定提示词如何进入 agent |
| `character` | “用户如何管理角色资源？” | JSON/PNG 导入、创建/编辑、当前文档 JSON/PNG 导出、per-session binding、API、UI、loader/world-book 资源快照 | prompt 放置、assistant 历史、世界书激活 |
| `user` | “用户如何管理自己的 Tavern 身份描述？” | 身份与可选头像文档、CRUD 持久化、API、UI、loader adapter | DSH Agent 身份、prompt 放置、Host seam |
| `world-book` | “哪些 lore entries 候选应被激活？” | ST/角色内嵌格式、归一化、纯匹配/排序/预算与 loader 投影 | session 选择、DSH 注入、角色卡存储 |
| `world-book-library` | “用户如何管理独立世界书资源？” | 原子 JSON 存储、CRUD/导出 API、编辑 UI、供 loader 读取的 document | session 选择所有权、matcher 复制、Host seam、角色卡内嵌书修改 |
| `session-template` | “怎样复用 Tavern 配置但创建干净 DSH 会话？” | 有界模板投影/原子存储/API、缺失资源诊断和客户端事务顺序 | DSH 历史、Trace、Session 构造、最终 prompt |
| `play` | “扮演表面的元状态存在哪、文件怎么守在根内？” | 全局 chrome、扮演工作区路径监狱、timeline/catalog 校验、`deriveFocus`、session HTTP；Host RPC 由 loader 适配 | DSH 事件改写、RP 锁、内置魔丸 DOM、`archiveSession` |
| `tavern-loader` | “当前资源怎样影响这次 DSH 请求？” | 装配选中预设、映射支持的 call config、append/replace 策略、Host/API 挂载、独占 pending-input 投影、RP 会话叠加 | 重新解释 ST 原始字段、实现具体 UI |
| `tavern-trace` | “这次 loader 为什么得到这个组合？” | turn/step 对齐、资源摘要、世界书决策、段落/来源 metadata、官方历史引用、按需验证读取、有界存储/API/并列 view | 替代 DSH 权威、持久化新的提示词/来源正文副本、append 会话事件或模型消息 |

角色卡已经在 `tavern-format` 增加 adapter/model，并在 `character` 用例层提供管理与资源入口；用户资源由独立 `user` 用例层提供严格 `{id,name,description,avatar?}` 文档；世界书格式兼容位于独立纯库 `packages/world-book`。所有资源最终由同一个 `tavern-loader` 组合。角色卡和用户模块都不读取预设排序，也不决定字段插入位置。

统一 loader 将逻辑 profile 展开为具名 `pmp-dsh-tavern:part:*` 段落，导入上下文与可选的 `rp:policy` 独立贡献，并引入 loader-owned `SessionSelectionStore`：preset、角色、用户和世界书的文档仍由各自模块管理，但“哪个 session 使用哪些资源”以及 RP 叠加由统一策略持久化。普通 fork 与 delegated subagent 都复制父选择。RP 不是 DSH agent preset。

统一 adapter、session 继承和 marker 契约见 `docs/LOADER_CONTRACT.md`；DSH 原生与插件增强消息流见 `docs/DSH_MESSAGE_FLOW.md`；世界书格式和投影细节见 `docs/world-book/DESIGN.md`。

DSH 原生“新会话”按钮当前默认继承上一个聚焦会话的 preset 等 Tavern 选择/设定；这是 Host 基线。架构和验收不得继续把原生新会话假定为空白配置。

干净会话与配置模板由 `packages/session-template` 保存纯选择投影，loader 注入真实资源库和 `SessionSelectionStore`。DSH 模式下，浏览器组合根只通过公开 `uiWorkspace.connectWorkspace()` 与 `uiWorkspace.openSession()` 创建/导航普通 blank session。魔丸模式下，同一控制面先 preview 配置并取得角色 id，再复用共享周目控制器与现有 v2 原子操作创建/复用该角色周目，最后通过 v1 apply 原子写入完整 selection；不增加“配置周目”专用后端动词。两条路径都不 fork 或伪造历史。完整事务边界见 `docs/LOADER_CONTRACT.md`。

## Loader-owned ActivationContext

DSH `0.2.1-rc.2` 的 `agent/inbox/spliced` 是公开、持久的 Session event；插入、替换、取消和 claim 都先 append 该事件并同步通知 `session/event`，随后实时 Inbox 才改变。loader 在这个边界维护唯一 `PendingInputProjection`，通过 `Session.ownEvents()` 排除 fork 继承前缀，把 durable history 与本次 claimed batch 去重后组合为临时 `ActivationContext`，供 world-book matcher 只读消费。其他当前日志读取集中使用 `session.seq` 与 `snapshotEvents()`，不再访问已删除的 `Session.events`。

这个投影属于 Host adapter，不下沉到纯模块：

- `world-book` 继续只接收显式 messages/text/options，不能读取 session 或监听 event；
- `character`、`user` 和 `world-book-library` 不复制 pending 状态，也不改变各自存储模型；
- `tavern-trace` 接收装配 snapshot，但 schema 4 落盘前删除 section/context/system message/source 正文，只保留 metadata 与官方引用；详情读取时冷查 DSH 历史，不保存完整 ActivationContext；
- Trace 引用使用官方事件视图的逻辑 seq/message/range，不是压缩日志文件字节偏移；每个详情请求执行一次 cold inspect，长会话有读取成本，不承诺随机访问或 O(1)；
- 失败原因以独立 `failureRef` 指向官方失败事件，不复制错误正文，也不扩大提示词引用的读取截点；详情核验失败引用后才返回原因。失败引用不可用不影响仍可验证的提示词段落；
- `packages/client` 不参与捕获，避免浏览器刷新或多窗口决定运行语义；
- loader 必须处理 cancel/replace/steer、多个 target、异常清理与下一 step 去重。

该投影让当前输入在首次 system assembly 时参与激活判断，但不改变 DSH durable history、真实 role message 顺序、工具权限、`agent/request` 或 `request/header` 的所有权。

## 控制面扩展

- 用户与独立世界书的关联已由统一 loader policy 的独立原子文件持有；`UserModel` 包含 `id/name/description` 与可选 `avatar`，`world-book-library` 文档也不反向保存用户 id。用户 UI 可以编辑关系，但最终以 session 显式来源优先、用户来源随后稳定去重，且只有 loader 的共享 adapter 运行 matcher。
- UI 缩放、语言与绑卡跟随 RP 已由 `packages/client` 的单一设置入口、共享 locale contract 和逐语言语义 catalog 实现。业务组件只引用语义 key，动态资源值通过显式 raw boundary 插值；运行时不再扫描或替换中文原文。loader 根 API 只持久化有界的全局显示文档（含 `rpFollowCharacter`），资源 JSON、profile 装配和 session selection 不读取显示语言/缩放。可选的 `rp:policy` 正文是另一份有界文件 `rp-policy.json`。
- Conversation 显示偏好不混入上述外层 UI 文档。loader 通过独立的 `conversation-settings.json` 和 v1 `/conversation-settings` 保存 `textScale/actionScale`；客户端用独立事件只通知魔丸 chat 与空周目 opening dock。正文缩放通过局部 CSS custom property 进入 RP 文本，按钮缩放只进入 durable QA 动作行，因此不会级联改变 DSH native、输入栏、Tavern 面板、提示词或导出内容。
- 这两项都必须复用现有单插件 API、安全边界、刷新事件和原子持久化模式，不能通过新增第二个可安装插件实现。

## 原生优先的前端适配策略

前端长期遵循“最小改动、最大兼容”：先在当前 DSH 版本的包 README、根导出类型和公开 slot / service 中寻找等价能力，只有 DSH 没有表达 Tavern 语义的公开接口时才自建。复用的判定标准不是“能从 DSH 源码里 import 到”，而是同时满足：能力在公开文档或根导出中出现、由插件清单显式注入或声明依赖、没有读取 `/src/*` 或 bundle 内部符号、卸载本插件后 Host 数据和原生界面仍可独立工作。

### 当前已经复用的 DSH 机制

| Tavern 能力 | 复用的 DSH 公开机制 | 自定义部分及边界 |
| --- | --- | --- |
| DT 悬浮入口 | `shell.overlay` additive slot、Cordis effect 生命周期 | 球体、菜单内容和全局 chrome 状态是产品 UI；不向 `document.body` 另建失控根节点 |
| 魔丸侧边栏 | `sidebar.workspaces` slot；owner 注入的 `useSessions` / `useWorkspaces`；`ctx.uiWorkspace.openSession()` | 只重组为角色卡 / 周目投影，不改写、不归档、不隐藏 Host session 数据 |
| 工作区诊断 | `useSessions` / `useWorkspaces` 公开 mirrors；现有 v1/v2 资源及受管文件读取 | 与侧栏共享当前问题，mirrors 就绪后判断会话可用性；不复制 Host 日志、不提供新的诊断 API |
| DSH 外层新会话 | DSH `0.2.1-rc.2` sidebar shell 自有；无供 Tavern 接管点击的公开 slot/service | Tavern 不用哈希 class、DOM capture 或源码替换接管；魔丸保留原生按钮并在文档中标为不推荐，普通区 `+` 只引导返回 native |
| 普通会话提示 | `conversation.input.dock` 独立整行 slot、继承的 `--dsh-composer-card-max-width` | 仅显示 Tavern 的 RP 工作区分类结果；提示按 Host composer 宽度居中，不接管原生 composer、不复制固定像素或读取哈希 class |
| 魔丸对话页 | `conversation.view` slot；`useChat` 的 `legacy.nodes/partial` 与 `timeline`；`useSession` 的生命周期和错误字段 | 周目跨 session 聚合是 Tavern 投影；不伪造 DSH 消息，不读取私有 runtime |
| 魔丸默认视图 | `slots.entries("conversation.session")` 暴露的 Conversation store 句柄、session 级 `conversation.input.dock` 及其 `actions.setView()` | 按 session/周目 binding 复用同一 store 并持续处理其他 scope；只为未选定视图设置默认，不注册第二个 `chat`，保留手动选择 |
| 实时发送和流式显示 | DSH `useChat` 的公开 `legacy` 消息投影 | `/v2/messages` 只做持久消息范围对账；Session 不再提供 `nodes/partial`，Chat 顶层 `nodes` 不是数组 |
| 空白周目开场 | 公开 `conversationPhase(session, conversation)` 与 `useConversation` | 不读取已删除的 Session `composerPhase`，不开第二套阶段状态机 |
| 对话滚动 | Conversation 的 `[data-conversation-scroll]` scrollport、sticky composer 几何和注入的 `chatScroll.save(null)` | 只选择何时调用原生“到底部”语义；不计算固定 composer 高度，不维护第二个滚动容器 |
| 干净新会话 / 配置模板 | DSH 模式复用 `uiWorkspace.connectWorkspace()`；魔丸模式复用周目 v2 session-controller 组合；两者都用 `uiWorkspace.openSession()` 导航 | Tavern 只在目标 session 上原子复制 selection；魔丸额外把配置角色作为周目归属并回读验证，不构造消息、不 fork 历史 |
| 周目 session 操作 | Host `sessions.create/rename/fork/prompt/history`、`workspace.insertSessionBefore`；Host 侧 `Session.deriveMessages()` | v2 把这些原子操作组成第三方前端可用的周目事务，同时保持 DSH session 为权威历史 |
| RP 安全模式 | 官方 `sandbox/mode` Session event、`tools.guard`、Session/agent 生命周期 hook | Tavern 只保存 RP 是否启用及跟随来源；不发明第二种沙箱状态 |
| prompt 与审计 | `systemPrompt.section`、`system-prompt/assemble`、`agent/request`、`llm/stream`、官方 Session events / inspect | loader 输出具名段落；Trace 保存有界来源 metadata 与官方历史引用，详情冷读并验证正文 |
| Tavern Trace | additive `conversation.view` | Trace 是 loader snapshot 的解释层，不取代原生 Chat / Trajectory |
| 视觉适配 | DSH `--dsw-*` theme / semantic tokens | 角色卡、周目和资源编辑器的布局仍由 Tavern 拥有 |

### 当前 Tavern 前端边界

以下行为属于当前实现及其公开依赖边界：

- 用户与 assistant 正文不直接迁移到 `MessageText` / `MarkdownText`。未覆盖消息从 DSH 权威 content 按“宏替换 → ST 显示正则（全局 → 预设 → 角色卡，各来源保持数组顺序）→ Marked 18.0.10 → DOMPurify”执行浏览器显示管线；因此自定义/XML 包裹标签不会阻断其内部 Markdown，嵌套标签和 ST 的宽松引用代码围栏语义也能保留。规则页只允许同来源拖拽，保存后全局写工作区文档，资源规则写回原生 `regex_scripts` 数组。DSH `MarkdownText` 会省略 raw HTML，不能作为 ST HTML 兼容渲染器；以后升级 Marked、清理策略或复用 DSH 低层能力，必须分别对照 ST 输出与恶意 HTML 用例，证明不会改变 Tavern 显示语义或越过 sanitizer 后再单独验收。
- details 使用独立块解析保留内部 Markdown，原始 HTML 布局不插入 Markdown 换行。闭合的无语言/html 围栏中，完整 HTML 文档按静态模板渲染，普通代码片段保留源码。含 style 的净化结果由 `rich-text-styles.js` 放入 Shadow DOM，完整文档逐个隔离并适配根选择器，外层使用布局/绘制 containment；React ref 在插入/更新后挂载，静态导出使用相同的声明式根。静态模板不执行 JS；可选交互卡片使用独立限额解释器、禁脚本 iframe 与有界 DOM 桥，见[显示架构](CONVERSATION_PRESENTATION.md)。浏览器验证：`node scripts/verify-rich-text-browser.mjs`（Chrome/Chromium，可设置 `CHROME_PATH`）。
- 魔丸不渲染 reasoning 或 runtime context，也不提供展开入口；用户需要运行细节时回到 DSH 原生“对话”。操作按钮只能依赖公开图标与 `Tooltip` 等接口；DSH bundle 内未公开的 `ReasoningRow`、`MessageIconActions` 不属于可依赖接口。
- DSH 的模型消息 `role` 与界面来源不是同一维度：公开 ConversationNode 已把运行时注入表示为 `kind: "context"`，但持久 history 投影仍可能给它 `role: "user"`。v2 因此在不改变 `role` 的前提下增加 additive `origin.kind`，并保留 `producer` / `form` / `summary` 等可选来源元数据。RP 前端必须按 `origin` 投影气泡、隐藏/单独呈现上下文和计算动作能力，不能靠文本、位置或“是否最后一段输出”猜测。
- timeline 以 `parentVariantId` 与活动 `head` 表示树状分支；显示、focus 和新 QA 对账只沿 head 的祖先路径工作。head 的 session 可以是刚 branch、尚无新 QA 的 continuation anchor，因此侧栏归类也必须把 head session 视为周目成员。旧平面 timeline 继续可读，下一次对账进入树结构。
- 内置动作行归属于 durable QA，而不是某一段可见 assistant 正文。真实 user/steering 输出直接重试自身；context 触发的父输出向前寻找最近真实用户 turn 并重跑整轮，控制器绝不把 `origin=context` 当用户提示重发。分支新周目与同周目回退复用同一 DSH branch/继承区间校验，区别仅是创建 catalog 副本还是移动原 timeline head。屏蔽能力及其 timeline 字段未进入 v2 合同；显示正则只决定各段正文是否渲染，一次 QA 无论包含多少段 assistant 输出、甚至全部被清空，都只在 QA 末尾保留一组动作；timeline 引用和 provenance 始终保留。
- DSH message surface replacement 可反复遮蔽当前节点，原始 append-only 事件仍可读取，但当前公开语义只有“连续区间 → 一个 message”，没有 `unreplace`、原子多 message 恢复或 per-request history projection。它适合原生 compaction/checkpoint，不适合承载 RP 分支树。DT 因此用多个公开 branch session 保存各条 continuation，让 DSH 历史、role/tool 配对、原生对话视图和卸载回退保持有效；timeline 只把这些 session 指针组合成活动周目路径。完整取舍见 `DSH_MESSAGE_FLOW.md` §1.1。
- `displayOverride` 由 conversation 内的多行编辑器修改；保存、取消/Esc 均留在当前回复位置，不使用浏览器 `window.prompt`。覆盖值定义为最终显示文本，跳过后续宏与显示正则，仍进入 Marked/DOMPurify。空字符串也是有效覆盖并保留恢复按钮；恢复为 `null` 后重新从 DSH 原文执行当前显示管线。保存继续通过既有 node controller 与 timeline CAS 写显示元数据，不改 DSH 原文或模型上下文。
- 周目 IO 只位于侧边栏 `PlayIoMenu`，不占用或改写原生 composer 左侧动作。
- 消息滚动复用 DSH scrollport 的 `scrollTop = scrollHeight` 语义，不维护本地锚点、固定遮挡量或 composer 高度补偿。

引入 primitives 时必须把 `@deepseek-ai/dsh-client-ui-primitives` 作为明确、同版本族的 client 依赖/注入项；不得借用 DSH 安装目录中的传递依赖。迁移必须逐项验收，不能为了统一外观一次替换所有控件。

### 必须保留的 Tavern 自定义层

DSH 当前没有角色卡、周目、greeting、跨 session adopted variant、ST 显示正则或 Tavern selection 的原生数据模型。因此 `catalog.json` / `timeline.json`、角色卡→周目侧栏投影、跨 session 回复切换、开场展示与首轮提示词参考、正则资源管理与 v2 周目协议继续由 Tavern 拥有；它们通过事件范围指向 DSH 权威消息，不复制正文。RP 工作区内子目录还必须经过 Tavern 路径监狱：DSH 的 native/browse directory flow 是选择或注册 Workspace 的 UI seam，不提供“在已绑定根内让第三方 v2 前端安全创建任意周目子目录”的统一 Host 能力。

周目名称和 DSH session 名称刻意分离：Tavern 在每张角色卡内保存单调序号，并按当前 UI 语言显示 `{number}周目` / `Playthrough {number}`；用户主动重命名后改为原文显示，不再随语言变化。DSH 原始 session 继续由 Host 按“角色卡名 + 时间”命名，便于退出魔丸或卸载插件后辨认权威数据。旧 catalog 没有序号时按该角色卡既有顺序补入计算；带序号的旧生成标题可在显示时识别，但不会仅为兼容而重写旧条目。

新建动作只检查该角色卡最高序号周目：timeline 已有 QA、导入上下文已有 QA、DSH 权威消息已有 user/assistant，或存在未完成回合时都不得复用；纯 greeting 不算 durable history。四者均为空才直接打开原 root session，不产生目录、session 或 catalog 写入。旧周目引用的 Session 缺失时，保留该周目及缺失提示，允许另建新周目；不能把缺失周目当成空周目覆盖或复用。其他读取错误仍传播，不猜测为空。

角色 selection 变更增加前置 membership guard：v1 只报告“需要脱离”及结构化冲突，不在未确认时写 selection；确认后的 v2 detach 在服务端按 `parentVariantId`（旧平面 timeline 按前一 adopted variant）计算目标及后代，以 timeline/catalog 各自 revision 做 CAS。它不删除 DSH session、不重挂兄弟分支；root 脱离后 catalog 保留空周目，下一次同角色创建为其连接新的 blank root session。这个显式生命周期动词避免第三方前端各自实现树裁剪算法。

导入记录仍是不可变的 `import-context.json`，不伪造 DSH user/assistant QA，也不复制进 timeline；实际请求中的导入 system 提示词由 DSH 官方历史保存。空 session 通过 `/sessions/:id/import-context` GET/PUT/DELETE 管理 loader 的权威绑定；换绑写新文件后替换 pending 引用，解绑只清除引用，保留工作区文件供恢复/审计。存在 DSH 对话、开放 turn 或绑定已 claimed 后，后端锁定修改。公开导出按“导入 greeting/QA → 后续 timeline 指针解析出的 DSH 原文”组合。静态 HTML 输出当前可见开场白与 RP 渲染；SillyTavern JSONL 输出开场白、当前活动路径和每组 QA 的 `swipes` / `swipe_id`，其中开场白的 `{{user}}` / `{{char}}` 在导出时固化为当前显示名。导入文件保持不可变并继续参与 hash 校验；loader 只在 prompt 投影阶段使用当前 user/character profile snapshot 展开 greeting 与 QA 中的 Tavern 宏，然后做 XML 转义，避免任何残留 ST 占位符被 DSH 误解释为 prompt variable。ST JSONL 无法表达完整周目树拓扑，本插件重新导入 ST 记录时也只绑定每行 `mes` 所代表的已选线性历史。当前公开面不定义 portable bundle；完整恢复需同时备份 RP 工作区、Tavern 持久目录及对应 DSH 会话日志与继承依赖。前端还需同步 catalog/timeline 的显示引用并回读校验；当前 v2 没有跨 import binding、文件和 catalog/timeline 的统一事务，因此校验只能暴露半完成状态，不能声称原子提交。
当前周目生命周期是这些原子能力的前端组合：角色卡侧边栏创建或复用最近的空 root session，写入角色/周目目录、空 timeline 和 catalog 元数据，再重新读取校验；`x周目` 重命名只改 catalog。空会话的 greeting 与外部记录预览挂在 session 级 `conversation.input.dock`，不注册第二个 conversation view。外部记录绑定到现有空 root session 的 import-context 文件，opening footer 提供绑定、换绑、解绑和最近三轮 QA 预览；真实消息、开放 turn 或 claimed 绑定由 Host API 锁定。

当前实现边界如下：

- greeting、导入 QA 和 timeline 不伪造 DSH user/assistant 历史消息；实际装配的 system 正文仍由 DSH 保存。首次实际 assembly 从同一 profile snapshot 读取公开 `claimEventSeqs`，成功后才把 pending binding 持久转为 `claimed`，并由 loader 注入转义且标为 `untrusted` 的只读上下文。无 claim 的 view/assembly 不注入或消费；同一 claimed identity 可在 terminal 前重放，terminal 后新 claim 不再注入。
- history 先以 `inspect` 固定截点，再一直分页读取至 Host `hasMore: false`；空页、非法 oldest `seq` 或 cursor 重复/不前进返回 502 `PLAY_HISTORY_CURSOR_STALLED`，不摘要或切片。
- catalog/timeline GET 在目标 guard 内读后校验并返回精确 UTF-8 字节 SHA-256 `revision`；PUT 在同一 guard 内比较显式 `expectedRevision`、校验、临时写并 rename。缺字段、格式错误和冲突使用稳定的 400/409 错误，冲突不改文件。
- 内置 live client 管理 revision 回读/缓存、`null` create-only 和有限 CAS 重放。重放只重新执行纯文档 mutator；外部 session/branch/user-message/目录等副作用不重复。仅有 get/put 的自定义 client 只获一次兼容 fallback，不获并发重放保证。
- 稳定 focus 由 playthrough id 派生；显式 path 路由只作为兼容入口。目标锁执行逐段路径检查、realpath 复核、排他临时文件与 rename 前复验；纯 Node 不承诺跨进程或内核级 no-follow 事务。
- Tavern branch/swipe 复制不含正文的 import lineage；同一终态前的 provider retry 可复用 claim，终态后的新 claim 不注入。第三方原生 fork 不在 Tavern 的拦截范围。
- 上述能力不构成跨文件周目事务。受监控变更由统一 API 边界记录关联 ID 与终态，少量检查点记录已确认的创建／写入结果；查询日志不产生日志。日志不能驱动自动恢复，需结合状态回读和错误码。完整覆盖、事件版本与容量见 [操作日志合同](OPERATION_LOGS.md)。

插件自有资源变化继续使用有界的 Tavern refresh event；Session / Workspace / live Chat 变化必须订阅 DSH store，不能用该自定义事件替代 Host 状态管理。

### DSH 升级审查

每次升级 DSH 版本先做只读差异审计：核对插件清单的 inject、公开包根导出、slot owner props、store 字段、Host RPC 和 README 合同；然后运行 native/play 双模式及卸载回退验收。若公开 seam 消失，优先让对应增强失败关闭并保留原生表面，再讨论协议调整；禁止临时改为 DOM 查询、内部 bundle 符号或私有 runtime。新增前端功能的设计记录必须明确写出“复用的原生机制 / 自定义原因 / 官方升级观察点”。

DSH `0.2.1-rc.2` 区分三个 owner：Session 管生命周期，Chat 管实时消息，Conversation 管视图和交互阶段。主视图当前 Session 从 `useSessions` 中 `retainedBy.mainView > 0` 的条目选择，导航使用公开 `uiWorkspace.openSession()`，不依赖已移除的 `sessions.current/open` 合同；mirror 继续提供生命周期与工作区归属。

RP/Trace slot 注册是全局的，复用的 `conversation.session` store 和注入 binding 则逐 Session 作用域解析。RP default adapter 保持挂载，按 session 身份/工作区/周目 binding 记录默认选择，只修改未选择的 view。其他保留 Session 若无 RP binding，会从 RP 返回原生 Chat；明确选择的 Chat/Trace 不被覆盖。缺失公开 store 句柄时不安装增强。暂时的 binding 读取失败保留已确认的匹配关系，不误判为无绑定。

RP snapshot cache 按 client 有界保存，key 包含周目路径与 Session ID；swipe 过渡可显式借用来源 Session 的快照，直到目标就绪。其他保留 Session 不能仅因属于同一周目而共用缓存。浏览器 `conversationPhase` 仍由 `entry.js` 注入。回归覆盖首发默认 RP、空白开场、partial、Trace、多 retained owner、scope 切换与模式退出释放。

Tavern 语言与 DSH 语言独立。RP、侧栏和开场 dock 订阅完整 UI 设置，而不是只订阅缩放值。语言变化还会刷新 Tavern 自己的 RP 页签注册项，因为 DSH 将 label 缓存在视图列表中；Conversation store 与已完成的默认视图选择保持不变。生成周目名随 locale 显示，用户自定标题及角色正文不翻译；不以 locale 事件替代 DSH 的 Session/Chat 订阅。

## 安装单位与纯库

安装单位是 Tavern 与必需的独立 assembler；Manager 可选。Tavern 内部 `tavern-format` 与 `world-book` 仍是根包内的纯库，公开 exports 是可组合程序接口，不是可单独启用的 Host bundle。loader 把来源拥有的只读编译接到共享 assembler；兼容包入口与 HTTP 路径保留。新接入见[完整接口索引](API_SURFACES.md)。

## 开发验证

测试环境、命令与运行时检查见 [开发验证指南](TESTING.md)。按变更范围完成以下检查：

1. 验证 ST 格式识别、未知字段保留、归一化、资源选择、提示词顺序与宏行为。
2. 运行相关测试；完整版本验证使用 `npm run check` 和 `npm run verify:2.0`，并为官方 codec / AgentLoop 测试配置目标 DSH 依赖根。条件跳过不能当作通过。
3. 在隔离 `DSH_HOME` 的目标 Host 上检查绑定、新会话、RP 生命周期，以及 `llm/stream`、官方持久消息和 Trace 引用的对应关系；验证重启后详情仍可冷读。
4. 核对安装包和已安装文件，确认 bundle、公开文档和图片齐全，且不包含测试数据、私有计划、真实路径、密钥或导入 fixture。
5. 同步中英文技术说明，将执行结果保存在本地验收记录中，并完成相应验收。分支推送、合并、tag 和发布遵循维护者分别给出的授权。

## 两组长期验收

格式兼容验收关注：输入识别、诊断、prompt order、启用状态、未知字段保留、稳定归一化，以及外部版权 fixture 只读且不进入仓库。

运行加载验收关注：当前选择、session 隔离、append/replace、资源组合顺序、call config、最终 LLM messages/config/tools、官方历史引用、API 审计与安装入口。以后更换加载策略时，不应使格式解析测试一起失效。

当前架构测试会检查关键依赖方向；它不能替代代码评审，但会阻止最明显的 DSH Host 逻辑回流到格式层。

### Tavern chrome revision 与事件边界

全局蓝/红前端状态由 `packages/play` 自有 `ChromeStore` 持有，`chrome.json` 保存 `mode` 与不透明 `revision`。`GET/PUT /v2/chrome` 保留旧的 `ok/mode` 字段并附加 `revision`；只有 atomic write 成功且 mode 实际变化时才发布一次变更。`GET /v2/chrome/events` 是同一 API 前缀下的 Tavern 自有 SSE：首次连接发送当前快照，随后发送 `chrome/change`，只暴露 `mode/revision`，并在连接关闭时释放订阅。它不改 DSH Host 的 store、transport 或 view；外部直接改文件和其他进程写入不在事件合同内，客户端必须以 GET/focus 刷新作为降级校验。

### 浏览器模式服务与消费者边界

client组合根创建 transport-independent mode core，以 `ctx.provide('pmpDshTavernChrome', face)` 注册在稳定插件fiber；SSE/focus/轮询只通过内部adapter提交服务端快照。TavernShell、悬浮球controller和 `playSlots.setMode()` 都是该服务的普通消费者，不再各自维护GET、focus或BroadcastChannel状态机。

该服务的 `when(mode, setup)` 只表达模式生命周期，不授予surface所有权。多个插件可以同时订阅并注册各自的DSH公开slot；同一slot的占用冲突仍由对应公开slot合同处理。provider卸载时先停止transport、清理effect，再由Cordis撤销服务并驱动required consumer卸载。native模式仍不修改DSH原生表面。

## 无会话开场生命周期

`PlaythroughDrafts` 拥有未发送周目的配置、装配快照和初始 MVU，保存于插件存储；catalog 与空 timeline 仍在 RP 工作区。草稿 ID 从不传给 DSH Session API。首次发送的准备与消息提交保持为两个可组合原语，唯一会话/请求身份先持久化，准备中的真实空会话由公开 Workspace 归档接口隔离。真实 `turn/start` 和首条输入身份共同证明受理后，catalog 才获得 `rootSessionId`；公开 `agent/pre-step` 中间件等待解除临时归档后再继续原生 gate。取消与消息受理串行协调，不清除已受理历史。现有原生周目 ID 保持不变，不需要修改 DSH 核心。

```mermaid
sequenceDiagram
  participant UI as Tavern UI
  participant Draft as PlaythroughDrafts
  participant DSH as Public DSH APIs
  UI->>Draft: 保存周目、配置、初始变量
  Note over Draft: 无 DSH 会话
  UI->>Draft: 准备唯一首条输入
  Draft->>DSH: 创建并临时归档真实会话
  Draft->>Draft: 转移配置与初始变量
  Draft-->>UI: sessionId + requestId
  UI->>DSH: 既有消息接口
  DSH-->>Draft: 真实 turn/start
  Draft->>Draft: 关联 catalog
  Draft->>DSH: 解除临时归档
  DSH-->>UI: 原生对话与流式回复
```
