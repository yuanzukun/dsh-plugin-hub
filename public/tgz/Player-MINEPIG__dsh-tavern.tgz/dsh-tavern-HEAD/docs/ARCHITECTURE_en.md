# dsh-tavern package architecture

[中文](ARCHITECTURE.md)

The required independent [assembler plugin](ASSEMBLER_INTEGRATION_en.md) owns registry, strategy storage and request assembly. Standard strategies use public DSH interfaces to order official system sections and contribute user context/pre-step messages. Advanced strategies enable complete request placement only after explicitly installing `dsh-prompt-assembler-core` and preparing its matching core. The original loader described below remains the compatibility path for sessions without an applied layout. Both paths retain DSH authority over durable history and provider serialization.

For DSH breaking-update reviews, see the [native dependency diagram and coupling matrix](assets/dsh-dependencies/README_en.md), with interactive HTML, repository-relative source links, and upgrade check entry points.

The current contract targets this repository's source (version in [package.json](../package.json)) and DSH `0.2.1-rc.2`.
The install identity is `pmp-dsh-tavern`. HTTP mounts at `/pmp-dsh-tavern/api`;
resources use `/v1`, the play-surface contract uses `/v2`, and assembly audit uses `/v3`.
This page records the current architecture and release-review gates.

[Interactive Tavern architecture](assets/architecture/tavern.en.html) · [Three-plugin architecture](assets/architecture/ecosystem.en.html). Editable Archify JSON is stored alongside each HTML. DSH durable history remains authoritative; Tavern stores resources, state, drafts, configuration and bounded trace references.

## Operation diagnostics and compatibility

The operation journal is bounded Tavern-owned diagnostic storage, separate from current-problem projection, Prompt Trace and DSH authoritative history. Route declarations own operation names and fixed path templates; a shared boundary records starts/terminals. Business code and the existing play-host.js adapter report a few confirmed checkpoints. The journal depends on no DSH service, event or history format and adds no DSH listener. A DSH upgrade should normally change the existing compatibility layer; changed business semantics require an event contract change. Queries and UI consume the [operation log contract](OPERATION_LOGS_en.md), not internal function stages.

## Target Host and durable-data boundary

The 3.0.4 contract targets DSH 0.2.1-rc.2, Cordis 4.0.5, and `dsh-util-crypto` 0.2.1-rc.2. Older Host runtimes are unsupported. The serial `agent/created` listener initializes selection, public pending-input projection, and RP before first use; initialization failure propagates.

DSH V4 owns system/user/assistant/tool history and producer sources, including `runtime-context` snapshots and native tool-role results. Preparation order is assembly → pre-step → request/config preparation → accepted message commits → request header and frozen messages → stream. Trace captures official body/error references and effective parameters; it is not another history store. The [one-way coordinate upgrade](DSH_0.1.7_MIGRATION_en.md) follows verified official migration stages, retains all pre-upgrade plugin backups, and never rewrites DSH logs. Pre-V3 header-body Trace references explicitly refuse conversion; no rollback tool is provided.

## Playthrough archive

Tavern records archive state in each catalog row's `ext.pmpDshTavern.archivedAt`, updated through the existing file revision/CAS path. It preserves playthrough/session relationships and does not move files, clear selections, or call DSH `archiveSession`. The sidebar projects archived runs into a collapsed archive box and retains their membership so sessions do not become loose entries; other active playthroughs can still show shared sessions. Restore removes only the marker. Timeline reads still establish membership; archiving does not promise smaller disk usage or a smaller full catalog. Older clients ignore archive visibility and older catalogs need no migration.

## RP error notice

The presentation layer reads the latest turn's `turn/end.reason.kind === 'error'` through the public DSH `0.2.1-rc.2` `useChat` timeline and combines it with `useSession`'s `promptError`, `lastAgentError`, and `openError`. A Tavern-localized notice includes the public error code/message (including session write-lock errors), with further diagnostics in native Chat; no provider-message matching or duplicate error history is introduced. New submissions and active generation hide the previous terminal notice; a later open, successful or cancelled turn supersedes old failures. Current Session errors remain visible even while busy. Browser crashes and connection failures that never reach these public outlets are outside this notice's guarantees.

## Current workspace diagnostics

The `packages/client` composition root owns one diagnostics controller. The sidebar and **DT → Diagnostics** share workspace, catalog and timeline reads; switching modes does not recreate diagnostics state. The panel works in native and play modes, with causes, recovery suggestions, expandable technical details, recheck and JSON report copying. The sidebar shows only a dismissible summary and warning buttons on affected playthroughs.

Diagnostics cover both failed file reads and readable timelines without an available Session. The latter reuse the sidebar's workspace-membership and archive projection after both official `useSessions` / `useWorkspaces` mirrors reach `ready`. An empty timeline still requires a usable root Session; neither row order nor a successful read proves availability. A mirror that is still loading does not prove absence. Official state changes recompute issues, resolved issues disappear, and a newer read invalidates older asynchronous results.

This is a current-problem projection, not a history log or a new HTTP API. Bounded `sessionStorage` entries hold only dismissed-summary identities (workspace, playthrough and error code), not error bodies, resources or conversations. Dismissal keeps issues and warning buttons available across refreshes and mode switches; a confirmed resolution followed by recurrence alerts again. Copied reports contain workspace paths, playthrough/Session identifiers and error details, which should be reviewed before sharing.

## Frontend product scope

Version 3.0.4 continues to host the first-party RP frontend through public DSH Web/Desktop extensions; the project will not build an additional standalone Web UI. DSH owns navigation, composition input and session lifecycle. Tavern owns resource panels, RP presentation and diagnostics. Third parties can still build clients with the existing composable APIs. This decision changes neither authoritative history, native sessions nor uninstall behavior and requires no data migration.

Math rendering lives in `packages/client/src/play/math.js` and uses Marked's public tokenizer/renderer extensions in the shared rich-text path. KaTeX emits only MathML, which is sanitized alongside HTML; formula layout styles stay within Tavern content and existing style-isolation boundaries. RP, greetings and static HTML exports reuse this path without adding a Host seam, network service, global renderer script, settings store or message copy. See the [presentation contract](CONVERSATION_PRESENTATION_en.md#math) for syntax and safety boundaries.

## Decisions

Tavern is an installable DSH plugin with internal resource layers and a one-way dependency on an independently enabled `dsh-prompt-assembler` Host bundle. Memory Manager is optional. Assembler adapters call public source services, never source-private files.

```text
SillyTavern JSON
       │
       ▼
packages/tavern-format
parse, validate, normalize, keep unknown fields, ST macros
       │
       ▼
packages/preset  packages/character  packages/user  packages/world-book-library
preset use case   character resource/UI  user resource/UI  standalone world-book resource/API/UI
          \              |              |              /
           \             |              |       packages/world-book
            \            |              |       pure world-book format, match, projection
             \           |              |             /
       │
       ▼
packages/play
chrome / play-workspace files / timeline validation / focus derivation (pure logic + HTTP)
       │
       ▼
packages/tavern-loader ◄── DSH session/event (PendingInputProjection)
Resource compilation, session/request policy, Host hooks and v1/v2/v3 HTTP; assembly delegates to the independent assembler
        │
        ├── packages/session-template (composed by the loader)
        │   clean-session configuration projection, atomic store/API (no history)
        │
        ├── packages/tavern-trace
        │   minimal audit model, bounded plugin store/API, conversation.view
        │
        ▼
DSH system prompt + agent request
```

Dependencies only go down: `tavern-loader → play/preset/character/user/world-book-library/world-book/tavern-trace → tavern-format`. The format layer and the `world-book` pure library must not import DSH, the filesystem, or UI. The preset, character, user, world-book-library, and `play` use-case layers must not register `systemPrompt`, `agent/request`, or other Host seams. Only the loader is the root `main` entry and may depend on the DSH runtime. `tavern-trace` accepts ordinary snapshot/session-event data from the loader, but it does not import DSH or append Session events. It owns only a minimal audit format, bounded plugin storage, a read-only API, and a browser view. The browser side is composed by `packages/client` from the use-case UIs. It is not the Host loader.

Before constructing any Store, the loader resolves one shared `storageDir`. The default bundle uses DSH `dshHomePath()` to set it to `<DSH_HOME>/pmp-dsh-tavern/`; it neither occupies `<DSH_HOME>/storages/`, which is managed by `dsh-storage-json`, nor leaves user content under pnpm-replaceable `node_modules`. An explicit `storageDir` still has highest priority. Legacy package-local `data/` migrates only when the target is empty, through a sibling temporary copy and atomic publication. The source copy is retained and a populated target is never overwritten. This directory owns Tavern resources, settings, and bindings; DSH durable sessions and the selected RP workspace remain under their respective Host contracts.

## Layer responsibilities

| Layer | Question it answers | Current contents | Explicitly not responsible for |
| --- | --- | --- | --- |
| `tavern-format` | “What does this ST file express?” | Preset recognition, order/enablement normalization, original-field retention, edit model, macro interpretation | Session selection, DSH system sections, model call parameters, HTTP, disk |
| `preset` | “How does the user manage presets?” | Atomic file store, import/create/edit/delete/select, API, sidebar source | Deciding how prompts enter the agent |
| `character` | “How does the user manage character resources?” | JSON/PNG import, create/edit, current-document JSON/PNG export, per-session binding, API, UI, loader/world-book resource snapshots | Prompt placement, assistant history, world-book activation |
| `user` | “How does the user manage their Tavern identity description?” | Identity and optional avatar document, CRUD persistence, API, UI, loader adapter | DSH Agent identity, prompt placement, Host seams |
| `world-book` | “Which lore entries should be activation candidates?” | ST/embedded-card format, normalization, pure match/rank/budget and loader projection | Session selection, DSH injection, character-card storage |
| `world-book-library` | “How does the user manage standalone world-book resources?” | Atomic JSON store, CRUD/export API, editor UI, documents for the loader | Session-selection ownership, matcher copies, Host seams, editing a card's embedded book |
| `session-template` | “How do we reuse Tavern configuration but create a clean DSH session?” | Bounded template projection / atomic store / API, missing-resource diagnostics, client transaction order | DSH history, Trace, Session construction, final prompt |
| `play` | “Where does play-surface meta-state live, and how do files stay inside the root?” | Global chrome, play-workspace path jail, timeline/catalog validation, `deriveFocus`, session HTTP; Host RPC is adapted by the loader | Rewriting DSH events, RP lock, bundled Mowan DOM, `archiveSession` |
| `tavern-loader` | “How do current resources affect this DSH request?” | Assemble the selected preset, map supported call config, append/replace policy, Host/API mount, exclusive pending-input projection, RP session overlay | Reinterpreting raw ST fields, implementing concrete UI |
| `tavern-trace` | “Why did this loader run produce this combination?” | Turn/step alignment, resource summaries, lore decisions, section/source metadata, official-history references, verified on-demand reads, bounded store/API/sibling view | Replacing DSH authority, persisting new prompt/source body copies, appending session events or model messages |

Character cards already have an adapter/model in `tavern-format` and management/resource entry points in the `character` use-case layer. User resources are a separate `user` use-case layer with a strict `{id,name,description,avatar?}` document. World-book format compatibility lives in the independent pure library `packages/world-book`. All resources are finally composed by the same `tavern-loader`. Neither the character nor the user module reads preset order or decides field insertion.

The unified loader expands its profile registration into named `pmp-dsh-tavern:part:*` sections, keeps import context and optional `rp:policy` separate, and introduces loader-owned `SessionSelectionStore`. Preset, character, user, and world-book documents stay in their modules, but “which session uses which resources” and the RP overlay are persisted by one policy. Ordinary forks and delegated subagents both copy the parent selection. RP is not a DSH agent preset.

Unified adapter, session inheritance, and marker contract: `LOADER_CONTRACT_en.md`. Native DSH and plugin-enhanced message flow: `DSH_MESSAGE_FLOW_en.md`. World-book format and projection: `world-book/DESIGN_en.md`.

Native DSH **New session** currently inherits the last focused session's preset and other Tavern selection/settings by default. That is Host baseline. Architecture and acceptance must not keep treating a native new session as a blank configuration.

Clean sessions and configuration templates are stored by `packages/session-template` as a pure selection projection. The loader injects the real resource libraries and `SessionSelectionStore`. In DSH mode, the browser composition root creates/navigates an ordinary blank session only through public `uiWorkspace.connectWorkspace()` and `uiWorkspace.openSession()`. In Mowan, the same control plane first previews the configuration and obtains the character id, then reuses the shared playthrough controller and existing v2 atomic operations to create or reuse that character's playthrough, and finally writes the complete selection atomically through v1 apply. There is no dedicated “configure playthrough” backend verb. Neither path forks or forges history. Full transaction boundary: `LOADER_CONTRACT_en.md`.

## Loader-owned ActivationContext

DSH `0.2.1-rc.2` `agent/inbox/spliced` is a public, durable Session event. Insert, replace, cancel, and claim first append that event and synchronously notify `session/event`; only then does the live Inbox change. At this boundary the loader maintains the only `PendingInputProjection`; it uses `Session.ownEvents()` to exclude a fork's inherited prefix, then combines durable history with this step's claimed batch (after de-duplication) into a temporary `ActivationContext` for the world-book matcher to consume read-only. Other current-log reads are centralized on `session.seq` and `snapshotEvents()` and no longer access the removed `Session.events`.

This projection belongs to the Host adapter and does not sink into pure modules:

- `world-book` still receives only explicit messages/text/options. It cannot read a session or listen to events.
- `character`, `user`, and `world-book-library` do not copy pending state or change their storage models.
- `tavern-trace` receives assembly snapshots, but schema 4 removes section/context/system-message/source bodies before persistence and retains metadata plus official references. Detail reads cold-inspect DSH history. The complete ActivationContext is not stored.
- Trace references use logical seq/message/range coordinates in the official event view, not byte offsets into compressed log files. Each detail performs one cold inspect, so long Sessions have a read cost; random access and O(1) lookup are not promised.
- Failure reasons use an independent `failureRef` to an official failure event. Error bodies are not copied and the prompt-reference cut is not extended. Details return a reason only after reference verification; an unavailable failure reference does not invalidate prompt sections that can still be verified.
- `packages/client` does not participate in capture, so a browser refresh or extra window cannot decide runtime semantics.
- The loader must handle cancel/replace/steer, multiple targets, exception cleanup, and next-step de-duplication.

This projection lets current input participate in activation during the first system assembly. It does not change ownership of DSH durable history, real role-message order, tool permissions, `agent/request`, or `request/header`.

## Control-plane extensions

- User–standalone-world-book relations are held in a separate atomic file owned by unified loader policy. `UserModel` contains `id/name/description` and optional `avatar`. `world-book-library` documents do not store user ids in reverse. The user UI can edit relations, but session-explicit sources win, user sources follow with stable de-duplication, and only the loader's shared adapter runs the matcher.
- UI scale, language, and Follow character into RP are implemented by one settings entry in `packages/client`, a shared locale contract, and per-language semantic catalogs. Business components reference semantic keys only. Dynamic resource values interpolate through an explicit raw boundary. Runtime no longer scans or replaces Chinese source strings. The loader root API persists only a bounded global display document (including `rpFollowCharacter`). Resource JSON, profile assembly, and session selection do not read display language/scale. Optional `rp:policy` text is another bounded file, `rp-policy.json`.
- Conversation display preferences are not mixed into that outer UI document. The loader saves `textScale/actionScale` through independent `conversation-settings.json` and v1 `/conversation-settings`. The client notifies only Mowan chat and the empty-playthrough opening dock. Body scale enters RP text through a local CSS custom property. Button scale enters only the durable QA action row, so it does not cascade into native DSH, the composer, Tavern panels, prompts, or exports.
- Both of these must reuse the existing single-plugin API, security boundary, refresh events, and atomic persistence. They must not be implemented by adding a second installable plugin.

## Native-first frontend adaptation

The frontend long-term rule is “minimal change, maximum compatibility”: first look for an equivalent in the current DSH version's package README, root export types, and public slots/services. Build only when DSH has no public interface for that Tavern meaning. Reuse is not “we can import it from DSH source”. It must be in public docs or root exports, injected or declared by the plugin manifest, must not read `/src/*` or bundle-internal symbols, and Host data plus the native UI must still work independently after this plugin is uninstalled.

### DSH mechanisms already reused

| Tavern capability | Public DSH mechanism reused | Custom part and boundary |
| --- | --- | --- |
| DT orb entry | Additive `shell.overlay` slot, Cordis effect lifecycle | Orb, menu contents, and global chrome state are product UI. Do not create an uncontrolled root on `document.body` |
| Mowan sidebar | `sidebar.workspaces` slot; owner-injected `useSessions` / `useWorkspaces`; `ctx.uiWorkspace.openSession()` | Reproject as character/playthrough only. Do not rewrite, archive, or hide Host session data |
| Workspace diagnostics | Public `useSessions` / `useWorkspaces` mirrors; existing v1/v2 resource and managed-file reads | Share current problems with the sidebar and assess Session availability after mirrors are ready. Do not copy Host logs or add a diagnostics API |
| DSH outer New session | Owned by the DSH `0.2.1-rc.2` sidebar shell; no public slot/service for Tavern to take over its click | Tavern does not take it over with hashed classes, DOM capture, or source replacement. Mowan keeps the native button and documents it as not recommended. Ordinary-area `+` only guides back to native |
| Ordinary-session hint | Independent full-row `conversation.input.dock` slot, inherited `--dsh-composer-card-max-width` | Shows only Tavern's RP-workspace classification. The hint is centered to Host composer width. It does not take over the native composer, copy fixed pixels, or read hashed classes |
| Mowan conversation page | `conversation.view`; `useChat` with `legacy.nodes/partial` and `timeline`; `useSession` lifecycle and error fields | Cross-session aggregation is a Tavern projection. Do not forge DSH messages or read private runtime |
| Mowan default view | Conversation store handle from `slots.entries("conversation.session")`, session-scoped `conversation.input.dock` and `actions.setView()` | Reuse the same store for each session/playthrough binding; retain the adapter for other scoped owners. Do not register a second `chat` or override explicit choices |
| Live send and streaming | The public `legacy` message projection from DSH `useChat` | `/v2/messages` only reconciles durable ranges. Session no longer has `nodes/partial`; top-level Chat `nodes` is not an array |
| Blank-playthrough opening | Public `conversationPhase(session, conversation)` and `useConversation` | Do not read removed Session `composerPhase` or duplicate the phase state machine |
| Conversation scroll | Conversation `[data-conversation-scroll]` scrollport, sticky composer geometry, injected `chatScroll.save(null)` | Choose only when to call native “scroll to bottom”. Do not compute a fixed composer height or keep a second scroll container |
| Clean new session / templates | DSH mode reuses `uiWorkspace.connectWorkspace()`; Mowan reuses the playthrough v2 session-controller composition; both navigate with `uiWorkspace.openSession()` | Tavern only copies selection atomically onto the target session. Mowan additionally treats the configured character as playthrough ownership and read-back-validates. It does not construct messages or fork history |
| Playthrough session operations | Host `sessions.create/rename/fork/prompt/history`, `workspace.insertSessionBefore`; Host-side `Session.deriveMessages()` | v2 composes these atomic operations into playthrough transactions usable by third-party frontends, while DSH sessions remain authoritative history |
| RP secure mode | Official `sandbox/mode` Session event, `tools.guard`, Session/agent lifecycle hooks | Tavern stores only whether RP is on and the follow source. It does not invent a second sandbox state |
| Prompt and audit | `systemPrompt.section`, `system-prompt/assemble`, `agent/request`, `llm/stream`, official Session events / inspect | The loader emits named sections. Trace stores bounded source metadata and official-history references, then cold-reads and verifies bodies on demand |
| Tavern Trace | Additive `conversation.view` | Trace is an explanation layer over the loader snapshot. It does not replace native Chat / Trajectory |
| Visual adaptation | DSH `--dsw-*` theme / semantic tokens | Character-card, playthrough, and resource-editor layout stay owned by Tavern |

### Current Tavern frontend boundaries

The following behavior defines the current implementation and its public dependency boundary:

- User and assistant bodies are not migrated directly onto `MessageText` / `MarkdownText`. Uncovered messages run the browser display pipeline from DSH-authoritative content: “macro replace → ST display regex (global → preset → character, each source keeps array order) → Marked 18.0.10 → DOMPurify”. Custom/XML wrapper tags therefore do not block Markdown inside them, and nested tags plus ST's loose quoted-fence semantics stay. The rules page allows drag only within one source. After save, global rules write the workspace document; resource rules write back to native `regex_scripts`. DSH `MarkdownText` omits raw HTML and cannot be the ST-HTML-compatible renderer. Later Marked upgrades, sanitizer changes, or reuse of lower DSH capabilities must separately compare ST output and malicious-HTML cases, prove they do not change Tavern display semantics or bypass the sanitizer, then accept independently.
- A dedicated details block parser preserves inner Markdown without adding Markdown breaks to raw HTML layouts. Complete HTML documents in closed unlabeled/html fences render as static templates; ordinary code fragments stay literal. `rich-text-styles.js` places purified styled content in Shadow DOM, isolates complete documents individually and adapts their root selectors, with outer layout/paint containment. A React ref mounts it after insertion/updates; static exports use the same declarative roots. Static templates never execute JS. Optional interactive cards use a separate quota-limited interpreter, a script-disabled iframe and bounded DOM bridge; see [presentation architecture](CONVERSATION_PRESENTATION_en.md). Browser verification: `node scripts/verify-rich-text-browser.mjs` (Chrome/Chromium; optionally set `CHROME_PATH`).
- Mowan does not render reasoning or runtime context and provides no expand control. Users who need runtime detail return to native DSH **Chat**. Action buttons may depend only on public icons, `Tooltip`, and similar interfaces; bundle-internal unpublished `ReasoningRow` and `MessageIconActions` are not dependable interfaces.
- DSH model-message `role` and UI origin are different dimensions. Public ConversationNode already represents runtime injection as `kind: "context"`, but the durable history projection may still give it `role: "user"`. v2 therefore adds additive `origin.kind` without changing `role`, and keeps optional source metadata such as `producer` / `form` / `summary`. An RP frontend must project bubbles, hide/present context, and compute action capability from `origin`. It must not guess from text, position, or “is this the last output segment”.
- Timeline expresses a branch tree with `parentVariantId` and an active `head`. Display, focus, and new-QA reconcile work only along the head's ancestor path. The head session may be a continuation just branched with no new QA yet, so sidebar classification must treat the head session as a playthrough member. Old flat timelines stay readable; the next reconcile enters the tree.
- Built-in action rows belong to the durable QA, not to one visible assistant body. Real user/steering output retries itself. Context-triggered parent output walks backward to the nearest real user turn and reruns the whole turn. The controller never resends `origin=context` as a user prompt. New-playthrough branch and same-playthrough rollback reuse the same DSH branch / inherited-range checks. The only difference is creating a catalog copy versus moving the original timeline head. Hide and its timeline field never entered the v2 contract. Display regex only decides whether each body segment renders. One QA, no matter how many assistant segments it has or whether all were cleared, keeps one action group at the QA end. Timeline references and provenance always remain.
- DSH message-surface replacement can repeatedly obscure the current node. Original append-only events stay readable, but the current public meaning is only “a contiguous range → one message”. There is no `unreplace`, atomic multi-message restore, or per-request history projection. It fits native compaction/checkpoint. It does not fit an RP branch tree. DT therefore stores each continuation in a public branch session so DSH history, role/tool pairing, native Chat, and uninstall fallback stay valid. Timeline only composes those session pointers into the active playthrough path. Full trade-off: `DSH_MESSAGE_FLOW_en.md` §1.1.
- `displayOverride` is edited by an in-conversation multiline editor. Save and Cancel/Esc stay on the current reply. They do not use `window.prompt`. The override is defined as final display text: later macros and display regex are skipped; Marked/DOMPurify still run. An empty string is a valid override and keeps Restore. Restore sets `null` and reruns the current display pipeline from the DSH original. Save still writes display metadata through the existing node controller and timeline CAS. It does not change the DSH original or model context.
- Playthrough IO exists only in the sidebar `PlayIoMenu`; it does not occupy or rewrite native composer-left actions.
- Message scrolling uses the DSH scrollport's `scrollTop = scrollHeight` semantics. Tavern does not maintain local anchors, fixed occlusion values, or composer-height compensation.

When introducing primitives, `@deepseek-ai/dsh-client-ui-primitives` must be an explicit, same-version-family client dependency/inject. Do not borrow transitive dependencies from the DSH install directory. Migration must accept item by item. Do not replace every control at once for visual unity.

### Custom Tavern layers that must stay

DSH currently has no native data model for character cards, playthroughs, greeting, cross-session adopted variants, ST display regex, or Tavern selection. Therefore `catalog.json` / `timeline.json`, the character→playthrough sidebar projection, cross-session reply switching, opening display and first-turn prompt reference, regex resource management, and the v2 playthrough protocol stay owned by Tavern. They point at DSH-authoritative messages by event range and do not copy bodies. Subdirectories inside the RP workspace must also pass Tavern's path jail. DSH native/browse directory flow is a UI seam for choosing or registering a Workspace. It does not provide a unified Host capability for “let a third-party v2 frontend safely create arbitrary playthrough subdirectories inside an already-bound root”.

Playthrough names and DSH session names are intentionally separate. Tavern stores a monotonic number per character and displays `Playthrough {number}` or `{number}周目` for the current UI locale. After an explicit user rename, the title is shown verbatim and no longer changes with locale. The original DSH session stays named by Host as “character name + time”, so authoritative data stays recognizable after leaving Mowan or uninstalling. Old catalogs without a number get a computed fill from that card's existing order. Legacy generated titles with a number can be recognized at display time, but old rows are not rewritten only for compatibility.

Create only inspects that card's highest-numbered playthrough. Reuse is forbidden when the timeline already has QA, imported context already has QA, DSH-authoritative messages already have user/assistant, or an unfinished turn exists. Greeting alone is not durable history. Only when all four are empty is the original root session opened, with no directory, session, or catalog write. When an old playthrough references a missing Session, preserve that playthrough and its error while allowing a new playthrough. Never reuse or overwrite the missing run as empty. Other read errors propagate instead of being guessed as empty.

Character-selection changes add a membership guard first. v1 only reports “detach required” plus structured conflicts and does not write selection without confirm. After confirm, v2 detach is computed on the server from `parentVariantId` (flat timelines use the previous adopted variant) for the target and descendants, and commits with each timeline/catalog revision as CAS. It does not delete DSH sessions or rehang sibling branches. After root detach, catalog keeps the empty playthrough; the next same-character create attaches a new blank root session. This explicit lifecycle verb keeps third-party frontends from each inventing a tree-prune algorithm.

Imported records remain immutable `import-context.json`. They neither forge DSH user/assistant QA nor copy into the timeline; DSH official history does retain imported system text used in real requests. An empty session manages the loader's authoritative binding through `/sessions/:id/import-context` GET/PUT/DELETE. Rebind writes a new file then replaces the pending reference. Unbind only clears the reference and keeps the workspace file for recovery/audit. After DSH conversation, an open turn, or a claimed binding, the backend locks mutation. Public export composes “imported greeting/QA → later timeline pointers resolved to DSH originals”. Static HTML outputs the currently visible greeting and RP render. SillyTavern JSONL outputs greeting, the current active path, and each QA's `swipes` / `swipe_id`. Greeting `{{user}}` / `{{char}}` are frozen to current display names at export. Import files stay immutable and keep participating in hash checks. The loader expands Tavern macros in greeting and QA with the current user/character profile snapshot only at prompt-projection time, then XML-escapes so leftover ST placeholders are not misread as DSH prompt variables. ST JSONL cannot express the full playthrough tree. When this plugin re-imports an ST record it binds only the selected linear history represented by each line's `mes`. The current public surface defines no portable bundle. Full recovery requires the RP workspace, Tavern persistent directory, and corresponding DSH Session logs with their inheritance dependencies. The frontend must also sync catalog/timeline display references and read-back-validate. Current v2 has no unified transaction across import binding, files, and catalog/timeline, so validation can only expose a half-complete state. It cannot claim an atomic commit.
The current playthrough lifecycle is a frontend composition of these atomic capabilities: the character-card sidebar creates or reuses the latest empty root session, writes the character/playthrough directory, empty timeline, and catalog metadata, then rereads and validates. Renaming a generated `Playthrough N` edits the catalog and switches that row to a verbatim custom title. Empty-session greeting and imported-record preview hang on session-scoped `conversation.input.dock` and do not register a second conversation view. Imported records bind to the existing empty root session's import-context file. The opening footer provides bind, rebind, unbind, and last-three-QA preview. Real messages, an open turn, or a claimed binding lock the Host API.

Current implementation boundaries:

- Greeting, imported QA, and timelines never forge DSH user/assistant history messages; DSH still saves system text used in actual assembly. The first real assembly reads public `claimEventSeqs` from the same profile snapshot, then persists a successful pending → `claimed` transition and injects escaped, `untrusted`, read-only context. A view/assembly without a claim neither injects nor consumes. The same claimed identity may replay before terminal; a new claim after terminal does not inject.
- History first fixes a cut through `inspect`, then pages until Host `hasMore: false`. An empty page, illegal oldest `seq`, or repeating/non-advancing cursor returns 502 `PLAY_HISTORY_CURSOR_STALLED`; no summarization or slicing occurs.
- Catalog/timeline GET validates inside the target guard and returns the exact UTF-8-byte SHA-256 `revision`. PUT compares explicit `expectedRevision`, validates, writes a temporary file, and renames inside that guard. Missing fields, malformed revisions, and conflicts use stable 400/409 errors; a conflict leaves the file unchanged.
- The bundled live client manages revision read-back/cache, `null` create-only, and bounded CAS replay. Replay reruns pure document mutators only, never Session/branch/user-message/directory side effects. Custom clients exposing only get/put receive one compatibility fallback with no concurrent-replay guarantee.
- Stable focus is derived by playthrough id; explicit-path routes are compatibility entries. Target locks perform per-segment path checks, realpath verification, exclusive temporary writes, and revalidation before rename. Pure Node does not promise cross-process or kernel-level no-follow transactions.
- Tavern branch/swipe copies body-free import lineage. Provider retries before the same terminal may reuse the claim; new claims after terminal do not inject. Third-party native forks are outside Tavern interception.
- These operations do not form a cross-file transaction. The shared API boundary records correlation and terminals for monitored mutations; a few checkpoints record confirmed creations/writes. Reading logs emits no logs. Recovery requires state read-back and error codes, not automatic log replay. See the [operation log contract](OPERATION_LOGS_en.md) for coverage, event versions and capacity.

Plugin-owned resource changes continue to use a bounded Tavern refresh event. Session / Workspace / live Chat changes must subscribe to DSH stores. That custom event must not replace Host state management.

### DSH upgrade review

On every DSH version upgrade, first do a read-only diff audit: plugin-manifest inject, public package root exports, slot owner props, store fields, Host RPC, and README contracts. Then run native/play dual-mode and uninstall-fallback acceptance. If a public seam disappears, fail the matching enhancement closed and keep the native surface first, then discuss a protocol change. Do not temporarily switch to DOM queries, internal bundle symbols, or private runtime. Design notes for new frontend features must explicitly write “reused native mechanism / reason for custom work / official upgrade observation point”.

DSH `0.2.1-rc.2` separates three owners: Session owns lifecycle, Chat owns live messages, and Conversation owns views and interaction phase. The active main-view Session is selected from `useSessions` entries with `retainedBy.mainView > 0`; navigation uses public `uiWorkspace.openSession()`, not the removed `sessions.current/open` contract. Mirrors still supply lifecycle and workspace membership.

RP/Trace slot registration is global, while the reused `conversation.session` store and injected bindings are scoped to each Session. The RP default adapter stays mounted and makes one default decision per session identity/workspace/playthrough binding, changing only an unset view. An unrelated retained Session with no RP binding returns from RP to native Chat; explicit Chat/Trace choices stay intact. Missing public store handles disable this enhancement. Transient binding-read failure preserves an established matching binding instead of treating it as absent.

RP cached snapshots are bounded per client and keyed by playthrough path plus Session ID. Swipe transitions may explicitly retain the source Session's snapshot until the target is ready; unrelated retained Sessions cannot share a cache merely because they belong to one playthrough. Browser-only `conversationPhase` remains injected by `entry.js`. Regression covers first-send default RP, blank opening, partial increments, Trace, simultaneous retained owners, scope changes, and mode-exit disposal.

Tavern locale is independent of DSH locale. RP, sidebar, and opening dock subscribe to the full UI settings, not only scale. A locale change also refreshes Tavern's own RP tab registration because DSH snapshots its label in the view roster; the Conversation store and completed default-view choice stay intact. Generated playthrough names follow locale; custom titles and character bodies are not translated. Locale events do not replace DSH Session/Chat subscriptions.

## Installation units and pure libraries

The installable units are Tavern and its required independent assembler; Manager is optional. Tavern's `tavern-format` and `world-book` layers remain pure libraries inside the Tavern package. Their exports are composable program interfaces, not separate Host bundles. The loader attaches source-owned reads to the shared assembler and preserves compatibility package entry points and HTTP routes. New integrations use [the API surface index](API_SURFACES_en.md).

## Development verification

See [Developer verification](TESTING_en.md) for environment setup, commands and runtime checks.
Choose checks proportionate to the change:

1. Verify ST recognition, unknown-field retention, normalization, resource selection, prompt order, and macro behavior.
2. Run relevant tests. Full-version verification uses `npm run check` and `npm run verify:2.0`, with the target DSH dependency root configured for official codec / AgentLoop tests. Conditional skips are not passes.
3. In an isolated target Host `DSH_HOME`, check binding, new Sessions, RP lifecycle, and alignment between `llm/stream`, official durable messages, and Trace references. Verify cold detail reads after restart.
4. Check package contents and installed files: include the bundle, public documents, and assets; exclude test data, private plans, workstation paths, credentials, and imported fixtures.
5. Synchronize both languages, keep execution results in local acceptance records, and complete the applicable acceptance checks. Branch pushes, merges, tags, and releases follow the maintainer's separate authorizations.

## Two long-term acceptance tracks

Format-compatibility acceptance cares about: input recognition, diagnostics, prompt order, enablement, unknown-field retention, stable normalization, and external copyrighted fixtures staying read-only and out of the repo.

Runtime-load acceptance cares about: current selection, session isolation, append/replace, resource composition order, call config, final LLM messages/config/tools, official-history references, API audit, and the install entry. Changing load strategy later must not break format-parse tests with it.

Current architecture tests check critical dependency direction. They do not replace code review, but they stop the most obvious DSH Host logic from flowing back into the format layer.

### Tavern chrome revision and event boundary

Global blue/red frontend state is held by `packages/play`'s own `ChromeStore`. `chrome.json` stores `mode` and an opaque `revision`. `GET/PUT /v2/chrome` keep the old `ok/mode` fields and attach `revision`. A change is published only after a successful atomic write and an actual mode change. `GET /v2/chrome/events` is Tavern-owned SSE under the same API prefix: the first connection sends the current snapshot, then `chrome/change`, exposing only `mode/revision`, and releasing the subscription on close. It does not change the DSH Host store, transport, or view. External file edits and other-process writes are outside the event contract. Clients must use GET/focus refresh as a degraded check.

### Browser mode service and consumer boundary

The client composition root creates a transport-independent mode core and registers it on the stable plugin fiber with `ctx.provide('pmpDshTavernChrome', face)`. SSE/focus/polling commit server snapshots only through an internal adapter. TavernShell, the orb controller, and `playSlots.setMode()` are ordinary consumers of that service. They no longer each maintain GET, focus, or BroadcastChannel state machines.

The service's `when(mode, setup)` expresses only mode lifecycle. It does not grant surface ownership. Several plugins may subscribe at once and register their own public DSH slots. Contention for the same slot stays under that public slot contract. On provider unload, transport stops and effects are cleaned first; then Cordis revokes the service and drives required-consumer unload. Native mode still does not modify the native DSH surface.

## Sessionless opening lifecycle

`PlaythroughDrafts` owns unsent playthrough configuration, assembly snapshot and initial MVU in plugin storage; catalog and empty timeline remain in the RP workspace. Draft IDs never enter DSH Session APIs. Preparation and message admission remain separate composable primitives. A unique Session/request identity is persisted before preparation; public Workspace archive APIs isolate the prepared real blank. Only a real `turn/start` and matching first-input identity add `rootSessionId` to the catalog. Public `agent/pre-step` middleware waits for temporary unarchive before the native gate proceeds. Cancellation coordinates with admission and never clears admitted history. Existing native playthrough IDs remain unchanged; no DSH core modification is required.

```mermaid
sequenceDiagram
  participant UI as Tavern UI
  participant Draft as PlaythroughDrafts
  participant DSH as Public DSH APIs
  UI->>Draft: Save playthrough, configuration and initial variables
  Note over Draft: No DSH Session
  UI->>Draft: Prepare unique first input
  Draft->>DSH: Create and temporarily archive real Session
  Draft->>Draft: Transfer configuration and initial variables
  Draft-->>UI: sessionId + requestId
  UI->>DSH: Existing message API
  DSH-->>Draft: Real turn/start
  Draft->>Draft: Link catalog
  Draft->>DSH: Unarchive
  DSH-->>UI: Native conversation and streaming reply
```
