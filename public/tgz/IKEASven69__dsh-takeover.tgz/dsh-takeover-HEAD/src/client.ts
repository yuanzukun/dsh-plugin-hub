/**
 * dsh-takeover 浏览器半：设置页「dsh-takeover」卡 + 接力工作台（composer 浮层）。
 * 设置卡（DESIGN.md §4 设置卡页签，三段页签、禁止长滚动）：命令速览（/handoff · /inbox ·
 * /resume-*，mono 键+说明）/ 支持矩阵（九家读取器：规范名+品牌图标、会话数、状态 pill、
 * 启用开关）/ 开关语义说明。工作台（收件箱概览即时过滤 + 相邻重复卡分组 + 「新」卡徽标
 * （localStorage 已见集，键含 HANDOFF_HOME 散列）+ 展开看目标段预览 + 单卡/全部导出 .md +
 * 导出 HTML 报告（自包含单文件，state→html 为可单测纯函数）+ archived 计数 + 清空归档）
 * 在 slim 模式下由输入框「接力」按钮唤出，老宿主降级时内嵌在设置卡页签之外常驻。
 * 文案走宿主 i18n：ctx.locale 注册本卡词典（zh/en）+ bind 出 t()，
 * 语言切换经 locale revision 驱动重渲染（宿主缺席时回退 zh 静态词典）。
 * 数据通路走同源 fetch 直连 host 路由 /dsh-takeover/*。
 * 取件不在设置卡做——会话里 /inbox。
 * host 侧并行落地中的扩展字段（机器信封字符数 / 四态覆盖率）走防御式读取：
 * 字段缺席即整行/徽标不显示，绝不硬造。
 * @module dsh-takeover/client
 */

import { Component, createElement, useEffect, useId, useRef, useState, useSyncExternalStore } from 'react'
// 0.2.0：一方客户端插件直接收 cordis Context。
import type { Context } from '@deepseek-ai/cordis'
// Type-only: ctx.slots（SlotRegistry 服务）由 ui-renderer 的 cordis Context 合并提供。
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
// Type-only: pulls the settings shell's SlotMap merge (the 'settings.section' entry).
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
// Type-only: ctx.locale（LocaleRuntime）由 dsh-client-locale 的 Context 增强提供。
import type { LocaleRuntime } from '@deepseek-ai/dsh-client-locale/client'
// Type-only: Translate 形态（(key, params) => string，{name} 占位）。
import type { Translate } from '@deepseek-ai/dsh-client-ui-slots'
import { BRAND_FULL_SVG, BRAND_MARKS, PROVIDER_LABEL } from './brand-icons.ts'
import type { BrandMark } from './brand-icons.ts'
import { DICTS, NS, interpolate } from './locales.ts'
import {
  cardMarkdown,
  displayTitleOf,
  filterPending,
  groupAdjacent,
  loadSeenSet,
  newIdsOf,
  pendingListMarkdown,
  saveSeenSet,
  sourceFacets,
  seenStorageKey,
} from './inbox-view.ts'
import type { PendingGroup, SeenStore } from './inbox-view.ts'
import type { TakeoverState, PendingRow, ProviderRow } from './settings.ts'
import type { MemorySourceRow } from './memory.ts'
import {
  cwdFacets,
  depositCommand,
  filterByCwd,
  filterSessions,
  humanChars,
  isSubagentSession,
  OUTBOUND_LABELS,
  OUTBOUND_TARGETS,
  outboundCommand,
  pickupCommand,
  projectColor,
  relTime,
  shortId,
  takeoverCommand,
  uiNavigatorOf,
} from './browser-view.ts'
import type { OutboundTarget, SessionListBody, SessionPreviewBody, SessionRow } from './browser-view.ts'

/** 卡片渲染语言（跟随宿主 active locale；未登记语言回退 zh）。
 * 导出——报告纯函数按 lang 出 <html lang> 与文案注入，单测两套词典都要能过。 */
export type Lang = 'zh' | 'en'

// ---------------------------------------------------------------------------
// i18n：注册本卡词典并绑定 t。宿主 locale 服务缺席（旧宿主/非浏览器）时
// 回退 zh 静态词典 + 本地插值，保证卡片永远可用。
// ---------------------------------------------------------------------------

const tCache = new WeakMap<object, Translate>()

/**
 * 防御式取宿主 locale 服务：cordis 对未挂载服务的属性访问会直接 throw
 * （locale 插件可能晚于本插件挂载），绝不能让异常从渲染工厂里逃出去。
 */
function resolveLocale(ctx: Context): LocaleRuntime | undefined {
  try {
    const l: unknown = (ctx as unknown as { locale?: unknown }).locale
    return l !== null && typeof l === 'object' ? (l as LocaleRuntime) : undefined
  } catch {
    return undefined
  }
}

function makeT(ctx: Context): Translate {
  const hit = tCache.get(ctx)
  if (hit !== undefined) return hit
  const locale = resolveLocale(ctx)
  let t: Translate
  if (locale !== undefined && typeof locale.register === 'function' && typeof locale.bind === 'function') {
    try {
      locale.register(NS, 'zh', DICTS.zh)
      locale.register(NS, 'en', DICTS.en)
      t = locale.bind(NS)
    } catch (e) {
      // 重复注册（HMR 重跑）/宿主词典约束变化：降级静态 zh，卡片不塌
      console.warn('[dsh-takeover] locale register/bind 失败，回退静态词典：', e)
      t = (key, params) => interpolate(DICTS.zh[String(key)] ?? String(key), params)
    }
  } else {
    t = (key, params) => interpolate(DICTS.zh[String(key)] ?? String(key), params)
  }
  tCache.set(ctx, t)
  return t
}

/** 宿主 active locale → 卡片渲染语言 */
function langOf(locale: LocaleRuntime | undefined): Lang {
  try {
    return locale?.getLocale().active === 'en' ? 'en' : 'zh'
  } catch {
    return 'zh'
  }
}

/**
 * 宿主主题探测：宿主主题是 CSS 模块字面色、不暴露 --muted 令牌，
 * prefers-color-scheme 又只跟系统不跟宿主；宿主切主题换的是背景（浅=白底，
 * 深=黑底），文字色恒定。所以按 body 背景色亮度判断明暗，给 muted /
 * 语义色选对轴。每次渲染现算（主题切换后任意交互即校正）。
 * forceDark：工作台面（DESIGN.md §1 近黑画布指挥台）自铺 --tk-canvas，恒走暗轴
 * ——设置卡内嵌（老宿主降级）落在浅色宿主页里也不翻白。
 */
function themeVars(forceDark = false): Record<string, string> {
  let dark = true
  try {
    if (forceDark) return darkVars()
    // body 背景透明（rgba alpha 0 / 空）时退化到 html 根元素——部分宿主只给根上底色
    let bg = getComputedStyle(document.body).backgroundColor
    if (bg === '' || /rgba?\([^)]*\/\s*0\s*\)/.test(bg) || bg === 'transparent') {
      bg = getComputedStyle(document.documentElement).backgroundColor
    }
    // oklch/oklab 等 modern 色彩函数抓不出 r/g/b（`oklch(0.98 0 0)` 会被 \d+ 抓成 r=0,g=98）——
    // 提取首参亮度分量判明暗（0~1 或百分比），解析不了再退 rgb/深色保底
    const modern = /^(oklch|oklab|lab|lch)\(\s*([\d.]+)(%?)/.exec(bg)
    if (modern) {
      const l = Number(modern[2]) * (modern[3] === '%' ? 0.01 : 1)
      dark = l <= 0.5
    } else {
      const m = bg.match(/\d+/g)
      if (m && m.length >= 3) {
        const [r = 0, g = 0, b = 0] = m.map(Number)
        dark = (0.299 * r + 0.587 * g + 0.114 * b) / 255 <= 0.5
      }
    }
  } catch {
    /* 保底按深色 */
  }
  return dark
    ? darkVars()
    : {
        '--bt-a-text': '#4f46e5',
        '--bt-mut': 'rgba(30,41,59,.72)',
        '--bt-ok': '#15803d',
        '--bt-warn': '#b45309',
        '--bt-err': '#d93025',
        '--bt-card': 'rgba(15,23,42,.04)',
        '--bt-line': 'rgba(15,23,42,.12)',
        '--bt-id': 'rgba(30,41,59,.55)',
        '--bt-inset': 'inset 0 1px 0 rgba(255,255,255,.7)',
        // 壳层亮轴：白阶渐变
        '--bt-shell-bg': 'linear-gradient(180deg, #ffffff, #f4f5f7)',
        '--bt-shell-border': 'rgba(15,23,42,.12)',
        '--bt-shell-edge': 'linear-gradient(90deg, #6366F1, #8B5CF6, #6366F1)',
      }
}

/** 暗轴 --bt-* 令牌（宿主深色页 / 工作台画布内恒用）。文字与描边值对齐
 * DESIGN.md §2 的 --tk-* 三级文字与两级描边，内层组件（卡行/chips/输入框）
 * 不改一行也落在同一调色板上。 */
function darkVars(): Record<string, string> {
  return {
    '--bt-a-text': '#c7cdfd',
    '--bt-mut': '#9aa3b5',
    '--bt-ok': '#34d399',
    '--bt-warn': '#fbbf24',
    '--bt-err': '#fb7185',
    // 三级表面：canvas（浮层壳/面板自身，不另铺色）→ 卡（透明/极淡底+描边）
    // → 嵌套面（--bt-card，比卡再抬一档，预览块/输入框/会话行用）
    '--bt-card': 'rgba(255,255,255,.032)',
    '--bt-line': 'rgba(255,255,255,.075)',
    '--bt-id': '#6b7386',
    '--bt-hover': 'rgba(255,255,255,.055)',
    // 壳层（浮层模态本体）：近黑画布 + 发光描边——与宿主页立即拉开层次
    '--bt-shell-bg': 'linear-gradient(180deg, #0e0f13, #08090a)',
    '--bt-shell-border': 'rgba(255,255,255,.12)',
    '--bt-shell-edge': 'linear-gradient(90deg, #6366F1, #8B5CF6, #6366F1)',
    // 顶部 1px 内发光（描边浮现卡的内高光，随明暗轴换色）
    '--bt-inset': 'inset 0 1px 0 rgba(255,255,255,.06)',
  }
}

// 注意：不要把 'sidebarRightTabs' 加进 inject——第三方插件入口的加载器对未知
// 服务名会直接判激活失败（实测 0.2.0-rc.2 整卡全灭）。服务在客户端根上下文，
// 走 ctx.root 探测（与 sessionController 同款路径），缺席即降级。
export const inject = ['slots', 'locale']

// ---------------------------------------------------------------------------
// 品牌图标：assets/icon.svg 的内联副本（改图标时两边同步）。
// 圆角方底 + 接管意象（双箭头 » 进格 |，读作"接管席位"），渐变 #6366F1→#8B5CF6。
// 渐变 id 加 bt- 前缀避免与宿主页面里的 defs 撞名。
// ---------------------------------------------------------------------------

export const HELP_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>'
export const MEMORY_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>'

const ICON_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="100%" height="100%" role="img" aria-label="dsh-takeover">' +
  '<defs>' +
  '<linearGradient id="bt-bg" x1="0" y1="0" x2="1" y2="1">' +
  '<stop offset="0" stop-color="#6366F1"/><stop offset="1" stop-color="#8B5CF6"/>' +
  '</linearGradient>' +
  '<linearGradient id="bt-sheen" x1="0" y1="0" x2="0" y2="1">' +
  '<stop offset="0" stop-color="#ffffff" stop-opacity=".26"/>' +
  '<stop offset=".55" stop-color="#ffffff" stop-opacity="0"/>' +
  '</linearGradient>' +
  '</defs>' +
  '<rect x="2" y="2" width="60" height="60" rx="15" fill="url(#bt-bg)"/>' +
  '<rect x="2" y="2" width="60" height="60" rx="15" fill="url(#bt-sheen)"/>' +
  '<rect x="2.75" y="2.75" width="58.5" height="58.5" rx="14.25" fill="none" stroke="#ffffff" stroke-opacity=".22" stroke-width="1.5"/>' +
  '<g fill="none" stroke="#ffffff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round">' +
  '<path d="M15 19 L27 32 L15 45"/>' +
  '<path d="M29 19 L41 32 L29 45"/>' +
  '</g>' +
  '<rect x="46.5" y="17" width="6" height="30" rx="3" fill="#ffffff" opacity=".9"/>' +
  '</svg>'

// ---------------------------------------------------------------------------
// Provider 图标：官方矢量逐家在册（见 brand-icons.ts 的来源清单）；
// gemini（第 9 家读取器）暂无在册官方矢量，走兜底小标不出冒牌标。
// 常规形态 = 官方 tile 底色 + 官方 path（fill 逐 path 保真）；
// workbuddy = 官方完整 SVG 整体内嵌（自带渐变圆底）。
// ---------------------------------------------------------------------------

function providerMark(name: string): BrandMark | null {
  const m = BRAND_MARKS[name]
  return m ?? null
}

/** 项目文件夹图标：实心小夹子，颜色=项目身份色（projectColor）。
 * 会话浏览器的项目筛选 chips 与行内项目标同源同色——同一项目跨视图一眼可认。 */
function FolderIcon({ color, size = 13 }: { color: string; size?: number }): ReturnType<typeof createElement> {
  return createElement('svg', {
    viewBox: '0 0 16 16', width: size, height: size, 'aria-hidden': true, style: { flex: 'none', display: 'block' },
  },
    createElement('path', {
      d: 'M1.5 4A1.5 1.5 0 0 1 3 2.5h3.1c.44 0 .86.2 1.14.53l.9 1.07H13A1.5 1.5 0 0 1 14.5 5.6V12A1.5 1.5 0 0 1 13 13.5H3A1.5 1.5 0 0 1 1.5 12V4Z',
      fill: color,
    }),
  )
}

function ProviderIcon({ name, size = 20 }: { name: string; size?: number }): ReturnType<typeof createElement> {
  const full = BRAND_FULL_SVG[name]
  if (full !== undefined) {
    return createElement('span', {
      className: 'bt-icon bt-icon-full',
      style: { width: size, height: size },
      title: PROVIDER_LABEL[name] ?? name,
      dangerouslySetInnerHTML: { __html: full },
    })
  }
  const mark = providerMark(name)
  if (mark === null) {
    // 未知来源（实践中只有 dsh 宿主自己）：用本插件品牌小标，不出字母块
    return createElement('span', {
      className: 'bt-icon',
      style: { background: 'linear-gradient(135deg, #6366F1, #8B5CF6)', width: size, height: size },
      title: PROVIDER_LABEL[name] ?? name,
      dangerouslySetInnerHTML: { __html: '<svg viewBox="0 0 64 64" width="100%" height="100%"><g fill="none" stroke="#fff" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"><path d="M15 19 L27 32 L15 45"/><path d="M29 19 L41 32 L29 45"/></g></svg>' },
    })
  }
  return createElement('span', {
    className: 'bt-icon',
    style: { background: mark.tile, width: size, height: size },
    title: PROVIDER_LABEL[name] ?? name,
  }, createElement('svg', { viewBox: mark.viewBox, width: Math.round(size * 0.64), height: Math.round(size * 0.64), 'aria-hidden': true },
    ...mark.paths.map((p, i) => createElement('path', { key: i, d: p.d, fill: p.fill }))),
  )
}

// ---------------------------------------------------------------------------
// 样式：颜色尽量继承宿主令牌（--accent/--border/--muted），兜底值保证浅色可读；
// 深色模式下兜底值整体换轴（prefers-color-scheme），宿主令牌在场时天然跟随主题。
// ---------------------------------------------------------------------------

/**
 * DESIGN.md §2/§6 语义 token（--tk-*）：一处定义——CSS 经 TK_DECLS 注入
 * .bt-panel，浮层壳（在 .bt-panel 之外）行内展开同一份；组件规则只许引用
 * var(--tk-*)，禁止裸色值绕过 token（DESIGN.md DON'T）。
 * 动效 token 沿用 --bt-ease/--bt-dur（cubic-bezier(.4,0,.2,1) + 160ms，同 §7）。
 */
const TK_TOKENS = {
  // canvas：近黑画布 + 顶部品牌径向辉光（§2）；壳与内嵌工作台共用一份背景
  '--tk-canvas': '#0a0c11',
  '--tk-canvas-bg':
    'radial-gradient(900px 340px at 22% -8%, rgba(99,102,241,.16), transparent 60%), ' +
    'radial-gradient(700px 300px at 90% -12%, rgba(167,139,250,.10), transparent 60%), var(--tk-canvas)',
  // surface 两级 + 导航轨微底
  '--tk-surface': 'rgba(255,255,255,.032)',
  '--tk-surface-2': 'rgba(255,255,255,.055)',
  '--tk-rail': 'rgba(255,255,255,.018)',
  // line 两级
  '--tk-line': 'rgba(255,255,255,.075)',
  '--tk-line-2': 'rgba(255,255,255,.13)',
  // text 三级
  '--tk-text': '#e7eaf2',
  '--tk-mut': '#9aa3b5',
  '--tk-dim': '#6b7386',
  // 唯一 accent 渐变（§2：logo/主按钮/导航选中/win 顶条）+ 选中态文字/软底
  '--tk-a': '#818cf8',
  '--tk-a2': '#a78bfa',
  '--tk-a-text': '#c7cdfd',
  '--tk-a-soft': 'rgba(129,140,248,.14)',
  '--tk-a-line': 'rgba(129,140,248,.5)',
  '--tk-grad': 'linear-gradient(135deg, #6366F1, #8B5CF6)',
  '--tk-edge-grad': 'linear-gradient(90deg, #6366F1, #a78bfa, #6366F1)',
  // 渐变上的文字/滑块色（§2 on-accent）——规则里不再写 #fff
  '--tk-on-accent': '#fff',
  // 品牌辉光投影闭集（§2/§6）：glow = logo + primary 按钮；glow-ctl = 选中页签等紧凑控件
  '--tk-glow': '0 4px 14px rgba(99,102,241,.4)',
  '--tk-glow-ctl': '0 2px 10px rgba(99,102,241,.3)',
  // 状态三色（闭集，§2）
  '--tk-ok': '#34d399',
  '--tk-warn': '#fbbf24',
  '--tk-err': '#fb7185',
  // 状态 pill 底纹/描边（§4：ok/warn 两色底纹+描边）——tint 也只在这里定义一次
  '--tk-ok-soft': 'rgba(52,211,153,.1)',
  '--tk-ok-line': 'rgba(52,211,153,.3)',
  '--tk-warn-soft': 'rgba(251,191,36,.1)',
  '--tk-warn-line': 'rgba(251,191,36,.3)',
  // 唯一投影：浮层本体（§6）
  '--tk-shadow': '0 24px 70px rgba(0,0,0,.5)',
}
const TK_DECLS = Object.entries(TK_TOKENS).map(([k, v]) => `${k}: ${v};`).join(' ')

/** 导航轨图标（lucide 同款线性笔触，24 viewBox stroke=currentColor；UI 字形
 * 非品牌标，不涉「禁止虚构官方矢量」约束）。记忆快照字形与记忆卡折叠栏
 * 头部的图标同源（lucide database），独立一份避免图标计数误报。 */
const NAV_ICONS = {
  inbox: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/></svg>',
  browser: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19.07 4.93A10 10 0 0 0 6.99 3.34"/><path d="M4 6h.01"/><path d="M2.29 9.62A10 10 0 1 0 21.31 8.35"/><path d="M16.24 7.76A6 6 0 1 0 8.23 16.67"/><path d="M12 18h.01"/><path d="M17.99 11.66A6 6 0 0 1 15.77 16.67"/><circle cx="12" cy="12" r="2"/><path d="m13.41 10.59 5.66-5.66"/></svg>',
  send: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3.714 3.048a.498.498 0 0 0-.683.627l2.843 7.627a2 2 0 0 1 0 1.396l-2.842 7.627a.498.498 0 0 0 .682.627l18-8.5a.5.5 0 0 0 0-.904z"/><path d="M6 12h16"/></svg>',
  memory: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>',
}

const CSS = `
.bt-panel { display: flex; flex-direction: column; gap: 16px; padding: 4px 0 10px;
  container-type: inline-size;
  --bt-a: var(--accent, #6366f1); --bt-ok: #15803d; --bt-warn: #b45309; --bt-err: #d93025;
  --bt-line: var(--border, rgba(127,127,127,.2)); --bt-mut: rgba(30,41,59,.72); --bt-pulse-dur: 1.2s;
  --bt-card: var(--bg, rgba(127,127,127,.05)); --bt-hover: rgba(127,127,127,.07);
  --bt-shadow: 0 1px 2px rgba(16,24,40,.05), 0 12px 32px -18px rgba(16,24,40,.16);
  /* 动效 token：全套 transition/animation 只吃这两个值（D 批收敛，不再零散调参） */
  --bt-ease: cubic-bezier(.4,0,.2,1); --bt-dur: 160ms;
  /* 顶部 1px 内发光（明轴默认；暗轴由 themeVars 按 body 亮度覆写） */
  --bt-inset: inset 0 1px 0 rgba(255,255,255,.7);
  /* DESIGN.md §2/§6 语义 token（唯一定义见 TK_TOKENS） */
  ${TK_DECLS} }
/* ===== 工作台重排（DESIGN.md §5）：左导航轨 148px + 右侧全宽视图，两栏拼盘废除 ===== */
/* 浮层挂载（bt-bounded）：面板吃满浮层剩余高、贴壳零内距；滚动责任下沉到 .tk-scroll */
.bt-bounded { flex: 1 1 auto; min-height: 0; overflow: hidden; gap: 0; padding: 0; }
/* 屏幕阅读器专用（浮层标题：壳内唯一可见文字是导航轨，dialog 可及名走这里） */
.tk-sr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }
.tk-body { display: flex; flex: 1 1 auto; min-height: 0; color: var(--tk-text); }
/* 设置卡内嵌（老宿主降级，无浮层壳）：工作台自铺 canvas+辉光，成为页内一块深色指挥台 */
.bt-panel:not(.bt-bounded) .tk-body { background: var(--tk-canvas-bg); border: 1px solid var(--tk-line);
  border-radius: 16px; overflow: hidden; min-height: 480px; }
/* 导航轨：164px（148 会截断「会话浏览器」——真宿主验收 11-02 抓的），logo+四视图+上手指南+版本徽标（§4 导航轨项 / §5 布局） */
.tk-rail { width: 164px; flex: none; box-sizing: border-box; border-right: 1px solid var(--tk-line);
  background: var(--tk-rail); padding: 14px 10px; display: flex; flex-direction: column; gap: 4px; }
.tk-brand { display: flex; align-items: center; gap: 8px; padding: 4px 8px 14px; min-width: 0; }
.tk-brand-logo { width: 26px; height: 26px; flex: none; display: block; overflow: hidden; border-radius: 8px;
  filter: drop-shadow(var(--tk-glow)); }
.tk-brand-logo svg { display: block; }
.tk-brand b { font-size: 13px; font-weight: 600; letter-spacing: .01em; color: var(--tk-text); }
.tk-navitem { display: flex; align-items: center; gap: 9px; width: 100%; box-sizing: border-box;
  border: 0; background: transparent; color: var(--tk-mut); padding: 9px 10px; border-radius: 9px;
  font-size: 12.5px; font-weight: 500; font-family: inherit; cursor: pointer; text-align: left;
  position: relative; transition: background var(--bt-dur) var(--bt-ease), color var(--bt-dur) var(--bt-ease); }
.tk-navitem:hover { background: var(--tk-surface); color: var(--tk-text); }
.tk-navitem:focus-visible { outline: 2px solid var(--tk-a); outline-offset: -2px; }
/* 壳层关闭钮：右上角悬浮（视图头动作让出右缘，见 .bt-bounded .tk-head） */
.tk-close { position: absolute; top: 11px; right: 12px; z-index: 2; width: 26px; height: 26px;
  display: grid; place-items: center; border-radius: 8px; border: 1px solid var(--tk-line-2);
  background: var(--tk-surface); color: var(--tk-mut); font-size: 12px; font-family: inherit; cursor: pointer;
  transition: color var(--bt-dur, 160ms) var(--bt-ease, ease), border-color var(--bt-dur, 160ms) var(--bt-ease, ease); }
.tk-close:hover { color: var(--tk-text); border-color: var(--tk-a-line); }
.tk-close:focus-visible { outline: 2px solid var(--tk-a); outline-offset: 2px; }
/* 选中态：品牌渐变左缘光条 + --tk-a-soft 底（§4） */
.tk-navitem[aria-pressed="true"] { background: var(--tk-a-soft); color: var(--tk-a-text); font-weight: 600; }
.tk-navitem[aria-pressed="true"]::before { content: ''; position: absolute; left: -10px; top: 8px; bottom: 8px;
  width: 3px; border-radius: 0 3px 3px 0; background: var(--tk-grad); }
.tk-navitem .tk-ic { width: 15px; height: 15px; flex: none; display: inline-flex; }
.tk-navitem .tk-ic svg { width: 15px; height: 15px; display: block; }
.tk-navlabel { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.tk-badge { margin-left: auto; flex: none; font-size: 10px; font-weight: 600; min-width: 17px; text-align: center;
  padding: 1px 5px; border-radius: 999px; box-sizing: border-box; background: var(--tk-a-soft); color: var(--tk-a-text);
  font-variant-numeric: tabular-nums; }
.tk-badge-hot { background: var(--tk-grad); color: var(--tk-on-accent); }
.tk-rail-foot { margin-top: auto; display: flex; flex-direction: column; gap: 2px; }
.tk-ver { margin: 8px 8px 0; font-size: 10px; color: var(--tk-dim); font-family: ui-monospace, monospace;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
/* 主区：视图头（15px 标题+一句副标+视图级动作，§5）+ 视图体内滚，头部与轨常驻 */
.tk-main { flex: 1; min-width: 0; min-height: 0; display: flex; flex-direction: column; }
.tk-view { display: none; flex-direction: column; flex: 1 1 auto; min-height: 0; min-width: 0; }
.tk-view-on { display: flex; }
.tk-head { flex: none; display: flex; align-items: center; gap: 12px; flex-wrap: wrap;
  padding: 15px 20px 13px; border-bottom: 1px solid var(--tk-line); }
.bt-bounded .tk-head { padding-right: 50px; }
/* 指南属展开体（§6）：虚线顶边分隔，不嵌卡片底色 */
.tk-view-guide .tk-head { border-bottom-style: dashed; }
.tk-view-guide .tk-scroll > .bt-card { background: transparent; border: 0; border-radius: 0; box-shadow: none; padding: 0; }
.tk-head-text { min-width: 0; }
.tk-h { margin: 0; font-size: 15px; font-weight: 600; letter-spacing: -.01em; line-height: 1.3; }
.tk-p { margin: 2px 0 0; font-size: 11px; color: var(--tk-mut); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.tk-head-acts { margin-left: auto; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; justify-content: flex-end; }
.tk-head .bt-filter { flex: 0 1 220px; min-width: 150px; height: 30px; }
.tk-scroll { flex: 1 1 auto; min-height: 0; min-width: 0; display: flex; flex-direction: column; gap: 13px;
  padding: 16px 20px 20px; }
.bt-bounded .tk-scroll { overflow-y: auto; scrollbar-width: thin; scrollbar-color: rgba(255,255,255,.18) transparent; }
.bt-bounded .tk-scroll::-webkit-scrollbar { width: 8px; }
.bt-bounded .tk-scroll::-webkit-scrollbar-thumb { background: var(--tk-line-2); border-radius: 999px; }
.bt-bounded .tk-scroll::-webkit-scrollbar-track { background: transparent; }
.tk-strips { flex: none; display: flex; flex-direction: column; gap: 8px; padding: 10px 20px 0; }
/* 收件箱概览瓦片（§4）：大数字 19px tabular + 小标签 + 左缘 3px 语义色条；窄容器两行（§8）。
   DOM 顺序=标签在前数字在后（读屏念「待取件 3」而非「3 待取件」），column-reverse 负责视觉上数字在上 */
.tk-tiles { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; }
.tk-tile { background: var(--tk-surface); border: 1px solid var(--tk-line); border-radius: 12px;
  padding: 11px 13px 10px; position: relative; overflow: hidden; box-sizing: border-box; min-width: 0;
  display: flex; flex-direction: column-reverse; gap: 2px; }
.tk-tile::after { content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 3px;
  background: var(--tk-tc, var(--tk-a)); opacity: .85; }
.tk-tile-num { font-size: 19px; font-weight: 600; letter-spacing: -.02em; line-height: 1.15;
  font-variant-numeric: tabular-nums; }
.tk-tile-lab { font-size: 11px; color: var(--tk-mut); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.tk-tile-ok .tk-tile-num { color: var(--tk-ok); }
.tk-tile-warn .tk-tile-num { color: var(--tk-warn); }
.tk-tile-err .tk-tile-num { color: var(--tk-err); }
@container (max-width: 975px) {
  .tk-tiles { grid-template-columns: repeat(3, 1fr); }
  .tk-head { padding: 13px 16px 11px; }
  .tk-scroll { padding: 13px 16px 16px; }
  .tk-strips { padding: 10px 16px 0; }
}
/* 筛选行：未读开关居左、来源 chips 靠右随折行 */
.bt-filterrow { display: flex; flex-wrap: wrap; gap: 6px 14px; align-items: center; justify-content: space-between; }
.bt-filterrow .bt-chips { margin: 0; }
/* 只看新卡：独立复选框开关（未读数随显） */
.bt-newonly { display: inline-flex; align-items: center; gap: 6px; width: fit-content;
  font-size: 12px; color: var(--bt-mut); cursor: pointer; user-select: none; margin: 0; }
.bt-newonly:hover { color: var(--bt-a); }
.bt-newonly input { appearance: none; width: 14px; height: 14px; border-radius: 4px;
  border: 1px solid var(--bt-line); background: var(--bt-card); cursor: pointer; margin: 0;
  display: grid; place-content: center; transition: border-color var(--bt-dur) var(--bt-ease); }
.bt-newonly input::after { content: ''; width: 8px; height: 8px; transform: scale(0);
  background: var(--bt-a); border-radius: 2px; transition: transform var(--bt-dur) var(--bt-ease); }
.bt-newonly input:checked { border-color: var(--bt-a); }
.bt-newonly input:checked::after { transform: scale(1); }
/* 导出▾菜单：工具行右侧锚定的小浮层 */
.bt-export-wrap { position: relative; display: inline-flex; }
.bt-export-mask { position: fixed; inset: 0; z-index: 30; background: transparent; }
.bt-export-menu { position: absolute; top: calc(100% + 4px); right: 0; z-index: 31;
  display: flex; flex-direction: column; min-width: 168px; padding: 4px;
  background: var(--dsw-specific-input-major, var(--bt-card, #171717));
  border: 1px solid var(--bt-line); border-radius: 10px;
  box-shadow: 0 8px 28px rgba(0,0,0,.4); }
.bt-export-item { display: block; width: 100%; text-align: left; border: none; background: transparent;
  color: inherit; font-size: 12px; font-family: inherit; padding: 7px 10px; border-radius: 7px;
  cursor: pointer; white-space: nowrap; }
.bt-export-item:hover { background: var(--bt-hover); }
.bt-export-item:disabled { opacity: .45; cursor: default; }
/* 浮现卡（A 批）：canvas 上不铺实色底——极淡底 + 1px 描边 + 顶部 1px 内发光，
   层级靠描边与内浮现表达，替换灰底块观感 */
.bt-card { background: rgba(127,127,127,.03); border: 1px solid var(--bt-line); border-radius: 12px;
  padding: 16px 18px; display: flex; flex-direction: column; gap: 12px;
  box-shadow: var(--bt-inset), var(--bt-shadow); }
.bt-head { display: flex; align-items: center; gap: 12px; }
.bt-logo { width: 40px; height: 40px; border-radius: 11px; flex: none; overflow: hidden;
  box-shadow: 0 2px 8px rgba(99,102,241,.35), inset 0 0 0 1px rgba(255,255,255,.18); }
.bt-logo svg { display: block; }
/* 两级标题阶梯（字体纪律）：.bt-title 14px 卡主标题（最高一级），.bt-title-sec
   13px 卡内节标题——节标题一律走后者，禁止行内 fontSize 覆写 */
.bt-title { font-weight: 700; font-size: 14px; letter-spacing: -.01em; }
.bt-title-sec { font-weight: 700; font-size: 13px; letter-spacing: -.01em; }
.bt-sub { font-size: 12px; color: var(--bt-mut); line-height: 1.55; }
.bt-spacer { flex: 1; }
.bt-badge { font-size: 10px; font-weight: 600; padding: 3px 10px; border-radius: 999px;
  color: var(--bt-mut); background: rgba(127,127,127,.1); border: 1px solid var(--bt-line);
  font-variant-numeric: tabular-nums; }
.bt-badge-hot { color: var(--bt-a); background: rgba(99,102,241,.1); border-color: rgba(99,102,241,.3); }
/* bare 根（SendCard / ForeignBrowser / MemoryCard 嵌入视图体时的无壳容器） */
.bt-bare { min-width: 0; }
.bt-btn { cursor: pointer; border-radius: 10px; font-size: 12px; font-weight: 500; padding: 6px 16px;
  border: 1px solid var(--bt-line); background: transparent; color: inherit; white-space: nowrap;
  transition: border-color var(--bt-dur) var(--bt-ease), color var(--bt-dur) var(--bt-ease), background var(--bt-dur) var(--bt-ease), transform var(--bt-dur) var(--bt-ease); }
.bt-btn:disabled { opacity: .5; cursor: default; }
.bt-btn:not(:disabled):hover { border-color: var(--bt-a); color: var(--bt-a); transform: translateY(-1px); }
.bt-btn:not(:disabled):active { transform: translateY(0); }
.bt-btn-danger:not(:disabled):hover { border-color: var(--bt-err); color: var(--bt-err); }
.bt-btn-confirm { background: var(--bt-err); border-color: transparent; color: #fff; }
.bt-btn-confirm:not(:disabled):hover { color: #fff; transform: none; }
.bt-banner { font-size: 12px; line-height: 1.6; border-radius: 10px; padding: 8px 12px; }
.bt-banner-info { color: var(--bt-mut); background: rgba(127,127,127,.08); }
.bt-banner-err { color: var(--bt-err); background: rgba(211,47,47,.08); }
/* 卡行：描边浮现行——行层描边默认透明（占位不画框），hover 才浮现 1px 描边；
   未读行常驻品牌描边，长列表里不 hover 也能一眼分辨。常驻描边只留给卡与嵌套
   预览两级，行层不参与——30s 轮询整表刷新的长列表不成卡海。行入场无动画
   （刷新不闪），动效只挂在 hover/状态变化上（token：--bt-ease/--bt-dur） */
.bt-rows { display: flex; flex-direction: column; gap: 4px; }
.bt-pending { line-height: 1.45; display: flex; flex-wrap: wrap; gap: 2px 10px; align-items: flex-start;
  border-radius: 12px; padding: 10px 12px; font-size: 12px;
  border: 1px solid transparent; position: relative; box-shadow: var(--bt-inset);
  cursor: pointer; transition: background var(--bt-dur) var(--bt-ease), border-color var(--bt-dur) var(--bt-ease); }
.bt-pending:hover { background: var(--bt-hover); border-color: var(--bt-line); }
.bt-pending:focus-visible { outline: 2px solid var(--bt-a); outline-offset: -2px; }
.bt-pending-open { background: var(--bt-hover); }
.bt-pending-unread { background: rgba(99,102,241,.07); border-color: rgba(99,102,241,.3); }
.bt-pending-unread:hover { background: rgba(99,102,241,.11); border-color: rgba(99,102,241,.45); }
.bt-pending-unread::before { content: ''; position: absolute; left: 0; top: 10px; bottom: 10px;
  width: 3px; border-radius: 999px; background: linear-gradient(180deg, #6366F1, #8B5CF6);
  transform-origin: top; animation: bt-bar-in var(--bt-dur) var(--bt-ease); }
@keyframes bt-bar-in { from { transform: scaleY(0); } to { transform: scaleY(1); } }
.bt-pending-unread.bt-pending-open::before { top: 10px; }
.bt-pend-icon { flex: none; margin-top: 1px; }
.bt-pend-main { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
.bt-pend-line1 { display: flex; align-items: baseline; gap: 8px; }
.bt-pending-title { flex: 1; min-width: 0; font-weight: 600; font-size: 13px; line-height: 1.4; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.bt-pend-time { flex: none; font-size: 11px; color: var(--bt-mut); font-variant-numeric: tabular-nums; }
.bt-pending-chev { flex: none; font-size: 10px; color: var(--bt-mut); align-self: flex-start; margin-top: 3px; transition: transform var(--bt-dur) var(--bt-ease); }
.bt-pending-open .bt-pending-chev { transform: rotate(90deg); }
.bt-pend-meta { display: flex; gap: 6px; align-items: baseline; font-size: 11px; color: var(--bt-mut);
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-variant-numeric: tabular-nums; }
.bt-pend-src { font-weight: 500; }
.bt-pend-dot { opacity: .45; }
.bt-pend-id { font-family: ui-monospace, monospace; font-size: 11px; color: var(--bt-id); }
/* 展开预览：内嵌软面板（圆角 + 描边 + 品牌左缘），与行体有明确从属关系 */
.bt-preview { flex-basis: 100%; font-size: 12px; line-height: 1.65; color: inherit;
  background: var(--bt-card); border: 1px solid var(--bt-line); border-left: 2px solid var(--bt-a);
  border-radius: 10px;
  padding: 9px 12px; margin: 6px 0 2px 2px; white-space: pre-wrap;
  word-break: break-word; display: flex; flex-direction: column; gap: 4px; }
.bt-preview-hint { font-size: 11px; color: var(--bt-mut); }
/* 展开态动作行：预览提示 + 单卡导出按钮 */
.bt-preview-actions { display: flex; align-items: center; gap: 8px; justify-content: space-between;
  white-space: normal; }
/* 收件箱工具行：即时过滤输入 + 导出全部（过滤词空 = 全量） */
.bt-inbox-toolbar { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin-top: -2px; }
.bt-inbox-toolbar .bt-filter { flex: 1 1 180px; }
.bt-filter { flex: 1; min-width: 0; height: 32px; box-sizing: border-box;
  border: 1px solid var(--bt-line); border-radius: 10px; background: var(--bt-card);
  color: inherit; font-size: 12px; padding: 0 10px; outline: none;
  transition: border-color var(--bt-dur) var(--bt-ease), box-shadow var(--bt-dur) var(--bt-ease); }
.bt-filter:focus { border-color: var(--bt-a); box-shadow: 0 0 0 3px rgba(99,102,241,.15); }
.bt-filter::placeholder { color: var(--bt-mut); opacity: .75; }
/* 行内小徽标：「新」（未展开过的卡）与分组计数，同一基座。
   C 批降饱和：低饱和底 + 1px 同色描边，视觉权重降一档；字号 11px——文案是中文（§3 下限，与 .tk-pill 同裁决） */
.bt-tag { font-size: 11px; font-weight: 600; line-height: 1.5; padding: 1px 8px;
  border-radius: 999px; flex: none; white-space: nowrap; box-sizing: border-box; letter-spacing: .01em; }
.bt-tag-new { color: var(--bt-warn); background: rgba(251,191,36,.08); border: 1px solid rgba(251,191,36,.32); }
.bt-tag-lowinfo { color: var(--bt-mut); background: rgba(127,127,127,.06); border: 1px solid var(--bt-line); }
.bt-tag-group { color: var(--bt-a); background: rgba(99,102,241,.08); border: 1px solid rgba(99,102,241,.3); }
/* 组内成员行：整体右缩进，视觉上挂在组头下 */
.bt-pending-member { margin-left: 20px; }
/* 行外壳（中性容器，内含 role=button 行 + 兄弟预览块）：延续原先行内 flex-wrap 布局 */
.bt-pending-wrap { display: flex; flex-wrap: wrap; }
/* ===== 设置卡（DESIGN.md §4 设置卡页签 / 原型窗口 2）=====
   自铺 canvas 的深色指挥台块（--bt-* 行内恒走暗轴，浅色宿主页里不翻白，同工作台内嵌处理）：
   头行（logo+标题+分段器+动作）+ 三段页签面板（命令速览 / 支持矩阵 / 开关语义），禁止长滚动一屏到底 */
.tk-set { position: relative; overflow: hidden; box-sizing: border-box; min-width: 0;
  background: var(--tk-canvas-bg); color: var(--tk-text); border: 1px solid var(--tk-line); border-radius: 16px;
  padding: 16px 20px 20px; display: flex; flex-direction: column; gap: 13px;
  box-shadow: inset 0 1px 0 rgba(255,255,255,.05); }
/* 顶边 3px 品牌渐变条（§2：accent 渐变用于 win 顶条） */
.tk-set::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px;
  background: var(--tk-edge-grad); opacity: .9; }
.tk-set-head { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; min-width: 0; }
.tk-set-logo { width: 26px; height: 26px; flex: none; display: block; overflow: hidden; border-radius: 8px;
  filter: drop-shadow(var(--tk-glow)); }
.tk-set-logo svg { display: block; }
.tk-set-text { min-width: 0; flex: 0 1 auto; }
.tk-set-title { font-size: 13px; font-weight: 600; letter-spacing: -.01em; line-height: 1.3; color: var(--tk-text); }
.tk-set-sub { font-size: 11px; color: var(--tk-dim); margin-top: 1px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.tk-set-acts { display: flex; align-items: center; gap: 8px; flex: none; }
/* 分段器：3px 内距容器 + 7px 圆角页签，选中页签品牌渐变（§4）；button+aria-selected 语义 */
.tk-tabs { display: flex; gap: 3px; padding: 3px; width: fit-content; max-width: 100%; box-sizing: border-box;
  background: var(--tk-surface); border: 1px solid var(--tk-line); border-radius: 9px; margin-left: auto; }
.tk-tab { border: 0; background: transparent; color: var(--tk-mut); font-family: inherit; font-size: 12px; font-weight: 500;
  line-height: 1.3; padding: 6px 15px; border-radius: 7px; cursor: pointer; white-space: nowrap;
  transition: background var(--bt-dur) var(--bt-ease), color var(--bt-dur) var(--bt-ease); }
.tk-tab:hover { color: var(--tk-text); background: var(--tk-surface-2); }
.tk-tab:focus-visible { outline: 2px solid var(--tk-a); outline-offset: 2px; }
.tk-tab[aria-selected="true"] { background: var(--tk-grad); color: var(--tk-on-accent); font-weight: 600;
  box-shadow: var(--tk-glow-ctl); }
/* 面板：三块常驻挂载，hidden 切换（与工作台视图同一手法：display 由类控制，hidden 属性给语义） */
.tk-pane { display: none; flex-direction: column; gap: 10px; min-width: 0; }
.tk-pane-on { display: flex; }
.tk-pane[hidden] { display: none; }
.tk-pane-lead { font-size: 11px; color: var(--tk-dim); }
/* 命令速览网格：mono 键 + 说明文案（§3 代码 ui-monospace）；数据源不变（/handoff · /inbox · /resume-*） */
.tk-cmds { display: grid; grid-template-columns: repeat(auto-fill, minmax(290px, 1fr)); gap: 8px; }
.tk-cmd { display: flex; align-items: center; gap: 9px; min-width: 0; box-sizing: border-box;
  border: 1px solid var(--tk-line); border-radius: 9px; padding: 9px 12px; background: var(--tk-surface);
  transition: border-color var(--bt-dur) var(--bt-ease), opacity var(--bt-dur) var(--bt-ease); }
.tk-cmd:hover { border-color: var(--tk-a-line); }
.tk-cmd .bt-icon { width: 16px; height: 16px; flex: none; border-radius: 5px; }
.tk-cmd-key { font-family: ui-monospace, monospace; font-size: 11px; font-weight: 600; color: var(--tk-text); flex: none; }
.tk-cmd-key-primary { color: var(--tk-a-text); }
.tk-cmd-desc { font-size: 11px; color: var(--tk-mut); min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.tk-cmd-off { opacity: .42; }
.bt-icon { display: inline-flex; align-items: center; justify-content: center; border-radius: 6px;
  flex: none; overflow: hidden; box-shadow: inset 0 0 0 1px rgba(255,255,255,.14), 0 1px 2px rgba(0,0,0,.16); }
.bt-icon svg { display: block; }
.bt-icon-full { border-radius: 50%; }
.bt-icon-full svg { width: 100%; height: 100%; }
.bt-icon-letter { color: #fff; font-weight: 700; font-size: 11px; line-height: 1; letter-spacing: -.02em; user-select: none; }
/* 支持矩阵（九家）：名称列（品牌图标+规范名+mono id+哨兵提示）/ 会话数 / 状态 pill / 开关 */
.tk-mx { display: flex; flex-direction: column; }
.tk-mxr { display: grid; grid-template-columns: minmax(170px, auto) 1fr auto auto; gap: 11px; align-items: center;
  padding: 8px 4px; border-bottom: 1px solid var(--tk-line); border-radius: 8px;
  transition: opacity var(--bt-dur) var(--bt-ease), background var(--bt-dur) var(--bt-ease); }
.tk-mxr:hover { background: var(--tk-surface); }
.tk-mxr:last-child { border-bottom: 0; }
/* 灰行 = 本机未装或暂无会话（note 为空）；待确认行保持全亮，黄 pill 第一眼可辨 */
.tk-mxr-idle { opacity: .5; }
.tk-mxr-idle:hover { opacity: .85; }
.tk-mname-col { display: flex; flex-direction: column; gap: 3px; min-width: 0; }
.tk-mname-wrap { display: flex; align-items: center; gap: 8px; min-width: 0; }
.tk-mname { font-size: 13px; font-weight: 600; letter-spacing: -.01em; color: var(--tk-text); white-space: nowrap; }
.tk-mid { font-family: ui-monospace, monospace; font-size: 11px; color: var(--tk-dim); }
/* 假 0 哨兵浮出：supported 且 note 非空时行内黄色小字（不只放 title），与 pill 同轴 */
.tk-mnote { font-size: 11px; line-height: 1.5; color: var(--tk-warn); max-width: 360px; overflow-wrap: anywhere; }
.tk-mstat { font-size: 11px; color: var(--tk-mut); text-align: right; overflow: hidden; text-overflow: ellipsis;
  white-space: nowrap; font-variant-numeric: tabular-nums; }
/* 状态 pill（§4）：11px/600 胶囊（§3 中文下限 11px 优先于原型的 10px——文案是中文），
   ok/warn 两色底纹+描边，文案闭集（支持 / 待确认 / 不可用） */
.tk-pill { font-size: 11px; font-weight: 600; padding: 2px 9px; border-radius: 999px; flex: none;
  min-width: 34px; text-align: center; box-sizing: border-box; letter-spacing: .01em; white-space: nowrap; }
.tk-pill-ok { color: var(--tk-ok); background: var(--tk-ok-soft); border: 1px solid var(--tk-ok-line); }
.tk-pill-warn { color: var(--tk-warn); background: var(--tk-warn-soft); border: 1px solid var(--tk-warn-line); }
/* 开关（§4）：34×19 圆角轨（视觉），选中品牌渐变，白色滑块带投影；滑块只动 transform（§7）。
   命中区：透明 ::before 上下各扩 3px → 25px 高，满足 §8 可点目标 ≥24px，轨尺寸不变 */
.tk-switch { cursor: pointer; width: 34px; height: 19px; border-radius: 999px; border: 0; padding: 0;
  background: var(--tk-line-2); position: relative; justify-self: end; flex: none;
  transition: background var(--bt-dur) var(--bt-ease); }
.tk-switch::before { content: ''; position: absolute; left: 0; right: 0; top: -3px; bottom: -3px; }
.tk-switch:disabled { opacity: .45; cursor: default; }
.tk-switch:focus-visible { outline: 2px solid var(--tk-a); outline-offset: 2px; }
.tk-switch::after { content: ''; position: absolute; top: 2.5px; left: 2.5px; width: 14px; height: 14px; border-radius: 50%;
  background: var(--tk-on-accent); box-shadow: 0 1px 3px rgba(0,0,0,.35); transition: transform var(--bt-dur) var(--bt-ease); }
.tk-switch-on { background: var(--tk-grad); }
.tk-switch-on::after { transform: translateX(15px); }
/* 开关语义：虚线描边透明面（§6 不嵌套卡片底色），两段说明 */
.tk-sem { border: 1px dashed var(--tk-line); border-radius: 12px; padding: 13px 16px;
  font-size: 12px; color: var(--tk-mut); line-height: 1.7; display: flex; flex-direction: column; gap: 8px; }
.tk-sem p { margin: 0; }
.bt-note { font-size: 12px; color: var(--bt-mut); line-height: 1.6; border-left: 2px solid var(--bt-line);
  padding-left: 10px; }
.bt-note summary { cursor: pointer; user-select: none; list-style: none; display: flex; align-items: center; gap: 6px; }
.bt-note summary::-webkit-details-marker { display: none; }
.bt-note summary::before { content: '▸'; font-size: 10px; transition: transform var(--bt-dur) var(--bt-ease); }
.bt-note[open] summary::before { transform: rotate(90deg); }
.bt-note-body { margin-top: 6px; }
/* 窄容器（侧栏收窄）：矩阵行收掉会话数列，避免挤压换行（命令网格走 auto-fill 自然单列）；规则见文末 @container */
/* 来源筛选 chips：全部/各家/只看新卡，pill 基座 + 选中态品牌描边 */
.bt-chips { display: flex; flex-wrap: wrap; gap: 6px 8px; margin: 2px 0 8px; }
.bt-chip { display: inline-flex; align-items: center; gap: 6px; cursor: pointer;  border: 1px solid var(--bt-line); border-radius: 999px; padding: 3px 12px;
  background: transparent; color: var(--bt-mut); font-size: 11px; font-weight: 500;
  font-variant-numeric: tabular-nums;
  transition: border-color var(--bt-dur) var(--bt-ease), color var(--bt-dur) var(--bt-ease), background var(--bt-dur) var(--bt-ease); }
.bt-chip:hover { border-color: var(--bt-a); color: var(--bt-a); }
.bt-chip-on { color: var(--bt-a-text); background: rgba(99,102,241,.12);
  border-color: rgba(99,102,241,.45); font-weight: 600; }
.bt-chip-count { font-size: 10px; opacity: .75; }
/* chips 内品牌图标（来源筛选 / 接收方选择 / 外部会话浏览器 pills 同款） */
.bt-chip svg { width: 13px; height: 13px; display: block; }
/* 外部会话浏览器：行 + 预览展开体。接管/寄存一键投递——面板不产卡，
 * 蒸馏都在会话里由模型完成（卡片质量跟模型能力走）。
 * 样式：主操作「接管」有主按钮权重；动作按钮定宽防状态文案切换跳动；
 * chips 与按钮补键盘焦点环。 */
/* primary 按钮（§4/§6）：品牌渐变底 + on-accent 文字 + 品牌投影 --tk-glow（原型 tk-btn.primary 同法）；
   悬浮只提亮（brightness）不换色，基类 hover 的描边/文字换色在此覆盖；全部走 --tk-* token */
.bt-btn-primary { color: var(--tk-on-accent); border-color: transparent; background: var(--tk-grad); font-weight: 600;
  box-shadow: var(--tk-glow); transition: filter var(--bt-dur) var(--bt-ease), transform var(--bt-dur) var(--bt-ease); }
.bt-btn-primary:not(:disabled):hover { background: var(--tk-grad); border-color: transparent; color: var(--tk-on-accent);
  filter: brightness(1.12); transform: translateY(-1px); }
.bt-fsess-act .bt-btn-xs { min-width: 4.5em; }
.bt-chip:focus-visible, .bt-btn:focus-visible { outline: 2px solid var(--bt-a); outline-offset: 2px; }
.bt-chip-off { opacity: .4; }
.bt-chip-off:hover { border-color: var(--bt-line); color: var(--bt-mut); }
.bt-btn-xs { font-size: 11px; padding: 2px 8px; border-radius: 8px; }
.bt-fsess { min-width: 0; border: 1px solid var(--bt-line); border-radius: 10px; padding: 7px 10px; margin-bottom: 6px; background: var(--bt-card); }
.bt-fsess-line1 { display: flex; gap: 8px; align-items: baseline; }
.bt-fsess-title { flex: 1; min-width: 0; font-size: 13px; font-weight: 600; overflow: hidden;
  text-overflow: ellipsis; white-space: nowrap; cursor: pointer; border-radius: 4px; }
.bt-fsess-title:hover { color: var(--bt-a); }
.bt-fsess-title:focus-visible { outline: 2px solid var(--bt-a); outline-offset: 2px; }
.bt-fsess-time { flex: none; font-size: 11px; color: var(--bt-mut); font-variant-numeric: tabular-nums; }
.bt-fsess-line2 { display: flex; gap: 8px; align-items: center; margin-top: 4px; }
.bt-fsess-src { display: inline-flex; align-items: center; gap: 5px; flex: none; max-width: 32%;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 11px; font-weight: 600; }
.bt-fsess-src svg { flex: none; }
.bt-fsess-id { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  font-size: 11px; color: var(--bt-mut); cursor: pointer; font-variant-numeric: tabular-nums; }
.bt-fsess-id:hover { color: var(--bt-a); }
.bt-fsess-id:focus-visible { outline: 2px solid var(--bt-a); outline-offset: 2px; }
.bt-fsess-act { flex: none; display: flex; gap: 4px; }
.bt-fsprev { margin-top: 7px; padding-top: 7px; border-top: 1px dashed var(--bt-line); display: grid;
  gap: 3px; font-size: 11px; }
.bt-fsprev-line { display: flex; gap: 6px; min-width: 0; }
.bt-fsprev-label { flex: none; color: var(--bt-mut); }
.bt-fsprev-text { min-width: 0; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 3;
  -webkit-box-orient: vertical; word-break: break-word; }
.bt-fsprev-warn { color: var(--bt-warn); }
.bt-fs-empty { padding: 8px 2px; }
.bt-fs-count { margin: 8px 0 6px; }
/* 骨架屏（E 批）：state 未到位时收件箱概览的占位——3 条脉冲条替代「加载」纯文字，
   脉冲只动 opacity（不触发布局），宽差 100/70/45% 由行内样式给 */
.bt-skeleton { height: 12px; border-radius: 6px; background: var(--bt-hover);
  animation: bt-pulse var(--bt-pulse-dur) var(--bt-ease) infinite; }
@keyframes bt-pulse { 0%, 100% { opacity: 1; } 50% { opacity: .4; } }
/* 动效降级：系统声明减少动效时，脉冲/强调条展开全部停用（全仓首批 @keyframes 的守卫） */
@media (prefers-reduced-motion: reduce) {
  .bt-skeleton { animation: none; opacity: .55; }
  .bt-pending-unread::before { animation: none; }
}
@container (max-width: 430px) {
  .bt-fsess-act { flex-wrap: wrap; }
}
@container (max-width: 430px) {
  .tk-mxr { grid-template-columns: minmax(0, auto) auto auto; }
  .tk-mstat { display: none; }
}
`

// ---------------------------------------------------------------------------
// 数据获取
// ---------------------------------------------------------------------------

async function getState(): Promise<TakeoverState> {
  const res = await fetch('/dsh-takeover/state', { cache: 'no-store' })
  const body = await res.json() as TakeoverState | { error: string }
  if (!res.ok || 'error' in body) throw new Error('error' in body ? body.error : `HTTP ${res.status}`)
  return body
}

async function post<T extends object>(path: string, body: unknown): Promise<T> {
  const res = await fetch(path, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  })
  const data = await res.json() as T | { error: string }
  if (!res.ok || 'error' in data) throw new Error('error' in data ? data.error : `HTTP ${res.status}`)
  return data
}

/** GET JSON：HTTP 层错误抛出（错误文案优先取响应体 error 字段）；业务面 ok:false 由调用方窄化 */
async function getJson<T>(url: string): Promise<T> {
  const res = await fetch(url, { cache: 'no-store' })
  if (!res.ok) {
    let msg = `HTTP ${res.status}`
    try {
      const b = await res.json() as { error?: string }
      if (typeof b.error === 'string' && b.error !== '') msg = b.error
    } catch { /* 无响应体则保留 HTTP 状态文案 */ }
    throw new Error(msg)
  }
  return await res.json() as T
}

/** 复制到剪贴板：Clipboard API 优先（需安全上下文——面板在 localhost 恒满足），
 * 不可得退 textarea+execCommand。异常上抛，由调用方进错误横幅。 */
function copyText(text: string): Promise<void> {
  const nav: { clipboard?: { writeText?: (t: string) => Promise<void> } } | undefined = globalThis.navigator
  if (nav?.clipboard?.writeText !== undefined) return nav.clipboard.writeText(text)
  return new Promise((resolve, reject) => {
    try {
      const ta = document.createElement('textarea')
      ta.value = text
      ta.style.position = 'fixed'
      ta.style.opacity = '0'
      document.body.appendChild(ta)
      ta.select()
      const ok = document.execCommand('copy')
      ta.remove()
      if (ok) resolve()
      else reject(new Error('execCommand copy failed'))
    } catch (e) { reject(e) }
  })
}

function fmtTime(iso: string, lang: Lang): string {
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso
  const pad = (n: number): string => String(n).padStart(2, '0')
  const hm = `${pad(d.getHours())}:${pad(d.getMinutes())}`
  const now = new Date()
  const sameDay = d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() && d.getDate() === now.getDate()
  if (sameDay) return hm // 今天的只给时刻，别把行撑长
  return lang === 'en'
    ? `${d.getMonth() + 1}/${d.getDate()} ${hm}`
    : `${d.getMonth() + 1}月${d.getDate()}日 ${hm}`
}

/**
 * 防御式取 localStorage：隐私模式 / 禁写（SecurityError、quota）回 null，
 * 已见集合退化为仅本会话记住（纯内存），徽标语义仍在，卡片不塌。
 * 探测一次真实读写——拿到引用不代表能写（Safari 隐私模式的老坑）。
 */
function safeLocalStorage(): SeenStore | null {
  try {
    const s: unknown = globalThis.localStorage
    if (s === null || typeof s !== 'object') return null
    const store = s as SeenStore
    const probe = '__dsh_takeover_probe__'
    store.setItem(probe, probe)
    store.removeItem(probe)
    return store
  } catch {
    return null
  }
}

/** Blob 下载：零依赖（URL.createObjectURL + 隐形 <a> 点击）；异常由调用方进错误横幅。
 * mime 由调用方给：.md 走 text/markdown，HTML 报告走 text/html。 */
function downloadText(filename: string, text: string, mime = 'text/markdown;charset=utf-8'): void {
  const blob = new Blob([text], { type: mime })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  window.setTimeout(() => { URL.revokeObjectURL(url) }, 1_000)
}

/** 导出文件名的时间戳尾巴：handoff-pending-20261003-1215.md */
function exportStamp(d = new Date()): string {
  const pad = (n: number): string => String(n).padStart(2, '0')
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}`
}

// ---------------------------------------------------------------------------
// host 侧并行落地字段的防御式读取（0.3.2 预留位）
// 字段由 host 半（settings.ts/tools.ts，另一条工作线）稍后落地；客户端约定两处
// 落点：state.extras.* 优先、顶层 * 兜底。任一都不在或形态不符 → null，
// 对应整行/徽标不渲染——宁可少显示，不硬造。
// ---------------------------------------------------------------------------

/** 非负有限数才算计数（信封字符数 / coverage 计数）；NaN、负数、字符串数字不认 */
function isCount(v: unknown): v is number {
  return typeof v === 'number' && Number.isFinite(v) && v >= 0
}

/** state.extras 防御式取对象：host 侧未落地 / 形态漂移一律回空对象 */
function extrasOf(state: TakeoverState): Record<string, unknown> {
  const v: unknown = (state as unknown as Record<string, unknown>).extras
  return v !== null && typeof v === 'object' ? (v as Record<string, unknown>) : {}
}

/**
 * 机器信封字符数。host 半真实契约（src/tools.ts InboxLoadResult）：
 * envelopeChars?: number（随卡消费的机器信封 JSON 字符数）。state 侧落地位置
 * 未定稿前两处都探：extras.envelopeChars / envelopeChars，另容 envelope: { chars }
 * 对象形态。全不在 → null（「机器信封已随卡归档」整行不显示）。
 */
/** 死亡地图事件总数：读侧活性跳过 + 持久事件总数（0.4.1 拒收徽标） */
export function rejectionCount(state: TakeoverState | null): number {
  const r = state?.rejections
  if (!r) return 0
  return r.live.length + (r.persistedTotal || 0)
}

/** 拒收徽标的悬浮明细：按阶段聚合（写/读/取），最多列 6 条，不落卡正文 */
export function rejectionTitle(state: TakeoverState | null): string {
  const r = state?.rejections
  if (!r) return ''
  const byStage = new Map<string, number>()
  for (const e of r.persisted) byStage.set(`${e.stage}/${e.reason}`, (byStage.get(`${e.stage}/${e.reason}`) ?? 0) + 1)
  for (const l of r.live) byStage.set(`read/${l.reason}`, (byStage.get(`read/${l.reason}`) ?? 0) + 1)
  const parts = [...byStage.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6).map(([k, n]) => `${k}×${n}`)
  return parts.join('、')
}

export function envelopeCharsOf(state: TakeoverState): number | null {
  const top = state as unknown as Record<string, unknown>
  const extra = extrasOf(state)
  for (const c of [extra.envelopeChars, top.envelopeChars]) {
    if (isCount(c)) return c
  }
  for (const env of [extra.envelope, top.envelope]) {
    if (env !== null && typeof env === 'object') {
      const chars: unknown = (env as Record<string, unknown>).chars
      if (isCount(chars)) return chars
    }
  }
  return null
}

/**
 * 四态覆盖率徽标文本（extras.coverage 优先、顶层 coverage 兜底——extras.coverage
 * 即 host 半 coverageFromExtras 的取数位，src/tools.ts CoverageStats）：
 * - 对象形态认真实契约 { statements, marked, unmarked }（三字段齐且全为非负数），
 *   出 "marked/statements"，与工具侧 renderCoverageLine 的 x/y 口径一致；
 * - 字符串形态（如 "3/8"）trim 后非空即原样展示；
 * - 兜底对象形态 { done, total }（x / y 字面键再兜一层）拼成 "x/y"。
 * 全不在/形态不符 → null（徽标位整体不渲染）。
 */
export function coverageTextOf(state: TakeoverState): string | null {
  const top = state as unknown as Record<string, unknown>
  const extra = extrasOf(state)
  for (const c of [extra.coverage, top.coverage]) {
    if (typeof c === 'string') {
      const s = c.trim()
      if (s !== '') return s
    } else if (c !== null && typeof c === 'object') {
      const o = c as Record<string, unknown>
      if (isCount(o.statements) && isCount(o.marked) && isCount(o.unmarked)) {
        return `${o.marked}/${o.statements}`
      }
      const x = isCount(o.done) ? o.done : isCount(o.x) ? o.x : null
      const y = isCount(o.total) ? o.total : isCount(o.y) ? o.y : null
      if (x !== null && y !== null) return `${x}/${y}`
    }
  }
  return null
}

// ---------------------------------------------------------------------------
// HTML 单文件报告导出（对齐 对标 Claude Code /export 需求）。
// state→html 是可导出纯函数：单测直接喂 state + 双语词典 + 固定时刻，无 DOM。
// 诚实纪律：内容仅来自 state 真有字段（pending 全卡 / 九家矩阵 / archived 计数 /
// pendingSkipped / inboxError），不硬造；卡片标题与预览是模型生成文本，进 HTML
// 前一律过 escHtml——自包含单文件没有 CSP 兜底，转义是唯一防线。
// ---------------------------------------------------------------------------

/** HTML 文本转义：& < > " ' 全量，任何 state 来的字符串进模板前必须过这里 */
function escHtml(v: string): string {
  return v
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

/** 报告里的绝对时间：解析失败原样返回（诚实优于臆造）；成功给本地 YYYY-MM-DD HH:mm */
function absTime(iso: string): string {
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso
  const pad = (n: number): string => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`
}

/** 报告文案包（调用方按语言现配，本函数保持无 i18n 依赖——同 inbox-view 的 ExportNotes 纪律） */
export interface ReportWords {
  title: string
  subtitle: string
  /** 「生成于 {n}」模板，{n} 由 buildReportHtml 代入 */
  generated: string
  /** 顶部边界说明：内容仅来自 state，完整卡片回会话 /inbox 取 */
  note: string
  statPending: string
  statArchived: string
  statProviders: string
  sectionInbox: string
  sectionMatrix: string
  pendingEmpty: string
  /** 「另有 {n} 张无法解析的卡片被跳过」模板 */
  skipped: string
  labelFrom: string
  labelProject: string
  labelTime: string
  labelPreview: string
  previewEmpty: string
  /** 矩阵行：会话数 / 探测失败 / 不支持 / 启用状态 */
  sessionsCount: string
  sessionsProbeFail: string
  unsupported: string
  unsupportedNote: string
  pillOk: string
  pillNo: string
  disabled: string
  /** 来源为空时的兜底显示名（host 侧 0.4.0 起下发空串） */
  unknownSource: string
}

/** 从本卡词典组装报告文案包（zh/en 全量对齐，漏译在 tests/locales.spec.ts 拦下） */
export function reportWords(lang: Lang): ReportWords {
  const d = DICTS[lang]
  const w = (key: string): string => d[key] ?? key
  return {
    title: w('reportTitle'),
    subtitle: w('reportSubtitle'),
    generated: w('reportGenerated'),
    note: w('reportNote'),
    statPending: w('reportStatPending'),
    statArchived: w('reportStatArchived'),
    statProviders: w('reportStatProviders'),
    sectionInbox: w('inboxTitle'),
    sectionMatrix: w('matrixTitle'),
    pendingEmpty: w('reportPendingEmpty'),
    skipped: w('reportSkipped'),
    labelFrom: w('reportLabelFrom'),
    labelProject: w('reportLabelProject'),
    labelTime: w('reportLabelTime'),
    labelPreview: w('reportLabelPreview'),
    previewEmpty: w('previewEmpty'),
    sessionsCount: w('sessionsCount'),
    sessionsProbeFail: w('sessionsProbeFail'),
    unsupported: w('unsupported'),
    unsupportedNote: w('unsupportedNote'),
    pillOk: w('pillOk'),
    pillNo: w('pillNo'),
    disabled: w('reportDisabled'),
    unknownSource: w('unknownSource'),
  }
}

/** 报告样式：内联进单文件（自包含、离线可开）；品牌渐变头 #6366F1→#8B5CF6 */
const REPORT_CSS = `
:root { color-scheme: light; }
* { box-sizing: border-box; }
body { margin: 0; background: #f4f5fb; color: #1e293b;
  font: 14px/1.65 system-ui, -apple-system, 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif; }
.rt-hero { background: linear-gradient(135deg, #6366F1, #8B5CF6); color: #fff; padding: 34px 28px 28px; }
.rt-hero h1 { margin: 0; font-size: 22px; letter-spacing: .01em; overflow-wrap: anywhere; }
.rt-sub { margin: 6px 0 0; font-size: 13.5px; opacity: .85; }
.rt-meta { margin: 14px 0 0; font-size: 12px; opacity: .78; }
.rt-main { max-width: 860px; margin: 0 auto; padding: 22px 20px 8px; display: flex; flex-direction: column; gap: 16px; }
.rt-stats { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; }
.rt-stat { background: #fff; border: 1px solid rgba(99,102,241,.18); border-radius: 12px; padding: 14px 16px;
  display: flex; flex-direction: column; gap: 2px; box-shadow: 0 1px 2px rgba(30,41,59,.06); }
.rt-stat-n { font-size: 24px; font-weight: 700; color: #4f46e5; }
.rt-stat-label { font-size: 12px; color: #64748b; }
.rt-note { margin: 0; font-size: 12px; line-height: 1.7; color: #64748b; background: rgba(99,102,241,.06);
  border: 1px solid rgba(99,102,241,.16); border-radius: 10px; padding: 10px 14px; }
.rt-card { background: #fff; border: 1px solid rgba(30,41,59,.08); border-radius: 12px; padding: 16px 18px; }
.rt-card h2 { margin: 0 0 12px; font-size: 15px; color: #312e81; }
.rt-empty { color: #64748b; font-size: 13px; background: rgba(127,127,127,.07); border-radius: 8px; padding: 12px 14px; }
.rt-warn { color: #b45309; font-size: 12.5px; line-height: 1.6; background: rgba(251,191,36,.13);
  border-radius: 8px; padding: 10px 14px; margin: 0 0 10px; overflow-wrap: anywhere; }
.rt-pcard { border: 1px solid rgba(30,41,59,.08); border-radius: 10px; padding: 12px 14px; }
.rt-pcard + .rt-pcard { margin-top: 10px; }
.rt-ptitle { margin: 0 0 4px; font-weight: 600; font-size: 14px; overflow-wrap: anywhere; }
.rt-pid { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 11px;
  font-weight: 500; color: #6366F1; background: rgba(99,102,241,.08); border-radius: 6px; padding: 1px 7px; margin-left: 6px; }
.rt-pmeta { margin: 0 0 8px; font-size: 12px; color: #64748b; display: flex; flex-wrap: wrap; gap: 2px 14px; }
.rt-plabel { font-size: 11px; opacity: .82; margin-right: 3px; }
.rt-preview { margin-top: 2px; padding: 8px 12px; border-left: 3px solid #6366F1; background: #f8f9ff;
  border-radius: 0 8px 8px 0; }
.rt-preview-body { font-size: 12.5px; white-space: pre-wrap; overflow-wrap: anywhere; }
.rt-mrow { display: flex; flex-wrap: wrap; align-items: baseline; gap: 4px 10px; padding: 7px 2px;
  border-bottom: 1px dashed rgba(30,41,59,.1); font-size: 13px; }
.rt-mrow:last-child { border-bottom: none; }
.rt-mrow-off { opacity: .55; }
.rt-mname { font-weight: 600; min-width: 140px; }
.rt-mid { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 11px; color: #94a3b8; }
.rt-pill { font-size: 11px; font-weight: 600; border-radius: 999px; padding: 1px 10px; white-space: nowrap; }
.rt-pill-ok { color: #15803d; background: rgba(21,128,61,.1); border: 1px solid rgba(21,128,61,.35); }
.rt-pill-no { color: #b45309; background: rgba(180,83,9,.1); border: 1px solid rgba(180,83,9,.35); }
.rt-mstat { color: #64748b; font-size: 12px; }
.rt-mnote { flex-basis: 100%; color: #b45309; font-size: 11px; line-height: 1.55; overflow-wrap: anywhere; }
.rt-foot { text-align: center; color: #94a3b8; font-size: 11.5px; padding: 14px 0 30px; }
@media (max-width: 560px) { .rt-stats { grid-template-columns: 1fr; } }
`

/**
 * state → 自包含 HTML 报告（纯函数，无 DOM / 无 i18n / 无时钟依赖）：
 * - generatedAt 由调用方给定（展示与 <title> 用；文件名时间戳在调用方拼），
 *   单测喂固定串即可逐字断言；
 * - 内容面：头部品牌渐变 + 三张统计卡（待取件 / 已消费 / 读取器已启用-总数）+
 *   边界说明 + 收件箱全卡（空态出横幅；inboxError / pendingSkipped 诚实浮出）+
 *   九家支持矩阵（启用与否、支持 pill、会话数、note 浮出）。
 */
export function buildReportHtml(
  state: TakeoverState,
  words: ReportWords,
  lang: Lang,
  generatedAt: string,
): string {
  const esc = escHtml
  const enabled = state.providers.filter((p) => p.enabled).length

  const statCards =
    `<div class="rt-stat"><span class="rt-stat-n">${state.pending.length}</span>` +
    `<span class="rt-stat-label">${esc(words.statPending)}</span></div>` +
    `<div class="rt-stat"><span class="rt-stat-n">${state.archivedCount}</span>` +
    `<span class="rt-stat-label">${esc(words.statArchived)}</span></div>` +
    `<div class="rt-stat"><span class="rt-stat-n">${enabled}/${state.providers.length}</span>` +
    `<span class="rt-stat-label">${esc(words.statProviders)}</span></div>`

  // 收件箱诚实浮出：概览不可用 / 坏卡跳过——只转述 state 给的原文，不粉饰成「为空」
  const inboxFlags =
    (state.inboxError !== undefined && state.inboxError !== ''
      ? `<div class="rt-warn">${esc(state.inboxError)}</div>`
      : '') +
    (state.pendingSkipped > 0
      ? `<div class="rt-warn">${esc(interpolate(words.skipped, { n: state.pendingSkipped }))}</div>`
      : '')

  const pendingCards = state.pending.map((p) => {
    const title = displayTitleOf(p)
    const idChip = `<span class="rt-pid">${esc(p.id)}</span>`
    const project = p.project !== ''
      ? `<span><span class="rt-plabel">${esc(words.labelProject)}</span>${esc(p.project)}</span>`
      : ''
    const previewBody = p.preview !== '' ? p.preview : words.previewEmpty
    return `<div class="rt-pcard">` +
      `<p class="rt-ptitle">${esc(title)}${idChip}</p>` +
      `<p class="rt-pmeta">` +
      `<span><span class="rt-plabel">${esc(words.labelFrom)}</span>${esc(PROVIDER_LABEL[p.agent] ?? (p.agent === '' ? words.unknownSource : p.agent))}</span>` +
      project +
      `<span><span class="rt-plabel">${esc(words.labelTime)}</span>${esc(absTime(p.pushedAt))}</span>` +
      `</p>` +
      `<div class="rt-preview"><span class="rt-plabel">${esc(words.labelPreview)}</span>` +
      `<div class="rt-preview-body">${esc(previewBody)}</div></div>` +
      `</div>`
  }).join('')

  const inboxBody = state.pending.length === 0
    ? `<div class="rt-empty">${esc(words.pendingEmpty)}</div>`
    : pendingCards

  const matrixRows = state.providers.map((r) => {
    const label = PROVIDER_LABEL[r.name] ?? r.name
    const stat = r.supported
      ? (r.sessions >= 0 ? interpolate(words.sessionsCount, { n: r.sessions }) : words.sessionsProbeFail)
      : (r.note !== '' ? interpolate(words.unsupportedNote, { note: r.note }) : words.unsupported)
    // 假 0 哨兵浮出与设置卡同口径：supported 且 note 非空才浮出
    const note = r.supported && r.note !== '' ? `<span class="rt-mnote">${esc(r.note)}</span>` : ''
    return `<div class="rt-mrow${r.enabled ? '' : ' rt-mrow-off'}">` +
      `<span class="rt-mname">${esc(label)}</span>` +
      `<span class="rt-mid">${esc(r.name)}</span>` +
      `<span class="rt-pill ${r.supported ? 'rt-pill-ok' : 'rt-pill-no'}">${esc(r.supported ? words.pillOk : words.pillNo)}</span>` +
      `<span class="rt-mstat">${esc(stat)}${r.enabled ? '' : ` · ${esc(words.disabled)}`}</span>` +
      note +
      `</div>`
  }).join('')

  return `<!DOCTYPE html>
<html lang="${lang}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(words.title)} · ${esc(generatedAt)}</title>
<style>${REPORT_CSS}</style>
</head>
<body>
<header class="rt-hero">
<h1>${esc(words.title)}</h1>
<p class="rt-sub">${esc(words.subtitle)}</p>
<p class="rt-meta">${esc(interpolate(words.generated, { n: generatedAt }))} · dsh-takeover</p>
</header>
<main class="rt-main">
<div class="rt-stats">${statCards}</div>
<p class="rt-note">${esc(words.note)}</p>
<section class="rt-card">
<h2>${esc(words.sectionInbox)}</h2>
${inboxFlags}
${inboxBody}
</section>
<section class="rt-card">
<h2>${esc(words.sectionMatrix)}</h2>
${matrixRows}
</section>
</main>
<footer class="rt-foot">dsh-takeover · handoff: 1</footer>
</body>
</html>
`
}

// ---------------------------------------------------------------------------
// 展示件
// ---------------------------------------------------------------------------

export function PendingList({ rows, query, home, t, lang, onExport, onChainFilter, onTakeInbox, takeBusyId, onDismiss, dismissBusyId }: {
  rows: PendingRow[]
  query: string
  /** 解析后的 HANDOFF_HOME（state.home）：已见集合 localStorage 键的散列源 */
  home: string
  t: Translate
  lang: Lang
  /** 单卡导出（展开态「导出 .md」按钮），下载逻辑在 Panel */
  onExport: (p: PendingRow) => void
  /** 按接力链过滤（把查询词设为前置卡 id） */
  onChainFilter: (id: string) => void
  /** 一键取件（新建会话投递 /inbox，带卡 id 定向取件），投递态在 Panel */
  onTakeInbox: (p: PendingRow) => void
  /** 正在投递的卡 id（按行显示投递中，其余行仅 disabled） */
  takeBusyId: string | null
  /** 忽略这张卡（原样移入 archived/，审计保留不计消费） */
  onDismiss: (p: PendingRow) => void
  /** 正在忽略的卡 id（按行显示忽略中） */
  dismissBusyId: string | null
}): ReturnType<typeof createElement> {
  // 已见集合：localStorage 按 HANDOFF_HOME 散列分键；打开过（展开过）即记为已见。
  // 存储不可写时退化为仅本会话记住（loadSeenSet/saveSeenSet 全程不抛）。
  const [store] = useState(safeLocalStorage)
  const [seen, setSeen] = useState<Set<string>>(() => loadSeenSet(store, seenStorageKey(home)))
  const [openIds, setOpenIds] = useState<Set<string>>(new Set())
  // HANDOFF_HOME 变更（服务端换目录/换机器）→ 键变，已见集随之重载
  useEffect(() => { setSeen(loadSeenSet(store, seenStorageKey(home))) }, [store, home])

  const markSeen = (ids: readonly string[]): void => {
    setSeen((prev) => {
      const fresh = ids.filter((id) => !prev.has(id))
      if (fresh.length === 0) return prev
      const next = new Set(prev)
      for (const id of fresh) next.add(id)
      // 副作用（localStorage 持久化）在 updater 外做：updater 须为纯函数
      queueMicrotask(() => saveSeenSet(store, seenStorageKey(home), next))
      return next
    })
  }
  const toggleOpen = (id: string): void => {
    setOpenIds((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
    markSeen([id]) // 打开过即记为已见，「新」徽标随之消失
  }
  const toggleGroup = (g: PendingGroup): void => {
    const willOpen = !openIds.has(g.key)
    setOpenIds((prev) => {
      const next = new Set(prev)
      if (next.has(g.key)) next.delete(g.key)
      else next.add(g.key)
      return next
    })
    // 组头展开即整组可见：全部成员一并记为已见（同一 openIds 机制，键是组 key）
    if (willOpen) markSeen(g.rows.map((r) => r.id))
  }

  // 来源筛选 + 只看新卡：收件箱自持的筛选状态（重开设置卡即重置，轻量符合直觉）
  const [sourceSel, setSourceSel] = useState<string | null>(null)
  const [newOnly, setNewOnly] = useState(false)

  // 先滤（来源 → 只看新卡 → 文本）后组：过滤改变可见序列，「相邻」在滤后的列表上判定。
  // 空壳卡分离成「低信息」次级组（默认折叠）——主列表只留实质工作卡（Linear/Gmail 范式）
  const newIds = new Set(newIdsOf(rows, seen))
  // 「只看新卡」下展开的行不因记已见而消失：展开 = 正在分诊，收起才算分诊完成
  // （否则行在点击瞬间蒸发，详情永远看不到——0.4.3 复验实测的交互回归）
  const newOrOpen = new Set([...newIds, ...openIds])
  const visible = filterPending(
    rows,
    query,
    (a) => PROVIDER_LABEL[a] ?? (a === '' ? t('unknownSource') : a),
    sourceSel,
    newOnly ? newOrOpen : null,
  )
  const lowRows = visible.filter((r) => r.lowInfo === true)
  const mainRows = visible.filter((r) => r.lowInfo !== true)
  const groups = groupAdjacent(mainRows)
  const facets = sourceFacets(rows)

  // 来源筛选 chips：全部 + 各家（带计数）。「只看新卡」不混进来源组——它是未读开关，
  // 独立成复选框行（aria 语义干净：来源组只管来源）
  const chip = (label: string, count: number, on: boolean, onClick: () => void, key: string): ReturnType<typeof createElement> =>
    createElement('button', {
      key,
      className: `bt-chip${on ? ' bt-chip-on' : ''}`,
      'aria-pressed': on,
      onClick,
      type: 'button',
    },
      createElement('span', { className: 'bt-chip-label' }, label),
      createElement('span', { className: 'bt-chip-count' }, String(count)),
    )
  // 来源显示名：host 侧空串回退（0.4.0 起不再下发中文字面量），由词典渲染兜底
  const agentLabel = (a: string): string => PROVIDER_LABEL[a] ?? (a === '' ? t('unknownSource') : a)
  const chipBar = createElement('div', { className: 'bt-chips', role: 'group', 'aria-label': t('chipSourceAria') },
    chip(t('chipAll'), rows.length, sourceSel === null, () => setSourceSel(null), 'chip-all'),
    ...facets.map((f) => chip(
      agentLabel(f.agent),
      f.count,
      sourceSel === f.agent,
      () => setSourceSel(sourceSel === f.agent ? null : f.agent),
      'chip-' + f.agent,
    )),
  )

  // 低信息次级组：可展开（与普通组同一 openIds 机制），组头带数量与「低信息」语义
  const lowInfoNode = (low: PendingRow[]): ReturnType<typeof createElement> => {
    const key = 'bt-lowinfo'
    const open = openIds.has(key)
    const hasNew = low.some((r) => !seen.has(r.id))
    const toggle = () => {
      setOpenIds((prev) => { const nx = new Set(prev); if (nx.has(key)) nx.delete(key); else nx.add(key); return nx })
      if (!open) markSeen(low.map((r) => r.id)) // 展开即整组记已见（与 toggleGroup 对齐——）
    }
    return createElement('div', { key, className: 'bt-group' },
      createElement('div', {
        className: `bt-pending${open ? ' bt-pending-open' : ''}`,
        role: 'button',
        tabIndex: 0,
        'aria-expanded': open,
        'aria-label': t('groupAria', { title: t('lowInfoGroup', { n: low.length }), n: low.length }),
        onClick: toggle,
        onKeyDown: (e: { key: string; preventDefault(): void }) => {
          if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle() }
        },
      },
        createElement('span', { className: 'bt-tag bt-tag-lowinfo' }, t('lowInfoBadge')),
        createElement('span', { className: 'bt-pending-title' }, t('lowInfoGroup', { n: low.length })),
        hasNew ? createElement('span', { className: 'bt-tag bt-tag-new' }, t('newBadge')) : null,
        createElement('span', { className: 'bt-pending-chev', 'aria-hidden': true }, '▸'),
      ),
      open ? low.map((r) => rowNode(r, true)) : null,
    )
  }

  const rowNode = (p: PendingRow, inGroup: boolean): ReturnType<typeof createElement> => {
    const open = openIds.has(p.id)
    const isNew = !seen.has(p.id)
    // 外层是中性容器：预览与「导出 .md」按钮必须是 role=button 行的**兄弟**节点——
    // 嵌套可交互元素违反 ARIA 禁则（stopPropagation 只解决事件，不解决语义）
    return createElement('div', { key: p.id, className: inGroup ? 'bt-pending-member' : undefined },
      createElement('div', {
      className: `bt-pending${open ? ' bt-pending-open' : ''}${isNew ? ' bt-pending-unread' : ''}`,
      title: p.id,
      role: 'button',
      tabIndex: 0,
      'aria-expanded': open,
      onClick: () => { toggleOpen(p.id) },
      onKeyDown: (e: { key: string; preventDefault(): void }) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggleOpen(p.id) }
      },
    },
      createElement('span', { className: 'bt-pend-icon' }, createElement(ProviderIcon, { name: p.agent, size: 22 })),
      createElement('span', { className: 'bt-pend-main' },
        createElement('span', { className: 'bt-pend-line1' },
          createElement('span', { className: 'bt-pending-title', title: p.id }, displayTitleOf(p)),
          // 未读态已由行首强调条表达；「新」徽标只留给 1 小时内的新卡（防满屏 amber 噪音）
          (isNew && Date.now() - Date.parse(p.pushedAt) < 3_600_000) ? createElement('span', { className: 'bt-tag bt-tag-new' }, t('newBadge')) : null,
          p.lowInfo === true ? createElement('span', { className: 'bt-tag bt-tag-lowinfo' }, t('lowInfoBadge')) : null,
          // 接力链徽标（展示位；过滤入口在展开态「只看此链」——行内不嵌交互，ARIA 禁则同前）
          p.supersedes !== undefined
            ? createElement('span', {
                className: 'bt-tag bt-tag-group',
                title: t('chainBadgeTitle', { id: p.supersedes }),
              }, t('chainBadge', { id: p.supersedes.length > 16 ? `${p.supersedes.slice(0, 16)}…` : p.supersedes }))
            : null,
          createElement('span', { className: 'bt-pend-time' }, p.pushedAt === '' ? t('noTime') : fmtTime(p.pushedAt, lang)),
        ),
        createElement('span', {
          className: 'bt-pend-meta',
          title: `${t('from', { name: '' }).trim()} · ${t('project', { name: '' }).trim()} · ${t('idLabel', { id: '' }).trim()}`,
        },
          createElement('span', { className: 'bt-pend-src' }, agentLabel(p.agent)),
          p.project !== '' ? createElement('span', { className: 'bt-pend-dot' }, '·') : null,
          p.project !== '' ? createElement('span', null, p.project) : null,
          createElement('span', { className: 'bt-pend-dot' }, '·'),
          createElement('span', { className: 'bt-pend-id' }, p.id),
        ),
      ),
      createElement('span', { className: 'bt-pending-chev', 'aria-hidden': true }, '▸'),
      ),
      open ? createElement('div', { className: 'bt-preview', onClick: (e: Event) => e.stopPropagation() },
        createElement('span', null, p.preview !== '' ? p.preview : t('previewEmpty')),
        createElement('span', { className: 'bt-preview-actions' },
          createElement('span', { className: 'bt-preview-hint' }, t('previewHint')),
          p.supersedes !== undefined
            ? createElement('button', {
                className: 'bt-btn',
                onClick: () => {
                  // 链过滤要同时清掉行内来源/新卡筛选，否则组合过滤出空列表
                  setSourceSel(null)
                  setNewOnly(false)
                  onChainFilter(p.supersedes as string)
                },
                title: t('chainFilterTitle', { id: p.supersedes }),
              }, t('chainFilterBtn'))
            : null,
          createElement('button', {
            className: 'bt-btn',
            disabled: takeBusyId !== null,
            onClick: () => { onTakeInbox(p) },
            title: t('inboxTakeTitle'),
          }, takeBusyId === p.id ? t('deliveringBtn') : t('inboxTakeBtn')),
          createElement('button', {
            className: 'bt-btn',
            onClick: () => { onExport(p) },
            title: t('exportCardTitle'),
          }, t('exportCard')),
          createElement('button', {
            className: 'bt-btn',
            disabled: dismissBusyId !== null,
            onClick: () => { onDismiss(p) },
            title: t('dismissTitle'),
          }, dismissBusyId === p.id ? t('dismissingBtn') : t('dismissBtn')),
        ),
      ) : null,
    )
  }

  const groupNode = (g: PendingGroup): ReturnType<typeof createElement> => {
    const open = openIds.has(g.key)
    const hasNew = g.rows.some((r) => !seen.has(r.id))
    const head = g.rows[0]
    return createElement('div', { key: g.key, className: 'bt-group' },
      createElement('div', {
        className: `bt-pending${open ? ' bt-pending-open' : ''}`,
        title: g.rows.map((r) => r.id).join(' · '),
        role: 'button',
        tabIndex: 0,
        'aria-expanded': open,
        'aria-label': t('groupAria', { title: g.title, n: g.rows.length }),
        onClick: () => { toggleGroup(g) },
        onKeyDown: (e: { key: string; preventDefault(): void }) => {
          if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggleGroup(g) }
        },
      },
        createElement('span', { className: 'bt-pend-icon' }, createElement(ProviderIcon, { name: g.agent, size: 22 })),
        createElement('span', { className: 'bt-pend-main' },
          createElement('span', { className: 'bt-pend-line1' },
            createElement('span', { className: 'bt-pending-title' }, g.title),
            createElement('span', { className: 'bt-tag bt-tag-group' }, t('groupCount', { n: g.rows.length })),
            hasNew ? createElement('span', { className: 'bt-tag bt-tag-new' }, t('newBadge')) : null,
            head !== undefined
              ? createElement('span', { className: 'bt-pend-time' }, head.pushedAt === '' ? t('noTime') : fmtTime(head.pushedAt, lang))
              : null,
          ),
          createElement('span', {
            className: 'bt-pend-meta',
            title: t('from', { name: '' }).trim(),
          },
            createElement('span', { className: 'bt-pend-src' }, agentLabel(g.agent)),
          ),
        ),
        createElement('span', { className: 'bt-pending-chev', 'aria-hidden': true }, '▸'),
      ),
      open ? g.rows.map((r) => rowNode(r, true)) : null,
    )
  }

  return createElement('div', { className: 'bt-rows' },
    // 筛选行：未读开关（复选框，独立语义）与来源 chips 同行排布——省一行竖向空间
    createElement('div', { className: 'bt-filterrow' },
      createElement('label', { className: 'bt-newonly' },
        createElement('input', {
          type: 'checkbox',
          checked: newOnly,
          'aria-label': t('newOnlyAria'),
          onChange: () => setNewOnly((v) => !v),
        }),
        createElement('span', null, t('newOnlyChip')),
        createElement('span', { className: 'bt-chip-count' }, String(newIds.size)),
      ),
      chipBar,
    ),
    rows.length === 0
      ? createElement('div', { className: 'bt-banner bt-banner-info' }, t('emptyInbox'))
      : visible.length === 0
        ? createElement('div', { className: 'bt-banner bt-banner-info' }, t('filterEmpty'))
        : mainRows.length === 0 && lowRows.length > 0
          ? lowInfoNode(lowRows)
          : [
              ...groups.map((g) => (g.rows.length > 1 ? groupNode(g) : rowNode(g.rows[0] as PendingRow, false))),
              lowRows.length > 0 ? lowInfoNode(lowRows) : null,
            ],
  )
}

export function ProviderMatrix({ rows, busy, onToggle, t }: {
  rows: ProviderRow[]
  busy: string | null
  onToggle: (name: string, enabled: boolean) => void
  t: Translate
}): ReturnType<typeof createElement> {
  return createElement('div', { className: 'tk-mx' },
    ...rows.map((r) => {
      const label = PROVIDER_LABEL[r.name] ?? r.name
      // 假 0 哨兵浮出：supported 且 note 非空（布局迁移提示等）→ 行内黄色小字 +
      // title 悬浮 + aria-describedby，三处同源；unsupported 行仍走 stat 列的 unsupportedNote
      const showNote = r.supported && r.note !== ''
      const noteId = `bt-mnote-${r.name}`
      // 状态 pill（DESIGN.md §2 三色纪律，§4 文案闭集）：
      //   绿「支持」= 可用且发现了会话；
      //   黄「待确认」= 目录存在但 0 会话（假 0 哨兵：sessions===0 且 note 非空）或会话数探测失败（<0，低信息）；
      //   黄「不可用」= 本机不支持。
      // 灰行（idle）只给「本机未装/暂无会话」（0 会话且无哨兵）与不支持行——待确认行保持全亮，黄 pill 第一眼可辨
      const pending = r.supported && ((r.sessions === 0 && r.note !== '') || r.sessions < 0)
      const idle = !r.supported || (r.sessions === 0 && r.note === '')
      const pillClass = r.supported && !pending ? 'tk-pill tk-pill-ok' : 'tk-pill tk-pill-warn'
      const pillText = !r.supported ? t('pillNo') : pending ? t('pillPending') : t('pillOk')
      return createElement('div', {
        key: r.name,
        className: `tk-mxr${idle ? ' tk-mxr-idle' : ''}`,
        title: r.note !== '' ? r.note : undefined,
        // aria-description 不是有效 ARIA 属性（读屏不识别）——改 aria-describedby 指向可见 note 节点
        'aria-describedby': showNote ? noteId : undefined,
      },
        createElement('span', { className: 'tk-mname-col' },
          createElement('span', { className: 'tk-mname-wrap' },
            createElement(ProviderIcon, { name: r.name }),
            createElement('span', { className: 'tk-mname' }, label),
            createElement('span', { className: 'tk-mid' }, r.name),
          ),
          showNote ? createElement('span', { className: 'tk-mnote', id: noteId }, r.note) : null,
        ),
        createElement('span', { className: 'tk-mstat' },
          r.supported
            ? (r.sessions >= 0 ? t('sessionsCount', { n: r.sessions }) : t('sessionsProbeFail'))
            : (r.note !== '' ? t('unsupportedNote', { note: r.note }) : t('unsupported'))),
        createElement('span', { className: pillClass }, pillText),
        createElement('button', {
          className: `tk-switch${r.enabled ? ' tk-switch-on' : ''}`,
          type: 'button',
          role: 'switch',
          'aria-checked': r.enabled,
          'aria-label': t('toggleAria', { label, id: r.name }),
          disabled: busy !== null,
          title: r.enabled ? t('toggleDisable', { label }) : t('toggleEnable', { label }),
          onClick: () => { onToggle(r.name, !r.enabled) },
        }),
      )
    }),
  )
}

// ---------------------------------------------------------------------------
// 交接出去（outbound）+ 记忆快照：右栏新增两卡。与 ForeignBrowser 同层。
// ---------------------------------------------------------------------------

/** 接收方 chips：交接出去与记忆快照共用（任意 agent + 九家） */
export function TargetChips({ sel, lang, onSelect, ariaLabel }: {
  sel: string
  lang: Lang
  onSelect: (t: OutboundTarget) => void
  ariaLabel?: string
}): ReturnType<typeof createElement> {
  return createElement('div', { className: 'bt-chips', role: 'group', 'aria-label': ariaLabel, style: { marginTop: 8 } },
    ...OUTBOUND_TARGETS.map((tg) => createElement('button', {
      key: tg,
      className: `bt-chip${sel === tg ? ' bt-chip-on' : ''}`,
      'aria-pressed': sel === tg,
      type: 'button',
      onClick: () => onSelect(tg),
    },
      // 与左侧来源 pills 同款品牌图标——「交接给谁」不再是裸文字钮（any 用本插件品牌小标）
      tg === 'any'
        ? createElement('span', { className: 'bt-icon', style: { width: 13, height: 13, background: 'linear-gradient(135deg, #6366F1, #8B5CF6)' }, dangerouslySetInnerHTML: { __html: '<svg viewBox="0 0 64 64" width="100%" height="100%"><g fill="none" stroke="#fff" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"><path d="M15 19 L27 32 L15 45"/><path d="M29 19 L41 32 L29 45"/></g></svg>' } })
        : createElement(ProviderIcon, { name: tg, size: 13 }),
      createElement('span', { className: 'bt-chip-label' }, OUTBOUND_LABELS[tg][lang]),
    )),
  )
}

/** 对面取件指引：按选中目标给一条可复制命令（CLI 家给一键启动行，输入框家给同句） */
export function PickupGuide({ target, lang, t }: { target: OutboundTarget; lang: Lang; t: Translate }): ReturnType<typeof createElement> {
  const sample = pickupCommand(target, '<卡片编号>', lang)
  const lines = [
    createElement('div', { className: 'bt-sub', key: 'g0' }, t('pickupGuideIntro', { label: OUTBOUND_LABELS[target][lang] })),
    createElement('div', { className: 'bt-fsprev-line', key: 'g1' },
      createElement('span', { className: 'bt-fsprev-text', style: { fontFamily: 'monospace', fontSize: 11 } }, sample),
    ),
    createElement('div', { className: 'bt-sub', key: 'g2' }, t('pickupGuideDsh')),
  ]
  return createElement('div', { className: 'bt-fsprev', style: { marginTop: 8 } }, ...lines)
}

/** 交接出去卡：当前会话 → 共享收件箱 → 对面接手。
 * 一键把寄存指令 queue 进本会话（sessionId 由宿主座位注入）；
 * 老宿主拿不到 sessionId 时自动退回复制路径（粘进输入框效果相同）。 */
export function SendCard({ sessionId, t, lang, onError, onNotice, bare }: {
  sessionId?: string
  t: Translate
  lang: Lang
  onError: (msg: string) => void
  onNotice: (msg: string) => void
  /** bare=true：无卡片壳/无标题/无说明——嵌入分段动作卡的窗格用 */
  bare?: boolean
}): ReturnType<typeof createElement> {
  const [target, setTarget] = useState<OutboundTarget>('any')
  const [busy, setBusy] = useState(false)
  const [sent, setSent] = useState(false)
  const [copied, setCopied] = useState(false)
  const copyTimer = useRef<number | undefined>(undefined)

  const copyInstruction = (text: string, notice: string): void => {
    void copyText(text)
      .then(() => {
        setCopied(true)
        window.clearTimeout(copyTimer.current)
        copyTimer.current = window.setTimeout(() => setCopied(false), 2400)
        onNotice(notice)
      })
      .catch((e: unknown) => onError(e instanceof Error ? e.message : String(e)))
  }

  const targetLabelText = OUTBOUND_LABELS[target][lang]
  const send = (): void => {
    if (busy) return
    const instruction = outboundCommand(lang, target === 'any' ? undefined : targetLabelText)
    if (sessionId === undefined || sessionId === '') {
      // 老宿主：座位没带 sessionId——复制指令，用户粘进输入框（语义一致）
      copyInstruction(instruction, t('sendCopiedNotice'))
      return
    }
    setBusy(true)
    void post<{ ok: true } | { ok: false; error: string; instruction?: string }>('/dsh-takeover/send', { sessionId, lang, target })
      .then((r) => {
        if (r.ok) {
          setSent(true)
          onNotice(t('sentNotice'))
          return undefined
        }
        // 规范降级：服务端带回指令 → 复制路径（失败原因随横幅浮出，不吞错）
        if (typeof r.instruction === 'string' && r.instruction !== '') {
          copyInstruction(r.instruction, `${t('sendFallbackNotice')}：${r.error}`)
          return undefined
        }
        throw new Error(r.error)
      })
      .catch((e: unknown) => onError(e instanceof Error ? e.message : String(e)))
      .finally(() => setBusy(false))
  }

  return createElement('div', { className: bare === true ? 'bt-bare' : 'bt-card' },
    bare === true ? null : createElement('div', { className: 'bt-head' },
      createElement('span', { className: 'bt-title-sec' }, t('sendTitle')),
    ),
    bare === true ? null : createElement('div', { className: 'bt-sub' }, sessionId !== undefined && sessionId !== '' ? t('sendHint') : t('sendHintCopy')),
    createElement('div', { className: 'bt-sub', style: { marginTop: 6, fontWeight: 600 } }, t('targetGroupLabel')),
    createElement(TargetChips, { sel: target, lang, onSelect: setTarget, ariaLabel: t('targetGroupLabel') }),
    createElement('div', { style: { display: 'flex', gap: 8, alignItems: 'center', marginTop: 8 } },
      createElement('button', {
        className: 'bt-btn bt-btn-primary',
        type: 'button',
        disabled: busy,
        onClick: send,
        title: t('sendBtnTitle'),
      },
        copied ? t('copiedBtn') : busy ? t('sendBusy') : target === 'any' ? t('sendBtn') : t('sendBtnTo', { label: targetLabelText }),
      ),
    ),
    createElement('details', { className: 'bt-note', open: sent, style: { marginTop: 8 } },
      createElement('summary', null, t('pickupGuideTitle')),
      createElement('div', { className: 'bt-note-body' },
        createElement(PickupGuide, { target, lang, t }),
      ),
    ),
  )
}

/** 记忆快照卡：扫描本机各 agent 的记忆文件，勾选打包成一张交接卡进收件箱。
 * 会话能交接，记忆也能——取件方按卡「建议加载」吸收进自己的记忆文件。 */
export function MemoryCard({ t, lang, onError, onNotice, onPushed, defaultOpen, active, bare }: {
  t: Translate
  lang: Lang
  onError: (msg: string) => void
  onNotice: (msg: string) => void
  /** 出卡成功后回调（工作台 reload state，新卡即刻出现在收件箱） */
  onPushed: () => void
  /** 初始展开（默认收起；展开即扫描一次） */
  defaultOpen?: boolean
  /** 分段窗格激活（bare 模式下据此自动扫描） */
  active?: boolean
  /** bare=true：无折叠壳/标题/说明——嵌入分段动作卡窗格用 */
  bare?: boolean
}): ReturnType<typeof createElement> {
  const [open, setOpen] = useState(defaultOpen === true || bare === true)
  const [scanned, setScanned] = useState(false)
  const [rows, setRows] = useState<MemorySourceRow[] | null>(null)
  const [picked, setPicked] = useState<Set<string>>(new Set())
  const [target, setTarget] = useState<OutboundTarget>('any')
  const [busy, setBusy] = useState(false)

  const scan = (): void => {
    setScanned(true)
    setRows(null)
    void getJson<{ ok: true; sources: MemorySourceRow[] }>('/dsh-takeover/memory-scan')
      .then((b) => {
        setRows(b.sources)
        setPicked(new Set(b.sources.filter((r) => r.exists).map((r) => r.key)))
      })
      .catch((e: unknown) => onError(e instanceof Error ? e.message : String(e)))
  }

  // 展开即扫描（onToggle / defaultOpen / 分段窗格激活三条路都汇到这里；scanned 防重）
  useEffect(() => {
    if ((open || (bare === true && active === true)) && !scanned) scan()
    // eslint-disable-next-line react-hooks/exhaustive-deps -- scan 只闭包 setState，挂载期稳定
  }, [open, scanned])

  const toggle = (key: string): void => {
    setPicked((prev) => {
      const next = new Set(prev)
      if (next.has(key)) next.delete(key)
      else next.add(key)
      return next
    })
  }

  const push = (): void => {
    if (busy || picked.size === 0) return
    setBusy(true)
    void post<{ ok: true; sources: number } | { ok: false; error: string }>('/dsh-takeover/memory-push', { keys: [...picked], target })
      .then((r) => {
        if (!r.ok) throw new Error(r.error)
        onNotice(t('memoryPushedNotice', { n: r.sources }))
        onPushed()
      })
      .catch((e: unknown) => onError(e instanceof Error ? e.message : String(e)))
      .finally(() => setBusy(false))
  }

  const kb = (n: number): string => (n >= 1024 ? `${Math.max(1, Math.round(n / 1024))} KB` : `${n} B`)
  const existing = rows?.filter((r) => r.exists) ?? []
  // 不存在的来源不渲染（对没装某家的用户就是噪音——「跟 hippo 有啥关系」），
  // 只报个数保持「扫过哪些」的透明度
  const missing = rows?.filter((r) => !r.exists).length ?? 0

  if (bare === true) {
    // bare（分段窗格）：无折叠壳——标题/说明由窗格外的分段器承担，内容直出
    return createElement('div', { className: 'bt-bare' },
      createElement('div', { className: 'bt-sub', style: { margin: '2px 0 8px' } },
        rows === null
          ? createElement('span', { className: 'bt-sub bt-fs-empty' }, scanned ? t('memoryScanning') : '')
          : null),
      rows === null
        ? null
        : existing.length === 0
          ? createElement('div', { className: 'bt-sub bt-fs-empty' }, t('memoryNone'))
          : [
              createElement('div', { key: 'rows', style: { display: 'grid', gap: 4, marginTop: 4 } },
                ...existing.map((r) => createElement('label', {
                  key: r.key,
                  style: {
                    display: 'flex', gap: 8, alignItems: 'center', fontSize: 12,
                    cursor: 'pointer',
                  },
                  title: r.preview !== '' ? r.preview : r.path,
                },
                  createElement('input', {
                    type: 'checkbox',
                    checked: picked.has(r.key),
                    onChange: () => { toggle(r.key) },
                  }),
                  createElement('span', { style: { flex: '0 0 auto', fontWeight: 600 } }, r.agent),
                  createElement('span', { style: { flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', opacity: 0.75 } }, r.path),
                  createElement('span', { style: { flex: '0 0 auto', opacity: 0.6 } }, kb(r.bytes)),
                )),
              ),
              missing > 0 ? createElement('div', { key: 'missing', className: 'bt-sub', style: { marginTop: 4, opacity: 0.6 } }, t('memoryMissingNote', { n: missing })) : null,
              createElement(TargetChips, { key: 'targets', sel: target, lang, onSelect: setTarget, ariaLabel: t('targetGroupLabel') }),
              createElement('div', { key: 'act', style: { display: 'flex', gap: 8, alignItems: 'center', marginTop: 8 } },
                createElement('button', {
                  className: 'bt-btn bt-btn-primary',
                  type: 'button',
                  disabled: busy || picked.size === 0,
                  onClick: push,
                  title: t('memoryPushBtnTitle'),
                }, busy ? t('memoryPushing') : t('memoryPushBtn', { n: picked.size })),
              ),
            ],
    )
  }
  return createElement('details', {
    className: 'bt-group',
    open,
    onToggle: (e: unknown) => {
      const now = (e as { target?: { open?: boolean } }).target?.open === true
      setOpen(now)
      if (now && !scanned) scan()
    },
  },
    createElement('summary', { className: 'bt-pending', style: { listStyle: 'none', cursor: 'pointer' } },
      createElement('span', {
        className: 'bt-logo',
        style: { width: 13, height: 13, display: 'inline-block', opacity: 0.9 },
        dangerouslySetInnerHTML: { __html: MEMORY_SVG },
      }),
      createElement('span', { className: 'bt-title-sec' }, `${t('memoryTitle')}`),
      createElement('span', { className: 'bt-spacer' }),
      createElement('span', { className: 'bt-pending-chev', 'aria-hidden': true }, '▸'),
    ),
    createElement('div', { style: { padding: '8px 2px 2px' } },
      createElement('div', { className: 'bt-sub' }, t('memoryHint')),
      rows === null
        ? createElement('div', { className: 'bt-sub bt-fs-empty' }, scanned ? t('memoryScanning') : t('memoryExpandHint'))
        : existing.length === 0
          ? createElement('div', { className: 'bt-sub bt-fs-empty' }, t('memoryNone'))
          : [
              createElement('div', { key: 'rows', style: { display: 'grid', gap: 4, marginTop: 8 } },
                ...existing.map((r) => createElement('label', {
                  key: r.key,
                  style: {
                    display: 'flex', gap: 8, alignItems: 'center', fontSize: 12,
                    cursor: 'pointer',
                  },
                  title: r.preview !== '' ? r.preview : r.path,
                },
                  createElement('input', {
                    type: 'checkbox',
                    checked: picked.has(r.key),
                    onChange: () => { toggle(r.key) },
                  }),
                  createElement('span', { style: { flex: '0 0 auto', fontWeight: 600 } }, r.agent),
                  createElement('span', { style: { flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', opacity: 0.75 } }, r.path),
                  createElement('span', { style: { flex: '0 0 auto', opacity: 0.6 } }, kb(r.bytes)),
                )),
              ),
              missing > 0 ? createElement('div', { key: 'missing', className: 'bt-sub', style: { marginTop: 4, opacity: 0.6 } }, t('memoryMissingNote', { n: missing })) : null,
              createElement(TargetChips, { key: 'targets', sel: target, lang, onSelect: setTarget, ariaLabel: t('targetGroupLabel') }),
              createElement('div', { key: 'act', style: { display: 'flex', gap: 8, alignItems: 'center', marginTop: 8 } },
                createElement('button', {
                  className: 'bt-btn bt-btn-primary',
                  type: 'button',
                  disabled: busy || picked.size === 0,
                  onClick: push,
                  title: t('memoryPushBtnTitle'),
                }, busy ? t('memoryPushing') : t('memoryPushBtn', { n: picked.size })),
              ),
            ],
    ),
  )
}


/** 新手帮助 / FAQ：问答列表本体（显隐由挂载方的按钮控制——工作台在浮层标题栏，
 * 设置卡在头卡按钮；不再各占一整行） */
export function HelpCard({ t }: { t: Translate }): ReturnType<typeof createElement> {
  const entries = [1, 2, 3, 4, 5, 6, 7, 8].map((i) => ({
    q: t(`qa${i}q`),
    a: t(`qa${i}a`),
  }))
  return createElement('div', { className: 'bt-card', 'data-help-card': '1' },
    createElement('div', { className: 'bt-head' },
      createElement('span', {
        className: 'bt-logo',
        style: { width: 13, height: 13, display: 'inline-block', opacity: 0.9 },
        dangerouslySetInnerHTML: { __html: HELP_SVG },
      }),
      createElement('span', { className: 'bt-title-sec' }, t('helpTitle')),
    ),
    // 三步上手（复用引导条文案——引导条消失后的唯一常驻指南）
    createElement('div', { style: { display: 'grid', gap: 4, fontSize: 12, marginBottom: 10 } },
      createElement('span', { style: { fontWeight: 600 } }, t('popoverSubtitle')),
      createElement('span', { style: { opacity: .85 } }, `① ${t('onboard1')}`),
      createElement('span', { style: { opacity: .85 } }, `② ${t('onboard2')}`),
      createElement('span', { style: { opacity: .85 } }, `③ ${t('onboard3')}`),
    ),
    createElement('div', { style: { display: 'grid', gap: 8 } },
      ...entries.map((e, i) => createElement('div', { key: i, style: { marginBottom: 8 } },
        createElement('div', { style: { fontWeight: 600, marginBottom: 2 } }, e.q),
        createElement('div', { style: { opacity: 0.85 } }, e.a),
      )),
    ),
  )
}

// ---------------------------------------------------------------------------
// 外部会话浏览器：浏览 + 一键投递。面板不产卡——蒸馏都在会话里由
// 模型完成（卡片质量跟着模型能力走，这正是「跟着模型升级」的接法）；
// 一键投递只是把与手动复制同源的指令送进新会话，失败退回复制。
// 列表走轻量发现层（默认不自动扫九家，点哪家读哪家）；预览按需单会话拉结构化摘要。
// ---------------------------------------------------------------------------

interface PreviewEntry {
  loading: boolean
  data: SessionPreviewBody | null
  error: string | null
}

export function ForeignBrowser({ state, t, lang, onError, onNotice, navigate, bare, active }: {
  state: TakeoverState | null
  t: Translate
  lang: Lang
  onError: (msg: string) => void
  /** 软回执横幅（ 降级原因等，8s 自清）——降级不吞错 */
  onNotice: (msg: string) => void
  /** 投递成功后切换到新会话（宿主 uiWorkspace.openSession；缺席回 false 走树内提示） */
  navigate: (sessionId: string) => boolean
  /** bare=true：无卡片壳/标题/说明——嵌入分段动作卡窗格用（内容自动前置） */
  bare?: boolean
  /** active=true：窗格激活（分段器选中）——bare 模式下据此自动载入首店 */
  active?: boolean
}): ReturnType<typeof createElement> {
  const providers = state?.providers ?? []
  // 选中家：bare 模式自动前置会话最多的可用家（内容默认可见——「点谁读谁」的
  // 成本纪律保持：一次只扫一家）；非 bare 保持点选语义
  const [sel, setSel] = useState<string | null>(null)
  const [lists, setLists] = useState<Record<string, SessionListBody>>({})
  // 按家记加载态（单字符串设计会在 A 加载中点 B 时把 B 永久卡在「加载中…」）
  const [loading, setLoading] = useState<Record<string, boolean>>({})
  const [query, setQuery] = useState('')
  // 项目（cwd）facet 选中键；子代理组展开态
  const [cwdSel, setCwdSel] = useState<string | null>(null)
  const [subOpen, setSubOpen] = useState(false)
  // 一键接管投递态（busyKey 防双击；delivered 成功回执）
  const [busyKey, setBusyKey] = useState<string | null>(null)
  const [deliveredKey, setDeliveredKey] = useState<string | null>(null)
  // 预览：单行展开（openId），按会话 id 缓存
  const [openId, setOpenId] = useState<string | null>(null)
  const [previews, setPreviews] = useState<Record<string, PreviewEntry>>({})
  // 复制回执：按钮文案短暂切换（不引入 toast 组件）
  const [copied, setCopied] = useState<string | null>(null)
  const copyTimer = useRef<number | undefined>(undefined)

  const load = (provider: string): void => {
    setLoading((prev) => ({ ...prev, [provider]: true }))
    void getJson<SessionListBody | { ok: false; error: string }>(`/dsh-takeover/sessions?provider=${encodeURIComponent(provider)}`)
      .then((b) => {
        if (b.ok !== true) throw new Error(b.error)
        setLists((prev) => ({ ...prev, [provider]: b }))
      })
      .catch((e: unknown) => onError(e instanceof Error ? e.message : String(e)))
      .finally(() => setLoading((cur) => {
        if (cur[provider] !== true) return cur
        const next = { ...cur }
        delete next[provider]
        return next
      }))
  }

  // bare+active：自动前置会话最多的可用家（内容默认可见——空态从此不存在；
  // 换家仍走 chip 过滤，一次只扫一家的成本纪律保持）
  useEffect(() => {
    if (bare !== true || active !== true || sel !== null) return
    const best = [...providers].filter((p) => p.supported && p.enabled && p.sessions > 0)
      .sort((a, b) => b.sessions - a.sessions)[0]
    if (best !== undefined) {
      setSel(best.name)
      load(best.name)
    }
  }, [bare, active, providers, sel])

  const loadPreview = (provider: string, id: string): void => {
    setPreviews((prev) => ({ ...prev, [id]: { loading: true, data: prev[id]?.data ?? null, error: null } }))
    void getJson<SessionPreviewBody | { ok: false; error: string }>(
      `/dsh-takeover/session-preview?provider=${encodeURIComponent(provider)}&reference=${encodeURIComponent(id)}`,
    )
      .then((b) => {
        if (b.ok !== true) throw new Error(b.error)
        setPreviews((prev) => ({ ...prev, [id]: { loading: false, data: b, error: null } }))
      })
      .catch((e: unknown) => {
        setPreviews((prev) => ({ ...prev, [id]: { loading: false, data: null, error: e instanceof Error ? e.message : String(e) } }))
      })
  }

  const copy = (key: string, text: string): void => {
    void copyText(text)
      .then(() => {
        setCopied(key)
        window.clearTimeout(copyTimer.current)
        copyTimer.current = window.setTimeout(() => setCopied(null), 1600)
      })
      .catch((e: unknown) => onError(e instanceof Error ? e.message : String(e)))
  }

  const now = Date.now()
  const list = sel !== null ? lists[sel] : undefined
  const provider = sel ?? ''
  const clip = (s: string, n = 260): string => (s.length > n ? `${s.slice(0, n)}…` : s)

  /** 一键接管：POST 宿主投递（建新会话+queue 指令）；失败（含宿主缺控制器）
   * 自动退回复制路径——按钮与手动粘贴的载荷同源（takeoverCommand/depositCommand），
   * 降级永不改变语义，只多一步粘贴；失败原因随信息横幅浮出（不吞错）。 */
  const runTakeover = (key: string, mode: 'take' | 'take_deposit', id: string): void => {
    if (busyKey !== null) return
    const fallback = mode === 'take_deposit' ? depositCommand(provider, id, lang) : takeoverCommand(provider, id)
    setBusyKey(key)
    void post<{ ok: true; sessionId: string; title: string } | { ok: false; error: string }>(
      '/dsh-takeover/takeover',
      { mode, provider, reference: id, lang },
    )
      .then((r) => {
        if (!r.ok) throw new Error(r.error)
        setDeliveredKey(key)
        const switched = navigate(r.sessionId)
        onNotice(t(switched ? 'deliveredNoticeNav' : 'deliveredNotice', { title: r.title }))
        return undefined
      })
      .catch((e: unknown) => {
        const reason = e instanceof Error ? e.message : String(e)
        copyText(fallback)
          .then(() => {
            setCopied(key)
            window.clearTimeout(copyTimer.current)
            copyTimer.current = window.setTimeout(() => setCopied(null), 2400)
            onNotice(t('fallbackNotice', { reason }))
          })
          .catch((ce: unknown) => onError(ce instanceof Error ? ce.message : String(ce)))
      })
      .finally(() => setBusyKey(null))
  }

  const line = (label: string, text: string, key?: string): ReturnType<typeof createElement> =>
    createElement('div', { className: 'bt-fsprev-line', key },
      label !== '' ? createElement('span', { className: 'bt-fsprev-label' }, label) : null,
      createElement('span', { className: 'bt-fsprev-text' }, text),
    )

  const previewNode = (id: string): ReturnType<typeof createElement> | null => {
    const pv = previews[id]
    if (pv === undefined || pv.loading) return createElement('div', { className: 'bt-fsprev' }, t('loading'))
    if (pv.error !== null) {
      return createElement('div', { className: 'bt-fsprev bt-fsprev-warn' }, `${t('previewLoadFail')}：${pv.error}`)
    }
    const d = pv.data
    if (d === null) return null
    const warns = d.skeleton.warnings.split('\n').map((s) => s.trim()).filter((s) => s !== '').slice(0, 3)
    return createElement('div', { className: 'bt-fsprev' },
      createElement('div', { className: 'bt-fsprev-line' },
        createElement('span', { className: 'bt-fsprev-label' },
          t('previewTurns', { n: d.summary.turnCount, u: d.summary.userTurns })),
        d.note !== undefined ? createElement('span', { className: 'bt-fsprev-warn' }, d.note) : null,
      ),
      d.summary.firstUserMessage !== '' ? line(t('previewFirst'), clip(d.summary.firstUserMessage), 'pv-first') : null,
      ...d.summary.tailProgress.slice(0, 2).map((s, i) => line(i === 0 ? t('previewTail') : '', clip(s, 200), `pv-tail-${i}`)),
      line(t('previewStop'), clip(d.skeleton.stopped), 'pv-stop'),
      ...warns.map((w, i) => createElement('div', { className: 'bt-fsprev-line bt-fsprev-warn', key: `pv-warn-${i}` }, `⚠ ${clip(w, 200)}`)),
    )
  }

  const toggleRow = (r: SessionRow, open: boolean): void => {
    setOpenId(open ? null : r.id)
    if (!open && previews[r.id] === undefined && sel !== null) loadPreview(sel, r.id)
  }

  /** fsess 标题清洗：剥系统前缀（<local-command-*>）与应答模板行（"Reply only with…"），
   * 取第一条用户可读行；全空回退 id（0.4.3——审查实测 12 条标题一半是系统噪声） */
  const fsessDisplayTitle = (raw: string, idShown: string): string => {
    const trimmed = raw.trim()
    if (trimmed === '') return idShown
    const cleaned = trimmed
      .replace(/<local-command-[a-z-]+>[\s\S]*?<\/local-command-[a-z-]+>/gi, '')
      .replace(/<local-command-[a-z-]+>/gi, '')
      .replace(/^Reply only with[^\n]*\n?/i, '')
      .trim()
    return cleaned !== '' ? (cleaned.split('\n')[0] ?? idShown).slice(0, 200) : idShown
  }

  const rowNode = (r: SessionRow): ReturnType<typeof createElement> => {
    const open = openId === r.id
    const idShown = shortId(r)
    const idKey = `id:${r.id}`
    const rowCol = projectColor(r.cwd)
    return createElement('div', {
      key: r.id,
      className: 'bt-fsess',
      // 项目色左缘条：整个列表按项目着色——滚动里扫一眼就知道哪片是哪个项目
      style: { borderLeft: `3px solid ${rowCol.hex}` },
    },
      createElement('div', { className: 'bt-fsess-line1' },
        createElement('span', {
          className: 'bt-fsess-title',
          role: 'button',
          tabIndex: 0,
          'aria-expanded': open,
          title: fsessDisplayTitle(r.title, r.id),
          onClick: () => toggleRow(r, open),
          onKeyDown: (e: { key: string; preventDefault(): void }) => {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggleRow(r, open) }
          },
        }, fsessDisplayTitle(r.title, idShown)),
        createElement('span', { className: 'bt-fsess-time' }, relTime(r.updatedAt, now, lang)),
      ),
      createElement('div', { className: 'bt-fsess-line2' },
        (() => {
          const col = projectColor(r.cwd)
          const label = r.cwd === '' ? '—' : (r.cwd.split(/[\\/]/).filter(Boolean).pop() ?? r.cwd)
          return createElement('span', {
            className: 'bt-fsess-src',
            title: r.cwd !== '' ? r.cwd : undefined,
            style: r.cwd === '' ? undefined : { color: col.hex },
          }, createElement(FolderIcon, { color: col.hex }), label)
        })(),
        createElement('span', {
          className: 'bt-fsess-id',
          role: 'button',
          tabIndex: 0,
          title: t('copyIdTitle'),
          onClick: () => copy(idKey, r.id),
          onKeyDown: (e: { key: string; preventDefault(): void }) => {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); copy(idKey, r.id) }
          },
        }, copied === idKey ? t('copiedBtn') : idShown),
        createElement('span', { className: 'bt-fsess-act' },
          createElement('button', {
            className: 'bt-btn bt-btn-xs bt-btn-primary',
            type: 'button',
            disabled: busyKey !== null,
            title: t('takeoverTitle'),
            onClick: () => runTakeover(`take:${r.id}`, 'take', r.id),
          },
            deliveredKey === `take:${r.id}` ? t('deliveredBtn')
            : busyKey === `take:${r.id}` ? t('deliveringBtn')
            : copied === `take:${r.id}` ? t('fallbackCopyBtn')
            : t('takeoverBtn')),
          createElement('button', {
            className: 'bt-btn bt-btn-xs',
            type: 'button',
            disabled: busyKey !== null,
            title: t('depositTitle'),
            onClick: () => runTakeover(`dep:${r.id}`, 'take_deposit', r.id),
          },
            deliveredKey === `dep:${r.id}` ? t('deliveredBtn')
            : busyKey === `dep:${r.id}` ? t('deliveringBtn')
            : copied === `dep:${r.id}` ? t('fallbackCopyBtn')
            : t('depositBtn')),
        ),
      ),
      open ? previewNode(r.id) : null,
    )
  }

  const matched = list !== undefined ? filterSessions(list.sessions, query) : []
  // facet 计数随查询走（不含自身 cwd 选择，保持各 facet 计数可点）
  const facets = list !== undefined ? cwdFacets(matched) : []
  // 选中的 facet 因查询变化/换家消失时自动失效——不留下隐形过滤器
  const cwdEffective = facets.some((f) => f.cwd === cwdSel) ? cwdSel : null
  const visible = filterByCwd(matched, cwdEffective).filter((r) => !isSubagentSession(r))
  // 子代理/工作流会话收进次级折叠组（agent-sessions #49、cc-sessions #3 两家用户各自请求）
  const subRows = filterByCwd(matched, cwdEffective).filter(isSubagentSession)

  // 次级折叠组（与收件箱低信息组同款交互：组头开合，默认收起）
  const subGroupNode = subRows.length > 0
    ? createElement('div', { className: 'bt-group', key: 'fs-sub' },
        createElement('div', {
          className: `bt-pending${subOpen ? ' bt-pending-open' : ''}`,
          role: 'button',
          tabIndex: 0,
          'aria-expanded': subOpen,
          'aria-label': t('subagentGroup', { n: subRows.length }),
          onClick: () => setSubOpen(!subOpen),
          onKeyDown: (e: { key: string; preventDefault(): void }) => {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setSubOpen(!subOpen) }
          },
        },
          createElement('span', { className: 'bt-tag bt-tag-lowinfo' }, t('subagentBadge')),
          createElement('span', { className: 'bt-pending-title' }, t('subagentGroup', { n: subRows.length })),
          createElement('span', { className: 'bt-pending-chev', 'aria-hidden': true }, '▸'),
        ),
        subOpen ? subRows.map(rowNode) : null,
      )
    : null

  return createElement('div', { className: bare === true ? 'bt-bare' : 'bt-card' },
    bare === true ? null : createElement('div', { className: 'bt-head' },
      createElement('span', { className: 'bt-title-sec' }, t('browserTitle')),
    ),
    bare === true ? null : createElement('div', { className: 'bt-sub' }, t('browserHint')),
    bare === true ? null : createElement('div', { className: 'bt-sub', style: { marginTop: 8, fontWeight: 600 } }, t('browserGroupLabel')),
    createElement('div', { className: 'bt-chips', role: 'group', 'aria-label': t('browserChipAria'), style: { marginTop: 8 } },
      ...providers.map((p) => {
        const usable = p.supported && p.enabled
        return createElement('button', {
          key: p.name,
          className: `bt-chip${sel === p.name ? ' bt-chip-on' : ''}${usable ? '' : ' bt-chip-off'}`,
          disabled: !usable,
          'aria-pressed': sel === p.name,
          type: 'button',
          title: !usable
            ? t('browserDisabledTitle', { label: PROVIDER_LABEL[p.name] ?? p.name })
            : (p.supported && p.note !== '' ? p.note : undefined),
          onClick: () => {
            setSel(p.name)
            setOpenId(null)
            setCwdSel(null) // 换家必清项目 facet——旧家的 cwd 对新家是隐形过滤器
            if (lists[p.name] === undefined && loading[p.name] !== true) load(p.name)
          },
        },
          createElement(ProviderIcon, { name: p.name, size: 13 }),
          createElement('span', { className: 'bt-chip-label' }, PROVIDER_LABEL[p.name] ?? p.name),
          createElement('span', { className: 'bt-chip-count' }, p.sessions >= 0 ? String(p.sessions) : '…'),
        )
      }),
    ),
    sel === null || list === undefined
      ? createElement('div', { className: 'bt-sub bt-fs-empty' }, sel === null ? t('browserPick') : t('loading'))
      : [
          createElement('div', { className: 'bt-inbox-toolbar', key: 'fs-bar' },
            createElement('input', {
              className: 'bt-filter',
              type: 'search',
              value: query,
              placeholder: t('filterSessionsPlaceholder'),
              'aria-label': t('filterSessionsAria'),
              title: t('filterSessionsAria'),
              onChange: (e: { target: { value: string } }) => { setQuery(e.target.value) },
            }),
            createElement('button', {
              className: 'bt-btn',
              type: 'button',
              disabled: loading[provider] === true,
              onClick: () => { setOpenId(null); load(provider) },
            }, loading[provider] === true ? t('loading') : t('refresh')),
          ),
          createElement('div', { className: 'bt-sub bt-fs-count', key: 'fs-count' },
            list.total === 0
              ? t('browserEmpty')
              : t('browserTotal', { m: list.total, n: list.sessions.length }),
            list.note !== undefined ? ` · ${t('browserNote', { note: list.note })}` : '',
          ),
          list.total > 0 && facets.length > 1
            ? createElement('div', { className: 'bt-chips', key: 'fs-cwd', role: 'group', 'aria-label': t('facetCwdAria'), style: { marginTop: 6 } },
                ...facets.map((f) => {
                  const col = projectColor(f.cwd)
                  const on = cwdEffective === f.cwd
                  return createElement('button', {
                    key: f.cwd === '' ? '(empty)' : f.cwd,
                    className: `bt-chip${on ? ' bt-chip-on' : ''}`,
                    style: on ? { borderColor: `rgba(${col.rgb},.55)`, background: `rgba(${col.rgb},.14)`, color: col.hex } : undefined,
                    'aria-pressed': on,
                    type: 'button',
                    title: f.cwd === '' ? undefined : f.cwd,
                    onClick: () => setCwdSel(on ? null : f.cwd),
                  },
                    createElement(FolderIcon, { color: col.hex }),
                    createElement('span', { className: 'bt-chip-label' }, f.label),
                    createElement('span', { className: 'bt-chip-count' }, String(f.count)),
                  )
                }),
              )
            : null,
          list.total > 0 && matched.length === 0
            ? createElement('div', { className: 'bt-banner bt-banner-info', key: 'fs-nomatch' }, t('browserFilterEmpty'))
            : createElement('div', { key: 'fs-rows' }, visible.map(rowNode), subGroupNode),
        ],
  )
}

// ---------------------------------------------------------------------------
// 命令速览：设置卡「命令速览」页签的网格体（mono 键 + 说明文案，DESIGN.md §3/§4）。
// provider 与 foreign.ts 的 FOREIGN_PROVIDERS 保持一致——不直接 import
// （值引入会把 host 半的 cordis/dsh-tools 拖进客户端包）。
// ---------------------------------------------------------------------------

const RESUME_PROVIDERS = ['claude', 'codex', 'opencode', 'zcode', 'pi', 'workbuddy', 'cursor', 'grok', 'gemini'] as const

export function CommandsGrid({ state, t }: { state: TakeoverState | null; t: Translate }): ReturnType<typeof createElement> {
  const disabled = new Set<string>(
    (state?.providers ?? []).filter((p) => !p.enabled).map((p) => p.name as string),
  )
  const chip = (cmd: string, desc: string, provider?: string, primary = false): ReturnType<typeof createElement> => {
    const off = provider !== undefined && disabled.has(provider)
    const label = provider !== undefined ? (PROVIDER_LABEL[provider] ?? provider) : undefined
    return createElement('div', {
      key: cmd,
      className: `tk-cmd${off ? ' tk-cmd-off' : ''}`,
      title: off && label !== undefined ? t('cmdOffTitle', { label }) : undefined,
    },
      provider !== undefined
        ? createElement(ProviderIcon, { name: provider })
        // 本插件自有命令：品牌渐变块（§2 来源头像：品牌渐变圆角块 + 图标）
        : createElement('span', { className: 'bt-icon', style: { width: 16, height: 16, background: 'var(--tk-grad)' } },
            createElement('svg', { viewBox: '0 0 64 64', width: 10, height: 10, 'aria-hidden': true },
              createElement('rect', { x: 12, y: 26.5, width: 40, height: 11, rx: 5.5, fill: '#fff', transform: 'rotate(-45 32 32)' }))),
      createElement('span', { className: `tk-cmd-key${primary ? ' tk-cmd-key-primary' : ''}` }, cmd),
      createElement('span', { className: 'tk-cmd-desc' }, desc),
    )
  }
  return createElement('div', { className: 'tk-cmds' },
    chip('/handoff', t('cmdHandoffDesc'), undefined, true),
    chip('/inbox', t('cmdInboxDesc'), undefined, true),
    ...RESUME_PROVIDERS.map((p) => chip(`/resume-${p}`, t('cmdResumeDesc', { name: PROVIDER_LABEL[p] ?? p }), p)),
  )
}

// 渲染错误边界：任何渲染期异常直接显示在卡片里（宿主外壳会吞 React 报错，
// 静默空白最难排查——宁可把错误亮出来）。
type BoundaryState = { err: unknown }
export class PanelBoundary extends Component<{ children: ReturnType<typeof createElement>; t: Translate }, BoundaryState> {
  override state: BoundaryState = { err: null }
  static getDerivedStateFromError(err: unknown): BoundaryState { return { err } }
  override render(): ReturnType<typeof createElement> {
    if (this.state.err !== null) {
      const e = this.state.err as { stack?: string; message?: string }
      return createElement('div', { className: 'bt-panel', style: themeVars() },
        createElement('style', null, CSS),
        createElement('div', { className: 'bt-card' },
          createElement('div', { className: 'bt-title' }, this.props.t('renderErrorTitle')),
          createElement('pre',
            { style: { fontSize: 11, whiteSpace: 'pre-wrap', wordBreak: 'break-word', margin: 0, lineHeight: 1.5 } },
            e.stack ?? e.message ?? String(this.state.err)),
        ),
      )
    }
    return this.props.children
  }
}

/** 宿主 locale revision 变化即重渲染（bound t 在渲染时取词）——设置卡与右侧栏工作台共用 */
function useLocaleSync(locale: LocaleRuntime | undefined): void {
  useSyncExternalStore(
    (cb) => {
      try {
        return locale?.subscribe(cb) ?? (() => {})
      } catch {
        return (() => {}) as () => void
      }
    },
    () => {
      try {
        return locale?.getSnapshot().revision ?? 0
      } catch {
        return 0
      }
    },
  )
}

/** /dsh-takeover/state 轮询：请求代数防慢响应回弹；30s 仅前台可见时刷。两个挂载面共用。
 * setState/generationRef 一并暴露：开关切换的成功响应带全量 state 就地采纳，
 * 且与 reload 共用同一请求代数（慢 toggle 响应不回弹）。 */
function useTakeoverPolling(): {
  state: TakeoverState | null
  setState: (s: TakeoverState | null) => void
  error: string | null
  setError: (e: string | null) => void
  reload: () => void
  generationRef: { current: number }
} {
  const [state, setState] = useState<TakeoverState | null>(null)
  const [error, setError] = useState<string | null>(null)
  const generationRef = useRef(0)
  const reload = (): void => {
    const gen = ++generationRef.current
    void getState().then(
      (s) => {
        if (gen !== generationRef.current) return
        setState(s); setError(null)
      },
      (e: unknown) => {
        if (gen !== generationRef.current) return
        setError(e instanceof Error ? e.message : String(e))
      },
    )
  }
  useEffect(reload, [])
  useEffect(() => {
    const timer = window.setInterval(() => {
      try {
        if (document.visibilityState === 'visible') reload()
      } catch {
        /* visibilityState 不可得（非浏览器环境）：跳过本轮 */
      }
    }, 30_000)
    return () => { window.clearInterval(timer) }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- reload 只闭包 setState，挂载期稳定
  }, [])
  return { state, setState, error, setError, reload, generationRef }
}

/** 面板版本徽标（显示在导航轨底部，用于一眼核对部署版本） */
// 版本徽标：构建期由 scripts/build-client.mjs 经 esbuild define 注入 package.json 的 version——
// 不再手写（0.4.3 发 0.4.4 时它还停在旧值）。tsx 直跑（测试）无 define，回退 'v?'。
declare const __PANEL_VERSION__: string
const PANEL_VERSION: string = typeof __PANEL_VERSION__ === 'string' ? __PANEL_VERSION__ : 'v?'

/** 工作台视图键：四个数据视图（常驻挂载、display 切换保状态）+ 轨底「上手指南」唤出的第五视图 */
type WorkView = 'inbox' | 'browse' | 'send' | 'memory' | 'guide'

/** 工作台面（DESIGN.md §5：左导航轨 148px + 右侧全宽视图）：收件箱 / 会话浏览器 /
 * 交接出去 / 记忆快照（一键接管/定向取件/出站交接/记忆打包全在这里）。挂载面有两个——
 * composer「接力」浮层（bounded=true，壳由 ComposerChip 提供）与老宿主降级时的设置卡内嵌
 * （bounded 缺席，工作台自铺 canvas）。sessionId 由宿主座位注入（交接出去用）；缺席只降级该卡。 */
export function WorkspaceBody({ t, locale, navigate, chrome, sessionId, showHelp, bounded }: {
  t: Translate
  locale: LocaleRuntime | undefined
  navigate: (sessionId: string) => boolean
  chrome: boolean
  /** 当前会话 id（宿主 conversation 座位注入；设置卡/老宿主缺席 → 交接出去卡走复制路径） */
  sessionId?: string
  /** 新手 FAQ：true 时初始落在「上手指南」视图（轨底按钮可随时切换；默认收件箱） */
  showHelp?: boolean
  /** 浮层挂载（有固定高度外壳：面板变 flex 列、视图体内滚） */
  bounded?: boolean
}): ReturnType<typeof createElement> {
  useLocaleSync(locale)
  const { state, error, setError, reload } = useTakeoverPolling()
  const lang: Lang = langOf(locale)
  // 新手引导条：知道了之后 localStorage 记住不再出现
  const [onboardGone, setOnboardGone] = useState(() => { try { return localStorage.getItem('dsh-takeover-onboard') === '1' } catch { return true } })
  // 收件箱即时过滤词：空串 = 不过滤（纯前端，输入即滤，清空恢复全部）
  const [query, setQuery] = useState('')
  const [confirmClear, setConfirmClear] = useState(false)
  // 导出▾菜单显隐：两个导出入口（全部 .md / HTML 报告）收进一个菜单，工具行不再摆两个长按钮
  const [exportMenu, setExportMenu] = useState(false)
  // 取件投递态（记正在投的卡 id，按行显示投递中）+ 操作回执横幅
  const [takeBusyId, setTakeBusyId] = useState<string | null>(null)
  // 导航轨当前视图：四视图常驻挂载（display 切换保状态），指南按需渲染。
  // showHelp=true（旧浮层 [?] 语义）→ 落在指南视图
  const [view, setView] = useState<WorkView>(showHelp === true ? 'guide' : 'inbox')
  useEffect(() => { if (showHelp === true) setView('guide') }, [showHelp])
  // 视图头 h2 id 前缀：设置卡内嵌 + composer 浮层可同时挂两实例（chipReady 晚翻转），
  // 固定 id 会撞、aria-labelledby 指向歧义——与设置卡 tabId/paneId 同法走 useId
  const uid = useId()
  const headId = (k: WorkView): string => `${uid}h-${k}`
  const rootRef = useRef<HTMLDivElement | null>(null)
  const railRef = useRef<HTMLElement | null>(null)
  const filterRef = useRef<HTMLInputElement | null>(null)
  // 过滤框聚焦（DESIGN.md §5：`/` 键聚焦，Cmd/Ctrl+K 语义）：过滤框只在收件箱视图头，
  // 其他视图下先切回收件箱，等本轮提交后再聚焦（display:none 的输入框 focus 会落空）
  const focusFilter = (): void => {
    if (view === 'inbox') {
      filterRef.current?.focus()
      filterRef.current?.select()
      return
    }
    setView('inbox')
    window.setTimeout(() => { filterRef.current?.focus(); filterRef.current?.select() }, 0)
  }
  // 键盘流挂在工作台根（React 合成事件只在焦点落在工作台内时触发——设置卡内嵌态不劫持
  // 宿主页面其他输入；浮层态打开即焦点入壳，`/` 立即可用）。`/` 在可编辑元素里放行（照常输入），
  // Cmd/Ctrl+K 不分焦点一律生效并截断（盖掉浏览器/宿主自己的 K 绑定）
  const onRootKeyDown = (e: { key: string; metaKey: boolean; ctrlKey: boolean; altKey: boolean; target: unknown; preventDefault(): void; stopPropagation(): void }): void => {
    const cmdK = (e.metaKey || e.ctrlKey) && !e.altKey && (e.key === 'k' || e.key === 'K')
    if (cmdK) { e.preventDefault(); e.stopPropagation(); focusFilter(); return }
    if (e.key !== '/' || e.metaKey || e.ctrlKey || e.altKey) return
    const el = e.target as { tagName?: string; isContentEditable?: boolean } | null
    const tag = el?.tagName ?? ''
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || el?.isContentEditable === true) return
    e.preventDefault()
    focusFilter()
  }
  const [clearBusy, setClearBusy] = useState(false)
  const [notice, setNotice] = useState<string | null>(null)
  const noticeTimer = useRef<number | undefined>(undefined)
  const showNotice = (msg: string): void => {
    setNotice(msg)
    window.clearTimeout(noticeTimer.current)
    noticeTimer.current = window.setTimeout(() => setNotice(null), 8000)
  }
  const takeInbox = (p: PendingRow): void => {
    if (takeBusyId !== null) return
    setTakeBusyId(p.id)
    // 行级按钮带卡 id 定向取件——服务端指令升级为「取编号 xxx 这张」，
    // 多卡待取时模型取的就是用户点的那张，不再是「自行挑一张」
    void post<{ ok: true; sessionId: string; title: string } | { ok: false; error: string }>('/dsh-takeover/takeover', { mode: 'inbox', reference: p.id })
      .then((r) => {
        if (!r.ok) throw new Error(r.error)
        const switched = navigate(r.sessionId)
        showNotice(t(switched ? 'deliveredNoticeNav' : 'deliveredNotice', { title: r.title }))
        return undefined
      })
      .catch((e: unknown) => setError(e instanceof Error ? e.message : String(e)))
      .finally(() => setTakeBusyId(null))
  }
  const clear = (): void => {
    if (!confirmClear) {
      setConfirmClear(true)
      setTimeout(() => { setConfirmClear(false) }, 6000)
      return
    }
    setConfirmClear(false)
    setClearBusy(true)
    void post<{ ok: true; cleared: number }>('/dsh-takeover/clear-archived', {})
      .then(() => { reload() })
      .catch((e: unknown) => { setError(e instanceof Error ? e.message : String(e)) })
      .finally(() => { setClearBusy(false) })
  }
  // 忽略一张待取件卡：原样移入 archived/（审计保留，不计消费）——pending 唯一的退出出口
  const [dismissBusyId, setDismissBusyId] = useState<string | null>(null)
  const dismiss = (p: PendingRow): void => {
    if (dismissBusyId !== null) return
    setDismissBusyId(p.id)
    void post<{ ok: true; moved: number } | { ok: false; error: string }>('/dsh-takeover/dismiss-pending', { id: p.id })
      .then((r) => {
        if (!r.ok) throw new Error(r.error)
        showNotice(t('dismissedNotice', { id: p.id }))
        reload()
        return undefined
      })
      .catch((e: unknown) => setError(e instanceof Error ? e.message : String(e)))
      .finally(() => setDismissBusyId(null))
  }
  const archivedCount = state?.archivedCount ?? 0
  // host 侧并行字段（0.3.2 预留位）：state 缺席或字段未落地 → null，行/徽标整体不渲染
  const envelopeChars = state !== null ? envelopeCharsOf(state) : null
  const coverage = state !== null ? coverageTextOf(state) : null
  // 导出说明文案随当前语言现取；生成/下载全程 try 包住，异常进错误横幅不塌卡
  const exportNotes = (): { top: string; missing: string } => ({
    top: t('exportNoteTop'),
    missing: t('exportSectionMissing'),
  })
  // 单卡导出：文件名 = 编号.md；内容由 state 真有字段生成，缺的段就地注明（inbox-view.ts）
  const exportOne = (p: PendingRow): void => {
    try {
      downloadText(`${p.id}.md`, cardMarkdown(p, exportNotes()))
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    }
  }
  // 导出全部：全部待取件拼一个 .md（文件名带导出时刻，避免反复下载互相覆盖）
  const exportAll = (): void => {
    if (state === null || state.pending.length === 0) return
    try {
      downloadText(`handoff-pending-${exportStamp()}.md`, pendingListMarkdown(state.pending, exportNotes()))
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    }
  }
  // 导出 HTML 报告：自包含单文件（九家矩阵 + 全部待取件 + 已消费计数；pending 为空也
  // 有矩阵与计数可报，故不随 pending 禁用）。state→html 组装在 buildReportHtml 纯函数，
  // 文案按当前语言现取（reportWords）；文件名带导出时刻，生成失败进错误横幅不塌卡
  const exportHtmlReport = (): void => {
    if (state === null) return
    try {
      const d = new Date()
      downloadText(
        `handoff-report-${exportStamp(d)}.html`,
        buildReportHtml(state, reportWords(lang), lang, absTime(d.toISOString())),
        'text/html;charset=utf-8',
      )
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    }
  }
  // ---- 导航轨数据：待取件数 / 默认前置家会话数（与 ForeignBrowser bare+active 自动前置规则同口径：
  //      会话最多的可用家；浏览器内换家是其私有状态，轨徽标不跟随——title 里如实披露口径） ----
  const pendingCount = state?.pending.length ?? 0
  const frontHome = state === null
    ? undefined
    : [...state.providers].filter((p) => p.supported && p.enabled && p.sessions > 0).sort((a, b) => b.sessions - a.sessions)[0]
  interface NavItem { k: WorkView; label: string; icon: string; badge?: number; hot?: boolean; badgeTitle?: string }
  const navItems: NavItem[] = [
    { k: 'inbox', label: t('navInbox'), icon: NAV_ICONS.inbox, badge: state !== null ? pendingCount : undefined, hot: pendingCount > 0, badgeTitle: t('pendingDirHint') },
    {
      k: 'browse', label: t('navBrowser'), icon: NAV_ICONS.browser, badge: frontHome?.sessions,
      badgeTitle: frontHome !== undefined ? t('navBrowserBadgeTitle', { label: PROVIDER_LABEL[frontHome.name] ?? frontHome.name }) : undefined,
    },
    { k: 'send', label: t('sendTitle'), icon: NAV_ICONS.send },
    { k: 'memory', label: t('memoryTitle'), icon: NAV_ICONS.memory },
  ]
  // ---- 导航轨键盘流（DESIGN.md §4 导航轨项）：↑/↓ 循环、Home/End 首尾，落焦即切视图
  //      （与设置卡页签 onTabsKeyDown 同法；轨是 <nav>，各项保持可 Tab，不做 roving tabindex）----
  const RAIL_ORDER: readonly WorkView[] = ['inbox', 'browse', 'send', 'memory', 'guide']
  const onRailKeyDown = (e: { key: string; preventDefault(): void }): void => {
    const i = RAIL_ORDER.indexOf(view)
    const n = RAIL_ORDER.length
    const next = e.key === 'ArrowDown' ? RAIL_ORDER[(i + 1) % n]
      : e.key === 'ArrowUp' ? RAIL_ORDER[(i - 1 + n) % n]
        : e.key === 'Home' ? RAIL_ORDER[0]
          : e.key === 'End' ? RAIL_ORDER[n - 1]
            : undefined
    if (next === undefined) return
    e.preventDefault()
    setView(next)
    // 指南视图按需渲染，但轨上的按钮常驻——同步查到即可聚焦
    railRef.current?.querySelector<HTMLElement>(`[data-view="${next}"]`)?.focus()
  }
  const navButton = (item: NavItem): ReturnType<typeof createElement> =>
    createElement('button', {
      key: item.k,
      className: 'tk-navitem',
      type: 'button',
      'data-view': item.k,
      'aria-pressed': view === item.k,
      onClick: () => setView(item.k),
    },
      createElement('span', { className: 'tk-ic', 'aria-hidden': true, dangerouslySetInnerHTML: { __html: item.icon } }),
      createElement('span', { className: 'tk-navlabel' }, item.label),
      item.badge !== undefined
        ? createElement('span', { className: `tk-badge${item.hot === true ? ' tk-badge-hot' : ''}`, title: item.badgeTitle }, String(item.badge))
        : null,
    )

  // ---- 视图头（15px 标题 + 一句副标 + 视图级动作）与视图壳（hidden 视图 display:none + hidden 属性）----
  type Node = ReturnType<typeof createElement> | null
  const head = (k: WorkView, title: string, sub: string, actions: Node[]): ReturnType<typeof createElement> =>
    createElement('div', { className: 'tk-head' },
      createElement('div', { className: 'tk-head-text' },
        createElement('h2', { className: 'tk-h', id: headId(k) }, title),
        createElement('p', { className: 'tk-p' }, sub),
      ),
      actions.some((a) => a !== null) ? createElement('div', { className: 'tk-head-acts' }, ...actions) : null,
    )
  // 横幅/引导条只渲染一份：挂在当前视图头下（头部常驻，视图体内滚）
  const stripNodes: Node[] = [
    error !== null ? createElement('div', { key: 'err', className: 'bt-banner bt-banner-err' }, error) : null,
    notice !== null ? createElement('div', { key: 'notice', className: 'bt-banner bt-banner-info' }, notice) : null,
    // 新手三步引导条（仅浮层挂载；「知道了」后 localStorage 记住不再出现）
    bounded === true && onboardGone === false
      ? createElement('div', { key: 'onboard', className: 'bt-card', style: { borderColor: 'var(--bt-a)' } },
          createElement('div', { style: { display: 'grid', gap: 4, fontSize: 12 } },
            createElement('span', { style: { fontWeight: 600 } }, t('popoverSubtitle')),
            createElement('span', null, `① ${t('onboard1')} → ② ${t('onboard2')} → ③ ${t('onboard3')}`),
          ),
          createElement('div', { style: { display: 'flex', justifyContent: 'flex-end', marginTop: 6 } },
            createElement('button', {
              className: 'bt-btn bt-btn-xs',
              onClick: () => {
                setOnboardGone(true)
                try { localStorage.setItem('dsh-takeover-onboard', '1') } catch { /* 隐私模式 */ }
              },
            }, t('onboardDone')),
          ),
        )
      : null,
  ]
  const strips = stripNodes.some((n) => n !== null) ? createElement('div', { className: 'tk-strips' }, ...stripNodes) : null
  const section = (k: WorkView, title: string, sub: string, actions: Node[], body: Node[]): ReturnType<typeof createElement> =>
    createElement('section', {
      key: k,
      className: `tk-view${view === k ? ' tk-view-on' : ''}${k === 'guide' ? ' tk-view-guide' : ''}`,
      'data-v': k,
      'aria-labelledby': headId(k),
      hidden: view !== k,
    },
      head(k, title, sub, actions),
      view === k ? strips : null,
      createElement('div', { className: 'tk-scroll' }, ...body),
    )

  // ---- 收件箱概览瓦片（DESIGN.md §4）：待取件/已存档/进展可查证/信封附件/拒收，
  //      语义色左缘 品牌紫/绿/绿/紫/红；重复文件为防御计数，>0 才出第六枚（黄） ----
  const tile = (key: string, value: string, label: string, color: string, tone: '' | 'ok' | 'warn' | 'err', title: string): ReturnType<typeof createElement> =>
    createElement('div', { key, className: `tk-tile${tone !== '' ? ` tk-tile-${tone}` : ''}`, style: { '--tk-tc': color }, title },
      createElement('span', { className: 'tk-tile-lab' }, label),
      ' ',
      createElement('b', { className: 'tk-tile-num' }, value),
    )
  const rejected = rejectionCount(state)
  const tiles = state === null
    ? null
    : createElement('div', { className: 'tk-tiles' },
        tile('pending', String(state.pending.length), t('tilePending'), 'var(--tk-a)', '', t('pendingDirHint')),
        tile('archived', String(archivedCount), t('tileArchived'), 'var(--tk-ok)', '', t('archivedDirHint')),
        coverage !== null ? tile('coverage', coverage, t('tileCoverage'), 'var(--tk-ok)', 'ok', t('coverageBadgeTitle')) : null,
        envelopeChars !== null ? tile('envelope', humanChars(envelopeChars), t('tileEnvelope'), 'var(--tk-a2)', '', t('envelopeArchivedTitle', { n: envelopeChars })) : null,
        tile('rejected', String(rejected), t('tileRejected'), 'var(--tk-err)', rejected > 0 ? 'err' : '',
          rejected > 0 ? `${t('rejectionsTitle')}；${rejectionTitle(state)}` : t('rejectionsTitle')),
        (state.pendingDuplicates ?? 0) > 0
          ? tile('dup', String(state.pendingDuplicates), t('tileDup'), 'var(--tk-warn)', 'warn', t('pendingDupTitle'))
          : null,
      )

  // ---- 收件箱视图级动作：即时过滤（`/` 与 Cmd/Ctrl+K 聚焦，见 onRootKeyDown）+ 清空已消费（二次确认）+ 导出▾菜单 ----
  const inboxActions: Node[] = [
    state !== null
      ? createElement('input', {
          key: 'filter',
          ref: filterRef,
          className: 'bt-filter',
          type: 'search',
          value: query,
          placeholder: t('filterPlaceholder'),
          'aria-label': t('filterAria'),
          // 快捷键写进 title（可发现性，§7 DON'T「为极简砍可发现性」）
          title: `${t('filterAria')} · ${t('filterShortcut')}`,
          onChange: (e: { target: { value: string } }) => { setQuery(e.target.value) },
          // 有字时 Escape 先清空并截断（各浏览器一致，不靠 Chrome 的 search 原生清空）；
          // 清空后再按 Escape 才冒泡到浮层壳去关闭（DESIGN.md §5 模态契约）
          onKeyDown: (e: { key: string; preventDefault(): void; stopPropagation(): void }) => {
            if (e.key === 'Escape' && query !== '') { e.preventDefault(); e.stopPropagation(); setQuery('') }
          },
        })
      : null,
    createElement('button', {
      key: 'clear',
      className: `bt-btn bt-btn-danger${confirmClear ? ' bt-btn-confirm' : ''}`,
      disabled: clearBusy || takeBusyId !== null || archivedCount === 0,
      onClick: clear,
      title: t('clearArchivedTitle'),
    }, confirmClear ? t('clearConfirm', { n: archivedCount }) : t('clearArchived')),
    state !== null
      ? createElement('div', { key: 'export', className: 'bt-export-wrap' },
          createElement('button', {
            className: 'bt-btn',
            disabled: state.pending.length === 0,
            'aria-haspopup': 'menu',
            'aria-expanded': exportMenu,
            onClick: () => setExportMenu((v) => !v),
            title: t('exportMenuAria'),
          }, t('exportMenu')),
          exportMenu ? createElement('div', {
            className: 'bt-export-mask',
            onClick: () => setExportMenu(false),
          }) : null,
          exportMenu ? createElement('div', { className: 'bt-export-menu', role: 'menu' },
            createElement('button', {
              className: 'bt-export-item',
              role: 'menuitem',
              disabled: state.pending.length === 0,
              onClick: () => { setExportMenu(false); exportAll() },
              title: t('exportAllTitle'),
            }, t('exportAll')),
            createElement('button', {
              className: 'bt-export-item',
              role: 'menuitem',
              onClick: () => { setExportMenu(false); exportHtmlReport() },
              title: t('exportHtmlTitle'),
            }, t('exportHtml')),
          ) : null,
        )
      : null,
  ]
  const inboxBody: Node[] = [
    tiles,
    state !== null
      ? createElement(PendingList, {
          rows: state.pending,
          query,
          home: state.home,
          t,
          lang,
          onExport: exportOne,
          onChainFilter: (id: string) => { setQuery(id) },
          onTakeInbox: takeInbox,
          takeBusyId,
          onDismiss: dismiss,
          dismissBusyId,
        })
      // state 未到位：3 条骨架条占位（E 批）——比「加载」纯文字更接近成卡后的版面
      : createElement('div', { style: { display: 'grid', gap: 8, padding: '4px 0' } },
          createElement('div', { className: 'bt-skeleton', style: { width: '100%' } }),
          createElement('div', { className: 'bt-skeleton', style: { width: '70%' } }),
          createElement('div', { className: 'bt-skeleton', style: { width: '45%' } }),
        ),
  ]

  return createElement('div', { className: `bt-panel${bounded === true ? ' bt-bounded' : ''}`, style: themeVars(true), ref: rootRef, onKeyDown: onRootKeyDown },
    createElement('style', null, CSS),

    // 右侧栏挂载时的 slim 头卡：标识 + 手动刷新（设置卡内嵌时头卡由 Panel 提供）
    chrome
      ? createElement('div', { className: 'bt-card' },
          createElement('div', { className: 'bt-head' },
            createElement('span', { className: 'bt-logo', dangerouslySetInnerHTML: { __html: ICON_SVG } }),
            createElement('span', { className: 'bt-title-sec' }, t('sidebarTabTitle')),
            createElement('span', { className: 'bt-spacer' }),
            createElement('button', { className: 'bt-btn', onClick: reload }, t('refresh')),
          ),
        )
      : null,

    // 工作台本体：左导航轨 148px + 右侧全宽视图（DESIGN.md §5，两栏拼盘废除）
    createElement('div', { className: 'tk-body' },
      createElement('nav', { className: 'tk-rail', 'aria-label': t('navAria'), ref: railRef, onKeyDown: onRailKeyDown },
        createElement('div', { className: 'tk-brand' },
          createElement('span', { className: 'tk-brand-logo', 'aria-hidden': true, dangerouslySetInnerHTML: { __html: ICON_SVG } }),
          createElement('b', null, t('sidebarTabTitle')),
        ),
        ...navItems.map(navButton),
        createElement('div', { className: 'tk-rail-foot' },
          createElement('button', {
            className: 'tk-navitem',
            type: 'button',
            'data-view': 'guide',
            'aria-pressed': view === 'guide',
            onClick: () => setView('guide'),
            title: t('helpTitle'),
          },
            createElement('span', { className: 'tk-ic', 'aria-hidden': true, dangerouslySetInnerHTML: { __html: HELP_SVG } }),
            createElement('span', { className: 'tk-navlabel' }, t('navGuide')),
          ),
          createElement('div', { className: 'tk-ver', title: t('versionTitle') }, `dsh-takeover ${PANEL_VERSION}`),
        ),
      ),
      createElement('div', { className: 'tk-main' },
        section('inbox', t('inboxTitle'), t('viewInboxSub', { n: state?.pending.length ?? '…' }), inboxActions, inboxBody),
        // 浏览窗格 bare+active 自动前置会话最多的可用家（内容默认可见，空态从此不存在）
        section('browse', t('browserTitle'), t('browserHint'), [], [
          createElement(ForeignBrowser, { state, t, lang, onError: (msg) => setError(msg), onNotice: showNotice, navigate, bare: true, active: view === 'browse' }),
        ]),
        section('send', t('sendTitle'), sessionId !== undefined && sessionId !== '' ? t('sendHint') : t('sendHintCopy'), [], [
          createElement(SendCard, { sessionId, t, lang, onError: (msg) => setError(msg), onNotice: showNotice, bare: true }),
        ]),
        section('memory', t('memoryTitle'), t('viewMemorySub'), [], [
          createElement(MemoryCard, { t, lang, onError: (msg) => setError(msg), onNotice: showNotice, onPushed: reload, bare: true, defaultOpen: true, active: view === 'memory' }),
        ]),
        // 上手指南：轨底按钮唤出的第五视图（无状态，按需渲染；展开体不嵌卡片底色，见 .tk-view-guide）
        view === 'guide'
          ? section('guide', t('helpTitle'), t('popoverSubtitle'), [], [createElement(HelpCard, { t })])
          : null,
      ),
    ),
  )
}

/** composer 卡内浮动「接力」chip：一枚小按钮（挂在 conversation.input.activity
 * 座位——composer 卡内部浮动条目），点开向上浮出工作台卡片（帮助 + 收件箱 +
 * 交接出去 + 外部会话浏览器 + 记忆快照）。fixed 透明遮罩点击关闭。
 * 浮层几何按按钮实际位置现算（fixed + 视口夹取）：矮窗限高到按钮上缘以上空间
 * （不够放就改朝下），窄窗左缘夹进视口——不再顶出屏幕外、不再钻进侧栏底下。
 * sessionId 由宿主座位注入（session 级座位的标准参数；交接出去一键用，缺席降级复制路径）。 */
export function ComposerChip({ t, locale, navigate, sessionId }: {
  t: Translate
  locale: LocaleRuntime | undefined
  navigate: (sessionId: string) => boolean
  sessionId?: string
}): ReturnType<typeof createElement> {
  useLocaleSync(locale)
  const [open, setOpen] = useState(false)
  const chipRef = useRef<HTMLButtonElement | null>(null)
  const dialogRef = useRef<HTMLDivElement | null>(null)
  // 浮层定位（0.4.3 起为视口居中模态）：不再锚定 chip——用户明确要「居中」，
  // 且居中定位与宿主滚动完全解耦（不再需要捕获阶段滚动监听）。
  // 只量两个数：宽度分档 + 可用高度（视口 - 上下 16px 边距）。
  const [pos, setPos] = useState<{ maxH: number; width: number } | null>(null)
  const measure = (): void => {
    if (typeof window === 'undefined' || typeof window.innerHeight !== 'number') return
    const vw = window.innerWidth
    const vh = window.innerHeight
    // 宽度分档（视觉审查 P0-1）：大屏放大、中屏定宽、小屏贴边；上限 1180（DESIGN.md §8）
    const width = vw >= 1600 ? Math.min(1180, vw - 48) : vw >= 1200 ? Math.min(1040, vw - 48) : Math.max(360, Math.min(720, vw - 16))
    setPos({ width, maxH: Math.max(240, vh - 32) })
  }
  useEffect(() => {
    if (!open) return
    const onRe = (): void => { measure() }
    window.addEventListener('resize', onRe)
    return () => {
      window.removeEventListener('resize', onRe)
    }
  }, [open])
  // 模态契约（DESIGN.md §5；兑现 role=dialog + aria-modal 的声明）：
  //   打开 → 焦点入壳（落在当前视图的导航项，`/` 立即可用；没有就落关闭钮）；
  //   Tab/Shift+Tab 在壳内圈闭（跳过 hidden 视图与 tabindex=-1）；Escape 关闭；
  //   关闭/卸载 → 焦点归还唤出 chip。监听挂 document：焦点无论在壳内何处都接得住
  useEffect(() => {
    if (!open) return
    const dlg = dialogRef.current
    if (dlg === null) return
    const focusables = (): HTMLElement[] =>
      [...dlg.querySelectorAll<HTMLElement>('a[href], button, input, select, textarea, [tabindex]')]
        .filter((el) => !(el as { disabled?: boolean }).disabled
          && el.getAttribute('tabindex') !== '-1'
          && el.closest('[hidden]') === null)
    const t0 = window.setTimeout(() => {
      const first = dlg.querySelector<HTMLElement>('.tk-navitem[aria-pressed="true"]') ?? dlg.querySelector<HTMLElement>('.tk-close')
      first?.focus()
    }, 0)
    const onKey = (e: KeyboardEvent): void => {
      if (e.key === 'Escape') {
        if (e.defaultPrevented) return // 过滤框有字时先清空（WorkspaceBody 已截断），不关壳
        e.preventDefault()
        setOpen(false)
        return
      }
      if (e.key !== 'Tab') return
      const list = focusables()
      if (list.length === 0) return
      const first = list[0] as HTMLElement
      const last = list[list.length - 1] as HTMLElement
      const active = document.activeElement
      const inside = active !== null && dlg.contains(active)
      if (e.shiftKey) {
        if (!inside || active === first) { e.preventDefault(); last.focus() }
      } else if (!inside || active === last) {
        e.preventDefault(); first.focus()
      }
    }
    document.addEventListener('keydown', onKey)
    return () => {
      window.clearTimeout(t0)
      document.removeEventListener('keydown', onKey)
      chipRef.current?.focus()
    }
  }, [open])
  return createElement('div', { style: { position: 'relative', display: 'inline-flex' } },
    // ghost 样式对齐宿主 composer 原生控件（无边框/次级标签色/悬停浅底），
    // 颜色直接吃宿主 dsw alias 变量；<style> 就地注入——chip 挂载点在
    // WorkspaceBody 之外，收起态没有面板的 style 块可用
    createElement('style', null, '.bt-chip{display:inline-flex;align-items:center;gap:5px;background:transparent;'
      + 'color:var(--dsw-alias-label-secondary,inherit);border:none;cursor:pointer;font-size:13px;font-family:inherit;'
      + 'padding:5px 8px;border-radius:8px;transition:background-color .1s;line-height:1}'
      + '.bt-chip:hover,.bt-chip[data-open="true"]{background:var(--dsw-alias-interactive-bg-hover,rgba(127,127,127,.14))}'
      + '.bt-chip svg{width:13px;height:13px;display:block}'),
    createElement('button', {
      className: 'bt-chip',
      'data-open': String(open),
      ref: chipRef,
      onClick: () => {
        if (!open) measure() // 打开瞬间先量好几何，首帧就位（避免闪到旧位置）
        setOpen((v) => !v)
      },
      title: t('sidebarTabDesc'),
    },
      createElement('span', {
        style: { width: 13, height: 13, display: 'inline-block', opacity: 0.9 },
        dangerouslySetInnerHTML: { __html: ICON_SVG },
      }),
      t('sidebarTabTitle'),
    ),
    open ? createElement('div', {
      style: { position: 'fixed', inset: 0, zIndex: 9998, background: 'rgba(0,0,0,.32)' },
      onClick: () => setOpen(false),
    }) : null,
    open ? createElement('div', {
      ref: dialogRef,
      role: 'dialog',
      'aria-modal': true,
      'aria-label': t('popoverTitle'),
      style: {
        // DESIGN.md §2/§6 token 行内展开：壳在 .bt-panel 的 <style> 作用域之外，
        // var(--tk-*) 要在这一层可解析（同一份 TK_TOKENS，不另写色值）
        ...TK_TOKENS,
        position: 'fixed', zIndex: 9999,
        boxSizing: 'border-box', // maxHeight 必须含 padding+border，否则矮窗仍溢出视口（实测 583>568）
        // 视口居中模态（inset:0 + margin:auto + fit-content：双轴居中，maxHeight
        // 受尊重且与宿主滚动完全解耦——不再锚定 chip 位置）
        inset: 0, margin: 'auto', height: 'fit-content',
        // 整体不滚（overflow hidden）：滚动责任下沉到 .bt-bounded/.tk-scroll——
        // 导航轨与视图头常驻，视图体内滚
        display: 'flex', flexDirection: 'column', overflow: 'hidden',
        ...(pos !== null
          ? { width: pos.width, maxHeight: pos.maxH }
          : { width: 'min(1040px, calc(100vw - 16px))', maxHeight: '70vh' }),
        // 壳 = canvas 近黑画布 + 顶部品牌径向辉光（§2）；line 描边；唯一投影（§6）
        background: 'var(--tk-canvas-bg)',
        color: 'var(--tk-text)',
        border: '1px solid var(--tk-line)', borderRadius: 16,
        boxShadow: 'var(--tk-shadow), inset 0 1px 0 rgba(255,255,255,.05)',
        padding: 0,
      },
    },
      // 顶边 3px 品牌渐变条（模态身份标识，保留）
      createElement('div', { 'aria-hidden': true, style: { height: 3, flex: 'none', background: 'var(--tk-edge-grad)', opacity: 0.9 } }),
      // dialog 可及名的可见落点：壳内可见文字只剩导航轨「接力」，完整标题走读屏专用节点
      createElement('h2', { className: 'tk-sr' }, t('popoverTitle')),
      createElement('button', {
        className: 'tk-close',
        type: 'button',
        onClick: () => setOpen(false),
        'aria-label': 'close',
        title: t('closeBtn'),
      }, '✕'),
      createElement(PanelBoundary, {
        t,
        // 这层包装是壳与 bt-bounded 之间的 flex 中继：不给 flex:1/minHeight:0 的话
        // 默认 min-height:auto 挡住收缩链，bt-bounded 撑到内容高，视图体内滚失效（真机实测）
        children: createElement('div', { style: { display: 'flex', flexDirection: 'column', flex: '1 1 auto', minHeight: 0, overflow: 'hidden' } },
          createElement(WorkspaceBody, { t, locale, navigate, chrome: false, sessionId, bounded: true }),
        ),
      }),
    ) : null,
  )
}

/** 设置卡页签键（DESIGN.md §4 设置卡页签：命令速览 / 支持矩阵 / 开关语义）；数组顺序即方向键遍历序 */
type SettingsTab = 'cmds' | 'matrix' | 'sem'
const SETTINGS_TABS: readonly SettingsTab[] = ['cmds', 'matrix', 'sem']

export function Panel({ t, locale, navigate, slim }: { t: Translate; locale: LocaleRuntime | undefined; navigate: (sessionId: string) => boolean; /** true = 工作台面已挂进会话输入区上方，设置卡只留设置与指引（座位注册失败时降级为 false 内嵌工作台） */ slim: boolean }): ReturnType<typeof createElement> {
  useLocaleSync(locale)
  const { state, setState, error, setError, reload, generationRef } = useTakeoverPolling()
  // 每家开关的操作中态（矩阵行级禁用）
  const [busy, setBusy] = useState<string | null>(null)
  // 新手 FAQ 显隐（头行 [?] 按钮切换，默认隐藏不占行）
  const [showHelp, setShowHelp] = useState(false)
  // 设置卡页签：默认停在命令速览；三面板常驻挂载、hidden 切换（切页不丢矩阵开关的操作中态，禁止长滚动）
  const [tab, setTab] = useState<SettingsTab>('cmds')
  // tab/panel id 前缀：同页多实例不撞 id，aria-controls / aria-labelledby 才能准确互指
  const uid = useId()
  const panelRef = useRef<HTMLDivElement | null>(null)
  const tabsRef = useRef<HTMLDivElement | null>(null)

  const toggle = (name: string, enabled: boolean): void => {
    setBusy(name)
    const gen = ++generationRef.current
    void post<{ ok: true; state: TakeoverState }>('/dsh-takeover/provider', { provider: name, enabled })
      .then((r) => {
        if (gen !== generationRef.current) return
        setState(r.state); setError(null)
      })
      .catch((e: unknown) => {
        if (gen !== generationRef.current) return
        setError(e instanceof Error ? e.message : String(e))
      })
      .finally(() => { setBusy(null) })
  }

  const tabId = (k: SettingsTab): string => `${uid}tab-${k}`
  const paneId = (k: SettingsTab): string => `${uid}pane-${k}`
  const tabLabel: Record<SettingsTab, string> = { cmds: t('tabCmds'), matrix: t('tabMatrix'), sem: t('tabSemantics') }
  // WAI-ARIA tabs 键盘流：←/→ 循环、Home/End 首尾；选中即切面板，焦点随之移动（roving tabindex）
  const onTabsKeyDown = (e: { key: string; preventDefault: () => void }): void => {
    const i = SETTINGS_TABS.indexOf(tab)
    const n = SETTINGS_TABS.length
    const next = e.key === 'ArrowRight' ? SETTINGS_TABS[(i + 1) % n]
      : e.key === 'ArrowLeft' ? SETTINGS_TABS[(i - 1 + n) % n]
        : e.key === 'Home' ? SETTINGS_TABS[0]
          : e.key === 'End' ? SETTINGS_TABS[n - 1]
            : undefined
    if (next === undefined) return
    e.preventDefault()
    setTab(next)
    tabsRef.current?.querySelector<HTMLElement>(`[data-tab="${next}"]`)?.focus()
  }
  const pane = (k: SettingsTab, ...body: Array<ReturnType<typeof createElement> | null>): ReturnType<typeof createElement> =>
    createElement('div', {
      key: k,
      id: paneId(k),
      className: `tk-pane${tab === k ? ' tk-pane-on' : ''}`,
      role: 'tabpanel',
      'aria-labelledby': tabId(k),
      hidden: tab !== k,
    }, ...body)

  return createElement('div', { className: 'bt-panel', ref: panelRef, style: themeVars() },
    createElement('style', null, CSS),

    // 设置卡本体（DESIGN.md §4 / 原型窗口 2）：自铺近黑画布的指挥台块；--bt-* 行内恒走暗轴
    // （浅色宿主页里不翻白，同工作台内嵌处理）。头行 = 标识 + 分段器 + [?]/刷新；下接三段页签面板
    createElement('div', { className: 'tk-set', style: themeVars(true) },
      createElement('div', { className: 'tk-set-head' },
        createElement('span', { className: 'tk-set-logo', 'aria-hidden': true, dangerouslySetInnerHTML: { __html: ICON_SVG } }),
        createElement('span', { className: 'tk-set-text' },
          createElement('div', { className: 'tk-set-title' }, t('appTitle')),
          createElement('div', { className: 'tk-set-sub', title: t('appSubtitle') }, t('appSubtitle')),
        ),
        // 分段器（3px 内距容器 + 7px 圆角页签，选中品牌渐变）：button[role=tab] + aria-selected/aria-controls
        createElement('div', { className: 'tk-tabs', role: 'tablist', 'aria-label': t('tabsAria'), ref: tabsRef, onKeyDown: onTabsKeyDown },
          ...SETTINGS_TABS.map((k) => createElement('button', {
            key: k,
            id: tabId(k),
            className: 'tk-tab',
            type: 'button',
            role: 'tab',
            'data-tab': k,
            'aria-selected': tab === k,
            'aria-controls': paneId(k),
            tabIndex: tab === k ? 0 : -1,
            onClick: () => { setTab(k) },
          }, tabLabel[k])),
        ),
        createElement('span', { className: 'tk-set-acts' },
          createElement('button', {
            className: `bt-btn bt-btn-xs${showHelp ? ' bt-chip-on' : ''}`,
            type: 'button',
            // 同浮层 [?]：打开时把帮助卡滚进视口，长页面里否则看不见变化
            onClick: () => {
              const next = !showHelp
              setShowHelp(next)
              if (next) {
                window.setTimeout(() => {
                  panelRef.current?.querySelector('[data-help-card]')?.scrollIntoView({ block: 'start' })
                }, 0)
              }
            },
            'aria-label': 'help',
            title: t('helpTitle'),
            style: { minWidth: 26 },
          }, '?'),
          createElement('button', { className: 'bt-btn', type: 'button', onClick: reload, disabled: busy !== null }, t('refresh')),
        ),
      ),
      error !== null ? createElement('div', { className: 'bt-banner bt-banner-err' }, error) : null,

      // 命令速览：数据源不变（/handoff · /inbox · /resume-*），mono 键 + 说明文案
      pane('cmds',
        createElement('div', { className: 'tk-pane-lead' }, t('cmdBadge')),
        createElement(CommandsGrid, { state, t }),
      ),
      // 支持矩阵（九家读取器）
      pane('matrix',
        state !== null
          ? createElement(ProviderMatrix, { rows: state.providers, busy, onToggle: toggle, t })
          : createElement('div', { className: 'bt-sub' }, t('loading')),
      ),
      // 开关语义：开关行为 + 状态 pill 口径（绿支持 / 黄待确认 / 黄不可用）
      pane('sem',
        createElement('div', { className: 'tk-sem' },
          createElement('p', null, t('noteBody')),
          createElement('p', null, t('noteBodyPending')),
        ),
      ),
    ),

    // 工作台去留（页签外常驻，不留死入口）：宿主 0.2 右侧栏/composer 挂载时（slim）一行指引指向
    // 输入框「接力」按钮；老宿主（座位缺席）降级内嵌工作台——收件箱概览在其收件箱视图，行为与旧版一致
    slim
      ? createElement('div', { className: 'bt-card' },
          createElement('div', { className: 'bt-sub' }, t('settingsPointer')),
        )
      : createElement(WorkspaceBody, { t, locale, navigate, chrome: false }),

    // 新手帮助 / FAQ（头行 [?] 按钮切换，默认隐藏不占行）
    showHelp ? createElement(HelpCard, { t }) : null,
  )
}

export function apply(ctx: Context): void {
  // 防御：宿主若没有 slots 服务（SlotRegistry 形态不符）只告警降级，
  // 不把整个客户端插件树拖崩。
  const slots: unknown = ctx.slots
  if (
    slots === null || typeof slots !== 'object'
    || typeof (slots as { inject?: unknown }).inject !== 'function'
    || typeof (slots as { register?: unknown }).register !== 'function'
  ) {
    console.warn('[dsh-takeover] 宿主未提供可用的 slots 服务（需要 @deepseek-ai/dsh-client-ui-renderer），设置卡跳过挂载')
    return
  }
  // 工作台挂载面：composer 卡内部的 conversation.input.overlay 座位（浮动条目，
  // 与消息反馈对话框同座）。与设置卡同走 slots 服务。注意时序：本插件在 profile
  // bundle 序里先于 web-app 激活，apply 时点该座位可能尚未声明（实测 inject 会抛）
  // ——用 ctx.effect 延后到启动完成再注册，另加 3s 重试兜底。始终失败（老宿主座位
  // 缺席）→ chipReady 保持 false → 设置卡内嵌工作台，行为不倒退。
  let chipReady = false
  const registerChip = (): void => {
    if (chipReady) return
    try {
      // 绑定后调用：slots 服务对象经属性访问现取（getter），把方法抽成局部函数
      // 再调用会丢 this（实测 TypeError: Cannot read properties of undefined
      // (reading 'ctx')）——必须 bind 或直接以方法形式调用。
      const injectSeat = (ctx.slots.inject as (this: unknown, name: string, fn: (...args: unknown[]) => unknown, label?: string) => void).bind(ctx.slots)
      const registerSeat = (ctx.slots.register as (this: unknown, metadata: Record<string, unknown>, body: (...args: unknown[]) => unknown) => unknown).bind(ctx.slots)
      // session 级座位把 sessionId 递给注入方（位置参数）与渲染体（标准 props）——
      // 两处形态都防御式接（老宿主不给 → undefined → 交接出去卡走复制路径）
      const sessionIdOf = (arg: unknown): string | undefined => {
        if (typeof arg === 'string' && arg !== '') return arg
        if (arg !== null && typeof arg === 'object') {
          const v = (arg as { sessionId?: unknown }).sessionId
          if (typeof v === 'string' && v !== '') return v
        }
        return undefined
      }
      injectSeat('conversation.input.activity', (injectSession?: unknown) => registerSeat(
        { name: 'conversation.input.activity', id: 'dsh-takeover' },
        (...seatArgs: unknown[]) => {
          const chipT = makeT(ctx)
          const sessionId = sessionIdOf(seatArgs[0]) ?? sessionIdOf(injectSession)
          return createElement(ComposerChip, { t: chipT, locale: resolveLocale(ctx), navigate: uiNavigatorOf(ctx), sessionId })
        },
      ), 'dsh-takeover: takeover composer chip')
      chipReady = true
    } catch (e) {
      const msg = e instanceof Error ? (e.stack ?? e.message) : String(e)
      console.warn('[dsh-takeover] takeover chip registration failed; settings card keeps the work zones', e)
    }
  }
  const effectFn = (ctx as unknown as { effect?: (fn: () => void, label?: string) => void }).effect
  const registerChipWithRetry = (): void => {
    registerChip()
    if (!chipReady) (globalThis as { setTimeout?: (fn: () => void, ms: number) => unknown }).setTimeout?.(() => registerChip(), 3000)
  }
  if (typeof effectFn === 'function') {
    effectFn.call(ctx, registerChipWithRetry, 'dsh-takeover: takeover chip registration')
  } else {
    registerChipWithRetry()
  }
  ctx.slots.inject('settings.section', () => ctx.slots.register(
    { name: 'settings.section', id: 'dsh-takeover', order: 42, label: 'dsh-takeover' },
    () => {
      const t = makeT(ctx)
      return createElement(PanelBoundary, {
        t,
        children: createElement(Panel, { t, locale: resolveLocale(ctx), navigate: uiNavigatorOf(ctx), slim: chipReady }),
      })
    },
  ))
}
