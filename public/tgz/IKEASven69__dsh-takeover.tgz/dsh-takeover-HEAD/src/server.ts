/**
 * host 侧 /dsh-takeover/ JSON API（webServer 路由桥）：
 *   GET  /dsh-takeover/state           设置卡状态（收件箱概览 + 支持矩阵）
 *   GET  /dsh-takeover/sessions        外部会话浏览列表 ?provider=&limit=（轻量发现层，不读内容）
 *   GET  /dsh-takeover/session-preview 单会话结构化预览 ?provider=&reference=（摘要+骨架素材，不吐原文轮次）
 *   POST /dsh-takeover/takeover        一键接管/取件 {mode, provider?, reference?}——宿主会话控制器建新会话并投递指令
 *   POST /dsh-takeover/provider        切 provider 开关 {provider, enabled}
 *   POST /dsh-takeover/clear-archived  清空 archived/
 *   POST /dsh-takeover/dismiss-pending 忽略一张待取件卡 {id}——原样移入 archived/（审计轨迹保留，不计消费）
 * POST 一律过同源守卫；响应 { ok, ... } 规范值，失败不抛异常。
 * @module dsh-takeover/server
 */

import type { IncomingMessage, ServerResponse } from 'node:http'
import { randomUUID } from 'node:crypto'
import { closeSync, existsSync, openSync, readSync } from 'node:fs'
import type { Context } from '@deepseek-ai/cordis'
// Type-only: pulls the Context.webServer merge（宿主由 web bundle 提供，不打进产物）。
import type {} from '@deepseek-ai/dsh-host-webserver'
import { defaultForeignReaders, foreignResolveOne, foreignSessionPreview, foreignSessionsList, type ForeignProvider } from './foreign.ts'
import { depositCommand, outboundCommand, OUTBOUND_LABELS, takeoverCommand, type Lang, type SessionRowLike } from './browser-view.ts'
import { writeRelayProvenance } from './relay-records.ts'
import { pushMemoryCard, scanMemorySources } from './memory.ts'
import { buildState, clearArchived, dismissPending, isProviderEnabled, setProviderEnabled } from './settings.ts'

function sendJson(response: ServerResponse, code: number, body: unknown): void {
  response.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
  response.end(JSON.stringify(body))
}

// ---------------------------------------------------------------------------
// 列表标题增强（文件系会话缺人类标题时的头窥取）：读文件头 64KB 找首条用户
// 消息文本。尽力而为——任何一步失败回空串按原行展示，列表页永不因此变慢报错。
// ---------------------------------------------------------------------------

/** 判「没有人类标题」：空串 / 标题就是 id（或其文件名 stem）/ UUID 形态 */
export function looksUntitled(r: SessionRowLike): boolean {
  if (r.kind !== 'file') return false
  const base = r.id.split(/[\\/]/).pop() ?? ''
  const stem = base.replace(/\.jsonl$/i, '')
  return r.title === '' || r.title === r.id || r.title === base || r.title === stem || /^[0-9a-f]{8}-[0-9a-f]{4}/i.test(r.title)
}

/** 头窥标题：首条含 "type":"user" 的行里抠 text / content 字符串值（JSON 转义最简还原） */
export function sniffTitle(id: string): string {
  try {
    if (!id.toLowerCase().endsWith('.jsonl') || !existsSync(id)) return ''
    const fd = openSync(id, 'r')
    try {
      const buf = Buffer.alloc(65536)
      const n = readSync(fd, buf, 0, 65536, 0)
      for (const line of buf.toString('utf-8', 0, n).split('\n')) {
        if (!line.includes('"type":"user"')) continue
        const raw = /"text":"((?:[^"\\]|\\.)*)"/.exec(line)?.[1]
          ?? /"content":"((?:[^"\\]|\\.)*)"/.exec(line)?.[1]
        if (raw === undefined || raw.trim() === '') continue
        const text = raw
          .replace(/\\n/g, ' ')
          .replace(/\\"/g, '"')
          .replace(/\\u[0-9a-fA-F]{4}/g, '')
          .replace(/\\t/g, ' ')
          .trim()
        if (text !== '') return text.slice(0, 80)
      }
    } finally { closeSync(fd) }
  } catch { /* 尽力而为 */ }
  return ''
}

/** Host 头是否指向本机回环。面板只服务本机：DNS rebinding 下 Host 是攻击者域，
 * 与 Origin 同域比对无法识别——直接要求 Host 是回环（127.0.0.1/[::1]/localhost）。 */
function loopbackHost(host: string): boolean {
  const h = host.toLowerCase()
  const hostname = h.startsWith('[') ? h.slice(0, h.indexOf(']') + 1) : h.split(':')[0] ?? h
  return hostname === '127.0.0.1' || hostname === '::1' || hostname === '[::1]' || hostname === 'localhost'
}

/** TCP 对端是否本机回环。请求头（Host/Origin/Sec-Fetch-Site）对非浏览器客户端全部可伪造，
 * 唯一伪造不了的是连接本身：宿主按一等配置可能绑 0.0.0.0（LAN 可达），此时只看头部等于没防——
 * 连接源地址不是回环一律 403，与头部无关。导出仅为测试。 */
export function isLoopbackRemote(remoteAddress: string | undefined): boolean {
  if (remoteAddress === undefined) return false
  return remoteAddress === '127.0.0.1' || remoteAddress === '::1'
    || remoteAddress === '::ffff:127.0.0.1'
}

/** provider 开关写队列：读-改-写 config.json 的串行化——两个并发 POST 同基线改写会丢失更新
 * （同时停 A/B 只停了 B），链式串行消除同进程竞态。 */
let providerWriteQueue: Promise<unknown> = Promise.resolve()

/** 同源守卫：带 Origin 的请求必须与 Host 一致，且 Host 必须回环（防跨站 POST 与 rebinding）。
 * 不再裸比 `new URL(origin).host === Host`——Host 头客户端完全可控，等价于没防。 */
function sameOrigin(request: { headers: { origin?: string; host?: string } }): boolean {
  const { origin, host } = request.headers
  if (origin === undefined || host === undefined) return false
  if (!loopbackHost(host)) return false
  try {
    const u = new URL(origin)
    return u.host === host.toLowerCase() && loopbackHost(u.host)
  } catch {
    return false
  }
}

/** 读守卫（GET state）：Host 回环之外，浏览器跨站 no-cors 请求带 Sec-Fetch-Site: cross-site
 * （forbidden header name，页面脚本改不了），非浏览器客户端（curl/CLI）不带该头放行——
 * 监听面在本机回环，Host 已验证。30s 轮询的面板自身 fetch 是 same-origin，不受影响。 */
function readGuard(request: { headers: { host?: string; 'sec-fetch-site'?: string } }): boolean {
  const host = request.headers.host
  if (host === undefined || !loopbackHost(host)) return false
  const site = request.headers['sec-fetch-site']
  return site === undefined || site === 'same-origin' || site === 'none'
}

/** 读取 JSON 请求体（上限 4 KiB，超限拒绝）。 */
function readJsonBody(request: IncomingMessage): Promise<Record<string, unknown>> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    let size = 0
    request.on('data', (chunk: Buffer) => {
      size += chunk.length
      if (size > 4096) {
        reject(new Error('body too large'))
        request.destroy()
        return
      }
      chunks.push(chunk)
    })
    request.on('end', () => {
      try {
        const raw = Buffer.concat(chunks).toString('utf8').trim()
        const parsed: unknown = raw === '' ? {} : JSON.parse(raw)
        // 极端形态防御：null/数组/标量一律归 {}——下游按字段取值，
        // 不让 `body['mode']` 这类访问把 unhandled rejection 打进宿主事件循环
        resolve(
          parsed !== null && typeof parsed === 'object' && !Array.isArray(parsed)
            ? (parsed as Record<string, unknown>)
            : {},
        )
      } catch {
        reject(new Error('invalid JSON body'))
      }
    })
    request.on('error', reject)
  })
}

async function stateBody(): Promise<ReturnType<typeof buildState>> {
  return buildState(await defaultForeignReaders())
}

// ---------------------------------------------------------------------------
// 一键接管：宿主会话控制器的最小面 + 投递核心。
// 访问形态与官方包同款（dsh-schedule 直接 ctx.sessionController；cordis 对
// 未挂载服务的属性访问会 throw——防御式取用，缺席即规范降级）。
// ---------------------------------------------------------------------------

/** 会话控制器最小面（对齐 dsh-api-session-controller 0.2.0-rc.2 的 Remote 形状；多退少补） */
export interface SessionControllerLike {
  create(request?: { cwd?: string; workspaceId?: string }): Promise<{ sessionId: string }>
  rename(request: { sessionId: string; title: string }): Promise<unknown>
  prompt(request: {
    requestId: string
    sessionId: string
    mode: 'queue' | 'steer'
    content: Array<{ type: 'text'; text: string }>
    clientTimeZone?: string
  }, signal?: AbortSignal): Promise<{ accepted: true }>
}

/** 防御式取宿主会话控制器：服务挂在根 ctx（本插件 ctx 未 inject 该服务名，
 * 直接取会 throw「cannot get property without inject」——root 层即可达）。
 * 缺席/形态不符回 undefined（ 规范降级），绝不抛出。 */
export function sessionControllerOf(ctx: unknown): SessionControllerLike | undefined {
  const layers: unknown[] = []
  try { layers.push((ctx as { root?: unknown }).root) } catch { /* root 不可达就试本层 */ }
  layers.push(ctx)
  for (const layer of layers) {
    if (layer === null || typeof layer !== 'object') continue
    try {
      const sc: unknown = (layer as { sessionController?: unknown }).sessionController
      if (sc === null || typeof sc !== 'object') continue
      const o = sc as Record<string, unknown>
      if (typeof o['create'] !== 'function' || typeof o['rename'] !== 'function' || typeof o['prompt'] !== 'function') {
        continue
      }
      return sc as SessionControllerLike
    } catch { /* 该层未注入（without inject），试下一层 */ }
  }
  return undefined
}

export type TakeoverMode = 'take' | 'take_deposit' | 'inbox'

export type TakeoverOutcome =
  | { ok: true; sessionId: string; title: string }
  | { ok: false; error: string; /** create 成功但后续失败的孤儿会话 id（不隐瞒，可循此清理） */ sessionId?: string }

const TAKEOVER_TITLE_MAX = 48
const TAKEOVER_MODES: readonly TakeoverMode[] = ['take', 'take_deposit', 'inbox']

/**
 * 投递核心（可脱离 cordis 单测）：建新会话 → 改可找标题 → queue 模式投递指令。
 * 指令与浏览器复制的载荷同一出处（browser-view 的 takeoverCommand/depositCommand），
 * 「点按钮」和「手动粘贴」永远等价；mode=inbox 投递裸 /inbox（最小输入纪律），
 * 带reference 时升级为定向取件（/inbox + 指明编号——行级按钮必须取那一张）。
 * 任何一步失败回规范错误值；已建会话的 id 随错误带出（不隐瞒孤儿会话）。
 */
export async function admitTakeover(
  controller: SessionControllerLike,
  args: { mode: TakeoverMode; provider?: string; reference?: string; lang?: 'zh' | 'en' },
  deps?: {
    resolve?: typeof foreignResolveOne
    random?: () => string
    /** 停用闸环境（与读路由同口径）：停用家一键接管同样拒绝 */
    env?: Parameters<typeof foreignResolveOne>[2]
    /** 会话查找（可选）：在场时投递成功后向会话日志追加接力溯源记录
     * （依托宿主 ≥0.2.1-alpha.2 的实验性 plugin record API，缺席即跳过） */
    sessions?: { get?: (id: string) => unknown; flush?: (session: unknown) => unknown }
  },
): Promise<TakeoverOutcome> {
  if (!TAKEOVER_MODES.includes(args.mode)) {
    return { ok: false, error: `未知 mode：${String(args.mode)}（支持 ${TAKEOVER_MODES.join(' / ')}）` }
  }
  const lang: 'zh' | 'en' = args.lang === 'en' ? 'en' : 'zh'
  let instruction: string
  let title: string
  // 接力溯源数据（resolve 块内填充；inbox 模式只带卡 id）
  let sourceAgent = ''
  let sourceId = ''
  if (args.mode === 'inbox') {
    const ref = String(args.reference ?? '').trim()
    instruction = ref === '' ? '/inbox' : `/inbox\n取编号 ${ref} 这张卡，消费即取。`
    title = lang === 'en' ? 'Inbox pickup' : '收件箱取件'
  } else {
    // provider 与解析层同一归一化：传 "ZCode" 解析得过、指令里却会是
    // 无法识别的 /resume-ZCode——先归一化再进指令
    const provider = String(args.provider ?? '').trim().toLowerCase()
    const resolve = deps?.resolve ?? foreignResolveOne
    const resolved = await resolve({ provider, reference: args.reference }, undefined, deps?.env)
    if (!resolved.ok) return resolved
    sourceAgent = provider
    sourceId = resolved.ref.id
    instruction = args.mode === 'take_deposit'
      ? depositCommand(provider, resolved.ref.id, lang)
      : takeoverCommand(provider, resolved.ref.id)
    // 同一会话可被多次接管——标题带分/级时间戳避免树里同名堆积（P1-3）。
    // 手工拼 MM-DD HH:mm：toLocaleString 随 locale 产出 / 或 - 分隔，测试与展示都要确定性
    const d = new Date()
    const p2 = (n: number): string => String(n).padStart(2, '0')
    const stamp = `${p2(d.getMonth() + 1)}-${p2(d.getDate())} ${p2(d.getHours())}:${p2(d.getMinutes())}`
    title = `接管：${resolved.ref.title || resolved.ref.id}（${stamp}）`.slice(0, TAKEOVER_TITLE_MAX)
  }
  let sessionId = ''
  try {
    const created = await controller.create({})
    sessionId = (created as { sessionId?: unknown } | undefined)?.sessionId as string | undefined ?? ''
    if (sessionId === '') {
      return { ok: false, error: '会话创建结果缺少 sessionId（宿主会话控制器形态变化）' }
    }
    const random = deps?.random ?? randomUUID
    await controller.rename({ sessionId, title })
    // prompt 的 @Remote 签名是 (request, signal)——本地直调也要给不中止的 signal
    await controller.prompt({
      requestId: random(),
      sessionId,
      mode: 'queue',
      content: [{ type: 'text', text: instruction }],
    }, new AbortController().signal)
    // 接力溯源双层持久化：保底层写 <HANDOFF_HOME>/relay/<sessionId>.json（本插件
    // 完全可控，跨机随 HANDOFF_HOME 同步）；增益层尽力追加宿主实验性 plugin record
    // （ignorable 事件不进模型上下文，fork/resume 随行；rc.2 无此 API 静默跳过）。
    // 两层任何失败都不影响投递结果。
    const kind = args.mode === 'inbox' ? 'pickup' : args.mode === 'take_deposit' ? 'take_deposit' : 'takeover'
    const provenance = {
      provider: sourceAgent,
      sourceId,
      cardId: args.mode === 'inbox' ? args.reference ?? '' : '',
      title,
      at: new Date().toISOString(),
    }
    writeRelayProvenance(sessionId, provenance)
    // 增益层后台追加：非阻塞——投递响应立即返回，后台等会话挂载进 sessions
    // 服务（agent 循环启动即挂载）后写入 plugin record 并 flush。全程尽力而为。
    void (async () => {
      let session: unknown
      for (let i = 0; i < 24 && session === undefined; i++) {
        session = deps?.sessions?.get?.(sessionId)
        if (session === undefined) await new Promise((r) => setTimeout(r, 5000))
      }
      if (session === undefined) return
      const { appendRelayRecord } = await import('./relay-records.ts')
      await appendRelayRecord(session, kind, provenance)
      await deps?.sessions?.flush?.(session)
    })()
    return { ok: true, sessionId, title }
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    // create 已成功的失败（rename/prompt 阶段）：孤儿会话 id 随错误带出，不隐瞒
    return sessionId === ''
      ? { ok: false, error: msg }
      : { ok: false, error: `${msg}（已建会话 ${sessionId}「${title}」，可在会话树删除）`, sessionId }
  }
}

/**
 * 注册 /dsh-takeover/ 前缀路由。webServer 是宿主可选服务（CLI 形态没有），
 * 走 ctx.inject 缺席即跳过，不影响工具与 skill 注册面。
 * opts.takeoverEnv：provider 停用闸（全部路由共用，缺省读真实设置开关；
 * 测试注入假闸——isProviderEnabled 直读真实 HOME，测试不碰）。
 */
export function registerTakeoverRoutes(
  ctx: Context,
  opts?: { takeoverEnv?: { isEnabled: (p: ForeignProvider) => boolean } },
): void {
  /** 会话查找（防御式）：增益层的接力溯源追加用。走 root 上的 sessions 服务
   * （每次属性访问独立 try——注入纪律代理会抛），缺席即整体跳过增益层；
   * 保底溯源写盘不经过这里，投递不受影响。 */
  const rootSessionsOf = (): { get?: (id: string) => unknown } | undefined => {
    const read = (get: () => unknown): unknown => { try { return get() } catch { return undefined } }
    const rootObj = read(() => (ctx as unknown as { root?: unknown }).root) as unknown
    const rootSessions = read(() => (rootObj as { sessions?: unknown })?.sessions)
    const ctxSessions = read(() => (ctx as unknown as { sessions?: unknown }).sessions)
    const cand = (rootSessions ?? ctxSessions) as { get?: unknown } | undefined
    if (cand && typeof cand.get === 'function') return cand as { get: (id: string) => unknown }
    return undefined
  }
  const env = opts?.takeoverEnv ?? { isEnabled: (p: ForeignProvider) => isProviderEnabled(p) }
  // S8 短窗去重：同 (mode|provider|reference) 5 秒内的重复点击复用同一次投递——
  // 双标签页/快速重试不再产生 N 个重复会话；admitTakeover 永不 reject，缓存安全
  const takeoverMemo = new Map<string, { at: number; run: Promise<TakeoverOutcome> }>()
  ctx.inject(['webServer'], (host) => {
    host.effect(() => host.webServer.register({
      kind: 'prefix',
      // 注意不能带尾斜杠：匹配规则是 pathname === prefix 或 startsWith(prefix + '/')，
      // '/dsh-takeover/' 会要求 '/dsh-takeover//' 才命中（先例：前缀不带尾斜杠）。
      path: '/dsh-takeover',
      handler: (request, response) => {
        // 连接级回环闸先行：源地址非本机一律 403（0.0.0.0 绑定下 LAN 请求在此被拒，
        // 头部守卫只对已进门的回环连接继续做浏览器面防护）
        if (!isLoopbackRemote(request.socket.remoteAddress)) {
          sendJson(response, 403, { error: '面板仅服务本机回环连接' })
          return
        }
        const sub = (request.url ?? '/').replace(/^\/dsh-takeover\/?/, '').split('?')[0] ?? ''

        if (sub === 'state') {
          if (request.method !== 'GET') {
            response.writeHead(405, { allow: 'GET' })
            response.end()
            return
          }
          // state 一直全裸（返回 HANDOFF_HOME 绝对路径与卡片预览，且每请求全量扫盘）——补读守卫
          if (!readGuard(request)) {
            sendJson(response, 403, { error: '仅接受本机同源读取' })
            return
          }
          void stateBody().then(
            (state) => { sendJson(response, 200, state) },
            (error: unknown) => { sendJson(response, 500, { error: error instanceof Error ? error.message : String(error) }) },
          )
          return
        }

        if (sub === 'sessions' || sub === 'session-preview') {
          if (request.method !== 'GET') {
            response.writeHead(405, { allow: 'GET' })
            response.end()
            return
          }
          // 与 state 同一读守卫：会话元数据/摘要与卡片预览同级敏感
          if (!readGuard(request)) {
            sendJson(response, 403, { error: '仅接受本机同源读取' })
            return
          }
          const q = new URL(request.url ?? '/', 'http://localhost').searchParams
          // 规范值（含 ok:false）一律 200——停用/未知名是业务结果不是 HTTP 事故；意外异常才 500
          const body: Promise<unknown> = sub === 'sessions'
            ? (() => {
                const limitRaw = Number(q.get('limit') ?? '')
                return foreignSessionsList(
                  { provider: q.get('provider') ?? '', limit: Number.isFinite(limitRaw) && limitRaw > 0 ? Math.floor(limitRaw) : undefined },
                  undefined,
                  env,
                ).then((res) => {
                  // 标题增强：缺人类标题的文件系会话头窥首条用户消息（同步、每行 ≤64KB、失败原样）
                  if (res.ok) {
                    for (const r of res.sessions) {
                      if (!looksUntitled(r)) continue
                      const t = sniffTitle(r.id)
                      if (t !== '') r.title = t
                    }
                  }
                  return res
                })
              })()
            : foreignSessionPreview(
                { provider: q.get('provider') ?? '', reference: q.get('reference') ?? '' },
                undefined,
                env,
              )
          void body.then(
            (r) => { sendJson(response, 200, r) },
            (error: unknown) => { sendJson(response, 500, { ok: false, error: error instanceof Error ? error.message : String(error) }) },
          )
          return
        }

        if (sub === 'takeover') {
          if (request.method !== 'POST') {
            response.writeHead(405, { allow: 'POST' })
            response.end()
            return
          }
          if (!sameOrigin(request)) {
            sendJson(response, 403, { error: '仅接受同源请求' })
            return
          }
          void readJsonBody(request).then(
            (body) => {
              try {
                const controller = sessionControllerOf(ctx)
                if (controller === undefined) {
                  // 规范降级：面板收到后自动退回复制指令路径
                  sendJson(response, 200, { ok: false, error: '宿主缺会话控制器，一键接管不可用——请改用复制指令' })
                  return
                }
                const mode = String(body['mode'] ?? '')
                if (!(TAKEOVER_MODES as readonly string[]).includes(mode)) {
                  sendJson(response, 200, { ok: false, error: `未知 mode：${mode}（支持 ${TAKEOVER_MODES.join(' / ')}）` })
                  return
                }
                const provider = String(body['provider'] ?? '')
                const reference = String(body['reference'] ?? '')
                const lang = body['lang'] === 'en' ? 'en' : 'zh'
                const key = `${mode}|${provider}|${reference}`
                const cached = takeoverMemo.get(key)
                if (cached !== undefined && Date.now() - cached.at < 5000) {
                  void cached.run.then((r) => { sendJson(response, 200, r) })
                  return
                }
                const run = admitTakeover(controller, { mode: mode as TakeoverMode, provider, reference, lang }, { env, sessions: rootSessionsOf() })
                takeoverMemo.set(key, { at: Date.now(), run })
                // 结果落地 10s 后清条目（去重窗 5s 之内仍可命中）：Map 不随使用历史无界增长
                void run.then(
                  (r) => {
                    sendJson(response, 200, r)
                    setTimeout(() => {
                      const cur = takeoverMemo.get(key)
                      if (cur !== undefined && cur.run === run) takeoverMemo.delete(key)
                    }, 10_000)
                  },
                  // admitTakeover 承诺不 reject——此 catch 只兜绝对意外，不让 unhandled rejection 出门
                  (e: unknown) => { sendJson(response, 500, { ok: false, error: e instanceof Error ? e.message : String(e) }) },
                )
              } catch (e) {
                sendJson(response, 500, { ok: false, error: e instanceof Error ? e.message : String(e) })
              }
            },
            (error: unknown) => { sendJson(response, 400, { ok: false, error: error instanceof Error ? error.message : String(error) }) },
          )
          return
        }

        if (sub === 'send') {
          // 交接出去：把寄存指令 queue 进「当前会话」——本会话的 agent 蒸馏寄存后，
          // 卡进共享收件箱，对面按取件指引接手。与 takeover 反向：不建新会话。
          if (request.method !== 'POST') {
            response.writeHead(405, { allow: 'POST' })
            response.end()
            return
          }
          if (!sameOrigin(request)) {
            sendJson(response, 403, { error: '仅接受同源请求' })
            return
          }
          void readJsonBody(request).then(
            (body) => {
              try {
                const lang: 'zh' | 'en' = body['lang'] === 'en' ? 'en' : 'zh'
                // target 是 chips 键（claude/any/…），换算成展示名进指令
                const targetKey = String(body['target'] ?? 'any')
                const targetLabel = (OUTBOUND_LABELS as Record<string, { zh: string; en: string }>)[targetKey]?.[lang] ?? targetKey
                const sessionId = String(body['sessionId'] ?? '').trim()
                if (sessionId === '') {
                  sendJson(response, 200, { ok: false, error: '缺少当前会话 id（老宿主座位不带 sessionId 时走复制路径）', instruction: outboundCommand(lang, targetLabel) })
                  return
                }
                const controller = sessionControllerOf(ctx)
                if (controller === undefined) {
                  // 规范降级：带指令回包，面板自动退回复制路径
                  sendJson(response, 200, { ok: false, error: '宿主缺会话控制器，一键交接不可用——请复制指令粘进输入框', instruction: outboundCommand(lang, targetLabel) })
                  return
                }
                void controller.prompt({
                  requestId: randomUUID(),
                  sessionId,
                  mode: 'queue',
                  content: [{ type: 'text', text: outboundCommand(lang, targetLabel) }],
                }, new AbortController().signal).then(
                  () => { sendJson(response, 200, { ok: true }) },
                  (e: unknown) => {
                    sendJson(response, 200, {
                      ok: false,
                      error: e instanceof Error ? e.message : String(e),
                      instruction: outboundCommand(lang, targetLabel),
                    })
                  },
                )
              } catch (e) {
                sendJson(response, 500, { ok: false, error: e instanceof Error ? e.message : String(e) })
              }
            },
            (error: unknown) => { sendJson(response, 400, { ok: false, error: error instanceof Error ? error.message : String(error) }) },
          )
          return
        }

        if (sub === 'memory-scan') {
          if (request.method !== 'GET') {
            response.writeHead(405, { allow: 'GET' })
            response.end()
            return
          }
          if (!readGuard(request)) {
            sendJson(response, 403, { error: '仅接受本机同源读取' })
            return
          }
          // 只读扫描：清单确定（已知路径逐个探测），不猜测目录内容
          sendJson(response, 200, { ok: true, sources: scanMemorySources() })
          return
        }

        if (sub === 'memory-push') {
          if (request.method !== 'POST') {
            response.writeHead(405, { allow: 'POST' })
            response.end()
            return
          }
          if (!sameOrigin(request)) {
            sendJson(response, 403, { error: '仅接受同源请求' })
            return
          }
          void readJsonBody(request).then(
            (body) => {
              try {
                const keys = Array.isArray(body['keys']) ? body['keys'].map((x: unknown) => String(x)) : undefined
                const result = pushMemoryCard({ keys, target: String(body['target'] ?? ''), title: String(body['title'] ?? '') })
                sendJson(response, 200, result)
              } catch (e) {
                sendJson(response, 500, { ok: false, error: e instanceof Error ? e.message : String(e) })
              }
            },
            (error: unknown) => { sendJson(response, 400, { ok: false, error: error instanceof Error ? error.message : String(error) }) },
          )
          return
        }

        if (sub === 'provider') {
          if (request.method !== 'POST') {
            response.writeHead(405, { allow: 'POST' })
            response.end()
            return
          }
          if (!sameOrigin(request)) {
            sendJson(response, 403, { error: '仅接受同源请求' })
            return
          }
          void readJsonBody(request).then(
            (body) => {
              // 写操作进串行队列：上一个 provider 写完成（含回读 state）才开始下一个
              providerWriteQueue = providerWriteQueue.then(async () => {
                try {
                  const provider = String(body['provider'] ?? '').trim().toLowerCase()
                  const enabled = body['enabled'] === true
                  setProviderEnabled(provider as ForeignProvider | string, enabled)
                  sendJson(response, 200, { ok: true, state: await stateBody() })
                } catch (e) {
                  sendJson(response, 400, { ok: false, error: e instanceof Error ? e.message : String(e) })
                }
              })
            },
            (error: unknown) => { sendJson(response, 400, { ok: false, error: error instanceof Error ? error.message : String(error) }) },
          )
          return
        }

        if (sub === 'clear-archived') {
          if (request.method !== 'POST') {
            response.writeHead(405, { allow: 'POST' })
            response.end()
            return
          }
          if (!sameOrigin(request)) {
            sendJson(response, 403, { error: '仅接受同源请求' })
            return
          }
          try {
            const cleared = clearArchived()
            sendJson(response, 200, { ok: true, cleared })
          } catch (e) {
            sendJson(response, 500, { ok: false, error: e instanceof Error ? e.message : String(e) })
          }
          return
        }

        if (sub === 'dismiss-pending') {
          if (request.method !== 'POST') {
            response.writeHead(405, { allow: 'POST' })
            response.end()
            return
          }
          if (!sameOrigin(request)) {
            sendJson(response, 403, { error: '仅接受同源请求' })
            return
          }
          void readJsonBody(request).then(
            (body) => {
              try {
                const r = dismissPending(String(body['id'] ?? ''))
                sendJson(response, r.ok ? 200 : 400, r)
              } catch (e) {
                sendJson(response, 500, { ok: false, error: e instanceof Error ? e.message : String(e) })
              }
            },
            (error: unknown) => { sendJson(response, 400, { ok: false, error: error instanceof Error ? error.message : String(error) }) },
          )
          return
        }

        sendJson(response, 404, { error: `未知路由：/dsh-takeover/${sub}（支持 state / sessions / session-preview / takeover / provider / clear-archived / dismiss-pending）` })
      },
    }))
  })
}
