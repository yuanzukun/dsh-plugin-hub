import { readFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = dirname(fileURLToPath(import.meta.url))

export async function apply(ctx) {
  const content = await readFile(join(root, 'skills', 'galgame-world', 'SKILL.md'), 'utf8')

  if (!ctx.skills?.register) {
    throw new Error('galgame-dsh-plugin requires the dsh skill capability')
  }

  ctx.skills.register({
    name: 'galgame-world',
    description: 'Run a customizable text-based galgame or otome world with persistent NPCs, relationships, and time.',
    content,
    // The dsh skill registry requires a string `source` when loading a
    // registered skill's body; without it, loading throws
    // "loaded skill source must be a string".
    source: join(root, 'skills', 'galgame-world', 'SKILL.md'),
    invocation: {
      modelInvocable: true,
      userInvocable: true
    }
  })
}
