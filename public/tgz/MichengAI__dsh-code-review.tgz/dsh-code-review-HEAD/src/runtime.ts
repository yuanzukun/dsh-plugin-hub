import { readHostLocale, outputLanguage, translate, type Locale } from './i18n.js';
import { randomUUID } from 'node:crypto';
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { SessionId } from '@deepseek-ai/dsh-session';
import type { SubagentActivation, SubagentResult } from '@deepseek-ai/dsh-subagent';
import { PERSONA_PREFIX_SECTION } from '@deepseek-ai/dsh-system-prompt';
import type {} from '@deepseek-ai/dsh-tools';
import { reviewPrompt, type Target } from './request.js';
import { parseReport, REVIEW_PROMPT, type Report } from './report.js';

// 旧状态仅为历史报告兼容；新运行不再生成快照、过期或插件自定覆盖判断。
export type Status = 'no-changes' | 'completed-clean' | 'completed-findings' | 'completed-text' | 'partial' | 'failed' | 'interrupted' | 'invalid-output' | 'stale';
export interface Outcome { id: string; status: Status; detail: string; fingerprint?: string; base?: string; target?: string; report?: Report; raw?: string }
// 与 Agency 专家一致：角色由 provider 组合，禁止递归召唤专家，权限由宿主委派。
const delegatedTools = ['summon_expert', 'summon_experts', 'list_experts', 'list_expert_teams', 'get_expert_team', 'summon_expert_team'];

function formatAbortReason(reason: unknown, locale: Locale = 'zh'): string {
  const t = (key: Parameters<typeof translate>[1]) => translate(locale, key);
  if (reason instanceof Error) {
    if (reason.name === 'AbortError' || reason.message === 'This operation was aborted') return t('操作已中止。');
    if (reason.name === 'TimeoutError' || /timed?\s*out/i.test(reason.message)) return t('操作超时。');
    return reason.message;
  }
  if (typeof reason === 'string' && reason.trim()) {
    if (reason === 'This operation was aborted') return t('操作已中止。');
    return reason.trim();
  }
  if (typeof reason === 'object' && reason !== null) {
    const obj = reason as Record<string, unknown>;
    if (typeof obj.message === 'string' && obj.message.trim()) return obj.message.trim();
    if (typeof obj.kind === 'string') {
      if (obj.kind === 'user') return t('用户已取消操作。');
      if (obj.kind === 'parent') return t('父级任务已取消。');
      if (obj.kind === 'disposed') return t('会话已销毁。');
      if (obj.kind === 'hook') {
        const detail = typeof obj.reason === 'string' && obj.reason.trim() ? (locale === 'en' ? `: ${obj.reason.trim()}` : `：${obj.reason.trim()}`) : '';
        return `${t('操作已中止')}${detail}${detail ? '' : t('。')}`;
      }
      return `${t('操作已中止。')} (${obj.kind})`;
    }
  }
  return t('操作已中止。');
}

function abortError(signal: AbortSignal, locale: Locale = 'zh'): Error {
  const reason = signal.reason;
  if (reason instanceof Error) {
    if (reason.name === 'AbortError' || reason.message === 'This operation was aborted') {
      return Object.assign(new Error(formatAbortReason(reason, locale)), { name: 'AbortError' });
    }
    return reason;
  }
  return Object.assign(new Error(formatAbortReason(reason, locale)), { name: 'AbortError' });
}

/** 等待 activation 结果；调用方 abort 时立即失败并 fire-and-forget dispose，避免与未协作的 LLM stream 死锁。 */
function awaitActivationResult(activation: SubagentActivation, signal: AbortSignal, locale: Locale = 'zh'): Promise<SubagentResult> {
  if (signal.aborted) {
    void activation.dispose();
    return Promise.reject(abortError(signal, locale));
  }
  return new Promise<SubagentResult>((resolve, reject) => {
    const onAbort = () => {
      void activation.dispose();
      reject(abortError(signal, locale));
    };
    signal.addEventListener('abort', onAbort, { once: true });
    activation.result.then(
      (result) => { signal.removeEventListener('abort', onAbort); resolve(result); },
      (error) => { signal.removeEventListener('abort', onAbort); reject(error); },
    );
  });
}

/**
 * 原生 spawn 独立历史；只发送短任务，Git 和代码检查由子 Agent 自行完成。
 * 角色与工具过滤在子 Agent `agent/created` 时恢复；适配 0.2.2-rc.1 嵌套与 0.2.2-rc.2+ 扁平激活入参。
 */
export async function runReview(ctx: Context, parent: Agent, target: Target, signal: AbortSignal, timeoutMs?: number, reviewModel?: string, locale: Locale = readHostLocale(ctx)): Promise<Outcome> {
  const t = (key: Parameters<typeof translate>[1]) => translate(locale, key);
  const id = randomUUID();
  const combined = timeoutMs === undefined ? signal : AbortSignal.any([signal, AbortSignal.timeout(timeoutMs)]);
  let activation: SubagentActivation | undefined;
  let outcome: Outcome = { id, status: 'failed', detail: t('审查未完成。') };
  let abortedEarly = false;
  try {
    const cwd = parent.session.header.cwd;
    if (!cwd) throw new Error(t('会话没有有效 cwd。'));
    const prompt = await reviewPrompt(target, cwd, combined, locale);
    const provider = ctx.subagents.getProvider('spawn');
    if (!provider || provider.inheritsParentContext) throw new Error(t('需要独立上下文的原生 spawn provider。'));
    const persona = `${REVIEW_PROMPT}\n\n${outputLanguage(locale)}`;
    const deny = delegatedTools.filter(name => ctx.tools.get(name, parent) !== undefined);
    const subagents = ctx.subagents;
    // 低于 0.2.2-rc.1 的宿主没有 startActivation；版本门之外的强制安装会走到这里，
    // 给一句可执行的升级提示，而不是把底层 TypeError 当成审查失败原因回给用户。
    if (typeof (subagents as { startActivation?: unknown }).startActivation !== 'function') {
      throw new Error(t('当前宿主缺少原生子 Agent 启动接口，请升级 DeepSeek Harness 后重试。'));
    }
    const childId = SessionId(randomUUID());
    const stop = ctx.on('agent/created', ({ agent }) => {
      if (agent.id !== childId) return undefined;
      agent.ctx.systemPrompt.section({
        name: PERSONA_PREFIX_SECTION,
        order: agent.ctx.systemPrompt.getSectionOrder('DEPLOYMENT_PERSONA_PREFIX'),
        text: persona,
      });
      if (deny.length) agent.ctx.tools.restrict({ deny });
      return undefined;
    });
    try {
      // `rootOf` 是 0.2.2-rc.2 才出现的服务方法，与「激活入参是否扁平」一一对应：
      // rc.1 无该方法是嵌套 request，rc.2～rc.5 有该方法是扁平入参（npm pack 逐版实测）。
      // 入参形状已被 `as never` 绕开类型检查，守它的是 CI 宿主矩阵；新宿主 RC 发布时先补进矩阵再调整判据。
      const isFlatSpec = typeof (subagents as { rootOf?: unknown }).rootOf === 'function';
      activation = await subagents.startActivation({
        provider: 'spawn',
        label: t('代码审查'),
        childId,
        signal: combined,
        delivery: 'caller',
        ...(isFlatSpec
          ? {
              parent,
              prompt: [{ type: 'text', text: prompt }],
              ...(reviewModel ? { agentOptions: { model: reviewModel } } : {}),
            }
          : {
              request: {
                parent,
                prompt: [{ type: 'text', text: prompt }],
                ...(reviewModel ? { agentOptions: { model: reviewModel } } : {}),
              },
            }),
      } as never);
    } finally {
      stop();
    }
    const result = await awaitActivationResult(activation, combined, locale);
    combined.throwIfAborted();
    if (result.stopReason !== 'completed') throw new Error(`${t('原生子 Agent 未完成：')}${result.stopReason}${result.diagnostic ? ` ${result.diagnostic}` : ''}`);
    const raw = result.output.filter(b => b.type === 'text').map(b => b.text).join('');
    if (!raw.trim()) throw new Error(t('审查 Agent 未返回报告。'));
    const report = parseReport(raw, locale);
    outcome = { id, status: report.format === 'text' ? 'completed-text' : report.findings.length ? 'completed-findings' : 'completed-clean',
      detail: t('审查完成。'), report };
  } catch (error) {
    abortedEarly = combined.aborted;
    let detail = combined.aborted
      ? formatAbortReason(combined.reason, locale)
      : (error instanceof Error ? error.message : formatAbortReason(error, locale));
    const isDomAbort = error instanceof Error && (error.name === 'AbortError' || error.name === 'TimeoutError' || (typeof DOMException !== 'undefined' && error instanceof DOMException));
    if (combined.aborted && error instanceof Error && !isDomAbort && error.message && error.message !== detail) {
      detail = `${detail} (${error.message})`;
    }
    outcome = { ...outcome, status: combined.aborted ? 'interrupted' : 'failed', detail };
  } finally {
    if (activation) {
      try {
        if (abortedEarly) {
          // 中断时 dispose 可能等 LLM；限时等待以便夹具看到无残留，超时则放行。
          await Promise.race([
            activation.dispose(),
            new Promise<void>(resolve => setTimeout(resolve, 2000)),
          ]);
        } else {
          await activation.dispose();
        }
      } catch (error) {
        if (!abortedEarly) outcome = { ...outcome, status: 'failed', detail: `${t('Agent 清理失败：')}${String(error)}` };
      }
    }
  }
  return outcome;
}
