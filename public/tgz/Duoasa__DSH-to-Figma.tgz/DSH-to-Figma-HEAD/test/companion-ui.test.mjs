import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import vm from 'node:vm'

test('metadata and results accept Figma outer-window and parent messages, rejecting foreign senders', async () => {
  const html = await readFile(new URL('../companion/ui.html', import.meta.url), 'utf8')
  const elements = new Map()
  const parent = { postMessage() {} }, top = {}
  const window = {}
  const context = vm.createContext({ window, parent, top, crypto, setInterval() {}, setTimeout(){}, clearTimeout(){}, document: {
    body: {dataset:{}},
    querySelector(selector) {
      if (!elements.has(selector)) elements.set(selector, {})
      return elements.get(selector)
    },
  } })
  vm.runInContext(html.match(/<script>([\s\S]*?)<\/script>/)[1], context)
  const message = { data: { pluginMessage: { type: 'document', name: 'Canvas', editorType: 'figma' } } }
  window.onmessage({ ...message, source: top, origin: 'https://evil.example' })
  assert.equal(elements.get('#document'), undefined)
  window.onmessage({ ...message, source: {}, origin: 'https://www.figma.com' })
  assert.equal(elements.get('#document'), undefined)
  window.onmessage({ ...message, source: top, origin: 'https://www.figma.com' })
  assert.equal(elements.get('#document').textContent, 'Canvas · figma')
  for (const sender of [
    { source: top, origin: 'https://www.figma.com' },
    { source: top, origin: 'https://figma.com' },
    { source: parent, origin: 'null' },
  ]) {
    let received
    context.resolveResult = value => { received = value }
    vm.runInContext("pending.set('job-1', resolveResult)", context)
    const result = { type: 'result', id: 'job-1', ok: true, result: { value: 'readback' } }
    window.onmessage({ source: {}, origin: 'https://www.figma.com', data: { pluginMessage: result } })
    window.onmessage({ source: top, origin: 'https://www.figma.com.evil.example', data: { pluginMessage: result } })
    assert.equal(received, undefined)
    window.onmessage({ ...sender, data: { pluginMessage: result } })
    assert.equal(received, result)
    assert.equal(vm.runInContext("pending.has('job-1')", context), false)
  }
})

test('companion endpoint uses localhost and matches the manifest development allowlist', async () => {
  const html = await readFile(new URL('../companion/ui.html', import.meta.url), 'utf8')
  const manifest = JSON.parse(await readFile(new URL('../companion/manifest.json', import.meta.url), 'utf8'))
  const endpoint = html.match(/const base='([^']+)'/)[1]
  assert.equal(endpoint, 'http://localhost:3055')
  assert.deepEqual(manifest.networkAccess.devAllowedDomains, [endpoint])
  assert.deepEqual(manifest.networkAccess.allowedDomains, ['none'])
})

async function uiHarness(fetcher){
 const html=await readFile(new URL('../companion/ui.html',import.meta.url),'utf8'),elements=new Map(),timers=[],messages=[]
 const element=()=>({value:'',textContent:'',dataset:{},children:[],setAttribute(){},getBoundingClientRect(){return {height:400}},replaceChildren(){this.children=[];this.value=''},appendChild(child){this.children.push(child);if(!this.value)this.value=child.value}})
 const parent={postMessage(message){messages.push(message)}},window={},document={body:{dataset:{}},createElement:element,querySelector(selector){if(!elements.has(selector))elements.set(selector,element());return elements.get(selector)}}
 const ctx=vm.createContext({window,parent,top:{},document,crypto:{getRandomValues:values=>crypto.getRandomValues(values)},URL,AbortSignal,fetch:fetcher,setInterval(){},setTimeout(fn){timers.push(fn);return timers.length},clearTimeout(){}})
 vm.runInContext(html.match(/<script>([\s\S]*?)<\/script>/)[1],ctx)
 const send=message=>window.onmessage({source:parent,origin:'null',data:{pluginMessage:message}})
 const flush=async()=>{for(let i=0;i<6;i++)await new Promise(resolve=>setImmediate(resolve))}
 return {ctx,elements,timers,messages,send,flush,boot:(extra={})=>send({type:'document',name:'Auto Canvas',editorType:'figma',connection:{token:'a'.repeat(64),port:3055,version:'test'},...extra})}
}
const ok=value=>({ok:true,status:200,json:async()=>value})
test('native file key survives reconnect and cannot be replaced by a stale manual file link',async()=>{
 const keys=[]
 const h=await uiHarness(async(url,options)=>{
  if(url.endsWith('/connect')){keys.push(JSON.parse(options.body).fileKey);return ok({connectionId:'connection-'+keys.length})}
  if(url.endsWith('/disconnect'))return ok({disconnected:true})
  return new Promise(()=>{})
 })
 vm.runInContext("document.querySelector('#file').value='https://www.figma.com/design/WrongFile123'",h.ctx)
 h.boot({fileKey:'NativeFile123'});await h.flush()
 await h.elements.get('#connect').onclick();await h.flush()
 await h.elements.get('#connect').onclick();await h.flush()
 assert.deepEqual(keys,['NativeFile123','NativeFile123'])
})
test('manual file link remains a fallback only when the native file key is unavailable',async()=>{
 let key
 const h=await uiHarness(async(url,options)=>{
  if(url.endsWith('/connect')){key=JSON.parse(options.body).fileKey;return ok({connectionId:'connected'})}
  return new Promise(()=>{})
 })
 vm.runInContext("document.querySelector('#file').value='https://www.figma.com/design/ManualFile123'",h.ctx)
 h.boot();await h.flush();assert.equal(key,'ManualFile123')
})
test('placeholder progress is visible with node names, bounded, and cleared when finished',async()=>{
 const h=await uiHarness(async url=>url.endsWith('/connect')?ok({connectionId:'connected'}):ok({id:'job-progress',method:'use_figma',args:{code:'return 1'}}))
 h.boot();await h.flush()
 h.send({type:'progress',nodes:[{id:'1:1',name:'Test card'},{id:'1:2',name:'Button'},{id:'1:3',name:'X'.repeat(1000)}]})
 assert.equal(vm.runInContext('document.body.dataset.notice',h.ctx),'true')
 assert.match(h.elements.get('#status').textContent,/Test card.*Button.*3 项/)
 assert.ok(h.elements.get('#status').textContent.length<150)
 h.send({type:'progress',nodes:[]})
 assert.equal(vm.runInContext('document.body.dataset.notice',h.ctx),'false')
})
test('paired companion auto-connects and retries idle startup failure without manual token entry',async()=>{
 let attempts=0
 const h=await uiHarness(async(url,options)=>{
  assert.equal(options.headers.authorization,'Bearer '+'a'.repeat(64))
  if(url.endsWith('/connect')){assert.match(JSON.parse(options.body).clientId,/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/);attempts++;if(attempts===1)throw new Error('offline');return ok({connectionId:'connected'})}
  if(url.endsWith('/poll'))return new Promise(()=>{})
  throw new Error('unexpected request')
 })
 h.boot();await h.flush();assert.equal(attempts,1);assert.equal(h.timers.length,1)
 h.timers[0]();await h.flush();assert.equal(attempts,2);assert.equal(vm.runInContext('active',h.ctx),true)
 assert.equal(h.elements.get('#token')?.value??'','')
 assert.match(h.elements.get('#status').textContent,/可以回到 DSH/)
})
test('companion never reconnects or replays after losing an operation result',async()=>{
 let connects=0,results=0
 const h=await uiHarness(async url=>{
  if(url.endsWith('/connect')){connects++;return ok({connectionId:'connected'})}
  if(url.endsWith('/poll'))return ok({id:'job-1',method:'use_figma',args:{code:'return 1'}})
  if(url.endsWith('/result')){results++;throw new Error('lost result acknowledgement')}
  throw new Error('unexpected request')
 })
 h.boot();await h.flush();assert.equal(h.messages.filter(m=>m.pluginMessage.type==='execute').length,1)
 h.send({type:'result',id:'job-1',ok:true,result:{value:1}});await h.flush()
 assert.equal(results,1);assert.equal(connects,1);assert.equal(h.timers.length,0);assert.equal(vm.runInContext('blocked',h.ctx),true)
 await h.elements.get('#connect').onclick();await h.flush();assert.equal(connects,1)
 assert.match(h.elements.get('#status').textContent,/不会重放/)
})



test('companion connects without a spec panel or legacy storage requests',async()=>{
 const requests=[]
 const h=await uiHarness(async url=>{requests.push(url);return url.endsWith('/connect')?ok({connectionId:'connected'}):new Promise(()=>{})})
 h.boot();await h.flush()
 assert.equal(vm.runInContext('active',h.ctx),true)
 assert.ok(requests.some(url=>url.endsWith('/poll')))
 assert.ok(requests.every(url=>!url.includes('/specs/')))
 const html=await readFile(new URL('../companion/ui.html',import.meta.url),'utf8')
 assert.doesNotMatch(html,/local-specs|spec-import|spec-set-default|spec-export|本地设计规范/)
})
test('unpaired companion displays its own version before a manual pairing is available',async()=>{
 const h=await uiHarness(async()=>{throw Error('No network expected before pairing')})
 h.send({type:'document',name:'Version fixture',editorType:'figma',companionVersion:'0.4.1',connection:null})
 assert.equal(h.elements.get('#version').textContent,'0.4.1')
 assert.equal(vm.runInContext('active',h.ctx),false)
})

test('reference accordion is collapsed, exports only on demand and shares bind/unbind state with DSH',async()=>{
 const h=await uiHarness(async url=>url.endsWith('/connect')?ok({connectionId:'connected'}):new Promise(()=>{}))
 h.boot({designReference:{kind:'frame',nodeId:'1:5',name:'<unsafe name>',state:'bound'}});await h.flush()
 assert.equal(h.messages.filter(m=>m.pluginMessage.type==='reference').length,0)
 assert.equal(h.elements.get('#reference-name').textContent,'<unsafe name>')
 const panel=h.elements.get('#design-reference');panel.open=true;panel.ontoggle()
 const first=h.messages.at(-2)?.pluginMessage.type==='reference'?h.messages.at(-2).pluginMessage:h.messages.find(m=>m.pluginMessage.type==='reference').pluginMessage
 assert.equal(first.action,'get');assert.equal(first.includePreview,true)
 h.send({type:'reference-result',id:first.id,ok:true,result:{value:{reference:{kind:'frame',nodeId:'1:5',name:'新名称',state:'bound'}},images:[{mimeType:'image/png',data:'YWJj'}]}})
 assert.equal(h.elements.get('#reference-image').hidden,false)
 h.elements.get('#reference-clear').onclick()
 const clear=h.messages.filter(m=>m.pluginMessage.type==='reference').at(-1).pluginMessage;assert.equal(clear.action,'clear')
 h.send({type:'reference-result',id:clear.id,ok:true,result:{value:{reference:null},images:[]}})
 assert.equal(h.elements.get('#reference-bind').hidden,false);assert.equal(h.elements.get('#reference-image').src,'')
 h.send({type:'reference-changed',reference:{kind:'spec',name:'品牌规范',state:'bound'}})
 assert.equal(h.elements.get('#reference-name').textContent,'品牌规范');assert.equal(h.elements.get('#reference-image').hidden,true)
 panel.open=false;panel.ontoggle();assert.equal(h.elements.get('#reference-image').src,'')
})
