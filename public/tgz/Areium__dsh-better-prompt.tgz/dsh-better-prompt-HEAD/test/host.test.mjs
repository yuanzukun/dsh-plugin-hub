import { test } from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';
import { mkdtempSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { Readable } from 'node:stream';
import * as hostPlugin from '../lib/index.js';
import { askUserQuestions, normalizeAnswers, runClarify, runOptimize, runOptimizeFlow, resolveSelection } from '../lib/index.js';

const here = fileURLToPath(new URL('.', import.meta.url));
const bundledSkillDir = join(here, '..', 'skills', 'better-prompt');

const config = {
  skillDir: bundledSkillDir,
  timeoutMs: 60000,
  maxInputChars: 20000,
  maxTokens: 8192,
  clarifyMaxQuestions: 3,
  askTimeoutMs: 300000,
};

// ---------------------------------------------------------------------------
// Module shape — exactly what cordis does before it applies a plugin:
//   unwrapExports(ns) then isApplicable(plugin)
// A missing `apply` export fails the whole profile boot, so guard it here.
// ---------------------------------------------------------------------------

test('host module is a valid cordis plugin (loader shape)', () => {
  const unwrapped = hostPlugin.default ?? hostPlugin;
  const plugin = unwrapped.__esModule ? (unwrapped.default ?? unwrapped) : unwrapped;
  assert.ok(plugin !== null && typeof plugin === 'object', 'plugin must be an object');
  assert.equal(typeof plugin.apply, 'function', 'plugin.apply must be a function');
  assert.equal(plugin.name, 'dsh-better-prompt');
  assert.deepEqual(plugin.inject, ['webServer', 'sessions', 'llm', 'agentDefaultModel']);
  assert.equal(typeof plugin.Config, 'function');
});

test('Config schema fills every default used by the loader', () => {
  const resolved = hostPlugin.Config({});
  assert.deepEqual(resolved, {
    skillDir: '',
    timeoutMs: 120000,
    maxInputChars: 20000,
    maxTokens: 8192,
    clarifyMaxQuestions: 3,
    askTimeoutMs: 300000,
  });
  assert.equal(hostPlugin.Config({ timeoutMs: 30000 }).timeoutMs, 30000);
});

test('ensureSkill seeds the default skill into an empty directory, never overwrites', () => {
  const dir = mkdtempSync(join(tmpdir(), 'better-prompt-'));
  const local = { ...config, skillDir: dir };
  const file = hostPlugin.ensureSkill(local);
  assert.equal(file, join(dir, 'SKILL.md'));
  assert.ok(readFileSync(file, 'utf8').includes('提示词优化方向'));

  writeFileSync(file, 'my own directions');
  hostPlugin.ensureSkill(local);
  assert.equal(readFileSync(file, 'utf8'), 'my own directions');
});

test('resolveSkillDir prefers the configured directory over the harness home', () => {
  assert.equal(hostPlugin.resolveSkillDir({ skillDir: 'D:/x/y' }), 'D:/x/y');
  assert.ok(hostPlugin.resolveSkillDir({ skillDir: '' }).endsWith(join('skills', 'better-prompt')));
});

// ---------------------------------------------------------------------------
// apply() + route handler, driven end to end with a fake http req/res.
// ---------------------------------------------------------------------------

function fakeCtx(chunks) {
  const routes = [];
  const ctx = {
    routes,
    get: () => undefined,
    effect(callback) {
      return callback();
    },
    webServer: {
      register(route) {
        routes.push(route);
        return () => {};
      },
    },
    sessions: { get: () => null },
    agentDefaultModel: { currentSelection: () => ({ provider: 'deepseek-official', model: 'deepseek-v4-flash' }) },
    llm: {
      stream: () => (async function* () {
        for (const chunk of chunks) yield chunk;
      })(),
    },
  };
  return ctx;
}

function fakeRequest(method, url, body) {
  const req = Readable.from(body === undefined ? [] : [Buffer.from(JSON.stringify(body), 'utf8')]);
  req.method = method;
  req.url = url;
  req.destroy = () => {};
  return req;
}

function fakeResponse() {
  return {
    status: 0,
    headers: null,
    body: '',
    writeHead(status, headers) {
      this.status = status;
      this.headers = headers;
    },
    end(body) {
      this.body = body;
    },
  };
}

const OK_CHUNKS = [
  { type: 'text-delta', index: 0, text: '更好的' },
  { type: 'text-delta', index: 0, text: '提示词' },
  { type: 'finish', reason: { kind: 'stop' } },
];

test('apply registers the API prefix route', () => {
  const ctx = fakeCtx(OK_CHUNKS);
  hostPlugin.apply(ctx, config);
  assert.equal(ctx.routes.length, 1);
  assert.equal(ctx.routes[0].kind, 'prefix');
  assert.equal(ctx.routes[0].path, '/better-prompt/api');
  assert.equal(typeof ctx.routes[0].handler, 'function');
});

test('POST /better-prompt/api/optimize answers with the optimized text', async () => {
  const ctx = fakeCtx(OK_CHUNKS);
  hostPlugin.apply(ctx, config);
  const req = fakeRequest('POST', '/better-prompt/api/optimize', { draft: '写个脚本', sessionId: 's1' });
  const res = fakeResponse();
  ctx.routes[0].handler(req, res);
  await new Promise((resolve) => setTimeout(resolve, 50));
  assert.equal(res.status, 200);
  assert.equal(res.headers['content-type'], 'application/json; charset=utf-8');
  assert.deepEqual(JSON.parse(res.body), { ok: true, text: '更好的提示词' });
});

test('POST /better-prompt/api/optimize reports an empty draft as a 400 JSON error', async () => {
  const ctx = fakeCtx(OK_CHUNKS);
  hostPlugin.apply(ctx, config);
  const req = fakeRequest('POST', '/better-prompt/api/optimize', { draft: '   ' });
  const res = fakeResponse();
  ctx.routes[0].handler(req, res);
  await new Promise((resolve) => setTimeout(resolve, 50));
  assert.equal(res.status, 400);
  assert.equal(JSON.parse(res.body).ok, false);
});

test('GET /better-prompt/api/skill describes the current optimization directions', async () => {
  const ctx = fakeCtx(OK_CHUNKS);
  hostPlugin.apply(ctx, config);
  const req = fakeRequest('GET', '/better-prompt/api/skill');
  const res = fakeResponse();
  ctx.routes[0].handler(req, res);
  await new Promise((resolve) => setTimeout(resolve, 50));
  assert.equal(res.status, 200);
  const payload = JSON.parse(res.body);
  assert.equal(payload.ok, true);
  assert.equal(payload.name, 'better-prompt');
  assert.ok(payload.description.length > 0);
});

test('unknown API path answers 404 JSON', async () => {
  const ctx = fakeCtx(OK_CHUNKS);
  hostPlugin.apply(ctx, config);
  const req = fakeRequest('GET', '/better-prompt/api/nope');
  const res = fakeResponse();
  ctx.routes[0].handler(req, res);
  await new Promise((resolve) => setTimeout(resolve, 50));
  assert.equal(res.status, 404);
  assert.equal(JSON.parse(res.body).ok, false);
});

// ---------------------------------------------------------------------------
// Document API — the settings page's read/save/reset path. Every write test
// uses its own temp directory so the repository's bundled default is never
// touched.
// ---------------------------------------------------------------------------

function tempConfig() {
  return { ...config, skillDir: mkdtempSync(join(tmpdir(), 'better-prompt-doc-')) };
}

async function call(ctx, method, url, body) {
  const req = fakeRequest(method, url, body);
  const res = fakeResponse();
  ctx.routes[0].handler(req, res);
  await new Promise((resolve) => setTimeout(resolve, 50));
  return { status: res.status, payload: JSON.parse(res.body) };
}

function routeCtx(local) {
  const ctx = fakeCtx(OK_CHUNKS);
  hostPlugin.apply(ctx, local);
  return ctx;
}

test('GET /skill seeds the user copy from the bundled default and reports it as default', async () => {
  const local = tempConfig();
  const { status, payload } = await call(routeCtx(local), 'GET', '/better-prompt/api/skill');
  assert.equal(status, 200);
  assert.equal(payload.ok, true);
  assert.equal(payload.path, join(local.skillDir, 'SKILL.md'));
  assert.equal(payload.customized, false);
  assert.equal(typeof payload.maxChars, 'number');
  assert.ok(payload.text.includes('# 提示词优化方向'));
  assert.equal(readFileSync(payload.path, 'utf8'), payload.text);
});

test('PUT /skill persists the document and it takes effect immediately', async () => {
  const local = tempConfig();
  const ctx = routeCtx(local);
  const saved = await call(ctx, 'PUT', '/better-prompt/api/skill', { text: '我的方向：先给结论' });
  assert.equal(saved.status, 200);
  assert.equal(saved.payload.ok, true);
  assert.equal(saved.payload.customized, true);
  assert.equal(readFileSync(join(local.skillDir, 'SKILL.md'), 'utf8'), '我的方向：先给结论');

  // Immediate effect: the next optimize call reads the saved document.
  const read = await call(ctx, 'GET', '/better-prompt/api/skill');
  assert.equal(read.payload.text, '我的方向：先给结论');
  assert.equal(read.payload.customized, true);
  const optimizeCtx = ctxWith();
  const result = await runOptimize(optimizeCtx, local, { draft: '帮我写个脚本' });
  assert.equal(result.ok, true);
  assert.ok(optimizeCtx.seen.options.system.includes('我的方向：先给结论'));
});

test('an empty saved document falls back to the bundled default directions', async () => {
  const local = tempConfig();
  const ctx = routeCtx(local);
  const saved = await call(ctx, 'PUT', '/better-prompt/api/skill', { text: '   ' });
  assert.equal(saved.status, 200);
  assert.equal(hostPlugin.effectiveSkillText(local).includes('# 提示词优化方向'), true);
  const result = await runOptimize(ctxWith(), local, { draft: '帮我写个脚本' });
  assert.equal(result.ok, true);
});

test('POST /skill/reset restores the bundled default', async () => {
  const local = tempConfig();
  const ctx = routeCtx(local);
  await call(ctx, 'PUT', '/better-prompt/api/skill', { text: '临时方向' });
  assert.equal(hostPlugin.isCustomized(local), true);
  const reset = await call(ctx, 'POST', '/better-prompt/api/skill/reset');
  assert.equal(reset.status, 200);
  assert.equal(reset.payload.customized, false);
  assert.ok(reset.payload.text.includes('# 提示词优化方向'));
  assert.equal(hostPlugin.isCustomized(local), false);
});

test('PUT /skill validates the payload and bounds the document', async () => {
  const local = tempConfig();
  const ctx = routeCtx(local);
  const missing = await call(ctx, 'PUT', '/better-prompt/api/skill', {});
  assert.equal(missing.status, 400);
  assert.ok(missing.payload.error.includes('text'));
  const tooLong = await call(ctx, 'PUT', '/better-prompt/api/skill', { text: 'x'.repeat(256 * 1024 + 1) });
  assert.equal(tooLong.status, 400);
  assert.ok(tooLong.payload.error.includes('上限'));
});

test('saving leaves no temporary file behind (atomic write)', async () => {
  const local = tempConfig();
  const ctx = routeCtx(local);
  await call(ctx, 'PUT', '/better-prompt/api/skill', { text: '方向 A' });
  const leftovers = readdirSync(local.skillDir).filter((name) => name.includes('.tmp-'));
  assert.deepEqual(leftovers, []);
});

test('a document with only whitespace differences is not "customized"', async () => {
  const local = tempConfig();
  const bundled = hostPlugin.readBundledSkill();
  hostPlugin.saveSkillText(local, `${bundled}\n\n`);
  assert.equal(hostPlugin.isCustomized(local), false);
  hostPlugin.saveSkillText(local, `${bundled}\n额外方向`);
  assert.equal(hostPlugin.isCustomized(local), true);
});


function ctxWith(options = {}) {
  const seen = { options: null };
  return {
    seen,
    get: (name) => (name === 'userQuestions' ? options.userQuestions : name === 'agents' ? options.agents : undefined),
    sessions: {
      get: () => options.session ?? null,
    },
    agentDefaultModel: {
      currentSelection: () => options.defaultSelection ?? { provider: 'deepseek-official', model: 'deepseek-v4-flash' },
    },
    llm: {
      stream: (streamOptions) => {
        seen.options = streamOptions;
        return (async function* () {
          for (const chunk of options.chunks ?? [
            { type: 'text-delta', index: 0, text: '优化后的' },
            { type: 'text-delta', index: 0, text: '提示词' },
            { type: 'finish', reason: { kind: 'stop' } },
          ]) {
            yield chunk;
          }
        })();
      },
    },
  };
}

test('runOptimize rewrites a draft and returns the assembled text', async () => {
  const ctx = ctxWith();
  const result = await runOptimize(ctx, config, { draft: ' 帮我写个脚本  ' });
  assert.equal(result.ok, true);
  assert.equal(result.text, '优化后的提示词');
  assert.equal(ctx.seen.options.provider, 'deepseek-official');
  assert.equal(ctx.seen.options.model, 'deepseek-v4-flash');
  assert.ok(typeof ctx.seen.options.system === 'string' && ctx.seen.options.system.includes('优化方向'));
  assert.equal(ctx.seen.options.messages.length, 1);
  assert.equal(ctx.seen.options.messages[0].content[0].text, '帮我写个脚本');
});

test('runOptimize prefers the session model selection', async () => {
  const session = { requestHeader: () => ({ config: { provider: 'moonshot', model: 'kimi-k3', reasoningEffort: 'high' } }) };
  const ctx = ctxWith({ session });
  await runOptimize(ctx, config, { draft: 'hello', sessionId: 's1' });
  assert.equal(ctx.seen.options.provider, 'moonshot');
  assert.equal(ctx.seen.options.model, 'kimi-k3');
  assert.equal(ctx.seen.options.reasoningEffort, 'high');
});

test('runOptimize falls back to the default when the session has no header', async () => {
  const session = { requestHeader: () => undefined };
  const ctx = ctxWith({ session });
  await runOptimize(ctx, config, { draft: 'hello', sessionId: 's1' });
  assert.equal(ctx.seen.options.provider, 'deepseek-official');
});

test('runOptimize rejects an empty or oversized draft', async () => {
  const ctx = ctxWith();
  const empty = await runOptimize(ctx, config, { draft: '   ' });
  assert.equal(empty.ok, false);
  const big = await runOptimize(ctx, config, { draft: 'x'.repeat(config.maxInputChars + 1) });
  assert.equal(big.ok, false);
  assert.ok(big.error.includes('上限'));
});

test('runOptimize reports model error finishes as a failure', async () => {
  const ctx = ctxWith({
    chunks: [{ type: 'finish', reason: { kind: 'error', failure: { message: 'quota exceeded', code: 'QUOTA' } } }],
  });
  const result = await runOptimize(ctx, config, { draft: 'hello' });
  assert.equal(result.ok, false);
  assert.ok(result.error.includes('quota exceeded'));
});

test('runOptimize strips a fenced-code wrapper from the result', async () => {
  const ctx = ctxWith({
    chunks: [
      { type: 'text-delta', index: 0, text: '```\n' },
      { type: 'text-delta', index: 0, text: 'final prompt\n```' },
      { type: 'finish', reason: { kind: 'stop' } },
    ],
  });
  const result = await runOptimize(ctx, config, { draft: 'x' });
  assert.equal(result.ok, true);
  assert.equal(result.text, 'final prompt');
});

test('resolveSelection prefers the session config, else the default', () => {
  const ctx = ctxWith({
    session: { requestHeader: () => ({ config: { provider: 'p', model: 'm' } }) },
  });
  assert.deepEqual(resolveSelection(ctx, 's1'), { provider: 'p', model: 'm' });
  assert.deepEqual(resolveSelection(ctxWith(), 's1'), { provider: 'deepseek-official', model: 'deepseek-v4-flash' });
  assert.deepEqual(resolveSelection(ctxWith(), undefined), { provider: 'deepseek-official', model: 'deepseek-v4-flash' });
});

// ---------------------------------------------------------------------------
// "Grill me" (clarify) flow — the model decides whether the draft is missing
// something blocking, and the questions go out through the harness' native
// ask_user_question channel (ctx.userQuestions) instead of a custom dialog.
// ---------------------------------------------------------------------------

const ASK_CHUNKS = [
  { type: 'text-delta', index: 0, text: '{"action":"ask","questions":[' },
  { type: 'text-delta', index: 0, text: '{"header":"技术栈","question":"用哪个语言？","options":[{"label":"Python（推荐）"},{"label":"TypeScript"}]}' },
  { type: 'text-delta', index: 0, text: ']}' },
  { type: 'finish', reason: { kind: 'stop' } },
];
const FINAL_CHUNKS = [
  { type: 'text-delta', index: 0, text: '最终提示词' },
  { type: 'finish', reason: { kind: 'stop' } },
];

/** A ctx whose successive stream calls replay the supplied chunk lists. */
function flowCtx({ replies, userQuestions, agents, session }) {
  const seen = { streams: [] };
  let call = 0;
  return {
    seen,
    get: (name) => (name === 'userQuestions' ? userQuestions : name === 'agents' ? agents : undefined),
    sessions: { get: () => session ?? null },
    agentDefaultModel: { currentSelection: () => ({ provider: 'deepseek-official', model: 'deepseek-v4-flash' }) },
    llm: {
      stream: (streamOptions) => {
        seen.streams.push(streamOptions);
        const chunks = replies[Math.min(call, replies.length - 1)] ?? [];
        call += 1;
        return (async function* () {
          for (const chunk of chunks) yield chunk;
        })();
      },
    },
  };
}

function fakeUserQuestions(result) {
  const seen = { request: null };
  return {
    seen,
    ask: async (request) => {
      seen.request = request;
      return typeof result === 'function' ? result(request) : result;
    },
  };
}

function fakeAgents(agent) {
  return {
    get: (id) => (id === 's1' ? agent : undefined),
    roots: () => (agent === undefined ? [] : [agent]),
  };
}

test('runClarify returns the questions with their options', async () => {
  const ctx = ctxWith({ chunks: ASK_CHUNKS });
  const result = await runClarify(ctx, config, { draft: '写个脚本' });
  assert.equal(result.ok, true);
  assert.equal(result.action, 'ask');
  assert.equal(result.questions.length, 1);
  assert.equal(result.questions[0].header, '技术栈');
  assert.deepEqual(result.questions[0].options.map((option) => option.label), ['Python（推荐）', 'TypeScript']);
  assert.ok(ctx.seen.options.system.includes('默认不问'));
});

test('runClarify returns the optimized prompt when nothing needs asking', async () => {
  const ctx = ctxWith({
    chunks: [
      { type: 'text-delta', index: 0, text: '{"action":"optimize","prompt":"最终提示词"}' },
      { type: 'finish', reason: { kind: 'stop' } },
    ],
  });
  const result = await runClarify(ctx, config, { draft: '写个脚本' });
  assert.deepEqual(result, { ok: true, action: 'optimize', text: '最终提示词' });
});

test('runClarify surfaces an unusable clarify reply as a failure', async () => {
  const ctx = ctxWith({
    chunks: [
      { type: 'text-delta', index: 0, text: '{"action":"nonsense"}' },
      { type: 'finish', reason: { kind: 'stop' } },
    ],
  });
  const result = await runClarify(ctx, config, { draft: '写个脚本' });
  assert.equal(result.ok, false);
  assert.ok(result.error.length > 0);
});

test('runOptimizeFlow asks through the native channel and rewrites with the answers', async () => {
  const agent = { id: 's1' };
  const questions = fakeUserQuestions({ answers: [{ id: 'q1', selected: ['Python（推荐）'], custom: '其实用 Go' }] });
  const ctx = flowCtx({ replies: [ASK_CHUNKS, FINAL_CHUNKS], userQuestions: questions, agents: fakeAgents(agent) });

  const result = await runOptimizeFlow(ctx, config, { draft: '写个脚本', sessionId: 's1' });
  assert.equal(result.ok, true);
  assert.equal(result.text, '最终提示词');
  // the native request carries the live agent and the options
  assert.equal(questions.seen.request.agent, agent);
  assert.equal(questions.seen.request.questions[0].header, '技术栈');
  assert.equal(questions.seen.request.questions[0].options.length, 2);
  // the final rewrite folds the picked option and the custom text in
  const sent = ctx.seen.streams[1].messages[0].content[0].text;
  assert.ok(sent.includes('Python（推荐）'));
  assert.ok(sent.includes('其实用 Go'));
});

test('runOptimizeFlow rewrites directly when the native channel is unavailable', async () => {
  const ctx = flowCtx({ replies: [ASK_CHUNKS, FINAL_CHUNKS] });
  const result = await runOptimizeFlow(ctx, config, { draft: '写个脚本', sessionId: 's1' });
  assert.equal(result.ok, true);
  assert.equal(result.text, '最终提示词');
  assert.equal(ctx.seen.streams.length, 2);
  // no answers were collected, so the rewrite gets the bare draft
  assert.equal(ctx.seen.streams[1].messages[0].content[0].text, '写个脚本');
});

test('runOptimizeFlow skips the final call when the clarify pass already optimized', async () => {
  const ctx = flowCtx({
    replies: [[
      { type: 'text-delta', index: 0, text: '{"action":"optimize","prompt":"直接结果"}' },
      { type: 'finish', reason: { kind: 'stop' } },
    ]],
  });
  const result = await runOptimizeFlow(ctx, config, { draft: '写个脚本', sessionId: 's1' });
  assert.deepEqual(result, { ok: true, text: '直接结果' });
  assert.equal(ctx.seen.streams.length, 1);
});

test('askUserQuestions declines a non-root agent', async () => {
  const questions = fakeUserQuestions({ answers: [] });
  const ctx = flowCtx({ replies: [FINAL_CHUNKS], userQuestions: questions, agents: { get: () => ({ id: 's1' }), roots: () => [] } });
  const answers = await askUserQuestions(ctx, config, 's1', [{ id: 'q1', header: '', question: 'q', options: [], multiSelect: false }]);
  assert.equal(answers, null);
  assert.equal(questions.seen.request, null);
});

test('runOptimize folds clarify answers into the user message', async () => {
  const ctx = ctxWith();
  const result = await runOptimize(ctx, config, {
    draft: '写个脚本',
    answers: [{ question: '用哪个语言？', answer: 'Python' }, { question: '要测试吗？', answer: '' }],
  });
  assert.equal(result.ok, true);
  const sent = ctx.seen.options.messages[0].content[0].text;
  assert.ok(sent.includes('【原始草稿】'));
  assert.ok(sent.includes('写个脚本'));
  assert.ok(sent.includes('用哪个语言？'));
  assert.ok(sent.includes('Python'));
  assert.ok(sent.includes('（未回答）'));
});

test('normalizeAnswers drops empty entries and bounds the list', () => {
  assert.deepEqual(normalizeAnswers(undefined), []);
  assert.deepEqual(normalizeAnswers([{ question: ' q ', answer: ' a ' }, { answer: '   ' }, 'nope']), [
    { question: 'q', answer: 'a' },
  ]);
  const many = Array.from({ length: 40 }, (_, index) => ({ question: `q${index}`, answer: 'a' }));
  assert.equal(normalizeAnswers(many).length, 20);
});

test('POST /better-prompt/api/optimize runs the whole flow', async () => {
  const ctx = fakeCtx(FINAL_CHUNKS);
  hostPlugin.apply(ctx, config);
  const req = fakeRequest('POST', '/better-prompt/api/optimize', { draft: '写个脚本', sessionId: 's1' });
  const res = fakeResponse();
  ctx.routes[0].handler(req, res);
  await new Promise((resolve) => setTimeout(resolve, 50));
  assert.equal(res.status, 200);
  assert.deepEqual(JSON.parse(res.body), { ok: true, text: '最终提示词' });
});
