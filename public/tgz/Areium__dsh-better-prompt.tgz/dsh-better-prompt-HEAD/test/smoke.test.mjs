import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';
import {
  buildAnswersBlock,
  buildClarifySystemPrompt,
  buildSystemPrompt,
  cleanResult,
  formatNativeAnswers,
  parseClarifyReply,
  parseFrontmatter,
} from '../lib/skill.js';

const here = fileURLToPath(new URL('.', import.meta.url));
const bundledSkill = join(here, '..', 'skills', 'better-prompt', 'SKILL.md');

test('bundled skill is a valid skill document', () => {
  const text = readFileSync(bundledSkill, 'utf8');
  const front = parseFrontmatter(text);
  assert.equal(front.name, 'better-prompt');
  assert.ok(typeof front.description === 'string' && front.description.length > 0);
  assert.ok(text.includes('# 提示词优化方向'));
});

test('default skill is skipped when absent (fallback text)', () => {
  const prompt = buildSystemPrompt('');
  assert.ok(prompt.includes('未找到优化方向技能内容'));
  assert.ok(prompt.includes('只输出优化后的提示词正文'));
});

test('skill text is embedded verbatim in the system prompt', () => {
  const skill = '---\nname: mine\n---\n我的优化方向：=保留用户语气=';
  const prompt = buildSystemPrompt(skill);
  assert.ok(prompt.includes('=保留用户语气='));
  assert.ok(prompt.includes('## 优化方向'));
});

test('frontmatter parsing', () => {
  assert.deepEqual(parseFrontmatter('no frontmatter'), {});
  assert.deepEqual(parseFrontmatter(`---
name: x
description: hello world
other-key: v
---
body
`), { name: 'x', description: 'hello world', 'other-key': 'v' });
  // Tolerate a leading blank line before the frontmatter block.
  assert.ok(Object.keys(parseFrontmatter('\n---\nname: y\n---\n')).length === 0);
});

test('cleanResult strips accidental fenced-code wrapper', () => {
  assert.equal(cleanResult('  我是一名  工程师  '), '我是一名  工程师');
  assert.equal(cleanResult('```\n优化后的提示词\n```'), '优化后的提示词');
  assert.equal(cleanResult('```md\n# 标题\n\n正文\n```'), '# 标题\n\n正文');
});

test('clarify system prompt embeds the directions and the question cap', () => {
  const prompt = buildClarifySystemPrompt('=我的方向=', 2);
  assert.ok(prompt.includes('=我的方向='));
  assert.ok(prompt.includes('最多问 2 个问题'));
  assert.ok(prompt.includes('默认不问'));
  assert.ok(prompt.includes('"action":"ask"'));
  assert.ok(prompt.includes('"action":"optimize"'));
  assert.ok(prompt.includes('"options"'));
  assert.ok(buildClarifySystemPrompt('', undefined).includes('最多问 3 个问题'));
});

test('parseClarifyReply reads the ask shape with options', () => {
  const parsed = parseClarifyReply('{"action":"ask","questions":[{"header":" 技术栈 ","question":" 用哪个语言？ ","options":[{"label":" Python（推荐） ","description":"生态全"},"TypeScript"]},"要测试吗？"]}');
  assert.equal(parsed.action, 'ask');
  assert.deepEqual(parsed.questions, [
    {
      id: 'q1',
      header: '技术栈',
      question: '用哪个语言？',
      options: [
        { label: 'Python（推荐）', description: '生态全' },
        { label: 'TypeScript', description: '' },
      ],
      multiSelect: false,
    },
    { id: 'q2', header: '', question: '要测试吗？', options: [], multiSelect: false },
  ]);
});

test('parseClarifyReply caps the question count', () => {
  const parsed = parseClarifyReply('{"action":"ask","questions":["a","b","c","d"]}', 2);
  assert.equal(parsed.questions.length, 2);
});

test('formatNativeAnswers folds selected options and custom text', () => {
  const questions = [{ id: 'q1', question: '用哪个语言？' }, { id: 'q2', question: '要测试吗？' }];
  assert.deepEqual(
    formatNativeAnswers(questions, [
      { id: 'q1', selected: ['Python（推荐）'], custom: '其实用 Go' },
      { id: 'q2', selected: [] },
    ]),
    [
      { question: '用哪个语言？', answer: 'Python（推荐）；其实用 Go' },
      { question: '要测试吗？', answer: '' },
    ],
  );
  assert.deepEqual(formatNativeAnswers(questions, []), [
    { question: '用哪个语言？', answer: '' },
    { question: '要测试吗？', answer: '' },
  ]);
});

test('parseClarifyReply reads the optimize shape, fenced or bare', () => {
  assert.deepEqual(parseClarifyReply('```json\n{"action":"optimize","prompt":"最终提示词"}\n```'), {
    action: 'optimize',
    text: '最终提示词',
  });
  assert.deepEqual(parseClarifyReply('{"action":"optimize","prompt":"  x  "}'), { action: 'optimize', text: 'x' });
});

test('parseClarifyReply treats a non-JSON reply as a direct optimization', () => {
  assert.deepEqual(parseClarifyReply('  直接给一段提示词  '), { action: 'optimize', text: '直接给一段提示词' });
});

test('parseClarifyReply rejects unusable replies', () => {
  assert.equal(parseClarifyReply('').action, 'invalid');
  assert.equal(parseClarifyReply('{"action":"nope"}').action, 'invalid');
  assert.equal(parseClarifyReply('{"action":"ask","questions":[]}').action, 'invalid');
  assert.equal(parseClarifyReply('{"action":"optimize","prompt":"   "}').action, 'invalid');
});

test('buildAnswersBlock lists the draft and the answers', () => {
  const block = buildAnswersBlock('原始草稿', [
    { question: 'Q1', answer: 'A1' },
    { question: 'Q2', answer: '' },
  ]);
  assert.ok(block.startsWith('【原始草稿】\n原始草稿'));
  assert.ok(block.includes('1. Q1\n   A1'));
  assert.ok(block.includes('2. Q2\n   （未回答）'));
});
