# dsh-better-prompt

一个 [DeepSeek Harness (dsh)](https://github.com/deepseek-ai/deepseek-harness) 插件：把你在输入框里草拟的内容交给 LLM 优化，优化后的提示词**自动写回输入框**，确认满意后再发送。

优化方向不是写死的：它来自一个 **skill** 文档（`SKILL.md`），首次加载时自动生成在 `~/.dsh/skills/better-prompt/SKILL.md`。你既可以直接改文件，也可以**在 dsh 设置界面里编辑**（设置 → 提示词优化），改完立即生效。

草稿确实缺关键信息时，模型才会**先追问**（grill me），而且提问走 **dsh 原生提问界面**（每题几个选项，可点选或自行输入），答完再生成提示词；草稿够清楚就直接生成，不打扰你。

## 功能

- 在输入框工具行（发送按钮左侧）新增按钮：**✨优化**。
- 点击后先判断草稿是否缺关键信息——缺才提问（走 dsh 原生 `ask_user_question`，带选项、可自行输入），答完生成；不缺就直接改写。判定与改写都用**当前会话选择的模型**（或默认模型）。
- 写回后出现 **↩ 撤回** 按钮，可一键恢复优化前的输入内容。
- 出错时显示 **!** 标记，悬停可见错误信息。
- 输入框内容不会自动发送，用户确认后再点发送。
- **设置界面**：设置 → **提示词优化**，直接查看/编辑优化方向文档，支持保存、取消、重置为默认；有未保存修改时离开会二次确认。

## 安装

```powershell
# 从 GitHub 安装（推荐）
dsh plugin --profile web add git+https://github.com/Areium/dsh-better-prompt.git

# 或使用 github: 简写
dsh plugin --profile web add github:Areium/dsh-better-prompt

# 从本地目录安装（开发模式，改完立即生效）
dsh plugin --profile web add link:D:\Code\better-prompt

# 或从 npm 安装（发布后）
dsh plugin --profile web add dsh-better-prompt
```

仓库地址：https://github.com/Areium/dsh-better-prompt

安装完成后**重启 dsh web**（`dsh web` / `dsh --profile web`）使插件加载。浏览器插件端通过 HMR 刷新；修改 host 端（`lib/index.js`）需要重启。

## 使用

1. 在输入框输入一段内容（可以是任意语言、任何粗糙的草稿）。
2. 点击 **✨优化**。
   - 草稿缺关键信息：输入区切换为 **dsh 原生提问**（每题几个选项，可点选，也可自行输入；最多 `clarifyMaxQuestions` 个），答完自动继续。
   - 草稿信息足够：直接给出优化结果，不打断你。
3. 输入框内容被替换为优化后的提示词；不满意可点 **↩ 撤回** 恢复原文，或直接编辑。
4. 确认后点击发送。

## 编辑优化方向（skill）

### 方式一：设置界面（推荐）

**设置 → 提示词优化**：

- 顶部显示当前编辑的**文件路径**，以及当前是「默认」还是「自定义」；
- 多行编辑区直接改文档；**保存**后立即生效（下一次点 ✨优化 就用新方向，无需重启）；
- **取消**放弃未保存的修改（会二次确认）；
- **重置为默认**用插件内置文档覆盖当前文件（会二次确认，立即写盘）；
- 有未保存修改时，切换设置页 / 关闭设置 / 刷新页面都会二次确认。

### 方式二：直接改文件

文档位置：`~/.dsh/skills/better-prompt/SKILL.md`（也可由 `skillDir` 配置指向别处）：

- **name / description**：frontmatter，用于标识技能。
- **正文**：优化原则——明确性、角色、上下文、约束、结构、输出形式、示例、质量要求、平衡准则、输出纪律。按需增删。

如果删掉该文件，插件下次读取时会把捆绑的默认版本重新生成；文档为空时同样回退到默认方向，不会崩溃。
也可以把 skills 目录移到自己工作区的任意位置，并在 profile 中配置 `skillDir`：

```yaml
# ~/.dsh/profiles/web/cordis.patch.yml —— 在插件行上覆盖配置
- id: dsh-better-prompt
  config:
    skillDir: D:/Workspace/my-skill-dir
```

## 配置

| 字段 | 默认 | 说明 |
| --- | --- | --- |
| `skillDir` | `$DSH_HOME/skills/better-prompt` | 优化方向技能目录（含 SKILL.md） |
| `timeoutMs` | `120000` | 单次优化调用超时（ms） |
| `maxInputChars` | `20000` | 输入草稿长度上限 |
| `maxTokens` | `8192` | 优化输出 token 上限 |
| `clarifyMaxQuestions` | `3` | 「追问」单次最多提几个问题（1–10） |
| `askTimeoutMs` | `300000` | 等待用户回答原生提问的超时（ms），超时则不追问直接改写 |

在 profile 的 `cordis.patch.yml` 中以"覆盖整行 config"的方式修改（注意要保留不想改的字段）：

```yaml
- id: dsh-better-prompt
  config:
    timeoutMs: 60000
    maxInputChars: 20000
    maxTokens: 8192
    clarifyMaxQuestions: 3
    askTimeoutMs: 300000
```

## 架构

```
浏览器 (lib/client.js)
  ├─ composer 工具行插槽 conversation.input.right
  │    └─ 点击 ✨ → POST /better-prompt/api/optimize {sessionId, draft}
  │         （一个请求跑完整个流程；需要提问时宿主阻塞等待，浏览器端不弹自建对话框）
  └─ 设置页插槽 settings.section（id better-prompt，order 25）
       └─ GET/PUT /better-prompt/api/skill、POST /better-prompt/api/skill/reset
主机 (lib/index.js, host 插件)
  ├─ 文档：用户副本 $DSH_HOME/skills/better-prompt/SKILL.md（缺失/为空则回退到包内默认）
  ├─ 解析模型:会话当前模型(session.requestHeader().config) ?? agentDefaultModel.currentSelection()
  ├─ 判定：ctx.llm.stream({system: 追问判定+文档+JSON 格式}) → questions 或 text
  ├─ 提问：agents.get(sessionId) 取当前会话的 live root agent → ctx.userQuestions.ask({questions, agent})
  │        拿不到 agent / 原生通道 → 跳过提问，直接改写
  ├─ 改写：ctx.llm.stream({system: 文档+输出纪律, messages: 草稿 [+ 回答]})
  └─ 返回 { ok, text } → 浏览器 inputActions.setDraft(text)
```

### HTTP API

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/better-prompt/api/skill` | 读取文档：`{ ok, path, name, description, text, customized, maxChars }`（文件不存在时自动从内置默认创建） |
| PUT | `/better-prompt/api/skill` | 保存文档：`{ text }` → `{ ok, path, text, customized }`（原子写入，立即生效） |
| POST | `/better-prompt/api/skill/reset` | 用内置默认覆盖用户副本 |
| POST | `/better-prompt/api/optimize` | 完整流程：`{ sessionId?, draft }` → `{ ok, text }`。内部先判定是否需要提问；需要时通过 `ctx.userQuestions.ask` 走原生提问界面，答完再改写 |

## 开发

```powershell
# 无构建步骤：host 端是纯 ESM，客户端是纯 JS CJS 工厂
npm test                # 单元测试(node --test)，覆盖文档 API / 优化调用 / 配置 schema
node --check lib/index.js
node --check lib/client.js
# 改 lib/client.js 后刷新浏览器即可（client-modules 按内容 hash 缓存）
# 改 lib/index.js 后重启 dsh web
```

### 目录

```
lib/index.js              主机插件（webServer 路由 / 文档读写 / LLM 调用）
lib/client.js             浏览器插件（输入行按钮 + 设置页，CJS factory）
lib/skill.js              纯函数（system prompt 构建 / frontmatter 解析 / 结果清洗）
skills/better-prompt/SKILL.md   内置默认优化方向文档（首次读取时复制到用户目录）
cordis.patch.yml          bundle 补丁（插入 host 行；客户端行由 dsh.client 声明自动挂载）
test/smoke.test.mjs       纯函数冒烟测试（system prompt / frontmatter / 清洗）
test/host.test.mjs        host 端测试（插件形态 / 配置 / 文档 API / 优化调用）
```

## 依赖

- `@deepseek-ai/dsh-llm` — 通过 `ctx.llm` 调用当前模型。
- `@deepseek-ai/dsh-home-paths` — 解析 `$DSH_HOME/skills`。
- `@deepseek-ai/schemastery` — 插件配置 schema。
- host 服务：`webServer`、`sessions`、`llm`、`agentDefaultModel`。
- 客户端服务/模块：`slots`、`locale`、`react`、`@deepseek-ai/dsh-client-ui-primitives`（Button / Modal，均来自前端内置模块表，无需新增依赖）。

## License

MIT
