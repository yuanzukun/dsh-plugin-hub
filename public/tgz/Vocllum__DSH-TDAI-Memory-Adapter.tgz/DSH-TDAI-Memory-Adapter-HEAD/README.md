# 🧠 DSH TDAI Memory Adapter

<p align="center"><strong>DeepSeek Harness 的 TencentDB Agent Memory Adapter</strong><br>把自动 recall、turn 捕获和主动搜索接入现有 Gateway/Core。</p>

<p align="center"><a href="https://github.com/Vocllum/DSH-TDAI-Memory-Adapter"><img src="https://img.shields.io/badge/DSH-plugin-7c3aed?style=flat-square&logo=github&logoColor=white"></a> <a href="https://github.com/Vocllum/DSH-TDAI-Memory-Adapter/blob/main/LICENSE"><img src="https://img.shields.io/github/license/Vocllum/DSH-TDAI-Memory-Adapter?style=flat-square"></a> <a href="README_EN.md"><img src="https://img.shields.io/badge/English-README-64748b?style=flat-square"></a></p>

<p align="center"><a href="#安装">安装</a> · <a href="#功能">功能</a> · <a href="#和-dsh-tdai-memory-的区别">区别</a> · <a href="#配置">配置</a> · <a href="README_EN.md">English</a></p>

## ✨ 功能

- 🔎 **自动 recall**：在 `agent/pre-step` 前从已有 Gateway 检索相关记忆并注入上下文。
- 🧾 **turn 捕获**：在 `agent/turn-stopping` / `session/flush` 捕获对话，避免重复提交。
- 🌱 **后台沉淀**：由现有 MemoryCore 异步完成 L1/L2/L3 与 Skill 提取。
- 🧰 **主动搜索**：提供 `tdai_memory_search`、`tdai_conversation_search`、`tdai_skill_search` 只读工具。
- 🛟 **故障隔离**：Gateway 或记忆服务异常时 fail-open，不阻断 DSH。

## 🧭 工作方式

```text
DSH lifecycle → Gateway → MemoryCore
     recall       L0 capture       L1/L2/L3/Skill (后台异步)
```

## 🎯 和 `dsh-tdai-memory` 的区别

这是两个不同方向的项目：

| 项目 | 定位 |
| --- | --- |
| `Scorp1o117/dsh-tdai-memory` | 把 MemoryCore、存储、向量和提取流水线整体移植到 DSH，并提供设置 UI。 |
| 本项目 | 轻量 Adapter，复用已运行的 TencentDB Agent Memory Gateway/Core，只负责 DSH 生命周期、身份传递和聚焦工具注册。 |

本项目不复制 MemoryCore，不管理本地记忆目录，不实现 MemoryProxy，也不暴露任意 URL/HTTP 执行器。两者可以按部署形态二选一，不能再共用同一个包名。

## 🚀 安装

```bash
dsh plugin --profile web add https://github.com/Vocllum/DSH-TDAI-Memory-Adapter.git
```

安装后重启目标 DSH profile。也可以从本地目录安装：

```bash
git clone https://github.com/Vocllum/DSH-TDAI-Memory-Adapter.git
dsh plugin --profile web add ./DSH-TDAI-Memory-Adapter
```

## ⚙️ 配置

```bash
export TDAI_MEMORY_ENDPOINT=http://127.0.0.1:8420
export TDAI_MEMORY_API_KEY=...
export TDAI_MEMORY_INSTANCE_ID=default
export TDAI_MEMORY_TEAM_ID=default
export TDAI_MEMORY_AGENT_ID=your-agent-id
export TDAI_MEMORY_USER_ID=your-user-id
export TDAI_MEMORY_RECALL_LIMIT=5
```

缺少身份配置时，该会话的记忆操作会停用，但不会阻断 DSH。密钥不会写入文件、模型上下文或工具结果。

## 🧰 工具

| 工具 | 用途 | Gateway 路径 |
| --- | --- | --- |
| `tdai_memory_search` | 搜索结构化长期记忆 | `/v3/atomic/search` |
| `tdai_conversation_search` | 搜索原始对话历史 | `/v3/conversation/search` |
| `tdai_skill_search` | 搜索后端管理的 Skill | `/v3/skill/search` |

## 🧪 开发

```bash
npm test
```

## 📄 许可证

MIT

<p align="center"><a href="README_EN.md">🇬🇧 Read this page in English</a></p>
