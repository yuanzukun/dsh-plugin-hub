import assert from 'node:assert/strict'
import { TdaiClient, safeText } from '../client.mjs'

const calls = []
globalThis.fetch = async (url, init) => {
  calls.push({ url, init, body: JSON.parse(init.body) })
  return new Response(JSON.stringify({ code: 0, data: { ok: true } }), {
    status: 200,
    headers: { 'content-type': 'application/json' },
  })
}

const client = new TdaiClient({ endpoint: 'http://localhost:8420/', apiKey: 'test-key', serviceId: 'default' })
const identity = { space_id: 'default', team_id: 'team', agent_id: 'agent', user_id: 'user', session_id: 'session' }

await client.recall(identity, 'query', 7)
assert.equal(calls[0].url, 'http://localhost:8420/v3/atomic/search')
assert.equal(calls[0].body.limit, 7)
assert.equal(calls[0].body.top_k, undefined)
assert.equal(calls[0].init.headers.authorization, 'Bearer test-key')
assert.equal(calls[0].init.headers['x-tdai-service-id'], 'default')

await client.conversationSearch(identity, 'query', 3)
assert.equal(calls[1].body.limit, 3)

await client.skillSearch(identity, 'query', 4)
assert.equal(calls[2].body.top_k, 4)

assert.equal(safeText([{ text: 'a' }, { content: 'b' }]), 'a\nb')
console.log('client contract ok')
