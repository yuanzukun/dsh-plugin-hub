# 🧠 DSH TDAI Memory Adapter

<p align="center"><strong>A TencentDB Agent Memory Adapter for DeepSeek Harness</strong><br>Lifecycle recall, turn capture, and focused search on top of an existing Gateway/Core.</p>

<p align="center"><a href="README.md">🇨🇳 中文</a> · <a href="https://github.com/Vocllum/DSH-TDAI-Memory-Adapter">GitHub</a> · <a href="https://github.com/Vocllum/DSH-TDAI-Memory-Adapter/issues">Issues</a></p>

## ✨ Features

- 🔎 Automatic recall before `agent/pre-step`.
- 🧾 Exactly-once turn capture through DSH lifecycle events.
- 🌱 Backend asynchronous L1/L2/L3 and Skill extraction.
- 🧰 Focused read-only tools for memory, conversation, and Skill search.
- 🛟 Fail-open behavior when Gateway or memory services are unavailable.

## 🎯 Difference from `dsh-tdai-memory`

`Scorp1o117/dsh-tdai-memory` is a full local MemoryCore port with storage, vectors, extraction, and settings UI. This repository is a smaller adapter: it reuses an existing TencentDB Agent Memory Gateway/Core and only owns DSH lifecycle wiring, identity propagation, and focused tools.

It does not bundle MemoryCore, own local memory storage, implement MemoryProxy, or expose arbitrary HTTP execution.

## 🚀 Install

```bash
dsh plugin --profile web add https://github.com/Vocllum/DSH-TDAI-Memory-Adapter.git
```

Restart the target DSH profile after installation.

## ⚙️ Configure

```bash
export TDAI_MEMORY_ENDPOINT=http://127.0.0.1:8420
export TDAI_MEMORY_API_KEY=...
export TDAI_MEMORY_INSTANCE_ID=default
export TDAI_MEMORY_TEAM_ID=default
export TDAI_MEMORY_AGENT_ID=your-agent-id
export TDAI_MEMORY_USER_ID=your-user-id
export TDAI_MEMORY_RECALL_LIMIT=5
```

Secrets are never written to files, model context, or tool results. Missing identity disables memory operations for that session without blocking DSH.

## 🧰 Tools

| Tool | Purpose | Gateway route |
| --- | --- | --- |
| `tdai_memory_search` | Structured long-term memory search | `/v3/atomic/search` |
| `tdai_conversation_search` | Raw conversation search | `/v3/conversation/search` |
| `tdai_skill_search` | Backend-managed Skill search | `/v3/skill/search` |

## 🧪 Development

```bash
npm test
```

## 📄 License

MIT

<p align="center"><a href="README.md">🇨🇳 阅读中文说明</a></p>
