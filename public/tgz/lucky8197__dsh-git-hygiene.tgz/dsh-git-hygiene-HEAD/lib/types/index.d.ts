/**
 * Git Hygiene — DSH Git 卫生巡检插件（host 半区）。
 *
 * 注册 `git_hygiene` 模型工具：只读扫描仓库的已合并/过期分支、大文件、
 * 未跟踪文件与工作区状态，输出体检报告与清理建议（不自动删除任何东西）。
 *
 * 安全边界：只执行白名单只读 git 子命令（见 src/git.ts WHITELIST）。
 */
import type { Context } from '@deepseek-ai/cordis';
export { buildSuggestions, renderReport } from './scan.ts';
export type { GitHygieneReport, Finding, Severity, FindingKind } from './types.ts';
export declare const name = "git-hygiene";
export declare const inject: readonly [];
/** 插件配置（cordis 配置节 git-hygiene: {...}）。 */
export interface GitHygieneConfig {
    /** 过期分支阈值（天）。默认 90。 */
    staleDays?: number;
    /** 大文件阈值（字节）。默认 5 MB。 */
    maxFileBytes?: number;
    /** 各清单最大展示条数。默认 30。 */
    maxList?: number;
    /** 审计默认目录。 */
    defaultCwd?: string;
}
export declare function apply(ctx: Context, config?: GitHygieneConfig): void;
