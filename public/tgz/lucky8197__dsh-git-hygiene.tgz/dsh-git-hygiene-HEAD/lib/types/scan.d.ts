/**
 * Git 输出解析（纯函数）。
 */
import type { Config, Finding, FindingKind, GitHygieneReport, Severity } from './types.ts';
/** 解析 `git branch --merged HEAD` 输出 → 分支名列表（去掉 * 当前标记）。 */
export declare function parseMergedBranches(stdout: string, currentBranch?: string): string[];
export interface RefDate {
    branch: string;
    unix: number;
}
/** 解析 `git for-each-ref ... --format=%(refname:short)|%(committerdate:unix)`。 */
export declare function parseRefDates(stdout: string): RefDate[];
export interface StatusEntry {
    path: string;
    /** XY 状态码（porcelain v1）。 */
    xy: string;
}
/** 解析 `git status --porcelain`。 */
export declare function parseStatus(stdout: string): StatusEntry[];
export interface CountObjects {
    sizeBytes: number;
    packCount: number;
    objectCount: number;
}
/** 解析 `git count-objects -v`（size 单位 KiB）。 */
export declare function parseCountObjects(stdout: string): CountObjects;
/** 解析 `git ls-files` → 跟踪文件路径列表。 */
export declare function parseLsFiles(stdout: string): string[];
export declare const KIND_LABEL: Record<FindingKind, string>;
export declare const SEVERITY_ORDER: Record<Severity, number>;
export interface AnalyzeInput {
    config: Config;
    currentBranch?: string;
    merged: string[];
    stale: RefDate[];
    largeFiles: {
        path: string;
        bytes: number;
    }[];
    untracked: StatusEntry[];
    dirtyCount: number;
}
/** 生成发现条目。 */
export declare function analyze(input: AnalyzeInput): {
    findings: Finding[];
    suggestions: {
        severity: Severity;
        text: string;
    }[];
};
export declare function buildSuggestions(findings: Finding[]): {
    severity: Severity;
    text: string;
}[];
export declare function formatBytes(bytes: number): string;
/** 渲染分节报告。 */
export declare function renderReport(report: GitHygieneReport): string;
