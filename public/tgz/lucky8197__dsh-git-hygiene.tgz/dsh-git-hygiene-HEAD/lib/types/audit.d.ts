import { renderReport } from './scan.ts';
import type { Config, GitHygieneReport } from './types.ts';
export { renderReport };
export interface AuditOptions {
    cwd: string;
    signal: AbortSignal;
    config: Config;
}
export declare function runAudit(options: AuditOptions): Promise<GitHygieneReport>;
