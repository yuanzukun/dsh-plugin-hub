/** 白名单：完整参数序列（顺序敏感）。 */
export declare const WHITELIST: readonly string[][];
/** 校验参数是否命中白名单。 */
export declare function validateGitArgs(args: readonly string[]): boolean;
export interface GitResult {
    code: number;
    stdout: string;
    stderr: string;
}
/** 执行只读 git 命令（白名单校验；超时 15s；denied 时 code=-2）。 */
export declare function runGit(cwd: string, args: readonly string[], signal?: AbortSignal): Promise<GitResult>;
