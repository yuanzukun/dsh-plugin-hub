# agent-setup.md — 供 Agent 安装与使用 dsh-git-hygiene

## 1. 安装

```bash
dsh plugin --profile web add "github:lucky8197/dsh-git-hygiene#main"
# 或本地 link 安装（等价验证）：dsh plugin --profile web add "link:<本地路径>"
```

安装后**重启 dsh web** 使插件生效。

## 2. 验证挂载

```bash
dsh --profile web --dump-config | grep git-hygiene
# 期望输出包含：id: git-hygiene
```

## 3. 调用工具

```
git_hygiene(cwd: "/path/to/repo")                 # 全量默认体检
git_hygiene(cwd: "/path/to/repo", staleDays: 30)  # 更激进的过期分支阈值
git_hygiene(cwd: "/path/to/repo", maxFileBytes: 1048576)  # 1MB 以上算大文件
```

## 4. 解读报告

- `findings[]`：每条含 `severity`、`kind`、`detail`、`evidence`、`fix`。
  严重度：`merged_branch` medium；`stale_branch`/`large_file`/`untracked`/`dirty_worktree` low。
- `repo`：仓库根/当前分支/HEAD/远程/对象库体积。
- `suggestions[]`：按严重度排序的清理建议。

## 5. Agent 工作流建议

1. 接手新仓库或定期维护时跑一次 `git_hygiene`；
2. 按建议执行清理（工具本身**只建议不执行**）：
   - 已合并分支：`git branch -d <branch>`（安全删除，未合并会被 git 拒绝）；
   - 过期分支：确认废弃后 `git branch -D <branch>` 或打 tag 归档；
   - 大文件：`git filter-repo`/BFG 清理历史，或迁移 LFS；
   - 未跟踪文件：该入库的 `git add`，临时的加 `.gitignore`；
3. 清理后复跑确认 `findingCount` 归零。

## 6. 注意

- 工具只执行**白名单只读 git 命令**（status/branch/for-each-ref/ls-files/count-objects 等），
  不会执行任何破坏性操作；
- 非 git 目录返回 `isRepo: false`；
- 删除分支/文件等写操作一律由用户手动执行。
