/**
 * dsh-git-hygiene 端到端测试（真实 git 临时仓库）。
 */
import assert from 'node:assert/strict'
import { writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { test } from 'node:test'
import { runAudit } from '../src/audit.ts'
import { renderReport } from '../src/scan.ts'
import { git, makeGitRepo, testConfig } from './helpers.ts'

function signal(): AbortSignal {
  return new AbortController().signal
}

test('e2e: 非 git 仓库 → isRepo=false', async () => {
  const { mkdtemp } = await import('node:fs/promises')
  const { tmpdir } = await import('node:os')
  const dir = await mkdtemp(join(tmpdir(), 'git-hygiene-norepo-'))
  const report = await runAudit({ cwd: dir, signal: signal(), config: testConfig() })
  assert.equal(report.repo.isRepo, false)
  assert.equal(report.findings.length, 0)
})

test('e2e: 干净仓库 → 无发现', async () => {
  const repo = await makeGitRepo({ 'src/a.ts': 'export const a = 1\n' })
  const report = await runAudit({ cwd: repo, signal: signal(), config: testConfig() })
  assert.equal(report.repo.isRepo, true)
  assert.equal(report.repo.branch, 'main')
  assert.equal(report.findings.length, 0)
  assert.ok(renderReport(report).includes('卫生良好'))
})

test('e2e: 已合并分支被检出（medium）', async () => {
  const repo = await makeGitRepo({ 'a.txt': 'x\n' })
  git(repo, ['branch', 'merged-feature'])
  const report = await runAudit({ cwd: repo, signal: signal(), config: testConfig() })
  const merged = report.findings.filter((f) => f.kind === 'merged_branch')
  assert.equal(merged.length, 1)
  assert.equal(merged[0]?.severity, 'medium')
  assert.ok(merged[0]?.detail.includes('merged-feature'))
  assert.ok(merged[0]?.fix.includes('git branch -d'))
})

test('e2e: 未合并分支不算已合并', async () => {
  const repo = await makeGitRepo({ 'a.txt': 'x\n' })
  git(repo, ['checkout', '-b', 'unmerged'])
  await writeFile(join(repo, 'new.txt'), 'y\n')
  git(repo, ['add', '.'])
  git(repo, ['commit', '-m', 'feature'])
  git(repo, ['checkout', 'main'])
  const report = await runAudit({ cwd: repo, signal: signal(), config: testConfig() })
  assert.ok(!report.findings.some((f) => f.kind === 'merged_branch'))
})

test('e2e: 过期分支按天数检出（staleDays 生效）', async () => {
  const repo = await makeGitRepo({ 'a.txt': 'x\n' })
  git(repo, ['checkout', '-b', 'old-branch'])
  await writeFile(join(repo, 'old.txt'), 'o\n')
  git(repo, ['add', '.'])
  git(repo, ['commit', '-m', 'old', '--date', '2024-01-01T00:00:00'], { GIT_COMMITTER_DATE: '2024-01-01T00:00:00' })
  git(repo, ['checkout', 'main'])
  const report = await runAudit({ cwd: repo, signal: signal(), config: testConfig({ staleDays: 30 }) })
  const stale = report.findings.filter((f) => f.kind === 'stale_branch')
  assert.equal(stale.length, 1)
  assert.ok(stale[0]?.detail.includes('old-branch'))
  // 阈值放大 → 不再过期
  const report2 = await runAudit({ cwd: repo, signal: signal(), config: testConfig({ staleDays: 2000 }) })
  assert.ok(!report2.findings.some((f) => f.kind === 'stale_branch'))
})

test('e2e: 大文件检出（maxFileBytes 生效）', async () => {
  const repo = await makeGitRepo({ 'big.bin': 'b'.repeat(6 * 1024 * 1024) })
  const report = await runAudit({ cwd: repo, signal: signal(), config: testConfig({ maxFileBytes: 5 * 1024 * 1024 }) })
  const big = report.findings.filter((f) => f.kind === 'large_file')
  assert.equal(big.length, 1)
  assert.ok(big[0]?.detail.includes('big.bin'))
  assert.ok(big[0]?.evidence.includes('MB'))
  // 阈值放大 → 不算大
  const report2 = await runAudit({ cwd: repo, signal: signal(), config: testConfig({ maxFileBytes: 10 * 1024 * 1024 }) })
  assert.ok(!report2.findings.some((f) => f.kind === 'large_file'))
})

test('e2e: 未跟踪文件检出', async () => {
  const repo = await makeGitRepo({ 'a.txt': 'x\n' })
  await writeFile(join(repo, 'untracked.log'), 'log\n')
  const report = await runAudit({ cwd: repo, signal: signal(), config: testConfig() })
  const untracked = report.findings.filter((f) => f.kind === 'untracked')
  assert.equal(untracked.length, 1)
  assert.ok(untracked[0]?.detail.includes('untracked.log'))
})

test('e2e: 未提交修改检出（dirty_worktree）', async () => {
  const repo = await makeGitRepo({ 'a.txt': 'x\n' })
  await writeFile(join(repo, 'a.txt'), 'y\n')
  const report = await runAudit({ cwd: repo, signal: signal(), config: testConfig() })
  const dirty = report.findings.filter((f) => f.kind === 'dirty_worktree')
  assert.equal(dirty.length, 1)
  assert.ok(dirty[0]?.detail.includes('1 个未提交修改'))
})

test('e2e: 报告形状 + 远程解析', async () => {
  const repo = await makeGitRepo({ 'a.txt': 'x\n' })
  const report = await runAudit({ cwd: repo, signal: signal(), config: testConfig() })
  assert.equal(report.tool, 'git_hygiene')
  assert.equal(report.version, 1)
  assert.ok(report.repo.root)
  assert.ok(report.repo.head)
  assert.ok(Array.isArray(report.repo.remotes))
  assert.equal(report.stats.findingCount, report.findings.length)
})

test('e2e: detached HEAD 不崩溃', async () => {
  const repo = await makeGitRepo({ 'a.txt': 'x\n' })
  git(repo, ['checkout', '--detach'])
  const report = await runAudit({ cwd: repo, signal: signal(), config: testConfig() })
  assert.equal(report.repo.isRepo, true)
  assert.equal(report.repo.branch, undefined)
})

test('e2e: 渲染报告分节完整', async () => {
  const repo = await makeGitRepo({ 'a.txt': 'x\n' })
  git(repo, ['branch', 'merged-x'])
  const report = await runAudit({ cwd: repo, signal: signal(), config: testConfig() })
  const text = renderReport(report)
  assert.ok(text.includes('Git Hygiene 体检报告'))
  assert.ok(text.includes('## 仓库概览'))
  assert.ok(text.includes('## 发现'))
  assert.ok(text.includes('## 建议'))
})
