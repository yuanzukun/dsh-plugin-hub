/**
 * git.ts 白名单 + scan.ts 解析函数单元测试。
 */
import assert from 'node:assert/strict'
import { test } from 'node:test'
import { validateGitArgs } from '../src/git.ts'
import {
  analyze, formatBytes, parseCountObjects, parseLsFiles, parseMergedBranches,
  parseRefDates, parseStatus,
} from '../src/scan.ts'
import { testConfig } from './helpers.ts'

/* ---------- 白名单 ---------- */

test('git: 白名单放行只读命令', () => {
  assert.equal(validateGitArgs(['status', '--porcelain']), true)
  assert.equal(validateGitArgs(['branch', '--merged', 'HEAD']), true)
  assert.equal(validateGitArgs(['for-each-ref', 'refs/heads', '--format=%(refname:short)|%(committerdate:unix)']), true)
  assert.equal(validateGitArgs(['ls-files']), true)
  assert.equal(validateGitArgs(['count-objects', '-v']), true)
})

test('git: 白名单拒绝破坏性命令', () => {
  assert.equal(validateGitArgs(['checkout', '-b', 'x']), false)
  assert.equal(validateGitArgs(['branch', '-D', 'x']), false)
  assert.equal(validateGitArgs(['reset', '--hard']), false)
  assert.equal(validateGitArgs(['clean', '-fd']), false)
  assert.equal(validateGitArgs(['push', 'origin', 'main']), false)
  assert.equal(validateGitArgs(['delete', '-f']), false)
  assert.equal(validateGitArgs(['status', '--porcelain', '--extra']), false)
  assert.equal(validateGitArgs(['status']), false) // 缺 --porcelain 也拒绝（严格匹配）
})

/* ---------- 解析函数 ---------- */

test('scan: parseMergedBranches 去掉 * 与当前分支', () => {
  const branches = parseMergedBranches('* main\n  feature-a\n  feature-b\n', 'main')
  assert.deepEqual(branches, ['feature-a', 'feature-b'])
})

test('scan: parseRefDates 解析分支与 unix 时间戳', () => {
  const refs = parseRefDates('main|1750000000\nold-branch|1600000000\n')
  assert.equal(refs.length, 2)
  assert.equal(refs[0]?.branch, 'main')
  assert.equal(refs[0]?.unix, 1750000000)
  assert.equal(refs[1]?.branch, 'old-branch')
})

test('scan: parseStatus 解析 ?? 与 M', () => {
  const status = parseStatus('?? new-file.txt\n M modified.ts\n')
  assert.equal(status.length, 2)
  assert.equal(status[0]?.xy, '??')
  assert.equal(status[0]?.path, 'new-file.txt')
  assert.equal(status[1]?.xy, ' M')
})

test('scan: parseCountObjects 解析 size/count/packs', () => {
  const parsed = parseCountObjects('count: 42\nsize: 128\nin-pack: 100\npacks: 2\nsize-pack: 64\n')
  assert.equal(parsed.objectCount, 42)
  assert.equal(parsed.packCount, 2)
  assert.equal(parsed.sizeBytes, (128 + 64) * 1024)
})

test('scan: parseLsFiles 解析文件列表', () => {
  assert.deepEqual(parseLsFiles('a.ts\nb/c.ts\n'), ['a.ts', 'b/c.ts'])
})

test('scan: formatBytes', () => {
  assert.equal(formatBytes(512), '512 B')
  assert.equal(formatBytes(2048), '2.0 KB')
  assert.equal(formatBytes(5 * 1024 * 1024), '5.00 MB')
})

/* ---------- analyze ---------- */

test('analyze: 已合并分支 → medium', () => {
  const { findings } = analyze({
    config: testConfig(),
    currentBranch: 'main',
    merged: ['feature-x', 'feature-y'],
    stale: [],
    largeFiles: [],
    untracked: [],
    dirtyCount: 0,
  })
  assert.equal(findings.length, 1)
  assert.equal(findings[0]?.kind, 'merged_branch')
  assert.equal(findings[0]?.severity, 'medium')
  assert.ok(findings[0]?.fix.includes('git branch -d'))
})

test('analyze: 无发现 → 健康建议', () => {
  const { findings, suggestions } = analyze({
    config: testConfig(), merged: [], stale: [], largeFiles: [], untracked: [], dirtyCount: 0,
  })
  assert.equal(findings.length, 0)
  assert.ok(suggestions[0]?.text.includes('卫生良好'))
})

test('analyze: 每条发现都有 fix 且建议按严重度排序', () => {
  const { findings, suggestions } = analyze({
    config: testConfig(),
    currentBranch: 'main',
    merged: ['a'],
    stale: [{ branch: 'old', unix: 1600000000 }],
    largeFiles: [{ path: 'big.bin', bytes: 10 * 1024 * 1024 }],
    untracked: [{ path: 'tmp.txt', xy: '??' }],
    dirtyCount: 2,
  })
  assert.ok(findings.length >= 4)
  for (const f of findings) assert.ok(f.fix.length > 0, `缺 fix: ${f.kind}`)
  const order = { high: 0, medium: 1, low: 2 }
  const sev = suggestions.map((s) => order[s.severity])
  for (let i = 1; i < sev.length; i++) {
    assert.ok((sev[i] ?? 0) >= (sev[i - 1] ?? 0))
  }
})
