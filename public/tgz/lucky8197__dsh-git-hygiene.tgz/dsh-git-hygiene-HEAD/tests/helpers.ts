/**
 * 测试辅助：真实 git 临时仓库构造 + 解析函数单测共用。
 */
import { execFileSync } from 'node:child_process'
import { mkdtemp, mkdir, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { DEFAULT_CONFIG, type Config } from '../src/types.ts'

/** 在一个临时目录初始化 git 仓库并提交初始文件。 */
export async function makeGitRepo(
  files: Record<string, string>,
  opts: { branch?: string } = {},
): Promise<string> {
  const dir = await mkdtemp(join(tmpdir(), 'git-hygiene-test-'))
  git(dir, ['init', '-b', opts.branch ?? 'main'])
  git(dir, ['config', 'user.name', 'Test User'])
  git(dir, ['config', 'user.email', 'test@example.com'])
  for (const [rel, content] of Object.entries(files)) {
    const abs = join(dir, ...rel.split('/'))
    await mkdir(dirname(abs), { recursive: true })
    await writeFile(abs, content)
  }
  git(dir, ['add', '.'])
  git(dir, ['commit', '-m', 'init'])
  return dir
}

/** 执行 git 命令（同步，供测试构造仓库）。 */
export function git(cwd: string, args: string[], env?: Record<string, string>): string {
  return execFileSync('git', args, {
    cwd,
    encoding: 'utf8',
    env: { ...process.env, ...env },
  }).trim()
}

export function testConfig(overrides: Partial<Config> = {}): Config {
  return { ...DEFAULT_CONFIG, ...overrides }
}
