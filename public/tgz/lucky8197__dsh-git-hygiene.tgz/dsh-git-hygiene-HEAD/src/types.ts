/**
 * git-hygiene 共享类型。
 *
 * 安全边界（硬性要求，见 README）：
 * - 只执行白名单内的只读 git 命令（见 git.ts WHITELIST），绝不执行破坏性命令；
 * - 不自动删除/修改任何分支或文件，只输出建议；
 * - 文件大小用只读 node:fs stat；报告不含文件内容。
 */

export type Severity = 'high' | 'medium' | 'low'

export type FindingKind =
  | 'merged_branch'     // 已合并到 HEAD 但未删除的分支
  | 'stale_branch'      // 超过 N 天无提交的分支
  | 'large_file'        // 跟踪文件超过大小阈值
  | 'untracked'         // 未跟踪文件（提示检查是否应入库）
  | 'dirty_worktree'    // 工作区有未提交修改

export interface Finding {
  severity: Severity
  kind: FindingKind
  detail: string
  evidence: string
  fix: string
}

export interface GitHygieneReport {
  tool: 'git_hygiene'
  version: 1
  cwd: string
  repo: {
    isRepo: boolean
    root?: string
    branch?: string
    head?: string
    remotes: string[]
    sizeBytes?: number
    objectCount?: number
  }
  findings: Finding[]
  stats: { findingCount: number; byKind: Record<string, number> }
  suggestions: { severity: Severity; text: string }[]
}

export interface Config {
  /** 过期分支阈值（天）。默认 90。 */
  staleDays: number
  /** 大文件阈值（字节）。默认 5 MB。 */
  maxFileBytes: number
  /** 各清单最大展示条数。 */
  maxList: number
  maxEvidenceLen: number
}

export const DEFAULT_CONFIG: Config = {
  staleDays: 90,
  maxFileBytes: 5 * 1024 * 1024,
  maxList: 30,
  maxEvidenceLen: 200,
}
