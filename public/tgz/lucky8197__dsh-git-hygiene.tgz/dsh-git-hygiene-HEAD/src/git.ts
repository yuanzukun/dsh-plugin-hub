/**
 * Git 命令执行器：只允许白名单内的只读子命令。
 *
 * 安全边界：WHITELIST 之外的任何参数组合一律拒绝（返回 code -2），
 * 不执行 checkout/reset/clean/delete/push 等任何有副作用的命令。
 */
import { execFile } from 'node:child_process'

/** 白名单：完整参数序列（顺序敏感）。 */
export const WHITELIST: readonly string[][] = [
  ['rev-parse', '--is-inside-work-tree'],
  ['rev-parse', '--show-toplevel'],
  ['rev-parse', '--abbrev-ref', 'HEAD'],
  ['status', '--porcelain'],
  ['branch', '--merged', 'HEAD'],
  ['branch', '--no-merged', 'HEAD'],
  ['for-each-ref', 'refs/heads', '--format=%(refname:short)|%(committerdate:unix)'],
  ['ls-files'],
  ['count-objects', '-v'],
  ['remote', '-v'],
  ['log', '-1', '--format=%H'],
  ['symbolic-ref', '-q', 'HEAD'],
]

/** 校验参数是否命中白名单。 */
export function validateGitArgs(args: readonly string[]): boolean {
  return WHITELIST.some((w) => w.length === args.length && w.every((a, i) => a === args[i]))
}

export interface GitResult {
  code: number
  stdout: string
  stderr: string
}

/** 执行只读 git 命令（白名单校验；超时 15s；denied 时 code=-2）。 */
export function runGit(cwd: string, args: readonly string[], signal?: AbortSignal): Promise<GitResult> {
  return new Promise((resolve) => {
    if (!validateGitArgs(args)) {
      resolve({ code: -2, stdout: '', stderr: 'denied: non-whitelisted git command' })
      return
    }
    const child = execFile('git', [...args], { cwd, timeout: 15_000, windowsHide: true }, (err, stdout, stderr) => {
      if (err === null) {
        resolve({ code: 0, stdout: String(stdout), stderr: String(stderr) })
      } else {
        const code = (err as NodeJS.ErrnoException & { code?: unknown }).code
        resolve({
          code: code === 'ETIMEDOUT' ? 124 : 1,
          stdout: String(stdout),
          stderr: String(stderr),
        })
      }
    })
    if (signal !== undefined) {
      signal.addEventListener('abort', () => child.kill(), { once: true })
    }
  })
}
