/**
 * Git 输出解析（纯函数）。
 */
import type { Config, Finding, FindingKind, GitHygieneReport, Severity } from './types.ts'

/** 解析 `git branch --merged HEAD` 输出 → 分支名列表（去掉 * 当前标记）。 */
export function parseMergedBranches(stdout: string, currentBranch?: string): string[] {
  const out: string[] = []
  for (const line of stdout.split(/\r?\n/)) {
    const name = line.trim().replace(/^\*\s*/, '').trim()
    if (name === '' || name === currentBranch) continue
    out.push(name)
  }
  return out
}

export interface RefDate {
  branch: string
  unix: number
}

/** 解析 `git for-each-ref ... --format=%(refname:short)|%(committerdate:unix)`。 */
export function parseRefDates(stdout: string): RefDate[] {
  const out: RefDate[] = []
  for (const line of stdout.split(/\r?\n/)) {
    if (line.trim() === '') continue
    const [branch, date] = line.split('|')
    if (branch === undefined || date === undefined) continue
    const unix = Number(date)
    if (!Number.isNaN(unix)) out.push({ branch, unix })
  }
  return out
}

export interface StatusEntry {
  path: string
  /** XY 状态码（porcelain v1）。 */
  xy: string
}

/** 解析 `git status --porcelain`。 */
export function parseStatus(stdout: string): StatusEntry[] {
  const out: StatusEntry[] = []
  for (const line of stdout.split(/\r?\n/)) {
    if (line.trim() === '') continue
    const xy = line.slice(0, 2)
    const path = line.slice(3).trim()
    if (path !== '') out.push({ path, xy })
  }
  return out
}

export interface CountObjects {
  sizeBytes: number
  packCount: number
  objectCount: number
}

/** 解析 `git count-objects -v`（size 单位 KiB）。 */
export function parseCountObjects(stdout: string): CountObjects {
  let sizeBytes = 0
  let packCount = 0
  let objectCount = 0
  for (const line of stdout.split(/\r?\n/)) {
    const match = /^([a-z-]+):\s*(\d+)/.exec(line.trim())
    if (match === null) continue
    const key = match[1] ?? ''
    const value = Number(match[2] ?? 0)
    if (key === 'size') sizeBytes = value * 1024
    else if (key === 'size-pack') sizeBytes += value * 1024
    else if (key === 'count') objectCount = value
    else if (key === 'packs') packCount = value
  }
  return { sizeBytes, packCount, objectCount }
}

/** 解析 `git ls-files` → 跟踪文件路径列表。 */
export function parseLsFiles(stdout: string): string[] {
  return stdout.split(/\r?\n/).map((l) => l.trim()).filter((l) => l !== '')
}

/* ------------------------------------------------------------------ */
/* 分析层                                                              */
/* ------------------------------------------------------------------ */

export const KIND_LABEL: Record<FindingKind, string> = {
  merged_branch: '已合并分支未清理',
  stale_branch: '长期无提交分支',
  large_file: '大文件',
  untracked: '未跟踪文件',
  dirty_worktree: '未提交修改',
}

export const SEVERITY_ORDER: Record<Severity, number> = { high: 0, medium: 1, low: 2 }

export interface AnalyzeInput {
  config: Config
  currentBranch?: string
  merged: string[]
  stale: RefDate[]
  largeFiles: { path: string; bytes: number }[]
  untracked: StatusEntry[]
  dirtyCount: number
}

/** 生成发现条目。 */
export function analyze(input: AnalyzeInput): { findings: Finding[]; suggestions: { severity: Severity; text: string }[] } {
  const findings: Finding[] = []
  const maxList = input.config.maxList

  const merged = input.merged.slice(0, maxList)
  if (merged.length > 0) {
    findings.push({
      severity: 'medium',
      kind: 'merged_branch',
      detail: `${input.merged.length} 个分支已合并到当前分支，可以安全删除：${merged.join('、')}`,
      evidence: merged.join(', '),
      fix: '对每个已合并分支执行 `git branch -d <branch>`（-d 安全删除，未合并会拒绝）',
    })
  }
  for (const ref of input.stale.slice(0, maxList)) {
    const days = Math.floor((Date.now() / 1000 - ref.unix) / 86_400)
    findings.push({
      severity: 'low',
      kind: 'stale_branch',
      detail: `分支 ${ref.branch} 已有 ${days} 天无提交（阈值 ${input.config.staleDays} 天）`,
      evidence: `${ref.branch} @ ${days} 天前`,
      fix: `确认 ${ref.branch} 是否废弃：归档后执行 ` + '`git branch -D <branch>`（如仍需要可打 tag 保留）',
    })
  }
  for (const file of input.largeFiles.slice(0, maxList)) {
    findings.push({
      severity: 'low',
      kind: 'large_file',
      detail: `跟踪文件 ${file.path} 体积 ${formatBytes(file.bytes)}，超过阈值 ${formatBytes(input.config.maxFileBytes)}`,
      evidence: formatBytes(file.bytes),
      fix: `用 git filter-repo/BFG 从历史中移除 ${file.path}，或改用 LFS/外部存储（仅建议，不自动执行）`,
    })
  }
  if (input.untracked.length > 0) {
    const shown = input.untracked.slice(0, maxList).map((u) => u.path).join('、')
    findings.push({
      severity: 'low',
      kind: 'untracked',
      detail: `${input.untracked.length} 个未跟踪文件：${shown}`,
      evidence: `${input.untracked.length} untracked`,
      fix: '检查未跟踪文件：应入库的执行 `git add`，临时的加入 .gitignore',
    })
  }
  if (input.dirtyCount > 0) {
    findings.push({
      severity: 'low',
      kind: 'dirty_worktree',
      detail: `工作区有 ${input.dirtyCount} 个未提交修改`,
      evidence: `${input.dirtyCount} modified/untracked`,
      fix: '提交或暂存当前修改，保持工作区干净',
    })
  }

  const suggestions = buildSuggestions(findings)
  return { findings, suggestions }
}

export function buildSuggestions(findings: Finding[]): { severity: Severity; text: string }[] {
  if (findings.length === 0) {
    return [{ severity: 'low', text: '仓库卫生良好：无已合并/过期分支堆积，无大文件与未跟踪文件。' }]
  }
  const byKind = new Map<FindingKind, Finding[]>()
  for (const f of findings) {
    const list = byKind.get(f.kind)
    if (list === undefined) byKind.set(f.kind, [f])
    else list.push(f)
  }
  const out: { severity: Severity; text: string }[] = []
  for (const [kind, list] of [...byKind.entries()].sort((a, b) => {
    const sa = a[1][0]?.severity ?? 'low'
    const sb = b[1][0]?.severity ?? 'low'
    return SEVERITY_ORDER[sa] - SEVERITY_ORDER[sb]
  })) {
    const first = list[0]
    if (first === undefined) continue
    out.push({ severity: first.severity, text: `${KIND_LABEL[kind]}：${list.length} 项。${first.detail}。修复：${first.fix}` })
  }
  return out
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`
}

/** 渲染分节报告。 */
export function renderReport(report: GitHygieneReport): string {
  const lines: string[] = []
  lines.push(`# Git Hygiene 体检报告（cwd: ${report.cwd}）`)
  lines.push('')
  if (!report.repo.isRepo) {
    lines.push('⚠ 当前目录不是 git 仓库（或无法访问）。')
    return lines.join('\n')
  }
  lines.push(`## 仓库概览`)
  lines.push(`- 根目录：${report.repo.root ?? '-'}`)
  lines.push(`- 当前分支：${report.repo.branch ?? '(detached)'}`)
  lines.push(`- HEAD：${report.repo.head?.slice(0, 8) ?? '-'}`)
  lines.push(`- 远程：${report.repo.remotes.length > 0 ? report.repo.remotes.join(', ') : '无'}`)
  lines.push(`- 对象库体积：${report.repo.sizeBytes !== undefined ? formatBytes(report.repo.sizeBytes) : '-'}`)
  lines.push('')
  if (report.findings.length === 0) {
    lines.push('未发现问题，仓库卫生良好。')
  } else {
    const byKind = new Map<FindingKind, Finding[]>()
    for (const f of report.findings) {
      const list = byKind.get(f.kind)
      if (list === undefined) byKind.set(f.kind, [f])
      else list.push(f)
    }
    lines.push(`## 发现（${report.findings.length} 项）`)
    for (const [kind, list] of byKind) {
      lines.push(`### ${KIND_LABEL[kind]}（${list.length} 项）`)
      for (const f of list.slice(0, 20)) {
        lines.push(`- [${f.severity}] ${f.detail}`)
        lines.push(`  - 证据：${f.evidence}`)
        lines.push(`  - 修复：${f.fix}`)
      }
      if (list.length > 20) lines.push(`- …还有 ${list.length - 20} 项同类型`)
      lines.push('')
    }
  }
  lines.push(`## 建议（按严重度排序，${report.suggestions.length} 条）`)
  for (const s of report.suggestions) lines.push(`- [${s.severity}] ${s.text}`)
  return lines.join('\n')
}
