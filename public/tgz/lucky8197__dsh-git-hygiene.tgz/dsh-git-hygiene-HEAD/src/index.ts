/**
 * Git Hygiene — DSH Git 卫生巡检插件（host 半区）。
 *
 * 注册 `git_hygiene` 模型工具：只读扫描仓库的已合并/过期分支、大文件、
 * 未跟踪文件与工作区状态，输出体检报告与清理建议（不自动删除任何东西）。
 *
 * 安全边界：只执行白名单只读 git 子命令（见 src/git.ts WHITELIST）。
 */
import type { Context } from '@deepseek-ai/cordis'
import { defineTool, type JsonValue } from '@deepseek-ai/dsh-tools'
import { renderReport, runAudit, type AuditOptions } from './audit.ts'
import { DEFAULT_CONFIG, type Config, type GitHygieneReport } from './types.ts'

export { buildSuggestions, renderReport } from './scan.ts'
export type { GitHygieneReport, Finding, Severity, FindingKind } from './types.ts'

export const name = 'git-hygiene'
export const inject = [] as const

/** 插件配置（cordis 配置节 git-hygiene: {...}）。 */
export interface GitHygieneConfig {
  /** 过期分支阈值（天）。默认 90。 */
  staleDays?: number
  /** 大文件阈值（字节）。默认 5 MB。 */
  maxFileBytes?: number
  /** 各清单最大展示条数。默认 30。 */
  maxList?: number
  /** 审计默认目录。 */
  defaultCwd?: string
}

export function apply(ctx: Context, config: GitHygieneConfig = {}): void {
  const effective: Config = {
    ...DEFAULT_CONFIG,
    ...(config.staleDays !== undefined ? { staleDays: config.staleDays } : {}),
    ...(config.maxFileBytes !== undefined ? { maxFileBytes: config.maxFileBytes } : {}),
    ...(config.maxList !== undefined ? { maxList: config.maxList } : {}),
  }

  ctx.tools.register(defineTool({
    name: 'git_hygiene',
    description:
      'Git 卫生巡检：只读扫描仓库的已合并分支、长期无提交分支、超大跟踪文件、'
      + '未跟踪文件与未提交修改，输出体检报告与清理建议。只执行只读 git 命令，'
      + '不自动删除任何分支或文件。',
    parameters: {
      cwd: { type: 'string', description: '仓库目录；默认使用当前会话工作目录' },
      staleDays: { type: 'number', description: '过期分支阈值（天），默认 90' },
      maxFileBytes: { type: 'number', description: '大文件阈值（字节），默认 5MB' },
    },
    output: {
      schema: { type: 'object', additionalProperties: true },
      render: (_args, value: Record<string, JsonValue>) => [
        { type: 'text', text: renderReport(value as unknown as GitHygieneReport) },
      ],
    },
    async execute(args, exec): Promise<Record<string, JsonValue>> {
      const agentCwd = (exec.agent as { session?: { header?: { cwd?: string } } } | undefined)
        ?.session?.header?.cwd
      const cwd = args.cwd ?? agentCwd ?? config.defaultCwd ?? process.cwd()
      const merged: Config = { ...effective }
      if (args.staleDays !== undefined) merged.staleDays = args.staleDays
      if (args.maxFileBytes !== undefined) merged.maxFileBytes = args.maxFileBytes
      const options: AuditOptions = { cwd, signal: exec.signal, config: merged }
      const report = await runAudit(options)
      return report as unknown as Record<string, JsonValue>
    },
  }))
}
