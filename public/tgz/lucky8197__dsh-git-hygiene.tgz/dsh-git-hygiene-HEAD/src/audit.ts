/**
 * 审计编排：git_hygiene 工具的核心逻辑。
 * 只执行白名单只读 git 命令 + 只读 node:fs stat（大文件体积）。
 */
import { stat as nodeStat } from 'node:fs/promises'
import { join } from 'node:path'
import { runGit } from './git.ts'
import { analyze, renderReport } from './scan.ts'
import {
  parseCountObjects, parseLsFiles, parseMergedBranches, parseRefDates, parseStatus,
} from './scan.ts'
import type { Config, GitHygieneReport } from './types.ts'

export { renderReport }

export interface AuditOptions {
  cwd: string
  signal: AbortSignal
  config: Config
}

export async function runAudit(options: AuditOptions): Promise<GitHygieneReport> {
  const { config } = options
  const base: GitHygieneReport = {
    tool: 'git_hygiene',
    version: 1,
    cwd: options.cwd,
    repo: { isRepo: false, remotes: [] },
    findings: [],
    stats: { findingCount: 0, byKind: {} },
    suggestions: [],
  }

  // 1. 是否 git 仓库
  const inside = await runGit(options.cwd, ['rev-parse', '--is-inside-work-tree'], options.signal)
  if (inside.code !== 0 || inside.stdout.trim() !== 'true') {
    base.repo = { isRepo: false, remotes: [] }
    return base
  }
  const top = await runGit(options.cwd, ['rev-parse', '--show-toplevel'], options.signal)
  const repoRoot = top.stdout.trim()
  const branchRes = await runGit(repoRoot, ['rev-parse', '--abbrev-ref', 'HEAD'], options.signal)
  const branch = branchRes.code === 0 && branchRes.stdout.trim() !== 'HEAD' ? branchRes.stdout.trim() : undefined
  const headRes = await runGit(repoRoot, ['log', '-1', '--format=%H'], options.signal)
  const head = headRes.code === 0 ? headRes.stdout.trim() : undefined
  const remoteRes = await runGit(repoRoot, ['remote', '-v'], options.signal)
  const remotes = parseLsFiles(remoteRes.stdout).length > 0
    ? unique([...remoteRes.stdout.matchAll(/^(\S+)/gm)].map((m) => m[1] ?? '').filter(Boolean))
    : []
  const countRes = await runGit(repoRoot, ['count-objects', '-v'], options.signal)
  const counted = countRes.code === 0 ? parseCountObjects(countRes.stdout) : undefined

  const report: GitHygieneReport = {
    ...base,
    cwd: options.cwd,
    repo: {
      isRepo: true,
      root: repoRoot,
      ...(branch !== undefined ? { branch } : {}),
      ...(head !== undefined ? { head } : {}),
      remotes,
      ...(counted !== undefined ? { sizeBytes: counted.sizeBytes, objectCount: counted.objectCount } : {}),
    },
    findings: [],
    stats: { findingCount: 0, byKind: {} },
    suggestions: [],
  }

  // 2. 工作区状态
  const statusRes = await runGit(repoRoot, ['status', '--porcelain'], options.signal)
  const status = statusRes.code === 0 ? parseStatus(statusRes.stdout) : []
  const untracked = status.filter((s) => s.xy.startsWith('??') || s.xy.includes('?'))
  const dirtyCount = status.length

  // 3. 已合并分支
  const mergedRes = await runGit(repoRoot, ['branch', '--merged', 'HEAD'], options.signal)
  const merged = mergedRes.code === 0 ? parseMergedBranches(mergedRes.stdout, branch) : []

  // 4. 过期分支
  const refRes = await runGit(repoRoot, ['for-each-ref', 'refs/heads', '--format=%(refname:short)|%(committerdate:unix)'], options.signal)
  const refs = refRes.code === 0 ? parseRefDates(refRes.stdout) : []
  const staleCutoff = Date.now() / 1000 - config.staleDays * 86_400
  const stale = refs.filter((r) => r.unix < staleCutoff && r.branch !== branch)

  // 5. 大文件（跟踪文件体积，只读 stat）
  const lsRes = await runGit(repoRoot, ['ls-files'], options.signal)
  const tracked = lsRes.code === 0 ? parseLsFiles(lsRes.stdout) : []
  const largeFiles: { path: string; bytes: number }[] = []
  for (const file of tracked.slice(0, 500)) {
    try {
      const st = await nodeStat(join(repoRoot, ...file.split('/')))
      if (st.isFile() && st.size > config.maxFileBytes) largeFiles.push({ path: file, bytes: st.size })
    } catch {
      // 文件缺失/不可读：跳过
    }
  }

  // 6. 分析
  const { findings, suggestions } = analyze({
    config,
    ...(branch !== undefined ? { currentBranch: branch } : {}),
    merged,
    stale,
    largeFiles,
    untracked,
    dirtyCount,
  })
  report.findings = findings
  report.suggestions = suggestions
  const byKind: Record<string, number> = {}
  for (const f of findings) byKind[f.kind] = (byKind[f.kind] ?? 0) + 1
  report.stats = { findingCount: findings.length, byKind }
  return report
}

function unique(values: string[]): string[] {
  return [...new Set(values)]
}
