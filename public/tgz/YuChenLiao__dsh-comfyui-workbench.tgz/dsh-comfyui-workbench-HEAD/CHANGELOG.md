# CHANGELOG

## 0.8.2 — 2026-11-25

### 修复（对应 issue #6）

- **修复 Windows 下从 git 源安装/更新必然失败（issue #6，感谢 @Euryale076）**：
  - `0.8.1` 在 [package.json](package.json) 加入 `"prepare": "git config core.hooksPath .githooks || true"` 后，一方面 `pnpm add github:...` 会在无 `.git` 的临时目录触发 `npm install`（白白拉取全量 `devDependencies`），另一方面 Windows `cmd.exe` 不认识 POSIX 的 `true` 导致退出码 1、整次安装回滚。
  - 彻底移除 `prepare` 生命周期钩子，改为显式开发脚本 `npm run hooks:install`（[scripts/setup-git-hooks.mjs](scripts/setup-git-hooks.mjs)，无 `.git` 时安全退出 0、纯 Node 实现跨平台零依赖），并在中英文 README 开发章节补上说明。
  - [tests/arch.mjs](tests/arch.mjs) 新增永久门禁：禁止在 `package.json` 的 `scripts` 中声明 `prepare` / `prepack` / `prepublish` 或包含 Windows `cmd.exe` 不支持的 `|| true` 写法。

## 0.8.1 — 2026-11-25

### 修复（对应 issue #3 / #4 / #5 及面板文案）

- **`ctx.root` 在新版 cordis 上导致 10/12 entry 启动失败（issue #3）**：升级指南标注 cordis `4.0.0-rc.12` 起把根上下文换成 `ctx[Context.root]`（实测 DSH `0.2.3-alpha.2` / cordis `4.2.0-alpha.1` 抛 `cannot get property "root" without inject`，而本机 `0.2.2-rc.5` / `4.0.2` 仍保留 `ctx.root`）。新增 [adapter 的 `resolveHostRoot`](src/shared/host/adapter.ts)：symbol 优先、普通属性兜底、最后退回自身并留警告 —— 三条路都必须保留，只认 symbol 会在仍用 `ctx.root` 的宿主上静默退回自身，表现为每个 entry 各建一份 Runtime。
- **资产库 `/items` 在超大 workspace 里要 27 秒（issue #4）**：
  - [collect.ts](src/components/panel-gallery/server/scan/collect.ts) 改为「先判收不收得下，再决定碰不碰磁盘」：sidecar 判定从 `existsSync` 降成同目录文件名集合的 O(1) 查询；`bare` 满额后非 PNG 直接跳过 `statSync`，普通 PNG 也先判内嵌头再决定是否 `statSync`，双满时在当前目录循环内立即 `break`。19 万文件 / 11 万媒体的目录从 22 万次 syscall 降到千级。
  - [scan-cache.ts](src/components/panel-gallery/server/assets/scan-cache.ts) 的缓存时间戳从**扫描开始**改为**扫描结束**：大目录一次扫描本身要十几秒，按开始时刻记等于刚存进去就已过期，这是"连测三次都没有缓存效果"的真正原因。
  - `cacheMs` 默认 4s → 30s；新增 `excludeDirs` 配置项（与内置跳过名单合并），让用户能把几百 GB 的素材目录排除掉；客户端刷新/出图完成/回收站变更补传 `refresh=1`，服务端通过共享 `AssetIndex.onMutate` 与 `/upload` 回调跨 bundle 主动清扫描缓存，避免模型工具出图后 30 秒内切到相册看不到新图。
- **终端面板无法关机、外部实例卡死（issue #5）**：
  - [supervisor.ts](src/shared/comfy/supervisor.ts) 进入 `external` 时补写 `detail`，新增 `recheckExternal()`（返回 `'alive' | 'gone' | 'not-external'`、2s 超时 + 单飞锁，并在工作流面板 `/service/stats` 顺手复查）；给 `start()` 补上 `AbortController` 与 `sleepAbortable`，修复 `starting` 期间被 `stop()` 取消时覆写 `failed` / 幽灵 `ready` 以及取消后 1–2 秒内再点「启动」被旧 `starting` 吞掉的竞态。
  - 终端新增 `POST /terminal?action=stop`，走自己的路由而不是 `panel.workflow` 的 `/service/stop` —— 用户关掉工作流面板后那条路由不在，点「关机」会 404。
  - 按钮组合抽成纯函数 [buttons.ts](src/components/panel-terminal/client/buttons.ts)：外部实例只显示灰掉的关机（杀别人的进程是越界）、受管实例启动中可点「取消启动」、超时残留进程先给「关机」、就绪后可点「关机」（队列有活时二次确认）。
- **工作流导入面板文案同步**：更新 [i18n-data.ts](src/client/i18n-data.ts) 的 `importHint`、`importPlaceholder`、`importEmpty` 与 `emptyWorkflowsHint`（中英），去掉旧的「只接受 API 格式 / Export (API)」提示，明确说明支持 API / UI 格式 JSON 与带工作流元数据的 ComfyUI 原图 PNG 拖放及批量导入。
- **测试硬编码路径**：[tests/costume-panel-image-source.test.mjs](tests/costume-panel-image-source.test.mjs) 写死了 `D:/dsh/dsh-comfyui-workbench`，导致别人 clone 后 `npm test` 必红；改为按本文件位置推仓库根。

### DSH 双向适配层与宿主隔离

在进入 v0.9 对话流新槽位前，把原先分散在 `src/index.ts`、11 条 `src/entries/*.ts`、`src/shared/run/notify.ts` 与 `src/client/index.tsx` 里的原始 DSH 宿主调用收拢进双向适配层；对外工具名、HTTP 路由、面板 UI 与 `cordis.patch.yml` 保持不变：

- **服务端适配层**：
  - 新增 [src/shared/host/adapter.ts](src/shared/host/adapter.ts)：统一封装 `onHostDispose`、`mountHostRoutes`、`resolveHostTools`、`registerHostTool`、`registerHostTools` 与 `createHostToolRegistrar`，集中处理 `ctx.get('tools')` 判空降级、`ctx.effect` 生命周期与 `disposer` 追踪，并预留 `onRegistered` 扩展钩子。
  - 新增 [src/shared/host/session.ts](src/shared/host/session.ts)：收口 DSH 会话格式 v4 要求的 `NOTICE_SOURCE_KIND = 'plugin:dsh-comfyui-workbench'`、`noticeMessage` 信封与 `deliverSessionNotice` 双层异常兜底，[notify.ts](src/shared/run/notify.ts)、[run-batch.ts](src/components/tool-generate/tools/run-batch.ts) 与 [skill.ts](src/shared/host/skill.ts) 统一复用。
  - 收敛 [src/index.ts](src/index.ts) 及全部 `src/entries/*.ts`，保留顶层静态 `export const inject` 供 Cordis Loader 读取，运行时宿主注册全部经由 `adapter.ts` 中转。
- **客户端适配层**：
  - 新增 [src/client/host/types.ts](src/client/host/types.ts)、[src/client/host/slots.ts](src/client/host/slots.ts) 与 [src/client/host/runtime.ts](src/client/host/runtime.ts)：统一封装 `mountWorkbenchEntries`（`betterSidebar.registerTab` 可选注入与降级、`sidebar.panellist`、`main`）、`navigateToConversation` 与 `hostLocale`，并预留 `mountToolView` / `mountComposerSlot` / `mountInputDock` 槽位挂载入口，瘦身 [src/client/index.tsx](src/client/index.tsx)。

### 编码期与提交期契约门禁

- **架构门禁加固**：[tests/arch.mjs](tests/arch.mjs) 新增第 4 条宿主耦合边界，扫描 `src/components/`、`src/entries/`、`src/shared/run/` 及非 `src/client/host/` 的前端源码，阻断直调 `ctx.get` / `ctx.effect` / `slots.register` / `betterSidebar` 或硬编码 `plugin:dsh-comfyui-workbench`。
- **产物级契约单测**：新增 [tests/host-adapter.test.mjs](tests/host-adapter.test.mjs)，面向真实构建产物 `lib/index.js` 与 `lib/client.js` 验证服务缺席降级、`disposer` 回收、会话信封与双层异常兜底。
- **ESLint + 原生 Git Hooks**：新增 [eslint.config.mjs](eslint.config.mjs)（`workbench/module-boundaries` 分层与零依赖检查 + AST 级 `no-restricted-syntax` 宿主耦合规则）与零依赖原生 [.githooks/pre-commit](.githooks/pre-commit) / [.githooks/pre-push](.githooks/pre-push)；`package.json` 新增 `lint`、`prepare` 并将 `lint` 并入 `npm run check`。

### 文档与演进路线图

- **README 架构图重绘**：同步更新 [README.md](README.md) 与 [README.en.md](README.en.md) 的三张 Mermaid 架构图（装配拓扑显性化 DSH 双向适配层、数据流标注 `shared/host/session` 投递、模块依赖边界补齐入口层与宿主隔离门禁）以及目录结构与边界说明。
- **产品演进企划书**：归档 [docs/roadmap-v0.9-v1.x.md](docs/roadmap-v0.9-v1.x.md)（v0.9 → v1.x 路线图与里程碑）。

## 0.8.0 — 2026-11-22

### 文档与知识层同步

- **内嵌 Skill 知识层**：[skill.ts](src/shared/host/skill.ts) 与 [workbench.skill.md](src/shared/host/workbench.skill.md) 同步 0.8.0 新能力（`preset` / `grid`、本机模型盘点与 `loras.json` 触发词、角色库与涂蒙版 `baseImage`/`maskImage` 接 `comfyui_compose`、工作流管理面板拖放导入 UI JSON / PNG、音视频产物与异步 `tags` 写入索引）。
- **README（中英）**：补充 0.8.0 功能、工作流管理面板说明、开头目录、Mermaid 架构图、Star 趋势图与宣传头图。

### 工作流管理面板：按底模分组、搜索筛选、卡片减负

面板原来有三个硬伤：顶部固定在列表外面的控件把小视口啃光、每张卡常驻一个大 textarea 和红按钮
（工作流一多整屏都是输入框）、后端早就返回的字段（`imageSlots` / `modelHint` / 输入槽位）
前端一个都没接。这一批按"先减负、再接通"重排：

- **顶部收成单行**：服务状态灯（在线 / 启动中 / 失败）+ 显存 + 可点击的「运行中 N」；
  「精确进度」「出图等不等」两个开关收进「运行设置」折叠区，默认不占位置；
  活跃任务点开就是抽屉，带排队位次与百分比。
- **按底模分组折叠**：只有 `checkpoint` / `diffusion` 才当底模（`infer.ts` 的 primary 兜底会把
  `4x-UltraSharp.pth` 也变成 model），放大 / VAE / 无模型统一进末尾的「后处理 / 通用工具」组。
  分组键把 `\` 与 `/` 归一 —— 否则 Windows 存档与 POSIX 路径会把同一套底模拆成两组。
  组头带启用计数与告警红点（收起时也看得见哪组坏了）。
- **默认全部收起**，展开状态按组持久化；搜索或筛选时**强制展开**（否则搜到了却因为组折叠而
  看不见），体检命中告警的组自动展开。
- **卡片两行收起态**：启用开关 + 标题 + `workflowId` + 能力标（吃图 / 出视频 / 出音频）+ 一行备注
  预览；点开才露出标题 / 备注受控编辑、输入槽位（basic 直接列、advanced 折叠）、缺模型的
  本机替代建议、预设与删除。
- **标题与备注改成受控输入**：原来 `defaultValue` + `onBlur` 既不点失焦不保存，也不会跟着
  `comfyui_workflow_edit` 的外部修改更新；现在有脏标记与明确的保存按钮。
- **删除改成卡片内二次确认**，不再弹 `window.confirm`。
- **导入更顺手**：整面拖放（不用先点开导入框）、支持多文件（逐条试、逐条报结果，一个坏 JSON 不会把整批带走）、按钮带文字标签；
  `importHint` 也顺手从"只接受 API 格式"改成三种输入的真实情况。
- **预设可见可删**：列表项与详情都带 `presets` 名字（**空数组也照给**，否则前端删不掉最后一个），展开卡片能删单个预设；删不存在的名字回 404 而不是假装成功
  （新增预设仍走 `comfyui_workflow_edit` 或手改 `.meta.json` —— 面板上没有"一组完整参数"的表单）。
- **送进对话**：把 `请用工作流 <id> 出图：` 填进输入框草稿，生图仍然走模型侧工具，
  不在面板里复制一套生图前端。

顺手修的：

- `fetchServiceStats` 之前把服务端返回的 `progress` / `queuePosition` 丢了 —— 控制条只能显示
  "有个任务在跑"，看不到排队位次与百分比。
- `tests/lint.mjs` 补上「函数参数解构」也算声明：子组件 `function Row({ onOpen })` 里的 `onOpen`
  之前会被误报成未定义。

测试：`tests/workflow-grouping.test.mjs`（11 条）钉住分组 / 归一 / 兜底 / 排序 / 筛选 / 搜索 /
折叠策略；`tests/api.test.mjs` 补预设真入口用例（列表带名字、删预设不动备注与开关）；
`tests/render.mjs` 补卡片收起态与展开态断言。变异验证：斜杠不归一、兜底不置底、搜索不强制展开
三项都会让对应用例变红。

### 相册：媒体语义收口（0.8.0 前的两处小毛刺）

视频/音频已经进了相册（见下文《相册支持视频与音频产物》），但动作按钮与文案还停在"只有图片"的年代：

- **图片语义的动作按钮按 `kind` 收掉**：`复制图片`（走 `createImageBitmap`）、`涂蒙版`（要像素）、
  `反推提示词`（要有画面）、`送进吃图工作流`（槽位只收图片）、`送进对话`（图片附件不收 mp4）
  —— 对视频/音频点了只会报错或塞错类型，留一个这样的按钮比不给更糟。
  `复制提示词` / `导出工作流` / `再跑一次` / `删除` 保留：它们只依赖 sidecar，与媒体类型无关。
- **灯箱的缩放控件也只对图片显示**：视频/音频不套 `transform`，控件留着只会让百分比空转。
- **删除相关文案从"图片"改成"媒体"**：`removeBody` / `bulkRemoveTitle` / `bulkRemoveBody` /
  `bulkDeleted` / `bulkDeletePartial` / `duplicateHint`（中英各一组）。服务端的报错文案上一批
  已经改成"媒体文件"，前端这份这次跟上。

`tests/render.mjs` 补断言：视频卡片没有「复制图片」「送进对话」、但仍有「复制提示词」「删除」；
图片卡片不受影响。

### 角色库：两类校验各补一道闸门

角色库此前**没有专门的测试文件**：路由分派跟着通用路由在 `api.test.mjs` 里测过，
缺的是「数据 ↔ 白名单 ↔ 落盘 ↔ 生产取图参数」这几层。这几层坏起来全是静默的，
表现只在用户点开卡片的那一刻：

- 取图配置漏传参数（`pathPattern`、`cacheSubdirs`、`recursiveCache`）→ 每条图 502，
  或缓存上限与 `/characters/cache` 双双失效，而导入脚本毫无反应
- `catalog.json` 里两个角色指向同一个文件 → 某个角色永远显示别人的图
- 落盘不按 `<id>_<slot>` 改名 → 20 个角色的三视图互相覆盖，工作流里那条旧路径悄悄指向另一张图
- 运行时 origin 与 `catalog.origin` 各拼一份 → 上游迁移后体检全绿、生产全 502

**离线：`tests/characters.test.mjs`（13 条，进 `npm test`，零网络）**

- 取图参数**从生产工厂 `characterImageOptions()` 导入**，测试不再自己配一份：
  以前每个用图用例都自建 `createImageCache({...})`，entries 那边删掉 `pathPattern`
  或把 `cacheSubdirs` 写成 `['img']`，测试照样全绿。现在这两处一改就红，
  并且会断言缓存真的落在 `设定图/` 子树下、`stats().diskFiles > 0`
- origin 与 `characterOrigin(commit)` 互锁：两处各拼一份是"体检全绿、生产全 502"的根
- `catalog.json` 的 120 条路径全部过 `CHARACTER_PATH`（同样从生产代码导入），
  且互不相同、不含 `..`、不是绝对路径、不越出所属角色目录
- 白名单反向：八种坏形状必须被拒，其中两条 `.png` 结尾的穿越形状只能靠 `..` 那段负向断言拦住
- 两份手写槽位清单对账：工具的 `view` enum 必须覆盖 catalog 出现的每个槽位键，
  且不提供 `preview`（那是面板缩略图）；路由侧六个槽位逐个断言 200
- 落盘改名：工具与 `/characters/fetch` 两条路径都验，同一角色两个槽位落成两个文件、
  内容不同 —— basename 全库相同，这是真会互相覆盖的点
- `/characters/image` 的**响应体**也断言（只验头的话，`res.end()` 不写体会让缩略图全白、
  「入对话」传 0 字节 blob，而头一切正常）
- 取图 URL 逐段编码：目录名含中文，整串编码会把 `/` 变成 `%2F`，上游一律 404
- 工具的默认 `view`、`bad_input` / `not_found`（不打网络）/ `no_view` 三条错误路径、
  搜索结果的 `views` 与空结果 `hint`，以及返回值能无损 JSON 往返（宿主对 `undefined` 那条规则）
- 字节数与 `CHARACTER_MAX_BYTES` 互锁：catalog 里最大的一张（2.65 MB）必须仍在取图上限以内，
  超了那个角色会永远取不到图而导入脚本不会有任何反应
- `catalog.json` 改了要能看见：索引的 mtime+size 指纹变了就重建，面板常驻不该显示旧数据

**在线：`npm run characters:verify`（12 条探针测试，不进 `pretest`）**

`catalog.json` 记的是上游相对路径与导入那一刻的字节数，没有任何东西保证它们今天还在。
脚本对 120 条路径发 `HEAD`（并发 8、5xx 与 429 才重试、`redirect: 'error'`），
核对 `200` 与 `Content-Length === bytes`。**默认只拿状态码与长度**；上游不给长度时
才对那一条补一个 `Range: bytes=0-0`，取首字节、从 `Content-Range` 读总长然后立刻断开 ——
不下载、不落缓存，许可边界不变。

判定分四类且互斥：`ok` / `unreachable` / `size-mismatch` / `unmeasured`。
「有字节数但量不出长度」归 `unmeasured` 而不是「不符」，**说不清就不报通过**。
失败逐条打印路径与原因，非零退出；`--limit` 抽查，`--json` 给机器读，
`--catalog` 可以拿别的目录演练故障。

`probe` / `rangedLength` 抽成可导入的纯函数并有测试（`tests/verify-characters.test.mjs`）。
起因是一个真 bug：`Number(headers.get('content-length'))` 在头缺失时是 `Number(null) === 0`，
于是「没给长度」被当成「长度是 0」—— 有字节数的条目被误判成不符（假红），
只有路径的 preview 被判 ok（假绿），而 `Range` 兜底永远执行不到。

现状：**120/120 可达；100 条槽位图的字节数与 catalog 逐条相符**
（20 张 preview 在 catalog 里只有路径，只验了可达）。

### P0：异步索引断链、角色库接入 compose、写接口测试债

**异步出图的产物现在也会进资产索引。**

原来只有「同步等到产物」那条分支 `index.add(...)`。而默认 `runWait: async`：提交即返回，
产物由后台 `watchRun` / `sweepRun` 收 —— 那条路只更新运行注册表，索引里永远没有这一行。
后果很安静：图在磁盘上、相册扫目录也看得见，但 `tags` 参数**等于没写**
（`/assets?tag=…` 查不到），而且工具描述把这缺口写成了特性。

- 新增 `shared/run/record.ts` 的 `recordArtifacts()`：同步分支、异步 watcher、面板
  `/run`/`/rerun`、批量提交共用同一份登记逻辑。两边各写一份的话 `tags` / `workflowHash` /
  `promptId` 迟早漂，而漂移只表现为"某些图按工作流筛不出来"，没有报错。
- `PendingContext` 增加 `tags`：异步登记发生在几十分钟后，提交方早就不在了，
  标签只能随上下文走。sidecar 里也写一份 —— 索引是可删可重建的派生数据，
  重建时要靠 sidecar 找回标签。
- `watchRun` / `sweepRun` 增加 `onCollected` 回调（形参推导，不引组件类型）。
  `shared/run` 不认识 `AssetIndex`，只声明形状，装配层注入。
- `/run` 与 `/rerun` 的路由依赖增加 `index`，由 `entries/workflow.ts` 注入 `rt.index`。
- `comfyui_run` 的 `tags` 描述改成实话：同步与异步都登记。

**`comfyui_compose` 能直接吃角色设定板了。**

- `MaterialSource` 增加 `character` / `fetchCharacter(id, view)`；角色 entry 注册进
  `rt.materials`，落盘名 `<id>_<view>.<ext>`（所有角色的切片 basename 相同，不改名会互相覆盖）。
- `MaterialRole` 增加 `'character'`，语义词只收**具体词**：`角色 / 三视图 / 立绘 /
  character / turnaround`。语义词表里**不能有泛词** —— `matchRole` 按数组顺序先命中
  即返回，而 character 排在最前，收 `设定` 会让 label「服装设定图」被判成角色：
  衣装的线索被丢掉，两张参考图还会静默对调（实测：角色板进服装槽、针织衫进角色槽，
  不报错，唯一提示是一行 assumption）。裸 `sheet` 同理会让 `Costume Sheet` 先命中角色。
  「角色设定图」「Character Sheet」仍分别由 `角色` / `character` 命中。
- `comfyui_compose` 增加 `characterId` 与 `characterView`（默认 `turnaround`）。
  视图清单与 `panel-characters/server/tools.ts` 的 `VIEWS` 是两处手写（组件之间不能
  互相 import），由一条对账用例钉住两者一致 —— 漂移的后果不对称：多一个视图会被
  compose 硬拒，少一个则靠 `fetchCharacter` 抛错兜住。
  放不下时进 `dropped` 并说明原因，不静默丢。

**角色库的安全边界与面板收口。**

- `comfyui_character` 去掉自定义 `outputDir`，统一落 uploads —— 与 `comfyui_pose` /
  `comfyui_costume` 对齐。多一个自定义目录就多一条要校验的写路径，而这个工具没有
  "落到别处"的场景。
- 角色面板补上请求序号守卫：快速切品牌时旧响应不再覆盖新列表（表现是"点了 DeepSeek
  又闪回上一个品牌"）。**防抖窗口里也要 bump 序号** —— 从点品牌到新请求真正发出之间
  有 250ms，只靠 `load` 里的守卫，那段时间旧响应仍然"是最新的"。卸载时清掉防抖计时器。
- 工作台外壳的 `enabled` 初值补 `'panel.characters'`，与 `componentStateOf` 的键集对齐。
  消费处是 `enabled[component] !== false`，键缺失得到 `undefined` 也照样显示 ——
  所以这行**不是**硬约束，只是为了可读；真正钉住键集的是 `tests/arch.mjs`。
- `comfyui_character` 的参数表有了断言（恰好 5 个键、不含 `outputDir`）：`additionalProperties`
  只在宿主侧生效，单测直呼 `execute` 时旧参数会被静默忽略，没有这条断言删参数等于无法验证。
- README 里「衣装面板只展示写实版」的旧描述更正为「可在写实 / 二次元之间切换」。

**相册检索与写接口测试债。**

- `/items?q=` 的 haystack 纳入 `checkpoint` 与 `workflowId`：能按底模名、工作流名检索。
  原来只搜文件名与提示词 —— 而用户常记得「那张 SDXL 出的」「那个放大工作流跑的」。
- `arch-write-routes.mjs` 的 `KNOWN_UNTESTED` **清零**。五条历史债
  （`/delete`、`/delete-many`、`/assets/rebuild`、`/service/stop`、`/free`）都补上了走
  `applyAll()` + 真实 `fetch` 的用例，断言分派层不再把它们拦成 405。
  其中 `/free` 的用例把 `baseUrl` 指到不可达端口：client 接了
  `supervisor.ensureReady()`，探通真实地址就会 `POST /free {unload_models:true}` ——
  一台正开着 ComfyUI 的机器跑 `npm test` 会真的卸载模型，这条用例只想验分派层。

### 工作流导入：UI 格式自动转换与 PNG 原图拖拽

ComfyUI 默认「保存」出来的是 **UI 格式**（`nodes` + `links` + `widgets_values`），
所以"在 ComfyUI 里导出 → 粘进面板"这条最自然的路径，八成在第一步就被拒。底层其实
早就有 `convertUiToApi` 与 PNG 文本块解析，缺的只是把它们接进导入接口。

- `POST /workflows/import` 接受三种输入：API 格式 JSON、UI 格式 JSON（自动转换）、
  `Content-Type: image/png` 的图。UI 转换需要 `/object_info`（widget 顺序只能从节点定义读），
  路由层注入一个 3 秒上限、不触发拉起的 getter；**拿不到时退回**「请在 ComfyUI 里用
  Export (API) 重新导出」，而不是猜。
  **只有 UI 格式才去拉** `/object_info`：API 格式是绝大多数导入，每次都为一次探针买单
  意味着离线机器上每次导入白等一轮 3 秒超时。
- PNG 导入优先取 `prompt` 块（API 格式，**离线也能导**），其次 `workflow` 块（UI 格式，
  走转换）。两块都坏才算失败 —— 坏块降级而不是整次放弃：`prompt` 解析不出来时
  `workflow` 往往还是好的。两个块都没有（普通截图、别的软件存的图）时明确拒绝并说清原因。
- 体积上限 64MB（4K 上采样的无损 PNG 能到 40MB，原来的 8MB 会把真实图挡在门外），
  按 `Content-Length` 预判，超限回 **413** 并写清上限 —— 「图太大」和「图坏了」对用户是两件事。
- 畸形 UI 结构（`nodes` 里混进 `null`、`inputs` 里混进非对象）不再变成 500 + 内部栈文本：
  转换器逐项跳过并记 note，`store.ts` 再把没预料到的异常统一转成 400。
- `readPngTextChunksFromBuffer`：原来只有按文件路径读的那一份，上传流还没落盘没法用。
  两份解析逻辑（tEXt / zTXt / iTXt）合成一处，文件路径那条读完头部字节也走它。
  相册扫描目录下那份完整副本（`panel-gallery/server/scan/png-text.ts`）随之删掉，
  改从 `shared/media` 引 —— 否则"合成一处"只是说法。
- 面板：文件选择器放开 `.png`，导入区支持拖放；转换产生的 `notes`（跳过缺定义节点、
  旁路直通、占位值回落等）会跟着成功提示一起显示 —— 那是"导进来了但可能跑不对"的唯一线索。
- 相册灯箱新增「存为模板」：拿当前图的字节直接调导入接口，从一张成品图恢复模板。
  **只对 `.png` 显示**（jpg/webp 上点一下只会白下载整张再吃 400）。
- 文件名走 `x-workflow-name` 头，中文先 `encodeURIComponent`（HTTP 头只收 latin1）。

`tests/workflow-import-ui.test.mjs`（12 条）钉住：UI 自动转换并落盘、没有 `object_info`
时退回可读提示且不写盘、PNG 的 `prompt` 块离线可导、PNG 无工作流块时明说、
UI 格式的 JSON 体、`object_info` 拉取失败降级成 400（不是 500）、PNG 只有 UI 块时走转换、
转换不出节点时 400 且不留半成品、**API 格式不去拉 `object_info`**、畸形 UI 结构回 400
且内部异常不外泄、超限回 413、`zTXt` / `iTXt` / 过短早退的解析器边界。

### 服务状态条与模板管理

后端的 `/system_stats`、`/free`、`/service/stop`、`client.interrupt()`、`removeWorkflow()`
与体检逻辑其实早就有，缺的是**面板上看不见、也不可控**：卡住的任务只能等，显存满了
只能重启，模板坏了只能一个个点开看。

- `shared/comfy/audit.ts`：把模板体检从 `tool-generate/tools/workflow-audit.ts` 下沉。
  面板（`panel-workflow`）不能 import `tool-generate`，而两份实现必然漂 ——
  用户会看到 `comfyui_workflow { audit: true }` 与面板给出互相矛盾的结论。
  工具侧那份改成纯转发，导出名与调用方都不变；依赖收窄成 `{ workflowsDir, client }`。
- `GET /service/stats`：显存利用率 + 最近 5 条活跃任务 + 服务状态。`/system_stats`
  的返回带一堆 `torch_vram_*`，面板只显示利用率，所以在服务端裁成三个数。
  **服务离线时不整块失败**：gpu 为空、service 仍然报状态，面板据此显示"显存未知"。
- `POST /interrupt` 进 `router.ts` 的 `POST_ONLY`（只有 POST 语义，漏登记就是真机恒 405）。
- `DELETE /workflows/:id`：走已有的 `removeWorkflow`，连 `.schema.json` / `.meta.json`
  一起删；不存在时 404（原来 DELETE 直接 405）。面板上有二次确认 ——
  删的是模板，不是产物。
- 工作流面板顶部控制条：显存百分比、活跃任务数、四个按钮（中断 / 释放显存 /
  停止托管服务 / 体检模板）。轮询是"上一次回来再排下一次"的递归 `setTimeout` ——
  `setInterval` 会在服务慢时把请求叠起来，而按钮整段时间都是 disabled。
- 面板卡片新增「删模板」按钮（带确认）。

**审查修掉的几处**（都会在真实使用里咬人）：

- `/service/stats` 与体检的 `object_info` 显式 `skipEnsure`。这条会被每 5 秒轮询，
  走 `ensure` 的话服务没起时会被顺手拉起 ——「停止托管服务」五秒后又被撤销，
  并且拉起失败没有失败记忆、每轮重试。
- `active` 只算 `running` / `queued`。`runs.list` 按序号取最近几条、**不按状态过滤**，
  直接取前 5 条会把"最近跑完的 5 条"说成"5 个在跑"。
- 体检失败现在能在面板上看见原因。它走的是 HTTP 200 + `ok:false`（服务离线 / 空库 /
  节点清单为空都是正常分支），而客户端原来用 `apiJson` 把这个响应当成错误抛掉，
  用户永远只看到"请求失败：HTTP 200"。
- `DELETE /workflows/:id` 的 id 校验挪到 `decodeURIComponent` **之后**，
  且 `removeWorkflow` 内部再拦一次。原来先判原始片段再解码，`..%2fvictim`
  解码成 `../victim` 交给 `path.join` —— 实测能删掉工作流目录外的任意 `.json`。
- `client.interrupt()` 返回它到底发出去没有。原来内部 `catch {}` 吞掉一切，
  面板上"已中断"永远是假消息（服务离线、没有任务、回 500 都一个样）。
- 删除后用主文件是否还在复核：删不掉（被占用 / 没有权限）回 500 说明原因，
  而不是被当成"工作流不存在"。
- `summarizeGpu` 在缺 `vram_free` 时跳过该设备 —— 原来按 0 算，显示成"已用 100%"，
  看起来像显存爆了。
- 测试卫生：`tests/api.test.mjs` 里那条写接口用例补了 `autoStart: false`。
  它此前只把 `baseUrl` 指到不可达端口，而默认 `autoStart` 会在连不上时去拉起本机安装的
  ComfyUI —— 实测这条用例跑满 180 秒冷启动超时、在安装目录里留下写入。修完全量测试
  从 3 分钟回到 14 秒，也不再动用户的进程。

`tests/api.test.mjs` 补一条走真实分派的用例：中断、显存统计、体检、删模板四条，
`baseUrl` 指到不可达端口并关掉 `autoStart` —— 否则一台正开着 ComfyUI 的机器跑
`npm test` 会真的被打断任务，而默认 `autoStart` 还会在连不上时尝试拉起进程把测试挂住。

> 终端面板的控制条这一批没接：它与工作流面板完全重复，而组件之间不能互相 import
> （抽成共享组件需要放进 `client/`，那个位置只允许装配层引用组件）。留作后续。

### 相册：涂蒙版 → 局部重绘闭环

`comfyui_compose` 早就支持 `baseImage` + `maskImage`，但面板上没有任何地方能产出一张蒙版 ——
模型只能拿到原图路径，`maskImage` 永远空着。这条链路缺的就是画笔。

- 新增 `MaskEditor`：灯箱里点「涂蒙版」打开。**显示层与数据层分开** ——
  显示层是红色半透明笔迹，数据层是黑底白笔迹（白 = 重绘、黑 = 保留，正是 ComfyUI 读的遮罩），
  导出直接对数据层合成。只用一个 canvas 再"反推"遮罩的话，颜色与透明度要来回换算，
  导出结果和眼睛看到的永远对不上。
- 撤销栈按**字节预算**限步：`getImageData` 一步就是 `w*h*4`（2K 图 16MB、4K 图 64MB），
  固定存 20 步会一次涂蒙版就把标签页吃爆。现在按单步体积算步数（8 步上限，96MB 预算）。
- 导出前先合成到黑底：橡皮擦过的地方是透明的，直接 `toBlob` 会得到带透明区域的图，
  ComfyUI 读亮度时行为不确定。
- 完成后走已有的 `POST /upload`（后端本来就有魔数与体积校验，不需要新接口）落进 uploads，
  再把**原图与蒙版两个绝对路径**粘进对话草稿（`comfyui_compose { baseImage, maskImage }`
  要的正是这两个路径）。只弹 toast 不够 —— 它 2.8 秒后就没了，用户抄不下来。

**审查修掉的（这批的第一版有几个真错）**：

- **弹层被灯箱盖住**：`.cmf-root` / `.csf-root` 用了 `z-index:60`，而灯箱是 2600，
  两个弹层的唯一入口都在灯箱里 —— 点开按钮界面毫无反应，整条功能进不去。
  现在统一 2900，**并把"弹层层级必须高于灯箱"写成断言**（类名检查查不出这种错）。
- **显示层设计是错的**：原先底图烘焙进 canvas，再用 `multiply` + `destination-in` 染红。
  数据层是不透明黑底，黑×红仍是黑，涂完半透明叠上去 → 没涂的区域被压暗 50%，
  而擦过的地方反而全亮（明暗关系反了）；橡皮 `destination-out` 还会把底图一起擦掉、露出黑。
  改成三层：`<img>` 放底图、显示层只放透明底红笔、数据层透明底白笔 —— 橡皮只擦笔迹，
  导出时数据层合成到黑底（透明 → 黑 = 保留）。
- **上传失败会丢画**：原来先关弹层再上传，断网或 413（`/upload` 上限 16MB）时
  画了几十笔的东西随弹层消失。现在上传成功后才关，失败留在原地可重试。
- **「送入工作流」只填第一个图槽会静默出错**：多图槽模板若第二个槽在模板里烤了文件名，
  `applyVariables` 不报错 —— 会沿用模板那张参考图连同模板的 prompt/seed，出一张
  "条件不对"的图；第二个槽空着时报一句看不懂的 `variable_unbound`。
  现在只列**恰好一个图槽且无蒙版槽**的模板（与 `comfyui_compose` 的"宁可报错不硬塞"一致）。
- 提交后盯住 `promptId`：相册本身不轮询，不盯的话用户只看到 2.8 秒 toast，
  然后什么都没有（`rerunAsInput` 早就为此加过同一段）。
- 工作流面板被关掉时，弹层不再把"没有这个接口：/workflows"这种开发者话术原样甩给用户。
- `tests/classes.mjs` 的前缀表补上 `cmf` / `csf`：漏了的话这两个弹层的 27 个类名
  既不进 defined 也不进 used，"全部通过"对它们是空转。

### 相册：删除改为回收站（软删除）

产物旁的 `.json` sidecar 是"再来一张一模一样的"的**唯一**凭据。误删一张图丢的不只是
一张图，是那一整组参数（seed / prompt / 工作流版本）—— 而删除在面板上只是一次点击。

- `/delete` 与 `/delete-many` **默认软删除**：图片与 sidecar 一起移进 `<root>/.trash/`，
  `soft=0` 才是原来的物理删除（含同 digest 副本与缩略图）。目录按份独立
  （`.trash/<stamp>-<rand>/.restore.json` + 文件），因为同一张图可能被删两次，平铺会撞名。
- 新增 `GET /trash`、`POST /trash/restore`、`POST /trash/empty`；面板工具栏有了回收站入口
  （列表 + 恢复 + 彻底清空）。
- `.trash` 进 `SKIP_DIRS` ——**并且把 `scan/constants.ts` 改成 `shared/media` 的兼容层**：
  它原本是一份完整副本，把 `.trash` 加在 shared 那份上不会生效（默认配置看不出来，
  `.trash` 以点开头被"隐藏目录"规则顺手挡住；一旦 `includeHidden: true`，删掉的图会回流，
  索引重建还会把它收进去）。与 `assets/authorize.ts`、`assets/roots.ts` 同一个教训。
- 恢复时不覆盖：原路径被占时循环找 `-restored` / `-restored-2`…（`renameSync` 会覆盖既有
  文件，只查一次的话第二次恢复会把第一次恢复回来的图静默顶掉），并对最终路径再过一次
  授权根校验。
- 清空只删**我们造的**那些目录（必须带 `.restore.json`）：授权根下可能本来就有用户自己的
  `.trash`，一次点击就 `rm -rf` 别人的东西不可接受；跳过的条目数会回传。
- 软删除时 `removed` 里仍给原路径：前端按它算"要撤掉哪些卡片"，只回 `trashed` 的话
  前端得到一个空集合 —— 卡片留在原地、总数却 -1。
- 删除确认文案一并改掉（原来写着"不进回收站、无法恢复"，与现在的行为正好相反），
  `docs/design.md` 里把这条写成契约的两处也同步。

`tests/api.test.mjs` 补两条回归：`includeHidden: true` 下回收站里的图不回流、
恢复撞名不互相覆盖。四条变异（`.trash` 失效、`removed` 回空、撞名只查一次）都被拦住。

### 相册：双图对比与结构化筛选

- **双图对比**：选择模式下恰好选中两张时，「对比」可用。两种看法 —— 并排（比构图与色彩）
  与拉杆（`clip-path` 切左图，拖动滑块在两张之间划一条线，适合看"同一构图改了什么"）。
  侧栏只列**不同**的参数：`diffItems` 是纯函数，按"影响画面最大"排（提示词 → 种子 →
  采样参数 → 模型 → 尺寸），相同的行折叠。把两份 sidecar 并排贴出来等于让用户自己找差异，
  那正是这个弹层要省掉的事。
- **结构化筛选**：工具栏加工作流下拉、底模输入框、方向四档（全部/横/竖/方）。
  与搜索框互补 —— 搜索是"我记得点什么"，这些是"我只要这一类"。后端 `/items` 支持
  `workflow`（精确 id）、`checkpoint`（子串：用户记得 `sd_xl`，不记得完整文件名）、
  `aspect`（`aspectOf` 按 5% 容差分类：`1536×1500` 在视觉上就是方图，严格相等会判成横图）。
  非法的 `aspect` 值被忽略而不是 400。

`tests/api.test.mjs` 补一条真入口用例：三种筛选各命中预期、非法 aspect 不筛空。

### 相册筛选与对比的审查修复

`checkpoint` 筛选最初只读列表项的顶层字段，而**插件自己写的 sidecar 把参数全放在 `vars` 里**
（`runner.ts` 只落 `workflowId` / `workflowHash` / `vars`，没有顶层 `checkpoint`、也没有内嵌
`workflow`）—— 于是「按底模筛选」对自家产物永远是 0 条，而自家产物正是相册里的绝大多数。
现在 `summary` 的两条读法按可靠性排：顶层字段 → `vars`（`ckpt_name` 等约定键名，再兜底到
任何 `.safetensors` 值）→ 内嵌 `workflow` 图。同一根因也修好了 `q` 里对底模的模糊搜。

顺带：

- `checkpoint` 大小写不敏感（占位提示让人打的是 `sdxl`，而真实底模名常是 `SDXL_*`），
  两侧都折小写，两层任一层保留即可。
- `aspect` 的 5% 容差改成区间比较：`Math.abs(ratio - 1) <= 0.05` 在边界上浮点不对称 ——
  `1050×1000`（1.05）算出来是 1.05000000000000004，会被判成横图，而转 90° 的
  `1000×1050` 却是方图。
- **未知尺寸不参与方向筛选**：`includeBare` 打开时非生成图没有宽高，把它们一律排掉会让
  那个开关看起来坏了。
- 双图对比改从 `/meta` 读完整 sidecar 再做 diff。只用列表项的话，两张只差 steps/cfg/底模的
  图会显示成"参数完全相同"—— 那是弹层里最响也最错的一句话。读不到 sidecar 时标题退成
  "列表可见字段没有差异"。
- 弹层层级断言补上 `.csm-root` / `.cpm-root`（这条检查就是为了防"被灯箱盖住"，新弹层不该
  缺席）。

测试夹具补了 **runner 形态**（参数在 `vars`）—— 上一版手写的顶层 `checkpoint` 形态在生产里
只对应 ComfyUI 原生内嵌块，恰好把上面那个 bug 盖住了。变异验证：`summary` 不再从 `vars`
取底模、两层都去掉大小写归一 —— 都被拦住。

### 工作流预设与参数网格

**预设**：模板的 `.meta.json` 支持 `presets`（名字 → 一组默认 vars）。
`comfyui_run { preset: '夜景' }` 把它铺底，同时传的 `vars` 覆盖同名键 ——
`{ preset: '夜景', vars: { seed: 9 } }` 就是"用夜景那套参数，但换个种子"。
名字拼错时报 `preset_unknown` 并列出可用预设（静默忽略会让人以为"预设没生效"）。
`comfyui_workflow` 的列表项带上 `presets` 名字，模型不用猜。

放在 `.meta.json` 而不是 `.schema.json`：预设是"常用参数组合"，跟措辞、分组这些
展示层的东西不是一回事，而且它可以直接被 `comfyui_workflow_edit` 写。

**网格**：`comfyui_run_batch { grid: { cfg: [5, 7], sampler_name: ['euler', 'dpmpp_2m'] } }`
按维度笛卡尔展开成 4 条，共用外层 workflow 与同一个 batchId。
**上限在展开过程中就拦住**——先算乘积再判断的话，一个手滑的 20×20×20 会先造出 8000 条
才报错。与 `runs` 二选一（同时给以 `runs` 为准）；非数组、空数组都给明确错误。

`tests/presets-grid.test.mjs`（5 条）钉住：预设合入与覆盖、`preset_unknown` 带可用列表、
预设形状不对时不崩、网格四种组合都真的提交、三种边界报错。断言落在**真正交给 client
的那份 workflow** 上——"看起来生效、实际没进参数"是这两个功能最容易出的错。


**审查修掉的**：

- `preset_unknown` 原来用 `error` 字段，而 `render` 只读 `message` —— 模型只看到一句
  「执行失败。」，可用预设列表一个字都到不了。现在用 `message`，并补了**直接跑 render**
  的断言（只断言返回对象的话，这类"模型看不到"的问题测不出来）。
- `comfyui_workflow_edit` 写备注会把整份 meta 从零重建：`presets` 与 `enabled` 被静默抹掉。
  现在先摊开已有 meta 再覆盖（面板那侧一直是摊开的，两条写入路径不能语义相反）。
- 列表侧与运行侧各写一份预设归一化，于是"清单里列着 `broken`、点了却说没有这个预设"。
  现在共用 `shared/workflow` 的 `normalizedPresets`；预设名查找改用 `Object.hasOwn`
  （`toString` / `constructor` 会踩原型链，静默当空预设提交）。

> 相册按 batchId 折叠产物这一条这批没做：`batchId` 目前只活在运行注册表里，sidecar
> 里没有它，要折叠得先让 `runner` 把它写进 sidecar（会动到 sidecar 的契约）。

### 本机模型盘点与 LoRA 触发词

`comfyui_workflow { models: true }` 盘点本机可用模型，按类别分（checkpoint / lora /
vae / controlnet / upscaler），也可以只给类别名看一类。**复用已有工具、不新增工具名** ——
工具数量本身就是负担，而"我本机有哪些模型"和"我有哪些模板"是同一个问题域的两面。

- 收集的唯一入口是**字段必须像模型槽位**（`*_name` / `*_file` / `*_path`），并显式排除枚举字段。
  审查实测过：只按"节点类型带关键词就收"的话，`UNETLoader.weight_dtype`、
  `CheckpointLoader.config_name`、`LatentUpscale.upscale_method` 会把精度档位与插值算法
  列成"本机可用的模型"。节点类型只用来消歧 `model_name`（Upscale → upscaler，其余 → checkpoint）。
- 同一判据把 `other` 从"形同虚设"救回来：`InstantIDModelLoader.instantid_file`、
  `IPAdapterModelLoader.ipadapter_file`、`GLIGENLoader.gligen_name` 之前一条都不在清单里。
- 非模型 COMBO（`sampler_name` / `scheduler`）不进清单 —— 否则分不清"缺模型"和"缺采样器"。
- 离线时回 `ok: false` 并说明原因，**不假装"本机没有模型"**：一份空清单会被模型
  当成"这台机器什么都没有"，从而放弃使用本机已有的权重。
- `models` 给错值（`'loras'` / `'all'`）报错并列出合法值，**不静默降级成列工作流** ——
  那会让模型以为自己拿到了模型清单。`'TRUE'` / `'1 '` 这类大小写与空白差异归一后仍有效，不算错。

**LoRA 触发词**：`<插件数据目录>/loras.json`，形状容忍两种写法
（`{"模型名": "触发词"}` 或 `{"模型名": {"triggers": "…"}}`）。读失败只报一句人话、
不抛 —— 那是可选增强，不该让盘点本身挂掉。文件不存在时也把路径回给模型，
并在 hint 里写明格式：被指到一个文件却不知道怎么写，等于没给。

工具 description 与 README（中英）从"四档"改成"五档"：模型**只看得到 description**，
`models` 不写进去等于不存在。

`tests/model-catalog.test.mjs`（5 条）钉住：分类、触发词两种写法与两种写坏方式、
工具分支在线/离线两种表现、枚举字段不进清单、`models` 给错值必须报错。

### 相册支持视频与音频产物

出图工作流会顺带产出视频（AnimateDiff、SVD 这类）与音频，之前它们被整体排除在资产库之外 ——
"生成了却看不见"，而用户往往正是想找那段动图。

- `MEDIA_EXTS`（图片 + 视频 + 音频）成为扫描与删除校验的唯一判据；`mediaKindOf(ext)` 归一成
  `image` / `video` / `audio`，列表项带 `kind`。
- 卡片：视频用 `<video muted preload="metadata">`（**通常**能显示首帧 —— 具体取决于浏览器，
  Chrome 只拿到 moov 时画面要到播放才出现），
  音频用占位块；灯箱里视频/音频换成自带控件（视频不做缩放平移 —— 会和捏合手势打架）。
- **缩略图对非图片直接返回 undefined**：`ensureThumb` 里是先试再 catch 的，视频会为每个请求
  白试一次解码。现在先按扩展名判，非图片根本进不去。
- `MIME_BY_EXT` 补全视频/音频：`/file` 的 Content-Type 决定浏览器认不认，给成
  `application/octet-stream` 的话 `<video>` 直接空着。
- 删除的报错文案从"只能删除图片"改成"只能删除资产库里的媒体文件"。

`tests/api.test.mjs` 补一条真入口用例：mp4/mp3 进列表且 `kind` 正确、`/file` 的 MIME、
`thumb=1` 回退原文件（不是 404、也不是 image/webp）、视频可删除。

**审查修掉的**（两条都会让"视频真的能看"落空）：

- **`/file` 不支持 Range**：灯箱里 `<video controls>` 的进度条**拖不动**（用户看到的是
  "播放器坏了"），而卡片网格一页 60 个 `<video preload="metadata">` 各自从字节 0 拉整个文件
  （动辄几十 MB）。现在支持单区间 `bytes=start-end` / `bytes=start-` / `bytes=-N`，
  返回 206 + `Content-Range` + `Accept-Ranges: bytes`，越界回 416 + `*/总长`。
- **`.mkv` / `.avi` 浏览器解不了，却没有任何降级**：之前是网格里一块黑卡 + 灯箱里一个永远
  不播的控件条，没有任何"为什么"或出路。现在 `<video>` 带 `onError`，失败时换成占位块
  （卡片给一句"浏览器解不了这个格式"，灯箱直接给出文件路径让你用系统播放器打开）。
  顺手把灯箱视频的 `autoPlay` 配上 `muted`——相册是浏览场景，自动出声比"不自动播放"更打扰。
- **MIME 表原来有 5 份，只有 `/file` 那份补了视频/音频**：于是索引重建写进去的 `.mov` / `.flac`
  是 `application/octet-stream`，`kind=video` 筛不到、`kind=file` 反而命中。现在收口成
  `shared/media/constants.ts` 里唯一的一份，`rebuild.ts` 与 `runner.ts` 都改用它。
- **去重键不含媒体类别**：图片与视频若共享同一组 sidecar 字段会被合成一条，视频只剩灯箱里
  一行路径、删除合并项时还会被一起删掉。`looseKey` 现在带 `kind`。
- `tests/render.mjs` 补了视频/音频的渲染断言（这条 CR 之前是零覆盖，整条分支删掉都没人管）。

**`customRefsDir` 没有做**，理由见下一条：现有 `assetRoots` 已经覆盖"把私有参考图库挂进来"。

## 0.7.3 — 2026-11-19

### 修复：角色库的两个缺口

**每个槽位加了「入对话」。** 之前只有「落盘」——拿到本机路径给工作流。但看设定图的时候
更常见的动作是「我想就着这张图说点什么」，所以要能直接贴进输入框。走的是衣装库同一套
`addImageToConversation`，没有另起一份实现。

**详情区跟着筛选区一起吸顶。** 原来详情是列表上方的一个普通块，往下翻列表它就滚走了，
想对照着看只能滚回去。现在把它放进筛选区容器内部（那个容器本来就是 sticky），两者
一起钉住；五张图全展开会占满整屏，所以给它加了 `max-height: 42vh` 和内部滚动。

## 0.7.2 — 2026-11-18

### 新增组件：角色库 `panel.characters` —— AI 娘设定图（20 个角色 / 100 张图）

夹在标签库和姿势库之间的新页签。数据来自 [lmy414/ai-chan-sheets](https://github.com/lmy414/ai-chan-sheets)，
每个角色五个槽位：**三视图 / 表情 / 服装拆解 / 道具细节 / 整板总览**。

- `comfyui_character`：给 `query` 搜（能命中副标题与描述里的词，`狐娘` / `鲸鱼` 都行），
  给 `id` + `view` 取图落盘，返回绝对路径给工作流当参考图。
- 面板按品牌筛选（15 个品牌，胶囊 tab 横滚），点开卡片才拉五张图 —— 20×5 全预加载会把上游打满。
- 卡片用 **4:3 横版**而不是竖版：设定板本身是横的，竖卡片会把三视图裁成中间一个正面。

**许可比另两个素材库严格一档**：CC BY-NC-SA 4.0，仅非商业参考，且禁止再分发图像数据。
所以仓库只放元数据，图片运行时按需代理、不预取、不镜像，见 `data/characters/NOTICE.md`。

导入脚本 `npm run characters:import` 解析 README 的图鉴表格拿「preview ↔ 角色目录」对应，
并从 git tree 取实际存在的文件路径 —— 不按序号拼模板（12 号有两个变体，拼不出）。

### 取图缓存：为角色库补的四处能力

`createImageCache` 原先只为姿势/衣装设计，接角色库暴露了四个缺口：

1. **`materialize` 支持指定落盘名**。角色图 basename 全库相同（都叫
   `横版完整设定图_01_三视图_查看用.jpg`），只按 basename 落盘会让 20 个角色互相覆盖。
2. **`recursiveCache`**：缓存允许按子目录分层，`pruneDisk` / `stats` 递归遍历。
   不打开时行为不变（姿势/衣装仍是一级文件）。
3. **URL 逐段编码**：上游目录名全中文，直接拼可能因空格 / `@` / `·` / 括号而 400。
4. **`maxBytes` 可配**：默认 8 MB；角色库的整板切片最大 13.8 MB，用 16 MB。

## 0.7.1 — 2026-11-17

### 新增组件：`tool.sync-wait` —— 出图工具要不要接受 `wait`

「同步等待」现在是一个**独立的可开关组件**，出现在宿主插件页的组件列表里：

- **开着（默认）**：`comfyui_run` / `comfyui_rerun` / `comfyui_run_batch` 暴露 `wait` 参数，
  默认值由配置 `runWait` 决定，「工作流管理」面板上也能切。
- **关掉**：三个工具的 `wait` 参数从 schema 里消失，一律异步提交；面板上那个开关一并隐藏。

关掉它的场景很具体：如果你从来不用同步等待（批量刷图就是典型），少一个参数
能让模型少一次犯错的余地。实现上它不注册任何东西 —— `wait` 的解析在工具里，
装配这三个工具的 `generate` entry 直接读 `disabledComponents`（各 entry 是独立 bundle，
不能靠模块变量互相通知），这条 entry 的存在意义就是让这个能力在插件页可见、可关。

**注意它只能通过 `disabledComponents: ['tool.sync-wait']` 关**：在宿主插件页停掉这条
entry 并不会把键写进 `disabledComponents`，而真正读键的是 `generate`，所以 `wait` 参数照旧存在。

### 新增：出图的同步 / 异步可以设成默认了

以前只能每次调用传 `wait`。现在配置项 `runWait` 决定默认值，而且**「工作流管理」面板上
就能开关**，改完下一次提交即生效、不用重启：

- `async`（默认）：提交完立刻把控制权交回对话，出图完成后插件往会话推一条消息
- `sync`：一直等到产物落盘才返回，顺带把产物登记进资产索引

优先级是「面板开关 > 配置 / `COMFYUI_RUN_WAIT` > 内置默认」。工具调用里显式传 `wait`
仍然覆盖默认值——这个开关管的是「不传的时候怎么办」。

**等待上限单独成了一个配置项 `runWaitMaxMs`（默认 30 分钟）。** 原来 `parseWait` 借的是
`timeoutMs`——那是单次 HTTP 请求超时，默认只有 2 分钟，而正常出图就能超过 2 分钟。
借它的话「同步」实际会变成「等 2 分钟然后返回 pending」，与开这个开关的意图相反。
`timeoutMs` 保持原义（HTTP 请求超时），两者不再共用一个数。

注意环境变量那条有个坑：`resolveSettings` 是「配置里有值就用配置」，所以 `cordis.patch.yml`
写了 `runWait: async` 之后 `COMFYUI_RUN_WAIT` 永远不会生效。想用环境变量得先删掉那一行，
注释里已写明。

## 0.7.0

> **升级前请读这一段。** 工具从 16 个合并到 12 个，旧名字已不存在。
> 如果你在自己的提示词或脚本里写过 `comfyui_costume_search` 这类名字，需要改。

### 破坏性变更：工具 16 → 12

每一处合并都是「搜索 + 取图」或「列表 + 详情」这种同一件事的两半——分开时模型得先调一个
再调另一个，还常把 id 传给搜索接口。现在按参数区分：

| 旧 | 新 | 怎么区分 |
| --- | --- | --- |
| `comfyui_costume_search` + `comfyui_costume_fetch` | `comfyui_costume` | 给 `id` 取图，给 `query` 搜索 |
| `comfyui_pose_search` + `comfyui_pose_fetch` | `comfyui_pose` | 同上 |
| `comfyui_workflow_list` + `comfyui_workflow_inspect` | `comfyui_workflow` | 不给 `workflowId` 列表，给了看详情，给 `audit: true` 体检全库 |
| `danbooru_lookup` + `danbooru_lookup_batch` | `danbooru_lookup` | 给 `query` 查一个（没命中会联网），给 `queries` 批量（只查本地） |

`comfyui_run` 的 `waitMs` / `timeoutMs` 合并成一个 `wait`：`false` 异步提交、
`true` 等到产物落盘、给数字表示最多等这么久。不再有独立超时参数。

**提示词参考整块移除**（净 −2554 行）。那部分内容与工作台 skill 重复，而且更新总是滞后于
实测结论——留在两个地方，模型会读到互相矛盾的版本。

### 新功能：衣装库接第二个画风 —— 二次元版 1320 套

`comfyui_costume` 加 `source` 参数：`real`（默认，1407 套实拍风）与 `anime`（1320 套二次元风）。

数据来自 [ai-costume-gallery-zh](https://github.com/Deeyu/ai-costume-gallery-zh) 的 `costume-anime/`，
与写实库**同一个作者（ギア @giaaibusi）、同一套规格** —— 都是不含人物的衣装搭配、带中文标签与英文关键词。
区别只有画风。这一点很关键：Danbooru 那类插画带人物、带背景、动作不定，
当服装参考图会把这些无关变量一起喂进去；这套图本身就是纯服装，没有那个问题。

**两库分开索引、分开缓存、分开原站**：

| | real | anime |
| --- | --- | --- |
| 套数 / 分类 | 1407 / 8 类（春季穿搭…） | 1320 / 8 类（春装…） |
| 原站 | `ai-pose-gallery.anhao.app` | `ai-costume-anime-gallery.pages.dev` |
| 图路径白名单 | `(thumbs\|img)/costume/*.webp` | `(thumbs\|img)/*.webp` + `png/*.png` |
| 缓存目录 | `cache/costumes` | `cache/costumes-anime` |

两库 id 都是 `SPR-xxxx` 格式，所以**必须显式指定 source，不能猜**。

**词表不完全一样**（同源数据的两套译法）：动画版「缎带 / 吊带背心 / 牛仔布 / 皮革」，
写实版「蝴蝶结 / 吊带衫 / 牛仔 / 皮质」。skill 里补了这组对照。

**两库都没有"风格/品类"这一层**：`水手服` / `和服` / `校服` 依然零命中 —— 这是数据本身的限制，
要用构成单品去描述（水手服 → `衬衫 百褶裙`）。接之前就实测过，不是接完才发现。

**许可**：上游允许用作创作参考（含商业作品），但**禁止再分发图像数据、禁止批量下载（含工具自动获取）**。
所以照搬写实库那套做法：仓库里只放元数据（1320 条的编号/分类/标签/英文词/图地址），
图片运行时按需代理、落本机缓存、不再分发，**不做预取也不做镜像**。这条写进了 `data/costumes-anime/NOTICE.md`。

**面板也能切了** —— 第一版只做了工具层，面板仍只展示写实版，用户装上一看"看不到"。
衣装库的筛选行加了画风下拉（写实风 / 二次元风），选择存进 localStorage。
切库时会**清空分类**：两库的分类名不通用（写实版「春季穿搭」vs 动画版「春装」），
留着不存在的分类名会查到空列表。

`/costumes`、`/costumes/stats`、`/costumes/image`、`/costumes/fetch`、`/costumes/cache` 五条路由
都按 `?source=` 分派；动画库没挂上时回 404 并说明，不会悄悄给写实版的数据。

`npm test` **561/561**（新增 11 条：两库分开索引、source 分派、坏 source 报错、未接库时降级、
词表差异、风格词两库都零命中、按 source 取图、面板切换、两库 stats 与分类名不通用、
动画版原站与 png 路径）。


### 改进：衣装分类从下拉框改成横向 tab

一千多套衣装时，分类下拉框要先展开再选，翻找成本高。现在分类做成顶部一排胶囊 tab，
每个带该分类的套数，点一下直接切；tab 跟着筛选区一起吸顶，翻到中途也能换分类。
切换时会自动滚回顶部——`schedule` 会把列表清空重载，滚动位置不归零就会看到一片空白。

分类名与套数来自 `stats.categories`，两套画风的分类各自独立，换画风时 tab 会随之重排。

### 改进：姿势库改成两级 tab（体系 / 分类），分类按体系收窄

姿势库有 26 个动作分类，平铺一行 tab 仍要横向翻。所以做成两级：体系一行（4 个）、
分类一行，且分类随所选体系收窄——`GET /poses/stats?system=full` 只回该体系的分类，
26 个降到 3-13 个（full 9 / sexy 5 / bust 3 / pair 13）。换体系时清空已选分类并滚回顶部。

筛选区顺带吸顶，翻到中途也能换体系或分类。

### 修复：切体系/画风后 tab 仍显示上一套分类

新统计回来之前 `stats` 还是旧的，此时分类 tab 是「新体系 + 旧分类」，点下去必然空结果；
若 `?system=` 请求失败，旧分类会一直留在屏幕上。现在用 `statsFor` 记住这份统计属于哪个
体系/画风，不匹配就先不渲染分类，等新数据到了再出。

三个 tab 容器的角色从 `tablist`/`tab` 改成 `group`/`aria-pressed`：这些是筛选开关不是页签，
页签语义承诺 `aria-controls` 与方向键，而内容区只有一个网格，配不齐反而误导读屏。
统计数字加了 `title` 说明「不随搜索与筛选变化」，避免和筛选后的列表数对不上被当成 bug。

### 改进：素材库搜索的前缀回退与分类别名

接上一版的知识层，把两处"光靠告诉模型怎么查也救不了"的缺口补在代码与数据里。

**前缀回退**（`shared/search/fallback.ts`）：零命中时把最后一个词逐字砍短再试，最多 4 字。
实测救回 `坐着`→`坐` 58 条、`站着` 33、`跪着` 33、`坐在地上` 58、`坐在椅子上` 58。

**关键是判断"回退后的结果还能不能信"**。第一版按"命中占全库比例"卡（>20% 拒答），实测是错的：
姿势库只有 288 条，`坐着`→`坐` 正好占 20%，把**合理的**回退也拒了；而 `牛仔外套`→`牛仔` 只占 12%
反而放行 —— 那 175 条里「外套」在数据里是 0 条，一件外套都没有。

真正的判据是**被砍掉的是虚词还是实词**：`着` / `上` / `的` 这类砍掉不伤语义，照常给结果；
`裙子` / `外套` 这类实词砍掉等于换了问题，**直接拒答并给改写建议**。

**回退只对中文生效**。英文砍字没有语言学意义：`prone` 会依次变成 `pron` / `pro` / `pr`，
实测砍到 `pr` 撞上 4 组立位，全是假命中。

**分类别名**（`scripts/import-poses.mjs` 生成到 catalog 的 `aliases`）：姿势分类补英文与中文同义词，
`sitting` 49 条、`standing`、`lying` 都能查；「躺」并进 `趴卧` / `侧卧位`（数据原本只有仰卧/侧卧/俯卧）。
288 组全带上，catalog 248KB → 258KB。改的是**生成脚本**不是 `catalog.json`（后者是产物）。

别名**只标中性词**：`趴卧` 这个分类内部是「仰卧 11 / 其他 10 / 俯卧 9」，标 `prone`（俯卧）会让
查 prone 的人拿到一堆仰卧，所以只留 `lying` / `lying_down`。

**仍然救不回来的**（skill 里已写明）：`好看的连衣裙` 这类长修饰语、`水手服` / `和服` / `校服`
这类数据里没有的品类概念。

`npm test` **549/549**（新增 12 条：回退的四条边界 + 虚词判据 + 别名的四条精确断言）。
变异验证 3/3：`maxCuts` 放大到 100、英文也走回退、`aliases` 不参与检索。


### 改进：知识层补上素材库的查询词表（命中率）

反馈是"服装和姿势的查询命中率很低"。实测下来不是索引坏了，是**模型不知道该用什么词查**：

- 姿势：`坐姿` 30 条、`坐` 58 条，但 `坐着` / `坐在地上` / `sitting` / `standing` / `躺` **全部零命中**
- 衣装：`连衣裙` 393、`skirt` 470、`白色 针织` 59 都正常，但 `水手服` / `和服` / `校服` **全部零命中**

三个不同的病：姿势**只有中文没有英文**；匹配是**小写子串 + 空格 AND**，所以动词短语必然失败；
衣装缺"风格 / 品类"这一层 —— 数据只有单品的组合（`象牙白荷叶边针织衫・牛仔迷你半身裙・…`）。

这版先做知识层（零风险、立刻生效）：

- skill 正文列出姿势的**全部 26 个分类词**（带实测组数，含成人向那几类 —— 不替使用者筛）
- 衣装给出**单品 / 属性 / 配色**三组高频词（带命中数）与英文查询方式
- 两边都写明**哪些查法已经验证过是零命中**，省掉模型试错的那几轮
- 两个工具的 description 各加一句：姿势用中文分类词、衣装用单品名词

工具描述里那两句是重点：模型先看 description 再决定怎么调，skill 是深入时才读。

后续可做（本次没动）：零命中时"逐字砍尾再试"（实测能救 `坐着`→`坐`、`站着`、`跪着`、
`白裙子`→`白`，救不了 `躺着` 与 `水手服`）；以及给姿势分类加英文别名（要改 `scripts/import-poses.mjs`，
不能直接改生成出来的 `catalog.json`）。

`npm test` **537/537**（文档改动，无新增用例）。


### 改进：danbooru 查询 2 → 1（工具数 13 → 12）

`danbooru_lookup` + `danbooru_lookup_batch` → `danbooru_lookup`：**给 `query` 查一个，给 `queries` 查一批**。

两条路径的关键差别保留下来了，也写进了描述：单个 `query` 走本地库、没命中**自动联网兜底**；
批量 `queries` **只查本地**（一次查几十个还逐个联网会慢且容易限流，缺哪个再用 `query` 补）。
合并的只是"选哪个工具"，不是"两件事变成一件"。

为什么合：都是"把名字转成 tag"这一个动作，没有"先查一个再查一批"的顺序，
`query` 与 `queries` 天然互斥。拆成两个工具只是让模型多判断一次。

实现上 `lookup-batch.ts` 从"工具"降级成纯函数 `batchLookup(deps, args)`，`lookup.ts` 做分派 ——
两条路径的逻辑仍各自独立、可以单独测。

**这是工具瘦身的最后一块**：方案里的四组（素材库 4→2、工作流查询 2→1、run 参数 9→6、danbooru 2→1）
全部完成，工具从 **16 个降到 12 个**。

`npm test` **536/536**（新增 1 条分派用例：给 `queries` 走批量、两个都不给时报错要同时提两条路径）。


### 改进：`wait` 一参两用，参数表 9 → 6

`comfyui_run` 原来有三个参数管同一件事：`wait`（等不等）、`waitMs`（等多久）、`timeoutMs`
（已废弃，描述里写着"请用 waitMs"却还留着）。模型经常两个都传，或者传 `timeoutMs` 以为在设
等待上限。现在只剩 `wait`：**布尔表示等不等，数字表示"等，但最多等这么久"**（字符串数字也认）。

参数表从 9 个降到 **6 个**：`promptId` / `workflow` / `vars` / `outputPath` / `wait` / `tags`。
顺手删掉 `returnImages`（工具结果本来就不能承载二进制，它只是为兼容旧调用留的空壳）。

**`comfyui_rerun` 与 `comfyui_run_batch` 同步改**：它们各自也有一份 `waitMs` / `timeoutMs`。
只改 run 的话会留下三种等待语义，比不改更乱。提交超时（拉起服务 + 校验 + 入队）收成内部值，
不再暴露成参数 —— 调用方关心的是"等多久出图"，那是 `wait`。

解析规则抽成 `shared/tools/types.ts` 的 `parseWait`，三个工具共用一份。**抽的原因不是"三份重复"，
是三份已经跑偏**：`run_batch` 解析出了数字却没拿它决定同步与否（仍用 `args.wait !== true`），
`wait: 3000` 会立刻返回 —— 参数是摆设。第一版就是这样，审查实测抓出来的。

**这个改动差点假绿**：`additionalProperties: false` 只在宿主侧校验，单元测试直接调 `execute` 时
多余参数会被静默忽略。改完 schema 后测试照样全绿，但十处测试传的 `waitMs` / `timeoutMs` 已经不生效 ——
它们本想验证"等 1 秒超时"，实际按 deps 里的配置值在等（`run_batch` 那条从 0.06 秒变成 30.1 秒）。

现在测试统一改成数值形式的 `wait`，并新增 8 条用例钉住：布尔/数字/字符串数字、`0` 与负数当"不等"、
小于下限抬到 1 秒、`true` 被 30 分钟上限夹住、参数表只剩六个、三个工具的 schema 一致。
变异验证 4/4 打红：`run_batch` 退回旧判据、`parseWait` 忽略数字、`0` 改成同步、`true` 不夹上限。

`npm test` **532/532**。


### 改进：工作流查询 2 → 1，并入体检（`comfyui_workflow`）

`comfyui_workflow_list` + `comfyui_workflow_inspect` → `comfyui_workflow`。

**四档靠参数决定，不靠工具名**：不给 → 列表；给 `workflowId` → IO 面 + 节点清单；
再加 `nodeId` → 单节点完整配置；给 `audit: true` → 全库体检。

为什么合：四档都是**同一个对象上的只读查询**，失败后的下一步也相同（换 id、或去启用/导入）。
原来拆成两个工具，模型得先判断"我现在该调哪个"——那是个假选择。而体检本来会变成第三个工具，
直接挂在 `audit` 上，不占位置。

**体检补的是社区最痛的那件事**：ComfyUI 一更新/一装新节点包，就读不到"哪套模板已经废了"，
要等跑失败了才知道。现在 `audit: true` 一次回答：

- **缺节点** → 必然跑不起来（那套模板就没用了，得装回节点包或换模板）
- **缺模型** → 能提交，但会跑偏或报错（返回里给本机可用的替代模型）
- 其余健康，只给数量

拿不到 `/object_info` 时它明说"**无法体检**"，**绝不假装全部健康** —— 假装健康比不报更危险。

实现分在三个文件（`workflow-list` / `workflow-inspect` / `workflow-audit`），`workflow.ts` 只做分派
与 schema；各自逻辑留在各自文件，可以单独测。

工具数 **14 → 13**。`npm test` **517/517**（新增 4 条体检用例：三档分流、拿不到节点清单、
节点清单为空、全部健康时不制造焦虑）。


### 改进：素材库工具 4 → 2（`comfyui_pose` / `comfyui_costume`）

`comfyui_pose_search` + `comfyui_pose_fetch` → `comfyui_pose`，衣装同理。

**给 `query` 是搜，给 `id` 是取图。** 两个动作在同一个对象上，`query` 与 `id` 天然互斥，失败后的
下一步也是同一句（搜不到就换词、id 找不到就先去搜）—— 拆成两个工具只是让模型多一次无意义的选择。
成功的返回里用 `mode: "search" | "fetch"` 说明走了哪条路（失败时只有 `ok: false` 与 `error`）。

**不做 4 → 1**，四条理由：姿势多一个 `system`（`full` / `sexy` / `bust` / `pair`，衣装没有对应概念，
合并后对衣装是纯噪声）；`category` 是两套完全不同的词表（动作分类 vs 穿搭场景）；返回值一个是多角度、
一个带英文关键词；最根本的是用途不同 —— 姿势控构图（ControlNet 吃线稿），衣装控外观（IPAdapter +
关键词进提示词）。模型选哪个是**意图判断**，不该降级成一个 `kind` 参数。

**搜索不落缩略图。** 原方案想让结果直接带可用图路径，省掉"搜完再取一次"。实测否决：一次搜 10 条
就是 10 次第三方图床请求（`ai-pose-gallery.anhao.app`），那个站点不稳，会把毫秒级的索引查询变成
几秒的等待，而大部分结果模型根本不会用。搜索保持轻，要图就传 `id`。

工具数 **16 → 14**。同步改了 skill 正文、README 中英工具表、`compose` 的报错与参数说明，
并给合并后的工具补了一条互斥测试（给 `id` 时不搜索、不给 `id` 时不碰网络）。

`npm test` **512/512**。

### 修复：`npm test` 因宿主不再提供 React 而中断

`tests/render.mjs` 从 `~/.dsh/profiles/desktop` 解析 `react-dom/server`，而 DSH 升级后那个目录
只剩 `react-icons` —— `npm test` 卡在第五步，后面五百多条用例一条都没跑。

**"从宿主拿"这条路不存在**：宿主的 React 是编译进前端 bundle 的，`app.asar` 里没有任何可 require
的 `react` / `react-dom` 包（实测 0 个文件）。

修法：`react` / `react-dom` 进 `devDependencies`（项目早就声明了对应的 `@types`，缺的只是实现），
`render.mjs` 改成**先查项目自己的 `node_modules`**、再回落宿主 profile；两边都没有时给一句能照做的
报错（`npm i -D react react-dom`），而不是一句 `Cannot find module`。

运行时零依赖这条没破：devDependency 不进产物，`arch.mjs` 的外部包检查仍只看 `src/**` 的 import。

`npm test` **528/528**，exit 0 —— 这条链现在能从第一步跑到最后一步。

### 移除：提示词参考（Danbooru posts + 提示词池）

这块此前已经被"半停用"：UI 子页签从标签库面板摘掉了，但服务端三个文件、四条路由、
客户端组件都还在跑，文件头还写着「已停用，代码完整保留，不要删」。现在彻底移除。

理由不是"维护成本"。真正的理由在停用时还没看清：**提示词格式已经不可通约**。底模太多，
SD1.5 / SDXL / Pony / Illustrious / Flux / Qwen-Image / MOSS 各有各的 tag 语法、权重写法和
质量词约定，从别人的作品里抄来的 tag 串换一个底模，往往不是"差点"而是方向就不对。
提供一堆无法判断适用性的"参考"，比不提供更误导。

删掉：`prompts.ts`（419 行）、`danbooru-posts.ts`（153）、`pool-job.ts`（98）、`PromptRefs.tsx`（164）；
路由 `/tags/refs`、`/tags/refs/image`、`/tags/prompts*`；客户端 `fetchPromptRefs` / `fetchPostRefs` /
建池三函数 / `PostRef` / `PromptHit`；42 条 i18n 词条；11 行参考面板样式；两个测试文件（239 + 55 行）。

六个源文件合计 1128 行；全部改动增 580 / 删 3134（含 `lib/` 重编译产物），**净 -2554**。
`npm test` **511/511**（528 减去删掉的 17 条）。
要找回看 git 历史（0.6.3 及更早）。

## 0.6.3 — 2026-11-09

### 修复：隐私开关切页签就失效（隐藏 NSFW / 只看常规）

反馈：在资产库打开「隐藏 NSFW」，切到别的面板再切回来，开关重置成"显示"——
在有人路过时很容易社死。

根因：三个开关都是组件内的 `useState`，切页签会把面板卸载，state 自然回到初值。
`gallery.hideNsfw`、`poses.onlySafe`、`costumes.onlySafe` 是同一个毛病 —— 后两个一样会把
露骨素材重新摊开。

修法：存到 localStorage（`readPref` / `writePref`，放 `shared/host/prefs.ts`）。
**不用服务端 settings**：这类开关是"这台机器上不长眼"的隐私边界，跨设备同步反而是坏事
（在客厅那台机器上悄悄变回显示）。localStorage 抛错（隐私模式 / 被策略禁用）时读用默认值、
写静默，不影响功能。

放在 `shared/host` 而不是 `client/`：能被 `node --test` 直接单测，不必依赖客户端 bundle
（那个 bundle 的测试入口 `render.mjs` 目前因宿主缺 `react-dom` 跑不了）。

`node --test tests/*.test.mjs` **528/528**（新增 5 条：没存过 / 能读写 / localStorage 抛错 /
没有 window / 值不是 0/1）。`npm test` 这条链本身跑不完 —— `tests/render.mjs` 依赖宿主 profile 的
`react-dom/server`，而 DSH 升级后那个目录只剩 `react-icons`。环境问题，与本节无关。

开关"记住"这件事**没有运行时测试能覆盖**（面板卸载/重挂的过程在 SSR 里不存在），所以退一步守接线：
`arch.mjs` 现在断言三个开关的 `readPref` 与 `writePref` 必须**成对出现**在同一文件里 ——
删掉任一半就红（实测：删掉 `writePref` 那一行，arch 立刻报「变化时必须 writePref」）。

两个不做的事，写在这里免得被当成遗漏：**多标签页不同步**（没监听 `storage` 事件，后写的覆盖先写的，
已挂载的那个标签页内存态不变），以及 `includeBare` / `mergeDuplicates` **故意不持久化** ——
那两个是浏览状态，不是隐私边界，记住反而碍事。

## 0.6.2 — 2026-11-08

### 新功能：把「这套工作台怎么用」注册成 skill

模型经常绕过 `vars`，改为复制或改写工作流 JSON 再用 `workflow.path` 跑。查下来不是它用错 ——
工作流目录 36 个模板全是 API 格式、`workflow_list` 也给了 `inputs`，是**契约在鼓励改文件**：
`comfyui_run` 只说"参数用 vars 传"、没说"改参数别碰文件"，而 `workflow.path` 的说明像在暗示
"你可以自己造一份"。

两层一起修：

- **契约层**：`comfyui_run` 描述补上"改参数一律用 vars，不要为了改参数去复制或改写工作流 JSON"，
  `workflow` 参数改成"优先 `{"id"}`；`path` 只用于目录外的临时文件且必须是 API 格式"；
  `run_batch` 同步；`workflow_edit` 补一句"一次性参数不要用这个"；`rerun` 那句
  "或改 sidecar 里的 workflowId" 改成"不要去改 sidecar —— 它是复现凭据"
- **知识层**：注册 embedded skill `comfyui-workbench`，正文在 `workbench.skill.md`（构建时按文本内联）。
  讲四层分工（模板 / 变量 / 产物 / 素材）、跑图的标准路径、三种常见误用、素材三库怎么拼。
  不是工具手册 —— 参数在各自的 description 里，这里只讲取舍与顺序

审查在这一轮抓到 6 条必修，其中一条会让整个 skill 白做：注册时漏了 `source`，宿主加载时
`validateDefinition` 要求它是字符串 —— 现象是"目录里看得见、一点开就抛"，比不注册更糟。
### 新功能：`comfyui_compose` —— 素材到出图的最后一段

素材库能搜、能取图，但"这套衣服这张姿势该塞进哪个槽、提示词怎么拼"原来全靠模型临场推理，
每次都要重新判断还不稳定。`comfyui_compose` 把这段固化成一次确定性调用：输入素材，
输出一次可以直接交给 `comfyui_run` 的 `call`。

它**不执行** —— 出图仍然只有 `comfyui_run` 一条路，seed 记录、运行记录、产物归处不变。

槽位语义按三级线索推断（实测两个真实工作流得出的）：**label**（作者起过名就有用，如「原图」
「蒙版图」）→ **默认文件名**（`pose_ref_bath2.png`、`inpaint_mask.png`）→ **槽位顺序**。
任何靠顺序猜的地方都会写进 `assumptions`，不许静默；放不下的角色进 `dropped`。

提示词按「衣装英文关键词 → 标签 → 自由描述」拼，大小写不敏感去重，**不自动加质量词**
（那是模板或用户的事）。

素材取用面挂在 `Runtime.materials` 上：姿势库与衣装库两个 entry 各注册自己那一半，
工具侧惰性取 —— 不依赖 entry 的加载顺序，也不让 tools 直接 import 那两个组件。

槽位判据与提示词槽都有回归测试钉住（含两组"变异会红"的用例：把默认文件名那一轮删掉、
把 extraVars 挪到提示词之前，都会立刻打红）。

`npm test` **523/523**（新增 16 条：槽位匹配 6、提示词 3、端到端 7）。

## 0.6.1 — 2026-11-07

### 修复：两个搜索工具在非成人向结果上整次调用失败（#2）

`comfyui_pose_search` 与 `comfyui_costume_search` 的返回值里带着 `adult: undefined`：

```ts
adult: hit.adult || undefined,
```

非成人向时 `false || undefined` 得到 `undefined`。宿主对工具返回值做无损 JSON 校验，
`undefined` 往返后键会消失，于是整次调用被判 `returned invalid output: value is not lossless JSON` ——
一个结果都拿不到。

**影响面**：288 组姿势里 190 组成人向、1407 套衣装里 393 套成人向，所以绝大多数查询都落在这条路径上，
两个工具的模型侧入口基本不可用。

**为什么一直没被发现**：面板走 HTTP 路由，根本不经过工具输出校验，所以界面一切正常；
而我们自己的测试只断言了 `ok === true` 与字段存在，从没做过 `JSON.parse(JSON.stringify(x))` 往返。
这是测试缺口，已补。

修法：这一行直接取布尔值 —— `adult: hit.adult`。问题从来不是"值不是布尔"（`false` 完全可序列化），
而是 `|| undefined` 这个表达式自己造出了 `undefined`；删掉它，bug 就没了。

社区 PR #1（@jimzyx）先定位到这一处并给出了修复方向，其写法是"为真时才带上字段"
（`...(x ? { adult: true } : {})`）。思路采纳，实现改成保留显式 `false`：
模型能明确看到"这套是非成人向"，不必靠"字段缺失"去推断，而两者都不会产生 `undefined`。
回归测试相应断言该字段必须是布尔，而不是断言字段不存在。

**验证**：issue 里给的两条命令（`{query:"坐姿",limit:5}` / `{query:"连衣裙",limit:3}`）
以及 `onlySafe`、默认两条路径，返回值现在都能无损往返。

### 修复：`comfyui_rerun` 的 `seeds` 数组里也可能出现 undefined

同一个根因的另一处，发版审查时扫出来的。工作流没有 `seed` / `noise_seed` 槽位时：

```ts
seeds: submitted.map(item => item.seed),   // → [undefined]
```

数组元素是 `undefined` 一样会被宿主的无损 JSON 校验整次拒掉 —— 而这里的 `undefined`
同样是 `map` 造出来的，不是数据里的。改成 `flatMap`：没有 seed 就不放元素，返回 `[]`。
补了一条"无 seed 槽位的工作流"的测试，变异回 `map` 会红。

### 修复：衣装库「加入对话」点了没反应

现象：衣装库卡片上点「加入对话」，没有任何变化——不报错，附件也没进去。

排查过、都不是原因（记下来免得再猜一遍）：宿主确实支持 webp，白名单在
`dsh-attachment-local` 的 `imageLimits.mediaTypes` = png / jpeg / webp / gif；代理返回的
`Content-Type: image/webp` 也对；宿主的输入框选择器 `data-input-scroll` 还在。

真正的原因：**`findComposerEditor` 只判断元素"存在"，不判断"能不能收"**。
插件是侧栏页签、对话在中间列，两者**一直同时挂载** —— 所以输入框几乎总能在 DOM 里找到，
代码于是从不切页签。而宿主在会话 **settling 期**（`blank` / `loading` / subagent 可用性待定）
用 `visibility:hidden` 把输入框藏起来：visibility 不销毁布局盒，`getClientRects()` 照样返回矩形，
旧判据判它"可见"，paste 就派发进了一个看不见的编辑器 —— 宿主那边 `addFiles` 还没就绪，
直接 return，于是既不报错也没下文。

修法：判据从"有矩形"升级为三条一起查 —— `isConnected`、宿主自己的 `settling` 标记
（`[data-phase="settling"]` / `[data-content-phase="settling"]`）与 `getComputedStyle` 的
`display`/`visibility`、以及非零尺寸矩形。只有全部通过才算"能找到输入框"，否则调用方切页签再等。
挑选逻辑抽成纯函数 `pickComposerEditor`，可见性判据 `isVisibleElement` 单独导出便于覆盖。

测试同时收紧：原来那几条都自己注入可见性回调，判据本身的洞抓不到（审查指出「隐藏的 scoped
照样能过一条弱断言」）；现在直接喂假元素测生产判据，六种情形（正常 / `visibility:hidden` /
settling / `display:none` / 零尺寸 / 脱离文档）。变异验证：退回"只看矩形"的旧判据 → 红在
`visibility:hidden` 那条。

姿势库与资产库走同一个函数，这一修对它们同样生效。

**还有一类静默失败是插件改不了的**：宿主 `intakeFiles` 有五个前置条件，任一不满足就 return
且不提示 —— 会话被锁（`locked`）、机器忙（`machineBusy`，正在 adjudicating / submitting）、
当前是 subagent 且不可续、附件控制器未就绪（`addFiles === undefined`）、文件列表为空。
也就是说「会话正在跑任务」时点「加入对话」会被宿主忽略，这属于宿主行为，写在这里便于自查。

`npm test` **503/503**（`tests/render.mjs` 新增断言覆盖挑选逻辑与生产判据）。

## 0.6.0 — 2026-11-04

本轮主线：**工作台从四块界面长到六块**，并且把「测试全绿、真机不通」这类问题变成结构性检查。

- **两个新的参考库组件**：姿势库（288 组 / 1439 个角度）、衣装库（1407 套，每条带英文关键词）。
  都是"元数据随包、图经服务端代理按需取"，共用一套取图实现（磁盘缓存 / 单飞 / 失败冷却 / 字节头校验）。
- **标签库扩到四类 99372 条**，带语义大类筛选、滚到底自动加载、「更新标签」按钮。
- **工作流面板支持上传 / 粘贴导入**（同名不静默覆盖，旧模板留 `.bak`）。
- **写了三条结构性检查**：写接口必须有走真实入口的用例、页签与组件诊断表必须对齐、
  样式不许写成 TS 字符串。它们各自都当场抓到过真问题。
- **几个只在真机上现形的 bug**：中间产物混进资产库、固定 seed 的图被列表去重吞掉、
  外壳样式在 SSR 里整段丢失（React 19 只接受单个字符串 child）。
- **工具描述补上关键行为**：提交任务会自动拉起 ComfyUI，不需要先手动启动、也不该 kill 它。
- 「提示词参考」子页签**已停用**（代码保留，理由见下），参考面板换成 Danbooru posts 后又整体关掉。

### 修复：固定 seed 跑出来的图被列表去重吞掉

用户报告某个会话里最新跑的两张图没进资产库。

查下来：两张图在磁盘上、在 `assets.jsonl` 索引里（`status: present`）、也在 `runs.json` 的
artifacts 里 —— 但 `/api/items` 的 244 条里没有它们，而同目录更早的一张却在。
`?dedupe=0` 时是 **451 条**、那两张排在最前两位：**去重把它们吃掉了**。

根因：`duplicateKey` 只用 `seed|宽x高|提示词` 做签名。用户这几张的 seed 都是固定值、
尺寸相同、提示词模板相同（只换了服装），于是**不同运行产出的不同图**被判成"同一张图的副本"。
一次固定 seed 的系列跑几乎全被吞掉（451 → 244）。

修法：签名里加 `promptId`（sidecar 的 `comfy.promptId`，那次运行的唯一标识）。
**只有同一次运行的多份副本才合并**；拿不到 `promptId` 就不合并 —— 宁多勿错。

代价要说清：这会让"ComfyUI 自己存一份 + 插件另存一份"那种跨来源副本不再自动合并
（ComfyUI 那份是 PNG 内嵌块，没有 `comfy.promptId`）。资产库里可能看到更多重复条目，
但不会再吞掉真正不同的图 —— 用户报的就是被吞，这个方向的错更贵。

`npm test` **503/503**（新增 7 条：`tests/dedupe.test.mjs`）。

### 修复：中间产物不再混进资产库

用户测动作控制工作流时发现：depth 中间图和成品一起进了资产库。

根因：那个工作流（`moss_dual_pose_api`）有两个 SaveImage ——
node 17 存 `VAEDecode` 的结果（成品），node 18 存 `ImageScaleToTotalPixels` 的结果
（depth）。而 depth 那个节点的输出**同时**喂给 `ControlNet` 和这个 SaveImage。
原来的过滤只排 preview 节点与 `type=temp`，两个都是 `SaveImage` + `type=output`，
于是两个都当产物下载、都进了资产库。

修法：`intermediateSaves(workflow)` —— 一个 SaveImage 的**图片来源如果还被别的计算节点
消费**，它存的就是流程中间结果，标成 `kind='intermediate'`。判据取自数据流，不猜文件名。

审查用本机 40 个工作流模板做了改前/改后差异对比，抓出 3 条必修，都修了：

1. **兜底链缺一档**：只有「正式产物 → 含 temp 的正式产物 → 全都要」三档时，一个"唯一
   保存节点被判成中间产物"的工作流会掉到最后一档，把 `PreviewImage` 的临时预览一起收进来
   （某个模板实测 1 张变 8 张）。补上「仅中间产物」这一档，抽成纯函数 `pickArtifacts` 并
   用四条断言钉住（这一层原来埋在 `collectArtifacts` 里，零覆盖）。
2. **文案把中间产物说成预览图**：跳过计数里混着两种东西，笼统写成"已跳过 N 张预览图"
   是在撒谎。拆成 `skippedPreview` 与 `dropped` 两个数，分两句话说。
3. **误伤是静默的**：两段式放大/精修工作流的"前一段 SaveImage"也会被这个判据排掉
   （本机 `civitai-wai-nsfw-v13` 少了 `223:SaveImage←118`、`civitai_img2img-facedetailer`
   少了 `284:SaveImage←50`），而那张往往正是用户想看的。现在把被跳过的中间产物写进
   `notes`，并给出出路（去 ComfyUI 自己的输出目录取，或加进 `assetRoots`）。

顺带：`PreviewBridge` 不再算保存节点 —— 它是"把预览图传给下游继续算"的中转节点、不落盘。

**只治未来不治过去**：这次改动不影响已经下载到 outputDir 的中间产物，目录里既有的
`*_depth_*.png` 仍在，资产库照旧显示，需要手动删（或删掉重跑）。

`npm test` **496/496**（新增 9 条：`tests/artifact-kind.test.mjs`）。

### 修复：外壳的四份样式在 SSR 里整段丢失（既存缺陷）

`Workbench.tsx` 一直写的是 `<style>{WORKBENCH_CSS}{TAGS_CSS}{POSES_CSS}{COSTUMES_CSS}</style>`
（四个相邻 child）。React 19 的 SSR 对 `<style>` 的 children **只接受单个字符串**：
长度 ≥2 的数组被整段静默丢弃，于是渲染成空的 `<style></style>`。

**根因不是"`<style>` 被当成可提升资源"**（我第一版注释就写错了，被审查实测纠正）：
不带 href/precedence 的写法照样中招，带 href + precedence 的可提升路径也一样丢 —— 是
React 19 在 children 序列化里加了 `Array.isArray(children) ? (length < 2 ? children[0] : null)`
那道长度判断。React 18 没有这个行为（对照实测多 child 完全正常）。

**影响范围要说准**：宿主 Web 前端是 Vite SPA，生产走 CSR，浏览器端从来不受影响
（DOM 追加多个 text node 是合法的）。真正中招的是 `tests/render.mjs` 这条 SSR 链路 ——
而它此前从没断言过这段注入，所以"样式在 SSR 里是空的"这件事两边都没人看。
顺带修掉一个 hydration 隐患：改前 SSR 输出 0 个 text node、客户端 2 个，现在两边一致。

修法：先 `join('\n')` 拼成一个字符串再交给 `<style>`。四份 CSS 都以 `}` + 换行结尾、
以块注释开头，拼起来不会粘连（审查逐份核对过末尾/开头字符与产物边界）。

测试同时收紧：`tests/render.mjs` 改成遍历**所有** `<style>` 断言非空（不止外壳那一处），
正则放宽到 `<style[^>]*>`（免得宿主将来加 nonce 误报）。三组变异都能打红：改回四相邻 child
（外壳空）、只拼三份（缺 `.cct-root`）、把 Gallery 的单 child 改成两个相同 child（第 2 个 style 空）。

### 重构：样式从 TS 字符串搬进独立的 `.css` 文件

用户指出一个长期存在的坏习惯：**我把 CSS 写成 TS 里的模板字符串常量**
（`export const TAGS_CSS = \`...\``），六个文件加起来 43 KB。

后果是实打实的：编辑器里没有语法高亮、没有工具能校验、逻辑文件被样式淹掉，
而"反正构建时会打进 bundle"并不能成为把样式塞进 `.ts` 的理由。

改成：每个组件一份 `styles.css`，构建时按**文本**导入（`esbuild` 的
`loader: { '.css': 'text' }`），运行时照样 `<style>` 注入。
**分离的是源码，不是运行方式** —— 客户端 bundle 是 esbuild 打成的单文件、
经 `__ModuleLoader__` 加载，没有 HTML 入口可以挂 `<link>`，这一点没有变。

- `src/client/styles.css`（外壳，从 `styles-workbench.ts` 迁来）
- 五个面板各一份 `client/styles.css`
- 新增 `src/client/css.d.ts` 声明 `*.css` 的默认导出是字符串
- `tests/classes.mjs` 的样式表清单改成 `.css`，**并补上一直漏掉的终端面板**
  —— 光把它的 `.css` 加进清单不够：前缀表里也得有 `cwt`，否则它既不进 defined 也不进 used，
  检查照样全绿而实际空转（审查抓到的必修，见下）

`tests/arch.mjs` 新增一条检查：任何 `.ts` / `.tsx` 里出现
`const X_CSS = \`` 或 `const CSS = [` 这种写法就报错，并指向该改成 `.css`。
这条检查用临时文件变异验证过 —— 放一个 `src/client/_tmp-check.ts` 进去立刻红。

`npm test` **487/487**；`arch` 145 文件（少了 6 个样式 .ts）、10 条 entry、6 个页签对齐；
`classes` **180** 个类名（含终端面板；补前缀表前后分别是 168 / 180，后者才是真校验）。构建产物里六个前缀的类名都还在。

### 新功能：衣装库（第九个组件）

工作台多一个「衣装库」页签：**1407 套现实风格衣装**（图里没有人物），八类
（春 215 / 夏 254 / 秋 244 / 冬 253 / 内衣・睡衣 199 / 性感 140 / 泳装 54 / 派对 48），
按中文描述、标签、英文关键词或编号搜，取图存进 uploads 当工作流参考图。
模型侧多两个工具：`comfyui_costume_search`、`comfyui_costume_fetch`。

**接入方式与姿势库完全一样**（元数据随包、图经服务端代理按需取），而且**共用同一个取图实现**：
`createImageCache` 只多了一个 `pathPattern` 参数。缓存、单飞、失败冷却、字节头校验一行没复制 ——
那些逻辑抄第二遍必然漂移。两处差别只有三样：多一层 `costume/` 目录、id 带连字符、格式是 webp。

**它比姿势库多一样东西：英文关键词。** 每套都有
`ivory frill knit denim mini skirt coat socks white sneakers` 这样的英文串，覆盖率 100%，
卡片上一行、一键复制，直接能拼进提示词 —— 这正好补上"姿势库只有中文名、没有提示词"的遗憾
（那一轮实测过：拿 Danbooru 中文名反查姿势名几乎全打空，两套词汇体系不一样；服装的关键词是上游直接给的，不用猜）。

**默认全给 1407 套**，不做内容筛选；393 套标了成人向（内衣/泳装/性感三类）只加徽标，
勾「只看常规」才收窄到 1014 —— 与姿势库同一套规矩。

数据来自 ギア 的 COSTUME-DB-01，中文名与关键词来自 Anhao 的中文版镜像；
`data/costumes/catalog.json` 只含编号/描述/标签/关键词/图地址，**一张图都不在仓库里**，
授权与限制见 `data/costumes/NOTICE.md`（允许用作创作参考，禁止再分发图像数据本身）。

接线：第十条 entry `comfyui-workbench:costumes`（`panel.costumes` 可单独关）、第六个页签、
`applyAll` 里调了 `applyCostumes`、`/costumes/` 加进 router 的 `selfManaged` 前缀。

**上一轮新加的结构性检查当场抓住了我这次的漏项**：`componentStateOf` 里忘了补
`panel.costumes`，`arch.mjs` 直接报「这些页签在 Workbench 的 TABS 里，但 componentStateOf
没有对应的键」—— 同一个坑第四次踩，这次是被检查拦住而不是被用户发现。

`npm test` **487/487**（新增 10 条：`tests/costumes.test.mjs` 9 条 + `api/costumes` 真实入口 1 条）；
`arch.mjs` 150 文件 / 28 单元 / **10 条 entry / 6 个页签与诊断表对齐**。

### 新功能：姿势库（第八个组件）

工作台多一个「姿势库」页签：**288 组人体姿势、1439 个角度**的线稿，按中文名 / 编号 / 分类搜，
按体系（全身标准 365、全身性感 399、上半身 400、双人缠绵 275）与 26 个动作分类筛，
每张卡片可切五个角度（正面 / 斜侧 / 侧面 / 俯视 / 仰视），「取原图」把线稿存进 uploads
当工作流的输入图。模型侧多两个工具：`comfyui_pose_search`、`comfyui_pose_fetch`。

**数据从哪来**：上游是 [anhao/ai-pose-gallery-zh](https://github.com/anhao/ai-pose-gallery-zh)
（中文版图库），原始素材出自 ギア（[@giaaibusi](https://x.com/giaaibusi)）的
[AI Pose Gallery](https://ai-pose-gallery.pages.dev/)。上游 `data/pose-zh.json` 是 1439 条
「姿势 × 角度」的扁平淡，`scripts/import-poses.mjs` 按（体系 + 编号）聚成 288 组，
并校验四件事：条数、体系前缀与中文体系名对得上、图地址落在白名单内、同组内名称与分类一致。
任一条不符就报错退出。

**图不随包**。仓库里只有名称、分类与图地址（`data/poses/catalog.json`，253 KB）；
线稿在运行时经服务端代理读取并落盘缓存。版权与「不得用于商业用途」的限制写在
`data/poses/NOTICE.md`，本项目的 MIT 不覆盖任何一张线稿。

**默认全给，不做内容筛选**：288 组都在列表里。190 组被标了成人向（整个性感系 / 双人体系，
加「挤胸・强调事业线系」「性感・大胆系」两个分类），但标记只用于显示与可选收窄 ——
面板有个默认不勾的「只看常规」，工具侧是对应的 `onlySafe`。

**这里原本的写法是反的**：第一版把成人向默认藏起来、勾选才全开，理由是"比例不小、弄错就是事故"。
那是插件替使用者做了内容决定，属于越界；判定信息留着当标注就够了，看不看是使用者自己的事。
改成默认全给之后，那道开关的方向也从「要不要放开」变成「要不要收窄」。

**比"照搬上游做法"多做的四件事**：

1. **磁盘缓存**：上游只有 80 条内存缓存，进程一重启全丢，每次首屏重新下载几十张缩略图。
   这里落盘（上限 256 MB，按最久未用清理），重启后命中磁盘。
2. **单飞**：列表 + 详情 + 预览会对同一个视角并发发请求，不合并就是 N 次上游请求。
3. **失败冷却**：上游连挂三次就短路 30 秒，面板显示「线稿暂时取不到」，
   而不是让一屏 40 个缩略图各自挂 20 秒超时。成功一次即清零，偶发失败不会攒成"远端挂了"。
4. **校验到字节头**：只认 PNG / JPEG 的 magic bytes —— 扩展名是别人给的，不该当类型保证。

**这里刻意不做倒排索引**：288 组线性扫是微秒级。标签库 99372 条才值得建 2-gram，
给 288 条建索引是负优化 —— 「上游做过所以照做」不如先量一下规模。

**不抄上游的「工作室」定位**：那个插件自带 provider、自己调生图 API；工作台已经有
`comfyui_run`，出图只能有一条路，否则 seed、运行记录、通知会各分叉一份。这个组件只负责
把线稿变成工作流能吃的输入图。

`/poses/fetch` 是写接口（会在 uploads 落文件），走 `router.ts` 的 `selfManaged` 前缀，
`tests/api.test.mjs` 里那条用例同时断言「POST 返 404 而不是 405」与「GET 返 405」——
两个码合起来才说明分派层真的按方法在分流。

`npm test` **475/475**（新增 22 条：`tests/poses.test.mjs` 21 条 + `api/poses` 真实入口 1 条）；
`arch.mjs` 142 文件 / 26 单元 / **9 条 entry**；写接口真实入口覆盖 9/14。

审查抓到 4 条必修，都修了并补了会红的测试：

1. **代理没关重定向**，上游一个 302 就能把它变成任意 http(s) 出口（实测能打到 `127.0.0.1`），
   还会 https→http 降级。改 `redirect: 'error'`，测试断言这个参数确实传了
   （变异：删掉它，测试红）。
2. **8 MB 上界不限制内存**：原来先 `arrayBuffer()` 再判大小，9 MB 响应会被完整读进内存。
   改成先看声明长度、再流式读并逐块累计，超限即取消。测试用「谎报 content-length」的响应打。
3. **冷却检查排在磁盘命中之前**：上游一挂，连已经下过的图都打不开，缓存等于白建。
   调换顺序，测试在**同一实例**里先落盘、挤出内存、打出冷却，再取那张图必须 `from: 'disk'`
   （变异：换回旧顺序，测试红）。
4. **导入脚本有静默通**：上游缺「姿势名称/分类」时 `undefined === undefined` 通过"组内一致"
   校验，脚本 exit 0 写出一份没有 name 的目录，`categories` 里还多出一个字面 `"undefined"` 键。
   改成必填字段先校验（实测：造一份缺字段的上游数据，脚本 exit 1 且不动现有 catalog）。

顺带修掉的建议项：`materialize` 补 temp+rename；`routes.ts` 头注释「四条」改五条（漏了 `/poses/cache`）。
原本那个 `posesIncludeAdult` 配置项与 `PosesRoutesDeps.includeAdult` 死参数一并删掉了 ——
默认全给之后它们就没有存在意义。

`arch-write-routes.mjs` 的自报数字此前虚高一条：`selfManaged` 的 `sub === '/'` 被正则误收成写接口，
而 `api${'/'}` = `api/` 在任何 api 测试里都是子串，「已覆盖」判定当场成立。剔掉根路径后分母回到 14，
覆盖率 9/14 才是真的。

### 已停用：提示词参考（代码保留）

标签库面板的「提示词参考」子页签**已从 UI 摘掉**。理由：它把工具拖进了第二个数据源的维护——外部站点的可用性、拒绝浏览器 UA 的防盗链（为此还加了一层图片代理）、限流与重试、以及「落盘 vs 只接入」的取舍。而它只是「看别人怎么写 tag」的辅助功能，收益撑不起这份重量。

**代码完整保留，不要删。** 四个文件的文件头都写了停用原因与恢复方法：

| 文件 | 是什么 |
| --- | --- |
| `panel-tags/client/PromptRefs.tsx` | 子面板 UI（Danbooru posts 版，带图） |
| `panel-tags/server/danbooru-posts.ts` | 数据源：图 + tag 串，零落盘 + 图片代理 |
| `panel-tags/server/prompts.ts` | 旧数据源：HF 247 万条纯文本 + 本地池 |
| `panel-tags/server/pool-job.ts` | 「建提示词池」的后台任务 |

路由 `/tags/refs`、`/tags/refs/image`、`/tags/prompts*` 全部保留。要恢复只需在 `TagsPanel` 里把子页签加回来（看 git 历史）。

停用前那一轮的实测结论也留在这里，免得以后重走：

- **CDN 拒绝浏览器 UA**：`Mozilla/5.0 …` → 403，`dsh-comfyui-workbench` / curl → 200。所以图片必须走后端代理，前端直连一定加载不出来。
- **`order:random` 在匿名请求下让 Danbooru 返回 500**，随机只能靠翻页。
- **限流不是主要问题**：12 次连打（200ms 间隔）0 次 429，失败的 3 次是网络抖动（响应 400ms–4.2s）。
- **HF 那套的成本**：2 万条要 200 次请求、一路 429；`DiffusionDB` 有图但是 zip 分片，单片 **527 MB**。

### 变更：参考面板换成 Danbooru 的 posts（带图、不落盘）

用户要「每条参考带参考图」，并建议「数据量过大就只接入、不落盘」。原方案是
HuggingFace 的 247 万条**纯文本** + 本地池（2 万条落盘），配不了图。

新数据源是 `posts.json`：**一次请求同时给图（`preview_file_url` / `large_file_url`）、
tag 串（已按 general/character/copyright/artist 分好类）和服务端搜索**，零落盘 ——
前端直接 `<img src>` 加载。而且与本插件的标签库同源：参考出来的就是"用 danbooru tag
写的提示词"，和 `comfyui_run` 的 `vars.prompt` 是同一种语言。

顺带消失了三个问题：没有池子就没有"建池"、没有 429 队列、也没有"建池失败把原池写坏"。

**踩到两个坑**：`order:random` 在匿名请求下让 Danbooru 直接返回 **500**（改成随机翻页，
上限取匿名的 1000 页而不是 100 —— 否则只覆盖"最新 1200 条"约等于最近几小时）；
多词查询偶尔超时（retry 一次，超时给到 15s 而不是 tag 查询的 8s）。

**不走 `tool-danbooru` 的 `fetchJson`**：它带 SFW 镜像（`safebooru`）与模块级的
"上次成功镜像"状态 —— `rating=all` 降级后一条 NSFW 都没有（用户以为搜不到），
更糟的是一次 posts 超时会把后续 `tags.json` / `wiki` 查询也钉在镜像上，标签库静默变子集。
posts 自己发请求：单主站、单独超时、单独重试。

默认只看 `rating:general`（面板是学"tag 怎么写"，不是图库）；工具条右侧加了「全分级」
开关，勾上之后 g/s/q/e 全来。

### 保留而非删除

旧的 HF 那套（`prompts.ts` 的本地池、`pool-job.ts`、`GET /tags/prompts`、
`POST /tags/prompts/sync`、`client/api.ts` 的 `PromptHit`/`PoolSyncState` 系列、
`refsPool*` 文案键、`tests/prompts.test.mjs`）**按用户决定保留**，不做删除：
等后续调查或想到更轻的方案再说。四个核心文件（`PromptRefs.tsx`、
`danbooru-posts.ts`、`prompts.ts`、`pool-job.ts`）的文件头都加了停用告示，
`docs/design.md` 的 §7.0 也登记了。`refsPool*` 那批文案键随 UI 一起闲置，
但恢复子页签时还要用，同样留着。

### 功能优化

- **`/queue` 加了 single-flight**：批量提交时最多 20 条任务各自轮询队列，原先只有 1 秒缓存——而缓存要等结果回来才写，冷启动那一瞬间 20 个调用看到的是同一个空缓存，于是同时打出 20 个请求。现在共享同一个 in-flight promise，`tests/queue-singleflight.test.mjs` 用 30ms 延迟制造重叠，断言 20 并发只打 1 次（去掉 single-flight 会变成 20，测试会红）。

  顺带发现：`fetchQueue` 对所有失败（500 / 网络炸 / 坏 body）都降级成空队列、**从不 reject**，所以 `queue()` 里的 `.catch` 是纯防御代码。测试相应改成测真实行为（降级不抛、且过缓存窗口后会重新请求，不会把"空队列"永久钉住）。

- **两份 `toListItem` 各自改名**：面板侧叫 `toPanelItem`、模型侧叫 `toModelItem`。它们**没有合并**——字段已真实分叉（面板要 `imageSlots`/`basicCount`，模型要 `inputs` 明细），强行统一会造出一个谁都不满意的胖形状。改由 `tests/workflow-list-shape.test.mjs` 钉住：共同字段（`workflowId`/`title`/`description`/`undescribed`/`enabled`）必须逐字段相同，各自独有字段必须在，`outputs`/`nodes` 必须一致，以及**同名不同义的 `inputKinds`**（模型侧过滤掉 number/boolean/enum，面板侧全留）的差异要显式成立。

- **`docs/design.md` 三处漂移订正**：`/runs` 标注未实现；`/run/:id` 改成实际的 `/run-status?promptId=`；「改完不知道改了什么」那行按真实行为重写——改**备注**会写 `.meta.json` 的 `updatedBy`，但改**参数并 `persist: true`** 走 `writeWorkflow`、不碰 meta，溯源只存在于当次工具返回值里，事后翻不出来。

### 功能优化（续）

- **`new RunRegistry(outputDir)` 的接线守护补上了**。这条之前是半开的：`GET /run-status` 那条用例只能守"完全没接线"（`runs` 为 undefined 时 `runs.get()` 会抛、返回 500），守不住"写成 `new RunRegistry()` 漏传目录"——那种情况 registry 纯内存、`get()` 照样返回 `undefined`、接口照样 200 `found:false`，测试依然绿。

  修法是把装配入口打开：`applyAll` 现在**返回 runtime**（原来返回 void），测试从它拿到 `runs`、`submit` 一条、再断言 `outputDir/runs.json` 里真有这条记录。**变异验证**：把 `new RunRegistry(outputDir)` 改成 `new RunRegistry()`，这条立刻红；还原后全绿。

### 新功能

- **标签面板多一个「参考」子页签 —— 提示词参考**：从 HuggingFace 的 `FredZhang7/stable-diffusion-prompts-2.47M`（247 万条真实用户 prompt）里翻灵感。

  两个模式：**随机**走 HF 的任意 offset 抽样，不依赖任何本地缓存，第一次打开就能用；**搜索**在本地池里按关键词过滤（池子默认 **2 万条**，建池约一分钟，串行 200 次请求——`rows` 接口一次只给 100 条）。搜索是多词 AND + 简单的词边界加分，**不做语义搜索**：那需要向量化，与"翻素材"的定位不相称。

  池子不用 `TagIndex`：prompt 平均 150 字符，2 万条会产生约 300 万个 2-gram 条目，内存代价远高于线性扫 2 万条（20ms 级）。倒排索引在短 tag 上是好交易，在长文本上不是。

  新路由 `GET /tags/prompts?mode=random|search` 与 `POST /tags/prompts/sync`（建池，异步 + 单例，与「更新标签」同构）。字段读的是 `row.text` 而不是 `row.prompt` —— HF 的 features 里那条叫 `text`。

  顺带把 router 的 `selfManaged` 从逐条列举改成 **前缀** `sub.startsWith('/tags/')`：子路径以后还会加，列举就会漏，而漏的后果是"单测全绿、真机 405"（同一个坑已经踩了四次）。

- **标签面板可以手动更新数据**：面板右上角一个「更新标签」按钮，点一下重新拉 4 个上游 CSV（约 9 MB）与 91 个 wiki 分组页，全程两分半，按钮旁边实时显示「下载 general.csv（2/4）」这类阶段进度，跑完自动刷新统计与列表。

  两分多钟的活不能同步等在一个 HTTP 请求里，所以拆成 `POST /tags/sync`（立即返回）与 `GET /tags/sync`（轮进度）。**单例**——正在跑时重复点击返回同一个任务，不会起第二个去踩同一批文件。失败时如实报错（哪个 CSV、HTTP 几），不假装成功。写的是插件数据目录，不碰随包数据。

- **标签库面板**：工作台多一个「标签库」页签 —— 搜索框 + 大类快捷筛选 + 一键复制 tag。搜的是四类共 **99372 条**（角色 / 画师 / 作品 / 通用），一个输入框同时匹配 tag、中文名、别名；每行显示 tag、中文名、类别、大类、热度与最多三个别名。首屏约 550ms（读 129ms + 建索引 420ms），之后查询 1–3ms。

  大类筛选旁边**直接标着实到条数**（「服装 1413」），因为分类只覆盖通用标签的 26.9% —— 查不到时用户能看出是"分类没覆盖"而不是"功能坏了"。实现上新开一条只读路由 `GET /tags` 与 `GET /tags/stats`，走与工具同一份数据与索引（`createTagsIndex` 懒加载、`invalidate()` 重建），区别只是工具要 tag、面板要 tag + 中文名 + 热度。

  新增第八条 entry `comfyui-workbench:tags`（`panel.tags` 可单独关）。`tests/arch.mjs` 的 entry 清单原先硬编码了 5 条、连 `danbooru` 都没查，这轮补成 6 条并让计数动态。

- **工作流面板可以上传 / 粘贴导入了**：`POST /workflows/import`，body `{ name?, workflow, overwrite? }`。面板右上角一个导入按钮，展开后可以粘贴 ComfyUI 导出的 API 格式 JSON，也可以选文件（内容先填进粘贴框，让你看一眼再提交）。之前只有 `node scripts/import.mjs <文件>`。

  三个细节值得说：**同名不静默覆盖** —— 已存在时返回 409 `already-exists`，面板弹确认，确认后才带 `overwrite: true` 重发，并把旧模板备份成 `<id>.json.bak`；覆盖只换模板，`.meta.json` 与 `.schema.json` 保留。**不填名字时用时间戳生成 id**（`workflow-<base36>`），所以连续两次空名导入不会互相踩。**`/workflows/import` 必须注册在路由的 `exact` 表**，否则会被前缀路由当成 id=`import` 的工作流去读详情（返回 `no-workflow` 而不是导入结果）。

  `sanitizeId` 顺带修了一处：截断从 UTF-16 码元改按**码位**，否则名字里带星平面字符时可能切出孤代理，那个 id 回前端再 `encodeURIComponent` 会抛 `URIError`。

### 功能优化

- **200 响应里的 `node_errors` 不再被丢掉**：`POST /prompt` 有两条拒绝路径 —— 400（整份提交被拒，早就转成 `submitRejected`）和 **200 + `node_errors`**（提交被接受、会执行，但某些输出链的参数非法，那条链不产出文件）。后者以前被整份扔了，只能等十几秒后从「没有产物」倒推原因。

  现在 `queuePrompt` 返回 `{ promptId, warnings }`，`warnings` 里直接写清「节点 6（KSampler，参数 sampler_name）：Value not in list，收到 euler_ancestral_x。这条输出链不会产出文件。」，并进到 `notes` 里回给调用方。这是 0.5.0 那个 `no_output` 文案缺陷留下的尾巴 —— 当时只能事后猜原因，现在提交当场就能说。

  几条细节：多条警告会加一行「提交已被接受，其余输出链照常执行」的汇总头并**截断到 3 条**（10 个非法节点会拼成近千字单行，把产物路径淹掉）；`received_value` 不论类型都要说出来（`true`、`[3,1]`、`null`、空字符串以前会被静默丢掉）；**pending 出口也带 warnings** —— 「参数被判非法 → 那条链不产出」的典型后果就是等到超时，那是最需要这句话的时刻。

  `ComfyClient.queuePrompt` 的返回形状从 `string` 变成 `{ promptId, warnings }`，是破坏性变更。

### 功能扩充

- **通用标签有了语义分类**：Danbooru 的 tag 分组（`tag_groups` 是一篇 wiki，不是 API）抓下来——**91 个组、15064 个 tag、其中 1478 个跨组**——再归并成八个大类：动作 / 服装 / 外貌 / 构图 / 物件 / 主题 / 性相关 / 其它。`danbooru_lookup` 新增 `category` 参数，可以「只在服装里找 skirt」这种筛法。

  覆盖率是硬约束，说清楚：这 91 组（**15064 个 tag**）对 `general` 的 30693 条只直接命中 **26.9%**（8261 条），其余落「其它」。wiki 是人工精选——`Hair styles` 205 个链接里连 `ponytail`、`braid` 都没有。所以分类是**增强维度**：搜索仍是主路径，筛不到时工具会明说「是筛掉的，去掉 category 再查」，而不是伪装成「没找到」或跑去问在线（在线结果没有分类信息）。

  新增 `scripts/sync-tag-groups.mjs`（92 次请求、约 2.5 分钟，幂等）；`data/danbooru/groups.jsonl` 与 `category-map.json` 随包。全部抓失败时保留旧快照——半份分类比过期分类更危险。

- **标签库从 2 类扩到 4 类**：新增 `general`（**30693 条**，动作 / 服装 / 外貌 / 构图这些既不是角色也不是画师的标签）与 `copyright`（**8414 条**，作品名，`touhou` → 东方Project）。上游 `danbooru-tags-data-zh` 一直有这两个 CSV，只是导入脚本只映射了 `character` / `artist`。四类合计 **99372 条**，`general` 98.9% 有中文名（`long_hair` → 长发、`1girl` → 一个女孩）。

  实测成本（四类一起建 2-gram 倒排索引）：读取+解析 131ms、建索引 396ms、常驻约 **177 MB**、单次查询 **约 1ms**（线性扫描 57ms，快 54 倍）。这个 177 MB 是「以后还能不能再扩」的硬边界 —— 在加两万条 prompt 之前得先看内存。

### 功能优化

- **CSV 导入逻辑从脚本提到 `src/`**：`parseCsvLine` / `rowToRecord` / `importUpstream` 现在在 `components/tool-danbooru/server/upstream.ts`，`scripts/import-danbooru-zh.mjs` 瘦成参数解析。原因是面板上的「更新标签」按钮要走同一条路 —— 不提前抽出来，必然出现两份实现（本仓库在「同一概念两份实现」上栽过不止一次）。

  顺带把 `TagRecord.kind` 从 `'character' | 'artist'` 扩成 `TagKind` 四值；文件名改用**显式映射表**而不是 `${kind}s.jsonl`，否则 `general` 会变成 `generals`，而 `characters` / `artists` 已经是复数形式并随包分发，不能为了整齐去改名。`note` 字段也正式进了类型 —— 现有数据里本来就有，之前靠类型松弛混过去。

  随包数据只**新增** `general.jsonl` 与 `copyrights.jsonl`，原有 `characters.jsonl` / `artists.jsonl` 的 md5 一字未变（`ebc02196…` / `453ee1e1…`）。

## 0.5.1

### 修复

- **「作为输入图」不再沿用原 seed**：这条链路是位级确定的（实测三次，清缓存重算也逐字节相同），所以「换了参考图 + 沿用原 seed」等于每次点都得到一模一样的一张 —— 按钮看起来像没反应。现在 `POST /rerun` 带 `asInput: true` 时会换一个新的随机 seed，并在响应里把实际用的 `seed` 回给调用方；普通重跑（不传 `asInput`）仍然保留原 seed（那才是「完全复现」）。

  seed 槽位名不硬编码，按 `/^(noise_)?seed$/i` 从 IO 面找（与 `comfyui_rerun` 同一条规则）；工作流没有 seed 槽位就不动，也不报错。

  **注意两个入口的省略语义是相反的**，别混：`POST /rerun` 的 `asInput` 场景省略 `seed` 就是**随机**（换图要出新东西）；`comfyui_rerun` 工具省略 `seed` 是**沿用原值递增**（那是"做变体"的入口）。想用固定 seed 复现某一张，`asInput` 请求里带 `seed` 即可，数字字符串也认（模型常把数字包成字符串，与工具侧一致）。

### 新增

- **`POST /rerun` 新增可选入参 `seed` 与响应字段 `seed`**：显式指定就用它（数字或数字字符串），省略则随机；响应里回传本次实际使用的值，方便之后照着复现。

## 0.5.0

### 新增

- **面板上能直接开关「精确进度」**：`progressStream` 原来只能改 profile 的 `cordis.patch.yml` 或设环境变量，改完还得重启 DSH。现在「工作流管理」面板里有一个开关，写的是插件数据目录的 `settings.json`（`~/.dsh-comfyui-workbench/settings.json`），**下一次提交就生效**。

  优先级是「面板开关 > 配置 / 环境变量 > 内置默认」：配置文件仍然是"默认值"，用户点了开关就以开关为准；POST 传 `null` 能清掉覆盖、退回配置。`/config` 的响应里带 `toggles.progressStreamSource`（`toggle` / `config`），面板据此标一句"当前值来自配置文件"。

  两个实现要点：`/config` 加进了 dispatch 的 `selfManaged` —— 它是「GET 读配置 / POST 写开关」的同一路径，塞进 `WRITABLE` 会把 GET 也一起拦成 405（`/terminal` 与 `/rerun` 都踩过这个坑），同时 handler 自己挡掉 PUT/DELETE，别让它们落到"当 GET 处理"上返回 200；开关**故意不缓存** —— `toggles.ts` 会被两条 entry 各内联一份（`/config` 在 `lib/index.js`、`/run` 在 `lib/entries/workflow.js`），模块级缓存跨 bundle 不共享，面板写入只会失效自己那份，于是「面板显示已开、下一次运行却没有进度」。文件只有几十字节，`/run` 本来就在读工作流文件，直接读盘最省心。这一点是本仓第三次撞「模块级状态跨 bundle 分裂」，`RunRegistry` 与 `collecting` 都栽过。

- **`comfyui_runs`：查任务运行状态**（第 10 个工具）。补的是「提交之后那几分钟」的空白 —— 出图实测中位 115 秒、最长 336 秒，这段时间里模型不知道在跑、排队第几、卡住了还是死了，只有完成时的一条通知。

  运行表挂在 runtime 上（不是模块级：多个 entry 各一份 bundle，模块级会分裂），落盘 `<会话>/comfyui_output/runs.json`，最多 200 条。**重启后原来 queued/running 的标成 `unknown` + `stale`** —— 那些任务在 ComfyUI 侧可能早完成了，但我们已经无从得知，留在 `running` 会让人一直等一个永不变化的状态。

  排序用单调递增的 `seq` 而不是时间戳：批量提交的几条会挤在同一毫秒，"最近的在最前"靠时间戳会失效。

### 修复

- **`wait: true` 与「无 agent」的提交路径不收敛终态**：watcher 本来是唯一的状态更新来源，而它只在「异步 + 有会话」时挂。那两条路径的记录会永久停在 `queued`，`comfyui_runs` 对早就出完的图一直答"还在跑"，`activeCount` 虚高，僵尸记录还会挤占上限、把真正在跑的那条挤掉。补了 `sweepRun()`：自查 `checkRun` 收敛到 done / 超时 unknown / 异常 failed，不投递消息只更新注册表。
- **`sweepRun` 缺守卫会误标**：history 比轮询慢时同一 promptId 被并发处理，序列可能变成 `done → failed`（图已落盘却记成失败）；一次瞬时的 `ECONNREFUSED` 也会永久判死。加了 `inflight`/`settled`，并把 catch 分级 —— `execution_failed` 立即判失败，网络类错误累计 6 次才判。
- **`trim()` 会删掉正在跑的记录**：原来只按 seq 淘汰，200 条都在跑时新提交一条会删掉最老的 `running`，面板上那条正在跑的任务凭空消失。改成终态优先。
- **`sweepRun` 的日志会崩宿主**：catch 里 `logger.warn` 没包 try，它自己抛错就逃逸成 unhandledRejection（Node 默认结束进程）。与 `deliver()` 同一个理由，补上。
- **`no_output` 的文案把 validate 失败说成"末端缺输出节点"**：真机上给一个工作流传 `sampler_name: 'no_such_sampler_xyz'`，ComfyUI 的 validate 只拒掉那一条输出链、别的链照常跑完 —— `/history` 里仍是 `status_str: success` + `completed: true`，`outputs` 有内容（文本节点）但没有一个 `filename`。插件据此落 `no_output`，文案却让人"检查末端是否有 SaveImage / PreviewImage 节点"；而那个工作流有 SaveImage，真实原因是参数名拼错，`failure-kind.ts` 里 `bad_param` 的判据（含 `value not in list`）在这条路径上根本不可达。

  对照 ComfyUI 源码（`execution.py:1187-1194`、`:1232-1300`、`server.py:1234-1238`）重写成两种**成立**的成因：① 后端没回传任何带 `filename` 的产物引用（末端只连纯文本/纯数据节点最常见，自定义节点不回报 filename 也落这里）；② 原本写文件的那条链被 validate 拒、**且**剩下能跑完的链都不写文件（只有那条链被拒、别的链仍在写文件时产物照样有，走不到这里）。同时写明不能再说"缺输出节点"：一个 `OUTPUT_NODE` 都没有的模板在提交阶段就被 `prompt_no_outputs` 拒，全部链被拒则回 400 `prompt_outputs_failed_validation` —— 两条都走 `submit_rejected`，到不了 `no_output`。

  同源的另一处 `submitRejected`：原来一律说"检查被点名的节点参数"，而 `prompt_no_outputs` 的 body 里 `node_errors` 是**空对象**（`execution.py:1188-1194` 的 error 不带节点信息，`server.py:1238` 原样回传），那句话点不到任何东西。现在按 `body.error.type` 分三支：`prompt_no_outputs` 指向"没有输出节点"、`prompt_outputs_failed_validation` 指向"所有链参数都被判非法"，其余保持原文案（反代把 `error` 压成字符串时安全退回）。

  顺带删掉 `noOutput()` 的 `hintTerminal` 参数：全仓唯一调用点硬编码 `true`，false 那条措辞永远不会显示给任何人。`infer.ts` 的 notes（改成留退路的写法：插件按类名推断，自定义输出节点可能被漏判）、`failure-kind.ts` 关于 `bad_param` 的注释、`docs/design.md` 的三处同族措辞（错误表 `no_output` 与 `submit_rejected`、§7 边界表、B14 验收项）一并订正。

  **仍然缺的一环**：`POST /prompt` 的 200 响应里本来就带 `node_errors`（`server.py:1234`，部分链失败时也会返回），而 `client.ts` 只取 `prompt_id` 把它扔了。收下它就能在提交当场说出"节点 6 的 sampler_name 不在候选里"，不必等几秒后从"没有产物"倒推。

- **`sweepRun` 从不查 `/queue`，面板提交的记录没有 `running` 态与 `queuePosition`**：`watchRun`（工具提交、有会话通道）每 tick 先查队列写状态，`sweepRun`（面板 `/run`，以及无会话通道时的 `comfyui_run` / `comfyui_run_batch` / `comfyui_rerun`）完全没有这一段 —— 真机实测一次 11 秒的运行从头到尾只有 `queued → done`。面板上看不出「正在跑」和「排队中」的区别，而 `comfyui_runs` 的描述写着「queued 是排队中的（带 queuePosition）」，对面板提交的记录不成立。

  修法是把那段抽成 `syncQueueState(client, promptId, registry)` 给两个轮询者共用；两处 `registry` 的内联类型合并成 `QueueRegistry`（不 import `RunRegistry` —— `shared/run` 与 `shared/tools` 互不允许依赖，`tests/arch.mjs` 双向检查）。

  真机复验：`queued` → **`running`（`queuePosition=0`、`startedAt` 有值）** → `done`。

  两个已知边界（未修，都不改变终态）：`client.ts` 的 `queue()` 没有 single-flight，缓存是在 `await fetch` **之后**才赋值，批量 20 条同时进入首个 tick 时最多 20 路并发穿透（上界；实际因逐条 `await submitWorkflow` 后才挂 sweep，挂载时刻天然错开。稳态仍是 1 次/秒 —— 缓存是 client 实例级）；`syncQueueState` 放在 `checkRun` 之前，而 `queue` 的请求超时默认 120 秒（`COMFYUI_TIMEOUT_MS` 可配，最大 1 小时），ComfyUI 卡死时完成发现可能被推迟该次超时的时长。

- **`/run` 与 `/rerun` 的 `timeoutMs` 是死参数**：接口认真校验 1s~1h、`submitAndTrack` 认真往下传，而 `submitWorkflow` **一次都没读过 `RunOptions.timeoutMs`** —— 声明了、校验了、然后被丢掉。现在它只做一件事：**放宽**后台盯守时长（`maxWaitMs = max(30min, timeoutMs)`，见 `sweepBudgetOf`），并把实际生效的预算写进返回的 `notes`。传 60000 会被抬到 30 分钟（出图实测中位 115 秒、最长 336 秒，按 120s/300s 收紧会把真在跑的任务标 `unknown`），传 1 小时照用。

  这条接线原先不可测：纯函数用例删掉调用照样全绿。现在 `note` 读的就是传给 `sweepRun` 的**同一个对象**，摘掉 `maxWaitMs` 字段 note 会变 0 分钟，route 级用例立刻变红。

- **`resumeRun` 与 `sweepRun` 会把同一产物收两份**：面板按 promptId 轮询与后台兜底会同时（或先后）处理同一个 promptId。`targetFor` 用 `fs.existsSync` 判冲突 —— 都判"没冲突"就写同名（内容相同、无害），后一个判"有冲突"就落一份带时间戳前缀的副本，用户看到两张一样的图。

  更常见的是**顺序**的第二次：`forgetRun` 已把上下文清掉，跨 bundle 时 `recallRun` 恒空，那份副本的 sidecar 里 `workflowId` 会是 `"unknown"` —— 面板上点"作为输入出图"直接报 `no-workflow`，成为死链资产。

  判据因此落在**磁盘**上（比对 sidecar 里的 `comfy.promptId`），而不是模块级 Map：本仓库每条组件 entry 都是独立 bundle，模块级状态跨 bundle 不共享（`runtime.ts` 记过这个坑）。内存里那张 in-flight 表只作为同一 bundle 内的快速路径。

- **`progressStream` 在真机上不可能工作**：`progress` 事件带 sid 发出（`main.py:475`），而 `watchProgress` 自己造了个随机 `clientId` 去连 `/ws` —— 握手成功、`status` 能收，但**永远收不到本任务的进度**。真机实测：20 步跑完，相关事件 0 条。现在复用 `ComfyClient.clientId`（提交时用的那个），并新增 `Settings.progressStream`（默认关，`COMFYUI_PROGRESS_WS=1` 可开）。

  两条真机事实（对照本机 ComfyUI 源码核实）：`server.client_id` 是在**开始执行**时由 `extra_data["client_id"]` 赋值的（`execution.py:740`），所以它指的是"本任务的提交方"而不是"最后提交的那个"；但 `server.py:341-345` 同 sid 再连会 `sockets.pop(sid)`（旧连接不 close、只是不再收消息），所以**同一个 `client_id` 只能有一条活着的订阅**，并发两条运行时先建的那条会静默没有百分比。

  只接了面板路径（`/run`、`/rerun`）；工具侧没接 —— `ToolDeps` 里没有 `settings`，扩它要动 11 个工具的依赖面。

- **`comfyui_rerun`：从产物重跑 / 做变体**（第 11 个工具）。出图后最常见的下一步是"再来一张"或"这张构图好但细节差，调一点重跑"，而 sidecar 里已经躺着复现材料（`workflowId` / `workflowHash` / `vars` / `seed`），原来只能手工抄参数。

  三种 seed 策略：给数字就用它（`count>1` 依次 +1）、`'random'` 每张独立、不给就沿用原值递增。**sidecar 没记 seed 时出多张会各自随机** —— 否则三张是同一张的复制，"做变体"就失去意义。

  **seed 槽位名不硬编码**：从 IO 面找 `seed` 或 `noise_seed`，找不到就完全不注入。硬写 `vars.seed` 会让 `applyVariables` 抛 `variable_unknown` —— 本仓库自己的 `infer` 就把 `noise_seed` 当一等命名，这条踩过。

  工作流被改过（`workflowHash` 不同）时**提示但不阻止**：改内部参数不影响表面，`vars` 的键名可能仍兼容。

### 改进

- **执行失败分五类，建议按类给**。原来无论什么错都是同一句"通常是模型/节点参数不匹配或显存不足"。而真实失败就那么几类，解法完全不同：OOM 要降分辨率、缺模型要去装或换、输入图坏了要查文件、参数越界要改值。模型拿笼统句子只能猜，猜错就是又一轮报错。

  分类器是纯函数（`oom` / `missing_model` / `missing_node` / `bad_input` / `bad_param` / `unknown`），认不出就退化成原来那句。`code` 仍是 `execution_failed`（调用方可能按它分支），新增 `kind` 字段。

- **判据的二维性**：`isRetryable`（还等不等）与 `finalStateOf`（终态写什么）是**两件事**，不能合成一个布尔。典型分叉是 `no_output`（执行完成了但没拿到产物文件）：它还值得继续等 —— ComfyUI 写 outputs 与 SaveImage 落盘之间有竞态窗；但真的放弃时终态必须是 `failed`，"完成了但没产物"是个确定结论，写 unknown 会让人一直等。

  这个坑踩了两次：第一次是手写判据把 `no_output` 当"可重试的网络问题"，三条路径一起说"连续 6 次查不到 /history"（事实完全相反）；第二次是把判据换成 `isRetryable`，二维又压回一维，wait 路径照样把它降级成 pending，让用户去续查一个永远查不到的结果。

- **瞬时失败不再一次判死**：`/history` 报 5xx 在 ComfyUI 重启窗口里是常态，而 `watchRun` 原来一个 tick 就判死并发"执行失败"通知 —— 更糟的是判死后 `collectArtifacts` 永不执行，**图其实出了也不落盘**。现在只有 `execution_failed` / `auth_failed` 立即判死，网络类连续 6 次才标 unknown，文案改成"查不到 /history，用 promptId 续查"而不是"执行失败"。同一份 `client.history()` 的两个消费者（watchRun / sweepRun）现在用同一套判据。

- **`/history` 的 5xx 不再被当成"还没完成"**：原来 `if (!res.ok) return undefined`，于是 poller 永远认为任务在跑 —— 记录停在 queued、`activeCount` 虚高，而 ComfyUI 可能早挂了。现在 404 仍表示"记录还没有"，401/403 抛认证错误，其它非 2xx 抛可重试错误（文案说清是"查询失败"而不是"连不上"）。

  几个实测抓出来的坑：
  - **`Value not in list` 不能一律当缺模型**。`'add-detail-xl.safetensorsx' not in ['add-detail-xl.safetensors']` 是值写错了，候选里本来就有对的。现在归 `bad_param` 并点名"你写的是 X，候选里是 Y"。
  - **抓文件名要抓被拒绝的那个**。按扩展名找第一个匹配会落到候选列表里那个正确的名字，等于把"你拼错了"说成"你缺这个文件"。
  - 补了中文模式（自定义节点会抛中文）与 OOM / 缺节点的其它说法（`Errno 12 Cannot allocate memory`、`OOM when allocating tensor`、`The following node types were not found`、`Node 'X' not found`）。

### 新增

- **`comfyui_workflow_list` 可以按输入类型筛**：`inputs: 'image'` 只返回需要图片输入的工作流，并在结果里给出 `imageSlots`（该往哪个键里传图）与 `needsImage`。模型想"拿这张图去出图"时不必自己翻每个工作流的 `inputKinds` 再猜槽位名。

  配合 `comfyui_run` 的 `vars` 就通了：筛出工作流 → 把图路径传给对应槽位（`LoadImage` 只认 ComfyUI `input/` 目录里的文件名，插件会自动搬运本地图）。

  面板侧的"从资产库选图"入口尚未做 —— 那只是人类入口，模型这条链已经通了。

- **以产物当时的参数重跑（图作为输入）**：产物卡片上多一个按钮 —— 读 sidecar 里的 `workflowId` 与 `vars` **原样重跑，只把图片输入换成这张**。

  第一版做错了两处，都源于同一个误解：以为是"把图喂给某个工作流"，实际用户要的是"这张图当时怎么生成的，照那个再来一遍"。所以第一版让用户挑一个吃图的工作流、只传图路径，prompt / seed / 步数 / 模型全走默认值 —— 等于把原图的一半信息丢了。

  现在工作流由 sidecar 决定，不需要用户挑（那套浮层已删）。不传 `asInput` 就是普通重跑（参数全保留、不换图）；工作流不吃图会明确拒绝，不静默降级成空参数重跑。

  两个已知取舍：多个 image 槽位只换第一个（其余仍走 sidecar 原值）；普通重跑时 `image` 是 sidecar 里记的 ComfyUI 内文件名，依赖那份文件还在 ComfyUI 的 input 目录 —— 被删了会明确报错，不会静默跑空。

  面板走的是 HTTP 路由，与工具侧**是两份 `toListItem`** —— 第一版只改了工具侧那份，于是 `?inputs=image` 完全无效（形参还叫 `_url`，从不读 query），面板永远弹"本机没有需要图片输入的工作流"，静默失败还给出误导性提示。

  另外两处契约也只对了一半：`POST /run` 只认扁平的 `workflowId`（发 `{workflow:{id}}` 直接 400），而 `/run` 失败时返回 **200 + `ok:false`**（只看 `res.ok` 会把失败弹成"已提交"）。

- **精确进度（可选，默认关）**：`sweepRun` 新增 `progressStream`，从 ComfyUI 的 `/ws` 读 `progress` 事件，写进运行记录的 `progress: {value, max}`。轮询只能答"在跑吗、排队第几"，答不了"画到 37% 了"。

  **默认关闭，且未经真机验证**：本机 ComfyUI 离线（8188 无监听），这条路径只在注入假 WebSocket 下验过正向与降级。连不上时静默降级，出图不受影响。

  **目前没有任何生产调用方传它** —— `Settings` 里没有开关，`/run`、`run_batch`、`rerun` 都没接。只有测试或直接调用模块能开。

  已知局限：断线不重连（百分比会冻结在最后一次，看起来像卡住）；`max` 按采样节点重置会回跳；没有采样器的工作流（纯 upscale / VAE）全程无百分比；Node 20 没有全局 `WebSocket`，那时会静默不生效；有 basic auth / API key 的实例连不上；一条运行一条长连接，batch 20 就是 20 条。

  另外两处实现细节后来才补：`watchRun` 曾声明过 `progressStream` 却一次都没用（假契约，已删）；`stopAllWatchers` 原先只清 timer 不清进度连接，热重载后会残留 socket。

### 优化

- **批量提交只投递一条汇总通知**：`run_batch` 原来逐条挂 watcher，10 张图 = 10 次 `followup` = **10 轮对话打断** —— 一件本来可以一次说完的事被拆成十次汇报。

  **没有改用 `inject`（不唤醒）**：模型不知道出图效果就没法继续迭代，「这张脸崩了换 seed 再来」这类对话根本进行不下去。所以保留唤醒、改**频次**：一批结束投一条，含每条产物的路径与尺寸。

  踩了一个反直觉的坑：收尾处加「兜底 flush」看着稳妥，实际在异步路径上**必然先于任何 watcher 执行**，于是投出「本批 3 条全部结束（0 成功，0 失败），用时 0 秒」，而 `delivered` 标记把所有真实结果全挡掉 —— 比改动前的逐条推送更糟。兜底不能抢在真结果前面。

- **`run_batch` 按工作流分组后提交**：ComfyUI 的权重按"上次用的那份"常驻显存，同工作流连续跑只换 seed 不重载，但 `SDXL → Flux → SDXL` 来回切每次都要重载几十秒。改成提交前按工作流声明分组；`results` 仍按原始下标返回，调用方靠 `index` 对账不会错位。
- **`/queue` 加 1 秒缓存**：批量 20 条任务各自轮询，不缓存的话同一秒会打出 20 次请求。

## 0.4.0

### 新增

- **终端面板**（`panel.terminal`，可单独开关）：第三个面板，展示 ComfyUI 的命令行输出。想知道服务在干什么、卡在哪一步、模型加载到几成，这些只在终端里。

  **前提是把输出接上**：`ComfySupervisor` 此前用 `stdio: 'ignore'` 拉起子进程，ComfyUI 的输出被直接丢弃。现在改成 pipe，配一个 2000 行的环形缓冲挂在 runtime 上（组件可能还没加载，进程就已经在拉了）。缓冲带单调序号，前端按 cursor 拉增量，不重复下载整屏。

  **两个容易被忽略的细节**：ANSI 转义必须在入库前剥掉 —— ComfyUI 的进度条用 `\r` 加颜色码反复刷新同一行，原样送到浏览器是一屏乱码；子进程强制 `PYTHONIOENCODING=utf-8`，Windows 上不指定的话 Python 按控制台代码页输出（GBK），中文日志全是豆腐块。解码用 `TextDecoder` 的流式模式，进程退出时多字节字符被截在半个字符上也能拼回来。

  **面板能自己拉起服务**：只展示不启动的话，「打开终端看进度」必须先回对话生成一张图才会触发拉起 —— 那正是用户想避免的被动等待。面板上没有 `external` 实例时给出「启动」按钮。

  **外部实例也能看**：插件拉起的进程直接接 stdout / stderr；外部启动的实例（Desktop 自己起的那些）拿不到 stdout，改读它写的 `user/comfyui.log` —— 新增的 `LogTail` 首次给末尾 200 行、之后按偏移读增量、文件轮转则重来。两条路只走一条：ComfyUI 的 logger 同时挂 Stream 与 File 两个 handler，两边都读是每行两份。`installDirOf` 改成惰性探测（带负缓存，否则每 2 秒扫一次盘）—— 它原本只在 `start()` 里赋值，而外部实例根本走不到那里，日志就永远读不到。

  面板按状态分支说明（未启动 / 外部实例 / 启动失败带原因 / 正在读日志），而不是留一片空白让人以为是 bug。

  UI 上做了自动跟随底部（用户往上翻时不拽回来）、暂停、关键字过滤、清屏、丢弃行提示。

- **资产库可以一键隐藏 NSFW**：刷新按钮右侧一个省略号，悬浮展开。判定是启发式词表，不是分类器。

  强信号（`nsfw` / `explicit` / `hentai` / 性器官 / 中文「完全裸露」「完整裸露」「赤裸」「全裸」等）单命中即判；中信号（`nude` / `breast` / `lingerie` / 「裸露」「乳房」等）要凑够两个才算 —— 动漫 tag 里 `breasts`+`nipples` 是泳装与解剖图的标配，单命中必然误伤。

  三条约束都是被真数据打回来的：**存词根不存复数**（子串匹配，存 `breasts` 就漏 `breast`）；**不用下划线做边界**（tag 里 `lewd` 与 `lewd_pose` 都有）；**负向提示词不参与判定**（Danbooru 系底模的官方负向模板里就写着 `nsfw`，拿它判定会让一整库图全被藏，而那正是在排除成人内容）。在 363 张真实语料上校准过：「裸露」原本是强信号，会误伤 4 张 SFW 水彩插画（触发词「肩头裸露」），降为中信号后翻转恰好那 4 张。

### 修复

- **清屏接口恒 405**：`POST /terminal` 没进 `WRITABLE` 白名单，而前端不检查响应码 —— 界面清空了、下一秒整屏回填，看起来像灵异现象。同时前端现在看状态码，失败就不动本地状态。
- **cursor 超前会永久失明**：`since()` 原本回 `Math.max(cursor, last)`。插件热重载后缓冲重建、seq 从 1 开始，浏览器还拿着旧的高位 cursor，于是之后每轮都判成「没有新行」，面板死在原地；而唯一的自救手段（清屏）正好是坏的。改成回「实际给到哪一行」。
- **清屏会弹「更早的 N 行已滚出缓冲」**：可见行被计进了 `dropped`，而那是用户自己按的。
- **`/config` 只在工作流组件里注册**：关掉工作流后它 404，前端 catch 退化成「全开」—— 被关掉的页签照样显示，「独立开关」在组合场景下失效。挪到 core entry。
- **CRLF 收尾的进度条被拼成一行**：Windows 上 tqdm 的帧以 `\r` 开头、整行以 `\r\n` 收尾，
  先判「末尾是不是回车」就会整段保留，几十帧拼成一行。改成先剥 ANSI、再摘行尾回车、最后取最后一段 ——
  顺序错了就出错（转义码夹在回车两边，带着它们判必然拼帧）。
- **热重载后 cursor 失效却判不出来**：靠「序号是否连续」识别缓冲重建是错的 ——
  新缓冲可能已经输出到旧 cursor 之后，看起来完全连续，于是新内容前面几行永久丢失、旧行残留。
  改成给缓冲一个 `epoch` 代号，变了就清屏全量重拉。
- **首屏把「从未启动」说成「外部实例」**：只按 `managed` 二分，未启动时 `managed` 也是 false。改成按 `state` 分支。
- **计数比的是服务端总数**：PAGE=60 的库里没滚到底会显示「37 / 363」，像藏了 326 张。改成比「已加载」的条数。
- **隐藏后的「全选」会连带删掉看不见的**：`selectAllShown` 用的是未过滤全量列表 —— 隐藏 30 张后全选 39 张，一次删除把它们一起删掉。灯箱同源：按 → 会翻到隐藏的图，计数显示成「30 / 9」。三处都改成走过滤后的列表。
- **悬浮面板在指针到达前消失**：`top: calc(100% + 6px)` 中间是真空，鼠标斜着移过去时 `:hover` 断掉。改成面板自身 `padding-top` 撑间距；触屏没有 hover，补 `@media (hover:none)` 常驻。

## 0.3.0

### 新增

- **Danbooru 标签库组件**（`comfyui-workbench:danbooru`，可单独开关）：`danbooru_lookup` 支持按中文名或 Danbooru tag 查角色 / 画师，`danbooru_sync` 支持从 Danbooru 自抓。查询同时接受中文名、日文名与 Danbooru tag，空格与下划线等价，结果按「tag 名 → 别名精确 → 前缀 → 包含」分档、同档按帖子数降序。**输出只含 tag**（不带 postCount / 别名 / 匹配方式，避免挤占上下文）。本地库为空或没命中时自动走在线查询（`source: 'online'`），没同步过也能用。

  **数据随包内置**：`data/danbooru/` 里带 60,265 条（角色 35,384 + 画师 24,881，约 12MB），装好即可离线查询，不必先联网同步。来源是社区维护的中文库 [`danbooru-tags-data-zh`](https://github.com/amenorira/danbooru-tags-data-zh)（MIT，© 2026 amenorira），含中文名、别名（社区昵称如「葱娘」）与注释；上游 LICENSE 随数据保留。去掉被多条记录共用的别名后，角色 98.7% / 画师 94.9% 有中文名或别名（上游 CSV 为 99.7% / 95.8%）。`npm run danbooru:zh` 约 5 秒可重新导入（视网速）；自抓 wiki 作为补充路径保留（数据更新更及时，但对画师几乎拿不到中文名 —— Danbooru 平台不填 `other_names`）。

  **数据源降级**：`safebooru.donmai.us` 是 Danbooru 官方镜像（同接口、同数据，实测 `post_count` / `other_names` / 别名反查结果逐字段一致）。主站超时（8 秒）、`5xx`、`429` 或端点 `404` 时自动切换，`404` 也算镜像不可用 —— Danbooru 的"查无此项"是 `200 + []`，`404` 只表示这个站没有该端点。切过一次之后优先走能用的那个。`aibooru.online` 这类"同一套软件、不同数据库"的站不能当镜像（`hatsune_miku` 只有 1821 帖 vs 主站 148311）。

  **随包附带两个数据脚本**：`import-danbooru-zh.mjs`（从上游 CSV 重新导入）与 `sync-danbooru.mjs`（从 Danbooru 自抓），装包的人不必 clone 仓库就能自己更新数据。刻意排除了 `build.mjs`（依赖 devDep `esbuild`，装后跑必然 `ERR_MODULE_NOT_FOUND`）与 `acceptance.mjs`（打本机端口、写真数据目录）。

### 修复

含 0.3.0 新组件在开发期发现并修掉的缺陷（0.2.0 没有这个组件，升级者不会踩到）。

- **产物落到不相关的工作区**：`workspaceRegistry` 只知道有哪些工作区、不知道当前会话属于哪个，cwd 匹配不上时取列表首项 —— 而那个顺序与用户当前在哪个工作区无关，于是图落进了别人的目录。改成执行期用 `workingDirectory.get(session)` 取会话自己的工作区（`comfyui_run` 的 `exec.agent` 就带着 session），续查分支同步；`<会话工作区>/comfyui-output` 一棵并进写入授权，相册的读取授权也追加同一份（只修写入侧会变成"产物落对了、相册却列不出来、`/file` 还 403"）。该目录做 `canonical`，否则工作区是 junction / 符号链接时产物目录会把自己拒掉。配置项 `outputDir` 仍然最优先；面板直连（`runMode=direct`）与面板续查没有会话上下文，仍用启动期目录。
- **热度阈值是死旋钮**：参数写成 `post_count_gte`（Danbooru 不认，静默忽略），无论传多少都返回最热的那批。正确写法是 `search[post_count]=>N`。
- **限流下别名大面积丢失却报"同步完成"**：网络错误被一律当成"查不到"，覆盖率从 94% 掉到 61% 而日志正常。现在区分失败与空结果，日志报失败条数，退避吃服务端 `Retry-After`（30 秒上限）。
- **在线查询给出与本地不同的答案**：取 wiki 返回的第一条（顺序不代表热度）。改为逐条回查 `post_count` 后取最热。
- **在线被限流时静默返回空**：用户分不清"名字错了"与"被限流"。现在两种文案分开。
- **`404` 判定用错误文本匹配**：tag 名里可能含 404。改用状态码。
- **脚本参数传非法值时回退成 1/NaN**：`--min` 不带值会让 `Number(true) = 1`，静默跑成全量（全量 40 万条，实测 3~4 条/秒，约 30 小时）。现在挡类型。

### 工程

- **测试一直在测旧的 `lib`**：`npm test` 直接跑产物，而改代码只改 `src` —— 忘了 build 就变成"测试全绿、发包是旧的"。加 `pretest` 自动 build，守护断言明确盯产物（`lib/entries/gallery.js`）而不是源码。另加 `prepublishOnly` 在发布前重建，保证包内 `lib` 与 `src` 同步。
- 修掉五处形同虚设的测试（都是变异验证揭出来的）：断言硬依赖本机磁盘路径；某条靠"路径不存在"蒙对了规则；只测工具函数、没测工具有没有把参数传下去；测试自己传参数，测的是"支持"而不是"接没接上"；守护读 `src` 而运行时走 `lib`。
- **用户自己的库不会顶掉随包数据**：读路径优先用户数据目录、没有才回退包内；写路径只写用户目录，
  且 `writeStore` 拒绝任何指向随包数据目录的目标（含大小写变体与子目录）—— 否则一次写错就把随包的 12MB 覆盖掉。
- `files` 去掉一个不存在的根级 `client.js`。

## 0.2.0

### 修复

- **POSIX 上授权校验可被大小写绕过（读删越权）**：仓库里有两份 `authorize` / `roots` 实现 —— `shared/authz/` 一份，`panel-gallery/server/assets/` 一份，生产路由用的是后者。修前一份时漏了后一份，而它按 `toLowerCase()` 比较路径：POSIX 路径大小写敏感，`/data/App/x.png` 会被判在根 `/data/app` 之内而**放行**，随后 `statSync` / `unlinkSync` 用的却是原始路径 —— 校验通过的是 A，实际动的是 B。现在两处各一行 `export * from shared/authz/*`，只保留一份实现；折叠规则抽成 `foldPathCase`（Windows 折叠、其余平台原样），授权 / 根去重 / 缩略图缓存 / 扫描去重 / 工作区探测五处共用。
- 顺带补了两条此前抓不住的断言：同前缀兄弟目录（`/data/apple` 不属于 `/data/app`，把分隔符判断退化后会误放行），以及用 ghost 路径测 POSIX 大小写拒绝（不存在的路径会让 `canonical` 回退 `path.resolve`、保留原样）。
- **产物落到插件私有目录，而不是用户的工作区**：服务名取错。宿主服务叫 `workspaceRegistry`，`workspace` 只是它在 storages 里的**域名**（`workspace.json` 的 `unit.name`）—— 代码按域名去取，`ctx.get('workspace')` 恒为 `undefined`，工作区探测永远跳过这一级，产物一路退到 `~/.dsh-comfyui-workbench/outputs`，且没有任何报错。同时把 `workspaceRegistry` 加进包根 entry 的 `inject`：它不是"可见性"开关（`ctx.reflect.get` 本就不要求注入），而是**时序**——服务未就绪时 fiber 处于 INACTIVE、`apply` 不执行，探测会等它 ACTIVE 之后再跑。`GET /config` 的 `workspaceProbe` 可复核（`serviceCount` 应大于 0、`outputSource` 应为 `service`）。
- **同一工作区因路径大小写/分隔符不同而认不出来**：Windows 路径大小写不敏感、宿主给的 path 也可能是正斜杠，直接字符串比较会漏匹配、退回列表首项。比较前统一分隔符，并在 Windows 上折叠大小写（Unix 保持敏感，避免 `/srv/App` 与 `/srv/app` 撞在一起）；返回给调用方的仍是宿主原始形态。
- **多工作区时产物落到父工作区根下**：`related` 用 `paths.find` 取第一个前缀匹配，而 `D:\dsh` 与 `D:\dsh\notes` 可能都是 cwd 的祖先，靠前的先命中就返回。改为归一化分隔符后按路径长度降序取**最深**的那层。顺带修了正斜杠路径比不中的问题（Windows 下 `D:/x` 与 `D:\x` 直接比较永远不等）。
- **`comfyui_run` 的 `wait` / `waitMs` / `tags` 从未生效**：`execute` 一直在读这三个参数，但 schema 里没有声明，`additionalProperties:false` 下模型根本传不进来——「默认异步、可选同步等待」里的同步分支是死代码，产物索引的 tags 也恒为空。已补进 schema（`timeoutMs` 标为已弃用，语义并入 `waitMs`）。
- **出图通知可能重复投递**：`watchRun` 用 `setInterval` 轮询且不等上一轮 async 结束，`stop()` 又排在两个 `await` 之后 —— 响应稍慢时两个 tick 会同时读到 done，各投递一条通知（全量跑测试约 1/3 概率出现"收到 2 条"）。补 `settled`（只交付一次）与 `inflight`（防重入，`finally` 复位）守卫，完成 / 失败 / 超时三条路径语义一致；`settled` 只在真正投递前才置位，拼装通知文本若抛错仍会走失败通知而不是静默。另外两处 `logger.warn` 调用各自包了 `try` —— logger 是外部注入的，它自己抛错不该让通知丢失，更不该逃逸成 unhandledRejection（Node 默认因此结束宿主进程）。
- **五条 entry 面板全空**：组件 entry 是独立 bundle，`runtime.ts` 被各内联一份，模块级单例在 entry 之间不共享（`globalThis` 实测同样不共享），五个 prefix handler 各看各的路由表，导致 `/config`、`/workflows` 全 404、资产库与工作流面板同时为空。共享锚点改为 `ctx.root`（cordis 里所有 entry 的唯一共同原点，已用宿主 asar 内的 cordis 4.0.5 实测确认）。同时把 ComfyUI 客户端 / 进程托管 / 资产索引从「每条 entry 各建一份」收敛为一份。
- **重载后相册 404、要第二次重载才自愈**：core entry 只 `acquire` 不 `release`，引用计数永不到 0，旧运行时带着失效的 ctx 存活，重载时挂 effect 抛 `cannot create effect on inactive context`。现在 acquire / release 配对，卸载后 `refs=0`、`supervisor.dispose` 恰好调用一次。连续三轮全卸载→重载实测：prefix `1→0→1`、三个接口始终 200。
- **`ensureHttp` 先置位再注册**：失败或热重载后 `httpMounted` 恒为 true，前缀永不重新注册。改为注册成功后才置位，disposer 里复位。
- 注册类操作（`ensureHttp` / `track`）改用**调用方** ctx，不再用创建者的 —— 创建者 entry 卸载后再挂 effect 会抛。
- 被 `disabledComponents` 关掉的组件先判配置再 `acquire`，不再白建一份客户端与监督器；core 补 `inject: ['webServer']`，避免 HTTP 前缀落到某个组件身上（单独关它会整体失效）。
- `/workflows` 的批量导出实现留在相册（要读图、sidecar、打包），但不再挂进相册路由表，改由工作流组件的 POST 转发，消除两边抢同一路径的覆盖。
- 出图通知把消息来源写成 `{ kind: 'plugin', plugin: …, form: 'notice', summary: … }`，会话格式 v4 明确拒绝这个写法（`format v4 message requires a producer-owned source kind`），`Agent.followup` 在落事件时抛 `SessionFormatError`：通知永远发不出去，异常还发生在 agent 的 inbox 写入路径上，会把发起会话的驱动留在异常态（表现为那个对话再也接不到新消息）。现改为 v4 合法的 `{ kind: 'plugin:dsh-comfyui-workbench' }` —— 正是 v3→v4 迁移把旧写法改写成的形状。
- 通知投递一律经 `deliver()` 兜住异常并记日志，超时/完成/失败三条路径都不再把异常抛回宿主。
- `comfyui_run` 不再把产物作为 MCP 风格的内联图片块返回。宿主把工具结果的每个块按 `{type:'image', attachment}` 重建模型请求，裸 base64 块会让请求装配读到空 attachment 而抛错，被 LLM 适配器包装成 `TRANSPORT`；该块一旦落进会话历史，**这个会话之后每次请求都失败**（重进会话仍只报 `TRANSPORT`）。现在工具响应只含文本：路径、MIME、体积、原始宽高。
- `ToolBlock` 收窄为 `ToolText`，`ToolImage` 类型移除；`returnImages` 工具参数与同名配置字段保留但已弃用，只为兼容旧调用与旧配置。

### 清理

- 删除 `isDeadCtx`（判 `fiber.active` 在 cordis 4.0.5 下恒不成立，属死代码）、`runtimeReady`（无调用者）、`Runtime.ownerCtx`（只写不读）。
- 移除 `lib/{gallery,generate,edit}.js` 三个历史遗留产物（entry 产物已迁到 `lib/entries/`，这三个不再生成、全仓无引用）。

### 客户端

- 工作台外壳：资产库 / 工作流两个页签，共用侧边栏入口与 better-sidebar 页签。
- 工作流面板：选择器（标题 · 底模 · 备注）、只有输入输出的表单、advanced 折叠、输出区。
- 两种运行方式：**发进对话**（把结构化参数填进输入框，由模型调 `comfyui_run`）与**直接生成**（HTTP 直连，不消耗模型往返）。
- 参考图转提示词：图与固定格式指令一并填进输入框。自动回填依赖"订阅本会话新消息"，该能力尚未验证，因此当前停在"填好等你按回车"，并在找不到输入框时明确报错。

### 服务托管

- 探测：环境变量 `COMFYUI_HOME` / `COMFYUI_PATH` / `COMFYUI_DIR` → 常见位置；判据是"有 `main.py` 且有 `models/`"。
- 三种状态：外部在跑（只用不托管）、未跑但已安装（按需拉起）、未跑且未安装（报错给指引）。
- 只停**自己拉起的**进程；外部实例永不触碰（有测试钉住）。
- 空闲回收；拉起期间请求排队等待而不是立刻失败。
- `GET /service` 看状态（state / managed / pid / installDir / detail），`POST /service/stop` 停自己拉起的那个。

### 迁移

- `node scripts/migrate-album.mjs [--write]`：把相册的 roots / 扫描上限抄到本插件数据目录，不碰产物、不改 profile 装载行。

### 工程

- 测试覆盖：架构、静态、类名、宿主接口、客户端渲染、IO 面与变量、索引、执行链、HTTP 契约、服务托管、通知投递、组件隔离、目录解析。

## 0.1.0

首个版本：把 `dsh-comfyui-album` 的资产浏览能力整体继承过来，并加上工作流执行。

### 资产库

- 侧边栏入口 + 主面板；装了 `dsh-better-sidebar` 时注册页签，未装静默缺席。
- 搜索、根目录筛选、仅生成图、分页、手动重扫。
- 悬浮动作：复制图片、复制提示词、导出工作流、加入当前对话、删除。
- 灯箱：缩放、适应窗口、←→ 翻页、ESC。
- 多选：全选 / 清除 / 批量导出工作流（ZIP）/ 批量删除。
- 同图副本合并（`seed + 尺寸 + 提示词` 签名，不做内容哈希 —— 编码差异会导致漏合并）。
- 元数据：sidecar 优先，缺失时回退 PNG 内嵌工作流。

### 工作流

- `dsh workbench import`：只接受 API 格式；UI 格式给出 Export (API) 指引。
- IO 面推断：连线跳过、内部参数跳过、正负提示词按采样器回溯命名、`basic` 段只收提示词与图像。
- `applyVariables`：`bind` 路径写入 + `{{var}}` 按值替换（整串占位符保类型，数字不退化字符串）。
- 四个工具：`comfyui_workflow_list` / `comfyui_workflow_inspect` / `comfyui_run` / `comfyui_workflow_edit`。
- 执行：预检 → 提交 → 轮询 → 超时必发 `/interrupt` → 取产物 → sidecar。
- 工具响应带回图片块，并在文本中声明原始像素尺寸。

### 索引

- JSONL 追加式索引，可删可重建（真源是 sidecar）。
- `GET /assets`（q / workflow / tag / kind / status / 游标）、`POST /assets/rebuild`。

### 工程

- 全部 TypeScript，按域分层（scan / host / assets / workflow / comfy / run / store / tools / http / client）。
- `tests/arch.mjs` 把依赖方向约束变成可执行检查。
- 运行时零依赖（只用 `node:*`），构建期只依赖 typescript + esbuild + @types。
- 22 项测试：架构、静态、宿主接口、客户端渲染、IO 面与变量、索引、执行链（本地假 ComfyUI）。
