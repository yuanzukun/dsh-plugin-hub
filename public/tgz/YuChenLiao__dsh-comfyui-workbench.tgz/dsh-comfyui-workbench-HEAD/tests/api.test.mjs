/**
 * HTTP 层自检：工作流列表 / 详情 / 资产检索的契约。
 *
 * 全部用临时目录，不碰 ~/.dsh —— 这几个路由的默认目录来自配置，测试必须注入。
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import http from 'node:http'
import os from 'node:os'
import path from 'node:path'
import { test } from 'node:test'
import { listenSafe } from './helpers.mjs'


import { importWorkflowFile } from '../lib/workflow.js'

// 插件的默认目录（uploads / outputs / 索引）都挂在主目录下，测试必须隔离，
// 否则会扫到本机真实数据（上一轮就被真实产物绊过）。
const isoHome = fs.mkdtempSync(path.join(os.tmpdir(), 'cwf-home-'))
process.env.USERPROFILE = isoHome
process.env.HOME = isoHome
const { applyAll } = await import('../lib/index.js')

/** 起一个只含必要服务的假宿主。 */
async function boot(config) {
  const prefixRoutes = []
  const tools = []
  const ctx = {
    get(name) {
      if (name === 'webServer') {
        return {
          register(route) {
            prefixRoutes.push(route)
            return () => {}
          },
        }
      }
      if (name === 'tools') {
        return {
          register(spec) {
            tools.push(spec)
            return () => {}
          },
        }
      }
      return undefined
    },
    effect(run) {
      return run()
    },
  }

  applyAll(ctx, config)

  const registered = prefixRoutes[0]
  assert.ok(registered !== undefined, '应当注册 HTTP 路由')

  const server = http.createServer((req, res) => {
    void registered.handler(req, res)
  })
  const port = await listenSafe(server)
  const origin = `http://127.0.0.1:${port}`
  return {
    origin,
    tools,
    close: () => new Promise(resolve => server.close(resolve)),
  }
}

function tmpDirs() {
  const base = fs.mkdtempSync(path.join(os.tmpdir(), 'cwf-api-'))
  const workflows = path.join(base, 'workflows')
  const out = path.join(base, 'out')
  const uploads = path.join(base, 'uploads')
  const index = path.join(base, 'assets.jsonl')
  fs.mkdirSync(workflows, { recursive: true })
  fs.mkdirSync(out, { recursive: true })
  fs.mkdirSync(uploads, { recursive: true })
  return { base, workflows, out, uploads, index }
}

/** 1×1 透明 PNG。 */
const TINY_PNG = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
  'base64',
)

const SAMPLE = path.join(process.cwd(), 'samples', 'text2img-basic.json')

test('GET /workflows：空目录返回零条，导入后带模型与备注状态', async () => {
  const dirs = tmpDirs()
  const app = await boot({
    roots: [dirs.out],
    outputDir: dirs.out,
    workflowsDir: dirs.workflows,
  })

  try {
    const empty = await (await fetch(`${app.origin}/comfyui-workbench/api/workflows`)).json()
    assert.equal(empty.ok, true)
    assert.equal(empty.count, 0)
    assert.deepEqual(empty.workflows, [])

    importWorkflowFile(dirs.workflows, SAMPLE)

    const list = await (await fetch(`${app.origin}/comfyui-workbench/api/workflows`)).json()
    assert.equal(list.count, 1)
    const item = list.workflows[0]
    assert.equal(item.workflowId, 'text2img-basic')
    assert.equal(item.model, 'sd_xl_base_1.0.safetensors')
    assert.equal(item.modelKind, 'checkpoint')
    assert.equal(item.undescribed, true, '没有备注时应标出来')
    assert.deepEqual(item.inputKinds.sort(), ['number', 'string'])
    assert.ok(item.basicCount === 2, 'prompt 与 negative_prompt 进 basic')
  } finally {
    await app.close()
  }
})

test('GET /workflows/{id}：返回完整输入槽位；不存在时 404', async () => {
  const dirs = tmpDirs()
  importWorkflowFile(dirs.workflows, SAMPLE)
  const app = await boot({ roots: [dirs.out], outputDir: dirs.out, workflowsDir: dirs.workflows, uploadsDir: dirs.uploads, indexFile: dirs.index })

  try {
    const detail = await (await fetch(`${app.origin}/comfyui-workbench/api/workflows/text2img-basic`)).json()
    assert.equal(detail.ok, true)
    const surface = detail.surface
    assert.equal(surface.workflowId, 'text2img-basic')
    assert.equal(surface.inputs.length > 0, true)
    const prompt = surface.inputs.find(slot => slot.name === 'prompt')
    assert.equal(prompt.group, 'basic')
    assert.equal(prompt.bind, '6.inputs.text')
    assert.equal(surface.outputs[0].kind, 'image')

    const missing = await fetch(`${app.origin}/comfyui-workbench/api/workflows/nope`)
    assert.equal(missing.status, 404)
    assert.equal((await missing.json()).error, 'no-workflow')
  } finally {
    await app.close()
  }
})

test('POST /workflows/{id} 改设置：不存在的工作流 404', async () => {
  const dirs = tmpDirs()
  const app = await boot({ roots: [dirs.out], outputDir: dirs.out, workflowsDir: dirs.workflows, uploadsDir: dirs.uploads, indexFile: dirs.index })
  try {
    // 这条路径现在是"改工作流设置"（启用/备注），不再是只读
    const res = await fetch(`${app.origin}/comfyui-workbench/api/workflows/text2img-basic`, { method: 'POST' })
    assert.equal(res.status, 404, '工作流不存在就该 404')
    const del = await fetch(`${app.origin}/comfyui-workbench/api/workflows/text2img-basic`, { method: 'DELETE' })
    assert.equal(del.status, 405, 'DELETE 仍不受支持')
  } finally {
    await app.close()
  }
})

test('POST /workflows 仍是批量导出（无 body 时 400）', async () => {
  const dirs = tmpDirs()
  const app = await boot({ roots: [dirs.out], outputDir: dirs.out, workflowsDir: dirs.workflows, uploadsDir: dirs.uploads, indexFile: dirs.index })
  try {
    const res = await fetch(`${app.origin}/comfyui-workbench/api/workflows`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    })
    assert.equal(res.status, 400)
    assert.equal((await res.json()).error, 'bad-paths')
  } finally {
    await app.close()
  }
})

test('GET /assets：索引为空时返回空列表而不是报错', async () => {
  const dirs = tmpDirs()
  const app = await boot({ roots: [dirs.out], outputDir: dirs.out, workflowsDir: dirs.workflows, uploadsDir: dirs.uploads, indexFile: dirs.index })
  try {
    const res = await fetch(`${app.origin}/comfyui-workbench/api/assets?limit=10`)
    assert.equal(res.status, 200)
    const body = await res.json()
    assert.equal(body.ok, true)
    assert.deepEqual(body.items, [])
  } finally {
    await app.close()
  }
})

test('POST /run 拒绝授权范围外的输出目录', async () => {
  const dirs = tmpDirs()
  importWorkflowFile(dirs.workflows, SAMPLE)
  const app = await boot({ roots: [dirs.out], outputDir: dirs.out, workflowsDir: dirs.workflows, uploadsDir: dirs.uploads, indexFile: dirs.index })

  try {
    const res = await fetch(`${app.origin}/comfyui-workbench/api/run`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        workflowId: 'text2img-basic',
        vars: { prompt: 'x' },
        outputPath: path.join(os.tmpdir(), 'cwf-outside-should-not-exist'),
      }),
    })
    const body = await res.json()
    assert.equal(res.status, 400)
    assert.equal(body.error, 'forbidden-output')
    assert.match(body.message, /assetRoots/)

    // 授权内的目录不该被这一步拦下。用一个不存在的参数让它**在校验阶段**就失败，
    // 免得测试真的去连 ComfyUI 跑一次生成（那会让单测依赖外部服务状态与 GPU）。
    const ok = await fetch(`${app.origin}/comfyui-workbench/api/run`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ workflowId: 'text2img-basic', vars: { notAParameter: 1 }, outputPath: dirs.out }),
    })
    const okBody = await ok.json()
    assert.equal(okBody.error === 'forbidden-output', false, '授权内的目录不该被判为越权')
    assert.equal(okBody.code, 'variable_unknown', '应当走到参数校验这一步')
  } finally {
    await app.close()
  }
})

test('POST /upload：二进制直传落到上传目录，返回尺寸', async () => {
  const dirs = tmpDirs()
  const app = await boot({ roots: [dirs.out], outputDir: dirs.out, workflowsDir: dirs.workflows, uploadsDir: dirs.uploads, indexFile: dirs.index })
  try {
    const res = await fetch(`${app.origin}/comfyui-workbench/api/upload?filename=${encodeURIComponent('参考图.png')}`, {
      method: 'POST',
      headers: { 'content-type': 'image/png' },
      body: TINY_PNG,
    })
    assert.equal(res.status, 200)
    const body = await res.json()
    assert.equal(body.ok, true)
    assert.ok(typeof body.path === 'string' && fs.existsSync(body.path), '文件应当真的落盘')
    assert.equal(body.bytes, TINY_PNG.length)
    assert.equal(body.width, 1)
    assert.equal(body.height, 1)
    assert.ok(body.path.includes('参考图'), '文件名里的中文要保留')
    // 落了盘就能预览：同一条 /file 通道读得到
    const file = await fetch(`${app.origin}/comfyui-workbench/api/file?path=${encodeURIComponent(body.path)}`)
    assert.equal(file.status, 200)
  } finally {
    await app.close()
  }
})

test('POST /upload：不是图片就拒绝，扩展名不认也拒绝', async () => {
  const dirs = tmpDirs()
  const app = await boot({ roots: [dirs.out], outputDir: dirs.out, workflowsDir: dirs.workflows, uploadsDir: dirs.uploads, indexFile: dirs.index })
  try {
    const fake = await fetch(`${app.origin}/comfyui-workbench/api/upload?filename=a.png`, {
      method: 'POST',
      headers: { 'content-type': 'image/png' },
      body: Buffer.from('this is not an image'),
    })
    assert.equal(fake.status, 400)
    assert.equal((await fake.json()).error, 'not-an-image')

    const badExt = await fetch(`${app.origin}/comfyui-workbench/api/upload?filename=a.exe`, {
      method: 'POST',
      headers: { 'content-type': 'application/octet-stream' },
      body: TINY_PNG,
    })
    assert.equal(badExt.status, 400)
    assert.equal((await badExt.json()).error, 'unsupported-type')
  } finally {
    await app.close()
  }
})

test('终端面板：GET /terminal 不能被方法校验拦成 405', async () => {
  // 这条必须走真实的 createDispatch —— 前两轮分别漏了"POST 被 WRITABLE 漏掉"
  // 和"GET 被 WRITABLE 封死"，都是因为测试直接调组件路由、绕过了方法校验层。
  const dirs = tmpDirs()
  const app = await boot({
    roots: [dirs.out],
    outputDir: dirs.out,
    workflowsDir: dirs.workflows,
    uploadsDir: dirs.uploads,
    indexFile: dirs.index,
    // 别让测试真去拉 ComfyUI
    autoStart: false,
    autoDetect: false,
  })
  try {
    // 这里是真 http server，直接 fetch（boot 返回的是 origin 而不是封装好的 get/post）
    const read = await fetch(`${app.origin}/comfyui-workbench/api/terminal?since=0`)
    assert.equal(read.status, 200, 'GET 必须可用（面板靠它轮询）')
    const readBody = await read.json()
    assert.equal(readBody.ok, true)
    assert.ok(Array.isArray(readBody.lines))

    const clear = await fetch(`${app.origin}/comfyui-workbench/api/terminal`, { method: 'POST' })
    assert.equal(clear.status, 200, 'POST 是清屏')

    const start = await fetch(`${app.origin}/comfyui-workbench/api/terminal?action=start`, { method: 'POST' })
    assert.equal(start.status, 200, 'POST ?action=start 是拉起服务')
  } finally {
    await app.close()
  }
})

test('工具注册：6 个工具都带必要字段', async () => {
  const dirs = tmpDirs()
  const app = await boot({ roots: [dirs.out], outputDir: dirs.out, workflowsDir: dirs.workflows, uploadsDir: dirs.uploads, indexFile: dirs.index })
  try {
    const names = app.tools.map(spec => spec.name).sort()
    assert.deepEqual(names, [
      'comfyui_run',
      'comfyui_workflow_edit',
      'comfyui_workflow_inspect',
      'comfyui_workflow_list',
      'danbooru_lookup',
      'danbooru_sync',
    ])
    for (const spec of app.tools) {
      assert.equal(typeof spec.description, 'string')
      assert.ok(spec.description.length > 20, `${spec.name} 的描述应当能让模型判断何时用`)
      assert.equal(typeof spec.execute, 'function')
      assert.ok(spec.output !== undefined && typeof spec.output.render === 'function')
    }
  } finally {
    await app.close()
  }
})
