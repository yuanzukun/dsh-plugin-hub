/**
 * 类名自检：组件里用到的每一个 cwb-/cwf-/cfa- 类，样式表里必须有定义。
 *
 * 这条检查是一次次真事故换来的：
 *   - 重写版式时漏掉 ImagePicker 的 10 个类 → 上传区变成裸文字
 *   - 把外壳容器改名却留下旧类名 → 相册高度链断了、滚动条消失
 * 两次都是"组件引用了样式表里不存在的类"，肉眼看不出来，只能靠机器盯。
 */
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const root = path.join(here, '..')
const clientDir = path.join(root, 'src', 'client')
// 组件拆分后 UI 分散在 src/components/*/client，扫描要覆盖整个 src
const srcDir = path.join(root, 'src')

/** 收集一个目录下所有源码。 */
function sources(dir) {
  const out = []
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name)
    if (entry.isDirectory()) out.push(...sources(full))
    else if (/\.(ts|tsx)$/.test(entry.name)) out.push(full)
  }
  return out
}

/** 样式表文件（它们定义类名）。 */
// 每个组件一个独立 .css（构建时按文本导入），外加工作台外壳那份。
// **新增面板时必须在这里补一行**，否则它用的类名会被判成"没定义"。
const STYLE_FILES = [
  path.join(root, 'src', 'components', 'panel-gallery', 'client', 'styles.css'),
  path.join(root, 'src', 'components', 'panel-tags', 'client', 'styles.css'),
  path.join(root, 'src', 'components', 'panel-poses', 'client', 'styles.css'),
  path.join(root, 'src', 'components', 'panel-costumes', 'client', 'styles.css'),
  path.join(root, 'src', 'components', 'panel-characters', 'client', 'styles.css'),
  path.join(root, 'src', 'components', 'panel-terminal', 'client', 'styles.css'),
  path.join(clientDir, 'styles.css'),
]

/**
 * 类名前缀表。**新增面板必须在这里补自己的前缀**，否则它的类名既不进 defined
 * 也不进 used —— 检查看起来全绿，实际那个面板完全没被校验（终端面板漏了整整一轮，
 * 直到样式迁移时才被发现：加了它的 .css 却没加 `cwt`，校验是空转的）。
 */
const PREFIXES = 'cwb|cwf|cfa|cwa|ctg|cps|cct|cwt|cch|cmf|csf|csm|cpm'

/** 样式表里定义过的类名。 */
const defined = new Set()
for (const file of STYLE_FILES) {
  const text = fs.readFileSync(file, 'utf8')
  for (const match of text.matchAll(new RegExp(`\\.((?:${PREFIXES})-[a-z0-9-]+)`, 'g'))) defined.add(match[1])
}

/** 组件源码里引用过的类名（含模板字符串里的静态片段）。 */
const used = new Map()
for (const file of sources(srcDir)) {
  // 只扫源码（.ts/.tsx）；样式表在 STYLE_FILES 里，本来就不在这个集合中
  const text = fs.readFileSync(file, 'utf8')
  for (const match of text.matchAll(new RegExp(`\\b((?:${PREFIXES})-[a-z0-9-]+)`, 'g'))) {
    const name = match[1]
    // `cwf-field-${type}` 这种动态拼接只会命中前缀，跳过
    if (name.endsWith('-')) continue
    if (!used.has(name)) used.set(name, new Set())
    used.get(name).add(path.relative(root, file))
  }
}

const missing = [...used.entries()]
  .filter(([name]) => !defined.has(name))
  .map(([name, files]) => `${name}（${[...files].join(', ')}）`)

assert.deepEqual(missing, [], `这些类名在样式表里没有定义：\n  ${missing.join('\n  ')}`)

const unused = [...defined].filter(name => !used.has(name))
console.log(`classes: 全部通过（${used.size} 个类名都有定义${unused.length === 0 ? '' : `；${unused.length} 个已定义但没用到`}）`)

/**
 * 弹层层级：**必须在灯箱之上**。
 *
 * 这条是被真事故换来的：`MaskEditor` 与 `SendToWorkflow` 最初用 `z-index:60`，
 * 而灯箱是 2600 —— 两个弹层的唯一入口都在灯箱里，于是点开按钮界面毫无反应，
 * 整条"涂蒙版 → 局部重绘"和"送入工作流"完全进不去。上面的类名检查查不出这种错，
 * 因为类名确实都有定义。
 */
const galleryStyles = path.join(root, 'src', 'components', 'panel-gallery', 'client', 'styles.css')
const galleryCss = fs.readFileSync(galleryStyles, 'utf8')
const zIndexOf = selector => {
  const match = new RegExp(`${selector.replace('.', '\\.')}[^{]*\\{[^}]*z-index:\\s*(\\d+)`).exec(galleryCss)
  return match === null ? NaN : Number(match[1])
}
const lightboxZ = zIndexOf('.cfa-lb')
assert.ok(Number.isFinite(lightboxZ), '找不到 .cfa-lb 的 z-index —— 这条检查本身需要跟着改')
for (const selector of ['.cmf-root', '.csf-root', '.csm-root', '.cpm-root']) {
  const z = zIndexOf(selector)
  assert.ok(
    Number.isFinite(z) && z > lightboxZ,
    `${selector} 的 z-index（${z}）必须高于灯箱 ${lightboxZ}：入口在灯箱里，盖住就等于功能不可用`,
  )
}
console.log(`层级: 弹层 ${zIndexOf('.cmf-root')} / ${zIndexOf('.csf-root')} > 灯箱 ${lightboxZ}`)

/**
 * 滚动区里的组不能被 flex 压扁。
 *
 * `.cwa-list` 是工作流面板唯一的滚动区（`flex:1;min-height:0;overflow:auto`），而它的
 * 子项默认 `flex-shrink:1` —— 内容一高，flex 先把组压扁，组上的 `overflow:hidden`
 * 再把压掉的部分裁掉：展开的卡片看起来"被截断"，而且因为没有溢出到滚动区，
 * 连滚动条都不出现。这条断言就是为这个真事故设的。
 */
const workbenchCss = fs.readFileSync(path.join(clientDir, 'styles.css'), 'utf8')
const workbenchGroupRule = /\.cwa-group\{([^}]*)\}/.exec(workbenchCss)
assert.ok(workbenchGroupRule !== null, '找不到 .cwa-group 规则')
assert.match(workbenchGroupRule[1], /flex-shrink:0/, '.cwa-group 必须 flex-shrink:0，否则展开的卡片会被压扁截断且不出滚动条')
console.log('滚动: .cwa-group 不参与 flex 压缩')
