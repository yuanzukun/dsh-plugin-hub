import crypto from 'node:crypto'

import type { ApiWorkflow } from '../workflow/types.js'
import { authFailed, comfyUnreachable, describeNodeErrors, RunError, submitRejected } from './errors.js'
import { parseQueue } from './queue.js'
import type { FileRef, HistoryEntry, ObjectInfo } from './types.js'

/** 客户端配置。 */
export interface ComfyClientOptions {
  /** 形如 `http://127.0.0.1:8188`（不带尾斜杠）。 */
  baseUrl: string
  /** 透传请求头：反代鉴权、Cookie 之类。插件不内置任何默认值。 */
  headers?: Record<string, string>
  /** 单次 HTTP 上限（毫秒）。长任务不靠它兜，靠轮询超时。 */
  requestTimeoutMs?: number
  /**
   * 请求前的"确保服务可用"钩子（服务托管用）。
   * 返回 false 表示拉不起来，直接归成 comfy_unreachable。
   */
  ensure?: () => Promise<boolean>
}

/** 默认单请求超时：`/object_info` 可能几 MB，给足但不无限等。 */
const DEFAULT_REQUEST_TIMEOUT = 120_000

/**
 * ComfyUI 的 HTTP 客户端。
 *
 * 只做传输与错误分类，不含业务：什么时候预检、轮询多久、产物怎么命名都不在这里。
 * 端点按 ComfyUI 的既有 API：`/system_stats`、`/object_info`、`/prompt`、
 * `/history/{id}`、`/view`、`/interrupt`。
 */
export class ComfyClient {
  readonly baseUrl: string
  private readonly headers: Record<string, string>
  private readonly requestTimeoutMs: number
  private readonly ensure: (() => Promise<boolean>) | undefined
  /** `/object_info` 缓存：响应可能好几 MB，同一进程不必反复拉。 */
  /** `/queue` 的短缓存：同一 tick 里多条任务共用一次查询。 */
  private queueCache: { at: number; value: { running: string[]; pending: string[] } } | undefined
  /**
   * 正在飞的那次 `/queue` 请求。
   *
   * 只靠 `queueCache` 挡不住并发：缓存要等结果回来才写，20 个任务在冷启动那一瞬间
   * 看到的是同一个空缓存，于是同时发 20 个请求。共享 in-flight promise 才是真去重。
   */
  private queueInflight: Promise<{ running: string[]; pending: string[] }> | undefined
  private infoCache: ObjectInfo | null = null
  /**
   * 提交时带的 client_id（ComfyUI 用它区分来源），也是订阅 `/ws` 进度时必须复用的那个。
   *
   * 机制（对照本机 ComfyUI 源码核实）：
   * - `progress` 事件带 sid 发出（`main.py:475` 的 `send_sync("progress", progress, client_id)`）；
   * - 那个 `server.client_id` 在**开始执行**时由 `extra_data["client_id"]` 赋值
   *   （`execution.py:740`），所以是"本任务的提交方"，不是"最后提交的那个"；
   * - 自己另造一个随机 id 去订阅，握手会成功、`status` 能收到，但永远收不到
   *   `progress`（真机实测：20 步跑完，相关事件 0 条）。
   *
   * 注意 `server.py:341-345`：同 sid 再连会 `self.sockets.pop(sid, None)`（旧连接
   * 被摘出字典、不会被 close），所以**同一个 client_id 只能有一条活着的订阅**——
   * 并发两条运行同时开进度时，先建的那条会静默收不到。
   */
  readonly clientId = crypto.randomUUID()

  constructor(options: ComfyClientOptions) {
    this.baseUrl = options.baseUrl.replace(/\/+$/, '')
    this.headers = options.headers ?? {}
    this.requestTimeoutMs = options.requestTimeoutMs ?? DEFAULT_REQUEST_TIMEOUT
    this.ensure = options.ensure
  }

  /** 发一个请求；网络层失败统一归成 comfy_unreachable。 */
  private async request(
    path: string,
    init: RequestInit = {},
    timeoutMs = this.requestTimeoutMs,
    skipEnsure = false,
  ): Promise<Response> {
    if (this.ensure !== undefined && !skipEnsure) {
      const ready = await this.ensure()
      if (!ready) throw comfyUnreachable(this.baseUrl, new Error('服务未就绪，自动拉起也失败了'))
    }
    const url = `${this.baseUrl}${path}`
    try {
      return await fetch(url, {
        ...init,
        headers: { ...this.headers, ...(init.headers ?? {}) },
        signal: AbortSignal.timeout(timeoutMs),
      })
    } catch (error) {
      throw comfyUnreachable(this.baseUrl, error)
    }
  }

  /** 存活探测：轻量、不缓存。 */
  async systemStats(): Promise<unknown> {
    const res = await this.request('/system_stats', { method: 'GET' }, 10_000)
    if (res.status === 401 || res.status === 403) throw authFailed(this.baseUrl, res.status)
    if (!res.ok) throw comfyUnreachable(this.baseUrl, new Error(`/system_stats 返回 ${res.status}`))
    return await res.json()
  }

  /**
   * 节点清单。
   *
   * @param refresh - 强制重新拉（用户显式刷新时用）。
   */
  async objectInfo(
    refresh = false,
    options?: { timeoutMs?: number; skipEnsure?: boolean },
  ): Promise<ObjectInfo> {
    if (!refresh && this.infoCache !== null) return this.infoCache
    const res = await this.request('/object_info', { method: 'GET' }, options?.timeoutMs, options?.skipEnsure === true)
    if (res.status === 401 || res.status === 403) throw authFailed(this.baseUrl, res.status)
    if (!res.ok) throw comfyUnreachable(this.baseUrl, new Error(`/object_info 返回 ${res.status}`))
    const parsed: unknown = await res.json()
    const info = parsed !== null && typeof parsed === 'object' ? (parsed as ObjectInfo) : {}
    this.infoCache = info
    return info
  }

  /**
   * 查队列：哪些在跑、哪些在排。
   *
   * ComfyUI 的 `/queue` 响应是 `{ queue_running: [...], queue_pending: [...] }`，
   * 每项形如 `[number, prompt_id, {...}, extra, outputs]`。这个结构的字段在
   * 0.3 前后调整过（曾经叫 `queue_running` / 也出现过 `running`），所以按
   * "取到就用、取不到当空"写，不假定某一种精确形状 —— 与 `/object_info` 的处理一致。
   *
   * @returns 运行中与排队中的 promptId（顺序即队列顺序）。
   */
  async queue(): Promise<{ running: string[]; pending: string[] }> {
    // 批量提交时 20 条任务各自轮询，如果不缓存，同一秒会打出 20 次 /queue。
    // 这个数据本来就滞后于真实队列，1 秒的陈旧度不影响判定。
    const now = Date.now()
    if (this.queueCache !== undefined && now - this.queueCache.at < 1_000) return this.queueCache.value
    // **single-flight**：缓存只在结果回来之后才写，所以 20 个并发调用在"冷启动那
    // 一瞬间"会全部穿透 —— 它们看到的是同一个空缓存。共享同一个 in-flight promise
    // 才能真的只打一次。
    if (this.queueInflight !== undefined) return this.queueInflight
    const inflight = this.fetchQueue().then(value => {
      this.queueCache = { at: Date.now(), value }
      this.queueInflight = undefined
      return value
    }).catch(error => {
      // 失败不能把 promise 挂在那里：否则后续调用会一直拿到同一个 rejected promise
      this.queueInflight = undefined
      throw error
    })
    this.queueInflight = inflight
    return inflight
  }

  /** 真正去拉一次队列。 */
  private async fetchQueue(): Promise<{ running: string[]; pending: string[] }> {
    let body: unknown
    try {
      // skipEnsure: 查队列不该把 ComfyUI 拉起来
      const res = await this.request('/queue', { method: 'GET' }, this.requestTimeoutMs, true)
      if (!res.ok) return { running: [], pending: [] }
      body = await res.json()
    } catch {
      // 离线/超时都当"查不到"，调用方据此显示未知而不是崩
      return { running: [], pending: [] }
    }
    if (body === null || typeof body !== 'object') return { running: [], pending: [] }
    // 解析在 `queue.ts`：空闲回收那边也要读同一份数据，两套解析迟早会漂
    return parseQueue(body)
  }

  /**
   * 提交一份工作流，返回 prompt_id 与**提交时就能看到的警告**。
   *
   * `POST /prompt` 的 **200** 响应里可能带 `node_errors`：ComfyUI 接受了这次提交
   * （有 `prompt_id`、会执行），但某些输出链的参数被判非法，那部分不会产出文件。
   * 早期版本把整个 `node_errors` 扔了，于是只能等十几秒后从"没有产物"倒推原因 ——
   * 现在当场就能说出「节点 6 的 sampler_name 不在候选里」。
   */
  async queuePrompt(workflow: ApiWorkflow): Promise<{ promptId: string; warnings: string[] }> {
    const res = await this.request('/prompt', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: workflow, client_id: this.clientId }),
    })
    if (res.status === 401 || res.status === 403) throw authFailed(this.baseUrl, res.status)
    if (res.status === 400) {
      let body: unknown = null
      try {
        body = await res.json()
      } catch {
        body = null
      }
      throw submitRejected(body)
    }
    if (!res.ok) {
      throw new RunError('submit_rejected', `提交失败：HTTP ${res.status}`, '检查 ComfyUI 日志里的拒绝原因。')
    }
    const parsed: unknown = await res.json()
    const bag = parsed !== null && typeof parsed === 'object'
      ? (parsed as { prompt_id?: unknown; node_errors?: unknown })
      : {}
    const promptId = bag.prompt_id
    if (typeof promptId !== 'string' || promptId === '') {
      throw new RunError('submit_rejected', 'ComfyUI 没有返回 prompt_id。', '确认 ComfyUI 版本支持 POST /prompt。')
    }
    const warnings = describeNodeErrors(bag.node_errors)
    return { promptId, warnings }
  }

  /** 查一次 history：没完成时返回 undefined。 */
  async history(promptId: string): Promise<HistoryEntry | undefined> {
    const res = await this.request(`/history/${encodeURIComponent(promptId)}`, { method: 'GET' }, 30_000)
    // 404 表示"这条记录还没有"（任务没跑完时 history 本来就是空的）—— 返回 undefined 让它继续等。
    // 但 5xx / 401 / 403 不是"没完成"，而是查询本身出了问题。原来一律 return undefined，
    // 于是 poller 会永远认为任务在跑：记录停在 queued，activeCount 虚高，而 ComfyUI 那边
    // 可能早挂了。抛一个**可重试**的错误，让上层按瞬时失败累计，别静默卡死。
    if (res.status === 404) return undefined
    if (res.status === 401 || res.status === 403) throw authFailed(this.baseUrl, res.status)
    if (!res.ok) {
      // 不复用 comfyUnreachable：它的文案是"连不上"，而这里服务明明回了 500 ——
      // 让人去"确认 ComfyUI 在跑"是错的，它活着，是后端或中间层出了问题。
      throw new RunError(
        'comfy_unreachable',
        `ComfyUI 查询失败：/history 返回 ${res.status}`,
        '服务可能正在重启或后端异常。稍后重试；持续失败请看 ComfyUI 控制台日志。',
      )
    }
    const parsed: unknown = await res.json()
    if (parsed === null || typeof parsed !== 'object') return undefined
    const entry = (parsed as Record<string, unknown>)[promptId]
    if (entry === null || typeof entry !== 'object') return undefined
    return entry as HistoryEntry
  }

  /** 取产物字节。 */
  async view(ref: FileRef): Promise<Buffer> {
    const params = new URLSearchParams({
      filename: ref.filename,
      subfolder: ref.subfolder ?? '',
      type: ref.type ?? 'output',
    })
    const res = await this.request(`/view?${params.toString()}`, { method: 'GET' }, 120_000)
    if (!res.ok) throw new RunError('output_unreadable', `取产物失败：HTTP ${res.status}（${ref.filename}）`)
    const array = await res.arrayBuffer()
    if (array.byteLength === 0) throw new RunError('output_unreadable', `产物是空的：${ref.filename}`)
    return Buffer.from(array)
  }

  /**
   * 上传图片到 ComfyUI 的 input 目录。
   *
   * 不手动设 Content-Type：multipart 的 boundary 必须由 fetch 自己生成。
   *
   * @param form - 已装好 `image` 字段的表单。
   */
  async uploadImage(form: FormData): Promise<{ name: string; subfolder: string }> {
    const res = await this.request('/upload/image', { method: 'POST', body: form }, 120_000)
    if (res.status === 401 || res.status === 403) throw authFailed(this.baseUrl, res.status)
    if (!res.ok) {
      throw new RunError('output_unreadable', `图片上传到 ComfyUI 失败：HTTP ${res.status}`, '确认 ComfyUI 版本支持 POST /upload/image。')
    }
    const parsed: unknown = await res.json()
    const bag = parsed !== null && typeof parsed === 'object' ? (parsed as { name?: unknown; subfolder?: unknown }) : null
    const name = typeof bag?.name === 'string' ? bag.name : ''
    if (name === '') throw new RunError('output_unreadable', 'ComfyUI 没有返回文件名。', '检查 /upload/image 的返回格式。')
    return { name, subfolder: typeof bag?.subfolder === 'string' ? bag.subfolder : '' }
  }

  /**
   * 让 ComfyUI 释放显存与模型缓存。
   *
   * 对应界面上的"释放内存"：出完图后主动腾出显存，避免占着不放。
   */
  async free(): Promise<void> {
    const res = await this.request('/free', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ unload_models: true, free_memory: true }),
    }, 20_000)
    if (!res.ok) {
      throw new RunError('comfy_unreachable', `释放内存失败：HTTP ${res.status}`, '确认 ComfyUI 在线且版本支持 POST /free。')
    }
  }

  /** 取消执行（超时收尾必发，否则队列被一条已放弃的任务堵住）。 */
  async interrupt(): Promise<void> {
    try {
      await this.request('/interrupt', { method: 'POST' }, 10_000)
    } catch {
      // 取消失败不该掩盖"超时"这个原始结论
    }
  }
}
