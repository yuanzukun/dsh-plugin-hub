import type { IncomingMessage, ServerResponse } from 'node:http'
import path from 'node:path'

import { ComfyClient, ComfySupervisor } from './shared/comfy/index.js'
import { TerminalBuffer } from './shared/comfy/output-buffer.js'
import { RunRegistry } from './shared/run/registry.js'
import { LogTail } from './shared/comfy/log-tail.js'
import { isAuthorized } from './shared/authz/authorize.js'
import { rootsOf } from './shared/authz/roots.js'
import type { Settings } from './shared/host/config.js'
import type { MaterialSource } from './shared/tools/types.js'
import { resolveSettings } from './shared/host/config.js'
import { resolveLogger } from './shared/host/logger.js'
import { canonical, ensureDir, pluginDataDir, workflowsDir } from './shared/host/paths.js'
import type { HostContext } from './shared/host/types.js'
import { resolveOutputDir } from './shared/host/workspace.js'
import { sessionWorkspaceDir } from './shared/host/workspace.js'
import { probeWorkspace } from './shared/host/workspace.js'
import type { WorkspaceProbe } from './shared/host/workspace.js'
import { AssetIndex } from './components/panel-gallery/server/store/index.js'
import { stopAllWatchers } from './shared/run/index.js'
import * as httpModule from './http/router.js'

/** 路由处理器。 */
export type RouteHandler = (url: URL, res: ServerResponse, req: IncomingMessage) => void | Promise<void>

/**
 * 一个组件的路由表。
 *
 * `exact` 是精确路径；`prefix` 用来承接动态段（`/workflows/<id>` 这种）。
 * 组件的路由随组件 entry 上下线，不由前缀注册那一层决定。
 */
export interface RouteTable {
  exact: Record<string, RouteHandler>
  prefix?: Array<{ base: string; handle: RouteHandler }>
}

/**
 * 跨 entry 共享的运行时。
 *
 * 七个组件是**七条独立的 loader entry**（宿主界面里能看到并单独开关），
 * 但它们共用一份 ComfyUI 客户端、进程托管、资产索引与输出目录 ——
 * 各建一份会重复拉起服务、重复读索引。
 */
export interface Runtime {
  settings: Settings
  client: ComfyClient
  supervisor: ComfySupervisor
  /** ComfyUI 子进程的终端输出（面板读它）。 */
  terminal: TerminalBuffer
  /** 运行注册表：提交后的状态（面板与 comfyui_runs 读它）。 */
  runs: RunRegistry
  index: AssetIndex
  flowDir: string
  outputDir: string
  /** 按会话解析产物目录（多工作区）；拿不到会话信息就回退 outputDir。 */
  resolveOutputDirFor: (agent: unknown) => string
  /** 会话产物目录（已 canonical），相册的授权根要含它。 */
  sessionOutputDirs: Set<string>
  outputSource: 'config' | 'env' | 'workingDirectory' | 'service' | 'cwd' | 'data'
  /** 产物目录是怎么探测出来的（诊断用）。 */
  outputProbe: WorkspaceProbe
  uploadsDir: string
  assertWritable: (dir: string, agent?: unknown) => void
  logger: ReturnType<typeof resolveLogger>
  warn: (message: string) => void
  info: (message: string) => void
  track: (dispose: (() => void) | void) => void
  /** 素材取用面：姿势库与衣装库各自注册自己那一半，工具侧惰性取（不依赖 entry 加载顺序）。 */
  materials?: MaterialSource
  /** 批量导出（相册组件提供；工作流组件的 POST /workflows 调它）。 */
  exportWorkflows?: RouteHandler
  /** 各工具 entry 的注册结果（供 /config 展示）。 */
  tools: { registered: string[]; failed: Array<{ name: string; message: string }>; skipped: string[] }
}

/** 组件启用状态：由配置的 disabledComponents 推导。 */
export function componentStateOf(rt: Runtime): Record<string, boolean> {
  const disabled = new Set(rt.settings.disabledComponents)
  // 加组件时**必须**在这里补一行：漏了的话 `/config` 的 components 里没有这个键，
  // 前端 `enabled[x] !== false` 恒真 → 被关掉的页签照样显示，点进去 404。
  // 这个坑踩过三次（先是 workflow，再是 tags，第三次是 poses；第四次是 costumes —— 被下面那条检查当场抓住）。
  // `tests/arch.mjs` 现在会拿 Workbench 的 TABS 与本函数的键做比对，漏了直接红。
  return {
    'panel.gallery': !disabled.has('panel.gallery'),
    'panel.workflow': !disabled.has('panel.workflow'),
    'panel.tags': !disabled.has('panel.tags'),
    'panel.poses': !disabled.has('panel.poses'),
    'panel.costumes': !disabled.has('panel.costumes'),
    'panel.terminal': !disabled.has('panel.terminal'),
    'tool.generate': !disabled.has('tool.generate'),
    'tool.workflow-edit': !disabled.has('tool.workflow-edit'),
    'tool.danbooru': !disabled.has('tool.danbooru'),
  }
}

/**
 * 共享状态的容器。
 *
 * 每条组件 entry 是一个独立 bundle，esbuild 会把本模块各内联一份 —— 模块级变量
 * 在多个 bundle 之间**不共享**。曾因此踩坑：gallery 注册的路由在它自己的副本里，
 * workflow 的 prefix handler 看不到，`/config`、`/workflows` 全 404。
 *
 * 共享状态挂在 `ctx.root` 的属性槽上（见 `sharedOf`），不用 globalThis ——
 * 宿主模块加载器下各 bundle 的 globalThis 同样不共享。
 */
interface Shared {
  current: Runtime | undefined
  refs: number
  tables: Map<string, RouteTable>
  /** HTTP 前缀是否已注册（跨 bundle 共享，避免重复注册被宿主拒绝）。 */
  httpMounted: boolean
  /** 最近一次 acquire 的调用方 ctx：注册类操作要用它，而不是创建者的。 */
  currentCaller?: HostContext
}

const SHARED_PROP = '__dshComfyuiWorkbench'

/**
 * 取共享状态。
 *
 * 关键：锚点是 **ctx.root**，不是 entry 自己的 ctx，也不用 globalThis。
 * 已由真实 cordis 4.0.5 实测：每条 entry 的 ctx 是 `parent.extend({ fiber })` 出来的
 * 独立对象（兄弟之间不共享自有属性），而 globalThis 在宿主的模块加载器下同样不共享。
 * 只有 `ctx.root` 是所有 entry 共同的原点。
 */
function sharedOf(ctx: HostContext): Shared {
  // cordis 里每条 entry 的 ctx 是 `parent.extend({ fiber })` 出来的**独立对象**，
  // 兄弟之间不共享自有属性 —— 挂在 ctx 上等于各建一份（已由真实 cordis 实测确认）。
  // `ctx.root` 是所有 entry 共同的原点，只有它指向同一个对象。
  const anchor = ((ctx as unknown as { root?: unknown }).root ?? ctx) as Record<string, Shared | undefined>
  let slot = anchor[SHARED_PROP]
  if (slot === undefined) {
    slot = { current: undefined, refs: 0, tables: new Map(), httpMounted: false }
    anchor[SHARED_PROP] = slot
  }
  return slot
}

/** 挂载一个组件的路由。 */
export function mountRoutes(ctx: HostContext, componentId: string, table: RouteTable): () => void {
  const tables = sharedOf(ctx).tables
  tables.set(componentId, table)
  return () => { tables.delete(componentId) }
}

/** 取出当前所有组件的路由，合成一张表（后挂的覆盖先挂的同名路径）。 */
export function mergedRoutes(ctx: HostContext): RouteTable {
  const exact: Record<string, RouteHandler> = {}
  const prefix: Array<{ base: string; handle: RouteHandler }> = []
  for (const table of sharedOf(ctx).tables.values()) {
    Object.assign(exact, table.exact)
    if (table.prefix !== undefined) prefix.push(...table.prefix)
  }
  return { exact, prefix }
}

/**
 * 挂载 HTTP 前缀（幂等）。
 *
 * 前缀只该注册一次；具体路径由各组件 entry 自己挂进路由表，
 * 关掉组件时它那份路由跟着消失，前缀本身不反复注册。
 */
export function ensureHttp(ctx: HostContext, rt: Runtime): void {
  const shared = sharedOf(ctx)
  if (shared.httpMounted) return

  const server = ctx.get?.('webServer') as { register?: (route: unknown) => (() => void) | void } | undefined
  if (server === undefined || typeof server.register !== 'function') {
    rt.warn('[comfyui-workbench] 拿不到 webServer 服务，面板接口未注册。')
    return
  }
  const { createDispatch, PREFIX } = httpModule
  try {
    const dispose = server.register({ kind: 'prefix', path: PREFIX, handler: createDispatch(ctx) })
    // 只有真的注册成功才置位 —— 先置位再注册会让热重载后永久跳过注册。
    shared.httpMounted = true
    if (typeof dispose === 'function' && typeof ctx.effect === 'function') {
      ctx.effect(() => () => {
        // 卸载时复位：下次 apply 还要重新注册，否则重载后面板 API 静默消失。
        shared.httpMounted = false
        dispose()
      }, 'comfyui-workbench: http prefix')
    }
    rt.info(`[comfyui-workbench] API 就绪：${PREFIX}`)
  } catch (error) {
    // 热重载时前缀已存在：沿用现有的 handler（它查的是 ctx 上的那张表）。
    // 这里必须吞掉 —— 抛出去会让整条 entry 的 apply 中断，路由一条都挂不上。
    const message = error instanceof Error ? error.message : String(error)
    if (!message.includes('duplicate prefix route')) throw error
    rt.info('[comfyui-workbench] HTTP 前缀已存在（重载），沿用现有实例')
  }
}

/**
 * 取运行时（首次调用时创建，之后复用）。
 *
 * 引用计数：各条 entry 各自 acquire，最后一个 release 时才真正销毁 ——
 * 否则先卸载的那条会把别人还在用的 supervisor 一起关掉。
 *
 * 重建时机：只在「上一轮已全卸载」（`current === undefined`）时重建。
 * 曾想按 fiber 是否失效来判断，但 cordis 4.0.5 的 Fiber 只有 uid / state、
 * 没有 `active`，那个判据恒不成立（复审实测）。真正的兜底是引用计数配对
 * （core 也 release）+ 全卸载后重置前缀状态。
 */
export function acquire(ctx: HostContext, config: unknown): Runtime {
  const shared = sharedOf(ctx)
  shared.refs += 1
  shared.currentCaller = ctx
  if (shared.current !== undefined) return shared.current
  // 走到这里说明上一轮已经全卸载（current 为 undefined）：前缀状态一并复位。
  // 否则新的一轮会误判"前缀已注册"而跳过注册，靠旧 handler 支撑 —— 能跑但状态是错的。
  shared.httpMounted = false
  shared.current = create(ctx, config)
  return shared.current
}

/** 释放；计数归零才销毁。 */
export function release(ctx: HostContext): void {
  const shared = sharedOf(ctx)
  // 退出前把攒着的记录落盘：只有 1 秒防抖 + unref 的话，最后一批必丢
  shared.current?.runs.flush()
  shared.refs -= 1
  if (shared.refs > 0 || shared.current === undefined) return
  shared.current.supervisor.dispose()
  stopAllWatchers()
  shared.tables.clear()
  shared.current = undefined
  shared.refs = 0
}

function create(ctx: HostContext, config: unknown): Runtime {
  const settings = resolveSettings(config, process.env)
  const logger = resolveLogger(ctx, 'comfyui-workbench')
  const warn = (message: string): void => { logger?.warn?.(message) }
  const info = (message: string): void => { logger?.info?.(message) }

  const flowDir = settings.workflowsDir ?? workflowsDir()
  const uploadsDir = settings.uploadsDir ?? `${pluginDataDir()}/uploads`
  ensureDir(uploadsDir)

  const { guess, probe } = probeWorkspace(ctx)
  const resolved = resolveOutputDir(settings.outputDir, guess, pluginDataDir())
  const outputDir = resolved.dir
  ensureDir(outputDir)

  // 启动期定下的 outputDir 是"没有会话信息时"的默认值。多工作区场景下
  // 每次调用都要问一次会话级目录 —— registry 只知道有哪些工作区，不知道
  // 当前这个会话属于哪个，靠它猜会把产物丢进不相关的工作区。
  // 会话产物目录登记表：相册的授权根也要含它，否则产物落对了却读不出来。
  const sessionOutputDirs = new Set<string>()

  const resolveOutputDirFor = (agent: unknown): string => {
    if (settings.outputDir !== null) return settings.outputDir
    const sessionDir = sessionWorkspaceDir(ctx, agent)
    if (sessionDir === undefined) return outputDir
    const dir = path.join(sessionDir, 'comfyui-output')
    ensureDir(dir)
    sessionOutputDirs.add(canonical(dir))
    return dir
  }

  // 终端面板的数据源：supervisor 往里写，面板路由从这里读。
  // 放在 runtime 上而不是组件里 —— 进程是 runtime 拉起的，组件可能还没加载。
  const terminal = new TerminalBuffer(2000)
  // 注册表挂 runtime 上（不是模块级）：多 entry 各一份 bundle，模块级会分裂
  const runs = new RunRegistry(outputDir)

  const supervisor = new ComfySupervisor({
    baseUrl: settings.baseUrl,
    autoDetect: settings.autoDetect,
    autoStart: settings.autoStart,
    ...(settings.startCommand.length === 0 ? {} : { startCommand: settings.startCommand }),
    readyTimeoutMs: settings.readyTimeoutMs,
    idleShutdownMs: settings.idleShutdownMs,
    logger,
    onOutput: (stream, text) => terminal.push(stream, text),
  })

  // 外部实例（Desktop 自己起的那些）拿不到 stdout，只能读它写的日志文件。
  // 定时拉一次：成本只是 stat + 可能的增量读，比"让用户干等"划算得多。
  const logTailRef: { current: LogTail | undefined } = { current: undefined }
  const pumpLog = (): void => {
    // 自己拉起的进程已经把 stdout 接过来了；ComfyUI 的 logger 同时挂 StreamHandler 与
    // FileHandler，两边都读就是每行两份。所以只在"不是我们拉起的"时才看日志。
    if (supervisor.status().managed) return
    const installDir = supervisor.installDirOf()
    const file = LogTail.locate(installDir)
    if (file === undefined) return
    if (logTailRef.current === undefined || logTailRef.current.path !== file) {
      logTailRef.current = new LogTail(file)
      terminal.push('out', `—— 以下来自日志文件 ${file} ——\n`)
    }
    const chunk = logTailRef.current.poll()
    if (chunk !== '') terminal.push('out', chunk)
  }
  // 不依赖 autoStart：读日志文件没有副作用，外部实例恰恰最常见
  const logTimer = setInterval(pumpLog, 2_000)
  logTimer.unref?.()
  pumpLog()
  // 热重载会重新 create；不清掉的话每个旧实例都留一条定时器往死掉的 buffer 里 push
  if (typeof ctx.effect === 'function') {
    ctx.effect(() => () => { clearInterval(logTimer) }, 'runtime: log pump')
  }

  const client = new ComfyClient({
    baseUrl: settings.baseUrl,
    headers: settings.headers,
    requestTimeoutMs: settings.timeoutMs,
    ensure: () => supervisor.ensureReady(),
  })

  const index = settings.indexFile === null ? new AssetIndex() : new AssetIndex(settings.indexFile)

  const rootsSettings = { ...settings, resolvedOutputDir: outputDir }
  const assertWritable = (dir: string, agent?: unknown): void => {
    const roots = rootsOf(ctx, rootsSettings)
    if (roots.length === 0) return
    // 会话级工作区可能还没登记进 registry（新开的工作区、或 registry 缓存过期）——
    // 只按 defaultDirectory 判的话，产物落在正确的工作区里却会被拦下来。
    if (isAuthorized(dir, roots)) return
    // 只放行 <会话工作区>/comfyui-output 这一棵，不把整个会话 cwd 变成授权面 ——
    // 会话 cwd 可以是盘根（实测设成 D:\ 就等于整盘放行），那样这道闸就形同虚设。
    const sessionDir = sessionWorkspaceDir(ctx, agent)
    if (sessionDir !== undefined) {
      // 与 rootsOf 同语义：目标路径在 isAuthorized 里会先 realpath，
      // 这里不规范化的话，工作区是 junction / 符号链接时产物目录会把自己拒掉。
      const sessionOutput = canonical(path.join(sessionDir, 'comfyui-output'))
      sessionOutputDirs.add(sessionOutput)
      if (isAuthorized(dir, [...roots, { path: sessionOutput, label: 'session-output', kind: 'workspace' }])) return
    }
    throw new Error(`输出目录不在授权范围内：${dir}。请在配置的 assetRoots 里加上它，或改用 workspace 内的目录。`)
  }

  // track 用调用方的 ctx：创建者 entry 卸载后，rt.ctx 已失效，再挂 effect 会抛
  // `cannot create effect on inactive context`。
  const track = (dispose: (() => void) | void): void => {
    if (typeof dispose !== 'function') return
    const owner = sharedOf(ctx).currentCaller ?? ctx
    if (typeof owner.effect === 'function') owner.effect(() => dispose, 'comfyui-workbench: disposer')
  }

  info(`[comfyui-workbench] 运行时就绪：产物 ${outputDir}（来源 ${resolved.source}）`)

  return {
    settings,
    client,
    supervisor,
    terminal,
    runs,
    index,
    flowDir,
    outputDir,
    resolveOutputDirFor,
    sessionOutputDirs,
    outputSource: resolved.source,
    outputProbe: probe,
    uploadsDir,
    assertWritable,
    logger,
    warn,
    info,
    track,
    tools: { registered: [], failed: [], skipped: [] },
  }
}
