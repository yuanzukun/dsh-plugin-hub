import type { Settings } from '../../../shared/host/config.js'
import { sendJson } from '../../../shared/http/respond.js'

/**
 * `GET /comfyui-workbench/api/config`：界面需要的只读配置。
 *
 * 只暴露路径与地址，不暴露 headers 之类的凭据。
 */
export function createConfigHandler(deps: {
  settings: Settings
  outputDir: string
  workflowsDir: string
  /** 产物目录是怎么定下来的：配置 / 工作区 / 数据目录。 */
  outputSource?: 'config' | 'env' | 'workingDirectory' | 'service' | 'cwd' | 'data'
  /** 产物目录探测的取证记录（诊断用：看得出工作区为什么没识别到）。 */
  workspaceProbe?: Record<string, unknown>
  /** 惰性取诊断信息（工具在路由之后才注册，构造时求值会拿到空表）。 */
  getDiagnostics?: () => {
    components?: Record<string, boolean>
    tools?: { registered: string[]; failed: Array<{ name: string; message: string }>; skipped: string[] }
  }
}): (url: URL, res: import('node:http').ServerResponse) => void {
  return (_url, res) => {
    const diagnostics = deps.getDiagnostics?.() ?? {}
    sendJson(res, 200, {
      ok: true,
      config: {
        baseUrl: deps.settings.baseUrl,
        outputDir: deps.outputDir,
        outputSource: deps.outputSource ?? 'config',
        workflowsDir: deps.workflowsDir,
        runMode: deps.settings.runMode,
        returnImages: deps.settings.returnImages,
        timeoutMs: deps.settings.timeoutMs,
        ...(deps.workspaceProbe === undefined ? {} : { workspaceProbe: deps.workspaceProbe }),
        ...(diagnostics.components === undefined ? {} : { components: diagnostics.components }),
        ...(diagnostics.tools === undefined ? {} : { tools: diagnostics.tools }),
      },
    })
  }
}
