import fs from 'node:fs'
import path from 'node:path'

import { MEDIA_EXTS, mediaKindOf, toListItem } from '../scan/index.js'
import type { ImageRecord, ListItem } from '../scan/index.js'
import { foldPathCase } from '../../../../shared/host/paths.js'

import { isAuthorized } from './authorize.js'
import { dedupeItems } from './dedupe.js'
import type { DedupedItem } from './dedupe.js'
import { thumbPathFor } from './thumbs.js'
import { trashOne } from './trash.js'
import { isInsideTrash } from './trash.js'
import type { RootEntry } from './roots.js'
import { scanRoot } from './scan-cache.js'
import type { ScanSettings } from './scan-cache.js'

/** 列表查询参数（由 HTTP 层解析后传入，service 不认 URL）。 */
export interface ItemQuery {
  /** 根目录过滤：'all' 表示全部。 */
  root: string
  /** 关键词（已小写）。 */
  q: string
  /** 是否包含非生成图。 */
  all: boolean
  /** 是否跳过扫描缓存。 */
  refresh: boolean
  /** 是否合并同图副本。 */
  dedupe: boolean
  offset: number
  limit: number
  /** 按工作流 id 精确过滤（来源卡片的 sidecar）。 */
  workflow?: string
  /** 按底模过滤（子串：用户记得 `sd_xl`，不记得完整文件名）。 */
  checkpoint?: string
  /** 按方向过滤：landscape / portrait / square。 */
  aspect?: '' | 'landscape' | 'portrait' | 'square'
}

/**
 * 宽高比分类。
 *
 * 5% 容差：`1536×1536` 是方图，`1536×1500` 在视觉上同样是方图 —— 严格相等会把
 * 后者判成横图，用户筛"方图"时就少了一张。
 */
export function aspectOf(width: number | undefined, height: number | undefined): '' | 'landscape' | 'portrait' | 'square' {
  if (width === undefined || height === undefined || width <= 0 || height <= 0) return ''
  const ratio = width / height
  // 用区间比较而不是 `Math.abs(ratio - 1) <= 0.05`：后者在边界上是浮点不对称的 ——
  // `1050×1000`（1.05）算出来是 1.050000000000000044，会被判成横图，
  // 而转 90° 的 `1000×1050`（0.952381）却是方图。同一个形状不该因为方向翻档。
  if (ratio >= 0.95 && ratio <= 1.05) return 'square'
  return ratio > 1 ? 'landscape' : 'portrait'
}

/** 一页列表结果。 */
export interface ItemPage {
  total: number
  merged: boolean
  offset: number
  limit: number
  truncated: boolean
  items: Array<ListItem | DedupedItem>
}

/** 查询失败：根目录不在白名单内。 */
export class UnknownRootError extends Error {
  constructor() {
    super('这个根目录不在资产库的白名单里。')
    this.name = 'UnknownRootError'
  }
}

/**
 * 查一页资产。
 *
 * 过滤顺序刻意如此：先按扫描阶段的分类型过滤掉普通图片，再读元数据 ——
 * 默认（只看生成图）就不该为整目录的截图付元数据解析成本。
 *
 * @param roots - 授权根目录。
 * @param query - 查询参数。
 */
export function queryItems(
  roots: readonly RootEntry[],
  settings: ScanSettings,
  query: ItemQuery,
): ItemPage {
  if (roots.length === 0) {
    return { total: 0, merged: false, offset: query.offset, limit: query.limit, truncated: false, items: [] }
  }

  const targets = query.root === 'all' ? roots : roots.filter(root => root.path === query.root)
  if (targets.length === 0) throw new UnknownRootError()

  let truncated = false
  const merged: Array<{ file: ImageRecord; label: string }> = []
  // 同一个文件只能出现一次：根目录之间可能是父子关系（工作区与其下的 comfyui-output），
  // 各扫一遍就会把同一张图收两遍，再经同图合并变成莫名其妙的"副本 2"。
  const seenPaths = new Set<string>()
  for (const root of targets) {
    const scanned = scanRoot(root.path, settings, query.refresh)
    // 只有「影响本次结果」的截断才算数：默认只看生成图，普通图片被截断不该报提示。
    truncated = truncated || scanned.truncated
    for (const file of scanned.files) {
      // 与授权校验 / 根去重共用同一套折叠规则，别再各写一份。
      const key = foldPathCase(file.path)
      if (seenPaths.has(key)) continue
      seenPaths.add(key)
      merged.push({ file, label: root.label })
    }
  }
  merged.sort((a, b) => b.file.mtime - a.file.mtime)

  const items: ListItem[] = []
  for (const { file, label } of merged) {
    if (!query.all && file.generated !== true) continue
    const item = toListItem(file, label)
    // 兜底：探测到内嵌块但完整解析失败时，这里仍会把它挡在「仅生成图」之外。
    if (!query.all && item.hasMeta !== true) continue
    if (query.q !== '') {
      // 检索面：文件名的字面量之外，还要能按**底模**与**工作流**找。
      // 用户记得「那张 SDXL 出的」「那个放大工作流跑的」，但不记得文件名 ——
      // 只搜 name / prompt 时这两种意图都落空。
      const haystack = `${item.name} ${item.prompt ?? ''} ${item.negativePrompt ?? ''} ${item.checkpoint ?? ''} ${item.workflowId ?? ''}`.toLowerCase()
      if (!haystack.includes(query.q)) continue
    }
    // 结构化筛选：与 `q` 分开 —— `q` 是"我记得点什么"，这些是"我只要这一类"
    if (query.workflow !== undefined && query.workflow !== '' && item.workflowId !== query.workflow) continue
    if (query.checkpoint !== undefined && query.checkpoint !== ''
      && (item.checkpoint ?? '').toLowerCase().includes(query.checkpoint.toLowerCase()) === false) continue
    if (query.aspect !== undefined && query.aspect !== '') {
      // **未知尺寸不参与方向筛选**：`includeBare` 打开时非生成图没有 width/height，
      // 把它们一律排掉会让"包含非生成图"这个开关看起来坏了。
      const shape = aspectOf(item.width, item.height)
      if (shape !== '' && shape !== query.aspect) continue
    }
    items.push(item)
  }

  const visible = query.dedupe ? dedupeItems(items) : items
  return {
    total: visible.length,
    merged: query.dedupe,
    offset: query.offset,
    limit: query.limit,
    truncated,
    items: visible.slice(query.offset, query.offset + query.limit),
  }
}

/** 单次删除的结果。 */
export interface DeleteResult {
  target: string
  removed: string[]
  /** 软删除时：这份现在在回收站的哪个目录里（`/trash/restore` 要它）。 */
  trashed?: string
  error?: string
  code?: string
  /** 非致命问题（例如 sidecar 没能一起移走）：操作算成功，但用户该知道。 */
  warning?: string
}

/**
 * 物理删除一张图片及其附属文件（sidecar + 缩略图）。
 *
 * 图片本身删失败就立即返回错误；sidecar 与缩略图是附属品，删不掉也不该掩盖
 * "图片已删"的事实 —— 所以它们各自独立 try。
 *
 * @param target - 图片绝对路径。
 * @param roots - 授权根目录。
 */
export function deleteOne(
  target: string,
  roots: readonly RootEntry[],
  options: { soft?: boolean } = {},
): DeleteResult {
  if (!isAuthorized(target, roots)) {
    return { target, removed: [], error: '这个路径不在资产库的白名单里。', code: 'forbidden' }
  }
  if (!MEDIA_EXTS.has(path.extname(target).toLowerCase())) {
    return { target, removed: [], error: '只能删除资产库里的媒体文件（图片 / 视频 / 音频）。', code: 'not-an-image' }
  }

  let stat: fs.Stats
  try {
    stat = fs.statSync(target)
  } catch {
    return { target, removed: [], error: '文件已经不在了。', code: 'missing' }
  }
  if (!stat.isFile()) {
    return { target, removed: [], error: '路径不是文件。', code: 'not-a-file' }
  }

  // 软删除：移进 `<root>/.trash/`。产物旁边的 sidecar 是"再来一张"的唯一凭据，
  // 而面板上删除是一次点击 —— 至少要能撤回一次。物理删除仍然保留（清空回收站时走它）。
  if (options.soft === true) {
    // 已经在回收站里的不能再删：会在 `.trash` 里再套一层，之后恢复也只能恢复到
    // `.trash` 内 —— 那张图就再也看不见了
    if (isInsideTrash(target, roots)) {
      return { target, removed: [], error: '这张图已经在回收站里了。', code: 'in-trash' }
    }
    const result = trashOne(target, roots)
    if (result.ok !== true) return { target, removed: [], error: result.error, code: result.code }
    return {
      target,
      // `removed` 里放原路径：前端按它算"要从列表里撤掉哪些卡片"。
      // 软删除时文件没消失（在 `.trash` 里），但对图库来说就是"移除" ——
      // 只回 `trashed` 的话前端会算出一个空集合，卡片留在原地、计数却 -1。
      removed: [target, ...(result.sidecarMoved ? [`${target}.json`] : [])],
      trashed: result.dir,
      ...(result.sidecarMoved ? {} : { warning: '参数记录（sidecar）没能一起移进回收站，原处留了一个孤儿 .json。' }),
    }
  }

  const sidecar = `${target}.json`
  const thumb = thumbPathFor(target, stat)
  const removed: string[] = []

  try {
    fs.unlinkSync(target)
    removed.push(target)
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    return { target, removed, error: `删除失败：${message}`, code: 'delete-failed' }
  }

  try {
    if (fs.existsSync(sidecar)) {
      fs.unlinkSync(sidecar)
      removed.push(sidecar)
    }
  } catch {
    // 保留孤儿 sidecar：下次扫描不会再把它当成图片列出
  }

  try {
    fs.unlinkSync(thumb)
  } catch {
    // 没生成过（或已被清理）就不用管
  }

  return { target, removed }
}

/** 批量删除结果。 */
export interface BatchDeleteResult {
  removed: string[]
  /** 软删除时：每份被移进的回收站目录。 */
  trashed?: string[]
  failed: Array<{ path: string; error: string; message: string }>
}

/**
 * 批量删除：逐个物理删除，部分失败照实汇报，不整体回滚。
 *
 * @param paths - 待删路径。
 * @param roots - 授权根目录。
 */
export function deleteMany(
  paths: readonly string[],
  roots: readonly RootEntry[],
  options: { soft?: boolean } = {},
): BatchDeleteResult {
  const removed: string[] = []
  const trashed: string[] = []
  const failed: BatchDeleteResult['failed'] = []
  for (const one of paths) {
    const result = deleteOne(one, roots, options)
    if (result.error !== undefined) {
      failed.push({ path: one, error: result.code ?? 'unknown', message: result.error })
    } else {
      removed.push(...result.removed)
      if (result.trashed !== undefined) trashed.push(result.trashed)
    }
  }
  return { removed, ...(trashed.length === 0 ? {} : { trashed }), failed }
}

/** 批量导出工作流的中间产物。 */
export interface WorkflowExport {
  entries: Array<{ name: string; data: Buffer }>
  skipped: number
}

/**
 * 收集选中图片的工作流，准备打包。
 *
 * 名字冲突时加序号后缀而不是覆盖：用户选的两张图可能同名不同目录。
 *
 * @param paths - 选中路径。
 * @param roots - 授权根目录。
 * @param readFullSidecar - 读完整元数据的函数（注入，避免 service 直接依赖 scan 的缓存实现）。
 */
export function collectWorkflows(
  paths: readonly string[],
  roots: readonly RootEntry[],
  readFullSidecar: (imagePath: string) => Record<string, unknown> | undefined,
): WorkflowExport {
  const entries: Array<{ name: string; data: Buffer }> = []
  const used = new Set<string>()
  let skipped = 0

  for (const one of paths) {
    if (!isAuthorized(one, roots)) {
      skipped += 1
      continue
    }
    const meta = readFullSidecar(one)
    const workflow = meta?.workflow
    if (workflow === undefined || workflow === null) {
      skipped += 1
      continue
    }
    const base = path.basename(one, path.extname(one))
    let name = `${base}.workflow.json`
    for (let i = 2; used.has(name); i += 1) name = `${base}-${i}.workflow.json`
    used.add(name)
    entries.push({ name, data: Buffer.from(`${JSON.stringify(workflow, null, 2)}\n`, 'utf8') })
  }

  return { entries, skipped }
}
