import { useEffect, useRef, useState } from 'react'

import { Icon } from '../../../client/icons.js'
import { API } from '../../../client/api.js'
import { runAction } from '../../../client/actions.js'
import { readPref, writePref } from '../../../shared/host/prefs.js'
import { download, fetchRunStatus } from '../../../client/api.js'
import { useGalleryData } from './hooks/useGalleryData.js'
import type { Translate } from '../../../client/i18n.js'
import { isNsfw } from '../../../shared/gallery/nsfw.js'
import CSS from './styles.css'
import type { ActionKind, GalleryItem } from '../../../client/types.js'
import { BulkBar } from './BulkBar.js'
import { Card } from './Card.js'
import { ConfirmBulkRemove, ConfirmRemove } from './Confirm.js'
import { Lightbox } from './Lightbox.js'
import { Toolbar } from './Toolbar.js'

export interface GalleryProps {
  t: Translate
  visible: boolean
  /** 嵌在 better-sidebar 的页签里时为 true：此时不显示"在侧边栏打开"。 */
  embedded?: boolean
  goToConversation: () => void
  openSidebar: () => boolean
}

/** 轮询间隔：与后端 `sweepRun` 的节奏对齐，比它更快没有意义。 */
const POLL_MS = 1500
/**
 * 最多轮多少次（5 分钟）。
 *
 * `found:false`（运行记录被注册表 trim 掉、或插件重启过）时不能无限轮询，
 * 否则每 1.5 秒一个请求打到天荒地老，而且永远没有结论。
 */
const POLL_MAX_TICKS = 200

/**
 * 资产库主视图。
 *
 * 只做编排：筛选状态、多选、动作分发、几个弹层。数据加载在 useGalleryData，
 * 动作实现在 actions.ts，展示细节在各自组件里。
 */
export function Gallery({ t, visible, embedded, goToConversation, openSidebar }: GalleryProps): React.ReactElement {
  const [root, setRoot] = useState('all')
  const [query, setQuery] = useState('')
  const [includeBare, setIncludeBare] = useState(false)
  const [mergeDuplicates, setMergeDuplicates] = useState(true)
  /**
   * 隐藏 NSFW 内容。默认关：藏不藏是用户的选择，不该替人决定。
   *
   * **必须持久化**。切换页签会把本组件卸载，用普通 `useState(false)` 的话一离开资产库
   * 就悄悄变回显示 —— 在有人路过时这很要命。存在本机 localStorage 而不是服务端 settings：
   * 这类开关是"这台机器上不长眼"的隐私边界，不该跟着账号同步到别的机器。
   */
  const [hideNsfw, setHideNsfw] = useState(() => readPref('gallery.hideNsfw', false))
  const [activePath, setActivePath] = useState<string | null>(null)
  const [busy, setBusy] = useState('')
  const [pendingDelete, setPendingDelete] = useState<GalleryItem | null>(null)
  const [selecting, setSelecting] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(() => new Set())
  const [bulkConfirmOpen, setBulkConfirmOpen] = useState(false)
  /** 正在盯的运行（提交后轮询它的状态）。 */
  const [watching, setWatching] = useState<string | null>(null)

  const gallery = useGalleryData({ visible, root, query, includeBare, mergeDuplicates })
  const { items, itemsRef, total, truncated, loading, loadingMore, hasMore, notice, setNotice, reload } = gallery

  /**
   * 最新的 `reload`。
   *
   * `useGalleryData` 每次都返回新函数，而轮询 effect 只依赖 `watching` —— 直接闭包
   * 捕获的话，用户在轮询期间改了筛选/搜索，完成时 `reload(true)` 会按**旧参数**拉数据，
   * 列表与当前筛选对不上。走 ref 每次取当前那个。
   */
  const reloadRef = useRef(reload)
  reloadRef.current = reload

  // NSFW 过滤只作用在渲染层：数据仍全量在内存里，切回去立刻可见，不用重新拉。
  const nsfwFlags = items.map(item => isNsfw({
    name: item.name,
    prompt: item.prompt,
    negativePrompt: item.negativePrompt,
    checkpoint: item.checkpoint,
  }))
  const hiddenNsfwCount = nsfwFlags.filter(Boolean).length
  const visibleItems = hideNsfw ? items.filter((_, i) => nsfwFlags[i] !== true) : items

  // 灯箱按路径寻址：删除或刷新后列表变了，也能重新定位到正确的那张。
  // **寻址与翻页都用 visibleItems**：用全量列表的话，隐藏 NSFW 之后按 → 会翻到看不见的图，
  // 计数也会显示成「第 30 张 / 共 9 张」。
  const activeIndex = activePath === null ? -1 : visibleItems.findIndex(entry => entry.path === activePath)
  const activeItem = activeIndex >= 0 ? (visibleItems[activeIndex] ?? null) : null

  const stepActive = (delta: number): void => {
    if (activeIndex < 0 || visibleItems.length === 0) return
    // 首尾相接：最后一张按 → 回到第一张。
    const next = (activeIndex + delta + visibleItems.length) % visibleItems.length
    const target = visibleItems[next]
    if (target !== undefined) setActivePath(target.path)
  }

  // 打开隐藏开关时，正在看的那张可能被判成 NSFW —— 别停在一个已经不可见的项上。
  useEffect(() => {
    if (hideNsfw && activePath !== null && activeItem === null) setActivePath(null)
  }, [hideNsfw, activePath, activeItem])

  useEffect(() => {
    if (activePath === null) return undefined
    const onKey = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') {
        // 确认层开着时，Esc 只关确认层：别把底下的灯箱一起关掉。
        if (pendingDelete !== null) setPendingDelete(null)
        else setActivePath(null)
        return
      }
      if (pendingDelete !== null) return
      if (event.key === 'ArrowLeft') {
        event.preventDefault()
        stepActive(-1)
      } else if (event.key === 'ArrowRight') {
        event.preventDefault()
        stepActive(1)
      }
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [activePath, pendingDelete, items])

  const handlers = { goToConversation }

  /**
   * 以这张图的参数再跑一遍（图作为输入）。
   *
   * 原来这里是"让用户挑一个吃图的工作流，只传图路径" —— 那样 prompt / seed /
   * 步数 / 模型全走默认值，等于把原图的一半信息丢了。现在服务端读 sidecar 里的
   * `workflowId` + `vars` 原样重跑，只把图片输入换成这一张。
   *
   * **seed 会被换掉**（服务端做的）：换了参考图还沿用原 seed，等于「同一张图 +
   * 同一个 seed」，而这条链路是位级确定的 —— 每次点都得到一模一样的一张。
   */
  const rerunAsInput = async (item: GalleryItem): Promise<void> => {
    try {
      const res = await fetch(`${API}/rerun`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ path: item.path, asInput: true }),
      })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json() as { ok?: unknown; message?: unknown; error?: unknown; promptId?: unknown }
      if (data.ok !== true) throw new Error(String(data.message ?? data.error ?? '重跑失败'))
      setNotice({ kind: 'ok', text: t('useAsInputStarted').replace('{id}', item.name) })
      // 拿到 promptId 就盯住它：提交后什么都不显示，用户不知道到底出没出图
      if (typeof data.promptId === 'string' && data.promptId !== '') setWatching(data.promptId)
    } catch (error) {
      setNotice({ kind: 'err', text: error instanceof Error ? error.message : String(error) })
    }
  }

  /**
   * 盯一条刚提交的运行。
   *
   * `state` 收敛成 `done` / `failed` / `unknown` 就停；`unknown` 也要**刷新列表** ——
   * `wait_timeout` 与网络瞬断都会转 unknown，而那种情况下图往往已经落盘了。
   *
   * 三条防呆：
   * - **有上限**：`found:false`（注册表被 trim 掉、或插件重启过）时不能无限轮询，
   *   超过 `POLL_MAX_TICKS` 就停并提示。否则每 1.5 秒一个请求打到天荒地老。
   * - **用最新的 reload**：轮询期间用户可能改了筛选/搜索，闭包捕获的旧 `reload`
   *   会按旧参数拉数据，列表与当前筛选不符。走 ref 取当前那个。
   * - 单次查询失败不算数，等下一次。
   */
  useEffect(() => {
    if (watching === null) return undefined
    let ticks = 0
    const timer = setInterval(() => {
      ticks += 1
      if (ticks > POLL_MAX_TICKS) {
        clearInterval(timer)
        setWatching(null)
        setNotice({ kind: 'err', text: t('rerunUnknown') })
        return
      }
      void fetchRunStatus(watching)
        .then(status => {
          if (!status.found) return
          if (status.state === 'done') {
            setWatching(null)
            setNotice({ kind: 'ok', text: t('rerunDone') })
            reloadRef.current(true)
            return
          }
          if (status.state === 'failed') {
            setWatching(null)
            setNotice({ kind: 'err', text: t('rerunFailed').replace('{message}', status.error?.message ?? status.state) })
            return
          }
          if (status.state === 'unknown') {
            setWatching(null)
            // 图可能已经在盘上了：不刷新的话用户会以为没出图
            reloadRef.current(true)
            setNotice({ kind: 'err', text: t('rerunUnknown') })
          }
        })
        .catch(() => { /* 单次查询失败不算数，下次再试 */ })
    }, POLL_MS)
    return () => clearInterval(timer)
  }, [watching])

  const onAction = (kind: ActionKind, item: GalleryItem): void => {
    // 删除先过确认层，不在这里直接发请求。
    if (kind === 'remove') {
      setPendingDelete(item)
      return
    }
    // 作为输入出图：其余参数照旧、换图 + 换新 seed（服务端读 sidecar，不需要选工作流）
    if (kind === 'useAsInput') {
      const key = `useAsInput:${item.path}`
      if (busy === key) return
      setBusy(key)
      void rerunAsInput(item).finally(() => setBusy(''))
      return
    }
    const key = `${kind}:${item.path}`
    if (busy === key) return
    setBusy(key)
    void runAction(kind, item, t, handlers)
      .then(message => { if (message !== '') setNotice({ kind: 'ok', text: message }) })
      .catch(error => setNotice({ kind: 'err', text: error instanceof Error ? error.message : String(error) }))
      .finally(() => setBusy(''))
  }

  const removeBusyKey = pendingDelete === null ? '' : `remove:${pendingDelete.path}`

  const confirmRemove = async (): Promise<void> => {
    const target = pendingDelete
    if (target === null || busy === `remove:${target.path}`) return
    setBusy(`remove:${target.path}`)
    try {
      // 删除就是彻底删：主项与它的全部副本一起从磁盘移除，不留任何一份。
      const paths = [target.path, ...(target.duplicates ?? [])]
      const res = await fetch(`${API}/delete-many`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paths }),
      })
      let payload: unknown = null
      try {
        payload = await res.json()
      } catch {
        // 非 JSON 错误体：用状态码
      }
      const bag = payload !== null && typeof payload === 'object' ? (payload as Record<string, unknown>) : null
      if (!res.ok || bag === null || bag.ok !== true) {
        throw new Error(typeof bag?.message === 'string' ? bag.message : `删除失败：HTTP ${res.status}`)
      }
      const failures = Array.isArray(bag.failed) ? (bag.failed as Array<{ message?: unknown }>) : []
      const failure = failures[0]
      if (failure !== undefined) throw new Error(typeof failure.message === 'string' ? failure.message : '删除失败')

      const removedSet = new Set(Array.isArray(bag.removed) ? (bag.removed as string[]) : [])
      // 合并项在列表里只占一条，所以总数减一。
      gallery.dropItems(removedSet, 1)
      setActivePath(current => (current !== null && removedSet.has(current) ? null : current))
      setNotice({ kind: 'ok', text: t('removed') })
    } catch (error) {
      setNotice({ kind: 'err', text: error instanceof Error ? error.message : String(error) })
    } finally {
      setBusy('')
      setPendingDelete(null)
    }
  }

  const selectedItems = (): GalleryItem[] => itemsRef.current.filter(entry => selected.has(entry.path))

  const toggleSelect = (item: GalleryItem): void => {
    setSelected(previous => {
      const next = new Set(previous)
      if (next.has(item.path)) next.delete(item.path)
      else next.add(item.path)
      return next
    })
  }

  const exitSelect = (): void => {
    setSelecting(false)
    setSelected(new Set())
    setBulkConfirmOpen(false)
  }

  // 只选看得见的那些：隐藏状态下全选若带上不可见项，一次删除会把它们一并删掉。
  const selectAllShown = (): void => setSelected(new Set(visibleItems.map(entry => entry.path)))
  const selectNone = (): void => setSelected(new Set())

  const bulkExport = async (): Promise<void> => {
    const chosen = selectedItems()
    if (chosen.length === 0) return
    const paths = chosen.map(entry => entry.path)
    setBusy('bulk:export')
    try {
      const res = await fetch(`${API}/workflows`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paths }),
      })
      if (!res.ok) {
        let message = `导出失败：HTTP ${res.status}`
        try {
          const data: unknown = await res.json()
          const bag = data !== null && typeof data === 'object' ? (data as { message?: unknown }) : null
          if (typeof bag?.message === 'string') message = bag.message
        } catch {
          // 非 JSON 错误体
        }
        throw new Error(message)
      }
      const skipped = Number(res.headers.get('X-Workbench-Skipped') ?? '0')
      const blob = await res.blob()
      const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14)
      download(blob, `comfyui-workbench-workflows-${stamp}.zip`)
      const exported = Math.max(0, paths.length - skipped)
      setNotice({
        kind: 'ok',
        text: skipped > 0
          ? t('bulkExportedSkipped').replace('{n}', String(exported)).replace('{m}', String(skipped))
          : t('bulkExported').replace('{n}', String(exported)),
      })
    } catch (error) {
      setNotice({ kind: 'err', text: error instanceof Error ? error.message : String(error) })
    } finally {
      setBusy('')
    }
  }

  const bulkRemove = async (): Promise<void> => {
    const chosen = selectedItems()
    if (chosen.length === 0) return
    const paths: string[] = []
    for (const entry of chosen) {
      paths.push(entry.path)
      for (const extra of entry.duplicates ?? []) paths.push(extra)
    }
    setBusy('bulk:delete')
    try {
      const res = await fetch(`${API}/delete-many`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paths }),
      })
      let payload: unknown = null
      try {
        payload = await res.json()
      } catch {
        // 非 JSON 错误体
      }
      const bag = payload !== null && typeof payload === 'object' ? (payload as Record<string, unknown>) : null
      if (!res.ok || bag === null || bag.ok !== true) {
        throw new Error(typeof bag?.message === 'string' ? bag.message : `删除失败：HTTP ${res.status}`)
      }

      const failures = Array.isArray(bag.failed) ? (bag.failed as Array<{ path?: unknown }>) : []
      const failedSet = new Set(failures.map(entry => String(entry.path ?? '')))
      const chosenPaths = new Set(chosen.map(entry => entry.path))
      // 副本不算条目：总数只按"被删掉的主项"扣。
      const failedPrimary = chosen.filter(entry => failedSet.has(entry.path)).length
      const removedCount = chosen.length - failedPrimary
      const removedPaths = new Set([...chosenPaths].filter(path => !failedSet.has(path)))
      gallery.dropItems(removedPaths, removedCount)

      setActivePath(current => (current !== null && chosenPaths.has(current) ? null : current))
      setNotice({
        kind: failedPrimary > 0 ? 'err' : 'ok',
        text: failedPrimary > 0
          ? t('bulkDeletePartial').replace('{n}', String(removedCount)).replace('{m}', String(failedPrimary))
          : t('bulkDeleted').replace('{n}', String(removedCount)),
      })
      setSelected(new Set())
      setBulkConfirmOpen(false)
    } catch (error) {
      setNotice({ kind: 'err', text: error instanceof Error ? error.message : String(error) })
    } finally {
      setBusy('')
    }
  }

  const openInSidebar = (): void => {
    if (openSidebar() === false) setNotice({ kind: 'err', text: t('noSidebar') })
  }

  const emptyText = query.trim() !== ''
    ? t('emptyFiltered')
    : (hideNsfw && items.length > 0 ? t('emptyAllHidden') : t('empty'))

  return (
    <div className="cfa-root">
      <style>{CSS}</style>
      <Toolbar
        t={t}
        total={total}
        visibleCount={visibleItems.length}
        loadedCount={items.length}
        roots={gallery.roots}
        root={root}
        query={query}
        includeBare={includeBare}
        mergeDuplicates={mergeDuplicates}
        hideNsfw={hideNsfw}
        hiddenNsfwCount={hiddenNsfwCount}
        onToggleNsfw={() => setHideNsfw(value => {
          const next = !value
          writePref('gallery.hideNsfw', next)
          return next
        })}
        selecting={selecting}
        embedded={embedded === true}
        onQuery={setQuery}
        onRoot={setRoot}
        onToggleBare={() => setIncludeBare(value => !value)}
        onToggleDuplicates={() => setMergeDuplicates(value => !value)}
        onToggleSelecting={() => (selecting ? exitSelect() : setSelecting(true))}
        onRefresh={() => gallery.reload(true)}
        onOpenSidebar={openInSidebar}
      />
      <div className="cfa-body" ref={gallery.scrollRef}>
        {loading && visibleItems.length === 0 ? <div className="cfa-hint">{t('loading')}</div> : null}
        {!loading && visibleItems.length === 0 ? <div className="cfa-empty">{emptyText}</div> : null}
        {visibleItems.length > 0 ? (
          <div className="cfa-grid">
            {visibleItems.map(item => (
              <Card
                key={item.path}
                item={item}
                t={t}
                selecting={selecting}
                selected={selected.has(item.path)}
                onToggle={toggleSelect}
                onOpen={entry => setActivePath(entry.path)}
                onAction={onAction}
              />
            ))}
          </div>
        ) : null}
        {items.length > 0 ? (
          <div className="cfa-more" ref={gallery.sentinelRef}>
            {loadingMore ? <span className="cfa-hint">{t('loading')}</span> : null}
            {!loadingMore && hasMore ? (
              <button type="button" className="cfa-chip" onClick={() => gallery.reload(false)}>{t('loadMore')}</button>
            ) : null}
          </div>
        ) : null}
        {truncated ? <div className="cfa-hint">{t('truncated')}</div> : null}
      </div>
      {notice !== null ? <div className={`cfa-notice${notice.kind === 'err' ? ' err' : ''}`}>{notice.text}</div> : null}
      {selecting ? (
        <BulkBar
          t={t}
          selectedCount={selected.size}
          busy={busy}
          onSelectAll={selectAllShown}
          onSelectNone={selectNone}
          onExport={() => { void bulkExport() }}
          onRemove={() => setBulkConfirmOpen(true)}
          onExit={exitSelect}
        />
      ) : null}
      {activeItem !== null ? (
        <Lightbox
          item={activeItem}
          index={activeIndex}
          count={visibleItems.length}
          t={t}
          onClose={() => setActivePath(null)}
          onAction={onAction}
          onPrev={() => stepActive(-1)}
          onNext={() => stepActive(1)}
        />
      ) : null}
      {pendingDelete !== null ? (
        <ConfirmRemove
          item={pendingDelete}
          t={t}
          busy={busy === removeBusyKey}
          onCancel={() => { if (busy !== removeBusyKey) setPendingDelete(null) }}
          onConfirm={() => { void confirmRemove() }}
        />
      ) : null}
      {bulkConfirmOpen && selecting ? (
        <ConfirmBulkRemove
          count={selected.size}
          t={t}
          busy={busy === 'bulk:delete'}
          onCancel={() => { if (busy !== 'bulk:delete') setBulkConfirmOpen(false) }}
          onConfirm={() => { void bulkRemove() }}
        />
      ) : null}
    </div>
  )
}
