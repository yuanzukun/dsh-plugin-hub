import fs from 'node:fs'
import path from 'node:path'

import { applyOverrides, codeOrDefault, finalStateOf, overrideNotes, resumeRun, submitWorkflow, sweepRun, waitForRun, watchRun } from '../../../shared/run/index.js'
import type { NotifyTarget } from '../../../shared/run/index.js'
import type { PendingRun, RunOutcome } from '../../../shared/run/index.js'
import type { Artifact } from '../../../shared/run/index.js'
import { buildSurface, readEntry } from '../../../shared/workflow/index.js'
import { detectFormat, formatHint } from '../../../shared/workflow/detect.js'
import type { ApiWorkflow, WorkflowIOSurface } from '../../../shared/workflow/types.js'
import { asRecord, asString, parseWait } from '../../../shared/tools/types.js'
import type { ToolBlock, ToolDeps, ToolSpec } from '../../../shared/tools/types.js'

/**
 * 图片产物只以文件路径交付。
 *
 * 宿主把工具结果的每个块都当结构化内容重建模型请求：`{ type: 'image' }` 必须携带
 * 附件引用（attachment），裸 base64 的 MCP 风格图片块会让请求装配读到 undefined
 * 的 attachment 而抛错，并被 LLM 适配器包装成不可恢复的 TRANSPORT 失败。该失败会
 * 永久留在会话历史里，之后每次请求都失败。因此这里不再产出图片块。
 */

/** 已解析并备好 IO 面的工作流。 */
interface LoadedWorkflow {
  workflowId: string
  workflow: ApiWorkflow
  surface: WorkflowIOSurface
}

/** 从 workflow 参数里取模板：优先 { id }，其次 { path }。 */
function loadWorkflow(deps: ToolDeps, args: Record<string, unknown>): LoadedWorkflow {
  const spec = asRecord(args.workflow)
  const id = asString(spec.id).trim()
  if (id !== '') {
    const entry = readEntry(deps.workflowsDir, id)
    if (entry === undefined) throw new Error(`没有这个工作流：${id}。先用 comfyui_workflow 看有哪些。`)
    // 停用的工作流不该被执行：管理员关掉它通常是有原因的（吃显存、只在特定机器上能跑）。
    if (!entry.surface.enabled) {
      throw new Error(`工作流 ${id} 已被停用，不能执行。需要的话在工作流管理面板里重新启用。`)
    }
    return { workflowId: id, workflow: entry.workflow, surface: entry.surface }
  }

  const filePath = asString(spec.path).trim()
  if (filePath === '') throw new Error('需要 workflow：{"id":"…"} 或 {"path":"…"}。')

  let raw: unknown
  try {
    raw = JSON.parse(fs.readFileSync(filePath, 'utf8'))
  } catch (error) {
    throw new Error(`读不了工作流文件：${error instanceof Error ? error.message : String(error)}`)
  }
  if (raw === null || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('工作流文件不是 JSON 对象。')
  // 描述里承诺了"path 必须是 API 格式"，这里就得真的验 —— 否则模型传 UI 格式时
  // 拿到的是 ComfyUI 层那句晦涩报错，而不是下面这句能照做的指引。
  const format = detectFormat(raw)
  if (format !== 'api') throw new Error(formatHint(format))
  const workflow = raw as ApiWorkflow
  const workflowId = path.basename(filePath, path.extname(filePath))
  // 单文件模式：临时算一份 IO 面，保证变量校验与模板走同一套规则。
  return { workflowId, workflow, surface: buildSurface({ workflowId, workflow }) }
}

/** 没有会话通道时用的收尾：只更新注册表，不投递消息。 */
function sweepFallback(
  deps: ToolDeps,
  promptId: string,
  workflowId: string,
  outputDir: string,
): void {
  sweepRun({
    client: deps.client,
    promptId,
    workflowId,
    outputDir,
    intervalMs: deps.pollIntervalMs,
    registry: deps.runs,
    ...(deps.logger === undefined ? {} : { logger: deps.logger }),
  })
}

/** 批量提交复用同一套加载与校验规则（导出给 `run-batch` 用）。 */
export function loadWorkflowForBatch(
  deps: ToolDeps,
  args: Record<string, unknown>,
): LoadedWorkflow {
  return loadWorkflow(deps, args)
}

/**
 * `comfyui_run`：跑一次工作流。
 *
 * 产物只以路径 + 原始像素尺寸的文本交付：宿主的工具结果不能承载二进制图片，
 * 而尺寸必须写清楚 —— 只给压缩图会让模型以为原图就那么大，下一轮按错的尺寸设参数，
 * 产物必然糊。
 *
 * @param deps - 依赖。
 */
export function runTool(deps: ToolDeps): ToolSpec {
  return {
    name: 'comfyui_run',
    description:
      '执行一个 ComfyUI 工作流。'
      + '**服务没在跑时会自动拉起**：提交会等到服务就绪再发出去（默认最多等 3 分钟），'
      + '所以不用先手动启动 ComfyUI；也**不要**去 kill 或重启它 —— 它可能正在下载/加载模型，'
      + '打断会让它卡在自己的下载状态里。'
      + '参数用 vars 传（键必须是该工作流声明过的输入名，可用 comfyui_workflow（不带参数是列表，带 workflowId 是详情） 查）。'
      + '**改参数一律用 vars，不要为了改参数去复制或改写工作流 JSON** —— 模板 + 变量就是为此存在的，'
      + '改文件会让这次运行无法追溯，也让工作流目录越堆越乱；只有要改**结构**（增删节点、换连线）时才碰文件。'
      + '返回值包含产物路径与原始像素尺寸；宿主不回传图片本身，需要看图时按返回的路径读取原图。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      required: [],
      properties: {
        promptId: {
          type: 'string',
          description: '续查一次已提交但还没出完的运行（上一次返回里给的 promptId）。传了它就不用再给 workflow。',
        },
        workflow: {
          type: 'object',
          description:
            '工作流标识。**优先用 {"id":"sdxl"}** —— 指向工作流目录里的模板，配合 vars 改参数，这是常规路径。'
            + '{"path":"D:/某处/workflow.json"} 只用于目录之外的临时文件，且必须是 **API 格式**；'
            + 'UI 格式（带 nodes + links 的界面工程文件）不能直接提交，要先在 ComfyUI 里「Export (API)」。',
          properties: {
            id: { type: 'string' },
            path: { type: 'string' },
          },
        },
        vars: {
          type: 'object',
          description: '变量绑定。键必须是该工作流的输入名；不认识的键会报错而不是被忽略。',
          additionalProperties: true,
        },
        outputPath: { type: 'string', description: '产物落盘目录；不传用配置的 outputDir' },
        wait: {
          type: ['boolean', 'integer'],
          description:
            '要不要同步等到出图：`false`（默认）提交后立刻返回 promptId，出完图插件会主动通知对话；'
            + '`true` 等到产物落盘或超时；也可以直接给毫秒数（如 300000），表示等，但最多等这么久。'
            + '不再有独立的 waitMs / timeoutMs —— 要设上限就把数字传给 wait。',
        },
        tags: {
          type: 'array',
          items: { type: 'string' },
          description: '产物标签，登记进资产索引便于之后筛选。注意只有 wait:true 同步取回产物时才会登记；默认异步路径由后台通知落盘，不写索引。',
        },

      },
    },
    output: {
      schema: { type: 'object', additionalProperties: true },
      render: (_args, value) => {
        const blocks: ToolBlock[] = []
        const bag = value !== null && typeof value === 'object' ? (value as Record<string, unknown>) : {}
        const artifacts = Array.isArray(bag.artifacts) ? (bag.artifacts as Artifact[]) : []

        const lines: string[] = []
        if (bag.pending === true) {
          lines.push(String(bag.message ?? '已提交，还在出图。'))
          if (typeof bag.hint === 'string' && bag.hint !== '') lines.push(String(bag.hint))
          // notes 也要出现在这里：宿主只把 render 文本交给模型，返回对象里的字段它看不到。
          if (Array.isArray(bag.notes) && bag.notes.length > 0) lines.push(`备注：${bag.notes.join('；')}`)
          lines.push(`promptId：${String(bag.promptId)}`)
          blocks.push({ type: 'text', text: lines.join(String.fromCharCode(10)) })
          return blocks
        }
        if (bag.ok === true) {
          lines.push(`工作流 ${String(bag.workflowId)} 执行完成，用时 ${String(bag.durationMs)} ms。`)
          for (const item of artifacts) {
            const size = item.width !== undefined && item.height !== undefined ? `，原图 ${item.width}×${item.height}` : ''
            lines.push(`- ${item.path}（${item.mime}，${Math.round(item.bytes / 1024)} KB${size}）`)
          }
          if (Array.isArray(bag.notes) && bag.notes.length > 0) lines.push(`备注：${bag.notes.join('；')}`)
          lines.push('图片只给路径：需要看图或继续处理时，用上面的路径读取原图；响应里没有图片副本。')
        } else {
          lines.push(String(bag.message ?? '执行失败。'))
          if (typeof bag.hint === 'string' && bag.hint !== '') lines.push(`下一步：${bag.hint}`)
        }
        blocks.push({ type: 'text', text: lines.join('\n') })
        return blocks
      },
    },
    async execute(args, exec) {
      // 续查：上一次调用超时返回 pending 后，用 promptId 回来问结果。
      const resumeId = asString(args.promptId).trim()
      if (resumeId !== '') {
        try {
          // 续查也要用会话级目录，否则用户手动带 promptId 回来问结果时，产物会落到
          // 启动期那个（多工作区下不相关的）目录里。
          const resumeOutputDir = deps.resolveOutputDirFor?.(exec?.agent) ?? deps.outputDir
          const outcome = await resumeRun(deps.client, resumeId, { outputDir: resumeOutputDir })
          // 续查成功也要收敛注册表 —— 否则"wait 遇 5xx 写 unknown、用户照提示续查、
          // 真拿到产物，记录还是 unknown"这种自相矛盾就永远在。这正是 P1 要消灭的东西。
          if ('pending' in outcome) {
            deps.runs.update(resumeId, { state: 'unknown', queuePosition: undefined })
          } else {
            deps.runs.update(resumeId, {
              state: 'done',
              finishedAt: Date.now(),
              queuePosition: undefined,
              artifacts: outcome.artifacts.map(artifact => ({
                path: artifact.path,
                bytes: artifact.bytes,
                ...(artifact.width === undefined ? {} : { width: artifact.width }),
                ...(artifact.height === undefined ? {} : { height: artifact.height }),
              })),
            })
          }
          return formatOutcome(outcome, deps)
        } catch (error) {
          // 续查失败同样按二维判据收敛：确定的写 failed，网络类写 unknown
          const code = codeOrDefault(error, 'wait_failed')
          const definite = finalStateOf(error) === 'failed'
          deps.runs.update(resumeId, {
            state: definite ? 'failed' : 'unknown',
            finishedAt: definite ? Date.now() : undefined,
            queuePosition: undefined,
            error: { code, message: error instanceof Error ? error.message : String(error) },
          })
          return failureOf(error)
        }
      }

      const loaded = loadWorkflow(deps, args)

      const outputDir = asString(args.outputPath).trim() !== ''
        ? asString(args.outputPath).trim()
        : (deps.resolveOutputDirFor?.(exec?.agent) ?? deps.outputDir)
      // `wait` 一参两用：布尔表示等不等，数字表示"等，但最多这么久"。规则见 parseWait。
      const { shouldWait, waitMs } = parseWait(args.wait, deps.timeoutMs)

      // `RunOptions.timeoutMs` 是必填字段，但 submitWorkflow 内部并不读它 ——
      // 单次 HTTP 由 ComfyClient 的 requestTimeoutMs 管，等服务就绪由 readyTimeoutMs 管。
      // 这里照传配置值只是为了满足类型，不再是"提交超时"。
      const submitTimeoutMs = deps.timeoutMs

      // 一次性覆盖：来自 comfyui_workflow_edit（persist=false）。用完即清。
      //
      // 必须走 applyOverrides 而不是直接改 workflow —— applyVariables 会按 slot.default
      // 重写每个槽位绑定的路径，直改的值会被冲掉（无 default 的必填槽位更会直接抛
      // variable_unbound）。详见 shared/run/overrides.ts 的说明。
      // 先校验目录权限，再应用覆盖。反过来的话，本次被拒时覆盖已经被消耗掉了 ——
      // 用户改完权限重跑，参数会静默回到模板值，而他以为自己改过。
      try {
        deps.assertWritable(outputDir, exec?.agent)
      } catch (error) {
        return { ok: false, code: 'forbidden_output', message: error instanceof Error ? error.message : String(error) }
      }

      const pending = deps.overrides.get(loaded.workflowId)
      const applied = applyOverrides(
        loaded.workflow as Record<string, { class_type?: string; inputs?: Record<string, unknown> }>,
        loaded.surface,
        asRecord(args.vars),
        pending,
      )
      const preNotes: string[] = [...overrideNotes(applied)]

      try {
        const submitted = await submitWorkflow({
          timeoutMs: submitTimeoutMs,
          client: deps.client,
          workflow: loaded.workflow,
          slots: loaded.surface.inputs,
          vars: applied.vars,
          outputDir,

          pollIntervalMs: deps.pollIntervalMs,
          workflowId: loaded.workflowId,
          workflowHash: loaded.surface.workflowHash,
        })

        // 登记到运行表：提交之后那几分钟用户看不到任何东西，靠这张表补。
        deps.runs.submit(submitted.promptId, loaded.workflowId)

        // 提交成功之后才消耗覆盖：参数名写错（variable_unknown）、缺节点、ComfyUI 拒收
        // 这些都不该让覆盖消失 —— 用户改完重跑，还得用它。
        if (pending !== undefined && pending.length > 0) deps.overrides.delete(loaded.workflowId)

        // 默认异步：提交完就把控制权交回对话。出图要几分钟，
        // 让工具调用一直挂着会让用户以为连接断了。
        if (!shouldWait) {
          // 有 agent 就挂一个后台等待者：出图后由它调 Agent.followup 把结果塞回
          // 这个会话（与子代理回传同一条通道），用户不用再问一次。
          const agent = exec?.agent as NotifyTarget | undefined
          const canNotify = agent !== undefined && typeof agent.followup === 'function'
          // 没有 agent 就没有 watcher —— 那样记录会永远停在 queued。
          // 这种情况不挂等待者，但要在短延迟后自查一次，把终态收敛掉。
          if (!canNotify) sweepFallback(deps, submitted.promptId, loaded.workflowId, outputDir)
          if (canNotify) {
            watchRun({
              client: deps.client,
              target: agent,
              promptId: submitted.promptId,
              outputDir,
              intervalMs: deps.pollIntervalMs,
              registry: deps.runs,
              ...(deps.logger === undefined ? {} : { logger: deps.logger }),
            })
          }
          return {
            ok: true,
            pending: true,
            promptId: submitted.promptId,
            waitedMs: 0,
            message: `已提交（promptId ${submitted.promptId}），ComfyUI 正在出图。`,
            hint: canNotify
              ? '出图完成后我会在这个对话里主动通知你（含产物路径）；也可以随时用 comfyui_run 传 promptId 手动查。'
              : '出图要几分钟。稍后用 comfyui_run 传 promptId 就能取结果；这次调用结束后任务不会中断。',
            notes: [...preNotes, ...submitted.notes],
          }
        }

        let outcome: Awaited<ReturnType<typeof waitForRun>>
        try {
          outcome = await waitForRun(deps.client, submitted.promptId, {
            timeoutMs: waitMs,
            pollIntervalMs: deps.pollIntervalMs,
            fallback: {
              outputDir,
              workflowId: loaded.workflowId,
              workflowHash: loaded.surface.workflowHash,
              effective: submitted.effective,
            },
          })
        } catch (error) {
          // 可重试的（5xx / 网络）不该让这次运行变成"失败"，更不该把记录留在 queued：
          // ComfyUI 重启窗口里很常见，任务可能还在跑。标 unknown 并给出续查方式。
          // `waitForRun` 抛出来的已经是"攒满 6 次"的**放弃结论**，这里不该再降级。
          // 判据要用 finalStateOf 而不是 isRetryable：`no_output` 是"可重试但终态确定失败"
          // （见 policy.ts 的二维说明）—— 按 isRetryable 判会把它错写成 pending，
          // 让用户去续查一个永远查不到的结果，而且 wait 路径不挂 watcher，
          // 记录会永久停在 unknown（error.code 却是 no_output，自相矛盾）。
          const code = codeOrDefault(error, 'wait_failed')
          const definite = finalStateOf(error) === 'failed'
          const kind = (error as { kind?: unknown }).kind
          deps.runs.update(submitted.promptId, {
            state: definite ? 'failed' : 'unknown',
            finishedAt: definite ? Date.now() : undefined,
            queuePosition: undefined,
            error: {
              code,
              message: error instanceof Error ? error.message : String(error),
              ...(typeof kind === 'string' ? { kind } : {}),
            },
          })
          if (!definite) {
            // 超时/网络类的 pending 也要写 finishedAt —— 否则 runs.ts 的 elapsedMs
            // 用 (finishedAt ?? now) 会一直涨，面板上"耗时"永远在跳。
            deps.runs.update(submitted.promptId, { finishedAt: Date.now() })
            return {
              ok: true,
              pending: true,
              promptId: submitted.promptId,
              message: `提交成功，但查询状态时出错（${code}）：${error instanceof Error ? error.message : String(error)}`,
              hint: '任务可能还在 ComfyUI 那边跑。稍后用 comfyui_run 传这个 promptId 续查。',
              notes: [...preNotes, ...submitted.notes],
            }
          }
          throw error
        }

        if ('pending' in outcome) {
          // wait 超时：不标 failed（任务可能还在 ComfyUI 那边跑），标 unknown。
          // 不收敛终态的话，这条记录会永远停在 running/queued，comfyui_runs
          // 会一直答"还在跑"。finishedAt 与 error 也要写，不然面板上耗时永涨、
          // 且没有任何线索可排查。
          deps.runs.update(submitted.promptId, {
            state: 'unknown',
            finishedAt: Date.now(),
            queuePosition: undefined,
            error: {
              code: 'wait_timeout',
              message: `等了 ${Math.round(outcome.waitedMs / 1000)} 秒仍未出图。`,
            },
          })
          // pending 分支走 formatOutcome，它不认识 preNotes —— 在这里补上，
          // 否则 wait 超时时"已应用覆盖"这句会消失（异步与完成分支都有）。
          // `submitted.notes` 里有 200 响应带出的 node_errors 警告：而"参数被判非法
          // → 那条链不产出"的典型后果正是等到超时，这句最该在这里出现。
          return {
            ...formatOutcome(outcome, deps),
            ...((preNotes.length + submitted.notes.length) > 0 ? { notes: [...preNotes, ...submitted.notes] } : {}),
          }
        }

        // 登记索引：索引是派生（真源是 sidecar），登记失败不该让本次运行算失败。
        const createdAt = new Date().toISOString()
        const tags = Array.isArray(args.tags) ? args.tags.filter((tag): tag is string => typeof tag === 'string') : []
        for (const artifact of outcome.artifacts) {
          try {
            deps.index.add({
              digest: artifact.digest,
              path: artifact.path,
              bytes: artifact.bytes,
              mime: artifact.mime,
              ...(artifact.width === undefined ? {} : { width: artifact.width }),
              ...(artifact.height === undefined ? {} : { height: artifact.height }),
              workflowId: loaded.workflowId,
              workflowHash: loaded.surface.workflowHash,
              promptId: outcome.promptId,
              createdAt,
              tags,
              status: 'present',
            })
          } catch {
            deps.logger?.warn?.('资产索引登记失败（产物已落盘）')
          }
        }

        // wait 成功：这条必须收敛成终态，否则记录永远停在 queued。
        // watcher 只在"异步 + 有 agent"时才挂，wait 路径完全绕过它。
        deps.runs.update(submitted.promptId, {
          state: 'done',
          finishedAt: Date.now(),
          queuePosition: undefined,
          artifacts: outcome.artifacts.map(artifact => ({
            path: artifact.path,
            bytes: artifact.bytes,
            ...(artifact.width === undefined ? {} : { width: artifact.width }),
            ...(artifact.height === undefined ? {} : { height: artifact.height }),
          })),
        })

        // `outcome.notes` 是产物收集阶段的备注；提交时那条 `node_errors` 警告在
        // `submitted.notes` 里 —— 不合并就会在**最主路径**（wait 同步出图）上丢掉。
        const notes = [...preNotes, ...submitted.notes, ...outcome.notes]


        return {
          ok: true,
          workflowId: outcome.workflowId !== '' ? outcome.workflowId : loaded.workflowId,
          promptId: outcome.promptId,
          durationMs: outcome.durationMs,
          artifacts: outcome.artifacts,
          effectiveVars: outcome.effective,
          notes,
        }
      } catch (error) {
        return failureOf(error)
      }
    },
  }
}

/** 把完成/未完成两种结果统一成工具返回值。 */
function formatOutcome(
  outcome: RunOutcome | PendingRun,
  _deps: ToolDeps,
): Record<string, unknown> {
  if ('pending' in outcome) {
    return {
      ok: true,
      pending: true,
      promptId: outcome.promptId,
      waitedMs: outcome.waitedMs,
      message: `已提交，等了 ${Math.round(outcome.waitedMs / 1000)} 秒还在出图。`,
      hint: outcome.hint,
    }
  }
  return {
    ok: true,
    promptId: outcome.promptId,
    workflowId: outcome.workflowId,
    durationMs: outcome.durationMs,
    artifacts: outcome.artifacts,
    effectiveVars: outcome.effective,
    notes: outcome.notes,
  }
}

/** 失败统一出口。 */
function failureOf(error: unknown): Record<string, unknown> {
  const bag = error !== null && typeof error === 'object' ? (error as { code?: unknown; hint?: unknown }) : null
  return {
    ok: false,
    code: typeof bag?.code === 'string' ? bag.code : 'execution_failed',
    message: error instanceof Error ? error.message : String(error),
    ...(typeof bag?.hint === 'string' ? { hint: bag.hint } : {}),
  }
}
