---
name: wps-office-dsh
description: Operate WPS Writer, Spreadsheets, and Presentation through the namespaced WPS MCP tools in DeepSeek Harness.
---

# WPS Office for DeepSeek Harness

Use this skill when the user asks to read, create, edit, format, analyze, export, or coordinate WPS Writer, Spreadsheets, or Presentation documents.

## Tool namespace

The WPS MCP server is mounted with the `wps-office` server name. Every upstream tool is exposed to DSH as:

`mcp__wps-office__<upstream-tool-name>`

For example:

- `wps_common_ping` becomes `mcp__wps-office__wps_common_ping`.
- `wps_excel_read_range` becomes `mcp__wps-office__wps_excel_read_range`.
- `wps_word_get_document_text` becomes `mcp__wps-office__wps_word_get_document_text`.
- `wps_ppt_get_slide_count` becomes `mcp__wps-office__wps_ppt_get_slide_count`.

Choose tools from the live DSH tool catalog. Do not invent a tool that is not registered.

## Operating rules

1. Check the relevant WPS application and document state before editing. Use the matching ping, active-document, workbook, worksheet, presentation, or slide inspection tool available in the catalog.
2. Read the affected content or structure before changing it unless the user explicitly requests a new document.
3. Confirm the target when several documents, workbooks, sheets, or presentations are open and the request does not identify one safely.
4. Before a destructive or broad operation, state the exact range, pages, slides, files, or objects affected. Ask for confirmation when the user's scope is ambiguous.
5. After mutation, verify the changed value, range, paragraph, shape, slide, or exported file with a read operation when the server exposes one.
6. Report the document and application changed. Do not claim success from a tool request alone when its result reports an error or cannot be verified.

## Failure handling

- If no `mcp__wps-office__...` tools are present, report that the WPS MCP bridge did not load. Suggest running `node scripts/doctor.mjs` in the plugin checkout and checking `WPS_SKILLS_ROOT` or `WPS_OFFICE_MCP_ENTRY`.
- If the MCP server is available but WPS is disconnected, preserve the original error and ask the user to start or restart WPS Office, enable the upstream WPS add-in, and open the relevant document type.
- If a requested tool is unavailable, explain the missing capability and use a documented generic WPS method only when its schema is present and the operation is understood.
- Never turn a dependency, connection, permission, or WPS API failure into a silent fallback or a success message.

## Cross-application work

For work spanning multiple WPS applications, keep intermediate data explicit:

1. Read and validate the source data.
2. Inspect or create the destination document.
3. Write the smallest coherent batch supported by the destination tool.
4. Verify the destination and summarize any formatting that could not be preserved.

The WPS automation and MCP tools are provided by `lc2panda/wps-skills`. This skill supplies only DSH-specific routing and safety guidance.
