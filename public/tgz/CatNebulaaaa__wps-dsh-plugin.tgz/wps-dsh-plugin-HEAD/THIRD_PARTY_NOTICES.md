# Third-party notices

## lc2panda/wps-skills

- Source: https://github.com/lc2panda/wps-skills
- License: MIT
- Copyright: Copyright (c) 2026 lc2panda

`dsh-plugin-wps-office` does not redistribute the WPS MCP Server, WPS add-in, or upstream Skill files. At runtime it starts a separately obtained and built `wps-office-mcp` checkout supplied by the user.

The WPS capabilities, upstream tool names, and installation requirements described by this adapter refer to `lc2panda/wps-skills`. See the upstream repository for its complete license text and notices.

## DeepSeek Harness

- Source: https://github.com/deepseek-ai/deepseek-harness
- License: MIT

This bundle targets the public DeepSeek Harness plugin interface and mounts the Harness-provided `@deepseek-ai/dsh-mcp-client`. It does not redistribute DeepSeek Harness source code.
