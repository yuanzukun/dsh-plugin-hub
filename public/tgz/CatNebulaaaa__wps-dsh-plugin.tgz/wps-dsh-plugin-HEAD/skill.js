import { readFileSync } from 'node:fs'
import { dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

export const name = 'wps-office-dsh-skill'
export const inject = ['skills']

const skillUrl = new URL('./skills/wps-office-dsh/SKILL.md', import.meta.url)
const skillPath = fileURLToPath(skillUrl)
const rawSkill = readFileSync(skillUrl, 'utf8')
const content = rawSkill.replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n/, '').trim()

export function apply(ctx) {
  return ctx.skills.register({
    name: 'wps-office-dsh',
    description: 'Operate WPS Writer, Spreadsheets, and Presentation through the namespaced WPS MCP tools in DeepSeek Harness.',
    source: 'runtime',
    resourceBase: {
      kind: 'directory',
      path: dirname(skillPath),
    },
    content,
  })
}
