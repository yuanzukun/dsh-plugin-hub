import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'

const manifest = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'))
const patch = await readFile(new URL('../cordis.patch.yml', import.meta.url), 'utf8')

test('package declares an installable DSH bundle', () => {
  assert.equal(manifest.dsh.bundle.patch, './cordis.patch.yml')
  assert.equal(manifest.license, 'MIT')
  assert.equal(manifest.exports['./skill'], './skill.js')
})

test('bundle mounts the built-in MCP client with loud startup failure', () => {
  assert.match(patch, /@deepseek-ai\/dsh-mcp-client/)
  assert.match(patch, /serverName: wps-office/)
  assert.match(patch, /failOnStartupError: true/)
  assert.match(patch, /WPS_SKILLS_ROOT/)
  assert.match(patch, /WPS_MCP_HOME/)
})

test('runtime skill registers DSH-specific WPS guidance', async () => {
  const plugin = await import('../skill.js')
  let registration
  const dispose = () => {}
  const result = plugin.apply({
    skills: {
      register(value) {
        registration = value
        return dispose
      },
    },
  })

  assert.equal(result, dispose)
  assert.equal(registration.name, 'wps-office-dsh')
  assert.match(registration.content, /mcp__wps-office__/)
  assert.match(registration.content, /Never turn a dependency, connection, permission, or WPS API failure into a silent fallback/)
})
