export const name = 'inspect-wps-tools'
export const inject = ['tools', 'skills']

export function apply(ctx) {
  ctx.effect(() => {
    const startedAt = Date.now()
    let timer

    const inspect = async () => {
      const names = ctx.tools.schemas().map(tool => tool.name)
      const wpsNames = names.filter(value => value.startsWith('mcp__wps-office__'))
      const skills = await ctx.skills.list()
      const hasSkill = skills.some(skill => skill.name === 'wps-office-dsh')
      if (wpsNames.length > 0 && hasSkill) {
        console.log(`WPS_PLUGIN_DISCOVERY_OK tools=${wpsNames.length} skill=wps-office-dsh sample=${wpsNames.slice(0, 3).join(',')}`)
        process.exit(0)
      }
      if (Date.now() - startedAt >= 15_000) {
        console.error(`WPS_PLUGIN_DISCOVERY_ERROR tools=${wpsNames.length} skill=${hasSkill} total_tools=${names.length}`)
        process.exit(2)
      }
      timer = setTimeout(() => void inspect(), 100)
    }

    timer = setTimeout(() => void inspect(), 100)

    return () => clearTimeout(timer)
  }, 'inspect-wps-tools')
}
