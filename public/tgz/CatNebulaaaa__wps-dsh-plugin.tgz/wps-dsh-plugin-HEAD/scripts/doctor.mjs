#!/usr/bin/env node

import { access, readFile, readdir } from 'node:fs/promises'
import { isAbsolute, join, resolve } from 'node:path'

const argv = process.argv.slice(2)

function option(name) {
  const index = argv.indexOf(name)
  if (index < 0) return undefined
  const value = argv[index + 1]
  if (value === undefined || value.startsWith('--')) {
    throw new Error(`${name} requires a value`)
  }
  return value
}

async function exists(path) {
  try {
    await access(path)
    return true
  } catch {
    return false
  }
}

function nodeSupported(version) {
  const match = /^v?(\d+)\.(\d+)\.(\d+)/.exec(version)
  if (!match) return false
  const major = Number(match[1])
  const minor = Number(match[2])
  return (major === 22 && minor >= 19) || major >= 24
}

const checks = []

function record(level, label, detail) {
  checks.push({ level, label, detail })
}

const wpsRootInput = option('--wps-skills-root') ?? process.env.WPS_SKILLS_ROOT
const explicitEntry = option('--wps-mcp-entry') ?? process.env.WPS_OFFICE_MCP_ENTRY
const dshRootInput = option('--dsh-source-root') ?? process.env.DSH_SOURCE_ROOT

if (nodeSupported(process.version)) {
  record('OK', 'Node.js', `${process.version} satisfies the DSH runtime requirement`)
} else {
  record('ERROR', 'Node.js', `${process.version} is unsupported; use Node 22.19+ in the 22.x line or Node 24+`)
}

let wpsRoot
if (wpsRootInput) {
  wpsRoot = resolve(wpsRootInput)
  record(isAbsolute(wpsRootInput) ? 'OK' : 'WARN', 'WPS root', isAbsolute(wpsRootInput) ? wpsRoot : `resolved relative path to ${wpsRoot}`)
} else if (!explicitEntry) {
  record('ERROR', 'WPS root', 'set WPS_SKILLS_ROOT or pass --wps-skills-root')
}

const mcpEntry = explicitEntry
  ? resolve(explicitEntry)
  : wpsRoot
    ? join(wpsRoot, 'wps-office-mcp', 'dist', 'index.js')
    : undefined

if (mcpEntry) {
  if (!isAbsolute(explicitEntry ?? wpsRootInput ?? '')) {
    record('WARN', 'MCP entry', `resolved relative input to ${mcpEntry}`)
  }
  record(await exists(mcpEntry) ? 'OK' : 'ERROR', 'MCP build', await exists(mcpEntry) ? mcpEntry : `missing ${mcpEntry}; run npm install and npm run build in wps-office-mcp`)
}

if (wpsRoot) {
  const manifest = join(wpsRoot, 'wps-office-mcp', 'package.json')
  record(await exists(manifest) ? 'OK' : 'ERROR', 'wps-skills checkout', await exists(manifest) ? manifest : `missing ${manifest}`)
}

if (dshRootInput) {
  const dshRoot = resolve(dshRootInput)
  const packagePath = join(dshRoot, 'package.json')
  const cliPath = join(dshRoot, 'apps', 'cli', 'lib', 'bin.js')
  if (await exists(packagePath)) {
    const manifest = JSON.parse(await readFile(packagePath, 'utf8'))
    record('OK', 'DSH source', `${manifest.version ?? 'unknown version'} at ${dshRoot}`)
  } else {
    record('ERROR', 'DSH source', `missing ${packagePath}`)
  }
  record(await exists(cliPath) ? 'OK' : 'ERROR', 'DSH build', await exists(cliPath) ? cliPath : `missing ${cliPath}; run pnpm run build in the DSH checkout`)
} else {
  record('WARN', 'DSH source', 'not checked; pass --dsh-source-root when using a local DSH build')
}

if (process.platform === 'win32') {
  const appData = process.env.APPDATA
  if (!appData) {
    record('WARN', 'WPS add-in', 'APPDATA is unavailable, so the Windows add-in was not checked')
  } else {
    const addinRoot = join(appData, 'kingsoft', 'wps', 'jsaddons')
    const publishXml = join(addinRoot, 'publish.xml')
    if (await exists(addinRoot)) {
      const names = await readdir(addinRoot)
      const addin = names.find(value => value === 'wps-claude-addon_' || value === 'claude-assistant_')
      record(addin ? 'OK' : 'WARN', 'WPS add-in', addin ? join(addinRoot, addin) : `no supported add-in directory found under ${addinRoot}; Windows COM mode may still work, so confirm with wps_check_connection`)
      record(await exists(publishXml) ? 'OK' : 'WARN', 'WPS publish.xml', await exists(publishXml) ? publishXml : `missing ${publishXml}`)
    } else {
      record('WARN', 'WPS add-in', `missing ${addinRoot}; install WPS Office and the upstream add-in`)
    }
  }
}

for (const check of checks) {
  console.log(`${check.level.padEnd(5)} ${check.label}: ${check.detail}`)
}

const errors = checks.filter(check => check.level === 'ERROR').length
const warnings = checks.filter(check => check.level === 'WARN').length
console.log(`\nSummary: ${errors} error(s), ${warnings} warning(s)`)
process.exitCode = errors === 0 ? 0 : 1
