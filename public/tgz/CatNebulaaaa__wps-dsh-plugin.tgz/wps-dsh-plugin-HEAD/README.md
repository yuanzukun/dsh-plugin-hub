# dsh-plugin-wps-office

Unofficial [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) integration for [lc2panda/wps-skills](https://github.com/lc2panda/wps-skills).

这是一个独立的 DSH 适配层。它不复制 WPS MCP、WPS 加载项或上游 Skills，而是通过 DSH 自带的 MCP Client 启动现有 `wps-office-mcp`，并补充一份适配 DSH 工具命名的轻量 Skill。

> 当前按 DeepSeek Harness `0.1.0-rc.5` 开发和验证。DSH 仍处于 Developer Preview，后续版本可能产生破坏性变化。

## 提供什么

- 把 `wps-office-mcp` 的 stdio 服务挂载进 DSH。
- 将工具暴露为 `mcp__wps-office__<上游工具名>`，避免与其他 MCP Server 冲突。
- 注册 `wps-office-dsh` Skill，提供 DSH 专用路由、安全和错误处理规则。
- 提供只读的环境检查脚本，明确报告 Node、DSH、WPS MCP 和 Windows 加载项状态。

WPS Office 自动化、MCP Server 和 200 多个专业工具均由上游 `lc2panda/wps-skills` 提供。

## 前提条件

- WPS Office，以及按上游说明安装完成的 WPS 加载项。
- 一个已经构建的 `lc2panda/wps-skills` checkout。
- Node.js 22.19+（22.x）或 Node.js 24+，以满足当前 DSH 的运行要求。
- DeepSeek Harness `0.1.0-rc.5` 或兼容版本。

先构建上游 MCP：

```powershell
git clone https://github.com/lc2panda/wps-skills.git
Set-Location .\wps-skills\wps-office-mcp
npm install
npm run build
```

加载项安装和重启 WPS 的步骤以[上游安装文档](https://github.com/lc2panda/wps-skills/blob/main/INSTALL.md)为准。

## 配置 WPS 路径

推荐设置 `WPS_SKILLS_ROOT` 为上游仓库的绝对路径：

```powershell
$env:WPS_SKILLS_ROOT = (Resolve-Path 'C:\path\to\wps-skills').Path
```

也可以只设置编译入口：

```powershell
$env:WPS_OFFICE_MCP_ENTRY = (Resolve-Path 'C:\path\to\wps-skills\wps-office-mcp\dist\index.js').Path
```

DSH 会从启动目录的 `.env` 和 `$DSH_HOME/.env` 加载环境变量。需要跨项目使用时，可将不含密钥的路径配置写入 `$DSH_HOME/.env`；不要把个人路径或任何凭据提交到 Git。

上游 MCP 默认把日志写到用户主目录的 `.wps-office-mcp/logs`。如果运行环境限制该目录写入，可把日志重定向到另一个可写目录：

```powershell
$env:WPS_MCP_HOME = 'D:\path\to\writable-home'
```

## 使用本地构建的 DSH 安装

下面示例直接运行源码 checkout 已构建的 CLI：

```powershell
$DshRoot = 'D:\path\to\deepseek-harness'
$PluginRoot = 'D:\path\to\dsh-plugin-wps-office'

node "$DshRoot\apps\cli\lib\bin.js" plugin --profile web add $PluginRoot
node "$DshRoot\apps\cli\lib\bin.js" --profile web --dump-config
node "$DshRoot\apps\cli\lib\bin.js" web
```

已全局安装 DSH 时：

```powershell
dsh plugin --profile web add .
dsh --profile web --dump-config
dsh web
```

安装 GitHub 版本时建议固定 commit：

```powershell
dsh plugin --profile web add github:CatNebulaaaa/wps-dsh-plugin#COMMIT_SHA
```

## 诊断

```powershell
node scripts/doctor.mjs `
  --wps-skills-root 'D:\path\to\wps-skills' `
  --dsh-source-root 'D:\path\to\deepseek-harness'
```

结果使用 `OK / WARN / ERROR`，存在 `ERROR` 时返回非零退出码。插件本身也设置了 `failOnStartupError: true`：WPS MCP 路径错误、服务启动失败或工具发现失败时，DSH 应明确报错，而不是加载一个没有 WPS 工具的空壳。

## 工具命名

DSH 会给 MCP 工具增加服务器命名空间：

| 上游工具 | DSH 工具 |
|---|---|
| `wps_common_ping` | `mcp__wps-office__wps_common_ping` |
| `wps_excel_read_range` | `mcp__wps-office__wps_excel_read_range` |
| `wps_word_get_document_text` | `mcp__wps-office__wps_word_get_document_text` |
| `wps_ppt_get_slide_count` | `mcp__wps-office__wps_ppt_get_slide_count` |

模型会从实时工具目录获取完整 schema，不需要本插件复制上游工具定义。

## 卸载

```powershell
dsh plugin --profile web remove dsh-plugin-wps-office
```

卸载本插件不会删除 WPS Office、上游 `wps-skills` checkout 或 WPS 加载项。

## 安全和来源

- DSH 会把 stdio MCP Server 作为受信任的本机子进程启动；它不运行在 Agent 文件系统沙箱内。
- 上游 MCP 会写入 `.wps-office-mcp/logs`；本插件保留这一行为，并允许通过 `WPS_MCP_HOME` 改变日志根目录。
- WPS 工具能够修改真实文档。执行批量或覆盖操作前应确认范围并保留备份。
- 本项目不是金山办公、DeepSeek 或 `wps-skills` 维护者的官方项目。
- 上游来源和许可证信息见 [THIRD_PARTY_NOTICES.md](./THIRD_PARTY_NOTICES.md)。

## License

本适配层使用 MIT License。`wps-skills` 仍由其原作者按自己的 MIT License 发布。
