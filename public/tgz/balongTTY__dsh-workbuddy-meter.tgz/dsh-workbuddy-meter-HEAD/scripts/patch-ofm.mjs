#!/usr/bin/env node
/**
 * workbuddy-meter · OFM pack.js 补丁脚本
 * ============================================================
 * 目的：让 dsh-our-free-model（OFM）的 `BuddyAdapter.consumeSse` 在产出 usage 帧
 *       之前，把上游原始 `data.usage`（**含 credit 积分字段**）交给
 *       `globalThis.__wbMeter.capture(...)`，由 workbuddy-meter 的 Host 半身落盘。
 *
 * 补丁只插入**一行**，不引入任何 import，不改变 pack.js 的模块图。
 * Host 半身在 apply() 里设置 `globalThis.__wbMeter`；未装本插件时该表达式被
 * 可选链短路（`?.`），OFM 行为与未打补丁时完全一致。
 *
 * 用法（CONTRACT.md §7.1）：
 *   node scripts/patch-ofm.mjs              # dry-run，只报告会改什么（默认）
 *   node scripts/patch-ofm.mjs --apply      # 实际写入
 *   node scripts/patch-ofm.mjs --revert     # 从备份还原
 *   node scripts/patch-ofm.mjs --check      # 退出码 0=已在位 / 1=未打 / 2=版本漂移
 *
 * 可选：`--ofm <dir>` 覆盖 OFM 插件目录（默认 ~/.dsh/profiles/desktop/node_modules/dsh-our-free-model）
 *
 * 安全性（CONTRACT.md §7.3）：
 *   - 打补丁前自动备份 pack.js → pack.js.backup-<ISO时间戳>（同目录）
 *   - 幂等：已含 `__wbMeter` 标记则跳过
 *   - 锚点命中数 ≠ 1 → **中止且不碰文件**
 *   - 写入前后各做一次 `node --check` 语法校验，写后失败则自动从备份回滚
 *   - 状态记录到 ~/.dsh/workbuddy-meter/patch-state.json
 *
 * 零第三方依赖。
 */

import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import {
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  unlinkSync,
  writeFileSync,
} from 'node:fs'
import { homedir, tmpdir } from 'node:os'
import { dirname, join } from 'node:path'

// ───────────────────────────── 常量 ─────────────────────────────

const DEFAULT_OFM_DIR = join(
  homedir(),
  '.dsh',
  'profiles',
  'desktop',
  'node_modules',
  'dsh-our-free-model',
)

const STATE_DIR = join(homedir(), '.dsh', 'workbuddy-meter')
const STATE_FILE = join(STATE_DIR, 'patch-state.json')

/** pack.js 内相对 OFM 根目录的路径。 */
const PACK_REL = join('vendor', 'channel-pack', 'pack.js')

/**
 * 唯一性判据：这条注释在 pack.js 全文件中**只出现 1 次**（实测 2.9MB 单文件 bundle）。
 * 同名 `if (data.usage) {` 块共 4 处（codearts / buddy / lobsterai / 其他），
 * 只有 buddy 这处带该注释，所以用它做锚点。
 */
const ANCHOR_COMMENT = '// 与 codearts 一致：inputTokens 只计'

/** 幂等标记：文件里出现即视为已打过补丁。 */
const MARKER = '__wbMeter'

/**
 * 要插入的那一行（缩进在运行时按锚点上下文补齐）。
 *
 * 变量名依据 pack.js 实测作用域（2026-10-18 复核）：
 *   - `this.product.id`        → 'buddy' | 'workbuddy'（BuddyAdapter 实例字段）
 *   - `options.model`          → 带前缀的模型名，如 'buddy/deepseek-v4-flash'（Host 侧去前缀）
 *   - `policyBlockedAccountId` → consumeSse 的第 3 个**形参**；可能为 undefined
 *                                （注意：不是 currentAccountId —— 那是调用侧的变量名，
 *                                 在本函数体内出现 0 次）
 *   - `data.usage`             → 上游原始 usage 对象，含 credit
 *   - `startedAt`              → 本适配器无请求起始时间戳，用 Date.now()（记录收到 usage 的时刻）
 */
const CAPTURE_LINE =
  ';globalThis.__wbMeter?.capture?.({ provider: this.product.id, model: options.model, ' +
  'accountId: policyBlockedAccountId ?? "", usage: data.usage, startedAt: Date.now() })'

// ───────────────────────────── 工具 ─────────────────────────────

class PatchError extends Error {
  constructor(message, detail) {
    super(message)
    this.name = 'PatchError'
    this.detail = detail
  }
}

function sha256(buf) {
  return createHash('sha256').update(buf).digest('hex')
}

function countOccurrences(haystack, needle) {
  if (needle === '') return 0
  let count = 0
  let from = 0
  for (;;) {
    const i = haystack.indexOf(needle, from)
    if (i === -1) return count
    count += 1
    from = i + needle.length
  }
}

function lineOfIndex(src, index) {
  let line = 1
  for (let i = 0; i < index && i < src.length; i += 1) {
    if (src.charCodeAt(i) === 10 /* \n */) line += 1
  }
  return line
}

function lineCount(src) {
  return countOccurrences(src, '\n') + 1
}

function readJson(path) {
  try {
    return JSON.parse(readFileSync(path, 'utf8'))
  } catch {
    return null
  }
}

function readState() {
  return readJson(STATE_FILE)
}

function writeState(state) {
  mkdirSync(STATE_DIR, { recursive: true })
  writeFileSync(STATE_FILE, `${JSON.stringify(state, null, 2)}\n`, 'utf8')
}

/** Windows 文件名不能含 `:`，把 ISO 时间戳压成安全形式。 */
function isoStamp(date = new Date()) {
  return date.toISOString().replace(/[:.]/g, '-')
}

function readOfmVersion(ofmDir) {
  const pkg = readJson(join(ofmDir, 'package.json'))
  if (!pkg || typeof pkg.version !== 'string') {
    throw new PatchError(`读不到 OFM 版本：${join(ofmDir, 'package.json')} 不存在或不是合法 JSON`)
  }
  return pkg.version
}

/**
 * 用当前 node 对指定文件做语法校验（`node --check`）。
 * 校验副本写到系统临时目录，**不碰目标文件**。
 */
function checkSyntax(source, label) {
  const tmp = join(tmpdir(), `wb-meter-${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2)}.mjs`)
  try {
    writeFileSync(tmp, source, 'utf8')
    const res = spawnSync(process.execPath, ['--check', tmp], { encoding: 'utf8' })
    if (res.status !== 0) {
      const msg = `${res.stderr || res.stdout || ''}`.trim().split('\n').slice(0, 6).join('\n')
      return { ok: false, message: msg || `node --check 退出码 ${res.status}` }
    }
    return { ok: true, label }
  } finally {
    try {
      unlinkSync(tmp)
    } catch {
      /* 临时文件清理失败不影响主流程 */
    }
  }
}

// ───────────────────────────── 锚点定位 ─────────────────────────────

/**
 * 定位锚点并算出插入点。
 *
 * 返回：
 *   anchorIndex        锚点注释在源串中的下标
 *   insertIndex        补丁行的插入下标（`yield {` 那一行的行首）
 *   indent             `yield` 行的缩进（补丁行沿用同样的缩进）
 *   anchorCommentLine  锚点注释所在行号（原始文件，1-based）
 *   insertLine         补丁行插入后所在行号（1-based）
 */
function locateAnchor(src) {
  const hits = []
  let from = 0
  for (;;) {
    const i = src.indexOf(ANCHOR_COMMENT, from)
    if (i === -1) break
    hits.push(i)
    from = i + ANCHOR_COMMENT.length
  }

  if (hits.length === 0) {
    throw new PatchError(
      '锚点未命中：文件里找不到注释 `与 codearts 一致：inputTokens 只计`。' +
        '可能 OFM 已升级并重写了该块 —— 请先人工复核 pack.js 再更新本脚本的锚点。',
    )
  }
  if (hits.length > 1) {
    throw new PatchError(
      `锚点不唯一：注释命中 ${hits.length} 次（要求恰好 1 次）。为安全起见不改文件。`,
      hits.map((i) => lineOfIndex(src, i)),
    )
  }

  const anchorIndex = hits[0]
  const before = src.slice(0, anchorIndex)

  // 向前找最近的 `yield {\n<indent>type: "usage",` 块起始 —— 补丁插在该 yield 之前
  const re = /\n([ \t]*)yield \{\r?\n[ \t]*type: "usage",\r?\n/g
  let last = null
  for (const m of before.matchAll(re)) last = m
  if (!last) {
    throw new PatchError(
      '锚点上下文异常：在锚点注释之前找不到 `yield { type: "usage", }` 块。为安全起见不改文件。',
    )
  }

  const insertIndex = last.index + 1 // 跳过前导 \n，落在 `yield` 行行首
  const indent = last[1] ?? ''

  // 防御：usage 块应当紧邻锚点注释（实测约 6 行）。距离过大说明匹配到了别处。
  const distance = anchorIndex - insertIndex
  if (distance < 0 || distance > 800) {
    throw new PatchError(
      `锚点上下文异常：找到的 yield 块与锚点注释相距 ${distance} 字符（预期 < 800）。为安全起见不改文件。`,
    )
  }

  const anchorCommentLine = lineOfIndex(src, anchorIndex)
  const insertLine = lineOfIndex(src, insertIndex)

  return { anchorIndex, insertIndex, indent, anchorCommentLine, insertLine, distance }
}

function buildPatched(src, ins) {
  const line = `${ins.indent}${CAPTURE_LINE}\n`
  return {
    patched: src.slice(0, ins.insertIndex) + line + src.slice(ins.insertIndex),
    insertedLine: line,
  }
}

/** 生成用于人读的 diff 预览（插入点前后各 3 行）。 */
function previewDiff(src, ins, insertedLine) {
  const lines = src.split('\n')
  const at = ins.insertLine - 1 // 0-based 插入位置
  const from = Math.max(0, at - 3)
  const to = Math.min(lines.length, at + 3)
  const out = []
  for (let i = from; i < to; i += 1) {
    if (i === at) out.push(`+ ${insertedLine.replace(/\n$/, '')}`)
    out.push(`  ${lines[i]}`)
  }
  if (at >= to) out.push(`+ ${insertedLine.replace(/\n$/, '')}`)
  return out.join('\n')
}

// ───────────────────────────── 备份 ─────────────────────────────

const BACKUP_PREFIX = 'pack.js.backup-'

function listBackups(packDir) {
  let names
  try {
    names = readdirSync(packDir)
  } catch {
    return []
  }
  return names
    .filter((n) => n.startsWith(BACKUP_PREFIX))
    .sort()
    .map((n) => join(packDir, n))
}

function findLatestBackup(packDir, preferred) {
  if (preferred && existsSync(preferred)) return preferred
  const all = listBackups(packDir)
  return all.length > 0 ? all[all.length - 1] : null
}

// ───────────────────────────── 上下文 ─────────────────────────────

function resolveContext(argv) {
  const ofmIdx = argv.indexOf('--ofm')
  let ofmDir = DEFAULT_OFM_DIR
  if (ofmIdx !== -1) {
    const v = argv[ofmIdx + 1]
    if (!v || v.startsWith('--')) {
      throw new PatchError('`--ofm` 需要一个目录参数')
    }
    ofmDir = v
  } else if (process.env.WB_METER_OFM_DIR) {
    ofmDir = process.env.WB_METER_OFM_DIR
  }

  if (!existsSync(ofmDir)) {
    throw new PatchError(`OFM 插件目录不存在：${ofmDir}`)
  }

  const packPath = join(ofmDir, PACK_REL)
  if (!existsSync(packPath)) {
    throw new PatchError(`pack.js 不存在：${packPath}`)
  }

  return {
    ofmDir,
    packPath,
    packDir: dirname(packPath),
    ofmVersion: readOfmVersion(ofmDir),
  }
}

// ───────────────────────────── 模式实现 ─────────────────────────────

function modeInspect(ctx, { willApply }) {
  const buf = readFileSync(ctx.packPath)
  const src = buf.toString('utf8')
  const currentSha = sha256(buf)
  const markerCount = countOccurrences(src, MARKER)

  console.log('── workbuddy-meter · OFM 补丁 ─────────────────────────────')
  console.log(`模式        : ${willApply ? 'APPLY（实际写入）' : 'DRY-RUN（不写文件）'}`)
  console.log(`OFM 版本    : ${ctx.ofmVersion}`)
  console.log(`pack.js     : ${ctx.packPath}`)
  console.log(`文件大小    : ${buf.length} bytes / ${lineCount(src)} 行`)
  console.log(`当前 sha256 : ${currentSha}`)
  console.log(`补丁标记    : ${markerCount === 0 ? '未打（0 处 __wbMeter）' : `已存在（${markerCount} 处 __wbMeter）`}`)
  console.log('')

  // 已打过 → 幂等跳过
  if (markerCount > 0) {
    const state = readState()
    console.log('✔ 已打过补丁，幂等跳过（不重复插入、不新建备份）')
    if (state && state.sha256After && state.sha256After !== currentSha) {
      console.log(`⚠ 但当前 sha256 与 patch-state.json 记录的 ${state.sha256After} 不一致 —— 文件在打补丁后被改动过`)
    }
    if (state && state.ofmVersion && state.ofmVersion !== ctx.ofmVersion) {
      console.log(`⚠ 且 OFM 版本已从 ${state.ofmVersion} 变为 ${ctx.ofmVersion} —— 建议 --revert 后重打`)
    }
    if (state) {
      console.log(`  状态记录 : ${STATE_FILE}`)
      console.log(`  备份路径 : ${state.backupPath ?? '(未记录)'}`)
      console.log(`  打补丁于 : ${state.patchedAtIso ?? new Date(state.patchedAt).toISOString()}`)
    } else {
      console.log(`  状态记录 : 缺失（${STATE_FILE} 不存在）`)
    }
    return { code: 0, patched: false, alreadyPatched: true }
  }

  // 未打 → 定位锚点
  const ins = locateAnchor(src)
  const { patched, insertedLine } = buildPatched(src, ins)

  console.log(`锚点注释    : 命中 1 次 ✔（唯一性校验通过）`)
  console.log(`锚点行号    : ${ins.anchorCommentLine}`)
  console.log(`插入行号    : ${ins.insertLine}（插在 \`yield { type: "usage" }\` 之前）`)
  console.log(`缩进        : ${ins.indent.length} 空格`)
  console.log('')
  console.log('将插入的内容：')
  console.log(`  ${insertedLine.replace(/\n$/, '')}`)
  console.log('')
  console.log('diff 预览：')
  console.log(previewDiff(src, ins, insertedLine))
  console.log('')

  // 语法校验（写临时文件，不碰目标）
  const syn = checkSyntax(patched, 'patched')
  if (!syn.ok) {
    throw new PatchError(`补丁后语法校验失败（未写入任何文件）：\n${syn.message}`)
  }
  console.log('语法校验    : node --check 通过 ✔')
  console.log(`打补丁后 sha256 : ${sha256(Buffer.from(patched, 'utf8'))}`)
  console.log('')

  if (!willApply) {
    console.log('ℹ DRY-RUN：以上为将要发生的改动，文件未修改。加 --apply 实际写入。')
    return { code: 0, patched: false, dryRun: true }
  }

  // ── 实际写入 ──
  mkdirSync(ctx.packDir, { recursive: true })
  const backupPath = join(ctx.packDir, `${BACKUP_PREFIX}${isoStamp()}`)
  writeFileSync(backupPath, buf) // 逐字节复制原始内容
  const backupSha = sha256(readFileSync(backupPath))
  if (backupSha !== currentSha) {
    throw new PatchError(`备份校验失败：备份 sha256 ${backupSha} ≠ 原文件 ${currentSha}。已中止，未改 pack.js。`)
  }
  console.log(`✔ 已备份    : ${backupPath}`)
  console.log(`  备份 sha256: ${backupSha}`)

  const now = new Date()
  writeFileSync(ctx.packPath, patched, 'utf8')

  // 写后复验：语法 + 内容
  const afterBuf = readFileSync(ctx.packPath)
  const afterSha = sha256(afterBuf)
  const afterSrc = afterBuf.toString('utf8')
  const afterMarker = countOccurrences(afterSrc, MARKER)
  const verify = checkSyntax(afterSrc, 'written')

  if (!verify.ok || afterMarker !== 1 || afterSha !== sha256(Buffer.from(patched, 'utf8'))) {
    // 自动回滚
    writeFileSync(ctx.packPath, buf)
    const rolledBackSha = sha256(readFileSync(ctx.packPath))
    throw new PatchError(
      `写入后复验失败，已自动回滚（还原后 sha256=${rolledBackSha}，期望 ${currentSha}）。\n` +
        `  语法校验: ${verify.ok ? 'ok' : verify.message}\n` +
        `  __wbMeter 命中: ${afterMarker}（期望 1）\n` +
        `  备份保留在: ${backupPath}`,
    )
  }
  console.log('✔ 写入完成，复验通过（node --check + __wbMeter 命中 1 次 + sha256 一致）')

  const state = {
    v: 1,
    patched: true,
    ofmVersion: ctx.ofmVersion,
    ofmDir: ctx.ofmDir,
    packPath: ctx.packPath,
    patchedAt: now.getTime(),
    patchedAtIso: now.toISOString(),
    anchorLine: ins.insertLine, // 补丁行在打补丁后文件中的行号
    anchorCommentLine: ins.anchorCommentLine + 1, // 锚点注释在打补丁后文件中的行号
    insertLineBefore: ins.insertLine,
    backupPath,
    sha256Before: currentSha,
    sha256After: afterSha,
    patchLine: CAPTURE_LINE,
  }
  writeState(state)

  console.log(`✔ 已写状态  : ${STATE_FILE}`)
  console.log('')
  console.log('下一步：重启 DSH（或让 OFM 重新加载）后，发一次 buddy/workbuddy 请求，')
  console.log('        检查 ~/.dsh/workbuddy-meter/usage-<今天>.jsonl 是否出现 credit 非 null 的记录。')
  return { code: 0, patched: true }
}

function modeRevert(ctx) {
  const buf = readFileSync(ctx.packPath)
  const src = buf.toString('utf8')
  const currentSha = sha256(buf)
  const markerCount = countOccurrences(src, MARKER)
  const state = readState()

  console.log('── workbuddy-meter · OFM 补丁还原 ─────────────────────────')
  console.log(`OFM 版本    : ${ctx.ofmVersion}`)
  console.log(`pack.js     : ${ctx.packPath}`)
  console.log(`当前 sha256 : ${currentSha}`)
  console.log(`补丁标记    : ${markerCount === 0 ? '无（文件看起来是干净的）' : `${markerCount} 处 __wbMeter`}`)
  console.log('')

  const backupPath = findLatestBackup(ctx.packDir, state?.backupPath)
  if (!backupPath) {
    throw new PatchError(
      `找不到任何备份（在 ${ctx.packDir} 里找 ${BACKUP_PREFIX}*）。无法还原。`,
    )
  }

  const backupBuf = readFileSync(backupPath)
  const backupSha = sha256(backupBuf)
  console.log(`使用备份    : ${backupPath}`)
  console.log(`备份 sha256 : ${backupSha}`)

  if (state?.sha256Before && state.sha256Before !== backupSha) {
    console.log(`⚠ 备份 sha256 与 patch-state.json 记录的 sha256Before(${state.sha256Before}) 不一致 —— 请人工确认这个备份是否就是要还原的目标`)
  }

  const backupSrc = backupBuf.toString('utf8')
  if (countOccurrences(backupSrc, MARKER) !== 0) {
    throw new PatchError(
      `备份文件本身含 __wbMeter 标记 —— 它不是干净的原始文件，拒绝用它还原。请人工检查 ${backupPath}`,
    )
  }
  const syn = checkSyntax(backupSrc, 'backup')
  if (!syn.ok) {
    throw new PatchError(`备份文件语法校验失败，拒绝还原：\n${syn.message}`)
  }

  if (currentSha === backupSha) {
    console.log('')
    console.log('✔ 当前文件已与备份逐字节一致，无需还原。')
  } else {
    // 还原前也留一份"还原前"的快照，避免误操作丢东西
    const preRevertBackup = join(ctx.packDir, `pack.js.prerevert-${isoStamp()}`)
    writeFileSync(preRevertBackup, buf)
    console.log(`还原前快照  : ${preRevertBackup}`)

    writeFileSync(ctx.packPath, backupBuf)
    const restoredSha = sha256(readFileSync(ctx.packPath))
    if (restoredSha !== backupSha) {
      throw new PatchError(`还原失败：还原后 sha256=${restoredSha}，期望 ${backupSha}`)
    }
    console.log('✔ 已还原')
  }

  // 校验还原结果
  const finalBuf = readFileSync(ctx.packPath)
  const finalSha = sha256(finalBuf)
  const finalSrc = finalBuf.toString('utf8')
  const finalMarker = countOccurrences(finalSrc, MARKER)
  const finalSyn = checkSyntax(finalSrc, 'restored')

  console.log(`还原后 sha256 : ${finalSha}`)
  console.log(`备份 sha256   : ${backupSha}`)
  console.log(`sha256 一致   : ${finalSha === backupSha ? '是 ✔' : '否 ✘'}`)
  console.log(`__wbMeter 残留: ${finalMarker}（期望 0）${finalMarker === 0 ? ' ✔' : ' ✘'}`)
  console.log(`语法校验      : ${finalSyn.ok ? 'node --check 通过 ✔' : `失败 ✘ ${finalSyn.message}`}`)

  if (finalSha !== backupSha || finalMarker !== 0 || !finalSyn.ok) {
    throw new PatchError('还原后校验未全部通过，请人工介入。')
  }

  // 补丁已不在位 → 移除状态文件（保留"当前未打补丁"这一事实）
  if (existsSync(STATE_FILE)) {
    const removed = readState()
    unlinkSync(STATE_FILE)
    console.log('')
    console.log(`✔ 已移除状态文件 ${STATE_FILE}（原记录 ofmVersion=${removed?.ofmVersion ?? '?'}，patchedAtIso=${removed?.patchedAtIso ?? '?'}）`)
  }

  console.log('')
  console.log('✔ 还原完成：pack.js 已回到打补丁前的逐字节状态。')
  return { code: 0 }
}

function modeCheck(ctx) {
  const buf = readFileSync(ctx.packPath)
  const src = buf.toString('utf8')
  const currentSha = sha256(buf)
  const markerCount = countOccurrences(src, MARKER)
  const anchorCount = countOccurrences(src, ANCHOR_COMMENT)
  const state = readState()
  const version = ctx.ofmVersion

  console.log('── workbuddy-meter · OFM 补丁状态检查 ─────────────────────')
  console.log(`OFM 版本    : ${version}`)
  console.log(`pack.js     : ${ctx.packPath}`)
  console.log(`当前 sha256 : ${currentSha}`)
  console.log(`__wbMeter   : ${markerCount} 处`)
  console.log(`锚点注释    : ${anchorCount} 处`)
  console.log(`状态记录    : ${state ? `${STATE_FILE}（ofmVersion=${state.ofmVersion}，patchedAtIso=${state.patchedAtIso}）` : '无'}`)

  let code
  let verdict
  let reason

  if (markerCount > 0) {
    if (anchorCount !== 1) {
      code = 2
      verdict = 'DRIFT（版本漂移）'
      reason = `补丁标记在位，但锚点注释命中 ${anchorCount} 次（期望 1）—— 文件结构已变，补丁可能失效`
    } else if (!state) {
      code = 0
      verdict = 'PATCHED（在位，但无状态记录）'
      reason = '补丁在位且锚点正常；patch-state.json 缺失（可能被手工清理过）'
    } else if (state.ofmVersion !== version) {
      code = 2
      verdict = 'DRIFT（版本漂移）'
      reason = `补丁记录来自 OFM ${state.ofmVersion}，当前是 ${version} —— 请 --revert 后重打`
    } else if (state.sha256After && state.sha256After !== currentSha) {
      code = 2
      verdict = 'DRIFT（版本漂移）'
      reason = `补丁在位，但当前 sha256 与记录的打补丁后 sha256 不一致 —— 文件在打补丁后被改动过`
    } else {
      code = 0
      verdict = 'PATCHED（在位）'
      reason = '补丁在位，锚点唯一，sha256 与记录一致'
    }
  } else {
    if (state) {
      code = 2
      verdict = 'DRIFT（版本漂移）'
      reason = `曾有补丁记录（OFM ${state.ofmVersion}），但当前文件没有 __wbMeter —— OFM 升级覆盖了 pack.js，需要重打`
    } else {
      code = 1
      verdict = 'NOT PATCHED（未打）'
      reason = '文件里没有 __wbMeter，也没有补丁记录 —— 从未打过补丁'
    }
  }

  console.log('')
  console.log(`判定        : ${verdict}`)
  console.log(`原因        : ${reason}`)
  console.log(`退出码      : ${code}（0=已在位 / 1=未打 / 2=版本漂移）`)
  return { code, verdict, reason }
}

// ───────────────────────────── 入口 ─────────────────────────────

const USAGE = `workbuddy-meter · OFM pack.js 补丁脚本

用法:
  node scripts/patch-ofm.mjs             dry-run（默认，只报告不改文件）
  node scripts/patch-ofm.mjs --apply     实际写入补丁
  node scripts/patch-ofm.mjs --revert    从备份还原
  node scripts/patch-ofm.mjs --check     检查状态（退出码 0=在位 / 1=未打 / 2=版本漂移）

可选:
  --ofm <dir>   指定 OFM 插件目录（默认 ${DEFAULT_OFM_DIR}）
  -h, --help    显示本帮助`

function main(argv) {
  const args = argv.slice(2)

  if (args.includes('-h') || args.includes('--help')) {
    console.log(USAGE)
    return 0
  }

  const apply = args.includes('--apply')
  const revert = args.includes('--revert')
  const check = args.includes('--check')

  const modes = [apply, revert, check].filter(Boolean)
  if (modes.length > 1) {
    console.error('✘ --apply / --revert / --check 只能选一个')
    return 1
  }

  // 严格的参数白名单校验：--ofm 消耗一个值，其余必须是已知开关
  const unknown = []
  for (let i = 0; i < args.length; i += 1) {
    const a = args[i]
    if (a === '--ofm') {
      i += 1 // 跳过它的值
      continue
    }
    if (!['--apply', '--revert', '--check', '-h', '--help'].includes(a)) unknown.push(a)
  }
  if (unknown.length > 0) {
    console.error(`✘ 未知参数: ${unknown.join(' ')}`)
    console.error('  用 --help 查看用法')
    return 1
  }

  let ctx
  try {
    ctx = resolveContext(args)
  } catch (error) {
    console.error(`✘ ${error.message}`)
    return 1
  }

  try {
    if (check) return modeCheck(ctx).code
    if (revert) return modeRevert(ctx).code
    return modeInspect(ctx, { willApply: apply }).code
  } catch (error) {
    if (error instanceof PatchError) {
      console.error('')
      console.error(`✘ ${error.message}`)
      if (error.detail) {
        console.error(`  细节: ${JSON.stringify(error.detail)}`)
      }
      console.error('  （文件未被修改）')
      return 1
    }
    console.error('')
    console.error(`✘ 意外错误: ${error?.stack ?? error}`)
    return 1
  }
}

process.exitCode = main(process.argv)
