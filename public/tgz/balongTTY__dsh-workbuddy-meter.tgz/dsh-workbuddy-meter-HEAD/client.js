/**
 * dsh-workbuddy-meter — Client half (browser panel).
 *
 * Loaded directly by the Harness web app through `window.__ModuleLoader__.load`.
 * No build step, no ESM `import`, no third-party dependency: React comes from the
 * host module table via the factory's `require`.
 *
 * Registers two slots (see CONTRACT.md §6):
 *   - `sidebar.panellist` : sidebar icon, id `workbuddy-meter`, order 30 (after dsh-context's 20)
 *   - `main`              : the standalone panel, key `workbuddy-meter`
 *
 * Data comes from the Host half over four POST routes (§5). Every colour is a
 * `--dsw-alias-*` theme token so light/dark follow the host automatically.
 */
window.__ModuleLoader__.load({
  id: 'dsh-workbuddy-meter',
  factory(require) {
    'use strict'

    var React = require('react')
    var h = React.createElement
    var useState = React.useState
    var useEffect = React.useEffect
    var useCallback = React.useCallback
    var useRef = React.useRef

    var NS = 'dsh-workbuddy-meter'
    // CONTRACT §6 freezes the slot identity as `workbuddy-meter` (the module id
    // and the locale namespace stay package-qualified).
    var PANEL_KEY = 'workbuddy-meter'
    var API = 'api/workbuddy-meter'

    /* ------------------------------------------------------------------ *
     * Dictionaries — verbatim mirrors of locale/zh.json and locale/en.json.
     * The bundle cannot import JSON at runtime, so the same frozen key set is
     * embedded here and handed to the host locale service in `apply`.
     * ------------------------------------------------------------------ */

    var ZH = {
  "meta": {
    "title": "WorkBuddy 用量审计",
    "description": "本机 OFM 进程的 WorkBuddy / CodeBuddy 请求审计：按账号统计积分消耗、上下文规模与缓存节省。"
  },
  "title": "用量审计",
  "nav": "用量",
  "refresh": "刷新",
  "range": {
    "today": "今日",
    "d7": "7 日",
    "d30": "30 日"
  },
  "hero": {
    "label": "本区间消耗",
    "unit": "积分",
    "requests": "请求",
    "tokens": "token"
  },
  "chain": {
    "title": "为什么这么贵",
    "step1": "每次请求带",
    "step1Unit": "上下文",
    "step2": "所以单次花",
    "step2Unit": "积分",
    "step3": "按此节奏",
    "step3Unit": "积分 / 小时",
    "growth": "上下文比区间开始时涨了 {ratio}×",
    "growthDetail": "{first} → {last}",
    "saved": "缓存已省 {ratio}×",
    "savedDetail": "全冷要 {cold} 积分，实际 {actual}",
    "cold": "冷",
    "hot": "热",
    "priceUnit": "积分 / 1M token",
    "empty": "样本不足，多跑几轮后出现"
  },
  "accounts": {
    "account": "账号",
    "share": "占比",
    "requests": "请求",
    "tokens": "token",
    "unitPrice": "单价",
    "credit": "积分",
    "remaining": "剩余",
    "empty": "还没有记录",
    "burnTitle": "额度已用 {used} / {total}（{pct}）",
    "idle": "备",
    "remainUnit": "可用",
    "poolTitle": "账号池",
    "poolSubtitle": "在用与备用账号，余额与消耗",
    "switchTo": "切到这个账号",
    "switching": "切换中…",
    "activeBadge": "使用中",
    "switchHint": "选中的账号才会被 OFM 使用；停用其他账号可避免被自动选到",
    "switchFailed": "切换失败：{reason}",
    "limitActive": "限流中 · {min} 后解除",
    "limitClear": "无限流",
    "testNow": "测 {model}",
    "testing": "测试中…",
    "testOk": "✅ 可用 · {ms}ms",
    "testFail": "❌ 不可用",
    "testHint": "真发一次请求验证 {model} 是否可用（会消耗少量积分）"
  },
  "trend": {
    "title": "按天趋势",
    "tokens": "Token",
    "credit": "积分"
  },
  "models": {
    "title": "模型明细",
    "model": "模型",
    "provider": "渠道",
    "requests": "请求",
    "prompt": "输入",
    "cacheRead": "缓存命中",
    "completion": "输出",
    "reasoning": "思考",
    "total": "合计",
    "credit": "积分",
    "unitPrice": "单价",
    "empty": "还没有记录"
  },
  "balance": {},
  "patch": {
    "installed": "已打补丁",
    "missing": "未打补丁",
    "drift": "需重打",
    "selfHealed": "已自动重打",
    "ofmVersion": "OFM",
    "apply": "打补丁",
    "recheck": "重检"
  },
  "common": {
    "none": "—",
    "error": "出错了：{message}",
    "loading": "加载中…",
    "more": "展开明细",
    "less": "收起明细"
  },
  "overview": {
    "missing": "未上报"
  },
  "runway": {
    "title": "还能用多久",
    "label": "按当前速率",
    "hours": "{hours} 小时",
    "days": "{days} 天",
    "lessThanHour": "不到 1 小时",
    "noRate": "样本不足",
    "basis": "剩余 {remain} 积分 ÷ {rate} 积分/小时",
    "balanceUnknown": "需要余额数据",
    "confidence": {
      "high": "数据充分",
      "medium": "数据尚可",
      "low": "样本偏少，仅供参考",
      "none": "无法估算"
    },
    "tokensLeft": "还能用 token",
    "requestsLeft": "还能请求",
    "unitPriceNow": "按本区间实测 {price} 积分/1M（{model}）",
    "per1000": "1000 积分 ≈ {tokens}",
    "scopeSpending": "按本区间在消耗的账号余额",
    "scopePool": "整池可用",
    "accountsUnit": "个账号",
    "currentOnly": "当前账号单独可用 {span}（余额 {remain}）"
  },
  "insight": {
    "cache": "缓存命中 {pct}，单价被压到 {price} 积分/1M",
    "context": "但每次请求带 {tokens} 上下文，所以单次要 {cost} 积分"
  },
  "modelValue": {
    "title": "模型性价比",
    "subtitle": "按本区间实测单价排序，最便宜的在最上",
    "cheapest": "最省",
    "vs": "贵 {ratio}×",
    "overspend": "多花 {credit}",
    "hit": "命中 {pct}",
    "onlyOne": "本区间只有一种模型，无法比较",
    "noData": "还没有可比较的样本",
    "hint": "单价 = Σ积分 ÷ Σtoken，只用本区间真实数据",
    "gapLabel": "两者单价差",
    "gapDetail": "{second} 比 {best} 每 1M token 多花这么多（{ratio} 倍）"
  },
  "advice": {
    "title": "怎么更省",
    "subtitle": "按历史数据推算的节省空间",
    "empty": "当前没有可执行的开支优化项——缓存命中率和模型选择都在合理区间。",
    "cacheTitle": "缓存命中率偏低",
    "cacheBody": "当前命中 {hit}%。冷请求单价 {cold} 积分/1M，热请求只要 {hot}，差 {ratio} 倍。频繁新开会话或改动上下文会反复付全价。",
    "contextTitle": "上下文偏大",
    "contextBody": "{share}% 的积分花在单次上下文 ≥{threshold}k 的请求上（平均 {avg}k）。长会话每一轮都按全额重算，及时清会话或压缩能直接降本。",
    "modelTitle": "有更划算的模型",
    "modelBody": "{from} 的实测单价比 {to} 贵 {ratio} 倍，同样的 token 换成更便宜的模型即可省下。",
    "save": "约省 {credit}",
    "totalLabel": "合计可省",
    "totalShare": "约占当前开支 {pct}%",
    "note": "按本机历史数据推算，是上界估计而非承诺——各项之间可能重叠，实际节省取决于你怎么用。",
    "unitLabel": "积分",
    "noMoney": "本区间没有足够样本给出可量化的节省额——换更长的统计区间（7/30 天）可以看到模型对比。",
    "stepsLabel": "下一步",
    "stepContext": "{share}% 的开支来自大上下文（均值 {avg}k）——把长会话及时新开，或压缩历史后再继续",
    "stepModel": "把默认模型从 {from} 换成 {to}",
    "stepCache": "缓存命中 {hit}% 已经在省钱——尽量不要频繁改开头几轮的消息，那会让前缀缓存失效"
  },
  "history": {
    "vsPrev": "对比上期",
    "noBaseline": "无上期数据可比",
    "projected": "照此推算本区间约 {credit}"
  },
  "hourly": {
    "title": "时段分布",
    "peak": "最贵时段 {hour} 点 · 占 {pct}%"
  },
  "badge": {
    "ready": "可用",
    "limited": "限流中",
    "none": "未启用账号",
    "hint": "当前生效账号 · 剩余积分（点击侧栏「用量」看详情）",
    "limitLeft": "{time}后解除"
  },
  "rhythm": {
    "today": "今日",
    "todayReq": "今日请求",
    "rate": "当前速率",
    "month": "按此推算整月",
    "unitCredit": "积分",
    "unitReq": "次",
    "perHour": "积分 / 小时"
  },
  "scenario": {
    "now": "按当前速率",
    "peak": "按最忙时段",
    "lean": "上下文减半",
    "note": "后两项是推算值：最忙时段取窗口内最贵那一小时的实测速率，上下文减半按速率降一半估算。"
  },
  "bb": {
    "title": "折合",
    "tokensPerHour": "每小时消耗 token",
    "requestsPerHour": "每小时请求",
    "creditPerDay": "折合每天（24h 不停）"
  },
    "rename": {
    "hint": "点击修改显示名（只影响本地面板，不改上游账号）",
    "action": "修改昵称",
    "placeholder": "留空则恢复默认",
    "saved": "已改名",
    "failed": "改名失败"
  },
  "lexicon": {
    "title": "关键词风控中和",
    "sub": "上游按关键词拦截时的应急开关",
    "on": "已开启",
    "off": "已关闭",
    "enable": "总开关",
    "enableHint": "关闭后完全恢复原始请求，不做任何改写",
    "neutralize": "中和身份关键词",
    "neutralizeHint": "把「DeepSeek Harness」改为不可见分隔（渲染无差别）",
    "ensureSystem": "补首条 system",
    "ensureSystemHint": "首条非 system 时注入保底 system（11128 的另一个成因）",
    "hideIdentity": "隐藏品牌词",
    "hideIdentityHint": "更激进：连 DeepSeek 也打散，默认关",
    "stats": "已中和 {n} 处 · 注入 {m} 次",
    "statsIdle": "尚未拦截到需要改写的请求",
    "hookMissing": "钩子未安装",
    "patchMissing": "pack.js 未打钩子",
    "repair": "补打钩子",
    "pathSafe": "文件路径不会被改写"
  }
}

    var EN = {
  "meta": {
    "title": "WorkBuddy Usage Audit",
    "description": "Audit of this machine's OFM process: per-account credit spend, context size and cache savings for the WorkBuddy / CodeBuddy channels."
  },
  "title": "Usage Audit",
  "nav": "Usage",
  "refresh": "Refresh",
  "range": {
    "today": "Today",
    "d7": "7 days",
    "d30": "30 days"
  },
  "hero": {
    "label": "Spent this range",
    "unit": "credits",
    "requests": "Requests",
    "tokens": "Tokens"
  },
  "chain": {
    "title": "Why it costs this much",
    "step1": "Each request carries",
    "step1Unit": "context",
    "step2": "so each one costs",
    "step2Unit": "credits",
    "step3": "at this pace",
    "step3Unit": "credits / hour",
    "growth": "Context grew {ratio}× since the range started",
    "growthDetail": "{first} → {last}",
    "saved": "Cache saved {ratio}×",
    "savedDetail": "All-cold would cost {cold} credits; it cost {actual}",
    "cold": "Cold",
    "hot": "Hot",
    "priceUnit": "credits / 1M tokens",
    "empty": "Not enough samples yet"
  },
  "accounts": {
    "account": "Account",
    "share": "Share",
    "requests": "Reqs",
    "tokens": "Tokens",
    "unitPrice": "Unit",
    "credit": "Credits",
    "remaining": "Left",
    "empty": "No records yet",
    "burnTitle": "Used {used} of {total} ({pct})",
    "idle": "reserve",
    "remainUnit": "left",
    "poolTitle": "Account pool",
    "poolSubtitle": "Active and reserve accounts, balance and spend",
    "switchTo": "Use this account",
    "switching": "Switching…",
    "activeBadge": "in use",
    "switchHint": "Only the selected account is used by OFM; disable others to keep them out of automatic selection",
    "switchFailed": "Switch failed: {reason}",
    "limitActive": "rate-limited · {min} left",
    "limitClear": "no limit",
    "testNow": "Test {model}",
    "testing": "Testing…",
    "testOk": "OK · {ms}ms",
    "testFail": "Not available",
    "testHint": "Sends one real request to verify {model} is usable (costs a little credit)"
  },
  "trend": {
    "title": "Daily trend",
    "tokens": "Tokens",
    "credit": "Credits"
  },
  "models": {
    "title": "Model breakdown",
    "model": "Model",
    "provider": "Channel",
    "requests": "Reqs",
    "prompt": "Prompt",
    "cacheRead": "Cache read",
    "completion": "Output",
    "reasoning": "Reasoning",
    "total": "Total",
    "credit": "Credits",
    "unitPrice": "Unit",
    "empty": "No records yet"
  },
  "balance": {},
  "patch": {
    "installed": "Patched",
    "missing": "Not patched",
    "drift": "Re-apply needed",
    "selfHealed": "Auto re-applied",
    "ofmVersion": "OFM",
    "apply": "Apply",
    "recheck": "Re-check"
  },
  "common": {
    "none": "—",
    "error": "Error: {message}",
    "loading": "Loading…",
    "more": "Show details",
    "less": "Hide details"
  },
  "overview": {
    "missing": "not reported"
  },
  "runway": {
    "title": "Runway",
    "label": "At the current rate",
    "hours": "{hours} h",
    "days": "{days} d",
    "lessThanHour": "under 1 hour",
    "noRate": "Not enough samples",
    "basis": "{remain} credits left ÷ {rate} credits/hour",
    "balanceUnknown": "Balance needed",
    "confidence": {
      "high": "solid data",
      "medium": "fair data",
      "low": "few samples, rough only",
      "none": "cannot estimate"
    },
    "tokensLeft": "Tokens left",
    "requestsLeft": "Requests left",
    "unitPriceNow": "measured {price} credits/1M this range ({model})",
    "per1000": "1000 credits ≈ {tokens}",
    "scopeSpending": "Balance of accounts used this range",
    "scopePool": "Whole pool",
    "accountsUnit": "accounts",
    "currentOnly": "Current account alone: {span} ({remain} left)"
  },
  "insight": {
    "cache": "Cache hits {pct}, so the unit price sits at {price} credits/1M",
    "context": "but each request carries {tokens} of context, so one turn costs {cost} credits"
  },
  "modelValue": {
    "title": "Model value",
    "subtitle": "Sorted by measured unit price, cheapest first",
    "cheapest": "cheapest",
    "vs": "{ratio}× pricier",
    "overspend": "overpaid {credit}",
    "hit": "{pct} hit",
    "onlyOne": "Only one model in this range — nothing to compare",
    "noData": "No comparable samples yet",
    "hint": "Unit price = Σcredits ÷ Σtokens, measured data only",
    "gapLabel": "price gap",
    "gapDetail": "{second} costs this much more per 1M tokens than {best} ({ratio}x)"
  },
  "advice": {
    "title": "Spend less",
    "subtitle": "Headroom estimated from your own history",
    "empty": "Nothing actionable right now — cache hit rate and model choice are both in a healthy range.",
    "cacheTitle": "Cache hit rate is low",
    "cacheBody": "Currently {hit}%. A cold request costs {cold} credit/1M versus {hot} when cached — {ratio}× difference. New sessions and context edits re-pay the full prefix.",
    "contextTitle": "Context is oversized",
    "contextBody": "{share}% of your credit goes to requests whose prompt alone exceeds {threshold}k tokens (average {avg}k). Long sessions re-charge the whole prefix every turn; trimming or compacting them cuts cost directly.",
    "modelTitle": "A cheaper model is available",
    "modelBody": "{from} costs {ratio}× more per token than {to} in your own measurements; the same tokens would cost less on the cheaper model.",
    "save": "save ~{credit}",
    "totalLabel": "Total headroom",
    "totalShare": "~{pct}% of current spend",
    "note": "Estimated from this machine's history. This is an upper bound, not a promise — items can overlap and real savings depend on how you work.",
    "unitLabel": "credit",
    "noMoney": "Not enough samples in this range to price a saving — switch to a longer range (7/30 days) to see the model comparison.",
    "stepsLabel": "next steps",
    "stepContext": "{share}% of spend is oversized context (avg {avg}k) — start a fresh session sooner, or compact history before continuing",
    "stepModel": "switch the default model from {from} to {to}",
    "stepCache": "cache hits at {hit}% are already saving money — avoid editing early-turn messages, which invalidates the prefix cache"
  },
  "history": {
    "vsPrev": "vs previous",
    "noBaseline": "no prior period to compare",
    "projected": "on pace for {credit}"
  },
  "hourly": {
    "title": "By hour",
    "peak": "peak {hour}:00 · {pct}% of spend"
  },
  "badge": {
    "ready": "ready",
    "limited": "limited",
    "none": "no active account",
    "hint": "Active account · remaining credit (open Usage for detail)",
    "limitLeft": "clears in {time}"
  },
  "rhythm": {
    "today": "today",
    "todayReq": "today requests",
    "rate": "current rate",
    "month": "month at this pace",
    "unitCredit": "credit",
    "unitReq": "calls",
    "perHour": "credit / hour"
  },
  "scenario": {
    "now": "at current pace",
    "peak": "at peak hour",
    "lean": "half the context",
    "note": "The last two are estimates: peak uses the busiest observed hour, half context assumes the rate halves."
  },
  "bb": {
    "title": "equivalent to",
    "tokensPerHour": "tokens per hour",
    "requestsPerHour": "requests per hour",
    "creditPerDay": "per day at this rate (24h)"
  },
    "rename": {
    "hint": "Click to edit the display name (local only, does not change the upstream account)",
    "action": "Rename account",
    "placeholder": "Empty restores the default",
    "saved": "Renamed",
    "failed": "Rename failed"
  },
  "lexicon": {
    "title": "Keyword filter bypass",
    "sub": "Emergency switch for upstream keyword blocking",
    "on": "Enabled",
    "off": "Disabled",
    "enable": "Master switch",
    "enableHint": "Turning this off restores the original request untouched",
    "neutralize": "Neutralise identity keyword",
    "neutralizeHint": "Turns \"DeepSeek Harness\" into an invisible-separator form (renders identically)",
    "ensureSystem": "Prepend system message",
    "ensureSystemHint": "Injects a fallback system when the first message is not system (another 11128 cause)",
    "hideIdentity": "Also hide brand word",
    "hideIdentityHint": "More aggressive: splits DeepSeek too. Off by default",
    "stats": "Neutralised {n} spots · injected {m} times",
    "statsIdle": "No request needed rewriting yet",
    "hookMissing": "Hook not installed",
    "patchMissing": "pack.js has no hook",
    "repair": "Reinstall hook",
    "pathSafe": "File paths are never rewritten"
  }
}

    /* ------------------------------------------------------------------ *
     * i18n
     * ------------------------------------------------------------------ */

    function pick(dict, key) {
      var parts = String(key).split('.')
      var node = dict
      for (var i = 0; i < parts.length; i += 1) {
        if (node === null || typeof node !== 'object') return undefined
        node = node[parts[i]]
      }
      return typeof node === 'string' ? node : undefined
    }

    function interpolate(text, vars) {
      if (!vars) return text
      return String(text).replace(/\{(\w+)\}/g, function (all, name) {
        return Object.prototype.hasOwnProperty.call(vars, name) ? String(vars[name]) : all
      })
    }

    function fallbackT(key, vars) {
      var text = pick(ZH, key)
      if (text === undefined) text = pick(EN, key)
      if (text === undefined) return String(key)
      return interpolate(text, vars)
    }

    /** Bind the host locale service, degrading to the embedded dictionaries. */
    function makeT(ctx) {
      var bound = null
      try {
        if (ctx && ctx.locale && typeof ctx.locale.bind === 'function') bound = ctx.locale.bind(NS)
      } catch (err) {
        bound = null
      }
      return function t(key, vars) {
        if (typeof bound === 'function') {
          try {
            var value = bound(key, vars)
            if (typeof value === 'string' && value !== '' && value !== key) return value
          } catch (err) {
            /* fall through to the embedded dictionary */
          }
        }
        return fallbackT(key, vars)
      }
    }

    /* ------------------------------------------------------------------ *
     * Formatting
     * ------------------------------------------------------------------ */

    function num(value, fallback) {
      if (typeof value === 'number' && isFinite(value)) return value
      if (typeof value === 'string' && value.trim() !== '') {
        var parsed = Number(value)
        if (isFinite(parsed)) return parsed
      }
      return typeof fallback === 'number' ? fallback : 0
    }

    function bool(value) {
      return value === true || value === 'true' || value === 1
    }

    function trimNum(value, digits) {
      var fixed = tidy(Number(value)).toFixed(digits)
      return fixed.replace(/(\.\d*?)0+$/, '$1').replace(/\.$/, '')
    }

    function group(value) {
      var text = String(Math.round(value))
      var negative = text.charAt(0) === '-'
      if (negative) text = text.slice(1)
      text = text.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
      return negative ? '-' + text : text
    }

    function fmtInt(value) {
      return isFinite(value) ? group(value) : '—'
    }

    function fmtTokens(value) {
      if (!isFinite(value)) return '—'
      var abs = Math.abs(value)
      if (abs >= 1e9) return trimNum(value / 1e9, 2) + 'B'
      if (abs >= 1e6) return trimNum(value / 1e6, 2) + 'M'
      if (abs >= 1e4) return trimNum(value / 1e3, 1) + 'K'
      return group(value)
    }

    function fmtCredit(value) {
      if (!isFinite(value)) return '—'
      if (value === 0) return '0'
      var abs = Math.abs(value)
      if (abs >= 1000) return trimNum(value, 1)
      if (abs >= 10) return trimNum(value, 2)
      if (abs >= 1) return trimNum(value, 3)
      return trimNum(value, 4)
    }

    function fmtPrice(value) {
      if (!isFinite(value)) return '—'
      if (value === 0) return '0'
      if (Math.abs(value) >= 100) return trimNum(value, 1)
      if (Math.abs(value) >= 1) return trimNum(value, 2)
      return trimNum(value, 3)
    }

    function fmtPct(ratio) {
      if (!isFinite(ratio)) return '—'
      return trimNum(ratio * 100, 1) + '%'
    }

    /** Halve away binary float noise before rounding (0.17 * 3 -> 0.5100000000000001). */
    function tidy(value) {
      return Math.round(value * 1e10) / 1e10
    }

    function pad2(value) {
      return value < 10 ? '0' + value : String(value)
    }

    function fmtDate(ts) {
      if (!isFinite(ts) || ts <= 0) return '—'
      var date = new Date(ts)
      if (isNaN(date.getTime())) return '—'
      return (
        date.getFullYear() +
        '-' +
        pad2(date.getMonth() + 1) +
        '-' +
        pad2(date.getDate()) +
        ' ' +
        pad2(date.getHours()) +
        ':' +
        pad2(date.getMinutes())
      )
    }

    /** `2026-10-18` -> `10-18`; anything else is returned untouched. */
    function shortDay(day) {
      var text = String(day || '')
      var match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text)
      return match ? match[2] + '-' + match[3] : text
    }

    function ymdOf(date) {
      return date.getFullYear() + '-' + pad2(date.getMonth() + 1) + '-' + pad2(date.getDate())
    }

    /**
     * The trend must stay readable when the chosen range has no bucket for a
     * day (the plugin only writes files for days that saw traffic). Fill the
     * gaps with empty buckets so bars keep their true calendar spacing; only
     * do it when every label really is a `YYYY-MM-DD` day.
     */
    function fillDays(days, range) {
      if (!Array.isArray(days)) return days
      var limit = typeof range === 'number' && range > 0 ? range : 0
      // With one day of history the "fill the gaps" pass below has nothing to
      // fill and the chart renders a single bar in an empty frame. Anchor the
      // window to the requested range instead, so a 7-day view always shows
      // seven slots and the bar sits where today actually is.
      if (days.length === 0) {
        if (limit === 0) return days
        var today = new Date()
        var blank = []
        for (var b = limit - 1; b >= 0; b -= 1) {
          var d = new Date(today.getTime())
          d.setDate(d.getDate() - b)
          blank.push({ day: ymdOf(d), bucket: emptyBucket() })
        }
        return blank
      }
      var allDays = true
      for (var i = 0; i < days.length; i += 1) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(days[i].day)) {
          allDays = false
          break
        }
      }
      if (!allDays) return days
      var known = new Map()
      for (var k = 0; k < days.length; k += 1) known.set(days[k].day, days[k])
      // The window always ends at the latest known day (the host sorts them),
      // and starts `limit` days earlier when a range was asked for; otherwise
      // it starts at the earliest known day.
      var end = new Date(days[days.length - 1].day + 'T00:00:00')
      if (isNaN(end.getTime())) return days
      var start
      if (limit > 0) {
        start = new Date(end.getTime())
        start.setDate(start.getDate() - (limit - 1))
      } else {
        start = new Date(days[0].day + 'T00:00:00')
        if (isNaN(start.getTime()) || end < start) return days
      }
      var out = []
      var cursor = new Date(start.getTime())
      while (cursor <= end && out.length < 400) {
        var key = ymdOf(cursor)
        var existing = known.get(key)
        out.push(existing || { day: key, bucket: emptyBucket() })
        cursor.setDate(cursor.getDate() + 1)
      }
      return out
    }

    function errText(err) {
      if (err === null || err === undefined) return 'unknown error'
      if (typeof err === 'string') return err
      if (typeof err.message === 'string' && err.message !== '') return err.message
      return String(err)
    }

    function isAbort(err) {
      return !!err && (err.name === 'AbortError' || err.code === 20)
    }

    /* ------------------------------------------------------------------ *
     * Data normalization
     *
     * The Host half owns the aggregation shape; this client stays tolerant so a
     * shape tweak on that side degrades into "a number is missing" instead of a
     * crashed panel. CONTRACT §3.1 bucket fields are read as-is; `day`, `date`
     * and `key` are all accepted as the day label.
     * ------------------------------------------------------------------ */

    function emptyBucket() {
      return {
        requests: 0,
        reported: 0,
        errors: 0,
        promptTokens: 0,
        cacheReadTokens: 0,
        cacheWriteTokens: 0,
        completionTokens: 0,
        reasoningTokens: 0,
        totalTokens: 0,
        credit: 0,
        creditMissing: 0,
        ttftSumMs: 0,
        ttftCount: 0,
        tpsSum: 0,
        tpsCount: 0
      }
    }

    function bucketOf(source) {
      var out = emptyBucket()
      if (!source || typeof source !== 'object') return out
      out.requests = num(source.requests)
      out.creditMissing = num(source.creditMissing)
      out.reported = num(source.reported, out.requests - out.creditMissing)
      out.errors = num(source.errors)
      out.promptTokens = num(source.promptTokens)
      out.cacheReadTokens = num(source.cacheReadTokens)
      out.cacheWriteTokens = num(source.cacheWriteTokens)
      out.completionTokens = num(source.completionTokens)
      out.reasoningTokens = num(source.reasoningTokens)
      out.totalTokens = num(source.totalTokens, out.promptTokens + out.completionTokens)
      out.credit = num(source.credit)
      out.ttftSumMs = num(source.ttftSumMs)
      out.ttftCount = num(source.ttftCount)
      out.tpsSum = num(source.tpsSum)
      out.tpsCount = num(source.tpsCount)
      if (out.requests > 0 && out.creditMissing > out.requests) out.creditMissing = out.requests
      if (out.reported < 0) out.reported = 0
      return out
    }

    function addBucket(target, source) {
      var keys = Object.keys(emptyBucket())
      for (var i = 0; i < keys.length; i += 1) target[keys[i]] += num(source[keys[i]])
      return target
    }

    function looksLikeBucket(value) {
      if (!value || typeof value !== 'object') return false
      return (
        typeof value.requests === 'number' ||
        typeof value.totalTokens === 'number' ||
        typeof value.promptTokens === 'number' ||
        typeof value.credit === 'number'
      )
    }

    function childList(value) {
      if (!value || typeof value !== 'object') return null
      var candidates = [value.buckets, value.rows, value.models, value.entries, value.items]
      for (var i = 0; i < candidates.length; i += 1) {
        if (Array.isArray(candidates[i])) return candidates[i]
      }
      return null
    }

    /** Fold an entry that may be a flat bucket or a container of sub-buckets. */
    function foldEntry(entry) {
      if (!entry || typeof entry !== 'object') return null
      if (looksLikeBucket(entry)) return bucketOf(entry)
      var children = childList(entry)
      if (!children || children.length === 0) return null
      var total = emptyBucket()
      var seen = false
      for (var i = 0; i < children.length; i += 1) {
        var child = children[i]
        if (!child || typeof child !== 'object') continue
        addBucket(total, bucketOf(child))
        seen = true
      }
      return seen ? total : null
    }

    function dayKeyOf(entry) {
      if (!entry || typeof entry !== 'object') return ''
      var raw = entry.day || entry.date || entry.key || entry.dayKey
      if (typeof raw === 'string' && raw !== '') return raw
      if (typeof raw === 'number') return String(raw)
      var ts = entry.ts || entry.at
      if (typeof ts === 'number' && isFinite(ts)) {
        var date = new Date(ts)
        if (!isNaN(date.getTime())) {
          return date.getFullYear() + '-' + pad2(date.getMonth() + 1) + '-' + pad2(date.getDate())
        }
      }
      return ''
    }

    function normalizeDays(value) {
      var raw = value && Array.isArray(value.days) ? value.days : []
      var out = []
      for (var i = 0; i < raw.length; i += 1) {
        var entry = raw[i]
        var folded = foldEntry(entry)
        if (folded === null) continue
        out.push({ day: dayKeyOf(entry) || String(i + 1), bucket: folded })
      }
      out.sort(function (a, b) {
        return a.day < b.day ? -1 : a.day > b.day ? 1 : 0
      })
      return out
    }

    function normalizeModels(value) {
      var source = null
      if (value && Array.isArray(value.models)) source = value.models
      else if (value && value.totals && Array.isArray(value.totals.models)) source = value.totals.models
      else if (value && Array.isArray(value.rows)) source = value.rows

      var grouped = new Map()

      function addRow(row, forcedDay) {
        if (!row || typeof row !== 'object') return
        var model = typeof row.model === 'string' ? row.model : typeof row.name === 'string' ? row.name : ''
        if (model === '') return
        var provider = typeof row.provider === 'string' ? row.provider : ''
        var key = model + '\u0000' + provider
        var bucket = foldEntry(row)
        if (bucket === null) return
        var current = grouped.get(key)
        if (!current) {
          current = { model: model, provider: provider, bucket: emptyBucket(), lastDay: '' }
          grouped.set(key, current)
        }
        addBucket(current.bucket, bucket)
        if (forcedDay && forcedDay > current.lastDay) current.lastDay = forcedDay
      }

      if (source) {
        for (var i = 0; i < source.length; i += 1) addRow(source[i], '')
      } else {
        // Derive from the day buckets: day -> children -> rows.
        var rawDays = value && Array.isArray(value.days) ? value.days : []
        for (var d = 0; d < rawDays.length; d += 1) {
          var day = rawDays[d]
          var children = childList(day)
          if (!children) continue
          var dayLabel = dayKeyOf(day)
          for (var c = 0; c < children.length; c += 1) addRow(children[c], dayLabel)
        }
      }

      var rows = []
      grouped.forEach(function (row) {
        rows.push(row)
      })
      rows.sort(function (a, b) {
        return b.bucket.totalTokens - a.bucket.totalTokens || b.bucket.requests - a.bucket.requests
      })
      return rows
    }

    function sumDays(days) {
      var total = emptyBucket()
      for (var i = 0; i < days.length; i += 1) addBucket(total, days[i].bucket)
      return total
    }

    function safeDiv(a, b) {
      return isFinite(a) && isFinite(b) && b !== 0 ? a / b : NaN
    }

    /** CONTRACT §3.2 derived metrics; host-provided values win. */
    function derive(totals, provided) {
      var src = provided && typeof provided === 'object' ? provided : {}
      var reportedTokens = num(src.reportedTotalTokens, NaN)
      var creditTokens = isFinite(reportedTokens) ? reportedTokens : totals.totalTokens

      var cacheHit = num(src.cacheHitRate, NaN)
      if (!isFinite(cacheHit)) cacheHit = safeDiv(totals.cacheReadTokens, totals.promptTokens)

      var unitPrice = num(src.unitPrice, NaN)
      if (!isFinite(unitPrice)) {
        unitPrice = totals.reported > 0 && creditTokens > 0 ? safeDiv(totals.credit, creditTokens) * 1e6 : NaN
      }

      var perCredit = num(src.perCredit, NaN)
      if (!isFinite(perCredit)) perCredit = totals.credit > 0 ? safeDiv(totals.totalTokens, totals.credit) : NaN

      return {
        cacheHitRate: cacheHit,
        unitPrice: unitPrice,
        perCredit: perCredit,
        coldUnitPrice: num(src.coldUnitPrice, NaN),
        hotUnitPrice: num(src.hotUnitPrice, NaN)
      }
    }

    function normalizeSummary(value) {
      var safe = value && typeof value === 'object' ? value : {}
      var days = normalizeDays(safe)
      var totals = looksLikeBucket(safe.totals) ? bucketOf(safe.totals) : sumDays(days)
      if (days.length > 0 && totals.requests === 0 && totals.totalTokens === 0) totals = sumDays(days)
      var models = normalizeModels(safe)
      if (models.length === 0 && days.length === 0 && totals.requests === 0) {
        models = normalizeModels({ models: Array.isArray(safe.byModel) ? safe.byModel : [] })
      }
      return {
        days: days,
        totals: totals,
        models: models,
        derived: derive(totals, safe.derived),
        // Cost drivers pass straight through: only the host knows the span.
        drivers: normalizeDrivers(safe.drivers),
        // Per-account buckets: the "who is spending" view. Each row already
        // carries its own provider/model/credit rollup from the host.
        accounts: normalizeAccounts(safe.accounts),
        // Cheapest-first model ranking, already computed host-side.
        modelValue: normalizeModelValue(safe.modelValue),
        // Spend advice. normalizeSummary is a whitelist — every new host field
        // must be added here or it silently disappears before the panel sees it.
        advice: safe.advice && typeof safe.advice === 'object' ? safe.advice : null,
        history: safe.history && typeof safe.history === 'object' ? safe.history : null,
        hourly: safe.hourly && typeof safe.hourly === 'object' ? safe.hourly : null
      }
    }

    /**
     * Cooldown rows from the host /limits route, keyed by account id.
     * Shape: { [accountId]: [{ modelId, resetAt, remainingMs, active }] }
     */
    /** Compact "how long until the cooldown lifts" label. */
    function fmtMinutes(ms) {
      if (!isFinite(ms) || ms <= 0) return '0 分钟'
      var mins = Math.ceil(ms / 60000)
      if (mins < 60) return String(mins) + ' 分钟'
      var hours = Math.floor(mins / 60)
      var rest = mins % 60
      return rest === 0 ? String(hours) + ' 小时' : String(hours) + ' 小时 ' + String(rest) + ' 分'
    }

    /** Hour-of-day profile from the host /summary hourly block. */
    function normalizeHourly(value) {
      if (!value || typeof value !== 'object') return null
      var map = function (rows) {
        if (!Array.isArray(rows)) return []
        var out = []
        for (var i = 0; i < rows.length; i += 1) {
          var r = rows[i]
          if (!r || !isFinite(r.hour)) continue
          out.push({
            hour: r.hour,
            credit: isFinite(r.credit) ? r.credit : 0,
            requests: isFinite(r.requests) ? r.requests : 0
          })
        }
        return out
      }
      return {
        hours: map(value.hours),
        today: map(value.today),
        maxHourCredit: isFinite(value.maxHourCredit) ? value.maxHourCredit : 0,
        peakHour: isFinite(value.peakHour) ? value.peakHour : null,
        peakShare: isFinite(value.peakShare) ? value.peakShare : null
      }
    }

    /** Period-over-period comparison from the host /summary history block. */
    function normalizeHistory(value) {
      if (!value || typeof value !== 'object') return null
      var cur = value.current && typeof value.current === 'object' ? value.current : {}
      var prev = value.previous && typeof value.previous === 'object' ? value.previous : {}
      var del = value.delta && typeof value.delta === 'object' ? value.delta : {}
      var pick = function (obj, key) { return isFinite(obj[key]) ? obj[key] : null }
      return {
        currentCredit: pick(cur, 'credit'),
        previousCredit: pick(prev, 'credit'),
        // null = no baseline; the UI must say so rather than show 0% or +∞.
        deltaCredit: pick(del, 'credit'),
        elapsedFraction: pick(value, 'elapsedFraction'),
        projectedCredit: pick(value, 'projectedCredit')
      }
    }

    /** Host advice block: what to change, and roughly what it is worth. */
    function normalizeAdvice(value) {
      if (!value || typeof value !== 'object') return null
      var items = []
      var raw = Array.isArray(value.items) ? value.items : []
      for (var i = 0; i < raw.length; i += 1) {
        var it = raw[i]
        if (!it || typeof it.id !== 'string') continue
        items.push({
          id: it.id,
          severity: typeof it.severity === 'string' ? it.severity : 'medium',
          // null means "no honest number available" — never coerce to 0.
          impactCredit: isFinite(it.impactCredit) ? it.impactCredit : null,
          detail: it.detail && typeof it.detail === 'object' ? it.detail : {}
        })
      }
      return {
        items: items,
        potentialCredit: isFinite(value.potentialCredit) ? value.potentialCredit : null,
        potentialShareOfSpend: isFinite(value.potentialShareOfSpend) ? value.potentialShareOfSpend : null,
        thresholds: value.thresholds && typeof value.thresholds === 'object' ? value.thresholds : {}
      }
    }

    function normalizeLimits(value) {
      var out = {}
      if (!value || typeof value !== 'object' || !Array.isArray(value.accounts)) return out
      for (var i = 0; i < value.accounts.length; i += 1) {
        var a = value.accounts[i]
        if (!a || typeof a.id !== 'string') continue
        var limits = Array.isArray(a.limits) ? a.limits : []
        var clean = []
        for (var j = 0; j < limits.length; j += 1) {
          var l = limits[j]
          if (!l || typeof l.modelId !== 'string') continue
          if (!isFinite(l.resetAt)) continue
          clean.push({
            modelId: l.modelId,
            resetAt: l.resetAt,
            remainingMs: isFinite(l.remainingMs) ? l.remainingMs : 0,
            active: l.active === true
          })
        }
        out[a.id] = clean
      }
      return out
    }

    /** Account pool rows from channel-pack (host /accounts route). */
    function normalizePool(value) {
      if (!value || typeof value !== 'object') return { accounts: [] }
      var list = Array.isArray(value.accounts) ? value.accounts : []
      var out = []
      for (var i = 0; i < list.length; i += 1) {
        var a = list[i]
        if (!a || typeof a !== 'object') continue
        out.push({
          id: typeof a.id === 'string' ? a.id : '',
          nickname: typeof a.nickname === 'string' ? a.nickname : '',
          // Strict: only an explicit `true` counts as enabled. A missing field
          // used to default to true, which made every account look "in use".
          enabled: a.enabled === true,
          refreshable: a.refreshable !== false,
          remaining: num(a.remaining, NaN),
          packages: Array.isArray(a.packages) ? a.packages : []
        })
      }
      return { accounts: out }
    }

    /** Model value ranking rows (host aggregate §modelValue). */
    function normalizeModelValue(value) {
      if (!Array.isArray(value)) return []
      var out = []
      for (var i = 0; i < value.length; i += 1) {
        var m = value[i]
        if (!m || typeof m !== 'object') continue
        out.push({
          provider: typeof m.provider === 'string' ? m.provider : '',
          model: typeof m.model === 'string' ? m.model : '',
          unitPricePerMTok: num(m.unitPricePerMTok, NaN),
          cacheHitRate: num(m.cacheHitRate, NaN),
          requests: num(m.requests),
          totalTokens: num(m.totalTokens),
          credit: num(m.credit, NaN),
          tokensPerCredit: num(m.tokensPerCredit, NaN),
          vsCheapest: num(m.vsCheapest, 1),
          atCheapestCredit: num(m.atCheapestCredit, NaN),
          overspendCredit: num(m.overspendCredit, NaN)
        })
      }
      return out
    }

    /** Per-account rollup rows (host aggregate §accounts). */
    function normalizeAccounts(value) {
      if (!Array.isArray(value)) return []
      var out = []
      for (var i = 0; i < value.length; i += 1) {
        var a = value[i]
        if (!a || typeof a !== 'object') continue
        out.push({
          provider: typeof a.provider === 'string' ? a.provider : '',
          accountId: typeof a.accountId === 'string' ? a.accountId : '',
          requests: num(a.requests),
          reported: num(a.reported),
          errors: num(a.errors),
          promptTokens: num(a.promptTokens),
          cacheReadTokens: num(a.cacheReadTokens),
          completionTokens: num(a.completionTokens),
          reasoningTokens: num(a.reasoningTokens),
          totalTokens: num(a.totalTokens),
          credit: num(a.credit, NaN),
          creditMissing: num(a.creditMissing),
          derived: a.derived && typeof a.derived === 'object' ? a.derived : {}
        })
      }
      return out
    }

    function normalizeSide(value) {
      if (!value || typeof value !== 'object') return null
      return {
        requests: num(value.requests),
        totalTokens: num(value.totalTokens),
        promptTokens: num(value.promptTokens),
        completionTokens: num(value.completionTokens),
        cacheReadTokens: num(value.cacheReadTokens),
        credit: num(value.credit, NaN),
        creditReportedRequests: num(value.creditReportedRequests),
        derived: value.derived && typeof value.derived === 'object' ? value.derived : {}
      }
    }

    function normalizeDrivers(value) {
      if (!value || typeof value !== 'object') return null
      var growth = value.contextGrowth && typeof value.contextGrowth === 'object' ? value.contextGrowth : null
      return {
        scope: typeof value.scope === 'string' ? value.scope : 'local',
        samples: num(value.samples),
        reportedSamples: num(value.reportedSamples),
        avgPromptTokens: num(value.avgPromptTokens, NaN),
        creditPerRequest: num(value.creditPerRequest, NaN),
        cacheSavedMultiple: num(value.cacheSavedMultiple, NaN),
        coldEquivalentCredit: num(value.coldEquivalentCredit, NaN),
        actualCredit: num(value.actualCredit, NaN),
        contextGrowth: growth
          ? { first: num(growth.first), last: num(growth.last), ratio: num(growth.ratio, NaN) }
          : null,
        burnRatePerHour: num(value.burnRatePerHour, NaN),
        // Confidence + the two headline ratios the insight line needs.
        burnConfidence: typeof value.burnConfidence === 'string' ? value.burnConfidence : 'none',
        tokensPerRequest: num(value.tokensPerRequest, NaN),
        cacheHitRate: num(value.cacheHitRate, NaN),
        spanHours: num(value.spanHours, NaN)
      }
    }

    function normalizeBalance(value) {
      var safe = value && typeof value === 'object' ? value : {}
      var raw = Array.isArray(safe.accounts) ? safe.accounts : []
      var accounts = []
      for (var i = 0; i < raw.length; i += 1) {
        var acc = raw[i]
        if (!acc || typeof acc !== 'object') continue
        var packages = Array.isArray(acc.packages) ? acc.packages : []
        accounts.push({
          accountId: typeof acc.accountId === 'string' ? acc.accountId : '',
          provider: typeof acc.provider === 'string' ? acc.provider : '',
          nickname: typeof acc.nickname === 'string' ? acc.nickname : '',
          total: num(acc.total, NaN),
          expiredTotal: num(acc.expiredTotal),
          status: typeof acc.status === 'string' ? acc.status : '',
          at: num(acc.at, num(safe.at)),
          packages: packages
        })
      }
      return { at: num(safe.at), accounts: accounts }
    }

    function normalizePatch(value) {
      var safe = value && typeof value === 'object' ? value : {}
      var installed = bool(safe.installed)
      var anchors = num(safe.anchors)
      var state = 'missing'
      if (installed) state = anchors === 1 ? 'installed' : 'drift'
      if (safe.status === 'drift' || safe.drift === true) state = installed ? 'drift' : 'missing'
      return {
        state: state,
        installed: installed,
        anchors: anchors,
        ofmVersion: typeof safe.ofmVersion === 'string' ? safe.ofmVersion : '',
        lastPatchAt: num(safe.lastPatchAt, NaN)
      }
    }

    /* ------------------------------------------------------------------ *
     * Transport
     * ------------------------------------------------------------------ */

    function postJSON(path, body, signal) {
      return fetch(path, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body || {}),
        signal: signal
      }).then(function (response) {
        return response
          .json()
          .catch(function () {
            return null
          })
          .then(function (payload) {
            if (!response.ok) {
              var httpMessage = payload && payload.error && payload.error.message
              throw new Error(httpMessage || 'HTTP ' + response.status)
            }
            if (!payload || payload.ok !== true) {
              var routeMessage = payload && payload.error && payload.error.message
              throw new Error(routeMessage || 'request failed')
            }
            return payload.value
          })
      })
    }

    /* ------------------------------------------------------------------ *
     * Presentational helpers
     * ------------------------------------------------------------------ */

    /**
     * 24-cell hour strip. Colour intensity is credit relative to the busiest
     * hour, so the peak is obvious without reading any number.
     */
    function HourHeat(props) {
      var hourly = props.hourly
      var t = props.t
      var fmtCredit = props.fmtCredit
      if (!hourly || hourly.hours.length === 0) return null
      var max = hourly.maxHourCredit
      var cells = []
      for (var i = 0; i < hourly.hours.length; i += 1) {
        // NOTE: never name this `h` — that is the module's React.createElement
        // alias, and shadowing it makes every h(...) call in this component fail.
        var cell = hourly.hours[i]
        // level 0-4: empty / faint / light / warm / hot
        var level = 0
        if (max > 0 && cell.credit > 0) {
          var ratio = cell.credit / max
          level = ratio >= 0.75 ? 4 : ratio >= 0.45 ? 3 : ratio >= 0.18 ? 2 : 1
        }
        cells.push(
          h('div', {
            key: 'h' + i,
            className: 'wbm-heat-cell',
            'data-level': level,
            title: String(cell.hour).padStart(2, '0') + ':00 · ' + fmtCredit(cell.credit) + ' · ' + cell.requests + ' ' + t('hero.requests')
          })
        )
      }
      var axis = []
      for (var a = 0; a < 24; a += 6) {
        axis.push(h('span', { key: 'a' + a, className: 'wbm-heat-tick' }, String(a).padStart(2, '0')))
      }
      var peak =
        hourly.peakHour !== null && hourly.peakShare !== null
          ? h(
              'span',
              { className: 'wbm-heat-peak' },
              t('hourly.peak', {
                hour: String(hourly.peakHour).padStart(2, '0'),
                pct: Math.round(hourly.peakShare * 100)
              })
            )
          : null
      return h(
        'div',
        { className: 'wbm-heat' },
        h('div', { className: 'wbm-heat-head' },
          h('span', { className: 'wbm-heat-title' }, t('hourly.title')),
          h('span', { className: 'wbm-spacer' }),
          peak),
        h('div', { className: 'wbm-heat-cells' }, cells),
        h('div', { className: 'wbm-heat-axis' }, axis)
      )
    }

    /**
     * Period-over-period strip. Deliberately tiny: it answers "am I spending
     * more than before?" in one glance, and never invents a baseline.
     */
    function HistoryStrip(props) {
      var history = props.history
      var t = props.t
      var fmtCredit = props.fmtCredit
      if (!history || history.currentCredit === null) return null

      var deltaNode = null
      if (history.deltaCredit === null) {
        // No previous window to compare against (fresh install / reset).
        deltaNode = h('span', { className: 'wbm-hist-none' }, t('history.noBaseline'))
      } else {
        var pct = Math.round(history.deltaCredit * 100)
        var dir = pct > 0 ? 'up' : pct < 0 ? 'down' : 'flat'
        deltaNode = h(
          'span',
          { className: 'wbm-hist-delta', 'data-dir': dir },
          (pct > 0 ? '+' : '') + pct + '%'
        )
      }

      var projNode =
        history.projectedCredit !== null && history.elapsedFraction !== null && history.elapsedFraction < 0.98
          ? h(
              'span',
              { className: 'wbm-hist-proj' },
              t('history.projected', { credit: fmtCredit(history.projectedCredit) })
            )
          : null

      return h(
        'div',
        { className: 'wbm-hist' },
        h('span', { className: 'wbm-hist-label' }, t('history.vsPrev')),
        history.previousCredit !== null && history.previousCredit > 0
          ? h('span', { className: 'wbm-hist-prev' }, fmtCredit(history.previousCredit))
          : null,
        deltaNode,
        projNode
      )
    }

    /**
     * One line of "what to change". Each row is self-contained: label on the
     * left, the concrete number on the right, one sentence of reasoning below.
     */
    function AdviceRow(props) {
      var item = props.item
      var t = props.t
      var fmtCredit = props.fmtCredit
      var d = item.detail || {}
      var title = ''
      var body = ''
      if (item.id === 'cache') {
        title = t('advice.cacheTitle')
        body = t('advice.cacheBody', {
          hit: Math.round((d.hitRate || 0) * 100),
          cold: num(d.coldPrice, 0).toFixed(2),
          hot: num(d.hotPrice, 0).toFixed(2),
          ratio: Math.round(num(d.ratio, 1))
        })
      } else if (item.id === 'context') {
        title = t('advice.contextTitle')
        body = t('advice.contextBody', {
          share: Math.round((d.share || 0) * 100),
          threshold: Math.round((d.threshold || 500000) / 1000),
          avg: Math.round((d.avgPromptTokens || 0) / 1000)
        })
      } else if (item.id === 'model') {
        var off = Array.isArray(d.offenders) && d.offenders.length > 0 ? d.offenders[0] : null
        title = t('advice.modelTitle')
        body = off
          ? t('advice.modelBody', {
              from: off.model,
              ratio: num(off.ratio, 1).toFixed(1),
              to: d.cheapest ? d.cheapest.model : ''
            })
          : ''
      }
      var impact =
        item.impactCredit !== null && item.impactCredit > 0
          ? h('span', { className: 'wbm-adv-impact' }, t('advice.save', { credit: fmtCredit(item.impactCredit) }))
          : null
      return h(
        'div',
        { className: 'wbm-adv-row', 'data-severity': item.severity },
        h(
          'div',
          { className: 'wbm-adv-head' },
          h('span', { className: 'wbm-adv-dot', 'aria-hidden': 'true' }),
          h('span', { className: 'wbm-adv-title' }, title),
          h('span', { className: 'wbm-spacer' }),
          impact
        ),
        body ? h('p', { className: 'wbm-adv-body' }, body) : null
      )
    }

    function AdviceCard(props) {
      var advice = props.advice
      var t = props.t
      var fmtCredit = props.fmtCredit
      if (!advice || advice.items.length === 0) {
        return h('p', { className: 'wbm-adv-empty' }, t('advice.empty'))
      }
      // Items can exist without a credit estimate (for example the context
      // observation, which is a qualitative finding). Only claim "nothing to
      // do" when the list is genuinely empty — the total row is what says
      // whether anything is worth money.
      var rows = []
      for (var i = 0; i < advice.items.length; i += 1) {
        rows.push(h(AdviceRow, { key: advice.items[i].id, item: advice.items[i], t: t, fmtCredit: fmtCredit }))
      }
      var potential = null
      if (advice.potentialCredit !== null && advice.potentialCredit > 0) {
        potential = h(
          'div',
          { className: 'wbm-adv-total' },
          h('span', { className: 'wbm-adv-total-label' }, t('advice.totalLabel')),
          h('strong', { className: 'wbm-adv-total-value' }, fmtCredit(advice.potentialCredit)),
          h('span', { className: 'wbm-adv-total-unit' }, t('advice.unitLabel')),
          advice.potentialShareOfSpend !== null
            ? h(
                'span',
                { className: 'wbm-adv-total-share' },
                t('advice.totalShare', { pct: Math.round(advice.potentialShareOfSpend * 100) })
              )
            : null
        )
      }
      // Concrete next steps derived from the same items. Kept as short bullets
      // because the rows above already explain why; this is the "so do what".
      var steps = []
      for (var si = 0; si < advice.items.length; si += 1) {
        var it = advice.items[si]
        var d = it.detail || {}
        if (it.id === 'context' && isFinite(d.share)) {
          steps.push(t('advice.stepContext', {
            share: Math.round(d.share * 100),
            avg: Math.round((d.avgPromptTokens || 0) / 1000)
          }))
        } else if (it.id === 'model' && d.cheapest) {
          var off = Array.isArray(d.offenders) && d.offenders.length > 0 ? d.offenders[0] : null
          if (off) {
            steps.push(t('advice.stepModel', {
              from: off.model,
              to: d.cheapest.model
            }))
          }
        } else if (it.id === 'cache' && isFinite(d.hitRate)) {
          steps.push(t('advice.stepCache', { hit: Math.round(d.hitRate * 100) }))
        }
      }
      var stepList = steps.length > 0
        ? h('div', { className: 'wbm-adv-steps' },
            h('span', { className: 'wbm-adv-steps-k' }, t('advice.stepsLabel')),
            steps.map(function (s, i) {
              return h('span', { key: 'st' + i, className: 'wbm-adv-step' }, s)
            }))
        : null

      return h(
        'div',
        { className: 'wbm-adv' },
        rows,
        // When items exist but none is priced, say so instead of showing a
        // bare "0 credit" total that reads like "you can save nothing".
        potential !== null ? potential : h('p', { className: 'wbm-adv-empty' }, t('advice.noMoney')),
        stepList,
        h('p', { className: 'wbm-adv-note' }, t('advice.note'))
      )
    }

    /* ------------------------------------------------------------------ *
     * LexiconCard — 上游关键词风控中和的运行时开关
     *
     * 上游会对 system prompt 里的关键词做风控（400 / code 11128），这里给用户
     * 一个随时可关的开关：关掉就完全回到原始请求。上游策略以后变了也不用等
     * 插件更新。
     * ------------------------------------------------------------------ */

    function LexiconCard(props) {
      var t = props.t
      var value = props.value
      var busy = props.busy === true

      if (!value) {
        return h(
          Section,
          { title: t('lexicon.title'), subtitle: t('lexicon.sub'), className: 'wbm-lex' },
          h('p', { className: 'wbm-lex-empty' }, t('lexicon.statsIdle'))
        )
      }

      var config = value.config || {}
      var stats = value.stats || {}
      var enabled = config.enabled !== false
      var patchPresent = value.patchPresent === true
      var hookInstalled = value.hookInstalled === true

      // A compact chip = label + mini switch. Hover shows the full hint via the
      // native title attribute, so the card stays one short strip instead of
      // four tall rows pushing the footer below the fold.
      function chip(key, label, hint, checked, onToggle, disabled) {
        return h(
          'div',
          { className: 'wbm-lex-chip', key: key, 'data-off': disabled ? 'true' : 'false', title: hint },
          h('span', { className: 'wbm-lex-chiplabel' }, label),
          h('button', {
            type: 'button',
            className: 'wbm-lex-switch',
            'data-on': checked ? 'true' : 'false',
            'data-locked': disabled || busy ? 'true' : 'false',
            role: 'switch',
            'aria-checked': checked ? 'true' : 'false',
            'aria-label': label,
            onClick: function () {
              if (disabled || busy) return
              onToggle(!checked)
            },
          },
            h('span', { className: 'wbm-lex-knob' })
          )
        )
      }

      var statusBits = []
      if (!patchPresent) statusBits.push(t('lexicon.patchMissing'))
      if (!hookInstalled) statusBits.push(t('lexicon.hookMissing'))

      var statsText =
        stats.rewrites > 0
          ? t('lexicon.stats', { n: stats.hits || 0, m: stats.injected || 0 })
          : t('lexicon.statsIdle')

      return h(
        Section,
        {
          title: t('lexicon.title'),
          // 无 subtitle：四个芯片各带 title tooltip，省一行高度
          className: 'wbm-lex',
          action: h(
            'span',
            { className: 'wbm-lex-state', 'data-on': enabled ? 'true' : 'false' },
            enabled ? t('lexicon.on') : t('lexicon.off')
          ),
        },
        h(
          'div',
          { className: 'wbm-lex-body' },
          h(
            'div',
            { className: 'wbm-lex-chips' },
            chip('enable', t('lexicon.enable'), t('lexicon.enableHint'), enabled, function (next) {
              props.onToggle({ enabled: next })
            }, false),
            // Secondary switches only make sense while the master switch is on.
            chip('neutralize', t('lexicon.neutralize'), t('lexicon.neutralizeHint'), config.neutralize !== false, function (next) {
              props.onToggle({ neutralize: next })
            }, !enabled),
            chip('ensureSystem', t('lexicon.ensureSystem'), t('lexicon.ensureSystemHint'), config.ensureSystem !== false, function (next) {
              props.onToggle({ ensureSystem: next })
            }, !enabled),
            chip('hideIdentity', t('lexicon.hideIdentity'), t('lexicon.hideIdentityHint'), config.hideIdentity === true, function (next) {
              props.onToggle({ hideIdentity: next })
            }, !enabled),
            // 统计与 chips 同行：它是实时读数，不该单独占一段
            h('span', { className: 'wbm-spacer' }),
            h('span', { className: 'wbm-lex-stats', title: t('lexicon.pathSafe') }, statsText),
            statusBits.length > 0
              ? h(
                  'span',
                  { className: 'wbm-lex-warn' },
                  h('span', null, statusBits.join(' · ')),
                  h('button', {
                    type: 'button',
                    className: 'wbm-btn wbm-btn-ghost',
                    onClick: props.onRepair,
                  }, t('lexicon.repair'))
                )
              : null
          )
        )
      )
    }

    function Section(props) {
      return h(
        'section',
        {
          className: props.className ? 'wbm-card ' + props.className : 'wbm-card',
          style: props.style || undefined
        },
        h(
          'header',
          { className: 'wbm-card-head' },
          h('h2', { className: 'wbm-card-title' }, props.title),
          props.subtitle ? h('span', { className: 'wbm-card-sub' }, props.subtitle) : null,
          h('span', { className: 'wbm-spacer' }),
          props.action || null
        ),
        props.children
      )
    }

    function Stat(props) {
      return h(
        'div',
        { className: 'wbm-stat', title: props.hint || undefined },
        h('span', { className: 'wbm-stat-label' }, props.label),
        h('span', { className: 'wbm-stat-value' }, props.value),
        props.note ? h('span', { className: 'wbm-stat-note' }, props.note) : null
      )
    }

    function State(props) {
      var kind = props.kind || 'loading'
      return h(
        'div',
        { className: 'wbm-state wbm-state-' + kind, role: kind === 'error' ? 'alert' : 'status' },
        h('span', { className: 'wbm-state-dot' }),
        h('span', { className: 'wbm-state-text' }, props.text)
      )
    }

    /**
     * CONTRACT §2.2: `credit: null` (upstream did not report) and `credit: 0`
     * (upstream explicitly reported zero) are different facts and must not look
     * alike. Missing renders the em dash, dimmed and dotted; zero renders "0".
     */
    function CreditValue(props) {
      var bucket = props.bucket || {}
      var t = props.t
      var requests = num(bucket.requests)
      var missing = num(bucket.creditMissing)
      var reported = num(bucket.reported, requests - missing)
      var value = num(bucket.credit)
      var state = reported > 0 ? (value === 0 ? 'zero' : 'value') : 'missing'
      var text = state === 'missing' ? t('common.none') : fmtCredit(value)
      var title = state === 'missing' ? t('overview.missing') : missing > 0 ? t('overview.missing') + ' · ' + fmtInt(missing) : undefined
      return h(
        'span',
        {
          className: 'wbm-credit',
          'data-credit-state': state,
          title: title,
          'aria-label': state === 'missing' ? t('overview.missing') : text
        },
        text
      )
    }

    /* ------------------------------------------------------------------ *
     * Trend chart — hand-written SVG, dual axis (tokens bars / credit line).
     *
     * Height follows the data: a fixed 250px frame around a single day's bar
     * leaves half the viewport empty on a fresh install. Days are what the chart
     * plots, so days drive the frame.
     * ------------------------------------------------------------------ */

    var CHART_W = 760
    var CHART_H = 170
    var CHART_H_SPARSE = 116
    var CHART_PAD = { top: 16, right: 58, bottom: 34, left: 54 }

    /**
     * Chart frame height.
     *
     * Two inputs: how many days actually carry data, and how much vertical room
     * the window gives us. A short viewport keeps the compact frame; a tall one
     * lets the chart take the leftover space instead of leaving a dead band
     * under the last card. Capped so it never becomes the dominant element.
     */
    function chartHeightFor(days, viewportH) {
      var base = CHART_H
      if (Array.isArray(days)) {
        var populated = 0
        for (var i = 0; i < days.length; i += 1) {
          var bucket = days[i] && days[i].bucket
          if (bucket && (num(bucket.totalTokens) > 0 || num(bucket.requests) > 0)) populated += 1
        }
        if (populated <= 2) base = CHART_H_SPARSE
        else if (populated <= 5) base = Math.round((CHART_H_SPARSE + CHART_H) / 2)
      }
      if (!(viewportH > 0)) return base
      // Roughly: give the chart 22% of the window above 900px, capped at 300px.
      var bonus = Math.round(Math.max(0, Math.min(200, (viewportH - 880) * 0.25)))
      return base + bonus
    }

    function niceMax(value) {
      if (!(value > 0) || !isFinite(value)) return 1
      var exponent = Math.floor(Math.log10(value))
      var base = Math.pow(10, exponent)
      var mantissa = value / base
      var step = mantissa <= 1 ? 1 : mantissa <= 2 ? 2 : mantissa <= 5 ? 5 : 10
      return step * base
    }

    function TrendChart(props) {
      var days = fillDays(props.days, props.range)
      var t = props.t

      if (!days || days.length === 0) {
        return h('div', { className: 'wbm-empty-sm' }, t('common.none'))
      }

      var viewportH = typeof window !== 'undefined' && window.innerHeight ? window.innerHeight : 900
      var chartH = chartHeightFor(days, viewportH)
      // Draw at the container's real width in 1:1 units — see useElementWidth.
      var measured = useElementWidth(CHART_W)
      var chartW = measured.width
      var innerW = chartW - CHART_PAD.left - CHART_PAD.right
      var innerH = chartH - CHART_PAD.top - CHART_PAD.bottom
      var count = days.length
      var slot = innerW / count
      var barW = Math.max(6, Math.min(30, slot * 0.52))

      var maxTokens = 1
      var maxCredit = 0
      for (var i = 0; i < count; i += 1) {
        if (days[i].bucket.totalTokens > maxTokens) maxTokens = days[i].bucket.totalTokens
        if (days[i].bucket.credit > maxCredit) maxCredit = days[i].bucket.credit
      }
      var tokenTop = niceMax(maxTokens)
      var creditTop = niceMax(maxCredit)

      var xOf = function (index) {
        return CHART_PAD.left + slot * (index + 0.5)
      }
      var yTokens = function (value) {
        return CHART_PAD.top + innerH - (value / tokenTop) * innerH
      }
      var yCredit = function (value) {
        return CHART_PAD.top + innerH - (value / creditTop) * innerH
      }

      var children = []
      var gridCount = 4
      for (var g = 0; g <= gridCount; g += 1) {
        var ratio = g / gridCount
        var y = CHART_PAD.top + innerH * ratio
        children.push(
          h('line', {
            key: 'grid-' + g,
            x1: CHART_PAD.left,
            x2: CHART_PAD.left + innerW,
            y1: y,
            y2: y,
            stroke: 'var(--dsw-alias-border-l2)',
            'stroke-width': 1,
            'stroke-dasharray': g === gridCount ? '0' : '3 4',
            opacity: g === gridCount ? 0.9 : 0.55
          })
        )
        children.push(
          h(
            'text',
            {
              key: 'lt-' + g,
              x: CHART_PAD.left - 8,
              y: y + 3.5,
              'text-anchor': 'end',
              className: 'wbm-chart-tick'
            },
            fmtTokens(tokenTop * (1 - ratio))
          )
        )
        children.push(
          h(
            'text',
            {
              key: 'rt-' + g,
              x: CHART_PAD.left + innerW + 8,
              y: y + 3.5,
              'text-anchor': 'start',
              className: 'wbm-chart-tick wbm-chart-tick-credit'
            },
            fmtCredit(creditTop * (1 - ratio))
          )
        )
      }

      var labelEvery = Math.max(1, Math.ceil(count / 8))
      for (var b = 0; b < count; b += 1) {
        var day = days[b]
        var barTop = yTokens(day.bucket.totalTokens)
        var barHeight = Math.max(0, CHART_PAD.top + innerH - barTop)
        var barX = xOf(b) - barW / 2
        var tip =
          day.day +
          ' · ' +
          t('trend.tokens') +
          ' ' +
          fmtTokens(day.bucket.totalTokens) +
          ' · ' +
          t('trend.credit') +
          ' ' +
          (num(day.bucket.reported, day.bucket.requests - day.bucket.creditMissing) > 0
            ? fmtCredit(day.bucket.credit)
            : t('overview.missing'))
        children.push(
          h(
            'g',
            { key: 'bar-' + b, className: 'wbm-chart-bar' },
            h('title', null, tip),
            barHeight > 0
              ? h('rect', {
                  x: barX,
                  y: barTop,
                  width: barW,
                  height: barHeight,
                  rx: Math.min(3, barW / 3),
                  fill: 'var(--dsw-alias-brand-primary)',
                  opacity: 0.72
                })
              : null,
            h('rect', {
              x: xOf(b) - slot / 2,
              y: CHART_PAD.top,
              width: slot,
              height: innerH,
              fill: 'transparent'
            })
          )
        )
        if (b % labelEvery === 0) {
          children.push(
            h(
              'text',
              {
                key: 'x-' + b,
                x: xOf(b),
                y: CHART_PAD.top + innerH + 20,
                'text-anchor': 'middle',
                className: 'wbm-chart-tick'
              },
              shortDay(day.day)
            )
          )
        }
      }

      var points = []
      var dots = []
      for (var p = 0; p < count; p += 1) {
        var cx = xOf(p)
        var cy = yCredit(days[p].bucket.credit)
        points.push(cx + ',' + cy)
        dots.push(
          h('circle', {
            key: 'dot-' + p,
            className: 'wbm-chart-dot',
            cx: cx,
            cy: cy,
            r: 2.6,
            fill: 'var(--dsw-alias-state-business-primary)'
          })
        )
      }

      children.push(
        h('polyline', {
          key: 'credit-line',
          className: 'wbm-chart-line',
          points: points.join(' '),
          fill: 'none',
          stroke: 'var(--dsw-alias-state-business-primary)',
          'stroke-width': 2,
          'stroke-linejoin': 'round',
          'stroke-linecap': 'round',
          // Normalises the dash animation so `stroke-dasharray: 1` covers the
          // whole line regardless of its true length.
          pathLength: 1
        })
      )
      children.push(h('g', { key: 'credit-dots' }, dots))

      children.push(
        h('line', {
          key: 'axis-left',
          x1: CHART_PAD.left,
          x2: CHART_PAD.left,
          y1: CHART_PAD.top,
          y2: CHART_PAD.top + innerH,
          stroke: 'var(--dsw-alias-border-l2)',
          'stroke-width': 1
        })
      )
      children.push(
        h('line', {
          key: 'axis-right',
          x1: CHART_PAD.left + innerW,
          x2: CHART_PAD.left + innerW,
          y1: CHART_PAD.top,
          y2: CHART_PAD.top + innerH,
          stroke: 'var(--dsw-alias-border-l2)',
          'stroke-width': 1
        })
      )

      return h(
        'div',
        { className: 'wbm-chart', ref: measured.ref },
        h(
          'svg',
          {
            className: 'wbm-chart-svg',
            viewBox: '0 0 ' + chartW + ' ' + chartH,
            style: { maxHeight: chartH + 'px' },
            preserveAspectRatio: 'xMidYMid meet',
            role: 'img',
            'aria-label': t('trend.title')
          },
          children
        ),
        h(
          'div',
          { className: 'wbm-legend' },
          h('span', { className: 'wbm-legend-item' },
            h('i', { className: 'wbm-legend-bar' }),
            t('trend.tokens')
          ),
          h('span', { className: 'wbm-legend-item' },
            h('i', { className: 'wbm-legend-line' }),
            t('trend.credit')
          )
        )
      )
    }

    /* ------------------------------------------------------------------ *
     * Model table
     * ------------------------------------------------------------------ */

    var MODEL_COLUMNS = [
      { key: 'model', label: 'models.model', align: 'left', numeric: false },
      { key: 'provider', label: 'models.provider', align: 'left', numeric: false },
      { key: 'requests', label: 'models.requests', align: 'right', numeric: true },
      { key: 'promptTokens', label: 'models.prompt', align: 'right', numeric: true },
      { key: 'cacheReadTokens', label: 'models.cacheRead', align: 'right', numeric: true },
      { key: 'completionTokens', label: 'models.completion', align: 'right', numeric: true },
      { key: 'reasoningTokens', label: 'models.reasoning', align: 'right', numeric: true },
      { key: 'totalTokens', label: 'models.total', align: 'right', numeric: true },
      { key: 'credit', label: 'models.credit', align: 'right', numeric: true },
      { key: 'unitPrice', label: 'models.unitPrice', align: 'right', numeric: true }
    ]

    function rowUnitPrice(row) {
      var bucket = row.bucket
      var reported = num(bucket.reported, bucket.requests - bucket.creditMissing)
      if (reported <= 0 || bucket.totalTokens <= 0) return NaN
      return (bucket.credit / bucket.totalTokens) * 1e6
    }

    function sortValue(row, key) {
      if (key === 'model') return row.model.toLowerCase()
      if (key === 'provider') return row.provider.toLowerCase()
      if (key === 'unitPrice') {
        var price = rowUnitPrice(row)
        return isFinite(price) ? price : -1
      }
      return num(row.bucket[key])
    }

    /**
     * Per-account breakdown: who spent how much on which model. The join with
     * nicknames happens here (balance route knows them), so the table shows
     * "187****6221" instead of "buddy-94a6cb86".
     */
    function AccountTable(props) {
      var t = props.t
      var rows = props.rows || []
      var bal = props.balance && Array.isArray(props.balance.value) ? props.balance.value : (props.balance && props.balance.value && Array.isArray(props.balance.value.accounts) ? props.balance.value.accounts : [])
      function nicknameOf(accountId) {
        for (var i = 0; i < bal.length; i += 1) {
          if (bal[i].accountId === accountId && bal[i].nickname) return bal[i].nickname
        }
        return ''
      }
      function remainingOf(accountId) {
        for (var i = 0; i < bal.length; i += 1) {
          if (bal[i].accountId === accountId && isFinite(bal[i].total)) return bal[i].total
        }
        return NaN
      }
      var totalCredit = 0
      for (var i = 0; i < rows.length; i += 1) {
        if (isFinite(rows[i].credit)) totalCredit += rows[i].credit
      }

      var head = h(
        'thead',
        null,
        h(
          'tr',
          null,
          h('th', { className: 'wbm-th-left' }, t('accounts.account')),
          h('th', null, t('accounts.share')),
          h('th', null, t('accounts.requests')),
          h('th', null, t('accounts.tokens')),
          h('th', null, t('accounts.unitPrice')),
          h('th', null, t('accounts.credit')),
          h('th', null, t('accounts.remaining'))
        )
      )
      var body = h(
        'tbody',
        null,
        rows.map(function (row, index) {
          var nickname = nicknameOf(row.accountId)
          var displayName = nickname || row.accountId || t('common.none')
          var share = totalCredit > 0 && isFinite(row.credit) ? row.credit / totalCredit : 0
          var remaining = remainingOf(row.accountId)
          var price = row.derived && isFinite(row.derived.unitPricePerMTok) ? row.derived.unitPricePerMTok : NaN
          return h(
            'tr',
            { key: (row.accountId || 'account') + '\u0000' + index },
            h('td', { className: 'wbm-td-account' },
              h('div', { className: 'wbm-td-main' },
                h('b', { title: row.accountId }, displayName),
                nickname && row.accountId ? h('span', { className: 'wbm-td-sub' }, row.accountId) : null),
              h('div', { className: 'wbm-td-bar' },
                h('div', { className: 'wbm-td-bar-fill', style: { width: (share * 100).toFixed(1) + '%' } }))),
            h('td', null, fmtPct(share)),
            h('td', null, fmtInt(row.requests)),
            h('td', null, fmtTokens(row.totalTokens)),
            h('td', null, isFinite(price) ? fmtPrice(price) : t('common.none')),
            h('td', { className: 'wbm-td-strong' }, fmtCredit(isFinite(row.credit) ? row.credit : 0)),
            h('td', null, isFinite(remaining) ? fmtCredit(remaining) : t('common.none'))
          )
        })
      )
      return h('div', { className: 'wbm-table-wrap' }, h('table', { className: 'wbm-table' }, head, body))
    }

    function ModelTable(props) {
      var t = props.t
      var rows = props.rows
      var sortKey = props.sortKey
      var sortDir = props.sortDir
      var onSort = props.onSort

      var sorted = rows.slice()
      sorted.sort(function (a, b) {
        var left = sortValue(a, sortKey)
        var right = sortValue(b, sortKey)
        var result
        if (typeof left === 'string' || typeof right === 'string') {
          result = String(left) < String(right) ? -1 : String(left) > String(right) ? 1 : 0
        } else {
          result = left - right
        }
        return sortDir === 'asc' ? result : -result
      })

      var head = h(
        'tr',
        null,
        MODEL_COLUMNS.map(function (column) {
          var active = column.key === sortKey
          return h(
            'th',
            {
              key: column.key,
              className: 'wbm-th' + (column.align === 'right' ? ' wbm-right' : '') + (active ? ' wbm-th-on' : ''),
              scope: 'col',
              'aria-sort': active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none'
            },
            h(
              'button',
              {
                type: 'button',
                className: 'wbm-sort',
                onClick: function () {
                  onSort(column.key)
                }
              },
              t(column.label),
              active ? h('span', { className: 'wbm-sort-mark' }, sortDir === 'asc' ? '▲' : '▼') : null
            )
          )
        })
      )

      var body = sorted.map(function (row, index) {
        var bucket = row.bucket
        var price = rowUnitPrice(row)
        return h(
          'tr',
          { key: row.model + '\u0000' + row.provider + '\u0000' + index, className: 'wbm-tr' },
          h('td', { className: 'wbm-td wbm-td-model', title: row.model }, row.model),
          h('td', { className: 'wbm-td wbm-td-provider' }, row.provider || t('common.none')),
          h('td', { className: 'wbm-td wbm-right' }, fmtInt(bucket.requests)),
          h('td', { className: 'wbm-td wbm-right' }, fmtTokens(bucket.promptTokens)),
          h('td', { className: 'wbm-td wbm-right' }, fmtTokens(bucket.cacheReadTokens)),
          h('td', { className: 'wbm-td wbm-right' }, fmtTokens(bucket.completionTokens)),
          h('td', { className: 'wbm-td wbm-right' }, fmtTokens(bucket.reasoningTokens)),
          h('td', { className: 'wbm-td wbm-right wbm-strong' }, fmtTokens(bucket.totalTokens)),
          h('td', { className: 'wbm-td wbm-right' }, h(CreditValue, { bucket: bucket, t: t })),
          h(
            'td',
            { className: 'wbm-td wbm-right' },
            isFinite(price) ? fmtPrice(price) : h('span', { className: 'wbm-na' }, t('common.none'))
          )
        )
      })

      return h(
        'div',
        { className: 'wbm-table-wrap' },
        h('table', { className: 'wbm-table' }, h('thead', null, head), h('tbody', null, body))
      )
    }

    /* ------------------------------------------------------------------ *
     * Motion helpers
     *
     * One orchestrated entrance (hero → ruler → trend → table → balance),
     * a counting hero number, a growing price ruler, bars/lines that draw
     * themselves — all CSS/rAF, all disabled under prefers-reduced-motion.
     * Interaction feedback stays on hover transitions only.
     * ------------------------------------------------------------------ */

    var REDUCED_MOTION_QUERY = '(prefers-reduced-motion: reduce)'

    /**
     * Track an element's real pixel width so an SVG can use 1:1 viewBox units.
     * A fixed viewBox plus \`max-height\` letterboxes the drawing: the SVG box
     * stays 1087px wide while the scaled plot only fills its centre. Measuring
     * the container and drawing at that width removes the dead margins.
     */
    function useElementWidth(initial) {
      var state = useState(initial)
      var width = state[0]
      var setWidth = state[1]
      var ref = useRef(null)
      useEffect(function () {
        var el = ref.current
        if (!el) return undefined
        var apply = function (w) {
          var next = Math.max(240, Math.round(w))
          setWidth(function (prev) { return Math.abs(prev - next) < 2 ? prev : next })
        }
        apply(el.getBoundingClientRect().width)
        if (typeof ResizeObserver !== 'function') {
          var onResize = function () { apply(el.getBoundingClientRect().width) }
          window.addEventListener('resize', onResize)
          return function () { window.removeEventListener('resize', onResize) }
        }
        var ro = new ResizeObserver(function (entries) {
          for (var i = 0; i < entries.length; i += 1) apply(entries[i].contentRect.width)
        })
        ro.observe(el)
        return function () { ro.disconnect() }
      }, [])
      return { ref: ref, width: width }
    }

    function prefersReducedMotion() {
      return typeof window !== 'undefined' &&
        typeof window.matchMedia === 'function' &&
        window.matchMedia(REDUCED_MOTION_QUERY).matches
    }

    /**
     * Count-up hook: animates `target` from its previous value (or 0 on first
     * sight) to the current one with an ease-out. Returns the value to render.
     * Skips the whole thing when the target is not finite or the user asked
     * for reduced motion.
     */
    function useCountUp(target, durationMs) {
      var state = useState(function () {
        return { display: isFinite(target) ? 0 : target, raf: 0 }
      })
      var display = state[0].display
      var setDisplay = state[1]
      var fromRef = useRef(isFinite(target) ? 0 : target)
      useEffect(
        function () {
          if (!isFinite(target)) return undefined
          if (prefersReducedMotion()) {
            fromRef.current = target
            setDisplay({ display: target })
            return undefined
          }
          var from = fromRef.current
          if (from === target) return undefined
          var dur = typeof durationMs === 'number' && durationMs > 0 ? durationMs : 900
          var start = 0
          var raf = 0
          var step = function (ts) {
            if (!start) start = ts
            var p = Math.min(1, (ts - start) / dur)
            var eased = 1 - Math.pow(1 - p, 3)
            var value = from + (target - from) * eased
            if (p < 1) {
              raf = requestAnimationFrame(step)
            } else {
              value = target
            }
            setDisplay({ display: value })
          }
          raf = requestAnimationFrame(step)
          return function () {
            cancelAnimationFrame(raf)
            fromRef.current = target
          }
        },
        [target]
      )
      return display
    }

    /**
     * Staggered entrance: flips a `data-in` attribute on the panel root one
     * frame after mount; sections animate via `[data-in]` CSS with per-section
     * `--stagger` delays. Runs once per mount, never on data refreshes.
     */
    function useEntrance() {
      var state = useState(false)
      var entered = state[0]
      var setEntered = state[1]
      useEffect(function () {
        if (prefersReducedMotion()) return undefined
        var raf = requestAnimationFrame(function () {
          requestAnimationFrame(function () {
            setEntered(true)
          })
        })
        return function () {
          cancelAnimationFrame(raf)
        }
      }, [])
      return entered
    }

    /* ------------------------------------------------------------------ *
     * Panel view (pure: everything it needs arrives through props, so the
     * loading / empty / error / ready states are all directly testable).
     * ------------------------------------------------------------------ */

function PanelView(props) {
      var t = props.t
      var range = props.range
      var summary = props.summary
      var balance = props.balance
      var patch = props.patch
      var sortKey = props.sortKey
      var sortDir = props.sortDir

      // PanelView receives the host's raw day buckets (flat: credit/requests on
      // the entry itself). Other places in the file use normalizeDays() output,
      // which wraps them as { day, bucket }. Accept both so this cannot silently
      // read 0 — that bug already hid the "busiest day" scenario once.
      function dayCreditOf(entry) {
        if (!entry || typeof entry !== 'object') return 0
        var v = entry.bucket && typeof entry.bucket === 'object' ? entry.bucket.credit : entry.credit
        return isFinite(v) ? v : 0
      }
      function dayRequestsOf(entry) {
        if (!entry || typeof entry !== 'object') return 0
        var v = entry.bucket && typeof entry.bucket === 'object' ? entry.bucket.requests : entry.requests
        return isFinite(v) ? v : 0
      }

      var data = summary.value
      var totals = data ? data.totals : emptyBucket()
      var derived = data ? data.derived : derive(emptyBucket(), null)
      var days = data ? data.days : []
      var models = data ? data.models : []
      var accounts = data && Array.isArray(data.accounts) ? data.accounts : []
      var modelValue = data && Array.isArray(data.modelValue) ? data.modelValue : []
      var drivers = data ? data.drivers : null
      var advice = data ? normalizeAdvice(data.advice) : null
      var history = data ? normalizeHistory(data.history) : null
      var hourly = data ? normalizeHourly(data.hourly) : null

      // Account pool from channel-pack — the source of truth for "which account
      // will OFM actually use", as opposed to our own spend ledger.
      var poolData = props.pool && props.pool.value ? props.pool.value : null
      var poolAccounts = poolData && Array.isArray(poolData.accounts) ? poolData.accounts : []
      var poolError = props.pool && props.pool.status === 'error' ? props.pool.error : null
      var poolLimits = props.pool && props.pool.limits ? props.pool.limits : {}
      var testResult = props.testResult || { status: 'idle', accountId: '', value: null, error: null }
      var clock = props.clock || Date.now()
      // The model the panel offers to test. Kept as a constant: the card is a
      // health check for the model this user actually runs.
      var TEST_MODEL = 'deepseek-v4.1-flash'
      var activeAccountId = ''
      for (var pai = 0; pai < poolAccounts.length; pai += 1) {
        if (poolAccounts[pai].enabled) {
          // Only a single enabled account means the choice is unambiguous.
          if (activeAccountId === '') activeAccountId = poolAccounts[pai].id
          else activeAccountId = '__multiple__'
        }
      }

      var entered = useEntrance()
      var credit = isFinite(totals.credit) ? totals.credit : 0
      var animatedCredit = useCountUp(credit, 1000)
      var showModels = useState(false)
      var modelsOpen = showModels[0]
      var setModelsOpen = showModels[1]

      var rangeButtons = [
        { days: 1, label: 'range.today' },
        { days: 7, label: 'range.d7' },
        { days: 30, label: 'range.d30' }
      ]

      var patchState = patch.value ? patch.value.state : 'unknown'
      var patchLabel =
        patchState === 'installed'
          ? t('patch.installed')
          : patchState === 'drift'
            ? t('patch.drift')
            : t('patch.missing')

      /* ---------- balance lookup (nickname + remaining per account) ---------- */
      var balAccounts =
        balance.value && Array.isArray(balance.value.accounts) ? balance.value.accounts : []
      function balOf(accountId) {
        for (var i = 0; i < balAccounts.length; i += 1) {
          if (balAccounts[i].accountId === accountId) return balAccounts[i]
        }
        return null
      }

      /* ---------- account rows: the "who" answer ---------- */
      var totalCredit = 0
      for (var ci = 0; ci < accounts.length; ci += 1) {
        if (isFinite(accounts[ci].credit)) totalCredit += accounts[ci].credit
      }
      // A share figure only carries information once there is something to
      // compare against. With a single account it is always 100%, so the
      // percentage and its full-width bar are dropped rather than shown as
      // noise — the row then reads as one clean line of facts.
      // Share is only comparable with 2+ accounts, but the gradient bar is
      // worth keeping: it now encodes balance burn (used / total of the
      // account's live credit packages), which is meaningful even for a single
      // account and is the number a user actually watches.
      var showShare = accounts.length > 1
      // Build one row per account in the pool. Accounts that actually served
      // traffic lead (they are the live facts); the rest follow by balance, so
      // "what is waiting in reserve" is visible without leaving the panel.
      var spentById = {}
      for (var si = 0; si < accounts.length; si += 1) {
        spentById[accounts[si].accountId] = accounts[si]
      }
      var poolRows = []
      var seenIds = {}
      for (var ra = 0; ra < accounts.length; ra += 1) {
        var accA = accounts[ra]
        if (!accA.accountId || seenIds[accA.accountId]) continue
        seenIds[accA.accountId] = true
        poolRows.push({ accountId: accA.accountId, provider: accA.provider, stats: accA, balance: balOf(accA.accountId), spending: true })
      }
      for (var rb = 0; rb < balAccounts.length; rb += 1) {
        var accB = balAccounts[rb]
        if (!accB.accountId || seenIds[accB.accountId]) continue
        seenIds[accB.accountId] = true
        poolRows.push({ accountId: accB.accountId, provider: accB.provider, stats: null, balance: accB, spending: false })
      }
      // Reserve accounts sorted by remaining balance, richest first.
      var reserveRows = poolRows.filter(function (r) { return !r.spending })
      reserveRows.sort(function (a, b) {
        var av = a.balance && isFinite(a.balance.total) ? a.balance.total : -1
        var bv = b.balance && isFinite(b.balance.total) ? b.balance.total : -1
        return bv - av
      })
      poolRows = poolRows.filter(function (r) { return r.spending }).concat(reserveRows)

      // Share only means something when more than one account has real spend.
      var spendingCount = accounts.length
      var showShare = spendingCount > 1

      var accountRows = poolRows.map(function (row, index) {
        var account = row.stats
        var bal = row.balance
        var accountId = row.accountId
        var nickname = bal && bal.nickname ? bal.nickname : ''
        var label = nickname || accountId || t('common.none')
        var spentCredit = account && isFinite(account.credit) ? account.credit : 0
        var share = totalCredit > 0 && account && isFinite(account.credit) ? account.credit / totalCredit : 0
        var remaining = bal && isFinite(bal.total) ? bal.total : NaN
        var price = account && account.derived && isFinite(account.derived.unitPricePerMTok)
          ? account.derived.unitPricePerMTok
          : NaN
        // Only accounts that channel-pack manages for THIS provider can be
        // switched; other providers' accounts merely appear in the balance list.
        var isInPool = false
        for (var pqi = 0; pqi < poolAccounts.length; pqi += 1) {
          if (poolAccounts[pqi].id === accountId) { isInPool = true; break }
        }
        var isActivePoolAccount = activeAccountId === accountId
        var isSwitchingThis = props.switching === accountId

        // Cooldown for the model this card tests, recomputed against the live
        // clock so the label counts down without extra requests.
        var myLimits = poolLimits[accountId] || []
        var myLimit = null
        for (var mli = 0; mli < myLimits.length; mli += 1) {
          if (myLimits[mli].modelId === TEST_MODEL) { myLimit = myLimits[mli]; break }
        }
        var limitRemainingMs = myLimit ? Math.max(0, myLimit.resetAt - clock) : 0
        var limitActive = limitRemainingMs > 0

        var isTestingThis = testResult.status === 'running' && testResult.accountId === accountId
        var myTest = testResult.accountId === accountId && testResult.status !== 'running' ? testResult : null
        // Balance burn: how much of this account's live credit packages has
        // been consumed. Active packages only — expired ones would inflate the
        // denominator with quota that can no longer be spent.
        var burn = (function () {
          if (!bal || !Array.isArray(bal.packages)) return null
          var used = 0
          var total = 0
          for (var pi = 0; pi < bal.packages.length; pi += 1) {
            var pkg = bal.packages[pi]
            if (!pkg || pkg.active !== true) continue
            var pUsed = num(pkg.used)
            var pTotal = num(pkg.total)
            if (!isFinite(pUsed) || !isFinite(pTotal) || pTotal <= 0) continue
            used += pUsed
            total += pTotal
          }
          if (total <= 0) return null
          var ratio = Math.min(1, Math.max(0, used / total))
          return {
            ratio: ratio,
            level: ratio >= 0.85 ? 'high' : ratio >= 0.6 ? 'mid' : 'low',
            title: t('accounts.burnTitle', {
              used: fmtCredit(used),
              total: fmtCredit(total),
              pct: fmtPct(ratio)
            })
          }
        })()
        return h(
          'div',
          {
            key: accountId + index,
            className: 'wbm-acc',
            'data-state': row.spending ? 'spending' : 'reserve'
          },
          h(
            'div',
            { className: 'wbm-acc-line' },
            h('span', {
              className: 'wbm-dot ' + (row.spending ? 'wbm-dot-ok' : 'wbm-dot-idle')
            }),
            h('span', { className: 'wbm-acc-name', title: accountId }, label),
            // Inline rename: click ✎ to turn the name into an input. Kept
            // inline (no modal) because the panel is a dense dashboard and a
            // dialog would cover the very numbers the user is renaming against.
            isInPool
              ? (props.renaming === accountId
                  ? h('input', {
                      className: 'wbm-acc-input',
                      type: 'text',
                      value: props.renameDraft,
                      maxLength: 40,
                      autoFocus: true,
                      placeholder: t('rename.placeholder'),
                      'aria-label': t('rename.action'),
                      onChange: function (event) {
                        props.onRenameDraft(event.target.value)
                      },
                      onKeyDown: function (event) {
                        if (event.key === 'Enter') props.onRenameSubmit()
                        else if (event.key === 'Escape') props.onRenameCancel()
                      },
                      onBlur: function () {
                        props.onRenameSubmit()
                      },
                    })
                  : h('button', {
                      type: 'button',
                      className: 'wbm-acc-rename',
                      title: t('rename.hint'),
                      'aria-label': t('rename.action'),
                      onClick: function () {
                        props.onRename(accountId, nickname)
                      },
                    }, '✎'))
              : null,
            row.provider ? h('span', { className: 'wbm-tag' }, row.provider) : null,
            row.spending ? null : h('span', { className: 'wbm-acc-idle' }, t('accounts.idle')),
            showShare && row.spending
              ? h('span', { className: 'wbm-acc-share' }, fmtPct(share))
              : null,
            h('span', { className: 'wbm-spacer' }),
            h(
              'span',
              { className: 'wbm-acc-credit' },
              row.spending
                ? fmtCredit(spentCredit)
                : fmtCredit(isFinite(remaining) ? remaining : 0)
            ),
            h('span', { className: 'wbm-acc-unit' },
              row.spending ? t('hero.unit') : t('accounts.remainUnit'))
          ),
          burn
            ? h(
                'div',
                { className: 'wbm-acc-bar', title: burn.title },
                h('div', {
                  className: 'wbm-acc-fill',
                  'data-level': burn.level,
                  style: { width: (burn.ratio * 100).toFixed(1) + '%' }
                })
              )
            : null,
          // Cooldown + live test, shown for pool accounts only.
          isInPool
            ? h(
                'div',
                { className: 'wbm-acc-probe' },
                limitActive
                  ? h(
                      'span',
                      { className: 'wbm-limit-badge' },
                      t('accounts.limitActive', { min: fmtMinutes(limitRemainingMs) })
                    )
                  : myLimit
                    ? h('span', { className: 'wbm-limit-badge wbm-is-clear' }, t('accounts.limitClear'))
                    : null,
                h(
                  'button',
                  {
                    type: 'button',
                    className: 'wbm-btn wbm-btn-ghost wbm-acc-test-btn',
                    disabled: isTestingThis,
                    title: t('accounts.testHint', { model: TEST_MODEL }),
                    onClick: function () { props.onTestAccount(accountId, TEST_MODEL) }
                  },
                  isTestingThis ? t('accounts.testing') : t('accounts.testNow', { model: TEST_MODEL })
                ),
                myTest && myTest.status === 'done'
                  ? h(
                      'span',
                      {
                        className: 'wbm-test-result ' + (myTest.value && myTest.value.ok ? 'wbm-is-ok' : 'wbm-is-fail'),
                        title: myTest.value && myTest.value.message ? myTest.value.message : ''
                      },
                      myTest.value && myTest.value.ok
                        ? t('accounts.testOk', { ms: Math.round(myTest.value.elapsedMs || 0) })
                        : t('accounts.testFail')
                    )
                  : null,
                myTest && myTest.status === 'error'
                  ? h('span', { className: 'wbm-test-result wbm-is-fail', title: myTest.error || '' }, t('accounts.testFail'))
                  : null
              )
            : null,
          // Switcher: clicking a row makes it the only enabled account.
          props.onSwitchAccount !== undefined && isInPool && poolAccounts.length > 1
            ? h(
                'div',
                { className: 'wbm-acc-switch' },
                isActivePoolAccount
                  ? h('span', { className: 'wbm-acc-active' }, t('accounts.activeBadge'))
                  : h(
                      'button',
                      {
                        type: 'button',
                        className: 'wbm-btn wbm-btn-ghost wbm-acc-switch-btn',
                        disabled: isSwitchingThis,
                        onClick: function () { props.onSwitchAccount(accountId) }
                      },
                      isSwitchingThis ? t('accounts.switching') : t('accounts.switchTo')
                    )
              )
            : null,
          h(
            'div',
            { className: 'wbm-acc-meta' },
            row.spending && account
              ? h('span', null, t('accounts.requests') + ' ' + fmtInt(account.requests))
              : null,
            row.spending && account
              ? h('span', null, t('accounts.tokens') + ' ' + fmtTokens(account.totalTokens))
              : null,
            isFinite(price) ? h('span', null, t('accounts.unitPrice') + ' ' + fmtPrice(price)) : null,
            isFinite(remaining)
              ? h('span', { className: 'wbm-acc-rem' },
                  t('accounts.remaining') + ' ' + fmtCredit(remaining))
              : null
          )
        )
      })

      /* ---------- cost chain: turn the numbers into one readable sentence ---- */
      var chainParts = []
      if (drivers && drivers.reportedSamples > 0) {
        if (isFinite(drivers.avgPromptTokens)) {
          chainParts.push(
            h('div', { className: 'wbm-chain-step', key: 'ctx' },
              h('span', { className: 'wbm-chain-k' }, t('chain.step1')),
              h('span', { className: 'wbm-chain-v' }, fmtTokens(drivers.avgPromptTokens)),
              h('span', { className: 'wbm-chain-u' }, t('chain.step1Unit')))
          )
        }
        if (isFinite(drivers.creditPerRequest)) {
          chainParts.push(h('span', { className: 'wbm-chain-arrow', key: 'a1' }, '\u2192'))
          chainParts.push(
            h('div', { className: 'wbm-chain-step', key: 'per' },
              h('span', { className: 'wbm-chain-k' }, t('chain.step2')),
              h('span', { className: 'wbm-chain-v' }, fmtCredit(drivers.creditPerRequest)),
              h('span', { className: 'wbm-chain-u' }, t('chain.step2Unit')))
          )
        }
        if (isFinite(drivers.burnRatePerHour)) {
          chainParts.push(h('span', { className: 'wbm-chain-arrow', key: 'a2' }, '\u2192'))
          chainParts.push(
            h('div', { className: 'wbm-chain-step', key: 'burn' },
              h('span', { className: 'wbm-chain-k' }, t('chain.step3')),
              h('span', { className: 'wbm-chain-v' }, fmtCredit(drivers.burnRatePerHour)),
              h('span', { className: 'wbm-chain-u' }, t('chain.step3Unit')))
          )
        }
      }

      /* Decision line under the model ranking: the ranking alone says which is
       * cheaper, but not whether it is worth switching. This states the actual
       * delta per 1M tokens so the choice is concrete. */
      var modelValueNote = null
      if (modelValue.length >= 2) {
        var best = modelValue[0]
        var second = modelValue[1]
        // modelValue rows carry unitPricePerMTok at the top level (host
        // normalizeModelValue puts it there), not under a derived block.
        var bestPrice = best && isFinite(best.unitPricePerMTok) ? best.unitPricePerMTok : NaN
        var secondPrice = second && isFinite(second.unitPricePerMTok) ? second.unitPricePerMTok : NaN
        if (isFinite(bestPrice) && isFinite(secondPrice) && secondPrice > bestPrice) {
          var gap = secondPrice - bestPrice
          var gapRatio = secondPrice / bestPrice
          modelValueNote = h('div', { className: 'wbm-mv-note' },
            h('span', { className: 'wbm-mv-note-k' }, t('modelValue.gapLabel')),
            h('span', { className: 'wbm-mv-note-v' },
              fmtPrice(gap) + ' / 1M token'),
            h('span', { className: 'wbm-mv-note-sub' },
              t('modelValue.gapDetail', {
                ratio: trimNum(gapRatio, 1),
                best: best.model || '',
                second: second.model || ''
              })))
        }
      }

      var chainNotes = []
      if (drivers && drivers.contextGrowth && isFinite(drivers.contextGrowth.ratio) && drivers.contextGrowth.ratio > 1.01) {
        chainNotes.push(
          h('div', { className: 'wbm-chain-note wbm-chain-warn', key: 'grow' },
            h('span', null, t('chain.growth', { ratio: trimNum(drivers.contextGrowth.ratio, 1) })),
            h('span', { className: 'wbm-chain-sub' },
              t('chain.growthDetail', {
                first: fmtTokens(drivers.contextGrowth.first),
                last: fmtTokens(drivers.contextGrowth.last)
              })))
        )
      }
      if (drivers && isFinite(drivers.cacheSavedMultiple) && drivers.cacheSavedMultiple > 1) {
        chainNotes.push(
          h('div', { className: 'wbm-chain-note wbm-chain-ok', key: 'save' },
            h('span', null, t('chain.saved', { ratio: trimNum(drivers.cacheSavedMultiple, 0) })),
            h('span', { className: 'wbm-chain-sub' },
              t('chain.savedDetail', {
                cold: fmtCredit(drivers.coldEquivalentCredit),
                actual: fmtCredit(drivers.actualCredit)
              })))
        )
      }
      if (isFinite(derived.coldUnitPrice) || isFinite(derived.hotUnitPrice)) {
        chainNotes.push(
          h('div', { className: 'wbm-chain-note', key: 'price' },
            h('span', null,
              t('chain.cold') + ' ' + fmtPrice(derived.coldUnitPrice) + '  ' +
              t('chain.hot') + ' ' + fmtPrice(derived.hotUnitPrice)),
            h('span', { className: 'wbm-chain-sub' }, t('chain.priceUnit')))
        )
      }

      /* ---------- runway: "how long will the balance last" ---------- *
       * The one question the numbers are supposed to answer. It needs three
       * inputs: remaining credits (balance route), the burn rate (drivers), and
       * honesty about how much data the rate rests on — a 30-minute sample can
       * swing 3x, so the confidence label is part of the number, not decoration. */
      // Runway, two scopes side by side.
      //
      // The account pool is a relay: when one account hits its limit the next
      // takes over, so both numbers are real answers to different questions.
      //   • current  — "how long can I keep going without touching another
      //                account" (what governs right now)
      //   • pool     — "how long is all my remaining balance good for" (what
      //                governs after the switch)
      // Reporting only one of them is always wrong in one direction.
      var spendingIds = {}
      for (var ai = 0; ai < accounts.length; ai += 1) {
        if (accounts[ai].accountId) spendingIds[accounts[ai].accountId] = true
      }

      var currentRemain = 0
      var currentKnown = false
      var poolRemain = 0
      var poolKnown = false
      var poolAccounts = 0
      for (var bi = 0; bi < balAccounts.length; bi += 1) {
        var balAcct = balAccounts[bi]
        if (!isFinite(balAcct.total)) continue
        poolRemain += balAcct.total
        poolKnown = true
        poolAccounts += 1
        if (spendingIds[balAcct.accountId]) {
          currentRemain += balAcct.total
          currentKnown = true
        }
      }

      // The model actually driving this range's price — read from the same
      // models rollup the table shows, so the note never names a stale model.
      var topModelName = ''
      var topModelTokens = -1
      for (var mi = 0; mi < models.length; mi += 1) {
        var mt = num(models[mi].totalTokens)
        if (mt > topModelTokens) {
          topModelTokens = mt
          topModelName = models[mi].model || ''
        }
      }

      var burnRate = drivers && isFinite(drivers.burnRatePerHour) ? drivers.burnRatePerHour : NaN
      var burnConfidence = drivers && typeof drivers.burnConfidence === 'string' ? drivers.burnConfidence : 'none'
      var canRate = isFinite(burnRate) && burnRate > 0
      var currentHours = currentKnown && canRate ? currentRemain / burnRate : NaN
      var poolHours = poolKnown && canRate ? poolRemain / burnRate : NaN

      function formatSpan(hours) {
        if (!isFinite(hours)) return null
        if (hours >= 24) return t('runway.days', { days: trimNum(hours / 24, 1) })
        if (hours >= 1) return t('runway.hours', { hours: trimNum(hours, 1) })
        return t('runway.lessThanHour')
      }

      var tokensPerCredit =
        isFinite(totals.credit) && totals.credit > 0 ? totals.totalTokens / totals.credit : NaN
      var creditPerRequest =
        isFinite(totals.credit) && totals.requests > 0 ? totals.credit / totals.requests : NaN

      /* ---------- burn breakdown ---------- *
       * Fills the vertical gap between the causal chain and its footnotes.
       * Answers "94.77 credit/hour means what, in tokens and calls?" — the
       * question the chain raises but does not answer. */
      var burnBreakdown = null
      var hourlyTokens = NaN
      var hourlyRequests = NaN
      var dailyCredit = NaN
      if (isFinite(burnRate) && burnRate > 0 && isFinite(tokensPerCredit)) {
        hourlyTokens = burnRate * tokensPerCredit
      }
      if (isFinite(burnRate) && burnRate > 0 && isFinite(creditPerRequest) && creditPerRequest > 0) {
        hourlyRequests = burnRate / creditPerRequest
      }
      if (isFinite(burnRate) && burnRate > 0) dailyCredit = burnRate * 24

      if (isFinite(hourlyTokens) || isFinite(hourlyRequests)) {
        var bbRows = []
        if (isFinite(hourlyTokens)) {
          bbRows.push(h('div', { className: 'wbm-bb-row', key: 'tok' },
            h('span', { className: 'wbm-bb-k' }, t('bb.tokensPerHour')),
            h('span', { className: 'wbm-spacer' }),
            h('span', { className: 'wbm-bb-v' }, fmtTokens(hourlyTokens))))
        }
        if (isFinite(hourlyRequests)) {
          bbRows.push(h('div', { className: 'wbm-bb-row', key: 'req' },
            h('span', { className: 'wbm-bb-k' }, t('bb.requestsPerHour')),
            h('span', { className: 'wbm-spacer' }),
            h('span', { className: 'wbm-bb-v' }, fmtInt(Math.round(hourlyRequests)))))
        }
        if (isFinite(dailyCredit)) {
          bbRows.push(h('div', { className: 'wbm-bb-row', key: 'day' },
            h('span', { className: 'wbm-bb-k' }, t('bb.creditPerDay')),
            h('span', { className: 'wbm-spacer' }),
            h('span', { className: 'wbm-bb-v wbm-bb-warn' }, fmtCredit(dailyCredit))))
        }
        // A visual scale: how much of a day's 1000-credit mental unit is burned.
        var dayBarPct = isFinite(dailyCredit)
          ? Math.max(2, Math.min(100, Math.round((dailyCredit / Math.max(dailyCredit, 1000)) * 100)))
          : 0
        burnBreakdown = h('div', { className: 'wbm-bb' },
          h('div', { className: 'wbm-bb-head' }, t('bb.title')),
          bbRows,
          isFinite(dailyCredit)
            ? h('div', { className: 'wbm-bb-bar' },
                h('div', { className: 'wbm-bb-fill', style: { width: dayBarPct + '%' } }))
            : null)
      }


      // Headline = the pool (what the balance is worth); the sub-line = the
      // account actually serving traffic right now.
      var chainBody =
        chainParts.length > 0
          ? h(React.Fragment, null,
              h('div', { className: 'wbm-chain-row' }, chainParts),
              burnBreakdown,
              chainNotes.length > 0 ? h('div', { className: 'wbm-chain-notes' }, chainNotes) : null)
          : h('div', { className: 'wbm-empty-sm' }, t('chain.empty'))



      var headlineHours = poolKnown ? poolHours : currentHours
      var headlineRemain = poolKnown ? poolRemain : currentRemain
      var headlineKnown = poolKnown || currentKnown
      var headlineLabel = poolKnown ? t('runway.scopePool') : t('runway.scopeSpending')

      var runwayValue = formatSpan(headlineHours)
      var tokensLeft = headlineKnown && isFinite(tokensPerCredit) ? headlineRemain * tokensPerCredit : NaN
      var requestsLeft =
        headlineKnown && isFinite(creditPerRequest) && creditPerRequest > 0
          ? headlineRemain / creditPerRequest
          : NaN

      /* ---------- runway scenarios ---------- *
       * Three "how long can I keep going" answers instead of one. The card had
       * ~150px of空白 below the headline, and a single number does not tell the
       * user what changes if they behave differently. */
      var scenarioBody = null
      if (headlineKnown && canRate && isFinite(burnRate) && burnRate > 0) {
        var rows = []
        // 1) Current pace (the headline number, restated as a row so the three
        //    scenarios are directly comparable).
        rows.push({ id: 'now', hours: headlineRemain / burnRate, tone: 'base' })
        // 2) Full tilt: the busiest *hour* actually observed. Using the busiest
        //    day divided by 24 under-reports badly when only part of the window
        //    has traffic (it fell below the measured average and the row never
        //    rendered). The peak hour is a real observed rate, so it works as an
        //    upper bound.
        var peakRate = hourly && isFinite(hourly.maxHourCredit) ? hourly.maxHourCredit : NaN
        if (isFinite(peakRate) && peakRate > burnRate) {
          rows.push({ id: 'peak', hours: headlineRemain / peakRate, tone: 'worst' })
        }
        // 3) Half the context: the bill is dominated by prompt tokens, and
        //    cached prompt tokens are cheap but not free. Halving context
        //    roughly halves the marginal credit per request, so the rate
        //    drops by about half — labelled as an estimate, not a measurement.
        rows.push({ id: 'lean', hours: headlineRemain / (burnRate * 0.5), tone: 'best' })

        var maxHours = 0
        for (var ri = 0; ri < rows.length; ri += 1) {
          if (isFinite(rows[ri].hours) && rows[ri].hours > maxHours) maxHours = rows[ri].hours
        }
        scenarioBody = h(
          'div',
          { className: 'wbm-scen' },
          rows.map(function (r) {
            var pct = maxHours > 0 && isFinite(r.hours) ? Math.max(4, Math.round((r.hours / maxHours) * 100)) : 0
            return h(
              'div',
              { key: r.id, className: 'wbm-scen-row', 'data-tone': r.tone },
              h('span', { className: 'wbm-scen-k' },
                // Literal t(...) calls: the locale audit only sees string
                // literals, so a computed key would silently escape it.
                r.id === 'now' ? t('scenario.now') : r.id === 'peak' ? t('scenario.peak') : t('scenario.lean')),
              h('div', { className: 'wbm-scen-bar' },
                h('div', { className: 'wbm-scen-fill', style: { width: pct + '%' } })),
              h('span', { className: 'wbm-scen-v' }, formatSpan(r.hours) || t('common.none'))
            )
          }),
          h('p', { className: 'wbm-scen-note' }, t('scenario.note'))
        )
      }

      var runwayBody = h(
        'div',
        { className: 'wbm-runway' },
        h(
          'div',
          { className: 'wbm-runway-main' },
          h('span', { className: 'wbm-runway-k' }, t('runway.label')),
          h(
            'span',
            { className: 'wbm-runway-v' },
            runwayValue !== null
              ? runwayValue
              : canRate
                ? t('runway.balanceUnknown')
                : t('runway.noRate')
          ),
          isFinite(headlineHours)
            ? h('span', { className: 'wbm-runway-basis' },
                t('runway.basis', {
                  remain: fmtCredit(headlineRemain),
                  rate: fmtCredit(burnRate)
                }))
            : null,
          h('span', { className: 'wbm-runway-scope' },
            headlineLabel + ' \u00b7 ' + fmtInt(poolAccounts) + ' ' + t('runway.accountsUnit')),
          // The account currently burning, called out separately because that
          // is the limit you hit first.
          currentKnown && poolKnown && currentRemain !== poolRemain
            ? h('span', { className: 'wbm-runway-current' },
                t('runway.currentOnly', {
                  span: formatSpan(currentHours) || t('common.none'),
                  remain: fmtCredit(currentRemain)
                }))
            : null,
          isFinite(derived.unitPrice) && isFinite(tokensPerCredit)
            ? h('span', { className: 'wbm-runway-note' },
                t('runway.unitPriceNow', {
                  price: fmtPrice(derived.unitPrice),
                  model: topModelName
                }) +
                ' \u00b7 ' +
                t('runway.per1000', { tokens: fmtTokens(1000 * tokensPerCredit) }))
            : null,
          h(
            'div',
            { className: 'wbm-runway-grid' },
            h('div', { className: 'wbm-rg' },
              h('span', { className: 'wbm-rg-v' }, isFinite(tokensLeft) ? fmtTokens(tokensLeft) : t('common.none')),
              h('span', { className: 'wbm-rg-k' }, t('runway.tokensLeft'))),
            h('div', { className: 'wbm-rg' },
              h('span', { className: 'wbm-rg-v' }, isFinite(requestsLeft) ? fmtInt(Math.floor(requestsLeft)) : t('common.none')),
              h('span', { className: 'wbm-rg-k' }, t('runway.requestsLeft')))
          )
        ),
        h(
          'div',
          { className: 'wbm-runway-side' },
          h('span', { className: 'wbm-conf', 'data-level': burnConfidence },
            t('runway.confidence.' + burnConfidence)),
          headlineKnown ? h('span', { className: 'wbm-runway-remain' }, fmtCredit(headlineRemain)) : null
        )
      )

      // Scenarios ride below the runway block, filling the card's vertical space.
      if (scenarioBody !== null) {
        runwayBody = h('div', { className: 'wbm-runway-wrap' }, runwayBody, scenarioBody)
      }

      /* ---------- insight: one sentence that sums up the whole panel -------- */
      var insightBits = []
      if (drivers && drivers.reportedSamples > 0) {
        if (isFinite(drivers.cacheHitRate)) {
          insightBits.push(t('insight.cache', {
            pct: fmtPct(drivers.cacheHitRate),
            price: isFinite(derived.unitPrice) ? fmtPrice(derived.unitPrice) : t('common.none')
          }))
        }
        if (isFinite(drivers.avgPromptTokens) && isFinite(drivers.creditPerRequest)) {
          insightBits.push(t('insight.context', {
            tokens: fmtTokens(drivers.avgPromptTokens),
            cost: fmtCredit(drivers.creditPerRequest)
          }))
        }
      }
      var insightBody =
        insightBits.length > 0
          ? h('div', { className: 'wbm-insight' }, insightBits.join('，') + '。')
          : null

      /* ---------- rhythm: today / period / projected month ---------- *
       * The hero's right half was empty. These three answer the question the
       * big number raises: how fast is it going, and where does it land. All
       * three are derived from data already in hand — no extra requests. */
      var rhythmBody = null
      var todayBucket = null
      var todayKey = null
      if (Array.isArray(days) && days.length > 0) {
        // days are day buckets; the newest one is today (UTC+8).
        var lastDay = days[days.length - 1]
        if (lastDay) {
          todayBucket = {
            credit: dayCreditOf(lastDay),
            requests: dayRequestsOf(lastDay)
          }
          todayKey = lastDay.day
        }
      }
      var monthProjection = null
      var dayCount = isFinite(totals.credit) && totals.credit > 0 ? days.length : 0
      if (dayCount > 0) {
        var elapsedDays = Math.max(1, dayCount)
        var nowDate = new Date(clock)
        var daysInMonth = new Date(nowDate.getFullYear(), nowDate.getMonth() + 1, 0).getDate()
        var avgPerDay = totals.credit / elapsedDays
        monthProjection = avgPerDay * daysInMonth
      }
      var burnRate = drivers && isFinite(drivers.burnRatePerHour) ? drivers.burnRatePerHour : NaN

      if (todayBucket !== null || monthProjection !== null) {
        var rhythmCells = []
        if (todayBucket !== null) {
          rhythmCells.push(
            h('div', { className: 'wbm-rhythm-cell', key: 'today' },
              h('span', { className: 'wbm-rhythm-k' }, t('rhythm.today')),
              h('span', { className: 'wbm-rhythm-v' }, fmtCredit(todayBucket.credit)),
              h('span', { className: 'wbm-rhythm-u' }, t('rhythm.unitCredit')))
          )
          rhythmCells.push(
            h('div', { className: 'wbm-rhythm-cell', key: 'todayReq' },
              h('span', { className: 'wbm-rhythm-k' }, t('rhythm.todayReq')),
              h('span', { className: 'wbm-rhythm-v' }, fmtInt(todayBucket.requests)),
              h('span', { className: 'wbm-rhythm-u' }, t('rhythm.unitReq')))
          )
        }
        if (isFinite(burnRate) && burnRate > 0) {
          rhythmCells.push(
            h('div', { className: 'wbm-rhythm-cell', key: 'rate' },
              h('span', { className: 'wbm-rhythm-k' }, t('rhythm.rate')),
              h('span', { className: 'wbm-rhythm-v' }, fmtCredit(burnRate)),
              h('span', { className: 'wbm-rhythm-u' }, t('rhythm.perHour')))
          )
        }
        if (monthProjection !== null) {
          rhythmCells.push(
            h('div', { className: 'wbm-rhythm-cell', key: 'month', 'data-tone': 'forecast' },
              h('span', { className: 'wbm-rhythm-k' }, t('rhythm.month')),
              h('span', { className: 'wbm-rhythm-v' }, fmtCredit(monthProjection)),
              h('span', { className: 'wbm-rhythm-u' }, t('rhythm.unitCredit')))
          )
        }
        rhythmBody = h('div', { className: 'wbm-rhythm' }, rhythmCells)
      }

      /* ---------- model value: which model was worth it ---------- *
       * Born from a real loss: the operator spent a session on the pricier
       * model by default and only noticed afterwards. Ranking measured prices
       * cheapest-first turns that into a decision the next time round. */
      var modelValueBody = null
      if (modelValue.length >= 2) {
        modelValueBody = h(
          'div',
          { className: 'wbm-mv-list' },
          modelValue.map(function (mv, index) {
            var isCheapest = index === 0
            var label = mv.model || t('common.none')
            return h(
              'div',
              { key: (mv.provider || '') + '|' + label + index, className: 'wbm-mv', 'data-best': isCheapest ? 'true' : 'false' },
              h('span', { className: 'wbm-mv-rank' }, String(index + 1)),
              h(
                'div',
                { className: 'wbm-mv-main' },
                h('div', { className: 'wbm-mv-line' },
                  h('b', { className: 'wbm-mv-name' }, label),
                  mv.provider ? h('span', { className: 'wbm-tag' }, mv.provider) : null,
                  isCheapest ? h('span', { className: 'wbm-mv-best' }, t('modelValue.cheapest')) : null),
                h('div', { className: 'wbm-mv-meta' },
                  isFinite(mv.unitPricePerMTok) ? fmtPrice(mv.unitPricePerMTok) + ' ' + t('chain.priceUnit') : t('common.none'),
                  h('span', { className: 'wbm-mv-sep' }, '·'),
                  fmtInt(mv.requests) + ' ' + t('accounts.requests'),
                  isFinite(mv.cacheHitRate) ? h('span', { className: 'wbm-mv-sep' }, '·') : null,
                  isFinite(mv.cacheHitRate) ? t('modelValue.hit', { pct: fmtPct(mv.cacheHitRate) }) : null)
              ),
              h(
                'div',
                { className: 'wbm-mv-side' },
                isCheapest
                  ? h('span', { className: 'wbm-mv-ok' }, '\u2713')
                  : h(React.Fragment, null,
                      h('span', { className: 'wbm-mv-vs' }, t('modelValue.vs', { ratio: trimNum(mv.vsCheapest, 2) })),
                      isFinite(mv.overspendCredit) && mv.overspendCredit > 0
                        ? h('span', { className: 'wbm-mv-over' }, t('modelValue.overspend', { credit: fmtCredit(mv.overspendCredit) }))
                        : null)
              )
            )
          })
        )
      } else if (modelValue.length === 1) {
        modelValueBody = h('div', { className: 'wbm-empty-sm' }, t('modelValue.onlyOne'))
      } else {
        modelValueBody = h('div', { className: 'wbm-empty-sm' }, t('modelValue.noData'))
      }

      /* ---------- body ---------- */
      var body
      if (summary.status === 'loading' && !data) {
        body = h(State, { kind: 'loading', text: t('common.loading') })
      } else {
        body = h(
          React.Fragment,
          null,
          summary.status === 'error'
            ? h(State, { kind: 'error', text: t('common.error', { message: summary.error }) })
            : h(
                React.Fragment,
                null,
                // 1. Hero + cost chain share one band: total, then why.
                h(
                  'section',
                  { className: 'wbm-band wbm-anim', style: { '--stagger': 0 } },
                  h(
                    'div',
                    { className: 'wbm-hero' },
                    h(
                      'div',
                      { className: 'wbm-hero-main' },
                      h('span', { className: 'wbm-hero-label' }, t('hero.label')),
                      h('span', { className: 'wbm-hero-value' }, fmtCredit(animatedCredit)),
                      h('span', { className: 'wbm-hero-unit' }, t('hero.unit'))
                    ),
                    h(
                      'div',
                      { className: 'wbm-hero-stats' },
                      h('div', { className: 'wbm-hstat' },
                        h('span', { className: 'wbm-hstat-v' }, fmtInt(totals.requests)),
                        h('span', { className: 'wbm-hstat-k' }, t('hero.requests'))),
                      h('div', { className: 'wbm-hstat' },
                        h('span', { className: 'wbm-hstat-v' }, fmtTokens(totals.totalTokens)),
                        h('span', { className: 'wbm-hstat-k' }, t('hero.tokens')))
                    ),
                    h(HistoryStrip, { history: history, t: t, fmtCredit: fmtCredit })
                  ),
                  insightBody,
                  // Rhythm spans the full width on its own row: the band is a
                  // flex row, so leaving it as a third sibling squeezed it into
                  // a 96px column beside the hero.
                  h('div', { className: 'wbm-band-row' }, rhythmBody)
                ),
                // 2. Runway + accounts share one row: "how long" beside "who".
                h(
                  'div',
                  { className: 'wbm-row2 wbm-anim', style: { '--stagger': 1 } },
                  h(Section, { title: t('runway.title') }, runwayBody),
                  h(Section, { title: t('accounts.poolTitle'), subtitle: t('accounts.poolSubtitle') },
                    accountRows.length === 0
                      ? h('div', { className: 'wbm-empty-sm' }, t('accounts.empty'))
                      : h(React.Fragment, null,
                          h('div', { className: 'wbm-acc-list' }, accountRows),
                          poolError
                            ? h('p', { className: 'wbm-acc-note wbm-acc-note-err' }, t('accounts.switchFailed', { reason: poolError }))
                            : poolAccounts.length > 0
                              ? h('p', { className: 'wbm-acc-note' }, t('accounts.switchHint'))
                              : null,
                          // Brief confirmation after a rename; auto-clears on
                          // the next rename interaction rather than on a timer,
                          // so it never disappears mid-read.
                          props.renameNote === 'saved'
                            ? h('p', { className: 'wbm-acc-note wbm-acc-note-ok' }, t('rename.saved'))
                            : props.renameNote === 'failed'
                              ? h('p', { className: 'wbm-acc-note wbm-acc-note-err' }, t('rename.failed'))
                              : null))
                ),
                // (insight moved into the hero band below)
                // 3. Model value — which model was actually worth it.
                // 3. Cost explained: which model was worth it, and why the bill is
                //    what it is. These two answer the same question from different
                //    angles, so they share a row instead of stacking two
                //    half-empty full-width bands.
                h(
                  'div',
                  { className: 'wbm-row3 wbm-anim', style: { '--stagger': 3 } },
                  h(
                    Section,
                    { title: t('modelValue.title'), subtitle: t('modelValue.subtitle') },
                    h(React.Fragment, null,
                      modelValueBody,
                      modelValueNote,
                      h('p', { className: 'wbm-mv-hint' }, t('modelValue.hint')))
                  ),
                  h(Section, { title: t('chain.title') }, chainBody),
                  // Advice sits beside the cost explanation: both describe the
                  // same bill, one as "why", the other as "what to change". A
                  // separate full-width band pushed the panel past 1200px.
                  h(Section, { title: t('advice.title'), subtitle: t('advice.subtitle') },
                    h(AdviceCard, { advice: advice, t: t, fmtCredit: fmtCredit }))
                ),
                // 5. Trend + model detail share a row, both compact.
                h(
                  'div',
                  { className: 'wbm-row2 wbm-anim', style: { '--stagger': 4 } },
                  h(Section, { title: t('trend.title') }, h(TrendChart, { days: days, t: t, range: range })),
                  h(
                    Section,
                    {
                      title: t('models.title'),
                      subtitle: models.length > 0 ? fmtInt(models.length) : null,
                      action: models.length > 0
                        ? h('button', {
                            type: 'button', className: 'wbm-btn wbm-btn-ghost',
                            onClick: function () { setModelsOpen(!modelsOpen) }
                          }, modelsOpen ? t('common.less') : t('common.more'))
                        : null
                    },
                    h(React.Fragment, null,
                      models.length === 0
                        ? h('div', { className: 'wbm-empty-sm' }, t('models.empty'))
                        : modelsOpen
                          ? h(ModelTable, { rows: models, t: t, sortKey: sortKey, sortDir: sortDir, onSort: props.onSort })
                          : h('div', { className: 'wbm-mini' },
                              models.map(function (m, mi) {
                                var mPrice = m.derived && isFinite(m.derived.unitPricePerMTok)
                                  ? m.derived.unitPricePerMTok
                                  : NaN
                                return h('div', { key: 'mini-' + mi, className: 'wbm-mini-row' },
                                  h('span', { className: 'wbm-mini-name' }, m.model || t('common.none')),
                                  h('span', { className: 'wbm-spacer' }),
                                  h('span', { className: 'wbm-mini-v' }, fmtInt(m.requests)),
                                  h('span', { className: 'wbm-mini-k' }, t('accounts.requests')),
                                  h('span', { className: 'wbm-mini-v' }, fmtTokens(m.totalTokens)),
                                  h('span', { className: 'wbm-mini-k' }, 'token'),
                                  isFinite(mPrice)
                                    ? h('span', { className: 'wbm-mini-price' }, fmtPrice(mPrice))
                                    : null)
                              })
                            ),
                      // Hour profile lives here rather than under the trend chart:
                      // this card had spare vertical space, and stacking the heat
                      // map under the trend pushed the whole panel past 1200px.
                      h(HourHeat, { hourly: hourly, t: t, fmtCredit: fmtCredit }))
                  )
                ),
              )
        )
      }

      return h(
        'div',
        { className: 'wbm-root', 'data-in': entered ? 'true' : 'false' },
        h('style', null, STYLES),
        h(
          'header',
          { className: 'wbm-head' },
          h('h1', { className: 'wbm-h1' }, t('title')),
          h('span', { className: 'wbm-spacer' }),
          h(
            'div',
            { className: 'wbm-seg', role: 'group', 'aria-label': t('title') },
            rangeButtons.map(function (item) {
              return h('button', {
                key: item.days, type: 'button', className: 'wbm-seg-btn',
                'data-on': String(range === item.days),
                'aria-pressed': String(range === item.days),
                onClick: function () { props.onRange(item.days) }
              }, t(item.label))
            })
          ),
          h('button', { type: 'button', className: 'wbm-btn', onClick: props.onRefresh }, t('refresh'))
        ),
        body,
        // Keyword-filter bypass sits directly above the patch footer: both are
        // "plumbing" controls rather than measurements, so they read as one
        // group at the bottom instead of competing with the data cards.
        h(LexiconCard, {
          t: t,
          value: props.lexicon ? props.lexicon.value : null,
          busy: props.lexiconBusy === true,
          onToggle: props.onLexiconToggle,
          onRepair: props.onLexiconRepair,
        }),
        h(
          'footer',
          { className: 'wbm-patch', 'data-state': patchState },
          h('span', { className: 'wbm-dot ' + (patchState === 'installed' ? 'wbm-dot-ok' : patchState === 'drift' ? 'wbm-dot-warn' : 'wbm-dot-err') }),
          h('span', { className: 'wbm-patch-label' }, patchLabel),
          patch.value && patch.value.ofmVersion
            ? h('span', { className: 'wbm-patch-meta' }, t('patch.ofmVersion') + ' ' + patch.value.ofmVersion)
            : null,
          patch.value && patch.value.selfHealed
            ? h('span', { className: 'wbm-patch-meta' }, t('patch.selfHealed'))
            : null,
          h('span', { className: 'wbm-spacer' }),
          h('button', {
            type: 'button', className: 'wbm-btn wbm-btn-ghost',
            onClick: function () { props.onCopyCommand('node scripts/patch-ofm.mjs --apply') }
          }, t('patch.apply')),
          h('button', { type: 'button', className: 'wbm-btn wbm-btn-ghost', onClick: props.onRecheck }, t('patch.recheck'))
        )
      )
    }
    /* ------------------------------------------------------------------ *
     * Stateful panel: owns fetching, range and sort state.
     * ------------------------------------------------------------------ */

    function createPanel(t) {
      return function Panel() {
        var rangeState = useState(7)
        var range = rangeState[0]
        var setRange = rangeState[1]

        var tickState = useState(0)
        var tick = tickState[0]
        var setTick = tickState[1]

        var balanceTickState = useState(0)
        var balanceTick = balanceTickState[0]
        var setBalanceTick = balanceTickState[1]

        var summaryState = useState({ status: 'loading', value: null, error: null })
        var summary = summaryState[0]
        var setSummary = summaryState[1]

        var balanceState = useState({ status: 'loading', value: null, error: null })
        var balance = balanceState[0]
        var setBalance = balanceState[1]

        var patchState = useState({ status: 'loading', value: null, error: null })
        var patch = patchState[0]
        var setPatch = patchState[1]

        // Keyword-filter bypass: an emergency switch, so it lives in its own
        // state and never blocks the panel if the route is unavailable.
        var lexiconState = useState({ status: 'idle', value: null, error: null })
        var lexicon = lexiconState[0]
        var setLexicon = lexiconState[1]
        var lexiconBusyState = useState(false)
        var lexiconBusy = lexiconBusyState[0]
        var setLexiconBusy = lexiconBusyState[1]

        // Account pool: which OFM accounts exist, and which one is currently
        // allowed to serve traffic. Separate from the meter's own ledger —
        // this comes from channel-pack, the plugin that actually picks accounts.
        var poolState = useState({ status: 'idle', value: null, error: null })
        var pool = poolState[0]
        var setPool = poolState[1]
        var switchingState = useState('')
        var switching = switchingState[0]
        var setSwitching = switchingState[1]

        // Inline rename: which account is being edited, and the draft text.
        // Kept as plain state (not a form library) because there is exactly one
        // editable field in the whole panel.
        var renameState = useState({ accountId: '', draft: '', note: '' })
        var rename = renameState[0]
        var setRename = renameState[1]

        var poolTickState = useState(0)
        var poolTick = poolTickState[0]
        var setPoolTick = poolTickState[1]

        // Live polling. The numbers were always computed fresh on every request,
        // but nothing ever re-requested them — the panel sat on whatever it
        // loaded when opened, so a new session's spend did not show up until the
        // user pressed 刷新. Poll the summary on a slow timer instead; 5s is far
        // cheaper than the request the user just made and still feels immediate.
        useEffect(function () {
          var timer = setInterval(function () {
            // Never poll a hidden panel: a background tab costs nothing.
            if (typeof document !== 'undefined' && document.hidden) return
            setTick(function (n) { return n + 1 })
          }, 5000)
          return function () { clearInterval(timer) }
        }, [])

        // Balances live upstream (an API round trip per account), so they get a
        // much slower cadence than the ledger. Two minutes keeps the runway
        // honest without hammering the provider.
        useEffect(function () {
          var timer = setInterval(function () {
            if (typeof document !== 'undefined' && document.hidden) return
            setBalanceTick(function (n) { return n + 1 })
          }, 120000)
          return function () { clearInterval(timer) }
        }, [])

        var sortState = useState({ key: 'totalTokens', dir: 'desc' })
        var sort = sortState[0]
        var setSort = sortState[1]

        useEffect(
          function () {
            var alive = true
            var controller = typeof AbortController === 'function' ? new AbortController() : null
            setSummary(function (previous) {
              return { status: 'loading', value: previous.value, error: null }
            })
            postJSON(API + '/summary', { sinceDays: range }, controller ? controller.signal : undefined)
              .then(function (value) {
                if (!alive) return
                setSummary({ status: 'ready', value: normalizeSummary(value), error: null })
              })
              .catch(function (error) {
                if (!alive || isAbort(error)) return
                setSummary({ status: 'error', value: null, error: errText(error) })
              })
            return function () {
              alive = false
              if (controller) controller.abort()
            }
          },
          [range, tick]
        )

        useEffect(
          function () {
            var alive = true
            var controller = typeof AbortController === 'function' ? new AbortController() : null
            setPatch(function (previous) {
              return { status: 'loading', value: previous.value, error: null }
            })
            postJSON(API + '/patch-status', {}, controller ? controller.signal : undefined)
              .then(function (value) {
                if (!alive) return
                setPatch({ status: 'ready', value: normalizePatch(value), error: null })
                // patch-status piggybacks the lexicon block, so one round trip
                // hydrates both cards.
                if (value && value.lexicon) {
                  setLexicon({ status: 'ready', value: value.lexicon, error: null })
                }
              })
              .catch(function (error) {
                if (!alive || isAbort(error)) return
                setPatch({ status: 'error', value: null, error: errText(error) })
              })
            return function () {
              alive = false
              if (controller) controller.abort()
            }
          },
          [tick]
        )

        useEffect(
          function () {
            var alive = true
            var controller = typeof AbortController === 'function' ? new AbortController() : null
            Promise.all([
              postJSON(API + '/accounts', { provider: 'buddy' }, controller ? controller.signal : undefined),
              postJSON(API + '/limits', { provider: 'buddy' }, controller ? controller.signal : undefined).catch(function () {
                // Limits are an enhancement: if the call fails the account list
                // still renders, just without cooldown badges.
                return null
              })
            ])
              .then(function (results) {
                if (!alive) return
                var poolValue = normalizePool(results[0])
                var limitsValue = normalizeLimits(results[1])
                setPool({ status: 'ready', value: poolValue, limits: limitsValue, error: null })
              })
              .catch(function (error) {
                if (!alive || isAbort(error)) return
                setPool({ status: 'error', value: null, error: errText(error) })
              })
            return function () {
              alive = false
              if (controller) controller.abort()
            }
          },
          [poolTick]
        )

        // Live model test: on demand only (it spends one real upstream request).
        var testState = useState({ status: 'idle', accountId: '', value: null, error: null })
        var testResult = testState[0]
        var setTestResult = testState[1]

        var onTestAccount = useCallback(function (accountId, modelId) {
          setTestResult({ status: 'running', accountId: accountId, value: null, error: null })
          postJSON(API + '/test', { provider: 'buddy', modelId: modelId, accountId: accountId })
            .then(function (value) {
              setTestResult({ status: 'done', accountId: accountId, value: value, error: null })
              // A failed probe often leaves a fresh cooldown behind; refresh so
              // the countdown matches what the upstream just told us.
              setPoolTick(function (n) { return n + 1 })
            })
            .catch(function (error) {
              setTestResult({ status: 'error', accountId: accountId, value: null, error: errText(error) })
            })
        }, [])

        // Ticking clock for the countdown labels — purely local, no requests.
        var clockState = useState(Date.now())
        var clock = clockState[0]
        var setClock = clockState[1]
        useEffect(function () {
          var timer = setInterval(function () { setClock(Date.now()) }, 1000)
          return function () { clearInterval(timer) }
        }, [])

        // Switching accounts: refetch the pool afterwards so the UI reflects
        // what channel-pack actually persisted, not what we hoped it did.
        var onSwitchAccount = useCallback(function (accountId) {
          setSwitching(accountId)
          postJSON(API + '/accounts/switch', { provider: 'buddy', only: accountId })
            .then(function () {
              setPoolTick(function (n) { return n + 1 })
              setTick(function (n) { return n + 1 })
            })
            .catch(function (error) {
              setPool({
                status: 'error',
                value: null,
                error: errText(error)
              })
            })
            .finally(function () {
              setSwitching('')
            })
        }, [])

        useEffect(
          function () {
            var alive = true
            var controller = typeof AbortController === 'function' ? new AbortController() : null
            setBalance(function (previous) {
              return { status: 'loading', value: previous.value, error: null }
            })
            postJSON(API + '/balance', { force: balanceTick > 0 }, controller ? controller.signal : undefined)
              .then(function (value) {
                if (!alive) return
                setBalance({ status: 'ready', value: normalizeBalance(value), error: null })
              })
              .catch(function (error) {
                if (!alive || isAbort(error)) return
                setBalance({ status: 'error', value: null, error: errText(error) })
              })
            return function () {
              alive = false
              if (controller) controller.abort()
            }
          },
          [balanceTick]
        )

        var onRange = useCallback(function (next) {
          setRange(next)
        }, [])

        var onRefresh = useCallback(function () {
          setTick(function (value) {
            return value + 1
          })
        }, [])

        var onRecheck = useCallback(function () {
          setTick(function (value) {
            return value + 1
          })
        }, [])

        var onBalanceRefresh = useCallback(function () {
          setBalanceTick(function (value) {
            return value + 1
          })
        }, [])

        /* ---------- inline account rename ---------- */

        var onRename = useCallback(function (accountId, current) {
          setRename({ accountId: accountId, draft: current, note: '' })
        }, [])

        var onRenameDraft = useCallback(function (value) {
          setRename(function (previous) {
            return { accountId: previous.accountId, draft: value, note: '' }
          })
        }, [])

        var onRenameCancel = useCallback(function () {
          setRename({ accountId: '', draft: '', note: '' })
        }, [])

        // Submitting is idempotent and cheap to trigger twice (Enter then blur),
        // so guard with the accountId: after the first success it is cleared and
        // the second call becomes a no-op.
        var onRenameSubmit = useCallback(function () {
          var target = rename.accountId
          if (target === '') return
          var draft = rename.draft
          setRename({ accountId: '', draft: '', note: '' })
          postJSON(API + '/accounts/rename', { accountId: target, nickname: draft })
            .then(function (value) {
              var ok = value && value.applied !== false
              // Keep the toast brief: it reuses the rename note slot, and the
              // account list refresh is what actually proves it worked.
              setRename({ accountId: '', draft: '', note: ok ? 'saved' : 'failed' })
              setPoolTick(function (n) { return n + 1 })
              setBalanceTick(function (n) { return n + 1 })
            })
            .catch(function () {
              setRename({ accountId: '', draft: '', note: 'failed' })
              setPoolTick(function (n) { return n + 1 })
            })
        }, [rename.accountId, rename.draft])

        var onSort = useCallback(function (key) {
          setSort(function (previous) {
            if (previous.key === key) {
              return { key: key, dir: previous.dir === 'asc' ? 'desc' : 'asc' }
            }
            return { key: key, dir: key === 'model' || key === 'provider' ? 'asc' : 'desc' }
          })
        }, [])

        var onCopyCommand = useCallback(function (command) {          try {
            if (typeof navigator !== 'undefined' && navigator.clipboard && navigator.clipboard.writeText) {
              navigator.clipboard.writeText(command).catch(function () {})
            }
          } catch (error) {
            /* clipboard unavailable: the command is already in the button tooltip */
          }
        }, [])

        // Flip one lexicon switch. Optimistic: the UI moves immediately, and
        // the authoritative config from the Host replaces it on response. If
        // the call fails we roll back to the previous config so a switch never
        // silently lies about the real state.
        var onLexiconToggle = useCallback(function (patchFields) {
          setLexiconBusy(true)
          setLexicon(function (previous) {
            if (!previous.value) return previous
            return {
              status: previous.status,
              value: {
                config: Object.assign({}, previous.value.config, patchFields),
                stats: previous.value.stats,
                patchPresent: previous.value.patchPresent,
                hookInstalled: previous.value.hookInstalled,
              },
              error: null,
            }
          })
          var rollback = lexicon.value
          postJSON(API + '/lexicon', { action: 'set', patch: patchFields, resetStats: true })
            .then(function (value) {
              setLexicon(function (previous) {
                return {
                  status: 'ready',
                  value: {
                    config: value && value.config ? value.config : patchFields,
                    stats: { rewrites: 0, hits: 0, injected: 0, lastAt: null },
                    patchPresent: previous.value ? previous.value.patchPresent : true,
                    hookInstalled: previous.value ? previous.value.hookInstalled : true,
                  },
                  error: null,
                }
              })
            })
            .catch(function (error) {
              setLexicon(function () {
                return rollback && rollback.value
                  ? { status: 'ready', value: rollback.value, error: null }
                  : { status: 'error', value: null, error: errText(error) }
              })
            })
            .then(function () {
              setLexiconBusy(false)
            })
        }, [lexicon.value])

        var onLexiconRepair = useCallback(function () {
          setLexiconBusy(true)
          postJSON(API + '/lexicon', { action: 'repair-patch' })
            .then(function (value) {
              setLexicon(function (previous) {
                if (!previous.value) return previous
                return {
                  status: 'ready',
                  value: Object.assign({}, previous.value, {
                    patchPresent: value && value.patchPresent === true,
                  }),
                  error: null,
                }
              })
            })
            .catch(function () {
              /* leave the card showing the problem */
            })
            .then(function () {
              setLexiconBusy(false)
            })
        }, [])

        return h(PanelView, {
          t: t,
          range: range,
          summary: summary,
          balance: balance,
          patch: patch,
          lexicon: lexicon,
          lexiconBusy: lexiconBusy,
          onLexiconToggle: onLexiconToggle,
          onLexiconRepair: onLexiconRepair,
          pool: pool,
          switching: switching,
          renaming: rename.accountId,
          renameDraft: rename.draft,
          renameNote: rename.note,
          onRename: onRename,
          onRenameDraft: onRenameDraft,
          onRenameSubmit: onRenameSubmit,
          onRenameCancel: onRenameCancel,
          onSwitchAccount: onSwitchAccount,
          testResult: testResult,
          onTestAccount: onTestAccount,
          clock: clock,
          sortKey: sort.key,
          sortDir: sort.dir,
          onRange: onRange,
          onRefresh: onRefresh,
          onRecheck: onRecheck,
          onBalanceRefresh: onBalanceRefresh,
          onSort: onSort,
          onCopyCommand: onCopyCommand
        })
      }
    }

    /* ------------------------------------------------------------------ *
     * Sidebar icon (mirrors icon.svg, but inherits `currentColor` so it
     * follows the host theme instead of the fixed brand blues).
     * ------------------------------------------------------------------ */

    function Icon(props) {
      var size = props && typeof props.size === 'number' && props.size > 0 ? props.size : 18
      return h(
        'svg',
        {
          viewBox: '0 0 64 64',
          width: size,
          height: size,
          fill: 'none',
          'aria-hidden': 'true',
          focusable: 'false',
          style: { display: 'block', flex: 'none' }
        },
        h('rect', {
          x: 4,
          y: 4,
          width: 56,
          height: 56,
          rx: 14,
          stroke: 'currentColor',
          'stroke-width': 3,
          opacity: 0.35
        }),
        h('rect', { x: 14, y: 34, width: 7, height: 16, rx: 2.5, fill: 'currentColor', opacity: 0.5 }),
        h('rect', { x: 25, y: 26, width: 7, height: 24, rx: 2.5, fill: 'currentColor', opacity: 0.75 }),
        h('rect', { x: 36, y: 18, width: 7, height: 32, rx: 2.5, fill: 'currentColor' }),
        h('path', {
          d: 'M46 30 l5 -6 l-2.4 -0.6 l4.4 -3.4 l1.2 5.5 l-2.1 -1.2 l-4.2 5.1 z',
          fill: 'currentColor'
        })
      )
    }

    /* ------------------------------------------------------------------ *
     * Styles. Every colour is a --dsw-alias-* token (or a color-mix of one),
     * so light/dark follows the host with no media query of our own.
     * ------------------------------------------------------------------ */

    /**
     * Badge styles live outside STYLES and are injected by the badge slot itself.
     *
     * STYLES is rendered by the panel component only; the sidebar footer badge
     * renders in a different slot that mounts before any panel exists, so
     * relying on STYLES left the badge completely unstyled (display:block, no
     * bar). Injecting here makes the badge self-sufficient.
     */
    var BADGE_STYLES = [
      '.wbm-sbc{display:flex;flex-direction:column;gap:6px;width:100%;padding:8px 10px;border:1px solid var(--dsw-alias-border-l1);border-radius:12px;background:var(--dsw-alias-bg-layer-1);box-sizing:border-box}',
      '.wbm-sbc-head{display:flex;align-items:center;gap:5px;min-width:0}',
      '.wbm-sbc-dot{width:6px;height:6px;border-radius:50%;flex:none;background:var(--dsw-alias-state-success-primary)}',
      '.wbm-sbc-dot[data-state="warn"]{background:var(--dsw-alias-state-warn-primary)}',
      '.wbm-sbc-name{font-size:11px;font-weight:600;color:var(--dsw-alias-label-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}',
      '.wbm-sbc-credit{font-size:13px;font-weight:700;color:var(--dsw-alias-label-primary);font-variant-numeric:tabular-nums;white-space:nowrap;letter-spacing:-.2px}',
      '.wbm-sbc-bar{height:6px;border-radius:999px;background:var(--dsw-alias-bg-layer-3);overflow:hidden}',
      '.wbm-sbc-fill{height:100%;border-radius:999px;transform-origin:left center;animation:wbm-grow-x .8s cubic-bezier(.22,1,.36,1) both;background:linear-gradient(90deg,var(--dsw-alias-state-business-primary),color-mix(in srgb,var(--dsw-alias-state-business-primary) 50%,var(--dsw-alias-state-success-primary)))}',
      '.wbm-sbc-fill[data-level="high"]{background:linear-gradient(90deg,var(--dsw-alias-state-success-primary),color-mix(in srgb,var(--dsw-alias-state-success-primary) 55%,var(--dsw-alias-state-business-primary)))}',
      '.wbm-sbc-fill[data-level="mid"]{background:linear-gradient(90deg,var(--dsw-alias-state-warn-primary),var(--dsw-alias-state-error-primary))}',
      '.wbm-sbc-fill[data-level="low"]{background:var(--dsw-alias-state-error-primary)}',
      '.wbm-sbc-foot{display:flex;align-items:center;gap:4px;min-width:0}',
      '.wbm-sbc-model{font-size:9px;color:var(--dsw-alias-label-tertiary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}',
      '.wbm-sbc-ok{font-size:9px;color:var(--dsw-alias-state-success-primary);white-space:nowrap}',
      '.wbm-sbc-limit{font-size:9px;color:var(--dsw-alias-state-warn-primary);font-variant-numeric:tabular-nums;white-space:nowrap}',
    ].join('')

    var STYLES = [
      '.wbm-root{box-sizing:border-box;display:flex;flex-direction:column;gap:9px;height:100%;min-height:0;overflow:auto;padding:12px 18px 16px;color:var(--dsw-alias-label-primary);font-size:13px;line-height:1.5;font-variant-numeric:tabular-nums}',
      '.wbm-root *{box-sizing:border-box}',
      '.wbm-head{display:flex;align-items:center;gap:10px;flex-wrap:wrap;flex:none}',
      '.wbm-h1{margin:0;font-size:15px;font-weight:600;letter-spacing:.01em}',
      '.wbm-spacer{flex:1 1 auto}',
      '.wbm-seg{display:inline-flex;align-items:center;gap:2px;padding:2px;border:1px solid var(--dsw-alias-border-l2);border-radius:9px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2) 72%,transparent)}',
      '.wbm-seg-btn{appearance:none;border:0;border-radius:7px;background:transparent;color:var(--dsw-alias-label-secondary);font:inherit;font-size:12px;padding:4px 11px;cursor:pointer;transition:background .12s ease,color .12s ease}',
      '.wbm-seg-btn:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}',
      '.wbm-seg-btn[data-on="true"]{background:var(--dsw-alias-button-primary-fill);color:var(--dsw-alias-label-primary-foreground)}',
      '.wbm-btn{appearance:none;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;background:var(--dsw-alias-bg-layer-3);color:var(--dsw-alias-label-primary);font:inherit;font-size:12px;line-height:1.2;padding:5px 11px;cursor:pointer;transition:background .12s ease,border-color .12s ease}',
      '.wbm-btn:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover-solid)}',
      '.wbm-btn-ghost{background:transparent}',
      /* ── section cards ─────────────────────────────────────────────── */
      '.wbm-card{flex:none;display:flex;flex-direction:column;border:1px solid var(--dsw-alias-border-l2);border-radius:13px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-1) 78%,transparent);-webkit-backdrop-filter:blur(14px) saturate(150%);backdrop-filter:blur(14px) saturate(150%);padding:12px 15px 14px;transition:border-color .18s ease}',
      '.wbm-card:hover{border-color:color-mix(in srgb,var(--dsw-alias-brand-primary) 30%,var(--dsw-alias-border-l2))}',
      '@supports not ((backdrop-filter:blur(2px)) or (-webkit-backdrop-filter:blur(2px))){.wbm-card{background:var(--dsw-alias-bg-layer-1)}}',
      '.wbm-card-head{display:flex;align-items:baseline;gap:8px;margin-bottom:7px;flex-wrap:wrap}',
      '.wbm-card-title{margin:0;font-size:12.5px;font-weight:600}',
      '.wbm-card-sub{font-size:10.5px;color:var(--dsw-alias-label-tertiary)}',
      /* ── hero band: total + counts ─────────────────────────────────── */
      '.wbm-band{flex:none;display:flex;gap:20px;flex-wrap:wrap;align-items:flex-end;padding:12px 16px 11px;border:1px solid var(--dsw-alias-border-l2);border-radius:14px;background:linear-gradient(155deg,color-mix(in srgb,var(--dsw-alias-bg-layer-1) 92%,transparent),color-mix(in srgb,var(--dsw-alias-bg-layer-2) 66%,transparent));-webkit-backdrop-filter:blur(16px) saturate(150%);backdrop-filter:blur(16px) saturate(150%)}',
      '.wbm-band-row{flex:1 1 100%;order:99;min-width:0}',
      '.wbm-hero{display:flex;align-items:flex-end;gap:18px;flex-wrap:wrap;min-width:0}',
      '.wbm-hero-main{display:flex;flex-direction:column;gap:0;min-width:0}',
      '.wbm-hero-label{font-size:11px;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-hero-value{font-size:42px;font-weight:650;line-height:1.04;letter-spacing:-.024em;font-variant-numeric:tabular-nums}',
      '.wbm-hero-unit{font-size:11px;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-hero-stats{display:flex;gap:22px;padding-bottom:5px}',
      '.wbm-sb-none{font-size:9px;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-sb-dot{width:6px;height:6px;border-radius:50%;flex:none;background:var(--dsw-alias-state-success-primary)}',
      '.wbm-sb-dot[data-state="warn"]{background:var(--dsw-alias-state-warn-primary)}',
      '.wbm-heat{display:flex;flex-direction:column;gap:3px;margin-top:8px;padding-top:7px;border-top:1px solid color-mix(in srgb,var(--dsw-alias-label-tertiary) 14%,transparent)}',
      '.wbm-heat-head{display:flex;align-items:center;gap:6px}',
      '.wbm-heat-title{font-size:9.5px;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-heat-peak{font-size:9px;color:var(--dsw-alias-state-warning-primary);font-variant-numeric:tabular-nums;font-weight:600}',
      '.wbm-heat-cells{display:grid;grid-template-columns:repeat(24,1fr);gap:2px}',
      '.wbm-heat-cell{height:14px;border-radius:2px;background:color-mix(in srgb,var(--dsw-alias-label-tertiary) 9%,transparent);transition:transform .12s ease}',
      '.wbm-heat-cell:hover{transform:scaleY(1.28)}',
      '.wbm-heat-cell[data-level="1"]{background:color-mix(in srgb,var(--dsw-alias-state-business-primary) 22%,transparent)}',
      '.wbm-heat-cell[data-level="2"]{background:color-mix(in srgb,var(--dsw-alias-state-business-primary) 42%,transparent)}',
      '.wbm-heat-cell[data-level="3"]{background:color-mix(in srgb,var(--dsw-alias-state-warning-primary) 62%,transparent)}',
      '.wbm-heat-cell[data-level="4"]{background:var(--dsw-alias-state-error-primary)}',
      '.wbm-heat-axis{display:grid;grid-template-columns:repeat(4,1fr);margin-top:1px}',
      '.wbm-heat-tick{font-size:8px;color:var(--dsw-alias-label-tertiary);opacity:.6;font-variant-numeric:tabular-nums}',
      '.wbm-hist{display:flex;align-items:center;gap:7px;margin-top:5px;padding-top:5px;border-top:1px solid color-mix(in srgb,var(--dsw-alias-label-tertiary) 16%,transparent);flex-wrap:wrap}',
      '.wbm-hist-label{font-size:9px;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-hist-prev{font-size:9.5px;color:var(--dsw-alias-label-secondary);font-variant-numeric:tabular-nums}',
      '.wbm-hist-delta{font-size:10px;font-weight:700;font-variant-numeric:tabular-nums;padding:0 5px;border-radius:4px}',
      '.wbm-hist-delta[data-dir="up"]{color:var(--dsw-alias-state-error-primary);background:color-mix(in srgb,var(--dsw-alias-state-error-primary) 12%,transparent)}',
      '.wbm-hist-delta[data-dir="down"]{color:var(--dsw-alias-state-success-primary);background:color-mix(in srgb,var(--dsw-alias-state-success-primary) 12%,transparent)}',
      '.wbm-hist-delta[data-dir="flat"]{color:var(--dsw-alias-label-tertiary)}',
      '.wbm-hist-none{font-size:9px;color:var(--dsw-alias-label-tertiary);opacity:.8}',
      '.wbm-hist-proj{margin-left:auto;font-size:9px;color:var(--dsw-alias-label-tertiary);font-variant-numeric:tabular-nums}',
      '.wbm-hstat{display:flex;flex-direction:column;gap:0}',
      '.wbm-hstat-v{font-size:17px;font-weight:600;line-height:1.2}',
      '.wbm-hstat-k{font-size:10px;color:var(--dsw-alias-label-tertiary)}',
      /* ── account rows ──────────────────────────────────────────────── */
      '.wbm-acc-list{display:flex;flex-direction:column;gap:9px;justify-content:space-between;flex:1 1 auto;min-height:0}',
      '.wbm-acc{padding:8px 11px;border:1px solid var(--dsw-alias-border-l2);border-radius:11px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2) 42%,transparent);transition:border-color .16s ease}',
      '.wbm-acc:hover{border-color:color-mix(in srgb,var(--dsw-alias-brand-primary) 28%,var(--dsw-alias-border-l2))}',
      '.wbm-acc-line{display:flex;align-items:baseline;gap:7px;min-width:0}',
      '.wbm-acc-name{font-size:12.5px;font-weight:650;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
      '.wbm-tag{font-size:9px;padding:0 5px;border-radius:4px;background:color-mix(in srgb,var(--dsw-alias-label-tertiary) 14%,transparent);color:var(--dsw-alias-label-tertiary)}',
      '.wbm-acc-credit{font-size:16px;font-weight:650;line-height:1.1}',
      '.wbm-acc-unit{font-size:10px;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-acc-share{font-size:11px;font-weight:600;color:var(--dsw-alias-label-secondary);min-width:44px;text-align:right}',
      '.wbm-acc-bar{height:5px;margin:7px 0 6px;border-radius:3px;background:color-mix(in srgb,var(--dsw-alias-label-tertiary) 15%,transparent);overflow:hidden;box-shadow:inset 0 1px 1px color-mix(in srgb,var(--dsw-alias-label-primary) 8%,transparent)}',
      '.wbm-acc-fill{height:100%;border-radius:3px;transform-origin:left center;animation:wbm-grow-x .9s cubic-bezier(.22,1,.36,1) .25s both;background:linear-gradient(90deg,var(--dsw-alias-brand-primary),var(--dsw-alias-state-success-primary))}',
      '.wbm-acc-fill[data-level="mid"]{background:linear-gradient(90deg,var(--dsw-alias-state-business-primary),var(--dsw-alias-state-warn-primary))}',
      '.wbm-acc-fill[data-level="high"]{background:linear-gradient(90deg,var(--dsw-alias-state-warn-primary),var(--dsw-alias-state-error-primary))}',
      '.wbm-acc[data-state="reserve"]{opacity:.72}',
      '.wbm-acc[data-state="reserve"]:hover{opacity:1}',
      '.wbm-dot-idle{background:color-mix(in srgb,var(--dsw-alias-label-tertiary) 55%,transparent)}',
      '.wbm-acc-idle{font-size:9px;padding:0 5px;border-radius:4px;background:color-mix(in srgb,var(--dsw-alias-label-tertiary) 13%,transparent);color:var(--dsw-alias-label-tertiary)}',
      '.wbm-acc-switch{display:flex;align-items:center;gap:6px;margin-top:4px}',
      '.wbm-acc-active{font-size:9px;padding:1px 7px;border-radius:999px;background:color-mix(in srgb,var(--dsw-alias-state-success-primary) 20%,transparent);color:var(--dsw-alias-state-success-primary);font-weight:600;border:1px solid color-mix(in srgb,var(--dsw-alias-state-success-primary) 40%,transparent)}',
      '.wbm-acc-switch-btn{font-size:10px;padding:2px 8px;line-height:1.3}',
      '.wbm-acc-switch-btn:disabled{opacity:.5;cursor:default}',
      '.wbm-acc-note{margin:6px 0 0;font-size:9.5px;color:var(--dsw-alias-label-tertiary);line-height:1.45}',
      '.wbm-acc-note-err{color:var(--dsw-alias-state-error-primary)}',
      '.wbm-acc-note-ok{color:var(--dsw-alias-state-success-primary)}',
      '.wbm-adv{display:flex;flex-direction:column;gap:8px;flex:1 1 auto}',
      '.wbm-adv-body-wrap{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:8px}',
      '.wbm-adv-row{padding:7px 9px;border-radius:8px;background:color-mix(in srgb,var(--dsw-alias-label-tertiary) 7%,transparent);border-left:2px solid transparent}',
      '.wbm-adv-row[data-severity="high"]{border-left-color:var(--dsw-alias-state-error-primary);background:color-mix(in srgb,var(--dsw-alias-state-error-primary) 8%,transparent)}',
      '.wbm-adv-row[data-severity="medium"]{border-left-color:var(--dsw-alias-state-warning-primary);background:color-mix(in srgb,var(--dsw-alias-state-warning-primary) 7%,transparent)}',
      '.wbm-adv-head{display:flex;align-items:center;gap:6px}',
      '.wbm-adv-dot{width:6px;height:6px;border-radius:50%;flex:none;background:var(--dsw-alias-state-warning-primary)}',
      '.wbm-adv-row[data-severity="high"] .wbm-adv-dot{background:var(--dsw-alias-state-error-primary)}',
      '.wbm-adv-title{font-size:11.5px;font-weight:600;color:var(--dsw-alias-label-primary)}',
      '.wbm-adv-impact{font-size:10.5px;font-weight:700;color:var(--dsw-alias-state-success-primary);font-variant-numeric:tabular-nums;white-space:nowrap}',
      '.wbm-adv-body{margin:3px 0 0;font-size:9.5px;line-height:1.5;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-adv-total{display:flex;align-items:baseline;gap:5px;margin-top:2px;padding-top:7px;border-top:1px dashed color-mix(in srgb,var(--dsw-alias-label-tertiary) 28%,transparent)}',
      '.wbm-adv-total-label{font-size:10px;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-adv-total-value{font-size:16px;font-weight:700;color:var(--dsw-alias-state-success-primary);font-variant-numeric:tabular-nums;letter-spacing:-.3px}',
      '.wbm-adv-total-unit{font-size:9.5px;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-adv-total-share{margin-left:auto;font-size:9.5px;color:var(--dsw-alias-label-secondary);font-variant-numeric:tabular-nums}',
      '.wbm-adv-steps{display:flex;flex-direction:column;gap:4px;margin-top:6px;padding-top:6px;border-top:1px dashed color-mix(in srgb,var(--dsw-alias-label-tertiary) 22%,transparent)}',
      '.wbm-adv-steps-k{font-size:8.5px;font-weight:600;letter-spacing:.04em;text-transform:uppercase;color:var(--dsw-alias-label-tertiary);opacity:.78}',
      '.wbm-adv-step{font-size:9px;line-height:1.45;color:var(--dsw-alias-label-secondary);padding-left:9px;position:relative}',
      '.wbm-adv-step::before{content:"";position:absolute;left:1px;top:5px;width:3px;height:3px;border-radius:50%;background:var(--dsw-alias-state-business-primary)}',
      '.wbm-adv-note{margin:auto 0 0;padding-top:5px;font-size:9px;line-height:1.45;color:var(--dsw-alias-label-tertiary);opacity:.82}',
      '.wbm-adv-empty{margin:0;font-size:10px;line-height:1.5;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-acc-probe{display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin-top:4px}',
      '.wbm-limit-badge{font-size:9px;padding:1px 7px;border-radius:999px;font-weight:600;background:color-mix(in srgb,var(--dsw-alias-state-warning-primary) 18%,transparent);color:var(--dsw-alias-state-warning-primary);border:1px solid color-mix(in srgb,var(--dsw-alias-state-warning-primary) 38%,transparent);font-variant-numeric:tabular-nums}',
      '.wbm-limit-badge.wbm-is-clear{background:color-mix(in srgb,var(--dsw-alias-state-success-primary) 16%,transparent);color:var(--dsw-alias-state-success-primary);border-color:color-mix(in srgb,var(--dsw-alias-state-success-primary) 34%,transparent)}',
      '.wbm-acc-test-btn{font-size:9.5px;padding:1px 8px;line-height:1.5}',
      '.wbm-acc-test-btn:disabled{opacity:.55;cursor:default}',
      '.wbm-test-result{font-size:9px;font-weight:600;font-variant-numeric:tabular-nums}',
      '.wbm-test-result.wbm-is-ok{color:var(--dsw-alias-state-success-primary)}',
      '.wbm-test-result.wbm-is-fail{color:var(--dsw-alias-state-error-primary)}',
      '.wbm-acc-meta{display:flex;gap:13px;flex-wrap:wrap;font-size:10px;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-acc-rem{color:var(--dsw-alias-state-success-primary)}',
      /* ── two-column row ─────────────────────────────────────────────── */
      // Three-up row: the model ranking is content-light, the two cost cards
      // need comparable width so their text does not wrap into columns.
      '.wbm-row3{display:grid;grid-template-columns:minmax(0,.86fr) minmax(0,1fr) minmax(0,1.14fr);gap:9px;align-items:stretch}',
      '@media (max-width:1180px){.wbm-row3{grid-template-columns:minmax(0,1fr) minmax(0,1fr)}}',
      '.wbm-row2{display:grid;grid-template-columns:1fr 1fr;gap:10px;align-items:stretch}',
      '.wbm-row2 > .wbm-card{height:100%}',
      '.wbm-row2 > .wbm-card > .wbm-card-head{flex:none}',
      '.wbm-row2 > .wbm-card > :not(.wbm-card-head){flex:0 1 auto}',
      '.wbm-row2-wide-left{grid-template-columns:minmax(0,1.15fr) minmax(0,1fr)}',
      '@media (max-width:900px){.wbm-row2-wide-left{grid-template-columns:1fr}}',
      '@media (max-width:900px){.wbm-row2{grid-template-columns:1fr}}',
      /* ── runway: the answer to "how long will it last" ─────────────── */
      '.wbm-runway{display:flex;align-items:flex-end;gap:20px;flex-wrap:wrap;flex:1 1 auto;min-height:0;justify-content:space-between}',
      '.wbm-runway-main{display:flex;flex-direction:column;gap:1px;min-width:0}',
      '.wbm-runway-k{font-size:10.5px;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-runway-v{font-size:34px;font-weight:650;line-height:1.08;letter-spacing:-.02em;font-variant-numeric:tabular-nums}',
      '.wbm-runway-basis{font-size:10px;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-runway-note{font-size:9.5px;color:var(--dsw-alias-label-tertiary);line-height:1.4;margin-top:1px}',
      '.wbm-runway-scope{font-size:9.5px;color:var(--dsw-alias-label-tertiary);line-height:1.4}',
      '.wbm-runway-current{font-size:9.5px;color:var(--dsw-alias-state-warn-primary);line-height:1.4}',
      '.wbm-runway-grid{display:flex;gap:18px;margin-top:7px;padding-top:7px;border-top:1px solid color-mix(in srgb,var(--dsw-alias-border-l2) 55%,transparent)}',
      '.wbm-rg{display:flex;flex-direction:column;gap:0}',
      '.wbm-rg-v{font-size:17px;font-weight:650;line-height:1.15;color:var(--dsw-alias-label-primary)}',
      '.wbm-rg-k{font-size:9.5px;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-runway-side{display:flex;flex-direction:column;align-items:flex-end;gap:3px;margin-left:auto}',
      '.wbm-runway-remain{font-size:15px;font-weight:600;color:var(--dsw-alias-state-success-primary)}',
      '.wbm-conf{font-size:9.5px;padding:1px 7px;border-radius:999px;border:1px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-tertiary)}',
      '.wbm-conf[data-level="high"]{color:var(--dsw-alias-state-success-primary);border-color:color-mix(in srgb,var(--dsw-alias-state-success-primary) 45%,transparent)}',
      '.wbm-conf[data-level="medium"]{color:var(--dsw-alias-label-secondary)}',
      '.wbm-conf[data-level="low"]{color:var(--dsw-alias-state-warn-primary);border-color:color-mix(in srgb,var(--dsw-alias-state-warn-primary) 45%,transparent)}',
      '.wbm-conf[data-level="none"]{color:var(--dsw-alias-label-tertiary)}',
      /* ── insight: one sentence ──────────────────────────────────────── */
      '.wbm-insight{padding:9px 14px;border-radius:11px;border:1px solid color-mix(in srgb,var(--dsw-alias-brand-primary) 26%,var(--dsw-alias-border-l2));background:color-mix(in srgb,var(--dsw-alias-brand-primary) 6%,transparent);font-size:12.5px;line-height:1.55;color:var(--dsw-alias-label-secondary)}',
      '.wbm-runway-wrap{display:flex;flex-direction:column;gap:10px;flex:1 1 auto;justify-content:space-between}',
      '.wbm-scen{display:flex;flex-direction:column;gap:5px;padding-top:8px;border-top:1px solid color-mix(in srgb,var(--dsw-alias-label-tertiary) 14%,transparent)}',
      '.wbm-scen-row{display:flex;align-items:center;gap:8px}',
      '.wbm-scen-k{font-size:9px;color:var(--dsw-alias-label-tertiary);width:68px;flex:none;white-space:nowrap}',
      '.wbm-scen-bar{flex:1;height:5px;border-radius:999px;background:color-mix(in srgb,var(--dsw-alias-label-tertiary) 12%,transparent);overflow:hidden}',
      '.wbm-scen-fill{height:100%;border-radius:999px;transform-origin:left center;animation:wbm-grow-x .8s cubic-bezier(.22,1,.36,1) both}@keyframes noop{}',
      '.wbm-scen-row[data-tone="base"] .wbm-scen-fill{background:linear-gradient(90deg,var(--dsw-alias-state-business-primary),color-mix(in srgb,var(--dsw-alias-state-business-primary) 55%,var(--dsw-alias-state-success-primary)))}',
      '.wbm-scen-row[data-tone="worst"] .wbm-scen-fill{background:linear-gradient(90deg,var(--dsw-alias-state-warn-primary),var(--dsw-alias-state-error-primary))}',
      '.wbm-scen-row[data-tone="best"] .wbm-scen-fill{background:linear-gradient(90deg,var(--dsw-alias-state-success-primary),color-mix(in srgb,var(--dsw-alias-state-success-primary) 60%,var(--dsw-alias-state-business-primary)))}',
      '.wbm-scen-v{font-size:10px;font-weight:700;color:var(--dsw-alias-label-primary);font-variant-numeric:tabular-nums;width:56px;text-align:right;flex:none}',
      '.wbm-scen-note{margin:2px 0 0;font-size:8.5px;line-height:1.4;color:var(--dsw-alias-label-tertiary);opacity:.85}',
      '.wbm-rhythm{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:0;margin-top:9px;border-top:1px solid color-mix(in srgb,var(--dsw-alias-label-tertiary) 14%,transparent);padding-top:9px}',
      '.wbm-rhythm-cell{display:flex;flex-direction:column;gap:2px;padding:0 16px;min-width:0;border-left:1px solid color-mix(in srgb,var(--dsw-alias-label-tertiary) 11%,transparent)}',
      '.wbm-rhythm-k{font-size:9.5px;color:var(--dsw-alias-label-tertiary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
      '.wbm-rhythm-v{font-size:19px;font-weight:700;letter-spacing:-.3px;color:var(--dsw-alias-label-primary);font-variant-numeric:tabular-nums;line-height:1.15}',
      '.wbm-rhythm-u{font-size:9px;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-rhythm-cell[data-tone="forecast"] .wbm-rhythm-v{color:var(--dsw-alias-state-warning-primary)}',
      '.wbm-rhythm-cell:first-child{border-left:none;padding-left:0}',
      /* ── model value ranking ───────────────────────────────────────── */
      '.wbm-mv-list{display:flex;flex-direction:column;gap:7px;flex:0 0 auto;min-height:0}',
      '.wbm-mv{display:flex;align-items:center;gap:10px;padding:8px 11px;border:1px solid var(--dsw-alias-border-l2);border-radius:10px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2) 40%,transparent)}',
      '.wbm-mv[data-best="true"]{border-color:color-mix(in srgb,var(--dsw-alias-state-success-primary) 42%,var(--dsw-alias-border-l2));background:color-mix(in srgb,var(--dsw-alias-state-success-primary) 7%,transparent)}',
      '.wbm-mv-rank{width:17px;height:17px;flex:0 0 auto;display:flex;align-items:center;justify-content:center;border-radius:50%;font-size:10px;font-weight:650;background:color-mix(in srgb,var(--dsw-alias-label-tertiary) 16%,transparent);color:var(--dsw-alias-label-secondary)}',
      '.wbm-mv[data-best="true"] .wbm-mv-rank{background:var(--dsw-alias-state-success-primary);color:var(--dsw-alias-label-primary-foreground)}',
      '.wbm-mv-main{flex:1 1 auto;min-width:0;display:flex;flex-direction:column;gap:1px}',
      '.wbm-mv-line{display:flex;align-items:center;gap:6px;min-width:0}',
      '.wbm-mv-name{font-size:12px;font-weight:650;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
      '.wbm-mv-best{font-size:9px;padding:0 5px;border-radius:4px;background:var(--dsw-alias-state-success-primary);color:var(--dsw-alias-label-primary-foreground);font-weight:600}',
      '.wbm-mv-meta{display:flex;align-items:center;gap:5px;flex-wrap:wrap;font-size:10px;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-mv-sep{opacity:.5}',
      '.wbm-mv-side{display:flex;flex-direction:column;align-items:flex-end;gap:0;flex:0 0 auto}',
      '.wbm-mv-ok{font-size:15px;font-weight:700;color:var(--dsw-alias-state-success-primary)}',
      '.wbm-mv-vs{font-size:11px;font-weight:650;color:var(--dsw-alias-state-warn-primary)}',
      '.wbm-mv-over{font-size:9.5px;color:var(--dsw-alias-state-error-primary)}',
      '.wbm-mv-note{display:flex;flex-direction:column;gap:2px;margin-top:8px;padding:9px 11px;border-radius:9px;border:1px solid color-mix(in srgb,var(--dsw-alias-state-warn-primary) 26%,var(--dsw-alias-border-l2));background:color-mix(in srgb,var(--dsw-alias-state-warn-primary) 6%,transparent)}',
      '.wbm-mv-note-k{font-size:8.5px;letter-spacing:.04em;text-transform:uppercase;color:var(--dsw-alias-label-tertiary);opacity:.8}',
      '.wbm-mv-note-v{font-size:16px;font-weight:700;color:var(--dsw-alias-state-warn-primary);font-variant-numeric:tabular-nums;letter-spacing:-.3px}',
      '.wbm-mv-note-sub{font-size:9px;line-height:1.45;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-mv-hint{margin:7px 0 0;font-size:9.5px;color:var(--dsw-alias-label-tertiary)}',
      /* ── cost chain ────────────────────────────────────────────────── */
      '.wbm-chain-row{display:flex;align-items:flex-end;gap:9px;flex-wrap:wrap}',
      '.wbm-chain-step{display:flex;flex-direction:column;gap:0;min-width:0}',
      '.wbm-chain-k{font-size:10px;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-chain-v{font-size:24px;font-weight:650;line-height:1.1;letter-spacing:-.015em}',
      '.wbm-chain-u{font-size:10px;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-chain-arrow{font-size:16px;color:var(--dsw-alias-label-tertiary);padding-bottom:16px}',
      '.wbm-bb{display:flex;flex-direction:column;gap:4px;padding:9px 10px;border-radius:9px;background:color-mix(in srgb,var(--dsw-alias-label-tertiary) 6%,transparent)}',
      '.wbm-bb-head{font-size:8.5px;font-weight:600;letter-spacing:.05em;text-transform:uppercase;color:var(--dsw-alias-label-tertiary);opacity:.75;margin-bottom:1px}',
      '.wbm-bb-row{display:flex;align-items:baseline;gap:6px}',
      '.wbm-bb-k{font-size:9.5px;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-bb-v{font-size:11px;font-weight:700;color:var(--dsw-alias-label-primary);font-variant-numeric:tabular-nums}',
      '.wbm-bb-v.wbm-bb-warn{color:var(--dsw-alias-state-warn-primary)}',
      '.wbm-bb-bar{height:4px;border-radius:999px;background:color-mix(in srgb,var(--dsw-alias-label-tertiary) 14%,transparent);overflow:hidden;margin-top:2px}',
      '.wbm-bb-fill{height:100%;border-radius:999px;background:linear-gradient(90deg,var(--dsw-alias-state-business-primary),var(--dsw-alias-state-warn-primary),var(--dsw-alias-state-error-primary));transform-origin:left center;animation:wbm-grow-x .8s cubic-bezier(.22,1,.36,1) both}',
      '.wbm-chain-notes{display:flex;gap:18px;flex-wrap:wrap;margin-top:auto;padding-top:10px;border-top:1px solid color-mix(in srgb,var(--dsw-alias-border-l2) 60%,transparent)}',
      '.wbm-chain-note{display:flex;flex-direction:column;gap:0;font-size:11.5px;font-weight:600}',
      '.wbm-chain-sub{font-size:9.5px;font-weight:400;color:var(--dsw-alias-label-tertiary)}',
      '.wbm-chain-warn{color:var(--dsw-alias-state-warn-primary)}',
      '.wbm-chain-ok{color:var(--dsw-alias-state-success-primary)}',
      /* ── chart ─────────────────────────────────────────────────────── */
      '.wbm-chart{margin:0;display:flex;flex-direction:column;justify-content:center;gap:4px;flex:1 1 auto;min-height:0}',
      '.wbm-chart-svg{display:block;width:100%;height:auto;min-height:0;flex:0 1 auto}',
      '.wbm-legend{flex:none;display:flex;align-items:center;justify-content:center;gap:16px;white-space:nowrap;margin-top:2px}',
      '.wbm-legend-item{display:inline-flex;align-items:center;gap:5px;font-size:10px;color:var(--dsw-alias-label-tertiary);white-space:nowrap}',
      '.wbm-legend-bar{width:8px;height:8px;border-radius:2px;background:color-mix(in srgb,var(--dsw-alias-label-tertiary) 45%,transparent)}',
      '.wbm-legend-line{width:12px;height:2px;border-radius:1px;background:var(--dsw-alias-state-business-primary)}',
      '.wbm-chart-tick{font-size:9px;fill:var(--dsw-alias-label-tertiary);font-variant-numeric:tabular-nums}',
      '.wbm-chart-tick-credit{fill:var(--dsw-alias-state-business-primary)}',
      '.wbm-anim .wbm-chart-bar rect:not([fill="transparent"]){transform-origin:center bottom;animation:wbm-grow-y .7s cubic-bezier(.22,1,.36,1) .35s both}',
      '.wbm-anim .wbm-chart-line{stroke-dasharray:1;stroke-dashoffset:1;animation:wbm-draw 1s cubic-bezier(.22,1,.36,1) .55s forwards}',
      '.wbm-anim .wbm-chart-dot{opacity:0;animation:wbm-fade-in .35s ease .7s forwards}',
      '@keyframes wbm-grow-x{from{transform:scaleX(0)}to{transform:scaleX(1)}}',
      '@keyframes wbm-grow-y{from{transform:scaleY(0)}to{transform:scaleY(1)}}',
      '@keyframes wbm-draw{to{stroke-dashoffset:0}}',
      '@keyframes wbm-fade-in{to{opacity:1}}',
      /* ── table ─────────────────────────────────────────────────────── */
      '.wbm-table-wrap{overflow-x:auto;margin:0 -3px}',
      '.wbm-table{width:100%;border-collapse:collapse;font-size:11.5px}',
      '.wbm-table th,.wbm-table td{padding:5px 7px;text-align:right;white-space:nowrap}',
      '.wbm-table th:first-child,.wbm-table td:first-child{text-align:left}',
      '.wbm-table thead th{font-size:10px;font-weight:600;color:var(--dsw-alias-label-tertiary);border-bottom:1px solid var(--dsw-alias-border-l2)}',
      '.wbm-table tbody tr{border-bottom:1px solid color-mix(in srgb,var(--dsw-alias-border-l2) 50%,transparent)}',
      '.wbm-table tbody tr:hover{background:color-mix(in srgb,var(--dsw-alias-interactive-bg-hover) 55%,transparent)}',
      '.wbm-sort{appearance:none;border:0;background:none;color:inherit;font:inherit;font-size:inherit;font-weight:inherit;padding:0;cursor:pointer}',
      '.wbm-mini{display:flex;flex-direction:column;gap:5px;flex:1 1 auto;justify-content:space-evenly;min-height:0}',
      '.wbm-mini-row{display:flex;align-items:baseline;gap:6px;font-size:11px;padding:3px 0;border-bottom:1px solid color-mix(in srgb,var(--dsw-alias-border-l2) 40%,transparent)}',
      '.wbm-mini-row:last-child{border-bottom:0}',
      '.wbm-mini-name{font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:46%}',
      '.wbm-mini-v{font-variant-numeric:tabular-nums;font-weight:600}',
      '.wbm-mini-k{font-size:9px;color:var(--dsw-alias-label-tertiary);margin-left:-3px}',
      '.wbm-mini-price{font-size:10px;color:var(--dsw-alias-state-business-primary);font-variant-numeric:tabular-nums}',
      /* ── states / misc ─────────────────────────────────────────────── */
      '.wbm-dot{width:6px;height:6px;border-radius:50%;flex:0 0 auto}',
      '.wbm-dot-ok{background:var(--dsw-alias-state-success-primary)}',
      '.wbm-dot-warn{background:var(--dsw-alias-state-warn-primary)}',
      '.wbm-dot-err{background:var(--dsw-alias-state-error-primary)}',
      '.wbm-credit[data-credit-state="missing"]{color:var(--dsw-alias-label-tertiary);text-decoration:underline dotted;text-underline-offset:3px;cursor:help}',
      '.wbm-credit[data-credit-state="zero"]{color:var(--dsw-alias-label-secondary)}',
      '.wbm-na{color:var(--dsw-alias-label-tertiary)}',
      '.wbm-empty,.wbm-empty-sm{color:var(--dsw-alias-label-tertiary)}',
      '.wbm-empty{padding:18px 0;text-align:center;font-size:12px}',
      '.wbm-empty-sm{padding:6px 0;font-size:11.5px}',
      '.wbm-state{display:flex;align-items:center;gap:7px;padding:8px 0;font-size:12px;color:var(--dsw-alias-label-secondary)}',
      '.wbm-state-dot{width:6px;height:6px;border-radius:50%;flex:0 0 auto;background:var(--dsw-alias-label-tertiary)}',
      '.wbm-state-loading .wbm-state-dot{background:var(--dsw-alias-brand-primary);animation:wbm-pulse 1.1s ease-in-out infinite}',
      '.wbm-state-error{color:var(--dsw-alias-state-error-primary)}',
      '.wbm-state-error .wbm-state-dot{background:var(--dsw-alias-state-error-primary)}',
      '@keyframes wbm-pulse{0%,100%{opacity:.35}50%{opacity:1}}',
      /* ── patch footer ──────────────────────────────────────────────── */
      '.wbm-patch{flex:none;display:flex;align-items:center;gap:7px;flex-wrap:wrap;padding:7px 11px;border:1px solid var(--dsw-alias-border-l2);border-radius:10px;font-size:10.5px;color:var(--dsw-alias-label-secondary)}',
      '.wbm-patch-label{font-weight:600}',
      '.wbm-patch-meta{color:var(--dsw-alias-label-tertiary)}',
      '.wbm-patch[data-state="missing"]{border-color:color-mix(in srgb,var(--dsw-alias-state-error-primary) 45%,var(--dsw-alias-border-l2))}',
      '.wbm-patch[data-state="drift"]{border-color:color-mix(in srgb,var(--dsw-alias-state-warn-primary) 45%,var(--dsw-alias-border-l2))}',
      /* ── inline account rename ─────────────────────────────────────── */
      '.wbm-acc-rename{appearance:none;flex:none;border:1px solid transparent;background:transparent;color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:1;padding:2px 4px;border-radius:5px;cursor:pointer;opacity:0;transition:opacity .15s ease,color .15s ease,border-color .15s ease}',
      '.wbm-acc-line:hover .wbm-acc-rename,.wbm-acc-rename:focus-visible{opacity:1}',
      '.wbm-acc-rename:hover{color:var(--dsw-alias-brand-primary);border-color:var(--dsw-alias-border-l2)}',
      '.wbm-acc-input{appearance:none;flex:0 1 150px;min-width:80px;font-size:11.5px;font-weight:600;font-family:inherit;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-brand-primary);border-radius:6px;padding:2px 6px;outline:none}',
      '.wbm-acc-input::placeholder{color:var(--dsw-alias-label-tertiary);font-weight:400}',
      /* ── lexicon (keyword bypass) ──────────────────────────────────── */
      '.wbm-lex-state{font-size:10px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;padding:2px 7px;border-radius:999px;border:1px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-tertiary)}',
      '.wbm-lex-state[data-on="true"]{color:var(--dsw-alias-state-success-primary);border-color:color-mix(in srgb,var(--dsw-alias-state-success-primary) 40%,var(--dsw-alias-border-l2));background:color-mix(in srgb,var(--dsw-alias-state-success-primary) 10%,transparent)}',
      '.wbm-lex-body{display:flex;flex-direction:column;gap:8px}',
      '.wbm-lex-chips{display:flex;align-items:center;gap:8px;flex-wrap:wrap}',
      '.wbm-lex-chip{display:inline-flex;align-items:center;gap:7px;padding:4px 8px 4px 10px;border:1px solid var(--dsw-alias-border-l2);border-radius:999px;background:var(--dsw-alias-bg-layer-2);cursor:help}',
      '.wbm-lex-chip[data-off="true"]{opacity:.42}',
      '.wbm-lex-chiplabel{font-size:11px;font-weight:600;color:var(--dsw-alias-label-primary);white-space:nowrap}',
      '.wbm-lex-switch{appearance:none;flex:none;position:relative;width:30px;height:17px;border-radius:999px;border:1px solid var(--dsw-alias-border-l3);background:var(--dsw-alias-bg-layer-4);cursor:pointer;padding:0;transition:background .18s ease,border-color .18s ease}',
      '.wbm-lex-switch[data-on="true"]{background:var(--dsw-alias-state-success-primary);border-color:transparent}',
      '.wbm-lex-switch[data-locked="true"]{cursor:not-allowed}',
      '.wbm-lex-knob{position:absolute;top:50%;left:2px;width:11px;height:11px;border-radius:50%;background:var(--dsw-alias-bg-layer-1);transform:translateY(-50%);transition:left .18s cubic-bezier(.4,0,.2,1);box-shadow:0 1px 2px color-mix(in srgb,var(--dsw-alias-label-primary) 30%,transparent)}',
      '.wbm-lex-switch[data-on="true"] .wbm-lex-knob{left:15px;background:var(--dsw-alias-bg-layer-4)}',
                        '.wbm-lex-warn{display:inline-flex;align-items:center;gap:6px;color:var(--dsw-alias-state-warn-primary)}',
      '.wbm-lex-empty{margin:0;font-size:11px;color:var(--dsw-alias-label-tertiary)}',
      /* ── entrance ──────────────────────────────────────────────────── */
      '.wbm-anim{--stagger:0}',
      '.wbm-root[data-in="false"] .wbm-anim{opacity:0;transform:translateY(12px)}',
      '.wbm-root[data-in="true"] .wbm-anim{opacity:1;transform:none;transition:opacity .45s cubic-bezier(.22,1,.36,1),transform .5s cubic-bezier(.22,1,.36,1);transition-delay:calc(var(--stagger,0)*65ms)}',
      '.wbm-root[data-in="false"] .wbm-hero-main{opacity:0;transform:translateY(16px) scale(.985)}',
      '.wbm-root[data-in="true"] .wbm-hero-main{opacity:1;transform:none;transition:opacity .55s cubic-bezier(.22,1,.36,1) .04s,transform .6s cubic-bezier(.22,1,.36,1) .04s}',
      '@media (prefers-reduced-motion:reduce){' +
        '.wbm-state-loading .wbm-state-dot{animation:none}' +
        '.wbm-root[data-in="false"] .wbm-anim{opacity:1;transform:none}' +
        '.wbm-root[data-in="true"] .wbm-anim{transition:none;animation:none}' +
        '.wbm-hero-main,.wbm-acc-fill{animation:none!important;transition:none!important}' +
        '.wbm-anim .wbm-chart-bar rect{animation:none!important}' +
        '.wbm-anim .wbm-chart-line{stroke-dasharray:none;stroke-dashoffset:0;animation:none!important}' +
        '.wbm-anim .wbm-chart-dot{opacity:1;animation:none!important}}',
      /* ── responsive ────────────────────────────────────────────────── */
      '@media (max-width:640px){.wbm-root{padding:12px 11px 20px}.wbm-hero-value{font-size:34px}.wbm-chain-v{font-size:20px}.wbm-hero-stats{gap:16px}}'
    ].join('')

    /* ------------------------------------------------------------------ *
     * Plugin module
     * ------------------------------------------------------------------ */

    function apply(ctx) {
      var t = makeT(ctx)

      if (ctx && ctx.locale && typeof ctx.locale.register === 'function') {
        ctx.effect(function () {
          return ctx.locale.register(NS, { zh: ZH, en: EN })
        }, NS + ': dictionaries')
      }

      /**
     * Compact always-on status line for the sidebar foot.
     *
     * Kept deliberately minimal: it is a glanceable summary, not a second
     * panel. Anything that needs reading lives in the panel itself.
     */
    function SidebarBadge(props) {
      var wide = props.wide !== false
      var t = props.t
      var state = useState({ status: 'idle', accounts: [], limits: {} })
      var data = state[0]
      var setData = state[1]
      var tickState = useState(0)
      var tick = tickState[0]
      var setTick = tickState[1]

      useEffect(function () {
        var alive = true
        var controller = typeof AbortController === 'function' ? new AbortController() : null
        var signal = controller ? controller.signal : undefined
        Promise.all([
          postJSON(API + '/accounts', { provider: 'buddy' }, signal).catch(function () { return null }),
          postJSON(API + '/limits', { provider: 'buddy' }, signal).catch(function () { return null })
        ]).then(function (results) {
          if (!alive) return
          var accountsRaw = results[0] && Array.isArray(results[0].accounts) ? results[0].accounts : []
          var accounts = []
          for (var i = 0; i < accountsRaw.length; i += 1) {
            var a = accountsRaw[i]
            if (!a || typeof a.id !== 'string') continue
            accounts.push({
              id: a.id,
              nickname: typeof a.nickname === 'string' ? a.nickname : '',
              enabled: a.enabled === true,
              remaining: isFinite(a.remaining) ? a.remaining : null
            })
          }
          setData({ status: 'ready', accounts: accounts, limits: normalizeLimits(results[1]) })
        })
        var timer = setInterval(function () { setTick(function (n) { return n + 1 }) }, 30000)
        return function () {
          alive = false
          clearInterval(timer)
          if (controller) controller.abort()
        }
      }, [tick])

      if (data.status !== 'ready' || data.accounts.length === 0) return null

      // The account that can actually serve traffic right now.
      var active = null
      for (var i = 0; i < data.accounts.length; i += 1) {
        if (data.accounts[i].enabled) { active = data.accounts[i]; break }
      }
      if (active === null) {
        return wide ? h('span', { className: 'wbm-sb wbm-sb-none' }, t('badge.none')) : null
      }

      // Cooldown on the model this panel is about.
      var limits = data.limits[active.id] || []
      var limited = null
      for (var j = 0; j < limits.length; j += 1) {
        if (limits[j].modelId === 'deepseek-v4.1-flash' && limits[j].active) { limited = limits[j]; break }
      }

      if (!wide) {
        // Collapsed rail: a single dot, green when ready, amber when limited.
        return h('span', {
          className: 'wbm-sb-dot',
          'data-state': limited ? 'warn' : 'ok',
          title: active.nickname + (limited ? ' · ' + t('badge.limited') : ' · ' + t('badge.ready'))
        })
      }

      // Bar fill = how much of this account's credit is left, measured against
      // the largest balance across the pool. That turns the bar into "how much
      // room do I have left relative to my other accounts" rather than an
      // invented percentage.
      var maxRemaining = 0
      for (var k = 0; k < data.accounts.length; k += 1) {
        var r = data.accounts[k].remaining
        if (r !== null && r > maxRemaining) maxRemaining = r
      }
      var fillPct =
        active.remaining !== null && maxRemaining > 0
          ? Math.max(0, Math.min(100, Math.round((active.remaining / maxRemaining) * 100)))
          : null
      var level = fillPct === null ? 'none' : fillPct >= 60 ? 'high' : fillPct >= 25 ? 'mid' : 'low'

      return h(
        React.Fragment,
        null,
        // Self-injected: this slot renders outside the panel's style scope.
        h('style', null, BADGE_STYLES),
        h(
        'div',
        { className: 'wbm-sbc', title: t('badge.hint') },
        // Row 1: account + remaining credit
        h(
          'div',
          { className: 'wbm-sbc-head' },
          h('span', { className: 'wbm-sbc-dot', 'data-state': limited ? 'warn' : 'ok' }),
          h('span', { className: 'wbm-sbc-name' }, active.nickname || t('common.none')),
          h('span', { className: 'wbm-spacer' }),
          active.remaining !== null
            ? h('span', { className: 'wbm-sbc-credit' }, fmtCredit(active.remaining))
            : null
        ),
        // Row 2: gradient progress bar
        fillPct !== null
          ? h(
              'div',
              { className: 'wbm-sbc-bar' },
              h('div', { className: 'wbm-sbc-fill', 'data-level': level, style: { width: fillPct + '%' } })
            )
          : null,
        // Row 3: model + limit state
        h(
          'div',
          { className: 'wbm-sbc-foot' },
          h('span', { className: 'wbm-sbc-model' }, 'deepseek-v4.1-flash'),
          h('span', { className: 'wbm-spacer' }),
          limited
            ? h('span', { className: 'wbm-sbc-limit' }, t('badge.limitLeft', { time: fmtMinutes(Math.max(0, limited.resetAt - Date.now())) }))
            : h('span', { className: 'wbm-sbc-ok' }, t('badge.ready'))
        )
        )
      )
    }

    var Panel = createPanel(t)

      ctx.slots.inject('main', function () {
        return ctx.slots.register({ name: 'main', key: PANEL_KEY, locale: NS }, Panel)
      })

      ctx.slots.inject('sidebar.footer.action', function () {
        return ctx.slots.register(
          { name: 'sidebar.footer.action', id: 'workbuddy-meter-badge', order: 40, locale: NS },
          function BadgeSeat(props) {
            return h(SidebarBadge, { wide: props.wide, t: t })
          }
        )
      })

      ctx.slots.inject('sidebar.panellist', function () {
        return ctx.slots.register(
          { name: 'sidebar.panellist', id: PANEL_KEY, order: 30, label: function () { return t('nav') }, locale: NS },
          Icon
        )
      })
    }

    var mod = { name: NS, inject: ['slots', 'locale'], apply: apply }

    // Test hook: only reachable when a harness explicitly opts in, so the
    // production module surface stays exactly { name, inject, apply }.
    if (typeof window !== 'undefined' && window && window.__WBM_TEST__ === true) {
      mod.__internal = {
        ZH: ZH,
        EN: EN,
        STYLES: STYLES,
        createPanel: createPanel,
        createUI: function (t) {
          return { Panel: createPanel(t), PanelView: PanelView, Icon: Icon, TrendChart: TrendChart, ModelTable: ModelTable, CreditValue: CreditValue }
        },
        normalizeSummary: normalizeSummary,
        normalizeBalance: normalizeBalance,
        normalizePatch: normalizePatch,
        derive: derive,
        bucketOf: bucketOf,
        emptyBucket: emptyBucket,
        fillDays: fillDays,
        fmtCredit: fmtCredit,
        fmtTokens: fmtTokens,
        fmtInt: fmtInt,
        fmtPrice: fmtPrice,
        fmtPct: fmtPct,
        makeT: makeT,
        fallbackT: fallbackT
      }
    }

    return mod
  }
})










