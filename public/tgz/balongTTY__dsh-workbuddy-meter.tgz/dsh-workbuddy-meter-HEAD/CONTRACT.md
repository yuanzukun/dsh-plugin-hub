# workbuddy-meter 接口契约（冻结版 v1，2026-10-18）

> **冻结即不可改**。任何一方要改字段/路径，必须先在此文件改并通知 Lead 同步另一方。
> 本文件是 Lead 与各 worker 的唯一共享契约。

---

## 0. 目标与边界

记录**本地 OFM 通道**（`buddy/` 与 `workbuddy/` 两个 provider）每一次请求的 **token 明细 + credit（积分）消耗**，并在 DSH Web UI 提供独立面板。

**不记录**：其他 11 个渠道（codearts / minimax / qoder / trae / cline / loomy / raccoon / zcode / gemini / lobsterai / opencode）。
**不含**：服务器侧反代（HK workbuddy-gateway）的消耗 —— 那是另一台机器的账，本插件只统计本机 OFM 进程内的请求。

---

## 1. 上游事实（已实测，不要再验证）

### 1.1 usage.credit 字段确实存在，但被 OFM 丢弃

上游 SSE 最后一帧的 `usage` 对象（WorkBuddy 国际版与 CodeBuddy 国内版**同构**）实际返回：

```json
"usage": {
  "prompt_tokens": 4018,
  "completion_tokens": 8,
  "total_tokens": 4026,
  "prompt_cache_hit_tokens": 0,
  "prompt_cache_miss_tokens": 4018,
  "cache_read_input_tokens": 0,
  "cache_creation_input_tokens": 0,
  "prompt_cache_write_tokens": 0,
  "completion_thinking_tokens": 0,
  "credit": 0.17,
  "cached_tokens": 0
}
```

实测样本（2026-10-18）：
| 请求 | prompt_tokens | credit |
|---|---|---|
| CodeBuddy `deepseek-v4-flash` 小请求 | 13 | `0` |
| CodeBuddy `deepseek-v4-flash` 4018 tokens | 4018 | `0.17` |
| WorkBuddy `deepseek-v4.1-flash` 小请求 | 13 | `0` |

**credit 是小数，实测 2 位（0.17），HK 网关日志见过 `0.11`**。按 float 存，**不四舍五入**。
**注意**：`credit: 0` 不代表"免费" —— 小请求低于计费门槛也返回 0。要区分"免费模型"与"未达门槛"，只能靠模型倍率（`creditsRate`）判断，**本插件不做此判断**，如实记录 0。

### 1.2 OFM 的解析位置（补丁锚点）

`~/.dsh/profiles/desktop/node_modules/dsh-our-free-model/vendor/channel-pack/pack.js`

**BuddyAdapter.consumeSse** 内，`if (data.usage) { ... }` 块（line ≈35732，`provider=buddy/workbuddy` 共用同一类）。
该块产出 `{ type: "usage", usage: { inputTokens, outputTokens, cacheReadTokens?, cacheWriteTokens?, reasoningTokens? } }`。
**`credit` 字段在这里被丢弃** —— 这就是补丁要补的唯一位置。

⚠️ 同名块共 **4 处**（line 33568 codearts / 35732 buddy / 37057 lobsterai / 38484 其他），锚点必须用
`const reasoningTokens = data.usage.completion_tokens_details?.reasoning_tokens;` + 其后 `与 codearts 一致：inputTokens 只计` 注释**组合定位**，或按 provider 上下文定位。补丁脚本必须**校验命中唯一性**，命中数 ≠ 1 就中止。

---

## 2. 数据契约（磁盘，JSONL）

### 2.1 路径

```
~/.dsh/workbuddy-meter/usage-<YYYY-MM-DD>.jsonl
```

- 日期按 **UTC+8**（与 OFM 的 `utc8DayKey` 一致），格式 `YYYY-MM-DD`
- 每行一个 JSON 对象，**append-only**
- 单日文件建议在 > 32MB 时轮转（`-2.jsonl`），非必需

### 2.2 单条记录 schema

```json
{
  "v": 1,
  "ts": 1792324136123,
  "provider": "buddy",
  "accountId": "buddy-831aa02f",
  "model": "deepseek-v4-flash",
  "channel": "direct",
  "usageReported": true,
  "promptTokens": 4018,
  "cacheReadTokens": 0,
  "cacheWriteTokens": 0,
  "completionTokens": 8,
  "reasoningTokens": 0,
  "totalTokens": 4026,
  "credit": 0.17,
  "creditReported": true,
  "ttftMs": 1654,
  "durationMs": 1814,
  "error": null
}
```

字段规则（**严格**）：
| 字段 | 类型 | 说明 |
|---|---|---|
| `v` | number | 固定 `1`，schema 版本 |
| `ts` | number | epoch ms |
| `provider` | string | `"buddy"` \| `"workbuddy"`（其他 provider 不写本文件） |
| `accountId` | string | 账号池 id，取不到写 `""` |
| `model` | string | **裸模型名**（去掉 `buddy/` `workbuddy/` 前缀），如 `deepseek-v4-flash` |
| `channel` | string | `"direct"`（DSH 内直接调用）\| `"gateway"`（经 8326/18326 网关） |
| `usageReported` | boolean | 上游是否真的报了 usage |
| `promptTokens` | number | = `prompt_tokens`（**含**缓存命中部分，与上游一致） |
| `cacheReadTokens` | number | = `prompt_cache_hit_tokens`，无则 0 |
| `cacheWriteTokens` | number | = `cache_creation_input_tokens`，无则 0 |
| `completionTokens` | number | = `completion_tokens` |
| `reasoningTokens` | number | = `completion_thinking_tokens` 或 `reasoning_tokens`，无则 0 |
| `totalTokens` | number | = `total_tokens`，缺失时用 `prompt+completion` 兜底 |
| `credit` | number | 上游 `credit`；**未报时写 `null`**，不写 0 |
| `creditReported` | boolean | 上游是否带 credit 字段 |
| `ttftMs` | number \| null | 首字耗时 |
| `durationMs` | number | 整请求耗时 |
| `error` | string \| null | 失败原因（前 200 字符） |

⚠️ **`credit: null` 与 `credit: 0` 语义不同**：前者=上游没给，后者=上游明确说 0。面板必须分开显示（"未上报" vs "0"）。

---

## 3. 聚合契约（面板用）

### 3.1 聚合维度

按 **day × provider × model × account** 聚合，每个桶含：

```json
{
  "requests": 12,
  "reported": 11,
  "errors": 1,
  "promptTokens": 48000,
  "cacheReadTokens": 32000,
  "cacheWriteTokens": 0,
  "completionTokens": 900,
  "reasoningTokens": 200,
  "totalTokens": 48900,
  "credit": 1.23,
  "creditMissing": 1,
  "ttftSumMs": 18000,
  "ttftCount": 11,
  "tpsSum": 120.5,
  "tpsCount": 11
}
```

### 3.2 派生指标（**面板必须算，且要标明算法**）

| 指标 | 公式 | 说明 |
|---|---|---|
| 缓存命中率 | `cacheReadTokens / promptTokens` | 分母为 0 时显示 `—` |
| 实测单价 | `credit / totalTokens × 1e6` | **只在 `creditReported` 的请求上算**，单位"积分/1M token" |
| 冷/热单价 | 按 `cacheReadTokens > 0` 分桶，分别算 `credit / totalTokens × 1e6` | 两者差值即缓存带来的折扣 |
| 每积分 token 数 | `totalTokens / credit` | credit 为 0 时显示 `—` |

⚠️ 实测参考值（2026-10-18，deepseek-v4.1-flash 国内站）：冷 ≈14.4 积分/1M，热 ≈0.40 积分/1M，日均混合 ≈3.2 积分/1M。面板可显示这组基线供对比，但**不要硬编码为"预期值"**。

---

## 4. 余额契约（账号积分余额，独立于逐请求记录）

数据源：`POST {endpoint}/v2/billing/meter/get-user-resource`（OFM 已在用，`src/credits.ts` 的 `fetchCreditBalance`）。

响应结构（实测）：
```
data.Response.Data.Accounts[] = {
  PackageName, CapacityUnit, Status,
  CycleCapacityRemain(Precise), CycleCapacitySize(Precise), CycleCapacityUsed(Precise),
  ExpiredTime, DeductionEndTime, CycleStartTime, CycleEndTime
}
```
- **`*Precise` 字段是字符串，精度到 8 位小数**（实测 `"7.23000021"`）—— 优先用它，缺失才用整数字段
- `Status === 3` = 已过期；`DeductionEndTime` 已过 = 过期
- 有效余额 = `Σ(active ? CycleCapacityRemainPrecise : 0)`

写入：
```
~/.dsh/workbuddy-meter/balance.json
{
  "v": 1,
  "at": 1792324136123,
  "accounts": [
    { "accountId": "workbuddy-39fd267f", "provider": "workbuddy", "nickname": "alice",
      "total": 7.23, "expiredTotal": 0, "packages": [ ...原始包... ] }
  ]
}
```

---

## 5. 插件对外的 HTTP 路由（Host 半身）

挂载方式（与 dsh-context 同款）：
```js
ctx.inject(['connection'], (scope) => {
  const connection = scope.get('connection')
  registerFetch(scope, connection, '/api/workbuddy-meter/summary', handler, 'label')
})
```

| 路由 | 方法 | 请求 | 响应 |
|---|---|---|---|
| `/api/workbuddy-meter/summary` | POST | `{ sinceDays?: number }`（默认 7，钳制 1..90） | `{ ok: true, value: { days: [...], totals: {...}, derived: {...} } }` |
| `/api/workbuddy-meter/balance` | POST | `{ force?: boolean }` | `{ ok: true, value: { at, accounts: [...] } }` |
| `/api/workbuddy-meter/patch-status` | POST | `{}` | `{ ok: true, value: { installed: bool, anchors: number, ofmVersion: string, lastPatchAt: number\|null } }` |
| `/api/workbuddy-meter/export` | POST | `{ sinceDays?: number, format: 'csv'\|'json' }` | `{ ok: true, value: { filename, content } }` |

错误统一：`{ ok: false, error: { code, message } }`，HTTP 200（与 dsh-context 一致）。

---

## 6. 面板契约（Client 半身）

- **注册位置**：`sidebar.panellist`（id = `workbuddy-meter`，order = 30，label = 本地化"用量"）+ `main`（key = `workbuddy-meter`）
- **参考实现**：`dsh-context` 的 `Is()` 函数（`lib/client.js`），模式：
  ```js
  ctx.slots.inject('main', () => ctx.slots.register({ name: 'main', key: 'workbuddy-meter', locale }, Panel))
  ctx.slots.inject('sidebar.panellist', () => ctx.slots.register({ name: 'sidebar.panellist', id: 'workbuddy-meter', order: 30, label: () => t('title'), locale }, Icon))
  ```
- **取数**：`fetch('api/workbuddy-meter/summary', { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ sinceDays }) })`
- **主题**：只用 `var(--dsw-alias-*)` token，不写死颜色；亮/暗自动适配

面板信息架构（自上而下）：
1. **概览卡**：今日/7日/30日 切换 → 请求数、总 token、总积分、实测单价
2. **趋势图**：按天的 token 柱状 + 积分折线（双轴）；纯 SVG，不引第三方图表库
3. **模型明细表**：model × provider → 请求、token、cache 命中率、积分、单价
4. **账号余额**：每个 WorkBuddy/CodeBuddy 账号 → 剩余积分（`*Precise` 精度）、到期时间、状态
5. **补丁状态条**：OFM 版本、补丁是否在位、锚点数；不在位时给"重新打补丁"按钮

---

## 7. 补丁契约（scripts/patch-ofm.mjs）

### 7.1 行为

```
node scripts/patch-ofm.mjs            # dry-run，只报告会改什么
node scripts/patch-ofm.mjs --apply    # 实际写
node scripts/patch-ofm.mjs --revert   # 从备份还原
node scripts/patch-ofm.mjs --check    # 退出码 0=已在位 / 1=未打 / 2=版本漂移
```

### 7.2 补丁内容（最小侵入）

在 buddy 的 `if (data.usage) {` 块内、`yield { type: "usage", usage: {...} }` **之前**，插入一行采集调用：

```js
;globalThis.__wbMeter?.capture?.({
  provider: this.product.id,
  model: options.model,
  accountId: currentAccountId,
  usage: data.usage,
  startedAt: meta?.startedAt
})
```

（实际变量名以锚点上下文为准；`this.product.id` 在 BuddyAdapter 内可用，`options.model` 可用，`currentAccountId` 在 `consumeSse` 签名里。）

Host 半身在 `apply()` 里设置 `globalThis.__wbMeter = { capture(rec) {...} }`，**这样补丁不依赖任何 import，也不改 pack.js 的模块图**。

### 7.3 安全要求

- 打补丁前自动备份 `pack.js` → `pack.js.backup-<ISO时间戳>`
- 幂等：已含标记 `__wbMeter` 就跳过
- 失败（锚点数 ≠ 1）必须**不改文件**并报错
- 记录到 `~/.dsh/workbuddy-meter/patch-state.json`：`{ ofmVersion, patchedAt, anchorLine, backupPath, sha256Before, sha256After }`
- OFM 升级后 pack.js 被覆盖 → `--check` 报未打，面板显示提示

---

## 8. 写作用域划分（防冲突）

| 目录/文件 | Owner | 说明 |
|---|---|---|
| `index.js`（Host 半身） | **host-worker** | 采集钩子、聚合、4 个 HTTP 路由、补丁状态 |
| `client.js`（Client 半身） | **ui-worker** | 面板 UI、SVG 图表、主题 |
| `scripts/patch-ofm.mjs` | **patch-worker** | 补丁脚本（dry-run/apply/revert/check） |
| `package.json` / `cordis.patch.yml` / `locale/*.json` / `icon.svg` | **Lead** | 骨架与元数据，已冻结，不要改 |
| `CONTRACT.md` | **Lead** | 契约，改前通知 |

---

## 9. 验收标准

1. `node scripts/patch-ofm.mjs --check` 退出码 0
2. 打补丁后发一次真实 WorkBuddy 请求 → `~/.dsh/workbuddy-meter/usage-<今天>.jsonl` 出现一条 `credit` 非 null 的记录
3. `POST /api/workbuddy-meter/summary` 返回聚合正确（可用 jsonl 手算校验）
4. 面板在 DSH 侧边栏出现"用量"图标，点击进入可见概览/趋势/明细/余额四块
5. 补丁可 `--revert` 完全还原（sha256 与备份一致）
6. OFM 版本变更时面板显示"补丁失配"提示，不崩溃

---

*冻结于 2026-10-18。改契约 = 三方同步 + Lead 批准。*
