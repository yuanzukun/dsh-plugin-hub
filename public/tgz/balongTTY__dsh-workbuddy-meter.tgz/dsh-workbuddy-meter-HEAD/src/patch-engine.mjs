/**
 * OFM pack.js patch engine — shared by `scripts/patch-ofm.mjs` and the Host
 * half's self-heal path.
 *
 * Why a shared module: every `pluginManager` install/remove runs pnpm, and pnpm
 * re-materialises `dsh-our-free-model` from its pinned tarball. That silently
 * reverts the patch. Rather than asking the user to remember, the Host half
 * re-applies it on boot when it notices the marker is gone.
 *
 * The patch itself is one line calling `globalThis.__wbMeter.capture(...)`
 * right before the BuddyAdapter yields its usage frame. It needs no imports and
 * touches no other part of the bundle.
 */

import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import crypto from 'node:crypto'

/** Marker that proves the patch is present. */
export const PATCH_MARKER = '__wbMeter'

/** The comment that makes the anchor unique across the four usage blocks. */
export const ANCHOR_COMMENT = '与 codearts 一致：inputTokens 只计'

/** The line inserted before the `yield { type: "usage" }` block. */
export const PATCH_LINE =
  ';globalThis.__wbMeter?.capture?.({ provider: this.product.id, model: options.model, accountId: policyBlockedAccountId ?? "", usage: data.usage, startedAt: Date.now() })'

export function sha256(text) {
  return crypto.createHash('sha256').update(text).digest('hex')
}

/** Resolve `~/.dsh` honouring DSH_HOME. */
export function resolveDshHome() {
  const env = String(process.env.DSH_HOME ?? '').trim()
  return env.length > 0 ? env : path.join(os.homedir(), '.dsh')
}

/** Resolve the installed OFM package directory for a profile. */
export function resolveOfmDir({ dshHome, profile = 'desktop' } = {}) {
  const home = dshHome ?? resolveDshHome()
  const name = String(profile ?? 'desktop').trim() || 'desktop'
  return path.join(home, 'profiles', name, 'node_modules', 'dsh-our-free-model')
}

/** The pack file the patch targets. */
export function resolvePackFile(options = {}) {
  return path.join(resolveOfmDir(options), 'vendor', 'channel-pack', 'pack.js')
}

/** Read OFM's manifest version, or '' when unreadable. */
export function readOfmVersion(ofmDir) {
  try {
    const manifest = JSON.parse(fs.readFileSync(path.join(ofmDir, 'package.json'), 'utf8'))
    return typeof manifest?.version === 'string' ? manifest.version : ''
  } catch {
    return ''
  }
}

/** Count non-overlapping occurrences. */
export function countOccurrences(text, needle) {
  let count = 0
  let index = 0
  while ((index = text.indexOf(needle, index)) !== -1) {
    count += 1
    index += needle.length
  }
  return count
}

/**
 * Inspect a pack file without touching it.
 * @returns {{ok:boolean, reason?:string, patched:boolean, anchors:number, markers:number, sha256:string, text?:string}}
 */
export function inspectPack(packFile) {
  let text
  try {
    text = fs.readFileSync(packFile, 'utf8')
  } catch (error) {
    return {
      ok: false,
      reason: `pack.js 读取失败：${error instanceof Error ? error.message : String(error)}`,
      patched: false,
      anchors: 0,
      markers: 0,
      sha256: '',
    }
  }
  const markers = countOccurrences(text, PATCH_MARKER)
  const anchors = countOccurrences(text, ANCHOR_COMMENT)
  return {
    ok: true,
    patched: markers > 0,
    markers,
    anchors,
    sha256: sha256(text),
    text,
  }
}

/**
 * Locate the insertion point: the line index of the `yield {` that follows the
 * unique anchor comment. Returns null when the shape is not what we expect.
 */
export function findInsertIndex(lines) {
  const commentIndex = lines.findIndex((line) => line.includes(ANCHOR_COMMENT))
  if (commentIndex < 0) return null
  // The comment sits inside the usage object literal; walk forward to the
  // `yield {` that opened it. The yield always precedes the comment.
  for (let i = commentIndex; i >= 0; i -= 1) {
    const line = lines[i]
    if (/^\s*yield\s*\{\s*$/.test(line)) {
      return { yieldIndex: i, commentIndex }
    }
    if (commentIndex - i > 20) break
  }
  return null
}

/**
 * Apply the patch to a pack file.
 * @returns {{applied:boolean, reason?:string, backupPath?:string, sha256Before?:string, sha256After?:string, anchorLine?:number}}
 */
export function applyPatch({ packFile, dryRun = false } = {}) {
  const file = packFile ?? resolvePackFile()
  const state = inspectPack(file)
  if (!state.ok) return { applied: false, reason: state.reason }
  if (state.patched) return { applied: false, reason: 'already-patched', sha256Before: state.sha256, sha256After: state.sha256 }
  if (state.anchors !== 1) {
    return {
      applied: false,
      reason: `锚点唯一性校验失败：命中 ${state.anchors} 次（期望 1）。OFM 版本可能已变，未改动任何文件。`,
    }
  }

  const lines = state.text.split('\n')
  const found = findInsertIndex(lines)
  if (found === null) {
    return { applied: false, reason: '找不到 `yield { type: "usage" }` 插入点；OFM 结构可能已变，未改动任何文件。' }
  }

  const yieldLine = lines[found.yieldIndex]
  const indent = (yieldLine.match(/^\s*/) ?? [''])[0]
  lines.splice(found.yieldIndex, 0, indent + PATCH_LINE)
  const nextText = lines.join('\n')

  if (dryRun) {
    return {
      applied: false,
      reason: 'dry-run',
      anchorLine: found.yieldIndex + 1,
      sha256Before: state.sha256,
      sha256After: sha256(nextText),
    }
  }

  const stamp = new Date().toISOString().replace(/[:.]/g, '-')
  const backupPath = `${file}.backup-${stamp}`
  fs.copyFileSync(file, backupPath)
  const tmp = `${file}.wbm-tmp`
  fs.writeFileSync(tmp, nextText, 'utf8')
  fs.renameSync(tmp, file)

  const after = inspectPack(file)
  if (!after.ok || !after.patched) {
    // Roll back rather than leave a half-written bundle.
    fs.copyFileSync(backupPath, file)
    return { applied: false, reason: '写入后复验失败，已回滚', backupPath }
  }

  return {
    applied: true,
    backupPath,
    anchorLine: found.yieldIndex + 1,
    sha256Before: state.sha256,
    sha256After: after.sha256,
  }
}

/** Restore from the newest backup next to the pack file. */
export function revertPatch({ packFile } = {}) {
  const file = packFile ?? resolvePackFile()
  const dir = path.dirname(file)
  let backups = []
  try {
    backups = fs
      .readdirSync(dir)
      .filter((name) => name.startsWith(`${path.basename(file)}.backup-`))
      .sort()
  } catch {
    return { reverted: false, reason: '目录不可读' }
  }
  if (backups.length === 0) return { reverted: false, reason: '没有可用备份' }
  const newest = path.join(dir, backups[backups.length - 1])
  fs.copyFileSync(newest, file)
  const after = inspectPack(file)
  return { reverted: true, backupPath: newest, patched: after.patched, sha256: after.sha256 }
}

/** Where the patch bookkeeping lives. */
export function patchStatePath(dataDir) {
  return path.join(dataDir ?? path.join(resolveDshHome(), 'workbuddy-meter'), 'patch-state.json')
}

/** Read the recorded patch state, or null. */
export function readPatchState(dataDir) {
  try {
    const parsed = JSON.parse(fs.readFileSync(patchStatePath(dataDir), 'utf8'))
    return typeof parsed === 'object' && parsed !== null ? parsed : null
  } catch {
    return null
  }
}

/** Persist the patch state. */
export function writePatchState(dataDir, state) {
  const file = patchStatePath(dataDir)
  fs.mkdirSync(path.dirname(file), { recursive: true })
  fs.writeFileSync(file, `${JSON.stringify(state, null, 2)}\n`, 'utf8')
}


/* ================================================================== *
 * Patch #2 — 关键词风控中和（可运行时开关）
 *
 * 上游腾讯网关对 system prompt 里的关键词做内容风控：命中
 * 「DeepSeek Harness」就回 HTTP 400 / code 11128，措辞伪装成
 * 「Illegal API invocation from an unapproved channel」。
 *
 * 设计要点：pack.js 里只插**一行**极轻量的钩子，真正的替换逻辑由 Host
 * 半身通过 globalThis.__wbLexicon 提供。这样：
 *   ① 面板上开关即时生效，无需重新打补丁、无需重启 DSH；
 *   ② 关掉开关 = 完全回到原始行为（钩子读到 undefined 直接跳过）；
 *   ③ 逻辑集中在插件里，pack.js 只留一行，升级重打成本最低。
 * ================================================================== */

/** 关键词补丁的标记（证明钩子那行在位）。 */
export const LEXICON_MARKER = '__wbLexicon'

/** 钩子插入锚点：workbuddy 专属的首条 system 兜底块之后。 */
export const LEXICON_ANCHOR =
  'if (this.product.id === "workbuddy" && (messages.length === 0 || messages[0].role !== "system")) {'

/** 插在锚点块结束大括号之后的换行处。 */
const LEXICON_BLOCK_END = '\n    }\n'

/** 空白文本开关默认值。 */
export const LEXICON_DEFAULT_STATE = {
  enabled: true,
  hideIdentity: true,
  ensureSystem: true,
  keywords: ['DeepSeek Harness'],
}

function lexiconHookLine(indent) {
  return (
    indent +
    ';globalThis.__wbLexicon?.rewrite?.(messages);'
  )
}

/**
 * 在 pack.js 里定位关键词钩子的插入点。
 * @returns {{ok:boolean, reason?:string, index?:number, indent?:string}}
 */
export function findLexiconInsertPoint(text) {
  const anchorCount = countOccurrences(text, LEXICON_ANCHOR)
  if (anchorCount !== 1) {
    return { ok: false, reason: `关键词补丁锚点命中 ${anchorCount} 次（期望 1）—— OFM 版本可能已变` }
  }
  const anchorAt = text.indexOf(LEXICON_ANCHOR)
  // 锚点块是 if (...) { ... }，找到它闭合的那个 } —— 紧跟在后面的换行处插入。
  let depth = 0
  let i = anchorAt
  let seenBrace = false
  for (; i < text.length; i += 1) {
    const ch = text[i]
    if (ch === '{') {
      depth += 1
      seenBrace = true
    } else if (ch === '}') {
      depth -= 1
      if (seenBrace && depth === 0) {
        i += 1
        break
      }
    }
  }
  if (!seenBrace || depth !== 0) {
    return { ok: false, reason: '无法定位关键词补丁锚点块的闭合位置' }
  }
  // 跳到该行行尾
  const lineEnd = text.indexOf('\n', i)
  const insertAt = lineEnd < 0 ? text.length : lineEnd
  const lineStart = text.lastIndexOf('\n', anchorAt) + 1
  const indent = (text.slice(lineStart).match(/^\s*/) ?? [''])[0]
  return { ok: true, index: insertAt, indent }
}

/** 检查关键词补丁是否在位。 */
export function inspectLexicon(packFile) {
  let text
  try {
    text = fs.readFileSync(packFile, 'utf8')
  } catch (error) {
    return { ok: false, reason: `pack.js 读取失败：${error instanceof Error ? error.message : String(error)}`, patched: false, markers: 0, anchors: 0, sha256: '' }
  }
  const markers = countOccurrences(text, LEXICON_MARKER)
  const anchors = countOccurrences(text, LEXICON_ANCHOR)
  return { ok: true, patched: markers > 0, markers, anchors, sha256: sha256(text), text }
}

/**
 * 应用关键词钩子补丁。
 * @returns {{applied:boolean, reason?:string, backupPath?:string, sha256Before?:string, sha256After?:string, anchorLine?:number}}
 */
export function applyLexiconPatch({ packFile, dryRun = false } = {}) {
  const file = packFile ?? resolvePackFile()
  const state = inspectLexicon(file)
  if (!state.ok) return { applied: false, reason: state.reason }
  if (state.patched) {
    return { applied: false, reason: 'already-patched', sha256Before: state.sha256, sha256After: state.sha256 }
  }
  const where = findLexiconInsertPoint(state.text)
  if (!where.ok) return { applied: false, reason: where.reason }

  const hook = lexiconHookLine(where.indent)
  const nextText = state.text.slice(0, where.index) + '\n' + hook + state.text.slice(where.index)

  if (dryRun) {
    return { applied: false, reason: 'dry-run', sha256Before: state.sha256, sha256After: sha256(nextText) }
  }

  const stamp = new Date().toISOString().replace(/[:.]/g, '-')
  const backupPath = `${file}.lexicon-backup-${stamp}`
  fs.copyFileSync(file, backupPath)
  const tmp = `${file}.wbm-lex-tmp`
  fs.writeFileSync(tmp, nextText, 'utf8')
  fs.renameSync(tmp, file)

  const after = inspectLexicon(file)
  if (!after.ok || !after.patched) {
    fs.copyFileSync(backupPath, file)
    return { applied: false, reason: '写入后复验失败，已回滚', backupPath }
  }
  return {
    applied: true,
    backupPath,
    sha256Before: state.sha256,
    sha256After: after.sha256,
  }
}

/** 移除关键词钩子补丁（只删那一行）。 */
export function revertLexiconPatch({ packFile } = {}) {
  const file = packFile ?? resolvePackFile()
  const state = inspectLexicon(file)
  if (!state.ok) return { reverted: false, reason: state.reason }
  if (!state.patched) return { reverted: false, reason: 'not-patched' }
  const lines = state.text.split('\n').filter((line) => !line.includes(LEXICON_MARKER))
  const nextText = lines.join('\n')
  const tmp = `${file}.wbm-lex-rev-tmp`
  fs.writeFileSync(tmp, nextText, 'utf8')
  fs.renameSync(tmp, file)
  const after = inspectLexicon(file)
  return { reverted: true, patched: after.ok ? after.patched : true, sha256: after.ok ? after.sha256 : '' }
}
