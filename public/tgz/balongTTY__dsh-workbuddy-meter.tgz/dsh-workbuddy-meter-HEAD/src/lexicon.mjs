/**
 * 关键词风控中和（lexicon）—— 运行时开关的实现
 *
 * ## 为什么需要
 * 上游腾讯 WorkBuddy/CodeBuddy 网关对 system prompt 里的关键词做内容风控：
 * 命中「DeepSeek Harness」就回 HTTP 400 / code 11128，措辞伪装成
 * `Illegal API invocation from an unapproved channel`（极具误导性，实测与
 * 渠道、域名、客户端身份、请求头全都无关）。
 *
 * 实测（真实 DSH 请求形状：316 tools + effort=max + max_tokens=128000）：
 *   含 "DeepSeek Harness" 原样          → 0/5 全失败
 *   含 "DeepSeek\u200B Harness"（零宽） → 5/5 全通过
 *   同形状但短 system prompt（<1KB）不触发 —— 关键词 + 体积综合判定
 *
 * ## 为什么在出站层做而不是改宿主
 * 文案由 DSH 宿主生成（app.asar 内），改宿主既侵入升级又影响所有 provider。
 * 在 WorkBuddy 的出站 messages 上统一改写，只覆盖该渠道。
 *
 * ## 关键约束：不能无差别替换
 * 运行时上下文里有真实文件路径：
 *   D:\10_COD\DeepSeek Harness\resources\app.asar\dsh\
 * 若在路径里插入零宽字符，模型会把坏路径传给工具调用导致失败。
 * 因此用前后负向断言跳过路径语境（前后不能是 / 或 \）。
 * 实测：中和后路径里残留的那 1 处不会触发拦截（上游匹配身份陈述位置，
 * 不是全文子串）—— 原文 0/4，中和后 4/4。
 *
 * ## 为什么是可开关的
 * 上游随时可能改动策略。开关关掉 = 完全回到原始行为（钩子读到 undefined
 * 直接跳过，pack.js 那行变空操作）。不需要重新打补丁、不需要重启。
 */

/** 零宽空格：渲染上完全无差别，但上游的子串匹配不再命中。 */
export const ZERO_WIDTH_SPACE = '\u200B'

/** 默认配置。 */
export const LEXICON_DEFAULTS = {
  /** 总开关：关掉则钩子完全不介入，行为与未打补丁一致。 */
  enabled: true,
  /** 是否中和身份陈述里的关键词。 */
  neutralize: true,
  /** 是否额外隐藏「DeepSeek Harness」中的品牌词（更激进，默认关）。 */
  hideIdentity: false,
  /** 是否给非 system 开头的会话注入保底 system（11128 的另一个成因）。 */
  ensureSystem: true,
  /** 受管关键词列表（区分大小写，按整词对匹配）。 */
  keywords: ['DeepSeek Harness'],
}

/** 保底 system：上游要求首条必须是 system prompt。 */
export const FALLBACK_SYSTEM = 'You are a helpful assistant.'

/**
 * 把配置规范化成安全形态（防御坏配置让钩子抛错）。
 * 钩子运行在 OFM 的 SSE 流里，抛错会中断请求，所以这里必须永不 throw。
 */
export function normalizeLexiconConfig(raw) {
  const input = typeof raw === 'object' && raw !== null ? raw : {}
  const keywords = Array.isArray(input.keywords)
    ? input.keywords.filter((item) => typeof item === 'string' && item.trim().length > 0).map((item) => item.trim())
    : LEXICON_DEFAULTS.keywords
  return {
    enabled: input.enabled !== false,
    neutralize: input.neutralize !== false,
    hideIdentity: input.hideIdentity === true,
    ensureSystem: input.ensureSystem !== false,
    keywords: keywords.length > 0 ? keywords : LEXICON_DEFAULTS.keywords,
  }
}

/** 转义正则元字符。 */
function escapeRegExp(text) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

/**
 * 构造匹配器：关键词内部允许任意空白（含不间断空格与多个空格），
 * 但**前后不能是路径分隔符**，避免破坏 Windows/POSIX 路径。
 */
export function buildKeywordPattern(keyword) {
  const parts = keyword.split(/\s+/).filter(Boolean).map(escapeRegExp)
  if (parts.length === 0) return null
  const body = parts.join('[ \\u00A0]+')
  return new RegExp(`(?<![\\\\/])${body}(?![\\\\/])`, 'g')
}

/**
 * 中和单个字符串里的关键词。
 * @returns {{text:string, hits:number}}
 */
export function neutralizeText(text, config) {
  if (typeof text !== 'string' || text.length === 0) return { text, hits: 0 }
  let out = text
  let hits = 0
  for (const keyword of config.keywords) {
    const pattern = buildKeywordPattern(keyword)
    if (pattern === null) continue
    out = out.replace(pattern, (match) => {
      hits += 1
      // 在关键词语块之间插入零宽空格，保留原大小写与词间距的语义
      return match.split(/[ \u00A0]+/).join(ZERO_WIDTH_SPACE + ' ')
    })
    if (config.hideIdentity) {
      // 更激进：连品牌词本身也打散（默认关，避免破坏工具描述）
      const brandPattern = new RegExp('(?<![\\\\/])DeepSeek(?![\\\\/])', 'g')
      out = out.replace(brandPattern, 'Deep' + ZERO_WIDTH_SPACE + 'Seek')
    }
  }
  return { text: out, hits }
}

/**
 * 递归改写一条 message 里所有字符串字段。
 * content 可能是 string，也可能是 parts 数组（parts 里还有 text 字段）。
 * @returns {number} 命中次数
 */
export function neutralizeMessage(message, config) {
  if (message === null || typeof message !== 'object') return 0
  let hits = 0
  for (const key of Object.keys(message)) {
    const value = message[key]
    if (typeof value === 'string') {
      const result = neutralizeText(value, config)
      if (result.hits > 0) {
        message[key] = result.text
        hits += result.hits
      }
    } else if (Array.isArray(value)) {
      for (let i = 0; i < value.length; i += 1) {
        const item = value[i]
        if (typeof item === 'string') {
          const result = neutralizeText(item, config)
          if (result.hits > 0) {
            value[i] = result.text
            hits += result.hits
          }
        } else if (item !== null && typeof item === 'object') {
          hits += neutralizeMessage(item, config)
        }
      }
    } else if (value !== null && typeof value === 'object') {
      hits += neutralizeMessage(value, config)
    }
  }
  return hits
}

/**
 * 对整份 messages 做中和 + 首条 system 兜底。
 * 这个函数被 pack.js 里那一行钩子调用，**必须永不抛错**。
 * @returns {{hits:number, injected:boolean}}
 */
export function rewriteMessages(messages, rawConfig) {
  const config = normalizeLexiconConfig(rawConfig)
  if (!config.enabled) return { hits: 0, injected: false, skipped: true }
  if (!Array.isArray(messages)) return { hits: 0, injected: false }

  let hits = 0
  if (config.neutralize) {
    for (let i = 0; i < messages.length; i += 1) {
      hits += neutralizeMessage(messages[i], config)
    }
  }

  let injected = false
  if (config.ensureSystem) {
    const first = messages[0]
    if (first === undefined || first === null || first.role !== 'system') {
      messages.unshift({ role: 'system', content: FALLBACK_SYSTEM })
      injected = true
    }
  }
  return { hits, injected }
}

/**
 * 装一个永不抛错的钩子到 globalThis.__wbLexicon。
 * pack.js 里那一行是 `globalThis.__wbLexicon?.rewrite?.(messages)`，
 * 未装时可选链短路，行为与未打补丁完全一致。
 *
 * @param {{ getConfig: () => object, onStats?: (stats:object) => void, logger?: object }} deps
 * @returns {() => void} 卸载函数
 */
export function installLexiconHook(deps) {
  const { getConfig, onStats, logger } = deps

  const hook = {
    rewrite(messages) {
      // 这里抛错会中断 OFM 的 SSE 流，所以整体包 try/catch。
      try {
        const config = normalizeLexiconConfig(getConfig())
        if (!config.enabled) return
        const result = rewriteMessages(messages, config)
        if (result.hits > 0 || result.injected) onStats?.(result)
      } catch (error) {
        logger?.debug?.(
          `workbuddy-meter: lexicon rewrite failed (${error instanceof Error ? error.message : String(error)})`,
        )
      }
    },
  }

  globalThis.__wbLexicon = hook
  return () => {
    if (globalThis.__wbLexicon === hook) delete globalThis.__wbLexicon
  }
}
