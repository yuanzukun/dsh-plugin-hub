/**
 * workbuddy-meter — Host half.
 *
 * Records every local `buddy/` / `workbuddy/` channel request (token detail +
 * the upstream `usage.credit` the OFM adapter discards), aggregates it, reads
 * account credit balances from the upstream billing endpoint, and exposes four
 * POST routes on the DSH connection service for the browser half.
 *
 * Contract: ./CONTRACT.md (frozen v1). Zero third-party dependencies: node:fs,
 * node:path, node:os plus the global `fetch` / `Response`.
 *
 * The capture hook is installed on `globalThis.__wbMeter` so the OFM patch
 * (scripts/patch-ofm.mjs) can call it without importing anything from here and
 * without touching pack.js's module graph.
 */

import crypto from 'node:crypto'
import { createRequire } from 'node:module'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {
  applyLexiconPatch,
  applyPatch,
  inspectLexicon,
  inspectPack,
  readOfmVersion,
  readPatchState,
  resolveOfmDir,
  resolvePackFile,
  revertLexiconPatch,
  writePatchState,
} from './src/patch-engine.mjs'
import {
  LEXICON_DEFAULTS,
  installLexiconHook,
  normalizeLexiconConfig,
  rewriteMessages,
} from './src/lexicon.mjs'

export const name = 'workbuddy-meter'

/** No hard startup dependency: `connection` and `credentials` are injected lazily. */
export const inject = []

/* ------------------------------------------------------------------ *
 * Constants
 * ------------------------------------------------------------------ */

const SCHEMA_VERSION = 1
const DATA_DIR_NAME = 'workbuddy-meter'
const MAX_FILE_BYTES = 32 * 1024 * 1024
const DAY_MS = 86400000
const UTC8_OFFSET_MS = 8 * 3600 * 1000
const DEFAULT_SINCE_DAYS = 7
const MIN_SINCE_DAYS = 1
const MAX_SINCE_DAYS = 90
const BALANCE_CACHE_MS = 60_000
const BALANCE_TIMEOUT_MS = 30_000
const USER_RESOURCE_PATH = '/v2/billing/meter/get-user-resource'
const PACKAGE_STATUS_EXPIRED = 3
const TRACKED_PROVIDERS = new Set(['buddy', 'workbuddy'])
// Both halves live side by side: `usage-*` is this machine, `server-*` is the
// HK gateway. The prefix is captured so callers can filter by origin.
const USAGE_FILE_RE = /^(usage|server)-(\d{4}-\d{2}-\d{2})(?:-(\d+))?\.jsonl$/

/**
 * Upstream product descriptors, copied from OFM `vendor/channel-pack/src/product.ts`
 * so the balance request looks exactly like the client that owns the credential.
 */
const PRODUCTS = {
  workbuddy: {
    endpoint: 'https://www.workbuddy.ai',
    apiDomain: 'www.workbuddy.ai',
    productCode: 'workbuddy',
    userAgent: 'WorkBuddy/5.5.2 WorkBuddy AI/5.5.2 CLI/5.5.2',
  },
  buddy: {
    endpoint: 'https://copilot.tencent.com',
    apiDomain: 'copilot.tencent.com',
    productCode: 'codebuddy',
    userAgent: 'CodeBuddyIDE/1.106.1',
  },
}

/** The `X-Product` value the client sends for both WorkBuddy and CodeBuddy. */
const DEPLOYMENT_TYPE = 'SaaS'

/* ------------------------------------------------------------------ *
 * Small helpers
 * ------------------------------------------------------------------ */

function pad2(n) {
  return n < 10 ? `0${n}` : String(n)
}

/** Day key in UTC+8, matching OFM's `utc8DayKey`. */
function utc8Day(ts) {
  const d = new Date(ts + UTC8_OFFSET_MS)
  return `${d.getUTCFullYear()}-${pad2(d.getUTCMonth() + 1)}-${pad2(d.getUTCDate())}`
}

function toFiniteNumber(value, fallback = 0) {
  return typeof value === 'number' && Number.isFinite(value) ? value : fallback
}

/** A count that can never go below zero: corrupt input becomes 0, not a debit. */
function nonNegative(value) {
  const n = toFiniteNumber(value)
  return n > 0 ? n : 0
}

function roundTo(value, digits) {
  const factor = 10 ** digits
  return Math.round(value * factor) / factor
}

function clampSinceDays(raw) {
  const n = typeof raw === 'number' && Number.isFinite(raw) ? Math.trunc(raw) : DEFAULT_SINCE_DAYS
  return Math.min(MAX_SINCE_DAYS, Math.max(MIN_SINCE_DAYS, n))
}

function stripModelPrefix(model, provider) {
  const text = typeof model === 'string' ? model : ''
  const prefixes = [`${provider}/`, 'buddy/', 'workbuddy/']
  for (const prefix of prefixes) {
    if (text.startsWith(prefix)) return text.slice(prefix.length)
  }
  return text
}

function readJsonFile(file) {
  try {
    const text = fs.readFileSync(file, 'utf8')
    const parsed = JSON.parse(text)
    return typeof parsed === 'object' && parsed !== null ? parsed : undefined
  } catch {
    return undefined
  }
}

function writeJsonFile(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true })
  fs.writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`, 'utf8')
}

/** Harness home: explicit config, then `$DSH_HOME`, then `~/.dsh` (same order as dsh-home-paths). */
function resolveDshHome(config) {
  const configured = typeof config?.dshHome === 'string' ? config.dshHome.trim() : ''
  if (configured.length > 0) return path.resolve(configured)
  const fromEnv = typeof process.env.DSH_HOME === 'string' ? process.env.DSH_HOME.trim() : ''
  if (fromEnv.length > 0) return path.resolve(fromEnv)
  return path.join(os.homedir(), '.dsh')
}

/* ------------------------------------------------------------------ *
 * Record shaping (CONTRACT §2.2)
 * ------------------------------------------------------------------ */

/**
 * Turn one upstream usage frame into a durable record.
 *
 * `credit` stays `null` when the upstream did not report it — `null` and `0`
 * mean different things ("not reported" vs "explicitly zero"), and the panel
 * shows them differently.
 *
 * @returns the record, or `null` when the provider is not tracked.
 */
function toRecord(rec, now = Date.now()) {
  const provider = typeof rec?.provider === 'string' ? rec.provider : ''
  if (!TRACKED_PROVIDERS.has(provider)) return null

  const usage = typeof rec?.usage === 'object' && rec.usage !== null ? rec.usage : null
  const promptTokens = toFiniteNumber(usage?.prompt_tokens)
  const completionTokens = toFiniteNumber(usage?.completion_tokens)
  const rawTotal = usage?.total_tokens
  const totalTokens =
    typeof rawTotal === 'number' && Number.isFinite(rawTotal) ? rawTotal : promptTokens + completionTokens

  const cacheReadTokens = toFiniteNumber(
    usage?.prompt_cache_hit_tokens ??
      usage?.prompt_tokens_details?.cached_tokens ??
      usage?.cached_tokens,
  )
  const cacheWriteTokens = toFiniteNumber(
    usage?.cache_creation_input_tokens ?? usage?.prompt_cache_write_tokens,
  )
  const reasoningTokens = toFiniteNumber(
    usage?.completion_thinking_tokens ?? usage?.completion_tokens_details?.reasoning_tokens,
  )

  const credit = usage?.credit
  const creditReported = typeof credit === 'number' && Number.isFinite(credit)

  const startedAt = typeof rec?.startedAt === 'number' && Number.isFinite(rec.startedAt) ? rec.startedAt : 0
  // `durationMs` is only meaningful when `startedAt` marks the real request
  // start. The current patch (CONTRACT §7.2) has no start time in scope inside
  // `consumeSse`, so it passes `Date.now()` at capture time — a "duration" of a
  // few milliseconds is that, not a measurement. Anything under this floor is
  // reported as 0 (unmeasured) rather than as a fabricated sub-millisecond
  // request time.
  const MIN_MEASURABLE_DURATION_MS = 2
  const rawDuration = startedAt > 0 ? now - startedAt : 0
  const durationMs = rawDuration >= MIN_MEASURABLE_DURATION_MS ? rawDuration : 0

  // `ttftMs` is accepted from the caller when a future patch can measure it;
  // otherwise it stays null ("not measured"), never 0.
  const ttftMs =
    typeof rec?.ttftMs === 'number' && Number.isFinite(rec.ttftMs)
      ? rec.ttftMs
      : typeof rec?.firstTokenAt === 'number' && startedAt > 0 && rec.firstTokenAt >= startedAt
        ? rec.firstTokenAt - startedAt
        : null

  const rawError = rec?.error
  const error = rawError === undefined || rawError === null ? null : String(rawError).slice(0, 200)

  return {
    v: SCHEMA_VERSION,
    ts: now,
    provider,
    accountId: typeof rec?.accountId === 'string' ? rec.accountId : '',
    model: stripModelPrefix(rec?.model, provider),
    channel: rec?.channel === 'gateway' ? 'gateway' : 'direct',
    usageReported: usage !== null,
    promptTokens,
    cacheReadTokens,
    cacheWriteTokens,
    completionTokens,
    reasoningTokens,
    totalTokens,
    credit: creditReported ? credit : null,
    creditReported,
    ttftMs,
    durationMs,
    error,
  }
}

/* ------------------------------------------------------------------ *
 * JSONL store (CONTRACT §2.1)
 * ------------------------------------------------------------------ */

/**
 * Reset baseline: records at or before this epoch are excluded from every read.
 *
 * Why a baseline instead of deleting files: the server half is re-pulled from
 * the gateway log on every sync, so deleting `server-*.jsonl` only makes the old
 * rows come back a minute later. A baseline is one number, survives restarts,
 * and keeps the previous data on disk for auditing.
 */
function baselineFile(dataDir) {
  return path.join(dataDir, 'reset-baseline.json')
}

function readBaseline(dataDir) {
  const parsed = readJsonFile(baselineFile(dataDir))
  const ts = parsed?.baselineTs
  return typeof ts === 'number' && Number.isFinite(ts) && ts > 0 ? ts : null
}

function writeBaseline(dataDir, ts) {
  writeJsonFile(baselineFile(dataDir), {
    v: 1,
    baselineTs: ts,
    baselineIso: new Date(ts).toISOString(),
    note: '记录在此时间点之前的用量不计入统计（文件保留，可审计/回滚）',
  })
}

function createStore(dataDir) {
  let dirReady = false

  function ensureDir() {
    if (dirReady) return
    fs.mkdirSync(dataDir, { recursive: true })
    dirReady = true
  }

  /** Today's file, rotating to `usage-<day>-2.jsonl` once the current one passes 32 MB. */
  function pickFile(day, prefix = 'usage') {
    for (let index = 1; index <= 99; index += 1) {
      const filename = index === 1 ? `${prefix}-${day}.jsonl` : `${prefix}-${day}-${index}.jsonl`
      const file = path.join(dataDir, filename)
      let size = 0
      try {
        size = fs.statSync(file).size
      } catch {
        return file
      }
      if (size < MAX_FILE_BYTES) return file
    }
    return path.join(dataDir, `${prefix}-${day}.jsonl`)
  }

  /**
   * Append one record.
   *
   * Server-side records (origin === 'server') go to their own `server-<day>.jsonl`
   * files. They must never share a file with local records: the two halves have
   * different provenance and different credit semantics (local is per-request
   * exact, server is token-only), and mixing them would make "local only"
   * impossible to answer.
   */
  function append(record) {
    ensureDir()
    const prefix = record?.origin === 'server' ? 'server' : 'usage'
    const file = pickFile(utc8Day(record.ts), prefix)
    fs.appendFileSync(file, `${JSON.stringify(record)}\n`, 'utf8')
  }

  /** All records whose UTC+8 day falls inside the `sinceDays` window, oldest first. */
  function read(sinceDays, now = Date.now()) {
    const fromDay = utc8Day(now - (sinceDays - 1) * DAY_MS)
    // A reset baseline hides everything recorded before it without deleting the
    // files: the server half is re-pulled from the gateway log on every sync, so
    // "delete the files" alone would just resurrect the old rows a minute later.
    const baseline = readBaseline(dataDir)
    let filenames
    try {
      filenames = fs.readdirSync(dataDir)
    } catch {
      return []
    }
    const records = []
    for (const filename of filenames) {
      const match = USAGE_FILE_RE.exec(filename)
      if (match === null) continue
      const fileDay = match[2]
      if (fileDay < fromDay) continue
      let text
      try {
        text = fs.readFileSync(path.join(dataDir, filename), 'utf8')
      } catch {
        continue
      }
      for (const line of text.split('\n')) {
        if (line.trim().length === 0) continue
        let parsed
        try {
          parsed = JSON.parse(line)
        } catch {
          continue // a torn final line from a killed process is not fatal
        }
        if (typeof parsed !== 'object' || parsed === null) continue
        const ts = typeof parsed.ts === 'number' && Number.isFinite(parsed.ts) ? parsed.ts : 0
        if (ts === 0) continue
        if (utc8Day(ts) < fromDay) continue
        // Records at or before the reset baseline belong to the previous era.
        if (baseline !== null && ts <= baseline) continue
        records.push(parsed)
      }
    }
    records.sort((a, b) => a.ts - b.ts)
    return records
  }

  return { dir: dataDir, append, read }
}

/* ------------------------------------------------------------------ *
 * Aggregation (CONTRACT §3)
 * ------------------------------------------------------------------ */

function newBucket() {
  return {
    requests: 0,
    reported: 0,
    errors: 0,
    promptTokens: 0,
    cacheReadTokens: 0,
    cacheWriteTokens: 0,
    completionTokens: 0,
    reasoningTokens: 0,
    totalTokens: 0,
    credit: 0,
    creditMissing: 0,
    // Internal accumulators used only to derive prices (not part of §3.1).
    creditTokens: 0,
    coldCredit: 0,
    coldTokens: 0,
    hotCredit: 0,
    hotTokens: 0,
    // Requests whose prompt alone exceeded the large-context threshold, and
    // the credit they cost. Lets the panel say "half your requests, two thirds
    // of your bill" instead of leaving the user to guess.
    largeContextRequests: 0,
    largeContextCredit: 0,
    ttftSumMs: 0,
    ttftCount: 0,
    tpsSum: 0,
    tpsCount: 0,
  }
}

function accumulate(bucket, record) {
  // Large-context accounting. Threshold mirrors ADVICE.largeContextTokens; a
  // shared constant would be nicer but this function is also used by tests
  // that construct records directly.
  if (nonNegative(record.promptTokens) >= 500_000) {
    bucket.largeContextRequests += 1
    if (record.creditReported === true) bucket.largeContextCredit += nonNegative(record.credit)
  }
  bucket.requests += 1
  if (record.usageReported === true) bucket.reported += 1
  if (record.error !== null && record.error !== undefined) bucket.errors += 1
  // Tokens are counts: a negative or NaN value is corrupt input, not a
  // subtraction. Clamp at zero so one bad record cannot shrink the totals.
  bucket.promptTokens += nonNegative(record.promptTokens)
  bucket.cacheReadTokens += nonNegative(record.cacheReadTokens)
  bucket.cacheWriteTokens += nonNegative(record.cacheWriteTokens)
  bucket.completionTokens += nonNegative(record.completionTokens)
  bucket.reasoningTokens += nonNegative(record.reasoningTokens)
  bucket.totalTokens += nonNegative(record.totalTokens)

  const creditReported =
    record.creditReported === true && typeof record.credit === 'number' && Number.isFinite(record.credit)
  if (creditReported) {
    bucket.credit += record.credit
    // §3.2: the unit price denominator is only the tokens of requests that
    // actually reported credit — mixing in unreported ones would deflate it.
    bucket.creditTokens += toFiniteNumber(record.totalTokens)
    if (toFiniteNumber(record.cacheReadTokens) > 0) {
      bucket.hotCredit += record.credit
      bucket.hotTokens += toFiniteNumber(record.totalTokens)
    } else {
      bucket.coldCredit += record.credit
      bucket.coldTokens += toFiniteNumber(record.totalTokens)
    }
  } else {
    bucket.creditMissing += 1
  }

  const ttftMs = record.ttftMs
  if (typeof ttftMs === 'number' && Number.isFinite(ttftMs)) {
    bucket.ttftSumMs += ttftMs
    bucket.ttftCount += 1
  }

  const durationMs = toFiniteNumber(record.durationMs)
  if (durationMs > 0) {
    bucket.tpsSum += toFiniteNumber(record.completionTokens) / (durationMs / 1000)
    bucket.tpsCount += 1
  }
}

/**
 * §3.2 derived metrics. Every ratio with a zero denominator is `null`, never 0.
 *
 * The canonical names are `unitPricePerMTok` / `tokensPerCredit`; the shorter
 * aliases (`unitPrice` / `perCredit` / `reportedTotalTokens`) are what the
 * client half reads so that a host-computed number wins over its local
 * fallback. Both spellings carry the same value.
 */
function derive(bucket) {
  // A zero-credit bucket has no meaningful unit price: 0/0 is not "free", it
  // is "nothing billable to divide". Report null so the UI shows an em dash.
  const unitPricePerMTok =
    bucket.creditTokens > 0 && bucket.credit > 0
      ? roundTo((bucket.credit / bucket.creditTokens) * 1e6, 6)
      : null
  const tokensPerCredit = bucket.credit > 0 ? bucket.totalTokens / bucket.credit : null
  // Cost drivers. A request whose prompt is 470k tokens is expensive no matter
  // how cheap the per-token rate looks; surfacing the two together is what makes
  // "why is my balance draining" answerable instead of mysterious.
  const reportedRequests = Math.max(0, bucket.requests - bucket.creditMissing)
  const avgPromptTokens = reportedRequests > 0 ? bucket.promptTokens / reportedRequests : null
  const creditPerRequest = reportedRequests > 0 ? bucket.credit / reportedRequests : null
  return {
    cacheHitRate: bucket.promptTokens > 0 ? bucket.cacheReadTokens / bucket.promptTokens : null,
    unitPricePerMTok,
    unitPrice: unitPricePerMTok,
    tokensPerCredit,
    perCredit: tokensPerCredit,
    // §3.2 denominator: only the tokens of requests that reported credit.
    reportedTotalTokens: bucket.creditTokens,
    coldUnitPrice: bucket.coldTokens > 0 ? roundTo((bucket.coldCredit / bucket.coldTokens) * 1e6, 6) : null,
    hotUnitPrice: bucket.hotTokens > 0 ? roundTo((bucket.hotCredit / bucket.hotTokens) * 1e6, 6) : null,
    avgTtftMs: bucket.ttftCount > 0 ? roundTo(bucket.ttftSumMs / bucket.ttftCount, 3) : null,
    avgTps: bucket.tpsCount > 0 ? roundTo(bucket.tpsSum / bucket.tpsCount, 3) : null,
    creditReportedRequests: bucket.requests - bucket.creditMissing,
    // Cost drivers (added 2026-10-18 after the reconciliation pass):
    avgPromptTokens: avgPromptTokens === null ? null : Math.round(avgPromptTokens),
    creditPerRequest: creditPerRequest === null ? null : roundTo(creditPerRequest, 6),
  }
}

/** Public bucket shape: §3.1 fields (credit rounded to 6 dp) plus the derived block. */
function presentBucket(bucket) {
  return {
    requests: bucket.requests,
    reported: bucket.reported,
    errors: bucket.errors,
    promptTokens: bucket.promptTokens,
    cacheReadTokens: bucket.cacheReadTokens,
    cacheWriteTokens: bucket.cacheWriteTokens,
    completionTokens: bucket.completionTokens,
    reasoningTokens: bucket.reasoningTokens,
    totalTokens: bucket.totalTokens,
    credit: roundTo(bucket.credit, 6),
    creditMissing: bucket.creditMissing,
    ttftSumMs: bucket.ttftSumMs,
    ttftCount: bucket.ttftCount,
    tpsSum: roundTo(bucket.tpsSum, 3),
    tpsCount: bucket.tpsCount,
    // Extra (additive) fields the panel uses for the cold/hot comparison.
    coldCredit: roundTo(bucket.coldCredit, 6),
    coldTokens: bucket.coldTokens,
    largeContextRequests: bucket.largeContextRequests,
    largeContextCredit: roundTo(bucket.largeContextCredit, 6),
    hotCredit: roundTo(bucket.hotCredit, 6),
    hotTokens: bucket.hotTokens,
    derived: derive(bucket),
  }
}

function mergeInto(target, bucket) {
  for (const key of Object.keys(target)) target[key] += bucket[key]
}

/**
 * Aggregate records by day × provider × model × account (CONTRACT §3.1) and
 * roll the buckets up into per-day, per-model and per-account views.
 */
function aggregate(records, options = {}) {
  const sinceDays = clampSinceDays(options.sinceDays)
  const now = typeof options.now === 'number' ? options.now : Date.now()
  const fromDay = utc8Day(now - (sinceDays - 1) * DAY_MS)

  const buckets = new Map()
  const byDay = new Map()
  const byModel = new Map()
  const byAccount = new Map()
  const totals = newBucket()

  for (const record of records) {
    const ts = toFiniteNumber(record.ts)
    if (ts === 0) continue
    const day = utc8Day(ts)
    if (day < fromDay) continue
    const provider = typeof record.provider === 'string' ? record.provider : ''
    const model = typeof record.model === 'string' ? record.model : ''
    const accountId = typeof record.accountId === 'string' ? record.accountId : ''

    const bucketKey = `${day}|${provider}|${model}|${accountId}`
    let bucket = buckets.get(bucketKey)
    if (bucket === undefined) {
      bucket = newBucket()
      buckets.set(bucketKey, bucket)
    }
    accumulate(bucket, record)

    const dayKey = day
    let dayBucket = byDay.get(dayKey)
    if (dayBucket === undefined) {
      dayBucket = newBucket()
      byDay.set(dayKey, dayBucket)
    }
    accumulate(dayBucket, record)

    const modelKey = `${provider}|${model}`
    let modelBucket = byModel.get(modelKey)
    if (modelBucket === undefined) {
      modelBucket = newBucket()
      byModel.set(modelKey, modelBucket)
    }
    accumulate(modelBucket, record)

    const accountKey = `${provider}|${accountId}`
    let accountBucket = byAccount.get(accountKey)
    if (accountBucket === undefined) {
      accountBucket = newBucket()
      byAccount.set(accountKey, accountBucket)
    }
    accumulate(accountBucket, record)

    accumulate(totals, record)
  }

  const bucketList = [...buckets.entries()]
    .map(([key, bucket]) => {
      const [day, provider, model, accountId] = key.split('|')
      return { day, provider, model, accountId, ...presentBucket(bucket) }
    })
    .sort((a, b) => (a.day === b.day ? b.totalTokens - a.totalTokens : a.day < b.day ? -1 : 1))

  const days = [...byDay.entries()]
    .map(([day, bucket]) => ({ day, ...presentBucket(bucket) }))
    .sort((a, b) => (a.day < b.day ? -1 : 1))

  const models = [...byModel.entries()]
    .map(([key, bucket]) => {
      const [provider, model] = key.split('|')
      return { provider, model, ...presentBucket(bucket) }
    })
    .sort((a, b) => b.totalTokens - a.totalTokens)

  // Model value ranking: cheapest measured unit price first, using only the
  // models this window actually observed. Deliberately no catalogue-wide
  // extrapolation — a model with zero samples cannot be ranked.
  // Unit price comes from credit/tokens, but upstream rounds credit to 0.01.
  // A 261-token request billed 0.01 therefore implies 38 credits/1M — a 20x
  // overstatement that would poison any ranking. Only models whose traffic is
  // large enough for the rounding to be negligible compete for "cheapest".
  const MIN_VALUE_TOKENS = 1_000_000
  const modelValue = models
    .filter(
      (m) =>
        m.derived &&
        m.derived.unitPricePerMTok !== null &&
        m.reported > 0 &&
        toFiniteNumber(m.totalTokens) >= MIN_VALUE_TOKENS,
    )
    .map((m) => ({
      provider: m.provider,
      model: m.model,
      unitPricePerMTok: m.derived.unitPricePerMTok,
      cacheHitRate: m.derived.cacheHitRate,
      requests: m.requests,
      totalTokens: m.totalTokens,
      credit: m.credit,
      // Cheapest measured baseline in this window, used by the UI to show how
      // much a pricier model is costing relative to the best option seen.
      tokensPerCredit: m.derived.tokensPerCredit,
    }))
    .sort((a, b) => a.unitPricePerMTok - b.unitPricePerMTok)

  const cheapest = modelValue.length > 0 ? modelValue[0] : null
  for (const m of modelValue) {
    m.vsCheapest =
      cheapest !== null && cheapest.unitPricePerMTok > 0 && m !== cheapest
        ? roundTo(m.unitPricePerMTok / cheapest.unitPricePerMTok, 3)
        : 1
    // What this model's traffic would have cost at the cheapest measured rate.
    m.atCheapestCredit =
      cheapest !== null && cheapest.unitPricePerMTok > 0
        ? roundTo((m.totalTokens / 1e6) * cheapest.unitPricePerMTok, 4)
        : null
    m.overspendCredit =
      m.atCheapestCredit !== null ? roundTo(Math.max(0, m.credit - m.atCheapestCredit), 4) : null
  }

  const accounts = [...byAccount.entries()]
    .map(([key, bucket]) => {
      const [provider, accountId] = key.split('|')
      return { provider, accountId, ...presentBucket(bucket) }
    })
    .sort((a, b) => b.totalTokens - a.totalTokens)

  // Split kept local-only: server relay tracking was removed by request.
  // Local-only provenance. Server relay tracking was removed by request —
  // the panel counts this machine's OFM process and nothing else.
  const localRecords = records.filter((r) => r?.origin !== 'server')
  const split = (list) => {
    const totalsBucket = newBucket()
    for (const record of list) {
      const ts = toFiniteNumber(record.ts)
      if (ts === 0) continue
      if (utc8Day(ts) < fromDay) continue
      accumulate(totalsBucket, record)
    }
    return {
      requests: totalsBucket.requests,
      totalTokens: totalsBucket.totalTokens,
      promptTokens: totalsBucket.promptTokens,
      completionTokens: totalsBucket.completionTokens,
      cacheReadTokens: totalsBucket.cacheReadTokens,
      credit: roundTo(totalsBucket.credit, 6),
      creditReportedRequests: totalsBucket.requests - totalsBucket.creditMissing,
      derived: derive(totalsBucket),
    }
  }

  return {
    sinceDays,
    fromDay,
    toDay: utc8Day(now),
    generatedAt: now,
    totals: presentBucket(totals),
    derived: derive(totals),
    drivers: deriveDrivers(records, totals, sinceDays, now),
    local: split(localRecords),
    days,
    models,
    modelValue,
    accounts,
    buckets: bucketList,
  }
}

/**
 * Cost-driver summary (added 2026-10-18 after reconciling usage.credit against
 * real balance deltas).
 *
 * Three numbers explain "why is my balance draining" better than the unit price
 * alone:
 *   - avgPromptTokens: context carried per request. The single biggest lever.
 *   - creditPerRequest: what one turn actually costs.
 *   - cacheSavedMultiple: how much the prefix cache is already saving, so a
 *     cheap-looking per-token rate is not mistaken for cheap turns.
 * Also derives a local burn rate — deliberately from LOCAL records only, because
 * account balances are global and include server relay traffic.
 */
function deriveDrivers(records, totals, sinceDays, now) {
  const windowRecords = []
  const fromDay = utc8Day(now - (sinceDays - 1) * DAY_MS)
  for (const record of records) {
    const ts = toFiniteNumber(record.ts)
    if (ts === 0) continue
    if (utc8Day(ts) < fromDay) continue
    windowRecords.push(record)
  }

  const reported = windowRecords.filter(
    (r) => r.creditReported === true && typeof r.credit === 'number' && r.usageReported !== false,
  )
  const reportedCount = reported.length
  const creditSum = reported.reduce((sum, r) => sum + r.credit, 0)
  const tokenSum = reported.reduce((sum, r) => sum + toFiniteNumber(r.totalTokens), 0)
  const promptSum = reported.reduce((sum, r) => sum + toFiniteNumber(r.promptTokens), 0)

  const avgPromptTokens = reportedCount > 0 ? Math.round(promptSum / reportedCount) : null
  const creditPerRequest = reportedCount > 0 ? roundTo(creditSum / reportedCount, 6) : null

  // Cache saving: compare the measured cold rate against what this traffic cost.
  // coldPrice is credits per 1M tokens, so the all-cold cost of `tokenSum` is
  // tokenSum / 1e6 * coldPrice — not the other way round.
  const coldPrice = totals.coldTokens > 0 ? totals.coldCredit / totals.coldTokens : null
  let coldEquivalentCredit = null
  let cacheSavedMultiple = null
  if (coldPrice !== null && coldPrice > 0 && creditSum > 0 && tokenSum > 0) {
    coldEquivalentCredit = roundTo((tokenSum / 1e6) * coldPrice * 1e6, 4)
    cacheSavedMultiple = roundTo(coldEquivalentCredit / creditSum, 2)
  }

  // Context growth across the window (oldest vs newest reported request).
  let firstPrompt = null
  let lastPrompt = null
  if (reportedCount > 0) {
    const sorted = [...reported].sort((a, b) => toFiniteNumber(a.ts) - toFiniteNumber(b.ts))
    firstPrompt = toFiniteNumber(sorted[0].promptTokens)
    lastPrompt = toFiniteNumber(sorted[sorted.length - 1].promptTokens)
  }

  // Local burn rate: credits per hour over the observed span. Uses the actual
  // first/last timestamps rather than the whole range, so a 20-minute session
  // does not get averaged across 24 hours.
  let burnRatePerHour = null
  let spanHours = null
  if (windowRecords.length > 1 && creditSum > 0) {
    const stamps = windowRecords.map((r) => toFiniteNumber(r.ts)).filter((t) => t > 0).sort((a, b) => a - b)
    if (stamps.length > 1) {
      const spanMs = stamps[stamps.length - 1] - stamps[0]
      // Guard against a single burst: below one minute the rate is meaningless.
      if (spanMs >= 60_000) {
        spanHours = roundTo(spanMs / 3_600_000, 4)
        burnRatePerHour = roundTo(creditSum / spanHours, 2)
      }
    }
  }

  // Confidence for the burn rate. A rate measured over minutes swings wildly
  // with one burst, so it must never be shown as a hard number without saying
  // how much data it rests on.
  let burnConfidence = 'none'
  if (burnRatePerHour !== null) {
    if (spanHours >= 6 && reportedCount >= 60) burnConfidence = 'high'
    else if (spanHours >= 1 && reportedCount >= 20) burnConfidence = 'medium'
    else burnConfidence = 'low'
  }

  // "Tokens per request" is the single number that explains why one turn costs
  // what it does; it belongs beside the price rather than buried in a table.
  const tokensPerRequest = reportedCount > 0 ? Math.round(tokenSum / reportedCount) : null
  const promptSumAll = windowRecords.reduce((sum, r) => sum + toFiniteNumber(r.promptTokens), 0)
  const cacheSumAll = windowRecords.reduce((sum, r) => sum + toFiniteNumber(r.cacheReadTokens), 0)
  const cacheHitRate = promptSumAll > 0 ? roundTo(cacheSumAll / promptSumAll, 4) : null

  return {
    // Explicitly local: these come from this process's records only.
    scope: 'local',
    samples: windowRecords.length,
    reportedSamples: reportedCount,
    avgPromptTokens,
    creditPerRequest,
    cacheSavedMultiple,
    coldEquivalentCredit,
    actualCredit: roundTo(creditSum, 6),
    contextGrowth:
      firstPrompt !== null && lastPrompt !== null && firstPrompt > 0
        ? { first: firstPrompt, last: lastPrompt, ratio: roundTo(lastPrompt / firstPrompt, 3) }
        : null,
    burnRatePerHour,
    burnConfidence,
    spanHours,
    tokensPerRequest,
    cacheHitRate,
  }
}

/* ------------------------------------------------------------------ *
 * Balance (CONTRACT §4)
 * ------------------------------------------------------------------ */

function readPreciseNumber(source, baseKey) {
  const precise = source?.[`${baseKey}Precise`]
  if (typeof precise === 'string') {
    const parsed = Number.parseFloat(precise)
    if (Number.isFinite(parsed)) return parsed
  }
  if (typeof precise === 'number' && Number.isFinite(precise)) return precise
  return toFiniteNumber(source?.[baseKey])
}

function parseCreditPackage(entry, now = Date.now()) {
  const status = entry?.Status
  const expiredTime = typeof entry?.ExpiredTime === 'string' ? entry.ExpiredTime : ''
  const deductionEndTime = toFiniteNumber(entry?.DeductionEndTime)
  const expiredAt = expiredTime.length > 0 ? Date.parse(expiredTime.replace(' ', 'T')) : Number.NaN
  const active =
    status !== PACKAGE_STATUS_EXPIRED &&
    !(Number.isFinite(expiredAt) && now >= expiredAt) &&
    !(deductionEndTime > 0 && now >= deductionEndTime)

  return {
    ...entry,
    name: String(entry?.PackageName ?? entry?.SubProductName ?? entry?.PackageCode ?? ''),
    unit: String(entry?.CapacityUnit ?? entry?.OriginUnit ?? ''),
    remaining: readPreciseNumber(entry, 'CycleCapacityRemain'),
    total: readPreciseNumber(entry, 'CycleCapacitySize'),
    used: readPreciseNumber(entry, 'CycleCapacityUsed'),
    active,
    cycleStartTime: String(entry?.CycleStartTime ?? ''),
    cycleEndTime: String(entry?.CycleEndTime ?? ''),
    expiredTime,
  }
}

/** Parse `{code, data:{Response:{Data:{Accounts:[...]}}}}`; `null` when the shape is wrong. */
function parseUserResource(body, now = Date.now()) {
  if (typeof body !== 'object' || body === null) return null
  if (body.code !== 0) {
    return { error: `上游返回 code=${String(body.code)}${body.msg ? `: ${String(body.msg)}` : ''}` }
  }
  const accounts = body?.data?.Response?.Data?.Accounts
  if (!Array.isArray(accounts)) return { error: '响应缺少 data.Response.Data.Accounts' }

  const packages = accounts.map((entry) => parseCreditPackage(entry, now))
  let total = 0
  let expiredTotal = 0
  for (const pkg of packages) {
    if (pkg.active) total += pkg.remaining
    else expiredTotal += pkg.remaining
  }
  return { total: roundTo(total, 8), expiredTotal: roundTo(expiredTotal, 8), packages }
}

function balanceHeaders(credential, product) {
  const headers = {
    authorization: `Bearer ${String(credential?.access_token ?? '')}`,
    accept: 'application/json',
    'content-type': 'application/json',
    'x-domain': String(product.apiDomain || credential?.domain || ''),
    'x-product': DEPLOYMENT_TYPE,
    'x-product-code': product.productCode,
    'user-agent': product.userAgent,
  }
  if (typeof credential?.user_id === 'string' && credential.user_id.length > 0) {
    headers['x-user-id'] = credential.user_id
  }
  if (typeof credential?.enterprise_id === 'string' && credential.enterprise_id.length > 0) {
    headers['x-enterprise-id'] = credential.enterprise_id
    headers['x-tenant-id'] = credential.enterprise_id
  }
  return headers
}

async function fetchCreditBalance({ account, credential, fetchImpl = fetch, now = Date.now() }) {
  const product = PRODUCTS[account.provider]
  if (product === undefined) return { error: `未知 provider: ${account.provider}` }
  if (typeof credential?.access_token !== 'string' || credential.access_token.length === 0) {
    return { error: '凭据缺少 access_token' }
  }

  let response
  try {
    response = await fetchImpl(`${product.endpoint}${USER_RESOURCE_PATH}`, {
      method: 'POST',
      headers: balanceHeaders(credential, product),
      body: '{}',
      signal: AbortSignal.timeout(BALANCE_TIMEOUT_MS),
    })
  } catch (error) {
    return { error: error instanceof Error ? error.message : String(error) }
  }

  let text
  try {
    text = await response.text()
  } catch (error) {
    return { error: error instanceof Error ? error.message : String(error) }
  }

  let parsed
  try {
    parsed = JSON.parse(text)
  } catch {
    return {
      error:
        response.status === 401 || response.status === 403
          ? `凭据已失效（HTTP ${response.status}）`
          : `响应不是 JSON（HTTP ${response.status}）：${text.slice(0, 120)}`,
    }
  }

  const result = parseUserResource(parsed, now)
  if (result === null) return { error: '响应无法解析' }
  if (result.error !== undefined) return { error: result.error }
  return result
}

/** Accounts worth showing: the tracked providers present in the channel-pack pool. */
function readTrackedAccounts(dshHome) {
  const stateFile = path.join(dshHome, 'channel-pack', 'state.json')
  const state = readJsonFile(stateFile)
  const accounts = Array.isArray(state?.accounts) ? state.accounts : []
  const out = []
  for (const entry of accounts) {
    if (typeof entry !== 'object' || entry === null) continue
    if (!TRACKED_PROVIDERS.has(entry.provider)) continue
    out.push({
      accountId: String(entry.id ?? ''),
      provider: String(entry.provider),
      nickname: String(entry.nickname ?? entry.id ?? ''),
      credentialRef: String(entry.credentialRef ?? ''),
      enabled: entry.enabled === true,
    })
  }
  return out
}

/* ------------------------------------------------------------------ *
 * Patch status (CONTRACT §7.3)
 *
 * Path resolution, anchor counting and the patch itself live in
 * `src/patch-engine.mjs` — the same module the self-heal path and
 * `scripts/patch-ofm.mjs` use, so "is it in?" can never drift between them.
 * ------------------------------------------------------------------ */


function readPatchStatus({ dshHome, profile, dataDir }) {
  const ofmDir = resolveOfmDir({ dshHome, profile })
  const defaultPackFile = path.join(ofmDir, 'vendor', 'channel-pack', 'pack.js')
  const ofmVersion = readOfmVersion(ofmDir)
  const state = readJsonFile(path.join(dataDir, 'patch-state.json')) ?? null

  // scripts/patch-ofm.mjs records the exact file it touched; prefer that over
  // recomputing the path so a custom profile still reports its own pack.
  const packFile =
    typeof state?.packPath === 'string' && state.packPath.length > 0 ? state.packPath : defaultPackFile

  // Same engine the self-heal path uses — one source of truth for "is it in?".
  const inspected = inspectPack(packFile)
  const packExists = inspected.ok
  const anchors = inspected.anchors
  const packError = inspected.ok ? null : inspected.reason

  const stateVersion = typeof state?.ofmVersion === 'string' ? state.ofmVersion : ''
  // `patched:false` is the script's own revert record; honour it over a stale marker.
  const reverted = state?.patched === false

  let status
  if (!packExists || !inspected.patched || reverted) status = 'missing'
  else if (stateVersion.length > 0 && ofmVersion.length > 0 && stateVersion !== ofmVersion) status = 'drift'
  else status = 'installed'

  return {
    installed: status === 'installed',
    status,
    anchors,
    ofmVersion,
    patchedOfmVersion: stateVersion,
    lastPatchAt: typeof state?.patchedAt === 'number' ? state.patchedAt : null,
    anchorLine: typeof state?.anchorLine === 'number' ? state.anchorLine : null,
    backupPath: typeof state?.backupPath === 'string' ? state.backupPath : null,
    packPath: packFile,
    packExists,
    // True when the Host half re-applied the patch itself after a pnpm reinstall.
    selfHealed: state?.selfHealed === true,
    ...(packError === null ? {} : { error: packError }),
  }
}

/* ------------------------------------------------------------------ *
 * Export (CONTRACT §5)
 * ------------------------------------------------------------------ */

const RECORD_COLUMNS = [
  'ts',
  'day',
  'provider',
  'accountId',
  'model',
  'channel',
  'usageReported',
  'promptTokens',
  'cacheReadTokens',
  'cacheWriteTokens',
  'completionTokens',
  'reasoningTokens',
  'totalTokens',
  'credit',
  'creditReported',
  'ttftMs',
  'durationMs',
  'error',
]

function csvCell(value) {
  if (value === null || value === undefined) return ''
  const text = String(value)
  return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text
}

function toCsv(records) {
  const lines = [RECORD_COLUMNS.join(',')]
  for (const record of records) {
    const row = RECORD_COLUMNS.map((column) => {
      if (column === 'day') return csvCell(utc8Day(toFiniteNumber(record.ts)))
      if (column === 'credit') return csvCell(record.creditReported === true ? record.credit : '')
      return csvCell(record[column])
    })
    lines.push(row.join(','))
  }
  return lines.join('\n')
}

/* ------------------------------------------------------------------ *
 * HTTP plumbing
 * ------------------------------------------------------------------ */

function jsonResponse(payload) {
  return Response.json(payload, { headers: { 'cache-control': 'no-store' } })
}

function okResponse(value) {
  return jsonResponse({ ok: true, value })
}

function errorResponse(code, message) {
  return jsonResponse({ ok: false, error: { code, message } })
}

async function readBody(request) {
  try {
    const parsed = await request.json()
    return typeof parsed === 'object' && parsed !== null ? parsed : {}
  } catch {
    return {}
  }
}

/* ------------------------------------------------------------------ *
 * Plugin entry
 * ------------------------------------------------------------------ */

/**
 * Read one service off a Cordis scope. Cordis exposes services both as
 * properties and through `get()`; either spelling works depending on version,
 * and a missing service must read as `undefined` rather than throw — a throw
 * inside an `inject` callback would leave the fiber pending forever.
 */
function serviceOf(scope, name) {
  if (scope === undefined || scope === null) return undefined
  try {
    const direct = scope[name]
    if (direct !== undefined && direct !== null) return direct
  } catch {
    /* fall through to get() */
  }
  try {
    if (typeof scope.get === 'function') {
      const viaGet = scope.get(name)
      if (viaGet !== undefined && viaGet !== null) return viaGet
    }
  } catch {
    /* no such service */
  }
  return undefined
}

export function apply(ctx, config) {
  const logger = ctx.logger ?? {}
  // child_process is loaded lazily through createRequire: the plugin must stay
  // importable in environments where spawning is disallowed.
  const require = createRequire(import.meta.url)
  const dshHome = resolveDshHome(config)
  const dataDir =
    typeof config?.dataDir === 'string' && config.dataDir.trim().length > 0
      ? path.resolve(config.dataDir)
      : path.join(dshHome, DATA_DIR_NAME)
  const profile =
    typeof config?.profile === 'string' && config.profile.trim().length > 0
      ? config.profile.trim()
      : typeof process.env.DSH_PROFILE === 'string' && process.env.DSH_PROFILE.trim().length > 0
        ? process.env.DSH_PROFILE.trim()
        : 'desktop'

  const store = createStore(dataDir)
  const balanceFile = path.join(dataDir, 'balance.json')

  /* --- credentials service, resolved lazily so the plugin starts without it --- */
  let credentialsService
  ctx.inject(['credentials'], (scope) => {
    const service = serviceOf(scope, 'credentials')
    credentialsService = service
    scope.effect(
      () => () => {
        if (credentialsService === service) credentialsService = undefined
      },
      'workbuddy-meter: credentials service',
    )
  })

  function getCredentialsService() {
    if (credentialsService !== undefined) return credentialsService
    return serviceOf(ctx, 'credentials')
  }

  /* --- capture hook (CONTRACT §7.2) ------------------------------------- */

  // Never throws: an exception here would break the OFM SSE stream mid-flight.
  const hook = {
    capture(rec) {
      try {
        const record = toRecord(rec, Date.now())
        if (record === null) return
        store.append(record)
      } catch (error) {
        logger.debug?.(`workbuddy-meter: capture failed (${error instanceof Error ? error.message : String(error)})`)
      }
    },
  }

  ctx.effect(() => {
    globalThis.__wbMeter = hook
    return () => {
      if (globalThis.__wbMeter === hook) delete globalThis.__wbMeter
    }
  }, 'workbuddy-meter: capture hook')

  /* --- lexicon: 上游关键词风控中和（可运行时开关）---------------------- *
   * 上游对 system prompt 里的「DeepSeek Harness」做内容风控，命中即回
   * 400 / code 11128（措辞伪装成 unapproved channel）。这里装一个钩子，
   * 由 pack.js 里那一行 `globalThis.__wbLexicon?.rewrite?.(messages)` 调用。
   *
   * 开关关掉 = 钩子直接返回，行为与未打补丁一致；不需要重新打补丁或重启。
   * ------------------------------------------------------------------- */

  const lexiconFile = path.join(dataDir, 'lexicon.json')

  function readLexiconConfig() {
    try {
      const raw = JSON.parse(fs.readFileSync(lexiconFile, 'utf8'))
      return normalizeLexiconConfig(raw)
    } catch {
      return normalizeLexiconConfig(LEXICON_DEFAULTS)
    }
  }

  function writeLexiconConfig(next) {
    const normalized = normalizeLexiconConfig(next)
    fs.mkdirSync(dataDir, { recursive: true })
    const tmp = `${lexiconFile}.tmp`
    fs.writeFileSync(tmp, `${JSON.stringify(normalized, null, 2)}\n`, 'utf8')
    fs.renameSync(tmp, lexiconFile)
    return normalized
  }

  // 运行时统计：让面板能显示「已中和多少次」，出问题时一眼看出钩子有没有跑。
  const lexiconStats = { rewrites: 0, hits: 0, injected: 0, lastAt: null }

  ctx.effect(() => {
    const uninstall = installLexiconHook({
      getConfig: readLexiconConfig,
      logger,
      onStats: (result) => {
        lexiconStats.rewrites += 1
        lexiconStats.hits += result.hits
        if (result.injected) lexiconStats.injected += 1
        lexiconStats.lastAt = Date.now()
      },
    })
    return uninstall
  }, 'workbuddy-meter: lexicon hook')

  /* --- patch self-heal -------------------------------------------------- *
   * Every pluginManager install/remove runs pnpm, and pnpm re-materialises
   * dsh-our-free-model from its pinned tarball — silently reverting the patch.
   * Re-apply it on boot instead of making the user remember.
   * --------------------------------------------------------------------- */
  ctx.effect(() => {
    let cancelled = false
    const run = () => {
      if (cancelled) return
      try {
        const packFile = resolvePackFile({ dshHome, profile })
        const inspected = inspectPack(packFile)
        if (!inspected.ok) {
          logger.debug?.(`workbuddy-meter: patch self-heal skipped (${inspected.reason})`)
          return
        }
        if (inspected.patched) return
        if (inspected.anchors !== 1) {
          logger.warn?.(
            `workbuddy-meter: OFM 补丁自愈中止 —— 锚点命中 ${inspected.anchors} 次（期望 1）。OFM 结构可能已变，请手动检查。`,
          )
          return
        }
        const result = applyPatch({ packFile })
        if (result.applied) {
          writePatchState(dataDir, {
            v: 1,
            patched: true,
            ofmVersion: readOfmVersion(resolveOfmDir({ dshHome, profile })),
            packPath: packFile,
            patchedAt: Date.now(),
            patchedAtIso: new Date().toISOString(),
            anchorLine: result.anchorLine ?? null,
            backupPath: result.backupPath ?? null,
            sha256Before: result.sha256Before ?? null,
            sha256After: result.sha256After ?? null,
            selfHealed: true,
          })
          logger.info?.('workbuddy-meter: OFM 补丁已自动重打（pnpm 重装过 OFM），重启 DSH 后生效。')
        } else if (result.reason !== 'already-patched') {
          logger.warn?.(`workbuddy-meter: OFM 补丁自愈失败 —— ${result.reason}`)
        }
      } catch (error) {
        logger.debug?.(
          `workbuddy-meter: patch self-heal threw (${error instanceof Error ? error.message : String(error)})`,
        )
      }
    }
    // Defer past plugin activation so a slow disk never delays the UI.
    const timer = setTimeout(run, 1500)
    if (typeof timer.unref === 'function') timer.unref()
    return () => {
      cancelled = true
      clearTimeout(timer)
    }
  }, 'workbuddy-meter: patch self-heal')

  /* --- lexicon self-heal ------------------------------------------------ *
   * Same pnpm problem: reinstalling OFM drops the one-line hook. Re-add it on
   * boot so the switch keeps working across upgrades. The switch itself lives
   * in lexicon.json, so re-patching never changes the user's on/off choice.
   * ------------------------------------------------------------------- */
  ctx.effect(() => {
    let cancelled = false
    const run = () => {
      if (cancelled) return
      try {
        const packFile = resolvePackFile({ dshHome, profile })
        const inspected = inspectLexicon(packFile)
        if (!inspected.ok) {
          logger.debug?.(`workbuddy-meter: lexicon self-heal skipped (${inspected.reason})`)
          return
        }
        if (inspected.patched) return
        const result = applyLexiconPatch({ packFile })
        if (result.applied) {
          logger.info?.('workbuddy-meter: 关键词中和钩子已自动重打（pnpm 重装过 OFM），重启 DSH 后生效。')
        } else if (result.reason !== 'already-patched') {
          logger.warn?.(`workbuddy-meter: 关键词中和钩子自愈失败 —— ${result.reason}`)
        }
      } catch (error) {
        logger.debug?.(
          `workbuddy-meter: lexicon self-heal threw (${error instanceof Error ? error.message : String(error)})`,
        )
      }
    }
    const timer = setTimeout(run, 1800)
    if (typeof timer.unref === 'function') timer.unref()
    return () => {
      cancelled = true
      clearTimeout(timer)
    }
  }, 'workbuddy-meter: lexicon self-heal')

  /* --- balance (60s memory cache, `force` bypasses) --------------------- */

  let balanceCache = { at: 0, value: null }
  let balanceInFlight = null

  async function collectBalance({ force = false } = {}) {
    const now = Date.now()
    if (!force && balanceCache.value !== null && now - balanceCache.at < BALANCE_CACHE_MS) {
      return balanceCache.value
    }
    if (balanceInFlight !== null) return balanceInFlight

    const run = (async () => {
      const credentials = getCredentialsService()
      const accounts = readTrackedAccounts(dshHome)
      if (accounts.length === 0) {
        return { at: now, accounts: [], note: 'channel-pack state.json 中没有 buddy/workbuddy 账号' }
      }
      if (credentials === undefined || typeof credentials.resolve !== 'function') {
        return {
          at: now,
          accounts: accounts.map((account) => ({
            ...account,
            status: 'error',
            total: null,
            expiredTotal: null,
            packages: [],
            error: '凭据服务不可用',
          })),
          note: 'credentials 服务不可用',
        }
      }

      const results = []
      for (const account of accounts) {
        const base = {
          accountId: account.accountId,
          provider: account.provider,
          nickname: account.nickname,
          enabled: account.enabled,
        }
        let resolved
        try {
          resolved = await credentials.resolve(account.credentialRef)
        } catch (error) {
          results.push({
            ...base,
            status: 'error',
            total: null,
            expiredTotal: null,
            packages: [],
            error: `凭据读取失败：${error instanceof Error ? error.message : String(error)}`,
          })
          continue
        }
        if (resolved === undefined || resolved === null || typeof resolved.value !== 'string') {
          results.push({ ...base, status: 'error', total: null, expiredTotal: null, packages: [], error: '凭据未配置' })
          continue
        }
        let credential
        try {
          credential = JSON.parse(resolved.value)
        } catch {
          results.push({ ...base, status: 'error', total: null, expiredTotal: null, packages: [], error: '凭据不是合法 JSON' })
          continue
        }
        const balance = await fetchCreditBalance({ account, credential, now })
        if (balance.error !== undefined) {
          results.push({ ...base, status: 'error', total: null, expiredTotal: null, packages: [], error: balance.error })
        } else {
          const hasActive = balance.packages.some((pkg) => pkg.active)
          results.push({
            ...base,
            status: hasActive ? 'active' : 'expired',
            total: balance.total,
            expiredTotal: balance.expiredTotal,
            packages: balance.packages,
          })
        }
      }

      const value = { v: SCHEMA_VERSION, at: Date.now(), accounts: results }
      if (results.some((entry) => entry.error === undefined)) {
        try {
          writeJsonFile(balanceFile, value)
        } catch (error) {
          logger.debug?.(`workbuddy-meter: balance.json write failed (${error instanceof Error ? error.message : String(error)})`)
        }
      }
      balanceCache = { at: value.at, value }
      return value
    })()

    balanceInFlight = run
    try {
      return await run
    } finally {
      balanceInFlight = null
    }
  }

  /* --- routes (CONTRACT §5) -------------------------------------------- */

  /**
   * Call one channel-pack management method from the host half.
   *
   * The channel-pack plugin exposes its admin surface over the shared
   * `connection.fetch` registry rather than as an importable service, so we
   * reach it the same way its own UI does: an in-process fetch to
   * /api/channel-pack carrying the two-level envelopes.
   *
   * Returns undefined when the plugin is absent (not installed / not mounted),
   * which the routes turn into an honest "unavailable" rather than a crash.
   */
  /**
   * Mint the browser-session cookie the host accepts.
   *
   * The host authenticates its own HTTP surface with
   *   cookie dsh-auth-<b64url(sha256(authority))> = v1.<body>.<sig>
   * where body = b64url(JSON{version,authority,issuedAt,expiresAt}) and
   * sig = b64url(HMAC-SHA256(secret, body)). The secret is stored base64url
   * encoded under client-connection/browser-session in .credentials.yaml and
   * must be decoded before use — HMAC over the encoded text fails silently.
   *
   * Returns undefined when the port or the secret cannot be determined, so the
   * caller can degrade instead of throwing.
   */
  function browserAuthFor(authority) {
    const secret = readBrowserSecret()
    if (secret === undefined) return undefined
    const now = Date.now()
    const body = b64url(
      JSON.stringify({ version: 1, authority, issuedAt: now, expiresAt: now + 600_000 })
    )
    const sig = b64url(crypto.createHmac('sha256', secret).update(body).digest())
    const name = 'dsh-auth-' + b64url(crypto.createHash('sha256').update(authority).digest())
    return { authority, cookie: name + '=v1.' + body + '.' + sig }
  }

  function b64url(input) {
    const buf = Buffer.isBuffer(input) ? input : Buffer.from(input)
    return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
  }

  /** Web port: env override first, then the host's stored setting. */
  /**
   * Resolve the host's web port.
   *
   * The port is NOT stable: the desktop app picks one at startup and it has
   * already moved once (14677 → 5528) in this machine's history. A hardcoded
   * fallback silently 401s every management call, so resolution tries the
   * authoritative signals in order and only then guesses.
   *
   *   1. config.webPort           explicit override for this plugin
   *   2. DSH_WEB_PORT             set by some launch modes
   *   3. DSH_WEB_URL              full URL, parsed — present in agent shells
   *   4. probe a small candidate set (last resort, validated by a live call)
   */
  function readWebPortCandidates() {
    const out = []
    const push = (value) => {
      const n = Number.parseInt(String(value ?? ''), 10)
      if (Number.isFinite(n) && n > 0 && n < 65536 && !out.includes(n)) out.push(n)
    }
    // 1. Explicit override.
    push(config?.webPort)
    // 2. Env vars when the host happens to export them.
    push(process.env.DSH_WEB_PORT)
    const rawUrl = String(process.env.DSH_WEB_URL ?? '')
    const m = /:(\d{2,5})(?:\/|$)/.exec(rawUrl)
    if (m !== null) push(m[1])
    // 3. The authoritative source: ports this very process is listening on.
    //    The host binds its web server in-process, so its own socket table is
    //    the only signal that survives restarts (the port has moved
    //    14677 -> 5528 -> 7534 on this machine). Env vars are NOT exported to
    //    plugin code, so this is what actually works.
    for (const port of listeningPortsOfSelf()) push(port)
    return out
  }

  /**
   * Ports the current process listens on, via the OS socket table.
   *
   * Uses the platform's own tool (`netstat -ano` on Windows, `ss`/`lsof`
   * elsewhere) because Node has no portable API for this. Returns [] on any
   * failure — the caller then simply has no candidates and degrades cleanly.
   */
  function listeningPortsOfSelf() {
    const pid = process.pid
    try {
      const { execFileSync } = require('node:child_process')
      if (process.platform === 'win32') {
        const out = execFileSync('netstat', ['-ano', '-p', 'tcp'], { encoding: 'utf8', timeout: 5000, windowsHide: true })
        const ports = []
        for (const line of out.split(/\r?\n/)) {
          const m = /^\s*TCP\s+\S+:(\d+)\s+\S+\s+LISTENING\s+(\d+)\s*$/.exec(line)
          if (m === null) continue
          if (Number(m[2]) !== pid) continue
          const port = Number(m[1])
          // Skip the plugin's own helper ports; the web server is the one that
          // answers an authenticated RPC.
          if (port > 1024 && !ports.includes(port)) ports.push(port)
        }
        return ports
      }
      const out = execFileSync('ss', ['-ltnp'], { encoding: 'utf8', timeout: 5000 })
      const ports = []
      for (const line of out.split(/\r?\n/)) {
        if (!line.includes('pid=' + pid + ',')) continue
        const m = /:(\d+)\s/.exec(line)
        if (m === null) continue
        const port = Number(m[1])
        if (port > 1024 && !ports.includes(port)) ports.push(port)
      }
      return ports
    } catch {
      return []
    }
  }

  /** First candidate port that answers a cheap authenticated call. */
  async function resolveWebPort() {
    if (resolvedWebPort !== undefined) return resolvedWebPort
    for (const port of readWebPortCandidates()) {
      const authority = '127.0.0.1:' + port
      const auth = browserAuthFor(authority)
      if (auth === undefined) continue
      try {
        const response = await fetch('http://' + authority + '/api/channel-pack', {
          method: 'POST',
          headers: { 'content-type': 'application/json', cookie: auth.cookie },
          body: JSON.stringify({
            type: 'client-request',
            rpcId: 'wbm-probe',
            method: 'channel-pack',
            payload: { method: 'account.list', payload: { provider: 'buddy' } },
          }),
          signal: AbortSignal.timeout(3_000),
        })
        if (!response.ok) continue
        const parsed = await response.json()
        // A well-formed reply proves we reached the host AND the plugin.
        if (parsed && typeof parsed === 'object' && 'result' in parsed) {
          resolvedWebPort = port
          return port
        }
      } catch {
        // try next candidate
      }
    }
    return undefined
  }

  /** Decoded secret for the browser-session grant, or undefined. */
  function readBrowserSecret() {
    try {
      const raw = fs.readFileSync(path.join(dshHome, '.credentials.yaml'), 'utf8')
      // Minimal scan: the block is a plain 4-space indented mapping; a full YAML
      // parser is not worth a dependency for one fixed field.
      const marker = 'client-connection/browser-session:'
      const at = raw.indexOf(marker)
      if (at < 0) return undefined
      const tail = raw.slice(at + marker.length)
      const match = /secret:\s*([A-Za-z0-9_\-+/=]+)/.exec(tail)
      if (match === null) return undefined
      const encoded = match[1].trim()
      const normalized = encoded.replace(/-/g, '+').replace(/_/g, '/')
      const padded = normalized + '='.repeat((4 - (normalized.length % 4)) % 4)
      const decoded = Buffer.from(padded, 'base64')
      return decoded.length > 0 ? decoded : undefined
    } catch {
      return undefined
    }
  }

  /** Cached authority once a probe has succeeded; `undefined` = not yet resolved. */
  let resolvedWebPort

  async function channelPackCall(method, payload) {
    // The channel-pack admin surface is only registered on the host's
    // connection.fetch router, so we call it in-process over HTTP with the
    // browser-session cookie the host itself accepts. Reading the secret from
    // ~/.dsh/.credentials.yaml is the documented way to mint that cookie.
    const port = await resolveWebPort()
    if (port === undefined) return undefined
    const auth = browserAuthFor('127.0.0.1:' + port)
    if (auth === undefined) return undefined
    const body = JSON.stringify({
      type: 'client-request',
      rpcId: 'wbm-' + Math.random().toString(36).slice(2, 10),
      method: 'channel-pack',
      // ⚠️ outer method is the literal "channel-pack"; the real method name
      // lives one level down in payload.method (see channel-pack-rpc.ts).
      payload: { method, payload: payload ?? {} },
    })
    try {
      const response = await fetch('http://' + auth.authority + '/api/channel-pack', {
        method: 'POST',
        headers: { 'content-type': 'application/json', cookie: auth.cookie },
        body,
        signal: AbortSignal.timeout(20_000),
      })
      if (!response.ok) return undefined
      const parsed = await response.json()
      return parsed && typeof parsed === 'object' ? parsed.result : undefined
    } catch (error) {
      logger.warn?.('workbuddy-meter: channel-pack RPC failed: ' + (error instanceof Error ? error.message : String(error)))
      return undefined
    }
  }

  const routes = [
    {
      path: '/api/workbuddy-meter/summary',
      label: 'workbuddy-meter: summary route',
      handler: async (request) => {
        try {
          const body = await readBody(request)
          const sinceDays = clampSinceDays(body.sinceDays)
          const now = Date.now()
          // Read twice the window: aggregate filters down to `sinceDays`, while
          // deriveHistory needs the preceding window to compute the delta.
          const records = store.read(sinceDays * 2, now)
          const summary = aggregate(records, { sinceDays, now })
          // Advice is derived, never stored: it has to reflect the same query
          // the rest of the panel just rendered, otherwise the two disagree.
          summary.advice = deriveAdvice({
            totals: summary.totals,
            models: summary.models,
            sinceDays,
          })
          summary.history = deriveHistory(records, sinceDays, now)
          summary.hourly = deriveHourly(records, sinceDays, now)
          return okResponse(summary)
        } catch (error) {
          return errorResponse('meter/summary-failed', error instanceof Error ? error.message : String(error))
        }
      },
    },
    {
      path: '/api/workbuddy-meter/balance',
      label: 'workbuddy-meter: balance route',
      handler: async (request) => {
        try {
          const body = await readBody(request)
          const value = await collectBalance({ force: body.force === true })
          const allFailed = value.accounts.length > 0 && value.accounts.every((entry) => entry.error !== undefined)
          if (allFailed && balanceCache.value === null) {
            const cached = readJsonFile(balanceFile)
            if (cached !== undefined) return okResponse({ ...cached, stale: true })
            return errorResponse('meter/balance-unavailable', value.accounts[0]?.error ?? '余额查询失败')
          }
          return okResponse(value)
        } catch (error) {
          return errorResponse('meter/balance-failed', error instanceof Error ? error.message : String(error))
        }
      },
    },
    {
      path: '/api/workbuddy-meter/patch-status',
      label: 'workbuddy-meter: patch-status route',
      handler: async () => {
        try {
          const base = readPatchStatus({ dshHome, profile, dataDir })
          // Piggyback the lexicon patch state so the panel opens with one call.
          const packFile = base.packPath ?? resolvePackFile({ dshHome, profile })
          const lexiconPack = inspectLexicon(packFile)
          return okResponse({
            ...base,
            lexicon: {
              patchPresent: lexiconPack.ok ? lexiconPack.patched : false,
              patchError: lexiconPack.ok ? undefined : lexiconPack.reason,
              config: readLexiconConfig(),
              stats: { ...lexiconStats },
              hookInstalled: globalThis.__wbLexicon !== undefined,
            },
          })
        } catch (error) {
          return errorResponse('meter/patch-status-failed', error instanceof Error ? error.message : String(error))
        }
      },
    },
    {
      path: '/api/workbuddy-meter/lexicon',
      label: 'workbuddy-meter: lexicon route',
      handler: async (request) => {
        try {
          const body = await readBody(request)
          const action = typeof body.action === 'string' ? body.action : 'get'

          if (action === 'get') {
            const packFile = resolvePackFile({ dshHome, profile })
            const pack = inspectLexicon(packFile)
            return okResponse({
              config: readLexiconConfig(),
              stats: { ...lexiconStats },
              packPath: packFile,
              patchPresent: pack.ok ? pack.patched : false,
              patchError: pack.ok ? null : pack.reason,
              hookInstalled: globalThis.__wbLexicon !== undefined,
            })
          }

          if (action === 'set') {
            // Accept a partial patch so the UI can flip one switch at a time.
            const current = readLexiconConfig()
            const next = writeLexiconConfig({ ...current, ...(body.patch ?? {}) })
            // Reset the runtime counters: otherwise "已中和 N 次" keeps growing
            // across a mode change and the panel can't tell which mode did what.
            if (body.resetStats === true) {
              lexiconStats.rewrites = 0
              lexiconStats.hits = 0
              lexiconStats.injected = 0
              lexiconStats.lastAt = null
            }
            return okResponse({ config: next })
          }

          if (action === 'repair-patch') {
            const packFile = resolvePackFile({ dshHome, profile })
            const result = applyLexiconPatch({ packFile })
            const pack = inspectLexicon(packFile)
            return okResponse({
              applied: result.applied,
              reason: result.reason ?? null,
              patchPresent: pack.ok ? pack.patched : false,
              patchError: pack.ok ? null : pack.reason,
            })
          }

          if (action === 'remove-patch') {
            const packFile = resolvePackFile({ dshHome, profile })
            const result = revertLexiconPatch({ packFile })
            return okResponse({ reverted: result.reverted, reason: result.reason ?? null })
          }

          if (action === 'dry-run') {
            // 用当前配置对一段样例文本试跑，让面板能预览改写效果。
            const config = normalizeLexiconConfig({ ...readLexiconConfig(), ...(body.patch ?? {}) })
            const sample =
              typeof body.sample === 'string' && body.sample.length > 0
                ? body.sample
                : 'You are an AI agent powered by DeepSeek Harness.\nCheckout: D:\\10_COD\\DeepSeek Harness\\resources'
            const messages = [{ role: 'system', content: sample }]
            const result = rewriteMessages(messages, config)
            return okResponse({
              before: sample,
              after: messages[0].content,
              hits: result.hits,
              injected: result.injected,
            })
          }

          return errorResponse('meter/lexicon-bad-action', `未知 action：${action}`)
        } catch (error) {
          return errorResponse('meter/lexicon-failed', error instanceof Error ? error.message : String(error))
        }
      },
    },
    {
      path: '/api/workbuddy-meter/reset',
      label: 'workbuddy-meter: reset route',
      handler: async (request) => {
        try {
          const body = await readBody(request)
          // Dry-run by default, matching this workspace's convention for
          // anything destructive. `apply: true` is required to move the baseline.
          const now = Date.now()
          const before = store.read(90, now)
          const localCount = before.filter((r) => r?.origin !== 'server').length
          const serverCount = before.filter((r) => r?.origin === 'server').length
          const localCredit = before
            .filter((r) => r?.origin !== 'server' && r.creditReported === true && typeof r.credit === 'number')
            .reduce((sum, r) => sum + r.credit, 0)

          if (body.apply !== true) {
            return okResponse({
              applied: false,
              wouldHide: { local: localCount, server: serverCount },
              localCredit: roundTo(localCredit, 4),
              note: '这是 dry-run。传 {apply:true} 才会真正重置（文件保留，只移动统计基线）。',
            })
          }

          writeBaseline(dataDir, now)
          logger.info?.(
            `workbuddy-meter: 统计基线已重置到 ${new Date(now).toISOString()}，此前 ${localCount + serverCount} 条记录不再计入。`,
          )
          return okResponse({
            applied: true,
            baselineTs: now,
            baselineIso: new Date(now).toISOString(),
            hidden: { local: localCount, server: serverCount },
            localCredit: roundTo(localCredit, 4),
            note: '旧记录文件仍在磁盘上（可审计/回滚），只是不计入统计。',
          })
        } catch (error) {
          return errorResponse('meter/reset-failed', error instanceof Error ? error.message : String(error))
        }
      },
    },
    {
      path: '/api/workbuddy-meter/limits',
      label: 'workbuddy-meter: rate limit route',
      handler: async (request) => {
        try {
          const body = await readBody(request)
          const provider = typeof body.provider === 'string' && body.provider.length > 0 ? body.provider : 'buddy'
          const listed = await channelPackCall('account.list', { provider })
          if (listed === undefined) {
            return errorResponse('meter/limits-unavailable', 'channel-pack RPC 不可用')
          }
          if (listed.ok !== true) {
            return errorResponse('meter/limits-failed', JSON.stringify(listed.error ?? {}))
          }
          const accounts = Array.isArray(listed.value?.accounts) ? listed.value.accounts : []
          const now = Date.now()
          return okResponse({
            provider,
            now,
            accounts: accounts.map((entry) => {
              const raw = entry && typeof entry.modelRateLimits === 'object' && entry.modelRateLimits !== null
                ? entry.modelRateLimits
                : {}
              const limits = []
              for (const modelId of Object.keys(raw)) {
                const at = Number(raw[modelId])
                if (!Number.isFinite(at)) continue
                // channel-pack uses 0/absent for "no limit"; anything in the
                // future is an active cooldown, anything in the past is spent.
                if (at <= 0) continue
                limits.push({
                  modelId,
                  resetAt: at,
                  remainingMs: Math.max(0, at - now),
                  active: at > now,
                })
              }
              return {
                id: String(entry.id ?? ''),
                nickname: typeof entry.nickname === 'string' ? entry.nickname : '',
                enabled: entry.enabled === true,
                limits,
              }
            }),
          })
        } catch (error) {
          return errorResponse('meter/limits-failed', error instanceof Error ? error.message : String(error))
        }
      },
    },
    {
      path: '/api/workbuddy-meter/test',
      label: 'workbuddy-meter: live model test route',
      handler: async (request) => {
        try {
          const body = await readBody(request)
          const provider = typeof body.provider === 'string' && body.provider.length > 0 ? body.provider : 'buddy'
          const modelId = typeof body.modelId === 'string' && body.modelId.length > 0
            ? body.modelId
            : 'deepseek-v4.1-flash'

          // Resolve which account to test: an explicit id, or the one account
          // that is currently enabled (that is "the current account").
          let accountId = typeof body.accountId === 'string' && body.accountId.length > 0 ? body.accountId : ''
          if (accountId === '') {
            const listed = await channelPackCall('account.list', { provider })
            if (listed === undefined) {
              return errorResponse('meter/test-unavailable', 'channel-pack RPC 不可用')
            }
            const accounts = Array.isArray(listed.value?.accounts) ? listed.value.accounts : []
            const enabled = accounts.filter((a) => a && a.enabled === true)
            if (enabled.length !== 1) {
              return errorResponse(
                'meter/test-ambiguous',
                enabled.length === 0 ? '当前没有启用中的账号' : '同时启用了多个账号，请先只保留一个',
              )
            }
            accountId = String(enabled[0].id ?? '')
          }

          const startedAt = Date.now()
          const result = await channelPackCall('account.test', { accountId, modelId })
          const elapsedMs = Date.now() - startedAt
          if (result === undefined) {
            return errorResponse('meter/test-unavailable', 'channel-pack RPC 不可用')
          }
          if (result.ok !== true) {
            return errorResponse('meter/test-failed', JSON.stringify(result.error ?? {}))
          }
          const value = result.value ?? {}
          return okResponse({
            accountId,
            modelId: typeof value.modelId === 'string' ? value.modelId : modelId,
            nickname: typeof value.nickname === 'string' ? value.nickname : '',
            ok: value.ok === true,
            message: typeof value.message === 'string' ? value.message : '',
            // Authoritative cooldown the upstream told us about, if any.
            resetAt: Number.isFinite(value.resetTimeMs) ? value.resetTimeMs : null,
            remainingMs: Number.isFinite(value.resetTimeMs) ? Math.max(0, value.resetTimeMs - Date.now()) : null,
            elapsedMs,
            testedAt: startedAt,
          })
        } catch (error) {
          return errorResponse('meter/test-failed', error instanceof Error ? error.message : String(error))
        }
      },
    },
    {
      path: '/api/workbuddy-meter/accounts/rename',
      label: 'workbuddy-meter: rename account route',
      handler: async (request) => {
        try {
          const body = await readBody(request)
          const accountId = typeof body.accountId === 'string' ? body.accountId.trim() : ''
          if (accountId.length === 0) {
            return errorResponse('meter/rename-bad-id', '缺少 accountId')
          }

          // Empty nickname means "clear the custom name" — channel-pack then
          // falls back to the id on its own.
          const raw = typeof body.nickname === 'string' ? body.nickname : ''
          const nickname = raw.trim()
          if (nickname.length > 40) {
            return errorResponse('meter/rename-too-long', '昵称最长 40 个字符')
          }
          // Control characters would corrupt the panel and the pack's own logs.
          if (/[\u0000-\u001F\u007F]/.test(nickname)) {
            return errorResponse('meter/rename-bad-chars', '昵称不能包含控制字符')
          }

          // Read back first so a typo'd accountId fails loudly instead of
          // silently writing a new phantom entry. `account.list` filters by
          // provider and returns nothing for an empty one, so look the account
          // up across the providers this plugin tracks.
          let existing
          let listedAny = false
          for (const provider of TRACKED_PROVIDERS) {
            const listed = await channelPackCall('account.list', { provider })
            if (listed === undefined) continue
            listedAny = true
            const all = Array.isArray(listed.value?.accounts) ? listed.value.accounts : []
            const hit = all.find((entry) => entry && entry.id === accountId)
            if (hit !== undefined) {
              existing = hit
              break
            }
          }
          if (!listedAny) {
            return errorResponse('meter/rename-unavailable', 'channel-pack RPC 不可用')
          }
          if (existing === undefined) {
            return errorResponse('meter/rename-not-found', `找不到账号 ${accountId}`)
          }
          const previous = typeof existing.nickname === 'string' ? existing.nickname : ''

          // account.update merges the patch into the pool's in-memory cache AND
          // persists it to state.json. Writing state.json directly would be
          // invisible until DSH restarts, because the pool caches on first read.
          const result = await channelPackCall('account.update', {
            accountId,
            patch: { nickname },
          })
          if (result === undefined) {
            return errorResponse('meter/rename-unavailable', 'channel-pack RPC 不可用')
          }
          if (result.ok !== true) {
            return errorResponse('meter/rename-rejected', JSON.stringify(result.error ?? {}))
          }

          // Verify the write actually landed: a stale pool or a rejected patch
          // would otherwise report success while the panel still shows the old
          // name.
          let current = ''
          for (const provider of TRACKED_PROVIDERS) {
            const after = await channelPackCall('account.list', { provider })
            if (after === undefined) continue
            const afterAll = Array.isArray(after.value?.accounts) ? after.value.accounts : []
            const updated = afterAll.find((entry) => entry && entry.id === accountId)
            if (updated !== undefined) {
              current = typeof updated.nickname === 'string' ? updated.nickname : ''
              break
            }
          }
          return okResponse({
            accountId,
            previous,
            nickname: current,
            applied: current === nickname,
          })
        } catch (error) {
          return errorResponse('meter/rename-failed', error instanceof Error ? error.message : String(error))
        }
      },
    },
    {
      path: '/api/workbuddy-meter/accounts',
      label: 'workbuddy-meter: account pool route',
      handler: async (request) => {
        try {
          const body = await readBody(request)
          const provider = typeof body.provider === 'string' && body.provider.length > 0 ? body.provider : 'buddy'
          const listed = await channelPackCall('account.list', { provider })
          if (listed === undefined) {
            return errorResponse('meter/accounts-unavailable', 'channel-pack RPC 不可用')
          }
          if (listed.ok !== true) {
            return errorResponse('meter/accounts-failed', JSON.stringify(listed.error ?? {}))
          }
          const accounts = Array.isArray(listed.value?.accounts) ? listed.value.accounts : []
          // Balances come from the same management API so the switcher and the
          // panel never disagree about how much an account has left.
          const balances = await channelPackCall('credits.balances', { provider })
          const balanceById = new Map()
          const rows = Array.isArray(balances?.value?.accounts) ? balances.value.accounts : []
          for (const row of rows) {
            if (row && typeof row.accountId === 'string') balanceById.set(row.accountId, row.balance)
          }
          return okResponse({
            provider,
            accounts: accounts.map((entry) => {
              const balance = balanceById.get(entry.id)
              return {
                id: String(entry.id ?? ''),
                nickname: typeof entry.nickname === 'string' ? entry.nickname : '',
                // Strict: channel-pack may omit the field; only an explicit
                // true means this account is allowed to serve traffic.
                enabled: entry.enabled === true,
                refreshable: entry.refreshable !== false,
                // Remaining credits, when the provider exposes them.
                remaining:
                  balance && typeof balance.total === 'number' && Number.isFinite(balance.total)
                    ? balance.total
                    : null,
                packages: balance && Array.isArray(balance.packages)
                  ? balance.packages
                      .filter((p) => p && p.active === true)
                      .map((p) => ({
                        name: typeof p.name === 'string' ? p.name : '',
                        remaining: toFiniteNumber(p.remaining),
                        total: toFiniteNumber(p.total),
                        used: toFiniteNumber(p.used),
                      }))
                  : [],
              }
            }),
          })
        } catch (error) {
          return errorResponse('meter/accounts-failed', error instanceof Error ? error.message : String(error))
        }
      },
    },
    {
      path: '/api/workbuddy-meter/accounts/switch',
      label: 'workbuddy-meter: account switch route',
      handler: async (request) => {
        try {
          const body = await readBody(request)
          const provider = typeof body.provider === 'string' && body.provider.length > 0 ? body.provider : 'buddy'
          // Two modes:
          //   { accountId, enabled }        → toggle one account
          //   { only: 'buddy-xxx' }         → keep exactly that one enabled
          // The "only" form is what the plan-driven rotation needs: a single
          // call, no way to end up with zero enabled accounts by accident.
          if (typeof body.only === 'string' && body.only.length > 0) {
            const listed = await channelPackCall('account.list', { provider })
            if (listed === undefined || listed.ok !== true) {
              return errorResponse('meter/switch-failed', '无法读取账号池')
            }
            const all = Array.isArray(listed.value?.accounts) ? listed.value.accounts : []
            if (!all.some((a) => a.id === body.only)) {
              return errorResponse('meter/switch-failed', '账号 ' + body.only + ' 不存在')
            }
            const changed = []
            for (const entry of all) {
              const want = entry.id === body.only
              if ((entry.enabled !== false) === want) continue
              const res = await channelPackCall('account.update', {
                accountId: entry.id,
                patch: { enabled: want },
              })
              if (res === undefined || res.ok !== true) {
                return errorResponse('meter/switch-failed', '切换 ' + entry.id + ' 失败：' + JSON.stringify(res?.error ?? {}))
              }
              changed.push({ id: entry.id, enabled: want })
            }
            return okResponse({ applied: true, only: body.only, changed })
          }

          if (typeof body.accountId !== 'string' || body.accountId.length === 0) {
            return errorResponse('meter/switch-failed', 'accountId 或 only 必填')
          }
          const enabled = body.enabled !== false
          const res = await channelPackCall('account.update', {
            accountId: body.accountId,
            patch: { enabled },
          })
          if (res === undefined) return errorResponse('meter/switch-failed', 'channel-pack RPC 不可用')
          if (res.ok !== true) {
            return errorResponse('meter/switch-failed', JSON.stringify(res.error ?? {}))
          }
          return okResponse({ applied: true, accountId: body.accountId, enabled })
        } catch (error) {
          return errorResponse('meter/switch-failed', error instanceof Error ? error.message : String(error))
        }
      },
    },
    {
      path: '/api/workbuddy-meter/export',
      label: 'workbuddy-meter: export route',
      handler: async (request) => {
        try {
          const body = await readBody(request)
          const sinceDays = clampSinceDays(body.sinceDays)
          const format = body.format === 'json' ? 'json' : 'csv'
          const now = Date.now()
          const records = store.read(sinceDays, now)
          const stamp = utc8Day(now)
          if (format === 'json') {
            return okResponse({
              filename: `workbuddy-meter-usage-${stamp}-${sinceDays}d.json`,
              content: JSON.stringify({ generatedAt: now, sinceDays, records }, null, 2),
              count: records.length,
            })
          }
          return okResponse({
            filename: `workbuddy-meter-usage-${stamp}-${sinceDays}d.csv`,
            content: toCsv(records),
            count: records.length,
          })
        } catch (error) {
          return errorResponse('meter/export-failed', error instanceof Error ? error.message : String(error))
        }
      },
    },
  ]

  ctx.inject(['connection'], (scope) => {
    const connection = serviceOf(scope, 'connection')
    const register =
      typeof connection?.fetch?.register === 'function' ? connection.fetch.register.bind(connection.fetch) : undefined
    if (register === undefined) {
      logger.warn?.('workbuddy-meter: connection service has no fetch.register; routes not mounted')
      return
    }
    for (const route of routes) {
      scope.effect(
        () => register({ path: route.path, methods: ['POST'], requestBody: 'buffered', fetch: route.handler }),
        route.label,
      )
    }
  })

  logger.debug?.(`workbuddy-meter: host half ready (data=${dataDir}, profile=${profile})`)
}

/* ------------------------------------------------------------------ *
 * Hourly profile — when during the day does the money go out.
 * ------------------------------------------------------------------ */

/**
 * Bucket records into 24 local hours (UTC+8), for the current day and as a
 * multi-day average, so a single unusual hour does not look like a trend.
 */
function deriveHourly(records, sinceDays, now) {
  const hours = []
  for (let h = 0; h < 24; h += 1) {
    hours.push({ hour: h, credit: 0, requests: 0, totalTokens: 0, daysSeen: 0 })
  }
  // dayKey -> Set(hour) so "daysSeen" counts distinct days, not requests.
  const seen = new Map()
  const todayKey = utc8Day(now)
  const today = []
  for (let h = 0; h < 24; h += 1) today.push({ hour: h, credit: 0, requests: 0, totalTokens: 0 })

  for (const record of records) {
    const ts = toFiniteNumber(record.ts)
    if (ts === 0 || ts > now) continue
    const day = utc8Day(ts)
    // UTC+8 hour; getUTCHours on a +8 shifted timestamp is the local hour.
    const hour = new Date(ts + 8 * 60 * 60 * 1000).getUTCHours()
    const credit = record.creditReported === true ? nonNegative(record.credit) : 0

    const bucket = hours[hour]
    bucket.credit += credit
    bucket.requests += 1
    bucket.totalTokens += nonNegative(record.totalTokens)
    if (!seen.has(day)) seen.set(day, new Set())
    seen.get(day).add(hour)

    if (day === todayKey) {
      const t = today[hour]
      t.credit += credit
      t.requests += 1
      t.totalTokens += nonNegative(record.totalTokens)
    }
  }

  // daysSeen per hour = how many distinct days contributed, used to decide
  // whether the average is trustworthy.
  for (const [day, hourSet] of seen) {
    for (const h of hourSet) hours[h].daysSeen += 1
  }

  const round = (rows) =>
    rows.map((r) => ({
      hour: r.hour,
      credit: roundTo(r.credit, 6),
      requests: r.requests,
      totalTokens: r.totalTokens,
      ...('daysSeen' in r ? { daysSeen: r.daysSeen } : {}),
    }))

  const totalGiven = hours.reduce((sum, h) => sum + h.credit, 0)
  const maxHourCredit = hours.reduce((max, h) => Math.max(max, h.credit), 0)
  // The hottest hour is the actionable finding: "most of your spend happens here".
  let peakHour = null
  for (const h of hours) {
    if (maxHourCredit > 0 && h.credit === maxHourCredit) { peakHour = h.hour; break }
  }

  return {
    sinceDays,
    hours: round(hours),
    today: round(today),
    todayDay: todayKey,
    maxHourCredit: roundTo(maxHourCredit, 6),
    peakHour,
    peakShare: totalGiven > 0 && peakHour !== null ? roundTo(maxHourCredit / totalGiven, 4) : null,
  }
}

/* ------------------------------------------------------------------ *
 * History — period-over-period comparison and burn projection.
 * ------------------------------------------------------------------ */

const DAY_MS_LOCAL = 24 * 60 * 60 * 1000

/**
 * Compare the current window with the immediately preceding window of the
 * same length. A shorter/longer baseline would make the percentage meaningless.
 *
 * @param {Array} records  everything the store can read (already day-bucketed)
 * @param {number} sinceDays
 * @param {number} now
 */
function deriveHistory(records, sinceDays, now) {
  const spanMs = sinceDays * DAY_MS_LOCAL
  const currentStart = now - spanMs
  const previousStart = now - spanMs * 2

  const current = newBucket()
  const previous = newBucket()
  for (const record of records) {
    const ts = toFiniteNumber(record.ts)
    if (ts === 0) continue
    if (ts > now) continue
    if (ts >= currentStart) accumulate(current, record)
    else if (ts >= previousStart) accumulate(previous, record)
  }

  const delta = (cur, prev) => {
    // A percentage against a zero baseline is not "infinite growth", it is
    // undefined. Return null so the UI can say "no baseline" instead of +∞%.
    if (!(prev > 0)) return null
    return roundTo((cur - prev) / prev, 4)
  }

  // Projection: only meaningful with a decent amount of elapsed time and
  // traffic, otherwise one early request would extrapolate to a wild number.
  const elapsedMs = Math.max(0, now - currentStart)
  const elapsedFraction = Math.min(1, elapsedMs / spanMs)
  const projected =
    current.credit > 0 && elapsedFraction > 0.05
      ? roundTo(current.credit / elapsedFraction, 2)
      : null

  return {
    sinceDays,
    current: {
      credit: roundTo(current.credit, 6),
      requests: current.requests,
      totalTokens: current.totalTokens,
    },
    previous: {
      credit: roundTo(previous.credit, 6),
      requests: previous.requests,
      totalTokens: previous.totalTokens,
    },
    delta: {
      credit: delta(current.credit, previous.credit),
      requests: delta(current.requests, previous.requests),
      totalTokens: delta(current.totalTokens, previous.totalTokens),
    },
    // Share of the window that has actually elapsed — the UI shows this next to
    // the projection so the user can judge how much to trust it.
    elapsedFraction: roundTo(elapsedFraction, 4),
    projectedCredit: projected,
  }
}

/* ------------------------------------------------------------------ *
 * Advice — turn the numbers into "what should I change".
 * ------------------------------------------------------------------ */

/** Thresholds are part of the contract; the UI renders them verbatim. */
const ADVICE = {
  // A working session on this machine sits around 98%; dropping below 90%
  // means the prefix cache is being broken repeatedly (context edits, new
  // sessions, model switches), which multiplies the bill.
  cacheHitFloor: 0.9,
  // Above this, a single request costs more than a fresh small one.
  largeContextTokens: 500_000,
  // A model needs this much traffic before its measured unit price is stable
  // enough to recommend switching (upstream rounds credit to 0.01).
  minModelTokens: 5_000_000,
}

/**
 * @param {object} params
 * @param {object} params.totals   aggregate totals bucket (presentBucket shape)
 * @param {Array}  params.models   [{ provider, model, requests, totalTokens, credit, derived }]
 * @param {object} params.params   { sinceDays }
 */
function deriveAdvice({ totals, models, sinceDays }) {
  const items = []
  const derived = totals && totals.derived ? totals.derived : {}
  const totalCredit = Number(totals?.credit) || 0

  // ── 1. Cache hit rate ──────────────────────────────────────────────
  const hitRate = isFinite(derived.cacheHitRate) ? derived.cacheHitRate : null
  const coldPrice = isFinite(derived.coldUnitPrice) ? derived.coldUnitPrice : null
  const hotPrice = isFinite(derived.hotUnitPrice) ? derived.hotUnitPrice : null
  if (hitRate !== null && hitRate < ADVICE.cacheHitFloor && coldPrice !== null && hotPrice !== null && hotPrice > 0) {
    // What the same tokens would have cost at the cold rate.
    const tokens = Number(totals.creditTokens) || 0
    const coldCost = (tokens / 1e6) * coldPrice
    items.push({
      id: 'cache',
      severity: 'high',
      impactCredit: Math.max(0, roundTo(coldCost - totalCredit, 2)),
      // Every cold request re-pays for the whole prefix.
      detail: { hitRate, coldPrice, hotPrice, ratio: roundTo(coldPrice / hotPrice, 2), tokens },
    })
  }

  // ── 2. Oversized context ───────────────────────────────────────────
  // Share of credit spent on requests whose prompt alone was huge. Reported as
  // an observation, not a claim that the user should shrink every session.
  const large = Number.isFinite(totals.largeContextCredit) ? totals.largeContextCredit : null
  if (large !== null && totalCredit > 0 && large / totalCredit >= 0.5) {
    items.push({
      id: 'context',
      severity: 'medium',
      impactCredit: null,
      detail: {
        share: roundTo(large / totalCredit, 3),
        credit: roundTo(large, 2),
        requests: Number(totals.largeContextRequests) || 0,
        threshold: ADVICE.largeContextTokens,
        avgPromptTokens: isFinite(derived.avgPromptTokens) ? derived.avgPromptTokens : null,
      },
    })
  }

  // ── 3. Model choice ────────────────────────────────────────────────
  // Rank only models with enough traffic; the cheapest becomes the reference
  // and every other model's overspend is (its tokens) x (price gap).
  const priced = (Array.isArray(models) ? models : [])
    .filter((m) => m && m.derived && isFinite(m.derived.unitPricePerMTok) && m.derived.unitPricePerMTok > 0)
    .filter((m) => (Number(m.totalTokens) || 0) >= ADVICE.minModelTokens)
    .map((m) => ({
      model: String(m.model || ''),
      provider: String(m.provider || ''),
      unitPrice: m.derived.unitPricePerMTok,
      totalTokens: Number(m.totalTokens) || 0,
      credit: Number(m.credit) || 0,
    }))
    .sort((a, b) => a.unitPrice - b.unitPrice)

  if (priced.length >= 2) {
    const cheapest = priced[0]
    let overspend = 0
    const offenders = []
    for (let i = 1; i < priced.length; i += 1) {
      const m = priced[i]
      const wouldCost = (m.totalTokens / 1e6) * cheapest.unitPrice
      const extra = m.credit - wouldCost
      if (extra > 0) {
        overspend += extra
        offenders.push({
          model: m.model,
          provider: m.provider,
          unitPrice: m.unitPrice,
          totalTokens: m.totalTokens,
          credit: roundTo(m.credit, 2),
          extra: roundTo(extra, 2),
          ratio: roundTo(m.unitPrice / cheapest.unitPrice, 2),
        })
      }
    }
    if (overspend > 0) {
      items.push({
        id: 'model',
        severity: overspend >= 50 ? 'high' : 'medium',
        impactCredit: roundTo(overspend, 2),
        detail: {
          cheapest: { model: cheapest.model, provider: cheapest.provider, unitPrice: cheapest.unitPrice },
          offenders,
        },
      })
    }
  }

  const actionable = items.filter((i) => typeof i.impactCredit === 'number' && i.impactCredit > 0)
  const potential = actionable.reduce((sum, i) => sum + i.impactCredit, 0)
  return {
    sinceDays,
    items,
    // Sum of the *independent* estimates is an upper bound, not a promise; the
    // UI must label it as such.
    potentialCredit: roundTo(potential, 2),
    potentialShareOfSpend: totalCredit > 0 ? roundTo(potential / totalCredit, 3) : null,
    thresholds: ADVICE,
  }
}

/* ------------------------------------------------------------------ *
 * Test surface — not part of the plugin contract.
 * ------------------------------------------------------------------ */

export const __internals = {
  SCHEMA_VERSION,
  DATA_DIR_NAME,
  PRODUCTS,
  USER_RESOURCE_PATH,
  utc8Day,
  toRecord,
  createStore,
  aggregate,
  derive,
  parseCreditPackage,
  parseUserResource,
  balanceHeaders,
  fetchCreditBalance,
  readTrackedAccounts,
  readPatchStatus,
  resolveDshHome,
  stripModelPrefix,
  clampSinceDays,
  toCsv,
  RECORD_COLUMNS,
  deriveDrivers,
}

