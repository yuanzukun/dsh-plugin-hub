// Functional smoke test for the host half (run after pnpm build):
//
//   node tests/host.test.mjs
//
// Drives the real apply() against a mock cordis ctx: installs a synthetic
// provider fetch, lets the plugin wrap it, performs an llm/stream-correlated
// call, and asserts session correlation plus the JSON endpoint output.
import assert from "node:assert/strict";
import { ReadableStream } from "node:stream/web";
import { apply } from "../lib/index.js";

// ── mock cordis context ─────────────────────────────────────────────────────
const listeners = new Map();
const effects = [];
const routes = [];
const ctx = {
  on(event, handler) {
    listeners.set(event, handler);
  },
  effect(setup, label) {
    const dispose = setup();
    effects.push({ dispose, label });
    return dispose;
  },
  webServer: {
    register(route) {
      routes.push(route);
      return () => {
        const i = routes.indexOf(route);
        if (i >= 0) routes.splice(i, 1);
      };
    },
  },
};

// ── install the synthetic provider BEFORE apply(), so the plugin wraps it ───
const realFetch = globalThis.fetch;
let providerResponse = null;
const providerFetch = async () => providerResponse;

function sseResponse(lines) {
  const body = new ReadableStream({
    start(controller) {
      controller.enqueue(new TextEncoder().encode(lines.join("\n") + "\n"));
      controller.close();
    },
  });
  return new Response(body, { status: 200, headers: { "content-type": "text/event-stream" } });
}

globalThis.fetch = providerFetch;
apply(ctx, { pathPrefix: "/dsh-fingerprint-show" });

assert.equal(listeners.has("llm/stream"), true, "llm/stream listener registered");
assert.equal(routes.length, 1, "one route registered");
assert.equal(routes[0].path, "/dsh-fingerprint-show");
const route = routes[0];

// ── simulate one in-flight llm/stream call for session s-123 ────────────────
async function* fakeStream() {
  await new Promise((r) => setTimeout(r, 30));
  yield { type: "text-delta", index: 0, text: "hello" };
  yield { type: "finish", reason: { kind: "stop" } };
}
const streamHandler = listeners.get("llm/stream");
const wrapped = streamHandler(
  { provider: "deepseek-official", model: "deepseek-v4-flash", sessionId: "s-123" },
  () => fakeStream(),
);

// ── drive a synthetic provider response through the wrapped fetch ───────────
providerResponse = sseResponse([
  'data: {"id":"chatcmpl-1","model":"deepseek-v4-flash","system_fingerprint":"fp_abc12345","choices":[{"delta":{"content":"he"}}]}',
  "",
  'data: {"id":"chatcmpl-1","model":"deepseek-v4-flash","system_fingerprint":"fp_abc12345","choices":[{"delta":{"content":"llo"}}]}',
  "",
  "data: [DONE]",
  "",
]);
// The adapter consumes its branch; the observer tees its own.
const res = await globalThis.fetch("https://api.deepseek.com/chat/completions", { method: "POST" });
const consumed = await res.text();
assert.equal(consumed.includes("fp_abc12345"), true, "adapter branch untouched");

// Let the observer branch settle, then finish the waterfall generator.
await new Promise((r) => setTimeout(r, 80));
for await (const _ of wrapped) {
  void _;
}

// ── assertions over the HTTP route ──────────────────────────────────────────
function mockReq(pathname, search = "") {
  return { url: pathname + search };
}
function mockRes() {
  return {
    headers: null,
    body: null,
    writeHead(status, headers) {
      this.status = status;
      this.headers = headers;
    },
    end(body) {
      this.body = body;
    },
  };
}

let res2 = mockRes();
route.handler(mockReq("/dsh-fingerprint-show/api/observations", "?sessionId=s-123&limit=10"), res2);
let data = JSON.parse(res2.body);
assert.equal(res2.status, 200);
assert.equal(typeof data.stats.matchedResponses, "number", "diagnostic counters present");
assert.equal(data.observations.length, 1, "observation captured");
const obs = data.observations[0];
assert.equal(obs.fingerprint, "fp_abc12345");
assert.equal(obs.model, "deepseek-v4-flash");
assert.equal(obs.sessionId, "s-123", "correlated to the in-flight waterfall call");
assert.equal(obs.provider, "deepseek-official");

res2 = mockRes();
route.handler(mockReq("/dsh-fingerprint-show/api/observations", "?sessionId=other"), res2);
data = JSON.parse(res2.body);
assert.equal(data.observations.length, 0, "session filter excludes other sessions");

res2 = mockRes();
route.handler(mockReq("/dsh-fingerprint-show/api/nope"), res2);
assert.equal(res2.status, 404, "unknown path 404s");

// ── unattributed fetch records a null-session observation ───────────────────
providerResponse = sseResponse([
  'data: {"model":"m2","system_fingerprint":"fp_other"}',
  "",
  "data: [DONE]",
  "",
]);
await globalThis.fetch("https://api.example.com/v1/chat/completions");
await new Promise((r) => setTimeout(r, 60));
res2 = mockRes();
route.handler(mockReq("/dsh-fingerprint-show/api/observations", "?limit=5"), res2);
data = JSON.parse(res2.body);
assert.equal(data.observations.length, 2, "both observations stored");
assert.equal(data.observations[0].fingerprint, "fp_other");
assert.equal(data.observations[0].sessionId, null);

// ── non-matching URL is passed through unobserved ───────────────────────────
providerResponse = sseResponse(['data: {"system_fingerprint":"fp_skip"}', "", "data: [DONE]", ""]);
await globalThis.fetch("https://api.example.com/v1/embeddings");
await new Promise((r) => setTimeout(r, 60));
res2 = mockRes();
route.handler(mockReq("/dsh-fingerprint-show/api/observations", "?limit=5"), res2);
data = JSON.parse(res2.body);
assert.equal(data.observations.length, 2, "non-matching url not recorded");

// ── effect disposal restores fetch and removes the route ────────────────────
for (const e of effects) e.dispose();
assert.equal(globalThis.fetch, providerFetch, "pre-plugin fetch restored");
assert.equal(routes.length, 0, "route removed");

globalThis.fetch = realFetch;
console.log("host.test.mjs: all assertions passed");
