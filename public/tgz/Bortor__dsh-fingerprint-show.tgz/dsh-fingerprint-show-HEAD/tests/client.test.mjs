// Client-half smoke test (run after pnpm build):
//
//   node tests/client.test.mjs
//
// Fakes the DSH web shell's module loader global, materializes the built
// lib/client.js factory, asserts the assistant-actions slot registration
// flow, and verifies per-message history rendering: each closing message
// shows its own fingerprint as plain text; click-to-copy is wired.
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

// Minimal react stubs for the automatic JSX transform. useState is scripted
// so tests can stage what the "store" returns per render.
let storeValue = [];
const React = {
  createElement: (type, props, ...children) => ({ type, props, children }),
  useState: () => [storeValue, () => {}],
  useEffect: () => {},
};

let pluginExports = null;
globalThis.window = {
  __ModuleLoader__: {
    load({ id, factory }) {
      assert.equal(id, "dsh-fingerprint-show");
      const require = (spec) => {
        if (spec === "react") return React;
        if (spec === "react/jsx-runtime") {
          return {
            jsx: (type, props, key) => ({ type, props, key }),
            jsxs: (type, props, key) => ({ type, props, key }),
            Fragment: Symbol.for("react.fragment"),
          };
        }
        throw new Error("unexpected external require: " + spec);
      };
      pluginExports = factory(require);
    },
  },
};

// Execute the bundle exactly like a classic script would.
const code = readFileSync(new URL("../lib/client.js", import.meta.url), "utf8");
new Function(code)();
assert.ok(pluginExports, "factory registered");

assert.equal(typeof pluginExports.apply, "function", "exports apply");
assert.deepEqual(pluginExports.inject, ["slots"], "exports inject");
assert.equal(typeof pluginExports.matchFingerprints, "function", "exports matcher");

// ── slot registration flow ──────────────────────────────────────────────────
let injectWaitKey = null;
let injectedCallback = null;
let registeredSpec = null;
let registeredComponent = null;
pluginExports.apply({
  effect(setup) {
    return setup();
  },
  slots: {
    inject(key, callback) {
      injectWaitKey = key;
      injectedCallback = callback;
    },
    register(spec, component) {
      registeredSpec = spec;
      registeredComponent = component;
      return () => {};
    },
  },
});
assert.equal(injectWaitKey, "conversation.chat.assistant-actions", "waits for the assistant-actions declaration");
injectedCallback();
assert.equal(registeredSpec.name, "conversation.chat.assistant-actions");
assert.equal(registeredSpec.id, "fingerprint-show");
assert.equal(typeof registeredComponent, "function", "component registered");

// ── matcher: mid-conversation model switch keeps history ────────────────────
const { matchFingerprints } = pluginExports;
const messages = [
  { kind: "assistant", messageId: "m1", time: 1000 },
  { kind: "assistant", messageId: "m2", time: 2000 },
];
const observations = [
  { fingerprint: "fp_new", model: "v4-pro", time: 1900, purpose: null },
  { fingerprint: "fp_old", model: "v4-flash", time: 500, purpose: null },
];
const matched = matchFingerprints(messages, observations);
assert.equal(matched.get("m1")?.fingerprint, "fp_old", "m1 keeps its own deployment");
assert.equal(matched.get("m2")?.fingerprint, "fp_new", "m2 shows the switched deployment");

// ── component render: history on every closing message ──────────────────────
const session = {
  sessionId: "s-1",
  nodes: [
    { kind: "assistant", messageId: "m1", time: 1000, timing: { stepStartTime: 900, firstTokenTime: 950, completedTime: 1200 } },
    { kind: "assistant", messageId: "m2", time: 2000, timing: { stepStartTime: 1900, firstTokenTime: 1950, completedTime: 2200 } },
    // A message WITHOUT timing must not render the fingerprint (orphan guard).
    { kind: "assistant", messageId: "mNoTiming", time: 3000 },
  ],
};
const useSession = (selector) => selector(session);

// Empty store -> hidden.
storeValue = [];
React.useState = () => [[], () => {}];
assert.equal(registeredComponent({ messageId: "m2", sessionId: "s-1", useSession }), null, "hidden without observations");

// Loaded store -> BOTH messages render their own plain-text fingerprint.
React.useState = () => [observations, () => {}];
const tree1 = registeredComponent({ messageId: "m1", sessionId: "s-1", useSession });
assert.ok(tree1, "history message renders");
assert.equal(tree1.type, "span", "plain text element, not a button");
assert.equal(tree1.props.onClick, undefined, "no copy interaction");
const fp1 = tree1.props.children[1];
assert.equal(fp1.props.children, "fp_old", "full fingerprint, no truncation");
assert.equal(tree1.props.style.color, "var(--dsw-alias-label-tertiary)", "matches native tertiary label color");
assert.equal(tree1.props.style.fontFamily, undefined, "no font override");
const tree2 = registeredComponent({ messageId: "m2", sessionId: "s-1", useSession });
assert.ok(tree2, "latest message renders");
assert.equal(tree2.type, "span", "plain text element, not a button");

// A message whose request produced no observation stays untagged.
assert.equal(registeredComponent({ messageId: "mX", sessionId: "s-1", useSession }), null, "unknown message hidden");
// A message with NO metrics row (no timing) stays untagged, even if observed.
assert.equal(registeredComponent({ messageId: "mNoTiming", sessionId: "s-1", useSession }), null, "no-timing message shows no fingerprint");

// Missing session id -> hidden.
assert.equal(registeredComponent({ messageId: "m2", useSession }), null, "hidden without a session id");

console.log("client.test.mjs: all assertions passed");
