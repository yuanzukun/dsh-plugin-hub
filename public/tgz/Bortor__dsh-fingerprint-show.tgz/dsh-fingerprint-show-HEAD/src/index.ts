/**
 * dsh-fingerprint-show — host half.
 *
 * Captures the provider model fingerprint (OpenAI-compatible
 * `system_fingerprint` field, e.g. `fp_xxxxxxxx`) of every streaming LLM
 * call the harness makes, correlates it with the calling session, and serves
 * it to the Web UI over a small same-origin HTTP route.
 *
 * Why a fetch wrapper? The shipped DeepSeek adapter translates provider SSE
 * into the harness StreamChunk protocol and drops response-level metadata on
 * the way, so the fingerprint never reaches the llm/stream waterfall. The
 * only seam that still sees the raw wire format is the HTTP fetch itself,
 * which every adapter (direct-fetch DeepSeek and SDK-backed pi-ai alike)
 * goes through. The wrapper tees each matching response body, reads just
 * enough SSE to find the fingerprint, and hands the untouched branch back
 * to the adapter.
 *
 * Session correlation: the llm/stream waterfall sees
 * (options.sessionId, options.model, options.purpose) but not the wire;
 * the fetch wrapper sees the wire but not the session. Each adapter issues
 * exactly one provider request per stream() call, so an observation is
 * attributed to the most recent in-flight waterfall call — preferring an
 * exact model match — recorded while the response was in flight.
 *
 * Data channel: custom session event types are not viable for third-party
 * plugins (the persistence reader refuses unknown types and Session.append
 * offers no ignorable marker), and Remote namespaces need build-time codegen.
 * A plain webServer route polled by the client half is none of those things.
 */
import type { IncomingMessage, ServerResponse } from "node:http";

/** Row config accepted from cordis.patch.yml (no schema export: zero deps). */
export interface FingerprintShowConfig {
  /** HTTP route prefix served on the web server. Default /dsh-fingerprint-show. */
  pathPrefix?: string;
  /** Substring patterns matched against provider request URLs. */
  matchPatterns?: string[];
  /** Ring-buffer capacity for captured observations. Default 500. */
  maxObservations?: number;
}

/** One captured provider response carrying a system fingerprint. */
export interface FingerprintObservation {
  /** Provider response id when the SSE chunk carried one. */
  id?: string;
  /** The provider's system_fingerprint value. */
  fingerprint: string;
  /** Model id as echoed by the provider response. */
  model?: string;
  /** Coarse provider guess derived from the request URL host. */
  provider?: string;
  /** Harness session the call was attributed to; null when unattributed. */
  sessionId?: string | null;
  /** GenerateOptions.purpose of the correlated call ('compaction' | 'session-title' | undefined). */
  purpose?: string | null;
  /** Unix epoch ms of the capture. */
  time: number;
}

/** An llm/stream waterfall activation we still attribute fetches to. */
interface InflightCall {
  sessionId?: string;
  provider?: string;
  model: string;
  purpose?: string;
  startedAt: number;
}

/** Upper bound for stale in-flight entries (abandoned generators never run their finally). */
const INFLIGHT_TTL_MS = 10 * 60 * 1000;

export const name = "fingerprint-show";

/** This row needs the web profile's HTTP server; headless profiles keep it dormant. */
export const inject = ["webServer"];

export function apply(ctx: any, config: FingerprintShowConfig = {}) {
  const pathPrefix = config.pathPrefix ?? "/dsh-fingerprint-show";
  const patterns = config.matchPatterns?.length ? config.matchPatterns : ["chat/completions"];
  const maxObservations = Math.max(1, config.maxObservations ?? 500);

  /** Newest-last ring buffer of observations. */
  const observations: FingerprintObservation[] = [];
  /** Waterfall activations currently between entry and generator completion. */
  const inflight = new Set<InflightCall>();
  /** Capture counters surfaced through the API for diagnosis. */
  const stats = {
    matchedResponses: 0,
    capturedFingerprints: 0,
    /** SSE data payloads parsed by the observer across matched responses. */
    parsedChunks: 0,
    /**
     * First data payload of the most recent matched response that yielded NO
     * fingerprint — the ground truth for why capture came up empty.
     */
    lastPayloadSample: "" as string,
  };
  /** Log the first intercepted provider response once, not per request. */
  let announced = false;

  const record = (obs: FingerprintObservation): void => {
    observations.push(obs);
    if (observations.length > maxObservations) {
      observations.splice(0, observations.length - maxObservations);
    }
  };

  /** Most recent in-flight call, preferring an exact model match. */
  const correlate = (model?: string): InflightCall | undefined => {
    const now = Date.now();
    for (const call of inflight) {
      if (now - call.startedAt > INFLIGHT_TTL_MS) inflight.delete(call);
    }
    let fallback: InflightCall | undefined;
    for (const call of inflight) {
      if (model !== undefined && call.model === model) {
        if (!fallback || fallback.model !== model || call.startedAt > fallback.startedAt) fallback = call;
      } else if (!fallback || (fallback.model !== model && call.startedAt > fallback.startedAt)) {
        fallback = call;
      }
    }
    return fallback;
  };

  // ── 1. observe the llm/stream waterfall: session identity per model call ──
  ctx.on("llm/stream", (options: any, next: () => AsyncIterable<any>) => {
    const call: InflightCall = {
      sessionId: typeof options?.sessionId === "string" ? options.sessionId : undefined,
      provider: typeof options?.provider === "string" ? options.provider : undefined,
      model: String(options?.model ?? ""),
      purpose: typeof options?.purpose === "string" ? options.purpose : undefined,
      startedAt: Date.now(),
    };
    inflight.add(call);
    let inner: AsyncIterable<any>;
    try {
      inner = next();
    } catch (err) {
      inflight.delete(call);
      throw err;
    }
    return async function* () {
      try {
        yield* inner;
      } finally {
        inflight.delete(call);
      }
    }();
  });

  // ── 2. observe provider responses at the fetch boundary ───────────────────
  ctx.effect(() => {
    // Keep the exact original reference for restoration, and a bound view of
    // it for invocation (detached fetch breaks on some platforms).
    const originalFetch = globalThis.fetch;
    const callOriginal = originalFetch.bind(globalThis);

    const urlOf = (input: unknown): string => {
      if (typeof input === "string") return input;
      if (input instanceof URL) return input.href;
      if (input && typeof input === "object" && typeof (input as any).url === "string") return (input as any).url;
      return "";
    };

    const matches = (url: string): boolean => patterns.some((p) => p.length > 0 && url.includes(p));

    /**
     * Read the tee'd SSE branch until the first system_fingerprint shows up,
     * then stop. Every OpenAI-compatible chat-completions chunk repeats the
     * field, so this settles within the first payload or two.
     */
    const extractFromTee = async (branch: ReadableStream<Uint8Array>, url: string): Promise<void> => {
      const startedAt = Date.now();
      const reader = branch.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let finished = false;
      let firstPayload: string | undefined;
      try {
        while (!finished) {
          const { value, done } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          let newlineAt: number;
          while (!finished && (newlineAt = buffer.indexOf("\n")) !== -1) {
            const line = buffer.slice(0, newlineAt).trim();
            buffer = buffer.slice(newlineAt + 1);
            if (!line.startsWith("data:")) continue;
            const payload = line.slice(5).trim();
            if (payload === "[DONE]") {
              finished = true;
              break;
            }
            let chunk: any;
            try {
              chunk = JSON.parse(payload);
            } catch {
              continue;
            }
            stats.parsedChunks += 1;
            if (firstPayload === undefined) {
              firstPayload = payload.length > 240 ? payload.slice(0, 240) + "…" : payload;
            }
            const fingerprint = chunk?.system_fingerprint ?? chunk?.systemFingerprint;
            if (typeof fingerprint === "string" && fingerprint.length > 0) {
              const model = typeof chunk.model === "string" ? chunk.model : undefined;
              const call = correlate(model);
              let host: string | undefined;
              try {
                host = new URL(url, "http://placeholder.invalid").host || undefined;
              } catch {
                host = undefined;
              }
              record({
                id: typeof chunk.id === "string" ? chunk.id : undefined,
                fingerprint,
                model,
                provider: call?.provider ?? host,
                sessionId: call?.sessionId ?? null,
                purpose: call?.purpose ?? null,
                time: startedAt,
              });
              stats.capturedFingerprints += 1;
              finished = true;
            }
          }
        }
      } catch {
        // Provider closed early or the consumer aborted; nothing to record.
      } finally {
        if (firstPayload !== undefined) {
          stats.lastPayloadSample = firstPayload;
        }
        reader.cancel().catch(() => {});
      }
    };

    const wrappedFetch = async (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
      const res = await callOriginal(input as any, init as any);
      try {
        const url = urlOf(input);
        if (res.ok && res.body && matches(url)) {
          stats.matchedResponses += 1;
          if (!announced) {
            announced = true;
            console.info("[fingerprint-show] observing provider responses matching " + JSON.stringify(patterns) + " (first: " + res.status + " " + url + ")");
          }
          const [forAdapter, forObserver] = res.body.tee();
          void extractFromTee(forObserver, url).catch(() => {});
          // Re-wrap so the adapter consumes the untouched branch.
          return new Response(forAdapter, {
            status: res.status,
            statusText: res.statusText,
            headers: res.headers,
          });
        }
      } catch {
        // Never let observation break the actual call.
      }
      return res;
    };

    globalThis.fetch = wrappedFetch as typeof globalThis.fetch;
    return () => {
      if ((globalThis as any).fetch === wrappedFetch) {
        globalThis.fetch = originalFetch;
      }
    };
    // eslint-disable-next-line @typescript-eslint/no-unused-vars -- callOriginal used above
  }, "fingerprint-show: fetch wrapper");

  // ── 3. serve observations to the browser half over a same-origin route ────
  ctx.effect(() => {
    const json = (res: ServerResponse, status: number, body: unknown): void => {
      res.writeHead(status, {
        "content-type": "application/json; charset=utf-8",
        "cache-control": "no-store",
      });
      res.end(JSON.stringify(body));
    };

    const disposeRoute = ctx.webServer.register({
      kind: "prefix",
      path: pathPrefix,
      handler: (req: IncomingMessage, res: ServerResponse) => {
        let url: URL;
        try {
          url = new URL(req.url ?? "/", "http://placeholder.invalid");
        } catch {
          json(res, 400, { error: "bad-request" });
          return;
        }
        if (url.pathname !== pathPrefix + "/api/observations") {
          json(res, 404, { error: "not-found" });
          return;
        }
        const sessionId = url.searchParams.get("sessionId") ?? undefined;
        const limitRaw = Number(url.searchParams.get("limit"));
        const limit = Number.isFinite(limitRaw) ? Math.min(200, Math.max(1, Math.trunc(limitRaw))) : 20;
        const list = [...observations]
          .reverse()
          .filter((o) => !sessionId || o.sessionId === sessionId)
          .slice(0, limit);
        json(res, 200, {
          observations: list,
          stats: {
            ...stats,
            inflightCalls: inflight.size,
            totalStored: observations.length,
          },
        });
      },
    });
    return disposeRoute;
  }, "fingerprint-show: route");
}
