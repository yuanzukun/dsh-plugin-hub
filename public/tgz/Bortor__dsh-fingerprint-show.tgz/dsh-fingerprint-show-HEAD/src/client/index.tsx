/**
 * dsh-fingerprint-show — browser half.
 *
 * Appends the provider model fingerprint as a plain-text suffix to EACH
 * closing assistant message's metrics row ("time · ran-for · TTFT · tok/s ·
 * fingerprint"). Full value, no buttons, no copy interaction. Visibility is
 * synchronized with the hover-revealed metrics text: the injected stylesheet
 * hides the span until the message row is hovered/focused (inline opacity
 * would outrank those rules, so the style object carries none).
 *
 * Data: one shared poller per session reads the host half's observation
 * route; observations are aligned to messages by monotone time matching so
 * mid-conversation model switches keep each message's own fingerprint.
 *
 * Loaded by the DSH client module system from the package's
 * exports["./client"] bundle (built by scripts/build.mjs into the lazy-CJS
 * factory form). react / react-dom are shell-seeded externals.
 */
import { useEffect, useState } from "react";

interface Observation {
  id?: string;
  fingerprint: string;
  model?: string;
  provider?: string;
  sessionId?: string | null;
  purpose?: string | null;
  time: number;
}

const POLL_MS = 2500;
const FETCH_LIMIT = 200;

/**
 * Align observations to assistant messages: walk both lists in time order;
 * each message claims the latest observation that started before the
 * message's own log time, consuming every observation at most once — so
 * historical messages keep the fingerprint of the deployment that actually
 * answered them, even after a mid-conversation model switch.
 */
export function matchFingerprints(assistantNodes, observations) {
  const msgs = assistantNodes
    .filter((n) => n && n.kind === "assistant" && n.messageId && typeof n.time === "number")
    .slice()
    .sort((a, b) => a.time - b.time);
  const obs = (observations ?? [])
    .filter((o) => o && typeof o.fingerprint === "string" && !o.purpose)
    .slice()
    .sort((a, b) => a.time - b.time);
  const byMessage = new Map();
  let i = 0;
  for (const msg of msgs) {
    let candidate = null;
    while (i < obs.length && obs[i].time <= msg.time) {
      candidate = obs[i];
      i += 1;
    }
    if (candidate) byMessage.set(msg.messageId, candidate);
  }
  return byMessage;
}

/** Shared per-session poller; refcounted so mounted tags share one loop. */
class SessionObservationsStore {
  sessionId;
  listeners = new Set();
  observations = [];
  timer = undefined;
  alive = false;
  constructor(sessionId) {
    this.sessionId = sessionId;
  }
  subscribe = (listener) => {
    this.listeners.add(listener);
    if (this.listeners.size === 1) this.start();
    return () => {
      this.listeners.delete(listener);
      if (this.listeners.size === 0) this.stop();
    };
  };
  getSnapshot = () => this.observations;
  start() {
    this.alive = true;
    void this.poll();
  }
  stop() {
    this.alive = false;
    if (this.timer !== undefined) {
      clearTimeout(this.timer);
      this.timer = undefined;
    }
  }
  async poll() {
    let emptyPolls = 0;
    while (this.alive) {
      try {
        const res = await fetch(
          "/dsh-fingerprint-show/api/observations?sessionId=" + encodeURIComponent(this.sessionId) + "&limit=" + FETCH_LIMIT,
          { headers: { accept: "application/json" } },
        );
        if (!res.ok) throw new Error("HTTP " + res.status);
        const data = await res.json();
        const list = Array.isArray(data?.observations) ? data.observations : [];
        if (this.alive && list.length !== this.observations.length) {
          this.observations = list;
          for (const listener of [...this.listeners]) {
            try {
              listener();
            } catch {
              // One bad subscriber never blocks the rest.
            }
          }
        }
        // One-time hint when the host keeps reporting nothing: point at the
        // diagnostic counters so which half is missing stays obvious.
        if (this.alive && list.length === 0) {
          emptyPolls += 1;
          if (emptyPolls === 3) {
            const s = data?.stats ?? {};
            console.info(
              "[fingerprint-show] no fingerprints captured yet — matchedResponses=" + (s.matchedResponses ?? "?")
              + " capturedFingerprints=" + (s.capturedFingerprints ?? "?")
              + ". Send one message, then check /dsh-fingerprint-show/api/observations",
            );
          }
        } else if (list.length > 0) {
          emptyPolls = 0;
        }
      } catch {
        // Route absent (headless profile) or server restarting: retry later.
      }
      if (!this.alive) break;
      await new Promise((resolve) => {
        this.timer = setTimeout(resolve, POLL_MS);
      });
    }
  }
}

const stores = new Map();
function storeFor(sessionId) {
  let store = stores.get(sessionId);
  if (!store) {
    store = new SessionObservationsStore(sessionId);
    stores.set(sessionId, store);
  }
  return store;
}

/**
 * Plain-text look that blends into the metrics row ("… tok/s · fingerprint").
 * Mirrors the shipped clock-text styling: same tertiary label color and the
 * same 10px separator margins — no font/size overrides. NO inline opacity:
 * visibility is owned by the injected hover stylesheet (an inline value would
 * outrank those rules and defeat the hide/show). The order field pushes the
 * span after the trailing clock text when the actions row is a flex
 * container; harmless when it is not.
 */
const tagStyle = {
  color: "var(--dsw-alias-label-tertiary)",
  // Mirror the shipped clock text exactly (font-size 14px + line-height
  // 24px): the row container sets neither, so without both the dot glyph
  // lands on a different vertical position than the native separators.
  fontSize: "14px",
  lineHeight: "24px",
  whiteSpace: "nowrap",
  order: 99,
};

/**
 * Separator dot: right margin only. The actions row is a flex container with
 * gap:10px, so the LEFT spacing comes from that gap; a left margin here would
 * double it (20px) and detach the fingerprint from the metrics text.
 */
const dotStyle = { margin: "0 10px 0 0" };

/**
 * Subscribe to one store with plain useState/useEffect. Deliberately NOT
 * React's built-in useSyncExternalStore: the web shell seeds a hand-built
 * react module table whose exported surface is not guaranteed to carry it
 * (the shipped plugins stick to the basic hooks and vendor their own
 * use-sync-external-store shim), and a missing export crashes the tag.
 */
function useStoreValue(store) {
  const [value, setValue] = useState(() => store.getSnapshot());
  useEffect(() => {
    const update = () => setValue(store.getSnapshot());
    update();
    return store.subscribe(update);
  }, [store]);
  return value;
}

/**
 * Per-message tag: plain fingerprint text in the metrics row of EACH
 * finalized closing message — history keeps the fingerprint of the
 * deployment that actually answered it. Click copies the full value.
 */
function FingerprintTag(props) {
  const messageId = props?.messageId;
  // The standard kit carries both the plain sessionId and the session
  // selector hook; official consumers always pass a selector (uSES-based).
  const sessionId = props?.sessionId;
  const useSession = props?.useSession;
  // Resolve THIS message's node so we can gate on its metrics line: the
  // fingerprint only appends to a message that actually renders timing.
  const node = typeof useSession === "function"
    ? useSession((s) => {
        const list = s === null || s === undefined ? null : s.nodes;
        if (!Array.isArray(list)) return null;
        for (const n of list) {
          if (n && n.kind === "assistant" && n.messageId === messageId) return n;
        }
        return null;
      })
    : null;
  const key = sessionId ?? "";
  const observations = useStoreValue(storeFor(key));
  // No metrics row -> no fingerprint (avoids an orphaned dot at the row end).
  if (!node || !node.timing || !messageId || !sessionId || !observations.length) return null;
  const matched = matchFingerprints([node], observations).get(messageId);
  if (!matched) return null;
  const when = (() => {
    try {
      return new Date(matched.time).toLocaleTimeString();
    } catch {
      return "";
    }
  })();
  const tooltip = [
    "model: " + (matched.model ?? "?"),
    matched.provider ? "provider: " + matched.provider : null,
    when,
  ].filter(Boolean).join("\n");
  // Plain text, full value, no copy interaction; dot spacing matches the
  // native separator so the segment reads as one continuous metrics line.
  return (
    <span data-fingerprint-show title={tooltip} style={tagStyle}>
      <span aria-hidden="true" style={dotStyle}>{"\u00b7"}</span>
      <span>{matched.fingerprint}</span>
    </span>
  );
}

/** Required client services: the slot registry. */
export const inject = ["slots"];

/**
 * Client plugin body: one additive entry in the assistant-message action
 * strip (the seat ui-message-feedback also uses). The declaration is owned
 * by ui-conversation's chat view, so go through slots.inject() and only
 * register once the seat exists.
 */
export function apply(ctx) {
  // Show/hide the fingerprint in lockstep with the hover-revealed metrics
  // text: both sit at opacity 0 until the message row is hovered/focused, so
  // nothing floats alone in the reserved space. Mirrors the shipped rule for
  // [data-time-hover-root] :is(.timeStart,.timeEnd).
  ctx.effect(() => {
    if (typeof document === "undefined") return;
    const style = document.createElement("style");
    style.textContent =
      "@media (hover:hover){[data-time-hover-root] [data-fingerprint-show]{opacity:0!important;pointer-events:none!important;transition:opacity 80ms}"
      + "[data-time-hover-root]:hover [data-fingerprint-show],[data-time-hover-root]:focus-within [data-fingerprint-show]{opacity:1!important;pointer-events:auto!important}}";
    document.head.appendChild(style);
    return () => style.remove();
  }, "fingerprint-show: hover css");
  ctx.slots.inject("conversation.chat.assistant-actions", () => {
    return ctx.slots.register(
      {
        name: "conversation.chat.assistant-actions",
        id: "fingerprint-show",
        order: 20,
      },
      FingerprintTag,
    );
  });
}
