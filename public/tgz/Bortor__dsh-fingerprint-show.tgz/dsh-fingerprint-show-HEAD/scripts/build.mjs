// Build script: produces the two halves of the dual-face package.
//
//   lib/index.js   — host half (Node ESM cordis plugin)
//   lib/client.js  — browser half, wrapped in the lazy-CJS factory form the
//                    DSH client module loader expects:
//                    window.__ModuleLoader__.load({ id, factory(require) })
//
// Only esbuild is required; every @deepseek-ai/* import in src/ is type-only
// and erased at build time, and react is external (shell-seeded in the web
// client), so no DSH package needs to be installed to build.

import { build } from "esbuild";
import { mkdir } from "node:fs/promises";

const PKG_ID = "dsh-fingerprint-show";

await mkdir("lib", { recursive: true });

// ── host half ──────────────────────────────────────────────────────────────
await build({
  entryPoints: ["src/index.ts"],
  outfile: "lib/index.js",
  bundle: true,
  platform: "node",
  format: "esm",
  target: "node22",
  sourcemap: true,
  logLevel: "info",
});

// ── client half ────────────────────────────────────────────────────────────
await build({
  entryPoints: ["src/client/index.tsx"],
  outfile: "lib/client.js",
  bundle: true,
  platform: "browser",
  format: "cjs",
  target: "es2022",
  jsx: "automatic",
  sourcemap: true,
  // react / react-dom are seeded by the web shell; requiring them inside the
  // factory resolves through the client module loader at materialization.
  external: ["react", "react/jsx-runtime", "react-dom", "react-dom/*"],
  banner: {
    js: [
      `window.__ModuleLoader__.load({`,
      `  id: ${JSON.stringify(PKG_ID)},`,
      `  factory: (require) => {`,
      `    var module = { exports: {} };`,
      `    var exports = module.exports;`,
      "",
    ].join("\n"),
  },
  footer: {
    js: ["", "    return module.exports;", "  }", "});", ""].join("\n"),
  },
  logLevel: "info",
});

console.log("[dsh-fingerprint-show] built lib/index.js + lib/client.js");
