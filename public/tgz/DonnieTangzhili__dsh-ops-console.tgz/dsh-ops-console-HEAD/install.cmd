@echo off
chcp 65001 >nul
setlocal EnableExtensions
title DSH 更新与重启控制台 - 安装
echo ============================================================
echo    DSH 更新与重启控制台 一键安装
echo ============================================================
echo.

set "PLUGIN_ROOT=%USERPROFILE%\.dsh\plugins"
set "PLUGIN_DIR=%PLUGIN_ROOT%\dsh-ops-console"

where dsh >nul 2>nul
if errorlevel 1 (
    echo [错误] 找不到 dsh 命令。请确认已安装 DSH WebUI，且 npm 全局 bin 目录在 PATH 中。
    pause
    exit /b 1
)

echo [1/2] 复制插件文件 -^> %PLUGIN_DIR%
if not exist "%PLUGIN_ROOT%" mkdir "%PLUGIN_ROOT%"
if not exist "%PLUGIN_DIR%" mkdir "%PLUGIN_DIR%"
copy /Y "%~dp0package.json" "%PLUGIN_DIR%\" >nul
copy /Y "%~dp0cordis.patch.yml" "%PLUGIN_DIR%\" >nul
xcopy /E /I /Y "%~dp0lib" "%PLUGIN_DIR%\lib" >nul
xcopy /E /I /Y "%~dp0client" "%PLUGIN_DIR%\client" >nul
if errorlevel 1 (
    echo [错误] 复制文件失败。
    pause
    exit /b 1
)

echo [2/2] 注册到 web profile（pnpm add link:）
call dsh plugin --profile web add "link:%PLUGIN_DIR%"
set "RC=%ERRORLEVEL%"

echo.
echo ============================================================
if "%RC%"=="0" (
    echo    安装成功！
) else (
    echo    注册命令返回 %RC%，请查看上方 pnpm 输出。
)
echo.
echo    接下来：
echo      1. 完全退出 DSH（若正在运行），重新运行:  dsh web
echo      2. 浏览器打开 WebUI，左下角 设置 -^> 更新与重启
echo      3. 使用 检查更新 / 一键更新 / 重启 DSH
echo.
echo    卸载:  dsh plugin --profile web remove dsh-ops-console
echo ============================================================
pause
