﻿// One-time repair restart 鈥?STAGE 2 (detached helper): kills the DSH process
// listening on :8899, then relaunches `dsh web` (hidden console, logs under
// ~/.dsh). Stays alive until the new process binds the port (or ~60s timeout).
'use strict';
const { spawn, execFileSync } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const PORT = 8899;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function findPid() {
  try {
    const out = execFileSync('netstat', ['-ano'], { encoding: 'utf8', windowsHide: true, timeout: 8000 });
    const lines = out.split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (line.indexOf('LISTENING') === -1) continue;
      const parts = line.trim().split(' ').filter((s) => s.length > 0);
      if (parts.length < 2) continue;
      const addr = parts[1];
      const colon = addr.lastIndexOf(':');
      if (colon === -1) continue;
      if (Number(addr.slice(colon + 1)) !== PORT) continue;
      const pid = Number(parts[parts.length - 1]);
      if (Number.isFinite(pid) && pid > 0) return pid;
    }
  } catch (e) {}
  return null;
}

function log(msg) {
  try {
    fs.appendFileSync(path.join(os.homedir(), '.dsh', 'dsh-restart-now.log'),
      new Date().toISOString() + ' ' + msg + '\n');
  } catch (e) {}
}

(async () => {
  log('helper started; finding process on :' + PORT);
  await sleep(3000);
  const pid = findPid();
  if (pid === null) {
    log('no LISTENING process on :' + PORT);
    process.exit(2);
  }
  log('killing pid ' + pid);
  try {
    execFileSync('taskkill', ['/F', '/PID', String(pid)], { stdio: 'ignore', windowsHide: true });
  } catch (e) {}
  for (let i = 0; i < 40; i++) {
    await sleep(500);
    if (findPid() === null) break;
  }
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const logDir = path.join(os.homedir(), '.dsh');
  try { fs.mkdirSync(logDir, { recursive: true }); } catch (e) {}
  const logOut = path.join(logDir, 'dsh-restart-now-' + stamp + '.out.log');
  const logErr = path.join(logDir, 'dsh-restart-now-' + stamp + '.err.log');
  log('relaunching dsh web (logs=' + logOut + ')');
  try {
    const out = fs.openSync(logOut, 'a');
    const err = fs.openSync(logErr, 'a');
    const child = spawn('powershell.exe', ['-NoProfile', '-WindowStyle', 'Hidden', '-Command', '& dsh web'], {
      cwd: os.homedir(),
      detached: false,
      stdio: ['ignore', out, err],
      env: process.env,
      windowsHide: true,
    });
    child.unref();
  } catch (e) {
    log('relaunch failed: ' + String(e && e.message || e));
    process.exit(3);
  }
  for (let i = 0; i < 120; i++) {
    await sleep(500);
    if (findPid() !== null) {
      log('new process is up');
      process.exit(0);
    }
  }
  log('timeout waiting for the new process');
  process.exit(4);
})().catch((e) => {
  log('helper error: ' + String(e && e.stack || e));
  process.exit(1);
});

