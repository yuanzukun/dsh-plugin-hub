// One-time repair restart — STAGE 1: spawns a DETACHED helper (raw child
// process, survives the death of this script, pwsh and DSH) and exits. The
// helper (dsh-restart-helper.cjs) does the kill + relaunch.
const { spawn } = require('node:child_process');
const path = require('node:path');

const helperPath = path.join(__dirname, 'dsh-restart-helper.cjs');
const child = spawn(process.execPath, [helperPath], {
  detached: true,
  stdio: 'ignore',
  windowsHide: true,
});
child.unref();
console.log('dsh-restart-now: detached helper spawned (pid ' + child.pid + '); exiting');
setTimeout(() => process.exit(0), 200);
