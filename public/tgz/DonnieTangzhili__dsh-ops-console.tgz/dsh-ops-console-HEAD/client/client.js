window.__ModuleLoader__.load({ id: "dsh-ops-console", factory: (require) => {
var module = { exports: {} }; var exports = module.exports;
var React = require("react");

var S = {
  wrap: { display: 'flex', flexDirection: 'column', gap: 12, padding: '8px 2px', fontSize: 13, color: 'var(--dsw-alias-label-primary)' },
  header: { display: 'flex', alignItems: 'baseline', gap: 8, fontWeight: 600 },
  version: { fontWeight: 400, color: 'var(--dsw-alias-label-secondary)', fontSize: 12 },
  actions: { display: 'flex', gap: 8, flexWrap: 'wrap' },
  btn: { padding: '6px 14px', borderRadius: 6, border: '1px solid var(--dsw-alias-border-l1)', background: 'var(--dsw-alias-bg-layer-2)', color: 'var(--dsw-alias-label-primary)', cursor: 'pointer', fontSize: 13 },
  danger: { color: 'var(--dsw-alias-state-error-primary)', borderColor: 'var(--dsw-alias-state-error-primary)' },
  warn: { color: 'var(--dsw-alias-state-warn-primary)', borderColor: 'var(--dsw-alias-state-warn-primary)' },
  table: { borderCollapse: 'collapse', width: '100%', fontSize: 12 },
  th: { border: '1px solid var(--dsw-alias-border-l1)', padding: '5px 8px', textAlign: 'left', color: 'var(--dsw-alias-label-secondary)', fontWeight: 500 },
  td: { border: '1px solid var(--dsw-alias-border-l1)', padding: '5px 8px', textAlign: 'left', verticalAlign: 'top' },
  up: { color: 'var(--dsw-alias-state-warn-primary)', fontWeight: 600 },
  ok: { color: 'var(--dsw-alias-state-success-primary)' },
  fail: { color: 'var(--dsw-alias-state-error-primary)' },
  note: { color: 'var(--dsw-alias-label-secondary)', fontSize: 12, lineHeight: 1.6 },
  error: { color: 'var(--dsw-alias-state-error-primary)', fontSize: 12, whiteSpace: 'pre-wrap' },
  steps: { display: 'flex', flexDirection: 'column', gap: 6, fontSize: 12 },
  step: { display: 'flex', gap: 8, alignItems: 'baseline' },
  pre: { whiteSpace: 'pre-wrap', margin: 0, color: 'var(--dsw-alias-label-secondary)', fontSize: 11, background: 'var(--dsw-alias-bg-layer-2)', padding: '4px 6px', borderRadius: 4, maxHeight: 120, overflow: 'auto' },
};

function OpsSection() {
  var state = React.useState('idle');
  var phase = state[0];
  var setPhase = state[1];
  var dstate = React.useState(null);
  var data = dstate[0];
  var setData = dstate[1];
  var estate = React.useState(null);
  var error = estate[0];
  var setError = estate[1];
  var rstate = React.useState(false);
  var restarting = rstate[0];
  var setRestarting = rstate[1];
  var ststate = React.useState(false);
  var stopping = ststate[0];
  var setStopping = ststate[1];
  var pstate = React.useState(null);
  var poll = pstate[0];
  var setPoll = pstate[1];
  var ustate = React.useState(null);
  var updateResult = ustate[0];
  var setUpdateResult = ustate[1];

  var busy = phase === 'checking' || phase === 'updating' || restarting || stopping;

  function stopPoll(handle) {
    if (handle != null) { try { window.clearInterval(handle); } catch (e) {} }
    setPoll(null);
    return null;
  }

  // Clean up the reconnect-poll interval when the panel unmounts (Cordis
  // cleanup convention: manual resources are released explicitly).
  React.useEffect(function () {
    return function () {
      if (poll != null) { try { window.clearInterval(poll); } catch (e) {} }
    };
  }, [poll]);

  function check() {
    setPhase('checking');
    setError(null);
    fetch('/dsh-ops/check-updates', { cache: 'no-store' })
      .then(function (res) { return res.json(); })
      .then(function (r) {
        if (r && r.ok) { setData(r.data); setPhase('done'); }
        else { setError((r && r.error) || '检查失败'); setPhase('error'); }
      })
      .catch(function (e) { setError(String(e && e.message || e)); setPhase('error'); });
  }

  function startReconnectPoll() {
    if (poll !== null) return;
    var tries = 0;
    var handle = null;
    handle = window.setInterval(function () {
      tries += 1;
      try {
        fetch(window.location.origin + '/', { cache: 'no-store' }).then(function (res) {
          if (res.ok) window.location.reload();
        }).catch(function () {});
      } catch (e) {}
      if (tries >= 60) {
        window.clearInterval(handle);
        setPoll(null);
        setRestarting(false);
        setPhase('idle');
        setError('服务器未在预期时间内恢复，请手动刷新页面。若未能启动，请查看重启日志（%TEMP% 下的 dsh-ops-restart-*.log）。');
      }
    }, 2000);
    setPoll(handle);
  }

  function applyUpdates() {
    if (busy) return;
    if (!window.confirm('将安排一次「更新 + 自动重启」：\n\n1. 检测需要更新的核心包与插件\n2. 重启进程，并在重启过程中自动执行更新安装（npm install -g + pnpm）\n3. 完成后页面自动重连\n\n更新期间页面会短暂中断，无需手动操作。继续？')) return;
    setPhase('updating');
    setError(null);
    setUpdateResult(null);
    fetch('/dsh-ops/apply-updates', { method: 'POST', cache: 'no-store' })
      .then(function (res) { return res.json(); })
      .then(function (r) {
        if (r && r.ok) {
          if (r.scheduled) {
            setUpdateResult({ scheduled: true, message: r.message || '已安排更新并重启' });
            setPhase('done');
            startReconnectPoll();
          } else {
            setUpdateResult({ scheduled: false, message: r.message || '已是最新' });
            setPhase('done');
          }
        } else {
          setError((r && r.error) || '更新失败');
          setPhase('error');
        }
      })
      .catch(function (e) { setError(String(e && e.message || e)); setPhase('error'); });
  }

  function restart() {
    if (restarting) return;
    if (!window.confirm('确定要重启 DSH 吗？\n\n当前进程将在几秒后退出，页面会自动重新连接。\n会话历史已持久化，重启后仍可继续。')) return;
    setRestarting(true);
    setError(null);
    var port = Number(window.location.port) || 8899;
    fetch('/dsh-ops/restart?port=' + port, { method: 'POST', cache: 'no-store' })
      .then(function (res) { return res.json(); })
      .then(function (r) {
        if (!(r && r.ok)) {
          setError((r && r.error) || '重启请求失败');
          setRestarting(false);
          return;
        }
        startReconnectPoll();
      })
      .catch(function (e) {
        setError(String(e && e.message || e));
        setRestarting(false);
      });
  }

  // Full-screen notice injected straight into the DOM, so it SURVIVES the
  // server's death (React state and the connection die with the process).
  function showStoppedOverlay() {
    try {
      if (document.getElementById('dsh-ops-stopped-overlay')) return;
      var div = document.createElement('div');
      div.id = 'dsh-ops-stopped-overlay';
      div.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.75);display:flex;align-items:center;justify-content:center;color:#fff;font:15px/1.9 system-ui,sans-serif;text-align:center';
      var box = document.createElement('div');
      box.style.cssText = 'background:#202026;border:1px solid rgba(255,255,255,.18);border-radius:14px;padding:30px 40px;max-width:440px;box-shadow:0 12px 40px rgba(0,0,0,.5)';
      var title = document.createElement('div');
      title.style.cssText = 'font-size:22px;font-weight:700;margin-bottom:10px;color:#ff6b6b';
      title.textContent = '已停止 DSH';
      var body = document.createElement('div');
      body.innerHTML = '进程已终止，且<strong>不会自动重启</strong>。<br>如需恢复，请在终端运行：';
      var code = document.createElement('code');
      code.style.cssText = 'display:inline-block;margin-top:8px;padding:5px 12px;background:rgba(255,255,255,.1);border-radius:6px;font-size:14px';
      code.textContent = 'dsh web';
      var foot = document.createElement('div');
      foot.style.cssText = 'margin-top:14px;font-size:12px;opacity:.6';
      foot.textContent = '本页面已与服务器断开，可关闭此标签页。';
      box.appendChild(title);
      box.appendChild(body);
      box.appendChild(document.createElement('br'));
      box.appendChild(code);
      box.appendChild(foot);
      div.appendChild(box);
      document.body.appendChild(div);
    } catch (e) {}
  }

  function stopDsh() {
    if (busy) return;
    if (!window.confirm('确定要停止 DSH 吗？\n\n进程将被终止且【不会自动重启】。\n如需恢复，请手动运行: dsh web\n\n会话历史已持久化，不受影响。继续？')) return;
    setStopping(true);
    setError(null);
    fetch('/dsh-ops/stop', { method: 'POST', cache: 'no-store' })
      .then(function (res) { return res.json(); })
      .then(function (r) {
        if (!(r && r.ok)) {
          setError((r && r.error) || '停止请求失败');
          setStopping(false);
          return;
        }
        setUpdateResult({ scheduled: false, message: '已停止 DSH（未自动重启）。如需继续，请手动运行: dsh web' });
        setPhase('done');
        setStopping(false);
        showStoppedOverlay();
      })
      .catch(function (e) {
        setError(String(e && e.message || e));
        setStopping(false);
      });
  }

  var rows = null;
  if (data && Array.isArray(data.packages)) {
    rows = data.packages.map(function (p) {
      var latestCell = p.latest || (p.kind === 'npm' ? '获取失败' : '—');
      var marker = '';
      if (p.tags && p.latest && typeof p.latest === 'string') {
        var names = Object.keys(p.tags);
        var hit = null;
        for (var i = 0; i < names.length; i++) {
          if (names[i] !== 'latest' && p.tags[names[i]] === p.latest) { hit = names[i]; break; }
        }
        if (hit) marker = ' (' + hit + ')';
        else if (p.latest.indexOf('-') !== -1 && p.tags.latest !== p.latest) marker = ' (预发布)';
      }
      if (marker) latestCell = String(latestCell) + marker;
      var statusStyle = p.updateAvailable ? S.up : S.ok;
      var statusText = p.updateAvailable ? '有更新' : (p.kind === 'linked' ? '本地链接' : (p.kind === 'github' ? 'GitHub 安装' : '已是最新'));
      return React.createElement('tr', { key: p.name },
        React.createElement('td', { style: S.td }, p.name),
        React.createElement('td', { style: S.td }, p.installed || '—'),
        React.createElement('td', { style: S.td }, latestCell),
        React.createElement('td', { style: Object.assign({}, S.td, statusStyle) }, statusText));
    });
  }

  var hasUpdates = data && Array.isArray(data.packages) && data.packages.some(function (p) { return p.updateAvailable; });

  return React.createElement('div', { style: S.wrap },
    React.createElement('div', { style: S.header },
      React.createElement('span', null, 'DSH 更新与重启'),
      data && data.launcher ? React.createElement('span', { style: S.version }, '当前 ' + data.launcher) : null),
    React.createElement('div', { style: S.actions },
      React.createElement('button', { style: S.btn, onClick: check, disabled: busy }, phase === 'checking' ? '检查中…' : '检查更新'),
      React.createElement('button', { style: Object.assign({}, S.btn, S.warn), onClick: applyUpdates, disabled: busy }, phase === 'updating' ? '安排中…' : '一键更新'),
      React.createElement('button', { style: Object.assign({}, S.btn, S.danger), onClick: restart, disabled: busy }, restarting ? '重启中…' : '重启 DSH'),
      React.createElement('button', { style: Object.assign({}, S.btn, S.danger), onClick: stopDsh, disabled: busy }, stopping ? '停止中…' : '停止 DSH')),
    phase === 'error' ? React.createElement('div', { style: S.error }, String(error)) : null,
    restarting ? React.createElement('div', { style: S.note }, '正在重启 DSH，页面将自动刷新。若长时间未恢复，请手动刷新浏览器。') : null,
    rows ? React.createElement('table', { style: S.table },
      React.createElement('thead', null, React.createElement('tr', null,
        React.createElement('th', { style: S.th }, '包'),
        React.createElement('th', { style: S.th }, '已安装'),
        React.createElement('th', { style: S.th }, '最新'),
        React.createElement('th', { style: S.th }, '状态'))),
      React.createElement('tbody', null, rows)) : null,
    hasUpdates ? React.createElement('div', { style: S.note },
      '发现更新，可点「一键更新」——会在重启过程中自动安装并生效，页面自动重连。') : null,
    updateResult ? React.createElement('div', { style: S.note },
      updateResult.scheduled ? '已安排更新并重启，页面将自动重连。'
        : (updateResult.message || '操作完成')) : null);
}

function apply(ctx) {
  var slots = ctx.get('slots');
  if (slots === undefined) return;
  slots.inject('settings.section', function () {
    return slots.register(
      { name: 'settings.section', id: 'dsh-ops', order: 50, label: function () { return '更新与重启'; } },
      function () { return React.createElement(OpsSection, null); }
    );
  });
}

exports.apply = apply;
exports.name = 'dsh-ops-console';
exports.inject = ['slots'];
return module.exports;
}});
