# Changelog

## v1.1.0 (2026-08-20)

- 新增「停止 DSH」按钮（只停止、不自动重启；手动 `dsh web` 恢复）——回应 issue #2
- 重启不再新开浏览器标签页（自动追加 `--no-open`），原页面自动重连刷新——回应 issue #1
- 停止后显示全屏提示（DOM 注入，进程死后依然可见）
- 文档合规改进：新增 Schemastery `Config` schema（`profile` / `registries` 可配置）；profile 名从启动命令自动推导（不再硬编码 `web`）；client 重连定时器卸载时清理

## v1.0.0 (2026-08-20)

- 首次发布
- 功能：一键检查更新 / 一键更新（重启过程中执行，避免运行时替换文件）/ 一键重启 DSH（按原始启动命令精确重放）
- 安装方式：`dsh plugin --profile web add github:DonnieTangzhili/dsh-ops-console`
