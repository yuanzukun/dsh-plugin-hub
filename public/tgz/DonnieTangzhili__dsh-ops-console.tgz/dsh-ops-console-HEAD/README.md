# DSH 更新与重启控制台

[![GitHub release](https://img.shields.io/github/v/release/DonnieTangzhili/dsh-ops-console)](https://github.com/DonnieTangzhili/dsh-ops-console/releases)
[![License](https://img.shields.io/github/license/DonnieTangzhili/dsh-ops-console)](LICENSE)
[![GitHub stars](https://img.shields.io/github/stars/DonnieTangzhili/dsh-ops-console)](https://github.com/DonnieTangzhili/dsh-ops-console/stargazers)
[![Last commit](https://img.shields.io/github/last-commit/DonnieTangzhili/dsh-ops-console)](https://github.com/DonnieTangzhili/dsh-ops-console/commits/main)

> A DSH WebUI plugin: one-click **update check**, **apply updates during restart**, and a **reliable restart** button — all from the Settings page.
>
> DSH WebUI 插件：在「设置」页一键**检查更新**、**更新并自动重启**、**重启 DSH**。

给不想麻烦去使用带重启的桌面版的开发者使用，在纯dsh web上也可以点击重启
无外部依赖、无需构建，与 DSH 版本无关（rc.6 / rc.7 / rc.8 均可）。

---

## ✨ 功能

| 按钮 | 说明 |
| --- | --- |
| **检查更新** | 对比核心包（`@deepseek-ai/dsh`、`dsh-web-app`、`dsh-base`）与已装插件的已安装/最新版本，自动识别预发布标签（如 `(next)`） |
| **一键更新** | 生成更新计划并**自动重启**；更新命令（`npm install -g` + `pnpm`）在旧进程退出后执行——**不会在服务运行时替换文件，页面不会被弄挂** |
| **重启 DSH** | 按原始启动命令（含 `--port` 等参数）精确重放并重新拉起，页面自动重连 |
| **停止 DSH** | 终止进程**且不自动重启**；如需恢复，手动运行 `dsh web` |

> 可配置项（在 profile 的 `cordis.patch.yml` 中通过 `config` 覆盖）：`profile`（目标 profile 名，默认从启动命令自动推导）、`registries`（检查更新使用的 npm registry 列表）。

## 📋 要求

- 已安装 DSH WebUI（`dsh web` 能启动）
- `dsh`、`pnpm` 在 PATH 中（通过 npm 全局安装 dsh 时默认满足）

## 🚀 安装

### 方式一：GitHub 安装（推荐）

```bash
dsh plugin --profile web add github:DonnieTangzhili/dsh-ops-console
```

然后完全退出 DSH 并重新运行 `dsh web`，打开 WebUI → 左下角 **设置** → 侧边出现 **「更新与重启」**。

### 方式二：下载 ZIP 双击安装

1. 从 [Releases](https://github.com/DonnieTangzhili/dsh-ops-console/releases) 下载 zip 并解压
2. **先退出 DSH**
3. 双击 `install.cmd`
4. 重新运行 `dsh web`

### 方式三：手动安装

```bash
# 1. 把 dsh-ops-console 文件夹放到 ~/.dsh/plugins/ 下
# 2. 注册到 profile
dsh plugin --profile web add "link:%USERPROFILE%\.dsh\plugins\dsh-ops-console"
# 3. 重启 DSH
```

## 🔧 使用

打开 WebUI → 左下角 **设置** → **「更新与重启」** 页面：

1. 点 **检查更新** 查看所有相关包的版本对比
2. 有更新时点 **一键更新**——页面提示已安排，随后自动重启，更新在重启过程中完成，页面自动重连
3. 任何时候点 **重启 DSH** 快速重启

## 🗑️ 卸载

```bash
dsh plugin --profile web remove dsh-ops-console
```

## 🔍 故障排查

| 现象 | 处理 |
| --- | --- |
| 安装后设置里没有「更新与重启」 | 确认已重启 DSH；或到 设置 → 插件 检查 `dsh-ops-console` 是否加载 |
| 一键更新 / 重启后页面没回来 | 查看 `%TEMP%\dsh-ops-restart-*.log` |
| 按钮失效的兜底 | 终端运行 `node tools\dsh-restart-now.js`（杀掉 8899 端口的 DSH 并用 `dsh web` 重新拉起） |

## 🔄 更新插件本身

```bash
dsh plugin --profile web update dsh-ops-console
```
（GitHub 安装会拉到仓库最新提交，重启 DSH 生效。）

## 🛠️ 开发

- 无构建步骤：`lib/index.js`（Host）+ `client/client.js`（Client bundle）都是纯 JS
- 修改后 `git push`，使用者 `dsh plugin --profile web update dsh-ops-console` 即可
- 详情见 [CHANGELOG.md](CHANGELOG.md)

## 📄 License

[MIT](LICENSE)
