/**
 * Host-side heartbeat: a small JSON file written under `$DSH_HOME` once the
 * `qoder` provider is registered. The status CLI reads it to report
 * whether the host bundle is alive, independent of the browser card.
 *
 * 参考：corrinehu/dsh-workbuddy-connect（MIT，Copyright (c) 2026 Corrine Hu）
 *   — 该机制由其设计：浏览器端无法写文件，其健康只能靠 console.error 上报，
 *     因此由宿主写心跳文件，缺失即代表宿主从未启动；崩溃后的陈旧心跳
 *     通过 PID 存活检查识别。
 * 参考：dsh-connect-workbuddy（MIT，Copyright (c) 2026 LaoDing）的同名模块
 * 改动：纯改名移植（WorkBuddy → Qoder，包名/版本常量/心跳文件名），机制、
 *      `windowsHide`、PID 与 start-time 逻辑原样沿用。
 *
 * @module dsh-connect-qoder/host-heartbeat
 */

import { execFileSync } from 'node:child_process'
import { readFile, rm, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { resolveDshHome } from '@deepseek-ai/dsh-home-paths'
import { QODER_CONNECT_VERSION } from './version.ts'

/** Basename of the host heartbeat file inside the Harness home. */
export const QODER_HOST_HEARTBEAT_FILENAME = '.qoder-host-heartbeat.json'

/** Current on-disk heartbeat format; readers reject others. */
const HEARTBEAT_FORMAT_VERSION = 1

/** On-disk shape of the heartbeat. */
export interface QoderHostHeartbeat {
  version: typeof HEARTBEAT_FORMAT_VERSION
  package: 'dsh-connect-qoder'
  pluginVersion: string
  /** Epoch milliseconds when the host registered the provider. */
  registeredAt: number
  /** Host process PID, to distinguish a stale heartbeat after a crash. */
  pid: number
}

/** Absolute path of the host heartbeat file. */
export function qoderHostHeartbeatPath(): string {
  return join(resolveDshHome(), QODER_HOST_HEARTBEAT_FILENAME)
}

/**
 * Spawn options every external probe in this module is run with.
 *
 * `windowsHide` is REQUIRED here, not cosmetic. Windows hands a console-program
 * child a brand-new console window whenever its PARENT has none — and the
 * parent frequently has none: the DSH Desktop host is an Electron GUI process
 * (`MainWindowHandle = 0`, verified on the live host), as are Task Scheduler
 * jobs and CI services. That window is created VISIBLE, so every start-time
 * probe would flash a black box on the user's screen.
 *
 * Evidence (real Windows 11, parent created console-less through the WMI
 * service — the same condition as the Electron host; the child reports the
 * console it actually owns):
 *
 *   - without `windowsHide`: `NEW-console hwnd=1573500 visible=True`
 *   - with `windowsHide: true`: `no-console`
 *
 * Invoked from a terminal the parent HAS a console and the child simply
 * inherits it (no new window), which is why this never showed up in local
 * runs — the same blind spot `docs/WINDOWS.md` §0 describes. The sibling call
 * site `src/at-rest.ts` (the at-rest key fetch) already sets this option; this
 * module did not, and that inconsistency is what the test pins.
 *
 * On POSIX the option is ignored.
 */
export const PROCESS_PROBE_OPTIONS = { encoding: 'utf8', windowsHide: true } as const

/**
 * The command one start-time probe runs, per platform.
 *
 * Split out as a value so the spawn can be asserted WITHOUT a Windows machine:
 * `tests/host-heartbeat.spec.ts` checks the platform branch and the options
 * object directly, which is the only way a Windows-only spawn defect here can
 * be caught on the macOS development machine (§0: not "unreproduced" but
 * "impossible to reproduce").
 *
 * `platform` is injectable for the same reason, in the same spirit as
 * `defaultDesktopAuthDirs()` and `qoderAppExecutableCandidates()`.
 */
export function processStartProbe(
  pid: number,
  platform: NodeJS.Platform = process.platform,
): { file: string, args: string[] } {
  if (platform === 'win32') {
    return {
      file: 'powershell',
      args: [
        '-NoProfile', '-NonInteractive', '-Command',
        `(Get-Process -Id ${pid} -ErrorAction SilentlyContinue).StartTime.ToUniversalTime().ToString('o')`,
      ],
    }
  }
  return { file: 'ps', args: ['-o', 'lstart=', '-p', String(pid)] }
}

/**
 * Process start time in epoch milliseconds; undefined when unavailable.
 *
 * POSIX reads `ps -o lstart=`; Windows has no such command, so the creation
 * time is taken from PowerShell's `Get-Process` StartTime, emitted as UTC ISO
 * 8601 so `Date.parse` understands it without locale assumptions. Absent or
 * unqueryable processes (other users' processes) degrade to undefined.
 */
export function processStartTimeMs(pid: number): number | undefined {
  try {
    const probe = processStartProbe(pid)
    const output = execFileSync(probe.file, probe.args, PROCESS_PROBE_OPTIONS)
    const parsed = Date.parse(output.trim())
    return Number.isFinite(parsed) ? parsed : undefined
  } catch {
    return undefined
  }
}

/**
 * Whether the recorded host process still matches the heartbeat's PID.
 *
 * A PID can be reused after a crash, so the recorded start time is compared
 * against the live process: a different start time means a different process.
 */
export function isHeartbeatProcessAlive(heartbeat: QoderHostHeartbeat): boolean {
  if (!Number.isInteger(heartbeat.pid) || heartbeat.pid <= 0) return false
  try {
    // Signal 0 probes existence without delivering a signal.
    process.kill(heartbeat.pid, 0)
  } catch {
    return false
  }
  const startedAt = processStartTimeMs(heartbeat.pid)
  if (startedAt === undefined) return true
  // Allow one second of clock skew between the ps timestamp and Date.now().
  return Math.abs(startedAt - heartbeat.registeredAt) < 60_000
}

/** Read the heartbeat; absent or unparsable files report undefined. */
export async function readHostHeartbeat(): Promise<QoderHostHeartbeat | undefined> {
  try {
    const parsed: unknown = JSON.parse(await readFile(qoderHostHeartbeatPath(), 'utf8'))
    if (typeof parsed !== 'object' || parsed === null) return undefined
    const document = parsed as Record<string, unknown>
    if (document['version'] !== HEARTBEAT_FORMAT_VERSION) return undefined
    if (document['package'] !== 'dsh-connect-qoder') return undefined
    const pid = document['pid']
    const registeredAt = document['registeredAt']
    if (typeof pid !== 'number' || typeof registeredAt !== 'number') return undefined
    return {
      version: HEARTBEAT_FORMAT_VERSION,
      package: 'dsh-connect-qoder',
      pluginVersion: typeof document['pluginVersion'] === 'string' ? document['pluginVersion'] : QODER_CONNECT_VERSION,
      registeredAt,
      pid,
    }
  } catch {
    return undefined
  }
}

/** Write the heartbeat for the current process. */
export async function writeHostHeartbeat(): Promise<void> {
  const heartbeat: QoderHostHeartbeat = {
    version: HEARTBEAT_FORMAT_VERSION,
    package: 'dsh-connect-qoder',
    pluginVersion: QODER_CONNECT_VERSION,
    registeredAt: Date.now(),
    pid: process.pid,
  }
  await writeFile(qoderHostHeartbeatPath(), `${JSON.stringify(heartbeat, null, 2)}\n`, { mode: 0o600 })
}

/** Remove the heartbeat; called when the plugin is disposed. */
export async function clearHostHeartbeat(): Promise<void> {
  await rm(qoderHostHeartbeatPath(), { force: true })
}