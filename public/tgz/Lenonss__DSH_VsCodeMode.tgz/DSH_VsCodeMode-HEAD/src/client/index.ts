/**
 * dsh-vscode-mode client — 浏览器半入口：slot 注册 + 装配。
 * 挂点：官方右侧 Sidebar「文件编辑」Tab（DSH 0.1.5+，对话+编辑同屏）> betterSidebar Tab
 * （归档，仅旧版 DSH 回退）> conversation.view 中央页签 + conversation.input.dock 差异条 + header 差异角标。
 * 与 Host 通信：同源 fetch('/edrv/rpc')（shared/rpc 契约）。
 *
 * ⚠️ 跨版本 slot 装配（2026-08-21）：新版 DSH 的 slots 系统要求 slot 必须由父 entry
 * 的 children table 先声明，直接 `ctx.slots.register({name:'conversation.view'})` 在
 * 声明未就绪时抛 `slot ... is not declared (a parent entry's children table must declare it)`。
 * 正确写法 = `ctx.slots.inject(name, () => ctx.slots.register(...))`：声明存在时同步
 * 执行，否则等待声明（官方 ui-conversation 自身即此模式）；旧版（rc.8 及更早）同样支持，
 * 故跨版本兼容。slot 名：conversation.view / conversation.session.header.utilities /
 * conversation.input.dock。
 * 作者 ddj 2026-08-20
 */
import React from 'react'
import './styles/editor.css'
import { EditorView } from './ui/EditorView.js'
import { DiffBadge } from './ui/DiffBadge.js'
import { PerfSizeBadge } from './ui/PerfSizeBadge.js'
import { ConversationDiffDock } from './ui/ConversationDiffDock.js'
import { McpSettings } from './ui/McpSettings.js'
import { mcpSessionState } from './mcpSessionState.js'
import { McpSessionIcon, McpSessionDetail, type McpRowProps } from './ui/McpSessionStatus.js'
import { PluginDetailSection } from './ui/PluginDetailSection.js'
import { rpc } from './rpc.js'
import { loadMonaco } from './monaco/loader.js'
import { observeScheme, schemeOfSnapshot } from './monaco/theme.js'
import { createFileOpenerRegistry, scanSidebar, officialSidebarOpener, shouldClaimFiles, type FileOpenContext } from './fileOpeners.js'
import type { FileOpenerRegistry } from './fileOpeners.js'
import { installOpenPathRouter, vscodeOpener, autoValue } from './openPathRouter.js'
import { patchRemoteOpen, probeRemoteOpen } from './remoteOpenRouter.js'
import { patchSettingsDoc, probeSettingsDoc } from './settingsDocRouter.js'
import { openEditorView } from './events.js'
import { setupExtOpen } from './externalOpen.js'
import { SettingsContext } from './settingsContext.js'
import { SIDEBAR_PLUGIN, registerSlotSafely, settingsBridge } from './compat.js'
import { clientSummary } from './compatSummary.js'
import { detectSidebarService, hasSideRoute, installSideEditor, routeSideEditor, setEnsureSideEditor, SIDEBAR_INSTALL_CMD } from './sidebarBridge.js'
import { detectOfficial, installOfficial, registerOfficialFileClaim, OFFICIAL_TAB_KIND, OFFICIAL_TAB_TITLE, isEditorTabActive, markEditorActive, restoreEditorTab, buildFileAddress, readSavedTab, setEditorTabScope } from './officialSidebar.js'
import { setNativeCsv, setNativeOpenHandler, resetNativeOpen } from './nativeOpenStore.js'
import { SideEditorTab } from './ui/SideEditorTab.js'
import { OfficialSideTab } from './ui/OfficialSideTab.js'
import { createClaimRouter } from './ui/ClaimRouter.js'
import { createAddToConversation } from './addToConversation.js'
import { createSidebarPanelRegistry } from './sidebar/registry.js'
import { createFilePanel } from './sidebar/panels/index.js'
import { createSearchPanel } from './sidebar/panels/index.js'
import { createRulesPanel } from './sidebar/panels/index.js'
import { createSvnPanel } from './sidebar/panels/index.js'
import { createDebugPanel } from './sidebar/panels/index.js'
import { createTreeMenuRegistry } from './sidebar/contextMenu.js'
import { createDefaultFileMenuItems } from './sidebar/menuItems.js'
import { createOutlinePanel } from './outline/index.js'
import { createOutlineSourceRegistry, registerBuiltinOutlineSources } from './outline/sources.js'
import { createLspOutlineSource } from './outline/lspSource.js'
import { applyOfficialChords } from './keybindings.js'
import { createCommandBridge } from './commandBridge.js'
import type { CommandBridge } from './commandBridge.js'
import { REGISTRY_GLOBAL } from './commandGlobals.js'
import { awaitShortcutsService, bindCatalogChords, detectShortcuts, installLegacyKeys, migrateLegacyKeybindings, registerOfficialShortcuts } from './shortcutsOfficial.js'
import { SHORTCUT_PROFILES, defaultKeybindings, normalizeKeybindings } from '../shared/keybindings.js'
import { sidebarMinApply } from './sidebarMin.js'
import { editorLimitApply } from './editorLimit.js'
import { log } from './log.js'
import { installLocale } from './localeClient.js'
import { setupLsp, setSession, disposeLsp } from './monaco/lsp/index.js'
import { disposeSnippets } from './snippets/provider.js'
import { disposeLaunchJson } from './dap/launchSnippetProvider.js'
import { disposeAiInline } from './ai/inlineProvider.js'
import { readSessionScope, subscribeScope } from './sessionScope.js'
import { installPlanBridge } from './planBridge.js'
import { installPageReload } from './pageReload.js'
import { installUpdateNotice } from './updateNotice.js'
import { flushPageState, flushUiState, hydrateUiState, installUiStatePersist, onUiStateReady, reportUiStateEvent, uiStateSettled } from './state/uiStatePersist.js'
import { workspaceScopeOf } from './state/scopeStore.js'
import { dapStore } from './dap/store.js'
import type { CompatAdapter } from '../shared/compat.js'
import { setPanelImport } from './lazyPanel.js'
import { dbg } from './rpc.js'
import { BP_MODE, MODES, fieldOfMode } from './dap/BpWidget.js'
import { ContextMenu } from './ui/ContextMenu.js'

/** Root-owned live objects shared with independent panel chunks; no copied stores or transport state. */
export const __lazyShared = { rpc, dbg, dapStore, BP_MODE, MODES, fieldOfMode, ContextMenu }
export { setPanelImport as __setPanelImport }

// ⚠️ inject 只列必需服务：webUiSettings 是 @linxin666/dsh-client-ui-web-ui-settings 提供的
// 可选兼容桥（非官方服务），列入 inject 会让未装该桥的部署启动时 entry 永久 pending，
// web boot 直接失败（'1 entry did not activate'）。兼容层用 ctx.get 运行时探测 + 降级，不靠 inject。
// 设置桥服务同理不进 inject（DSH 0.1.7 移除 settingsScope、新增 configForms，0.1.6 反之；
// 写死任一桥名都会在另一版本停等）——设置桥由 compat.pickSettingsBinder 运行时探测三级降级。
export const inject = ['slots', 'timer', 'locale', 'connection', 'remote', 'workspaces', 'sessions', 'conversation']

/** 指令桥单例（同一 document 重复 apply 只装配一次；HMR 重挂不重复注册）。 */
let commandsBridge: CommandBridge | null = null

/**
 * 装配指令注册表（指令桥 + 命令栏）。
 * 指令桥不依赖已挂载编辑器（run 只派发窗口事件），故可在启动期装配；
 * 命令栏浮层的宿主由 CommandPalette 自己在编辑区树内认领。
 * @author ddj 2026年09月10号 / 2026年10月
 * @param ctx 客户端根上下文
 * @returns 指令桥（官方 shortcuts 注册的执行器来源）
 */
function setupCommands(ctx: any): CommandBridge {
  if (commandsBridge) return commandsBridge
  /** @author ddj 2026年09月28号 @returns Current session/workspace for command ownership. */
  const readScope = () => readSessionScope(ctx)
  /** @author ddj 2026年09月28号 @returns Whether an installed sidebar can mount the editor. */
  const canOpen = () => hasSideRoute()
  /** @author ddj 2026年09月28号 @returns Whether the current editor route accepted the request. */
  const open = () => routeSideEditor(null, false)
  const bridge = createCommandBridge({ readScope, canOpen, open })
  commandsBridge = bridge
  ctx.provide(REGISTRY_GLOBAL, bridge.registry)
  // 无条件镜像到 window（DSH 不创建 window.dsh，旧条件式赋值是死代码 → 命令栏空表）
  const host = window as unknown as Record<string, unknown>
  host[REGISTRY_GLOBAL] = bridge.registry
  ctx.effect(() => () => {
    bridge.dispose()
    commandsBridge = null
    if (host[REGISTRY_GLOBAL] === bridge.registry) delete host[REGISTRY_GLOBAL]
  }, 'vscode-mode: command registry')
  log.info('指令系统已装配：' + bridge.registry.list().length + ' 条指令，Ctrl+Shift+P 打开命令栏')
  return bridge
}

/**
 * 装配客户端：注册中央编辑区视图与 header 差异角标。
 * @author ddj 2026年08月20号
 * @param ctx 客户端根上下文（slots + timer 服务）
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function apply(ctx: any): Promise<void> {
  const schedule = (fn: () => void, ms: number) => ctx.timeout(fn, ms)

  // UI 壳层文案：注册本插件词典到官方 locale 服务（旧版无该服务时直读中文词典）。
  // slot label / 编辑 Tab 标题一律写成 thunk，让语言切换后无需重注册即可刷新。
  const t = installLocale(ctx)

  /**
   * 无门控上报界面状态镜像事件（绕过客户端 edrv.debug 开关，直接落 host 诊断日志）。
   * 开关关闭时 dbg 直接 return，「重启后没恢复」这类问题会在客户端侧彻底无痕，故另开一条通路。
   * @author ddj 2026年09月29号
   * @param text 事件文本
   * @param level 日志级别（缺省 'debug'）
   */
  const reportMirror = (text: string, level?: string): void => {
    // 只认 host 侧已知级别，其余落 'debug'（镜像内部只发 'debug'/'warn'）
    const lv = level === 'info' || level === 'warn' || level === 'error' ? level : 'debug'
    try {
      void rpc('edrv.debug', { sessionId: readSessionScope(ctx).sessionId, text: 'ui-state: ' + text, level: lv })
        .catch(() => { /* 诊断上报失败忽略 */ })
    } catch (error) { /* 会话未就绪等异常忽略 */ }
  }

  // 界面状态镜像：把 `edrv.*` 的 localStorage 状态写穿到 host，换 origin（重启换端口）后回填。
  // 必须早于任何界面首次读写 localStorage（编辑器页签/侧栏/预览态的恢复逻辑都读它）。
  if (installUiStatePersist(ctx, schedule, reportMirror)) {
    reportMirror('镜像装配成功（origin=' + (typeof location === 'undefined' ? '?' : location.origin) + '）')
    log.info('界面状态镜像已装配：界面状态随 host 持久化（重启/换端口可恢复）')
  } else {
    reportMirror('镜像装配失败：localStorage 不可用', 'warn')
    log.warn('界面状态镜像不可用（无 localStorage）：界面状态仅存当前 origin')
  }

  // 争取「回填先于任何界面组件挂载」：面板/编辑器的恢复逻辑都在挂载时读 localStorage，
  // 挂载后再回填只能靠 `edrv:ui-state-ready` 事件补跑（目前编辑器页签/侧栏已支持）。
  // 已知会话时这次 RPC 是本地往返（通常几十毫秒），故短超时即可；会话未就绪则不在此等待，
  // 交给镜像内部重试与迟到回填事件，避免拖慢启动。
  if (readSessionScope(ctx).sessionId) {
    try {
      await Promise.race([
        hydrateUiState(),
        new Promise<void>((resolve) => { schedule(() => resolve(), 600) }),
      ])
    } catch (error) { /* 水合失败已在镜像内降级 */ }
  }
  ctx.effect(() => () => { void flushUiState() }, 'vscode-mode: ui state flush')
  ctx.effect(() => {
    let disposed = false
    let attempts = 0
    let restore: (() => void) | null = null
    const install = (): void => {
      if (disposed || restore || attempts >= 15) return
      attempts += 1
      const service = probeSettingsDoc(ctx)
      if (service) {
        restore = patchSettingsDoc(service, async () => {
          const result = await rpc('vscode.settingsDocumentPath', {})
          return result.ok ? { ok: true, path: result.path } : { ok: false, error: result.error }
        }, openEditorView, (message) => log.warn(message))
        if (restore) return
      }
      if (attempts < 15) schedule(install, 2000)
    }
    install()
    return () => {
      disposed = true
      restore?.()
    }
  }, 'vscode-mode: settings document editor route')

  // 指令系统（命令栏 + 指令注册表）先装配：命令栏在被任何 React slot 渲染前即可唤起
  const commands = setupCommands(ctx)
  /** @private @author ddj 2026年10月12号 @param message Refresh refusal; surfaced in mounted editor status and diagnostic log. */
  const notifyReload = (message: string): void => {
    log.warn(message)
    window.dispatchEvent(new CustomEvent('edrv:reload-status', { detail: message }))
    window.alert(message)
  }
  ctx.effect(() => installPageReload(flushPageState, notifyReload), 'vscode-mode: guarded page reload')

  // 可用更新主动提醒：启动延迟 + 抖动后检查 registry，有新版本且未提醒过时 toast（失败静默）
  installUpdateNotice(ctx, schedule)

  const registry: FileOpenerRegistry = createFileOpenerRegistry()
  const workspaces = ctx.get('workspaces')
  const sessions = ctx.get('sessions')
  ctx.effect(() => installPlanBridge(ctx, schedule), 'vscode-mode: plan integration')

  // 外部深链落地：Windows 右键菜单 / Unity 外部编辑器 → 浏览器 URL 参数 → 打开规则路由
  ctx.effect(() => setupExtOpen(ctx), 'vscode-mode: external open')

  // Monaco 加载时机：不再 DSH 启动即预热，改为进入会话界面（当前会话出现）后再后台加载，
  // 用户点开「文件编辑」页签即用；空闲时仍由 EditorView 挂载兜底加载。
  // 模块级 promise 去重，重复触发只首次真正加载；requestIdleCallback 让出会话首屏带宽，缺省回退延时调度；
  // 预热失败静默吞掉（loader 失败会重置 promise，页签打开时仍走原有加载/重试路径）。
  //
  // 会话取值经 readSessionScope 收敛（跨版本三级链，见 sessionScope.ts）：
  // DSH 0.1.6-alpha.2 随多实例共存移除了 sessions.list.current，旧版则没有 uiSession；
  // 原先直读 list.getSnapshot().current 在新版恒为 undefined，会让预热/LSP 同步/编辑 Tab 恢复静默失效。
  // 会话切换 → LSP 文档归属更新 + 状态刷新（原先为两条订阅，取值源一致，此处合流为一条）。
  if (typeof window !== 'undefined') {
    const schedulePreload = () => {
      const preload = () => loadMonaco(() => {}).then((m: unknown) => setupLsp(m)).catch(() => {})
      if (typeof window.requestIdleCallback === 'function') window.requestIdleCallback(preload, { timeout: 2000 })
      else schedule(preload, 300)
    }
    let preloadedFor: string | undefined
    const onScopeChange = () => {
      const scope = readSessionScope(ctx)
      // 传 undefined = 清除绑定（保留原 LSP 同步语义：无当前会话时不残留旧归属）
      setSession(scope.sessionId)
      if (!scope.sessionId || scope.sessionId === preloadedFor) return
      preloadedFor = scope.sessionId
      schedulePreload()
    }
    ctx.effect(() => subscribeScope(ctx, onScopeChange), 'vscode-mode: monaco session trigger')
    onScopeChange()
  }
  // 会话切换 → 编辑 Tab 跨会话自动恢复：上一会话编辑区激活时，新会话自动展开并激活
  //（官方停靠面按会话隔离，新会话默认收起；先试 openTabIn 直写新会话面，未 adopt 走有界重试）。
  // 注意：首次打开某会话时通知早于会话字段落定，故通知只调度延迟任务，执行时再读最新作用域
  ctx.effect(() => {
    let lastCurrent = readSessionScope(ctx).sessionId
    const check = () => {
      const current = readSessionScope(ctx).sessionId
      if (!current || current === lastCurrent) return
      lastCurrent = current
      if (!isEditorTabActive() || officialService === undefined) return
      try { officialService.service.openTabIn?.(current, OFFICIAL_TAB_KIND, {}) } catch { /* 未 adopt 等 seat 就绪走重试 */ }
      restoreEditorTab(officialService.service, schedule)
    }
    return subscribeScope(ctx, () => schedule(check, 0))
  }, 'vscode-mode: editor tab restore')
  const originalOpenPath = workspaces?.openPath
  // 设置桥：服务不进 inject（0.1.6 settingsScope / 0.1.7 configForms 桥名互斥，写死任一
  // 都会在另一版本停等）→ compat.settingsBridge 探测 + 晚到 15×2s 有界重试，命中后重挂同步
  const bridge = settingsBridge(ctx, { schedule, attempts: 15, intervalMs: 2000 })
  let selected = autoValue('auto')
  /** 0.1.3+ 会话文件链接路由（remote.session.openWorkspacePath）是否已安装（compatSummary 展示用）。 */
  let remoteOpenInstalled = false
  /** 两条文件链接路由共用的路由日志（openPathRouter / remoteOpenRouter；统一走插件日志器）。 */
  const routeLogger = (message: string): void => log.warn(message)
  /** 两条路由共用的 FileOpenContext：当前会话 id 与工作区 cwd（跨版本取值链）。 */
  const openContext = (): FileOpenContext => readSessionScope(ctx) as FileOpenContext
  /** 可选探测 betterSidebar 服务（不进 inject：缺失会让插件停靠等待，杀死回退路径）。 */
  let sideService = detectSidebarService(ctx)
  /** 可选探测官方右侧 Sidebar（DSH 0.1.5-alpha.1+；探测命中 ≡ 版本判定，不进 inject 同上）。 */
  let officialService = detectOfficial(ctx)
  /** 官方 file 地址认领的当前注销器（null=未认领；由 syncFileClaim 依设置值切换）。 */
  let claimDisposer: (() => void) | null = null
  /** 「添加到对话」动作集：编辑区/Tab 右键菜单注入文件引用与代码块（conversation 服务缺失时各动作安全降级）。 */
  const addToConversation = createAddToConversation(ctx)

  /**
   * Build applicable client diagnostics from live installation state.
   * @private @author ddj 2026年10月13号
   * @param version Running DSH version supplied by the compat RPC.
   * @returns Applicable adapters; routing behavior is unchanged.
   */
  const compatSummary = (version = ''): CompatAdapter[] => clientSummary({
    settingsService: bridge.service(), settingsReady: bridge.scope() !== undefined,
    openPathReady: Boolean(workspaces?.openPath), remoteReady: remoteOpenInstalled,
    sidebarOpener: registry.get(SIDEBAR_PLUGIN) !== undefined,
    legacySidebar: sideService !== undefined, officialSidebar: officialService !== undefined,
    fileClaim: claimDisposer !== null, claimWanted: shouldClaimFiles(selected), selected,
  }, version)

  ctx.provide('fileOpeners', registry)
  ctx.effect(() => registry.register(vscodeOpener()), 'vscode-mode: file opener')

  // 侧边栏面板注册表（对外 provide，供本插件/第三方注册面板；文件管理为面板 #1）
  const sidebarPanels = createSidebarPanelRegistry()
  ctx.provide('edrvSidebarPanels', sidebarPanels)
  ctx.effect(() => sidebarPanels.register(createFilePanel()), 'vscode-mode: sidebar panel')
  // 搜索面板：活动栏「搜索」页签（Ctrl+Shift+F 唤起，VSCode 搜索视图形态）
  ctx.effect(() => sidebarPanels.register(createSearchPanel()), 'vscode-mode: sidebar panel search')
  // 规则面板：活动栏「规则」页签（Codebuddy 规则管理形态：用户/项目规则 + 启用开关，host 注入生效）
  ctx.effect(() => sidebarPanels.register(createRulesPanel()), 'vscode-mode: sidebar panel rules')
  // SVN 变更面板：活动栏「SVN 变更」页签（工作副本状态列表；visible 守卫使非 SVN 工作区不出现）
  ctx.effect(() => sidebarPanels.register(createSvnPanel()), 'vscode-mode: sidebar panel svn')
  // 调试面板：活动栏「调试」页签（VS Code 调试视图四段布局 + REPL；DAP 桥接）
  ctx.effect(() => sidebarPanels.register(createDebugPanel()), 'vscode-mode: sidebar panel debug')
  // 客户端（重）装配对账：host 的 DapSession 常驻，而本模块状态随刷新/HMR 归零，
  // 不对账则调试面板与暂停态 hover 静默失效（见 dapStore.resync）。
  void dapStore.resync()
  // 文件右键菜单项注册表（对外 provide，供本插件/第三方注册；内置「在文件浏览器中打开」）
  const fileMenuItems = createTreeMenuRegistry()
  ctx.provide('edrvFileContextMenuItems', fileMenuItems)
  for (const item of createDefaultFileMenuItems()) {
    ctx.effect(() => fileMenuItems.register(item), 'vscode-mode: file context menu item ' + item.id)
  }
  // 大纲源注册表（公开预留口）：第三方语言插件（LSP/VSIX 等）注册更高优先级源即可覆盖兜底
  const outlineSources = createOutlineSourceRegistry()
  ctx.provide('edrvOutlineSources', outlineSources)
  ctx.effect(() => registerBuiltinOutlineSources(outlineSources), 'vscode-mode: outline sources')
  // LSP 大纲源（priority 60）：lua/csharp 有 host 服务器时优先生效，否则自动落入 fallback
  ctx.effect(() => outlineSources.register(createLspOutlineSource()), 'vscode-mode: outline lsp source')
  ctx.effect(() => sidebarPanels.register(createOutlinePanel()), 'vscode-mode: sidebar panel outline')
  ctx.effect(() => registry.register({
    id: 'system', label: '系统默认应用', priority: 0,
    open: (path: string) => originalOpenPath.call(workspaces, path),
  }), 'vscode-mode: system file opener')
  ctx.effect(() => {
    const sidebar = scanSidebar(ctx)
    return sidebar ? registry.register(sidebar) : undefined
  }, 'vscode-mode: sidebar file opener')
  // 官方侧边栏正文组件装配（页类型正文；兼作 file 认领转发失败时的兜底正文）
  const officialRenderTab = (props: Record<string, unknown>) => React.createElement(OfficialSideTab, Object.assign({}, props, { schedule, addToConversation, sidebarPanels, outlineSources, fileMenuItems, fileOpeners: registry, sessions, readSessionScope: () => readSessionScope(ctx) }))
  /** 官方 file 地址认领同步：自动/VSCodeMode 档认领（转发进单一编辑器页签），其余交官方查看器。 */
  const syncFileClaim = (): void => {
    const official = officialService
    const want = official !== undefined && shouldClaimFiles(selected)
    if (want && claimDisposer === null && official) {
      // 认领正文只做转发：文件分页收归编辑器自带页签栏，官方侧栏不再按文件分裂编辑器实例
      const renderTab = createClaimRouter({ service: official.service, schedule, fallback: officialRenderTab })
      const disposer = registerOfficialFileClaim({ tabs: official.tabs, slots: ctx.slots, renderTab })
      if (disposer !== null) claimDisposer = ctx.effect(() => disposer, 'vscode-mode: official file claim')
      return
    }
    if (!want && claimDisposer !== null) {
      claimDisposer()
      claimDisposer = null
    }
  }
  const legacyDefaults = defaultKeybindings()
  let officialReady = false
  /**
   * 获取旧版快捷键覆盖；设置桥尚未就绪时回退默认键位。
   * @author ddj 2026年09月28号
   * @returns 旧版键位弦表
   */
  const legacyChords = (): Record<string, string> => ({
    ...legacyDefaults, ...normalizeKeybindings(bridge.scope()?.getSnapshot().value?.keybindings),
  })
  applyOfficialChords(legacyChords())
  // 设置同步（fileOpenTool / 快捷键 / 侧宽 / 页签上限）：桥可能晚于本插件 apply 就绪
  // （设置桥服务不进 inject），首次命中即挂两条 effect；晚到经 bridge.whenReady 重挂一次
  // （settingsBridge 15×2s 有界重试内命中才会触发，用尽后保持旧行为不轮询）。
  let settingsSyncMounted = false
  const mountSettingsSyncs = (): void => {
    if (settingsSyncMounted) return
    const scope = bridge.scope()
    if (!scope) return
    settingsSyncMounted = true
    ctx.effect(() => {
      const sync = (): void => {
        const snapshot = scope.getSnapshot()
        if (snapshot.status === 'loading') return
        selected = autoValue(snapshot.value?.fileOpenTool)
        syncFileClaim()
        window.dispatchEvent(new CustomEvent('edrv:file-open-tool-change', { detail: { value: selected } }))
      }
      sync()
      return scope.subscribe(sync)
    }, 'vscode-mode: file opener setting sync')
    // 界面偏好同步：侧边栏最小宽度（sidebarMinWidth）→ 派发 edrv:sidebar-min-width 通知编辑器重夹
    // 页签上限（maxOpenEditors）→ 派发 edrv:max-open-editors 通知编辑器复算淘汰
    // （快捷键配置已归官方 shortcuts 机制，目录弦表同步见 'vscode-mode: official shortcuts' effect）
    ctx.effect(() => {
      const sync = (): void => {
        const snapshot = scope.getSnapshot()
        if (snapshot.status === 'loading') return
        if (!officialReady) applyOfficialChords(legacyChords())
        const minW = sidebarMinApply(snapshot.value?.sidebarMinWidth)
        window.dispatchEvent(new CustomEvent('edrv:sidebar-min-width', { detail: { value: minW } }))
        const limit = editorLimitApply(snapshot.value?.maxOpenEditors)
        window.dispatchEvent(new CustomEvent('edrv:max-open-editors', { detail: { value: limit } }))
        // 原生打开范围同拍推送（nativeOpenStore 解析缓存；旧版无该字段 → 保持默认集）
        setNativeCsv(snapshot.value?.nativeOpenExts)
      }
      sync()
      return scope.subscribe(sync)
    }, 'vscode-mode: keybindings setting sync')
  }
  mountSettingsSyncs()
  if (!settingsSyncMounted) ctx.effect(() => bridge.whenReady(mountSettingsSyncs), 'vscode-mode: settings bridge wait')

  // 官方 shortcuts 机制装配（可选服务，有界重试；服务缺失仅降级告警，不阻断装配）：
  // ① 全部指令注册进官方目录（含无默认键位命令，官方 UI 可自定义绑定；冲突默认自动降级未绑定）；
  // ② 订阅官方目录 → 弦表同步（chordOf/bindingsOf 数据源，tooltip/命令栏提示跟随）；
  // ③ 旧 keybindings 设置一次性迁移进官方存储（幂等，与设置桥双就绪后有界重试）。
  ctx.effect(() => {
    let cancelled = false
    let disposeRegistration: (() => void) | null = null
    let disposeCatalog: (() => void) | null = null
    const disposeLegacy = installLegacyKeys(commands.registry.list(), commands.registry, legacyChords)
    const cancelProbe = awaitShortcutsService(ctx, {
      schedule,
      onReady: (service) => {
        if (cancelled) return
        if (service === null) {
          log.warn('官方 shortcuts 服务不可用（DSH 版本过旧？），继续使用旧版快捷键派发')
          return
        }
        disposeLegacy()
        officialReady = true
        disposeRegistration = registerOfficialShortcuts(service, commands.registry.list(), commands.registry, SHORTCUT_PROFILES)
        disposeCatalog = bindCatalogChords(service, applyOfficialChords)
        let attempts = 0
        const attemptMigration = (): void => {
          if (cancelled) return
          const scope = bridge.scope()
          if (!scope) {
            if (attempts < 15) {
              attempts += 1
              schedule(attemptMigration, 2000)
            }
            return
          }
          void migrateLegacyKeybindings(service, scope).then((result) => {
            if (cancelled || result.done) return
            if (attempts < 15) {
              attempts += 1
              schedule(attemptMigration, 2000)
            }
          })
        }
        attemptMigration()
      },
    })
    return () => {
      cancelled = true
      cancelProbe()
      disposeLegacy()
      disposeRegistration?.()
      disposeCatalog?.()
    }
  }, 'vscode-mode: official shortcuts')
  if (workspaces?.openPath) {
    ctx.effect(() => installOpenPathRouter({
      workspaces,
      registry,
      selected: () => selected,
      context: openContext,
      logger: routeLogger,
    }), 'vscode-mode: file link routing')
  }
  // 0.1.3+ 会话文件链接主路径：dsh-client-ui-chat 的 openFile 直接调
  // remote.session.openWorkspacePath（session/openWorkspacePath RPC），绕开
  // workspaces.openPath；该 namespace 由 api-remotes 在 loader.await 后挂载，
  // 晚于本插件 apply，且旧版 DSH 可能整段不存在——不加 inject（避免旧版停等
  // 永不激活），改为定时探测有界重试（与侧栏服务探测同款节奏）。
  let remoteRetries = 0
  const retryRemoteOpen = (): void => {
    if (remoteOpenInstalled || remoteRetries >= 15) {
      if (!remoteOpenInstalled) log.warn('未探测到 remote.session.openWorkspacePath，0.1.3+ 会话文件链接路由未安装')
      return
    }
    remoteRetries += 1
    schedule(() => {
      if (remoteOpenInstalled) return
      const service = probeRemoteOpen(ctx)
      if (!service) {
        retryRemoteOpen()
        return
      }
      const disposer = patchRemoteOpen(service, { registry, selected: () => selected, context: openContext, logger: routeLogger })
      if (!disposer) {
        log.warn('remote.session 存在但 openWorkspacePath 不可补丁，会话文件链接路由未安装')
        return
      }
      remoteOpenInstalled = true
      ctx.effect(() => disposer, 'vscode-mode: remote file link routing')
      log.info('已安装 0.1.3+ 会话文件链接路由（remote.session.openWorkspacePath）')
    }, 2000)
  }
  retryRemoteOpen()

  // 官方主题跟随（DSH 0.1.5+）：ctx.theme 快照事件优先，其次明暗标记观察（observeScheme），
  // 都不可用时 theme.ts 的 detectColorScheme 兜底；统一广播 edrv:theme-change 触发 Monaco 主题重刷。
  const themeService = ctx.get('theme') as { getTheme?: () => unknown } | undefined
  const emitTheme = (): void => {
    const snapshot = typeof themeService?.getTheme === 'function' ? themeService.getTheme() : undefined
    window.dispatchEvent(new CustomEvent('edrv:theme-change', { detail: { scheme: schemeOfSnapshot(snapshot) } }))
  }
  ctx.effect(() => {
    if (!themeService || typeof ctx.on !== 'function') return undefined
    const disposer = ctx.on('theme/change', emitTheme)
    return typeof disposer === 'function' ? disposer : undefined
  }, 'vscode-mode: official theme event')
  ctx.effect(() => observeScheme(emitTheme), 'vscode-mode: theme attribute watch')
  emitTheme()

  // 中央「文件编辑」页签（旧形态回退）：类 VSCode 编辑器；侧边栏形态（官方/better-sidebar）可用时
  // 编辑器住侧边栏 Tab，本页签不注册（避免双实例：Monaco×2 + diff dock 每会话单源抢占）。
  const registerLegacyTab = (): (() => void) | null => {
    return registerSlotSafely(ctx, {
      name: 'conversation.view',
      id: 'edrv-editor',
      order: 5,
      label: () => t('slot.fileEditor'),
      inject: (sessionId: string) => ({ sessionId }),
    }, (props: unknown) => React.createElement(EditorView, Object.assign({}, props, { layout: 'tab', sideHint: SIDEBAR_INSTALL_CMD, schedule, addToConversation, sidebarPanels, outlineSources, fileMenuItems, fileOpeners: registry, sessions })))
  }

  // 侧边栏三形态互斥切换：官方（DSH 0.1.5+）> better-sidebar（归档，仅旧版回退）> 中央页签。
  // officialDisposer / sideDisposer / legacyDisposer 任一时刻只保留其一（避免双实例 Monaco 抢占）。
  // ⚠️ 两个可选服务都可能晚于本插件就绪（better-sidebar bundle 1MB+ 后加载；官方服务旧 DSH
  // 不存在），一次性探测会误报——故启动后按 2s 间隔重试（窗口 ~30s）：每 tick 先探官方再探
  // better-sidebar；better-sidebar 先命中而官方后到时自动切换（官方优先），窗口结束仍未命中
  // 则保持中央页签回退。
  let officialDisposer: (() => void) | null = null
  let sideDisposer: (() => void) | null = null
  let legacyDisposer: (() => void) | null = null
  const installOfficialForm = (): void => {
    const official = officialService
    if (officialDisposer !== null || !official) return
    if (sideDisposer !== null) { sideDisposer(); sideDisposer = null }
    if (legacyDisposer !== null) { legacyDisposer(); legacyDisposer = null }
    const outcome = installOfficial({
      tabs: official.tabs,
      service: official.service,
      slots: ctx.slots,
      renderTab: officialRenderTab,
      title: () => t('slot.fileEditor'),
      guide: {
        title: () => t('guide.title'),
        description: () => t('guide.description'),
      },
    })
    if (outcome === null) {
      // 官方类型注册失败（API 变更等）：撤下官方标记，回退旧形态链
      officialService = undefined
      applySideForm()
      return
    }
    officialDisposer = ctx.effect(() => outcome, 'vscode-mode: official sidebar editor tab')
    // 编辑 Tab 展开/激活态按工作区落 localStorage（镜像层写穿 host，重启/换端口后仍在）：
    // 冷启动据此自动回到上次的编辑 Tab；官方 openTab 幂等，已激活时不重复调用。
    setEditorTabScope(() => {
      const scope = readSessionScope(ctx)
      return workspaceScopeOf(scope.cwd, scope.sessionId)
    })
    const restoreActiveTab = (): void => {
      const saved = readSavedTab()
      const active = isEditorTabActive()
      reportUiStateEvent('编辑 Tab 恢复：本地存档=' + String(saved) + '、当前激活=' + String(active))
      if (!active && saved) markEditorActive(true)
      restoreEditorTab(official.service, schedule)
    }
    restoreActiveTab()
    // 换 origin 时本地 localStorage 为空：镜像回填完成后重判一次，迟到的回填同样能恢复编辑 Tab
    ctx.effect(() => onUiStateReady(restoreActiveTab), 'vscode-mode: editor tab state hydration')
    // 官方打开器（下拉「官方侧边栏」选项，动态出现；openResource 能力缺失时跳过）+ 按当前设置同步 file 地址认领
    if (typeof official.service.openResource === 'function') {
      ctx.effect(() => registry.register(officialSidebarOpener(official.service)), 'vscode-mode: official sidebar opener')
      // 原生打开 handler：文件树 openFile 命中 nativeOpenExts 时经 openResource 落官方渲染器
      //（claim 的 canOpen 同步让位该范围，否则地址又被认领转发回本插件）；形态撤下时解绑
      ctx.effect(() => {
        setNativeOpenHandler((path) => {
          const scope = readSessionScope(ctx)
          if (!scope.sessionId) return false
          official.service.openResource?.(buildFileAddress(path, scope.sessionId))
          return typeof official.service.openResource === 'function'
        })
        return () => setNativeOpenHandler(null)
      }, 'vscode-mode: native open handler')
    }
    syncFileClaim()
  }
  const applySideForm = (): void => {
    if (officialService) {
      installOfficialForm()
      return
    }
    if (sideService) {
      if (sideDisposer !== null) return
      if (officialDisposer !== null) { officialDisposer(); officialDisposer = null }
      if (legacyDisposer !== null) { legacyDisposer(); legacyDisposer = null }
      sideDisposer = ctx.effect(() => installSideEditor({
        service: sideService as NonNullable<typeof sideService>,
        renderTab: (props: Record<string, unknown>) => React.createElement(SideEditorTab, Object.assign({}, props, { schedule, addToConversation, sidebarPanels, outlineSources, fileMenuItems, fileOpeners: registry, sessions })),
        activeSession: () => {
          const scope = readSessionScope(ctx)
          if (!scope.sessionId) return undefined
          return { sessionId: scope.sessionId, cwd: scope.cwd }
        },
        registerLegacyFallback: registerLegacyTab,
      }), 'vscode-mode: sidebar editor tab')
      return
    }
    if (legacyDisposer !== null) return
    if (officialDisposer !== null) { officialDisposer(); officialDisposer = null }
    if (sideDisposer !== null) { sideDisposer(); sideDisposer = null }
    setEnsureSideEditor(null)
    legacyDisposer = registerLegacyTab()
  }
  applySideForm()
  let sideRetries = 0
  const retrySideService = (): void => {
    if (officialService !== undefined || sideRetries >= 15) return
    sideRetries += 1
    schedule(() => {
      if (officialService !== undefined) return
      officialService = detectOfficial(ctx)
      if (officialService !== undefined) {
        log.info('检测到官方右侧 Sidebar（DSH 0.1.5+），切换官方侧边栏编辑形态')
        applySideForm()
        return
      }
      if (sideService === undefined) {
        sideService = detectSidebarService(ctx)
        if (sideService !== undefined) {
          log.info('检测到 ' + SIDEBAR_PLUGIN + '，切换侧边栏编辑形态（官方未探测到，后续仍优先官方）')
          applySideForm()
        }
      }
      retrySideService()
    }, 2000)
  }
  retrySideService()

  // Root row slots receive only sessionId: no sessions.scope()/activation for historical rows.
  ctx.effect(() => {
    const store = mcpSessionState()
    /** @author ddj 2026年10月20号 @param props Official root row identity. @returns Leading marker with shared polling. */
    const renderIcon = (props: unknown) => React.createElement(McpSessionIcon, { ...(props as McpRowProps), store })
    /** @author ddj 2026年10月20号 @param props Official hover identity. @returns Project-only initialization details. */
    const renderDetail = (props: unknown) => React.createElement(McpSessionDetail, { ...(props as McpRowProps), store })
    const leading = registerSlotSafely(ctx, { name: 'sidebar.session.row.leading', id: 'edrv-mcp-status', order: 20 }, renderIcon)
    const hover = registerSlotSafely(ctx, { name: 'sidebar.session.row.hover', id: 'edrv-mcp-detail', order: 20 }, renderDetail)
    return () => { leading?.(); hover?.(); store.dispose() }
  }, 'vscode-mode: session MCP status')

  // 对话输入框上方差异 dock：普通对话显示单文案按钮，文件编辑页由 EditorView 隐藏
  registerSlotSafely(ctx, {
    name: 'conversation.input.dock',
    id: 'edrv-diff-dock',
    order: 30,
    label: () => t('slot.diff'),
    inject: (sessionId: string) => ({ sessionId }),
  }, (props: unknown) => React.createElement(ConversationDiffDock, Object.assign({}, props)))

  // header 差异角标：仅当前工作区存在差异时渲染
  registerSlotSafely(ctx, { name: 'conversation.session.header.utilities', id: 'edrv-diff-badge', order: 90, label: () => t('slot.diff') },
    (props: unknown) => React.createElement(DiffBadge, Object.assign({}, props)))

  // header 会话体积指示器：当前会话持久化体积，超阈值提示新开会话（性能优化）
  registerSlotSafely(ctx, { name: 'conversation.session.header.utilities', id: 'edrv-perf-size', order: 89, label: () => t('slot.sessionSize') },
    (props: unknown) => React.createElement(PerfSizeBadge, Object.assign({}, props, { sessions })))

  // 设置页中的 VSCodeMode 专属页签，MCP 管理作为该页签的内部子 Tab。
  registerSlotSafely(ctx, {
    name: 'settings.section',
    id: 'vscode-mode',
    order: 30,
    label: () => t('slot.settings'),
  }, () => React.createElement(SettingsContext.Provider, { value: bridge.scope() }, React.createElement(McpSettings, {
    openerRegistry: registry,
    getMcpSession: () => readSessionScope(ctx).sessionId,
    compatSummary,
    // 快捷键统一走 DSH 官方配置：通用页只提供「打开官方快捷键配置」入口。
    // 服务运行时探测（自愈）：旧版 DSH 无该服务时按钮给出手动打开方式。
    getShortcuts: () => detectShortcuts(ctx),
  })))

  // 官方插件管理器详情页的只读状态段（DSH 0.2.1 新增扩展位）：非本插件页返回 null。
  // 该 slot 在旧版 DSH 不存在，slots.inject 会一直等待（不报错），故无需版本判断。
  registerSlotSafely(ctx, {
    name: 'plugins.detail.section',
    id: 'edrv-plugin-status',
    order: 40,
  }, (props: unknown) => React.createElement(PluginDetailSection, Object.assign({}, props)))

  // 卸载收尾（G4，DSH 0.1.6-alpha.2 起支持运行时卸载/重载）：
  // 注销挂在存活的 window.monaco 上的全部 Monaco provider 并复位模块状态。
  // 不做会导致重载后重复注册（补全/跳转/hover 各翻倍）与陈旧开关残留。
  ctx.effect(() => () => {
    setPanelImport()
    try { disposeSnippets() } catch { /* 卸载异常不得阻断其余清理 */ }
    try { disposeLaunchJson() } catch { /* 同上 */ }
    try { disposeAiInline() } catch { /* 同上 */ }
    try { disposeLsp() } catch { /* 同上 */ }
    // 原生打开范围复位回默认集（handler 解绑已由其自身 ctx.effect disposer 承担）
    try { resetNativeOpen() } catch { /* 同上 */ }
  }, 'vscode-mode: monaco providers teardown')

  // 会话晚到补试：冷启动早期 `sessions` 未就绪时 host 答「会话不存在」，首次水合会失败重试；
  // 作用域变化（sid→ws）后同样补一次，保证界面状态尽早回填。
  ctx.effect(() => subscribeScope(ctx, () => {
    if (!uiStateSettled()) void hydrateUiState()
  }), 'vscode-mode: ui state rehydrate')

  // 争取「回填先于界面首次读 localStorage」：宿主若 await 本 apply，此处等到水合结束（或 1.2s 超时兜底）。
  // 失败/超时不抛：镜像内部自带重试与结束事件，界面侧还有迟到回填重跑。
  try {
    await Promise.race([
      hydrateUiState(),
      new Promise<void>((resolve) => { schedule(() => resolve(), 1200) }),
    ])
  } catch (error) { /* 水合失败已在镜像内降级 */ }
  reportUiStateEvent('客户端装配完成：水合' + (uiStateSettled() ? '已结束' : '仍在进行（界面稍后重跑恢复）'))
}