// @ts-nocheck
/**
 * dsh-vscode-mode client — 侧边栏面板定义（文件管理 + 搜索 + 规则 + SVN 变更）。
 * 活动栏图标用官方 UI 原语（跟随 DSH 主题与皮肤）；原语缺失时由 SidebarView 回落文本渲染。
 * 「SVN 变更」带 visible 守卫：仅受 SVN 管理的工作区出现（非 SVN 工作区零变化）。
 * 作者 ddj 2026-08-26 / 2026-09-03 / 2026-09-10 / 2026-09-16
 */
import React from 'react'
import { IconBranchOutline16, IconFolderOpenOutline16, IconListPenOutline16, IconSearchOutline16 } from '../../ui/icons.js'
import { dapStore } from '../../dap/store.js'
import { FileExplorer } from './FileExplorer.js'
import { SearchPanel } from './SearchPanel.js'
import { LazyPanel } from '../../lazyPanel.js'
import { SvnPanel } from './SvnPanel.js'
import type { SidebarPanelDef, SidebarCtx } from '../types.js'

/**
 * 构造文件管理面板定义。
 * @author ddj 2026年08月26号 / 2026年09月10号
 * @returns 面板定义（含活动栏徽标 = 差异文件总数；图标 = 官方 IconFolderOpenOutline16）
 */
export function createFilePanel(): SidebarPanelDef {
  return {
    id: 'explorer',
    title: '文件管理',
    icon: IconFolderOpenOutline16,
    order: 10,
    badge: (ctx: SidebarCtx) => (ctx.sum && ctx.sum.totalFiles > 0 ? ctx.sum.totalFiles : null),
    render: (ctx: SidebarCtx) => React.createElement(FileExplorer, { ctx }),
  }
}

/**
 * 构造搜索面板定义。
 * @author ddj 2026年08月30号 / 2026年09月10号
 * @returns 面板定义（无徽标；图标 = 官方 IconSearchOutline16）
 */
export function createSearchPanel(): SidebarPanelDef {
  return {
    id: 'search',
    title: '搜索',
    icon: IconSearchOutline16,
    order: 15,
    render: (ctx: SidebarCtx) => React.createElement(SearchPanel, { ctx }),
  }
}

/**
 * 构造规则管理面板定义（Codebuddy 规则形态：用户规则/项目规则双 Tab + 开关）。
 * @author ddj 2026年09月03号 / 2026年09月10号
 * @returns 面板定义（无徽标；图标 = 官方 IconListPenOutline16）
 */
export function createRulesPanel(): SidebarPanelDef {
  return {
    id: 'rules',
    title: '规则',
    icon: IconListPenOutline16,
    order: 20,
    render: (ctx: SidebarCtx) => React.createElement(LazyPanel, { key: 'rules', panel: 'rules', ctx }),
  }
}

/**
 * 构造「SVN 变更」面板定义。
 * 徽标 = 过滤后仍显示的变更数（0/未加载不显示）；visible 守卫保证非 SVN 工作区
 * 既无活动栏图标也无面板（避免出现永远空的入口）。
 * @author ddj 2026年09月16号
 * @returns 面板定义（图标 = 官方 IconBranchOutline16；无原语时回落文本）
 */
export function createSvnPanel(): SidebarPanelDef {
  return {
    id: 'svn',
    title: 'SVN 变更',
    icon: typeof IconBranchOutline16 === 'function' ? IconBranchOutline16 : '⎇',
    order: 25,
    visible: (ctx: SidebarCtx) => Boolean(ctx?.svn?.managed && ctx?.svn?.svnCli),
    badge: (ctx: SidebarCtx) => {
      const entries = ctx?.svnChanges
      if (!Array.isArray(entries)) return null
      const count = svnVisibleCount(entries)
      return count > 0 ? count : null
    },
    render: (ctx: SidebarCtx) => React.createElement(SvnPanel, { ctx }),
  }
}

/**
 * 徽标计数：与面板默认过滤口径一致（显示未版本控制、隐藏忽略项）。
 * @author ddj 2026年09月16号
 * @param entries 变更清单
 * @returns 计数
 */
function svnVisibleCount(entries) {
  let count = 0
  for (const entry of entries) {
    if (entry?.status === 'ignored' || entry?.status === 'normal' || entry?.status === 'external') continue
    count += 1
  }
  return count
}

/**
 * 构造「调试」面板定义（VS Code 调试视图四段布局 + REPL）。
 * 图标用文本回落（官方原语图标集未含调试类图标时由 SidebarView 文本渲染）。
 * @author ddj 2026年09月29号
 * @returns 面板定义（徽标 = 已暂停时显示 1，吸引注意）
 */
export function createDebugPanel(): SidebarPanelDef {
  return {
    id: 'debug',
    title: '调试',
    icon: '🐞',
    order: 22,
    badge: () => (dapStore.getSnapshot().phase === 'paused' ? 1 : null),
    render: (ctx: SidebarCtx) => React.createElement(LazyPanel, { key: 'debug', panel: 'debug', ctx }),
  }
}
