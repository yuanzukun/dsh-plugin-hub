// @ts-nocheck
/**
 * dsh-vscode-mode client — 会话级差异 dock。
 * conversation.input.dock 是唯一实例：普通对话显示摘要，文件编辑页显示完整操作条。
 * 轮询已收敛到 state/recordsFeed.ts 的会话级共享订阅，本组件不再自建定时器。
 * 作者 ddj 2026-08-26
 */
import React from 'react'
import { openDiffView } from '../events.js'
import { diffSummary } from '../state/diffSummary.js'
import { subscribeReview } from '../state/reviewFeed.js'
import { subscribeRecords } from '../state/recordsFeed.js'
import { nextDiffPath } from '../diffDock.js'
import { dockInLayout, readDiffDock, subscribeDiffDock } from '../diffDockStore.js'
import { DiffBox } from './DiffBox.js'
import { CommandPalette } from './CommandPalette.js'

const nextIndexBySession = new Map()

/**
 * 对话输入框上方的唯一差异 dock。
 * @author ddj 2026年08月26号
 * @param props DSH 注入的会话属性
 * @returns 差异 dock React 元素或 null
 */
export function ConversationDiffDock(props) {
  const sessionId = props?.sessionId
  const [summary, setSummary] = React.useState(null)
  const [, setStoreRevision] = React.useState(0)

  React.useEffect(() => {
    if (!sessionId) {
      setSummary(null)
      return undefined
    }

    let records = [], page = null
    const offRecords = subscribeRecords(sessionId, (next) => { records = next; setSummary(diffSummary(records, page)) })
    const offReview = subscribeReview(sessionId, (feed) => { page = feed.page; setSummary(diffSummary(records, page)) })
    return () => { offRecords(); offReview() }
  }, [sessionId])

  React.useEffect(() => {
    if (!sessionId) return undefined
    const sync = () => setStoreRevision((value) => value + 1)
    sync()
    return subscribeDiffDock(sessionId, sync)
  }, [sessionId])

  const renderDock = (content, key) => React.createElement('div', {
    key,
    className: 'edrv-diff-dock-shell',
    'data-edrv-diff-dock-shell': '1',
  }, content)

  const editorSnapshot = readDiffDock(sessionId)
  // 命令栏浮层的兜底宿主：本 dock 是每会话常驻 slot（编辑区未挂载时仍能唤起命令栏）；
  // 与 EditorView 同时挂载时由 commandPaletteStore 的单实例认领保证只渲染一份。
  const palette = React.createElement(CommandPalette, { key: 'edrv-palette', sessionId })
  if (editorSnapshot) {
    if (!dockInLayout(editorSnapshot, 'tab')) return palette
    return React.createElement(React.Fragment, null,
      renderDock(React.createElement(DiffBox, Object.assign({}, editorSnapshot, { dock: true })), sessionId),
      palette)
  }

  if (!sessionId || !summary?.pendingFiles?.length) return palette

  const paths = summary.pendingFiles.map((file) => file.path)
  const click = () => {
    const current = nextIndexBySession.get(sessionId) ?? 0
    const next = nextDiffPath(paths, current)
    nextIndexBySession.set(sessionId, next.index)
    if (next.path) openDiffView(next.path)
  }

  return React.createElement(React.Fragment, null,
    palette,
    renderDock(React.createElement(DiffBox, {
      mode: 'chat', dock: true, fileTotal: paths.length, onOpenNextFile: click,
    }), sessionId || 'chat'))
}
