// @ts-nocheck
/**
 * dsh-vscode-mode client — 「语言服务器」设置子 Tab。
 * 四视图：服务器（状态 + 每语言启用/命令/路径）｜已安装（卸载/更新）｜市场（Open VSX 搜索/安装 + 本地 vsix）｜更新。
 * 状态经 edrv.lsp.detect（检测结果驱动卡片动态显示），配置经 edrv.lsp.configGet/Update，扩展经 edrv.lsp.ext.*。
 * 作者 ddj 2026-08-27 / 2026-09-03
 */
import React from 'react'
import { rpc } from '../rpc.js'
import '../styles/mcp.css'

/** 支持语言的展示元数据（卡片显示由检测结果驱动；未知 id 走 langMeta 兜底）。 */
const LANG_META = {
  lua: { label: 'Lua（EmmyLua / LuaLS）', hint: '优先使用已安装 EmmyLua；未安装时回退 LuaLS 或 PATH 中的 lua-language-server' },
  csharp: { label: 'C#（Roslyn / DotRush / OmniSharp）', hint: '优先自动发现 ms-dotnettools.csharp / DotRush 扩展（DotRush 需 .NET 10 运行时）；也可手动指定' },
}

/** 语言展示元数据（含未知 id 兜底）。 */
function langMeta(id) {
  return LANG_META[id] || { label: id + '（语言服务器）', hint: '' }
}

/** 该语言是否已存配置（禁用开关或手动命令/路径）。 */
function hasStoredConfig(cfg) {
  if (!cfg || typeof cfg !== 'object') return false
  if (cfg.enabled === false) return true
  return Boolean((cfg.command && cfg.command.trim()) || (cfg.path && cfg.path.trim()))
}

/** 该语言是否显示卡片：检测到可用 LSP、已存配置、或存在待安装的缺失环境。 */
function langVisible(status, config) {
  if (!status) return false
  if (status.source && status.source !== 'none') return true
  if (hasStoredConfig(config[status.languageId])) return true
  return Array.isArray(status.missingEnv) && status.missingEnv.length > 0
}

const PHASE_LABEL = {
  idle: '未启动', starting: '启动中', ready: '就绪', indexing: '索引中', unavailable: '不可用', stopped: '已停止',
}
const SOURCE_LABEL = { extension: '扩展', discover: '自动发现', manual: '手动配置', none: '未配置' }
const TABS = [
  { id: 'servers', label: '服务器' },
  { id: 'installed', label: '已安装' },
  { id: 'market', label: '市场' },
  { id: 'updates', label: '更新' },
]

/** 环境安装按钮文案（按安装进行态）。 */
function envButtonLabel(req, envStates) {
  const state = (envStates ?? []).find((s) => s.id === req.id)
  if (state?.phase === 'downloading') return '下载中…'
  if (state?.phase === 'extracting') return '安装中…'
  if (state?.phase === 'done') return '已完成'
  if (state?.phase === 'failed') return '重试'
  return '一键安装'
}

/** 语言卡片：状态 + 缺失环境提示（一键安装/官网下载） + 启用开关 + 命令/路径配置 + 重新检测。 */
function LangCard({ lang, config, status, busy, envStates, onInstallEnv, onToggle, onSave, onRedetect }) {
  const [pathDraft, setPathDraft] = React.useState(config?.path ?? '')
  const [commandDraft, setCommandDraft] = React.useState(config?.command ?? '')
  React.useEffect(() => { setPathDraft(config?.path ?? ''); setCommandDraft(config?.command ?? '') }, [config?.path, config?.command])
  const phase = status?.phase ?? 'idle'
  return React.createElement('article', { className: 'vsm-mcp-card' },
    React.createElement('div', { className: 'vsm-mcp-card-head' },
      React.createElement('div', { className: 'vsm-mcp-title' },
        React.createElement('span', { className: 'vsm-mcp-dot ' + (phase === 'ready' || phase === 'indexing' ? 'connected' : phase === 'unavailable' ? 'error' : 'disabled') }),
        lang.label),
      React.createElement('div', { className: 'vsm-mcp-actions' },
        React.createElement('button', { className: 'vsm-switch ' + (config?.enabled !== false ? 'on' : ''), onClick: () => onToggle(lang.id, config?.enabled !== false ? false : true), 'aria-label': '启用/禁用' }, config?.enabled !== false ? '●' : '○'))),
    React.createElement('div', { className: 'vsm-mcp-meta' },
      PHASE_LABEL[phase] ?? phase, ' · ', SOURCE_LABEL[status?.source] ?? status?.source,
      status?.providerName ? ' · ' + status.providerName : '',
      status?.version ? ' · v' + status.version : '',
      (phase === 'ready' && status?.root) ? ' · ' + String(status.root).split(/[\\/]/).pop() : ''),
    status?.reason ? React.createElement('div', { className: 'vsm-mcp-error' }, status.reason) : null,
    Array.isArray(status?.candidates) && status.candidates.length > 1
      ? React.createElement('div', { className: 'vsm-lsp-hint' },
        '候选（' + status.candidates.length + '）：' + status.candidates.map((c) =>
          c.name + (c.version ? ' v' + c.version : '') + (c.chosen ? '（当前）' : '')).join(' · '))
      : null,
    Array.isArray(status?.missingEnv) && status.missingEnv.length
      ? React.createElement('div', { className: 'vsm-lsp-hint' },
        '缺少运行环境（一键安装后自动生效）：',
        status.missingEnv.map((req) => React.createElement('div', { key: req.id, className: 'vsm-mcp-actions' },
          React.createElement('span', null, req.label, req.detail ? '（' + req.detail + '）' : ''),
          req.installable ? React.createElement('button', {
            className: 'vsm-primary vsm-small',
            disabled: busy === 'env:' + req.id,
            onClick: () => onInstallEnv(lang.id, req),
          }, envButtonLabel(req, envStates)) : null,
          req.manualUrl ? React.createElement('a', {
            href: req.manualUrl, target: '_blank', rel: 'noreferrer',
            style: { color: 'inherit', textDecoration: 'underline', alignSelf: 'center' },
          }, req.manualLabel ?? '官网下载') : null)))
      : null,
    React.createElement('div', { className: 'vsm-lsp-form' },
      React.createElement('label', null, React.createElement('span', null, '可执行文件路径（绝对路径，优先）'), React.createElement('input', { value: pathDraft, placeholder: '如 C:/.../lua-language-server.exe', onChange: (e) => setPathDraft(e.target.value) })),
      React.createElement('label', null, React.createElement('span', null, '命令名（PATH 内查找）'), React.createElement('input', { value: commandDraft, placeholder: '如 lua-language-server', onChange: (e) => setCommandDraft(e.target.value) })),
      React.createElement('button', { className: 'vsm-primary', disabled: busy === lang.id, onClick: () => onSave(lang.id, pathDraft, commandDraft) }, busy === lang.id ? '保存中…' : '保存配置'),
      React.createElement('button', { className: 'vsm-primary vsm-small', disabled: busy === lang.id, onClick: () => onRedetect(lang.id), title: '清缓存并重新选择语言服务器（EmmyLua / LuaLS）' }, busy === lang.id ? '检测中…' : '重新检测')),
    React.createElement('div', { className: 'vsm-lsp-hint' }, lang.hint))
}

/** 已装扩展卡片：清单 + 卸载/更新。 */
function InstalledCard({ ext, busy, onUninstall, onUpdate }) {
  return React.createElement('article', { className: 'vsm-mcp-card' },
    React.createElement('div', { className: 'vsm-mcp-card-head' },
      React.createElement('div', { className: 'vsm-mcp-title' },
        React.createElement('span', { className: 'vsm-mcp-dot connected' }),
        React.createElement('span', null, ext.displayName || ext.name),
        React.createElement('span', { className: 'vsm-ext-ver' }, ext.id + ' · v' + ext.version)),
      React.createElement('div', { className: 'vsm-mcp-actions' },
        React.createElement('button', { className: 'vsm-primary vsm-small', disabled: busy === ext.id, onClick: () => onUpdate(ext) }, '更新'),
        React.createElement('button', { className: 'vsm-danger vsm-small', disabled: busy === ext.id, onClick: () => onUninstall(ext) }, '卸载'))),
    ext.description ? React.createElement('div', { className: 'vsm-lsp-hint' }, ext.description) : null)
}

/** 市场条目卡片：安装/已装态。 */
function MarketCard({ item, installed, busy, onInstall }) {
  const has = installed.some((e) => e.id === item.id)
  return React.createElement('article', { className: 'vsm-mcp-card' },
    React.createElement('div', { className: 'vsm-mcp-card-head' },
      React.createElement('div', { className: 'vsm-mcp-title' },
        React.createElement('span', { className: 'vsm-mcp-dot ' + (has ? 'connected' : 'disabled') }),
        React.createElement('span', null, item.displayName || item.name),
        React.createElement('span', { className: 'vsm-ext-ver' }, item.id + ' · v' + item.version)),
      React.createElement('div', { className: 'vsm-mcp-actions' },
        React.createElement('button', { className: 'vsm-primary vsm-small', disabled: has || busy === item.id, onClick: () => onInstall(item) }, has ? '已安装' : '安装'))),
    item.description ? React.createElement('div', { className: 'vsm-lsp-hint' }, item.description) : null)
}

/**
 * 语言服务器设置页：服务器状态/配置 + VSIX 扩展（安装/更新/卸载三视图）。
 * @author ddj 2026年08月27号
 */
export function LspSettings() {
  const [tab, setTab] = React.useState('servers')
  const [config, setConfig] = React.useState({})
  const [servers, setServers] = React.useState([])
  const [installed, setInstalled] = React.useState([])
  const [updates, setUpdates] = React.useState([])
  const [market, setMarket] = React.useState([])
  const [query, setQuery] = React.useState('')
  const [vsixPath, setVsixPath] = React.useState('')
  const [busy, setBusy] = React.useState('')
  const [error, setError] = React.useState('')
  const [loading, setLoading] = React.useState(true)
  const [envStates, setEnvStates] = React.useState([])
  const [envLang, setEnvLang] = React.useState('')

  const refreshServers = React.useCallback(() => {
    Promise.all([rpc('edrv.lsp.configGet', {}), rpc('edrv.lsp.detect', {})])
      .then(([cfg, det]) => {
        if (cfg?.ok) setConfig(cfg.config ?? {})
        if (det?.ok) setServers(det.servers ?? [])
        setError('')
      })
      .catch((e) => setError(String(e)))
  }, [])

  const refreshExt = React.useCallback(() => {
    Promise.all([rpc('edrv.lsp.ext.list', {}), rpc('edrv.lsp.ext.updates', {})])
      .then(([l, u]) => {
        if (l?.ok) setInstalled(l.extensions ?? [])
        if (u?.ok) setUpdates(u.updates ?? [])
        setError('')
      })
      .catch((e) => setError(String(e)))
  }, [])

  const refreshEnvStates = React.useCallback(() => {
    return rpc('edrv.lsp.envState', {})
      .then((res) => {
        if (res?.ok) setEnvStates(res.states ?? [])
        return res?.states ?? []
      })
      .catch(() => [])
  }, [])

  const refresh = React.useCallback(() => {
    setLoading(true)
    Promise.all([refreshServers(), refreshExt()]).finally(() => setLoading(false))
  }, [refreshServers, refreshExt])

  React.useEffect(() => { refresh() }, [refresh])

  const switchTab = (next) => {
    setTab(next)
    setError('')
    if (next === 'market' && !query) setQuery('lua language server')
    if (next === 'installed' || next === 'updates') void refreshExt()
    if (next === 'servers') void refreshServers()
  }

  /** 合并 redetect/configUpdate 返回的服务器状态：只替换该语言条目。 */
  const mergeServers = (languageId, list) => {
    setServers((prev) => Array.isArray(list)
      ? [...prev.filter((s) => s.languageId !== languageId), ...list]
      : prev)
  }

  /** 重检测后通知编辑器：与 host 重新同步已打开的模型（触发重新 acquire）。 */
  const notifyResync = React.useCallback((languageId) => {
    window.dispatchEvent(new CustomEvent('edrv:lsp-redetect', { detail: { languageId } }))
  }, [])

  /** 一键安装缺失环境：启动内置安装器（成功后进入轮询，完成自动重同步）。 */
  const installEnv = (languageId, req) => {
    const key = 'env:' + req.id
    setBusy(key)
    setError('')
    setEnvLang(languageId)
    rpc('edrv.lsp.envInstall', { languageId, id: req.id })
      .then((res) => {
        if (!res?.ok) { setError(res?.error ?? '无法启动安装'); return }
        void refreshEnvStates()
        void refreshServers()
      })
      .catch((e) => setError(String(e)))
      .finally(() => setBusy(''))
  }

  // 环境安装进行中：2s 轮询进度并刷新状态；某项转入 done 时由下方过渡检测重同步
  React.useEffect(() => {
    const states = envStates ?? []
    const installing = states.some((s) => s.phase === 'downloading' || s.phase === 'extracting')
    if (!installing) return
    const timer = setInterval(() => {
      void refreshEnvStates()
      void refreshServers()
    }, 2000)
    return () => clearInterval(timer)
  }, [envStates, refreshEnvStates, refreshServers])

  // 环境安装完成过渡检测：刷新状态并通知编辑器重新同步对应语言
  const prevEnvPhases = React.useRef({})
  React.useEffect(() => {
    const states = envStates ?? []
    for (const s of states) {
      const prev = prevEnvPhases.current[s.id]
      if (prev && prev !== 'done' && s.phase === 'done' && envLang) {
        void refreshServers()
        notifyResync(envLang)
      }
      prevEnvPhases.current[s.id] = s.phase
    }
  }, [envStates, envLang, refreshServers, notifyResync])

  const saveLang = (languageId, path, command) => {
    setBusy(languageId)
    setError('')
    rpc('edrv.lsp.configUpdate', { languageId, path, command })
      .then((res) => {
        if (!res?.ok) { setError(res?.error ?? '保存失败'); return }
        setConfig(res.config ?? {})
        mergeServers(languageId, res.servers)
        notifyResync(languageId) // 保存后自动重新检测 + 同步模型
      })
      .catch((e) => setError(String(e)))
      .finally(() => setBusy(''))
  }

  const toggleLang = (languageId, enabled) => {
    setBusy(languageId)
    rpc('edrv.lsp.configUpdate', { languageId, enabled })
      .then((res) => {
        if (!res?.ok) { setError(res?.error ?? '切换失败'); return }
        setConfig(res.config ?? {})
        mergeServers(languageId, res.servers)
        notifyResync(languageId) // 切换启用状态后自动重新检测 + 同步模型
      })
      .catch((e) => setError(String(e)))
      .finally(() => setBusy(''))
  }

  const redetectLang = (languageId) => {
    setBusy(languageId)
    setError('')
    rpc('edrv.lsp.redetect', { languageId })
      .then((res) => {
        if (!res?.ok) { setError(res?.error ?? '重新检测失败'); return }
        mergeServers(languageId, res.servers)
        notifyResync(languageId)
      })
      .catch((e) => setError(String(e)))
      .finally(() => setBusy(''))
  }

  const searchMarket = () => {
    if (!query.trim()) return
    setBusy('__market')
    setError('')
    rpc('edrv.lsp.ext.market', { query: query.trim(), size: 12 })
      .then((res) => {
        if (res?.ok) setMarket(res.extensions ?? [])
        else setError(res?.error ?? '搜索失败')
      })
      .catch((e) => setError(String(e)))
      .finally(() => setBusy(''))
  }

  const installMarket = (item) => {
    setBusy(item.id)
    setError('')
    rpc('edrv.lsp.ext.install', { namespace: item.namespace, name: item.name })
      .then((res) => {
        if (!res?.ok) { setError(res?.error ?? '安装失败'); return }
        void refreshExt()
        void refreshServers() // 新装 LSP 使对应语言卡片出现
      })
      .catch((e) => setError(String(e)))
      .finally(() => setBusy(''))
  }

  const installLocal = () => {
    if (!vsixPath.trim()) return
    setBusy('__vsix')
    setError('')
    rpc('edrv.lsp.ext.install', { vsixPath: vsixPath.trim() })
      .then((res) => {
        if (!res?.ok) { setError(res?.error ?? '安装失败'); return }
        setVsixPath('')
        void refreshExt()
        void refreshServers() // 新装 LSP 使对应语言卡片出现
      })
      .catch((e) => setError(String(e)))
      .finally(() => setBusy(''))
  }

  const uninstallExt = (ext) => {
    if (!window.confirm('卸载扩展 ' + ext.id + '？')) return
    setBusy(ext.id)
    setError('')
    rpc('edrv.lsp.ext.uninstall', { id: ext.id })
      .then((res) => {
        if (!res?.ok) setError(res?.error ?? '卸载失败')
        void refreshExt()
        void refreshServers() // 卸载后对应语言卡片按最新检测隐匿
      })
      .catch((e) => setError(String(e)))
      .finally(() => setBusy(''))
  }

  const updateExt = (ext) => {
    setBusy(ext.id)
    setError('')
    rpc('edrv.lsp.ext.update', { id: ext.id })
      .then((res) => {
        if (!res?.ok) setError(res?.error ?? '更新失败')
        void refreshExt()
        void refreshServers() // 更新后选用版本随之变化
      })
      .catch((e) => setError(String(e)))
      .finally(() => setBusy(''))
  }

  if (loading) return React.createElement('div', { className: 'vsm-mcp-empty' }, '正在读取语言服务器状态…')
  const nav = React.createElement('nav', { className: 'vsm-mcp-tabs' },
    TABS.map((t) => React.createElement('button', { key: t.id, className: tab === t.id ? 'active' : '', onClick: () => switchTab(t.id) }, t.label)))
  const header = React.createElement('div', { className: 'vsm-mcp-header' },
    React.createElement('div', null,
      React.createElement('h2', null, '语言服务器（LSP）'),
      React.createElement('p', null, '代码索引 / 引用查找 / 动态跳转；可安装 VSIX 语言服务器扩展（Open VSX 市场 / 本地 .vsix）。')),
    React.createElement('button', { className: 'vsm-primary', onClick: refresh }, '↻ 刷新'))
  const banner = error ? React.createElement('div', { className: 'vsm-mcp-error vsm-mcp-banner' }, error) : null

  /** 线框面板容器：标题 + 内容体。 */
  const panel = (title, children) => React.createElement('section', { className: 'vsm-panel' },
    React.createElement('h3', { className: 'vsm-panel-title' }, title),
    React.createElement('div', { className: 'vsm-panel-body' }, children),
  )

  let body = null
  if (tab === 'servers') {
    // 动态显示：检测结果（detect 全量）驱动卡片可见性；未检出语言灰字列出
    const detected = Array.isArray(servers) ? servers : []
    const visible = detected.filter((s) => langVisible(s, config))
    const hidden = detected.filter((s) => !visible.includes(s))
    body = panel('语言服务器', React.createElement(React.Fragment, null,
      visible.length ? visible.map((status) => {
        const meta = langMeta(status.languageId)
        return React.createElement(LangCard, {
          key: status.languageId, lang: { id: status.languageId, label: meta.label, hint: meta.hint },
          config: config[status.languageId] ?? {},
          status,
          busy, envStates, onInstallEnv: installEnv, onToggle: toggleLang, onSave: saveLang, onRedetect: redetectLang,
        })
      }) : React.createElement('div', { className: 'vsm-mcp-empty' },
        '未检测到已安装的语言服务器；可切换到「市场」搜索安装（如 sumneko.lua），或安装本地 .vsix 后刷新。'),
      hidden.length ? React.createElement('div', { className: 'vsm-lsp-hint' },
        '未检测到：' + hidden.map((s) => langMeta(s.languageId).label).join('、') + ' —— 可在「市场」安装后刷新。') : null,
      React.createElement('div', { className: 'vsm-lsp-hint' }, '提示：打开对应语言的文件即自动（惰性）启动语言服务器；未配置时编辑器功能不受影响，大纲回退内置解析。')))
  } else if (tab === 'installed') {
    body = panel('已安装扩展', React.createElement(React.Fragment, null,
      React.createElement('div', { className: 'vsm-lsp-hint' }, '已安装的语言服务器扩展（存于 ~/.dsh/dsh-vscode-mode/extensions/）。语言服务器被自动发现为「扩展」源。'),
      installed.length ? installed.map((ext) => React.createElement(InstalledCard, { key: ext.id, ext, busy, onUninstall: uninstallExt, onUpdate: updateExt }))
        : React.createElement('div', { className: 'vsm-mcp-empty' }, '还没有安装扩展（去「市场」或指定本地 .vsix）')))
  } else if (tab === 'market') {
    body = panel('扩展市场', React.createElement(React.Fragment, null,
      React.createElement('div', { className: 'vsm-lsp-form' },
        React.createElement('label', null, React.createElement('span', null, '搜索 Open VSX 市场'), React.createElement('input', { value: query, placeholder: '如 sumneko.lua / lua language server', onChange: (e) => setQuery(e.target.value), onKeyDown: (e) => { if (e.key === 'Enter') searchMarket() } })),
        React.createElement('button', { className: 'vsm-primary', disabled: busy === '__market', onClick: searchMarket }, busy === '__market' ? '搜索中…' : '搜索')),
      React.createElement('div', { className: 'vsm-lsp-form' },
        React.createElement('label', null, React.createElement('span', null, '安装本地 .vsix 文件（服务器绝对路径）'), React.createElement('input', { value: vsixPath, placeholder: '如 C:/Downloads/sumneko.lua-3.19.1.vsix', onChange: (e) => setVsixPath(e.target.value) })),
        React.createElement('button', { className: 'vsm-primary', disabled: busy === '__vsix', onClick: installLocal }, busy === '__vsix' ? '安装中…' : '安装本地 .vsix')),
      React.createElement('div', { className: 'vsm-lsp-hint' }, '市场安装会下载并解包 VSIX 到扩展目录；含语言服务器（如 sumneko.lua）的扩展会被自动发现。'),
      market.map((item) => React.createElement(MarketCard, { key: item.id, item, installed, busy, onInstall: installMarket }))))
  } else {
    body = panel('可用更新', React.createElement(React.Fragment, null,
      React.createElement('div', { className: 'vsm-lsp-hint' }, '已装扩展与 Open VSX 最新版的差异。'),
      updates.length ? updates.map((u) => React.createElement('article', { key: u.id, className: 'vsm-mcp-card' },
        React.createElement('div', { className: 'vsm-mcp-card-head' },
          React.createElement('div', { className: 'vsm-mcp-title' },
            React.createElement('span', { className: 'vsm-mcp-dot error' }),
            React.createElement('span', null, u.displayName || u.id),
            React.createElement('span', { className: 'vsm-ext-ver' }, 'v' + u.current + ' → v' + u.latest)),
          React.createElement('div', { className: 'vsm-mcp-actions' },
            React.createElement('button', { className: 'vsm-primary vsm-small', disabled: busy === u.id, onClick: () => updateExt(u) }, busy === u.id ? '更新中…' : '更新')))))
        : React.createElement('div', { className: 'vsm-mcp-empty' }, '全部已是最新')))
  }
  return React.createElement('div', null, header, nav, banner, body)
}
