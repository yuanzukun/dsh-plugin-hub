# dsh-plugin-finder

在会话内搜索 GitHub 上的社区 DeepSeek Harness (DSH) 插件，按 star 排序，每个结果带一键安装命令。

> 灵感来自 OpenClaw / Claude Code 时代的 skills.sh 与 `npx skill`：让 agent 自己发现生态插件，而不是靠人肉翻列表。

## 功能

- `search_dsh_plugins`：实时搜索 GitHub 公开 `dsh-plugin` topic（约 1000+ 仓库），**排除官方 deepseek-ai 组织**
  - 按 star 排序，返回：插件名、star 数、最近更新时间、简介、issue 数
  - 每个结果附带可直接执行的安装命令：`dsh plugin --profile web add github:<owner>/<repo>`
- `audit_dsh_plugin`：安装前审查仓库
  - 下载源码到工作区沙盒 `<workspace>/.dsh-plugin-cache/<owner>__<name>/`（限 50MB；缓存 24h，可传 `refresh: true` 强制重下）
  - 解压后体积守卫：超过 200MB 自动清理并报错（防压缩炸弹）
  - 检测 `dsh.bundle` 安装清单与 `cordis.patch.yml`
  - 扫描 7 类危险模式：进程执行 / 动态执行 / 密钥与环境变量 / 文件写入删除 / 网络访问 / 危险命令 / 动态导入
  - 输出入口源码摘录 + "试用 → 转正式" 安装计划（含回滚步骤）
- 结果内存缓存 5 分钟，减少匿名 GitHub API 限流压力
- 纯只读：不安装、不修改任何插件或配置

## 安装

```sh
dsh plugin --profile web add github:meme-dog/dsh-plugin-finder
```

安装后**重启 dsh web** 生效。重启后直接对 agent 说：

- "找找有没有微信通知插件"
- "有什么 TUI 插件？"
- "审查一下 <owner>/<repo> 这个插件再装"

agent 会自动调用 `search_dsh_plugins` / `audit_dsh_plugin` 工具。

## 用法（作为动态插件试跑）

在会话内通过 cordis_define / cordis_run 注册，重启后失效；适合先体验。

## 工作原理

| 层 | 说明 |
|---|---|
| 数据源 | GitHub Search API `q=topic:dsh-plugin -org:deepseek-ai <keywords>&sort=stars` |
| 传输 | `ctx.shell` + curl（本部署禁用 fetch provider 以防御 SSRF；curl 走与 bash 工具相同的沙箱/审批链路） |
| 缓存 | 按 `(query, limit)` 内存缓存 5 分钟 |
| 插件形态 | 标准 out-of-tree bundle：`package.json` 声明 `dsh.bundle.patch`，`cordis.patch.yml` 插入一行 |

## 安全

- 工具只做**只读 GET** 请求，不执行任何安装动作
- 返回的安装命令需要你/agent 显式执行；安装第三方插件前请审阅源码
- 沙箱拒绝网络请求时会明确报错，不会静默降级

## 后续可扩展

- [ ] 合并 awesome-dsh-plugin 精选列表的中文简介（数据文件就绪后）
- [ ] `--verify` 冒烟测试：检查目标仓库是否声明 `dsh.bundle` manifest
- [ ] 按类别过滤（TUI / 记忆 / 通知 / 整活…）
- [ ] 检查插件 npm 是否已发布，优先给 npm 安装命令

## License

MIT
