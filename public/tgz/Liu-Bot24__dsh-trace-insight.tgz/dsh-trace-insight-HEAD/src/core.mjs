/**
 * Deterministic, read-only analysis of a DeepSeek Harness trajectory snapshot.
 * This module deliberately has no browser or Harness dependency so its rules
 * can be unit-tested and reused by the client view.
 */

export const ANALYZER_VERSION = '0.3.4'

const ERROR_PATTERNS = [
  ['FS_NOT_FOUND', /\b(?:FS_NOT_FOUND|ENOENT|file not found|path not found|no such file|找不到(?:文件|路径)|路径不存在|文件不存在)\b/i],
  ['COMMAND_NOT_FOUND', /\b(?:command not found|not recognized as an internal|不是内部或外部命令|找不到命令)\b/i],
  ['TOOL_UNAVAILABLE', /\b(?:tool unavailable|no (?:available )?(?:terminal|shell|bash|powershell|git|network|fetch) tool|没有可用的?(?:终端|工具|Git|网络)|工具不可用|not available in this environment)\b/i],
  ['PLATFORM_UNSUPPORTED', /\b(?:unsupported on (?:this )?platform|platform .* unsupported|(?:win32|Windows).*(?:不支持|unsupported)|(?:不支持|unsupported).*(?:win32|Windows)|terminal inspection is unsupported)\b/i],
  ['PERMISSION_DENIED', /\b(?:EACCES|EPERM|permission denied|access denied|没有权限|拒绝访问)\b/i],
  ['TIMEOUT', /\b(?:ETIMEDOUT|timeout|timed out|超时)\b/i],
  ['NETWORK_ERROR', /\b(?:ECONNREFUSED|ENETUNREACH|network error|fetch failed|connection refused|网络错误|连接失败)\b/i],
  ['INVALID_ARGUMENT', /\b(?:invalid argument|invalid parameter|schema validation|参数无效|参数错误)\b/i],
  ['RATE_LIMITED', /\b(?:rate limit|too many requests|429|限流|请求过多)\b/i],
  ['AUTH_FAILED', /\b(?:unauthorized|forbidden|401|403|authentication failed|鉴权失败|未授权)\b/i],
]

const SUCCESS_PATTERNS = /\b(?:created successfully|updated successfully|completed successfully|tests? passed|build succeeded|success|已创建|创建成功|已更新|更新成功|测试通过|构建成功|完成)\b/i
const COMPLETION_CUES = /(?:已完成|已经完成|完成了|成功完成|已经做好|已经做完|已生成|已创建|done|completed|finished|successfully)/i
const BLOCKED_CUES = /(?:无法(?:访问|读取|继续|执行|获取|完成|连接|调用)|不能(?:继续|完成|访问|读取|执行)|没有可用(?:工具|终端|权限|输入|仓库|文件)|需要你|请(?:提供|上传|克隆|给出)|访问不到|不可访问|blocked|cannot(?:\s+(?:proceed|continue|access|read|complete|run))?|can['’]?t\s+(?:proceed|continue|access|read|complete|run)|need you|please (?:provide|upload|clone)|unavailable)/i
const UNCERTAINTY_CUES = /(?:可能|似乎|看起来|尚未验证|无法确认|需要验证|maybe|likely|appears|unverified)/i

const LOCAL_FILE_TOOL = /(?:str_replace_editor|file(?:system)?|workspace|editor|read_file|write_file|apply_patch|patch|fs[_-]|directory|glob|grep)/i
const NETWORK_TOOL = /(?:web(?:_search|_fetch)?|http|fetch|curl|browser|github|git(?:_|$)|download|request|url)/i
const SHELL_TOOL = /(?:bash|shell|powershell|pwsh|terminal|exec|command|cmd)/i
const VERIFY_TOOL = /(?:test|lint|typecheck|build|pytest|vitest|jest|npm|pnpm|compile|check)/i
const MUTATION_TOOL = /(?:write|edit|replace|patch|create|delete|move|rename|mkdir|apply_patch|str_replace_editor)/i

const PATH_KEY = /^(?:path|file|filename|directory|dir|cwd|root|workspace|target|source|destination|output)$/i
const URL_KEY = /^(?:url|uri|href|endpoint|remote)$/i

function asArray(value) {
  return Array.isArray(value) ? value : []
}

function safeString(value) {
  if (typeof value === 'string') return value
  if (value === null || value === undefined) return ''
  if (typeof value === 'number' || typeof value === 'boolean') return String(value)
  try {
    return JSON.stringify(value)
  } catch {
    return String(value)
  }
}

function compactWhitespace(value) {
  return safeString(value).replace(/\s+/g, ' ').trim()
}

export function excerpt(value, limit = 220) {
  const text = compactWhitespace(value)
  if (text.length <= limit) return text
  return `${text.slice(0, Math.max(0, limit - 1))}…`
}

export function contentText(content) {
  if (typeof content === 'string') return content
  if (!Array.isArray(content)) return compactWhitespace(content)
  const chunks = []
  for (const block of content) {
    if (typeof block === 'string') {
      chunks.push(block)
      continue
    }
    if (!block || typeof block !== 'object') continue
    if (typeof block.text === 'string') chunks.push(block.text)
    else if (typeof block.content === 'string') chunks.push(block.content)
    else if (typeof block.value === 'string') chunks.push(block.value)
    else if (block.type !== 'image') chunks.push(safeString(block))
  }
  return chunks.join('\n')
}

export function assistantText(node) {
  const chunks = []
  for (const block of asArray(node?.blocks)) {
    if (block?.kind === 'text' || block?.kind === 'reasoning') chunks.push(safeString(block.text))
  }
  return chunks.join('\n').trim()
}

function parseArgs(raw) {
  if (raw && typeof raw === 'object') return raw
  const text = safeString(raw).trim()
  if (!text) return null
  try {
    return JSON.parse(text)
  } catch {
    return null
  }
}

function collectKeyedStrings(value, pathOutput, urlOutput, resourceUrlOutput, depth = 0) {
  if (depth > 8 || value === null || value === undefined) return
  if (Array.isArray(value)) {
    for (const item of value) collectKeyedStrings(item, pathOutput, urlOutput, resourceUrlOutput, depth + 1)
    return
  }
  if (typeof value !== 'object') return
  for (const [key, child] of Object.entries(value)) {
    if (typeof child === 'string') {
      const isUrl = /^https?:\/\//i.test(child)
      if (PATH_KEY.test(key)) pathOutput.push(child)
      if (URL_KEY.test(key) || isUrl) urlOutput.push(child)
      // Only URLs placed in resource-address fields are evidence that a local
      // file tool received a remote resource. URLs inside patch text, file
      // contents, or search queries are ordinary data and must not trigger the
      // tool-semantics finding.
      if (isUrl && (PATH_KEY.test(key) || URL_KEY.test(key))) resourceUrlOutput.push(child)
    } else {
      collectKeyedStrings(child, pathOutput, urlOutput, resourceUrlOutput, depth + 1)
    }
  }
}

function cleanCandidate(value) {
  let cleaned = safeString(value)
    .trim()
    .replace(/^["'`]+|["'`,;)}\]]+$/g, '')
  // A path found in raw JSON contains escaped backslashes, while the parsed
  // object contains their decoded form. Canonicalize drive-letter paths so
  // the two evidence channels deduplicate cleanly.
  if (/^[A-Za-z]:\\/.test(cleaned)) {
    while (cleaned.includes('\\\\')) cleaned = cleaned.replace(/\\\\/g, '\\')
  }
  return cleaned
}

function extractResourceReferences(argsRaw) {
  const paths = []
  const urls = []
  const resourceUrls = []
  const parsed = parseArgs(argsRaw)
  if (parsed !== null) collectKeyedStrings(parsed, paths, urls, resourceUrls)
  const raw = safeString(argsRaw)

  const urlMatches = raw.match(/https?:\/\/[^\s"'`,}\]]+/gi) ?? []
  urls.push(...urlMatches)

  // Windows absolute paths and POSIX-looking absolute paths. The POSIX arm is
  // intentionally conservative to avoid classifying JSON separators as paths.
  const windowsMatches = raw.match(/[A-Za-z]:\\(?:[^\s"'`,}\]]|\\ )+/g) ?? []
  paths.push(...windowsMatches)
  const posixMatches = raw.match(/(?:^|["'\s:])(\/(?:[^\s"'`,}\]]+\/)*[^\s"'`,}\]]+)/g) ?? []
  for (const match of posixMatches) {
    const candidate = match.trim().replace(/^["':]+/, '')
    if (candidate.length > 1 && !candidate.startsWith('//')) paths.push(candidate)
  }

  const normalizedUrls = [...new Set(urls.map(cleanCandidate).filter(value => /^https?:\/\//i.test(value)))]
  const normalizedResourceUrls = [...new Set(resourceUrls.map(cleanCandidate).filter(value => /^https?:\/\//i.test(value)))]
  const normalizedPaths = [...new Set(paths.map(cleanCandidate).filter(value => {
    if (!value || /^https?:\/\//i.test(value)) return false
    return /^[A-Za-z]:\\/.test(value) || value.startsWith('/')
  }))]
  return { paths: normalizedPaths, urls: normalizedUrls, resourceUrls: normalizedResourceUrls }
}

export function extractPathsAndUrls(argsRaw) {
  const { paths, urls } = extractResourceReferences(argsRaw)
  return { paths, urls }
}

function getCommand(argsRaw) {
  const parsed = parseArgs(argsRaw)
  if (parsed && typeof parsed === 'object') {
    for (const key of ['command', 'cmd', 'action', 'operation', 'mode']) {
      if (typeof parsed[key] === 'string') return parsed[key].toLowerCase()
    }
  }
  const raw = safeString(argsRaw)
  const match = raw.match(/(?:"|')?(?:command|cmd|action|operation|mode)(?:"|')?\s*:\s*(?:"|')([^"']+)(?:"|')/i)
  return match?.[1]?.toLowerCase() ?? ''
}

function locationNumber(value, key) {
  if (typeof value === 'number') return value
  if (value && typeof value === 'object' && typeof value[key] === 'number') return value[key]
  return undefined
}

export function eventLocation(node, eventLocations) {
  let turn = typeof node?.turn === 'number' ? node.turn : undefined
  let step = typeof node?.step === 'number' ? node.step : undefined
  if ((turn === undefined || step === undefined) && eventLocations?.get && typeof node?.seq === 'number') {
    const location = eventLocations.get(node.seq)
    if (location && typeof location === 'object') {
      turn ??= locationNumber(location.turn, 'turn')
      step ??= locationNumber(location.step, 'step')
      if (turn === undefined && location.location) turn = locationNumber(location.location.turn, 'turn')
      if (step === undefined && location.location) step = locationNumber(location.location.step, 'step')
    }
  }
  return { turn, step }
}

export function classifyError(text, explicitCode = '') {
  const codeText = safeString(explicitCode)
  const combined = `${codeText}\n${safeString(text)}`
  for (const [code, pattern] of ERROR_PATTERNS) {
    if (pattern.test(combined)) return code
  }
  return codeText ? codeText.toUpperCase().replace(/[^A-Z0-9_]+/g, '_') : null
}

function likelyErrorText(text) {
  const value = safeString(text)
  if (/(?:\bno errors?\b|\b0 errors?\b|without errors?|无错误|没有错误|未发现错误)/i.test(value)) return false
  return /\b(?:error|failed|failure|exception|not found|unsupported|denied|invalid|unavailable|unable to|cannot|could not|错误|失败|异常|找不到|不支持|拒绝|无权限|不可用|无法)\b/i.test(value)
}

function callKind(name, command, argsRaw) {
  const combined = `${name} ${command} ${safeString(argsRaw)}`
  // A multi-purpose tool such as str_replace_editor must be classified by its
  // explicit operation first. Otherwise a harmless `view` call is mistaken
  // for a mutation merely because the tool name contains "replace".
  if (/^(?:view|read|list|find|search|stat|inspect|show)$/i.test(command)) return 'inspect'
  if (/^(?:create|write|replace|insert|delete|move|rename|mkdir|patch|apply|update)$/i.test(command)) return 'mutate'
  // Verification intent comes from the tool/operation, not arbitrary argument
  // values. A read_file call for `test/example.js` is still inspection.
  if (VERIFY_TOOL.test(`${name} ${command}`)) return 'verify'
  if (NETWORK_TOOL.test(name)) return 'external'
  if (SHELL_TOOL.test(name)) return 'execute'
  if (LOCAL_FILE_TOOL.test(name)) return MUTATION_TOOL.test(name) ? 'mutate' : 'inspect'
  return 'tool'
}

function isLocalFileTool(name) {
  return LOCAL_FILE_TOOL.test(name) && !NETWORK_TOOL.test(name)
}

function flattenToolBlocks(blocks, eventLocations, output, parent = null) {
  for (const block of asArray(blocks)) {
    if (!block || typeof block !== 'object') continue
    const settled = block.kind === 'tool-result'
    const name = settled ? block.call?.name ?? 'unknown-tool' : block.name ?? 'unknown-tool'
    const argsRaw = settled ? block.call?.argsRaw ?? '' : block.argsRaw ?? ''
    const resultText = settled ? contentText(block.content) : ''
    const command = getCommand(argsRaw)
    const kind = callKind(name, command, argsRaw)
    const explicitCode = block.error?.code ?? block.error?.name ?? ''
    const structuredFailure = Boolean(block.isError || block.error)
    // File/search tools commonly return source text that legitimately contains
    // words such as "timeout", "403", or "RuntimeError". Their structured
    // isError/error fields are authoritative. Only execution tools need the
    // conservative text fallback because some DSH shell wrappers return fatal
    // stderr with isError=false.
    const inferredExecutionFailure = settled && !structuredFailure && kind === 'execute' && likelyErrorText(resultText)
    const failed = settled
      ? structuredFailure || inferredExecutionFailure
      : false
    const errorCode = failed ? classifyError(resultText, explicitCode) : null
    const { paths, urls, resourceUrls } = extractResourceReferences(argsRaw)
    const location = eventLocation(block, eventLocations)
    const call = {
      id: safeString(block.callId || `${name}:${block.seq ?? block.time ?? output.length}`),
      seq: typeof block.seq === 'number' ? block.seq : parent?.seq ?? Number.MAX_SAFE_INTEGER,
      time: typeof block.time === 'number' ? block.time : parent?.time,
      turn: location.turn ?? parent?.turn,
      step: location.step ?? parent?.step,
      name,
      argsRaw: safeString(argsRaw),
      command,
      paths,
      urls,
      resourceUrls,
      resultText,
      failed,
      settled,
      errorCode: failed ? errorCode ?? 'UNKNOWN_ERROR' : null,
      kind,
      mutation: kind === 'mutate',
      localFileTool: isLocalFileTool(name),
      parentId: parent?.id ?? null,
    }
    output.push(call)
    flattenToolBlocks(block.subCalls, eventLocations, output, call)
  }
}

function commandCall(node, eventLocations) {
  const location = eventLocation(node, eventLocations)
  const settled = node?.outcome !== null && node?.outcome !== undefined
  const failed = settled && node.outcome.kind === 'error'
  const resultText = settled ? safeString(node.outcome.text ?? node.outcome.kind) : ''
  return {
    id: safeString(node.commandId || `command:${node.seq}`),
    seq: typeof node.seq === 'number' ? node.seq : Number.MAX_SAFE_INTEGER,
    time: typeof node.time === 'number' ? node.time : undefined,
    turn: location.turn,
    step: location.step,
    name: node.name ? `/${node.name}` : '/command',
    argsRaw: safeString(node.args ?? ''),
    command: safeString(node.name ?? '').toLowerCase(),
    paths: [],
    urls: [],
    resourceUrls: [],
    resultText,
    failed,
    settled,
    errorCode: failed ? classifyError(resultText) ?? 'COMMAND_ERROR' : null,
    kind: 'execute',
    mutation: false,
    localFileTool: false,
    parentId: null,
  }
}

export function collectToolCalls(nodes, runningCalls = [], eventLocations = new Map()) {
  const calls = []
  for (const node of asArray(nodes)) {
    if (node?.kind === 'tool-result') flattenToolBlocks([node], eventLocations, calls)
    else if (node?.kind === 'command') calls.push(commandCall(node, eventLocations))
  }
  flattenToolBlocks(runningCalls, eventLocations, calls)
  calls.sort((left, right) => left.seq - right.seq || (left.time ?? 0) - (right.time ?? 0))
  return calls
}

function usageValue(usage, candidates) {
  if (!usage || typeof usage !== 'object') return 0
  for (const candidate of candidates) {
    const value = usage[candidate]
    if (typeof value === 'number' && Number.isFinite(value)) return value
  }
  return 0
}

function requestUsage(request) {
  const usage = request?.usage ?? request?.node?.usage
  return {
    input: usageValue(usage, ['inputTokens', 'input_tokens', 'input']),
    output: usageValue(usage, ['outputTokens', 'output_tokens', 'output']),
    reasoning: usageValue(usage, ['reasoningTokens', 'reasoning_tokens', 'reasoning']),
    cacheRead: usageValue(usage, ['cacheReadTokens', 'cache_read_tokens', 'cacheRead']),
    cacheWrite: usageValue(usage, ['cacheWriteTokens', 'cache_write_tokens', 'cacheWrite']),
  }
}

function addUsage(total, value) {
  total.input += value.input
  total.output += value.output
  total.reasoning += value.reasoning
  total.cacheRead += value.cacheRead
  total.cacheWrite += value.cacheWrite
}

function nodeTimes(nodes, requests) {
  const values = []
  for (const node of asArray(nodes)) if (typeof node?.time === 'number') values.push(node.time)
  for (const request of asArray(requests)) {
    if (typeof request?.startedAt === 'number') values.push(request.startedAt)
    if (typeof request?.completedAt === 'number') values.push(request.completedAt)
  }
  if (!values.length) return { startedAt: null, endedAt: null, durationMs: null }
  const startedAt = Math.min(...values)
  const endedAt = Math.max(...values)
  return { startedAt, endedAt, durationMs: Math.max(0, endedAt - startedAt) }
}

function evidenceFromCall(call, text = '') {
  return {
    seq: Number.isFinite(call.seq) ? call.seq : null,
    turn: call.turn ?? null,
    step: call.step ?? null,
    toolName: call.name,
    callId: call.id,
    excerpt: excerpt(text || call.resultText || call.argsRaw),
  }
}

function evidenceFromNode(node, eventLocations, text = '') {
  const location = eventLocation(node, eventLocations)
  return {
    seq: typeof node?.seq === 'number' ? node.seq : null,
    turn: location.turn ?? null,
    step: location.step ?? null,
    toolName: null,
    callId: null,
    excerpt: excerpt(text || assistantText(node) || contentText(node?.content)),
  }
}

function finding({ id, category, severity, title, summary, rootCause, recommendation, confidence = 'high', evidence = [] }) {
  return { id, category, severity, title, summary, rootCause, recommendation, confidence, evidence }
}

function repeatedFailureFindings(calls) {
  const groups = new Map()
  for (const call of calls) {
    if (!call.failed) continue
    const key = `${call.name}\u0000${call.errorCode}`
    const group = groups.get(key) ?? []
    group.push(call)
    groups.set(key, group)
  }
  const findings = []
  for (const [key, group] of groups) {
    if (group.length < 2) continue
    const [toolName, errorCode] = key.split('\u0000')
    findings.push(finding({
      id: `repeated-failure:${toolName}:${errorCode}`,
      category: 'repeated_failure',
      severity: group.length >= 4 ? 'high' : 'medium',
      title: `同类错误重复出现 ${group.length} 次`,
      summary: `${toolName} 连续或多次返回 ${errorCode}，但策略没有获得足以改变结果的新证据。`,
      rootCause: '失败后仍沿用同一种工具与同一类参数，只做表面替换，没有先确认能力边界或输入来源。',
      recommendation: '同一错误出现两次后暂停重试：先读取可见工作区、枚举可用工具，或向用户请求唯一缺失的输入。',
      evidence: group.slice(0, 6).map(call => evidenceFromCall(call)),
    }))
  }
  return findings
}

function blindPathFinding(calls) {
  const candidates = calls.filter(call => call.failed && call.errorCode === 'FS_NOT_FOUND' && call.paths.length)
  const uniquePaths = [...new Set(candidates.flatMap(call => call.paths))]
  if (uniquePaths.length < 3) return null
  return finding({
    id: 'blind-path-guessing',
    category: 'blind_path',
    severity: uniquePaths.length >= 6 ? 'high' : 'medium',
    title: `无证据猜测了 ${uniquePaths.length} 个本地路径`,
    summary: `Agent 在没有目录枚举结果的情况下轮流尝试 ${uniquePaths.slice(0, 5).join('、')}${uniquePaths.length > 5 ? ' 等路径' : ''}。`,
    rootCause: '把路径猜测当作仓库发现机制，而不是从已选 workspace、当前目录或用户提供的位置建立证据链。',
    recommendation: '先读取会话 workspace 和可见目录；若工具无法枚举目录，应立即说明阻塞条件，不继续扩展猜测空间。',
    evidence: candidates.slice(0, 8).map(call => evidenceFromCall(call, `${call.paths.join(', ')} → ${call.errorCode}`)),
  })
}

function urlToLocalFindings(calls) {
  return calls
    .filter(call => call.localFileTool && call.resourceUrls.length)
    .map((call, index) => finding({
      id: `url-to-local:${call.id}:${index}`,
      category: 'tool_semantics',
      severity: 'high',
      title: '把远程 URL 交给了本地文件工具',
      summary: `${call.name} 收到了 ${call.resourceUrls[0]}；这类工具只能读取本地文件系统路径。`,
      rootCause: '没有区分本地资源定位与远程资源获取两种工具语义。',
      recommendation: 'URL 应交给 web_fetch、GitHub、HTTP 或下载工具；若当前组合没有网络获取能力，应直接报告并请求用户提供本地副本。',
      evidence: [evidenceFromCall(call, `${call.name}(${call.resourceUrls.join(', ')}) → ${call.errorCode ?? '结果未知'}`)],
    }))
}

function platformMismatchFinding(calls) {
  const matches = calls.filter(call => call.failed && (
    call.errorCode === 'PLATFORM_UNSUPPORTED'
    || call.errorCode === 'TOOL_UNAVAILABLE'
    || /(?:Windows|win32).*(?:bash|shell|terminal)|(?:bash|shell|terminal).*(?:Windows|win32)/i.test(call.resultText)
  ))
  if (!matches.length) return null
  const firstIndex = calls.indexOf(matches[0])
  return finding({
    id: 'platform-capability-mismatch',
    category: 'capability',
    severity: 'high',
    title: firstIndex >= 5 ? '运行能力盘点发生得过晚' : '工具与当前平台能力不匹配',
    summary: `轨迹在第 ${firstIndex + 1} 次工具尝试附近才确认终端、平台或外部访问能力不足。`,
    rootCause: '任务开始前没有建立操作系统、工作区、终端、Git、网络和文件工具的能力清单。',
    recommendation: '把环境预检放在第一次实质操作之前；确认能力缺失后立即切换到可行路径，不再调用必然失败的工具。',
    evidence: matches.slice(0, 5).map(call => evidenceFromCall(call)),
  })
}

function noProgressLoopFinding(calls) {
  let best = []
  let current = []
  for (const call of calls) {
    if (!call.failed) {
      current = []
      continue
    }
    const previous = current[current.length - 1]
    if (previous && previous.name === call.name && previous.errorCode === call.errorCode) current.push(call)
    else current = [call]
    if (current.length > best.length) best = [...current]
  }
  if (best.length < 3) return null
  return finding({
    id: 'no-progress-loop',
    category: 'loop',
    severity: best.length >= 5 ? 'high' : 'medium',
    title: `出现 ${best.length} 步无进展重试循环`,
    summary: `${best[0].name} 在没有成功事件打断的情况下连续返回 ${best[0].errorCode}。`,
    rootCause: 'Agent 没有把重复错误视为停止信号，也没有设置重试预算或策略切换门槛。',
    recommendation: '为同工具同错误设置最多两次尝试；超过预算后必须总结证据、改用另一类工具或请求用户介入。',
    evidence: best.slice(0, 8).map(call => evidenceFromCall(call)),
  })
}

function prematureMutationFinding(calls) {
  const firstMutationIndex = calls.findIndex(call => call.mutation && call.settled && !call.failed && (SUCCESS_PATTERNS.test(call.resultText) || call.resultText))
  if (firstMutationIndex < 0) return null
  const priorSuccessfulInspection = calls.slice(0, firstMutationIndex).some(call => call.kind === 'inspect' && call.settled && !call.failed)
  const laterAccessFailures = calls.slice(firstMutationIndex + 1).filter(call => call.failed && ['FS_NOT_FOUND', 'TOOL_UNAVAILABLE', 'PLATFORM_UNSUPPORTED'].includes(call.errorCode))
  if (priorSuccessfulInspection || laterAccessFailures.length < 2) return null
  const mutation = calls[firstMutationIndex]
  return finding({
    id: 'premature-side-effect',
    category: 'ordering',
    severity: 'high',
    title: '在确认核心输入可访问之前产生了副作用',
    summary: `${mutation.name} 已执行写入或创建，但此后仍反复发现目标资料不可访问。`,
    rootCause: '执行顺序把“创建交付物”放在“确认输入与能力”之前，容易制造看似有产出的占位文件。',
    recommendation: '先完成输入可达性 Gate；只有读取到目标资料并建立最小证据后，才允许创建正式报告或修改项目。',
    evidence: [evidenceFromCall(mutation), ...laterAccessFailures.slice(0, 4).map(call => evidenceFromCall(call))],
  })
}

function highFailureFinding(calls) {
  const settled = calls.filter(call => call.settled)
  if (settled.length < 6) return null
  const failed = settled.filter(call => call.failed)
  const ratio = failed.length / settled.length
  if (ratio < 0.5) return null
  return finding({
    id: 'high-failure-ratio',
    category: 'efficiency',
    severity: ratio >= 0.75 ? 'high' : 'medium',
    title: `工具失败率达到 ${Math.round(ratio * 100)}%`,
    summary: `${settled.length} 次已结束工具调用中有 ${failed.length} 次失败，主要执行预算被消耗在未产生进展的尝试上。`,
    rootCause: '缺少失败预算、能力预检和阶段性停止条件。',
    recommendation: '每个阶段维护“新增证据”指标；连续两次没有新增证据时停止执行并重新规划。',
    evidence: failed.slice(0, 6).map(call => evidenceFromCall(call)),
  })
}

function unresolvedFailures(calls, throughSeq = Number.MAX_SAFE_INTEGER) {
  const inWindow = calls.filter(call => call.seq <= throughSeq)
  return inWindow.filter(failure => {
    if (!failure.failed) return false
    return !inWindow.some(candidate => (
      candidate.seq > failure.seq
      && candidate.settled
      && !candidate.failed
      && (candidate.kind === 'verify' || candidate.name === failure.name)
    ))
  })
}

function completionMismatchFinding(nodes, calls, eventLocations) {
  const assistants = asArray(nodes).filter(node => node?.kind === 'assistant')
  const finalAssistant = assistants[assistants.length - 1]
  if (!finalAssistant) return null
  const text = assistantText(finalAssistant)
  if (!COMPLETION_CUES.test(text) || BLOCKED_CUES.test(text) || UNCERTAINTY_CUES.test(text)) return null
  const finalSeq = typeof finalAssistant.seq === 'number' ? finalAssistant.seq : Number.MAX_SAFE_INTEGER
  const severeFailures = unresolvedFailures(calls, finalSeq)
  if (!severeFailures.length) return null
  return finding({
    id: 'completion-evidence-mismatch',
    category: 'claim_mismatch',
    severity: 'high',
    title: '最终完成表述缺少验证证据',
    summary: '最终回答出现“已完成/成功”表述，但轨迹中仍有未闭环失败，且之后没有成功验证步骤。',
    rootCause: '把计划、占位文件或局部成功当成了任务整体完成。',
    recommendation: '最终状态必须由最后一次验证结果驱动；存在未解决的关键失败时只能标记为“受阻”或“部分完成”。',
    evidence: [evidenceFromNode(finalAssistant, eventLocations, text), ...severeFailures.slice(-4).map(call => evidenceFromCall(call))],
  })
}

function userCorrectionFinding(nodes, calls, eventLocations) {
  const users = asArray(nodes).filter(node => node?.kind === 'user')
  if (users.length < 2) return null
  const correction = users.find(node => /(?:不是|不要|我说的是|你理解错|不对|停止|别再|wrong|not what|don['’]?t)/i.test(contentText(node.content)))
  if (!correction || typeof correction.seq !== 'number') return null
  const before = calls.filter(call => call.seq < correction.seq).slice(-2)
  const after = calls.filter(call => call.seq > correction.seq).slice(0, 3)
  if (!before.length || !after.length) return null
  const repeated = after.some(call => before.some(previous => previous.name === call.name && previous.errorCode === call.errorCode && call.failed))
  if (!repeated) return null
  return finding({
    id: 'correction-not-incorporated',
    category: 'user_feedback',
    severity: 'high',
    title: '用户纠正后仍重复了原策略',
    summary: '用户明确指出方向不对，但后续工具调用仍复用了纠正前的失败模式。',
    rootCause: '没有把用户纠正转换成新的约束和停止条件。',
    recommendation: '收到纠正后先复述新的任务边界，并废弃与纠正冲突的计划节点，再继续调用工具。',
    evidence: [evidenceFromNode(correction, eventLocations), ...after.filter(call => call.failed).map(call => evidenceFromCall(call))],
  })
}

function severityRank(value) {
  return value === 'high' ? 0 : value === 'medium' ? 1 : 2
}

function dedupeFindings(findings) {
  const seen = new Set()
  return findings
    .filter(Boolean)
    .filter(item => {
      if (seen.has(item.id)) return false
      seen.add(item.id)
      return true
    })
    .sort((left, right) => severityRank(left.severity) - severityRank(right.severity) || left.title.localeCompare(right.title, 'zh-CN'))
}

function phaseCategory(call) {
  switch (call.kind) {
    case 'inspect': return 'inspect'
    case 'external': return 'external'
    case 'mutate': return 'mutate'
    case 'verify': return 'verify'
    case 'execute': return 'execute'
    default: return 'tool'
  }
}

const PHASE_TITLES = {
  inspect: '定位输入与读取资料',
  external: '获取外部资源',
  mutate: '生成或修改产物',
  execute: '执行命令',
  verify: '验证结果',
  tool: '调用辅助工具',
}

export function buildPhases(calls, nodes = []) {
  const groups = []
  let current = null
  for (const call of calls) {
    const category = phaseCategory(call)
    const shouldSplit = !current
      || current.category !== category
      || (call.turn !== undefined && current.turn !== undefined && call.turn !== current.turn && current.calls.length >= 2)
    if (shouldSplit) {
      current = { category, title: PHASE_TITLES[category], calls: [], turn: call.turn }
      groups.push(current)
    }
    current.calls.push(call)
  }
  if (!groups.length && asArray(nodes).length) {
    return [{
      id: 'phase-analysis',
      title: '分析与沟通',
      category: 'analysis',
      seqStart: asArray(nodes)[0]?.seq ?? null,
      seqEnd: asArray(nodes)[asArray(nodes).length - 1]?.seq ?? null,
      callCount: 0,
      failureCount: 0,
      status: 'completed',
      summary: '本次轨迹没有记录工具调用，主要由消息交换构成。',
      tools: [],
    }]
  }
  return groups.map((group, index) => {
    const failed = group.calls.filter(call => call.failed)
    const tools = [...new Set(group.calls.map(call => call.name))]
    const paths = [...new Set(group.calls.flatMap(call => call.paths))]
    let summary = `调用 ${tools.slice(0, 3).join('、') || '工具'} 共 ${group.calls.length} 次`
    if (paths.length) summary += `，涉及 ${paths.length} 个路径`
    if (failed.length) summary += `，其中 ${failed.length} 次失败`
    else summary += '，未记录失败'
    return {
      id: `phase-${index + 1}`,
      title: group.title,
      category: group.category,
      seqStart: Number.isFinite(group.calls[0]?.seq) ? group.calls[0].seq : null,
      seqEnd: Number.isFinite(group.calls[group.calls.length - 1]?.seq) ? group.calls[group.calls.length - 1].seq : null,
      turn: group.turn ?? null,
      callCount: group.calls.length,
      failureCount: failed.length,
      status: failed.length === group.calls.length ? 'failed' : failed.length ? 'partial' : 'completed',
      summary,
      tools,
    }
  })
}

function inferStatus(snapshot, nodes, calls, findings) {
  const running = Boolean(
    snapshot?.running
    || snapshot?.status === 'running'
    || asArray(snapshot?.runningCalls).length
    || calls.some(call => !call.settled),
  )
  if (running) return { code: 'running', label: '运行中', tone: 'info' }

  const turnErrors = asArray(nodes).filter(node => node?.kind === 'turn-error')
  const turnFailures = asArray(nodes).filter(node => node?.kind === 'turn-failure')
  const turnWarnings = asArray(nodes).filter(node => node?.kind === 'turn-warning')
  const assistants = asArray(nodes).filter(node => node?.kind === 'assistant')
  const finalAssistant = assistants[assistants.length - 1]
  const finalText = assistantText(finalAssistant)
  const settled = calls.filter(call => call.settled)
  const failed = settled.filter(call => call.failed)
  const successful = settled.filter(call => !call.failed)
  const unresolved = unresolvedFailures(calls)

  if (turnErrors.length || (BLOCKED_CUES.test(finalText) && unresolved.length)) {
    return { code: 'blocked', label: '受阻', tone: 'danger' }
  }
  if (turnFailures.length) return { code: 'failed', label: '失败', tone: 'danger' }
  if (turnWarnings.length) return { code: 'partial', label: '部分完成', tone: 'warning' }
  if (unresolved.length && successful.length === 0 && settled.length) {
    return { code: 'failed', label: '失败', tone: 'danger' }
  }
  if (findings.some(item => item.id === 'completion-evidence-mismatch') || (unresolved.length && successful.length)) {
    return { code: 'partial', label: '部分完成', tone: 'warning' }
  }
  if (COMPLETION_CUES.test(finalText) && !UNCERTAINTY_CUES.test(finalText) && !unresolved.length) {
    return { code: 'complete', label: '已完成', tone: 'success' }
  }
  return { code: 'unverified', label: '需验证', tone: 'neutral' }
}

function statusSummary(status, metrics, findings) {
  const prefix = `本次运行${status.label}`
  const toolPart = metrics.toolCalls
    ? `：${metrics.toolCalls} 次工具调用中 ${metrics.failedTools} 次失败`
    : '：未记录工具调用'
  const top = findings.slice(0, 2).map(item => item.title)
  return `${prefix}${toolPart}${top.length ? `；主要问题是${top.join('，以及')}。` : '。'}`
}

function lessonsFromFindings(findings) {
  const rules = []
  const add = (id, title, text, sourceFindingId) => {
    if (rules.some(rule => rule.id === id)) return
    rules.push({ id, title, text, sourceFindingId })
  }
  for (const item of findings) {
    switch (item.category) {
      case 'repeated_failure':
      case 'loop':
        add('stop-after-repeat', '重复错误停止规则', '同一工具出现两次同类错误后，必须引入新证据或更换策略，不得只替换参数继续重试。', item.id)
        break
      case 'blind_path':
        add('no-path-guessing', '路径发现规则', '处理本地项目之前先读取已选工作区和可见目录；禁止凭空枚举磁盘路径。', item.id)
        break
      case 'tool_semantics':
        add('resource-tool-match', '资源与工具匹配规则', 'URL 交给网络或仓库工具，本地文件工具只处理已经存在的文件系统路径。', item.id)
        break
      case 'capability':
        add('capability-preflight', '环境预检规则', '第一次实质操作前确认操作系统、工作区、终端、Git、网络与文件工具能力。', item.id)
        break
      case 'ordering':
        add('input-before-output', '输入 Gate 规则', '核心输入尚未可访问时，不创建正式交付文件，也不宣称已开始实质审计。', item.id)
        break
      case 'claim_mismatch':
        add('evidence-backed-completion', '完成判定规则', '最终状态必须由成功验证结果驱动；关键失败未闭环时只能标记为受阻或部分完成。', item.id)
        break
      case 'efficiency':
        add('progress-budget', '进展预算规则', '连续两次工具调用没有新增证据时暂停执行，先总结阻塞条件并重新规划。', item.id)
        break
      case 'user_feedback':
        add('correction-reset', '纠正重置规则', '收到用户纠正后先更新约束并废弃冲突计划，再继续调用工具。', item.id)
        break
      default:
        break
    }
  }
  if (!rules.length) {
    add('verify-before-finish', '验证优先规则', '结束任务前保留一条与用户目标直接对应的验证证据，并让最终表述与该证据一致。', null)
  }
  return rules
}

function strategyFromPhases(phases) {
  if (!phases.length) return '轨迹中没有足够的阶段信息。'
  return phases.map(phase => phase.title).join(' → ')
}

function rootCauseFromFindings(findings) {
  const top = findings.find(item => item.severity === 'high') ?? findings[0]
  return top?.rootCause ?? '未发现明确的确定性故障模式；仍需结合任务目标人工核对最终结果。'
}

function collectMetrics(snapshot, nodes, requests, calls, eventLocations) {
  const settled = calls.filter(call => call.settled)
  const failed = settled.filter(call => call.failed)
  const turns = new Set()
  for (const node of asArray(nodes)) {
    const location = eventLocation(node, eventLocations)
    if (location.turn !== undefined) turns.add(location.turn)
  }
  const usage = { input: 0, output: 0, reasoning: 0, cacheRead: 0, cacheWrite: 0 }
  for (const request of asArray(requests)) addUsage(usage, requestUsage(request))
  if (!requests.length) {
    for (const node of asArray(nodes)) {
      if (node?.kind === 'assistant' && node.usage) addUsage(usage, requestUsage({ usage: node.usage }))
    }
  }
  return {
    events: asArray(nodes).length,
    turns: turns.size,
    requests: asArray(requests).length,
    toolCalls: settled.length,
    failedTools: failed.length,
    successfulTools: settled.length - failed.length,
    failureRate: settled.length ? failed.length / settled.length : 0,
    runningTools: calls.filter(call => !call.settled).length,
    usage,
    ...nodeTimes(nodes, requests),
    historyComplete: !snapshot?.hasMore,
  }
}

function normalizeTrace(snapshot, explicitTrace) {
  if (explicitTrace) return explicitTrace
  try {
    return snapshot?.views?.get?.('trajectory') ?? null
  } catch {
    return null
  }
}

function rawAssistantBlocks(content) {
  return asArray(content).flatMap(block => {
    if (!block || typeof block !== 'object') return []
    if (block.type === 'text' || block.type === 'reasoning') {
      return [{ kind: block.type, text: safeString(block.text) }]
    }
    if (block.type === 'tool-call') {
      return [{
        kind: 'tool-call',
        callId: safeString(block.id),
        name: safeString(block.name),
        argsRaw: safeString(block.arguments),
      }]
    }
    return []
  })
}

function rawEventLocation(data, openTurn, openStep) {
  const turn = typeof data?.turn === 'number' ? data.turn : openTurn
  const step = typeof data?.step === 'number' ? data.step : openStep
  if (typeof step === 'number') {
    return { kind: 'step', turn: { turn }, step: { step } }
  }
  if (typeof turn === 'number') return { kind: 'turn', turn: { turn } }
  return { kind: 'session' }
}

function rawLineageDescendantCount(nodes) {
  let count = 0
  for (const node of asArray(nodes)) {
    count += 1 + rawLineageDescendantCount(node?.descendants)
  }
  return count
}

/**
 * Convert a detached Host `sessionQuery.readSession()` observation and its
 * companion query records into the small trajectory vocabulary consumed by
 * the deterministic analyzer. The original raw events remain the source of
 * truth; this is an analysis projection, not a reconstruction of the UI.
 */
export function projectRawSession(payload = {}) {
  const log = payload?.log ?? payload
  const header = log?.session ?? {}
  const events = asArray(log?.events)
  const eventLocations = new Map()
  const nodes = []
  const calls = new Map()
  const settledCalls = new Set()
  const commands = new Map()
  const requests = new Map()
  const closedTurns = new Map()
  let openTurn
  let openStep

  for (const event of events) {
    if (!event || typeof event !== 'object') continue
    const data = event.data && typeof event.data === 'object' ? event.data : {}
    if (event.type === 'turn/start' && typeof data.turn === 'number') {
      openTurn = data.turn
      openStep = undefined
    }
    if (event.type === 'step/start') {
      if (typeof data.turn === 'number') openTurn = data.turn
      if (typeof data.step === 'number') openStep = data.step
    }

    const location = rawEventLocation(data, openTurn, openStep)
    if (typeof event.seq === 'number') eventLocations.set(event.seq, location)

    if (event.type === 'step/start' && typeof data.turn === 'number' && typeof data.step === 'number') {
      requests.set(`${data.turn}:${data.step}`, {
        purpose: 'assistant',
        startSeq: event.seq,
        turn: data.turn,
        step: data.step,
        startedAt: event.time,
        completedAt: null,
        status: 'running',
      })
    } else if (event.type === 'user/message') {
      nodes.push({
        kind: 'user',
        seq: event.seq,
        time: event.time,
        content: asArray(data.content),
        source: data.source ?? null,
      })
    } else if (event.type === 'assistant/message') {
      const turn = typeof data.turn === 'number' ? data.turn : openTurn
      const step = typeof data.step === 'number' ? data.step : openStep
      nodes.push({
        kind: 'assistant',
        seq: event.seq,
        time: event.time,
        turn,
        step,
        messageId: data.message?.id,
        blocks: rawAssistantBlocks(data.message?.content),
        usage: data.usage,
      })
      if (typeof turn === 'number' && typeof step === 'number') {
        const key = `${turn}:${step}`
        const previous = requests.get(key) ?? {
          purpose: 'assistant',
          startSeq: event.seq,
          turn,
          step,
          startedAt: event.time,
        }
        requests.set(key, {
          ...previous,
          completedAt: event.time,
          status: 'complete',
          resultSeq: event.seq,
          ...(data.usage === undefined ? {} : { usage: data.usage }),
        })
      }
    } else if (event.type === 'tool/call') {
      const callId = safeString(data.callId)
      calls.set(callId, {
        callId,
        name: safeString(data.name),
        argsRaw: safeString(data.arguments),
        turn: typeof data.turn === 'number' ? data.turn : openTurn,
        step: typeof data.step === 'number' ? data.step : openStep,
        seq: event.seq,
        time: event.time,
        subCalls: [],
      })
    } else if (event.type === 'tool/result') {
      // DSH session format v4 promotes the old tool-result wrapper to a
      // first-class tool message. Keep the projection readable for old exports.
      const resultBlock = data.message?.role === 'tool' ? data.message : data.message?.content?.find?.(block => block?.type === 'tool-result')
      const callId = safeString(data.message?.source?.callId ?? resultBlock?.toolCallId)
      const call = calls.get(callId)
      settledCalls.add(callId)
      nodes.push({
        kind: 'tool-result',
        seq: event.seq,
        time: event.time,
        turn: typeof data.turn === 'number' ? data.turn : call?.turn ?? openTurn,
        step: typeof data.step === 'number' ? data.step : call?.step ?? openStep,
        callId,
        call: call ? { name: call.name, argsRaw: call.argsRaw } : null,
        callTime: call?.time ?? null,
        content: asArray(resultBlock?.content),
        isError: resultBlock?.isError === true,
        ...(data.error === undefined ? {} : { error: data.error }),
        meta: data.meta,
        subCalls: [],
      })
    } else if (event.type === 'command/run') {
      commands.set(safeString(data.commandId), {
        commandId: safeString(data.commandId),
        name: safeString(data.name),
        args: safeString(data.args),
        time: event.time,
        seq: event.seq,
      })
    } else if (event.type === 'command/done') {
      const commandId = safeString(data.commandId)
      const command = commands.get(commandId)
      nodes.push({
        kind: 'command',
        commandId,
        name: command?.name ?? 'command',
        args: command?.args ?? '',
        seq: event.seq,
        time: event.time,
        outcome: { kind: data.kind, text: safeString(data.text ?? data.kind) },
      })
    } else if (event.type === 'turn/end') {
      const reason = data.reason?.kind
      if (reason === 'error') {
        nodes.push({
          kind: 'turn-failure',
          seq: event.seq,
          time: event.time,
          turn: data.turn,
          error: safeString(data.reason?.error?.message ?? data.reason?.error?.code ?? 'turn error'),
        })
      } else if (reason === 'blocked' || reason === 'aborted' || reason === 'interrupted') {
        nodes.push({
          kind: 'turn-error',
          seq: event.seq,
          time: event.time,
          turn: data.turn,
          error: safeString(reason),
        })
      } else if (reason === 'max-tokens') {
        nodes.push({ kind: 'turn-warning', seq: event.seq, time: event.time, turn: data.turn, warning: 'max-tokens' })
      }
    }

    if (event.type === 'step/end') {
      const key = `${data.turn}:${data.step}`
      const request = requests.get(key)
      if (request?.status === 'running') {
        requests.set(key, { ...request, completedAt: event.time, status: 'error' })
      }
      if (data.step === openStep) openStep = undefined
    }
    if (event.type === 'turn/end' && data.turn === openTurn) {
      closedTurns.set(data.turn, { seq: event.seq, time: event.time, reason: data.reason })
      openTurn = undefined
      openStep = undefined
    }
  }

  const runningCalls = []
  for (const call of calls.values()) {
    if (settledCalls.has(call.callId)) continue
    const boundary = closedTurns.get(call.turn)
    if (boundary === undefined) {
      runningCalls.push(call)
      continue
    }
    nodes.push({
      kind: 'tool-result',
      seq: boundary.seq - 0.8,
      time: boundary.time,
      turn: call.turn,
      step: call.step,
      callId: call.callId,
      call: { name: call.name, argsRaw: call.argsRaw },
      callTime: call.time,
      content: [],
      isError: true,
      error: { name: 'Interrupted', code: 'interrupted' },
      subCalls: [],
    })
  }
  const records = asArray(payload?.records)
  const surfaceCounts = { current: 0, shadowed: 0, logOnly: 0 }
  for (const record of records) {
    if (record?.surface === 'current') surfaceCounts.current += 1
    else if (record?.surface === 'shadowed') surfaceCounts.shadowed += 1
    else if (record?.surface === 'log-only') surfaceCounts.logOnly += 1
  }
  const replacementEvents = events.filter(event => event?.surfaceOp && typeof event.surfaceOp === 'object' && event.surfaceOp.op === 'replace').length
  const sourceLinks = events.reduce((total, event) => total + asArray(event?.sourceEventSeqs).length, 0)
  const lineage = payload?.lineage
  const source = {
    kind: 'host-session-query',
    rawEvents: events.length,
    currentSurfaceEvents: asArray(payload?.surface?.events).length,
    surfaceCounts,
    replacementEvents,
    sourceLinks,
    ancestors: asArray(lineage?.ancestors).length,
    descendants: rawLineageDescendantCount(lineage?.descendants),
    lineageComplete: lineage?.complete,
    diagnostics: asArray(payload?.diagnostics),
  }

  nodes.sort((left, right) => (left.seq ?? 0) - (right.seq ?? 0))
  return {
    snapshot: {
      sessionId: safeString(header?.id),
      running: typeof openTurn === 'number',
      hasMore: false,
      nodes,
      runningCalls,
    },
    trace: {
      eventNodes: nodes,
      eventLocations,
      requests: [...requests.values()].sort((left, right) => left.startSeq - right.startSeq),
      runningCalls,
    },
    source,
  }
}

export function analyzeTrace(input = {}) {
  const rawProjection = input.rawSession ? projectRawSession(input.rawSession) : null
  const snapshot = rawProjection?.snapshot ?? input.snapshot ?? {}
  const trace = rawProjection?.trace ?? normalizeTrace(snapshot, input.trace)
  const nodes = asArray(trace?.eventNodes?.length ? trace.eventNodes : snapshot.nodes)
  const eventLocations = trace?.eventLocations?.get ? trace.eventLocations : new Map()
  const requests = asArray(trace?.requests)
  const runningCalls = asArray(trace?.runningCalls?.length ? trace.runningCalls : snapshot.runningCalls)
  const calls = collectToolCalls(nodes, runningCalls, eventLocations)

  const findings = dedupeFindings([
    ...repeatedFailureFindings(calls),
    blindPathFinding(calls),
    ...urlToLocalFindings(calls),
    platformMismatchFinding(calls),
    noProgressLoopFinding(calls),
    prematureMutationFinding(calls),
    highFailureFinding(calls),
    completionMismatchFinding(nodes, calls, eventLocations),
    userCorrectionFinding(nodes, calls, eventLocations),
  ])
  const phases = buildPhases(calls, nodes)
  const source = rawProjection?.source ?? {
    kind: 'client-trajectory-projection',
    rawEvents: null,
  }
  const metrics = {
    ...collectMetrics(snapshot, nodes, requests, calls, eventLocations),
    ...(source.kind === 'host-session-query' ? {
      rawEvents: source.rawEvents,
      currentSurfaceEvents: source.currentSurfaceEvents,
      surfaceCounts: source.surfaceCounts,
      replacementEvents: source.replacementEvents,
      sourceLinks: source.sourceLinks,
    } : {}),
  }
  const status = inferStatus(snapshot, nodes, calls, findings)
  const assistants = nodes.filter(node => node?.kind === 'assistant')
  const users = nodes.filter(node => node?.kind === 'user')
  const finalAssistant = assistants[assistants.length - 1]

  return {
    schemaVersion: 1,
    analyzerVersion: ANALYZER_VERSION,
    generatedAt: new Date().toISOString(),
    sessionId: safeString(snapshot?.sessionId || input.sessionId || ''),
    source,
    status,
    summary: statusSummary(status, metrics, findings),
    strategy: strategyFromPhases(phases),
    rootCause: rootCauseFromFindings(findings),
    metrics,
    phases,
    findings,
    lessons: lessonsFromFindings(findings),
    finalAnswer: finalAssistant ? excerpt(assistantText(finalAssistant), 500) : '',
    userGoal: users[0] ? excerpt(contentText(users[0].content), 500) : '',
    limitations: [
      ...(metrics.historyComplete ? [] : ['当前只分析了已加载的轨迹窗口；点击“加载完整轨迹”后再作最终判断。']),
      ...(source.kind === 'host-session-query' || trace ? [] : ['未发现 trajectory 视图快照，已回退到会话公开节点；请求级指标可能不完整。']),
      ...asArray(source.diagnostics).map(item => `Host 查询附加信息不可用：${safeString(item?.operation ?? 'unknown')}。`),
      '本报告使用确定性规则生成，未调用模型，也不会写回原会话。',
    ],
  }
}
