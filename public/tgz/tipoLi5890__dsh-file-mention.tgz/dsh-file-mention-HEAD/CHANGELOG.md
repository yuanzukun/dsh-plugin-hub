# Changelog

All notable changes are documented here. The project follows semantic versioning.

## 0.7.0 - Unreleased

### Added

- Pasting non-image files into the composer uploads them through the managed
  pipeline and inserts their `@` path references, instead of failing in the
  built-in image intake. Pure rail-image pastes still reach the image rail.
  Controlled by the new "Upload pasted files" setting in the Uploads tab.
- Dropped and pasted uploads now insert at the composer caret recorded before
  the upload, using the frozen `slash/input-insert-text` contract with a
  draftRev compare-and-swap and a prefix/suffix caret remap across concurrent
  edits; refusals fall back to the previous append behavior.

### Changed

- The drop/upload-progress overlay renders in the official frame-wide
  `shell.overlay` slot instead of an imperative `document.body` element.
- Upload responses return the realpath-resolved managed path, so the inserted
  `@` reference, the pre-step marker, and path-action `check` agree
  byte-for-byte (macOS temp directories live behind a `/var` symlink). The
  reference validator's lexical pre-gate accepts realpath-form tokens for
  roots that sit behind symlinks.

### Testing

- Host end-to-end HTTP suite (`test/e2e.test.js`): the real `apply()` mounted
  on a real Node HTTP server, covering routes, the cross-site fence, settings
  persistence, live/cold/unknown session index resolution, status/maintenance,
  streaming upload with name sanitization and no-clobber renames, path-action
  confinement, and pre-step marker injection.

## 0.6.0 - Unreleased

### Added

- File Mention Control Center with Overview, Index, Uploads, and Output tabs.
- Path-free live status API for index strategy/version/counts and upload usage.
- Maintenance API and UI actions for targeted index rebuild and retention cleanup.
- Reference Tray cards with file/folder identity, copy, reveal, individual remove,
  and clear-all actions.
- Browser-local recent-path prioritization with explicit disable/clear controls.
- Optional changed-file status descriptions in mention candidates.
- Ignore-rule presets, upload usage meters, responsive layout, and diagnostics.
- Distinct Traditional Chinese and English interface copy, including localized
  navigation, Control Center, Reference Tray, settings, and status fallback text.

### Changed

- Directory picks preserve a trailing slash so the draft tray retains directory
  semantics while Host validation continues to normalize the path.
- Settings moved from a flat form to task-oriented operational views.
- Candidate ranking uses recent usage after textual relevance and before repository
  metadata tie-breakers.

## 0.5.0 - Unreleased

### Added

- Root/nested `.aiinclude` support with scoped Git-style globs,
  last-match-wins behavior, and discovery/scan bounds.
- Git dirty status and filesystem mtime metadata, dirty/recent ranking,
  monotonic `indexVersion`, and workspace watcher invalidation.
- Durable plugin settings API and official DSH settings section for enablement,
  pasted mention policy, index/ignore rules, upload policy, and output companion.
- Official `conversation.input.dock` reference chips with reveal/remove actions.
- Optional Host-validated assistant inline-code path companion using the official
  turn-tail/open-file integration without MutationObserver.
- Upload progress and cancellation.

### Changed

- Git index admission now applies one hard cap across files and directories.
- Uploads stream to temp files, use atomic no-clobber finalization, enforce
  per-file/session/global quotas, and run retention cleanup.
- Drag-drop insertion uses the official session input action instead of
  controlled-textarea DOM mutation.
- Pasted mentions carry an invisible marker that the Host strips before model
  input and ignores for reference generation when configured.

### Security

- Path preview/reveal is confined by lexical + realpath checks and starts the
  OS helper with `execFile` argument arrays (no shell).
- Settings, `.aiinclude`, traversal, uploads, and generated index rows all have
  explicit resource limits.

## 0.4.0 - Unreleased

### Added

- Session-scoped Git-aware workspace index with bounded non-Git fallback.
- Directory candidates alongside files.
- Per-session Client warm, single-flight fetch, stale-while-revalidate cache,
  and local fuzzy ranking.
- Quoted mention syntax for paths containing whitespace or quotes.
- Host `agent/pre-step` realpath/existence validation and path-only
  `<workspace-reference>` markers.
- Same-origin/trusted-host API fence and explicit request/resource bounds.
- Node Host/Client tests and `npm test` / `npm run check` scripts.
- Architecture, security, development, and API documentation.

### Changed

- Replaced `GET /api/file-mention/search?base=&q=` with
  `POST /api/file-mention/index { sessionId }`.
- Workspace root now comes only from Host session state; home/outside-root
  browsing was removed.
- Tab completion uses the input-trigger controller instead of DOM ID matching.
- Drag uploads pass the browser `File` directly to `fetch`; stored names replace
  whitespace with `_` so their references remain one token.
- Upload responses use the common `{ ok, value }` envelope.

### Security

- Absolute validated references are limited to managed uploads.
- Added lexical and realpath confinement, symlink-safe indexing, Git command
  timeout/output bounds, JSON/upload limits, and collision-safe writes.

## 0.3.0

- `@` file candidates from a bounded filesystem search.
- Workspace-relative paths and explicit outside-path browsing.
- Tab acceptance through menu DOM hooks.
- Non-image drag/drop uploads with image passthrough and clipboard fallback.
