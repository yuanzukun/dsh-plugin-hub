# Security model

## Protected assets

- workspace path names;
- files copied into the managed upload directory;
- the agent's ability to receive a trusted workspace-reference marker;
- Host availability and memory under large directory trees or uploads.

## Trust boundaries

- Browser state and request parameters are untrusted.
- `session.header.cwd` on the Host is authoritative.
- Only direct user-source messages represent a file-reference gesture.
- The marker is metadata, not permission for arbitrary filesystem access; the
  agent's own tools keep their existing policy and capability boundaries.

## Enforced controls

- same-origin / trusted-authority request fence;
- session-scoped index and upload routes;
- JSON and upload body limits;
- Git execution via `execFile` without a shell, timeout, and output cap;
- bounded non-Git traversal, hidden/heavy directory pruning, no symlink walk;
- lexical plus `realpath` confinement at pre-step;
- absolute references accepted only under the managed upload root;
- collision-safe writes with sanitized path components;
- streaming temp files with atomic no-clobber finalize, serialized quota
  admission, and automatic retention cleanup;
- `.aiinclude` discovery/scan caps and one combined files+directories index cap;
- structured `execFile` path reveal after workspace/upload realpath validation;
- XML-like marker attribute escaping;
- no plugin-side referenced-file reads.

## Deliberate behavior changes in v0.4.0–v0.5.0

The old search endpoint allowed a browser caller to submit any absolute `base`,
fall back to the Host user's home, and browse explicit `/`, `~/`, or `../` paths.
That behavior is removed. Users may still type normal text, but the plugin only
indexes a session workspace and only marks workspace or managed-upload paths as
validated references.

## Residual risks

- Retention is mtime-based and runs at startup/before upload, not from a
  continuously scheduled janitor. An idle Host may retain an expired upload
  until the next restart or upload.
- Quota admission is serialized inside one Host process. Multiple independent
  Host processes sharing the same upload directory need an external filesystem
  quota or lock for a globally atomic guarantee.
- Git output can reveal tracked hidden paths in the mention menu. This is useful
  for `.gitignore` and configuration files and is consistent with Git's visible
  project set; non-Git fallback hides dot entries by default.
- Drop and paste insertions use the frozen `slash/input-insert-text` contract
  with a draftRev compare-and-swap, remapping the recorded caret across
  concurrent edits via a prefix/suffix scan. Edits that overlap the caret, a
  busy composer phase, or a contract refusal fall back to appending through
  the official draft action, so a mid-draft caret position is best-effort.
- `.aiinclude` is intentionally powerful: a project-authored rule can surface a
  Git-ignored filename in the picker. Pre-step confinement still applies and
  the plugin never reads that file's bytes.
- The plugin does not add authentication to DSH itself. Remote deployments must
  configure DSH trusted hosts and access control correctly.

## Reporting

Do not include sensitive file contents in a public report. Provide the plugin
version, DSH version/commit, operating system, reproduction steps, and whether
the deployment is loopback-only or remotely reachable.
