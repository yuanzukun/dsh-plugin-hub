# Architecture

`dsh-file-mention` is a zero-build DSH plugin with a Host half and a browser half.
The central invariant is simple: the browser may request a session's path index,
but only the Host decides which workspace is addressed and which references are
valid.

## Data flow

```text
session.header.cwd
  -> Host index (Git + .aiinclude, bounded walk fallback)
  -> status/mtime + files-and-dirs hard cap + indexVersion
  -> POST /api/file-mention/index
  -> Client per-session cache / local ranking + browser-local recency tie-break
  -> inputTriggers @ menu
  -> full @relative/path in the draft
  -> direct user message
  -> Host agent/pre-step validation
  -> <workspace-reference path="..." kind="file|directory" />
  -> agent decides whether and how to read the path
```

Drag-and-drop and pasted files follow a separate intake path. A capture-phase
paste listener claims clipboard batches holding any non-rail media type (the
built-in image intake would reject the whole batch) and reuses the same
pipeline:

```text
browser File/Blob + XHR progress/cancel
  -> POST /api/file-mention/upload
  -> per-file/session/global admission
  -> streaming temp file -> atomic no-clobber finalize
  -> DSH_HOME/uploads/<sessionId>/<safe-name>
  -> absolute managed-upload @path inserted at the recorded caret
     (draftRev CAS via slash/input-insert-text; append fallback)
  -> the same pre-step validation and marker flow
```

## Host: `lib/index.js`

### Request fence

Every plugin route checks the request Host, DSH `trustedHosts`, `Origin`, and
`Sec-Fetch-Site`. Cross-site requests and untrusted authorities receive 403.
JSON bodies are capped at 256 KiB. Upload admission is bounded by configurable
per-file, per-session, and global quotas.

### Session-scoped root

`POST /api/file-mention/index` accepts only `{ sessionId }`. It obtains the
authoritative root from `ctx.sessions.get(sessionId).header.cwd`. The old
browser-supplied `base` parameter and home-directory fallback were removed:
client state is not a filesystem authorization boundary.

### Index strategy

For a Git workspace, two `git ls-files -z` calls are made without a shell:

- `--cached --others --exclude-standard`: tracked files plus untracked files
  not ignored by Git;
- `--deleted`: tracked paths deleted from disk, which are removed from results.

Directories are derived from file ancestors. This naturally honors
`.gitignore`; Git cannot represent empty directories. Root and nested
`.aiinclude` files may explicitly add ignored files. Their Git-style glob
subset is scoped to the rule file's directory and the last matching rule wins;
discovery is capped at 50 files.

`git status --porcelain=v1 -z` adds dirty state, and bounded `stat` reads add
mtime. The final admission algorithm applies one hard cap across both files and
derived directories, preserving dirty/recent files first. Every rebuilt value
receives a monotonic `indexVersion`. Recursive workspace watch events invalidate
only that cwd; settings changes invalidate every affected cached generation.

If Git is unavailable or the workspace is not a repository, the Host performs
a breadth-first `opendir` walk. The fallback:

- stops at 20,000 combined file/directory entries;
- stops descending after depth 32;
- skips symlinks, hidden entries, VCS metadata, dependencies, caches, and build
  outputs;
- ignores unreadable or concurrently removed branches.

The result is cached by canonical session cwd for 30 seconds. Concurrent callers
share one promise, and filesystem watcher invalidation can end that lifetime early.

### Reference boundary

At `agent/pre-step`, only direct user-source text is scanned. Supported syntax:

- `@src/main.js`
- `@docs/`
- `@"docs/file with spaces.md"`

Relative references must resolve within `session.cwd`. Absolute references are
accepted only when they resolve under the plugin-managed DSH upload root.
`realpath` is compared after lexical confinement to prevent symlink escapes.
The target is `stat`-checked immediately before the step.

The injected message contains only an escaped path and kind. It never contains
file bytes or directory listings.

### Upload storage

Dropped files are streamed to a mode-0600 temp file under
`DSH_HOME/uploads/<sessionId>/`. A serialized admission section measures current
session/global usage, enforces all three quotas, and finalizes with a same-filesystem
no-clobber hard link. Collisions receive ` (2)`, ` (3)`, and so on. Expired files
are removed at startup and before admission according to `uploadRetentionDays`.

## Client: `lib/client.js`

### Index lifecycle

The `inputTriggers` source calls the index endpoint once per session. `warm()`
starts the request as soon as the session controller exists. Candidate calls
join the same in-flight promise.

After settlement, the index is fresh for 30 seconds. When stale, the old list is
returned immediately and one background refresh starts. A superseded keystroke
does not cancel the shared index request; it only discards its own result.

### Ranking

Ranking happens in the browser, so typing never restarts a filesystem scan:

1. exact basename;
2. basename prefix;
3. basename substring;
4. full-path substring;
5. ordered subsequence fallback.

Ties optionally prefer browser-local recent usage, then dirty files, newer mtime,
shallower paths, and lexical order. Recent counts live only in `localStorage` and
can be disabled or cleared from the Control Center. At most 40 rows are rendered.
Files and directories share the same roll and use distinct icons; changed files
may expose a status label in their candidate description.

### Pick format

The full workspace-relative path is retained to avoid basename ambiguity.
Whitespace or quote-containing paths are inserted as quoted mentions. The
Host parser understands the same grammar.

### Tab completion

Tab uses the official per-session input-trigger controller's `menu` and `pick`
interfaces. It does not depend on menu DOM IDs or synthesize a pointer event.

### Official slots and drag-and-drop

`conversation.input.dock` is the single draft/action integration. It renders a
Reference Tray with file/folder identity, copy, reveal, individual removal, and
batch clear. It also keeps a session-addressed stable `inputActions.setDraft`
face for external drops. No textarea value setter, `execCommand`, or input-mirror
verification remains.

`settings.section` owns a four-tab Control Center. It reads path-free live
aggregates through `/status`, drives index rebuild/retention cleanup through
`/maintenance`, and owns durable plugin settings. The optional
`conversation.chat.turnTail` companion finds inline-code path candidates,
validates each through `/path-action`, then uses the owner-provided `openFile`
for preview and a structured Host reveal action. It uses no MutationObserver.

Pure-image drags and pastes remain owned by DSH's image rail. A drag or paste
containing a non-image file is uploaded through the Host route. XHR streams the
`File`, exposes progress, and is aborted from the upload overlay, which renders
in the frame-wide `shell.overlay` slot. Results insert at the caret recorded
before the upload through the frozen `slash/input-insert-text` contract
(draftRev CAS, prefix/suffix caret remap); refusals fall back to the stable
draft-action append, and clipboard fallback remains if the session input slot
disappears.

## Stable invariants

- No file content is read by the mention/index path.
- The browser never chooses an index root.
- Full paths, not basename-only aliases, are the durable reference format.
- Filesystem limits are hard limits, not UI suggestions.
- Client cache is a performance layer; Host pre-step validation is the truth.
- Control Center status never returns indexed paths or upload filenames.
- A connection reset discards all browser index state.
