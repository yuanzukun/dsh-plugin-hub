# Development and release workflow

## Requirements

- Node.js with the built-in `node:test` runner;
- Git on PATH for Git-index integration tests;
- a compatible DeepSeek Harness Web profile for manual E2E checks.

No package install or build step is required.

## Local checks

```sh
npm run check
```

This performs syntax checks on both bundles and runs every test under `test/`.

## Test layers

- Host pure/security tests: sanitizer, confinement, request fence, mention parser.
- Filesystem integration: depth/count bounds, hidden/heavy directories, symlink,
  Git tracked/untracked/ignored/deleted behavior, `.aiinclude`, metadata/cap,
  and retention cleanup.
- Pre-step integration: direct user source only, workspace/upload allow roots,
  path-only markers.
- Client contract: React runtime boundary, local/recent ranking, quoting/paste
  marker, draft batch removal, warm single-flight index, file/folder candidates,
  and full-path picks.

## Manual E2E matrix

Before release, install with a local link and restart DSH Web:

```sh
dsh plugin --profile web add link:/absolute/path/to/dsh-file-mention
dsh --profile web --dump-config
```

Verify:

1. bare `@` opens a mixed file/folder list;
2. `@readme`, `@src/ma`, arrows, Enter, and Tab work;
3. duplicate basenames show distinct parent directories and insert full paths;
4. a path containing spaces is inserted as `@"..."` and produces a validated
   marker;
5. a new untracked non-ignored file appears; an ignored file does not;
6. non-Git workspace fallback respects heavy-directory and depth limits;
7. drag a non-image file, then confirm the managed upload reference works;
8. pure-image drag still reaches the built-in image rail;
9. switch sessions/workspaces and confirm indexes do not cross;
10. restart/reconnect and confirm the client fetches a new index.
11. edit a tracked file and confirm its dirty badge/order and `indexVersion`
    refresh after the watcher debounce;
12. add an ignored Markdown file selected by `.aiinclude`, then add a later `!`
    rule and confirm last-match-wins;
13. open Settings → File mentions and verify every setting survives restart;
14. upload until each configured quota is hit, cancel a large upload, and verify
    no `.upload-*.tmp` file remains;
15. enable output companion and verify only Host-validated inline paths expose
    open/reveal actions.
16. verify Reference Tray copy/reveal/remove/clear-all behavior for mixed file and
    folder mentions without losing surrounding draft text;
17. verify all four Control Center tabs, live metrics, index rebuild, retention
    cleanup, presets, and recent-history clear in light and dark themes;
18. resize below 720 px and confirm the metrics, diagnostics, fields, and tray
    collapse without horizontal clipping.

## Release checklist

- run `npm run check`;
- perform the E2E matrix on the supported DSH version;
- update both READMEs and `CHANGELOG.md`;
- keep `package.json` version, install examples, and compatibility statement in
  sync;
- inspect `npm pack --dry-run` so Host, Client, Cordis patch, and docs are present;
- tag only after the clean-tarball install test passes.

Do not commit generated caches, DSH uploads, or local profile files.
