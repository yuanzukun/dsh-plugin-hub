import test from "node:test";
import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import { mkdtemp, mkdir, realpath, rm, symlink, utimes, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Readable, Writable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { promisify } from "node:util";

import {
	__test,
	buildWorkspaceIndex,
	capEntries,
	cleanupUploads,
	invalidateIndex,
	isTrustedApiRequest,
	isWithin,
	mentionPreStep,
	normalizeSettings,
	parseGitStatus,
	scanMentions,
	summarizeIndex,
	walkWorkspace,
} from "../lib/index.js";
import { aiIncluded, parseAiInclude } from "../lib/rules.js";

const run = promisify(execFile);

async function fixture(prefix = "dsh-file-mention-") {
	const root = await mkdtemp(join(tmpdir(), prefix));
	await mkdir(join(root, "src", "deep", "more"), { recursive: true });
	await mkdir(join(root, "node_modules", "pkg"), { recursive: true });
	await mkdir(join(root, ".secret"), { recursive: true });
	await writeFile(join(root, "README.md"), "# fixture\n");
	await writeFile(join(root, "space name.txt"), "space\n");
	await writeFile(join(root, "src", "main.js"), "export {};\n");
	await writeFile(join(root, "src", "deep", "nested.js"), "export {};\n");
	await writeFile(join(root, "src", "deep", "more", "last.js"), "export {};\n");
	await writeFile(join(root, "node_modules", "pkg", "index.js"), "module.exports = {};\n");
	await writeFile(join(root, ".secret", "token"), "hidden\n");
	return root;
}

test("sanitizers keep upload paths as safe single components", () => {
	assert.equal(__test.safeSessionId("abc-123_DEF"), "abc-123_DEF");
	assert.equal(__test.safeSessionId("../../"), undefined);
	assert.equal(__test.safeFileName("../a b.txt"), "a_b.txt");
	assert.equal(__test.safeFileName(".."), "file");
});

test("isWithin rejects sibling-prefix and parent escapes", () => {
	assert.equal(isWithin("/a/work", "/a/work/src/a.js"), true);
	assert.equal(isWithin("/a/work", "/a/work"), true);
	assert.equal(isWithin("/a/work", "/a/worker/secret"), false);
	assert.equal(isWithin("C:\\Work", "c:/work/src/a.js", "win32"), true);
});

test("trusted API fence enforces authority and browser origin", () => {
	assert.equal(isTrustedApiRequest({ headers: { host: "127.0.0.1:3000" } }), true);
	assert.equal(isTrustedApiRequest({ headers: { host: "evil.test" } }), false);
	assert.equal(isTrustedApiRequest({ headers: { host: "10.0.0.2:3000" } }, ["10.0.0.2"]), true);
	assert.equal(isTrustedApiRequest({ headers: { host: "127.0.0.1:3000", origin: "http://evil.test" } }), false);
	assert.equal(isTrustedApiRequest({ headers: { host: "127.0.0.1:3000", origin: "http://127.0.0.1:3000" } }), true);
	assert.equal(isTrustedApiRequest({ headers: { host: "127.0.0.1:3000", "sec-fetch-site": "cross-site" } }), false);
});

test("sessionCwd resolves live sessions from the in-memory store", async () => {
	const ctx = { sessions: { get: () => ({ header: { cwd: "/work/live" } }) }, get: () => void 0 };
	assert.equal(await __test.sessionCwd(ctx, "session-live"), "/work/live");
});

test("sessionCwd falls back to persistence for cold (non-live) sessions", async () => {
	const headers = [
		{ id: "session-other", cwd: "/work/other", version: 0, createdAt: 1 },
		{ id: "session-cold", cwd: "/work/cold", version: 0, createdAt: 2 },
	];
	const ctx = {
		sessions: { get: () => void 0 },
		get: (name) => name === "sessionPersistence" ? { list: async () => headers } : void 0,
	};
	assert.equal(await __test.sessionCwd(ctx, "session-cold"), "/work/cold");
});

test("sessionCwd ignores persisted headers without a usable cwd and rejects unknown sessions", async () => {
	const headers = [
		{ id: "session-nocwd", version: 0, createdAt: 1 },
		{ id: "session-relative", cwd: "relative/path", version: 0, createdAt: 2 },
	];
	const ctx = {
		sessions: { get: () => void 0 },
		get: (name) => name === "sessionPersistence" ? { list: async () => headers } : void 0,
	};
	await assert.rejects(
		__test.sessionCwd(ctx, "session-nocwd"),
		(error) => error.code === "unknown-session" && error.message === "session workspace is unavailable",
	);
	await assert.rejects(
		__test.sessionCwd(ctx, "session-relative"),
		(error) => error.code === "unknown-session",
	);
	await assert.rejects(
		__test.sessionCwd(ctx, "session-unknown"),
		(error) => error.code === "unknown-session",
	);
});

test("sessionCwd rejects empty sessionIds as missing", async () => {
	const ctx = { sessions: { get: () => void 0 }, get: () => void 0 };
	await assert.rejects(__test.sessionCwd(ctx, ""), (error) => error.code === "missing-session");
	await assert.rejects(__test.sessionCwd(ctx, void 0), (error) => error.code === "missing-session");
});

test("sessionCwd still rejects unknown sessions when persistence is absent", async () => {
	const ctx = { sessions: { get: () => void 0 }, get: () => void 0 };
	await assert.rejects(__test.sessionCwd(ctx, "session-unknown"), (error) => error.code === "unknown-session");
});

test("scanMentions supports full paths, directories, quoting, escapes, and dedupe", () => {
	assert.deepEqual(scanMentions("check @src/main.js and @src/main.js @docs/"), ["src/main.js", "docs"]);
	assert.deepEqual(scanMentions('read @"docs/space name.md" and @"a\\"b.txt"'), ["docs/space name.md", 'a"b.txt']);
});

test("pasted mention marker is ignored or stripped according to settings", () => {
	assert.deepEqual(scanMentions("@\u2060pasted.md @typed.md", { ignoreProtected: true }), ["typed.md"]);
	assert.deepEqual(scanMentions("@\u2060pasted.md", { ignoreProtected: false }), ["pasted.md"]);
});

test(".aiinclude uses Git-like globs, nested bases, and last-match-wins", () => {
	const rules = [
		...parseAiInclude("ignored/**/*.md\n!ignored/private/**", "", 0),
		...parseAiInclude("private/keep.md", "ignored", 10),
	];
	assert.equal(aiIncluded(rules, "ignored/docs/readme.md"), true);
	assert.equal(aiIncluded(rules, "ignored/private/secret.md"), false);
	assert.equal(aiIncluded(rules, "ignored/private/keep.md"), true);
});

test("Git status parsing and combined hard cap keep changed files first", () => {
	const status = parseGitStatus(" M src/a.js\0?? new.txt\0");
	assert.equal(status.get("src/a.js"), "M");
	assert.equal(status.get("new.txt"), "??");
	const capped = capEntries([
		{ relative: "deep/a/b/c.txt", kind: "file", mtimeMs: 1 },
		{ relative: "changed.txt", kind: "file", mtimeMs: 2, status: "M" },
	], 2);
	assert.deepEqual(capped.files, ["changed.txt"]);
	assert.equal(capped.entries.length <= 2, true);
	assert.equal(capped.truncated, true);
});

test("settings normalization enforces bounded quotas and rule count", () => {
	const value = normalizeSettings({ indexMaxEntries: 1, uploadFileLimitBytes: 1, uploadSessionQuotaBytes: 1, ignoreRules: ["dist/**", 42], prioritizeRecentMentions: false, showStatusBadges: false });
	assert.equal(value.indexMaxEntries, 100);
	assert.equal(value.uploadFileLimitBytes, 1024 ** 2);
	assert.equal(value.uploadSessionQuotaBytes >= value.uploadFileLimitBytes, true);
	assert.deepEqual(value.ignoreRules, ["dist/**"]);
	assert.equal(value.prioritizeRecentMentions, false);
	assert.equal(value.showStatusBadges, false);
	assert.equal(value.uploadPastedFiles, true, "paste upload defaults on");
	assert.equal(normalizeSettings({ uploadPastedFiles: false }).uploadPastedFiles, false);
});

test("control-center index summary exposes counts without path details", () => {
	assert.deepEqual(summarizeIndex({
		strategy: "git", indexVersion: 7, truncated: true, aiincludeFiles: [".aiinclude"],
		entries: [
			{ relative: "src/", kind: "dir" },
			{ relative: "src/a.js", kind: "file", status: "M" },
			{ relative: "README.md", kind: "file" },
		],
	}), { strategy: "git", indexVersion: 7, files: 2, dirs: 1, dirty: 1, truncated: true, aiincludeFiles: 1 });
});

test("streaming upload limiter rejects overflow without buffering a request body", async () => {
	const accepted = __test.streamLimiter(4);
	await pipeline(Readable.from([Buffer.from("12"), Buffer.from("34")]), accepted.limiter, new Writable({ write(_chunk, _encoding, done) { done(); } }));
	assert.equal(accepted.bytes(), 4);
	const overflow = __test.streamLimiter(3);
	await assert.rejects(
		pipeline(Readable.from([Buffer.from("12"), Buffer.from("34")]), overflow.limiter, new Writable({ write(_chunk, _encoding, done) { done(); } })),
		(error) => error.code === "file-too-large",
	);
});

test("filesystem fallback is bounded, skips hidden/heavy trees, and never follows symlinks", async () => {
	const root = await fixture();
	try {
		await symlink(join(root, "src"), join(root, "src-link"));
		const index = await walkWorkspace(root, 100, 1);
		assert.ok(index.files.includes("README.md"));
		assert.ok(index.files.includes("src/main.js"));
		assert.ok(!index.files.includes("src/deep/nested.js"), "depth limit is enforced");
		assert.ok(!index.files.some((path) => path.startsWith("node_modules/") || path.startsWith(".secret/") || path.startsWith("src-link/")));
		const capped = await walkWorkspace(root, 2, 32);
		assert.equal(capped.truncated, true);
		assert.ok(capped.files.length + capped.dirs.length <= 2);
	} finally {
		await rm(root, { recursive: true, force: true });
	}
});

test("Git index includes tracked and untracked non-ignored files, excludes ignored and deleted", async () => {
	const root = await mkdtemp(join(tmpdir(), "dsh-file-mention-git-"));
	try {
		await run("git", ["init", "--quiet"], { cwd: root });
		await writeFile(join(root, ".gitignore"), "ignored.txt\n");
		await writeFile(join(root, "tracked.txt"), "tracked\n");
		await writeFile(join(root, "new.txt"), "new\n");
		await writeFile(join(root, "ignored.txt"), "ignored\n");
		await run("git", ["add", ".gitignore", "tracked.txt"], { cwd: root });
		await rm(join(root, "tracked.txt"));
		const index = await buildWorkspaceIndex(root);
		assert.equal(index.strategy, "git");
		assert.ok(index.files.includes("new.txt"));
		assert.ok(index.files.includes(".gitignore"));
		assert.ok(!index.files.includes("ignored.txt"));
		assert.ok(!index.files.includes("tracked.txt"));
	} finally {
		await rm(root, { recursive: true, force: true });
	}
});

test("Git index adds ignored files selected by .aiinclude and reports metadata/version inputs", async () => {
	const root = await mkdtemp(join(tmpdir(), "dsh-file-mention-aiinclude-"));
	try {
		await run("git", ["init", "--quiet"], { cwd: root });
		await mkdir(join(root, "generated"), { recursive: true });
		await writeFile(join(root, ".gitignore"), "generated/\n");
		await writeFile(join(root, ".aiinclude"), "generated/**/*.md\n!generated/private/**\n");
		await writeFile(join(root, "generated", "kept.md"), "kept\n");
		await mkdir(join(root, "generated", "private"), { recursive: true });
		await writeFile(join(root, "generated", "private", "secret.md"), "secret\n");
		await run("git", ["add", ".gitignore", ".aiinclude"], { cwd: root });
		const index = await buildWorkspaceIndex(root, { maxEntries: 100, ignoreRules: [] });
		assert.ok(index.files.includes("generated/kept.md"));
		assert.ok(!index.files.includes("generated/private/secret.md"));
		const kept = index.entries.find((entry) => entry.relative === "generated/kept.md");
		assert.equal(typeof kept.mtimeMs, "number");
		assert.ok(index.aiincludeFiles.includes(".aiinclude"));
	} finally {
		await rm(root, { recursive: true, force: true });
	}
});

test("index generations are cached and monotonic after precise invalidation", async () => {
	const root = await mkdtemp(join(tmpdir(), "dsh-file-mention-version-"));
	try {
		await writeFile(join(root, "a.txt"), "a");
		const first = await __test.indexOf(root, normalizeSettings());
		const cached = await __test.indexOf(root, normalizeSettings());
		assert.equal(cached.indexVersion, first.indexVersion);
		invalidateIndex(root);
		const rebuilt = await __test.indexOf(root, normalizeSettings());
		assert.ok(rebuilt.indexVersion > first.indexVersion);
	} finally {
		invalidateIndex(root);
		await rm(root, { recursive: true, force: true });
	}
});

test("upload retention removes expired files and preserves fresh files", async () => {
	const root = await mkdtemp(join(tmpdir(), "dsh-file-mention-retention-"));
	try {
		const old = join(root, "old.txt");
		const fresh = join(root, "fresh.txt");
		await writeFile(old, "old");
		await writeFile(fresh, "fresh");
		const now = Date.now();
		await utimes(old, new Date(now - 10 * 86_400_000), new Date(now - 10 * 86_400_000));
		assert.equal(await cleanupUploads(root, 7, now), 1);
		await assert.rejects(realpath(old));
		assert.equal(await realpath(fresh), join(await realpath(root), "fresh.txt"));
	} finally {
		await rm(root, { recursive: true, force: true });
	}
});

test("pre-step injects validated workspace and managed-upload markers only", async () => {
	const workspace = await fixture("dsh-file-mention-step-");
	const uploadRoot = await mkdtemp(join(tmpdir(), "dsh-file-mention-upload-"));
	const outside = await mkdtemp(join(tmpdir(), "dsh-file-mention-outside-"));
	try {
		await writeFile(join(uploadRoot, "drop.txt"), "upload\n");
		await writeFile(join(outside, "secret.txt"), "outside\n");
		const messages = [{
			role: "user",
			source: { kind: "user" },
			content: [{ type: "text", text: `review @src/main.js @"space name.txt" @${join(uploadRoot, "drop.txt")} @${join(outside, "secret.txt")}` }],
		}, {
			role: "user",
			source: { kind: "plugin", plugin: "untrusted" },
			content: [{ type: "text", text: "@README.md" }],
		}];
		const downstream = { kind: "enter", messages: [{ role: "user", source: { kind: "user" }, content: [] }] };
		const decision = await mentionPreStep(workspace, uploadRoot, messages, new AbortController().signal, async () => downstream);
		assert.equal(decision.kind, "enter");
		assert.equal(decision.messages.length, 4);
		assert.deepEqual(decision.messages.slice(1).map((message) => message.source.relative), [
			"src/main.js",
			"space name.txt",
			join(await realpath(uploadRoot), "drop.txt"),
		]);
		assert.ok(decision.messages.slice(1).every((message) => !message.content[0].text.includes("upload\n")));
	} finally {
		await Promise.all([
			rm(workspace, { recursive: true, force: true }),
			rm(uploadRoot, { recursive: true, force: true }),
			rm(outside, { recursive: true, force: true }),
		]);
	}
});

test("pre-step passes reject decisions through unchanged", async () => {
	const decision = await mentionPreStep("/tmp", "/tmp/uploads", [], new AbortController().signal, async () => ({ kind: "reject" }));
	assert.deepEqual(decision, { kind: "reject" });
});

test("realpath-form tokens pass the lexical gate when a root sits behind a symlink", async () => {
	const real = await fixture("dsh-file-mention-real-");
	const holder = await fixture("dsh-file-mention-link-");
	const linkRoot = join(holder, "uploads");
	try {
		await symlink(real, linkRoot);
		await writeFile(join(real, "drop.txt"), "upload\n");
		const token = join(await realpath(real), "drop.txt");
		const reference = await __test.validatedReference("/nonexistent-cwd", linkRoot, token, new AbortController().signal);
		assert.deepEqual(reference, { path: token, kind: "file" });
	} finally {
		await Promise.all([
			rm(real, { recursive: true, force: true }),
			rm(holder, { recursive: true, force: true }),
		]);
	}
});
