import test from "node:test";
import assert from "node:assert/strict";

const registrations = [];
globalThis.window = { __ModuleLoader__: { load(spec) { registrations.push(spec); } } };
await import("../lib/client.js");

assert.equal(registrations.length, 1);
const react = {
	createElement: (...args) => ({ args }),
	useEffect: () => {},
	useSyncExternalStore: (_subscribe, snapshot) => snapshot(),
};
const client = registrations[0].factory((name) => {
	if (name === "react") return react;
	throw new Error(`unexpected client dependency: ${name}`);
});
const t = client.__test;

test("client exports the expected zero-build plugin shape", () => {
	assert.equal(registrations[0].id, "dsh-file-mention");
	assert.equal(typeof client.apply, "function");
	assert.deepEqual(client.inject, ["inputTriggers", "sessions", "locale", "slots"]);
});

test("Traditional Chinese and English UI labels stay distinct", () => {
	assert.equal(t.dictionaries.zh["settings.nav"], "檔案提及");
	assert.equal(t.dictionaries.zh["settings.title"], "檔案提及控制中心");
	assert.equal(t.dictionaries.zh["dock.title"], "引用匣");
	assert.equal(t.dictionaries.en["settings.nav"], "File mentions");
	assert.equal(t.dictionaries.en["settings.title"], "File Mention Control Center");
	assert.notEqual(t.dictionaries.zh["settings.statusUnavailable"], t.dictionaries.en["settings.statusUnavailable"]);
	assert.notEqual(t.dictionaries.zh["settings.pasteUpload"], t.dictionaries.en["settings.pasteUpload"]);
	assert.equal(typeof t.dictionaries.zh["settings.pasteUpload"], "string");
});

test("path label helpers preserve directory semantics", () => {
	assert.equal(t.basenameOf("src/app/main.js"), "main.js");
	assert.equal(t.basenameOf("src/app/"), "app");
	assert.equal(t.dirnameOf("src/app/main.js"), "src/app");
	assert.equal(t.dirnameOf("README.md"), "");
});

test("local ranking prioritizes exact basename, prefix, substring, and path queries", () => {
	const entries = [
		{ relative: "src/main.js", kind: "file" },
		{ relative: "docs/main.md", kind: "file" },
		{ relative: "src/components/main-view.tsx", kind: "file" },
		{ relative: "docs/", kind: "dir" },
	];
	assert.deepEqual(t.rankEntries(entries, "main").map((entry) => entry.relative), [
		"docs/main.md",
		"src/main.js",
		"src/components/main-view.tsx",
	]);
	assert.deepEqual(t.rankEntries(entries, "components/main").map((entry) => entry.relative), ["src/components/main-view.tsx"]);
	assert.deepEqual(t.rankEntries(entries, "zzz"), []);
	assert.equal(t.rankEntries(Array.from({ length: 80 }, (_v, index) => ({ relative: `f${index}.txt`, kind: "file" })), "f").length, 40);
	assert.deepEqual(t.rankEntries(entries, "main", 40, { "src/main.js": { count: 5 } }).map((entry) => entry.relative).slice(0, 2), [
		"src/main.js", "docs/main.md",
	]);
});

test("mentionText quotes whitespace paths and escapes quote/backslash characters", () => {
	assert.equal(t.mentionText("src/main.js"), "@src/main.js ");
	assert.equal(t.mentionText("docs/space name.md"), '@"docs/space name.md" ');
	assert.equal(t.mentionText('docs/a"b.md'), '@"docs/a\\"b.md" ');
});

test("pasted mentions are invisibly protected and dock parsing supports quoted paths", () => {
	assert.equal(t.protectPastedMentions("see @src/a.js and mail a@b.test"), "see @\u2060src/a.js and mail a@\u2060b.test");
	assert.deepEqual(t.draftMentions('see @src/a.js @"space name.md" @\u2060pasted.md').map((row) => row.relative), [
		"src/a.js", "space name.md",
	]);
	assert.equal(t.withoutToken("a @src/a.js b", 2, 11), "a  b");
	const repeated = t.draftMentions("@src/a.js and @docs/");
	assert.deepEqual(repeated.map((row) => row.kind), ["file", "dir"]);
	assert.equal(t.withoutMentions("@src/a.js and @docs/", repeated), " and");
});

test("registered source warms one index, ranks files and folders, and inserts full paths", async () => {
	let source;
	const effects = [];
	const slots = [];
	const ctx = {
		locale: { register: () => () => {}, bind: () => (key) => key },
		inputTriggers: { registerSource(value) { source = value; return () => {}; } },
		slots: {
			inject(_name, callback) { callback(); },
			register(options, component) { slots.push({ options, component }); return () => {}; },
		},
		sessions: {
			list: { getSnapshot: () => ({ current: "s1", byId: { s1: { cwd: "/workspace" } } }) },
			scope: (id) => ({ id }),
		},
		effect(fn, label) { effects.push({ fn, label }); },
		on() {},
	};
	client.apply(ctx);
	assert.deepEqual(slots.map((slot) => slot.options.name), [
		"conversation.input.dock", "settings.section", "conversation.chat.turnTail", "shell.overlay",
	]);
	effects.find((effect) => effect.label === "file-mention: source").fn();

	let requests = 0;
	globalThis.fetch = async (url, init) => {
		requests += 1;
		assert.equal(url, "/api/file-mention/index");
		assert.deepEqual(JSON.parse(init.body), { sessionId: "s1" });
		return {
			ok: true,
			status: 200,
			json: async () => ({
				ok: true,
				value: { files: ["README.md", "src/main.js", "docs/space name.md"], dirs: ["src/", "docs/"], strategy: "git" },
			}),
		};
	};

	const session = { sessionId: "s1" };
	source.warm(session);
	const rows = await source.candidates(session, { query: "main", signal: new AbortController().signal });
	assert.equal(requests, 1, "warm and candidate share one in-flight request");
	assert.deepEqual(rows.map((row) => [row.name, row.description, row.value]), [["main.js", "src", "src/main.js"]]);
	const folders = await source.candidates(session, { query: "doc", signal: new AbortController().signal });
	const folder = folders.find((row) => row.name === "docs/" && row.kind === "dir");
	assert.ok(folder);
	assert.deepEqual(source.onPick({ candidate: folder }), { text: "@docs/ " });
	assert.deepEqual(source.onPick({ candidate: rows[0] }), { text: "@src/main.js " });
	const spaced = (await source.candidates(session, { query: "space", signal: new AbortController().signal }))[0];
	assert.deepEqual(source.onPick({ candidate: spaced }), { text: '@"docs/space name.md" ' });
	assert.ok(source.lexicon(session).includes("src/main.js"));
});

test("pasted-file claim mirrors the image rail's media-type gate", () => {
	assert.equal(t.claimsPastedFiles([]), false);
	assert.equal(t.claimsPastedFiles([{ type: "image/png" }, { type: "image/gif" }]), false);
	assert.equal(t.claimsPastedFiles([{ type: "application/pdf" }]), true);
	assert.equal(t.claimsPastedFiles([{ type: "image/png" }, { type: "application/zip" }]), true);
	assert.equal(t.claimsPastedFiles([{ type: "image/svg+xml" }]), true, "non-rail image types are claimed");
});

test("insertion point snaps out of @tokens", () => {
	const draft = "see @src/main.js and more";
	const inside = draft.indexOf("main");
	assert.equal(t.snapInsertionPoint(draft, inside), draft.indexOf(" and"), "caret inside a mention lands after it");
	assert.equal(t.snapInsertionPoint(draft, 4), 4, "caret at a token start stays put");
	assert.equal(t.snapInsertionPoint(draft, 0), 0);
	assert.equal(t.snapInsertionPoint(draft, 999), draft.length, "offset clamps to the draft length");
	const quoted = 'ref @"docs/space name.md" tail';
	assert.equal(t.snapInsertionPoint(quoted, 10), quoted.indexOf(" tail"), "quoted mentions snap as one token");
});

test("insertion text keeps the newline block at draft end and inlines elsewhere", () => {
	const refs = ["@/u/a.pdf", "@/u/b.pdf"];
	assert.deepEqual(t.insertionTextFor(refs, "", 0), { at: 0, insert: "@/u/a.pdf\n@/u/b.pdf\n" });
	assert.deepEqual(t.insertionTextFor(refs, "draft", 5), { at: 5, insert: "\n@/u/a.pdf\n@/u/b.pdf\n" });
	assert.deepEqual(t.insertionTextFor(refs, "line\n", 5), { at: 5, insert: "@/u/a.pdf\n@/u/b.pdf\n" });
	assert.deepEqual(t.insertionTextFor(["@/u/a.pdf"], "before  after", 7), { at: 7, insert: "@/u/a.pdf " }, "mid-draft after whitespace needs no lead");
	assert.deepEqual(t.insertionTextFor(["@/u/a.pdf"], "before after", 6), { at: 6, insert: " @/u/a.pdf " }, "mid-draft after a word gains a leading space");
	const draft = "see @src/main.js tail";
	assert.deepEqual(t.insertionTextFor(["@/u/a.pdf"], draft, draft.indexOf("main")), { at: draft.indexOf(" tail"), insert: " @/u/a.pdf " }, "snap applies before separator math");
});

test("caret remaps across edits via common prefix/suffix scan", () => {
	assert.equal(t.remapOffset("hello world", "hello brave world", 3), 3, "caret before the edit is stable");
	assert.equal(t.remapOffset("hello world", "hello brave world", 8), 14, "pure insertions always map (suffix shift)");
	assert.equal(t.remapOffset("hello world", "hexxo world", 3), undefined, "caret inside a replaced region has no mapping");
	assert.equal(t.remapOffset("hello world", "hi world", 9), 6, "caret in the common suffix shifts by the delta");
	assert.equal(t.remapOffset("abc", "abc", 2), 2);
	assert.equal(t.remapOffset("abc", "", 1), undefined);
	assert.equal(t.remapOffset("", "abc", 0), 0);
});
