import test from "node:test";
import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import http from "node:http";
import { mkdtemp, readFile, realpath, rm, stat, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { basename, join } from "node:path";
import { promisify } from "node:util";

import { DEFAULT_SETTINGS, PASTED_MENTION_MARKER, apply, invalidateIndex, normalizeSettings } from "../lib/index.js";

const run = promisify(execFile);

/** Minimal Cordis ctx shape covering everything apply() touches. */
function createMockCtx({ home, sessions, persistence, trustedHosts = [] }) {
	const routes = [];
	const hooks = new Map();
	const disposals = [];
	return {
		routes,
		hooks,
		disposals,
		ctx: {
			effect(setup) {
				const dispose = setup();
				if (typeof dispose === "function") disposals.push(dispose);
			},
			webServer: { register(route) { routes.push(route); return () => {}; } },
			dshHomePath: (rel) => join(home, rel),
			sessions: { get: (id) => sessions.get(id) },
			webRuntime: { trustedHosts },
			get: (name) => (name === "sessionPersistence" ? persistence : undefined),
			on(event, listener) {
				hooks.set(event, [...(hooks.get(event) ?? []), listener]);
				return () => {};
			},
		},
	};
}

function createAgentCtx() {
	const hooks = new Map();
	const disposals = [];
	return {
		hooks,
		disposals,
		ctx: {
			effect(setup) {
				const dispose = setup();
				if (typeof dispose === "function") disposals.push(dispose);
			},
			on(event, listener) {
				hooks.set(event, [...(hooks.get(event) ?? []), listener]);
				return () => {};
			},
		},
	};
}

test("host end-to-end HTTP flows over the real apply()", async (t) => {
	const home = await mkdtemp(join(tmpdir(), "dsh-fm-e2e-home-"));
	const workspace = await mkdtemp(join(tmpdir(), "dsh-fm-e2e-ws-"));
	const coldWorkspace = await mkdtemp(join(tmpdir(), "dsh-fm-e2e-cold-"));
	await writeFile(join(workspace, "README.md"), "# fixture\n");
	await writeFile(join(workspace, "src.js"), "export {};\n");
	await writeFile(join(coldWorkspace, "cold.md"), "# cold\n");
	await run("git", ["init", "--quiet"], { cwd: workspace });

	const sessions = new Map([["session-live", { header: { cwd: workspace } }]]);
	const persistence = { list: async () => [{ id: "session-cold", cwd: coldWorkspace }] };
	const mock = createMockCtx({ home, sessions, persistence });
	apply(mock.ctx);

	const server = http.createServer((req, res) => {
		const route = mock.routes.find((entry) => entry.kind === "prefix" && req.url.startsWith(entry.path));
		if (route === undefined) {
			res.statusCode = 404;
			res.end();
			return;
		}
		void route.handler(req, res);
	});
	await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
	const base = `http://127.0.0.1:${server.address().port}`;
	const post = async (path, body, headers = {}) => {
		const response = await fetch(base + path, {
			method: "POST",
			headers: { "content-type": "application/json", ...headers },
			body: JSON.stringify(body ?? {}),
		});
		return { status: response.status, data: await response.json().catch(() => null) };
	};

	const agent = createAgentCtx();
	try {
		await t.test("route mounting registers one prefix route and the agent hook", () => {
			assert.equal(mock.routes.length, 1);
			assert.equal(mock.routes[0].kind, "prefix");
			assert.equal(mock.routes[0].path, "/api/file-mention");
			assert.equal(mock.hooks.has("agent/created"), true);
		});

		await t.test("cross-site requests are fenced with 403", async () => {
			const { status, data } = await post("/api/file-mention/status", { sessionId: "session-live" },
				{ origin: "http://evil.test", "sec-fetch-site": "cross-site" });
			assert.equal(status, 403);
			assert.equal(data.error.code, "forbidden");
		});

		await t.test("settings load defaults and persist writes", async () => {
			const loaded = await post("/api/file-mention/settings", {});
			assert.equal(loaded.status, 200);
			assert.deepEqual(loaded.data.value, normalizeSettings());
			assert.equal(loaded.data.value.uploadPastedFiles, true);

			const written = await post("/api/file-mention/settings", { settings: { uploadPastedFiles: false } });
			assert.equal(written.data.value.uploadPastedFiles, false);
			const disk = JSON.parse(await readFile(join(home, "storages", "dsh-file-mention", "settings.json"), "utf8"));
			assert.equal(disk.uploadPastedFiles, false);

			const restored = await post("/api/file-mention/settings", { settings: {} });
			assert.deepEqual(restored.data.value, { ...DEFAULT_SETTINGS });
		});

		await t.test("index resolves live and cold sessions and rejects unknown ones", async () => {
			const live = await post("/api/file-mention/index", { sessionId: "session-live" });
			assert.equal(live.status, 200);
			assert.equal(["git", "walk"].includes(live.data.value.strategy), true);
			assert.equal(live.data.value.files.includes("README.md"), true);
			assert.equal(live.data.value.files.includes("src.js"), true);

			const cold = await post("/api/file-mention/index", { sessionId: "session-cold" });
			assert.equal(cold.status, 200);
			assert.equal(cold.data.value.files.includes("cold.md"), true);

			const unknown = await post("/api/file-mention/index", { sessionId: "session-none" });
			assert.equal(unknown.status, 404);
			assert.equal(unknown.data.error.code, "unknown-session");
		});

		await t.test("status aggregates without path details and maintenance validates actions", async () => {
			const status = await post("/api/file-mention/status", { sessionId: "session-live" });
			assert.equal(status.status, 200);
			assert.equal(status.data.value.workspace, basename(workspace));
			assert.equal(JSON.stringify(status.data.value).includes(workspace), false, "no absolute workspace path leaks");
			assert.equal(typeof status.data.value.index.files, "number");
			assert.equal(status.data.value.uploads.fileLimitBytes, DEFAULT_SETTINGS.uploadFileLimitBytes);

			const rebuilt = await post("/api/file-mention/maintenance", { sessionId: "session-live", action: "rebuild-index" });
			assert.equal(rebuilt.status, 200);
			assert.equal(rebuilt.data.value.workspace, basename(workspace));

			const invalid = await post("/api/file-mention/maintenance", { sessionId: "session-live", action: "nope" });
			assert.equal(invalid.status, 400);
			assert.equal(invalid.data.error.code, "invalid-action");
		});

		let uploadedPath;
		await t.test("upload streams, sanitizes names, resolves realpath, and refuses bad sessions", async () => {
			const body = Buffer.from("uploaded bytes\n");
			const url = `/api/file-mention/upload?sessionId=session-live&name=${encodeURIComponent("../evil name.txt")}`;
			const first = await fetch(base + url, { method: "POST", headers: { "content-type": "application/octet-stream" }, body });
			const firstData = await first.json();
			assert.equal(first.status, 200);
			assert.equal(basename(firstData.value.path), "evil_name.txt");
			assert.equal(firstData.value.bytes, body.length);
			const expected = join(await realpath(join(home, "uploads", "session-live")), "evil_name.txt");
			assert.equal(firstData.value.path, expected, "upload responses carry the realpath");
			assert.equal(await readFile(firstData.value.path, "utf8"), "uploaded bytes\n");
			assert.equal((await stat(firstData.value.path)).mode & 0o777, 0o600);
			uploadedPath = firstData.value.path;

			const second = await fetch(base + url, { method: "POST", headers: { "content-type": "application/octet-stream" }, body });
			const secondData = await second.json();
			assert.equal(basename(secondData.value.path), "evil_name (2).txt", "no-clobber rename");

			const bad = await fetch(`${base}/api/file-mention/upload?sessionId=${encodeURIComponent("../../etc")}&name=a.txt`, {
				method: "POST", headers: { "content-type": "application/octet-stream" }, body,
			});
			assert.equal(bad.status, 400);
			assert.equal((await bad.json()).error.code, "invalid-session");
		});

		await t.test("path-action checks workspace and managed paths and rejects escapes", async () => {
			const inside = await post("/api/file-mention/path-action", { sessionId: "session-live", path: "src.js", action: "check" });
			assert.equal(inside.status, 200);
			assert.deepEqual(inside.data.value, { path: "src.js", kind: "file" });

			const managed = await post("/api/file-mention/path-action", { sessionId: "session-live", path: uploadedPath, action: "check" });
			assert.equal(managed.status, 200);
			assert.equal(managed.data.value.path, uploadedPath, "check echoes the same realpath string");

			const outside = await post("/api/file-mention/path-action", { sessionId: "session-live", path: "/etc/passwd", action: "check" });
			assert.equal(outside.status, 404);
			assert.equal(outside.data.error.code, "invalid-path");
		});

		await t.test("pre-step injects markers matching the upload response byte-for-byte", async () => {
			for (const listener of mock.hooks.get("agent/created")) {
				listener({ agent: { session: { header: { cwd: workspace } }, ctx: agent.ctx } });
			}
			const preSteps = agent.hooks.get("agent/pre-step");
			assert.equal(Array.isArray(preSteps) && preSteps.length === 1, true);
			const messages = [{
				role: "user",
				source: { kind: "user" },
				content: [{ type: "text", text: `review @src.js @${uploadedPath} keep@${PASTED_MENTION_MARKER}pasted` }],
			}];
			const downstream = { kind: "enter", messages: [...messages] };
			const decision = await preSteps[0]({ messages, signal: new AbortController().signal }, async () => downstream);
			assert.equal(decision.kind, "enter");
			const injected = decision.messages.slice(1);
			assert.deepEqual(injected.map((message) => message.source.relative), ["src.js", uploadedPath]);
			assert.equal(injected[0].content[0].text.includes('<workspace-reference path="src.js"'), true);
			assert.equal(injected[1].content[0].text.includes(`path="${uploadedPath}"`), true);
			assert.equal(decision.messages[0].content[0].text.includes(PASTED_MENTION_MARKER), false, "pasted markers are stripped");
		});
	} finally {
		for (const dispose of [...agent.disposals, ...mock.disposals]) {
			try { dispose(); } catch { /* already closed */ }
		}
		await new Promise((resolve) => server.close(resolve));
		invalidateIndex();
		await Promise.all([
			rm(home, { recursive: true, force: true }),
			rm(workspace, { recursive: true, force: true }),
			rm(coldWorkspace, { recursive: true, force: true }),
		]);
	}
});
