export function createStatusClient(require, styles) {
	const React = require("react");
	const { createPortal } = require("react-dom");
	const { Button, SegmentedControl, IconWarningOutlineRegular, useAnchoredPosition, useDismissOnOutsidePointer } = require("@deepseek-ai/dsh-client-ui-primitives");
	const { RemoteSnapshotStream, RemoteStreamCarrierError } = require("@deepseek-ai/dsh-api-gateway/client");
	const h = React.createElement;
	async function resultValue(request) {
		const result = await request;
		if (!result.ok) throw new Error(result.error.message);
		return result.value;
	}
	const locale = "layered-memory-status";
	const dictionaries = {
		zh: {
			"retrySchedule": "自动整理计划", "nextEligibleAt": "最早可重试时间", "retryCount": "连续退避 {count} 次", "retryReason": "原因", "retry-failed": "运行失败", "retry-timeout": "运行超时", "retry-deferred": "尚未完成", "retry-no_progress": "本轮无进展", "retry-interrupted": "运行中断", "retry-user_stopped": "本次已停止", "retry-cooldown": "共享冷却",
			reviewing: "正在核对记忆", organizing: "正在整理记忆", changed: "记忆已整理 {count} 条",
			settled: "记忆核对完成", awaitingEvidence: "记忆等待补充证据", idle: "记忆待命", initializing: "记忆状态加载中",
			stoppedReview: "记忆核对已停止", stoppedBatch: "记忆整理已停止",
			failed: "上次记忆核对未完成", partial: "记忆已整理 {count} 条 · 上次核对未完成", details: "查看记忆活动",
			unavailable: "记忆状态暂不可用", concurrent: "还有 {count} 项记忆任务运行中",
			activity: "记忆活动", runs: "运行记录", current: "当前任务", reviewWorker: "核对会话", batchWorker: "整理会话",
			review: "本轮核对", batch: "批量整理", legacy: "旧记录", empty: "还没有维护记录", historyEmpty: "暂无可显示的记录",
			loading: "正在读取…", refresh: "更新", older: "更早记录", stopping: "停止中…", stop: "停止", notStarted: "尚未开始",
			changedCount: "变更 {count} 条", retainedCount: "保留 {count} 条", waitingCount: "待证据 {count} 条", remainingCount: "未完成 {count} 条",
			"phase-preparing": "准备中", "phase-compacting": "压缩会话", "phase-running": "执行中", "phase-finishing": "保存结果", "phase-stopping": "正在停止", "phase-stopped": "已停止",
			"state-running": "运行中", "state-reviewed": "已完成", "state-unchanged": "无需更新", "state-waiting_evidence": "等待证据", "state-deferred": "未完成", "state-failed": "失败", "state-idle": "空闲", "state-stopped": "已停止",
			"trace-assistant": "回复", "trace-reasoning": "思考", "trace-tool": "工具调用", "trace-result": "工具结果", "trace-notice": "运行事件",
		},
		en: {
			"retrySchedule": "Organization schedule", "nextEligibleAt": "Next eligible time", "retryCount": "Backoff count: {count}", "retryReason": "Reason", "retry-failed": "Run failed", "retry-timeout": "Run timed out", "retry-deferred": "Incomplete", "retry-no_progress": "No progress", "retry-interrupted": "Run interrupted", "retry-user_stopped": "Current run stopped", "retry-cooldown": "Shared cooldown",
			reviewing: "Reviewing memory", organizing: "Organizing memory", changed: "Organized {count} memory entries",
			settled: "Memory review complete", awaitingEvidence: "Memory awaiting evidence", idle: "Memory ready", initializing: "Loading memory status",
			stoppedReview: "Memory review stopped", stoppedBatch: "Memory organization stopped",
			failed: "Last memory review incomplete", partial: "Organized {count} entries · last review incomplete", details: "View memory activity",
			unavailable: "Memory status unavailable", concurrent: "{count} more memory tasks running",
			activity: "Memory activity", runs: "Runs", current: "Current task", reviewWorker: "Review session", batchWorker: "Organization session",
			review: "Turn review", batch: "Memory organization", legacy: "Legacy", empty: "No maintenance runs yet", historyEmpty: "No records to display",
			loading: "Loading…", refresh: "Refresh", older: "Earlier records", stopping: "Stopping…", stop: "Stop", notStarted: "Not started",
			changedCount: "{count} changed", retainedCount: "{count} retained", waitingCount: "{count} awaiting evidence", remainingCount: "{count} remaining",
			"phase-preparing": "Preparing", "phase-compacting": "Compacting session", "phase-running": "Running", "phase-finishing": "Saving results", "phase-stopping": "Stopping", "phase-stopped": "Stopped",
			"state-running": "Running", "state-reviewed": "Completed", "state-unchanged": "No changes needed", "state-waiting_evidence": "Awaiting evidence", "state-deferred": "Incomplete", "state-failed": "Failed", "state-idle": "Idle", "state-stopped": "Stopped",
			"trace-assistant": "Reply", "trace-reasoning": "Thinking", "trace-tool": "Tool call", "trace-result": "Tool result", "trace-notice": "Run event",
		},
		ja: {
			"retrySchedule": "整理の再実行予定", "nextEligibleAt": "次回実行可能時刻", "retryCount": "連続待機 {count} 回", "retryReason": "理由", "retry-failed": "実行失敗", "retry-timeout": "実行タイムアウト", "retry-deferred": "未完了", "retry-no_progress": "進展なし", "retry-interrupted": "実行中断", "retry-user_stopped": "今回の実行を停止", "retry-cooldown": "共通クールダウン",
			"reviewing": "メモリを確認中", "organizing": "メモリを整理中", "changed": "メモリを {count} 件整理しました",
			"settled": "メモリ確認完了", "awaitingEvidence": "メモリは根拠待ち", "idle": "メモリ待機中", "initializing": "メモリ状態を読み込み中",
			"stoppedReview": "メモリ確認を停止しました", "stoppedBatch": "メモリ整理を停止しました",
			"failed": "前回のメモリ確認は未完了", "partial": "メモリを {count} 件整理 · 前回の確認は未完了", "details": "メモリ活動を表示",
			"unavailable": "メモリ状態は利用できません", "concurrent": "他に {count} 件のメモリタスクが実行中",
			"activity": "メモリ活動", "runs": "実行記録", "current": "現在のタスク", "reviewWorker": "確認セッション", "batchWorker": "整理セッション",
			"review": "今回の確認", "batch": "一括整理", "legacy": "旧記録", "empty": "まだメンテナンス記録がありません", "historyEmpty": "表示できる記録がありません",
			"loading": "読み込み中…", "refresh": "更新", "older": "以前の記録", "stopping": "停止中…", "stop": "停止", "notStarted": "未開始",
			"changedCount": "変更 {count} 件", "retainedCount": "保持 {count} 件", "waitingCount": "根拠待ち {count} 件", "remainingCount": "未完了 {count} 件",
			"phase-preparing": "準備中", "phase-compacting": "セッションを圧縮", "phase-running": "実行中", "phase-finishing": "結果を保存", "phase-stopping": "停止中", "phase-stopped": "停止済み",
			"state-running": "実行中", "state-reviewed": "完了", "state-unchanged": "更新不要", "state-waiting_evidence": "根拠待ち", "state-deferred": "未完了", "state-failed": "失敗", "state-idle": "アイドル", "state-stopped": "停止済み",
			"trace-assistant": "返信", "trace-reasoning": "思考", "trace-tool": "ツール呼び出し", "trace-result": "ツール結果", "trace-notice": "実行イベント",
		},
		es: {
			"retrySchedule": "Plan de organización", "nextEligibleAt": "Próxima hora elegible", "retryCount": "Esperas consecutivas: {count}", "retryReason": "Motivo", "retry-failed": "Ejecución fallida", "retry-timeout": "Tiempo agotado", "retry-deferred": "Incompleto", "retry-no_progress": "Sin progreso", "retry-interrupted": "Ejecución interrumpida", "retry-user_stopped": "Ejecución actual detenida", "retry-cooldown": "Espera compartida",
			"reviewing": "Revisando memoria", "organizing": "Organizando memoria", "changed": "Se organizaron {count} entradas",
			"settled": "Revisión de memoria completa", "awaitingEvidence": "Memoria esperando evidencia", "idle": "Memoria lista", "initializing": "Cargando estado de memoria",
			"stoppedReview": "Revisión de memoria detenida", "stoppedBatch": "Organización detenida",
			"failed": "La última revisión quedó incompleta", "partial": "{count} entradas organizadas · última revisión incompleta", "details": "Ver actividad de memoria",
			"unavailable": "Estado de memoria no disponible", "concurrent": "{count} tareas de memoria en ejecución",
			"activity": "Actividad de memoria", "runs": "Ejecuciones", "current": "Tarea actual", "reviewWorker": "Sesión de revisión", "batchWorker": "Sesión de organización",
			"review": "Revisión del turno", "batch": "Organización por lotes", "legacy": "Histórico", "empty": "Aún no hay registros de mantenimiento", "historyEmpty": "No hay registros que mostrar",
			"loading": "Cargando…", "refresh": "Actualizar", "older": "Registros anteriores", "stopping": "Deteniendo…", "stop": "Detener", "notStarted": "Sin empezar",
			"changedCount": "{count} cambiadas", "retainedCount": "{count} retenidas", "waitingCount": "{count} esperando evidencia", "remainingCount": "{count} pendientes",
			"phase-preparing": "Preparando", "phase-compacting": "Compactando sesión", "phase-running": "En ejecución", "phase-finishing": "Guardando resultados", "phase-stopping": "Deteniendo", "phase-stopped": "Detenido",
			"state-running": "En ejecución", "state-reviewed": "Completado", "state-unchanged": "Sin cambios", "state-waiting_evidence": "Esperando evidencia", "state-deferred": "Incompleto", "state-failed": "Fallido", "state-idle": "Inactivo", "state-stopped": "Detenido",
			"trace-assistant": "Respuesta", "trace-reasoning": "Pensamiento", "trace-tool": "Llamada a herramienta", "trace-result": "Resultado de herramienta", "trace-notice": "Evento de ejecución",
		},
		fr: {
			"retrySchedule": "Plan d’organisation", "nextEligibleAt": "Prochaine heure admissible", "retryCount": "Attentes consécutives : {count}", "retryReason": "Motif", "retry-failed": "Échec de l’exécution", "retry-timeout": "Délai dépassé", "retry-deferred": "Incomplet", "retry-no_progress": "Aucun progrès", "retry-interrupted": "Exécution interrompue", "retry-user_stopped": "Exécution actuelle arrêtée", "retry-cooldown": "Délai partagé",
			"reviewing": "Vérification de la mémoire", "organizing": "Organisation de la mémoire", "changed": "{count} entrées organisées",
			"settled": "Vérification terminée", "awaitingEvidence": "Mémoire en attente de preuve", "idle": "Mémoire prête", "initializing": "Chargement de l’état",
			"stoppedReview": "Vérification arrêtée", "stoppedBatch": "Organisation arrêtée",
			"failed": "La dernière vérification est incomplète", "partial": "{count} entrées organisées · vérification incomplète", "details": "Voir l’activité",
			"unavailable": "État de la mémoire indisponible", "concurrent": "{count} autres tâches en cours",
			"activity": "Activité mémoire", "runs": "Exécutions", "current": "Tâche actuelle", "reviewWorker": "Session de vérification", "batchWorker": "Session d’organisation",
			"review": "Vérification du tour", "batch": "Organisation par lot", "legacy": "Anciens enregistrements", "empty": "Aucun entretien enregistré", "historyEmpty": "Aucun enregistrement à afficher",
			"loading": "Chargement…", "refresh": "Actualiser", "older": "Enregistrements antérieurs", "stopping": "Arrêt…", "stop": "Arrêter", "notStarted": "Non démarré",
			"changedCount": "{count} modifiées", "retainedCount": "{count} conservées", "waitingCount": "{count} en attente de preuve", "remainingCount": "{count} restantes",
			"phase-preparing": "Préparation", "phase-compacting": "Compactage de la session", "phase-running": "En cours", "phase-finishing": "Enregistrement des résultats", "phase-stopping": "Arrêt", "phase-stopped": "Arrêté",
			"state-running": "En cours", "state-reviewed": "Terminé", "state-unchanged": "Aucun changement", "state-waiting_evidence": "En attente de preuve", "state-deferred": "Incomplet", "state-failed": "Échec", "state-idle": "Inactif", "state-stopped": "Arrêté",
			"trace-assistant": "Réponse", "trace-reasoning": "Réflexion", "trace-tool": "Appel d’outil", "trace-result": "Résultat d’outil", "trace-notice": "Événement d’exécution",
		},
		de: {
			"retrySchedule": "Organisationsplan", "nextEligibleAt": "Nächster möglicher Start", "retryCount": "Wartefolgen: {count}", "retryReason": "Grund", "retry-failed": "Lauf fehlgeschlagen", "retry-timeout": "Zeitüberschreitung", "retry-deferred": "Unvollständig", "retry-no_progress": "Kein Fortschritt", "retry-interrupted": "Lauf unterbrochen", "retry-user_stopped": "Aktueller Lauf gestoppt", "retry-cooldown": "Gemeinsame Wartezeit",
			"reviewing": "Speicher wird geprüft", "organizing": "Speicher wird organisiert", "changed": "{count} Einträge organisiert",
			"settled": "Speicherprüfung abgeschlossen", "awaitingEvidence": "Speicher wartet auf Nachweis", "idle": "Speicher bereit", "initializing": "Speicherstatus wird geladen",
			"stoppedReview": "Speicherprüfung gestoppt", "stoppedBatch": "Speicherorganisation gestoppt",
			"failed": "Letzte Speicherprüfung unvollständig", "partial": "{count} Einträge organisiert · letzte Prüfung unvollständig", "details": "Speicheraktivität anzeigen",
			"unavailable": "Speicherstatus nicht verfügbar", "concurrent": "{count} weitere Speicheraufgaben laufen",
			"activity": "Speicheraktivität", "runs": "Läufe", "current": "Aktuelle Aufgabe", "reviewWorker": "Prüfsitzung", "batchWorker": "Organisationssitzung",
			"review": "Prüfung dieses Turns", "batch": "Sammelorganisation", "legacy": "Altbestand", "empty": "Noch keine Wartungsläufe", "historyEmpty": "Keine Einträge anzuzeigen",
			"loading": "Wird geladen…", "refresh": "Aktualisieren", "older": "Frühere Einträge", "stopping": "Wird gestoppt…", "stop": "Stoppen", "notStarted": "Nicht gestartet",
			"changedCount": "{count} geändert", "retainedCount": "{count} behalten", "waitingCount": "{count} warten auf Nachweis", "remainingCount": "{count} offen",
			"phase-preparing": "Vorbereitung", "phase-compacting": "Sitzung wird komprimiert", "phase-running": "Läuft", "phase-finishing": "Ergebnisse werden gespeichert", "phase-stopping": "Wird gestoppt", "phase-stopped": "Gestoppt",
			"state-running": "Läuft", "state-reviewed": "Abgeschlossen", "state-unchanged": "Keine Änderungen", "state-waiting_evidence": "Wartet auf Nachweis", "state-deferred": "Unvollständig", "state-failed": "Fehlgeschlagen", "state-idle": "Leerlauf", "state-stopped": "Gestoppt",
			"trace-assistant": "Antwort", "trace-reasoning": "Denken", "trace-tool": "Werkzeugaufruf", "trace-result": "Werkzeugergebnis", "trace-notice": "Laufereignis",
		},
		ru: {
			"retrySchedule": "План организации", "nextEligibleAt": "Следующее допустимое время", "retryCount": "Отсрочек подряд: {count}", "retryReason": "Причина", "retry-failed": "Сбой запуска", "retry-timeout": "Время истекло", "retry-deferred": "Не завершено", "retry-no_progress": "Нет прогресса", "retry-interrupted": "Запуск прерван", "retry-user_stopped": "Текущий запуск остановлен", "retry-cooldown": "Общая пауза",
			"reviewing": "Проверка памяти", "organizing": "Организация памяти", "changed": "Организовано {count} записей",
			"settled": "Проверка памяти завершена", "awaitingEvidence": "Память ждёт доказательств", "idle": "Память готова", "initializing": "Загрузка состояния памяти",
			"stoppedReview": "Проверка памяти остановлена", "stoppedBatch": "Организация остановлена",
			"failed": "Прошлая проверка не завершена", "partial": "Организовано {count} записей · проверка не завершена", "details": "Показать активность памяти",
			"unavailable": "Состояние памяти недоступно", "concurrent": "Ещё {count} задач памяти выполняется",
			"activity": "Активность памяти", "runs": "Запуски", "current": "Текущая задача", "reviewWorker": "Сеанс проверки", "batchWorker": "Сеанс организации",
			"review": "Проверка хода", "batch": "Пакетная организация", "legacy": "Старые записи", "empty": "Записей обслуживания пока нет", "historyEmpty": "Нет записей для отображения",
			"loading": "Загрузка…", "refresh": "Обновить", "older": "Ранние записи", "stopping": "Остановка…", "stop": "Остановить", "notStarted": "Не начато",
			"changedCount": "Изменено {count}", "retainedCount": "Сохранено {count}", "waitingCount": "Ждут доказательств {count}", "remainingCount": "Осталось {count}",
			"phase-preparing": "Подготовка", "phase-compacting": "Сжатие сеанса", "phase-running": "Выполнение", "phase-finishing": "Сохранение результатов", "phase-stopping": "Остановка", "phase-stopped": "Остановлено",
			"state-running": "Выполняется", "state-reviewed": "Завершено", "state-unchanged": "Без изменений", "state-waiting_evidence": "Ждёт доказательств", "state-deferred": "Не завершено", "state-failed": "Ошибка", "state-idle": "Простой", "state-stopped": "Остановлено",
			"trace-assistant": "Ответ", "trace-reasoning": "Размышление", "trace-tool": "Вызов инструмента", "trace-result": "Результат инструмента", "trace-notice": "Событие запуска",
		},
		pt: {
			"retrySchedule": "Plano de organização", "nextEligibleAt": "Próximo horário elegível", "retryCount": "Esperas consecutivas: {count}", "retryReason": "Motivo", "retry-failed": "Falha na execução", "retry-timeout": "Tempo esgotado", "retry-deferred": "Incompleto", "retry-no_progress": "Sem progresso", "retry-interrupted": "Execução interrompida", "retry-user_stopped": "Execução atual interrompida", "retry-cooldown": "Espera compartilhada",
			"reviewing": "Revisando memória", "organizing": "Organizando memória", "changed": "{count} entradas organizadas",
			"settled": "Revisão da memória concluída", "awaitingEvidence": "Memória aguardando evidência", "idle": "Memória pronta", "initializing": "Carregando estado da memória",
			"stoppedReview": "Revisão da memória interrompida", "stoppedBatch": "Organização interrompida",
			"failed": "A última revisão ficou incompleta", "partial": "{count} entradas organizadas · revisão incompleta", "details": "Ver atividade da memória",
			"unavailable": "Estado da memória indisponível", "concurrent": "Mais {count} tarefas de memória em execução",
			"activity": "Atividade da memória", "runs": "Execuções", "current": "Tarefa atual", "reviewWorker": "Sessão de revisão", "batchWorker": "Sessão de organização",
			"review": "Revisão do turno", "batch": "Organização em lote", "legacy": "Registros antigos", "empty": "Ainda não há registros de manutenção", "historyEmpty": "Sem registros para exibir",
			"loading": "Carregando…", "refresh": "Atualizar", "older": "Registros anteriores", "stopping": "Parando…", "stop": "Parar", "notStarted": "Não iniciado",
			"changedCount": "{count} alteradas", "retainedCount": "{count} mantidas", "waitingCount": "{count} aguardando evidência", "remainingCount": "{count} restantes",
			"phase-preparing": "Preparando", "phase-compacting": "Compactando sessão", "phase-running": "Em execução", "phase-finishing": "Salvando resultados", "phase-stopping": "Parando", "phase-stopped": "Parado",
			"state-running": "Em execução", "state-reviewed": "Concluído", "state-unchanged": "Sem alterações", "state-waiting_evidence": "Aguardando evidência", "state-deferred": "Incompleto", "state-failed": "Falhou", "state-idle": "Ocioso", "state-stopped": "Parado",
			"trace-assistant": "Resposta", "trace-reasoning": "Raciocínio", "trace-tool": "Chamada de ferramenta", "trace-result": "Resultado da ferramenta", "trace-notice": "Evento de execução",
		},
	};
	function createStore(remote, sessionId, stores) {
		let value = { snapshot: null, error: false };
		let stream;
		let closing = Promise.resolve();
		const listeners = new Set();
		const publish = next => { value = next; for (const listener of listeners) listener(); };
		const accept = frame => {
			const snapshot = parseActivityFrame(frame).snapshot;
			if (snapshot.parentSessionId !== sessionId) throw new Error("记忆状态所属会话不匹配");
			publish({ snapshot, error: false });
		};
		const fail = () => publish({ ...value, error: true });
		function start() {
			stores.add(store);
			stream = new RemoteSnapshotStream(remote.$stream({
				name: "layered memory status",
				open: signal => remote.layeredMemoryStatus.watch(sessionId, signal),
				ended: accepted => accepted ? new RemoteStreamCarrierError("记忆状态流已断开") : new Error("记忆状态流缺少初始快照"),
				carrierFailed: fail,
			}), { name: "layered memory status", isSnapshot: frame => frame.type === "snapshot", replace: accept, update: accept, failed: fail });
			stream.start();
		}
		function stop() {
			stores.delete(store);
			const current = stream;
			stream = undefined;
			if (current) closing = Promise.all([closing, current.dispose()]).then(() => undefined);
			return closing;
		}
		const store = {
			getSnapshot: () => value,
			async refresh(signal) { accept({ type: "update", snapshot: await resultValue(remote.layeredMemoryStatus.getSnapshot(sessionId, signal)) }); },
			subscribe(listener) {
				listeners.add(listener);
				if (listeners.size === 1) start();
				return () => { listeners.delete(listener); if (!listeners.size) void stop().catch(fail); };
			},
			dispose: stop,
		};
		return store;
	}
	function Brain() {
		return h("svg", { className: "lm-status-glyph", width: 14, height: 14, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.6, strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": true },
			h("path", { d: "M12 18V6a3 3 0 0 0-5.7-1.3A4 4 0 0 0 3 11a4 4 0 0 0 1.5 7.5A4 4 0 0 0 12 20a4 4 0 0 0 7.5-1.5A4 4 0 0 0 21 11a4 4 0 0 0-3.3-6.3A3 3 0 0 0 12 6" }),
			h("path", { d: "M8 8a3 3 0 0 1-3 3m14 0a3 3 0 0 1-3-3M8 16a3 3 0 0 0-3 2m14 0a3 3 0 0 0-3-2" }));
	}
	const time = value => new Date(value).toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
	function Counts({ run, t }) {
		return h("div", { className: "lm-run-counts" },
			h("span", null, t("changedCount", { count: run.changedEntries })),
			run.retainedEntries ? h("span", null, t("retainedCount", { count: run.retainedEntries })) : null,
			run.waitingEntries ? h("span", null, t("waitingCount", { count: run.waitingEntries })) : null,
			run.remainingEntries ? h("span", null, t("remainingCount", { count: run.remainingEntries })) : null);
	}
	function ActivityPanel({ open, snapshot, controls, panelRef, panelId, position, t }) {
		const [workers, setWorkers] = React.useState([]);
		const [workersError, setWorkersError] = React.useState(null);
		const [refresh, setRefresh] = React.useState(0);
		const [workerId, setWorkerId] = React.useState(null);
		const [history, setHistory] = React.useState({ page: null, busy: false, error: null });
		const [historyRevision, setHistoryRevision] = React.useState(0);
		const [stopping, setStopping] = React.useState(null);
		const [stopError, setStopError] = React.useState(null);
		const historyRequest = React.useRef(null);
		const stopRequest = React.useRef(null);
		const historyEnd = React.useRef(null);
		React.useEffect(() => {
			if (!open) return;
			const controller = new AbortController();
			controls.refresh(controller.signal).catch(error => { if (!controller.signal.aborted) setWorkersError(error.message); });
			return () => controller.abort();
		}, [open, controls]);
		React.useEffect(() => {
			if (!open) return;
			const controller = new AbortController();
			controls.list(controller.signal).then(value => { setWorkers(parseWorkers(value)); setWorkersError(null); }).catch(error => { if (!controller.signal.aborted) setWorkersError(error.message); });
			return () => controller.abort();
		}, [open, snapshot?.revision, refresh, controls]);
		React.useEffect(() => {
			if (!open || !workerId) return;
			const controller = new AbortController();
			historyRequest.current = controller;
			setHistory({ page: null, busy: true, error: null });
			controls.read(workerId, null, 60, controller.signal).then(value => setHistory({ page: parseWorkerHistory(value), busy: false, error: null })).catch(error => { if (!controller.signal.aborted) setHistory({ page: null, busy: false, error: error.message }); });
			return () => historyRequest.current.abort();
		}, [open, workerId, historyRevision, controls]);
		React.useEffect(() => { historyEnd.current?.scrollIntoView({ block: "nearest" }); }, [history.page?.nextOffset, workerId]);
		React.useEffect(() => () => stopRequest.current?.abort(), []);
		async function loadOlder() {
			const page = history.page;
			const offset = Math.max(page.minOffset, page.offset - 60);
			const controller = new AbortController();
			historyRequest.current = controller;
			setHistory(value => ({ ...value, busy: true, error: null }));
			try {
				const earlier = parseWorkerHistory(await controls.read(workerId, offset, page.offset - offset, controller.signal));
				setHistory({ page: { ...page, rows: [...earlier.rows, ...page.rows], offset: earlier.offset, hasPrevious: earlier.hasPrevious }, busy: false, error: null });
			} catch (error) { if (!controller.signal.aborted) setHistory(value => ({ ...value, busy: false, error: error.message })); }
		}
		async function stop(worker) {
			const controller = new AbortController();
			stopRequest.current = controller;
			setStopping(worker.id);
			setStopError(null);
			try { await controls.stop(worker.id, controller.signal); setRefresh(value => value + 1); }
			catch (error) { if (!controller.signal.aborted) setStopError(error.message); }
			finally { setStopping(null); }
		}
		function stopButton(worker) {
			return worker?.canStop ? h(Button, { variant: "ghost", size: "sm", className: "lm-stop", disabled: Boolean(stopping), onClick: () => stop(worker), "data-memory-stop": worker.purpose }, stopping === worker.id ? t("stopping") : t("stop")) : null;
		}
		function runBody(run) {
			return h(React.Fragment, null, h(Counts, { run, t }), run.summary ? h("p", { className: "lm-run-summary" }, run.summary) : null);
		}
		const worker = workers.find(value => value.id === workerId);
		const finished = snapshot?.records.filter(run => run.finishedAt !== null) || [];
		const retries = snapshot?.reflection.filter(state => state.nextEligibleAt || state.retryCount || state.retryReason) || [];
		const retryRows = retries.map(state => h("details", { key: "retry-" + state.namespace, className: "lm-finished-run", "data-memory-retry": true, "data-namespace": state.namespace },
			h("summary", null,
				h("span", null, t("retrySchedule")),
				state.retryReason ? h("span", { className: "lm-run-state", "data-state": state.retryReason }, t("retry-" + state.retryReason)) : null,
				state.retryCount > 0 ? h("span", { className: "lm-run-state" }, t("retryCount", { count: state.retryCount })) : null,
				state.nextEligibleAt ? h("time", { dateTime: state.nextEligibleAt, title: state.nextEligibleAt }, time(state.nextEligibleAt)) : null),
			h("div", { className: "lm-run-counts" },
				h("span", null, state.namespace),
				state.nextEligibleAt ? h("span", null, t("nextEligibleAt"), " ", time(state.nextEligibleAt)) : null)));
		const view = workerId || "runs";
		const tabsId = panelId + "-views";
		return h("div", { ref: panelRef, id: panelId, role: "dialog", "aria-label": t("activity"), className: "lm-activity-panel", "data-memory-details": true, style: position || { visibility: "hidden", left: 0, top: 0 } },
			h("header", { className: "lm-activity-heading" },
				h("span", { className: "lm-activity-title" }, h(Brain), t("activity"))),
			h("div", { className: "lm-activity-rule", "aria-hidden": true }),
			h(SegmentedControl, {
				id: tabsId, value: view, label: t("activity"), className: "lm-activity-tabs",
				onChange: value => setWorkerId(value === "runs" ? null : value),
				options: [{ value: "runs", label: t("runs") }, ...workers.map(value => ({ value: value.id || value.purpose, label: t(value.purpose === "turn_review" ? "reviewWorker" : "batchWorker"), disabled: !value.id, title: value.id ? undefined : t("notStarted") }))],
			}),
			workersError ? h("p", { className: "lm-activity-error", role: "alert" }, workersError) : null,
			stopError ? h("p", { className: "lm-activity-error", role: "alert" }, stopError) : null,
			h("div", { className: "lm-activity-body", role: "tabpanel", id: tabsId + "-" + view + "-panel", "aria-labelledby": tabsId + "-" + view },
			workerId === null ? h("div", { className: "lm-activity-content" },
				snapshot?.running.length ? h("section", { className: "lm-current-runs" }, h("h3", null, t("current")), ...snapshot.running.map(run => h("article", { key: run.id, className: "lm-current-run", "data-memory-run": run.id, "data-phase": run.phase },
					h("div", { className: "lm-run-heading" }, h("strong", null, t(run.purpose === "turn_review" ? "review" : "batch")), h("span", { className: "lm-run-state" }, t(run.phase ? "phase-" + run.phase : "state-running")), stopButton(workers.find(value => value.runId === run.id))), runBody(run)))) : null,
				retryRows.length || finished.length ? h("section", null, retryRows, ...finished.map(run => h("details", { key: run.id, className: "lm-finished-run", open: run.id === snapshot.latestFailure?.id, "data-memory-run": run.id, "data-run-status": run.status },
					h("summary", null, h("span", null, t(run.purpose === "turn_review" ? "review" : "batch")), h("span", { className: "lm-run-state", "data-state": run.status }, t("state-" + run.status)), run.changedEntries ? h("span", { className: "lm-run-state" }, t("changedCount", { count: run.changedEntries })) : null, h("time", { dateTime: run.finishedAt, title: run.finishedAt }, time(run.finishedAt)), run.legacy ? h("span", { className: "lm-legacy", title: run.sessionId }, t("legacy")) : null), runBody(run)))) : !snapshot?.running.length ? h("p", { className: "lm-activity-empty" }, t("empty")) : null)
				: h(React.Fragment, null,
					h("div", { className: "lm-history-heading" }, h("span", null, t(worker.phase ? "phase-" + worker.phase : "state-" + worker.status)), stopButton(worker), h(Button, { variant: "ghost", size: "sm", onClick: () => setHistoryRevision(value => value + 1), disabled: history.busy }, t("refresh"))),
					h("div", { className: "lm-activity-content lm-history", "data-memory-history": workerId },
						history.page?.hasPrevious ? h(Button, { variant: "ghost", size: "sm", className: "lm-history-older", disabled: history.busy, onClick: loadOlder }, t("older")) : null,
						history.error ? h("p", { className: "lm-activity-error", role: "alert" }, history.error) : null,
						history.busy ? h("p", { className: "lm-activity-empty", role: "status" }, t("loading")) : null,
						...((history.page?.rows || []).map(row => row.kind === "assistant" ? h("article", { key: row.id, className: "lm-history-message", "data-memory-history-row": row.id }, h("div", { className: "lm-history-label" }, t("trace-" + row.kind), row.at ? h("time", { dateTime: row.at }, time(row.at)) : null), h("div", { className: "lm-history-body" }, row.text))
							: h("details", { key: row.id, className: "lm-history-event", "data-memory-history-row": row.id }, h("summary", null, t("trace-" + row.kind), row.at ? h("time", { dateTime: row.at }, time(row.at)) : null), h("pre", { className: "lm-history-body" }, row.text)))),
						!history.busy && history.page && !history.page.rows.length ? h("p", { className: "lm-activity-empty" }, t("historyEmpty")) : null,
						h("div", { ref: historyEnd })))));
	}
	function MemoryStatus({ activityStore, controls, t }) {
		const buttonRef = React.useRef(null);
		const panelRef = React.useRef(null);
		const panelId = React.useId();
		const [open, setOpen] = React.useState(false);
		const position = useAnchoredPosition({ open, anchorRef: buttonRef, panelRef, side: "top", gap: 8, margin: 12 });
		useDismissOnOutsidePointer(buttonRef, open, setOpen, panelRef);
		React.useEffect(() => {
			if (!open) return;
			const keydown = event => { if (event.key === "Escape") setOpen(false); };
			const click = event => {
				if (!buttonRef.current?.contains(event.target) && !panelRef.current?.contains(event.target)) setOpen(false);
			};
			document.addEventListener("keydown", keydown);
			document.addEventListener("click", click, true);
			return () => { document.removeEventListener("keydown", keydown); document.removeEventListener("click", click, true); };
		}, [open]);
		const value = React.useSyncExternalStore(activityStore.subscribe, activityStore.getSnapshot);
		const snapshot = value.snapshot;
		const running = snapshot?.running[0];
		const failure = snapshot?.latestFailure;
		const latestFinished = snapshot?.records.find(run => run.finishedAt !== null);
		const waiting = latestFinished?.status === "waiting_evidence" ? latestFinished : null;
		const stopped = latestFinished?.status === "stopped" ? latestFinished : null;
		const item = running || failure || waiting || stopped || snapshot?.latestChanged || snapshot?.records[0];
		const isFailure = value.error || (!running && Boolean(failure));
		let label = t(snapshot ? "idle" : "initializing");
		if (value.error) label = t("unavailable");
		else if (running) label = t(running.purpose === "turn_review" ? "reviewing" : "organizing");
		else if (failure) label = failure.changedEntries ? t("partial", { count: failure.changedEntries }) : t("failed");
		else if (waiting) label = t("awaitingEvidence");
		else if (stopped) label = t(stopped.purpose === "turn_review" ? "stoppedReview" : "stoppedBatch");
		else if (item) label = item.changedEntries ? t("changed", { count: item.changedEntries }) : t("settled");
		const clickable = !value.error && snapshot !== null;
		const title = [label, !running && (failure?.summary || waiting?.summary || stopped?.summary), !running && (waiting || stopped)?.changedEntries ? t("changedCount", { count: (waiting || stopped).changedEntries }) : "", clickable ? t("details") : "", running && snapshot.running.length > 1 ? t("concurrent", { count: snapshot.running.length - 1 }) : ""].filter(Boolean).join(" · ");
		return h(React.Fragment, null,
			h("style", null, styles),
			h("span", { className: "lm-status-seat", "data-memory-status": value.error ? "unavailable" : running ? "running" : failure ? "failed" : waiting ? "waiting" : stopped ? "stopped" : item ? item.changedEntries ? "changed" : "reviewed" : snapshot ? "idle" : "loading" },
				h(clickable ? "button" : "span", {
					className: "lm-status-line" + (running && !value.error ? " is-running" : "") + (isFailure ? " is-failed" : ""),
					...(clickable ? { ref: buttonRef, type: "button", onClick: () => setOpen(!open), "aria-haspopup": "dialog", "aria-expanded": open, "aria-controls": panelId } : {}),
					title, "aria-label": title,
				}, h(Brain), h("span", { className: "lm-status-text", role: "status", "aria-live": "polite" }, label),
					isFailure ? h(IconWarningOutlineRegular, { className: "lm-status-failure", size: 14 }) : null)),
			open && createPortal(h(ActivityPanel, { open, snapshot, controls, panelRef, panelId, position, t }), document.body));
	}
	return {
		inject: ["remote"],
		async apply(ctx) {
			// 状态与管理页的描述符合并挂载，避免同 package 两次 $mount
			const unmountRemote = await ctx.remote.$mount({ package: STATUS_PACKAGE, descriptors: [...STATUS_REMOTE.descriptors, ...STORE_REMOTE.descriptors] });
			const stores = new Set();
			const ui = ctx.inject(["remote.layeredMemoryStatus", "slots", "locale"], scope => {
				scope.effect(() => scope.locale.register(locale, dictionaries), "memory-status: locale");
				scope.slots.inject("conversation.composer.dock", () => scope.slots.register({
					name: "conversation.composer.dock", id: "layered-memory-status", order: 5, locale,
					inject: sessionId => {
						const store = createStore(scope.remote, sessionId, stores);
						return {
							activityStore: store,
							controls: {
								refresh: signal => store.refresh(signal),
								list: signal => resultValue(scope.remote.layeredMemoryStatus.listWorkers(sessionId, signal)),
								read: (workerId, offset, limit, signal) => resultValue(scope.remote.layeredMemoryStatus.readWorker(sessionId, workerId, offset, limit, signal)),
								stop: (workerId, signal) => resultValue(scope.remote.layeredMemoryStatus.stopWorker(sessionId, workerId, signal)),
							},
						};
					},
				}, MemoryStatus));
			});
			try { await ui; }
			catch (error) { await ui.dispose(); await unmountRemote(); throw error; }
			return async () => { await ui.dispose(); await Promise.all([...stores].map(store => store.dispose())); await unmountRemote(); };
		},
	};
}
