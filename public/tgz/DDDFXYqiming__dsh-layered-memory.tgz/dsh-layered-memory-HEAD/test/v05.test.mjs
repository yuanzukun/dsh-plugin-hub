// v0.5 新特性测试：内容相似度、近重复去重、memory_search、写入即压缩、
// 关联链接、promote、重试序列蒸馏（auto-pending 重做）、热度衰减。
import { test, expect, beforeEach, afterEach } from "vitest";
import { mkdtempSync, readFileSync, writeFileSync, existsSync, rmSync, mkdirSync, readdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { apply } from "../lib/index.js";
import { tokenize, jaccard, BM25Index } from "../src/similarity.js";
import { snippetAround } from "../src/search.js";
import { entryHeat } from "../src/store.js";

let memDir;
let disposer;
let tools;
let eventHandlers;
let effects = [];

function setup({ maxIndexLines = 30, autoPending = true } = {}) {
	memDir = mkdtempSync(join(tmpdir(), "dsh-memory-v05-test-"));
	const registered = [];
	eventHandlers = {};
	const agentsService = {
		get(id) {
			return injected.get(id) ?? null;
		},
	};
	const injected = new Map();
	const ctx = {
		get(service) {
			if (service === "systemPrompt") return { context: () => () => {} };
			if (service === "agents") return agentsService;
			if (service === "sessionQuery") return null;
			return undefined;
		},
		on(event, handler) {
			eventHandlers[event] = handler;
			return () => {};
		},
		skills: { register: () => () => {} },
		tools: {
			register(def) { registered.push(def); return () => {}; },
			restrict() { return () => {}; },
		},
		logger: { info() {}, warn() {} },
		effect(factory) {
			const d = factory();
			if (typeof d === "function") effects.push(d);
		},
	};
	effects = [];
	disposer = apply(ctx, {
		memoryDir: memDir,
		progressive: false,
		autoNamespace: false,
		defaultNamespace: "test",
		maxIndexLines,
		autoPending,
	});
	tools = registered;
	return { injected };
}

function tool(name) {
	const def = tools.find((t) => t.name === name);
	if (!def) throw new Error(`tool not found: ${name}`);
	return def;
}

beforeEach(() => {
	setup();
});

afterEach(() => {
	if (typeof disposer === "function") disposer();
	for (const f of effects) f();
	effects = [];
	if (memDir) rmSync(memDir, { recursive: true, force: true });
});

// ── similarity 原语 ──

test("similarity: jaccard detects reworded duplicates and rejects unrelated text", () => {
	const a = new Set(tokenize("DSH 插件安装后需要重启宿主才能生效，插件加载发生在启动阶段"));
	const b = new Set(tokenize("DSH 插件安装之后要重启宿主才会生效，插件在启动阶段被加载"));
	const c = new Set(tokenize("PowerShell 的执行策略限制脚本运行，需要 Set-ExecutionPolicy"));
	expect(jaccard(a, b)).toBeGreaterThan(0.4);
	expect(jaccard(a, c)).toBeLessThan(0.2);
});

test("similarity: BM25 ranks matching doc above others", () => {
	const idx = new BM25Index();
	idx.addDoc("gpu", "任务管理器显示 GPU 利用率 66% 温度 86°C");
	idx.addDoc("git", "git push 到 GitHub 需要网络代理配置");
	idx.addDoc("empty", "完全无关的内容");
	const hits = idx.search("GPU 利用率", 3);
	expect(hits[0]?.id).toBe("gpu");
	expect(hits.length).toBeGreaterThanOrEqual(1);
});

test("similarity: tokenize extracts ascii words and cjk bigrams", () => {
	const tokens = tokenize("重启宿主 restart host");
	expect(tokens).toContain("restart");
	expect(tokens).toContain("host");
	expect(tokens).toContain("重启");
	expect(tokens).toContain("宿主");
});

// ── 近重复去重与合并候选 ──

test("memory_maintain reports reworded near-duplicates as candidates without archiving them", async () => {
	const sopsDir = join(memDir, "test", "sops");
	mkdirSync(sopsDir, { recursive: true });
	// 内容级近重复（≥0.85 Jaccard）只产候选：[0.6.8] 起程序不再凭相似度自行归档，
	// 归档决定留给语义确认（词元集合读不出否定、参数与操作顺序）。
	const body = "DSH 插件安装后需要重启宿主才能生效。插件加载发生在宿主启动阶段，热更新不可用。安装命令是 dsh plugin --profile web add。";
	writeFileSync(join(sopsDir, "install-a.md"), `# install-a\n\n${body}\n`, "utf8");
	writeFileSync(join(sopsDir, "install-b.md"), `# install-b\n\n${body.replace("热更新不可用", "热更新不支持")}\n`, "utf8");

	const report = await tool("memory_maintain").execute({ namespace: "test" });
	expect(report.report.dedupe.removed).toHaveLength(0);
	const candidate = report.report.dedupe.nearDuplicates.find((c) => c.a === "install-a" && c.b === "install-b");
	expect(candidate).toBeTruthy();
	expect(candidate.similarity).toBeGreaterThanOrEqual(0.85);
	expect(candidate.kind).toBe("sop");
	// 两条都保持活跃：候选不写 archived（meta 文件在从未归档时不存在）
	const metaPath = join(memDir, "test", "memory-meta.json");
	const meta = existsSync(metaPath) ? JSON.parse(readFileSync(metaPath, "utf8")) : {};
	expect(meta.sops?.["install-a"]?.archived ?? false).toBe(false);
	expect(meta.sops?.["install-b"]?.archived ?? false).toBe(false);
});

test("parameter, negation and step-order differences are never auto-archived", async () => {
	const sopsDir = join(memDir, "test", "sops");
	mkdirSync(sopsDir, { recursive: true });
	// 三个合成反例：相似度都会越过 0.85，但语义互不等价，因此一条都不许自动归档。
	// 每对条目带各自的标记句，避免三对之间出现「完全一致」而走精确归档路径。
	const base = "部署说明：服务监听端口 8080，认证 enabled，执行顺序为先停服务，再复制数据库，最后启动服务。操作前确认备份完整。";
	const withPort = `${base} 端口档记录。`;
	const withAuth = `${base} 认证档记录。`;
	const withOrder = `${base} 顺序档记录。`;
	writeFileSync(join(sopsDir, "deploy-port-a.md"), `# deploy-port-a\n\n${withPort}\n`, "utf8");
	writeFileSync(join(sopsDir, "deploy-port-b.md"), `# deploy-port-b\n\n${withPort.replace("8080", "9090")}\n`, "utf8");
	writeFileSync(join(sopsDir, "deploy-auth-a.md"), `# deploy-auth-a\n\n${withAuth}\n`, "utf8");
	writeFileSync(join(sopsDir, "deploy-auth-b.md"), `# deploy-auth-b\n\n${withAuth.replace("认证 enabled", "认证 disabled")}\n`, "utf8");
	writeFileSync(join(sopsDir, "deploy-order-a.md"), `# deploy-order-a\n\n${withOrder}\n`, "utf8");
	writeFileSync(join(sopsDir, "deploy-order-b.md"), `# deploy-order-b\n\n${withOrder.replace("先停服务，再复制数据库，最后启动服务", "先复制数据库，再停服务，最后启动服务")}\n`, "utf8");

	const report = await tool("memory_maintain").execute({ namespace: "test" });
	expect(report.report.dedupe.removed).toHaveLength(0);
	expect(report.report.dedupe.nearDuplicates.length).toBeGreaterThanOrEqual(1);
	const metaPath = join(memDir, "test", "memory-meta.json");
	const meta = existsSync(metaPath) ? JSON.parse(readFileSync(metaPath, "utf8")) : {};
	for (const slug of ["deploy-port-a", "deploy-port-b", "deploy-auth-a", "deploy-auth-b", "deploy-order-a", "deploy-order-b"]) {
		expect(meta.sops?.[slug]?.archived ?? false).toBe(false);
	}
});

test("identical content across different names is reported as candidate, never auto-archived", async () => {
	const sopsDir = join(memDir, "test", "sops");
	mkdirSync(sopsDir, { recursive: true });
	// [0.6.9] 判定与检索归一化分离：内容逐字节相同但主题名不同也只报候选。
	// 两个主题名在陈述不同对象的事实，正文一样不代表第二条可以被第一条替代。
	const identical = "# dup-title\n\n完全一致的重复条目：同样的正文，同样的命令，同样的结论。\n";
	writeFileSync(join(sopsDir, "exact-a.md"), identical, "utf8");
	writeFileSync(join(sopsDir, "exact-b.md"), identical, "utf8");

	const report = await tool("memory_maintain").execute({ namespace: "test" });
	expect(report.report.dedupe.removed).toHaveLength(0);
	const pair = report.report.dedupe.exactDuplicates.find((d) => d.kind === "sop" && d.a === "exact-a" && d.b === "exact-b");
	expect(pair).toBeTruthy();
	expect(pair.match).toBe("exact");
	const metaPath = join(memDir, "test", "memory-meta.json");
	const meta = existsSync(metaPath) ? JSON.parse(readFileSync(metaPath, "utf8")) : {};
	expect(meta.sops?.["exact-a"]?.archived ?? false).toBe(false);
	expect(meta.sops?.["exact-b"]?.archived ?? false).toBe(false);
});

test("同名同内容的重复 section 自动无损合并，同名不同内容只报冲突", async () => {
	writeFileSync(join(memDir, "test", "facts.md"), "## 重复主题\n同一段内容\n\n## 重复主题\n同一段内容\n\n## 冲突主题\n甲版本\n\n## 冲突主题\n乙版本\n\n", "utf8");
	writeFileSync(join(memDir, "test", "memory-meta.json"), JSON.stringify({ facts: {}, sops: {} }), "utf8");
	const report = await tool("memory_maintain").execute({ namespace: "test" });
	expect(report.report.dedupe.merged.length).toBeGreaterThanOrEqual(1);
	expect(report.report.dedupe.conflicts.some((c) => c.name === "冲突主题")).toBe(true);
	const factsText = readFileSync(join(memDir, "test", "facts.md"), "utf8");
	// 同名同内容段合并后只剩一个；同名不同内容保持并列，等人工裁决。
	expect(factsText.split("## 重复主题").length - 1).toBe(1);
	expect(factsText.split("## 冲突主题").length - 1).toBe(2);
});

test("merge candidates are content-based: unrelated names no longer pair up", async () => {
	const sopsDir = join(memDir, "test", "sops");
	mkdirSync(sopsDir, { recursive: true });
	// 名称高度相似但内容完全无关 —— v0.4 会误报，v0.5 不应配对
	writeFileSync(join(sopsDir, "anysearch-dsh-plugin-install.md"), "# a\n\nAnySearch MCP 插件的安装与凭据配置方法。\n", "utf8");
	writeFileSync(join(sopsDir, "dsh-bundle-plugin-install.md"), "# b\n\nCordis bundle 打包交付与 cordis.patch.yml 的写法规范。\n", "utf8");

	const report = await tool("memory_maintain").execute({ namespace: "test" });
	expect(report.report.mergeCandidates).toHaveLength(0);
});

test("merge candidates report genuinely overlapping content pairs", async () => {
	const sopsDir = join(memDir, "test", "sops");
	mkdirSync(sopsDir, { recursive: true });
	const body = "安装 dsh 插件使用 dsh plugin --profile web add 命令；Windows 下 schannel 报错时改用本地路径安装；安装完成后需要重启宿主。";
	writeFileSync(join(sopsDir, "plugin-install-guide.md"), `# guide\n\n${body}\n`, "utf8");
	writeFileSync(join(sopsDir, "plugin-install-notes.md"), `# notes\n\n${body}\n补充：pnpm 安装失败时检查镜像源。\n`, "utf8");

	const report = await tool("memory_maintain").execute({ namespace: "test" });
	expect(report.report.mergeCandidates.length).toBe(1);
	expect(report.report.mergeCandidates[0].similarity).toBeGreaterThan(0.45);
});

// ── memory_search ──

test("memory_search finds entries including L1-hidden and archived ones", async () => {
	await tool("memory_write").execute({
		topic: "quantum-flux-config",
		entry_type: "fact",
		content: "量子通量校准参数存放在 C:\\etc\\flux.yaml",
		evidence: "unit test",
		namespace: "test",
	});
	// 制造一个归档条目
	await tool("memory_write").execute({
		topic: "archived-flux-note",
		entry_type: "sop",
		content: "关于量子通量的历史排查经验：先查 flux.yaml 再查环境变量",
		evidence: "unit test",
		namespace: "test",
	});
	await tool("memory_archive").execute({ topic: "archived-flux-note", entry_type: "sop", namespace: "test" });

	const r = await tool("memory_search").execute({ query: "量子通量", namespace: "test" });
	const names = r.results.map((x) => x.name);
	expect(names).toContain("quantum-flux-config");
	expect(names).toContain("archived-flux-note");
	expect(r.results[0].score).toBeGreaterThan(0);
});

test("memory_search respects include_archived=false", async () => {
	await tool("memory_write").execute({
		topic: "hidden-gem",
		entry_type: "fact",
		content: "稀有的独角兽配置片段 unicorn",
		evidence: "unit test",
		namespace: "test",
	});
	await tool("memory_archive").execute({ topic: "hidden-gem", entry_type: "fact", namespace: "test" });

	const r = await tool("memory_search").execute({ query: "unicorn 独角兽", namespace: "test", include_archived: false });
	expect(r.results.map((x) => x.name)).not.toContain("hidden-gem");
});

// ── 写入即压缩 ──

test("memory_write auto-compresses oversized index without manual maintain", async () => {
	if (typeof disposer === "function") disposer();
	if (memDir) rmSync(memDir, { recursive: true, force: true });
	setup({ maxIndexLines: 12 });

	for (let i = 1; i <= 6; i++) {
		const w = await tool("memory_write").execute({
			topic: `bulk-fact-${i}`,
			entry_type: "fact",
			content: `批量事实 ${i}`,
			evidence: "unit test",
			namespace: "test",
		});
		if (i === 6) {
			// 最后一次写入应已自动压缩（或索引本就未超限），且不再出现未压缩的 over_limit
			expect(w.index.compressed || !w.index.over_limit).toBe(true);
		}
		// 回归：出口消毒后结果必须可无损 JSON 往返（undefined 键已被出口剥离，
		// schema 已开放为 additionalProperties:true，不再约束字段）。
		expect(JSON.parse(JSON.stringify(w))).toEqual(w);
	}
	const index = readFileSync(join(memDir, "test", "index.txt"), "utf8");
	const lineCount = index.replace(/\n+$/, "").split("\n").length;
	expect(lineCount).toBeLessThanOrEqual(12);
	// 隐藏条目仍可读
	const hidden = await tool("memory_read").execute({ name: "bulk-fact-1", namespace: "test" });
	expect(hidden.not_found).not.toBe(true);
});

// ── 出口无损 JSON（宿主 lossless 校验回归）──

test("memory_update with supersede=false returns lossless JSON (no undefined-valued keys)", async () => {
	await tool("memory_write").execute({
		topic: "lossless-check",
		entry_type: "fact",
		content: "初始内容",
		evidence: "unit test",
		namespace: "test",
	});
	const r = await tool("memory_update").execute({
		topic: "lossless-check",
		entry_type: "fact",
		content: "更新内容",
		supersede: false,
	});
	// 显式 undefined 键会被 JSON.stringify 丢弃 → 宿主判整个结果非无损并拒收
	expect(JSON.parse(JSON.stringify(r))).toEqual(r);
	expect(r.action).toBe("updated");
});

// ── related 关联链接 ──

test("memory_write stores related links and memory_read surfaces them", async () => {
	await tool("memory_write").execute({
		topic: "base-entry",
		entry_type: "fact",
		content: "基础条目",
		evidence: "unit test",
		namespace: "test",
	});
	await tool("memory_write").execute({
		topic: "linked-entry",
		entry_type: "sop",
		content: "带关联的条目",
		evidence: "unit test",
		namespace: "test",
		related: ["base-entry"],
	});
	const r = await tool("memory_read").execute({ name: "linked-entry", namespace: "test" });
	expect(r.meta.related).toEqual(["base-entry"]);
});

test("memory_read surfaces resolved related_states without breaking related (v0.5.2)", async () => {
	await tool("memory_write").execute({
		topic: "rel-b",
		entry_type: "fact",
		content: "关系目标",
		evidence: "unit test",
		namespace: "test",
	});
	await tool("memory_write").execute({
		topic: "rel-a",
		entry_type: "sop",
		content: "带关系的条目",
		evidence: "unit test",
		namespace: "test",
		related: ["rel-b"],
	});
	const r = await tool("memory_read").execute({ name: "rel-a", namespace: "test" });
	// related 保持历史字符串数组契约
	expect(r.meta.related).toEqual(["rel-b"]);
	// 新字段给出解析后的状态（活跃/已归档/未找到）
	expect(r.meta.related_states).toEqual([{ name: "rel-b", state: "active" }]);
	// 归档后状态变为 archived
	await tool("memory_archive").execute({ topic: "rel-b", entry_type: "fact", namespace: "test" });
	const r2 = await tool("memory_read").execute({ name: "rel-a", namespace: "test" });
	expect(r2.meta.related_states).toEqual([{ name: "rel-b", state: "archived" }]);
});

test("memory_read strips duplicated leading '# title' in sop content (v0.5.2)", async () => {
	await tool("memory_write").execute({
		topic: "dup-title-sop",
		entry_type: "sop",
		content: "# dup-title-sop\n\n正文内容\n## 小节\n- 要点",
		evidence: "unit test",
		namespace: "test",
	});
	const r = await tool("memory_read").execute({ name: "dup-title-sop", namespace: "test" });
	expect(r.content.startsWith("# dup-title-sop")).toBe(false);
	expect(r.content).toContain("正文内容");
	expect(r.content).toContain("## 小节");
});

test("pendingSummary prefers retry error line over empty tail (v0.5.2)", async () => {
	const summary = (await import("../src/tools.js")).pendingSummary;
	const candidate = [
		"# Pending Memory Candidate",
		"- kind: retry-sequence",
		"- 错误尾部: Error: tool call timed out after 30000ms",
		"- 成功结果尾部: No files found",
		"",
	].join("\n");
	const s = summary(candidate);
	expect(s).toContain("retry-sequence");
	expect(s).toContain("timed out");
	// 旧策略取最后一行只会得到空串；新策略必须输出错误尾部
	expect(s.length).toBeGreaterThan(10);
});

// ── memory_promote ──

test("memory_promote copies to target namespace and archives source", async () => {
	await tool("memory_write").execute({
		topic: "local-wisdom",
		entry_type: "sop",
		content: "项目局部经验：部署前先跑冒烟测试",
		evidence: "unit test",
		namespace: "test",
	});
	const p = await tool("memory_promote").execute({
		topic: "local-wisdom",
		entry_type: "sop",
		from_namespace: "test",
		to_namespace: "default",
	});
	expect(p.promoted).toBe(true);

	// 目标空间可读
	const r = await tool("memory_read").execute({ name: "local-wisdom", namespace: "default" });
	expect(r.not_found).not.toBe(true);
	expect(r.content).toContain("冒烟测试");
	// 源条目已归档
	const src = await tool("memory_read").execute({ name: "local-wisdom", namespace: "test" });
	expect(src.not_found).toBe(true);
});

// ── auto-pending 重做：只捕获重试序列 ──

test("auto-pending ignores plain successes but captures fail-then-retry sequences", async () => {
	const execBase = { agent: { id: "agent-x" } };
	// 普通成功调用：不应产生 pending
	eventHandlers["tools/result"](
		{ ...execBase, name: "read" },
		{ isError: false, text: "file content" },
	);
	eventHandlers["tools/result"](
		{ ...execBase, name: "grep" },
		{ isError: false, text: "matches" },
	);
	eventHandlers["session/event"]({ id: "agent-x" }, { type: "turn/end", seq: 1 });
	let pendings = readdirSync(join(memDir, "test", "pending")).filter((f) => f.endsWith(".md"));
	expect(pendings).toHaveLength(0);

	// 失败两次后成功：应产生一条含重试序列的候选
	eventHandlers["tools/result"](
		{ ...execBase, name: "bash" },
		{ isError: true, text: "EPERM: operation not permitted" },
	);
	eventHandlers["tools/result"](
		{ ...execBase, name: "bash" },
		{ isError: true, text: "EPERM: operation not permitted (again)" },
	);
	eventHandlers["tools/result"](
		{ ...execBase, name: "bash" },
		{ isError: false, text: "succeeded with workaround" },
	);
	eventHandlers["session/event"]({ id: "agent-x" }, { type: "turn/end", seq: 2 });

	pendings = readdirSync(join(memDir, "test", "pending")).filter((f) => f.endsWith(".md"));
	expect(pendings).toHaveLength(1);
	const content = readFileSync(join(memDir, "test", "pending", pendings[0]), "utf8");
	expect(content).toContain("bash");
	expect(content).toContain("EPERM");
	expect(content).toContain("succeeded with workaround");
});

// ── 热度衰减 ──

test("entryHeat decays access counts with 14-day half-life", () => {
	const meta = { facts: {}, sops: {} };
	const now = Date.now();
	const freshAccess = { "sop:hot": { count: 8, lastAt: new Date(now).toISOString() } };
	const oldAccess = { "sop:cold": { count: 8, lastAt: new Date(now - 28 * 86400000).toISOString() } };
	const hot = entryHeat(freshAccess, meta, "sop", "hot");
	const cold = entryHeat(oldAccess, meta, "sop", "cold");
	expect(hot).toBeCloseTo(8, 1);
	expect(cold).toBeCloseTo(2, 1); // 28 天 = 两个半衰期 → 8/4
});

// ── 原子写与注入面防护（v0.5.3）──

test("atomic write leaves no temp files and survives on disk", async () => {
	await tool("memory_write").execute({
		topic: "atomic-probe",
		entry_type: "fact",
		content: "原子写验证内容",
		evidence: "regression test",
		namespace: "test",
	});
	const files = readdirSync(join(memDir, "test"));
	expect(files.some((f) => f.includes(".tmp-"))).toBe(false);
	const fact = readFileSync(join(memDir, "test", "facts.md"), "utf8");
	expect(fact).toContain("## atomic-probe");
});

test("writeMemory rejects topics with newline or control characters", async () => {
	await expect(
		tool("memory_write").execute({
			topic: "evil\ntopic",
			entry_type: "fact",
			content: "x",
			evidence: "regression test",
			namespace: "test",
		}),
	).rejects.toThrow(/控制字符/);
	await expect(
		tool("memory_write").execute({
			topic: "bad\u0000topic",
			entry_type: "sop",
			content: "x",
			evidence: "regression test",
			namespace: "test",
		}),
	).rejects.toThrow(/控制字符/);
});

test("L1 injection into systemPrompt is capped and wrapped in a sentinel", () => {
	let captured = "";
	const injected = new Map();
	const agentsService = { get(id) { return injected.get(id) ?? null; } };
	const sysCtx = {
		context(entry) {
			captured = entry.text();
			return () => {};
		},
	};
	const ctx = {
		get(service) {
			if (service === "systemPrompt") return sysCtx;
			if (service === "agents") return agentsService;
			if (service === "sessionQuery") return null;
			return undefined;
		},
		on() { return () => {}; },
		skills: { register: () => () => {} },
		tools: { register() { return () => {}; }, restrict() { return () => {}; } },
		logger: { info() {}, warn() {} },
		effect(factory) { factory(); },
	};
	apply(ctx, { memoryDir: memDir, progressive: false, autoNamespace: false, defaultNamespace: "test" });
	expect(captured.startsWith("<memory_index source=\"user-writable\">")).toBe(true);
	expect(captured.endsWith("</memory_index>")).toBe(true);
	expect(captured.length).toBeLessThan(9000);
});

// ── [0.6.8] 检索改进：复合词拆分索引 + 命中位置摘要 ──

test("tokenize indexes compound identifiers together with their split parts", () => {
	const tokens = tokenize("dsh-layered-memory");
	expect(tokens).toContain("dsh-layered-memory");
	expect(tokens).toContain("layered");
	expect(tokens).toContain("memory");
});

test("BM25 finds a hyphenated identifier from its split words", () => {
	const idx = new BM25Index();
	idx.addDoc("lm", "记忆插件 dsh-layered-memory 的索引与注入实现");
	idx.addDoc("other", "完全无关的内容，讲的是显示器接线与分辨率设置");
	expect(idx.search("layered memory", 3)[0]?.id).toBe("lm");
	expect(idx.search("dsh-layered-memory", 3)[0]?.id).toBe("lm");
});

test("snippet shows the hit neighbourhood instead of the document head", () => {
	const head = "开头是一大段与查询无关的说明文字。".repeat(12);
	const text = `${head}关键结论：qwen3.8-27b 在 128K 下必须启用 q4 KV 缓存。`;
	const snippet = snippetAround(text, "q4 KV", 160);
	expect(snippet).toContain("q4 KV");
	expect(snippet.startsWith("…")).toBe(true);
	expect(snippet.length).toBeLessThanOrEqual(165);
});
