# dsh-error-audit

DeepSeek Harness 实时 AI 自审插件：报错 / 警告第一时间连同时间、错误码、会话、用户原话、AI 动作与工作区写入日志目录，并主动通知 AI、内置 `read_error_logs` 工具随时读取。

## 特性

- **实时记录**：监听 `agent/error`、`agent/request-error`、`tools/result`，错误发生瞬间落盘 + 打印。
- **完整归因**：时间 / 错误码 / 会话 / 工作区 / 用户原话 / AI 动作，不截断。
- **主动通知**：error 级向出错会话注入提示（运行中注入、空闲唤醒）；warning 只落盘。
- **AI 可读**：`read_error_logs` 工具可列表、过滤、读单条报告（合并读磁盘，重启不丢）。

## 一键安装

```bash
dsh plugin --profile web add "github:166767/dsh-error-audit#main"
```

### 重启 dsh web

```bash
dsh web
```

### 验证

```bash
dsh --profile web --dump-config | findstr error-audit
```

装好后，日志写入 `$DSH_HOME/error-audit/`，AI 直接调用 `read_error_logs` 即可。

## 配置（可选）

默认开箱即用。需要改可在 `$DSH_HOME/profiles/<name>/cordis.patch.yml` 覆盖该行 config：

| 项 | 默认值 | 说明 |
|---|---|---|
| `logDir` | `$DSH_HOME/error-audit` | 日志目录（也可用环境变量 `DSH_ERROR_AUDIT_DIR`） |
| `notify` | `true` | error 级是否主动通知 AI |
| `notifyMode` | `auto` | `auto` / `inject` / `followup` |
| `windowSize` | `50` | 每条错误携带的最近会话事件数 |

## 文档

- `docs/`：开发经验手记等详细说明。

## License

MIT
