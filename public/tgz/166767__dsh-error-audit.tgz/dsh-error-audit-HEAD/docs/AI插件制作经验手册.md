# 制作 dsh-error-audit 插件的 AI 经验手册

> 本文记录我（一个 AI 编码代理）从零到一，在 DeepSeek Harness 上开发 **实时 AI 自审插件**（`dsh-error-audit`）的完整过程：如何调研一个陌生的系统、如何把模糊需求翻译成技术目标、踩过哪些坑、每个坑的根因和修复、以及沉淀下来可复用的方法论。
>
> 目标读者：未来的我、其他想在 DeepSeek Harness 上写 Cordis 插件的开发者、以及任何想学习"AI 如何自主啃一个不熟悉的代码库"的人。

---

## 目录

1. [项目背景与需求](#1-项目背景与需求)
2. [需求拆解：把模糊请求翻译成技术目标](#2-需求拆解)
3. [调研方法论：如何读懂一个不熟悉的系统](#3-调研方法论)
4. [关键技术发现：官方接口清单](#4-关键技术发现)
5. [架构设计：几个关键决策](#5-架构设计)
6. [踩坑记录（核心）](#6-踩坑记录)
7. [可复用的经验法则](#7-可复用的经验法则)
8. [附录 A：官方接口速查表](#附录-a官方接口速查表)
9. [附录 B：架构图](#附录-b架构图)
10. [附录 C：踩坑-修复对照表](#附录-c踩坑-修复对照表)

---

## 1. 项目背景与需求

用户的需求原文（提炼）：

> 一旦 DeepSeek Harness 出现任何报错、警告、问题，第一时间把报错打印出来，并附上：错误时间、错误代码、具体哪一个对话、用户说了什么、AI 做了什么导致、哪一个具体工作区。放进一个专门的报错文件夹，AI 可以随时读取。要求可开源、别人也能直接使用。后续又追加：报错时 AI 要"瞬间收到提示"、跨工作区跨会话、且不是只有作者能查看。

最终交付物（两种形态）：

| 形态 | 用途 | 生命周期 |
|---|---|---|
| 动态 Cordis 插件（`erraud-1`） | 本会话立刻验证效果 | 进程内临时 |
| npm 风格开源包（`dsh-error-audit/`） | 正式交付、别人可安装 | 持久、可发布 |

关键结论先行：**官方其实已经暴露了"错误事件"接口，根本不需要 hack。** 我们做的只是"监听官方事件 + 归约上下文 + 落盘 + 注入通知 + 注册读取工具"。

---

## 2. 需求拆解

模糊需求 → 技术目标，这一步是整个项目最容易翻车的地方。我的做法是：**先做足调研，再用"带推荐默认值的选择题"向用户确认**，而不是让用户回答技术细节。

### 2.1 需求翻译表

| 用户原话 | 翻译成的技术目标 |
|---|---|
| "任何报错、警告、问题" | 监听 `agent/error`、`agent/request-error`、`tools/result`、`agent-loop/config-start-failed` 四类事件 |
| "第一时间" | 事件回调里同步 `console.error` + 立即异步落盘，不轮询不延迟 |
| "错误时间" | `new Date().toISOString()` |
| "错误代码" | 从 error 对象提取 `code` / `info.code` / `error.code` |
| "哪一个对话" | `agent.id`（= sessionId）、`session.header.agentPreset`、`parentSession` |
| "用户说了什么 / AI 做了什么" | 维护按 session 的滚动窗口，从 `session/event` 归约 `user/message`、`assistant/message`、`tool/call`、`tool/result` |
| "哪一个工作区" | `session.header.cwd` |
| "AI 随时读取" | 注册 `read_error_logs` 工具 |
| "瞬间收到提示" | `agent.inject()` / `agent.followup()` 注入通知 |
| "跨工作区跨会话" | 挂到**宿主层**（进程根部），而不是某个 agent preset |
| "别人也能用" | npm 风格包 + README 安装说明 + `cordis.patch.yml` 挂载行 |

### 2.2 四次提问的作用

用户明确说"你可以反复向我提问"，我借机用 `ask_user_question` 分两轮问了 8 个问题。**经验：问"有推荐默认值的选择题"，不要问开放式的技术题。**

第一轮（决定交付形态和日志策略）：
1. 交付形态 → 两者都要（动态插件验证 + 开源包）
2. 日志目录 → `$DSH_HOME/error-audit`（全局）
3. 记录程度 → 完整记录、不截断
4. 监控范围 → 全量（error + 警告）

第二轮（决定"即时通知"的行为）：
5. 通知范围 → 只通知出错会话
6. 唤醒方式 → 自动（运行中注入 / 空闲才唤醒）
7. 文件夹模型 → 各自本地一份（非集中云）
8. 提示级别 → error 才主动提示，warning 只落盘

**教训**：如果第一轮就动手、没问清楚"通知范围/唤醒方式/文件夹模型"，后面极可能要返工重写通知逻辑。需求澄清的边际成本远低于返工成本。

---

## 3. 调研方法论

### 3.1 先加载技能，再动手

我第一时间加载了两个技能：
- `cordis-plugin-development`：动态插件的开发流程、平台选择、Services/Events 访问规则、生命周期、常见错误。
- `editing-cordis-compositions`：cordis.yml 组合的平面规则（宿主层 vs 预设层）。

**教训**：技能是"浓缩版 API 文档 + 反例集合"，先读能避免 80% 的低级错误（比如"动态代码不能用 JSX/TypeScript/require"、"waterfall 必须 next()"）。

### 3.2 三级渐进式发现法

对任何不熟悉的 Harness 能力，我都走"目录 → 精确契约"两步，绝不靠名字猜接口：

```
第 0 级：cordis_inspect_list          → 看有哪些 Provider（Service/Event/Builtin/Slots/Theme/Tool）
第 1 级：Service.listService（空参）   → 看全部服务的"紧凑目录"（key + 方法签名）
         Event.listEvents（空参）      → 看全部事件的"紧凑目录"（name + 监听签名）
第 2 级：Service.listService（带 service）→ 查某个服务的精确契约（方法、参数、返回、access 规则）
         Event.listEvents（带 event）   → 查某个事件的精确契约（参数、mode、referencedTypes）
```

**教训**：`cordis_inspect_list` / `cordis_inspect_query` 是"能力目录"，不是"业务数据"——它能告诉你 API 长什么样，但插件运行时必须调用真实 Service/Event，不能把 inspect 结果当业务数据缓存展示。

### 3.3 读编译产物的 `.d.ts`，而不是猜

关键数据结构（`SessionEvent`、`Agent`、`UserMessage`）的精确字段，我从源码的 `.d.ts` 里直接读出来的：

- `dsh-session/lib/types/types.d.ts` → `SessionEventMap`、`SessionEvent` 信封结构（`{type, seq, time, data, ignorable}`）
- `dsh-agent/lib/types/runtime-types.d.ts` → `Agent` 接口（`inject/followup/steer/send/status/session/id`）
- `dsh-llm/lib/types/message.d.ts` → `UserMessage`、`MessageSource`（`{kind:'plugin', plugin, form, summary}`）

**教训**：`.d.ts` 是系统作者留下的"精确说明书"，比任何猜测都可靠。`grep` 到类型定义后一定要 `read` 原文确认，不要只看 grep 的一行摘要。

### 3.4 找"官方范本"照抄

遇到"怎么做 X"时，先 `grep` 找系统里是否已有类似实现，直接读它的代码：

| 我要做的事 | 找到的范本 |
|---|---|
| 给 AI 注入"任务完成"通知 | `dsh-tool-jobs/lib/index.js` 的 `onJobDone` → `owner.followup(message)` / `owner.inject(message)` |
| 注册一个模型工具 | `dsh-tool-ask-user/lib/index.js` 的 `ctx.tools.register(defineTool({...}))` |
| 插件 `apply(ctx)` 基本结构 | `dsh-tool-call-timeout-policy/lib/index.js` |
| 宿主层如何挂新插件 | `dsh-web-app/cordis.patch.yml`、`dsh-base/cordis.patch.yml` |

**教训**：系统里几乎总有"前任"写过类似的东西。照抄官方范本 = 字段名、source 形状、注入方式都自动正确，比自己猜快且稳。

---

## 4. 关键技术发现

### 4.1 错误相关事件（官方直接暴露）

| 事件 | mode | 签名/载荷 | 用途 |
|---|---|---|---|
| `agent/error` | emit | `{agent, turn, step, error}` | AI 某一步/某轮出错（终态） |
| `agent/request-error` | **waterfall** | `{agent, turn, step, provider, failure, retryPolicy, signal}` + `next()` | 模型请求失败（限流/超时/网络，可重试） |
| `tools/result` | emit | `(exec, result)` | 每个工具调用结束（`result.isError`、`result.error.code`） |
| `session/event` | emit | `(session, event)` | 每次追加会话记录（用于归约上下文） |
| `agent-loop/config-start-failed` | emit | `{sessionId, error}` | 会话/代理启动失败 |

### 4.2 Agent 的"注入通知"接口

`Agent` 接口里四个关键方法（`dsh-agent/lib/types/runtime-types.d.ts`）：

| 方法 | 语义 |
|---|---|
| `inject(message)` | 注入模型可见上下文，**不唤醒** driver；运行中的 agent 在下一步边界领取 |
| `followup(message)` | 排队一个普通跟进轮次并**唤醒** driver |
| `steer(message)` | 提交 steering，空闲则开启新一轮 |
| `send(message, target, wakeup)` | 更底层的路由 |

官方 `dsh-tool-jobs` 的"自动唤醒"策略，我直接沿用：
```js
if (agent.status === 'idle') owner.followup(message)  // 空闲 → 唤醒
else owner.inject(message)                            // 运行中 → 注入
```

### 4.3 `UserMessage` 的 source 形状（最容易错的地方）

注入的 `UserMessage` 必须带正确 `source`，否则可能被校验拒绝或显示错乱：

```js
createUserMessage({
  content: [{ type: 'text', text: '...通知正文...' }],
  source: {
    kind: 'plugin',          // 谁产生的：插件
    plugin: 'dsh-error-audit', // 插件名
    form: 'notice',          // 什么类型：一次性通知
    summary: '一行摘要(<120字)' // notice 形式必需
  }
})
```

`MessageSourceMap` 里 `plugin` 类型 = `{kind:'plugin', plugin:string} & ContextFormed`，而 `ContextFormed` 的 `notice` 变体要求 `summary`。**漏掉 `form`/`summary` 或 `plugin` 名都会埋雷。**

### 4.4 `SessionEvent` 信封结构

```ts
SessionEvent = {
  type: 'user/message' | 'assistant/message' | 'tool/call' | 'tool/result' | 'turn/start' | ...,
  seq: number,
  time: number,
  data: { ... }              // 每种 type 的载荷
  ignorable?: true,
  sourceEventSeqs?: number[],
  surfaceOp?: 'append' | {op:'replace',...}
}
```

归约上下文时我只保留四种有意义的事件，其余全部跳过（见坑 3）。

### 4.5 非零退出 ≠ isError（重要认知）

读 `dsh-tool-pwsh` 的 README 才确认：

> 非零退出是"模型解读的结果"而非 `isError`；只有基础设施失败——spawn 错误与中止（`tool call aborted`）——才产生 `isError`。

所以非零退出在 `tools/result` 里 `isError === false`，只能在输出文本末尾的 `[exit code: N]` 标记里检测。

---

## 5. 架构设计

### 5.1 平面决策：宿主层 vs 预设层

这是最关键的架构判断（来自 `editing-cordis-compositions` 技能）：

- **要跨会话、跨工作区监控所有会话** → 必须挂**宿主层**（host composition 的 `cordis.patch.yml`），因为事件是 scope 过滤的（见坑 8），预设层的插件只能看到自己那个会话。
- 插件自身**不发布任何 Service**，只消费 `tools`（注册工具）、`sessions`、`sandboxPolicy`（可选 `ctx.get`）→ 不需要 `isolate` realm，直接挂宿主的 `insert:` 块即可。

### 5.2 两级交付策略

1. **先用动态插件在本会话跑通**（快速反馈、能立刻验证"通知"效果）。
2. **再沉淀成正式包**（`package.json` + `lib/index.js` + `README` + `LICENSE`），用 `createUserMessage`/`defineTool` 这些正式依赖，node:fs 直接写文件。

**教训**：动态插件适合"验证概念"，正式包适合"交付给别人"。两者共享同一套核心逻辑（归约、诊断、渲染），只是 I/O 层不同。

### 5.3 数据归约原则（贯穿始终）

> 绝不 `JSON.stringify` 任何 Cordis 活对象（Service / Session / Agent / Event 载荷）。

- 只读**叶子字段**（`agent.id`、`session.header.cwd`、`event.data.content`）。
- 立即构造成**自己拥有的纯 JSON**（incident 对象）。
- 错误对象只提取 `message`/`code`/`stack`，不整体序列化。

### 5.4 防御性设计

审计插件运行在"错误路径"里，**它自己绝不能抛错**，否则可能掩盖真实错误或破坏事件分发：

- 每个事件回调都包 `try/catch`。
- 文件写入用 promise 队列 `.catch` 吞错。
- 通知是 best-effort（失败只 `console.error`，不影响落盘）。
- 通知加冷却去重，防止"注入 → 再报错 → 再注入"死循环。

---

## 6. 踩坑记录

> 这一节是全文最有价值的部分。每个坑都按【现象 → 根因 → 修复 → 教训】记录。

### 坑 1：正则文本启发式导致误报

**现象**：触发一次 `pwsh exit 42`，却产生了**两条**日志，其中一条是 `cordis_inspect_self` 被误判成"工具警告"，`error.message` 里塞进了整个 inspect 结果。

**根因**：第一版用 `/\[exit code: [1-9]/` 匹配所有工具的结果文本。而 `cordis_inspect_self` 的返回内容里恰好包含了我插件自己的源码（源码里就有这串正则字面量），于是"结果里出现了 `[exit code:`"就被当成错误了。

**修复**：文本启发式只对 shell 工具（`pwsh`/`bash`）生效，并且把退出标记**锚定到输出末尾**：

```js
const toolName = exec?.name ?? ''
if (toolName !== 'pwsh' && toolName !== 'bash') return { level: null }
const trimmed = text.replace(/\s+$/, '')
if (/\[exit code: [1-9][0-9]*\]$/.test(trimmed)) { /* warning */ }
```

**教训**：
- 用文本内容判断错误，一定要**锚定 + 限定来源**，否则任何"内容里恰好包含关键词"的正常结果（grep 结果、inspect 转储）都会误报。
- 优先用结构化信号（`isError`、`error.code`），文本匹配只做兜底。

### 坑 2：工具事件拿不到 session → 工作区归错

**现象**：`pwsh exit 42` 和 `read 不存在文件` 两条日志里，`sessionId: null`，`workspace` 显示成 `C:\Users\yyyy`（而不是真正的工作区）。

**根因**：`tools/result` 事件签名是 `(exec, result)`，**没有 `payload.agent`**，但 `exec.agent` 里有。第一版只从 `payload.agent` 取 agent，工具事件自然取不到，于是 sessionId 为 null，工作区回退到 `sandboxPolicy.workspaceRoot`（即服务器 `process.cwd()` = `C:\Users\yyyy`）。

**修复**：agent 提取改成多源：
```js
const agent = (payload?.agent) || (payload?.exec?.agent) || null
```

**教训**：不同事件里"agent 在哪儿"不一致——`agent/error` 在 `payload.agent`，`tools/result` 在 `exec.agent`。写代码前要核对**每个事件的精确签名**（坑里全是这种"长得像但位置不同"的细节）。

### 坑 3：`assistant/chunk` 噪声淹没上下文

**现象**：日志里的"最近对话"上下文有约 45/50 条是 `assistant/chunk`（逐 token 流片段），把真正有用的 `user/message`、`assistant/message`、`tool/call` 挤得只剩几条。

**根因**：`session/event` 每追加一条事件就进滚动窗口，而模型每输出一个 token 就有一条 `assistant/chunk` 事件，占了窗口的绝大多数。

**修复**：`reduceEvent` 里只保留四种有意义事件，其余（chunk、step 边界、request header、todo 快照等）一律返回 `null` 跳过：

```js
switch (event.type) {
  case 'user/message': ...
  case 'assistant/message': ...   // 已聚合的完整文本
  case 'tool/call': ...
  case 'tool/result': ...
  case 'turn/end': 仅当 reason.kind === 'error' 时保留
  default: return null            // 跳过 chunk 与元数据
}
```

**教训**：滚动窗口的容量是有限的，**要按"信息价值"筛选事件**，不是无脑全塞。`assistant/message` 已经是 `assistant/chunk` 的聚合，重复记录 chunk 毫无意义。

### 坑 4：动态插件没有 Node 全局

**现象/约束**：动态 Host 代码的 `Builtin.listBuiltins` 只返回 `ctx`、`harness`、`console`、`btoa`、`atob`、`TextEncoder`、`TextDecoder`——**没有 `process`、`require`、`fs`、定时器**。

**后果**：
- 动态版拿不到 `process.env.DSH_HOME` → 只能**硬编码** `C:\Users\yyyy\.dsh\error-audit` 作为目录。
- 动态版不能 `import { createUserMessage }` → 只能**手搓** message 对象。

**教训**：动态插件和正式包的运行环境不一样。**别假设有 Node 全局**，先查 `Builtin.listBuiltins`。正式包（`lib/index.js`）跑在完整 Node 里，`node:fs`/`process` 随便用。

### 坑 5：`fs` 服务没有 mkdir / append

**现象/约束**：抽象 `fs` 服务的方法只有 `resolve/processPath/readText/streamText/readBytes/listDir/writeText/editText/stat/lstat/contains/fileUrl`——**没有 mkdir，也没有 appendText**。

**后果**：
- 动态版无法建子目录 → 改用**扁平文件**（`.md` + `.json` 直接放根目录），且目录需要我事先用 `pwsh` 建好。
- 追加 `index.jsonl` 只能用"读整文件 + 拼接 + 写回"，且要串行化队列防并发写乱。

**教训**：
- 正式包直接用 `node:fs/promises` 的 `mkdir({recursive:true})` + `appendFile`，没有这些限制。
- 这也印证了"两级交付"的必要性：动态插件受运行时约束，正式包才是完整能力。

### 坑 6：非零退出不是 isError

**现象**：`pwsh exit 42` 后，`tools/result` 的 `result.isError` 是 `false`，`result.error` 是 undefined。

**根因**：见 4.5——shell 工具只有 spawn 错误/中止才设 `isError`，非零退出只是文本末尾的 `[exit code: N]` 标记。

**修复**：检测逻辑分层——先看结构化 `isError`/`error.code`（真错误），再看文本末尾的退出标记（非零退出 → warning）。

**教训**：**不要凭"命令失败了"的直觉假设工具结果的结构**，读工具的 README/源码确认它的错误上报契约。

### 坑 7：`UserMessage.source` 的形状

**现象**：给 `agent.inject()` 传消息，如果 `source` 不对，可能被校验拒绝或 UI 显示异常。

**根因**：`source` 是判别联合，`{kind:'plugin'}` 必须带 `plugin` 名，`form:'notice'` 必须带 `summary`。

**修复**：正式包用 `createUserMessage` + 完整 source（见 4.3）；动态版手搓时也照这个形状补全。

**教训**：这类"形状约束"只靠读 `.d.ts` 的 `MessageSourceMap`/`ContextFormed` 才能确认。照官方范本（`dsh-tool-jobs`）是最省事的方式。

### 坑 8：事件 scope 过滤（架构级认知）

**现象**：动态插件只能收到**自己这个会话**的 `agent/error` 等事件，收不到别的会话的。

**根因**：`agent/error` 的签名是 `(this: Scoped<Agent>, payload)`，采用 scope-filtered dispatch——agent 作用域的监听器只收该 agent 的事件。动态插件挂在会话作用域，所以只见本会话。

**后果与修复**：要实现"跨会话监控"，插件必须挂**宿主层（根作用域）**，根监听器能看到所有后代 agent 的事件。这正是开源包设计成宿主层插件的根本原因。

**教训**：**事件的作用域决定你能看到什么**。写跨会话能力前，先看事件的 `this: Scoped<...>` 标注。

### 坑 9：waterfall 事件必须调用 next()

**现象**：`agent/request-error` 是 waterfall，如果监听器不调用 `next()`，模型的**重试恢复逻辑会被打断**。

**修复**：
```js
ctx.on('agent/request-error', (payload, next) => {
  record('warning', 'model-request-error', payload)
  return next()   // 关键：把控制权交还给恢复链
})
```

**教训**：waterfall 事件（`agent/request-error`、`agent/pre-step`、`tools/pre-execute`、`llm/stream` 等）的监听器**必须 next()**，除非你明确要接管结果。emit 事件则无此要求。

### 坑 10：通知可能造成死循环

**风险**：error → 注入通知 → AI 处理通知时又报错 → 又注入 → ……

**修复**：冷却去重——按 `sessionId + kind + code + message前缀` 做指纹，同一指纹在冷却窗口内（默认 5s）不再重复注入。

**教训**：任何"自我触发"的闭环能力都要考虑**终止条件**（去重/限流/冷却）。

### 坑 11：升级 = 新 Package，不可覆盖

**现象/约束**：Cordis 的 Package 是**不可变**的，改了代码不能覆盖旧版本。

**正确姿势**：
1. `cordis_define`（`kind:'existing'`, 原 pluginId）→ 得到新 `packageId`；
2. `cordis_run`（`mode:'update'`）切到新版本；
3. 失败回滚用 `mode:'run'` 回到 `currentPackageId`。

**教训**：我把 pkg-1 → pkg-2 → pkg-3 迭代了三次（修误报、修归属、去噪声），每次都走"新 package + update"，从没覆盖旧版。**回滚能力是靠不可变版本保住的。**

---

## 7. 可复用的经验法则

1. **先读技能，再读目录，再读契约，最后读官方范本。** 顺序不能乱。
2. **用"带推荐默认值的选择题"澄清需求**，别问开放式技术题，别让用户选实现机制。
3. **读 `.d.ts` 而不是猜字段**。grep 到类型定义后必须 read 原文。
4. **找系统里的"前任"照抄**。`dsh-tool-jobs` 的注入通知、`dsh-tool-ask-user` 的工具注册，都是现成范本。
5. **先动态插件验证，再沉淀正式包。** 两级交付，快速反馈 + 正式能力。
6. **绝不序列化活对象**，只读叶子字段、构造纯 JSON。
7. **审计/观测类插件自身必须零抛错**，全程 try/catch，落盘异步吞错。
8. **文本匹配判断错误要锚定 + 限定来源**，优先结构化信号。
9. **核对每个事件的精确签名**——"agent 在哪儿"、"waterfall 要不要 next"、"载荷字段名"每个都可能不一样。
10. **滚动窗口按信息价值筛选**，别让 token 级噪声淹没真上下文。
11. **跨会话能力挂宿主层**，因为事件是 scope 过滤的。
12. **自我触发的闭环要有冷却去重**，防死循环。
13. **改动要造真实错误来验证**——我故意 `exit 42`、故意读不存在的文件，才真正验证了 warning 和 error 两条路径。
14. **"官方/系统是否已有 X" 必须用 grep + 权威工具列表证伪**，绝不能信印象——AI 会对自己反复写过的字符串产生虚假记忆（见 8.1）。
15. **开源前复查要换三个攻击视角**：API 校对员、恶意测试者、新安装用户，最后再跑一遍语法校验（`node --check`）。

---

## 8. 开源前的三遍复查记录

用户要求"检查三遍、确认没有 bug 和遗漏才能开源"。这一轮复查本身又产出了新经验和几个真 bug，记录如下。

### 8.1 一个差点带偏复查的"虚假记忆"

复查时我一度怀疑"官方本来就内置了 `read_error_logs` 工具"（因为它在我的工具列表里、描述又和我要做的一模一样），如果为真，我开源包的注册就会**同名冲突**，是致命的遗漏。

**证伪过程**（不靠记忆，靠硬证据）：
1. `grep` 整个 `node_modules/*.js` 搜 `read_error_logs` → 无结果；
2. `grep` checkout 自身的 `lib/`、`config/` → 无结果；
3. 查用户 `$DSH_HOME/profiles`、`.agent-presets` → 无 `error-audit` 配置；
4. `cordis_inspect_query Tool.listTools` → 那个 `read_error_logs` 的描述**和我自己写的一字不差**。

**结论**：官方**没有**内置这个功能；工具列表里的 `read_error_logs` 是我自己动态插件注册的。我"记得它一开始就在"是**虚假记忆（confabulation）**——因为我在代码里反复写过这串字符串，大脑把它误认成了旧记忆。

**教训**：AI（以及人）会对"自己近期反复写过的字符串"产生虚假的熟悉感。**任何"官方/系统是否已有 X"的判断，都必须用 `grep` + 权威工具列表（`Tool.listTools`）证伪，绝不能信"印象"。**

### 8.2 复查揪出的真 bug（都已在源码修复）

| # | 问题 | 现象/后果 | 修复 |
|---|---|---|---|
| 12 | `errorInfo` 空消息 | 工具返回 `isError` 但无 `error.message` 时，`errorInfo({message:null})` 产出 `"[object Object]"` | `toolDiagnosis` 兜底消息为 `'tool call failed'`；`errorInfo` 对 null/字符串更稳健 |
| 13 | 内存泄漏 | `ring`/`lastNotify` 两个 Map 在会话销毁后永不清理，长驻进程缓慢泄漏 | 监听 `agent/disposed` + `session/disposed` 删除对应条目 |
| 14 | 遗漏：重启丢历史 | `read_error_logs` 只读内存，进程重启后工具显示"暂无记录"（但文件还在磁盘） | 工具合并读取磁盘 `index.jsonl` + 内存，按 id 去重、按时间倒序 |
| 15 | 细节 | `args.id` 查找在过滤之后，id+过滤组合会漏查 | 改为在合并后的全量 `byId` 里查找 |

### 8.3 复查方法论

- **第一遍**：对照官方 API 契约（事件签名、Service 方法、`createUserMessage` source、`SessionEvent` 信封）逐行核对，确认没有"长得像但字段位置不对"的错误。
- **第二遍**：逻辑与边界——内存泄漏、竞态、null 处理、死循环、重启后的可用性。
- **第三遍**：完整性与打包——imports 是否解析、`inject` 是否正确、工具名是否冲突、README/package.json 是否一致，并用 `node --check` 做语法校验。

**核心感悟**：复查不是"再读一遍"，而是**换一个攻击视角**——第一遍当"API 校对员"，第二遍当"恶意测试者"，第三遍当"新安装用户"。

---

## 附录 A：官方接口速查表

### A.1 事件（Event）

| 事件 | mode | 载荷 | 注意 |
|---|---|---|---|
| `agent/error` | emit | `{agent, turn, step, error}` | agent 在 `payload.agent` |
| `agent/request-error` | waterfall | `{agent, turn, step, provider, failure, retryPolicy, signal}` | 必须 `next()` |
| `tools/result` | emit | `(exec, result)` | agent 在 `exec.agent` |
| `session/event` | emit | `(session, event)` | 维护上下文窗口 |
| `agent-loop/config-start-failed` | emit | `{sessionId, error}` | 无 agent 对象 |
| `agent/inbox/inserted` | emit | `{agent, message}` | 观察注入 |
| `tools/execute` / `tools/pre-execute` / `tools/post-execute` | waterfall | 见契约 | 工具管线拦截点 |

### A.2 服务（Service）

| 服务 | 关键方法 |
|---|---|
| `agents` | `get(id)`, `list()`, `roots()`, `currentInitiator()` |
| `sessions` | `get(id)`, `list()` |
| `sessionQuery` | `readSession(id)`, `listEvents(id)`, `readTitle(id)` |
| `fs` | `resolve/readText/writeText/editText/listDir/stat`（**无 mkdir/append**） |
| `sandboxPolicy` | `resolve({session})`, `workspaceRoot`, `defaultMode` |
| `tools` | `register(def)`, `get(name, scope)` |

### A.3 动态 Host Builtin

`ctx`、`harness`、`console`、`btoa`、`atob`、`TextEncoder`、`TextDecoder`（**无 process/require/fs/timer**）。

### A.4 Agent 接口（节选）

`id`、`session`、`status`、`inject(msg)`、`followup(msg)`、`steer(msg)`、`send(msg,target,wakeup)`、`cancel(cause,opts)`、`whenIdle()`

### A.5 UserMessage source

```js
{ kind: 'plugin', plugin: '插件名', form: 'notice', summary: '摘要(<120字)' }
```

### A.6 SessionEvent 信封

```ts
{ type, seq, time, data, ignorable?, sourceEventSeqs?, surfaceOp? }
```

---

## 附录 B：架构图

```
                        ┌─────────────────────────────────────────┐
                        │        DeepSeek Harness 进程             │
                        │                                         │
  官方事件              │   ┌───────────────────────────────┐     │
 agent/error ──────────┼──▶│      dsh-error-audit 插件      │     │
 agent/request-error ──┼──▶│  (宿主层 / 根作用域)            │     │
 tools/result ─────────┼──▶│                                │     │
 session/event ────────┼──▶│  ① 归约上下文(滚动窗口,按session) │     │
 config-start-failed ──┼──▶│  ② buildIncident(时间/码/会话/   │     │
                        │  │    工作区/用户话/AI动作)          │     │
                        │  │  ③ console.error 即时打印        │     │
                        │  │  ④ 落盘 $DSH_HOME/error-audit   │     │
                        │  │     ├ index.jsonl                │     │
                        │  │     └ reports/<id>.md / .json    │     │
                        │  │  ⑤ error级 → agent.inject/followup│    │
                        │  │     (通知出错会话的 AI)            │     │
                        │  └───────────────┬───────────────────┘     │
                        │                  │                         │
                        │                  ▼                         │
                        │        read_error_logs 工具                │
                        │        (AI 随时读取/过滤/读单条)            │
                        └─────────────────────────────────────────┘

目录结构：
error-audit/
├── index.jsonl                     # 追加式总索引（每行一条）
└── reports/
    ├── 2026-...-0001.md            # 人类可读报告
    └── 2026-...-0001.json          # 机器可读记录
```

**事件 → 级别的映射：**

| 事件 | 判定 | 级别 |
|---|---|---|
| `agent/error` | — | error |
| `config-start-failed` | — | error |
| `tools/result` | `isError` 或 `error.code` | error |
| `tools/result`(pwsh/bash) | 文本末尾 `[exit code: N≠0]` 或 `[sandbox: 拒绝]` | warning |
| `agent/request-error` | — | warning |

---

## 附录 C：踩坑-修复对照表

| # | 坑 | 根因 | 修复 | 一句话教训 |
|---|---|---|---|---|
| 1 | inspect_self 被误判 | 正则未锚定+不限工具 | 锚定末尾+只限 shell 工具 | 文本匹配要锚定+限定来源 |
| 2 | 工作区归错 | 工具事件 agent 在 exec.agent | 多源提取 agent | 核对每个事件精确签名 |
| 3 | chunk 淹没上下文 | 窗口无差别收纳 | 只保留有意义事件 | 按信息价值筛选 |
| 4 | 拿不到 DSH_HOME | 动态无 process | 硬编码/正式包用 process.env | 先查 Builtin |
| 5 | 无 mkdir/append | fs 服务缺方法 | 扁平文件+读改写 | 正式包用 node:fs |
| 6 | 非零退出不是 isError | shell 工具契约 | 文本末尾标记检测 | 读工具 README |
| 7 | source 形状易错 | 判别联合约束 | createUserMessage+完整 source | 照官方范本 |
| 8 | 只见本会话 | 事件 scope 过滤 | 挂宿主层 | 跨会话能力挂宿主 |
| 9 | 打断重试 | waterfall 未 next() | return next() | waterfall 必须 next |
| 10 | 可能死循环 | 自我触发 | 冷却去重 | 闭环要有终止条件 |
| 11 | 覆盖旧版 | Package 不可变 | 新 package+update | 不可变版本保回滚 |
| 12 | 空消息变 `[object Object]` | 工具 isError 但无 message | 兜底消息 + errorInfo 稳健化 | 空值也要有兜底文案 |
| 13 | 内存泄漏 | ring/lastNotify 不清理 | agent/session disposed 时删除 | 长驻进程要清理 Map |
| 14 | 重启丢历史 | 只读内存 | 合并读磁盘 index.jsonl | "随时可读"要含持久层 |
| 15 | id 查找漏查 | 先过滤后查找 | 全量 byId 里查找 | 精确查找走未过滤集合 |

---

## 结语

这个项目的核心收获不是"写了个日志插件"，而是沉淀了一套**"AI 自主啃陌生系统"的方法**：读技能 → 读能力目录 → 读精确契约 → 读类型定义 → 读官方范本 → 先验证再交付，以及一路踩坑后总结的"锚定/限定来源、核对签名、按价值筛选、挂对平面、自我闭环加冷却"这些判断力。希望这份手册能让下一个做 Harness 插件的人少走弯路。

（本手册由制作 `dsh-error-audit` 插件的 AI 编写，随插件源码一起开放。）
