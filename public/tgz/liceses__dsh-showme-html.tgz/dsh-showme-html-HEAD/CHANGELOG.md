# 变更记录

## 0.2.6 — 2026-11-01

**模板重做：按内容定密度 + 横屏。** 起因是两句反馈：「纯文字的时候重复的卡片布局会很多」、
「模版有点难看了」，并要求按设计心理学来定，而不是只换配色。

### 改了什么（每条对应一条依据）

- **按内容定密度**（相似性原则 / 孤立效应）：条目不再一人一张卡。纯文字的条目合成**一块面板、一行一条**；
  **只有带 `image` 的条目才单独成卡**。混排时卡片组在前、两组各自保序。整页终于有焦点，不再是一排一模一样的卡。
- **小节标题去掉下边框**（信噪比）：soft 皮肤原来是 `.section > h2 { border-bottom }` + `margin-top: 68px`，
  截图里那对「平行黑线」就是它。改成 `44px` 间距 + 无边框，小节之间靠留白分。
- **横屏用满宽度**（米勒 / 分组）：量宽 soft `900 → 1120`、swiss `1060 → 1180`、blueprint/brutal `1020 → 1120`；
  `≥900px` 报头走两栏（标题在左、元信息在右）；文字行的判定控件固定 `296px` 右列成一列；
  `≤760px` 行折一列、分段控件铺满一行。
- **控件**（希克 / 菲茨）：判定改成胶囊**分段控件**（`role="group"` + `aria-label`，按钮高 36px）；
  补 `:focus-visible` 焦点环（以前只有备注输入改边框，键盘用户看不见按钮焦点）；
  行里的备注改成**虚线 + 静音**（可选项不该抢判定按钮的注意力）；卡片最大 `640px`、图 `max-height: 60vh`。
- **完成感**（目标梯度 / 蔡格尼克）：回执区新增进度「已表态 n / m」；已表态的条目 id 追加 `✓`、描述降权。
- **report 小节回执**：从「每节一张卡」改成**一行回执条**（id 在左、判定 + 备注在右并排），不再占一整块面板的高度。

### 可见变化（升级要知道）

- **没有 `image` 的条目从「卡」变「行」**。数据一个字都不用改，渲染形态变了。
- `sections[].two` 现在只影响带图卡片那一组；纯文字行永远是整行。

### 验证

- `npm test` **351 项全绿**：清单 7 / 宿主 116 / mermaid 35 / 客户端 72 / 预设 38 / **模板 46（+13）** / 页面 37。
- 新增 13 条护栏：纯文字不许成卡、带图必须成卡、混排保序、分段控件包裹与组名、`sm-note`/`sm-btn` 契约仍在、
  soft 皮肤无 `border-bottom`、`:focus-visible` 存在、窄屏铺满规则存在、完成降权存在、横屏两栏存在、进度元素存在。
- 真机（本地静态服务 + 真实浏览器）：`.dsh/showme/tpl-{review,pick,report}.html` 三种形状 × 1120 / 560 两宽度实拍；
  点一次判定 → id 出现 `✓`、回执 `已表态 1 / 6`、`#sm-out` 里出现 `stats-panel 要改`，全部照预期。

## 0.2.5 — 2026-11-01

**在独立实例上真跑了一轮 `show_html`，一次验出三个 bug，全修。**

0.2.4 把卡片搬成独立 Chat 行之后，只在离线测试里过 —— 真机上第一个回合就露馅了：
卡片在，但**身体是白的**，控制台/接口还报 `expected /raw/<sessionId>/<workspace-relative path>`。

### 修

- **卡片身体白屏（懒挂载永不触发）**。`IntersectionObserver` 在 chat 的流容器
  （`overflow: clip` + `container-type: inline-size`）里首次回调就是 `isIntersecting: false`，
  之后不再触发 —— 页面永远停在"滚动到这里时载入页面"。改成**几何判断 + 退避轮询**
  （250ms → ×1.6 → 上限 3s），scroll/resize 立即复检，进视口就停表。
  离屏历史卡片仍不持有活 iframe。
- **`expected /raw/<sessionId>/<workspace-relative path>`**（两层）：
  ① `ShowmePageNode` 只转交了 `{source, openFile}`，**把槽位标准 props 里的 `sessionId` 丢了**；
  ② `rawUrl('')` 会硬拼出 `/api/showme/raw//<path>`。现在显式转交 + 三级兜底
  （槽位 props → `meta.url` → `conversation.input.left` 记下的当前会话），
  `rawUrl` 遇空 id 直接返回空串。
- 地址为空时卡片显示「拿不到这一页的地址（会话还没就绪）。刷新一下聊天页再试。」，
  不再挂一个坏 iframe 让用户对着白块猜。

### 实测（独立实例，真模型回合）

```
tool/call   name=show_html  args={"path":".dsh/showme/mermaid-demo.html","title":"折叠验证"}
tool/result meta={"bytes":2107,"url":"/api/showme/raw/session-…/.dsh/showme/mermaid-demo.html"}
DOM： [data-chat-flow-kind="showme-page"] 存在（不在过程组里）
      iframe 1 个，.dsh-showme-placeholder 0 个
```

轮次结束后工具调用收起，卡片里的页面照常渲染。

- 离线断言 **338 项全绿**（清单 7 / 宿主 116 / mermaid 35 / **客户端 72** / 预设 38 / 模板 33 / 页面 37）。

## 0.2.4 — 2026-11-01

**页面卡片不再被「工作步骤」折叠吃掉 —— 它现在是一条独立的 Chat 行。**

### 修

- DSH 新版加了「工作步骤展示」：完成的轮次会把**整个过程组**收起来（简洁 / 标准 / 详细三档都收，
  只有「完全展开」不收）。卡片原来长在工具行内部（`tool.call.toolview`），工具行属于过程组，
  于是整页卡片被一起折掉 —— 用户得展开「工作步骤」→ 再展开某一组才找得到页面。
- 根因不是 CSS，是 chat 的分组规则：`TurnGroups.rebuild()` 按 `isAtOrOutside(node, 'process')`
  切分，**只有 `groupTree` 深度 ≤ `process` 的节点才不进组**（`exchange:0 / input:1 / turn:2 / process:3`）。
  工具调用行不声明 `groupTree`，默认就落在 `process` 上。

### 加

- **自家的 Chat 行**：`ctx.uiConversation.events.register()` 注册一条 `kind: 'showme-page'` 的行定义，
  渲染器挂在 `conversation.chat.node` 槽位（key = kind）。节点声明 **`groupTree: 'turn'`**
  （深度 2 ≤ 3）→ 不进过程组 → 折叠与它无关。DSH 自己的错误行（`turn-error`）用的就是同一招。
- 行数据从会话事件投影出来：`tool/call` 取参数、`tool/result` 取 `meta`（就是 `presentationMeta()`
  写的 `{ bytes, url }`）与错误态；会话 id 从地址里解（节点视图拿不到 `props.sessionId`）。
- 工具行降为**一行摘要**（标题 / 体积 / 「页面在下方」/ 侧栏打开 / 浏览器打开），不再内嵌 iframe。
- 旧宿主的兼容：`uiConversation` 是**可选注入**，服务不在时整段不执行、工具行原样内嵌整卡。

### 实测

- 离线断言 **333 项全绿**（清单 7 / 宿主 116 / mermaid 35 / **客户端 67** / 预设 38 / 模板 33 / 页面 37）。
  客户端新增 15 条：只认 `show_html`、`groupId` 归并、`groupTree === 'turn'`、`anchorSeq` 落点、
  `meta` 落地、从地址解会话 id、摘要行没有 iframe、缺 `uiConversation` 时不注册。
- `doctor` 的 `[5]` 在运行中的实例上核到新 bundle（25 个类名）。

### 已知边界

- 卡片位置跟着**调用结果**走（不是轮次末尾）：一轮里调两次 `show_html`，过程组会被切成
  `组 → 卡片 → 组 → 卡片 → 回答`。这是刻意的 —— 卡片要贴着它对应的那次调用。
- 只有 `show_html` 这么搬。其它工具（bash / read / edit …）照旧在过程组里折叠。

## 0.2.3 — 2026-11-01

**0.2.2 的补丁版：只补文档与截图，代码一行未改。**

为什么单独发一版而不是挪 `v0.2.2` 的 tag：tag 一旦推出去就不再移动，
而 0.2.2 的 tag 打在功能提交上 —— 从 tag 下载的包里 README 的两张 mermaid 图是断的。
所以按补丁版补发，功能与 0.2.2 完全一致。

### 加

- `docs/screenshots/mermaid-diagrams.png`：flowchart / sequence / state / pie 一页四图。
- `docs/screenshots/mermaid-types.png`：classDiagram / er / gitGraph / mindmap。
  两张都是**真截图**——临时实例（`dsh web --port 3312`）的镜像路由打开页面后拍的，
  原件在 `examples/mermaid-demo.html` 与 `examples/mermaid-types.html`，可复现。
- README 的 [mermaid] 一节补上这两张图与图注；仓库结构里标明哪个示例是截图原件。

### 说明

- 版本号为什么不是 `0.2.2.1`：语义化版本只有三段，`semver.valid('0.2.2.1') === null`；
  而 `0.2.2-1` 虽然合法，排序却**低于** `0.2.2`（预发布版），任何比较都会当成降级。
  "0.2.2 之后的一个补丁"在 semver 里就是 `0.2.3`。

## 0.2.2 — 2026-11-01

**页面里可以直接写 mermaid 了；而且图写错时 `show_html` 会当场失败。**

### 升级

- **重启一次 `dsh web` / 桌面实例**（宿主半区在启动时装载，改配置触发不了重载）。
  mermaid 的 5.5 MB 随包走，不下载、不改任何配置。
- 落地副本：`presets/` 不用动；`templates/README.md` 想拿到新版（多了"想画图"一节）就跑
  `npm run assets:refresh` —— create-only，旧文件会先备份成 `.bak-<时间戳>`。
- 重启后确认：`node test/doctor.mjs` 的 `[4]` 里应有
  `vendor 路由可达 …… 与磁盘一致（5494801 字节）`。

### 加

- **mermaid 支持**。页面里写 `<pre class="mermaid">graph TD; A-->B</pre>` 就会渲染成图
  （也认 `<div class="mermaid">`、`<code class="language-mermaid">`、`<pre data-mermaid>`）。
  vendored 的是 mermaid **12.2.0** 的 `dist/mermaid.min.js`（5.49 MB，普通脚本），
  由新路由 `GET /api/showme/vendor/mermaid.min.js` 发出，页面用 `<script src>` 加载 ——
  展示页是不透明源，`fetch` 会被跨域拦，只有 `<script src>` 过得去；也不走 CDN。
- **宿主侧语法预检**：`show_html` 返回**之前**，宿主把页面里每个 mermaid 块解析一遍。
  图写错 → 这次工具调用直接失败，报错里是 mermaid 自己的 `Parse error on line N: … ^` 原文。
  这就是"渲染报错 = 页面不通过"。
  实现：把 vendored 的 mermaid 喂进 `node:vm`；没有真 DOM 时 dompurify 会退化成空壳，
  流程图一解析就抛 `TypeError: Z1.addHook is not a function`，所以在**内存里**把
  `Z1=Rsr()` 换成 stub（磁盘上的文件不动，浏览器拿到的仍是原版）。
  首次加载 ~150 ms（每进程一次），每块 5–50 ms。补丁点由测试钉住：升级 mermaid 时会先红。
- **渲染回执与截图**：页面渲染完把每张图导出 PNG，`postMessage` → 浏览器半区（同源）
  `POST /api/showme/mermaid` → 落盘到 `<工作区>/.dsh/showme/mermaid/<页面名>.<序号>.png`
  （另写 `<页面名>.json`；有失败再写 `<页面名>.errors.txt`）。
  路径是**可预测**的，`show_html` 的结果里直接给出，模型渲染完 `read_image` 就能看见自己画的图。
- 卡片头部新增 mermaid 徽标：全部渲染成功是 `mermaid ✓`，运行时失败是红色 `mermaid 失败 ×N`
  （悬停看每张图的报错）。
- 纯静态页（没有内联 `<script>`）不再被页面冒烟测试判失败 —— 带图的页面常常一行 JS 都不用写。

### 为什么不用 `@mermaid-js/parser`

试过（2.0.1）：它只覆盖 architecture / gitgraph / packet / pie / radar / treemap / wardley /
cynefin / info / railroad / treeview / eventmodeling —— **没有 flowchart / sequence / class /
state / er**，而这几个恰好是最常写的。所以舍掉。

### 实测

- 离线断言 **318 项全绿**（清单 7 / 宿主 116 / mermaid 35 / 客户端 52 / 预设 38 / 模板 33 / 页面 37）。
  宿主的第 117 条是"软链接逃逸 403"——Windows 上建不出软链接时自动跳过，不是失败。
- 预检覆盖的图类型：flowchart / sequence / class / state / er / pie / gantt / mindmap 各一条好图
  全部通过；`graph TD; A-->` 这类坏图抛出带 `^` 指位的原文。

### 文档

- `vendor/README.md`：版本、sha256、为什么是单文件普通脚本、Node 侧为什么要打补丁、补丁点长什么样。
- `npm run vendor:mermaid`（`tools/vendor-mermaid.mjs`）：重新拉取并覆盖 `vendor/mermaid.min.js`。
- `SKILL.md` 新增 **§1.2**（怎么画、写错会失败、PNG 在哪、预检只管语法），TL;DR 与 `whenToUse` 各补一句。
  **没有重编号**——`templates/core.js`、`templates/README.md`、`README.md` 都在引用 §5。
- `templates/README.md` 新增"想画图：模板里没有图块，自己写页面"（含可直接抄的最小例子）。
- README 的 mermaid 一节补**两张真实截图**：`docs/screenshots/mermaid-diagrams.png`
  （flowchart / sequence / state / pie）与 `mermaid-types.png`（classDiagram / er / gitGraph / mindmap）。
  原件是 `examples/mermaid-demo.html` 与 `examples/mermaid-types.html`，
  截图就是经镜像路由打开这两个文件的样子 —— 不是拼出来的示意图。
- `README.md`：版本徽章 0.2.2、新增 [mermaid](#mermaid) 一节与目录项、已知限制补三条、仓库结构补
  `lib/mermaid-*.js` / `vendor/` / `tools/`、断言总数与分项同步。

### 已知边界

- 预检只查**语法**。运行时渲染错误（预检过了但浏览器里仍失败）拦不住已经返回的工具调用，
  这类错误显示成页面里的红框 + 卡片徽标 + `<页面名>.errors.txt`。
- JS 里动态拼出来的 mermaid 块不在预检范围内（宿主只扫静态 HTML）。
- 页面超过 2 MB 时不注入引导脚本。
- 原生文档预览（blob iframe）里没有 vendor 路由，图不会渲染 —— 用卡片 / 侧栏 / 全屏。

## 0.2.1 — 2026-11-01

**修一个只在 DSH 0.2.1-rc.5 上现形的 bug；补上"落地副本"这条盲区。**

### 修

- **镜像路由对"本进程还没加载过"的会话回 404**（rc.5 上）。
  根因：`sessionQuery.readSession()` 返回的是
  `{ session: <克隆的 header>, inheritedEventCount, events }` —— cwd 挂在 `session` 下，
  而 `readCwd()` 只认顶层 `header`。兜底链是 `sessions.get()` → `sessionQuery.readSession()`，
  前者对没加载过的会话是 miss，于是整条链断掉，诊断串是
  `sessions.get=miss sessionQuery=no-cwd`。
  现在 `readCwd()` 依次尝试 `header.cwd` / `session.cwd` / `session.header.cwd` / `meta.cwd` / `cwd`。
  回归用例：`test/route.test.mjs` 的「rc.5 的 { session: header } 形态也能解析」。
- 这个 bug **只在刚启动的进程上现形**：实例跑久了、会话被热起来之后，`sessions.get()` 会命中，
  症状自己消失（实测：同一个 3080 进程，23:48 启动，00:30 左右两个会话都 404，
  02:09 同样的请求全部 200）。所以验证必须对着**新起的实例**做，别对着跑了一天的那个。

### 加

- `npm run doctor` 第 **[6]** 节：工作区里 `.dsh/showme/templates/` 的落地副本是否与包内一致。
  落地是 create-only，插件升级或改了模板文档之后，工作区那份会悄悄停在旧版 ——
  症状不是报错，而是文档教的是已废弃的流程（这个坑踩过两次，现在有断言盯着）。
- `npm run assets:refresh`（`tools/refresh-assets.mjs`）：同步落地副本。
  覆盖前把旧文件备份成 `<文件名>.bak-<本地时间戳>`；`presets/` 默认只补缺、不覆盖内容。
- `tools/`：`asar-peek.mjs` / `asar-scan.mjs`（只读解析 `app.asar`，用来核对宿主契约）
  与 `asar-lib.mjs`。**不进 npm 包**（`files` 里没有 `tools/`）。

### 实测（DSH 0.2.1-rc.5，全局 npm 装的那份）

- `npm run doctor` 六节全绿：客户端半区 rev `ea91496cdb57`，23 个 `dsh-showme-*` 类名逐个核对通过。
- `live-probe` 五项全绿：页面 200 / 相对引用 SVG 200 / 越界 403 / 不存在 404 / 未登记类型 415。
- 404 那个 bug 的 A/B：同一份 rc.5、同一个持久化会话、**新起的实例** ——
  修前 `{"ok":false,"error":"unknown session: … (sessions.get=miss sessionQuery=no-cwd)"}`，
  修后 200 + 12 KB 页面正文。
- 离线断言 253 项全绿（清单 7 / 宿主 86 / 客户端 52 / 预设 38 / 模板 33 / 页面 37）。

### 文档

- README 版本徽章从 `0.1.0` 修正为当前版本；卡片头部图注补上「侧栏打开」（是四个按钮，不是三个）。
- README「支持的 DSH 版本」补 `0.2.1-rc.5`；开发一节的示例端口从已失效的 19387 改为 2785。
- 0.2.0 留下的那条边界（"没在 0.2.1-rc.2 上重跑 UI 人工回归"）已由用户在桌面端
  实际使用确认：对话卡片 / 全屏 / 侧栏打开 / 反馈回填都走过了。

## 0.2.0 — 2026-10-29

**兼容 DSH 0.2.x。**

- `engines.dsh` 由 `^0.1.7-rc.1` 放宽为 `^0.1.7-rc.1 || ^0.2.1-rc.1`。
  此前这条声明让插件在 DSH 0.2.1-rc.2 上被硬门禁拦下（安装与启动都会被拒），
  现在两个 DSH 版本线都声明支持。
- 在 DSH `0.2.1-rc.2` 上实测通过的证据（不是"应该能跑"）：
  - 宿主半区：`GET /api/showme/raw/<session>/<path>` 返回插件自己的 `unknown session` JSON，
    说明 `ctx.webServer.register` 那条前缀路由已挂上；
  - 浏览器半区：HMR graph 里出现 `dsh-showme-html`（`plugins/??dsh-showme-html/client.js&rev=…`），
    且该 bundle 可取回 29 KB 正文，说明 `dsh.client` 被 client-modules 正常发现。
  - 业务代码**未改一行**：`sidebarRightTabs` / `slots` / `tools` / `webServer` 四个扩展点在
    `0.2.1-rc.2` 的 `app.asar` 里都还在（逐个字符串核对过），API 形状未变。
- README 增加「支持的 DSH 版本」一段：写清这条声明是硬门禁、失败长什么样、
  以及 `dsh plugin allow-version` 这个精确版本逃生舱怎么用。

未覆盖的边界：本轮验的是「装载 + 路由可达」，没有在 0.2.1-rc.2 上重跑一遍
「对话卡片 / 全屏 / 右侧栏页类型」的人工交互回归；UI 层的自动化断言仍是
`npm test` 的 245 项离线断言（它们不依赖 DSH 版本）。

## 0.1.0

首个可用版本。

- `show_html` 工具（`path` / `title` / `note`）：把工作区里的 HTML 页直接展示在对话里。
- 镜像读路由 `/api/showme/raw/<sessionId>/<工作区相对路径>`，带工作区围栏（越界 403 / 不存在 404 / 未登记类型 415），
  页面里的相对引用天然可用。
- 三个呈现面：对话内卡片、画面内全屏（`shell.overlay`）、右侧栏页类型（`sidebarRightTabs`）。
- 反馈闭环：页面上「点名 + 表态」→ 一行回执 → 一键填回输入框 → 回到 agent 手里。
