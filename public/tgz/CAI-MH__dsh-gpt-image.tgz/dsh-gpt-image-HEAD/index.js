// dsh-gpt-image — 控制网页版 ChatGPT 生成图片并下载到本地（Host bundle 插件）。
// 通过注册 gpt_generate_image 工具，驱动已登录的 Edge 里的 ChatGPT 生成图片并下载。
import { defineTool } from '@deepseek-ai/dsh-tools'
import os from 'node:os'

export const name = 'gpt-image'
export const inject = ['tools', 'shell']

// 生图脚本及其依赖（puppeteer-core）所在目录：全局资源，默认 dph 工作区，
// 可用 profile 配置覆盖（cordis.patch.yml: - id: gpt-image / config: { workspace: <目录> }）。
const DEFAULT_CONFIG = { workspace: `${os.homedir()}/work/dph` }
const RUN_TIMEOUT_MS = 6 * 60 * 1000

const render = (_args, value) => [
  { type: 'text', text: typeof value === 'string' ? value : JSON.stringify(value, null, 2) },
]

export function apply(ctx, config) {
  const cfg = Object.assign({}, DEFAULT_CONFIG, config)
  const WORKSPACE = cfg.workspace
  const SCRIPT = WORKSPACE + '/gpt-image.mjs'
  ctx.effect(() => {
    const disposers = []

    // 持久行为约定：遇到生图类任务时，先询问是否使用本工具。
    const systemPrompt = ctx.get('systemPrompt')
    if (systemPrompt !== undefined) {
      const d = systemPrompt.section({
        name: 'gpt-image',
        order: 950,
        text: '当用户提出生成图片、画图、配图、插图等「生图」类任务时，先用 ask_user_question 询问用户是否需要使用 gpt_generate_image 工具（通过已登录的网页版 ChatGPT 实际生成并下载图片到本地）。用户确认需要、且 Edge 已用调试端口启动并登录 ChatGPT 后，再调用该工具；用户不需要则按其他方式处理。' +
          '若调用 gpt_generate_image 返回 ok:false 且报错含「fetch failed」或「Failed to fetch browser webSocket」，说明 Edge 调试端口（9222）已断开：先运行 bash ' + WORKSPACE + '/ensure-edge-debug.sh 恢复 Edge（该脚本幂等，端口已就绪则直接成功，断开则自动重启 Edge；需 sandbox_permissions: danger-full-access），确认端口就绪后直接重试 gpt_generate_image，无需逐步排查。',
      })
      if (typeof d === 'function') disposers.push(d)
    }

    disposers.push(ctx.tools.register(defineTool({
      name: 'gpt_generate_image',
      description:
        '控制已登录的网页版 ChatGPT 生成图片并下载到本地。传入 prompt 提示词后，工具会复用已登录的 ChatGPT 标签页，发送提示词，等待图片生成完成，然后下载到 downloads/ 目录。' +
        '前提：需要先让 Edge 以调试端口启动（运行工作区的 start-edge-debug.sh）并在其中登录 ChatGPT。' +
        '若生成失败或超时，返回的 message 会给出原因。',
      parameters: {
        prompt: {
          type: 'string',
          required: true,
          description: '生成图片的提示词，需明确表达生成图片的意图，例如「画一只戴着宇航员头盔的橘猫，卡通风格」。',
        },
        newChat: {
          type: 'boolean',
          description: '是否在发送前新建对话。默认 false（在当前对话继续）。',
        },
      },
      output: { schema: { type: 'object', additionalProperties: true }, render },
      timeoutMs: RUN_TIMEOUT_MS + 20000,
      async execute(args, exec) {
        const prompt = String((args && args.prompt) || '').trim()
        if (!prompt) throw new Error('prompt 不能为空')

        const env = { GPT_PROMPT: prompt }
        if (args && args.newChat) env.NEW_CHAT = '1'

        // 用调用方 session 解析 sandbox policy，使 workspaceRoot 指向会话工作区（而非进程 cwd）
        const sandboxPolicyService = ctx.get('sandboxPolicy')
        const sandboxPolicy = sandboxPolicyService !== undefined
          ? sandboxPolicyService.resolve(exec && exec.agent ? { session: exec.agent.session } : {})
          : undefined

        // 下载目录指向会话工作区（而非 workspace 外的固定 downloads/），避免被文件沙箱拦截
        if (sandboxPolicy && sandboxPolicy.workspaceRoot) {
          env.OUT_DIR = sandboxPolicy.workspaceRoot.replace(/[\/\\]+$/, '') + '/figures/gpt_generated'
        }

        const spec = ctx.shell.resolve({
          command: "node '" + SCRIPT + "'",
          workdir: WORKSPACE,
          timeoutMs: RUN_TIMEOUT_MS,
          env,
          sandboxPolicy,
        })
        const result = await ctx.shell.run(spec)
        const out = (result.stdout && result.stdout.text) || ''
        const err = (result.stderr && result.stderr.text) || ''

        if (result.timedOut) {
          return { ok: false, message: '生成超时（超过 6 分钟），可稍后重试' }
        }

        const m = out.match(/图片已保存:\s*(\S+)/)
        const savedPath = m ? m[1] : undefined

        if (result.exitCode === 0 && savedPath) {
          return { ok: true, savedPath, message: '图片已生成并下载' }
        }

        return { ok: false, message: '生成失败（exit ' + result.exitCode + '）: ' + (err || out).slice(-400) }
      },
    })))

    return () => {
      for (const d of disposers.splice(0)) d()
    }
  }, 'gpt-image')
}

export default { name, inject, apply }
