# ChatGPT 生图（dsh-gpt-image）

控制已登录的网页版 ChatGPT 生成图片并下载到本地的 DSH 插件：注册
`gpt_generate_image` 工具，复用 Edge 调试端口（9222）里的 ChatGPT 会话生成图片。

## 文件

- `index.js` — Host 半部分：注册 `gpt_generate_image` 工具 + 生图行为系统提示词
- `cordis.patch.yml` — host 组合插件行（id: `gpt-image`）
- `package.json` — bundle 元数据

## 依赖的全局资源（不在本 bundle 内）

生图脚本 `gpt-image.mjs`（含 puppeteer-core 依赖）、`ensure-edge-debug.sh`、
`start-edge-debug.sh` 及 Edge 调试 profile，均位于脚本目录（默认
`~/work/dph/`）。生成图片下载到**当前会话工作区**的 `figures/gpt_generated/`。

## 配置与迁移（重要）

默认脚本目录为 `~/work/dph`。若要迁移脚本与 Edge 资源目录，
**不要改本 bundle 源码**，改 web profile 的补丁配置：

`~/Library/Application Support/dsh-desktop/harness/profiles/web/cordis.patch.yml`

```yaml
- id: gpt-image
  config:
    workspace: ~/work/dph
```

把 `workspace` 改成新目录后重启 DSH Desktop 即可。

## 安装与生效

bundle 注册在 web profile 的 `package.json`（dependencies + `dsh.profile.bundles`），
`node_modules` 内为副本。**改代码要改本目录再重新拷贝进 node_modules，然后重启 DSH Desktop。**
