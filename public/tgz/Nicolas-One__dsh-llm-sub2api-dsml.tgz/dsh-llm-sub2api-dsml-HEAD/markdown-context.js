/** 有界的 Markdown 与显式讨论上下文；用于保护示例，不尝试理解回答语义。@author wwj */
const EXAMPLE = /(?:示例|例子|(?:讨论|引用|演示|以下|下面).*(?:标签|标记|语法)|\b(?:example|literal|syntax|discuss(?:ing)?|quot(?:e|ing)|following tags)\b)/i;

export class MarkdownContext {
  line = '';
  fence;
  inline = 0;
  ticks = 0;
  example = false;
  quoted = false;

  get protected() {
    return this.example || this.quoted || EXAMPLE.test(this.line) || Boolean(this.fence || this.inline || this.ticks)
      || /^(?: {0,3}>| {4}|\t| {0,3}(?:`{3,}|~{3,}))/.test(this.line);
  }

  get lineStart() { return /^[ \t\r]*$/.test(this.line); }

  push(char) {
    if (char === '`') this.ticks++;
    else if (this.ticks) {
      if (!this.inline) this.inline = this.ticks;
      else if (this.inline === this.ticks) this.inline = 0;
      this.ticks = 0;
    }
    if (char === '\n') {
      if (/^ {0,3}>/.test(this.line)) this.quoted = true;
      else if (!this.line.trim()) this.quoted = false;
      const match = /^ {0,3}(`{3,}|~{3,})(.*)$/.exec(this.line);
      if (match) {
        if (!this.fence) this.fence = match[1];
        else if (match[1][0] === this.fence[0] && match[1].length >= this.fence.length
          && !match[2].trim()) this.fence = undefined;
        this.inline = 0;
      }
      // 显式介绍标签、语法或示例后保守保留本块余下内容，避免把讨论变成执行。
      if (!this.fence && EXAMPLE.test(this.line)) {
        this.example = true;
      }
      this.line = '';
    } else if (this.line.length < 512) this.line += char;
  }
}
