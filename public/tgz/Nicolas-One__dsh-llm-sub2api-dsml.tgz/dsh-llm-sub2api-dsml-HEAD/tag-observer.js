/** 未确认语法只记录类别，不删除、不执行、不记录内容；命中不等于确认泄漏。@author wwj */
import { MarkdownContext } from './markdown-context.js';

const FAMILIES = [
  ['xml-tool', /^(?:tool_calls|tool_call|invoke|parameter|tool_name)$/],
  ['ds-tool', /^ds_tool(?:$|[-_:])/],
  ['ds-safety', /^ds_safety(?:$|[-_:])/],
  ['platform', /^(?:gongfeng|gazelle|gitsource)(?:$|[-_:])/],
  ['orchestration', /^(?:ai-content|route|framework)(?:$|[-_:])/],
  ['answer', /^answer$/],
  ['localized-tool', /^工具调用$/],
];

export class TagObserver {
  context = new MarkdownContext();
  pending = '';
  tail = '';
  constructor(report, seen = new Set()) { this.report = report; this.seen = seen; }

  record(category) {
    if (this.seen.has(category)) return;
    this.seen.add(category);
    this.report({ status: 'observed', category });
  }

  push(text) {
    for (const char of text) {
      const protectedText = this.context.protected;
      this.context.push(char);
      if (protectedText) { this.pending = this.tail = ''; continue; }
      this.tail = (this.tail + char).slice(-32);
      if (/(?:｜工具｜|｜tool_call_begin｜)$/.test(this.tail)) this.record('localized-tool');
      if (char === '<') this.pending = '<';
      else if (this.pending) {
        this.pending += char;
        if (char === '>') {
          const name = /^<\/?([\w\u4e00-\u9fff:-]+)(?:\s[^<>]*)?\s*>$/.exec(this.pending)?.[1];
          if (name) for (const [category, pattern] of FAMILIES) {
            if (pattern.test(name)) this.record(category);
          }
          this.pending = '';
        } else if (this.pending.length > 192) this.pending = '';
      }
    }
  }
}
