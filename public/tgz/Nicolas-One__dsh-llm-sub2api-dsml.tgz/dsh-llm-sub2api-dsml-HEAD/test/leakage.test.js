import test from 'node:test';
import assert from 'node:assert/strict';
import { EMPTY_RESPONSE_CODE } from '@deepseek-ai/dsh-llm';
import { run, chunks, root, invoke, sample } from './helpers.js';

function textChunks(text, parts = [...text]) {
  return chunks(text, parts).map((chunk) => ({ ...chunk,
    ...(chunk.type === 'reasoning-delta' ? { type: 'text-delta' } : {}),
    ...(chunk.blockType ? { blockType: 'text' } : {}),
    ...(chunk.block ? { block: { ...chunk.block, type: 'text' } } : {}),
  }));
}
const suffixes = ['</｜｜DSML｜｜invoke></｜｜DSML｜｜calls>', '</invoke></｜｜DSML｜｜calls>',
  '</｜DSML｜calls>', '</parameter>\n</invoke>\n</｜DSML｜ function_calls>',
  '</｜DSML｜invoke>\n</｜｜DSML｜｜calls>'];
const deltas = (result) => result.output.filter((c) => c.type === 'text-delta').map((c) => c.text).join('');

test('已报告的单个、多枚、混合闭合标签在每个分片边界清理，空结果报 EMPTY_RESPONSE', async () => {
  for (const suffix of suffixes) {
    for (let i = 0; i <= suffix.length; i++) {
      const result = await run(textChunks(suffix, [suffix.slice(0, i), suffix.slice(i)]));
      assert.equal(result.finish.failure?.code, EMPTY_RESPONSE_CODE, suffix);
      assert.equal(result.blocks[0].text, '');
      assert.equal(deltas(result), '');
      assert.equal(result.calls.length, 0);
    }
  }
});

test('正文加尾部与块首无名标记在 delta 和权威块中都清理，正文保留', async () => {
  for (const text of ['<｜｜DSML｜｜>正常答案。', '<｜DSML｜>正常答案。',
    `正常答案。${suffixes[1]}`, `<｜｜DSML｜｜>正常答案。${suffixes[0]}`]) {
    for (const input of [textChunks(text), textChunks(text).filter((c) => c.type !== 'block-end'),
      textChunks(text).filter((c) => c.type !== 'text-delta')]) {
      input.at(-1).replayState = { opaque: true };
      const result = await run(input);
      assert.equal(result.finish.kind, 'stop');
      assert.equal(result.blocks[0].text, '正常答案。');
      assert.equal(result.output.at(-1).replayState, undefined);
      assert.ok(!deltas(result).includes('DSML'));
    }
  }
  const empty = await run(textChunks('<｜｜DSML｜｜>'));
  assert.equal(empty.finish.failure?.code, EMPTY_RESPONSE_CODE);
});

test('function_calls 根支持两种 DSML 包装并继续校验参数与调用边界', async () => {
  for (const marker of ['｜DSML｜', '｜｜DSML｜｜']) {
    const valid = sample.replaceAll('｜DSML｜', marker).replaceAll(' calls>', ' function_calls>');
    const result = await run(chunks(valid, [...valid]));
    assert.equal(result.finish.kind, 'tool-calls');
    assert.deepEqual(JSON.parse(result.calls[0].arguments), { command: 'echo test' });
    const invalid = root(invoke('missing')).replaceAll(' calls>', ' function_calls>');
    assert.equal((await run(chunks(invalid))).finish.kind, 'error');
    assert.equal((await run(chunks(valid.slice(0, -8)))).calls.length, 0);
  }
});

test('引用、行内代码、缩进、围栏和明确讨论上下文不删除也不执行', async () => {
  for (const payload of [suffixes[0], root(), '<｜｜DSML｜｜>']) {
    for (const text of [`\`${payload}\``, `> ${payload}`, `    ${payload}`, `\t${payload}`,
      `\`\`\`xml\n${payload}\n\`\`\``, `~~~xml\n${payload}\n~~~`,
      `以下是正在讨论的标记：\n${payload}`, `Example syntax:\n\n${payload}`]) {
      const result = await run(textChunks(text));
      assert.equal(result.blocks[0].text, text, text);
      assert.equal(result.calls.length, 0, text);
      assert.equal(result.finish.kind, 'stop', text);
    }
  }
});

test('裸 XML、普通正文中间标签和 JSON 示例原样保留，且保留 replayState', async () => {
  for (const text of ['</invoke></parameter></calls>', '<tool_calls><invoke name="bash"/></tool_calls>',
    '正常内容<｜｜DSML｜｜>正常内容', `${suffixes[0]}\n后面还有普通正文`,
    '```json\n{"tool":"bash","command":"echo test"}\n```']) {
    const input = textChunks(text);
    input.at(-1).replayState = { opaque: true };
    const result = await run(input);
    assert.equal(result.blocks[0].text, text);
    assert.equal(deltas(result), text);
    assert.deepEqual(result.output.at(-1).replayState, { opaque: true });
  }
});

test('未知语法仅记录脱敏类别，跨分片与仅权威块均可观察，不删除正文', async () => {
  const text = '<ds_safety>secret</ds_safety><ds_tool>x</ds_tool><gongfeng>x</gongfeng>'
    + '<gazelle>x</gazelle><gitsource>x</gitsource><route>x</route><ai-content>x</ai-content>'
    + '<framework>x</framework><answer>答案</answer><工具调用>x</工具调用>｜工具｜｜tool_call_begin｜'
    + '<tool_name>bash</tool_name>';
  for (const input of [textChunks(text), textChunks(text).filter((c) => c.type !== 'text-delta')]) {
    const events = [];
    const result = await run(input, {}, { report: (event) => events.push(event) });
    assert.equal(result.blocks[0].text, text);
    assert.equal(result.calls.length, 0);
    assert.deepEqual(events.map((e) => e.category).sort(),
      ['answer', 'ds-safety', 'ds-tool', 'localized-tool', 'orchestration', 'platform', 'xml-tool']);
    assert.ok(!JSON.stringify(events).includes('secret'));
  }
});

test('同名正常词、代码示例与讨论上下文不产生未知类别告警', async () => {
  for (const text of ['answer route framework gongfeng', '`<ds_safety>example</ds_safety>`',
    '```xml\n<ds_safety>example</ds_safety>\n```', '讨论以下标签：\n<ds_safety>x</ds_safety>']) {
    const events = [];
    await run(textChunks(text), {}, { report: (e) => events.push(e) });
    assert.deepEqual(events, []);
  }
});

test('原生工具存在时清理标签不改变工具结束原因，取消与错误不触发空回复重试', async () => {
  const native = { type: 'block-end', index: 3, block: { type: 'tool-call', id: 'native',
    name: 'bash', arguments: '{"command":"echo test"}' } };
  const input = textChunks(suffixes[0]); input.unshift(native); input.at(-1).reason.kind = 'tool-calls';
  const result = await run(input);
  assert.equal(result.finish.kind, 'tool-calls');
  assert.equal(result.calls.length, 1);
  for (const kind of ['aborted', 'error', 'max-tokens']) {
    const input = textChunks(suffixes[0]); input.at(-1).reason.kind = kind;
    assert.equal((await run(input)).finish.kind, kind);
  }
});

test('没有 finish 的流保留尚未确定的闭合尾部；有界缓冲溢出明确失败', async () => {
  const input = textChunks(suffixes[1]).filter((c) => !['finish', 'block-end'].includes(c.type));
  assert.equal(deltas(await run(input)), suffixes[1]);
  const large = textChunks(suffixes[0] + ' '.repeat(200));
  const result = await run(large, {}, { maxBufferChars: 128 });
  assert.equal(result.finish.kind, 'error');
  assert.equal(result.calls.length, 0);
});

test('恢复完整工具调用时，前面的普通 XML 闭合残留不会因提前结束而丢失', async () => {
  const text = `</invoke>\n${root()}`;
  const result = await run(chunks(text, [...text]));
  assert.equal(result.finish.kind, 'tool-calls');
  assert.equal(result.blocks[0].text, '</invoke>\n');
  assert.equal(result.calls.length, 1);
});

test('讨论保护局限于当前文本块，不影响其他块的检测和工具执行', async () => {
  const first = textChunks('以下是正在讨论的标记：\n<ds_tool>x</ds_tool>').slice(0, -2);
  const second = textChunks('<ds_safety>x</ds_safety>').map((c) => Number.isInteger(c.index) ? { ...c, index: 1 } : c);
  const events = [];
  await run([...first, ...second], {}, { report: (e) => events.push(e) });
  assert.deepEqual(events.map((e) => e.category), ['ds-safety']);
  const text = `我会修正标签解析，然后读取文件。\n${root()}`;
  assert.equal((await run(chunks(text, [...text]))).finish.kind, 'tool-calls');
});

test('同一行的标签讨论和引用的惰性续行保留，调用参数中的词不会误触发', async () => {
  for (const text of [`讨论这些标记：${suffixes[0]}`, `> 引用日志\n${root()}`]) {
    const result = await run(textChunks(text));
    assert.equal(result.blocks[0].text, text);
    assert.equal(result.calls.length, 0);
  }
  const text = root(invoke('bash', '<parameter name="command" string="true">echo 示例</parameter>'));
  const result = await run(chunks(text, [...text]));
  assert.equal(result.calls.length, 1);
  assert.equal(JSON.parse(result.calls[0].arguments).command, 'echo 示例');
});
