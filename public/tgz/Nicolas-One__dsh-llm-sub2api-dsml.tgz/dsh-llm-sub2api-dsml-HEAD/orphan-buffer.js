/** 清理有 DSML 证据的孤立闭合尾部和块首无名标记；普通 XML 原样保留。@author wwj */
import { MarkdownContext } from './markdown-context.js';

const MARKER = '(?:｜DSML｜|｜｜DSML｜｜)';
const CLOSER = new RegExp(`^</(${MARKER}\\s*)?(parameter|invoke|calls|tool_calls|function_calls)\\s*>$`);
const ROOT = new RegExp(`<${MARKER}\\s*(?:calls|tool_calls|function_calls)\\s*>$`);
const EMPTY_MARKER = new RegExp(`^<${MARKER}\\s*>$`);
const PREFIXES = ['</｜DSML｜', '</｜｜DSML｜｜', '<｜DSML｜', '<｜｜DSML｜｜',
  '</parameter', '</invoke', '</calls', '</tool_calls', '</function_calls'];

export class OrphanDsmlSuffixBuffer {
  pending = '';
  candidate = '';
  evidence = false;
  removed = false;
  onlyWhitespace = true;
  hasRoot = false;
  rootTail = '';
  context = new MarkdownContext();

  constructor(limit = 1048576) { this.limit = limit; }

  push(text) {
    let visible = '';
    const emit = (value) => { visible += value; if (/\S/.test(value)) this.onlyWhitespace = false; };
    const flush = () => {
      emit(this.candidate);
      this.candidate = '';
      this.evidence = false;
    };
    for (const char of text) {
      this.rootTail = (this.rootTail + char).slice(-128);
      if (ROOT.test(this.rootTail)) this.hasRoot = true;
      const protectedText = this.context.protected || this.hasRoot;
      this.context.push(char);
      if (this.pending) {
        this.pending += char;
        if (char === '>') {
          const close = CLOSER.exec(this.pending);
          if (close) {
            this.candidate += this.pending;
            this.evidence ||= Boolean(close[1]);
          } else if (this.onlyWhitespace && !this.candidate && EMPTY_MARKER.test(this.pending)) {
            this.removed = true;
          } else { flush(); emit(this.pending); }
          this.pending = '';
        } else if (this.pending.length > 128 || !PREFIXES.some((prefix) =>
          prefix.startsWith(this.pending) || this.pending.startsWith(prefix))) {
          flush(); emit(this.pending); this.pending = '';
        }
      } else if (char === '<' && !protectedText) this.pending = char;
      else if (this.candidate && /\s/.test(char) && !protectedText) this.candidate += char;
      else { flush(); emit(char); }
      if (this.pending.length + this.candidate.length > this.limit) throw new Error('DSML 尾部缓冲超过限制');
    }
    return visible;
  }

  end({ clean = true } = {}) {
    let tail = this.candidate + this.pending;
    if (clean && this.evidence && !this.pending && !this.hasRoot) {
      this.removed = true;
      tail = '';
    }
    this.candidate = this.pending = '';
    this.evidence = false;
    return tail;
  }
}
