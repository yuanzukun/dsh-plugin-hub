/** 按字符保留候选标签，避免标签跨 SSE 分片泄漏；代码围栏原样保留。@author wwj */
import { MarkdownContext } from './markdown-context.js';
export { OrphanDsmlSuffixBuffer } from './orphan-buffer.js';

const MARKERS = ['｜DSML｜', '｜｜DSML｜｜'];
const PREFIXES = MARKERS.map((marker) => `<${marker}`);
const NAMES = ['calls', 'tool_calls', 'function_calls'];
const OPEN = new RegExp(`^<(${MARKERS.join('|')})\\s*(calls|tool_calls|function_calls)\\s*>$`);

function isPrefix(value, candidates) {
  return candidates.some((candidate) => candidate.startsWith(value));
}

function possibleOpening(value) {
  const prefix = PREFIXES.find((candidate) => value.startsWith(candidate));
  if (!prefix) return isPrefix(value, PREFIXES);
  const tail = value.slice(prefix.length).trimStart();
  return NAMES.some((name) => name.startsWith(tail)
    || (tail.startsWith(name) && /^\s*>?$/.test(tail.slice(name.length))));
}

export class DsmlTextBuffer {
  mode = 'normal';
  pending = '';
  captured = '';
  completed = false;
  captureTail = '';
  rootName = '';
  closePattern;
  context = new MarkdownContext();

  constructor(limit) { this.limit = limit; }

  track(char) { this.context.push(char); }

  push(text) {
    let visible = '';
    for (const char of text) {
      if (this.completed) break;
      if (this.mode === 'capture') {
        this.captured += char;
        if (this.captured.length > this.limit) throw new Error('DSML 缓冲超过限制');
        this.captureTail = (this.captureTail + char).slice(-128);
        if (this.closePattern.test(this.captureTail)) this.completed = true;
        continue;
      }
      if (this.mode === 'probe' || (char === '<' && this.context.lineStart && !this.context.protected)) {
        this.mode = 'probe';
        this.pending += char;
        const opening = OPEN.exec(this.pending);
        if (opening) {
          this.mode = 'capture';
          this.captured = this.pending;
          this.rootName = opening[2];
          this.closePattern = new RegExp(`</${opening[1]}\\s*${this.rootName}\\s*>$`);
          this.pending = '';
        } else if (this.pending.length > 128 || !possibleOpening(this.pending)) {
          const literal = this.pending;
          this.pending = '';
          this.mode = 'normal';
          visible += literal;
          for (const value of literal) this.track(value);
        }
        continue;
      }
      visible += char;
      this.track(char);
    }
    return visible;
  }

  end() {
    if (PREFIXES.some((prefix) => this.pending.startsWith(prefix))) {
      this.captured = this.pending;
      this.pending = '';
      return '';
    }
    const remainder = this.pending;
    this.pending = '';
    return remainder;
  }
}
