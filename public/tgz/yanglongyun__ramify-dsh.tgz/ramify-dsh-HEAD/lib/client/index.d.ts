import type { Context } from '@deepseek-ai/cordis';
export declare const inject: string[];
/** Mount the native DSH sidebar action and frame-wide Ramify workspace. */
export declare function apply(ctx: Context): void;
export { RamifySidebarAction, RamifyWorkspaceOverlay } from './RamifySurface.js';
export { RamifyProjectToolCard } from './RamifyToolCard.js';
export { ramifyWorkspaceOpen, setRamifyWorkspaceOpen, subscribeRamifyWorkspace, } from './store.js';
