# pi_agent_session_tree

English | [中文](README.zh.md)

Append-only multi-branch conversation trees for DeepSeek-Harness: the agent's
sole conversation history is a tree keyed by agent session, forkable at any
historical node, with standard LLM message reconstruction, JSON snapshots, and
an embedded WebUI tree panel.

## Surface

| Surface | Name | Notes |
|---|---|---|
| Tool | `session_tree` | one tree per agent session; operations below |
| Command | `/tree` | `list`, `branches`, `tree`, `context`, `jump <nodeId>`, `branch <nodeId> <name>`, `snapshot save`, `snapshot load <json>` |
| Commands | `/fork`, `/clone`, `/session` | fork a selected user message to a same-project session, clone the whole current session, inspect tree status |
| Remote service | `sessionTree` | `list(agent)`, `jump(agent, nodeId)`, `fork(agent, nodeId, branch)`, `session(agent)` — drives the browser panel |
| Browser slot | `conversation.details.panel` / `shell.overlay` | native details seat in a patched checkout, additive drawer in an official Bundle; click a node to jump |

## Tool operations

`create`, `append`, `list`, `branches`, `tree`, `jump`, `fork`, `clone`,
`context`, `session`, `branch`, `branch.summary`, `snapshot.save`,
`snapshot.load`, `sessions`.

- `context` returns `{cursor, messages}` where `messages` is the standard LLM
  messages array for the root→cursor path.
- `branch` parks the cursor at an existing node and names the next append's
  branch; `branch.summary` additionally appends a summary node. Historical
  nodes are never modified or deleted.
- `snapshot.save` returns the versioned tree snapshot; `snapshot.load` restores
  it under the same sessionId (see `SNAPSHOT_VERSION` versioning:
  `version: 1`).

Every operation answers `{ok: true, value}` or `{ok: false, error: {code, message}}`
with codes `INVALID_ARGUMENT` | `SESSION_NOT_FOUND` | `SESSION_ALREADY_EXISTS` |
`NODE_NOT_FOUND` | `INVALID_SNAPSHOT` | `NOT_FOUND`,
so tool and Remote results are always lossless JSON.

## Tool examples

```json
{"operation":"create","sessionId":"demo"}
{"operation":"append","sessionId":"demo","message":{"role":"user","content":"Explore option A"}}
{"operation":"append","sessionId":"demo","message":{"role":"assistant","content":"Baseline answer"}}
{"operation":"branch","sessionId":"demo","nodeId":"<root-nodeId>","branch":"option-b"}
{"operation":"append","sessionId":"demo","message":{"role":"user","content":"Explore option B"},"branch":"option-b"}
{"operation":"context","sessionId":"demo"}
{"operation":"snapshot.save","sessionId":"demo"}
{"operation":"snapshot.load","sessionId":"demo","snapshot":{"version":1,"sessionId":"demo","cursor":null,"activeBranch":"main","nodes":[]}}
```

## Composition

Add the host row to the active Cordis composition (the standalone Bundle's
`cordis.patch.yml` already carries it):

```yaml
- id: pi-agent-session-tree
  name: '@robiteame/dsh-pi-agent-session-tree'
```

The browser panel ships as `@robiteame/dsh-client-ui-session-tree`. A patched
checkout mounts it as `conversation.details.panel`; an official Bundle mounts
it as the additive `shell.overlay`. See `SYSTEM_PROMPT.md` for the
system-prompt fragment this plugin installs.

## Implementation notes

- The store is process-wide and shared by the tool, the command, and the
  Remote service, so model appends appear in the panel immediately.
- Harness `Session` events are the durable source of truth; the tree is an
  incrementally synchronized projection. Explicit `snapshot.save`/`snapshot.load`
  events remain available for export and full-tree restore.
- A patched checkout persists tree markers as `session-tree/*` events. On
  official builds, tree navigation leaves the Session log intact and saves
  branch and cursor state in `$DSH_HOME/storages/session-tree/<sessionId>.json`.
  Use `/fork` to continue from an earlier user prompt in a separate session.
- Model-visible ⇔ logged: native Harness message events always synchronize
  into tree nodes; the tree does not synthesize history that was never logged.

## Model Experience

### Model-facing surface

#### What the model sees

The domain service registers no prompt, schema, or result of its own: the model-facing surface is entirely owned by `@robiteame/dsh-tool-session-tree` (tool, `/tree` command, system-prompt section). The Remote methods this package exposes serve the browser panel only and never enter model context.

#### Token effect

None — this package contributes no model-visible text.

#### KV Cache effect

None — nothing from this package joins the model request prefix.
