/* MinerU conversion gallery (QA only): the settings section, the import route panel, the job card and the history, with fixed props (no backend),
   built and screenshotted by scripts/qa/mineru-shots.mjs. Every state of the one-click install card has its own gallery: scripts/qa/mineru-install-gallery.jsx.
   Query: ?lang=zh|en&theme=dark|light&scene=settings|route|jobs|history|case
   scene=case&case=<key>: ONE settings section in one state (the layout matrix, measured by scripts/qa/mineru-layout.mjs). The cloud route was removed in
   3.6: only old history rows still show it. */
import React from 'react';
import { createRoot } from 'react-dom/client';
import styleCss from '../../ui/styles.js';
import { setUiLanguage } from '../../ui/i18n.js';
import MineruSettings from '../../ui/MineruSettings.jsx';
import MineruRoute from '../../ui/MineruRoute.jsx';
import { PdfConvertHistory, PdfConvertJobs } from '../../ui/PdfConvertJob.jsx';
import LargeDocumentCard from '../../ui/LargeDocumentCard.jsx';

const params = new URLSearchParams(location.search);
const lang = params.get('lang') === 'en' ? 'en' : 'zh';
const theme = params.get('theme') === 'light' ? 'light' : 'dark';
const scene = params.get('scene') || 'settings';
setUiLanguage(lang);

const style = document.createElement('style');
style.textContent = `${styleCss}
  html, body, #root { height: 100%; margin: 0; }
  .gallery { max-width: 1040px; margin: 0 auto; padding: 24px 28px 96px; }
  .g-section { padding: 24px 0; border-top: 1px solid var(--line-soft); }
  .g-section > h2 { margin: 0 0 14px; font-size: 13px; letter-spacing: .12em; text-transform: uppercase; color: var(--text-muted); font-weight: 600; }
  @container study (max-width: 640px) { .gallery { padding: 16px 12px 72px; } }`;
document.head.appendChild(style);

const call = async () => ({});
const est = { basic: 1.6, standard: 2.5 };
const installed = { status: 'complete', stage: 'done', stages: ['tools', 'python', 'package', 'models', 'enable', 'check'], done: ['tools', 'python', 'package', 'models', 'enable', 'check'], step: 6, of: 6,
  folder: 'D:\\StudyHub\\MinerU', installedFolder: 'D:\\StudyHub\\MinerU', installed: true, tier: 'basic', mineruVersion: '4.0.12', log: [], error: null };
const local = {
  missing: { state: 'not-installed', next: 'install', origin: null, estimates: est },
  needs: { state: 'needs-models', next: 'download-models', origin: 'search', tier: 'flash', modelsMbByTier: { basic: 800, standard: 2000 }, estimates: est },
  stopped: { state: 'server-stopped', next: 'start-server', origin: 'installed', folder: installed.folder, install: installed, tier: 'basic', version: '4.0.12', estimates: est },
  ready: { state: 'ready', next: null, origin: 'installed', folder: installed.folder, install: installed, tier: 'basic', version: '4.0.12', estimates: est, windowPages: 50 },
  external: { state: 'ready', next: null, origin: 'search', exe: 'C:\\Users\\student\\.local\\bin\\mineru.exe', tier: 'standard', version: '4.0.10', estimates: est, windowPages: 50 },
  unknown: { state: 'unknown', next: 'recheck', origin: 'search', version: '4.0.10', running: true, estimates: est },
};
const plan = {
  name: 'Operating Systems.pdf', pages: 422, bytes: 96 * 1024 * 1024, byChapters: true, maySplitFurther: false,
  pieces: [[1, 118], [119, 281], [282, 422]].map(([startPage, endPage], i) => ({ index: i + 1, startPage, endPage, pages: endPage - startPage + 1 })),
  windows: Array.from({ length: 9 }, (_, i) => ({ index: i + 1, startPage: i * 50 + 1, endPage: Math.min(422, i * 50 + 50), pages: Math.min(50, 422 - i * 50) })),
};
const file = { name: 'Operating Systems.pdf', size: 96 * 1024 * 1024 };
const job = (extra = {}) => ({ id: `j${Math.random()}`, type: 'pdf-convert', route: 'local', filename: 'Operating Systems.pdf', status: 'running', phase: 'local', done: 211, total: 422,
  chunk: { index: 2, count: 3 }, chunks: [{ index: 1, startPage: 1, endPage: 118, pages: 118, state: 'done' }, { index: 2, startPage: 119, endPage: 281, pages: 163, state: 'parsing' }, { index: 3, startPage: 282, endPage: 422, pages: 141, state: 'planned' }],
  stage: '第 2/3 段 · 正在本地解析', warnings: [], note: '', startedAt: new Date(Date.now() - 185_000).toISOString(), ...extra });
const STOPPED = '本机 MinerU 服务没有在运行，或解析到一半停了。点「接着做」会先启动服务，再从停下的那一段接着解析（已完成的段落会保留）。';

/* The 解析历史: every state of a row (complete, local, failed, interrupted, cancelled, running, document deleted, a very long name), many days, the
   confirm to clear, the empty state, and the panel the "用 MinerU 解析" link opens. Fixed records, a fixed clock. */
const HOUR = 3_600_000, NOW = Date.now(), MB = 1024 * 1024;
/* What does the work (运行环境): captured when a conversion starts. */
const LOCAL_ENV = { kind: 'local', mineruVersion: '4.0.10', tier: 'standard', model: 'MinerU2.5-Pro-2605-1.2B-GGUF', modelsPath: 'C:\\Users\\student\\.mineru\\models', modelsRealPath: 'E:\\mineru-models\\models', windows: { kind: 'fixed', pages: 50 } };
const CLOUD_ENV = { kind: 'cloud', modelVersion: 'vlm', language: 'ch', maxPages: 200, maxBytes: 180 * MB, bookBytes: 96 * MB };
const windows = count => Array.from({ length: count }, (_, i) => ({ index: i + 1, startPage: i * 50 + 1, endPage: Math.min(562, i * 50 + 50), pages: 50, state: i < 2 ? 'done' : 'planned' }));
const up = { state: 'running', basis: 'window', at: new Date(Date.now() - 25_000).toISOString() };
let recordNumber = 0;
const ago = hours => new Date(NOW - hours * HOUR).toISOString();
const row = (extra = {}) => { const started = extra.hours ?? 0.2; const { hours, ...rest } = extra; return { id: `job-${String(++recordNumber).padStart(4, '0')}`, version: 1, filename: 'Operating Systems.pdf', bytes: 96 * MB, pages: 422, pieces: 3,
  route: 'cloud', status: 'complete', phase: 'done', pagesDone: 422, attempts: 1, elapsedMs: 260_000, startedAt: ago(started + 0.08), finishedAt: ago(started), importedPages: 420, skippedPages: 2,
  documentId: 'document-a-json', title: 'Operating Systems', canRetry: false, live: false, document: { exists: true, title: 'Operating Systems', pages: 420, sourceIds: ['s1'] },
  env: rest.route === 'local' ? { ...LOCAL_ENV, tier: rest.tier || 'basic', model: rest.tier === 'standard' ? LOCAL_ENV.model : 'MinerU-4_models_onnx', modelsPath: undefined, modelsRealPath: undefined } : CLOUD_ENV, ...rest }; };
const gone = { documentId: undefined, importedPages: undefined, skippedPages: undefined, document: undefined };
const historyRows = () => [
  row({ hours: 0.05, status: 'running', phase: 'parse', finishedAt: undefined, elapsedMs: 0, pagesDone: 211, live: true, ...gone, filename: 'Databases Lecture Notes.pdf', pages: 330, bytes: 18 * MB }),
  row({ hours: 0.3 }),
  row({ hours: 0.9, route: 'local', tier: 'basic', filename: 'Algorithms.pdf', pages: 120, pieces: 3, bytes: 7 * MB, elapsedMs: 310_000, importedPages: 120, skippedPages: 0, document: { exists: true, title: 'Algorithms', pages: 120, sourceIds: ['s2'] } }),
  row({ hours: 2.5, status: 'failed', phase: 'parse', pagesDone: 200, elapsedMs: 600_000, ...gone, canRetry: true, failure: { stage: 'parse', piece: 2, reason: 'MinerU 没能转换这一段文件（可能是文件受保护或内容异常）。' } }),
  row({ hours: 3, status: 'failed', phase: 'upload', pagesDone: 0, elapsedMs: 4000, ...gone, canRetry: false, failure: { stage: 'upload', reason: '连不上 MinerU：请检查网络后重试（已完成的部分会保留）。' }, filename: 'Networks.pdf', pages: 88 }),
  row({ hours: 4, status: 'failed', route: 'local', tier: 'basic', phase: 'local', pagesDone: 50, elapsedMs: 130_000, ...gone, canRetry: true, filename: 'Compilers.pdf', pages: 120, failure: { stage: 'local', piece: 2, code: 'server-stopped', reason: STOPPED } }),
  row({ hours: 5, status: 'failed', phase: 'parse', pagesDone: 0, elapsedMs: 3000, ...gone, canRetry: false, failure: { stage: 'parse', code: 'invalid-token', reason: 'MinerU 令牌无效：请到「设置 › MinerU 云端解析」重新粘贴一个有效的令牌。' }, filename: 'Security.pdf' }),
  row({ hours: 7, status: 'interrupted', phase: 'parse', finishedAt: undefined, elapsedMs: 0, pagesDone: 200, ...gone, canRetry: true, filename: 'Distributed Systems.pdf' }),
  row({ hours: 8, status: 'interrupted', phase: 'parse', finishedAt: undefined, elapsedMs: 0, pagesDone: 0, ...gone, canRetry: false, filename: 'Old Notes.pdf', pages: 40 }),
  row({ hours: 10, status: 'cancelled', phase: 'parse', pagesDone: 118, elapsedMs: 90_000, ...gone, filename: 'Machine Learning.pdf' }),
  row({ hours: 26, document: { exists: false, title: 'Gone', pages: 0, sourceIds: [] }, filename: 'A very long file name that keeps going and going so that the row has to wrap somewhere sensible 2026 final FINAL (copy 3).pdf', elapsedMs: 4_000_000 }),
  ...Array.from({ length: 12 }, (_, index) => row({ hours: 30 + index * 20, filename: `Chapter pack ${index + 1}.pdf`, route: index % 3 ? 'cloud' : 'local', tier: index % 3 ? undefined : 'standard', elapsedMs: 60_000 + index * 37_000 })),
];
const noFetch = async () => ({ records: [] });

function Section({ title, children }) { return <section className="g-section"><h2>{title}</h2>{children}</section>; }
const noop = () => {};

/* The layout matrix: the local status of each case. */
const CASES = { missing: local.missing, needs: local.needs, stopped: local.stopped, ready: local.ready, external: local.external, unknown: local.unknown };

function Scene() {
  if (scene === 'case') return <main><div className="page gallery"><MineruSettings call={call} initialLocal={CASES[params.get('case')] || CASES.missing} /></div></main>;
  if (scene === 'history') return <main><div className="page gallery">
    <Section title="Many rows, every state (10 shown, the rest behind 显示更多)"><PdfConvertHistory call={noFetch} initialRecords={historyRows()} now={NOW} onOpenSources={noop} onOpenSettings={noop} /></Section>
    <Section title="All shown"><PdfConvertHistory call={noFetch} initialRecords={historyRows()} initialShown={40} now={NOW} onOpenSources={noop} /></Section>
    <Section title="Asking before clearing"><PdfConvertHistory call={noFetch} initialRecords={historyRows().slice(1, 5)} initialConfirmClear now={NOW} onOpenSources={noop} /></Section>
    <Section title="Empty"><PdfConvertHistory call={noFetch} initialRecords={[]} now={NOW} /></Section>
    <Section title="Inside the MinerU panel (opened from 用 MinerU 解析), MinerU not installed"><MineruRoute call={call} onFile={noop} initialLocal={local.missing} initialHistory={historyRows().slice(0, 4)} historyNow={NOW} historyOpen onOpenSources={noop} /></Section>
    <Section title="Inside the MinerU panel, a PDF chosen, local ready"><MineruRoute file={file} call={call} initialLocal={local.ready} initialPlan={plan} initialHistory={historyRows().slice(1, 3)} historyNow={NOW} historyOpen onOpenSources={noop} /></Section>
  </div></main>;
  if (scene === 'settings') return <main><div className="page gallery">
    <Section title="Not installed"><MineruSettings call={call} initialLocal={local.missing} /></Section>
    <Section title="Ready (StudyHub's install)"><MineruSettings call={call} initialLocal={local.ready} /></Section>
    <Section title="Installed · service stopped"><MineruSettings call={call} initialLocal={local.stopped} /></Section>
    <Section title="Ready (the learner's own mineru)"><MineruSettings call={call} initialLocal={local.external} /></Section>
  </div></main>;
  if (scene === 'route') return <main><div className="page gallery">
    <Section title="MinerU not installed (the one-click card inline)"><MineruRoute file={file} call={call} initialLocal={local.missing} initialPlan={plan} onOpenSettings={noop} /></Section>
    <Section title="Local ready (default)"><MineruRoute file={file} call={call} initialLocal={local.ready} initialPlan={plan} /></Section>
    <Section title="Installed, service stopped (the conversion starts it)"><MineruRoute file={file} call={call} initialLocal={local.stopped} initialPlan={plan} /></Section>
    <Section title="No file yet"><MineruRoute call={call} onFile={noop} initialLocal={local.ready} /></Section>
    <Section title="Inside the large-textbook card"><LargeDocumentCard reason="pdf-pages" detail={{ name: 'Operating Systems.pdf', file }} retrieval={null} call={call} courseNames={[]} /></Section>
  </div></main>;
  return <main><div className="page gallery">
    <Section title="Local: running piece 2 of 3"><PdfConvertJobs call={call} jobs={[job()]} /></Section>
    <Section title="Starting the stopped service before the first window"><PdfConvertJobs call={call} jobs={[job({ phase: 'start-service', stage: '正在启动本机 MinerU 服务（第一次约 1 分钟）', done: 0, service: { state: 'starting', basis: 'start', at: new Date().toISOString() } })]} /></Section>
    <Section title="Local: window 3 of 9 (no fake percentage inside a window)"><PdfConvertJobs call={call} jobs={[job({ route: 'local', phase: 'local', done: 100, total: 422, chunk: { index: 3, count: 9 }, stage: '第 3/9 段 · 正在本地解析',
      chunks: Array.from({ length: 9 }, (_, i) => ({ index: i + 1, startPage: i * 50 + 1, endPage: Math.min(422, i * 50 + 50), pages: 50, state: i < 2 ? 'done' : 'planned' })) })]} /></Section>
    <Section title="Failed: local service stopped (接着做 starts it)"><PdfConvertJobs call={call} jobs={[job({ status: 'failed', retryable: true, errorCode: 'server-stopped', stage: STOPPED, finishedAt: new Date().toISOString() })]} /></Section>
    <Section title="An old cloud job (the route was removed): nothing to continue"><PdfConvertJobs call={call} jobs={[job({ route: 'cloud', phase: 'parse', status: 'failed', retryable: false, errorCode: 'cloud-removed', stage: '云端解析已停用；请重新选择这份 PDF 用本机解析。', finishedAt: new Date().toISOString() })]} /></Section>
    <Section title="运行环境 · local standard, 12 windows folded, service up (confirmed by a finished window)"><PdfConvertJobs call={call} jobs={[job({ tier: 'standard', env: LOCAL_ENV, service: up, total: 562, done: 100, chunk: { index: 3, count: 12 }, chunks: windows(12), stage: '第 3/12 段 · 正在本地解析', phase: 'local', route: 'local' })]} /></Section>
    <Section title="Same, all windows shown (wrap inside the card)"><PdfConvertJobs call={call} expandChunks jobs={[job({ tier: 'standard', env: LOCAL_ENV, service: up, total: 562, done: 100, chunk: { index: 3, count: 12 }, chunks: windows(12), stage: '第 3/12 段 · 正在本地解析', phase: 'local', route: 'local' })]} /></Section>
    <Section title="Local basic with a device the CLI reported · 6 windows listed"><PdfConvertJobs call={call} jobs={[job({ tier: 'basic', env: { ...LOCAL_ENV, tier: 'basic', model: 'MinerU-4_models_onnx', device: 'cuda', modelsRealPath: undefined }, service: up, total: 300, done: 100, chunk: { index: 3, count: 6 }, chunks: windows(6), stage: '第 3/6 段 · 正在本地解析', phase: 'local', route: 'local' })]} /></Section>
    <Section title="Service state not known (after a restart)"><PdfConvertJobs call={call} jobs={[job({ tier: 'standard', env: LOCAL_ENV, service: { state: 'unknown', basis: 'none', at: new Date().toISOString() }, route: 'local', chunks: windows(4), chunk: { index: 2, count: 4 }, phase: 'local', stage: '第 2/4 段 · 正在本地解析' })]} /></Section>
    <Section title="Failed: the service stopped (warning + the existing restart action)"><PdfConvertJobs call={call} jobs={[job({ route: 'local', tier: 'standard', env: LOCAL_ENV, status: 'failed', retryable: true, errorCode: 'server-stopped', service: { state: 'stopped', basis: 'window', at: new Date().toISOString() }, phase: 'local', chunks: windows(12), chunk: { index: 3, count: 12 }, total: 562, done: 100,
      stage: STOPPED, finishedAt: new Date().toISOString() })]} /></Section>
    <Section title="An old cloud job's environment"><PdfConvertJobs call={call} jobs={[job({ env: CLOUD_ENV, service: undefined, route: 'cloud', phase: 'parse', tier: undefined, status: 'failed', retryable: false, errorCode: 'cloud-removed', stage: '云端解析已停用；请重新选择这份 PDF 用本机解析。' })]} /></Section>

    <Section title="Cancelled · complete"><PdfConvertJobs call={call} onOpenSources={noop} jobs={[job({ status: 'cancelled', stage: '已取消；已解析好的段落会保留，再导入同一个文件不会重复解析', finishedAt: new Date().toISOString() }),
      job({ status: 'complete', phase: 'done', done: 422, sourceIds: Array.from({ length: 422 }, (_, i) => `s${i}`), finishedAt: new Date().toISOString(), warnings: ['Pages 12, 45 have no text in the converted output (pictures or blank pages) and were skipped.'] })]} /></Section>
  </div></main>;
}

createRoot(document.getElementById('root')).render(<div className="study-app" data-theme={theme} lang={lang === 'en' ? 'en' : 'zh-CN'}><Scene /></div>);
