# Content Quality Protocol

## Node

A node must state a recallable core conclusion, relevant prerequisites, a
subject-appropriate example or derivation, common mistakes, and related next
material. Do not create a shallow node only to satisfy a quiz link.

When a node makes claims that depend on provided evidence, especially for
history, law, literature, or social science, `sources` must identify the
relevant source or passage and the body must distinguish evidence from
interpretation.

## Quiz

Prepare new source-based questions in separate stages. First extract valuable
knowledge points and their verbatim supporting passages, without designing
questions or scenarios. Use only selected material; retain fewer points when
there is insufficient evidence instead of inventing targets to fill a quota.
Next derive a concrete answer and checkable reasoning from each verified point,
then any necessary scenario conditions and options or scoring criteria. Finally
write and self-check the question using that bound knowledge point and answer
plan; do not replace its quotations or answer with newly invented content.
A source saying two concepts are different does not justify inventing a precise
distinction absent from it. Constructed scenarios may add explicit hypothetical
assumptions, but cannot introduce unsupported subject-matter facts.

After drafting, check and improve every card before independent review:

- Self-contained: the learner cannot see the original slide or diagram during
  ordinary review. Supply necessary conditions in the stem. Do not ask about an
  unseen bracket, arrow position, "this slide", or "the classroom original".
  The same rule applies to lecture notes and audio transcripts. Never ask what
  "this note", "these materials" or "the teacher's list" says without providing
  the actual task context. Name the concept, scope and necessary scenario facts;
  citations and document titles do not make an empty stem self-contained.
  Test knowledge or application, not recollection of the wording of a hidden
  document. If adding context would reveal the answer, replace the target.
- No answer leakage: a learner must demonstrate knowledge, not paraphrase the
  stem. The prompt, topic and hint must not supply the requested conclusion or
  list its answer terms. A hint suggests a method, not the answer's location.
- Comparable choices: use a shared judgment axis and abstraction level, with
  equally plausible near-misses. Avoid options about unrelated properties or a
  correct answer identifiable only by length, terminology or quotation style.
- Useful target: test a meaningful distinction or application. Keep foundational
  flashcards short and focused; do not turn every card into a long multi-part
  scenario. Slide-layout trivia is not evidence of understanding.
- Honest evidence: label constructed scenarios in the explanation and supply
  all facts needed for them. Do not turn an invented teaching interpretation
  into a sourced claim merely by adding a disclaimer. Narrow or skip questions
  whose decisive distinction is not supported.
- Teachable explanation: connect the actual stem conditions to a rule and its
  result. Explain unfamiliar terms, show decisive intermediate steps, and clarify
  the most tempting misconception and a reusable boundary. Check intermediate
  results for correctness; repeating the answer or labelling options true/false
  is not teaching. Keep simple recall concise instead of adding generic padding.

Record brief concrete changes and require independent per-card checks on all
six dimensions. An empty list of issues alone is not an adequate review.
Repairs require a fresh independent review of the repaired text; the repairer's
own pass markers cannot approve the result.

A quiz must have a clear answer, useful hint, direct explanation, common
misconception, and linked source material. A numerical or reasoning answer
must include enough intermediate steps to verify it. An open-ended quiz must
state a scoring rubric.

A teaching-derived supplemental quiz is allowed only when it tests a distinct,
independently gradable transfer target not already covered by a linked quiz. It
must link to the consolidated node and retain teaching provenance.

An evidence-based quiz must identify the supporting source or passage in its
prompt or explanation and explain how that evidence supports the answer.

## Mathematical notation

Put every formula that needs typesetting inside math delimiters: `$…$` inline,
`$$…$$` for a displayed equation. This covers variables with subscripts or
superscripts, Greek letters, fractions, sums, and chemical or physical
expressions. Never leave a formula as plain text such as `a^{l-1}` or
`\frac{a}{b}`; the learner would see the raw characters. Use the same delimiters
in the stem, every option, the hint and the explanation, so one formula looks the
same everywhere. Ordinary prose, code (in backticks) and currency ("$5") are not
formulas and need no delimiters.

Inside JSON, write each backslash twice: `"$\\frac{a}{b}$"`, `"$\\sigma(z^l)$"`. A
single backslash silently turns `\beta`, `\frac`, `\theta` or `\nabla` into control
characters. A card whose formula is outside the delimiters is rejected.

## Recruitment Extension

When recruitment mode is active, read `references/recruitment-prep.md` and
apply it in addition to the generic quality rules. A node must be an
interviewable leaf that covers HOW, WHY, and WHERE and ends in an observable
output. A quiz must test one uncovered depth target and include a scoring
rubric, follow-up ladder, interview signal, and precise debrief action.

For multiple-choice or multi-select questions, use plausible alternatives at
the same abstraction level and similar length. Avoid joke answers, grammar
cues, repeated answer-position patterns, and a fixed number of correct
options. Every distractor should expose a real misconception.

## Daily Bite

A Bite has one source and one recall target. It must be short enough for quick
review and must not duplicate an entire quiz.
