# 代理工作规则（统一任务运行时）

适用于任何参与这项重构的代理（Claude 或其他）。违反任意一条的 PR 不合并。

## 1. 所有权与契约优先

- `lib/jobs/**`、`docs/job-contract.md`、`docs/plans/unified-job-runtime/**` 只有**内核负责人**能合并。
- 功能迁移只能调用**已发布**的内核接口。需要新接口：先提交只改契约文档与测试的 PR，合并后再迁移调用方。
- 同一时间只有一个代理修改同一个核心文件。并行只用于互不相关的功能目录。
- 开工与交接更新 sprint 接手记录：负责人、分支、基线 SHA、文件范围、前置评审链接、验证证据、未确认项、下一步。完成以已合并 PR 和对应验证为准，不以聊天中的完成声明为准。

## 2. DSH 优先

- 写任何公共部件前，先在 sprint 文件的「DSH 能力对照表」里查：DSH 有对应接口就复用（cordis 上下文与作用域、`ctx.llm`、宿主子代理服务、`ctx.sessions`、`uiWorkspace`、`schemastery`、`dsh-timeout` 等）。
- 只有 DSH 没有的部分才在插件里实现，并且实现为薄适配；PR 描述必须引用能力表行 ID、证据路径/版本，写明“复用了什么 / 缺口如何验证 / 自写边界在哪里”。
- “待核验”不能当成“不支持”。缺少源码、类型或可用宿主时，记录缺少的证据与受阻步骤；不能先写替代实现。只实现当前试点用到的能力，后续资源与执行模式如实声明未支持。
- 不在插件里自建会话、模拟子代理或绕过宿主限制；宿主做不到的写进对照表的"宿主限制"。

## 3. 禁止的写法（迁移完成的路径上）

- 新建第二份任务表（`new Map()` 当 jobs 用）、第二套队列/并发闸门或另一个 429 退避层。演进现有实现或已核验的宿主适配按能力表评审；同一资源实例、任务事实来源与责任层保持唯一。
- 直接 `fetch` 服务商、直接调用 `complete` / `ctx.llm`，绕过模型网关。
- 直接修改公共任务状态、私自结算任务、写第二份用量记录。
- 叠加重试包装（同一请求只能有一个传输重试层）。
- 伪造数据：观测不到的时间、请求数、用量留空或标 `unknown` / `estimated`；不支持的能力不显示假按钮、不写空壳实现。
- 未登记的旁路：迁移期保留的旧入口必须在例外清单里有负责人和移除阶段。

## 4. 行为保持与开关

- 先接入、保持原行为，再单独打开改进（恢复、解除翻译串行、子代理优先、并发策略）。每个改进有独立开关、验收和回退说明。
- 迁移前先写特征测试固定现有行为；迁移后同一组测试必须仍然通过（开关开与关各跑一次）。

## 5. 测试

- 实现新契约、新能力或修复缺陷时，先写失败的测试并记录红灯输出，再实现。S1-0 的特征测试用于描述旧实现，应在不改生产代码的情况下通过；文档修改无需制造红灯。基线中发现的缺陷单独登记，不在特征测试中偷偷修复或扩大预期行为。
- 核心逻辑用可控执行器、模拟 provider、假时钟、故障注入；等待用 `tests/helpers/wait.mjs`（`until`、`settleJob`），不用固定延时。
- 平时用 `npm run test:fast`；全量 `npm test` / `npm run verify` 会经机器级锁排队，不要设 `STUDY_TEST_NO_LOCK`。新的浏览器/ffmpeg/外部程序测试登记到 `tests/slow-tests.json`。
- UI 改动：先有设计稿；验证布局跳动（`scripts/qa/journey.mjs` 的 CLS 检测、`scripts/qa/layout-late.mjs`）、界面缩放 100%/150%、宽度 1280/420。
- 发布前用真实模型抽检受影响路径，记录输入、模型、档位、质量、耗时、请求数、用量。

## 6. 安全与环境

- 运行测试或 DSH 前清空所有 `*_API_KEY`、`*_TOKEN`、`*BASE_URL` 环境变量，用工作区内的私有 TEMP/TMP 和 `DSH_HOME`；不向模型服务商发真实请求（真实抽检除外，且由所有者授权）。
- 不碰所有者的学习库（`D:\A\1NUS\1Sem\SWE5001\.dsh-study`）、`~/.dsh`、`~/.mineru` 与任何密钥；本地 DSH 测试用 0.2.0-rc.2，`SSH_TTY=audit`。
- 在独立 git worktree 中工作，在自己的 worktree 里 `npm ci --legacy-peer-deps`；不要 junction 共享 `node_modules`，不要 `git worktree remove --force`，不要动主检出目录里别人的未提交改动。
- 文件保持原有换行符（CRLF/LF 混用；`git ls-files --eol` 查看）；不要用 `sed -i` 改 CRLF 文件。

## 7. 提交与 PR

- 一个 issue / 一个 sprint 步骤一个提交，提交信息带编号。
- 分支命名 `codex/<主题>`；合并基线用 `git merge origin/main`，不 rebase、不 force-push。
- 代理不自行合并 PR（所有者合并），除非所有者在当次明确授权。
- PR 描述包含：做了什么、DSH 对照表引用、开关与默认值、测试与红灯记录、真实抽检（如适用）、回退说明、未完成事项。
- 合并前逐条核对 [review-checklist.md](review-checklist.md)，每项给出证据链接；不适用须说明本 PR 的范围，不得把尚未验证写成不适用。
- 文档 PR 不能勾选实施步骤或声明运行验证通过。真实模型抽检需要单独记录所有者授权和预算；未授权时保持发布门禁待验证，不能代填结果。

## 8. 迁移之后新增的规则（P6 起）

这些规则由守卫测试强制，违反的 PR 在 CI 里就红：

- **模型只在一处被做出**：`modelServices(` 只在 `lib/runtime/instant.js`（计量入口）、`lib/runtime/models.js`（定义）和 `lib/service.js` 的兼容 getter 里。一次一答的前台请求不建任务，也要经这个入口（共享 provider 配额的租约、用量只记一次）；新增的调用点先在 `s1-7-legacy-exceptions.json` 的 `hostModelAccess` 登记（`tests/instant-model-guard.test.mjs`）。
- **Job 模块的五条边界、内核向下的依赖**：见 [S6-3](s6-3-boundaries.md)（`unified-runtime-boundaries.test.mjs`、`architecture-boundaries.test.mjs`）。新增例外要精确（模块、规则、API、次数），带理由、负责人和移除时点。
- **结算通知走内核的 sink，不在执行器里自己通知**：定义同时声明 `notifications`（任务不持久化时）和端口上的 `notifications`（持久化时），两份必须同 channel、同幂等性；持久化一侧的 sink 从 `persistence.open` 的闭包拿通知器，不从 bindings 拿（[s2-architecture.md §4.1](s2-architecture.md)）。
- **落盘形状**：内核记录不得新增任何字段；每个写出的 manifest 必须被 `tests/fixtures/release-2.7.1/` 里 2.7.1 自己的校验器读入（`unified-runtime-rollback-shape.test.mjs`）。任何新的持久文件种类先登记并写进回退矩阵（`unified-runtime-rollback-read.test.mjs`：每个开关一行）。
- **文件锁**：库、看板、笔记本登记的写入都经 `lib/store-lock.js` 的进程内队列，文件锁只在进程间仲裁；不要在写入里再开一次同库写入（`STORE_REENTRANT`）。
- **新增一种普通任务**：只注册定义、执行器和可选详情，不改内核 kind/type 分支，见 [S6-4 的接入说明](s6-4-minimal-integration.md)。
- **测试的时间**：等待观察到的状态，不跟真实时钟赛跑；性能守卫度量工作量（增长比例）而不是耗时；演练（`tests/fixtures/runtime-s*/run-drill.mjs`）不在 CI 里，发布前手工重跑，旧版树由 `tests/fixtures/extract-release.mjs` 只用 git 取出。会运行 git 的测试登记到 `tests/slow-tests.json`。
- **没有被验证的东西不写成已验证**：真实模型、真实宿主、真实安装包的结果只有所有者授权后才记录（[S6-7 §8](s6-7-acceptance.md#8-待定门禁pending只有所有者授权后才能做)）；任何文档都不得把某个 commit 记为 alpha 或已发布。
