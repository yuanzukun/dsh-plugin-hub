# Course outline

[中文](course-outline.zh-CN.md)

The **Course outline** page lays out the current course by its materials instead of by its decks: each material, its chapters, and under each chapter the questions that cite it. Use it to find the questions about a part of the course and practise exactly those, without working out which deck holds them.

Step 1 lays the course out by the materials' own chapters, with no AI text. Step 2 adds **Generate outline**: the model organises the materials into a book-like outline (chapters, sections, knowledge points) in learning order. The review book's explanation layer writes notes under each knowledge point of the outline (see The review book below). Checked against the code on 2026-10-12.

## Open it

On the **Study library** home page, the course area (under the course name and its progress bar) has a **Course outline** link. It opens the outline of the current course. **Back to library** returns to the home page. The page has no sidebar entry.

The home page keeps one main card and its one continue button. The folded **Course route** list that used to sit under the progress bar is gone; the outline replaces it. The progress bar and **Continue course** still follow the deck order.

## The organised outline (step 2)

Without an outline, the page lists the materials as in step 1, with one main button, **Generate outline**, above them. One click starts the task **Organise the outline** in the background; there is no estimate and no confirmation, and the **Tasks** page shows its progress and what it used, as for every task. While it runs, the page says **Organising the outline (step i of n)…** with **View progress**; it can be paused, stopped (the inventory read so far is kept, no outline) or retried there (the finished model calls are kept).

Once the outline exists, the page reads like a book's contents:

| Row | What it is |
| --- | --- |
| **Chapter N** | A chapter of the course, with a short introduction. Chapters are open when the page first shows the outline. |
| N.M | A section of a chapter, with its introduction (a chapter without sections holds its knowledge points directly). Closed at first. |
| N.M.K | A knowledge point. It holds rows of the materials (a whole material, or some chapters of one); opening it lists those rows, each named with its material, and they open to their questions. A point that holds a single row opens straight to its questions. Materials of the same name under one point (four notes called **补充笔记 · Reintroduction**) are one row, **(4 with this name)**. |
| Other | Everything no knowledge point holds: what the model left out, and materials added after the outline was made. Never hidden. |
| Not placed | As in step 1. |

Every row has the mastery line (**Mastery 62% · 12 questions**), **Practise this**, and a tick box that picks every question under it at any depth. The counts are computed from the library as it is now, not stored in the outline: a question added, answered or deleted later counts at once.

Above the outline, one line says what the learning order rests on (**Learning order based on: the order of the syllabus “…” · the numbers in the material titles · the recording dates**). The model is told to follow, in this order, a syllabus material of the course (a short material whose name says 大纲 or syllabus), the numbers and version marks in titles (01., Lecture 3, Day1, v2.1), recording dates and parts, and what must be learned first; the line keeps only the grounds the library actually has. Next to it, a quiet **Reorganise** makes a new version; the old one is kept as an archived record. When the course's materials change after the outline was made (added, removed, renamed, re-imported), the line says **Your materials have changed since; reorganising is suggested**.

**Sample papers.** The materials whose name says they are a sample paper (样卷, 真题, sample paper, past paper, exam paper …, the rule of the 考点清单) are used by default: the line under the buttons says **Sample papers used: … (recognised by their names; you can change them)**, and **Change the sample papers** (folded) lists the course's materials with those ticked. What you tick (or untick: none) is remembered on the outline until you change it. The task reads each paper and marks the knowledge points its questions test, **In sample papers (N/M)**, from quotes found word for word in the paper; the others say **Extra**. Without papers, nothing about exams is said.

**A reference, never evidence.** The outline is a record of the library, but it is not a material: the **Sources** page, the pickers, search, counts and every list of materials leave it out, and a request that names it as material (to make questions from, as a reference source) is refused. Questions keep citing the original materials word for word.

**Built from the inventory.** Both **Generate outline** and **Write the review book** first take stock of the materials (the *inventory*, 资料清点): every page range of every material (whole pages, at most about 15,000 characters a range; a sample paper is not inventoried) is read by the model, which lists what the range teaches, one item each — term, definition, concept, formula, step, rule, example, claim, warning — with a one-line gist, its page and a quote copied from the range. The program checks every quote word for word; an item whose quote is not found is kept but flagged unverified. Items with the same name (case, width, punctuation and a bracketed gloss aside) are merged across ranges and across versions of a document. The calls run in parallel at your text concurrency (**Settings › Audio**, the setting the audio pipeline's text steps use), each range is retried alone, a rate limit lowers the pool and waits, and an unchanged range is never read again. The inventory is a hidden machine record (`provenance: 'course-outline-inventory'`), written as soon as it is read and replaced by the next one.

The outline is then made from the items, not from the file names: the items, a few materials at a time, are grouped into **knowledge points** (a coherent group a learner studies as one unit, typically a handful to fifteen items; a big document gives many points, small documents about one topic join one point), in parallel; one call arranges the points into chapters, sections and knowledge points in learning order (the syllabus or course-opening material, the materials' order and numbering, prerequisites first). Every item is in exactly one knowledge point; what the model leaves out goes to a last chapter, **Other / not placed**, never away. Each knowledge point holds the pages it teaches: a whole material, whole chapters, or a span of pages (`doc@s3-7`); every page of a material belongs to one point (the one with the most items there; a page without items goes with the page before it), so questions, **Practise this** and the exports keep working. A material with no readable text, and a paper, are in **Other**. In the test library shaped like a real course (134 materials, about 900 questions) that is 7 inventory calls, 2 grouping calls and 1 arrangement, plus 1 per 8,000 characters of sample paper; a rerun reuses the inventory and the grouping (only the papers are read again). When the inventory finds nothing (no material has readable text), the quick outline from the materials' names, chapters and questions is made instead, as before.

## The review book (explanation layer)

The review book (复习全书) writes, for every knowledge point of the outline, an explanation a learner can study instead of the slides, and **checks it against everything the materials teach**: that is what one prompt to a chat model cannot guarantee.

**Making it.** **Write the review book** (or **Update the book**) starts one task in the background: no estimate, no confirmation; the **Tasks** page shows its parallel lanes (**Inventory · Group · Write · Review · Repair**, one lane per material or knowledge point), a **Knowledge points** tab with each point's state (writing, reviewing, complete, short) and lets you pause, stop (the inventory read so far is kept, no book) or retry. The only precondition is a course with at least one material.

**The workflow, in ten lines.**

1. Inventory every page range of every material (parallel, quotes checked, reused while unchanged).
2. Build or keep the outline from it (knowledge points of items; every item in exactly one point).
3. Items the outline does not hold yet are placed by their anchor's page, then by one cheap call, else in **Other / not placed**.
4. Each point gets a MUST-COVER checklist: its items, a must or optional by the **Explanation depth**; a stressed item, and every item of a point the sample papers test, is always a must.
5. Each point is written in its own call (a big one in passes of whole pages of at most 20,000 characters), all points in parallel: free, learner-first prose in the book's language, no fixed sections and no length floor; every checklist term explained where it first comes up, a lead-in from the point before and on to the next, anything not in the materials marked **（资料以外）**.
6. The writer says which checklist items it explained; every cite must be found word for word in the point's own pages, else it is dropped with its mark.
7. An independent review call (another brief, the **review** reasoning level of **Settings › Generation**) checks the text against the checklist and the pages: missing or only named items, unsupported claims, contradictions, undefined terms, missing transitions, hard passages.
8. The program decides: an item counts as covered only when the writer claimed it, its name appears in the text and the reviewer did not flag it; a point passes when every must item is covered and nothing unsupported or contradictory remains.
9. A failing point is repaired (only the flagged parts, the issues named) and reviewed again, at most twice; one still failing is kept, marked **Short: N concept(s) missing**, never shown as complete, and the task ends **partial**.
10. One write saves the notes, their coverage and the glossary (**Glossary**, made by the program from the covered items, alphabetical, in the lookup pages); the next build asks nothing for points that passed and are unchanged, and mends only what is short.

**How coverage is defined.** At three levels, shown on the outline page and on top of the book's contents: **materials** (the materials with readable text the inventory read, and their pages), **knowledge points** (complete: every must item covered, no unsupported claim) and **concepts** (the must items of all checklists that are covered). Each opened point says **Concepts covered N/M** with the missing names, and **Fill the gaps** when it is short: a task of its own that reviews and repairs only that point against what is missing (a pass that was never written is written alone). Coverage is measured against the inventory of what is in the materials, never against a length or a template.

**What a knowledge point holds.** Opening it shows **In the sample papers** (only with papers), the explanation (Markdown, formulas with KaTeX, cite marks that open the reader at the quoted sentence), the sources, and its concept coverage. Notes written by earlier versions (key points, explanation, example, extra, passes under **Pages a–b**, italic transitions) keep showing as they were until the next update rewrites them.

**Explanation depth (讲解详尽程度).** Chosen next to **Write the review book** or in **Settings › Practice** (one setting, `settings.book.coverage`, default **Standard**). It decides which items are a must: **Lean** terms, definitions, concepts and formulas; **Standard** also steps, rules and warnings; **Detailed** every item, examples and claims too. The other items are shown to the writer as optional. Every point is written from all its pages at every level.

**A reference, never evidence.** Like the outline, the book is a hidden record of the library (`provenance: 'course-outline-notes'`), not a material; questions keep citing the original materials. Nothing you write in the book is ever overwritten by it.

**An update changes only what changed.** A point's explanation records a fingerprint of the texts it read, its checklist, its neighbours, the depth and the language; 考情 records its paper places. An unchanged point that passed costs no call; a changed one is written again; a short one is mended; new sample papers rewrite only 考情; new questions are no input. In the test library (134 materials, 19 knowledge points, one sample paper) the first book is 7 inventory + 2 grouping + 1 arrangement + 1 paper + 19 writing + 19 review calls + 1 for 考情 (plus a repair and a review for each point that misses something); the second, unchanged, makes none. Each update keeps the old version as an archived record.

## What it shows (without an outline)

| Row | What it is |
| --- | --- |
| A material | Every material filed under the course, also one with no question yet (**No questions yet**). A material that has no course of its own counts as filed under the course its questions' decks belong to. A material filed under no course, a material of another course and an archived one are not rows, even when this course's questions cite them. |
| A chapter | The chapters the material has on the **Sources** page: the converter's chapters of a book, or the chapters you applied from a kept outline. A material without chapters is one row. |
| Not matched to a chapter | Questions of a material with chapters whose place could not be put in a chapter (a question written from an older version whose quote is no longer in the text). |
| Not placed | The course's questions that no material row holds, each with why: it cites no material; **Cites a material that is not filed under this course** (a material filed under no course); it cites a material of another course or an archived one; or the material was deleted. The group names the materials filed under no course and links to the **Sources** page: file them under the course there and their questions move into their rows. These questions can be practised; they cannot be moved by hand. |

Each row shows its mastery in the words of the **Sources** list (**Mastery 62% · 12 questions**, **New · 3 questions**, **No questions yet**) and **Practise this**. When a round of exactly a row's questions is unfinished, the button says **Continue i/n** and goes on with that round.

Open a chapter (or a material without chapters, or **Not placed**) to list its questions: the question, its deck, its level and **Due** when it is due. A row lists at most 400 questions; the rest are counted and **Practise this** includes them.

**Filter by deck** narrows every row to one deck's questions. Decks stay where they are; this page never edits them.

The one hover explanation is on **What is the outline?** next to the course line.

## Where a question goes

A question is placed by the rule the coverage figure uses: its selection, else the place a generation plan verified, else where its quote stands in the text, also when the quote is written a little differently. A question that cites a page of a material is under the material's chapter that holds that place; one that cites an older version of the material, or another material made from the same recording, is placed by finding its quote in the current text.

A question that cites two chapters is listed under both and flagged **Also listed elsewhere**. It counts once in the material, in the course total and in a practice round.

The questions are those of the course's decks: archived decks and suspended questions are left out, as everywhere else. Questions still in drafts are only counted (**N more in drafts**) until they are published.

The numbers on this page are its own. The **Sources** row counts every deck's questions that cite a material, any course; the outline counts this course's questions. The numbers the **Sources** page shows are unchanged.

## Practise

Tick a row to pick all its questions, or tick single questions. The bar at the bottom says how many are picked, each question once, and **Practise picked (N)** starts the round. **Practise this** on a row starts a round of that row.

A round takes at most 200 questions. When more are picked, the round takes the first 200 in the order a practice round asks them, and the bar says so. A practice round asks due questions first, then weak ones, then new ones; it does not follow the outline order.

The round comes back to the outline: **Back to the outline** in the round and on its result page opens it as you left it (the same rows open, the same deck filter). On the result page it is the main button; the page's own next step becomes the secondary button beside it only when it goes on (continue this scope and so on); a step that is just another place to go back to (back to the learning path) is left out, and at 420 px a second button has the width of the main one.

## Limits

- The quality of the organised outline depends on the model; it has been checked with a fake model on a synthetic library shaped like a real one, not yet with a real model on a real course.
- The order of new questions in **Continue course**, on the home page and in the **Study map** is still the deck order (step 3 will prefer the outline).
- An outline is never edited by hand; **Reorganise** makes a new one.
- A question cannot be moved to another row by hand.
- Recordings keep their parts as chapters only when the material has chapters; there is no jump to a time in the recording.
- The quality of the review book's explanations depends on the model; the flow, the call counts and the quote checks have been verified with a fake model, the content not yet with a real model on a real textbook.
- The review book is updated as a whole; **Fill the gaps** asks for one short point only, and the book page's own editing changes the text.
- Each build has its own pool of parallel calls at the text concurrency: two builds of different courses running at once use up to twice that many calls together.
- The inventory and grouping answers are reused by their content (the texts, the prompts' versions, the language), not by the model: changing the model does not read the materials again; a new prompt version does.
- A knowledge point is stored in at most 80 units (passes); a longer one keeps the first 80 and says **Too long: not all of it was kept**. A very large course is fitted to at most 800 outline nodes and 400 items a point by splitting and merging points, never by dropping items.
- **Generate outline** ends **partial** when a range of the inventory or a grouping call failed; the next build asks only those.
- A point held by page spans counts no drafts (drafts are counted per material, not per page); its published questions count as usual.
- A point with no concept of the inventory to check it against is shown **Unchecked**, never complete; one must item is always kept per point that has any.

## For developers

- `course.outline {course?, deckId?, expand?, pick?}` (lib/course-outline.js; the placement is lib/course-outline-index.js) is read on demand and never sent with the snapshot. Without `expand` it returns the material rows with counts; `expand: [key]` adds the chapters of a material or the questions of a row; `pick: { keys, cards }` returns only `practice: { scope, total, capped, limit }`, a scope `review.start {mode:'path'}` takes as it is.
- `course.outline.qa {course?, keys?, cards?}` (lib/course-outline-qa.js) reads, on demand, the questions and answers kept about some rows (a knowledge point of the book page's 本节问答): a card's follow-ups of its current wording, the reader's passage annotations inside the rows' places (the chapter holding the offset, as a question is placed; the passage still the stored text) and source-QA cards. At most 200 cards are read (`cards: { total, read, capped, limit }`); each item is `{ kind: 'card' | 'passage' | 'qa-card', question, answer, at, place, openRef }`, in reading order.
- The placement is cached per library revision, minute, course and deck filter. A synthetic library of 200 materials (6 million characters), 3,000 questions and 600 fuzzy quotes takes about 75 ms the first time and 5 ms after; the answer without open rows is about 55 KB.
- The page is ui/outline/; the registry row is `outline` in ui/pages.js.
- The organised outline is a source record (lib/course-outline-book.js): `provenance: 'course-outline'`, a readable `text` and the structured `courseOutline` (`nodes` of at most three levels, each leaf's `anchors` being the document and chapter keys of `course.outline`, `other`, `orderBasis`, `papers`, a materials `fingerprint`, `supersedes`). lib/exam-point-list.js `isLibraryListSource` hides it with the 考点清单. `course.outline` answers `book` (lib/course-outline-book-view.js lays it over the engine's rows; its keys start with `bk:` and work with `expand` and `pick`).
- `generation.courseOutline.build {course, language?, papers?, supersedes?}` starts the Job `course-outline-build` (lib/contexts/generation/outline/): map calls over batches of descriptors, one reduce call, a call per chunk of sample paper, one write. Refusals: course-outline-no-course, course-outline-no-materials, course-outline-paper-invalid, course-outline-no-readable-text, course-outline-supersedes-invalid. Its result names `{ kind: 'course-outline', id, course }`; the console's open button goes to this page for that course. `papersOnly: true` keeps the current outline's knowledge points (the same ids) and only marks them again with `papers`; without an outline it is refused (course-outline-no-outline). While a review book build of the course runs, a build is refused (course-outline-book-running).
- The review book is a source record (lib/course-book.js): `provenance: 'course-outline-notes'`, a readable `text` and the structured `courseNotes` (`outlineId`, `language`, `leaves: [{ id, title, anchors, body?, exam? }]`, `papers`, `counts`, `supersedes`). A `body` is `{ fingerprint, points, explain, example?, extra?, cites: [{ n, sourceId, quote, start, end }], replaces? }` (`[^n]` marks cite n in the texts) or `{ fingerprint, empty: true }`; an `exam` is `{ fingerprint, tested, note?, replaces? }`. The fingerprints and what "out of date" means are lib/course-book-inputs.js, shared by the page and the task. `isLibraryListSource` hides it; `assertMaterials` refuses it with course-notes-not-material. `course.outline` answers `book.notes` (`{ id, stale, missing, changed, leaves, papers }`), and an expanded knowledge point carries its own notes in `open[key].notes` (lib/course-book-view.js).
- `generation.courseBook.build {course, language?, papers?}` starts the Job `course-book-build` (lib/contexts/generation/book/): the outline's stages first when needed (the same Job, `organiseOutline`), explanation calls in batches, 考情 calls, and one `sources.ingest` (the outline and the book together; what they replace is archived in the same write). The language follows the request's `language`. Refusals: course-book-no-course, course-book-no-materials, course-book-outline-running, and the outline's own. Its result names `{ kind: 'course-book', id, course }`; the console's **Open the review book** goes to the outline page of that course.
