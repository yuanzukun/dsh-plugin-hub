/* 复习全书 M4 on the page (static zh and en): an AI block sits in the learner's layer of its point, after the point's text and the learner's notes (its
   words dashed in the text above), says what it is about, 新 until kept, 保留 / 重新生成 / 删除 and a follow-up field; one whose words are gone is marked
   原位置已变; the panel over selected words offers 弄懂 and an instruction, under a heading only the instruction; without a model the shared gate. Fakes only. */
import test from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { loadUi } from './helpers/ui-module.mjs';

const ui = await loadUi(`
  export { default as BookChapter } from './ui/book/BookChapter.jsx';
  export { default as BookAiAsk } from './ui/book/BookAiAsk.jsx';
  export * from './ui/book/model.js';
  export { aiBlock } from './lib/course-book-ai-text.js';
  export { AiFoldContext } from './ui/book/ai-fold.js';
  export { summaryOf } from './ui/book/BookAiBlock.jsx';
  export { StudyServicesContext } from './ui/study-context.jsx';
  export { setUiLanguage } from './ui/i18n.js';`);
const h = React.createElement, noop = () => {}, han = /[㐀-鿿]/;
const services = { call: async () => ({}), act: async () => undefined, busy: false, notify: noop, askInChat: noop, host: {}, openSettings: noop, navigate: noop, openModal: noop };
const render = element => renderToStaticMarkup(h(ui.StudyServicesContext.Provider, { value: services }, element));
const english = fn => { ui.setUiLanguage('en'); try { return fn(); } finally { ui.setUiLanguage('zh'); } };
const textOf = html => html.replace(/<style[\s\S]*?<\/style>/g, '').replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
globalThis.window ??= { innerWidth: 1280, addEventListener: noop, removeEventListener: noop };

const gen = 'First paragraph.\n\nThe architect records each decision and its reasons.\n\nThird paragraph.';
const block = ui.aiBlock({ id: 'ai1', at: 'x', about: 'records each decision', body: 'An **explanation** of it.' }, 'zh');
const gone = ui.aiBlock({ id: 'ai2', at: 'y', about: 'words that are nowhere', body: 'Orphan.', state: 'kept' }, 'zh');
const node = { hid: 'h2', key: 'bk:p1', title: 'Entropy', number: '1', depth: 1, leaf: true, gen, mine: `My note.\n\n${block}\n\n${gone}`, qa: '',
  files: { gen: 'p1.gen.md', mine: 'p1.mine.md' }, questionTotal: 0, questions: [], children: [] };
const handlers = { gone: ui.goneSet([]), qaOpen: () => false, toggleQa: noop, source: noop, card: noop, practice: noop, create: noop, files: {}, choose: noop, busy: false,
  addHere: noop, aiAction: noop, aiFollow: noop };
const chapter = () => render(h(ui.BookChapter, { node, open: true, onToggle: noop, course: 'SA', handlers }));

test('an AI block in the learner\'s layer, with 保留 / 重新生成 / 删除 and a follow-up; one whose words are gone marked 原位置已变', () => {
  const html = chapter(), text = textOf(html);
  assert.ok(text.indexOf('Third paragraph.') < text.indexOf('My note.') && text.indexOf('My note.') < text.indexOf('关于：「records each decision」'), 'after the point\'s text and the notes');
  assert.match(text, /我的笔记与 AI 解释 \(3\) My note\./, 'under the layer\'s header, with its count');
  assert.match(html, /data-ai-block="ai1" data-ai-state="new"/);
  assert.match(text, /关于：「records each decision」 新/);
  assert.match(text, /保留 重新生成 删除/);
  assert.match(html, /placeholder="接着问…"/);
  assert.ok(text.indexOf('Orphan.') > text.indexOf('An explanation of it.'), 'in the order of the own file');
  assert.match(text, /关于：「words that are nowhere」 原位置已变/);
  assert.doesNotMatch(html, /sh:ai/, 'no marker shown');
  assert.match(text, /在这里加一段/, 'a point offers 在这里加一段');
  assert.match(html, /data-book-point="h2"/);
});

test('the panel: 弄懂 and an instruction over selected words; only the instruction under a heading; without a model the gate', () => {
  const over = render(h(ui.BookAiAsk, { target: { heading: 'h2', words: 'records', top: 10, left: 10 }, model: { ready: true }, onStart: noop, onClose: noop }));
  assert.match(over, /data-book-ai="explain"[^>]*>[\s\S]*弄懂/);
  assert.match(over, /placeholder="让 AI 写一段…（讲细点、加个例子、对比做个表）"/);
  const here = render(h(ui.BookAiAsk, { target: { heading: 'h2', top: 10, left: 10 }, model: { ready: true }, onStart: noop, onClose: noop }));
  assert.doesNotMatch(here, /data-book-ai="explain"/);
  assert.match(here, /placeholder="在这里加一段：写什么？"/);
  const off = render(h(ui.BookAiAsk, { target: { heading: 'h2', words: 'records', top: 10, left: 10 }, model: { ready: false }, onStart: noop, onClose: noop }));
  assert.match(off, /disabled="" data-book-ai="explain"/);
  assert.match(textOf(off), /弄懂和加一段需要先配置模型|读书页、改书页照常能用/);
});

test('the panel of a task not yet written shows its state and takes no second start; the × stays', () => {
  const props = { model: { ready: true }, onStart: noop, onClose: noop };
  const idle = render(h(ui.BookAiAsk, { ...props, target: { heading: 'h2', words: 'records', top: 10, left: 10 } }));
  assert.doesNotMatch(idle, /data-book-ai="state"/);
  const busy = render(h(ui.BookAiAsk, { ...props, target: { heading: 'h2', words: 'records', top: 10, left: 10, jobId: 'job-1' } }));
  assert.match(busy, /data-book-ai="state"[^>]*>正在写…/);
  assert.match(busy, /disabled="" data-book-ai="explain"/);
  assert.match(busy, /disabled="" data-book-ai="write"/);
  assert.match(busy, /aria-label="关闭"/, 'the × is still there');
  assert.match(english(() => textOf(render(h(ui.BookAiAsk, { ...props, target: { heading: 'h2', words: 'records', top: 10, left: 10, jobId: 'job-1' } })))), /Writing…/);
});

test('English: the page\'s own words', () => english(() => {
  const html = chapter(), panel = render(h(ui.BookAiAsk, { target: { heading: 'h2', words: 'records', top: 10, left: 10 }, model: { ready: true }, onStart: noop, onClose: noop }));
  const own = `${textOf(html)} ${textOf(panel)}`.replace(/Entropy|First paragraph\.|The architect records each decision and its reasons\.|Third paragraph\.|My note\.|An explanation of it\.|Orphan\.|关于：「records each decision」|关于：「words that are nowhere」/g, '');
  assert.equal(han.test(own), false, own);
  assert.match(textOf(html), /Keep Regenerate Delete/);
  assert.match(textOf(panel), /Explain/);
}));

const folding = (folded, element) => h(ui.AiFoldContext.Provider, { value: { folded: id => folded.includes(id), fold: noop, foldAll: noop } }, element);
const folded = (list, point = node) => render(folding(list, h(ui.BookChapter, { node: point, open: true, onToggle: noop, course: 'SA', handlers })));

test('a folded block: the header (AI, what it is about) and the first line of the answer as a quiet summary; no 新, body, actions or follow-up; open: all of them', () => {
  const open = folded([]), shut = folded(['ai1']);
  assert.match(open, /aria-expanded="true"[^>]*aria-label="AI 写的段落"/);
  assert.doesNotMatch(open, /book-ai__summary/);
  const from = shut.indexOf('data-ai-block="ai1"'), block1 = shut.slice(from, shut.indexOf('</aside>', from));
  assert.match(block1, /data-ai-folded="true"/);
  assert.match(block1, /aria-expanded="false"/);
  assert.match(textOf(block1), /AI 关于：「records each decision」 An explanation of it\.$/);
  assert.doesNotMatch(block1, /book-ai__actions|book-ai__follow|book-ai__body/);
  assert.match(shut.slice(shut.indexOf('data-ai-block="ai2"')), /book-ai__actions/, 'the other block is still open');
});

test('整理 on a point with AI blocks under the page\'s fold; the layer\'s header folds or opens them all', () => {
  const layer = html => /class="[^"]*book-layer__toggle[^"]*"[^>]*aria-expanded="(true|false)"|aria-expanded="(true|false)"[^>]*class="[^"]*book-layer__toggle/.exec(html)?.slice(1).find(Boolean);
  assert.match(textOf(folded([])), /在这里加一段 暂无题 出题 本节问答 整理/);
  assert.equal(layer(folded([])), 'true');
  assert.equal(layer(folded(['ai1', 'ai2'])), 'false');
  assert.match(textOf(folded([], { ...node, mine: `My note.\n\n${block}` })), /整理/, 'one block is enough');
  assert.doesNotMatch(textOf(folded([], { ...node, mine: 'My note.' })), /整理/, 'no block: nothing to tidy');
  assert.doesNotMatch(textOf(chapter()), /整理/, 'without the page\'s fold');
});

test('the summary is plain words: marks, cites and links off', () => {
  assert.equal(ui.summaryOf('\n  **Bold** and `code` [^1] see [a link](studyhub://x) and [[term]]\nsecond line'), 'Bold and code see a link and term');
  assert.equal(ui.summaryOf(''), '');
});

test('English: the fold words', () => english(() => {
  assert.match(textOf(folded(['ai1'])), /Add a paragraph here .*Tidy up .*My notes and AI explanations \(3\)/);
  assert.match(folded([]), /aria-label="Paragraph written by AI"/);
}));
