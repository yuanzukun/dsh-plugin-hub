# DSH 数学笔记助手（dsh-math-memory）

[English](README.md) · [简体中文](README.zh.md)

> 住在 Obsidian 右侧栏里的数学笔记助手，会记住你上次做到哪里。

普通对话助手聊完就忘。这个插件把笔记和长期记忆都放在你自己的 vault 里，新会话能接着上次继续。所有数据都在本机。

## 它做什么

- **跨会话记得住。** 它把画像、记忆卡、想法备忘录和对话原文都存进 `.deepseek/`，全是可读可改的 Markdown。
- **一次搜索就找得到。** `note_recall` 同时搜笔记和所有记忆层，先读最相关的几条再回答。
- **看得见、改得动。** 记忆面板列出它记住的东西，每张卡可以确认、标错或归档，回复里也会标出引用了哪张卡。
- **不越界。** 笔记留在你的 vault，服务只监听本机，助手没有 shell、不能上网、也没有删除工具。

## 现在到哪一步

版本 **0.8.3**，还是试做型。「记住、找到、改得动」这条线已经能完整跑通。还差更难的一半：帮你**建立**数学理解——知道你卡在哪、下一步该练什么、怎么复用你自己的技巧。那才是 1.0。当前状态和待办放在 [docs/README.md](docs/README.md)。

## 安装

**A. 从 Obsidian 装（推荐）。** 设置 → 第三方插件 → 浏览，搜索 **DSH Math Notes Assistant**，安装并启用。首次运行时插件会找到 DeepSeek Harness、装好配置和 vault 模板，并启动服务。

**B. 命令行安装。**

```bash
npm install -g dsh-math-memory
dsh-math-memory install --vault "<你的 vault 路径>"
dsh --profile notes-assistant --port 3180
```

**C. 手动安装。** 从[最新 Release](https://github.com/maple110011/dsh-obsidian-math/releases) 下载 `main.js`、`manifest.json` 和 `styles.css`，放进 `<vault>/.obsidian/plugins/dsh-math-assistant/`。

## 环境要求

- Obsidian 桌面版，Node.js 22.5 或更新。
- DeepSeek Harness（`@deepseek-ai/dsh`，**要求 ≥ 0.1.7-rc.2**），并配好 DeepSeek 模型。
- 默认端口 3180。普通 dsh web 用 3080，两者可以同时运行。

## vault 里放什么

```text
vault/
  AGENTS.md                     工作约定，自动加载
  .deepseek/
    memory/profile.md           你是谁、习惯怎么工作
    memory/notation.md          记号表
    memory/records/             记忆卡片
    memory/episodes/            对话原文证据
    memory/topics/              主题索引
    inbox/                      想法备忘录
    capture-policy.md           哪些内容会自动记住
```

## 装好之后

打开右侧栏开始聊天。每次会话开始时，助手会读 `AGENTS.md` 和记忆索引。想看或改它记住了什么，打开记忆面板；想改自动记忆的范围，用面板里的捕获策略一行或插件设置。

## 项目与开发

- 当前状态与待办：[docs/README.md](docs/README.md)
- 两个组件怎么配合：[ARCHITECTURE.md](ARCHITECTURE.md)
- 安装与发布细节：[docs/installation.md](docs/installation.md)、[docs/release.md](docs/release.md)
- 为什么这样改：[docs/changelog.md](docs/changelog.md)
- 改记忆或检索之前：[docs/memory/README.md](docs/memory/README.md)
- 助手的工具：四个笔记工具（`note_recall`、`note_strategy`、`note_create`、`note_links`），外加文件读写与搜索。

开发命令：

```bash
npm test          # 语法 + 478 项零 token 回归 + 路由回归（69 项路由断言） + 侧栏认证握手回归（8 项，对真实 dsh）+ 侧栏反代回归（24 项）+ 安装器 e2e（漂移检测）
npm run qa        # 引擎探针（不花 API 钱）
node scripts/build-obsidian.mjs   # 改共享文件后重建 main.js
```

- 版本：**0.8.3**

## 隐私

全部在本机运行：服务只监听 127.0.0.1，记忆是 vault 里的 Markdown，会话索引不出本机。

## License

MIT
