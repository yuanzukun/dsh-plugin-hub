# 交接文档（Handoff for the next agent）

> 目的：让下一个接手本项目的 agent 在**不翻聊天记录**的情况下，完整掌握现状、决策、已修坑、未做事项与工作约定。
> 当前版本：0.8.3
> （本文件描述**当前**状态；它与 `package.json` 的一致性由 `check-version-consistency.mjs` 守卫）
>
> ⚠️ **已发布的 0.7.8 及更早**是 dsh 0.1.7 适配**之前**的形态（bundle 补丁里没有 preset 声明），装它之后**每次新建会话都会失败**——用户侧警告见 [`docs/installation.md`](installation.md) 的"0.7.8 及更早不要用"。**0.8.0（2026-09-27 发布）起已修**，本文件描述的修复都在其中。
> 最后更新：2026-10-18（文档清理，代码未动；最近一次代码发布仍是 2026-09-27 / 0.8.0）——**离线安装也装成真正的包**（于是它出现在 dsh 的插件管理页里，并有自己的名字与图标）+ **安装器不再动你自己的配置**（`install --force` 此前会整份覆盖 profile 的 `cordis.patch.yml` 与 `package.json`，实测吃掉过真实的模型配置）+ 一批「静默失效」的修复（侧栏新建对话、会话记忆读旧格式日志、面板客户端半个装不上、回复里的记忆卡点不开、重载插件卡死端口）。**本次发布把 0.1.7 适配之前的所有修复第一次交付给用户**（0.7.8 及更早都装不上/建不了会话）。计数（门禁条数、零 token 回归断言数）一律以 `scripts/lib/gates.mjs` 与套件自报的 `__CHECKS__` 为准，不要从这段叙述里抄。
> 更早：2026-09-18（0.7.8）——**治理闭环 + 记录纪律**：净增益 `gain`、有方向的依据链 `depends_on` 与失效级联、接地门、状态即权限、边界随否决收窄、`decision_guidance`；**体检台账**（`cache/audit-ledger.jsonl`，跨次判定史，"此前已在账"不再当作新问题）、**索引行说明下限**、**卡片尺寸上限**、**预算截断自报**、**破坏性写入原子化 + 失败进报告**、注入预算档位（含设置页入口）。**0.7.7 与它之间没有 Release**：0.7.8 装的是 0.7.7 之后 43 个提交的全部用户可见改动。门禁 38 → **41**，零 token 回归 240 → **376** 项。**⬅ 这两个数字是那一版的历史快照**。本节越往下越像"当下"，所以凡是要引用计数，**以 `scripts/lib/gates.mjs` 与套件自报的 `__CHECKS__` 为准**，不要从这一段的叙述里抄。
> 更早：2026-09-15（0.7.7）——用户实测的三处缺陷：**工具返回值不合 schema**（dsh 对成功返回值也严格校验 + `additionalProperties: false`，坑 75）、**`note_recall` 遇到边界卡直接抛异常**（`entry.doc.X` 形状错误，零覆盖分支，坑 76）、**链接跳转的端口/令牌不稳定 + 点链接弹外部网页**（`target="_blank"` 与跨源导航，坑 77）。门禁 35 → **38**。此前的 2026-09-14（0.7.6）：「新建会话」静默失效的根因与修复（agent preset 的 persona 字段 `text`→`prefix`，见坑 70）+ 卡顿随文档规模增长的实测（坑 71、`archive/sidebar-performance-2026-09.md` §0.3）。更早的 2026-08 大改收尾——仓库文档大改 + 文献库子系统 + 记忆系统强化（两轮）+ Phase 1 解耦 + Phase 2a/2b dsh web 面板 + 面板方案 A（两实例）。**0.7.2 时**（记忆纠错与确定性自维护落地，见 `self-correction.md`；上一版 0.7.1 = 2026-08-26）。0.7.1 新增 **dsh-native 分发重构**（bundle + `dsh plugin add` 原生安装、`--direct` 离线拷贝、owner marker 冲突解决、对称 `uninstall`；功能无变化，仅优化安装方式），详见 `docs/dsh-native-refactor.md` 与 `docs/installation.md`。

## 1. 项目是什么

`dsh-math-memory`（原 `dsh-obsidian-math`）：把 DeepSeek Harness（dsh）嵌入 Obsidian 右侧栏的**数学笔记助手**，核心是跨会话分层记忆系统。**单仓库**、**两个独立分发产物**，外加两个仓库内子系统：

- **npm 包 `dsh-math-memory`**（`dsh/`）：dsh agent preset + profile + 安装器，把记忆系统装进任意 DSH_HOME。
- **Obsidian 社区插件**（id `dsh-math-assistant`，根目录 `main.js`/`manifest.json`/`styles.css`）：右侧栏 UI（服务管理、记忆面板 ItemView、反馈闭环、归档）。
- **文献库**（`literature/`）：双面文献库——人类侧 `cards/`/`reading/`/`notes/`/`index.md`，机器侧 `.raw/`/`.index.json`（gitignored）；14 篇论文全部导入（均有 MinerU 全文）。
- **dsh web 管理面板**（`dsh/host/math-memory-panel.mjs` + `dsh/client-panel/`）：装在**主 dsh web（3080）** 的 React 面板，读/写记忆与工作区切换。

仓库地址：github.com/maple110011/dsh-obsidian-math（**仓库名未改**，只有 npm 包名改了）。

## 2. 文件地图（改哪里先看哪）

| 路径 | 职责 |
|---|---|
| `dsh/preset/math-memory.mjs` | 记忆注入引擎：五层导航摘要、体检、dialogue index、memo 提醒、`config.md` 开关解析 |
| `dsh/preset/note-tools.mjs` | 笔记工具：note_recall（含 tag-only 枚举）/note_strategy/note_create/note_links + BM25 + `resolveWorkspaceRoot` + `hookPrior`（`note_search` 2026-09-20 退役，见 `docs/memory/retrieval-v3.md` §5.1） |
| `dsh/preset/hook-frontmatter.mjs` | **共享 hook 块解析器**（单一事实源；+ `HOOK_SCHEMA_VERSION`；被 ESM import + 插件嵌入 loader 双路加载） |
| `dsh/preset/agent.cordis.yml` | preset 装配：最小工具面 + 记忆开关（`enabled`/`dialogueIndex`/`reminders`/`audit`） |
| `dsh/preset/preset.yml` | preset 元信息（显示名「数学笔记助手」） |
| `dsh/profile/` | **profile `notes-assistant`**：fail-closed 沙箱（workspace-write + approval never）；**不挂载任何 `@linxin666` UI 插件**（没有 opt-in 皮肤中心；皮肤只在主 dsh web，见 ARCHITECTURE） |
| `dsh/templates/` | vault 模板：`vault-AGENTS.md`（工作协议，安装后名为 `AGENTS.md`）+ 记忆层模板 + `config.md`（独立设置）+ `capture-policy.md` |
| `dsh/templates-manifest.json` | **模板清单单一事实源**（build/install/bootstrap 三处派生 + 构建漏模板门禁） |
| `dsh/install.mjs` | CLI **编排器**（npm bin `dsh-math-memory`）：`install`（原生 `dsh plugin add`）/ `install --direct`（离线扁平拷贝）/ `status` / `uninstall`；写 owner marker |
| `dsh/host/memory-admin.mjs` | host-agnostic 记忆管理核心（确定性操作 + 面板数据层；Obsidian 插件经嵌入 loader 复用） |
| `dsh/host/math-memory-panel.mjs` | **dsh web 宿主面板插件**：inject `webServer`+`workspaceRegistry`，路由 `/memory-panel/*`（state/workspaces/feedback/archive/capture-policy/archive-episodes），loopback-only + `pathInside` 门控 |
| `dsh/client-panel/` | **dsh web 客户端面板**：React 源码 `src/index.jsx` + esbuild 打包 `build-client.mjs` + 安装 `install-into-profile.mjs` + 产物 `lib/client.js` |
| `literature/` + `scripts/lit-import.mjs` + `docs/literature.md` | **文献库子系统**：BibTeX + PDF + MinerU markdown → 双面文献库（14 篇） |
| `docs/dsh-panel-research.md` | dsh web 面板机制调研（客户端契约 / settings.section 槽位 / profile 装配名单 / 宿主路由） |
| `docs/design-intake-2026-09-21.md` | **用户提问评估（2026-09-21）**：三个问题的取证与吸纳决策——拖拽引用（可行性 + 待实测项，**只登记未实施**；该功能已于 2026-10-18 移除）、记忆引用打不开（两处根因 + B组实施范围）、注入机制（实测数据 + 「不做 handoff 文档」的理由） |
| `obsidian/main.template.js` | Obsidian 插件源码：服务管理、LinkServer（/open + /feedback）、MemoryView 面板、全局皮肤 patch 兜底、bootstrap、**命令「在 dsh web 打开记忆面板」+ `memoryPanelUrl` 设置** |
| `scripts/build-obsidian.mjs` | 把模板 + dsh 文件嵌入 `main.js`（**改共享文件后必跑**） |
| `scripts/test-memory.mjs` | 零 token 记忆回归（478 项断言，进 `npm test`） |
| `scripts/test-panel-routes.mjs` | `/memory-panel` 路由信任边界回归（69 项断言：跨源拒绝、root 锚定（含**未配置**时拒绝调用方 root）、token、字段校验、写入型端点；进 `npm test`） |
| `scripts/test-panel-proxy.mjs` | 侧栏反代回归（权威 cookie、Host 保真、401 透传、升级转发、接线断言 + **笔记链接拦截器**注入；共 24 项断言） |
| `scripts/test-panel-auth.mjs` | 侧栏握手端到端（8 项，对真实 dsh；未装 dsh 或环境不允许子进程写自身状态时 SKIP） |
| `scripts/test-panel-present.mjs` | **呈现层**纯净决策回归（提取 `MemoryView` 的 `layerEntries`/`pendingItems`/`cardMeta`/`trendText` 四个方法并求值；测真源码，接缝挪走即报错） |
| `scripts/test-installer.mjs` | 安装器 e2e + 漂移检测 |
| `scripts/check-doc-consistency.mjs` | 文档一致性守卫（断言数等数字与代码实测对齐，进 `npm test`） |
| `scripts/check-rename.mjs` / `check-skin-fallback.mjs` / `check-plugin-id.mjs` | 三个守卫（见 [`traps.md`](traps.md)） |
| `scripts/qa/` | engine-probe（12 组 ground-truth + §2 可达性分层/池化 A/B）+ e2e（真实 token 会话，`npm run qa:e2e`）；侧栏性能探针已于 2026-10-18 随机制删除 |
| `scripts/deploy-local.mjs` | 本机一键部署（gitignored，含本机路径；用 copyFileSync 手动遍历，勿用 cpSync） |

## 3. 当前状态与近期改动（最新在上；现状口径以 docs/README.md 为准）

> **增量（本会话）**：文献库入库 MemTrapBench（第 15 篇，已蒸馏），并落地「记忆适用性（防记忆陷阱，AdaptiveMem 本土化）」——AGENTS.md §5 四风险 + 决策流程、`math-memory.mjs` 每轮注入适用性纪律、`note_recall` 适用性提示、`inapplicable` 反馈动作（不降成功率）、`lit-import.mjs` 改增量合并（修全量覆盖 bug）、`docs/literature.md` 补「新增单篇文献 SOP」。回归 83→90。皮肤中心加固：`skinCenterMountable` 收紧为检查两个具体皮肤包，degrade 皮肤禁用块改为运行时读取 `$DSH_HOME/cordis.patch.yml` 动态生成（去硬编码 11 id）。又入库并蒸馏 4 篇检索对齐文献（Dual RAG / QueryLink / HyPE / MemSearcher；**文献库当前规模见 [`docs/literature.md`](literature.md)**，此处不再复述数字——同一事实曾被写出 14/15/19/20 四个版本），综合改进见 `literature/notes/retrieval-alignment-2026-08.md`。**策略层已实现**（`strategy-layer.md` 落地）：strategy 模板 + `note_strategy` 工具 + `working.md` 注入 + AGENTS.md 策略层路由/iterative retrieval；回归 +5（strategy 解析/classify/working 注入）。**记忆纠错与确定性自维护已实现（0.7.2）**：`docs/memory/self-correction.md` P1–P5 全部落地——P1 纠错进检索三件套（superseded/duplicate_of 排除 / wrong 降 verified+封顶 0.35 / hookPrior 权重 0.15）、P2 待重审清单、P3 低效用卡自动归档（默认 off）、P4 duplicate_of 标记、P5 strategy 统一生命周期；回归 90→104，`main.js` 已重建。**自动保存对话已实现（0.7.3）**：`docs/memory/obelisk-comparison.md` §5 落地——整场对话（不含思考）确定性写进 episodes（尾截断 + seq 增量续接 + vault 过滤 + `sessionCapture` 当时默认开；**0.7.4 起改为默认关**——见 §5 决策记录），`distillSession` 加 seq/createdAt/clip 参数，`runSessionCapture` + marker；回归 104→118。双面板 UI（Obsidian 记忆面板 + dsh web 记忆面板的「自动保存对话」开关、「立即保存对话」按钮、「N 个未保存」角标）也已落地，`main.js` 与 `lib/client.js` 重建。

**本轮改动总账（按阶段）**：

1. **仓库文档大改**：测试断言数全仓统一（README 中英 / ARCHITECTURE / docs-memory-README / handoff）；README 双语旧身份 `obsidian`→`notes-assistant`；env 旧名改新名（`DSH_WORKSPACE_ROOT`/`DSH_MATH_MEMORY_*`）；`docs/archive/REFACTOR-PLAN.md` 退役、根 `TESTING.md` 并入 `docs/memory/testing.md`；新增 `scripts/check-doc-consistency.mjs` 一致性守卫。
2. **文献库子系统**：`literature/` 双面文献库 + `scripts/lit-import.mjs` + `docs/literature.md`；**当时**导入 14 篇论文、产出 14 张卡 + 14 条精读记录 + `notes/memory-system-review.md`（14 篇综合、优先级建议）。**当前规模以 `docs/literature.md` 为准**（现为 20 篇，该文件与 `literature/.raw/` 的实际内容一致）。
3. **记忆系统强化（两轮）**：`hookPrior` promote/demote（verified/success_rate/uses 0.45/0.25/0.20 + recency 0.10，90 天线性衰减）；每日体检新增反模式、热度归档候选（heat 0.5/0.3/0.2）、被动召回信号（空结果率）；records 模板加 `confidence` 与「可修订记录」；templates/profile/AGENTS.md 补定理表聚合、条件演化门、写卡去重、自动链接、Refine 步、检索粒度纪律；回归 75→82。
4. **Phase 1 解耦（host-agnostic core）**：把 Obsidian 插件里的确定性记忆操作抽成 `dsh/host/memory-admin.mjs`（纯 node:fs/path）；`build-obsidian.mjs` 嵌入 + 插件 `MEMORY_ADMIN` loader；插件本地副本改别名；`npm test` 增 `node --check dsh/host/*.mjs`。
5. **Phase 2a（宿主面板路由）**：`dsh/host/math-memory-panel.mjs` 挂 `/memory-panel/*`（loopback-only + pathInside 门控，复用 memory-admin）；boot 冒烟 `GET /memory-panel/state` 返回 `{ok:true}`。
6. **Phase 2b（客户端面板）**：`dsh/client-panel/` React 面板（工作区下拉 + 手动 root + localStorage），esbuild 打包，装在主 dsh web Settings（`settings.section` 槽位，显示名「记忆面板」）；实测可用。
7. **面板方案 A（两实例）**：主 dsh web `3080`（`web` profile，编程 + 记忆面板）、notes dsh web `3180`（`notes-assistant` profile，Obsidian 聊天，fail-closed、不挂 `@linxin666`）。Obsidian 插件新增命令「在 dsh web 打开记忆面板」+ 设置 `memoryPanelUrl`（默认 `http://127.0.0.1:3080/`，`electron.shell.openExternal`）。

**身份解耦（早前 Phase 2，已稳定）**：文件更名 `obsidian-*`→`math-memory`/`note-tools`/`math-memory-workspace`；npm 包 `dsh-obsidian-math`→`dsh-math-memory`；profile/preset id `obsidian`→`notes-assistant`；权限预设 `obsidian-locked`→`math-memory-locked`；env 别名 `DSH_WORKSPACE_ROOT`/`DSH_MATH_MEMORY_*`（旧名兼容）。**单仓**（不拆双 git 仓库）。

**开关与共存 / 独立设置面板**：总开关 `enabled` + 粒度开关 `dialogueIndex`/`reminders`/`audit`；独立设置面板 = 工作区级 `.deepseek/config.md`（host-agnostic 配置文件）；**皮肤中心改为可选**（默认不挂载；Obsidian 设置「启用皮肤中心」开关把 `ui-skin-center` + `ui-web-ui-settings` 追加到 `notes-assistant.patch.yml`，需 web profile 镜像 `@linxin666` 包）。

**QA 状态（2026-09-26 重测）**：`npm test`（= `node scripts/run-gates.mjs`）**51 条门禁注册、本机 49 ok / 2 SKIP / 0 FAIL**；记忆回归 **427/427**、路由 **62/62**、反代 **32/32**、呈现层 20/20。⚠️ **两条 SKIP 不是通过**——`test: panel auth e2e` 与 `test: agent preset mounts` 都因"本机没有已安装的 dsh + notes-assistant profile"而**一条都没比**（汇总会单独列出被跳过者与原因，见坑 98）。合成 vault 引擎探针 **8/8 PASS**（本轮实测，`npm run qa`）。**真实 vault 探针本轮 SKIP**（`engine-probe: 需要 DSH_WORKSPACE_ROOT 或 DSH_OBSIDIAN_VAULT`）⇒ 本节历史上写的"真实 vault 探针 12/12"**在本机无法复核**；§7 另记 2026-09-20 实测为 **11/12**（唯一红项是定理索引命中，已判为 vault 内容漂移）。**以「哪一次、在什么上跑」为准，不要引用一个不带日期的分数。** 真实 token 会话 E2E（`npm run qa:e2e`）**仍需用户本机跑**（要 DSH_HOME/DSH_WORKSPACE_ROOT/DSH_BIN 真实 JS 入口 + 模型余额）。侧栏交互性能探针（`scripts/qa/sidebar-perf-probe.mjs`）当时按需运行、不进 CI；**该探针已于 2026-10-18 随侧栏性能机制删除**。

**宿主适配（2026-09-10，dsh 0.1.5-rc.1 + dsh-web-all 0.3.20）**：完整取证与清单见 [`docs/dsh-0.1.5-adaptation.md`](dsh-0.1.5-adaptation.md)。结论：解码与蒸馏路径**无需改动**（V3 仍是多帧无字典 zstd，事件名与 `source.kind==="user"` 判据不变）；profile patch / preset / `settings.section` 槽位在 0.1.5 下全部实测有效（boot 冒烟 + `/memory-panel/*` 均 200）。唯一真实缺陷是 **V3 迁移会为同一会话保留 V2 原件**，于是"一个会话两份都以 `.jsonl.zstd` 结尾的日志"成为长期状态；已按会话去重（**显式优先 `.v3.` 变体**，因为两者 mtime 可能同刻）修复，`findSessionLogs` 在切片前完成折叠，preset 与 host 两份副本同步。回归 126→138，`main.js` 已重建并已 `deploy-local` 到本机 vault / `$DSH_HOME`。

**安全修复（2026-09-10，评估 P0 三连 + 三个小修）**：完整评估与优先级队列见 [`docs/project-assessment-2026-09-10.md`](project-assessment-2026-09-10.md)。本轮修掉：① `/memory-panel/*` 无鉴权 + 约束根由调用方指定（→ root 锚定 + Origin 校验 + 可选 token）；② `archiveMemoryFile` 零校验（→ 只收 `.deepseek/<层>/*.md` 常规文件，且校验通过才建归档目录）；③ frontmatter 写入的 `$` 替换模板展开与空块偏移 0 插入（→ `frontmatterSpan` + `replaceFrontmatter` 按偏移拼接）；④ `install-into-profile.mjs` 在所有随仓库发布的 patch 上静默 no-op（→ 追加式 insert + 写后断言）；⑤ LinkServer 二次解码导致链接挂起（→ 删二次解码 + handler 包 try/catch）；⑥ `/memory-panel/workspaces` 因 root 门禁永远 400（→ 分支前移）；⑦ capture-policy 的 `field` 未校验（→ 白名单 + mode 白名单）。回归 **165 + 路由回归 25**（现为 191 + 28）；新增 `scripts/test-panel-routes.mjs`、`scripts/check-embedded-writers.mjs`；`check-doc-consistency.mjs` 改为读**运行期** `__CHECKS__`。`main.js` 已重建、`deploy-local` 已执行、live 验收 9/9（含"被拒的归档不留空目录"）。

**检索与验收网修复（2026-09-10，第二批）**：① **探针改调产品真管线**——`note-tools.mjs` 新增 `buildRecallDoc` / `rankRecallDocuments` / `rankStrategyCards`，`note_recall`、`note_strategy` 与两个探针共用同一实现（原先探针手抄 `0.85*BM25+0.10*cjk`，产品是 `0.75*BM25+0.10*cjk+0.15*hookPrior`，静默分叉导致纠错机制长期无回归覆盖）；② **导航索引降权**（`episode-index` 0.4、`theorem-index` 0.7）+ 弱信号判据落在内容文档上 ⇒ **真实 vault 探针 9/12 → 12/12，未改任何 ground truth**；③ 四项决策落地：皮肤中心开关改名并写清"关掉不关皮肤"（默认仍 false）、junction 镜像自愈（`lstatSync` 判别悬空即重建）、`captureSubagents`（默认 false，V3 头部 `origin`/`delegationDepth` 可判定）、导航索引降权。回归 **160 → 165**（新增子代理过滤 5 项）。

**体检报告与面板呈现重做 + 反馈三选项分层（2026-09-10，第三批，0.7.5）**：用户提出四个问题——体检报告「几乎是 ds 的输出记录，令人不知所云」、记录层「对/错/归档」三选项「不明所以，感觉意义不大」、记忆面板信息显示待优化、Release 没更新版本导致插件商店拿不到新版。两份只读取证调研（面板呈现 + 反馈机制）之后落地：

- **体检报告拆成两个渲染、一份数据**：`buildAuditReport` 现在产出 `checklist`（模型看的指令清单）与 `human`（人看的中文摘要），结构化事实进 `counts`/`decisions`/`thresholds`/`sections`/`structural` + `schemaVersion: 2`；`readAuditReport` 让面板拿到对象而不是一根字符串。顺带修掉「报告建议归档一张它刚刚归档掉的卡」的排序缺陷（`archivedRels` 统一过滤 section 与 `decisions`）。
- **数据层补齐**：`collectMemoryState` 收集全部五个卡片层（此前只 records/templates，文档承诺的 topics/theorems/strategy 在两个面板都不可达）、episode 带人类标题/主题/日期（解析 `episodes/index.md`，替代捕获写盘时间）、卡片带 `topic` 与 `layer`、搜索大小写不敏感且覆盖 episode。
- **「对/错/归档」分层**：回复行改为每卡一行并写明卡标题、去掉 🔁 不适用（它写的字段无任何读取方）；`归档` 从评估行移出，成为面板的生命周期动作（二次确认 + 危险样式）；web 面板的 `run()` 不再丢弃响应体（**回执**是这次改动的关键之一）；`❌` 不再给无评级卡凭空写 `success_rate`；无 `hook:` 块的卡自动补块，✅/❌ 对所有卡可用。
- **发布链路**：新增 `scripts/check-version-consistency.mjs`（五处版本 + tag）、`versions.json`、`docs/release.md`；三方版本对齐 0.7.5；`release.yml` 从「推 tag 零测试」变成完整门禁（npm ci + 版本一致性 + 重建 diff + npm test + 正确的 CHANGELOG 段落）。**推 tag 仍需用户口令。**
- 回归 **165 → 224**（新增 §30 面板数据层 22 项、§31 体检归档一致性 6 项），`main.js` 与 `lib/client.js` 均已重建。

## 4. 必须知道的坑（勿重蹈覆辙）

> 完整清单已移到 [`traps.md`](traps.md)（**121 条**，编号 1..121 稳定；数字由 `scripts/check-doc-counts.mjs` 守）。
> **改动前按编号查与你改动相关的条目，不要通读。**

## 5. 用户决策记录（不要推翻）

- **单仓**（不拆双 git 仓库），两个产物独立分发（npm 包 + Obsidian 插件）+ 仓库内文献库/面板子系统。
- npm 包名 `dsh-math-memory`；插件 id `dsh-math-assistant`（**不改**）；仓库名 `dsh-obsidian-math`（**未改**）。
- 版本 0.6.2（2026-08-23：链接站内跳转 + 数学交流提示词 + ask_user 节制 + 链接路径免手工编码）。
- 独立设置面板 = **配置文件**（`.deepseek/config.md`），不是图形 UI（若需要可后续在其上加 web 页面）。
- **记忆面板进主 dsh web（3080）**（方案 A）：Obsidian 用命令 `shell.openExternal` 打开 3080；notes profile（3180）保持独立/fail-closed、**默认不挂任何 `@linxin666` UI**（**2026-10-18：opt-in 皮肤中心已删除**，见下方复核）。
- **文献库放仓库**（`.raw/` gitignore）。
- 不做 token 型 benchmark；推送 GitHub 必须等用户口令（"推送"）。
- **项目定位（2026-09-10 明确，已写进 README 中英与 docs/memory/README.md）**：记忆系统已解决「agent 记不住用户问过什么」；**「辅助用户打磨一套数学理解，并建立对理解/技巧的调用体系」远未解决，真正实现它才是 1.0**。当前（0.8.3）仍是"记忆基础设施 + 控制面可用"的 0.x 试做型。
- **会话隔离（`docs/session-scope.md`）已否决**（2026-09-10，用户决定）：P1/P2/P3/P4 全不做——原始不适来自"面板信息量太低"而非会话列表本身，而 P1 要包住被会话搜索 / lineage / 按 URL 打开共用的 `sessionPersistence.list()`，代价与收益不成比例；侧栏分组折叠（状态持久化）已经够用。详见该文顶部的否决块。
- **捕获策略扩到四个档位**（2026-09-10）：`idea/fact/preference/structure` 各管一组层，`structure` 默认 `auto`（缺行等同 auto，升级不会让用户被多问）。见 `control-panel.md` §2.4。
- **外部设计吸纳**（2026-09-10）：只吸收 5 个「卡片字段 + 确定性检查」级别的小件（适用边界门控 / `harmed` / `verified_by` / 声明值对账 / `degraded`），**拒绝任何"每轮新增必做步骤"**的机制——我们的实测失败模式是"机制没人用"，不是"机制不够多"。评估存档 `docs/design-intake-2026-09-10.md`（含否决清单，勿重议）。
- **检索不做通用去冗余/多样化重排**（有反例实验支撑，见坑 46）。
- **GraphMemix（Li et al. 2026）吸纳范围（2026-09-10 定）**：已吸收「边界门控 / `harmed` / `verified_by` / 声明值与有效值 / `degraded`」（`design-intake-2026-09-10.md` §1）；**多视图 max-pool 实测后不采纳**（探针 A/B：Direct 11→11 不变，目标排名均值 1.73 → 2.27，2 例变差 0 例改善 ⇒ 保持单袋默认，`retrieval-v3.md` §7.2）；查询条件化关系信任 + 锚点槽位、自适应 k、两阶段适用性判定**记录在案不实现**（各带触发条件，`retrieval-v3.md` §7.4）。可达性分层 + 有符号净恢复 Δ 已作为**常驻测量**进引擎探针（`retrieval-v3.md` §7.5）。
- **侧栏性能模式默认开启**（2026-09-10）：它是**唯一**会改动 dsh 侧栏响应字节的机制，取舍是「皮肤毛玻璃 + 两处热循环的节奏」换「宿主与侧栏动画不再掉帧」。开关在插件设置里，关掉即回皮肤原样；不动 dsh 本体、不动皮肤文件、只作用于侧栏这一份渲染。
- **侧栏加载皮肤动态装饰默认开启**（2026-09-10，第二轮）：关掉后侧栏不加载皮肤客户端脚本（hero 场景/状态角色/信号芯片消失），换来实测最流畅的一档（帧 >50ms 归零、Task −18%、RecalcStyle ops −34%）。默认保留装饰，把选择权留给用户。

> **（2026-10-18 复核：机制已删除）** 上面两条决策记录**作废**（保留以存史）：侧栏性能模式、皮肤 hooks 改写与 opt-in 皮肤中心**全部删除**——皮肤只在主 dsh web（3080），Obsidian 侧栏不追皮肤；插件不再改写侧栏 HTML，唯一保留的是**笔记链接拦截器**。实测结论不变：卡顿主因是 **dsh 前端 DOM 规模/布局与样式重算**，属上游，插件不修。历史证据见 [`archive/sidebar-performance-2026-09.md`](archive/sidebar-performance-2026-09.md)；现行边界见 [`memory/control-panel.md`](memory/control-panel.md) §2.6。
- **lemmalog（`JordyZomer/lemmalog`，Rust Datalog 记忆引擎）评估结论：不引入**（2026-10-01）。理由：**fit failure 而非质量问题**——四个彼此独立的阻断项（① 要新增一层记忆，在"不做"清单里；② 打破"vault = 唯一持久化 + 纯 Markdown、无数据库"；③ 三条安装通道**没有一条**能交付 `cargo build` 产物；④ 主用法是 MCP 服务，而 preset **刻意不挂** shell/web/subagent，够不着），每条在本仓库都有**书面决定**。它许诺的好处也已被覆盖或**有意拒绝**（传递式级联 `design.md:130` 拒绝；来源链已设计为纯 JS 的 V0–V9 计划；图检索实测 **flat > graph**）。**完整证据、成本与"若坚持要验"的唯一合理形态见 [`lemmalog-assessment-2026-10-01.md`](lemmalog-assessment-2026-10-01.md)。** ⚠️ 本行是**决策记录**：下次再提请先读该文，不要从头再评一遍。
- **dsh 版本下限保持 `>=0.1.7-rc.2`**（2026-10-01 用户拍板）：0.2.0-rc.2 已实测通过且**没有破坏性变更**，所以**不**把下限提到 0.2.0（那会把还能用的 0.1.7-rc.2 用户挡在门外）。两个 README 已写明"0.2.0-rc.2 已实测"。**反向禁止**：不要把范围"顺手整理"成 `>=0.2.0` / `^0.2.0`——在 prerelease 运行时上不匹配会让插件被静默停用（陷阱 112）。
- **外部工具/系统的引入登记惯例**（2026-10-16 立）：引入一个外部系统/仓库的机制或结论时，**必须同时留下两样**——① **一份专项评估文** `docs/<tool>-assessment-<date>.md`（裁决 ＋ 理由 ＋ 成本 ＋「若坚持要验」的唯一合理形态；先例 [`lemmalog-assessment-2026-10-01.md`](lemmalog-assessment-2026-10-01.md)）；② **本节一行决策记录**。之所以要立：这条惯例此前**不存在**，缺口由文档自己记下（`literature/cards/yangOptSkillsLearningGeneralizable2026.md:38`、`literature/notes/improvement-details-2026-09-17.md:452`），于是决策散落在**五个地方**（本节 / `design-intake-*-§3` / `references.md` 的"不适用"段 / `plugin-family-assessment` §3.1 台账 / `pending-decisions-*`），**谁都不是权威**。⚠️ **不要记进 §7**：§7 是"未做/下一步候选"，把已关闭的决定写进去会被下一个人当成未处理项重捡——`literature/reading/verymathOrg2026.md` 与 `wangMemForestEfficientAgent2026.md` 曾这样指路，已更正。

## 6. 工作流命令

```bash
npm test                        # 478 项零 token 回归 + 69 项路由回归 + 8 项认证 + 反代回归（项数由套件自报）+ 安装器 e2e + 漂移 + 五守卫 + 文档一致性 + 中英配对 + 语法检查（= node scripts/run-gates.mjs）
node scripts/build-obsidian.mjs # 改 dsh/ 或模板后重建 main.js
npm run build:client            # 改 dsh/client-panel/src 后重建 lib/client.js
node dsh/client-panel/install-into-profile.mjs --dsh-home <home>   # 装面板进 web profile
node scripts/deploy-local.mjs   # 本机部署（vault / DSH_HOME / 插件目录）
dsh --profile notes-assistant --port 3180   # 原生（bundle 已提供 panel/workspace）；--direct 装时需 --patch notes-assistant.patch.yml
dsh plugin --profile web add dsh-math-memory   # 把 preset 加进主 web profile（原生，替代旧 --preset-only）
# 真实 E2E（需模型余额 + 真实 vault + 真实 JS 入口）：
#   DSH_HOME=<home> DSH_WORKSPACE_ROOT=<vault> DSH_BIN=<.../lib/bin.js> npm run qa:e2e
# 调试日志：<vault>/.obsidian/plugins/dsh-math-assistant/debug.log
```

## 7. 未做 / 下一步候选（供新会话挑选）

> 本清单已拆成两份（2026-10-18）：**开放项**在 [acklog.md](backlog.md)（53 行，只挑开放项）；**已完成台账**在 [rchive/handoff-section7-done-2026-10-18.md](handoff-section7-done-2026-10-18.md)（56 行，只读，不要重做）。
> 本节不再维护内容——新增/完成一项请改 `backlog.md`，并把"为什么/验证"写进 `changelog.md`。

## 8. 与用户协作约定

- 大改先评估（docs 先行），用户抉择后再动手；
- 每轮改动同步 docs（changelog 必写），代码与文档同提交；
- 涉及部署/推送等副作用操作，先说明再执行；用户口令 "推送" 才 push。
