# 文档索引（先看这里）

> 这是本仓库文档的**唯一入口**。版本 **0.8.3**（最后整理：2026-10-18）。
> 读者假定：你大致知道这是个「Obsidian 里的数学笔记助手」，但不需要先了解它的全部历史和内部术语。
> 新增、移动或废弃文档必须同步本页；`scripts/check-doc-layout.mjs` 会检查「每份 docs 文档都能从本页到达」以及「文档间的链接都存在」。

## 30 秒：项目现在到哪一步

- **已经能用**：跨会话记忆（画像 / 记忆卡 / 想法 / 对话原文）、统一检索 `note_recall`、记忆面板里的浏览与纠正、每日确定性体检、三种安装方式。
- **还没做到**：把「记住你说过什么」升级成「帮你想明白」——理解状态、卡点、技巧调用体系、复习调度。这四件是 1.0 的定义。
- **活跃的决策**：见 [pending-decisions-2026-10-01.md](pending-decisions-2026-10-01.md)（重构蓝图 P1–P7）和 [pending-decisions-2026-09-26.md](pending-decisions-2026-09-26.md)（记忆相关；**先读文件头部的状态块**，正文是当时的建议）。
- **想接着干活**：[`backlog.md`](backlog.md)（只挑仍开放的项）；已完成台账在 [`handoff-section7-done-2026-10-18.md`](handoff-section7-done-2026-10-18.md)（只读，不要重做）。

## 我想……（按需求查）

| 我想…… | 看这份 |
|---|---|
| 知道这是什么、怎么装、用户能看到什么 | [README.md](../README.md) / [installation.md](installation.md) |
| 改代码、跑测试、提交 | [AGENTS.md](../AGENTS.md)（维护协议，agent 会自动加载） |
| 看目录职责、两个组件怎么配合 | [ARCHITECTURE.md](../ARCHITECTURE.md) |
| 为什么主 dsh web（3080）与侧栏 dsh（3180）不一样 | [port-and-isolation.md](port-and-isolation.md)（两个 profile 是安全 / 稳定性边界；2026-10-18 复核见文首） |
| 改记忆系统 / 检索 | [memory/README.md](memory/README.md) → [memory/design.md](memory/design.md)（当前实现规格） |
| 改记忆面板、路由、反馈 | [memory/control-panel.md](memory/control-panel.md) |
| 改环境变量 | [env-vars.md](env-vars.md)（唯一参考，代码与本表双向校验） |
| 发版 | [release.md](release.md) |
| 查「为什么当时这么改」 | [changelog.md](changelog.md)（2026-10 起；更早见 [changelog-2026-Q3.md](changelog-2026-Q3.md)；按日期/关键词找） |
| 看用户可见的版本变化 | [CHANGELOG.md](../CHANGELOG.md) |
| 找历史踩过的坑 | [traps.md](traps.md)（121 条，按编号查，不要通读） |
| 看还没拍板 / 没做的事 | [backlog.md](backlog.md)（开放项）；决策台账见 [pending-decisions-2026-10-01.md](pending-decisions-2026-10-01.md) / [pending-decisions-2026-09-26.md](pending-decisions-2026-09-26.md) |
| 改文献库 | [literature.md](literature.md) |

## 写文档的规则（30 秒版）

1. **先声明身份**：每份文档前 5 行写类型、状态、权威范围、被谁取代、核对证据（模板见文末）。**文件名带完整日期（`*-YYYY-MM-DD.md`）的历史文档必须写 `类型：`/`状态：`——`check-doc-layout` 会强制检查**；其余文档在下次改动时补。
2. **现在时只写当前事实**，并带 `as of 版本/日期` 或代码行号/门禁名。没有日期或证据的「当前 / 目前」视为待核实。
3. **一个事实只在一个地方定义**，别处只写一句 + 链接。重复的副本迟早会分裂（项目定位曾有 5 份，5 份都过期）。
4. **历史不改写**：旧结论保留，用 `（YYYY-MM-DD 复核：……）` 追加更正，不把历史段落改写成"现在时"。
5. **新增文档必须进本索引**；一次性评估、已完成的方案放 `docs/archive/` 或标 `historical`，不进"先读"路径。
6. **产品模板（`dsh/templates/*.md`）**是给用户 vault 的，不引用仓库内部路径、不承诺没有 UI 入口的动作。

## 文档清单（按类型）

### 现状与指南（动手前读这一组）

| 文档 | 是什么 | 状态 / 时效 |
|---|---|---|
| [AGENTS.md](../AGENTS.md) | 仓库维护协议：改哪里、跑什么、怎么验证、记录纪律 | current as of 0.8.3 |
| [ARCHITECTURE.md](../ARCHITECTURE.md) | 仓库结构与两个组件的数据流 | current as of 0.8.3 |
| [handoff.md](handoff.md) | 交接：文件地图（§1–2）、当前状态（§3）、用户决策（§5）、工作流（§6）；陷阱与待办已拆出 | 现状部分以本页为准 |
| [traps.md](traps.md) | 121 条历史陷阱（编号 1..121 稳定；按编号查，不要通读） | 有计数门禁 |
| [memory/README.md](memory/README.md) | 记忆知识库导航 + 当前状态表 | 2026-10-18 复核 |
| [memory/design.md](memory/design.md) | 记忆系统**当前实现规格**（层、预算、检索、写回、字段归属） | current as of 0.8.3 |
| [memory/control-panel.md](memory/control-panel.md) | 面板 / 反馈 / 验证徽标的交互规格 | 阶段 1a–1d 已实现 |
| [memory/testing.md](memory/testing.md) | QA 方法论与本机验收手册 | 随测试流程更新 |
| [env-vars.md](env-vars.md) | 环境变量唯一参考（谁读、优先级、死开关） | 有双向门禁 |
| [installation.md](installation.md) | 安装 / 冲突解决 / 卸载的用户指引 | 随安装器更新 |
| [release.md](release.md) | 发版手册与 npm 侧一次性配置 | 随发布链路更新 |
| [literature.md](literature.md) | 文献库架构与导入流程 | 随文献库更新 |
| [agent-repo-maintenance.md](agent-repo-maintenance.md) | 通用 agent 仓库维护方法；只读 §0.5 / §0.6（约 6 KB），其余与本仓库无关 | 通用参考 |

### 决策与待办（有约束力，先看状态块）

| 文档 | 是什么 |
|---|---|
| [backlog.md](backlog.md) | **唯一权威的「未做/下一步」清单**（开放项；已完成台账另存） |
| [pending-decisions-2026-10-01.md](pending-decisions-2026-10-01.md) | 重构蓝图 P1–P7 的决策台账（当前唯一干净的一份） |
| [pending-decisions-2026-09-26.md](pending-decisions-2026-09-26.md) | A/B/C 决策台账；多数已落地，仍开放 C9-A′、C10、P5-B、4 个开关 UI |
| [refactor-blueprint-2026-10-01.md](refactor-blueprint-2026-10-01.md) | 从「个人插件」到「插件家族」的重构蓝图（提案） |
| [bundle-channel-plan-2026-09-26.md](bundle-channel-plan-2026-09-26.md) | 离线通道包化方案；S1–S6 已落地，本文是设计与记录 |
| [port-and-isolation.md](port-and-isolation.md) | 为什么用独立端口、隔离边界；结论已定、3180 内嵌面板未做 |
| [settings-surfaces-2026-09-26.md](settings-surfaces-2026-09-26.md) | 三个设置面的分工查证；"6 个开关无 UI"已变为 4 个 |
| [session-scope.md](session-scope.md) | 会话范围方案；**已否决**，只作存档 |

### 记录与历史（只读；不要用它们判断"现在"）

| 文档 | 是什么 |
|---|---|
| [changelog.md](changelog.md) | 仓库级细账：每次改动的**为什么**、排查过程、实测数字（按季分文件；当前文件只放当季） |
| [changelog-2026-Q3.md](changelog-2026-Q3.md) | 上述细账的 2026-08 ～ 2026-09 历史分段（只读） |
| [handoff-section7-done-2026-10-18.md](handoff-section7-done-2026-10-18.md) | handoff §7 的已完成台账（历史，只读） |
| [CHANGELOG.md](../CHANGELOG.md) | 面向用户的发布摘要（最新在上） |
| [dsh-0.1.5-adaptation.md](dsh-0.1.5-adaptation.md) | dsh 0.1.5 / 会话 V3 的适配取证 |
| [dsh-0.1.7-adaptation.md](dsh-0.1.7-adaptation.md) | dsh 0.1.7 preset 声明机制的适配取证 |
| [dsh-0.2.0-adaptation.md](dsh-0.2.0-adaptation.md) | dsh 0.2.0 适配：接口核对、修了哪三处 |
| [dsh-0.2.1-assessment-2026-10-17.md](dsh-0.2.1-assessment-2026-10-17.md) | dsh 0.2.1 适配评估（含 P1 结论回退） |
| [dsh-native-refactor.md](dsh-native-refactor.md) | 0.7.1 的 dsh-native 分发重构（已完成） |
| [dsh-panel-research.md](dsh-panel-research.md) | dsh web 面板机制调研（2026-08 快照） |
| [design-intake-2026-09-10.md](design-intake-2026-09-10.md) | 2026-09-10 的用户问题评估；§2/§3 的否决项勿重议 |
| [design-intake-2026-09-21.md](design-intake-2026-09-21.md) | 2026-09-21 评估；**拖拽引用已移除**，§1 仅存档 |
| [project-assessment-2026-09-10.md](project-assessment-2026-09-10.md) | 2026-09-10 完整项目评估（P0 已修） |
| [coupling-assessment-2026-10-15.md](coupling-assessment-2026-10-15.md) | 2026-10-15 全插件耦合度重测（最新读数） |
| [decoupling-assessment-2026-09-26.md](decoupling-assessment-2026-09-26.md) | 2026-09-26 解耦评估（读数已被 10-15 取代） |
| [plugin-family-assessment-2026-10-01.md](plugin-family-assessment-2026-10-01.md) | 插件家族四问评估（§1 判断已被蓝图修正） |
| [lemmalog-assessment-2026-10-01.md](lemmalog-assessment-2026-10-01.md) | lemmalog 纳入评估（已否决） |
| [note-noise-and-memory-fidelity-2026-09-26.md](note-noise-and-memory-fidelity-2026-09-26.md) | 脏笔记 / AI 补全 / 记忆保真度；P1–P3 已实现，P4–P7 提案 |

### 参考与调查（写方案时查）

| 文档 | 是什么 |
|---|---|
| [memory/assessment.md](memory/assessment.md) | 两轮记忆系统评估（2026-08，历史） |
| [memory/benchmark.md](memory/benchmark.md) | 基准测试设计；零 token 探针已实现，真实 token E2E 7/8 |
| [memory/retrieval-v3.md](memory/retrieval-v3.md) | 检索 v3 设计 + GraphMemix 吸纳决策与 A/B 测量 |
| [memory/strategy-layer.md](memory/strategy-layer.md) | 策略层设计（已实现；§7.2 记候选卡计数缺口） |
| [memory/self-correction.md](memory/self-correction.md) | 纠错与确定性自维护（0.7.2 已实现） |
| [memory/obelisk-comparison.md](memory/obelisk-comparison.md) | Obelisk 对照与"保存对话"方案（引擎/UI 均已实现） |
| [memory/v2-proposal.md](memory/v2-proposal.md) | 记忆 v2 方案（控制面 1a–1d 已实现） |
| [memory/references.md](memory/references.md) | 论文/系统笔记（参考文献库） |

### 归档（历史存档，不再维护）

| 文档 | 是什么 |
|---|---|
| [archive/REFACTOR-PLAN.md](archive/REFACTOR-PLAN.md) | 早期拆分重构规划（已退役） |
| [archive/cost-benchmark-2026-08.md](archive/cost-benchmark-2026-08.md) | 一次性的成本基准（口径已停用） |
| [archive/release-notes-0.7.8.md](archive/release-notes-0.7.8.md) | 0.7.8 发布说明快照（CHANGELOG 副本） |
| [archive/release-notes-0.8.1.md](archive/release-notes-0.8.1.md) | 0.8.1 发布说明快照（CHANGELOG 副本） |
| [archive/maintainability-review-2026-09-11.md](archive/maintainability-review-2026-09-11.md) | 可维护性审查快照（一次性，2026-09-11） |
| [archive/maintainability-fixes-2026-09-11.md](archive/maintainability-fixes-2026-09-11.md) | 上述审查的整改台账（已完成） |
| [archive/user-visible-changes-2026-09-26.md](archive/user-visible-changes-2026-09-26.md) | 2026-09-26 那批改动的用户走查（不随版本更新） |
| [archive/drag-drop-design-2026-09-21.md](archive/drag-drop-design-2026-09-21.md) | 拖拽引用设计（功能已于 2026-10-18 移除） |
| [archive/drag-to-mention-progress-2026-09-25.md](archive/drag-to-mention-progress-2026-09-25.md) | 拖拽引用进度（功能已移除） |
| [archive/sidebar-performance-2026-09.md](archive/sidebar-performance-2026-09.md) | 侧栏卡顿排查的原始证据（2026-09；侧栏性能模式/皮肤改写已于 2026-10-18 删除，只作历史证据） |
| [promotion/README.md](promotion/README.md) | 宣传稿存档说明（稿件本身 gitignored，不入库） |

> 产品内嵌文档不列在这里：`dsh/templates/vault-AGENTS.md` 等是**安装进用户 vault** 的协议与模板（改它们要重建 `main.js` 并跑 `check-*`），入口看 [ARCHITECTURE.md](../ARCHITECTURE.md) 的文件地图。

## 维护流程（改完代码/文档后照做）

1. **开工前**：`AGENTS.md` §1「当前权威」→ 本页「现状与指南」→ 对应的 spec；历史与决策只在需要查证时读。
2. **改完代码**：按 `AGENTS.md` §5 记录——`docs/changelog.md` 写"为什么"（当季文件）；`CHANGELOG.md` 写用户可见变化；[`backlog.md`](backlog.md) 增删未做项；受影响的 spec 更新 `as of`。
3. **发版前**：`npm test` 全绿；版本号只改一处，其余由 `check-version-consistency` 校验；spec 的 `as of` 对齐新版本。
4. **新增/移动文档**：套下面的头部模板 → 加/改本页索引 → 跑 `node scripts/check-doc-layout.mjs`。
5. **每季度**：把已完成的评估移入 `docs/archive/`；把过长的日志按版本切分；复核本页「30 秒」段（这是唯一允许手写现状的地方，过期就改它）。

## 文档类型与头部模板

| 类型 | 用途 | 写法 |
|---|---|---|
| `spec` | 现在就是这样（实现规格） | 只写当前事实；每节带代码行号；不写历史 |
| `guide` | 怎么装、怎么发版、怎么验收 | 步骤 + 故障；命令要能直接跑 |
| `decision` | 拍板记录 | 日期、open/closed、选项、结论、supersedes |
| `record` | 历史（changelog、陷阱、已完成台账） | 只追加、不改写；带日期 |
| `index` | 本页这类入口 | 类型 + 状态 + as-of + 一句话 + 何时读 |

```markdown
> 类型：spec | decision | record | guide | index
> 状态：current as of 0.8.3 (2026-10-18) | proposal | closed | historical
> 权威范围：<这份文档唯一负责说清的事>
> 被替代：—（或 superseded by <file>）
> 核对证据：<file:line / 门禁名 / 实跑命令>
```
