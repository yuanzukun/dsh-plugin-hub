# DSH 0.2.0 → 0.2.1-rc.2 适配评估（2026-10-17）

> 类型：assessment（一次性） · 状态：historical —— P1 结论已回退，见文内更正。

> **状态：评估完成 → P2 已实施（2026-10-18）；P1 的"跟随 `workingDirectory`"结论已回退（部署前自查，见 §2 修正与陷阱 120）。**
> 本文件保留审计口径与证据；实施细账见 [`changelog.md`](changelog.md) 2026-10-18 一节。
> **基线**：`0.2.0-rc.2`（npm `latest`，上一轮适配口径）→ **目标**：`0.2.1-rc.2`（npm `next`，本机实装）。
> `0.2.1-rc.1` 正文自述"汇总自 `v0.2.0-rc.2` 以来的主要变更"，中间还有 `0.2.1-alpha.1…5`，故变更面 = 这 7 份 release notes。
> **判定口径**：**破坏** = 不改就坏；**静默失效** = 不报错但功能/声明悄悄退化；**机会** = 0.2.1 新接口；**无交点** = 逐条核对后确认用不到或上游未变。
> 证据来源：本机实装 `%APPDATA%\npm\node_modules\@deepseek-ai\dsh`（0.2.1-rc.2）+ 从 npm 拉取的 0.2.0-rc.2 tgz 基线 + 本仓库 v0.8.2 + 真 dsh 运行时探针。
> 过程证据（不随版本控制发布）：`E:\software\ss\Deepseek-Harness\._dsh021-assessment\{01..04}-*.md`（client/host/触点/运行时四份）。

> **⚠️ 2026-10-18 实机更正（用户报告）：本页"破坏性变更 0 条"不成立。**
> 0.2.1-rc.2 的 prompt variable 注册表只剩 `provider` / `model`（`dsh-agent-loop/lib/index.js:1591-1592` 是唯一注册点），**`{{cwd}}` 不再被注册**；而本仓库 preset / persona 前缀仍写 `{{cwd}}`（当时的 `dsh/preset/agent.cordis.yml`、`dsh/profile/cordis.patch.yml`）。后果是侧栏**每一轮**都在组装 system prompt 时抛 `unknown prompt variable "{{cwd}}" in section "deployment:persona-prefix"; registered variables: provider, model`，完全无法对话。
> 修法：从 persona 文本删掉 `{{cwd}}`（保留 `{{model}}`），重新生成 preset 声明、重建 `main.js`；部署后插件启动时 `ensurePresetDeclaration` 会把 profile 里的旧 GENERATED 块刷新掉。教训：0.2.1 的插值是**严格**的——文本里出现未注册变量不是降级，而是**该轮直接失败**。

---

## 0. 一页结论

| 结论 | 读数 |
|---|---|
| **破坏性变更** | **0 条** |
| **需要动手的适配** | **实际落地**：P2 × 2（兼容声明 + 文档）；P1 结论修正为**不改代码**（vault 不跟随 `cd`，见 §2）；部署仍待用户执行 |
| **运行时回归** | **25 项检查全部 ok 或环境性 SKIP/FAIL**：真 dsh 冷启动 `agent preset mounts` **26/26**（`session/create ok:true`、`/memory-panel/state` 200）、工具 schema **22/22**、shape **11/11**（用 0.2.1 自带校验器）、安装器 **176 ok/0 fail**、`--dump-config` **1411 行 / `not found` 0 / warn 0** |
| **不需要改的机制** | `ctx.fs` 8 法（含 `createIfAbsent`）· `defineTool` 全选项 · `system-prompt/assemble` · `settings.section` slot 与 `slots.inject/register` · `webServer.register` · `workspaceRegistry` · posture 4 条 patch 行 + `agent-preset-registry` 行 · preset 声明形状 · session 日志 V4 文件名/header · CLI spawn 参数与 token 正则 —— **全部逐条核对仍在** |
| **npm 通道** | `latest` 仍是 `0.2.0-rc.2`；`0.2.1-rc.2` 在 `next`。**只跟 latest 的用户本轮不受影响**，本轮是给 next 通道/尝鲜用户的适配 |

**一句话**：0.2.1 没有把插件弄坏；真正要改的是"把已经失效的兼容声明写进它真正读的字段 + 把文档从 0.2.0 更新到 0.2.1"。原判的 P1（`cd` 后锚点停在旧 vault）经部署前复核**不是缺陷而是正确语义**——记忆是工作区级的，不能跟着瞬态当前目录走。

---

## 1. 判定总表（上游变更 → 本插件）

| # | 0.2.1 变更（release notes / 实装） | 对本插件 | 动作 |
|---|---|---|---|
| 1 | 第三方插件兼容门禁**优先顶层 `engines.dsh`**，否则回退 `peerDependencies` | 门禁实际读的是 peer：本包只写了**嵌套** `dsh.engines.dsh`（`package.json:51-53`），该字段 0.2.1 全库零命中 ⇒ 走 `peerDependencies["@deepseek-ai/dsh"]=">=0.1.7-rc.2"`（`package.json:55-57`），`includePrerelease` 下接受 0.2.1-rc.2，**通过** | **P2**：把范围写进顶层 `engines.dsh`（与 peer 同值），否则声明是装饰品 |
| 2 | 子路径插件不再读独立 `package.json`（显示文本/图标须走子路径导出） | preset 行是**文件子路径** `dsh-math-memory/dsh/preset/math-memory.mjs`（`dsh/cordis.patch.yml:98`）；0.2.0 与 0.2.1 **都**解析不到 `…/math-memory.mjs/package.json`（ENOTDIR）⇒ 两版都退化为模块说明符文本，**无回归**。bundle 宿主行按包名 → `package.json.icon` + `locale/*.json` 照常生效 | **不改**（既有显示降级，修它要改成目录型导出，成本 > 收益） |
| 3 | 新增 `working_directory` 工具；会话 cwd 改为 session projection，`header.cwd` 保持原始值 | 插件两处都把 `session.header.cwd` 当 vault 锚点（`dsh/preset/math-memory.mjs:5096-5098`、`dsh/preset/note-tools.mjs:184-189`）。0.2.1 的 `dsh-base` **默认挂载** `working-directory` + `tool-working-directory`（本机 profile 组合实测有这两行），会话中途 `cd` 后注入/检索会静默锚在旧目录 | **P1**：优先读 `workingDirectory` 投影，`header.cwd` 只作 fallback（见 §2） |
| 4 | `agent-instructions` 移除逐行 `dshHome`、新增 `$DSH_AGENTS_HOME` 共享 agents 目录 | 本插件 preset 只配 `maxBytes: 65536`（`dsh/preset/agent.cordis.yml:52-55`），仍合法；vault 里的 `AGENTS.md`（`dsh/templates/vault-AGENTS.md`）仍按 workspace 链被发现 | **不改** |
| 5 | 移除运行时 invariant 插件与各包 `./invariant` 导出 | 全仓 `invariant` 仅 3 处注释/文案，无 import/无 patch 行/无 client 产物 | **不改**（零交点） |
| 6 | 工具展示 `both` 混合模式移除（仅 native/ptc） | 插件工具不设 presentation 字段；全仓 `both` 命中都在 install.mjs 注释里 | **不改**（零交点） |
| 7 | 输入区统计 `stats` 拆为 `activity` + `usage` 两个注册 ID | 插件只注册 `settings.section`（`dsh/client-panel/src/index.jsx:456`），不碰 composer dock | **不改**（零交点） |
| 8 | 新增实验性 Session 状态记录（`plugin:` 事件） | 可用来替代"文件 marker"记录每会话注入/捕获水位；属实验性 API | **P2 机会**（现在不做） |
| 9 | 插件启用/停用/卸载/更新后的依赖同步；HMR 下可替换插件可免重启 | 三条安装通道命令形态不变；"升级后必须重启"的说法在 HMR 开启时可能过严 | **P2 文档** |
| 10 | 新增 Slots：用户消息、文本/图片展示、新会话页、模型选择器、`conversation.input.model.label` | 记忆面板/拖拽引用**可以**改用原生 slot，但收益不明确（现有 DOM 方案已实测可用） | **P3 机会**（不建议本轮动） |
| 11 | 新会话预填未发送提示；恢复草稿/切换工作区保留文件、目录、会话引用 | 与插件 `drop-mention` 的"合成 `@路径` 插入草稿"可能重叠；未发现明确破坏点，但无 CI 级 DOM 契约保护 | **观察**（见 §5） |
| 12 | 插件包元信息不可读不再阻断请求；组合包详情显示来源/版本 | 本包元信息完整（`icon.svg`、`locale/{en,zh}.json`、`dsh.bundle.patch`），不触发该降级路径 | **不改** |
| 13 | pi-ai `^0.87.1→^1.1.0`、Azure 提供方更名、API Key 优先级、CLI `--public-url`/TLS、`--from-default-profile` 语义 | profile patch 不触模型面；Obsidian spawn 的 `--profile/--patch/--no-open/--port 0` 全部仍有效且插件未用被改语义的 flag | **不改**（零交点） |
| 14 | 依赖面 6 个包由 dependencies 移入 devDependencies（其中 4 个物理不存在） | 插件 profile 引用的 6 个包全部仍在；但本机已摘除的 `pretooluse-guard` 曾依赖 `dsh-hooks-claude-code`，该包 0.2.1 已不存在 ⇒ 那个守卫机制不能按原样恢复 | **记录**（与插件无关） |
| 15 | 自定义插件索引源、插件市场、按需组合包 | 与 `docs/bundle-channel-plan-2026-09-26.md` 的"插件可见性"路线有交集，是分发机会 | **P3 机会** |

---

## 2. P1（**结论已修正：不改代码**）：会话中途 `cd` 不改变 vault

> **部署前复核修正（2026-10-18）。** 下面"建议修法"（跟随 `workingDirectory` 投影）曾在提交 `ce2e2c9` 落地，
> **随后整体回退**。理由：`session.header.cwd` 是"**会话创建时**的工作目录"，`workingDirectory` 只是"当前目录"；
> 上游 README 明说"当前目录消失时…恢复到**原始项目**"——原始项目 = 工作区。本插件的 vault 是**工作区级**的
> （历史会话归属 `isVaultSessionLog` 也按日志头 `header.cwd` 判定），若跟随投影，`cd` 进 vault 子目录会把
> **子目录**当 vault（`.deepseek/` 找不到 ⇒ 注入退化成"未配置"），`cd` 到别处更会换库——比"停在原 vault"更糟。
> 另外 Obsidian 侧启动**总是**注入 `DSH_OBSIDIAN_VAULT`（`obsidian/main.template.js:1689`），而 env 优先级高于
> 会话 cwd，侧栏模式根本不受 `cd` 影响。结论与教训见 [`handoff.md`](handoff.md) 陷阱 120；细节见
> [`changelog.md`](changelog.md) 2026-10-18 一节。**下面保留原始审计文字（便于追溯第一版为什么判错），
> 但"修法"已作废。**

**上游事实（0.2.1，读码 + 本机实测）**

- 新服务 `workingDirectory`：cwd 存在 session projection（键 `workingDirectory`，初值 `header.cwd`），`working-directory/change` 事件更新；`get(session)` 直接读投影。`session.header.cwd` **不被改写**。
- 新工具 `working_directory`（`cd` 参数）由 `dsh-base` 的 patch **默认插入**（本机 `--dump-config` 实测第 109-112 行有 `working-directory` + `tool-working-directory`）；0.2.0 的 base 没有这两行。
- 因此"会话 cwd 在整场会话内不变"——插件写在 `math-memory.mjs:5096` / `note-tools.mjs:186` 的假设——首次有了被打破的入口。

**影响**：会话起点在 vault 内、中途 `cd` 到别处后，记忆注入与 `note_*` 仍锚在**原 header.cwd**：继续读写旧 vault（静默指错目录）；起点在 vault 外则永远找不到 vault（静默降级为未配置）。不报错、无日志。面板侧不受影响（走 `workspaceRegistry`，`dsh/host/math-memory-panel.mjs:260,381`）。

**条件性**：本 preset 自己没声明 `tool-working-directory`，该工具是否真的出现在 preset agent 的工具面取决于 preset 的 realm 隔离语义（本轮未用真模型会话证实）。但修复本身是**纯增量 + 有 fallback**，成本低，建议先做。

**建议修法**（**已作废 2026-10-18，未保留代码**：vault 是工作区级锚点，见本节开头的修正块。原方案曾落到 `note-tools.mjs` 的 `effectiveSessionCwd()`，已随 `ce2e2c9` 之后的修正提交整体回退）

1. `dsh/preset/math-memory.mjs` 的 `resolveWorkspaceRoot` / `sectionForAgent` 与 `dsh/preset/note-tools.mjs` 的 `resolveVault`：解析顺序改为
   `config.vaultRoot → DSH_WORKSPACE_ROOT / DSH_OBSIDIAN_VAULT → ctx.get("workingDirectory")?.get(session) → session.header.cwd`。
   0.2.0 上没有 `workingDirectory` 服务 ⇒ `ctx.get` 返回空、自然回落到 `header.cwd`，不需要版本分支。
2. 两处引擎各自持有一份解析（`preset` 与 `host`），改的时候按仓库纪律同步 `check-engine-sync` 的共享清单；`note-tools` 的 `resolveVault(ctx, exec, config)` 已经拿得到 `ctx`，把 vault 解析改成接收 ctx 即可。
3. 补一条断言（`scripts/test-agent-preset.mjs` 或 `test-memory.mjs`）：伪 session 的投影 cwd 与 header.cwd 不同时，锚点取投影值；再做一次变异验证（把解析改回只读 header.cwd ⇒ 该断言必须红）。

**验收**：一次真会话（或等价的程序化 session）里 `cd` 后调用 `note_recall`，断言命中新目录/vault 判定正确；成本是一次工具调用，不需要大批 token。

---

## 3. P2：声明、文档与部署

### 3.1 兼容声明（**已实施 2026-10-18**）

- 现状：`package.json:51-53` 的 `dsh.engines.dsh` 在 0.2.1 **不会被任何门禁读**；真正生效的是 `peerDependencies`。0.2.1 首次真的开始读**顶层** `engines.dsh`（`dsh-app-boot/lib/index.js:280-285`），声明存在时**忽略 peers**。
- 实施：范围已写进顶层 `engines.dsh` 并与 `peerDependencies` 同值保留；物化清单（`local-bundle.mjs`、`main.template.js`）也同时写两处；两条门禁断言同值。⚠️ **不要借机把范围收紧成 `>=0.2.0` / `^0.2.0`**——prerelease 运行时不匹配，插件会被静默跳过（陷阱 112 的原始教训仍成立）。

### 3.2 文档要更新的事实（本轮审计已发现三处过时）

| 位置 | 过时内容 | 应改为 |
|---|---|---|
| `README.md:55` / `README.zh.md:55` | "已在 `0.2.0-rc.2` 上实测" | 追加"`0.2.1-rc.2` 已实测（2026-10-17）" |
| `docs/handoff.md:543`、`docs/dsh-0.2.0-adaptation.md:225` | "dsh.engines.dsh 是生态惯例，门禁不读它（全库对 engines.dsh 零命中）" | 0.2.1 起**顶层 `engines.dsh`** 会被门禁读；嵌套 `dsh.engines.dsh` 仍不读 |
| `docs/installation.md:110,132,209` | "升级后必须重启 dsh" | 0.2.1 + HMR 默认开启时通常免重启（替换失败/禁用 HMR 才需要）；未实测前可写成"通常" |

（`check-version-consistency.mjs:157` 也写着旧结论，改文档时一并处理。）

**实施状态（2026-10-18）**：上表三处均已更新；`check-version-consistency.mjs` 与 `check-plugin-manifest-meta.mjs` 改为断言顶层 `engines.dsh` 与 peer 同值。`dsh.engines.dsh` 已从 `package.json` 移除（生成物里改为顶层 `engines.dsh`）。

### 3.3 部署滞后（环境问题，非上游）

本机真实 profile 的 bundle 仍是 `dsh-math-memory@0.7.8`（`.dsh-math-memory` 0.8.0），仓库已是 0.8.2。评估结论基于**仓库 0.8.2** 在隔离真 dsh 冷启动中的表现（`self-provisioned profile` 10/10），**不是**真实部署的热更新验证。若要在 Obsidian 侧栏吃到本轮结论，需要重装/重新引导一次。

---

## 4. 明确不改（防止为"适配"而适配）

| 项 | 为什么不动 | 证据 |
|---|---|---|
| `ctx.fs` 8 个方法 | 名称/形状/`createIfAbsent` 全在 | `dsh-fs/lib/types/types.d.ts:111-113` 等 |
| `defineTool` 选项（`presentCall`/`output.render`/`isConcurrencySafe`） | 逐项仍在 | `dsh-tools` 定义区 |
| `system-prompt/assemble` + `context.agent` | waterfall 与 `{agent,scope,signal}` 未变 | `dsh-system-prompt`、`dsh-agent` |
| `settings.section` + `slots.inject/register` | 0.2.0→0.2.1 的 `SlotRegistry` 类型定义 **Compare-Object 零差异** | `dsh-client-ui-renderer/lib/types/client/registry.d.ts` |
| posture 4 条 patch 行 + preset registry 行 | 全部仍命中，`--dump-config` **not found = 0** | 运行时探针 §6 |
| preset 声明形状 | `{id,name,description,order,plugins}` 未变 | `dsh-agent-preset` |
| session 日志文件名/header | `session[.vN].jsonl.zstd`、`header.cwd` 必填未变 | `dsh-session-format`、`dsh-session` |
| CLI spawn 参数 | `--profile/--patch/--no-open/--port 0` 全在；token 仍是 `?token=` + base64url | `dsh/lib/bin.js`、`dsh-web-app` |
| 面板鉴权/路由 | 引擎未变；本轮环境性 SKIP 已如实记录，不当作通过 | 运行时 findings §7 |
| `stats`/`invariant`/`both`/`dshHome`/`pi-ai`/`Azure`/API Key/TLS | 逐条零命中或无交点 | 四份 findings 的 grep 记录 |

---

## 5. 观察项：拖拽引用（drop-to-mention）与 0.2.1 的输入框改动

> **⚠️ 已关闭（2026-10-18）**：拖拽引用功能已按用户决定整体移除，本节观察项不再需要人工回归；
> 下文保留为当时的评估记录，代码引用（`drop-mention/composer-drop.mjs`）已不存在。

0.2.1 对输入框做了多项改动（命令与参数边界、新会话预填、恢复草稿/切换工作区保留文件、目录、会话引用）。插件的拖拽落笔依赖两个**未被上游承诺的** DOM 事实：`[contenteditable="true"]` 是唯一输入面；宿主 composer 自己消费合成的 `ClipboardEvent('paste')`（`dsh/client-panel/src/drop-mention/composer-drop.mjs:106-128`）。

- 静态核对未发现破坏点（0.2.1 的 `dsh-client-ui-conversation` 仍有 28 处 `contenteditable`、含 `insertFromPaste` 分支），但这条路径没有 CI 级保护（e2e 探针按需才跑），"合成 paste 仍被消费"没有真宿主证据。
- 建议：本轮不改实现，只把"0.2.1 输入框改动后需人工回归一次拖拽"记进 `docs/handoff.md` §7；若后续要做，用 `conversation.input.*` 新 slot/引用能力替代 DOM hack 是更稳的方向，但不是必须。

---

## 6. 运行时证据（本机，dsh 0.2.1-rc.2）

| 检查 | 结果 | 分类 |
|---|---|---|
| `dsh --version` / `--help` / `web --help` / `plugin --help` | `0.2.1-rc.2`；6/6、7/7 flag 在；exit 0 | ok |
| `--dump-config`（隔离副本） | exit 0、1411 行、`not found` **0**、warn 0；posture 4 行 + `agent-preset-registry` 全命中；bundle/preset 行在 | ok |
| 真 dsh 冷启动 + `session/create`（agent preset mounts） | **26/26**，`ok:true`、preset `notes-assistant`、`/memory-panel/state` 200 | ok |
| 工具 output schema / shape | **22/22**、**11/11**（用 0.2.1 自带 `dsh-tools` 校验器） | ok |
| 安装器（三通道） | 176 `[ok]` / 0 fail；`self-provisioned profile` 10/10 | ok |
| bundle freshness / profile contract / rebuilds / preset 声明 | 全 ok | ok |
| panel auth e2e | **SKIP 0/0**（环境禁止子进程写真实 home） | 环境，**不算通过** |
| panel routes | **68/69**（唯一红 = 沙箱禁止写 `D:\notes`；服务端锚定逻辑正确） | 环境 |
| 真实 `~/.dsh` 文件 | 前后 sha256 零字节改动 | ok |
| 兼容门禁合成探针 | 顶层 `engines.dsh` 优先、嵌套被忽略；真插件经 peer 被接受 | 上游行为变化，无回归 |

> 环境性 SKIP/FAIL 均按 `AGENTS.md` §4 分类，未用改断言的方式"修绿"。完整输出见 `._dsh021-assessment/04-runtime.md`。

---

## 7. 仍未验证 / 需用户拍板

1. **P1 已结案（不改代码）**：vault 锚点保持 `config → env → 会话创建目录`，"跟随 `workingDirectory`"的方案已回退（§2 修正、陷阱 120）。不需要再验证 `tool-working-directory` 是否可见——即使可见，语义上也不应改变 vault。
2. **Obsidian 实机侧栏**：本轮未启动 Obsidian、未重装真实 profile（0.7.8→0.8.2 的部署是用户动作）；面板/拖拽的实机回归待部署后做。
3. **客户端半**：`dsh.client.inject` 的三个包名在 0.2.1 安装树中仍存在，`window.__ModuleLoader__.load({id, factory})` 产物契约也仍在（`dsh-client-modules/lib/index.js:18,463`）；但 rc.1 的"依赖同步"是否把该字段变成解析目标**未核实**，当前不下"必改"结论（详见 `._dsh021-assessment/01-upstream-client-ui.md`）。
4. **pi-ai 模型 ID 可服务性**：需真 API 请求，按仓库纪律不擅自跑。
5. **是否发布新版本**：本轮是评估，不动版本号、不打 tag、不发布；`[Unreleased]` 也先不写，等实施时按 `docs/release.md` §5 补。

---

## 8. 复现入口

```powershell
# 0) 版本面
dsh --version                                                    # 0.2.1-rc.2
node -e "console.log(require('./package.json').version)"         # 0.8.2

# 1) 组合是否仍命中（零 token）
dsh --profile notes-assistant --dump-config | Select-String 'not found|math-memory|preset-notes-assistant'

# 2) 关键门禁（用 0.2.1 自带校验器 / 真 dsh 冷启动）
node scripts/run-gates.mjs --only "agent preset mount"   # 26/26
node scripts/run-gates.mjs --only "tool output schemas"  # 22/22
node scripts/run-gates.mjs --only "tool output shape"    # 11/11
node scripts/run-gates.mjs --only "installer"            # 176 ok

# 3) 本轮新增事实的定点取证（读 0.2.1 实装）
#    顶层 engines.dsh 优先：dsh-app-boot/lib/index.js:276-298
#    working_directory 默认挂载：dsh-base/cordis.patch.yml:166-170；dsh-working-directory/lib/index.js:30-40,76-78
#    子路径不读 package.json：dsh-app-boot/lib/index.js:2199-2223
```

## 9. 关联文档

| 文档 | 用途 |
|---|---|
| [`dsh-0.2.0-adaptation.md`](dsh-0.2.0-adaptation.md) | 上一轮（0.1.7-rc.2→0.2.0-rc.2）结论；本文接续 |
| [`dsh-0.1.7-adaptation.md`](dsh-0.1.7-adaptation.md)、[`dsh-0.1.5-adaptation.md`](dsh-0.1.5-adaptation.md) | 更早两轮的机制迁移 |
| [`handoff.md`](handoff.md) §4/§5/§7 | 陷阱、决策、未做清单（实施时在此追加） |
| [`changelog.md`](changelog.md) | 实施时追加"为什么" |
| 上游 | [v0.2.1-rc.1](https://github.com/deepseek-ai/deepseek-harness/releases/tag/dsh-v0.2.1-rc.1)、[v0.2.1-rc.2](https://github.com/deepseek-ai/deepseek-harness/releases/tag/dsh-v0.2.1-rc.2) |
