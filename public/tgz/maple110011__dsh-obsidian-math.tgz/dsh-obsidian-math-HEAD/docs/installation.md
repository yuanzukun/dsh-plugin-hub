# 安装 / 卸载 / 冲突解决指引

**只想安装的用户**看 README 的 A/B/C 三种方式；本文件解释它们底下的三条实现通道（native bundle / 安装器 / `--direct` 离线拷贝），三者产出的配置等价。

本文是给**用户**看的使用指引：讲清安装原理、三条实现通道、冲突解决功能怎么用、卸载怎么用。内部设计规格见 [`dsh-native-refactor.md`](dsh-native-refactor.md)。

## 0. 一句话原理

dsh-math-memory 由**两层**组成，安装方式不同：

- **能力层（bundle）**：preset「数学笔记助手」、笔记工具、记忆引擎、面板路由、工作区自动注册。这一层用 dsh 原生命令 `dsh plugin` 安装，**符合 dsh 设计理念**。
- **姿态层（posture）**：fail-closed 沙箱、审批策略、权限表、默认 preset、工作区根目录。这一层是「部署姿态」，由安装程序写入 profile 的 `cordis.patch.yml`。

> 一句话：**能力走 `dsh plugin`，姿态由安装程序落盘。** 因为「能力」是可复用的插件，「姿态」是这台机器/这个用户的部署选择，二者不该混在一个可复用包里。

## 1. 安装方式

### 方式 A：把 bundle 加进已有 `web` profile（只装能力）

```bash
dsh plugin --profile web add dsh-math-memory
```

把我们的 bundle 加进**已存在**的 `web` profile（它自带 in-box 的 dsh-base + dsh-web-app）。bundle 自带的补丁层会往 profile 里插一条宿主行和一条 preset 声明，preset 的模块按**包内路径**解析（包已在 `profile/node_modules` 里），所以什么都**不需要**在启动前先落盘。装完后**重启 dsh**，新建会话即可在预设选择器里看到「数学笔记助手」。

> 这种方式**不会**把它设为默认预设——默认预设由 profile 自己的 `cordis.patch.yml` 里 `agent-preset-registry` 那行的 `default` 决定，只有专门的 `notes-assistant` profile（方式 B / C / Obsidian 插件）才会写它。在 `web` 里请在新建会话时手动选。旧文档说的"同步进 `~/.dsh/.agent-presets/`"自 dsh 0.1.7 起已不成立（那个目录**不再被写入**，只在找不到 profile 安装清单时作为**兼容回退**被读——见 §3 与 `dsh/host/channel-owner.mjs`）。

**注意**：`@deepseek-ai/dsh-web-app` 是 dsh 的 **in-box bundle**（随 dsh 安装自带），**不能** `dsh plugin add`（会去注册表拉一个版本对不上的副本）。新建专用 profile 请用方式 B（安装程序会写骨架），方式 A 只适合往已有 `web` profile 里加 bundle。方式 A 也**没有** fail-closed 沙箱（沿用 web 的沙箱）。

> ⚠️ **实测症状（2026-09-26）**：把它加到 dsh 新建的**自定义** profile（例如 `dsh plugin --profile myprobe add …`）时，`add` 会成功、`bundles` 也写对了，但启动日志只说一句
> `dsh: warning: 2 entries did not activate`（`math-memory-host … pending (waiting for services: webServer, workspaceRegistry)`、`preset-notes-assistant … pending (waiting for service: agentPresets)`），**并且永远不会打印 token 地址** —— 那个 profile 没有 web 栈。要用方式 A 就加到已有的 `web`；要新 profile 请走方式 B。
> 可复现探针：`node scripts/qa/release-accept.mjs`（临时 `DSH_HOME`，不碰你的真实环境）。

### 方式 B：安装程序（能力 + 姿态 + 模板，CLI/npm 用户）

```bash
dsh-math-memory install --vault /path/to/你的Obsidian库
```

内部依次做：调 `dsh plugin add` 装能力 → 写 profile 姿态 → 写 owner marker → 种 vault 模板（`AGENTS.md` + `.deepseek/**`）。这是**完整**安装，需要 pnpm + 网络。

### 方式 C：离线安装（优先本地包化，失败才平铺）

```bash
dsh-math-memory install --direct --vault /path/to/你的Obsidian库
```

**A′（2026-09-26）之后，这条通道默认会先试着"包化"**：把本插件**物化成一个真正的包**放进 profile 的
`.dsh-math-memory/`，再用 `dsh plugin add file:<绝对路径>` 装进 profile —— 这一步**不联网**（`file:` 规格不查
registry，实测 `downloaded 0`），装成的包因此**会出现在 dsh 的「插件管理」页**并可启用/禁用/移除。

- **需要的东西**：`dsh` 与 `pnpm` 在场。**任一不在、或装完核验不通过**（核验看的是文件系统：包目录存在
  **且**名字在 `dsh.profile.bundles` 里，不看退出码）⇒ 自动回落到**平铺**（方式 C 的旧行为），并**明确打印`
[fallback]` 与原因**，不静默。
- **想强制走旧的平铺形态**：加 `--flat`（输出的成功行会写清是哪条通道赢了，`status` 也是这条通道的唯一真相）。
- **离线承诺的变化**：之前写的是"**不需要** pnpm / 网络"；现在是"**优先**不联网地包化，`dsh`/`pnpm` 不在时
  回落平铺"。**平铺通道本身没有消失**，无 pnpm 的机器仍然可用。

平铺形态把随包发布的 preset/profile 文件直接写进 `~/.dsh`，并写同样的 owner marker。功能与方式 B 等价，差别在
**能力怎么送达**：方式 B 由 bundle 的补丁层声明 preset（模块走包内路径），平铺形态把 preset 的模块
**命令式落盘到 profile 目录**、并在 `--patch` overlay 里用相对路径引用它们（这两条都在 dsh 启动前完成，所以
不存在"第一次启动来不及"的问题）。

### Obsidian 插件安装

Obsidian 插件**内置直写流程**（等价于方式 C 的 `--direct` 逻辑，因为插件必须离线可用、不依赖 node/pnpm），并写同样的 owner marker。三种方式功能等价，靠 owner marker 避免互相覆盖。

### 三种方式在 dsh「内置插件 → 插件管理」页里的可见性不同（2026-09-26 实测）

那一页列的是**包**，不是行。它的数据来自 dsh 自己的 `dsh-plugin-manager`：

```
names = dsh.profile.bundles ∪ profile.dependencies ∪ installation.dependencies
```

而且只有清单里声明了 **`dsh.bundle.patch`** 的包才会带版本号/描述/行列表被列出来（否则只在"被选中"时以 `not-bundle` 问题项出现）。

| 安装方式 | 那一页里看到什么 |
|---|---|
| **方式 A**（把 bundle 加进 profile） | ✅ 能看到 `dsh-math-memory`，带版本、描述、它声明的行，可启用/禁用/移除 |
| **方式 B**（安装程序，native） | ✅ 同上（B 内部就是 `dsh plugin add dsh-math-memory`） |
| **方式 C / Obsidian 插件**（离线通道） | **取决于它实际走了哪条路（A′ 之后）**：**包化成功** ⇒ ✅ 能看到（与 A/B 一样，因为内部就是 `dsh plugin add file:<本地目录>`）；**回落平铺** ⇒ ❌ 看不到（平铺形态只把模块铺进 profile 目录，没有包名/版本/`dsh.bundle.patch`，那一页没有可列的东西）。**怎么分辨**：`dsh-math-memory status` 会显示当前是哪条通道，安装结束的成功行也会写明。 |

**回落形态（平铺）不是缺陷，但它确实不由 dsh 的包管理器托管**：那条路存在的意义就是"`dsh`/`pnpm` 不在时也要能用"。那种情况下**离线通道的启用/禁用/卸载在 Obsidian 插件的设置页里做**，CLI 侧用 `dsh-math-memory uninstall`。

对照：用 `dsh plugin add` 装进去的第三方包（例如 `@linxin666/dsh-client-ui-skin-center`）**会**出现在那一页 ✓。

> **A′ 已落地（2026-09-26）**：让离线通道也"包化"曾是一份提案，现在 S1–S5 已实现 —— 离线通道默认先试包化、
> 失败回落平铺并明确报告，`--flat` 可强制旧形态。计划与实测见 [`bundle-channel-plan-2026-09-26.md`](bundle-channel-plan-2026-09-26.md)。

### 让主 dsh web（3080）也有笔记助手模式与记忆面板

默认只有专用 profile（`notes-assistant`，Obsidian 侧栏用）会被插件铺好；主 `web` profile 里
**看不到"数学笔记助手"模式、也没有记忆面板**——因为引擎/preset/面板路由来自我们的 bundle，而客户端
半个是单独装的。想两侧通用：

```bash
# ① 引擎 + preset + 面板宿主路由（bundle 通道；装进 web 即成为该 profile 的一个 bundle）
dsh plugin --profile web add dsh-math-memory

# ② 面板的客户端半个（安装器会把 loader 行插进 web 自己的 cordis.patch.yml —— 那一层没人重写）
node dsh/install.mjs install --profile web
```

> ⚠️ **`--profile web` 不能省。** 这里此前写着 `dsh-math-memory install --native`，而 `--native` 这个
> flag **不存在**：`install.mjs` 的参数解析没有它、也不报错（未知参数被静默忽略），于是命令会退回默认
> profile `notes-assistant`，把客户端半个装进**侧栏那个 profile**，而 `web` 依旧没有面板——正好是本节
> 想解决的反面，而且全程没有任何提示（2026-09-26 查文档时发现并删掉）。

三点注意：

- **通常需要重启 3080 那个 dsh**（bundle 列表在启动时读）。0.2.1 起 HMR 开启时替换包可能免重启，但失败或缺 HMR 时仍会提示重启；重启会断开当前页面连接。
- **0.7.8 及更早不要用**：它们是 0.1.7 适配之前的形态，bundle 补丁里**没有 preset 声明** ⇒ 装完
  3080 里不会出现笔记助手模式（实测）。**0.8.0（2026-09-27 发布）起已修**；若还在旧版上，可临时用本地目录
  `dsh plugin --profile web add file:<仓库绝对路径>`（会在该 profile 的 `package.json` 留下
  `file:` 依赖，仓库挪位置后要重装）。
- **客户端半个只能装一份真宿主**：`web` 装了 bundle 之后，bundle 的行**已经**注册
  `/memory-panel/*`，所以客户端包里必须是**空宿主半**（安装器现在会自动这样判；两份真宿主会让整个
  profile 以 `duplicate prefix route` 起不来）。
- **数据是共享的**：记忆在 vault 的 `.deepseek/memory/**`，两侧用同一个 vault 就是同一份记忆；
  3080 侧第一次用面板前，先让它有一个以该 vault 为工作区的会话，下拉里才会出现它。

### 装进已有 `web` profile？

可以，但会**失去 fail-closed 沙箱**（沿用 `web` profile 自己的沙箱策略）。安装程序检测到非专用 profile 时会打印醒目警告。想保证安全边界，请用专用的 `notes-assistant` profile。

## 2. 升级

```bash
# 能力层升级（preset/工具/引擎/面板）
dsh plugin --profile notes-assistant update dsh-math-memory
```

升级后**通常重启 dsh 即可**（0.2.1 起 HMR 开启时替换包可免重启；无法热重载时会提示，重启一定生效）：preset 是 bundle 补丁里的一行声明，随包升级自动生效（离线通道则由安装器/插件引导把新版模块覆盖进 profile 目录——它们是代码不是配置，每次都覆盖）。vault 模板属于「种子」，只在 `install` 时种一次、之后归用户，升级不会覆盖你改过的模板。

## 3. 冲突解决怎么用

系统在多个位置写入时，用 **owner marker（归属标记）** 判定所有权，避免两条通道（`npm` bundle vs `direct` 直写）互相覆盖。owner 取值只有两个：`npm`（bundle 通道）和 `direct`（`--direct` 或 Obsidian 内置直写）。**标记文件是 profile 自己的 `~/.dsh/profiles/<profile>/.install-manifest.json`**（三条安装方式都写它，守卫优先读它）。

旧的 `~/.dsh/.agent-presets/notes-assistant/.owner.json` 已**退役**（2026-09-26）：不再被任何通道写入，只在 profile 清单缺失时作为**兼容回退**被读取（这样 2026-09-26 之前装的那份仍会被认出来，而不是被另一条通道静默接管）；`uninstall` 会把它连同那个目录一起清掉。原本只有它一个锚点，于是"清理这个没人读的死目录"会**静默废掉**这层保护——这也是它被迁走的原因。

**先诊断：**

```bash
dsh-math-memory status
```

会列出：bundle 是否登记、preset 同步状态、姿态是否在位、当前 owner 是谁、vault 模板清单。

**遇到「归属冲突」报错时：**

```
[conflict] profile notes-assistant is owned by "direct" (manifest, v0.7.0) — pass --force to take over as "npm"
```

（示例：括号里是 `manifest` 或 `legacy`，即归属来自 profile 的安装清单还是退役的 `.agent-presets` 标记；版本是该次安装记录的版本。出现这行时命令以 **exit 1** 结束。）

意思是：之前用 `--direct`（或 Obsidian 内置直写）装的（owner=direct），现在又用 bundle 装（owner=npm）。**这是保护，不是故障**。两个选择：

- **切回原通道**：用回之前那套（direct / Obsidian）继续维护，不要混用。
- **切换到新通道（接管）**：确认后加 `--force`：

  ```bash
  dsh-math-memory install --force
  ```

  `--force` 会重写 marker，把所有权接管到 npm 通道，之后以 npm 包为准。

**双向保护**：这套拒绝是双向的——`--direct`/Obsidian 直写遇到 owner=npm 会拒绝；bundle 在启动时同步遇到 owner=direct 也会跳过并告警。任何一方都不会静默覆盖另一方的安装。

**patch 写在哪**：本系统**不写**全局 `$DSH_HOME/cordis.patch.yml`，只写 **profile 自己的** `$DSH_HOME/profiles/<profile>/cordis.patch.yml`（fail-closed 沙箱/审批/preset 声明；给 `web` 装客户端半个时也插进 `web` 自己的那一层）。该文件是 dsh 与用户也会写的**共享层**，所以 `uninstall` 不做"摘除自己这一块"的块级编辑：它只删安装清单里登记、且与安装时摘要一致的**安装器自有文件**，共享文件（`cordis.patch.yml` / `package.json` / `cordis.yml`）无条件保留（实现见 `dsh/install.mjs` 的 `commandUninstall` 与 `POSTURE_SHARED_FILES`）。

## 4. 卸载怎么用

```bash
dsh-math-memory uninstall            # 先看计划，不做任何改动（默认 dry-run）
dsh-math-memory uninstall --yes      # 执行「自动删」级别
dsh-math-memory uninstall --purge --yes          # 加删脚手架模板
dsh-math-memory uninstall --purge --purge-data --yes   # 加删记忆内容（需确认短语）
```

卸载按「**可重建性**」分三级：

> **记忆默认保留**：卸载**不会**删除你的记忆内容（records/topics/theorems/templates/episodes/strategy 卡片、inbox、archive 等），除非你**显式**加 `--purge-data` 并输入确认短语 `DELETE MY MATH MEMORY`。不传 `--vault` 时 `.deepseek/**` 完全不被触碰。

| 级别 | 内容 | 何时删 |
|---|---|---|
| 自动删 | bundle 登记、同步出的 preset 副本、机器缓存 `.deepseek/cache/**`、工作区注册 | `--yes` |
| 骨架 | `index.md`、`_README.md`（纯索引骨架，重装可逐字重建） | `--purge` |
| 内容 | `AGENTS.md`、`profile.md`、`notation.md`、`capture-policy.md`、`config.md`、`working.md`、records/topics/theorems/templates/episodes/strategy 卡片、`inbox/*.md`、`archive/**` | `--purge-data` + 输入 `DELETE MY MATH MEMORY` |

**安全设计**：

1. 默认 dry-run：不带 `--yes` 时只打印「将删 / 将保留」清单，不写任何东西。
2. 记忆内容（不可重建）只有在 `--purge-data` **且**输入确认短语 `DELETE MY MATH MEMORY` 时才删，删除前会提示你先备份。
3. 执行结束打印三份清单：**已删 / 已保留（列路径）/ 需手动**（如 Obsidian 插件本体，交给 Obsidian 自己禁用/卸载）。

示例输出（**示例**：实际行随已装通道 / profile / vault 内容而不同；诊断当前状态用 `dsh-math-memory status`）：

```
$ dsh-math-memory uninstall
[dry-run] pass --yes to execute (default is a plan only).
[run] dsh plugin --profile notes-assistant remove dsh-math-memory
[dry-run] would remove <DSH_HOME>/.agent-presets/notes-assistant
[dry-run] would remove <vault>/.deepseek/cache
[keep] vault skeletons (use --purge): .deepseek/**/index.md, _README.md
[keep] memory content (use --purge-data): AGENTS.md, profile.md, notation.md, cards, inbox, archive, ...
[keep] profile dir <DSH_HOME>/profiles/notes-assistant (use --purge to remove)
[memory] KEPT — memory cards/inbox/archive under .deepseek/ were left untouched. Use --purge-data to delete them.
Obsidian plugin: disable/uninstall it from Obsidian's own settings.
```

## 5. 常见问题

- **装完看不到「数学笔记助手」preset？** bundle 在 dsh 启动时才同步 preset，`dsh plugin add` 后请**重启 dsh**（0.2.1 起热重载可能已生效，重启仍是最稳的做法）。
- **`status` 显示 owner 是 direct，我想改用 npm？** 见 §3，用 `install --force` 接管。
- **只想删缓存、保留所有记忆？** `uninstall --yes`（只动「自动删」级别，记忆内容默认保留）。
- **卸载会删我的笔记吗？** 不会。本系统只管理 `.deepseek/**` 下的记忆文件与模板；你的普通笔记（`.md`）从不被安装/卸载触碰。记忆内容也只在 `--purge-data` + 确认短语时才删。
- **为什么装能力用 `dsh plugin`、装姿态要用安装程序？** 见 §0 与 [`dsh-native-refactor.md`](dsh-native-refactor.md) §2：`dsh plugin` 是 dsh 原生的 bundle 安装通道；「种安全姿态」这类部署操作 dsh 没有原生命令，只能由安装程序落盘。
