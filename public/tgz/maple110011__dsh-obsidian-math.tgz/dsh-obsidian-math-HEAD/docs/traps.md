# 陷阱库（从 handoff §4 拆出）

> 本文件是仓库历史陷阱的**唯一清单**（编号 1..121 稳定：加新陷阱只追加，不改旧号、不跳号）。
> 数字由 `scripts/check-doc-counts.mjs` 从本文件的 marker 行与编号里数出并校验；改动前按编号查，**不要通读**。
> 原位置：`docs/handoff.md` §4（2026-10-18 拆分，只搬家不改写）。

## 4. 必须知道的坑（勿重蹈覆辙）

> 陷阱条数：121

**为什么这里要写一个数字**：别的文档（`AGENTS.md` §1/§6）要引用"这个仓库有多少条历史陷阱"。**手写的数字会腐烂**——它曾长期写着「69 条」而实际已到 81，读者无法判断该信哪一份。现在这个数字是**机器可读的单一事实源**：`scripts/check-doc-counts.mjs` 从本节的编号里数出真值，比对这一行、以及其它引用它的文档；任一处对不上就红。**加一条陷阱 = 同时改这一行**（改完跑那条守卫即可知道自己漏没漏）。

1. **本机 `fs.cpSync` 会原生崩溃**（0xC0000409）。任何脚本用「手动遍历 + copyFileSync」。
2. **Obsidian 1.13.7 视图生命周期有 `open(containerEl)` 方法**——ItemView 子类**不得**定义 `open/close/load` 同名方法。
3. **vault 索引排除点号路径段**（`.deepseek` 对 Obsidian API 不可见）：面板用 node fs 读取 + 预览 Modal，不能 openLinkText/TFile。
4. **Obsidian 1.13.7 的 Notice 构造不调 setMessage**——抓 toast 用 DOM MutationObserver。
5. **插件 id `dsh-math-assistant` 是稳定标识、永远不要改**——Obsidian 按 `.obsidian/plugins/<目录名>/` 加载插件，manifest `id` 必须等于目录名；改 id 会让已有安装插件「消失」。有 `check-plugin-id` 守卫。
6. **notes profile 默认不挂载 `@linxin666` UI 插件**——皮肤中心（`ui-skin-center`/`ui-web-ui-settings`）是可选的，由 Obsidian 设置「启用皮肤中心」在运行时追加进 `notes-assistant.patch.yml`（仅在存在 web profile 可镜像时）。若有人把 `@linxin666` 挂载加回 `cordis.patch.yml` 会 boot 崩（`check-skin-fallback` 会拦：挂载必须在降级块里被禁用；`cordis.patch.yml` 当前是 0 挂载）。（**2026-10-18 复核：opt-in 皮肤中心与「启用皮肤中心」设置已删除——皮肤只在主 dsh web，Obsidian 侧栏不追皮肤；本条前半「notes profile 不挂载 @linxin666」仍成立**。）
7. **插件 bootstrap 每次加载强制刷新** `math-memory.mjs/note-tools.mjs/.../notes-assistant.patch.yml`（overwrite=true）——机器本地手改这些文件会被冲掉，改动必须进仓库。
8. **防护必须双端接线**：给 loopback 端点加 CSRF/权限校验时，必须同步更新注入给模型的链接模板（`t=`）；只改端点不改模板 = 点击闭环静默断裂。
9. **缓存语义变更必须带版本**：`cache/dialogue-index.json` 按指纹复用；任何过滤/配对语义变化都要 bump `schemaVersion`（现为 2）。
10. **fallback 写入必须抵抗刷新**：`notes-assistant.patch.yml` 每次加载 overwrite 刷新；运行时追加的机器本地块要在 `ensureObsidianPatch` 里提取重放。
11. **dsh web 客户端插件契约**（已核对 `@linxin666/dsh-client-ui-*` 类型）：`window.__ModuleLoader__.load({id, factory})`；`factory(require)` 内自建 `var module={exports:{}}`、`var exports=module.exports`，末尾 `return module.exports`；导出 `inject` + `apply(ctx)`；`ctx.inject([...deps], (scope)=>...)`；槽注入 `scope.slots.inject('settings.section', () => scope.slots.register({name,id,order,label}, Component))`；清理用 `ctx.effect(() => disposer, name)`；宿主路由 `ctx.webServer.register({kind:'prefix'|'exact', path, handler})`。`settings.section` 的显示名字段是 **`label`**（不是 `title`/`locale`），否则节无名。
12. **web profile 客户端装配是显式名单**：`profiles/web/package.json` 的 `dsh.profile.bundles` 聚合 + `cordis.patch.yml` 里 insert 包名。新增客户端包必须跑 `install-into-profile.mjs` 把包名 insert 进 patch，否则不加载；目录不会被自动扫描。
13. **面板 = 宿主半 + 客户端半**：宿主插件（`dsh/host/math-memory-panel.mjs` 的 webServer 路由）+ 客户端插件（`dsh/client-panel/` 的 React 壳）**两半都要装进同一 profile** 才成面板。
14. **`DSH_BIN=dsh` 是 shell shim**：e2e/脚本要传真实 JS 入口 `.../node_modules/@deepseek-ai/dsh/lib/bin.js`，否则 service 早期退出 code 1。
15. **dsh web 长会话 OOM**：本机曾 `JavaScript heap out of memory`（fetch ECONNRESET 表象）。启动加 `--max-old-space-size`（本机 4096）+ `--no-open`，boot 失败把 cause 写进日志再断言，别只报 code。
16. **面板前端 fetch 空 root**：`root` 为空时 fetch 会拿到 SPA HTML（`<!doctype`）导致 `Unexpected token '<'`。root 输入 + localStorage（`dsh-math-memory.panelRoot`）守卫；工作区列表走 `GET /memory-panel/workspaces`。
17. **本机有两个 dsh 安装**：Obsidian 插件 `dshInstallDir` 可能指向非 npm 全局的 dsh（如 `E:/software/deepseek-harness/dsh` v0.1.0-rc.6），其 dsh-web-frontend bundle 与 npm 全局版（v0.1.1-rc.2）文件名与渲染器变量都不同。前端补丁必须同时改写 `new URL(u).protocol` 与 `new URL(s).protocol` 两种写法；排查「补丁未命中」先看插件 `data.json` 的 `dshInstallDir` 到底指向哪个 dsh。
18. **乱码 workspace 会话目录会让 dsh 崩溃**：`$DSH_HOME/sessions/` 里若出现含 `~FFFD~`（Unicode 替换字符）的乱码目录，dsh 0.1.1-rc.2 在 session identity 校验时报 `corrupt session log` 并 boot 失败。把乱码目录移出 `sessions/`（备份，勿直接删）即可恢复。
19. **dsh ≥ 0.1.5：一个会话可能有多份日志**（每次格式升级都保留旧代原件）——V2 → V3 迁移生成 `session.v3.jsonl.zstd`、V3 → V4 生成 `session.v4.jsonl.zstd`，都**保留**原件，同目录长期共存；新会话只写最新一代，`version` 字段在头行（`0`/`2` = 旧，`3` = V3，`4` = V4）。⇒ 任何"扫 `$DSH_HOME/sessions`"的代码都必须**按会话去重并取最新世代**（`sessionLogKey` + `selectAuthoritativeLogs`：`artifactGeneration` 先比 `vN` 世代号，mtime 只作同代兜底），否则同一个会话会被计两次/索引两次，**或者（更隐蔽）一直读旧代导致新轮次永不落盘**——2026-09-25 实测本机 2 个会话目录 v3+v4 并存且 V4 更新，旧的"显式优先 `.v3.`"判据正是这样选错的（见 `docs/dsh-0.1.7-adaptation.md` §4.2）。旧版本文档里的 `findSessionLogs` 平铺夹具（`s1.jsonl.zstd`）也已改为真实 `<session-id>/session.jsonl.zstd` 目录布局。
20. **V3 里没有逐块流事件**：`assistant/chunk` / `reasoning-chunks` / `text-chunks` / `tool-call-chunks` 在 V3 中不再存在（内容进 `assistant/message.data.stream[]`），事件量显著变小。依赖"逐块事件"的任何新逻辑在 V3 上会静默拿不到数据。—— 以上两条的完整取证见 `docs/dsh-0.1.5-adaptation.md`。
21. **`String.replace(a, b)` 的 `b` 是替换"模板"不是字面量**：agent 写的 frontmatter 里 `$$`／`$&`／`$'`／`` $` `` 会被展开（`title: 关于 $$ 的表示` → `关于 $ 的表示`；`$&` 把整段 frontmatter 注入标题）。写文件的代码一律用 `replaceFrontmatter`（按偏移量拼接）或 `replace(x, () => y)`；同一个坑 `scripts/build-obsidian.mjs:57-59` 早有注释记录。
22. **空 frontmatter（`---\n\n---\nbody`）是合法输入**：`replace("", x)` 会在偏移 0 **插入**而非替换，把收尾 `---` 推到文件中间——而调用方仍收到 `{ok:true}`。写入器一律走 `frontmatterSpan` 定位。
23. **loopback 不是授权边界**：`/memory-panel/*` 的旧实现在 `127.0.0.1` 之上再无校验，而**任意网页**都能用 `content-type: text/plain` 发 CORS 简单请求（无预检）打到它。现在靠三件套：root 只在重启述 profile 的 vault、非 loopback `Origin` 拒绝、有 token 的实例强制 token。**改这些路由时不要削弱任何一件**——`scripts/test-panel-routes.mjs` 会在拆掉守卫时立刻失败（变异验过）。
24. **插件内嵌的那份 `memory-admin.mjs` 才是 Obsidian 里真正跑的代码**：改 `dsh/host/memory-admin.mjs` 后**必须** `node scripts/build-obsidian.mjs`，否则 `check-embedded-writers.mjs` 会以 `main.js embeds the current …` 失败拦住提交（这条守卫补上了"旧 embedded-loader 守卫比对的是自己那份名单"的漏洞）。
25. **验收必须跑在"已部署"的代码上**：本轮实施时首轮 live 验收跑在还没部署修复的 profile 上，把真实 vault 的 `临时.md` 归档了一次（已复原、时间戳不变）。跑 destructive 验收前先确认 `$DSH_HOME` 里的副本与仓库一致（`deploy-local`，或显式比对哈希）。
26. **dsh ≥ 0.1.5：裸 root 一律 401，界面只能通过带 token 的启动地址打开**。token 只出现在子进程 **stdout**（`--no-open` 时不会进浏览器），插件必须流式抓取并让 iframe 加载该地址（303 会顺手种下 `dsh-auth-<sha256(host:port)>` cookie）；cookie 绑定 `host:port`，**换端口即失效**。探测必须三态（`ready`/`unauthorized`/`down`）——把 401 当"健康"正是侧栏显示 401 文本页却报"服务就绪"的原因。回归见 `scripts/test-panel-auth.mjs`。
27. **`probeService` 这类依赖 Node 内建模块的 helper 必须放进嵌入 loader 的 body 里**：`new Function` 求值的代码**没有**模板作用域的闭包，所以 `http` 要在 `new Function` 的参数表里注入、函数在 body 内定义、再经 `return {…}` 白名单导出。直接写在模板里会 `ReferenceError`（只有 Obsidian 运行时才会炸）。
28. **dsh 的会话 cookie 是 `SameSite=Strict`，Obsidian 的 iframe 永远拿不到它**——这是"抓到 token 但界面仍 401"的真正根因。iframe 的顶层站是 `app://obsidian.md`、框架是 `http://127.0.0.1:3180`，**跨站**；`SameSite=Strict` 的 cookie 在这种导航/子请求里既存不下也用不上。**解法是让插件在主进程里做反代**（`DshWebProxy`）：代理解析启动行里的 token，**以"公共权威"（用户配置的端口）**兑换出 cookie 并保存，然后给每一个转发请求注入 `cookie` 与 `host`；dsh 自己退到 `--port 0` 的内部端口。**两条不能改**：(a) 代理必须监听用户配置的那个端口（cookie 名是 `dsh-auth-<sha256(host:port)>`，端口一变 cookie 名就变）；(b) 转发时必须把 `host` 改写成公共权威（`requestAuthority` 取 `Host`），否则 cookie 名对不上。另外 Node 的 `fetch` **忽略**调用方传的 `host` 头（forbidden header），要指定权威必须用 `http.request` + `setHost:false`。回归：`scripts/test-panel-proxy.mjs`（15 项，stub 上游）+ `scripts/test-panel-auth.mjs`（7 项，**对真实 dsh**）。
29. **探针绝不能自己复刻打分公式**：两个 QA 探针曾各自手抄一份 `0.85*BM25 + 0.10*cjk`，而产品是 `0.75*BM25 + 0.10*cjk + 0.15*hookPrior`，且探针从不调用 `isRecallEligible`——**权重改了三个月没人发现，纠错机制等于没有回归网**。现在产品管线抽成 `buildRecallDoc` / `rankRecallDocuments` / `rankStrategyCards`，任何新探针/新测试都必须调用它们，**不要**在测试里重写评分。
30. **导航索引（`episodes/index.md`、`theorems/index.md`）对任意中文查询都有高覆盖率**（它列出所有条目标题），因此**不能**用它的 coverage 判断"库里有没有答案"——弱信号判据必须落在内容文档上。它在排序上已按 kind 降权（`episode-index` 0.4、`theorem-index` 0.7），但仍留在语料里（它是"这里有什么"的地图）。
31. **正则里的 `\s` 会吃掉换行**：`parseEpisodeIndex` 的分隔符原写成 `(?:\s*[—–-]\s*(.*))?$`，于是 `- [[a]]` 的下一行 `- [[b|标题]] — 主题` 被当成**同一行**的续写——`a` 的 `topic` 变成下一行的整条链接。行内分隔符一律用 `[ \t]`（`scripts/test-memory.mjs` §30 钉住了这一点）。
32. **面板的「空状态」判据必须覆盖所有层**：旧判据只看 4 层，于是只有主题/策略卡的 vault 被判成"记忆库还是空的"；而真实 vault 里它又几乎永不触发（episodes 被自动捕获填满），第一次使用的人只看到一堆事件文件名。改判据时同步改两个面板。
33. **回执是功能的一部分**：dsh web 面板的 `run()` 原本丢弃响应体——点 ✅/❌/归档 界面上什么都不发生，而唯一显示的 `success=` 对真实卡永远是 `—`。**任何写操作都必须把宿主返回的 `message`/error 显示出来**，否则用户无法区分"生效了"和"点了没反应"。
34. **`last_not_applicable` 没有读取方**（全仓库 grep 只有写入点）。加新的 frontmatter 字段时，必须同时指出**谁读它**；写而不读的字段会在 UI 上表现为"看起来像 ❌、实际零效果"，比没有这个选项更糟。
35. **真实 vault 里这套反馈机制从未被使用过**（2026-09-10 全库普查：`last_wrong`/`needs_review`/`last_not_applicable`/`status: superseded`/`verified: user-confirmed`/`success_rate` 全为 0，🔁 字符 0 个，`.deepseek/archive/` 不存在，3 张真实卡全是 `single-source` 且无 `success_rate`）。**"没人用"本身就是最强的信号**：先怀疑入口（文案/回执/位置），再怀疑机制。
36. **版本号不是发布**：Obsidian 的更新只认「**tag 等于 `manifest.json` 版本的 Release**」。当时 0.7.2–0.7.4 从未推过 tag ⇒ 用户端永远停在 0.7.1，表现为"商店里看不到新版本"。发版步骤见 `docs/release.md`；`check-version-consistency.mjs` 钉住五处版本号（package / manifest / lock / versions.json / CHANGELOG）。
    - **⚠️ 更正（2026-09-15）**：本条原文还写着「本插件**不在** `community-plugins.json` 里」并把它当作"看不到新版本"的原因之一。**那句是错的**——插件早已在架，收录方式已改变、`community-plugins.json` 不再是收录依据（详见坑 78）。"版本号不是发布"这个结论仍然成立，成立的理由只有 tag 那一条。
37. **面板是两半，生效方式不同**：宿主半（`math-memory-panel.mjs` + `memory-admin.mjs`，装在 `profiles/web/node_modules/@dsh-math-memory/…`）**由 dsh web 进程启动时加载** ⇒ 换新要**重启 dsh web**；客户端半（`client.js`）是页面加载时取的静态文件 ⇒ **刷新页面**即可。两者之间存在"新客户端 + 旧宿主"的窗口，所以客户端必须给每个字段兜底（`{ rel:'', topic:'', … , ...card }`），否则会渲染出字面量 `#undefined`。
38. **旧缓存（audit schema v1）要能降级渲染**：v1 的 `memory-audit.json` 只有 `report` 字符串，没有 `human`/`sections`/`decisions`/`today`。面板不能因此说"还没有体检记录"，也不能把模型清单原样摊开——`normalizeAuditForPanel` 会从 v1 遗留的 `pendingReview`/`archiveCandidates`/`passive`/`generatedAt` 合成 `sections`/`decisions`/`today`，`legacyAuditSummary` 合成人话摘要；下一次体检写回新格式后自动失效。
39. **跨皮肤写样式只能用各皮肤都保证存在的 token**。dsh web 面板的次级文字原本用 `--dsw-alias-label-dimmed`，而用户当前皮肤 `orca-link` **只定义 `primary/secondary/tertiary/caption`** —— 该变量不存在，`color` 声明在计算值阶段失效、颜色回退到继承值。表现是"浅色文字看不清"，真因是"这条样式根本没生效"。现在统一用 `var(--dsw-alias-label-secondary, var(--dsw-alias-label-tertiary, …))`。Obsidian 侧同理：`--text-faint` 换成 `var(--text-muted, var(--text-faint))`。**改面板配色前先确认皮肤里有没有这个变量**。
40. **侧栏只有 ~340px，卡片必须纵向排布**。观察到的"标题看不出内容"有一半是布局问题：四个动作按钮（`✅ 确认`/`❌ 有错`/`过期`/`归档`）本身要 235px，元信息又占 60%，单行 `nowrap` 布局下标题与摘要各只剩 ~50px（约 4 个汉字）。现在每张卡四行、各占满一行（标题/摘要/元信息/动作），元素改回 `flex: 1 1 auto` 或 `max-width: 60%` 就会退化回去——用 headless Chromium 量过（316/400/500/700/900px 五档，摘要都在标题下方且不溢出）。
41. **卡片摘要必须跳过"记账行"**：真实 vault 里导航层卡片的正文首行是 `- 标签：#…`，而 `strategy/strat-ot-structure-proof.md` 里有两行**游离在 frontmatter 之外**的 `uses: 0`（早期写入缺陷留下的，已于 2026-09-10 清理）。按"取正文第一行"直接做摘要会得到"标签：#…"和"uses: 0"。`summaryOf` 因此跳过 YAML 形状的行与一组中文记账前缀，并且**只认文件开头那个 frontmatter 块**。
42. **"后来才长出来的东西"要回头比对所有枚举消费点**（2026-09-10 专项审计的元结论）。按轴搜出 6 处真实缺陷：归档目的地/索引写死 `records`（策略卡会误归档 + 该层索引悬空）、web 面板 sessionCapture 勾选与引擎相反（缺失键=OFF 而面板用 `!== false`）、文档说 sessionCapture 默认开而实际默认关、注入的"分层长期记忆"说明停在五层（没有 templates/strategy）、AGENTS.md 三写第 3 步清单漏了 `strategy/`、本机 `deploy-local.mjs` 只部署 8/19 个模板。**新增一个层/动作/开关时固定要问：谁枚举了它的兄弟？**（归档目的地、索引、注入段、设置页、面板、模板清单、文档表、测试都算）。三处判定为有意为之并写明理由：体检只扫 records/templates/strategy、`structural` 只对 records 生效、`notation.md` 按普通笔记进检索语料。
43. **"追加 frontmatter 字段"的助手也会写到块外**：`syncTopLevelStatsToCard` 把**含首尾 `---` 的整块**传给了只认"行"的 `setTopFieldText`，于是没有 `uses:` 行的策略卡被追加到**闭合分隔符之后**（正文里），而且每次体检再加一行——`strategy/strat-ot-structure-proof.md` 里那两行游离 `uses: 0` 就是这么来的（2026-09-10 定位并修复）。**规则**：追加字段前先把块拆成「分隔符 + 内容 + 分隔符」，只在内容里拼接；写完**读回验证**（这次正是读回验证抓到的，见坑 44）。
44. **"写完就当成功"是最容易复发的缺陷形态**（2026-09-10 一天内 4 个 bug 全是它：安装脚本 no-op、归档非卡、面板显示开启而引擎关闭、体检建议归档它刚归档的卡）。现在体检的每处确定性写入都**返回布尔 + 读回核对**，`status: "degraded"` + `warnings` 会写进人话摘要与模型清单。**新加写入路径时必须照此办理**，否则它会静静地不生效（上线当轮它就抓出了坑 43）。
45. **`uses` 是「声明值 + 未合并增量」**：`cache/retrieval-stats.json` 是**增量**（体检合并进 frontmatter 后清零），不是总量。面板显示 `uses`（有效值）并另给 `usesDeclared`/`usesPending`；只看 frontmatter 会在两次体检之间少报，只看 stats 会以为计数丢了。
46. **检索不要做通用「去冗余 / 多样化」**：GraphMemix 的冻结候选控制实验里 MMR/DPP 类目标不优于朴素 top-k、净回收为负（−6 / −36）；有用的是**已验证的关系**（`related`/`source` 顺链，+43）。这条已写进 `AGENTS.md` §5，避免以后凭直觉加惩罚项（见 `docs/memory/references.md` §12）。
47. **`not_applicable_when` 现在门控检索**：查询命中边界短语 → 该卡不进候选、但在结果里单独列出「因适用边界被排除」（**不静默丢弃**：静默假阴性比误召回更难发现）。匹配按标点拆出的 ≤12 字短片段做子串包含，所以**要写成短句/关键词列表**——整段散文会被拆碎、门控不准。
48. **`verified_by` 是验证等级的凭据**：只有用户点 ✅ 时由插件写 `user`；❌ 把等级留在 single-source 之上时会写 `none` 作废旧确认；体检把「等级高于 single-source 却没有凭据」列为越权升级（**只报告、不自动改**——自动改写可能覆盖用户手改）。
49. **iframe 内的 `backdrop-filter` 看着很贵，实测不是卡顿来源**（第一轮的错误结论，保留作教训）：皮肤 `orca-link` 在侧栏区域盖了一层 `:before { inset: 0; backdrop-filter: blur(10px) }`，第一轮据此推断「跨帧毛玻璃让宿主动画每帧重算模糊」并上线了 CSS 注入。**用户复测仍然卡**，随后用 CDP 做对照实验：把皮肤 CSS **全部**移除后，6 次真实点击的帧数据**一点没变**（3→4 帧 >50ms、最差 84→83ms、RecalcStyle 1172→1165ms）。教训：**「看起来贵」不等于「测得出贵」**——先 A/B，再改代码（`docs/memory/sidebar-performance.md` §2/§4）。CSS 注入保留（代价为零），但别再把功劳记在它头上。
50. **★ 侧栏卡顿的真因是皮肤的客户端脚本 `hooks.mjs`**（同一个皮肤在 Obsidian 侧栏与 3080 都在跑，所以两边一起卡）：它注册约 14 个 subtree MutationObserver，有一个约 5 次/秒改 `DIV.orca-ch-statusCharacterSprite` 内联样式的角色循环，还有一个 ResizeObserver 跟着侧栏动画**每帧**触发（读布局 → 写 body 级 CSS 变量 → 翻 `body[data-orca-sidebar-wide]`）。停用该模块：帧 >50ms 从 3 → **0**，最差帧 84 → **33ms**，LoAF 8 → **0**。处置：代理改写该模块的两处热循环（默认，装饰保留），或换成空实现（可选设置，最流畅）。
51. **给转发响应加 `content-length` 时必须同时删掉 `transfer-encoding`**：dsh 的 HTML 走 chunked，注入改写后如果两个头并存，客户端直接判协议违规（`Content-Length can't be present with Transfer-Encoding`），现象是**打开侧栏就白屏**。这个缺陷是 `test-panel-proxy.mjs` 的 stub 上游抓到的（真实 dsh 也是 chunked，所以它一定会发生）。
52. **注入只能在未压缩响应上做**：dsh 只要客户端声明 `accept-encoding: gzip` 就压（实测 28884 → 4388 字节）。所以 **HTML 注入通道**（2026-10-18 起只剩笔记链接拦截器）的改写路径必须 (a) 只对**导航请求**去掉 `accept-encoding`，(b) 见到 `content-encoding` 就原样透传，(c) 没有 `</head>` 就原样透传。三条都进了回归。
53. **改写第三方模块必须「锚点全中才改、否则原样返回」**：皮肤 `hooks.mjs` 的补丁按宽松正则匹配两处锚点，任一缺失就返回原文并写日志——皮肤更新后补丁失效是**降级**，绝不能变成「皮肤崩了」。
54. **渲染线程上的同步文件 IO 会被当成"界面卡"**：`writeDebugLog` 原用 `appendFileSync`，由 `render()` 调用（启动日志实测 7 ms 内 3 条）。改成队列 + 250 ms 异步批量追加；卸载时 flush 一次。同类：记忆面板搜索框曾**每次按键**重扫整个 vault（`collectMemoryState` 是同步扫盘），现在 220 ms 防抖 + 显式按钮走 `renderNow()`。
55. **挂起 iframe 必须能自愈**：`display:none` 挂起（侧栏收起/切标签页）能省下整个 guest 的渲染，但判据一旦误判就是"面板永远空白"。两条保险：只认无歧义信号（祖先 `display:none`、容器矩形为 0、`isShown()===false`），且**挂起期间每秒自检**（只在挂起时跑）——漏事件不会永久黑屏。
56. **★ 守卫必须容忍"这个套件在本机不跑"**：`check-doc-consistency.mjs` 会真的运行各套件并解析它们的 `__CHECKS__` 行，而 `test-panel-auth.mjs` 在没有本地 dsh 时**按设计 SKIP**（CI runner、任何新克隆都是这种情况）——于是守卫把"没有 `__CHECKS__` 行"判成失败，并把文档里写的 7 项认证断言与凭空得到的 0 相比。**这个缺陷让 0.7.5 的第一次 tag 发布在 CI 上挂掉，而本机全绿**。现在 `runSuite(rel, { optional: true })` 识别 SKIP 并返回 null，认证锚点只报告不比较；其它套件缺 `__CHECKS__` 仍然算失败。教训：**任何"在 CI 上不跑"的套件都要在守卫里显式声明**。
57. **★ 守卫必须容忍 CRLF**：CI 是双平台（ubuntu + windows），Windows runner 检出的是 **CRLF**。两个嵌入守卫用多行字面量/逐字节比较解析文本，于是 Windows 上分别报「appended loader helper is unterminated」与「main.js 里的 memory-admin 是旧版」——**Linux 全绿**。修法：读入即 `replace(/\r\n/g, '\n')`（`build-obsidian.mjs` 早就这么做了，所以嵌入体本来就是 LF 形态），比较时两侧都归一化。复现方法：`git -c core.autocrlf=true archive <commit> | tar -x` 得到一个 CRLF 检出（本机验证过 `npm test` 现在 exit 0）。
58. **`npm publish` 失败时日志什么也不说，而且旧的 2FA-bypass token 路线正在被 npm 关掉**：0.7.5 的 Release 与 npm 是两条独立流水线——Release 成功（GitHub Release + 4 个资产），npm 那条在 `Publish` 步失败（前面 6 步全过）。npm 对「token 缺失/过期/无发布权/需要 2FA」一律只给非零退出码。**方向已定：改用 trusted publishing（OIDC），不要再造长效 token**——[2026-07-08](https://github.blog/changelog/2026-07-08-npm-install-time-security-and-gat-bypass2fa-deprecation/) 起 2FA-bypass 的 granular token 已不能做账号/包管理，[2026-07-31](https://github.blog/changelog/2026-07-31-restricting-npm-bypass-2fa-granular-access-tokens/) 明确约 **2027-01 起连直接发布也不能**。因此 `npm-publish.yml` 现在：① 不设 `NODE_AUTH_TOKEN`；② 显式 `npm install -g npm@11`（trusted publishing 要求 ≥11.5.1，Node 22 自带 npm 10；**钉 11 不钉 12**——npm 12 默认不跑依赖 lifecycle 脚本，会静默跳过 esbuild 的 `postinstall` 二进制下载）；③ publish 前加一步只读诊断（npm 版本 / `ACTIONS_ID_TOKEN_REQUEST_URL` 是否存在 / `whoami`）。**剩下的是一次性人工动作**：npmjs.com → 包 `dsh-math-memory` → Settings → Trusted Publisher → GitHub Actions，填 `maple110011` / `dsh-obsidian-math` / workflow 文件名 `npm-publish.yml`（**environment 必须留空**——job 未声明 environment，claims 里没有该字段，填了就必然 403）；配完在 Actions 页面对失败的那条 run 直接 **Re-run failed jobs**（不必重新推 tag）。**2026-09-11 已全通**：用户配好 Trusted Publisher 后 re-run 成功，`dsh-math-memory@0.7.5` 上线（`latest`，带 SLSA provenance）。两条由此得来的教训写进 `docs/release.md` §2：**退出码 0 ≠ 已发布**（staged publishing 要人工批准）、**退出码非 0 ≠ 未发布**（重复推同一 tag 会报 `cannot publish over the previously published versions`，现在算成功）；判断成败一律看 registry 实际状态（workflow 里 `Confirm the registry state`），并据此自动关闭历史失败 issue。另：**本机代理会缓存 registry 文档**，排查时通过它查询会看到过期的 `modified` 与 404。
59. **★ 受限环境禁止「管道 stdio」，而一条 `&&` 链会把它伪装成回归**：在禁止子进程管道 stdio 的环境里（本机沙箱、部分 CI 容器），node 进程**无法**通过管道 spawn 另一个 node 进程——`spawnSync` 直接返回 `error.code === 'EPERM'`，`stdout` 为空。后果有二：① `npm test` 的 `&&` 链在第 5 个门禁（auth e2e）断掉，**静默跳过其后 16 条命令**，于是"红了"不携带任何关于其余门禁的信息；② `check-doc-consistency.mjs` 拿到空输出、把计数读成 0，报出 **18 条"文档漂移：文档写 232、实际 0"**——而文档全是对的，**照它去改就会把正确的文档改错**（这才是真正的损失）。修法两条：`scripts/run-node.mjs` 把子进程 stdio **重定向到真实文件描述符**而不是管道（两种环境都能跑且照样捕获输出；实测 `pipe → EPERM / stdout=undefined`，`file fd → status 0 / 输出完整`）；`scripts/run-gates.mjs` 一次跑完**所有**门禁再汇总，失败不再吞掉后续门禁，并把"子进程根本没起来"单独标成环境结果。**判断"红"之前先问：这是代码的问题，还是运行环境的问题？**
60. **★ 仓库内的模板文件名不要叫 `AGENTS.md`**：`dsh/templates/AGENTS.md` 是**要安装进用户 vault 的教学协议**，但 agent harness 只要在仓库里读到 `AGENTS.md` 就会把它当成"**本仓库**的指令"自动注入——实测仅仅读取该文件，就被注入约 200 行"你是本 vault 的数学学习伙伴"，其中还含与仓库维护**直接冲突**的硬约束。修法：源文件改名 `dsh/templates/vault-AGENTS.md`，**安装后的名字仍由 `templates-manifest.json` 映射为 `AGENTS.md`**（build / install / 插件引导三条路径都是按 `source → target` 遍历，所以只需改清单 + 一处漂移断言）；同时补上仓库根 `AGENTS.md` 作为维护协议。**推论**：凡是"面向别人家仓库/目录的指令文件"，都不要在源仓库里占用会被自动发现的文件名。
61. **★ `__CHECKS__` 的分母必须由套件自己数，不能手写常量**：`test-panel-proxy.mjs` 写死 `EXPECTED_CHECKS = 31` 而实际执行 **32** 个断言；`test-panel-auth.mjs` 打印 `7 - failed`/`7` 而可达断言是 **8** 个（9 个调用点里一个在 else 分支）。文档锚点盯着这些自报数，于是**把错的数字抄进了 5 处文档**，而"全绿"只是**算术**而不是覆盖证据。修法：计数放进 `check()` 内部（`total += 1`），末尾打印真实值；`check-doc-consistency.mjs` 的锚点随之被修正。
62. **★ 安全边界要锚在服务端自己的状态上，且"未配置"分支必须有测试**：`/memory-panel` 的约束根一度在**两个环境变量都没设**时退回"请求里带的 `root`"——于是下游 `pathInside(root, target)` 两端都由调用方决定，形同虚设；而套件在它之前的**每个**用例都先设了环境变量，恰好绕过这条分支。修法：允许的根 = 环境变量 ∪ `ctx.workspaceRegistry`，**两者都空则拒绝一切带 root 的请求**；补"未配置 + 空注册表 → 403 且文件未被移动"的用例。**变异验证**：把旧逻辑还原，新用例立刻失败且报 `status: 200`（即真的把卡移走了）。
63. **版本横幅会静默腐烂**：`handoff.md` 写着"版本 0.7.2"而仓库已在 0.7.5，`design.md` 停在"v0.6.x 实现规格"——读者（人和 agent）无法判断文档落后了几个版本，也无法判断该信谁。修法：活文档加**精确标记行**（版本号独占一行）：

   ```
   > 当前版本：0.7.5
   ```

   由 `check-version-consistency.mjs` 与 `package.json` 比对。**用精确标记而不是宽松正则**，是为了不把"0.1.5 adaptation""0.7.2 时…"这类**历史引用**误判成关于当下的声明。
64. **★ 审计报告本身也会过期：照它删代码之前，先自己确认"真的没人读"**：本轮落地一份审查报告时，报告点名 `math-memory.mjs:1294` 是"把写入失败直接吞掉且不留计数器"——实测该处**已经**记录 `statsResetFailed = true` 并进入 `warnings`（报告写于更早的 HEAD，或当时判断有误）。同一轮核对还有两个方向的教训：`RETRIEVE_TARGETS` 确实**零读取方**（删），但它被 `strategy-layer.md` 当作"内核枚举"引用，所以**删它必须同时改文档**，否则那句"改常量就能加取值"的假承诺会随代码一起消失而无人知晓；`pathIsInside`/`pathInside` 是**同名盲区**——两者的名字不同，于是"比对同名符号"的守卫**看不见**这一对，删/改任何一个都不会有提示。**规则**：报告是**线索**不是**事实**——每条"这是死代码"先 grep 全仓（**含 docs**），每条"这里吞了错误"先读现场。核对成本几分钟，误删/误修的成本是一次真实故障。**推论**：写守卫时要想清楚"用什么特征配对"——按名字配对就会漏掉改了名的重复实现。
65. **★ 同一份逻辑的多份拷贝，"能不能 import"决定了修法；守卫该按语义配对而不是按名字/文本**：frontmatter 的边界正则曾被复制 **15 次**、散在 6 个解析器里（P1-6），而它是坑 21/22/43 三次数据损坏的共同根因。看起来"抽成一个模块、全改调它"就够了，但**宿主树根本不能 import**：Obsidian 插件是用 `new Function(params, body)` 求值 `memory-admin.mjs` 的，靠注入绑定、不解析 import。硬凑成一份就要改 loader 的注入契约，风险大于收益。所以最终形态是**一份规范 + 一份必要拷贝 + 一条证明两者行为等价的守卫**。三条推论：① **配对依据是"守卫要防哪种分歧"**——`check-engine-sync.mjs` 防的是同名符号漂移，所以比词法流；这里两份实现的注释与风格本来就不该强求相同，必须相同的是"它认为块在哪"，所以比 **13 个 fixture 上的行为**。② **守卫要放过文档**：只扫代码、跳过注释行，判据是"**运行时能不能与另一个副本分歧**"，否则它会把自己解释规则的注释和引用它的文档一起判违规（第一版守卫就这样误报了 4 处）。③ **要动没人测的路径，先给它加测试**：`hook-frontmatter.mjs` 在插件里的求值路径（剥 `export {...}` + `new Function`）当时**零覆盖**，而这轮正要把它的导出从 3 个改成 9 个、还变成多行——先补 `check-embedded-loader.mjs`（含"真的解析一个 hook 块"）再动代码。
66. **★ 用脚本按行拼接 CRLF 文件：`split("\n")` + `join("\r\n")` 会产生 `\r\r\n`**。读文件用 `[System.IO.File]::ReadAllText` 再 `-split "\`n"`，每个元素**末尾仍带 `\r`**；拼回去时若用 `join("\r\n")`，被保留的那些行就变成 `\r\r\n`（本轮重编 `CHANGELOG.md` 的 `[0.7.5]` 节时踩到，325 行中招）。最阴的地方是**它看起来是对的**：文件照样能读、`check-version-consistency` 与 `check-doc-consistency` 照样通过（守卫都按 `\r?\n` 切分，多出的 `\r` 被当成行内容），但 .NET 的 `ReadLine` 会把那个多出来的 `\r` **当成一次换行**，于是 `Select-String` / `Get-Content` 报出的**行号整体偏移**，让人误判"拼接错位/内容丢了"。**修法**：拆分后 `TrimEnd("\`r")` 再拼，或整文件 `Replace("\r\r\n", "\r\n")` 收尾；**验收**：`[regex]::Matches($raw, "\r\r\n").Count` 必须为 0，且 `(?<!\r)\n` 也为 0（不引入混合行尾）。同族坑见坑 57（守卫必须容忍 CRLF）——那条讲读，这条讲写。
67. **★ grep 会跳过点目录，所以「全仓 grep 过」不等于「真的全仓」**：本轮做文档漂移排查时，`grep dsh.web.ui` 报 28 处、没有 `scripts/qa/benchmark-vault/.deepseek/config.md`；而新守卫直接 `readdirSync` 走文件系统，**立刻报出这一处**——它在一个 `.deepseek/` 目录里（被 grep 工具默认忽略的隐藏目录），而且是 **git 跟踪的文件**（`git check-ignore` 退出码 1）。同一份排查还漏不掉别的：`.github/`、`.vscode/`、任何 `.*` 目录都在 grep 的盲区里。**规则**：要声称"全仓没有 X"，用**自己遍历文件系统的守卫**，不要用 grep；排查阶段的 grep 只用于**定位**，不用于**证明不存在**。**推论**：写这类守卫时要么显式遍历（含隐藏目录），要么把"跳过了哪些目录"打印出来——静默跳过会让守卫和 grep 犯同一个错。
68. **★ 断言/守卫「看起来在工作」的两种形态：读了一个从未赋值的变量 / 前置条件永远不成立**。审查 P3 点名过这一类（"守卫看起来在工作、实际条件失效"），本轮修掉两个真实实例：
    - **① 读了一个从未赋值的变量**：`check-embedded-loader.mjs` 的 `loaderCall()` 算出了偏移 `at`，却写成 `return { params, args, fnAt }` —— 返回的是模块级那个**还没赋值**的 `let fnAt`。于是 `lastIndexOf(marker, undefined)` 按规范等价于**从模板末尾往回搜**，守卫永远校验**最后一个** allowlist，而不是注释里写的"最近的前一个"。**今天正确纯属运气**：memory-admin 的 loader 恰好排在最后；再加一个 loader，它就会去校验**错误的名单**而照样打印 OK。修法：`return { …, fnAt: at }`；并把提取函数**参数化**（`text = template`）以便自测——往合成模板末尾再接一个 loader，断言取到的仍是 memory-admin 的名单。**变异验证**：把 `fnAt: at` 改回 `fnAt` → 自测立刻失败并报出根因（"returned a non-integer fnAt (undefined) … the `fnAt` bug is back"）。
    - **② 前置条件永远不成立**：`test-installer.mjs` 的 `check('vault cache removed', !existsSync(vault/.deepseek/cache))` —— 安装器**从不创建**该目录，夹具里也没有 ⇒ 这条断言**恒真**，把它删掉或注释掉都不会有人发现。修法**不是删掉断言，而是让前置条件成立**：夹具先建出 `.deepseek/cache/captured-sessions.json`（真实 vault 跑过插件后就是这样），再断言 `--purge` 删掉它。修完立刻证明这个行为**确实实现了**（安装器日志打出 `[remove] …\.deepseek\cache`）——也就是说这条断言过去既没保护代码、也没保护文档承诺。
    - **判据（写完任何断言/守卫都问两句）**：「**它读到的东西真的被赋过值吗？**」「**让它失败的那个输入真的可能出现吗？**」两句都答不上来，这条断言就是装饰。同族：坑 44（写完就当成功）、坑 56（守卫把"没跑起来"当成失败）。
69. **★ 逐字节比对构建产物的守卫必须归一化换行；而且"本地全绿"可能是假的——守卫 exit 0 不代表它比过**。新加的 `check-client-bundle.mjs` 把提交进仓库的 `dsh/client-panel/lib/client.js` 与一次全新构建**逐字节**比较，**忘了归一化换行**：Windows runner（`core.autocrlf=true`）检出的产物是 **CRLF / 14456 字节**，构建输出是 **LF / 14445 字节**，差值恰好是文件的 **11 个换行**（实测该文件的 LF 计数 = 11）。于是**同一个 commit** 在 `test (windows-latest)` 上红（"产物过期"）、在 `test (ubuntu-latest)` 上绿（Linux 检出是 LF）。**这是坑 57 的复发**——`check-bundle-freshness.mjs`（main.js）早就用 `s.replace(/\r\n/g, '\n')` 修过同一件事，写新守卫时没照做。
    - **为什么本地几轮都显不出来**：本机沙箱禁止 esbuild 的**子进程**（`spawn EPERM`），守卫**如实打印了 SKIP**、只跑形状检查，然后 **exit 0**；而 `run-gates.mjs` 只按退出码判定成败，于是汇总照打 **34/34**。我连续几轮把"34/34"读成"全部验证过"，**其实那一条什么都没比**（失败只能由 CI 报出来）。**这是坑 68 的第三张脸**：守卫没撒谎，是汇总把它抹平了。
    - **规则**：① 写字节比较的守卫前，先看同族守卫有没有归一化（这里是坑 57）；② **别用"汇总全绿"代替"这一条真的跑了"**——看到 `SKIP`/环境字样就去读那条门禁自己的输出（`node scripts/run-gates.mjs --only bundle`）；③ 本地与 CI 不一致时优先怀疑**换行、路径分隔符、大小写**。
    - **复现与变异验证（修复时实做）**：`git checkout -- <file>` 在内容未变时是 **no-op**，必须 `Remove-Item` 后再 `git checkout --`，才能拿到真检出（实测 `bytes=14456 CRLF=11`）。修前报 `committed 14456 bytes vs fresh 14445 bytes`（**与 CI 逐字一致**）、修后 OK；再故意追加 7 字节 → 仍然 FAIL（证明没有把守卫改成恒真）。
    - **附带**：`core.autocrlf=true` 会让这种"LF 工作区 vs LF blob"在 `git status` 里显示成 `M`，而 `git diff --quiet` 退出 0、`git hash-object -- <file>` 与 `git rev-parse HEAD:<file>` 相同 ⇒ **那是 stat 假象，不是内容变化**；要判断"到底改了没有"，用哈希而不是 status。
70. **★ 「按钮点了没反应」不一定是前端：`/api/session/create` 用 HTTP 200 回答失败，而 UI 只在控制台写一行 warning**（2026-09-14，真实故障：Obsidian 侧栏的「新建会话」永久失效）。
    - **表象**：侧栏界面正常渲染、能上网关、按钮可点、网络面板里**没有任何失败请求**、Obsidian 通知区**什么都不弹**。用户只知道"新建对话按钮没法新建对话了"。
    - **真因**：agent preset 挂载失败 —— `.agent-presets/notes-assistant/agent.cordis.yml` 的 persona 行写的是旧字段 `text:`，而 `@deepseek-ai/dsh-persona` ≥ 0.1.5-rc.1 的 Config 是 `prefix` **必填**：
      `agent-presets: preset "notes-assistant" failed to mount: failed to apply loader entry persona (@deepseek-ai/dsh-persona): invalid config: - $.prefix missing required value (at prefix)`
      preset 挂不了 ⇒ 每次建会话都失败。**这不是插件 UI、反代或按钮的缺陷，是"配置 schema 变了下游没跟"**。
    - **为什么难查**：① 接口是 RPC 风格，成功与业务失败都返回 **HTTP 200**，`ok:false` 在响应体里（`{"type":"server-response","result":{"ok":false,"error":{…}}}`），只看状态码/网络失败**永远看不到**；② 前端只 `console.warn('new session failed: …')`，不弹 toast；③ 反代按设计原样透传、日志里也没有异常。
    - **排查手法（可复用）**：headless Chromium + CDP 打开**真实** dsh（要经插件反代就经反代），点那个按钮，然后读 `Runtime.consoleAPICalled` 与 `Network.getResponseBody` —— 本次就是这样一次拿到完整错误链的（工具：`scripts/qa/sidebar-newchat-probe.mjs`）。
    - **守卫**：`scripts/test-agent-preset.mjs`（零 token）：① 静态断言仓库与**已安装** preset 的 persona 行都用 `prefix:`、都不含 `text:`；② 真的用已安装的 dsh 建一个会话，断言 `ok:true` 且错误里没有 `failed to mount`。**变异验证**：把已安装 preset 改回 `text:` → 套件 5/9 红并打印上面那条原始错误；改回 `prefix` → 9/9 绿。
    - **推论（重要）**：`bootstrapDshConfig` 对 `agent.cordis.yml` / `cordis.patch.yml` 用 `force=false`（保护用户手改），所以 **dsh 升级后 preset 不会自动跟上新 schema**。dsh 每次升级都要问一句："我这份 preset 的字段还是当前 schema 吗？"——本次正是 9/10 升级 dsh 到 0.1.5-rc.1 后遗留的**静默**失效。
71. **★ 侧栏卡顿随"当前会话的渲染树规模"增长——这是"刚启动不卡、用久了才卡"的第一解释**（2026-09-14 实测，同轮同一 harness）：
    | 文档元素数 | 每次样式重算 | 帧 >50ms | 最差帧 | LoAF |
    |---|---|---|---|---|
    | 730（空会话 hero） | **1.2 ms/op** | 0–1 | 50–67 ms | 1–3 |
    | 12 731（注入占位行模拟长会话） | **19.9 ms/op**（16.6×） | **52** | **533 ms** | 54 |
    对照 2026-09-11 在**真实 Obsidian** 里的读数：13 102 元素时 410 次重算共 **22.76 s = 55 ms/op**（比注入的纯 div 还贵，因为真实会话节点带着自己的样式与合成层）。三条推论：① 卡顿的主成本是 **RecalcStyle/布局**，与 dsh 前端把侧栏宽度做成 CSS grid 轨道有关（上游）；② 插件侧能做的只有"别让这份文档继续长大"（皮肤脚本减速/停用已做，见 §0 原因 1）；③ 所以"重开会话 / 少留超长会话"是当前**唯一用户可用的缓解手段**。
    - **为什么"关掉其他程序后没有马上恢复"**：内存压力只是放大器，不是主因。关掉程序后 ① Windows 回收工作集/页文件是滞后的；② 那个已经很大的文档仍在同一个渲染进程里，重算成本不会因为别的程序退出而下降——**要恢复得让 dsh 侧那份文档变小（切换/重开会话、重载面板、重启 Obsidian）**。用户在"关掉其他程序 + 重启 Obsidian"之后连续 2 小时流畅，正是因为**换了新会话、少了 13k 节点**。
    - 复现：`node scripts/qa/sidebar-newchat-probe.mjs --vault=<vault> --bloat=3000`。（**2026-10-18 复核：该探针与侧栏性能机制已删除**；本条表格与读数保留为历史证据，方法可用任意 headless Chromium + CDP 复现。）
72. **★ 排障纪律：仪器本身会把被测对象弄坏；「服务端 ok:true」不等于「用户界面有反应」；自建实例的结论不能代替用户实例**（2026-09-14，同一天里我在这三条上各栽了一次，全部写下来）。
    - **① 仪器制造的故障**：为了"记录一切"，我给页面 patch 了 `window.fetch`（`res.clone().text()` 记响应体）。dsh 客户端靠**流式响应**维持会话控制流，克隆读取把那条流消耗掉，页面随即**永久停在**「自动重连中...」/`phase=connecting`、控制台刷 `[connection] connection lost, retry #N`。我据此得出"服务连不上"——**错的**。不插桩时同一个实例 WebSocket `/api/remote.mux` 建得好好的。**规则：观测工具不得改写被观测的流**；要抓响应体就用 CDP 的 `Network.getResponseBody`（代理侧），不要在页面里包 `fetch`。
    - **② `ok:true` ≠ 有反应**：`POST /api/session/create` 返回 `ok:true` 只说明**服务端**建了会话；用户看的是界面。这一轮真正的判据是**侧栏会话行数有没有增加**（点击前后 `[role=treeitem]` 计数）。我先前只看服务端返回就宣布修好，结果被用户当场否掉。
    - **③ 自建实例 ≠ 用户实例**：我起的 dsh（`--port 0` + 自建 vault 目录）与用户在 Obsidian 里跑的那个（插件反代 + 真实 vault + 真实会话历史 + 皮肤）在**页面状态**上并不等价——同一段代码、同一个 preset 字段 bug，在两者上的表现可以完全不同。**要判断"用户那边怎么了"，必须打用户那个实例**：现在探针支持 `--entry=http://127.0.0.1:3180/`（跳过自建、直连已在跑的实例）。
    - **④ 顺带纠正一条数字**：`sidebar-performance.md` §0.3 那张"12 731 元素 19.9 ms/次"的表是**注入 3000 行 div** 造的，而 `data-chat-flow` 未必挂在可注入位置（实测 `flow=DIV[other]`，注入落在 `body`）。它只能证明"同页面上文档越大越贵"，**不能**预测"你会话写到 13k 节点时一定卡"——真实数字只认 §0.2 的真实 Obsidian 读数（13 102 节点、55 ms/次）。该节已加更正块。
    - **⑤ 结论**：坑 70 的 preset 修复是**真实且必要**的（服务端 `session/create` 从 `ok:false` 变 `ok:true`，有变异验证），用户也在**没有重启 Obsidian** 的情况下确认「新建会话会正常新建跳转了」（`agent-presets` 每次建会话现读，所以改盘即生效）。但"点按钮没反应"当时是否**只**由 preset 引起，我没有把用户实例的界面状态测到底——**别再把它当成"已完整解释"**。

73. **★ npm 发布有一条"publish 成功了但 registry 还没可见"的竞态，会被判成失败**（2026-09-14 发 0.7.6 实测）。整条流水线的每一步都是绿的——`Publish (trusted publishing)` 步 **success**、日志里已有 `+ dsh-math-memory@0.7.6` 与 `Provenance statement published to transparency log`——但紧跟着的 `Confirm the registry state` 在 **60 秒**内查到 registry 上 still missing，于是走失败分支：开 issue「npm publish failed for 0.7.6」并把 job 判红。**实测约 60–80 秒后** `https://registry.npmjs.org/dsh-math-memory` 才出现 0.7.6（`latest` 也才翻过去）。**处置：Re-run failed jobs**（`POST /actions/runs/<id>/rerun-failed-jobs`），第二次跑该步就能确认到 —— 转绿并自动 close 掉那个 issue。**不要因为这条红去改代码或改版本号**。这与坑 58 记的两种"退出码在撒谎"是同一族但方向相反：那条讲"退出码 0 ≠ 已发布"，这条讲"**registry 的可见性有延迟，查早了就是假红**"；`docs/release.md` §2 的"判断成败一律看 registry 实际状态"要加一条限定——**看 registry 也要给它一两分钟**。
    - 顺带核实了本次 claims 与 0.7.5 一致（`job_workflow_ref` 带 `@refs/tags/0.7.6`、无 `environment`、`aud = npm:registry.npmjs.org`），所以 trusted publisher 配置无需改动。
    - **第四次复现（2026-09-27 发 0.8.0）**：延迟这次 **> 90 秒**（issue #6），而 `Confirm the registry state` 当时的口袋正好是 **90 秒**（`for attempt in 1..6; sleep 15`）⇒ 又判红。**注意这条陷阱的原样复现说明"轮询存在"不等于"轮询够久"**——四次实测的延迟是 60–80 s / 92 s / 4–5 min / >90 s，**在增长**。已把该步改成 **18 次退避轮询（前 6 次 10 s、其后 25 s，约 6 分钟）**，并把**实际耗时打进日志**（`elapsed Ns`），这样下一次要重新定标时看日志即可，不必再靠猜。只读核实的方式不变，且仍是唯一判据。

74. **★ 探针会往用户的 dsh 里"注册工作区"，而且删目录删不掉它**（2026-09-14，用户发现侧栏多了 7 个 `dsh-preset-ws-XXXXXX`）。
    - **机制**：`session/create` 的副作用是**永久登记一个工作区**，dsh 把它写进 `$DSH_HOME/storages/workspace.json`（`tables.workspaces` + `global.workspaceIds`），这份表直接喂给侧栏的「工作区」列表。所以"用一个 `mkdtempSync` 临时目录建个会话试试"这种探针，会在**用户自己的侧栏**留下一个他从未创建过的工作区。我的 `test-agent-preset.mjs` 第一版用 `mkdtempSync('dsh-preset-ws-')`（每次新目录）⇒ 每次 `npm test` 留一个，一共留了 8 个。
    - **删目录没用**：登记项在 json 里，路径不存在也照样显示。必须**摘登记项**（现在有 `scripts/lib/workspace-registry.mjs` 的 `pruneWorkspaces` / `pruneMissingWorkspacePaths`）。
    - **第二个坑：大小写**。`os.tmpdir()` 在 Windows 给 `C:\WINDOWS\TEMP`，而 dsh 写的是 `C:\Windows\Temp` —— `path.startsWith(probePath)` 逐字符比较**全部漏掉**，于是"清理成功但一条没删"。`pruneWorkspaces` 负责把小写化 + 反斜杠归一，调用方只给谓词。
    - **第三个坑：服务内存里还有一份**。只手改 `workspace.json` 不管用——**运行中的 dsh 服务持有内存态**，它下次落盘会把删掉的条目写回来。清理顺序必须是：**先让服务结束 → 再改文件 → 再让服务起来**（实测：kill 后它并不会在退出时把旧列表刷回去，所以这个顺序是安全的）。
    - **规则**：任何会调 `session/create`（或点「新建会话」）的探针，跑完必须自己摘登记项，并把这一步做成断言（"残留在 json 里的条目数 === 0"），否则它会静默污染用户环境。**探针的默认工作区应该是固定路径 + 用完即删**，不要每次 `mkdtempSync` 一个新目录。
    - **顺带一条**：如果探针在 3180 上跑，它点的「新建会话」会在**用户真实 vault 的工作区**里建一个空白会话（我第一次就这么干了，两个空会话已删）。用 `--entry` 打用户实例时要接受这一点，或者只读不点。

75. **★ 工具返回值多一个字段 = 整次调用失败（dsh 的严格校验 + `additionalProperties: false`）**（2026-09-14，用户实测：模型说"note_recall 返回结构不合 schema，我改用 note_search/grep"）。
    - **机制**：dsh ≥0.1.5 的 `ToolRuntime` 对**成功返回值**也做 `validateJsonSchemaValue(tool.output.schema, value)`，而我们的 output schema 一律 `additionalProperties: false`。于是"**多返回**一个未声明字段"就是失败（不是"少返回"）。
    - **实测到的三处**：`rankRecallDocuments` 的 match 对象带 `hook` / `boundary` 且被原样返回给 `note_recall`；`note_recall` / `note_strategy` 的 `excluded` 项曾经带 `kind` / `score`；`note_create` 返回 `{ path, operation }` 时把键写成 `rel`（schema 里没有 `rel`）。**`note_strategy` 还少一个必填字段**（schema 声明了 `title`，返回里没有）。
    - **修法**：在**工具边界**收窄（管线内部可以继续带 rich 值给探针用），并补齐声明。`rankRecallDocuments` 的 matches 现在就在管线里收窄，因为它同时是探针与工具的输入。
    - **守卫**：`scripts/test-tool-schemas.mjs`（静态"声明了但没出现"+ 用 dsh 真校验器跑 fixture，含 `--mutate` 变异验证）、`scripts/test-tool-shape.mjs`（**真调管线**再递归比对声明与实际，并留一条"直通值必须被判违规"的反证）。
    - **设计教训**：静态文本匹配**不能**用来找"多字段"——第一版用"逗号/冒号切 token"读键，把 `path: a ?? "all"` 里的 `:` 当键分隔符，报出 `all`/`rel`/`null` 四个**假阳性**。**假阳性比不检查更糟**（教人忽略这个套件）。静态只报"缺"，"多"交给真值测试。
76. **★ `entry.doc.X` 的形状错误：`note_recall` 只要遇到一张"适用边界命中查询"的卡就整体抛 TypeError**（2026-09-14，同一轮修掉）。
    - `rankRecallDocuments` 的 `boundaryHitsOf(entry)` 原先写 `entry.doc.boundary`，而 `entry` **本身就是** scored 项（`{ doc, i, score, operatorMatch }`）⇒ `entry.doc` 是 `undefined`，读 `.boundary` 直接抛。`excluded` 的 map 又写 `entry.doc.rel`，同一处错误。
    - **为什么一直没被发现**：记忆回归（240 项）测的是**打分与排名**，不读 `excluded`；探针也不覆盖"边界命中"这条分支。**这条分支没有任何测试走过**——正是坑 68 那族（"没有用例走到的分支，不算被测过"）。
    - **触发条件**：库里任何一张带 `not_applicable_when` 的卡，其边界短语出现在查询里 → 整个 `note_recall` 不可用（模型侧只能退回 grep，用户看到的就是这句话）。
    - **修法**：`excluded.push({ doc: entry.doc, hits })` + map 用 `doc.*`，返回的四个键与 schema 逐字一致。守卫见坑 75 的两个套件（fixture 里**故意**放一张带边界的卡）。
77. **★ 链接跳转服务的端口与令牌必须跨加载稳定**（2026-09-14，用户实测"回复里的双链点了没反应"）。
    - **机制**：模型回复里的笔记链接是 `http://127.0.0.1:<LinkServer 端口>/open?path=…&t=<令牌>`，而这个地址是**写进系统提示**的（`DSH_MATH_MEMORY_LINK_URL` / `DSH_MATH_MEMORY_FEEDBACK_TOKEN`），提示又只在 **dsh 子进程启动时**生成一次。原先端口是 `listen(0)`（每次随机）、令牌每次插件加载重新 `randomBytes` ⇒ **插件一重载，此前所有回复里的链接立刻失效**：端口没人听（连接被拒），或者令牌对不上（403）。
    - **实测证据**：会话日志里模型生成的链接指向 `127.0.0.1:52269`，`netstat` 显示该端口早已不存在；同一时刻**任何**回环端口上都没有 LinkServer 在听。
    - **修法**：端口与令牌进 `data.json`（`linkServerPort` / `linkServerToken`），启动时复用；端口被占则回落随机端口**并写一行日志**（"链接又变了"必须有痕迹，否则下次还得从零排查）。守卫 `scripts/test-link-server.mjs`（12 项：固定端口、重载后端口/令牌不变、占用时回落不抛、两个端点的令牌与路径穿越判定）。
    - **仍未做**：把链接模板改成**运行时**注入（`ctx.systemPrompt.context()`），这样即使 LinkServer 换端口，新回复也总带当前地址；以及 3180 代理在"服务还活着但代理没绑上"时能自愈（本次排查中我把代理 reload 成了无监听状态，只能靠 reload 插件恢复）。
78. **★ 「某份清单里没有它」不是「它不存在」：我据一份过期的收录清单，把一个在架的插件判成"没上架"**（2026-09-15，同一天里我先误判、再按误判改了文档，被维护者当场纠正）。
    - **经过**：维护者要求核对中英 README 的漂移。我读到 `docs/project-assessment-2026-09-10.md` 第 16 条（判 HIGH：README 让用户在社区插件市场搜索，而 `obsidian-releases` 的 `community-plugins.json` 里没有 `dsh-math-assistant`），又**只**核验了 `community-plugins.json`（当时实测 2991 行，确实没有本插件），于是判定 zh 侧的「第三方插件 → 搜索安装」是**不存在的安装方式**，把它改掉，并把 en 侧早已存在的「尚未上架社区插件市场」当成正确的一侧去"统一"。
    - **实际事实**：**插件已在架**，中文 README 原本是对的。Obsidian 的收录方式已经改变，`community-plugins.json` **不再是收录依据**；现行依据是插件在 [community.obsidian.md](https://community.obsidian.md/plugins/dsh-math-assistant) 有页面（第三方目录 [obsidianstats](https://www.obsidianstats.com/plugins/dsh-math-assistant) 也收录了）。用一句"JSON 里没有"就下结论，等于**拿一把已经作废的尺子量**。
    - **它同时命中了仓库自己的两条纪律**：① `docs/agent-repo-maintenance.md` §5.3「已归档/已退役的文件里，仍可能藏着一句当下的声明」——`project-assessment-2026-09-10.md` 是**日期化快照**，它写的是 2026-09-10 的观察，不是今天的结论；② 「报告是线索不是事实」（坑 64）——我当时把它的结论当成了可直接执行的事实，**没有回去核对当下**。**核查规则**：判断"某东西存不存在"要用**当下的权威来源**（官方商店页 / 官方 API / 现场），清单文件只在**其自身被声明为权威**时才算证据；用清单做否定结论前，先确认这份清单还在被维护。
    - **连带纠正**：en 侧 README 的「**Not in the community plugin browser yet**」callout（含 BRAT 退路）**本身是错的**，需要按在架事实改正（本轮先把误改的 zh 侧还原，en 侧的事实修正单独做）。`docs/project-assessment-2026-09-10.md` 第 16 条与 `docs/release.md` §3 也要就地加日期化更正——它们仍在把这条早已不成立的观察当现状引用。
    - **本轮的净产出（保留）**：① 门禁 `scripts/check-readme-pair.mjs`（第 39 条）+ 一致性记录 `README.i18n.yaml`：只改一侧就红并指出是哪一侧（"最近被改的一侧即源"的机器形态），另比结构签名 / 切换行 / 相对链接集合 / 围栏代码骨架；② 它自己的变异验证 `--selftest`（8 项，同进程纯函数——**初版是假的**：fork 守卫看退出码，而受限环境禁止管道 stdio ⇒ `spawnSync` EPERM 被读成"退出 1"，于是每个变异都"被抓住"，最后 8/8 才真正成立）；③ 两侧 README 的 `- Version:`/`- 版本：` 行纳入 `check-version-consistency.mjs`（此前只锚 `handoff.md`/`design.md`）；④ 两侧**真实同构**的结论（14 节 / 29 条目 / 3 围栏、层级逐节一致）——即"英文显著落后于中文"这一初始判断不成立，真正落后的是两者共同腐烂的版本行。
    - **★ 与 dsh 上游 docs/i18n 的两处「故意不同」（照抄会误报，保留此结论）**：① 上游要求围栏代码块**逐字节一致（含注释）**——本仓库的注释是**有意本地化**的，`check-doc-consistency.mjs` 正是锚在中文那一份的注释措辞上（`# 语法 + 240 项零 token 回归`），所以这里只比"去掉注释后的首个 token（命令/路径）"；② 上游要求中文侧相对链接指向 `.zh.md`——本仓库**没有第二语言语料**（`docs/**`、`literature/**` 都只有中文一份），两侧必须指向**同一批文件**，所以比的是"两侧链接集合相等"。第一版按上游规则写，当场误报 15 处。**教训**：规则随语料结构走。

79. **★ 解析出的值带着包裹引号去拼接：边界会静默失效**（2026-09-17，构造探针查出）。
    - **经过**：「用户否决 ⇒ 收窄适用边界」的功能把本次查询的特征追加进 `not_applicable_when`。旧实现取整行值后**直接按顿号切片**，而模板 `templates/records/_README.md` 推荐的写法**带引号**（`not_applicable_when: "等价刻画不存在或更繁时"`），于是开引号黏在第一个片段上，值变成 `"等价刻画不存在或更繁时"、谱半径`。
    - **为什么危险**：门控是按**子串包含**判定的（`boundarySegments` 切出 2–12 字片段后做 `query.includes(segment)`），带引号的片段几乎永远不命中 ⇒ **用户点一次「本次场景不适用」，那张卡的原有边界就悄悄失效了**，而文件看起来完全正常、没有任何报错。
    - **修法**：取值后先 `trim()` 再剥掉包裹引号（`replace(/^["']|["']$/g, '')`）再切片（`memory-admin.mjs` 的 `inapplicable` 分支）。
    - **为什么值得记**：这是「**模板推荐的写法恰好触发代码的缺陷**」——最常用的形态反而是坏的。而且它**只在拼接时才暴露**，单看任何一半都正常。**推而广之：任何"读出值 → 拼接 → 写回"的字段处理，都要先按门控/消费者的解析方式归一化**，而不是按写入时的观感。
    - **它是被构造探针查出来的，不是读代码看出来的**：先写一个"带引号的边界"输入跑一遍，才看到输出坏掉。断言现为 `test-memory.mjs` 的 `shrink: a QUOTED boundary is unwrapped…` 与 `shrink: both the pre-existing boundary and the added one actually gate`。

80. **★ 文档承诺的纪律，代码可能一条都没实现**（2026-09-17，多个实例）。
    - **实例**：`strategy-readme.md` / `vault-AGENTS.md` 一直写着「策略卡是**候选**不是**指令**」，但 `rankStrategyCards` 只排除 `superseded`，而且**返回值里连 `status` 字段都没有** ⇒ 模型拿到的 `matches` 里 `active` 与 `candidate` 完全无法区分。同类：`uses` 数的是"被检索出来几次"，却被当作"有用"参与排序；`harmed` 只进体检报告、不影响排序。
    - **判据**：**文档里的每条"纪律"都要能指出它在代码里的执行点**；指不出来就是口号。发现方式很便宜——把文档里带"必须/只能/不得"的句子逐条去 grep 代码。
    - **反例（做对了的）**：`verified` 高于 `single-source` 必须有 `verified_by` 凭据，这条既有写入方（只有用户点 ✅ 会写）又有检测方（体检的 `unjustifiedUpgrade`）。**这条是范本：承诺 + 唯一写入者 + 检测者，三者齐备。**

81. **★ 断言在变异下照样通过：本仓库已出现至少五次**（2026-09-17 汇总）。
    - **形态**：断言看起来在测某性质，实际上夹具/条件让它在变异下也通过。已发生的实例——① 夹具内容**不超过**预算上限，所以测不出上限（写作 `compact` 与 `rich` 长度相同，我当时误判成"代码有未知机制在缩短"）；② `last_query` **完全没有写入侧断言**（测试手写 stats 文件，删掉记录那行照样全绿）；③ 重复对排序的夹具里强组写在**靠前的文件名**，扫描序恰好是降序，去掉 `sort` 断言不红；④ 「`wrong` 不动边界」写在**已被 `inapplicable` 收窄过**的卡上，"不重复添加"让变异无从体现；⑤ 无源卡的**技巧名独一无二**，去掉"无 source 不计入"的保护后什么都不会变。
    - **纪律**：**加了守卫必须做变异验证**（故意造缺陷 ⇒ 确认报错 ⇒ 恢复 ⇒ `git diff` 为空）。验收标准是"**它在该报错时确实报错**"，不是"跑了没报错"。**夹具必须跨过被测的阈值**，否则测的是阈值以下的行为。
82. **★ 「成本怎么量」本身当时是坏的——所以"省了 x% tokens"这类数字不能当套件产物看**（2026-09-18 归档时查清）。
    - **经过**：用户决定把 README 里那条「成本基准」存档（一道题：旧系统约 17 万计费 tokens → 新系统约 2.5 万，缓存命中 68%）。查它**是什么**时发现：**没有任何脚本、用例或 baseline 绑定这两个数字**（它来自一次人工对照运行），而且当时用来量成本的机器本身是坏的——`scripts/qa/e2e.mjs` 的 **token 计量恒为 0**，因为它只读会话格式 V3 里**已被移除**的 `assistant/chunk` usage 事件（`project-assessment-2026-09-10.md` §2 第 11 条）。
    - **最刺的地方**：`docs/memory/benchmark.md` §5 恰好把"tokens 从 `assistant/chunk` 的 usage 里取"写成了成本记录的**设计**。也就是说文档与代码在同一个错误上互相印证，而**没有任何门禁会发现"计量恒为 0"**——0 是一个合法数字，不会让任何断言失败。
    - **纪律**：① **一个没有测量脚本绑定的数字，不配进验收记录**——它无法重跑、无法验证，只会在文档里独立腐烂（本条正是它的下场）；② 量成本的产物里如果出现**恒为 0 或恒定不变**的字段，先怀疑**它读的事件还在不在**，而不是去解释那个 0；③ 归档"停用口径"的测量时，把**证据边界**一起存档（本次存进 `docs/archive/cost-benchmark-2026-08.md` §4），否则下一个人会把旧数字重新抄回文档。

83. **★ 「迁移」只迁了职责、没摘旧工具 ⇒ 一个能力留下多个入口，模型就自己挑**（2026-09-20 查清）。
    - **经过**：用户问「grep 是不是和 note_search 重复了」。核对后发现 `note_search` **两边都重复**——tag 过滤与 `note_recall` 用的是同一套 `noteTags`/`matchesTagFilter`，字面文本查找又与 grep 重叠（且是不排序的子串，精度更低）。更要紧的是 `docs/memory/retrieval-v3.md` §5 当初就写着「search 取代 note_search 与 note_retrieve 的查询职责」、§6 也把 `note_retrieve` 标成已退役，**但 `note_search` 这个工具本身没被摘掉**。于是 vault 里长期并存三个"找东西"的入口（`note_recall` / `note_search` / grep），模型自己挑；同一天排查的"grep 被当检索器用"正是同一病根的另一面（协议在多个位置把 grep 写成可选检索路径）。
    - **为什么长期没人发现**：没有任何门禁会因为"多一个入口"报错——工具数、schema、fixture 全都自洽。真实会话日志里 `note_search` 15 次调用**全部带 `query`、0 次只按 tag**，也就是说它唯一不可替代的能力（按 tag 枚举）其实没人在用，而它被当成"低精度字面搜索"，看起来还能用。
    - **纪律**：① **迁移一个接口时，旧接口要么当场摘掉，要么在工具面之外显式标成"已退役"并留一条守卫**——"职责迁走了"不等于"入口没了"；② 判断两个工具是否重复**不要凭印象**：把能力逐项列出来、对照代码（本例是"同名的 tag 匹配函数"这一条把结论钉死的）；③ 摘工具前先量一次**真实调用分布**（`note_search` 的 15/0 就是"可以摘"的证据），否则会把偶尔有用的能力一起删掉。
84. **★ 冻结的 fixture 会让你以为"顺手同步"是安全的**（2026-09-20，同一次改动）。
    - **形态**：`scripts/qa/benchmark-vault/` 是**冻结的基准语料**（`handoff.md` §7 已登记、`check-rename.mjs` 也按目录前缀豁免）。本轮改了 vault 协议（`vault-AGENTS.md`）后，它那份**故意停留在旧措辞**（还写着 `note_search` 与「grep episodes」路由）。
    - **纪律**：改协议模板时**先确认哪些副本是"生成的"、哪些是"冻结的"**——生成的要重建（`main.js`），冻结的**不要顺手改**，它的更新方式是"一次有意的刷新 + 新 baseline"，并且必须在改动记录里写明"刻意没同步它、为什么"。
85. **★ 夹具在证明一个不存在的场景是对的：三个"永远成功"的桩联手放走了一个必现缺陷**（2026-09-21）。
    - **形态**：`/open` 把 `.deepseek/**`（Obsidian 的隐藏目录）交给 `openLinkText`，**必然打不开**，而这个缺陷在该套件里**结构上不可能被发现**——因为三件事同时成立：① 所有 `/open` 用例**只用普通笔记路径**（`.deepseek` 只出现在 `/feedback` 用例里）；② 假 workspace 的 `openLinkText` 是**永远成功的桩**；③ `existsSync` 是**恒真桩**、`pathInside` 是**恒真桩**。于是"文件不存在 → 404"和"路径越界 → 403"这两条契约也从未被真正测过。
    - **同族**：坑 69（守卫 exit 0 不代表它比过）、坑 56（守卫把"没跑起来"当失败）、坑 81（断言在变异下照样通过）。共同点是**验证动作本身失效，而输出仍然是"通过"**。
    - **纪律**：① 桩要**如实反映真实约束**——`openLinkText` 对点目录"给不出 TFile"这一条，起码要在桩里留痕（本轮加了 `impossible` 标记），否则夹具会把产品缺陷洗成绿；② **每个端点都要有一条"不成功"的用例**（不存在、越界、令牌错），只测成功路径等于只测了一半；③ 新增分支时**先问"哪个桩会替它撒谎"**。
86. **★ 截断逻辑可以长期零覆盖：所有夹具都小于预算**（2026-09-21）。
    - **形态**：`clip()` 的截断分支两年没被触发过——本仓库所有夹具的注入内容都**远低于各自预算**（实测 `benchmark-vault` 整段 **4088 字符**、零截断），而它恰恰是错的（只保头部 ⇒ append-only 文件的**最新内容最先被丢**）。构造"增长型"夹具（旧在前、新在后、条目数超过预算）后立刻现形：`rec-1` 保住、`rec-40` 丢掉。
    - **纪律**：**超限/降级/错误分支都要有专门构造的夹具**，"默认路径绿"不覆盖它们；夹具的**形状**（而非只是大小）决定它能测到什么——append-only 的语料必须"最旧的在前"，否则"保头还是保尾"这个性质根本不会被区分。
87. **★ 断言把"包装"算进了被包装物的上限**（2026-09-21）。
    - **形态**：`audit: report bounded` 断言 `report.report.length <= 1200`，而被截断的报告长度 = 内容 + **截断标记**。标记因为要写出"省略了多少字符"长了 12 个字符，于是**内容一字未变**的报告报红。
    - **纪律**：断言一个量的时候，先问"这个量里还装了别的东西吗"；上限类断言要**分别**断言"被保留的内容 ≤ N"与"超限时标记存在"，不要合成一个恒等式。
88. **★ 一个被注释掉的列表项，让整个 profile 无法启动——而 41 条门禁全绿**（2026-09-21，实测踩到）。
    - **形态**：`dsh/profile/cordis.patch.yml` 的**第一行与上一条注释拼在了同一行**（`# …plus the cross-session memory plugin.- id: agent-presets`）。那一行因此是注释 ⇒ 顶层序列**从未开始** ⇒ 后面第一个裸 `- id:` 就是 YAML 语法错误。真 `dsh` 直接拒绝启动整个 `notes-assistant` profile：`failed to parse overlay …: YAMLException: end of the stream or a document separator is expected (16:1)`。**Obsidian 侧栏、`dsh --profile notes-assistant`、以及依赖它的门禁全部一起坏掉。**
    - **为什么门禁没发现**：① 除 preset 门禁外，**所有门禁都把这些文件当文本读**——`test-preset-sync.mjs` 逐字节比对两份拷贝，而被改坏的行仍然是合法文本，两份还**完全一致**；② 唯一会发现的 preset 门禁是因为它**真的启动 dsh** 才撞上的，而它在受限环境里会因"写不了 `$DSH_HOME`"先失败 ⇒ **恰好在看不到真相的环境里，这个 YAML 错误是不可见的**（同族：坑 56/59/69）。
    - **纪律**：① **"是合法文本"不等于"是合法配置"**——对装配文件（`*.patch.yml` / `*.cordis.yml`）必须有**解析**它的门禁，不能只做字节或文本断言；② 一个只在"能启动真进程"时才被发现的缺陷，等于在受限环境里**没有守卫**；③ 注释与结构的边界是这类文件的常见雷区（本仓库已两次：坑 60 的文件名、这条的注释吞行）——**新增守卫 `scripts/check-patch-yaml.mjs`**（解析 + 顶层必须是 op 序列 + 每个 op 带 `id`/`insert` + 直接断言"没有行被注释吞掉"）。
89. **★ 包装进了 `node_modules`，却没有任何 loader 挂载它——拖拽"接住了、也回 204"，就是不落笔**（2026-09-21，用户实测踩到；**该功能已于 2026-10-18 整体移除**，本条保留为装配层教训）。
    - **形态**：从 Obsidian 文件列表把笔记拖进侧栏 dsh 输入框 → 提示条出现 → 松手 → **草稿里什么都没有**。插件 `debug.log` 把故障区间夹得很死：
      `[drop] 收到拖拽，解析结果="抄书/最优传输/最优传输2"` → `[drop] 直插=false` → `[drop] /mention 响应 204`，连续 5 次，全部这样。
      也就是说：**Obsidian 那侧完全正常**（路径解析对了、服务端也收下了），断的是"送进页面之后由谁落笔"。
    - **两个独立成因，缺一都修不好**：
      1. **直插那条路结构性不存在**：`insertMentionIntoFrame` 调 `frame.executeJavaScript` —— 那是 Electron `<webview>` 的方法，而侧栏里放的是**跨源 `<iframe>`**，没有这个方法 ⇒ 它按设计返回 `false`（日志里的 `直插=false` 是**正确行为**，不是 bug）。
      2. **兜底那条路没有接收方**：`/mention` → SSE `/mention-stream` 那半边要求页面里跑着**记忆面板的客户端半个**（它才 `window.__dshMentionInsert` + 订阅 SSE），而那个包**只躺在 `node_modules` 里，没有任何 loader 行挂载它**：`dsh/profile/notes-assistant.patch.yml` 与 `profiles/notes-assistant/cordis.patch.yml` 里都只有宿主半个。于是 `pushMention` 每次都落进空队列（`mentionClients.size === 0`）后被挤掉，**204 是真的、送达是假的**。
    - **根因（为什么"装好了"却"没挂上"）**：安装器 `install-into-profile.mjs` 把 loader 行**追加到 `profiles/<profile>/cordis.patch.yml`**。可 Obsidian 插件在**每次启动服务时**都用内嵌副本重写 `notes-assistant.patch.yml`（`buildNotesAssistantPatch`），而启动命令是 `dsh --profile notes-assistant --patch …/notes-assistant.patch.yml` —— **`cordis.patch.yml` 压根不在这条启动路径上**。两头都错：追加到 A 的行会被覆盖（就算追加到 B 也一样）。
    - **为什么门禁没发现**：① `install-into-profile.mjs` 的"成功判据"是 `patch.includes(PKG)` —— 一个**子串**检查，它证明"文件里出现过包名"，证明不了"有一行 id 挂载了它"；② `test-installer.mjs` 当时的断言是"`cordis.patch.yml` 的仓库内容是**前缀**，且追加块里有这个包名" —— 这条断言**把 bug 写成了期望**，等于给故障盖了章；③ `check-patch-yaml.mjs` 当时只断言 id **不冲突**（证明不了它**存在**）；④ e2e 探针 `drop-to-mention-e2e.mjs` 起实例时**没传 `--patch`**，于是它那台 profile 本来就不加载客户端半个，那条"该 profile 自己加载了客户端半个"永远红 —— **一条长期为红的断言，等于没有断言**（同族：坑 56/59/69）。
    - **修法与纪律**：① **那一行必须是发布物的一部分**，写进权威源 `dsh/profile/notes-assistant.patch.yml`（由 build 内嵌进 `main.js`，每次启动重写时自然带上）；② 安装器只做"**装包 + 校验行在**"，**不再往任何 patch 文件写行**；③ 门禁从"不冲突"改成**"恰好出现一次"**（零次＝静默失效，两次＝`duplicate loader entry id` 整个 profile 起不来），并**变异验证**过两种红；④ 探针改为照抄插件真实启动参数（含 `--patch`），于是那条断言第一次真的在测装配路径；⑤ **判据要锚在结构上，不要锚在子串上**："装好了"必须由"能解析出一行 id、且它指向的包确实存在"来证，不能由 `includes('包名')` 来证。
    - **为什么这条值得记**：拖拽功能**每一段代码都测过、每一段也都是对的**（解析、载荷、合成 paste、SSE、CSRF），坏的是**装配**——而装配恰好落在"安装器"与"插件每次启动重写 overlay"这两个各自都很合理的设计的**接缝**上。**"装进 profile"不等于"界面里加载了它"**；凡是有"安装期写文件 + 运行期重写同一文件"的地方，都要问一句**谁是权威、谁会覆盖谁**。
90. **★ 拿一个"沉默的旧构建"的观察结果去判定新代码有没有被执行**（2026-09-21/25，查拖拽时踩到；该功能已移除，本条保留为通用纪律）。
    - **形态**：真实侧栏实例（127.0.0.1:3180，经插件反代）上，我量到"页面订阅了 `/mention-stream`、服务端推一条、页面 `message` 事件**确实收到** `"路径"`、可草稿是空的"，于是判定"消息处理器那一段没落笔"。**这个结论当时是无效的**：那台实例上跑的客户端包是**旧构建**（`lib/client.js` 在页面加载时取，服务重启前一直是旧的），它根本**没有**我刚加的自述诊断代码——于是"日志里没有诊断行"被我读成了"处理器没执行"，而真相是"那段代码不在运行的包里"。
    - **为什么危险**：这是坑 88（文本 vs 配置）的近亲 —— **"我没观察到" ≠ "它没发生"**：观察通道本身可能是旧版本、或压根不存在。用一条"还没被部署的代码"的沉默当证据，等于拿空气当证据；而它会把排查方向引到完全错误的地方（我当时已经开始怀疑 SSE 解析与事件次序）。
    - **纪律**：① 判定"某段代码有没有被执行"之前，**先证明那段代码在运行的构建里**（取它自己的特征串/导出名去当前页面或当前产物里查一次，例如 `describeMentionInsert` 在不在服务的 bundle 里）；② **让被观察的东西自己说话**：静默的失败分支必须自述（`describeMentionInsert` + `/mention-report`），而不是靠外部推断"没看到 ⇒ 没发生"；③ 客户端包是**页面加载时**取的 —— 改了 `lib/client.js` 之后，**旧页面仍是旧代码**，"重启服务"与"刷新页面"是两件不同的事。
91. **★ 测试探针改动了用户的持久状态：一条"零 token 可随意跑"的探针，往侧栏塞了 38 条垃圾工作区**（2026-09-21/25，我自己造成的）。
    - **形态**：`dsh/profile/math-memory-workspace.mjs` 会把 `DSH_WORKSPACE_ROOT` **登记**进 `$DSH_HOME/storages/workspace.json`。而 QA 探针为了不碰真实 vault，都用 `mkdtempSync` 造临时 vault 起 dsh ⇒ **每跑一次探针，用户侧栏的「工作区」列表里就多一条 `C:\Windows\Temp\dsh-*-probe-*/vault`**。反复调试拖拽那几天累计塞进 **38 条**，列表里全是同名 `vault` / `probe-vault-*`。
    - **为什么危险**：工作区登记是**持久**的（写在 json 里、不是进程内状态），而且探针"零 token、可随意跑"这个表述**诱导人把它当成无副作用**。它的副作用还与排查混在一起：列表被垃圾项填满后，页面会先显示"选择工作区"而不是直接给输入框 —— **看起来像功能坏了**，实际是我的探针弄脏了用户环境。
    - **纪律**：① 探针前先问"它会写哪些**持久**状态"（workspace.json、settings、`.agent-presets`、会话目录…），会写就**用完立刻清**；② 清理要做成**按判据**的脚本（`scripts/qa/clean-probe-workspaces.mjs`：只删系统临时目录下的登记、先写 `.bak`、默认 dry-run），而不是手改 json —— `test-agent-preset.mjs` 早就有这条纪律（固定探针路径 + 用完摘登记），新探针必须照做；③ 探针的 vault 目录要用**唯一名字**，同名既让夹具无法确定性点中，也让垃圾项更难辨认；④ **"用完清理"不够，最好让它一开始就写不到**：`scripts/lib/isolated-dsh-home.mjs` 给探针种一个临时 `$DSH_HOME`（复制 profile 要点 + junction 链 node_modules），登记于是写进副本。注意两个反例：**删目录前要先读登记表**（顺序反了 `catch` 会返回 0 ⇒ 断言永远绿），以及**路径比较必须归一化**（`dsh` 写的是反斜杠路径，拿正斜杠前缀 `startsWith` 一条都匹配不到 —— 这是同一条断言"永远绿"的第二个原因；两处都做过变异验证）。

    - **补充（2026-09-25）**：本机残留的 10 条已在适配时清掉，那之后 `test: agent preset mounts` 由 16/17 变 17/17。**但这条断言本身就是"锚在用户环境数据上"的**：它读真实 `$DSH_HOME` 的工作区表，所以任何历史残留都会让它红——它是**告警**，不是回归。见到它红先跑 `node scripts/qa/clean-probe-workspaces.mjs`（dry-run）确认是不是旧垃圾，**不要**改断言。
92. **★ dsh ≥ 0.1.7：preset 里相对 `name:` 的解析锚点是 profile 目录，不是你写声明的地方**（2026-09-25，做 0.1.7 适配时踩到）。
    - **形态**：0.1.7 起 preset 变成一条普通 Cordis 行（`name: '@deepseek-ai/dsh-agent-preset'`，`config.plugins` 放组合）。把 `./math-memory.mjs` 这类相对行名按"和组合文件同目录"去理解（上一轮 V3 适配留下的直觉），于是把 `.mjs` 与声明它们的 patch 放在一起 ⇒ preset 审计报 `math-memory (./math-memory.mjs): never started`、`session/create` 返回 `agent-preset/invalid`；把**同一份** patch 里的 `.mjs` 只换位置（放进 `$DSH_HOME/profiles/<profile>/`）就一次通过（做过双 marker 差分：只有 `PROFILE_DIR:imported` 出现）。
    - **根因**：`agentPresetRegistry.register()` 捕获的是**registry 服务自己的 ctx**（`dsh-agent-preset-registry/lib/index.js:500-501,534` → `mountPreset(scope.ctx.extend({ baseUrl: record.context.baseUrl }))`），而 registry 行挂在 profile 里 ⇒ 相对行名锚定 **profile 目录**。`…/dsh/lib/profile-boot-*.js` 的注释也写了同一件事：*"the Loader needs a real include root to anchor `baseUrl` at the profile directory"*。
    - **纪律**：① 迁移这类"声明与实体分离"的机制时，**锚点要靠实测定位，不能靠"文件应该在哪"的直觉**——判据是"换个位置就通/不通"的差分实验，不是读代码猜；② 跨版本适配**不要从上一轮的结论外推**（V3 那轮"和组合文件同目录"是对的，0.1.7 就不是了）；③ 我们的落地形状：`dsh/preset/preset-deploy.mjs` 把体文件铺进 profile 目录，声明由 `scripts/build-preset-declaration.mjs` 生成进两个通道的 patch，两者由 `test: agent preset mounts` 一起钉住。
93. **★ import 失败在 preset 审计里只有一句 "never started"，真实异常被吞掉**（2026-09-25）。
    - **形态**：模块解析失败时**看不到** `ERR_MODULE_NOT_FOUND`。`cordis-plugin-loader/src/config/entry.ts:221-235` 的 `_init()` 把 `tree.import()` 的异常 `ctx.logger.error(error)` 之后**直接 return**（fiber 永不创建），于是 registry 的审计只能报 `math-memory (./math-memory.mjs): never started`；dsh 的启动 stdout/stderr 全文里也只有那一行 URL。
    - **为什么危险**：诊断文本指向"这个插件没起来"，但**不告诉你为什么**；而"没起来"与"起来后抛错"在审计里长得不一样、修法也完全不同（前者是装配/解析，后者看 apply）。若拿报错文本去 grep 模块名，会一条都搜不到。
    - **纪律**：① **门禁不要锚在错误文本上**：判据用"`agentPresets/list` 里有没有无 `broken` 的本 preset" + "`session/create` 是否 `ok:true`"；② 要知道"异步 apply 抛错是会被审计抓到的"（有对照实验：故意让 apply throw ⇒ 审计报 `broken`），所以"全程无 broken"可以当"apply 跑完了"的证据；③ 自己写插件时，装配失败要**主动自述**（照坑 90 的纪律），别指望宿主把它翻译出来。
94. **★ "仓库门禁全绿"不等于"机器上那份是好的"：声明在一个 overlay 里、却不在真正启动的那个里**（2026-09-25，阶段 3 真机验收时抓到）。
    - **形态**：把 preset 迁移做完、`npm test` 全绿之后，真机验收仍然报 `agent-preset/not-found`。原因不在代码：**已部署**的 `$DSH_HOME/profiles/notes-assistant/cordis.patch.yml` 里没有那条声明，而 `--dump-config` 看起来是"好的"（它把各层合起来看）。真正被当作 `--patch` 传进去的是 **`notes-assistant.patch.yml`**——`cordis.patch.yml` 走的是另一条路。**同一个 profile 的两个 overlay 都是真实启动路径的一部分，只在一个里放声明，就还是"认不出来"。**
    - **为什么危险**：仓库侧门禁是**自己铺自己验**（从仓库文件重建一份隔离 home），它证明的是"仓库对"；而真机上那份是**安装/引导写出来的**，两者可以不一致而不被任何仓库门禁发现。这是"夹具替产品撒谎"的又一个变体（坑 56 / 87 同族）：**验证的形状对了，被验证的对象不是现场那个**。
    - **纪律**：① 交付"配置类"改动时，**必须从现场（已部署的那份）再验一次**，不能只用"从仓库重建"的夹具；② 多 overlay 的启动链要**逐个**确认哪一层真的被读（这里靠实跑定位：`--patch` 参数就是答案）；③ 修完把"从现场出发"的验收**固化成门禁**：新增 `test: deployed profile accepts a session (real dsh)`——它从真实 profile 起隔离副本、只回填引导会写的东西，然后真建一个会话；两条路（仓库 / 现场）分开钉，才能各自说话。
    - **附带**：这一轮的临时验收脚本第一版**又踩了坑 91**（往真实工作区表塞了 3 条 `dsh-real-accept-*`，已用 `clean-probe-workspaces.mjs --apply` 摘掉）。教训照旧且更硬：**新探针默认先建隔离 home，而不是"记得清理"**。
    - **另附（工具纪律）**：本轮的文档计数更新一度用 PowerShell `Get-Content -Raw` + `[IO.File]::WriteAllText` 往返，把 `AGENTS.md` 与 `handoff.md` 的中文整篇变成了 mojibake（文件本身仍是合法 UTF-8，所以没有任何门禁发现；是 `git diff` 里满屏 `鈥?` 才暴露）。⇒ **改仓库文本文件一律用 read/edit/write 工具，不要用 PowerShell 把整份读进来再写回去**；`git diff` 中文字符的显示本身不可信（控制台编码），判断编码要看字节与工具读数。

95. **★ "没有调用方的导出"不被任何门禁执行：一个坏模块可以一直躺在发布包里**（2026-09-26）。
    - **形态**：`dsh/preset/preset-deploy.mjs` 的 `presetBodyDeployed()` 用了 `existsSync`，而该文件的 import 行里**没有它** ⇒ 一调就 `ReferenceError: existsSync is not defined`（实测跑过一次）。它从 0.1.7 适配那一轮就写在那儿，注释还写着"给安装器/status 用"。
    - **为什么没被发现**：① `node --check` 只查语法，而 `existsSync` 是运行时名字，语法层看不见；② `gates.mjs` 里没有它的 `--check` 条目；③ **全仓零调用方**——想调它的代码从来没写过，所以没有任何测试路径会碰到它。三条合起来 = "发布包里躺着一段一执行就崩的代码"。
    - **纪律**：① 守卫要**真的执行**导出，而不是只读源码文本：新门禁 `check: preset body lists agree` 直接 `deployPresetBody(...)` 写一个临时目录、再用 `presetBodyDeployedIn(...)` 各问一次，这类坏导出从此必红；② **零调用方的导出要么删、要么有守卫执行它**——"没有调用方"不等于"没有风险"，它只是"没有证据"。
96. **★ "四份清单"的漂移：`install --direct` 少铺两个文件，而门禁把错的布局写成了期望**（2026-09-26）。
    - **形态**：preset 体文件清单（`math-memory.mjs` / `note-tools.mjs` / `hook-frontmatter.mjs`）一度存在**四处**：`preset-deploy.mjs` 的 `PRESET_BODY_FILES`、`obsidian/main.template.js` 的 `DIRECT_PROFILE_FILES`、`dsh/install.mjs` 的 `DIRECT_PROFILE_FILES`、以及生成声明里的相对 `name:`。0.1.7 适配改了 Obsidian 那份与 npm 那条路，**漏了 `install.mjs`** ⇒ `install --direct` 产出的 profile 里声明写着 `name: ./math-memory.mjs`，而那个文件从没被铺进去。
    - **症状与判据（实测）**：`agentPresets/list` 里 preset 带 `broken:"math-memory (./math-memory.mjs): never started"`、`session/create` → `agent-preset/invalid`，**启动日志零告警**。把两个文件手工补进 profile 目录 → 立刻 `ok:true`（对照实验，因果确立）。
    - **为什么门禁没拦住**：`test-installer.mjs` 当时断言的是**已退役**的 `.agent-presets/notes-assistant/*` 布局（preset 解析锚点改成 profile 目录之后没人动这段期望）⇒ **它守着一个已经没人读的目录**，同时给坏通道盖章。而"清单与声明对得上"那条断言只检查 `preset-deploy.mjs` 里有没有那两个字符串，看不到 `install.mjs` 那份缺项。
    - **纪律**：① 一份清单只能有一处**权威**，其余要么派生、要么由守卫比对：现在权威 = `PRESET_BODY_FILES`，判它完不完备的判据是 `dsh/preset/math-memory.mjs` 的**相对 import 闭包**（`check: preset body lists agree`）；② 改一条通道的期望时，**同一提交里**要把断言其它通道的门禁一起改，否则"绿"只说明没人比。
97. **★ bundle 通道的 preset 不能用相对 `name:`：冷启动第一次必坏，第二次就好**（2026-09-26）。
    - **形态**：preset 的模块改成"由宿主行 `apply()` 铺进 profile 目录"之后，`dsh plugin --profile <名> add dsh-math-memory` 的**第一次**启动必然失败：`agentPresets/list` 报 `broken:"math-memory (./math-memory.mjs): never started"`、`session/create` → `agent-preset/invalid`，**而启动日志一行都没有**；第二次启动（文件已在）一切正常。最小复刻里把"铺文件的行使者"放在声明行**之前**那次是通的，所以这**不是**"顺序写没写对"的问题。
    - **根因**：registry 挂载 preset 的 `plugins` 行发生在**声明行激活时**，而那时宿主行**还在 import 自己**（动态 import 是异步的）。任何"宿主先铺文件、声明再解析相对名"的设计都天然有一拍窗口，插件侧关不掉。
    - **修法（实测）**：bundle 通道把 preset 入口行写成**包内 specifier**（`dsh-math-memory/dsh/preset/math-memory.mjs`）——包本来就是 `dsh plugin add` 装进 `profile/node_modules` 的，**不需要任何东西先存在**，冷启动一次就通；同一 profile 名故意不叫 `notes-assistant` 也照样通。离线通道（Obsidian 引导、`install --direct`）继续用 `./name`，因为那两条**在 dsh 启动前**就把体文件写进 profile 目录了。
    - **纪律**：① 判据必须是"**冷启动一次**能不能建出会话"，不能接受"重启一次就好了"；② 两种 name 形态由同一次生成产出、由守卫**分别**钉住（`check: preset body lists agree`），**不要手改生成物**；③ 见到只有一句 `never started` 的报错，先按坑 93 换判据，别去 grep 错误文本。
98. **★ 门禁会退化成 `0/0 断言 + exit 0`，而汇总把它算成"通过"**（2026-09-26）。
    - **形态**：`test: deployed profile accepts a session` 的起点是**机器上已部署**的 profile。2026-09-25 那次整机事故把 `$DSH_HOME` 清掉之后，它的前置条件永久不成立 ⇒ 打印 SKIP 并 `exit 0`、**一条断言都没跑**；而 `run-gates.mjs` 当时**只按退出码统计**，汇总于是报"45/45 gates passed"。真相反过来：它测的那种形状是**唯一没坏的**，另有三种形态全坏（profile 名 ≠ 常量、冷启动第一次、`--direct`），一条都没被覆盖。
    - **为什么危险**：SKIP 与 PASS 在汇总里长得一模一样，而"全绿"是人做判断的依据。更要命的是**门禁越依赖现场就越容易退化成这样**：现场会消失（事故、换机器、CI），而它不会因此变红。
    - **纪律**：① 门禁要**自带前置条件**而不是依赖现场：这条现在自己离线装一份 bundle 形态的 profile（`node_modules` 也是拷的，不联网、不用 pnpm），profile 名**故意不叫 `notes-assistant`**，冷启动一次再建会话——三种坏形态一网打尽；② 汇总必须**三态**（`ok` / `SKIP` / `FAIL`）并**列出被跳过的门禁名与原因**，`__SKIP__ <原因>` 是套件声明跳过的唯一标记；③ 合成型门禁（自己再跑别的套件的那种）**不要回显子套件的 `__SKIP__`**，否则父门禁会被误判成跳过（`check-doc-consistency.mjs` 现在回显前会剥掉该标记）。附带一个容易踩的细节：`\bSKIP\b` **匹配不到** `__SKIP__`（`_` 是词字符，没有词边界），本轮差点因此让 `check-doc-consistency` 直接 FAIL。

99. **★ "防御性兜底"的前提会失效，而它不会因此报错**（2026-09-26）。
    - **形态**：`syncGlobalPackageLinks` 存在的理由是"皮肤管理器把活动皮肤写进 `$DSH_HOME/cordis.patch.yml`，而那个全局层作用于**每一个** profile，所以侧栏 profile 也必须能解析 `@linxin666`"。但 skin-center **0.4.x 已经不再改写那个文件**（它自己的 README 原文：*"no reload, no cordis.patch.yml rewrite, no restart"*），并且它的 legacy bridge 会把 v1 的受管段**清掉**。本机 `$DSH_HOME/cordis.patch.yml` 里确实一行 skin 都没有 ⇒ 镜像的**全部理由**消失了，代码却仍在每次启动时建 18 条目录链接。
    - **为什么危险**：这类"为兼容上游行为而写的兜底"**不会随上游改变而报错**——它只是退化成一个纯副作用：在本机（全局禁止建链接、且刚经历过一次 harness home 全损、目录链接是疑似载体）悄悄建 18 条链接，而且**没有任何门禁能发现"前提已不成立"**，因为门禁测的是"镜像有没有清理干净"，而不是"还要不要镜像"。
    - **纪律**：① 写兜底/兼容代码时，把**它成立的前提**写进注释并给出**可复核的判据**（这里是"`$DSH_HOME/cordis.patch.yml` 里有没有 skin 行"）——下一次适配先跑那个判据；② 兜底要有**退出条件**，不能只有触发条件；③ 退役时**保留仍能独立成立的那部分防御**：机器级 patch 里若还有皮肤行，`buildSkinFallbackBlock` 仍会把它们 `disabled: true` 掉（这件事不依赖镜像）；④ 只为它存在的门禁（`check: mirror cleanup`）与代码一起删，别留着测死代码。

100. **★ 一个"自己报了名、却没报版本"的清单文件，能让整条回复链路全废**（2026-09-26）。
    - **形态**：实机侧栏里**每一轮回复**都失败，报 `本轮运行失败 DeepSeek request extension preparation failed`；会话日志显示 `request/context` 之后约 30 ms 就 `turn/end: error` ⇒ **HTTP 之前**、**没花 token**。真凶是 profile 自己的 `package.json`：它有 `name` 却**没有 `version`**。
    - **为什么危险**：上游唯一抛那句话的地方是 `dsh-llm-deepseek` 的 `prepareRequestExtensions`，它把真正的 `cause` 包在里层（UI 与会话日志**只留外层**）⇒ 从症状读不出病因。而触发链很绕：`dsh-base` 里那个**默认开启**的 `@deepseek-ai/dsh-plugin-package-inventory-deepseek` 请求扩展会解析**每一个活动行**的"归属清单"；**相对路径行**（`./math-memory.mjs`，正是离线通道的形态）走 `nearestManifest()` 一路向上找到了 **profile 自己的 `package.json`**，然后上游的 `identityFromManifest(path, allowAnonymous=true)` 是这么写的：
      `if (allowAnonymous && manifest.name === undefined) return undefined;`（**没有 name = 当作 loose module，放行**）
      `if (!name || !version) throw new Error('… must declare non-empty name and version');`
      ⇒ **有 name、缺 version 就抛**。`web` profile 从不触发，因为它所有行都是裸包名，压根不走那次向上查找。
    - **纪律**：① 症状指向"上游/版本适配"时，先想办法拿到**里层 cause**——本轮最终靠的是"在真 profile 里挂一个包住 `prepare` 的探针插件，把 `cause`/`aggregate`/活动行列成文件"（探针同时**吞掉**失败，用户先能用），比猜三轮都值；② profile 清单这类"我以为是脚手架、其实参与解析"的文件，**只有 name 不够**：脚手架、安装器和插件引导都必须补齐 `version`，且**存量 profile 要能被修复**（`copyFile` 默认保留用户可编辑文件 ⇒ 光改脚手架救不了已装用户）；③ 中途两个"看起来证伪"的实验其实什么都没测——headless profile 里那一行 inject `webServer`/`workspaceRegistry`，没有这些服务就**不是活动行**，而该扩展只看活动行（`fiber.state === 2`）。**"没复现"不等于"不是它"**，先确认实验真的压到了那条路径。

101. **`$DSH_HOME/sessions/` 的目录名是"有损编码"，但**别**用它给会话归因**（2026-09-26）。
    - **形态**：目录名看着像乱码，容易被当成"编码 bug"去修（`docs/handoff.md` §7 那条"mojibake"就是这么写的），
      实测**不是** bug、也**不该**被本插件依赖。
    - **方案本身**（读 dsh 源码确认，`@deepseek-ai/dsh-session-persistence-jsonl/lib/index.js:875-894 projectKey`）：
      `/ \ :` → 单个 `-`；`[A-Za-z0-9._-]` 原样；**其余字符**（中文、`~` 等）→ `~` + `charCodeAt().toString(16)`
      大写补 4 位；结果包成 `--…--` 并**截断到 251 字符**。所以 `小新` 变 `~5C0F~65B0`（不是乱码，是可逆的转义）。
      源码 `:870-871` 自己注明**截断与分隔符替换是"有意有损"的**（human-navigable 惯例）⇒ 两个很长的项目路径
      **可能共用同一个目录**。
    - **为什么不该依赖它**：本插件给会话归因用的是**会话日志头行的 `cwd`** 再 `pathInside(root, cwd)`
      （`dsh/preset/math-memory.mjs:394-405 isVaultSessionLog`）⇒ 目录名怎么编码、是否被截断、是否合并，
      都**不影响**"这场会话属不属于这个 vault"；再加 `selectAuthoritativeLogs` 按会话 id 去重，
      同一会话也不会因目录重复而被计两次。**结论：拿目录名当项目身份是个陷阱**——它有损且可能碰撞。
    - **仍然真实的上游风险**（陷阱 18）：`sessions/` 里若真出现含 `~FFFD~`（U+FFFD 替换字符）的目录，
      dsh 0.1.1-rc.2 会在 session identity 校验时报 `corrupt session log` 并 **boot 失败**；处置是把该目录
      **移出**（备份，勿直接删）。本插件的扫描对读不了的目录是 `try/catch` 跳过，不会因此崩。
    - **本机实测（只读）**：`$DSH_HOME/sessions/` 只有 2 个项目目录、命名规范、含 `~FFFD~` 的 **0 个**
      ⇒ "编码分裂（正确 vs 乱码并存）"在本机**不存在**；写这条时不要照抄旧结论。

102. **★ "重复注册 `/memory-panel` 前缀会让整个 profile 起不来"——在本机 dsh 上复现不出来，别当成既定事实**（2026-09-26）。
    - **背景**：`dsh/client-panel/install-into-profile.mjs` 的注释与 `docs/bundle-channel-plan-2026-09-26.md` 的 S3
      都把 `duplicate prefix route "/memory-panel"` 当作**硬失败**（"整个 profile 起不来"），并据此说"没有这条守卫
      就不能合"。本轮为验证 S3 去真装配，**没能复现**这个硬失败。
    - **实测怎么做的**：隔离 `$DSH_HOME` → 真物化 bundle 包放进 `node_modules` → 用 `--patch` 挂上**仍声明那两行**的
      overlay → 先用 `--dump-config` 确认组合树里**同时**有包的行（`math-memory-host` / `math-memory`）与 overlay 的行
      （`math-memory-workspace` / `math-memory-panel`）→ 再真启动。**结果：启动成功，0 条 duplicate 诊断。**
    - **为什么第一次没测出来（值得记的坑）**：overlay 那两行是**相对名**，而 bundle 通道**只在 `node_modules` 里放包、
      不在 profile 根铺平铺文件** ⇒ 它们以 `failed to import` 告终，**根本没挂载**，自然不撞车。把 `math-memory-panel.mjs`
      的**完整依赖链**补到 profile 根（它需要同级的 `memory-admin.mjs` 与 `hook-frontmatter.mjs`，后者又需要
      `engine-shared.mjs`）后，panel 行**确实 import 成功**，**仍然没有** duplicate 报错。
    - **结论与纪律**：① **不要**再引用"重复注册该前缀 ⇒ dsh 硬失败"作为设计前提；`install-into-profile.mjs` 注释里那次
      历史故障**想必另有条件**，要引用就得先复现。② 结论变了**不代表 S3 白做**：剥掉那两行仍然正确（组合树只声明一份、
      不留死行），只是它是**正确性/整洁性**改进，**不是**阻断性风险。③ 探针**必须自证施加了变异**——我第一版把
      "变异形态"与"S3 输出形态"的 overlay 文本**接反**了，静默测了正确形态并得出"无碰撞"；是靠 `--dump-config`
      打印组合行才发现的（与陷阱 68 同族：**控制用例必须能把现象归因到它自己那一次运行**）。
    - **另一条操作细节**：`dsh --patch` 必须排在 app 参数（`--no-open` / `--port`）**之前**，否则 dsh 已停止解析自己的
      flag，报 `unknown option '--patch'`（仓库里 `test-agent-preset.mjs` 就是这么写的）。

103. **★ `--force` 曾把用户在 `<profile>/cordis.patch.yml` 里写的配置整份吃掉**（2026-09-27 真机，同一机制一天内两次）。
    - **症状**：用户装本插件到 3080 的 `web` profile，随后"自定义模型信息消失了"。
    - **根因**：那个文件是 **profile 自己的、用户可编辑的 dsh patch 层**（用户把自定义 provider 写在这里）。
      `install.mjs` 有四处把 `!existsSync(target) || options.force` 当 `copyFile` 的 overwrite 标志传给
      `PROFILE_DIR/cordis.patch.yml`。而 `--force` 的**本职是通道归属接管**（`assertChannelOwnership`），与这个文件无关
      ⇒ 任何 `install --force` 都会整份替换它。实测：`web` 的层 `988 B → 3738 B`（`15:13:18`），用户的 `llm-pi-ai`
      块随之消失；`notes-assistant` 的层同日 `14:27:45` 同样被换掉。
    - **我们其实早就把契约写下来了**——写在**安装器自己种进那个文件的注释里**
      （`dsh/client-panel/install-into-profile.mjs`）："这一层是 profile 自己的 patch 层，**没有任何人会重写它**"。
      所以这不是设计分歧，是**自己违反自己的契约**。
    - **修法**：新增 `ensurePosture()`，四处调用点全部改走它：**只在缺失时铺脚手架**，存在就原样保留（并打 `[keep]` 行），
      通道需要的声明增删仍由本来就会保留用户行的 `stripPresetDeclaration` / `ensurePresetDeclaration` 精确完成。
      **关键细节**：真正防住数据丢失的是 `copyFile(..., false)`，不是那句 `if (existsSync)` 提前返回
      ——变异验证时把提前返回去掉，文件**依然安全**（只是不再出声），把标志位改回 `options.force` 才会丢数据。
    - **门禁**：`test-installer.mjs` 新增 11 条（helper 保持 `--force` 不改写 / 逐字节不变 / 出声 / 真 CLI 端到端 /
      缺失时仍铺且与仓库一致 / `--dry-run` 不写 / **源码里不许再出现 `cordis.patch.yml` 与 `options.force` 同行** /
      四个调用点都走 `ensurePosture`）。**变异验证**：还原成原始形态 ⇒ **5 条红**（含两条数据丢失断言与 CLI 端到端）。
    - **教训**：一个 flag 同时兼职"接管归属"与"覆盖文件"两件事时，**"用户数据"是它顺手碾过去的那一类**。给可写配置加
      overwrite 参数之前，先问"这个文件到底是我的还是用户的"。
    - **顺带记录（未修）**：同一批 `copyFile` 对 `package.json` 也传了 `firstRun || options.force`（3 处）。profile 的
      `dsh.profile.bundles` 里可能有用户自己加的行，**这是同一类风险的候选**，本轮未查未改，别当成已解决。

104. **★ 本地工作副本的行尾**可以**和提交的内容不一样**，而 `git status` 一声不吭 —— 于是"本地全绿、CI 全红"（2026-09-27 实测）。
    - **症状**：把积压的 129 个提交推上去后 CI 红；同一个门禁在本机跑是绿的。失败的只有一条：
      `no drift …\profiles\notes-assistant\cordis.patch.yml`（`test: installer e2e`）。
    - **根因**：仓库里这个文件的行尾是 **CRLF**（无 `.gitattributes`；实测 267 个受版本控制的文件在 blob 里都是 CRLF），
      而本机工作副本里它恰是 **LF**。本机 `core.autocrlf=true` ⇒ **比较时两边都被规范化**，
      所以工作副本字节不同而 `git status` 仍然干净。声明修复函数又把 `"\n"` 写死：
      `stripPresetDeclaration` 的空白行折叠**匹配不到** CRLF 的连续空行（`\r\n\r\n\r\n` 每对之间都有 `\r`），
      append 路径则把 LF 块接到 CRLF 文档上 ⇒ 实测 `9849 → 9726` 字符、**行尾混用**（79 CRLF + 123 LF）。
      本地(LF)往返是恒等的，CI(CRLF)不是 ⇒ drift 断言只在 CI 红。
    - **怎么复现 CI（这条方法比结论更值钱）**：`git archive` 取出**受版本控制的那棵树**（不含任何被忽略的本地文件），
      复制 `node_modules` 后在里面直接跑套件 —— 那就是 CI 拿到的文件集合。本机 `git clone --local` 会因硬链接失败而不可用。
    - **纪律**：① **不要拿本地文件的行尾当事实**——门禁要**显式喂 CRLF**（本次新增的 6 条就是这么写的），
      断言仓库自带文件等于跟着 checkouts 漂移；② 生成/改写配置的函数**不许写死行尾**，要么探测、要么保持；
      ③ "本地绿、CI 红"优先怀疑**文件集合与字节**的差异，而不是代码逻辑差异。
    - **修复**：`lineEndingOf()` / `withLineEnding()` + 两处修复函数改为行尾保真（LF 下结果逐字节不变）。变异验证：
      把 `lineEndingOf` 改回写死 `"\n"` ⇒ **恰好 3 条 CRLF 断言红**（LF 三条仍绿），数字与事故现场一致（9849→9726、crlf 202→79）。

105. **★ 只在 Windows 成立的"测试缝"等于在 Linux 上是空过**——`spawnSync` 报"工具缺失"的形态**按平台不同**（2026-09-27 实测）。
    - **症状**：Ubuntu CI **连续三轮**都只有一条红，Windows 同一提交全绿：
      `[FAIL] S4 fallback: it SAYS it fell back, with the reason`，细节是
      `[fallback] 本地包化未成功（dsh not found on PATH）⇒ 回落到平铺通道`。
    - **根因**：`tryBundleInstall` 先判 `result.error` 再判那条测试缝。而 `spawnSync("dsh", …, { shell: process.platform === "win32" })`：
      **Linux 上 `shell:false` ⇒ 返回 `result.error`（ENOENT）**；**Windows 上 `shell:true` ⇒ cmd 起得来，只有退出码非零**。
      于是没有 `dsh` 的机器上，**Linux 走 ENOENT 提前返回，永远到不了 `DSH_TEST_UNREGISTER_BUNDLE` 那条缝** ——
      这条缝本来要用变异证明"判定来自文件系统而不是退出码"，在 Linux 上**一次都没比过**；而断言又要求理由里出现
      `DSH_TEST_UNREGISTER_BUNDLE|not registered`，于是 Linux 报红、Windows 报绿。
    - **纪律**：**测试缝必须排在任何环境相关的提前返回之前**，否则它在某些平台上静默失效（正是本仓库反复删掉的
      "空过"形状，见 AGENTS.md §6「没有用例走到的分支，不算被测过」）。判据不要依赖 `spawnSync` 的**形态**
      （`error` vs `status`），那是平台方言。
    - **复现办法（本机就能做，不必等 Linux）**：把 `install.mjs` 里三处 `shell: process.platform === "win32"` 全改成
      `shell: false`（= 模拟 Linux 分支），并把 `Roaming\npm` 从 `PATH` 里去掉（= 模拟 CI 没有 `dsh`/`pnpm`）。
      于是：**修复前** ⇒ 恰好 1 条红、细节字符串与 Ubuntu 注解逐字相同；**修复后** ⇒ 全绿。
    - **修复**：把 `const forcedUnregistered = …` 提到 spawn 之前，并写成 `if (result.error && !forcedUnregistered)`。
      附带发现：`run-gates.mjs` 失败时只打**尾 25 行**，而这条红排在约 470 条通过断言之前 ⇒ **报告失败却报不出是哪条**；
      连 CI 注解也救不了（截断发生在 run-gates 内部，`[FAIL]` 行从未到达 stdout）。已改为**先打印所有 `[FAIL]` 行**再打尾部；
      workflow 的 `::error::` 窗口也从 2500 字符放宽到 6000。**诊断信息不该把失败藏起来**。

106. **★ `install --force` 也吃掉过 profile 的 `package.json`**——与陷阱 103 同源、同一天，且是**这一类的最后一处**（2026-09-27）。
    - **症状**：一个自己加过东西的 profile，跑 `install --direct --flat --force` 之后，`dsh.profile.bundles` 里用户加的
      `user-custom-bundle`、`dependencies` 里的 `some-user-plugin`、`scripts`、以及一个自定义顶层键**全部消失**
      （实测 `371 → 304` 字符）；而且 `name` 变成脚手架里写死的 `dsh-profile-notes-assistant` —— 往 `web` 装也自称是
      notes-assistant 那个 profile。
    - **根因**：三处把 `firstRun || options.force` 当 `copyFile` 的 overwrite 标志传给
      `PROFILE_DIR/package.json`（`nativeInstall` / `tryBundleInstall` / `directInstallProfile`）。
      `--force` 的本职是**通道归属接管**，与这个文件无关 —— 与陷阱 103 一模一样的形状。
    - **仓库其实早就知道这文件是用户的**：`repairProfileManifest` 的注释称它为 "the one file a user may have edited by
      hand" 并为它守住了 `--dry-run`；卸载路径也守住"手改过的 posture 不删"。**三条路径守了两条，`--force` 这条没守。**
    - **关键实测（修复的安全性依据）**：模板拷贝对**已有** profile 是**多余**的。在"今天本来就会跳过拷贝"的路径上
      （已有 profile、不加 `--force`、走真 bundle 通道 + pnpm）实测：`dsh-math-memory` 照样被注册进
      `bundles`，用户那条 `user-custom-bundle` 也还在。所以去掉 `|| options.force` 是**构造上安全**的。
    - **修复**：新增 `ensureProfileManifest()`（与 `ensurePosture` 同形）——**缺失才铺脚手架，存在则保留并打 `[keep]`**；
      三处调用点共用它，其返回值天然就是原来的 `firstRun`。顺带修掉写死的 name：新建时按
      `dsh-profile-<profile 目录名>` 推导（与 `repairProfileManifest` 已有的规则一致；对默认 profile 结果不变）。
    - **门禁**：`test-installer` 新增 11 条（真 CLI `--force` 后用户四项**全在** / 仍自称自己 / 安装器自己的依赖**仍被追加** /
      出声 / 缺失时仍铺且 name 按目录推导 / `--dry-run` 不写 / **源码里不许再出现 `package.json` 与 `options.force` 同行** /
      三个调用点都走 `ensureProfileManifest`）。**变异验证**：还原成原始形态（去掉 keep-guard + 标志位改回
      `options.force`）⇒ **3 条红**（两条数据丢失 + 一条结构性）。注意：**只**去掉 keep-guard 是**测不出来**的
      —— 真正防住的是 `copyFile(..., false)` 这个标志位（与陷阱 103 记的同一条教训）。
    - **纪律**：给"可写配置"加 overwrite 参数之前，先问"这文件到底是我的还是用户的"；`--force` 只做归属。
      `install.mjs` 里**仅存**的 `options.force` 文件写入就是这三处，其余（`assertChannelOwnership` / 卸载判定）
      都不碰用户文件 —— 这一类到此为止。

107. **★ npm 拒绝发布"比当前 `latest` 更低"的版本**——所以版本一经发布就**不能往回改**（2026-09-27 实测，代价是一整轮改号作废）。
    - **怎么撞上的**：0.8.0 已发布后，用户判定本批以修补为主、要求改成 `0.7.9`。GitHub 侧清干净了（删 Release + tag），
      npm 侧也想"留着 0.8.0 当孤儿、把 0.7.9 发成 latest"，结果 `npm publish` 直接被拒：
      ```
      npm error Cannot implicitly apply the "latest" tag because previously published version 0.8.0
                is higher than the new version 0.7.9. You must specify a tag using --tag.
      ```
    - **含义**：npm 不会隐式把 `latest` **倒退**。要走下去只有两条：① 显式 `--tag latest`（绕过这道守卫，但会在 registry 里
      **永久**留下一个更高的孤儿版本，且此后每次发布都要显式覆盖一步安全检查）；② 先 `npm unpublish`（见下）。
      **结论：发布过的版本号就是事实，改动它是逆着 registry 走的**，除非愿意付上面两种代价之一。
    - **unpublish 只能人工做**（本次实测到底）：npm **没有网页入口**，只有 CLI `npm unpublish <pkg>@<version>`
      （72 小时内；单版本不需要 `-f`，**加 `-f` 或省略版本号会删掉整个包**）。它要求**登录 + 2FA**，本机 `~/.npmrc`
      **没有任何 token**（`npm whoami` → `ENEEDAUTH`）⇒ 自动化不了。**OIDC trusted publishing 也不行**：我用它换到了凭据，
      但 registry 在授权层拒绝 —— `400 Bad Request ... OIDC publish authorize: Invalid request`
      （**trusted publishing 只授权 publish，不授权 unpublish**；那是 npm 侧的策略，不是配置错误）。
    - **纪律**：① 发版前把版本号想清楚，"先发再改号"不是可逆操作；② 想知道发没发出去**只看 registry**，
      `npm view` 的本机缓存会骗人（要用带 cache-buster 的直连查询）；③ 判据别信 `Publish` 步的绿 —— 它是
      `continue-on-error`，真正的判据是 `Confirm the registry state`（本次正是它抓住"npm 拒绝了"，并把 npm 的原话写进 issue #7）。
    - **顺带一条可复用的手法**：npm 的失败原文会进 **issue**（job 日志要 admin 权限才能读，issue 不需要）——排查发布问题时**先读 issue**。

108. **★ 只冻结"只有我们会写"的文件的字节**——把别人也会写的文件做哈希冻结，等于**按插件自己的指示操作就会永久飘红**（2026-10-01 实测）。
    - **怎么撞上的**：安装清单给**每一个** posture 文件记 sha256 并当硬校验。其中 `cordis.patch.yml` 被同一个安装器
      在 650 行之外定义为"用户的层、永不重写"，而 **dsh 自己的设置面板按设计就重写它**：
      `@deepseek-ai/dsh-config-editor` 把整份文件重新序列化后追加自己那一行（`:23-26` / `:105-109` / `:123`）。
      本机记录 `733715c9…`、现存 `69ea710a…`，13 个文件里**只此一个**不符 ⇒ 门禁 53 唯一那条红。
    - **形态特征（认得出来就能立刻定性）**：不是人手编辑的样子 —— 安装器写的 `3738 B` 被 YAML 重新序列化成 `3749 B`
      （只有 2 条长 `!!js` 标量在默认 80 列处折成 4 行），再加 `774 B` 的 3 行新配置。
      **同类但更隐蔽的一条**：`cordis.yml` 由 dsh **每次**组合 profile 都重写成 `[]`（`--dump-config` 就会写）——
      **字节相同所以摘要不红**，但字节归 dsh 所有，一旦上游改一次排版就会红成同一形态。
    - **纪律**：判据是**"谁还会写这个文件"**，不是"谁创建了它"。共享清单住在
      `dsh/preset/profile-contract.mjs` 的 `POSTURE_SHARED_FILES`，**每条必须带实测到的第二写入方**，
      没有第二写入方的文件**不许进来**。共享文件不冻结摘要、卸载时**无条件保留**
      （"仅在漂移时保留"会在**未改动**时把它们删掉 —— 那正是 2026-09-26 丢配置的同一类）。
    - **守卫形态**：两个 manifest 写入方（CLI 与 Obsidian 模板）此前**没有任何比对**。`check-profile-contract.mjs`
      的 `PINNED-7` 把模板那个函数**从 `main.js` 里取出来真求值**，拿同一份 profile 与 CLI 实现逐文件比摘要 ——
      **不要**改成比对源码文本（那只能钉住写法）。

109. **★ dsh 0.2.0 起 `$DSH_HOME/cordis.patch.yml`（home 层）压过 profile 自己的层**（2026-10-01 读源码 + 实测，本机当前无冲突）。
    - **含义**：home 层与 profile 层若有**同 id** 的行，home 层**静默赢**（`profile-boot`, `:192-198`）。
      插件把 `permission` / `approval` / `sandbox-policy` / `fs-sandbox` 写在 **profile 层** ——
      用户在 home 层写同名 id 就会**静默覆盖**它们，而没有任何东西会报错。
    - **第二条连带**：配置编辑器现在会**拒绝保存**被 home patch 覆盖的行（`dsh-config-editor/lib/index.js:122`，
      `Configuration for "<id>" is overridden by a home patch or command-line overlay`）。
      它**堵住了** §7 里那条 C1（把 Obsidian 开关搬到插件 `Config`）——那条本就未拍板，现在多一条反对理由。
    - **本机现状**：`~/.dsh/cordis.patch.yml` 只有一条 `- insert:` 的 `pretooluse-guard` 行，**不覆盖任何 id**。
    - **要做的事**：属产品决策（要不要在启动时检测 home 层与插件同 id 的行并提示），已记 §7。

110. **★ 断言被"硬编码路径 + 静默跳过"变成假绿**——门禁报 `9/9`，实际动态校验**整块没跑**（2026-10-01 实测）。
    - **怎么撞上的**：两个工具套件里**唯一**调用 dsh 校验器的断言，都 gate 在
      `<DSH_HOME>/profiles/node_modules/@deepseek-ai/dsh-tools/lib/index.js`。本机实测：
      `~/.dsh/profiles/node_modules/…` **False**、`…/profiles/notes-assistant/node_modules/…` **False**、
      `%APPDATA%\npm\node_modules\@deepseek-ai\dsh\node_modules\@deepseek-ai\dsh-tools\lib\index.js` **True**
      ⇒ `npm i -g` 装的 dsh 把内置包放在**全局安装内部**，那些断言全部 `[skip]`。
    - **为什么危险**：`output.schema` 还能过**宿主自带的**校验器，正是"宿主升级后工具契约仍成立"的**唯一动态证据**。
      一个会静默跳过的检查**无法为任何宿主版本作证** —— 与坑 98（0/0 断言 + exit 0）同族，
      但更隐蔽：套件**内部**的分块跳过不会反映到汇总的 `passed/total` 上。
    - **纪律**：① 解析路径要**按候选顺序试**（含 npm 全局安装内部），并给显式覆盖变量；
      ② 找不到时**大声 SKIP 并打印试过的路径**，不要让它看起来像通过了；③ 新变量要同步 `docs/env-vars.md`
      （那条守卫双向，本次先红了一次才补上）。
    - **修后**：`22/22` + `11/11`（修前各 `9/9` 且动态块跳过），且是拿 0.2.0-rc.2 **自己的**校验器跑的。

111. **★ JS 正则里 `$` 在无 `m` 标志时也匹配"尾随换行之前"，`replace` 会**悄悄吞掉行尾**（2026-10-01 自己踩的，症状很能骗人）。
    - **怎么撞上的**：写 `migrateRetiredPresetRow` 时用 `/^(\s*)-\s*id:\s*…['"]?\s*(\r?\n)?$/` 去匹配**仍带 `\n` 的行**。
      `$` 在 `(\r?\n)?` **之前**就匹配成功 ⇒ 那个捕获组不被消费 ⇒ `replace` 的输出**少了换行**。
      实测症状：断言 detail 打印 `renamed`（函数确实改了文件、`migrated === true`），但
      **行数从 14 变 12**（该少 1 行却少了 2 行）——只看"改没改"完全看不出来。
    - **纪律**：**在剥掉终止符的行体上匹配**（先 `line.replace(/\r?\n$/, "")`，改名后再把终止符拼回去）；
      或者给正则加 `m` 标志并让 `$` 明确落在行体末尾。任何"按行改写文件"的代码都该有一条**行数守恒**的断言。
    - **顺带**：这条同族的教训是"函数返回 true ≠ 文件正确"，所以新加的迁移测试同时断言
      **改名成功 / 丢掉失效键 / 其余逐字节保留 / 行数只少 1 / 幂等 / 相似 id 不碰**。

112. **★ dsh 的版本范围不许"顺手整理"成 `>=0.2.0` / `^0.2.0`**——在 prerelease 运行时上它**不匹配**，插件会被**静默停用**（2026-10-01 隔离实测）。
    - **机制**：兼容门禁只读 `peerDependencies` 里 `@deepseek-ai/dsh` / `@deepseek-ai/dsh-*`
      （`dsh-app-boot/lib/index.js:294`），用 `semver.satisfies(…, { includePrerelease: true })` 比对（`:300`）；
      **整个 key 不存在 = 完全不检查**（`:289`）；`dsh.engines.dsh` **门禁根本不读**（全库零命中）。
      ⚠️ **0.2.1 起口径变化**：门禁改为**优先读顶层 `engines.dsh`**（`dsh-app-boot/lib/index.js:280-285`），
      有它就忽略 peers；嵌套的 `dsh.engines.dsh` 仍然无人读（见陷阱 119）。本仓库现在两处同值声明。
    - **隔离 `DSH_HOME` 实测**：`>=0.2.0` ✗、`^0.2.0` ✗（都跳过）、`>=0.2.0-rc.2` ✓、`>=0.1.7-rc.2` ✓。
    - **失败信号很弱，必须认得**：不兼容**不会**让 dsh 非零退出 —— 它是 **exit 0 + stderr 一行**
      （`dsh: skipping profile bundle …`）**+ 组合结果被掏空**。只有 `--dump-config-schema` 会 exit 1。
      真实启动时还有**第二道更严的按行门禁**（`dsh: disabling profile plugin row …`），
      **`--dump-config` 看不到它**（dump 从不挂 Loader）。
    - **例外通道**：`dsh plugin --profile <p> allow-version <pkg>@<ver> --dsh-version <exact> --accept-risk`
      写 `<profile>/compatibility.json` 后即可放行（实测无需联网、无交互）。

113. **★ 判据"看不见自己的输入"，于是它永远发现不了它要抓的东西**——新加的"共享上游不算共证"判据**跑得通、测得过**，却**结构上不可能**命中（2026-10-01，C8）。
    - **两个同时存在的缺陷**：① 证据池条目建成 `{ rel, text }`，而判据要读候选文档的 `source`/`related`
      ⇒ `other.source` 永远是 `""`；② 计算"共享上游"用的链接访问器只读 `source`/`related`，而 `extractLinks`
      当时是 `buildAuditReport` 里的闭包 ⇒ `depends_on` 在这条路径上**根本看不见**。
    - **为什么危险**：它不会报错、不会红，只会**恒返回"没有共享上游"**——即"两层防御都不会打架"，
      而人的直觉会认为"我加了这条判据，所以它被守住了"。这正是本仓库"断言在变异下照样通过"那一族：
      **守卫看不见自己的输入**（同族：`cardRef` 少带 `uses`/`successRate` 导致 weak 自检每张卡都触发）。
    - **纪律**：加**任何**"读某字段做判断"的逻辑，先写一句**断言这个字段真的被读到了**——
      最省事的形态是**成对测例**（同源必须不升级 + 独立来源必须升级），因为只写"同源不升级"的话，
      "判据根本没跑"和"判据跑了并拒绝"给出**完全一样**的结果。
    - **顺带**：`extractLinks` 已提为模块级（两处共用同一提取，`depends_on` 一并纳入），
      证据池补 `provenanceOfDocument`。

114. **★ 收集结果的数组在"收集之前"就绑定了，于是发现被静默丢弃**（2026-10-01，C7）。
    - **形状**：`origin` 的越权声明先由 `originBlocked` 收集，`structural` 对象**稍后**才 `= { …, unauthorizedOrigin: [] }`
      ⇒ 那个空数组才是 `structural.unauthorizedOrigin`，收集到的东西**从未接上**，
      `counts.originUnauthorized` **恒为 0**、`sections.originUnauthorized` 恒为空。
    - **症状很能骗人**：卡上确实写着 `origin: user`、成员数组里确实有那条字符串，
      但报告与计数是空的——**"我明明 push 了"**。实测由新测例（断言 `counts.originUnauthorized === 1`）抓出。
    - **纪律**：**同一个事实不要有两个数组**。要么让后续结构体**引用**那个数组（现在是 `unauthorizedOrigin: originBlocked`），
      要么在结构体定义之后才收集。写完这类"收集 → 汇总"的两段式代码，**回头看一遍谁指向谁**，
      并让断言读**最终报告**里的字段（而不是读你刚 push 的那个变量）。

115. **★ `--dry-run` 在"最可能丢数据的文件"上说了反话**（2026-10-01，装 0.8.1 时踩到）。
    - **形状**：`copyFile(options, src, dst, overwrite = false)` 先判 `dryRun` 再判 `!overwrite && exists`，
      于是 dry-run 对**每一个**目标都打印 `would copy`，而真跑对已存在目标是
      `[skip] exists, preserving user edits`。**实测**（临时 vault 里预置 `profile.md`）：
      dry-run 输出 `would copy … profile.md`，真跑输出 `[skip] exists …`，文件**逐字节未变**。
    - **为什么这条特别坏**：`--dry-run` 的**唯一用途**就是让人在动手前确认"会不会覆盖我的东西"。
      它偏偏在 `profile.md`（用户画像）/ `notation.md`（记号表）/ `AGENTS.md`（协议）这几处——
      **整个安装过程里唯一有丢数据风险的文件**——给出了与真跑相反的承诺。我是**因为部署前先列了目标文件现状**
      才没被误导；只看 dry-run 会以为要覆盖 19 个文件。
    - **纪律**：**dry-run 必须与真跑走同一套判定、同一顺序**，只在"动作"那一步分叉。
      任何"预览/预演"实现都该有一条断言：**模拟与真实对同一输入的结论一致**。
      修法是把 `!overwrite && exists` 提到 `dryRun` 之前，并打印 `[dry-run] would skip`。

116. **★ 启动守卫拒绝了自己写下的配置**（2026-10-14，用户报障）。
    - **形状**：侧栏引导**成功**走过 A′ 的"机会式包化"后，会把 profile 的 `.install-manifest.json` 写成
      `owner: npm` + `bundleSource: local`；而它**下一次**启动的冲突守卫只比 `owner` 一个字段，
      `npm !== direct` ⇒ 判定"别的通道拥有此 profile"并抛错。**插件拒绝了自己上一轮写下的配置**：
      每次开 Obsidian 弹一条红字，而 dsh 本身照常可用（配置早已铺好，只是不再被引导）。
    - **附带损害（比弹窗更坏）**：抛错点在 `onLayoutReady` 的**同一个 `try`** 里，`bootstrapVaultTemplates()`
      排在 `bootstrapDshConfig()` 之后 ⇒ 只要归属是 `npm`，**vault 模板自愈全程不执行且静默无声**。
      用户看得见的是一条噪声，看不见的是自愈已经死了。
    - **为什么门禁抓不到**：`check-bundle-recovery.mjs` §7 只跑**一次** bootstrap 就断言 `owner=npm`；
      §3 的幂等用例跑在平铺通道上（`owner` 始终 `direct`）⇒「包化成功之后的第二次启动」这一格从没被测过。
      **纪律：幂等用例必须跑在"第一次就换了通道"的那条分支上**，否则它测的是另一条路。
    - **纪律**：**凡"读一份本方自己会写的状态文件"的守卫，判据必须与本方写入的字段集合一致**。
      只读 `owner` 而写 `(owner, bundleSource)` 就属这类不一致；判据已按 A4 拍板改成二元组
      （`docs/pending-decisions-2026-09-26.md` §1 A4=①，其代价一栏写的就是"三处守卫改判据"）。
    - **另一处同类耦合**：`check-bundle-recovery.mjs` 的 `HARNESS_PRELUDE` **手工镜像**模板顶层常量。
      在模板里新增顶层 `const` 却忘了镜像 ⇒ 抽出的 `bootstrapDshConfig` 每个用例都
      `NPM_CHANNEL is not defined`（实测：拿 HEAD 版门禁跑新版 `main.js` = 6 条红）。
      **新增模板顶层常量时，必须同步 prelude。**

117. **★ preset 体文件清单在"preset 自己长出新 import"时静默过期**（2026-10-15，解耦第 3 步踩到）。
    - **形状**：`engine-shared.mjs` 从"只有宿主半用"变成"preset 也用"（新增的
      `RETRIEVAL_STATS_*` 常量要两个引擎共享，所以它是唯一该放的家），而
      `scripts/test-agent-preset.mjs` 里那份**手写**的
      `['math-memory.mjs','note-tools.mjs','hook-frontmatter.mjs']` 没跟着长 ⇒ 探针 home 少了
      一个文件 ⇒ `dsh/preset/math-memory.mjs` 解析不到 `./engine-shared.mjs` ⇒
      **`agent-preset/invalid` / `math-memory (./math-memory.mjs): never started`**。
    - **为什么难发现**：症状就是本仓库第一类静默故障（"点新建会话没反应"，boot 日志无内容），
      而**同一提交里五条 `check: preset body lists` 类门禁全绿**——因为它们比的是
      `PRESET_BODY_FILES`（契约）与 import 闭包，**不看这份探针拷贝**。
    - **纪律**：探针里任何"手写文件清单"都要**与契约比对**，不要只与自己比。已改：
      该断言现在断言 `PRESET_BODY_FILES`（从 `dsh/preset/profile-contract.mjs` import）
      的每一项都存在，少一项立刻报出是哪个名字。
    - **教训归属**：这正是坑 96 的形态（"同一批事实存在多处副本"）在**测试夹具**上的复现——
      上一次是生产代码里的四份清单，这一次是探针里的第五份。

118. **★ "把 ESM 模块 require 进来"这个理由会随运行时版本腐烂；而"要不要真机"本身也可能是个可查的问题**（2026-10-15，解耦第 6 步核实）。
    - **形状（同一处，栽了两次）**：写"插件为什么必须用 `new Function` 求值 `memory-admin.mjs`、
      而不能直接 `require()` 它"时，
      **第一次**写的是"CJS 里 require 一个 `.mjs` 会抛 `ERR_REQUIRE_ESM`" —— 本机
      Node 24.14.1 实测 `require('./mod.mjs')` **成功**，这句被推翻；
      **第二次**改口成"宿主是否支持 `require(esm)` **本机无法判定，需要真机证据**" ——
      **这也是错的**：`require(esm)` 默认开启始于 **Node 20.19.0**
      （[发布说明](https://nodejs.org/en/blog/release/v20.19.0)，2025-03-13；v22/v23 默认，
      此前 v20 需 `--experimental-require-module`），而 **Electron 25.0.0 捆的是 Node 18.15.0**
      （[Electron 25.0.0](https://www.electronjs.org/blog/electron-25-0)）。本插件
      `minAppVersion` 是 **1.4.0** ⇒ **在其支持的运行时上这条路根本不存在**，
      不需要任何真机。
    - **两条纪律**：① 凡是要写"运行时为什么做不到 X"，**先在当前运行时上跑一次那个操作**
      （本例 6 行探针：`dep.mjs` + `mod.mjs` + 一个 `require` 它们的 `.cjs`）；
      **② 但"本机实测"证明的是开发机，不是交付目标** —— 决定能不能用的是**宿主/目标运行时**
      的版本，而它通常能从**权威发布说明**查到。把"需要真机证据"当结论下得太早，
      会**挡住一个其实能查清的问题**（这次就是这样）。
    - **顺带记下真正的失败模式**（探针给出）：把兄弟依赖 `./dep.mjs` 删掉 ⇒
      **`ERR_MODULE_NOT_FOUND`**，即"能不能 require 取决于相对 import 闭包是否都躺在
      可解析的磁盘路径上" —— 这也正是 loader 把 `engine-shared.mjs` 拼进同一求值体的理由。
    - **教训归属**：与坑 79 同族（"报告是线索不是事实"）——**语言/运行时的能力边界也会过期**；
      再叠一条：**"这需要真机"这个判断本身也要先查一遍**，它不是免于取证的通行证。

119. **★ 兼容门禁读的是**顶层** `engines.dsh`，而"看起来像声明"的嵌套 `dsh.engines.dsh` 没有任何读者**（2026-10-18，0.2.1 适配取证）。
    - **形状**：dsh 0.2.1 的 `unmetRequirements` 先看 `Object.hasOwn(manifest.engines, "dsh")`
      （`dsh-app-boot/lib/index.js:280-285`），**有它就只用它、忽略 `peerDependencies`**（`:286-297`）。
      本仓库从 0.1.7 起把范围写在 **`dsh.engines.dsh`**（`package.json` 的 `dsh` 段内），
      而 0.2.1 全库对**嵌套**字段零命中 ⇒ 它一直是装饰品；真正生效的只有 peer。
    - **为什么危险**：它**不报错**（门禁回退到 peer，而 peer 恰好同值），于是"声明写在哪个字段"
      看起来无关紧要；直到某天门禁只认 `engines.dsh`、或两个值漂移，插件才以
      `skipping profile bundle`（exit 0 + 一行 stderr）**静默停用**——与陷阱 112 是同一族失败形态。
    - **修法/纪律**：范围**同时**写进顶层 `engines.dsh`（0.2.1+ 门禁）与 `peerDependencies`
      （0.1.7–0.2.0 门禁），两者必须同值。守卫：`check-version-consistency.mjs` 与
      `check-plugin-manifest-meta.mjs` 都断言这两条。**生成物也一样**：`local-bundle.mjs` 与
      `main.template.js` 的物化 manifest 同时写两处，A′ 包才能在两种宿主上都过。

120. **★ 0.2.1 的 `working_directory`/`cd` 只改"当前目录"，不是换工作区——vault 锚点不许跟着它走**（2026-10-18，0.2.1 适配取证；第一版改错后回退）。
    - **上游事实**：`session.header.cwd` 是"会话创建时的工作目录"（`dsh-session` 类型注释：
      *Absolute working directory the session was created in*）。0.2.1 新增 `workingDirectory`：
      `cd` 只更新 session projection（`working-directory/change`），`header.cwd` 不变
      （`dsh-working-directory/lib/index.js:30-40,76-78`）；`dsh-base` 默认挂载该工具
      （本机 `--dump-config` 实测第 109-112 行）。`dsh-tool-fs` 用它解析**相对路径**
      （`dsh-tool-fs/lib/index.js:172`），绝对路径与沙箱根不受影响。
    - **为什么不能"跟随"**：本插件的 vault 是**工作区级**的（`resolveWorkspaceRoot`：
      config → `DSH_WORKSPACE_ROOT`/`DSH_OBSIDIAN_VAULT` → 会话创建目录），历史会话归属
      （`isVaultSessionLog`）也按日志头 `header.cwd` 判定。若改用投影，`cd` 进 vault
      子目录就会把**子目录**当成 vault（`.deepseek/` 找不到 ⇒ 注入退化成"未配置"），
      `cd` 到别处更会换库——比"停在原 vault"更糟。
    - **第一版是怎么错的（留证）**：审计把"模型看到的当前目录变了"当成"插件应当跟随"，
      于是加了 `effectiveSessionCwd()`（优先投影、回退 header）。回退理由不是测试失败
      （那条自证测试当然绿），而是**语义**：`working_directory` 的 README 明说
      "当前目录消失时…恢复到**原始项目**"——原始项目 = 工作区。
      ⚠️ 教训：给"要不要跟随新状态"下结论前，先确认新状态属于**哪个层级**
      （工作区 vs 工作区内位置）。
    - **Obsidian 模式更不受影响**：侧栏启动时总是注入 `DSH_OBSIDIAN_VAULT`
      （`obsidian/main.template.js:1689`），而 `resolveWorkspaceRoot` 的环境变量优先级高于
      cwd ⇒ `cd` 不可能改变 vault；只有"裸 CLI 从 vault 目录启动"才走到 cwd 分支，
      那里"vault = 会话创建目录"才是对的。
    - **纪律**：若以后要支持"换库"，应走显式配置或新会话，不要把瞬态 cwd 当 vault。

121. **★ Windows junction 的 `lstatSync().isSymbolicLink()` 会返回 `false`——清理临时 home 时删掉了真实 profile 的 `node_modules`**（2026-10-18，跑全量门禁时实测踩到）。
    - **形态**：`scripts/test-agent-preset.mjs` 用 `seedIsolatedHome()` 把临时 `$DSH_HOME/profiles/notes-assistant/node_modules` 建成指向**真实 profile** 的 junction（读真实依赖、写临时 home）。跑一次 `npm test` 后，真实 profile 的 `node_modules` 变成空目录（实测 **6 项 → 0 项**，mtime 正好落在该门禁结束时）；随后同一门禁报 `GET /memory-panel/state → 404`（bundle 与客户端包都解析不到），看起来像"记忆面板坏了"，实际是部署状态被探针清空。
    - **根因**：`removeIsolatedHome()` 用 `lstatSync(p).isSymbolicLink()` 判断链接。本机 Node 24 上，对 `symlinkSync(target, link, 'junction')` 建出的目录联接：`lstatSync` 返回 `{ isSymbolicLink: false, isDirectory: true }`，而 `readdirSync(parent, {withFileTypes:true})` 的 dirent 返回 `isSymbolicLink: true`（`readlinkSync` 抛 `EINVAL`）。于是 walk **递归进了 junction 目标**，把真实 `node_modules` 的内容逐个 unlink，再删掉联接本身。
    - **修法**：清理函数改用 **dirent 判定**（`readdirSync(dir, {withFileTypes:true})` + `entry.isSymbolicLink()`）；链接只摘链接本身，绝不进入目标。验证：修复后同一门禁 **26/26**，真实 `node_modules` 前后都是 **6 项**（`dsh-math-memory` 仍可解析）。
    - **纪律**：**任何递归删除/拷贝都要按 dirent 判定链接**（`deploy-local.mjs` 的 `safeCopyTree` 也用了 lstat，只因目标目录里没有 junction 才没踩到）；"用 lstat 就够了"在 Windows junction 上不成立——要**在本机实测**，不要照文档推断。

