# 未做 / 下一步候选（Backlog）

> 只收**还没做完、需要决定、或带触发条件在观察**的项。已完成/已关闭的 56 行在 [`handoff-section7-done-2026-10-18.md`](handoff-section7-done-2026-10-18.md)（只读，不要重做）。
> **每条都要能独立读懂**：括号里的编号（如 `C9-A′`、`P1–P7`、`D0–D7`）是决策台账里的编号，含义在对应文档里，本节不重复论证，只给链接。
> 维护：做完一项就删掉那一行，并把"为什么 / 怎么验证"写进 [`changelog.md`](changelog.md)；新增一项要写清「做什么 / 怎么算做完 / 优先级」。

## 一、等用户拍板（未拍板不动代码）

| 事项 | 是什么（为什么还没做） | 台账 / 出处 |
|---|---|---|
| 插件家族重构的 7 项前提（P1–P7） | 是否从「个人笔记插件」转向「1 monorepo × N 个 bundle 包 × 2–3 个 profile」的插件家族；含派生索引 `node:sqlite`、质量/成本基准、仓库形态等。**前提已置换，但未拍板** | [`pending-decisions-2026-10-01.md`](pending-decisions-2026-10-01.md) |
| 插件家族评估的 11 项表态（D0–D7 + N-A/N-B + L12） | 外部复杂工具（数据库/Lean/多智能体）该纳入现有插件还是另做包；L12「新增每轮必做步骤一律拒」是挡掉十来项机制的**总闸** | [`plugin-family-assessment-2026-10-01.md`](plugin-family-assessment-2026-10-01.md) §8 |
| 记忆度量重设计（C9 → C9-A′） | 用户从未用过 ✅/❌（真实库 0 次写入），原「把反馈回填到暴露记录」建立在不存在的数据上。改成四层度量：暴露 → 被读 → 被引用 → 用户明说不满，**先只报告** | [`pending-decisions-2026-09-26.md`](pending-decisions-2026-09-26.md) §3.1 |
| 固化输入隔离 A/B（C10） | 写卡那一轮不把旧抽象索引注入上下文；文献显示旧库可见会拉低质量，但要做 A/B 才能下结论（花钱） | [`pending-decisions-2026-09-26.md`](pending-decisions-2026-09-26.md) §3.1 |
| 单源老化降权（P5-B） | 给 `hookPrior` 加「未核实且陈旧只降不升」，拉回单源高频卡压过用户确认卡的反转。**会移动既有排序**，须先过 `retrieval-v3.md` §7.5 的门槛（Direct 不降 且 排名均值不升） | [`note-noise-and-memory-fidelity-2026-09-26.md`](note-noise-and-memory-fidelity-2026-09-26.md) §4 |
| 剩余 4 个记忆开关是否做 UI | `dialogueIndex` / `reminders` / `audit` / `captureSubagents` 目前只能手改 `.deepseek/config.md`；建议不做（避免设置页变成开关墙） | [`settings-surfaces-2026-09-26.md`](settings-surfaces-2026-09-26.md) §3 |
| `baseline.json` 去留 | `scripts/qa/runs/*/baseline.json` 已提交但**没有代码读它**。二选一：让守卫真的消费它，或移出 git 当本机产物。在此之前不要声称"可 CI 比对" | [`memory/testing.md`](memory/testing.md) |
| persona / vault 协议的「Obsidian」措辞 | 是否把 persona 与产品协议里的「Obsidian」改成「工作区」（纯语义改动，需拍板） | 本文 |

## 二、工程待办（可在仓库内直接推进）

| 事项 | 做什么 / 怎么算做完 | 优先级 |
|---|---|---|
| 引擎去重收尾（剩 1 对） | `decodeZstdSessionLog` / `decodeSessionLog` 合并，需把解压器参数化；完成后**同步删掉** `KNOWN_ESCAPES` 对应条目（守卫会把过期条报红） | 中 |
| 大函数拆分 | `buildAuditReport` 1305 行 / `MemoryView` 552 / `DshWebProxy` 526 / `DshObsidianSettingTab` 441；按"读数据 / 算判定 / 渲染"切，每段给独立可测入口 | 低 |
| 可溯源：source 证据链 | 面板卡片的「引用次数」已交付；欠的只有 `source` 链——`collectMemoryState` 的卡片字段里没有 `source`，需补数据层 + 面板展示 | 中 |
| 自指式断言收口 | 把「import 常量再断言」与残留魔法数（`cards === 5` 等）改为独立推导或从清单注入 | 低 |
| `engine-probe` ground truth 夹具化 | 真实 vault 的用例抽象成合成 vault 等价语料；保留本机真实探针作验收。当前真实库 11/12 的红项是 vault 内容漂移 | 中 |
| hook 卡审计重复读 | `writeGain` 复用审计已读的文本，去掉每卡多一次 `readFileSync`（每日一次、卡片百级，非热路径） | 低 |
| 3 类陷阱压力样例进引擎探针 | 造 Cognitive Bias / Task Boundary / Trauma 的数学版 ground truth 进 `scripts/qa/engine-probe.mjs` | 中 |
| home 层 patch 同 id 检测 | 启动/安装时检测 `$DSH_HOME/cordis.patch.yml` 是否与插件 posture 同 id（0.2.0 起 home 层压过 profile 层）；有则**点名提示**，不自动改用户文件 | 中 |
| `defaultPreset` 支点加固 | 组合出的沙箱/审批默认值目前只靠 `defaultPreset: math-memory-locked` 通过启动检查；给 preset 表补一行反向映射（安全配置需单独拍板） | 低 |
| 端口占用回退 | 3180 被占时回退到 OS 分配并显示实际地址；注意 `resolveAuth` 的 `wanted=0` 会反复重绑、作废已兑换 cookie | 中 |
| workspace 登记副作用 | QA 探针的临时 vault 会被登记进 `$DSH_HOME/storages/workspace.json`；给登记加"探针/临时目录不登记"开关，或探针用独立 `DSH_HOME` | 中 |
| 卸载残留客户端包目录 | `--direct` 装的 `node_modules/@dsh-math-memory/**` 不在卸载删除清单里；写进 owner marker | 低 |
| `session.messages` 死代码 | 上游 `Session` 没有 `messages` 成员，该分支永不命中；删死支并评估改用公开读取面 | 低 |
| `working.md` 500 上限 | 五字段标签就占约 120 字符，500 装不下进度；提到 800–1000 或精简模板，二选一，先与注入体积一起量 | 低 |
| CHANGELOG 旧说法核实 | 旧条目称"dsh 前端已内置 loopback 站内跳转"，本机前端产物 grep `127.0.0.1/localhost/loopback` 0 命中；需单独核实后更正 | 低 |
| 工具套件的分块 SKIP | 套件内部的 SKIP 不反映到 `run-gates` 三态汇总（汇总只区分整套 SKIP） | 低 |
| 命名空间隔离（`memoryRoot`） | 多套记忆共存时再做，需迁移 | 低（延后） |
| 修正归档恢复的运行时文案 | `note-tools.mjs` 的 `note_recall` 提示仍说"可在记忆面板恢复"，但面板没有恢复按钮；改文案并重建 `main.js`、跑记忆回归 | 中 |
| 老 vault 的模板刷新 | 安装器对已存在模板不覆盖（`install.mjs` 的 `copyFile(..., false)`），模板修正只对新装生效；需要"模板版本 + 升级时可选刷新"的设计 | 中 |
| 文档一致性收尾（可选） | `docs/memory/` 的提案类文档（retrieval-v3 / strategy-layer / self-correction / v2-proposal / benchmark / obelisk-comparison）补 `类型：` 头；两份 `pending-decisions-*` 是否合并成单一决策索引（现在靠状态块区分） | 低 |
| 修 3080 记忆面板客户端半的层选择 | 审计发现：web profile 的面板客户端行只写在 `notes-assistant.patch.yml`，而 `dsh web` 启动不读 overlay；根因是 A′ 通道对所有 profile 先写 overlay + 客户端安装器按"overlay 是否存在"选层。需一次 `--dump-config` 核实（会写 profile 的 cordis.yml，需用户同意）后改 install-into-profile 的选层规则。 | 中 |
| 核对 notes 的扁平 preset 声明残留 | 只读证据矛盾：notes profile 层有扁平 preset 块（`~/./` 形态），bundle 又声明同 id；仓库记录该形态让 preset broken。需 `dsh --profile notes-assistant --dump-config` 复核（写 cordis.yml，需用户同意），确认后按 stripPresetDeclaration 清掉。 | 中 |
| web profile 的 posture 混装（历史遗留） | 本机 web/cordis.patch.yml 顶部是 Obsidian 模式 sandbox/approval 行 + 用户模型/UI 行混装，源自 2026-09-27 `--force` 吃用户层事故；安装器现在只补缺失，但已铺过的不会自动回退。要不要清理属用户决定。 | 低（需用户拍板） |

## 三、观察（满足触发条件再动）

| 观察项 | 现状与触发条件 | 优先级 |
|---|---|---|
| note 工具使用与候选卡「自锁」 | 候选卡只进 `candidates` 桶、不计 `uses`，晋升门不可达；样本太薄（1 张卡 / 0 次真实晋升），暂不改。触发：候选卡明显增多 / 出现"用了但晋升不了"的实例 / 用户发起策略层建设 | 观察 |
| 关系信任 + 锚点槽位 | GraphMemix 的查询条件化关系信任，需要 `related`/`source` 边带可信度；触发条件见 `retrieval-v3.md` §7.4 | 低（有触发条件） |
| 多视图 max-pool 复测 | 本轮 Δ=0 且排名变差，保持单袋；出现"标题精确命中却排 5 名后"的真实稀释案例时，先补 ground truth 再复测 | 低（有触发条件） |
| `note_recall` 结构化适用性字段 | 现为 prompt 提醒，可升级为可判定的弱信号；等有真实误用样本再说 | 低 |
| 记忆诱发退化被动信号 | 有/无记忆对照的答案质量（LLM-judge）作为体检健康指标；需接 judge | 低 |
| session 路径编码 / 上游崩溃 | 本插件归因看日志头 `cwd`，不受目录名编码影响；上游对含 `~FFFD~` 目录会 boot 失败（陷阱 18），只能等上游 | 观察 |
| 1.0 缺口 | ①理解状态与卡点 ②技巧的调用体系 ③主动教学闭环 ④复习调度——这才是 1.0 的定义 | 高（方向） |

## 四、用户动作（agent 不自动做）

| 事项 | 说明 |
|---|---|
| 发布前验收 | `npm run qa:e2e`（需真实 `DSH_HOME` / vault / 模型余额）+ Obsidian 本机 reload 后实测面板与侧栏 |
| 换机/重装后确认版本 | 本机 `notes-assistant` 已于 **2026-10-18 11:59** 装到 **0.8.2**（`install-manifest.json` 可查）；只有换机或重装后才需要重新确认，不是当前待办 |
| 真实笔记里试用 C9-A′ | 需要真实笔记会话样本才能度量"暴露 → 被读 → 被引用"；在此之前不要为个位数调用建重型指标 |
