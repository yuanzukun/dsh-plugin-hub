# 耦合度评估（2026-10-15）：面向「插件家族」的重新读数

> **本文是什么**：对 `dsh-obsidian-math` v0.8.1 当前树做一次**全插件范围的耦合度重测**，并给出**排好序的解耦路线**。它是 [`decoupling-assessment-2026-09-26.md`](decoupling-assessment-2026-09-26.md)（Obsidian↔dsh 两侧解耦）的**续测**，不是复述：那份的六类耦合（C1–C6）与四个方案（A–D）仍然有效，本文只回答「**过了 19 天、102 个提交之后，读数变了什么、家族化之前还差哪几刀**」。
> **与家族计划的关系**：目标形态取自 [`refactor-blueprint-2026-10-01.md`](refactor-blueprint-2026-10-01.md) §2.1（1 契约包 + 1 核心包 + N 能力包 + 2 profile）与 [`plugin-family-assessment-2026-10-01.md`](plugin-family-assessment-2026-10-01.md) §2.1 的四条硬边界。本文**只评估耦合**，不重开那份的结论。
> **状态**：只读评估 + 可控隔离实验，**未改动任何产品代码**（唯一新增文件是本文）。所有数字均为本机实跑，命令与原始输出见 §7。
> **⚠️ 一条必须先说的事**：本次实跑全门禁得到 **53/54**，唯一失败是**真回归**（不是环境结果）——见 §6.1，一行作用域错误，建议先修它再看本文其余部分。

---

## 0. 一页结论

| # | 结论 | 关键读数 |
|---|---|---|
| 1 | **上次解耦做对了**：契约化（`profile-contract.mjs`）、声明搬家（B3）、平铺文件哈希基线（B0）都落地了，且**第 3 步（所有权转移 / A′）也已收口**——旧路线图第 0/1/2 步已完成，第 3 步的插件侧字面量已删（`main.template.js:2105-2107` 改为构建期注入）。 | §1 对照表 |
| 2 | **但耦合的"总量"涨回去了，而且长在一个新轴上**：生成的产物守卫从 8 条涨到 **13 条**（增长 63%）——profile 契约、本地包物化（A′）、两个宿主 shim、"被清空的 `$DSH_HOME` 重建"各自带来一族守卫。**家族化会放大这条轴**（每加一个包就多一份物化产物）。 | §2 门禁分类：**28/54 条**只为防跨边界漂移或生成物过期 |
| 3 | **最深的耦合仍然是同一条：同一份引擎活在四处**（`dsh/**` 源 → `main.js` 内嵌 → profile 平铺 → 物化包 payload）。比例由 62% 降到 **63%**（`main.js` 870 609 字节里 550 842 字节是内嵌引擎 JSON），**引擎本体 19 天长了 24%**（3 975 → 4 838 行）。 | §3 C1 |
| 4 | **一条新的、比"重复"更危险的东西出现了：契约幻觉**。`profile-contract.mjs` 的 5 个字段里只有 3 个有运行时读者；`overlayRows` 与 `panelRoutes` **零运行时消费者**——真值仍在三份 yml 与面板的 `if` 链里。契约对这两个字段是「被门禁钉住的抄本」。 | §3 C2、§4 P2 |
| 5 | **数据契约是家族化最大的空白**：10 类知识格式里 4 类**连版本字段都没有**；全部格式**零迁移机制**（"不认识就重建/降级"）。家族一多写者，这里最先崩。 | §3 C4、§4 P3 |
| 6 | **引擎重复的减半机会已被门禁自身证明**：`KNOWN_DIVERGENT` 6 条里 **4 条的差异是历史遗留而非环境约束**（`CAPTURE_FILE`/`distillSession`/`findSessionLogs`/`scanZstdFrames`），可常量下沉直接消掉。剩下一对（解压器）**只能参数化后合并**。 | §3 C1、`check-engine-sync.mjs` 实跑 |
| 7 | **建议的家族切分依据不是"话题"而是符号契约面**：11 个功能切面中，`buildAuditReport` 是一个 **1 537 行的单函数**（横跨 31 处同文件调用），它是"体检只报告"这条不变量与"写回"之间的唯一断点——**它是第一刀**。 | §3 C6、§4 P4 |

---

## 1. 与上次评估（2026-09-26）的对照：哪些读数变了

被测状态：**v0.8.1，工作树干净**（`git status` 空）。上次读数点 `b29c566`，本次 `047318a`，之间 **102 个提交 / 98 个文件 / +14 798 行**。

| 指标 | 2026-09-26（`b29c566`） | 2026-10-15（`047318a`） | 变化 |
|---|---|---|---|
| 门禁总数 | 50 | **54** | +4 |
| 门禁构成 | 50 条里 30 条（60%）为两侧同步 | **54 条里 28 条（52%）**：15 条纯跨边界同步 + 13 条生成物/物化产物 | 比例降、**绝对数涨**；新增的一族是"物化产物" |
| `main.js` | 732 080 B | **870 609 B** | +19% |
| 内嵌引擎（`dsh/**` 拷贝）在 `main.js` 里的占比 | 62%（450 602 B） | **63%**（550 842 B） | 基本不变 |
| 插件源码 `obsidian/main.template.js` | 3 543 行 | **4 258 行** | +20% |
| 引擎主体 `dsh/preset/math-memory.mjs` | 3 975 行 / 227 616 B | **4 838 行 / 272 040 B** | **+22% / +19%** |
| 宿主引擎 `dsh/host/memory-admin.mjs` | 1 567 行 | **1 675 行** | +7% |
| 检索 `dsh/preset/note-tools.mjs` | 1 652 行 | **1 848 行** | +12% |
| 安装器 `dsh/install.mjs` | ~570 行（推） | **1 613 行** | **大幅增长**（三条通道 + 物化 + 回滚） |
| 引擎同名符号 | 23（17 同步 + 6 偏离） | **23（17 同步 + 6 偏离）** | 不变 |
| 跨名 token-shape 配对数 | 3 225（注释写 3 537，已过期） | **3 803** | **文档再次过期**（见 §3 C5） |
| `KNOWN_ESCAPES` | 4 → 2（当日合并了 2 对） | **2** | 不变（`dedup` + `structural`） |
| 共享助手模块 | 新建 `engine-shared.mjs`（2 助手） | **3 导出**（`contentText`/`joinFrontmatterLines`/`setTopField`）+ 宿主 shim | 已稳定 |
| 契约文件 | 新建 `profile-contract.mjs` | 106 行，5 字段，`3 read + 7 pinned` | 已落但**两个字段零读者** |
| "三份源码" | 3 份（源 / 内嵌 / 平铺） | **4 份**（源 / 内嵌 / 平铺 / 物化包 payload） | **多了一份** |

**读法**：上次的四个方案没有白做——**事故土壤确实少了**（四条清单收敛成一条、声明不再住在被重写的 overlay 里、平铺文件有了哈希基线）。但"新增功能"这条路本身会把耦合**换个位置再生**：A′（机会式包化）解决了"离线装看不见"，代价是**第四份产物**与三条新守卫。这正是家族化前必须先看清的东西。

---

## 2. 耦合的"护栏厚度"：54 条门禁的分类读数

> **本节读数之后门禁又加了一条（2026-10-15，本次解耦的第 12 刀）：总数 54 → 55。** 新增的是 `check: mutation anchors are live`——它盯住变异清单（`scripts/lib/mutation-entries.mjs`）的锚点新鲜度。**这一刀的意义不在于"多一条门禁"**：第一次成体系跑 `scripts/qa/mutation-sweep.mjs`（12 条变异）时，**找到 2 条守卫对它们存在的那个缺陷是瞎的**（统计重置的原子性、`note_recall` 的版本盖章——套件当时全绿），两条都已补上断言。⇒ **"护栏厚度"这个读数本身需要打折**：门禁条数衡量的是**意图**，不是**有效覆盖**；后者要靠变异扫描来量，而在此之前本仓库只做过零散的、不可复现的变异验证。详见 `docs/changelog.md` 2026-10-15 那一节。

**结论：54 条里 28 条（52%）存在的唯一理由是「防止跨越某条边界时漂移」。** 其中 13 条守的是**生成物/物化产物**（这一族在 09-26 时只有 8 条）。

| 类别 | 条数 | 门禁 |
|---|---|---|
| **跨边界同步** | **15** | `engine sync`、`preset body lists agree`、`profile contract is the single source`、`overlay drops bundle-owned rows`、`preset declaration is current`、`frontmatter single source`、`config scaffold parity`、`env vars`、`channel ownership anchor`、`plugin rebuilds a wiped $DSH_HOME`、`rename`、`agent instruction files`、`version consistency`（三处版本 + 引擎约束）、`embedded writers`、`release artifact paths` |
| **生成物 / 物化产物过期** | **13** | `main.js bundle freshness`、`client bundle freshness`、`embedded loader`（`new Function` 参数表）、`client package layout`（真 `import()` 一次产物）、`6 条 syntax`、`shipped yaml parses`、`profile contract` 的注入副本逐字节比对 |
| **运行时接口行为** | 8 | `panel routes` / `panel proxy` / `panel auth e2e` / `panel presentation` / `drop-to-mention` / `channel ownership anchor` / `tool output schemas` / `tool shape` |
| **功能与回归** | 5 | `memory regression`（3 760 行）、`installer e2e`、`lit-import`、`link server`、`self-provisioned profile` |
| **纯语法** | 6 | 6 个 `.mjs`（含 `local-bundle.mjs` 的"零调用方"防腐） |
| **文档锚点** | 7 | `readme pair` / `doc consistency` / `doc constants` / `doc counts` / `doc consistency` 的运行时断言计数 / `version consistency` 的文档横幅 / `plugin manifest meta` |
| **产品元数据** | 1 | `plugin id`、`skin fallback`、`plugin unload cleanup` 归在此列 |

> **为什么这张表是"耦合深度"的读数**：一个不需要跨越边界的系统不需要 15 条同步守卫；一个不生成产物的系统不需要 13 条新鲜度守卫。家族化（N 个包 × 2 个 profile × 物化通道）会**同时**放大这两族。**边界需要预算是**——这是 [`plugin-family-assessment-2026-10-01.md`](plugin-family-assessment-2026-10-01.md) §2.2 已经写下、但当时还没有本机读数的判断。

**本机门禁实跑结果**：`53/54 gates passed in 173.4s`。失败 1 条为**真回归**（§6.1）；2 处 SKIP（`panel auth e2e`、`check-bundle-recovery` 里的 pnpm 子段）。

---

## 3. 七类耦合的当前读数

### C1 源码重复：同一份引擎活在**四处**（最深，但已被守住）

| 那一份 | 读数 | 谁守 |
|---|---|---|
| ① `dsh/**` 源 | 23 个文件；三大件 **8 361 行**（preset 4 838 + host 1 675 + note-tools 1 848） | git + 全部门禁 |
| ② `main.js` 内嵌 | 870 609 B 中 **550 842 B**（63%）是内嵌引擎 JSON 字面量；17 个嵌入键 + 4 条 `NOT_EMBEDDED`（各有理由） | `main.js bundle freshness`（逐字节）+ `embedded loader`/`embedded writers` |
| ③ profile 平铺 | 13 个文件（body 4 + scaffold 9），由 `PRESET_BODY_FILES`/`PROFILE_SCAFFOLD_FILES` 派生 | `postureDigests` 哈希基线 + `test-agent-preset` 的"磁盘 vs manifest"硬断言 |
| ④ **物化包 payload（新）** | `main.js` 内 **26 563 B** 的 `__BUNDLE_PAYLOAD_JSON__`（另一半经 basename map 复用 ②，否则要多 ~440 KB） | `build-obsidian.mjs` 的**第 4 道完整性门**：payload 自身的 import 图必须闭合 |

**引擎内部的功能切面（11 片，家族切分的依据）**：

| 片 | 行区间 | 符号 | 说明 |
|---|---|---|---|
| F1 路径/预算常量核 | 67–151 | 23 | `MAX_*`、`BUDGET_TIERS`、`budgetsFor` |
| F2 体检常量 | 152–298 | 38 | `AUDIT_*`、`cardGain` |
| F3 捕获常量 | 299–313 | 7 | `CAPTURE_*` |
| F4 捕获/会话日志 | 314–989 | 22 | zstd 帧、`runSessionCapture`、`buildDialogueIndex` |
| F5 memo/策略/config 解析 | 990–1126 | 17 | `memoDigest` |
| F6 卡片回写 + 账本 + 笔记体检 | 1127–2471 | 33 | `rewriteHookStats`、`setCardOrigin`、`scanNoteHygiene` |
| **F7 体检主体 `buildAuditReport`** | **2472–4008** | **1** | **1 537 行的单函数**，31 处同文件调用 |
| F8 引擎小助手 + hook 历史 | 4009–4156 | 12 | `pathInside`、`writeHookHistory` |
| F9 注入渲染 `buildMemorySection` | 4157–4535 | 9 | 预算裁剪、索引摘要 |
| F10 索引缓存 | 4536–4632 | 11 | `fingerprint`/`cacheIndexValid`（`DIALOGUE_INDEX_VERSION = 2`） |
| F11/F12 `MemoryEngine` + `apply()` | 4633–4838 | 2 | 装配、节流、缓存；动态 `import('./note-tools.mjs')` |

**模块级可变状态（隐式耦合）**：`sessionHeaderCache`（preset:416，宿主侧**没有**同缓存 ⇒ 同义函数行为分叉）、`noteReadCache` + `statsWriteQueue`（note-tools:261/1298）、`mounted`（host/index:69）、`MemoryEngine` 的 `#cachedIndex/#fingerprint/#auditCache/#lastCaptureAt/**#sessionCaptureOverride**`。最后一个是**跨切面顺序依赖**：`captureNow()` 在 `system-prompt/assemble` 里被调用，而它的开关来自**上一次** `sectionForAgent` 写入的字段。

### C2 布局与文件契约：从"四份清单"进化成"契约 + 两个零读者字段"

**进步**（上次路线图的第 2 步确实兑现）：profile 文件全集现在**一处权威 + 三处读派生**：

| 事实 | 权威 | 真读契约的地方 | 手写但被钉住的地方 |
|---|---|---|---|
| profile 文件全集（13） | `profile-contract.mjs:21,27` | `preset-deploy.mjs:54`（re-export）、`install.mjs:125,131-134`、`main.template.js:2105-2107`（构建期注入） | `build-obsidian.mjs:37-61` 的 17 个嵌入键、`install.mjs:1186-1210` 的 9 条 `copyFile`、`main.template.js:2236-2277` 的 12 条 `ensureFile`、`local-bundle.mjs:52-61` 的 5 条 extras |
| **overlay 行 id（6）** | `profile-contract.mjs:76-83` | **无（零运行时读者）** | 三份 yml 的 11+ 行 id；`OWN_ROW_ID_PATTERN:86` 是**同一命名规则的第二处陈述** |
| **面板路由（10）** | `profile-contract.mjs:93-104` | **无（零运行时读者）** | `math-memory-panel.mjs:241-307` 的 11 条 `if (pathname === …)`；**另有第 4 份**：`main.template.js:4068/4104/4136/4164` 的客户端路径字面量 |
| preset 声明 | `agent.cordis.yml` + `preset.yml` | 生成器 `preset-declaration.mjs:115` | 两处生成块（`--check` 钉住） |

**这条比"四份清单"更值得警惕**：`check-profile-contract.mjs` 自报 `3 read + 7 pinned`，但**对 `overlayRows`/`panelRoutes` 而言，契约仍是"被门禁钉住的抄本"**——`READ-2b` 只断言"注入进 `main.js` 的副本逐字节等于契约"，即断言"契约被注入过"，而不是"契约是权威"。真值还在三份 yml 与面板 `if` 链里。**家族化时最大的风险是"以为改了契约就生效了"**（见 §4 P2 的验收判据）。

**另一处具体的复制**：客户端路由那 4 条字面量**只被第 4 份字面量再钉一遍**——`test-panel-routes.mjs:442-444` 比对的是同一个陈旧字面量。所以"把契约和服务端一起改、忘了客户端"这个动作**门禁是绿的**，而设置页写入会 404。

### C3 运行时接口：24 处契约级依赖，10 处**静默失效**

对 `obsidian/main.template.js`（4 258 行）逐处取证，按"公开 API / CLI 契约 / 内部形状"分类：

| 静默失效点（**无报错、无日志、功能消失**） | 位置 | 后果 |
|---|---|---|
| `probeService` 把 `200 ≤ code < 500` **一律判为 ready** | `:193-212` | dsh 若用 403/302 表示未认证 ⇒ 状态行显示 running，iframe 里是错误页 |
| 反代删掉上游 `x-frame-options`/`content-security-policy`/`set-cookie` | `:1283-1363` | 上游加 Origin/Sec-Fetch-Site 校验 ⇒ 每帧 403，而状态 running |
| 升级转发白名单写死 `['/api/']`，不匹配就 `socket.destroy()` **零日志** | `:963, 1450-1479` | WS 静默失效 |
| 注入锚点写死 **`</head>`**，缺失即整份返回、**无日志** | `:1104-1110` | dsh 换外壳/流式 ⇒ 性能样式 + 笔记链接拦截 + mention meta **三者同时消失** |
| `x-dsh-token` 只对硬编码前缀 `/memory-panel` 注入 | `:281-284, 1312` | 前缀改名 ⇒ 面板 403，工作区下拉**静默退化成文本框** |
| 皮肤路由正则 `/^\/api\/skin-center\/[^?]*\/hooks\.mjs(\?|$)/` | `:1147` | 皮肤改路由 ⇒ 补丁不生效，**连日志都没有** |
| 性能样式依赖皮肤类名 `[class*="Glow"]`/`[class*="orca-"]` | `:1023-1038` | 皮肤改名 ⇒ 收益消失 |
| 仅当 `content-encoding === undefined && 200 && text/html` 才注入 | `:1316, 1364-1367` | dsh 改压缩策略 ⇒ 不注入（只有 >2 MiB 才记日志） |
| 启动 token 正则 `http://127\.0\.0\.1:(\d+)/\?token=([A-Za-z0-9_-]{8,})` | `:1534-1541` | `https`/`localhost`/token 字符集变化 ⇒ `authUrl` 恒 null ⇒ 启动超时 |
| 拖拽送达依赖上游 composer 读 `text/plain` | `client-panel/src/drop-mention/composer-drop.mjs:11-16` | 上游改 composer ⇒ 落笔静默无效（作者自己注明"不是公开契约"） |

**已覆盖的**：CLI 启动形状（`test-panel-proxy.mjs:324-331` 正则钉模板文本）、token 兑换 303、`x-dsh-token` 盖章、HTML 注入/无 `</head>`/gzip（`test-panel-proxy.mjs:211-278`）、overlay 不带声明（`test-agent-preset.mjs`）、契约单一来源。

**没覆盖的**：`probeService` 的 403 情形、`</head>` 缺失的**后果**（现有用例只钉"原文透传"）、`/api/` 前缀与 dsh 真实 mux 路径（`test-panel-proxy` 用的上游是**仓库自己写的 stub**，对真实 dsh 是自证）、`ensureProfileDeclaration` 的静默 `return false` 分支，以及**旧插件写出的已部署 overlay**（模板没有 `stripBundleOwnedRows` 那种对过时声明的运行时剥离）。

> **一处我亲自复核并修正的读数**：D2 报了一条"旧插件 + 强制重装 ⇒ 声明被擦掉且无报错"（Case C）。我把它做成**隔离实验**（抽出真实的 `ensureProfileDeclaration`，喂 W1 旧形态 / 无标记无声明 / 空文件三种现场）：**三种全部正确修复，且第二次运行是 no-op**（§7 实验 3）。所以这条**不成立**，`repaired=false` 只表示"无需改动"。D2 与 D3 都点名了它，两份都不采信。
> **真正成立的那半**（我复核确认）：模板里的标记字面量与权威常量**确实不等**——`begin` 模板为 `"# >>> GENERATED agent-preset declaration"`、权威为 `"# >>> GENERATED agent-preset declaration (scripts/build-preset-declaration.mjs) >>>"`、`end` 两侧逐字相等。因为 `begin` 只作 `indexOf` 前缀用，当前不产生故障，**但没有任何门禁比对这两个字面量**，而历史上正是一次 `end` 被截断写坏过 profile（`main.template.js:346-352` 的注释记着）。

### C4 数据契约：10 类格式，4 类零版本，**零迁移**

| 格式 | 定义者 | 写者 | 读者 | 版本字段 | 迁移 |
|---|---|---|---|---|---|
| 卡片 frontmatter + hook | `hook-frontmatter.mjs:16` | preset 体检回写 / 模型 / 用户 | preset、host、note-tools | `HOOK_SCHEMA_VERSION = 1` | ❌ |
| `.deepseek/cache/dialogue-index.json` | preset:73 | preset | preset | `DIALOGUE_INDEX_VERSION = 2`（:78） | ❌（不认识即重建） |
| `cache/memory-audit.json` | preset:153 | **preset** | host:662/957/998 | `AUDIT_SCHEMA_VERSION = 2` + host 侧 `MIN 1/MAX 2`（:653-671） | ❌（版本超出 ⇒ `null` ⇒ 面板静默无报告） |
| `cache/captured-sessions.json` | preset:299 / host:1022 | preset + host | preset + host | `CAPTURE_SCHEMA_VERSION = 1`（两侧**各自**声明） | ❌ |
| `cache/audit-ledger.jsonl` | preset:192 | preset | preset | 每行 `v`（`AUDIT_LEDGER_SCHEMA_VERSION = 1`） | ❌ |
| `cache/card-origin.jsonl` | preset:216 | preset | preset | 每行 `v`（`CARD_ORIGIN_SCHEMA_VERSION = 1`） | ❌ |
| **`cache/retrieval-stats.json`** | preset:154 / note-tools:1301 | **note-tools（记命中）+ preset 体检（合并后重置）** | host:88/805、preset:1224 | **无**（只有 `__meta__` 约定） | ❌ |
| **`cache/hook-history.json`** | preset:4009 | preset | host:821 | **无**（`snapshots` 形状隐式） | ❌ |
| `.deepseek/config.md` / `capture-policy.md` | preset:1064/1023 | host（面板路由）+ preset（体检回写）+ 用户 | 全部 | 无 | ❌ |
| `.deepseek/working.md`、`inbox/**`、`strategy/**`、模板 md | 模板 + 模型 | 模型 / 用户 | 全部 | 无 | ❌（模板靠 manifest 三路安装） |

**两条要单独说的**：

1. **`retrieval-stats.json` 是一条跨包协议，且两侧锁不同**。它是**增量语义**（"上次体检以来的命中"），host 明确按"声明值 + 待合并值"显示（`memory-admin.mjs:795-801`），preset 的体检负责"合并进卡片 hook 后重置"（`math-memory.mjs:2764-2782`）。而 `note-tools.mjs:1298` 用**模块级 promise 队列**串行化自己的读改写，preset 体检的 `writeFileSync` 却**不经过那个队列**——两者同时发生就会丢计数。目前没有门禁覆盖这条协议。**这正是家族切分时"核心包 ↔ 能力包"必须先定契约的那种缝**。
2. **`memory-audit.json` 是"preset 写、host 读"的单向契约**，host 侧主动做了版本区间校验（`:653-671`），**这是全仓库最好的一个数据契约实践**——但它没有迁移，超版本时是 `null`（静默降级），家族的"数据契约包"应当把它升级成范例。

### C5 文档与锚点：7 条文档门禁，**仍有活体腐烂**

| 已腐烂的锚点 | 真值 | 写在 |
|---|---|---|
| 跨名 token-shape 配对数 | **3 803**（实跑） | `AGENTS.md:60` 写 **3 225**；`check-engine-sync.mjs` 的注释已按上次评估改成"跑 `--sweep` 看实跑值" |
| 引擎顶层符号数 | preset **170** / host **61** | `AGENTS.md` 未载（无法比对） |
| `--sweep` 的共享模块比对声明数 | **3** | `AGENTS.md` 未载 |

`AGENTS.md` 同一句里明说"不要在这里写死"这个数字，却仍写死了它——**这是"文档锚在会变的量上"的第 4 次复发**（前三次：陷阱数 69→81、门禁数 34→41、配对数 3537→3225）。建议的修法不是改数字，是**把该句改成指向 `--sweep` 的输出**。

### C6 版本与生命周期：闭合良好，一条缺口在"物化产物"

版本面**没有新问题**：五处版本由 `check-version-consistency.mjs` 钉住（含文档横幅与引擎约束 `>=0.1.7-rc.2` 两处同值）。三条通道的归属锚点（`.install-manifest.json` → 退役 `.agent-presets/<id>/.owner.json` 回退）已被 `test: channel ownership anchor` 覆盖，且刚修过一次判据（HEAD 提交 `047318a`：改成 `(owner, bundleSource)` 二元组，起因是"守卫拒绝自己写下的配置"）。

**缺口**：`materializeLocalBundle`（`local-bundle.mjs:135-157`）**不清空目标目录**（两个调用方都没有 `rmSync`）⇒ 上一版删掉的文件会作为**孤儿**留在 `.dsh-math-memory/` 里被继续挂载；而 `localBundleInstalledIn` 的唯一调用点是 `uninstall`，也就是说**重物化时没有单点判据**。这条在家族里会变成"N 个包各自的物化目录都可能带孤儿"。

### C6.5 补充取证：插件里那份引擎到底被用了几成（方案 C 的判据）

复核方案 C 时实测了 `obsidian/main.template.js` 里嵌入 loader 的**真实消费面**（该 loader 把 `dsh/host/memory-admin.mjs` 逐字求值进 `main.js`）：

| 类别 | 数量 | 符号 |
|---|---|---|
| loader 对外导出 | **23** | 见 `main.template.js:214` 的 return 列表 |
| **真正被调用**（含经常量别名） | **5 + 6** | 直接调用：`probeService`（2 处）、`pathInside`（4）、`applyFeedback`（2）、`archiveMemoryFile`（2）、`archiveOldEpisodes`（3）；经别名调用：`daysSinceText`、`parseMemoryFrontmatter`（4）、`collectMemoryState`、`runSessionCapture`、`countUncapturedSessions`、`FEEDBACK_MESSAGES` |
| **设了别名但从未被调用**（残留） | **3** | `setHookField`(:466)、`setTopField`(:469)、`readAuditText`(:2731) |
| **连别名都没有**（死导出） | **4** | `setMemoryBudget`、`setMemoryConfigFlag`、`setSessionCapture`、`readSessionCaptureEnabled`——2026-09-26 的 D2 把它们改走 HTTP 路由后，**loader 的 return 列表没同步收缩** |
| 在导出表里、未见调用点 | 5 | `frontmatterSpan`、`replaceFrontmatter`、`setCapturePolicyMode`、`titleOf`，以及上表未列的其余项 |

**两点由此确定**：

1. **读仍然是同步、进程内、直接读盘**：`renderBody` **同步**调用 `collectMemoryState`（`main.template.js:2988`；其定义 `memory-admin.mjs:784` 用 `readFileSync`）。所以"把读改成 HTTP"不是搬代码，而是**把同步渲染改成异步数据流**——这是方案 C 的真实成本。
2. **嵌入的那份引擎无法被"完全退役"，只能被"缩小"到只剩读**；而缩小到只剩读之后，**它仍然是同一份引擎的第四份拷贝**（读逻辑同样会漂移）。⇒ **方案 C 与"四份 → 三份"不是同一件事**，两者不要混为一谈。

另记一条实测缺口：`MemoryView` **没有订阅 vault 文件变更事件**（全文无 `vault.on('modify')`，刷新只能靠显式 `this.render()`）。这条与上面那条互补——**它正是"读改走 HTTP 后如何知道该刷新"的现成解法**。

### C7 决策与文档耦合：家族计划的**三个前置**仍未拍板

`docs/pending-decisions-2026-09-26.md`（A1–A7 / B1–B5 / C1–C6）与 `docs/pending-decisions-2026-10-01.md` 仍是"未拍板不动代码"的状态。按 blueprints §2.1，家族化的**第一件事是建 `packages/contract/`**，而它的内容（数据契约版本 + 服务接口 + 命名规则 + 家族清单）**恰好全部落在本文 C2/C4 的空白处**。换句话说：

> **家族的第一刀不是"拆包"，而是"把本文 C2 的两个零读者字段变成真权威 + 给 C4 的四类格式补上版本与迁移"。** 这两件事做完，拆包才是机械动作；不做，拆包只是把"N 份手写清单"变成"N 个包各自的 N 份手写清单"。

---

## 4. 解耦路线（按 收益 ÷ 成本 排序）

**⚠️ 执行状态（2026-10-15 起按本文顺序动手，每步一次 commit；这是本节的现行状态，别照建议的顺序重新开工）**

| 本文建议 | 状态 | 提交 |
|---|---|---|
| §6.1 门禁回归（`deployedIsBundle`） | ✅ 已修 | `8cd48f6` |
| P2 契约去幻觉——**`panelRoutes`** + 客户端第 4 份副本 | ✅ 已落地（`check-profile-contract` `3 read+7 pinned` → `4 read+6 pinned`；`test-panel-routes` 62 → 65） | `3b9fe2d` |
| P2 契约去幻觉——**`overlayRows`** | ✅ **已核实为"结构上已足够"，不再改**（2026-10-15）：① 行 id 仍由 PINNED-3/3b **双向**核对（契约缺一行、或某一层多一行自家 id，都红）；② 特意试过把 `OWN_ROW_ID_PATTERN` 从 `OVERLAY_ROWS` 派生，**两次都更差**（按最后一个 `-` 切 ⇒ 模式变宽、误报 `math-lint`；用行 id 本身做 alternation ⇒ `undeclaredRows` 检查空转），已把这段判断写进契约注释，避免下一轮重试；③ 把 overlay 的 YAML 行体改成生成物**能**做（与 preset 声明同一套生成器），但**它防的是门禁已经双向防住的漂移**，代价是每次启动/flat 安装都要重新验证排布 ⇒ 判定为"不值得，除非将来出现手工排布的第二个写入方" | `3d64e60` |
| P3 数据契约 B+D（版本字段 + 未知版本拒绝改写） | ✅ 已落地（`retrieval-stats` / `hook-history` 带 `__schemaVersion__`；`test-memory` 457 → 460） | `5b616ce` |
| P4 `retrieval-stats` 双写者协议 | ✅ 已落地（重置改原子写；协议写成两处契约注释；460 → 461） | `583a5e6` |
| P5 拆 `buildAuditReport` | ✅ **已按 (a) 落地 + 接缝补全**：① `makeCardWriter` 接缝（461 → 463）；② **(a) 归档移动挪到分析之后**——`moveCardsToArchive` 的**调用**移到报告组装前，`archivedRels`/`live` 仍在同一点构造 ⇒ **报告行为不变（469 条断言全过）**，但"分析"与"写回"的边界从此可指认；③ **接缝补全**：`promote` 与**归档移动**原本都**绕过接缝**（用裸 `writeFileSync` / 直调 `moveCardsToArchive`）⇒ 注入 deferred 写者时**仍会真改用户的库**，接缝自己的承诺是假的；现在两者都走接缝，各有一条点名断言 + 变异验证（469 → **471**） | `35edc72`、本轮 |
| ↳ P5 的**量化**与一次**自我更正**（2026-10-15） | 隔离实验（两份临时库、只改 `autoArchive`、逐字段 diff）：**归档改变报告 122 个字段中的 22 个**——`counts.cards` 2→1、`decisions.total` 2→1、`sections.unused`/`.unverified` 1→0、`archived` 0→1，外加 `checklist`/`human`/`report`/`ledger.newCount`。⚠️ **但我据此推出的结论错了一半**：我用它论证"劈法 (a) 会改变体检报告"，而实测 **(a) 对报告是 no-op**（469 条断言一条没动）。**"22/122"描述的是"归档改变了什么"，不是"把那次调用挪个位置改变了什么"**——把这两件事混为一谈，才让 (a) 看起来像行为变更。⇒ **真正需要决策的只剩 (b)**（跑两遍分析再 diff：每天两次、且"两次体检"可观察）；**(a) 不需要任何人拍板，已实施** | 本轮 |
| ↳ P5 的**结构性收益**（为什么 (a) 仍值得做） | 它不是"少 22 个字段差异"，而是：**"体检先分析、再写回"这句话现在能说出口了**。此前那次移动是分析后半段的**输入**，所以读者无法判断哪些结论描述"发现时的库"、哪些描述"写回后的库"。现在边界明确：边界之上的每个 pass（promote、结构、互证、以及 `markPromotedCardsActive` 的读盘）看到的是**发现时的库**；边界之下（`archivedRels` 起）描述的是**本趟自己写完之后**的库 | 本轮 |
| J1=B 退役 Obsidian 侧嵌入 loader | ✅ **三刀已落地 + 已定论**：① `probeService` 移出 loader、注入面少一项 `http`（导出 23 → 22）；② **读路径**改走 `/memory-panel/state` + 补 vault 变更订阅、清掉 13 个零调用者导出（22 → 10）；③ **面板卡片按钮的写路径**（✅/❌/忘掉）也搬进 `/memory-panel/feedback`｜`/archive` 守卫路由；④ **"能不能删掉"已有出处可查的定论**（见下两行）。顺带修掉四处守卫缺陷（标记歧义、哨兵硬编码、消费扫描扫注释、断言锚点失效） | `587d014`、`d490049`、`6dad774` |
| J1=B 剩余（**已收敛为一条判断，且已核实到底**） | ✅ **"loader 能不能删掉"已有确定答案：在现有交付形态下不能**（2026-10-15 核实，证据见下）。⇒ 本项从"待办"改为"已决定"：loader 保留，缩到最小注入面，并**把它的名字与职责写准**（它是"源码注入求值"，不是"模块加载器"） | — |
| ↳ 为什么删不掉（**已定论**；含两处我先写错、先后被推翻的说法） | Obsidian 插件是 **CommonJS**：`obsidian/main.template.js` 用 `require('obsidian')`/`require('fs')`…，全文件**零静态 import、零动态 `import()`**（实测：require 说明符 9 个，import 语句 0）。宿主模块 \`dsh/host/memory-admin.mjs\` 是 **ESM** ⇒ 交进这个进程只有两条路：**(1) 运行时求值**（现在的 \`new Function(body)(注入 fs/path/zlib)\`，即 loader）；**(2) 真模块解析**。**路线 (2) 已被排除**，见下。⚠️ 我先后写错过两次，都留在这里：<br>**错误一**："CJS 里 \`require()\` 一个 \`.mjs\` 会抛 \`ERR_REQUIRE_ESM\`" ⇒ 在本机 Node 24.14.1 上**实测 \`require('./mod.mjs')\` 成功**，所以这不是理由。<br>**错误二**：改口成"宿主是否支持 \`require(esm)\` **本机无法判定，需要真机证据**" ⇒ **也是错的：这是有权威来源的事实题**。<br>**定论（有出处）**：\`require(esm)\` 默认开启始于 **Node 20.19.0**（2025-03-13，此前 v20 需要 \`--experimental-require-module\`；v22/v23 默认）——见 [Node.js 20.19.0 发布说明](https://nodejs.org/en/blog/release/v20.19.0)；而 **Electron 25.0.0 捆的是 Node.js 18.15.0**——见 [Electron 25.0.0 发布说明](https://www.electronjs.org/blog/electron-25-0)。本插件 \`minAppVersion\` 为 **1.4.0**（2023-07 推出的版本，对应用户可能仍在跑的旧 Electron）⇒ **在其支持的运行时上 \`require(esm)\` 根本不存在**，路线 (2) **不可用**。<br>**⚠️ 这条纪律值得单独记住**：本机 **Node 24.14.1** 的实测只说明*开发机*能 require，**与交付目标无关**——决定能不能用的是**宿主/目标运行时**的版本，而它可以从**权威发布说明**查到，不需要真机。我把"需要真机证据"这个结论下得太早，而它恰好挡住了一个其实能查清的问题。<br>⇒ 结论：**loader 保留，且这是定论而非权衡**；能做的只有"把注入面压到最小 + 名字诚实"——它替的是"这个进程没有模块系统"，把导出从 10 减到 8/6/4 **都不会让它消失**，所以 §4 里"退役 loader"这个目标名应当改掉 | — |
| ↳ `/feedback` 落地页为什么**不能**照搬面板那条 HTTP 路（2026-10-15 核实） | LinkServer 绑在**用户配置的公共端口**（默认 3180）上，而调用方本身就在改那个端口的请求流；更关键的是 **Obsidian 主进程的 fetch 在 Node 侧**——它若打到同一个代理端口，就请求"自己的服务器再转发给 dsh"，中间要经过它自己那条正在处理该请求的路径。要么死锁、要么递归，取决于代理实现；而 dsh 的**内部端口**（`--port 0` 随机分配）住在 proxy 对象里，不是 LinkServer 的现成输入。⇒ 这一迁移需要**真机验证**（本机无 Obsidian + dsh 配对在跑），不是纯静态改动 | — |
| ↳ 读路径的**真 dsh 验证**（2026-10-15，已补） | ✅ `test-agent-preset` 新增两条断言，跑在**真 dsh** 上：① `GET /memory-panel/state?root=<探针 workspace>` ⇒ **200** + `{ ok:true, state:{ layers, records, templates, topics } }`；② 同一个路径配一个**服务器不拥有的** root ⇒ **403** `root not allowed`。这补上了 `test-panel-routes` 结构上无法覆盖的一格（它是进程内跑 handler、自己设环境变量，永远看不见"两边对 root 的理解不一致"）。套件 24 → 26 | `7a8e30c` |

**排序依据**：① 是否解锁家族化；② 是否消除**静默**故障面（静默 > 报错，这是本仓库自己反复踩的形态）；③ 改动面是否可独立验证；④ 是否会与旧路线图重复。

### 第 0 档 — 当场可做（建议今天就做）

| # | 动作 | 为什么现在 | 改动面 | 验收判据 |
|---|---|---|---|---|
| **P1** | **修 §6.1 的门禁回归**（`deployedIsBundle` 作用域） | 全门禁 53/54，且失败分支在真机上**必然触发** ⇒ 这条门禁目前**从不真正评估声明位置** | `scripts/test-agent-preset.mjs`（一行作用域） | `node scripts/test-agent-preset.mjs` 退出 0，且 `53/54 → 54/54` |
| **P2** | **让契约的两个零读者字段变成真权威**（`panelRoutes` / `overlayRows`） | 这是 §3 C2 的"契约幻觉"，也是家族契约包的第一块砖；现在改**只有 4 处消费者** | `math-memory-panel.mjs:241-307`（11 条 if → 查表）、`main.template.js:4068/4104/4136/4164`（读注入契约）、`OWN_ROW_ID_PATTERN` 去重 | ① 从契约删一条路由 ⇒ **行为**变（不是门禁变）；② 客户端 4 条字面量与契约**同源**（变异：改契约 ⇒ 客户端与服务端一起红）；③ `test-panel-routes` 全绿 |
| **P3** | **给 C4 的 4 类零版本格式补版本字段**（`retrieval-stats.json` / `hook-history.json` / `config.md` / `capture-policy.md`） | 家族一多写者，这里最先静默腐坏；补版本是**加法**（旧文件缺版本 ⇒ 按 v0 语义读） | 4 个常量 + 4 处读写点 | ① 旧文件（无 `schemaVersion`）仍能读且语义不变；② 新写入带版本；③ 一条"版本不认 ⇒ 明说降级"的断言 |
| **P4** | **把 `retrieval-stats.json` 的双写者协议写成契约**（含"谁负责重置"） | 它是唯一一条**跨包且锁不同**的现有协议（§3 C4-1），也是"核心包 ↔ 能力包"的第一条真缝 | `note-tools.mjs:1298` 的队列与 `math-memory.mjs:2764-2782` 的重置合成一个导出函数 | ① 一条"并发记命中 + 体检重置"的断言（构造交错，断言不丢计数）；② 协议注释指向契约文件 |

### 第 1 档 — 家族化的前置（建议本轮内完成）

| # | 动作 | 依据 | 验收判据 |
|---|---|---|---|
| **P5** | **把 `buildAuditReport`（1 537 行）拆成"报告"与"写回"，写回改成注入的 `cardWriter`** | §3 C1 的 F7；这条同时是不变量（只报不改）与家族切分的**唯一断点**。目前它直接调用 6 个写盘符号 | ① 断言"不注入 `cardWriter` 时 `buildAuditReport` **零写盘**"；② 既有 `setTopField` 7 条断言仍绿；③ 体检产出的报告与拆分前逐字段相等 |
| **P6** | **常量下沉，消掉 4 条伪偏离**（`CAPTURE_FILE`/`distillSession`/`findSessionLogs`/`scanZstdFrames`） | 守卫自己证明它们的差异是历史遗留（`KNOWN_DIVERGENT` 6 条里 4 条） | 从 `KNOWN_DIVERGENT` 删这 4 条后守卫**仍绿**（该守卫对"已一致却仍登记"会报红，正好当信号） |
| **P7** | **解压器参数化，合并 `decodeZstdSessionLog`/`decodeSessionLog`**（顺带 `readSessionHeader`） | 09-26 的路线图把它列为"不建议现在做"，理由是"有更危险的耦合没解"。**现在那批已解**（A′/B3/B0 落地），而家族切分要求 `CAPTURE` 能力包能独立 | `--sweep` 最高分不再是 0.844；删对应 `KNOWN_ESCAPES` 条目后守卫仍绿；`check-embedded-loader` 绿（证明注入仍生效） |
| **P8** | **物化产物：清空重建 + 单点判据** | §3 C6；家族里每个包都会有自己的物化目录 | 旧版遗留的孤儿文件在重物化后不存在；`check-bundle-recovery` 补一条 |

### 第 2 档 — 与旧路线图合流（不重复提案，只标状态）

| 旧路线图项 | 当前状态 | 说明 |
|---|---|---|
| 方案 A（契约化） | ✅ 主体落地；**剩余**：`overlayRows`/`panelRoutes` 无运行时读者 | 由本文 **P2** 承接 |
| 方案 B（所有权转移 / A′） | ✅ 主体落地（插件侧字面量已删，改为构建期注入契约） | — |
| 方案 C（面板走 HTTP，退役嵌入 loader） | ⏸ **未做**，仍待用户拍板 D2（服务未起来时面板还能不能用） | `main.template.js:176-225` 的 `new Function` loader 仍在。**它是"插件里那份引擎"的直接载体**——退役后 `main.js` 可掉约 76 KB，也是"④ 份 → ③ 份"的直接路径 |
| 方案 D（三份源码指定唯一权威） | ✅ 第 0 步落地（`postureDigests` 基线） | **新增第 4 份**（物化 payload）由 `build-obsidian.mjs` 的第 4 道门覆盖 |
| `AGENTS.md` 的 3 803 配对数字 | ❌ 又过期 | **P9**：把该句改成指向 `--sweep` 输出，不要再写具体数字 |

### 第 3 档 — 建议**缓做**（说清理由）

| 动作 | 理由 |
|---|---|
| 真把 `packages/*` 拆成 npm 包 | 蓝图 §2.1 的**六个前置**（数据契约版本、服务接口、命名规则、家族清单、两条 profile 的姿态、质量度量）一个都还没落地。此时拆包 = 把 N 份手写清单变成 N 个包各自的 N 份 |
| Tier B（embedding）/数据库派生索引 | 它们解锁的是"成本型"限制（[`plugin-family-assessment-2026-10-01.md`](plugin-family-assessment-2026-10-01.md) §1.1），与**耦合**无关；先做 P2–P5 更便宜 |
| 把面板 `if` 链改成表驱动**并且**同时重排路由匹配语义 | P2 已经包含"表驱动"；额外重排顺序会碰信任边界，收益低 |

### 第 4 档 — **本轮的收口状态（2026-10-15，P1–P6/P9 已执行）**

> 执行了 **P1（门禁回归）、P2（契约去幻觉）、P3（数据契约 B+D）、P4（双写者协议）、P5（体检写路径接缝）、P6（loader 三刀 + 定论）**，外加 **P9**。**每一项都可单独回退**，且每步都跑了门禁 + 变异验证。

| 项 | 收口状态 |
|---|---|
| P1 修 `test-agent-preset` 回归 | ✅ 完成（引入提交 `5f5b949`；4 个提交含一次发版曾漏跑全量门禁） |
| P2 契约去幻觉 | ✅ `panelRoutes` 已成**真权威**（面板路由表 + 客户端从注入契约取名，第 4 份副本消失）；`overlayRows` **判定为"结构上已足够"**（行 id 已双向核对；试过两条派生路径**都更差**，理由入库） |
| P3 数据契约 B+D | ✅ 4 类格式补版本；`hook-history` 的标记此前**零覆盖**（已补断言）；`captured-sessions` 的"优先"经核实**不需要迁移机器**（缺版本＝v1 与"拒绝未知版本"已足够） |
| P4 双写者协议 | ✅ 契约化 + 原子写（`.bak` 可观察痕迹）+ 盖章，**三处都有断言** |
| P5 体检写路径 | ✅ **已按 (a) 落地**：接缝 + 归档移动挪到分析之后（报告行为不变）+ 接缝补全（promote 与归档移动原本绕过接缝）。⚠️ 我此前说"(a) 会改变报告"**是错的**，已更正 |
| P6 loader | ✅ **定论**：路线 (2) 真模块解析**已被排除**（有出处的版本证据）；保留 loader、注入面 23 → 10、名字与职责改准 |

**"护栏厚度"读数同时被修正**（§2）：门禁条数量的是**意图**，不是**有效覆盖**。本轮建立并跑了可复现的**变异扫描**（`scripts/qa/mutation-sweep.mjs`，**23 条，23/23 检出**），它当场抓到 **1 个真 bug（两份 shim 早已漂移）+ 3 个真盲区**（统计重置的原子性、`note_recall` 的版本盖章、overlay 的裸声明行）。⇒ 这是本评估里**唯一一条"把自称的验证变成可复核证据"**的工作，也是后续任何"加守卫"动作的下限要求。

---


## 5. 哪些耦合是必要的、哪些是自找的（更新版）

沿用 09-26 §4 的判定框架，只列**判定有变化**的行：

| 耦合 | 上次判定 | 本次判定 | 依据 |
|---|---|---|---|
| 三份源码 → **四份**（新增物化 payload） | 一半自找 | **仍是"一半自找"，但新增的那一份是"交付形态的必要代价"** | ② 单文件分发、③ 离线通道、④ 插件管理页可见性——三者都是产品要求；**自找的是"没有单点权威来生成它们"**，现在 payload 已有第 4 道门 |
| 四份文件名清单 | 自找 | **已收敛为"一处权威 + 三处真读 + 四处被钉住"**，判定改善 | §3 C2 |
| 契约的 `overlayRows`/`panelRoutes` | — | **新增：自找（契约幻觉）** | 两个字段零运行时读者 |
| 读 `retrieval-stats.json` 的双写者协议 | — | **新增：自找（跨包协议未契约化）** | §3 C4-1 |
| dsh CLI / token / cookie / 会话日志 / `ctx.*` | 必要 | **必要（不变）** | 只能用 dsh 的公开入口 |
| 端口三角色 | 必要 | **必要（不变）** | `docs/port-and-isolation.md` 已论证 |

---

## 5.5 守卫清点：55 条门禁到底在守什么（2026-10-15 实测）

> 用户问"目前有 400 多条守卫，会不会有冗余、需要解耦吗"。**先把数字校准**：**不是 400 多条门禁**，而是 **55 条门禁**（`scripts/lib/gates.mjs` 注册表，由 `check-doc-counts.mjs` 守住）；**约 1 195 条断言**（各套件自报 `__CHECKS__` 之和，另有约 30 条门禁不申报计数）。下面全部是实测：`node scripts/qa/mutation-sweep.mjs` 与逐条计时脚本（112.0s 全套）。

| 类别 | 条数 | 断言 | 耗时 | 说明 |
|---|---|---|---|---|
| **A. 语法检查**（`node --check` 单文件） | 12 | 0 | 1.3s | 每条只检查一个文件能不能被 parse |
| **B. 行为测试**（跑代码、断言行为） | 14 | 958 | 73.1s | 真正的覆盖；`test-memory` 一条就 478 条 |
| **C. 一致性守卫**（比对两处事实） | 28 | 237 | 37.5s | **全部门禁的 51%**，正是"防跨边界漂移"那一族 |
| **D. preset 可加载性** | 1 | 0 | 0.2s | import 一次 preset 并检查它暴露 name |

**成本集中在极少数**：最贵的 6 条 = `installer e2e` 30.1s、`doc consistency` 22.6s、`panel auth e2e` 15.5s、`rebuilds a wiped $DSH_HOME` 8.7s、`agent preset mounts` 7.4s、`self-provisioned profile` 7.0s ⇒ 合计 91s，占 112s 的 **81%**。**其余 49 条合计 21 秒。**

### 有没有真冗余？逐类查过，结论是"没有可删的重复"

- **"同一文件被多条门禁读"很常见，但那是补集，不是重复。** 例：`dsh/profile/notes-assistant.patch.yml` 被 **10 条**门禁读到——`shipped yaml parses` 查它是不是合法 YAML、`preset declaration is current` 查生成块是否最新、`profile contract` 查行 id 与契约双向一致、`overlay drops bundle-owned rows` 查**运行时裁剪行为**。**四条断言的是四件不同的事**，删任何一条都会留下一个无人看守的缺口。我逐条核对过候选对（`plugin id` vs `manifest meta`——一个查 id 被三处引用一致、一个查图标/locale/peer；`doc constants` vs `doc consistency`——一个查工具/论文常量、一个查计数锚点），**没有一对是"同一事实、同一判据"**。
- **真正"零断言"的只有 13 条**：12 条语法 + 1 条 preset 可加载性。其中 **`main.js` 那条可以被 `bundle freshness` 吸收**（后者会重建整个 bundle 并逐字节比对，语法错必然先在那里炸）。但它只花 **130ms**，而它给的是"**哪个文件第几行**"的定位，比"重建产物与提交不符"有用得多。**删掉它省 130ms，换来更难读的失败信息——不值得。**
- 所以：**守卫层面没有值得动的解耦**。55 条里有约一半是"因为系统耦合才存在"的，这一点成立；但它们是**症状的守卫**，不是症状本身。

### 那"门禁太多"该怎么减？答案是减耦合，不是减守卫

`§2` 已经量过：**28 条一致性守卫（51%）存在的唯一理由是"防止跨越某条边界时漂移"**。要减少它们，得让**边界消失或变窄**，而不是删守卫——这次解耦里已有两个实例：

| 做法 | 效果 |
|---|---|
| `panelRoutes` 变成**唯一的运行时权威**（客户端从注入契约取名） | 第 4 份副本消失 ⇒ 守它的断言从"比三处"变成"比两处" |
| loader 注入面 23 → 10 | 守注入面的断言面变窄 |

**所以：要"门禁变少"，该做的是继续把"同一事实存在多处副本"的地方合并成单一权威**（这正是 §4 P2 那一类工作）。反过来先删守卫，会得到一个**更小但更瞎**的测试面——2026-10-15 那次变异扫描已经示范过代价：**扫描清单扩到 29 条后，共发现 1 个真 bug（两份 shim 早已漂移）+ 3 个真盲区（统计重置的原子性、`note_recall` 的版本盖章、overlay 的裸声明行），每一个在被发现时门禁都是绿的**。

**一个可选的下一步**（若你想让测试面更瘦）：把 `doc consistency`（22.6s）里"逐文件扫全仓找计数锚点"的部分改成**只扫声明了锚点的文件**，或把它的正则预编译——那是**性能**优化，不是冗余清理。我没有动它，因为它现在**每次都能查出真漂移**（本轮就拦住我三次）。

**本节数字怎么复现**（不留一次性脚本进仓库）：读 `scripts/lib/gates.mjs` 的注册表拿到 55 条 `{name, args}`，逐条 `execFileSync('node', args)` 计时；断言数优先取输出里的 `__CHECKS__ n/m`，没有就数 `[ok]` 行，两者都没有就记"不申报计数"。⚠️ 一个已知的复现坑：`preset: imports and exposes its name` 这条的 args 是 `['-e', "import(…)"]`，**裸 `execFileSync` 会因为没有 `-e` 的脚本参数而 exit 1**，必须在脚本里特殊处理（正常执行器会处理它，所以 `npm test` 是绿的）。我第一版没处理，于是拿到一个假的 exit 1——**"自己写的度量脚本也会骗人"的又一例**。

---

## 6. 需要你决定或知道的事

> ⚠️ **本节写于评估当时，内容已被其后的执行工作取代。** §6.1 那条红**已修**（`8cd48f6`，并补了变异验证）；§6.2 的三项**已全部拍板**（J1=B、J2=B+D、J3 撤回——用户明确"家族拆包先不急"）。保留原文是为了让读者看到"当时的判断"，但**不要照它行动**；当前状态看 §4 的第 4 档收口表。

### 6.1 ⚠️ 已知的红：一条真回归（不是环境结果）

```
53/54 gates passed in 173.4s
FAILED: test: agent preset mounts (real dsh, no tokens) (exit 1)
  ReferenceError: deployedIsBundle is not defined
      at scripts/test-agent-preset.mjs:285:39
```

**根因**（我已定位到行）：`const deployedIsBundle = …` 在 **157 行声明于 `{ }` 块内**（145–163 行的 overlay 检查块），而 **285 行**在另一个 `{ }` 块里引用它。它在 `packageOwnsIt` 为真时求值——也就是**bundle 通道**的 profile。

**为什么它一直没被发现**（这点比 bug 本身更值得记）：
- 引入者 `5f5b949`（"bundle 通道的完整性基线写早了"）把变量放进了块内；
- 该分支要求 `$DSH_HOME/profiles/<id>/node_modules/dsh-math-memory/dsh/cordis.patch.yml` **存在且声明了 preset**——我在本机实测为**真**，所以它在"bundle 通道已安装"的机器上**必然崩**；
- 于是"这条门禁"此前只评估了 145–163 那一段，**284 行那条"声明恰好在一处"的断言从未真正跑过**。这与仓库自己的陷阱族同形（"只测已配置的分支"、"SKIP 不等于通过"）。
- 时间线：`5f5b949` 之后还有 4 个提交（含 0.8.1 发版 `126d181`）——也就是说**发版时这条门禁没有全量跑过**。

**我没有动你的代码**（本次授权是"只读评估"）。修法是一行作用域（把 157 行的 `const` 提到块外，或把该块改成表达式），但因为它改的是**门禁自身**，我建议由你落，并顺手做一次变异验证（把包内 patch 的声明行删掉 ⇒ 必须是**红**，而不是"崩"）。

### 6.2 需要你拍板的三项（都影响家族形状）

| # | 决定 | 选项 | 我的建议 |
|---|---|---|---|
| **J1** | 方案 C 现在做不做（退役嵌入 loader、面板走 HTTP） | A 保留现状 / B 退役（服务未起 ⇒ 面板不可用）/ C 折中（读留在进程内、写全走 HTTP） | **选 C**（同上一次的 D2 建议）。它是"四份 → 三份"最直接的一刀，且把最容易出事故的**写入器**搬出插件 |
| **J2** | 数据契约版本字段的**兼容基线**怎么定 | A 只做"缺版本 = v0、向上兼容"（纯加法）/ B 同时上"一跳一个迁移包"（照 dsh 会话格式的先例） | **先 A**。迁移机制要为**已经存在的历史文件**服务，而现在没有任何外部第三方在读这些格式——先补版本、把"未知版本 ⇒ 拒绝写入并报告"这条规则立起来，迁移等真有 v2 需求时按蓝图 §4.2 加 |
| **J3** | 家族拆包的门槛 | A 先把 P2–P5 做完再拆 / B 边拆边补契约 | **选 A**。蓝图 §2.2 自己写明"没有契约包，第三方贡献无从谈起"；本文 C2/C4 就是那两份契约的空白清单 |

---

## 7. 取证方法与边界（可复核）

**本次实跑的命令**（全部只读；唯一的写操作在会话工作区的 `._coupling-scratch/` 与 `%TEMP%`）：

```
node scripts/run-gates.mjs --list                 → 54 条（与 scripts/lib/gates.mjs 一致）
node scripts/run-gates.mjs                        → 53/54（唯一 FAIL = §6.1 的真回归）
node scripts/check-engine-sync.mjs                → 170 / 61 符号；23 = 17 同步 + 6 偏离；0 stale
node scripts/check-engine-sync.mjs --sweep         → 3803 对，阈值 0.70，最高 0.844 / 0.792 / 0.662
node scripts/check-frontmatter-source.mjs          → ok（98 文件，宿主拷贝 13 fixtures 等价）
node scripts/check-bundle-freshness.mjs            → 已提交的 main.js 与全新构建逐字节相同
node scripts/check-profile-contract.mjs            → ok（3 read + 7 pinned；PINNED-7b bootstrap=10 cli=10）
node scripts/check-preset-body-lists.mjs           → ok（closure==list(4)；local bundle derived=16）
node scripts/check-overlay-bundle-rows.mjs         → ok（22/22）
node scripts/check-bundle-recovery.mjs             → ok（38/38，含 1 条自报 SKIP：no pnpm）
node scripts/test-real-profile-accept.mjs          → 10/10（首次曾 3/4，未复现，判为偶发并如实记录）
git diff --stat b29c566..HEAD / git status         → 102 commits，+14 798 行，工作树干净
```

**三项隔离实验**（写在会话工作区的 scratch 目录，**未触碰被审仓库**）：

1. **import 图**：101 个本地模块的 fan-in —— 最高是 `hook-frontmatter.mjs`（8）与 `profile-contract.mjs`（7）；`math-memory.mjs` 只被 3 个 QA/测试文件 import（**说明引擎的耦合主要不是"被很多文件 import"，而是"被嵌入三份"**）。
2. **产物字节分解**：`main.js` 870 609 B = 模板 215 527 B + 内嵌引擎 JSON 550 842 B + 物化 payload JSON 26 563 B + 转义开销。
3. **W1-profile 修复实验**（复核 D2 的 Case C）：抽出真实的 `ensureProfileDeclaration`，喂三种现场 —— 旧形态（有声明行、无标记）/ 无声明无标记 / 空文件。结果：**三种全部修复到 canonical 形态，`repaired=true`；第二次运行 no-op**。⇒ 该修复路径健全，Case C **不成立**。

**本文明确未验证的**：

- `probeService` 的 403 情形、`</head>` 缺失的**后果**、`/api/` 前缀与 dsh 真实 mux 路径——均无真实 dsh 用例（`test-panel-proxy` 的上游是仓库自写 stub，对真实 dsh 属**自证**）。
- 客户端路由 4 条字面量的**运行时症状**（设置页 404）未在真机触发。
- `retrieval-stats.json` 双写者的**真实丢失**未构造出来（只从锁的缺失推断）。
- `--sweep` 的 3 条共享模块比对声明的逐条明细未展开。
- 家族化的**成本**（N 个包的门禁预算、两条 profile 的维护面）本文只给依据，未做估算。

---

## 8. 一句话回答"该不该现在做家族"

**该做的前置不是拆包，而是把两份契约补全**：让 `profile-contract.mjs` 的两个零读者字段变成真权威（P2），给 4 类零版本的知识格式补上版本与降级规则（P3），把跨包的 `retrieval-stats` 协议写下来（P4），再把 1 537 行的 `buildAuditReport` 拆成"报告 / 写回"（P5）。**这四件事做完，"拆包"会退化成机械动作**；不做，家族化的实际效果是把当前的"四份手写清单"复制成"N 个包各自的四份"。
