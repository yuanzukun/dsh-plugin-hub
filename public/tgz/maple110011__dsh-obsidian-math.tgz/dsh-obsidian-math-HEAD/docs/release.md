# 发布手册（Release Runbook）

> 目标读者：维护者本人。**一次发版只改一个数字，其余全部由守卫自动校验**；
> 任何一步跳过都会在 CI 或用户端以「版本拿不到」的形式暴露出来。

## 0. 两个产物，一个版本号

| 产物 | 渠道 | 由谁取用 | 版本号来源 |
|---|---|---|---|
| Obsidian 插件 | GitHub Release（tag = 版本号） | 用户手动安装 / BRAT / 社区商店 | `manifest.json` |
| npm 包 `dsh-math-memory` | npm registry | `dsh plugin add` / `dsh/install.mjs` | `package.json` |

两者必须同号：用户可能一边用 npm 装的 preset，一边用 Release 装的插件。
`scripts/check-version-consistency.mjs` 强制下面 **五个**位置一致：

1. `package.json` → `version`
2. `manifest.json` → `version`（必须是纯 `x.y.z`，Obsidian 社区注册表拒绝预发布号）
3. `package-lock.json` → `version`（跑一次 `npm install` 刷新）
4. `versions.json` → 新增一条 `"<版本>": "<minAppVersion>"`
5. `CHANGELOG.md` → 最新的非 `[Unreleased]` 标题 `## [<版本>] - YYYY-MM-DD`

带 tag 时（`--tag 0.7.5`）还会额外要求 **tag 字符串 === 版本号**。

## 1. 发版步骤

```bash
# ① 版本号（4 个文件）+ versions.json 新条目
#    package.json / package-lock.json（两处：根与 packages[""]）/ manifest.json
#    versions.json: {"0.7.6": "1.4.0", ...}   ← 只增行，不删旧行

# ② CHANGELOG.md：把 [Unreleased] 攒的内容改成
#    ## [0.7.6] - YYYY-MM-DD，并在顶部留一个空的 [Unreleased]

# ③ 重新生成被提交的产物（CI 有 rebuild + git diff 门禁，忘了必红）
node scripts/build-obsidian.mjs      # obsidian/main.template.js → main.js
node dsh/client-panel/build-client.mjs   # src/index.jsx → lib/client.js（改了面板才需要）

# ④ 本地过一遍与 CI 完全相同的门禁
npm test
node scripts/check-version-consistency.mjs --tag 0.7.6
#    ⚠️ 本机全绿 ≠ CI 全绿：认证握手套件在本机（装了 dsh）会真跑、在 CI 上按设计 SKIP；
#    Windows runner 检出的是 CRLF。推 tag 前先确认 ci.yml 的 ubuntu 与 windows 两个 job 都绿
#    （0.7.5 第一次推 tag 就栽在这两点上）。

# ⑤ 提交与打 tag（推送需要用户口令，见 §4）
git add -A && git commit -m "0.7.6: <一句话主题>"
git tag 0.7.6          # 注意：不带 v 前缀，release.yml 只匹配 [0-9]+.[0-9]+.[0-9]+
git push origin main
git push origin 0.7.6  # ← 这一步才会真正产出 Release
```

`npm-publish.yml` 在推 tag 时并行发布 npm 包。**认证走 trusted publishing（OIDC），不再用长效 token**：

- npm 正在废弃 2FA-bypass 的 granular token（[2026-07-08](https://github.blog/changelog/2026-07-08-npm-install-time-security-and-gat-bypass2fa-deprecation/) / [2026-07-31](https://github.blog/changelog/2026-07-31-restricting-npm-bypass-2fa-granular-access-tokens/)）：这类 token 已不能做账号/包管理，**约 2027-01 起也不能直接发布**。
- **一次性配置（人工 + 2FA，自动化不了）**：npmjs.com → 包 `dsh-math-memory` → Settings → Trusted Publisher → GitHub Actions，填 `maple110011` / `dsh-obsidian-math` / **workflow 文件名 `npm-publish.yml`**（环境留空）。**workflow 名填错是最常见的失败原因。**
- workflow 侧：`permissions: id-token: write`（已有）、**不设 `NODE_AUTH_TOKEN`**、npm 必须 **≥ 11.5.1**（所以显式 `npm install -g npm@11`；Node 22 自带 npm 10）。**故意钉 11 不钉 12**：npm 12 打开了安装期安全默认值（依赖 lifecycle 脚本默认不跑，需 allowlist），会静默跳过 esbuild 的 `postinstall` 二进制下载。
- 失败时先看 `Registry / OIDC diagnostics` 那一步：它打印 npm 版本、是否拿到 `ACTIONS_ID_TOKEN_REQUEST_URL`、以及 `whoami` 的结果。**发布失败时同一份信息还会进 job summary 与一个 issue**（job 日志需要 admin 权限才能读，issue 不需要），其中包含 registry 的原话 + **本次实际出示的 OIDC claims**。
- **两种情况用错误码就能分辨**：`E404` = npm 上没有匹配的 trusted publisher（没配 / 仓库名或 workflow 文件名对不上）；`E403 OIDC permission denied for this action` = 配置**匹配到了**但某个 claim 不一致（最常见是 **environment**，或 workflow 文件名写成了全路径）。
- 本仓库的 workflow 实际出示的 claims（2026-09-11 实测，可作为比对基准）：

  ```
  repository        = maple110011/dsh-obsidian-math
  job_workflow_ref  = maple110011/dsh-obsidian-math/.github/workflows/npm-publish.yml@refs/tags/<tag>
  event_name        = push          ref_type = tag
  aud               = npm:registry.npmjs.org
  ```

  注意**没有 `environment` claim**（job 未声明 `environment:`），所以 npm 侧的 Environment 必须留空。
- **用 CLI 配置/核对（npm ≥ 11.10，需账号 2FA；每个包只允许一条配置）**：

  ```bash
  npm trust list dsh-math-memory --json          # 看现有的 file / repo / environment
  npm trust revoke --id <trust-id> dsh-math-memory   # 要改就得先撤销（一个包只允许一条）
  npm trust github dsh-math-memory --file npm-publish.yml \
      --repo maple110011/dsh-obsidian-math --yes   # 不带 --env 即要求无 environment
  ```

- 若 npm 侧只能选**分阶段发布**（staged publishing，需人工 2FA 批准后才公开），workflow 要改成 `npm stage publish`（需要 npm ≥ 11.16/12：可以放在 `npm ci` **之后**再升级 npm，避开 npm 12 的安装期默认值），并保留最后的人工批准步骤。这一步尚未实现——需要时再改。

## 2. 三个工作流各自的门禁

| 工作流 | 触发 | 做什么 |
|---|---|---|
| `ci.yml` | push / PR | Ubuntu + Windows 双矩阵：`npm ci` → 版本一致性 → **Ubuntu 上**重建 `main.js` 并 `git diff --exit-code` → `npm test` |
| `release.yml` | 推 `x.y.z` tag | 版本一致性（含 tag）→ 重建 + diff 门禁 → `npm test` → 从 CHANGELOG 抽取**该版本**段落当 Release notes → 上传 `main.js` / `manifest.json` / `styles.css` / `versions.json` |
| `npm-publish.yml` | 推 `x.y.z` tag | 同上校验 → `npm publish --provenance`（OIDC，无 token）→ **按 registry 实际状态判定成败**（约 6 分钟退避轮询；public 即成功并关闭历史失败 issue；missing 则打印 npm 原话 + OIDC claims、开 issue、判失败） |

**发布是否成功只由 registry 状态决定，不看 npm 的退出码**——「退出码/流水线在撒谎」的情况已经遇到过三种：

- **退出码 0 ≠ 已发布**：分阶段发布（staged publishing）上传后等人用 2FA 批准，此时公开 registry 上什么都没有，而 pipeline 会全绿（0.7.5 就出现过一次「全绿但 npm 上没有」）。
- **退出码非 0 ≠ 未发布**：重复推送同一个 tag 时 npm 报 `You cannot publish over the previously published versions`，而该版本其实早就在了（仓库为修发布链路反复移动过 0.7.5 tag）。现在这种情况算成功。
- **⚠️ 第三种：registry 的可见性有延迟（0.7.6 实测 60–80 秒；0.7.7 约 4–5 分钟；0.7.8 约 92 秒；0.8.0 **> 90 秒**）**。`Publish` 步 success、日志里已有 `+ dsh-math-memory@<版本>`，但下一步 `Confirm the registry state` 查到的仍是 missing ⇒ 开 issue + 判红。
  - **该步已经会轮询，问题在预算**（2026-09-27 更正）：改前是固定 90 秒（6 × 15 s），而上面四次实测的延迟**在增长**、最长到 4–5 分钟 ⇒ 90 秒必然偶尔不够。现为 **18 次退避轮询（前 6 次 10 s，其后 25 s，约 6 分钟）**，并把 `elapsed Ns` 打进日志，便于以后重新定标。**"轮询存在"不等于"轮询够久"。**
  - **处置**：**先用只读方式独立核实 registry 的真实状态，不要凭 workflow 的结论行动**（0.7.8 实测有效的查法：直接取 `https://registry.npmjs.org/dsh-math-memory/latest`，回应里 `"version"`/`"_id"` 就是当前真实状态；本机 `npm view` 在受限环境可能因 `EPERM` 写不了缓存而失败，**失败≠未发布**）。若 registry 已有该版本 ⇒ 该红是**假失败**：可 `Re-run failed jobs`（等 registry 可见后第二次即绿并自动关 issue），也可以不 re-run、只手工关 issue。**绝对不要据此改代码或版本号。**
  - **附带后果**：失败路径会把"关历史 publish-failure issue"那一步 `skip`，所以每次这类假失败都**留下一件手工事（关 issue）**；issue 正文里最好写明"实际已发布 + 核实依据"，与 0.7.7 的做法一致。

历史教训（已修，勿回退）：

- Release 的 notes 曾是 `## [Unreleased]`——旧 `awk '/^## \[/{n++} n==1{print}'` 取的是第一个段落。
- 推 tag 的工作流曾**不跑任何测试**：任何能推 tag 的人都能从任意未验证提交发版。
- 版本号曾三方漂移（package 0.7.3 / manifest 0.7.4 / npm latest 0.7.1），
  于是「插件商店拿不到新版本」——见 §3。
- **本机全绿 ≠ CI 全绿（0.7.5 第一次推 tag 就栽在这上面）**：两个只在 CI 环境暴露的守卫缺陷——① `check-doc-consistency.mjs` 把「套件在本机 SKIP（没有 dsh）」当成失败；② 两个嵌入守卫用多行字面量解析文本，Windows runner 的 **CRLF** 检出让它们误报。修法见 `handoff.md` 坑 56/57。**推 tag 前先看一眼 `ci.yml` 的两个 job 是否都绿**（Ubuntu + Windows）。
- **`npm publish` 的失败信息为零，且 token 路线正在被废弃**：token 缺失/过期/无发布权/需要 2FA 都只有非零退出码。已改为 **trusted publishing（OIDC）**：workflow 不设 `NODE_AUTH_TOKEN`、显式 `npm install -g npm@11`（要求 ≥11.5.1，Node 22 自带 npm 10）、publish 前加只读诊断（npm 版本 / id-token 端点 / `whoami` / **解码后的 OIDC claims**）。**npm 侧一次性配置是人工动作**：包 Settings → Trusted Publisher → GitHub Actions 填仓库 + workflow 文件名 `npm-publish.yml`、**environment 留空**（job 未声明 environment，claims 里没有该字段 ⇒ 填了必然 403）。别再创建长效发布 token：2FA-bypass token 已失去账号/包管理能力，约 2027-01 起失去直接发布能力。**2026-09-11 实测全通**：`dsh-math-memory@0.7.5` 已发布并带 SLSA provenance 证明。
- **npm 12 的安装期安全默认值**（`allowScripts` 默认关、`--allow-git`/`--allow-remote` 默认 `none`）：本项目唯一带 lifecycle 脚本的依赖是 devDependency `esbuild`（`postinstall: node install.js`）。`npm ci` 仍会成功，但 **esbuild 的二进制不会下载**，于是 `npm run build:client` 会失败。因此发布工作流钉在 npm 11；将来升 12 时先跑 `npm approve-scripts --allow-scripts-pending` 并把 allowlist 提交进 `package.json`。
- **本地 registry 缓存会骗人**：排查期间通过本机代理查询 `registry.npmjs.org` 拿到的是**过期文档**（`modified` 时间戳停在旧日期、`/0.7.5` 返回 404），而包其实已经发布。判断「到底发出去没有」要用带 cache-buster 的直连查询，或者看 workflow 里那步 `Confirm the registry state` 的输出。

## 3. Obsidian 插件商店的更新通道

> **⚠️ 更正（2026-09-15）**：本节原标题是「为什么 Obsidian『插件商店』看不到新版本」，并断言「插件 id 不在 `community-plugins.json` 里 ⇒ 浏览里搜不到」。**那个判据已经作废**：实测该文件至今（2991 行）仍没有 `dsh-math-assistant`，但插件**已在架** —— Obsidian 的收录方式已改变，`community-plugins.json` 不再是收录依据。现行依据是插件在 [community.obsidian.md/plugins/dsh-math-assistant](https://community.obsidian.md/plugins/dsh-math-assistant) 有页面。**判断"上架没有"要查商店页面本身，不要查这个 JSON**（见 `handoff.md` 坑 78）。下面的"更新通道"部分仍然成立，它是**版本可见性**的机制，与收录方式无关。

更新通道只认一件事：**仓库里存在 tag 等于 `manifest.json` 版本的 Release**。插件在架、但版本页停在旧号的典型成因：

- `manifest.json` 的版本必须有一个**同号 tag 的 Release**；本地 git tag 曾停在 0.7.1、npm `latest` 也是 0.7.1，而 0.7.2–0.7.4 从未发过 tag ⇒ 用户端能拿到的最新版永远是 0.7.1。

结论：**发版 = 推 tag**，不是改版本号。改完版本号不推 tag，等于什么都没发生。

三条可用的分发路径：

1. **社区商店安装**（推荐，[商店页](https://community.obsidian.md/plugins/dsh-math-assistant)）：Obsidian → 设置 → 第三方插件 → 浏览 → 搜索 **DSH Math Notes Assistant**；更新随插件管理器走。
2. **手动安装**：下载 Release 的 `main.js` + `manifest.json` + `styles.css` 放进 `<vault>/.obsidian/plugins/dsh-math-assistant/`。
3. **BRAT**（Beta Reviewers Auto-update Tool）：填 `maple110011/dsh-obsidian-math`，它按 Release 的 `manifest.json` 版本自动更新——同样要求先推 tag。
4. **分发面**：上架后再改名/改 id 会被商店判为"新插件"，`manifest.json` 的 `id` 与 `scripts/check-plugin-id.mjs` 必须保持一致。（历史上曾通过向 `obsidianmd/obsidian-releases` 提 PR 在 `community-plugins.json` 追加条目来上架；该路径已不适用，仅作历史记录。）

## 4. 推送纪律

- `git push` / `git tag` 推送 / `npm publish` **必须等用户明确口令**，不要自行执行。
- 本地 `npm test` 全绿 + `check-version-consistency --tag <版本>` 通过，是请求口令前的最低门槛。
- 发版后回头核对三处：GitHub Releases 页面有该 tag、npm `npm view dsh-math-memory version`
  等于该版本、`docs/handoff.md` 记录本次发版。

## 5. 版本更新说明（CHANGELOG 段落）的写法

`CHANGELOG.md` 的版本段落**会原样成为 Release 正文**（`release.yml` 抽取），所以它同时是**面向用户的更新说明**。写法规则（2026-09-18 用户明确要求）：

- **正文开头只写一段「本版主要包含哪几个方面」的摘要**——3–4 个方面，每个方面点出关键机制即可，让读者十秒内知道这版在做什么。
- **不要在段落里写内部过程**：累计了多少个提交、哪个版本漏发过、哪些内容曾长期躺在 `[Unreleased]`、门禁/断言数从多少涨到多少（后者属 `Internal` 小节，可保留但不必进摘要）。这些是**维护者细账**，去处是 `docs/changelog.md`。
- 摘要之外的小节（`Added` / `Changed` / `Fixed` 等）照旧按用户价值写。
- **口吻用第三人称：写「用户」，不写「你」**（2026-10-05 用户明确要求）。这是**发布说明**，不是给某个人的回信；同一条里也不要出现"你说的""你的库"这类指代。
- **只写"改了什么"，不写"为什么这么改"**（2026-10-05）。「抬高下限会把还能用的人挡在门外」这类**原因**属于 `docs/changelog.md`；用户要看的是这次行为变成了什么。同一段里"为什么"最多以从句形式出现一次，且只在**它本身就是用户关心的后果**时。
- **评估类与一般实现文档不进发布摘要**（2026-10-05）。`lemmalog 评估`（结论"不引入"）、`dsh-0.2.0-adaptation`（适配过程）这类**不进**；只有**特别重要**的文档才在里面说明（判据：用户会因为不看它而**误用或误判这个版本**吗？答"不会"就不写）。⚠️ 移出摘要的内容必须**在内部文档里仍有一处权威记录**，别把唯一记录删掉。
- **面向所有读者，不用内部说法**（2026-10-05，用户第二次指出）。判据是"**一个没读过我们对话、也不了解这套系统的人能看懂吗**"。具体禁忌（都实测出现在 0.8.1 的第一稿里）：
  - **不要描述我们内部观察到的那次失败**（"此前讨论同一话题时助手容易每次都给出差不多的回答""那篇高分笔记被当成结论复述了"）——读者不知道在说哪件事。要写成读者能想象的**一般情形**（"同一篇旧综述被反复当成结论使用，是回答雷同的常见原因"）。
  - **不要出现内部字段名/标记语法/代号**（`origin`、`<!-- AI 补全 -->`、`［AI 补全 ×N·不宜当结论］`、`三条写`、"固化""闸门""候选项""事件层""互证""检索排序"）——用日常说法替换（"来源""助手补写的段落""还没定稿""互相印证""搜索结果的顺序"）。
  - **术语首次出现时要自解释**，例如"记忆卡（助手把对话整理成的笔记条目）"。

**为什么写进手册**：这是第二次出现"把维护者视角写进用户说明"的返工（第一次是 0.7.8 的摘要，用户读后指出不需要"本版是 X 之后累积的全部改动、共 N 个提交"这类交代）。规则写在手册里，比留在某次对话里更可能被下一次发版的人遵守。

> ⚠️ **2026-10-05：返工发生了第三次，而且规则当时就在上面这几行里。** 0.8.1 的摘要又写进了"门禁 54/54、零 token 回归 455""第一次直查 registry 是 404""陷阱 115""（Zhang et al., …Table 5）"以及"本批含 0.8.0 之后未提交的全部改动（56 项）"——**其中最后一条正是第一次返工被否掉的原话**。段落从 2640 字符压回 2097。教训不是"再写一条规则"，而是**手册里有规则 ≠ 下次会读到它**：所以把动作钉在这里——

**发版前的自检（三步，每步都要能回答"是"）**：

1. **我读过 §5 了吗？** 逐条对照上面三条规则，特别是"不写内部过程"。
2. **段落里每个数字/编号问一遍"这对用户意味着什么"**——答不上来就删（门禁数、断言数、提交数、陷阱编号、流水线延迟、registry 状态全部属此列）。
3. **摘要是不是"十秒版"**？3–4 个方面各点一句机制即可。**逐条对照 §5.1 的形式**：四类小节、**一条一句话**（dsh 实测 20–50 字）、不写"此前→现在"、不出现内部说法、"解耦/接缝/契约"这类**维护者收益**不进摘要；**为什么这么做**留给 `docs/changelog.md`。

> 📌 **已发布的 Release 正文不会随 `CHANGELOG.md` 更新**（它是打 tag 那一刻的快照）。发现写法问题就地修正 `CHANGELOG.md`，再按 0.7.8 的先例在 `docs/archive/` 存一份**从 CHANGELOG 抽取生成**（不要手抄——第一次手抄时相对链接就少了一层）的修正快照；需要让线上正文也跟上时，用 `gh release edit <tag> --notes-file <文件>`。

### 5.1 形式：四类小节、一句一条（2026-10-16 用户明确要求，参照 dsh 官方 Release）

**参照**：[dsh 的 Release 正文](https://github.com/deepseek-ai/deepseek-harness/releases)（如 `dsh-v0.2.1-alpha.3`）。小节固定四类、按此顺序，**空的不写**：

| 小节 | 放什么 | 旧名 |
|---|---|---|
| `### 新增功能` | 用户**新得到**的能力 | `Added` |
| `### 问题修复` | 用户**此前会遇到**的故障 | `Fixed` |
| `### 体验优化` | 行为或界面变了，既不是新能力也不是修 bug | `Changed` 的一半 |
| `### 其他变更` | **会影响用户做法**的迁移项（"需重新选择""需迁移"），以及"这不是硬限制"这类必须说清的边界 | `Changed` 的另一半 |

**一条一句话**（硬规则；dsh 条目的实测区间是 **20–50 字**）：

- 一条 = **一个用户能看见的结果**，陈述句，一句话说完。
- **不要"此前会怎样 → 现在会怎样"**。历史对比、根因、排查过程、证据（门禁数 / 断言数 / 提交数 / 陷阱编号 / `file:line`）**全部**属于 `docs/changelog.md`。
- **不出现内部说法**：字段名、层名、标记语法、代号，以及"解耦 / 接缝 / 契约 / 派生缓存 / 双写者"这类维护者词汇。**维护者的收益不是用户可见结果**——例如"功能解耦，以便后续开发"不进摘要；若解耦**确实**改变了用户能看到的东西（面板怎么取数、报错是否明确），**只写那个结果**。
- **只有读者会误用**时，才多给一句后果。
- 摘要段一句话说清 2–4 个方面。不用 emoji 小节名（dsh 最近的版本也已去掉）。

**为什么把形式也钉住**：§5 的既有规则已被违反三次（第三次时规则就在上面），但三次都是"写太长"，而"长"此前只算风格差异。把四类小节 + 一句一条 + 反例写死之后，"写长"变成**可以指认的违规**。

**反例（2026-10-16 实际压过的两条）**：`CHANGELOG.md` 里"每次打开 Obsidian 弹红字"那条 **~300 字 → 40 字**，"助手不会再上来就让你选"那条 **~260 字 → 28 字**。删掉的是根因与连带影响——它们本来就在 `docs/changelog.md` 里，摘要只留结果。


