# 变更账本：为什么改、怎么改、踩了什么坑

> **范围**：**整个仓库**，不只是记忆子系统（本文原名「记忆系统变更日志」、位于 `docs/memory/`，2026-09-11 提升到 `docs/changelog.md`——因为它的内容早已超出记忆子系统，而目录位置在说"这是记忆那摊事"）。
> **与根 `CHANGELOG.md` 的分工**：根文件是**发布摘要**（每个版本面向用户「改了什么」）；本文是**维护者细账**（为什么这么改、排查过程、实测数字、被否决的方案）。**最新在上。**

## 索引

- [`changelog-2026-Q3.md`](changelog-2026-Q3.md) —— 2026-08 ～ 2026-09 的历史分段（只读）
- 本文件 = **2026-10 起**（最新在上；新条目追加在本索引之后）

## 2026-10-18 · 0.8.3 发布：适配 dsh 0.2.1-rc.2、修复侧栏对话、移除侧栏皮肤/性能适配（**已实现**）

**版本**：0.8.2 → **0.8.3**。九处版本声明以 `node scripts/check-version-consistency.mjs --tag 0.8.3` 为准：`package.json` / `package-lock.json`（两处）/ `manifest.json` / `versions.json` / `CHANGELOG.md` / `README.md` / `README.zh.md` / `docs/handoff.md` 与 `docs/memory/design.md` 的 `> 当前版本：` 横幅。
**用户可见内容**：见 `CHANGELOG.md` 的 `[0.8.3]` 段（适配 dsh 0.2.1-rc.2；移除拖拽引用与侧栏皮肤/性能设置）。修复 `{{cwd}}` 的技术细节见下一条。
**内部整理**（不进 Release notes）：文档结构清理（索引/traps/backlog/按季 changelog/身份头）、handoff 与 changelog 瘦身、sidebar-performance 归档、README 中英改写；皮肤中心与侧栏性能适配的代码/测试/文档同步删除（proxy 32→24 条断言）。
**验证**：`test-panel-proxy 24/24`；`test-installer` 覆盖"旧声明块含 `{{cwd}}` 会被刷新"的升级路径；临时 `DSH_HOME` 冷安装两条通道（`--flat` 与 bundle）均 exit 0、0 个 `{{cwd}}`、`--dump-config` exit 0；全量 `run-gates` **52/55（0 SKIP）**，3 条失败是沙箱环境（`test-panel-routes` 写 `D:/notes` 被拒、`doc consistency` 连带、`test-link-server` CDP 超时），与本次改动无关，留给 CI 复核。
**发布动作**（用户）：提交 → `git tag 0.8.3`（无 `v` 前缀）→ push `main` 与 tag；CI 的 ubuntu/windows 两 job 绿后 `release.yml` 产出 Obsidian 资产，`npm-publish.yml` 发 npm。

## 2026-10-18 · 修复 dsh 0.2.1 上每轮对话失败：`{{cwd}}` prompt variable 已不存在（**已实现**）

**触发**：用户在 Obsidian 侧栏发消息时报 `unknown prompt variable "{{cwd}}" in section "deployment:persona-prefix"; registered variables: provider, model`，每一轮都失败、完全无法对话。

**根因**：dsh 0.2.1-rc.2 的 prompt 插值只认注册过的变量，而注册表只剩 `provider` / `model`（`dsh-agent-loop/lib/index.js:1591-1592`）。本仓库的 preset / persona 前缀仍在写 `{{cwd}}`（`dsh/preset/agent.cordis.yml`、`dsh/profile/cordis.patch.yml` 的 GENERATED 块），于是每轮组装 system prompt 时直接抛错。`docs/dsh-0.2.1-assessment-2026-10-17.md` 的"破坏性变更 0 条"漏掉了 prompt variable 这一面，已在该文件顶部补实机更正。

**改动**：
- 从 preset 与 profile 的 persona 文本删掉 `{{cwd}}`（保留 `{{model}}`）；`node scripts/build-preset-declaration.mjs` 重新生成 `dsh/cordis.patch.yml` 的声明块；`main.js` 重建。部署后插件启动的 `ensurePresetDeclaration` 会把 profile 里的旧 GENERATED 块刷新成新文本。
- 文档：本条目 + `CHANGELOG.md [Unreleased]` 一条问题修复 + 0.2.1 评估页的日期化更正。

**验证**：`{{cwd}}` 在 `dsh/**` 与 `main.js` 中 0 命中；preset 声明生成检查、`check-bundle-freshness`、`check-doc-*` 均绿；待用户在真实 Obsidian 里发一条消息确认。

## 2026-10-18 · 删除侧栏性能模式 / 皮肤 hooks 改写 / opt-in 皮肤中心（**已实现**）

**触发**：用户质疑"侧栏性能与皮肤卡顿"这一整套是否必要，并怀疑主 dsh web（3080）与侧栏（3180）本就互不冲突、皮肤中心适配是自造问题。三路只读审计（`.docaudit/skin-audit.md`、`perf-audit.md`、`profile-consistency.md`）支持该判断：

- **冲突不存在**：skin-center 0.4.x 已不再写 `$DSH_HOME/cordis.patch.yml`（只写 `skin-center-active.json`），v1 的"全局插皮肤行"才是唯一真实冲突源；本机 home 层 0 行、`notes-assistant` profile 0 个 `@linxin666`，侧栏 3180 的 `/api/skin-center/**` 实测 404。
- **卡顿主因不在皮肤**：仓库自己的附着测量（归档于 `docs/archive/sidebar-performance-2026-09.md` §0.2）结论是"100% 在 dsh 侧"——宿主 Obsidian 0 掉帧、最差 18 ms，iframe 的 `RecalcStyle` 22.76 s / 410 次（55 ms/次）而 JS 仅 2.04 s ⇒ 主因是 dsh 前端文档规模/布局重算，属上游；皮肤 hooks 贡献的 A/B 从未做，而本机侧栏根本没装皮肤。
- **两 profile 不一致是有意隔离**：`--profile` 单值 ⇒ 两用途必然两进程；侧栏 fail-closed + 最小面是书面决策。推荐的方案是保持两个 profile，把侧栏定位为"聊天工作台"，不追主 web 的 UI（`docs/port-and-isolation.md` 2026-10-18 复核）。

### 改动

- **代码**（`obsidian/main.template.js` 4036→3650 行）：删掉 `sidebarPerformanceMode` / `sidebarSkinScripts` / `enableSkinCenter` 三个设置及设置页 UI、`perfMode`/`perfStylesheet`、`isSkinHooks`/`perfSkinScriptsOff`/`stubSkinHooks`/`isScriptResponse`/`patchSkinHooks`、opt-in 皮肤中心的安装/挂载谓词（`installSkinCenterPackages`/`SKIN_CENTER_INSERT`/`skinCenter*`）；`injectPerfStyle` 改为常开的 `injectSidebarScripts`，**只注入笔记链接拦截器**（不再依赖任何设置；这是功能，不是性能开关）。保留代理核心（cookie/authority/401/升级/面板 token）与 `forwardInjecting` 的 gzip 透传/chunked 修正/2 MB 上限。
- **boot 安全网保留**：`readGlobalSkinIds`/`buildSkinFallbackBlock`/`SKIN_FALLBACK_*` 及 `ensureObsidianPatch` 调用（老机器 home 层残留 v1 skin 行时按 id 禁用，防止 profile 起不来）；`check-skin-fallback.mjs` 收敛为两条不变量：基础 profile 零硬挂载 + 插件不得建链接（删掉随功能消失的谓词断言）。`dsh/profile/*.patch.yml` 的 opt-in 注释同步为现状。
- **测试/探针**：`test-panel-proxy.mjs` 32→**24** 断言（删 9 条 skin hooks/perf、改造 1 条"0.8.x 残留设置不能关掉注入"）；删 `sidebar-perf-probe.mjs`/`sidebar-attach-probe.mjs`，`sidebar-newchat-probe.mjs` 去掉 skin 参数；README 两语 proxy 计数 32→24 并重记配对 hash。`main.js` 重建（**872,105 B**，17 embedded sources）。
- **文档**：`docs/memory/sidebar-performance.md` 归档为 `docs/archive/sidebar-performance-2026-09.md`（内容保留，§0.2/§0.3 实测仍是"主因在 dsh 前端"的证据）；control-panel §2.6 压成"机制已删 + 结论指向 archive"；ARCHITECTURE / testing / settings-surfaces / memory README / traps 52 / handoff §5 / backlog / port-and-isolation 同步；port-and-isolation 修正"皮肤侧栏跟随"的旧说法并加 2026-10-18 行号漂移提示；CHANGELOG `[Unreleased]` 记两条用户可见删除。

### 验证

- `test-panel-proxy` **24/24**；`check-skin-fallback`、`check-bundle-freshness`、`check-readme-pair`、`check-doc-layout`、`check-doc-counts`、`check-version-consistency`、`check-doc-constants`、`check-env-vars` 均绿；模板里 21 个待删符号 0 命中、`node --check` 通过。
- 全量 `node scripts/run-gates.mjs`：**49/55 通过、1 SKIP、5 FAIL**；5 条 FAIL 与删除前完全相同，均为本会话沙箱环境结果（`test-panel-routes` 写 `D:/notes` 被 EPERM、`doc consistency` 连带、`installer e2e` 子进程管道 EPERM、`link server` CDP 超时、`agent preset mounts` 临时 home junction EPERM）。
- 未做：真机 Obsidian 人眼验收（侧栏菜单动画/笔记链接点击）、真实 token QA。

### 未做（已入 backlog）

3080 面板客户端半的层选择缺陷（`dsh web` 不读 overlay）、notes 扁平 preset 声明残留（需 `--dump-config` 核实）、web profile posture 混装（需用户拍板）、3180 端口占用回退。

## 2026-10-18 · 文档清理（第三批）：重写 backlog、给历史文档补身份头（**已实现**）

**触发**：用户指出拆出来的 `backlog.md` 混入了「当时的现场状态」和失去上下文的评估编号——例如「本次改动尚未装到你的 vault」是写作时的部署提醒，`C9` / `C10` 是 `pending-decisions-2026-09-26.md` 里的编号，单独出现在 backlog 里没人看得懂。根因是拆分时按「✅ / 非✅」整行搬运，没有做**可执行性**判断。

### 改动

- **重写 `docs/backlog.md`**：53 行混合台账 → **39 条**，按读者目的分四节：**等用户拍板 8 条**（每条用一句话解释编号含义，再给决策台账链接）、**工程待办 21 条**（每条写「做什么 / 怎么算做完」）、**观察 7 条**（写触发条件）、**用户动作 3 条**（agent 不自动做）。
- **删掉的不是待办，而是非待办**：已完成但带 ✅ 的行（3080 面板 JSON 报错、主 web 面板、设置搬 `Config` 勘察、3180 内嵌面板）、纯观察记录（注入体积读数、会话日志样本状态）、过期的部署提醒（「本次改动尚未装到你 vault」）、已被后续工作取代的清单（「文档清理第二批」——本轮已完成）。历史信息仍在 `handoff-section7-done-2026-10-18.md` 与 `changelog` 里，不丢。
- **补身份头**：给 **20 份日期命名的历史文档**（评估/计划/决策台账/已完成台账）+ 4 份旧适配/研究记录加 `> 类型：… · 状态：…` 头；`docs/memory/assessment.md` 标 historical。
- **门禁**：`check-doc-layout.mjs` 新增规则——文件名带完整日期的文档，前 10 行必须同时有 `类型：` 与 `状态：`，否则红。以后新增的评估不可能再"不带身份"地长出来。
- **新增两条 backlog**：`note-tools` 运行时文案仍说"可在面板恢复"（与模板修正同源，改文案要动代码）；老 vault 模板不随升级刷新。

### 验证（覆盖范围）

- `check-doc-layout` ok（80 份 md、318 条相对链接、55 份 docs 可达、**20 份日期文档有身份头**）；`check-doc-counts` ok（121/55）；`check-version-consistency` ok；`check-readme-pair` ok；`check-rename` ok；`check-doc-constants` / `check-env-vars` ok。
- 未跑全量 `run-gates`（本批只改文档与 doc-layout 门禁；该门禁单跑已绿）；未跑真实 token QA 与部署验收。

## 2026-10-18 · 文档清理（第二批）：拆 handoff、按季切 changelog、归档一次性评估（**已实现**）

**触发**：第一批（见下一条）收尾时登记的第二批；用户确认继续。目标是把「首读路径上的 262 KB handoff + 595 KB changelog」降下来，并让文档从「一个平面目录」变成有类型的仓库结构。

### 改动

- **handoff 拆分**：`docs/handoff.md` **871 → 139 行**。§4 的 **121 条陷阱**整体搬到 [`traps.md`](traps.md)（编号 1..121 不变，marker 行 `> 陷阱条数：121` 随文件走；`check-doc-counts` 的真值来源改读该文件）；§7 拆成 [`backlog.md`](backlog.md)（**53 条**开放/待决/观察项，唯一权威的未做清单）与 [`handoff-section7-done-2026-10-18.md`](handoff-section7-done-2026-10-18.md)（**56 条**已完成/已关闭行，原文只读存档）。handoff 的 §4/§7 只留指针；历史行只搬家、不改写。
- **changelog 按季切分**：`docs/changelog.md` **600,630 B / 5,029 行 → 约 130 KB（含本节）**；2026-08～09 的 152 条历史条目整体移到 [`changelog-2026-Q3.md`](changelog-2026-Q3.md)（只读，相对链接随文件位置重写）。后续按同一规则每季度切一次。
- **一次性评估归档**：`maintainability-review` / `maintainability-fixes`（2026-09-11）、`user-visible-changes`（2026-09-26）、`drag-drop-design`（2026-09-21）、`drag-to-mention-progress`（2026-09-25）移入 `docs/archive/`，各自补「类型 / 状态」头；全仓 **15 条**相对链接与 `docs/README.md` 的索引/归档表同步。`docs/` 顶层净减少 1 份（34 → 33）：移出 5 份一次性评估，新增 4 份有类型的入口/记录文件（`traps.md` / `backlog.md` / `handoff-section7-done-…` / `changelog-2026-Q3.md`）。
- **门禁与索引**：`check-doc-counts.mjs` 的陷阱真值改读 `docs/traps.md`（§4 标题与 marker 行保留，旧「陷阱 N」引用不受影响）；`check-rename.mjs` 给新的历史分段/存档文件补 `HISTORICAL` / `MOVED_ALLOW` 理由；`docs/README.md`、`AGENTS.md`、`ARCHITECTURE.md` 的入口与计数说明同步。
- 第一批条目末尾写的「未做（第二批）」已完成；该条保留原文作为当时记录。

### 验证（覆盖范围）

- 单条：`check-doc-layout` ok（80 份 md、309 条相对链接、55 份 docs 文档从总索引 ≤2 跳可达）；`check-doc-counts` ok（121 陷阱 / 55 门禁）；`check-version-consistency` ok；`check-readme-pair` ok；`check-rename` ok；`check-doc-constants` / `check-env-vars` / `check-release-paths` / `check-bundle-freshness` / `check-embedded-writers` / `check-embedded-loader` ok。
- 全量 `node scripts/run-gates.mjs`：**49/55 通过、1 SKIP、5 FAIL**，与第一批相同，5 条 FAIL 全部是本会话沙箱的环境结果（`D:/notes` 写入 EPERM、子进程管道 EPERM、无头 CDP 超时、临时 home junction EPERM）——不是文档改动。
- 未跑：真实 token `npm run qa:e2e`、Obsidian 本机部署验收（用户动作）。

### 未做（第三批候选）

按季度继续切 changelog；把 `docs/` 顶层剩下的 12 份 dated 评估逐个补「类型/状态/当前权威」头（本轮只给移入 archive 的 5 份补了）；`docs/memory/` 的旧评估（assessment 等）是否归档仍待决定。见 `docs/backlog.md`。

## 2026-10-18 · 文档清理（第一批）：修漂移、建索引、README 说人话（**已实现**）

**触发**：用户对文档冗余/漂移的审计（四路只读审计，报告在仓库外 `.docaudit/`）结论是「数字被门禁守住了，但入口与生命周期没管」：91 份文档 3.04 MB，历史/评估/提案/决策占 **62.4% 字节**，现状规格只占 4.9%；`AGENTS.md` 入口表指向 1.42 MB、其中 **87% 是历史**；5 条 tracked 断链、60% 的 docs 文档没有任何入口。用户要求开工清理，并把维护方式落成规范/工作流、面向人类的文档说人话。

### 改动

- **入口层**：新增 [`docs/README.md`](README.md)（总索引 + 30 秒现状 + 写文档规则 + 维护流程 + 类型/头部模板）；`AGENTS.md` §1 拆成「当前权威 / 查历史查决策」两张表，§3.3 的写死数字（3225/3803）改为「跑 `--sweep` 看实跑值」，§5 补文档身份与入口规则；README 中英重写为普通读者说明（删内部术语、历史取证与兼容性长段，细节移入 docs），结构继续由 `check-readme-pair` 保障。
- **漂移修正**：`docs/handoff.md` 顶部删掉「当前版本 0.8.0」、手写门禁/回归计数与 2026-09 的「最后更新」；6 处「当前 0.7.x」改为 0.x（当前 0.8.2）；`ARCHITECTURE.md` 的模板名与 docs/memory 清单；`docs/installation.md` 的 `.agent-presets` 自相矛盾、不存在的全局 patch 标记与示例输出；`docs/release.md` 的「五处」→九处与 versions.json 规则；`docs/env-vars.md` 的读取方与历史计数；`docs/literature.md` 的 `.raw` 目录数；`docs/dsh-0.1.7-adaptation.md` 与 `docs/archive/REFACTOR-PLAN.md` 的断链。
- **记忆文档语义**：`docs/memory/design.md` 的捕获默认值（`ask`，不是 `auto`）与 `verified_by` 写入者（feedback 写 `user` / 体检写 `corroboration`）；`self-correction.md` 的 `autoArchive` 默认值统一为「2026-09-18 起 on」；`docs/memory/README.md` 的「当前状态（2026-08）」改为截至 0.8.2，并补 0.8.1 三项机制（`origin` / AI 补全标记 / 固化闸门）；benchmark、retrieval-v3、v2-proposal、testing 的状态与数字对齐当前实现。
- **旧台账**：`pending-decisions-2026-09-26`、`bundle-channel-plan-2026-09-26`、`decoupling-assessment-2026-09-26`、`coupling-assessment-2026-10-15`、`settings-surfaces-2026-09-26`、`design-intake-2026-09-21` 各加 3–5 行日期化状态块（不改正文，历史保留）。
- **产品模板**（`dsh/templates/`）：`vault-AGENTS.md` 删掉「面板有恢复动作」的假承诺、补候选卡 promote 的事实边界、删仓库内部路径引用、版本行改 0.x；`strategy-readme.md` 同步；`inbox-readme.md` 把装进 vault 后不存在的相对链接改成行内路径。`dsh/profile/*.patch.yml` 的 junction 镜像旧注释改为现状。`main.js` 已按 `build-obsidian.mjs` 重建（**894146 字节**）。
- **防复发**：新增门禁 `scripts/check-doc-layout.mjs`（相对 md 链接可达、禁止链到 gitignored 证据、`docs/README.md` 必须覆盖所有 docs 文档且直达当前权威入口）；注册后门禁 **54 → 55**，`AGENTS.md` 的计数由 `check-doc-counts` 自动比对。
- **根 CHANGELOG**：`[Unreleased]` 补两条用户可见的更正（助手不再承诺「面板可恢复」「候选卡自动晋升」）。

### 验证（覆盖范围）

- 文档门禁单跑（当前工作树）：`check-doc-layout` ok（76 份 md、293 条相对链接、51 份 docs 文档 ≤2 跳可达）；`check-doc-counts` ok（121 陷阱 / 55 门禁）；`check-version-consistency` ok（0.8.2 九处）；`check-readme-pair` ok（10 节 / 14 条目 / 3 围栏）；`check-rename` ok；`check-doc-constants` ok；`check-env-vars` ok（20 名 / 106 文件）；`check-bundle-freshness` ok（`main.js` 与全新构建逐字节一致）；`check-embedded-writers` / `check-embedded-loader` / `check-config-scaffold` ok。
- 全量 `node scripts/run-gates.mjs`：**49/55 通过、1 SKIP、5 FAIL**。5 条 FAIL 均分类为**本会话沙箱的环境结果，不是本次文档改动**：`test: panel routes`（写本机 `D:/notes` 被 `EPERM`，既有环境红）、`check: doc consistency`（其连带）、`test: installer e2e`（子进程 `status=null`，沙箱禁管道 stdio）、`test: link server`（无头 Edge 的 CDP `Page.enable` 超时）、`test: agent preset mounts`（临时 home 的 `node_modules` junction 建不起来 `EPERM`，随后 `/memory-panel/state` 404；与陷阱 121 同环境族）。SKIP 是 `test: panel auth e2e`（缺 dsh 子进程状态权限）。
- 未跑：真实 token 的 `npm run qa:e2e`、Obsidian 本机部署验收（都是用户动作）。

### 未做（第二批，已登记 handoff §7）

`docs/handoff.md` §4/§7 物理拆分（traps / backlog）、`docs/changelog.md` 按季切分、一次性评估移入 `docs/archive/`、旧评估补状态头。这些会改变文档路径与门禁锚点，单独一批做。

## 2026-10-18 · 修：探针清理不再跟随 Windows junction 删掉真实 `node_modules`（**已实现**）

**触发**：验证"移除拖拽引用"时跑全量门禁，`test: agent preset mounts` 结束后真实 profile 的 `node_modules` 被清空（**6 → 0 项**），同一门禁随即报 `GET /memory-panel/state → 404`。查证为陷阱 121：本机 Node 24 对 `symlinkSync(..., 'junction')` 建出的目录联接，`lstatSync().isSymbolicLink()` 返回 **false**（`isDirectory: true`），而 `readdirSync(..., {withFileTypes:true})` 的 dirent 返回 **true**。

### 改动

`scripts/lib/isolated-dsh-home.mjs` 的 `removeIsolatedHome()`：walk 改用 **dirent 判定链接**（链接只摘链接本身），不再在 lstat 判定为"普通目录"后递归进入；注释写明本机实测差异与后果。

### 验证

- **修复前**：跑 `--only 'agent preset mounts'`，真实 `node_modules` **6 项 → 0 项**（门禁本身仍 **26/26**——它先读后删，这正是"门禁绿但环境被破坏"的形状）。
- **修复后**：同一门禁 **26/26**，前后 `node_modules` 均为 **6 项**，`dsh-math-memory` 仍可解析。
- 全量 **54** 条门禁：**51/54**（3 条仍是本机环境红：`panel routes` 的 `/config-flag` 写真实 vault 分支、其连带 `doc consistency`、`link server` ⑤ 真浏览器 CDP）；`agent preset mounts` 恢复 **26/26**。
- 被旧代码清空的依赖用 `pnpm install --offline`（profile 内）恢复两次（现场一次、对照实验后一次）；陷阱 121 与计数 121 已同步 `docs/handoff.md` / `AGENTS.md`。

## 2026-10-18 · 移除拖拽引用（drop-to-mention）整条链路（**已实现**）

**触发**：用户判断该功能冗余——"我完全可以打笔记名字就好了，笔记检索 tool 会自己找到笔记的"，要求从插件中去掉拖拽引用。

### 删除面

- **客户端半个**：删除 `dsh/client-panel/src/drop-mention/`（`parse.drop.mjs` / `composer-drop.mjs` / `mention-inbox.mjs`，共 3 个文件）；`src/index.jsx` 不再安装 drop 监听、不再导出 mention 诊断入口，也不再发布 `window.__dshMentionInsert` 或订阅 `/mention-stream`。`lib/client.js` 重建（**22618 → 15328 字节**）。
- **Obsidian 侧**：`obsidian/main.template.js` 删除拖拽落点（`installDropZone`）、`sendMention`、`insertMentionIntoFrame`、`mentionChannelMeta`，以及 LinkServer 的 `/mention`、`/mention-stream`、`/mention-report` 三条路由与推送队列；`styles.css` 删除 `.dsh-math-assistant-dropzone` 与承载它的定位样式。`main.js` 重建（**911882 → 892991 字节**）。
- **测试与探针**：删除 `scripts/test-drop-mention.mjs` 及其门禁 `test: drop-to-mention`（门禁总数 **55 → 54**）；删除 `scripts/lib/extract-bundle-function.mjs`（唯一调用方就是拖拽 e2e 探针）；删除 `scripts/qa/` 下 10 个专属探针（`drag-payload-probe`、`iframe-drop-probe`、`composer-drop-probe`、`composer-selector-probe`、`drop-to-mention-e2e`、`mention-insert-probe`、`mention-insert-live-probe`、`mention-stream-delivery-probe`、`mention-handler-probe`、`mention-pipe-probe`）。共删除 15 个文件。
- **文档**：两份专题文档保留为存档并在首部标注"功能已移除"（避免历史引用断链）；`AGENTS.md` 入口表、`ARCHITECTURE.md` 模块表、`handoff.md` §2/§7 与陷阱 89/90 同步；`docs/design-intake-2026-09-21.md` 与 `docs/dsh-0.2.1-assessment-2026-10-17.md` 的对应结论标注已关闭。

### 为什么删而不是修

这条链路的装配面与它带来的收益不成比例：拖拽事件在 Obsidian 文档里、落笔在跨源 iframe 的 dsh 页面里，需要"透明落点 + 直插 webview + loopback SSE"三套送达机制，落笔还依赖上游未承诺的合成 `ClipboardEvent('paste')`（装配教训见陷阱 89/90）。用户的真实用法是直接输入笔记名，`note_recall` 的统一检索已覆盖；拖拽的边际收益不足以继续承担这些跨边界契约的维护成本。

### 验证（覆盖范围）

- `node scripts/build-obsidian.mjs` 重建 `main.js`（17 个内嵌源）；`node dsh/client-panel/build-client.mjs` 重建 `lib/client.js`。
- 全量 `node scripts/run-gates.mjs`：**51/54 ok + 3 FAIL**，逐条对照**干净 HEAD 的同一门禁**后确认三条都是本机环境结果、不是本次改动的回归：
  - `test: panel routes` **68/69**（唯一红 `/config-flag` 无 env root 分支：本机低完整性进程写不了配置的 vault；stash 后同红）；
  - `check: doc consistency` 是上一条的连带（它读套件的失败计数）；
  - `test: link server port+token` 的 ①–④/④b 全绿，⑤ 真浏览器 CDP 在 `Page.enable` 超时（本机 headless Edge 不可用；stash 后同红）。
- 与本次改动直接相关的守卫均绿：`check: client bundle freshness`、`check: main.js bundle freshness`、`check: client package layout`、`check: doc counts (traps/gates)`、`check: version consistency`、`check: preset declaration is current`、`check: embedded loader/writers`。
- **本机部署**：`scripts/deploy-local.mjs` 要写真实 vault `D:\Obsidian笔记数据库`，而本会话的 shell 被宿主限制在 **Low 完整性**（`whoami /groups` = Low；另起子会话同样 Low，实测写 D: 为 `EPERM`），无法直接执行整条脚本。改为**等价写入本次改动实际影响的三处文件**：vault `main.js`、`styles.css`，以及 profile 的 `.dsh-client-panel/client.js`；并用**归一化后逐字节比较**证明与重建产物完全一致（`main.js` 809859 字符、`styles.css` 9080 字符全等；`client.js` SHA256 相等）。部署后 `main.js` **892991 字节**、`node --check` 通过，三个文件里 `__dshMentionInsert` / `mention-stream` / `mention-report` / `dropzone` / `installDropZone` 均**零残留**。deploy-local 的其余步骤（备份、模板、manifest）与本次改动无关；用户仍可在普通终端重跑该脚本（幂等，结果应完全相同）。

## 2026-10-18 · dsh 0.2.1-rc.2 适配：兼容声明字段修正；P1"跟随 cwd"结论已回退（**已实现**）

**触发**：用户要求按 [`dsh-0.2.1-assessment-2026-10-17.md`](dsh-0.2.1-assessment-2026-10-17.md) 落地。上游 0.2.0-rc.2 → 0.2.1-rc.2 的审计结论是**无破坏性变更**；真正要动的是 P2（兼容声明字段 + 文档）。

### 落地：P2 兼容声明

`package.json` 的范围从嵌套 `dsh.engines.dsh` 迁到**顶层 `engines.dsh`**（dsh 0.2.1 门禁读的字段，且声明后忽略 peers），并与 `peerDependencies` 同值保留（0.1.7–0.2.0 门禁读）。物化清单（`local-bundle.mjs`、`main.template.js`）同步写两处；`install.mjs` / `test-real-profile-accept.mjs` / `check-doc-consistency.mjs` 的取值顺序改为 engines.dsh 优先；`check-version-consistency.mjs` 与 `check-plugin-manifest-meta.mjs` 断言两字段同值。

### P1 结论修正：vault 锚点**不**跟随 `workingDirectory`（代码已回退，见陷阱 120）

第一版按审计建议加了 `effectiveSessionCwd()`（优先 0.2.1 的 session projection、回退 `header.cwd`），并在 `note-tools.mjs` / `math-memory.mjs` 使用。**部署前自查发现这是错的，已整体回退**：

- `session.header.cwd` 是"**会话创建时**的工作目录"，`workingDirectory` 只是"当前目录"；上游 README 明说"当前目录消失时…恢复到**原始项目**"——原始项目 = 工作区。
- 本插件的 vault 是**工作区级**的，历史会话归属（`isVaultSessionLog`）也按日志头 `header.cwd` 判定；若跟随投影，`cd` 进 vault 子目录会把**子目录**当 vault（`.deepseek/` 找不到 ⇒ 注入退化成"未配置"），比"停在原 vault"更糟。
- **Obsidian 模式不受影响**：侧栏启动总是注入 `DSH_OBSIDIAN_VAULT`（`obsidian/main.template.js:1689`），env 优先级高于 cwd ⇒ `cd` 不可能改变 vault。
- 教训写进陷阱 120：下"是否跟随新状态"的结论前，先确认它属于**工作区**还是**工作区内位置**。

### 文档

本文件 + 根 `CHANGELOG.md`（本无用户可见变化，`[Unreleased]` 保持空）；`handoff.md` 陷阱 119（顶层 `engines.dsh`）与 120（不要跟随 `cd`），并按 0.2.1 口径更新陷阱 112；`dsh-0.2.0-adaptation.md` §4.4 更正；`installation.md` 三处"必须重启"改为"通常重启即可（0.2.1 HMR）"；评估文档 §2/§3 标注实施与修正。

### 验证（覆盖范围）

- `node scripts/test-memory.mjs` → **478/478**（回退后与适配前一致；此前跟随方案的 8 条断言已删除）。
- **变异验证（M122）**：把 `package.json` 的 `engines.dsh` 改成 `>=0.2.0` ⇒ `check-version-consistency` 与 `check-plugin-manifest-meta` **同时红**；恢复后通过。
- `node scripts/build-obsidian.mjs` 重建 `main.js`；`check-bundle-freshness` **逐字节一致**。
- 断言计数锚点保持 **478**（跟随方案期间曾改到 486，已全部回退）；README 对已重录。
- 全量 `node scripts/run-gates.mjs`：**49/55 ok + 1 SKIP + 5 FAIL**，逐条归因后**无代码缺陷**——`panel routes`（唯一红 `/config-flag` 要写本机真实 vault，进程沙箱 EPERM）、`installer e2e`（捕获型 `spawnSync` 管道 EPERM，干净 HEAD 上同样复现）、`agent preset mounts`（临时 home 的 `node_modules` junction 被拒 ⇒ bundle 跳过 ⇒ 2 条 404）、`link server`（第 ⑤ 条要 Chromium page target）、`panel auth`（SKIP：禁止子进程写真实 home）；`doc consistency` 的那条红就是 `panel routes` 的连带。用 runtime 轮的沙箱 shim 复跑两条关键套件：`agent preset mounts` **26/26 ok**、`installer e2e` **ok**。


## 2026-10-16 · 0.8.2 摘要：把"写长"从风格问题变成可指认的违规（**已实现**）

**触发**：发版前用户指出摘要"还是太长"，要求像 dsh 官方 Release 那样简洁。§5 里其实早就有"不写内部过程"的规则——**这已是第四次返工**（0.7.8、0.8.1 两稿、本次）。

**问题不是缺规则，是缺形式**：前三次都靠"再写一条规则"，而规则本来就在上面。所以这次**把形式写死**：

1. **`[Unreleased]` 收成 `[0.8.2]` 并按新形式重写**。量化前后：那条"每次打开 Obsidian 弹红字"的 Fixed 条目 **~300 字 → 40 字**（根因、连带影响、两条分支全删）；"助手不会再上来就让你选" **~260 字 → 28 字**。**删掉的内容没有丢**——根因与证据本来就在本文（见 `047318a` / `488d9bd` 两节），这正是"摘要写结果、账本写原因"的分工。
2. **`docs/release.md` 新增 §5.1「形式」**：四类小节（`新增功能`/`问题修复`/`体验优化`/`其他变更`，**空的不写**）、**一条一句话**（实测 dsh 在 20–50 字）、**不写"此前→现在"**、不出现内部说法、**维护者收益不进摘要**（"功能解耦，以便后续开发"是明写的反例）。§5 自检第 3 步从旧的 `Added`/`Changed`/`Fixed` 改指新形式。
3. **`AGENTS.md` 加指针**：§1 文档路由表与 §5 记录纪律表两处都指向 §5。理由写在 §5.1 末尾——规则放在子文档里 ≠ 下次会读到它，而 `AGENTS.md` 是 harness 自动注入的那份。
4. **修一处指向性漂移**：`CHANGELOG.md` 开头把 `docs/user-visible-changes-2026-09-26.md` 说成"只想看这次我能看到什么变化"，但那份是 2026-09-26 那批的**当时**走查、不随版本更新。改为明确标注"不随版本更新"，并把"这次能看到什么"指向最新一版本身。

**版本 0.8.1 → 0.8.2**（**九处**，以 `check-version-consistency.mjs` 的逐条输出为准）：`package.json` / `package-lock.json` / `manifest.json` / `versions.json` / `CHANGELOG.md` + `README.md` 与 `README.zh.md` 的版本行 + `docs/handoff.md` 与 `docs/memory/design.md` 的 `> 当前版本：` 横幅。⚠️ 顺带更正：`AGENTS.md` §3.4 原本写"版本号**五处**必须一致"，而门禁实际强制**九处**——该行已改成"几处由门禁说了算，不要手写清单"。**讽刺的是这句话的第一版我把九写成了八**（`AGENTS.md` 与本节各一处），写门禁验证时才抓到；已按门禁输出更正，并把"以门禁输出为准"写进该行。这正是本仓库"手写计数必腐烂"那条纪律的又一次实证——**连"不要写数"这句话本身都不该带数**。

**用户可见内容的完整性**：除用户列的三项（修弹窗 / 助手先解释再弹选项 / 面板读写走服务）外，本轮补上一条**用户可见、但此前不在 `[Unreleased]` 里**的改动——记忆面板显示"本次体检把哪些卡移入了归档目录"（`47b2f20`）。它归入「体验优化」而非单列「新增功能」，因为触发条件很窄（零使用 + >90 天 + 非用户确认），多数用户可能永远看不到。用户拍板的另两项：小节名改用 dsh 四类中文；「解耦」只写用户可见后果。

**体检会改动什么**（用户追问后查实的口径，供下次写摘要复用）：① **归档移动**（唯一让卡从库里消失的写，预设 `autoArchive` 默认开；判据 = `active` 且非 `user-confirmed` 且 `uses === 0` 且 >90 天且非保留侧）；② 命中统计回写 `hook.uses`/`hook.last_used`；③ 给老卡补 `origin`；④ 台账/历史。面板那行**只点名①**。

**未做**：`git tag` 与 `git push` 是用户的动作，本轮不碰。

## 2026-10-16 · 取证更正批次：Obelisk 的「Litestream / MCP」说法是错的 ＋ 登记惯例立规（**已实现**，纯文档）

**触发**：为「要不要给插件引入 SQLite 存对话、能不能直接复用别人做好的」做取证时，发现本仓库对 Obelisk 的两条**"能确认"级**陈述都是错的；而 `docs/memory/obelisk-comparison.md` 已在 GitHub 上，社区插件索引把它标成了 **「the source of the Litestream claim」**——**别人在引用我们这条未经核实的说法**。同一轮还查出两处"指错章节"的引用与一处 arXiv id 写错。

### 一、Obelisk：三条更正（按一手来源重核）

**怎么查的**：本机实装 `@obelisk-apps/cli@0.2.6`（读 `dist/**`：`node:sqlite` 的 `DatabaseSync` ＋ `better-sqlite3` 回退、`schema.sql`、四个动词、**零 URL 零 `fetch`**）＋ 上游 `README` / `CONTEXT.md` / `schema.md` / ADR 索引 ＋ 本机已装的 docs-only skill `~/.agents/skills/obelisk`。

1. **存储 ≠ SQLite + Litestream**。实际是**单个本地 SQLite 文件** ＋ WAL ＋ 跨进程 writer lease（`BEGIN IMMEDIATE` on `writer.lock.sqlite`）；检索是 **FTS5**。上游文档全无 Litestream·S3·复制·备份字样，旧说法的唯一出处是一篇第三方文章（`it-boltwise.de`）。**影响不只是措辞**：对照表里「**跨机备份**」这一栏是凭空的，而它当时是"部分追（只动缓存层）"这个结论的论据之一。
2. **不是 MCP server**。它是 daemon-free CLI ＋ docs-only skill；上游 `CONTEXT.md` 原话：「CLI and a **future** MCP server are transports over this same shape」。**影响**：`plugin-family-assessment` 的形态决策树第 1 步（"外部已有 MCP server ⇒ 一行 config 零代码"）**对 Obelisk 不成立**；官方 dsh 集成（ADR-0012）是**插件自带 skill ＋ 让模型用 Bash 工具跑 `obelisk --query`** ⇒ 它在**不挂 shell 的 fail-closed preset 里够不着**（`dsh/preset/agent.cordis.yml:12-13`）。
3. **无 embedding**（"推断、未核实"里的一半可以关掉）。schema 无向量表/列、无 `sqlite-vec`；glossary 把 "vector memory" 列为避免用词。

**同轮补记两条对判断有用的事实**（进 `references.md` §11 第 5 条与许可行）：它**分层与我们同构**（会话证据＝可重建的派生索引；记忆层明写"`path` 的 markdown 才是持久记忆，`summary` 只是紧凑检索面"），且检索文本与工具 JSON **截断 10k 字符** ⇒ **它本身不是事实源**；许可是 **AGPL-3.0-only** ⇒ 可当外部程序用，**不可 vendor**（本仓库 dsh 侧是 MIT，AGPL §13 有网络提供源码义务）。

### 二、两处"指错章节"的引用（会制造重复讨论）

`literature/reading/verymathOrg2026.md` 与 `literature/reading/wangMemForestEfficientAgent2026.md` 都写「把『已评估、不采纳』**记进 `docs/handoff.md` §7**」。但 §7 是**「未做 / 下一步候选」**（表头 `项 | 说明 | 优先级`，装着"待决（最高）"这类**开放**项）——**把已关闭的决定写进去，下一个人会当成未处理项重捡**，正是这两句话想防的事。已改指 **§5「用户决策记录（不要推翻）」**（lemmalog 先例就在 §5）。

### 三、arXiv id 写错一处

Louck 那篇在 `docs/memory/design.md:180` 与本文 2026-10-01 那条 `origin` 条目里写作 **2606.34591**，而卡片 frontmatter 的 `doi`/`url`、`literature/reading/louckSecuringLLMAgentLongTerm2026.md:7`、`library.bib:557-565` 三处都是 **2606.24322**。四处对两处 ⇒ 统一为 **2606.24322**。历史条目只改数字、不加注（更正记录就在本节）。

### 四、立一条登记惯例（补上文档自己承认的缺口）

**缺口**：本仓库对"从外部系统/仓库引入的机制"**没有登记惯例**——由文档自己写下（`literature/cards/yangOptSkillsLearningGeneralizable2026.md:38`、`literature/notes/improvement-details-2026-09-17.md:452`），且第 10 项长期挂着"未做"。后果是决策散落在**五个地方**（`handoff.md` §5 / `design-intake-*-§3` / `references.md` 的"不适用"段 / `plugin-family-assessment` §3.1 台账 / `pending-decisions-*`），**谁都不是权威**。

**新规矩**（写进 `handoff.md` §5）：引入外部系统/机制 = ① 一份专项评估文 `docs/<tool>-assessment-<date>.md`（先例 `lemmalog-assessment-2026-10-01.md`）＋ ② `handoff.md` **§5** 一行决策记录；**不要记进 §7**。`improvement-details-2026-09-17.md` 第 10 项据此收口，并记录一处**刻意偏离**：未照抄 `SOURCES.md` 的"快照 commit"字段——本仓库登记的是**机制/结论的采纳与否**（可复核的是评估文里的出处与证据强度），不是二进制来源。

### 五、顺带修掉一处过期状态

`obelisk-comparison.md` 头部写「已定案，**实现中**」，而该文 §7 早已列 0.7.3 三项全 ✅。改为「已定案，**已实现**（0.7.3）」。发现同类"状态页眉过期"是这份仓库重复踩过的坑（2026-09-26 的核实 sweep 就改掉过 3 份）。

### 六、`ctx.sessionQuery` 可达性探针（只读，**未实测**）

**问题**：能否用 dsh 自带的 `ctx.sessionQuery` 替掉 preset/host **两份手写的会话日志扫描 + zstd 解码**（`math-memory.mjs:452` `decodeZstdSessionLog` ↔ `memory-admin.mjs` 的 `decodeSessionLog`——**`check-engine-sync.mjs` 里最后一对 `KNOWN_ESCAPES`**）与每轮指纹扫描（`cacheTtlMs: 0` ⇒ `math-memory.mjs:5020`）。

**结论：两个半都可达**（读声明 ＋ 读上游 cordis 源码机制 ＋ 现成先例；**未实测**）。

**⚠️ 本节第一版的机制写错了，此处更正**——初版拿 `dsh-scope` 的"作用域向下继承"（`README.md:12/:73`）当理由。**跨平面可见与 fiber 祖先关系无关**：Cordis 的服务解析按 **isolate 标签查根级进程全局 store**——`cordis/src/reflect.ts:237-239` `const key = this.ctx[symbols.isolate][name]; const impl = key && this.store[key]`，`:286-292` 用 `ctx.root[symbols.isolate][name] ??= Symbol(name)` 且重复注册即 throw。而 `dsh-scope` 管的是 **scope-aware 注册表与事件**，它自己 `README.md:101` 就写着「**an arbitrary Cordis service remains context-global** merely because it is called through a scoped context」⇒ 初版是**张冠李戴**。真正的证据是三条：

1. **官方声明**：`dsh-agent-preset-registry/README.md:58`「**A row waiting for a Host service stays mounted** … so startup order does not decide the outcome」；`:95`「**Presets are not security sandboxes**」。
2. **现成先例，且不必外求**：本仓库 preset 半**今天就在消费 host 平面服务**——`dsh/preset/math-memory.mjs:68` `export const inject = ["tools","fs","systemPrompt","loader"]`（`loader` 由 `cordis-plugin-loader` 提供，`tools`/`systemPrompt` 由 `dsh-base` 行提供）；另有 `dsh-persona` **只**挂 preset，而 `lib/index.js:21` `inject = ["systemPrompt"]` 的 provider 在 host 平面。
3. `sessionQuery` 是 Cordis 服务：`dsh-session-query/lib/index.js` 的 `super(ctx,"sessionQuery")` ＋ `lib/types/index.d.ts:23-27` 的模块增强。

**⚠️ 一个会把改动做成"静默半死"的形状（本轮新查出）**：`inject` 是**硬门**，而挂载只对 `failed` 抛错、**容忍 `pending`**（`dsh-agent-preset-registry/lib/types/mount.js:236-241`）⇒ 若服务其实够不着，把 `sessionQuery` 加进 `math-memory.mjs:68` 只会留下 `waiting for sessionQuery` 一行，**记忆系统整体不动**。所以首探必须用 `ctx.get()`（`cordis/src/reflect.ts:9-19`：不需要 inject 声明，因此探针不会门住插件）。另两条硬约束：preset 半**不能用静态 bare import**（`--direct` 通道只铺 `PRESET_BODY_FILES`，`note-tools.mjs:46-76` 有现成规避写法）；**`--dump-config` 不是只读**（会重写 profile 的 `cordis.yml`，`dsh/preset/profile-contract.mjs:59-60` 已实测），不要拿它取证。细节与证伪条件见 `handoff.md` §7。

**⚠️ 同轮查到一个更有用的红利**：`dsh-base` 与 `dsh-web-app` 都以 **`openAt: never`** 挂 `session-query-sqlite`（`dsh-base/cordis.patch.yml:143-153`、`dsh-web-app/cordis.patch.yml:27-30`，两个 profile 都未覆盖），而 `never` **只关掉 `searchSessions`/`searchEvents`**——**精确读 / 过滤 / trace 照常可用**。⇒ **替换手写扫描不必打开 SQLite 索引**（`listSessions` / `filterSessions({cwd})` / `filterEvents(id,{text})` 足够）；开 `openAt` 只为拿 FTS5 排名。这把"要不要数据库"与"能不能别再手写解码器"**拆成了两个独立决定**——后者不依赖 P4。

**未做**：本轮只改文档取证与登记惯例，**未改任何代码、未运行探针**；探针的结论、机制与证伪条件见 `handoff.md` §7。（注：机制段初版写在 `af2df21` 里、引错了 `dsh-scope`，由紧随其后的那次只读取证更正——同一次调查，第二次读的是上游 `cordis` 源码与官方 README，而不是推断。）

## 2026-10-15 · P5b 的最后一里：面板现在真的显示"本趟改了什么"（**已实现**）

**(b) 落地后我发现它其实还没到用户眼前。** `report.found` 被算出来了、也随报告落进 `cache/memory-audit.json`，但**全仓只有测试在读它**：数据通路是通的（`normalizeAuditForPanel` 用 `{ ...audit, … }` 透传，`collectMemoryState` 返回完整 `audit`），**缺的是渲染**——用户体验到的仍是 `auditHuman`，而它描述的是**写回之后**的库：一张刚被归档的卡在里面就是"不存在"，读者无从知道数字是**因为本趟**动了。

### 改了什么

- `MemoryView.foundChangeSummary(audit)`：从 `audit.found` 生成一行"本次体检改动了 N 张卡：…（已移入 .deepseek/archive/，移动而非删除）"；
- 在体检区、`auditHuman` 之下渲染（`cls: 'dsh-memory-audit-changes'`）。

**两处刻意的限制**：
- **只点名归档**。它是读者**必须**知道的那一项改动（它把卡移出库，可逆但是真移动）；`found.changed` 的其余字段都是它的后果，把字段名列出来是日志、不是信息；
- **没有 `found` 就什么都不渲染**（2026-10-15 之前的 schema v2 报告没有这个字段），而不是显示"什么都没改"——后者会在旧报告上撒谎。

### 验证

- `test-panel-routes` **68 → 69**：`artifact: the panel renders what the audit CHANGED (reads audit.found, not just the post-state)`；
- `foundChangeSummary` 的**边界逐个验过**（直接从模板抽出方法做独立求值）：无 `found` ⇒ `''`；`found` 但零改动 ⇒ `''`；1 张 ⇒ 点名；5 张 ⇒ 点名前 3 + "等 5 张"；`audit` 为 `null` ⇒ `''`；
- **变异验证**：把那次**调用**删掉 ⇒ 该条红（见下）。
- 文档计数 68 → 69 route（README 中英 + ARCHITECTURE + handoff）+ README 对重录。

### 又一处"变异没长成守卫要抓的形状"（第四次，已记进清单注释）

这条变异我**第一版写错了**：我把 `const foundSummary = "";`（清空局部变量），而守卫的四个探针（方法定义、方法里的 `audit.found`/`found.archivedByThisPass`、`cls` 字符串）**全都还在** ⇒ 断言照绿、扫描器报 `NOT-DETECTED`。**这个缺陷的形状是"`renderBody` 再也不调用那个摘要"**，所以变异改成**删掉调用**，随即红。

**扫描清单 28 → 29 条，29/29 检出。**

**验证汇总**：`test-panel-routes` 69/69；`test-memory` 478/478；全量门禁 **55/55**；`check-bundle-freshness` OK（`main.js` 911 549 B）；`check-mutation-anchors` ok（29 锚点）。

## 2026-10-15 · P5 按 (b) 落地：体检报告现在能说"我发现时是什么样、我做了什么"（**已实现**）

**用户拍板选 (b)**，并明确"这个改动对用户影响不大，如果能实现解耦那是最好的"。于是 (b) 不是"跑两遍分析"，而是**给体检加一个真正纯观察的模式**，再由它派生"发现时 vs 写回后"的对照。

### 实现的形态

| 机制 | 作用 |
|---|---|
| `helpers.reportOnly` | 跑完整趟分析、**一个字节都不写** |
| `helpers.compareWithFound` | 先跑一趟 `reportOnly`（"发现时"），再跑真的那一趟，把**差异**挂到报告上 |
| `report.found` | `{ archivedByThisPass, changed }`——本趟归档了谁、哪些字段因此变了 |

**为什么两趟可比**：`reportOnly` **不改变"算什么"**——合并、检测、排序、所有计数都照跑，只是跳过写。所以逐字段 diff 是有意义的，而那个 diff **就是"本趟改了什么"**。

### 必须抑制的写入（一处是我第一版漏掉的）

`reportOnly` 要抑制的不只是卡片写：

- 卡片写（四条，走 `effectiveWriter` 的 deferred 分支）；
- **归档移动**；
- **检索统计的整文件重置**——它是"消费待处理命中"，只读那趟若重置，后面真跑就丢了这批命中；
- **hook 历史快照**——派生状态，且会同一天写两次；
- **审计台账**（只追加、按天计）与 **notation 块**；
- **`cache/card-origin.jsonl`（C7 首见台账）** ← **这一处是第一版漏掉的**，由新测试抓到。

漏掉最后一处的后果很具体：它按 `firstSeen` 记录"宿主首次见到这张卡"，只读那趟写一笔，**后面真跑就会读到由一趟"什么都没改"的运行盖下的时间戳**。

### 两处 artifact，必须从 diff 里排除（都实测确认过）

拿两份隔离库做对照实验后发现，有两类字段在两次运行之间不同，但**不是"本趟改了什么"**：

- **`generatedAt`** —— 第二趟的时间戳；
- **`status` / `warnings`** —— 只读那趟合法地报 `degraded`（"没有写可确认"），所以它那些"未确认项"警告不是发现；
- **`structural.usesMismatch`** —— 它比的是**盘上声明的 `uses` vs 内存合并值**，所以任何只读趟都会把**每一笔待写**报成不一致：**它是观察行为的产物，不是库的事实**。

实测：把这三类算进 diff，会凭空多出 5 个字段。**排除后，diff 恰好是归档的效应**（11 个字段：`counts.cards` 2→1、`decisions.total` 2→1、`sections.unused`/`unverified` 1→0 等），而在**一个不需要改动的库上 diff 为空**——这正是让这个对照可信的性质。

### 验证（`test-memory` 471 → **478**，+7）

- `reportOnly` 是**纯的**：`reportOnly: a pure observation writes NOTHING (not even the origin ledger)`——逐文件字节比对，**零文件变化**；
- 它**仍然算完整报告**（`cards: 2`、目标 1 张、`archived: 0`），且**待处理命中没被消费**（`calls` 仍为 3）；
- `compareWithFound` **点名本趟归档了谁**，diff **恰是归档效应（11 字段）**；
- **run artifact 不进 diff**（`generatedAt`/`status`/`warnings` 都不在 changed 里）；
- **不需要改动的库 ⇒ 空 diff**。

**变异验证三条**（各自退回旧写法）：① 不抑制 origin 台账 ⇒ 报 `changed: .deepseek/cache/card-origin.jsonl`；② 不抑制统计重置 ⇒ 报两个文件变化 + 命中被消费；③ 把 `usesMismatch` 塞回 diff ⇒ 报"diff 不是归档效应"。三条都**点名了预期断言**，并已登记进 `mutation-entries`（**25 → 28 条**）。

### 代价与边界

- **代价**：每日体检的文件读取翻倍。报告本身缓存 `auditIntervalMs`（默认 24h），所以是**每次体检一次**，不是每次提示一次。用户判断"对用户影响不大"与本实现一致。
- **边界**：`buildAuditReport` **仍然是一个大函数**。本刀建立的是**语义边界**（"发现时 vs 写回后"两个视图），不是物理拆分；`compareWithFound` 是**按调用点 opt-in** 的（`auditReportFor` 打开，单元测试默认关闭，避免套件跑两遍）。真要做物理拆分，现在有了这个对照作为**行为等价的验收工具**——这正是 (b) 的长期价值。

**验证汇总**：`test-memory` 471 → **478**；`main.js` 重建（909 207 B）；全量门禁 **55/55**；`check-mutation-anchors` ok（28 锚点）；文档计数 471 → 478（7 处）+ README 对重录。

## 2026-10-15 · P5 按 (a) 落地：归档移动挪到分析之后；顺带发现接缝有两处"绕过"（**已实现**）

**用户拍板选了 (a)**（"归档挪到分析之后，按'这个 id 被移走了'重算那些 section"）。做完之后有一件事必须先说：**我此前对 (a) 的描述是错的**。

### 我的结论错了一半

上一节我写：把归档挪到分析之后、重算那些 section 会"**改变体检报告**"，所以 (a) 是一个需要产品决策的取舍。**实测：行为完全没变，469 条断言一条没过。**

原因很简单，也值得记住：**"22/122 个字段不同"描述的是"归档改变了什么"，不是"把那次调用挪个位置改变了什么"。** `archivedRels`/`live` 仍在原来那个位置构造，过滤的是**同一个集合**——移动的只是 `moveCardsToArchive` 的**调用时机**。把这两件事混为一谈，才让 (a) 看起来像行为变更。

⇒ **真正需要决策的只剩 (b)**（跑两遍分析再 diff：每天两次、且"两次体检"会变成可观察行为）。(a) 不需要任何人拍板。

### 那 (a) 的价值是什么

不是"少 22 个字段差异"，而是：**"体检先分析、再写回"这句话现在能说出口了。**

此前那次移动是分析后半段的**输入**，所以读者无法判断哪些结论描述"发现时的库"、哪些描述"写回后的库"。现在边界明确，且**为什么可以延后是核实过的**（不是假设）：

- 旧位置到新位置之间**没有任何代码消费** `archived`/`archiveFailures`；
- 这段区间里唯一读盘的 pass 是 promote 循环，它要求 `status === "candidate"`，而归档目标要求 `status === "active"` ⇒ **不可能同一张卡**，所以移动删不掉那个循环正要读的文件；
- `moveCardsToArchive` 的索引副作用是**重标链接**（`[[stem|` → `[[archive/stem|`），不是删行，而索引解析发生在更早处。

### 顺带抓到的真缺陷：接缝有两处"绕过"

`makeCardWriter` 的承诺是"注入 deferred 写者 ⇒ 不碰 vault"。实测**有两处违反它**：

| 绕过点 | 旧写法 | 后果 |
|---|---|---|
| promote 晋升 | 裸 `writeFileSync(card.filePath, …)` | 注入 deferred 写者后**仍改写用户卡片** |
| 归档移动 | 直调 `moveCardsToArchive(root, …)` | 注入 deferred 写者后**仍把卡片移出库** |

后果不只是"接缝不完整"：它意味着**任何"只报告"的探针都会真改用户的库**——正是这条接缝存在的理由。接缝自己的注释也承认了归档移动没被覆盖（"widening this seam … would be the next step"），promote 那处则连注释都没提。

**修法**：给接缝加 `setStatusActive(filePath)` 与 `moveToArchive(root, targets)`，两处调用改走接缝。promote 那条**同时在内存里更新 `card.status`**——deferred 模式下报告仍须描述"这趟的判定"，否则"只报告"会变成"丢失结论"。

**验证（471 条，+2）**：

- `card-write seam: promote (setStatusActive) goes through the writer, not a bare writeFileSync`
- `card-write seam: the archive MOVE goes through the writer (a report-only pass renames nothing)`

两条都做了**变异验证**（把代码退回旧写法）：分别报 `unchanged:false` 与 `staleStillThere:false`——**正是缺陷本身**，且都点名了对应该条断言。两条已登记进 `scripts/lib/mutation-entries.mjs`，**扫描清单 23 → 25 条，25/25 检出**。

**边界**：本刀**没有**拆函数、**没有**改报告语义；`buildAuditReport` 仍是那个大函数，只是边界可指认了。真正的"物理拆分"仍需要 (b) 那类决策或另一次设计。

**验证汇总**：`test-memory` **469 → 471**；`main.js` 重建（900 892 B）；全量门禁 **55/55**；`check-mutation-anchors` ok（25 锚点）；文档计数 469 → 471（7 处）+ README 对重录。

## 2026-10-15 · loader 判据**定论**：路线 (2) 已排除，而且"需要真机"这个结论也是错的（**已实现**）

**上一节我留了一个尾巴**："宿主运行时是否支持 `require(esm)` —— 本机无法判定，**需要真机证据**"。这一节把它查清了：**它不是真机题，是有权威来源的事实题**，而且答案让结论变硬。

**查到的事实（两条出处）**

- `require(esm)` **默认开启始于 Node 20.19.0**（2025-03-13；此前 v20 需要 `--experimental-require-module`，v22/v23 默认）—— [Node.js 20.19.0 发布说明](https://nodejs.org/en/blog/release/v20.19.0)
- **Electron 25.0.0 捆的是 Node.js 18.15.0** —— [Electron 25.0.0 发布说明](https://www.electronjs.org/blog/electron-25-0)
- 本插件 `minAppVersion` = **1.4.0**（2023-07 推出的版本，对应用户可能仍在跑旧 Electron）

⇒ **在其支持的运行时上 `require(esm)` 根本不存在**，"路线 (2)：真模块解析"**被排除**。所以 loader 保留是**定论**，不是权衡。

**同一处我栽了两次，都写进陷阱 118**

| 次数 | 我写的 | 实测/查证结果 |
|---|---|---|
| 一 | "CJS 里 `require()` 一个 `.mjs` 会抛 `ERR_REQUIRE_ESM`" | 本机 Node 24.14.1 下 `require('./mod.mjs')` **成功**，被推翻 |
| 二 | "宿主是否支持 `require(esm)`，**本机无法判定，需要真机证据**" | **也是错的**：查两条官方发布说明即可定论 |

**新增的第二条纪律（比第一条更有价值）**：**"本机实测"证明的是开发机，不是交付目标**；决定能不能用的是**宿主/目标运行时**的版本，而它通常可以从**权威发布说明**查到。把"需要真机证据"当结论下得太早，会**挡住一个其实能查清的问题**——这次就是如此。所以"这需要真机"这个判断本身也要先查一遍，它不是免于取证的通行证。

**顺带留下的真失败模式**（探针给出，仍有价值）：把兄弟依赖 `./dep.mjs` 删掉 ⇒ **`ERR_MODULE_NOT_FOUND`**，即"能不能 require 取决于相对 import 闭包是否都躺在可解析的磁盘路径上"——这正是 loader 把 `engine-shared.mjs` 拼进同一求值体的理由。

**验证**：`doc-counts` ok（118 陷阱、55 门禁）；`doc-consistency` 13 锚点一致；全量门禁 **55/55**。本刀**不动代码、不动生成物**（纯文档 + 陷阱 118 重写）。

## 2026-10-15 · loader 的最终判据：删不掉，但**理由要换**（含一处被实测推翻的说法）

**这一刀回答的是 J1=B 最后那个开放问题**："嵌入 loader 到底能不能退役？"——结论是**在现有交付形态下不能**，但**我原先给的理由有一半是错的**，所以两件事都要记。

**查清了什么（可复核的实测）**

- 插件是 **CommonJS**：`obsidian/main.template.js` 用 `require('obsidian')`/`require('fs')`…，全文件**零静态 import、零动态 `import()`**（实测：require 说明符 9 个，import 语句 0）。
- 宿主模块 `dsh/host/memory-admin.mjs` 是 **ESM**。⇒ 交进这个进程只有两条路：**(1) 运行时求值**（现在的 `new Function(body)(注入 fs/path/zlib)`，即 loader）；**(2) 真模块解析**（`require`/`import` 磁盘上那个文件）。

**我说错的那半句（实测推翻）**：我写的是"CJS 里 `require()` 一个 `.mjs` 会抛 `ERR_REQUIRE_ESM`"。**本机 Node 24.14.1 实测 `require('./mod.mjs')` 成功**（`require(esm)` 早已可用）。所以"ESM 不能被 require"**不是**理由。

**实测给出的真失败模式**：把那 6 行探针里的兄弟依赖 `./dep.mjs` 删掉 ⇒ **`ERR_MODULE_NOT_FOUND`**。也就是说真正的约束是"**相对 import 闭包是否都躺在可解析的磁盘路径上**"——而 loader 存在的理由之一，正是它把 `engine-shared.mjs` **拼接进同一个求值体**，让那次 import 根本不必解析。

**于是它从"一句结论"变成两个可判定的问题**：**(a)** 宿主模块及其相对闭包是否保证在磁盘上以可解析路径存在（`dsh/` 树会被铺进 profile，但插件侧不保证那个铺法）；**(b)** 宿主运行时是否支持 `require(esm)`——本插件 `minAppVersion` 是 **1.4.0**，用户可能跑在**不支持**的 Electron/Node 上，而这一点**本机无法判定，需要真机证据**。⇒ 在拿到真机证据前，删 loader 不安全。

**顺带一个更根本的发现**：把 loader 的导出从 10 减到 8、6、4 **都不会让它消失**——它替的是"这个进程没有模块系统"这件事。所以 §4 里"退役 loader"这个目标名应当改成"**把注入面压到最小 + 名字诚实**"（它是"嵌入源码的运行时求值"，不是"模块加载器"）。

**记录纪律**：这也是"理由会随运行时版本腐烂"这一族。已写成陷阱 **118**（陷阱条数 117 → **118**）：凡是要写"运行时为什么做不到 X"，**先在当前运行时上跑一次那个操作**；版本相关的断言要**写明它依赖哪个版本**，判不了的就写"需要真机证据"，不能写成结论。

**验证**：全量门禁 **55/55**；`doc-counts` ok（118 陷阱、55 门禁）；`doc-consistency` 13 锚点一致。本刀**不动代码、不动生成物**（纯文档 + 一条陷阱）。

## 2026-10-15 · 变异清单 21 → 23 条：一条"看着像盲区、其实覆盖充足"的记录（**已实现**）

**这次加的两条，都是仓库里强度最高的守卫**

| 变异 | 守卫 | 为什么它强 |
|---|---|---|
| 客户端包的拷贝**漏掉一个模块** | `check-client-package-layout` | 它**真的 `import()` 一次产物**，所以"闭包少一个文件"表现为 import 失败，而不是"清单对不上" |
| 契约的行 id 清单**少一行** | `check-profile-contract` PINNED-3 | 契约与三个 patch 层的行 id 双向核对 |

清单 **21 → 23 条，23/23 检出**。

**一条重要的"否"：看着是盲区，其实是覆盖充足**

我先试的变异是"**overlay 源文件里把 `math-memory-client-panel` 行改名**"。结果：

| 门禁 | 结果 |
|---|---|
| `check-overlay-bundle-rows` | **绿（22/22）** ← 我原本以为的守卫 |
| `check-patch-yaml` | **红**（"客户端半个的 loader 行在所有 patch 层里恰好出现一次"） |
| `check-profile-contract` | **红**（PINNED-3 missing + PINNED-3b undeclared） |

⇒ **覆盖是充足的**，只是不在我以为的那条门禁里。两条独立门禁各自报出**准确**的原因（一条说"拖拽引用将没有接收方"，一条说契约与层不一致）。**这条因此不进清单**——把它登记成"变异"只会让清单去测别的门禁，反而掩盖真相。

（`check-overlay-bundle-rows` 的 22 条断言确实不管**源文件**的行集合，它管的是**运行时 strip 行为**：带 bundle 注册时哪些行被移除、客户端行必须存活、标记缺失时整个文本不变。那是它的职责边界，不是缺口。写在这里是为了让下一个读它的人不要把它当成"行 id 的守卫"。）

**一条方法论上的修正**：这条"否"第一次是被我在**只跑一家门禁**的探针里判成"未检出"的。**判"盲区"之前要把相关门禁都跑一遍**——单家门禁的绿不等于无人看守。这与前几轮"判据错"是同一类错误的另一面，一并记下。

**验证**：`mutation-sweep` **23/23**；`check-mutation-anchors` ok（23 锚点各一次，3 条已治愈盲区仍被点名）；全量门禁 **55/55**；`main.js` 无变化；文档计数未动（本刀无新断言、无新门禁）。

## 2026-10-15 · 变异清单再扩 5 条：抓到 B3 那个形状的第三个入口（**已实现**）

**为什么再扩**：这一批盯的是**本次解耦依赖的另外几条守卫**——preset 体文件清单、bootstrap 是否真从契约派生、overlay 不得带声明、frontmatter 单一来源。清单 **17 → 21 条，21/21 检出**。

**抓到的真盲区（B3 事故形状的第三个入口）**

`dsh/profile/notes-assistant.patch.yml` 的"不得带声明"那条断言，实现是 `blockOf(rel) === null`——`blockOf` **只找生成标记块**。于是**一句无标记的 `- id: preset-notes-assistant`** 可以安然住在 overlay 里，**所有门禁全绿**。

而 overlay 正是**插件每次起服务都重写**的那份文件（从内嵌副本重新生成）：声明住在这里 ⇒ 下一次启动就被擦掉 ⇒ 每个会话报 `agent-preset/not-found`。**这就是 2026-09-26 B3 那次真机事故的形状**，B3 把声明搬走了，但只把"标记块"这条路堵上，**没堵"裸声明行"那条**。

已补断言：按**行 id** 判（`/^\s*-\s*id:\s*['"]?preset-notes-assistant['"]?\s*$/m`），不再只看标记块。变异：插入那句裸声明 ⇒ 该条红。

**两条"我的变异没长成守卫要抓的形状"**（同样记下来，因为它们会让扫描器谎报覆盖）

- **frontmatter 拷贝**：我把复制来的分隔符正则塞进 `dsh/preset/hook-frontmatter.mjs`——而那正是守卫**按路径跳过**的两个规范文件之一（不跳过它就会把自己判违规）。⇒ 变异放进了白名单，什么都没验到。已改放进消费者 `note-tools.mjs`，并**当场被 `check-mutation-anchors` 抓到锚点写错**（那个门禁做对了它该做的事）。
- **overlay 声明**：同上，第一版变异插的行不带标记，而判据只认标记。

**顺带修掉扫描器自己的第三处判据缺口**：`check-frontmatter-source` 的报错行是 `[COPY] file:line` 加一行汇总，**根本没有 `FAIL` 字样**（它靠 exit 1 表达失败）。我的失败行过滤只认 `[FAIL]` 与 `^FAIL`，于是把它误判成"判据不符"。现在认"任何 `[XXX]` 前缀或行首 FAIL"。

**验证**：`mutation-sweep` **21/21**；`check-mutation-anchors` ok（21 锚点各一次，**3 条已治愈盲区**仍被点名——新增的 B3 那条也进了 `fixedBy`）；`check-preset-body-lists` 绿（新增 1 条断言）；全量门禁 **55/55**；`main.js` 无变化（本刀不碰生成物）。

**边界**：清单仍是"本次解耦动过的守卫"，不是全仓 57 条断言级的覆盖；本次 5 条里 **1 条是真盲区**、4 条是判据/形状修正。

## 2026-10-15 · 变异清单首次扩展：抓到一个真 bug（两份 shim 早已漂移）与一处零覆盖（**已实现**）

**为什么扩展**：上一刀的清单只覆盖"本次会话单独改过的守卫"（12 条）。这一次补上**同一批语义里我漏掉的**五条，结果两条有价值、三条暴露的是**我的判据写错了而不是代码有问题**——两种都要如实记。

**抓到的真问题**

1. **两份 shim 已经漂移（真 bug）**：`dsh/host/hook-frontmatter.mjs`（发布包里的那份）re-export 三个符号，而 `build-obsidian.mjs` **生成**给物化包的那份只有两个——**少了 `HOOK_SCHEMA_VERSION`**。两份文件头都写着"Same role as the file the published package ships"，**没有任何门禁比过它们**。今天没有消费者 import 那个符号，所以是**潜伏**的：一旦 bundle 布局里有代码 import 它，就是启动期 `SyntaxError`。已把生成侧补齐，并让 `check-engine-sync.mjs` 断言"发布侧与生成侧 re-export **同一组**符号（双向相等）"，不再靠注释。

2. **`hook-history.json` 的 schemaVersion 零覆盖**：上一刀给它加了格式标记，**没有断言**。删掉那一行，469 条断言**全绿**。已补：`buildHookHistory` 的返回值必须带 `schemaVersion`（返回值就是 `writeHookHistory` 落盘的内容）。

**三条"其实是我判据错"的**（写下来是因为它们同样会误导人）

- **v1 基线**（把"缺版本 ⇒ v1"改成"⇒ 未知"）：我给的期望断言名不在失败列表里，于是被标成"未检出"。实际它**触发 10 条断言**（passive 信号、merge、报告行…全部塌）。⇒ 这种"一改动整条管线全塌"的变异，**钉一个名字反而低估了证据**；条目改成显式 `expectAny: true`。
- **权威常量被改**：同理，触发 3 条（含 v1 那条）。
- **嵌入 loader 名单多一个符号**：判据漏了——本仓库的守卫有**两种失败前缀**，`[FAIL] label` 与 `FAIL  message`（后者是较早那批独立守卫）。我只匹配了带方括号的那种。已改成两种都认。

**新增的五条又暴露出一处"判据依赖注释"**：那份新检查第一次跑就红了——**但红的是我的检查**：我原本断言"shim 镜像权威文件的全部导出"，而 `hook-frontmatter` 的 shim **有意只 re-export 三个**（宿主只 import 一个）。已改成正确判据：① shim 覆盖`dsh/host/*` 真正 import 的符号；② 发布侧与生成侧**同一组**。第二条正是抓到真 bug 的那条。

**验证**：`mutation-sweep` **16 条 → 17 条，17/17 全部检出**（都点名预期断言）；`check-engine-sync` 绿（新增 4 条 shim 断言）；`test-memory` **468 → 469**；全量门禁 **55/55**；文档计数 468 → 469（7 处）+ README 对重录。

**边界**：清单仍只覆盖`本次解耦动过的守卫`，不是全仓 55 条门禁；本次新增的 5 条里 3 条是"判据修正"而非"新覆盖"。

## 2026-10-15 · 第一次成体系跑变异扫描：找到 2 条"守卫盯着的其实是别的东西"（**已实现**）

**为什么做**：本仓库的规矩是"加守卫必须做变异验证"（`AGENTS.md` §6）。本次解耦改动过的每条守卫**都**这样验过——但**一次一条、在会话草稿目录里手动跑**，那个目录现在不存在了 ⇒ **证据不可复现**：读者能看到提交与账本里的声称，却重跑不出那份验证。这一刀把它做成可重跑的。

**做法**：`scripts/qa/mutation-sweep.mjs` —— 逐条**反转一个守卫**（在内存里改、`finally` 还原）、跑**那条守卫自己的门禁**、要求输出里出现 `[FAIL]`，并且**点名预期的那条断言**。判据严格这一条是刻意的：第一版判据是"输出里出现 failed"，于是两条**门禁其实瞎**的变异被算成"已检出"——它们的门禁只是打印了含 failed 的描述文字。

**结果（12 条，12/12 检出，且都点名了预期断言）**，其中**两条是真盲区**：

| 变异 | 第一版判据 | 真相 |
|---|---|---|
| 统计重置**不再原子**（`writeFileAtomic` → `writeFileSync`） | 算"检出" | **瞎**：两者**内容相同**，差别只在"写一半崩了会怎样"。套件**全绿** |
| `note_recall` **不再盖章 schemaVersion** | 算"检出" | **瞎**：既有断言**总是从体检已经盖过章的文件出发**，所以删掉这次盖章它们什么都看不到。套件**全绿** |

**两条都补上了断言**（`test-memory` **463 → 468**）：

- **原子性有了可观察痕迹**：`writeFileAtomic` 在目标存在时留下一份 `.bak`（内容是**重置前**的字节），而 `writeFileSync` 什么都不留。断言实测：`{"bak":{"uses":1,...},"tmp":false}`。这是本机不杀进程就能看到"原子与非原子之别"的唯一办法。
- **盖章从"空文件"起测**：先删掉 stats 文件，再调 `recordRetrievalStats`，于是**只有那个写者**能把版本标记放进去；断言它确实放了。

**顺带的结构改动**：清单抽成 `scripts/lib/mutation-entries.mjs`，由一个**快且只读**的新门禁 `scripts/check-mutation-anchors.mjs` 盯住——每条变异的 `from` 锚点必须在目标文件里**恰好出现一次**，且两条"已治愈的盲区"所指的断言必须**还在**（删掉断言就等于重新打开那个洞）。扫描器本身**永远不能当门禁**（它写被跟踪的文件，崩了会留下被改过的树），所以"能进 CI 的那一半"就是锚点新鲜度。门禁总数 **54 → 55**。

**验证**：`mutation-sweep` **12/12**（每条都点名预期断言）；`check-mutation-anchors` ok（12 锚点各命中一次，2 条盲区仍被点名）；`test-memory` **468/468**；全量门禁 **55/55**；文档计数 463 → 468、门禁 54 → 55（各 7 处/1 处）+ README 对重录。

**边界（如实说明）**：12 条覆盖的是**本次会话改动过的**守卫，不是全仓 55 条门禁；`test-agent-preset` 的两条真 dsh 断言、`check-engine-sync` 的 `KNOWN_ESCAPES` 到期检查等**未纳入**本轮清单（前者需要真 dsh 起停，后者需要造出"已一致却仍登记"的重复）。清单是可扩展的，不是穷尽。

## 2026-10-15 · 把"归档那一刀改变体检报告"从断言变成数字，并钉住它（**已实现**）

**来源**：耦合评估 §4 P5。上一刀把体检的卡片写盘收进 `makeCardWriter` 接缝后，我判断"把 1 537 行的 `buildAuditReport` 劈成分析 / 写回"**不能机械做**，理由是**归档那一刀会改变体检自己的输出**。那次只有一句断言，没有数字。这次先量它。

**怎么量的**（隔离实验，两份临时库、只改 `autoArchive` 开关、逐字段 diff）：

| | autoArchive=false | autoArchive=true |
|---|---|---|
| `sections.autoArchiveTargets` | 1 | 1 |
| `sections.archived` | 0 | **1** |
| 卡片仍在 `records/` | 是 | **否**（移到 `.deepseek/archive/records/`） |
| `counts.cards` | 2 | **1** |
| `decisions.total` | 2 | **1** |
| `sections.unused` / `.unverified` | 1 / 1 | **0 / 0** |

**整份报告 122 个字段里有 22 个不同**（含 `checklist`、`human`、`report`、`ledger.newCount`、`counts.archiveCandidates`）。根因是 `moveCardsToArchive` 在**函数中段**执行，而其后构建的每个 section 都按 `live(card)` 过滤——**那次写不是分析的副作用，而是分析后半段的输入**。

**因此劈法只有两种，各有代价**（这是本次真正的结论，写进测试注释）：

- **(a) 把归档挪到分析之后**，再重算那些 section ⇒ **改变体检报告**（被归档的卡会留在 live 区）；
- **(b) 跑两遍分析再 diff** ⇒ 每天的体检跑两次，且"两次体检"会变成可观察的行为。

**改了什么**：不劈，而是**把依赖关系钉成断言**（`scripts/test-memory.mjs` 新增 3 条，**463 → 466**）：

1. `autoArchive=false`：卡片被列为 `autoArchiveTargets`，但**一个都没移动**；
2. `autoArchive=true`：确实移动了（**移动而非删除**，落在 `.deepseek/archive/records/`），且报告如实写出 `sections.archived` 与 `counts.autoArchived`；
3. **依赖本身**：同一份库在开关两态下报告**必须不同**（`counts.cards` 2→1、`decisions.total` 2→1、`unused`/`unverified` 1→0、`checklist` 含"已自动归档"）。⇒ 未来若有人"顺手"把归档挪到分析之后，这三条会红，而不是静默改变体检报告。

**验证**：`test-memory` **463 → 466** 全绿；`main.js` 重建（897 738 B，字节无变化）；全量门禁 **54/54**；文档计数 463 → 466（7 处）+ README 对重录。

**边界**：本刀**没有**拆函数——接缝（`makeCardWriter`）已在，拆的两种代价也已量化，但选择哪一种属于**产品取舍**（要不要让体检报告反映归档后的世界），需要用户拍板，我不替他定。

## 2026-10-15 · 第 6 步第三刀：面板卡片按钮的写路径也搬进守卫路由（**已实现**）

**来源**：J1=B / 耦合评估 §3 C4-1。上一刀搬走读路径后，`applyFeedback` 与 `archiveMemoryFile` 还剩**两处**消费者：① 面板自己卡片上的 ✅/❌/**忘掉** 按钮（`MemoryView.feedback()`，进程内直接改卡）；② **agent 渲染的 `/feedback` 链接**（LinkServer 的落地页）。① 是**唯一一条没有 token 墙、没有 Origin 校验、没有服务端锚定 root 的写路径**——正是 D2（2026-09-26）在设置页已经消灭的那种形状，只是当时漏了面板按钮。

**改了什么**

1. **请求/回执两个助手提升到模块作用域**：`panelRequest(plugin, path, body)` 与 `panelRequestWithReceipt(plugin, path, body, okText)`（原来只在设置页里，叫 `panelWrite`/`writeOrNotice`）。设置页改成两行委托，**行为不变**。
2. **`MemoryView.feedback(rel, action)` 改 async、走守卫路由**：`forget` ⇒ `/memory-panel/archive`，其余动作 ⇒ `/memory-panel/feedback`；回执取自服务端 JSON（原先用本地 `FEEDBACK_MESSAGES` 文案，现在服务端的 `applyFeedback` 自己返回消息，前端文案只作兜底）。body 里的 `root` **不是信任输入**——路由会用服务端自己的 workspace 注册表再校验一次（`resolveAllowedRoot`），客户端那段 `parts` 检查只是提前退出。
3. **`LinkServer` 的 `/feedback` 落地页刻意保持进程内**，并在 allowlist 注释里写明理由：它是 **agent 渲染的链接的落地页**，由 LinkServer 直接服务；那条路上**没有**代理端口可用（反代可能没绑），交给 HTTP 会是"服务没起来时点反馈链接彻底无响应"。这是一次**有意的例外**，不是遗漏。
4. 因此 allowlist **仍是 10**（`applyFeedback`/`archiveMemoryFile` 为这一处保留），但"面板写卡绕过守卫"这条不一致消失了。

**顺带修掉一条自查失效**：`test-panel-routes` 里"设置页不再手写路由路径"那条断言，锚点是 `const panelWrite = async (path, body) => {`。助手提升后这行不再以 `async` 开头 ⇒ `indexOf` 返回 −1 ⇒ 断言在**空字符串**上比对，**它自己在无内容可查的情况下"通过"了**。这与上一刀 `appendedHelper` 的标记歧义是同一形态（守卫锚在会变的文本上），锚点已改为形如 `const panelWrite = (path, body) =>` 的搜索。

**验证**

- `test-panel-routes` **67 → 68**：新增"面板卡片按钮走守卫路由（非进程内）"断言（要求 `async feedback(rel, action)` + `panelRoute('archive') : panelRoute('feedback')` + `await panelRequestWithReceipt(...)`）。
- **变异验证**：把 `feedback()` 退回进程内（`archiveMemoryFile`/`applyFeedback`）⇒ 该条红；恢复后重建、归绿。
- 全量门禁 **54/54**；文档路由计数 67 → 68（5 处）。

**剩余**：loader 仍未退役——它现在服务的是**恰好 10 个导出**，其中 `applyFeedback`/`archiveMemoryFile` 只服务 `/feedback` 落地页，`pathInside` 是反代自己的包含性检查，`parseMemoryFrontmatter` 服务设置页两处只读文本。**"删掉 loader" 不是一个纯机械动作**：要么给这三类各找一个不依赖嵌入求值的归宿（其中 `/feedback` 需要真机验证），要么接受"loader 保留、但缩到最小注入面"。这一判断已写进评估报告 §4 的状态表。

## 2026-10-15 · 第 6 步第二刀：内存面板的**读路径**改走服务端，并补上 vault 变更订阅（**已实现**）

**来源**：J1=B。上一刀把 `probeService` 移出 loader 后，剩下的导出里最大的一块是**读路径**：面板用它自己的数据靠 `MEMORY_ADMIN.collectMemoryState` **同步、进程内**读盘——也就是把 `dsh/host/memory-admin.mjs` 求值进 `main.js` 再调。同一份读取逻辑因此存在两份，引擎一改就得重建插件。

**改了什么**

1. **`fetchPanelState`**（模板作用域新函数）：面板改从 `/memory-panel/state` 取数据——那是 dsh 宿主**本来就提供**的同一份数据，且在 loopback + Origin + token 边界之后；token 与 settings 端口沿用设置页写入那套（已验证的路径）。失败**报错**（"服务没起来" 与 "你还没有记忆" 必须在界面上看得出区别），绝不渲染成空面板。
2. **`render()` / `renderBody()` 改 async**：`body.empty()` 与错误兜底留在 `render()`，数据获取在 `renderBody()`。调用点里 `this.render()` 不 await（工具栏与定时器保持响应），拒绝在 `render()` 内部处理。
3. **补上 vault 变更订阅**（`modify`/`create`/`delete`，400 ms 去抖，`onClose` 清理定时器）：这是评估报告 §C6.5 记下的那个缺口——体检与 agent 都在面板背后写卡，而**此前没有任何东西会重新渲染**，用户看到的数字一直是旧的。也正是它让"把同步读改成异步取"在体验上不失分。
4. **清掉 13 个零调用者导出**：读路径一走，`collectMemoryState`/`readAuditText`/`titleOf` 随之失去唯一调用者；另有 9 个是 D2（2026-09-26）把设置页写入改走路由后**遗留的别名**（`setHookField`/`setTopField`/`setCapturePolicyMode`/`setMemoryBudget`/`setMemoryConfigFlag`/`setSessionCapture`/`readSessionCaptureEnabled`/`frontmatterSpan`/`replaceFrontmatter`）。loader 的 allowlist **23 → 10**。

**顺带修掉三处守卫缺陷**（都是这次改动暴露的）

- `check-embedded-loader` 的"模板消费了什么"**扫到了注释**：我写的说明注释里提到 `MEMORY_ADMIN.collectMemoryState`，守卫就要求 allowlist 保留它——**退役一个符号后注释还在，allowlist 就永远缩不掉**。现在先剥注释行再扫（与陷阱 65 同族：锚在代码上，不锚在散文上）。
- `check-embedded-writers` 的 `required` 列表**钉住了一个已经消失的形状**（4 个已退役的写者），且把非函数的 `FEEDBACK_MESSAGES` 也按 `typeof === 'function'` 断言。现在列表与模板实际消费者一致，并把"可调用"与"存在"分开断言。
- 该守卫的 prologue **仍把 `http` 当第 14 个注入绑定**，而上一刀已把它从 loader 参数表删掉（多传的实参被忽略，静默）。已在注释里标明；参数表派生留作下一刀（与陷阱 116 的"手工镜像模板常量"同族）。

**验证**

- `check-embedded-loader`：`allowlist covers all 10 MEMORY_ADMIN.* consumers`、`all 10 allowlisted symbols resolve`、两条自检绿；`check-embedded-writers` 绿。
- `test-panel-routes` **65 → 67**：新增两条 artifact 断言——①面板经 `await fetchPanelState` 取数且 `renderBody` 是 async（旧的同步读在这条断言下红），②订阅了 vault 变更且带去抖与清理。
- **变异验证 ①**：把读路径退回 `collectMemoryState` ⇒ 红（"reads its state over the guarded route"）；**变异验证 ②**：删掉 `vault.on('modify')` 订阅 ⇒ 红（"subscribes to vault changes"）；两次都恢复后重建、归绿。
- 全量门禁 **54/54**；文档计数随路由数 65 → 67 更新（5 处）。

**剩余**：loader 还剩 **10 个导出**（`applyFeedback`/`archiveMemoryFile` 是最后一条**进程内写路径**，`/feedback` 的 CSRF 守卫与 `test-link-server.mjs` 的抽取夹具要一起改；`pathInside` 是反代自己的包含性检查，可能永远留在插件侧）。这三件做完 loader 才能整体删除。

## 2026-10-15 · 第 6 步第一刀：把 `probeService` 移出嵌入 loader（**已实现**）

**来源与目标**：J1=B（退役 Obsidian 侧嵌入 loader）的第一小步。loader 的 23 个导出里，`probeService` 是**唯一当初没有理由待在体内**的那个——它进体内只因"体内能拿到 `http`"（注释原文如此），而 `obsidian/main.template.js` 顶层本来就 `const http = require('http')` 给反代用。把它搬出去，同时让 loader 的**注入参数表少一项**（`http` 不再注入），是本仓库"减少注入面"的直接收益。

**改了什么**

1. `obsidian/main.template.js`：`probeService` 从 `new Function` 的体内**移到模板作用域**（紧邻反代），`probeServiceStatus` 改成一行薄包装；loader 的 `return { … }` 去掉它，`new Function(...)` 的参数表与实参表同时去掉 `http`。`main.js` 891 026 B（+176）。
2. `scripts/check-embedded-loader.mjs`：**该守卫自己有两处结构性缺陷，被这次改动暴露并修掉**——
   - **标记歧义**：`appendedHelper()` 用 `'    + `'` 找"体内追加的 helper"。模板里**本来就有别的地方**（HTML `<meta>` 构造器）是同样的缩进 + 反引号，helper 在时它只是**恰好最先出现**；helper 一删，守卫就撞上无关的那个、报"unterminated"。现在改成**标记与终止符一起匹配**（`/\n    \+ `([\s\S]*?)`;/`），只会命中追加惯用法，不存在时返回空串。
   - **哨兵腐烂**：那个"锚点是不是最近的前一个 loader"的自检**硬编码** `probeService` 当哨兵。退役一个导出就会让自检假红——这与本仓库反复记录的"数字/名字写进守卫会腐烂"同族。现在哨兵取自**本次实际读到的 allowlist 的第一项**，不再硬编码。
3. 新增模块级注释说明"为什么它以前在体内、现在不在"，以及**剩下那些导出各自需要什么归宿**（读路径去服务端、写路径去面板路由）之后 loader 才能整体退役。

**验证**

- `check-embedded-loader`：`loader injects 13 bindings`（原 14，少了 `http`）、`allowlist 22 symbols`（原 23）、`all 22 allowlisted symbols resolve`、两条自检均绿。
- **变异验证**：把 `probeService` 塞回 allowlist（它已不在体内）⇒ 红，报 `ReferenceError: probeService is not defined`（即"名单与体内实际定义脱节"这件事仍然会被抓到）；恢复后绿。
- 全量门禁 **54/54**；`check-embedded-writers` 绿。

**剩余（第 6 步未完成的部分，如实列出）**：内存面板的**读路径**仍是同步、进程内读盘（`renderBody` → `collectMemoryState`），要改成异步经 `/memory-panel/state` + 订阅 vault 变更刷新；`/feedback` 的**写入**（`applyFeedback`/`archiveMemoryFile`）仍走进程内；`/feedback` 的 CSRF 守卫与 `test-link-server.mjs` 的抽取夹具都要跟着改。这三件做完，loader 才能整体删除。

## 2026-10-15 · 体检的"写回"变成一条可注入的接缝（**已实现，第一步**）

**来源**：耦合度重测（[`docs/coupling-assessment-2026-10-15.md`](coupling-assessment-2026-10-15.md) §3 C1 的 F7 / §4 P5）实测：`buildAuditReport` 是**一个 1 537 行的单函数**，前半分析、后半**直接写盘**（hook 统计、`gain`、卡片 origin、归档移动、notation 块、账本、快照）。由此两件事既**说不清也测不了**：

- **"体检只报不改"这条不变量看不见边界**——写盘与分析在同一函数体里，读者无法指出"从哪一行开始改东西"；
- **无法回答"这一趟会对库做什么"**——没有"注入一个不写盘的写者"的口子。

**改了什么（本次只做接缝，不做整体搬家）**

1. **`makeCardWriter()`**：把体检的**四处卡片写盘**收成一个对象——`syncHookStats` / `syncTopLevelStats` / `setOrigin`——默认由同一批既有函数构造（**行为一字不变**），调用方可以经 `helpers.cardWriter` 覆盖它。
2. **体检三处写盘点全部改走这条接缝**：hook 统计合并、`gain` 落盘、origin 声明落盘。`gain` 那处仍先用 `rewriteHookStats` 判断"是否真有变化"，无变化就不调用写者（保住"没东西要存就一个字节都不动"的既有性质）。
3. **`__deferred` 标记**：接缝上新增一个显式字段，表示"这个写者**故意没写盘**"。体检的后置条件原本是"写完回读文件比对"，对不写盘的写者毫无意义，把它当失败会让每一次 report-only 探测都报 `degraded`；现在按写者自己的返回值判定（默认写者不设该字段，行为不变）。
4. **没做的事，以及为什么**：没有把 1 537 行函数整体劈成 `buildAuditReport`（纯）+ `applyAuditReport`（写）。原因是**归档那一刀会改变体检自己的输出**（`sections.archived` / `downstreamReview` 都依赖"这一趟哪些卡被移走了"），要忠实拆分就得让"写"回传一个被改写的报告，或在报告里塞私有上下文——那是**等价行为的风险**，不该和"建接缝"挤在同一步。接缝到位后，那一步可以在有对照断言的前提下单独做。

**验证**（`scripts/test-memory.mjs` 新增 2 条断言，**461 → 463**）

- **注入一个 deferred 写者**跑完整体检：断言 ①写者收到**每一次**卡片写入意图（实测 3 次：`setOrigin` + 两次 `syncHookStats`，其中合并后的 `uses` 为 5），②**卡片文件字节完全不变**（`after === before`），③`postconditions.statsFailures` 为空。
- 同一趟的报告仍然**完整**，而且**明说它没落盘**：`status === 'degraded'` 且 warning 为"声明 uses 与合并值不一致"——即"只报告"这件事在报告里可见，而不是伪装成一次成功的写回。
- 全量门禁 54/54；`check-engine-sync` 绿（23 共享符号未变）；`main.js` 重建 890 292 B。

**边界（如实说明）**：本次**未**覆盖 **归档移动**（`moveCardsToArchive`）、**notation 块**（`syncNotationBlock`）、**账本/快照** 这三类写盘——按接缝注释里写的理由，它们属于"引擎自己的簿记"与"报告之外的副作用"，扩接缝是下一步而不是这一步。

## 2026-10-15 · `retrieval-stats.json` 的双写者协议写成契约，重置改成原子写（**已实现**）

**来源**：耦合度重测（[`docs/coupling-assessment-2026-10-15.md`](coupling-assessment-2026-10-15.md) §3 C4-1 / §4 P4）实测：`cache/retrieval-stats.json` 是**唯一一个两个写者共写**的派生文件，而两侧的**锁不一样**——`note-tools.mjs` 用模块级 promise 队列串行化自己的读改写，体检的重置却在队列之外直接 `writeFileSync`。它当时**没有任何门禁覆盖**。

**改了什么**

1. **重置改成原子写**：体检的 `writeFileSync(…, JSON.stringify(cleaned))` → `writeFileAtomic(…)`（写 `.tmp-<pid>` 再 `rename`）。理由不是"并发更好看"，而是**截断写入的后果无界**：文件被读成"没有统计"⇒ 那一窗的命中全被静默丢弃。原子化把这条路径的失败模式收窄成"旧值仍在"。
2. **协议写成三行契约**（`note-tools.mjs` 队列上方 + 体检重置处，两处各写一份、互相引用）：谁记录（增量：`uses` 与 `__meta__.calls/empty`，文件是 **delta 不是总数**）、谁消费（合并进卡片后归零）、未知版本**两侧都停手**。并**如实写下它不保证什么**：队列只排本写者自己的更新，**不是分布式锁**，体检不取它；落在"体检读→写"窗口内的一次命中仍可能丢——可接受，因为计数是建议性的，且丢失上界是一个体检窗口。
3. **不新增机制**：没有加文件锁、没有改 IPC、没有让体检去 import `note-tools` 的队列（那会把"预设侧两模块"变成新的硬依赖）。协议靠**文档 + 原子写 + 断言**钉住。

**验证**（`scripts/test-memory.mjs` 新增 1 条断言，**460 → 461**）

- **双写者顺序**：先 `buildAuditReport`（合并 + 重置），**再** `recordRetrievalStats` 记一次命中；断言重置后的文件仍带 `__schemaVersion__: 1`、`__meta__.calls === 0`（可被下一个写者直接接上），且随后的命中写进 `uses: 1` 与 `last_query`。实测输出：
  `reset={"__schemaVersion__":1,…,"__meta__":{"calls":0,"empty":0}}` →
  `hit={…,"uses":1,"last_query":"版本测试"},__meta__:{calls:1,empty:0}`。
- 前一条改动的三条断言（缺版本=v1 / 未知版本拒绝改写 / 保留键不作为卡片）仍绿。
- 全量门禁 54/54；`check-engine-sync` 绿（23 共享符号未变）。

**边界（如实说明）**：本次**没有**构造真正的并发交错（两条写路径分别位于体检与工具调用里，进程内无法稳定复现"体检读到一半时一次命中落下"）。因此"丢一次命中"那半只有**静态论证**（锁不互斥），没有实测断言；被断言的是**原子性与可续写性**那半。

## 2026-10-15 · 派生缓存补上 schemaVersion：兼容基线只有两半——"缺版本=v1"与"不认识的版本拒绝改写"（**已实现**）

**来源**：耦合度重测（[`docs/coupling-assessment-2026-10-15.md`](coupling-assessment-2026-10-15.md) §3 C4）实测：10 类知识格式里 **4 类连版本字段都没有**，且**全部零迁移机制**。其中 `cache/retrieval-stats.json` 是唯一一个**两个写者**共写的派生缓存（`note-tools.mjs` 记命中、体检合并后重置），而它连"形状变了"都表达不出来。

**拍板与范围**（用户 2026-10-15 选定 **B + D**）：只做"缺版本 = v1 的向上兼容"与"未知版本 ⇒ 拒绝写入并报告"，**不做**一跳一个迁移包（C）。理由是这 6 个 cache 全是**可重建的派生件**，迁移机制对它们没有意义；而且当时**没有任何历史版本需要迁移**，建迁移器只是空壳。保留原件（不变量 2）只对**有损**的两类有意义——卡片 frontmatter 与 `captured-sessions.json` 的捕获水位线——它们不进本次改动。

**改了什么**

1. **共享常量下沉到 `dsh/preset/engine-shared.mjs`**（`RETRIEVAL_STATS_VERSION_KEY` / `RETRIEVAL_STATS_SCHEMA_VERSION`）。第一版把它们分别写在 `math-memory.mjs`、`memory-admin.mjs`、`note-tools.mjs` 三处，`check-engine-sync.mjs` 立刻报"共享符号清单新增一项"（23 → 24）——它抓对了：这是**同一批事实的第三份手抄**。下沉后清单一字未动（17 同步 + 6 偏离）。宿主 shim `dsh/host/engine-shared.mjs` 与 `build-obsidian.mjs` 的 `SHIM_SOURCES` 同步加了两个导出（两者都是"手抄导出列表"，必须一起改）。

2. **`cache/retrieval-stats.json` 带版本**：`__schemaVersion__` 与 `__meta__` 同属**引擎保留键**（卡片路径永不与之相撞）。`note-tools` 每次写入盖章；`math-memory` 的体检在读取时判版本、在重置时**保留**该键并回读校验（新后置条件 `statsVersionLost`）。消费该文件的两处宿主代码（`collectMemoryState` 的待合并命中、boundary phrases 的 `last_query`）都把保留键排除。

3. **兼容基线的两半，逐条可执行**：
   - **缺版本 ⇒ v1**：读到没有键的文件按 v1 解释，计数照常消费；下一次写入补上键。**旧文件不需要被改写**（这是"纯加法"的可执行含义）。
   - **未知版本 ⇒ 不动它**：版本越界时 `readRetrievalStats` 返回 `{ usable:false }`，体检把命中计数当**"无数据"而不是 0**（`passive.calls === 0`）、在 `warnings` 里点名、**跳过重置**（否则会把更新引擎写的东西覆盖掉），并在报告里新增 `retrievalStats: { version, usable }` 供面板显示"统计文件来自更新版本"。`note-tools` 侧遇到未知版本**直接不记录**（retrieval 本身不受影响）。

4. **`cache/hook-history.json` 带版本**：`buildHookHistory` 返回值加 `schemaVersion`。宿主读者按字段挑，无需改（旧文件 = v1）。

**验证**（`scripts/test-memory.mjs` 新增 3 条断言，**457 → 460**）

- ① 无版本文件读出 v1，且下一次重置**盖上版本并保留计数**（实测输出 `{"__schemaVersion__":1,…,"__meta__":{"calls":0,"empty":0}}`）。
- ② `__schemaVersion__: 99` 的文件：报告 `{version:99, usable:false}`、`passive.calls === 0`、warning 点名、且**文件与改写前逐字节相同**（用 `readFileSync === foreign` 断言）。
- ③ 保留键不会作为"一张卡"出现在面板数据里。
- `check-engine-sync` 绿（23 共享符号未变）、`check-frontmatter-source` 绿、全量门禁 54/54。

**顺带修掉一个由本次改动暴露的坑（handoff 陷阱 117）**：`engine-shared.mjs` 过去只有宿主半用，所以 `scripts/test-agent-preset.mjs` 里那份**手写**的探针 staging 清单没有它；preset 现在也要 import 它 ⇒ 探针 home 少一个文件 ⇒ 那条真 dsh 门禁报 `agent-preset/invalid / math-memory (./math-memory.mjs): never started`（本仓库第一类静默故障）。**五条 `preset body lists` 门禁全绿也没抓到**，因为它们比的是契约与 import 闭包，不看这份探针拷贝。已把该断言改成**对契约（`PRESET_BODY_FILES`）断言**，少一项就报出名字。

## 2026-10-15 · 面板路由与客户端写作路径不再各抄一份（**已实现**）

**来源**：耦合度重测（[`docs/coupling-assessment-2026-10-15.md`](coupling-assessment-2026-10-15.md) §3 C2）把 `PANEL_ROUTES` 判为**契约幻觉**——`profile-contract.mjs` 里那两个字段（`panelRoutes` / `overlayRows`）**没有任何运行时读者**，真值仍在面板的 `if (method === … && pathname === …)` 链、三份 yml 和客户端字面量里；门禁只能拿正则**从源码里抠**这些字符串来比对，所以"改了契约就生效"是假的。

**改了什么**

1. **`dsh/host/math-memory-panel.mjs`：把 11 条 `if` 分支换成一个导出的数据表 `PANEL_ROUTE_TABLE`**（`{ methods, root, handler }`），`apply()` 迭代它。顺序**刻意与 if 链逐条一致**，因为它是承重的：
   - `root: false` 的路由（只有 `/workspaces`）必须在**根校验闸门之前**服务——它服务的是工作区注册表而不是 vault，而客户端半个**不带 `root`** 取它；要求 root 会让下拉框永久为空（实测过的旧故障）。
   - 其余路由必须在闸门之后。运行时因此加了一条**形状断言**：`PANEL_ROUTE_TABLE` 必须**恰好一条** `root: false` 且**排在第一位**，否则插件启动即抛错——防的是"未来编辑悄悄把闸门挪走"这类结构性回退（与"约束根永远来自服务端"那条陷阱同族）。
- 非 200 的响应从"在每个分支里自己 `json(res, …, 400)`"改为返回 `{ __status, __envelope }`，由唯一的派发点写响应；语义逐条不变（`/feedback` 的 `rel/action required` 仍是 400、`outside root` 仍是 403）。

2. **`scripts/check-profile-contract.mjs`：PINNED-4 → READ-3 + READ-3b。** 现在 `import` 那张表，断言**它的键集合 == 契约的 `PANEL_ROUTES`**（双向，多一个少一个都红），并断言每条都有 `methods` + `handler` + boolean `root`。契约自报从 `3 read + 7 pinned` 变成 **`4 read + 6 pinned`**。

3. **`obsidian/main.template.js`：设置页不再手写路由路径。** 新增 `panelRoute(name)`，从构建期注入的 `PROFILE_CONTRACT.panelRoutes` 里取；4 处 `panelWrite/writeOrNotice` 改为 `panelRoute('config-flag' | 'capture-policy' | 'session-capture-toggle' | 'injection-budget')`。契约里没有那个名字就**在插件加载时抛错**，而不是 POST 到一个没人服务的路径。

4. **`scripts/test-panel-routes.mjs`：把"钉字面量"换成"钉查找名"。** 原先那三条断言比对的是**本文件里的字面量**（等于自己跟自己比）：契约与服务端一起改、忘了客户端时，门禁仍绿而设置页 404。现在断言 ①4 个查找名都在、②**设置页那个代码块里**不再出现 `'/memory-panel/…'` 字面量、③未知名字会抛错。负向断言只扫设置页那一段——`main.js` 里还嵌着契约模块自身的源码（`PANEL_ROUTES = [...]`），那些字符串是**合法存在**的。

**验证**

- `node scripts/check-profile-contract.mjs` → ok（4 read + 6 pinned；READ-3 `table=10`）。
- `node scripts/test-panel-routes.mjs` → **65/65**（原 62/62；含"路由回归"整段未改仍全绿，证明派发语义等价）。
- **变异验证 ①**（路由权威）：把表里 `/memory-panel/injection-budget` 改名 ⇒ `READ-3` 红，报 `missing=/memory-panel/injection-budget undeclared=/memory-panel/injection-budget-RENAMED`；恢复后归零。
- **变异验证 ②**（客户端契约）：把 `panelRoute('config-flag')` 退回字面量 ⇒ 重建后 `test-panel-routes` 64/65，红的正是"named from the contract"那条；恢复后 65/65。
- `main.js` 重建：870 609 → **874 952** 字节（表 + 注入的查找函数）；`check-bundle-freshness` 绿。

**边界（如实说明）**：`overlayRows` **仍未解决**——它同样零运行时读者，真要让它成为权威得把 `notes-assistant.patch.yml` 的那三行改成生成物（与 preset 声明同一套生成器形状）。本次只做了 `panelRoutes` 这一半，另一半记在耦合评估 §4 P2 里。

## 2026-10-15 · 一条"真 dsh"门禁在所有装成 bundle 的机器上崩溃（**已实现**）

**怎么发现的**：重测耦合度时跑了**全量**门禁（`node scripts/run-gates.mjs`），得到 53/54。唯一失败是**代码缺陷**而非环境结果：

```
ReferenceError: deployedIsBundle is not defined
    at scripts/test-agent-preset.mjs:285:39
```

**缺口在哪**：`const deployedIsBundle = …` 在 145–163 行的 `{ }` 块里声明，285 行在**另一个**块里引用它。该引用位于三元表达式的**求值**位置（`packageOwnsIt ? !profileOwnsIt || deployedIsBundle : profileOwnsIt`），于是它只在 `packageOwnsIt` 为真时求值——也就是**bundle 通道的 profile**。

**为什么一直没被发现**（比 bug 本身更值得记）：这条分支要求
`$DSH_HOME/profiles/<id>/node_modules/dsh-math-memory/dsh/cordis.patch.yml` 存在且声明了 preset。本机实测为**真**（本地包安装留下的），所以在"装成 bundle"的机器上**必然崩**；而在崩溃点上求值失败 ⇒ **284 行那句「preset 声明恰好在一处（bundle ⇒ 包内；平铺 ⇒ profile 自己那层）」从未真正评估过**。这与仓库自己的陷阱族同形（"没有用例走到的分支，不算被测过"）。

**引入点与时间线**：`5f5b949`（"bundle 通道的完整性基线写早了"）把变量放进了块内；其后的 4 个提交（含 0.8.1 发版 `126d181`）都没有跑过全量门禁 ⇒ **发版时这条门禁是崩的**。

**改了什么**：`scripts/test-agent-preset.mjs` —— 把"这个 profile 是不是 bundle 通道"抽成一个模块级辅助函数 `deployedProfileIsBundle()`（带注释说明为什么它必须能在两处被调用），第 172 行与第 285 行**各自调用**它，而不是共享一个块作用域常量。

**验证**：`node scripts/test-agent-preset.mjs` → **24/24**，其中那句此前从未跑到的断言现在**真的执行并通过**（输出：`包内 patch 声明；profile 层也声明了（bundle 通道应为空）`）。随后全量门禁 **54/54**（原 53/54）。

**残留（如实说明）**：本机该 profile 的 `postureDigests` 记录里 `math-memory.mjs`/`note-tools.mjs` 落后仓库（"落后 2/7"），门禁按设计只提示不失败；重新引导一次即可追上。本次未动用户的 `$DSH_HOME`。

**边界**：这是**门禁自身**的缺陷，产品代码与行为均未变，所以不进面向用户的 `CHANGELOG.md`（无版本号改动）。

## 2026-10-14 · 弹窗必须先解释（用户报障；**已实现**）

**用户的话**：「我还发现一个问题，现在有时候会出现 agent 思考完了不先回答，而是马上让用户选择，我认为 agent 应该先解释再让用户选择，用户都不知道有什么东西，怎么去做决策呢，需要约束一下这个」。

**缺口在哪**：协议里本来只有一条 `**少弹窗（ask_user 节制）**`（`dsh/templates/vault-AGENTS.md`，紧跟在「数学交流风格」之后）：它管的是**少弹**——真需要抉择才弹、一次一个问题、选项 ≤3——**没有**要求弹窗前先给解释。所以"弹窗是一轮里的第一件事"在字面上并不违规。

**为什么不能只改模板（这次的关键）**：vault 的 `AGENTS.md` 是**安装进用户库的副本**，由 `bootstrapVaultTemplates` 以 `ensureFile(overwrite=false)` 铺——**用户内容零覆盖是刻意的**（2026-10-05 那次部署实测 19 个模板全部 `[skip] exists`）。因此**存量 vault 永远吃不到改过的模板**。管"每轮行为"的规则必须同时进**注入文本**（`math-memory.mjs` 的 `buildMemorySection`），那条路每个会话都重算。
⇒ 采用与 13b「固化闸门」**同一套两处同押**写法：注入文本管存量、模板管新装，`scripts/test-memory.mjs` 同时钉两处。

**改了什么**：

- `dsh/preset/math-memory.mjs`：新增一节「### 提问与抉择（ask_user 纪律）」，两条——**先回答，再让人选**（正文必须先给出：你看到了什么/结论是什么、为什么这件事需要用户拍板、每个选项分别意味着什么与代价是什么；**弹窗不能是一轮里的第一件事**）、**选项要自解释**（写「做什么 + 后果」，不要「方案 A / 方案 B」；推荐项排第一并给一句理由）。
- `dsh/templates/vault-AGENTS.md`：同一句话（给新安装的库）。
- `scripts/test-memory.mjs`：新增 2 条断言，把这条声称钉在两处文案上（**改文案必须同时改两处**，否则红）。

**验证**：`test-memory` **455 → 457**，两处断言全绿。变异验证 **D**：只把注入那处的关键词拿掉 ⇒ 只有"INJECTED"那条红、模板那条仍绿——守卫确实分得清两处，而不是同一条断言被满足两次；恢复后 457/457。

**收尾（2026-10-14 补完，教训）**：加断言这一步做完了，**但扫文档那一步漏了**——`check-doc-consistency.mjs` 是**按套件实跑数**（`__CHECKS__`，不是正则数调用点）比对全仓计数声明的，所以 `455 → 457` 一落地，门禁立刻红：`README.md`、`README.zh.md`、`ARCHITECTURE.md`（2 处）、`docs/memory/README.md`、`docs/handoff.md`（2 处）共 **7 处**仍写 455，已全部改为 **457**。**历史记录里的 455 保持原样**——`docs/handoff.md` 里的「断言 427 → 455」「发布前零 token 回归 455」是**当时的实测值**，改它才是篡改；这条区分（"当前声明" vs "历史快照"）是手改计数时唯一要判的东西。改后该门禁的 7 条计数锚点全绿。**变异验证 D 复跑**：只拿掉注入侧关键词 ⇒ **456/457**，红的正是 INJECTED 那条、模板那条仍绿。

**边界（如实说明）**：这条约束是**提示词级**的，不是硬闸门——模型仍可能违反，区别只是违规现在**在字面上可被指出**（有原文可对）。要变成硬约束就得进 `ask_user_question` 的调用路径（host 侧拦一道），那是产品决策，本次未做。

## 2026-10-14 · 插件启动守卫拒绝了自己写下的配置（用户报障；**已实现**）

**用户的话**：「打开 Obsidian 时右上角会弹出 `dsh-math-assistant: Error: dsh 配置由「npm」通道安装……`，不过 Obsidian 内的 dsh 倒是可以正常打开」。

**形状**：侧栏那条引导**成功**走过 A′ 的"机会式包化"后，会把 profile 的 `.install-manifest.json` 写成 `owner: npm` + `bundleSource: local`（`obsidian/main.template.js` 自己的最后一次写入）。而**下一次**启动时，同一函数的冲突守卫只比 `owner` 一个字段：`npm !== direct` ⇒ 判定"别的通道拥有此 profile"并抛错。**插件拒绝了自己上一轮写下的配置**——每次开 Obsidian 弹一条红字，而 dsh 本身照常可用（配置早已铺好，只是不再被引导）。

**附带损害（比弹窗更该修）**：抛错点在 `onLayoutReady` 的**同一个 `try`** 里，`bootstrapVaultTemplates()` 排在 `bootstrapDshConfig()` 之后 ⇒ 只要归属是 `npm`，**vault 模板自愈从此全程不执行**，且静默无声。用户看得见的是一条噪声，看不见的是自愈已经死了。

**为什么门禁是绿的**：`scripts/check-bundle-recovery.mjs` §7 只跑**一次** bootstrap 就断言 `owner=npm`；§3 的幂等用例跑在平铺通道上（`owner` 始终 `direct`）⇒「包化成功之后的第二次启动」这一格**从没被测过**。

**真机证据**：`~/.dsh/profiles/notes-assistant/.install-manifest.json` = `owner:"npm"` + `bundleSource:"local"` + `staging:".dsh-math-memory"`，与 `main.template.js` 那次写入逐字段一致；`docs/handoff.md` §7 记录的 2026-10-05 `install --direct --force` 部署留下了它（CLI 的 `directInstallProfile` 会写同一个形状）。

**判据（按已拍板的 A4 落地，不是新决策）**：`docs/pending-decisions-2026-09-26.md` §1 的 **A4 = ①**，其代价一栏写的就是「三处守卫改判据」。所以守卫改成按 **(owner, bundleSource) 二元组**判：`direct`、或 `npm` + `bundleSource: local`（同通道、同本地来源、同一份产物）⇒ 放行；`npm` **没有** `bundleSource`（从注册表正式装的）⇒ 照旧拒绝——"用内嵌副本修好一个已经发布的包"正是这条守卫要拦的事。

**另外两条纪律**：

- **不静默换通道**：本次若没能重跑包化（设置里关了 / pnpm 不在），归属**保持 `npm`**，不回落写成 `direct`。CLI 早就划了这条线（`dsh/install.mjs` → `directInstallProfile`：npm ⇒ direct 属于 `--force`）。平铺文件照常刷新，它们确实存在，所以 manifest 的 posture 清单仍是真话。
- **红字只在用户主动要的时候出现**：拒绝现在带 `channelConflict` 标记，启动路径据此**只写日志**（设置页可见），真失败仍弹 `Notice`；设置页那两个按钮照旧显示原文，因为那才是用户要求重装的地方。

**门禁**：断言 **41 → 51（+10）**。变异验证 3 条：①守卫判据退回只比 `owner` ⇒ **5 条红**（含 §7 二次启动）；②去掉"不降级"规则 ⇒ **1 条红**（`owner=direct`）；③两个自愈退回共用一个 `try` ⇒ **§8 两条红**。门禁本体（`check-bundle-recovery.mjs`，门禁名 `test: channel ownership anchor`）实测绿，重建的 `main.js` 与已认证产物**逐字节相同**；本条原记的 3 条变异验证本次复核未重跑。

**⚠️ 更正（2026-10-14 复核）**：本节原写「恢复后 `npm test` **54/54 绿、零 SKIP**」，**复核不成立**——本机实测 **48/54 + 1 SKIP**。5 条红**全部与本条改动无关**：把本条改动 `git stash` 后，在它之前的 HEAD 上逐字复现——`test: panel routes` 61/62、`test: installer e2e`（16 条断言 + `notes-assistant.patch.yml` ENOENT）、`test: link server port+token stability`（`⑤ 真浏览器验证 | Chromium 没有暴露 page target`）、`test: agent preset mounts`（`ReferenceError: deployedIsBundle is not defined`）。SKIP 的是 `test: panel auth e2e`（环境不允许子进程写自身状态）。**「零 SKIP」这个断言本身就是错的读法**：那条套件在本机一直声明 SKIP、汇总也一直单独列出它——写成 54/54 且零 SKIP，等于把"跑不动"读成了"通过"（坑 69/98 同族）。其中 `test-agent-preset.mjs` 那条是**真缺陷**：`deployedIsBundle` 声明在第 145–163 行的块内，却在块外的第 285 行被引用 ⇒ 门禁在**它本该报错的那种形态**下抛异常，而不是报错。

**诚实边界**：§7 需要本机有 pnpm；没有它时该节**大声 SKIP**（不假装通过），而不依赖 pnpm 的那两条（§4 判据 / §6b 不降级）照常跑。另：`check-bundle-recovery.mjs` 的 `HARNESS_PRELUDE` **手工镜像**模板顶层常量，本次新增 `NPM_CHANNEL` / `LOCAL_BUNDLE_SOURCE` 必须同步镜像——漏了就是每个用例 `NPM_CHANNEL is not defined`（实测：拿 HEAD 版门禁跑新版 `main.js`，6 条红）。

## 2026-10-05 · CHANGELOG 写法返工（第三次）：用户说明不是维护者细账（**已修正**）

**用户的话**：「发布摘要版的 changelog 写得不好，要像 0.7.8 那样简洁，不要说太多关于修改过程的细节，只要说清楚改了什么就好」。

**这是同一类返工的第三次**——`docs/release.md` §5 里已经写着规则（2026-09-18 用户明确要求）：开头**只写一段 3–4 个方面**的摘要；**不要在段落里写内部过程**（累计多少提交、哪个版本漏发、门禁/断言数从多少涨到多少）；细节归 `docs/changelog.md`。**规则写在手册里了，我仍然没读就动笔**——发版时只看了上一版的标题结构，没读 §5。这条比规则本身更值得记：**手册里有规则 ≠ 下次会读到它**。

**我这一版具体错在哪**（对照 §5 逐条）：

| 我写的 | 属于 | 为什么不该进 Release 正文 |
|---|---|---|
| 「门禁 **54/54**、零 token 回归 **455**」 | 内部计数 | §5 明文：门禁/断言数属维护者细账 |
| 「第一次直查是 404……坑 73 那个窗口」 | 流水线过程 | 用户不需要知道 registry 可见性延迟 |
| 「陷阱 115」「陷阱 107」 | 内部编号 | 编号对用户无意义，且会腐烂 |
| 「(Zhang et al., arXiv:2605.12978 Table 5)」 | 论证 | 摘要里点出机制即可，出处归细账 |
| 「本批含 0.8.0 之后未提交的全部改动（56 项）」 | 版本交代 | **第一次返工（0.7.8）就是被这句否掉的** |

**修正**：按 §5 重写 0.8.1 段落——一段摘要（四个方面）+ `Added`/`Changed`/`Fixed`/`Docs` 各条一句"改了什么、你为什么在意"，**只留一条给维护者的反向提醒**（不要把 dsh 版本范围收紧成 `>=0.2.0`，否则插件被静默跳过）。段落 **2640 → 2097 字符**、条目 15 → 12。

**归档与"不漂移"**：线上 Release `0.8.1` 的正文是打 tag 时抽走的**旧版**（含上面那些内部细节），**已发布的 Release 正文不会自动更新**。按 0.7.8 的先例存了 [`docs/archive/release-notes-0.8.1.md`](archive/release-notes-0.8.1.md)；该文件**由脚本从 `CHANGELOG.md` 抽取生成、不手工转录**（我第一次手抄时链接就少了一层 `../`），并核验过"CHANGELOG 的该段逐字包含在归档里"。

**下次怎么防**：发版前**先读 `docs/release.md` §5**，并把摘要当"给用户看的十秒版"来写——凡是要写数字、编号、流水线状态的地方，问一句"这条对用户意味着什么"，答不上来就删。

## 2026-10-01 · 固化改成显式动作（用户拍板；文献处方）**已实现**

**用户的话**：「只加个提示会不会太单薄了，文献又指出如何改善吗」。**问得对**——`［…·不宜当结论］` 那个前缀本质是 P2 那一档（"用记忆时降级引用"），而文献里真正的大头在**写路径**。

**文献给的是什么（引原文，不是我的转述）**：Zhang et al.（arXiv:2605.12978）Table 5 的组件剥离，准确率逐档：**默认就地改写 43.2 → append-only 且旧库可见 50.0 → 加剪枝不去就地编辑 64.0 → append-only 且旧库隐藏 70.0 → 原始轨迹 76.6**。两条直接结论：① **"就地重写旧条目"是单项最伤**；② **"旧抽象在写/用时可见 vs 隐藏"是同一批里最大的一跳**。它的处方（§5）是「episodic 与 schema 两个角色不要塌进同一条重写回路；**abstraction 应 opt-in 且被证据设闸，而不是每次交互后触发**」。卡片里的映射（`literature/cards/zhangUsefulMemoriesBecome2026.md:35`）写得很直接：*"与 P2 互补：P2 管'用记忆时降级引用'，隔离管'写记忆时不受旧抽象影响'"*，并且*"对 P5「单源老化降权」的修正：Zhang 的处方是'原始证据优先'，**不是**'给旧抽象打低权重'"*。

**查档发现的病灶比预想更具体**：写入**其实已经被门控**——`capture-policy.md` 默认 `idea=ask / fact=ask / preference=ask`（要同意），只有 `structure=auto`，而且捕获提问有「**每轮最多一次**」纪律。**但 `vault-AGENTS.md` §2 的"每轮收尾按需三写"是另一套、且没有闸门** ⇒ 「每轮自动固化」不是协议允许的，而是**模型自愿多做的**——恰好落在文献点名最伤的那一格上。

**做法**（两处，缺一不可）：

1. **注入文本**（`math-memory.mjs` 的捕获策略段）：新增一条明确规则——**没有用户同意，不要把本轮内容固化成 records/topics/templates/strategy 的卡或行**；默认执行方式＝**先问**（与既有捕获提问**合并成一次，因此不增加弹窗次数**）；例外只有两个：① 用户当场明确要求记录/整理，② 捕获档位/profile 给过长期授权。并写明 **「没写」不是失败**（整场对话原文由确定性会话捕获进 episodes，跳过固化不丢信息）。
2. **vault 协议模板**（`dsh/templates/vault-AGENTS.md` §2）：同一规则，给新安装的库。

**为什么必须两处**：vault 里那份 `AGENTS.md` 是**安装时的副本**——老 vault 不重装就吃不到新协议，而这条规则管的是**每轮**行为。所以注入侧是主路径，模板侧管新库。**两处由断言钉住**（`test-memory.mjs` 的 `consolidation gate:` 三条），改一处忘另一处会红。

**验证**：断言 **452 → 455**（3 条）。**变异验证 2 条**：删掉注入侧那条 ⇒ **2 红**；只改模板侧 ⇒ **1 红**。恢复后 455/455。

**证据边界（不声称的）**：① 该实验全部在**程序化 agent benchmark** 上（记忆是 LLM 自写的 lesson bank），**没有**测过"人类笔记 + AI 补全"的混合库 ⇒ 可迁移的是**机制**，**不能**换算成你这篇笔记能降多少；② 这条闸门只约束**模型写入行为**（由提示词执行，**不**由确定性层强制），所以它是"降低频率"，不是"禁止"；③ 我**没有**做 A/B 实测（要打真实 API、花钱，需用户点头）——这正是文献的 Table 5 形态，也是唯一能给出真实数字的路。

## 2026-10-01 · 混写笔记：AI 补全段落可见（N-a，**已实现**）

**用户的问题**（2026-10-01 原话）：「如果有一些笔记是 AI 和用户混写的呢，比如 AI 在某篇用户笔记中补全了一些内容，它其实也类似于脏记忆，这个该怎么解决」。

**查档结论：协议早就要求标，真实库也确实在标，但系统三处没接上。**

- 协议要求：`dsh/templates/vault-AGENTS.md` §3 第 2 条「补细节：补证明/例子/定义，标注 `<!-- AI 补全 -->`」——**这条从 0.x 就在**。
- 真实库实测（只读扫描）：`统计学/方法论/数据压缩.md` 里确实有 `> <!-- AI 补全 -->`，另有笔记在正文里自报"其中两处……已单独标注为**待核对**"。⇒ **标记习惯是存在的，缺的是消费者。**
- 三处断裂：
  1. `scanNoteHygiene` 的 gap 正则只数 `待补|待核对|待证明|TODO|待完成`（`math-memory.mjs`）——**不含 AI 标记**，所以标了也不进报告；
  2. `note_recall` 把 AI 补全段落与用户原文**同权返回**，结果行里没有任何提示；
  3. 该标记只在 `scanNoteClaims`（"定理索引写已证、载体自己承认 AI 补全"）那一条**很窄**的路上被消费过。

**为什么文件级的 `origin`（C7）救不了它**：C7 的字段描述**整张卡**是谁写的，而这里是**同一篇笔记里逐段混写**——一个 frontmatter 字段表达不了"第 3 段是 AI 补的、第 5 段是我写的"。按段归属**无法自动判定**（让模型判"哪段像 AI 写的"是语义判断，撞"插件不调模型"红线，而且会误报），所以**唯一出路是把已有标记接进系统**。

**做法**（纯增量、不动排序）：

- `scanNoteHygiene` 新增 `aiMarked` / `aiMarkedTotal`，与 `noteGaps` **分开报**：未闭合是"待做的活"，AI 补全是"不是你说的话"，动作不同，合在一起会让后者消失在"TODO 计数"里。
- 标记识别用**一条**交替正则（注释式在前）⇒ 字面 `<!-- AI 补全 -->` **只计一次**；裸写 `AI 补全`（体检既有的标记词表）仍认得。
- `buildRecallDoc` 给 note 记 `aiCompletions`；`note_recall` 把 `［含 N 处 AI 补全·非用户原话］` **前缀到 snippet**。
  - **为什么前缀到 snippet 而不是加字段**：match 项在 output schema 里是 `additionalProperties: false`，加字段会被 dsh 严格校验拒绝并**打死整次工具调用**——2026-09-14 已经这样挂过一次（`hook`/`boundary` 那次）。这与既有"归档"标签用的是同一条通道、同一个理由。
  - **为什么放 snippet 不放元数据行**：标记的含义是"**这段文字**里有不是用户写的部分"，读者看的就是 snippet。
- 体检清单给一条**带引用规则**的发现（"标记覆盖的段落不是用户本人写的……不得当作用户原话或已核实结论"），人类摘要给一条讲清"你复核后可以删标记，删了就等于认可"。
- `vault-AGENTS.md` §3 把标记从一行注释扩成读写纪律：**一段一个标记、放在段落之前**；读到标记覆盖的段落按"笔记里的说法"引用；用户删标记＝认可，**模型不得替用户删**。

**刻意不做**：**不检测"未标记的补全"**。那是语义判断（红线）、且必然误报；漏标的责任放在协议上（"漏标就等于把 AI 写的话伪装成用户原话"）。

**验证**：断言 **440 → 450**（10 条，含成对否定性断言：混写笔记有计数 / 全自写笔记**不报**；snippet 有前缀 / 干净笔记**没有**前缀；并断言 match 项**没有**多出未声明字段——正是 2026-09-14 的失败形态）。

**遵守 `agent-experience` skill 的一处自我修正**：第一版把"这个前缀是什么意思"同时写进了 snippet 与工具描述（**同一个事实说两遍**），并把标记语法（**实现细节**）写进了模型可见的工具描述。已改成：结果里只出现前缀本身，工具描述只说行为一句，**规则与语法写在 vault 协议侧**。

### 追加：临时标记 `［…·不宜当结论］`（2026-10-01，用户指出真实症状后）

用户在 N-a 之后纠正了我对"干扰"的理解：**不是排序错，是"回复被那篇笔记同化、每次都差不多"**。这条纠正把病因从检索层搬到了**模型行为**层，而且它是对的——`note-interference-probe`（新增只读探针）实测：

- 那篇 61,341 字符的笔记在 **5/5 相关查询**里 rank 1–2（最高 0.93）；
- **0/5 无关查询**侵入 top-8（Borel-Cantelli / Wasserstein / 矩阵打洞 / 不动点 / 数学归纳法）。

⇒ **排序是准的**。真正的机制是 **experience-following**：高分命中被当成结论复述。而仓库里早就有这条失效形态的名字（`note_recall` 描述里的 "fixation trap"）与针对**卡片层**的防御（`inbox/` 带「待打磨」、记录层当已沉淀）——**用户自己的笔记两边都不占**。

**做法**：`buildRecallDoc` 给 note 另外记 `openMarkers`（`待核对/待补/待证明/存疑`），与 `aiCompletions` **合并成一个** snippet 前缀 `［AI 补全 ×11·待核对 ×14·不宜当结论］`；工具描述补一句行为（见到该前缀 ⇒ 重新推导而不是复述，且不得说成用户原话）。

**为什么合并**：两个计数给同一句裁决，两个前缀会在 snippet 窗口里收两次费——第一版 58 字符的长前缀吃掉约 19% 窗口。

**实测（真实库那篇笔记）**：`aiCompletions=11`、`openMarkers=14`，前缀出现在**每一次**取回它的结果里。**它正文第 6 行自己写着的"不是我的原稿、两处待核对"，过去永远不进检索语料**（passage 只取正文前 1500 字符），现在在检索那一刻就被看到。

**不声称的**：这只降低"被复述为结论"的概率；模型行为不由确定性层保证。要根治仍需把"讨论存档"与"可引用的知识"分开——那篇的本质是**逐次追加型活文档**（`§3.6/§3.7/§2.7/§1.6/§2.1.1` 全是过去讨论的存档，标题里就写着"增补/附/错在哪"）。**我没有动用户的笔记**。

## 2026-10-01 · 脏记忆：来源（`origin`）+ 互证判据收紧（C7/C8，**已实现**）

**这一批来自第七批文献**（跨论文评估 [`../literature/notes/memory-fidelity-papers-2026-10-01.md`](../literature/notes/memory-fidelity-papers-2026-10-01.md)，
决策 [`pending-decisions-2026-09-26.md`](pending-decisions-2026-09-26.md) §3.1 的 **C7=A / C8=A**，用户 2026-10-01 拍板）。
**范围是"只加字段 + 收紧一处判据"**：不排序、不权限、不改注入体积——文献 §8 的顺序 1+2。

### 一、`origin`：谁写的，与"验过没有"分开记（C7/N1）

**缺口**：`hook.verified` 回答的是「验过没有」，而「**这话是谁说的**」根本没被记录。Louck（arXiv:2606.24322）
机检证明"以内容、或以内容可导出的血缘边为判决依据的信任信号可被洗白"（T1），要求"写入时绑来源"（T3）；
我们的 `verified` 是**标签**——任何人（含模型）都能打，所以它从来不是 T1 要的那个"来源"。

**做法**（与 `verified`/`verified_by`/`unjustifiedUpgrade` 同一形状：**承诺 + 唯一写入者 + 检测者**，即 `handoff.md:249` 记的范本）：

- 卡片 frontmatter **顶格** `origin: agent|user|imported`；**缺席＝来源未知**（老卡不静默降级）。
- **唯一写入者是每日体检**（`auditMaintainOrigin`，默认开）；模型不可写。
- **凭据**：`.deepseek/cache/card-origin.jsonl`，只追加、只有体检写，每行 `{ v, rel, firstSeen, origin, evidence, updated }`。
  `firstSeen` 是**宿主自己第一次见到这张卡的日期**——内容可以编，日期不行；这就是"绑定"的那一半。
- **检测者**：`structural.unauthorizedOrigin`（照 `unjustifiedUpgrade`：**只报不改**）。`origin: user` **永远**进这一列——
  本地 vault 是纯文本、无认证通道，Louck 的前提 A1 在这里只能退化为"通道推断"（该文献 §5.2 自己写明），
  所以"这是用户原话"**无法被证实**，只能由用户本人确认。
- **取值来源**：`AUDIT_CARD_DIRS` 扫的三层按协议保留给 agent ⇒ 路径判定只会得出 `agent`；`user`/`imported` **不会被路径判出**。
  这是刻意的：本库没有任何通道能区分"剪藏的文章"与"用户自己的散文"，硬猜就是 T1 点名的"用内容派生可信度"。
- **幂等**：值与原记录一致时不更新 `firstSeen`、不改 `updated`。第一版无条件写 `today`，于是**每天都会重写一遍**
  `updated`——把"这张卡的内容变过没有"这个信息抹掉（凭据就废了）。这条由新测例推出（见下）。

**为什么不做排序**：C7=A 明确"只显示不排序"。动排序要过 `engine-probe` 的门槛（`retrieval-v3.md:229`），
而加字段是纯增量——先把"谁说的"记下来，才谈得上按它调权。

**边界（不要过度声称）**：`origin` 只覆盖**体检扫得到的层**（即 AI 自己写的卡）。用户手写的笔记不在 `AUDIT_CARD_DIRS` 里，
所以系统**不给用户的笔记盖来源章**——"你的笔记"这一侧仍然只靠层来区分。

### 二、`cross-referenced` 判据收紧：共享上游不算第二票（C8/N4）

**缺口**：`findCorroboration` 此前只问"别处有没有出现同一个 pattern"。Louck 的 L-c「制造共证」与 Dash 的
Salience（**重复 ≥3 次被当成重要性**）说明"重复出现"是**可以被制造**的信号：把同一次对话的结论抄进两份文档，
就能从零铸出 `cross-referenced`。既有文 §5 曾把它算作"系统自己能降噪"，**本条改口**。

**做法**：匹配到的文档若与本卡**共用同一个 `source`/`depends_on` 出处** ⇒ **同一来源的复述**，**不升级**，
进 `sections.corroborationRepetitions`（"相关重复、不计票"）+ 人类摘要一行。独立性用**候选文档自己声明的链接**观测
（"卡链到了它"是这对匹配成立的原因，不能当独立性证据）；而**一份被污染的文档不否决后面那份独立文档**。

**实现时被自己的测例抓到的两个真缺陷**（都属于"守卫看不见自己的输入"这一族）：

1. **同源集合在 `depends_on` 上是瞎的**——`extractLinks` 是 `buildAuditReport` 里的闭包，而喂给 `findCorroboration`
   的访问器只读 `source`/`related`。已提为**模块级**函数、两处共用同一提取，`depends_on` 一并纳入。
2. **候选文档的出处根本没被读**——证据池条目是 `{ rel, text }`，所以 `other.source` 永远是 `""` ⇒ 新判据
   **结构上不可能**发现同源，却能"通过自己的测试"。已补 `provenanceOfDocument`。
   另有第三个：`structural` 对象在来源 pass **之后**才初始化，于是 `originBlocked` 收集的越权声明被丢进另一个数组，
   `counts.originUnauthorized` 恒为 0——现在 `structural.unauthorizedOrigin` 直接引用那个数组。

**不声称的**：两个**没有**共享链接的文档被当作独立，这是**推断不是证明**（vault 没有认证通道，A1 不成立）。

### 三、验证与覆盖

- `node scripts/test-memory.mjs` **440/440**（427 → 440：来源 8 条 + 互证 5 条）。
- 断言选择：`C8` 组含**否定性断言**（同源不升级 + 独立来源仍升级，两条成对，防"把判据调死"）；
  `C7` 组含**幂等断言**（第二遍不重写卡、不改台账）与 **`maintainOrigin:false` 不写**的配置可达性断言（陷阱 80 的同形）。
- **变异验证**（人工确认，做完即恢复；`math-memory.mjs` 与变异前**逐字节相同**）：
  1. **M-C8**：让 `findCorroboration` 在发现共享上游时**照样**返回独立来源（＝回到 2026-10-01 之前的行为）⇒ C8 组 **4 条红**
     （同源卡被升成 `cross-referenced`）——这条判据确实在管那次升级。
  2. **M-origin-idempotence**：把台账的 `settled` 判定改成恒 `false`（＝每轮都重记一遍）⇒ **2 条红**，
     且输出直接给出证据：`firstSeen` 从 `2026-10-04` 变成 `2026-10-05`（**每跑一次体检，凭据的日期就往后挪一天**）。
  - ⚠️ **这条变异第一次跑时是绿的**——当时的断言只检查"卡片没被重写"，而台账的抖动**看不见**（同一形态：断言没在测它声称的东西）。
     补上"第二遍之后台账逐字节不变"这条断言，变异才转红。**这就是先让变异证明断言有效的价值**：绿的那一次暴露的是断言太弱，不是代码对。
- 文档计数锚点（`check-doc-consistency`）与生成物（`check: main.js bundle freshness`）已随之更新。

### 四、明确不做（本批）

- **不动排序**：`origin` 不进 `hookPrior`（C7=A）。
- **不改注入措辞**：注入层仍按原样；文献 §8 顺序 3/4（固化输入隔离 A/B、诊断基线）与顺序 5（"每轮固化"设闸 = P4/D1-A）
  **仍未拍板**，`pending-decisions-2026-09-26.md` §3.1 保持"待用户决定"。

## 2026-10-01 · dsh 0.2.0-rc.2 适配：审计无破坏 + 三处收口（**已实现**）

**口径先说清**：上一轮（0.1.7）是"插件在宿主上是坏的"（新建会话直接失败）。**本轮没有找到任何破坏**——
逐接口核对下来，插件调用的每个宿主面都还在、签名未变，profile 的 5 条 patch 行 id 全部仍命中
（`dsh --profile notes-assistant --dump-config` = **exit 0、1377 行、零 `not found` 警告**），
依赖面**只增不减**（0.1.7-rc.2 → 0.2.0-rc.2 只多了 `@deepseek-ai/dsh-experimental-schedule-bundle`，**没有任何包被移除**，
而插件对 dsh 的 schedule 服务零依赖——它的"提醒"是注入文本 + memo frontmatter 的 `last_reminded` 自述式，
`math-memory.mjs:3995-4000`/`:4076`）。变更面也窄：npm 上 `0.1.7-rc.2 → 0.2.0-rc.1 → 0.2.0-rc.2`，
**中间没有 alpha/rc.3**，所以口径就是那两份 release notes；其中与本项目有交点的只有 3 条（兼容提示文案、
配置保存更快、pi-ai 0.87.1 移旧模型 ID），逐条判"不改"。完整逐接口表见
[`dsh-0.2.0-adaptation.md`](dsh-0.2.0-adaptation.md)。

⇒ **所以本轮的价值不在"迁移"，而在"把以为验证过、其实跳过了的那条补成真验证"**，外加两处契约/静默失效收口。

### 一、工具 schema 的动态校验此前是**假的绿**（陷阱 110）

两个套件（`test-tool-schemas.mjs` ②、`test-tool-shape.mjs` ②b）里**唯一**调用 dsh 校验器的断言，
都 gate 在同一个硬编码路径上：`<DSH_HOME>/profiles/node_modules/@deepseek-ai/dsh-tools/lib/index.js`。
**本机实测三种形态**：`~/.dsh/profiles/node_modules/…` **False**、`…/profiles/notes-assistant/node_modules/…` **False**、
`%APPDATA%\npm\node_modules\@deepseek-ai\dsh\node_modules\@deepseek-ai\dsh-tools\lib\index.js` **True**
（`npm i -g` 装的 dsh 把内置包放在**全局安装内部**）。⇒ 断言**整块跳过**，而门禁汇总仍打 `9/9`。

**为什么这条在本轮特别要命**：`output.schema` 还能过**宿主自带的**校验器，正是"宿主升级后工具契约仍然成立"的
**唯一动态证据**。一个会静默跳过的检查**无法为 0.2.0-rc.2 作证**——它是 `AGENTS.md` §4 里那种
"绿覆盖的断言比它看起来少"的形态，与坑 98 同族。

**做法**：新增**一个共享解析器** `scripts/lib/dsh-tools-validator.mjs`（两个套件都用它，不写第二份清单）：
候选顺序 = `DSH_TOOLS_PATH` → `$DSH_HOME/profiles/node_modules` → 三个 profile 各自的 `node_modules`
→ **npm 全局安装内部** → `./node_modules`；找不到返回 `null`，调用方**大声 SKIP 并打印试过的路径**。
新变量已登记进 `docs/env-vars.md`（那条守卫双向：代码读了没写下来也红——本次实测确实先红了一次）。

**修后实测**：`test-tool-schemas` **22/22**、`test-tool-shape` **11/11**（修前各 `9/9` 且动态块整块跳过）；
即 4 个工具的 `output.schema` / 9 条代表性 fixture 对 **0.2.0-rc.2 自带**的校验器**零违规**，
反向证明（给 matches 加未声明字段必须被判违规）也是拿那个校验器跑的。

### 二、posture 契约拆分：安装器私有 vs 共享（陷阱 108）

**缺陷**：安装清单给**每一个** posture 文件记 sha256 并当硬校验（"第三份完整性基线"）。
其中 `cordis.patch.yml` 被同一个安装器在 650 行之外定义为"用户的层、永不重写"（`ensurePosture` 注释），
而 **dsh 自己的设置面板按设计就重写它**：`@deepseek-ai/dsh-config-editor` 把整份文件重新序列化后追加自己那一行
（`documentPath === profileContext.patchPath`，`:23-26`；`document.add(...)`，`:105-109`；`writeFileAtomic`，`:123`）。
**逐字节复现**（用 dsh 自己的 `yaml` 包）：安装器写的 `3738 B` → 重序列化 `3749 B`（只有 2 行长 `!!js`
标量被折成 4 行，YAML 默认 80 列）+ 追加 `774 B` 的 3 行 —— **不是人手编辑能产生的形态**。
本机记录 `733715c9…`、现存 `69ea710a…`，13 个文件里**只此一个**不符。

⇒ **门禁把"按插件自己的指示去 `cordis.patch.yml` 改配置"判成了故障，而且永久**：
插件自己在 `notes-assistant.patch.yml:1-4` 就写着 *"user edits belong in `cordis.patch.yml`"*。
**它不是 0.2.0 引入的**：该文件 mtime `2026-09-28 15:26`（早于 rc.2 发布），0.1.7 上同样会红；
且 `dsh --dump-config` 在 0.2.0-rc.2 上实测**只重写 `cordis.yml`**（字节相同、mtime 每次变）、
**完全不碰 `cordis.patch.yml`**。

**判据**（写进契约）：**谁还会写这个文件**，而不是"谁创建了它"。
`dsh/preset/profile-contract.mjs` 的新 `POSTURE_SHARED_FILES` 逐条带实测到的第二写入方：

| 文件 | 第二写入方 | 处置 |
|---|---|---|
| `package.json` | dsh 的插件管理器（`dsh plugin add` 写 bundles/dependencies） | 共享：不冻结、不删 |
| `cordis.yml` | dsh **每次**组合 profile 都重写成 `[]`（`--dump-config` 就会写） | 共享：不冻结、不删 |
| `cordis.patch.yml` | 用户（按设计）+ dsh-config-editor | 共享：不冻结、不删 |
| 模块 `.mjs` / `notes-assistant.patch.yml` / `pnpm-workspace.yaml` | 目前只有我们 | **继续硬基线** |

**做法**：`postureDigests()` 跳过共享文件；`verifyPostureDigests()` 新增 `shared` 桶（**不是** drifted）；
**卸载时共享文件无条件保留**（旧的"仅在漂移时保留"会在**未改动**时把它们删掉——那正是 2026-09-26
那次丢配置的同一类）；旧清单里记了共享文件摘要的条目**重新归类**而非报 drift ⇒ **不用重装即转绿**。
Obsidian 那半个（模板 `postureDigestsOf`）不能 import，过滤来自构建期注入的契约。

**门禁**：`check-profile-contract.mjs` 新增 `PINNED-7`（此前**两个写入方没有任何守卫比对**）——
它把模板那个函数**从 `main.js` 里取出来真求值**，拿同一份临时 profile 与 CLI 实现逐文件比对摘要，
不比对源码文本（那只能钉住写法）。`test-installer` 相应重写：硬基线只数安装器私有文件、
自变异受害者由 `cordis.patch.yml` 换成 `hook-frontmatter.mjs`（否则那条断言在拆分后**变成不可能失败**，
正是坑 68/81 的形状），并新增"共享文件在**未改动**时也必须活过卸载"的夹具。
**变异验证 3 条**（均实测报红 + 恢复后字节级一致）：CLI 侧漏过滤 ⇒ `PINNED-7b/7c` 红
（`bootstrap=10 cli=13`）；模板侧漏过滤（重建 `main.js` 后）⇒ 同样红（`bootstrap=13 cli=10`）；
卸载丢掉共享跳过 ⇒ "kept 0/3" 红。**结果**：`test: agent preset mounts` 由 **23/24 → 24/24**，
且**没有碰用户真实的 profile**（`$DSH_HOME/profiles/notes-assistant` 一字节未改）。

### 三、已死的 `agent-presets` 行不再静默丢失默认 preset（陷阱 108 同族，但独立）

0.2.0 里 `- id: agent-presets` **全库零命中**（逐包 grep），`includeUserRoot` 同样。
而 patch 行的 id 匹配不到任何行时 dsh **只 warn 并跳过** ⇒ 老版本插件装过的 profile 会静默失去
"默认 preset = notes-assistant"。`ensurePresetDeclaration()` 只认自己那段 `BEGIN/END` 块，**不会**迁移它。

**做法**：新增 `migrateRetiredPresetRow()` 并在 `ensurePresetDeclaration()` 里调用。判据刻意收窄（它改的是用户文件）：
只认**顶层**序列项、id **恰好** `agent-presets`（`agent-presets-*` 不碰）；丢掉 `includeUserRoot`；
其余内容与**行尾**逐字节保留；**幂等**。
**门禁**：`test-installer` 新增 9 条，含**调用点**两条（覆盖"有/没有生成块"两个分支）——
只测 helper 的话，未来重构把调用删掉仍会全绿。**变异验证**：把调用换成 `const migrated = false;` ⇒ 两条调用点断言红。

**踩到的自己的坑（记为陷阱 111）**：第一版用 `/…(\r?\n)?$/` 去匹配**仍带 `\n` 的行**。
JS 里 `$` 在**没有 `m` 标志**时也会匹配"尾随换行之前"的位置 ⇒ `(\r?\n)?` 组可以不被消费，
`replace` 于是**悄悄吞掉行尾**。实测症状：断言 detail 打印 `renamed`（函数确实改了文件），
但行数从 14 变 12（**该少 1 行却少了 2 行**）。修法：**在剥掉终止符的行体上匹配**。

### 四、宿主新增风险（记录，不改）

1. **`$DSH_HOME/cordis.patch.yml`（home 层）在 0.2.0 里压过 profile 自己的层**（陷阱 109）。
   本机 home 层只有一条 `- insert:` 的 `pretooluse-guard` 行，**当前无冲突**；但若用户在 home 层写与插件同 id 的
   `permission`/`approval`/`sandbox-policy`/`fs-sandbox` 行，那些行会被**静默覆盖**。属产品决策，已记 §7。
2. **配置编辑器现在会拒绝**保存被 home patch 覆盖的行（`dsh-config-editor/lib/index.js:122`）——
   它**堵住了**上一轮列的 C1（把 Obsidian 开关搬到插件 `Config`），C1 本就未拍板，现在多一条反对理由。
3. **`dsh-base` 的 approval 默认值反了**（`:248` 是 `danger-full-access ? 'never' : 'ask'`，插件的 profile 层给的是相反映射）。
   插件层赢，且启动检查（`dsh-permission-presets/lib/index.js:178-181`）目前由 `defaultPreset: math-memory-locked` 保证通过；
   **改安全配置不属于"顺手做"**，只记录：若哪天去掉 `defaultPreset`，这条会红。
4. **版本范围不许"顺手整理"**（陷阱 112）：`>=0.2.0` / `^0.2.0` 在 **prerelease** 运行时上**不匹配**，
   dsh 会把 bundle 层**静默跳过**（**exit 0**，只有一行 stderr）。隔离 `DSH_HOME` 实测：
   `>=0.2.0` ✗、`^0.2.0` ✗、`>=0.2.0-rc.2` ✓、`>=0.1.7-rc.2` ✓；**不声明 `peerDependencies` 整个 key ⇒ 完全不检查**。
   另记：兼容门禁的失败信号是 **stderr + 组合结果被掏空**，**不是**非零退出（只有 `--dump-config-schema` 会 exit 1），
   且真实启动时还有**第二道更严的按行门禁**（`dsh: disabling profile plugin row …`）——`--dump-config` 看不到它。

### 五、版本声明与"明确不改"

**用户拍板**：版本下限**保持 `>=0.1.7-rc.2`**（`dsh.engines.dsh` 与 `peerDependencies` 两处一致，
由 `check-version-consistency.mjs` 钉住），在两个 README 的宿主要求行后**写明"0.2.0-rc.2 已实测"**。
理由：0.2.0-rc.2 上没发现破坏 ⇒ 收紧下限会把还能用的 0.1.7-rc.2 用户挡在门外。
README 的宿主要求**锚在 `package.json` 的 peer 范围上**（`check-doc-consistency.mjs:148-169`，派生而非字面量），
所以改范围必须同时改 README；`check-readme-pair.mjs --write` 已重录。

**明确不改**（防止过度适配）：`ctx.fs.readText` **没有被 `readBytes` 取代**——两者在
`dsh-fs/lib/types/index.d.ts:162` 与 `:183` 区段**并列声明**（上一轮列为【待取证】，本轮确证）；
`session.log` 仍是真实运行时字段（`dsh-session/lib/index.js:1249`），`.messages` 不存在（原有的良性 fallback）；
`snapshotEvents`/`eventAt`/`ownEvents` 仍未使用；`!!js` patch 方言未变（且 0.2.0 **没有** `remove:` 操作，插件不用它）；
会话仍是 V4（本机 26/26 `session.v4.jsonl.zstd`）。

### 六、同批：lemmalog 评估 —— **不引入**

`JordyZomer/lemmalog` 是真实的（Rust、MIT、326 stars、双时态 Datalog、半朴素增量、`why()` 证明树、MCP 服务），
但它是 **fit failure 而非质量问题**：四个彼此独立的阻断项（要新增一层记忆 / 打破"vault = 唯一持久化、纯 Markdown" /
三条安装通道没有一条能交付 `cargo build` 产物 / 主用法是 MCP 而 preset 刻意不挂那个面），
每条在本仓库都有**书面决定**。它许诺的两个好处也已被覆盖或**有意拒绝**
（传递式级联 `design.md:130` 拒绝；来源链已设计为纯 JS 的 V0–V9 计划；图检索实测 **flat > graph**）。
详见 [`lemmalog-assessment-2026-10-01.md`](lemmalog-assessment-2026-10-01.md)。**决策已登记进 `handoff.md` §5。**

### 七、本轮**不属于**本轮的一条红（分类而非"修"）

`check: doc constants` 曾报 `docs/literature.md claims 30 papers, but literature/.raw holds 34 directories`。
取证：`literature/.raw` 下多了 4 个目录（mtime `2026-10-01 13:22`），卡片/研读笔记/`index.md`/`.index.json`/`library.bib`
都已生成 ⇒ **是另一次文献导入的产物**，与本插件、与 0.2.0 无关；而该文件的计数是一串相互关联的数字（30/27/26），
只改一个会更糊涂。**按 `AGENTS.md` §4 的纪律不去改断言掩盖**。⇒ 随后该次导入的负责人**自己**把
`docs/literature.md` 更新成 34/31，门禁自行转绿。**这正是"先分类再动手"该有的结果。**


