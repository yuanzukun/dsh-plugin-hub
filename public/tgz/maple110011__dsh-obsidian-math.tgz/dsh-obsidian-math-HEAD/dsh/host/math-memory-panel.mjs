// dsh/host/math-memory-panel.mjs — host-plane memory management panel routes.
// injects webServer and serves /memory-panel/* (loopback-only, workspace-gated)
// by reusing the pure functions in ./memory-admin.mjs. The browser client half
// (Phase 2b) will consume these routes from a dsh web settings-section panel.

import { readFileSync } from "node:fs";
import { resolve, join } from "node:path";
import { homedir } from "node:os";
import { fileURLToPath } from "node:url";
import { timingSafeEqual } from "node:crypto";
import { pathInside, collectMemoryState, applyFeedback, archiveMemoryFile, setCapturePolicyMode, archiveOldEpisodes, runSessionCapture, countUncapturedSessions, readCaptureState, setSessionCapture, readSessionCaptureEnabled, setMemoryBudget, setMemoryConfigFlag } from "./memory-admin.mjs";
import { parseHookFrontmatter } from "./hook-frontmatter.mjs";

export const name = "math-memory-panel";
export const inject = ["webServer", "workspaceRegistry"];

const json = (res, envelope, status = 200) => {
  res.writeHead(status, { "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(envelope));
};
const ok = (value) => ({ ok: true, ...(value ?? {}) });
const fail = (error) => ({ ok: false, error });

const loopbackOnly = (req) => {
  const a = req.socket?.remoteAddress ?? "";
  return a === "127.0.0.1" || a === "::1" || a === "::ffff:127.0.0.1";
};

/** Hosts a same-origin browser request legitimately carries in `Origin`. */
const loopbackHost = (host) => /^(?:127\.0\.0\.1|localhost|\[::1\])(?::\d+)?$/i.test(String(host));

/**
 * Reject a mutating request whose `Origin` is a foreign site.
 *
 * A browser always attaches `Origin` to POST (cross-site or not), so this is
 * the check that stops the attack loopback alone does not: any web page the
 * user visits can POST here with `content-type: text/plain` — a CORS "simple
 * request", so no preflight is issued and no readable response is needed for
 * the side effect to land. The 2026-09-10 audit confirmed that such a request
 * (no token, caller-chosen root) moved a user note into `.deepseek/archive/`.
 *
 * A missing `Origin` is allowed: non-browser clients (curl, a local script, the
 * plugin) do not send one, and they are already inside the trust boundary this
 * route can meaningfully defend — the root confinement below is what limits
 * them. `Origin: null` (sandboxed iframe / local file) is NOT allowed.
 */
const originAllowed = (req) => {
  const origin = req.headers?.origin;
  if (origin === undefined) return true;
  try {
    return loopbackHost(new URL(String(origin)).host);
  } catch {
    return false;
  }
};

/**
 * Optional shared secret, read from the environment the launching plugin
 * controls — the same variable `dsh/preset/math-memory.mjs` renders into the
 * feedback links.
 *
 * **Both names are accepted, new one first** (`DSH_MATH_MEMORY_FEEDBACK_TOKEN`,
 * falling back to the legacy `DSH_OBSIDIAN_FEEDBACK_TOKEN`). Until 2026-09-11
 * this function read ONLY the legacy name while the preset preferred the new
 * one, so the rename was half-done: whatever the plugin injected, one of the two
 * sides could not see it. Reading the pair the same way on both sides makes the
 * preference order irrelevant, which is the point — see `docs/env-vars.md`.
 *
 * The plugin sets it for the notes profile it spawns, so that instance also
 * requires it on every request. The user's own `web` profile usually has it
 * unset, so there the Origin + root-confinement pair carries the request. When
 * it IS set, a missing/incorrect token is fatal — that is the stronger mode.
 */
function panelToken() {
  return (process.env.DSH_MATH_MEMORY_FEEDBACK_TOKEN ?? process.env.DSH_OBSIDIAN_FEEDBACK_TOKEN ?? "").trim();
}

/** Timing-safe comparison of the request token against the configured one. */
function tokenMatches(req, url, body) {
  const expected = panelToken();
  if (expected === "") return true; // not configured on this instance
  const header = req.headers?.["x-dsh-token"];
  const supplied = (typeof header === "string" && header !== "" ? header : (url.searchParams.get("t") ?? "")) ||
    (typeof body?.token === "string" ? body.token : "");
  const a = Buffer.from(String(supplied), "utf8");
  const b = Buffer.from(expected, "utf8");
  return a.length === b.length && a.length > 0 && timingSafeEqual(a, b);
}

/**
 * The one root this server will act on: the vault the profile was started for.
 *
 * `body.root` / `?root=` used to BE the confinement root, which made the
 * downstream `pathInside(root, target)` check vacuous — the caller chose both
 * ends. A first fix made the ENV value win, but only while it was set: with
 * neither `DSH_WORKSPACE_ROOT` nor `DSH_OBSIDIAN_VAULT` configured, the
 * request's own root silently became the confinement root again, and the route
 * suite never exercised that branch because every check set one of the two
 * (reproduced by the 2026-09-11 maintainability review: a POST archived a card
 * out of a caller-named vault).
 *
 * The anchor is therefore never the request. It is this instance's own state:
 * the configured env value AND the workspaces the instance has registered. A
 * request may only *restate* one of those (the panel sends the workspace it
 * displays); anything else is refused, and an instance with neither source
 * refuses every rooted request rather than trusting the caller.
 *
 * @param requested the `root` the request restates (may be absent)
 * @param registryRoots workspace paths from `ctx.workspaceRegistry`
 * @returns the resolved root, or "" when the request does not name an allowed one
 */
function resolveAllowedRoot(requested, registryRoots) {
  const configured = (process.env.DSH_WORKSPACE_ROOT ?? process.env.DSH_OBSIDIAN_VAULT ?? "").trim();
  const configuredRoot = configured === "" ? "" : resolve(configured);
  const allowed = new Set();
  if (configuredRoot !== "") allowed.add(configuredRoot);
  for (const path of registryRoots) {
    if (typeof path === "string" && path.trim() !== "") allowed.add(resolve(path));
  }
  const asked = typeof requested === "string" ? requested.trim() : "";
  if (asked === "") {
    // A configured instance keeps answering bare requests (the panel fetches
    // `/state` etc. without restating the root). A registry-only instance
    // answers only when its registry names exactly one workspace.
    if (configuredRoot !== "") return configuredRoot;
    return allowed.size === 1 ? [...allowed][0] : "";
  }
  const resolved = resolve(asked);
  return allowed.has(resolved) ? resolved : "";
}

async function readJson(req) {
  let raw = "";
  for await (const chunk of req) raw += chunk;
  if (raw === "") return {};
  try { return JSON.parse(raw); } catch { return null; }
}

const CAPTURE_POLICY_FALLBACK = [
  "---",
  "idea: ask",
  "fact: ask",
  "preference: ask",
  "structure: auto",
  "updated: 2026-09-02",
  "---",
  "",
  "# 捕获策略",
  ""
].join("\n");

/**
 * Minimal scaffold used when `.deepseek/config.md` has to be CREATED and the real
 * template cannot be reached (see configScaffold below).
 *
 * ⚠️ Its frontmatter must stay equal — same keys, same order, same values — to the
 * one in `dsh/templates/config.md`. Both the plugin's settings page and this panel
 * perform the same "create the file when absent" operation, and they used to
 * disagree: the panel wrote `autoArchive: false` (and no `captureSubagents`) while
 * the template wrote `autoArchive: true`, so what a vault ended up with depended on
 * which UI you touched first. `scripts/check-config-scaffold.mjs` pins them
 * together; do not edit this literal alone.
 */
export const CONFIG_FALLBACK = [
  "---",
  "enabled: true",
  "dialogueIndex: true",
  "reminders: true",
  "audit: true",
  "autoArchive: true",
  "sessionCapture: false",
  "captureSubagents: false",
  "budget: standard",
  "---",
  "",
  "# 记忆系统设置（本工作区）",
  ""
].join("\n");

/**
 * The scaffold to create `.deepseek/config.md` from: the REAL vault template when
 * this file can see it, else `CONFIG_FALLBACK`.
 *
 * WHY both paths. The template is the authoritative scaffold (it carries the field
 * documentation the user reads), and it is byte-available whenever this module runs
 * out of the installed package (`dsh-math-memory/dsh/host/…` → `../templates/…`) —
 * the npm/bundle channel. The offline (`--direct` / Obsidian) channel stages this
 * file into the profile directory, where no `templates/` sibling exists, so there we
 * fall back to the literal — which `check-config-scaffold.mjs` keeps pinned to the
 * template's frontmatter. Reaching for the file first means the two channels cannot
 * drift in the common case; the gate covers the fallback.
 */
export function configScaffold() {
  try {
    return readFileSync(fileURLToPath(new URL("../templates/config.md", import.meta.url)), "utf8");
  } catch {
    return CONFIG_FALLBACK;
  }
}

/**
 * The session-log store the capture routes scan.
 *
 * `DSH_SESSIONS_ROOT` must win over the `$DSH_HOME/sessions` default, because
 * that is exactly what `dsh/preset/math-memory.mjs` does
 * (`normalizeConfig`: `process.env.DSH_SESSIONS_ROOT ?? config.sessionsRoot`)
 * and what the Obsidian plugin sets when it spawns this service. Reading the
 * default unconditionally here made the two halves of the same feature disagree
 * about which store to scan: the preset would index one directory while the
 * panel's "N 个会话未保存" badge and its 「立即保存对话」 button read another.
 *
 * NOTE: the harness's own persistence plugin does NOT read this variable — the
 * session store root there is the `session-persistence-jsonl` `config.root`
 * (default `dshHomePath('sessions')`, see dsh-base/cordis.patch.yml). So today
 * this only steers the memory feature, not the session list. See
 * docs/session-scope.md.
 */
function sessionsRoot() {
  const override = (process.env.DSH_SESSIONS_ROOT ?? "").trim();
  if (override !== "") return resolve(override);
  return join(process.env.DSH_HOME ?? join(homedir(), ".dsh"), "sessions");
}

// A route that answers a non-200 keeps the status with its envelope; everything else is a plain
// `{ ok, … }` and answers 200. Declared BEFORE the table: the table's handlers close over them.
const badRequest = (error) => ({ __status: 400, __envelope: fail(error) });
const forbidden = (error) => ({ __status: 403, __envelope: fail(error) });

/**
 * Every route this panel serves, as DATA — the runtime authority for "which paths exist".
 *
 * WHY IT IS DATA (2026-10-15, coupling assessment §3 C2 / §4 P2). This used to be an
 * `if (method === … && pathname === …) return …` chain, i.e. a second hand-written statement of the
 * route set — the first one being `PANEL_ROUTES` in `dsh/preset/profile-contract.mjs`. The gate
 * `check-profile-contract.mjs` could only compare the two with a regex over this file's source, so
 * nobody could tell whether the contract was the authority or just a pinned copy. It was the copy:
 * `PANEL_ROUTES` had zero runtime readers.
 *
 * Now the panel is the authority for the PATH STRINGS and the gate reads this export, so the two
 * cannot disagree silently. `check-profile-contract.mjs` asserts the contract's list equals the keys
 * of this table.
 *
 * ORDER IS LOAD-BEARING — the same order the if-chain had:
 *   · `root: false` routes are served BEFORE the root-confirmation gate below. `/workspaces` serves
 *     the registry, not the vault, and the client half fetches it WITHOUT a `root`; requiring one
 *     answered 400 and left the workspace dropdown permanently empty.
 *   · every other route requires a resolved root and is gated.
 * The single `root: false` entry must therefore stay FIRST; the runtime assertion below enforces
 * that shape so a future edit cannot silently move the gate.
 *
 * `handler({ root, url, body })` returns the envelope `{ ok, … }`; the dispatcher serializes it.
 * A route that must answer a non-200 status returns `{ __status, __envelope }` instead (see
 * `/feedback`: bad `rel`/`action` is a 400, and a failing `applyFeedback` is a 400 too).
 */
export const PANEL_ROUTE_TABLE = {
  "/memory-panel/workspaces": {
    methods: ["GET"],
    root: false,
    handler: ({ ctx }) => ok({
      workspaces: (ctx.workspaceRegistry?.list?.() ?? []).map((w) => ({ id: w.id, path: w.path, title: w.title }))
    })
  },
  "/memory-panel/state": {
    methods: ["GET"],
    root: true,
    handler: ({ root, url }) => ok({ state: collectMemoryState(root, url.searchParams.get("q") ?? "", parseHookFrontmatter) })
  },
  "/memory-panel/feedback": {
    methods: ["POST"],
    root: true,
    handler: ({ root, body }) => {
      if (typeof body.rel !== "string" || typeof body.action !== "string") return badRequest("rel/action required");
      const target = join(root, body.rel);
      if (!pathInside(root, target)) return forbidden("outside root");
      return ok(applyFeedback(target, body.action, root));
    }
  },
  "/memory-panel/archive": {
    methods: ["POST"],
    root: true,
    handler: ({ root, body }) => {
      if (typeof body.rel !== "string") return badRequest("rel required");
      const parts = body.rel.split("/").filter(Boolean);
      // archiveMemoryFile re-validates the source (memory tree, .md, regular
      // file) and throws otherwise; the throw surfaces as a 500 below.
      return ok({ archived: archiveMemoryFile(root, parts) });
    }
  },
  "/memory-panel/capture-policy": {
    methods: ["POST"],
    root: true,
    handler: ({ root, body }) => {
      if (typeof body.field !== "string" || typeof body.mode !== "string") return badRequest("field/mode required");
      // `field` reaches setTopField's `new RegExp("^" + field + ":")`, so a
      // metacharacter or an embedded newline can rewrite unrelated lines.
      if (!/^[A-Za-z_][A-Za-z0-9_-]{0,63}$/.test(body.field)) return badRequest("invalid field");
      if (!/^[a-z]{2,16}$/.test(body.mode)) return badRequest("invalid mode");
      setCapturePolicyMode(root, body.field, body.mode, CAPTURE_POLICY_FALLBACK);
      return ok({});
    }
  },
  "/memory-panel/archive-episodes": {
    methods: ["POST"],
    root: true,
    handler: ({ root, body }) => ok(archiveOldEpisodes(root, Number.isFinite(body.maxDays) ? body.maxDays : 90))
  },
  // One path, two methods: GET reports the capture state, POST runs a capture pass.
  "/memory-panel/session-capture": {
    methods: ["GET", "POST"],
    root: true,
    handler: ({ root, method }) => (method === "GET"
      ? (() => {
          const state = readCaptureState(root);
          return ok({
            count: countUncapturedSessions(root, sessionsRoot()),
            captured: Object.keys(state.sessions ?? {}).length,
            enabled: readSessionCaptureEnabled(root)
          });
        })()
      : ok(runSessionCapture(root, sessionsRoot(), readCaptureState(root))))
  },
  "/memory-panel/session-capture-toggle": {
    methods: ["POST"],
    root: true,
    handler: ({ root, body }) => {
      if (typeof body.enabled !== "boolean") return badRequest("enabled required");
      setSessionCapture(root, body.enabled, configScaffold());
      return ok({ enabled: body.enabled });
    }
  },
  // D2 (2026-09-26): the Obsidian settings page used to write these IN PROCESS. Writes now go
  // through the same guarded routes the panel uses (loopback + Origin + token + the server-anchored
  // `root` above), so there is one write path with one trust boundary instead of two.
  //
  // `field` is NOT interpolated and not trusted: `setMemoryConfigFlag` matches it against an
  // allowlist before it can reach `setTopField`'s RegExp, and a refusal becomes a 400.
  "/memory-panel/config-flag": {
    methods: ["POST"],
    root: true,
    handler: ({ root, body }) => {
      if (typeof body.field !== "string" || typeof body.enabled !== "boolean") return badRequest("field/enabled required");
      try {
        setMemoryConfigFlag(root, body.field, body.enabled, configScaffold());
      } catch (error) {
        return badRequest(String(error?.message ?? error));
      }
      return ok({ field: body.field, enabled: body.enabled });
    }
  },
  "/memory-panel/injection-budget": {
    methods: ["POST"],
    root: true,
    handler: ({ root, body }) => {
      if (typeof body.tier !== "string") return badRequest("tier required");
      if (!["compact", "standard", "rich"].includes(body.tier)) return badRequest("invalid tier");
      setMemoryBudget(root, body.tier, configScaffold());
      return ok({ tier: body.tier });
    }
  }
};

export function apply(ctx) {
  const noRootRoutes = Object.entries(PANEL_ROUTE_TABLE).filter(([, spec]) => spec.root === false);
  // The root-confirmation gate is the trust boundary: it must run after the registry route and
  // before every vault route. Assert the shape instead of trusting future edits (the same class of
  // slip as a `root` fallback to the caller-supplied value, which this repo has a trap for).
  if (noRootRoutes.length !== 1 || Object.values(PANEL_ROUTE_TABLE)[0].root !== false) {
    throw new Error("math-memory-panel: PANEL_ROUTE_TABLE must declare exactly one `root: false` route, first");
  }
  const noRootPath = noRootRoutes[0][0];

  const handler = async (req, res) => {
    if (!loopbackOnly(req)) return json(res, fail("forbidden: loopback-only"), 403);
    if (!originAllowed(req)) return json(res, fail("forbidden: cross-origin"), 403);
    const url = new URL(req.url ?? "/", "http://127.0.0.1");
    const pathname = url.pathname;
    const body = req.method === "POST" ? await readJson(req) : {};
    if (body === null) return json(res, fail("malformed json"), 400);
    if (!tokenMatches(req, url, body)) return json(res, fail("forbidden: bad or missing token"), 403);
    const requestedRoot = typeof body.root === "string" && body.root !== "" ? body.root : url.searchParams.get("root");
    const registryRoots = (ctx.workspaceRegistry?.list?.() ?? []).map((w) => w?.path);
    const root = resolveAllowedRoot(requestedRoot, registryRoots);

    try {
      // Listed BEFORE the root gate: it serves the registry, not the vault, and
      // the client panel fetches it with no `root` — requiring one here answered
      // 400 and left the workspace dropdown permanently empty.
      if (req.method === "GET" && pathname === noRootPath) {
        return json(res, PANEL_ROUTE_TABLE[noRootPath].handler({ ctx, root, url, body, method: req.method }));
      }
      if (root === "") {
        return json(res, fail(requestedRoot === undefined || requestedRoot === null ? "missing root" : "root not allowed"), requestedRoot === undefined || requestedRoot === null ? 400 : 403);
      }
      const spec = PANEL_ROUTE_TABLE[pathname];
      if (spec !== undefined && spec.methods.includes(req.method)) {
        const envelope = spec.handler({ ctx, root, url, body, method: req.method });
        if (envelope?.__status !== undefined) return json(res, envelope.__envelope, envelope.__status);
        return json(res, envelope);
      }
      return json(res, fail("not found"), 404);
    } catch (error) {
      ctx.logger?.warn?.("math-memory-panel: " + String(error));
      return json(res, fail(String(error)), 500);
    }
  };

  ctx.effect(() => ctx.webServer.register({ kind: "prefix", path: "/memory-panel", handler }), "math-memory-panel: /memory-panel routes");
}
