/**
 * note-tools — dedicated Obsidian note tools for the `obsidian` dsh agent
 * preset:
 *   - note_recall    unified BM25-ranked recall over notes + memory layers
 *                    (retrieval v3 primary entry; hook-field weighting, CJK
 *                    char containment, success-rate prior, coverage weak-signal
 *                    indicator; hit stats land in .deepseek/cache/retrieval-stats.json).
 *                    Also the tag-only enumeration mode: omit `query` and pass
 *                    `tag` to list user notes carrying that tag by `updated` desc.
 *                    This absorbed the retired `note_search` (retrieval-v3.md §5.1):
 *                    the vault has ONE content-discovery entry, not three.
 *   - note_create    create a new note; refuses to overwrite an existing one
 *   - note_links     backlink (wikilink) queries
 *
 * Registered through `defineTool` from @deepseek-ai/dsh-tools, following the
 * same pattern as the dsh-obsidian-assistant reference plugin. Every touch of
 * a USER NOTE goes through the harness `ctx.fs` service so the profile's
 * workspace-write sandbox and fail-closed approval stay authoritative. The
 * only raw Node fs usage below is the plugin-owned retrieval-stats cache
 * under .deepseek/cache/ (the same convention as math-memory.mjs).
 */
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, isAbsolute, join, resolve } from "node:path";
import { parseHookFrontmatter, stripFrontmatter } from "./hook-frontmatter.mjs";

export const name = "note-tools";
export const inject = ["tools", "fs", "systemPrompt", "loader"];

/**
 * Load `defineTool` without a static bare import. A local agent-preset plugin
 * lives under `$DSH_HOME/.agent-presets/notes-assistant/`, where Node's ordinary ESM
 * resolution cannot see the harness's `node_modules`; static
 * `import "@deepseek-ai/dsh-tools"` would fail for almost every user. The
 * harness loader resolves bare specifiers from the host composition instead
 * (the same mechanism preset rows like `@deepseek-ai/dsh-tool-fs` use), so we
 * ask it for the module once at apply time.
 */
async function loadDefineTool(ctx) {
  const internal = ctx.loader?.internal;
  if (typeof internal?.import === "function") {
    // The profile directory is the correct resolution anchor: app-boot heals
    // `$DSH_HOME/profiles/node_modules` with links to every dsh package, while
    // `ctx.loader.ctx.baseUrl` points at the preset directory and cannot see
    // `@deepseek-ai/dsh-tools`.
    const base = ctx.root?.baseUrl ?? ctx.loader?.ctx?.baseUrl ?? ctx.baseUrl;
    if (base === undefined) {
      throw new Error("note-tools: cannot resolve the harness module base (ctx.root.baseUrl is unset)");
    }
    const module = await internal.import("@deepseek-ai/dsh-tools", base, {});
    if (typeof module.defineTool !== "function") {
      throw new Error("note-tools: @deepseek-ai/dsh-tools did not export defineTool");
    }
    return module.defineTool;
  }
  // Bare-Node fallback (smoke tests): normal resolution from this file.
  const module = await import("@deepseek-ai/dsh-tools");
  if (typeof module.defineTool !== "function") {
    throw new Error("note-tools: @deepseek-ai/dsh-tools did not export defineTool");
  }
  return module.defineTool;
}

const DEFAULT_MAX_RESULTS = 50;
const HARD_MAX_RESULTS = 200;
const DEFAULT_MAX_NOTE_BYTES = 1024 * 1024;
const DEFAULT_EXCLUDE_PATTERNS = [".obsidian", ".trash", ".git", "node_modules"];

/**
 * The marker the vault protocol already REQUIRES for AI-written passages
 * (`dsh/templates/vault-AGENTS.md` §2.2: "补细节：补证明/例子/定义，标注
 * `<!-- AI 补全 -->`"), and which the retrieval layer used to ignore completely.
 *
 * WHY retrieval has to know (N-a, 2026-10-01): a mixed note — the user's own prose with
 * the agent's completed proof/definition in the middle — is exactly the case where
 * "this file is the user's note" stops being true, and the file-level `origin` field of
 * memory cards cannot express it (one field cannot describe段落 in a file the user also
 * writes). Measured on the real vault before this change: one note carried
 * `> <!-- AI 补全 -->` and the retrieval result showed no trace of it, so the agent's
 * completion was returned on equal footing with the user's own words. The marker is
 * mechanical and authored by whoever wrote the passage, so reading it needs no model and
 * no heuristic — trying to DETECT unmarked completions would be a semantic judgement,
 * which the plugin does not do (and which would cry wolf).
 *
 * ONE alternation for both spellings: the comment form first, so a literal
 * `<!-- AI 补全 -->` counts once rather than twice, while a bare `AI 补全` (the marker
 * vocabulary the audit already knew, `AUDIT_OPEN_MARKERS`) is still recognised.
 */
const AI_COMPLETION_MARKER = /<!--\s*AI\s*补全\s*-->|AI\s*补全/g;

/** How many AI-completion markers a note's BODY carries (0 for non-notes). */
export function aiCompletionCount(body) {
  const text = String(body ?? "");
  if (text === "") return 0;
  return text.match(AI_COMPLETION_MARKER)?.length ?? 0;
}

/**
 * How many open/uncertain markers a note's body carries (`待核对`/`待补`/`待证明`/`存疑`).
 *
 * The SAME vocabulary the audit already used for its "unfinished business" scan and for
 * the index-contradiction check — read here so retrieval can surface it too. Counted on
 * the BODY, where those markers live (the audit's own gap scan does the same).
 *
 * WHY retrieval needs it (2026-10-01, the user's real complaint): "每次讨论相关问题时助手的
 * 回复都差不多" — the answer keeps getting pulled toward one note. Measured on the real
 * vault: that note came back at rank 1-2 for **every** related query (score up to 0.93),
 * and it declares at its own top that it is AI-drafted with two unverified conclusions.
 * The model was reciting it as settled knowledge. The card layers already have this
 * defence (`inbox/` injects as 待打磨, records as settled); a user's OWN note had neither,
 * so the single most influential document in the vault carried no provisional marking.
 */
export function openMarkerCount(body) {
  const text = String(body ?? "");
  if (text === "") return 0;
  return text.match(/待核对|待补|待证明|存疑/g)?.length ?? 0;
}

/**
 * The provisional bracket a snippet carries, or `""` when the document claims nothing
 * provisional. Merged into ONE bracket on purpose: both counts say the same thing to a
 * reader ("do not take this as settled"), and two stacked prefixes cost the snippet window
 * twice for one verdict.
 */
function provisionalLabel(doc) {
  const marks = [];
  if (doc?.aiCompletions > 0) marks.push(`AI 补全 ×${doc.aiCompletions}`);
  if (doc?.openMarkers > 0) marks.push(`待核对 ×${doc.openMarkers}`);
  return marks.length === 0 ? "" : `［${marks.join("·")}·不宜当结论］ `;
}

function positiveInteger(value, fallback, label) {
  const number = Number(value ?? fallback);
  if (!Number.isInteger(number) || number < 1) {
    throw new Error(`note-tools: ${label} must be a positive integer`);
  }
  return number;
}

function normalizeConfig(config) {
  const raw = config ?? {};
  return {
    vaultRoot: typeof raw.vaultRoot === "string" ? raw.vaultRoot.trim() : "",
    maxSearchResults: positiveInteger(raw.maxSearchResults, DEFAULT_MAX_RESULTS, "maxSearchResults"),
    maxNoteBytes: positiveInteger(raw.maxNoteBytes, DEFAULT_MAX_NOTE_BYTES, "maxNoteBytes"),
    excludePatterns: Array.isArray(raw.excludePatterns)
      ? raw.excludePatterns.filter((pattern) => typeof pattern === "string" && pattern.trim() !== "").map((pattern) => pattern.trim())
      : DEFAULT_EXCLUDE_PATTERNS
  };
}

// ── vault resolution ────────────────────────────────────────────────────────

/**
 * Single source of truth for resolving the workspace/vault root that both the
 * memory engine (math-memory.mjs) and these note tools act on. Priority
 * (most explicit wins): preset config vaultRoot → DSH_OBSIDIAN_VAULT env →
 * session cwd. Empty means "not determinable" (the caller decides whether that
 * is an error); a relative path is treated as unusable (must be absolute).
 */
export function resolveWorkspaceRoot(configVaultRoot, envVault, sessionCwd) {
  const pick = (value) => (typeof value === "string" && value.trim() !== "" ? value.trim() : "");
  const raw = pick(configVaultRoot) || pick(envVault) || pick(sessionCwd);
  if (raw === "" || !isAbsolute(raw)) return "";
  return resolve(raw);
}

/** Resolve the vault the tools act on via resolveWorkspaceRoot. */
function vaultRootFor(exec, config) {
  const session = exec?.agent?.session;
  const cwd = typeof session?.header?.cwd === "string"
    ? session.header.cwd
    : typeof session?.cwd === "string" ? session.cwd : "";
  const root = resolveWorkspaceRoot(config.vaultRoot, process.env.DSH_WORKSPACE_ROOT ?? process.env.DSH_OBSIDIAN_VAULT, cwd);
  if (root === "") {
    throw new Error("note-tools: cannot determine the vault directory; set DSH_OBSIDIAN_VAULT or configure vaultRoot in the preset.");
  }
  return root;
}

async function resolveVault(ctx, exec, config) {
  const rootPath = vaultRootFor(exec, config);
  const rootTarget = await ctx.fs.resolve(rootPath, { signal: exec?.signal });
  const info = await ctx.fs.stat(rootTarget, exec?.signal);
  if (info === undefined) throw new Error(`note-tools: vault root not found: ${rootPath}`);
  if (info.type !== "directory") throw new Error(`note-tools: vault root is not a directory: ${rootPath}`);
  return { rootPath, rootTarget };
}

function requireInsideVault(ctx, rootTarget, target) {
  if (!ctx.fs.contains(rootTarget, target)) {
    throw new Error(`note-tools: path escapes the vault: ${target.displayPath}`);
  }
}

// ── exclusion glob (simple `*` wildcard, like the reference plugin) ──────────

function globMatch(pattern, value) {
  const pat = pattern.replace(/\\/g, "/");
  const val = value.replace(/\\/g, "/");
  if (!pat.includes("*")) return val === pat || val.startsWith(`${pat}/`);
  const expression = pat.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*");
  return new RegExp(`^${expression}$`).test(val);
}

function isExcluded(name, relDir, patterns) {
  const full = relDir === "" ? name : `${relDir}/${name}`;
  return patterns.some((pattern) => globMatch(pattern, name) || globMatch(pattern, full));
}

// ── note discovery / parsing ────────────────────────────────────────────────

async function listNotes(ctx, rootTarget, signal, excludePatterns, extraExcludeDirs = []) {
  const notes = [];
  const seenDirectories = new Set();

  async function walk(target, relDir) {
    if (seenDirectories.has(target.targetKey)) return; // symlink-cycle guard
    seenDirectories.add(target.targetKey);
    const entries = await ctx.fs.listDir(target, signal);
    for (const entry of entries) {
      if (entry.type === "directory") {
        if (isExcluded(entry.name, relDir, excludePatterns)) continue;
        if (extraExcludeDirs.includes(entry.name)) continue;
        if (!ctx.fs.contains(rootTarget, entry.target)) continue;
        await walk(entry.target, relDir === "" ? entry.name : `${relDir}/${entry.name}`);
      } else if (entry.type === "file" && entry.name.toLowerCase().endsWith(".md")) {
        if (isExcluded(entry.name, relDir, excludePatterns)) continue;
        if (!ctx.fs.contains(rootTarget, entry.target)) continue;
        const rel = relDir === "" ? entry.name : `${relDir}/${entry.name}`;
        notes.push({ path: rel, name: rel.slice(0, -3), target: entry.target });
      }
    }
  }

  await walk(rootTarget, "");
  notes.sort((a, b) => a.path.localeCompare(b.path));
  return notes;
}

/** Split leading YAML frontmatter from the note body. */
function splitFrontmatter(raw) {
  if (!raw.startsWith("---")) return { frontmatter: null, body: raw };
  const close = raw.indexOf("\n---", 3);
  if (close < 0) return { frontmatter: null, body: raw };
  const frontmatter = raw.slice(3, close).replace(/^\r?\n/, "");
  const body = raw.slice(close + 4).replace(/^\r?\n/, "");
  return { frontmatter, body };
}

// ── memory v2: feature-hook parsing (informed by arXiv:2606.31191, ISM) ─────

// The hook-block parser lives in hook-frontmatter.mjs (single source of truth,
// shared with the Obsidian plugin through the embedded-source loader).
export { parseHookFrontmatter };

// ── incremental note-text cache (memory v2 perf, D) ─────────────────────────
// note_recall / note_links previously read every .md on every call. This cache
// reuses the raw text while a file's mtime+size stay unchanged: per call the
// cost drops to a metadata stat plus reading only files that actually changed.
const NOTE_CACHE_LIMIT = 5000;
const noteReadCache = new Map(); // rootPath -> Map<relPath, {mtimeMs, size, raw}>

export function cacheEntryFresh(entry, mtimeMs, size) {
  return entry !== undefined && entry !== null && entry.mtimeMs === mtimeMs && entry.size === size;
}

async function readNoteTextCached(ctx, rootPath, note, signal) {
  let cache = noteReadCache.get(rootPath);
  if (cache === undefined) {
    cache = new Map();
    noteReadCache.set(rootPath, cache);
  }
  let info;
  try {
    info = await ctx.fs.stat(note.target, signal);
  } catch {
    return null;
  }
  if (info === undefined) return null;
  const mtimeMs = typeof info.mtimeMs === "number" ? info.mtimeMs : (info.mtime instanceof Date ? info.mtime.getTime() : 0);
  const size = typeof info.size === "number" ? info.size : -1;
  const hit = cache.get(note.path);
  if (cacheEntryFresh(hit, mtimeMs, size)) return hit.raw;
  let raw;
  try {
    raw = await ctx.fs.readText(note.target, signal);
  } catch {
    return null;
  }
  cache.set(note.path, { mtimeMs, size, raw });
  if (cache.size > NOTE_CACHE_LIMIT) noteReadCache.delete(rootPath); // rebuild lazily on a huge vault
  return raw;
}

function cleanTagToken(token) {
  return token.trim().replace(/^['"]|['"]$/g, "").replace(/^#+/, "");
}

/** Extract `tags:` from YAML-ish frontmatter (inline list, flow list, or `-` list). */
function frontmatterTags(text) {
  if (text === null) return [];
  const tags = [];
  const lines = text.split(/\r?\n/);
  let inTagList = false;
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    if (inTagList) {
      const item = /^\s+-\s+(.+)$/.exec(line);
      if (item !== null) {
        tags.push(cleanTagToken(item[1]));
        continue;
      }
      inTagList = false;
    }
    const key = /^tags:\s*(.*)$/.exec(line);
    if (key === null) continue;
    const value = key[1].trim();
    if (value === "") {
      inTagList = true;
    } else if (value.startsWith("[") && value.endsWith("]")) {
      for (const item of value.slice(1, -1).split(",")) {
        const token = cleanTagToken(item);
        if (token !== "") tags.push(token);
      }
    } else {
      for (const item of value.split(/[\s,]+/)) {
        const token = cleanTagToken(item);
        if (token !== "") tags.push(token);
      }
    }
  }
  return tags;
}

/** Extract inline `#tag` occurrences (never `# heading`). */
function inlineTags(body) {
  const tags = [];
  const expression = /(?:^|[\s([{])#([A-Za-z0-9_\-/]+)/g;
  let match;
  while ((match = expression.exec(body)) !== null) tags.push(match[1]);
  return tags;
}

function noteTags(note) {
  const seen = new Set();
  const tags = [];
  for (const raw of [...frontmatterTags(note.frontmatter), ...inlineTags(note.body)]) {
    const tag = raw.replace(/^#+/, "");
    const key = tag.toLowerCase();
    if (tag === "" || seen.has(key)) continue;
    seen.add(key);
    tags.push(tag);
  }
  return tags;
}

function normalizeTagFilter(raw) {
  return String(raw ?? "").trim().replace(/^#+/, "").toLowerCase().replace(/^\/+|\/+$/g, "");
}

function matchesTagFilter(tags, filter) {
  return tags.some((tag) => {
    const normalized = tag.toLowerCase();
    return normalized === filter || normalized.endsWith(`/${filter}`);
  });
}

function makeSnippet(haystack, index, matchLength) {
  const start = Math.max(0, index - 60);
  const end = Math.min(haystack.length, index + matchLength + 120);
  return `${start > 0 ? "…" : ""}${haystack.slice(start, end).replace(/\s+/g, " ").trim()}${end < haystack.length ? "…" : ""}`;
}

/** Wikilinks, including embeds and heading/anchor suffixes. */
function extractWikiLinks(raw) {
  const links = new Set();
  const expression = /!?\[\[([^\[\]|#]+)(?:#[^\]\[]*)?(?:\|[^\]\[]*)?\]\]/g;
  let match;
  while ((match = expression.exec(raw)) !== null) {
    const target = match[1].trim().replace(/\.md$/i, "");
    if (target !== "") links.add(target);
  }
  return [...links];
}

function normalizeNoteRelPath(input) {
  const rawInput = String(input).trim();
  if (rawInput.includes("\u0000")) throw new Error("note-tools: note path contains a NUL byte");
  if (isAbsolute(rawInput) || /^[A-Za-z]:[\\/]/.test(rawInput)) {
    throw new Error(`note-tools: note path must be vault-relative, got ${JSON.stringify(rawInput)}`);
  }
  let rel = rawInput.replace(/\\/g, "/").replace(/^\.\/+/, "");
  if (rel.startsWith("/")) rel = rel.replace(/^\/+/, "");
  if (rel === "" || rel === "." || rel.endsWith("/")) {
    throw new Error(`note-tools: invalid note path ${JSON.stringify(rawInput)}`);
  }
  const parts = rel.split("/");
  if (parts.some((part) => part === "" || part === "." || part === ".." || part.includes(":"))) {
    throw new Error(`note-tools: note path escapes the vault or is invalid: ${JSON.stringify(rawInput)}`);
  }
  if (!rel.toLowerCase().endsWith(".md")) rel += ".md";
  return rel;
}

const OVERWRITE_REFUSAL = (rel) => `note_create: note already exists (${rel}); refusing to overwrite. Read it and use edit/write only when the user explicitly asks to change the existing note.`;

// ── memory v2: two-stage strategy retrieval (ISM scoring + Dual RAG query) ──

const RECALL_DEFAULT_MAX_RESULTS = 15;
const RECALL_HARD_MAX_RESULTS = 50;

// Retrieval-v3 scoring blend (self-correction.md P1c): the hook prior is
// deliberately raised from a token 0.05 so verified/success_rate feedback
// actually moves ranking (previous effective influence was ~3%).
const RECALL_BM25_WEIGHT = 0.75;
const RECALL_CJK_WEIGHT = 0.10;
const RECALL_PRIOR_WEIGHT = 0.15;
// Multiplier applied to score for ARCHIVED material when a caller explicitly asks for
// it (`note_recall({ includeArchived: true })`). Archives exist so nothing is lost;
// they must not compete with live knowledge at equal relevance, so recovered evidence
// is demoted hard (roughly "one tier down" in the blended score) AND labelled in the
// rendered result. Zero would make the feature pointless; 1 would defeat the point.
const ARCHIVE_RECALL_WEIGHT = 0.5;

/**
 * Whether a vault doc may compete in note_recall ranking. Superseded cards and
 * cards already consolidated into another (duplicate_of) are evidence only —
 * they stay on disk for grep/read provenance but must not surface as live
 * candidates (self-correction.md P1a / P4).
 */
export function isRecallEligible(status, duplicateOf) {
  if (String(status ?? "").trim().toLowerCase() === "superseded") return false;
  if (String(duplicateOf ?? "").trim() !== "") return false;
  return true;
}

/** Known operator vocabulary (hard-filter key, stage 1). */
const HOOK_OPERATORS = new Set([
  "algebra", "number-theory", "geometry", "combinatorics", "probability",
  "analysis", "statistics", "calculus", "linear-algebra", "topology", "logic"
]);

/**
 * Retrieval-target vocabulary for strategy cards (strategy-layer.md §8).
 *
 * REMOVED 2026-09-11 — it was exported but nothing read it (`strategyRetrieve`
 * below flattens/dedupes whatever the card lists, and validates nothing), so
 * `strategy-layer.md`'s "add a value = change the constant" was a promise the
 * code did not keep: a maintainer would edit the enum, see all gates stay green,
 * and change no behaviour. Targets are free-form strings; adding one needs no
 * code change. Kept here as a comment only so the vocabulary is still discoverable.
 *
 *   similar-problem · technique · theorem · proven-path · definition · notation
 */

function normalizeOperator(raw) {
  return String(raw ?? "").trim().toLowerCase().replace(/\s+/g, "-");
}

/** ASCII words plus CJK bigrams (with the full run as a fallback token). */
export function tokenize(text) {
  const tokens = [];
  if (typeof text !== "string") return tokens;
  // Unicode dash normalization: Borel–Cantelli / Borel—Cantelli / a-b must
  // all tokenize identically to borel-cantelli, otherwise hyphen/en-dash
  // variants of the same named technique never match each other.
  const normalized = text.toLowerCase().replace(/[\u2013\u2014\u2212]/g, "-");
  for (const token of normalized.match(/[a-z0-9][a-z0-9_-]*/g) ?? []) tokens.push(token);
  for (const run of normalized.match(/[\u4e00-\u9fff]+/g) ?? []) {
    if (run.length === 1) { tokens.push(run); continue; }
    for (let i = 0; i < run.length - 1; i += 1) tokens.push(run.slice(i, i + 2));
    tokens.push(run);
  }
  return tokens;
}

function tokenFrequencies(tokens) {
  const freq = new Map();
  for (const token of tokens) freq.set(token, (freq.get(token) ?? 0) + 1);
  return freq;
}

/**
 * IDF-weighted overlap coefficient in [0,1]: how much of the query's token
 * mass is covered by the card, down-weighting tokens that appear everywhere
 * (the dependency-free stand-in for ISM's embedding similarity term).
 */
export function weightedOverlap(queryTokens, cardTokens, docFreq) {
  if (queryTokens.length === 0 || cardTokens.length === 0) return 0;
  const qFreq = tokenFrequencies(queryTokens);
  const cFreq = tokenFrequencies(cardTokens);
  const docCount = Math.max(1, docFreq.docCount);
  let matched = 0;
  let total = 0;
  for (const [token, qCount] of qFreq) {
    const df = docFreq.map.get(token) ?? 0;
    const idf = Math.log(1 + docCount / Math.max(1, df + 1));
    total += qCount * idf;
    matched += Math.min(qCount, cFreq.get(token) ?? 0) * idf;
  }
  return total === 0 ? 0 : matched / total;
}

export function computeDocFreq(tokenLists) {
  const map = new Map();
  for (const tokens of tokenLists) {
    for (const token of new Set(tokens)) map.set(token, (map.get(token) ?? 0) + 1);
  }
  return { docCount: tokenLists.length, map };
}

// ── memory v3: BM25 scorer (retrieval-v3.md S2) ──────────────────────────────

/**
 * Corpus statistics for BM25: document count, average length, term df table.
 * Independent of the overlap coefficient's { docCount, map } shape so the
 * two scorers stay interchangeable during the transition.
 */
export function computeCorpusStats(tokenizedDocs) {
  const docFreq = new Map();
  let totalLen = 0;
  for (const tokens of tokenizedDocs) {
    totalLen += tokens.length;
    for (const token of new Set(tokens)) docFreq.set(token, (docFreq.get(token) ?? 0) + 1);
  }
  return {
    docCount: tokenizedDocs.length,
    avgLen: tokenizedDocs.length > 0 ? totalLen / tokenizedDocs.length : 1,
    docFreq
  };
}

/**
 * Standard BM25 (k1=1.2, b=0.75): term-frequency saturation, inverse document
 * frequency, and document-length normalization. Strong classic lexical
 * baseline — strictly better than the overlap coefficient for ranking.
 * Query repetition is honored (each query occurrence adds its own term),
 * document repetition saturates.
 */
export function bm25Score(queryTokens, docTokens, stats, k1 = 1.2, b = 0.75) {
  if (queryTokens.length === 0 || docTokens.length === 0 || stats.docCount === 0) return 0;
  const qFreq = tokenFrequencies(queryTokens);
  const dFreq = tokenFrequencies(docTokens);
  const docLen = docTokens.length;
  const lengthNorm = 1 - b + b * (docLen / Math.max(1, stats.avgLen));
  let score = 0;
  for (const [token, qCount] of qFreq) {
    const df = stats.docFreq.get(token) ?? 0;
    if (df === 0) continue; // unseen terms carry no BM25 signal
    const tf = dFreq.get(token) ?? 0;
    if (tf === 0) continue;
    const idf = Math.log(1 + (stats.docCount - df + 0.5) / (df + 0.5));
    score += qCount * idf * (tf * (k1 + 1)) / (tf + k1 * lengthNorm);
  }
  return score;
}

/**
 * Rank documents with BM25, returning sorted [score, index] pairs (desc).
 */
export function rankBm25(queryTokens, tokenizedDocs, stats) {
  const scored = tokenizedDocs.map((docTokens, index) => ({ index, score: bm25Score(queryTokens, docTokens, stats) }));
  scored.sort((a, b) => b.score - a.score);
  return scored;
}

/**
 * Hook prior for note_recall ranking (ISM promote/demote, localized):
 * verified level + success_rate + usage frequency, mapped into [0,1].
 * Non-hook documents get the neutral 0.5 baseline; a user-confirmed, high-
 * success, frequently-used card ranks above a single-source, low-success one.
 *
 * `gain` enters with the weight taken OUT of `uses` (0.25 -> 0.15 + 0.10), so the
 * total is unchanged and the change is reversible: `uses` counts how often a card
 * was RETRIEVED, which is not the same as whether it helped (a card retrieved 20
 * times and discarded 18 times looked identical to one that solved 20 problems).
 * `gain` is the signed verdict from explicit user feedback — see `cardGain` in
 * math-memory.mjs for why it is built only from ✅/❌ and why absent means neutral.
 * A negative gain therefore demotes a card BELOW an unrated one, which is the
 * point: `harmed` used to be a one-sided counter that only ever showed up in the
 * audit report and never affected ranking.
 *
 * Robustness: `success_rate` / `uses` / `last_used` / `gain` are PLUGIN-OWNED
 * fields (docs/memory/design.md §5.1 ownership table) — the agent is forbidden to
 * write them, but they arrive here as text parsed out of a user-editable markdown
 * file, so they must be treated as untrusted input. Every term is clamped into
 * range and the result is clamped into [0,1]: a hand-edited `success_rate: 5`,
 * `uses: -3` or `gain: 99` must not be able to push a card's prior outside the
 * scale that the BM25 blend assumes. Inside the scale the formula is unchanged,
 * so existing rankings do not move.
 */
export function hookPrior(hook, updatedDate = null) {
  if (hook === null || hook === undefined) return 0.5;
  const clamp01 = (value, fallback) => {
    const n = Number(value);
    if (!Number.isFinite(n)) return fallback;
    return Math.max(0, Math.min(1, n));
  };
  const verifiedWeight = { "user-confirmed": 1, "cross-referenced": 0.75, "single-source": 0.5 };
  const verified = verifiedWeight[hook.verified] ?? 0.5;
  const success = clamp01(hook.success_rate, 0.5);
  const uses = clamp01(Number(hook.uses) / 10, 0);
  // Gain is signed; a missing value must stay neutral, not count as "good".
  const rawGain = Number(hook.gain);
  const gain = Number.isFinite(rawGain) ? Math.max(-1, Math.min(1, rawGain)) : 0;
  // Recency (Belief Memory λ^τ, generalized to records): prefer cards that
  // were updated or used recently; 90-day linear decay into [0,1].
  const date = updatedDate || hook.last_used;
  let recency = 0.5;
  if (typeof date === "string" && date !== "") {
    const t = Date.parse(date);
    if (Number.isFinite(t)) recency = Math.max(0, Math.min(1, 1 - (Date.now() - t) / (90 * 86400000)));
  }
  return clamp01(0.45 * success + 0.15 * uses + 0.10 * ((gain + 1) / 2) + 0.20 * verified + 0.10 * recency, 0.5);
}

/**
 * CJK character containment in [0,1]: how many DISTINCT Chinese characters of
 * the query appear in the doc. Bridges short-vs-long word mismatch (子列 vs
 * 子序列) that bigram tokenization cannot see; zero for non-CJK queries.
 */
/**
 * Fraction of DISTINCT query tokens covered by the doc (BM25-token level).
 * A high ranking score with low coverage is a lexical coincidence: the
 * relative max-normalization hides it, so the tool exposes this as a
 * weak-signal indicator (retrieval v3 probe finding).
 */
export function queryCoverage(queryTokens, docTokens) {
  const distinct = new Set(queryTokens);
  if (distinct.size === 0) return 1;
  const docSet = new Set(docTokens);
  let hit = 0;
  for (const token of distinct) if (docSet.has(token)) hit += 1;
  return hit / distinct.size;
}

export function cjkCharOverlap(queryText, docText) {
  const chars = (value) => {
    const set = new Set();
    for (const ch of String(value ?? "")) if (/[\u4e00-\u9fff]/.test(ch)) set.add(ch);
    return set;
  };
  const q = chars(queryText);
  if (q.size < 2) return 0; // single char is noise; require a real CJK query
  const d = chars(docText);
  let hit = 0;
  for (const ch of q) if (d.has(ch)) hit += 1;
  return hit / q.size;
}

// ── memory v3 S1: unified recall corpus (retrieval-v3.md) ───────────────────

/**
 * Score strategy cards against a challenge query.
 *
 * Shared with the QA probes: `note_strategy`'s ranking is BM25 over the card's
 * surface, multiplied by a verified-level weight (self-correction.md P5a), and
 * only positive scores are returned. Cards come from
 * {@link buildRecallDoc} filtered to `kind === "strategy"`.
 */
export function rankStrategyCards(cards, query, options = {}) {
  const { difficulty = "", limit = 3 } = options;
  const filter = difficulty === "" ? "" : normalizeOperator(difficulty);
  const queryTokens = tokenize(query);
  const kept = [];
  for (const card of cards) {
    if (card.kind !== "strategy" || card.strategy === "") continue;
    const cardDifficulty = normalizeOperator(card.difficulty ?? "");
    if (filter !== "" && cardDifficulty !== filter) continue;
    if (String(card.status ?? "").trim().toLowerCase() === "superseded") continue;
    kept.push(card);
  }
  const surfaces = kept.map((card) => card.strategy);
  const stats = computeCorpusStats(surfaces.map((surface) => tokenize(surface)));
  const verifiedWeight = { "user-confirmed": 1, "cross-referenced": 0.92, "single-source": 0.84 };
  const scored = kept
    .map((card) => ({
      card,
      score: bm25Score(queryTokens, tokenize(card.strategy), stats) * (verifiedWeight[card.hook?.verified] ?? 0.9)
    }))
    .filter((entry) => entry.score > 0)
    .sort((a, b) => b.score - a.score);

  // The strategy layer is where `not_applicable_when` originally lived, so the
  // same applicability gate applies here (docs/design-intake-2026-09-10.md §1).
  const excluded = [];
  const eligible = [];
  for (const entry of scored) {
    const hits = entry.card.boundary === "" ? [] : boundaryHits(query, entry.card.boundary);
    if (hits.length === 0) { eligible.push(entry); continue; }
    excluded.push({ card: entry.card, hits });
  }

  // ── status is a permission, not a label ───────────────────────────────────
  // `status: candidate` means the card has NOT been promoted yet (the audit
  // promotes on uses>=PROMOTE_USES and success_rate>=PROMOTE_RATE). A candidate
  // is a useful LEAD, but it must not be presented as a mandate — so it is
  // returned in its own bucket instead of mixed into `matches`.
  //
  // Only an EXPLICIT `candidate` is diverted: an absent/unknown status stays in
  // `matches`, because the daily audit already treats `meta.status ?? "active"`
  // (math-memory.mjs) as active, and silently re-classifying older hand-written
  // cards here would change what the model is allowed to rely on. Permission
  // narrows only where the vault actually declares it.
  const toMatch = ({ card, score }) => ({
    path: card.rel,
    title: card.title,
    difficulty: normalizeOperator(card.difficulty ?? ""),
    status: String(card.status ?? "").trim().toLowerCase() || "active",
    verified: card.hook?.verified ?? "single-source",
    score: Number(score.toFixed(4))
  });
  const cap = Math.min(10, Math.max(1, limit));
  const isCandidate = (entry) => String(entry.card.status ?? "").trim().toLowerCase() === "candidate";
  return {
    difficulty: filter,
    matches: eligible.filter((entry) => !isCandidate(entry)).slice(0, cap).map(toMatch),
    candidates: eligible.filter(isCandidate).slice(0, cap).map(toMatch),
    excluded: excluded.map(({ card, hits }) => ({
      path: card.rel,
      title: card.title,
      boundary: card.boundary,
      boundaryHits: hits
    }))
  };
}

/**
 * Build one recall-corpus document from a path plus its raw text.
 *
 * Part of the shared pipeline `note_recall` AND the QA probes call, so the
 * probes exercise the shipped ranking instead of re-deriving it. (They used to
 * re-implement the score formula; it silently diverged when the hook prior
 * landed — docs/project-assessment-2026-09-10.md §2 P1-4.)
 */
export function buildRecallDoc(rel, raw, options = {}) {
  const kind = classifyVaultDoc(rel, options);
  if (kind === "skip") return null;
  const { frontmatter, body } = splitFrontmatter(raw);
  const name = rel.split("/").at(-1) ?? rel;
  const hook = frontmatter === null ? null : parseHookFrontmatter(frontmatter);
  return {
    kind,
    rel,
    // Archived material, when a caller asked for it. Carried here so the ranker can
    // demote it and the renderer can LABEL it: recovered evidence must never read
    // like current knowledge.
    archived: rel.startsWith(".deepseek/archive/"),
    title: titleFromDoc(frontmatter, body, name),
    tags: kind === "note" ? noteTags({ frontmatter, body }) : [],
    topic: metaScalar(frontmatter, "topic") ?? "",
    updated: metaScalar(frontmatter, "updated") ?? "",
    hook,
    // AI-written passages the NOTE ITSELF marked (N-a). Read from the body, not the
    // frontmatter: the whole point is that authorship here is per-paragraph, and only the
    // note can say which paragraphs those are. Zero for every non-note kind — memory cards
    // carry `origin` instead (C7), and a card is agent-written by construction.
    aiCompletions: kind === "note" ? aiCompletionCount(body) : 0,
    // Open/uncertain markers the note carries (`待核对`/`待补`/…). Read for the same reason
    // as `aiCompletions` and reported through the same channel: a note that admits "this
    // part is not settled" must not arrive as a settled conclusion.
    openMarkers: kind === "note" ? openMarkerCount(body) : 0,
    strategy: kind === "strategy" ? strategySurface(frontmatter) : "",
    status: metaScalar(frontmatter, "status") ?? "",
    duplicateOf: metaScalar(frontmatter, "duplicate_of") ?? "",
    difficulty: metaScalar(frontmatter, "difficulty") ?? "",
    // Applicability boundary (R1 `anti_conditions`, see docs/design-intake-2026-09-10.md
    // §1): the conditions under which this card must NOT be applied. Read from the
    // top-level key the strategy layer already uses, or from inside the hook block.
    boundary: metaScalar(frontmatter, "not_applicable_when")
      ?? (typeof hook?.not_applicable_when === "string" ? hook.not_applicable_when : "")
      ?? "",
    rawFrontmatter: frontmatter ?? "",
    body
  };
}

/**
 * Split an applicability boundary into the SHORT phrases that make it decidable.
 *
 * A boundary is written as prose (`成本非二次（无内积化）或 μ 非绝对连续（映射形式
 * 不成立…）时，第 3-4 格需改`). Whole-text token overlap against a query is
 * uselessly small for such a string, so we keep only the short comma-separated
 * fragments — those are the discriminative ones (`非绝对连续`) — and drop the
 * long explanatory ones. Keyword-list style boundaries (`非绝对连续、成本非二次`)
 * survive this unchanged, so both spellings work.
 */
export function boundarySegments(text, maxLength = 12) {
  return String(text ?? "")
    .split(/[、，,；;。()（）\[\]【】/]|或者|或|时|时需|不要|不能/)
    .map((part) => part.replace(/\s+/g, " ").trim())
    .filter((part) => part.length >= 2 && part.length <= maxLength);
}

/** The boundary fragments the query actually mentions, in boundary order. */
export function boundaryHits(query, boundary, maxLength = 12) {
  const text = String(query ?? "").replace(/\s+/g, " ").trim();
  if (text === "") return [];
  return boundarySegments(boundary, maxLength).filter((segment) => text.includes(segment));
}

/**
 * Navigation index documents carry the *map*, not the evidence, so they are
 * demoted in the ranking. Without this the episodes index outranked the notes
 * it points at on several real queries: it lists every episode title, so it
 * matches almost any CJK query on raw character overlap alone.
 */
const KIND_CORPUS_WEIGHT = { "episode-index": 0.4, "theorem-index": 0.7 };

/**
 * The one ranking pipeline: filter → passage → BM25 → blend weights → sort.
 *
 * `note_recall` and the QA probes both call this. `docs` are
 * {@link buildRecallDoc} results; pass `passages`/`docTokens` to reuse a corpus
 * across queries.
 *
 * An EMPTY `query` with a non-empty `tag` is the **tag-only enumeration** branch:
 * relevance scoring is skipped on purpose (there is no query to be relevant to),
 * so the result is the note list carrying that tag, ordered by `updated` desc,
 * with `score: 0` and `coverage: 0`. Reporting 0 rather than a fabricated
 * similarity is the point — the renderer shows a dash for it (retrieval-v3.md §5.1).
 *
 * @returns `{ mode, operator, matches, passages, docTokens }`
 */
export function rankRecallDocuments(docs, query, options = {}) {
  const { tag = "", operator = null, limit = RECALL_DEFAULT_MAX_RESULTS, passages: givenPassages, docTokens: givenTokens, viewPool = "bag" } = options;
  const safeLimit = Math.min(Math.max(1, Number.isFinite(limit) ? Math.trunc(limit) : RECALL_DEFAULT_MAX_RESULTS), RECALL_HARD_MAX_RESULTS);
  const queryTokens = tokenize(query);

  const kept = [];
  for (const doc of docs) {
    if (tag !== "" && !matchesTagFilter(doc.tags ?? [], tag)) continue;
    if (!isRecallEligible(doc.status, doc.duplicateOf)) continue;
    kept.push(doc);
  }

  const passages = givenPassages ?? kept.map((doc) => composePassage(doc.kind, doc));
  const docTokens = givenTokens ?? passages.map((passage) => tokenize(passage));
  const docTokenSets = docTokens.map((tokens) => new Set(tokens));
  const shape = (entry, score) => ({
    path: entry.doc.rel,
    kind: entry.doc.kind,
    title: entry.doc.title,
    verified: typeof entry.doc.hook?.verified === "string" ? entry.doc.hook.verified : null,
    hookOperator: typeof entry.doc.hook?.operator === "string" ? entry.doc.hook.operator : null,
    uses: Math.max(0, Math.trunc(hookNumber(entry.doc.hook, "uses", 0))),
    successRate: Number.isFinite(Number(entry.doc.hook?.success_rate)) ? Number(entry.doc.hook.success_rate) : null,
    score,
    // The label rides on the snippet because the output schema is
    // `additionalProperties: false` on match items too: adding an `archived` field
    // would fail dsh's strict validation and kill the whole call (the 2026-09-14
    // failure). A prefix is visible to the reader AND schema-safe.
    //
    // The AI-completion label uses the same channel and for the same reason (N-a): an
    // `aiCompletions` field on the match would be rejected by dsh's validator and take the
    // whole note_recall call down — the exact failure that already happened once here.
    // Prefixed onto the SNIPPET rather than the metadata line because the snippet is the
    // text the reader actually looks at, and the marker's meaning is "part of THIS text is
    // not the user's".
    //
    // The two provisional counts are merged into ONE bracket (2026-10-01) rather than
    // stacking two prefixes: they carry the same verdict ("do not take this as settled"),
    // and the agent-experience rule is to say a fact once. The 58-character long form ate
    // ~19% of a 300-character snippet window, so the wording is deliberately terse and the
    // prompt-text conventions stay on the tool description / vault protocol, not here.
    snippet: (entry.doc.archived === true ? "［已归档·未被删，可在面板恢复］ " : "")
      + provisionalLabel(entry.doc)
      + snippetForPassage(passages[entry.i], queryTokens),
    // Enumeration reports 0, not the formula's "no tokens ⇒ 1": a tag listing has
    // no query, so a coverage of 1 would claim perfect lexical coverage of nothing
    // (and the renderer prints a dash for it either way).
    coverage: queryTokens.length === 0 ? 0 : Number(queryCoverage(queryTokens, docTokenSets[entry.i]).toFixed(2))
    // 注意：这里**不要**再加 `hook` / `boundary` 之类的内部字段。dsh ≥0.1.5 会对成功
    // 返回值做严格校验，而 note_recall 的 output schema 是 `additionalProperties: false`
    // ⇒ 多一个字段 = 整次工具调用失败（ToolOutputError）。曾经的 `hook: doc.hook,
    // boundary: doc.boundary ?? ""` 就是这样把 note_recall 打死的（2026-09-14）。
    // 需要 rich 值的是**调用方**：`rankRecallDocuments` 的返回值里仍然带着它们。
  });

  // ── tag-only enumeration ────────────────────────────────────────────────
  // No scoring, no coverage: ordering is `updated` desc (undated last), path as
  // the deterministic tiebreak. The applicability gate is NOT applied here — it
  // is keyed on query phrases, and an enumeration has no query to key on.
  if (queryTokens.length === 0 && tag !== "") {
    const entries = kept.map((doc, i) => ({ doc, i, score: 0 }));
    entries.sort((a, b) => {
      const ua = String(a.doc.updated ?? "").trim();
      const ub = String(b.doc.updated ?? "").trim();
      if (ua !== ub) {
        if (ua === "") return 1;
        if (ub === "") return -1;
        return ua < ub ? 1 : -1;
      }
      return a.doc.rel < b.doc.rel ? -1 : a.doc.rel > b.doc.rel ? 1 : 0;
    });
    const top = entries.slice(0, safeLimit);
    return {
      mode: "enumeration",
      operator,
      viewPool: "bag",
      passages,
      docTokens,
      docTokenSets,
      matches: top.map((entry) => shape(entry, 0)),
      excluded: []
    };
  }

  const corpusStats = computeCorpusStats(docTokens);
  // Multi-view max-pool (experimental, GraphMemix §multi-view): score every named
  // view with its own length statistics and keep the best one per document, so a
  // short exact-title match is not diluted by a long body. IDF still comes from
  // the bag corpus, so only the per-view length normalization differs.
  const maxPooled = viewPool === "max"
    ? (() => {
        const viewsByDoc = kept.map((doc) => composePassageViews(doc.kind, doc));
        const viewCount = Math.max(0, ...viewsByDoc.map((views) => views.length));
        const tokenColumns = [];
        const statsColumns = [];
        const textColumns = [];
        for (let v = 0; v < viewCount; v += 1) {
          const texts = viewsByDoc.map((views) => views[v]?.text ?? "");
          const tokens = texts.map((text) => tokenize(text));
          textColumns.push(texts);
          tokenColumns.push(tokens);
          statsColumns.push(computeCorpusStats(tokens));
        }
        return {
          raw: kept.map((doc, i) => {
            let best = 0;
            for (let v = 0; v < viewCount; v += 1) {
              if (tokenColumns[v][i].length === 0) continue;
              best = Math.max(best, bm25Score(queryTokens, tokenColumns[v][i], statsColumns[v]));
            }
            return best;
          }),
          cjk: kept.map((doc, i) => {
            let best = 0;
            for (let v = 0; v < viewCount; v += 1) best = Math.max(best, cjkCharOverlap(query, textColumns[v][i]));
            return best;
          }),
          views: viewsByDoc
        };
      })()
    : null;
  const rawScores = maxPooled === null
    ? kept.map((doc, i) => bm25Score(queryTokens, docTokens[i], corpusStats))
    : maxPooled.raw;
  // NOT `Math.max(1e-9, ...rawScores)`: the spread pushes every score onto the
  // stack, so a vault that enumerates a few hundred thousand docs would die with
  // a RangeError instead of returning a ranking.
  let maxScore = 1e-9;
  for (const value of rawScores) if (value > maxScore) maxScore = value;
  const priorOf = (doc) => hookPrior(doc.hook, doc.updated);
  const operatorMatch = (doc) => operator === null || (doc.hook !== null && normalizeOperator(doc.hook.operator) === operator);
  // BM25 (dominant, semantic/lexical) + CJK char containment (bridges
  // 子列/子序列-class word-form gaps) + hook prior (promote/demote), then the
  // per-kind corpus weight for navigation indices.
  const cjkBonus = maxPooled === null
    ? kept.map((doc, i) => cjkCharOverlap(query, passages[i]))
    : maxPooled.cjk;
  const scored = kept.map((doc, i) => ({
    doc,
    i,
    score: (RECALL_BM25_WEIGHT * (rawScores[i] / maxScore)
      + RECALL_CJK_WEIGHT * cjkBonus[i]
      + RECALL_PRIOR_WEIGHT * priorOf(doc)) * (KIND_CORPUS_WEIGHT[doc.kind] ?? 1)
      // Archive demotion: archived evidence is RETAINED for retrieval, but it must
      // never outrank live material at equal relevance (`ARCHIVE_RECALL_WEIGHT`).
      * (doc.archived === true ? ARCHIVE_RECALL_WEIGHT : 1),
    operatorMatch: operatorMatch(doc)
  }));

  let pool = scored;
  let operatorFallback = false;
  if (operator !== null) {
    if (scored.some((entry) => entry.operatorMatch)) pool = scored.filter((entry) => entry.operatorMatch);
    else operatorFallback = true;
  }
  pool = [...pool].sort((a, b) => b.score - a.score);

  // Applicability gate (R1 anti-conditions): a card whose own boundary phrases
  // appear in the query is NOT offered as a candidate. It is reported instead of
  // silently dropped — a silent false negative would hide a memory the user has,
  // and an unexplained one is indistinguishable from "not found" (design-intake
  // §4 risk 2). Excluded entries never consume a result slot.
  // 注意 `entry` 本身就是 scored 项（形状是 `{ doc, i, score, operatorMatch }`），
  // 不是 `{ entry: … }` 包装。曾经这里写成 `entry.doc.boundary`，于是**任何一次有卡被
  // 适用边界排除的检索都会抛 TypeError**（`Cannot read properties of undefined`），
  // 也就是 note_recall 在"边界卡命中查询"时整体不可用（2026-09-14 用户实测）。
  const boundaryHitsOf = (entry) => (entry.doc.boundary === "" ? [] : boundaryHits(query, entry.doc.boundary));
  // 注意 `entry` 本身就是 scored 项（形状是 `{ doc, i, score, operatorMatch }`），
  // 不是 `{ entry: … }` 包装。曾经这里写成 `entry.doc.*`，于是**任何一次有卡被适用边界
  // 排除的检索都会抛 TypeError**（`Cannot read properties of undefined`），也就是
  // note_recall 在"边界卡命中查询"时整体不可用（2026-09-14 用户实测：模型看到工具侧报错，
  // 只好改用 note_search / grep）。返回的键也必须与 output schema 逐字一致。
  const excluded = [];
  const eligible = [];
  for (const entry of pool) {
    const hits = boundaryHitsOf(entry);
    if (hits.length === 0) { eligible.push(entry); continue; }
    excluded.push({ doc: entry.doc, hits });
  }
  const top = eligible.slice(0, safeLimit);

  return {
    mode: operatorFallback ? "fallback" : "unified",
    operator,
    // Reported so a caller (and the QA A/B) can tell which pooling produced the
    // ranking above — declared state, never an assumption.
    viewPool: maxPooled === null ? "bag" : "max",
    passages,
    docTokens,
    docTokenSets,
    matches: top.map((entry) => shape(entry, Number(entry.score.toFixed(4)))),
    // Boundary-excluded cards, with the phrase that triggered the exclusion. The
    // caller reports them; it must not silently pretend they do not exist.
    // 这四个键就是 output schema 声明的全部（多一个都会被 dsh 的严格校验判失败）。
    excluded: excluded.map(({ doc, hits }) => ({
      path: doc.rel,
      title: doc.title,
      boundary: doc.boundary,
      boundaryHits: hits
    }))
  };
}

/**
 * Classify a vault-relative path into the unified corpus kinds. Scaffold and
 * machine files return "skip"; raw episode bodies are skipped too (evidence
 * is reached via grep/read — only their index lines join the corpus).
 */
export function classifyVaultDoc(rel, options = {}) {
  // The vault's working protocol is instructions, not note content — excluded
  // under BOTH names it can have: `AGENTS.md` is what the installer writes, and
  // `vault-AGENTS.md` is the repo's own template-source name (a vault can carry
  // it, and the synthetic benchmark vault was renamed to it on 2026-09-11 so the
  // file stops being auto-injected as repo instructions — see
  // `scripts/check-agent-instructions.mjs`).
  if (rel === "AGENTS.md" || rel === "vault-AGENTS.md") return "skip";
  if (rel === ".deepseek/capture-policy.md" || rel === ".deepseek/memory/profile.md") return "skip";
  if (rel === ".deepseek/working.md") return "skip"; // scratch draft, not part of the retrieval corpus
  if (rel.startsWith(".deepseek/cache")) return "skip";
  // Archived material is skipped BY DEFAULT ("evidence only") — but that default was
  // the whole bug: `archive/` is excluded from the corpus AND from the injected
  // timeline, so anything archived became invisible in practice. Archiving meant
  // forgetting something that might still be useful, which is exactly the loss the
  // user named. So the ordinary corpus still excludes it, and `note_recall` can ask
  // for it explicitly (`includeArchived`). An archived card classifies as its
  // UNDERLYING kind (`.deepseek/archive/records/x.md` → `record`), not as a new
  // kind, so every existing consumer (passage composition, hooks, gates) keeps
  // working unchanged; `buildRecallDoc` records the archive fact in `doc.archived`.
  if (rel.startsWith(".deepseek/archive/")) {
    if (options.includeArchived !== true) return "skip";
    const bare = rel.slice(".deepseek/archive/".length);
    const slash = bare.indexOf("/");
    if (slash <= 0) return "skip";
    const layer = bare.slice(0, slash);
    const rest = bare.slice(slash + 1);
    // An archived card's LIVE home is not always guessable from the path: `records`,
    // `templates`, `topics` and `inbox` live under `.deepseek/memory/<layer>/`, while
    // `strategy` lives directly under `.deepseek/`. Trying only `.deepseek/<layer>/`
    // fell through to `note` for records (caught by the gate assertion), and trying
    // only `.deepseek/memory/<layer>/` did the same for strategy — so try each
    // candidate and keep the first that resolves to something other than `note`.
    for (const candidate of [".deepseek/memory/" + layer + "/" + rest, ".deepseek/" + layer + "/" + rest]) {
      const kind = classifyVaultDoc(candidate);
      if (kind !== "skip" && kind !== "note") return kind;
    }
    return "note";
  }
  if (rel.startsWith(".deepseek/memory/episodes/")) {
    return rel.endsWith("/index.md") ? "episode-index" : "skip";
  }
  const memoryDir = (dir) => {
    const stem = rel.slice(dir.length);
    if (stem === "index.md" || stem.startsWith("_")) return "skip";
    return rel.endsWith(".md") ? "ok" : "skip";
  };
  if (rel.startsWith(".deepseek/memory/records/")) return memoryDir(".deepseek/memory/records/") === "ok" ? "record" : "skip";
  if (rel.startsWith(".deepseek/memory/templates/")) return memoryDir(".deepseek/memory/templates/") === "ok" ? "template" : "skip";
  if (rel.startsWith(".deepseek/inbox/")) return memoryDir(".deepseek/inbox/") === "ok" ? "memo" : "skip";
  if (rel.startsWith(".deepseek/memory/topics/")) return memoryDir(".deepseek/memory/topics/") === "ok" ? "topic" : "skip";
  if (rel === ".deepseek/memory/theorems/index.md") return "theorem-index";
  if (rel.startsWith(".deepseek/strategy/")) return memoryDir(".deepseek/strategy/") === "ok" ? "strategy" : "skip";
  return "note";
}

/**
 * Kind-aware retrieval passage (LeanSearch kind-aware passages, localized):
 * hook cards emphasize hook fields, memos/notes emphasize body heads, index
 * kinds keep their line-based content. Frontmatter is excluded.
 *
 * This is the product passage, unchanged since retrieval v3 landed: the token
 * stream it produces is what every existing ranking, snippet and probe result
 * was measured on, so it must not be reordered casually.
 */
export function composePassage(kind, doc) {
  const hookText = [doc.hook?.operator, doc.hook?.pattern, doc.hook?.techniques, doc.hook?.applications, doc.hook?.heuristics, doc.hook?.quantity]
    .filter((part) => Array.isArray(part) ? part.length > 0 : typeof part === "string" && part !== "")
    .flat()
    .join(" ");
  const body = stripFrontmatter(String(doc.body ?? "")).trim();
  const title = String(doc.title ?? "");
  const topic = String(doc.topic ?? "");
  const join = (...parts) => parts.filter((part) => part !== "").join(" ");
  switch (kind) {
    case "record":
    case "template":
      return join(title, hookText, topic, body.slice(0, 800));
    case "memo":
      return join(title, topic, body.slice(0, 1500));
    case "topic":
      return join(title, body.slice(0, 2000));
    case "episode-index":
    case "theorem-index":
      return join(title, body.slice(0, 2000));
    case "strategy":
      return join(title, doc.strategy ?? "", body.slice(0, 200));
    default:
      return join(title, (doc.tags ?? []).join(" "), body.slice(0, 1500));
  }
}

/**
 * The SAME passage split into named views (title / keywords / body), for the
 * multi-view max-pool experiment (`rankRecallDocuments(…, { viewPool: "max" })`).
 *
 * Why separate views: one concatenated bag length-normalizes as a whole, so a
 * card whose TITLE matches the query exactly can lose to a card that merely
 * mentions the words often in a long body. GraphMemix (arXiv:2608.26983) scores
 * each view separately and keeps the best — see docs/memory/retrieval-v3.md §7.
 *
 * This function is deliberately NOT a refactor of `composePassage`: the bag is
 * frozen (it is what every earlier measurement ran on), so the view split lives
 * beside it and only the probe's A/B compares them.
 */
export function composePassageViews(kind, doc) {
  const hookText = [doc.hook?.operator, doc.hook?.pattern, doc.hook?.techniques, doc.hook?.applications, doc.hook?.heuristics, doc.hook?.quantity]
    .filter((part) => Array.isArray(part) ? part.length > 0 : typeof part === "string" && part !== "")
    .flat()
    .join(" ");
  const body = stripFrontmatter(String(doc.body ?? "")).trim();
  const title = String(doc.title ?? "");
  const topic = String(doc.topic ?? "");
  const viewsWith = (keywordText, bodyLimit, bodyPrefix = "") => [
    { name: "title", text: title },
    { name: "keywords", text: keywordText },
    { name: "body", text: joinParts(bodyPrefix, body.slice(0, bodyLimit)) }
  ];
  // The view split carries exactly the fields the bag carries (so the A/B
  // isolates POOLING, not extra evidence): title | keywords | body.
  switch (kind) {
    case "record":
    case "template":
      return viewsWith(topic, 800, hookText);
    case "memo":
      return viewsWith(topic, 1500);
    case "topic":
    case "episode-index":
    case "theorem-index":
      return viewsWith("", 2000);
    case "strategy":
      return viewsWith(doc.strategy ?? "", 200);
    default:
      return viewsWith((doc.tags ?? []).join(" "), 1500);
  }
}

function joinParts(...parts) {
  return parts.filter((part) => part !== "").join(" ");
}

/**
 * Flatten a strategy card's frontmatter into its retrievable surface:
 * difficulty (main axis) + problem_type + domain + strategies[].move +
 * abstraction (concrete/principle/generalize). The field values carry the
 * searchable vocabulary — this is what BM25 scores for the strategy layer.
 */
export function strategySurface(frontmatter) {
  if (typeof frontmatter !== "string" || frontmatter === "") return "";
  const parts = [];
  const collect = (re, text) => {
    for (const m of text.matchAll(re)) {
      const v = (m[1] ?? "").trim();
      if (v !== "") parts.push(v);
    }
  };
  collect(/^difficulty:\s*(.+)$/gm, frontmatter);
  collect(/^problem_type:\s*(.+)$/gm, frontmatter);
  collect(/^domain:\s*(.+)$/gm, frontmatter);
  collect(/^\s*-\s*move:\s*(.+)$/gm, frontmatter);
  for (const key of ["concrete", "principle", "generalize"]) {
    collect(new RegExp("^\\s*" + key + ":\\s*\"?([^\"\\n]+)\"?\\s*$", "gm"), frontmatter);
  }
  return parts.join(" ");
}

/** Extract `- move: X` values from a strategy card's frontmatter. */
export function strategyMoves(frontmatter) {
  if (typeof frontmatter !== "string") return [];
  return [...frontmatter.matchAll(/^\s*-\s*move:\s*(.+)$/gm)].map((m) => m[1].trim()).filter((v) => v !== "");
}

/** Extract `retrieve: [list]` targets (flattened, deduped) from a strategy card. */
export function strategyRetrieve(frontmatter) {
  if (typeof frontmatter !== "string") return [];
  const seen = new Set();
  const out = [];
  for (const m of frontmatter.matchAll(/^\s*retrieve:\s*\[(.*)\]$/gm)) {
    for (const part of m[1].split(",")) {
      const v = part.trim().replace(/^['"]|['"]$/g, "");
      if (v !== "" && !seen.has(v)) { seen.add(v); out.push(v); }
    }
  }
  return out;
}

/** Join the abstraction ladder (concrete / principle / generalize) into one string. */
export function strategyAbstraction(frontmatter) {
  if (typeof frontmatter !== "string") return "";
  const parts = [];
  for (const key of ["concrete", "principle", "generalize"]) {
    const m = new RegExp("^\\s*" + key + ":\\s*\"?([^\"\\n]+)\"?\\s*$", "m").exec(frontmatter);
    if (m) parts.push(m[1].trim());
  }
  return parts.join(" → ");
}

/**
 * Paired decision guidance from a strategy card, as `{ prefer, avoid }` strings.
 *
 * WHY a pair rather than one list (MSCE `D = (context, a⁺, a⁻, evidence, reliability)`,
 * arXiv:2607.16621 §B.10): "what to do" alone does not carry the lesson. Recording
 * "do X / avoid Y" together is what turns one failure into a transferable judgement;
 * the audit's `反模式` section is only a loose sentence by comparison.
 *
 * Read from `decision_guidance:` with ONE line each for `prefer` / `avoid`. A
 * single-line string is deliberate: it stays readable as prose in the card and avoids
 * the inline-flow-list trap this repo keeps hitting (a `[a b]` flow list parses as ONE
 * token). Multiple items are separated by `;` or `；`.
 */
export function strategyGuidance(frontmatter) {
  if (typeof frontmatter !== "string") return { prefer: "", avoid: "" };
  const pick = (key) => {
    const m = new RegExp("^\\s*" + key + ":\\s*[\"']?(.*?)[\"']?\\s*$", "m").exec(frontmatter);
    if (m === null) return "";
    return m[1].split(/[;；]/).map((part) => part.trim()).filter(Boolean).join("；");
  };
  return { prefer: pick("prefer"), avoid: pick("avoid") };
}

/** Extract a scalar from YAML-ish frontmatter text (no dependency on the memory module). */
function metaScalar(frontmatter, key) {
  if (frontmatter === null) return undefined;
  const match = new RegExp("^" + key + ":\\s*(.*)$", "m").exec(frontmatter);
  if (match === null) return undefined;
  const value = match[1].trim().replace(/^['\"]|['\"]$/g, "");
  return value === "" ? undefined : value;
}

/** Title for a corpus doc: frontmatter title → first heading → filename stem. */
function titleFromDoc(frontmatter, body, fallback) {
  const meta = metaScalar(frontmatter, "title");
  if (meta !== undefined) return meta;
  const heading = /^#\s+(.+)$/m.exec(body)?.[1]?.trim();
  return heading ?? fallback.replace(/\.md$/i, "");
}

/** One-line snippet around the first query-token occurrence (or passage head). */
function snippetForPassage(passage, queryTokens, maxLen = 140) {
  const lower = passage.toLowerCase();
  let index = -1;
  for (const token of queryTokens) {
    if (token.length < 2) continue;
    const at = lower.indexOf(token.toLowerCase());
    if (at >= 0) { index = at; break; }
  }
  if (index < 0) return passage.slice(0, maxLen);
  return makeSnippet(passage, index, 2);
}

function hookNumber(hook, key, fallback) {
  const value = Number(hook?.[key]);
  return Number.isFinite(value) ? value : fallback;
}



function localDateString() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}

// Serialize stats writes: note_recall declares itself concurrency-safe,
// so two concurrent hits could otherwise interleave read-modify-write and
// lose a count. A module-level promise queue makes the update atomic.
let statsWriteQueue = Promise.resolve();

function recordRetrievalStatsNow(vaultPath, cardPaths, query = "") {
  const statsPath = join(vaultPath, ".deepseek", "cache", "retrieval-stats.json");
  let stats = {};
  try {
    if (existsSync(statsPath)) stats = JSON.parse(readFileSync(statsPath, "utf8")) ?? {};
  } catch {
    stats = {};
  }
  const today = localDateString();
  const meta = stats["__meta__"] ?? { calls: 0, empty: 0 };
  meta.calls = (Number.isFinite(meta.calls) ? meta.calls : 0) + 1;
  if (cardPaths.length === 0) meta.empty = (Number.isFinite(meta.empty) ? meta.empty : 0) + 1;
  stats["__meta__"] = meta;
  const trimmedQuery = String(query ?? "").replace(/\s+/g, " ").trim().slice(0, 200);
  for (const rel of cardPaths) {
    const entry = stats[rel] ?? {};
    entry.uses = (Number.isFinite(entry.uses) ? entry.uses : 0) + 1;
    entry.last_used = today;
    // Kept as `last_query`, never merged into the card. The audit's stats reset runs
    // over these entries and preserves only `last_used`, so this field is cleared
    // with the rest — which is intended: it is context for the NEXT ❌, not history.
    if (trimmedQuery !== "") entry.last_query = trimmedQuery;
    stats[rel] = entry;
  }
  try {
    mkdirSync(dirname(statsPath), { recursive: true });
    writeFileSync(statsPath, JSON.stringify(stats, null, 2), "utf8");
  } catch {
    // Stats are advisory; ignore write failures.
  }
}

/**
 * Best-effort hit accounting into the plugin-owned stats cache
 * (.deepseek/cache/retrieval-stats.json). The audit pass in
 * math-memory.mjs merges this into the cards' hook.uses / last_used and
 * then zeroes the entries (no double counting). Never throws: a stats write
 * failure must not fail the retrieval itself.
 *
 * `query` is recorded per card as `last_query`. It is NOT a usage statistic and is
 * not merged into the card: it exists so that a later rejection can name the context
 * it rejected (`applyFeedback` → boundary narrowing, improvement-details item 8). The
 * user's rejection arrives through a link that carries only a path and an action,
 * so the query has to be remembered at hit time or it is gone.
 *
 * Exported so the regression suite can exercise the write directly: the callers live
 * inside the tool handlers and the write runs on a serialized promise queue, so there
 * is no public pure function that reaches it. Testing only the read side left the
 * recording uncovered — a mutation that dropped `last_query` passed every assertion.
 */
export function recordRetrievalStats(vaultPath, cardPaths, query = "") {
  if (typeof vaultPath !== "string" || vaultPath === "") return;
  statsWriteQueue = statsWriteQueue
    .then(() => recordRetrievalStatsNow(vaultPath, cardPaths, query))
    .catch(() => {});
}

// ── cordis plugin ────────────────────────────────────────────────────────────

export async function apply(ctx, config) {
  const cfg = normalizeConfig(config);
  const defineTool = await loadDefineTool(ctx);

  ctx.systemPrompt.section({
    name: "tool:note-tools",
    order: 103,
    text:
      "Use the dedicated Obsidian note tools for note-level operations: " +
      "note_recall (PRIMARY retrieval entry — unified relevance-ranked search over user notes AND all memory layers with BM25 + hook signals; use it whenever you need to FIND relevant content, then read the top 2-3 matches in full before using them; an empty result is a signal to reformulate the query. Pass `tag` without `query` to enumerate user notes carrying that tag, newest first), " +
      "note_strategy (method layer for proof/construction problems), " +
      "note_create (new note only — it refuses to overwrite an existing note), and note_links (which notes link to a note). " +
      "Keep the generic file tools for read/write/edit. Do NOT use grep as a discovery tool: it is a precision tool for verifying an exact string or line inside a file whose path you already know (found via note_recall); glob is for locating a file by path pattern, not for searching content. There is no separate note_search tool — note_recall answers query and tag lookups."
  });

  // ── note_search: RETIRED (2026-09-20) ──────────────────────────────────
  // The tool used to live here and is deliberately NOT registered any more. Its
  // query duty was already absorbed by note_recall in retrieval v3 (S1–S3), but
  // the tool itself was left behind, so the vault had three "find something"
  // entries (note_recall / note_search / grep) and the model picked among them —
  // the same defect family as the grep-as-retrieval routing cleaned up the same
  // day (docs/changelog.md 2026-09-20). Its one capability note_recall lacked —
  // "list by tag without a query word" — is now note_recall's tag-only
  // enumeration mode (mode: "enumeration"). Verified before deleting: all 15
  // recorded real calls passed a `query` and none was tag-only, and no test or
  // script referenced the tool except its own fixture (removed from
  // scripts/fixtures/tool-outputs.json). See docs/memory/retrieval-v3.md §5.1.

  // ── note_create ────────────────────────────────────────────────────────
  ctx.tools.register(defineTool({
    name: "note_create",
    description: `Create a new markdown note in the Obsidian vault at the given vault-relative path. The full markdown (including any frontmatter) is written exactly as provided. This tool refuses to overwrite an existing note and has no overwrite flag; to change an existing note, use read + edit/write after the user asks for it.`,
    parameters: {
      path: { type: "string", required: true, description: "Vault-relative path for the new note, with or without the \".md\" extension." },
      content: { type: "string", required: true, description: "Full markdown content of the note, including any YAML frontmatter you want at the top." }
    },
    output: {
      schema: {
        type: "object",
        additionalProperties: false,
        properties: {
          path: { type: "string", required: true },
          operation: { type: "string", required: true, enum: ["create"] }
        }
      },
      render: (_args, value) => [{ type: "text", text: `Created note: ${value.path}` }]
    },
    async execute(args, exec) {
      const { rootPath, rootTarget } = await resolveVault(ctx, exec, cfg);
      const rel = normalizeNoteRelPath(args.path);
      const bytes = Buffer.byteLength(args.content, "utf8");
      if (bytes > cfg.maxNoteBytes) {
        throw new Error(`note_create: note is ${bytes} bytes; maximum is ${cfg.maxNoteBytes} bytes`);
      }
      const target = await ctx.fs.resolve(join(rootPath, ...rel.split("/")), { signal: exec?.signal });
      requireInsideVault(ctx, rootTarget, target);

      const existing = await ctx.fs.stat(target, exec?.signal);
      if (existing !== undefined) throw new Error(OVERWRITE_REFUSAL(rel));

      let outcome;
      try {
        outcome = await ctx.fs.writeText(target, args.content, { kind: "createIfAbsent" }, exec?.signal);
      } catch (error) {
        if (error?.code === "FS_NOT_OBSERVED") throw new Error(OVERWRITE_REFUSAL(rel));
        throw error;
      }
      ctx.emit("fs/observed", target, { kind: "present", version: outcome.version }, exec);
      // 键名必须与 output schema 一致：`rel` 既不是声明里的 `path`，也会被 dsh 的严格校验
      // 判成"未声明字段"⇒ 建笔记成功但整次调用报错（2026-09-14 修）。
      return { path: rel, operation: "create" };
    },
    presentCall: (args) => ({
      card: "diff",
      title: `Create note ${args.path}`,
      diffs: [{ path: args.path, oldText: null, newText: args.content }]
    })
  }));

  // ── note_links ─────────────────────────────────────────────────────────
  ctx.tools.register(defineTool({
    name: "note_links",
    description: `Query wikilink backlinks in the Obsidian vault: which notes link TO a note. Pass a note name (with or without the ".md" extension) to see only its incoming links; omit the argument to return the full note-name -> linking-notes map.`,
    parameters: {
      note: { type: "string", description: "Optional note name or vault-relative path (extension optional) to filter backlinks to." }
    },
    output: {
      schema: {
        type: "object",
        additionalProperties: false,
        properties: {
          queried: { oneOf: [{ type: "string" }, { type: "null" }], required: true },
          exists: { type: "boolean", required: true },
          backlinks: { type: "json", required: true },
          total: { type: "integer", required: true }
        }
      },
      render: (_args, value) => {
        const entries = Object.entries(value.backlinks ?? {});
        const lines = entries.map(([target, sources]) => `- ${target} ← ${sources.join(", ")}`);
        if (value.queried !== null) {
          if (!value.exists) return [{ type: "text", text: `No note found: ${value.queried}` }];
          return [{
            type: "text",
            text: `Backlinks for ${value.queried} (${value.total}):\n${lines.join("\n") || "（none）"}`
          }];
        }
        return [{
          type: "text",
          text: `Backlink map across vault (${value.total} links):\n${lines.join("\n") || "（none）"}`
        }];
      }
    },
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const { rootPath, rootTarget } = await resolveVault(ctx, exec, cfg);
      const notes = await listNotes(ctx, rootTarget, exec?.signal, cfg.excludePatterns);

      const backlinks = new Map();
      const noteNames = new Map();
      const notePaths = new Map();
      for (const note of notes) {
        noteNames.set(note.name.toLowerCase(), note.name);
        notePaths.set(note.path.toLowerCase().replace(/\.md$/i, ""), note.name);
      }
      for (const note of notes) {
        const raw = await readNoteTextCached(ctx, rootPath, note, exec?.signal);
        if (raw === null) continue;
        for (const target of extractWikiLinks(raw)) {
          const sources = backlinks.get(target) ?? [];
          if (!sources.some((source) => source.toLowerCase() === note.name.toLowerCase())) sources.push(note.name);
          backlinks.set(target, sources);
        }
      }
      for (const sources of backlinks.values()) sources.sort((a, b) => a.localeCompare(b));

      const requested = typeof args.note === "string" ? args.note.trim().replace(/\.md$/i, "") : "";
      if (requested === "") {
        const all = Object.fromEntries([...backlinks.entries()].sort(([a], [b]) => a.localeCompare(b)));
        const total = Object.values(all).reduce((sum, sources) => sum + sources.length, 0);
        return { queried: null, exists: true, backlinks: all, total };
      }

      const requestedLower = requested.toLowerCase();
      const exactKey = [...backlinks.keys()].find((key) => key.toLowerCase() === requestedLower);
      const suffixKey = [...backlinks.keys()].find((key) => key.toLowerCase().endsWith(`/${requestedLower}`));
      const key = exactKey ?? suffixKey;
      const noteName = notePaths.get(requestedLower) ?? noteNames.get(requestedLower);
      if (key !== undefined) {
        const sources = backlinks.get(key) ?? [];
        return { queried: key, exists: true, backlinks: { [key]: sources }, total: sources.length };
      }
      if (noteName !== undefined) {
        return { queried: noteName, exists: true, backlinks: { [noteName]: [] }, total: 0 };
      }
      return { queried: requested, exists: false, backlinks: { [requested]: [] }, total: 0 };
    },
    presentCall: (args) => ({ card: "generic", title: "Query backlinks", kind: "search", rawInput: args.note ?? "(all)" })
  }));

  // ── note_recall (memory v3 S1: unified entry) ─────────────────────────────
  ctx.tools.register(defineTool({
    name: "note_recall",
    description: `Unified relevance-ranked search across the WHOLE vault: user notes AND the memory layers (records/templates cards with hook weighting, memos, topic files, theorem index, episode index). BM25 ranking + hook-field signals + success-rate prior. This is the PRIMARY retrieval entry and the ONLY content-discovery tool — grep is not a discovery tool (use grep only to verify an exact string or line number inside a file whose path is already known), and there is no separate note_search. Returns a compact top-k with kind, title, one-line snippet, verification level, uses/success_rate, score and coverage (fraction of query tokens matched — coverage below 0.35 marks a weak, likely lexical-coincidence hit even when the score looks high; a long or bilingual query depresses coverage across the WHOLE list, so when everything looks weak read the top hit in full before concluding the vault is empty). Snippets are short WINDOWS around the query terms, not the full card. Then READ the top 2-3 matches in full and RE-EVALUATE whether each actually fits the CURRENT query before using them — a relevant, verified, high-score hit is a candidate, not a mandate (a previously-successful technique can be a fixation trap on a slightly-different instance). An empty result is a signal: reformulate the query (different challenge wording or technique keywords) or change approach — never force-fit unrelated cards. A snippet prefixed ［…·不宜当结论］ means the note itself marks part of its content as AI-written or not yet settled: those parts are not settled knowledge, so re-derive the answer instead of restating the note, and do not report them as the user's own words. Enumerate by tag when you need "which notes carry this tag" rather than "what is relevant": pass tag and OMIT query.`,
    parameters: {
      query: { type: "string", description: "Distilled search query: the reasoning challenge plus candidate technique keywords, e.g. '证明独立随机变量和 a.s. 收敛 子序列 Borel-Cantelli'. OMIT it to enumerate by tag instead (then `tag` is required)." },
      operator: { type: "string", description: `Optional stage-1 hard filter, one of ${[...HOOK_OPERATORS].join("/")}. Only hook cards with a matching operator are scored; when none matches, all docs are scored and mode reports the fallback.` },
      tag: { type: "string", description: "Tag filter, without leading '#' (nested tags match: \"analysis\" also matches \"math/analysis\"). With a query it restricts the corpus to those notes; WITHOUT a query it is the tag-only enumeration mode — user notes carrying the tag, ordered by frontmatter `updated` descending (undated last), with no relevance score and no coverage." },
      maxResults: { type: "integer", description: `Optional cap on matches; defaults to ${RECALL_DEFAULT_MAX_RESULTS}, maximum ${RECALL_HARD_MAX_RESULTS}.` },
      includeArchived: { type: "boolean", description: "Also search ARCHIVED memory (`.deepseek/archive/`), which is excluded by default so it is not mistaken for live knowledge. Use it when the ordinary search comes up empty but you suspect the vault once held something relevant: archived cards are demoted in the ranking and their snippets are prefixed ［已归档］. Archive is a MOVE, not a deletion — anything found this way can be restored by the user in the memory panel." }
    },
    output: {
      schema: {
        type: "object",
        additionalProperties: false,
        properties: {
          query: { type: "string", required: true },
          mode: { type: "string", required: true, enum: ["unified", "fallback", "enumeration"] },
          operator: { oneOf: [{ type: "string" }, { type: "null" }], required: true },
          matches: {
            type: "array",
            required: true,
            items: {
              type: "object",
              additionalProperties: false,
              properties: {
                path: { type: "string", required: true },
                kind: { type: "string", required: true },
                title: { type: "string", required: true },
                snippet: { type: "string", required: true },
                verified: { oneOf: [{ type: "string" }, { type: "null" }], required: true },
                hookOperator: { oneOf: [{ type: "string" }, { type: "null" }], required: true },
                uses: { type: "integer", required: true },
                successRate: { oneOf: [{ type: "number" }, { type: "null" }], required: true },
                score: { type: "number", required: true },
                coverage: { type: "number", required: true }
              }
            }
          },
          excluded: {
            type: "array",
            required: true,
            description: "Candidates withheld by their own applicability boundary (not_applicable_when), with the phrase that matched.",
            items: {
              type: "object",
              additionalProperties: false,
              properties: {
                path: { type: "string", required: true },
                title: { type: "string", required: true },
                boundary: { type: "string", required: true },
                boundaryHits: { type: "array", required: true, items: { type: "string" } }
              }
            }
          }
        }
      },
      render: (_args, value) => {
        const withheld = value.excluded.length === 0 ? "" : `\n另有 ${value.excluded.length} 条因**适用边界**被排除（不是"没找到"；若确实需要，先读原文判断边界是否真的成立）：\n${value.excluded.map((item) => `- ${item.title} (${item.path}) — 命中边界「${item.boundaryHits.join("、")}」`).join("\n")}`;
        // Say out loud that archived material is in this result set. A reader who is
        // not told would treat recovered evidence as current knowledge.
        const recovered = value.matches.filter((match) => match.snippet.startsWith("［已归档")).length;
        const archivedNote = recovered === 0
          ? ""
          : `\n其中 ${recovered} 条来自 **归档**（曾被判低效用而移动，未被删除）：归档内容**降权**排列，且只应作为"以前记过、供参考"的线索，不要当作当前有效的技巧引用；如果它其实仍然有用，请在记忆面板里恢复它。`;
        if (value.matches.length === 0) {
          return [{ type: "text", text: `No relevant content found — treat this as a signal to reformulate the query or change approach.${withheld}` }];
        }
        const kindLabel = { note: "笔记", record: "记忆卡", template: "模板", memo: "备忘录", topic: "主题", "episode-index": "事件", "theorem-index": "定理" };
        // Tag-only enumeration has no relevance score and no coverage (there was no
        // query to score against), so it must not print a fabricated 覆盖:0.00 next
        // to results the reader would then rank by it. It says what it is instead.
        const enumeration = value.mode === "enumeration";
        const lines = value.matches.map((match) => {
          const extra = [
            match.verified === null ? "" : { "user-confirmed": "✅", "cross-referenced": "⚖️", "single-source": "❓" }[match.verified] ?? match.verified,
            match.hookOperator === null ? "" : `算子:${match.hookOperator}`,
            `uses:${match.uses}`,
            match.successRate === null ? "" : `成功率:${match.successRate}`,
            enumeration ? "覆盖:—（枚举模式不计分）" : `覆盖:${match.coverage}`
          ].filter((part) => part !== "").join(" · ");
          return enumeration
            ? `- [${kindLabel[match.kind] ?? match.kind}] ${match.title} (${match.path})${extra === "" ? "" : " · " + extra}`
            : `- [${kindLabel[match.kind] ?? match.kind}] ${match.title} (${match.path}) score ${match.score.toFixed(3)}${extra === "" ? "" : " · " + extra}\n  ${match.snippet}`;
        });
        if (enumeration) {
          return [{ type: "text", text: `${value.matches.length} 条笔记带此 tag（**枚举模式**：按 frontmatter updated 降序，不是相关性排序；没有查询词就没有 score/coverage 可报，需要找"相关内容"请带 query 再检索一次）:\n${lines.join("\n")}${archivedNote}` }];
        }
        const weak = value.matches.filter((match) => match.coverage < 0.35).length;
        // A blanket weak verdict is usually an artifact, not a finding: coverage is
        // computed over ALL query tokens, so one long or bilingual query depresses
        // every hit at once. Saying only "弱信号，多为词面巧合" per list here is what
        // pushed the model out of note_recall and into raw grep discovery; when the
        // whole list is weak, point at the ranking instead (see the tool description).
        const weakNote = weak === 0
          ? ""
          : weak === value.matches.length
            ? `全部 ${weak} 条 coverage<0.35——多为「长查询/中英混排把覆盖率整体压低」的表现，不等于库里没有：先读排第一的那篇全文核实，再决定是否改写查询（不要改用 grep 全库搜）`
            : `${weak} 条 coverage<0.35 属弱信号，多为词面巧合（优先信排名靠前且分数高的那几条）`;
        return [{ type: "text", text: `${value.matches.length} 条候选（读前 2-3 条全文核实适用性后再使用——相关 + 已验证 ≠ 适用于本题；${weakNote}）:\n${lines.join("\n")}${archivedNote}${withheld}` }];
      }
    },
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const { rootPath, rootTarget } = await resolveVault(ctx, exec, cfg);
      const query = String(args.query ?? "").trim();
      const tag = normalizeTagFilter(args.tag);
      if (query === "" && tag === "") {
        throw new Error("note_recall: provide query, tag, or both");
      }
      const operator = args.operator === undefined || args.operator === null || String(args.operator).trim() === ""
        ? null
        : normalizeOperator(args.operator);
      const requested = Number(args.maxResults ?? RECALL_DEFAULT_MAX_RESULTS);
      if (!Number.isInteger(requested) || requested < 1) {
        throw new Error(`note_recall: maxResults must be a positive integer`);
      }
      const limit = Math.min(requested, RECALL_HARD_MAX_RESULTS);
      const includeArchived = args.includeArchived === true;

      // One walk covers notes AND memory (no .deepseek exclusion here).
      const notes = await listNotes(ctx, rootTarget, exec?.signal, cfg.excludePatterns);
      const docs = [];
      for (const note of notes) {
        const raw = await readNoteTextCached(ctx, rootPath, note, exec?.signal);
        if (raw === null) continue;
        const doc = buildRecallDoc(note.path, raw, { includeArchived });
        if (doc !== null) docs.push(doc);
      }

      const ranked = rankRecallDocuments(docs, query, { tag, operator, limit });

      // Hook stats migration (memory v3): the unified entry records hits for
      // hook cards; the daily audit merges them back into uses/last_used. A hit
      // count is a claim that this call RETRIEVED the card for a query, so
      // enumeration (no query) records nothing — a tag listing is not a hit.
      if (query !== "") {
        recordRetrievalStats(rootPath, ranked.matches.filter((match) => match.hook !== null).map((match) => match.path), query);
      }

      return { query, mode: ranked.mode, operator: ranked.operator, matches: ranked.matches, excluded: ranked.excluded };
    },
    presentCall: (args) => ({ card: "generic", title: "Recall vault content", kind: "search", rawInput: args.query })
  }));

  // ── note_strategy (strategy layer: method retrieval) ──────────────────────
  ctx.tools.register(defineTool({
    name: "note_strategy",
    description: `Retrieve strategy cards from the method layer (.deepseek/strategy/): given a reasoning challenge / difficulty, find the stored "how to attack this kind of problem" playbook — each card lists candidate strategies (moves) and, for each, where to retrieve supporting content (retrieve targets). Use it BEFORE note_recall on proof/construction problems: it returns the playbook (difficulty → moves → where to look), then execute the moves via note_recall. This is the method-layer navigator; it is a CANDIDATE not a mandate — re-evaluate each move's applicability to the current problem before following it. Results are split by card status: \`matches\` are cards eligible to follow now (status active or unspecified), while \`candidates\` are still at status candidate — not yet promoted by usage, so treat them as leads and do NOT cite them as an established technique. An empty result = no stored strategy for this difficulty yet; fall back to note_recall directly.`,
    parameters: {
      query: { type: "string", required: true, description: "The distilled difficulty / challenge description, e.g. '定义层证明冗长' or '证明 a.s. 收敛 子列技巧'." },
      difficulty: { type: "string", description: "Optional exact difficulty token to hard-filter (matches the card's difficulty field); omit to let BM25 score decide." },
      maxResults: { type: "integer", description: "Optional cap on matches; defaults to 3, maximum 10." }
    },
    output: {
      schema: {
        type: "object",
        additionalProperties: false,
        properties: {
          query: { type: "string", required: true },
          matches: {
            type: "array",
            required: true,
            description: "Strategy cards eligible to be followed now (status active or unspecified).",
            items: {
              type: "object",
              additionalProperties: false,
              properties: {
                path: { type: "string", required: true },
                title: { type: "string", required: true },
                difficulty: { type: "string", required: true },
                status: { type: "string", required: true },
                moves: { type: "array", required: true, items: { type: "string" } },
                retrieve: { type: "array", required: true, items: { type: "string" } },
                abstraction: { type: "string", required: true },
                notApplicableWhen: { type: "string", required: true },
                prefer: { type: "string", required: true },
                avoid: { type: "string", required: true },
                verified: { type: "string", required: true },
                score: { type: "number", required: true }
              }
            }
          },
          candidates: {
            type: "array",
            required: true,
            description: "Strategy cards still at status `candidate`: leads, NOT mandates — they have not been promoted by usage yet, so do not cite them as an established technique.",
            items: {
              type: "object",
              additionalProperties: false,
              properties: {
                path: { type: "string", required: true },
                title: { type: "string", required: true },
                difficulty: { type: "string", required: true },
                status: { type: "string", required: true },
                moves: { type: "array", required: true, items: { type: "string" } },
                retrieve: { type: "array", required: true, items: { type: "string" } },
                abstraction: { type: "string", required: true },
                notApplicableWhen: { type: "string", required: true },
                prefer: { type: "string", required: true },
                avoid: { type: "string", required: true },
                verified: { type: "string", required: true },
                score: { type: "number", required: true }
              }
            }
          },
          excluded: {
            type: "array",
            required: true,
            description: "Strategy cards withheld by their own not_applicable_when boundary, with the matched phrase.",
            items: {
              type: "object",
              additionalProperties: false,
              properties: {
                path: { type: "string", required: true },
                title: { type: "string", required: true },
                boundary: { type: "string", required: true },
                boundaryHits: { type: "array", required: true, items: { type: "string" } }
              }
            }
          }
        }
      },
      render: (_args, value) => {
        const withheld = value.excluded.length === 0 ? "" : `\n另有 ${value.excluded.length} 张策略卡因**不适用边界**被排除（不是"库里没有"）：\n${value.excluded.map((item) => `- ${item.title} (${item.path}) — 命中边界「${item.boundaryHits.join("、")}」`).join("\n")}`;
        if (value.matches.length === 0) {
          return [{ type: "text", text: `No stored strategy for this difficulty — fall back to note_recall directly (and consider distilling one into .deepseek/strategy/ after this turn).${withheld}` }];
        }
        const badge = (v) => v === "user-confirmed" ? " ✅" : v === "cross-referenced" ? " ⚖️" : " ❓";
        const renderCard = (m) =>
          `- [策略] ${m.difficulty}${badge(m.verified)} (${m.path}) score ${m.score.toFixed(3)}\n  moves: ${m.moves.join(" / ")}\n  retrieve: ${m.retrieve.join(", ")}\n  abstraction: ${m.abstraction}${m.notApplicableWhen !== "" ? "\n  ⚠ 不适用: " + m.notApplicableWhen : ""}${m.prefer !== "" ? "\n  ✔ 建议: " + m.prefer : ""}${m.avoid !== "" ? "\n  ✘ 避免: " + m.avoid : ""}`;
        // Candidates get their own block with an explicit permission sentence:
        // `status: candidate` means the audit has not promoted this card yet, so
        // following its moves is fine but citing it as an established technique is
        // not. Mixed into `matches` it was indistinguishable from a promoted card,
        // because the pre-2026-09-17 shape carried no `status` at all.
        const candidateBlock = value.candidates.length === 0 ? "" :
          `\n\n另有 ${value.candidates.length} 张**候选**策略卡（status: candidate，尚未按使用记录晋升——可以把 moves 当线索试用，但**不得当作已验证技巧引用**）:\n${value.candidates.map(renderCard).join("\n")}`;
        if (value.matches.length === 0) {
          return [{ type: "text", text: `No stored strategy for this difficulty — fall back to note_recall directly (and consider distilling one into .deepseek/strategy/ after this turn).${withheld}${candidateBlock}` }];
        }
        const lines = value.matches.map(renderCard);
        return [{ type: "text", text: `${value.matches.length} 张策略卡（候选，不是指令——按适用性逐条重判后再用）:\n${lines.join("\n")}${withheld}${candidateBlock}` }];
      }
    },
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const { rootPath, rootTarget } = await resolveVault(ctx, exec, cfg);
      const query = String(args.query ?? "").trim();
      if (query === "") throw new Error("note_strategy: provide a query (difficulty/challenge description)");
      const requested = Number(args.maxResults ?? 3);
      if (!Number.isInteger(requested) || requested < 1) throw new Error("note_strategy: maxResults must be a positive integer");
      const limit = Math.min(requested, 10);
      const difficultyFilter = typeof args.difficulty === "string" ? normalizeOperator(args.difficulty) : "";

      // Method layer only: walk the vault, keep strategy cards, build their surface.
      const notes = await listNotes(ctx, rootTarget, exec?.signal, cfg.excludePatterns);
      const docs = [];
      for (const note of notes) {
        if (classifyVaultDoc(note.path) !== "strategy") continue;
        const raw = await readNoteTextCached(ctx, rootPath, note, exec?.signal);
        if (raw === null) continue;
        const doc = buildRecallDoc(note.path, raw);
        if (doc === null || doc.strategy === "") continue;
        docs.push(doc);
      }

      const ranked = rankStrategyCards(docs, query, { difficulty: difficultyFilter, limit });
      const byPath = new Map(docs.map((doc) => [doc.rel, doc]));
      const expand = ({ path, score, status }) => {
        const doc = byPath.get(path);
        return {
          card: {
            path,
            title: doc.title,
            difficulty: doc.difficulty,
            status,
            surface: doc.strategy,
            moves: strategyMoves(doc.rawFrontmatter),
            retrieve: strategyRetrieve(doc.rawFrontmatter),
            abstraction: strategyAbstraction(doc.rawFrontmatter),
            notApplicableWhen: metaScalar(doc.rawFrontmatter, "not_applicable_when") ?? "",
            guidance: strategyGuidance(doc.rawFrontmatter),
            verified: doc.hook?.verified ?? "single-source"
          },
          score
        };
      };
      const top = ranked.matches.map(expand);
      const candidateTop = ranked.candidates.map(expand);

      // Strategy hits feed the same usage stats as records, so the daily audit
      // can promote candidates (self-correction.md P5b).
      recordRetrievalStats(rootPath, top.map((entry) => entry.card.path), query);

      // Shape one card for the wire. Only keys declared in the output schema may
      // appear: dsh validates the returned value strictly against a schema with
      // `additionalProperties: false`, so one extra field fails the whole call
      // (`card.kind`/`score` used to make note_strategy throw every time —
      // fixed 2026-09-14).
      const toWire = ({ card, score }) => ({
        path: card.path,
        title: card.title,
        difficulty: card.difficulty,
        status: card.status,
        moves: card.moves,
        retrieve: card.retrieve,
        abstraction: card.abstraction,
        notApplicableWhen: card.notApplicableWhen,
        prefer: card.guidance?.prefer ?? "",
        avoid: card.guidance?.avoid ?? "",
        verified: card.verified,
        score: Number(score.toFixed(4))
      });

      return {
        query,
        matches: top.map(toWire),
        candidates: candidateTop.map(toWire),
        excluded: ranked.excluded.map((item) => ({
          path: item.path,
          title: item.title,
          boundary: item.boundary,
          boundaryHits: item.boundaryHits
        }))
      };
    },
    presentCall: (args) => ({ card: "generic", title: "Retrieve strategy", kind: "search", rawInput: args.query })
  }));
}
