#!/usr/bin/env node
/**
 * mutation-sweep — "守卫在该报错时确实报错"的**成体系**复核，而不是逐条口头声称。
 *
 * WHY THIS EXISTS (2026-10-15). This repo's own rule is that a guard is accepted only after a mutation
 * proves it reddens (`AGENTS.md` §6: 「加守卫必须做变异验证」). Every guard added or changed by the
 * 2026-10-15 decoupling pass was verified that way — one at a time, interactively, in a scratch
 * directory that no longer exists. So the evidence was unreproducible: a reader could see the commits
 * and the changelog claims, but could not re-run the check.
 *
 * This script is that evidence, made re-runnable. It reverts ONE guard per entry (in memory: the file
 * is restored in a `finally`), runs that guard's own gate, and requires an actual `[FAIL]` assertion
 * line — plus, where named, that the failure is the EXPECTED assertion. The stricter criterion matters:
 * the first version of this sweep accepted "output mentions failed", and two mutations whose gates
 * merely printed descriptive text were counted as detected while the guard was in fact blind to them
 * (found 2026-10-15; both gaps are now covered by assertions, see the `fixed-by` note per entry).
 *
 * Usage:
 *   node scripts/qa/mutation-sweep.mjs            # run every entry
 *   node scripts/qa/mutation-sweep.mjs --list     # list entries without touching anything
 *
 * ⚠️ It writes to tracked files (and restores them). Run it on a clean tree, and treat a non-empty
 * `git diff` afterwards as a failure of THIS script, not of the guards.
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { MUTATION_ENTRIES } from '../lib/mutation-entries.mjs';

const repo = join(dirname(fileURLToPath(import.meta.url)), '..', '..');

/**
 * The list itself lives in `scripts/lib/mutation-entries.mjs`, shared with the fast read-only gate
 * `scripts/check-mutation-anchors.mjs` — which is what keeps these anchors from rotting between runs.
 * `from` must appear exactly once in `file`; `expect` is the assertion text that must show up in a
 * `[FAIL]` line (omitting it only checks "some assertion failed", which is weaker — see the header).
 */
const ENTRIES = MUTATION_ENTRIES;

if (process.argv.includes('--list')) {
  for (const e of ENTRIES) console.log(`${e.file.padEnd(34)} ${e.label}`);
  console.log(`\n${ENTRIES.length} entries`);
  process.exit(0);
}

const results = [];
for (const entry of ENTRIES) {
  const path = join(repo, entry.file);
  const backup = readFileSync(path, 'utf8');
  const lf = backup.replace(/\r\n/g, '\n');
  const occurrences = lf.split(entry.from).length - 1;
  if (occurrences !== 1) {
    results.push({ ...entry, status: occurrences === 0 ? 'ANCHOR-MISSING' : `ANCHOR-AMBIGUOUS(${occurrences})` });
    continue;
  }
  const crlf = backup.includes('\r\n');
  const mutated = lf.replace(entry.from, entry.to);
  writeFileSync(path, crlf ? mutated.replace(/\n/g, '\r\n') : mutated, 'utf8');
  try {
    if (entry.rebuild === true) {
      try { execFileSync('node', ['scripts/build-obsidian.mjs'], { cwd: repo, stdio: 'pipe' }); } catch { /* reported by the gate */ }
    }
    let output = '';
    let exit = 0;
    try {
      output = execFileSync('node', [entry.gate], { cwd: repo, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
    } catch (error) {
      exit = error.status ?? 1;
      output = (error.stdout ?? '') + (error.stderr ?? '');
    }
    // Failure lines in this repo come in more shapes than one: `[FAIL] label` (most suites),
    // `FAIL  message` (the older standalone guards), and `[COPY] file:line` +
    // `N re-typed frontmatter delimiter(s) found` (check-frontmatter-source, which reports a category
    // before a summary). Matching only `[FAIL]`/`^FAIL` made the frontmatter entry look like it failed
    // for the wrong reason while it was in fact detected (found 2026-10-15).
    const failLines = output.split('\n').filter((line) => /^\s*\[[A-Z]+\]/.test(line) || /^FAIL\s/.test(line));
    const detected = failLines.length > 0 || exit !== 0;
    // `expectAny: true` is an explicit "some assertion fails" — used where the defect breaks a whole
    // pipeline (ten assertions at once) or where pinning one name would understate the evidence. An
    // entry with NEITHER `expect` nor `expectAny` is treated as `expectAny` but flagged in the summary,
    // so "I forgot to name it" cannot masquerade as a deliberate choice.
    const namedRight = entry.expect === undefined
      ? null
      : failLines.some((line) => line.includes(entry.expect));
    results.push({
      ...entry,
      status: !detected ? 'NOT-DETECTED' : namedRight === false ? 'WRONG-ASSERTION' : 'RED',
      exit,
      firstFail: failLines[0]?.trim().slice(0, 140) ?? ''
    });
  } finally {
    writeFileSync(path, backup, 'utf8');
    if (entry.rebuild === true) {
      try { execFileSync('node', ['scripts/build-obsidian.mjs'], { cwd: repo, stdio: 'pipe' }); } catch { /* restored by the next gate run */ }
    }
  }
}

let clean = true;
for (const r of results) {
  console.log(`[${r.status}] ${r.label}`);
  if (r.firstFail !== '') console.log(`    ${r.firstFail}`);
  if (r.status !== 'RED') clean = false;
}
console.log(`\nmutation-sweep: ${results.filter((r) => r.status === 'RED').length}/${results.length} mutations detected by their own gate`);
if (!clean) {
  console.error('NOT all mutations were detected — a guard is blind to the defect it exists for.');
  process.exit(1);
}
console.log('All files restored; verify with `git diff` before committing.');
