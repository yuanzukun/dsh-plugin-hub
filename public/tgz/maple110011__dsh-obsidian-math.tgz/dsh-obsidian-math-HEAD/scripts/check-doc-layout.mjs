#!/usr/bin/env node
/**
 * check-doc-layout — 文档树的"可达性"守卫。
 *
 * 为什么需要它
 * ------------
 * 2026-10-18 的文档审计（`.docaudit/`）给出三个反复出现的形态：
 *   1. 文件被移动 / 归档后，引用它的相对链接没有改（断链，靠人肉眼发现）；
 *   2. `docs/` 顶层混放 33 份文档、没有总索引，60% 的文档没有任何入口；
 *   3. 文档把 `gitignored` 的本地草稿（`.scratch-*`、`推文-*`、`literature/.raw/`）
 *      当成"仓库内可查的证据"引用——新 clone 里根本不存在。
 *
 * 三条规则（只读、不产生子进程，故受限环境也能跑）
 * -----------------------------------------------
 *   1. **链接可达**：仓库内 md 的相对 `.md` 链接必须解析到仓库内的真实文件；
 *      指向 gitignored 证据的链接、或 `../` 逃出仓库的链接，直接失败。
 *   2. **索引覆盖**：`docs/README.md` 必须存在，并直接链接到一组"当前权威"入口；
 *      `docs/**` 下的每份文档都必须能从它出发、在 ≤2 跳内到达
 *      （`docs/README.md → docs/memory/README.md → memory/design.md` 这种算 1 跳）。
 *   3. **入口有效**：规则 1 已经覆盖 `AGENTS.md` / `README.md` 里的链接。
 *
 * 为什么是"2 跳"而不是"必须直接列出"：文档分组是必要的（memory 有 13 份，
 * 全塞进总索引会把它变成第二份正文）；但"总索引 → 子索引 → 文档"必须成立，
 * 否则就是"没有入口"。
 *
 * 不做什么：不判内容对错、不判状态标注新旧（那两件事分别由
 * `check-doc-consistency` / 评审负责）；不检查 http(s) 链接。
 */
import { readFileSync, existsSync, readdirSync } from "node:fs";
import { dirname, join, resolve, relative, sep } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

let failed = 0;
const fail = (msg) => {
  console.error(`FAIL  ${msg}`);
  failed += 1;
};

/** 审计范围：仓库内 md。排除构建产物、产品语料、基准夹具、本地草稿。 */
function collectMarkdown() {
  const out = [];
  const walk = (dir) => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      if (entry.isDirectory()) {
        if (entry.name === "node_modules" || entry.name === ".git") continue;
        // literature/ 是产品语料（.raw 还 gitignored）；benchmark-vault 是合成测试夹具。
        if (dir === root && entry.name === "literature") continue;
        if (entry.name === "benchmark-vault") continue;
        walk(join(dir, entry.name));
        continue;
      }
      if (!entry.name.endsWith(".md")) continue;
      const abs = join(dir, entry.name);
      const rel = relative(root, abs).split(sep).join("/");
      // 本地工作草稿：gitignored，刻意不纳入任何文档规则（见 .gitignore）。
      if (/^\.scratch-/.test(rel)) continue;
      if (/^docs\/promotion\/推文-/.test(rel)) continue;
      out.push(rel);
    }
  };
  walk(root);
  return out.sort();
}

/** 解析一份 md 的相对链接（跳过代码围栏；带行号，便于报错）。 */
function relativeLinks(rel) {
  const text = readFileSync(join(root, rel), "utf8").replace(/\r\n/g, "\n");
  const links = [];
  let fence = null;
  text.split("\n").forEach((line, index) => {
    if (fence !== null) {
      if (line.trim().startsWith(fence)) fence = null;
      return;
    }
    const open = /^(```+|~~~+)/.exec(line);
    if (open !== null) {
      fence = open[1];
      return;
    }
    // 行内代码不是链接：历史记录里可能出现"坏链接形态"的示例文本（例如
    // docs/changelog.md 里用反引号包起来的旧路径），不能当成断链。若不做这层过滤，
    // 那条历史示例会被误报（2026-10-18 实测）。
    const cleaned = line.replace(/`[^`]*`/g, "");
    for (const m of cleaned.matchAll(/\]\(([^)\s]+)\)/g)) {
      const target = m[1];
      if (/^(https?:|mailto:|#)/i.test(target)) continue;
      links.push({ target, line: index + 1 });
    }
  });
  return links;
}

const GITIGNORED_EVIDENCE = [
  [/^literature\/\.raw\//, "literature/.raw/ 是 gitignored 的原始语料"],
  [/(^|\/)\.scratch-/, ".scratch-* 是 gitignored 的本地草稿"],
  [/推文-/, "推文-*.md 是 gitignored 的本地宣传稿"],
];

const files = collectMarkdown();

// ── 规则 1：相对 md 链接必须指向仓库内的真实文件 ────────────────────────────
let linkCount = 0;
for (const rel of files) {
  for (const { target, line } of relativeLinks(rel)) {
    const pathPart = target.split("#")[0];
    if (!pathPart.toLowerCase().endsWith(".md")) continue;
    linkCount += 1;
    const abs = resolve(root, dirname(rel), pathPart);
    const inside = abs === root || abs.startsWith(root + sep);
    const resolvedRel = relative(root, abs).split(sep).join("/");
    if (!inside) {
      fail(`${rel}:${line} 链接 ${target} 逃出了仓库（解析到 ${resolvedRel}）——文档必须自带可复核的材料`);
      continue;
    }
    for (const [pattern, why] of GITIGNORED_EVIDENCE) {
      if (pattern.test(resolvedRel)) fail(`${rel}:${line} 链接到 gitignored 证据 ${target}（${why}）`);
    }
    if (!existsSync(abs)) {
      fail(`${rel}:${line} 链接 ${target} 不存在（解析到 ${resolvedRel}）`);
    }
  }
}

// ── 规则 2：docs/README.md 是总索引，docs/** 必须可达 ───────────────────────
const INDEX = "docs/README.md";
const REQUIRED_ENTRIES = [
  "AGENTS.md",
  "ARCHITECTURE.md",
  "README.md",
  "docs/changelog.md",
  "docs/env-vars.md",
  "docs/handoff.md",
  "docs/installation.md",
  "docs/literature.md",
  "docs/memory/README.md",
  "docs/memory/control-panel.md",
  "docs/memory/design.md",
  "docs/release.md",
];

/** 从一份文档解析出的、仓库内真实存在的 md 文件（绝对路径集合）。 */
function resolveLinks(rel) {
  const set = new Set();
  for (const { target } of relativeLinks(rel)) {
    const pathPart = target.split("#")[0];
    if (!pathPart.toLowerCase().endsWith(".md")) continue;
    const abs = resolve(root, dirname(rel), pathPart);
    if (abs === root || abs.startsWith(root + sep)) set.add(abs);
  }
  return set;
}

let direct = new Set();
let reachable = new Set();
if (!existsSync(join(root, INDEX))) {
  fail(`缺少文档总索引 ${INDEX}——新增/移动文档前先建立它（规则见该文件）`);
} else {
  direct = resolveLinks(INDEX);
  reachable = new Set(direct);
  for (const abs of direct) {
    if (!existsSync(abs)) continue;
    for (const deeper of resolveLinks(relative(root, abs).split(sep).join("/"))) reachable.add(deeper);
  }
  const directRel = new Set([...direct].map((abs) => relative(root, abs).split(sep).join("/")));
  for (const required of REQUIRED_ENTRIES) {
    if (!directRel.has(required)) fail(`${INDEX} 没有直接链接到「当前权威」入口 ${required}`);
  }
}

const docsFiles = files.filter((rel) => rel.startsWith("docs/") && rel !== INDEX);
for (const rel of docsFiles) {
  if (!reachable.has(join(root, rel))) {
    fail(`docs 文档没有入口：${rel}（需从 ${INDEX} 出发 ≤2 跳可达——直接列进总索引，或列进子索引）`);
  }
}

// ── 规则 3：日期命名的历史文档必须有身份头 ──────────────────────────────────
// 2026-10-18 的教训：`docs/*-YYYY-MM-DD.md` 是一次性评估/历史记录，读者最容易
// 把"成文时的结论"当成"现在"。规则很窄——只要求文件名带完整日期的文档在前 10 行
// 里写明 `类型：` 与 `状态：`（模板见 docs/README.md），不追溯正文。
const DATED = /-\d{4}-\d{2}-\d{2}\.md$/;
let dated = 0;
for (const rel of files) {
  if (!rel.startsWith("docs/") || !DATED.test(rel)) continue;
  dated += 1;
  const head = readFileSync(join(root, rel), "utf8").replace(/\r\n/g, "\n").split("\n").slice(0, 10).join("\n");
  if (!/类型：/.test(head)) {
    fail(`${rel}: 日期命名的历史文档要在标题后写 \`> 类型：…… · 状态：……\` 头（模板见 ${INDEX}）`);
  }
  if (!/状态：/.test(head)) {
    fail(`${rel}: 日期命名的历史文档缺少 \`状态：\`（historical / closed / proposal / partial 等）`);
  }
}

if (failed > 0) {
  console.error(`\ndoc-layout: ${failed} 个问题。索引规则与文档类型见 ${INDEX}。`);
  process.exit(1);
}
console.log(
  `doc-layout: ok (${files.length} 份 md；${linkCount} 条相对 md 链接全部可达；` +
    `${docsFiles.length} 份 docs 文档均可从 ${INDEX} ≤2 跳到达；${dated} 份日期文档有身份头)`
);
