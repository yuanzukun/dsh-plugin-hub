// Regression for the loopback reverse proxy that carries dsh web.
//
// WHY: dsh >= 0.1.5 mints a `SameSite=Strict` session cookie named after the
// request authority. Obsidian's sidebar iframe is cross-site (app://obsidian.md
// → http://127.0.0.1:3180), so the browser neither stores nor sends that cookie
// and the panel showed dsh's "authentication required" page even after the
// plugin captured the launch token (docs/dsh-0.1.5-adaptation.md §3.7 follow-up).
//
// The proxy in the plugin's main process is immune: it redeems the token once,
// keeps the cookie and injects it into every forwarded request — which requires
// it to own the public port, with dsh moved to an internal one.
//
// The class under test is EXTRACTED FROM the shipped template (not re-typed) and
// run against a stub upstream that reproduces dsh's authority + cookie rules.
//
// It also covers the sidebar HTML injection: the proxy rewrites the HTML document
// it serves (the only way to reach the cross-origin sidebar frame) to add the
// note-link interceptor — ALWAYS, because that interceptor is functional. The
// proxy's old "侧栏性能模式" CSS + skin-hooks rewriting was removed on 2026-10-18
// (see .docaudit/perf-audit.md); the injection path itself stays, which is why the
// stub still serves a realistic `</head>` document, a bare one, a gzip one and
// header echoes.
import { readFileSync } from 'node:fs';
import { createServer, request as httpRequest } from 'node:http';
import { createHash } from 'node:crypto';
import { gunzipSync, gzipSync } from 'node:zlib';
import { setTimeout as sleep } from 'node:timers/promises';

const template = readFileSync('obsidian/main.template.js', 'utf8');

// Assertions are COUNTED as they run, never declared. This suite used to carry
// `const EXPECTED_CHECKS = 31` while 32 `check(` call sites executed, so its
// tail line "31/31 passed" was arithmetic on a stale constant rather than
// evidence of coverage — and the docs, anchored to that line, repeated 31.
let passed = 0;
let total = 0;
const check = (name, cond, detail = '') => {
  total += 1;
  if (cond) passed += 1;
  console.log((cond ? '[ok] ' : '[FAIL] ') + name + (detail ? ' | ' + detail : ''));
};

/** Cut a whole `class X { … }` out of the template by brace matching. */
function classSource(name) {
  const start = template.indexOf(`class ${name} {`);
  if (start < 0) throw new Error(`class ${name} not found in the template`);
  const braceStart = template.indexOf('{', start);
  let depth = 0;
  for (let i = braceStart; i < template.length; i += 1) {
    if (template[i] === '{') depth += 1;
    else if (template[i] === '}') {
      depth -= 1;
      if (depth === 0) return template.slice(start, i + 1);
    }
  }
  throw new Error(`unbalanced braces for ${name}`);
}

/** One GET through the proxy, returning the raw response. */
function get(path, headers = {}) {
  return new Promise((resolve) => {
    const req = httpRequest({ host: '127.0.0.1', port: PUBLIC_PORT, path, method: 'GET', headers }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
    });
    req.on('error', () => resolve({ status: 0, headers: {}, body: Buffer.alloc(0) }));
    req.end();
  });
}

const cookieNameFor = (authority) =>
  'dsh-auth-' + createHash('sha256').update(authority).digest('base64')
    .replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/u, '');

// ── stub upstream: exactly dsh's rules (authority-named cookie, 401 without) ─
const LAUNCH_TOKEN = 'stub-launch-token_ABC-123';
const SHELL = '<!doctype html><html><head><title>dsh</title></head><body><script>window.__DSH_BOOT__={}</script></body></html>';
let upstreamPort = 0;
const upstream = createServer((req, res) => {
  const authority = req.headers.host;
  const cookie = req.headers.cookie ?? '';
  const url = new URL(req.url ?? '/', 'http://stub');
  if (url.pathname === '/' && url.searchParams.get('token') === LAUNCH_TOKEN && authority !== undefined) {
    res.writeHead(303, {
      location: '/',
      'set-cookie': `${cookieNameFor(authority)}=v1.stub.sig; Path=/; HttpOnly; SameSite=Strict`
    });
    res.end();
    return;
  }
  if (cookie.includes(`${cookieNameFor(authority ?? '')}=`)) {
    if (url.pathname === '/') {
      res.writeHead(200, { 'content-type': 'text/html' });
      res.end(SHELL);
      return;
    }
    // A document without </head>: the injection point does not exist, and the
    // response must still arrive whole.
    if (url.pathname === '/bare') {
      res.writeHead(200, { 'content-type': 'text/html' });
      res.end('<!doctype html><body>bare');
      return;
    }
    // Always gzip, whatever the client advertised: the proxy must pass it through
    // instead of injecting into compressed bytes.
    if (url.pathname === '/gz') {
      const body = gzipSync(SHELL);
      res.writeHead(200, { 'content-type': 'text/html', 'content-encoding': 'gzip', 'content-length': String(body.length) });
      res.end(body);
      return;
    }
    if (url.pathname === '/headers') {
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ sawAcceptEncoding: req.headers['accept-encoding'] ?? null }));
      return;
    }
    if (url.pathname.startsWith('/assets/')) {
      res.writeHead(200, { 'content-type': 'application/javascript' });
      res.end('/*bundle*/'.repeat(200));
      return;
    }
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ ok: true, sawAuthority: authority, sawCookie: true }));
    return;
  }
  res.writeHead(401, { 'content-type': 'text/plain' });
  res.end('dsh web authentication required; reopen the URL printed by dsh web.\n');
});
upstream.on('upgrade', (req, socket) => {
  const authority = req.headers.host;
  const cookie = req.headers.cookie ?? '';
  if (!cookie.includes(`${cookieNameFor(authority ?? '')}=`)) {
    socket.write('HTTP/1.1 401 Unauthorized\r\nconnection: close\r\n\r\n');
    socket.destroy();
    return;
  }
  socket.write('HTTP/1.1 101 Switching Protocols\r\nupgrade: websocket\r\nconnection: Upgrade\r\n\r\n');
  socket.on('data', (chunk) => socket.write(chunk));
});
await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
upstreamPort = upstream.address().port;

// ── instantiate the template's real proxy ───────────────────────────────────
const DshWebProxy = new Function(
  'createServer', 'httpRequest', 'URL', 'sleep',
  `${classSource('DshWebProxy')}\nreturn DshWebProxy;`
)(createServer, httpRequest, URL, sleep);

const PUBLIC_PORT = 3220;
const proxy = new DshWebProxy();
proxy.upstreamPort = upstreamPort;
await proxy.listen(PUBLIC_PORT);
const at = (p) => `http://127.0.0.1:${PUBLIC_PORT}${p}`;
check('proxy listens on the configured port', proxy.port === PUBLIC_PORT && proxy.running, `port=${proxy.port}`);

// 1. before redeeming, the 401 must pass through untouched
const before = await fetch(at('/'), { redirect: 'manual' });
check('before redemption the upstream 401 passes through', before.status === 401, `status=${before.status}`);

// 2. redeem the launch token AS THE PUBLIC AUTHORITY
const redeemed = await proxy.redeem(`http://127.0.0.1:${upstreamPort}/?token=${LAUNCH_TOKEN}`);
check('redeem() succeeds against the upstream token URL', redeemed === true);
check('the stored cookie is named for the PUBLIC authority (not the upstream one)',
  proxy.cookie.startsWith(cookieNameFor(`127.0.0.1:${PUBLIC_PORT}`)),
  proxy.cookie.split('=')[0]);

// 3. the UI now arrives through the proxy
const index = await fetch(at('/'), { redirect: 'manual' });
const html = await index.text();
check('proxy serves the app shell (no 401)', index.status === 200 && html.includes('__DSH_BOOT__'), `status=${index.status}`);
const asset = await fetch(at('/assets/index-x.js'), { redirect: 'manual' });
check('proxy serves static assets', asset.status === 200 && (await asset.text()).length > 500);

// 3b. Sidebar HTML injection: the note-link interceptor is what reaches the
// cross-origin frame. It is injected UNCONDITIONALLY — it is functional (a link
// click must stay inside the sidebar instead of opening the system browser), so
// there is no setting that can turn it off. The old 侧栏性能模式 stylesheet and the
// skin-hooks rewrite that used to share this path were deleted 2026-10-18.
const nav = { accept: 'text/html,application/xhtml+xml' };
const injected = await get('/', nav);
const injectedText = injected.body.toString('utf8');
check('inject: the HTML document carries the note-link interceptor before </head>',
  injectedText.includes(`<script id="${proxy.noteLinkScriptId}"`) && injectedText.indexOf(proxy.noteLinkScriptId) < injectedText.indexOf('</head>'),
  `status=${injected.status}`);
check('inject: the shell itself is unchanged around the injection',
  injectedText.includes('__DSH_BOOT__') && injectedText.startsWith('<!doctype html>') && injectedText.includes('</body></html>'));
check('inject: a navigation asks the upstream for an uncompressed body to inject into',
  (await get('/headers', { ...nav, 'accept-encoding': 'br' })).body.toString('utf8').includes('"sawAcceptEncoding":null'));
check('inject: a non-navigation keeps its accept-encoding (assets stay compressed)',
  (await get('/headers', { accept: '*/*', 'accept-encoding': 'br' })).body.toString('utf8').includes('"sawAcceptEncoding":"br"'));
const assetBody = await get('/assets/index-x.js', nav);
check('inject: non-HTML responses are never rewritten',
  !assetBody.body.toString('utf8').includes(proxy.noteLinkScriptId) && assetBody.body.toString('utf8').startsWith('/*bundle*/'));
const bare = await get('/bare', nav);
check('inject: a document without </head> passes through whole',
  bare.body.toString('utf8') === '<!doctype html><body>bare', bare.body.toString('utf8').slice(0, 40));
const gz = await get('/gz', nav);
let gzText = '';
try {
  gzText = gunzipSync(gz.body).toString('utf8');
} catch {
  gzText = '(not gzip)';
}
check('inject: a gzip document passes through byte-identical (never injected into compressed bytes)',
  gz.headers['content-encoding'] === 'gzip' && gzText === SHELL, `encoding=${gz.headers['content-encoding']}`);
// Leftover settings keys from 0.8.x are inert: even with both "off", the
// interceptor is still injected (the setting no longer exists, and a stale
// data.json must not re-create the old "links open the system browser" bug).
proxy.plugin = { settings: { sidebarPerformanceMode: false, sidebarSkinScripts: false } };
const off = await get('/', nav);
check('inject: leftover 0.8.x settings cannot disable the interceptor (always on)',
  off.body.toString('utf8').includes(proxy.noteLinkScriptId) && off.body.toString('utf8') !== SHELL,
  `bytes=${off.body.length}`);
proxy.plugin = null;

// 4. the upstream must see the public authority (that is what keeps the cookie valid)
const api = await fetch(at('/api'), { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
const payload = await api.json();
check('proxy presents the PUBLIC authority upstream', payload.sawAuthority === `127.0.0.1:${PUBLIC_PORT}`, `saw=${payload.sawAuthority}`);
check('proxy injects the session cookie upstream', payload.sawCookie === true);

// 5. websocket upgrade on the mux path
const wsOk = await new Promise((resolve) => {
  const req = httpRequest({ host: '127.0.0.1', port: PUBLIC_PORT, path: '/api/remote.mux', headers: {
    connection: 'Upgrade', upgrade: 'websocket', 'sec-websocket-key': Buffer.from('0123456789abcdef').toString('base64'),
    'sec-websocket-version': '13', host: `127.0.0.1:${PUBLIC_PORT}`
  } });
  let settled = false;
  const done = (v) => { if (!settled) { settled = true; resolve(v); } };
  req.on('upgrade', (res) => { done(`upgraded ${res.statusCode}`); req.destroy(); });
  req.on('response', (res) => done(`response ${res.statusCode}`));
  req.on('error', (e) => done('error ' + e.code));
  req.end();
  setTimeout(() => done('timeout'), 5000);
});
check('proxy forwards the websocket upgrade (/api/remote.mux)', wsOk.startsWith('upgraded'), wsOk);

// 6. a non-mux upgrade must not be tunnelled
const otherUpgrade = await new Promise((resolve) => {
  const req = httpRequest({ host: '127.0.0.1', port: PUBLIC_PORT, path: '/not-mux', headers: {
    connection: 'Upgrade', upgrade: 'websocket', 'sec-websocket-key': Buffer.from('0123456789abcdef').toString('base64'),
    'sec-websocket-version': '13'
  } });
  let settled = false;
  const done = (v) => { if (!settled) { settled = true; resolve(v); } };
  req.on('upgrade', () => done('upgraded'));
  req.on('response', (res) => done('response ' + res.statusCode));
  req.on('error', (e) => done('error ' + e.code));
  req.end();
  setTimeout(() => done('timeout'), 5000);
});
check('proxy refuses an unknown upgrade path', otherUpgrade !== 'upgraded', otherUpgrade);

// 7. close() must free the port and drop the cookie
await proxy.close();
check('close() releases the port and forgets the cookie', proxy.running === false && proxy.cookie === '');

// 8. wiring: the rest of the plugin must actually use the proxy
check('wiring: iframeSrc prefers the proxy', /get iframeSrc\(\) \{\s*\n\s*if \(this\.proxy\.running\) return this\.proxy\.baseUrl;/.test(template));
check('wiring: dsh is spawned with an OS-assigned internal port',
  template.includes("'--no-open', '--port', '0'"), 'expected --port 0 in the spawn args');
check('wiring: readiness is judged through the proxy, not the raw port',
  /const through = await probeServiceStatus\(this\.proxy\.port/.test(template));
check('wiring: stop() closes the proxy', /await this\.proxy\.close\(\);/.test(template));
check('wiring: the launch line is parsed for the INTERNAL port',
  /this\.internalPort = port;/.test(template));

// Tear everything down: the proxy first (it holds upstream sockets), then the
// stub. Without this the process waits on idle keep-alive sockets and the npm
// test chain stalls until the harness timeout.
await proxy.close();
upstream.closeAllConnections?.();
await new Promise((resolve) => {
  upstream.close(() => resolve());
  setTimeout(resolve, 500).unref?.();
});
console.log(`__CHECKS__ ${passed}/${total}`);
console.log(passed === total ? '\nproxy: OK' : `\nproxy: ${total - passed} FAILED`);
process.exit(passed === total ? 0 : 1);
