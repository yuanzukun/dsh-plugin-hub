/**
 * check-skin-fallback — the base notes-assistant profile must boot with NO web
 * profile and NO @linxin666 UI package installed.
 *
 * Two invariants:
 *   1. `dsh/profile/cordis.patch.yml` hard-mounts no @linxin666 package. A hard
 *      mount here would make a web-profile-less boot die with
 *      ERR_MODULE_NOT_FOUND.
 *   2. The plugin creates no directory links. Machines may still carry v1
 *      skin rows in the machine-level `$DSH_HOME/cordis.patch.yml` (skin-center
 *      0.4.x no longer writes them, but old installs can); the plugin's boot
 *      safety net is `buildSkinFallbackBlock`, which disables those rows per id
 *      for this profile. That net must stay in the source — it is the only thing
 *      between a stale global row and a broken boot.
 *
 * 2026-10-18: the opt-in sidebar skin center (settings.enableSkinCenter + the
 * "install into the sidebar profile" action) was removed. Skin is only used by
 * the main `web` profile (3080); the sidebar does not pursue it. The assertions
 * that used to pin the opt-in predicates went with the feature.
 */
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("..", import.meta.url));
const cordis = readFileSync(join(root, "dsh", "profile", "cordis.patch.yml"), "utf8");

// Mounted @linxin666 ids: `- id: X` immediately followed by `name: '@linxin666/…'`.
const mountRe = /-\s*id:\s*(\S+)\s*\n\s*name:\s*['"]@linxin666\//g;
const mounts = [...cordis.matchAll(mountRe)].map((m) => m[1]);

if (mounts.length > 0) {
  console.error(`\n${mounts.length} @linxin666 mount(s) in cordis.patch.yml: ${mounts.join(", ")}`);
  console.error("The base notes-assistant profile must stay @linxin666-free — skin belongs to the main web profile.");
  process.exit(1);
}

const templatePath = join(root, "obsidian", "main.template.js");
const template = readFileSync(templatePath, "utf8");
const problems = [];

// ── boot safety net: v1 machine-level skin rows must be disabled ─────────────
for (const [name, re, label] of [
  ["readGlobalSkinIds", /function readGlobalSkinIds\s*\(/, "readGlobalSkinIds"],
  ["buildSkinFallbackBlock", /function buildSkinFallbackBlock\s*\(/, "buildSkinFallbackBlock"],
  ["ensureObsidianPatch call", /buildSkinFallbackBlock\s*\(\s*home\s*\)/, "the buildSkinFallbackBlock(home) call"]
]) {
  if (!re.test(template)) {
    problems.push(`${label} is missing from obsidian/main.template.js — stale machine-level skin rows would make this profile fail to boot`);
  }
}

// ── the plugin must never create directory links again ──────────────────────
// This machine lost its entire harness home once, with a directory junction as
// the suspected vector; a global guard now denies link creation for agent shell
// tools. A `symlinkSync` from the Obsidian renderer is invisible to that guard,
// so the plugin must not be the one component still doing it.
const banned = [
  [/\bsymlinkSync\s*\(/, "symlinkSync(...)"],
  [/['"]junction['"]/, "'junction' as a link type"]
];
for (const [re, label] of banned) {
  if (re.test(template)) {
    problems.push(`obsidian/main.template.js calls ${label} — this plugin must not create directory links (see docs/changelog.md 2026-09-26 P2-D)`);
  }
}

if (problems.length > 0) {
  console.error("\n" + problems.map((p) => " - " + p).join("\n"));
  console.error("\nSee docs/changelog.md 2026-09-26 (P2-D) for why the mirror was retired.");
  process.exit(1);
}

console.log("skin-fallback check: ok (0 @linxin666 mounts in cordis.patch.yml; boot safety net present; no link creation in the plugin source)");
