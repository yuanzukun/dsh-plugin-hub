#!/usr/bin/env node
/**
 * check-mutation-anchors — the read-only half of the mutation sweep.
 *
 * The sweep itself (`scripts/qa/mutation-sweep.mjs`) writes to tracked files and restores them, so it can
 * never be a CI gate: a crash mid-run would leave a mutated tree. But if nobody runs it, its `from`
 * anchors rot — and a rotted anchor makes an entry report `ANCHOR-MISSING`, i.e. a verification step that
 * quietly stopped verifying. That is the failure this repo has paid for repeatedly (a guard that no
 * longer looks at anything), so the list is shared (`scripts/lib/mutation-entries.mjs`) and this gate
 * checks, fast and read-only, that every anchor still matches **exactly once**.
 *
 * What it does NOT do: run the mutations. Evidence that each guard actually reddens comes from running
 * `node scripts/qa/mutation-sweep.mjs` and reading its output; this gate only guarantees that the run
 * would still be testing what it claims to test.
 */
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { MUTATION_ENTRIES } from './lib/mutation-entries.mjs';

const repo = join(dirname(fileURLToPath(import.meta.url)), '..');
let failed = 0;
const fail = (message) => { failed += 1; console.error('FAIL  ' + message); };

const byFile = new Map();
for (const entry of MUTATION_ENTRIES) {
  if (entry.label === undefined || entry.file === undefined || entry.from === undefined || entry.to === undefined) {
    fail(`a mutation entry is incomplete: ${JSON.stringify(Object.keys(entry))}`);
    continue;
  }
  if (entry.from === entry.to) {
    fail(`"${entry.label}" mutates nothing (from === to)`);
    continue;
  }
  if (!byFile.has(entry.file)) {
    try {
      byFile.set(entry.file, readFileSync(join(repo, entry.file), 'utf8').replace(/\r\n/g, '\n'));
    } catch (error) {
      fail(`"${entry.label}": cannot read ${entry.file} (${String(error.message ?? error)})`);
      byFile.set(entry.file, null);
    }
  }
  const text = byFile.get(entry.file);
  if (text === null) continue;
  const occurrences = text.split(entry.from).length - 1;
  if (occurrences === 0) {
    fail(`"${entry.label}": its anchor no longer exists in ${entry.file} — the sweep would report ANCHOR-MISSING and verify nothing`);
  } else if (occurrences > 1) {
    fail(`"${entry.label}": its anchor matches ${occurrences} times in ${entry.file} — the sweep would rewrite the wrong occurrence (or refuse to run)`);
  }
}

// The two entries that closed REAL blind spots must keep pointing at the assertions that closed them;
// deleting such an assertion would silently re-open the hole this list exists to remember.
const healed = MUTATION_ENTRIES.filter((entry) => entry.fixedBy !== undefined);
for (const entry of healed) {
  const gateFile = entry.gate;
  let gateText = byFile.get(gateFile);
  if (gateText === undefined) {
    try { gateText = readFileSync(join(repo, gateFile), 'utf8').replace(/\r\n/g, '\n'); } catch { gateText = null; }
    byFile.set(gateFile, gateText);
  }
  const key = String(entry.fixedBy).split('(')[0].trim().slice(0, 40);
  if (gateText === null || !gateText.includes(key)) {
    fail(`"${entry.label}" records a past blind spot fixed by "${key}" — that assertion is gone from ${entry.gate}, so the hole is open again`);
  }
}

if (failed > 0) {
  console.error(`\nmutation-anchors: ${failed} failed`);
  process.exit(1);
}
console.log(`mutation-anchors: ok (${MUTATION_ENTRIES.length} anchors, each matching exactly once; ${healed.length} healed blind spots still named)`);
