// src/operations/exec-ops.ts — 外部命令类操作（dsh 标准卸载 / pnpm store prune）
// 这类操作的副作用发生在外部进程，无法本地备份；undo 语义为"补偿提示"而非文件恢复。
// 命令执行经注入的 CommandRunner（默认 spawnSync），argv 数组形态、无 shell。
//
// V4 升级：
//   1. 瞬态重试 —— spawn 失败且错误码可重试（EAGAIN/超时/句柄耗尽类）时最多退避重试 2 次；
//      非瞬态失败（如 ENOENT 命令不存在）立即失败，不做无意义重试
//   2. 超时上限 —— 单命令超时钳制在 MAX_COMMAND_TIMEOUT_MS 内，超时 fail-closed
//      返回 err 而非挂死；重试耗尽仍超时同样 err
//   3. 输出结构化 —— stdout/stderr/exitCode/durationMs/attempts 进入 preview（探针）
//      与 execute（真实命令）的 detail，随 step-done 落 WAL/审计链
//
// V5.8 升级：
//   1. SIGTERM→SIGKILL 升级 —— spawnSync 的 timeout 只发一次 SIGTERM，忽略
//      SIGTERM 的进程会让"5 分钟硬上限"失效（同步等待直到进程退出）。改用异步
//      spawn：超时先 SIGTERM（优雅），KILL_GRACE_MS 宽限后 SIGKILL（不可忽略）
//   2. 解析路径贯穿 —— validate 经注册表解析出的可执行实体（裸名/显式 env
//      路径/救援绝对路径）由 execute 复用，消灭"探测的是 A、执行的是 B"
//   3. spawn 错误码进消息 —— classifyFailureMode 按 `/spawn .* ENOENT/i` 归类
//      dependency、EAGAIN 归类 resource，失败档案得到正确处方而非"未知根因"
import { spawn } from 'child_process'

import type { NukeError, PluginName, ProfileName, Result } from '../contracts/base'
import { err, ok } from '../contracts/base'
import type { IToolRegistry, ToolResolution } from '../contracts/tool.contract'
import type {
  CleanOperation, CommandExecutionDetail, ExecutedStep, OperationPlan, TxContext,
} from '../contracts/transaction'
import type { IInputValidator } from '../contracts/validation'
import { adaptSpawnInvocation } from '../infra/cmd-shim'
import { createToolRegistry } from '../infra/tool-registry'

/** 命令运行器返回形态（error/signal 为 V4 增量可选字段，旧注入实现无需改动） */
export interface CommandResult {
  readonly status: number | null
  readonly stdout: string
  readonly stderr: string
  /** spawn 层错误（如 ENOENT/EAGAIN/ETIMEDOUT）；缺省 = 运行器未提供 */
  readonly error?: unknown
  /** 子进程被信号终止时的信号名（超时终止为 SIGTERM/SIGKILL） */
  readonly signal?: string | null
}

/** V5.8：运行器允许返回 Promise（默认实现改为异步 spawn 以支持 SIGKILL 升级）；
 *  同步注入实现（测试桩/旧代码）天然兼容 —— 返回值协变无需改动 */
export type CommandRunner = (
  cmd: string, args: readonly string[], opts: { cwd?: string; timeoutMs: number },
) => CommandResult | Promise<CommandResult>

/** SIGTERM 宽限期：优雅终止窗口过后升级 SIGKILL（不可忽略、不可捕获） */
export const KILL_GRACE_MS = 5_000

/** 输出捕获的内存上限（与 spawnSync 默认 maxBuffer 同量级：失控进程在超时
 *  窗口内的输出不允许无界膨胀；超出部分丢弃，最终截断到 MAX_CAPTURE_CHARS） */
const MAX_STREAM_CHARS = 1_000_000

/** 异步 spawn 包装（V5.8）：
 *  - 归一化 stdout/stderr（spawn 失败时可能为 null）—— 调用方拿到的永远是 string
 *  - 透传 error/signal 供瞬态判定与超时识别
 *  - 超时纪律两段式：SIGTERM（优雅）→ KILL_GRACE_MS 宽限 → SIGKILL（硬终止）。
 *    spawnSync 只发一次 SIGTERM，忽略 SIGTERM 的进程会让同步等待永久挂死，
 *    "5 分钟硬上限"形同虚设 —— 本实现保证上限是真的上限
 *  - 超时击杀归一化为 ETIMEDOUT 错误码（与 spawnSync 语义对齐，
 *    上游 isTimedOut/isRetryable 无需感知实现差异） */
export const defaultCommandRunner: CommandRunner = (cmd, args, opts) =>
  new Promise<CommandResult>(resolve => {
    // Windows .cmd/.bat shim 经 ComSpec 适配（直接 spawn 会抛 EINVAL，见 cmd-shim）
    const t = adaptSpawnInvocation(cmd, args)
    const child = spawn(t.file, t.args, { ...(opts.cwd !== undefined ? { cwd: opts.cwd } : {}) })
    let stdout = ''
    let stderr = ''
    let settled = false
    let escalationTimer: NodeJS.Timeout | null = null

    const capture = (stream: NodeJS.ReadableStream | null, sink: (s: string) => void): void => {
      if (stream === null) return
      stream.setEncoding('utf-8')
      stream.on('data', (chunk: string) => { sink(chunk) })
    }
    capture(child.stdout, s => { if (stdout.length < MAX_STREAM_CHARS) stdout += s })
    capture(child.stderr, s => { if (stderr.length < MAX_STREAM_CHARS) stderr += s })

    const finish = (r: CommandResult): void => {
      if (settled) return
      settled = true
      if (escalationTimer !== null) clearTimeout(escalationTimer)
      resolve(r)
    }

    const timeoutTimer = setTimeout(() => {
      child.kill('SIGTERM')
      escalationTimer = setTimeout(() => { child.kill('SIGKILL') }, KILL_GRACE_MS)
    }, opts.timeoutMs)

    child.on('error', err => {
      clearTimeout(timeoutTimer)
      finish({ status: null, stdout, stderr, error: err })
    })
    child.on('close', (code, signal) => {
      clearTimeout(timeoutTimer)
      const killedByTimeout = escalationTimer !== null
      finish({
        status: code,
        stdout, stderr,
        // 超时击杀（无干净退出码）→ 合成 ETIMEDOUT 错误码，语义与 spawnSync 对齐；
        // 恰好在超时瞬间自然退出的竞态（code 非 null）→ 如实上报退出码
        ...(killedByTimeout && code === null
          ? {
              error: Object.assign(new Error(`spawn ${cmd} ETIMEDOUT`), { code: 'ETIMEDOUT' }),
              signal: signal ?? 'SIGTERM',
            }
          : signal !== null ? { signal } : {}),
      })
    })
  })

// ─── V4：瞬态重试与超时纪律 ─────────────────────────────────

/** 单命令超时硬上限（5 分钟）：任何配置值都被钳制在此之下，
 *  保证最坏情况（首跑 + 2 次重试全超时）也有界，绝不无限挂死。 */
export const MAX_COMMAND_TIMEOUT_MS = 300_000

/** 视为瞬态可重试的 spawn 错误码（EAGAIN/超时类）。
 *  ENOENT（命令不存在）是永久性错误，重试毫无意义 —— 不在列表中。 */
const RETRYABLE_ERRNOS: ReadonlySet<string> = new Set([
  'EAGAIN',      // 资源暂不可用
  'ETIMEDOUT',   // 命令超时被终止
  'EMFILE',      // 进程级句柄耗尽
  'ENFILE',      // 系统级文件表满
  'EINTR',       // 被信号打断
  'EBUSY',       // 资源占用（Windows 常见）
])

/** 结构化捕获中 stdout/stderr 的截断上限（字节级安全边界：WAL/审计链不容噪声膨胀） */
const MAX_CAPTURE_CHARS = 4_000

/** 瞬态重试策略 */
export interface CommandRetryPolicy {
  /** 重试次数上限（不含首次执行），默认 2 */
  readonly maxRetries: number
  /** 首次退避基准（ms）；第 k 次重试前等待 base×2^(k-1) */
  readonly baseDelayMs: number
}

export const DEFAULT_RETRY_POLICY: CommandRetryPolicy = { maxRetries: 2, baseDelayMs: 25 }

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms))
}

/** 判定一次命令结果是否值得重试：
 *  - 有退出码（status !== null）= 命令跑完自己失败了 → 不重试（业务失败）
 *  - status === null 且 error.code 命中瞬态集合 → 重试
 *  - status === null 且无 error 信息（自定义运行器/被信号击杀）→ 重试
 *    （fail-safe：拿不到根因时宁可多试一次，也不把可自愈抖动升级为用户可见错误） */
function isRetryable(r: CommandResult): boolean {
  if (r.status !== null) return false
  const code = (r.error as { code?: unknown } | null | undefined)?.code
  if (typeof code === 'string') return RETRYABLE_ERRNOS.has(code)
  return true
}

/** 是否因超时终止：spawnSync 超时以 ETIMEDOUT 错误码或 SIGTERM 信号呈现 */
function isTimedOut(r: CommandResult): boolean {
  const code = (r.error as { code?: unknown } | null | undefined)?.code
  return code === 'ETIMEDOUT' || r.signal === 'SIGTERM'
}

/** 带瞬态重试的命令执行：返回结构化捕获（含总尝试次数与总耗时） */
export async function runCommandWithRetry(
  run: CommandRunner,
  cmd: string,
  args: readonly string[],
  opts: { cwd?: string; timeoutMs: number },
  retry: CommandRetryPolicy = DEFAULT_RETRY_POLICY,
): Promise<CommandExecutionDetail> {
  // 超时上限钳制：配置值再大也不能突破硬顶（fail-closed 的物理保证）
  const timeoutMs = Math.min(Math.max(1, Math.round(opts.timeoutMs)), MAX_COMMAND_TIMEOUT_MS)
  const startedAt = Date.now()
  let attempts = 0
  let last: CommandResult
  for (;;) {
    attempts++
    // V5.8：运行器可异步（默认实现）—— await 对同步返回值同样安全
    last = await run(cmd, args, { ...(opts.cwd ? { cwd: opts.cwd } : {}), timeoutMs })
    if (!isRetryable(last) || attempts > retry.maxRetries) break
    await sleep(Math.min(1_000, retry.baseDelayMs * 2 ** (attempts - 1)))
  }
  return {
    cmd,
    args,
    exitCode: last.status,
    stdout: last.stdout.slice(0, MAX_CAPTURE_CHARS),
    stderr: last.stderr.slice(0, MAX_CAPTURE_CHARS),
    durationMs: Date.now() - startedAt,
    attempts,
    timedOut: isTimedOut(last),
    // V5.1：透传 spawn 错误码 —— ENOENT（未找到）与"执行了但退出非 0"语义迥异
    ...(typeof (last.error as { code?: unknown } | null | undefined)?.code === 'string'
      ? { errorCode: (last.error as { code: string }).code }
      : {}),
  }
}

export interface ExecOpOptions {
  readonly validator: IInputValidator
  readonly runCommand?: CommandRunner
  readonly commandTimeoutMs?: number
  /** V4 增量：瞬态重试策略（缺省 = 最多 2 次退避重试） */
  readonly retry?: CommandRetryPolicy
  /** V5.1 增量：命令解析注入点（PATH 救援探测；缺省 = bin-resolver 真实实现，测试可注入） */
  readonly resolveCommand?: (cmd: string) => { readonly path: string; readonly dir: string } | null
  /** V5.2 增量：共享工具注册表（解析单一事实源；缺省 = 用本操作的 run/retry 组装私有注册表） */
  readonly toolRegistry?: IToolRegistry
}

/** 用本操作的 run/retry 组装私有注册表（未注入共享注册表时的兼容路径） */
function buildPrivateRegistry(
  options: ExecOpOptions,
  run: CommandRunner,
  retry: CommandRetryPolicy,
): IToolRegistry {
  return createToolRegistry({
    // 探测适配器：复用 runCommandWithRetry 的重试/超时纪律，映射到注册表探针形态
    probe: (cmdOrPath: string) =>
      runCommandWithRetry(run, cmdOrPath, ['--version'], { timeoutMs: 5_000 }, retry)
        .then(d => ({
          status: d.exitCode,
          stdout: d.stdout,
          stderr: d.stderr,
          ...(d.errorCode !== undefined ? { errorCode: d.errorCode } : {}),
        })),
    // 注意：注入解析器"返回 null"就是它的判定结果，不能穿透到默认解析器
    ...(options.resolveCommand ? { resolveCommand: options.resolveCommand } : {}),
  })
}

/** 经注册表校验工具可用性（缺失 → 结构化错误，detail/fixHint 来自单一事实源；
 *  成功 → 返回解析结果，调用方可将探测通过的同一可执行实体贯穿到 execute） */
async function requireTool(
  registry: IToolRegistry, tool: string,
): Promise<Result<ToolResolution, NukeError & { details?: { resolution?: ToolResolution } }>> {
  const res = await registry.resolve(tool)
  if (res.status === 'missing') {
    return err({
      code: 'E_IO',
      message: `${res.detail}: ${res.fixHint}`,
      details: { resolution: res },
    })
  }
  return ok(res)
}

/** 失败路径的统一错误构造：结构化捕获进 details（审计链可见）。
 *  V5.8：spawn 层错误码进消息文本 —— classifyFailureMode 据此把
 *  "spawn ENOENT" 归类 dependency（装包/修 PATH 的处方）、EAGAIN 归类
 *  resource（瞬态、值得引擎重试），而非一律落进"未知根因" */
function commandError(context: string, cap: CommandExecutionDetail): NukeError {
  const tail = (cap.stderr || cap.stdout).trim().slice(0, 200)
  const message = cap.timedOut
    ? `${context}超时（${cap.durationMs}ms / 上限 ${MAX_COMMAND_TIMEOUT_MS}ms 内未完成，fail-closed 拒绝）`
    : cap.exitCode === null
      ? `${context}失败（进程未正常退出${cap.errorCode !== undefined ? `，spawn ${cap.cmd} ${cap.errorCode}` : ''}）${tail.length > 0 ? `: ${tail}` : ''}`
      : `${context}失败（exit ${cap.exitCode}）: ${tail}`
  return {
    code: 'E_IO',
    message,
    details: { command: cap },
  }
}

// ─── standard-remove ───────────────────────────────────────

export function makeStandardRemoveOp(
  target: PluginName, profile: ProfileName, options: ExecOpOptions,
): CleanOperation {
  const run = options.runCommand ?? defaultCommandRunner
  const timeoutMs = options.commandTimeoutMs ?? 60_000
  const retry = options.retry ?? DEFAULT_RETRY_POLICY
  // V5.2：CLI 解析委托注册表（共享实例优先，缺省私有组装 —— 语义只有一份）
  const registry = options.toolRegistry ?? buildPrivateRegistry(options, run, retry)
  // V5.8：validate 解析出的可执行实体（裸名/显式 env 路径/救援绝对路径），
  // execute 复用同一实体 —— 消灭"validate 经救援放行、execute 裸名再 ENOENT"
  // 的语义裂缝。引擎保证 validate 先于 execute；操作实例单事务生命周期，无跨程泄漏
  let resolvedExecPath: string | null = null

  return {
    id: `op-standard-remove:${target}`,
    action: 'standard-remove',
    target,

    async preview(): Promise<OperationPlan> {
      // 只读探针（--version）：dry-run 报告即可见 CLI 可用性与版本输出，零副作用
      const probe = await runCommandWithRetry(run, 'dsh', ['--version'], { timeoutMs: 5_000 }, retry)
      const probeNote = probe.exitCode === 0
        ? `（CLI 探针 ${probe.durationMs}ms）`
        : `（⚠ CLI 探针 exit=${probe.exitCode ?? 'null'}，validate 将复核）`
      return {
        summary: `dsh plugin --profile ${profile} remove ${target}（标准卸载）${probeNote}`,
        touchedPaths: [],
        estimatedBytesReclaimable: 0,
        requiresExclusiveLock: true,   // 触发外部包管理，独占
        command: probe,
      }
    },

    async validate(): Promise<Result<void>> {
      const name = options.validator.validatePluginName(target)
      if (!name.ok) {
        return err({
          code: 'E_VALIDATION',
          message: `插件名非法: ${target}`,
          details: { violations: name.error },
        })
      }
      const prof = options.validator.validateProfileName(profile)
      if (!prof.ok) {
        return err({
          code: 'E_VALIDATION',
          message: `profile 名非法: ${profile}`,
          details: { violations: prof.error },
        })
      }
      // V5.2：CLI 可用性委托工具注册表（显式 env → PATH → 救援三段式，语义单一事实源）
      // V5.8：解析成功的可执行实体 memo 给 execute —— 探测谁就执行谁
      const tool = await requireTool(registry, 'dsh')
      if (!tool.ok) return tool
      resolvedExecPath = tool.value.path ?? 'dsh'
      return ok(undefined)
    },

    async execute(): Promise<Result<ExecutedStep>> {
      const cap = await runCommandWithRetry(
        run, resolvedExecPath ?? 'dsh', ['plugin', '--profile', profile, 'remove', target], { timeoutMs }, retry,
      )
      if (cap.exitCode !== 0) {
        return err(commandError('dsh 卸载', cap))
      }
      return ok({
        outcome: {
          bytesFreed: 0,
          message: `标准卸载完成: ${target}（${cap.attempts} 次尝试，${cap.durationMs}ms）`,
          command: cap,
        },
        backup: null,   // 外部系统副作用，undo 为补偿提示
      })
    },

    async undo(): Promise<Result<void>> {
      // 外部进程操作不可本地恢复；补偿动作 = 重新安装提示（不自动执行，防副作用放大）
      return ok(undefined)
    },
  }
}

// ─── pnpm-store-prune（aggressive 专属，全局一次） ─────────

export function makePnpmPruneOp(
  profile: ProfileName, profileDirOf: (ctx: TxContext) => string, options: ExecOpOptions,
): CleanOperation {
  const run = options.runCommand ?? defaultCommandRunner
  const timeoutMs = options.commandTimeoutMs ?? 120_000
  const retry = options.retry ?? DEFAULT_RETRY_POLICY
  // V5.2：CLI 解析委托注册表（与 standard-remove 同一事实源）
  const registry = options.toolRegistry ?? buildPrivateRegistry(options, run, retry)
  // V5.8：与 standard-remove 同一纪律 —— validate 探测谁，execute 就执行谁
  let resolvedExecPath: string | null = null

  return {
    id: 'op-pnpm-store-prune:global',
    action: 'pnpm-store-prune',
    target: '*store*' as PluginName,

    async preview(): Promise<OperationPlan> {
      // 只读探针：与 standard-remove 同纪律
      const probe = await runCommandWithRetry(run, 'pnpm', ['--version'], { timeoutMs: 5_000 }, retry)
      const probeNote = probe.exitCode === 0
        ? `（CLI 探针 ${probe.durationMs}ms）`
        : `（⚠ CLI 探针 exit=${probe.exitCode ?? 'null'}，validate 将复核）`
      return {
        summary: `pnpm store prune（清理 profile ${profile} 关联的 pnpm 全局 store 未引用包）${probeNote}`,
        touchedPaths: [],
        estimatedBytesReclaimable: 0,   // 体量由 pnpm 决定，无法预估
        requiresExclusiveLock: true,
        command: probe,
      }
    },

    async validate(): Promise<Result<void>> {
      // V5.2：委托工具注册表（三段式：env 覆盖 → PATH → 救援；旗标差异不再误报）
      // V5.8：解析成功的可执行实体 memo 给 execute —— 探测谁就执行谁
      const tool = await requireTool(registry, 'pnpm')
      if (!tool.ok) return tool
      resolvedExecPath = tool.value.path ?? 'pnpm'
      return ok(undefined)
    },

    async execute(ctx): Promise<Result<ExecutedStep>> {
      const cap = await runCommandWithRetry(
        run, resolvedExecPath ?? 'pnpm', ['store', 'prune'], { cwd: profileDirOf(ctx), timeoutMs }, retry,
      )
      if (cap.exitCode !== 0) {
        return err(commandError('pnpm store prune', cap))
      }
      return ok({
        outcome: {
          bytesFreed: 0,
          message: `pnpm store prune 完成（实际回收以 pnpm 输出为准；${cap.attempts} 次尝试，${cap.durationMs}ms）`,
          command: cap,
        },
        backup: null,
      })
    },

    async undo(): Promise<Result<void>> { return ok(undefined) },
  }
}
