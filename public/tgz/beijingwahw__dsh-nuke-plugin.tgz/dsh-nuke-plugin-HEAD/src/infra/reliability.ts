// src/infra/reliability.ts — IReliabilityModel 实现
// 数据源是审计链而非独立状态文件：单一事实源，永不与实际历史漂移；
// 审计 hash chain 的完整性同时就是可靠性数据的信任根。
//
// 统计方法（经验贝叶斯分层收缩）：
//   全局层  μ = (S + K·μ₀)/(S+F+K)   —— pooled 成功率向设计先验 μ₀ 收缩
//   动作层  α = μκ + s_a,  β = (1-μ)κ + f_a
//   p̂_a   = α/(α+β)                  —— 向全局均值收缩的后验均值
//   CI95   = Wilson score interval    —— 以 (p̂_a, α+β) 为输入的 Wilson 区间
//   selfWeight = (s_a+f_a)/(s_a+f_a+κ) —— 收缩系数（可解释）
// κ 是动作层先验强度：动作观测数 << κ 时几乎完全借力全局，>> κ 时自信。
//
// 设计先验（V5.1.1 冷启动修复）：
//   旧全局层用 Laplace +1/+2 → 零历史时 μ=0.5（硬币先验）。硬币先验对
//   "无信息"是中立的，但对本域是错的：事务引擎 validate 前置（失败在
//   commit 前被拦截）、编辑前快照备份、目录改名进回收区、Saga 回滚 ——
//   步骤失败是设计上的例外而非常态。更致命的是先知按 Saga 连乘
//   P = ∏p_i：0.5⁴=6%、0.5¹⁴=0.006%，把"零信息"误渲染为"高故障"，
//   用户看到的是吓人的低成功率而非诚实的"尚无数据"。
//   修复：全局层向设计先验 μ₀=0.95 收缩（强度 K=20 —— 约 20 次全局
//   观测后历史数据权重过半，先验随数据自动稀释）；零历史时 μ=μ₀，
//   0.95⁴=81%、0.95¹⁴=49%，与"设计上会成功"的直觉一致，且置信度
//   仍诚实标注 low、CI 仍宽（Wilson 不假装知道）。
//
// CI 升级说明（正态近似 → Wilson）：
//   Beta 正态近似在小区间（n 小 / p̂ 近 0 或 1）会给出越界 [0,1] 的区间，
//   只能靠 clamp 掩盖 —— 形同虚设。Wilson score interval 以
//   p̂ + z²/2n 为中心、以 (1+z²/n)⁻¹ 收缩幅度，天然有界、小样本偏斜
//   正确，是计数型比例区间的小样本标准解。此处 p̂ 取收缩后验均值、
//   n 取后验有效样本量 α+β —— 区间与点估计同源（都来自同一 Beta 后验）。
//
// 校准分布升级（等权分位数 → 时间加权分位数）：
//   估算精度会漂移（工具链/磁盘形态变化），老样本的可信度自然衰减。
//   每个 ratio 样本按其时间戳获得指数衰减权重（半衰期可配，默认 30 天），
//   分位数在"权重代表位置"上做线性插值 —— 全 1 权重时严格退化为
//   旧公式 pos=(n-1)·q（兼容既有语义），近期样本权重更高则区间整体
//   向近期观测偏移。
import {
  classifyFailureMode, DEFAULT_RETRY_EFFICACY, MODE_TRANSIENCE, retryAdjustedProbability,
} from '../contracts/failure.contract'
import type { FailureMode, FailureModeStat } from '../contracts/failure.contract'
import type { IAuditLog } from '../contracts/logging'
import { OP_AUDIT_PREFIX } from '../contracts/logging'
import type {
  ActionReliability, CalibrationSummary, DurationSummary, IReliabilityModel,
  RetryEfficacyStat, SizeBucket,
} from '../contracts/reliability.contract'

// ─── V5.2：大小桶边界（操作级协变量调制） ─────────────────────
// 大目录删除的失败模式（EBUSY/长路径/超时/句柄耗尽）与 5MB 级完全不同，
// "remove-node-modules 的成功率"应按体量分层。桶先验强度 κ_b=5：
// 桶内样本天然稀疏（动作层样本被 3 个桶摊薄），更快向动作层让位。
const SIZE_BUCKETS: readonly { readonly bucket: SizeBucket; readonly min: number; readonly max: number | null }[] = [
  { bucket: 'small', min: 0, max: 1024 * 1024 },                    // < 1MB
  { bucket: 'medium', min: 1024 * 1024, max: 100 * 1024 * 1024 },   // 1MB ~ 100MB
  { bucket: 'large', min: 100 * 1024 * 1024, max: null },           // ≥ 100MB
]

function bucketOf(sizeBytes: number): (typeof SIZE_BUCKETS)[number] | null {
  for (const b of SIZE_BUCKETS) {
    if (sizeBytes >= b.min && (b.max === null || sizeBytes < b.max)) return b
  }
  return null
}

/** 桶层先验强度：小于动作层 κ=10 —— 桶样本被三桶摊薄，更快向动作层让位 */
const BUCKET_KAPPA = 5

/** V5.4 重试疗效先验强度：营救池样本 << 4 时几乎完全借力先验
 *  （1-(1-0.5)²=0.75），≥ 4 次重试观测后自身数据权重过半 */
const RETRY_PRIOR_WEIGHT = 4

export interface ReliabilityModelOptions {
  readonly audit: IAuditLog
  /** 经验贝叶斯先验强度 κ（默认 10：约 10 次观测后自身数据过半） */
  readonly shrinkage?: number
  /**
   * 设计先验成功率 μ₀（默认 0.95）：零历史时全局层的收缩锚点。
   * 取值依据：validate 前置 + 快照备份 + 回收区改名 + Saga 回滚的事务
   * 引擎，步骤失败是设计上的例外。可配置（如观察到真实环境更脆弱可调低）。
   */
  readonly priorSuccessProbability?: number
  /** 设计先验强度 K（默认 20：约 20 次全局观测后历史数据权重过半） */
  readonly priorStrength?: number
  /** 校准分布所需最少样本数（默认 3，不足则诚实返回 null） */
  readonly minCalibrationSamples?: number
  /** 校准样本权重半衰期（ms，默认 30 天）：权重 = 0.5^(年龄/半衰期)。
   *  年龄以该动作样本中最新的时间戳为基准 —— 无墙钟依赖，结果确定。
   *  Infinity = 不做时间衰减（全 1 权重，等价于未加权分位数）。 */
  readonly calibrationHalfLifeMs?: number
  /** V5.3：重试调整投影的引擎重试次数上限（默认 2，与引擎默认重试策略
   *  对齐 —— 模型描述的必须是将要发生的引擎行为）。 */
  readonly retryAttempts?: number
  /** V5.3：单次重试对瞬态失败的成功率（默认 0.5，见 failure.contract） */
  readonly retryEfficacy?: number
  /** 只统计该时间之后的观测（ISO；默认全部） */
  readonly since?: string
}

interface CalibrationSample {
  readonly value: number
  readonly atMs: number   // Date.parse(timestamp)；NaN = 时间不可知
}

interface ActionStats {
  successes: number
  failures: number
  samples: CalibrationSample[]
  /** V5.4：耗时样本（value=durationMs，含重试退避等待 —— 用户视角的墙钟） */
  durations: CalibrationSample[]
  /** V5.2：大小桶统计（estimated 可归桶的成败样本；双向归桶保证无偏） */
  buckets: Map<SizeBucket, { successes: number; failures: number }>
  /** V5.3：失败模式计数（错误文本 → 分类学；写方也可直接给 failureMode） */
  modes: Map<FailureMode, number>
}

function quantile(sorted: readonly number[], q: number): number {
  if (sorted.length === 0) return 0
  const pos = (sorted.length - 1) * q
  const lo = Math.floor(pos)
  const hi = Math.ceil(pos)
  if (lo === hi) return sorted[lo]!
  return sorted[lo]! + (sorted[hi]! - sorted[lo]!) * (pos - lo)
}

function clamp01(n: number): number {
  return Math.min(1, Math.max(0, n))
}

/** Wilson score interval：输入比例点估计与有效样本量，返回 95% 区间。
 *  n ≤ 0（零有效样本）→ [0,1]：诚实承认一无所知。 */
function wilsonInterval(pHat: number, n: number, z = 1.96): [number, number] {
  if (n <= 0) return [0, 1]
  const z2 = z * z
  const denom = 1 + z2 / n
  const center = (pHat + z2 / (2 * n)) / denom
  const spread = (z / denom) * Math.sqrt((pHat * (1 - pHat)) / n + z2 / (4 * n * n))
  return [clamp01(center - spread), clamp01(center + spread)]
}

interface WeightedSample {
  readonly value: number
  readonly weight: number
}

/** 加权分位数（线性插值）：样本 i 的代表位置 = 其权重区间的起点
 *  （前缀权和 C_{i-1}），插值目标 t = q·(W-1) —— 与未加权公式
 *  pos=(n-1)·q 完全同构（全 1 权重时逐位等价）。 */
function weightedQuantile(sorted: readonly WeightedSample[], q: number): number {
  const n = sorted.length
  if (n === 0) return 0
  const anchors: number[] = []
  let cum = 0
  for (const s of sorted) {
    anchors.push(cum)
    cum += s.weight
  }
  const W = cum
  if (W <= 0) {
    // 权重全部衰减为 0（理论边界）：退化为未加权分位数
    return quantile(sorted.map(s => s.value), q)
  }
  const t = q * (W - 1)
  if (t <= anchors[0]!) return sorted[0]!.value
  if (t >= anchors[n - 1]!) return sorted[n - 1]!.value
  for (let i = 0; i < n - 1; i++) {
    const a = anchors[i]!
    const b = anchors[i + 1]!
    if (t >= a && t < b) {
      if (b <= a) return sorted[i]!.value   // 零权重样本无跨度
      return sorted[i]!.value
        + (sorted[i + 1]!.value - sorted[i]!.value) * ((t - a) / (b - a))
    }
  }
  return sorted[n - 1]!.value
}

export async function createReliabilityModel(
  options: ReliabilityModelOptions,
): Promise<IReliabilityModel> {
  const kappa = options.shrinkage ?? 10
  const mu0 = options.priorSuccessProbability ?? 0.95
  const priorK = options.priorStrength ?? 20
  const minCal = options.minCalibrationSamples ?? 3
  const halfLifeMs = options.calibrationHalfLifeMs ?? 30 * 24 * 3600 * 1000
  const retryAttempts = options.retryAttempts ?? 2
  const retryEfficacy = options.retryEfficacy ?? DEFAULT_RETRY_EFFICACY

  // ── 采集：一次性读审计链，按动作聚合 ───────────────────────
  const entries = await options.audit.query(options.since !== undefined ? { since: options.since } : {})
  const stats = new Map<string, ActionStats>()
  let pooledS = 0
  let pooledF = 0
  // V5.4 重试疗效营救池（全局层 —— 按动作分层样本过稀，全局池才有统计力）
  let retryPool = 0
  let retryRescued = 0
  for (const e of entries) {
    if (!e.action.startsWith(OP_AUDIT_PREFIX)) continue
    if (e.outcome === 'skipped') continue   // 策略性跳过不是可靠性证据
    const action = e.action.slice(OP_AUDIT_PREFIX.length)
    const s = stats.get(action)
      ?? {
        successes: 0, failures: 0, samples: [] as CalibrationSample[],
        durations: [] as CalibrationSample[],
        buckets: new Map<SizeBucket, { successes: number; failures: number }>(),
        modes: new Map<FailureMode, number>(),
      }
    const est = (e.detail as { estimated?: unknown }).estimated
    const act = (e.detail as { actual?: unknown }).actual
    const durMs = (e.detail as { durationMs?: unknown }).durationMs
    if (e.outcome === 'success') {
      s.successes++
      pooledS++
      // 校准样本：detail { estimated, actual }（estimated>0 时才有意义）
      if (typeof est === 'number' && typeof act === 'number' && est > 0) {
        s.samples.push({ value: act / est, atMs: Date.parse(e.timestamp) })
      }
    } else {
      s.failures++
      pooledF++
      // V5.3 失败模式归因：优先取写方显式记录的 failureMode（事务引擎
      // 已分类），缺失（旧条目/外部写入）则从 error 文本现场分类 ——
      // 分类学在契约层单一事实源，两侧规则永不漂移。
      const detail = e.detail as { failureMode?: unknown; error?: unknown }
      const mode: FailureMode = typeof detail.failureMode === 'string'
        && detail.failureMode in MODE_TRANSIENCE
        ? detail.failureMode as FailureMode
        : classifyFailureMode(typeof detail.error === 'string' ? detail.error : null)
      s.modes.set(mode, (s.modes.get(mode) ?? 0) + 1)
    }
    // V5.4 耗时样本：成败双向计入（失败步骤的耗时同样是"这步要多久"
    // 的证据）；墙钟口径含重试退避等待 —— 用户等的就是这个数
    if (typeof durMs === 'number' && Number.isFinite(durMs) && durMs >= 0) {
      s.durations.push({ value: durMs, atMs: Date.parse(e.timestamp) })
    }
    // V5.4 重试营救池：retries ≥ 1 = 引擎真的重试过（成功条目仅在
    // retries>0 时携带该字段，失败条目恒携带 —— 写方语义见事务引擎）
    const retries = (e.detail as { retries?: unknown }).retries
    if (typeof retries === 'number' && retries >= 1) {
      retryPool++
      if (e.outcome === 'success') retryRescued++
    }
    // V5.2 大小桶：成败双向归桶（estimated>0 即可归桶；失败样本同样
    // 带 estimated —— 事务引擎失败审计已记录预估量，负证据不丢失）
    if (typeof est === 'number' && est > 0) {
      const b = bucketOf(est)
      if (b) {
        const bs = s.buckets.get(b.bucket) ?? { successes: 0, failures: 0 }
        if (e.outcome === 'success') bs.successes++
        else bs.failures++
        s.buckets.set(b.bucket, bs)
      }
    }
    stats.set(action, s)
  }

  // 全局层：pooled 成功率向设计先验 μ₀ 收缩（强度 K）。
  // 零历史 → μ = μ₀（0.95）；数据累积 → 先验权重 1/(n+K) 自动稀释。
  const mu = (pooledS + priorK * mu0) / (pooledS + pooledF + priorK)
  const sampleCount = pooledS + pooledF

  // ── V5.4 重试疗效学习 ─────────────────────────────────────
  // 营救池（retries≥1 的步骤）→ 最终营救率（向先验收缩）→ 反解单次疗效。
  //   r̂ = (rescued + a·r₀)/(pool + a)，r₀ = 1-(1-e₀)^R（先验的"总营救率"口径）
  //   ê = 1-(1-r̂)^(1/R)（单次疗效 —— 数据由当前 R 产生时严格往返：
  //   r̂=0.64, R=2 → ê=0.4 → 复合回 1-(1-0.4)²=0.64；配置变更 R 时
  //   按单次疗效外推，语义忠实于"每次重试的独立效果"）
  // 显式配置 options.retryEfficacy 时投影取配置值（用户显式指定优先），
  // 学习统计照常暴露（观测数据的价值不因配置覆盖而消失）。
  const priorRescueRate = retryAdjustedProbability(0, 1, retryAttempts, retryEfficacy)
  const learnedRescueRate = retryPool > 0
    ? (retryRescued + RETRY_PRIOR_WEIGHT * priorRescueRate) / (retryPool + RETRY_PRIOR_WEIGHT)
    : priorRescueRate
  const perAttemptEfficacy = retryAttempts > 0
    ? 1 - (1 - learnedRescueRate) ** (1 / retryAttempts)
    : retryEfficacy
  const retryEfficacyStat: RetryEfficacyStat = {
    rescueRate: learnedRescueRate,
    perAttemptEfficacy,
    pool: retryPool,
    rescued: retryRescued,
    selfWeight: retryPool / (retryPool + RETRY_PRIOR_WEIGHT),
  }
  const efficacyForProjection = options.retryEfficacy ?? perAttemptEfficacy

  /** 校准样本 → 时间加权样本集（按值升序，权重随年龄指数衰减） */
  function weightedSamples(samples: readonly CalibrationSample[]): WeightedSample[] {
    const finite = samples.map(x => x.atMs).filter(v => Number.isFinite(v))
    const tRef = finite.length > 0 ? Math.max(...finite) : null
    return samples.map(x => ({
      value: x.value,
      weight: tRef !== null && Number.isFinite(x.atMs)
        ? 0.5 ** (Math.max(0, tRef - x.atMs) / halfLifeMs)
        : 1,   // 时间不可知的样本不降权（保守计入，宁可多信不可盲弃）
    })).sort((a, b) => a.value - b.value)
  }

  function build(
    action: string,
    s: ActionStats | undefined,
    sizeBytes?: number,
  ): ActionReliability {
    const succ = s?.successes ?? 0
    const fail = s?.failures ?? 0
    const alpha = mu * kappa + succ
    const beta = (1 - mu) * kappa + fail
    let mean = alpha / (alpha + beta)
    let ci: readonly [number, number]
    const selfWeight = (succ + fail) / (succ + fail + kappa)
    let sizeBucket: ActionReliability['sizeBucket']

    // V5.2 桶层调制：α_b = p_action·κ_b + s_b, β_b = (1-p_action)·κ_b + f_b
    //（三层收缩：桶 → 动作 → 全局 → 设计先验；κ_b=5）
    // 注意：selfWeight 保持动作层口径（"该动作有多少自身历史"），
    // 桶层权重单独由 sizeBucket.selfWeight 表达 —— 两个语义不混用。
    // V5.6：posterior 暴露最终层 Beta 参数（桶调制生效时为桶层后验）——
    // Thompson 采样 / 探索智能的输入，与 mean 点估计严格同源。
    let posterior: { readonly alpha: number; readonly beta: number }
    if (typeof sizeBytes === 'number' && sizeBytes >= 0) {
      const b = bucketOf(sizeBytes)
      if (b) {
        const bs = s?.buckets.get(b.bucket) ?? { successes: 0, failures: 0 }
        const nB = bs.successes + bs.failures
        const alphaB = mean * BUCKET_KAPPA + bs.successes
        const betaB = (1 - mean) * BUCKET_KAPPA + bs.failures
        mean = alphaB / (alphaB + betaB)
        ci = wilsonInterval(mean, alphaB + betaB)
        posterior = { alpha: alphaB, beta: betaB }
        sizeBucket = {
          bucket: b.bucket,
          rangeBytes: [b.min, b.max],
          samples: nB,
          selfWeight: nB / (nB + BUCKET_KAPPA),
        }
      } else {
        ci = wilsonInterval(mean, alpha + beta)
        posterior = { alpha, beta }
      }
    } else {
      ci = wilsonInterval(mean, alpha + beta)
      posterior = { alpha, beta }
    }

    // Wilson score interval：点估计与区间同源于 Beta(α,β) 后验
    const [lo, hi] = ci
    const samples = weightedSamples(s?.samples ?? [])
    const calibration: CalibrationSummary | null = samples.length >= minCal
      ? {
        samples: samples.length,
        p10: weightedQuantile(samples, 0.10),
        p50: weightedQuantile(samples, 0.50),
        p90: weightedQuantile(samples, 0.90),
      }
      : null

    // V5.4 耗时分布：时间加权 p50/p90。样本不足 → null（诚实留白，
    // 先知渲染层显示 n/a 而非假装知道）。墙钟口径含重试退避等待。
    const durSamples = weightedSamples(s?.durations ?? [])
    const duration: DurationSummary | null = durSamples.length >= minCal
      ? {
        samples: durSamples.length,
        p50: weightedQuantile(durSamples, 0.50),
        p90: weightedQuantile(durSamples, 0.90),
      }
      : null

    // V5.3 失败模式智能：模式分布（share 降序）+ 瞬态份额 + 重试调整投影。
    // 基础 p 是经验值（历史若已含重试效果则一并计入）—— 投影建立在
    // 经验之上而非替换经验，重试效果不会被双重计息（收敛不发散）。
    // V5.4：疗效参数取学习值（营救池观测）—— "重试有多有效"由引擎
    // 自己的历史成绩说话，常数 0.5 仅在零观测时兜底。
    const totalFail = fail
    const failureModes: FailureModeStat[] = []
    if (totalFail > 0 && s) {
      for (const [mode, count] of s.modes) {
        failureModes.push({
          mode,
          count,
          share: count / totalFail,
          transience: MODE_TRANSIENCE[mode],
        })
      }
      failureModes.sort((a, b) => b.count - a.count)
    }
    const transientShare = totalFail > 0 && s
      ? [...s.modes.entries()]
        .filter(([m]) => MODE_TRANSIENCE[m] === 'transient')
        .reduce((acc, [, c]) => acc + c, 0) / totalFail
      : 0
    const retryAdj = retryAdjustedProbability(mean, transientShare, retryAttempts, efficacyForProjection)

    return {
      action,
      successes: succ,
      failures: fail,
      successProbability: mean,
      ci95: [lo, hi],
      selfWeight,
      posterior,
      calibration,
      ...(sizeBucket !== undefined ? { sizeBucket } : {}),
      failureModes,
      transientShare,
      retryAdjustedProbability: retryAdj,
      duration,
    }
  }

  const snapshot = new Map<string, ActionReliability>()
  for (const [action, s] of stats) snapshot.set(action, build(action, s))

  return {
    sampleCount,
    globalSuccessProbability: mu,
    retryEfficacy: retryEfficacyStat,
    byAction: () => snapshot,
    reliabilityOf: (action, opts) => {
      const base = stats.get(action)
      return build(action, base, opts?.sizeBytes)
    },
  }
}
