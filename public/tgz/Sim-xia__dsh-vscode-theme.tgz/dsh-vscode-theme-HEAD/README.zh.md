# DSH VS Code 主题

[English](README.md) | [简体中文](README.zh.md)

`dsh-vscode-theme` 为 DeepSeek Harness Web 添加 VS Code 主题导入器。在“设置 -> 插件 -> VS Code 主题”中拖入 `.vsix` 文件，选择其中的主题变体后，DSH 界面会立即切换。解析完全在浏览器中进行，VSIX 不会上传。界面会跟随 DSH 当前语言，支持简体中文和 English。

插件也提供 `vscode_theme_parse` 工具，供 Agent 读取工作区中 VS Code 主题的完整颜色与语法 token 数据。

## 安装

直接从 GitHub 安装：

```sh
dsh plugin --profile web add github:Sim-xia/dsh-vscode-theme
```

若从 DSH 源码 checkout 中运行，请使用等价命令：

```sh
pnpm dsh plugin --profile web add github:Sim-xia/dsh-vscode-theme
```

该包已声明 DSH bundle patch，命令会将它启用到对应 profile。重启 profile 后生效。插件依赖 Web profile 默认提供的 `fs` 和 `tools` 服务。

本地开发时，将 GitHub specifier 替换为此仓库的绝对路径即可。

## 使用界面

安装或重新构建后重启 DSH Web profile，打开“设置 -> 插件 -> VS Code 主题”。将 VSIX 拖到导入区，或从本机选择文件；每个导入的 VSIX 都会保存到当前浏览器的 IndexedDB。刷新或重启 DSH 后，可通过“已保存的主题包”列表在不同主题包之间切换，不会上传。通过本插件应用的主题会在刷新后保持；改用其他 DSH 主题时会自动取消该恢复偏好。

DSH 与 VS Code 的视觉 token 体系不同。导入器会把工作台配色中的背景、文字、边框、焦点、选择、高亮状态和侧边栏映射为 DSH UI token。语法 token 颜色可由 Agent 解析读取，但不会改变 DSH 界面。

## 供 Agent 使用

让 Agent 检查一个 VSIX，或直接调用注册的工具：

```json
{
  "path": "/workspace/piousdeer.adwaita-theme-1.1.0.vsix",
  "theme": "Adwaita Dark",
  "detail": "summary"
}
```

将 `detail` 设为 `full` 会返回全部已解析的颜色和 token 规则。默认 `summary` 会返回元数据、规则数量、继承文件及前 24 个工作台颜色，避免普通对话占用过多上下文。

## 开发

构建和发布需要 Node.js 22 或更高版本；已编译的 host 插件仍以 Node.js 20 为目标，可用于对应版本的 DSH 运行时。

```sh
npm install
npm run check
npm run build
```
