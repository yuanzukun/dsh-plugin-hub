import assert from 'node:assert/strict'
import test from 'node:test'
import { ACTIVE_THEME_KEY, ImportedThemeManager } from '../src/theme-manager.js'

const importedTheme = {
  path: 'extension/themes/dark.json',
  label: 'Example Dark',
  uiTheme: 'vs-dark',
  colors: {
    'editor.background': '#101010',
    'editor.foreground': '#eeeeee',
  },
}

class MemoryStorage {
  values = new Map<string, string>()

  getItem(key: string) { return this.values.get(key) ?? null }
  setItem(key: string, value: string) { this.values.set(key, value) }
  removeItem(key: string) { this.values.delete(key) }
}

class DshThemeStub {
  preference = 'system'
  durablePreference = 'system'
  overrides = new Map<string, Record<string, { light: string, dark: string }>>()
  register() { throw new Error('dynamic theme registration must not be used') }

  setTheme(preference: string) {
    this.preference = preference
    this.durablePreference = preference
  }

  overrideTokens(source: string, tokens: Record<string, { light: string, dark: string }>) {
    this.overrides.set(source, tokens)
    return () => { this.overrides.delete(source) }
  }
}

test('persists a built-in base and restores the imported token layer after refresh', () => {
  const storage = new MemoryStorage()
  const firstRuntime = new DshThemeStub()
  const firstManager = new ImportedThemeManager(firstRuntime, storage)

  firstManager.apply(importedTheme)

  assert.equal(firstRuntime.durablePreference, 'dark')
  assert.equal(firstRuntime.overrides.get('dsh-vscode-theme')?.['--dsw-alias-bg-base']?.dark, '#101010')
  assert.ok(storage.getItem(ACTIVE_THEME_KEY))
  firstManager.dispose()

  const refreshedRuntime = new DshThemeStub()
  refreshedRuntime.preference = firstRuntime.durablePreference
  refreshedRuntime.durablePreference = firstRuntime.durablePreference
  const refreshedManager = new ImportedThemeManager(refreshedRuntime, storage)
  refreshedManager.restore()

  assert.equal(refreshedRuntime.preference, 'dark')
  assert.equal(refreshedRuntime.overrides.get('dsh-vscode-theme')?.['--dsw-alias-bg-base']?.light, '#101010')
  assert.ok(storage.getItem(ACTIVE_THEME_KEY))
})

test('clears the imported layer when DSH changes to another base preference', () => {
  const storage = new MemoryStorage()
  const runtime = new DshThemeStub()
  const manager = new ImportedThemeManager(runtime, storage)
  manager.apply(importedTheme)

  manager.sync({ preference: 'system' })

  assert.equal(runtime.overrides.size, 0)
  assert.equal(storage.getItem(ACTIVE_THEME_KEY), null)
})
