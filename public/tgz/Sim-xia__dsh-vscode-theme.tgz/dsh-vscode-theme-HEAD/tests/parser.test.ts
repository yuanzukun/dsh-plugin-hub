import assert from 'node:assert/strict'
import test from 'node:test'
import { strToU8, zipSync } from 'fflate'
import { parseVsix } from '../src/parser.ts'

test('parses a self-contained VSIX with inherited colors and token files', () => {
  const archive = zipSync({
    'extension/package.json': strToU8(`{
      // VSIX manifests and themes may contain comments.
      "name": "example-theme",
      "displayName": "Example Theme",
      "publisher": "example",
      "version": "1.0.0",
      "contributes": {
        "themes": [{ "label": "Example Dark", "uiTheme": "vs-dark", "path": "themes/dark.json" }],
        "productIconThemes": [{ "id": "example-icons" }]
      }
    }`),
    'extension/themes/base.json': strToU8(`{
      "colors": { "editor.background": "#111111", "editor.foreground": "#eeeeee" },
      "tokenColors": [{ "scope": "comment", "settings": { "foreground": "#888888" } }]
    }`),
    'extension/themes/dark.json': strToU8(`{
      "include": "./base.json",
      "colors": { "editor.background": "#222222" },
      "tokenColors": "./tokens.json",
      "semanticTokenColors": { "variable.readonly": "#ff0000" }
    }`),
    'extension/themes/tokens.json': strToU8(`[
      { "name": "Keyword", "scope": ["keyword", "storage"], "settings": { "foreground": "#00ff00" } }
    ]`),
  })
  const parsed = parseVsix(archive, 'example.vsix')

  assert.equal(parsed.path, 'example.vsix')
  assert.equal(parsed.extension.name, 'example-theme')
  assert.equal(parsed.extension.publisher, 'example')
  assert.deepEqual(parsed.productIconThemes, ['example-icons'])
  assert.equal(parsed.themes.length, 1)

  const dark = parsed.themes[0]
  assert.ok(dark)
  assert.equal(dark.label, 'Example Dark')
  assert.equal(dark.uiTheme, 'vs-dark')
  assert.deepEqual(dark.includes, ['extension/themes/base.json'])
  assert.equal(dark.colors['editor.background'], '#222222')
  assert.equal(dark.colors['editor.foreground'], '#eeeeee')
  assert.equal(dark.tokenColors.length, 2)
  assert.equal(dark.semanticTokenColors['variable.readonly'], '#ff0000')
})
