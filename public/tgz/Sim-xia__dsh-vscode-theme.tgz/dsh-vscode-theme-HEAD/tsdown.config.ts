import { defineConfig } from 'tsdown'
import { fileURLToPath } from 'node:url'

const CLIENT_ID = 'dsh-vscode-theme'
const BROWSER_FFLATE = fileURLToPath(new URL('./node_modules/fflate/esm/browser.js', import.meta.url))
const BROWSER_JSONC_PARSER = fileURLToPath(new URL('./node_modules/jsonc-parser/lib/esm/main.js', import.meta.url))

export default defineConfig([
  {
    entry: ['src/index.ts'],
    outDir: 'lib',
    format: ['esm'],
    platform: 'node',
    target: 'node20',
    dts: true,
    clean: true,
    deps: {
      neverBundle: [
        '@deepseek-ai/cordis',
        '@deepseek-ai/dsh-fs',
        '@deepseek-ai/dsh-tools',
      ],
    },
  },
  {
    entry: { client: 'src/client.js' },
    outDir: 'lib',
    format: ['cjs'],
    platform: 'browser',
    target: 'es2020',
    dts: false,
    clean: false,
    deps: {
      neverBundle: ['react'],
      alwaysBundle: ['fflate', 'jsonc-parser'],
    },
    plugins: [{
      name: 'browser-jsonc-parser',
      resolveId(source) {
        if (source === 'fflate') return BROWSER_FFLATE
        return source === 'jsonc-parser' ? BROWSER_JSONC_PARSER : null
      },
    }],
    outputOptions: {
      entryFileNames: 'client.js',
      banner: `window.__ModuleLoader__.load({ id: ${JSON.stringify(CLIENT_ID)}, factory: (require) => {`,
      footer: 'return module.exports; } });',
      intro: 'var module = { exports: {} }; var exports = module.exports;',
    },
  },
])
