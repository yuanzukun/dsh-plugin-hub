# Changelog

All notable changes to this project are documented in this file.

## 0.1.0 - 2026-08-15

- Added browser-side import of VS Code `.vsix` theme packages.
- Added selection and immediate application of themes included in a package.
- Added English and Simplified Chinese UI support through DSH's locale runtime.
- Added the `vscode_theme_parse` agent tool for inspecting VSIX theme data.

