import { Context } from "@deepseek-ai/cordis";
//#region src/types.d.ts
/** A VS Code color value or a color customization object. */
type ThemeColorValue = string | Record<string, unknown>;
/** A compact description of one theme contribution in a VSIX manifest. */
interface ThemeContribution {
  readonly label: string;
  readonly uiTheme?: string;
  readonly path: string;
}
/** One syntax-highlighting rule as declared by a VS Code theme. */
interface TokenColorRule {
  readonly name?: string;
  readonly scope?: string | readonly string[];
  readonly settings: Record<string, unknown>;
}
/** Fully resolved information for one theme file. */
interface ParsedTheme {
  readonly label: string;
  readonly path: string;
  readonly uiTheme?: string;
  readonly includes: readonly string[];
  readonly colors: Readonly<Record<string, ThemeColorValue>>;
  readonly tokenColors: readonly TokenColorRule[];
  readonly semanticTokenColors: Readonly<Record<string, unknown>>;
}
/** Package metadata and parsed themes returned by the archive parser. */
interface ParsedVsix {
  readonly path: string;
  readonly extension: {
    readonly name?: string;
    readonly displayName?: string;
    readonly publisher?: string;
    readonly version?: string;
    readonly description?: string;
  };
  readonly themes: readonly ParsedTheme[];
  readonly productIconThemes: readonly string[];
}
//#endregion
//#region src/parser.d.ts
/** An image declared by the VSIX extension manifest. */
interface VsixIcon {
  readonly path: string;
  readonly bytes: Uint8Array;
}
/** Parse a VSIX archive without extracting it onto disk. */
declare function parseVsix(bytes: Uint8Array, displayPath: string): ParsedVsix;
/** Read the extension icon declared by a VSIX manifest, when present. */
declare function getVsixIcon(bytes: Uint8Array): VsixIcon | undefined;
//#endregion
//#region src/index.d.ts
declare const name = "vscode-theme";
declare const inject: string[];
/** Register the read-only `vscode_theme_parse` tool. */
declare function apply(ctx: Context): void;
//#endregion
export { type ParsedTheme, type ParsedVsix, type ThemeColorValue, type ThemeContribution, type TokenColorRule, apply, getVsixIcon, inject, name, parseVsix };
//# sourceMappingURL=index.d.mts.map