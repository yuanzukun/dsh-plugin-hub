/**
 * Model-facing VS Code theme inspection for DeepSeek Harness.
 * @module dsh-vscode-theme
 */

import { readFile } from 'node:fs/promises'
import type { Context } from '@deepseek-ai/cordis'
import { defineTool, type JsonValue } from '@deepseek-ai/dsh-tools'
import type {} from '@deepseek-ai/dsh-fs'
import { parseVsix } from './parser.js'
import type { ParsedTheme, ParsedVsix } from './types.js'

export { getVsixIcon, parseVsix } from './parser.js'
export type { ParsedTheme, ParsedVsix, ThemeContribution, ThemeColorValue, TokenColorRule } from './types.js'

export const name = 'vscode-theme'
export const inject = ['tools', 'fs']

const DEFAULT_MAX_VSIX_BYTES = 32 * 1024 * 1024

interface ParseArgs {
  readonly path: string
  readonly theme?: string
  readonly detail?: 'summary' | 'full'
}

/** Register the read-only `vscode_theme_parse` tool. */
export function apply(ctx: Context): void {
  ctx.tools.register(defineTool({
    name: 'vscode_theme_parse',
    description: 'Parse a VS Code .vsix theme package from the workspace. Returns extension metadata, theme variants, resolved workbench colors, syntax token rules, and semantic-token colors. Use detail "summary" first; use "full" only when exact theme values are needed.',
    parameters: {
      path: {
        type: 'string',
        required: true,
        description: 'Path to a .vsix file. Relative paths resolve in the current workspace.',
      },
      theme: {
        type: 'string',
        description: 'Optional theme label or manifest path. Omit to inspect all themes in summary mode.',
      },
      detail: {
        type: 'string',
        enum: ['summary', 'full'],
        description: 'summary returns counts and a color sample. full returns all colors and token rules. Defaults to summary.',
      },
    },
    output: {
      schema: { type: 'object', additionalProperties: true },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
    },
    async execute(args: ParseArgs, exec) {
      const target = await ctx.fs.resolve(args.path, { signal: exec.signal })
      const info = await ctx.fs.stat(target, exec.signal)
      if (info === undefined || info.type !== 'file') throw new Error(`Cannot read ${target.displayPath}: expected a regular .vsix file`)
      if (info.size !== undefined && info.size > DEFAULT_MAX_VSIX_BYTES) {
        throw new Error(`Cannot read ${target.displayPath}: VSIX is larger than the ${DEFAULT_MAX_VSIX_BYTES / 1024 / 1024} MiB safety limit`)
      }
      const bytes = await readFile(ctx.fs.processPath(target), { signal: exec.signal })
      if (bytes.byteLength > DEFAULT_MAX_VSIX_BYTES) {
        throw new Error(`Cannot read ${target.displayPath}: VSIX is larger than the ${DEFAULT_MAX_VSIX_BYTES / 1024 / 1024} MiB safety limit`)
      }
      const parsed = parseVsix(bytes, target.displayPath)
      return present(parsed, args.theme, args.detail ?? 'summary')
    },
    presentCall: args => ({ card: 'generic', title: `Parse VS Code theme ${args.path}`, kind: 'read', locations: [{ path: args.path }] }),
  }))
}

function present(parsed: ParsedVsix, requestedTheme: string | undefined, detail: 'summary' | 'full'): Record<string, JsonValue> {
  const themes = requestedTheme === undefined
    ? parsed.themes
    : parsed.themes.filter(theme => theme.label === requestedTheme || theme.path === requestedTheme)
  if (themes.length === 0) throw new Error(`Theme ${JSON.stringify(requestedTheme)} was not found. Available themes: ${parsed.themes.map(theme => theme.label).join(', ')}`)

  return {
    path: parsed.path,
    extension: parsed.extension,
    productIconThemes: [...parsed.productIconThemes],
    themes: themes.map(theme => detail === 'full' ? theme as unknown as JsonValue : summarize(theme)),
  }
}

function summarize(theme: ParsedTheme): Record<string, JsonValue> {
  const colorEntries = Object.entries(theme.colors)
  return {
    label: theme.label,
    path: theme.path,
    ...theme.uiTheme === undefined ? {} : { uiTheme: theme.uiTheme },
    includes: [...theme.includes],
    colorCount: colorEntries.length,
    tokenColorRuleCount: theme.tokenColors.length,
    semanticTokenColorCount: Object.keys(theme.semanticTokenColors).length,
    colors: Object.fromEntries(colorEntries.slice(0, 24)) as JsonValue,
  }
}
