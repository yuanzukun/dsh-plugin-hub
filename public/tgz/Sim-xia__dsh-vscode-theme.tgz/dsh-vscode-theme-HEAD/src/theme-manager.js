export const ACTIVE_THEME_KEY = 'dsh-vscode-theme.active-v2'

const OVERRIDE_SOURCE = 'dsh-vscode-theme'

export const color = (theme, ...keys) => {
  for (const key of keys) {
    const value = theme.colors[key]
    if (typeof value === 'string') return value
  }
  return undefined
}

export const themeScheme = (theme) => {
  if (theme.uiTheme === 'vs-dark' || theme.uiTheme === 'hc-black') return 'dark'
  if (theme.uiTheme === 'vs' || theme.uiTheme === 'hc-light') return 'light'
  const background = color(theme, 'editor.background')
  if (background !== undefined && /^#[0-9a-f]{6}$/i.test(background)) {
    const red = Number.parseInt(background.slice(1, 3), 16)
    const green = Number.parseInt(background.slice(3, 5), 16)
    const blue = Number.parseInt(background.slice(5, 7), 16)
    return red * 0.2126 + green * 0.7152 + blue * 0.0722 < 128 ? 'dark' : 'light'
  }
  return 'dark'
}

export const dshTokens = (theme) => {
  const tokens = {}
  const define = (name, ...keys) => {
    const value = color(theme, ...keys)
    if (value !== undefined) tokens[name] = value
  }
  define('--dsw-alias-bg-base', 'editor.background', 'sideBar.background')
  define('--dsw-alias-bg-layer-1', 'editorWidget.background', 'panel.background', 'sideBar.background')
  define('--dsw-alias-bg-layer-2', 'editorGroupHeader.tabsBackground', 'tab.inactiveBackground', 'panel.background')
  define('--dsw-alias-bg-layer-3', 'tab.activeBackground', 'list.activeSelectionBackground', 'editor.background')
  define('--dsw-alias-bg-overlay', 'editorHoverWidget.background', 'editorWidget.background')
  define('--dsw-alias-bg-module-platform', 'editorWidget.background', 'sideBar.background')
  define('--dsw-alias-label-primary', 'editor.foreground', 'foreground')
  define('--dsw-alias-label-secondary', 'descriptionForeground', 'editorLineNumber.foreground')
  define('--dsw-alias-label-tertiary', 'editorLineNumber.foreground', 'disabledForeground')
  define('--dsw-alias-border-l1', 'focusBorder', 'panel.border')
  define('--dsw-alias-border-l2', 'panel.border', 'editorGroup.border', 'sideBar.border')
  define('--dsw-alias-brand-primary', 'button.background', 'activityBarBadge.background', 'focusBorder')
  define('--dsw-alias-state-business-primary', 'focusBorder', 'button.background')
  define('--dsw-alias-interactive-bg-hover', 'list.hoverBackground', 'list.inactiveSelectionBackground')
  define('--dsw-alias-state-error-primary', 'errorForeground', 'editorError.foreground', 'terminal.ansiRed')
  define('--dsw-alias-state-success-primary', 'gitDecoration.addedResourceForeground', 'terminal.ansiGreen')
  define('--dsw-alias-state-warn-primary', 'editorWarning.foreground', 'terminal.ansiYellow')
  define('--dsw-specific-sidebar-fill', 'sideBar.background', 'activityBar.background')
  return tokens
}

const tokenModes = (theme) => Object.fromEntries(
  Object.entries(dshTokens(theme)).map(([name, value]) => [name, { light: value, dark: value }]),
)

const isStoredTheme = (value) => value !== null && typeof value === 'object'
  && typeof value.path === 'string'
  && typeof value.label === 'string'
  && typeof value.colors === 'object' && value.colors !== null

export class ImportedThemeManager {
  constructor(theme, storage = localStorage) {
    this.theme = theme
    this.storage = storage
    this.current = undefined
    this.applying = false
  }

  apply(theme) {
    this.clearCurrent()
    const basePreference = themeScheme(theme)
    this.applying = true
    try {
      // DSH persists only its built-in preferences. The imported palette is a
      // reversible token layer over that durable light/dark base.
      this.theme.setTheme(basePreference)
      const dispose = this.theme.overrideTokens(OVERRIDE_SOURCE, tokenModes(theme))
      this.current = { dispose, basePreference }
      try {
        this.storage.setItem(ACTIVE_THEME_KEY, JSON.stringify(theme))
      } catch {}
    } finally {
      this.applying = false
    }
  }

  restore() {
    try {
      const stored = JSON.parse(this.storage.getItem(ACTIVE_THEME_KEY) ?? 'null')
      if (isStoredTheme(stored)) this.apply(stored)
    } catch {}
  }

  sync(snapshot) {
    if (this.applying || this.current === undefined) return
    if (snapshot.preference !== this.current.basePreference) {
      this.clearCurrent()
      try {
        this.storage.removeItem(ACTIVE_THEME_KEY)
      } catch {}
    }
  }

  clearCurrent() {
    const current = this.current
    this.current = undefined
    current?.dispose()
  }

  dispose() {
    this.clearCurrent()
  }
}
