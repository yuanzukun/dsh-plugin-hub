import { unzipSync } from 'fflate'
import { parse, printParseErrorCode, type ParseError } from 'jsonc-parser'
import type { ParsedTheme, ParsedVsix, ThemeColorValue, ThemeContribution, TokenColorRule } from './types.js'

const textDecoder = new TextDecoder('utf-8', { fatal: true })

interface ThemeDocument {
  readonly include?: unknown
  readonly colors?: unknown
  readonly tokenColors?: unknown
  readonly semanticTokenColors?: unknown
}

interface ExtensionManifest {
  readonly name?: unknown
  readonly displayName?: unknown
  readonly publisher?: unknown
  readonly version?: unknown
  readonly description?: unknown
  readonly icon?: unknown
  readonly contributes?: {
    readonly themes?: unknown
    readonly productIconThemes?: unknown
  }
}

type Archive = Readonly<Record<string, Uint8Array>>

/** An image declared by the VSIX extension manifest. */
export interface VsixIcon {
  readonly path: string
  readonly bytes: Uint8Array
}

/** Parse a VSIX archive without extracting it onto disk. */
export function parseVsix(bytes: Uint8Array, displayPath: string): ParsedVsix {
  let archive: Archive
  try {
    archive = unzipSync(bytes)
  } catch (error) {
    throw new Error(`Cannot open ${displayPath} as a VSIX ZIP archive: ${messageOf(error)}`)
  }

  const manifest = readJson<ExtensionManifest>(archive, 'extension/package.json')
  const contributions = readThemeContributions(manifest)
  const themes = contributions.map(contribution => resolveTheme(archive, contribution))

  return {
    path: displayPath,
    extension: {
      ...stringField(manifest, 'name'),
      ...stringField(manifest, 'displayName'),
      ...stringField(manifest, 'publisher'),
      ...stringField(manifest, 'version'),
      ...stringField(manifest, 'description'),
    },
    themes,
    productIconThemes: readProductIconThemes(manifest),
  }
}

/** Read the extension icon declared by a VSIX manifest, when present. */
export function getVsixIcon(bytes: Uint8Array): VsixIcon | undefined {
  let archive: Archive
  try {
    archive = unzipSync(bytes)
  } catch {
    return undefined
  }
  const manifest = readJson<ExtensionManifest>(archive, 'extension/package.json')
  const icon = stringValue(manifest.icon)
  if (icon === undefined) return undefined
  const path = archivePath(icon)
  const image = archive[path]
  return image === undefined ? undefined : { path, bytes: image }
}

function resolveTheme(archive: Archive, contribution: ThemeContribution): ParsedTheme {
  const rootPath = archivePath(contribution.path)
  const resolved = resolveThemeDocument(archive, rootPath, new Set())
  return {
    label: contribution.label,
    path: contribution.path,
    ...contribution.uiTheme === undefined ? {} : { uiTheme: contribution.uiTheme },
    includes: resolved.includes,
    colors: resolved.colors,
    tokenColors: resolved.tokenColors,
    semanticTokenColors: resolved.semanticTokenColors,
  }
}

function resolveThemeDocument(archive: Archive, path: string, ancestors: ReadonlySet<string>): Omit<ParsedTheme, 'label' | 'path' | 'uiTheme'> {
  if (ancestors.has(path)) throw new Error(`Theme include cycle detected at ${path}`)
  const document = readJson<ThemeDocument>(archive, path)
  const nextAncestors = new Set(ancestors).add(path)
  const includePath = stringValue(document.include)
  const base = includePath === undefined
    ? emptyTheme()
    : resolveThemeDocument(archive, resolveIncludedPath(path, includePath), nextAncestors)

  const colors = { ...base.colors, ...objectOfThemeColors(document.colors, path) }
  const semanticTokenColors = { ...base.semanticTokenColors, ...objectValue(document.semanticTokenColors, path, 'semanticTokenColors') }
  const localTokenColors = readTokenColors(archive, path, document.tokenColors)

  return {
    includes: includePath === undefined ? base.includes : [...base.includes, resolveIncludedPath(path, includePath)],
    colors,
    tokenColors: [...base.tokenColors, ...localTokenColors],
    semanticTokenColors,
  }
}

function emptyTheme(): Omit<ParsedTheme, 'label' | 'path' | 'uiTheme'> {
  return { includes: [], colors: {}, tokenColors: [], semanticTokenColors: {} }
}

function readThemeContributions(manifest: ExtensionManifest): ThemeContribution[] {
  const themes = manifest.contributes?.themes
  if (!Array.isArray(themes) || themes.length === 0) {
    throw new Error('extension/package.json does not declare contributes.themes')
  }

  return themes.map((value, index) => {
    if (!isRecord(value)) throw new Error(`contributes.themes[${index}] must be an object`)
    const label = stringValue(value.label)
    const path = stringValue(value.path)
    if (label === undefined || path === undefined) {
      throw new Error(`contributes.themes[${index}] must contain string label and path fields`)
    }
    const uiTheme = stringValue(value.uiTheme)
    return { label, path, ...uiTheme === undefined ? {} : { uiTheme } }
  })
}

function readProductIconThemes(manifest: ExtensionManifest): string[] {
  const themes = manifest.contributes?.productIconThemes
  if (!Array.isArray(themes)) return []
  return themes.flatMap(value => isRecord(value) && typeof value.id === 'string' ? [value.id] : [])
}

function readTokenColors(archive: Archive, themePath: string, value: unknown): TokenColorRule[] {
  if (value === undefined) return []
  if (typeof value === 'string') return readTokenColors(archive, resolveIncludedPath(themePath, value), readJson<unknown>(archive, resolveIncludedPath(themePath, value)))
  if (!Array.isArray(value)) throw new Error(`${themePath}: tokenColors must be an array or a JSON file path`)
  return value.map((rule, index) => normalizeTokenRule(rule, `${themePath}: tokenColors[${index}]`))
}

function normalizeTokenRule(value: unknown, location: string): TokenColorRule {
  if (!isRecord(value) || !isRecord(value.settings)) throw new Error(`${location} must contain an object settings field`)
  const name = stringValue(value.name)
  const scope = typeof value.scope === 'string'
    ? value.scope
    : Array.isArray(value.scope) && value.scope.every(part => typeof part === 'string')
      ? value.scope as string[]
      : undefined
  return {
    ...name === undefined ? {} : { name },
    ...scope === undefined ? {} : { scope },
    settings: value.settings,
  }
}

function objectOfThemeColors(value: unknown, path: string): Record<string, ThemeColorValue> {
  return objectValue(value, path, 'colors') as Record<string, ThemeColorValue>
}

function objectValue(value: unknown, path: string, field: string): Record<string, unknown> {
  if (value === undefined) return {}
  if (!isRecord(value)) throw new Error(`${path}: ${field} must be an object`)
  return value
}

function readJson<T>(archive: Archive, path: string): T {
  const source = archive[path]
  if (source === undefined) throw new Error(`Archive entry not found: ${path}`)
  let text: string
  try {
    text = textDecoder.decode(source)
  } catch {
    throw new Error(`Archive entry ${path} is not valid UTF-8 text`)
  }
  const errors: ParseError[] = []
  const value = parse(text, errors, { allowTrailingComma: true, disallowComments: false })
  if (errors.length > 0) {
    const first = errors[0]
    throw new Error(`${path} contains invalid JSONC (${first === undefined ? 'unknown parse error' : printParseErrorCode(first.error)})`)
  }
  if (!isRecord(value) && !Array.isArray(value)) throw new Error(`${path} must contain a JSON object or array`)
  return value as T
}

function archivePath(path: string): string {
  const normalized = normalizePath(path)
  return normalized.startsWith('extension/') ? normalized : `extension/${normalized}`
}

function resolveIncludedPath(from: string, include: string): string {
  if (include.startsWith('/')) throw new Error(`${from}: absolute include paths are not allowed`)
  const directory = from.slice(0, Math.max(0, from.lastIndexOf('/') + 1))
  return normalizePath(`${directory}${include}`)
}

function normalizePath(path: string): string {
  const parts: string[] = []
  for (const part of path.replaceAll('\\', '/').split('/')) {
    if (part === '' || part === '.') continue
    if (part === '..') {
      if (parts.length === 0) throw new Error(`Archive path escapes the package: ${path}`)
      parts.pop()
      continue
    }
    parts.push(part)
  }
  if (parts.length === 0) throw new Error(`Invalid empty archive path: ${path}`)
  return parts.join('/')
}

function stringField(value: ExtensionManifest, field: keyof ExtensionManifest): Record<string, string> {
  const string = stringValue(value[field])
  return string === undefined ? {} : { [field]: string }
}

function stringValue(value: unknown): string | undefined {
  return typeof value === 'string' ? value : undefined
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}
