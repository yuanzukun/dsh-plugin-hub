/** A VS Code color value or a color customization object. */
export type ThemeColorValue = string | Record<string, unknown>

/** A compact description of one theme contribution in a VSIX manifest. */
export interface ThemeContribution {
  readonly label: string
  readonly uiTheme?: string
  readonly path: string
}

/** One syntax-highlighting rule as declared by a VS Code theme. */
export interface TokenColorRule {
  readonly name?: string
  readonly scope?: string | readonly string[]
  readonly settings: Record<string, unknown>
}

/** Fully resolved information for one theme file. */
export interface ParsedTheme {
  readonly label: string
  readonly path: string
  readonly uiTheme?: string
  readonly includes: readonly string[]
  readonly colors: Readonly<Record<string, ThemeColorValue>>
  readonly tokenColors: readonly TokenColorRule[]
  readonly semanticTokenColors: Readonly<Record<string, unknown>>
}

/** Package metadata and parsed themes returned by the archive parser. */
export interface ParsedVsix {
  readonly path: string
  readonly extension: {
    readonly name?: string
    readonly displayName?: string
    readonly publisher?: string
    readonly version?: string
    readonly description?: string
  }
  readonly themes: readonly ParsedTheme[]
  readonly productIconThemes: readonly string[]
}
