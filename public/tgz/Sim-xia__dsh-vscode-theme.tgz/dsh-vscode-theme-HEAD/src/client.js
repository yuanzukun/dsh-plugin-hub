import React from 'react'
import { getVsixIcon, parseVsix } from './parser.js'
import { color, ImportedThemeManager } from './theme-manager.js'

export const inject = ['slots', 'theme', 'locale']

const ARCHIVE_DATABASE = 'dsh-vscode-theme'
const ARCHIVE_STORE = 'archives'
const LEGACY_ARCHIVE_KEY = 'latest'
const MAX_VSIX_BYTES = 32 * 1024 * 1024
const LOCALE_NAMESPACE = 'vscode-theme'

const zh = {
  tab: 'VS Code 主题',
  title: '导入 VS Code 主题',
  description: '将 .vsix 文件拖到这里，或从本机选择一个主题包。',
  choose: '选择 VSIX',
  parsing: '正在解析...',
  saving: '正在保存到本地...',
  parseError: '无法解析该 VSIX 文件',
  fileTooLarge: '该 VSIX 文件超过 32 MiB，无法保存。',
  saveError: '主题已解析，但无法保存到本地。',
  restoreError: '无法恢复已保存的 VSIX 文件。',
  removeError: '无法移除已保存的 VSIX 文件。',
  savedArchives: '已保存的主题包',
  savedArchivesHint: '点击一个主题包以查看其中的主题。',
  removeArchive: '移除已保存的 VSIX',
  availableThemes: '{count} 个可用主题',
  workbenchColors: '{count} 个工作台颜色',
  syntaxRules: '{count} 条语法规则',
  applied: '已应用',
  apply: '应用',
}

const en = {
  tab: 'VS Code Themes',
  title: 'Import a VS Code Theme',
  description: 'Drop a .vsix file here, or choose a theme package from your computer.',
  choose: 'Choose VSIX',
  parsing: 'Parsing...',
  saving: 'Saving locally...',
  parseError: 'Unable to parse this VSIX file',
  fileTooLarge: 'This VSIX file is larger than 32 MiB and cannot be saved.',
  saveError: 'The theme was parsed but could not be saved locally.',
  restoreError: 'Unable to restore the saved VSIX file.',
  removeError: 'Unable to remove the saved VSIX file.',
  savedArchives: 'Saved theme packages',
  savedArchivesHint: 'Click a theme package to view its included themes.',
  removeArchive: 'Remove saved VSIX',
  availableThemes: '{count} theme(s) available',
  workbenchColors: '{count} workbench colors',
  syntaxRules: '{count} syntax rules',
  applied: 'Applied',
  apply: 'Apply',
}

function openArchiveDatabase() {
  if (typeof indexedDB === 'undefined') return Promise.reject(new Error('IndexedDB is unavailable'))
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(ARCHIVE_DATABASE, 1)
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(ARCHIVE_STORE)) request.result.createObjectStore(ARCHIVE_STORE)
    }
    request.onerror = () => reject(request.error ?? new Error('Unable to open IndexedDB'))
    request.onsuccess = () => resolve(request.result)
  })
}

async function readSavedArchives() {
  const database = await openArchiveDatabase()
  try {
    return await new Promise((resolve, reject) => {
      const request = database.transaction(ARCHIVE_STORE, 'readonly').objectStore(ARCHIVE_STORE).getAll()
      request.onerror = () => reject(request.error ?? new Error('Unable to read saved VSIX'))
      request.onsuccess = () => resolve((request.result ?? []).map(archive => ({
        ...archive,
        id: typeof archive.id === 'string' ? archive.id : LEGACY_ARCHIVE_KEY,
      })).filter(archive => typeof archive.name === 'string' && archive.bytes instanceof ArrayBuffer))
    })
  } finally {
    database.close()
  }
}

async function readSavedArchive(id) {
  const database = await openArchiveDatabase()
  try {
    return await new Promise((resolve, reject) => {
      const request = database.transaction(ARCHIVE_STORE, 'readonly').objectStore(ARCHIVE_STORE).get(id)
      request.onerror = () => reject(request.error ?? new Error('Unable to read saved VSIX'))
      request.onsuccess = () => resolve(request.result ?? null)
    })
  } finally {
    database.close()
  }
}

function createArchiveId() {
  return typeof globalThis.crypto?.randomUUID === 'function'
    ? globalThis.crypto.randomUUID()
    : `archive-${Date.now()}-${Math.random().toString(36).slice(2)}`
}

async function saveArchive(id, name, bytes) {
  const database = await openArchiveDatabase()
  try {
    await new Promise((resolve, reject) => {
      const request = database.transaction(ARCHIVE_STORE, 'readwrite').objectStore(ARCHIVE_STORE).put({ id, name, bytes, icon: iconDataUrl(getVsixIcon(bytes)), savedAt: Date.now() }, id)
      request.onerror = () => reject(request.error ?? new Error('Unable to save VSIX'))
      request.onsuccess = () => resolve()
    })
  } finally {
    database.close()
  }
}

function iconDataUrl(icon) {
  if (icon === undefined) return undefined
  const extension = icon.path.split('.').pop()?.toLowerCase()
  const mediaType = extension === 'svg' ? 'image/svg+xml'
    : extension === 'jpg' || extension === 'jpeg' ? 'image/jpeg'
      : extension === 'webp' ? 'image/webp'
        : 'image/png'
  let binary = ''
  for (let index = 0; index < icon.bytes.length; index += 8192) {
    binary += String.fromCharCode(...icon.bytes.subarray(index, index + 8192))
  }
  return `data:${mediaType};base64,${btoa(binary)}`
}

async function removeSavedArchive(id) {
  const database = await openArchiveDatabase()
  try {
    await new Promise((resolve, reject) => {
      const request = database.transaction(ARCHIVE_STORE, 'readwrite').objectStore(ARCHIVE_STORE).delete(id)
      request.onerror = () => reject(request.error ?? new Error('Unable to remove saved VSIX'))
      request.onsuccess = () => resolve()
    })
  } finally {
    database.close()
  }
}

export function apply(ctx) {
  const manager = new ImportedThemeManager(ctx.theme)
  ctx.effect(() => () => { manager.dispose() }, 'vscode-theme: imported theme cleanup')
  ctx.effect(() => ctx.locale.register(LOCALE_NAMESPACE, { zh, en }), 'vscode-theme: dictionaries')
  ctx.on('theme/change', snapshot => { manager.sync(snapshot) })
  manager.restore()
  const t = ctx.locale.bind(LOCALE_NAMESPACE)
  ctx.slots.inject('settings.plugins.tab', () => ctx.slots.register({
    name: 'settings.plugins.tab',
    id: 'vscode-theme',
    order: 30,
    label: () => t('tab'),
    locale: LOCALE_NAMESPACE,
    inject: () => ({ manager }),
  }, ThemeSettingsPanel))
}

function ThemeSettingsPanel({ manager, t }) {
  const input = React.useRef(null)
  const [parsed, setParsed] = React.useState(null)
  const [selected, setSelected] = React.useState(null)
  const [error, setError] = React.useState(null)
  const [loading, setLoading] = React.useState(false)
  const [archives, setArchives] = React.useState([])
  const [archiveId, setArchiveId] = React.useState(null)
  const [expandedArchiveId, setExpandedArchiveId] = React.useState(null)

  React.useEffect(() => {
    let active = true
    setLoading(true)
    void readSavedArchives().then((storedArchives) => {
      if (!active || storedArchives.length === 0) return
      const archive = storedArchives.sort((left, right) => (right.savedAt ?? 0) - (left.savedAt ?? 0))[0]
      const result = parseVsix(new Uint8Array(archive.bytes), archive.name)
      if (!active) return
      setParsed(result)
      setArchives(storedArchives.map(archive => ({
        id: archive.id,
        name: archive.name,
        savedAt: archive.savedAt,
        icon: typeof archive.icon === 'string' ? archive.icon : iconDataUrl(getVsixIcon(archive.bytes)),
      })))
      setArchiveId(archive.id)
      setExpandedArchiveId(archive.id)
      setSelected(null)
    }, () => {
      if (active) setError(t('restoreError'))
    }).finally(() => {
      if (active) setLoading(false)
    })
    return () => { active = false }
  }, [t])

  const importFile = async (file) => {
    if (file === undefined || file === null) return
    setLoading(true)
    setError(null)
    try {
      const bytes = await file.arrayBuffer()
      if (bytes.byteLength > MAX_VSIX_BYTES) throw new Error(t('fileTooLarge'))
      const result = parseVsix(new Uint8Array(bytes), file.name)
      const id = createArchiveId()
      setParsed(result)
      setSelected(null)
      try {
        await saveArchive(id, file.name, bytes)
        setArchives(current => [{ id, name: file.name, icon: iconDataUrl(getVsixIcon(bytes)), savedAt: Date.now() }, ...current])
        setArchiveId(id)
        setExpandedArchiveId(id)
      } catch {
        setError(t('saveError'))
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : t('parseError'))
    } finally {
      setLoading(false)
    }
  }

  const selectSavedArchive = async (id) => {
    setLoading(true)
    setError(null)
    try {
      const archive = await readSavedArchive(id)
      if (archive === null || typeof archive.name !== 'string' || !(archive.bytes instanceof ArrayBuffer)) throw new Error()
      const result = parseVsix(new Uint8Array(archive.bytes), archive.name)
      setParsed(result)
      setArchiveId(id)
      setSelected(null)
    } catch {
      setError(t('restoreError'))
    } finally {
      setLoading(false)
    }
  }

  const toggleSavedArchive = async (id) => {
    if (expandedArchiveId === id) {
      setExpandedArchiveId(null)
      return
    }
    setExpandedArchiveId(id)
    if (archiveId !== id) await selectSavedArchive(id)
  }

  const clearSavedArchive = async () => {
    if (archiveId === null) return
    setLoading(true)
    setError(null)
    try {
      await removeSavedArchive(archiveId)
      const remaining = archives.filter(archive => archive.id !== archiveId)
      setArchives(remaining)
      if (remaining.length === 0) {
        setParsed(null)
        setArchiveId(null)
        setSelected(null)
        setExpandedArchiveId(null)
      } else {
        setExpandedArchiveId(remaining[0].id)
        await selectSavedArchive(remaining[0].id)
      }
    } catch {
      setError(t('removeError'))
    } finally {
      setLoading(false)
    }
  }

  const activate = (theme) => {
    manager.apply(theme)
    setSelected(theme.path)
  }

  const styles = {
    panel: { color: 'var(--dsw-alias-label-primary)', display: 'grid', gap: 16, maxWidth: 760 },
    import: { border: '1px dashed var(--dsw-alias-border-l2)', background: 'var(--dsw-alias-bg-layer-1)', borderRadius: 8, padding: 24, textAlign: 'center', display: 'grid', gap: 10 },
    library: { background: 'var(--dsw-alias-bg-layer-1)', border: '1px solid var(--dsw-alias-border-l2)', borderRadius: 8, display: 'grid', gap: 12, padding: 16 },
    button: { background: 'var(--dsw-alias-brand-primary)', border: 0, borderRadius: 6, color: 'white', cursor: 'pointer', font: 'inherit', justifySelf: 'center', padding: '8px 14px' },
    meta: { color: 'var(--dsw-alias-label-secondary)', fontSize: 13, margin: 0 },
    list: { display: 'grid', gap: 8, listStyle: 'none', margin: 0, padding: 0 },
    archive: { alignItems: 'center', background: 'var(--dsw-alias-bg-layer-2)', border: '1px solid var(--dsw-alias-border-l2)', borderRadius: 7, color: 'var(--dsw-alias-label-primary)', cursor: 'pointer', display: 'grid', gridTemplateColumns: '38px minmax(0, 1fr) 18px', gap: 10, padding: 10, textAlign: 'left', width: '100%' },
    archiveIcon: { alignItems: 'center', background: 'var(--dsw-alias-bg-layer-3)', border: '1px solid var(--dsw-alias-border-l2)', borderRadius: 4, color: 'var(--dsw-alias-brand-primary)', display: 'flex', fontSize: 9, fontWeight: 700, height: 30, justifyContent: 'center', width: 30 },
    theme: { alignItems: 'center', background: 'var(--dsw-alias-bg-layer-1)', border: '1px solid var(--dsw-alias-border-l2)', borderRadius: 7, display: 'grid', gap: 12, gridTemplateColumns: '32px minmax(0, 1fr) auto', padding: 12, textAlign: 'left', width: '100%' },
  }

  return React.createElement('div', { style: styles.panel },
    React.createElement('div', {
      style: styles.import,
      onDragOver: event => { event.preventDefault() },
      onDrop: event => { event.preventDefault(); void importFile(event.dataTransfer.files[0]) },
    },
    React.createElement('strong', null, t('title')),
    React.createElement('p', { style: styles.meta }, t('description')),
    React.createElement('input', { ref: input, type: 'file', accept: '.vsix,application/vsix', hidden: true, onChange: event => { void importFile(event.currentTarget.files?.[0]) } }),
    React.createElement('button', { type: 'button', style: styles.button, onClick: () => input.current?.click(), disabled: loading }, loading ? t('parsing') : t('choose'))),
    error === null ? null : React.createElement('p', { role: 'alert', style: { color: 'var(--dsw-alias-state-error-primary)', margin: 0 } }, error),
    archives.length === 0 ? null : React.createElement('section', { style: styles.library },
      React.createElement('div', null,
        React.createElement('strong', null, t('savedArchives')),
        React.createElement('p', { style: styles.meta }, t('savedArchivesHint'))),
      React.createElement('ul', { style: styles.list }, archives.map(archive => {
        const expanded = expandedArchiveId === archive.id
        const loaded = archiveId === archive.id && parsed !== null
        const archiveName = archive.name.replace(/\.vsix$/i, '')
        return React.createElement('li', { key: archive.id },
          React.createElement('button', { type: 'button', style: { ...styles.archive, outline: expanded ? '2px solid var(--dsw-alias-state-business-primary)' : 'none' }, onClick: () => { void toggleSavedArchive(archive.id) }, disabled: loading, 'aria-expanded': expanded },
            archive.icon === undefined
              ? React.createElement('span', { style: styles.archiveIcon, 'aria-hidden': true }, 'VSIX')
              : React.createElement('img', { alt: '', src: archive.icon, style: { ...styles.archiveIcon, objectFit: 'cover' } }),
            React.createElement('span', null, archiveName),
            React.createElement('span', { style: { fontSize: 16, lineHeight: 1 } }, expanded ? '-' : '+')),
          expanded && loaded ? React.createElement('div', { style: { display: 'grid', gap: 10, padding: '10px 0 0 12px' } },
            React.createElement('div', { style: { alignItems: 'center', display: 'flex', gap: 10, justifyContent: 'space-between' } },
              React.createElement('p', { style: styles.meta }, t('availableThemes', { count: parsed.themes.length })),
              React.createElement('button', { type: 'button', style: { ...styles.button, background: 'var(--dsw-alias-bg-layer-3)', color: 'var(--dsw-alias-label-primary)', padding: '5px 9px' }, onClick: () => { void clearSavedArchive() }, disabled: loading }, t('removeArchive'))),
            React.createElement('ul', { style: styles.list }, parsed.themes.map(theme => {
        const active = selected === theme.path
        return React.createElement('li', { key: theme.path },
          React.createElement('button', {
            type: 'button',
            style: { ...styles.theme, cursor: 'pointer', outline: active ? '2px solid var(--dsw-alias-state-business-primary)' : 'none' },
            onClick: () => activate(theme),
            'aria-pressed': active,
          },
          React.createElement('span', { style: { background: color(theme, 'editor.background', 'sideBar.background') ?? 'var(--dsw-alias-bg-base)', border: '1px solid var(--dsw-alias-border-l2)', borderRadius: 5, height: 30, width: 30 } }),
            React.createElement('span', null,
              React.createElement('strong', { style: { display: 'block' } }, theme.label),
            React.createElement('span', { style: styles.meta }, `${t('workbenchColors', { count: Object.keys(theme.colors).length })}, ${t('syntaxRules', { count: theme.tokenColors.length })}`)),
          React.createElement('span', { style: { color: 'var(--dsw-alias-label-secondary)', fontSize: 12 } }, active ? t('applied') : t('apply'))))
            }))) : null)
      })))
  )
}
