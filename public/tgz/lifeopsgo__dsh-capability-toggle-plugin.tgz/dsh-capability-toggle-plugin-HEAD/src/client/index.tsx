/**
 * Browser half of dsh-capability-toggle-plugin — the composer-row entry point.
 *
 * Registers one control into the composer tool row (`conversation.input.left`):
 * a small toggle button that opens the capability popup. This module owns only
 * the control host (open/close, load-on-open, out-of-click/Escape dismissal,
 * the request-ordering guard, and the write callback) plus the plugin wiring;
 * the popup's presentation lives in ./components.tsx and the two same-origin
 * HTTP calls live in ./api.ts.
 *
 * The button and every switch are disabled while the agent is running — toggles
 * apply only when the agent is idle, per the plugin's contract. State is read
 * from and written to the Host over the ./api.ts routes; the Host owns
 * persistence and enforcement.
 *
 * The component is authored with React from the loader's module table and needs
 * no framework client types at build time (see ./types.ts for why the platform
 * slot/locale types are declared locally).
 *
 * @module dsh-capability-toggle-plugin/client
 */

import { useCallback, useEffect, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { createPortal } from 'react-dom'
import type { CSSProperties } from 'react'

import type {
  CapabilityToggleProjection, ToggleLevel, ToggleState,
} from '../shared/types.ts'
import { fetchState, respondConfirm, subscribeConfirm, writeState, writeStateMany } from './api.ts'
import { ConfirmationCard, Panel } from './components.tsx'
import { insideAny } from './dismiss.ts'
import { installSelectionClickGuard } from './drag-guard.ts'
import { usePortalHost } from './portal.ts'
import { applySessionRefsPref, bindTriggerService } from './session-refs.ts'
import { NS, dictionaries } from './locales.ts'
import { publishPrefs, readPrefs, subscribePrefs } from './prefs.ts'
import type { PanelPrefs } from './prefs.ts'
import { runningOf, sessionIdOf } from './session.ts'
import { injectStyles } from './styles.ts'
import type { ClientContext, ConfirmCard, ConfirmPush, InputZoneProps } from './types.ts'

interface ConfirmEntry {
  readonly card: ConfirmCard
  readonly status: 'idle' | 'busy' | 'retry'
}

interface ConfirmScope {
  readonly sessionId: string
  readonly cards: Map<string, ConfirmEntry>
  active: boolean
}

/** The always-visible control: a button that toggles the popup. */
function CapabilityToggleControl(props: InputZoneProps): JSX.Element | null {
  const { t } = props
  const sessionId = sessionIdOf(props)
  const running = runningOf(props)
  const [open, setOpen] = useState(false)
  const [projection, setProjection] = useState<CapabilityToggleProjection | null>(null)
  const [loading, setLoading] = useState(false)
  const [prefs, setPrefs] = useState<PanelPrefs>(readPrefs)
  const wrapRef = useRef<HTMLDivElement | null>(null)
  // The overlay lives in a body-level portal, so it is not a DOM descendant of
  // wrapRef; outside-click dismissal has to test this node as well.
  const popupRef = useRef<HTMLDivElement | null>(null)
  // The composer tool row is a `container-type: inline-size` box, which becomes
  // the containing block for `position: fixed` children: an overlay rendered
  // inline centers on that row, not the viewport. The host's slot catalog says
  // fixed overlays must portal to the document body for this reason.
  const popupHost = usePortalHost()
  const confirmHost = usePortalHost()
  const buttonRef = useRef<HTMLButtonElement | null>(null)
  const aliveRef = useRef(true)
  // Read and write each get their OWN monotonic token; a settled request
  // commits only when it is still its channel's latest. Separate channels
  // matter because a write and a refresh must not invalidate each other by
  // sharing one counter — that let a slow refresh discard a newer write's
  // committed projection (and vice versa), leaving the panel out of sync with
  // the server. A started write also bumps the read token, since its result
  // supersedes any refresh already in flight.
  const readSeqRef = useRef(0)
  const writeSeqRef = useRef(0)
  // Writes are serialized through this promise chain so rapid toggles apply in
  // FIFO order server-side; the last write's projection then reflects every
  // preceding write, instead of racing concurrent POSTs whose apply order (and
  // thus returned projection) is undefined.
  const writeChainRef = useRef<Promise<void>>(Promise.resolve())

  useEffect(() => {
    aliveRef.current = true
    return () => { aliveRef.current = false }
  }, [])

  const refresh = useCallback(async () => {
    const seq = ++readSeqRef.current
    setLoading(true)
    try {
      const next = await fetchState(sessionId)
      // Bail if unmounted, superseded by a newer read, or overtaken by a write
      // started after us (which bumped readSeqRef): don't clobber fresher state.
      if (!aliveRef.current || seq !== readSeqRef.current) return
      setProjection(next)
    } finally {
      // Clear loading only if still the latest read, so a superseded refresh
      // never strands `loading` true nor fights the winner over it.
      if (aliveRef.current && seq === readSeqRef.current) setLoading(false)
    }
  }, [sessionId])

  useEffect(() => {
    if (typeof document === 'undefined') return
    return installSelectionClickGuard(document)
  }, [])

  useEffect(() => applySessionRefsPref(prefs.disableSessionRefs), [prefs.disableSessionRefs])

  // Load when the popup opens; also reload when the agent finishes a turn while
  // open, since restrictions may have changed the visible tool set.
  useEffect(() => {
    if (open) void refresh()
  }, [open, running, refresh])

  // Close on outside click and on Escape.
  useEffect(() => {
    if (!open) return
    const onDown = (e: MouseEvent) => {
      if (insideAny(e.target, [wrapRef.current, popupRef.current])) return
      setOpen(false)
    }
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false) }
    document.addEventListener('mousedown', onDown)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', onDown)
      document.removeEventListener('keydown', onKey)
    }
  }, [open])

  // Return focus to the trigger when the panel closes, so a keyboard user who
  // opened it (and especially one who dismissed it with Escape) is not stranded
  // with focus on a now-removed panel element. Gated on `wasOpenRef` so the very
  // first render (open=false) does not steal focus on mount; only a real
  // open->close transition restores it.
  const wasOpenRef = useRef(false)
  useEffect(() => {
    if (!open && wasOpenRef.current) buttonRef.current?.focus()
    wasOpenRef.current = open
  }, [open])

  const onSet = useCallback((level: ToggleLevel, id: string, next: ToggleState) => {
    const seq = ++writeSeqRef.current
    // A fresh write supersedes any refresh in flight: invalidate the read token
    // so a late-landing refresh cannot overwrite this write's projection.
    readSeqRef.current++
    // Enqueue on the write chain so writes apply in FIFO order server-side.
    writeChainRef.current = writeChainRef.current.then(async () => {
      const updated = await writeState({ session: sessionId, level, id, state: next })
      // Only the latest write commits its projection; earlier writes' results
      // are stale (the latest reflects them too, applied cumulatively).
      if (!aliveRef.current || seq !== writeSeqRef.current) return
      if (updated !== null) setProjection(updated)
      else void refresh()
    })
  }, [sessionId, refresh])

  // The toolbar's bulk action: same one-token-per-write / FIFO-chain discipline
  // as onSet, just posting the batched /set-many route instead of N single
  // writes. Sharing writeChainRef with onSet keeps a bulk action and an
  // in-flight single toggle from racing each other server-side.
  const onSetMany = useCallback((level: ToggleLevel, ids: readonly string[], next: ToggleState) => {
    const seq = ++writeSeqRef.current
    readSeqRef.current++
    writeChainRef.current = writeChainRef.current.then(async () => {
      const updated = await writeStateMany({ session: sessionId, level, ids, state: next })
      if (!aliveRef.current || seq !== writeSeqRef.current) return
      if (updated !== null) setProjection(updated)
      else void refresh()
    })
  }, [sessionId, refresh])

  const onPrefsChange = useCallback((next: PanelPrefs) => {
    setPrefs(next)
    publishPrefs(next)
  }, [])

  useEffect(() => subscribePrefs(setPrefs), [])

  const scopeRef = useRef<ConfirmScope | null>(null)
  const [, rerender] = useState(0)

  const updateScope = useCallback((next: ConfirmScope | null) => {
    scopeRef.current = next
    rerender(n => n + 1)
  }, [])

  const apply = useCallback((cards: Map<string, ConfirmEntry>) => {
    const scope = scopeRef.current
    if (scope === null) return
    updateScope({ sessionId: scope.sessionId, cards, active: scope.active })
  }, [updateScope])

  const applyRef = useRef(apply)
  applyRef.current = apply

  useEffect(() => {
    if (!aliveRef.current || sessionId === '') {
      scopeRef.current = null
      rerender(n => n + 1)
      return
    }
    const scope: ConfirmScope = { sessionId, cards: new Map(), active: true }
    scopeRef.current = scope
    rerender(n => n + 1)
    const stop = subscribeConfirm(sessionId, (push: ConfirmPush) => {
      const current = scopeRef.current
      if (!current || !current.active) return
      if (push.kind === 'snapshot') {
        const next = new Map<string, ConfirmEntry>()
        for (const card of push.cards) next.set(card.id, { card, status: 'idle' })
        applyRef.current(next)
        return
      }
      if (push.kind === 'resolved') {
        const previous = current.cards
        if (!previous.has(push.id)) return
        const next = new Map(previous)
        next.delete(push.id)
        applyRef.current(next)
        return
      }
      const next = new Map(current.cards)
      next.set(push.card.id, { card: push.card, status: 'idle' })
      applyRef.current(next)
    })
    return () => { scope.active = false; stop() }
  }, [sessionId])

  const onAnswer = useCallback((id: string, decision: 'allow' | 'deny') => {
    const scope = scopeRef.current
    if (scope === null) return
    const entry = scope.cards.get(id)
    if (entry === undefined || entry.status === 'busy') return
    const next = new Map(scope.cards)
    next.set(id, { card: entry.card, status: 'busy' })
    apply(next)
    void respondConfirm(scope.sessionId, id, decision).then(outcome => {
      if (!aliveRef.current) return
      const currentScope = scopeRef.current
      if (currentScope === null || currentScope.sessionId !== scope.sessionId) return
      const current = currentScope.cards.get(id)
      if (current === undefined) return
      if (outcome === 'accepted') {
        const next = new Map(currentScope.cards)
        next.delete(id)
        apply(next)
      } else if (outcome === 'gone') {
        const next = new Map(currentScope.cards)
        next.delete(id)
        apply(next)
      } else {
        const next = new Map(currentScope.cards)
        next.set(id, { card: current.card, status: 'retry' })
        apply(next)
      }
    })
  }, [apply])

  const confirmList = scopeRef.current === null || scopeRef.current.sessionId !== sessionId ? [] : [...scopeRef.current.cards.values()]

  return (
    <div className="dshct-wrap" ref={wrapRef}>
      <button
        type="button"
        ref={buttonRef}
        className="dshct-button"
        data-open={open}
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-label={t('button.aria')}
        title={running ? t('button.title.running') : t('button.title')}
        onClick={() => setOpen(v => !v)}
      >
        <SlidersIcon />
      </button>
      {open
        ? (
          renderPortaled(popupHost,
            <div
              className="dshct-overlay"
              ref={popupRef}
              // Backdrop click closes. The panel stops propagation, so only a
              // click on the backdrop itself (target === the overlay) reaches
              // here; the document-level outside-click handler also covers it.
              onMouseDown={e => { if (e.target === e.currentTarget) setOpen(false) }}
            >
              {loading && projection === null
                ? <div className="dshct-panel dshct-panel-loading">{t('loading')}</div>
                : projection === null
                  ? <div className="dshct-panel dshct-panel-loading">{t('unavailable')}</div>
                  : (
                    <Panel
                      projection={projection}
                      disabled={running}
                      t={t}
                      prefs={prefs}
                      onPrefsChange={onPrefsChange}
                      onSet={onSet}
                      onSetMany={onSetMany}
                    />
                  )}
            </div>,
          )
        )
        : null}
      {confirmList.length > 0
        ? (
          renderPortaled(confirmHost,
            confirmList.map(entry => (
              <ConfirmationCard
                key={entry.card.id}
                guardId={entry.card.guardId}
                guardAction={entry.card.guardAction}
                reason={entry.card.reason}
                toolName={entry.card.toolName}
                detail={entry.card.detail}
                busy={entry.status === 'busy'}
                failed={entry.status === 'retry'}
                t={t}
                onAnswer={decision => onAnswer(entry.card.id, decision)}
              />
            )),
          )
        )
        : null}
    </div>
  )
}

/** Render into the body-level host when one exists, otherwise in place. */
function renderPortaled(host: HTMLElement | null, children: ReactNode): ReactNode {
  if (host === null) return children
  return createPortal(children, host)
}

/** Inline sliders glyph (self-contained; avoids depending on the icon package). */
function SlidersIcon(): JSX.Element {
  const s: CSSProperties = { display: 'block' }
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" style={s} aria-hidden="true">
      <path d="M2 4.5h6M11 4.5h3M2 11.5h3M8 11.5h6" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
      <circle cx="9.5" cy="4.5" r="1.7" stroke="currentColor" strokeWidth="1.3" />
      <circle cx="6.5" cy="11.5" r="1.7" stroke="currentColor" strokeWidth="1.3" />
    </svg>
  )
}

/** Cordis plugin name (client half). */
export const name = 'dsh-capability-toggle-plugin/client'

/** Services this client half injects. */
export const inject = ['slots', 'locale']

/**
 * Client plugin body: install the dictionaries and the composer-row control.
 * @param ctx - the client root context (narrowed locally; see ./types.ts).
 */
export function apply(ctx: ClientContext): void {
  bindTriggerService(() => ctx.get?.('inputTriggers'))
  ctx.effect(() => injectStyles(), 'capability-toggle: styles')
  ctx.effect(() => ctx.locale.register(NS, dictionaries), 'capability-toggle: dictionaries')
  ctx.slots.inject('conversation.input.left', () =>
    ctx.slots.register(
      { name: 'conversation.input.left', id: NS, order: 40, locale: NS },
      CapabilityToggleControl as unknown as (props: InputZoneProps) => unknown,
    ),
  )
}
