# 指针供给方案（S1R 后续 · 册一至册三）—— 小节地址由库供给 · 写入事务化

> **态标签（R1/R5）**：本档为**决策态**产物，**未施工**。册一至册三的落地须**具名授权**。
> **上游**：S1R（2026-09-19 · P0–P3）已施工并经本会话实测复核；本档只处理其**残余缺口**，不改已收口部分。
> **证据纪律**：本文所有读数均为**本次会话实测**（复跑命令见 §7），非自述、非估计。

---

## 1 问题定位（一句话根本决策）

**根本决策：`notes/x.md §y` 是库的地址空间 —— 地址由库侧定义并供给，模型只做选择、不得发明；索引行与其详情小节是「一次写入的两个部分」，必须同事务。**

取证链（四条，逐条可复跑）：

| # | 事实 | 读数 |
|---|---|---|
| ① | 存量悬空指针的来源 | `section-ref-reanchor.mjs` 27 条重指样本，逐条 `git log -S` 回溯首次引入提交：**24 条由 `memory: distill` 引入** · 1 条 snapshot · 2 条无引入提交 |
| ② | 写入面生产集中度 | 库侧触碰主档的 40 次提交中 **39 次 = `memory: distill`**，1 次 = deep-sleep |
| ③ | 机制实锤（行落了、详情从没落） | `87478c4` 新增两行指向 `notes/env.md §ZCode 环境`，**同提交 `notes/env.md` 零改动**；该名在 env.md **全历史不存在**（真名 `ZCode 配置`） |
| ④ | 规模化同型 | `21046e3` 一次蒸馏新增 **55 条**索引行，同提交 `notes/` 只改 **3 项** |

**根因两句话**：
- **地址来源错**：蒸馏 prompt 要求「section = **既有** ## 小节名」，但材料里**从未注入真实小节清单**（`distill-agent.ts:191-198` 只有会话正文 / manifest / 召回行 / pending 候选）⇒ 模型只能凭记忆编名。抽查 5 个典型悬空名，在真库 **334** 个两级小节中 **0 命中**。
- **写入不同步**：`memory-append --new` 原先只校行首标签；且 `writeDispatch` 中 **appends 循环先于 newIndex 循环**，append 因「顶层 ## 需人工建锚」exit 2 失败后 **行照写**（仅 `failed++`）。

---

## 2 现状契约（已完成 / 残余）——描述现状，不写目标态

### 2.1 已完成（S1R，本会话实测复核，非自述）

| 项 | 实测读数 |
|---|---|
| 库工具链已实装 | `memory-append.mjs` / `section-ref.mjs` / `memory_write_gate.mjs` / `read_section.mjs` 仓 ↔ 库 **sha256 逐一相同** |
| 索引行准入生效 | 隔离库实跑：悬空指针 → **exit 2 不落盘**；合法指针 → exit 0；`SHOUCANG_APPEND_SECTION_CHECK=0` → 回退旧行为 |
| 真库棘轮 | `check-section-refs`：exists **551** · partial **0** · ambiguous **0** · **missing 0** · 同名小节 **0**（主档 3 件 / 含指针行 526） |
| 跨面同源 | `check-section-ref-parity`（差分锁）PASS |
| 部署面 | `check-deploy-sync`：检查 260 件 · **不一致 0**（库内缺失 176 = 未部署，非错误） |
| 安装副本 | `check-installed-sync`：仓内 254 ↔ 已安装 254 · **逐件 sha1 一致** |
| 解析面真实读数 | 真库主档 3 件：含指针行 **526** · 指针总数 **551** · 一行多文件指针 **25 行**（全部解析正确）· 解析伪影 **0** |
| 深睡 principles 已受门 | `deepsleep-apply.ts#gateText` → `memory_write_gate.mjs ['AGENT.md', tmp]`（§ 已被校）——**非缺口** |
| 在册 | `check-content-types` / `check-section-ref-parity` / `check-section-refs` / `check-deploy-sync` 均在 `CHECKS`，定点回归 4/145 PASS（**非全量**） |

### 2.2 残余缺口（本方案的对象）

| 代号 | 缺口 | 后果 | 证据位置 |
|---|---|---|---|
| **G1** | 提示侧无真实小节清单 | 门会「拒」⇒ **污染换成了丢料**（同条知识静默丢弃，只落日志） | `distill-agent.ts:191-198` 材料段无清单；`distill.ts:162` 只写"既有小节名" |
| **G2** | 行—详情非原子 | **已实测坐实，且比"失败"更严重**：`appends` 落点失败（顶层节缺 ⇒ exit 2）后**仅 `failed++` 不阻断**，随后 `newIndex` 行**照写**——且该行指针指向**合法存在**的小节 ⇒ **行落了、知识没落，指针还完全可解析**。准入在此**原理上失明**（它校验的是地址有效性，不是"该地址下是否真有这段知识"）。实测：行 `[env] 半落探针 … → notes/env.md §DSH 环境` 落盘，正文未落 | `distill-write.ts:218-231`（appends）先于 `:232-285`（newIndex），失败仅 `failed++` |
| **G3** | 拒收不可见、无回退 | newIndex 失败只 `log` + 计数，**无逐条审计、无 pending 回退** ⇒ 丢料不可查、不可捞；**G2 的半落形态连 `failed` 都不计**（指针合法 ⇒ 走的是成功分支） | `distill-write.ts:284` |
| **G4** | profiles 通道无 § 准入 | USER/AGENT 行（`← 源: notes/x.md §y`）可落悬空；深睡 `profileOps` 同路。AGENT.md 现 **97 行**带指针（当前 0 悬空 ⇒ **潜在口**） | `writeProfileLine`（`distill-write.ts:121-158`）无 § 判据；调用点 `deepsleep-run.ts:532` |
| **G5** | appends 放置是**第 5 份实现** | **已实测坐实**：夹具库仅 `## DSH 环境`，写入「环境」⇒ 双向包含（`k.includes(t)`）**误配，探针落进了「DSH 环境」节**（exit 0 无提示）。与三态语义不统一 | `memory-append.mjs:59-98` 本地 `findChild` / `matches` |
| **G6** | 写门文件存在性检查的字符类漏 CJK 文件名 | **已实测，但实际不可达（降级）**：`export/.../notes/<CJK>.md` 不被 `[A-Za-z0-9_-]+` 捕获 ⇒ 不报"文件不存在"。但 **`notes/` 白名单本身只允许 ASCII 文件名**（`memory-append.mjs:31` / `section-ref.mjs#normNotesFile`），CJK 名文件**进不了库** ⇒ 该漏检在当前契约下**不可达**。**原写的"跨文件指针索引错位"经实测证伪**：ASCII 名多指针三例（前缺/后缺/单缺）**全部正确 exit 2** | `memory_write_gate.mjs:120-126` |

> ⚠ 深睡 **principles** 通道**不在**缺口内：它整文件走 `memory_write_gate`（`applyPrinciples → commitAccepted → gateText`，target=`AGENT.md`），§ 已被校 — 本会话实测确认。
>
> ⚠ **已证伪、不进入本方案的候选缺口（如实登记，防后来人重复怀疑）**：
> - 「`pointersOfRow` 解析伪影（spec 吞入 `→ notes/x.md`）」——合成输入可触发，但**真库 0/551 例**（一行多文件指针 25 行全部解析正确）⇒ **不成立**，仅作册一的**夹具级**加固项。
> - 「写门跨文件伪指针**索引错位**」——**本会话实测证伪**：ASCII 文件名的三例多指针（第一个缺 / 第二个缺 / 单个缺）**全部正确 exit 2**。真实（但不可达）的漏检是 **CJK 文件名不进字符类**，而白名单本就禁止 CJK 名 ⇒ 降级为 G6 备注。
> - 「深睡 principles 通道绕过写门」——**证伪**：`gateText` 实测以 `AGENT.md` 为 target 走 `memory_write_gate.mjs`。

> ⚠ **本方案最重要的一条认识（G2/G7 实证推论）**：**准入只能保证「地址有效」，不能保证「地址下有知识」**。
> 两条独立实测形态：
> 1. **半落**（写入时）：append 失败 → 行照写 → 指针指向**真实存在且合法**的小节 ⇒ 该行背后什么都没有。
> 2. **空壳落点**（P2 重指时，**已在真库发生**）：重指表把行从 `missing` 指到**存在但正文为 0 字**的小节。
> ⇒ 这解释了「棘轮全绿」与「指针指向空处」为何能并存：
> **现有全部机检都在测地址空间（名字能否解析），没有一条在测「地址背后是否真有内容」。**

### 2.3 真库实测：空壳落点清点（G7 · 本轮新发现）

| 读数 | 值 |
|---|---|
| 主档指针总数 | 551（全部可解析 ⇒ 棘轮**全绿**） |
| **指向空壳小节**（可解析、正文 0 非空行） | **4 条**，去重 **3 个**小节 |
| — `notes/lessons.md §行号与字节核验` | 被 **2** 条索引行指向 |
| — `notes/lessons.md §通道与代理（GitHub raw / ghproxy）` | 被 1 条 |
| — `notes/env.md §执行环境（pwsh / node / 工具可用性）` | 被 1 条（`AGENT.md`，指针 `§插件安装通道/§执行环境`） |
| **P2 重指表 27 条中有多少落到空壳** | **2 条**：`§编辑安全与字节核验 ⇒ §行号与字节核验`、`§环境与通道 ⇒ §通道与代理（GitHub raw / ghproxy）` |
| 空壳小节的引入提交 | `7aecee6` = `memory: snapshot 2026-09-11T05:47:26`（**非 P2 新造**：P2 未改 `notes/lessons.md`） |

**判因（两步，均已实测）**：
1. 空壳节**先于** P2 存在（引入者 `7aecee6`，P2 提交 `3c7c25a` 未触碰 `notes/lessons.md`）⇒ 空壳是**旧账**；
2. 但 P2 的**重指表把行指了过去**——旧指针 `missing`（不可解析，能红）被换成**可解析但空**（全绿）。
   ⇒ **P2 消除了红灯读数，却没消除「行背后没有知识」**。这正是「棘轮归零」与「内容缺失」并存的机制。

**待决项（须用户拍板，非本方案可自决）**：这 3 个空壳小节与其 4 条引用行如何处置——
① 回填正文（从 `notes/archive/` 或历史提交捞）② 重指到真正承载该知识的小节 ③ 废弃该索引行。
**本方案不自行处置**（属存量真源改写，R3 第 ①/④ 类）。

---

## 3 册一 · 地址供给（根因消除）

**目标**：让模型**从清单里选**地址，而不是编地址；判据面从「事后拒收」前移到「事前供给」。

**做法（方向级）**
1. 新增**地址供给段**（材料侧，非 persona）：`notes/<file> → 现有 ## / ### 标题清单`，由库侧现读生成。
2. **单一实现**：清单生成复用 `section-ref` 的 `sectionTitles`（不新写解析器）。
3. **双面接线**（具体落点，改前须逐点核）：
   | 面 | 接线点 | 形态 |
   |---|---|---|
   | 蒸馏 | `distill-agent.ts:191-198` `userInput` 数组 | 新增一段 `## 可用小节地址（appends/newIndex 的 section 必须逐字取自此处）` |
   | 深睡 | `deepsleep-materials.ts` 的 `gatherMaterials` 返回体 | **并入既有「现行树节清单」段**（`deepsleep-materials.ts:58`），不叠第二份 |
   | 生成器 | 新增 `src/section-supply.ts`（薄件：只调 `sectionTitles` + 拼文本 + 预算裁剪） | 供上面两处共用（**单一实现**） |
4. **预算有界**：超出材料预算时降级为「白名单 5 文件 ## 级 + 本段召回命中文件的 ### 级」；继续超则只给 ## 级。⚠ 清单**绝不写进 `distillPrompt`/persona**（用户可自定义且会陈旧），只进材料。
5. **夹具级加固**（非缺口，随册一顺带）：`check-section-ref-parity` 增加合成输入用例，把「spec 吞入 `→ notes/x.md`」的潜在形态钉死（真库 0 例，但**契约不该依赖输入恰好合法**）。

**验收方案（成对）**
- **在册机检**（新增 `check-section-supply.mjs`，登记 `CHECKS`）：正面断言——**从装配函数真跑一遍**得到的 `userInput` 文本**含清单段**，且**清单条数 == `sectionTitles` 实测数**（"接线 ≠ 抵达"型断言，补假绿：只 import 不等于抵达）。
- **先红**：改造前该断言必 FAIL（无段）；改造后 PASS。**红读数入档**。
- **阴性对照**：3 节夹具库 ⇒ 清单恰好 3 条、零误报；空库 ⇒ 显式输出「清单 0 条」而非缺段（输入量可见化）。
- **读数**：新增审计字段 `sectionMiss`（模型给的 section 不在清单内）落 `distill-run`；比较注入前后分布。**N=0 显式记 0**。
- **回归红线**：`check-section-refs` 棘轮保持 **0**（只许收紧，不上调基线）。

**UI/RPC 影响面（显式声明，避免"改了 UI 不知道"）**

| 消费点 | 读数 | 本轮影响 |
|---|---|---|
| `GET /memory/overview`（`panel-memory.ts:60-85`） | 读 `distill-run` 的 `added/rejected/failed` + `gate-reject` 计数 | **兼容**：只**新增**可选字段 `sectionMiss`，不改既有字段语义 ⇒ 前端读数不变，**无需改契约** |
| `spec/panel-contract` 契约表 | `distill-run` 不是 RPC 契约字段（审计产物） | **不动**：不新增路由、不改 `panel-contract.ts` |
| `client.js` 前端 | 只消费 overview 既有字段 | **不动**（无 `build:client` 需求） |
| 深睡审计（`deepsleep-run.ts:613-614`） | `enqueued`/`result` 计数 | 册一**不动**；若加段后材料条数变化，只影响日志文本 |

> ⇒ **本方案不触发 UI 契约变更**；若施工中发现必须改契约，按仓规 ⑦ 走 `gen-panel-contract --check` + `check-panel-contract` 双门。

**不做**：不自动建顶层散落大节；不把清单固化成提示词常量；不改 `section` 归一化逻辑。

---

## 4 册二 · 写入事务化与拒收可见化

**目标**：索引行与它的详情**同生共死**；被拒的知识**可见、可捞**，不再静默消失。

**做法（方向级）**
1. **段级成对裁决**（针对 G2 实测形态）：`appends` 与 `newIndex` 之间建立**段级提交边界**——任一条 append 未成功 ⇒ 该段**不进入** newIndex 落盘（或仅落**与失败 append 无关**的行）。判据用**同 target 文件 + 指针可解析前缀**配对，保守优先。
2. **拒收逐条审计**：`newIndex` 被拒 ⇒ 落 `gate-reject`（含 target / 指针 / 原因分类：missing｜ambiguous｜dup｜容量｜其他），不吞成聚合 `failed` 计数。
3. **未落地知识回退**：被拒的行（含其概况）写入 `pending/` 候选，等下轮重蒸或人工认领 —— **复用既有 project-defer 降级机制，不新造通道**。
4. 水位推进逻辑**不动**（防重演"静默丢料"型历史缺陷）。

**新增判据：内容存在性（补 G2/G7 暴露的空白面）**

> 现有全部机检测的是**地址空间**；本条测**地址背后是否有内容**。这是本册的**核心产出**，不是附加项。
> ⚠ **词面代理已被本轮实测否证**（见下「失败记录」）⇒ 本条**只做确定性判定：正文非空（含非 stub）**，
> **不做语义/词面相似度判定**。

- **形态（v2 · 按实测修正）**：对每条索引行，沿读侧回落语义取**最终落点小节**，判定其「标题后到下一个同级/更高级标题之间」**是否存在非空行**。
  - `0 非空行` ⇒ 记「空壳落点」（**确定性事实，可直接当 FAIL 门**）
  - 正文非空 ⇒ 通过（**不追加词面判定** —— 见失败记录）
- **落点**：新增 `scripts/check-pointer-content.mjs`，登记 `CHECKS`。
  - **真库基线（本轮实测）**：空壳落点 **4 条**，去重 3 小节 ⇒ 可作**棘轮基线 4**（只许收紧）。
  - ⚠ 基线须**先经用户确认**这 3 个空壳的处置口径（回填/重指/废弃）后再下调，否则会锁死待决项。
- **阴性对照**：夹具库放「有内容节 + 空壳节 + 不可解析节」⇒ 只报空壳 1 条，零误报。

**⚠ 失败记录（如实入档，防后来人重走）**：
第一版探针用「行主题词 ∩ 小节正文实词 ≥1」作判据，真库读数 **405/551 = 73.5% 疑似**——
但抽验 `§网络坑`（1812 字）、`§DSH 环境`（16084 字）等**内容充沛的宽节全被判疑似**。
**根因**：索引行用缩写短语（"代理分通道/git不读env"），小节标题是完整名（"网络坑"），
**词面交集天然为零** ⇒ 该代理**在真实数据上失效**，已弃用。
**结论**：内容存在性**只能做确定性的"有没有非空行"**，语义层的"内容对不对"**必须交模型**（本仓既有分工），
不得用词面代理冒充。

**验收方案（成对）**
- **先红夹具**：① 模拟 G2（append 悬空 → 行指向合法小节）⇒ 段级裁决**必须**让行**不落**；② 合法段 ⇒ 行照常落、零 pending（**阴性对照**）。
- **隔离库实跑**：改造前／后双跑读数入档（改造前：行落 + 详情未落 = 已实测）。
- **在册机检**：审计字段存在性（`gate-reject` 带指针字段）+ 回退文件命名规范 + `check-pointer-content` 在册。
- **回归红线**：真库棘轮 0 不变；`check-deploy-sync` 0 不一致。

**不做**：不改容量判据（用户 2026-09-16 判定"提醒即可"）；不删任何既有行；不碰 `_memory/` 以外真源；**不把词面代理当语义判据**（不作 FAIL 门）。

---

## 5 册三 · 判据单一化收尾 + profiles 准入

**目标**：把 G5/G4 两个"同类判据的第二份实现"收干净——S1R 已完成"读侧/写门/准入"的收敛，**放置与画像两条路还在外面**。

**做法（方向级）**
1. **appends 放置收敛到 `section-ref`**：保留「缺失层自动分裂 `###`」作为**写入策略**，但匹配语义统一为三态（exact 优先 → loose 唯一命中 → 多命中 ⇒ 拒绝并要求「父/子」全路径），删除本地 `findChild`/`matches` 双向包含实现。
2. **profiles § 准入补齐**：`writeProfileLine` 落盘前对行内 `← 源: notes/x.md §y` 跑**同一** `admitIndexRow` 语义（跨面同源，差分锁守）；`missing` ⇒ 拒（与写门同判据），`ambiguous`/`partial` ⇒ 放行 + 提示。
3. 两条都**不新增判据**，只把已有单一实现接上去。

**验收方案（成对）**
- **差分锁扩面**：`check-section-ref-parity` 夹具集纳入**放置决策**（同一 `(文件, 路径)` → 期望落点/拒绝逐例比对）。
- **先红**：现实现下「环境」双向包含命中「DSH 环境」⇒ 夹具应红；收敛后为 ambiguous 或 exact。
- **画像准入先红**：造一条无锚 `← 源:` 行 ⇒ 现落盘、改造后拒。
- **阴性对照**：真库 AGENT/USER 行数不变（97 / 8），棘轮仍 0 —— 证明"只堵新口、不动存量"。

**不做**：不改写存量 0 悬空态（已归零，无存量手术）；不上调任何棘轮基线。

---

## 6 验收总纲（每册同口径，缺一条即未完成）

| # | 判据 | 命令 / 证据 |
|---|---|---|
| ① | 仓内绿 | `npm run typecheck` + `npm run build` |
| ② | 全量门禁 | `node scripts/check-runner.mjs`（**不带 `--only`/`--fast`**；子集只作过程检查） |
| ③ | 新件在册 | 每册新增机检件**登记进 `CHECKS`**（未登记 = 没写） |
| ④ | 先红可证 | 改造前夹具必红（逐册列出红读数） |
| ⑤ | 部署同步 | `check-deploy-sync` 0 不一致（含库内 `scripts/`） |
| ⑥ | 运行态生效 | 热重载后跑 `check-installed-features`——**文件 sha 一致 ≠ 特性齐全** |
| ⑦ | 云端 + pin | `git push` → `git status -sb` 无 ahead → 核 profile `dependencies['dsh-shoucang-memory']` 的 `#<sha>` |
| ⑧ | 推送前 | `node scripts/check-public-tree.mjs` 必须 PASS |

---

## 7 证据索引（复跑命令 + 本次读数）

```powershell
# ① 来源归因：27 条重指样本逐条回溯
Select-String -Path D:\FF\shoucang\scripts\section-ref-reanchor.mjs -Pattern "^\s*'(notes/[^']+ §[^']+)':"
git -C <库根> log --format='%s' -S '<小节名>' -- <file>
# ② 写入面集中度
git -C <库根> log --format='%s' -100 -- MEMORY.md AGENT.md USER.md notes | Group-Object {…}
# ③ 机制实锤
git -C <库根> show 87478c4 -- MEMORY.md notes/env.md
git -C <库根> log -S 'ZCode 环境' --all -- notes/env.md      # → 空（全历史不存在）
# ④ 规模化
git -C <库根> show --stat --format='' 21046e3
# ⑤ 棘轮 / 差分锁 / 部署面 / 安装副本
node scripts/check-section-refs.mjs --json
node scripts/check-runner.mjs --only check-section-ref-parity,check-section-refs,check-deploy-sync
# ⑥ G5 放置误配（夹具库只放 ## DSH 环境，写「环境」）
node <库根>/scripts/memory-append.mjs notes/env.md '环境' '探针正文'   # → 探针落进「DSH 环境」节
# ⑦ 解析面真实读数（伪影 0 的取证）
node scripts/.probe-pointer-artifact.mjs                            # 一次性探针（已删）
# ⑧ 空壳落点全量清点（§2.3 读数来源 · 临时探针已删，复现逻辑见下）
#    口径：pointersOfRow → 逐部分 resolveSection 取最后可解析者 → 标题后到下一同级/更高级标题之间非空行数
# ⑨ G2 半落实证（append 失败后行照写且指针合法）
node <库根>/scripts/memory-append.mjs notes/env.md '完全不存在的顶层XYZ' '正文'   # exit 2
node <库根>/scripts/memory-append.mjs MEMORY.md - --new '[env] 半落探针 · 概况 → notes/env.md §DSH 环境'  # exit 0 → 行落、正文未落
```

| 读数 | 值 |
|---|---|
| 重指样本归因 | distill **24** / snapshot 1 / 无引入 2（共 27） |
| 主档提交归因 | distill **39** / deep-sleep 1（共 40） |
| 真库小节总数（两级） | **334** |
| 抽查 5 个悬空名命中率 | **0 / 334** |
| 解析面 | 含指针行 526 · 指针 551 · 多文件指针行 25 · **伪影 0** |
| 棘轮 | exists 551 · partial 0 · ambiguous 0 · missing 0 · dup 0 |
| **空壳落点（新）** | **4 条 / 去重 3 小节**（棘轮仍全绿） |
| **P2 重指落空壳** | **2 / 27** |
| G5 放置误配 | **成立**（写入「环境」⇒ 落进「DSH 环境」） |
| **词面代理探针** | **405/551 疑似 = 73.5% ⇒ 判据失效，已弃用**（抽验宽节全误报） |
| 部署面 | 260 件 · 不一致 0 |
| 安装副本 | 254 / 254 一致 |

---

## 8 风险、回退与不做

| 风险 | 处置 |
|---|---|
| 清单体积挤占材料预算 | 按既有分片/预算机制裁剪；超限逐级降级（§3-4） |
| 拒收率上升（丢料可见但可能真丢） | 册二回退 `pending/` 兜底；审计逐条可见 |
| 与用户自定义 `distillPrompt` 冲突 | 清单只进**材料**，不进 persona |
| 册三改放置语义 → 落点行为变化 | 保留「拒绝并要求全路径」而非猜；先红 + 阴性对照双证；真库当前 0 悬空，无存量回填 |
| 需要上调棘轮基线 | **本方案不需要**；棘轮只许收紧（上调须用户拍板） |
| 真库数据 | 本方案**不做存量手术**；仅册二运行时的自然 `pending/` 流转 |
| 清单规模（334 节）可能超材料预算 | 逐级降级（§3-4）；若实测降级过频，则把「### 级」改为**按本段召回命中文件**限定（宁可少给 ## 级也不截断到半行） |
| **空壳落点（真库已存在 4 条）** | 属**存量真源**，本方案**不自行处置**（R3 ①/④）⇒ 见 §2.3 待决项，由用户拍板回填/重指/废弃 |
| 词面代理类判据被误用 | 已在本档 §4 立**失败记录**；后续新增判据凡涉"内容相关性"一律**交模型**，不得用交集率冒充 |

---

## 9 施工清单（授权后按此顺序，逐步可停）

| 步 | 册 | 动作 | 停点判据 |
|---|---|---|---|
| 1 | 册一 | 建 `src/section-supply.ts` + 双面接线 + `check-section-supply.mjs` 在册 | 先红 → 绿、清单条数 == 实测数 |
| 2 | 册一 | 审计加 `sectionMiss` 字段 | 落一条真蒸馏，字段可读且 N=0 时显式 0 |
| 3 | 册二 | **段级成对裁决**（针对 G2 半落形态）+ 逐条 `gate-reject` + `pending/` 回退 | 先红夹具①②双证（改造前：行落而详情未落 = 已实测） |
| 4 | 册二 | `check-pointer-content.mjs`（**确定性判据**：正文非空；**词面代理已否证不用**） | 真库出「空壳落点」清单（基线 **4**）；**基线下调须等 §2.3 待决项拍板** |
| 5 | 册三 | 放置收敛（删本地双向包含）+ profiles § 准入 | 差分锁扩面 PASS、AGENT/USER 行数不变（97 / 8） |
| 6 | 全册 | 五层同步（§6 ①–⑧） | 每层有读数 |

> ⚠ **步 4 与 §2.3 待决项耦合**：`check-pointer-content` 一旦在册并把基线钉在 4，
> 那 3 个空壳要么被回填/重指、要么基线永留在 4。**建议：先跑报告态出清单交用户拍板，再决定是否设 FAIL 门。**

> **每步结束都必须能回答 R5**：「本步改了什么、态标签是什么、由谁授权、证据在哪」。

---

## 10 授权清单（R1）

| 册 | 内容 | 态 | 需要 |
|---|---|---|---|
| — | 出方案（本档） | 决策态 | 已完成（自主） |
| 册一 | 地址供给（清单注入 + 在册机检） | 施工态 | **具名授权** |
| 册二 | 写入事务化 + 拒收可见化 + pending 回退 | 施工态 | **具名授权** |
| 册三 | 放置路径收敛 + profiles § 准入 | 施工态 | **具名授权** |

**建议顺序：册一 → 册二 → 册三**（先除因、再补事务、最后收尾判据）。

---

## 11 施工记录（2026-09-19 · 三册全量落地）

> **态标签（R5）**：册一/册二/册三 = **施工态**，授权来源 = 用户在上一轮方案交付后明确指令「**目标模式，继续全量推进**」。
> 本会话另已先落 `docs/distill-admission-plan.md` 册三（失败三态）——本档 §7 的接口决策（指针册二须在其后）**前提已满足**。

### 11.1 每册落点与判据

| 册 | 落点（改动） | 在册判据 | 先红 → 后绿 |
|---|---|---|---|
| **册一** 地址供给 | **新增** `src/section-supply.ts`：`sectionAddressSupply`（复用 `section-ref#sectionTitles` 作唯一解析器、预算逐级降级+不截半行）+ `buildDistillUserInput`（纯装配，供"抵达"机检）；接线 `distill-agent`（材料段 + 审计 `sectionMiss`/`supplySections`） | `check-section-supply` | 先红：**无该模块 ⇒ 首跑 import 即失败**；后绿 **19 PASS** |
| **册二** 写入事务化 | `distill-write.ts`：`pairKeyOf`/`unpairedPointersOf`（**导出纯函数** ⇒ 可机检且不触真库）+ 段级成对裁决 + `-knowledge-defer-` 回退队列（幂等命名）+ 逐条 `gate-reject` **class 分类**；`distill-agent` 候选过滤器排除 `-knowledge-defer-`（**防重裁决循环**） | `check-pointer-pairing` + **`check-pointer-content`** | 先红（真机形态 G2：行落而详情未落）；后绿 **15 PASS** / **7 PASS** |
| **册三** 判据收尾 | `section-ref`（TS + `skill/scripts` 孪生 + 仓内两份）：增 `resolveLevelInParent`/`planPlacement`（**写侧严格语义**：exact → **前缀** loose 唯一 → 多命中**拒绝**；`loose:'contains'` 参数化 = 应急回退）；`memory-append`（三份副本）**删本地 `matches`/`findChild`**；`writeProfileLine` 补**画像行 § 准入**（与索引行同一实现）；差分锁**扩面 5 例放置** | `check-placement-convergence` + `check-profile-admission` + 差分锁扩面 | 先红（G5：环境→DSH 环境 误配；画像口 0 判据）；后绿 **12 PASS** / **9 PASS** / 差分锁 `+ 放置 5 例` |

### 11.2 真机读数

| 项 | 读数 |
|---|---|
| 地址供给（册一） | 真库材料段现含 `## 可用小节地址`（库侧清单）；`sectionMiss`/`supplySections` 落 `distill-run`（**新字段只增不改**） |
| 内容存在性（册二 · 复核方案 §2.3 基线） | **独立复现**：指针 **617** · 含指针行 **592** · **空壳落点 4 条 / 去重 3 小节** · 悬空 0 —— 与方案 §2.3 记录 **4/3 一致** |
| 画像口存量（册三） | AGENT **5** + USER **5** = **10 行**带 `← 源: notes/`；同判据下**全部可通过**（只堵新口、不动存量） |
| 放置语义（册三） | 夹具两态对照：默认写「环境」⇒ **exit 2 且文件零副写**；`SHOUCANG_APPEND_PLACEMENT_CHECK=0` ⇒ **exit 0 落进「DSH 环境」**（旧行为可复现 ⇒ 两态确有差别，非恒真） |

### 11.3 五层验收（本轮实测）

| 层 | 命令 | 读数 |
|---|---|---|
| ① 仓内绿 | `npm run typecheck` · `npm run build` | 均 exit 0 |
| ② 部署同步 | `deploy-installed` → `check-installed-sync --strict` | **364 件一致 / 漂移 0**；另 `check-deploy-sync` = **一致 86 · 不一致 0**（首跑曾红 **4 件**：库内 `memory-append.mjs`/`section-ref.mjs` 仍是旧逻辑 ⇒ **运行态走库内那份**，已部署归零） |
| ③ 运行态生效 | `dev_reload_package` | fiber active |
| ④ 功能探针 | `check-installed-features` | **71 项齐全**（本轮 +4：`sectionAddressSupply` / `planPlacement` / `unpairedPointersOf` / `源指针悬空`） |
| ⑤ 云端 + pin | push + `git status -sb` + profile pin | 见提交记录 |

### 11.4 遗留（**收口轮全部关闭**，2026-09-19）

> 收口授权：用户明确「**遗留全部处理，目标模式做**」⇒ 第 1 项由"待拍板"转入**施工态**（R1 具名授权），第 3 项转入施工态。

1. ~~**空壳落点 3 小节**（§2.3 待决项）~~ **已处置完毕**：4 条空落点行逐条重指 + 4 个空壳并档消除
   （`scripts/apply-empty-shell-merge.mjs --apply`，库备份 `~/.dsh/backups/sc-shellmerge-2026-09-19T08-37-15`，
   读数 `{applied:4, skipped:0, archived:4}`，三条事后断言全过）⇒ `check-pointer-content` 基线 **4 → 0**（`BASELINE_EMPTY = 0`，只许收紧）。
2. **跨批"行—详情"一致性** —— **判据面已覆盖，写入面明确不做**：`check-pointer-content` 的扫描是**全库**的
   （`notesFilesOf(bankRoot)` 全 `notes/*.md` + 全部索引行 → `scanEmptyLandings`），**不区分批次**
   ⇒ 跨批失配与同批失配在同一判据下同时可测（真机当前 **0**）。故不另立"跨批事务"：写入侧只保证同批成对（册二），
   跨批一致性由**全库巡检 + 定期登记**（§12）兜住。
3. ~~**两个"待认领"队列无自动消费者**~~ **已关闭（收口轮）**：`src/pointer-deficits.ts#deferredQueueOf` 作统一读出口，
   `registerDeficits` 作定期登记（挂维护链），判据 `scripts/check-deferred-queue.mjs` ⇒ 见 §12。
   设计边界**不变**：只登记不处置（不自动建锚、不回填内容）。

## 12 收口轮施工记录（2026-09-19 · 遗留清零）

> **态标签（R5）**：施工态。授权来源 = 用户指令「**遗留全部处理，目标模式做**」。
> 本轮同时收口 `docs/distill-admission-plan.md` §13.4 的两项（`needsAnchor` 消费方 + `dsh-client-auto-continue` 归因）。

### 12.1 落点与判据

| 项 | 落点（改动） | 判据 | 读数 |
|---|---|---|---|
| ① 行重指 | `scripts/section-ref-reanchor.mjs` `ROW_OVERRIDES` **+4 条**（批改前先核字节→`lessons §完整性核验`；架构档机检与落点→`flows`；git 推送与代理回退→`env §网络与代理`；不可达结论须多通道→`lessons §假失败`） | 幂等复跑 | 首跑改动 4 行；**复跑 0 改动**；备份 `~/.dsh/backups/sc-s1r-2026-09-19T08-35-31` |
| ② 空壳消除 | `scripts/apply-empty-shell-merge.mjs`（**新**；dry/apply 两态，先备份、先断言后执行、事后三断言） | `check-pointer-content --strict` | `{applied:4,skipped:0,archived:4}` ⇒ 空壳 **4 → 0** |
| ③ 统一出口 | `src/pointer-deficits.ts`（**新**）：`scanEmptySections`/`scanEmptyLandings`/`readAnchorNeeded`/`readKnowledgeDefers`/`pointerStats`/`deferredQueueOf`/`knowledgeDeferFileOf`/`registerDeficits`；`distill-bank#runSelfCheck` 挂维护链 | `check-deferred-queue` | 4 组断言全绿（含**幂等**与**干净库零写入**阴性对照） |
| ④ 判据收口 | `scripts/check-pointer-content.mjs` 重写为**薄封装**（扫描全部来自 `lib/pointer-deficits.js`，**不再自带第二份**）+ 基线钉 0；新增 `scripts/check-deferred-queue.mjs` 并**登记进 `check-runner`** | `check-runner` | 登记纪律（N1）：未登记 = 没写 |

### 12.2 真机读数（收口后）
| 项 | 读数 |
|---|---|
| 统一出口计数 | `{"empty-landing":0,"empty-section":0,"anchor-needed":25,"knowledge-defer":0}` **total = 25** |
| 登记闭环 | `{scanned:0, written:0, skipped:0}`（库已干净 ⇒ 零新增；**幂等**） |
| 小节寻址 | `check-section-refs`：exists **627** · partial **0** · ambiguous **0** · missing **0** |
| 空壳 | 空落点 **0** · 全库空壳标题 **0**（基线 0） |
| 库写入 | `Record` 影子对账 `分歧 0`；库仓提交 `1e8f891` 作**回退点** |

**注（如实登记，非缺陷）**：`anchor-needed` 行是**存量待人工建锚**的排队项（蒸馏写侧登记"知识无锚可落"），
本轮的产出是**让它可统一读取与定期登记**，**不是**自动建锚（§3 边界）。其处置权在用户：或建锚、或转 pending。

### 12.3 续修：队列读数两次**全盲**（2026-09-19 · G12/G13/G14 · 全权授权后施工）

> **判因**：§12.2 记的 `anchor-needed 25` 是**错的**——不是 25，也不总是 0；读数随"台账落在哪一卷 / 多长"而变。
> 两处机制性失明（都不是"没数据"，而是**读侧看不见**）：

| 缺口 | 判据（实测） | 修法 |
|---|---|---|
| **G12 窗口截断** | `readAnchorNeeded` 缺省 `slice(-4000)`：台账 2.2 万行时**靠前的缺陷行被静默漏掉**（出口 **25** vs 全量 **33**） | 改为**全量读**；判据 `check-deferred-queue` ①″（6001 行夹具，缺陷行放最前 ⇒ 旧实现 0 条） |
| **G13 轮转失明** | 台账**按大小轮转**（`rotateBySize` ⇒ `ledger.jsonl.1`）：17:45 轮转后主档只剩 105 行，**33 条 anchor 行全在旧卷** ⇒ 只读主档读数 **0**（全盲） | 复用**既有单一实现** `ledger-compact#readLedgerVolumes`（跨档按时间序）——**不自写第二份"读哪些文件"**；判据 ①‴（缺陷行只放旧卷 ⇒ 必须读到） |
| **G14 过时项冒充缺陷** | 台账里指向**已建好**小节的行仍在报"缺锚"（小节后来经别的路径建好） | `readAnchorNeeded(file, bankRoot)` 逐行判 `stillMissing`（复用 `section-ref#resolveSectionSpec`）；过时项归 `staleAnchor` + `staleRefs` 单列，**不计入** `counts/rows`；判据 ①′（含"删掉小节即变回真缺陷"的反例自证） |

**真机读数（修后 · 全部卷）**：`{"empty-landing":0,"empty-section":0,"**anchor-needed:8**,"knowledge-defer":0}` **total = 8**
· **过时项 17**（`staleAnchor`）⇒ 台账 33 行 = **8 真缺陷 + 17 过时（去重后）+ 其余为同 ref 重复行**。
不变量：`rows.length === total === Σcounts`（清单与计数同源，stale 单列）。
**先红证据**：①″ 先红 `anchors=0`（6001 行）· ①‴ 先红 `anchors=0`（33 行在旧卷）· ①′ 先红 `staleAnchor=undefined`。

**8 条真缺陷（待人工建锚）**：`flows.md §圆桌预设事务化更新` · `tools.md §圆桌三模式差异` · `tools.md §构建打包/tsdown clean` ·
`env.md §插件RPC无鉴权边界` · `env.md §用量真值` · `env.md §目标模式/goal 回合约束` · `lessons.md §静默席判据` · `lessons.md §掩盖根因的开关`。
**不自动建锚**（§3 边界不变）：建锚须带内容，而空锚会立刻撞上本档刚收紧的**空壳基线 0**（自伤）。



