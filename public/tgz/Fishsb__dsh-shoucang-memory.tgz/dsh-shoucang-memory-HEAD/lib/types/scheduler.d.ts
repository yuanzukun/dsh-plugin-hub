/**
 * @dsh-external/shoucang-scheduler — 守藏调度执行器。
 * 沿革：2026-09-05 重定义为 suite 只读装配检测（HANDOVER #2，旧 boards 三板块废弃）；
 * 2026-09-08 三合一后本模块承载 = ① suite 装配检测（shoucang_suite，矩阵单一实现在 targets.ts）
 * + ② 蒸馏器装配与回归工具（shoucang_verify / shoucang_targets_probe，蒸馏器本体在 distill.ts）
 * + ③ 自持配置通道加载（~/.dsh/suite/scheduler.json 启动期覆盖 Config 缺省）。
 *
 * 装配检测口径（零硬编码红线：不写死机器路径，运行时经 env/home 探测）：
 *   1. injected 基准：注入器 registry.json（$DSH_HOME/super-injector/registry.json，dev 注入装配）
 *   2. profile 基准：$DSH_HOME/profiles/<profile>/package.json 的 dependencies + dsh.profile.bundles
 *      （bundle 装配；多 profile 全扫，逐 profile 归属）
 *   成员状态 = injected / profile / both / missing。
 *
 * 高性能铁律：工具 schema 精简（description 短句，详解放 tool result / 引导文本）；
 * 只读工具，不产生副作用。
 */
import type { Context } from 'cordis';
import { type ProbeConfigFields } from './probe-config.js';
import { type ModelConfigFields } from './model-config.js';
import { type EvalConfigFields } from './eval-config.js';
import type { CompositionHandles } from './composition.js';
export declare const name = "@dsh-external/shoucang-scheduler";
export declare const inject: string[];
export interface SuiteMember {
    id: string;
    package: string;
    repo: string;
    role: string;
}
export interface Config extends ProbeConfigFields, EvalConfigFields, ModelConfigFields {
    members: SuiteMember[];
    verify_enabled: boolean;
    enableDistill: boolean;
    idleWakeMs: number;
    minTurnChars: number;
    distillPrescan: boolean;
    prescanMinChars: number;
    distillPrompt: string;
    llmProvider: string;
    llmModel: string;
    capAgent: number;
    capUser: number;
    capMemory: number;
    /** ADR-333 容量门开关（缺省 false=不阻断）。三处同批：本类型 + 下方 zod schema + `distillOptionsOf` 映射。 */
    capacityEnforce: boolean;
    storeMode: string;
    enableDeepSleep: boolean;
    enableRemPass?: boolean;
    deepSleepIdleMs: number;
    deepSleepDaemonParent: boolean;
    activationShadow: boolean;
    activationPrefetch: boolean;
    activationTOn: number;
    activationTOff: number;
    activationCooldownSteps: number;
    activationTopK: number;
    embedEnabled: boolean;
    embedBaseUrl: string;
    embedModel: string;
    embedApiKeyEnv: string;
    recallFusion: string;
    injectRelevance: boolean;
    injectFreshSlots: number;
    injectProfileRows: number;
    scoreWeights: string;
    shadowScore: boolean;
    maturationEnforce: boolean;
    perItemGate: boolean;
    selfCheck: boolean;
    selfCheckRepo: string;
    selfCheckAutoRollback: boolean;
    selfCheckIntervalHours: number;
    bankGit: boolean;
    activityWarmDays: number;
    activityColdDays: number;
    activityArchiveDays: number;
    activityHotHits: number;
    deepSleepContentMinChars: number;
    deepSleepMaterialChunkChars: number;
    recallColdFactorPercent: number;
    mclEnabled: boolean;
    mclFamiliarThreshold: number;
    mclMaxNudges: number;
    mclBudgetChars: number;
    /** P2b（2026-09-13）：慢通道材料改挂 systemPrompt 段（缺省 false ＝ 现状零行为变化） */
    mclMaterialInSystem: boolean;
    mclTopK: number;
    mclAudit: boolean;
}
export declare const Config: any;
export declare function applyScheduler(ctx: Context, config: Config, comp?: CompositionHandles): void;
