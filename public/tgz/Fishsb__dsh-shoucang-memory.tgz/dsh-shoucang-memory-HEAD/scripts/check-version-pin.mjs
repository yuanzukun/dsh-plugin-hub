#!/usr/bin/env node
/**
 * check-version-pin.mjs — 部署版本**三处记录一致性**只读巡检（G0「deploy 版本一致性」· 2026-09-13）
 *
 * 背景（仓内 AGENTS.md 实测记录，不是推测）：profile 里同一个依赖有**三份互不相同的版本记录**——
 *   `package.json`（声明的 specifier）· `pnpm-lock.yaml`（锁定的解析结果）· `node_modules/.modules.yaml`
 *   （实际装上去的那份）。三份各说各话时，**"仓内绿"与"装上去的是哪一代"完全脱钩**：
 *   曾出现修复早已提交、安装副本仍是旧代码，而三道门全绿的情况。
 *
 * ⚠ 为什么是**报告态**（不一致时仍 exit 0）：
 *   部署含 push / 用户热重载等**环境侧步骤**，把环境问题做成红灯＝**假红灯**（与假绿灯是镜像错误）。
 *   仓内先例：`check-installed-sync.mjs` 同为报告工具。要把它当 CI 硬门时加 `--strict` 即可。
 *
 * 用法：
 *   node scripts/check-version-pin.mjs [--profile web] [--pkg dsh-shoucang-memory] [--json out.json] [--strict]
 * 退出码：0 = 一致，或（不一致但非 --strict）报告态 · 1 = --strict 下不一致 · 3 = 跳过（profile/依赖不存在）
 */
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

const argv = process.argv.slice(2)
const argOf = (n, d) => { const i = argv.indexOf(n); return i >= 0 && argv[i + 1] ? argv[i + 1] : d }
const STRICT = argv.includes('--strict')
const SELFTEST = argv.includes('--selftest')
const JSON_OUT = argOf('--json', '')
const dshHome = process.env.DSH_HOME || join(homedir(), '.dsh')
const PROFILE = argOf('--profile', 'web')
const PKG = argOf('--pkg', 'dsh-shoucang-memory')
const root = join(dshHome, 'profiles', PROFILE)

if (!existsSync(root)) {
  console.log(`⏭ profile 不存在（${root}）—— 版本巡检跳过`)
  process.exit(3)
}

/** 从文本里抽取所有 `<pkg>...tar.gz/<sha40>` 或 `#<sha40>`（同一份文件可能记多处） */
function shasIn(text, pkg) {
  const out = new Set()
  for (const m of text.matchAll(new RegExp(`${pkg}[^\\s"']*?(?:tar\\.gz/|#)([0-9a-f]{7,40})`, 'g'))) out.add(m[1])
  return [...out]
}

// ── 反向证伪（`--selftest`）：证明抽取器**真的会抽出东西**，否则它坏了也只会显示"跳过" ──
/**
 * 判据：**同一提交的不同书写长度不算不一致**。
 * 2026-09-19 实测假红（本件自己的缺陷）：声明侧写 7 位短 sha `#ad6d737`、lock/.modules.yaml 记 40 位全 sha
 *   `ad6d7370ec76…` ⇒ `new Set(shas).size === 2` 被判"三处不一致"，而三处其实是**同一提交**。
 *   「假红灯」与「假绿灯」是镜像错误：它会让一次成功的归位看起来没做，从而诱导人做无用的重装。
 * 严格性**不变**：只要存在两个**互不为前缀**的 sha ⇒ 仍判不一致（那才是真的脱钩）。
 */
function pinConsistent(shas) {
  const xs = [...new Set(shas.map((s) => String(s).trim().toLowerCase()).filter(Boolean))]
  if (xs.length === 0) return { consistent: false, canon: '', short: false }
  const canon = xs.slice().sort((a, b) => b.length - a.length)[0]
  const consistent = xs.every((s) => canon.startsWith(s))
  return { consistent, canon, short: consistent && xs.some((s) => s.length < canon.length) }
}

if (SELFTEST) {
  const cases = [
    ['dsh-shoucang-memory": "github:Fishsb/dsh-shoucang-memory#f81eb2e5b6f8517e4af6f0d0284f3375302fed74",', 'dsh-shoucang-memory', ['f81eb2e5b6f8517e4af6f0d0284f3375302fed74']],
    ['version: https://codeload.github.com/Fishsb/dsh-shoucang-memory/tar.gz/9f6c920ed7b14ff5fd8871127e72ee3273934561(schemastery@3.18.0)', 'dsh-shoucang-memory', ['9f6c920ed7b14ff5fd8871127e72ee3273934561']],
    ['"dsh-shoucang-memory@https://codeload.github.com/Fishsb/dsh-shoucang-memory/tar.gz/1c5b09fee7bf130ab96e4b548e3fcfd8ca93f26c(s@1)": [', 'dsh-shoucang-memory', ['1c5b09fee7bf130ab96e4b548e3fcfd8ca93f26c']],
    ['"other-pkg": "github:x/y#abcdef1",', 'dsh-shoucang-memory', []],
  ]
  let bad = 0
  for (const [text, pkg, want] of cases) {
    const got = shasIn(text, pkg)
    const okCase = JSON.stringify(got) === JSON.stringify(want)
    if (!okCase) bad++
    console.log(`${okCase ? '✅' : '❌'} 抽 ${want.length} 个 → 得 ${JSON.stringify(got)}`)
  }
  // 一致性判据自证：**必须能区分"同一提交的不同长度"与"真的不同提交"**（否则修完还是假红/假绿）。
  const aliasCases = [
    ['短 7 位 vs 全 40 位（同一提交）', ['ad6d737', 'ad6d7370ec768dbef17f4a80087420a0ba83d72c'], true],
    ['两侧都是全 40 位', ['ad6d7370ec768dbef17f4a80087420a0ba83d72c', 'ad6d7370ec768dbef17f4a80087420a0ba83d72c'], true],
    ['真的不同提交（反例，必须判不一致）', ['ad6d737', '3339116a1b2c3d4e5f60718293a4b5c6d7e8f901'], false],
    ['空集（无记录）', [''], false],
  ]
  for (const [name, shas, want] of aliasCases) {
    const got = pinConsistent(shas).consistent
    const okCase = got === want
    if (!okCase) bad++
    console.log(`${okCase ? '✅' : '❌'} 一致性判据 · ${name} → ${got ? '一致' : '不一致'}（期望 ${want ? '一致' : '不一致'}）`)
  }
  // **声明侧 BOM 反例**（2026-09-20 round 10）：带 BOM 的 JSON.parse 必抛 ⇒ 必须被判为"解析失败"
  //   而不是被静默排除出三处判定（后者会让本门在声明侧失读时**降级为两处比对仍报 PASS**）。
  {
    const withBom = '\uFEFF{"dependencies":{"x":"github:y#abcdef1"}}'
    let threw = false
    try { JSON.parse(withBom) } catch { threw = true }
    const okCase = threw === true
    if (!okCase) bad++
    console.log(`${okCase ? '✅' : '❌'} 反例自证 · 带 UTF-8 BOM 的 JSON **必须**解析失败（否则修法无意义）`)
    // 正例：去掉 BOM 后可解析（证明修法是"去 BOM"而非"放弃解析"）
    let parsed = null
    try { parsed = JSON.parse(withBom.replace(/^\uFEFF/, '')) } catch { /* 不应发生 */ }
    const okFix = parsed !== null
    if (!okFix) bad++
    console.log(`${okFix ? '✅' : '❌'} 反例自证 · 剥 BOM 后可正常解析（修法有效）`)
  }
  console.log(bad ? `\nFAIL（${bad} 例）` : '\nPASS（抽取器自证可用）')
  process.exit(bad ? 1 : 0)
}

const sources = []
const pkgJsonPath = join(root, 'package.json')
const lockPath = join(root, 'pnpm-lock.yaml')
const modulesPath = join(root, 'node_modules', '.modules.yaml')

let declared = ''
if (existsSync(pkgJsonPath)) {
  try {
    const j = JSON.parse(readFileSync(pkgJsonPath, 'utf8'))
    const spec = { ...(j.dependencies || {}), ...(j.devDependencies || {}) }[PKG]
    if (typeof spec === 'string') declared = (spec.split('#')[1] || '').trim()
    sources.push({ file: 'package.json', role: '声明', present: true, shas: declared ? [declared] : [] })
  } catch (e) { sources.push({ file: 'package.json', role: '声明', present: true, shas: [], error: String(e.message).slice(0, 80) }) }
} else sources.push({ file: 'package.json', role: '声明', present: false, shas: [] })

for (const [file, role] of [['pnpm-lock.yaml', '锁定'], [join('node_modules', '.modules.yaml'), '实装']]) {
  const abs = join(root, file)
  if (!existsSync(abs)) { sources.push({ file, role, present: false, shas: [] }); continue }
  const text = readFileSync(abs, 'utf8')
  const shas = shasIn(text, PKG)
  // **静默失效防御**：文件里有该依赖名却抽不出 SHA ⇒ 是解析器坏了，不是"没有记录"。
  // 若不区分，解析器一旦失效就会走"跳过"分支（exit 3）而永远不被发现——正是仓内一直在剿的假绿。
  const parseMiss = shas.length === 0 && text.includes(PKG)
  sources.push({ file, role, present: true, shas, parseMiss })
}

const broken = sources.filter((s) => s.parseMiss)
if (broken.length) {
  console.log(`❌ 解析器失效：${broken.map((s) => s.file).join(', ')} 含依赖名但未抽出 SHA —— 这是代码问题（非环境问题），不判跳过`)
  process.exit(1)
}

/* ⚠ **2026-09-20 round 10 修假绿**（本件自身缺陷，实测踩到）：
 *   病征：profile `package.json` 被写入 **UTF-8 BOM**（一次改 pin 的副作用）⇒ `JSON.parse` 抛
 *     `Unexpected token ''` ⇒ 声明侧 `shas: []` + `error` 被记进 sources，**但判定只取 `all = flatMap(shas)`**
 *     ⇒ 声明侧**整侧被静默排除**，剩下 lock + .modules.yaml 两处一致 ⇒ 打印
 *     **「PASS（三处一致 @ …）」** —— 「三处」实际只读了两处，**关键的那一处在报错中被吞掉**。
 *   这正是本仓反复剿的形态：**把"坏掉了"显示成"没那么坏"**；且此门恰是防"声明领先于 lock"的那道，
 *   声明侧失读时它静默失能 = 门自己变成假绿来源。
 *   修法：**声明侧解析失败 ⇒ 立即 exit 1（代码/文件问题，非环境问题）**，不再降级为"少读一处仍判一致"。
 *   （与上方 `parseMiss` 分支同旨：先把"读不到"和"真的没有"分开，再谈一致性。）
 */
const declaredBroken = sources.filter((s) => s.error)
if (declaredBroken.length) {
  console.log(`❌ 声明侧解析失败：${declaredBroken.map((s) => `${s.file}（${s.error}）`).join(', ')}`)
  console.log('  · 常见成因：`package.json` 带 **UTF-8 BOM**（某些写入方式默认加 BOM）⇒ JSON.parse 失败。')
  console.log('  · 为何不判环境跳过：读不到声明值 ≠ 声明值一致；降级判定会把「三处」悄悄变成两处仍报 PASS。')
  process.exit(1)
}

if (!sources.some((s) => s.present && s.shas.length)) {
  console.log(`⏭ 三处均无 ${PKG} 的版本记录（profile=${PROFILE}）—— 巡检跳过`)
  process.exit(3)
}

const all = sources.flatMap((s) => s.shas)
const { consistent, canon, short } = pinConsistent(all)
console.log(`版本记录巡检 · profile=${PROFILE} · 依赖=${PKG}`)
for (const s of sources) {
  const v = !s.present ? '（文件缺席）' : s.shas.length ? s.shas.map((x) => x.slice(0, 8)).join(' / ') : '（无记录）'
  console.log(`  ${s.role.padEnd(2)} ${s.file.padEnd(26)} ${v}${s.error ? ` · ${s.error}` : ''}`)
}
if (consistent) console.log(`\nPASS（三处一致 @ ${canon.slice(0, 8)}${short ? ' · 声明侧为短 sha，同一提交' : ''}）`)
else {
  console.log(`\n⚠ 三处不一致（${[...new Set(all.map((x) => x.slice(0, 8)))].join(' / ')}）`)
  console.log('  · 这意味着「仓内绿」与「装上去的是哪一代」脱钩——曾有修复已提交、安装副本仍旧代而三道门全绿的前例。')
  console.log('  · 根治：在 profile 跑一次 `pnpm install` 重生成 lock 与 .modules.yaml（会触发宿主批量删除保护，宜择时手动做）。')
  console.log(`  · 本件为报告态（不改仓库、不判代码红）；要当 CI 硬门用 --strict。`)
}

if (JSON_OUT) {
  writeFileSync(JSON_OUT, JSON.stringify({ profile: PROFILE, pkg: PKG, root, consistent, shas: [...all], sources }, null, 1), 'utf8')
  console.log(`报告已落：${JSON_OUT}`)
}
if (!consistent && STRICT) process.exit(1)
