/**
 * Community data source: GitHub repositories under the `dsh-plugin` topic, with
 * a TTL cache and a degradation chain (live GitHub → stale cache → built-in
 * registry snapshot). GitHub rate-limit responses (403/429) and network errors
 * never propagate to the caller; they step down the chain instead.
 *
 * @module dsh-plugin-doctor/github
 */

import { fetchJson, fetchText } from './http.ts'
import type { HttpDeps } from './http.ts'
import type { CommunityPlugin, SearchFilters, SearchResult } from './types.ts'
import type { InstallInspection } from './install-check.ts'

/** GitHub Search API topic every discovery query narrows to. */
const DSH_PLUGIN_TOPIC = 'dsh-plugin'

/** Third-party registry pages scraped in the degradation chain. */
const REGISTRY_URLS = ['https://dshplugin.world/', 'https://dsh.pub/en/plugins/'] as const

/** README excerpt length kept for similarity scoring. */
const README_EXCERPT_CHARS = 500

/** One cached listing of the whole topic, plus when it was fetched. */
interface CacheEntry {
  readonly fetchedAt: number
  readonly plugins: readonly CommunityPlugin[]
}

/**
 * Static snapshot of third-party registries (dshplugin.world, dsh.pub) used
 * only when both the live API and the cache are unavailable. Kept inline so
 * the plugin stays a single installable package with no extra fetch targets.
 */
const REGISTRY_SNAPSHOT: readonly CommunityPlugin[] = [
  {
    name: 'dsh-plugin-memory',
    repo: 'community/dsh-plugin-memory',
    installRef: 'github:community/dsh-plugin-memory',
    description: 'Persistent conversation memory with recall and summarization.',
    readmeExcerpt: 'Persistent conversation memory for DSH agents: recall prior sessions, summarize long histories, and inject relevant context. capabilities: memory, context, session',
    capabilities: ['memory', 'context', 'session'],
    dependencies: [],
    stars: 0,
    updatedAt: '',
    source: 'registry',
  },
  {
    name: 'dsh-plugin-market',
    repo: 'community/dsh-plugin-market',
    installRef: 'github:community/dsh-plugin-market',
    description: 'Browse and install community plugins from the registry.',
    readmeExcerpt: 'Marketplace browser for DSH community plugins: search the registry, show install commands, manage installed plugins. capabilities: catalog, install',
    capabilities: ['catalog', 'install'],
    dependencies: [],
    stars: 0,
    updatedAt: '',
    source: 'registry',
  },
]

/** Shape of one GitHub repository-search item this module reads. */
interface GitHubRepo {
  full_name?: string
  name?: string
  html_url?: string
  description?: string | null
  stargazers_count?: number
  pushed_at?: string
  default_branch?: string
}

/**
 * Extract capability tags and dependencies from a README excerpt. Recognizes
 * explicit `capabilities:` / `dependencies:` lines and bracketed tag lists;
 * missing sections yield empty arrays rather than guesses.
 * @param excerpt - README head text.
 */
function parseReadmeMetadata(excerpt: string): { capabilities: string[]; dependencies: string[] } {
  const capabilities: string[] = []
  const dependencies: string[] = []
  for (const line of excerpt.split(/\r?\n/)) {
    const cap = /^[-*>\s]*capabilities?\s*[:=]\s*(.+)$/i.exec(line)
    if (cap !== null) {
      capabilities.push(...cap[1]!.split(/[,;|]/).map(tag => tag.trim().toLowerCase()).filter(tag => tag.length > 0))
      continue
    }
    const dep = /^[-*>\s]*dependencies?\s*[:=]\s*(.+)$/i.exec(line)
    if (dep !== null) {
      dependencies.push(...dep[1]!.split(/[,;|]/).map(dep2 => dep2.trim()).filter(dep2 => dep2.length > 0))
    }
  }
  return { capabilities: [...new Set(capabilities)], dependencies: [...new Set(dependencies)] }
}

/**
 * Client for the community data source with TTL caching and degradation.
 * One instance lives in the plugin's `apply` scope; its cache is the
 * process-lifetime equivalent of the shared plugin context.
 */
export class CommunitySource {
  private cache?: CacheEntry

  /**
   * @param deps - HTTP dependencies (web capability, token).
   * @param ttlMinutes - cache lifetime in minutes; listings older than this are refreshed.
   */
  constructor(
    private readonly deps: HttpDeps,
    private readonly ttlMinutes: number,
  ) {}

  /**
   * List community plugins matching a natural-language intent. The live GitHub
   * topic listing is fetched at most once per TTL window; keyword ranking and
   * filters run locally against the cached listing.
   * @param intent - natural-language description of what the user needs.
   * @param filters - optional star/recency filters.
   * @param signal - cancellation signal from the tool execution.
   * @returns ranked plugins plus a degradation note when a fallback served them.
   */
  async search(intent: string, filters: SearchFilters, signal: AbortSignal | undefined): Promise<SearchResult> {
    const listing = await this.listing(signal)
    const keywords = tokenizeIntent(intent)
    const now = Date.now()
    const ranked = listing.plugins
      .filter(plugin => (filters.minStars === undefined || plugin.stars >= filters.minStars)
        && (filters.updatedWithinDays === undefined
          || plugin.updatedAt.length === 0
          || now - Date.parse(plugin.updatedAt) <= filters.updatedWithinDays * 86_400_000))
      .map(plugin => ({ plugin, score: keywords.length === 0 ? 0 : overlapScore(keywords, plugin) }))
      .filter(entry => entry.score > 0 || keywords.length === 0)
      .sort((x, y) => y.score - x.score || y.plugin.stars - x.plugin.stars)
      .map(entry => entry.plugin)
    return { plugins: ranked, degraded: listing.degraded }
  }

  /**
   * Fetch the package manifest and optional Cordis patch for install preflight.
   * A per-repository failure is returned as data so one bad candidate does not
   * hide the other conflicts; the install guard blocks when inspection fails.
   * @param refs - GitHub install references or repository URLs.
   * @param signal - cancellation signal from the tool execution.
   */
  async inspectInstallRefs(refs: readonly string[], signal: AbortSignal | undefined): Promise<InstallInspection[]> {
    return Promise.all(refs.map(async ref => {
      const repo = normalizeGitHubRepo(ref)
      if (repo === undefined) return { ref, error: 'only GitHub repository refs or URLs can be inspected', errorKind: 'unsupported' as const }
      try {
        const metadata = await fetchJson(this.deps, `https://api.github.com/repos/${repo}`, signal) as { default_branch?: unknown }
        const branch = typeof metadata.default_branch === 'string' && metadata.default_branch.length > 0 ? metadata.default_branch : 'main'
        const packageResult = await fetchText(this.deps, `https://raw.githubusercontent.com/${repo}/${encodeURI(branch)}/package.json`, signal, 'application/json')
        if (!(packageResult.status >= 200 && packageResult.status < 300)) {
          const errorKind = packageResult.status === 403 || packageResult.status === 429 ? 'rate-limit' as const : 'http' as const
          return { ref, repo, error: `package.json returned HTTP ${packageResult.status}`, errorKind }
        }
        const packageJson = JSON.parse(packageResult.text) as { dsh?: { bundle?: { patch?: unknown } } }
        const declaredPatch = packageJson.dsh?.bundle?.patch
        const patchPath = typeof declaredPatch === 'string' ? declaredPatch.replace(/^\.\//, '') : 'cordis.patch.yml'
        if (patchPath.startsWith('/') || patchPath.split('/').includes('..')) throw new Error(`unsafe bundle patch path: ${patchPath}`)
        const patchResult = await fetchText(this.deps, `https://raw.githubusercontent.com/${repo}/${encodeURI(branch)}/${patchPath}`, signal, 'text/plain')
        return {
          ref,
          repo,
          packageJson,
          patchText: patchResult.status >= 200 && patchResult.status < 300 ? patchResult.text : '',
        }
      } catch (error) {
        const message = errorMessage(error)
        return { ref, repo, error: message, errorKind: /\b(?:403|429)\b|rate.?limit/i.test(message) ? 'rate-limit' as const : 'network' as const }
      }
    }))
  }

  /**
   * Fetch (or serve from cache) the full topic listing with README excerpts.
   * Errors step down: live API → stale cache → live registry pages → built-in
   * registry snapshot.
   */
  private async listing(signal: AbortSignal | undefined): Promise<{ plugins: readonly CommunityPlugin[]; degraded?: string }> {
    const fresh = this.cache !== undefined && Date.now() - this.cache.fetchedAt < this.ttlMinutes * 60_000
    if (fresh) return { plugins: this.cache!.plugins }
    try {
      const plugins = await this.fetchTopic(signal)
      this.cache = { fetchedAt: Date.now(), plugins }
      return { plugins }
    } catch (error) {
      const cause = errorMessage(error)
      if (this.cache !== undefined) {
        return { plugins: this.cache.plugins, degraded: `GitHub API unavailable (${cause}); serving stale cache` }
      }
      const live = await this.fetchRegistries(signal)
      if (live !== undefined && live.length > 0) {
        return { plugins: live, degraded: `GitHub API unavailable (${cause}); serving live third-party registry data` }
      }
      return {
        plugins: REGISTRY_SNAPSHOT,
        degraded: `GitHub API unavailable (${cause}); serving built-in registry snapshot`,
      }
    }
  }

  /**
   * Scrape the third-party plugin registries (dshplugin.world, dsh.pub) for
   * GitHub repository references. Returns `undefined` when every page fails;
   * an empty array means the pages loaded but exposed no repositories — the
   * caller then falls through to the static snapshot.
   * @param signal - cancellation signal from the tool execution.
   */
  private async fetchRegistries(signal: AbortSignal | undefined): Promise<CommunityPlugin[] | undefined> {
    const plugins = new Map<string, CommunityPlugin>()
    let anyPageLoaded = false
    for (const url of REGISTRY_URLS) {
      try {
        const { status, text } = await fetchText(this.deps, url, signal, 'text/html')
        if (!(status >= 200 && status < 300)) continue
        anyPageLoaded = true
        for (const match of text.matchAll(/github\.com\/([A-Za-z0-9][A-Za-z0-9_.-]*)\/([A-Za-z0-9][A-Za-z0-9_.-]*)/g)) {
          const repo = `${match[1]}/${match[2]}`
          if (plugins.has(repo)) continue
          plugins.set(repo, {
            name: match[2]!,
            repo,
            installRef: `github:${repo}`,
            description: `Listed on ${new URL(url).hostname}`,
            readmeExcerpt: '',
            capabilities: [],
            dependencies: [],
            stars: 0,
            updatedAt: '',
            source: 'registry',
          })
        }
      } catch {
        // One unreachable registry must not block the other or the fallback.
      }
    }
    return anyPageLoaded ? [...plugins.values()] : undefined
  }

  /**
   * Query the GitHub Search API for the topic and enrich each hit with its
   * README head. Per-repository README failures degrade to the repo description.
   */
  private async fetchTopic(signal: AbortSignal | undefined): Promise<CommunityPlugin[]> {
    const url = `https://api.github.com/search/repositories?q=topic:${DSH_PLUGIN_TOPIC}&sort=stars&order=desc&per_page=30`
    const payload = await fetchJson(this.deps, url, signal) as { items?: GitHubRepo[] }
    const items = payload.items ?? []
    const plugins: CommunityPlugin[] = []
    for (const item of items) {
      const repo = item.full_name
      if (repo === undefined) continue
      const excerpt = await this.readmeExcerpt(repo, signal)
      const metadata = parseReadmeMetadata(excerpt)
      plugins.push({
        name: item.name ?? repo,
        repo,
        installRef: `github:${repo}`,
        description: item.description ?? '',
        readmeExcerpt: excerpt,
        capabilities: metadata.capabilities,
        dependencies: metadata.dependencies,
        stars: item.stargazers_count ?? 0,
        updatedAt: item.pushed_at ?? '',
        source: 'github',
      })
    }
    return plugins
  }

  /** First {@link README_EXCERPT_CHARS} characters of the repository README. */
  private async readmeExcerpt(repo: string, signal: AbortSignal | undefined): Promise<string> {
    try {
      const { status, text } = await fetchText(
        this.deps,
        `https://api.github.com/repos/${repo}/readme`,
        signal,
        'application/vnd.github.raw',
      )
      if (status >= 200 && status < 300) return text.slice(0, README_EXCERPT_CHARS)
    } catch {
      // README enrichment is best-effort; similarity falls back to description.
    }
    return ''
  }
}

function normalizeGitHubRepo(ref: string): string | undefined {
  const trimmed = ref.trim().replace(/^github:/, '').replace(/\.git$/, '')
  const url = /^https?:\/\/github\.com\/([^/]+\/[^/#?]+)(?:[/?#].*)?$/i.exec(trimmed)?.[1]
  const repo = url ?? (/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(trimmed) ? trimmed : undefined)
  return repo === undefined ? undefined : repo
}

/**
 * Lowercase word tokens of an intent, minus stopwords; also keeps hyphenated
 * compound fragments so "sandbox approval" matches `sandbox-approval`.
 * @param intent - natural-language text.
 */
function tokenizeIntent(intent: string): string[] {
  const stopwords = new Set(['a', 'an', 'the', 'i', 'need', 'want', 'plugin', 'for', 'that', 'can', 'to', 'of', 'and', 'with', 'me', 'my', 'dsh'])
  return intent
    .toLowerCase()
    .split(/[^a-z0-9+#-]+/)
    .flatMap(token => token.split('-'))
    .filter(token => token.length > 1 && !stopwords.has(token))
}

/**
 * Fraction of intent keywords appearing in the plugin's text fields.
 * @param keywords - tokenized intent.
 * @param plugin - candidate plugin.
 */
function overlapScore(keywords: readonly string[], plugin: CommunityPlugin): number {
  const haystack = `${plugin.name} ${plugin.description} ${plugin.readmeExcerpt} ${plugin.capabilities.join(' ')}`.toLowerCase()
  const hits = keywords.filter(keyword => haystack.includes(keyword)).length
  return keywords.length === 0 ? 0 : hits / keywords.length
}

/**
 * Normalize an unknown thrown value into a short message.
 * @param error - thrown value.
 */
function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}
