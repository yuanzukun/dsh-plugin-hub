import { describe, expect, it } from 'vitest'
import {
  agentsFromWindows,
  layoutSwarm,
  pulseProgress,
  swarmEdges,
  type SwarmEntrySource,
} from '../src/client/swarm/swarm-model.ts'

const catalog = (seq: number, childId: string, label?: string) => ({
  type: 'event' as const,
  event: { type: 'subagent/catalog', seq, data: { childId, childCreatedAt: seq, mode: 'continuable', ...(label === undefined ? {} : { label }) } },
})
const windowOf = (sessionId: string, entries: unknown[]): SwarmEntrySource => ({ sessionId, entries })

describe('agentsFromWindows', () => {
  it('lists direct children from the root window catalog events', () => {
    const agents = agentsFromWindows([
      windowOf('root', [
        { type: 'event', event: { type: 'user/message', seq: 1 } },
        catalog(2, 'a', '检索器'),
        catalog(3, 'b', '写手'),
      ]),
    ], 'root')
    expect(agents.map(a => a.id).sort()).toEqual(['a', 'b'])
    expect(agents.find(a => a.id === 'a')).toMatchObject({ parentId: 'root', depth: 1, label: '检索器' })
  })

  it('stitches grandchildren from child windows, one level deep at most per call', () => {
    const agents = agentsFromWindows([
      windowOf('root', [catalog(1, 'a'), catalog(2, 'b')]),
      windowOf('a', [catalog(5, 'a1', '爬虫')]),
    ], 'root')
    expect(agents.find(a => a.id === 'a1')).toMatchObject({ parentId: 'a', depth: 2, label: '爬虫' })
  })

  it('a later catalog event cannot remove an earlier child (append-only facts)', () => {
    const agents = agentsFromWindows([
      windowOf('root', [catalog(1, 'a'), catalog(2, 'b')]),
      windowOf('root2', [catalog(9, 'a')]),
    ], 'root')
    expect(agents.map(a => a.id).sort()).toEqual(['a', 'b'])
  })

  it('ignores malformed rows and non-catalog events', () => {
    const agents = agentsFromWindows([
      windowOf('root', [
        { type: 'event', event: { type: 'subagent/catalog', seq: 1 } },
        { type: 'event', event: { type: 'subagent/catalog', seq: 2, data: 'nope' } },
        catalog(3, 'a'),
        catalog(4, 'root'),
      ]),
    ], 'root')
    expect(agents.map(a => a.id)).toEqual(['a'])
  })

  it('caps the swarm size, keeping shallow agents first', () => {
    const entries = Array.from({ length: 30 }, (_, i) => catalog(i + 1, `c${i}`))
    const agents = agentsFromWindows([windowOf('root', entries)], 'root', 24)
    expect(agents.length).toBe(24)
  })
})

describe('layoutSwarm', () => {
  it('places the root at the center and children on one ring', () => {
    const agents = [
      { id: 'root', parentId: null, depth: 0, label: 'R', mode: 'continuable' as const },
      { id: 'a', parentId: 'root', depth: 1, label: 'A', mode: 'one-shot' as const },
      { id: 'b', parentId: 'root', depth: 1, label: 'B', mode: 'one-shot' as const },
    ]
    const layout = layoutSwarm(agents, 'root', { radius: 200 })
    expect(layout.positions.get('root')).toEqual({ x: 0, y: 0 })
    const a = layout.positions.get('a')
    const b = layout.positions.get('b')
    expect(Math.hypot(a!.x, a!.y)).toBeCloseTo(200, 5)
    expect(Math.hypot(b!.x, b!.y)).toBeCloseTo(200, 5)
    // Even angular spacing, deterministic order.
    expect(a!.x).toBeCloseTo(-b!.x, 5)
  })

  it('orbits grandchildren around their own parent at a smaller radius', () => {
    const agents = [
      { id: 'root', parentId: null, depth: 0, label: 'R', mode: 'continuable' as const },
      { id: 'a', parentId: 'root', depth: 1, label: 'A', mode: 'one-shot' as const },
      { id: 'a1', parentId: 'a', depth: 2, label: 'A1', mode: 'one-shot' as const },
    ]
    const layout = layoutSwarm(agents, 'root', { radius: 200, childRadius: 90 })
    const a = layout.positions.get('a')!
    const a1 = layout.positions.get('a1')!
    expect(Math.hypot(a1.x - a.x, a1.y - a.y)).toBeCloseTo(90, 5)
  })

  it('every agent gets a finite position, unreachable ones included', () => {
    const agents = [
      { id: 'root', parentId: null, depth: 0, label: 'R', mode: 'continuable' as const },
      { id: 'x', parentId: 'missing', depth: 1, label: 'X', mode: 'one-shot' as const },
    ]
    const layout = layoutSwarm(agents, 'root')
    for (const id of ['root', 'x']) {
      const p = layout.positions.get(id)!
      expect(Number.isFinite(p.x)).toBe(true)
      expect(Number.isFinite(p.y)).toBe(true)
    }
  })
})

describe('swarmEdges', () => {
  it('one edge per non-root agent, child to parent', () => {
    const agents = [
      { id: 'root', parentId: null, depth: 0, label: 'R', mode: 'continuable' as const },
      { id: 'a', parentId: 'root', depth: 1, label: 'A', mode: 'one-shot' as const },
      { id: 'a1', parentId: 'a', depth: 2, label: 'A1', mode: 'one-shot' as const },
    ]
    expect(swarmEdges(agents, 'root')).toEqual([
      { from: 'root', to: 'a' },
      { from: 'a', to: 'a1' },
    ])
  })
})

describe('pulseProgress', () => {
  it('cycles from 0 to 1 while the edge is hot, then goes cold', () => {
    expect(pulseProgress(10_000, 10_000, 2_000)).toBe(0)
    expect(pulseProgress(10_000, 11_000, 2_000)).toBe(0.5)
    expect(pulseProgress(10_000, 12_000, 2_000)).toBe(0)
    // Cold after the grace window: no pulse is drawn.
    expect(pulseProgress(10_000, 10_000 + 2_000 + 1_500 + 1, 2_000)).toBeNull()
  })
})

import { activityFromEntries, fitScale } from '../src/client/swarm/swarm-model.ts'
import { layoutActivity } from '../src/client/swarm/swarm-model.ts'

const call = (seq: number, callId: string, name: string) => ({
  type: 'event' as const,
  event: { type: 'tool/call', seq, data: { turn: 0, step: 1, callId, name, arguments: '{}' } },
})
const result = (seq: number, callId: string, error?: boolean) => ({
  type: 'event' as const,
  event: { type: 'tool/result', seq, data: { message: { toolCallId: callId }, ...(error ? { error: { message: 'x' } } : {}) } },
})
const turnStart = (seq: number, turn: number) => ({ type: 'event' as const, event: { type: 'turn/start', seq, data: { turn } } })
const turnEnd = (seq: number, turn: number) => ({ type: 'event' as const, event: { type: 'turn/end', seq, data: { turn, reason: { kind: 'completed' } } } })

describe('activityFromEntries', () => {
  it('pairs tool calls with results and flags the pending one', () => {
    const activity = activityFromEntries([
      turnStart(1, 0),
      call(2, 'c1', 'read'),
      result(3, 'c1'),
      call(4, 'c2', 'grep'),
    ])
    expect(activity.turnCount).toBe(0)
    expect(activity.openTurn).toBe(true)
    expect(activity.currentTurn).toBe(0)
    expect(activity.tools.map(t => t.status)).toEqual(['ok', 'pending'])
    expect(activity.pendingToolId).toBe('c2')
  })

  it('counts completed turns and reports no open turn when settled', () => {
    const activity = activityFromEntries([
      turnStart(1, 0), turnEnd(2, 0),
      turnStart(3, 1), turnEnd(4, 1),
    ])
    expect(activity.turnCount).toBe(2)
    expect(activity.openTurn).toBe(false)
    expect(activity.currentTurn).toBeNull()
    expect(activity.pendingToolId).toBeNull()
  })

  it('marks a tool whose result carried an error', () => {
    const activity = activityFromEntries([call(1, 'c1', 'shell'), result(2, 'c1', true)])
    expect(activity.tools[0]?.status).toBe('error')
  })

  it('keeps only the most recent tools', () => {
    const entries = Array.from({ length: 20 }, (_, i) => call(i + 1, `c${i}`, `t${i}`))
    const activity = activityFromEntries(entries, 12)
    expect(activity.tools.length).toBe(12)
    expect(activity.tools[0]?.id).toBe('c8')
    expect(activity.tools[11]?.id).toBe('c19')
  })

  it('skips malformed rows without throwing', () => {
    const activity = activityFromEntries([
      { type: 'event', event: { type: 'tool/call', seq: 1 } },
      call(2, 'c1', 'read'),
    ])
    expect(activity.tools.map(t => t.id)).toEqual(['c1'])
  })
})

describe('layoutActivity', () => {
  it('spirals outward in execution order and stays within maxRadius', () => {
    const activity = activityFromEntries([call(1, 'c1', 'a'), call(2, 'c2', 'b'), call(3, 'c3', 'c')])
    const layout = layoutActivity(activity.tools, { baseRadius: 200, maxRadius: 340 })
    const radii = activity.tools.map(tool => {
      const p = layout.positions.get(tool.id)!
      return Math.hypot(p.x, p.y)
    })
    expect(radii[0]).toBeDefined()
    expect(radii[0]!).toBeCloseTo(200, 5)
    expect(radii[2]!).toBeCloseTo(340, 5)
    // Monotonically outward — the sequence reads.
    expect(radii[1]!).toBeGreaterThan(radii[0]!)
    expect(layout.maxRadius).toBe(340)
  })

  it('many tools converge onto the outer ring instead of overflowing', () => {
    const entries = Array.from({ length: 20 }, (_, i) => call(i + 1, `c${i}`, 't'))
    const activity = activityFromEntries(entries)
    const layout = layoutActivity(activity.tools, { baseRadius: 200, maxRadius: 340 })
    for (const tool of activity.tools) {
      const p = layout.positions.get(tool.id)!
      expect(Math.hypot(p.x, p.y)).toBeLessThanOrEqual(340.5)
    }
  })

  it('a turn boundary adds an angular gap', () => {
    const tools = [
      { id: 'a', name: 'x', status: 'ok' as const, turn: 0 },
      { id: 'b', name: 'y', status: 'ok' as const, turn: 1 },
    ]
    const layout = layoutActivity(tools, { baseRadius: 200, maxRadius: 340, angularStep: 0.62, turnGap: 0.5 })
    const a = layout.positions.get('a')!
    const b = layout.positions.get('b')!
    const angleA = Math.atan2(a.y, a.x)
    const angleB = Math.atan2(b.y, b.x)
    expect(angleB - angleA).toBeCloseTo(0.62 + 0.5, 5)
  })

  it('an empty list has no positions', () => {
    const layout = layoutActivity([])
    expect(layout.positions.size).toBe(0)
    expect(layout.maxRadius).toBe(340)
  })
})

describe('fitScale', () => {
  it('fits the plane into the container without enlarging past 1:1', () => {
    expect(fitScale(1960, 1600, 980, 800)).toBe(1)
    expect(fitScale(700, 800, 980, 800)).toBeCloseTo((700 - 32) / 980, 5)
  })

  it('never shrinks below the legibility floor and treats unknown sizes as 1', () => {
    expect(fitScale(100, 100, 980, 800)).toBe(0.35)
    expect(fitScale(0, 0, 980, 800)).toBe(1)
  })
})

import { todosFromEntries } from '../src/client/swarm/swarm-model.ts'

describe('todosFromEntries', () => {
  it('returns the last todo/write snapshot, last-write-wins', () => {
    const todos = todosFromEntries([
      { type: 'event', event: { type: 'todo/write', seq: 1, data: { todos: [{ content: '旧的', status: 'pending' }] } } },
      { type: 'event', event: { type: 'todo/write', seq: 2, data: { todos: [
        { content: '拆需求', status: 'completed' },
        { content: '写代码', status: 'in_progress' },
        { content: '测试', status: 'pending' },
      ] } } },
    ])
    expect(todos?.map(t => `${t.content}:${t.status}`)).toEqual(['拆需求:completed', '写代码:in_progress', '测试:pending'])
  })

  it('returns null before the first write and on malformed rows', () => {
    expect(todosFromEntries([])).toBeNull()
    expect(todosFromEntries([
      { type: 'event', event: { type: 'todo/write', seq: 1, data: 'nope' } },
      { type: 'event', event: { type: 'user/message', seq: 2, data: {} } },
    ])).toBeNull()
  })
})

import { sweepProgress } from '../src/client/swarm/swarm-model.ts'

describe('sweepProgress', () => {
  const opts = { period: 6000, step: 300, travel: 1500 }
  it('a pulse travels each edge in staggered order within a period', () => {
    // Edge 0 starts at phase 0; edge 1 at 300ms; edge 2 at 600ms.
    expect(sweepProgress(0, 0, opts)).toBe(0)
    expect(sweepProgress(1, 300, opts)).toBe(0)
    expect(sweepProgress(2, 600, opts)).toBe(0)
    expect(sweepProgress(0, 750, opts)).toBeCloseTo(0.5, 5)
    expect(sweepProgress(1, 750, opts)).toBeCloseTo(0.3, 5)
  })

  it('an edge is dark before its slot and after the travel window', () => {
    expect(sweepProgress(3, 0, opts)).toBeNull() // its slot has not come
    expect(sweepProgress(0, 1600, opts)).toBeNull() // travelled home
  })

  it('wraps at the period boundary, so the sweep keeps running', () => {
    expect(sweepProgress(0, 6000, opts)).toBe(0)
    expect(sweepProgress(0, 6500, opts)).toBeCloseTo(500 / 1500, 5)
  })
})

import { toolGlyph, turnGroups } from '../src/client/swarm/swarm-model.ts'

describe('toolGlyph', () => {
  it('maps common tool families to a glyph and a family color', () => {
    expect(toolGlyph('pwsh').glyph).toBe('▸')
    expect(toolGlyph('pwsh').color).toBe('#2f9e6f')
    expect(toolGlyph('read').glyph).toBe('◧')
    expect(toolGlyph('write').glyph).toBe('✎')
    expect(toolGlyph('edit').glyph).toBe('✎')
    expect(toolGlyph('grep').glyph).toBe('⌕')
    expect(toolGlyph('job_output').glyph).toBe('▤')
    expect(toolGlyph('todo').glyph).toBe('☑')
  })

  it('falls back to a generic glyph for unknown tools', () => {
    expect(toolGlyph('mystery_tool').glyph).toBe('⚙')
  })

  it('each family carries its own robot variant', () => {
    expect(toolGlyph('pwsh').variant).toBe('shell')
    expect(toolGlyph('job_output').variant).toBe('job')
    expect(toolGlyph('read').variant).toBe('read')
    expect(toolGlyph('edit').variant).toBe('write')
    expect(toolGlyph('grep').variant).toBe('search')
    expect(toolGlyph('todo').variant).toBe('todo')
    expect(toolGlyph('fetch').variant).toBe('fetch')
    expect(toolGlyph('mystery').variant).toBe('generic')
  })
})

describe('turnGroups', () => {
  const tool = (turn: number, name: string): { id: string; name: string; status: 'ok'; turn: number } =>
    ({ id: `${name}${turn}`, name, status: 'ok', turn })

  it('groups consecutive tools of the same turn', () => {
    const groups = turnGroups([tool(0, 'a'), tool(0, 'b'), tool(1, 'c'), tool(1, 'd'), tool(1, 'e'), tool(2, 'f')])
    expect(groups.map(g => ({ turn: g.turn, start: g.startIndex, end: g.endIndex }))).toEqual([
      { turn: 0, start: 0, end: 1 },
      { turn: 1, start: 2, end: 4 },
      { turn: 2, start: 5, end: 5 },
    ])
  })

  it('returns no groups for no tools', () => {
    expect(turnGroups([])).toEqual([])
  })
})

import { paletteAccent, SWARM_PALETTES } from '../src/client/swarm/swarm-model.ts'

describe('paletteAccent', () => {
  it('the default palette walks the hue wheel with time', () => {
    const aurora = SWARM_PALETTES[0]!
    expect(paletteAccent(aurora, 0)).toBe('hsl(0, 72%, 64%)')
    expect(paletteAccent(aurora, 5000)).toBe('hsl(100, 72%, 64%)')
    expect(paletteAccent(aurora, 0)).not.toBe(paletteAccent(aurora, 3000))
  })

  it('a fixed palette is constant', () => {
    const cyan = SWARM_PALETTES.find(p => p.id === 'cyan')!
    expect(paletteAccent(cyan, 0)).toBe('#39d0d8')
    expect(paletteAccent(cyan, 999999)).toBe('#39d0d8')
  })
})

import { anchoredPan, teamMembersFromList } from '../src/client/swarm/swarm-model.ts'

describe('teamMembersFromList', () => {
  it('collects members from every session projection, first sighting wins', () => {
    const members = teamMembersFromList({
      projectionsBySession: {
        lead1: { values: { agentTeam: { members: [
          { id: 'm1', name: '前端', role: 'teammate' },
          { id: 'lead1', name: 'lead', role: 'lead' },
        ] } } },
        lead2: { values: { agentTeam: { members: [
          { id: 'm1', name: '重名', role: 'teammate' },
        ] } } },
      },
    })
    expect(members.get('m1')?.name).toBe('前端')
    expect(members.get('lead1')?.role).toBe('lead')
    expect(members.size).toBe(2)
  })

  it('returns an empty map for absent or malformed projections', () => {
    expect(teamMembersFromList(undefined).size).toBe(0)
    expect(teamMembersFromList({ projectionsBySession: { a: { values: {} } } }).size).toBe(0)
  })
})

describe('anchoredPan', () => {
  it('keeps the point under the cursor fixed across a zoom', () => {
    const center = { x: 500, y: 400 }
    const cursor = { x: 650, y: 480 }
    const pan = { x: 0, y: 0 }
    // At scale 1 the content point under the cursor is (150, 80) from origin.
    const next = anchoredPan(pan, 1, 2, cursor, center)
    // At scale 2 that same content point must still land on the cursor.
    const contentX = 150, contentY = 80
    expect(next.x).toBeCloseTo(cursor.x - center.x - contentX * 2, 5)
    expect(next.y).toBeCloseTo(cursor.y - center.y - contentY * 2, 5)
  })
})

describe('activityFromEntries previews', () => {
  it('captures a bounded one-line preview of the call arguments', () => {
    const activity = activityFromEntries([
      { type: 'event', event: { type: 'tool/call', seq: 1, data: { turn: 0, step: 1, callId: 'c1', name: 'pwsh', arguments: 'npm  test\n--watch' } } },
    ])
    expect(activity.tools[0]?.preview).toBe('npm test --watch')
  })

  it('bounds long previews with an ellipsis', () => {
    const activity = activityFromEntries([
      { type: 'event', event: { type: 'tool/call', seq: 1, data: { turn: 0, step: 1, callId: 'c1', name: 'write', arguments: 'x'.repeat(80) } } },
    ])
    expect(activity.tools[0]?.preview?.length).toBe(49)
    expect(activity.tools[0]?.preview?.endsWith('…')).toBe(true)
  })
})

import { collapseTools } from '../src/client/swarm/swarm-model.ts'

describe('collapseTools', () => {
  const t = (id: string, name: string, status: 'pending' | 'ok' | 'error' = 'ok'): { id: string; name: string; status: 'ok' | 'pending' | 'error'; turn: number; id2?: never } =>
    ({ id, name, status, turn: 0 }) as never

  it('folds consecutive same-name tools into one chip with a count', () => {
    const collapsed = collapseTools([
      t('c1', 'send_message'), t('c2', 'send_message'), t('c3', 'send_message'), t('c4', 'read'),
    ])
    expect(collapsed.map(group => `${group.tool.name}×${group.count}`)).toEqual(['send_message×3', 'read×1'])
    // The representative is the most recent of the run.
    expect(collapsed[0]?.tool.id).toBe('c3')
  })

  it('a status change breaks the run', () => {
    const collapsed = collapseTools([t('c1', 'pwsh', 'error'), t('c2', 'pwsh')])
    expect(collapsed.map(group => `${group.tool.name}×${group.count}`)).toEqual(['pwsh×1', 'pwsh×1'])
  })

  it('non-consecutive same-name tools stay separate', () => {
    const collapsed = collapseTools([t('c1', 'read'), t('c2', 'write'), t('c3', 'read')])
    expect(collapsed).toHaveLength(3)
  })
})

describe('tool failure messages', () => {
  it('captures the error message from the result', () => {
    const activity = activityFromEntries([
      { type: 'event', event: { type: 'tool/call', seq: 1, data: { turn: 0, step: 1, callId: 'c1', name: 'pwsh', arguments: '{}' } } },
      { type: 'event', event: { type: 'tool/result', seq: 2, data: { message: { toolCallId: 'c1' }, error: { message: 'exit code 1' } } } },
    ])
    expect(activity.tools[0]?.status).toBe('error')
    expect(activity.tools[0]?.error).toBe('exit code 1')
  })
})

import { orderTeamTasks } from '../src/client/swarm/swarm-model.ts'

describe('orderTeamTasks', () => {
  it('puts in-progress first, then pending, then finished — stable within bands', () => {
    const tasks = [
      { id: '1', subject: 'done-1', status: 'completed' },
      { id: '2', subject: 'active', status: 'in_progress' },
      { id: '3', subject: 'pending-1', status: 'pending' },
      { id: '4', subject: 'done-2', status: 'completed' },
      { id: '5', subject: 'pending-2', status: 'pending' },
    ]
    expect(orderTeamTasks(tasks).map(t => t.subject)).toEqual(['active', 'pending-1', 'pending-2', 'done-1', 'done-2'])
  })
})

import { teamTasksByOwner } from '../src/client/swarm/swarm-model.ts'

describe('teamTasksByOwner', () => {
  it('folds in-progress subjects per owner session', () => {
    const byOwner = teamTasksByOwner({
      projectionsBySession: {
        lead: { values: { agentTeam: { members: [], tasks: [
          { id: 't1', subject: '写接口', status: 'in_progress', ownerId: 'mate1' },
          { id: 't2', subject: '已完成', status: 'completed', ownerId: 'mate1' },
          { id: 't3', subject: '待办', status: 'pending', ownerId: 'mate2' },
        ] } } },
      },
    })
    expect(byOwner.get('mate1')).toEqual(['写接口'])
    // Pending tasks are not in progress — they do not fold.
    expect(byOwner.get('mate2')).toBeUndefined()
  })

  it('malformed projections yield an empty map', () => {
    expect(teamTasksByOwner(null).size).toBe(0)
    expect(teamTasksByOwner({ projectionsBySession: { a: { values: { agentTeam: { tasks: 'nope' } } } } }).size).toBe(0)
  })
})

import { toolLabel } from '../src/client/swarm/swarm-model.ts'

describe('toolLabel', () => {
  it('maps known tool families to Chinese labels', () => {
    expect(toolLabel('pwsh')).toBe('终端')
    expect(toolLabel('job_output')).toBe('后台任务')
    expect(toolLabel('read')).toBe('读取')
    expect(toolLabel('write')).toBe('写入')
    expect(toolLabel('grep')).toBe('搜索')
    expect(toolLabel('send_message')).toBe('发消息')
    expect(toolLabel('spawn_teammate')).toBe('创建队友')
    expect(toolLabel('wait_agent')).toBe('等待')
    expect(toolLabel('working_directory')).toBe('工作目录')
  })

  it('unknown tools keep the raw name', () => {
    expect(toolLabel('mystery_tool')).toBe('mystery_tool')
  })
})

import { getTeamDescription } from '../src/client/swarm/swarm-model.ts'

describe('team description cache', () => {
  it('caches and retrieves descriptions from team/member events', () => {
    agentsFromWindows([{
      sessionId: 'root',
      entries: [
        { type: 'event', event: { type: 'team/member', seq: 1, data: { version: 2, teamId: 't1', member: { id: 'm1', name: '校验员', role: 'teammate', status: 'inactive', description: '负责检查链接校验' } } } },
      ],
    }], 'root')
    expect(getTeamDescription('m1')).toBe('负责检查链接校验')
  })
})
