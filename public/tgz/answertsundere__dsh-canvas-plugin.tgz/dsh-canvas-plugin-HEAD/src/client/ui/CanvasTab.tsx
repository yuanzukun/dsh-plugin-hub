import {
  Fragment, useEffect, useReducer, useRef, useState,
  type CSSProperties, type FC, type MouseEvent as ReactMouseEvent,
} from 'react'
import type { ComparisonResult, LaunchMode, SessionId } from '../../shared/contracts.ts'
import { theme } from '../theme.ts'
import { layoutLayered, type LayoutPoint } from '../graph/graph-layout.ts'
import { hiddenByCollapse } from '../graph/graph-model.ts'
import { parallelWriteIds } from '../graph/parallel-write.ts'
import { tailSnippet } from '../live/live-tail.ts'
import { NodeCard } from './NodeCard.tsx'
import { RightPanel, type RightPanelTab } from './RightPanel.tsx'
import { BranchTimeline, cutSeqAt } from './BranchTimeline.tsx'
import { ForkDialog } from './ForkDialog.tsx'
import { ComparePanel } from './ComparePanel.tsx'
import { AgentSwarmView } from './AgentSwarmView.tsx'
import type { AgentSwarmController } from '../controllers/agent-swarm-controller.ts'
import type { CanvasDetail, CanvasModel, CanvasView } from './canvas-model.ts'

export interface CanvasTabProps {
  /** Absent until the controller layer is wired in; the tab still boots. */
  readonly canvas?: CanvasModel
}

const NODE_WIDTH = 200
const NODE_HEIGHT = 72
const MIN_SCALE = 0.4
const MAX_SCALE = 2
/** Nominal viewport the fit-view button targets, in canvas units. */
const FIT_VIEWPORT = { width: 1000, height: 600 }

/**
 * The canvas has no CSS pipeline (inline styles only), so the few things that
 * need real CSS — the breathing halo keyframes and the ⌖ hover — ride in as a
 * single injected sheet. The halo color comes from each card's --breath-color,
 * which is the status's own color.
 */
const CANVAS_CSS = `
@keyframes dshCanvasBreath {
  0%, 100% { box-shadow: 0 0 0 0 transparent; }
  50% { box-shadow: 0 0 18px 3px var(--breath-color); }
}
.dsh-canvas-inspect:hover { color: ${theme.text}; border-color: ${theme.accent}; }

/* Worker robots: each node's avatar animates by what it is doing. */
@keyframes dshRobotBob { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-2px); } }
@keyframes dshRobotBreathe { 0%, 100% { opacity: 1; } 50% { opacity: 0.78; } }
@keyframes dshRobotLed { 0%, 100% { opacity: 1; } 50% { opacity: 0.2; } }
@keyframes dshRobotArmL { 0%, 100% { transform: rotate(0deg); } 50% { transform: rotate(-16deg); } }
@keyframes dshRobotArmR { 0%, 100% { transform: rotate(0deg); } 50% { transform: rotate(16deg); } }
@keyframes dshRobotShake { 0%, 100% { transform: rotate(0deg); } 25% { transform: rotate(-3deg); } 75% { transform: rotate(3deg); } }
@keyframes dshDashFlow { to { stroke-dashoffset: -24; } }

.dsh-robot-working { animation: dshRobotBob 1.1s ease-in-out infinite; }
.dsh-robot-working .dsh-robot-led { animation: dshRobotLed 0.7s ease-in-out infinite; }
.dsh-robot-working .dsh-robot-arm-l { animation: dshRobotArmL 1.1s ease-in-out infinite; transform-origin: 7px 31px; }
.dsh-robot-working .dsh-robot-arm-r { animation: dshRobotArmR 1.1s ease-in-out infinite; transform-origin: 33px 31px; }
.dsh-robot-idle { animation: dshRobotBreathe 3.4s ease-in-out infinite; }
.dsh-robot-idle .dsh-robot-led { opacity: 0.55; }
.dsh-robot-done .dsh-robot-eye { fill: #2f9e6f; }
.dsh-robot-failed { animation: dshRobotShake 0.5s ease-in-out infinite; }
.dsh-robot-failed .dsh-robot-led { animation: dshRobotLed 0.35s ease-in-out infinite; }

/* A hot thread is a conveyor: dashes flow toward the parent while work runs,
   and the thread itself breathes its width. */
@keyframes dshHotWidth { 0%, 100% { stroke-width: 1.8; } 50% { stroke-width: 3; } }
.dsh-swarm-hot { stroke-dasharray: 6 6; animation: dshDashFlow 0.8s linear infinite, dshHotWidth 1.2s ease-in-out infinite; }

/* Idle robots fidget with their own tool: the investigator swings the
   magnifier, the scribe taps the pencil, the scanner lens glints. */
@keyframes dshIdleSwing { 0%, 100% { transform: rotate(-6deg); } 50% { transform: rotate(6deg); } }
@keyframes dshIdleTap { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-2px); } }
@keyframes dshIdleGlint { 0%, 70%, 100% { opacity: 0.8; } 80% { opacity: 0.1; } }
@keyframes dshWaitBreath { 0%, 100% { opacity: 0.45; } 50% { opacity: 1; } }
[data-conclusion-waiting] { animation: dshWaitBreath 1.6s ease-in-out infinite; }

/* Canvas texture: a 24px dot grid turns the flat void into a workbench. */
.dsh-canvas-surface {
  background-image: radial-gradient(${theme.border} 1px, transparent 1px);
  background-size: 24px 24px;
}
/* Node cards lift on hover — the standard affordance for "this is grabbable". */
.dsh-node-card { transition: transform 0.15s ease, box-shadow 0.15s ease, left 0.3s ease, top 0.3s ease; }
[data-canvas-node]:hover { transform: translateY(-2px); box-shadow: 0 6px 16px rgba(0, 0, 0, 0.4); }
/* Threads feeding working sessions flow, like the swarm's silk. */
.dsh-edge-busy { stroke-dasharray: 6 6; animation: dshDashFlow 0.9s linear infinite; }
/* The selected card breathes a soft accent ring. */
@keyframes dshSelectedBreath { 0%, 100% { box-shadow: 0 0 0 0 transparent; } 50% { box-shadow: 0 0 0 3px #6af55; } }
[data-canvas-node][data-selected='true'] { animation: dshSelectedBreath 2.2s ease-in-out infinite; }
@keyframes dshWaitBreath { 0%, 100% { opacity: 0.45; } 50% { opacity: 1; } }
[data-conclusion-waiting] { animation: dshWaitBreath 1.6s ease-in-out infinite; }
.dsh-robot-v-search.dsh-robot-idle [data-robot-part='magnifier'] { transform-origin: 24px 20px; animation: dshIdleSwing 3.6s ease-in-out infinite; }
.dsh-robot-v-write.dsh-robot-idle [data-robot-part='pencil'] { animation: dshIdleTap 2.8s ease-in-out infinite; }
.dsh-robot-v-read.dsh-robot-idle .dsh-robot-eye { animation: dshIdleGlint 4.2s ease-in-out infinite; }
`

/**
 * Corner overview: every node as a status dot, the current viewport as a
 * frame, and a click that recenters the view on the chosen spot.
 */
const MiniMap: FC<{
  readonly canvas: CanvasModel
  readonly layout: { width: number; height: number; positions: ReadonlyMap<SessionId, LayoutPoint> }
  /** The measured stage the web renders into; defaults to the nominal viewport. */
  readonly stage?: { readonly width: number; readonly height: number }
  onViewChange(view: CanvasView): void
  onSelectNode?(id: SessionId): void
}> = ({ canvas, layout, stage, onViewChange, onSelectNode }) => {
  // Dragging anywhere on the minimap pans the real view in real time.
  const dragRef = useRef<{ x: number; y: number; viewX: number; viewY: number } | null>(null)
  const onDragMove = (event: ReactMouseEvent): void => {
    const started = dragRef.current
    if (started === null) return
    onViewChange({
      x: started.viewX - (event.clientX - started.x),
      y: started.viewY - (event.clientY - started.y),
      scale: canvas.view.scale,
    })
  }
  const BOX = { width: 148, height: 96, pad: 6 }
  const scale = Math.min(
    BOX.width / Math.max(layout.width, 1),
    BOX.height / Math.max(layout.height, 1),
  )
  const stageWidth = stage?.width ?? FIT_VIEWPORT.width
  const stageHeight = stage?.height ?? FIT_VIEWPORT.height
  const viewportWidth = Math.max((stageWidth / canvas.view.scale) * scale, 10)
  const viewportHeight = Math.max((stageHeight / canvas.view.scale) * scale, 10)
  const viewportX = BOX.pad - canvas.view.x * scale
  const viewportY = BOX.pad - canvas.view.y * scale
  return (
    <div
      data-canvas-minimap
      title="点击跳转到对应位置"
      style={{
        position: 'absolute', right: 10, bottom: 10, zIndex: 4,
        width: BOX.width, height: BOX.height,
        background: theme.panel, border: `1px solid ${theme.border}`, borderRadius: 8,
        opacity: 0.85, cursor: 'crosshair',
      }}
      onMouseDown={event => {
        dragRef.current = { x: event.clientX, y: event.clientY, viewX: canvas.view.x, viewY: canvas.view.y }
      }}
      onMouseMove={onDragMove}
      onMouseUp={() => { dragRef.current = null }}
      onMouseLeave={() => { dragRef.current = null }}
      onClick={event => {
        const rect = (event.currentTarget as HTMLElement).getBoundingClientRect()
        const contentX = (event.clientX - rect.left - BOX.pad) / scale
        const contentY = (event.clientY - rect.top - BOX.pad) / scale
        onViewChange({
          x: FIT_VIEWPORT.width / 2 - contentX * canvas.view.scale,
          y: FIT_VIEWPORT.height / 2 - contentY * canvas.view.scale,
          scale: canvas.view.scale,
        })
      }}
    >
      <div
        data-minimap-frame
        style={{
          position: 'absolute', left: viewportX, top: viewportY,
          width: viewportWidth, height: viewportHeight,
          border: `1px solid ${theme.accent}`, borderRadius: 2, opacity: 0.9,
        }}
      />
      {[...layout.positions.entries()].map(([id, point]) => {
        const selected = canvas.selectedId === id
        return (
          <span
            key={id}
            data-minimap-node={id}
            data-minimap-selected={selected ? 'true' : 'false'}
            title={canvas.graph.nodes.get(id)?.title}
            onClick={event => {
              if (onSelectNode === undefined) return
              event.stopPropagation()
              onSelectNode(id)
            }}
            style={{
              position: 'absolute',
              left: BOX.pad + point.x * scale - 1.5,
              top: BOX.pad + point.y * scale - 1.5,
              width: selected ? 5 : 3, height: selected ? 5 : 3, borderRadius: 1.5,
              background: canvas.statusOf(id).color,
              outline: selected ? `1px solid ${theme.accent}` : undefined,
              cursor: onSelectNode === undefined ? 'default' : 'pointer',
            }}
          />
        )
      })}
    </div>
  )
}

export const CanvasTab: FC<CanvasTabProps> = ({ canvas }) => {
  const [query, setQuery] = useState('')
  const [tab, setTab] = useState<RightPanelTab>('detail')
  const [detail, setDetail] = useState<CanvasDetail | null>(null)
  const [comparison, setComparison] = useState<ComparisonResult | null>(null)
  const [fork, setFork] = useState<{ rowIndex: number; atSeq: number } | null>(null)
  const [forkBusy, setForkBusy] = useState(false)
  const [forkError, setForkError] = useState<string | undefined>(undefined)
  const [carried, setCarried] = useState(false)
  const [swarm, setSwarm] = useState<AgentSwarmController | null>(null)
  const drag = useRef<{ startX: number; startY: number; viewX: number; viewY: number } | null>(null)
  const [, bump] = useReducer((tick: number) => tick + 1, 0)

  const selectedId = canvas?.selectedId
  const compareKey = canvas?.compareIds.join('\u0000') ?? ''

  // A running node has a live window; its detail updates in place, so the tab
  // must not pay for (or overwrite it with) the one-shot read. Everything that
  // acts on "the detail the user is looking at" — rows, fork cut, session id —
  // reads this effective value, not the one-shot state.
  const liveDetail = selectedId === undefined ? null : canvas?.liveDetail?.(selectedId) ?? null
  const effectiveDetail = liveDetail ?? detail
  const tail = selectedId === undefined ? null : canvas?.tailOf?.(selectedId) ?? null

  // The slot hands the tab a single model object for its lifetime, so live
  // updates arrive through the model's own invalidation channel rather than
  // through new props.
  useEffect(() => canvas?.subscribe?.(() => { bump() }), [canvas])

  // The swarm view owns its controller: every open window is a retain, so the
  // tab disposes it on close and on unmount.
  const swarmRef = useRef<AgentSwarmController | null>(null)
  swarmRef.current = swarm
  useEffect(() => swarm?.subscribe(() => { bump() }), [swarm])
  useEffect(() => () => { swarmRef.current?.dispose() }, [])

  const openSwarm = (id: string): void => {
    if (canvas?.inspectSwarm === undefined) return
    swarmRef.current?.dispose()
    const next = canvas.inspectSwarm(id)
    swarmRef.current = next
    setSwarm(next)
  }
  const closeSwarm = (): void => {
    swarmRef.current?.dispose()
    swarmRef.current = null
    setSwarm(null)
  }

  // Right-click fork: selecting a node whose detail has not loaded yet means
  // the cut point arrives later — remember the intent, open the dialog when
  // the effective detail shows up.
  const [pendingForkFor, setPendingForkFor] = useState<string | null>(null)
  useEffect(() => {
    if (pendingForkFor === null || effectiveDetail?.sessionId !== pendingForkFor) return
    const rows = effectiveDetail.turns
    let lastIdx = -1
    for (let i = rows.length - 1; i >= 0; i -= 1) {
      const row = rows[i]
      if (row !== undefined && !row.synthetic) { lastIdx = i; break }
    }
    setPendingForkFor(null)
    if (lastIdx < 0) return
    const atSeq = cutSeqAt(rows, lastIdx)
    if (atSeq === undefined) return
    setTab('detail')
    setFork({ rowIndex: lastIdx, atSeq })
  }, [pendingForkFor, effectiveDetail])

  // Keyboard pan/zoom: arrow keys pan, +/- zooms. Active only when the focus
  // is not in a text field, so typing never moves the view.
  useEffect(() => {
    const onKey = (event: KeyboardEvent): void => {
      const target = event.target as HTMLElement | null
      if (target !== null && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)) return
        if (canvas === undefined) return
      const PAN = 60
      switch (event.key) {
        case 'ArrowLeft': canvas.onViewChange({ ...canvas.view, x: canvas.view.x + PAN }); break
        case 'ArrowRight': canvas.onViewChange({ ...canvas.view, x: canvas.view.x - PAN }); break
        case 'ArrowUp': canvas.onViewChange({ ...canvas.view, y: canvas.view.y + PAN }); break
        case 'ArrowDown': canvas.onViewChange({ ...canvas.view, y: canvas.view.y - PAN }); break
        case '+': case '=':
          canvas.onViewChange({ ...canvas.view, scale: Math.min(2, canvas.view.scale * 1.12) }); break
        case '-': case '_':
          canvas.onViewChange({ ...canvas.view, scale: Math.max(0.4, canvas.view.scale / 1.12) }); break
        default:
          return
      }
      event.preventDefault()
    }
    window.addEventListener('keydown', onKey)
    return () => { window.removeEventListener('keydown', onKey) }
  }, [canvas])

  // Esc unwinds layer by layer: context menu first, then the swarm, then the
  // selection — one press per layer, never all at once.
  useEffect(() => {
    const onKey = (event: KeyboardEvent): void => {
      if (event.key !== 'Escape') return
      if (menu !== null) { setMenu(null); return }
      if (swarmRef.current !== null) { closeSwarm(); return }
      if (selectedId !== undefined) canvas?.clearSelection?.()
    }
    window.addEventListener('keydown', onKey)
    return () => { window.removeEventListener('keydown', onKey) }
  })

  // Fit the view once, when the first nodes arrive — an empty opening canvas
  // that grows into a lopsided corner is exactly what 适配视图 exists for.
  // A window resize re-fits: the layout that fit 1600px does not fit 900px.
  const autoFitted = useRef(false)
  const fitView = (): void => {
    if (canvas === undefined) return
    const layout = layoutLayered(canvas.graph, { nodeWidth: NODE_WIDTH, nodeHeight: NODE_HEIGHT })
    if (layout.width === 0 || layout.height === 0) return
    const fitScale = Math.min(
      (FIT_VIEWPORT.width - 40) / layout.width,
      (FIT_VIEWPORT.height - 40) / layout.height,
      1,
    )
    const clamped = Math.max(MIN_SCALE, Math.min(MAX_SCALE, fitScale === 0 ? 1 : fitScale))
    canvas.onViewChange({
      x: (FIT_VIEWPORT.width - layout.width * clamped) / 2,
      y: (FIT_VIEWPORT.height - layout.height * clamped) / 2,
      scale: clamped,
    })
  }
  useEffect(() => {
    if (autoFitted.current || canvas === undefined) return
    if (canvas.graph.nodes.size === 0) return
    autoFitted.current = true
    fitView()
  }, [canvas, canvas?.graph.nodes.size, fitView])

  // Window resize re-fits with a small debounce — the layout that fit 1600px
  // does not fit 900px, and fighting the user mid-drag helps no one.
  useEffect(() => {
    let timer: number | undefined
    const onResize = (): void => {
      window.clearTimeout(timer)
      timer = window.setTimeout(() => { fitView() }, 200)
    }
    window.addEventListener('resize', onResize)
    return () => {
      window.clearTimeout(timer)
      window.removeEventListener('resize', onResize)
    }
  }, [fitView])

  // Selecting a node centers it — but only when it is outside the viewport;
  // nearby clicks must not yank the view.
  const centerOn = (id: SessionId): void => {
    if (canvas === undefined) return
    const point = layout.positions.get(id)
    if (point === undefined) return
    const screenX = point.x * canvas.view.scale + canvas.view.x
    const screenY = point.y * canvas.view.scale + canvas.view.y
    if (screenX >= 0 && screenX <= FIT_VIEWPORT.width && screenY >= 0 && screenY <= FIT_VIEWPORT.height) return
    canvas.onViewChange({
      x: FIT_VIEWPORT.width / 2 - (point.x + NODE_WIDTH / 2) * canvas.view.scale,
      y: FIT_VIEWPORT.height / 2 - (point.y + NODE_HEIGHT / 2) * canvas.view.scale,
      scale: canvas.view.scale,
    })
  }

  useEffect(() => {
    if (selectedId !== undefined) centerOn(selectedId)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId])

  // The minimap's viewport frame is drawn against the measured stage, so it
  // tracks the real window rather than the nominal one.
  const surfaceRef = useRef<HTMLDivElement | null>(null)
  const [stageSize, setStageSize] = useState<{ width: number; height: number } | undefined>(undefined)
  useEffect(() => {
    const element = surfaceRef.current
    if (element === null || typeof ResizeObserver === 'undefined') return
    const measure = (): void => {
      setStageSize({ width: element.clientWidth, height: element.clientHeight })
    }
    measure()
    const observer = new ResizeObserver(measure)
    observer.observe(element)
    return () => { observer.disconnect() }
  }, [])



  const [menu, setMenu] = useState<{ x: number; y: number; id: string } | null>(null)
  const openContext = (event: ReactMouseEvent<HTMLDivElement>, id: string): void => {
    setMenu({ x: event.clientX, y: event.clientY, id })
  }
  const menuFork = (): void => {
    const id = menu?.id
    setMenu(null)
    if (id === undefined) return
    if (canvas?.selectedId !== id) canvas?.onSelect(id)
    setPendingForkFor(id)
  }

  // A node's turns come from its live window while one is open, and from a
  // one-shot read otherwise — including when a running session stops and its
  // window closes under the selection.
  const hasLiveDetail = liveDetail !== null
  useEffect(() => {
    setTab('detail')
    // A pending right-click fork opens the dialog for this very selection in
    // the same commit; resetting here would clear it before it is seen.
    if (pendingForkFor === null) {
      setFork(null)
      setForkError(undefined)
    }
    if (canvas?.detail === undefined || selectedId === undefined || hasLiveDetail) {
      setDetail(null)
      return
    }
    let live = true
    void canvas.detail(selectedId).then(next => { if (live) setDetail(next) })
    return () => { live = false }
  }, [canvas, selectedId, hasLiveDetail])

  useEffect(() => {
    if (tab !== 'compare' || canvas?.comparison === undefined) return
    let live = true
    void canvas.comparison().then(next => { if (live) setComparison(next) })
    return () => { live = false }
  }, [canvas, tab, compareKey])

  if (canvas === undefined) {
    return (
      <div
        data-canvas-root
        data-canvas-unwired="true"
        style={{ height: '100%', background: theme.bg, color: theme.muted, padding: 16, font: '12px system-ui, sans-serif' }}
      >
        画布尚未接线
      </div>
    )
  }

  const now = Date.now()
  const needle = query.trim().toLowerCase()
  const [legendVisible, setLegendVisible] = useState(false)
  const runningCount = [...canvas.graph.nodes.values()]
    .filter(node => {
      const kind = canvas.statusOf(node.id).kind
      return kind === 'thinking' || kind === 'tool'
    })
    .length
  const matches = (needle: string): number =>
    needle === '' ? 0 : [...canvas.graph.nodes.values()].filter(node => matchesNode(node, needle)).length
  const selectedNode = selectedId === undefined ? undefined : canvas.graph.nodes.get(selectedId)

  // A pan that started on a card must not end as an accidental selection:
  // once the pointer travels past the threshold, the click is swallowed.
  const suppressClick = useRef(false)
  const dragStart = useRef<{ x: number; y: number } | null>(null)
  // Hovering a node highlights its spokes.
  const [hoverId, setHoverId] = useState<SessionId | undefined>(undefined)
  // Collapsed subtrees drop out of the layout: their nodes, edges, and the
  // minimap all re-derive from the filtered graph.
  const hidden = hiddenByCollapse(canvas.graph.nodes, canvas.collapsedNodes ?? new Set())
  const displayGraph = hidden.size === 0
    ? canvas.graph
    : {
        ...canvas.graph,
        nodes: new Map([...canvas.graph.nodes].filter(([id]) => !hidden.has(id))),
        roots: canvas.graph.roots.filter(id => !hidden.has(id)),
      }
  const layout = layoutLayered(displayGraph, { nodeWidth: NODE_WIDTH, nodeHeight: NODE_HEIGHT })
  const parallelWrite = parallelWriteIds(displayGraph)
  const displayCanvas: CanvasModel = { ...canvas, graph: displayGraph }
  const handleNodeClick = (event: ReactMouseEvent<HTMLDivElement>, id: SessionId): void => {
    if (suppressClick.current) return
    if (event.metaKey || event.ctrlKey) canvas.onToggleCompare(id)
    else canvas.onSelect(id)
  }

  const fit = (): void => { fitView() }

  const openFork = (rowIndex: number): void => {
    const atSeq = cutSeqAt(effectiveDetail?.turns ?? [], rowIndex)
    if (atSeq === undefined) return
    setForkError(undefined)
    setFork({ rowIndex, atSeq })
  }

  const confirmFork = async (instruction: string, mode: LaunchMode): Promise<void> => {
    const sessionId = effectiveDetail?.sessionId
    if (sessionId === undefined || fork === null || canvas.forkFromRow === undefined) return
    setForkBusy(true)
    setForkError(undefined)
    const outcome = await canvas.forkFromRow(sessionId, fork.atSeq, instruction, mode)
    setForkBusy(false)
    if (outcome.phase === 'done') {
      setFork(null)
      return
    }
    // `unverified` is not a failure — the child may exist. Saying so is the whole
    // reason the phase is kept separate from `failed`.
    setForkError(outcome.error ?? (outcome.phase === 'unverified'
      ? '分支可能已创建，但无法确认，请刷新后检查'
      : '分支创建失败'))
  }

  const carry = (draft: string): void => {
    // v1 has no composer handle, so the draft goes to the clipboard rather than
    // being submitted anywhere. The user still ends up with the text.
    const clipboard = (globalThis as {
      navigator?: { clipboard?: { writeText(text: string): Promise<void> } }
    }).navigator?.clipboard
    void clipboard?.writeText(draft)
    setCarried(true)
  }

  return (
    <div
      data-canvas-root
      style={{ height: '100%', display: 'flex', flexDirection: 'column', background: theme.bg, color: theme.text, position: 'relative' }}
    >
      <style>{CANVAS_CSS}</style>
      {swarm !== null && (
        <AgentSwarmView
          swarm={swarm.state()}
          onClose={closeSwarm}
          onSelectAgent={id => {
            closeSwarm()
            canvas.onSelect(id)
          }}
          onOpenRoot={selectedId === undefined ? undefined : () => {
            closeSwarm()
            canvas.openInChat?.(selectedId)
          }}
        />
      )}
      {menu !== null && (
        <>
          <div
            data-context-backdrop
            onClick={() => setMenu(null)}
            onContextMenu={event => { event.preventDefault(); setMenu(null) }}
            style={{ position: 'fixed', inset: 0, zIndex: 20 }}
          />
          <div
            data-context-menu
            style={{
              position: 'fixed', left: menu.x, top: menu.y, zIndex: 21,
              minWidth: 180, padding: 4,
              background: theme.panel, border: `1px solid ${theme.border}`, borderRadius: 8,
              boxShadow: '0 8px 24px rgba(0,0,0,0.5)',
              font: '12px system-ui, sans-serif', color: theme.text,
            }}
          >
            {[
              { key: 'fork', label: '⑂ 从最新消息分叉', run: menuFork },
              ...(canvas.inspectSwarm !== undefined
                ? [{ key: 'inspect', label: '⌖ Agent 实况', run: () => { setMenu(null); openSwarm(menu.id) } }]
                : []),
              ...(canvas.openInChat !== undefined
                ? [{ key: 'open', label: '打开对话', run: () => { setMenu(null); canvas.openInChat?.(menu.id) } }]
                : []),
            ].map(item => (
              <div
                key={item.key}
                data-context-item={item.key}
                onClick={item.run}
                style={{ padding: '6px 10px', borderRadius: 6, cursor: 'pointer' }}
                onMouseEnter={event => { event.currentTarget.style.background = theme.cardActive }}
                onMouseLeave={event => { event.currentTarget.style.background = 'transparent' }}
              >
                {item.label}
              </div>
            ))}
          </div>
        </>
      )}
      <div
        data-canvas-toolbar
        style={{
          display: 'flex', alignItems: 'center', gap: 8, padding: '6px 10px',
          borderBottom: `1px solid ${theme.border}`, background: theme.panel,
          font: '12px system-ui, sans-serif',
        }}
      >
        {needle !== '' && (
          <span data-canvas-match-count style={{ color: theme.muted, font: '11px system-ui, sans-serif' }}>
            {matches(needle)} 个匹配
          </span>
        )}
        <input
          data-canvas-search
          value={query}
          placeholder="搜索会话（Enter 跳下一个）"
          aria-label="搜索会话"
          onChange={event => {
            setQuery(event.target.value)
            canvas.search(event.target.value)
          }}
          onKeyDown={event => {
            if (event.key === 'Enter') canvas.searchNext?.(query)
          }}
          style={{
            background: theme.bg, color: theme.text, border: `1px solid ${theme.border}`,
            borderRadius: 6, padding: '3px 8px', width: 180, font: 'inherit',
          }}
        />
        <span style={{ color: theme.muted }}>
          {canvas.graph.nodes.size} 个会话
          {runningCount > 0 && (
            <span data-canvas-running-count style={{ color: theme.warn, marginLeft: 6 }}>
              · {runningCount} 运行中
            </span>
          )}
        </span>
        <button type="button" data-canvas-fit onClick={fit} style={buttonStyle}>适配视图</button>
        {canvas.toggleShowSubagents !== undefined && (
          <button
            type="button"
            data-canvas-toggle-subagents
            aria-pressed={canvas.showSubagents === true}
            title="子代理是对话内部的关系：默认折叠进父对话的「机器人 ×N」徽章，⌖ 实况里看全网"
            onClick={() => canvas.toggleShowSubagents?.()}
            style={{
              ...buttonStyle,
              ...(canvas.showSubagents === true
                ? { borderColor: theme.accent, color: theme.accent }
                : {}),
            }}
          >
            {canvas.showSubagents === true ? '子代理·显示中' : '子代理'}
          </button>
        )}
        {canvas.refresh !== undefined && (
          <button type="button" data-canvas-refresh onClick={() => canvas.refresh?.()} style={buttonStyle}>刷新</button>
        )}
      </div>

      <div style={{ display: 'flex', flex: '1 1 auto', minHeight: 0 }}>
        <div
          ref={surfaceRef}
          data-canvas-surface
          className="dsh-canvas-surface"
          onMouseDown={event => {
            drag.current = {
              startX: event.clientX, startY: event.clientY,
              viewX: canvas.view.x, viewY: canvas.view.y,
            }
            dragStart.current = { x: event.clientX, y: event.clientY }
            suppressClick.current = false
          }}
          onMouseMove={event => {
            const started = drag.current
            if (started === null) return
            const origin = dragStart.current
            if (origin !== null && Math.hypot(event.clientX - origin.x, event.clientY - origin.y) > 4) {
              suppressClick.current = true
            }
            canvas.onViewChange({
              x: started.viewX + (event.clientX - started.startX),
              y: started.viewY + (event.clientY - started.startY),
              scale: canvas.view.scale,
            })
          }}
          onMouseUp={() => { drag.current = null }}
          onMouseLeave={() => { drag.current = null }}
          onDoubleClick={event => {
            // Double-clicking empty canvas space re-fits the view.
            if ((event.target as HTMLElement).closest('[data-canvas-node]')) return
            fitView()
          }}
          onWheel={event => {
            const factor = event.deltaY < 0 ? 1.1 : 1 / 1.1
            canvas.onViewChange({ ...canvas.view, scale: clamp(canvas.view.scale * factor, MIN_SCALE, MAX_SCALE) })
          }}
          style={{ position: 'relative', flex: '1 1 auto', overflow: 'hidden', cursor: 'grab' }}
        >
          {canvas.graph.nodes.size === 0 && (
            <div
              data-canvas-empty
              style={{
                position: 'absolute', inset: 0, display: 'flex',
                flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                color: theme.muted, font: '13px system-ui, sans-serif', gap: 6,
              }}
            >
              <span>当前工作区还没有会话</span>
              <span style={{ fontSize: 11, opacity: 0.7 }}>归档的会话不会出现在画布上</span>
            </div>
          )}
          <div
            data-canvas-plane
            style={{
              position: 'absolute',
              inset: 0,
              transform: `translate(${canvas.view.x}px, ${canvas.view.y}px) scale(${canvas.view.scale})`,
              transformOrigin: '0 0',
            }}
          >
            <svg
              data-canvas-edges
              width={Math.max(layout.width, 1)}
              height={Math.max(layout.height, 1)}
              style={{ position: 'absolute', left: 0, top: 0, pointerEvents: 'none' }}
            >
              <defs>
                <filter id="dsh-glow" x="-40%" y="-40%" width="180%" height="180%">
                  <feGaussianBlur stdDeviation="3.5" />
                </filter>
                <marker id="dsh-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
                  <path d="M 0 0 L 10 5 L 0 10 z" fill={theme.border} />
                </marker>
                <marker id="dsh-arrow-accent" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
                  <path d="M 0 0 L 10 5 L 0 10 z" fill={theme.accent} />
                </marker>
                <marker id="dsh-arrow-warn" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
                  <path d="M 0 0 L 10 5 L 0 10 z" fill={theme.warn} />
                </marker>
              </defs>
              {edgePaths(displayCanvas, layout.positions, hoverId).map(edge => (
                <Fragment key={`${edge.from}->${edge.to}`}>
                  <path
                    d={edge.d}
                    fill="none"
                    stroke={edge.active ? theme.accent : edge.hover ? theme.text : edge.busy ? theme.warn : theme.border}
                    strokeWidth={edge.active ? 1.8 : edge.hover ? 2 : edge.busy ? 1.6 : 1.5}
                    opacity={edge.active ? 1 : edge.busy ? 0.8 : 0.7}
                    className={edge.busy ? 'dsh-edge-busy' : undefined}
                    markerEnd={edge.active ? 'url(#dsh-arrow-accent)' : edge.busy ? 'url(#dsh-arrow-warn)' : 'url(#dsh-arrow)'}
                  />
                  {edge.busy && (
                    <path
                      data-edge-glow={`${edge.from}->${edge.to}`}
                      d={edge.d}
                      fill="none"
                      stroke={theme.warn}
                      strokeWidth={4}
                      opacity={0.35}
                      filter="url(#dsh-glow)"
                    />
                  )}
                </Fragment>
              ))}
            </svg>

            {[...displayGraph.nodes.values()].map(node => {
              const nodeTail = canvas.tailOf?.(node.id) ?? null
              const nodeStatus = canvas.statusOf(node.id)
              return (
                <NodeCard
                  key={node.id}
                  node={node}
                  status={nodeStatus}
                  position={layout.positions.get(node.id) ?? { x: 0, y: 0 }}
                  width={NODE_WIDTH}
                  height={NODE_HEIGHT}
                  selected={canvas.selectedId === node.id}
                  comparing={canvas.compareIds.includes(node.id)}
                  parallelWrite={parallelWrite.has(node.id)}
                  highlight={needle !== '' && matchesNode(node, needle)}
                  live={nodeTail === null ? null : tailSnippet(nodeTail, 40)}
                  active={nodeStatus.kind === 'thinking' || nodeStatus.kind === 'tool' || nodeTail !== null}
                  dimmed={now - node.createdAt > 24 * 60 * 60 * 1000}
                  now={now}
                  onClick={handleNodeClick}
                  onOpen={id => canvas.openInChat?.(id)}
                  onInspect={canvas.inspectSwarm === undefined ? undefined : openSwarm}
                  onContext={openContext}
                  onMouseEnter={() => setHoverId(node.id)}
                  onMouseLeave={() => setHoverId(undefined)}
                  collapseToggle={{
                    visible: node.childCount > 0,
                    collapsed: (canvas.collapsedNodes ?? new Set()).has(node.id),
                    onToggle: () => canvas.toggleSubtree?.(node.id),
                  }}
                />
              )
            })}
          </div>

          {layout.width > 0 && (
            <MiniMap
              canvas={canvas}
              layout={layout}
              stage={stageSize}
              onViewChange={view => canvas.onViewChange(view)}
              onSelectNode={id => {
                canvas.onSelect(id)
                centerOn(id)
              }}
            />
          )}
        </div>

        {selectedId !== undefined && (
          <RightPanel
            tab={tab}
            title={selectedNode?.title}
            headerAction={canvas.inspectSwarm !== undefined && selectedId !== undefined
              ? {
                  label: '⌖ Agent 实况',
                  title: '查看这个会话的 agent 蛛网：谁在跑、正在输出什么',
                  onClick: () => openSwarm(selectedId),
                }
              : undefined}
            onTabChange={setTab}
            onClose={() => canvas.clearSelection?.()}
          >
            {tab === 'detail' && selectedId !== undefined && (
              <div
                data-panel-actions
                style={{ display: 'flex', gap: 6, padding: '6px 10px', borderBottom: `1px solid ${theme.border}` }}
              >
                <button
                  type="button"
                  data-action-open-chat
                  onClick={() => canvas.openInChat?.(selectedId)}
                  style={{ background: theme.card, color: theme.text, border: `1px solid ${theme.border}`, borderRadius: 6, padding: '3px 8px', font: 'inherit', cursor: 'pointer' }}
                >
                  打开对话
                </button>
                <button
                  type="button"
                  data-action-fork-latest
                  title="从最新一条消息之后分叉"
                  onClick={() => { setPendingForkFor(selectedId); setTab('detail') }}
                  style={{ background: theme.card, color: theme.text, border: `1px solid ${theme.border}`, borderRadius: 6, padding: '3px 8px', font: 'inherit', cursor: 'pointer' }}
                >
                  ⑂ 从最新分叉
                </button>
              </div>
            )}
            {tab === 'detail' && (effectiveDetail?.turns.length ?? 0) > 0 && (
              <div
                data-panel-stats
                style={{ padding: '6px 10px', color: theme.muted, font: '11px system-ui, sans-serif', borderBottom: `1px solid ${theme.border}` }}
              >
                共 {effectiveDetail?.turns.length} 轮 · {effectiveDetail?.turns.reduce((sum, turn) => sum + turn.tools.length, 0)} 次工具
                {swarm !== null && swarm.state().activity.turnCount > 0 ? '' : ''}
              </div>
            )}
            {tab === 'detail' ? (
              <BranchTimeline
                turns={effectiveDetail?.turns ?? []}
                inheritedCount={effectiveDetail?.inheritedCount ?? 0}
                cwdWarning={effectiveDetail?.cwdWarning ?? false}
                conclusion={effectiveDetail?.conclusion ?? null}
                live={tail}
                onFork={openFork}
              />
            ) : (
              <>
                <ComparePanel
                  result={comparison}
                  onContinue={side => {
                    const id = canvas.compareIds[side === 'a' ? 0 : 1]
                    if (id !== undefined) canvas.onSelect(id)
                  }}
                  onCarry={(_side, draft) => { carry(draft) }}
                />
                {carried && (
                  <div data-carry-done style={{ color: theme.accent, padding: '0 10px 10px' }}>已复制到剪贴板</div>
                )}
              </>
            )}

            <ForkDialog
              open={fork !== null}
              atSeq={fork?.atSeq ?? 0}
              inheritedCount={effectiveDetail?.inheritedCount ?? 0}
              busy={forkBusy}
              {...(forkError === undefined ? {} : { error: forkError })}
              onCancel={() => { setFork(null); setForkError(undefined) }}
              onConfirm={(instruction, mode) => { void confirmFork(instruction, mode) }}
            />
          </RightPanel>
        )}
      </div>
    </div>
  )
}

function edgePaths(canvas: CanvasModel, positions: ReadonlyMap<SessionId, LayoutPoint>, hoverId?: SessionId) {
  const edges: { from: SessionId; to: SessionId; d: string; active: boolean; busy: boolean; hover: boolean }[] = []
  for (const node of canvas.graph.nodes.values()) {
    if (node.parentId === null) continue
    const from = positions.get(node.parentId)
    const to = positions.get(node.id)
    if (from === undefined || to === undefined) continue
    const x1 = from.x + NODE_WIDTH
    const y1 = from.y + NODE_HEIGHT / 2
    const x2 = to.x
    const y2 = to.y + NODE_HEIGHT / 2
    const status = canvas.statusOf(node.id).kind
    edges.push({
      from: node.parentId,
      to: node.id,
      d: `M ${x1} ${y1} C ${x1 + 40} ${y1}, ${x2 - 40} ${y2}, ${x2} ${y2}`,
      active: canvas.selectedId === node.id || canvas.compareIds.includes(node.id),
      // A thread feeding a working session is never border-dark.
      busy: status === 'thinking' || status === 'tool',
      hover: hoverId !== undefined && (node.id === hoverId || node.parentId === hoverId),
    })
  }
  return edges
}

function matches(title: string, id: string, needle: string): boolean {
  return title.toLowerCase().includes(needle) || id.toLowerCase().includes(needle)
}

function matchesNode(node: { title: string; id: string }, needle: string): boolean {
  return matches(node.title, node.id, needle)
}

function clamp(value: number, min: number, max: number): number {
  return value < min ? min : value > max ? max : value
}

const buttonStyle: CSSProperties = {
  background: theme.card, color: theme.text, border: `1px solid ${theme.border}`,
  borderRadius: 6, padding: '3px 10px', font: 'inherit', cursor: 'pointer',
}

export type { CanvasView }
