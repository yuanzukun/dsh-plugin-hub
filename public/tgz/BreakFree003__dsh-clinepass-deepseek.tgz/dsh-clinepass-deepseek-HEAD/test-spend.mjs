/**
 * `spend.js` 的单元测试：设置页「官方定价累计」。
 *
 * 只跑纯函数 + 临时目录，不碰真实 `$DSH_HOME`、不联网、不启宿主。
 */

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { captureQuotaBaseline, createSpendHandler, readSpend, SPEND_ROUTE, spendFileFor, sumCachedCosts, writeSpend } from './spend.js'
import { COST_STATE_VERSION, costViewOf } from './cost.js'

let failures = 0
const check = (label, ok, detail) => {
  if (ok) {
    console.log(`  ok   ${label}${detail === undefined ? '' : ` — ${detail}`}`)
    return
  }
  failures += 1
  console.log(` FAIL  ${label}${detail === undefined ? '' : ` — ${detail}`}`)
}

/** `costViewOf` 要的状态形状：一次高峰请求 = ¥0.00296。 */
const stateOf = (cacheRead = 4000, requests = 1) => ({
  inheritedEventCount: 0,
  route: { provider: 'cline-pass', model: 'cline-pass/deepseek-v4.1-flash-1017' },
  peak: { cacheRead, uncachedInput: 1000, cacheWrite: 0, output: 100, requests },
  off: { cacheRead: 0, uncachedInput: 0, cacheWrite: 0, output: 0, requests: 0 },
  last: null,
})

/** 全谷段的状态：实际价比峰价口径便宜一半。 */
const offStateOf = () => ({
  inheritedEventCount: 0,
  route: { provider: 'cline-pass', model: 'cline-pass/deepseek-v4.1-flash-1017' },
  peak: { cacheRead: 0, uncachedInput: 0, cacheWrite: 0, output: 0, requests: 0 },
  off: { cacheRead: 4000, uncachedInput: 1000, cacheWrite: 0, output: 100, requests: 1 },
  last: null,
})

/** 一次请求的实际金额（写死，不用 costViewOf 现算 —— 否则求和断言是自证）。 */
const CNY_ONE = 0.00296
const near = (a, b) => Math.abs(a - b) < 1e-9

/** 写一个投影缓存文件（形状与宿主落盘的 `{record:{identity,rows:{key:{seq,ver,val}}}}` 一致）。 */
const writeCache = (dir, id, value, extra = {}, createdAt) => {
  const rows = { tokenUsage: { ver: 2, seq: 1, val: {} } }
  if (value !== undefined) rows.clinepassCost = { ver: COST_STATE_VERSION, seq: 2, val: value, ...extra }
  const identity = typeof createdAt === 'number' ? { id, createdAt } : { id }
  fs.writeFileSync(path.join(dir, `${id}.json`), JSON.stringify({ record: { identity, rows } }))
}

const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'clinepass-spend-'))
const cacheDir = path.join(tempRoot, 'sessions')
fs.mkdirSync(cacheDir)
const spendFile = path.join(tempRoot, 'spend.json')

try {
  // ── 求和（按会话）─────────────────────────────────────
  writeCache(cacheDir, 'a', stateOf())
  writeCache(cacheDir, 'b', stateOf(8000, 2))
  writeCache(cacheDir, 'c', undefined) // 没有本投影的会话
  fs.writeFileSync(path.join(cacheDir, 'd.json'), '{broken')
  writeCache(cacheDir, 'e', stateOf(), { ver: COST_STATE_VERSION + 1 }) // 版本不匹配的行
  const sum = await sumCachedCosts(cacheDir)
  check('按会话给出成本', sum.sessions.size === 2 && near(sum.sessions.get('a'), CNY_ONE) && near(sum.sessions.get('b'), costViewOf(stateOf(8000, 2)).cny), JSON.stringify([...sum.sessions]))
  check('每个文件都扫到', sum.scanned === 5, String(sum.scanned))
  check('坏文件只计错误、不进总数', sum.errors === 1, String(sum.errors))
  check('版本不匹配的行被跳过而不是硬折', sum.skipped === 1, String(sum.skipped))
  check('目录不存在时是空表而不是抛错', (await sumCachedCosts(path.join(tempRoot, 'nope'))).sessions.size === 0)

  // 配额口径（恒按峰价）与实际价口径必须分开求和：谷段 token 在 `cny` 上打五折，
  // 在 `peaks` 上不打折 —— 两个数一样就说明 `cnyPeak` 没被用上。
  writeCache(cacheDir, 'off', offStateOf())
  const sumOff = await sumCachedCosts(cacheDir)
  const offView = costViewOf(offStateOf())
  check('谷段在峰价口径上不打折', near(sumOff.peaks.get('off'), offView.cnyPeak) && near(sumOff.sessions.get('off'), offView.cny), `${sumOff.peaks.get('off')} vs ${offView.cnyPeak}`)
  check('峰价口径约为实际价的两倍（全谷段）', sumOff.peaks.get('off') > sumOff.sessions.get('off') * 1.9, `${sumOff.peaks.get('off')} vs ${sumOff.sessions.get('off')}`)

  // ── 首次运行：每个会话记基线 ─────────────────────────
  let clock = 1_700_000_000_000
  const handler = createSpendHandler({ file: spendFile, dir: cacheDir, cacheMs: 0, now: () => clock, logger: { warn() {} } })

  const first = await (await handler({ method: 'GET' })).json()
  check('首次运行从 0 开始', first.ok === true && first.cny === 0 && first.cnyPeak === 0 && first.seen === 3, JSON.stringify({ cny: first.cny, seen: first.seen }))
  check('起点 = 现在', first.since === new Date(clock).toISOString())
  const persisted = readSpend(spendFile)
  check('每个会话都落了基线', persisted !== null && persisted.sessions.size === 3 && near(persisted.sessions.get('a'), CNY_ONE) && persisted.peaks !== undefined, JSON.stringify([...(persisted?.sessions ?? [])]))

  // ── 旧会话后来才出现：不跳 ───────────────────────────
  writeCache(cacheDir, 'old', stateOf(8000, 5)) // 一段"升级前"的历史
  clock += 1000
  const afterOld = await (await handler({ method: 'GET' })).json()
  check('新出现的旧会话不倒灌历史', afterOld.cny === 0, JSON.stringify(afterOld))
  check('…但它的基线被记住了', afterOld.seen === 4 && readSpend(spendFile).sessions.has('old'))

  // ── 已有会话继续花：只计增量 ─────────────────────────
  writeCache(cacheDir, 'a', stateOf(8000, 2)) // 从 ¥0.00296 涨到 ¥0.00608
  clock += 1000
  const grown = await (await handler({ method: 'GET' })).json()
  const grownDelta = costViewOf(stateOf(8000, 2)).cny - CNY_ONE
  check('会话增长只计增量', near(grown.cny, grownDelta), `${grown.cny} vs ${grownDelta}`)
  check('计数的会话数', grown.sessions === 1, String(grown.sessions))
  check('峰价口径同样只计增量', near(grown.cnyPeak, costViewOf(stateOf(8000, 2)).cnyPeak - CNY_ONE), `${grown.cnyPeak}`)

  // ── 重置 ─────────────────────────────────────────────
  clock += 1000
  const reset = await (await handler({ method: 'POST' })).json()
  check('重置后显示 0', reset.ok === true && reset.reset === true && reset.cny === 0, JSON.stringify(reset))
  check('重置返回了重置前的值', near(reset.previous, grown.cny), `${reset.previous} vs ${grown.cny}`)
  check('重置后起点更新', reset.since === new Date(clock).toISOString())
  const afterResetFile = readSpend(spendFile)
  check('重置把每个会话的当前花费拍成基线', near(afterResetFile.sessions.get('a'), costViewOf(stateOf(8000, 2)).cny))
  check('重置也把峰价口径拍成基线', afterResetFile.peaks.has('a') && near(afterResetFile.peaks.get('a'), costViewOf(stateOf(8000, 2)).cnyPeak))
  check('重置后峰价累计归零', reset.cnyPeak === 0, JSON.stringify(reset.cnyPeak))

  // ── 重置后继续累计 ───────────────────────────────────
  writeCache(cacheDir, 'a', stateOf(12000, 3))
  clock += 1000
  const third = await (await handler({ method: 'GET' })).json()
  const expected = costViewOf(stateOf(12000, 3)).cny - costViewOf(stateOf(8000, 2)).cny
  check('重置后新花费重新计数', near(third.cny, expected), `${third.cny} vs ${expected}`)
  check('起点没再变', third.since === new Date(clock - 1000).toISOString())

  // ── 结果缓存 ─────────────────────────────────────────
  const caching = createSpendHandler({ file: spendFile, dir: cacheDir, cacheMs: 60000, now: () => clock, logger: { warn() {} } })
  const baselineRead = await (await caching({ method: 'GET' })).json()
  writeCache(cacheDir, 'a', stateOf(16000, 4))
  const cached = await (await caching({ method: 'GET' })).json()
  check('cacheMs 内不重扫', cached.cny === baselineRead.cny, `${cached.cny} vs ${baselineRead.cny}`)
  clock += 60001
  const forced = await (await caching({ method: 'GET' })).json()
  const delta = costViewOf(stateOf(16000, 4)).cny - costViewOf(stateOf(12000, 3)).cny
  check('…过期后重扫', near(forced.cny, cached.cny + delta), `${forced.cny} vs ${cached.cny + delta}`)

  // ── 重置之后才创建的会话：基线必须是 0 ───────────────
  //
  // 设置页没开的时候，扫描只发生在再次打开页面的那一刻。如果这类会话按「首次看见时的花费」
  // 记基线，整段睡眠时间跑完的会话会被吞掉（2026-11-02 夜里就这样少算了 ~¥1.3）。
  const bornDir = path.join(tempRoot, 'born-sessions')
  fs.mkdirSync(bornDir)
  const bornFile = path.join(tempRoot, 'born.json')
  const T0 = Date.UTC(2026, 10, 2, 12, 0, 0)
  const bornCost = costViewOf(stateOf()).cny
  const oldCost = costViewOf(stateOf(8000, 2)).cny
  writeCache(bornDir, 'new', stateOf(), {}, T0 + 60_000)
  writeCache(bornDir, 'old', stateOf(8000, 2), {}, T0 - 60_000)
  fs.writeFileSync(bornFile, JSON.stringify({ version: 3, since: new Date(T0).toISOString(), sessions: {}, peaks: {} }))
  const bornHandler = createSpendHandler({ file: bornFile, dir: bornDir, cacheMs: 0, now: () => T0 + 3600_000, logger: { warn() {} } })
  const bornBody = await (await bornHandler({ method: 'GET' })).json()
  check('重置之后创建的会话整段计入', near(bornBody.cny, bornCost), `${bornBody.cny} vs ${bornCost}`)
  const bornSaved = readSpend(bornFile)
  check('…它的基线是 0', bornSaved.sessions.get('new') === 0, JSON.stringify([...bornSaved.sessions]))
  check('重置之前创建的会话仍按首次看见记基线', near(bornSaved.sessions.get('old'), oldCost), JSON.stringify([...bornSaved.sessions]))

  bornSaved.sessions.set('new', bornCost)
  bornSaved.peaks.set('new', bornCost)
  writeSpend(bornFile, bornSaved)
  const healed = await (await bornHandler({ method: 'GET' })).json()
  check('已被写脏的基线（>0）就地改回 0', near(healed.cny, bornCost) && readSpend(bornFile).sessions.get('new') === 0, `${healed.cny}`)

  // ── 损坏/旧形状的基线文件：重建 ──────────────────────
  fs.writeFileSync(spendFile, JSON.stringify({ baseline: 4.4, since: 'x' })) // 旧形状
  const fresh = createSpendHandler({ file: spendFile, dir: cacheDir, cacheMs: 0, now: () => clock, logger: { warn() {} } })
  const rebuilt = await (await fresh({ method: 'GET' })).json()
  check('旧形状基线被丢弃、按当前重建', rebuilt.ok === true && rebuilt.cny === 0, JSON.stringify(rebuilt))
  check('…重建后是新形状', readSpend(spendFile).sessions.size > 0)

  // ── 写失败不崩 ───────────────────────────────────────
  const broken = createSpendHandler({ file: path.join(tempRoot, 'nope', 'deep', 'spend.json'), dir: cacheDir, cacheMs: 0, now: () => clock, logger: { warn() {} } })
  const brokenRead = await (await broken({ method: 'GET' })).json()
  check('写失败时 GET 仍可读（只是没有基线）', brokenRead.ok === true && brokenRead.cny === 0)

  // ── v1 基线迁移 ─────────────────────────────────────
  //
  // v1 文件只有实际价基线。升级后必须按该会话「当前峰价 / 当前实际价」的比例补出峰价基线，
  // 而不是把旧基线当成峰价（那会把升级前的谷段折扣算进「已用配额」）。
  const legacyDir = path.join(tempRoot, 'legacy-sessions')
  fs.mkdirSync(legacyDir)
  writeCache(legacyDir, 'L', stateOf(8000, 2))
  const legacyFile = path.join(tempRoot, 'legacy.json')
  const half = costViewOf(stateOf(8000, 2))
  fs.writeFileSync(legacyFile, JSON.stringify({ version: 1, since: '2026-01-01T00:00:00.000Z', sessions: { L: half.cny / 2 } }))
  const legacy = createSpendHandler({ file: legacyFile, dir: legacyDir, cacheMs: 0, now: () => clock, logger: { warn() {} } })
  const legacyBody = await (await legacy({ method: 'GET' })).json()
  const migrated = readSpend(legacyFile)
  check('v1 基线补出峰价那一列', migrated !== null && migrated.peaks.has('L') && near(migrated.peaks.get('L'), half.cnyPeak / 2), JSON.stringify([...(migrated?.peaks ?? [])]))
  check('…起点不变', legacyBody.since === '2026-01-01T00:00:00.000Z', legacyBody.since)
  check('…峰价增量按补出的基线算', near(legacyBody.cnyPeak, half.cnyPeak - half.cny / 2), `${legacyBody.cnyPeak} vs ${half.cnyPeak - half.cny / 2}`)
  check('…写回时升级成 v3', JSON.parse(fs.readFileSync(legacyFile, 'utf8')).version === 3)

  // ── 月额度基线：重置时把网关的 monthly.percentUsed 记下来 ──
  //
  // 卡上的百分比 = 当前读数 − 这个基线，两个数都是 API 值，不做金额除法。
  const quotaHandler = createSpendHandler({ file: spendFile, dir: cacheDir, cacheMs: 0, now: () => clock + 5000, logger: { warn() {} } })
  const quotaReset = await (await quotaHandler({ method: 'POST', text: async () => JSON.stringify({ monthlyPercent: 87 }) })).json()
  const quotaFile = readSpend(spendFile)
  check('重置接受 body 里的 monthlyPercent', quotaReset.ok === true && quotaFile?.quota?.monthlyPercent === 87, JSON.stringify(quotaFile?.quota))
  check('没有 body 时基线为空、不编造', (await (await quotaHandler({ method: 'POST' })).json()).ok === true && readSpend(spendFile).quota.monthlyPercent === null)
  const captured = captureQuotaBaseline(spendFile, 62.5)
  check('lazily captured baseline is stored', captured?.monthlyPercent === 62.5 && readSpend(spendFile).quota.monthlyPercent === 62.5, JSON.stringify(captured))

  // ── 常量与往返 ───────────────────────────────────────
  check('路由常量', SPEND_ROUTE === '/api/clinepass.spend')
  check('writeSpend/readSpend 往返', (() => {
    const file = path.join(tempRoot, 'roundtrip.json')
    writeSpend(file, { since: '2026-11-02T00:00:00.000Z', sessions: new Map([['x', 1.5], ['y', 0]]), peaks: new Map([['x', 2.5], ['y', 0]]), quota: { monthlyPercent: 87, at: '2026-11-02T00:00:00.000Z' } })
    const back = readSpend(file)
    return back.since === '2026-11-02T00:00:00.000Z' && near(back.sessions.get('x'), 1.5) && back.sessions.get('y') === 0 && near(back.peaks.get('x'), 2.5) && back.quota.monthlyPercent === 87
  })())
} finally {
  fs.rmSync(tempRoot, { recursive: true, force: true })
}

// 默认路径跟随 DSH_HOME（用临时值，不碰真实目录）。
process.env.DSH_HOME = path.join(os.tmpdir(), 'clinepass-home-probe')
check('spendFileFor 跟随 DSH_HOME', spendFileFor() === path.join(process.env.DSH_HOME, 'dsh-clinepass-spend.json'), spendFileFor())

console.log(failures === 0 ? '\n全部通过' : `\n${failures} 项失败`)
process.exitCode = failures === 0 ? 0 : 1
