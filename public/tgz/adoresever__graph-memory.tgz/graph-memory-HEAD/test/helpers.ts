/**
 * graph-memory — 测试辅助
 *
 * By: adoresever
 * Email: Wywelljob@gmail.com
 *
 * 提供内存 SQLite 数据库，每个测试用例独立，互不干扰
 */

import { DatabaseSync, type DatabaseSyncInstance } from "../src/store/sqlite.ts";

/**
 * 创建内存数据库 + 完整 migration
 * 等价于 getDb() 但用 :memory: 不写磁盘
 */
export function createTestDb(): DatabaseSyncInstance {
  const db = new DatabaseSync(":memory:");
  db.exec("PRAGMA journal_mode = WAL");
  db.exec("PRAGMA foreign_keys = ON");

  // m1: 核心表
  db.exec(`
    CREATE TABLE IF NOT EXISTS gm_nodes (
      id              TEXT PRIMARY KEY,
      type            TEXT NOT NULL CHECK(type IN ('TASK','SKILL','EVENT')),
      name            TEXT NOT NULL,
      description     TEXT NOT NULL DEFAULT '',
      content         TEXT NOT NULL,
      temporal_json   TEXT NOT NULL DEFAULT '{}',
      status          TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','deprecated')),
      validated_count INTEGER NOT NULL DEFAULT 1,
      source_sessions TEXT NOT NULL DEFAULT '[]',
      community_id    TEXT,
      pagerank        REAL NOT NULL DEFAULT 0,
      created_at      INTEGER NOT NULL,
      updated_at      INTEGER NOT NULL
    );
    CREATE UNIQUE INDEX IF NOT EXISTS ux_gm_nodes_name ON gm_nodes(name);
    CREATE INDEX IF NOT EXISTS ix_gm_nodes_type_status ON gm_nodes(type, status);
    CREATE INDEX IF NOT EXISTS ix_gm_nodes_community ON gm_nodes(community_id);

    CREATE TABLE IF NOT EXISTS gm_edges (
      id          TEXT PRIMARY KEY,
      from_id     TEXT NOT NULL REFERENCES gm_nodes(id),
      to_id       TEXT NOT NULL REFERENCES gm_nodes(id),
      type        TEXT NOT NULL CHECK(type IN ('RELATES','SUPERSEDES','USED_SKILL','SOLVED_BY','REQUIRES','PATCHES','CONFLICTS_WITH')),
      instruction TEXT NOT NULL,
      condition   TEXT,
      session_id  TEXT NOT NULL,
      created_at  INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS ix_gm_edges_from ON gm_edges(from_id);
    CREATE INDEX IF NOT EXISTS ix_gm_edges_to   ON gm_edges(to_id);

    CREATE TABLE IF NOT EXISTS gm_node_revisions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      node_id TEXT NOT NULL REFERENCES gm_nodes(id) ON DELETE CASCADE,
      previous_description TEXT NOT NULL,
      previous_content TEXT NOT NULL,
      previous_temporal_json TEXT NOT NULL DEFAULT '{}',
      previous_validated_count INTEGER NOT NULL,
      previous_source_refs TEXT NOT NULL DEFAULT '[]',
      replacement_session_id TEXT NOT NULL,
      replaced_at INTEGER NOT NULL
    );
  `);

  // m2: 消息
  db.exec(`
    CREATE TABLE IF NOT EXISTS gm_messages (
      id          TEXT PRIMARY KEY,
      session_id  TEXT NOT NULL,
      turn_index  INTEGER NOT NULL,
      role        TEXT NOT NULL,
      content     TEXT NOT NULL,
      extracted   INTEGER NOT NULL DEFAULT 0,
      extraction_state TEXT NOT NULL DEFAULT 'pending'
        CHECK(extraction_state IN ('pending', 'succeeded', 'quarantined')),
      extraction_attempts INTEGER NOT NULL DEFAULT 0,
      extraction_error TEXT,
      extraction_next_retry_at INTEGER,
      extraction_updated_at INTEGER,
      created_at  INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS ix_gm_msg_session ON gm_messages(session_id, turn_index);
    CREATE INDEX IF NOT EXISTS ix_gm_msg_retention
      ON gm_messages(extracted, created_at, session_id, turn_index);
    CREATE INDEX IF NOT EXISTS ix_gm_msg_extraction_queue
      ON gm_messages(extraction_state, extraction_next_retry_at, session_id, turn_index);
    CREATE TABLE IF NOT EXISTS gm_extraction_sessions (
      session_id TEXT PRIMARY KEY,
      completed_turn INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );
  `);

  // m3: 信号
  db.exec(`
    CREATE TABLE IF NOT EXISTS gm_signals (
      id          TEXT PRIMARY KEY,
      session_id  TEXT NOT NULL,
      turn_index  INTEGER NOT NULL,
      type        TEXT NOT NULL,
      data        TEXT NOT NULL DEFAULT '{}',
      processed   INTEGER NOT NULL DEFAULT 0,
      created_at  INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS ix_gm_sig_session ON gm_signals(session_id, processed);
  `);

  // m4: FTS5
  try {
    db.exec(`
      CREATE VIRTUAL TABLE IF NOT EXISTS gm_nodes_fts USING fts5(
        name, description, content,
        content=gm_nodes, content_rowid=rowid
      );
      CREATE TRIGGER IF NOT EXISTS gm_nodes_ai AFTER INSERT ON gm_nodes BEGIN
        INSERT INTO gm_nodes_fts(rowid, name, description, content)
        VALUES (NEW.rowid, NEW.name, NEW.description, NEW.content);
      END;
      CREATE TRIGGER IF NOT EXISTS gm_nodes_ad AFTER DELETE ON gm_nodes BEGIN
        INSERT INTO gm_nodes_fts(gm_nodes_fts, rowid, name, description, content)
        VALUES ('delete', OLD.rowid, OLD.name, OLD.description, OLD.content);
      END;
      CREATE TRIGGER IF NOT EXISTS gm_nodes_au AFTER UPDATE ON gm_nodes BEGIN
        INSERT INTO gm_nodes_fts(gm_nodes_fts, rowid, name, description, content)
        VALUES ('delete', OLD.rowid, OLD.name, OLD.description, OLD.content);
        INSERT INTO gm_nodes_fts(rowid, name, description, content)
        VALUES (NEW.rowid, NEW.name, NEW.description, NEW.content);
      END;
    `);
  } catch { /* FTS5 不可用 */ }

  // m5: 向量
  db.exec(`
    CREATE TABLE IF NOT EXISTS gm_vectors (
      node_id      TEXT PRIMARY KEY REFERENCES gm_nodes(id),
      content_hash TEXT NOT NULL,
      embedding    BLOB NOT NULL
    );
  `);

  // m15: compact per-turn memory index and provenance
  db.exec(`
    CREATE TABLE IF NOT EXISTS gm_turn_memories (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      summary TEXT NOT NULL,
      outcome TEXT NOT NULL CHECK(outcome IN ('completed','partial','failed','informational','unknown')),
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS ix_gm_turn_memories_session
      ON gm_turn_memories(session_id, updated_at);
    CREATE TABLE IF NOT EXISTS gm_turn_memory_sources (
      memory_id TEXT NOT NULL REFERENCES gm_turn_memories(id) ON DELETE CASCADE,
      message_id TEXT NOT NULL REFERENCES gm_messages(id) ON DELETE CASCADE,
      turn_index INTEGER NOT NULL,
      source_order INTEGER NOT NULL,
      PRIMARY KEY (memory_id, message_id)
    );
    CREATE TABLE IF NOT EXISTS gm_turn_vectors (
      memory_id TEXT PRIMARY KEY REFERENCES gm_turn_memories(id) ON DELETE CASCADE,
      content_hash TEXT NOT NULL,
      embedding BLOB NOT NULL
    );
    CREATE TABLE IF NOT EXISTS gm_navigation_terms (
      id TEXT PRIMARY KEY,
      normalized TEXT NOT NULL UNIQUE,
      display_text TEXT NOT NULL,
      community_id TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS gm_navigation_triples (
      id TEXT PRIMARY KEY,
      memory_id TEXT NOT NULL REFERENCES gm_turn_memories(id) ON DELETE CASCADE,
      session_id TEXT NOT NULL,
      subject_id TEXT NOT NULL REFERENCES gm_navigation_terms(id),
      predicate TEXT NOT NULL,
      object_id TEXT NOT NULL REFERENCES gm_navigation_terms(id),
      created_at INTEGER NOT NULL,
      UNIQUE(memory_id, subject_id, predicate, object_id)
    );
  `);

  // m6: 社区摘要
  db.exec(`
    CREATE TABLE IF NOT EXISTS gm_communities (
      id               TEXT PRIMARY KEY,
      summary          TEXT NOT NULL,
      node_count       INTEGER NOT NULL DEFAULT 0,
      embedding        BLOB,
      member_signature TEXT,
      created_at       INTEGER NOT NULL,
      updated_at       INTEGER NOT NULL
    );
  `);

  // m9: graph node provenance
  db.exec(`
    CREATE TABLE IF NOT EXISTS gm_node_sources (
      node_id TEXT NOT NULL REFERENCES gm_nodes(id) ON DELETE CASCADE,
      session_id TEXT NOT NULL,
      message_id TEXT NOT NULL REFERENCES gm_messages(id) ON DELETE CASCADE,
      turn_index INTEGER NOT NULL,
      PRIMARY KEY (node_id, message_id)
    );
  `);

  return db;
}

/**
 * 快速插入测试节点
 */
export function insertNode(
  db: DatabaseSyncInstance,
  opts: {
    id?: string;
    type?: string;
    name: string;
    description?: string;
    content?: string;
    status?: string;
    validatedCount?: number;
    sessions?: string[];
  },
): string {
  const id = opts.id ?? `n-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  db.prepare(`
    INSERT INTO gm_nodes (id, type, name, description, content, status, validated_count, source_sessions, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    opts.type ?? "SKILL",
    opts.name,
    opts.description ?? `desc of ${opts.name}`,
    opts.content ?? `content of ${opts.name}`,
    opts.status ?? "active",
    opts.validatedCount ?? 1,
    JSON.stringify(opts.sessions ?? ["test-session"]),
    Date.now(),
    Date.now(),
  );
  return id;
}

/**
 * 快速插入测试边
 */
export function insertEdge(
  db: DatabaseSyncInstance,
  opts: {
    fromId: string;
    toId: string;
    type?: string;
    instruction?: string;
  },
): void {
  const id = `e-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  db.prepare(`
    INSERT INTO gm_edges (id, from_id, to_id, type, instruction, session_id, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    opts.fromId,
    opts.toId,
    opts.type ?? "USED_SKILL",
    opts.instruction ?? "test instruction",
    "test-session",
    Date.now(),
  );
}
