import { ObjectType, UnitData } from "@chronodivide/game-api";
import { LEXICON } from "./lexicon.js";

export type ObservationSource = "visible" | "last-seen";

export interface FogObservationApi {
  getCurrentTick(): number;
  getVisibleUnits(playerName: string, type: "self" | "hostile" | "enemy"): number[];
  getUnitData(unitId: number): UnitData | undefined;
}

export interface FogSafeContact {
  id: number;
  unitType: string;
  label: string;
  kind: string;
  position: { x: number; y: number };
  hpPct: number;
  observedAtTick: number;
  source: ObservationSource;
}

export interface FogSafeObservation {
  tick: number;
  ownUnits: FogSafeContact[];
  visibleEnemies: FogSafeContact[];
  lastSeenEnemies: FogSafeContact[];
  visibleNeutralObjects: FogSafeContact[];
}

export class FogSafetyError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "FogSafetyError";
  }
}

function readOrFail<T>(operation: string, read: () => T): T {
  try {
    return read();
  } catch (error) {
    if (error instanceof FogSafetyError) throw error;
    throw new FogSafetyError(`${operation} failed: ${String(error)}`);
  }
}

function visibleIds(game: FogObservationApi, selfName: string, type: "self" | "hostile" | "enemy"): Set<number> {
  const ids = readOrFail(`getVisibleUnits(${type})`, () => game.getVisibleUnits(selfName, type));
  if (!Array.isArray(ids) || ids.some((id) => !Number.isInteger(id))) {
    throw new FogSafetyError(`getVisibleUnits(${type}) returned invalid unit ids`);
  }
  return new Set(ids);
}

function contactFromUnit(unit: UnitData, source: ObservationSource, observedAtTick: number): FogSafeContact {
  const x = unit.tile?.rx;
  const y = unit.tile?.ry;
  if (!Number.isFinite(x) || !Number.isFinite(y)) {
    throw new FogSafetyError(`unit ${unit.id} has no usable visible position`);
  }
  if (!Number.isFinite(unit.hitPoints) || !Number.isFinite(unit.maxHitPoints) || unit.maxHitPoints <= 0) {
    throw new FogSafetyError(`unit ${unit.id} has no usable visible health`);
  }

  return {
    id: unit.id,
    unitType: unit.rules.name,
    label: LEXICON.get(unit.rules.name)?.label ?? unit.rules.name,
    kind: ObjectType[unit.type] ?? "Unknown",
    position: { x, y },
    hpPct: Math.round(Math.max(0, Math.min(100, (unit.hitPoints / unit.maxHitPoints) * 100))),
    observedAtTick,
    source,
  };
}

function readContact(game: FogObservationApi, id: number, source: ObservationSource, tick: number): FogSafeContact {
  const unit = readOrFail(`getUnitData(${id})`, () => game.getUnitData(id));
  if (!unit) throw new FogSafetyError(`getUnitData(${id}) returned no data for a visible unit`);
  try {
    return contactFromUnit(unit, source, tick);
  } catch (error) {
    if (error instanceof FogSafetyError) throw error;
    throw new FogSafetyError(`getUnitData(${id}) returned unsafe data: ${String(error)}`);
  }
}

function copyContact(contact: FogSafeContact, source: ObservationSource): FogSafeContact {
  return { ...contact, position: { ...contact.position }, source };
}

/**
 * Projects the current player's visible units, enemies, and neutral objects,
 * and retains enemy contacts without refreshing them while they are hidden.
 */
export class FogSafeProjector {
  private readonly lastSeen = new Map<number, FogSafeContact>();

  project(game: FogObservationApi, selfName: string): FogSafeObservation {
    const tick = readOrFail("getCurrentTick", () => game.getCurrentTick());
    const ownIds = visibleIds(game, selfName, "self");
    const hostileIds = visibleIds(game, selfName, "hostile");
    const enemyIds = visibleIds(game, selfName, "enemy");
    const missingFromHostile = [...enemyIds].filter((id) => !hostileIds.has(id));
    if (missingFromHostile.length > 0) {
      throw new FogSafetyError(
        `visible enemy ids are not a subset of visible hostile ids: ${missingFromHostile.join(",")}`,
      );
    }

    const ownContacts = [...ownIds]
      .sort((a, b) => a - b)
      .map((id) => readContact(game, id, "visible", tick));
    const visibleEnemyContacts = [...enemyIds]
      .sort((a, b) => a - b)
      .map((id) => readContact(game, id, "visible", tick));
    const visibleNeutralContacts = [...hostileIds]
      .filter((id) => !enemyIds.has(id))
      .sort((a, b) => a - b)
      .map((id) => readContact(game, id, "visible", tick));

    const nextLastSeen = new Map(this.lastSeen);
    for (const contact of visibleEnemyContacts) nextLastSeen.set(contact.id, copyContact(contact, "visible"));
    this.lastSeen.clear();
    for (const [id, contact] of nextLastSeen) this.lastSeen.set(id, contact);

    const lastSeenEnemies = [...this.lastSeen.entries()]
      .filter(([id]) => !enemyIds.has(id))
      .sort(([a], [b]) => a - b)
      .map(([, contact]) => copyContact(contact, "last-seen"));

    return {
      tick,
      ownUnits: ownContacts.map((contact) => copyContact(contact, "visible")),
      visibleEnemies: visibleEnemyContacts.map((contact) => copyContact(contact, "visible")),
      lastSeenEnemies,
      visibleNeutralObjects: visibleNeutralContacts.map((contact) => copyContact(contact, "visible")),
    };
  }
}

/**
 * Runs a product operation only after the fog projection and its subset check
 * succeed. A projection failure rejects before the callback can run.
 */
export async function withFogSafeObservation<T>(
  projector: FogSafeProjector,
  game: FogObservationApi,
  selfName: string,
  operation: (observation: FogSafeObservation) => T | Promise<T>,
): Promise<{ observation: FogSafeObservation; result: T }> {
  const observation = projector.project(game, selfName);
  return { observation, result: await operation(observation) };
}
