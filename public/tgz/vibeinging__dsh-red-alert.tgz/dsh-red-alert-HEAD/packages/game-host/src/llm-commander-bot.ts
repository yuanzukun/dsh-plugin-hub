import { Bot, GameApi, ApiEvent } from "@chronodivide/game-api";

/**
 * LLM 指挥官的 bot 壳：本身不做决策（决策在 host 主循环的 update 间隙），
 * 只负责捕获 GameApi 引用与雷达事件缓冲。
 */
export class LLMCommanderBot extends Bot {
  lastGameApi: GameApi | null = null;
  radarEvents: string[] = [];

  constructor(name: string, country: string) {
    super(name, country);
  }

  override onGameTick(game: GameApi): void {
    this.lastGameApi = game;
  }

  override onGameEvent(ev: ApiEvent, game: GameApi): void {
    // 事件类型名化，供快照 events 参考
    try {
      this.radarEvents.push(`t${game.getCurrentTick()} ${String((ev as any).type ?? "event")}`);
      if (this.radarEvents.length > 40) this.radarEvents.splice(0, this.radarEvents.length - 40);
    } catch {
      // 事件结构异常不影响对局
    }
  }

  /** 0.75 无公开 context getter，经 any 取 BotContext { game, player, logger } */
  playerApi(): any | null {
    return (this as any).context?.player ?? null;
  }
}
