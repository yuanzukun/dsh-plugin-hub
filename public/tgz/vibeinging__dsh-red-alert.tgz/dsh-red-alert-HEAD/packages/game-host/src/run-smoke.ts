import path from "node:path";
import { fileURLToPath } from "node:url";
import { cdapi, CreateOfflineOpts } from "@chronodivide/game-api";
import { NoopBot } from "./noop-bot.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MIX_DIR = path.resolve(HERE, "../../../assets");
const ARTIFACTS = path.resolve(HERE, "../../../artifacts");
const MAP = "simple-1v1-no-preview.map";

/** M0.3 烟测：验证独立项目内 init → createGame → update 循环 → saveReplay 全链路 */
async function main() {
  await cdapi.init(MIX_DIR);

  const gameSettings: CreateOfflineOpts = {
    buildOffAlly: false,
    cratesAppear: false,
    credits: 10000,
    gameMode: cdapi.getAvailableGameModes(MAP)[0],
    gameSpeed: 6,
    mapName: MAP,
    mcvRepacks: true,
    shortGame: true,
    superWeapons: false,
    unitCount: 0,
    online: false,
    agents: [new NoopBot("Red", "Russians"), new NoopBot("Blue", "Americans")],
  };

  const game = await cdapi.createGame(gameSettings);
  console.log("game created, tickRate =", game.getTickRate());

  const maxTicks = 2000;
  let ticks = 0;
  const startedAt = Date.now();
  while (!game.isFinished() && ticks < maxTicks) {
    await game.update();
    ticks++;
    if (ticks % 500 === 0) {
      console.log(`tick ${ticks} (${((Date.now() - startedAt) / 1000).toFixed(1)}s)`);
    }
  }

  console.log("finished:", game.isFinished(), "| ticks:", ticks, "| wall:", `${((Date.now() - startedAt) / 1000).toFixed(1)}s`);
  console.log("stats:", JSON.stringify(game.getPlayerStats()));
  const replay = game.saveReplay(ARTIFACTS);
  console.log("replay saved:", replay);
  game.dispose();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
