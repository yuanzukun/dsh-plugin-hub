/**
 * 单位字典层：rules.ini 内部名 → LLM 可读语义。
 * 语义标注基于 rules.ini 属性核对（cost/strength/speed/prereq），非记忆臆测。
 */

export interface LexEntry {
  name: string;
  label: string; // 中文语义
  kind: "building" | "infantry" | "vehicle" | "aircraft" | "neutral";
  cost: number;
  note?: string;
}

const ENTRIES: LexEntry[] = [
  // ── 苏军建筑（ prereq 链：NACNST→NAPOWR→NAREFN→NAHAND/NAWEAP→NARADR→NATECH ）
  { name: "NACNST", label: "建造基地(主基地)", kind: "building", cost: 3000, note: "MCV 展开而来，一切建造的根" },
  { name: "NAPOWR", label: "磁能电厂", kind: "building", cost: 600, note: "电力 +100，缺电全停" },
  { name: "NAREFN", label: "矿石精炼厂", kind: "building", cost: 2000, note: "矿石卸货点，附送 1 矿车" },
  { name: "NAHAND", label: "兵营", kind: "building", cost: 500, note: "步兵生产" },
  { name: "NAWEAP", label: "战车工厂", kind: "building", cost: 2000, note: "载具生产" },
  { name: "NARADR", label: "雷达", kind: "building", cost: 1000, note: "解锁高级单位，需持续供电" },
  { name: "NATECH", label: "作战实验室", kind: "building", cost: 2000, note: "解锁天启等顶级单位" },
  { name: "NADEPT", label: "维修厂", kind: "building", cost: 800, note: "维修载具，MCV 重pack 前置" },
  { name: "NASAM", label: "防空炮", kind: "building", cost: 600, note: "对空防御" },
  { name: "NALASR", label: "哨戒炮", kind: "building", cost: 600, note: "反步兵防御" },
  { name: "TESLA", label: "磁爆线圈", kind: "building", cost: 1000, note: "反装甲防御，耗电" },
  { name: "NAIRON", label: "铁幕装置", kind: "building", cost: 2500, note: "超武：无敌" },

  // ── 苏军步兵
  { name: "E2", label: "动员兵", kind: "infantry", cost: 100, note: "廉价炮灰" },
  { name: "DOG", label: "军犬", kind: "infantry", cost: 200, note: "反步兵/侦察" },
  { name: "FLAKT", label: "防空步兵", kind: "infantry", cost: 300 },
  { name: "SHK", label: "磁爆步兵", kind: "infantry", cost: 500, note: "反装甲" },
  { name: "ENGINEER", label: "工程师", kind: "infantry", cost: 500, note: "占领建筑/修桥" },
  { name: "DESO", label: "辐射工兵", kind: "infantry", cost: 600, note: "伊拉克特有，区域辐射" },
  { name: "IVAN", label: "疯狂伊万", kind: "infantry", cost: 600, note: "炸弹" },
  { name: "TERROR", label: "恐怖分子", kind: "infantry", cost: 200, note: "自爆" },

  // ── 苏军载具
  { name: "HTNK", label: "重型坦克(犀牛)", kind: "vehicle", cost: 900, note: "主战坦克，性价比核心" },
  { name: "LTNK", label: "轻型坦克", kind: "vehicle", cost: 600 },
  { name: "APOC", label: "天启坦克", kind: "vehicle", cost: 1750, note: "需实验室，陆战之王" },
  { name: "HTK", label: "防空履带车", kind: "vehicle", cost: 500, note: "对空 + 运兵" },
  { name: "DRON", label: "恐怖机器人", kind: "vehicle", cost: 500, note: "速袭矿车/步兵克星" },
  { name: "HARV", label: "武装采矿车", kind: "vehicle", cost: 1400, note: "经济命脉" },
  { name: "V3", label: "V3火箭车", kind: "vehicle", cost: 800, note: "远程攻城，需雷达" },
  { name: "SMCV", label: "苏军机动基地车", kind: "vehicle", cost: 3000, note: "展开为新基地" },

  // ── 盟军识别（敌情标注用）
  { name: "GACNST", label: "盟军基地", kind: "building", cost: 3000 },
  { name: "GAPOWR", label: "盟军电厂", kind: "building", cost: 800 },
  { name: "GAREFN", label: "盟军矿场", kind: "building", cost: 2000 },
  { name: "GAPILE", label: "盟军兵营", kind: "building", cost: 500 },
  { name: "GAWEAP", label: "盟军战车厂", kind: "building", cost: 2000 },
  { name: "MTNK", label: "盟军主战坦克(灰熊)", kind: "vehicle", cost: 700 },
  { name: "CMIN", label: "盟军时空矿车", kind: "vehicle", cost: 1400 },
  { name: "AMCV", label: "盟军机动基地车", kind: "vehicle", cost: 3000 },
  { name: "E1", label: "盟军大兵", kind: "infantry", cost: 200 },

  // ── 中立
  { name: "CAOIL", label: "油井", kind: "neutral", cost: 0, note: "占领得持续收入" },
];

export const LEXICON = new Map(ENTRIES.map((e) => [e.name, e]));

/** 注入 prompt 的紧凑字典文本 */
export function lexiconText(): string {
  return ENTRIES.map((e) => `${e.name}=${e.label}(${e.cost})${e.note ? " " + e.note : ""}`).join("\n");
}
