import { GameApi, ObjectType, OrderType, QueueType } from "@chronodivide/game-api";
import { LEXICON } from "./lexicon.js";

/**
 * 指令翻译器：LLM 高层 JSON 指令 → 引擎调用。
 *
 * 引擎约束（实测）：每个生产队列同一时刻只接受一项，生产中再排队会被静默吞掉。
 * 因此桥维护 pending 缓冲：build/train 指令先进缓冲，pumpQueues() 按引擎节奏逐项消费。
 * 单位指令以"单位类型"为编队（v1），LLM 不接触裸 unit id。
 */

export type Order =
  | { action: "build"; target: string; reason?: string }
  | { action: "train"; target: string; qty: number; reason?: string }
  | { action: "cancel"; target: string; qty: number; reason?: string }
  | { action: "attackMove"; units: string; x: number; y: number; reason?: string }
  | { action: "move"; units: string; x: number; y: number; reason?: string }
  | { action: "attackTarget"; units: string; contact: string; reason?: string }
  | { action: "retreat"; units: string; reason?: string }
  | { action: "deploy"; units: string; reason?: string };

export interface Receipt {
  ok: boolean;
  order: Order;
  detail: string;
}

const QUEUE_STATUS_READY = 3;
const MAX_PENDING_PER_QUEUE = 24;

/** 注入 prompt 的指令协议文本 */
export function orderProtocolText(): string {
  return `每轮输出一个 JSON 对象：{"orders":[{...},...],"assessment":"一句话战局判断","stance":"当前总方针"}
orders 数组每项（action 之一）：
- {"action":"build","target":"建筑内部名","reason":"..."}            申请建造（桥会按节奏排队+找位置放置，可连续申请多个）
- {"action":"train","target":"单位内部名","qty":N,"reason":"..."}    申请生产（桥按队列节奏消费，同名自动累计）
- {"action":"cancel","target":"内部名","qty":N}                      取消申请
- {"action":"attackMove","units":"内部名或ALL","x":N,"y":N}          攻击行军（沿途遇敌交战）
- {"action":"move","units":"...","x":N,"y":N}                        平移（不打仗）
- {"action":"attackTarget","units":"...","contact":"敌单位内部名"}    集火某类可见敌人
- {"action":"retreat","units":"..."}                                 撤回基地
- {"action":"deploy","units":"SMCV"}                                 展开基地车（通常无需，桥会自动展开）
规则：只输出 JSON；target/units 必须用字典内部名；坐标是格子坐标；局势平稳时 orders 可为空数组；已在态势[待建]/[待产]列表里的项目不要重复申请。`;
}

export class OrderTranslator {
  private pendingBuilds: string[] = [];
  private pendingUnits = new Map<QueueType, Map<string, number>>();

  constructor(
    private selfName: string,
    private actions: any, // ActionsApi
    private production: any, // ProductionApi
  ) {}

  /** Production API used by the fair snapshot builder without exposing queues. */
  productionApi(): any {
    return this.production;
  }

  /** LLM 可见的 pending 状态（进快照） */
  pendingSummary(): { builds: string[]; units: { queue: string; name: string; qty: number }[] } {
    const units: { queue: string; name: string; qty: number }[] = [];
    for (const [qt, m] of this.pendingUnits) for (const [name, qty] of m) units.push({ queue: QueueType[qt], name, qty });
    return { builds: [...this.pendingBuilds], units };
  }

  /** 基础执行器：MCV 展开 + Ready 建筑放置 + pending 消费（每 15 tick 调用） */
  pumpQueues(game: GameApi): string[] {
    const done: string[] = [...this.ensureMcvDeployed(game)];

    // 1. Ready → 放置（不放会卡死队列）
    const sq = this.queueData(QueueType.Structures);
    if (sq && sq.status === QUEUE_STATUS_READY && sq.items.length > 0) {
      const name = sq.items[0].rules.name;
      const spot = this.findPlacement(game, name);
      if (spot) {
        this.actions.placeBuilding(name, spot.x, spot.y);
        done.push(`placed ${name} @(${spot.x},${spot.y})`);
      }
      return done; // 放置帧不再排新项
    }

    // 2. 建筑队列空闲 → 消费 pendingBuilds（前置不满足时放回队头，不丢项）
    const idle = !sq || (sq.status === 0 && sq.items.length === 0);
    if (idle && this.pendingBuilds.length > 0) {
      const name = this.pendingBuilds[0];
      if (this.isAvailableNow(QueueType.Structures, name)) {
        this.pendingBuilds.shift();
        this.actions.queueForProduction(QueueType.Structures, name, ObjectType.Building, 1);
        done.push(`queued ${name}`);
      } else {
        done.push(`waiting ${name} (prereq)`);
      }
    }

    // 3. 单位队列空闲 → 消费 pendingUnits（同样预检，失败不丢项）
    for (const qt of [QueueType.Infantry, QueueType.Vehicles, QueueType.Aircrafts]) {
      const q = this.queueData(qt);
      const qIdle = !q || (q.status === 0 && q.items.length === 0);
      const pend = this.pendingUnits.get(qt);
      if (!qIdle || !pend || pend.size === 0) continue;
      const [name, qty] = [...pend.entries()][0];
      if (!this.isAvailableNow(qt, name)) {
        done.push(`waiting ${name} (${QueueType[qt]} prereq)`);
        continue;
      }
      pend.delete(name);
      this.actions.queueForProduction(qt, name, this.objectTypeFor(qt), qty);
      done.push(`queued ${name}×${qty} (${QueueType[qt]})`);
    }
    return done;
  }

  /** 引擎侧可用性预检：prereq 不满足时 queueForProduction 会被静默吞掉 */
  private isAvailableNow(qt: QueueType, name: string): boolean {
    try {
      const avail = this.production?.getAvailableObjects?.(qt) ?? [];
      return avail.some((r: any) => r.name === name);
    } catch {
      return false;
    }
  }

  private queueData(qt: QueueType): any {
    try {
      return this.production?.getQueueData?.(qt) ?? null;
    } catch {
      return null;
    }
  }

  /** 空闲 MCV 自动展开（没有基地一切排队都会被静默吞掉） */
  private ensureMcvDeployed(game: GameApi): string[] {
    const done: string[] = [];
    for (const id of game.getVisibleUnits(this.selfName, "self")) {
      const u = game.getUnitData(id);
      if (!u || u.rules.name !== "SMCV" || u.type !== ObjectType.Vehicle) continue;
      try {
        this.actions.orderUnits([id], OrderType.DeploySelected);
        done.push(`deployed SMCV #${id}`);
      } catch {
        // ignore
      }
    }
    return done;
  }

  /** 从基地质心螺旋向外找合法放置位 */
  private findPlacement(game: GameApi, name: string): { x: number; y: number } | null {
    const base = this.baseCenter(game);
    for (let r = 1; r <= 20; r++) {
      for (let dx = -r; dx <= r; dx++) {
        for (let dy = -r; dy <= r; dy++) {
          if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
          const x = base.x + dx;
          const y = base.y + dy;
          try {
            if (game.canPlaceBuilding(this.selfName, name, { rx: x, ry: y } as any)) return { x, y };
          } catch {
            // 越界等，跳过
          }
        }
      }
    }
    return null;
  }

  private baseCenter(game: GameApi): { x: number; y: number } {
    const own = game.getVisibleUnits(this.selfName, "self");
    const conys = own.map((id) => game.getUnitData(id)!).filter((u) => u && u.rules.name === "NACNST");
    if (conys.length > 0) {
      return {
        x: Math.round(conys.reduce((s, u) => s + u.tile.rx, 0) / conys.length),
        y: Math.round(conys.reduce((s, u) => s + u.tile.ry, 0) / conys.length),
      };
    }
    const me = game.getPlayerData(this.selfName);
    const start = me.startLocation as unknown as { x: number; y: number };
    return { x: start.x, y: start.y };
  }

  applyOrders(game: GameApi, orders: unknown[]): Receipt[] {
    if (!Array.isArray(orders)) return [];
    return orders.slice(0, 12).map((raw) => this.applyOne(game, raw));
  }

  private applyOne(game: GameApi, raw: unknown): Receipt {
    const o = raw as Order;
    const why = o.reason ? ` (${o.reason})` : "";
    if (!o || typeof (o as any).action !== "string") return { ok: false, order: o, detail: "非法指令结构" };
    try {
      switch (o.action) {
        case "build": {
          if (!LEXICON.has(o.target) || LEXICON.get(o.target)!.kind !== "building")
            return { ok: false, order: o, detail: `未知建筑 ${o.target}` };
          if (this.pendingBuilds.includes(o.target))
            return { ok: true, order: o, detail: `${o.target} 已在待建` };
          const sq = this.queueData(QueueType.Structures);
          const inFlight = sq?.items.some((it: any) => it.rules.name === o.target);
          if (inFlight) return { ok: true, order: o, detail: `${o.target} 已在建造` };
          if (this.pendingBuilds.length >= MAX_PENDING_PER_QUEUE)
            return { ok: false, order: o, detail: "待建队列已满" };
          this.pendingBuilds.push(o.target);
          return { ok: true, order: o, detail: `申请建造 ${o.target}${why}` };
        }
        case "train": {
          const qty = Math.max(1, Math.min(10, Math.floor(o.qty ?? 1)));
          const qt = this.queueTypeFor(o.target);
          if (qt == null) return { ok: false, order: o, detail: `无法确定 ${o.target} 的生产队列` };
          const m = this.pendingUnits.get(qt) ?? new Map<string, number>();
          const cur = m.get(o.target) ?? 0;
          if (cur + qty > MAX_PENDING_PER_QUEUE) return { ok: false, order: o, detail: "待产数量过多" };
          m.set(o.target, cur + qty);
          this.pendingUnits.set(qt, m);
          return { ok: true, order: o, detail: `申请生产 ${o.target}×${qty}（待产累计 ${cur + qty}）${why}` };
        }
        case "cancel": {
          const qty = Math.max(1, Math.min(10, Math.floor(o.qty ?? 1)));
          // 先从 pending 扣
          const qt = this.queueTypeFor(o.target) ?? (LEXICON.get(o.target)?.kind === "building" ? QueueType.Structures : null);
          if (qt === QueueType.Structures) {
            const i = this.pendingBuilds.indexOf(o.target);
            if (i >= 0) {
              this.pendingBuilds.splice(i, 1);
              return { ok: true, order: o, detail: `取消待建 ${o.target}` };
            }
          } else if (qt != null) {
            const m = this.pendingUnits.get(qt);
            if (m?.has(o.target)) {
              const cur = m.get(o.target)!;
              const left = cur - qty;
              if (left > 0) m.set(o.target, left);
              else m.delete(o.target);
              return { ok: true, order: o, detail: `取消待产 ${o.target}（余 ${Math.max(0, left)}）` };
            }
          }
          // 不在 pending 则尝试取消引擎队列
          if (qt != null) {
            this.actions.unqueueFromProduction(qt, o.target, this.objectTypeFor(qt), qty);
            return { ok: true, order: o, detail: `取消排队 ${o.target}×${qty}` };
          }
          return { ok: false, order: o, detail: `未知 ${o.target}` };
        }
        case "attackMove":
        case "move": {
          const ids = this.unitIdsByType(game, o.units);
          if (ids.length === 0) return { ok: false, order: o, detail: `没有 ${o.units} 单位` };
          this.actions.orderUnits(ids, o.action === "attackMove" ? OrderType.AttackMove : OrderType.Move, o.x, o.y);
          return { ok: true, order: o, detail: `${o.units}×${ids.length} ${o.action}→(${o.x},${o.y})${why}` };
        }
        case "attackTarget": {
          const ids = this.unitIdsByType(game, o.units);
          if (ids.length === 0) return { ok: false, order: o, detail: `没有 ${o.units} 单位` };
          const enemyId = game
            .getVisibleUnits(this.selfName, "enemy")
            .map((id) => game.getUnitData(id)!)
            .find((u) => u && u.rules.name === o.contact)?.id;
          if (enemyId == null) return { ok: false, order: o, detail: `看不见 ${o.contact}` };
          this.actions.orderUnits(ids, OrderType.Attack, enemyId);
          return { ok: true, order: o, detail: `${o.units}×${ids.length} 集火 ${o.contact}${why}` };
        }
        case "retreat": {
          const ids = this.unitIdsByType(game, o.units);
          if (ids.length === 0) return { ok: false, order: o, detail: `没有 ${o.units} 单位` };
          const base = this.baseCenter(game);
          this.actions.orderUnits(ids, OrderType.Move, base.x, base.y);
          return { ok: true, order: o, detail: `${o.units}×${ids.length} 撤回基地${why}` };
        }
        case "deploy": {
          const ids = this.unitIdsByType(game, o.units);
          if (ids.length === 0) return { ok: false, order: o, detail: `没有 ${o.units}` };
          this.actions.orderUnits(ids, OrderType.DeploySelected);
          return { ok: true, order: o, detail: `deploy ${o.units}×${ids.length}${why}` };
        }
        default:
          return { ok: false, order: o, detail: `未知 action ${(o as any).action}` };
      }
    } catch (err) {
      return { ok: false, order: o, detail: `执行异常: ${String(err).slice(0, 120)}` };
    }
  }

  private unitIdsByType(game: GameApi, typeName: string): number[] {
    return game
      .getVisibleUnits(this.selfName, "self")
      .map((id) => game.getUnitData(id)!)
      .filter((u) => {
        if (!u) return false;
        if (typeName === "ALL") return u.type === ObjectType.Vehicle || u.type === ObjectType.Infantry;
        return u.rules.name === typeName;
      })
      .filter((u) => u.type !== ObjectType.Building)
      .map((u) => u.id);
  }

  private queueTypeFor(name: string): QueueType | null {
    const e = LEXICON.get(name);
    if (!e) return null;
    if (e.kind === "infantry") return QueueType.Infantry;
    if (e.kind === "vehicle") return QueueType.Vehicles;
    if (e.kind === "aircraft") return QueueType.Aircrafts;
    if (e.kind === "building") return QueueType.Structures;
    return null;
  }

  private objectTypeFor(qt: QueueType): ObjectType {
    switch (qt) {
      case QueueType.Infantry:
        return ObjectType.Infantry;
      case QueueType.Vehicles:
        return ObjectType.Vehicle;
      case QueueType.Aircrafts:
        return ObjectType.Aircraft;
      default:
        return ObjectType.Building;
    }
  }
}
