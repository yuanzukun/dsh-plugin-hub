import { Bot, GameApi } from "@chronodivide/game-api";

/**
 * 什么都不做的 bot：烟测占位 / 被推演的靶子。
 * 记录最新 tick 与 GameApi 引用（0.75 无 GameInstanceApi.gameApi，从回调取是最稳路径）。
 */
export class NoopBot extends Bot {
  lastTick = -1;
  lastGameApi: GameApi | null = null;

  constructor(name: string, country: string) {
    super(name, country);
  }

  override onGameTick(game: GameApi): void {
    this.lastTick = game.getCurrentTick();
    this.lastGameApi = game;
  }
}
