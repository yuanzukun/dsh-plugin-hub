import path from "node:path";
import { fileURLToPath } from "node:url";
import { cdapi, CreateOfflineOpts, QueueType } from "@chronodivide/game-api";
import { LLMCommanderBot } from "./llm-commander-bot.js";
import { NoopBot } from "./noop-bot.js";
import { OrderTranslator } from "./orders.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MIX_DIR = path.resolve(HERE, "../../../assets");
const MAP = "simple-1v1-no-preview.map";
const RED = "RedCommander";

/** 调试建造链：排一个电厂，观察队列状态与放置尝试全过程 */
async function main() {
  await cdapi.init(MIX_DIR);
  const red = new LLMCommanderBot(RED, "Russians");
  const game = await cdapi.createGame({
    buildOffAlly: false,
    cratesAppear: false,
    credits: 10000,
    gameMode: cdapi.getAvailableGameModes(MAP)[0],
    gameSpeed: 6,
    mapName: MAP,
    mcvRepacks: true,
    shortGame: true,
    superWeapons: false,
    unitCount: 0,
    online: false,
    agents: [red, new NoopBot("BlueCommander", "Russians")],
  } as CreateOfflineOpts);

  let translator: OrderTranslator | null = null;
  let queued = false;
  let ticks = 0;
  const maxTicks = 900;

  while (!game.isFinished() && ticks < maxTicks) {
    await game.update();
    ticks++;
    const api = red.lastGameApi;
    if (!api) continue;
    if (!translator) {
      const p = red.playerApi();
      if (p?.actions) translator = new OrderTranslator(RED, p.actions, p.production);
    }
    if (!translator) continue;

    // 开局：t30 展开 MCV
    if (ticks === 30) translator.pumpQueues(api);
    // t120 排队电厂
    if (ticks === 120 && !queued) {
      translator.applyOrders(api, [{ action: "build", target: "NAPOWR" }]);
      queued = true;
    }
    // 每 60 tick 打印队列 + 放置尝试
    if (ticks % 60 === 0) {
      const q = (red.playerApi()?.production?.getQueueData)?.(QueueType.Structures);
      const qs = q ? `status=${["Idle","Active","OnHold","Ready"][q.status]} items=[${q.items.map((i: any) => i.rules.name + "x" + i.quantity)}]` : "no-queue";
      const placed = translator.pumpQueues(api);
      const bld = api.getVisibleUnits(RED, "self").map((id) => api.getUnitData(id)!).filter((u) => u?.type === 2).map((u) => u.rules.name);
      console.log(`t${ticks} queue: ${qs} | placedNow: [${placed}] | buildings: [${bld}]`);
    }
  }
  game.dispose();
}

main().catch((e) => { console.error(e); process.exit(1); });
