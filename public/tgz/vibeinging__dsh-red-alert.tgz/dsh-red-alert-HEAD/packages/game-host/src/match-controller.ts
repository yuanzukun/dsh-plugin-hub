import { mkdir, mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { randomUUID } from "node:crypto";
import {
  cdapi,
  CreateOfflineOpts,
  GameApi,
  GameInstanceApi,
  type Size,
} from "@chronodivide/game-api";
import { SupalosaBot } from "@supalosa/chronodivide-bot/dist/bot/bot.js";
import { FogSafeContact, FogSafeObservation, FogSafeProjector } from "./fog-safe-observation.js";
import { LLMCommanderBot } from "./llm-commander-bot.js";
import { NoopBot } from "./noop-bot.js";
import { OrderTranslator, Receipt } from "./orders.js";
import { Snapshot, buildSnapshot } from "./snapshot.js";

const RED_PLAYER = "RedCommander";
const SOVIET_COUNTRIES = ["Russians", "Arabs", "Africans", "Confederation"];

let initializedAssetsDir: string | undefined;
let initialization: Promise<void> | undefined;

/** Identity carried by a DSH tool call and checked as a pair. */
export interface MatchOwner {
  readonly agentId: string;
  readonly sessionId: string;
}

/** User-selectable offline engine settings. */
export interface StartMatchRequest {
  readonly map: string;
  readonly myCountry: string;
  readonly opponents: number;
  readonly opponentType: "noop" | "supalosa";
  readonly decisionPeriod: number;
  readonly maxTicks: number;
}

/** Product-safe result returned by every match operation. */
export interface MatchView {
  readonly matchId: string;
  readonly map: string;
  readonly mapSize: {
    readonly width: number;
    readonly height: number;
  };
  readonly myCountry: string;
  readonly status: "active" | "finished" | "stopped";
  readonly tick: number;
  readonly cycle: number;
  readonly view: {
    readonly mode: "offline";
    readonly realUiAvailable: false;
  };
  readonly observation: FogSafeObservation;
  readonly facts: {
    readonly gameTimeSec: number;
    readonly phase: Snapshot["phase"];
    readonly self: Snapshot["self"];
    readonly visibleEnemyGroups: number;
    readonly lastSeenEnemyGroups: number;
    readonly visibleNeutralGroups: number;
  };
  readonly receipts: readonly Receipt[];
  readonly placements: readonly string[];
  readonly replaySaved: boolean;
  readonly replayPath?: string;
}

/** Result of applying a command batch and moving to the next decision point. */
export interface ActMatchResult extends MatchView {
  readonly advanced: true;
}

/** A failed match request is safe to expose to the tool result. */
export class MatchControllerError extends Error {
  readonly code = "RED_ALERT_MATCH";
}

interface MatchRecord {
  readonly matchId: string;
  readonly owner: MatchOwner;
  readonly map: string;
  readonly mapSize: {
    readonly width: number;
    readonly height: number;
  };
  readonly myCountry: string;
  readonly game: GameInstanceApi;
  readonly redBot: LLMCommanderBot;
  readonly translator: OrderTranslator;
  readonly projector: FogSafeProjector;
  readonly replayDir: string;
  readonly decisionPeriod: number;
  readonly maxTicks: number;
  status: "active" | "finished" | "stopped";
  cycle: number;
  observation: FogSafeObservation;
  snapshot: Snapshot;
  previousOwnIds: Set<number>;
  previousEnemyTypes: Set<string>;
  replayPath: string | undefined;
  operation: Promise<unknown> | undefined;
}

function throwIfAborted(signal: AbortSignal): void {
  if (!signal.aborted) return;
  const error = signal.reason instanceof Error ? signal.reason : new Error("red-alert operation aborted");
  error.name = "AbortError";
  throw error;
}

function requirePositiveInteger(name: string, value: number, max: number): number {
  if (!Number.isSafeInteger(value) || value < 1 || value > max) {
    throw new MatchControllerError(`${name} must be an integer between 1 and ${max}`);
  }
  return value;
}

function normalizeMapSize(size: Size): { readonly width: number; readonly height: number } {
  if (!Number.isFinite(size.width) || !Number.isFinite(size.height) || size.width <= 0 || size.height <= 0) {
    throw new MatchControllerError("Chrono Divide returned an invalid public map size");
  }
  return { width: size.width, height: size.height };
}

async function initializeEngine(assetsDir: string, signal: AbortSignal): Promise<void> {
  throwIfAborted(signal);
  if (initializedAssetsDir !== undefined && initializedAssetsDir !== assetsDir) {
    throw new MatchControllerError("Chrono Divide is already initialized with another assetsDir");
  }
  if (initialization === undefined) {
    initializedAssetsDir = assetsDir;
    initialization = cdapi.init(assetsDir).catch((error: unknown) => {
      initializedAssetsDir = undefined;
      initialization = undefined;
      throw error;
    });
  }
  await initialization;
  throwIfAborted(signal);
}

function sameIds(left: readonly number[], right: ReadonlySet<number>): boolean {
  return left.length === right.size && left.every((id) => right.has(id));
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isFogSafeContact(value: unknown): value is FogSafeContact {
  if (!isRecord(value) || !Number.isSafeInteger(value.id) || typeof value.unitType !== "string" || typeof value.label !== "string" || typeof value.kind !== "string") return false;
  if (value.source !== "visible" && value.source !== "last-seen") return false;
  if (!Number.isSafeInteger(value.observedAtTick) || !Number.isFinite(value.hpPct) || !isRecord(value.position)) return false;
  return Number.isFinite(value.position.x) && Number.isFinite(value.position.y);
}

function isFogSafeObservation(value: unknown): value is FogSafeObservation {
  if (!isRecord(value) || !Number.isSafeInteger(value.tick)) return false;
  return [value.ownUnits, value.visibleEnemies, value.lastSeenEnemies, value.visibleNeutralObjects].every(
    (contacts) => Array.isArray(contacts) && contacts.every(isFogSafeContact),
  );
}

function contactKey(contact: FogSafeContact): string {
  return [
    contact.id,
    contact.unitType,
    contact.label,
    contact.kind,
    contact.position.x,
    contact.position.y,
    contact.hpPct,
    contact.observedAtTick,
    contact.source,
  ].join("|");
}

function sameContacts(left: readonly FogSafeContact[], right: readonly FogSafeContact[]): boolean {
  return left.length === right.length && left.every((contact, index) => contactKey(contact) === contactKey(right[index]));
}

function sameObservation(left: FogSafeObservation, right: FogSafeObservation): boolean {
  return left.tick === right.tick
    && sameContacts(left.ownUnits, right.ownUnits)
    && sameContacts(left.visibleEnemies, right.visibleEnemies)
    && sameContacts(left.lastSeenEnemies, right.lastSeenEnemies)
    && sameContacts(left.visibleNeutralObjects, right.visibleNeutralObjects);
}

/**
 * Owns the offline engine lifecycle for DSH sessions.
 *
 * The controller deliberately receives only an owner identity from the DSH
 * adapter. It never treats a match id as an authorization token.
 */
export class MatchController {
  private readonly records = new Map<string, MatchRecord>();
  private readonly activeBySession = new Map<string, string>();
  private readonly sessionTails = new Map<string, Promise<void>>();
  private disposed = false;

  constructor(private readonly assetsDir: string) {}

  /** Start one offline match and advance it to its first fair observation. */
  async start(owner: MatchOwner, request: StartMatchRequest, signal: AbortSignal): Promise<MatchView> {
    return this.serialize(owner.sessionId, signal, async () => {
      if (this.disposed) throw new MatchControllerError("red-alert plugin is disposed");
      throwIfAborted(signal);
      if (this.activeBySession.has(owner.sessionId)) {
        throw new MatchControllerError("this Agent session already owns an active match");
      }
      const settings = this.resolveRequest(request);
      await initializeEngine(this.assetsDir, signal);
      const gameMode = cdapi.getAvailableGameModes(settings.map)[0];
      if (gameMode === undefined) {
        throw new MatchControllerError(`map ${settings.map} is not available in assetsDir`);
      }

      const redBot = new LLMCommanderBot(RED_PLAYER, settings.myCountry);
      const agents = [redBot, ...this.createOpponents(settings)];
      const gameSettings: CreateOfflineOpts = {
        buildOffAlly: false,
        cratesAppear: false,
        credits: 10000,
        gameMode,
        gameSpeed: 6,
        mapName: settings.map,
        mcvRepacks: true,
        shortGame: true,
        superWeapons: false,
        unitCount: 0,
        online: false,
        agents,
      };

      let game: GameInstanceApi | undefined;
      let replayDir: string | undefined;
      try {
        game = await cdapi.createGame(gameSettings);
        replayDir = await mkdtemp(path.join(tmpdir(), "dsh-red-alert-match-"));
        await this.advanceGame(game, redBot, 1, signal);
        const playerApi = redBot.playerApi();
        if (playerApi === null || typeof playerApi !== "object") {
          throw new MatchControllerError("red commander player APIs are unavailable");
        }
        const gameApi = redBot.lastGameApi;
        if (gameApi === null) throw new MatchControllerError("red commander GameApi is unavailable");
        const mapSize = normalizeMapSize(gameApi.map.getRealMapSize());
        const translator = new OrderTranslator(RED_PLAYER, playerApi.actions, playerApi.production);
        const projector = new FogSafeProjector();
        const record: MatchRecord = {
          matchId: randomUUID(),
          owner: { agentId: owner.agentId, sessionId: owner.sessionId },
          map: settings.map,
          mapSize,
          myCountry: settings.myCountry,
          game,
          redBot,
          translator,
          projector,
          replayDir,
          decisionPeriod: settings.decisionPeriod,
          maxTicks: settings.maxTicks,
          status: "active",
          cycle: 0,
          observation: undefined as unknown as FogSafeObservation,
          snapshot: undefined as unknown as Snapshot,
          previousOwnIds: new Set<number>(),
          previousEnemyTypes: new Set<string>(),
          replayPath: undefined,
          operation: undefined,
        };
        this.refresh(record, projector.project(gameApi, RED_PLAYER));
        this.records.set(record.matchId, record);
        this.activeBySession.set(owner.sessionId, record.matchId);
        this.updateFinishedState(record);
        return this.view(record, [], []);
      } catch (error) {
        game?.dispose();
        if (replayDir !== undefined) await rm(replayDir, { recursive: true, force: true });
        if (error instanceof MatchControllerError) throw error;
        throw new MatchControllerError(`failed to create offline match: ${String(error).slice(0, 240)}`);
      }
    });
  }

  /** Apply commands, then advance exactly one bounded decision window. */
  async act(owner: MatchOwner, matchId: string, orders: readonly unknown[], signal: AbortSignal): Promise<ActMatchResult> {
    return this.serialize(owner.sessionId, signal, async () => {
      const record = this.requireOwned(owner, matchId);
      if (record.status !== "active") throw new MatchControllerError(`match ${matchId} is ${record.status}`);
      throwIfAborted(signal);
      const api = this.currentApi(record);
      const receipts = record.translator.applyOrders(api, [...orders]);
      const placements = await this.advanceRecord(record, signal);
      return { ...this.view(record, receipts, placements), advanced: true as const };
    });
  }

  /** Return the last committed observation without advancing the engine. */
  async status(owner: MatchOwner, matchId: string, signal: AbortSignal): Promise<MatchView> {
    return this.serialize(owner.sessionId, signal, async () => {
      throwIfAborted(signal);
      return this.view(this.requireOwned(owner, matchId), [], []);
    });
  }

  /** Save and close one match; a repeated stop is intentionally idempotent. */
  async stop(owner: MatchOwner, matchId: string, signal: AbortSignal): Promise<MatchView> {
    return this.serialize(owner.sessionId, signal, async () => {
      throwIfAborted(signal);
      const record = this.requireOwned(owner, matchId);
      if (record.status !== "stopped") await this.closeRecord(record);
      return this.view(record, [], []);
    });
  }

  /** Stop all matches owned by one exact Agent/session pair after prior session work settles. */
  async stopOwner(owner: MatchOwner): Promise<void> {
    await this.serialize(owner.sessionId, new AbortController().signal, async () => {
      const records = [...this.records.values()].filter((record) =>
        record.owner.agentId === owner.agentId && record.owner.sessionId === owner.sessionId,
      );
      for (const record of records) await this.closeRecord(record);
    });
  }

  /** Stop every owned match before the plugin fiber is released, preserving cleanup failures. */
  async dispose(): Promise<void> {
    this.disposed = true;
    await Promise.all([...this.sessionTails.values()]);
    for (const record of this.records.values()) await this.closeRecord(record);
  }

  /** Snapshot the owned relationships for the package invariant companion. */
  assertInvariants(fail: (message: string) => never): void {
    for (const record of this.records.values()) {
      if (record.status === "active") {
        if (record.owner.agentId.length === 0 || record.owner.sessionId.length === 0) {
          fail(`active match ${record.matchId} has an incomplete Agent/session owner`);
        }
        if (this.activeBySession.get(record.owner.sessionId) !== record.matchId) {
          fail(`active match ${record.matchId} is not indexed by its owner session`);
        }
        this.assertFairOutput(record, fail);
      } else if (this.activeBySession.get(record.owner.sessionId) === record.matchId) {
        fail(`non-active match ${record.matchId} remains in the active session index`);
      }
    }
    for (const [sessionId, matchId] of this.activeBySession) {
      const record = this.records.get(matchId);
      if (record === undefined || record.status !== "active" || record.owner.sessionId !== sessionId) {
        fail(`active session index points to an invalid match ${matchId}`);
      }
    }
  }

  /** Validate the exact fair observation materialized in a successful tool result. */
  assertToolOutput(value: unknown, fail: (message: string) => never): void {
    if (!isRecord(value) || typeof value.matchId !== "string" || !isFogSafeObservation(value.observation)) {
      fail("red-alert tool output does not contain a valid FogSafeObservation");
    }
    const record = this.records.get(value.matchId);
    if (record === undefined) fail(`red-alert tool output references unknown match ${value.matchId}`);
    if (!sameObservation(value.observation, record.observation)) {
      fail(`red-alert tool output observation does not match committed match state ${value.matchId}`);
    }
    if (record.status === "active" || record.status === "finished") this.assertFairOutput(record, fail);
  }

  private resolveRequest(request: StartMatchRequest): StartMatchRequest {
    if (request.map.trim() !== request.map || request.map.length === 0) {
      throw new MatchControllerError("map must be a non-empty name without surrounding whitespace");
    }
    if (request.myCountry.trim() !== request.myCountry || request.myCountry.length === 0) {
      throw new MatchControllerError("myCountry must be a non-empty country name without surrounding whitespace");
    }
    if (request.opponentType !== "noop" && request.opponentType !== "supalosa") {
      throw new MatchControllerError("opponentType must be noop or supalosa");
    }
    return {
      map: request.map,
      myCountry: request.myCountry,
      opponents: requirePositiveInteger("opponents", request.opponents, 3),
      opponentType: request.opponentType,
      decisionPeriod: requirePositiveInteger("decisionPeriod", request.decisionPeriod, 120),
      maxTicks: requirePositiveInteger("maxTicks", request.maxTicks, 10_000),
    };
  }

  private createOpponents(settings: StartMatchRequest): NoopBot[] | SupalosaBot[] {
    return Array.from({ length: settings.opponents }, (_, index) => {
      const name = `BlueCommander${index + 1}`;
      const country = SOVIET_COUNTRIES[index % SOVIET_COUNTRIES.length];
      if (settings.opponentType === "noop") return new NoopBot(name, country);
      return new SupalosaBot(name, country as never, [RED_PLAYER], false);
    }) as NoopBot[] | SupalosaBot[];
  }

  private async advanceGame(
    game: GameInstanceApi,
    redBot: LLMCommanderBot,
    steps: number,
    signal: AbortSignal,
  ): Promise<void> {
    for (let index = 0; index < steps; index++) {
      throwIfAborted(signal);
      await game.update();
    }
    throwIfAborted(signal);
    if (redBot.lastGameApi === null) throw new MatchControllerError("red commander did not receive a GameApi observation");
  }

  private async advanceRecord(record: MatchRecord, signal: AbortSignal): Promise<string[]> {
    const placements: string[] = [];
    const steps = Math.min(record.decisionPeriod, Math.max(0, record.maxTicks - record.game.getCurrentTick()));
    for (let index = 0; index < steps && !record.game.isFinished(); index++) {
      throwIfAborted(signal);
      await record.game.update();
      if (index % 15 === 0) placements.push(...record.translator.pumpQueues(this.currentApi(record)));
    }
    throwIfAborted(signal);
    this.refresh(record, record.projector.project(this.currentApi(record), RED_PLAYER));
    record.cycle += 1;
    this.updateFinishedState(record);
    return placements;
  }

  private refresh(record: MatchRecord, observation: FogSafeObservation): void {
    const api = this.currentApi(record);
    const snapshot = buildSnapshot(
      api,
      RED_PLAYER,
      record.translator.productionApi(),
      record.previousOwnIds,
      record.previousEnemyTypes,
      record.translator.pendingSummary(),
      observation,
    );
    record.observation = observation;
    record.snapshot = snapshot;
    record.previousOwnIds = new Set(api.getVisibleUnits(RED_PLAYER, "self"));
    record.previousEnemyTypes = new Set(snapshot.enemyContacts.map((group) => group.unitType));
  }

  private currentApi(record: MatchRecord): GameApi {
    const api = record.redBot.lastGameApi;
    if (api === null) throw new MatchControllerError("red commander GameApi is unavailable");
    return api;
  }

  private updateFinishedState(record: MatchRecord): void {
    if (!record.game.isFinished() && record.game.getCurrentTick() < record.maxTicks) return;
    record.status = "finished";
    if (this.activeBySession.get(record.owner.sessionId) === record.matchId) {
      this.activeBySession.delete(record.owner.sessionId);
    }
  }

  private requireOwned(owner: MatchOwner, matchId: string): MatchRecord {
    const record = this.records.get(matchId);
    if (record === undefined) throw new MatchControllerError(`unknown matchId ${matchId}`);
    if (record.owner.agentId !== owner.agentId || record.owner.sessionId !== owner.sessionId) {
      throw new MatchControllerError(`matchId ${matchId} is not owned by this Agent session`);
    }
    return record;
  }

  private async closeRecord(record: MatchRecord): Promise<void> {
    if (record.status === "stopped") return;
    try {
      await mkdir(record.replayDir, { recursive: true });
      record.replayPath = record.game.saveReplay(record.replayDir);
    } finally {
      record.game.dispose();
      record.status = "stopped";
      if (this.activeBySession.get(record.owner.sessionId) === record.matchId) {
        this.activeBySession.delete(record.owner.sessionId);
      }
    }
  }

  private assertFairOutput(record: MatchRecord, fail: (message: string) => never): void {
    this.assertFairObservation(record, record.observation, fail);
    if (record.snapshot.enemyContacts.some((group) => group.source !== "visible")) {
      fail(`match ${record.matchId} snapshot enemy groups lost visible source metadata`);
    }
  }

  private assertFairObservation(record: MatchRecord, observation: FogSafeObservation, fail: (message: string) => never): void {
    const api = this.currentApi(record);
    const hostile = api.getVisibleUnits(RED_PLAYER, "hostile");
    const enemy = api.getVisibleUnits(RED_PLAYER, "enemy");
    const own = api.getVisibleUnits(RED_PLAYER, "self");
    const hostileSet = new Set(hostile);
    const enemySet = new Set(enemy);
    if (!sameIds(observation.ownUnits.map((contact) => contact.id), new Set(own))) {
      fail(`match ${record.matchId} output own units do not match the current self API`);
    }
    if (observation.ownUnits.some((contact) => contact.source !== "visible")) {
      fail(`match ${record.matchId} marked an own unit as non-visible`);
    }
    if (enemy.some((id) => !hostileSet.has(id))) fail(`match ${record.matchId} exposed an enemy outside hostile visibility`);
    if (!sameIds(observation.visibleEnemies.map((contact) => contact.id), enemySet)) {
      fail(`match ${record.matchId} output visible enemies do not match the current enemy API`);
    }
    const neutral = hostile.filter((id) => !enemySet.has(id));
    if (!sameIds(observation.visibleNeutralObjects.map((contact) => contact.id), new Set(neutral))) {
      fail(`match ${record.matchId} output neutrals are not hostile minus enemy`);
    }
    if (observation.lastSeenEnemies.some((contact) => enemySet.has(contact.id))) {
      fail(`match ${record.matchId} marked a currently visible enemy as last-seen`);
    }
  }

  private async serialize<T>(sessionId: string, signal: AbortSignal, operation: () => Promise<T>): Promise<T> {
    const previous = this.sessionTails.get(sessionId) ?? Promise.resolve();
    let current: Promise<T>;
    current = previous.catch(() => undefined).then(operation);
    const tail = current.then(() => undefined, () => undefined);
    this.sessionTails.set(sessionId, tail);
    try {
      return await current;
    } finally {
      if (this.sessionTails.get(sessionId) === tail) this.sessionTails.delete(sessionId);
    }
  }

  private view(record: MatchRecord, receipts: readonly Receipt[], placements: readonly string[]): MatchView {
    return {
      matchId: record.matchId,
      map: record.map,
      mapSize: record.mapSize,
      myCountry: record.myCountry,
      status: record.status,
      tick: record.observation.tick,
      cycle: record.cycle,
      view: { mode: "offline", realUiAvailable: false },
      observation: record.observation,
      facts: {
        gameTimeSec: record.snapshot.gameTimeSec,
        phase: record.snapshot.phase,
        self: record.snapshot.self,
        visibleEnemyGroups: record.snapshot.enemyContacts.length,
        lastSeenEnemyGroups: record.snapshot.lastSeenEnemyContacts.length,
        visibleNeutralGroups: record.snapshot.visibleNeutralObjects.length,
      },
      receipts,
      placements,
      replaySaved: record.replayPath !== undefined,
      ...(record.replayPath === undefined ? {} : { replayPath: record.replayPath }),
    };
  }
}
