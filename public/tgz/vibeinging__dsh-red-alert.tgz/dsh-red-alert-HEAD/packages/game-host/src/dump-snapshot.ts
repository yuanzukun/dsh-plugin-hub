import path from "node:path";
import { fileURLToPath } from "node:url";
import { writeFileSync } from "node:fs";
import {
  cdapi,
  CreateOfflineOpts,
  GameApi,
  GameInstanceApi,
  ObjectType,
  QueueType,
  UnitData,
} from "@chronodivide/game-api";
import { SupalosaBot } from "@supalosa/chronodivide-bot/dist/bot/bot.js";
import { Countries } from "@supalosa/chronodivide-bot/dist/bot/logic/common/utils.js";
import { NoopBot } from "./noop-bot.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MIX_DIR = path.resolve(HERE, "../../../assets");
const ARTIFACTS = path.resolve(HERE, "../../../artifacts");
const MAP = "simple-1v1-no-preview.map";

/** 采样点：开局基建 / 经济成型 / 中期出兵 / 首次接敌 / 集团推进 / 终局 */
const SAMPLE_TICKS = [150, 450, 900, 1500, 2400, 3600];

const RED = "RedCommander";
const BLUE = "BlueDummy";

function slimUnit(game: GameApi, id: number, visibleTo: string) {
  const u = game.getUnitData(id);
  if (!u) return null;
  return {
    id,
    name: u.rules.name,
    owner: u.owner,
    kind: ObjectType[u.type],
    tile: { x: u.tile.rx, y: u.tile.ry },
    hp: u.hitPoints,
    maxHp: u.maxHitPoints,
    hpPct: Math.round((u.hitPoints / u.maxHitPoints) * 100),
    veteran: u.veteranLevel,
    attackState: u.attackState,
    value: u.purchaseValue,
    visibleTo,
  };
}

function dumpAt(game: GameApi, commanderBot: SupalosaBot) {
  const tick = game.getCurrentTick();
  const players = game.getPlayers().map((name) => {
    const d = game.getPlayerData(name);
    return {
      name,
      side: d.country?.side,
      country: d.country?.name,
      credits: Math.floor(d.credits),
      power: d.power,
      defeated: game.isPlayerDefeated(name),
      startLocation: d.startLocation,
    };
  });

  const own = game
    .getVisibleUnits(RED, "self")
    .map((id) => slimUnit(game, id, RED))
    .filter(Boolean);
  const enemy = game
    .getVisibleUnits(RED, "enemy")
    .map((id) => slimUnit(game, id, RED))
    .filter(Boolean);
  const neutral = game
    .getNeutralUnits()
    .map((id) => slimUnit(game, id, "neutral"))
    .filter(Boolean);

  // 生产队列：经 bot 的 PlayerApi 读取（GameApi 无直接队列查询）
  const production: Record<string, unknown> = {};
  const playerApi = (commanderBot as unknown as { context?: { player?: { production?: any } } }).context?.player;
  if (playerApi?.production) {
    for (const qt of Object.values(QueueType).filter((v) => typeof v === "number") as QueueType[]) {
      const q = playerApi.production.getQueueData(qt);
      if (q && (q.items.length > 0 || q.status !== 0)) {
        production[QueueType[qt]] = {
          status: QueueStatusName(q.status),
          items: q.items.map((it: any) => ({ name: it.rules.name, qty: it.quantity })),
        };
      }
    }
  }

  return {
    meta: { tick, gameTimeSec: Math.round(game.getCurrentTime()), tickRate: game.getTickRate() },
    players,
    commanderView: {
      ownUnits: own,
      enemyContacts: enemy,
      neutralObjects: neutral,
    },
    production,
    superweapons: game.getAllSuperWeaponData(),
  };
}

function QueueStatusName(s: number): string {
  return ["Idle", "Active", "OnHold", "Ready"][s] ?? String(s);
}

async function main() {
  await cdapi.init(MIX_DIR);

  const commander = new SupalosaBot(RED, Countries.IRAQ, [BLUE], false);
  const dummy = new NoopBot(BLUE, "Russians");

  const gameSettings: CreateOfflineOpts = {
    buildOffAlly: false,
    cratesAppear: false,
    credits: 10000,
    gameMode: cdapi.getAvailableGameModes(MAP)[0],
    gameSpeed: 6,
    mapName: MAP,
    mcvRepacks: true,
    shortGame: true,
    superWeapons: false,
    unitCount: 0,
    online: false,
    agents: [commander, dummy],
  };

  const game: GameInstanceApi = await cdapi.createGame(gameSettings);
  const pending = new Set(SAMPLE_TICKS);
  let ticks = 0;
  const maxTicks = 5000;

  while (!game.isFinished() && ticks < maxTicks) {
    await game.update();
    ticks++;
    if (pending.has(ticks)) {
      pending.delete(ticks);
      const api = dummy.lastGameApi;
      if (!api) throw new Error("no GameApi captured yet");
      const snap = dumpAt(api, commander);
      const file = path.join(ARTIFACTS, `snapshot-t${String(ticks).padStart(4, "0")}.json`);
      writeFileSync(file, JSON.stringify(snap, null, 1));
      const own = snap.commanderView.ownUnits.length;
      const enemy = snap.commanderView.enemyContacts.length;
      console.log(
        `dumped t${ticks}: own=${own} enemy=${enemy} credits=${snap.players[0]?.credits} -> ${path.basename(file)}`,
      );
    }
  }

  console.log("match finished:", game.isFinished(), "| ticks:", ticks);
  console.log("stats:", JSON.stringify(game.getPlayerStats().map((s) => ({ name: s.name, defeated: s.defeated }))));
  game.saveReplay(ARTIFACTS);
  game.dispose();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
