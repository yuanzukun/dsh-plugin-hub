import { GameApi, ObjectType, QueueType, UnitData } from "@chronodivide/game-api";
import { FogSafeContact, FogSafeObservation, ObservationSource, FogSafetyError } from "./fog-safe-observation.js";
import { LEXICON } from "./lexicon.js";

/** 聚合层快照：LLM 指挥官每决策周期看到的视图（schema v1 聚合层实现） */

export interface GroupInfo {
  unitType: string;
  label: string;
  count: number;
  avgHpPct: number;
  centroid: { x: number; y: number };
  totalValue: number;
  ids: number[];
}

export interface ContactGroup {
  unitType: string;
  label: string;
  count: number;
  avgHpPct: number;
  centroid: { x: number; y: number };
  ids: number[];
  source: ObservationSource;
  observedAtTick: number;
}

export interface Snapshot {
  tick: number;
  gameTimeSec: number;
  phase: "early" | "mid" | "late";
  self: {
    credits: number;
    power: { total: number; drain: number; isLowPower: boolean };
    defeated: boolean;
  };
  buildings: { unitType: string; label: string; count: number; hpPct: number }[];
  ownCombatGroups: GroupInfo[];
  economy: { harvesters: number; harvesterIdleHint: number; refineries: number };
  enemyContacts: ContactGroup[];
  lastSeenEnemyContacts: ContactGroup[];
  visibleNeutralObjects: ContactGroup[];
  production: Record<string, { status: string; items: { name: string; qty: number }[] }>;
  pending: { builds: string[]; units: string[] };
  events: string[];
}

const COMBAT_KINDS = new Set([ObjectType.Infantry, ObjectType.Vehicle, ObjectType.Aircraft]);

function label(name: string): string {
  return LEXICON.get(name)?.label ?? name;
}

function aggregate(units: UnitData[]): GroupInfo[] {
  const byType = new Map<string, UnitData[]>();
  for (const u of units) byType.set(u.rules.name, [...(byType.get(u.rules.name) ?? []), u]);
  return [...byType.entries()]
    .map(([unitType, us]) => ({
      unitType,
      label: label(unitType),
      count: us.length,
      avgHpPct: Math.round(us.reduce((s, u) => s + (u.hitPoints / u.maxHitPoints) * 100, 0) / us.length),
      centroid: {
        x: Math.round(us.reduce((s, u) => s + u.tile.rx, 0) / us.length),
        y: Math.round(us.reduce((s, u) => s + u.tile.ry, 0) / us.length),
      },
      totalValue: us.reduce((s, u) => s + u.purchaseValue, 0),
      ids: us.map((u) => u.id),
    }))
    .sort((a, b) => b.totalValue - a.totalValue);
}

function aggregateContacts(contacts: FogSafeContact[]): ContactGroup[] {
  const byObservation = new Map<string, FogSafeContact[]>();
  for (const contact of contacts) {
    const key = `${contact.source}:${contact.unitType}:${contact.observedAtTick}`;
    byObservation.set(key, [...(byObservation.get(key) ?? []), contact]);
  }
  return [...byObservation.values()]
    .map((group) => ({
      unitType: group[0].unitType,
      label: group[0].label,
      count: group.length,
      avgHpPct: Math.round(group.reduce((sum, contact) => sum + contact.hpPct, 0) / group.length),
      centroid: {
        x: Math.round(group.reduce((sum, contact) => sum + contact.position.x, 0) / group.length),
        y: Math.round(group.reduce((sum, contact) => sum + contact.position.y, 0) / group.length),
      },
      ids: group.map((contact) => contact.id),
      source: group[0].source,
      observedAtTick: group[0].observedAtTick,
    }))
    .sort((a, b) => b.count - a.count || a.unitType.localeCompare(b.unitType) || a.observedAtTick - b.observedAtTick);
}

const QUEUE_STATUS = ["Idle", "Active", "OnHold", "Ready"];

export function buildSnapshot(
  game: GameApi,
  selfName: string,
  production: any,
  prevIds: Set<number>,
  prevEnemyTypes: Set<string>,
  pending: { builds: string[]; units: { queue: string; name: string; qty: number }[] } | undefined,
  observation: FogSafeObservation,
): Snapshot {
  const tick = game.getCurrentTick();
  if (tick !== observation.tick) {
    throw new FogSafetyError(`snapshot tick ${tick} does not match fog observation tick ${observation.tick}`);
  }
  const me = game.getPlayerData(selfName);

  const ownAll = game.getVisibleUnits(selfName, "self").map((id) => game.getUnitData(id)!).filter(Boolean);
  const buildings = aggregate(ownAll.filter((u) => u.type === ObjectType.Building));
  const combat = aggregate(ownAll.filter((u) => COMBAT_KINDS.has(u.type)));
  const enemyAgg = aggregateContacts(observation.visibleEnemies);
  const lastSeenAgg = aggregateContacts(observation.lastSeenEnemies);
  const neutralAgg = aggregateContacts(observation.visibleNeutralObjects);

  // 周期间 diff → 事件
  const events: string[] = [];
  const nowIds = new Set(ownAll.map((u) => u.id));
  let lost = 0;
  for (const id of prevIds) if (!nowIds.has(id)) lost++;
  if (lost > 0) events.push(`损失单位 ${lost} 个`);
  if (prevIds.size > 0) {
    const gained = [...nowIds].filter((id) => !prevIds.has(id)).length;
    if (gained > 0) events.push(`新增单位 ${gained} 个`);
  }
  for (const g of enemyAgg) {
    if (!prevEnemyTypes.has(g.unitType)) events.push(`新发现敌情: ${g.label}×${g.count} @(${g.centroid.x},${g.centroid.y})`);
  }

  const prod: Snapshot["production"] = {};
  if (production) {
    for (const qt of Object.values(QueueType).filter((v) => typeof v === "number") as QueueType[]) {
      const q = production.getQueueData(qt);
      if (q && (q.items.length > 0 || q.status !== 0)) {
        prod[QueueType[qt]] = {
          status: QUEUE_STATUS[q.status] ?? String(q.status),
          items: q.items.map((it: any) => ({ name: it.rules.name, qty: it.quantity })),
        };
      }
    }
  }

  const harvesters = combat.find((g) => g.unitType === "HARV")?.count ?? 0;
  const refineries = buildings.find((b) => b.unitType === "NAREFN")?.count ?? 0;

  return {
    tick,
    gameTimeSec: Math.round(game.getCurrentTime()),
    phase: tick < 900 ? "early" : tick < 2400 ? "mid" : "late",
    self: {
      credits: Math.floor(me.credits),
      power: me.power,
      defeated: game.isPlayerDefeated(selfName),
    },
    buildings: buildings.map((b) => ({ unitType: b.unitType, label: b.label, count: b.count, hpPct: b.avgHpPct })),
    ownCombatGroups: combat.filter((g) => g.unitType !== "HARV"),
    economy: { harvesters, harvesterIdleHint: 0, refineries },
    enemyContacts: enemyAgg,
    lastSeenEnemyContacts: lastSeenAgg,
    visibleNeutralObjects: neutralAgg,
    production: prod,
    pending: pending
      ? {
          builds: pending.builds,
          units: pending.units.map((u) => `${u.name}×${u.qty}`),
        }
      : { builds: [], units: [] },
    events,
  };
}

function formatContactGroups(groups: ContactGroup[]): string {
  return (
    groups
      .map(
        (contact) =>
          `${contact.label}×${contact.count}@(${contact.centroid.x},${contact.centroid.y})[${contact.source},t${contact.observedAtTick}]`,
      )
      .join("、") || "无"
  );
}

/** 快照 → LLM prompt 紧凑文本（不含 ids，指挥官不操作裸 id）。 */
export function snapshotText(s: Snapshot): string {
  const L = (arr: { toString(): string }[], sep = "; ") => arr.join(sep);
  return [
    `[时刻] tick=${s.tick} 游戏时间=${Math.floor(s.gameTimeSec / 60)}分${s.gameTimeSec % 60}秒 阶段=${s.phase}`,
    `[我方] 资金=${s.self.credits} 电力=${s.self.power.drain}/${s.self.power.total}${s.self.power.isLowPower ? "(低电力!)" : ""}`,
    `[建筑] ${s.buildings.map((b) => `${b.label}×${b.count}${b.hpPct < 60 ? `(损${b.hpPct}%)` : ""}`).join("、") || "无"}`,
    `[经济] 矿车×${s.economy.harvesters} 矿场×${s.economy.refineries}`,
    `[部队] ${s.ownCombatGroups.map((g) => `${g.label}×${g.count}@(${g.centroid.x},${g.centroid.y})${g.avgHpPct < 70 ? `[均血${g.avgHpPct}%]` : ""}`).join("、") || "无"}`,
    `[生产队列] ${Object.entries(s.production).map(([q, d]) => `${q}:${d.items.map((i) => `${i.name}×${i.qty}`).join(",") || "空"}(${d.status})`).join("、") || "全部空闲"}`,
    `[待建] ${s.pending.builds.join("、") || "无"} | [待产] ${s.pending.units.join("、") || "无"}`,
    `[敌情] ${formatContactGroups(s.enemyContacts)}`,
    `[最后已知敌情] ${formatContactGroups(s.lastSeenEnemyContacts)}`,
    `[可见中立] ${formatContactGroups(s.visibleNeutralObjects)}`,
    `[本期事件] ${L(s.events, "；") || "无"}`,
  ].join("\n");
}
