import path from "node:path";
import { fileURLToPath } from "node:url";
import { mkdirSync, appendFileSync, writeFileSync } from "node:fs";
import { cdapi, CreateOfflineOpts, GameApi, ObjectType } from "@chronodivide/game-api";
import { SupalosaBot } from "@supalosa/chronodivide-bot/dist/bot/bot.js";
import { Countries } from "@supalosa/chronodivide-bot/dist/bot/logic/common/utils.js";
import { LLMCommanderBot } from "./llm-commander-bot.js";
import { FogSafeObservation, FogSafeProjector, withFogSafeObservation } from "./fog-safe-observation.js";
import { buildSnapshot, snapshotText } from "./snapshot.js";
import { OrderTranslator, Receipt } from "./orders.js";
import { Commander, DshCommander, MockCommander, Side } from "./commander.js";
import { WatchServer, BattleUnit } from "./serve.js";
import { LEXICON } from "./lexicon.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MIX_DIR = path.resolve(HERE, "../../../assets");
const ARTIFACTS_ROOT = path.resolve(HERE, "../../../artifacts");

const RED = "RedCommander";

const ALLIED_COUNTRIES = new Set(["Americans", "Alliance", "French", "Germans", "British"]);
const SOVIET_COUNTRY_ROTATION = ["Russians", "Arabs", "Africans", "Confederation"];

export function sideOf(country: string): Side {
  return ALLIED_COUNTRIES.has(country) ? "allied" : "soviet";
}

export interface MatchConfig {
  map: string;
  myCountry: string; // 指挥官阵营（受统帅训令控制的一方）
  opponents: number; // 敌对 AI 家数
  opponentType: "supalosa" | "noop";
  commander: "dsh" | "mock";
  watcher?: WatchServer; // 大厅注入复用；缺省按 RA_SERVE 自建
  tickDelayMs?: number;
  decisionPeriod?: number;
  maxTicks?: number;
}

export interface MatchResult {
  ok: boolean;
  error?: string;
  finished?: boolean;
  ticks?: number;
  cycles?: number;
  stats?: { name: string; defeated: boolean }[];
  matchDir?: string;
}

interface CycleLog {
  cycle: number;
  tick: number;
  wallSec: number;
  commander: string;
  snapshotSummary: Record<string, unknown>;
  orders: unknown[];
  assessment?: string;
  receipts: Receipt[];
  placements: string[];
  raw?: string;
  error?: string;
}

/** 观战帧：红方指挥官视角（含战争迷雾 —— 观战者即红方统帅） */
export function buildBattleFrame(game: GameApi, observation: FogSafeObservation, redName: string, thinking: boolean) {
  const units: BattleUnit[] = [];
  const pushOwn = (id: number) => {
    const u = game.getUnitData(id);
    if (!u) return;
    units.push({
      id,
      name: u.rules.name,
      label: LEXICON.get(u.rules.name)?.label ?? u.rules.name,
      side: "red",
      kind: ObjectType[u.type] ?? "Unknown",
      x: u.tile.rx,
      y: u.tile.ry,
      hpPct: Math.round((u.hitPoints / u.maxHitPoints) * 100),
      source: "visible",
      observedAtTick: observation.tick,
    });
  };
  for (const id of game.getVisibleUnits(redName, "self")) pushOwn(id);
  for (const contact of [...observation.visibleEnemies, ...observation.lastSeenEnemies]) {
    units.push({
      id: contact.id,
      name: contact.unitType,
      label: contact.label,
      side: "blue",
      kind: contact.kind,
      x: contact.position.x,
      y: contact.position.y,
      hpPct: contact.hpPct,
      source: contact.source,
      observedAtTick: contact.observedAtTick,
    });
  }
  for (const contact of observation.visibleNeutralObjects) {
    units.push({
      id: contact.id,
      name: contact.unitType,
      label: contact.label,
      side: "neutral",
      kind: contact.kind,
      x: contact.position.x,
      y: contact.position.y,
      hpPct: contact.hpPct,
      source: contact.source,
      observedAtTick: contact.observedAtTick,
    });
  }
  const me = game.getPlayerData(redName);
  return {
    type: "battle",
    tick: game.getCurrentTick(),
    gameTimeSec: Math.round(game.getCurrentTime()),
    thinking,
    units,
    credits: Math.floor(me.credits),
    power: me.power,
  };
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function runMatch(cfg: MatchConfig): Promise<MatchResult> {
  const decisionPeriod = cfg.decisionPeriod ?? Number(process.env.RA_DECISION_PERIOD ?? 45);
  const maxTicks = cfg.maxTicks ?? Number(process.env.RA_MAX_TICKS ?? 6000);
  const maxCycles = Number(process.env.RA_MAX_CYCLES ?? 500);
  const tickDelay = cfg.tickDelayMs ?? Number(process.env.RA_TICK_DELAY_MS ?? 0);

  const matchDir = path.join(ARTIFACTS_ROOT, `match-${Date.now()}`);
  mkdirSync(matchDir, { recursive: true });
  const logFile = path.join(matchDir, "decisions.jsonl");

  await cdapi.init(MIX_DIR);

  const side = sideOf(cfg.myCountry);
  const COMMANDER: Commander =
    cfg.commander === "dsh" ? new DshCommander("dsv4flash", undefined, undefined, side) : new MockCommander();
  const projector = new FogSafeProjector();

  const redBot = new LLMCommanderBot(RED, cfg.myCountry);
  const opponentNames: string[] = [];
  const agents: any[] = [redBot];
  const { NoopBot } = await import("./noop-bot.js");
  for (let i = 0; i < cfg.opponents; i++) {
    const name = `BlueCommander${i + 1}`;
    opponentNames.push(name);
    const country = SOVIET_COUNTRY_ROTATION[i % SOVIET_COUNTRY_ROTATION.length];
    agents.push(
      cfg.opponentType === "supalosa"
        ? new SupalosaBot(name, country as any, [RED], false)
        : new NoopBot(name, country),
    );
  }

  const baseSettings = {
    buildOffAlly: false,
    cratesAppear: false,
    credits: 10000,
    gameMode: cdapi.getAvailableGameModes(cfg.map)[0],
    gameSpeed: 6,
    mapName: cfg.map,
    mcvRepacks: true,
    shortGame: true,
    superWeapons: false,
    unitCount: 0,
  };
  if (!baseSettings.gameMode) {
    return { ok: false, error: `地图 ${cfg.map} 不可用（检查 assets/ 目录）` };
  }

  let game;
  try {
    game = await cdapi.createGame({ ...baseSettings, online: false, agents } as CreateOfflineOpts);
  } catch (e) {
    return { ok: false, error: `创建对局失败（地图可能不支持 ${cfg.opponents + 1} 家）：${String(e).slice(0, 200)}` };
  }
  console.log(`[match] map=${cfg.map} me=${cfg.myCountry}(${side}) opponents=${cfg.opponents}×${cfg.opponentType} commander=${COMMANDER.name} dir=${matchDir}`);

  // 观战服务：大厅注入 or 自建
  const ownsWatcher = !cfg.watcher && process.env.RA_SERVE === "1";
  const watcher = cfg.watcher ?? (ownsWatcher ? new WatchServer(Number(process.env.RA_PORT ?? 7860)) : null);

  let cycle = 0;
  let ticks = 0;
  let prevIds = new Set<number>();
  let prevEnemyTypes = new Set<string>();
  let latestObservation: FogSafeObservation | null = null;
  const t0 = Date.now();
  let translator: OrderTranslator | null = null;
  let metaSent = false;
  let outStats: { name: string; defeated: boolean }[] = [];
  let outFinished = false;

  try {
    while (!game.isFinished() && ticks < maxTicks && cycle < maxCycles) {
      await game.update();
      ticks++;
      if (tickDelay > 0) await sleep(tickDelay);

      const api = redBot.lastGameApi;
      if (!api) continue;

      if (watcher && !metaSent) {
        metaSent = true;
        const size = (api as any).mapApi?.getRealMapSize?.() ?? { width: 120, height: 120 };
        watcher.setMeta({
          mapW: size.width ?? 120,
          mapH: size.height ?? 120,
          mapName: cfg.map,
          commander: COMMANDER.name,
          opponent: `${cfg.opponents}×${cfg.opponentType}`,
          myCountry: cfg.myCountry,
        });
      }

      // 观战帧：与 pump 同频（每 15 tick 一帧战场态势）
      if (watcher && ticks % 15 === 0) {
        latestObservation = projector.project(api, RED);
        watcher.broadcast(buildBattleFrame(api, latestObservation, RED, false));
      }

      if (translator == null) {
        const player = redBot.playerApi();
        if (player?.actions) translator = new OrderTranslator(RED, player.actions, player.production);
      }

      // 基础执行器：MCV 展开 + Ready 建筑落地 + pending 消费（每 15 tick）
      let placements: string[] = [];
      if (translator && ticks % 15 === 0) {
        placements = translator.pumpQueues(api);
      }

      // 决策周期
      if (ticks % decisionPeriod === 0 && translator) {
        cycle++;
        const directives = watcher ? watcher.takeDirectives() : [];
        const cycleStart = Date.now();
        let result: Awaited<ReturnType<Commander["decide"]>> = null;
        let error: string | undefined;
        const projected = await withFogSafeObservation(projector, api, RED, async (observation) => {
          latestObservation = observation;
          const snap = buildSnapshot(
            api,
            RED,
            redBot.playerApi()?.production,
            prevIds,
            prevEnemyTypes,
            translator?.pendingSummary(),
            observation,
          );
          watcher?.broadcast(buildBattleFrame(api, observation, RED, true)); // AI 思考中
          try {
            return { snapshot: snap, result: await COMMANDER.decide(snapshotText(snap), directives) };
          } catch (e) {
            error = String(e).slice(0, 200);
            return { snapshot: snap, result: null };
          }
        });
        latestObservation = projected.observation;
        const snap = projected.result.snapshot;
        result = projected.result.result;
        prevIds = new Set(api.getVisibleUnits(RED, "self").map((id) => id));
        prevEnemyTypes = new Set(snap.enemyContacts.map((c) => c.unitType));
        if (watcher && latestObservation) watcher.broadcast(buildBattleFrame(api, latestObservation, RED, false)); // 思考结束

        let receipts: Receipt[] = [];
        let orders: unknown[] = [];
        if (result?.orders?.length) {
          orders = result.orders;
          receipts = translator.applyOrders(api, orders);
        }

        const log: CycleLog = {
          cycle,
          tick: ticks,
          wallSec: Math.round(((Date.now() - t0) / 1000) * 10) / 10,
          commander: COMMANDER.name,
          snapshotSummary: {
            credits: snap.self.credits,
            power: `${snap.self.power.drain}/${snap.self.power.total}`,
            buildings: snap.buildings.map((b) => `${b.label}×${b.count}`).join("、"),
            combat: snap.ownCombatGroups.map((g) => `${g.label}×${g.count}`).join("、"),
            enemy: snap.enemyContacts.map((c) => `${c.label}×${c.count}`).join("、"),
            lastSeenEnemy: snap.lastSeenEnemyContacts.map((c) => `${c.label}×${c.count}`).join("、"),
            visibleNeutral: snap.visibleNeutralObjects.map((c) => `${c.label}×${c.count}`).join("、"),
            events: snap.events,
          },
          orders,
          assessment: result?.assessment,
          receipts,
          placements,
          raw: result?.raw?.slice(0, 2000),
          error,
        };
        appendFileSync(logFile, JSON.stringify(log) + "\n");
        watcher?.broadcast({
          type: "decision",
          cycle,
          tick: ticks,
          llmMs: Date.now() - cycleStart,
          directives,
          assessment: result?.assessment ?? error ?? null,
          orders,
          receipts: receipts.map((r) => ({ ok: r.ok, detail: r.detail })),
          placements,
        });

        const llmMs = Date.now() - cycleStart;
        console.log(
          `[cycle ${cycle}] t${ticks} wall=${((Date.now() - t0) / 60000).toFixed(1)}min llm=${llmMs}ms | ${snap.self.credits}cr ${snap.buildings.length}类建筑 | orders=${orders.length} ok=${receipts.filter((r) => r.ok).length} | ${result?.assessment ?? error ?? "-"}`,
        );
      }
    }
  } finally {
    outStats = game.getPlayerStats().map((s) => ({ name: s.name, defeated: s.defeated }));
    outFinished = game.isFinished();
    const finished = outFinished;
    console.log(`[match end] finished=${finished} ticks=${ticks} cycles=${cycle} wall=${((Date.now() - t0) / 60000).toFixed(1)}min`);
    console.log(`[stats]`, JSON.stringify(outStats));
    game.saveReplay(matchDir);
    game.dispose();

    watcher?.broadcast({ type: "end", finished, ticks, cycles: cycle, stats: outStats });
    if (ownsWatcher && watcher) {
      const t: NodeJS.Timeout = setTimeout(() => watcher.close(), 30_000);
      t.unref?.();
    }

    writeFileSync(
      path.join(matchDir, "summary.json"),
      JSON.stringify(
        {
          map: cfg.map,
          myCountry: cfg.myCountry,
          opponents: cfg.opponents,
          opponentType: cfg.opponentType,
          commander: COMMANDER.name,
          finished,
          ticks,
          cycles: cycle,
          stats: outStats,
        },
        null,
        2,
      ),
    );
  }

  return { ok: true, finished: outFinished, ticks, cycles: cycle, stats: outStats, matchDir };
}

// ── CLI 入口：pnpm match（env 组装配置）──
async function cli() {
  const result = await runMatch({
    map: process.env.RA_MAP ?? "simple-1v1-no-preview.map",
    myCountry: process.env.RA_MY_COUNTRY ?? "Russians",
    opponents: Number(process.env.RA_OPPONENTS ?? 1),
    opponentType: (process.env.RA_OPPONENT as "supalosa" | "noop") ?? "supalosa",
    commander: process.env.RA_COMMANDER === "dsh" ? "dsh" : "mock",
  });
  if (!result.ok) {
    console.error("[cli] 对局失败:", result.error);
    process.exit(1);
  }
}

if (process.argv[1]?.includes("run-match")) {
  cli().catch((err) => {
    console.error(err);
    process.exit(1);
  });
}
