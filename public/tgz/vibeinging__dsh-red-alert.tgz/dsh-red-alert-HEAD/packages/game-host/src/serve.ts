import http from "node:http";
import { readFileSync, existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { WebSocketServer, WebSocket } from "ws";

/**
 * 观战服务：HTTP 静态 UI + WS 帧广播 + 统帅训令接收。
 * 内嵌于 game-host 进程 —— 引擎、决策、观战同进程（单容器部署最简）。
 */

const HERE = path.dirname(fileURLToPath(import.meta.url));
const WEB_DIR = path.resolve(HERE, "../web");

export interface BattleUnit {
  id: number;
  name: string;
  label: string;
  side: "red" | "blue" | "neutral";
  kind: string; // Building | Vehicle | Infantry | Aircraft
  x: number;
  y: number;
  hpPct: number;
  source: "visible" | "last-seen";
  observedAtTick: number;
}

export class WatchServer {
  private server: http.Server;
  private wss: WebSocketServer;
  private clients = new Set<WebSocket>();
  private directives: string[] = [];
  private closed = false;
  private meta: unknown = null;
  /** 大厅模式：收到自然语言建局指令时的回调 */
  onNewMatch: ((text: string) => void) | null = null;

  constructor(port: number) {
    this.server = http.createServer((req, res) => {
      const pathname = (req.url ?? "/").split("?")[0];
      if (pathname === "/" || pathname === "/index.html") {
        const file = path.join(WEB_DIR, "index.html");
        if (existsSync(file)) {
          res.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
          res.end(readFileSync(file));
          return;
        }
      }
      res.writeHead(404);
      res.end("not found");
    });

    this.wss = new WebSocketServer({ server: this.server });
    this.wss.on("connection", (ws) => {
      this.clients.add(ws);
      if (this.meta) ws.send(JSON.stringify(this.meta));
      if (this.lobbyState) ws.send(JSON.stringify(this.lobbyState));
      ws.on("message", (data) => {
        try {
          const msg = JSON.parse(String(data));
          if (msg?.type === "directive" && typeof msg.text === "string") {
            const text = msg.text.trim().slice(0, 200);
            if (text && this.directives.length < 5) {
              this.directives.push(text);
              ws.send(JSON.stringify({ type: "directiveAck", text, queued: this.directives.length }));
              this.broadcast({ type: "directiveEcho", text });
            }
          } else if (msg?.type === "newMatch" && typeof msg.text === "string") {
            const text = String(msg.text).trim().slice(0, 300);
            console.log(`[serve] 收到建局指令: ${text} | handler=${this.onNewMatch ? "yes" : "no"}`);
            if (text) {
              ws.send(JSON.stringify({ type: "newMatchAck", text }));
              this.onNewMatch?.(text);
            }
          }
        } catch {
          // ignore malformed
        }
      });
      ws.on("close", () => this.clients.delete(ws));
    });

    this.server.listen(port);
    console.log(`[serve] watch UI: http://localhost:${port}`);
  }

  /** 大厅消息（状态/建局结果反馈） */
  lobby(msg: unknown): void {
    // lobby 基础帧缓存，新连接补发
    if ((msg as any)?.type === "lobby") this.lobbyState = msg;
    this.broadcast(msg);
  }

  private lobbyState: unknown = null;

  /** 对局元信息（连接晚的客户端也能收到；lobby 模式下也承载 joinUrl 等） */
  setMeta(meta: unknown): void {
    this.meta = { type: "meta", ...(meta as object) };
    this.broadcast(this.meta);
  }

  clearMeta(): void {
    this.meta = null;
    this.lobbyState = null;
  }

  /** 取走待处理训令（决策周期消费后清空） */
  takeDirectives(): string[] {
    const d = this.directives;
    this.directives = [];
    return d;
  }

  broadcast(msg: unknown): void {
    if (this.closed) return;
    const s = JSON.stringify(msg);
    for (const ws of this.clients) if (ws.readyState === WebSocket.OPEN) ws.send(s);
  }

  close(): void {
    this.closed = true;
    setTimeout(() => {
      for (const ws of this.clients) ws.close();
      this.server.close();
    }, 300);
  }
}
