import path from "node:path";
import { fileURLToPath } from "node:url";
import { readdirSync } from "node:fs";
import { WatchServer } from "./serve.js";
import { runMatch, MatchConfig } from "./run-match.js";
import { execFile } from "node:child_process";

/**
 * 大厅入口：常驻服务 + 自然语言建局。
 * 启动页输入"新建一局 1对7 的 xx 地图战争，我们使用美国" → 解析 → 自动开局。
 */

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ASSETS = path.resolve(HERE, "../../../assets");
const PORT = Number(process.env.RA_PORT ?? 7860);

const COUNTRY_ALIASES: Record<string, string> = {
  美国: "Americans", 盟军: "Americans", 美利坚: "Americans", american: "Americans", usa: "Americans",
  苏俄: "Russians", 苏联: "Russians", 俄国: "Russians", russia: "Russians",
  法国: "French", french: "French",
  德国: "Germans", german: "Germans",
  英国: "British", british: "British",
  韩国: "Alliance", korea: "Alliance",
  伊拉克: "Arabs", 利比亚: "Africans", 古巴: "Confederation",
};

export interface ParsedMatch {
  ok: boolean;
  error?: string;
  config?: Omit<MatchConfig, "commander" | "watcher">;
  note?: string;
}

/** 规则解析（离线/冒烟用，零 LLM 成本） */
export function ruleParse(text: string, maps: string[]): ParsedMatch {
  // 人数："1对7" "1v7" "8人" "一对七"
  const cnDigits: Record<string, number> = { 一: 1, 二: 2, 两: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9, 十: 10 };
  let opponents = 1;
  const m = text.match(/(\d+|[一二两三四五六七八九十])\s*(?:对|v|V|vs|VS|打)\s*(\d+|[一二两三四五六七八九十])/);
  if (m) {
    const a = cnDigits[m[1]] ?? Number(m[1]);
    const b = cnDigits[m[2]] ?? Number(m[2]);
    if (a >= 1 && b >= 1) opponents = b; // "1对7"=我方1 vs 敌7
  } else {
    const m2 = text.match(/(\d+)\s*人/);
    if (m2) opponents = Math.max(1, Number(m2[2] ?? m2[1]) - 1 || 1);
  }

  // 阵营
  let myCountry = "Russians";
  for (const [alias, name] of Object.entries(COUNTRY_ALIASES)) {
    if (text.includes(alias) || text.toLowerCase().includes(alias)) {
      myCountry = name;
      break;
    }
  }

  // 地图：按用户提到的名字模糊匹配，否则第一张
  let map = maps[0];
  const mentioned = maps.find((mm) => text.includes(mm.replace(/\.(map|mpr)$/i, "").split(/[-_]/)[0]));
  if (mentioned) map = mentioned;

  // 对手强度
  const opponentType = /弱|简单|noop|靶/i.test(text) ? "noop" : "supalosa";

  const note = `地图=${map} 阵营=${myCountry} 敌方=${opponents}家(${opponentType})`;
  return { ok: true, config: { map, myCountry, opponents, opponentType }, note };
}

/** LLM 解析（dsh 模式）：地图必须从可用列表选 */
export async function llmParse(text: string, maps: string[]): Promise<ParsedMatch> {
  const countryList = [...new Set(Object.values(COUNTRY_ALIASES))];
  const prompt = `你是红警对战平台的建局助手。把用户的建局指令解析成 JSON 配置。

可用地图（map 字段只能从中选）：
${maps.join("\n")}

可用阵营（myCountry，从这些内部名选）：${countryList.join("、")}
（美国=Americans 苏俄=Russians 法国=French 德国=Germans 英国=British 韩国=Alliance）

字段：
- map: 地图文件名
- myCountry: 我方阵营内部名
- opponents: 敌方 AI 家数（"1对7"即 7）
- opponentType: "supalosa"(正常强度) | "noop"(靶子/练手)

用户指令：「${text}」

只输出 JSON：{"map":"...","myCountry":"...","opponents":N,"opponentType":"...","note":"一句话建局摘要"}`;
  const raw = await invokeDsh(prompt);
  if (!raw) return { ok: false, error: "建局指令解析失败（LLM 无响应）" };
  try {
    const first = raw.indexOf("{");
    const last = raw.lastIndexOf("}");
    const obj = JSON.parse(raw.slice(first, last + 1));
    const map = maps.includes(obj.map) ? obj.map : maps[0];
    const myCountry = countryList.includes(obj.myCountry) ? obj.myCountry : "Russians";
    const opponents = Math.max(1, Math.min(7, Math.floor(Number(obj.opponents) || 1)));
    const opponentType = obj.opponentType === "noop" ? "noop" : "supalosa";
    return { ok: true, config: { map, myCountry, opponents, opponentType }, note: String(obj.note ?? "") };
  } catch {
    return { ok: false, error: "建局指令无法解析为配置，请换个说法（例如：新建一局 1对1 的 simple 地图，我们使用美国）" };
  }
}

async function invokeDsh(prompt: string): Promise<string | null> {
  const dshSource = process.env.RA_DSH_SOURCE ?? path.join(process.env.HOME!, ".dsh/source/current");
  return new Promise((resolve) => {
    execFile(
      "pnpm",
      ["run", "demo:headless", "--output-format", "json", "--", prompt],
      { cwd: dshSource, timeout: 60_000, maxBuffer: 16 * 1024 * 1024 },
      (err, stdout) => {
        if (err) return resolve(null);
        const line = stdout.split("\n").map((l) => l.trim()).filter((l) => l.startsWith('{"type":"result"')).pop();
        if (!line) return resolve(null);
        try {
          resolve(JSON.parse(line).output ?? null);
        } catch {
          resolve(null);
        }
      },
    );
  });
}

async function main() {
  const maps = readdirSync(ASSETS).filter((f) => /\.(map|mpr)$/i.test(f)).sort();
  if (maps.length === 0) {
    console.error("[lobby] assets/ 下没有地图文件");
    process.exit(1);
  }
  const commanderMode = process.env.RA_COMMANDER === "dsh" ? "dsh" : "mock";
  const useLlmParse = process.env.RA_LOBBY_PARSER
    ? process.env.RA_LOBBY_PARSER === "llm"
    : commanderMode === "dsh";

  const watcher = new WatchServer(PORT);
  let running = false;

  watcher.lobby({
    type: "lobby",
    maps,
    commander: commanderMode,
    hint: `可用地图 ${maps.length} 张；示例：「新建一局 1对1 的 ${maps[0].replace(/\.(map|mpr)$/i, "")} 地图战争，我们使用美国」`,
  });
  console.log(`[lobby] 模式=${commanderMode} 建局解析=${useLlmParse ? "llm" : "rule"} 地图=${maps.length}张`);

  watcher.onNewMatch = async (text) => {
    if (running) {
      watcher.lobby({ type: "lobbyMsg", level: "warn", text: "对局进行中，结束后再开新局（可在右侧下发统帅训令）" });
      return;
    }
    running = true;
    watcher.clearMeta();
    try {
      watcher.lobby({ type: "lobbyMsg", level: "info", text: `正在解析建局指令…（${useLlmParse ? "dsv4flash" : "规则"}）` });
      const parsed = useLlmParse ? await llmParse(text, maps) : ruleParse(text, maps);
      if (!parsed.ok || !parsed.config) {
        watcher.lobby({ type: "lobbyMsg", level: "error", text: parsed.error ?? "解析失败" });
        return;
      }
      const cfg = parsed.config;
      watcher.lobby({
        type: "lobbyMsg",
        level: "ok",
        text: `建局成功：${parsed.note ?? ""}。指挥官 dsv4flash 接管 ${cfg.myCountry}，对局开始！`,
      });
      const result = await runMatch({ ...cfg, commander: commanderMode as "dsh" | "mock", watcher });
      if (!result.ok) {
        watcher.lobby({ type: "lobbyMsg", level: "error", text: `对局失败：${result.error}` });
      } else {
        watcher.lobby({ type: "lobbyMsg", level: "ok", text: "对局结束。回放与决策日志已存 artifacts/，可再次输入开新局。" });
      }
    } finally {
      running = false;
      watcher.clearMeta();
      watcher.lobby({
        type: "lobby",
        maps,
        commander: commanderMode,
        hint: `可用地图 ${maps.length} 张；示例：「新建一局 1对1 的 ${maps[0].replace(/\.(map|mpr)$/i, "")} 地图战争，我们使用美国」`,
      });
      watcher.lobby({ type: "backToLobby" });
    }
  };
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
