import path from "node:path";
import { fileURLToPath } from "node:url";
import { readFileSync } from "node:fs";

/** 对局复盘摘要：从 decisions.jsonl 生成战报（DecisionLog 消费端） */

interface CycleLog {
  cycle: number;
  tick: number;
  wallSec: number;
  commander: string;
  snapshotSummary: {
    credits: number;
    power: string;
    buildings: string;
    combat: string;
    enemy: string;
    events: string[];
  };
  orders: { action: string; target?: string; units?: string; qty?: number; reason?: string }[];
  assessment?: string;
  receipts: { ok: boolean; detail: string }[];
  placements: string[];
  error?: string;
}

function main() {
  const file = process.argv[2];
  if (!file) {
    console.error("usage: tsx src/analyze-match.ts <match-dir>/decisions.jsonl");
    process.exit(1);
  }
  const rows: CycleLog[] = readFileSync(file, "utf-8").trim().split("\n").map((l) => JSON.parse(l));
  const t0 = rows[0];

  console.log(`═══ 战报 ═══`);
  console.log(`指挥官: ${t0.commander} | 决策周期: ${rows.length} | 起始tick: ${t0.tick}`);

  // 关键节点：建筑首次落地 / 首次接敌 / 首次进攻指令 / 战损事件
  const seen = new Set<string>();
  const marks: string[] = [];
  for (const r of rows) {
    for (const b of String(r.snapshotSummary.buildings).split("、")) {
      const name = b.split("×")[0];
      if (name && !seen.has("b:" + name) && name !== "无") {
        seen.add("b:" + name);
        marks.push(`t${r.tick} 建成 ${name}`);
      }
    }
    const enemy = String(r.snapshotSummary.enemy);
    if (enemy && enemy !== "无" && !seen.has("enemy")) {
      seen.add("enemy");
      marks.push(`t${r.tick} 首次接敌: ${enemy}`);
    }
    for (const o of r.orders) {
      if (o.action === "attackMove" && !seen.has("atk")) {
        seen.add("atk");
        marks.push(`t${r.tick} 发起进攻: ${o.units}→(${(o as any).x},${(o as any).y})`);
      }
    }
    for (const e of r.snapshotSummary.events ?? []) {
      if (e.includes("损失") && Number(e.replace(/\D/g, "")) >= 3 && !seen.has("loss3")) {
        seen.add("loss3");
        marks.push(`t${r.tick} 明显卡损: ${e}`);
      }
    }
  }
  console.log("\n── 关键节点 ──");
  for (const m of marks) console.log(" ", m);

  // 指令统计
  const actionCount = new Map<string, number>();
  let okCount = 0;
  let failCount = 0;
  for (const r of rows) {
    for (const o of r.orders) actionCount.set(o.action, (actionCount.get(o.action) ?? 0) + 1);
    for (const rc of r.receipts) rc.ok ? okCount++ : failCount++;
  }
  console.log("\n── 指令统计 ──");
  console.log(" ", [...actionCount.entries()].map(([a, c]) => `${a}:${c}`).join("  "));
  console.log(`  执行成功 ${okCount} / 失败 ${failCount}`);

  // 资金曲线（每 10 周期采样）
  console.log("\n── 资金/军力轨迹（每10周期） ──");
  rows
    .filter((_, i) => i % 10 === 0)
    .forEach((r) => {
      const combat = String(r.snapshotSummary.combat);
      const n = (combat.match(/×(\d+)/g) ?? []).reduce((s, m) => s + Number(m.slice(1)), 0);
      console.log(`  t${r.tick} cr=${r.snapshotSummary.credits} 军力≈${n} ${combat !== "无" ? "[" + combat.slice(0, 60) + "]" : ""}`);
    });

  // 失败指令 top
  const fails = new Map<string, number>();
  for (const r of rows) for (const rc of r.receipts) if (!rc.ok) fails.set(rc.detail, (fails.get(rc.detail) ?? 0) + 1);
  if (fails.size > 0) {
    console.log("\n── 失败指令 ──");
    for (const [d, c] of [...fails.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5)) console.log(`  ×${c} ${d}`);
  }

  // 精彩判断（assessment 抽样）
  console.log("\n── 指挥官判断摘录 ──");
  const picks = rows.filter((r) => r.assessment && r.orders.length >= 2).slice(0, 3);
  const picks2 = rows.filter((r) => r.assessment && (r.snapshotSummary.enemy !== "无")).slice(0, 3);
  for (const r of [...picks, ...picks2].slice(0, 5)) console.log(`  t${r.tick}: ${r.assessment}`);
}

main();
