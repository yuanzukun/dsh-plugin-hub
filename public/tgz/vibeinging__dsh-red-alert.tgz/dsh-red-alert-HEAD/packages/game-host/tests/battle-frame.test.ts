import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";
import { GameApi, ObjectType } from "@chronodivide/game-api";
import { FogSafeObservation } from "../src/fog-safe-observation.js";
import { buildBattleFrame } from "../src/run-match.js";

test("battle frames preserve visible and last-seen sources for the UI", () => {
  const observation: FogSafeObservation = {
    tick: 12,
    ownUnits: [
      {
        id: 1,
        unitType: "E1",
        label: "步兵",
        kind: "Infantry",
        position: { x: 1, y: 2 },
        hpPct: 100,
        observedAtTick: 12,
        source: "visible",
      },
    ],
    visibleEnemies: [
      {
        id: 2,
        unitType: "HTNK",
        label: "坦克",
        kind: "Vehicle",
        position: { x: 4, y: 5 },
        hpPct: 100,
        observedAtTick: 12,
        source: "visible",
      },
    ],
    lastSeenEnemies: [
      {
        id: 3,
        unitType: "E1",
        label: "步兵",
        kind: "Infantry",
        position: { x: 8, y: 9 },
        hpPct: 80,
        observedAtTick: 8,
        source: "last-seen",
      },
    ],
    visibleNeutralObjects: [],
  };
  const ownUnit = {
    id: 1,
    type: ObjectType.Infantry,
    rules: { name: "E1" },
    tile: { rx: 1, ry: 2 },
    hitPoints: 100,
    maxHitPoints: 100,
  };
  const game = {
    getVisibleUnits: (_player: string, type: string) => (type === "self" ? [1] : []),
    getUnitData: (id: number) => (id === 1 ? ownUnit : undefined),
    getCurrentTick: () => 12,
    getCurrentTime: () => 3,
    getPlayerData: () => ({ credits: 1000, power: { total: 100, drain: 20, isLowPower: false } }),
  } as unknown as GameApi;

  const frame = buildBattleFrame(game, observation, "RedCommander", false);
  assert.deepEqual(
    frame.units.map((unit) => ({ id: unit.id, source: unit.source, observedAtTick: unit.observedAtTick })),
    [
      { id: 1, source: "visible", observedAtTick: 12 },
      { id: 2, source: "visible", observedAtTick: 12 },
      { id: 3, source: "last-seen", observedAtTick: 8 },
    ],
  );

  const page = readFileSync(new URL("../web/index.html", import.meta.url), "utf8");
  assert.match(page, /u\.source === "last-seen"/);
  assert.match(page, /最后发现/);
  assert.match(page, /setLineDash/);
  assert.doesNotMatch(page, /蓝=敌\(可见\)/);
});
