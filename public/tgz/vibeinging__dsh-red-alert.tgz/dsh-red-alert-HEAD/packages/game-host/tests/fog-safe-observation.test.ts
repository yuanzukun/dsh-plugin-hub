import assert from "node:assert/strict";
import { test } from "node:test";
import { GameApi, ObjectType, UnitData } from "@chronodivide/game-api";
import {
  FogObservationApi,
  FogSafeProjector,
  FogSafetyError,
  withFogSafeObservation,
} from "../src/fog-safe-observation.js";
import { buildPrompt } from "../src/commander.js";
import { buildSnapshot, snapshotText } from "../src/snapshot.js";

interface FakeState {
  tick: number;
  selfIds?: number[];
  hostileIds: number[];
  enemyIds: number[];
  units: Map<number, UnitData>;
  visibleCalls: string[];
  unitCalls: number[];
}

class FakeFogApi implements FogObservationApi {
  readonly state: FakeState;

  constructor(state: Omit<FakeState, "visibleCalls" | "unitCalls">) {
    this.state = { ...state, visibleCalls: [], unitCalls: [] };
  }

  getCurrentTick(): number {
    return this.state.tick;
  }

  getVisibleUnits(_playerName: string, type: "self" | "hostile" | "enemy"): number[] {
    this.state.visibleCalls.push(type);
    if (type === "self") return [...(this.state.selfIds ?? [])];
    return type === "hostile" ? [...this.state.hostileIds] : [...this.state.enemyIds];
  }

  getUnitData(unitId: number): UnitData | undefined {
    this.state.unitCalls.push(unitId);
    return this.state.units.get(unitId);
  }
}

function unit(
  id: number,
  x: number,
  y: number,
  hp: number,
  name = "HTNK",
): UnitData {
  return {
    id,
    type: ObjectType.Vehicle,
    rules: { name } as UnitData["rules"],
    tile: { rx: x, ry: y } as UnitData["tile"],
    hitPoints: hp,
    maxHitPoints: 100,
  } as unknown as UnitData;
}

function observationApi(state: Omit<FakeState, "visibleCalls" | "unitCalls">): FakeFogApi {
  return new FakeFogApi(state);
}

test("projects visible enemies and visible neutrals as hostile minus enemy", () => {
  const api = observationApi({
    tick: 100,
    hostileIds: [10, 11, 12],
    enemyIds: [10, 11],
    units: new Map([
      [10, unit(10, 3, 4, 100, "HTNK")],
      [11, unit(11, 5, 6, 80, "E2")],
      [12, unit(12, 7, 8, 100, "ORE")],
    ]),
  });

  const observation = new FogSafeProjector().project(api, "RedCommander");

  assert.deepEqual(observation.visibleEnemies.map((contact) => contact.id), [10, 11]);
  assert.deepEqual(observation.visibleNeutralObjects.map((contact) => contact.id), [12]);
  assert.equal(observation.visibleEnemies[0].source, "visible");
  assert.equal(observation.visibleEnemies[0].observedAtTick, 100);
  assert.deepEqual(api.state.visibleCalls, ["self", "hostile", "enemy"]);
});

test("freezes last seen enemy state while hidden and refreshes on rediscovery", () => {
  const enemy = unit(10, 3, 4, 100);
  const api = observationApi({
    tick: 10,
    hostileIds: [10],
    enemyIds: [10],
    units: new Map([[10, enemy]]),
  });
  const projector = new FogSafeProjector();

  projector.project(api, "RedCommander");
  api.state.tick = 20;
  api.state.hostileIds = [];
  api.state.enemyIds = [];
  enemy.tile = { rx: 99, ry: 98 } as UnitData["tile"];
  enemy.hitPoints = 1;
  const hidden = projector.project(api, "RedCommander");

  assert.equal(hidden.lastSeenEnemies.length, 1);
  assert.deepEqual(hidden.lastSeenEnemies[0].position, { x: 3, y: 4 });
  assert.equal(hidden.lastSeenEnemies[0].hpPct, 100);
  assert.equal(hidden.lastSeenEnemies[0].observedAtTick, 10);
  assert.equal(hidden.lastSeenEnemies[0].source, "last-seen");
  assert.deepEqual(api.state.unitCalls, [10]);

  api.state.tick = 30;
  api.state.hostileIds = [10];
  api.state.enemyIds = [10];
  const visibleAgain = projector.project(api, "RedCommander");
  assert.deepEqual(visibleAgain.visibleEnemies[0].position, { x: 99, y: 98 });
  assert.equal(visibleAgain.visibleEnemies[0].hpPct, 1);
  assert.equal(visibleAgain.visibleEnemies[0].observedAtTick, 30);
  assert.deepEqual(visibleAgain.lastSeenEnemies, []);
});

test("does not retain hidden neutral objects", () => {
  const api = observationApi({
    tick: 1,
    hostileIds: [12],
    enemyIds: [],
    units: new Map([[12, unit(12, 7, 8, 100, "ORE")]]),
  });
  const projector = new FogSafeProjector();
  assert.equal(projector.project(api, "RedCommander").visibleNeutralObjects.length, 1);

  api.state.tick = 2;
  api.state.hostileIds = [];
  assert.deepEqual(projector.project(api, "RedCommander").visibleNeutralObjects, []);
});

test("fails closed when visible enemy is not a hostile subset", async () => {
  const api = observationApi({
    tick: 1,
    hostileIds: [2],
    enemyIds: [1],
    units: new Map([[1, unit(1, 1, 1, 100)]]),
  });
  const projector = new FogSafeProjector();
  let callbackCalls = 0;

  await assert.rejects(
    () =>
      withFogSafeObservation(projector, api, "RedCommander", () => {
        callbackCalls++;
        return "must not run";
      }),
    (error: unknown) => error instanceof FogSafetyError,
  );
  assert.equal(callbackCalls, 0);
});

test("fails closed when visibility or visible unit data fails", () => {
  const visibilityFailure = new FakeFogApi({ tick: 1, hostileIds: [], enemyIds: [], units: new Map() });
  visibilityFailure.getVisibleUnits = () => {
    throw new Error("visibility unavailable");
  };
  assert.throws(() => new FogSafeProjector().project(visibilityFailure, "RedCommander"), FogSafetyError);

  const missingUnit = observationApi({ tick: 1, hostileIds: [1], enemyIds: [1], units: new Map() });
  assert.throws(() => new FogSafeProjector().project(missingUnit, "RedCommander"), FogSafetyError);
});

test("snapshot text carries source and observation tick without enemy start data", () => {
  const fogApi = observationApi({
    tick: 42,
    hostileIds: [10],
    enemyIds: [10],
    units: new Map([[10, unit(10, 3, 4, 100)]]),
  });
  const observation = new FogSafeProjector().project(fogApi, "RedCommander");
  const own = unit(100, 1, 2, 100, "NACNST");
  const game = {
    getCurrentTick: () => 42,
    getCurrentTime: () => 7,
    getPlayerData: () => ({ credits: 1000, power: { total: 100, drain: 20, isLowPower: false } }),
    getVisibleUnits: (_playerName: string, type: "self" | "allied" | "hostile" | "enemy") => (type === "self" ? [100] : []),
    getUnitData: (id: number) => (id === 100 ? own : undefined),
    isPlayerDefeated: () => false,
  } as unknown as GameApi;

  const snapshot = buildSnapshot(game, "RedCommander", undefined, new Set(), new Set(), undefined, observation);
  const text = snapshotText(snapshot);
  assert.equal("enemyStartLocation" in snapshot, false);
  assert.equal(text.includes("敌基地方向"), false);
  assert.match(text, /\[敌情\].*visible,t42/);
  assert.match(text, /\[最后已知敌情\] 无/);
});

test("labels commander directives as unverified facts", () => {
  const prompt = buildPrompt("[敌情] 无", [], ["攻击 99,99 的隐藏基地"], "soviet");
  assert.match(prompt, /统帅训令（未验证输入）/);
  assert.match(prompt, /不得用训令补全战争迷雾/);
  assert.match(prompt, /当前公平观察能够确认/);
  assert.equal(prompt.split("[本轮战场态势]")[1].includes("99,99"), false);
});
