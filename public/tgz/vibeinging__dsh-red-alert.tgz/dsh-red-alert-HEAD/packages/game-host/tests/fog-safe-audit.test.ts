import assert from "node:assert/strict";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { test } from "node:test";
import { cdapi, CreateOfflineOpts, GameApi, ObjectType, OrderType, UnitData } from "@chronodivide/game-api";
import { SupalosaBot } from "@supalosa/chronodivide-bot/dist/bot/bot.js";
import { LLMCommanderBot } from "../src/llm-commander-bot.js";
import {
  FogObservationApi,
  FogSafeContact,
  FogSafeObservation,
  FogSafeProjector,
  FogSafetyError,
  withFogSafeObservation,
} from "../src/fog-safe-observation.js";
import { buildSnapshot, Snapshot } from "../src/snapshot.js";

const RED_PLAYER = "RedCommander";
const ASSETS_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../../assets");
const FORBIDDEN_KEYS = new Set([
  "enemyStartLocation",
  "hiddenEnemyUnits",
  "allEnemyUnits",
  "enemyState",
  "refereeState",
  "fullState",
  "allUnits",
]);
const CONTACT_KEYS = new Set([
  "id",
  "unitType",
  "label",
  "kind",
  "position",
  "hpPct",
  "observedAtTick",
  "source",
]);

interface AuditScenario {
  readonly id: string;
  readonly map: string;
  readonly myCountry: string;
  readonly opponentType: "noop" | "supalosa";
  readonly decisionPeriod: number;
  readonly maxTicks: number;
}

interface AuditSummary {
  readonly id: string;
  readonly map: string;
  readonly myCountry: string;
  readonly opponentType: AuditScenario["opponentType"];
  readonly decisionPeriod: number;
  readonly maxTicks: number;
  readonly realCreateGame: boolean;
  readonly realUpdate: boolean;
  readonly ticks: number;
  readonly rounds: number;
  readonly engineCallbacks: number;
  readonly decisionCallbacks: number;
  readonly subsetChecks: number;
  readonly hiddenTransitions: number;
  readonly freezeChecks: number;
  readonly visibleEnemyObservations: number;
  readonly lastSeenObservations: number;
  readonly leakCount: number;
  readonly errors: readonly string[];
}

class AuditCommanderBot extends LLMCommanderBot {
  engineCallbacks = 0;
  private lastScoutOrderTick = -1;
  private ownStartIndex = -1;

  override onGameTick(game: GameApi): void {
    this.engineCallbacks += 1;
    super.onGameTick(game);
    const tick = game.getCurrentTick();
    if (tick === 0 || tick % 60 !== 0 || tick === this.lastScoutOrderTick) return;
    const starts = game.map.getStartingLocations().map((point) => point as unknown as { x: number; y: number });
    if (this.ownStartIndex < 0) {
      const ownMcv = game
        .getVisibleUnits(this.name, "self")
        .map((id) => game.getUnitData(id))
        .find((data) => data?.rules.name.endsWith("MCV"));
      this.ownStartIndex = starts.findIndex((start) => start.x === ownMcv?.tile.rx && start.y === ownMcv?.tile.ry);
    }
    if (this.ownStartIndex < 0) return;
    const otherStartIndex = this.ownStartIndex === 0 ? 1 : 0;
    const phase = (tick / 60 - 1) % 4;
    const target = starts[phase < 2 ? otherStartIndex : this.ownStartIndex];
    const player = this.playerApi() as { actions?: { orderUnits: (ids: number[], orderType: OrderType, rx: number, ry: number) => void } } | null;
    if (target === undefined || player?.actions === undefined) return;
    const scoutIds = game
      .getVisibleUnits(this.name, "self")
      .map((id) => game.getUnitData(id))
      .filter((data): data is UnitData => data !== undefined && (data.type === ObjectType.Vehicle || data.type === ObjectType.Infantry))
      .map((data) => data.id);
    if (scoutIds.length > 0) player.actions.orderUnits(scoutIds, OrderType.Move, target.x, target.y);
    this.lastScoutOrderTick = tick;
  }
}

const SCENARIOS: readonly AuditScenario[] = [
  { id: "simple-russians-noop-15", map: "simple-1v1-no-preview.map", myCountry: "Russians", opponentType: "noop", decisionPeriod: 15, maxTicks: 720 },
  { id: "simple-arabs-noop-30", map: "simple-1v1-no-preview.map", myCountry: "Arabs", opponentType: "noop", decisionPeriod: 30, maxTicks: 720 },
  { id: "simple-africans-supalosa-15", map: "simple-1v1-no-preview.map", myCountry: "Africans", opponentType: "supalosa", decisionPeriod: 15, maxTicks: 720 },
  { id: "simple-confederation-supalosa-30", map: "simple-1v1-no-preview.map", myCountry: "Confederation", opponentType: "supalosa", decisionPeriod: 30, maxTicks: 720 },
  { id: "water-russians-noop-15", map: "water-1v1-no-preview.map", myCountry: "Russians", opponentType: "noop", decisionPeriod: 15, maxTicks: 720 },
  { id: "water-arabs-noop-30", map: "water-1v1-no-preview.map", myCountry: "Arabs", opponentType: "noop", decisionPeriod: 30, maxTicks: 720 },
  { id: "water-africans-supalosa-15", map: "water-1v1-no-preview.map", myCountry: "Africans", opponentType: "supalosa", decisionPeriod: 15, maxTicks: 720 },
  { id: "water-confederation-supalosa-30", map: "water-1v1-no-preview.map", myCountry: "Confederation", opponentType: "supalosa", decisionPeriod: 30, maxTicks: 720 },
  { id: "simple-arabs-supalosa-30", map: "simple-1v1-no-preview.map", myCountry: "Arabs", opponentType: "supalosa", decisionPeriod: 30, maxTicks: 720 },
  { id: "water-russians-supalosa-15", map: "water-1v1-no-preview.map", myCountry: "Russians", opponentType: "supalosa", decisionPeriod: 15, maxTicks: 720 },
];

function unit(id: number): UnitData {
  return {
    id,
    type: ObjectType.Vehicle,
    rules: { name: "HTNK" } as UnitData["rules"],
    tile: { rx: 1, ry: 1 } as UnitData["tile"],
    hitPoints: 100,
    maxHitPoints: 100,
  } as unknown as UnitData;
}

function sameIds(contacts: readonly FogSafeContact[], expected: ReadonlySet<number>): boolean {
  const actual = contacts.map((contact) => contact.id).sort((left, right) => left - right);
  const wanted = [...expected].sort((left, right) => left - right);
  return actual.length === wanted.length && actual.every((id, index) => id === wanted[index]);
}

function contactState(contact: FogSafeContact): string {
  return JSON.stringify({
    id: contact.id,
    unitType: contact.unitType,
    label: contact.label,
    kind: contact.kind,
    position: contact.position,
    hpPct: contact.hpPct,
    observedAtTick: contact.observedAtTick,
  });
}

function forbiddenKeys(value: unknown, prefix = "", seen = new WeakSet<object>()): string[] {
  if (typeof value !== "object" || value === null) return [];
  if (seen.has(value)) return [];
  seen.add(value);
  const found: string[] = [];
  for (const [key, child] of Object.entries(value)) {
    const current = prefix.length > 0 ? `${prefix}.${key}` : key;
    if (FORBIDDEN_KEYS.has(key)) found.push(current);
    found.push(...forbiddenKeys(child, current, seen));
  }
  return found;
}

function contactShapeViolations(observation: FogSafeObservation): string[] {
  const violations: string[] = [];
  const lists = [observation.ownUnits, observation.visibleEnemies, observation.lastSeenEnemies, observation.visibleNeutralObjects];
  for (const contact of lists.flat()) {
    for (const key of Object.keys(contact)) {
      if (!CONTACT_KEYS.has(key)) violations.push(`contact contains unapproved field ${key}`);
    }
  }
  const topLevelKeys = Object.keys(observation).sort().join(",");
  if (topLevelKeys !== "lastSeenEnemies,ownUnits,tick,visibleEnemies,visibleNeutralObjects") {
    violations.push(`observation shape is not closed: ${topLevelKeys}`);
  }
  return violations;
}

interface RoundAudit {
  readonly violations: readonly string[];
  readonly hiddenTransitions: number;
  readonly freezeChecks: number;
  readonly snapshot: Snapshot;
}

function auditRound(
  api: GameApi,
  observation: FogSafeObservation,
  previous: FogSafeObservation | undefined,
  production: unknown,
  previousOwnIds: Set<number>,
  previousEnemyTypes: Set<string>,
): RoundAudit {
  const violations = [...contactShapeViolations(observation), ...forbiddenKeys(observation)];
  const hostile = new Set(api.getVisibleUnits(RED_PLAYER, "hostile"));
  const enemy = new Set(api.getVisibleUnits(RED_PLAYER, "enemy"));
  const own = new Set(api.getVisibleUnits(RED_PLAYER, "self"));
  const neutral = new Set([...hostile].filter((id) => !enemy.has(id)));
  if (!sameIds(observation.ownUnits, own)) violations.push("own units do not equal the self API set");
  if (observation.ownUnits.some((contact) => contact.source !== "visible")) violations.push("own unit source is not visible");
  if ([...enemy].some((id) => !hostile.has(id))) violations.push("visible enemy is not a hostile subset");
  if (!sameIds(observation.visibleEnemies, enemy)) violations.push("visible enemy does not equal the enemy API set");
  if (!sameIds(observation.visibleNeutralObjects, neutral)) violations.push("visible neutral is not hostile minus enemy");
  if (observation.lastSeenEnemies.some((contact) => enemy.has(contact.id))) violations.push("last-seen overlaps current enemy");
  if (observation.lastSeenEnemies.some((contact) => contact.source !== "last-seen")) violations.push("last-seen source is not frozen");
  if (observation.visibleEnemies.some((contact) => contact.source !== "visible")) violations.push("visible enemy source is not visible");

  const previousContacts = new Map<number, FogSafeContact>();
  for (const contact of previous?.visibleEnemies ?? []) previousContacts.set(contact.id, contact);
  for (const contact of previous?.lastSeenEnemies ?? []) previousContacts.set(contact.id, contact);
  const currentLastSeen = new Map(observation.lastSeenEnemies.map((contact) => [contact.id, contact]));
  let hiddenTransitions = 0;
  let freezeChecks = 0;
  for (const [id, prior] of previousContacts) {
    if (enemy.has(id)) continue;
    const frozen = currentLastSeen.get(id);
    freezeChecks += 1;
    if (prior.source === "visible") hiddenTransitions += 1;
    if (frozen === undefined) {
      violations.push(`hidden contact ${id} disappeared from last-seen memory`);
    } else if (contactState(frozen) !== contactState(prior)) {
      violations.push(`hidden contact ${id} changed while hidden`);
    }
  }

  const snapshot = buildSnapshot(
    api,
    RED_PLAYER,
    production,
    previousOwnIds,
    previousEnemyTypes,
    undefined,
    observation,
  );
  violations.push(...forbiddenKeys(snapshot));
  return { violations, hiddenTransitions, freezeChecks, snapshot };
}

async function auditScenario(scenario: AuditScenario): Promise<AuditSummary> {
  const redBot = new AuditCommanderBot(RED_PLAYER, scenario.myCountry);
  const blueBot = scenario.opponentType === "noop"
    ? new AuditCommanderBot("BlueCommander", "Americans")
    : new SupalosaBot("BlueCommander", "Americans" as never, [RED_PLAYER], false);
  const gameMode = cdapi.getAvailableGameModes(scenario.map)[0];
  if (gameMode === undefined) {
    return {
      ...scenario,
      realCreateGame: false,
      realUpdate: false,
      ticks: 0,
      rounds: 0,
      engineCallbacks: 0,
      decisionCallbacks: 0,
      subsetChecks: 0,
      hiddenTransitions: 0,
      freezeChecks: 0,
      visibleEnemyObservations: 0,
      lastSeenObservations: 0,
      leakCount: 1,
      errors: [`map ${scenario.map} is unavailable`],
    };
  }

  let game: Awaited<ReturnType<typeof cdapi.createGame>> | undefined;
  let ticks = 0;
  let rounds = 0;
  let decisionCallbacks = 0;
  let subsetChecks = 0;
  let hiddenTransitions = 0;
  let freezeChecks = 0;
  let visibleEnemyObservations = 0;
  let lastSeenObservations = 0;
  let leakCount = 0;
  const errors: string[] = [];
  try {
    const settings: CreateOfflineOpts = {
      buildOffAlly: false,
      cratesAppear: false,
      credits: 10000,
      gameMode,
      gameSpeed: 6,
      mapName: scenario.map,
      mcvRepacks: true,
      shortGame: true,
      superWeapons: false,
      unitCount: 10,
      online: false,
      agents: [redBot, blueBot],
    };
    game = await cdapi.createGame(settings);
    const projector = new FogSafeProjector();
    let previousObservation: FogSafeObservation | undefined;
    let previousOwnIds = new Set<number>();
    let previousEnemyTypes = new Set<string>();
    while (!game.isFinished() && ticks < scenario.maxTicks) {
      await game.update();
      ticks += 1;
      const api = redBot.lastGameApi;
      if (api === null) {
        leakCount += 1;
        errors.push(`no red-player GameApi after engine update ${ticks}`);
        break;
      }
      if (ticks !== 1 && ticks % scenario.decisionPeriod !== 0 && !game.isFinished() && ticks !== scenario.maxTicks) continue;
      const player = redBot.playerApi() as { production?: unknown } | null;
      try {
        const result = await withFogSafeObservation(projector, api, RED_PLAYER, (observation) => {
          subsetChecks += 1;
          const round = auditRound(api, observation, previousObservation, player?.production, previousOwnIds, previousEnemyTypes);
          if (round.violations.length > 0) throw new FogSafetyError(round.violations.join("; "));
          hiddenTransitions += round.hiddenTransitions;
          freezeChecks += round.freezeChecks;
          decisionCallbacks += 1;
          return round;
        });
        previousObservation = result.observation;
        previousOwnIds = new Set(api.getVisibleUnits(RED_PLAYER, "self"));
        previousEnemyTypes = new Set(result.result.snapshot.enemyContacts.map((contact) => contact.unitType));
        rounds += 1;
        visibleEnemyObservations += result.observation.visibleEnemies.length;
        lastSeenObservations += result.observation.lastSeenEnemies.length;
      } catch (error) {
        leakCount += 1;
        errors.push(`tick ${api.getCurrentTick()}: ${String(error)}`);
        break;
      }
    }
  } catch (error) {
    leakCount += 1;
    errors.push(String(error));
  } finally {
    game?.dispose();
  }

  return {
    ...scenario,
    realCreateGame: game !== undefined,
    realUpdate: game !== undefined && ticks > 0,
    ticks,
    rounds,
    engineCallbacks: redBot.engineCallbacks,
    decisionCallbacks,
    subsetChecks,
    hiddenTransitions,
    freezeChecks,
    visibleEnemyObservations,
    lastSeenObservations,
    leakCount,
    errors,
  };
}

function invalidSubsetApi(): FogObservationApi {
  return {
    getCurrentTick: () => 1,
    getVisibleUnits: (_playerName, type) => (type === "hostile" ? [2] : [1]),
    getUnitData: () => unit(1),
  };
}

function failingVisibilityApi(): FogObservationApi {
  return {
    getCurrentTick: () => 1,
    getVisibleUnits: () => { throw new Error("injected visibility failure"); },
    getUnitData: () => unit(1),
  };
}

test("audits ten real Chrono Divide offline games through every fair observation round", async () => {
  await cdapi.init(ASSETS_DIR);
  const games = [] as AuditSummary[];
  for (const scenario of SCENARIOS) games.push(await auditScenario(scenario));
  const report = {
    schema: "fog-safe-audit-v1",
    engine: "chronodivide-offline",
    gameCount: games.length,
    leakCount: games.reduce((total, game) => total + game.leakCount, 0),
    games,
  };
  console.log(`[fog-audit] ${JSON.stringify(report)}`);
  assert.equal(report.gameCount, 10);
  assert.equal(report.leakCount, 0, JSON.stringify(report));
  for (const game of games) {
    assert.equal(game.realCreateGame, true, JSON.stringify(game));
    assert.equal(game.realUpdate, true, JSON.stringify(game));
    assert.ok(game.rounds > 0, JSON.stringify(game));
    assert.equal(game.decisionCallbacks, game.subsetChecks, JSON.stringify(game));
    assert.equal(game.errors.length, 0, JSON.stringify(game));
  }
  assert.ok(games.some((game) => game.visibleEnemyObservations > 0), JSON.stringify(report));
  assert.ok(games.some((game) => game.hiddenTransitions > 0), JSON.stringify(report));
  assert.ok(games.some((game) => game.freezeChecks > 0), JSON.stringify(report));
});

test("blocks the decision callback for injected hidden-enemy and visibility failures", async () => {
  for (const api of [invalidSubsetApi(), failingVisibilityApi()]) {
    let decisionCallbacks = 0;
    await assert.rejects(
      () => withFogSafeObservation(new FogSafeProjector(), api, RED_PLAYER, () => {
        decisionCallbacks += 1;
        return "must-not-run";
      }),
      FogSafetyError,
    );
    assert.equal(decisionCallbacks, 0);
  }
});
