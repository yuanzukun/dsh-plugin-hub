import { describe, expect, it } from "vitest";
import {
  RendererBridge,
  RENDERER_PROTOCOL_VERSION,
  type RendererMessageEndpoint,
} from "../src/client/renderer-bridge.ts";

class FakeEndpoint implements RendererMessageEndpoint {
  readonly posted: unknown[] = [];
  private readonly listeners = new Set<(event: { readonly origin: string; readonly source: unknown; readonly data: unknown }) => void>();

  constructor(readonly origin = "https://dsh.test") {}

  postMessage(message: unknown, _targetOrigin: string): void {
    this.posted.push(message);
  }

  addEventListener(_type: "message", listener: (event: { readonly origin: string; readonly source: unknown; readonly data: unknown }) => void): void {
    this.listeners.add(listener);
  }

  get listenerCount(): number {
    return this.listeners.size;
  }

  removeEventListener(_type: "message", listener: (event: { readonly origin: string; readonly source: unknown; readonly data: unknown }) => void): void {
    this.listeners.delete(listener);
  }

  emit(data: unknown, origin = this.origin, source: unknown = this): void {
    for (const listener of this.listeners) listener({ origin, source, data });
  }
}

const identity = {
  sessionId: "session-renderer",
  matchId: "match-renderer",
  seat: "Russians",
  tick: 4,
} as const;

function bridge(endpoint: FakeEndpoint, onObservation?: (value: unknown) => void): RendererBridge {
  return new RendererBridge({
    endpoint,
    targetOrigin: endpoint.origin,
    identity,
    onObservation: onObservation as never,
  });
}

function readyMessage(requestId: string, tick: number = identity.tick): Record<string, unknown> {
  return {
    protocolVersion: RENDERER_PROTOCOL_VERSION,
    sessionId: identity.sessionId,
    matchId: identity.matchId,
    seat: identity.seat,
    tick,
    type: "renderer/ready",
    requestId,
  };
}

function observationMessage(extra: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    protocolVersion: RENDERER_PROTOCOL_VERSION,
    sessionId: identity.sessionId,
    matchId: identity.matchId,
    seat: identity.seat,
    tick: 5,
    type: "renderer/observation",
    observation: {
      tick: 5,
      ownUnits: [],
      visibleEnemies: [],
      lastSeenEnemies: [],
      visibleNeutralObjects: [],
    },
    ...extra,
  };
}

function deliver(
  endpoint: FakeEndpoint,
  instance: RendererBridge,
  data: unknown,
  origin = endpoint.origin,
  source: unknown = endpoint,
): boolean {
  return instance.handleMessage({ origin, source, data });
}

describe("loopback companion renderer bridge", () => {
  it("rejects observations before handshake", () => {
    const endpoint = new FakeEndpoint();
    const observed: unknown[] = [];
    const instance = bridge(endpoint, (value) => observed.push(value));
    expect(deliver(endpoint, instance, observationMessage())).toBe(false);
    expect(instance.currentTick).toBe(identity.tick);
    expect(observed).toHaveLength(0);
    instance.dispose();
  });

  it("rejects observations after disconnect", async () => {
    const endpoint = new FakeEndpoint();
    const observed: unknown[] = [];
    const instance = bridge(endpoint, (value) => observed.push(value));
    const connected = instance.connect();
    const hello = endpoint.posted[0] as Record<string, unknown>;
    endpoint.emit(readyMessage(String(hello.requestId)));
    await connected;
    endpoint.emit({
      protocolVersion: 1,
      sessionId: identity.sessionId,
      matchId: identity.matchId,
      seat: identity.seat,
      tick: 5,
      type: "renderer/disconnected",
      reason: "adapter closed",
    });
    expect(deliver(endpoint, instance, observationMessage())).toBe(false);
    expect(instance.currentTick).toBe(identity.tick);
    expect(observed).toHaveLength(0);
    instance.dispose();
  });

  it("fails fast for an already-aborted handshake without posting", async () => {
    const endpoint = new FakeEndpoint();
    const instance = bridge(endpoint);
    const controller = new AbortController();
    controller.abort();
    await expect(instance.connect(controller.signal)).rejects.toMatchObject({ code: "CANCELLED" });
    expect(endpoint.posted).toHaveLength(0);
    expect(instance.state).toBe("idle");
    instance.dispose();
  });

  it("fails fast for an already-aborted command without posting", async () => {
    const endpoint = new FakeEndpoint();
    const instance = bridge(endpoint);
    const connected = instance.connect();
    const hello = endpoint.posted[0] as Record<string, unknown>;
    endpoint.emit(readyMessage(String(hello.requestId)));
    await connected;
    const controller = new AbortController();
    controller.abort();
    await expect(instance.sendCommand({ type: "orders", orders: [] }, controller.signal)).rejects.toMatchObject({ code: "CANCELLED" });
    expect(endpoint.posted).toHaveLength(1);
    instance.dispose();
  });

  it("attaches only when requested and removes the listener on dispose", () => {
    const endpoint = new FakeEndpoint();
    const instance = new RendererBridge({
      endpoint,
      targetOrigin: endpoint.origin,
      identity,
      autoAttach: false,
    });
    expect(endpoint.listenerCount).toBe(0);
    instance.attach();
    instance.attach();
    expect(endpoint.listenerCount).toBe(1);
    instance.dispose();
    expect(endpoint.listenerCount).toBe(0);
  });

  it("handshakes with one session, match, seat and monotonic tick", async () => {
    const endpoint = new FakeEndpoint();
    const observed: unknown[] = [];
    const instance = bridge(endpoint, (value) => observed.push(value));
    const connected = instance.connect();
    const hello = endpoint.posted[0] as Record<string, unknown>;
    expect(hello).toMatchObject({
      protocolVersion: 1,
      sessionId: identity.sessionId,
      matchId: identity.matchId,
      seat: identity.seat,
      tick: 4,
      type: "renderer/hello",
    });
    endpoint.emit(readyMessage(String(hello.requestId)));
    await connected;
    expect(instance.state).toBe("ready");

    expect(deliver(endpoint, instance, observationMessage())).toBe(true);
    expect(instance.currentTick).toBe(5);
    expect(observed).toHaveLength(1);
    expect(deliver(endpoint, instance, observationMessage())).toBe(true);
    instance.dispose();
  });

  it("rejects origin, source, identity and hidden-state payloads", async () => {
    const endpoint = new FakeEndpoint();
    const instance = bridge(endpoint);
    const connected = instance.connect();
    const hello = endpoint.posted[0] as Record<string, unknown>;
    endpoint.emit(readyMessage(String(hello.requestId)));
    await connected;

    expect(deliver(endpoint, instance, observationMessage(), "https://evil.test")).toBe(false);
    expect(deliver(endpoint, instance, observationMessage(), endpoint.origin, {})).toBe(false);
    expect(deliver(endpoint, instance, { ...observationMessage(), sessionId: "other-session" })).toBe(false);
    expect(deliver(endpoint, instance, observationMessage({ enemyStartLocation: { x: 99, y: 99 } }))).toBe(false);
    expect(deliver(endpoint, instance, observationMessage({ tick: 6 }))).toBe(false);
    expect(instance.lastError?.code).toBe("INVALID_MESSAGE");
    instance.dispose();
  });

  it("sends same-match commands, acknowledges them, and supports cancellation", async () => {
    const endpoint = new FakeEndpoint();
    const instance = bridge(endpoint);
    const connected = instance.connect();
    const hello = endpoint.posted[0] as Record<string, unknown>;
    endpoint.emit(readyMessage(String(hello.requestId)));
    await connected;

    const commandPromise = instance.sendCommand({ type: "orders", orders: [{ action: "move", x: 3, y: 4 }] });
    const command = endpoint.posted.at(-1) as Record<string, unknown>;
    expect(command).toMatchObject({
      type: "renderer/command",
      sessionId: identity.sessionId,
      matchId: identity.matchId,
      seat: identity.seat,
      tick: 4,
    });
    endpoint.emit({
      protocolVersion: command.protocolVersion,
      sessionId: command.sessionId,
      matchId: command.matchId,
      seat: command.seat,
      type: "renderer/command-ack",
      tick: 5,
      requestId: command.requestId,
      ok: true,
      detail: "applied to same match",
    });
    await expect(commandPromise).resolves.toMatchObject({ ok: true, tick: 5 });

    const createPromise = instance.sendCommand({
      type: "create-match",
      map: "current",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "normal",
      gameSpeed: 0,
    });
    const createCommand = endpoint.posted.at(-1) as Record<string, unknown>;
    expect(createCommand).toMatchObject({
      type: "renderer/command",
      command: { type: "create-match", opponentType: "normal", gameSpeed: 0 },
    });
    endpoint.emit({
      protocolVersion: createCommand.protocolVersion,
      sessionId: createCommand.sessionId,
      matchId: createCommand.matchId,
      seat: createCommand.seat,
      type: "renderer/command-ack",
      tick: 5,
      requestId: createCommand.requestId,
      ok: true,
      detail: "created with normal opponent",
    });
    await expect(createPromise).resolves.toMatchObject({ ok: true, tick: 5 });

    const controller = new AbortController();
    const cancelled = instance.sendCommand({ type: "orders", orders: [{ action: "move", x: 1, y: 1 }] }, controller.signal);
    controller.abort();
    await expect(cancelled).rejects.toMatchObject({ code: "CANCELLED" });
    expect(endpoint.posted.at(-1)).toMatchObject({ type: "renderer/cancel" });
    instance.dispose();
  });

  it("returns only the exact tool result and rejects extra enemy fields", async () => {
    const endpoint = new FakeEndpoint();
    const instance = bridge(endpoint);
    const connected = instance.connect();
    const hello = endpoint.posted[0] as Record<string, unknown>;
    endpoint.emit(readyMessage(String(hello.requestId)));
    await connected;

    const valid = instance.sendCommand({ type: "tool", request: { tool: "red_alert_lobby_players" } });
    const validCommand = endpoint.posted.at(-1) as Record<string, unknown>;
    endpoint.emit({
      protocolVersion: 1,
      sessionId: identity.sessionId,
      matchId: identity.matchId,
      seat: identity.seat,
      type: "renderer/command-ack",
      tick: 5,
      requestId: validCommand.requestId,
      ok: true,
      detail: "public players",
      toolResult: { players: [{ name: "Enemy", self: false, ai: true, defeated: false, allied: false }] },
    });
    await expect(valid).resolves.toMatchObject({
      tick: 5,
      toolResult: { players: [{ name: "Enemy", self: false, ai: true, defeated: false, allied: false }] },
    });

    const invalid = instance.sendCommand({ type: "tool", request: { tool: "red_alert_lobby_players" } });
    const invalidCommand = endpoint.posted.at(-1) as Record<string, unknown>;
    endpoint.emit({
      protocolVersion: 1,
      sessionId: identity.sessionId,
      matchId: identity.matchId,
      seat: identity.seat,
      type: "renderer/command-ack",
      tick: 6,
      requestId: invalidCommand.requestId,
      ok: true,
      detail: "must be rejected",
      toolResult: { players: [{ name: "Enemy", self: false, ai: true, defeated: false, allied: false, startLocation: { x: 90, y: 90 } }] },
    });
    await expect(invalid).rejects.toMatchObject({ code: "INVALID_MESSAGE" });
    expect(instance.currentTick).toBe(5);
    instance.dispose();
  });

  it("keeps the bridge ready when a renderer rejects one tool command", async () => {
    const endpoint = new FakeEndpoint();
    const instance = bridge(endpoint);
    const connected = instance.connect();
    const hello = endpoint.posted[0] as Record<string, unknown>;
    endpoint.emit(readyMessage(String(hello.requestId)));
    await connected;

    const rejected = instance.sendCommand({ type: "tool", request: { tool: "red_alert_construction_catalog" } });
    const command = endpoint.posted.at(-1) as Record<string, unknown>;
    endpoint.emit({
      protocolVersion: 1,
      sessionId: identity.sessionId,
      matchId: identity.matchId,
      seat: identity.seat,
      type: "renderer/command-ack",
      tick: 6,
      requestId: command.requestId,
      ok: false,
      detail: "building is not currently available to this seat",
    });

    await expect(rejected).rejects.toMatchObject({
      code: "COMMAND_REJECTED",
      message: "building is not currently available to this seat",
    });
    expect(instance.currentTick).toBe(6);
    expect(instance.state).toBe("ready");
    instance.dispose();
  });

  it("handles disconnect/reconnect and releases the transport", async () => {
    const endpoint = new FakeEndpoint();
    const instance = bridge(endpoint);
    const connected = instance.connect();
    const hello = endpoint.posted[0] as Record<string, unknown>;
    endpoint.emit(readyMessage(String(hello.requestId)));
    await connected;
    endpoint.emit({
      protocolVersion: 1,
      sessionId: identity.sessionId,
      matchId: identity.matchId,
      seat: identity.seat,
      tick: 5,
      type: "renderer/disconnected",
      reason: "adapter closed",
    });
    expect(instance.state).toBe("disconnected");

    const reconnected = instance.connect();
    const reconnectHello = endpoint.posted.at(-1) as Record<string, unknown>;
    endpoint.emit(readyMessage(String(reconnectHello.requestId), 5));
    await reconnected;
    expect(instance.state).toBe("ready");

    instance.dispose();
    expect(instance.state).toBe("disposed");
    expect(deliver(endpoint, instance, observationMessage())).toBe(false);
    await expect(instance.sendCommand({ type: "orders", orders: [] })).rejects.toMatchObject({ code: "DISPOSED" });
  });

  it("rejects a pending handshake when the renderer disconnects", async () => {
    const endpoint = new FakeEndpoint();
    const instance = bridge(endpoint);
    const connected = instance.connect();
    endpoint.emit({
      protocolVersion: 1,
      sessionId: identity.sessionId,
      matchId: identity.matchId,
      seat: identity.seat,
      tick: identity.tick,
      type: "renderer/disconnected",
      reason: "renderer closed before ready",
    });
    await expect(connected).rejects.toMatchObject({ code: "DISCONNECTED" });
    expect(instance.state).toBe("disconnected");
    instance.dispose();
  });

  it("rejects stale observations", async () => {
    const endpoint = new FakeEndpoint();
    const instance = bridge(endpoint);
    const connected = instance.connect();
    const hello = endpoint.posted[0] as Record<string, unknown>;
    endpoint.emit(readyMessage(String(hello.requestId)));
    await connected;
    expect(deliver(endpoint, instance, observationMessage())).toBe(true);
    expect(deliver(endpoint, instance, { ...observationMessage(), tick: 4, observation: { ...(observationMessage().observation as object), tick: 4 } })).toBe(false);
    expect(instance.lastError?.message).toContain("stale");
    instance.dispose();
  });
});
