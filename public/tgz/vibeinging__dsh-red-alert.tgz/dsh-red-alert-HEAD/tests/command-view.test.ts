import { describe, expect, it } from "vitest";
import type { FogSafeContact } from "../packages/game-host/src/fog-safe-observation.ts";
import {
  BROWSER_TRANSPORT_PROTOCOL_VERSION,
  type BrowserCommandReceipt,
} from "../src/browser-command-protocol.ts";
import { MAX_COMMAND_VIEW_CONTACTS, compactCommandView } from "../src/command-view.ts";

function contact(id: number, source: "visible" | "last-seen" = "visible"): FogSafeContact {
  return {
    id,
    unitType: "E1",
    label: "Conscript",
    kind: "Infantry",
    position: { x: id, y: id + 1 },
    hpPct: 80,
    observedAtTick: 30,
    source,
  };
}

describe("compact browser command view", () => {
  it("returns a bounded fog-safe state and drops display-only fields", () => {
    const receipt: BrowserCommandReceipt = {
      protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
      requestId: "request",
      sessionId: "session",
      matchId: "match",
      seat: "Russians",
      tick: 40,
      ok: true,
      detail: "completed",
      match: {
        map: "mp02t2.map",
        mapSize: { width: 64, height: 64 },
        myCountry: "Russians",
        status: "active",
        self: { credits: 2_000, power: { total: 100, drain: 60, isLowPower: false }, defeated: false },
      },
      observation: {
        tick: 40,
        ownUnits: Array.from({ length: 129 }, (_, index) => contact(index + 1)),
        visibleEnemies: [contact(200)],
        lastSeenEnemies: [contact(201, "last-seen")],
        visibleNeutralObjects: [],
      },
    };

    const view = compactCommandView(receipt) as {
      readonly tick: number;
      readonly own: { readonly total: number; readonly truncated: boolean; readonly contacts: readonly Record<string, unknown>[] };
      readonly visibleEnemies: { readonly total: number };
      readonly lastSeenEnemies: { readonly total: number };
    };
    expect(view.tick).toBe(40);
    expect(view.own).toMatchObject({ total: 129, truncated: true });
    expect(view.own.contacts).toHaveLength(MAX_COMMAND_VIEW_CONTACTS);
    expect(view.visibleEnemies.total).toBe(1);
    expect(view.lastSeenEnemies.total).toBe(1);
    expect(view.own.contacts[0]).toEqual({ id: 1, type: "E1", kind: "Infantry", x: 1, y: 2, hpPct: 80, observedAtTick: 30 });
    expect(JSON.stringify(view)).not.toMatch(/Conscript|label|source/);
  });

  it("returns no state when a receipt is not an atomic match snapshot", () => {
    expect(compactCommandView({
      protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
      requestId: "request",
      sessionId: "session",
      matchId: "match",
      seat: "Russians",
      tick: 0,
      ok: true,
      detail: "connected",
    })).toBeUndefined();
  });
});
