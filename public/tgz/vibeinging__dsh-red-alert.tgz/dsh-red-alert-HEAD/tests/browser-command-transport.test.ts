import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { runInNewContext } from "node:vm";
import { describe, expect, it, vi } from "vitest";
import { Context } from "@deepseek-ai/cordis";
import type { HostConnectionHandle, HostConnectionRpc } from "@deepseek-ai/dsh-client-connection";
import type { ClientConnectionRpc, ConnectionHandle, IApiClient, RpcResult } from "@deepseek-ai/dsh-client-connection/client";
import type { ISessions } from "@deepseek-ai/dsh-client-runtime/client";
import { Session, SessionId, SessionStore } from "@deepseek-ai/dsh-session";
import { SessionProjectionRegistry } from "@deepseek-ai/dsh-session-projection";
import type { SessionEvent } from "@deepseek-ai/dsh-session";
import {
  applyBrowserCommandProjection,
  emptyBrowserCommandProjection,
  redAlertCommandProjection,
} from "../src/projection.ts";
import {
  BROWSER_TRANSPORT_PROTOCOL_VERSION,
  RED_ALERT_BROWSER_COMMAND_EVENT,
  RED_ALERT_BROWSER_COMMAND_PUBLISHED_EVENT,
  RED_ALERT_BROWSER_COMMAND_RESULT_EVENT,
  RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT,
  MAX_BROWSER_ORDERS,
  decodeBrowserCommand,
  decodeBrowserRendererConfigValue,
  decodeBrowserToolResult,
  type BrowserCommandProjectionFoldState,
  type BrowserCommandProjectionState,
  type BrowserCommandReceipt,
} from "../src/browser-command-protocol.ts";
import {
  BrowserAdapterRegistry,
  BrowserCommandClientConsumer,
  BrowserCommandClientService,
  type BrowserMatchAdapter,
} from "../src/client/browser-command-consumer.ts";
import {
  BrowserCommandTransport,
  type BrowserCommandTransportOptions,
} from "../src/browser-command-transport.ts";

type RpcHandler = (endpoint: string, payload: unknown, signal: AbortSignal) => Promise<RpcResult<unknown>>;

class FakeConnection {
  handler: RpcHandler | undefined;
  disposed = false;
  unregisterCalls = 0;
  unregisterFailure: Error | undefined;
  unregisterGate: Promise<void> | undefined;
  onUnregister: (() => void) | undefined;
  readonly calls: string[] = [];
  readonly hostRpc: HostConnectionRpc = {
    handle: (channel, handler, options) => {
      expect(channel).toBe("/red-alert");
      expect(options.authority).toBe("loopback");
      this.handler = handler;
      return async () => {
        this.unregisterCalls += 1;
        this.onUnregister?.();
        if (this.unregisterGate !== undefined) await this.unregisterGate;
        this.disposed = true;
        this.handler = undefined;
        if (this.unregisterFailure !== undefined) throw this.unregisterFailure;
      };
    },
    intercept: () => { throw new Error("unexpected shared API interception"); },
  };
  readonly clientRpc: ClientConnectionRpc = {
    call: (channel, endpoint, payload, signal) => {
      this.calls.push(endpoint);
      if (channel !== "/red-alert" || this.handler === undefined) return Promise.resolve({ ok: false, error: { code: "internal", message: "no channel", details: {} } } as RpcResult<unknown>);
      return this.handler(endpoint, payload, signal ?? new AbortController().signal);
    },
  };
  readonly connection = { rpc: this.hostRpc } as HostConnectionHandle;
}

class Value<T> {
  private readonly listeners = new Set<() => void>();

  constructor(private value: T) {}

  getSnapshot(): T {
    return this.value;
  }

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  set(value: T): void {
    this.value = value;
    for (const listener of this.listeners) listener();
  }

  get listenerCount(): number {
    return this.listeners.size;
  }
}

interface FakeSessionState {
  readonly session: Session;
  readonly events: SessionEvent[];
  readonly commandProjection: Value<BrowserCommandProjectionState>;
  commandFold: BrowserCommandProjectionFoldState;
  readonly stateProjection: Value<unknown>;
  publishCommandProjection?: (value: BrowserCommandProjectionState, seq: number) => void;
  flushGate?: Promise<void>;
  flushFailure?: Error;
  appendFailure?: { readonly type: string; readonly error: Error };
}

function fakeSession(id = "session-browser"): FakeSessionState {
  const events: SessionEvent[] = [];
  const commandProjection = new Value<BrowserCommandProjectionState>(emptyBrowserCommandProjection().visible);
  const stateProjection = new Value<unknown>({
    status: "running",
    match: { matchId: "match-browser", seat: "Russians", tick: 4, status: "active" },
  });
  let state!: FakeSessionState;
  const session = {
    id: id as SessionId,
    events,
    append(type: string, data: unknown) {
      if (state.appendFailure?.type === type) throw state.appendFailure.error;
      const event = { type, seq: events.length, time: events.length + 1, data } as SessionEvent;
      events.push(event);
      state.commandFold = applyBrowserCommandProjection(state.commandFold, event);
      state.commandProjection.set(state.commandFold.visible);
      state.publishCommandProjection?.(state.commandFold.visible, event.seq);
      return event;
    },
  } as unknown as Session;
  state = { session, events, commandProjection, commandFold: emptyBrowserCommandProjection(), stateProjection };
  return state;
}

function publishNewEvents(state: FakeSessionState, seen: { value: number }): void {
  seen.value = state.events.length;
}

interface OfficialSessionFixture {
  readonly context: Context;
  readonly sessions: ISessions & {
    refresh(): Promise<void>;
    open(id: SessionId): void;
    binding(id: SessionId): { readonly sessionId: SessionId; readonly session: { readonly projections: { faceOf(key: string): { getSnapshot(): unknown } } } } | undefined;
    handleMuxEnvelope(envelope: unknown): void;
  };
  readonly sessionId: SessionId;
}

type OfficialSessionRuntimeConstructor = new (context: Context, api: IApiClient, remote: { readonly commands: unknown }) => OfficialSessionFixture["sessions"];

function loadOfficialRuntime(): { readonly SessionRuntime: OfficialSessionRuntimeConstructor } {
  const packageRequire = createRequire(import.meta.url);
  const source = readFileSync(packageRequire.resolve("@deepseek-ai/dsh-client-runtime/client"), "utf8");
  let handoff: { readonly factory: (require: (specifier: string) => unknown) => Record<string, unknown> } | undefined;
  runInNewContext(source, {
    queueMicrotask,
    window: {
      __ModuleLoader__: {
        load(value: { readonly factory: (require: (specifier: string) => unknown) => Record<string, unknown> }): void {
          handoff = value;
        },
      },
    },
  });
  if (handoff === undefined) throw new Error("official runtime did not register a client handoff");
  type FallbackModule = ((...args: readonly unknown[]) => unknown) & Record<string, unknown>;
  let fallback: FallbackModule;
  function fallbackModule(..._args: readonly unknown[]): unknown {
    return fallback;
  }
  fallback = new Proxy(fallbackModule as FallbackModule, {
    get: () => fallback,
    apply: () => fallback,
    construct: () => fallback,
  });
  const tolerantRequire = (specifier: string): unknown => {
    try {
      return packageRequire(specifier);
    } catch {
      return fallback;
    }
  };
  const runtime = handoff.factory(tolerantRequire);
  if (typeof runtime.SessionRuntime !== "function") throw new Error("official runtime did not expose SessionRuntime");
  return { SessionRuntime: runtime.SessionRuntime as OfficialSessionRuntimeConstructor };
}

function loadOfficialConnectionRpc(connection: FakeConnection): ClientConnectionRpc {
  const packageRequire = createRequire(import.meta.url);
  const source = readFileSync(packageRequire.resolve("@deepseek-ai/dsh-client-connection/client"), "utf8");
  let handoff: { readonly factory: (require: (specifier: string) => unknown) => Record<string, unknown> } | undefined;
  const fetch = async (_input: unknown, init?: { readonly body?: unknown; readonly signal?: AbortSignal }) => {
    const message = JSON.parse(String(init?.body)) as { readonly rpcId: string; readonly method: string; readonly payload: unknown };
    const result = await connection.clientRpc.call("/red-alert", message.method, message.payload, init?.signal ?? new AbortController().signal);
    return { ok: true, json: async () => ({ type: "server-response", rpcId: message.rpcId, result }) };
  };
  runInNewContext(source, {
    URL,
    URLSearchParams,
    AbortController,
    crypto: globalThis.crypto,
    fetch,
    queueMicrotask,
    window: {
      __ModuleLoader__: {
        load(value: { readonly factory: (require: (specifier: string) => unknown) => Record<string, unknown> }): void {
          handoff = value;
        },
      },
    },
  });
  if (handoff === undefined) throw new Error("official connection did not register a client handoff");
  type FallbackModule = ((...args: readonly unknown[]) => unknown) & Record<string, unknown>;
  let fallback: FallbackModule;
  function fallbackModule(..._args: readonly unknown[]): unknown {
    return fallback;
  }
  fallback = new Proxy(fallbackModule as FallbackModule, {
    get: () => fallback,
    apply: () => fallback,
    construct: () => fallback,
  });
  const tolerantRequire = (specifier: string): unknown => {
    try {
      return packageRequire(specifier);
    } catch {
      return fallback;
    }
  };
  const runtime = handoff.factory(tolerantRequire);
  if (typeof runtime.apply !== "function") throw new Error("official connection did not expose apply");
  const context = new Context();
  (runtime.apply as (context: Context) => void)(context);
  return (context.get("connection") as unknown as ConnectionHandle).rpc;
}

async function officialSessionFixture(sessionId = "session-browser" as SessionId): Promise<OfficialSessionFixture> {
  const summary = {
    sessionId,
    updatedAt: 1,
    running: true,
    blank: false,
  };
  const api = {
    sessions: {
      list: async () => ({ result: { ok: true, value: { items: [summary] } } }),
      history: async () => ({ result: { ok: true, value: { events: [], hasMore: false, projections: { asOfSeq: 0, values: {} } } } }),
    },
  } as unknown as IApiClient;
  const context = new Context();
  const sessions = new (loadOfficialRuntime().SessionRuntime)(context, api, { commands: {} });
  await sessions.refresh();
  sessions.open(sessionId);
  const binding = sessions.binding(sessionId);
  if (binding === undefined) throw new Error("official SessionRuntime did not resolve the session binding");
  expect(binding.sessionId).toBe(sessionId);
  expect(binding.session.projections.faceOf("redAlert").getSnapshot()).toBeUndefined();
  return { context, sessions, sessionId };
}

function publishOfficialProjection(fixture: OfficialSessionFixture, key: string, value: unknown, seq: number): void {
  fixture.sessions.handleMuxEnvelope({
    rpcId: `fixture-${seq}`,
    payload: { type: "session/projection", sessionId: fixture.sessionId, key, value, seq },
  } as never);
}

function makeTransport(
  connection: FakeConnection,
  state: FakeSessionState,
  seen: { value: number },
  overrides: Partial<BrowserCommandTransportOptions> = {},
): BrowserCommandTransport {
  return new BrowserCommandTransport({
    connection: connection.connection,
    flush: async (session) => {
      if (state.flushGate !== undefined) await state.flushGate;
      if (state.flushFailure !== undefined) throw state.flushFailure;
      await new Promise<void>((resolve) => {
        queueMicrotask(() => {
          resolve();
          queueMicrotask(() => publishNewEvents(state, seen));
        });
      });
      void session;
    },
    isSessionOwner: () => true,
    resolveAuthority: () => ({ matchId: "match-browser", seat: "Russians", tick: 4, status: "active" }),
    resolveSession: () => state.session,
    timeoutMs: 100,
    requestId: () => "request-browser-1",
    ...overrides,
  });
}

function runningSessionPorts(state: FakeSessionState): ISessions {
  const list = new Value({ current: state.session.id });
  const binding = {
    session: {
      projections: {
        faceOf(key: string) {
          if (key === "redAlert") return state.stateProjection;
          return state.commandProjection;
        },
      },
    },
  };
  return {
    list,
    binding: () => binding,
  } as unknown as ISessions;
}

function successReceipt(command: { requestId: string; sessionId: string; matchId: string; seat: string; expectedTick: number }): BrowserCommandReceipt {
  return {
    protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
    requestId: command.requestId,
    sessionId: command.sessionId,
    matchId: command.matchId,
    seat: command.seat,
    tick: command.expectedTick + 1,
    ok: true,
    detail: "fake adapter applied command",
  };
}

describe("D3 browser command transport", () => {
  it("accepts only game speeds from 0 through 6 on create-match commands", () => {
    const command = {
      protocolVersion: 1,
      requestId: "request-speed",
      sessionId: "session-speed",
      matchId: "match-speed",
      seat: "Russians",
      expectedTick: 0,
      kind: "create-match",
      request: { map: "current", myCountry: "Russians", opponents: 1, opponentType: "normal", gameSpeed: 0 },
    } as const;
    expect(decodeBrowserCommand(command)).toMatchObject({ request: { gameSpeed: 0 } });
    expect(() => decodeBrowserCommand({ ...command, adapterAttachDeadlineMs: 1_800_000_000_000 })).toThrow(/unknown fields/);
    expect(() => decodeBrowserCommand({ ...command, request: { ...command.request, gameSpeed: -1 } })).toThrow(/game speed is invalid/);
    expect(() => decodeBrowserCommand({ ...command, request: { ...command.request, gameSpeed: 7 } })).toThrow(/game speed is invalid/);
    expect(() => decodeBrowserCommand({ ...command, request: { ...command.request, gameSpeed: 1.5 } })).toThrow(/game speed is invalid/);
  });

  it("rejects incomplete rectangles and tool results with fields outside the exact wrapper", () => {
    const identity = {
      protocolVersion: 1,
      requestId: "request-exact-tool",
      sessionId: "session-exact-tool",
      matchId: "match-browser",
      seat: "Russians",
      expectedTick: 4,
      kind: "tool",
    } as const;
    expect(() => decodeBrowserCommand({
      ...identity,
      request: { tool: "red_alert_map", x: 1, y: 2, width: 4 },
    })).toThrow(/rectangle is incomplete/);
    expect(() => decodeBrowserCommand({
      ...identity,
      request: { tool: "red_alert_resources", x: 1, y: 2, width: 17, height: 1 },
    })).toThrow(/resources request is invalid/);
    expect(() => decodeBrowserToolResult({ tool: "red_alert_lobby_players" }, {
      players: [{ name: "Enemy", self: false, ai: true, defeated: false, allied: false, credits: 99_999 }],
    })).toThrow(/result is invalid/);
    expect(decodeBrowserToolResult({ tool: "red_alert_lobby_players" }, {
      players: [{ name: "Enemy", self: false, ai: true, defeated: false, allied: false }],
    })).toEqual({ players: [{ name: "Enemy", self: false, ai: true, defeated: false, allied: false }] });
    expect(decodeBrowserToolResult({ tool: "red_alert_construction", operation: "place", name: "NAPOWR", x: 134, y: 79 }, {
      operation: "place", accepted: true, placement: { x: 138, y: 79 },
    })).toEqual({ operation: "place", accepted: true, placement: { x: 138, y: 79 } });
    expect(() => decodeBrowserToolResult({ tool: "red_alert_construction", operation: "place", name: "NAPOWR", x: 134, y: 79 }, {
      operation: "place", accepted: true,
    })).toThrow(/result is invalid/);
  });

  it("rejects a hidden field in an exact tool receipt before durable publication", async () => {
    const connection = new FakeConnection();
    const state = fakeSession("session-tool-result-boundary");
    const seen = { value: 0 };
    const transport = makeTransport(connection, state, seen, {
      isSessionOwner: (sessionId) => sessionId === String(state.session.id),
      requestId: () => "request-tool-result-boundary",
    });
    transport.start();
    const leaseResult = await connection.clientRpc.call("/red-alert", "lease/register", {
      protocolVersion: 1,
      sessionId: state.session.id,
      matchId: "match-browser",
      seat: "Russians",
      clientInstanceId: "client-tool-result-boundary",
    });
    expect(leaseResult.ok).toBe(true);
    if (!leaseResult.ok) return;
    const leaseToken = (leaseResult.value as { readonly leaseToken: string }).leaseToken;
    const abort = new AbortController();
    const command = transport.dispatch(state.session, {
      matchId: "match-browser",
      seat: "Russians",
      expectedTick: 4,
      kind: "tool",
      request: { tool: "red_alert_lobby_players" },
    }, abort.signal);
    for (let attempt = 0; attempt < 10 && state.commandProjection.getSnapshot().status !== "pending"; attempt += 1) {
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
    }
    const rejected = await connection.clientRpc.call("/red-alert", "receipt", {
      protocolVersion: 1,
      requestId: "request-tool-result-boundary",
      sessionId: state.session.id,
      matchId: "match-browser",
      seat: "Russians",
      tick: 5,
      ok: true,
      detail: "malformed exact result",
      toolResult: { players: [{ name: "Enemy", self: false, ai: true, defeated: false, allied: false, credits: 99_999 }] },
      leaseToken,
    });
    expect(rejected).toMatchObject({ ok: false, error: { code: "internal" } });
    expect(JSON.stringify(state.events)).not.toContain("99999");
    abort.abort();
    await expect(command).rejects.toMatchObject({ code: "CANCELLED" });
    await transport.dispose();
  });

  it("serves renderer config through live RPC without durable URL state", async () => {
    const connection = new FakeConnection();
    const state = fakeSession("session-live-renderer-config");
    const seen = { value: 0 };
    const transport = makeTransport(connection, state, seen, {
      resolveRendererConfig: (sessionId) => ({
        protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
        sessionId,
        matchId: "match-browser",
        seat: "Russians",
        url: "http://localhost:45678/",
        port: 45678,
      }),
    });
    transport.start();
    const lease = await connection.clientRpc.call("/red-alert", "lease/register", {
      protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
      sessionId: state.session.id,
      matchId: "match-browser",
      seat: "Russians",
      clientInstanceId: "client-live-renderer-config",
    });
    expect(lease.ok).toBe(true);
    if (!lease.ok) return;
    const leaseToken = (lease.value as { readonly leaseToken: string }).leaseToken;
    const config = await connection.clientRpc.call("/red-alert", "renderer/config", {
      protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
      sessionId: state.session.id,
      matchId: "match-browser",
      seat: "Russians",
      leaseToken,
    });
    expect(config).toMatchObject({ ok: true, value: { url: "http://localhost:45678/", port: 45678 } });
    if (config.ok) expect(decodeBrowserRendererConfigValue(config.value)).toMatchObject({ url: "http://localhost:45678/" });
    expect(() => decodeBrowserRendererConfigValue({
      protocolVersion: 1,
      sessionId: state.session.id,
      matchId: "match-browser",
      seat: "Russians",
      url: "http://127.0.0.1:45678/",
      port: 45678,
    })).toThrow(/isolated loopback/);
    expect(JSON.stringify(state.events)).not.toContain("localhost:45678");

    const stale = await connection.clientRpc.call("/red-alert", "renderer/config", {
      protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
      sessionId: state.session.id,
      matchId: "match-browser",
      seat: "Russians",
      leaseToken: "wrong-lease",
    });
    expect(stale.ok).toBe(false);
    await transport.dispose();
  });

  it("releases the finished match lease before configuring a rematch in the same session", async () => {
    const connection = new FakeConnection();
    const state = fakeSession("session-live-renderer-rematch");
    const seen = { value: 0 };
    let authority = { matchId: "match-browser", seat: "Russians", tick: 4, status: "active" as const };
    const transport = makeTransport(connection, state, seen, {
      resolveAuthority: () => authority,
      resolveRendererConfig: (sessionId) => ({
        protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
        sessionId,
        matchId: authority.matchId,
        seat: authority.seat,
        url: "http://localhost:45678/",
        port: 45678,
      }),
    });
    transport.start();
    const consumer = new BrowserCommandClientConsumer({
      rpc: connection.clientRpc,
      sessions: runningSessionPorts(state),
      clientInstanceId: "client-live-renderer-rematch",
    });
    consumer.start();

    await expect(consumer.rendererConfig({ sessionId: String(state.session.id), matchId: authority.matchId, seat: authority.seat, tick: authority.tick })).resolves.toMatchObject({ matchId: "match-browser" });
    authority = { matchId: "match-rematch", seat: "Russians", tick: 0, status: "active" };
    await expect(consumer.rendererConfig({ sessionId: String(state.session.id), matchId: authority.matchId, seat: authority.seat, tick: authority.tick })).resolves.toMatchObject({ matchId: "match-rematch" });
    expect(connection.calls.slice(0, 5)).toEqual(["lease/register", "renderer/config", "lease/release", "lease/register", "renderer/config"]);

    await consumer.dispose();
    await transport.dispose();
  });

  it("rebinds a ready root renderer when the same session starts a new match", async () => {
    const bootstrapContainer = {
      setAttribute: vi.fn(),
      style: {},
      remove: vi.fn(),
    } as unknown as HTMLDivElement;
    vi.stubGlobal("document", {
      createElement: vi.fn(() => bootstrapContainer),
      body: { append: vi.fn() },
    });
    const state = fakeSession("session-root-renderer-rematch");
    state.stateProjection.set({
      status: "stopped",
      match: { matchId: "match-finished", seat: "Russians", tick: 20, status: "finished" },
    });
    const context = new Context();
    const service = new BrowserCommandClientService(context, {
      rpc: { call: async () => ({ ok: true, value: { released: true } }) },
      sessions: runningSessionPorts(state),
      clientInstanceId: "client-root-renderer-rematch",
    });
    let activeMatchId = "match-finished";
    const attachRenderer = vi.fn(async (_container: HTMLElement, identity: { readonly matchId: string }) => {
      activeMatchId = identity.matchId;
    });
    service.renderer.register(String(state.session.id), {
      state: "ready",
      matchesIdentity: identity => identity.matchId === activeMatchId,
      command: async command => successReceipt(command),
      attachRenderer,
      detachRenderer: async () => undefined,
      dispose: async () => undefined,
    });

    await service.ensureRenderer({ sessionId: String(state.session.id), matchId: "match-rematch", seat: "Russians", tick: 0 });
    expect(attachRenderer).toHaveBeenCalledTimes(1);
    expect(activeMatchId).toBe("match-rematch");

    await service.dispose();
    vi.unstubAllGlobals();
  });

  it("continues queued renderer session cleanup after an earlier removal fails", async () => {
    const connection = new FakeConnection();
    const stateA = fakeSession("session-renderer-cleanup-a");
    const stateB = fakeSession("session-renderer-cleanup-b");
    const list = new Value({ current: stateA.session.id });
    const binding = {
      session: {
        projections: {
          faceOf: (key: string) => key === "redAlert" ? stateA.stateProjection : stateA.commandProjection,
        },
      },
    };
    const sessions = { list, binding: () => binding } as unknown as ISessions;
    const context = new Context();
    const service = new BrowserCommandClientService(context, { rpc: connection.clientRpc, sessions, clientInstanceId: "client-renderer-cleanup" });
    let failedDisposeCalls = 0;
    service.renderer.register("session-renderer-cleanup-a", {
      command: async (command) => successReceipt(command),
      attachRenderer: async () => undefined,
      detachRenderer: async () => undefined,
      dispose: async () => {
        failedDisposeCalls += 1;
        throw new Error("renderer A cleanup failure");
      },
    });

    list.set({ current: stateB.session.id });
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(failedDisposeCalls).toBe(1);

    let secondDisposeCalls = 0;
    service.renderer.register("session-renderer-cleanup-b", {
      command: async (command) => successReceipt(command),
      attachRenderer: async () => undefined,
      detachRenderer: async () => undefined,
      dispose: async () => { secondDisposeCalls += 1; },
    });
    list.set({ current: "session-renderer-cleanup-c" as SessionId });
    const outcome = service.dispose().then(
      () => ({ ok: true as const }),
      (error: unknown) => ({ ok: false as const, error }),
    );
    const result = await outcome;
    expect(secondDisposeCalls).toBe(1);
    expect(result.ok).toBe(false);
    if (result.ok) throw new Error("expected session cleanup failure to be reported");
    expect(result.error).toMatchObject({ code: "RENDERER_CLEANUP_FAILED" });
  });

  it("does not publish or wait for a browser command before durable flush", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    let releaseFlush!: () => void;
    state.flushGate = new Promise<void>((resolve) => { releaseFlush = resolve; });
    const transport = makeTransport(connection, state, seen);
    transport.start();
    const abort = new AbortController();
    const pending = transport.dispatch(state.session, { matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [] }, abort.signal);
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(state.events.map((event) => event.type)).toEqual([RED_ALERT_BROWSER_COMMAND_EVENT]);
    expect(state.commandProjection.getSnapshot().status).toBe("idle");
    abort.abort();
    releaseFlush();
    await expect(pending).rejects.toMatchObject({ code: "CANCELLED" });
    await transport.dispose();
  });

  it("rejects a second dispatch for the same session while the first command is pending", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    const transport = makeTransport(connection, state, seen);
    transport.start();
    const firstAbort = new AbortController();
    const first = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, firstAbort.signal);
    for (let attempt = 0; attempt < 10 && state.commandProjection.getSnapshot().status !== "pending"; attempt += 1) {
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
    }
    await expect(transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, new AbortController().signal)).rejects.toMatchObject({ code: "BUSY" });
    expect(state.events.filter((event) => event.type === RED_ALERT_BROWSER_COMMAND_EVENT)).toHaveLength(1);
    firstAbort.abort();
    await expect(first).rejects.toMatchObject({ code: "CANCELLED" });
    await transport.dispose();
  });

  it("rejects a non-positive browser command timeout at construction", () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    expect(() => makeTransport(connection, state, seen, { timeoutMs: 0 })).toThrow(/positive integer/);
    expect(() => makeTransport(connection, state, seen, { createMatchTimeoutMs: 0 })).toThrow(/positive integer/);
  });

  it("keeps first-match startup pending beyond the normal command timeout", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    const transport = makeTransport(connection, state, seen, {
      timeoutMs: 5,
      createMatchTimeoutMs: 200,
      resolveAuthority: () => ({ matchId: "match-browser", seat: "Russians", tick: 0, status: "creating" }),
    });
    transport.start();
    const controller = new AbortController();
    const command = transport.dispatch(state.session, {
      matchId: "match-browser",
      seat: "Russians",
      expectedTick: 0,
      kind: "create-match",
      request: { map: "current", myCountry: "Russians", opponents: 1, opponentType: "normal", gameSpeed: 2 },
    }, controller.signal);
    for (let attempt = 0; attempt < 10 && state.commandProjection.getSnapshot().status !== "pending"; attempt += 1) {
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
    }
    await new Promise<void>((resolve) => setTimeout(resolve, 30));
    expect(transport.hasPending(String(state.session.id))).toBe(true);
    expect(state.commandProjection.getSnapshot()).toMatchObject({ status: "pending", command: { kind: "create-match" } });
    controller.abort();
    await expect(command).rejects.toMatchObject({ code: "CANCELLED" });
    await transport.dispose();
  });

  it("cleans one session lease and pending command without affecting another session", async () => {
    const connection = new FakeConnection();
    const stateA = fakeSession("session-browser-a");
    const stateB = fakeSession("session-browser-b");
    const seenA = { value: 0 };
    const seenB = { value: 0 };
    const states = new Map([[String(stateA.session.id), [stateA, seenA] as const], [String(stateB.session.id), [stateB, seenB] as const]]);
    let requestNumber = 0;
    const transport = makeTransport(connection, stateA, seenA, {
      isSessionOwner: () => true,
      resolveAuthority: (sessionId) => states.has(sessionId) ? { matchId: "match-browser", seat: "Russians", tick: 4, status: "active" } : undefined,
      resolveSession: (sessionId) => states.get(sessionId)?.[0].session,
      requestId: () => `request-browser-${++requestNumber}`,
      flush: async (session) => {
        const target = states.get(String(session.id));
        if (target === undefined) throw new Error("unknown fake session");
        await new Promise<void>((resolve) => {
          queueMicrotask(() => {
            resolve();
            queueMicrotask(() => publishNewEvents(target[0], target[1]));
          });
        });
      },
    });
    transport.start();
    for (const state of [stateA, stateB]) {
      const lease = await connection.clientRpc.call("/red-alert", "lease/register", {
        protocolVersion: 1,
        sessionId: state.session.id,
        matchId: "match-browser",
        seat: "Russians",
        clientInstanceId: `client-${state.session.id}`,
      });
      expect(lease.ok).toBe(true);
    }
    const abortA = new AbortController();
    const commandA = transport.dispatch(stateA.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, abortA.signal);
    const abortB = new AbortController();
    const commandB = transport.dispatch(stateB.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, abortB.signal);
    for (let attempt = 0; attempt < 10 && (stateA.commandProjection.getSnapshot().status !== "pending" || stateB.commandProjection.getSnapshot().status !== "pending"); attempt += 1) {
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
    }
    await transport.cleanupSession(String(stateA.session.id));
    await expect(commandA).rejects.toMatchObject({ code: "SESSION_DISPOSED" });
    expect(stateA.events.at(-2)?.data).toMatchObject({ status: "cancelled", failure: { code: "SESSION_DISPOSED" } });
    expect((transport as unknown as { readonly pending: Map<unknown, unknown> }).pending.size).toBe(1);
    expect((transport as unknown as { readonly leases: Map<unknown, unknown> }).leases.size).toBe(1);
    expect(stateB.commandProjection.getSnapshot().status).toBe("pending");
    abortB.abort();
    await expect(commandB).rejects.toMatchObject({ code: "CANCELLED" });
    await transport.dispose();
  });

  it("keeps the admitted event non-pending in a real Host Session projection until the marker", async () => {
    const context = new Context();
    const store = new SessionStore(context);
    const registry = new SessionProjectionRegistry(context);
    const disposeProjection = registry.register(redAlertCommandProjection);
    const session = store.prepare(SessionId("session-real-command-projection"));
    const detach = store.enter(session);
    store.announce(session);
    const changes: Array<{ readonly value: unknown; readonly seq: number }> = [];
    const disposeChanges = registry.onChanged((_session, key, value, seq) => {
      if (key === "redAlertCommand") changes.push({ value, seq });
    });
    const command = {
      protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
      requestId: "request-real-projection",
      sessionId: String(session.id),
      matchId: "match-browser",
      seat: "Russians",
      expectedTick: 4,
      kind: "orders",
      orders: [],
    } as const;
    try {
      session.append(RED_ALERT_BROWSER_COMMAND_EVENT, command);
      expect(registry.snapshot(session).values.redAlertCommand).toEqual({ status: "idle" });
      expect(changes.at(-1)).toEqual({ value: { status: "idle" }, seq: 0 });

      await store.flush(session);
      session.append(RED_ALERT_BROWSER_COMMAND_PUBLISHED_EVENT, {
        protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
        requestId: command.requestId,
        sessionId: command.sessionId,
        matchId: command.matchId,
        seat: command.seat,
        expectedTick: command.expectedTick,
      });
      expect(registry.snapshot(session).values.redAlertCommand).toEqual({ status: "pending", command });
      expect(changes.at(-1)).toEqual({ value: { status: "pending", command }, seq: 1 });
    } finally {
      disposeChanges();
      disposeProjection();
      detach();
    }
  });

  it("keeps a real result-admitted event pending until the flushed result marker", async () => {
    const context = new Context();
    const store = new SessionStore(context);
    const registry = new SessionProjectionRegistry(context);
    const disposeProjection = registry.register(redAlertCommandProjection);
    const session = store.prepare(SessionId("session-real-result-projection"));
    const detach = store.enter(session);
    store.announce(session);
    const command = {
      protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
      requestId: "request-real-result-projection",
      sessionId: String(session.id),
      matchId: "match-browser",
      seat: "Russians",
      expectedTick: 4,
      kind: "orders",
      orders: [],
    } as const;
    const receipt = {
      protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
      requestId: command.requestId,
      sessionId: command.sessionId,
      matchId: command.matchId,
      seat: command.seat,
      tick: 5,
      ok: true,
      detail: "real result",
    } as const;
    const result = {
      protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
      requestId: command.requestId,
      sessionId: command.sessionId,
      matchId: command.matchId,
      seat: command.seat,
      command,
      status: "completed" as const,
      receipt,
    };
    try {
      session.append(RED_ALERT_BROWSER_COMMAND_EVENT, command);
      await store.flush(session);
      session.append(RED_ALERT_BROWSER_COMMAND_PUBLISHED_EVENT, {
        protocolVersion: command.protocolVersion,
        requestId: command.requestId,
        sessionId: command.sessionId,
        matchId: command.matchId,
        seat: command.seat,
        expectedTick: command.expectedTick,
      });
      expect(registry.snapshot(session).values.redAlertCommand).toMatchObject({ status: "pending" });

      session.append(RED_ALERT_BROWSER_COMMAND_RESULT_EVENT, result);
      expect(registry.snapshot(session).values.redAlertCommand).toMatchObject({ status: "pending" });

      await store.flush(session);
      session.append(RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT, {
        protocolVersion: command.protocolVersion,
        requestId: command.requestId,
        sessionId: command.sessionId,
        matchId: command.matchId,
        seat: command.seat,
        status: "completed",
      });
      expect(registry.snapshot(session).values.redAlertCommand).toMatchObject({ status: "completed", receipt });
    } finally {
      disposeProjection();
      detach();
    }
  });

  it("fails closed on out-of-order, mismatched, and malformed result markers", () => {
    const command = {
      protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
      requestId: "request-marker-order",
      sessionId: "session-marker-order",
      matchId: "match-browser",
      seat: "Russians",
      expectedTick: 4,
      kind: "orders",
      orders: [],
    } as const;
    const result = {
      protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
      requestId: command.requestId,
      sessionId: command.sessionId,
      matchId: command.matchId,
      seat: command.seat,
      command,
      status: "completed" as const,
      receipt: {
        protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
        requestId: command.requestId,
        sessionId: command.sessionId,
        matchId: command.matchId,
        seat: command.seat,
        tick: 5,
        ok: true,
        detail: "marker order",
      },
    };
    const event = (type: string, data: unknown, seq: number): SessionEvent => ({ type, data, seq, time: seq + 1 } as SessionEvent);
    let fold = emptyBrowserCommandProjection();
    fold = applyBrowserCommandProjection(fold, event(RED_ALERT_BROWSER_COMMAND_EVENT, command, 0));
    fold = applyBrowserCommandProjection(fold, event(RED_ALERT_BROWSER_COMMAND_PUBLISHED_EVENT, {
      protocolVersion: command.protocolVersion,
      requestId: command.requestId,
      sessionId: command.sessionId,
      matchId: command.matchId,
      seat: command.seat,
      expectedTick: command.expectedTick,
    }, 1));
    const beforeResult = fold;
    fold = applyBrowserCommandProjection(fold, event(RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT, {
      protocolVersion: command.protocolVersion,
      requestId: command.requestId,
      sessionId: command.sessionId,
      matchId: command.matchId,
      seat: command.seat,
      status: "completed",
    }, 2));
    expect(fold).toBe(beforeResult);
    fold = applyBrowserCommandProjection(fold, event(RED_ALERT_BROWSER_COMMAND_RESULT_EVENT, result, 3));
    expect(fold.visible.status).toBe("pending");
    const beforeBadMarker = fold;
    fold = applyBrowserCommandProjection(fold, event(RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT, {
      protocolVersion: command.protocolVersion,
      requestId: command.requestId,
      sessionId: command.sessionId,
      matchId: command.matchId,
      seat: "Americans",
      status: "completed",
    }, 4));
    expect(fold).toBe(beforeBadMarker);
    fold = applyBrowserCommandProjection(fold, event(RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT, {
      protocolVersion: command.protocolVersion,
      requestId: command.requestId,
      sessionId: command.sessionId,
      matchId: command.matchId,
      seat: command.seat,
      status: "completed",
      extra: "not allowed",
    }, 5));
    expect(fold).toBe(beforeBadMarker);
    fold = applyBrowserCommandProjection(fold, event(RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT, {
      protocolVersion: command.protocolVersion,
      requestId: command.requestId,
      sessionId: command.sessionId,
      matchId: command.matchId,
      seat: command.seat,
      status: "completed",
    }, 6));
    expect(fold.visible).toMatchObject({ status: "completed", receipt: { detail: "marker order" } });
  });

  it("uses flush as the publication boundary observed through an official SessionBinding", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    const official = await officialSessionFixture(state.session.id);
    const runningState = {
      status: "running",
      match: { matchId: "match-browser", seat: "Russians", tick: 4, status: "active" },
    } as const;
    publishOfficialProjection(official, "redAlert", runningState, 1);
    state.publishCommandProjection = (value, seq) => publishOfficialProjection(official, "redAlertCommand", value, seq + 1);
    let releaseFlush!: () => void;
    state.flushGate = new Promise<void>((resolve) => { releaseFlush = resolve; });
    const transport = makeTransport(connection, state, seen);
    transport.start();
    let adapterCalls = 0;
    const adapters = new BrowserAdapterRegistry();
    adapters.register(state.session.id, {
      command: async (command) => {
        adapterCalls += 1;
        return successReceipt(command);
      },
    });
    const consumer = new BrowserCommandClientConsumer({ rpc: connection.clientRpc, sessions: official.sessions, adapters, clientInstanceId: "client-flush-boundary" });
    consumer.start();
    const command = transport.dispatch(state.session, { matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [] }, new AbortController().signal);
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(official.sessions.binding(official.sessionId)?.session.projections.faceOf("redAlertCommand").getSnapshot()).toEqual({ status: "idle" });
    expect(adapterCalls).toBe(0);
    releaseFlush();
    await expect(command).resolves.toMatchObject({ ok: true });
    expect(adapterCalls).toBe(1);
    expect(official.sessions.binding(official.sessionId)?.session.projections.faceOf("redAlertCommand").getSnapshot()).toMatchObject({ status: "completed" });
    await consumer.dispose();
    await transport.dispose();
  });

  it("fails closed on admission flush failure without dispatching to a client", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    const logMessages: unknown[] = [];
    state.flushFailure = new Error("hiddenWorld /secret/path token=should-not-cross");
    const transport = makeTransport(connection, state, seen, { logger: { error: (...args: unknown[]) => logMessages.push(args) } });
    transport.start();
    const rejection = await transport.dispatch(state.session, { matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [] }, new AbortController().signal).catch((error: unknown) => error);
    expect(rejection).toMatchObject({ code: "ADMISSION_FAILED", message: "browser command admission failed" });
    expect(JSON.stringify(rejection)).not.toContain("hiddenWorld");
    expect(JSON.stringify(rejection)).not.toContain("/secret/path");
    expect(JSON.stringify(rejection)).not.toContain("token=should-not-cross");
    expect(state.commandProjection.getSnapshot().status).toBe("idle");
    expect(state.events.at(-1)?.type).toBe(RED_ALERT_BROWSER_COMMAND_RESULT_EVENT);
    expect(JSON.stringify(state.events)).not.toContain("hiddenWorld");
    expect(JSON.stringify(state.events)).not.toContain("/secret/path");
    expect(JSON.stringify(state.events)).not.toContain("token=should-not-cross");
    expect(state.events.at(-1)?.data).toMatchObject({ failure: { message: "browser command admission failed" } });
    expect(JSON.stringify(logMessages)).not.toContain("hiddenWorld");
    expect(JSON.stringify(logMessages)).not.toContain("/secret/path");
    expect(JSON.stringify(logMessages)).not.toContain("token=should-not-cross");
    expect(logMessages).toContainEqual(["red-alert ADMISSION_FAILED: browser command admission failed"]);
    expect(state.events.some((event) => event.type === RED_ALERT_BROWSER_COMMAND_PUBLISHED_EVENT)).toBe(false);
    expect(connection.handler).toBeDefined();
    await transport.dispose();
  });

  it("normalizes a marker append failure before returning it to the caller", async () => {
    const connection = new FakeConnection();
    const state = fakeSession("session-marker-append-failure");
    const seen = { value: 0 };
    const logMessages: unknown[] = [];
    state.appendFailure = {
      type: RED_ALERT_BROWSER_COMMAND_PUBLISHED_EVENT,
      error: new Error("hiddenWorld /secret/path token=should-not-cross"),
    };
    const transport = makeTransport(connection, state, seen, { logger: { error: (...args: unknown[]) => logMessages.push(args) } });
    transport.start();
    const rejection = await transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, new AbortController().signal).catch((error: unknown) => error);
    expect(rejection).toMatchObject({ code: "ADMISSION_FAILED", message: "browser command admission failed" });
    expect(JSON.stringify(rejection)).not.toContain("hiddenWorld");
    expect(JSON.stringify(rejection)).not.toContain("/secret/path");
    expect(JSON.stringify(rejection)).not.toContain("token=should-not-cross");
    expect(JSON.stringify(state.events)).not.toContain("hiddenWorld");
    expect(JSON.stringify(state.events)).not.toContain("/secret/path");
    expect(JSON.stringify(state.events)).not.toContain("token=should-not-cross");
    expect(JSON.stringify(logMessages)).not.toContain("hiddenWorld");
    expect(JSON.stringify(logMessages)).not.toContain("/secret/path");
    expect(JSON.stringify(logMessages)).not.toContain("token=should-not-cross");
    expect(logMessages).toContainEqual(["red-alert ADMISSION_FAILED: browser command admission failed"]);
    await transport.dispose();
  });

  it("does not append a second result when pre-publication cancellation result flush fails", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    let releaseAdmission!: () => void;
    let flushCount = 0;
    const admissionGate = new Promise<void>((resolve) => { releaseAdmission = resolve; });
    const transport = makeTransport(connection, state, seen, {
      flush: async (session) => {
        flushCount += 1;
        if (flushCount === 1) {
          await admissionGate;
        } else {
          throw new Error("cancel result flush failed");
        }
        await new Promise<void>((resolve) => {
          queueMicrotask(() => {
            resolve();
            queueMicrotask(() => publishNewEvents(state, seen));
          });
        });
        void session;
      },
    });
    transport.start();
    const abort = new AbortController();
    const command = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, abort.signal);
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(state.events.map((event) => event.type)).toEqual([RED_ALERT_BROWSER_COMMAND_EVENT]);
    abort.abort();
    releaseAdmission();
    await expect(command).rejects.toMatchObject({ code: "RESULT_COMMIT_FAILED" });
    expect(state.events.map((event) => event.type)).toEqual([
      RED_ALERT_BROWSER_COMMAND_EVENT,
      RED_ALERT_BROWSER_COMMAND_RESULT_EVENT,
    ]);
    expect(state.events).toHaveLength(2);
    expect(state.events.at(-1)?.data).toMatchObject({ status: "cancelled" });
    await transport.dispose();
  });

  it("rejects session cleanup when admission cancellation result flush fails without a duplicate terminal event", async () => {
    const connection = new FakeConnection();
    const state = fakeSession("session-cleanup-admission-failure");
    const seen = { value: 0 };
    let releaseAdmission!: () => void;
    let releaseResult!: () => void;
    let markResultStarted!: () => void;
    let flushCount = 0;
    const admissionGate = new Promise<void>((resolve) => { releaseAdmission = resolve; });
    const resultGate = new Promise<void>((resolve) => { releaseResult = resolve; });
    const resultStarted = new Promise<void>((resolve) => { markResultStarted = resolve; });
    const transport = makeTransport(connection, state, seen, {
      flush: async (session) => {
        flushCount += 1;
        if (flushCount === 1) {
          await admissionGate;
        } else if (flushCount === 2) {
          markResultStarted();
          await resultGate;
          throw new Error("session cleanup result flush failed");
        }
        await new Promise<void>((resolve) => {
          queueMicrotask(() => {
            resolve();
            queueMicrotask(() => publishNewEvents(state, seen));
          });
        });
        void session;
      },
    });
    transport.start();
    const lease = await connection.clientRpc.call("/red-alert", "lease/register", {
      protocolVersion: 1,
      sessionId: state.session.id,
      matchId: "match-browser",
      seat: "Russians",
      clientInstanceId: "client-cleanup-admission-failure",
    });
    expect(lease.ok).toBe(true);
    const command = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, new AbortController().signal);
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    const cleanup = transport.cleanupSession(String(state.session.id));
    releaseAdmission();
    await resultStarted;
    let cleanupResolved = false;
    void cleanup.then(() => { cleanupResolved = true; }, () => { cleanupResolved = true; });
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(cleanupResolved).toBe(false);
    releaseResult();
    await expect(cleanup).rejects.toMatchObject({ code: "RESULT_COMMIT_FAILED" });
    await expect(command).rejects.toMatchObject({ code: "RESULT_COMMIT_FAILED" });
    expect(state.events.map((event) => event.type)).toEqual([
      RED_ALERT_BROWSER_COMMAND_EVENT,
      RED_ALERT_BROWSER_COMMAND_RESULT_EVENT,
    ]);
    expect(state.events.filter((event) => event.type === RED_ALERT_BROWSER_COMMAND_RESULT_EVENT)).toHaveLength(1);
    expect(state.events.some((event) => event.type === RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT)).toBe(false);
    expect((transport as unknown as { readonly pending: Map<unknown, unknown> }).pending.size).toBe(0);
    expect((transport as unknown as { readonly leases: Map<unknown, unknown> }).leases.size).toBe(0);
    await transport.dispose();
  });

  it("accepts 256 orders but rejects 257 before the first durable append", async () => {
    const acceptedConnection = new FakeConnection();
    const acceptedState = fakeSession("session-browser-256");
    const acceptedSeen = { value: 0 };
    const acceptedTransport = makeTransport(acceptedConnection, acceptedState, acceptedSeen, {
      isSessionOwner: (sessionId) => sessionId === String(acceptedState.session.id),
      requestId: () => "request-browser-256",
    });
    acceptedTransport.start();
    const acceptedAbort = new AbortController();
    const accepted = acceptedTransport.dispatch(acceptedState.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders",
      orders: Array.from({ length: MAX_BROWSER_ORDERS }, () => ({ action: "move" as const })),
    }, acceptedAbort.signal);
    for (let attempt = 0; attempt < 10 && acceptedState.commandProjection.getSnapshot().status !== "pending"; attempt += 1) {
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
    }
    expect(acceptedState.events[0]?.type).toBe(RED_ALERT_BROWSER_COMMAND_EVENT);
    expect(acceptedState.events[0]?.data).toMatchObject({ orders: { length: MAX_BROWSER_ORDERS } });
    acceptedAbort.abort();
    await expect(accepted).rejects.toMatchObject({ code: "CANCELLED" });
    await acceptedTransport.dispose();

    const rejectedConnection = new FakeConnection();
    const rejectedState = fakeSession("session-browser-257");
    const rejectedSeen = { value: 0 };
    const rejectedTransport = makeTransport(rejectedConnection, rejectedState, rejectedSeen, {
      isSessionOwner: (sessionId) => sessionId === String(rejectedState.session.id),
      requestId: () => "request-browser-257",
    });
    rejectedTransport.start();
    await expect(rejectedTransport.dispatch(rejectedState.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders",
      orders: Array.from({ length: MAX_BROWSER_ORDERS + 1 }, () => ({ action: "move" as const })),
    }, new AbortController().signal)).rejects.toMatchObject({ code: "INVALID_MESSAGE" });
    expect(rejectedState.events).toHaveLength(0);
    await rejectedTransport.dispose();
  });

  it("replaces an idle crashed-client lease but rejects takeover while a command is pending", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    const transport = makeTransport(connection, state, seen);
    transport.start();
    const first = await connection.clientRpc.call("/red-alert", "lease/register", {
      protocolVersion: 1, sessionId: "session-browser", matchId: "match-browser", seat: "Russians", clientInstanceId: "client-a",
    });
    expect(first.ok).toBe(true);
    if (!first.ok) return;
    const lease = first.value as { readonly leaseToken: string };
    const second = await connection.clientRpc.call("/red-alert", "lease/register", {
      protocolVersion: 1, sessionId: "session-browser", matchId: "match-browser", seat: "Russians", clientInstanceId: "client-b",
    });
    expect(second.ok).toBe(true);
    if (!second.ok) return;
    const replacementLease = second.value as { readonly leaseToken: string };
    expect(replacementLease.leaseToken).not.toBe(lease.leaseToken);
    const command = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, new AbortController().signal);
    for (let attempt = 0; attempt < 10 && state.commandProjection.getSnapshot().status !== "pending"; attempt += 1) {
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
    }
    const busyTakeover = await connection.clientRpc.call("/red-alert", "lease/register", {
      protocolVersion: 1, sessionId: "session-browser", matchId: "match-browser", seat: "Russians", clientInstanceId: "client-c",
    });
    expect(busyTakeover).toMatchObject({ ok: false, error: { code: "internal", message: expect.stringContaining("LEASE_BUSY") } });
    const baseReceipt = {
      protocolVersion: 1,
      requestId: "request-browser-1",
      sessionId: "session-browser",
      matchId: "match-browser",
      seat: "Russians",
      tick: 5,
      ok: true,
      detail: "accepted once",
      leaseToken: replacementLease.leaseToken,
    } as const;
    const wrongLease = await connection.clientRpc.call("/red-alert", "receipt", {
      ...baseReceipt,
      leaseToken: lease.leaseToken,
    });
    expect(wrongLease).toMatchObject({ ok: false, error: { code: "internal", message: expect.stringContaining("LEASE_INVALID") } });
    const wrongSession = await connection.clientRpc.call("/red-alert", "receipt", {
      ...baseReceipt,
      sessionId: "other-session",
    });
    expect(wrongSession).toMatchObject({ ok: false, error: { code: "internal" } });
    const wrongMatch = await connection.clientRpc.call("/red-alert", "receipt", {
      ...baseReceipt,
      matchId: "other-match",
    });
    expect(wrongMatch).toMatchObject({ ok: false, error: { code: "internal", message: expect.stringContaining("STALE_IDENTITY") } });
    const wrongSeat = await connection.clientRpc.call("/red-alert", "receipt", {
      ...baseReceipt,
      seat: "Americans",
    });
    expect(wrongSeat).toMatchObject({ ok: false, error: { code: "internal", message: expect.stringContaining("STALE_IDENTITY") } });
    const staleTick = await connection.clientRpc.call("/red-alert", "receipt", {
      ...baseReceipt,
      tick: 3,
    });
    expect(staleTick).toMatchObject({ ok: false, error: { code: "internal", message: expect.stringContaining("STALE_TICK") } });
    const hiddenObservation = await connection.clientRpc.call("/red-alert", "receipt", {
      ...baseReceipt,
      observation: {
        tick: 5,
        ownUnits: [],
        visibleEnemies: [],
        lastSeenEnemies: [],
        visibleNeutralObjects: [],
        hiddenEnemy: { id: 9001, x: 91, y: 92, hp: 100 },
      },
    });
    expect(hiddenObservation).toMatchObject({ ok: false, error: { code: "internal" } });
    const accepted = await connection.clientRpc.call("/red-alert", "receipt", baseReceipt);
    expect(accepted).toMatchObject({ ok: true, value: { accepted: true, replayed: false } });
    await expect(command).resolves.toMatchObject({ ok: true, detail: "accepted once" });
    const replay = await connection.clientRpc.call("/red-alert", "receipt", baseReceipt);
    expect(replay).toMatchObject({ ok: true, value: { accepted: true, replayed: true } });
    const mismatchedDuplicate = await connection.clientRpc.call("/red-alert", "receipt", {
      ...baseReceipt,
      detail: "different result",
    });
    expect(mismatchedDuplicate).toMatchObject({ ok: false, error: { code: "internal", message: expect.stringContaining("DUPLICATE_MISMATCH") } });
    await transport.dispose();
  });

  it("passes plugin failure responses through the official Connection response decoder", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    const transport = makeTransport(connection, state, seen);
    transport.start();
    const rpc = loadOfficialConnectionRpc(connection);
    const first = await rpc.call("/red-alert", "lease/register", {
      protocolVersion: 1, sessionId: state.session.id, matchId: "match-browser", seat: "Russians", clientInstanceId: "carrier-a",
    });
    expect(first.ok).toBe(true);
    const controller = new AbortController();
    const command = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, controller.signal);
    for (let attempt = 0; attempt < 10 && state.commandProjection.getSnapshot().status !== "pending"; attempt += 1) {
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
    }
    const second = await rpc.call("/red-alert", "lease/register", {
      protocolVersion: 1, sessionId: state.session.id, matchId: "match-browser", seat: "Russians", clientInstanceId: "carrier-b",
    });
    expect(second).toMatchObject({ ok: false, error: { code: "internal", details: {} } });
    if (!second.ok) expect(second.error.message.length).toBeLessThanOrEqual(240);
    controller.abort();
    await expect(command).rejects.toMatchObject({ code: "CANCELLED" });
    await transport.dispose();
  });

  it("records a failed timeout and rejects a late receipt", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    const transport = makeTransport(connection, state, seen, { timeoutMs: 5 });
    transport.start();
    const command = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, new AbortController().signal);
    for (let attempt = 0; attempt < 10 && state.commandProjection.getSnapshot().status !== "pending"; attempt += 1) {
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
    }
    const leaseResult = await connection.clientRpc.call("/red-alert", "lease/register", {
      protocolVersion: 1, sessionId: state.session.id, matchId: "match-browser", seat: "Russians", clientInstanceId: "client-timeout",
    });
    expect(leaseResult.ok).toBe(true);
    if (!leaseResult.ok) return;
    const leaseToken = (leaseResult.value as { readonly leaseToken: string }).leaseToken;
    await expect(command).rejects.toMatchObject({ code: "TIMEOUT" });
    expect(state.events.at(-2)?.data).toMatchObject({ status: "failed", failure: { code: "TIMEOUT" } });
    const late = await connection.clientRpc.call("/red-alert", "receipt", {
      protocolVersion: 1,
      requestId: "request-browser-1",
      sessionId: state.session.id,
      matchId: "match-browser",
      seat: "Russians",
      tick: 5,
      ok: true,
      detail: "late timeout receipt",
      leaseToken,
    });
    expect(late).toMatchObject({ ok: false, error: { code: "internal", message: expect.stringContaining("NOT_PENDING") } });
    await transport.dispose();
  });

  it("catches an abort result flush failure without an unhandled rejection", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    const logMessages: unknown[] = [];
    const transport = makeTransport(connection, state, seen, { logger: { error: (...args: unknown[]) => logMessages.push(args) } });
    transport.start();
    const abort = new AbortController();
    const command = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, abort.signal);
    for (let attempt = 0; attempt < 10 && state.commandProjection.getSnapshot().status !== "pending"; attempt += 1) {
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
    }
    state.flushFailure = new Error("hiddenWorld /secret/path token=abort-result");
    abort.abort();
    await expect(command).rejects.toMatchObject({ code: "RESULT_COMMIT_FAILED" });
    expect(state.commandProjection.getSnapshot().status).toBe("pending");
    expect(state.events.some((event) => event.type === RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT)).toBe(false);
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(logMessages.length).toBeGreaterThan(0);
    expect(JSON.stringify(logMessages)).not.toContain("hiddenWorld");
    expect(JSON.stringify(logMessages)).not.toContain("/secret/path");
    expect(JSON.stringify(logMessages)).not.toContain("token=abort-result");
    expect(JSON.stringify(logMessages)).toContain("red-alert RESULT_COMMIT_FAILED: browser command result could not be durably committed");
    await transport.dispose();
  });

  it("catches a timeout result flush failure without an unhandled rejection", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    const logMessages: unknown[] = [];
    const transport = makeTransport(connection, state, seen, { timeoutMs: 5, logger: { error: (...args: unknown[]) => logMessages.push(args) } });
    transport.start();
    const command = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, new AbortController().signal);
    for (let attempt = 0; attempt < 10 && state.commandProjection.getSnapshot().status !== "pending"; attempt += 1) {
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
    }
    state.flushFailure = new Error("hiddenWorld /secret/path token=timeout-result");
    await expect(command).rejects.toMatchObject({ code: "RESULT_COMMIT_FAILED" });
    expect(state.commandProjection.getSnapshot().status).toBe("pending");
    expect(state.events.some((event) => event.type === RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT)).toBe(false);
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(logMessages.length).toBeGreaterThan(0);
    expect(JSON.stringify(logMessages)).not.toContain("hiddenWorld");
    expect(JSON.stringify(logMessages)).not.toContain("/secret/path");
    expect(JSON.stringify(logMessages)).not.toContain("token=timeout-result");
    expect(JSON.stringify(logMessages)).toContain("red-alert RESULT_COMMIT_FAILED: browser command result could not be durably committed");
    await transport.dispose();
  });

  it("unregisters the channel and waits for a cancelled result flush during Host dispose", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    let markResultFlushStarted!: () => void;
    let releaseResultFlush!: () => void;
    let flushCount = 0;
    const resultFlushStarted = new Promise<void>((resolve) => { markResultFlushStarted = resolve; });
    const resultFlush = new Promise<void>((resolve) => { releaseResultFlush = resolve; });
    const transport = makeTransport(connection, state, seen, {
      flush: async (session) => {
        flushCount += 1;
        if (flushCount > 1) {
          markResultFlushStarted();
          await resultFlush;
        }
        await new Promise<void>((resolve) => {
          queueMicrotask(() => {
            resolve();
            queueMicrotask(() => publishNewEvents(state, seen));
          });
        });
        void session;
      },
    });
    transport.start();
    const command = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, new AbortController().signal);
    for (let attempt = 0; attempt < 10 && state.commandProjection.getSnapshot().status !== "pending"; attempt += 1) {
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
    }
    const disposing = transport.dispose();
    await resultFlushStarted;
    expect(connection.handler).toBeUndefined();
    expect(state.events.at(-1)?.data).toMatchObject({ status: "cancelled" });
    let disposed = false;
    void disposing.then(() => { disposed = true; });
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(disposed).toBe(false);
    releaseResultFlush();
    await disposing;
    expect(disposed).toBe(true);
    await expect(command).rejects.toMatchObject({ code: "TRANSPORT_DISPOSED" });
  });

  it("does not publish or execute a command when dispose wins before admission publication", async () => {
    const connection = new FakeConnection();
    let markUnregisterStarted!: () => void;
    const unregisterStarted = new Promise<void>((resolve) => { markUnregisterStarted = resolve; });
    connection.onUnregister = markUnregisterStarted;
    const state = fakeSession();
    const seen = { value: 0 };
    let releaseAdmission!: () => void;
    let releaseResult!: () => void;
    let markAdmissionStarted!: () => void;
    let markResultStarted!: () => void;
    const admissionStarted = new Promise<void>((resolve) => { markAdmissionStarted = resolve; });
    const resultStarted = new Promise<void>((resolve) => { markResultStarted = resolve; });
    const admissionGate = new Promise<void>((resolve) => { releaseAdmission = resolve; });
    const resultGate = new Promise<void>((resolve) => { releaseResult = resolve; });
    let flushCount = 0;
    const transport = makeTransport(connection, state, seen, {
      flush: async (session) => {
        flushCount += 1;
        if (flushCount === 1) {
          markAdmissionStarted();
          await admissionGate;
        } else if (flushCount === 2) {
          markResultStarted();
          await resultGate;
        }
        await new Promise<void>((resolve) => {
          queueMicrotask(() => {
            resolve();
            queueMicrotask(() => publishNewEvents(state, seen));
          });
        });
        void session;
      },
    });
    transport.start();
    const adapters = new BrowserAdapterRegistry();
    let adapterCalls = 0;
    adapters.register(state.session.id, { command: async (command) => { adapterCalls += 1; return successReceipt(command); } });
    const consumer = new BrowserCommandClientConsumer({ rpc: connection.clientRpc, sessions: runningSessionPorts(state), adapters, clientInstanceId: "client-dispose-admission" });
    consumer.start();
    const command = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, new AbortController().signal);
    await admissionStarted;
    const disposing = transport.dispose();
    const secondDisposing = transport.dispose();
    expect(secondDisposing).toBe(disposing);
    await unregisterStarted;
    releaseAdmission();
    await resultStarted;
    expect(state.events.map((event) => event.type)).toEqual([
      RED_ALERT_BROWSER_COMMAND_EVENT,
      RED_ALERT_BROWSER_COMMAND_RESULT_EVENT,
    ]);
    expect(state.commandProjection.getSnapshot().status).not.toBe("pending");
    expect(adapterCalls).toBe(0);
    let disposed = false;
    void disposing.then(() => { disposed = true; });
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(disposed).toBe(false);
    releaseResult();
    await expect(command).rejects.toMatchObject({ code: "TRANSPORT_DISPOSED" });
    await Promise.all([disposing, secondDisposing]);
    expect(disposed).toBe(true);
    expect(connection.handler).toBeUndefined();
    await consumer.dispose();
  });

  it("waits for a receipt result flush across two shared Host dispose calls", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    let markResultFlushStarted!: () => void;
    let releaseResultFlush!: () => void;
    let flushCount = 0;
    const resultFlushStarted = new Promise<void>((resolve) => { markResultFlushStarted = resolve; });
    const resultFlush = new Promise<void>((resolve) => { releaseResultFlush = resolve; });
    const transport = makeTransport(connection, state, seen, {
      flush: async (session) => {
        flushCount += 1;
        if (flushCount > 1) {
          markResultFlushStarted();
          await resultFlush;
        }
        await new Promise<void>((resolve) => {
          queueMicrotask(() => {
            resolve();
            queueMicrotask(() => publishNewEvents(state, seen));
          });
        });
        void session;
      },
    });
    transport.start();
    const command = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, new AbortController().signal);
    for (let attempt = 0; attempt < 10 && state.commandProjection.getSnapshot().status !== "pending"; attempt += 1) {
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
    }
    const leaseResult = await connection.clientRpc.call("/red-alert", "lease/register", {
      protocolVersion: 1, sessionId: state.session.id, matchId: "match-browser", seat: "Russians", clientInstanceId: "client-double-dispose",
    });
    expect(leaseResult.ok).toBe(true);
    if (!leaseResult.ok) return;
    const leaseToken = (leaseResult.value as { readonly leaseToken: string }).leaseToken;
    const receipt = connection.clientRpc.call("/red-alert", "receipt", {
      protocolVersion: 1,
      requestId: "request-browser-1",
      sessionId: state.session.id,
      matchId: "match-browser",
      seat: "Russians",
      tick: 5,
      ok: true,
      detail: "receipt flush",
      leaseToken,
    });
    await resultFlushStarted;
    const firstDispose = transport.dispose();
    const secondDispose = transport.dispose();
    expect(secondDispose).toBe(firstDispose);
    let firstResolved = false;
    let secondResolved = false;
    void firstDispose.then(() => { firstResolved = true; });
    void secondDispose.then(() => { secondResolved = true; });
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(firstResolved).toBe(false);
    expect(secondResolved).toBe(false);
    releaseResultFlush();
    await Promise.all([firstDispose, secondDispose, receipt, command]);
    expect(state.events.map((event) => event.type)).toEqual([
      RED_ALERT_BROWSER_COMMAND_EVENT,
      RED_ALERT_BROWSER_COMMAND_PUBLISHED_EVENT,
      RED_ALERT_BROWSER_COMMAND_RESULT_EVENT,
      RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT,
    ]);
    expect(state.events.at(-2)?.data).toMatchObject({ status: "completed", receipt: { detail: "receipt flush" } });
  });

  it("finishes pending, timer, lease, and channel cleanup when Host unregister fails", async () => {
    const connection = new FakeConnection();
    connection.unregisterFailure = new Error("unregister failed");
    const state = fakeSession();
    const seen = { value: 0 };
    const transport = makeTransport(connection, state, seen, { timeoutMs: 20 });
    transport.start();
    const leaseResult = await connection.clientRpc.call("/red-alert", "lease/register", {
      protocolVersion: 1, sessionId: state.session.id, matchId: "match-browser", seat: "Russians", clientInstanceId: "client-unregister-failure",
    });
    expect(leaseResult.ok).toBe(true);
    const command = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, new AbortController().signal);
    for (let attempt = 0; attempt < 10 && state.commandProjection.getSnapshot().status !== "pending"; attempt += 1) {
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
    }
    const disposing = transport.dispose();
    await expect(disposing).rejects.toThrow("unregister failed");
    await expect(command).rejects.toMatchObject({ code: "TRANSPORT_DISPOSED" });
    expect(connection.unregisterCalls).toBe(1);
    expect(connection.handler).toBeUndefined();
    expect(state.events.at(-2)?.data).toMatchObject({ status: "cancelled", failure: { code: "TRANSPORT_DISPOSED" } });
    expect((transport as unknown as { readonly pending: Map<unknown, unknown> }).pending.size).toBe(0);
    expect((transport as unknown as { readonly leases: Map<unknown, unknown> }).leases.size).toBe(0);
    const eventCount = state.events.length;
    await new Promise<void>((resolve) => setTimeout(resolve, 40));
    expect(state.events).toHaveLength(eventCount);
    const secondDispose = transport.dispose();
    expect(secondDispose).toBe(disposing);
    await expect(secondDispose).rejects.toThrow("unregister failed");
    expect(connection.unregisterCalls).toBe(1);
  });

  it("exposes cancellation result flush failure to shared Host dispose cleanup", async () => {
    const connection = new FakeConnection();
    connection.unregisterFailure = new Error("unregister failed");
    const state = fakeSession();
    const seen = { value: 0 };
    let logCount = 0;
    const logger = { error: () => { logCount += 1; } };
    const transport = makeTransport(connection, state, seen, { logger });
    transport.start();
    const leaseResult = await connection.clientRpc.call("/red-alert", "lease/register", {
      protocolVersion: 1, sessionId: state.session.id, matchId: "match-browser", seat: "Russians", clientInstanceId: "client-cancel-flush-failure",
    });
    expect(leaseResult.ok).toBe(true);
    const command = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, new AbortController().signal);
    for (let attempt = 0; attempt < 10 && state.commandProjection.getSnapshot().status !== "pending"; attempt += 1) {
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
    }
    state.flushFailure = new Error("cancel flush failed");
    const disposing = transport.dispose();
    const disposalError = await disposing.then(() => undefined, (error: unknown) => error);
    expect(disposalError).toBeInstanceOf(AggregateError);
    const errors = (disposalError as AggregateError).errors;
    expect(errors).toEqual(expect.arrayContaining([
      connection.unregisterFailure,
      expect.objectContaining({ code: "RESULT_COMMIT_FAILED" }),
    ]));
    await expect(command).rejects.toMatchObject({ code: "RESULT_COMMIT_FAILED" });
    expect(connection.handler).toBeUndefined();
    expect(connection.unregisterCalls).toBe(1);
    expect((transport as unknown as { readonly pending: Map<unknown, unknown> }).pending.size).toBe(0);
    expect((transport as unknown as { readonly leases: Map<unknown, unknown> }).leases.size).toBe(0);
    const eventCount = state.events.length;
    await new Promise<void>((resolve) => setTimeout(resolve, 40));
    expect(state.events).toHaveLength(eventCount);
    expect(logCount).toBeGreaterThan(0);
    const secondDispose = transport.dispose();
    expect(secondDispose).toBe(disposing);
    await expect(secondDispose).rejects.toBe(disposalError);
  });

  it("rejects a late receipt while cancellation result finalization is still flushing", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    let markResultFlushStarted!: () => void;
    let releaseResultFlush!: () => void;
    let flushCount = 0;
    const resultFlushStarted = new Promise<void>((resolve) => { markResultFlushStarted = resolve; });
    const resultFlush = new Promise<void>((resolve) => { releaseResultFlush = resolve; });
    const transport = makeTransport(connection, state, seen, {
      flush: async (session) => {
        flushCount += 1;
        if (flushCount > 1) {
          markResultFlushStarted();
          await resultFlush;
        }
        await new Promise<void>((resolve) => {
          queueMicrotask(() => {
            resolve();
            queueMicrotask(() => publishNewEvents(state, seen));
          });
        });
        void session;
      },
    });
    transport.start();
    const abort = new AbortController();
    const command = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, abort.signal);
    for (let attempt = 0; attempt < 10 && state.commandProjection.getSnapshot().status !== "pending"; attempt += 1) {
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
    }
    const leaseResult = await connection.clientRpc.call("/red-alert", "lease/register", {
      protocolVersion: 1, sessionId: state.session.id, matchId: "match-browser", seat: "Russians", clientInstanceId: "client-finalize-cancel",
    });
    expect(leaseResult.ok).toBe(true);
    if (!leaseResult.ok) return;
    const leaseToken = (leaseResult.value as { readonly leaseToken: string }).leaseToken;
    abort.abort();
    await resultFlushStarted;
    const rpc = loadOfficialConnectionRpc(connection);
    const late = await rpc.call("/red-alert", "receipt", {
      protocolVersion: 1,
      requestId: "request-browser-1",
      sessionId: state.session.id,
      matchId: "match-browser",
      seat: "Russians",
      tick: 5,
      ok: true,
      detail: "late receipt",
      leaseToken,
    });
    expect(late).toMatchObject({ ok: false, error: { code: "internal", message: expect.stringContaining("FINALIZING") } });
    releaseResultFlush();
    await expect(command).rejects.toMatchObject({ code: "CANCELLED" });
    expect(state.events.at(-2)?.data).toMatchObject({ status: "cancelled" });
    await transport.dispose();
  });

  it("rejects a different receipt while the first result is being durably committed", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    let markResultFlushStarted!: () => void;
    let releaseResultFlush!: () => void;
    let flushCount = 0;
    const resultFlushStarted = new Promise<void>((resolve) => { markResultFlushStarted = resolve; });
    const resultFlush = new Promise<void>((resolve) => { releaseResultFlush = resolve; });
    const transport = makeTransport(connection, state, seen, {
      flush: async (session) => {
        flushCount += 1;
        if (flushCount > 1) {
          markResultFlushStarted();
          await resultFlush;
        }
        await new Promise<void>((resolve) => {
          queueMicrotask(() => {
            resolve();
            queueMicrotask(() => publishNewEvents(state, seen));
          });
        });
        void session;
      },
    });
    transport.start();
    const command = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, new AbortController().signal);
    for (let attempt = 0; attempt < 10 && state.commandProjection.getSnapshot().status !== "pending"; attempt += 1) {
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
    }
    const leaseResult = await connection.clientRpc.call("/red-alert", "lease/register", {
      protocolVersion: 1, sessionId: state.session.id, matchId: "match-browser", seat: "Russians", clientInstanceId: "client-finalize-receipt",
    });
    expect(leaseResult.ok).toBe(true);
    if (!leaseResult.ok) return;
    const leaseToken = (leaseResult.value as { readonly leaseToken: string }).leaseToken;
    const firstReceipt = connection.clientRpc.call("/red-alert", "receipt", {
      protocolVersion: 1,
      requestId: "request-browser-1",
      sessionId: state.session.id,
      matchId: "match-browser",
      seat: "Russians",
      tick: 5,
      ok: true,
      detail: "first receipt",
      leaseToken,
    });
    await resultFlushStarted;
    const rpc = loadOfficialConnectionRpc(connection);
    const second = await rpc.call("/red-alert", "receipt", {
      protocolVersion: 1,
      requestId: "request-browser-1",
      sessionId: state.session.id,
      matchId: "match-browser",
      seat: "Russians",
      tick: 5,
      ok: true,
      detail: "different receipt",
      leaseToken,
    });
    expect(second).toMatchObject({ ok: false, error: { code: "internal", message: expect.stringContaining("FINALIZING") } });
    releaseResultFlush();
    await expect(firstReceipt).resolves.toMatchObject({ ok: true, value: { accepted: true } });
    await expect(command).resolves.toMatchObject({ ok: true, detail: "first receipt" });
    expect(state.events.at(-2)?.data).toMatchObject({ status: "completed", receipt: { detail: "first receipt" } });
    await transport.dispose();
  });

  it("registers an in-flight adapter promise before execution and emits one failure receipt", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    const transport = makeTransport(connection, state, seen);
    transport.start();
    const adapters = new BrowserAdapterRegistry();
    const rpcPayloads: unknown[] = [];
    let adapterCalls = 0;
    let markStarted!: () => void;
    const started = new Promise<void>((resolve) => { markStarted = resolve; });
    let rejectAdapter!: (error: unknown) => void;
    adapters.register(state.session.id, {
      command: async () => {
        adapterCalls += 1;
        markStarted();
        await new Promise<never>((_resolve, reject) => { rejectAdapter = reject; });
        throw new Error("unreachable");
      },
    });
    const rpc: ClientConnectionRpc = {
      call: async (channel, endpoint, payload, signal) => {
        if (endpoint === "receipt") rpcPayloads.push(payload);
        return connection.clientRpc.call(channel, endpoint, payload, signal);
      },
    };
    const consumer = new BrowserCommandClientConsumer({ rpc, sessions: runningSessionPorts(state), adapters, clientInstanceId: "client-exactly-once" });
    consumer.start();
    const command = transport.dispatch(state.session, { matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [] }, new AbortController().signal);
    await started;
    const retries = Promise.all([consumer.reconcile(), consumer.reconcile(), consumer.reconcile()]);
    rejectAdapter(new Error("hiddenWorld /secret/path token=should-not-cross"));
    await expect(command).resolves.toMatchObject({ ok: false, detail: expect.stringContaining("ADAPTER_COMMAND_FAILED") });
    await retries;
    expect(adapterCalls).toBe(1);
    expect(rpcPayloads).toHaveLength(1);
    expect(JSON.stringify(rpcPayloads)).not.toContain("hiddenWorld");
    expect(JSON.stringify(rpcPayloads)).not.toContain("/secret/path");
    expect(JSON.stringify(rpcPayloads)).not.toContain("token=should-not-cross");
    expect(JSON.stringify(state.events)).not.toContain("hiddenWorld");
    expect(JSON.stringify(state.events)).not.toContain("/secret/path");
    expect(JSON.stringify(state.events)).not.toContain("token=should-not-cross");
    await consumer.dispose();
    await transport.dispose();
  });

  it("waits for the same-session renderer adapter before executing the admitted command", async () => {
    const connection = new FakeConnection();
    const state = fakeSession("session-delayed-adapter");
    state.stateProjection.set({
      status: "running",
      view: { renderer: { adapterAttachTimeoutMs: 400 } },
      match: { matchId: "match-browser", seat: "Russians", tick: 4, status: "active" },
    });
    const seen = { value: 0 };
    const transport = makeTransport(connection, state, seen, { timeoutMs: 500 });
    transport.start();
    const adapters = new BrowserAdapterRegistry();
    let adapterCalls = 0;
    const consumer = new BrowserCommandClientConsumer({
      rpc: connection.clientRpc,
      sessions: runningSessionPorts(state),
      adapters,
      clientInstanceId: "client-delayed-adapter",
    });
    consumer.start();

    const command = transport.dispatch(state.session, {
      matchId: "match-browser",
      seat: "Russians",
      expectedTick: 4,
      kind: "orders",
      orders: [],
    }, new AbortController().signal);
    await vi.waitFor(() => expect(adapters.listenerCount).toBe(2));
    adapters.register(state.session.id, {
      command: async (envelope) => {
        adapterCalls += 1;
        return successReceipt(envelope);
      },
    });

    await expect(command).resolves.toMatchObject({ ok: true, tick: 5 });
    expect(adapterCalls).toBe(1);
    expect(adapters.listenerCount).toBe(1);
    await consumer.dispose();
    await transport.dispose();
  });

  it("fails closed and removes the waiter when the adapter deadline expires", async () => {
    const connection = new FakeConnection();
    const state = fakeSession("session-adapter-timeout");
    state.stateProjection.set({
      status: "running",
      view: { renderer: { adapterAttachTimeoutMs: 20 } },
      match: { matchId: "match-browser", seat: "Russians", tick: 4, status: "active" },
    });
    const seen = { value: 0 };
    const transport = makeTransport(connection, state, seen, { timeoutMs: 200 });
    transport.start();
    const adapters = new BrowserAdapterRegistry();
    const consumer = new BrowserCommandClientConsumer({
      rpc: connection.clientRpc,
      sessions: runningSessionPorts(state),
      adapters,
      clientInstanceId: "client-adapter-timeout",
    });
    consumer.start();

    const command = transport.dispatch(state.session, {
      matchId: "match-browser",
      seat: "Russians",
      expectedTick: 4,
      kind: "orders",
      orders: [],
    }, new AbortController().signal);
    await expect(command).resolves.toMatchObject({ ok: false, detail: expect.stringContaining("ADAPTER_UNAVAILABLE") });
    expect(adapters.listenerCount).toBe(1);
    await consumer.dispose();
    await transport.dispose();
  });

  it("continues dispatching from a recoverable active-match error projection", async () => {
    const connection = new FakeConnection();
    const state = fakeSession("session-recoverable-client");
    state.stateProjection.set({
      status: "error",
      match: { matchId: "match-browser", seat: "Russians", tick: 4, status: "active" },
      failure: { phase: "running", code: "COMMAND_REJECTED", message: "invalid placement", recoverable: true },
    });
    const seen = { value: 0 };
    const transport = makeTransport(connection, state, seen);
    transport.start();
    let adapterCalls = 0;
    const adapters = new BrowserAdapterRegistry();
    adapters.register(state.session.id, {
      command: async (command) => {
        adapterCalls += 1;
        return successReceipt(command);
      },
    });
    const consumer = new BrowserCommandClientConsumer({
      rpc: connection.clientRpc,
      sessions: runningSessionPorts(state),
      adapters,
      clientInstanceId: "client-recoverable-error",
    });
    consumer.start();
    const command = transport.dispatch(state.session, {
      matchId: "match-browser",
      seat: "Russians",
      expectedTick: 4,
      kind: "orders",
      orders: [],
    }, new AbortController().signal);
    await expect(command).resolves.toMatchObject({ ok: true, tick: 5 });
    expect(adapterCalls).toBe(1);
    await consumer.dispose();
    await transport.dispose();
  });

  it("continues a pending create command from a recoverable creating error projection", async () => {
    const connection = new FakeConnection();
    const state = fakeSession("session-recoverable-creating-client");
    state.stateProjection.set({
      status: "error",
      identity: { matchId: "match-browser", seat: "Russians", tick: 0 },
      failure: { phase: "creating", code: "TIMEOUT", message: "browser command receipt timed out", recoverable: true },
    });
    const seen = { value: 0 };
    const transport = makeTransport(connection, state, seen, {
      resolveAuthority: () => ({ matchId: "match-browser", seat: "Russians", tick: 0, status: "creating" }),
    });
    transport.start();
    let adapterCalls = 0;
    const adapters = new BrowserAdapterRegistry();
    adapters.register(state.session.id, {
      command: async (command) => {
        adapterCalls += 1;
        return successReceipt(command);
      },
    });
    const consumer = new BrowserCommandClientConsumer({
      rpc: connection.clientRpc,
      sessions: runningSessionPorts(state),
      adapters,
      clientInstanceId: "client-recoverable-creating-error",
    });
    consumer.start();
    const command = transport.dispatch(state.session, {
      matchId: "match-browser",
      seat: "Russians",
      expectedTick: 0,
      kind: "create-match",
      request: { map: "current", myCountry: "Russians", opponents: 1, opponentType: "normal", gameSpeed: 2 },
    }, new AbortController().signal);
    await expect(command).resolves.toMatchObject({ ok: true, tick: 1 });
    expect(adapterCalls).toBe(1);
    await consumer.dispose();
    await transport.dispose();
  });

  it("retries the same receipt after a transient RPC failure without rerunning the adapter", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    const transport = makeTransport(connection, state, seen);
    transport.start();
    const list = new Value({ current: state.session.id });
    const binding = {
      session: {
        projections: {
          faceOf: (key: string) => key === "redAlert" ? state.stateProjection : state.commandProjection,
        },
      },
    };
    const sessions = { list, binding: () => binding } as unknown as ISessions;
    const adapters = new BrowserAdapterRegistry();
    let adapterCalls = 0;
    let receiptCalls = 0;
    const receiptPayloads: unknown[] = [];
    adapters.register(state.session.id, {
      command: async (command) => {
        adapterCalls += 1;
        return successReceipt(command);
      },
    });
    const rpc: ClientConnectionRpc = {
      call: async (channel, endpoint, payload, signal) => {
        if (endpoint === "receipt") {
          receiptCalls += 1;
          receiptPayloads.push(payload);
          if (receiptCalls === 1) return { ok: false, error: { code: "internal", message: "temporary connection failure", details: {} } };
        }
        return connection.clientRpc.call(channel, endpoint, payload, signal);
      },
    };
    const consumer = new BrowserCommandClientConsumer({ rpc, sessions, adapters, clientInstanceId: "client-retry-receipt" });
    consumer.start();
    const command = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, new AbortController().signal);
    for (let attempt = 0; attempt < 20 && receiptCalls < 1; attempt += 1) await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(receiptCalls).toBe(1);
    await consumer.reconcile();
    await expect(command).resolves.toMatchObject({ ok: true, requestId: "request-browser-1" });
    expect(receiptCalls).toBe(2);
    expect(adapterCalls).toBe(1);
    expect(receiptPayloads[1]).toEqual(receiptPayloads[0]);
    await consumer.dispose();
    await transport.dispose();
  });

  it("reconciles the same receipt on a Cordis connection reset without rerunning the adapter", async () => {
    const connection = new FakeConnection();
    const state = fakeSession("session-service-reset");
    const seen = { value: 0 };
    const transport = makeTransport(connection, state, seen);
    transport.start();
    const list = new Value({ current: state.session.id });
    const binding = {
      session: {
        projections: {
          faceOf: (key: string) => key === "redAlert" ? state.stateProjection : state.commandProjection,
        },
      },
    };
    const sessions = { list, binding: () => binding } as unknown as ISessions;
    let adapterCalls = 0;
    let receiptCalls = 0;
    const receiptPayloads: unknown[] = [];
    const rpc: ClientConnectionRpc = {
      call: async (channel, endpoint, payload, signal) => {
        if (endpoint === "receipt") {
          receiptCalls += 1;
          receiptPayloads.push(payload);
          if (receiptCalls === 1) return { ok: false, error: { code: "internal", message: "connection lost", details: {} } };
        }
        return connection.clientRpc.call(channel, endpoint, payload, signal);
      },
    };
    const context = new Context();
    const service = new BrowserCommandClientService(context, { rpc, sessions, clientInstanceId: "client-service-reset" });
    service.adapters.register(state.session.id, { command: async (command) => {
      adapterCalls += 1;
      return successReceipt(command);
    } });
    const command = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, new AbortController().signal);
    for (let attempt = 0; attempt < 20 && receiptCalls < 1; attempt += 1) await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(receiptCalls).toBe(1);
    expect(adapterCalls).toBe(1);

    context.emit("connection/reset");
    await expect(command).resolves.toMatchObject({ ok: true, requestId: "request-browser-1" });
    expect(receiptCalls).toBe(2);
    expect(adapterCalls).toBe(1);
    expect(receiptPayloads[1]).toEqual(receiptPayloads[0]);

    await service.dispose();
    context.emit("connection/reset");
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(receiptCalls).toBe(2);
    await transport.dispose();
  });

  it("removes list, state, command, and adapter listeners on client dispose", async () => {
    const connection = new FakeConnection();
    const state = fakeSession("session-listener-cleanup");
    const list = new Value({ current: state.session.id });
    const binding = {
      session: {
        projections: {
          faceOf: (key: string) => key === "redAlert" ? state.stateProjection : state.commandProjection,
        },
      },
    };
    const sessions = { list, binding: () => binding } as unknown as ISessions;
    const adapters = new BrowserAdapterRegistry();
    adapters.register(state.session.id, { command: async (command) => successReceipt(command) });
    const consumer = new BrowserCommandClientConsumer({ rpc: connection.clientRpc, sessions, adapters, clientInstanceId: "client-listener-cleanup" });
    consumer.start();
    expect(list.listenerCount).toBe(1);
    expect(state.stateProjection.listenerCount).toBe(1);
    expect(state.commandProjection.listenerCount).toBe(1);
    expect(adapters.listenerCount).toBe(1);
    await consumer.dispose();
    expect(list.listenerCount).toBe(0);
    expect(state.stateProjection.listenerCount).toBe(0);
    expect(state.commandProjection.listenerCount).toBe(0);
    expect(adapters.listenerCount).toBe(0);
  });

  it("waits for a stale lease response and its release before dispose resolves", async () => {
    const connection = new FakeConnection();
    const first = fakeSession("session-lease-first");
    const second = fakeSession("session-lease-second");
    const seen = { value: 0 };
    const transport = makeTransport(connection, first, seen, {
      resolveSession: (sessionId) => sessionId === first.session.id ? first.session : second.session,
    });
    transport.start();
    let releaseRegister!: () => void;
    let releaseLease!: () => void;
    let releaseStarted = false;
    const delayedRpc: ClientConnectionRpc = {
      call: async (channel, endpoint, payload, signal) => {
        const result = await connection.clientRpc.call(channel, endpoint, payload, signal);
        if (endpoint === "lease/register") return new Promise<RpcResult<unknown>>((resolve) => { releaseRegister = () => resolve(result); });
        if (endpoint === "lease/release") {
          releaseStarted = true;
          return new Promise<RpcResult<unknown>>((resolve) => { releaseLease = () => resolve(result); });
        }
        return result;
      },
    };
    const list = new Value({ current: first.session.id });
    const binding = (state: FakeSessionState) => ({ session: { projections: { faceOf: (key: string) => key === "redAlert" ? state.stateProjection : state.commandProjection } } });
    const sessions = { list, binding: (id: SessionId) => id === first.session.id ? binding(first) : binding(second) } as unknown as ISessions;
    const consumer = new BrowserCommandClientConsumer({ rpc: delayedRpc, sessions, clientInstanceId: "client-stale-lease" });
    consumer.start();
    first.commandProjection.set({
      status: "pending",
      command: {
        protocolVersion: 1,
        requestId: "pending-lease-command",
        sessionId: first.session.id,
        matchId: "match-browser",
        seat: "Russians",
        expectedTick: 4,
        kind: "orders",
        orders: [],
      },
    });
    for (let attempt = 0; attempt < 10 && releaseRegister === undefined; attempt += 1) await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(releaseRegister).toBeTypeOf("function");
    let disposed = false;
    const disposing = consumer.dispose();
    const secondDisposing = consumer.dispose();
    expect(secondDisposing).toBe(disposing);
    void disposing.then(() => { disposed = true; });
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(disposed).toBe(false);
    releaseRegister();
    for (let attempt = 0; attempt < 10 && !releaseStarted; attempt += 1) await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(releaseStarted).toBe(true);
    expect(disposed).toBe(false);
    releaseLease();
    await disposing;
    expect(disposed).toBe(true);
    await transport.dispose();
  });

  it("waits for A cleanup before re-registering A after a fast A-to-B-to-A switch", async () => {
    const connection = new FakeConnection();
    const first = fakeSession("session-fast-a");
    const second = fakeSession("session-fast-b");
    const seen = { value: 0 };
    let requestNumber = 0;
    const transport = makeTransport(connection, first, seen, {
      resolveSession: (sessionId) => sessionId === first.session.id ? first.session : second.session,
      requestId: () => `request-fast-${++requestNumber}`,
    });
    transport.start();
    let releaseOldLease!: () => void;
    let releaseCallCount = 0;
    let oldReleaseStarted = false;
    const delayedReleaseRpc: ClientConnectionRpc = {
      call: async (channel, endpoint, payload, signal) => {
        const result = await connection.clientRpc.call(channel, endpoint, payload, signal);
        if (endpoint !== "lease/release") return result;
        releaseCallCount += 1;
        if (releaseCallCount === 1) {
          oldReleaseStarted = true;
          return new Promise<RpcResult<unknown>>((resolve) => { releaseOldLease = () => resolve(result); });
        }
        return result;
      },
    };
    const list = new Value({ current: first.session.id });
    const binding = (state: FakeSessionState) => ({ session: { projections: { faceOf: (key: string) => key === "redAlert" ? state.stateProjection : state.commandProjection } } });
    const sessions = { list, binding: (id: SessionId) => id === first.session.id ? binding(first) : binding(second) } as unknown as ISessions;
    const adapters = new BrowserAdapterRegistry();
    let adapterCalls = 0;
    let markFirstStarted!: () => void;
    const firstStarted = new Promise<void>((resolve) => { markFirstStarted = resolve; });
    let releaseFirstAdapter!: () => void;
    adapters.register(first.session.id, {
      command: async (command) => {
        adapterCalls += 1;
        if (adapterCalls === 1) {
          markFirstStarted();
          await new Promise<void>((resolve) => { releaseFirstAdapter = resolve; });
        }
        return successReceipt(command);
      },
    });
    const consumer = new BrowserCommandClientConsumer({ rpc: delayedReleaseRpc, sessions, adapters, clientInstanceId: "client-fast-switch" });
    consumer.start();
    const oldCommand = transport.dispatch(first.session, { matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [] }, new AbortController().signal);
    await firstStarted;
    list.set({ current: second.session.id });
    await expect(oldCommand).resolves.toMatchObject({ ok: false, detail: expect.stringContaining("CLIENT_DISPOSED") });
    expect(adapterCalls).toBe(1);
    expect(oldReleaseStarted).toBe(false);
    list.set({ current: first.session.id });
    const nextCommand = transport.dispatch(first.session, { matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [{ action: "move", x: 8, y: 9 }] }, new AbortController().signal);
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(adapterCalls).toBe(1);
    expect(oldReleaseStarted).toBe(false);
    releaseFirstAdapter();
    for (let attempt = 0; attempt < 10 && !oldReleaseStarted; attempt += 1) await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(oldReleaseStarted).toBe(true);
    releaseOldLease();
    await expect(nextCommand).resolves.toMatchObject({ ok: true, requestId: "request-fast-2" });
    expect(adapterCalls).toBe(2);
    await consumer.dispose();
    await transport.dispose();
  });

  it("waits for the adapter promise across two shared client dispose calls", async () => {
    const connection = new FakeConnection();
    const state = fakeSession("session-client-dispose");
    const seen = { value: 0 };
    const transport = makeTransport(connection, state, seen);
    transport.start();
    const adapters = new BrowserAdapterRegistry();
    let adapterCalls = 0;
    let markStarted!: () => void;
    const started = new Promise<void>((resolve) => { markStarted = resolve; });
    let releaseAdapter!: () => void;
    adapters.register(state.session.id, {
      command: async (command) => {
        adapterCalls += 1;
        markStarted();
        await new Promise<void>((resolve) => { releaseAdapter = resolve; });
        return successReceipt(command);
      },
    });
    const consumer = new BrowserCommandClientConsumer({
      rpc: connection.clientRpc,
      sessions: runningSessionPorts(state),
      adapters,
      clientInstanceId: "client-double-dispose",
    });
    consumer.start();
    const command = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [],
    }, new AbortController().signal);
    await started;
    const firstDispose = consumer.dispose();
    const secondDispose = consumer.dispose();
    expect(secondDispose).toBe(firstDispose);
    await expect(command).resolves.toMatchObject({ ok: false, detail: expect.stringContaining("CLIENT_DISPOSED") });
    let disposed = false;
    void firstDispose.then(() => { disposed = true; });
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(disposed).toBe(false);
    expect(adapterCalls).toBe(1);
    releaseAdapter();
    await Promise.all([firstDispose, secondDispose]);
    expect(disposed).toBe(true);
    expect(adapters.listenerCount).toBe(0);
    await transport.dispose();
  });

  it("assembles Host event/projection, official Connection RPC, client root, and fake adapter exactly once", async () => {
    const connection = new FakeConnection();
    const state = fakeSession();
    const seen = { value: 0 };
    const official = await officialSessionFixture(state.session.id);
    const runningState = {
      status: "running",
      match: { matchId: "match-browser", seat: "Russians", tick: 4, status: "active" },
    } as const;
    publishOfficialProjection(official, "redAlert", runningState, 1);
    expect(official.sessions.binding(official.sessionId)?.session.projections.faceOf("redAlert").getSnapshot()).toEqual(runningState);
    state.publishCommandProjection = (value, seq) => publishOfficialProjection(official, "redAlertCommand", value, seq + 1);
    const transport = makeTransport(connection, state, seen);
    transport.start();
    let adapterCalls = 0;
    const adapter: BrowserMatchAdapter = {
      command: async (command) => {
        adapterCalls += 1;
        return successReceipt(command);
      },
    };
    const adapters = new BrowserAdapterRegistry();
    adapters.register("session-browser", adapter);
    const consumer = new BrowserCommandClientConsumer({ rpc: connection.clientRpc, sessions: official.sessions, adapters, clientInstanceId: "client-assembled" });
    consumer.start();

    const commandResult = transport.dispatch(state.session, {
      matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [{ action: "move", x: 3, y: 4 }],
    }, new AbortController().signal);
    const receipt = await commandResult;
    expect(receipt).toMatchObject({ requestId: "request-browser-1", sessionId: "session-browser", matchId: "match-browser", seat: "Russians", ok: true, tick: 5 });
    expect(adapterCalls).toBe(1);
    expect(state.events.map((event) => event.type)).toEqual([
      RED_ALERT_BROWSER_COMMAND_EVENT,
      RED_ALERT_BROWSER_COMMAND_PUBLISHED_EVENT,
      RED_ALERT_BROWSER_COMMAND_RESULT_EVENT,
      RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT,
    ]);
    expect(state.commandProjection.getSnapshot().status).toBe("completed");

    await consumer.reconcile();
    state.commandProjection.set(state.commandProjection.getSnapshot());
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(adapterCalls).toBe(1);
    await consumer.dispose();
    await transport.dispose();
  });

  it("keeps session switch and dispose isolated from old command subscriptions", async () => {
    const connection = new FakeConnection();
    const first = fakeSession("session-one");
    const second = fakeSession("session-two");
    const seen = { value: 0 };
    const transport = makeTransport(connection, first, seen, {
      isSessionOwner: () => true,
      resolveAuthority: (_sessionId) => ({ matchId: "match-browser", seat: "Russians", tick: 4, status: "active" }),
      resolveSession: (sessionId) => sessionId === "session-one" ? first.session : second.session,
      requestId: () => "request-switch",
    });
    transport.start();
    const list = new Value({ current: first.session.id });
    const binding = (state: FakeSessionState) => ({ session: { projections: { faceOf: (key: string) => key === "redAlert" ? state.stateProjection : state.commandProjection } } });
    const sessions = { list, binding: (id: SessionId) => id === first.session.id ? binding(first) : binding(second) } as unknown as ISessions;
    const adapters = new BrowserAdapterRegistry();
    let calls = 0;
    let releaseAdapter!: () => void;
    adapters.register("session-one", { command: async (command) => {
      calls += 1;
      await new Promise<void>((resolve) => { releaseAdapter = resolve; });
      return successReceipt(command);
    } });
    const consumer = new BrowserCommandClientConsumer({ rpc: connection.clientRpc, sessions, adapters, clientInstanceId: "client-switch" });
    consumer.start();
    const oldCommand = transport.dispatch(first.session, { matchId: "match-browser", seat: "Russians", expectedTick: 4, kind: "orders", orders: [] }, new AbortController().signal);
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    list.set({ current: second.session.id });
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    expect(consumer.adapters.get("session-two")).toBeUndefined();
    expect(calls).toBeLessThanOrEqual(1);
    const disposing = consumer.dispose();
    const secondDisposing = consumer.dispose();
    expect(secondDisposing).toBe(disposing);
    await expect(oldCommand).resolves.toMatchObject({ ok: false, detail: expect.stringContaining("CLIENT_DISPOSED") });
    releaseAdapter?.();
    await disposing;
    await transport.dispose();
  });
});
