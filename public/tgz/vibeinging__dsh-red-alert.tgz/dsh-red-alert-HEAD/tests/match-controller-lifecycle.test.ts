import assert from "node:assert/strict";
import path from "node:path";
import { it } from "vitest";
import { MatchController } from "../packages/game-host/src/match-controller.js";

interface ControllerRecord {
  readonly matchId: string;
  readonly owner: { readonly agentId: string; readonly sessionId: string };
  readonly game: { update: () => Promise<void> };
  status: string;
}

interface ControllerInternals {
  readonly records: Map<string, ControllerRecord>;
  readonly activeBySession: Map<string, string>;
}

function internals(controller: MatchController): ControllerInternals {
  return controller as unknown as ControllerInternals;
}

it("Agent disposal waits for an in-flight act before closing the match", async () => {
  const controller = new MatchController(path.resolve("assets"));
  const owner = { agentId: "agent-lifecycle", sessionId: "agent-lifecycle" };
  try {
    const started = await controller.start(owner, {
      map: "simple-1v1-no-preview.map",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "noop",
      decisionPeriod: 1,
      maxTicks: 20,
    }, new AbortController().signal);
    const record = internals(controller).records.get(started.matchId);
    assert.ok(record);

    let releaseUpdate!: () => void;
    const updateReleased = new Promise<void>((resolve) => { releaseUpdate = resolve; });
    let updateEntered!: () => void;
    const updateStarted = new Promise<void>((resolve) => { updateEntered = resolve; });
    const originalUpdate = record.game.update.bind(record.game);
    record.game.update = async () => {
      updateEntered();
      await updateReleased;
      await originalUpdate();
    };

    const actPromise = controller.act(owner, started.matchId, [], new AbortController().signal);
    await updateStarted;
    let stopFinished = false;
    const stopPromise = controller.stopOwner(owner).then(() => { stopFinished = true; });
    await Promise.resolve();
    assert.equal(stopFinished, false);
    assert.equal(internals(controller).activeBySession.get(owner.sessionId), started.matchId);

    releaseUpdate();
    await actPromise;
    await stopPromise;
    assert.equal(stopFinished, true);
    assert.equal(record.status, "stopped");
    assert.equal(internals(controller).activeBySession.has(owner.sessionId), false);
    controller.assertInvariants((message): never => { throw new Error(message); });
  } finally {
    await controller.dispose();
  }
});
