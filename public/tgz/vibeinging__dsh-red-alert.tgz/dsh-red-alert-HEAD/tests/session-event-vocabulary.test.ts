import { describe, expect, it } from "vitest";

import {
  RED_ALERT_BROWSER_COMMAND_EVENT,
  RED_ALERT_BROWSER_COMMAND_PUBLISHED_EVENT,
  RED_ALERT_BROWSER_COMMAND_RESULT_EVENT,
  RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT,
} from "../src/browser-command-protocol.ts";
import { RED_ALERT_EVENT } from "../src/projection.ts";
import { RED_ALERT_SESSION_EVENT_TYPES } from "../src/session-event-types.ts";
import {
  RED_ALERT_STRATEGY_BRIEF_EVENT,
  RED_ALERT_STRATEGY_EPISODE_EVENT,
  RED_ALERT_STRATEGY_REVIEW_EVENT,
} from "../src/strategy-learning.ts";
import { RED_ALERT_TOOL_GROUP_EVENT } from "../src/tool-groups.ts";
import { RED_ALERT_FIELD_MANUAL_EVENT } from "../src/field-manual.ts";

describe("red-alert session event vocabulary", () => {
  it("lists every durable plugin event once", () => {
    expect(new Set(RED_ALERT_SESSION_EVENT_TYPES).size).toBe(RED_ALERT_SESSION_EVENT_TYPES.length);
    expect(RED_ALERT_SESSION_EVENT_TYPES).toEqual([
      RED_ALERT_EVENT,
      RED_ALERT_TOOL_GROUP_EVENT,
      RED_ALERT_FIELD_MANUAL_EVENT,
      RED_ALERT_STRATEGY_BRIEF_EVENT,
      RED_ALERT_STRATEGY_EPISODE_EVENT,
      RED_ALERT_STRATEGY_REVIEW_EVENT,
      RED_ALERT_BROWSER_COMMAND_EVENT,
      RED_ALERT_BROWSER_COMMAND_PUBLISHED_EVENT,
      RED_ALERT_BROWSER_COMMAND_RESULT_EVENT,
      RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT,
    ]);
  });
});
