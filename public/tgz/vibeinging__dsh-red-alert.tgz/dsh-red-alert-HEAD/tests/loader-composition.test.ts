import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { afterEach, describe, expect, it, vi } from "vitest";
import { Context } from "@deepseek-ai/cordis";
import Include from "@deepseek-ai/cordis-plugin-include";
import Loader from "@deepseek-ai/cordis-plugin-loader";
import type { HostConnectionHandle } from "@deepseek-ai/dsh-client-connection";
import type { WebRoute } from "@deepseek-ai/dsh-host-webserver";
import AgentRegistry from "@deepseek-ai/dsh-agent";
import AgentLoop from "@deepseek-ai/dsh-agent-loop";
import InvariantService from "@deepseek-ai/dsh-invariants";
import { CallId } from "@deepseek-ai/dsh-llm";
import LlmService from "@deepseek-ai/dsh-llm";
import SessionStore, { SessionId, type SessionEvent } from "@deepseek-ai/dsh-session";
import Settings, { SettingsNamespace } from "@deepseek-ai/dsh-settings";
import SessionProjection from "@deepseek-ai/dsh-session-projection";
import SystemPrompt from "@deepseek-ai/dsh-system-prompt";
import ToolRegistry, { defineTool, ToolExecutionResult } from "@deepseek-ai/dsh-tools";
import * as RedAlert from "@vibeinging/dsh-red-alert";
import * as RedAlertInvariant from "@vibeinging/dsh-red-alert/invariant";
import { decodeToolGroupSelection, restoreSelectedGroups } from "../src/tool-groups.ts";
import { IMPLEMENTED_TOOL_NAMES } from "../src/tool-policy.ts";
import { RED_ALERT_STRATEGY_PROMPT } from "../src/strategy-prompt.ts";
import { creatingState, failureState } from "../src/projection.ts";

let context: Context | undefined;
let temporaryRoot: string | undefined;
let rendererRoot: string | undefined;
let callNumber = 0;

const TEST_CONNECTION: HostConnectionHandle = {
  rpc: {
    handle: (_channel, _handler, _options) => async () => {},
    intercept: (_channel, _matches, _handler, _options) => async () => {},
  },
};

const BASE_PROFILE_SERVICE_ROWS = [
  "- name: '@deepseek-ai/dsh-settings-local'",
  "- name: '@deepseek-ai/dsh-llm'",
  "- name: '@deepseek-ai/dsh-session'",
  "- name: '@deepseek-ai/dsh-system-prompt'",
  "- name: '@deepseek-ai/dsh-tools'",
  "- name: '@deepseek-ai/dsh-agent'",
  "- name: '@deepseek-ai/dsh-agent-loop'",
  "  config: { agents: [] }",
] as const;
const SESSION_PROJECTION_SERVICE_ROW = "- name: '@deepseek-ai/dsh-session-projection'" as const;

async function redAlertPatchRows(): Promise<string[]> {
  const patch = await readFile(path.resolve("cordis.patch.yml"), "utf8");
  const names = [...patch.matchAll(/^\s+name:\s*'([^']+)'/gm)].map((match) => match[1]);
  expect(names).toEqual([
    "@deepseek-ai/dsh-invariants",
    "@vibeinging/dsh-red-alert",
    "@vibeinging/dsh-red-alert/invariant",
  ]);
  return names.flatMap((name) => {
    if (name === "@vibeinging/dsh-red-alert") {
      return [
        `- name: '${name}'`,
        `  config: { assetsDir: ${JSON.stringify(path.resolve("assets"))} }`,
      ];
    }
    return [`- name: '${name}'`];
  });
}

async function loadBaseProfileWithRedAlertPatch(): Promise<Context> {
  return loadBundle([
    ...BASE_PROFILE_SERVICE_ROWS,
    SESSION_PROJECTION_SERVICE_ROW,
    ...(await redAlertPatchRows()),
  ]);
}

class MemorySettings extends Settings {
  readonly writable = false;

  protected async load(): Promise<Record<string, unknown>> {
    return {};
  }

  protected async persist(_namespace: SettingsNamespace, _section: Record<string, unknown>): Promise<void> {}
}

interface LoadBundleOptions {
  readonly connection?: HostConnectionHandle | null;
  readonly webServer?: {
    readonly host: string;
    readonly port: number;
    register(route: WebRoute): () => void;
  };
}

async function loadBundle(configLines: readonly string[], options: LoadBundleOptions = {}): Promise<Context> {
  temporaryRoot = await mkdtemp(path.join(tmpdir(), "dsh-red-alert-loader-"));
  const configPath = path.join(temporaryRoot, "cordis.yml");
  await writeFile(configPath, `${configLines.join("\n")}\n`);

  context = new Context();
  context.baseUrl = pathToFileURL(temporaryRoot).href + "/";
  if (options.connection !== null) context.provide("connection", options.connection ?? TEST_CONNECTION);
  if (options.webServer !== undefined) context.provide("webServer", options.webServer);
  await context.plugin(Loader);
  context.loader.builtins.include = Include;
  const modules = new Map<string, unknown>([
    ["@deepseek-ai/dsh-invariants", InvariantService],
    ["@deepseek-ai/dsh-settings", MemorySettings],
    ["@deepseek-ai/dsh-settings-local", MemorySettings],
    ["@deepseek-ai/dsh-llm", LlmService],
    ["@deepseek-ai/dsh-session", SessionStore],
    ["@deepseek-ai/dsh-session-projection", SessionProjection],
    ["@deepseek-ai/dsh-system-prompt", SystemPrompt],
    ["@deepseek-ai/dsh-tools", ToolRegistry],
    ["@deepseek-ai/dsh-agent", AgentRegistry],
    ["@deepseek-ai/dsh-agent-loop", AgentLoop],
    ["@vibeinging/dsh-red-alert", RedAlert],
    ["@vibeinging/dsh-red-alert/invariant", RedAlertInvariant],
  ]);
  context.loader.internal = {
    version: "v2",
    async import(specifier: string) {
      const module = modules.get(specifier);
      if (module === undefined) throw new Error(`unexpected Loader import: ${specifier}`);
      return module;
    },
  } as unknown as NonNullable<typeof context.loader.internal>;
  await context.loader.create({
    name: "cordis:include",
    config: { path: pathToFileURL(configPath).href },
  });
  await context.loader.await();
  return context;
}

async function callTool(
  ctx: Context,
  agent: NonNullable<Context["agent"]>,
  name: string,
  args: unknown,
  signal = new AbortController().signal,
): Promise<ToolExecutionResult> {
  return ctx.tools.execute({
    callId: CallId(`red-alert-test-${callNumber++}`),
    name,
    arguments: args,
    agent,
    signal,
  });
}

function valueOf(result: ToolExecutionResult): Record<string, unknown> {
  expect(result.isError, result.isError ? result.error.message : undefined).toBe(false);
  if (result.isError) throw new Error(result.error.message);
  return result.value as Record<string, unknown>;
}

async function loadGroup(
  ctx: Context,
  agent: NonNullable<Context["agent"]>,
  group: string,
  matchId?: string,
): Promise<Record<string, unknown>> {
  return valueOf(await callTool(ctx, agent, "red_alert_load_group", {
    group,
    ...(matchId === undefined ? {} : { matchId }),
  }));
}

afterEach(async () => {
  await context?.fiber.dispose();
  context = undefined;
  vi.unstubAllEnvs();
  if (temporaryRoot !== undefined) await rm(temporaryRoot, { recursive: true, force: true });
  temporaryRoot = undefined;
  if (rendererRoot !== undefined) await rm(rendererRoot, { recursive: true, force: true });
  rendererRoot = undefined;
});

describe("real DSH Loader composition", () => {
  it("does not block plugin loading while the optional Web server is unavailable", async () => {
    rendererRoot = await mkdtemp(path.join(tmpdir(), "dsh-red-alert-renderer-deferred-web-"));
    await writeFile(path.join(rendererRoot, "index.html"), "real renderer entry");
    context = new Context();
    await RedAlert.registerHostSessionEventVocabulary();

    const outcome = await Promise.race([
      RedAlert.apply(context, { rendererDistDir: rendererRoot }).then(() => "returned" as const),
      new Promise<"blocked">((resolve) => setTimeout(() => resolve("blocked"), 250)),
    ]);

    expect(outcome).toBe("returned");
    expect(context.get("redAlert", false)).toBeUndefined();
    expect(context.get("redAlertRendererHost", false)).toBeUndefined();
  });

  it("starts when the base service set supplies session-projection and the patch supplies invariants", async () => {
    const ctx = await loadBaseProfileWithRedAlertPatch();
    expect(ctx.invariants).toBeDefined();
    await expect(ctx.systemPrompt.assemble()).resolves.toMatchObject({
      sections: expect.arrayContaining([{
        name: "red-alert:opening-doctrine",
        text: RED_ALERT_STRATEGY_PROMPT,
      }]),
    });
    expect(RED_ALERT_STRATEGY_PROMPT).toContain("queue status 3 (ready)");
    expect(RED_ALERT_STRATEGY_PROMPT).toContain("Never repeat placement while its queue");
    expect(RED_ALERT_STRATEGY_PROMPT).toContain("at least 16 combat units defend");
    expect(RED_ALERT_STRATEGY_PROMPT).toContain("one cheap anti-infantry base defense");
    expect(RED_ALERT_STRATEGY_PROMPT).toContain("NAWEAP and GAWEAP are war factories");
    expect(RED_ALERT_STRATEGY_PROMPT).toContain("NAYARD and GAYARD are naval yards");
    expect(RED_ALERT_STRATEGY_PROMPT).toContain("remove stale ids");
    expect(RED_ALERT_STRATEGY_PROMPT).toContain("red_alert_strategy_brief");
    expect(RED_ALERT_STRATEGY_PROMPT).toContain("red_alert_field_manual");
    expect(RED_ALERT_STRATEGY_PROMPT).toContain("gameSpeed 2");
    expect(RED_ALERT_STRATEGY_PROMPT).toContain("commandView");
    expect(RED_ALERT_STRATEGY_PROMPT).toContain("only tactical decision maker");
    expect(RED_ALERT_STRATEGY_PROMPT).toContain("one red_alert_unit_order orders array");
    expect(RED_ALERT_STRATEGY_PROMPT).toContain("red_alert_review_match");
    expect(ctx.tools.schemas().map((tool) => tool.name)).toEqual(expect.arrayContaining([
      "red_alert_start",
      "red_alert_unit_order",
      "red_alert_status",
      "red_alert_stop",
    ]));
    expect(ctx.tools.schemas().map((tool) => tool.name)).not.toContain("red_alert_commander_start");
    expect(ctx.tools.schemas().map((tool) => tool.name)).toEqual(expect.arrayContaining(IMPLEMENTED_TOOL_NAMES));
    const handle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-base-profile"),
      agentOptions: { provider: "unused", model: "unused" },
    });
    const initialRedAlertNames = ctx.tools.schemas(handle.agent)
      .map((tool) => tool.name)
      .filter((name) => name.startsWith("red_alert_"));
    expect(initialRedAlertNames).toEqual(expect.arrayContaining([
      "red_alert_capabilities",
      "red_alert_load_group",
    ]));
    expect(initialRedAlertNames).toHaveLength(2);
    await loadGroup(ctx, handle.agent, "lobby/setup");
    const lobbyRedAlertNames = ctx.tools.schemas(handle.agent)
      .map((tool) => tool.name)
      .filter((name) => name.startsWith("red_alert_"));
    expect(lobbyRedAlertNames).toEqual(expect.arrayContaining([
      "red_alert_capabilities",
      "red_alert_load_group",
      "red_alert_start",
    ]));
    expect(lobbyRedAlertNames).toHaveLength(3);
    const started = valueOf(await callTool(ctx, handle.agent, "red_alert_start", {
      map: "simple-1v1-no-preview.map",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "noop",
      decisionPeriod: 1,
      maxTicks: 8,
    }));
    expect(started.view).toEqual({ mode: "offline", realUiAvailable: false });
    await handle.dispose();
    expect(ctx.redAlert.controller).toBeDefined();
  });

  it("can disable the opening doctrine without removing red-alert tools", async () => {
    const ctx = await loadBundle([
      ...BASE_PROFILE_SERVICE_ROWS,
      SESSION_PROJECTION_SERVICE_ROW,
      "- name: '@vibeinging/dsh-red-alert'",
      `  config: { assetsDir: ${JSON.stringify(path.resolve("assets"))}, enableOpeningDoctrine: false }`,
    ]);
    const assembly = await ctx.systemPrompt.assemble();
    expect(assembly.sections.map((section) => section.name)).not.toContain("red-alert:opening-doctrine");
    expect(ctx.tools.schemas().map((tool) => tool.name)).toContain("red_alert_start");
  });

  it("starts a Web composition with exactly one base session-projection service", async () => {
    const patchRows = await redAlertPatchRows();
    const compositionRows = [
      ...BASE_PROFILE_SERVICE_ROWS,
      SESSION_PROJECTION_SERVICE_ROW,
      ...patchRows,
    ];
    expect(compositionRows.filter((row) => row.includes("@deepseek-ai/dsh-session-projection"))).toHaveLength(1);

    const ctx = await loadBundle(compositionRows);
    expect(ctx.sessionProjections).toBeDefined();
    const handle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-web-composition"),
      agentOptions: { provider: "unused", model: "unused" },
    });
    await loadGroup(ctx, handle.agent, "lobby/setup");
    const started = valueOf(await callTool(ctx, handle.agent, "red_alert_start", {
      map: "simple-1v1-no-preview.map",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "noop",
      decisionPeriod: 1,
      maxTicks: 8,
    }));
    const projection = ctx.sessionProjections.snapshot(handle.agent.session).values.redAlert as {
      readonly status: string;
    };
    expect(projection.status).toBe("running");
    expect(started.matchId).toBeDefined();
    await handle.dispose();
  });

  it("starts browser authority before MatchService and exposes bootstrap tools on the latest DSH Web host", async () => {
    rendererRoot = await mkdtemp(path.join(tmpdir(), "dsh-red-alert-renderer-loader-"));
    await writeFile(path.join(rendererRoot, "index.html"), "real renderer entry");
    const routes: WebRoute[] = [];
    const ctx = await loadBundle([
      ...BASE_PROFILE_SERVICE_ROWS,
      SESSION_PROJECTION_SERVICE_ROW,
      "- name: '@vibeinging/dsh-red-alert'",
      `  config: { rendererDistDir: ${JSON.stringify(rendererRoot)} }`,
    ], {
      connection: null,
      webServer: {
        host: "127.0.0.1",
        port: 3080,
        register(route) {
          routes.push(route);
          return () => undefined;
        },
      },
    });

    expect(ctx.redAlert.controller).toBeUndefined();
    expect(ctx.redAlert.rendererDescriptor).toEqual({
      mode: "loopback",
      enabled: true,
      sourceLabel: "用户确认的本地兼容客户端",
      adapterAttachTimeoutMs: 30_000,
    });
    expect(ctx.redAlert.defaults.gameSpeed).toBe(2);
    expect(ctx.redAlertCompatConnection).toBeDefined();
    expect(routes).toEqual(expect.arrayContaining([
      expect.objectContaining({ kind: "prefix", path: "/red-alert" }),
    ]));

    const handle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-browser-old-dsh"),
      agentOptions: { provider: "unused", model: "unused" },
    });
    const initialRedAlertNames = ctx.tools.schemas(handle.agent)
      .map((tool) => tool.name)
      .filter((toolName) => toolName.startsWith("red_alert_"));
    expect(initialRedAlertNames).toEqual([
      "red_alert_capabilities",
      "red_alert_load_group",
    ]);
    await handle.dispose();
  });

  it("keeps live renderer authority during a recoverable creating error", async () => {
    rendererRoot = await mkdtemp(path.join(tmpdir(), "dsh-red-alert-renderer-recoverable-creating-"));
    await writeFile(path.join(rendererRoot, "index.html"), "real renderer entry");
    const ctx = await loadBundle([
      ...BASE_PROFILE_SERVICE_ROWS,
      SESSION_PROJECTION_SERVICE_ROW,
      "- name: '@vibeinging/dsh-red-alert'",
      `  config: { rendererDistDir: ${JSON.stringify(rendererRoot)} }`,
    ], {
      connection: null,
      webServer: {
        host: "127.0.0.1",
        port: 3080,
        register: () => () => undefined,
      },
    });
    const handle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-recoverable-creating-authority"),
      agentOptions: { provider: "unused", model: "unused" },
    });
    const request = {
      map: "current",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "normal" as const,
      gameSpeed: 2,
      decisionPeriod: 15,
      maxTicks: 600,
    };
    const identity = {
      matchId: "recoverable-creating-match",
      sessionId: String(handle.agent.session.id),
      seat: "Russians",
      tick: 0,
    };
    handle.agent.session.append("red-alert/state", failureState("creating", new Error("browser command receipt timed out"), undefined, request, identity));
    await ctx.sessions.flush(handle.agent.session);

    const abort = new AbortController();
    const dispatched = ctx.redAlert.browserTransport!.dispatch(handle.agent.session, {
      matchId: identity.matchId,
      seat: identity.seat,
      expectedTick: identity.tick,
      kind: "create-match",
      request: {
        map: request.map,
        myCountry: request.myCountry,
        opponents: request.opponents,
        opponentType: request.opponentType,
        gameSpeed: request.gameSpeed,
      },
    }, abort.signal);
    abort.abort();
    await expect(dispatched).rejects.toMatchObject({ code: "CANCELLED" });
    expect(handle.agent.session.events.some(event => event.type === "red-alert/browser-command-admitted")).toBe(true);
    await handle.dispose();
  });

  it("retries one stale browser creation after restart without duplicating a live command", async () => {
    rendererRoot = await mkdtemp(path.join(tmpdir(), "dsh-red-alert-renderer-retry-"));
    await writeFile(path.join(rendererRoot, "index.html"), "real renderer entry");
    const ctx = await loadBundle([
      ...BASE_PROFILE_SERVICE_ROWS,
      SESSION_PROJECTION_SERVICE_ROW,
      "- name: '@vibeinging/dsh-red-alert'",
      `  config: { rendererDistDir: ${JSON.stringify(rendererRoot)} }`,
    ], {
      webServer: {
        host: "127.0.0.1",
        port: 3080,
        register() {
          return () => undefined;
        },
      },
    });
    const handle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-browser-retry-after-restart"),
      agentOptions: { provider: "unused", model: "unused" },
    });
    await loadGroup(ctx, handle.agent, "lobby/setup");
    const request = {
      map: "current",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "normal" as const,
      gameSpeed: 2,
      decisionPeriod: 15,
      maxTicks: 600,
    };
    const staleCreating = creatingState(request, {
      matchId: "stale-browser-match",
      sessionId: String(handle.agent.session.id),
      seat: "Russians",
      tick: 0,
    });
    handle.agent.session.append("red-alert/state", staleCreating);
    await ctx.sessions.flush(handle.agent.session);

    const capabilities = valueOf(await callTool(ctx, handle.agent, "red_alert_capabilities", {})) as { phase: string };
    expect(capabilities.phase).toBe("lobby-ready");
    expect(ctx.tools.schemas(handle.agent).map(tool => tool.name)).toContain("red_alert_start");

    const replacementDispatch = vi.fn(async (..._args: unknown[]) => {
      throw new Error("replacement dispatch reached");
    });
    const service = ctx.redAlert as unknown as {
      browserTransport: {
        hasPending(sessionId: string): boolean;
        dispatch(...args: unknown[]): Promise<never>;
      };
    };
    service.browserTransport = {
      hasPending: () => false,
      dispatch: replacementDispatch,
    };
    const retry = await callTool(ctx, handle.agent, "red_alert_start", request);
    expect(retry.isError).toBe(true);
    if (retry.isError) expect(retry.error.message).toContain("replacement dispatch reached");
    expect(replacementDispatch).toHaveBeenCalledOnce();
    expect(handle.agent.session.events
      .filter(event => event.type === "red-alert/state")
      .map(event => event.data.status)
      .slice(-3)).toEqual(["error", "creating", "error"]);

    handle.agent.session.append("red-alert/state", staleCreating);
    await ctx.sessions.flush(handle.agent.session);
    service.browserTransport = {
      hasPending: () => true,
      dispatch: replacementDispatch,
    };
    const duplicate = await callTool(ctx, handle.agent, "red_alert_start", request);
    expect(duplicate.isError).toBe(true);
    if (duplicate.isError) expect(duplicate.error.message).toContain("already has a browser match creation in flight");
    expect(replacementDispatch).toHaveBeenCalledOnce();
    await handle.dispose();
  });

  it("loads the published patch renderer port expression as a number", async () => {
    rendererRoot = await mkdtemp(path.join(tmpdir(), "dsh-red-alert-renderer-port-loader-"));
    await writeFile(path.join(rendererRoot, "index.html"), "real renderer entry");
    vi.stubEnv("RA_RENDERER_DIST_DIR", rendererRoot);
    vi.stubEnv("RA_RENDERER_PORT", "0");

    const ctx = await loadBundle([
      ...BASE_PROFILE_SERVICE_ROWS,
      SESSION_PROJECTION_SERVICE_ROW,
      "- name: '@vibeinging/dsh-red-alert'",
      "  config:",
      "    rendererDistDir: !!js process.env.RA_RENDERER_DIST_DIR",
      "    rendererPort: !!js 'process.env.RA_RENDERER_PORT ? Number(process.env.RA_RENDERER_PORT) : undefined'",
    ], {
      connection: null,
      webServer: {
        host: "127.0.0.1",
        port: 3080,
        register: () => () => undefined,
      },
    });

    expect(ctx.redAlert.rendererDescriptor).toMatchObject({
      mode: "loopback",
      enabled: true,
    });
  });

  it("persists a fog-safe strategy episode and structured review across a natural headless result", async () => {
    const ctx = await loadBaseProfileWithRedAlertPatch();
    const handle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-auto-learning"),
      agentOptions: { provider: "unused", model: "unused" },
    });

    await loadGroup(ctx, handle.agent, "strategy/learning");
    const manual = valueOf(await callTool(ctx, handle.agent, "red_alert_field_manual", {
      topic: "structures",
      faction: "soviet",
    }));
    expect(manual).toMatchObject({ topic: "structures", faction: "soviet" });
    expect((manual.entries as Array<{ id: string }>).map(entry => entry.id)).toContain("NAWEAP");
    expect(handle.agent.session.events.some(event => event.type === "red-alert/field-manual")).toBe(true);
    const firstBrief = valueOf(await callTool(ctx, handle.agent, "red_alert_strategy_brief", {
      map: "simple-1v1-no-preview.map",
      myCountry: "Russians",
      opponentType: "noop",
    }));
    expect(firstBrief).toMatchObject({ rules: [], sourceMatchIds: [] });
    await loadGroup(ctx, handle.agent, "lobby/setup");
    const started = valueOf(await callTool(ctx, handle.agent, "red_alert_start", {
      map: "simple-1v1-no-preview.map",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "noop",
      decisionPeriod: 1,
      maxTicks: 2,
    }));
    const matchId = started.matchId as string;
    const creating = handle.agent.session.events.find(event => event.type === "red-alert/state" && event.data.status === "creating");
    expect(creating?.type === "red-alert/state" ? creating.data.request?.gameSpeed : undefined).toBe(2);

    await loadGroup(ctx, handle.agent, "units/combat", matchId);
    const finished = valueOf(await callTool(ctx, handle.agent, "red_alert_unit_order", { matchId, orders: [] }));
    expect(finished.status).toBe("finished");
    const episode = handle.agent.session.events.find(event => event.type === "red-alert/strategy-episode");
    expect(episode?.type === "red-alert/strategy-episode" ? episode.data.matchId : undefined).toBe(matchId);
    expect(ctx.tools.schemas(handle.agent).map(tool => tool.name)).toContain("red_alert_review_match");

    const reviewed = valueOf(await callTool(ctx, handle.agent, "red_alert_review_match", {
      matchId,
      adoptedRuleIds: [],
      rejectedRuleIds: [],
    }));
    expect(reviewed.status).toBe("committed");
    expect(handle.agent.session.events.some(event => event.type === "red-alert/strategy-review")).toBe(true);
    expect(valueOf(await callTool(ctx, handle.agent, "red_alert_capabilities", {})).phase).toBe("ended");
    expect(ctx.tools.schemas(handle.agent).map(tool => tool.name)).toContain("red_alert_start");
    const rematch = valueOf(await callTool(ctx, handle.agent, "red_alert_start", {
      map: "simple-1v1-no-preview.map",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "noop",
      decisionPeriod: 1,
      maxTicks: 4,
    }));
    expect(rematch.status).toBe("active");
    expect(rematch.matchId).not.toBe(matchId);
    await handle.dispose();
  });

  it("registers isolated offline start, act, status, and stop tools", async () => {
    const ctx = await loadBundle([
      "- name: '@deepseek-ai/dsh-invariants'",
      "- name: '@deepseek-ai/dsh-settings'",
      "- name: '@deepseek-ai/dsh-llm'",
      "- name: '@deepseek-ai/dsh-session'",
      "- name: '@deepseek-ai/dsh-session-projection'",
      "- name: '@deepseek-ai/dsh-system-prompt'",
      "- name: '@deepseek-ai/dsh-tools'",
      "- name: '@deepseek-ai/dsh-agent'",
      "- name: '@deepseek-ai/dsh-agent-loop'",
      "  config: { agents: [] }",
      "- name: '@vibeinging/dsh-red-alert'",
      `  config: { assetsDir: ${JSON.stringify(path.resolve("assets"))} }`,
      "- name: '@vibeinging/dsh-red-alert/invariant'",
    ]);
    expect(ctx.tools.schemas().map((tool) => tool.name)).toEqual(expect.arrayContaining([
      "red_alert_start",
      "red_alert_unit_order",
      "red_alert_status",
      "red_alert_stop",
    ]));

    const agentOneHandle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-loader-one"),
      agentOptions: { provider: "unused", model: "unused" },
    });
    const agentTwoHandle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-loader-two"),
      agentOptions: { provider: "unused", model: "unused" },
    });
    const agentOne = agentOneHandle.agent;
    const agentTwo = agentTwoHandle.agent;
    expect(ctx.tools.schemas(agentOne).map((tool) => tool.name)).toEqual(expect.arrayContaining([
      "red_alert_capabilities",
      "red_alert_load_group",
    ]));
    expect(ctx.tools.schemas(agentOne).map((tool) => tool.name)).not.toContain("red_alert_start");
    await loadGroup(ctx, agentOne, "lobby/setup");
    const start = valueOf(await callTool(ctx, agentOne, "red_alert_start", {
      map: "simple-1v1-no-preview.map",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "noop",
      decisionPeriod: 1,
      maxTicks: 12,
    }));
    expect(start.view).toEqual({ mode: "offline", realUiAvailable: false });
    expect(start).not.toHaveProperty("joinUrl");
    const matchId = start.matchId as string;
    await loadGroup(ctx, agentOne, "observation", matchId);
    await loadGroup(ctx, agentOne, "units/combat", matchId);
    await loadGroup(ctx, agentOne, "lifecycle/replay", matchId);

    const duplicate = await callTool(ctx, agentOne, "red_alert_start", {});
    expect(duplicate.isError).toBe(true);
    const before = valueOf(await callTool(ctx, agentOne, "red_alert_status", { matchId }));
    const acted = valueOf(await callTool(ctx, agentOne, "red_alert_unit_order", { matchId, orders: [] }));
    expect(acted.advanced).toBe(true);
    expect(Number(acted.tick)).toBeGreaterThan(Number(before.tick));

    const crossSession = await callTool(ctx, agentTwo, "red_alert_status", { matchId });
    expect(crossSession.isError).toBe(true);
    const aborted = new AbortController();
    aborted.abort(new Error("test cancellation"));
    const cancelled = await callTool(ctx, agentOne, "red_alert_unit_order", { matchId, orders: [] }, aborted.signal);
    expect(cancelled.isError).toBe(true);

    const stopped = valueOf(await callTool(ctx, agentOne, "red_alert_stop", { matchId }));
    expect(stopped.status).toBe("stopped");
    expect(stopped.replaySaved).toBe(true);
    expect(valueOf(await callTool(ctx, agentOne, "red_alert_stop", { matchId })).status).toBe("stopped");

    const stateEvents = agentOne.session.events.filter((event) => event.type === "red-alert/state");
    expect(stateEvents.map((event) => event.data.status)).toEqual([
      "creating", "running", "running", "running", "stopped", "stopped",
    ]);
    expect(stateEvents.map((event) => event.seq)).toEqual([...stateEvents].sort((a, b) => a.seq - b.seq).map((event) => event.seq));
    expect(stateEvents.every((event) => !Object.hasOwn(event.data, "revision") && !Object.hasOwn(event.data, "seq"))).toBe(true);
    const projection = ctx.sessionProjections.snapshot(agentOne.session);
    expect(projection.asOfSeq).toBe(agentOne.session.seq - 1);
    expect((projection.values.redAlert as { status: string }).status).toBe("stopped");

    await loadGroup(ctx, agentTwo, "lobby/setup");
    const second = valueOf(await callTool(ctx, agentTwo, "red_alert_start", {
      map: "simple-1v1-no-preview.map",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "noop",
      decisionPeriod: 1,
      maxTicks: 4,
    }));
    await loadGroup(ctx, agentTwo, "units/combat", second.matchId as string);
    expect(second.status).toBe("active");
    const unauthorizedAct = await callTool(ctx, agentTwo, "red_alert_unit_order", { matchId, orders: [] });
    expect(unauthorizedAct.isError).toBe(true);
    const unknownAct = await callTool(ctx, agentTwo, "red_alert_unit_order", { matchId: "unknown-match", orders: [] });
    expect(unknownAct.isError).toBe(true);
    const secondProjection = ctx.sessionProjections.snapshot(agentTwo.session).values.redAlert as { status: string; match?: { matchId: string } };
    expect(secondProjection.status).toBe("error");
    expect(secondProjection.match?.matchId).toBe(second.matchId);
    const secondController = ctx.redAlert.controller as unknown as { readonly activeBySession: Map<string, string> };
    expect(secondController.activeBySession.get("red-alert-loader-two")).toBe(second.matchId);
    await agentTwoHandle.dispose();
    await new Promise<void>((resolve) => setImmediate(resolve));
    ctx.redAlert.assertInvariants((message): never => { throw new Error(message); });
  });

  it("uses a red-alert-only deny filter, intersects external restrictions, and tightens after stop", async () => {
    const ctx = await loadBaseProfileWithRedAlertPatch();
    const foreignDisposer = ctx.tools.register(defineTool({
      name: "foreign_probe",
      description: "An unrelated DSH tool used to prove restriction scope.",
      parameters: {},
      output: { schema: { type: "json" }, render: () => [] },
      execute: async () => ({ ok: true }),
    }));
    const handle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-group-scope"),
      agentOptions: { provider: "unused", model: "unused" },
    });
    const names = () => ctx.tools.schemas(handle.agent).map((tool) => tool.name);
    expect(names()).toContain("red_alert_capabilities");
    expect(names()).toContain("red_alert_load_group");
    expect(names()).toContain("foreign_probe");
    expect(names()).not.toContain("red_alert_start");

    const externalLift = handle.agent.ctx.tools.restrict({ deny: ["red_alert_start"] });
    await loadGroup(ctx, handle.agent, "lobby/setup");
    expect(names()).toContain("foreign_probe");
    expect(names()).not.toContain("red_alert_start");
    externalLift();
    expect(names()).toContain("red_alert_start");

    const started = valueOf(await callTool(ctx, handle.agent, "red_alert_start", {
      map: "simple-1v1-no-preview.map",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "noop",
      decisionPeriod: 1,
      maxTicks: 8,
    })) as { matchId: string };
    await loadGroup(ctx, handle.agent, "observation", started.matchId);
    await loadGroup(ctx, handle.agent, "lifecycle/replay", started.matchId);
    await loadGroup(ctx, handle.agent, "units/combat", started.matchId);
    expect(names()).toContain("red_alert_unit_order");
    await callTool(ctx, handle.agent, "red_alert_stop", { matchId: started.matchId });
    expect(names()).not.toContain("red_alert_unit_order");
    expect(names()).toContain("red_alert_status");
    const reloadEnded = await callTool(ctx, handle.agent, "red_alert_load_group", {
      group: "units/combat",
      matchId: started.matchId,
    });
    expect(reloadEnded.isError).toBe(true);
    const otherHandle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-group-other-agent"),
      agentOptions: { provider: "unused", model: "unused" },
    });
    const otherAgentForeignLift = otherHandle.agent.ctx.tools.restrict({ deny: ["foreign_probe"] });
    await handle.dispose();
    expect(ctx.tools.schemas(otherHandle.agent).map((tool) => tool.name)).not.toContain("foreign_probe");
    otherAgentForeignLift();
    expect(ctx.tools.schemas(otherHandle.agent).map((tool) => tool.name)).toContain("foreign_probe");
    expect(ctx.tools.schemas(handle.agent).map((tool) => tool.name)).toContain("red_alert_start");
    await otherHandle.dispose();
    foreignDisposer();
  });

  it("rolls both visibility and the replayed selection back when group flush fails", async () => {
    const ctx = await loadBaseProfileWithRedAlertPatch();
    const handle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-group-flush-rollback"),
      agentOptions: { provider: "unused", model: "unused" },
    });
    await loadGroup(ctx, handle.agent, "lobby/setup");
    const started = valueOf(await callTool(ctx, handle.agent, "red_alert_start", {
      map: "simple-1v1-no-preview.map",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "noop",
      decisionPeriod: 1,
      maxTicks: 8,
    })) as { matchId: string };
    const before = ctx.tools.schemas(handle.agent).map((tool) => tool.name);
    let failFlush = false;
    ctx.on("session/flush", () => {
      if (failFlush) throw new Error("injected group selection flush failure");
    });
    failFlush = true;
    const failed = await callTool(ctx, handle.agent, "red_alert_load_group", {
      group: "observation",
      matchId: started.matchId,
    });
    expect(failed.isError).toBe(true);
    expect(ctx.tools.schemas(handle.agent).map((tool) => tool.name)).toEqual(before);
    const selectionEvents = handle.agent.session.events.filter((event) => event.type === "red-alert/tool-group-selection");
    expect(selectionEvents.at(-1)?.data).toMatchObject({ groupId: "observation", outcome: "rollback" });
    expect(restoreSelectedGroups(handle.agent.session, handle.agent)).not.toContain("observation");
    const capabilities = valueOf(await callTool(ctx, handle.agent, "red_alert_capabilities", {}));
    const observation = (capabilities.groups as Array<{ groupId: string; selected: boolean }>).find(group => group.groupId === "observation");
    expect(observation?.selected).toBe(false);
    await handle.dispose();
  });

  it("keeps the old schema visible until the group commit flush resolves", async () => {
    const ctx = await loadBaseProfileWithRedAlertPatch();
    const handle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-group-pending-flush"),
      agentOptions: { provider: "unused", model: "unused" },
    });
    await loadGroup(ctx, handle.agent, "lobby/setup");
    const started = valueOf(await callTool(ctx, handle.agent, "red_alert_start", {
      map: "simple-1v1-no-preview.map",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "noop",
      decisionPeriod: 1,
      maxTicks: 8,
    })) as { matchId: string };
    const before = ctx.tools.schemas(handle.agent).map((tool) => tool.name);
    let releaseFlush!: () => void;
    const pendingFlush = new Promise<void>((resolve) => { releaseFlush = resolve; });
    let holdFlush = true;
    ctx.on("session/flush", () => holdFlush ? pendingFlush : undefined);

    const loading = callTool(ctx, handle.agent, "red_alert_load_group", {
      group: "observation",
      matchId: started.matchId,
    });
    await new Promise<void>((resolve) => setImmediate(resolve));
    expect(ctx.tools.schemas(handle.agent).map((tool) => tool.name)).toEqual(before);

    holdFlush = false;
    releaseFlush();
    const loaded = valueOf(await loading);
    expect(loaded.status).toBe("loaded");
    expect(ctx.tools.schemas(handle.agent).map((tool) => tool.name)).not.toEqual(before);
    await handle.dispose();
  });

  it("registers an exact browser group after the session selects it", async () => {
    const ctx = await loadBaseProfileWithRedAlertPatch();
    const handle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-group-pending-only"),
      agentOptions: { provider: "unused", model: "unused" },
    });
    await loadGroup(ctx, handle.agent, "lobby/setup");
    const started = valueOf(await callTool(ctx, handle.agent, "red_alert_start", {
      map: "simple-1v1-no-preview.map",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "noop",
      decisionPeriod: 1,
      maxTicks: 8,
    })) as { matchId: string };
    const loaded = valueOf(await callTool(ctx, handle.agent, "red_alert_load_group", {
      group: "production/economy",
      matchId: started.matchId,
    }));
    expect(loaded).toMatchObject({
      status: "loaded",
      schemaState: "loaded",
      registeredTools: [
        "red_alert_production_catalog",
        "red_alert_production_status",
        "red_alert_production",
      ],
    });
    const duplicate = valueOf(await callTool(ctx, handle.agent, "red_alert_load_group", {
      group: "production/economy",
      matchId: started.matchId,
    }));
    expect(duplicate.status).toBe("already_loaded");
    const capabilities = valueOf(await callTool(ctx, handle.agent, "red_alert_capabilities", {}));
    const production = (capabilities.groups as Array<{ groupId: string; selected: boolean; visible: boolean; selectionStatus: string }>)
      .find((group) => group.groupId === "production/economy");
    expect(production).toMatchObject({ selected: true, visible: true, selectionStatus: "loaded" });
    expect(ctx.tools.schemas(handle.agent).map((tool) => tool.name)).toContain("red_alert_production_catalog");
    await handle.dispose();
  });

  it("restores exact owner-session selections and does not inherit them into a fork", async () => {
    const ctx = await loadBaseProfileWithRedAlertPatch();
    const sessionId = SessionId("red-alert-group-restore");
    const first = await ctx.agentLoop.createAgent(ctx, {
      sessionId,
      agentOptions: { provider: "unused", model: "unused" },
    });
    await loadGroup(ctx, first.agent, "lobby/setup");
    const seed = [...first.agent.session.events];
    await first.dispose();

    const restored = await ctx.agentLoop.createAgent(ctx, {
      sessionId,
      seed,
      agentOptions: { provider: "unused", model: "unused" },
    });
    expect(ctx.tools.schemas(restored.agent).map((tool) => tool.name)).toContain("red_alert_start");
    await restored.dispose();

    const fork = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-group-fork"),
      seed,
      agentOptions: { provider: "unused", model: "unused" },
    });
    expect(ctx.tools.schemas(fork.agent).map((tool) => tool.name)).not.toContain("red_alert_start");
    await fork.dispose();
  });

  it("keeps the visible set unchanged when replacement restriction installation fails", async () => {
    const ctx = await loadBaseProfileWithRedAlertPatch();
    const handle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-group-install-rollback"),
      agentOptions: { provider: "unused", model: "unused" },
    });
    const before = ctx.tools.schemas(handle.agent).map((tool) => tool.name);
    const restrict = vi.spyOn(handle.agent.ctx.tools, "restrict").mockImplementationOnce(() => {
      throw new Error("injected restriction installation failure");
    });
    const failed = await callTool(ctx, handle.agent, "red_alert_load_group", { group: "lobby/setup" });
    expect(failed.isError).toBe(true);
    expect(ctx.tools.schemas(handle.agent).map((tool) => tool.name)).toEqual(before);
    expect(handle.agent.session.events
      .filter((event) => event.type === "red-alert/tool-group-selection")
      .map((event) => event.data.outcome)).toEqual(["committed", "rollback"]);
    expect(restoreSelectedGroups(handle.agent.session, handle.agent)).not.toContain("lobby/setup");
    restrict.mockRestore();
    await handle.dispose();
  });

  it("fails closed on malformed durable group-selection data", async () => {
    const malformedData = {
      agentId: "red-alert-malformed",
      sessionId: "red-alert-malformed",
      groupId: "observation",
      phase: "running",
      methodKeys: ["not-a-manifest-key"],
      schemaState: "loaded",
      outcome: "committed",
    };
    expect(() => decodeToolGroupSelection(malformedData)).toThrow(/methodKeys/);
    const malformedEvent = {
      type: "red-alert/tool-group-selection",
      seq: 0,
      time: 0,
      data: malformedData,
    } as unknown as SessionEvent;
    const ctx = await loadBaseProfileWithRedAlertPatch();
    await expect(ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-malformed"),
      seed: [malformedEvent],
      agentOptions: { provider: "unused", model: "unused" },
    })).rejects.toThrow(/methodKeys/);
  });

  it("replays legacy pending selections across implementation changes but rejects cross-group keys", async () => {
    const legacyPendingData = {
      agentId: "red-alert-legacy-selection",
      sessionId: "red-alert-legacy-selection",
      groupId: "production/economy",
      phase: "running",
      methodKeys: ["ProductionApi::getQueueData::0"],
      schemaState: "pending-client-adapter",
      outcome: "committed",
    } as const;
    const decodedLegacy = decodeToolGroupSelection(legacyPendingData);
    expect(decodedLegacy.version).toBe(0);
    expect(decodedLegacy.schemaState).toBe("pending-client-adapter");
    expect(decodeToolGroupSelection({
      ...legacyPendingData,
      version: 1,
      schemaState: "loaded",
    }).schemaState).toBe("loaded");
    expect(() => decodeToolGroupSelection({
      ...legacyPendingData,
      methodKeys: ["GameApi::getAllUnits::0"],
    })).toThrow(/not valid for manifest group/);

    const legacyEvent = {
      type: "red-alert/tool-group-selection",
      seq: 0,
      time: 0,
      data: legacyPendingData,
    } as unknown as SessionEvent;
    const ctx = await loadBaseProfileWithRedAlertPatch();
    const handle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-legacy-selection"),
      seed: [legacyEvent],
      agentOptions: { provider: "unused", model: "unused" },
    });
    expect(restoreSelectedGroups(handle.agent.session, handle.agent)).toContain("production/economy");
    expect(ctx.tools.schemas(handle.agent).map((tool) => tool.name)).not.toContain("red_alert_production_catalog");
    await handle.dispose();
  });

  it("waits for Agent disposal cleanup while an act is still running", async () => {
    const ctx = await loadBundle([
      "- name: '@deepseek-ai/dsh-invariants'",
      "- name: '@deepseek-ai/dsh-settings'",
      "- name: '@deepseek-ai/dsh-llm'",
      "- name: '@deepseek-ai/dsh-session'",
      "- name: '@deepseek-ai/dsh-session-projection'",
      "- name: '@deepseek-ai/dsh-system-prompt'",
      "- name: '@deepseek-ai/dsh-tools'",
      "- name: '@deepseek-ai/dsh-agent'",
      "- name: '@deepseek-ai/dsh-agent-loop'",
      "  config: { agents: [] }",
      "- name: '@vibeinging/dsh-red-alert'",
      `  config: { assetsDir: ${JSON.stringify(path.resolve("assets"))} }`,
      "- name: '@vibeinging/dsh-red-alert/invariant'",
    ]);
    const handle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-loader-dispose"),
      agentOptions: { provider: "unused", model: "unused" },
    });
    await loadGroup(ctx, handle.agent, "lobby/setup");
    const started = valueOf(await callTool(ctx, handle.agent, "red_alert_start", {
      map: "simple-1v1-no-preview.map",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "noop",
      decisionPeriod: 1,
      maxTicks: 20,
    }));
    await loadGroup(ctx, handle.agent, "units/combat", started.matchId as string);
    const controller = ctx.redAlert.controller as unknown as {
      readonly records: Map<string, { readonly game: { update: () => Promise<void> }; status: string }>;
      readonly activeBySession: Map<string, string>;
    };
    const record = controller.records.get(started.matchId as string);
    expect(record).toBeDefined();
    if (record === undefined) throw new Error("match record was not created");
    let releaseUpdate!: () => void;
    const updateReleased = new Promise<void>((resolve) => { releaseUpdate = resolve; });
    let updateEntered!: () => void;
    const updateStarted = new Promise<void>((resolve) => { updateEntered = resolve; });
    const originalUpdate = record.game.update.bind(record.game);
    record.game.update = async () => {
      updateEntered();
      await updateReleased;
      await originalUpdate();
    };

    const actPromise = callTool(ctx, handle.agent, "red_alert_unit_order", {
      matchId: started.matchId,
      orders: [],
    });
    await updateStarted;
    await handle.dispose();
    let fiberFinished = false;
    const fiberDisposal = Promise.resolve(ctx.fiber.dispose()).then(() => { fiberFinished = true; });
    await Promise.resolve();
    expect(fiberFinished).toBe(false);
    releaseUpdate();
    await actPromise;
    await fiberDisposal;
    expect(fiberFinished).toBe(true);
    expect(controller.activeBySession.has("red-alert-loader-dispose")).toBe(false);
  });

  it("fails closed when the post-engine projection flush fails", async () => {
    const ctx = await loadBaseProfileWithRedAlertPatch();
    const handle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-flush-failure"),
      agentOptions: { provider: "unused", model: "unused" },
    });
    await loadGroup(ctx, handle.agent, "lobby/setup");
    let failFlush = false;
    ctx.on("session/flush", () => {
      if (failFlush) throw new Error("injected projection flush failure");
    });
    const controller = ctx.redAlert.controller as unknown as {
      readonly records: Map<string, { status: string }>;
      readonly activeBySession: Map<string, string>;
      start: (...args: unknown[]) => Promise<unknown>;
    };
    const originalStart = controller.start.bind(controller);
    controller.start = async (...args: unknown[]) => {
      const result = await originalStart(...args);
      failFlush = true;
      return result;
    };

    const failed = await callTool(ctx, handle.agent, "red_alert_start", {
      map: "simple-1v1-no-preview.map",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "noop",
      decisionPeriod: 1,
      maxTicks: 12,
    });
    expect(failed.isError).toBe(true);
    expect(controller.activeBySession.has("red-alert-flush-failure")).toBe(false);
    expect([...controller.records.values()].every((record) => record.status !== "active")).toBe(true);
    const liveProjection = ctx.sessionProjections.snapshot(handle.agent.session).values.redAlert as { status: string };
    expect(liveProjection.status).toBe("error");
    expect(handle.agent.session.events.filter((event) => event.type === "red-alert/state").map((event) => event.data.status)).toEqual([
      "creating",
      "running",
      "error",
    ]);
    await handle.dispose();
  });

  it("keeps the selected start tool available after a recoverable first-run create failure", async () => {
    const ctx = await loadBaseProfileWithRedAlertPatch();
    const handle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-retry-create"),
      agentOptions: { provider: "unused", model: "unused" },
    });
    await loadGroup(ctx, handle.agent, "lobby/setup");
    handle.agent.session.append("red-alert/state", failureState(
      "creating",
      Object.assign(new Error("local game files are required"), { code: "ADAPTER_COMMAND_FAILED" }),
      undefined,
      { map: "current", myCountry: "Russians", opponents: 1, opponentType: "normal", gameSpeed: 2, decisionPeriod: 15, maxTicks: 600 },
    ));
    await ctx.sessions.flush(handle.agent.session);

    const capabilities = valueOf(await callTool(ctx, handle.agent, "red_alert_capabilities", {})) as { phase: string };
    expect(capabilities.phase).toBe("catalog-only");
    expect(ctx.tools.schemas(handle.agent).map(tool => tool.name)).toContain("red_alert_start");
    await handle.dispose();
  });

  it("fails closed once when an act projection flush fails after the engine succeeds", async () => {
    const ctx = await loadBaseProfileWithRedAlertPatch();
    const handle = await ctx.agentLoop.createAgent(ctx, {
      sessionId: SessionId("red-alert-act-flush-failure"),
      agentOptions: { provider: "unused", model: "unused" },
    });
    await loadGroup(ctx, handle.agent, "lobby/setup");
    const started = valueOf(await callTool(ctx, handle.agent, "red_alert_start", {
      map: "simple-1v1-no-preview.map",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "noop",
      decisionPeriod: 1,
      maxTicks: 12,
    })) as { matchId: string };
    await loadGroup(ctx, handle.agent, "units/combat", started.matchId);

    let failFlush = false;
    ctx.on("session/flush", () => {
      if (failFlush) throw new Error("injected act projection flush failure");
    });
    const controller = ctx.redAlert.controller as unknown as {
      readonly records: Map<string, { status: string }>;
      readonly activeBySession: Map<string, string>;
      act: (...args: unknown[]) => Promise<unknown>;
    };
    const originalAct = controller.act.bind(controller);
    controller.act = async (...args: unknown[]) => {
      const result = await originalAct(...args);
      failFlush = true;
      return result;
    };

    const failed = await callTool(ctx, handle.agent, "red_alert_unit_order", {
      matchId: started.matchId,
      orders: [],
    });
    expect(failed.isError).toBe(true);
    expect(controller.activeBySession.has("red-alert-act-flush-failure")).toBe(false);
    expect([...controller.records.values()].every((record) => record.status !== "active")).toBe(true);
    const liveProjection = ctx.sessionProjections.snapshot(handle.agent.session).values.redAlert as { status: string };
    expect(liveProjection.status).toBe("error");

    const statuses = handle.agent.session.events
      .filter((event) => event.type === "red-alert/state")
      .map((event) => event.data.status);
    expect(statuses).toEqual(["creating", "running", "running", "error"]);
    expect(statuses.filter((status) => status === "error")).toHaveLength(1);
    expect(statuses.slice(-2)).not.toEqual(["error", "error"]);
    await handle.dispose();
  });

  it("points an ordinary DSH start to setup and the Red Alert launcher", async () => {
    let failure: unknown;
    try {
      await loadBundle([
        "- name: '@deepseek-ai/dsh-invariants'",
        "- name: '@deepseek-ai/dsh-settings'",
        "- name: '@deepseek-ai/dsh-llm'",
        "- name: '@deepseek-ai/dsh-session'",
        "- name: '@deepseek-ai/dsh-session-projection'",
        "- name: '@deepseek-ai/dsh-system-prompt'",
        "- name: '@deepseek-ai/dsh-tools'",
        "- name: '@deepseek-ai/dsh-agent'",
        "- name: '@deepseek-ai/dsh-agent-loop'",
        "  config: { agents: [] }",
        "- name: '@vibeinging/dsh-red-alert'",
      ]);
    } catch (error) {
      failure = error;
    }
    const message = failure instanceof Error ? failure.message : String(failure);
    expect(message).toContain("pnpm exec dsh-red-alert-setup --profile <profile>");
    expect(message).toContain("pnpm exec dsh-red-alert");
    expect(message).toContain("Game files are selected later in the browser battlefield");
    expect(message).not.toContain("RA_ASSETS_DIR");
  });
});
