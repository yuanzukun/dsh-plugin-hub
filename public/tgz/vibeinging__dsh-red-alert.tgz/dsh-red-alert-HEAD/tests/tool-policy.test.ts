import { describe, expect, it } from "vitest";
import {
  METHOD_POLICY,
  TOOL_MANIFEST,
  methodKey,
  type MethodOwner,
} from "../src/tool-policy.ts";

const OWNERS: readonly MethodOwner[] = [
  "PublicApi",
  "GameInstanceApi",
  "GameApi",
  "MapApi",
  "PlayerApi",
  "ProductionApi",
  "ActionsApi",
];

describe("red-alert method policy", () => {
  it("keeps the locked seven-owner surface unique and fully classified", () => {
    const keys = METHOD_POLICY.map((entry) => entry.methodKey);
    expect(new Set(keys).size).toBe(keys.length);
    expect(new Set(METHOD_POLICY.map((entry) => entry.owner))).toEqual(new Set(OWNERS));
    expect(METHOD_POLICY).toHaveLength(85);

    for (const entry of METHOD_POLICY) {
      if (entry.decision !== "allow-wrapper") continue;
      const tool = TOOL_MANIFEST.find((candidate) => candidate.tool === entry.tool);
      expect(tool, entry.methodKey).toBeDefined();
      expect(tool?.methodKeys).toContain(entry.methodKey);
      expect(entry.group).not.toBe("internal");
      expect(entry.phase).not.toBe("never");
    }
  });

  it("keeps fog-breaking and debug methods out of every model tool manifest", () => {
    const forbiddenKeys = [
      methodKey("GameApi", "getAllUnits"),
      methodKey("GameApi", "getNeutralUnits"),
      methodKey("GameApi", "getGameObjectData"),
      methodKey("GameInstanceApi", "getDebugStateDump"),
      methodKey("ActionsApi", "setGlobalDebugText"),
      methodKey("ActionsApi", "setUnitDebugText"),
    ];
    const manifestKeys = TOOL_MANIFEST.flatMap((entry) => entry.methodKeys);

    for (const key of forbiddenKeys) {
      expect(METHOD_POLICY.find((entry) => entry.methodKey === key)?.decision, key).toBe("internal-only");
      expect(manifestKeys, key).not.toContain(key);
    }
  });

  it("counts overloads as separate policy entries", () => {
    expect(METHOD_POLICY.filter((entry) => entry.methodKey.startsWith("MapApi::getTilesInRect::"))).toHaveLength(2);
    expect(METHOD_POLICY.filter((entry) => entry.methodKey.startsWith("ActionsApi::orderUnits::"))).toHaveLength(3);
  });

  it("keeps every exact wrapper inside its owning lazy group", () => {
    expect(TOOL_MANIFEST.some((entry) => entry.legacyCrossGroup === true)).toBe(false);
    const unitOrder = TOOL_MANIFEST.find((entry) => entry.tool === "red_alert_unit_order");
    expect(unitOrder?.group).toBe("units/combat");
    expect(unitOrder?.methodKeys).toEqual(expect.arrayContaining([
      methodKey("GameInstanceApi", "update"),
      methodKey("ActionsApi", "orderUnits", 0),
      methodKey("ActionsApi", "orderUnits", 1),
      methodKey("ActionsApi", "orderUnits", 2),
    ]));
    expect(unitOrder?.methodKeys).not.toEqual(expect.arrayContaining([
      methodKey("ActionsApi", "queueForProduction"),
      methodKey("ActionsApi", "unqueueFromProduction"),
      methodKey("GameApi", "canPlaceBuilding"),
    ]));
    expect(TOOL_MANIFEST.find((entry) => entry.tool === "red_alert_production")?.group).toBe("production/economy");
    expect(TOOL_MANIFEST.find((entry) => entry.tool === "red_alert_construction")?.group).toBe("construction");
    expect(TOOL_MANIFEST.find((entry) => entry.tool === "red_alert_field_manual")).toMatchObject({
      group: "strategy/learning",
      phase: "catalog-only",
      methodKeys: [],
      sessionEvent: "red-alert/field-manual",
    });
  });
});
