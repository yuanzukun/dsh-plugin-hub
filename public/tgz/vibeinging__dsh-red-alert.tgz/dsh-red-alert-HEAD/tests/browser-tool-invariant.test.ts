import { describe, expect, it } from "vitest";
import type { Session } from "@deepseek-ai/dsh-session";
import { MatchService } from "../src/index.ts";

const observation = {
  tick: 120,
  ownUnits: [],
  visibleEnemies: [],
  lastSeenEnemies: [],
  visibleNeutralObjects: [],
};

function serviceFor(match: object): MatchService {
  return {
    controller: undefined,
    currentMatch: () => match,
  } as unknown as MatchService;
}

function fail(message: string): never {
  throw new Error(message);
}

describe("browser tool output invariant", () => {
  it("accepts an exact wrapper result after its atomic observation was committed", () => {
    const service = serviceFor({ matchId: "match-exact", seat: "Russians", tick: 120, observation });
    const session = { id: "session-exact" } as Session;
    const result = {
      matchId: "match-exact",
      sessionId: "session-exact",
      seat: "Russians",
      tick: 120,
      result: { map: "mp02t2.map", width: 80, height: 80 },
    };
    expect(() => MatchService.prototype.assertToolOutput.call(service, result, session, fail)).not.toThrow();
  });

  it("rejects an exact wrapper result whose identity is not the committed match", () => {
    const service = serviceFor({ matchId: "match-exact", seat: "Russians", tick: 120, observation });
    const session = { id: "session-exact" } as Session;
    const result = {
      matchId: "match-exact",
      sessionId: "session-exact",
      seat: "Russians",
      tick: 121,
      result: { map: "mp02t2.map", width: 80, height: 80 },
    };
    expect(() => MatchService.prototype.assertToolOutput.call(service, result, session, fail)).toThrow(/identity does not match/);
  });

  it("keeps exact tools available after a recoverable active-match command error", () => {
    const session = { id: "session-recoverable" } as Session;
    const service = {
      ctx: {
        sessionProjections: {
          snapshot: () => ({
            values: {
              redAlert: {
                status: "error",
                view: { mode: "real-browser", realUiAvailable: true },
                match: { status: "active" },
                failure: { phase: "running", code: "COMMAND_REJECTED", message: "invalid placement", recoverable: true },
              },
            },
          }),
        },
      },
    };
    const phaseFor = (MatchService.prototype as unknown as { phaseFor(sessionValue: Session): string }).phaseFor;
    expect(phaseFor.call(service, session)).toBe("running");
  });

  it("reports a rejected renderer tool detail instead of a missing-result error", async () => {
    const session = { id: "session-rejected-tool" } as Session;
    const previous = { matchId: "match-rejected-tool", seat: "Russians", myCountry: "Russians", status: "active", tick: 10 };
    const browserView = (MatchService.prototype as unknown as { browserView: (...args: unknown[]) => unknown }).browserView;
    const service = {
      rendererDescriptor: { mode: "loopback", enabled: true, sourceLabel: "test renderer" },
      resourceArchive: undefined,
      defaults: { decisionPeriod: 15 },
      withSession: (_exec: unknown, operation: (owner: object, sessionValue: Session) => Promise<unknown>) => operation({}, session),
      requireActiveBrowserMatch: () => previous,
      requireBrowserTransport: () => ({
        dispatch: async () => ({
          protocolVersion: 1,
          requestId: "request-rejected-tool",
          sessionId: String(session.id),
          matchId: previous.matchId,
          seat: previous.seat,
          tick: 11,
          ok: false,
          detail: "building is not currently available to this seat",
        }),
      }),
      browserView,
      appendFailure: async () => undefined,
      combineFailure: (error: unknown) => error,
    };
    await expect(MatchService.prototype.browserTool.call(
      service as unknown as MatchService,
      { matchId: previous.matchId, tool: "red_alert_construction_catalog" },
      { signal: new AbortController().signal } as never,
    )).rejects.toThrow("building is not currently available to this seat");
  });
});
