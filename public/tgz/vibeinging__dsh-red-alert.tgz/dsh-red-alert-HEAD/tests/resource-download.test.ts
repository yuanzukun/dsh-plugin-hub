import { createHash } from "node:crypto";
import { mkdtemp, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { describe, expect, it, vi } from "vitest";
import { downloadVerifiedArchive, fileMatchesArchive } from "../scripts/resource-download.mjs";

const bytes = new TextEncoder().encode("verified archive");
const descriptor = {
  url: "https://resources.example.test/full-pack.7z",
  byteLength: bytes.byteLength,
  sha256: createHash("sha256").update(bytes).digest("hex"),
};

function archiveResponse(body = bytes, declaredLength = body.byteLength): Response {
  return new Response(body, {
    status: 200,
    headers: { "content-length": String(declaredLength) },
  });
}

describe("verified setup resource download", () => {
  it("streams the declared archive, verifies it, and reuses the verified file", async () => {
    const root = await mkdtemp(path.join(tmpdir(), "dsh-ra-resource-download-"));
    const target = path.join(root, "dsh-red-alert-resource.7z");
    try {
      const fetchImpl = vi.fn(async () => archiveResponse());
      await expect(downloadVerifiedArchive(descriptor, target, { fetchImpl })).resolves.toEqual({ reused: false });
      await expect(readFile(target)).resolves.toEqual(Buffer.from(bytes));
      await expect(fileMatchesArchive(target, descriptor)).resolves.toBe(true);

      const unexpectedFetch = vi.fn(async () => { throw new Error("verified resources must not be fetched twice"); });
      await expect(downloadVerifiedArchive(descriptor, target, { fetchImpl: unexpectedFetch })).resolves.toEqual({ reused: true });
      expect(unexpectedFetch).not.toHaveBeenCalled();
      expect(fetchImpl).toHaveBeenCalledWith(descriptor.url, { redirect: "error" });
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("rejects changed headers, oversized bodies, and digest mismatches without publishing a part file", async () => {
    const cases = [
      archiveResponse(bytes, bytes.byteLength + 1),
      archiveResponse(new Uint8Array(bytes.byteLength + 1), bytes.byteLength),
      archiveResponse(new Uint8Array(bytes.byteLength), bytes.byteLength),
    ];
    for (const [index, response] of cases.entries()) {
      const root = await mkdtemp(path.join(tmpdir(), `dsh-ra-resource-reject-${index}-`));
      const target = path.join(root, "dsh-red-alert-resource.7z");
      try {
        await expect(downloadVerifiedArchive(descriptor, target, { fetchImpl: async () => response })).rejects.toThrow(/content-length|exceeds|SHA-256/);
        await expect(readdir(root)).resolves.toEqual([]);
      } finally {
        await rm(root, { recursive: true, force: true });
      }
    }
  });

  it("preserves an invalid previous setup file before publishing the verified replacement", async () => {
    const root = await mkdtemp(path.join(tmpdir(), "dsh-ra-resource-replace-"));
    const target = path.join(root, "dsh-red-alert-resource.7z");
    try {
      await writeFile(target, "invalid");
      const result = await downloadVerifiedArchive(descriptor, target, { fetchImpl: async () => archiveResponse() });
      expect(result.reused).toBe(false);
      expect(result.rejectedPath).toMatch(/\.rejected-[0-9]+$/);
      await expect(readFile(result.rejectedPath!)).resolves.toEqual(Buffer.from("invalid"));
      await expect(fileMatchesArchive(target, descriptor)).resolves.toBe(true);
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });
});
