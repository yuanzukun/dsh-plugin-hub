import { describe, expect, it } from "vitest";
import type { SessionEvent } from "@deepseek-ai/dsh-session";
import type { FogSafeContact } from "../packages/game-host/src/fog-safe-observation.ts";
import type { RedAlertState } from "../src/projection.ts";
import {
  RED_ALERT_STRATEGY_EPISODE_EVENT,
  RED_ALERT_STRATEGY_REVIEW_EVENT,
  deriveStrategyBrief,
  deriveStrategyEpisode,
  type StrategyEpisode,
  type StrategyReview,
} from "../src/strategy-learning.ts";
import { BROWSER_TRANSPORT_PROTOCOL_VERSION } from "../src/browser-command-protocol.ts";

const MATCH_ID = "learning-match";
const SESSION_ID = "learning-session";

function event(type: SessionEvent["type"], data: unknown, seq: number, time = seq): SessionEvent {
  return { type, data, seq, time } as SessionEvent;
}

function contact(id: number, unitType: string, kind: string, tick: number): FogSafeContact {
  return {
    id,
    unitType,
    label: unitType,
    kind,
    position: { x: id, y: id },
    hpPct: 100,
    observedAtTick: tick,
    source: "visible",
  };
}

function matchState(
  tick: number,
  status: "active" | "finished",
  ownUnits: readonly FogSafeContact[],
  visibleEnemies: readonly FogSafeContact[],
): RedAlertState {
  return {
    status: status === "active" ? "running" : "stopped",
    view: { mode: "offline", realUiAvailable: false },
    match: {
      matchId: MATCH_ID,
      map: "mp02t2.map",
      mapSize: { width: 64, height: 64 },
      myCountry: "Russians",
      status,
      tick,
      cycle: tick,
      view: { mode: "offline", realUiAvailable: false },
      observation: {
        tick,
        ownUnits: [...ownUnits],
        visibleEnemies: [...visibleEnemies],
        lastSeenEnemies: [],
        visibleNeutralObjects: [],
      },
      facts: {
        gameTimeSec: tick / 15,
        phase: "early",
        self: {
          credits: 1_000,
          power: { total: 100, drain: 50, isLowPower: false },
          defeated: status === "finished",
        },
        visibleEnemyGroups: visibleEnemies.length,
        lastSeenEnemyGroups: 0,
        visibleNeutralGroups: 0,
      },
      receipts: [],
      placements: [],
      replaySaved: false,
    },
  };
}

function command(tool: "red_alert_observe" | "red_alert_production", seq: number): SessionEvent {
  return event("red-alert/browser-command-admitted", {
    protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
    requestId: `request-${seq}`,
    sessionId: SESSION_ID,
    matchId: MATCH_ID,
    seat: "Russians",
    expectedTick: seq,
    kind: "tool",
    request: tool === "red_alert_observe"
      ? { tool }
      : { tool, operation: "queue", queueType: 0, name: "E1", quantity: 1 },
  }, seq);
}

function unitCommand(
  seq: number,
  orders: readonly Record<string, unknown>[],
): SessionEvent {
  return event("red-alert/browser-command-admitted", {
    protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
    requestId: `unit-request-${seq}`,
    sessionId: SESSION_ID,
    matchId: MATCH_ID,
    seat: "Russians",
    expectedTick: seq,
    kind: "orders",
    orders,
  }, seq);
}

function learningFixture(): { readonly finalState: RedAlertState; readonly events: SessionEvent[] } {
  const earlyOwn = Array.from({ length: 8 }, (_, index) => contact(index + 1, "E1", "Infantry", 50));
  const visibleRush = Array.from({ length: 20 }, (_, index) => contact(index + 100, "E2", "Infantry", 100));
  const contactState = matchState(100, "active", earlyOwn, visibleRush);
  const finalState = matchState(200, "finished", [...earlyOwn, contact(50, "HTNK", "Vehicle", 200)], visibleRush);
  const staleCommand = {
    protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
    requestId: "stale-request",
    sessionId: SESSION_ID,
    matchId: MATCH_ID,
    seat: "Russians",
    expectedTick: 150,
    kind: "orders" as const,
    orders: [{ action: "attackMove" as const, units: "999", x: 10, y: 10 }],
  };
  return {
    finalState,
    events: [
      event("red-alert/state", {
        status: "creating",
        view: { mode: "offline", realUiAvailable: false },
        request: {
          map: "mp02t2.map",
          myCountry: "Russians",
          opponents: 1,
          opponentType: "normal",
          gameSpeed: 2,
          decisionPeriod: 15,
          maxTicks: 9_000,
        },
        identity: { matchId: MATCH_ID, sessionId: SESSION_ID, seat: "Russians", tick: 0 },
      }, 1),
      event("red-alert/state", contactState, 2),
      command("red_alert_observe", 3),
      command("red_alert_observe", 4),
      command("red_alert_observe", 5),
      command("red_alert_production", 6),
      event("red-alert/browser-command-result", {
        protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
        requestId: staleCommand.requestId,
        sessionId: SESSION_ID,
        matchId: MATCH_ID,
        seat: "Russians",
        command: staleCommand,
        status: "failed",
        failure: { code: "OWNERSHIP", message: "unit is not currently owned because ownership changed" },
      }, 7),
      event("red-alert/state", finalState, 8),
    ],
  };
}

describe("red-alert strategy learning", () => {
  it("derives only closed fog-safe lesson candidates from a natural result", () => {
    const fixture = learningFixture();
    const episode = deriveStrategyEpisode(
      { id: SESSION_ID, events: fixture.events },
      fixture.finalState,
      { maxLearnedDefenders: 24 },
    );

    expect(episode).toMatchObject({
      matchId: MATCH_ID,
      gameSpeed: 2,
      result: "defeat",
      metrics: {
        maxVisibleEnemies: 20,
        maxVisibleEnemyInfantry: 20,
        maxOwnedCombatUnits: 9,
        firstVisibleEnemyTick: 100,
        firstArmoredUnitTick: 200,
        readCommands: 3,
        actionCommands: 1,
        staleOwnershipFailures: 1,
        unitOrderBatches: 0,
        issuedUnitOrders: 0,
        multiOrderBatches: 0,
        attackOrderBatches: 0,
        retreatOrderBatches: 0,
      },
    });
    expect(episode?.candidates.map(candidate => candidate.ruleId)).toEqual([
      "rush-defender-target",
      "anti-infantry-defense",
      "armor-before-contact",
      "fresh-owned-ids",
      "act-before-reread",
      "sustain-model-attacks",
    ]);
    expect(episode?.candidates[0]).toMatchObject({ target: 20 });
    expect(JSON.stringify(episode)).not.toMatch(/enemyStartLocation|rawWorld|hiddenUnits/);
  });

  it("measures only tactical batches explicitly chosen by the model", () => {
    const fixture = learningFixture();
    const events = [
      ...fixture.events.slice(0, -1),
      unitCommand(8, [
        { action: "retreat", units: "1", reason: "save damaged armor" },
        { action: "attackTarget", units: "2,3,4", contact: "100", reason: "focus a current-visible threat" },
      ]),
      unitCommand(9, [
        { action: "attackMove", units: "5,6,7,8", x: 20, y: 20, reason: "model-selected second wave" },
      ]),
      event("red-alert/state", fixture.finalState, 10),
    ];
    const episode = deriveStrategyEpisode(
      { id: SESSION_ID, events },
      fixture.finalState,
      { maxLearnedDefenders: 24 },
    );

    expect(episode?.metrics).toMatchObject({
      actionCommands: 3,
      unitOrderBatches: 2,
      issuedUnitOrders: 3,
      multiOrderBatches: 1,
      attackOrderBatches: 2,
      retreatOrderBatches: 1,
    });
    expect(episode?.candidates.map(candidate => candidate.ruleId)).not.toContain("sustain-model-attacks");
  });

  it("folds prior episodes and model verdicts into a bounded future brief", () => {
    const fixture = learningFixture();
    const episode = deriveStrategyEpisode(
      { id: SESSION_ID, events: fixture.events },
      fixture.finalState,
      { maxLearnedDefenders: 24 },
    ) as StrategyEpisode;
    const review: StrategyReview = {
      version: 1,
      sessionId: SESSION_ID,
      matchId: MATCH_ID,
      adoptedRuleIds: ["rush-defender-target"],
      rejectedRuleIds: ["anti-infantry-defense"],
    };
    const brief = deriveStrategyBrief("next-session", [{ events: [
      event(RED_ALERT_STRATEGY_EPISODE_EVENT, episode, 1, 100),
      event(RED_ALERT_STRATEGY_REVIEW_EVENT, review, 2, 101),
    ] }], {
      map: "mp02t2.map",
      myCountry: "Russians",
      opponentType: "normal",
    }, { historyLimit: 20, maxRules: 3 });

    expect(brief.rules).toHaveLength(3);
    expect(brief.rules[0]).toMatchObject({ ruleId: "rush-defender-target", status: "confirmed", evidenceMatches: 1 });
    expect(brief.rules.some(rule => rule.ruleId === "anti-infantry-defense")).toBe(false);
    expect(brief.sourceMatchIds).toEqual([MATCH_ID]);
  });

  it("does not append a second episode for the same match", () => {
    const fixture = learningFixture();
    const episode = deriveStrategyEpisode(
      { id: SESSION_ID, events: fixture.events },
      fixture.finalState,
      { maxLearnedDefenders: 24 },
    ) as StrategyEpisode;
    expect(deriveStrategyEpisode(
      { id: SESSION_ID, events: [...fixture.events, event(RED_ALERT_STRATEGY_EPISODE_EVENT, episode, 9)] },
      fixture.finalState,
      { maxLearnedDefenders: 24 },
    )).toBeUndefined();
  });
});
