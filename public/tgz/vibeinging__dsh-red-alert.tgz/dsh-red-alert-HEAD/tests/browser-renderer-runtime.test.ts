/** @vitest-environment jsdom */

import { describe, expect, it, vi } from "vitest";
import type { BrowserCommandEnvelope, BrowserCommandReceipt } from "../src/browser-command-protocol.ts";
import { BrowserAdapterRegistry } from "../src/client/browser-command-consumer.ts";
import { BrowserRendererRuntime, LoopbackRendererAdapter, type BrowserRendererAdapter, type BrowserRendererIdentity } from "../src/client/browser-renderer-runtime.ts";

function receipt(value: BrowserCommandEnvelope): BrowserCommandReceipt {
  return {
    protocolVersion: 1,
    requestId: value.requestId,
    sessionId: value.sessionId,
    matchId: value.matchId,
    seat: value.seat,
    tick: value.expectedTick,
    ok: true,
    detail: "runtime test receipt",
  };
}

class FakeRendererAdapter implements BrowserRendererAdapter {
  disposeCalls = 0;
  private readonly disposePromise: Promise<void>;

  constructor(private readonly disposeResult: Promise<void> = Promise.resolve()) {
    this.disposePromise = disposeResult.then(() => undefined);
  }

  command(value: BrowserCommandEnvelope, _signal: AbortSignal): Promise<BrowserCommandReceipt> {
    return Promise.resolve(receipt(value));
  }

  attachRenderer(_container: HTMLElement, _identity: BrowserRendererIdentity): Promise<void> {
    return Promise.resolve();
  }

  detachRenderer(_container: HTMLElement): Promise<void> {
    return Promise.resolve();
  }

  dispose(): Promise<void> {
    this.disposeCalls += 1;
    return this.disposePromise;
  }
}

function deferred(): { readonly promise: Promise<void>; readonly release: () => void } {
  let release!: () => void;
  const promise = new Promise<void>((resolve) => { release = resolve; });
  return { promise, release };
}

describe("browser renderer runtime lifecycle", () => {
  it("reconnects the same loopback frame after a renderer disconnect and publishes live state", async () => {
    const identity = { sessionId: "session-loopback", matchId: "match-loopback", seat: "Russians", tick: 4 } as const;
    const origin = "http://localhost:45678";
    const adapter = new LoopbackRendererAdapter({
      url: `${origin}/`,
      parentOrigin: "http://127.0.0.1:60786",
      origin: { allowLoopback: true, loopbackPort: 45678 },
      parentWindow: window,
      loadTimeoutMs: 1_000,
    });
    const states: string[] = [];
    const stop = adapter.subscribeState((state) => states.push(state));
    const container = document.createElement("div");
    Object.defineProperty(container, "getBoundingClientRect", { value: () => ({ left: 0, top: 0, width: 640, height: 480 }) });

    const attach = adapter.attachRenderer(container, identity);
    const frame = document.querySelector("iframe[data-red-alert-renderer]") as HTMLIFrameElement | null;
    expect(frame).not.toBeNull();
    if (frame === null || frame.contentWindow === null) throw new Error("expected loopback iframe contentWindow");
    expect(frame.referrerPolicy).toBe("origin");
    expect(frame.getAttribute("sandbox")).toBe("allow-scripts allow-same-origin");
    const child = frame.contentWindow;
    const postMessage = vi.fn((message: unknown) => {
      const value = message as { readonly type?: string; readonly requestId?: string; readonly tick?: number };
      if (value.type === "renderer/hello") {
        queueMicrotask(() => window.dispatchEvent(new MessageEvent("message", {
          origin,
          source: child,
          data: {
            protocolVersion: 1,
            sessionId: identity.sessionId,
            matchId: identity.matchId,
            seat: identity.seat,
            tick: identity.tick,
            type: "renderer/ready",
            requestId: value.requestId,
          },
        })));
      }
      if (value.type === "renderer/command") {
        queueMicrotask(() => window.dispatchEvent(new MessageEvent("message", {
          origin,
          source: child,
          data: {
            protocolVersion: 1,
            sessionId: identity.sessionId,
            matchId: identity.matchId,
            seat: identity.seat,
            tick: 5,
            type: "renderer/command-ack",
            requestId: value.requestId,
            ok: true,
            detail: "move applied",
            observation: { tick: 5, ownUnits: [], visibleEnemies: [], lastSeenEnemies: [], visibleNeutralObjects: [] },
          },
        })));
      }
    });
    Object.defineProperty(child, "postMessage", { configurable: true, value: postMessage });
    let earlyCommandSettled = false;
    const earlyCommand = adapter.command({
      protocolVersion: 1,
      requestId: "command-during-handshake",
      sessionId: identity.sessionId,
      matchId: identity.matchId,
      seat: identity.seat,
      expectedTick: identity.tick,
      kind: "orders",
      orders: [],
    }, new AbortController().signal).finally(() => { earlyCommandSettled = true; });
    await Promise.resolve();
    expect(earlyCommandSettled).toBe(false);
    frame.dispatchEvent(new Event("load"));
    await attach;
    await expect(earlyCommand).resolves.toMatchObject({ tick: 5 });
    expect(adapter.state).toBe("ready");
    expect(states).toContain("connecting");
    expect(states.at(-1)).toBe("ready");
    expect(postMessage).toHaveBeenCalledTimes(2);

    window.dispatchEvent(new MessageEvent("message", {
      origin,
      source: child,
      data: {
        protocolVersion: 1,
        sessionId: identity.sessionId,
        matchId: identity.matchId,
        seat: identity.seat,
        tick: identity.tick,
        type: "renderer/disconnected",
        reason: "renderer reset",
      },
    }));
    expect(adapter.state).toBe("disconnected");

    const retry = adapter.attachRenderer(container, identity);
    await retry;
    expect(adapter.state).toBe("ready");
    expect(postMessage.mock.calls.filter(([message]) => (message as { readonly type?: string }).type === "renderer/hello")).toHaveLength(2);

    window.dispatchEvent(new MessageEvent("message", {
      origin,
      source: child,
      data: {
        protocolVersion: 1,
        sessionId: identity.sessionId,
        matchId: identity.matchId,
        seat: identity.seat,
        tick: identity.tick,
        type: "renderer/observation",
        observation: {
          tick: identity.tick,
          ownUnits: [],
          visibleEnemies: [{ id: 7, unitType: "E1", label: "visible", kind: "Infantry", position: { x: 4, y: 5 }, hpPct: 100, observedAtTick: identity.tick, source: "visible" }],
          lastSeenEnemies: [],
          visibleNeutralObjects: [],
        },
      },
    }));
    await expect(adapter.command({
      protocolVersion: 1,
      requestId: "mixed-visibility-targets",
      sessionId: identity.sessionId,
      matchId: identity.matchId,
      seat: identity.seat,
      expectedTick: 2,
      kind: "orders",
      orders: [
        { action: "attackTarget", contact: "7" },
        { action: "attackTarget", contact: "8" },
      ],
    }, new AbortController().signal)).rejects.toMatchObject({ code: "IDENTITY" });
    expect(postMessage.mock.calls.filter(([message]) => (message as { readonly type?: string }).type === "renderer/command")).toHaveLength(1);
    await expect(adapter.command({
      protocolVersion: 1,
      requestId: "visible-target-by-type",
      sessionId: identity.sessionId,
      matchId: identity.matchId,
      seat: identity.seat,
      expectedTick: 2,
      kind: "orders",
      orders: [{ action: "attackTarget", units: "ALL", contact: "E1" }],
    }, new AbortController().signal)).resolves.toMatchObject({ tick: 5 });
    await expect(adapter.command({ protocolVersion: 1, requestId: "old-observation-command", sessionId: identity.sessionId, matchId: identity.matchId, seat: identity.seat, expectedTick: 2, kind: "orders", orders: [{ action: "move", x: 4, y: 5 }] }, new AbortController().signal)).resolves.toMatchObject({ tick: 5 });
    await expect(adapter.command({ protocolVersion: 1, requestId: "future-command", sessionId: identity.sessionId, matchId: identity.matchId, seat: identity.seat, expectedTick: 6, kind: "orders", orders: [] }, new AbortController().signal)).rejects.toMatchObject({ code: "STALE_TICK" });
    stop();
    await adapter.dispose();
    expect(adapter.state).toBe("disposed");
    expect(document.querySelector("iframe[data-red-alert-renderer]")).toBeNull();
  });

  it("keeps an adapter reusable when a view detaches during handshake and ignores stale container cleanup", async () => {
    const identity = { sessionId: "session-handshake", matchId: "match-handshake", seat: "Russians", tick: 3 } as const;
    const origin = "http://localhost:45679";
    const adapter = new LoopbackRendererAdapter({
      url: `${origin}/`,
      parentOrigin: "http://127.0.0.1:60786",
      origin: { allowLoopback: true, loopbackPort: 45679 },
      parentWindow: window,
      loadTimeoutMs: 1_000,
    });
    const firstContainer = document.createElement("div");
    const secondContainer = document.createElement("div");
    Object.defineProperty(firstContainer, "getBoundingClientRect", { value: () => ({ left: 1, top: 2, width: 320, height: 240 }) });
    Object.defineProperty(secondContainer, "getBoundingClientRect", { value: () => ({ left: 10, top: 20, width: 800, height: 600 }) });

    const firstAttach = adapter.attachRenderer(firstContainer, identity);
    const frame = document.querySelector("iframe[data-red-alert-renderer]") as HTMLIFrameElement | null;
    if (frame === null || frame.contentWindow === null) throw new Error("expected loopback iframe contentWindow");
    const child = frame.contentWindow;
    const postMessage = vi.fn();
    Object.defineProperty(child, "postMessage", { configurable: true, value: postMessage });
    frame.dispatchEvent(new Event("load"));
    await Promise.resolve();
    const detach = adapter.detachRenderer(firstContainer);
    await expect(firstAttach).rejects.toMatchObject({ code: "DISPOSED" });
    await detach;
    expect(adapter.state).not.toBe("disposed");
    expect(document.querySelectorAll("iframe[data-red-alert-renderer]")).toHaveLength(1);

    postMessage.mockImplementation((message: unknown) => {
      const value = message as { readonly type?: string; readonly requestId?: string };
      if (value.type !== "renderer/hello") return;
      queueMicrotask(() => window.dispatchEvent(new MessageEvent("message", {
        origin,
        source: child,
        data: {
          protocolVersion: 1,
          sessionId: identity.sessionId,
          matchId: identity.matchId,
          seat: identity.seat,
          tick: identity.tick,
          type: "renderer/ready",
          requestId: value.requestId,
        },
      })));
    });
    await adapter.attachRenderer(secondContainer, identity);
    expect(adapter.state).toBe("ready");
    const host = document.querySelector("[data-red-alert-renderer-host]") as HTMLDivElement | null;
    expect(host?.style.visibility).toBe("visible");
    expect(host?.style.left).toBe("10px");
    await adapter.detachRenderer(firstContainer);
    expect(host?.style.visibility).toBe("visible");
    await adapter.dispose();
  });

  it("keeps a UI removal drain visible to root session cleanup", async () => {
    const registry = new BrowserAdapterRegistry();
    const runtime = new BrowserRendererRuntime(registry);
    const gate = deferred();
    const adapter = new FakeRendererAdapter(gate.promise);
    const registration = runtime.register("session-ui-removal", adapter);

    const first = registration();
    const rootCleanup = runtime.removeSession("session-ui-removal");
    expect(rootCleanup).toBe(first);
    expect(registry.get("session-ui-removal")).toBeUndefined();
    expect(adapter.disposeCalls).toBe(1);

    let settled = false;
    void rootCleanup.then(() => { settled = true; });
    await Promise.resolve();
    expect(settled).toBe(false);
    expect(() => runtime.register("session-ui-removal", new FakeRendererAdapter())).toThrow(/removal is still in progress/);

    gate.release();
    await rootCleanup;
    expect(await runtime.removeSession("session-ui-removal")).toBeUndefined();
    const replacement = runtime.register("session-ui-removal", new FakeRendererAdapter());
    await replacement();
    await runtime.dispose();
  });

  it("waits for every adapter during dispose and reports all settled failures", async () => {
    const registry = new BrowserAdapterRegistry();
    const runtime = new BrowserRendererRuntime(registry);
    const gate = deferred();
    const slow = new FakeRendererAdapter(gate.promise);
    const failed = new FakeRendererAdapter(Promise.reject(new Error("renderer cleanup failed")));
    runtime.register("session-slow", slow);
    runtime.register("session-failed", failed);

    const disposal = runtime.dispose().then(
      () => ({ ok: true as const }),
      (error: unknown) => ({ ok: false as const, error }),
    );
    await Promise.resolve();
    expect(slow.disposeCalls).toBe(1);
    expect(failed.disposeCalls).toBe(1);
    let finished = false;
    void disposal.then(() => { finished = true; });
    await Promise.resolve();
    expect(finished).toBe(false);

    gate.release();
    const result = await disposal;
    expect(result.ok).toBe(false);
    if (result.ok) throw new Error("expected renderer disposal to fail");
    expect(result.error).toBeInstanceOf(Error);
  });
});
