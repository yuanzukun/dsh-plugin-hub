import { afterEach, describe, expect, it } from "vitest";
import { Context } from "@deepseek-ai/cordis";
import type { HostConnectionHandle } from "@deepseek-ai/dsh-client-connection";
import {
  RedAlertCompatConnectionService,
  supportsHostConnectionRpc,
} from "../src/compat-connection.ts";

let context: Context | undefined;

afterEach(async () => {
  await context?.fiber.dispose();
  context = undefined;
});

describe("latest DSH Web connection fallback", () => {
  it("selects only a connection that actually implements generic Host RPC", () => {
    expect(supportsHostConnectionRpc({})).toBe(false);
    expect(supportsHostConnectionRpc({ rpc: {} })).toBe(false);
    expect(supportsHostConnectionRpc({ rpc: { handle() {} } })).toBe(true);
  });

  it("registers an isolated fallback service without replacing the active connection", () => {
    context = new Context();
    const legacyConnection = { api: {} };
    context.provide("connection", legacyConnection as unknown as HostConnectionHandle);
    new RedAlertCompatConnectionService(context);

    expect(context.get("connection", false)).toBe(legacyConnection);
    const compat = context.get("redAlertCompatConnection", false);
    expect(compat).toBeInstanceOf(RedAlertCompatConnectionService);
    expect(supportsHostConnectionRpc(compat)).toBe(true);
  });
});
