/** @vitest-environment jsdom */

import React from "react";
import { act, cleanup, fireEvent, render } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { ConvViewProps } from "@deepseek-ai/dsh-client-ui-conversation/client";
import { RedAlertView } from "../src/client/index.tsx";
import type { RedAlertState } from "../src/projection.ts";
import type { BrowserCommandClientService } from "../src/client/browser-command-consumer.ts";
import type { BrowserRendererState } from "../src/client/browser-renderer-runtime.ts";

afterEach(() => cleanup());

const contact = (id: number, source: "visible" | "last-seen", x: number, y: number) => ({
  id,
  unitType: "E1",
  label: source === "visible" ? "可见单位" : "最后发现单位",
  kind: "Infantry",
  position: { x, y },
  hpPct: 80,
  observedAtTick: source === "visible" ? 120 : 90,
  source,
});

const running: RedAlertState = {
  status: "running",
  view: { mode: "offline", realUiAvailable: false },
  match: {
    matchId: "match-client-view",
    map: "simple-1v1-no-preview.map",
    mapSize: { width: 64, height: 64 },
    myCountry: "Russians",
    status: "active",
    tick: 120,
    cycle: 8,
    view: { mode: "offline", realUiAvailable: false },
    observation: {
      tick: 120,
      ownUnits: [contact(1, "visible", 4, 5)],
      visibleEnemies: [contact(2, "visible", 12, 13)],
      lastSeenEnemies: [contact(3, "last-seen", 8, 9)],
      visibleNeutralObjects: [],
    },
    facts: {
      gameTimeSec: 20,
      phase: "early",
      self: { credits: 1000, power: { total: 100, drain: 20, isLowPower: false }, defeated: false },
      visibleEnemyGroups: 1,
      lastSeenEnemyGroups: 1,
      visibleNeutralGroups: 0,
    },
    receipts: [],
    placements: [],
    replaySaved: false,
  },
};

function viewFor(state: RedAlertState | undefined, rendererService?: BrowserCommandClientService) {
  const useProjection = () => state;
  return render(React.createElement(RedAlertView, { useProjection, rendererService } as unknown as ConvViewProps));
}

describe("red-alert DSH client view", () => {
  it("does not create a browser bridge or iframe before explicit live-config confirmation", () => {
    const state: RedAlertState = {
      ...running,
      match: running.match === undefined ? undefined : {
        ...running.match,
        sessionId: "session-renderer-view",
        seat: "Russians",
      },
    };
    const addSpy = vi.spyOn(window, "addEventListener");
    const view = render(React.createElement(
      React.StrictMode,
      null,
      React.createElement(RedAlertView, { useProjection: () => state } as unknown as ConvViewProps),
    ));
    const messageAdds = addSpy.mock.calls.filter(([type]) => type === "message").length;
    expect(messageAdds).toBe(0);
    expect(view.container.querySelector("iframe")).toBeNull();
    view.unmount();
    addSpy.mockRestore();
  });

  it("renders empty and creating states with the Chat handoff", () => {
    const empty = viewFor({ status: "empty", view: { mode: "offline", realUiAvailable: false } });
    expect(empty.container.querySelector("[data-state='empty']")).not.toBeNull();
    expect(empty.container.textContent).toContain("创建一场 1v1 红警对战");
    empty.unmount();

    const creating = viewFor({
      status: "creating",
      view: { mode: "offline", realUiAvailable: false },
      request: { map: "simple-1v1-no-preview.map", myCountry: "Russians", opponents: 1, opponentType: "noop", decisionPeriod: 15, maxTicks: 600 },
      identity: { matchId: "creating-client-view", sessionId: "creating-session", seat: "Russians", tick: 0 },
    });
    expect(creating.container.querySelector("[data-state='creating']")).not.toBeNull();
    expect(creating.container.textContent).toContain("正在由真实浏览器客户端建立对局");
    expect(creating.container.querySelector("[data-match-id='creating-client-view']")).not.toBeNull();
  });

  it("shows automatic resource setup and the local fallback before a real-renderer match", () => {
    const service = {} as BrowserCommandClientService;
    const empty = viewFor({ status: "empty", view: { mode: "offline", realUiAvailable: false } }, service);
    expect(empty.container.textContent).toContain("资源自动准备与本地备用");
    expect(empty.container.textContent).toContain("--download-resources");
    expect(empty.container.textContent).toContain("https://download.ra2web.com/full-pack.7z");
    expect(empty.container.textContent).toContain("不代表 EA");
    expect(empty.container.textContent).not.toContain("Headless 兼容模式");
  });

  it("renders running, stopped, and error state branches", () => {
    const runningView = viewFor(running);
    expect(runningView.container.querySelector("[data-state='running']")).not.toBeNull();
    expect(runningView.container.querySelector("[data-testid='ra-tactical-map']")).not.toBeNull();
    expect(runningView.container.querySelectorAll("[data-marker-kind='own']")).toHaveLength(1);
    expect(runningView.container.querySelectorAll("[data-marker-kind='enemy']")).toHaveLength(1);
    expect(runningView.container.querySelectorAll("[data-marker-kind='last-seen']")).toHaveLength(1);
    expect(runningView.container.querySelector("[data-match-id='match-client-view']")).not.toBeNull();
    expect(runningView.container.querySelector(".ra-header")).toBeNull();
    expect(runningView.container.querySelector(".ra-meta")).toBeNull();
    expect(runningView.container.querySelector(".ra-renderer-heading")).toBeNull();
    expect(runningView.container.textContent).not.toContain("red alert / real client / fog-safe control");
    expect(runningView.container.textContent).not.toContain("红色警戒游戏画面");
    expect(runningView.container.textContent).toContain("最后发现");
    expect(runningView.container.textContent).toContain("当前可见");
    runningView.unmount();

    const stoppedView = viewFor({ ...running, status: "stopped", match: { ...running.match!, status: "stopped", replaySaved: true } });
    expect(stoppedView.container.querySelector("[data-state='stopped']")).not.toBeNull();
    expect(stoppedView.container.querySelector("[data-match-id='match-client-view']")).not.toBeNull();
    stoppedView.unmount();

    const errorView = viewFor({
      status: "error",
      view: { mode: "offline", realUiAvailable: false },
      match: running.match,
      failure: { phase: "running", code: "RED_ALERT_OPERATION", message: "可恢复错误", recoverable: true },
    });
    expect(errorView.container.querySelector("[data-state='error']")).not.toBeNull();
    expect(errorView.container.textContent).toContain("可恢复错误");
  });

  it("keeps the real renderer mounted for a recoverable active-match error", () => {
    const descriptor = { mode: "loopback" as const, enabled: true as const, sourceLabel: "test renderer" };
    const service = {
      rendererConfig: vi.fn(),
      renderer: { get: vi.fn(() => undefined) },
    } as unknown as BrowserCommandClientService;
    const error = viewFor({
      status: "error",
      view: { mode: "real-browser", realUiAvailable: true, renderer: descriptor },
      match: { ...running.match!, sessionId: "session-recoverable", seat: "Russians", view: { mode: "real-browser", realUiAvailable: true, renderer: descriptor } },
      failure: { phase: "running", code: "COMMAND_REJECTED", message: "放置点不可用", recoverable: true },
    }, service);
    expect(error.container.querySelector(".ra-renderer-panel")).not.toBeNull();
    expect(error.getByRole("button", { name: "确认并连接本地 renderer" })).toBeTruthy();
    expect(error.container.textContent).toContain("放置点不可用");
  });

  it("keeps the real renderer mounted after a recoverable first-run create failure", () => {
    const descriptor = { mode: "loopback" as const, enabled: true as const, sourceLabel: "test renderer" };
    const service = {
      rendererConfig: vi.fn(),
      renderer: { get: vi.fn(() => undefined) },
    } as unknown as BrowserCommandClientService;
    const error = viewFor({
      status: "error",
      view: { mode: "real-browser", realUiAvailable: true, renderer: descriptor },
      request: { map: "current", myCountry: "Russians", opponents: 1, opponentType: "normal", gameSpeed: 2, decisionPeriod: 15, maxTicks: 600 },
      identity: { matchId: "first-run-match", sessionId: "first-run-session", seat: "Russians", tick: 0 },
      failure: { phase: "creating", code: "ADAPTER_COMMAND_FAILED", message: "local game files are required", recoverable: true },
    }, service);
    expect(error.container.querySelector(".ra-renderer-panel")).not.toBeNull();
    expect(error.container.querySelector("[data-match-id='first-run-match']")).not.toBeNull();
    expect(error.getByRole("button", { name: "确认并连接本地 renderer" })).toBeTruthy();
    expect(error.container.textContent).toContain("local game files are required");
  });

  it("keeps an existing real renderer visible on the finished match result screen", async () => {
    const descriptor = { mode: "loopback" as const, enabled: true as const, sourceLabel: "test renderer" };
    const match = {
      ...running.match!,
      status: "finished" as const,
      sessionId: "session-finished-result",
      seat: "Russians",
      view: { mode: "real-browser" as const, realUiAvailable: true as const, renderer: descriptor },
      facts: { ...running.match!.facts, self: { ...running.match!.facts.self, defeated: true } },
    };
    const endpoint = { url: "http://localhost:45678/", port: 45678 };
    const attach = vi.fn(async () => undefined);
    const detach = vi.fn(async () => undefined);
    const rendererConfig = vi.fn();
    const service = {
      rendererConfig,
      renderer: {
        get: vi.fn(() => ({ endpoint })),
        getState: vi.fn(() => "ready" as const),
        getEndpoint: vi.fn(() => endpoint),
        subscribeState: vi.fn((_sessionId: string, listener: (next: "ready") => void) => {
          listener("ready");
          return () => undefined;
        }),
        attach,
        detach,
      },
    } as unknown as BrowserCommandClientService;
    const finished = viewFor({ status: "stopped", view: match.view, match }, service);
    await act(async () => { await Promise.resolve(); });
    expect(attach).toHaveBeenCalledTimes(1);
    expect(rendererConfig).not.toHaveBeenCalled();
    expect(finished.container.querySelector("[data-renderer-state='ready']")).not.toBeNull();
    expect(finished.container.textContent).not.toContain("当前对局已停止");
    finished.unmount();
    expect(detach).toHaveBeenCalledTimes(1);
  });

  it("does not offer a dead live reconnect after a finished match reload", () => {
    const descriptor = { mode: "loopback" as const, enabled: true as const, sourceLabel: "test renderer" };
    const match = {
      ...running.match!,
      status: "finished" as const,
      sessionId: "session-finished-reload",
      seat: "Russians",
      view: { mode: "real-browser" as const, realUiAvailable: true as const, renderer: descriptor },
      facts: { ...running.match!.facts, self: { ...running.match!.facts.self, defeated: true } },
    };
    const rendererConfig = vi.fn();
    const service = {
      rendererConfig,
      renderer: {
        get: vi.fn(() => undefined),
        getState: vi.fn(() => "unavailable" as const),
      },
    } as unknown as BrowserCommandClientService;
    const finished = viewFor({ status: "stopped", view: match.view, match }, service);

    expect(finished.container.querySelector("[data-renderer-state='ended']")).not.toBeNull();
    expect(finished.container.textContent).toContain("上一局已经结束");
    expect(finished.container.textContent).toContain("在当前 Chat 创建下一局");
    expect(finished.queryByRole("button", { name: /连接本地 renderer/ })).toBeNull();
    expect(rendererConfig).not.toHaveBeenCalled();
    finished.unmount();
  });

  it("does not detach the same-match renderer while entering and leaving a recoverable error", async () => {
    const descriptor = { mode: "loopback" as const, enabled: true as const, sourceLabel: "test renderer" };
    const match = { ...running.match!, sessionId: "session-stable-error", seat: "Russians", view: { mode: "real-browser" as const, realUiAvailable: true as const, renderer: descriptor } };
    let state: RedAlertState = { ...running, view: match.view, match };
    const endpoint = { url: "http://localhost:45678/", port: 45678 };
    const attach = vi.fn(async () => undefined);
    const detach = vi.fn(async () => undefined);
    const service = {
      rendererConfig: vi.fn(async () => ({ protocolVersion: 1 as const, sessionId: match.sessionId, matchId: match.matchId, seat: match.seat, ...endpoint })),
      renderer: {
        get: vi.fn(() => ({ endpoint })),
        getState: vi.fn(() => "ready" as const),
        getEndpoint: vi.fn(() => endpoint),
        subscribeState: vi.fn((_sessionId: string, listener: (next: "ready") => void) => {
          listener("ready");
          return () => undefined;
        }),
        attach,
        detach,
      },
    } as unknown as BrowserCommandClientService;
    const useProjection = () => state;
    const element = () => React.createElement(RedAlertView, { useProjection, rendererService: service } as unknown as ConvViewProps);
    const view = render(element());
    await act(async () => { await Promise.resolve(); });
    expect(attach).toHaveBeenCalledTimes(1);

    state = {
      status: "error",
      view: match.view,
      match,
      failure: { phase: "running", code: "COMMAND_REJECTED", message: "放置点不可用", recoverable: true },
    };
    view.rerender(element());
    await act(async () => { await Promise.resolve(); });
    expect(attach).toHaveBeenCalledTimes(1);
    expect(detach).not.toHaveBeenCalled();

    state = { ...running, view: match.view, match };
    view.rerender(element());
    await act(async () => { await Promise.resolve(); });
    expect(attach).toHaveBeenCalledTimes(1);
    expect(detach).not.toHaveBeenCalled();
  });

  it("renders only fair observation fields and has a projection-missing state", () => {
    const result = viewFor(running);
    const text = result.container.textContent ?? "";
    expect(text).toContain("12,13");
    expect(text).toContain("8,9");
    expect(text).not.toContain("hidden-enemy-id");
    expect(text).not.toContain("99,99");
    expect(result.container.querySelector("[data-source='last-seen']")).not.toBeNull();
    result.unmount();

    const missing = viewFor(undefined);
    expect(missing.container.querySelector("[data-state='projection-missing']")).not.toBeNull();
    expect(missing.container.textContent).toContain("不会读取浏览器缓存");
  });

  it("uses exclusive idle, connecting, error, and confirmed renderer states", async () => {
    const descriptor = { mode: "loopback" as const, enabled: true as const, sourceLabel: "test renderer" };
    const state: RedAlertState = {
      ...running,
      view: { mode: "real-browser", realUiAvailable: true, renderer: descriptor },
      match: { ...running.match!, sessionId: "session-renderer-state", seat: "Russians" },
    };
    let resolveConfig!: (value: { readonly url: string; readonly port: number; readonly protocolVersion: 1; readonly sessionId: string; readonly matchId: string; readonly seat: string }) => void;
    const rendererConfig = vi.fn(() => new Promise((resolve) => { resolveConfig = resolve as typeof resolveConfig; }));
    const registerLoopback = vi.fn(() => ({ remove: async () => undefined }));
    const renderer = {
      get: vi.fn(() => undefined),
      attach: vi.fn(async () => undefined),
      detach: vi.fn(async () => undefined),
      registerLoopback,
    };
    const service = { rendererConfig, renderer } as unknown as BrowserCommandClientService;
    const view = render(React.createElement(RedAlertView, { useProjection: () => state, rendererService: service } as unknown as ConvViewProps));
    const connect = view.getByRole("button", { name: "确认并连接本地 renderer" });
    fireEvent.click(connect);
    expect(view.container.querySelector("[data-renderer-state='connecting']")).not.toBeNull();
    expect(view.queryByRole("button", { name: "确认并连接本地 renderer" })).toBeNull();
    expect(rendererConfig).toHaveBeenCalledTimes(1);

    resolveConfig({ protocolVersion: 1, sessionId: "session-renderer-state", matchId: state.match!.matchId, seat: "Russians", url: "http://localhost:45678/", port: 45678 });
    await act(async () => { await Promise.resolve(); });
    expect(registerLoopback).toHaveBeenCalledTimes(1);
    view.unmount();

    const failureService = {
      rendererConfig: vi.fn(async () => { throw new Error("live config failed"); }),
      renderer: { get: () => undefined, attach: async () => undefined, detach: async () => undefined, registerLoopback: vi.fn() },
    } as unknown as BrowserCommandClientService;
    const failed = render(React.createElement(RedAlertView, { useProjection: () => state, rendererService: failureService } as unknown as ConvViewProps));
    fireEvent.click(failed.getByRole("button", { name: "确认并连接本地 renderer" }));
    await act(async () => { await Promise.resolve(); });
    expect(failed.container.querySelectorAll(".ra-renderer-placeholder[data-state='error']")).toHaveLength(1);
    expect(failed.getByRole("button", { name: "重试连接本地 renderer" }).className).toContain("ra-renderer-action");
    expect(failed.queryByRole("button", { name: "确认并连接本地 renderer" })).toBeNull();
    failed.unmount();
  });

  it("reuses a healthy root adapter after remount but replaces it after a transport error", async () => {
    const descriptor = { mode: "loopback" as const, enabled: true as const, sourceLabel: "test renderer" };
    const state: RedAlertState = {
      ...running,
      view: { mode: "real-browser", realUiAvailable: true, renderer: descriptor },
      match: { ...running.match!, sessionId: "session-renderer-retry", seat: "Russians" },
    };
    let adapterState: "ready" | "error" = "ready";
    const listeners = new Set<(next: "ready" | "error") => void>();
    const attach = vi.fn(async () => undefined);
    const rendererConfig = vi.fn(async () => ({ protocolVersion: 1 as const, sessionId: state.match!.sessionId!, matchId: state.match!.matchId, seat: "Russians", url: "http://localhost:45678/", port: 45678 }));
    let adapterPresent = true;
    const registerLoopback = vi.fn(() => {
      adapterPresent = true;
      return { remove: async () => undefined };
    });
    const removeSession = vi.fn(async () => { adapterPresent = false; });
    const existingAdapter = { endpoint: { url: "http://localhost:45678/", port: 45678 } };
    const service = {
      rendererConfig,
      renderer: {
        get: vi.fn(() => adapterPresent ? existingAdapter : undefined),
        getState: vi.fn(() => adapterState),
        getEndpoint: vi.fn(() => adapterPresent ? existingAdapter.endpoint : undefined),
        subscribeState: vi.fn((_sessionId: string, listener: (next: "ready" | "error") => void) => {
          listeners.add(listener);
          listener(adapterState);
          return () => listeners.delete(listener);
        }),
        attach,
        detach: vi.fn(async () => undefined),
        registerLoopback,
        removeSession,
      },
    } as unknown as BrowserCommandClientService;
    let view = render(React.createElement(RedAlertView, { useProjection: () => state, rendererService: service } as unknown as ConvViewProps));
    await act(async () => { await Promise.resolve(); });
    expect(attach).toHaveBeenCalledTimes(1);

    view.unmount();
    view = render(React.createElement(RedAlertView, { useProjection: () => state, rendererService: service } as unknown as ConvViewProps));
    await act(async () => { await Promise.resolve(); });
    expect(attach).toHaveBeenCalledTimes(2);

    adapterState = "error";
    for (const listener of listeners) listener("error");
    await act(async () => { await Promise.resolve(); });
    expect(view.container.querySelector("[data-renderer-state='error']")).not.toBeNull();
    expect(view.getByRole("button", { name: "重试连接本地 renderer" })).toBeTruthy();

    fireEvent.click(view.getByRole("button", { name: "重试连接本地 renderer" }));
    await act(async () => { await Promise.resolve(); });
    expect(rendererConfig).toHaveBeenCalledTimes(1);
    expect(removeSession).toHaveBeenCalledWith(state.match!.sessionId);
    expect(registerLoopback).toHaveBeenCalledTimes(1);
    expect(attach).toHaveBeenCalledTimes(3);
    adapterState = "ready";
    for (const listener of listeners) listener("ready");
    await act(async () => { await Promise.resolve(); });
    expect(view.container.querySelector("[data-renderer-state='connecting']")).toBeNull();
    expect(view.container.querySelector("[data-renderer-state='ready']")).not.toBeNull();
    view.unmount();
  });

  it("drains a root adapter before registering a changed endpoint", async () => {
    const descriptor = { mode: "loopback" as const, enabled: true as const, sourceLabel: "test renderer" };
    const state: RedAlertState = {
      ...running,
      view: { mode: "real-browser", realUiAvailable: true, renderer: descriptor },
      match: { ...running.match!, sessionId: "session-renderer-endpoint", seat: "Russians" },
    };
    let endpoint = { url: "http://localhost:45678/", port: 45678 };
    let adapterPresent = true;
    let adapterState: "ready" | "disconnected" = "ready";
    const listeners = new Set<(next: "ready" | "disconnected") => void>();
    const existingEndpoint = { url: endpoint.url, port: endpoint.port };
    const removeSession = vi.fn(async (_sessionId: string) => undefined);
    const registerLoopback = vi.fn(() => { adapterPresent = true; return { remove: async () => undefined }; });
    const rendererConfig = vi.fn(async () => ({ protocolVersion: 1 as const, sessionId: state.match!.sessionId!, matchId: state.match!.matchId, seat: "Russians", ...endpoint }));
    const service = {
      rendererConfig,
      renderer: {
        get: vi.fn(() => adapterPresent ? { endpoint: existingEndpoint } : undefined),
        getState: vi.fn(() => adapterState),
        getEndpoint: vi.fn(() => adapterPresent ? existingEndpoint : undefined),
        subscribeState: vi.fn((_sessionId: string, listener: (next: "ready" | "disconnected") => void) => {
          listeners.add(listener);
          listener(adapterState);
          return () => listeners.delete(listener);
        }),
        attach: vi.fn(async () => undefined),
        detach: vi.fn(async () => undefined),
        removeSession: vi.fn(async () => { adapterPresent = false; await removeSession(state.match!.sessionId!); }),
        registerLoopback,
      },
    } as unknown as BrowserCommandClientService;
    const view = render(React.createElement(RedAlertView, { useProjection: () => state, rendererService: service } as unknown as ConvViewProps));
    await act(async () => { await Promise.resolve(); });
    adapterState = "disconnected";
    for (const listener of listeners) listener("disconnected");
    await act(async () => { await Promise.resolve(); });
    expect(view.getByRole("button", { name: "重试连接本地 renderer" })).toBeTruthy();

    endpoint = { url: "http://localhost:45679/", port: 45679 };
    fireEvent.click(view.getByRole("button", { name: "重试连接本地 renderer" }));
    await act(async () => { await Promise.resolve(); });
    expect(removeSession).toHaveBeenCalledWith(state.match!.sessionId);
    expect(registerLoopback).toHaveBeenCalledTimes(1);
    expect(registerLoopback).toHaveBeenCalledWith(state.match!.sessionId, expect.objectContaining({ url: endpoint.url, origin: { allowLoopback: true, loopbackPort: endpoint.port } }));
    view.unmount();
  });

  it("ignores a stale adapter state callback after an identity switch", async () => {
    const descriptor = { mode: "loopback" as const, enabled: true as const, sourceLabel: "test renderer" };
    const first: RedAlertState = {
      ...running,
      view: { mode: "real-browser", realUiAvailable: true, renderer: descriptor },
      match: { ...running.match!, sessionId: "session-stale-state", matchId: "match-stale-state-a", seat: "Russians" },
    };
    const second: RedAlertState = {
      ...first,
      match: { ...first.match!, matchId: "match-stale-state-b" },
    };
    const listeners: Array<(state: BrowserRendererState) => void> = [];
    const service = {
      rendererConfig: vi.fn(),
      renderer: {
        get: vi.fn(() => ({}) as never),
        getState: vi.fn(() => "ready"),
        subscribeState: vi.fn((_sessionId: string, listener: (state: BrowserRendererState) => void) => {
          listeners.push(listener);
          listener("ready");
          return () => undefined;
        }),
        attach: vi.fn(async () => undefined),
        detach: vi.fn(async () => undefined),
        registerLoopback: vi.fn(),
      },
    } as unknown as BrowserCommandClientService;
    const view = render(React.createElement(RedAlertView, { useProjection: () => first, rendererService: service } as unknown as ConvViewProps));
    await act(async () => { await Promise.resolve(); });
    view.rerender(React.createElement(RedAlertView, { useProjection: () => second, rendererService: service } as unknown as ConvViewProps));
    await act(async () => { await Promise.resolve(); });
    expect(view.container.querySelector("[data-renderer-state='confirm']")).not.toBeNull();
    const stale = listeners[0];
    if (stale === undefined) throw new Error("expected first adapter listener");
    stale("ready");
    await act(async () => { await Promise.resolve(); });
    expect(view.container.querySelector("[data-renderer-state='confirm']")).not.toBeNull();
    view.unmount();
  });

  it("resets an identity to idle and ignores a stale config after session change", async () => {
    const descriptor = { mode: "loopback" as const, enabled: true as const, sourceLabel: "test renderer" };
    const first: RedAlertState = {
      ...running,
      view: { mode: "real-browser", realUiAvailable: true, renderer: descriptor },
      match: { ...running.match!, sessionId: "session-renderer-first", seat: "Russians" },
    };
    const second: RedAlertState = {
      ...first,
      match: { ...first.match!, sessionId: "session-renderer-second", matchId: "match-renderer-second" },
    };
    let resolveConfig!: (value: unknown) => void;
    const rendererConfig = vi.fn(() => new Promise((resolve) => { resolveConfig = resolve; }));
    const registerLoopback = vi.fn(() => ({ remove: async () => undefined }));
    const service = {
      rendererConfig,
      renderer: { get: () => undefined, attach: async () => undefined, detach: async () => undefined, registerLoopback },
    } as unknown as BrowserCommandClientService;
    const view = render(React.createElement(RedAlertView, { useProjection: () => first, rendererService: service } as unknown as ConvViewProps));
    fireEvent.click(view.getByRole("button", { name: "确认并连接本地 renderer" }));
    expect(view.container.querySelector("[data-renderer-state='connecting']")).not.toBeNull();

    view.rerender(React.createElement(RedAlertView, { useProjection: () => second, rendererService: service } as unknown as ConvViewProps));
    await act(async () => { await Promise.resolve(); });
    expect(view.container.querySelector("[data-renderer-state='confirm']")).not.toBeNull();
    resolveConfig({ protocolVersion: 1, sessionId: first.match!.sessionId, matchId: first.match!.matchId, seat: "Russians", url: "http://localhost:45678/", port: 45678 });
    await act(async () => { await Promise.resolve(); });
    expect(registerLoopback).not.toHaveBeenCalled();
    expect(view.container.querySelector("[data-renderer-state='confirm']")).not.toBeNull();
  });

  it("restores a registered adapter from the current session without asking again", async () => {
    const descriptor = { mode: "loopback" as const, enabled: true as const, sourceLabel: "test renderer" };
    const attach = vi.fn(async () => undefined);
    const service = {
      rendererConfig: vi.fn(),
      renderer: { get: vi.fn(() => ({}) as never), attach, detach: vi.fn(async () => undefined), registerLoopback: vi.fn() },
    } as unknown as BrowserCommandClientService;
    const state: RedAlertState = {
      ...running,
      view: { mode: "real-browser", realUiAvailable: true, renderer: descriptor },
      match: { ...running.match!, sessionId: "session-renderer-existing", seat: "Russians" },
    };
    const view = render(React.createElement(RedAlertView, { useProjection: () => state, rendererService: service } as unknown as ConvViewProps));
    await act(async () => { await Promise.resolve(); });
    expect(view.queryByRole("button", { name: "确认并连接本地 renderer" })).toBeNull();
    expect(attach).toHaveBeenCalledTimes(1);
  });
});
