import { describe, expect, test } from "vitest";
import { buildDshLaunchArgs } from "../scripts/run-dsh-args.mjs";

describe("DSH launcher browser boundary", () => {
  test("always disables automatic browser opening", () => {
    expect(buildDshLaunchArgs("web", [])).toEqual(["--profile", "web", "--no-open"]);
  });

  test("removes explicit open requests and keeps ordinary DSH arguments", () => {
    expect(buildDshLaunchArgs("showcase", ["--open", "--port", "3081"])).toEqual([
      "--profile",
      "showcase",
      "--port",
      "3081",
      "--no-open",
    ]);
  });

  test("deduplicates separators and no-open flags", () => {
    expect(buildDshLaunchArgs("web", ["--", "--no-open", "--no-open"])).toEqual([
      "--profile",
      "web",
      "--no-open",
    ]);
  });
});
