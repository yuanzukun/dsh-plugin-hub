/** @vitest-environment jsdom */

import React from "react";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, expect, it, vi, type Mock } from "vitest";
import type { ILayout } from "@deepseek-ai/dsh-client-ui-layout/client";
import { RedAlertBattlefieldDock } from "../src/client/index.tsx";
import { emptyRedAlertState } from "../src/projection.ts";
import type { RedAlertState } from "../src/projection.ts";

afterEach(() => cleanup());

type LayoutMock = {
  readonly toggleSidebar: Mock<() => void>;
  readonly openDetails: Mock<() => void>;
  readonly closeDetails: Mock<() => void>;
};

function layoutMock(): LayoutMock {
  return {
    toggleSidebar: vi.fn<() => void>(),
    openDetails: vi.fn<() => void>(),
    closeDetails: vi.fn<() => void>(),
  };
}

function renderDock(layout: ILayout, state: RedAlertState = emptyRedAlertState()): ReturnType<typeof render> {
  return render(React.createElement(RedAlertBattlefieldDock, {
    layout,
    sessionId: "session-one",
    useProjection: ((key: string) => key === "redAlert" ? state : undefined) as never,
  } as never));
}

it("keeps Chat selected while opening a single right-side battlefield", () => {
  const layout = layoutMock();
  renderDock(layout);

  expect(layout.openDetails).toHaveBeenCalledTimes(1);
  expect(screen.getByRole("button", { name: "战场" }).getAttribute("aria-pressed")).toBe("true");
  expect(screen.getByRole("complementary", { name: "红警 2 右侧战场" })).toBeTruthy();
  expect(screen.getByText("尚未建立红警对战")).toBeTruthy();
  expect(document.querySelectorAll("[data-testid='ra-side-battlefield']")).toHaveLength(1);

  fireEvent.click(screen.getByRole("button", { name: "放大" }));
  expect(screen.getByRole("complementary", { name: "红警 2 右侧战场" }).getAttribute("data-wide")).toBe("true");

  fireEvent.click(screen.getByRole("button", { name: "收起" }));
  expect(layout.closeDetails).toHaveBeenCalledTimes(1);
  expect(screen.queryByRole("complementary", { name: "红警 2 右侧战场" })).toBeNull();
  expect(screen.getByRole("button", { name: "战场" }).getAttribute("aria-pressed")).toBe("false");

  fireEvent.click(screen.getByRole("button", { name: "战场" }));
  expect(layout.openDetails).toHaveBeenCalledTimes(2);
  expect(document.querySelectorAll("[data-testid='ra-side-battlefield']")).toHaveLength(1);
});

it("shows the camera-only drag affordance for an active match", () => {
  const state: RedAlertState = {
    status: "running",
    view: { mode: "offline", realUiAvailable: false },
    match: {
      matchId: "viewer-match",
      map: "mp02t2.map",
      mapSize: { width: 200, height: 200 },
      myCountry: "Russians",
      status: "active",
      tick: 3181,
      cycle: 1,
      view: { mode: "offline", realUiAvailable: false },
      observation: { tick: 3181, ownUnits: [], visibleEnemies: [], lastSeenEnemies: [], visibleNeutralObjects: [] },
      facts: {
        gameTimeSec: 212,
        phase: "mid",
        self: { credits: 6900, power: { total: 150, drain: 0, isLowPower: false }, defeated: false },
        visibleEnemyGroups: 0,
        lastSeenEnemyGroups: 0,
        visibleNeutralGroups: 0,
      },
      receipts: [],
      placements: [],
      replaySaved: false,
    },
  };

  renderDock(layoutMock(), state);
  expect(screen.getByText("active · t3181 · 左键拖动观战")).toBeTruthy();
});

it("returns the official details column when the session dock unmounts", () => {
  const layout = layoutMock();
  const view = renderDock(layout);
  view.unmount();
  expect(layout.closeDetails).toHaveBeenCalledTimes(1);
});
