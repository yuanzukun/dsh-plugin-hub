/** @vitest-environment jsdom */

import React from "react";
import { fireEvent, render, waitFor } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { ResourceImportPanel } from "../src/client/index.tsx";
import { BrowserResourceProvider, type ResourceStorage, type StoredResourceArchive } from "../src/client/resource-provider.ts";
import { resolveResourceArchiveDescriptor } from "../src/resource-config.ts";

class MemoryResourceStorage implements ResourceStorage {
  private readonly records = new Map<string, StoredResourceArchive>();

  async read(id: string): Promise<StoredResourceArchive | undefined> {
    return this.records.get(id);
  }

  async write(record: StoredResourceArchive): Promise<void> {
    this.records.set(record.id, record);
  }

  async remove(id: string): Promise<void> {
    this.records.delete(id);
  }
}

const descriptor = resolveResourceArchiveDescriptor({
  resourceArchiveUrl: "https://example.test/ui-pack.7z",
  resourceArchiveSize: 4,
  resourceArchiveSha256: "c".repeat(64),
  resourceArchiveVersion: "ui-test",
  resourceArchiveSourceLabel: "UI test source",
  resourceArchiveLicenseNotice: "UI test rights notice",
});

describe("resource import UI", () => {
  it("does not fetch until source confirmation and exposes progress plus retry controls", async () => {
    const fetchImpl = vi.fn(async () => new Response(new ArrayBuffer(4), { status: 200, headers: { "content-length": "4" } })) as unknown as typeof fetch;
    const provider = new BrowserResourceProvider(descriptor, {
      storage: new MemoryResourceStorage(),
      fetch: fetchImpl,
      digest: async () => "c".repeat(64),
    });
    const result = render(<ResourceImportPanel provider={provider} descriptor={descriptor} />);
    await waitFor(() => expect(result.getByTestId("ra-resource-import").getAttribute("data-state")).toBe("missing"));
    expect(fetchImpl).not.toHaveBeenCalled();

    fireEvent.click(result.getByRole("button", { name: "查看并确认导入" }));
    expect(result.getByText("请确认以上公开来源、文件大小、SHA-256 和版权提示，再开始下载。")).toBeTruthy();
    fireEvent.click(result.getByRole("button", { name: "确认并下载" }));
    await waitFor(() => expect(result.getByTestId("ra-resource-import").getAttribute("data-state")).toBe("ready"));
    expect(fetchImpl).toHaveBeenCalledTimes(1);
    expect(result.getByText(/资源已通过大小和 SHA-256 校验/)).toBeTruthy();
  });
});
