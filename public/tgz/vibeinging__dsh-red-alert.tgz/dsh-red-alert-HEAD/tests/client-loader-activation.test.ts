import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { runInNewContext } from "node:vm";
import { Context } from "@deepseek-ai/cordis";
import { expect, it } from "vitest";

type ClientHandoff = {
  readonly id: string;
  readonly factory: (require: (specifier: string) => unknown) => Record<string, unknown>;
};

type ClientSurface = {
  readonly id: string;
  readonly inject: readonly string[];
  readonly apply: (ctx: Context) => void;
};

type SlotEntry = {
  readonly options: {
    readonly id?: string;
    readonly order?: number;
  };
};

type SlotService = {
  readonly register: (
    options: {
      readonly name: string;
      readonly id?: string;
      readonly order?: number;
      readonly label?: string;
      readonly children?: Record<string, { readonly kind: string; readonly scope: string }>;
      readonly store?: unknown;
    },
    component: unknown,
  ) => () => void;
  readonly entries: (name: string) => readonly SlotEntry[];
};

function loadClientSurface(packageName: string): ClientSurface | (ClientSurface & { readonly SlotRegistry: unknown }) {
  const packageRequire = createRequire(import.meta.url);
  const source = readFileSync(packageRequire.resolve(`${packageName}/client`), "utf8");
  let handoff: ClientHandoff | undefined;
  runInNewContext(source, {
    window: {
      __ModuleLoader__: {
        load(value: ClientHandoff): void {
          handoff = value;
        },
      },
    },
  });
  if (handoff === undefined) throw new Error(`${packageName} did not register a client handoff`);

  type FallbackModule = ((...args: readonly unknown[]) => unknown) & Record<string, unknown>;
  let fallback: FallbackModule;
  function fallbackModule(..._args: readonly unknown[]): unknown {
    return fallback;
  }
  fallback = new Proxy(fallbackModule as FallbackModule, {
    get: () => fallback,
    apply: () => fallback,
    construct: () => fallback,
  });
  const tolerantRequire = (specifier: string): unknown => {
    try {
      return packageRequire(specifier);
    } catch {
      return fallback;
    }
  };
  return { id: handoff.id, ...handoff.factory(tolerantRequire) } as ClientSurface & { readonly SlotRegistry?: unknown; readonly defineStore?: unknown };
}

it("uses the latest runtime SlotRegistry to register the right-side battlefield action", async () => {
  const runtime = loadClientSurface("@deepseek-ai/dsh-client-runtime") as ClientSurface & { readonly SlotRegistry?: unknown; readonly defineStore?: unknown };
  expect(runtime.SlotRegistry).toBeTypeOf("function");
  expect(runtime.defineStore).toBeTypeOf("function");

  const ctx = new Context();
  const runtimeFiber = ctx.plugin(runtime.SlotRegistry as never, undefined as never);
  await runtimeFiber.await();

  const slots = ctx.get("slots") as unknown as SlotService;
  slots.register({
    name: "root",
    children: {
      "conversation.session": { kind: "single", scope: "session" },
      "conversation.session.header.actions": { kind: "list", scope: "session" },
      "conversation.view": { kind: "list", scope: "session" },
    },
  }, () => null);
  const defineStore = runtime.defineStore as (spec: {
    readonly init: () => { view: string | null };
    readonly actions: { readonly setView: (draft: { view: string | null }, view: string) => void };
  }) => unknown;
  const chatStore = defineStore({
    init: () => ({ view: null }),
    actions: { setView: (draft, view) => { draft.view = view; } },
  });
  slots.register({ name: "conversation.session", store: chatStore }, () => null);
  slots.register({ name: "conversation.view", id: "chat", order: 0 }, () => null);

  ctx.provide("connection", {
    api: {},
    isLoopback: true,
    rpc: { call: async () => ({ ok: false, error: { code: "internal", message: "no channel", details: {} } }) },
    start: () => ({ stop: () => {} }),
  });
  ctx.provide("sessions", {
    list: { getSnapshot: () => ({ current: undefined }), subscribe: () => () => {} },
    binding: () => undefined,
  });
  ctx.provide("layout", {
    toggleSidebar: () => {},
    openDetails: () => {},
    closeDetails: () => {},
  });

  const redAlert = loadClientSurface("@vibeinging/dsh-red-alert");
  expect(redAlert.inject).toEqual(["connection", "layout", "sessions", "slots"]);
  const redAlertFiber = ctx.plugin({ inject: [...redAlert.inject], apply: redAlert.apply });
  await redAlertFiber.await();

  expect(slots.entries("conversation.view").map((entry) => ({
    id: entry.options.id,
    order: entry.options.order,
  }))).toEqual([{ id: "chat", order: 0 }]);
  expect(slots.entries("conversation.session.header.actions").map((entry) => ({
    id: entry.options.id,
    order: entry.options.order,
  }))).toEqual([{ id: "red-alert-battlefield", order: -20 }]);

  await redAlertFiber.dispose();
  expect(slots.entries("conversation.view")).toHaveLength(1);
  expect(slots.entries("conversation.session.header.actions")).toHaveLength(0);
  await runtimeFiber.dispose();
});
