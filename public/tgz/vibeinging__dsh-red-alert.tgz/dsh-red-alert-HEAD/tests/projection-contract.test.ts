import { describe, expect, it } from "vitest";
import type { SessionEvent } from "@deepseek-ai/dsh-session";
import {
  applyRedAlertProjection,
  creatingState,
  emptyRedAlertState,
  failureState,
  redAlertProjectionSchema,
  stateFromMatch,
} from "../src/projection.ts";

const match = {
  matchId: "projection-match",
  map: "simple-1v1-no-preview.map",
  mapSize: { width: 64, height: 64 },
  myCountry: "Russians",
  status: "active" as const,
  tick: 4,
  cycle: 1,
  view: { mode: "offline" as const, realUiAvailable: false as const },
  observation: { tick: 4, ownUnits: [], visibleEnemies: [], lastSeenEnemies: [], visibleNeutralObjects: [] },
  facts: {
    gameTimeSec: 1,
    phase: "early" as const,
    self: { credits: 1000, power: { total: 100, drain: 10, isLowPower: false }, defeated: false },
    visibleEnemyGroups: 0,
    lastSeenEnemyGroups: 0,
    visibleNeutralGroups: 0,
  },
  receipts: [],
  placements: [],
  replaySaved: false,
};

describe("red-alert session projection contract", () => {
  it("folds only the complete red-alert state event and leaves other events unchanged", () => {
    const state = stateFromMatch(match);
    const event = {
      type: "red-alert/state",
      seq: 7,
      time: 1,
      data: state,
    } as SessionEvent;
    const folded = applyRedAlertProjection(emptyRedAlertState(), event);
    expect(folded).toEqual(state);
    expect(Object.hasOwn(folded, "revision")).toBe(false);
    expect(Object.hasOwn(folded, "seq")).toBe(false);
    expect(applyRedAlertProjection(folded, { type: "turn/start", seq: 8, time: 2, data: { turn: 1 } } as SessionEvent)).toBe(folded);
  });

  it("validates empty and creating states at the wire boundary", () => {
    expect(redAlertProjectionSchema.parse(emptyRedAlertState()).status).toBe("empty");
    const creating = creatingState({
      map: "simple-1v1-no-preview.map",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "noop",
      gameSpeed: 0,
      decisionPeriod: 15,
      maxTicks: 600,
    }, { matchId: "creating-match", sessionId: "creating-session", seat: "Russians", tick: 0 });
    expect(redAlertProjectionSchema.parse(creating)).toEqual(creating);
    if (creating.request === undefined) throw new Error("creating state omitted its request");
    const { gameSpeed: _historicalGameSpeed, ...historicalRequest } = creating.request;
    expect(redAlertProjectionSchema.parse({ ...creating, request: historicalRequest }).request).not.toHaveProperty("gameSpeed");
    expect(() => redAlertProjectionSchema.parse({ ...creating, revision: 1 })).toThrow();
  });

  it("publishes the real browser authority truthfully while accepting historical offline events", () => {
    const renderer = { mode: "loopback" as const, enabled: true as const, sourceLabel: "pinned compatible renderer" };
    const state = stateFromMatch(match, { sessionId: "browser-session", seat: "Russians" }, undefined, renderer);
    expect(state.view).toMatchObject({ mode: "real-browser", realUiAvailable: true, renderer });
    expect(state.match?.view).toMatchObject({ mode: "real-browser", realUiAvailable: true, renderer });
    expect(redAlertProjectionSchema.parse(state)).toEqual(state);

    const historical = { ...state, view: { ...state.view, mode: "offline", realUiAvailable: false } as const };
    expect(redAlertProjectionSchema.parse(historical).view.mode).toBe("offline");
  });

  it("preserves the browser identity while a first-run create failure waits for resource import", () => {
    const identity = { matchId: "first-run-match", sessionId: "first-run-session", seat: "Russians", tick: 0 as const };
    const request = {
      map: "current",
      myCountry: "Russians",
      opponents: 1,
      opponentType: "normal" as const,
      gameSpeed: 2,
      decisionPeriod: 15,
      maxTicks: 600,
    };
    const renderer = { mode: "loopback" as const, enabled: true as const, sourceLabel: "pinned compatible renderer" };
    const failed = failureState("creating", new Error("local game files are required"), undefined, request, identity, undefined, renderer);

    expect(failed.identity).toEqual(identity);
    expect(redAlertProjectionSchema.parse(failed)).toEqual(failed);
  });
});
