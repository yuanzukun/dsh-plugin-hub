import { existsSync, readFileSync, readdirSync } from "node:fs";
import { cp, mkdir, mkdtemp, realpath, rm } from "node:fs/promises";
import { execFile } from "node:child_process";
import { createRequire } from "node:module";
import { tmpdir } from "node:os";
import path from "node:path";
import { promisify } from "node:util";
import { runInNewContext } from "node:vm";
import { expect, it } from "vitest";
import * as Runtime from "@vibeinging/dsh-red-alert";
import * as Invariant from "@vibeinging/dsh-red-alert/invariant";

const execFileAsync = promisify(execFile);

type ClientHandoff = {
  readonly id: string;
  readonly factory: (require: (specifier: string) => unknown) => Record<string, unknown>;
};

type ClientBootEntry = {
  readonly id: string;
  readonly packageJsonPath: string;
  readonly clientPath: string;
  readonly inject: readonly string[];
};

function browserPlatformRequire(specifier: string): unknown {
  return createRequire(import.meta.url)(specifier === "cordis" ? "@deepseek-ai/cordis" : specifier);
}

function discoverClientBootEntry(profileRequire: NodeRequire, packageName: string): ClientBootEntry {
  const packageJsonPath = profileRequire.resolve(`${packageName}/package.json`);
  const manifest = JSON.parse(readFileSync(packageJsonPath, "utf8")) as {
    readonly name: string;
    readonly dsh?: { readonly client?: { readonly platform?: string; readonly inject?: readonly string[] } };
  };
  if (manifest.name !== packageName || manifest.dsh?.client?.platform !== "web" || manifest.dsh.client.inject === undefined) {
    throw new Error(`${packageName} is not a web dsh.client package`);
  }
  const clientPath = profileRequire.resolve(`${packageName}/client`);
  return { id: packageName, packageJsonPath, clientPath, inject: manifest.dsh.client.inject };
}

it("loads the checked-in built DSH bundle and its declaration entry", () => {
  const manifest = JSON.parse(readFileSync(new URL("../package.json", import.meta.url), "utf8")) as {
    readonly name: string;
    readonly exports: { readonly ".": { readonly types: string }; readonly "./invariant": { readonly types: string }; readonly "./client": { readonly types: string; readonly default: string }; readonly "./package.json": string };
  };
  const builtRuntime = readFileSync(new URL("../lib/index.js", import.meta.url), "utf8");
  const builtInvariant = readFileSync(new URL("../lib/invariant.js", import.meta.url), "utf8");
  const builtClient = readFileSync(new URL("../lib/client.cjs", import.meta.url), "utf8");

  expect(Runtime.name).toBe("red-alert");
  expect(Invariant.name).toBe("red-alert-invariant");
  expect(manifest.exports["."].types).toBe("./lib/types/src/index.d.ts");
  expect(manifest.exports["./invariant"].types).toBe("./lib/types/src/invariant.d.ts");
  expect(manifest.exports["./client"].default).toBe("./lib/client.cjs");
  expect(manifest.exports["./package.json"]).toBe("./package.json");
  expect(builtClient).toContain("window.__ModuleLoader__.load");
  expect(builtClient).toContain('specifier === "@deepseek-ai/cordis" ? "cordis" : specifier');
  expect(existsSync(new URL("../lib/types/src/index.d.ts", import.meta.url))).toBe(true);
  expect(existsSync(new URL("../lib/types/src/invariant.d.ts", import.meta.url))).toBe(true);
  expect(`${builtRuntime}\n${builtInvariant}`).not.toMatch(/DshCommander|execFile|enemyStartLocation|敌基地方向/);

  let handoff: ClientHandoff | undefined;
  runInNewContext(builtClient, {
    window: {
      __ModuleLoader__: {
        load(value: ClientHandoff): void {
          handoff = value;
        },
      },
    },
  });
  expect(handoff?.id).toBe(manifest.name);
  if (handoff === undefined) throw new Error("built client did not register a DSH loader handoff");
  const clientExports = handoff.factory(browserPlatformRequire);
  expect(clientExports.inject).toEqual([
    "connection",
    "layout",
    "sessions",
    "slots",
  ]);
  expect(typeof clientExports.apply).toBe("function");
});

it("discovers the packed dual-face client from a Profile createRequire anchor", async () => {
  const temporaryRoot = await mkdtemp(path.join(tmpdir(), "dsh-red-alert-profile-"));
  try {
    const packageArchiveDirectory = path.join(temporaryRoot, "archive");
    const extractedDirectory = path.join(temporaryRoot, "extracted");
    const profileDirectory = path.join(temporaryRoot, "profile");
    await mkdir(packageArchiveDirectory, { recursive: true });
    await mkdir(extractedDirectory, { recursive: true });
    await mkdir(path.join(profileDirectory, "config"), { recursive: true });
    await execFileAsync("pnpm", ["pack", "--pack-destination", packageArchiveDirectory], { cwd: process.cwd() });
    const archiveName = readdirSync(packageArchiveDirectory).find((entry) => entry.endsWith(".tgz"));
    if (archiveName === undefined) throw new Error("pnpm pack did not create a package archive");
    await execFileAsync("tar", ["-xzf", path.join(packageArchiveDirectory, archiveName), "-C", extractedDirectory]);

    const packageDirectory = path.join(profileDirectory, "node_modules", "@vibeinging", "dsh-red-alert");
    await mkdir(path.dirname(packageDirectory), { recursive: true });
    await cp(path.join(extractedDirectory, "package"), packageDirectory, { recursive: true });

    const profileRequire = createRequire(path.join(profileDirectory, "config", "boot.mjs"));
    const bootEntry = discoverClientBootEntry(profileRequire, "@vibeinging/dsh-red-alert");
    const packedManifest = JSON.parse(readFileSync(bootEntry.packageJsonPath, "utf8")) as {
      readonly name: string;
      readonly private: boolean;
      readonly license: string;
      readonly publishConfig: { readonly access: string; readonly registry: string };
      readonly bin: {
        readonly "dsh-red-alert": string;
        readonly "dsh-red-alert-prepare-renderer": string;
        readonly "dsh-red-alert-setup": string;
      };
      readonly peerDependencies: Record<string, string>;
      readonly peerDependenciesMeta?: Record<string, { readonly optional: boolean }>;
      readonly dsh: {
        readonly bundle: { readonly patch: string };
        readonly client: { readonly platform: string; readonly inject: readonly string[] };
      };
      readonly exports: { readonly "./client": { readonly default: string } };
    };
    expect(packedManifest.name).toBe("@vibeinging/dsh-red-alert");
    expect(packedManifest.private).toBe(false);
    expect(packedManifest.license).toBe("GPL-3.0-only");
    expect(packedManifest.publishConfig).toEqual({ access: "public", registry: "https://registry.npmjs.org/" });
    expect(packedManifest.bin["dsh-red-alert"]).toBe("scripts/run-dsh.mjs");
    expect(packedManifest.bin["dsh-red-alert-prepare-renderer"]).toBe("scripts/prepare-compatible-renderer.mjs");
    expect(packedManifest.bin["dsh-red-alert-setup"]).toBe("scripts/setup-dsh.mjs");
    expect(packedManifest.peerDependencies).toEqual({ "@deepseek-ai/dsh": "0.1.1-rc.2" });
    expect(packedManifest.peerDependenciesMeta).toBeUndefined();
    expect(packedManifest.dsh.bundle.patch).toBe("./cordis.patch.yml");
    expect(packedManifest.dsh.client.platform).toBe("web");
    expect(existsSync(path.join(packageDirectory, "LICENSE"))).toBe(true);
    expect(existsSync(path.join(packageDirectory, "docs", "readme-media", "real-ai-battlefield.webp"))).toBe(true);
    expect(existsSync(path.join(packageDirectory, "docs", "reports", "2026-08-22_dsh-real-client-final-acceptance.md"))).toBe(true);
    expect(readFileSync(path.join(packageDirectory, "scripts", "run-dsh-args.mjs"), "utf8")).toContain('"--no-open"');
    expect(bootEntry.clientPath).toBe(await realpath(path.join(packageDirectory, "lib/client.cjs")));
    expect(packedManifest.exports["./client"].default).toBe("./lib/client.cjs");

    let handoff: ClientHandoff | undefined;
    runInNewContext(readFileSync(bootEntry.clientPath, "utf8"), {
      window: {
        __ModuleLoader__: {
          load(value: ClientHandoff): void {
            handoff = value;
          },
        },
      },
    });
    expect(handoff?.id).toBe(bootEntry.id);
    expect(bootEntry.inject).toEqual([
      "@deepseek-ai/dsh-client-connection",
      "@deepseek-ai/dsh-client-runtime",
      "@deepseek-ai/dsh-client-ui-layout",
      "@deepseek-ai/dsh-client-ui-conversation",
    ]);
    if (handoff === undefined) throw new Error("packed client did not register a DSH loader handoff");
    const clientExports = handoff.factory(browserPlatformRequire);
    expect(clientExports.inject).toEqual(["connection", "layout", "sessions", "slots"]);
    expect(typeof clientExports.BrowserAdapterRegistry).toBe("function");
    expect(typeof clientExports.BrowserCommandClientService).toBe("function");
  } finally {
    await rm(temporaryRoot, { recursive: true, force: true });
  }
});
