import { copyFileSync, mkdirSync, mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { describe, expect, test } from "vitest";

const root = path.resolve(import.meta.dirname, "..");
const setupScript = path.join(root, "scripts", "setup-dsh.mjs");

function runSetup(args: string[]) {
  return spawnSync(process.execPath, [setupScript, ...args], {
    cwd: root,
    encoding: "utf8",
  });
}

function runPnpmSetup(args: string[]) {
  return spawnSync("pnpm", ["run", "setup", "--", ...args], {
    cwd: root,
    encoding: "utf8",
  });
}

function runInstalledSetup(args: string[], dshHome: string) {
  const installedRoot = mkdtempSync(path.join(tmpdir(), "dsh-ra-installed-test-"));
  mkdirSync(path.join(installedRoot, "scripts"));
  copyFileSync(setupScript, path.join(installedRoot, "scripts", "setup-dsh.mjs"));
  copyFileSync(path.join(root, "scripts", "resource-download.mjs"), path.join(installedRoot, "scripts", "resource-download.mjs"));
  writeFileSync(path.join(installedRoot, "package.json"), `${JSON.stringify({
    name: "@vibeinging/dsh-red-alert",
    version: "0.1.2",
  }, null, 2)}\n`);
  return spawnSync(process.execPath, [path.join(installedRoot, "scripts", "setup-dsh.mjs"), ...args], {
    cwd: installedRoot,
    env: { ...process.env, DSH_HOME: dshHome },
    encoding: "utf8",
  });
}

describe("DSH setup command", () => {
  test("documents the existing Profile and asset boundaries", () => {
    const result = runSetup(["--help"]);

    expect(result.status).toBe(0);
    expect(result.stdout).toContain("published package or a source checkout");
    expect(result.stdout).toContain("does not install DSH");
    expect(result.stdout).toContain("--download-resources");
    expect(result.stdout).toContain("no Red Alert 2 game assets unless --download-resources");
    expect(result.stdout).toContain("https://download.ra2web.com/full-pack.7z");
    expect(result.stdout).toContain("no global Bun");
    expect(result.stdout).toContain("installation is required");
    expect(result.stdout).toContain("requires @deepseek-ai/dsh 0.1.1-rc.2");
  });

  test("rejects an unsafe Profile name before running commands", () => {
    const result = runSetup(["--profile", "../../profile", "--dry-run"]);

    expect(result.status).toBe(1);
    expect(result.stderr).toContain("profile must contain only");
    expect(result.stdout).not.toContain("> git --version");
  });

  test("prints a complete non-mutating plan", () => {
    const rendererDir = path.join(mkdtempSync(path.join(tmpdir(), "dsh-ra-setup-test-")), "renderer");
    const result = runPnpmSetup(["--profile", "showcase", "--renderer-dir", rendererDir, "--dry-run"]);

    expect(result.status).toBe(0);
    expect(result.stdout).toContain("Dry run. No files or Profile state will be changed.");
    expect(result.stdout).toContain("dsh --profile showcase --dump-default-config");
    expect(result.stdout).toContain("pnpm dlx bun@1.3.14 --version");
    expect(result.stdout).not.toContain("bun --version");
    expect(result.stdout).toContain(`prepare-compatible-renderer.mjs ${rendererDir}`);
    expect(result.stdout).toContain("dsh plugin --profile showcase add -w file:");
    expect(result.stdout).toContain("Would write");
    expect(result.stdout).toContain("RA_RENDERER_PORT=a stable free port selected from 4317-4367");
    expect(result.stdout).toContain("Would not download game resources");
  });

  test("prints the exact authorized resource plan without downloading in dry-run", () => {
    const rendererDir = path.join(mkdtempSync(path.join(tmpdir(), "dsh-ra-resource-plan-")), "renderer");
    const result = runSetup(["--profile", "web", "--renderer-dir", rendererDir, "--download-resources", "--dry-run"]);

    expect(result.status).toBe(0);
    expect(result.stdout).toContain("Would download https://download.ra2web.com/full-pack.7z");
    expect(result.stdout).toContain("3119b300794839ab597df556df8718c0a0a28fe89648ddced1c3790d801cb646");
    expect(result.stdout).toContain(path.join(rendererDir, "dist", "dsh-red-alert-resource.7z"));
    expect(result.stdout).not.toContain("Resource download requested");
  });

  test("reuses a verified renderer without requiring Git or Bun", () => {
    const rendererDir = path.join(mkdtempSync(path.join(tmpdir(), "dsh-ra-ready-renderer-")), "renderer");
    mkdirSync(path.join(rendererDir, "dist"), { recursive: true });
    writeFileSync(path.join(rendererDir, "dist", "index.html"), "renderer");
    writeFileSync(path.join(rendererDir, ".dsh-red-alert-renderer.json"), `${JSON.stringify({
      schema: "dsh-red-alert-renderer-v5",
      upstream: "https://github.com/huangkaoya/redalert2.git",
      commit: "8c07f1092b2a9e8d8605ed49ef46d77b6c3ea367",
    })}\n`);

    const result = runSetup(["--profile", "web", "--renderer-dir", rendererDir, "--dry-run"]);

    expect(result.status).toBe(0);
    expect(result.stdout).not.toContain("git --version");
    expect(result.stdout).not.toContain("bun@1.3.14");
    expect(result.stdout).not.toContain("prepare-compatible-renderer.mjs");
    expect(result.stdout).toContain("dsh plugin --profile web add");
  });

  test("prints an installed-package plan without rebuilding node_modules", () => {
    const temporaryRoot = mkdtempSync(path.join(tmpdir(), "dsh-ra-installed-plan-"));
    const dshHome = path.join(temporaryRoot, "dsh-home");
    const rendererDir = path.join(temporaryRoot, "renderer");
    const result = runInstalledSetup(["--profile", "web", "--renderer-dir", rendererDir, "--dry-run"], dshHome);

    expect(result.status).toBe(0);
    expect(result.stdout).toContain("dsh plugin --profile web add -w @vibeinging/dsh-red-alert@0.1.2 --save-exact --ignore-scripts");
    expect(result.stdout).toContain(path.join(dshHome, "red-alert", "install.json"));
    expect(result.stdout).not.toContain("pnpm install --frozen-lockfile");
    expect(result.stdout).not.toContain("pnpm run build");
    expect(result.stdout).toContain("RA_RENDERER_PORT=a stable free port selected from 4317-4367");
  });

  test("validates an explicit stable renderer port before running commands", () => {
    const result = runSetup(["--renderer-port", "70000", "--dry-run"]);

    expect(result.status).toBe(1);
    expect(result.stderr).toContain("--renderer-port requires an integer from 1 through 65535");
    expect(result.stdout).not.toContain("> git --version");
  });
});
