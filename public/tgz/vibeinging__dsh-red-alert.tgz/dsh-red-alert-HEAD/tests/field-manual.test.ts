import { describe, expect, it } from "vitest";

import {
  FIELD_MANUAL_FACTIONS,
  FIELD_MANUAL_TOPICS,
  createFieldManualPage,
} from "../src/field-manual.ts";

describe("red-alert field manual", () => {
  it("returns exact land and naval structure ids without mixing their roles", () => {
    const page = createFieldManualPage("manual-session", "structures", "soviet");
    const warFactory = page.entries.find(entry => entry.id === "NAWEAP");
    const shipyard = page.entries.find(entry => entry.id === "NAYARD");

    expect(page).toMatchObject({ version: 1, topic: "structures", faction: "soviet" });
    expect(warFactory).toMatchObject({ name: "Soviet War Factory", cost: 2000, role: "Land vehicle production" });
    expect(shipyard).toMatchObject({ name: "Soviet Shipyard", cost: 1000, role: "Naval production" });
    expect(page.rules.join(" ")).toContain("NAWEAP and GAWEAP are land war factories");
    expect(page.entries.some(entry => entry.faction === "allied")).toBe(false);
  });

  it("keeps pages bounded, faction filtered, and free of hidden live state", () => {
    for (const topic of FIELD_MANUAL_TOPICS) {
      for (const faction of FIELD_MANUAL_FACTIONS) {
        const page = createFieldManualPage("manual-session", topic, faction);
        expect(page.entries.length).toBeLessThanOrEqual(21);
        expect(JSON.stringify(page)).not.toMatch(/enemyStartLocation|hiddenUnits|rawWorld|fullMap/);
      }
    }
    const allied = createFieldManualPage("manual-session", "vehicles-air", "allied");
    expect(allied.entries.map(entry => entry.id)).toEqual(["MTNK", "FV", "MGTK", "SREF", "ORCA"]);
  });
});
