import { mkdtemp, rm, symlink, writeFile } from "node:fs/promises";
import { Writable } from "node:stream";
import type { IncomingMessage, ServerResponse } from "node:http";
import path from "node:path";
import { tmpdir } from "node:os";
import { describe, expect, it } from "vitest";
import { createRendererStaticHandler, resolveRendererDistDir } from "../src/renderer-host.ts";

class TestResponse extends Writable {
  headersSent = false;
  statusCode = 0;
  headers: Record<string, string | number> = {};
  readonly chunks: Buffer[] = [];

  writeHead(statusCode: number, headers: Record<string, string | number>): this {
    this.statusCode = statusCode;
    this.headers = headers;
    this.headersSent = true;
    return this;
  }

  _write(chunk: Buffer | string, _encoding: BufferEncoding, callback: (error?: Error) => void): void {
    this.chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
    callback();
  }

  text(): string {
    return Buffer.concat(this.chunks).toString("utf8");
  }
}

async function request(handler: ReturnType<typeof createRendererStaticHandler>, method: string, url: string, host = "localhost:60786"): Promise<TestResponse> {
  const response = new TestResponse();
  await handler({ method, url, headers: { host } } as IncomingMessage, response as unknown as ServerResponse);
  return response;
}

describe("renderer host static boundary", () => {
  it("serves only the configured renderer files with exact security headers", async () => {
    const root = await mkdtemp(path.join(tmpdir(), "dsh-red-alert-renderer-"));
    const outside = await mkdtemp(path.join(tmpdir(), "dsh-red-alert-outside-"));
    try {
      await writeFile(path.join(root, "index.html"), "real renderer entry");
      await writeFile(path.join(root, "app.js"), "console.log('renderer');");
      await writeFile(path.join(root, "app.js.map"), "{}\n");
      await writeFile(path.join(root, "config.ini"), "[renderer]\n");
      await writeFile(path.join(root, "ini.mix"), "mix");
      await writeFile(path.join(root, "general.csf"), "csf");
      await writeFile(path.join(root, "dsh-red-alert-resource.7z"), "archive");
      await writeFile(path.join(outside, "secret.js"), "secret renderer state");
      await symlink(path.join(outside, "secret.js"), path.join(root, "escape.js"));
      const handler = createRendererStaticHandler(root, "http://127.0.0.1:60786", "localhost:60786");
      const index = await request(handler, "GET", "/");
      expect(index.statusCode).toBe(200);
      expect(index.text()).toBe("real renderer entry");
      expect(index.headers["X-Content-Type-Options"]).toBe("nosniff");
      expect(index.headers["Content-Security-Policy"]).toContain("frame-ancestors http://127.0.0.1:60786");

      const head = await request(handler, "HEAD", "/app.js");
      expect(head.statusCode).toBe(200);
      expect(head.text()).toBe("");
      expect((await request(handler, "GET", "/config.ini")).headers["Content-Type"]).toBe("text/plain; charset=utf-8");
      expect((await request(handler, "GET", "/ini.mix")).headers["Content-Type"]).toBe("application/octet-stream");
      expect((await request(handler, "GET", "/general.csf")).headers["Content-Type"]).toBe("application/octet-stream");
      expect((await request(handler, "GET", "/dsh-red-alert-resource.7z")).headers["Content-Type"]).toBe("application/x-7z-compressed");

      const unknown = await request(handler, "GET", "/missing");
      expect(unknown.statusCode).toBe(404);
      expect(unknown.text()).not.toContain("real renderer entry");
      expect(unknown.headers["Content-Security-Policy"]).toContain("frame-ancestors http://127.0.0.1:60786");

      expect((await request(handler, "GET", "/app.js.map")).statusCode).toBe(404);
      expect((await request(handler, "GET", "/escape.js")).statusCode).toBe(404);
      expect((await request(handler, "GET", "/%2e%2e/secret.js")).statusCode).toBe(404);
      expect((await request(handler, "GET", "/%252e%252e/secret.js")).statusCode).toBe(404);
      expect((await request(handler, "GET", "/..\\secret.js")).statusCode).toBe(404);
      expect((await request(handler, "GET", "/%00secret.js")).statusCode).toBe(404);
      expect((await request(handler, "POST", "/")).statusCode).toBe(405);
      expect((await request(handler, "POST", "/")).headers["Content-Security-Policy"]).toContain("frame-ancestors");
      expect((await request(handler, "GET", "/", "127.0.0.1:60786")).statusCode).toBe(400);
      expect((await request(handler, "GET", "/", "localhost:60787")).statusCode).toBe(400);
      expect((await request(handler, "GET", "/", "")).statusCode).toBe(400);
    } finally {
      await rm(root, { recursive: true, force: true });
      await rm(outside, { recursive: true, force: true });
    }
  });

  it("rejects a renderer directory that is not absolute or does not exist", async () => {
    expect(() => resolveRendererDistDir("relative-renderer")).toThrow(/absolute/);
    expect(() => resolveRendererDistDir(path.join(tmpdir(), "missing-red-alert-renderer"))).toThrow(/existing directory/);
  });
});
