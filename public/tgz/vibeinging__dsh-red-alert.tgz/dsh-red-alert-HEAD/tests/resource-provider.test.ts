import { describe, expect, it, vi } from "vitest";
import {
  BrowserResourceProvider,
  CacheStorageResourceStorage,
  ResourceIntegrityError,
  selectRendererEntries,
  type ResourceStorage,
  type StoredResourceArchive,
} from "../src/client/resource-provider.ts";
import { resolveResourceArchiveDescriptor } from "../src/resource-config.ts";

class MemoryResourceStorage implements ResourceStorage {
  private readonly records = new Map<string, StoredResourceArchive>();

  async read(id: string): Promise<StoredResourceArchive | undefined> {
    return this.records.get(id);
  }

  async write(record: StoredResourceArchive): Promise<void> {
    this.records.set(record.id, record);
  }

  async remove(id: string): Promise<void> {
    this.records.delete(id);
  }
}

const bytes = new Uint8Array([1, 2, 3, 4]);
const descriptor = resolveResourceArchiveDescriptor({
  resourceArchiveUrl: "https://example.test/full-pack.7z",
  resourceArchiveSize: bytes.byteLength,
  resourceArchiveSha256: "a".repeat(64),
  resourceArchiveVersion: "test",
  resourceArchiveSourceLabel: "test source",
  resourceArchiveLicenseNotice: "test notice",
});

function responseFor(value: Uint8Array): Response {
  return new Response(new ArrayBuffer(value.byteLength), {
    status: 200,
    headers: { "content-length": String(value.byteLength), "content-type": "application/x-7z-compressed" },
  });
}

function provider(fetchImpl: typeof globalThis.fetch, storage = new MemoryResourceStorage()): BrowserResourceProvider {
  return new BrowserResourceProvider(descriptor, {
    storage,
    fetch: fetchImpl,
    digest: async () => "a".repeat(64),
    now: () => 123,
  });
}

describe("browser resource provider", () => {
  it("does not label a custom archive as the default public candidate", () => {
    const custom = resolveResourceArchiveDescriptor({
      resourceArchiveUrl: "https://example.test/custom.7z",
      resourceArchiveSize: 4,
      resourceArchiveSha256: "d".repeat(64),
    });
    expect(custom.sourceLabel).toBe("User-configured resource archive");
    expect(custom.version).toBe("custom");
  });

  it("uses the plugin-owned Cache Storage namespace", async () => {
    const records = new Map<string, Response>();
    const cache = {
      match: async (request: Request) => records.get(request.url),
      put: async (request: Request, response: Response) => { records.set(request.url, response); },
      delete: async (request: Request) => records.delete(request.url),
    } as unknown as Cache;
    const open = vi.fn(async (name: string) => {
      expect(name).toBe("dsh-red-alert-test-namespace");
      return cache;
    });
    const storage = new CacheStorageResourceStorage({ open } as unknown as CacheStorage, "dsh-red-alert-test-namespace");
    await storage.write({
      id: "test-resource",
      bytes: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),
      byteLength: bytes.byteLength,
      sha256: "a".repeat(64),
      storedAt: 123,
    });
    await expect(storage.read("test-resource")).resolves.toMatchObject({ id: "test-resource", byteLength: 4, sha256: "a".repeat(64) });
    expect(open).toHaveBeenCalledWith("dsh-red-alert-test-namespace");
  });

  it("does not fetch before an explicit import call and persists only verified bytes", async () => {
    const fetchImpl = vi.fn(async () => responseFor(bytes)) as unknown as typeof fetch;
    const storage = new MemoryResourceStorage();
    const instance = provider(fetchImpl, storage);
    expect(fetchImpl).not.toHaveBeenCalled();
    expect(await instance.status()).toEqual({ state: "missing" });
    expect(fetchImpl).not.toHaveBeenCalled();

    const progress: string[] = [];
    const imported = await instance.downloadAndVerify({ onProgress: (value) => progress.push(value.phase) });
    expect(imported).toMatchObject({ source: "network", byteLength: 4, sha256: "a".repeat(64), storedAt: 123 });
    expect(progress).toEqual(expect.arrayContaining(["downloading", "verifying", "storing"]));
    expect(await instance.status()).toEqual({ state: "ready", storedAt: 123 });
    expect(await instance.downloadAndVerify()).toMatchObject({ source: "cache" });
    expect(fetchImpl).toHaveBeenCalledTimes(1);
  });

  it("rejects size and hash failures without leaving an import", async () => {
    const wrongSize = new BrowserResourceProvider(descriptor, {
      storage: new MemoryResourceStorage(),
      fetch: (vi.fn(async () => responseFor(new Uint8Array([1, 2, 3]))) as unknown) as typeof fetch,
      digest: async () => "a".repeat(64),
    });
    await expect(wrongSize.downloadAndVerify()).rejects.toBeInstanceOf(ResourceIntegrityError);
    expect(await wrongSize.status()).toEqual({ state: "missing" });

    const wrongHash = new BrowserResourceProvider(descriptor, {
      storage: new MemoryResourceStorage(),
      fetch: (vi.fn(async () => responseFor(bytes)) as unknown) as typeof fetch,
      digest: async () => "b".repeat(64),
    });
    await expect(wrongHash.downloadAndVerify()).rejects.toThrow(/SHA-256/);
    expect(await wrongHash.status()).toEqual({ state: "missing" });
  });

  it("rejects a mismatched Content-Length before reading the response", async () => {
    let readCalled = false;
    const response = {
      ok: true,
      status: 200,
      headers: new Headers({ "content-length": "5" }),
      body: {
        getReader: () => {
          readCalled = true;
          throw new Error("response body should not be read");
        },
      },
    } as unknown as Response;
    const instance = provider(async () => response);
    await expect(instance.downloadAndVerify()).rejects.toThrow(/content-length mismatch/);
    expect(readCalled).toBe(false);
  });

  it("cancels a stream as soon as it exceeds the declared size", async () => {
    let readCalls = 0;
    let cancelCalled = false;
    const response = {
      ok: true,
      status: 200,
      headers: new Headers(),
      body: {
        getReader: () => ({
          read: async () => {
            readCalls += 1;
            return { done: false, value: new Uint8Array([1, 2, 3, 4, 5]) };
          },
          cancel: async () => {
            cancelCalled = true;
          },
          releaseLock: () => undefined,
        }),
      },
    } as unknown as Response;
    const instance = provider(async () => response);
    await expect(instance.downloadAndVerify()).rejects.toThrow(/exceeds declared size/);
    expect(cancelCalled).toBe(true);
    expect(readCalls).toBe(1);
  });

  it("checks the size after a body-less response is read", async () => {
    const response = {
      ok: true,
      status: 200,
      headers: new Headers(),
      body: null,
      arrayBuffer: async () => new ArrayBuffer(3),
    } as unknown as Response;
    const instance = provider(async () => response);
    await expect(instance.downloadAndVerify()).rejects.toThrow(/byte length mismatch/);
  });

  it("cancels an explicit download and can retry successfully", async () => {
    const controller = new AbortController();
    const blockedFetch = (async (_input: RequestInfo | URL, init?: RequestInit) => new Promise<Response>((_resolve, reject) => {
      if (init?.signal?.aborted) {
        const error = new Error("cancelled");
        error.name = "AbortError";
        reject(error);
        return;
      }
      init?.signal?.addEventListener("abort", () => {
        const error = new Error("cancelled");
        error.name = "AbortError";
        reject(error);
      }, { once: true });
    })) as typeof fetch;
    const instance = provider(blockedFetch);
    const pending = instance.downloadAndVerify({ signal: controller.signal });
    controller.abort();
    await expect(pending).rejects.toMatchObject({ name: "AbortError" });

    const retryFetch = vi.fn(async () => responseFor(bytes)) as unknown as typeof fetch;
    const retried = provider(retryFetch);
    await expect(retried.downloadAndVerify()).resolves.toMatchObject({ source: "network" });
    expect(retryFetch).toHaveBeenCalledTimes(1);
  });

  it("keeps the renderer allowlist free of music and executable assets", () => {
    expect(selectRendererEntries([
      "RA2.MIX",
      "language.mix",
      "multi.mix",
      "theme.mix",
      "Taunts/voice.aud",
      "movies/intro.vqa",
      "game.exe",
      "ddraw.dll",
      "maps/simple.map",
    ])).toEqual({
      selected: ["RA2.MIX", "language.mix", "multi.mix", "maps/simple.map"],
      excluded: ["theme.mix", "Taunts/voice.aud", "movies/intro.vqa", "game.exe", "ddraw.dll"],
      missing: [],
    });
  });
});
