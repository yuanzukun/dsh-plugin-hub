import { Service, type Context } from "@deepseek-ai/cordis";
import { BrowserRendererRuntime } from "./browser-renderer-runtime.ts";
import type { ClientConnectionRpc } from "@deepseek-ai/dsh-client-connection/client";
import type { ConnectionHandle } from "@deepseek-ai/dsh-client-connection/client";
import type { ISessions } from "@deepseek-ai/dsh-client-runtime/client";
import type { ObservableSnapshot } from "@deepseek-ai/dsh-client-runtime/client";
import {
  BROWSER_TRANSPORT_PROTOCOL_VERSION,
  RED_ALERT_BROWSER_CHANNEL,
  decodeBrowserCommandProjection,
  decodeBrowserCommandReceipt,
  decodeBrowserRendererConfigValue,
  decodeBrowserLeaseValue,
  type BrowserCommandEnvelope,
  type BrowserCommandReceipt,
  type BrowserLeaseValue,
  type BrowserRendererConfigValue,
} from "../browser-command-protocol.ts";

type CompatibleConnectionHandle = Omit<ConnectionHandle, "rpc"> & {
  readonly rpc?: ClientConnectionRpc;
};

type ClientSessionId = Parameters<ISessions["binding"]>[0];

/** Build the generic RPC caller for DSH Web releases predating connection.rpc. */
function createCompatibleWebRpc(): ClientConnectionRpc {
  return {
    async call(channel, endpoint, payload, signal) {
      if (!/^\/[A-Za-z0-9._~-]+$/.test(channel) || endpoint.split("/").some(segment => !/^[A-Za-z0-9_$.-]+$/.test(segment))) {
        throw new Error("red-alert connection RPC target is invalid");
      }
      const rpcId = crypto.randomUUID();
      const response = await fetch(new URL(`${channel}/${endpoint}`, window.location.origin), {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ type: "client-request", rpcId, method: endpoint, payload }),
        signal,
      });
      if (!response.ok) throw new Error(`red-alert connection RPC failed with HTTP ${response.status}`);
      const envelope: unknown = await response.json();
      if (!isRecord(envelope) || envelope.type !== "server-response" || envelope.rpcId !== rpcId || !isRecord(envelope.result) || typeof envelope.result.ok !== "boolean") {
        throw new Error("red-alert connection RPC returned an invalid envelope");
      }
      return envelope.result as unknown as Awaited<ReturnType<ClientConnectionRpc["call"]>>;
    },
  };
}

/** Minimum adapter seam owned by the plugin; real renderer code remains pending. */
export interface BrowserMatchAdapter {
  /**
   * Apply one safe command to the same browser game instance.
   *
   * The adapter must observe the signal and settle promptly after abort. Client
   * teardown waits for this promise before releasing the session lease, so a
   * renderer that ignores abort cannot be represented as quiescent.
   */
  command(command: BrowserCommandEnvelope, signal: AbortSignal): Promise<unknown>;
}

/** Registry used by the client root to attach a browser adapter without coupling it to a tab. */
export class BrowserAdapterRegistry {
  private readonly adapters = new Map<string, BrowserMatchAdapter>();
  private readonly listeners = new Set<() => void>();

  /** Register one adapter for one session; a different live adapter cannot take over. */
  register(sessionId: string, adapter: BrowserMatchAdapter): () => void {
    const existing = this.adapters.get(sessionId);
    if (existing !== undefined && existing !== adapter) throw new Error("red-alert browser adapter is already attached to this session");
    this.adapters.set(sessionId, adapter);
    this.changed();
    return () => {
      if (this.adapters.get(sessionId) !== adapter) return;
      this.adapters.delete(sessionId);
      this.changed();
    };
  }

  /** Resolve the adapter for a session without exposing any engine state. */
  get(sessionId: string): BrowserMatchAdapter | undefined {
    return this.adapters.get(sessionId);
  }

  /** Wait until the exact session adapter attaches, the deadline expires, or the caller aborts. */
  waitFor(sessionId: string, deadlineMs: number, signal: AbortSignal): Promise<BrowserMatchAdapter | undefined> {
    const existing = this.adapters.get(sessionId);
    if (existing !== undefined || signal.aborted || deadlineMs <= Date.now()) return Promise.resolve(existing);
    return new Promise((resolve) => {
      let timer: ReturnType<typeof setTimeout> | undefined;
      let settled = false;
      const finish = (adapter: BrowserMatchAdapter | undefined) => {
        if (settled) return;
        settled = true;
        if (timer !== undefined) clearTimeout(timer);
        this.listeners.delete(onChanged);
        signal.removeEventListener("abort", onAbort);
        resolve(adapter);
      };
      const onChanged = () => {
        const adapter = this.adapters.get(sessionId);
        if (adapter !== undefined) finish(adapter);
      };
      const onAbort = () => finish(undefined);
      this.listeners.add(onChanged);
      signal.addEventListener("abort", onAbort, { once: true });
      timer = setTimeout(() => finish(undefined), Math.max(1, deadlineMs - Date.now()));
      onChanged();
    });
  }

  /** Subscribe the root consumer to adapter attach/detach changes. */
  subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  /** Number of root consumers currently subscribed to registry changes. */
  get listenerCount(): number {
    return this.listeners.size;
  }

  private changed(): void {
    for (const listener of this.listeners) listener();
  }
}

export interface BrowserSessionIdentity {
  readonly sessionId: string;
  readonly matchId: string;
  readonly seat: string;
  readonly tick: number;
}

interface InFlightReceipt {
  readonly command: BrowserCommandEnvelope;
  readonly controller: AbortController;
  readonly generation: number;
  promise: Promise<void>;
  receiptPromise?: Promise<void>;
  receipt?: BrowserCommandReceipt;
  cancelled: boolean;
}

interface LeaseRequest {
  readonly sessionId: string;
  readonly generation: number;
  readonly controller: AbortController;
  readonly promise: Promise<BrowserLeaseValue>;
}

interface ClientSessionFace {
  readonly projections: {
    faceOf(key: string): ObservableSnapshot<unknown>;
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function safeIdentity(value: unknown): value is BrowserSessionIdentity {
  if (!isRecord(value)) return false;
  const failure = isRecord(value.failure) ? value.failure : undefined;
  const recoverableError = value.status === "error" && failure?.recoverable === true;
  const recoverableCreatingError = recoverableError && failure.phase === "creating";
  const identity = value.status === "creating" || recoverableCreatingError ? value.identity : value.match;
  if (!isRecord(identity)) return false;
  return typeof value.sessionId === "string"
    && value.sessionId.length > 0
    && typeof identity.matchId === "string"
    && identity.matchId.length > 0
    && typeof identity.seat === "string"
    && identity.seat.length > 0
    && typeof identity.tick === "number"
    && Number.isSafeInteger(identity.tick)
    && identity.tick >= 0
    && (value.status === "creating" || recoverableCreatingError || ((value.status === "running" || recoverableError) && identity.status === "active"));
}

function readIdentity(sessionId: string, value: unknown): BrowserSessionIdentity | undefined {
  if (!safeIdentity({ sessionId, ...(isRecord(value) ? value : {}) })) return undefined;
  const state = value as { readonly status: string; readonly failure?: { readonly phase?: string }; readonly identity?: { readonly matchId: string; readonly seat: string; readonly tick: number }; readonly match?: { readonly matchId: string; readonly seat: string; readonly tick: number } };
  const identity = state.status === "creating" || (state.status === "error" && state.failure?.phase === "creating") ? state.identity! : state.match!;
  return { sessionId, matchId: identity.matchId, seat: identity.seat, tick: identity.tick };
}

/** Read the browser-only mount budget without adding scheduler data to game commands. */
function readAdapterAttachTimeoutMs(value: unknown): number | undefined {
  if (!isRecord(value) || !isRecord(value.view) || !isRecord(value.view.renderer)) return undefined;
  const timeoutMs = value.view.renderer.adapterAttachTimeoutMs;
  return typeof timeoutMs === "number" && Number.isSafeInteger(timeoutMs) && timeoutMs > 0
    ? timeoutMs
    : undefined;
}

function boundedFailureDetail(_error: unknown): string {
  return "browser adapter command failed";
}

/** Error used by the client consumer after the official RPC result is decoded. */
export class BrowserCommandClientError extends Error {
  constructor(readonly code: string, message: string) {
    super(message);
    this.name = "BrowserCommandClientError";
  }
}

/**
 * Root client consumer. It follows the current DSH session and command
 * projection even when no red-alert tab is mounted.
 */
export class BrowserCommandClientConsumer {
  private readonly rpc: ClientConnectionRpc;
  private readonly sessions: ISessions;
  readonly adapters: BrowserAdapterRegistry;
  private readonly clientInstanceId: string;
  private readonly processed = new Map<string, string>();
  private readonly inFlight = new Map<string, InFlightReceipt>();
  private listDisposer: (() => void) | undefined;
  private commandDisposer: (() => void) | undefined;
  private stateDisposer: (() => void) | undefined;
  private adapterDisposer: (() => void) | undefined;
  private sessionId: string | undefined;
  private commandFace: ObservableSnapshot<unknown> | undefined;
  private stateFace: ObservableSnapshot<unknown> | undefined;
  private lease: BrowserLeaseValue | undefined;
  private leaseRequest: LeaseRequest | undefined;
  private readonly leaseDrains = new Map<string, Promise<void>>();
  private generation = 0;
  private started = false;
  private disposed = false;
  private disposePromise: Promise<void> | undefined;

  constructor(options: {
    readonly rpc: ClientConnectionRpc;
    readonly sessions: ISessions;
    readonly adapters?: BrowserAdapterRegistry;
    readonly clientInstanceId?: string;
  }) {
    if (options.clientInstanceId !== undefined && options.clientInstanceId.length === 0) throw new BrowserCommandClientError("CONFIG", "clientInstanceId must not be empty");
    this.rpc = options.rpc;
    this.sessions = options.sessions;
    this.adapters = options.adapters ?? new BrowserAdapterRegistry();
    this.clientInstanceId = options.clientInstanceId ?? globalThis.crypto?.randomUUID?.() ?? `browser-${Date.now()}-${Math.random()}`;
  }

  /** Begin following the current session and adapter registry. */
  start(): void {
    if (this.disposed) throw new BrowserCommandClientError("DISPOSED", "browser command consumer is disposed");
    if (this.started) return;
    this.started = true;
    this.listDisposer = this.sessions.list.subscribe(() => this.syncSession());
    this.adapterDisposer = this.adapters.subscribe(() => { void this.reconcile(); });
    this.syncSession();
  }

  /** Re-read the current projection after a Connection reconnect. */
  reconcile(): Promise<void> {
    return this.reconcileInternal();
  }

  /** Release subscriptions, adapter work and the current Host lease. */
  dispose(): Promise<void> {
    if (this.disposePromise !== undefined) return this.disposePromise;
    this.disposePromise = this.disposeInternal();
    return this.disposePromise;
  }

  private async disposeInternal(): Promise<void> {
    this.disposed = true;
    this.generation += 1;
    const leaseDrains = [...this.leaseDrains.values(), this.abortLeaseRequest()];
    this.listDisposer?.();
    this.listDisposer = undefined;
    this.commandDisposer?.();
    this.commandDisposer = undefined;
    this.stateDisposer?.();
    this.stateDisposer = undefined;
    this.adapterDisposer?.();
    this.adapterDisposer = undefined;
    const sessionId = this.sessionId;
    const lease = this.lease;
    if (sessionId !== undefined && lease !== undefined) await this.cancelRequests(sessionId, lease);
    if (lease !== undefined) await this.releaseLease(lease);
    await Promise.all(leaseDrains);
    this.lease = undefined;
    this.sessionId = undefined;
    this.commandFace = undefined;
    this.stateFace = undefined;
    this.processed.clear();
  }

  private syncSession(): void {
    if (this.disposed) return;
    const next = this.sessions.list.getSnapshot().current;
    const nextId = next === undefined ? undefined : String(next);
    if (nextId === this.sessionId && this.commandFace !== undefined) {
      void this.reconcile();
      return;
    }
    const oldId = this.sessionId;
    const oldLease = this.lease;
    void this.abortLeaseRequest();
    this.generation += 1;
    this.commandDisposer?.();
    this.commandDisposer = undefined;
    this.stateDisposer?.();
    this.stateDisposer = undefined;
    this.commandFace = undefined;
    this.stateFace = undefined;
    this.sessionId = nextId;
    this.lease = undefined;
    if (oldId !== undefined && oldId !== nextId) this.processed.delete(oldId);
    if (oldId !== undefined && oldLease !== undefined) {
      this.enqueueLeaseDrain(oldId, this.cancelRequests(oldId, oldLease).then(() => this.releaseLease(oldLease)));
    }
    if (nextId === undefined) return;
    const binding = this.sessions.binding(nextId as ClientSessionId);
    if (binding === undefined) return;
    const face = binding.session as unknown as ClientSessionFace;
    this.stateFace = face.projections.faceOf("redAlert");
    this.commandFace = face.projections.faceOf("redAlertCommand");
    this.stateDisposer = this.stateFace.subscribe(() => { void this.reconcile(); });
    this.commandDisposer = this.commandFace.subscribe(() => { void this.reconcile(); });
    void this.reconcile();
  }

  private async reconcileInternal(): Promise<void> {
    if (this.disposed || this.sessionId === undefined || this.commandFace === undefined || this.stateFace === undefined) return;
    const sessionId = this.sessionId;
    const generation = this.generation;
    const stateValue = this.stateFace.getSnapshot();
    const identity = readIdentity(sessionId, stateValue);
    if (identity === undefined) {
      if (this.lease !== undefined) {
        const lease = this.lease;
        this.lease = undefined;
        await this.releaseLease(lease);
      }
      return;
    }
    const projectionValue = this.commandFace.getSnapshot();
    let projection;
    try {
      projection = decodeBrowserCommandProjection(projectionValue);
    } catch {
      return;
    }
    if (projection.status !== "pending") {
      this.processed.delete(sessionId);
      return;
    }
    const command = projection.command;
    if (command.sessionId !== sessionId || command.matchId !== identity.matchId || command.seat !== identity.seat || command.expectedTick > identity.tick) return;
    try {
      const lease = await this.ensureLease(identity);
      if (this.disposed || this.generation !== generation || this.sessionId !== sessionId) return;
      await this.execute(command, lease, generation, readAdapterAttachTimeoutMs(stateValue));
    } catch {
      // A reconnect or an adapter registration will re-run reconcile. No raw
      // transport or engine error is surfaced through the client projection.
    }
  }

  /** Read live loopback renderer config through the current leased Connection. */
  async rendererConfig(identity: BrowserSessionIdentity): Promise<BrowserRendererConfigValue> {
    if (this.disposed || this.sessionId !== identity.sessionId) throw new BrowserCommandClientError("STALE_SESSION", "renderer configuration belongs to an inactive session");
    const generation = this.generation;
    const lease = await this.ensureLease(identity);
    if (this.disposed || this.sessionId !== identity.sessionId || this.generation !== generation) throw new BrowserCommandClientError("STALE_SESSION", "renderer configuration belongs to an inactive connection");
    const result = await this.rpc.call("/red-alert", "renderer/config", {
      protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
      sessionId: identity.sessionId,
      matchId: identity.matchId,
      seat: identity.seat,
      leaseToken: lease.leaseToken,
    });
    if (!result.ok) throw new BrowserCommandClientError(result.error.code, result.error.message);
    if (this.disposed || this.sessionId !== identity.sessionId || this.generation !== generation || this.lease !== lease) throw new BrowserCommandClientError("STALE_SESSION", "renderer configuration belongs to an inactive connection");
    const config = decodeBrowserRendererConfigValue(result.value);
    if (config.sessionId !== identity.sessionId || config.matchId !== identity.matchId || config.seat !== identity.seat) throw new BrowserCommandClientError("IDENTITY", "renderer configuration does not match the current session");
    return config;
  }

  private async ensureLease(identity: BrowserSessionIdentity): Promise<BrowserLeaseValue> {
    if (this.lease !== undefined && this.lease.sessionId === identity.sessionId && this.lease.matchId === identity.matchId && this.lease.seat === identity.seat) return this.lease;
    if (this.lease !== undefined) {
      const staleLease = this.lease;
      this.lease = undefined;
      await this.releaseLease(staleLease);
      if (this.disposed || this.sessionId !== identity.sessionId) {
        throw new BrowserCommandClientError("STALE_LEASE", "browser lease identity changed after the session became inactive");
      }
    }
    const drain = this.leaseDrains.get(identity.sessionId);
    if (drain !== undefined) {
      await drain;
      if (this.disposed || this.sessionId !== identity.sessionId) throw new BrowserCommandClientError("STALE_LEASE", "browser lease request belongs to an inactive session");
    }
    const activeRequest = this.leaseRequest;
    if (activeRequest !== undefined) {
      if (activeRequest.sessionId === identity.sessionId && activeRequest.generation === this.generation) return activeRequest.promise;
      void this.abortLeaseRequest();
    }
    const generation = this.generation;
    const sessionId = identity.sessionId;
    const controller = new AbortController();
    let promise!: Promise<BrowserLeaseValue>;
    promise = (async () => {
      const result = await this.rpc.call(RED_ALERT_BROWSER_CHANNEL, "lease/register", {
        protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
        sessionId: identity.sessionId,
        matchId: identity.matchId,
        seat: identity.seat,
        clientInstanceId: this.clientInstanceId,
      }, controller.signal);
      if (!result.ok) throw new BrowserCommandClientError(result.error.code, result.error.message);
      const lease = decodeBrowserLeaseValue(result.value);
      if (lease.sessionId !== identity.sessionId || lease.matchId !== identity.matchId || lease.seat !== identity.seat) throw new BrowserCommandClientError("IDENTITY", "browser lease response does not match the current session");
      if (controller.signal.aborted || this.disposed || this.generation !== generation || this.sessionId !== sessionId) {
        await this.releaseLease(lease);
        throw new BrowserCommandClientError("STALE_LEASE", "browser lease response belongs to an inactive session");
      }
      this.lease = lease;
      return lease;
    })().finally(() => {
      if (this.leaseRequest?.promise === promise) this.leaseRequest = undefined;
    });
    this.leaseRequest = { sessionId, generation, controller, promise };
    return promise;
  }

  private abortLeaseRequest(): Promise<void> {
    const request = this.leaseRequest;
    if (request === undefined) return Promise.resolve();
    this.leaseRequest = undefined;
    request.controller.abort();
    const drain = request.promise.then(() => undefined, () => undefined);
    return this.enqueueLeaseDrain(request.sessionId, drain);
  }

  private enqueueLeaseDrain(sessionId: string, drain: Promise<void>): Promise<void> {
    const prior = this.leaseDrains.get(sessionId);
    const combined = prior === undefined ? drain : prior.then(() => drain, () => drain);
    this.leaseDrains.set(sessionId, combined);
    void combined.then(() => {
      if (this.leaseDrains.get(sessionId) === combined) this.leaseDrains.delete(sessionId);
    });
    return combined;
  }

  private async execute(command: BrowserCommandEnvelope, lease: BrowserLeaseValue, generation: number, adapterAttachTimeoutMs?: number): Promise<void> {
    const key = `${command.sessionId}:${command.requestId}`;
    const current = this.inFlight.get(key);
    if (current !== undefined) {
      try {
        await current.promise;
      } catch {
        if (current.receipt !== undefined) await this.sendReceiptOnce(current, lease, generation);
      }
      return;
    }
    if (this.processed.get(command.sessionId) === command.requestId) return;
    const controller = new AbortController();
    const inFlight: InFlightReceipt = { command, controller, generation, promise: Promise.resolve(), cancelled: false };
    this.inFlight.set(key, inFlight);
    inFlight.promise = this.perform(inFlight, lease, generation, adapterAttachTimeoutMs);
    await inFlight.promise;
  }

  private async perform(inFlight: InFlightReceipt, lease: BrowserLeaseValue, generation: number, adapterAttachTimeoutMs?: number): Promise<void> {
    const { command, controller } = inFlight;
    if (inFlight.cancelled) {
      inFlight.receipt = this.failureReceipt(command, "CLIENT_DISPOSED", "browser client session was disposed");
    } else {
      let adapter = this.adapters.get(command.sessionId);
      if (adapter === undefined && adapterAttachTimeoutMs !== undefined) {
        adapter = await this.adapters.waitFor(command.sessionId, Date.now() + adapterAttachTimeoutMs, controller.signal);
      }
      if (inFlight.cancelled || controller.signal.aborted) {
        inFlight.receipt = this.failureReceipt(command, "CLIENT_DISPOSED", "browser client session was disposed");
      } else if (adapter === undefined) {
        inFlight.receipt = this.failureReceipt(command, "ADAPTER_UNAVAILABLE", "browser renderer adapter was not attached before the command deadline");
      } else {
        try {
          const candidate = decodeBrowserCommandReceipt(await adapter.command(command, controller.signal));
          inFlight.receipt = inFlight.cancelled
            ? this.failureReceipt(command, "CLIENT_DISPOSED", "browser client session was disposed")
            : this.validateReceipt(command, candidate);
        } catch (error) {
          inFlight.receipt = this.failureReceipt(command, inFlight.cancelled ? "CLIENT_DISPOSED" : "ADAPTER_COMMAND_FAILED", inFlight.cancelled ? "browser client session was disposed" : boundedFailureDetail(error));
        }
      }
    }
    await this.sendReceiptOnce(inFlight, lease, generation);
  }

  private validateReceipt(command: BrowserCommandEnvelope, receipt: BrowserCommandReceipt): BrowserCommandReceipt {
    if (receipt.requestId !== command.requestId || receipt.sessionId !== command.sessionId || receipt.matchId !== command.matchId || receipt.seat !== command.seat || receipt.tick < command.expectedTick) throw new BrowserCommandClientError("IDENTITY", "browser adapter receipt does not match the command");
    return receipt;
  }

  private failureReceipt(command: BrowserCommandEnvelope, code: string, detail: string): BrowserCommandReceipt {
    return {
      protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
      requestId: command.requestId,
      sessionId: command.sessionId,
      matchId: command.matchId,
      seat: command.seat,
      tick: command.expectedTick,
      ok: false,
      detail: `${code}: ${detail}`.slice(0, 512),
    };
  }

  private async sendReceipt(inFlight: InFlightReceipt, lease: BrowserLeaseValue, generation: number): Promise<void> {
    if (this.disposed || this.generation !== generation || this.sessionId !== inFlight.command.sessionId) return;
    const receipt = inFlight.receipt;
    if (receipt === undefined) return;
    const result = await this.rpc.call(RED_ALERT_BROWSER_CHANNEL, "receipt", { ...receipt, leaseToken: lease.leaseToken }, inFlight.controller.signal);
    if (!result.ok) throw new BrowserCommandClientError(result.error.code, result.error.message);
    this.processed.set(inFlight.command.sessionId, inFlight.command.requestId);
    this.inFlight.delete(`${inFlight.command.sessionId}:${inFlight.command.requestId}`);
  }

  private sendReceiptOnce(inFlight: InFlightReceipt, lease: BrowserLeaseValue, generation: number): Promise<void> {
    const active = inFlight.receiptPromise;
    if (active !== undefined) return active;
    const promise = this.sendReceipt(inFlight, lease, generation).finally(() => {
      if (inFlight.receiptPromise === promise) inFlight.receiptPromise = undefined;
    });
    inFlight.receiptPromise = promise;
    return promise;
  }

  private async cancelRequests(sessionId: string, lease: BrowserLeaseValue): Promise<void> {
    const entries = [...this.inFlight.values()].filter((entry) => entry.command.sessionId === sessionId);
    await Promise.allSettled(entries.map(async (entry) => {
      entry.cancelled = true;
      entry.controller.abort();
      const receipt = entry.receipt ?? this.failureReceipt(entry.command, "CLIENT_DISPOSED", "browser client session was disposed");
      entry.receipt = receipt;
      const result = await this.rpc.call(RED_ALERT_BROWSER_CHANNEL, "receipt", { ...receipt, leaseToken: lease.leaseToken });
      if (result.ok) this.processed.set(entry.command.sessionId, entry.command.requestId);
    }));
    await Promise.allSettled(entries.map((entry) => entry.promise));
    for (const entry of entries) this.inFlight.delete(`${entry.command.sessionId}:${entry.command.requestId}`);
  }

  private async releaseLease(lease: BrowserLeaseValue): Promise<void> {
    try {
      await this.rpc.call(RED_ALERT_BROWSER_CHANNEL, "lease/release", {
        protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
        sessionId: lease.sessionId,
        leaseToken: lease.leaseToken,
      });
    } catch {
      // The Host may already have disposed the lease; no client state can be
      // recovered from this best-effort release path.
    }
  }
}

/** Client service wrapper; its lifetime is independent from any red-alert React view. */
export class BrowserCommandClientService extends Service {
  static inject = ["connection", "sessions"];
  readonly consumer: BrowserCommandClientConsumer;
  readonly adapters: BrowserAdapterRegistry;
  readonly renderer: BrowserRendererRuntime;
  private disposePromise: Promise<void> | undefined;
  private rendererSessionCleanup: Promise<void> = Promise.resolve();
  private readonly rendererSessionErrors: Error[] = [];
  private readonly rendererBootstraps = new Map<string, Promise<void>>();
  private readonly rendererBootstrapContainers = new Map<string, HTMLDivElement>();

  constructor(ctx: Context, options?: { readonly rpc: ClientConnectionRpc; readonly sessions: ISessions; readonly clientInstanceId?: string }) {
    super(ctx, "redAlertBrowserCommands");
    const client = ctx as Context & { readonly connection: CompatibleConnectionHandle; readonly sessions: ISessions };
    const resolved = options ?? { rpc: client.connection.rpc ?? createCompatibleWebRpc(), sessions: client.sessions };
    this.adapters = new BrowserAdapterRegistry();
    this.consumer = new BrowserCommandClientConsumer({ ...resolved, adapters: this.adapters });
    this.renderer = new BrowserRendererRuntime(this.adapters);
    this.consumer.start();
    ctx.on("connection/reset", () => {
      void this.consumer.reconcile().catch(() => ctx.logger.error(new Error("red-alert browser reconnect reconciliation failed")));
    });
    let previousSession: string | undefined;
    ctx.effect(() => {
      const syncRendererSession = () => {
        const current = resolved.sessions.list.getSnapshot().current;
        const currentSession = current === undefined ? undefined : String(current);
        const oldSession = previousSession;
        previousSession = currentSession;
        if (oldSession === undefined || oldSession === currentSession) return;
        const cleanup = this.rendererSessionCleanup.then(
          () => this.renderer.removeSession(oldSession),
          () => this.renderer.removeSession(oldSession),
        ).finally(() => {
          this.rendererBootstrapContainers.get(oldSession)?.remove();
          this.rendererBootstrapContainers.delete(oldSession);
        });
        this.rendererSessionCleanup = cleanup.then(
          () => undefined,
          () => {
            this.rendererSessionErrors.push(new BrowserCommandClientError("RENDERER_CLEANUP_FAILED", "red-alert renderer session cleanup failed"));
          },
        );
      };
      const disposer = resolved.sessions.list.subscribe(syncRendererSession);
      syncRendererSession();
      return () => disposer();
    }, "red-alert renderer session lifecycle");
    ctx.effect(() => {
      let stateDisposer: (() => void) | undefined;
      let boundSession: string | undefined;
      const bindCurrentState = () => {
        const current = resolved.sessions.list.getSnapshot().current;
        const sessionId = current === undefined ? undefined : String(current);
        if (sessionId === boundSession) return;
        stateDisposer?.();
        stateDisposer = undefined;
        boundSession = sessionId;
        if (sessionId === undefined) return;
        const binding = resolved.sessions.binding(sessionId as ClientSessionId);
        if (binding === undefined) return;
        const face = (binding.session as unknown as ClientSessionFace).projections.faceOf("redAlert");
        const sync = () => {
          const identity = readIdentity(sessionId, face.getSnapshot());
          if (identity === undefined) return;
          void this.ensureRenderer(identity).catch(() => ctx.logger.error(new Error("red-alert renderer bootstrap failed")));
        };
        stateDisposer = face.subscribe(sync);
        sync();
      };
      const listDisposer = resolved.sessions.list.subscribe(bindCurrentState);
      bindCurrentState();
      return () => {
        stateDisposer?.();
        listDisposer();
      };
    }, "red-alert renderer authority bootstrap");
    ctx.effect(() => async () => {
      await this.dispose();
    }, "red-alert browser command client");
  }

  /** Resolve the live loopback renderer endpoint for the current leased session. */
  rendererConfig(identity: BrowserSessionIdentity): Promise<BrowserRendererConfigValue> {
    return this.consumer.rendererConfig(identity);
  }

  /** Ensure the real renderer exists even while the user is on the Chat tab. */
  ensureRenderer(identity: BrowserSessionIdentity): Promise<void> {
    const active = this.rendererBootstraps.get(identity.sessionId);
    if (active !== undefined) return active;
    const bootstrap = this.ensureRendererInternal(identity).finally(() => {
      if (this.rendererBootstraps.get(identity.sessionId) === bootstrap) this.rendererBootstraps.delete(identity.sessionId);
    });
    this.rendererBootstraps.set(identity.sessionId, bootstrap);
    return bootstrap;
  }

  private async ensureRendererInternal(identity: BrowserSessionIdentity): Promise<void> {
    const existing = this.renderer.get(identity.sessionId);
    if (existing !== undefined && existing.state === "ready" && this.renderer.matchesIdentity(identity.sessionId, identity)) return;
    if (existing === undefined) {
      const config = await this.rendererConfig(identity);
      if (this.renderer.get(identity.sessionId) === undefined) {
        this.renderer.registerLoopback(identity.sessionId, {
          url: config.url,
          parentOrigin: window.location.origin,
          origin: { allowLoopback: true, loopbackPort: config.port },
        });
      }
    }
    let container = this.rendererBootstrapContainers.get(identity.sessionId);
    if (container === undefined) {
      container = document.createElement("div");
      container.setAttribute("data-red-alert-renderer-bootstrap", "root-owned");
      container.style.position = "fixed";
      container.style.left = "-10000px";
      container.style.top = "0";
      container.style.width = "1280px";
      container.style.height = "720px";
      container.style.visibility = "hidden";
      document.body.append(container);
      this.rendererBootstrapContainers.set(identity.sessionId, container);
    }
    await this.renderer.attach(identity.sessionId, container, identity);
  }

  /** Release the root consumer explicitly for tests and host lifecycle teardown. */
  dispose(): Promise<void> {
    if (this.disposePromise !== undefined) return this.disposePromise;
    this.disposePromise = (async () => {
      const errors: unknown[] = [];
      try {
        await this.consumer.dispose();
      } catch (error) {
        errors.push(error);
      }
      try {
        await this.rendererSessionCleanup;
      } catch (error) {
        errors.push(error);
      }
      await Promise.allSettled(this.rendererBootstraps.values());
      errors.push(...this.rendererSessionErrors);
      try {
        await this.renderer.dispose();
      } catch (error) {
        errors.push(error);
      }
      for (const container of this.rendererBootstrapContainers.values()) container.remove();
      this.rendererBootstrapContainers.clear();
      if (errors.length === 1) throw errors[0];
      if (errors.length > 1) throw new AggregateError(errors, "red-alert browser renderer disposal failed");
    })();
    return this.disposePromise;
  }
}
