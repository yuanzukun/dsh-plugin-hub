/**
 * Browser-side resource acquisition for an explicitly requested renderer import.
 * The provider stores only the verified archive; it never starts a download on construction.
 */

import {
  resolveResourceArchiveDescriptor,
  type ResourceArchiveConfig,
  type ResourceArchiveDescriptor,
} from "../resource-config.ts";

export { DEFAULT_RESOURCE_ARCHIVE, resolveResourceArchiveDescriptor } from "../resource-config.ts";
export type { ResourceArchiveConfig, ResourceArchiveDescriptor } from "../resource-config.ts";

export interface StoredResourceArchive {
  readonly id: string;
  readonly bytes: ArrayBuffer;
  readonly byteLength: number;
  readonly sha256: string;
  readonly storedAt: number;
}

/** Storage seam used by the provider so browser persistence is testable without a second database. */
export interface ResourceStorage {
  read(id: string): Promise<StoredResourceArchive | undefined>;
  write(record: StoredResourceArchive): Promise<void>;
  remove(id: string): Promise<void>;
}

/** A Cache Storage implementation suitable for the DSH browser client. */
export class CacheStorageResourceStorage implements ResourceStorage {
  private readonly cacheStorage: CacheStorage;
  private readonly cacheName: string;

  constructor(cacheStorage: CacheStorage, cacheName = "dsh-red-alert-resources-v1") {
    this.cacheStorage = cacheStorage;
    this.cacheName = cacheName;
  }

  async read(id: string): Promise<StoredResourceArchive | undefined> {
    const cache = await this.cacheStorage.open(this.cacheName);
    const response = await cache.match(this.cacheKey(id));
    if (response === undefined) return undefined;
    const bytes = await response.arrayBuffer();
    return {
      id: response.headers.get("x-ra-resource-id") ?? id,
      bytes,
      byteLength: Number(response.headers.get("x-ra-byte-length") ?? bytes.byteLength),
      sha256: response.headers.get("x-ra-sha256") ?? "",
      storedAt: Number(response.headers.get("x-ra-stored-at") ?? 0),
    };
  }

  async write(record: StoredResourceArchive): Promise<void> {
    const cache = await this.cacheStorage.open(this.cacheName);
    const response = new Response(new Uint8Array(record.bytes), {
      headers: {
        "content-type": "application/x-7z-compressed",
        "x-ra-resource-id": record.id,
        "x-ra-byte-length": String(record.byteLength),
        "x-ra-sha256": record.sha256,
        "x-ra-stored-at": String(record.storedAt),
      },
    });
    await cache.put(this.cacheKey(record.id), response);
  }

  async remove(id: string): Promise<void> {
    const cache = await this.cacheStorage.open(this.cacheName);
    await cache.delete(this.cacheKey(id));
  }

  private cacheKey(id: string): Request {
    return new Request(`https://dsh-red-alert.invalid/resources/${encodeURIComponent(id)}`);
  }
}

export type ResourceProviderStatus =
  | { readonly state: "missing" }
  | { readonly state: "invalid"; readonly reason: string }
  | { readonly state: "ready"; readonly storedAt: number };

export interface ResourceImportResult {
  readonly source: "cache" | "network";
  readonly resourceId: string;
  readonly byteLength: number;
  readonly sha256: string;
  readonly storedAt: number;
}

export interface ResourceDownloadProgress {
  readonly phase: "downloading" | "verifying" | "storing";
  readonly receivedBytes: number;
  readonly totalBytes: number;
  readonly percent: number;
}

export interface ResourceDownloadOptions {
  readonly signal?: AbortSignal;
  readonly onProgress?: (progress: ResourceDownloadProgress) => void;
}

export interface ResourceProviderOptions {
  readonly storage: ResourceStorage;
  readonly fetch?: typeof fetch;
  readonly digest?: (bytes: ArrayBuffer) => Promise<string>;
  readonly now?: () => number;
}

/** Build a browser provider from the plugin's public archive configuration. */
export function createBrowserResourceProvider(
  config: ResourceArchiveConfig = {},
  options?: Omit<ResourceProviderOptions, "storage"> & { readonly cacheStorage?: CacheStorage; readonly cacheName?: string },
): BrowserResourceProvider | undefined {
  const cacheStorage = options?.cacheStorage ?? globalThis.caches;
  if (cacheStorage === undefined) return undefined;
  return new BrowserResourceProvider(resolveResourceArchiveDescriptor(config), {
    storage: new CacheStorageResourceStorage(cacheStorage, options?.cacheName),
    fetch: options?.fetch,
    digest: options?.digest,
    now: options?.now,
  });
}

/** Raised when a downloaded or cached archive does not match its declared descriptor. */
export class ResourceIntegrityError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ResourceIntegrityError";
  }
}

function throwIfAborted(signal: AbortSignal | undefined): never | void {
  if (signal === undefined || !signal.aborted) return;
  const error = signal.reason instanceof Error ? signal.reason : new Error("resource import was cancelled");
  error.name = "AbortError";
  throw error;
}

async function sha256Hex(bytes: ArrayBuffer): Promise<string> {
  const subtle = globalThis.crypto?.subtle;
  if (subtle === undefined) throw new ResourceIntegrityError("Web Crypto SHA-256 is unavailable");
  const digest = await subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

/**
 * Fetch, verify, and persist one declared archive. Callers must invoke the method from a user action.
 */
export class BrowserResourceProvider {
  readonly descriptor: ResourceArchiveDescriptor;
  private readonly storage: ResourceStorage;
  private readonly fetchImpl: typeof fetch;
  private readonly digest: (bytes: ArrayBuffer) => Promise<string>;
  private readonly now: () => number;

  constructor(descriptor: ResourceArchiveDescriptor, options: ResourceProviderOptions) {
    this.descriptor = descriptor;
    this.storage = options.storage;
    this.fetchImpl = options.fetch ?? globalThis.fetch.bind(globalThis);
    this.digest = options.digest ?? sha256Hex;
    this.now = options.now ?? Date.now;
  }

  async status(): Promise<ResourceProviderStatus> {
    const record = await this.storage.read(this.descriptor.id);
    if (record === undefined) return { state: "missing" };
    try {
      await this.verify(record.bytes, record.byteLength, record.sha256);
      return { state: "ready", storedAt: record.storedAt };
    } catch (error) {
      return { state: "invalid", reason: error instanceof Error ? error.message : String(error) };
    }
  }

  async downloadAndVerify(options: ResourceDownloadOptions = {}): Promise<ResourceImportResult> {
    throwIfAborted(options.signal);
    const cached = await this.storage.read(this.descriptor.id);
    if (cached !== undefined) {
      try {
        await this.verify(cached.bytes, cached.byteLength, cached.sha256);
        options.onProgress?.({
          phase: "verifying",
          receivedBytes: this.descriptor.byteLength,
          totalBytes: this.descriptor.byteLength,
          percent: 100,
        });
        return this.result("cache", cached);
      } catch {
        await this.storage.remove(this.descriptor.id);
      }
    }
    const response = await this.fetchImpl(this.descriptor.url, { signal: options.signal });
    if (!response.ok) throw new ResourceIntegrityError(`resource download failed with HTTP ${response.status}`);
    const bytes = await this.readResponse(response, options);
    options.onProgress?.({
      phase: "verifying",
      receivedBytes: bytes.byteLength,
      totalBytes: this.descriptor.byteLength,
      percent: 100,
    });
    await this.verify(bytes, bytes.byteLength, this.descriptor.sha256);
    const record: StoredResourceArchive = {
      id: this.descriptor.id,
      bytes,
      byteLength: bytes.byteLength,
      sha256: this.descriptor.sha256,
      storedAt: this.now(),
    };
    options.onProgress?.({
      phase: "storing",
      receivedBytes: bytes.byteLength,
      totalBytes: this.descriptor.byteLength,
      percent: 100,
    });
    await this.storage.write(record);
    return this.result("network", record);
  }

  /** Return the verified archive for an adapter; raw bytes never enter a DSH session event. */
  async openVerifiedArchive(): Promise<Blob> {
    const record = await this.storage.read(this.descriptor.id);
    if (record === undefined) throw new ResourceIntegrityError("resource archive has not been imported");
    await this.verify(record.bytes, record.byteLength, record.sha256);
    return new Blob([new Uint8Array(record.bytes)], { type: "application/x-7z-compressed" });
  }

  async clear(): Promise<void> {
    await this.storage.remove(this.descriptor.id);
  }

  private async readResponse(response: Response, options: ResourceDownloadOptions): Promise<ArrayBuffer> {
    throwIfAborted(options.signal);
    const contentLength = response.headers.get("content-length");
    const totalBytes = contentLength === null ? this.descriptor.byteLength : Number(contentLength);
    if (!Number.isSafeInteger(totalBytes) || totalBytes !== this.descriptor.byteLength) {
      throw new ResourceIntegrityError(`resource content-length mismatch: expected ${this.descriptor.byteLength}, got ${contentLength ?? "missing"}`);
    }
    options.onProgress?.({ phase: "downloading", receivedBytes: 0, totalBytes, percent: 0 });
    if (response.body === null) {
      const bytes = await response.arrayBuffer();
      throwIfAborted(options.signal);
      if (bytes.byteLength !== this.descriptor.byteLength) {
        throw new ResourceIntegrityError(`resource byte length mismatch: expected ${this.descriptor.byteLength}, got ${bytes.byteLength}`);
      }
      return bytes;
    }
    const reader = response.body.getReader();
    const chunks: Uint8Array[] = [];
    let receivedBytes = 0;
    const onAbort = () => {
      void reader.cancel(options.signal?.reason).catch(() => undefined);
    };
    options.signal?.addEventListener("abort", onAbort, { once: true });
    try {
      while (true) {
        if (options.signal?.aborted) throwIfAborted(options.signal);
        const next = await reader.read();
        if (options.signal?.aborted) throwIfAborted(options.signal);
        if (next.done) break;
        const chunk = next.value;
        receivedBytes += chunk.byteLength;
        if (receivedBytes > this.descriptor.byteLength) {
          await reader.cancel("resource archive exceeded its declared size").catch(() => undefined);
          throw new ResourceIntegrityError(`resource byte length exceeds declared size: expected ${this.descriptor.byteLength}, got at least ${receivedBytes}`);
        }
        chunks.push(chunk);
        options.onProgress?.({
          phase: "downloading",
          receivedBytes,
          totalBytes,
          percent: Math.min(100, Math.round((receivedBytes / totalBytes) * 100)),
        });
      }
    } finally {
      options.signal?.removeEventListener("abort", onAbort);
      reader.releaseLock();
    }
    const bytes = new Uint8Array(receivedBytes);
    let offset = 0;
    for (const chunk of chunks) {
      bytes.set(chunk, offset);
      offset += chunk.byteLength;
    }
    return bytes.buffer;
  }

  private async verify(bytes: ArrayBuffer, storedByteLength: number, storedSha256: string): Promise<void> {
    if (bytes.byteLength !== this.descriptor.byteLength || storedByteLength !== this.descriptor.byteLength) {
      throw new ResourceIntegrityError(`resource byte length mismatch: expected ${this.descriptor.byteLength}, got ${bytes.byteLength}`);
    }
    if (storedSha256.toLowerCase() !== this.descriptor.sha256.toLowerCase()) {
      throw new ResourceIntegrityError("stored resource hash metadata does not match the descriptor");
    }
    const actualSha256 = await this.digest(bytes);
    if (actualSha256.toLowerCase() !== this.descriptor.sha256.toLowerCase()) {
      throw new ResourceIntegrityError("resource SHA-256 mismatch");
    }
  }

  private result(source: ResourceImportResult["source"], record: StoredResourceArchive): ResourceImportResult {
    return {
      source,
      resourceId: record.id,
      byteLength: record.byteLength,
      sha256: record.sha256,
      storedAt: record.storedAt,
    };
  }
}

export type RendererEntryDecision = "required" | "allowed" | "excluded" | "ignored";

export const REQUIRED_RENDERER_ENTRIES = ["ra2.mix", "language.mix", "multi.mix"] as const;

/** Classify top-level archive entries before a renderer adapter imports them. */
export function classifyRendererEntry(entryName: string): RendererEntryDecision {
  const normalized = entryName.replaceAll("\\", "/").replace(/^\.\/+/, "").toLowerCase();
  if ((REQUIRED_RENDERER_ENTRIES as readonly string[]).includes(normalized)) return "required";
  if (/^(?:theme(?:[^/]*)?\.mix|taunts(?:\/|$)|movies(?:\/|$))/.test(normalized)) return "excluded";
  if (/\.(?:exe|dll)$/.test(normalized)) return "excluded";
  if (normalized.startsWith("maps/")) return "allowed";
  return "ignored";
}

export function selectRendererEntries(entryNames: readonly string[]): {
  readonly selected: readonly string[];
  readonly excluded: readonly string[];
  readonly missing: readonly string[];
} {
  const selected = entryNames.filter((entryName) => {
    const decision = classifyRendererEntry(entryName);
    return decision === "required" || decision === "allowed";
  });
  const excluded = entryNames.filter((entryName) => classifyRendererEntry(entryName) === "excluded");
  const normalized = new Set(entryNames.map((entryName) => entryName.replaceAll("\\", "/").toLowerCase()));
  const missing = REQUIRED_RENDERER_ENTRIES.filter((entryName) => !normalized.has(entryName));
  return { selected, excluded, missing };
}
