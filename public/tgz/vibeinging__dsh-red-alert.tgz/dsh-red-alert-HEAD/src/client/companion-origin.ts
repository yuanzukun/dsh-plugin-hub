import { RED_ALERT_RENDERER_LOOPBACK_HOST } from "../browser-command-protocol.ts";

/** Options for the explicitly configured local companion exception. */
export interface CompanionOriginOptions {
  readonly loopbackPort?: number;
  readonly allowLoopback?: boolean;
}

/** Stable error raised when a companion URL is outside the configured boundary. */
export class CompanionOriginError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CompanionOriginError";
  }
}

function requireOrigin(value: string, label: string): string {
  let url: URL;
  try {
    url = new URL(value);
  } catch {
    throw new CompanionOriginError(`${label} must be an absolute origin`);
  }
  if (url.origin === "null" || url.username !== "" || url.password !== "" || url.pathname !== "/" || url.search !== "" || url.hash !== "") {
    throw new CompanionOriginError(`${label} must contain only scheme, host and port`);
  }
  return url.origin;
}

/**
 * Resolve a user-confirmed URL for the plugin-owned companion server. Only an
 * explicit http loopback address with the configured numeric port is accepted.
 * The dedicated loopback host also keeps the real game cross-site from DSH so
 * game-engine work cannot block Chat and live command receipts.
 */
export function resolveCompanionUrl(
  rawUrl: string,
  parentOrigin: string,
  options: CompanionOriginOptions = {},
): URL {
  const expectedParentOrigin = requireOrigin(parentOrigin, "parent origin");
  if (rawUrl === "*" || rawUrl.length === 0) throw new CompanionOriginError("companion URL must be explicit");
  let url: URL;
  try {
    url = new URL(rawUrl, expectedParentOrigin);
  } catch {
    throw new CompanionOriginError("companion URL is invalid");
  }
  if (url.origin === "null" || url.username !== "" || url.password !== "" || url.hash !== "" || url.search !== "") {
    throw new CompanionOriginError("companion URL cannot contain credentials, query or fragment");
  }
  const configuredPort = options.loopbackPort;
  const loopbackAllowed = options.allowLoopback === true
    && configuredPort !== undefined
    && Number.isInteger(configuredPort)
    && configuredPort > 0
    && configuredPort <= 65535
    && url.protocol === "http:"
    && url.hostname === RED_ALERT_RENDERER_LOOPBACK_HOST
    && url.port === String(configuredPort);
  if (!loopbackAllowed) throw new CompanionOriginError("companion URL is outside the DSH origin and configured loopback boundary");
  return url;
}

/** Return true only for the exact origin/source pair accepted by the bridge. */
export function isCompanionMessageOrigin(actualOrigin: string, expectedOrigin: string): boolean {
  return actualOrigin === expectedOrigin && expectedOrigin !== "*" && expectedOrigin !== "null";
}
