import { useEffect, useMemo, useRef, useState } from "react";
import type { Context } from "@deepseek-ai/cordis";
import type { ConvViewProps } from "@deepseek-ai/dsh-client-ui-conversation/client";
import type { PropsRuntime } from "@deepseek-ai/dsh-client-ui-slots";
import type { ILayout } from "@deepseek-ai/dsh-client-ui-layout/client";
import type { FogSafeContact } from "../projection.ts";
import type { RedAlertState } from "../projection.ts";
import {
  DEFAULT_RESOURCE_ARCHIVE,
  createBrowserResourceProvider,
  type BrowserResourceProvider,
  type ResourceDownloadProgress,
  type ResourceProviderStatus,
} from "./resource-provider.ts";
import {
  type BrowserRendererRuntime,
  type BrowserRendererIdentity,
  type BrowserRendererState,
} from "./browser-renderer-runtime.ts";
import type { ResourceArchiveDescriptor } from "../resource-config.ts";
import { BrowserCommandClientService } from "./browser-command-consumer.ts";

export { BrowserAdapterRegistry, BrowserCommandClientService } from "./browser-command-consumer.ts";
export type { BrowserMatchAdapter } from "./browser-command-consumer.ts";
export {
  BrowserRendererError,
  BrowserRendererRuntime,
  LoopbackRendererAdapter,
} from "./browser-renderer-runtime.ts";
export type {
  BrowserRendererAdapter,
  BrowserRendererEndpoint,
  BrowserRendererIdentity,
  BrowserRendererState,
} from "./browser-renderer-runtime.ts";

declare module "@deepseek-ai/cordis" {
  interface Context {
    redAlertBrowserCommands: BrowserCommandClientService;
  }
}

// Type-only imports pull the official DSH view slot and standard projection
// kit into the client declaration graph. The browser never imports host code.
import type {} from "@deepseek-ai/dsh-client-runtime/client";
import type {} from "@deepseek-ai/dsh-client-ui-conversation/client";

export type { RedAlertState } from "../projection.ts";

/** The client face is loaded after the shared DSH slot and runtime services. */
export const inject = [
  "connection",
  "layout",
  "sessions",
  "slots",
];

const ignoreRendererReady = (): void => undefined;

type ResourcePanelState = "checking" | "missing" | "invalid" | "confirming" | "downloading" | "ready" | "error" | "unavailable";

function formatBytes(bytes: number): string {
  return `${bytes.toLocaleString("en-US")} bytes`;
}

function resourceStatusState(status: ResourceProviderStatus): ResourcePanelState {
  return status.state === "ready" ? "ready" : status.state === "invalid" ? "invalid" : "missing";
}

export interface ResourceImportPanelProps {
  readonly provider: BrowserResourceProvider | undefined;
  readonly descriptor?: ResourceArchiveDescriptor;
}

/** User-confirmed resource import controls; construction never starts a download. */
export function ResourceImportPanel({ provider, descriptor = provider?.descriptor ?? DEFAULT_RESOURCE_ARCHIVE }: ResourceImportPanelProps): JSX.Element {
  const [panelState, setPanelState] = useState<ResourcePanelState>(provider === undefined ? "unavailable" : "checking");
  const [progress, setProgress] = useState<ResourceDownloadProgress | undefined>();
  const [error, setError] = useState<string | undefined>();
  const abortRef = useRef<AbortController | undefined>();

  useEffect(() => {
    let active = true;
    if (provider === undefined) {
      setPanelState("unavailable");
      return () => { active = false; };
    }
    setPanelState("checking");
    void provider.status().then((status) => {
      if (active) setPanelState(resourceStatusState(status));
    }).catch((statusError: unknown) => {
      if (active) {
        setError(statusError instanceof Error ? statusError.message : String(statusError));
        setPanelState("error");
      }
    });
    return () => {
      active = false;
      abortRef.current?.abort();
    };
  }, [provider]);

  const confirmImport = () => {
    if (provider === undefined) return;
    const controller = new AbortController();
    abortRef.current = controller;
    setError(undefined);
    setProgress(undefined);
    setPanelState("downloading");
    void provider.downloadAndVerify({
      signal: controller.signal,
      onProgress: setProgress,
    }).then(() => {
      if (abortRef.current === controller) abortRef.current = undefined;
      setPanelState("ready");
    }).catch((downloadError: unknown) => {
      if (abortRef.current === controller) abortRef.current = undefined;
      if (downloadError instanceof Error && downloadError.name === "AbortError") {
        setPanelState("missing");
        return;
      }
      setError(downloadError instanceof Error ? downloadError.message : String(downloadError));
      setPanelState("error");
    });
  };

  const cancelImport = () => {
    abortRef.current?.abort();
    abortRef.current = undefined;
    setPanelState("missing");
  };

  const clearImport = () => {
    if (provider === undefined) return;
    void provider.clear().then(() => {
      setProgress(undefined);
      setPanelState("missing");
    }).catch((clearError: unknown) => {
      setError(clearError instanceof Error ? clearError.message : String(clearError));
      setPanelState("error");
    });
  };

  return (
    <section className="ra-resource" data-testid="ra-resource-import" data-state={panelState} aria-labelledby="ra-resource-title">
      <h3 id="ra-resource-title">运行资源导入</h3>
      <dl>
        <dt>来源</dt><dd>{descriptor.sourceLabel}</dd>
        <dt>版本</dt><dd>{descriptor.version}</dd>
        <dt>大小</dt><dd>{formatBytes(descriptor.byteLength)}</dd>
        <dt>SHA-256</dt><dd>{descriptor.sha256}</dd>
      </dl>
      <p className="ra-resource-note">{descriptor.licenseNotice} 仅在你确认来源、大小、hash 和权利提示后下载；资源留在本浏览器的 dsh-red-alert Cache Storage 命名空间。</p>
      {panelState === "unavailable" ? <p className="ra-resource-error" role="alert">当前浏览器没有可用的 Cache Storage，不能把资源写入 DSH 服务端。</p> : null}
      {panelState === "invalid" ? <p className="ra-resource-error" role="alert">已缓存资源校验失败，请重新导入。</p> : null}
      {panelState === "confirming" ? (
        <>
          <p className="ra-resource-note">请确认以上公开来源、文件大小、SHA-256 和版权提示，再开始下载。</p>
          <div className="ra-resource-actions">
            <button type="button" onClick={confirmImport}>确认并下载</button>
            <button type="button" onClick={() => setPanelState("missing")}>取消</button>
          </div>
        </>
      ) : null}
      {panelState === "downloading" ? (
        <>
          <progress max={100} value={progress?.percent ?? 0} aria-label="资源下载进度" />
          <p className="ra-resource-note">{progress === undefined ? "准备下载" : `${progress.phase} · ${progress.percent}% · ${formatBytes(progress.receivedBytes)} / ${formatBytes(progress.totalBytes)}`}</p>
          <div className="ra-resource-actions"><button type="button" onClick={cancelImport}>取消下载</button></div>
        </>
      ) : null}
      {panelState === "error" ? (
        <>
          <p className="ra-resource-error" role="alert">资源导入失败：{error ?? "未知错误"}</p>
          <div className="ra-resource-actions"><button type="button" onClick={() => setPanelState("confirming")}>重试</button></div>
        </>
      ) : null}
      {panelState === "ready" ? (
        <>
          <p className="ra-resource-note" role="status">资源已在 DSH origin 的浏览器 Cache Storage 中通过大小和 SHA-256 校验；这不等于兼容 renderer 已就绪。跨 origin companion 不能直接读取此缓存，资源 Blob 到 companion 的严格导入仍待 D4，音乐、Taunts、电影和可执行文件仍会被排除。</p>
          <div className="ra-resource-actions"><button type="button" onClick={clearImport}>清除浏览器资源</button></div>
        </>
      ) : null}
      {(panelState === "missing" || panelState === "invalid") && provider !== undefined ? (
        <div className="ra-resource-actions"><button type="button" onClick={() => setPanelState("confirming")}>查看并确认导入</button></div>
      ) : null}
    </section>
  );
}

/** First-run automatic resource preparation and visible local fallback. */
function LocalArchiveGuide(): JSX.Element {
  return (
    <section className="ra-resource" data-testid="ra-local-archive-guide" aria-labelledby="ra-local-archive-title">
      <h3 id="ra-local-archive-title">资源自动准备与本地备用</h3>
      <p className="ra-resource-note">推荐在启动前运行 <code>pnpm exec dsh-red-alert-setup --profile web --download-resources</code>。它会从 <code>https://download.ra2web.com/full-pack.7z</code> 下载固定版本，校验大小和 SHA-256，再让首次建局自动导入并继续，不需要返回 Chat 告诉模型。</p>
      <p className="ra-resource-note">该公开候选地址不代表 EA 或其他权利方授权素材使用。若不使用它，游戏画面仍保留本地 7z 入口；最小归档只需 RA2.MIX、LANGUAGE.MIX 和 MULTI.MIX，并排除音乐、Taunts、电影、exe 和 dll。</p>
    </section>
  );
}

function rendererStateLabel(state: BrowserRendererState | "missing-identity" | "disabled" | "ended" | "confirm"): string {
  if (state === "ready") return "renderer adapter 已握手";
  if (state === "connecting") return "等待同一 browser instance 内的 renderer adapter";
  if (state === "disconnected") return "renderer adapter 已断开，可重连";
  if (state === "error") return "renderer adapter 报告错误";
  if (state === "disposed") return "renderer bridge 已释放";
  if (state === "missing-identity") return "缺少 session/match/seat 绑定，拒绝启动 renderer";
  if (state === "disabled") return "当前对局已停止，renderer 不再接收命令";
  if (state === "ended") return "上一局已经结束";
  if (state === "confirm") return "等待用户确认后连接本地 renderer";
  return "renderer 尚未连接";
}

function RendererContainer({
  identity,
  lifecycleStatus,
  rendererDescriptor,
  rendererService,
  onRendererReady,
}: {
  readonly identity: BrowserRendererIdentity | undefined;
  readonly lifecycleStatus: "creating" | "active" | "finished" | "stopped";
  readonly rendererDescriptor: RedAlertState["view"]["renderer"];
  readonly rendererService: BrowserCommandClientService | undefined;
  readonly onRendererReady: (ready: boolean) => void;
}): JSX.Element {
  const identityKey = identity === undefined ? undefined : `${identity.sessionId}:${identity.matchId}:${identity.seat}`;
  const [rendererState, setRendererState] = useState<BrowserRendererState>("unavailable");
  const [confirmationState, setConfirmationState] = useState<"idle" | "connecting" | "error" | "confirmed">("idle");
  const [container, setContainer] = useState<HTMLElement | null>(null);
  const registrationRef = useRef<{ readonly sessionId: string; readonly identityKey: string; readonly url: string; readonly port: number } | undefined>();
  const rendererRuntime = rendererService?.renderer;
  const currentIdentityRef = useRef<BrowserRendererIdentity | undefined>(identity);
  currentIdentityRef.current = identity;
  const lifecycleRef = useRef(0);
  const connectGenerationRef = useRef(0);
  const previousIdentityKeyRef = useRef(identityKey);
  useEffect(() => {
    const lifecycle = lifecycleRef.current + 1;
    lifecycleRef.current = lifecycle;
    return () => {
      if (lifecycleRef.current === lifecycle) lifecycleRef.current += 1;
    };
  }, []);

  const hasRegisteredAdapter = identity !== undefined && rendererRuntime?.get(identity.sessionId) !== undefined;
  const attachIdentity = useMemo(() => identity, [identityKey, hasRegisteredAdapter]);

  useEffect(() => {
    connectGenerationRef.current += 1;
    const identityChanged = previousIdentityKeyRef.current !== identityKey;
    previousIdentityKeyRef.current = identityKey;
    setConfirmationState(identityChanged ? "idle" : hasRegisteredAdapter ? "confirmed" : "idle");
    if (!hasRegisteredAdapter) setRendererState("unavailable");
  }, [identityKey, hasRegisteredAdapter]);

  useEffect(() => {
    if (attachIdentity === undefined || lifecycleStatus === "stopped" || rendererRuntime === undefined || container === null) {
      setRendererState(attachIdentity === undefined ? "unavailable" : lifecycleStatus === "stopped" ? "disconnected" : "unavailable");
      onRendererReady(false);
      return;
    }
    if (!hasRegisteredAdapter) {
      setRendererState("unavailable");
      onRendererReady(false);
      return;
    }
    if (confirmationState !== "confirmed") {
      if (confirmationState === "connecting") setRendererState("connecting");
      onRendererReady(false);
      return;
    }
    let active = true;
    const runtimeWithState = rendererRuntime as BrowserRendererRuntime & {
      readonly getState?: (sessionId: string) => BrowserRendererState;
      readonly subscribeState?: (sessionId: string, listener: (state: BrowserRendererState) => void) => () => void;
    };
    const hasStateSubscription = typeof runtimeWithState.subscribeState === "function";
    let reachedReady = runtimeWithState.getState?.(attachIdentity.sessionId) === "ready";
    const stopStateSubscription = hasStateSubscription
      ? runtimeWithState.subscribeState(attachIdentity.sessionId, (nextState) => {
        if (!active) return;
        setRendererState(nextState);
        if (nextState === "ready") reachedReady = true;
        if (reachedReady && (nextState === "disconnected" || nextState === "error" || nextState === "disposed")) {
          setConfirmationState("error");
          onRendererReady(false);
        } else {
          onRendererReady(nextState === "ready");
        }
      })
      : () => undefined;
    const initialRendererState = runtimeWithState.getState?.(attachIdentity.sessionId) ?? "unavailable";
    setRendererState(initialRendererState === "ready" ? "ready" : "connecting");
    void rendererRuntime.attach(attachIdentity.sessionId, container, attachIdentity).then(() => {
      if (active) {
        if (!hasStateSubscription) {
          setRendererState("ready");
          onRendererReady(true);
        }
      }
    }).catch(() => {
      if (active) {
        setRendererState("error");
        setConfirmationState("error");
        onRendererReady(false);
      }
    });
    return () => {
      active = false;
      stopStateSubscription();
      onRendererReady(false);
      void rendererRuntime.detach(attachIdentity.sessionId, container).catch(() => undefined);
    };
  }, [attachIdentity, confirmationState, container, hasRegisteredAdapter, lifecycleStatus, onRendererReady, rendererRuntime]);

  useEffect(() => {
    const registration = registrationRef.current;
    if (registration !== undefined && identity?.sessionId !== registration.sessionId) {
      void rendererRuntime?.removeSession(registration.sessionId).catch(() => undefined);
      registrationRef.current = undefined;
    }
  }, [identity?.sessionId, rendererRuntime]);

  function connectRenderer(): void {
    if (identity === undefined || lifecycleStatus === "finished" || lifecycleStatus === "stopped" || rendererDescriptor === undefined || rendererService === undefined || rendererRuntime === undefined) return;
    const requestedIdentity = identity;
    const lifecycle = lifecycleRef.current;
    const generation = connectGenerationRef.current + 1;
    connectGenerationRef.current = generation;
    const isCurrent = () => lifecycleRef.current === lifecycle
      && connectGenerationRef.current === generation
      && currentIdentityRef.current?.sessionId === requestedIdentity.sessionId
      && currentIdentityRef.current?.matchId === requestedIdentity.matchId
      && currentIdentityRef.current?.seat === requestedIdentity.seat;
    setRendererState("connecting");
    setConfirmationState("connecting");
    void (async () => {
      const config = await rendererService.rendererConfig(requestedIdentity);
      if (!isCurrent()) return;
      const runtimeWithState = rendererRuntime as BrowserRendererRuntime & {
        readonly getState?: (sessionId: string) => BrowserRendererState;
        readonly getEndpoint?: (sessionId: string) => { readonly url: string; readonly port: number } | undefined;
        readonly removeSession?: (sessionId: string) => Promise<void>;
      };
      const existingAdapter = rendererRuntime.get(requestedIdentity.sessionId);
      const existingState = runtimeWithState.getState?.(requestedIdentity.sessionId);
      const adapterFailed = existingState === "disposed" || existingState === "error" || existingState === "disconnected";
      const existingEndpoint = runtimeWithState.getEndpoint?.(requestedIdentity.sessionId) ?? existingAdapter?.endpoint;
      const endpointMatches = existingAdapter !== undefined
        && !adapterFailed
        && existingEndpoint?.url === config.url
        && existingEndpoint.port === config.port;
      if (existingAdapter !== undefined && !endpointMatches) {
        const remove = runtimeWithState.removeSession?.(requestedIdentity.sessionId);
        if (remove === undefined) throw new Error("renderer runtime cannot drain an existing adapter");
        await remove;
        if (!isCurrent()) return;
        registrationRef.current = undefined;
      }
      if (!isCurrent()) return;
      if (rendererRuntime.get(requestedIdentity.sessionId) === undefined) {
        rendererRuntime.registerLoopback(requestedIdentity.sessionId, {
          url: config.url,
          parentOrigin: window.location.origin,
          origin: { allowLoopback: true, loopbackPort: config.port },
        });
        registrationRef.current = { sessionId: requestedIdentity.sessionId, identityKey: identityKey ?? "", url: config.url, port: config.port };
      } else {
        registrationRef.current = { sessionId: requestedIdentity.sessionId, identityKey: identityKey ?? "", url: config.url, port: config.port };
      }
      if (!isCurrent()) return;
      setConfirmationState("confirmed");
    })().catch(() => {
      if (!isCurrent()) return;
      setRendererState("error");
      setConfirmationState("error");
    });
  }

  const state: BrowserRendererState | "missing-identity" | "disabled" | "ended" | "confirm" = identity === undefined
    ? "missing-identity"
    : lifecycleStatus === "stopped"
      ? "disabled"
      : lifecycleStatus === "finished" && !hasRegisteredAdapter
        ? "ended"
      : rendererDescriptor === undefined
        ? "unavailable"
        : confirmationState === "idle"
          ? "confirm"
          : confirmationState === "connecting"
            ? "connecting"
            : confirmationState === "error"
              ? "error"
              : rendererState;
  return (
    <section className="ra-renderer-panel" aria-label="红警游戏画面">
      <div ref={setContainer} className="ra-renderer-container" data-testid="ra-renderer-container" data-renderer-state={state} data-match-id={identity?.matchId}>
        {state === "confirm" ? <div className="ra-renderer-placeholder" data-state={state}>
          <strong>{rendererStateLabel(state)}</strong>
          <span>需要你明确确认后，才通过 live Connection 配置连接插件自有 loopback renderer。</span>
          <button className="ra-renderer-action" type="button" onClick={connectRenderer}>确认并连接本地 renderer</button>
        </div> : null}
        {state === "error" && rendererDescriptor !== undefined ? <div className="ra-renderer-placeholder" data-state={state}>
          <strong>{rendererStateLabel(state)}</strong>
          <span>live Connection 配置或 renderer 握手失败；重试会销毁旧连接并重新加载本地 renderer。</span>
          <button className="ra-renderer-action" type="button" onClick={connectRenderer}>重试连接本地 renderer</button>
        </div> : null}
        {state === "ended" ? <div className="ra-renderer-placeholder" data-state={state}>
          <strong>{rendererStateLabel(state)}</strong>
          <span>终局 renderer 不再接受 live 配置或命令。模型完成复盘后，可以在当前 Chat 创建下一局；新对局会使用新的 match 身份和全新游戏画面。</span>
        </div> : null}
        {state !== "confirm" && state !== "error" && state !== "ready" && state !== "ended" ? <div className="ra-renderer-placeholder" data-state={state}>
          <strong>{rendererStateLabel(state)}</strong>
          <span>未连接时不显示占位画面，也不使用 SVG、Canvas、截图、视频或跨源页面代替真实客户端。</span>
        </div> : null}
      </div>
    </section>
  );
}

const STYLE = `
.ra-battlefield-toggle { border: 1px solid #d6d9de; border-radius: 8px; background: #fff; color: #25282d; padding: 5px 10px; font: inherit; cursor: pointer; }
.ra-battlefield-toggle:hover, .ra-battlefield-toggle:focus-visible, .ra-battlefield-toggle[aria-pressed='true'] { border-color: #9e2f23; color: #8c261d; outline: none; box-shadow: 0 0 0 2px rgba(158, 47, 35, .14); }
.ra-side-panel { position: fixed; inset: 0 0 0 auto; z-index: 19; width: clamp(600px, 48vw, 760px); min-width: 600px; max-width: 48vw; display: flex; flex-direction: column; border-left: 1px solid #353a3d; background: #0d1111; color: #e9dcc2; box-shadow: -12px 0 30px rgba(0, 0, 0, .18); }
.ra-side-panel[data-wide='true'] { width: min(920px, 64vw); min-width: min(920px, 64vw); max-width: 64vw; }
.ra-side-panel-header { flex: none; min-height: 48px; display: flex; align-items: center; gap: 8px; padding: 8px 10px 8px 12px; border-bottom: 1px solid #353a3d; background: #171b1b; }
.ra-side-panel-title { min-width: 0; flex: 1; }
.ra-side-panel-title strong { display: block; overflow: hidden; color: #f0bf69; font: 600 12px/1.35 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; text-overflow: ellipsis; white-space: nowrap; }
.ra-side-panel-title span { display: block; overflow: hidden; color: #938b7b; font: 10px/1.35 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; text-overflow: ellipsis; white-space: nowrap; }
.ra-side-panel-control { border: 1px solid #575b59; border-radius: 5px; background: #252928; color: #d6cbb8; padding: 5px 7px; font: 11px/1.2 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; cursor: pointer; }
.ra-side-panel-control:hover, .ra-side-panel-control:focus-visible { border-color: #d18a3d; color: #f2c879; outline: none; }
.ra-side-panel-body { min-height: 0; flex: 1; overflow: auto; }
.ra-side-panel .ra-battlefield { min-height: 100%; }
.ra-side-panel .ra-renderer-container { min-height: clamp(460px, 64vh, 620px); }
.ra-side-panel .ra-resource-flow, .ra-side-panel .ra-debug { margin-inline: 10px; }
.ra-side-panel .ra-empty, .ra-side-panel .ra-error { margin: 12px 10px; }
.ra-side-panel .ra-grid { grid-template-columns: 1fr; }
.ra-side-panel .ra-map { min-height: 210px; }
.ra-battlefield { color: #e9dcc2; background: #0d1111; min-height: 100%; padding: 0; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; }
.ra-battlefield *, .ra-battlefield *::before, .ra-battlefield *::after { box-sizing: border-box; }
.ra-renderer-panel { background: #0d1111; margin: 0; }
.ra-renderer-container { min-height: clamp(560px, calc(100vh - 96px), 1000px); background: #0d1111; display: grid; place-items: center; padding: 0; }
.ra-renderer-placeholder { max-width: 620px; text-align: center; border: 1px dashed #76512d; padding: 22px; color: #c2b7a0; line-height: 1.65; }
.ra-renderer-placeholder strong { display: block; color: #f0bf69; margin-bottom: 8px; }
.ra-renderer-action { min-height: 44px; margin-top: 12px; padding: 10px 18px; border: 1px solid #f1b35d; border-radius: 4px; background: #9b2d22; color: #fff3df; box-shadow: 0 0 0 1px rgba(17, 10, 7, .72), 0 5px 16px rgba(0, 0, 0, .28); font: 700 13px/1.25 ui-sans-serif, system-ui, sans-serif; letter-spacing: .02em; cursor: pointer; }
.ra-renderer-action:hover { border-color: #ffd28a; background: #b13a2a; color: #fff7e9; }
.ra-renderer-action:focus-visible { outline: 3px solid #f1b35d; outline-offset: 3px; }
.ra-renderer-action:active { background: #81251c; box-shadow: 0 0 0 1px rgba(17, 10, 7, .72); transform: translateY(1px); }
.ra-renderer-placeholder[data-state='ready'] { border-color: #a98e50; }
.ra-renderer-placeholder[data-state='error'] { border-color: #ff745d; color: #ffd0c4; }
.ra-resource-flow { margin: 14px 18px 0; border: 1px solid #3e3b32; background: #202322; }
.ra-resource-flow summary { cursor: pointer; color: #b8aa91; padding: 10px 12px; font-size: 11px; }
.ra-resource { border-top: 1px solid #3e3b32; padding: 12px; }
.ra-resource h3 { margin: 0 0 8px; color: #d9bf8d; font-size: 12px; letter-spacing: .08em; text-transform: uppercase; }
.ra-resource dl { display: grid; grid-template-columns: minmax(90px, auto) minmax(0, 1fr); gap: 4px 10px; margin: 0; color: #c2b7a0; font-size: 11px; }
.ra-resource dt { color: #96866a; }
.ra-resource dd { margin: 0; overflow-wrap: anywhere; }
.ra-resource-note { color: #b8aa91; font-size: 11px; line-height: 1.55; }
.ra-resource-actions { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px; }
.ra-resource button { border: 1px solid #a56125; background: #2b251d; color: #f3d18f; padding: 8px 11px; font: inherit; cursor: pointer; }
.ra-resource button:hover, .ra-resource button:focus-visible { background: #473421; outline: 2px solid #f0a23b; outline-offset: 2px; }
.ra-resource button:disabled { cursor: wait; opacity: .6; }
.ra-resource progress { display: block; width: 100%; height: 10px; margin-top: 10px; accent-color: #d59038; }
.ra-resource-error { margin-top: 8px; color: #ffd0c4; }
.ra-debug { margin: 14px 18px 0; border-top: 1px solid #3e3b32; padding-top: 10px; }
.ra-debug summary { cursor: pointer; color: #a89b83; font-size: 11px; }
.ra-grid { display: grid; grid-template-columns: minmax(0, 1.5fr) minmax(260px, 1fr); gap: 14px; }
.ra-map-panel { grid-column: 1 / -1; border: 1px solid #665333; border-top: 3px solid #b26b2c; background: #151a1a; padding: 14px; }
.ra-map-heading { display: flex; justify-content: space-between; align-items: baseline; gap: 12px; margin-bottom: 10px; }
.ra-map-heading h2 { margin: 0; color: #f0c16f; font-size: 14px; letter-spacing: .1em; text-transform: uppercase; }
.ra-map-heading span { color: #96866a; font-size: 11px; }
.ra-map-shell { overflow: hidden; border: 1px solid #4e4737; background: #101716; box-shadow: inset 0 0 0 1px #232b28, inset 0 0 40px rgba(205, 135, 51, .08); }
.ra-map { display: block; width: 100%; min-height: 270px; max-height: 62vh; background: #101716; }
.ra-map-boundary { fill: none; stroke: #8a6c3b; stroke-width: .35; vector-effect: non-scaling-stroke; }
.ra-map-scanline { fill: none; stroke: rgba(225, 174, 83, .18); stroke-width: .22; vector-effect: non-scaling-stroke; }
.ra-marker { cursor: default; }
.ra-marker-own { fill: #e4b75d; stroke: #fff1ba; }
.ra-marker-enemy { fill: #cc4c37; stroke: #ffb09a; }
.ra-marker-neutral { fill: #969b82; stroke: #d8d5b9; }
.ra-marker-last-seen { fill: #a7774a; stroke: #d6b28a; stroke-dasharray: 1.2 1; opacity: .52; }
.ra-marker-shape { stroke-width: .55; vector-effect: non-scaling-stroke; }
.ra-marker-label { fill: #f8ecd2; font-size: 2.6px; font-weight: 700; paint-order: stroke; stroke: #101716; stroke-width: .65px; stroke-linejoin: round; text-anchor: middle; dominant-baseline: central; pointer-events: none; }
.ra-map-legend { display: flex; flex-wrap: wrap; gap: 8px 16px; margin-top: 10px; color: #c9b995; font-size: 11px; }
.ra-legend-item { display: inline-flex; align-items: center; gap: 6px; }
.ra-legend-mark { display: inline-flex; width: 18px; height: 12px; align-items: center; justify-content: center; border: 1px solid currentColor; font-size: 9px; line-height: 1; }
.ra-legend-mark[data-kind='last-seen'] { border-style: dashed; opacity: .55; }
.ra-panel { border-top: 2px solid #76512d; background: #202322; padding: 14px; }
.ra-panel h2 { margin: 0 0 12px; color: #d9bf8d; font-size: 13px; letter-spacing: .08em; text-transform: uppercase; }
.ra-panel p { color: #c2b7a0; font-size: 13px; line-height: 1.65; }
.ra-contact-list { display: grid; gap: 7px; }
.ra-contact { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 8px; border-left: 3px solid #bb432d; background: #2a2b29; padding: 8px 10px; }
.ra-contact[data-source='last-seen'] { border-left-style: dashed; opacity: .48; }
.ra-contact-name { color: #f0e2c6; font-size: 13px; }
.ra-contact-detail { color: #a89b83; font-size: 11px; line-height: 1.5; }
.ra-contact-mark { color: #e48a36; font-size: 10px; text-align: right; white-space: nowrap; }
.ra-empty { margin: 18px; border: 1px dashed #76512d; padding: 28px 20px; text-align: center; }
.ra-empty strong { display: block; color: #f0bf69; font-size: 15px; margin-bottom: 10px; }
.ra-error { margin: 18px; border-left: 3px solid #ff745d; background: #2c211f; padding: 12px; color: #ffd0c4; }
.ra-error code { color: #ffad91; }
.ra-footer { margin: 16px 18px 0; padding-bottom: 18px; color: #847a68; font-size: 11px; line-height: 1.5; }
@media (min-width: 761px) and (max-width: 1199px) { .ra-side-panel { width: min(560px, 52vw); min-width: min(560px, 52vw); max-width: 52vw; } .ra-side-panel[data-wide='true'] { width: min(720px, 68vw); min-width: min(720px, 68vw); max-width: 68vw; } }
@media (max-width: 760px) { .ra-side-panel, .ra-side-panel[data-wide='true'] { width: min(420px, 82vw); min-width: min(420px, 82vw); max-width: 82vw; } .ra-renderer-container { min-height: clamp(420px, calc(100vh - 96px), 760px); } .ra-side-panel .ra-renderer-container { min-height: clamp(320px, 48vh, 440px); } .ra-grid { grid-template-columns: 1fr; } .ra-map-heading { display: block; } .ra-map-heading span { display: block; margin-top: 5px; } .ra-map { min-height: 220px; } }
@media (prefers-reduced-motion: reduce) { .ra-battlefield * { transition: none !important; animation: none !important; } }
`;

function ContactList({ title, contacts }: { title: string; contacts: readonly FogSafeContact[] }): JSX.Element {
  return (
    <section className="ra-panel" aria-labelledby={`ra-${title}`}>
      <h2 id={`ra-${title}`}>{title}</h2>
      {contacts.length === 0 ? <p>当前公平观察没有记录。</p> : (
        <div className="ra-contact-list">
          {contacts.map((contact) => (
            <div className="ra-contact" data-source={contact.source} key={`${contact.source}-${contact.id}-${contact.observedAtTick}`}>
              <div>
                <div className="ra-contact-name">{contact.label}</div>
                <div className="ra-contact-detail">
                  {contact.kind} · 坐标 {contact.position.x},{contact.position.y} · 完整度 {contact.hpPct}% · t{contact.observedAtTick}
                </div>
              </div>
              <div className="ra-contact-mark">{contact.source === "visible" ? "当前可见" : "最后发现"}</div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

type TacticalMarkerKind = "own" | "enemy" | "last-seen" | "neutral";

function mapCoordinate(value: number, size: number): number {
  if (!Number.isFinite(value) || !Number.isFinite(size) || size <= 0) return 0;
  return Math.min(98, Math.max(2, (value / size) * 100));
}

function TacticalMarker({
  contact,
  mapSize,
  kind,
  label,
}: {
  contact: FogSafeContact;
  mapSize: NonNullable<RedAlertState["match"]>["mapSize"];
  kind: TacticalMarkerKind;
  label: string;
}): JSX.Element {
  const x = mapCoordinate(contact.position.x, mapSize.width);
  const y = mapCoordinate(contact.position.y, mapSize.height);
  const markerClass = `ra-marker ra-marker-${kind}`;
  return (
    <g
      className={markerClass}
      data-source={contact.source}
      data-marker-kind={kind}
      transform={`translate(${x} ${y})`}
      aria-label={`${label} ${contact.label}，坐标 ${contact.position.x},${contact.position.y}`}
    >
      {kind === "own" ? (
        <rect className="ra-marker-shape" x="-1.8" y="-1.8" width="3.6" height="3.6" />
      ) : kind === "neutral" ? (
        <path className="ra-marker-shape" d="M 0 -2.1 L 2.1 0 L 0 2.1 L -2.1 0 Z" />
      ) : (
        <circle className="ra-marker-shape" r="2.1" />
      )}
      <text className="ra-marker-label" x="0" y="0">{label}</text>
    </g>
  );
}

function TacticalMap({ match }: { match: NonNullable<RedAlertState["match"]> }): JSX.Element {
  const { mapSize, observation } = match;
  return (
    <figure className="ra-map-panel" aria-labelledby="ra-map-title">
      <div className="ra-map-heading">
        <h2 id="ra-map-title">公平战术地图</h2>
        <span>公开尺寸 {mapSize.width} × {mapSize.height} · 仅绘制当前 session 的公平观察</span>
      </div>
      <div className="ra-map-shell">
        <svg className="ra-map" data-testid="ra-tactical-map" viewBox="0 0 100 100" role="img" aria-labelledby="ra-map-title ra-map-description">
          <title id="ra-map-description">带战争迷雾边界的离线推演战术地图</title>
          <defs>
            <pattern id="ra-map-grid" width="10" height="10" patternUnits="userSpaceOnUse">
              <path d="M 10 0 L 0 0 0 10" className="ra-map-scanline" />
            </pattern>
          </defs>
          <rect x="0" y="0" width="100" height="100" fill="url(#ra-map-grid)" />
          <rect x="1" y="1" width="98" height="98" className="ra-map-boundary" />
          <path d="M 50 1 V 99 M 1 50 H 99" className="ra-map-scanline" />
          {observation.ownUnits.map((contact) => (
            <TacticalMarker key={`own-${contact.id}`} contact={contact} mapSize={mapSize} kind="own" label="我方" />
          ))}
          {observation.visibleEnemies.map((contact) => (
            <TacticalMarker key={`enemy-${contact.id}`} contact={contact} mapSize={mapSize} kind="enemy" label="敌可见" />
          ))}
          {observation.lastSeenEnemies.map((contact) => (
            <TacticalMarker key={`last-seen-${contact.id}`} contact={contact} mapSize={mapSize} kind="last-seen" label="最后" />
          ))}
          {observation.visibleNeutralObjects.map((contact) => (
            <TacticalMarker key={`neutral-${contact.id}`} contact={contact} mapSize={mapSize} kind="neutral" label="中立" />
          ))}
        </svg>
      </div>
      <figcaption className="ra-map-legend" aria-label="战术地图图例">
        <span className="ra-legend-item"><span className="ra-legend-mark" data-kind="own">我方</span>我方单位/建筑</span>
        <span className="ra-legend-item"><span className="ra-legend-mark" data-kind="enemy">敌可见</span>当前可见敌军</span>
        <span className="ra-legend-item"><span className="ra-legend-mark" data-kind="last-seen">最后</span>最后发现，位置冻结</span>
        <span className="ra-legend-item"><span className="ra-legend-mark" data-kind="neutral">中立</span>可见中立对象</span>
      </figcaption>
    </figure>
  );
}

function MatchView({
  match,
  provider,
  descriptor,
  rendererService,
  rendererDescriptor,
  onRendererReady,
}: {
  readonly match: NonNullable<RedAlertState["match"]>;
  readonly provider: BrowserResourceProvider | undefined;
  readonly descriptor: ResourceArchiveDescriptor;
  readonly rendererService: BrowserCommandClientService | undefined;
  readonly rendererDescriptor: RedAlertState["view"]["renderer"];
  readonly onRendererReady: (ready: boolean) => void;
}): JSX.Element {
  const identity = match.sessionId === undefined || match.seat === undefined
    ? undefined
    : { sessionId: match.sessionId, matchId: match.matchId, seat: match.seat, tick: match.tick };
  return (
    <section className="ra-match" data-match-id={match.matchId}>
      <RendererContainer identity={identity} lifecycleStatus={match.status} rendererDescriptor={rendererDescriptor} rendererService={rendererService} onRendererReady={onRendererReady} />
      <details className="ra-resource-flow">
        <summary>运行资源导入与本地客户端准备（不会挤压游戏画面）</summary>
        {rendererDescriptor === undefined ? <ResourceImportPanel provider={provider} descriptor={descriptor} /> : <LocalArchiveGuide />}
      </details>
      <details className="ra-debug">
        <summary>公平观察 debug 投影（不是实际游戏画面）</summary>
        <TacticalMap match={match} />
        <div className="ra-grid">
          <ContactList title="我方编组与建筑" contacts={match.observation.ownUnits} />
          <ContactList title="当前可见敌情" contacts={match.observation.visibleEnemies} />
          <ContactList title="最后发现" contacts={match.observation.lastSeenEnemies} />
          <ContactList title="可见中立对象" contacts={match.observation.visibleNeutralObjects} />
        </div>
      </details>
      <p className="ra-footer">坐标、血量和数量只来自当前公平观察；最后发现采用弱化显示，不代表敌方当前状态。</p>
    </section>
  );
}

function StateBody({ state, provider, descriptor, rendererService, onRendererReady }: { state: RedAlertState; provider: BrowserResourceProvider | undefined; descriptor: ResourceArchiveDescriptor; rendererService: BrowserCommandClientService | undefined; onRendererReady: (ready: boolean) => void }): JSX.Element {
  const realClientConfigured = rendererService !== undefined;
  const resourceGuide = realClientConfigured || state.view.renderer !== undefined
    ? <LocalArchiveGuide />
    : <ResourceImportPanel provider={provider} descriptor={descriptor} />;
  if (state.status === "empty") {
    return <><div className="ra-empty"><strong>尚未建立红警对战</strong><p>请切换到 Chat，并输入“创建一场 1v1 红警对战”。</p></div>{resourceGuide}</>;
  }
  if (state.status === "creating") {
    return <><RendererContainer identity={state.identity} lifecycleStatus="creating" rendererDescriptor={state.view.renderer} rendererService={rendererService} onRendererReady={onRendererReady} /><div className="ra-empty"><strong>正在由真实浏览器客户端建立对局</strong><p>地图：{state.request?.map ?? "当前地图"} · setup 已准备资源时会自动导入并继续；否则游戏画面会显示本地备用入口。正在等待第一份公平观察，请不要重复提交。</p></div>{resourceGuide}</>;
  }
  if (state.status === "error") {
    if (state.match?.status === "active") {
      return (
        <>
          <MatchView match={state.match} provider={provider} descriptor={descriptor} rendererService={rendererService} rendererDescriptor={state.view.renderer} onRendererReady={onRendererReady} />
          <div className="ra-error" role="alert">
            <strong>操作未完成，可恢复</strong>
            <p>{state.failure?.message ?? "未提供错误详情"}</p>
            <code>{state.failure?.phase ?? "unknown"} · {state.failure?.code ?? "RED_ALERT_OPERATION"}</code>
          </div>
        </>
      );
    }
    const failedCreateRenderer = state.failure?.recoverable === true
      && state.failure.phase === "creating"
      && state.identity !== undefined
      && state.view.renderer !== undefined
      ? <RendererContainer identity={state.identity} lifecycleStatus="creating" rendererDescriptor={state.view.renderer} rendererService={rendererService} onRendererReady={onRendererReady} />
      : null;
    return (
      <>
        {failedCreateRenderer}
        <div className="ra-error" role="alert">
          <strong>操作未完成，可恢复</strong>
          <p>{state.failure?.message ?? "未提供错误详情"}</p>
          <code>{state.failure?.phase ?? "unknown"} · {state.failure?.code ?? "RED_ALERT_OPERATION"}</code>
        </div>
        {state.match === undefined ? resourceGuide : <p className="ra-footer">已保留最近一份公平状态；请在 Chat 查看工具错误并决定重试或停止。</p>}
      </>
    );
  }
  if (state.match === undefined) return <div className="ra-error" role="alert">投影缺少对局状态，不能从浏览器缓存或引擎全量数据补写。</div>;
  return <><MatchView match={state.match} provider={provider} descriptor={descriptor} rendererService={rendererService} rendererDescriptor={state.view.renderer} onRendererReady={onRendererReady} /></>;
}

/** Reusable real-client battlefield body with a fair projection fallback. */
export function RedAlertView({ useProjection, rendererService }: ConvViewProps & { readonly rendererService?: BrowserCommandClientService }): JSX.Element {
  const state = useProjection("redAlert");
  const resourceDescriptor = state?.view.resourceArchive ?? DEFAULT_RESOURCE_ARCHIVE;
  const resourceProvider = useMemo(() => createBrowserResourceProvider({
    resourceArchiveUrl: resourceDescriptor.url,
    resourceArchiveSize: resourceDescriptor.byteLength,
    resourceArchiveSha256: resourceDescriptor.sha256,
    resourceArchiveVersion: resourceDescriptor.version,
    resourceArchiveSourceLabel: resourceDescriptor.sourceLabel,
    resourceArchiveLicenseNotice: resourceDescriptor.licenseNotice,
  }), [
    resourceDescriptor.byteLength,
    resourceDescriptor.licenseNotice,
    resourceDescriptor.sha256,
    resourceDescriptor.sourceLabel,
    resourceDescriptor.url,
    resourceDescriptor.version,
  ]);
  const stateName = state?.status ?? "projection-missing";
  return (
    <main className="ra-battlefield" data-state={stateName} aria-label="红警战场">
      <style>{STYLE}</style>
      {state === undefined ? (
        <div className="ra-error" role="alert"><strong>红警投影暂不可用</strong><p>正在等待同一 session 的权威投影；不会读取浏览器缓存或引擎全量状态。</p></div>
      ) : <StateBody state={state} provider={resourceProvider} descriptor={resourceDescriptor} rendererService={rendererService} onRendererReady={ignoreRendererReady} />}
    </main>
  );
}

type RedAlertBattlefieldDockProps = PropsRuntime<"conversation.session.header.actions"> & {
  readonly layout: ILayout;
  readonly rendererService?: BrowserCommandClientService;
};

/** Session-header control and persistent right-side battlefield beside the canonical Chat view. */
export function RedAlertBattlefieldDock({ useProjection, layout, rendererService }: RedAlertBattlefieldDockProps): JSX.Element {
  const state = useProjection("redAlert");
  const resourceDescriptor = state?.view.resourceArchive ?? DEFAULT_RESOURCE_ARCHIVE;
  const resourceProvider = useMemo(() => createBrowserResourceProvider({
    resourceArchiveUrl: resourceDescriptor.url,
    resourceArchiveSize: resourceDescriptor.byteLength,
    resourceArchiveSha256: resourceDescriptor.sha256,
    resourceArchiveVersion: resourceDescriptor.version,
    resourceArchiveSourceLabel: resourceDescriptor.sourceLabel,
    resourceArchiveLicenseNotice: resourceDescriptor.licenseNotice,
  }), [
    resourceDescriptor.byteLength,
    resourceDescriptor.licenseNotice,
    resourceDescriptor.sha256,
    resourceDescriptor.sourceLabel,
    resourceDescriptor.url,
    resourceDescriptor.version,
  ]);
  const [open, setOpen] = useState(true);
  const [wide, setWide] = useState(false);

  useEffect(() => {
    if (open) layout.openDetails();
  }, [layout, open]);
  useEffect(() => () => layout.closeDetails(), [layout]);

  const toggle = () => {
    setOpen((current) => {
      const next = !current;
      if (!next) layout.closeDetails();
      return next;
    });
  };
  const stateName = state?.status ?? "projection-missing";
  const matchLabel = state?.match === undefined
    ? "等待真实对局"
    : `${state.match.status} · t${state.match.tick} · 左键拖动观战`;
  return (
    <>
      <style>{STYLE}</style>
      <button type="button" className="ra-battlefield-toggle" aria-pressed={open} onClick={toggle}>战场</button>
      {open ? (
        <aside className="ra-side-panel" data-testid="ra-side-battlefield" data-wide={wide} aria-label="红警 2 右侧战场">
          <header className="ra-side-panel-header">
            <div className="ra-side-panel-title"><strong>红警 2 战场</strong><span>{matchLabel}</span></div>
            <button type="button" className="ra-side-panel-control" aria-pressed={wide} onClick={() => setWide((current) => !current)}>{wide ? "还原" : "放大"}</button>
            <button type="button" className="ra-side-panel-control" onClick={toggle}>收起</button>
          </header>
          <div className="ra-side-panel-body">
            <main className="ra-battlefield" data-state={stateName} aria-label="红警战场">
              {state === undefined ? (
                <div className="ra-error" role="alert"><strong>红警投影暂不可用</strong><p>正在等待同一 session 的权威投影；不会读取浏览器缓存或引擎全量状态。</p></div>
              ) : <StateBody state={state} provider={resourceProvider} descriptor={resourceDescriptor} rendererService={rendererService} onRendererReady={ignoreRendererReady} />}
            </main>
          </div>
        </aside>
      ) : null}
    </>
  );
}

/** Register the right-side battlefield without replacing the canonical DSH Chat view. */
export function apply(ctx: Context): void {
  ctx.plugin(BrowserCommandClientService);
  ctx.slots.inject("conversation.session.header.actions", () => ctx.slots.register({
    name: "conversation.session.header.actions",
    id: "red-alert-battlefield",
    order: -20,
    inject: () => ({
      layout: ctx.layout,
      rendererService: ctx.get("redAlertBrowserCommands", false),
    }),
  }, RedAlertBattlefieldDock));
}
