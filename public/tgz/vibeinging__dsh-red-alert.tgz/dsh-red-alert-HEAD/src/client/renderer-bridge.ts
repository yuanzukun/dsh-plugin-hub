import {
  decodeBrowserObservation,
  decodeBrowserMatchSnapshot,
  decodeBrowserCommand,
  decodeBrowserToolValue,
  decodeBrowserToolResult,
  MAX_BROWSER_ORDERS,
  type BrowserCreateMatchRequest,
  type BrowserMatchSnapshot,
  type BrowserGameToolRequest,
  type BrowserToolValue,
  type FogSafeObservation,
} from "../browser-command-protocol.ts";

/** Protocol version for the plugin-owned loopback companion boundary. */
export const RENDERER_PROTOCOL_VERSION = 1 as const;

export type RendererBridgeState = "idle" | "connecting" | "ready" | "disconnected" | "error" | "disposed";

export interface RendererIdentity {
  readonly sessionId: string;
  readonly matchId: string;
  readonly seat: string;
  readonly tick: number;
}

/** Minimal message-event surface used by Window and keyless bridge tests. */
export interface RendererMessageEvent {
  readonly origin: string;
  readonly source: unknown;
  readonly data: unknown;
}

/** Same-browser message transport; the caller binds it to one loopback iframe window. */
export interface RendererMessageEndpoint {
  postMessage(message: unknown, targetOrigin: string): void;
  addEventListener(type: "message", listener: (event: RendererMessageEvent) => void): void;
  removeEventListener(type: "message", listener: (event: RendererMessageEvent) => void): void;
}

export type RendererOrderAction = "build" | "train" | "cancel" | "move" | "attackMove" | "attackTarget" | "retreat" | "deploy";

export interface RendererOrder {
  readonly action: RendererOrderAction;
  readonly target?: string;
  readonly qty?: number;
  readonly units?: string;
  readonly x?: number;
  readonly y?: number;
  readonly contact?: string;
  readonly reason?: string;
}

/** Strict commands accepted by the real renderer companion. */
export type RendererCommand =
  | { readonly type: "create-match"; readonly map?: string; readonly myCountry: string; readonly opponents: number; readonly opponentType: "noop" | "normal"; readonly gameSpeed?: number }
  | { readonly type: "orders"; readonly orders: readonly RendererOrder[] }
  | { readonly type: "tool"; readonly request: BrowserGameToolRequest }
  | { readonly type: "observe" }
  | { readonly type: "stop-match" };

export interface RendererCommandReceipt {
  readonly requestId: string;
  readonly tick: number;
  readonly ok: true;
  readonly detail: string;
  /** The renderer's atomic post-command fair observation, when supplied. */
  readonly observation?: FogSafeObservation;
  readonly match?: BrowserMatchSnapshot;
  readonly toolResult?: BrowserToolValue;
}

export type RendererBridgeErrorCode =
  | "INVALID_MESSAGE"
  | "NOT_READY"
  | "DISCONNECTED"
  | "CANCELLED"
  | "DISPOSED"
  | "COMMAND_REJECTED"
  | "PROTOCOL";

/** A bounded error from the renderer bridge boundary. */
export class RendererBridgeError extends Error {
  constructor(readonly code: RendererBridgeErrorCode, message: string) {
    super(message);
    this.name = "RendererBridgeError";
  }
}

interface RendererEnvelope {
  readonly protocolVersion: typeof RENDERER_PROTOCOL_VERSION;
  readonly sessionId: string;
  readonly matchId: string;
  readonly seat: string;
  readonly tick: number;
  readonly type: string;
}

type RendererWireMessage =
  | (RendererEnvelope & { readonly type: "renderer/hello"; readonly requestId: string })
  | (RendererEnvelope & { readonly type: "renderer/ready"; readonly requestId: string })
  | (RendererEnvelope & { readonly type: "renderer/command"; readonly requestId: string; readonly command: RendererCommand })
  | (RendererEnvelope & { readonly type: "renderer/command-ack"; readonly requestId: string; readonly ok: boolean; readonly detail: string; readonly observation?: FogSafeObservation; readonly match?: BrowserMatchSnapshot; readonly toolResult?: BrowserToolValue })
  | (RendererEnvelope & { readonly type: "renderer/observation"; readonly observation: FogSafeObservation })
  | (RendererEnvelope & { readonly type: "renderer/error"; readonly requestId?: string; readonly code: string; readonly message: string })
  | (RendererEnvelope & { readonly type: "renderer/disconnected"; readonly reason: string })
  | (RendererEnvelope & { readonly type: "renderer/cancel"; readonly requestId: string })
  | (RendererEnvelope & { readonly type: "renderer/dispose" });

export interface RendererBridgeOptions {
  readonly endpoint: RendererMessageEndpoint;
  readonly targetOrigin: string;
  readonly identity: RendererIdentity;
  readonly expectedSource?: unknown;
  /** Attach the message listener immediately for non-React consumers; browser views use attach in an effect. */
  readonly autoAttach?: boolean;
  readonly onObservation?: (observation: FogSafeObservation, tick: number) => void;
  readonly onStateChange?: (state: RendererBridgeState) => void;
}

const ORDER_ACTIONS: readonly RendererOrderAction[] = [
  "build",
  "train",
  "cancel",
  "move",
  "attackMove",
  "attackTarget",
  "retreat",
  "deploy",
];
const MAX_RENDERER_STRING_LENGTH = 512;
const MAX_RENDERER_TYPE_LENGTH = 128;
const ENVELOPE_KEYS: readonly string[] = ["protocolVersion", "sessionId", "matchId", "seat", "tick", "type"];
const ORDER_KEYS = new Set(["action", "target", "qty", "units", "x", "y", "contact", "reason"]);

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function exactKeys(value: Record<string, unknown>, keys: readonly string[], optional: readonly string[] = []): boolean {
  const allowed = new Set([...keys, ...optional]);
  return Object.keys(value).every((key) => allowed.has(key)) && keys.every((key) => Object.hasOwn(value, key));
}

function optionalKeys(value: Record<string, unknown>, keys: readonly string[]): boolean {
  const allowed = new Set(keys);
  return Object.keys(value).every((key) => allowed.has(key));
}

function safeTick(value: unknown): value is number {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}

function safeNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.length > 0 && value.length <= MAX_RENDERER_STRING_LENGTH;
}

function safeType(value: unknown): value is string {
  return typeof value === "string" && value.length > 0 && value.length <= MAX_RENDERER_TYPE_LENGTH;
}

function isRendererOrder(value: unknown): value is RendererOrder {
  if (!isRecord(value) || !Object.hasOwn(value, "action") || !ORDER_ACTIONS.includes(value.action as RendererOrderAction)) return false;
  if (!Object.keys(value).every((key) => ORDER_KEYS.has(key))) return false;
  if (value.target !== undefined && !safeNonEmptyString(value.target)) return false;
  if (value.qty !== undefined && (typeof value.qty !== "number" || !Number.isSafeInteger(value.qty) || value.qty < 1)) return false;
  if (value.units !== undefined && !safeNonEmptyString(value.units)) return false;
  if (value.x !== undefined && !Number.isSafeInteger(value.x)) return false;
  if (value.y !== undefined && !Number.isSafeInteger(value.y)) return false;
  if (value.contact !== undefined && !safeNonEmptyString(value.contact)) return false;
  if (value.reason !== undefined && !safeNonEmptyString(value.reason)) return false;
  return true;
}

function isRendererCommand(value: unknown): value is RendererCommand {
  if (!isRecord(value)) return false;
  if (value.type === "orders") return exactKeys(value, ["type", "orders"])
    && Array.isArray(value.orders)
    && value.orders.length <= MAX_BROWSER_ORDERS
    && value.orders.every(isRendererOrder);
  if (value.type === "observe" || value.type === "stop-match") return exactKeys(value, ["type"]);
  if (value.type === "tool") {
    if (!exactKeys(value, ["type", "request"]) || !isRecord(value.request)) return false;
    try {
      decodeBrowserCommand({
        protocolVersion: 1,
        requestId: "renderer-validation",
        sessionId: "renderer-validation",
        matchId: "renderer-validation",
        seat: "renderer-validation",
        expectedTick: 0,
        kind: "tool",
        request: value.request,
      });
      return true;
    } catch {
      return false;
    }
  }
  if (value.type !== "create-match" || !exactKeys(value, ["type", "myCountry", "opponents", "opponentType"], ["map", "gameSpeed"])) return false;
  const request = value as unknown as BrowserCreateMatchRequest & { readonly type: "create-match" };
  return safeNonEmptyString(request.myCountry)
    && Number.isSafeInteger(request.opponents)
    && request.opponents >= 1
    && request.opponents <= 7
    && (request.opponentType === "noop" || request.opponentType === "normal")
    && (request.gameSpeed === undefined || (Number.isSafeInteger(request.gameSpeed) && request.gameSpeed >= 0 && request.gameSpeed <= 6))
    && (request.map === undefined || safeNonEmptyString(request.map));
}

/** Decode only the strict fair-observation shape accepted from a renderer. */
export function decodeRendererObservation(value: unknown): FogSafeObservation {
  try {
    return decodeBrowserObservation(value);
  } catch {
    throw new RendererBridgeError("INVALID_MESSAGE", "renderer observation is not a bounded FogSafeObservation");
  }
}

function decodeWireMessage(value: unknown): RendererWireMessage {
  if (!isRecord(value) || !exactKeys(value, ENVELOPE_KEYS.concat("requestId"))) {
    if (!isRecord(value) || !optionalKeys(value, ENVELOPE_KEYS.concat("requestId", "command", "ok", "detail", "observation", "match", "toolResult", "code", "message", "reason"))) {
      throw new RendererBridgeError("INVALID_MESSAGE", "renderer message has unknown or missing fields");
    }
  }
  if (value.protocolVersion !== RENDERER_PROTOCOL_VERSION) throw new RendererBridgeError("PROTOCOL", "renderer protocol version is unsupported");
  if (!safeNonEmptyString(value.sessionId) || !safeNonEmptyString(value.matchId) || !safeNonEmptyString(value.seat) || !safeTick(value.tick)) {
    throw new RendererBridgeError("INVALID_MESSAGE", "renderer message identity is invalid");
  }
  if (!safeType(value.type)) throw new RendererBridgeError("INVALID_MESSAGE", "renderer message type is invalid");
  const base = value as unknown as RendererEnvelope;
  switch (value.type) {
    case "renderer/hello":
    case "renderer/ready":
      if (!exactKeys(value, [...ENVELOPE_KEYS, "requestId"]) || !safeNonEmptyString(value.requestId)) throw new RendererBridgeError("INVALID_MESSAGE", "renderer handshake message is invalid");
      return value as unknown as RendererWireMessage;
    case "renderer/command":
      if (!exactKeys(value, [...ENVELOPE_KEYS, "requestId", "command"]) || !safeNonEmptyString(value.requestId) || !isRendererCommand(value.command)) throw new RendererBridgeError("INVALID_MESSAGE", "renderer command message is invalid");
      return value as unknown as RendererWireMessage;
    case "renderer/command-ack":
      if (!exactKeys(value, [...ENVELOPE_KEYS, "requestId", "ok", "detail"], ["observation", "match", "toolResult"]) || !safeNonEmptyString(value.requestId) || typeof value.ok !== "boolean" || !safeNonEmptyString(value.detail)) throw new RendererBridgeError("INVALID_MESSAGE", "renderer command acknowledgement is invalid");
      if (value.observation !== undefined) {
        const observation = decodeRendererObservation(value.observation);
        if (observation.tick !== value.tick) throw new RendererBridgeError("INVALID_MESSAGE", "renderer acknowledgement observation tick does not match its envelope");
      }
      if (value.match !== undefined) decodeBrowserMatchSnapshot(value.match);
      if (value.toolResult !== undefined) decodeBrowserToolValue(value.toolResult);
      return value as unknown as RendererWireMessage;
    case "renderer/observation":
      if (!exactKeys(value, [...ENVELOPE_KEYS, "observation"])) throw new RendererBridgeError("INVALID_MESSAGE", "renderer observation message is invalid");
      decodeRendererObservation(value.observation);
      return value as unknown as RendererWireMessage;
    case "renderer/error":
      if (!optionalKeys(value, [...ENVELOPE_KEYS, "requestId", "code", "message"]) || !safeNonEmptyString(value.code) || !safeNonEmptyString(value.message)) throw new RendererBridgeError("INVALID_MESSAGE", "renderer error message is invalid");
      if (value.requestId !== undefined && !safeNonEmptyString(value.requestId)) throw new RendererBridgeError("INVALID_MESSAGE", "renderer error request id is invalid");
      return value as unknown as RendererWireMessage;
    case "renderer/disconnected":
      if (!exactKeys(value, [...ENVELOPE_KEYS, "reason"]) || !safeNonEmptyString(value.reason)) throw new RendererBridgeError("INVALID_MESSAGE", "renderer disconnect message is invalid");
      return value as unknown as RendererWireMessage;
    case "renderer/cancel":
      if (!exactKeys(value, [...ENVELOPE_KEYS, "requestId"]) || !safeNonEmptyString(value.requestId)) throw new RendererBridgeError("INVALID_MESSAGE", "renderer cancel message is invalid");
      return value as unknown as RendererWireMessage;
    case "renderer/dispose":
      if (!exactKeys(value, ENVELOPE_KEYS)) throw new RendererBridgeError("INVALID_MESSAGE", "renderer dispose message is invalid");
      return value as unknown as RendererWireMessage;
    default:
      void base;
      throw new RendererBridgeError("INVALID_MESSAGE", "renderer message type is not supported");
  }
}

function abortError(message: string): RendererBridgeError {
  return new RendererBridgeError("CANCELLED", message);
}

interface PendingConnect {
  readonly requestId: string;
  readonly resolve: () => void;
  readonly reject: (error: unknown) => void;
  cleanup?: () => void;
}

interface PendingCommand {
  readonly resolve: (receipt: RendererCommandReceipt) => void;
  readonly reject: (error: unknown) => void;
  readonly tick: number;
  readonly command: RendererCommand;
  cleanup?: () => void;
}

/**
 * Owns the loopback companion protocol for one session, match and seat.
 * It never accepts renderer state other than a strict FogSafeObservation.
 */
export class RendererBridge {
  private readonly endpoint: RendererMessageEndpoint;
  private readonly targetOrigin: string;
  private readonly identity: Omit<RendererIdentity, "tick">;
  private readonly expectedSource: unknown;
  private readonly onObservation?: RendererBridgeOptions["onObservation"];
  private readonly onStateChange?: RendererBridgeOptions["onStateChange"];
  private readonly listener: (event: RendererMessageEvent) => void;
  private readonly pendingCommands = new Map<string, PendingCommand>();
  private currentTickValue: number;
  private requestNumber = 0;
  private stateValue: RendererBridgeState = "idle";
  private connectPending: PendingConnect | undefined;
  private connectPromise: Promise<void> | undefined;
  private lastErrorValue: RendererBridgeError | undefined;
  private attached = false;

  constructor(options: RendererBridgeOptions) {
    if (options.targetOrigin.length === 0 || options.targetOrigin === "*") throw new RendererBridgeError("PROTOCOL", "renderer targetOrigin must be explicit");
    if (!safeNonEmptyString(options.identity.sessionId) || !safeNonEmptyString(options.identity.matchId) || !safeNonEmptyString(options.identity.seat) || !safeTick(options.identity.tick)) {
      throw new RendererBridgeError("PROTOCOL", "renderer identity is invalid");
    }
    this.endpoint = options.endpoint;
    this.targetOrigin = options.targetOrigin;
    this.identity = {
      sessionId: options.identity.sessionId,
      matchId: options.identity.matchId,
      seat: options.identity.seat,
    };
    this.currentTickValue = options.identity.tick;
    this.expectedSource = options.expectedSource ?? options.endpoint;
    this.onObservation = options.onObservation;
    this.onStateChange = options.onStateChange;
    this.listener = (event) => {
      this.handleMessage(event);
    };
    if (options.autoAttach === true) this.attach();
  }

  get state(): RendererBridgeState {
    return this.stateValue;
  }

  get currentTick(): number {
    return this.currentTickValue;
  }

  get lastError(): RendererBridgeError | undefined {
    return this.lastErrorValue;
  }

  /** Attach the transport listener; safe to call more than once. */
  attach(): void {
    if (this.stateValue === "disposed") throw new RendererBridgeError("DISPOSED", "renderer bridge is disposed");
    if (this.attached) return;
    this.endpoint.addEventListener("message", this.listener);
    this.attached = true;
  }

  /** Start or repeat the loopback companion handshake. */
  connect(signal?: AbortSignal): Promise<void> {
    if (signal?.aborted) return Promise.reject(abortError("renderer handshake was cancelled before it started"));
    if (this.stateValue === "disposed") return Promise.reject(new RendererBridgeError("DISPOSED", "renderer bridge is disposed"));
    if (this.stateValue === "ready") return Promise.resolve();
    if (this.connectPending !== undefined) return this.connectPromise ?? Promise.reject(new RendererBridgeError("DISCONNECTED", "renderer handshake is unavailable"));
    this.attach();
    const requestId = this.nextRequestId("hello");
    this.setState("connecting");
    const promise = new Promise<void>((resolve, reject) => {
      const pending: PendingConnect = { requestId, resolve, reject };
      this.connectPending = pending;
      if (signal !== undefined) {
        const onAbort = () => {
          if (this.connectPending !== pending) return;
          this.connectPending = undefined;
          this.connectPromise = undefined;
          pending.cleanup?.();
          this.setState("disconnected");
          reject(abortError("renderer handshake was cancelled"));
        };
        signal.addEventListener("abort", onAbort, { once: true });
        pending.cleanup = () => signal.removeEventListener("abort", onAbort);
      }
      try {
        this.post(this.message("renderer/hello", { requestId }));
      } catch (error) {
        this.connectPending = undefined;
        this.connectPromise = undefined;
        pending.cleanup?.();
        this.setState("error");
        reject(error);
      }
    });
    this.connectPromise = promise;
    return promise;
  }

  /** Send a bounded order command after the renderer handshake is ready. */
  sendCommand(command: RendererCommand, signal?: AbortSignal): Promise<RendererCommandReceipt> {
    if (signal?.aborted) return Promise.reject(abortError("renderer command was cancelled before it started"));
    if (this.stateValue === "disposed") return Promise.reject(new RendererBridgeError("DISPOSED", "renderer bridge is disposed"));
    if (this.stateValue !== "ready") return Promise.reject(new RendererBridgeError("NOT_READY", "renderer bridge is not ready"));
    if (!isRendererCommand(command)) return Promise.reject(new RendererBridgeError("INVALID_MESSAGE", "renderer command is invalid"));
    const requestId = this.nextRequestId("command");
    const tick = this.currentTickValue;
    return new Promise<RendererCommandReceipt>((resolve, reject) => {
      const pending: PendingCommand = { resolve, reject, tick, command };
      this.pendingCommands.set(requestId, pending);
      if (signal !== undefined) {
        const onAbort = () => this.cancel(requestId);
        signal.addEventListener("abort", onAbort, { once: true });
        pending.cleanup = () => signal.removeEventListener("abort", onAbort);
      }
      try {
        this.post(this.message("renderer/command", { requestId, command }));
      } catch (error) {
        this.pendingCommands.delete(requestId);
        pending.cleanup?.();
        reject(error);
      }
    });
  }

  /** Cancel one pending command and notify the renderer adapter. */
  cancel(requestId: string): boolean {
    const pending = this.pendingCommands.get(requestId);
    if (pending === undefined) return false;
    this.pendingCommands.delete(requestId);
    pending.cleanup?.();
    try {
      this.post(this.message("renderer/cancel", { requestId }));
    } finally {
      pending.reject(abortError(`renderer command ${requestId} was cancelled`));
    }
    return true;
  }

  /** Validate and dispatch one browser message; false means it was rejected. */
  handleMessage(event: RendererMessageEvent): boolean {
    if (this.stateValue === "disposed" || event.origin !== this.targetOrigin || event.source !== this.expectedSource) return false;
    try {
      const message = decodeWireMessage(event.data);
      if (message.sessionId !== this.identity.sessionId || message.matchId !== this.identity.matchId || message.seat !== this.identity.seat) {
        throw new RendererBridgeError("INVALID_MESSAGE", "renderer message identity does not match this session");
      }
      if (message.type === "renderer/ready") {
        if (this.stateValue !== "connecting") throw new RendererBridgeError("INVALID_MESSAGE", "renderer ready is only valid during handshake");
        if (this.connectPending?.requestId !== message.requestId) throw new RendererBridgeError("INVALID_MESSAGE", "renderer ready request is unknown");
        this.acceptTick(message.tick);
        const pending = this.connectPending;
        this.connectPending = undefined;
        this.connectPromise = undefined;
        pending.cleanup?.();
        this.setState("ready");
        pending.resolve();
        return true;
      }
      if (message.type === "renderer/observation") {
        if (this.stateValue !== "ready") throw new RendererBridgeError("INVALID_MESSAGE", "renderer observation is only valid when ready");
        if (message.observation.tick !== message.tick) {
          throw new RendererBridgeError("INVALID_MESSAGE", "renderer observation tick does not match its envelope");
        }
        this.acceptTick(message.tick);
        this.onObservation?.(decodeRendererObservation(message.observation), message.tick);
        return true;
      }
      if (message.type === "renderer/command-ack") {
        if (this.stateValue !== "ready") throw new RendererBridgeError("INVALID_MESSAGE", "renderer command acknowledgement is only valid when ready");
        const pending = this.pendingCommands.get(message.requestId);
        if (pending === undefined) throw new RendererBridgeError("INVALID_MESSAGE", "renderer acknowledgement request is unknown");
        if (!message.ok) {
          if (message.toolResult !== undefined) throw new RendererBridgeError("INVALID_MESSAGE", "rejected renderer command contains a tool result");
          this.acceptTick(message.tick);
          this.pendingCommands.delete(message.requestId);
          pending.cleanup?.();
          pending.reject(new RendererBridgeError("COMMAND_REJECTED", message.detail));
          return true;
        }
        let toolResult: BrowserToolValue | undefined;
        try {
          if (pending.command.type === "tool") {
            if (message.toolResult === undefined) throw new Error("renderer tool acknowledgement is missing its exact result");
            toolResult = decodeBrowserToolResult(pending.command.request, message.toolResult);
          } else if (message.toolResult !== undefined) {
            throw new Error("renderer non-tool acknowledgement contains a tool result");
          }
        } catch {
          const invalid = new RendererBridgeError("INVALID_MESSAGE", "renderer command result does not match its exact tool");
          this.pendingCommands.delete(message.requestId);
          pending.cleanup?.();
          pending.reject(invalid);
          this.lastErrorValue = invalid;
          return false;
        }
        this.acceptTick(message.tick);
        this.pendingCommands.delete(message.requestId);
        pending.cleanup?.();
        pending.resolve({
          requestId: message.requestId,
          tick: message.tick,
          ok: true,
          detail: message.detail,
          ...(message.observation === undefined ? {} : { observation: decodeRendererObservation(message.observation) }),
          ...(message.match === undefined ? {} : { match: decodeBrowserMatchSnapshot(message.match) }),
          ...(toolResult === undefined ? {} : { toolResult }),
        });
        return true;
      }
      if (message.type === "renderer/error") {
        if (this.stateValue !== "connecting" && this.stateValue !== "ready") throw new RendererBridgeError("INVALID_MESSAGE", "renderer error is not valid in the current state");
        const error = new RendererBridgeError("COMMAND_REJECTED", message.message);
        const wasConnecting = this.stateValue === "connecting";
        this.lastErrorValue = error;
        this.setState("error");
        if (wasConnecting) {
          this.rejectConnect(error);
        } else if (message.requestId !== undefined) {
          const pending = this.pendingCommands.get(message.requestId);
          if (pending !== undefined) {
            this.pendingCommands.delete(message.requestId);
            pending.cleanup?.();
            pending.reject(error);
          }
          this.rejectPending(error);
        } else {
          this.rejectPending(error);
        }
        return true;
      }
      if (message.type === "renderer/disconnected") {
        if (this.stateValue !== "connecting" && this.stateValue !== "ready") throw new RendererBridgeError("INVALID_MESSAGE", "renderer disconnect is not valid in the current state");
        const error = new RendererBridgeError("DISCONNECTED", message.reason);
        this.lastErrorValue = error;
        this.rejectConnect(error);
        this.rejectPending(error);
        this.setState("disconnected");
        return true;
      }
      return false;
    } catch (error) {
      this.lastErrorValue = error instanceof RendererBridgeError
        ? error
        : new RendererBridgeError("INVALID_MESSAGE", error instanceof Error ? error.message : String(error));
      return false;
    }
  }

  /** Stop all transport activity and reject every pending operation. */
  dispose(): void {
    if (this.stateValue === "disposed") return;
    try {
      if (this.stateValue === "ready" || this.stateValue === "connecting") this.post(this.message("renderer/dispose", {}));
    } finally {
      if (this.attached) this.endpoint.removeEventListener("message", this.listener);
      this.attached = false;
      const error = new RendererBridgeError("DISPOSED", "renderer bridge is disposed");
      this.connectPending?.cleanup?.();
      this.connectPending?.reject(error);
      this.connectPending = undefined;
      this.connectPromise = undefined;
      this.rejectPending(error);
      this.setState("disposed");
    }
  }

  private acceptTick(tick: number): void {
    if (tick < this.currentTickValue) throw new RendererBridgeError("INVALID_MESSAGE", "renderer message tick is stale");
    this.currentTickValue = tick;
  }

  private rejectPending(error: unknown): void {
    for (const pending of this.pendingCommands.values()) {
      pending.cleanup?.();
      pending.reject(error);
    }
    this.pendingCommands.clear();
  }

  private rejectConnect(error: unknown): void {
    const pending = this.connectPending;
    if (pending === undefined) return;
    this.connectPending = undefined;
    this.connectPromise = undefined;
    pending.cleanup?.();
    pending.reject(error);
  }

  private setState(state: RendererBridgeState): void {
    this.stateValue = state;
    this.onStateChange?.(state);
  }

  private nextRequestId(kind: string): string {
    this.requestNumber += 1;
    return `red-alert-renderer-${kind}-${this.requestNumber}`;
  }

  private message(type: RendererWireMessage["type"], fields: Record<string, unknown>): RendererWireMessage {
    return {
      protocolVersion: RENDERER_PROTOCOL_VERSION,
      sessionId: this.identity.sessionId,
      matchId: this.identity.matchId,
      seat: this.identity.seat,
      tick: this.currentTickValue,
      type,
      ...fields,
    } as RendererWireMessage;
  }

  private post(message: RendererWireMessage): void {
    this.endpoint.postMessage(message, this.targetOrigin);
  }
}
