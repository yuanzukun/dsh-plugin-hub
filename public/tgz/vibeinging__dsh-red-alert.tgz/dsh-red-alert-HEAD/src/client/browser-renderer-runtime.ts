import type { FogSafeObservation } from "../projection.ts";
import {
  BROWSER_TRANSPORT_PROTOCOL_VERSION,
  type BrowserCommandEnvelope,
  type BrowserCommandReceipt,
} from "../browser-command-protocol.ts";
import {
  decodeRendererObservation,
  RendererBridge,
  type RendererBridgeState,
  type RendererIdentity,
  type RendererMessageEndpoint,
  type RendererOrder,
} from "./renderer-bridge.ts";
import { resolveCompanionUrl, type CompanionOriginOptions } from "./companion-origin.ts";
import type { BrowserAdapterRegistry, BrowserMatchAdapter } from "./browser-command-consumer.ts";

/** Runtime identity used for the renderer and the Host command envelope. */
export type BrowserRendererIdentity = RendererIdentity;

/** Public loopback endpoint metadata; it exposes no renderer or engine state. */
export interface BrowserRendererEndpoint {
  readonly url: string;
  readonly port: number;
}

/** Adapter extension owned by the client root; it never owns the DSH tab. */
export interface BrowserRendererAdapter extends BrowserMatchAdapter {
  /** Endpoint metadata used to reuse a root-owned adapter after view remount. */
  readonly endpoint?: BrowserRendererEndpoint;
  readonly state?: BrowserRendererState;
  /** Test whether this adapter is already bound to the exact live match identity. */
  matchesIdentity?(identity: BrowserRendererIdentity): boolean;
  /** Subscribe to live adapter state; the disposer must remove the listener. */
  subscribeState?(listener: (state: BrowserRendererState) => void): () => void;
  attachRenderer(container: HTMLElement, identity: BrowserRendererIdentity): Promise<void>;
  detachRenderer(container: HTMLElement): Promise<void>;
  dispose(): Promise<void>;
}

export type BrowserRendererState = RendererBridgeState | "unavailable";

/** Stable client-side error for an unavailable or invalid renderer. */
export class BrowserRendererError extends Error {
  constructor(readonly code: "CONFIG" | "IDENTITY" | "NOT_ATTACHED" | "DISPOSED" | "LOAD_FAILED" | "STALE_TICK", message: string) {
    super(message);
    this.name = "BrowserRendererError";
  }
}

function toRendererOrders(command: Extract<BrowserCommandEnvelope, { readonly kind: "orders" }>): readonly RendererOrder[] {
  return command.orders.map((order) => ({
    action: order.action,
    ...(order.target === undefined ? {} : { target: order.target }),
    ...(order.qty === undefined ? {} : { qty: order.qty }),
    ...(order.units === undefined ? {} : { units: order.units }),
    ...(order.x === undefined ? {} : { x: order.x }),
    ...(order.y === undefined ? {} : { y: order.y }),
    ...(order.contact === undefined ? {} : { contact: order.contact }),
    ...(order.reason === undefined ? {} : { reason: order.reason }),
  }));
}

function toRendererCommand(command: BrowserCommandEnvelope): import("./renderer-bridge.ts").RendererCommand {
  if (command.kind === "orders") return { type: "orders", orders: toRendererOrders(command) };
  if (command.kind === "tool") return { type: "tool", request: command.request };
  if (command.kind === "observe") return { type: "observe" };
  if (command.kind === "stop-match") return { type: "stop-match" };
  return {
    type: "create-match",
    ...(command.request.map === undefined ? {} : { map: command.request.map }),
    myCountry: command.request.myCountry,
    opponents: command.request.opponents,
    opponentType: command.request.opponentType,
    ...(command.request.gameSpeed === undefined ? {} : { gameSpeed: command.request.gameSpeed }),
  };
}

function windowEndpoint(parent: Window, child: Window): RendererMessageEndpoint {
  return {
    postMessage(message, targetOrigin) {
      child.postMessage(message, targetOrigin);
    },
    addEventListener(_type, listener) {
      parent.addEventListener("message", listener as unknown as EventListener);
    },
    removeEventListener(_type, listener) {
      parent.removeEventListener("message", listener as unknown as EventListener);
    },
  };
}

function browserReceipt(
  command: BrowserCommandEnvelope,
  tick: number,
  observation: FogSafeObservation,
  match?: import("../browser-command-protocol.ts").BrowserMatchSnapshot,
  toolResult?: import("../browser-command-protocol.ts").BrowserToolValue,
): BrowserCommandReceipt {
  if (observation.tick !== tick) throw new BrowserRendererError("LOAD_FAILED", "renderer acknowledgement observation is not atomic");
  return {
    protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
    requestId: command.requestId,
    sessionId: command.sessionId,
    matchId: command.matchId,
    seat: command.seat,
    tick,
    ok: true,
    detail: "renderer command applied",
    observation,
    ...(match === undefined ? {} : { match }),
    ...(toolResult === undefined ? {} : { toolResult }),
  };
}

function sameIdentity(left: BrowserRendererIdentity | undefined, right: BrowserRendererIdentity): boolean {
  return left !== undefined
    && left.sessionId === right.sessionId
    && left.matchId === right.matchId
    && left.seat === right.seat;
}

function commandKey(command: BrowserCommandEnvelope): string {
  return JSON.stringify(command);
}

interface AttachOperation {
  readonly generation: number;
  readonly identity: BrowserRendererIdentity;
  readonly controller: AbortController;
  readonly promise: Promise<void>;
}

/**
 * Adapter for a user-provided real client served by the plugin-owned loopback
 * server. The iframe stays in a root-owned connected host; the view only
 * changes that host's position and visibility.
 */
export class LoopbackRendererAdapter implements BrowserRendererAdapter {
  readonly endpoint: BrowserRendererEndpoint;
  private readonly parent: Window;
  private readonly url: URL;
  private readonly loadTimeoutMs: number;
  private frame: HTMLIFrameElement | undefined;
  private frameHost: HTMLDivElement | undefined;
  private bridge: RendererBridge | undefined;
  private identity: BrowserRendererIdentity | undefined;
  private readonly commandInFlight = new Map<string, { readonly key: string; readonly promise: Promise<BrowserCommandReceipt> }>();
  private readonly completedCommands = new Map<string, { readonly key: string; readonly receipt: BrowserCommandReceipt }>();
  private readonly commandDrains = new Set<Promise<unknown>>();
  private readonly stateListeners = new Set<(state: BrowserRendererState) => void>();
  private latestObservation: FogSafeObservation | undefined;
  private attachOperation: AttachOperation | undefined;
  private attachGeneration = 0;
  private resizeObserver: ResizeObserver | undefined;
  private observedContainer: HTMLElement | undefined;
  private geometrySync: (() => void) | undefined;
  private attachedContainer: HTMLElement | undefined;
  private disposed = false;
  private disposePromise: Promise<void> | undefined;
  private stateValue: BrowserRendererState = "unavailable";

  constructor(options: {
    readonly url: string;
    readonly parentOrigin: string;
    readonly origin?: CompanionOriginOptions;
    readonly parentWindow?: Window;
    readonly loadTimeoutMs?: number;
  }) {
    const parent = options.parentWindow ?? globalThis.window;
    if (parent === undefined) throw new BrowserRendererError("CONFIG", "renderer requires a browser window");
    this.parent = parent;
    this.url = resolveCompanionUrl(options.url, options.parentOrigin, options.origin);
    this.endpoint = { url: this.url.href, port: Number(this.url.port) };
    this.loadTimeoutMs = options.loadTimeoutMs ?? 15_000;
    if (!Number.isSafeInteger(this.loadTimeoutMs) || this.loadTimeoutMs < 1) throw new BrowserRendererError("CONFIG", "renderer loadTimeoutMs must be positive");
  }

  get state(): BrowserRendererState {
    return this.stateValue;
  }

  matchesIdentity(identity: BrowserRendererIdentity): boolean {
    return sameIdentity(this.identity, identity);
  }

  subscribeState(listener: (state: BrowserRendererState) => void): () => void {
    this.stateListeners.add(listener);
    listener(this.stateValue);
    return () => this.stateListeners.delete(listener);
  }

  async attachRenderer(container: HTMLElement, identity: BrowserRendererIdentity): Promise<void> {
    if (this.disposed) throw new BrowserRendererError("DISPOSED", "renderer adapter is disposed");
    this.attachedContainer = container;
    const current = this.attachOperation;
    if (current !== undefined) {
      if (sameIdentity(current.identity, identity)) {
        await current.promise;
        if (this.disposed || current.generation !== this.attachGeneration) throw new BrowserRendererError("DISPOSED", "renderer attachment was cancelled");
        this.showFrame(container);
        return;
      }
      this.invalidateAttachment();
      await current.promise.catch(() => undefined);
    }
    const generation = ++this.attachGeneration;
    const controller = new AbortController();
    const operation: AttachOperation = {
      generation,
      identity,
      controller,
      promise: this.attachInternal(container, identity, generation, controller.signal),
    };
    this.attachOperation = operation;
    try {
      await operation.promise;
    } finally {
      if (this.attachOperation === operation) this.attachOperation = undefined;
    }
  }

  /** Hide the fixed host and cancel only unfinished attachment work. */
  async detachRenderer(container: HTMLElement): Promise<void> {
    if (this.attachedContainer !== container) return;
    this.attachedContainer = undefined;
    this.invalidateAttachment();
    this.stopGeometrySync();
    if (this.frameHost !== undefined) {
      this.frameHost.style.visibility = "hidden";
      this.frameHost.style.pointerEvents = "none";
    }
    const operation = this.attachOperation;
    if (operation !== undefined) await operation.promise.catch(() => undefined);
  }

  command(command: BrowserCommandEnvelope, signal: AbortSignal): Promise<BrowserCommandReceipt> {
    if (this.disposed) return Promise.reject(new BrowserRendererError("DISPOSED", "renderer adapter is disposed"));
    if (signal.aborted) return Promise.reject(new BrowserRendererError("DISPOSED", "renderer command was cancelled"));
    if (this.bridge?.state !== "ready") {
      return this.waitUntilReady(signal).then(() => this.command(command, signal));
    }
    const identity = this.identity;
    const bridge = this.bridge;
    if (identity === undefined || bridge === undefined) return Promise.reject(new BrowserRendererError("NOT_ATTACHED", "renderer adapter is not ready"));
    if (command.sessionId !== identity.sessionId || command.matchId !== identity.matchId || command.seat !== identity.seat) {
      return Promise.reject(new BrowserRendererError("IDENTITY", "renderer command identity does not match the active adapter"));
    }
    if (command.expectedTick > bridge.currentTick) return Promise.reject(new BrowserRendererError("STALE_TICK", "renderer command tick is from the future"));
    for (const order of command.kind === "orders" ? command.orders : []) {
      if (order.action !== "attackTarget") continue;
      const target = order.contact ?? order.target;
      if (target === undefined || this.latestObservation?.visibleEnemies.every(
        (contact) => String(contact.id) !== target && contact.unitType !== target,
      ) !== false) {
        return Promise.reject(new BrowserRendererError("IDENTITY", "attack target is not currently visible to the renderer seat"));
      }
    }
    const key = commandKey(command);
    const completed = this.completedCommands.get(command.requestId);
    if (completed !== undefined) {
      if (completed.key !== key) return Promise.reject(new BrowserRendererError("IDENTITY", "renderer requestId was reused with different command data"));
      return Promise.resolve(completed.receipt);
    }
    const active = this.commandInFlight.get(command.requestId);
    if (active !== undefined) {
      if (active.key !== key) return Promise.reject(new BrowserRendererError("IDENTITY", "renderer requestId is already in flight"));
      return active.promise;
    }
    const promise = bridge.sendCommand(toRendererCommand(command), signal).then((receipt) => {
      if (receipt.observation === undefined) throw new BrowserRendererError("LOAD_FAILED", "renderer acknowledgement omitted its fair observation");
      const observation = decodeRendererObservation(receipt.observation);
      this.latestObservation = observation;
      if (command.kind !== "orders" && receipt.match === undefined) {
        throw new BrowserRendererError("LOAD_FAILED", "renderer acknowledgement omitted its public match snapshot");
      }
      const safeReceipt = browserReceipt(command, receipt.tick, observation, receipt.match, receipt.toolResult);
      this.completedCommands.set(command.requestId, { key, receipt: safeReceipt });
      while (this.completedCommands.size > 128) this.completedCommands.delete(this.completedCommands.keys().next().value as string);
      return safeReceipt;
    });
    this.commandInFlight.set(command.requestId, { key, promise });
    this.commandDrains.add(promise);
    const cleanup = () => {
      this.commandInFlight.delete(command.requestId);
      this.commandDrains.delete(promise);
    };
    void promise.then(cleanup, cleanup);
    return promise;
  }

  private waitUntilReady(signal: AbortSignal): Promise<void> {
    if (this.bridge?.state === "ready") return Promise.resolve();
    if (this.disposed) return Promise.reject(new BrowserRendererError("DISPOSED", "renderer adapter is disposed"));
    if (signal.aborted) return Promise.reject(new BrowserRendererError("DISPOSED", "renderer command was cancelled"));
    return new Promise<void>((resolve, reject) => {
      let settled = false;
      let stop: () => void = () => undefined;
      let timer: ReturnType<typeof setTimeout> | undefined;
      const finish = (error?: BrowserRendererError) => {
        if (settled) return;
        settled = true;
        if (timer !== undefined) clearTimeout(timer);
        signal.removeEventListener("abort", onAbort);
        stop();
        if (error === undefined) resolve();
        else reject(error);
      };
      const onAbort = () => finish(new BrowserRendererError("DISPOSED", "renderer command was cancelled"));
      const onState = (state: BrowserRendererState) => {
        if (state === "ready") finish();
        else if (state === "error" || state === "disconnected" || state === "disposed") {
          finish(new BrowserRendererError("NOT_ATTACHED", "renderer adapter did not become ready"));
        }
      };
      signal.addEventListener("abort", onAbort, { once: true });
      timer = setTimeout(
        () => finish(new BrowserRendererError("NOT_ATTACHED", "renderer adapter did not become ready before timeout")),
        this.loadTimeoutMs,
      );
      stop = this.subscribeState(onState);
      if (settled) stop();
    });
  }

  dispose(): Promise<void> {
    if (this.disposePromise !== undefined) return this.disposePromise;
    this.disposed = true;
    this.disposePromise = this.disposeInternal();
    return this.disposePromise;
  }

  private async disposeInternal(): Promise<void> {
    this.invalidateAttachment();
    const operation = this.attachOperation;
    if (operation !== undefined) await operation.promise.catch(() => undefined);
    let bridgeError: unknown;
    try {
      await this.disposeBridge();
    } catch (error) {
      bridgeError = error;
    }
    await Promise.allSettled(this.commandDrains);
    this.stopGeometrySync();
    this.frameHost?.remove();
    this.frameHost = undefined;
    this.frame = undefined;
    this.identity = undefined;
    this.latestObservation = undefined;
    this.attachedContainer = undefined;
    this.setState("disposed");
    if (bridgeError !== undefined) throw bridgeError;
  }

  private async attachInternal(container: HTMLElement, identity: BrowserRendererIdentity, generation: number, signal: AbortSignal): Promise<void> {
    this.assertGeneration(generation, signal);
    if (sameIdentity(this.identity, identity) && this.bridge?.state === "ready") {
      this.identity = identity;
      this.showFrame(container);
      return;
    }
    if (this.identity !== undefined && !sameIdentity(this.identity, identity)) await this.resetForIdentity(signal, generation);
    this.identity = identity;
    await this.ensureFrame(signal, generation);
    this.assertGeneration(generation, signal);
    const child = this.frame?.contentWindow;
    if (child === null || child === undefined) throw new BrowserRendererError("LOAD_FAILED", "renderer iframe has no contentWindow");
    if (this.bridge?.state === "ready") {
      this.showFrame(container);
      return;
    }
    await this.disposeBridge();
    let bridge: RendererBridge | undefined;
    bridge = new RendererBridge({
      endpoint: windowEndpoint(this.parent, child),
      targetOrigin: this.url.origin,
      expectedSource: child,
      identity,
      autoAttach: true,
      onObservation: (observation) => { if (this.bridge === bridge) this.latestObservation = observation; },
      onStateChange: (state) => { if (this.bridge === bridge) this.setState(state); },
    });
    this.bridge = bridge;
    await this.connectWithTimeout(bridge, signal, generation);
    this.assertGeneration(generation, signal);
    this.showFrame(container);
  }

  private invalidateAttachment(): void {
    this.attachGeneration += 1;
    this.attachOperation?.controller.abort();
  }

  private assertGeneration(generation: number, signal: AbortSignal): void {
    if (this.disposed || signal.aborted || generation !== this.attachGeneration) throw new BrowserRendererError("DISPOSED", "renderer attachment is no longer current");
  }

  private async ensureFrame(signal: AbortSignal, generation: number): Promise<void> {
    if (this.frame !== undefined) return;
    const body = this.parent.document.body;
    if (body === null) throw new BrowserRendererError("LOAD_FAILED", "renderer document has no body");
    const host = this.parent.document.createElement("div");
    host.setAttribute("data-red-alert-renderer-host", "root-owned");
    host.style.position = "fixed";
    host.style.inset = "";
    host.style.zIndex = "20";
    host.style.visibility = "hidden";
    host.style.pointerEvents = "none";
    const frame = this.parent.document.createElement("iframe");
    frame.title = "用户自备红警兼容客户端";
    // The companion derives the one allowed parent origin from this origin-only
    // referrer, then still checks MessageEvent.origin and source on every frame.
    frame.referrerPolicy = "origin";
    frame.setAttribute("sandbox", "allow-scripts allow-same-origin");
    frame.setAttribute("data-red-alert-renderer", "user-provided-loopback");
    frame.style.width = "100%";
    frame.style.height = "100%";
    frame.style.border = "0";
    host.append(frame);
    body.append(host);
    this.frameHost = host;
    this.frame = frame;
    const loadPromise = this.waitForLoad(frame, signal);
    frame.src = this.url.href;
    await loadPromise;
    this.assertGeneration(generation, signal);
  }

  private showFrame(container: HTMLElement): void {
    if (this.frameHost === undefined) return;
    const rect = container.getBoundingClientRect();
    this.frameHost.style.left = `${rect.left}px`;
    this.frameHost.style.top = `${rect.top}px`;
    this.frameHost.style.width = `${rect.width}px`;
    this.frameHost.style.height = `${rect.height}px`;
    this.frameHost.style.visibility = "visible";
    this.frameHost.style.pointerEvents = "auto";
    this.startGeometrySync(container);
  }

  private startGeometrySync(container: HTMLElement): void {
    this.stopGeometrySync();
    this.observedContainer = container;
    const sync = () => {
      if (this.observedContainer === container) this.showFrameGeometry(container);
    };
    this.geometrySync = sync;
    this.parent.addEventListener("resize", sync);
    this.parent.addEventListener("scroll", sync, true);
    if (typeof ResizeObserver !== "undefined") {
      this.resizeObserver = new ResizeObserver(sync);
      this.resizeObserver.observe(container);
    }
  }

  private showFrameGeometry(container: HTMLElement): void {
    if (this.frameHost === undefined) return;
    const rect = container.getBoundingClientRect();
    this.frameHost.style.inset = "";
    this.frameHost.style.left = `${rect.left}px`;
    this.frameHost.style.top = `${rect.top}px`;
    this.frameHost.style.width = `${rect.width}px`;
    this.frameHost.style.height = `${rect.height}px`;
  }

  private stopGeometrySync(): void {
    const sync = this.geometrySync;
    if (sync !== undefined) {
      this.parent.removeEventListener("resize", sync);
      this.parent.removeEventListener("scroll", sync, true);
    }
    this.resizeObserver?.disconnect();
    this.resizeObserver = undefined;
    this.observedContainer = undefined;
    this.geometrySync = undefined;
  }

  private async resetForIdentity(signal: AbortSignal, generation: number): Promise<void> {
    await this.disposeBridge();
    await this.awaitCommandDrains();
    this.commandInFlight.clear();
    this.completedCommands.clear();
    this.latestObservation = undefined;
    const frame = this.frame;
    if (frame === undefined) return;
    const blankLoad = this.waitForLoad(frame, signal);
    frame.src = "about:blank";
    await blankLoad;
    this.assertGeneration(generation, signal);
    const nextLoad = this.waitForLoad(frame, signal);
    frame.src = this.url.href;
    await nextLoad;
  }

  private async connectWithTimeout(bridge: RendererBridge, parentSignal: AbortSignal, generation: number): Promise<void> {
    if (parentSignal.aborted) throw new BrowserRendererError("DISPOSED", "renderer handshake was cancelled");
    const controller = new AbortController();
    const abort = () => controller.abort();
    parentSignal.addEventListener("abort", abort, { once: true });
    const timer = setTimeout(() => controller.abort(), this.loadTimeoutMs);
    try {
      await bridge.connect(controller.signal);
      this.assertGeneration(generation, parentSignal);
    } catch {
      if (this.bridge === bridge) this.bridge = undefined;
      bridge.dispose();
      if (!this.disposed) this.setState(parentSignal.aborted ? "disconnected" : "error");
      if (parentSignal.aborted) throw new BrowserRendererError("DISPOSED", "renderer handshake was cancelled");
      throw new BrowserRendererError("LOAD_FAILED", "renderer handshake failed or timed out");
    } finally {
      clearTimeout(timer);
      parentSignal.removeEventListener("abort", abort);
    }
  }

  private async disposeBridge(): Promise<void> {
    const bridge = this.bridge;
    this.bridge = undefined;
    if (bridge !== undefined) bridge.dispose();
  }

  private setState(state: BrowserRendererState): void {
    this.stateValue = state;
    for (const listener of this.stateListeners) listener(state);
  }

  private async awaitCommandDrains(): Promise<void> {
    while (this.commandDrains.size > 0) {
      await Promise.allSettled(this.commandDrains);
    }
  }

  private waitForLoad(frame: HTMLIFrameElement, signal: AbortSignal): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      if (signal.aborted) {
        reject(new BrowserRendererError("DISPOSED", "renderer iframe load was cancelled"));
        return;
      }
      let settled = false;
      const finish = (error?: BrowserRendererError) => {
        if (settled) return;
        settled = true;
        frame.removeEventListener("load", onLoad);
        frame.removeEventListener("error", onError);
        signal.removeEventListener("abort", onAbort);
        clearTimeout(timer);
        if (error === undefined) resolve();
        else reject(error);
      };
      const onLoad = () => finish();
      const onError = () => finish(new BrowserRendererError("LOAD_FAILED", "renderer iframe failed to load"));
      const onAbort = () => finish(new BrowserRendererError("DISPOSED", "renderer iframe load was cancelled"));
      const timer = setTimeout(() => finish(new BrowserRendererError("LOAD_FAILED", "renderer iframe load timed out")), this.loadTimeoutMs);
      frame.addEventListener("load", onLoad, { once: true });
      frame.addEventListener("error", onError, { once: true });
      signal.addEventListener("abort", onAbort, { once: true });
    });
  }
}

interface OwnedAdapter {
  readonly adapter: BrowserRendererAdapter;
  readonly unregister: () => void;
  removal?: Promise<void>;
}

/** Root-owned runtime that keeps adapters alive when React tabs are switched. */
export class BrowserRendererRuntime {
  private readonly registry: BrowserAdapterRegistry;
  private readonly owned = new Map<string, OwnedAdapter>();
  private readonly removalDrains = new Map<string, Promise<void>>();
  private disposed = false;
  private disposePromise: Promise<void> | undefined;

  constructor(registry: BrowserAdapterRegistry) {
    this.registry = registry;
  }

  register(sessionId: string, adapter: BrowserRendererAdapter): () => Promise<void> {
    if (this.disposed) throw new BrowserRendererError("DISPOSED", "renderer runtime is disposed");
    if (this.owned.has(sessionId)) throw new BrowserRendererError("CONFIG", "renderer already registered for this session");
    if (this.removalDrains.has(sessionId)) throw new BrowserRendererError("CONFIG", "renderer session removal is still in progress");
    const unregister = this.registry.register(sessionId, adapter);
    const entry: OwnedAdapter = { adapter, unregister };
    this.owned.set(sessionId, entry);
    return () => this.remove(sessionId, entry);
  }

  registerLoopback(sessionId: string, options: ConstructorParameters<typeof LoopbackRendererAdapter>[0]): { readonly adapter: LoopbackRendererAdapter; readonly remove: () => Promise<void> } {
    const adapter = new LoopbackRendererAdapter(options);
    return { adapter, remove: this.register(sessionId, adapter) };
  }

  get(sessionId: string): BrowserRendererAdapter | undefined {
    return this.owned.get(sessionId)?.adapter;
  }

  /** Read the current renderer lifecycle state without exposing renderer data. */
  getState(sessionId: string): BrowserRendererState {
    return this.owned.get(sessionId)?.adapter.state ?? "unavailable";
  }

  /** Read the current adapter endpoint without exposing renderer or engine state. */
  getEndpoint(sessionId: string): BrowserRendererEndpoint | undefined {
    const endpoint = this.owned.get(sessionId)?.adapter.endpoint;
    return endpoint === undefined ? undefined : { url: endpoint.url, port: endpoint.port };
  }

  /** Test whether the session adapter is already bound to the exact live match. */
  matchesIdentity(sessionId: string, identity: BrowserRendererIdentity): boolean {
    return this.owned.get(sessionId)?.adapter.matchesIdentity?.(identity) ?? false;
  }

  /** Subscribe to one session's renderer lifecycle; a missing subscription is a no-op. */
  subscribeState(sessionId: string, listener: (state: BrowserRendererState) => void): () => void {
    const adapter = this.owned.get(sessionId)?.adapter;
    if (adapter === undefined || adapter.subscribeState === undefined) return () => undefined;
    return adapter.subscribeState(listener);
  }

  async attach(sessionId: string, container: HTMLElement, identity: BrowserRendererIdentity): Promise<void> {
    const adapter = this.get(sessionId);
    if (adapter === undefined) throw new BrowserRendererError("NOT_ATTACHED", "no renderer adapter is registered for this session");
    await adapter.attachRenderer(container, identity);
  }

  async detach(sessionId: string, container: HTMLElement): Promise<void> {
    const adapter = this.get(sessionId);
    if (adapter !== undefined) await adapter.detachRenderer(container);
  }

  /** Remove one session-owned adapter at the root lifecycle boundary. */
  removeSession(sessionId: string): Promise<void> {
    const entry = this.owned.get(sessionId);
    if (entry !== undefined) return this.remove(sessionId, entry);
    return this.removalDrains.get(sessionId) ?? Promise.resolve();
  }

  dispose(): Promise<void> {
    if (this.disposePromise !== undefined) return this.disposePromise;
    this.disposePromise = this.disposeInternal();
    return this.disposePromise;
  }

  private remove(sessionId: string, entry: OwnedAdapter): Promise<void> {
    if (entry.removal !== undefined) return entry.removal;
    const removal = (async () => {
      if (this.owned.get(sessionId) === entry) this.owned.delete(sessionId);
      let unregisterError: unknown;
      try {
        entry.unregister();
      } catch (error) {
        unregisterError = error;
      }
      try {
        await entry.adapter.dispose();
      } catch (error) {
        if (unregisterError === undefined) throw error;
        throw new AggregateError([unregisterError, error], "renderer adapter removal failed");
      }
      if (unregisterError !== undefined) throw unregisterError;
      })();
    entry.removal = removal;
    this.removalDrains.set(sessionId, removal);
    void removal.then(
      () => {
        if (this.removalDrains.get(sessionId) === removal) this.removalDrains.delete(sessionId);
      },
      () => {
        if (this.removalDrains.get(sessionId) === removal) this.removalDrains.delete(sessionId);
      },
    );
    return removal;
  }

  private async disposeInternal(): Promise<void> {
    this.disposed = true;
    const entries = [...this.owned.entries()];
    const drains = new Set<Promise<void>>();
    for (const [sessionId, entry] of entries) drains.add(this.remove(sessionId, entry));
    for (const drain of this.removalDrains.values()) drains.add(drain);
    const results = await Promise.allSettled(drains);
    const errors = results.flatMap((result) => result.status === "rejected" ? [result.reason] : []);
    if (errors.length === 1) throw errors[0];
    if (errors.length > 1) throw new AggregateError(errors, "renderer runtime disposal failed");
  }
}
