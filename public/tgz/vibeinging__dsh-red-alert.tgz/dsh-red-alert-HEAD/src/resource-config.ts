/** Public archive metadata shared by the host configuration and browser face. */
export interface ResourceArchiveDescriptor {
  readonly id: string;
  readonly url: string;
  readonly byteLength: number;
  readonly sha256: string;
  readonly version: string;
  readonly sourceLabel: string;
  readonly licenseNotice: string;
}

/** Configuration overrides for the user-triggered browser resource import. */
export interface ResourceArchiveConfig {
  readonly resourceArchiveUrl?: string;
  readonly resourceArchiveSize?: number;
  readonly resourceArchiveSha256?: string;
  readonly resourceArchiveVersion?: string;
  readonly resourceArchiveSourceLabel?: string;
  readonly resourceArchiveLicenseNotice?: string;
}

/** The public RA2WEB candidate recorded by the compatibility client's config.ini. */
export const DEFAULT_RESOURCE_ARCHIVE: ResourceArchiveDescriptor = {
  id: "ra2web-full-pack-2024-09-30",
  url: "https://download.ra2web.com/full-pack.7z",
  byteLength: 140_316_786,
  sha256: "3119b300794839ab597df556df8718c0a0a28fe89648ddced1c3790d801cb646",
  version: "2024-09-30",
  sourceLabel: "RA2WEB public full-pack endpoint",
  licenseNotice: "User-triggered import only; EA and third-party game and asset rights remain applicable.",
};

function requiredString(name: string, value: string | undefined, fallback: string): string {
  const resolved = value ?? fallback;
  if (resolved.length === 0) throw new Error(`resource archive ${name} must not be empty`);
  return resolved;
}

/** Resolve and validate the public archive descriptor without performing network I/O. */
export function resolveResourceArchiveDescriptor(config: ResourceArchiveConfig = {}): ResourceArchiveDescriptor {
  const url = requiredString("URL", config.resourceArchiveUrl, DEFAULT_RESOURCE_ARCHIVE.url);
  let parsedUrl: URL;
  try {
    parsedUrl = new URL(url);
  } catch {
    throw new Error(`resource archive URL is invalid: ${url}`);
  }
  if (parsedUrl.protocol !== "http:" && parsedUrl.protocol !== "https:") {
    throw new Error("resource archive URL must use http or https");
  }

  const byteLength = config.resourceArchiveSize ?? DEFAULT_RESOURCE_ARCHIVE.byteLength;
  if (!Number.isSafeInteger(byteLength) || byteLength < 1) {
    throw new Error("resource archive size must be a positive safe integer");
  }
  const sha256 = requiredString("SHA-256", config.resourceArchiveSha256, DEFAULT_RESOURCE_ARCHIVE.sha256).toLowerCase();
  if (!/^[a-f0-9]{64}$/.test(sha256)) throw new Error("resource archive SHA-256 must be 64 hexadecimal characters");
  const isDefaultCandidate = sha256 === DEFAULT_RESOURCE_ARCHIVE.sha256
    && url === DEFAULT_RESOURCE_ARCHIVE.url
    && byteLength === DEFAULT_RESOURCE_ARCHIVE.byteLength;
  const version = requiredString("version", config.resourceArchiveVersion, isDefaultCandidate ? DEFAULT_RESOURCE_ARCHIVE.version : "custom");
  const sourceLabel = requiredString("source label", config.resourceArchiveSourceLabel, isDefaultCandidate ? DEFAULT_RESOURCE_ARCHIVE.sourceLabel : "User-configured resource archive");
  const licenseNotice = requiredString("license notice", config.resourceArchiveLicenseNotice, isDefaultCandidate
    ? DEFAULT_RESOURCE_ARCHIVE.licenseNotice
    : "User-configured archive; verify source, rights and permitted use before importing.");
  const id = isDefaultCandidate
    ? DEFAULT_RESOURCE_ARCHIVE.id
    : `red-alert-resource-${sha256.slice(0, 16)}`;
  return { id, url, byteLength, sha256, version, sourceLabel, licenseNotice };
}
