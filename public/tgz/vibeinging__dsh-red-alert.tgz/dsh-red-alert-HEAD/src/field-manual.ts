/** Durable event containing the exact built-in manual page exposed to the model. */
export const RED_ALERT_FIELD_MANUAL_EVENT = "red-alert/field-manual" as const;

/** Small manual topics that can be loaded independently before a match. */
export const FIELD_MANUAL_TOPICS = [
  "structures",
  "infantry",
  "vehicles-air",
  "opening",
  "combat",
] as const;

/** Faction filter accepted by the built-in manual. */
export const FIELD_MANUAL_FACTIONS = ["soviet", "allied", "general"] as const;

/** One independently loadable built-in manual topic. */
export type FieldManualTopic = typeof FIELD_MANUAL_TOPICS[number];
/** One faction filter for a manual topic. */
export type FieldManualFaction = typeof FIELD_MANUAL_FACTIONS[number];

/** One rules.ini-backed unit or structure summary. */
export interface FieldManualEntry {
  readonly id: string;
  readonly name: string;
  readonly faction: FieldManualFaction;
  readonly cost: number;
  readonly prerequisites: readonly string[];
  readonly role: string;
  readonly use: string;
  readonly warning?: string;
}

/** Exact manual page recorded before it reaches the model. */
export interface FieldManualPage {
  readonly version: 1;
  readonly sessionId: string;
  readonly topic: FieldManualTopic;
  readonly faction: FieldManualFaction;
  readonly title: string;
  readonly rules: readonly string[];
  readonly entries: readonly FieldManualEntry[];
  readonly sources: readonly {
    readonly kind: "ruleset" | "guide" | "battle-review";
    readonly label: string;
  }[];
  readonly fairness: string;
}

declare module "@deepseek-ai/dsh-session" {
  interface SessionEventMap {
    /** Exact built-in battlefield manual page exposed to the model. */
    "red-alert/field-manual": FieldManualPage;
  }
}

declare module "@deepseek-ai/dsh-session/types" {
  interface SessionEventMap {
    /** Exact built-in battlefield manual page exposed to the model. */
    "red-alert/field-manual": FieldManualPage;
  }
}

const STRUCTURES: readonly FieldManualEntry[] = [
  { id: "NACNST", name: "Soviet Construction Yard", faction: "soviet", cost: 3000, prerequisites: [], role: "Base construction", use: "Keep it alive; it unlocks and places Soviet structures." },
  { id: "NAPOWR", name: "Tesla Reactor", faction: "soviet", cost: 600, prerequisites: ["NACNST"], role: "Power", use: "Build first and add power before the base enters low power." },
  { id: "NAREFN", name: "Soviet Ore Refinery", faction: "soviet", cost: 2000, prerequisites: ["POWER", "NACNST"], role: "Economy", use: "Place near reachable ore after power; protect the miner route." },
  { id: "NAHAND", name: "Soviet Barracks", faction: "soviet", cost: 500, prerequisites: ["POWER", "NACNST"], role: "Infantry production", use: "Unlock cheap defenders, dogs, engineers, and later specialist infantry." },
  { id: "NALASR", name: "Sentry Gun", faction: "soviet", cost: 500, prerequisites: ["BARRACKS", "NACNST"], role: "Anti-infantry defense", use: "Place on a currently visible approach, between the rush and key production." },
  { id: "NAWEAP", name: "Soviet War Factory", faction: "soviet", cost: 2000, prerequisites: ["PROC", "NAHAND", "NACNST"], role: "Land vehicle production", use: "Build for miners, Rhino tanks, Flak Tracks, V3 launchers, and late armor.", warning: "This is the Soviet land war factory. Do not confuse it with NAYARD." },
  { id: "NARADR", name: "Radar Tower", faction: "soviet", cost: 1000, prerequisites: ["NAREFN", "NACNST"], role: "Radar and tech", use: "Unlocks radar-tier units after the anti-rush core is stable." },
  { id: "NADEPT", name: "Soviet Service Depot", faction: "soviet", cost: 800, prerequisites: ["NAWEAP", "NACNST"], role: "Vehicle repair", use: "Use when damaged armor can retreat safely for repair." },
  { id: "NATECH", name: "Soviet Battle Lab", faction: "soviet", cost: 2000, prerequisites: ["NAWEAP", "RADAR", "NACNST"], role: "Late technology", use: "Delay until economy and the first defense force are secure." },
  { id: "NAYARD", name: "Soviet Shipyard", faction: "soviet", cost: 1000, prerequisites: ["PROC", "POWER", "NACNST"], role: "Naval production", use: "Build only for a planned naval force on a map with a legal visible shoreline.", warning: "NAYARD is not a land war factory." },
  { id: "GACNST", name: "Allied Construction Yard", faction: "allied", cost: 3000, prerequisites: [], role: "Base construction", use: "Keep it alive; it unlocks and places Allied structures." },
  { id: "GAPOWR", name: "Power Plant", faction: "allied", cost: 800, prerequisites: ["GACNST"], role: "Power", use: "Build first and add power before the base enters low power." },
  { id: "GAREFN", name: "Allied Ore Refinery", faction: "allied", cost: 2000, prerequisites: ["POWER", "GACNST"], role: "Economy", use: "Place near reachable ore after power; protect the miner route." },
  { id: "GAPILE", name: "Allied Barracks", faction: "allied", cost: 500, prerequisites: ["POWER", "GACNST"], role: "Infantry production", use: "Unlock GIs, dogs, engineers, and later specialist infantry." },
  { id: "GAPILL", name: "Pill Box", faction: "allied", cost: 500, prerequisites: ["BARRACKS", "GACNST"], role: "Anti-infantry defense", use: "Place on a currently visible approach, between the rush and key production." },
  { id: "GAWEAP", name: "Allied War Factory", faction: "allied", cost: 2000, prerequisites: ["PROC", "GAPILE", "GACNST"], role: "Land vehicle production", use: "Build for miners, Grizzly tanks, IFVs, and late Allied armor.", warning: "This is the Allied land war factory. Do not confuse it with GAYARD." },
  { id: "GAAIRC", name: "Airforce Command Headquarters", faction: "allied", cost: 1000, prerequisites: ["GAREFN", "GACNST"], role: "Radar and aircraft production", use: "Unlocks radar-tier options and builds Allied aircraft." },
  { id: "GADEPT", name: "Allied Service Depot", faction: "allied", cost: 800, prerequisites: ["GAWEAP", "GACNST"], role: "Vehicle repair", use: "Use when damaged armor can retreat safely for repair." },
  { id: "GATECH", name: "Allied Battle Lab", faction: "allied", cost: 2000, prerequisites: ["GAWEAP", "RADAR", "GACNST"], role: "Late technology", use: "Delay until economy and the first defense force are secure." },
  { id: "GAYARD", name: "Allied Shipyard", faction: "allied", cost: 1000, prerequisites: ["PROC", "POWER", "GACNST"], role: "Naval production", use: "Build only for a planned naval force on a map with a legal visible shoreline.", warning: "GAYARD is not a land war factory." },
];

const INFANTRY: readonly FieldManualEntry[] = [
  { id: "E2", name: "Conscript", faction: "soviet", cost: 100, prerequisites: ["NAHAND"], role: "Cheap line infantry", use: "Mass early for anti-rush defense and as a screen in front of armor." },
  { id: "FLAKT", name: "Flak Trooper", faction: "soviet", cost: 300, prerequisites: ["NAHAND", "NARADR"], role: "Anti-air infantry", use: "Mix into a force only after air threats are possible or visible." },
  { id: "SHK", name: "Tesla Trooper", faction: "soviet", cost: 500, prerequisites: ["NAHAND"], role: "Heavy infantry", use: "Support a defensive line against vehicles; avoid sending it alone." },
  { id: "E1", name: "GI", faction: "allied", cost: 200, prerequisites: ["GAPILE"], role: "Basic Allied infantry", use: "Use as the early defensive line; deploy at a safe firing position when the renderer tool supports it." },
  { id: "JUMPJET", name: "Rocketeer", faction: "allied", cost: 600, prerequisites: ["GAPILE", "RADAR"], role: "Flying scout and skirmisher", use: "Scout carefully and pressure targets that lack visible anti-air." },
  { id: "GHOST", name: "SEAL", faction: "allied", cost: 1000, prerequisites: ["GAPILE", "RADAR"], role: "Specialist anti-infantry and demolition", use: "Protect it and use only against currently visible high-value targets." },
  { id: "ENGINEER", name: "Engineer", faction: "general", cost: 500, prerequisites: ["BARRACKS"], role: "Repair and capture", use: "Escort it; never lead a combat group with an engineer." },
  { id: "DOG", name: "Attack Dog", faction: "general", cost: 200, prerequisites: ["BARRACKS"], role: "Fast scout and anti-infantry", use: "Use one for current-LOS scouting while the main defense remains home." },
];

const VEHICLES_AIR: readonly FieldManualEntry[] = [
  { id: "HARV", name: "War Miner", faction: "soviet", cost: 1400, prerequisites: ["NAWEAP", "PROC"], role: "Armed economy unit", use: "Keep mining routes short and defended; do not count it as the main attack force." },
  { id: "HTNK", name: "Rhino Heavy Tank", faction: "soviet", cost: 900, prerequisites: ["NAWEAP"], role: "Core battle tank", use: "Form the first three-vehicle armored group, then fight behind an infantry screen." },
  { id: "HTK", name: "Flak Track", faction: "soviet", cost: 500, prerequisites: ["NAWEAP"], role: "Fast transport and mobile anti-air", use: "Mix with armor when aircraft appear; its speed also helps reposition infantry." },
  { id: "V3", name: "V3 Launcher", faction: "soviet", cost: 800, prerequisites: ["NAWEAP", "NARADR"], role: "Long-range siege", use: "Keep behind tanks and use against currently visible static targets." },
  { id: "APOC", name: "Apocalypse", faction: "soviet", cost: 1750, prerequisites: ["NAWEAP", "NATECH"], role: "Late heavy armor", use: "Use as a late combined-arms anchor, not as an excuse to delay early Rhino production." },
  { id: "ZEP", name: "Kirov Airship", faction: "soviet", cost: 2000, prerequisites: ["NAWEAP", "NATECH"], role: "Late heavy bomber", use: "Commit only when the visible route and enemy anti-air make the cost reasonable." },
  { id: "MTNK", name: "Grizzly Battle Tank", faction: "allied", cost: 700, prerequisites: ["GAWEAP"], role: "Core battle tank", use: "Form the first three-vehicle armored group and combine it with infantry and IFVs." },
  { id: "FV", name: "IFV", faction: "allied", cost: 600, prerequisites: ["GAWEAP"], role: "Fast transport and mobile anti-air", use: "Mix with Grizzlies for air cover; passengers can change its combat role." },
  { id: "MGTK", name: "Mirage Tank", faction: "allied", cost: 1000, prerequisites: ["GAWEAP", "GATECH"], role: "Late ambush armor", use: "Fight from a supported position and avoid exposing its light armor alone." },
  { id: "SREF", name: "Prism Tank", faction: "allied", cost: 1200, prerequisites: ["GAWEAP", "GATECH"], role: "Long-range ground siege", use: "Keep behind tanks and screen it from fast attackers." },
  { id: "ORCA", name: "Harrier", faction: "allied", cost: 1200, prerequisites: ["RADAR"], role: "Strike aircraft", use: "Attack currently visible high-value targets and recover before the next sortie." },
];

const SHARED_OPENING_RULES = [
  "Treat the live production and construction catalogs as authoritative; maps and countries can change availability.",
  "Deploy the MCV, then build power, refinery, barracks, one catalog-confirmed anti-infantry defense, and the land war factory.",
  "Keep basic infantry production active until at least 16 combat units defend near the construction yard, or use the higher confirmed target from red_alert_strategy_brief.",
  "Build at least three core tanks before slow expansion or optional technology. Add a second miner or refinery only after the first rush can be held.",
  "Never wait on repeated unchanged reads: use one current result, queue every independent legal action, and read again after real game time advances.",
] as const;

const COMBAT_RULES = [
  "Refresh one compact observation immediately before combat and command only unit ids still present in the owned set.",
  "Keep the main defense at home until the first visible rush is repelled; use one cheap fast scout instead of moving the whole army.",
  "Use infantry as a screen, core tanks as the main damage group, and mobile anti-air only when aircraft are possible or visible.",
  "Prefer one compatible attackMove batch toward the center of a current visible threat over many fragile single-target orders.",
  "A last-seen contact is stale intelligence, not a live target: scout the area again before committing a valuable force.",
  "Retreat damaged armor when the route is currently safe, repair it if a service depot is available, and preserve production buildings during a base attack.",
] as const;

function entriesFor(entries: readonly FieldManualEntry[], faction: FieldManualFaction): FieldManualEntry[] {
  return entries.filter(entry => faction === "general" || entry.faction === "general" || entry.faction === faction);
}

function rulesFor(topic: FieldManualTopic, faction: FieldManualFaction): readonly string[] {
  if (topic === "opening") {
    return faction === "soviet"
      ? [...SHARED_OPENING_RULES, "Soviet land production is NAWEAP. Prefer early Conscripts, a Sentry Gun, then Rhino tanks against a normal infantry rush."]
      : faction === "allied"
        ? [...SHARED_OPENING_RULES, "Allied land production is GAWEAP. Prefer early GIs, a Pill Box, then Grizzly tanks with IFV support."]
        : SHARED_OPENING_RULES;
  }
  if (topic === "combat") return COMBAT_RULES;
  if (topic === "structures") return [
    "Use exact ids from the current catalog; aliases such as POWER, PROC, BARRACKS, RADAR, and TECH are prerequisite groups, not queue names.",
    "NAWEAP and GAWEAP are land war factories. NAYARD and GAYARD are naval yards.",
  ];
  if (topic === "infantry") return [
    "Basic infantry provides cheap early defense, but it should not chase vehicles or a larger visible force without support.",
    "Scout with one fast cheap unit and keep the rest near the base until the first attack is repelled.",
  ];
  return [
    "Build a three-vehicle core before optional technology, then add counters based only on current visible threats.",
    "Protect miners and fragile siege units; expensive late units do not replace an early defense force.",
  ];
}

/** Build one compact manual page from audited static data. */
export function createFieldManualPage(
  sessionId: string,
  topic: FieldManualTopic,
  faction: FieldManualFaction,
): FieldManualPage {
  const entries = topic === "structures"
    ? entriesFor(STRUCTURES, faction)
    : topic === "infantry"
      ? entriesFor(INFANTRY, faction)
      : topic === "vehicles-air"
        ? entriesFor(VEHICLES_AIR, faction)
        : [];
  return {
    version: 1,
    sessionId,
    topic,
    faction,
    title: `${faction} ${topic} field manual`,
    rules: rulesFor(topic, faction),
    entries,
    sources: [
      { kind: "ruleset", label: "Red Alert 2 rules.ini ids, costs, and prerequisites" },
      { kind: "guide", label: "CnCNet beginner build-order guidance" },
      { kind: "battle-review", label: "Fog-safe DSH match reviews" },
    ],
    fairness: "This manual contains static public game knowledge only. Live enemy positions, economy, units, and targets still come only from the bound seat's fog-safe observation.",
  };
}
