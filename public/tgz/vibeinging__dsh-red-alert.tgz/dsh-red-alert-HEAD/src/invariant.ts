import type { Context } from "@deepseek-ai/cordis";
import type { InvariantFailure, InvariantInstaller } from "@deepseek-ai/dsh-invariants";
import { TOOL_MANIFEST } from "./tool-policy.ts";
import { validateToolGroupSelectionLog } from "./tool-groups.ts";

const PACKAGE_NAME = "@vibeinging/dsh-red-alert";
const MATCH_TOOL_NAMES = new Set(TOOL_MANIFEST
  .filter(entry => entry.implemented && entry.methodKeys.length > 0)
  .map(entry => entry.tool));

/** Cordis companion plugin name. */
export const name = "red-alert-invariant";
/** The runtime service must be present before relationship checks install. */
export const inject = ["invariants"];

const install: InvariantInstaller = Object.assign(
  (ctx: Context, fail: InvariantFailure) => {
    ctx.redAlert.assertInvariants(fail);
    ctx.on("agent/created", ({ agent }) => {
      try {
        validateToolGroupSelectionLog(agent.session);
      } catch (error) {
        fail(error instanceof Error ? error.message : String(error));
      }
    });
    ctx.on("tools/result", (exec, result) => {
      if (exec.agent !== undefined) {
        try {
          validateToolGroupSelectionLog(exec.agent.session);
        } catch (error) {
          fail(error instanceof Error ? error.message : String(error));
        }
      }
      if (MATCH_TOOL_NAMES.has(exec.name) && !result.isError) {
        ctx.redAlert.assertToolOutput(result.value, exec.agent?.session, fail);
      }
      ctx.redAlert.assertInvariants(fail);
    });
  },
  { inject: ["redAlert", "tools"] },
);

/** Register the package-owned active-match and fair-output checks. */
export const apply = (ctx: Context): Promise<() => void> =>
  Promise.resolve(ctx.invariants.register(PACKAGE_NAME, install));
