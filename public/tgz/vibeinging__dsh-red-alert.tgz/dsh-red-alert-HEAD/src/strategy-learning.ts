import type { Session, SessionEvent } from "@deepseek-ai/dsh-session";
import {
  RED_ALERT_BROWSER_COMMAND_EVENT,
  RED_ALERT_BROWSER_COMMAND_RESULT_EVENT,
  type BrowserCommandEnvelope,
  type BrowserCommandResultEvent,
} from "./browser-command-protocol.ts";
import { RED_ALERT_EVENT, type RedAlertState } from "./projection.ts";

/** Durable event written once when a natural match reaches an engine result. */
export const RED_ALERT_STRATEGY_EPISODE_EVENT = "red-alert/strategy-episode" as const;
/** Durable model-facing strategy brief applied before a later match. */
export const RED_ALERT_STRATEGY_BRIEF_EVENT = "red-alert/strategy-brief" as const;
/** Durable structured verdict selected by the model after reviewing an episode. */
export const RED_ALERT_STRATEGY_REVIEW_EVENT = "red-alert/strategy-review" as const;

/** Closed lessons keep learned prompt text bounded and auditable. */
export const STRATEGY_RULE_IDS = [
  "rush-defender-target",
  "anti-infantry-defense",
  "armor-before-contact",
  "fresh-owned-ids",
  "act-before-reread",
  "sustain-model-attacks",
] as const;

export type StrategyRuleId = typeof STRATEGY_RULE_IDS[number];

/** Evidence retained from one fog-safe match without raw world or hidden enemy data. */
export interface StrategyEpisode {
  readonly version: 1;
  readonly sessionId: string;
  readonly matchId: string;
  readonly map: string;
  readonly myCountry: string;
  readonly opponentType: "noop" | "supalosa" | "normal";
  readonly gameSpeed: number;
  readonly result: "victory" | "defeat";
  readonly finalTick: number;
  readonly gameTimeSec: number;
  readonly metrics: {
    readonly maxVisibleEnemies: number;
    readonly maxVisibleEnemyInfantry: number;
    readonly maxOwnedCombatUnits: number;
    readonly firstVisibleEnemyTick?: number;
    readonly firstArmoredUnitTick?: number;
    readonly readCommands: number;
    readonly actionCommands: number;
    readonly staleOwnershipFailures: number;
    readonly unitOrderBatches: number;
    readonly issuedUnitOrders: number;
    readonly multiOrderBatches: number;
    readonly attackOrderBatches: number;
    readonly retreatOrderBatches: number;
  };
  readonly candidates: readonly StrategyCandidate[];
}

/** One deterministic lesson candidate supported by bounded match evidence. */
export interface StrategyCandidate {
  readonly ruleId: StrategyRuleId;
  readonly evidenceTick: number;
  readonly evidence: string;
  readonly target?: number;
}

/** Model verdict over candidates from its own finished match. */
export interface StrategyReview {
  readonly version: 1;
  readonly sessionId: string;
  readonly matchId: string;
  readonly adoptedRuleIds: readonly StrategyRuleId[];
  readonly rejectedRuleIds: readonly StrategyRuleId[];
}

/** Bounded learned rule returned to a later model turn. */
export interface StrategyBriefRule {
  readonly ruleId: StrategyRuleId;
  readonly status: "confirmed" | "experimental";
  readonly confidence: number;
  readonly evidenceMatches: number;
  readonly instruction: string;
}

/** Exact strategy query and result recorded before it reaches a model. */
export interface StrategyBrief {
  readonly version: 1;
  readonly sessionId: string;
  readonly query: {
    readonly map: string;
    readonly myCountry: string;
    readonly opponentType: "noop" | "supalosa" | "normal";
  };
  readonly rules: readonly StrategyBriefRule[];
  readonly sourceMatchIds: readonly string[];
}

declare module "@deepseek-ai/dsh-session" {
  interface SessionEventMap {
    /** Fog-safe metrics and lesson candidates from one natural match result. */
    "red-alert/strategy-episode": StrategyEpisode;
    /** Exact learned brief exposed to a later model turn. */
    "red-alert/strategy-brief": StrategyBrief;
    /** Model-selected verdict over one episode's closed lesson candidates. */
    "red-alert/strategy-review": StrategyReview;
  }
}

declare module "@deepseek-ai/dsh-session/types" {
  interface SessionEventMap {
    /** Fog-safe metrics and lesson candidates from one natural match result. */
    "red-alert/strategy-episode": StrategyEpisode;
    /** Exact learned brief exposed to a later model turn. */
    "red-alert/strategy-brief": StrategyBrief;
    /** Model-selected verdict over one episode's closed lesson candidates. */
    "red-alert/strategy-review": StrategyReview;
  }
}

interface StrategyLearningOptions {
  readonly maxLearnedDefenders: number;
  readonly historyLimit: number;
  readonly maxRules: number;
}

const READ_TOOLS = new Set([
  "red_alert_lobby_map",
  "red_alert_lobby_players",
  "red_alert_observe",
  "red_alert_map",
  "red_alert_resources",
  "red_alert_rules",
  "red_alert_production_catalog",
  "red_alert_production_status",
  "red_alert_construction_catalog",
]);

const ACTION_TOOLS = new Set([
  "red_alert_production",
  "red_alert_construction",
  "red_alert_diplomacy",
  "red_alert_superweapons",
]);

function isCombatUnit(kind: string, unitType: string): boolean {
  const normalizedKind = kind.toLowerCase();
  const normalizedType = unitType.toUpperCase();
  if (normalizedKind.includes("building") || normalizedKind.includes("structure")) return false;
  return !["HARV", "SMCV", "MCV"].includes(normalizedType);
}

function isInfantry(kind: string, unitType: string): boolean {
  return kind.toLowerCase().includes("infantry") || /^E[12]$/i.test(unitType);
}

function isArmored(kind: string, unitType: string): boolean {
  const normalizedType = unitType.toUpperCase();
  return (kind.toLowerCase().includes("vehicle") || ["HTNK", "MTNK", "APOC", "FV", "TNKD"].includes(normalizedType))
    && !["HARV", "SMCV", "MCV"].includes(normalizedType);
}

function stateData(event: SessionEvent): RedAlertState | undefined {
  return event.type === RED_ALERT_EVENT ? (event as SessionEvent<"red-alert/state">).data : undefined;
}

function commandData(event: SessionEvent): BrowserCommandEnvelope | undefined {
  return event.type === RED_ALERT_BROWSER_COMMAND_EVENT
    ? (event as SessionEvent<"red-alert/browser-command-admitted">).data
    : undefined;
}

function commandResultData(event: SessionEvent): BrowserCommandResultEvent | undefined {
  return event.type === RED_ALERT_BROWSER_COMMAND_RESULT_EVENT
    ? (event as SessionEvent<"red-alert/browser-command-result">).data
    : undefined;
}

function uniqueCandidates(candidates: readonly StrategyCandidate[]): StrategyCandidate[] {
  const result = new Map<StrategyRuleId, StrategyCandidate>();
  for (const candidate of candidates) {
    const previous = result.get(candidate.ruleId);
    if (previous === undefined || (candidate.target ?? 0) > (previous.target ?? 0)) result.set(candidate.ruleId, candidate);
  }
  return [...result.values()];
}

/** Derive one bounded episode from durable fair state and command events. */
export function deriveStrategyEpisode(
  session: Pick<Session, "id" | "events">,
  finalState: RedAlertState,
  options: Pick<StrategyLearningOptions, "maxLearnedDefenders">,
): StrategyEpisode | undefined {
  const match = finalState.match;
  if (match === undefined || match.status !== "finished") return undefined;
  if (session.events.some(event => event.type === RED_ALERT_STRATEGY_EPISODE_EVENT
    && (event as SessionEvent<"red-alert/strategy-episode">).data.matchId === match.matchId)) return undefined;

  const firstMatchStateIndex = session.events.findIndex(event => stateData(event)?.match?.matchId === match.matchId);
  const creating = session.events
    .slice(0, firstMatchStateIndex < 0 ? session.events.length : firstMatchStateIndex)
    .map(stateData)
    .findLast(state => state?.status === "creating");
  const request = creating?.request;
  if (request === undefined) return undefined;

  const states = session.events
    .map(stateData)
    .filter((state): state is RedAlertState => state?.match?.matchId === match.matchId);
  let maxVisibleEnemies = 0;
  let maxVisibleEnemyInfantry = 0;
  let maxOwnedCombatUnits = 0;
  let firstVisibleEnemyTick: number | undefined;
  let firstArmoredUnitTick: number | undefined;
  for (const state of states) {
    const current = state.match;
    if (current === undefined) continue;
    const observation = current.observation;
    maxVisibleEnemies = Math.max(maxVisibleEnemies, observation.visibleEnemies.length);
    maxVisibleEnemyInfantry = Math.max(
      maxVisibleEnemyInfantry,
      observation.visibleEnemies.filter(contact => isInfantry(contact.kind, contact.unitType)).length,
    );
    maxOwnedCombatUnits = Math.max(
      maxOwnedCombatUnits,
      observation.ownUnits.filter(contact => isCombatUnit(contact.kind, contact.unitType)).length,
    );
    if (firstVisibleEnemyTick === undefined && observation.visibleEnemies.length > 0) firstVisibleEnemyTick = observation.tick;
    if (firstArmoredUnitTick === undefined
      && observation.ownUnits.some(contact => isArmored(contact.kind, contact.unitType))) firstArmoredUnitTick = observation.tick;
  }

  let readCommands = 0;
  let actionCommands = 0;
  let unitOrderBatches = 0;
  let issuedUnitOrders = 0;
  let multiOrderBatches = 0;
  let attackOrderBatches = 0;
  let retreatOrderBatches = 0;
  for (const event of session.events) {
    const command = commandData(event);
    if (command?.matchId !== match.matchId) continue;
    if (command.kind === "observe") readCommands += 1;
    else if (command.kind === "orders") {
      actionCommands += 1;
      unitOrderBatches += 1;
      issuedUnitOrders += command.orders.length;
      if (command.orders.length > 1) multiOrderBatches += 1;
      if (command.orders.some(order => order.action === "attackMove" || order.action === "attackTarget")) attackOrderBatches += 1;
      if (command.orders.some(order => order.action === "retreat")) retreatOrderBatches += 1;
    }
    else if (command.kind === "tool") {
      if (READ_TOOLS.has(command.request.tool)) readCommands += 1;
      if (ACTION_TOOLS.has(command.request.tool)) actionCommands += 1;
    }
  }
  const staleOwnershipFailures = session.events.reduce((count, event) => {
    const result = commandResultData(event);
    return result?.matchId === match.matchId && result.status === "failed"
      && /not currently owned|ownership changed/i.test(result.failure.message) ? count + 1 : count;
  }, 0);

  const defeated = match.facts.self.defeated;
  const evidenceTick = match.tick;
  const candidates: StrategyCandidate[] = [];
  if (defeated && maxVisibleEnemyInfantry > maxOwnedCombatUnits) {
    candidates.push({
      ruleId: "rush-defender-target",
      evidenceTick,
      evidence: `visible enemy infantry peaked at ${maxVisibleEnemyInfantry} while owned combat units peaked at ${maxOwnedCombatUnits}`,
      target: Math.min(options.maxLearnedDefenders, Math.max(16, maxVisibleEnemyInfantry)),
    });
  }
  if (defeated && maxVisibleEnemyInfantry > 0 && maxVisibleEnemyInfantry >= Math.ceil(maxVisibleEnemies * 0.6)) {
    candidates.push({
      ruleId: "anti-infantry-defense",
      evidenceTick,
      evidence: `${maxVisibleEnemyInfantry} of ${maxVisibleEnemies} peak visible enemies were infantry`,
    });
  }
  if (defeated && firstVisibleEnemyTick !== undefined
    && (firstArmoredUnitTick === undefined || firstArmoredUnitTick > firstVisibleEnemyTick)) {
    candidates.push({
      ruleId: "armor-before-contact",
      evidenceTick: firstVisibleEnemyTick,
      evidence: firstArmoredUnitTick === undefined
        ? "no owned armored unit appeared before defeat"
        : `first armor appeared at tick ${firstArmoredUnitTick} after contact at tick ${firstVisibleEnemyTick}`,
    });
  }
  if (staleOwnershipFailures > 0) {
    candidates.push({
      ruleId: "fresh-owned-ids",
      evidenceTick,
      evidence: `${staleOwnershipFailures} command batches failed after ownership changed`,
    });
  }
  if (readCommands > Math.max(1, actionCommands * 2)) {
    candidates.push({
      ruleId: "act-before-reread",
      evidenceTick,
      evidence: `${readCommands} read commands versus ${actionCommands} action commands`,
    });
  }
  if (defeated && maxOwnedCombatUnits >= 8 && attackOrderBatches < 2) {
    candidates.push({
      ruleId: "sustain-model-attacks",
      evidenceTick,
      evidence: `${maxOwnedCombatUnits} owned combat units were available, but the model issued only ${attackOrderBatches} attack batch${attackOrderBatches === 1 ? "" : "es"}`,
      target: 2,
    });
  }

  return {
    version: 1,
    sessionId: String(session.id),
    matchId: match.matchId,
    map: match.map,
    myCountry: match.myCountry,
    opponentType: request.opponentType,
    gameSpeed: request.gameSpeed ?? 2,
    result: defeated ? "defeat" : "victory",
    finalTick: match.tick,
    gameTimeSec: match.facts.gameTimeSec,
    metrics: {
      maxVisibleEnemies,
      maxVisibleEnemyInfantry,
      maxOwnedCombatUnits,
      ...(firstVisibleEnemyTick === undefined ? {} : { firstVisibleEnemyTick }),
      ...(firstArmoredUnitTick === undefined ? {} : { firstArmoredUnitTick }),
      readCommands,
      actionCommands,
      staleOwnershipFailures,
      unitOrderBatches,
      issuedUnitOrders,
      multiOrderBatches,
      attackOrderBatches,
      retreatOrderBatches,
    },
    candidates: uniqueCandidates(candidates),
  };
}

function episodesAndReviews(sessions: readonly Pick<Session, "events">[]): {
  episodes: Array<{ readonly episode: StrategyEpisode; readonly time: number }>;
  reviews: Map<string, StrategyReview>;
} {
  const episodes: Array<{ episode: StrategyEpisode; time: number }> = [];
  const reviews = new Map<string, StrategyReview>();
  for (const session of sessions) {
    for (const event of session.events) {
      if (event.type === RED_ALERT_STRATEGY_EPISODE_EVENT) {
        episodes.push({ episode: (event as SessionEvent<"red-alert/strategy-episode">).data, time: event.time });
      } else if (event.type === RED_ALERT_STRATEGY_REVIEW_EVENT) {
        const review = (event as SessionEvent<"red-alert/strategy-review">).data;
        reviews.set(review.matchId, review);
      }
    }
  }
  return { episodes, reviews };
}

function instructionFor(ruleId: StrategyRuleId, target: number | undefined): string {
  switch (ruleId) {
    case "rush-defender-target":
      return `Keep at least ${target ?? 16} combat units defending the base until the first visible rush is repelled.`;
    case "anti-infantry-defense":
      return "If the current catalog offers one, place a cheap anti-infantry defense before committing to slow expansion.";
    case "armor-before-contact":
      return "Prioritize the war factory and a three-vehicle armored group early enough to meet the first visible attack.";
    case "fresh-owned-ids":
      return "Refresh once immediately before each combat batch and remove every unit id absent from the latest owned set.";
    case "act-before-reread":
      return "Use one compact read, execute all independent legal actions, and do not poll unchanged state again in the same cycle.";
    case "sustain-model-attacks":
      return `Personally launch at least ${target ?? 2} evidence-based attack batches when enough combat units are ready; keep choosing every unit and target instead of leaving the army idle.`;
  }
}

/** Fold prior episode and review events into a short selector-specific strategy. */
export function deriveStrategyBrief(
  sessionId: string,
  sessions: readonly Pick<Session, "events">[],
  query: StrategyBrief["query"],
  options: Pick<StrategyLearningOptions, "historyLimit" | "maxRules">,
): StrategyBrief {
  const { episodes, reviews } = episodesAndReviews(sessions);
  const matching = episodes
    .filter(({ episode }) => episode.myCountry === query.myCountry
      && episode.opponentType === query.opponentType
      && (query.map === "current" || episode.map === query.map))
    .sort((left, right) => right.time - left.time)
    .slice(0, options.historyLimit);
  const aggregate = new Map<StrategyRuleId, {
    evidence: Set<string>;
    adopted: number;
    rejected: number;
    target?: number;
  }>();
  for (const { episode } of matching) {
    const review = reviews.get(episode.matchId);
    for (const candidate of episode.candidates) {
      const row = aggregate.get(candidate.ruleId) ?? { evidence: new Set<string>(), adopted: 0, rejected: 0 };
      row.evidence.add(episode.matchId);
      if (review?.adoptedRuleIds.includes(candidate.ruleId)) row.adopted += 1;
      if (review?.rejectedRuleIds.includes(candidate.ruleId)) row.rejected += 1;
      if (candidate.target !== undefined) row.target = Math.max(row.target ?? 0, candidate.target);
      aggregate.set(candidate.ruleId, row);
    }
  }
  const rules = [...aggregate.entries()]
    .filter(([, row]) => row.adopted > row.rejected || row.evidence.size >= 2 || row.rejected === 0)
    .map(([ruleId, row]): StrategyBriefRule => {
      const confidence = Math.max(0.2, Math.min(0.95,
        0.45 + Math.min(3, row.evidence.size) * 0.12 + row.adopted * 0.2 - row.rejected * 0.18));
      return {
        ruleId,
        status: row.adopted > row.rejected || row.evidence.size >= 2 ? "confirmed" : "experimental",
        confidence: Math.round(confidence * 100) / 100,
        evidenceMatches: row.evidence.size,
        instruction: instructionFor(ruleId, row.target),
      };
    })
    .sort((left, right) => Number(right.status === "confirmed") - Number(left.status === "confirmed")
      || right.confidence - left.confidence
      || left.ruleId.localeCompare(right.ruleId))
    .slice(0, options.maxRules);
  return {
    version: 1,
    sessionId,
    query,
    rules,
    sourceMatchIds: matching.map(({ episode }) => episode.matchId),
  };
}

/** Return the current session's exact episode when it is ready for model review. */
export function strategyEpisodeForReview(
  session: Pick<Session, "events">,
  matchId: string,
): StrategyEpisode | undefined {
  return session.events
    .filter(event => event.type === RED_ALERT_STRATEGY_EPISODE_EVENT)
    .map(event => (event as SessionEvent<"red-alert/strategy-episode">).data)
    .find(episode => episode.matchId === matchId);
}

/** Return an existing structured review for idempotent tool execution. */
export function strategyReviewForMatch(
  session: Pick<Session, "events">,
  matchId: string,
): StrategyReview | undefined {
  return session.events
    .filter(event => event.type === RED_ALERT_STRATEGY_REVIEW_EVENT)
    .map(event => (event as SessionEvent<"red-alert/strategy-review">).data)
    .find(review => review.matchId === matchId);
}

/** Validate a closed lesson id from a model-facing JSON boundary. */
export function isStrategyRuleId(value: unknown): value is StrategyRuleId {
  return typeof value === "string" && (STRATEGY_RULE_IDS as readonly string[]).includes(value);
}
