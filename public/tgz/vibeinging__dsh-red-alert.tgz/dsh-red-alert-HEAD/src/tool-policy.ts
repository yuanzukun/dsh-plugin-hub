/**
 * Typed red-alert tool groups and the single policy inventory for the locked
 * Chrono Divide game-api surface.
 */

export const RED_ALERT_GROUPS = [
  "bootstrap/capability",
  "strategy/learning",
  "lobby/setup",
  "observation",
  "production/economy",
  "construction",
  "units/combat",
  "diplomacy/comms",
  "superweapon",
  "lifecycle/replay",
] as const;

export type RedAlertGroupId = typeof RED_ALERT_GROUPS[number];
export type MethodOwner =
  | "PublicApi"
  | "GameInstanceApi"
  | "GameApi"
  | "MapApi"
  | "PlayerApi"
  | "ProductionApi"
  | "ActionsApi";
export type MethodDecision = "allow-wrapper" | "internal-only" | "deny";
export type MethodAvailability = "current-headless-wrapper" | "real-browser-wrapper" | "pending-client-adapter" | "not-exposed";
export type RedAlertPhase = "catalog-only" | "lobby-ready" | "lobby-created" | "running" | "ended" | "stopped" | "error";

export interface MethodPolicy {
  readonly methodKey: string;
  readonly owner: MethodOwner;
  readonly method: string;
  readonly signature: string;
  readonly overload: number;
  readonly decision: MethodDecision;
  readonly availability: MethodAvailability;
  readonly tool: string | undefined;
  readonly group: RedAlertGroupId | "internal";
  readonly phase: RedAlertPhase | "never";
  readonly fairnessRule: string;
}

export interface ToolManifestEntry {
  readonly tool: string;
  readonly group: RedAlertGroupId;
  readonly phase: RedAlertPhase | "all";
  readonly methodKeys: readonly string[];
  readonly schemaId: string;
  readonly sessionEvent:
    | "red-alert/state"
    | "red-alert/tool-group-selection"
    | "red-alert/field-manual"
    | "red-alert/strategy-brief"
    | "red-alert/strategy-review";
  readonly implemented: boolean;
  readonly testId: string;
  readonly pendingReason?: string;
  readonly legacyCrossGroup?: true;
}

interface SurfaceRow {
  readonly owner: MethodOwner;
  readonly method: string;
  readonly signature: string;
  readonly overload: number;
}

const row = (owner: MethodOwner, method: string, signature: string, overload = 0): SurfaceRow => ({
  owner,
  method,
  signature,
  overload,
});

const SURFACE: readonly SurfaceRow[] = [
  row("PublicApi", "init", "init(mixDir: string): Promise<void>"),
  row("PublicApi", "getAvailableMaps", "getAvailableMaps(): string[]"),
  row("PublicApi", "getAvailableGameModes", "getAvailableGameModes(mapName: string): number[]"),
  row("PublicApi", "createGame", "createGame(opts: CreateOpts): Promise<GameInstanceApi>"),

  row("GameInstanceApi", "isFinished", "isFinished(): boolean"),
  row("GameInstanceApi", "update", "update(): Promise<void>"),
  row("GameInstanceApi", "getCurrentTick", "getCurrentTick(): number"),
  row("GameInstanceApi", "getTickRate", "getTickRate(): number"),
  row("GameInstanceApi", "getPlayerStats", "getPlayerStats(): PlayerStats[]"),
  row("GameInstanceApi", "saveReplay", "saveReplay(targetDir?: string): string"),
  row("GameInstanceApi", "getDebugStateDump", "getDebugStateDump(): object[] | undefined"),
  row("GameInstanceApi", "dispose", "dispose(): void"),

  row("GameApi", "map", "map: MapApi"),
  row("GameApi", "rules", "rules: RulesApi"),
  row("GameApi", "mapApi", "mapApi: MapApi"),
  row("GameApi", "rulesApi", "rulesApi: RulesApi"),
  row("GameApi", "isPlayerDefeated", "isPlayerDefeated(playerName: string): boolean"),
  row("GameApi", "areAlliedPlayers", "areAlliedPlayers(p1Name: string, p2Name: string): boolean"),
  row("GameApi", "canPlaceBuilding", "canPlaceBuilding(playerName: string, buildingName: string, tile: Tile, options?: PlaceCheckOptions): boolean"),
  row("GameApi", "getBuildingPlacementData", "getBuildingPlacementData(objName: string): BuildingPlacementData"),
  row("GameApi", "getPlayers", "getPlayers(): string[]"),
  row("GameApi", "getPlayerData", "getPlayerData(playerName: string): PlayerData"),
  row("GameApi", "getAllTerrainObjects", "getAllTerrainObjects(): number[]"),
  row("GameApi", "getAllUnits", "getAllUnits(filter?: (r: TechnoRules) => boolean): number[]"),
  row("GameApi", "getNeutralUnits", "getNeutralUnits(filter?: (r: TechnoRules) => boolean): number[]"),
  row("GameApi", "getUnitsInArea", "getUnitsInArea(tileRange: Box2): number[]"),
  row("GameApi", "getVisibleUnits", "getVisibleUnits(playerName: string, type: VisibleUnitType, filter?: (r: TechnoRules) => boolean): number[]"),
  row("GameApi", "getGameObjectData", "getGameObjectData(objId: number): GameObjectData | undefined"),
  row("GameApi", "getUnitData", "getUnitData(unitId: number): UnitData | undefined"),
  row("GameApi", "getAllSuperWeaponData", "getAllSuperWeaponData(): SuperWeaponData[]"),
  row("GameApi", "getGeneralRules", "getGeneralRules(): GeneralRules"),
  row("GameApi", "getRulesIni", "getRulesIni(): IniFile"),
  row("GameApi", "getArtIni", "getArtIni(): IniFile"),
  row("GameApi", "getAiIni", "getAiIni(): IniFile"),
  row("GameApi", "generateRandomInt", "generateRandomInt(min: number, max: number): number"),
  row("GameApi", "generateRandom", "generateRandom(): number"),
  row("GameApi", "getTickRate", "getTickRate(): number"),
  row("GameApi", "getBaseTickRate", "getBaseTickRate(): number"),
  row("GameApi", "getCurrentTick", "getCurrentTick(): number"),
  row("GameApi", "getCurrentTime", "getCurrentTime(): number"),

  row("MapApi", "getRealMapSize", "getRealMapSize(): Size"),
  row("MapApi", "getStartingLocations", "getStartingLocations(): Vector2[]"),
  row("MapApi", "getTheaterType", "getTheaterType(): TheaterType"),
  row("MapApi", "getTile", "getTile(rx: number, ry: number): Tile | undefined"),
  row("MapApi", "getTilesInRect", "getTilesInRect(rectangle: Rectangle): Tile[]", 0),
  row("MapApi", "getTilesInRect", "getTilesInRect(baseTile: Tile, size: Size): Tile[]", 1),
  row("MapApi", "getObjectsOnTile", "getObjectsOnTile(tile: Tile): number[]"),
  row("MapApi", "hasBridgeOnTile", "hasBridgeOnTile(tile: Tile): boolean"),
  row("MapApi", "hasHighBridgeOnTile", "hasHighBridgeOnTile(tile: Tile): boolean"),
  row("MapApi", "isPassableTile", "isPassableTile(tile: Tile, speedType: SpeedType, onBridge: boolean, subCell: boolean): boolean", 0),
  row("MapApi", "isPassableTile", "isPassableTile(tile: Tile, speedType: SpeedType, onBridge: boolean): boolean", 1),
  row("MapApi", "findPath", "findPath(speedType: SpeedType, subCell: boolean, from: PathNode, to: PathNode, options?: PathFinderOptions): PathNode[]"),
  row("MapApi", "getReachabilityMap", "getReachabilityMap(speedType: SpeedType, subCell: boolean): ReachabilityMap"),
  row("MapApi", "isVisibleTile", "isVisibleTile(tile: Tile, playerName: string, tileElevation?: number): boolean"),
  row("MapApi", "getTileResourceData", "getTileResourceData(tile: Tile): TileResourceData | undefined"),
  row("MapApi", "getAllTilesResourceData", "getAllTilesResourceData(): TileResourceData[]"),

  row("PlayerApi", "name", "name: string"),
  row("PlayerApi", "actions", "actions: ActionsApi"),
  row("PlayerApi", "production", "production: ProductionApi"),
  row("PlayerApi", "getPlayerData", "getPlayerData(): PlayerData"),
  row("PlayerApi", "isDefeated", "isDefeated(): boolean"),
  row("PlayerApi", "isAlliedWith", "isAlliedWith(otherPlayerName: string): boolean"),
  row("PlayerApi", "canPlaceBuilding", "canPlaceBuilding(buildingName: string, tile: Tile): boolean"),
  row("PlayerApi", "getVisibleUnits", "getVisibleUnits(type: VisibleUnitType, filter?: (r: TechnoRules) => boolean): number[]"),

  row("ProductionApi", "isAvailableForProduction", "isAvailableForProduction(objRules: TechnoRules): boolean"),
  row("ProductionApi", "getAvailableObjects", "getAvailableObjects(queueType?: QueueType): TechnoRules[]"),
  row("ProductionApi", "getQueueTypeForObject", "getQueueTypeForObject(objRules: TechnoRules): QueueType"),
  row("ProductionApi", "getQueueData", "getQueueData(queueType: QueueType): QueueData"),

  row("ActionsApi", "placeBuilding", "placeBuilding(buildingName: string, rx: number, ry: number): void"),
  row("ActionsApi", "sellObject", "sellObject(objectId: number): void"),
  row("ActionsApi", "sellBuilding", "sellBuilding(buildingId: number): void"),
  row("ActionsApi", "toggleRepairWrench", "toggleRepairWrench(buildingId: number): void"),
  row("ActionsApi", "toggleAlliance", "toggleAlliance(toPlayer: string, enabled: boolean): void"),
  row("ActionsApi", "pauseProduction", "pauseProduction(queueType: QueueType): void"),
  row("ActionsApi", "resumeProduction", "resumeProduction(queueType: QueueType): void"),
  row("ActionsApi", "queueForProduction", "queueForProduction(queueType: QueueType, objName: string, objType: ObjectType, quantity: number): void"),
  row("ActionsApi", "unqueueFromProduction", "unqueueFromProduction(queueType: QueueType, objName: string, objType: ObjectType, quantity: number): void"),
  row("ActionsApi", "activateSuperWeapon", "activateSuperWeapon(type: SuperWeaponType, tile: { rx: number; ry: number }, tile2?: { rx: number; ry: number }): void"),
  row("ActionsApi", "orderUnits", "orderUnits(unitIds: number[], orderType: OrderType): void", 0),
  row("ActionsApi", "orderUnits", "orderUnits(unitIds: number[], orderType: OrderType, targetUnit: number): void", 1),
  row("ActionsApi", "orderUnits", "orderUnits(unitIds: number[], orderType: OrderType, rx: number, ry: number, onBridge?: boolean): void", 2),
  row("ActionsApi", "sayAll", "sayAll(text: string): void"),
  row("ActionsApi", "setGlobalDebugText", "setGlobalDebugText(text: string | undefined): void"),
  row("ActionsApi", "setUnitDebugText", "setUnitDebugText(unitId: number, text: string | undefined): void"),
  row("ActionsApi", "quitGame", "quitGame(): void"),
];

export function methodKey(owner: MethodOwner, method: string, overload = 0): string {
  return `${owner}::${method}::${overload}`;
}

const current = new Map<string, Omit<MethodPolicy, "methodKey" | "owner" | "method" | "signature" | "overload">>();

function allow(
  target: Map<string, Omit<MethodPolicy, "methodKey" | "owner" | "method" | "signature" | "overload">>,
  owner: MethodOwner,
  method: string,
  tool: string,
  group: RedAlertGroupId,
  phase: RedAlertPhase,
  fairnessRule: string,
  overload = 0,
  availability: MethodAvailability = "current-headless-wrapper",
): void {
  target.set(methodKey(owner, method, overload), {
    decision: "allow-wrapper",
    availability,
    tool,
    group,
    phase,
    fairnessRule,
  });
}

function internal(owner: MethodOwner, method: string, fairnessRule: string, overload = 0): void {
  current.set(methodKey(owner, method, overload), {
    decision: "internal-only",
    availability: "not-exposed",
    tool: undefined,
    group: "internal",
    phase: "never",
    fairnessRule,
  });
}

function browserWrapper(owner: MethodOwner, method: string, tool: string, group: RedAlertGroupId, phase: RedAlertPhase, fairnessRule: string, overload = 0): void {
  allow(current, owner, method, tool, group, phase, fairnessRule, overload, "real-browser-wrapper");
}

allow(current, "PublicApi", "getAvailableGameModes", "red_alert_start", "lobby/setup", "catalog-only", "Only public map/mode names; no hidden map state.");
allow(current, "PublicApi", "createGame", "red_alert_start", "lobby/setup", "catalog-only", "Offline engine creation is owned by the current Agent session.");
browserWrapper("PublicApi", "getAvailableMaps", "red_alert_lobby_map", "lobby/setup", "running", "Return only the running public map name.");
internal("PublicApi", "init", "Runtime-only asset initialization; never model-visible.");

allow(current, "GameInstanceApi", "isFinished", "red_alert_status", "observation", "running", "Expose only lifecycle status for the owning match.");
allow(current, "GameInstanceApi", "update", "red_alert_unit_order", "units/combat", "running", "Advance only after fair unit commands are validated.");
allow(current, "GameInstanceApi", "getCurrentTick", "red_alert_status", "observation", "running", "Expose authoritative tick with observation.");
allow(current, "GameInstanceApi", "getTickRate", "red_alert_status", "observation", "running", "Expose timing metadata only.");
internal("GameInstanceApi", "saveReplay", "The compatible renderer does not expose replay bytes across the DSH boundary.");
allow(current, "GameInstanceApi", "dispose", "red_alert_stop", "lifecycle/replay", "running", "Stop and dispose only the owning match.");
internal("GameInstanceApi", "getDebugStateDump", "Full debug state is referee-only and never model-visible.");
browserWrapper("GameInstanceApi", "getPlayerStats", "red_alert_observe", "observation", "running", "Project only self-safe economy and lifecycle fields.");

internal("GameApi", "map", "Runtime map access is filtered by the observation projector.");
internal("GameApi", "rules", "Runtime rules access is filtered by wrappers.");
internal("GameApi", "mapApi", "Deprecated runtime alias; never model-visible.");
internal("GameApi", "rulesApi", "Deprecated runtime alias; never model-visible.");
allow(current, "GameApi", "isPlayerDefeated", "red_alert_status", "observation", "running", "Return only the owning player's status.");
browserWrapper("GameApi", "areAlliedPlayers", "red_alert_diplomacy", "diplomacy/comms", "running", "Return only seat-authorized alliance facts.");
browserWrapper("GameApi", "canPlaceBuilding", "red_alert_construction", "construction", "running", "Validate placement without exposing hidden map objects.");
browserWrapper("GameApi", "getBuildingPlacementData", "red_alert_construction_catalog", "construction", "running", "Return public placement geometry only.");
browserWrapper("GameApi", "getPlayers", "red_alert_lobby_players", "lobby/setup", "running", "Return public seats, excluding hidden opponent state.");
allow(current, "GameApi", "getPlayerData", "red_alert_status", "observation", "running", "Project self data only; never enemy economy or start location.");
internal("GameApi", "getAllTerrainObjects", "Full terrain object enumeration is referee-only.");
internal("GameApi", "getAllUnits", "Full unit enumeration bypasses fog and is referee-only.");
internal("GameApi", "getNeutralUnits", "Full neutral enumeration bypasses visibility and is forbidden in product paths.");
internal("GameApi", "getUnitsInArea", "Area enumeration can cross shroud and is referee-only.");
allow(current, "GameApi", "getVisibleUnits", "red_alert_status", "observation", "running", "Enemy data must come only from getVisibleUnits(self, enemy); hostile-minus-enemy derives visible neutral.");
internal("GameApi", "getGameObjectData", "Unfiltered object lookup can reveal hidden IDs and is referee-only.");
allow(current, "GameApi", "getUnitData", "red_alert_status", "observation", "running", "Only IDs already in the fair visible/last-seen projection may be resolved.");
browserWrapper("GameApi", "getAllSuperWeaponData", "red_alert_superweapons", "superweapon", "running", "Return only seat-owned available superweapons.");
browserWrapper("GameApi", "getGeneralRules", "red_alert_rules", "observation", "running", "Expose only non-secret rules needed for legal decisions.");
internal("GameApi", "getRulesIni", "Raw rules.ini is not model-visible.");
internal("GameApi", "getArtIni", "Raw art.ini is not model-visible.");
internal("GameApi", "getAiIni", "Raw ai.ini is not model-visible.");
internal("GameApi", "generateRandomInt", "Engine PRNG is runtime-only.");
internal("GameApi", "generateRandom", "Engine PRNG is runtime-only.");
allow(current, "GameApi", "getTickRate", "red_alert_status", "observation", "running", "Expose timing metadata only.");
allow(current, "GameApi", "getBaseTickRate", "red_alert_status", "observation", "running", "Expose timing metadata only.");
allow(current, "GameApi", "getCurrentTick", "red_alert_status", "observation", "running", "Expose authoritative tick only.");
allow(current, "GameApi", "getCurrentTime", "red_alert_status", "observation", "running", "Expose elapsed match time only.");

allow(current, "MapApi", "getRealMapSize", "red_alert_status", "observation", "running", "Expose public map dimensions only.");
browserWrapper("MapApi", "getStartingLocations", "red_alert_lobby_map", "lobby/setup", "running", "Return only this seat's own starting location.");
browserWrapper("MapApi", "getTheaterType", "red_alert_map", "observation", "running", "Expose public map metadata only.");
browserWrapper("MapApi", "getTile", "red_alert_map", "observation", "running", "Return only tiles legal for the owning seat's current visible view.");
browserWrapper("MapApi", "getTilesInRect", "red_alert_map", "observation", "running", "Return only current-visible tiles; rectangle overload.", 0);
browserWrapper("MapApi", "getTilesInRect", "red_alert_map", "observation", "running", "Return only current-visible tiles; base-tile overload.", 1);
internal("MapApi", "getObjectsOnTile", "Object enumeration can bypass fog.");
browserWrapper("MapApi", "hasBridgeOnTile", "red_alert_map", "observation", "running", "Return bridge facts only for visible tiles.");
browserWrapper("MapApi", "hasHighBridgeOnTile", "red_alert_map", "observation", "running", "Return bridge facts only for visible tiles.");
internal("MapApi", "isPassableTile", "Runtime path validation only; overload 0.", 0);
internal("MapApi", "isPassableTile", "Deprecated runtime path validation only; overload 1.", 1);
internal("MapApi", "findPath", "Pathfinding is performed inside a validated order wrapper.");
internal("MapApi", "getReachabilityMap", "Reachability data can disclose hidden terrain.");
internal("MapApi", "isVisibleTile", "Visibility checks feed the projector and are not model tools.");
browserWrapper("MapApi", "getTileResourceData", "red_alert_resources", "observation", "running", "Return resources only on currently visible tiles.");
internal("MapApi", "getAllTilesResourceData", "Full resource enumeration discloses hidden economy.");

allow(current, "PlayerApi", "name", "red_alert_status", "observation", "running", "Expose the owning seat name only.");
internal("PlayerApi", "actions", "Runtime action capability object is never model-visible.");
internal("PlayerApi", "production", "Runtime production capability object is never model-visible.");
allow(current, "PlayerApi", "getPlayerData", "red_alert_status", "observation", "running", "Project self data only.");
allow(current, "PlayerApi", "isDefeated", "red_alert_status", "observation", "running", "Expose seat lifecycle only.");
browserWrapper("PlayerApi", "isAlliedWith", "red_alert_diplomacy", "diplomacy/comms", "running", "Return only seat-authorized alliance facts.");
browserWrapper("PlayerApi", "canPlaceBuilding", "red_alert_construction", "construction", "running", "Validate a placement without hidden map data.");
allow(current, "PlayerApi", "getVisibleUnits", "red_alert_status", "observation", "running", "Use the fair visibility API and never a full-unit getter.");

browserWrapper("ProductionApi", "isAvailableForProduction", "red_alert_production_catalog", "production/economy", "running", "Project only self-seat production availability.");
browserWrapper("ProductionApi", "getAvailableObjects", "red_alert_production_catalog", "production/economy", "running", "Project only self-seat legal production items.");
browserWrapper("ProductionApi", "getQueueTypeForObject", "red_alert_production_catalog", "production/economy", "running", "Project public queue classification only.");
browserWrapper("ProductionApi", "getQueueData", "red_alert_production_status", "production/economy", "running", "Project only self-seat queue state.");

browserWrapper("ActionsApi", "placeBuilding", "red_alert_construction", "construction", "running", "Execute only validated self-seat placement orders.");
browserWrapper("ActionsApi", "sellObject", "red_alert_construction", "construction", "running", "Execute only owned object sales.");
browserWrapper("ActionsApi", "sellBuilding", "red_alert_construction", "construction", "running", "Deprecated alias; execute only owned building sales.");
browserWrapper("ActionsApi", "toggleRepairWrench", "red_alert_construction", "construction", "running", "Execute only owned repair actions.");
browserWrapper("ActionsApi", "toggleAlliance", "red_alert_diplomacy", "diplomacy/comms", "running", "Execute only seat-authorized diplomacy.");
browserWrapper("ActionsApi", "pauseProduction", "red_alert_production", "production/economy", "running", "Execute only self-seat queue changes.");
browserWrapper("ActionsApi", "resumeProduction", "red_alert_production", "production/economy", "running", "Execute only self-seat queue changes.");
browserWrapper("ActionsApi", "queueForProduction", "red_alert_production", "production/economy", "running", "Execute only self-seat legal production orders.");
browserWrapper("ActionsApi", "unqueueFromProduction", "red_alert_production", "production/economy", "running", "Execute only self-seat legal production orders.");
browserWrapper("ActionsApi", "activateSuperWeapon", "red_alert_superweapons", "superweapon", "running", "Execute only available self-seat superweapons.");
allow(current, "ActionsApi", "orderUnits", "red_alert_unit_order", "units/combat", "running", "Execute only self-seat visible unit orders.", 0);
allow(current, "ActionsApi", "orderUnits", "red_alert_unit_order", "units/combat", "running", "Execute only self-seat visible unit orders.", 1);
allow(current, "ActionsApi", "orderUnits", "red_alert_unit_order", "units/combat", "running", "Execute only self-seat visible unit orders.", 2);
internal("ActionsApi", "sayAll", "The compatible single-player renderer has no authoritative player chat transport.");
internal("ActionsApi", "setGlobalDebugText", "Debug labels are never model-visible.");
internal("ActionsApi", "setUnitDebugText", "Debug labels are never model-visible.");
allow(current, "ActionsApi", "quitGame", "red_alert_stop", "lifecycle/replay", "running", "Lifecycle control must close only the owning match.");

export const METHOD_POLICY: readonly MethodPolicy[] = SURFACE.map((entry) => {
  const key = methodKey(entry.owner, entry.method, entry.overload);
  const override = current.get(key);
  return {
    methodKey: key,
    owner: entry.owner,
    method: entry.method,
    signature: entry.signature,
    overload: entry.overload,
    decision: override?.decision ?? "deny",
    availability: override?.availability ?? "not-exposed",
    tool: override?.tool,
    group: override?.group ?? "internal",
    phase: override?.phase ?? "never",
    fairnessRule: override?.fairnessRule ?? "No safe wrapper exists; keep this method out of model-visible tools.",
  } satisfies MethodPolicy;
});

const methodPolicyByKey = new Map(METHOD_POLICY.map((entry) => [entry.methodKey, entry]));

const tool = (
  toolName: string,
  group: RedAlertGroupId,
  phase: RedAlertPhase | "all",
  methodKeys: readonly string[],
  implemented: boolean,
  pendingReason?: string,
  sessionEvent?: ToolManifestEntry["sessionEvent"],
): ToolManifestEntry => ({
  tool: toolName,
  group,
  phase,
  methodKeys,
  schemaId: `${toolName}-v1`,
  sessionEvent: sessionEvent ?? (group === "bootstrap/capability" ? "red-alert/tool-group-selection" : "red-alert/state"),
  implemented,
  testId: `${toolName}:contract`,
  ...(pendingReason === undefined ? {} : { pendingReason }),
});

export const TOOL_MANIFEST: readonly ToolManifestEntry[] = [
  tool("red_alert_capabilities", "bootstrap/capability", "all", [], true),
  tool("red_alert_load_group", "bootstrap/capability", "all", [], true),
  tool("red_alert_field_manual", "strategy/learning", "catalog-only", [], true, undefined, "red-alert/field-manual"),
  tool("red_alert_strategy_brief", "strategy/learning", "catalog-only", [], true, undefined, "red-alert/strategy-brief"),
  tool("red_alert_review_match", "strategy/learning", "ended", [], true, undefined, "red-alert/strategy-review"),
  tool("red_alert_start", "lobby/setup", "catalog-only", [
    methodKey("PublicApi", "getAvailableGameModes"),
    methodKey("PublicApi", "createGame"),
  ], true),
  tool("red_alert_lobby_map", "lobby/setup", "running", [
    methodKey("PublicApi", "getAvailableMaps"),
    methodKey("MapApi", "getStartingLocations"),
  ], true),
  tool("red_alert_lobby_players", "lobby/setup", "running", [methodKey("GameApi", "getPlayers")], true),
  tool("red_alert_observe", "observation", "running", [methodKey("GameInstanceApi", "getPlayerStats")], true),
  tool("red_alert_status", "observation", "all", [
    methodKey("GameInstanceApi", "isFinished"),
    methodKey("GameInstanceApi", "getCurrentTick"),
    methodKey("GameInstanceApi", "getTickRate"),
    methodKey("GameApi", "getPlayerData"),
    methodKey("GameApi", "isPlayerDefeated"),
    methodKey("GameApi", "getVisibleUnits"),
    methodKey("GameApi", "getUnitData"),
    methodKey("GameApi", "getTickRate"),
    methodKey("GameApi", "getBaseTickRate"),
    methodKey("GameApi", "getCurrentTick"),
    methodKey("GameApi", "getCurrentTime"),
    methodKey("MapApi", "getRealMapSize"),
    methodKey("PlayerApi", "name"),
    methodKey("PlayerApi", "getPlayerData"),
    methodKey("PlayerApi", "isDefeated"),
    methodKey("PlayerApi", "getVisibleUnits"),
  ], true),
  tool("red_alert_unit_order", "units/combat", "running", [
    methodKey("GameInstanceApi", "update"),
    methodKey("ActionsApi", "orderUnits", 0),
    methodKey("ActionsApi", "orderUnits", 1),
    methodKey("ActionsApi", "orderUnits", 2),
  ], true),
  tool("red_alert_production_catalog", "production/economy", "running", [
    methodKey("ProductionApi", "isAvailableForProduction"),
    methodKey("ProductionApi", "getAvailableObjects"),
    methodKey("ProductionApi", "getQueueTypeForObject"),
  ], true),
  tool("red_alert_production_status", "production/economy", "running", [methodKey("ProductionApi", "getQueueData")], true),
  tool("red_alert_production", "production/economy", "running", [
    methodKey("ActionsApi", "pauseProduction"),
    methodKey("ActionsApi", "resumeProduction"),
    methodKey("ActionsApi", "queueForProduction"),
    methodKey("ActionsApi", "unqueueFromProduction"),
  ], true),
  tool("red_alert_construction_catalog", "construction", "running", [methodKey("GameApi", "getBuildingPlacementData")], true),
  tool("red_alert_construction", "construction", "running", [
    methodKey("GameApi", "canPlaceBuilding"),
    methodKey("PlayerApi", "canPlaceBuilding"),
    methodKey("ActionsApi", "placeBuilding"),
    methodKey("ActionsApi", "sellObject"),
    methodKey("ActionsApi", "sellBuilding"),
    methodKey("ActionsApi", "toggleRepairWrench"),
  ], true),
  tool("red_alert_map", "observation", "running", [
    methodKey("MapApi", "getTheaterType"),
    methodKey("MapApi", "getTile"),
    methodKey("MapApi", "getTilesInRect", 0),
    methodKey("MapApi", "getTilesInRect", 1),
    methodKey("MapApi", "hasBridgeOnTile"),
    methodKey("MapApi", "hasHighBridgeOnTile"),
  ], true),
  tool("red_alert_resources", "observation", "running", [methodKey("MapApi", "getTileResourceData")], true),
  tool("red_alert_diplomacy", "diplomacy/comms", "running", [
    methodKey("GameApi", "areAlliedPlayers"),
    methodKey("PlayerApi", "isAlliedWith"),
    methodKey("ActionsApi", "toggleAlliance"),
  ], true),
  tool("red_alert_superweapons", "superweapon", "running", [
    methodKey("GameApi", "getAllSuperWeaponData"),
    methodKey("ActionsApi", "activateSuperWeapon"),
  ], true),
  tool("red_alert_rules", "observation", "running", [methodKey("GameApi", "getGeneralRules")], true),
  tool("red_alert_stop", "lifecycle/replay", "all", [
    methodKey("GameInstanceApi", "dispose"),
    methodKey("ActionsApi", "quitGame"),
  ], true),
];

export const IMPLEMENTED_TOOL_NAMES = TOOL_MANIFEST.filter(entry => entry.implemented).map(entry => entry.tool);
export const DEFERRED_TOOL_NAMES = TOOL_MANIFEST.filter(entry => !entry.implemented).map(entry => entry.tool);

export function methodPolicy(methodKeyValue: string): MethodPolicy | undefined {
  return methodPolicyByKey.get(methodKeyValue);
}

export function toolsForGroup(group: RedAlertGroupId): readonly ToolManifestEntry[] {
  return TOOL_MANIFEST.filter(entry => entry.group === group);
}

export function policyForTool(toolName: string): readonly MethodPolicy[] {
  return METHOD_POLICY.filter(entry => entry.tool === toolName);
}
