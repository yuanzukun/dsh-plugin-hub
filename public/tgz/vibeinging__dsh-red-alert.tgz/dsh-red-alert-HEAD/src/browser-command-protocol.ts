import type { SessionEvent } from "@deepseek-ai/dsh-session";
import type { RpcResult } from "@deepseek-ai/dsh-client-connection/client";
import type { FogSafeContact, FogSafeObservation } from "../packages/game-host/src/fog-safe-observation.ts";

/** Fixed version for the DSH Host-to-browser red-alert command channel. */
export const BROWSER_TRANSPORT_PROTOCOL_VERSION = 1 as const;
/** Dedicated loopback host kept cross-site from the DSH Web origin. */
export const RED_ALERT_RENDERER_LOOPBACK_HOST = "localhost" as const;
/** Maximum number of orders accepted in one loopback command payload. */
export const MAX_BROWSER_ORDERS = 256;
/** Maximum contacts accepted in each fair-observation collection; not a combined total. */
export const MAX_BROWSER_OBSERVATION_CONTACTS = 4096;
/** Official Connection RPC channel owned by this external plugin. */
export const RED_ALERT_BROWSER_CHANNEL = "/red-alert" as const;
/** Durable first-phase event carrying one browser command into the outbox. */
export const RED_ALERT_BROWSER_COMMAND_EVENT = "red-alert/browser-command-admitted" as const;
/** Publication marker emitted only after the admitted command has flushed. */
export const RED_ALERT_BROWSER_COMMAND_PUBLISHED_EVENT = "red-alert/browser-command-published" as const;
/** Durable first-phase event carrying a safe result; it is not visible until its marker. */
export const RED_ALERT_BROWSER_COMMAND_RESULT_EVENT = "red-alert/browser-command-result" as const;
/** Publication marker emitted only after the full result has flushed. */
export const RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT = "red-alert/browser-command-result-published" as const;
/** Client projection key for the latest browser command state. */
export const RED_ALERT_BROWSER_COMMAND_PROJECTION = "redAlertCommand" as const;

export type BrowserOrderAction = "build" | "train" | "cancel" | "move" | "attackMove" | "attackTarget" | "retreat" | "deploy";

/** The only order fields that may cross the Host/browser boundary in D3. */
export interface BrowserOrder {
  readonly action: BrowserOrderAction;
  readonly target?: string;
  readonly qty?: number;
  readonly units?: string;
  readonly x?: number;
  readonly y?: number;
  readonly contact?: string;
  readonly reason?: string;
}

export interface BrowserCreateMatchRequest {
  readonly map?: string;
  readonly myCountry: string;
  readonly opponents: number;
  readonly opponentType: "noop" | "normal";
  readonly gameSpeed?: number;
}

/** Exact safe game operations carried after a model-facing group tool validates its schema. */
export type BrowserGameToolRequest =
  | { readonly tool: "red_alert_lobby_map" }
  | { readonly tool: "red_alert_lobby_players" }
  | { readonly tool: "red_alert_observe" }
  | { readonly tool: "red_alert_map"; readonly x?: number; readonly y?: number; readonly width?: number; readonly height?: number }
  | { readonly tool: "red_alert_resources"; readonly x: number; readonly y: number; readonly width: number; readonly height: number }
  | { readonly tool: "red_alert_rules" }
  | { readonly tool: "red_alert_production_catalog" }
  | { readonly tool: "red_alert_production_status" }
  | { readonly tool: "red_alert_production"; readonly operation: "queue" | "cancel" | "pause" | "resume"; readonly queueType: number; readonly name?: string; readonly quantity?: number }
  | { readonly tool: "red_alert_construction_catalog" }
  | { readonly tool: "red_alert_construction"; readonly operation: "place" | "sell" | "repair"; readonly name?: string; readonly objectId?: number; readonly x?: number; readonly y?: number }
  | { readonly tool: "red_alert_diplomacy"; readonly player?: string; readonly allied?: boolean }
  | { readonly tool: "red_alert_superweapons"; readonly type?: number; readonly x?: number; readonly y?: number; readonly x2?: number; readonly y2?: number };

/** Recursively bounded plain JSON returned by one exact renderer tool. */
export type BrowserToolValue = null | boolean | number | string | readonly BrowserToolValue[] | { readonly [key: string]: BrowserToolValue };

interface BrowserCommandIdentity {
  readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
  readonly requestId: string;
  readonly sessionId: string;
  readonly matchId: string;
  readonly seat: string;
  readonly expectedTick: number;
}

/** An opaque, identity-bound command retained by the durable outbox. */
export type BrowserCommandEnvelope = BrowserCommandIdentity & (
  | { readonly kind: "create-match"; readonly request: BrowserCreateMatchRequest }
  | { readonly kind: "orders"; readonly orders: readonly BrowserOrder[] }
  | { readonly kind: "tool"; readonly request: BrowserGameToolRequest }
  | { readonly kind: "observe" }
  | { readonly kind: "stop-match" }
);

/** Marker that makes an already-flushed command visible to the browser projection. */
export interface BrowserCommandPublicationEvent {
  readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
  readonly requestId: string;
  readonly sessionId: string;
  readonly matchId: string;
  readonly seat: string;
  readonly expectedTick: number;
}

/** Marker that exposes a previously flushed browser command result. */
export interface BrowserCommandResultPublicationEvent {
  readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
  readonly requestId: string;
  readonly sessionId: string;
  readonly matchId: string;
  readonly seat: string;
  readonly status: "completed" | "failed" | "cancelled";
}

/** Safe receipt returned by a browser adapter; no engine object is allowed. */
export interface BrowserCommandReceipt {
  readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
  readonly requestId: string;
  readonly sessionId: string;
  readonly matchId: string;
  readonly seat: string;
  readonly tick: number;
  readonly ok: boolean;
  readonly detail: string;
  readonly observation?: FogSafeObservation;
  readonly match?: BrowserMatchSnapshot;
  readonly toolResult?: BrowserToolValue;
}

/** Public match facts returned atomically with a fair browser observation. */
export interface BrowserMatchSnapshot {
  readonly map: string;
  readonly mapSize: { readonly width: number; readonly height: number };
  readonly myCountry: string;
  readonly status: "active" | "finished" | "stopped";
  readonly self: {
    readonly credits: number;
    readonly power: { readonly total: number; readonly drain: number; readonly isLowPower: boolean };
    readonly defeated: boolean;
  };
}

/** Host-side lease registration request. The token is never part of this payload. */
export interface BrowserLeaseRegisterRequest {
  readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
  readonly sessionId: string;
  readonly matchId: string;
  readonly seat: string;
  readonly clientInstanceId: string;
}

/** Host response containing the in-memory-only lease token. */
export interface BrowserLeaseValue {
  readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
  readonly sessionId: string;
  readonly matchId: string;
  readonly seat: string;
  readonly leaseToken: string;
}

/** Idempotent release request for the in-memory browser lease. */
export interface BrowserLeaseReleaseRequest {
  readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
  readonly sessionId: string;
  readonly leaseToken: string;
}

/** Live renderer config request; the lease binds it to the current session. */
export interface BrowserRendererConfigRequest {
  readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
  readonly sessionId: string;
  readonly matchId: string;
  readonly seat: string;
  readonly leaseToken: string;
}

/** Public live renderer endpoint; it contains no local filesystem path. */
export interface BrowserRendererConfigValue {
  readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
  readonly sessionId: string;
  readonly matchId: string;
  readonly seat: string;
  readonly url: string;
  readonly port: number;
}

/** Browser receipt RPC payload. The lease token is accepted and discarded at the Host boundary. */
export interface BrowserReceiptRequest extends BrowserCommandReceipt {
  readonly leaseToken: string;
}

export interface BrowserCommandFailure {
  readonly code: string;
  readonly message: string;
}

/** Wire state represented by the browser command projection. */
export type BrowserCommandProjectionState =
  | { readonly status: "idle" }
  | { readonly status: "pending"; readonly command: BrowserCommandEnvelope }
  | { readonly status: "completed"; readonly command: BrowserCommandEnvelope; readonly receipt: BrowserCommandReceipt }
  | { readonly status: "failed"; readonly command: BrowserCommandEnvelope; readonly failure: BrowserCommandFailure }
  | { readonly status: "cancelled"; readonly command: BrowserCommandEnvelope; readonly failure: BrowserCommandFailure };

/** Durable admitted-command event data. SessionEvent.seq remains the only event version. */
export type BrowserCommandEvent = BrowserCommandEnvelope;

/** Internal plain-JSON fold state; the admitted command is hidden by `view` until published. */
export interface BrowserCommandProjectionFoldState {
  readonly visible: BrowserCommandProjectionState;
  readonly admitted?: BrowserCommandEnvelope;
  readonly admittedResult?: BrowserCommandResultEvent;
}

/** Durable admitted-result event data. It repeats only safe command identity and fields, never a revision or token. */
export type BrowserCommandResultEvent =
  | {
      readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
      readonly requestId: string;
      readonly sessionId: string;
      readonly matchId: string;
      readonly seat: string;
      readonly command: BrowserCommandEnvelope;
      readonly status: "completed";
      readonly receipt: BrowserCommandReceipt;
    }
  | {
      readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
      readonly requestId: string;
      readonly sessionId: string;
      readonly matchId: string;
      readonly seat: string;
      readonly command: BrowserCommandEnvelope;
      readonly status: "failed" | "cancelled";
      readonly failure: BrowserCommandFailure;
    };

/** Durable result marker data; the full result remains in the preceding admitted event. */
export type BrowserCommandResultMarkerEvent = BrowserCommandResultPublicationEvent;

declare module "@deepseek-ai/dsh-session" {
  interface SessionEventMap {
    /** One safe command admitted to the browser outbox; it is not visible until the marker. */
    "red-alert/browser-command-admitted": BrowserCommandEvent;
    /** Makes an already-flushed command visible to the browser projection. */
    "red-alert/browser-command-published": BrowserCommandPublicationEvent;
    /** One safe browser command outcome admitted by the Host; it is not visible until its marker. */
    "red-alert/browser-command-result": BrowserCommandResultEvent;
    /** Makes an already-flushed browser command outcome visible to the projection. */
    "red-alert/browser-command-result-published": BrowserCommandResultPublicationEvent;
  }
}

declare module "@deepseek-ai/dsh-session/types" {
  interface SessionEventMap {
    /** One safe command admitted to the browser outbox; it is not visible until the marker. */
    "red-alert/browser-command-admitted": BrowserCommandEvent;
    /** Makes an already-flushed command visible to the browser projection. */
    "red-alert/browser-command-published": BrowserCommandPublicationEvent;
    /** One safe browser command outcome admitted by the Host; it is not visible until its marker. */
    "red-alert/browser-command-result": BrowserCommandResultEvent;
    /** Makes an already-flushed browser command outcome visible to the projection. */
    "red-alert/browser-command-result-published": BrowserCommandResultPublicationEvent;
  }
}

declare module "@deepseek-ai/dsh-session-projection/types" {
  interface SessionProjectionMap {
    /** Latest browser command state for the current DSH session. */
    redAlertCommand: BrowserCommandProjectionState;
  }
  interface SessionProjectionStateMap {
    /** Internal durable fold state; admitted values stay hidden until publication. */
    redAlertCommand: BrowserCommandProjectionFoldState;
  }
}

export type BrowserProtocolErrorCode = "INVALID_MESSAGE" | "PROTOCOL" | "IDENTITY" | "LEASE";

/** Bounded protocol error used before any engine or RPC error can cross the boundary. */
export class BrowserProtocolError extends Error {
  constructor(readonly code: BrowserProtocolErrorCode, message: string) {
    super(message);
    this.name = "BrowserProtocolError";
  }
}

const ORDER_ACTIONS: readonly BrowserOrderAction[] = [
  "build",
  "train",
  "cancel",
  "move",
  "attackMove",
  "attackTarget",
  "retreat",
  "deploy",
];
const ORDER_KEYS = new Set(["action", "target", "qty", "units", "x", "y", "contact", "reason"]);
const COMMAND_IDENTITY_KEYS = ["protocolVersion", "requestId", "sessionId", "matchId", "seat", "expectedTick", "kind"] as const;
const CREATE_REQUEST_KEYS = ["myCountry", "opponents", "opponentType"] as const;
const GAME_TOOL_NAMES = new Set<BrowserGameToolRequest["tool"]>([
  "red_alert_lobby_map", "red_alert_lobby_players", "red_alert_observe", "red_alert_map", "red_alert_resources", "red_alert_rules",
  "red_alert_production_catalog", "red_alert_production_status", "red_alert_production", "red_alert_construction_catalog", "red_alert_construction",
  "red_alert_diplomacy", "red_alert_superweapons",
]);
const PUBLICATION_KEYS = ["protocolVersion", "requestId", "sessionId", "matchId", "seat", "expectedTick"] as const;
const LEASE_KEYS = ["protocolVersion", "sessionId", "matchId", "seat", "clientInstanceId"] as const;
const LEASE_VALUE_KEYS = ["protocolVersion", "sessionId", "matchId", "seat", "leaseToken"] as const;
const LEASE_RELEASE_KEYS = ["protocolVersion", "sessionId", "leaseToken"] as const;
const RENDERER_CONFIG_KEYS = ["protocolVersion", "sessionId", "matchId", "seat", "leaseToken"] as const;
const RENDERER_CONFIG_VALUE_KEYS = ["protocolVersion", "sessionId", "matchId", "seat", "url", "port"] as const;
const RECEIPT_KEYS = ["protocolVersion", "requestId", "sessionId", "matchId", "seat", "tick", "ok", "detail"] as const;
const RECEIPT_REQUEST_KEYS = [...RECEIPT_KEYS, "leaseToken"] as const;
const RESULT_KEYS = ["protocolVersion", "requestId", "sessionId", "matchId", "seat", "command", "status"] as const;
const RESULT_PUBLICATION_KEYS = ["protocolVersion", "requestId", "sessionId", "matchId", "seat", "status"] as const;
const FAILURE_KEYS = ["code", "message"] as const;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function exactKeys(value: Record<string, unknown>, keys: readonly string[], optional: readonly string[] = []): boolean {
  const required = new Set(keys);
  const allowed = new Set([...keys, ...optional]);
  return Object.keys(value).every((key) => allowed.has(key)) && [...required].every((key) => Object.hasOwn(value, key));
}

function safeString(value: unknown): value is string {
  return typeof value === "string" && value.length > 0 && value.length <= 512;
}

function safeDetail(value: unknown): value is string {
  return typeof value === "string" && value.length <= 512;
}

function safeTick(value: unknown): value is number {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}

function safeNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function safeInteger(value: unknown): value is number {
  return typeof value === "number" && Number.isSafeInteger(value);
}

function decodeGameToolRequest(value: unknown): BrowserGameToolRequest {
  if (!isRecord(value) || !safeString(value.tool) || !GAME_TOOL_NAMES.has(value.tool as BrowserGameToolRequest["tool"])) {
    throw new BrowserProtocolError("INVALID_MESSAGE", "browser game tool request is invalid");
  }
  const noArgs = new Set(["red_alert_lobby_map", "red_alert_lobby_players", "red_alert_observe", "red_alert_rules", "red_alert_production_catalog", "red_alert_production_status", "red_alert_construction_catalog"]);
  if (noArgs.has(value.tool)) {
    if (!exactKeys(value, ["tool"])) throw new BrowserProtocolError("INVALID_MESSAGE", "browser game tool request has unknown fields");
    return value as BrowserGameToolRequest;
  }
  if (value.tool === "red_alert_map") {
    if (!exactKeys(value, ["tool"], ["x", "y", "width", "height"])) throw new BrowserProtocolError("INVALID_MESSAGE", "browser map request has unknown fields");
    for (const key of ["x", "y", "width", "height"] as const) if (value[key] !== undefined && !safeInteger(value[key])) throw new BrowserProtocolError("INVALID_MESSAGE", `browser map ${key} is invalid`);
    const rectangleValues = [value.x, value.y, value.width, value.height];
    const hasRectangle = rectangleValues.some(item => item !== undefined);
    if (hasRectangle && rectangleValues.some(item => item === undefined)) throw new BrowserProtocolError("INVALID_MESSAGE", "browser map rectangle is incomplete");
    if ((value.width !== undefined && (Number(value.width) < 1 || Number(value.width) > 16)) || (value.height !== undefined && (Number(value.height) < 1 || Number(value.height) > 16))) throw new BrowserProtocolError("INVALID_MESSAGE", "browser map dimensions are invalid");
    return value as BrowserGameToolRequest;
  }
  if (value.tool === "red_alert_resources") {
    if (!exactKeys(value, ["tool", "x", "y", "width", "height"]) || !safeInteger(value.x) || !safeInteger(value.y) || !safeInteger(value.width) || !safeInteger(value.height) || Number(value.width) < 1 || Number(value.width) > 16 || Number(value.height) < 1 || Number(value.height) > 16) throw new BrowserProtocolError("INVALID_MESSAGE", "browser resources request is invalid");
    return value as BrowserGameToolRequest;
  }
  if (value.tool === "red_alert_production") {
    if (!exactKeys(value, ["tool", "operation", "queueType"], ["name", "quantity"]) || !["queue", "cancel", "pause", "resume"].includes(String(value.operation)) || !safeInteger(value.queueType) || Number(value.queueType) < 0 || Number(value.queueType) > 5) throw new BrowserProtocolError("INVALID_MESSAGE", "browser production request is invalid");
    if (value.name !== undefined && !safeString(value.name)) throw new BrowserProtocolError("INVALID_MESSAGE", "browser production name is invalid");
    if (value.quantity !== undefined && (!safeInteger(value.quantity) || Number(value.quantity) < 1 || Number(value.quantity) > 99)) throw new BrowserProtocolError("INVALID_MESSAGE", "browser production quantity is invalid");
    if ((value.operation === "queue" || value.operation === "cancel") && (value.name === undefined || value.quantity === undefined)) throw new BrowserProtocolError("INVALID_MESSAGE", "browser production item is required");
    return value as BrowserGameToolRequest;
  }
  if (value.tool === "red_alert_construction") {
    if (!exactKeys(value, ["tool", "operation"], ["name", "objectId", "x", "y"]) || !["place", "sell", "repair"].includes(String(value.operation))) throw new BrowserProtocolError("INVALID_MESSAGE", "browser construction request is invalid");
    if (value.name !== undefined && !safeString(value.name)) throw new BrowserProtocolError("INVALID_MESSAGE", "browser construction name is invalid");
    for (const key of ["objectId", "x", "y"] as const) if (value[key] !== undefined && !safeInteger(value[key])) throw new BrowserProtocolError("INVALID_MESSAGE", `browser construction ${key} is invalid`);
    if (value.operation === "place" && (value.name === undefined || value.x === undefined || value.y === undefined)) throw new BrowserProtocolError("INVALID_MESSAGE", "browser construction placement is incomplete");
    if ((value.operation === "sell" || value.operation === "repair") && value.objectId === undefined) throw new BrowserProtocolError("INVALID_MESSAGE", "browser construction objectId is required");
    return value as BrowserGameToolRequest;
  }
  if (value.tool === "red_alert_diplomacy") {
    if (!exactKeys(value, ["tool"], ["player", "allied"]) || (value.player !== undefined && !safeString(value.player)) || (value.allied !== undefined && typeof value.allied !== "boolean") || ((value.player === undefined) !== (value.allied === undefined))) throw new BrowserProtocolError("INVALID_MESSAGE", "browser diplomacy request is invalid");
    return value as BrowserGameToolRequest;
  }
  if (!exactKeys(value, ["tool"], ["type", "x", "y", "x2", "y2"])) throw new BrowserProtocolError("INVALID_MESSAGE", "browser superweapon request has unknown fields");
  for (const key of ["type", "x", "y", "x2", "y2"] as const) if (value[key] !== undefined && !safeInteger(value[key])) throw new BrowserProtocolError("INVALID_MESSAGE", `browser superweapon ${key} is invalid`);
  if (value.type !== undefined && (value.x === undefined || value.y === undefined)) throw new BrowserProtocolError("INVALID_MESSAGE", "browser superweapon target is incomplete");
  return value as BrowserGameToolRequest;
}

/** Validate a renderer tool result before it becomes durable or model-visible. */
export function decodeBrowserToolValue(value: unknown): BrowserToolValue {
  let nodes = 0;
  const visit = (current: unknown, depth: number): BrowserToolValue => {
    nodes += 1;
    if (nodes > 8192 || depth > 8) throw new BrowserProtocolError("INVALID_MESSAGE", "browser tool result exceeds its structural limit");
    if (current === null || typeof current === "boolean" || (typeof current === "number" && Number.isFinite(current))) return current;
    if (typeof current === "string" && current.length <= 512) return current;
    if (Array.isArray(current) && current.length <= 4096) return current.map(item => visit(item, depth + 1));
    if (isRecord(current) && Object.keys(current).length <= 256 && Object.keys(current).every(key => key.length > 0 && key.length <= 128)) {
      return Object.fromEntries(Object.entries(current).map(([key, item]) => [key, visit(item, depth + 1)]));
    }
    throw new BrowserProtocolError("INVALID_MESSAGE", "browser tool result is not bounded plain JSON");
  };
  return visit(value, 0);
}

/** Validate one renderer result against the exact tool that produced it. */
export function decodeBrowserToolResult(request: BrowserGameToolRequest, value: unknown): BrowserToolValue {
  const decoded = decodeBrowserToolValue(value);
  const fail = (): never => { throw new BrowserProtocolError("INVALID_MESSAGE", `browser ${request.tool} result is invalid`); };
  const record = (current: BrowserToolValue): Record<string, BrowserToolValue> => isRecord(current) ? current as Record<string, BrowserToolValue> : fail();
  const fields = (current: BrowserToolValue, required: readonly string[], optional: readonly string[] = []): Record<string, BrowserToolValue> => {
    const result = record(current);
    return exactKeys(result, required, optional) ? result : fail();
  };
  const textValue = (current: BrowserToolValue): string => typeof current === "string" && current.length > 0 ? current : fail();
  const numberValue = (current: BrowserToolValue): number => typeof current === "number" && Number.isFinite(current) ? current : fail();
  const booleanValue = (current: BrowserToolValue): boolean => typeof current === "boolean" ? current : fail();
  const arrayValue = (current: BrowserToolValue): readonly BrowserToolValue[] => Array.isArray(current) ? current : fail();
  const sizeValue = (current: BrowserToolValue): void => {
    const size = fields(current, ["width", "height"]);
    numberValue(size.width);
    numberValue(size.height);
  };
  const playersValue = (current: BrowserToolValue): void => {
    for (const item of arrayValue(current)) {
      const player = fields(item, ["name", "self", "ai", "defeated", "allied"]);
      textValue(player.name);
      booleanValue(player.self);
      booleanValue(player.ai);
      booleanValue(player.defeated);
      booleanValue(player.allied);
    }
  };
  const queuesValue = (current: BrowserToolValue): void => {
    for (const item of arrayValue(current)) {
      const queue = fields(item, ["queueType", "size", "maxSize", "status", "items"]);
      numberValue(queue.queueType);
      numberValue(queue.size);
      numberValue(queue.maxSize);
      numberValue(queue.status);
      for (const queueItemValue of arrayValue(queue.items)) {
        const queueItem = fields(queueItemValue, ["name", "objectType", "quantity"]);
        textValue(queueItem.name);
        numberValue(queueItem.objectType);
        numberValue(queueItem.quantity);
      }
    }
  };

  if (request.tool === "red_alert_lobby_map") {
    const result = fields(decoded, ["map", "theater", "size", "ownStart"]);
    textValue(result.map);
    numberValue(result.theater);
    sizeValue(result.size);
    const start = fields(result.ownStart, ["x", "y"]);
    numberValue(start.x);
    numberValue(start.y);
    return decoded;
  }
  if (request.tool === "red_alert_lobby_players" || request.tool === "red_alert_diplomacy") {
    const result = fields(decoded, ["players"]);
    playersValue(result.players);
    return decoded;
  }
  if (request.tool === "red_alert_observe") {
    const result = fields(decoded, ["observation"]);
    decodeBrowserObservation(result.observation);
    return decoded;
  }
  if (request.tool === "red_alert_map") {
    const result = fields(decoded, ["map", "theater", "size"], ["tiles"]);
    textValue(result.map);
    numberValue(result.theater);
    sizeValue(result.size);
    if (result.tiles !== undefined) for (const item of arrayValue(result.tiles)) {
      const tile = fields(item, ["x", "y", "elevation", "bridge", "highBridge"]);
      numberValue(tile.x);
      numberValue(tile.y);
      numberValue(tile.elevation);
      booleanValue(tile.bridge);
      booleanValue(tile.highBridge);
    }
    return decoded;
  }
  if (request.tool === "red_alert_resources") {
    const result = fields(decoded, ["resources"]);
    for (const item of arrayValue(result.resources)) {
      const resource = fields(item, ["x", "y", "ore", "gems", "spawnsOre"]);
      numberValue(resource.x);
      numberValue(resource.y);
      numberValue(resource.ore);
      numberValue(resource.gems);
      booleanValue(resource.spawnsOre);
    }
    return decoded;
  }
  if (request.tool === "red_alert_rules") {
    const result = fields(decoded, ["baseUnits", "harvesterUnits", "buildSpeed", "maximumQueuedObjects", "refundPercent", "closeEnough"]);
    for (const item of arrayValue(result.baseUnits)) textValue(item);
    for (const item of arrayValue(result.harvesterUnits)) textValue(item);
    numberValue(result.buildSpeed);
    numberValue(result.maximumQueuedObjects);
    numberValue(result.refundPercent);
    numberValue(result.closeEnough);
    return decoded;
  }
  if (request.tool === "red_alert_production_catalog") {
    const result = fields(decoded, ["items"]);
    for (const item of arrayValue(result.items)) {
      const product = fields(item, ["name", "objectType", "queueType", "cost", "buildLimit"]);
      textValue(product.name);
      numberValue(product.objectType);
      numberValue(product.queueType);
      numberValue(product.cost);
      numberValue(product.buildLimit);
    }
    return decoded;
  }
  if (request.tool === "red_alert_production_status") {
    const result = fields(decoded, ["queues"]);
    queuesValue(result.queues);
    return decoded;
  }
  if (request.tool === "red_alert_production") {
    const result = fields(decoded, ["operation", "queues"]);
    if (textValue(result.operation) !== request.operation) fail();
    queuesValue(result.queues);
    return decoded;
  }
  if (request.tool === "red_alert_construction_catalog") {
    const result = fields(decoded, ["buildings"]);
    for (const item of arrayValue(result.buildings)) {
      const building = fields(item, ["name", "cost", "queueType", "foundation"]);
      textValue(building.name);
      numberValue(building.cost);
      numberValue(building.queueType);
      sizeValue(building.foundation);
    }
    return decoded;
  }
  if (request.tool === "red_alert_construction") {
    const result = fields(decoded, ["operation", "accepted"], ["placement"]);
    if (textValue(result.operation) !== request.operation || booleanValue(result.accepted) !== true) fail();
    if (request.operation === "place") {
      const placement = fields(result.placement, ["x", "y"]);
      numberValue(placement.x);
      numberValue(placement.y);
    } else if (result.placement !== undefined) {
      fail();
    }
    return decoded;
  }
  const result = fields(decoded, ["weapons"]);
  for (const item of arrayValue(result.weapons)) {
    const weapon = fields(item, ["type", "status", "timerSeconds"]);
    if (typeof weapon.type === "number") numberValue(weapon.type);
    else textValue(weapon.type);
    textValue(weapon.status);
    numberValue(weapon.timerSeconds);
  }
  return decoded;
}

function isSafeOrder(value: unknown): value is BrowserOrder {
  if (!isRecord(value) || !Object.hasOwn(value, "action") || !ORDER_ACTIONS.includes(value.action as BrowserOrderAction)) return false;
  if (!Object.keys(value).every((key) => ORDER_KEYS.has(key))) return false;
  if (value.target !== undefined && !safeString(value.target)) return false;
  if (value.qty !== undefined && (typeof value.qty !== "number" || !Number.isSafeInteger(value.qty) || value.qty < 1)) return false;
  if (value.units !== undefined && !safeString(value.units)) return false;
  if (value.x !== undefined && !Number.isSafeInteger(value.x)) return false;
  if (value.y !== undefined && !Number.isSafeInteger(value.y)) return false;
  if (value.contact !== undefined && !safeString(value.contact)) return false;
  if (value.reason !== undefined && !safeDetail(value.reason)) return false;
  return true;
}

function decodeCreateMatchRequest(value: unknown): BrowserCreateMatchRequest {
  if (!isRecord(value) || !exactKeys(value, CREATE_REQUEST_KEYS, ["map", "gameSpeed"])) throw new BrowserProtocolError("INVALID_MESSAGE", "browser create-match request has unknown or missing fields");
  if (!safeString(value.myCountry) || !Number.isSafeInteger(value.opponents) || Number(value.opponents) < 1 || Number(value.opponents) > 7 || (value.opponentType !== "noop" && value.opponentType !== "normal")) {
    throw new BrowserProtocolError("INVALID_MESSAGE", "browser create-match request is invalid");
  }
  if (value.map !== undefined && !safeString(value.map)) throw new BrowserProtocolError("INVALID_MESSAGE", "browser create-match map is invalid");
  if (value.gameSpeed !== undefined && (!Number.isSafeInteger(value.gameSpeed) || Number(value.gameSpeed) < 0 || Number(value.gameSpeed) > 6)) {
    throw new BrowserProtocolError("INVALID_MESSAGE", "browser create-match game speed is invalid");
  }
  return value as unknown as BrowserCreateMatchRequest;
}

export function decodeBrowserMatchSnapshot(value: unknown): BrowserMatchSnapshot {
  if (!isRecord(value) || !exactKeys(value, ["map", "mapSize", "myCountry", "status", "self"])) throw new BrowserProtocolError("INVALID_MESSAGE", "browser match snapshot has unknown or missing fields");
  if (!safeString(value.map) || !safeString(value.myCountry) || (value.status !== "active" && value.status !== "finished" && value.status !== "stopped")) throw new BrowserProtocolError("INVALID_MESSAGE", "browser match snapshot identity is invalid");
  if (!isRecord(value.mapSize) || !exactKeys(value.mapSize, ["width", "height"]) || !safeNumber(value.mapSize.width) || value.mapSize.width <= 0 || !safeNumber(value.mapSize.height) || value.mapSize.height <= 0) throw new BrowserProtocolError("INVALID_MESSAGE", "browser match map size is invalid");
  if (!isRecord(value.self) || !exactKeys(value.self, ["credits", "power", "defeated"]) || !safeNumber(value.self.credits) || value.self.credits < 0 || typeof value.self.defeated !== "boolean") throw new BrowserProtocolError("INVALID_MESSAGE", "browser match self state is invalid");
  if (!isRecord(value.self.power) || !exactKeys(value.self.power, ["total", "drain", "isLowPower"]) || !safeNumber(value.self.power.total) || !safeNumber(value.self.power.drain) || typeof value.self.power.isLowPower !== "boolean") throw new BrowserProtocolError("INVALID_MESSAGE", "browser match power state is invalid");
  return value as unknown as BrowserMatchSnapshot;
}

function isFogSafeContact(value: unknown, expectedSource: FogSafeContact["source"]): value is FogSafeContact {
  if (!isRecord(value) || !exactKeys(value, ["id", "unitType", "label", "kind", "position", "hpPct", "observedAtTick", "source"])) return false;
  if (typeof value.id !== "number" || !Number.isSafeInteger(value.id) || value.id < 0) return false;
  if (!safeString(value.unitType) || !safeString(value.label) || !safeString(value.kind)) return false;
  if (value.source !== expectedSource || !safeTick(value.observedAtTick)) return false;
  if (!safeNumber(value.hpPct) || value.hpPct < 0 || value.hpPct > 100) return false;
  if (!isRecord(value.position) || !exactKeys(value.position, ["x", "y"]) || !safeNumber(value.position.x) || !safeNumber(value.position.y)) return false;
  return true;
}

/** Decode the only observation shape that may be placed in a browser receipt. */
export function decodeBrowserObservation(value: unknown): FogSafeObservation {
  if (!isRecord(value) || !exactKeys(value, ["tick", "ownUnits", "visibleEnemies", "lastSeenEnemies", "visibleNeutralObjects"])) {
    throw new BrowserProtocolError("INVALID_MESSAGE", "browser observation is not FogSafeObservation");
  }
  if (!safeTick(value.tick)) throw new BrowserProtocolError("INVALID_MESSAGE", "browser observation tick is invalid");
  if (!Array.isArray(value.ownUnits) || value.ownUnits.length > MAX_BROWSER_OBSERVATION_CONTACTS || !value.ownUnits.every((item) => isFogSafeContact(item, "visible"))) throw new BrowserProtocolError("INVALID_MESSAGE", "browser ownUnits are invalid");
  if (!Array.isArray(value.visibleEnemies) || value.visibleEnemies.length > MAX_BROWSER_OBSERVATION_CONTACTS || !value.visibleEnemies.every((item) => isFogSafeContact(item, "visible"))) throw new BrowserProtocolError("INVALID_MESSAGE", "browser visibleEnemies are invalid");
  if (!Array.isArray(value.lastSeenEnemies) || value.lastSeenEnemies.length > MAX_BROWSER_OBSERVATION_CONTACTS || !value.lastSeenEnemies.every((item) => isFogSafeContact(item, "last-seen"))) throw new BrowserProtocolError("INVALID_MESSAGE", "browser lastSeenEnemies are invalid");
  if (!Array.isArray(value.visibleNeutralObjects) || value.visibleNeutralObjects.length > MAX_BROWSER_OBSERVATION_CONTACTS || !value.visibleNeutralObjects.every((item) => isFogSafeContact(item, "visible"))) throw new BrowserProtocolError("INVALID_MESSAGE", "browser visibleNeutralObjects are invalid");
  const visibleEnemyIds = new Set(value.visibleEnemies.map((item) => item.id));
  if (value.lastSeenEnemies.some((item) => visibleEnemyIds.has(item.id))) throw new BrowserProtocolError("INVALID_MESSAGE", "browser observation overlaps visible and last-seen enemies");
  return value as unknown as FogSafeObservation;
}

/** Decode a safe command envelope from a durable projection or adapter boundary. */
export function decodeBrowserCommand(value: unknown): BrowserCommandEnvelope {
  if (!isRecord(value) || !COMMAND_IDENTITY_KEYS.every((key) => Object.hasOwn(value, key))) throw new BrowserProtocolError("INVALID_MESSAGE", "browser command has missing fields");
  if (value.protocolVersion !== BROWSER_TRANSPORT_PROTOCOL_VERSION) throw new BrowserProtocolError("PROTOCOL", "browser command protocol is unsupported");
  if (!safeString(value.requestId) || !safeString(value.sessionId) || !safeString(value.matchId) || !safeString(value.seat) || !safeTick(value.expectedTick)) throw new BrowserProtocolError("IDENTITY", "browser command identity is invalid");
  if (value.kind === "orders") {
    if (!exactKeys(value, [...COMMAND_IDENTITY_KEYS, "orders"]) || !Array.isArray(value.orders) || value.orders.length > MAX_BROWSER_ORDERS || !value.orders.every(isSafeOrder)) throw new BrowserProtocolError("INVALID_MESSAGE", "browser command orders are invalid");
    return value as unknown as BrowserCommandEnvelope;
  }
  if (value.kind === "create-match") {
    if (!exactKeys(value, [...COMMAND_IDENTITY_KEYS, "request"])) throw new BrowserProtocolError("INVALID_MESSAGE", "browser create-match command has unknown fields");
    decodeCreateMatchRequest(value.request);
    return value as unknown as BrowserCommandEnvelope;
  }
  if (value.kind === "tool") {
    if (!exactKeys(value, [...COMMAND_IDENTITY_KEYS, "request"])) throw new BrowserProtocolError("INVALID_MESSAGE", "browser tool command has unknown fields");
    return { ...value, request: decodeGameToolRequest(value.request) } as BrowserCommandEnvelope;
  }
  if (value.kind === "observe" || value.kind === "stop-match") {
    if (!exactKeys(value, COMMAND_IDENTITY_KEYS)) throw new BrowserProtocolError("INVALID_MESSAGE", "browser observe command has unknown fields");
    return value as unknown as BrowserCommandEnvelope;
  }
  throw new BrowserProtocolError("PROTOCOL", "browser command kind is unsupported");
}

/** Decode a strict lease registration request. */
export function decodeBrowserLeaseRequest(value: unknown): BrowserLeaseRegisterRequest {
  if (!isRecord(value) || !exactKeys(value, LEASE_KEYS)) throw new BrowserProtocolError("INVALID_MESSAGE", "browser lease request has unknown or missing fields");
  if (value.protocolVersion !== BROWSER_TRANSPORT_PROTOCOL_VERSION || !safeString(value.sessionId) || !safeString(value.matchId) || !safeString(value.seat) || !safeString(value.clientInstanceId)) throw new BrowserProtocolError("IDENTITY", "browser lease identity is invalid");
  return value as unknown as BrowserLeaseRegisterRequest;
}

/** Compatibility-named alias used by the Host transport endpoint. */
export const decodeBrowserLeaseRegisterRequest = decodeBrowserLeaseRequest;

/** Decode the opaque lease value returned by the Host. */
export function decodeBrowserLeaseValue(value: unknown): BrowserLeaseValue {
  if (!isRecord(value) || !exactKeys(value, LEASE_VALUE_KEYS)) throw new BrowserProtocolError("INVALID_MESSAGE", "browser lease response has unknown or missing fields");
  if (value.protocolVersion !== BROWSER_TRANSPORT_PROTOCOL_VERSION || !safeString(value.sessionId) || !safeString(value.matchId) || !safeString(value.seat) || !safeString(value.leaseToken)) throw new BrowserProtocolError("IDENTITY", "browser lease response is invalid");
  return value as unknown as BrowserLeaseValue;
}

/** Decode a strict lease release request. */
export function decodeBrowserLeaseReleaseRequest(value: unknown): BrowserLeaseReleaseRequest {
  if (!isRecord(value) || !exactKeys(value, LEASE_RELEASE_KEYS)) throw new BrowserProtocolError("INVALID_MESSAGE", "browser lease release has unknown or missing fields");
  if (value.protocolVersion !== BROWSER_TRANSPORT_PROTOCOL_VERSION || !safeString(value.sessionId) || !safeString(value.leaseToken)) throw new BrowserProtocolError("IDENTITY", "browser lease release identity is invalid");
  return value as unknown as BrowserLeaseReleaseRequest;
}

/** Decode a lease-bound live renderer config request. */
export function decodeBrowserRendererConfigRequest(value: unknown): BrowserRendererConfigRequest {
  if (!isRecord(value) || !exactKeys(value, RENDERER_CONFIG_KEYS)) throw new BrowserProtocolError("INVALID_MESSAGE", "renderer config request has unknown or missing fields");
  if (value.protocolVersion !== BROWSER_TRANSPORT_PROTOCOL_VERSION || !safeString(value.sessionId) || !safeString(value.matchId) || !safeString(value.seat) || !safeString(value.leaseToken)) throw new BrowserProtocolError("IDENTITY", "renderer config request identity is invalid");
  return value as unknown as BrowserRendererConfigRequest;
}

/** Decode a loopback-only live renderer config value. */
export function decodeBrowserRendererConfigValue(value: unknown): BrowserRendererConfigValue {
  if (!isRecord(value) || !exactKeys(value, RENDERER_CONFIG_VALUE_KEYS)) throw new BrowserProtocolError("INVALID_MESSAGE", "renderer config value has unknown or missing fields");
  if (value.protocolVersion !== BROWSER_TRANSPORT_PROTOCOL_VERSION || !safeString(value.sessionId) || !safeString(value.matchId) || !safeString(value.seat) || typeof value.port !== "number" || !Number.isSafeInteger(value.port) || value.port < 1 || value.port > 65535 || typeof value.url !== "string") throw new BrowserProtocolError("IDENTITY", "renderer config value identity is invalid");
  let url: URL;
  try {
    url = new URL(value.url);
  } catch {
    throw new BrowserProtocolError("INVALID_MESSAGE", "renderer config URL is invalid");
  }
  if (url.protocol !== "http:" || url.hostname !== RED_ALERT_RENDERER_LOOPBACK_HOST || url.port !== String(value.port) || url.pathname !== "/" || url.search !== "" || url.hash !== "" || url.username !== "" || url.password !== "") throw new BrowserProtocolError("INVALID_MESSAGE", "renderer config URL is not the expected isolated loopback endpoint");
  return value as unknown as BrowserRendererConfigValue;
}

/** Decode the receipt accepted by the Host. Lease tokens are checked separately. */
export function decodeBrowserReceipt(value: unknown): BrowserReceiptRequest {
  if (!isRecord(value) || !exactKeys(value, RECEIPT_REQUEST_KEYS, ["observation", "match", "toolResult"])) throw new BrowserProtocolError("INVALID_MESSAGE", "browser receipt has unknown or missing fields");
  if (value.protocolVersion !== BROWSER_TRANSPORT_PROTOCOL_VERSION || !safeString(value.requestId) || !safeString(value.sessionId) || !safeString(value.matchId) || !safeString(value.seat) || !safeTick(value.tick) || typeof value.ok !== "boolean" || !safeDetail(value.detail) || !safeString(value.leaseToken)) throw new BrowserProtocolError("IDENTITY", "browser receipt identity is invalid");
  if (value.observation !== undefined) {
    const observation = decodeBrowserObservation(value.observation);
    if (observation.tick !== value.tick) throw new BrowserProtocolError("PROTOCOL", "browser receipt observation tick does not match receipt tick");
  }
  if (value.match !== undefined) decodeBrowserMatchSnapshot(value.match);
  if (value.toolResult !== undefined) decodeBrowserToolValue(value.toolResult);
  return value as unknown as BrowserReceiptRequest;
}

/** Decode a safe receipt without the in-memory lease token. */
export function decodeBrowserCommandReceipt(value: unknown): BrowserCommandReceipt {
  if (!isRecord(value) || !exactKeys(value, RECEIPT_KEYS, ["observation", "match", "toolResult"])) throw new BrowserProtocolError("INVALID_MESSAGE", "browser adapter receipt has unknown or missing fields");
  if (value.protocolVersion !== BROWSER_TRANSPORT_PROTOCOL_VERSION || !safeString(value.requestId) || !safeString(value.sessionId) || !safeString(value.matchId) || !safeString(value.seat) || !safeTick(value.tick) || typeof value.ok !== "boolean" || !safeDetail(value.detail)) throw new BrowserProtocolError("IDENTITY", "browser adapter receipt identity is invalid");
  if (value.observation !== undefined) {
    const observation = decodeBrowserObservation(value.observation);
    if (observation.tick !== value.tick) throw new BrowserProtocolError("PROTOCOL", "browser adapter observation tick does not match receipt tick");
  }
  if (value.match !== undefined) decodeBrowserMatchSnapshot(value.match);
  if (value.toolResult !== undefined) decodeBrowserToolValue(value.toolResult);
  return value as unknown as BrowserCommandReceipt;
}

/** Enforce the command/result relationship before a receipt becomes durable or model-visible. */
export function validateBrowserCommandReceipt(command: BrowserCommandEnvelope, receipt: BrowserCommandReceipt): BrowserCommandReceipt {
  if (command.kind === "tool") {
    if (receipt.ok && receipt.toolResult === undefined) throw new BrowserProtocolError("INVALID_MESSAGE", "browser tool receipt is missing its exact result");
    if (receipt.toolResult !== undefined) decodeBrowserToolResult(command.request, receipt.toolResult);
  } else if (receipt.toolResult !== undefined) {
    throw new BrowserProtocolError("INVALID_MESSAGE", "non-tool browser receipt contains a tool result");
  }
  return receipt;
}

/** Decode a persisted admitted failed or completed command result. */
export function decodeBrowserCommandResult(value: unknown): BrowserCommandResultEvent {
  if (!isRecord(value) || !exactKeys(value, RESULT_KEYS, ["receipt", "failure"])) throw new BrowserProtocolError("INVALID_MESSAGE", "browser command result has unknown or missing fields");
  if (value.protocolVersion !== BROWSER_TRANSPORT_PROTOCOL_VERSION || !safeString(value.requestId) || !safeString(value.sessionId) || !safeString(value.matchId) || !safeString(value.seat)) throw new BrowserProtocolError("IDENTITY", "browser command result identity is invalid");
  const command = decodeBrowserCommand(value.command);
  if (command.requestId !== value.requestId || command.sessionId !== value.sessionId || command.matchId !== value.matchId || command.seat !== value.seat) throw new BrowserProtocolError("IDENTITY", "browser command result identity does not match command");
  if (value.status === "completed") {
    if (!Object.hasOwn(value, "receipt") || Object.hasOwn(value, "failure")) throw new BrowserProtocolError("INVALID_MESSAGE", "completed browser result shape is invalid");
    const receipt = decodeBrowserCommandReceipt(value.receipt);
    if (receipt.requestId !== value.requestId || receipt.sessionId !== value.sessionId || receipt.matchId !== value.matchId || receipt.seat !== value.seat) throw new BrowserProtocolError("IDENTITY", "browser receipt identity does not match command");
    validateBrowserCommandReceipt(command, receipt);
    return value as unknown as BrowserCommandResultEvent;
  }
  if (value.status !== "failed" && value.status !== "cancelled") throw new BrowserProtocolError("INVALID_MESSAGE", "browser command result status is invalid");
  if (!Object.hasOwn(value, "failure") || Object.hasOwn(value, "receipt") || !isRecord(value.failure) || !exactKeys(value.failure, FAILURE_KEYS) || !safeString(value.failure.code) || !safeDetail(value.failure.message)) throw new BrowserProtocolError("INVALID_MESSAGE", "browser command failure shape is invalid");
  return value as unknown as BrowserCommandResultEvent;
}

/** Decode the marker that exposes a previously flushed command result. */
export function decodeBrowserCommandResultPublicationEvent(value: unknown): BrowserCommandResultPublicationEvent {
  if (!isRecord(value) || !exactKeys(value, RESULT_PUBLICATION_KEYS)) throw new BrowserProtocolError("INVALID_MESSAGE", "browser result publication has unknown or missing fields");
  if (value.protocolVersion !== BROWSER_TRANSPORT_PROTOCOL_VERSION || !safeString(value.requestId) || !safeString(value.sessionId) || !safeString(value.matchId) || !safeString(value.seat)) throw new BrowserProtocolError("IDENTITY", "browser result publication identity is invalid");
  if (value.status !== "completed" && value.status !== "failed" && value.status !== "cancelled") throw new BrowserProtocolError("INVALID_MESSAGE", "browser result publication status is invalid");
  return value as unknown as BrowserCommandResultPublicationEvent;
}

/** Decode the durable command event without accepting lease or engine fields. */
export function decodeBrowserCommandEvent(value: unknown): BrowserCommandEvent {
  return decodeBrowserCommand(value);
}

/** Decode the marker that exposes only a previously admitted command. */
export function decodeBrowserCommandPublicationEvent(value: unknown): BrowserCommandPublicationEvent {
  if (!isRecord(value) || !exactKeys(value, PUBLICATION_KEYS)) throw new BrowserProtocolError("INVALID_MESSAGE", "browser command publication has unknown or missing fields");
  if (value.protocolVersion !== BROWSER_TRANSPORT_PROTOCOL_VERSION || !safeString(value.requestId) || !safeString(value.sessionId) || !safeString(value.matchId) || !safeString(value.seat) || !safeTick(value.expectedTick)) throw new BrowserProtocolError("IDENTITY", "browser command publication identity is invalid");
  return value as unknown as BrowserCommandPublicationEvent;
}

/** Convert a completed result into the client projection state. */
export function projectBrowserCommandResult(result: BrowserCommandResultEvent): BrowserCommandProjectionState {
  if (result.status === "completed") return { status: "completed", command: result.command, receipt: result.receipt };
  return { status: result.status, command: result.command, failure: result.failure };
}

/** Runtime guard for an exact projection value read from the DSH client store. */
export function decodeBrowserCommandProjection(value: unknown): BrowserCommandProjectionState {
  if (!isRecord(value) || typeof value.status !== "string") throw new BrowserProtocolError("INVALID_MESSAGE", "browser command projection has unknown or missing fields");
  if (value.status === "idle") {
    if (!exactKeys(value, ["status"])) throw new BrowserProtocolError("INVALID_MESSAGE", "idle browser command projection is invalid");
    return value as BrowserCommandProjectionState;
  }
  if (!Object.hasOwn(value, "command")) throw new BrowserProtocolError("INVALID_MESSAGE", "browser command projection is missing command");
  const command = decodeBrowserCommand(value.command);
  if (value.status === "pending") {
    if (!exactKeys(value, ["status", "command"])) throw new BrowserProtocolError("INVALID_MESSAGE", "pending browser command projection is invalid");
    return { status: "pending", command };
  }
  if (value.status === "completed") {
    if (!exactKeys(value, ["status", "command", "receipt"])) throw new BrowserProtocolError("INVALID_MESSAGE", "completed browser command projection is invalid");
    const receipt = decodeBrowserCommandReceipt(value.receipt);
    validateBrowserCommandReceipt(command, receipt);
    return { status: "completed", command, receipt };
  }
  if (value.status !== "failed" && value.status !== "cancelled") throw new BrowserProtocolError("INVALID_MESSAGE", "browser command projection status is invalid");
  if (!exactKeys(value, ["status", "command", "failure"]) || !isRecord(value.failure) || !exactKeys(value.failure, FAILURE_KEYS) || !safeString(value.failure.code) || !safeDetail(value.failure.message)) throw new BrowserProtocolError("INVALID_MESSAGE", "failed browser command projection is invalid");
  return { status: value.status, command, failure: value.failure as unknown as BrowserCommandFailure };
}

/** Build a bounded protocol failure for the official Connection RpcResult shape. */
export function browserRpcError(code: string, message: string): RpcResult<never> {
  const bounded = message.slice(0, 240);
  if (code === "CANCELLED" || code === "cancelled") return { ok: false, error: { code: "cancelled", message: bounded, details: {} } };
  return { ok: false, error: { code: "internal", message: `${code}: ${bounded}`.slice(0, 240), details: {} } };
}

/** Keep event types visible to declaration emit without importing a second runtime. */
export type { FogSafeContact, FogSafeObservation, SessionEvent };
