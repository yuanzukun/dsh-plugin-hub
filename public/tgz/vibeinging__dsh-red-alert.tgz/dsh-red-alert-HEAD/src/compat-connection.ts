import type { IncomingMessage, ServerResponse } from "node:http";
import { Service, type Context } from "@deepseek-ai/cordis";
import type {
  ConnectionRpcEndpointMatcher,
  ConnectionRpcHandler,
  ConnectionRpcHandlerOptions,
  HostConnectionHandle,
  HostConnectionRpc,
} from "@deepseek-ai/dsh-client-connection";
import type { WebRoute } from "@deepseek-ai/dsh-host-webserver";

declare module "@deepseek-ai/cordis" {
  interface Context {
    redAlertCompatConnection: RedAlertCompatConnectionService;
  }
}

const BODY_LIMIT = 1_048_576;
const CHANNEL_PATTERN = /^\/[A-Za-z0-9._~-]+$/;
const ENDPOINT_SEGMENT_PATTERN = /^[A-Za-z0-9_$.-]+$/;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/** Detect the generic Host RPC seam instead of trusting the service name alone. */
export function supportsHostConnectionRpc(value: unknown): value is HostConnectionHandle {
  if (!isRecord(value) || !isRecord(value.rpc)) return false;
  return typeof value.rpc.handle === "function";
}

function isLoopbackHostname(hostname: string): boolean {
  if (hostname === "localhost" || hostname === "[::1]") return true;
  const parts = hostname.split(".");
  return parts.length === 4 && parts[0] === "127" && parts.every(part => /^\d{1,3}$/.test(part) && Number(part) <= 255);
}

function trustedLoopbackRequest(req: IncomingMessage): boolean {
  const host = req.headers.host;
  if (host === undefined || req.headers["sec-fetch-site"] === "cross-site") return false;
  let authority: URL;
  try {
    authority = new URL(`http://${host}`);
  } catch {
    return false;
  }
  if (!isLoopbackHostname(authority.hostname)) return false;
  const origin = req.headers.origin;
  if (origin === undefined) return true;
  try {
    return new URL(origin).origin === authority.origin;
  } catch {
    return false;
  }
}

async function readJson(req: IncomingMessage): Promise<unknown> {
  const declared = req.headers["content-length"];
  if (declared !== undefined && (!/^\d+$/.test(declared) || Number(declared) > BODY_LIMIT)) {
    throw new Error("red-alert RPC body is too large");
  }
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of req) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk as Uint8Array);
    size += buffer.byteLength;
    if (size > BODY_LIMIT) throw new Error("red-alert RPC body is too large");
    chunks.push(buffer);
  }
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

function endpointFromRequest(channel: string, req: IncomingMessage): string | undefined {
  const pathname = new URL(req.url ?? "/", "http://dsh.internal").pathname;
  if (!pathname.startsWith(`${channel}/`)) return undefined;
  const endpoint = pathname.slice(channel.length + 1);
  if (endpoint.split("/").some(segment => segment.length === 0 || !ENDPOINT_SEGMENT_PATTERN.test(segment))) return undefined;
  return endpoint;
}

function writeJson(res: ServerResponse, status: number, value: unknown): void {
  const body = JSON.stringify(value);
  res.writeHead(status, { "content-type": "application/json", "content-length": Buffer.byteLength(body) });
  res.end(body);
}

/** Plugin-owned loopback RPC carrier used when the active Web connection does not expose RPC. */
export class RedAlertCompatConnectionService extends Service implements HostConnectionHandle {
  constructor(ctx: Context) {
    super(ctx, "redAlertCompatConnection");
  }

  /** Register one isolated loopback channel without replacing DSH's shared `/api`. */
  get rpc(): HostConnectionRpc {
    return {
      handle: (channel, handler, options) => this.register(channel, handler, options),
      intercept: (_channel: "/api", _matches: ConnectionRpcEndpointMatcher, _handler: ConnectionRpcHandler, _options: ConnectionRpcHandlerOptions) => {
        throw new Error("red-alert compatibility connection cannot intercept DSH /api");
      },
    };
  }

  private register(channel: string, handler: ConnectionRpcHandler, options: ConnectionRpcHandlerOptions): () => Promise<void> {
    if (!CHANNEL_PATTERN.test(channel) || channel === "/api" || options.authority !== "loopback") {
      throw new Error("red-alert compatibility connection requires a dedicated loopback channel");
    }
    const route: WebRoute = {
      kind: "prefix",
      path: channel,
      handler: async (req, res) => {
        if (!trustedLoopbackRequest(req)) {
          res.writeHead(403);
          res.end("forbidden");
          return;
        }
        const endpoint = endpointFromRequest(channel, req);
        if (req.method !== "POST" || endpoint === undefined || req.headers["content-type"]?.split(";", 1)[0]?.trim().toLowerCase() !== "application/json") {
          res.writeHead(404);
          res.end("not found");
          return;
        }
        let body: unknown;
        try {
          body = await readJson(req);
        } catch {
          res.writeHead(400);
          res.end("invalid JSON body");
          return;
        }
        if (!isRecord(body) || Object.keys(body).length !== 4 || body.type !== "client-request" || typeof body.rpcId !== "string" || body.rpcId.length === 0 || body.method !== endpoint || !Object.hasOwn(body, "payload")) {
          res.writeHead(400);
          res.end("invalid RPC envelope");
          return;
        }
        const controller = new AbortController();
        const onAborted = () => controller.abort();
        req.once("aborted", onAborted);
        try {
          const result = await handler(endpoint, body.payload, controller.signal);
          writeJson(res, 200, { type: "server-response", rpcId: body.rpcId, result });
        } finally {
          req.off("aborted", onAborted);
        }
      },
    };
    const dispose = this.ctx.webServer.register(route);
    return async () => dispose();
  }
}
