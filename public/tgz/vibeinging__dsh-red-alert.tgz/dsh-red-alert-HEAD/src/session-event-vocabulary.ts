import { existsSync, realpathSync } from "node:fs";
import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

import { RED_ALERT_SESSION_EVENT_TYPES } from "./session-event-types.ts";

export { RED_ALERT_SESSION_EVENT_TYPES } from "./session-event-types.ts";

interface HostSessionModule {
  readonly KNOWN_SESSION_EVENT_TYPES?: ReadonlySet<string>;
}

/**
 * Register the plugin's durable vocabulary with the exact DSH host runtime.
 *
 * DSH 0.1.1-rc.2 exports the persistence vocabulary as a read-only type but
 * does not yet expose an external-plugin registration service. Its concrete
 * runtime value is an extensible Set. The plugin resolves the host's own
 * dsh-session instance through @deepseek-ai/dsh instead of mutating the SDK
 * copy bundled into this package. Failure is load-time and loud so a session
 * is never written that the same installed host cannot restore.
 */
export async function registerHostSessionEventVocabulary(): Promise<void> {
  // Resolve from the package's physical Profile installation. The launcher
  // itself lives in a separate consumer installation, so import.meta.url can
  // otherwise reach the wrong copy of the host SDK under pnpm.
  const profileDir = process.env.RA_DSH_PROFILE_DIR;
  const profilePluginEntry = profileDir === undefined
    ? undefined
    : path.join(profileDir, "node_modules", "@vibeinging", "dsh-red-alert", "lib", "index.js");
  const resolveFrom = profilePluginEntry !== undefined && existsSync(profilePluginEntry)
    ? realpathSync(profilePluginEntry)
    : realpathSync(fileURLToPath(import.meta.url));
  const pluginRequire = createRequire(resolveFrom);
  let dshPackagePath: string;
  try {
    dshPackagePath = pluginRequire.resolve("@deepseek-ai/dsh/package.json");
  } catch (error) {
    throw new Error("red-alert requires the installed @deepseek-ai/dsh host package", { cause: error });
  }
  const hostRequire = createRequire(dshPackagePath);
  let sessionEntry: string;
  try {
    sessionEntry = hostRequire.resolve("@deepseek-ai/dsh-session");
  } catch (error) {
    throw new Error("red-alert cannot resolve the DSH host session runtime", { cause: error });
  }
  const hostSession = await import(pathToFileURL(sessionEntry).href) as HostSessionModule;
  const known = hostSession.KNOWN_SESSION_EVENT_TYPES;
  const add = (known as { readonly add?: (type: string) => unknown } | undefined)?.add;
  if (known === undefined || typeof add !== "function") {
    throw new Error("red-alert requires the DSH 0.1.1-rc.2 session vocabulary contract");
  }
  for (const type of RED_ALERT_SESSION_EVENT_TYPES) add.call(known, type);
  for (const type of RED_ALERT_SESSION_EVENT_TYPES) {
    if (!known.has(type)) throw new Error(`red-alert could not register session event type: ${type}`);
  }
}
