import type { Agent } from "@deepseek-ai/dsh-agent";
import type { Session } from "@deepseek-ai/dsh-session";
import {
  DEFERRED_TOOL_NAMES,
  RED_ALERT_GROUPS,
  TOOL_MANIFEST,
  type RedAlertGroupId,
  type RedAlertPhase,
} from "./tool-policy.ts";

/** The durable event that records one red-alert group selection transition. */
export const RED_ALERT_TOOL_GROUP_EVENT = "red-alert/tool-group-selection" as const;

/** Versions of the durable group-selection payload supported by the decoder. */
export type ToolGroupSelectionVersion = 0 | 1;
export type ToolGroupSelectionOutcome = "committed" | "rollback";
export type ToolGroupSchemaState = "loaded" | "pending-client-adapter";

export interface RedAlertToolGroupSelection {
  readonly version: ToolGroupSelectionVersion;
  readonly agentId: string;
  readonly sessionId: string;
  readonly groupId: RedAlertGroupId;
  readonly phase: RedAlertPhase;
  readonly methodKeys: readonly string[];
  readonly schemaState: ToolGroupSchemaState;
  readonly outcome: ToolGroupSelectionOutcome;
}

declare module "@deepseek-ai/dsh-session" {
  interface SessionEventMap {
    /** A red-alert group selection transition; event.seq remains envelope-only. */
    "red-alert/tool-group-selection": RedAlertToolGroupSelection;
  }
}

declare module "@deepseek-ai/dsh-session/types" {
  interface SessionEventMap {
    /** A red-alert group selection transition; event.seq remains envelope-only. */
    "red-alert/tool-group-selection": RedAlertToolGroupSelection;
  }
}

export interface RedAlertToolGroupState {
  readonly agent: Agent;
  readonly session: Session;
  readonly selected: Set<RedAlertGroupId>;
  readonly deniedNames: readonly string[];
  readonly phase: RedAlertPhase;
  readonly restriction?: () => void;
}

type LoadableRedAlertGroupId = Exclude<RedAlertGroupId, "bootstrap/capability">;
const RED_ALERT_LOADABLE_GROUPS: readonly LoadableRedAlertGroupId[] = RED_ALERT_GROUPS.filter(
  (group): group is LoadableRedAlertGroupId => group !== "bootstrap/capability",
);
const RED_ALERT_PHASES: readonly RedAlertPhase[] = [
  "catalog-only",
  "lobby-ready",
  "lobby-created",
  "running",
  "ended",
  "stopped",
  "error",
];
const RED_ALERT_SELECTION_FIELDS = new Set([
  "version",
  "agentId",
  "sessionId",
  "groupId",
  "phase",
  "methodKeys",
  "schemaState",
  "outcome",
]);

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function allowedMethodKeys(group: RedAlertGroupId): ReadonlySet<string> {
  return TOOL_MANIFEST
    .filter((entry) => entry.group === group)
    .flatMap((entry) => entry.methodKeys)
    .reduce((keys, key) => keys.add(key), new Set<string>());
}

/** Decode one versioned or legacy durable group-selection payload at the persistence boundary. */
export function decodeToolGroupSelection(value: unknown): RedAlertToolGroupSelection {
  if (!isRecord(value)) throw new Error("red-alert group selection must be an object");
  for (const key of Object.keys(value)) {
    if (!RED_ALERT_SELECTION_FIELDS.has(key)) throw new Error(`red-alert group selection has unknown field ${key}`);
  }
  const versionValue = Object.hasOwn(value, "version") ? value.version : 0;
  if (versionValue !== 0 && versionValue !== 1) {
    throw new Error(`red-alert group selection version is invalid: ${String(versionValue)}`);
  }
  const version = versionValue as ToolGroupSelectionVersion;
  const agentId = value.agentId;
  const sessionId = value.sessionId;
  const groupId = value.groupId;
  const phase = value.phase;
  const methodKeys = value.methodKeys;
  const schemaState = value.schemaState;
  const outcome = value.outcome;
  if (typeof agentId !== "string" || agentId.length === 0) throw new Error("red-alert group selection agentId is invalid");
  if (typeof sessionId !== "string" || sessionId.length === 0) throw new Error("red-alert group selection sessionId is invalid");
  if (typeof groupId !== "string" || !RED_ALERT_LOADABLE_GROUPS.includes(groupId as LoadableRedAlertGroupId)) {
    throw new Error(`red-alert group selection groupId is invalid: ${String(groupId)}`);
  }
  if (typeof phase !== "string" || !RED_ALERT_PHASES.includes(phase as RedAlertPhase)) {
    throw new Error(`red-alert group selection phase is invalid: ${String(phase)}`);
  }
  if (!Array.isArray(methodKeys) || methodKeys.some((key) => typeof key !== "string")) {
    throw new Error("red-alert group selection methodKeys must be strings");
  }
  const keys = methodKeys as string[];
  const sortedUnique = keys.every((key, index) => index === 0 || keys[index - 1] < key);
  if (!sortedUnique) throw new Error("red-alert group selection methodKeys must be sorted and unique");
  const loadableGroupId = groupId as LoadableRedAlertGroupId;
  const allowedKeys = allowedMethodKeys(loadableGroupId);
  if (keys.some((key) => !allowedKeys.has(key))) {
    throw new Error(`red-alert group selection methodKeys are not valid for manifest group ${groupId}`);
  }
  if (schemaState !== "loaded" && schemaState !== "pending-client-adapter") {
    throw new Error(`red-alert group selection schemaState is invalid: ${String(schemaState)}`);
  }
  if (outcome !== "committed" && outcome !== "rollback") {
    throw new Error(`red-alert group selection outcome is invalid: ${String(outcome)}`);
  }
  return {
    version,
    agentId,
    sessionId,
    groupId: loadableGroupId,
    phase: phase as RedAlertPhase,
    methodKeys: [...keys],
    schemaState,
    outcome,
  };
}

/** Validate every red-alert group event before runtime or invariant consumers use it. */
export function validateToolGroupSelectionLog(session: Session): void {
  for (const event of session.events) {
    if (event.type === RED_ALERT_TOOL_GROUP_EVENT) decodeToolGroupSelection(event.data);
  }
}

/** Return all tool names owned by a deferred red-alert group. */
export function deferredNamesForGroup(group: RedAlertGroupId): readonly string[] {
  return TOOL_MANIFEST
    .filter(entry => entry.group === group && DEFERRED_TOOL_NAMES.includes(entry.tool))
    .map(entry => entry.tool);
}

/** Return only registered tool names owned by a deferred group. */
export function registeredNamesForGroup(group: RedAlertGroupId, registeredNames: ReadonlySet<string>): readonly string[] {
  return deferredNamesForGroup(group).filter(toolName => registeredNames.has(toolName));
}

/** Return the event sequence's committed group selection for one exact owner pair. */
export function restoreSelectedGroups(session: Session, agent: Agent): Set<RedAlertGroupId> {
  const selected = new Set<RedAlertGroupId>();
  for (const event of session.events) {
    if (event.type !== RED_ALERT_TOOL_GROUP_EVENT) continue;
    const data = decodeToolGroupSelection(event.data);
    if (data.agentId !== String(agent.id) || data.sessionId !== String(session.id)) continue;
    if (data.outcome === "committed") selected.add(data.groupId);
    else selected.delete(data.groupId);
  }
  return selected;
}
