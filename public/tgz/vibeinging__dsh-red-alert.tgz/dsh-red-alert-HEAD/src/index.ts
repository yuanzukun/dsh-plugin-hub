import { existsSync, realpathSync, statSync } from "node:fs";
import { randomUUID } from "node:crypto";
import path from "node:path";
import { Context, Service } from "@deepseek-ai/cordis";
import z from "@deepseek-ai/schemastery";
import type { Agent } from "@deepseek-ai/dsh-agent";
import type { Session, SessionId } from "@deepseek-ai/dsh-session";
import type {} from "@deepseek-ai/dsh-session";
import type {} from "@deepseek-ai/dsh-session-projection";
import type { HostConnectionHandle } from "@deepseek-ai/dsh-client-connection";
import type { ToolRunContext } from "@deepseek-ai/dsh-tools";
import type {} from "@deepseek-ai/dsh-system-prompt";
import {
  MatchController,
  MatchControllerError,
  MatchOwner,
} from "../packages/game-host/src/match-controller.ts";
import type { MatchView, StartMatchRequest } from "../packages/game-host/src/match-controller.ts";
import {
  resolveResourceArchiveDescriptor,
  type ResourceArchiveDescriptor,
} from "./resource-config.ts";
import {
  RED_ALERT_EVENT,
  creatingState,
  failureState,
  redAlertProjection,
  redAlertCommandProjection,
  stateFromMatch,
} from "./projection.ts";
import type {
  RedAlertCreatingRequest,
  RedAlertMatch,
  RedAlertMatchIdentity,
  RedAlertState,
} from "./projection.ts";
import {
  IMPLEMENTED_TOOL_NAMES,
  RED_ALERT_GROUPS,
  TOOL_MANIFEST,
  type RedAlertGroupId,
  type RedAlertPhase,
  type ToolManifestEntry,
} from "./tool-policy.ts";
import {
  RED_ALERT_TOOL_GROUP_EVENT,
  restoreSelectedGroups,
  type RedAlertToolGroupSelection,
  type RedAlertToolGroupState,
} from "./tool-groups.ts";
import { createMatchTools } from "./tools.ts";
import {
  BrowserCommandTransport,
  type BrowserCommandTransportOptions,
} from "./browser-command-transport.ts";
import {
  BROWSER_TRANSPORT_PROTOCOL_VERSION,
  RED_ALERT_RENDERER_LOOPBACK_HOST,
  decodeBrowserObservation,
  type BrowserCommandReceipt,
  type BrowserGameToolRequest,
  type BrowserToolValue,
  type BrowserOrder,
  type BrowserRendererConfigValue,
} from "./browser-command-protocol.ts";
import { RendererHostService } from "./renderer-host.ts";
import {
  RedAlertCompatConnectionService,
  supportsHostConnectionRpc,
} from "./compat-connection.ts";
import { RED_ALERT_STRATEGY_PROMPT } from "./strategy-prompt.ts";
import { compactCommandView } from "./command-view.ts";
import {
  RED_ALERT_STRATEGY_BRIEF_EVENT,
  RED_ALERT_STRATEGY_EPISODE_EVENT,
  RED_ALERT_STRATEGY_REVIEW_EVENT,
  deriveStrategyBrief,
  deriveStrategyEpisode,
  isStrategyRuleId,
  strategyEpisodeForReview,
  strategyReviewForMatch,
  type StrategyReview,
  type StrategyRuleId,
} from "./strategy-learning.ts";
import { registerHostSessionEventVocabulary } from "./session-event-vocabulary.ts";
import {
  RED_ALERT_FIELD_MANUAL_EVENT,
  createFieldManualPage,
  type FieldManualFaction,
  type FieldManualTopic,
} from "./field-manual.ts";

export {
  RED_ALERT_SESSION_EVENT_TYPES,
  registerHostSessionEventVocabulary,
} from "./session-event-vocabulary.ts";

declare module "@deepseek-ai/cordis" {
  interface Context {
    redAlert: MatchService;
  }
}

/** Runtime configuration for the external DSH bundle. */
export interface Config {
  readonly assetsDir?: string;
  readonly defaultMap?: string;
  readonly defaultCountry?: string;
  readonly defaultOpponents?: number;
  readonly defaultOpponentType?: string;
  readonly defaultGameSpeed?: number;
  readonly enableOpeningDoctrine?: boolean;
  readonly enableAutoLearning?: boolean;
  readonly strategyHistoryLimit?: number;
  readonly strategyMaxRules?: number;
  readonly maxLearnedDefenders?: number;
  readonly decisionPeriod?: number;
  readonly maxTicks?: number;
  readonly resourceArchiveUrl?: string;
  readonly resourceArchiveSize?: number;
  readonly resourceArchiveSha256?: string;
  readonly browserAdapterAttachTimeoutMs?: number;
  readonly browserCommandTimeoutMs?: number;
  readonly browserCreateMatchTimeoutMs?: number;
  readonly rendererDistDir?: string;
  readonly rendererPort?: number;
}

/** Load-time schema; headless assets are optional when a real renderer is configured. */
export const Config: z<Config> = z.object({
  assetsDir: z.union([z.string(), z.const(undefined)]),
  defaultMap: z.string().default("current"),
  defaultCountry: z.string().default("Russians"),
  defaultOpponents: z.number().default(1),
  defaultOpponentType: z.string().default("noop"),
  defaultGameSpeed: z.number().default(2),
  enableOpeningDoctrine: z.boolean().default(true),
  enableAutoLearning: z.boolean().default(true),
  strategyHistoryLimit: z.number().default(20),
  strategyMaxRules: z.number().default(6),
  maxLearnedDefenders: z.number().default(24),
  decisionPeriod: z.number().default(15),
  maxTicks: z.number().default(600),
  resourceArchiveUrl: z.string().default("https://download.ra2web.com/full-pack.7z"),
  resourceArchiveSize: z.number().default(140_316_786),
  resourceArchiveSha256: z.string().default("3119b300794839ab597df556df8718c0a0a28fe89648ddced1c3790d801cb646"),
  browserAdapterAttachTimeoutMs: z.number().default(30_000),
  browserCommandTimeoutMs: z.number().default(120_000),
  browserCreateMatchTimeoutMs: z.number().default(600_000),
  rendererDistDir: z.union([z.string(), z.const(undefined)]),
  rendererPort: z.union([z.number(), z.const(undefined)]),
});

/** Cordis plugin name. */
export const name = "red-alert";
/** Services required before the session-owned tool layer is installed. */
export const inject = ["agents", "sessions", "sessionProjections", "systemPrompt", "tools"];

function resolveAssetsDir(value: string | undefined): string {
  if (typeof value !== "string" || value.length === 0 || !path.isAbsolute(value)) {
    throw new Error(
      "DSH Red Alert started without its renderer. Stop this DSH process. "
      + "On first use run `pnpm exec dsh-red-alert-setup --profile <profile>`; "
      + "then start it with `pnpm exec dsh-red-alert`. "
      + "Game files are selected later in the browser battlefield.",
    );
  }
  if (!existsSync(value) || !statSync(value).isDirectory()) {
    throw new Error(`red-alert config.assetsDir is not an existing directory: ${value}`);
  }
  return realpathSync(value);
}

function positiveDefault(name: string, value: number | undefined, fallback: number): number {
  const resolved = value ?? fallback;
  if (!Number.isSafeInteger(resolved) || resolved < 1) throw new Error(`red-alert ${name} must be a positive integer`);
  return resolved;
}

function gameSpeed(value: number | undefined, fallback: number): number {
  const resolved = value ?? fallback;
  if (!Number.isSafeInteger(resolved) || resolved < 0 || resolved > 6) {
    throw new MatchControllerError("red-alert game speed must be an integer from 0 through 6");
  }
  return resolved;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/** Session defaults shared by the bootstrap loader and deferred match tools. */
export interface MatchDefaults {
  readonly map: string;
  readonly myCountry: string;
  readonly opponents: number;
  readonly opponentType: "noop" | "supalosa" | "normal";
  readonly gameSpeed: number;
  readonly decisionPeriod: number;
  readonly maxTicks: number;
}

interface MatchServiceConfig extends Config {
  readonly rendererHost?: RendererHostService;
}

interface MutableToolGroupState extends Omit<RedAlertToolGroupState, "deniedNames" | "phase" | "restriction"> {
  deniedNames: readonly string[];
  phase: RedAlertPhase;
  restriction: (() => void) | undefined;
}

/** Service that binds each DSH Agent session to one headless or real browser match authority. */
export class MatchService extends Service {
  static inject = inject;
  readonly controller: MatchController | undefined;
  /** Browser authority transport; headless compatibility mode does not use it. */
  readonly browserTransport: BrowserCommandTransport | undefined;
  readonly defaults: MatchDefaults;
  readonly resourceArchive: ResourceArchiveDescriptor;
  readonly rendererDescriptor: import("./projection.ts").RedAlertRendererDescriptor | undefined;
  private readonly sessionTails = new Map<string, Promise<void>>();
  private readonly pendingAgentDisposals = new Set<Promise<void>>();
  private readonly agentDisposalErrors: unknown[] = [];
  private readonly toolGroupStates = new Map<Agent, MutableToolGroupState>();
  private readonly registeredDeferredToolNames: ReadonlySet<string>;
  private readonly strategyOptions: {
    readonly enabled: boolean;
    readonly historyLimit: number;
    readonly maxRules: number;
    readonly maxLearnedDefenders: number;
  };

  /** Check the owned headless records or the current browser-backed session projections. */
  assertInvariants(fail: (message: string) => never): void {
    if ((this.controller === undefined) === (this.rendererDescriptor === undefined)) {
      fail("red-alert must have exactly one match authority");
    }
    this.controller?.assertInvariants(fail);
    if (this.rendererDescriptor === undefined) return;
    for (const state of this.toolGroupStates.values()) {
      const current = this.currentState(state.session);
      if (current?.status === "creating") {
        if (current.identity === undefined || current.identity.sessionId !== String(state.session.id)) {
          fail("red-alert creating browser match is not owned by its Agent session");
        }
        continue;
      }
      const match = current?.match;
      if (match === undefined) continue;
      if (match.sessionId !== String(state.session.id) || match.seat !== match.myCountry) {
        fail(`red-alert browser match ${match.matchId} has inconsistent session or seat ownership`);
      }
      try {
        const observation = decodeBrowserObservation(match.observation);
        if (observation.tick !== match.tick) fail(`red-alert browser match ${match.matchId} has an inconsistent observation tick`);
      } catch (error) {
        fail(error instanceof Error ? error.message : String(error));
      }
    }
  }

  /** Check a successful model-visible result against the current authoritative session projection. */
  assertToolOutput(value: unknown, session: Session | undefined, fail: (message: string) => never): void {
    if (this.controller !== undefined) {
      this.controller.assertToolOutput(value, fail);
      return;
    }
    if (session === undefined || !isRecord(value) || typeof value.matchId !== "string") {
      fail("red-alert browser tool output has no owning session or match identity");
    }
    const match = this.currentMatch(session);
    if (match === undefined || match.matchId !== value.matchId) {
      fail(`red-alert browser tool output references a non-current match ${value.matchId}`);
    }
    if ("result" in value) {
      if (value.sessionId !== String(session.id) || value.seat !== match.seat || value.tick !== match.tick) {
        fail(`red-alert exact tool output identity does not match committed match state ${value.matchId}`);
      }
      return;
    }
    let observation;
    try {
      observation = decodeBrowserObservation(value.observation);
    } catch (error) {
      fail(error instanceof Error ? error.message : String(error));
    }
    if (JSON.stringify(observation) !== JSON.stringify(match.observation)) {
      fail(`red-alert browser tool output observation does not match committed match state ${value.matchId}`);
    }
  }

  constructor(ctx: Context, config: MatchServiceConfig) {
    super(ctx, "redAlert");
    if (config.enableOpeningDoctrine ?? true) {
      ctx.systemPrompt.section({
        name: "red-alert:opening-doctrine",
        order: 120,
        text: RED_ALERT_STRATEGY_PROMPT,
      });
    }
    const opponentType = config.defaultOpponentType ?? "noop";
    if (opponentType !== "noop" && opponentType !== "supalosa" && opponentType !== "normal") {
      throw new Error("red-alert defaultOpponentType must be noop, normal or supalosa");
    }
    this.defaults = {
      map: config.defaultMap ?? "current",
      myCountry: config.defaultCountry ?? "Russians",
      opponents: positiveDefault("defaultOpponents", config.defaultOpponents, 1),
      opponentType,
      gameSpeed: gameSpeed(config.defaultGameSpeed, 2),
      decisionPeriod: positiveDefault("decisionPeriod", config.decisionPeriod, 15),
      maxTicks: positiveDefault("maxTicks", config.maxTicks, 600),
    };
    this.strategyOptions = {
      enabled: config.enableAutoLearning ?? true,
      historyLimit: positiveDefault("strategyHistoryLimit", config.strategyHistoryLimit, 20),
      maxRules: positiveDefault("strategyMaxRules", config.strategyMaxRules, 6),
      maxLearnedDefenders: positiveDefault("maxLearnedDefenders", config.maxLearnedDefenders, 24),
    };
    this.resourceArchive = resolveResourceArchiveDescriptor(config);
    const browserCommandTimeoutMs = positiveDefault("browserCommandTimeoutMs", config.browserCommandTimeoutMs, 120_000);
    const browserCreateMatchTimeoutMs = positiveDefault("browserCreateMatchTimeoutMs", config.browserCreateMatchTimeoutMs, 600_000);
    const browserAdapterAttachTimeoutMs = positiveDefault("browserAdapterAttachTimeoutMs", config.browserAdapterAttachTimeoutMs, 30_000);
    if (browserAdapterAttachTimeoutMs >= Math.min(browserCommandTimeoutMs, browserCreateMatchTimeoutMs)) {
      throw new Error("red-alert browserAdapterAttachTimeoutMs must be shorter than both browserCommandTimeoutMs and browserCreateMatchTimeoutMs");
    }
    const rendererHost = config.rendererHost;
    this.rendererDescriptor = rendererHost === undefined ? undefined : {
      mode: "loopback",
      enabled: true,
      sourceLabel: "用户确认的本地兼容客户端",
      adapterAttachTimeoutMs: browserAdapterAttachTimeoutMs,
    };
    this.controller = this.rendererDescriptor === undefined
      ? new MatchController(resolveAssetsDir(config.assetsDir))
      : undefined;
    const platformConnection = ctx.get("connection", false);
    const compatConnection = ctx.get("redAlertCompatConnection", false);
    const connection: HostConnectionHandle | undefined = supportsHostConnectionRpc(platformConnection)
      ? platformConnection
      : supportsHostConnectionRpc(compatConnection) ? compatConnection : undefined;
    const transportOptions: Omit<BrowserCommandTransportOptions, "connection"> = {
      flush: async session => { await ctx.sessions.flush(session); },
      isSessionOwner: sessionId => this.agentForSession(sessionId) !== undefined,
      resolveAuthority: sessionId => {
        const agent = this.agentForSession(sessionId);
        if (agent === undefined) return undefined;
        const state = this.currentState(agent.session);
        const recoverableCreating = state?.status === "error"
          && state.failure?.recoverable === true
          && state.failure.phase === "creating";
        if ((state?.status === "creating" || recoverableCreating) && state.identity !== undefined) {
          return { matchId: state.identity.matchId, seat: state.identity.seat, tick: state.identity.tick, status: "creating" };
        }
        const match = this.currentMatch(agent.session);
        if (match === undefined) return undefined;
        return { matchId: match.matchId, seat: match.seat ?? match.myCountry, tick: match.tick, status: match.status };
      },
      resolveSession: sessionId => this.agentForSession(sessionId)?.session,
      resolveRendererConfig: sessionId => {
        const agent = this.agentForSession(sessionId);
        const state = agent === undefined ? undefined : this.currentState(agent.session);
        const recoverableCreating = state?.status === "error"
          && state.failure?.recoverable === true
          && state.failure.phase === "creating";
        const identity = state?.status === "creating" || recoverableCreating
          ? state.identity
          : state?.match === undefined ? undefined : {
              matchId: state.match.matchId,
              sessionId,
              seat: state.match.seat ?? state.match.myCountry,
              tick: state.match.tick,
            };
        if (identity === undefined || (state?.status !== "creating" && !recoverableCreating && state?.match?.status !== "active") || rendererHost?.url === undefined) return undefined;
        let url: URL;
        try {
          url = new URL(rendererHost.url);
        } catch {
          return undefined;
        }
        if (url.protocol !== "http:" || url.hostname !== RED_ALERT_RENDERER_LOOPBACK_HOST || url.pathname !== "/" || url.search !== "" || url.hash !== "" || url.username !== "" || url.password !== "") return undefined;
        const port = Number(url.port);
        if (!Number.isSafeInteger(port) || port < 1 || port > 65535) return undefined;
        return {
          protocolVersion: BROWSER_TRANSPORT_PROTOCOL_VERSION,
          sessionId,
          matchId: identity.matchId,
          seat: identity.seat,
          url: url.href,
          port,
        } satisfies BrowserRendererConfigValue;
      },
      timeoutMs: browserCommandTimeoutMs,
      createMatchTimeoutMs: browserCreateMatchTimeoutMs,
      logger: ctx.logger,
    };
    this.browserTransport = connection === undefined ? undefined : new BrowserCommandTransport({ ...transportOptions, connection });
    if (this.browserTransport !== undefined) {
      const transport = this.browserTransport;
      ctx.effect(() => {
        transport.start();
        return () => transport.dispose();
      }, "red-alert browser command transport");
    }

    const disposeStateProjection = ctx.sessionProjections.register(redAlertProjection);
    const disposeCommandProjection = ctx.sessionProjections.register(redAlertCommandProjection);
    ctx.effect(() => () => {
      disposeCommandProjection();
      disposeStateProjection();
    }, "red-alert: session projection");

    const tools = createMatchTools(this);
    const actualNames = new Set(tools.map((tool) => tool.name));
    const expectedNames = new Set(IMPLEMENTED_TOOL_NAMES);
    const missingNames = [...expectedNames].filter((toolName) => !actualNames.has(toolName));
    const unexpectedNames = [...actualNames].filter((toolName) => !expectedNames.has(toolName));
    if (actualNames.size !== tools.length || missingNames.length > 0 || unexpectedNames.length > 0) {
      throw new Error(
        `red-alert tool manifest/registration mismatch: missing=${missingNames.join(",") || "none"}; `
        + `unexpected=${unexpectedNames.join(",") || "none"}; duplicate=${actualNames.size !== tools.length}`,
      );
    }
    this.registeredDeferredToolNames = new Set(
      [...actualNames].filter((toolName) => toolName !== "red_alert_capabilities" && toolName !== "red_alert_load_group"),
    );
    for (const tool of tools) ctx.effect(() => ctx.tools.register(tool));
    ctx.on("agent/created", ({ agent }) => this.installToolGroupState(agent));
    for (const agent of ctx.agents.list()) this.installToolGroupState(agent);
    ctx.on("agent/disposed", ({ agent }) => this.trackAgentDisposal(this.ownerOfAgent(agent)));
    ctx.on("agent/disposed", ({ agent }) => this.uninstallToolGroupState(agent));
    ctx.effect(() => async () => {
      for (const agent of this.toolGroupStates.keys()) this.uninstallToolGroupState(agent);
      let controllerError: unknown;
      try {
        await this.waitForSessionOperations();
        await this.controller?.dispose();
      } catch (error) {
        controllerError = error;
      }
      await this.waitForAgentDisposals();
      if (controllerError !== undefined) throw controllerError;
      if (this.agentDisposalErrors.length > 0) {
        throw new AggregateError(this.agentDisposalErrors, "red-alert Agent disposal failed");
      }
    });
  }

  /** Convert a DSH execution to an exact Agent/session ownership pair. */
  ownerOf(exec: ToolRunContext): MatchOwner {
    const agent = exec.agent;
    if (agent === undefined || agent.id !== agent.session.id || this.ctx.agents.get(agent.id) !== agent) {
      throw new MatchControllerError("red-alert tools require the live owning Agent session");
    }
    return this.ownerOfAgent(agent);
  }

  /** Recheck ownership, group selection, and the current phase before a legacy tool runs. */
  runGroupTool<T>(toolName: string, exec: ToolRunContext, operation: () => Promise<T>): Promise<T> {
    this.assertGroupToolAccess(toolName, exec);
    return operation();
  }

  /** Return the model-visible capability catalog for one owning Agent session. */
  capabilities(exec: ToolRunContext): Promise<Record<string, unknown>> {
    return this.withSession(exec, async (_owner, session) => {
      const agent = exec.agent as Agent;
      const state = this.requireToolGroupState(agent);
      const phase = this.phaseFor(session);
      this.refreshToolGroupVisibility(state, phase);
      return {
        phase,
        selectedGroupIds: [...state.selected].sort(),
        groups: RED_ALERT_GROUPS.filter(group => group !== "bootstrap/capability").map(group => {
          const entries = TOOL_MANIFEST.filter(entry => entry.group === group);
          const registeredTools = entries
            .filter(entry => entry.implemented && this.registeredDeferredToolNames.has(entry.tool))
            .map(entry => entry.tool);
          const pendingTools = entries
            .filter(entry => !entry.implemented || !this.registeredDeferredToolNames.has(entry.tool))
            .map(entry => entry.tool);
      const selectionStatus = state.selected.has(group)
        ? registeredTools.length > 0 ? "loaded" : "selected_pending"
        : "not_selected";
      return {
        groupId: group,
        selected: state.selected.has(group),
        selectionStatus,
        visible: state.selected.has(group) && registeredTools.length > 0 && entries.some(entry => this.manifestAllowsPhase(entry, phase)),
        registeredTools,
        pendingTools,
      };
        }),
      };
    });
  }

  /** Load one exact group and durably commit its selection with rollback on failure. */
  loadGroup(
    args: { readonly group: RedAlertGroupId; readonly matchId?: string },
    exec: ToolRunContext,
  ): Promise<Record<string, unknown>> {
    return this.withSession(exec, async (_owner, session) => {
      const agent = exec.agent as Agent;
      const state = this.requireToolGroupState(agent);
      const group = args.group;
      if (!RED_ALERT_GROUPS.includes(group) || group === "bootstrap/capability") {
        throw new MatchControllerError(`unknown red-alert tool group: ${String(group)}`);
      }
      const phase = this.phaseFor(session);
      if (!this.groupCanLoad(group, phase)) {
        throw new MatchControllerError(`red-alert tool group ${group} is not loadable during phase ${phase}`);
      }
      const current = this.currentMatch(session);
      if (phase !== "catalog-only") {
        if (args.matchId === undefined || current?.matchId !== args.matchId) {
          throw new MatchControllerError("red-alert group loading requires the owning current matchId");
        }
      }
      if (state.selected.has(group)) {
        this.refreshToolGroupVisibility(state, phase);
        return this.groupLoadResult(state, group, phase, "already_loaded");
      }

      const previousSelected = new Set(state.selected);
      const previousDeniedNames = [...state.deniedNames];
      const nextSelected = new Set(state.selected);
      nextSelected.add(group);
      const nextDeniedNames = this.deniedNamesFor(nextSelected, phase);
      let visibilityChanged = false;
      let selectionAppended = false;
      try {
        const entries = TOOL_MANIFEST.filter(entry => entry.group === group);
        const payload: RedAlertToolGroupSelection = {
          version: 1,
          agentId: String(agent.id),
          sessionId: String(session.id),
          groupId: group,
          phase,
          methodKeys: entries.flatMap(entry => entry.methodKeys).sort(),
          schemaState: entries.some(entry => entry.implemented && this.registeredDeferredToolNames.has(entry.tool))
            ? "loaded"
            : "pending-client-adapter",
          outcome: "committed",
        };
        session.append(RED_ALERT_TOOL_GROUP_EVENT, payload);
        selectionAppended = true;
        await this.ctx.sessions.flush(session);
        this.replaceToolGroupRestriction(state, nextDeniedNames);
        visibilityChanged = true;
        state.selected.add(group);
        state.phase = phase;
        return this.groupLoadResult(state, group, phase, "loaded");
      } catch (error) {
        if (visibilityChanged) {
          try {
            this.restoreToolGroupRestriction(state, previousDeniedNames);
          } catch (restoreError) {
            this.ctx.logger.error(restoreError);
            throw this.combineFailure(error, restoreError);
          }
        }
        state.selected.clear();
        for (const selectedGroup of previousSelected) state.selected.add(selectedGroup);
        if (selectionAppended) await this.appendGroupRollback(session, agent, group, phase, error);
        throw error;
      }
    });
  }

  /** Record and return the bounded strategy learned for a future match selector. */
  strategyBrief(args: {
    readonly map?: string;
    readonly myCountry?: string;
    readonly opponentType?: "noop" | "supalosa" | "normal";
  }, exec: ToolRunContext): Promise<Record<string, unknown>> {
    return this.withSession(exec, async (_owner, session) => {
      const query = {
        map: args.map ?? this.defaults.map,
        myCountry: args.myCountry ?? this.defaults.myCountry,
        opponentType: args.opponentType ?? this.defaults.opponentType,
      };
      const brief = this.strategyOptions.enabled
        ? deriveStrategyBrief(String(session.id), this.ctx.sessions.list(), query, this.strategyOptions)
        : { version: 1 as const, sessionId: String(session.id), query, rules: [], sourceMatchIds: [] };
      session.append(RED_ALERT_STRATEGY_BRIEF_EVENT, brief);
      await this.ctx.sessions.flush(session);
      return brief as unknown as Record<string, unknown>;
    });
  }

  /** Record and return one compact built-in battlefield manual page. */
  fieldManual(args: {
    readonly topic: FieldManualTopic;
    readonly faction: FieldManualFaction;
  }, exec: ToolRunContext): Promise<Record<string, unknown>> {
    return this.withSession(exec, async (_owner, session) => {
      const page = createFieldManualPage(String(session.id), args.topic, args.faction);
      session.append(RED_ALERT_FIELD_MANUAL_EVENT, page);
      await this.ctx.sessions.flush(session);
      return page as unknown as Record<string, unknown>;
    });
  }

  /** Persist one model verdict over the current finished match's closed candidates. */
  reviewMatch(args: {
    readonly matchId: string;
    readonly adoptedRuleIds: readonly unknown[];
    readonly rejectedRuleIds: readonly unknown[];
  }, exec: ToolRunContext): Promise<Record<string, unknown>> {
    return this.withSession(exec, async (_owner, session) => {
      if (!this.strategyOptions.enabled) throw new MatchControllerError("red-alert automatic strategy learning is disabled");
      const episode = strategyEpisodeForReview(session, args.matchId);
      if (episode === undefined) throw new MatchControllerError("red-alert strategy review requires this session's natural finished-match episode");
      const adopted = this.decodeRuleIds("adoptedRuleIds", args.adoptedRuleIds);
      const rejected = this.decodeRuleIds("rejectedRuleIds", args.rejectedRuleIds);
      if (adopted.some(ruleId => rejected.includes(ruleId))) {
        throw new MatchControllerError("red-alert strategy review cannot both adopt and reject the same rule");
      }
      const available = new Set(episode.candidates.map(candidate => candidate.ruleId));
      const unknown = [...adopted, ...rejected].filter(ruleId => !available.has(ruleId));
      if (unknown.length > 0) {
        throw new MatchControllerError(`red-alert strategy review references a rule absent from the episode: ${unknown.join(",")}`);
      }
      const next: StrategyReview = {
        version: 1,
        sessionId: String(session.id),
        matchId: args.matchId,
        adoptedRuleIds: adopted,
        rejectedRuleIds: rejected,
      };
      const existing = strategyReviewForMatch(session, args.matchId);
      if (existing !== undefined) {
        if (JSON.stringify(existing) !== JSON.stringify(next)) {
          throw new MatchControllerError("red-alert strategy review is already committed with a different verdict");
        }
      } else {
        session.append(RED_ALERT_STRATEGY_REVIEW_EVENT, next);
        await this.ctx.sessions.flush(session);
      }
      const brief = deriveStrategyBrief(String(session.id), this.ctx.sessions.list(), {
        map: episode.map,
        myCountry: episode.myCountry,
        opponentType: episode.opponentType,
      }, this.strategyOptions);
      return {
        status: existing === undefined ? "committed" : "already_committed",
        review: next,
        nextMatchBrief: brief,
      };
    });
  }

  /** Start using only the defaults and validated model arguments. */
  start(args: {
    readonly map?: string;
    readonly myCountry?: string;
    readonly opponents?: number;
    readonly opponentType?: "noop" | "supalosa" | "normal";
    readonly gameSpeed?: number;
    readonly decisionPeriod?: number;
    readonly maxTicks?: number;
  }, exec: ToolRunContext) {
    return this.withSession(exec, async (owner, session) => {
      const request = { ...this.defaults, ...args, gameSpeed: gameSpeed(args.gameSpeed, this.defaults.gameSpeed) } as RedAlertCreatingRequest;
      if (this.rendererDescriptor !== undefined) return this.startBrowserMatch(request, session, exec.signal);
      if (request.opponentType === "normal") {
        throw new MatchControllerError("normal opponents require the real browser renderer");
      }
      const legacyRequest: StartMatchRequest = { ...request, opponentType: request.opponentType };
      const existing = this.currentMatch(session);
      if (existing?.status === "active") {
        const error = new MatchControllerError("this Agent session already owns an active match");
        const failureError = await this.appendFailure(session, failureState("creating", error, existing, request, undefined, this.resourceArchive, this.rendererDescriptor));
        throw this.combineFailure(error, failureError);
      }
      await this.appendState(session, creatingState(request, {
        matchId: randomUUID(),
        sessionId: String(session.id),
        seat: request.myCountry,
        tick: 0,
      }, this.resourceArchive, this.rendererDescriptor));
      let view: MatchView;
      try {
        view = await this.requireLegacyController().start(owner, legacyRequest, exec.signal);
      } catch (error) {
        const failureError = await this.appendFailure(session, failureState("creating", error, undefined, request, undefined, this.resourceArchive, this.rendererDescriptor));
        throw this.combineFailure(error, failureError);
      }
        return this.commitOperation(session, owner, view, "running", request);
    });
  }

  /** Apply commands for the exact owner. */
  act(args: { readonly matchId: string; readonly orders: readonly unknown[] }, exec: ToolRunContext) {
    return this.withSession(exec, async (owner, session) => {
      if (this.rendererDescriptor !== undefined) return this.actBrowserMatch(args, session, exec.signal);
      let previous: MatchView | RedAlertMatch | undefined;
      let statusRead = false;
      let view: MatchView;
      try {
        previous = await this.requireLegacyController().status(owner, args.matchId, exec.signal);
        statusRead = true;
        view = await this.requireLegacyController().act(owner, args.matchId, args.orders, exec.signal);
      } catch (error) {
        const closed = statusRead ? await this.closeAfterFailure(owner, args.matchId) : {};
        const fallback = closed.view ?? previous ?? this.currentMatch(session);
        const failureError = await this.appendFailure(session, failureState(
          "running",
          error,
          fallback,
          undefined,
          { sessionId: String(session.id), seat: fallback?.myCountry ?? this.defaults.myCountry },
          this.resourceArchive,
          this.rendererDescriptor,
        ));
        throw this.combineFailure(error, closed.error, failureError);
      }
      return this.commitOperation(session, owner, view, "running");
    });
  }

  /** Read state without advancing. */
  status(args: { readonly matchId: string }, exec: ToolRunContext) {
    return this.withSession(exec, async (owner, session) => {
      if (this.rendererDescriptor !== undefined) return this.readBrowserMatch(args.matchId, session, exec.signal);
      try {
        const view = await this.requireLegacyController().status(owner, args.matchId, exec.signal);
        await this.appendState(session, stateFromMatch(view, { sessionId: String(session.id), seat: view.myCountry }, this.resourceArchive, this.rendererDescriptor));
        return view;
      } catch (error) {
        const current = this.currentMatch(session);
        const failureError = await this.appendFailure(session, failureState(
          "reading",
          error,
          current,
          undefined,
          { sessionId: String(session.id), seat: current?.myCountry ?? this.defaults.myCountry },
          this.resourceArchive,
          this.rendererDescriptor,
        ));
        throw this.combineFailure(error, failureError);
      }
    });
  }

  /** Execute one exact fair browser-backed game tool and durably commit its post-call observation. */
  browserTool(args: { readonly matchId: string } & BrowserGameToolRequest, exec: ToolRunContext): Promise<Record<string, unknown>> {
    return this.withSession(exec, async (_owner, session) => {
      if (this.rendererDescriptor === undefined) throw new MatchControllerError(`${args.tool} requires the real browser renderer`);
      const previous = this.requireActiveBrowserMatch(session, args.matchId);
      const { matchId: _matchId, ...request } = args;
      try {
        const receipt = await this.requireBrowserTransport().dispatch(session, {
          matchId: previous.matchId,
          seat: previous.seat ?? previous.myCountry,
          expectedTick: previous.tick,
          kind: "tool",
          request: request as BrowserGameToolRequest,
        }, exec.signal);
        const view = this.browserView(receipt, previous.matchId, previous, this.defaults.decisionPeriod);
        if (receipt.toolResult === undefined) throw new MatchControllerError(`${args.tool} renderer receipt omitted its tool result`);
        await this.appendState(session, stateFromMatch(view, { sessionId: String(session.id), seat: previous.seat ?? previous.myCountry }, this.resourceArchive, this.rendererDescriptor));
        const commandView = compactCommandView(receipt);
        const strategyReview = this.strategyReviewHint(session, previous.matchId);
        return {
          matchId: previous.matchId,
          sessionId: String(session.id),
          seat: previous.seat ?? previous.myCountry,
          tick: receipt.tick,
          result: receipt.toolResult as BrowserToolValue,
          ...(commandView === undefined ? {} : { commandView }),
          ...(strategyReview === undefined ? {} : { strategyReview }),
        };
      } catch (error) {
        const failureError = await this.appendFailure(session, failureState("running", error, previous, undefined, { sessionId: String(session.id), seat: previous.seat ?? previous.myCountry }, this.resourceArchive, this.rendererDescriptor));
        throw this.combineFailure(error, failureError);
      }
    });
  }

  /** Save and stop the exact owner's match. */
  stop(args: { readonly matchId: string }, exec: ToolRunContext) {
    return this.withSession(exec, async (owner, session) => {
      if (this.rendererDescriptor !== undefined) return this.stopBrowserMatch(args.matchId, session, exec.signal);
      try {
        const view = await this.requireLegacyController().stop(owner, args.matchId, exec.signal);
        await this.appendState(session, stateFromMatch(view, { sessionId: String(session.id), seat: view.myCountry }, this.resourceArchive, this.rendererDescriptor));
        return view;
      } catch (error) {
        const closed = await this.closeAfterFailure(owner, args.matchId);
        const fallback = closed.view ?? this.currentMatch(session);
        const failureError = await this.appendFailure(session, failureState(
          "stopping",
          error,
          fallback,
          undefined,
          { sessionId: String(session.id), seat: fallback?.myCountry ?? this.defaults.myCountry },
          this.resourceArchive,
          this.rendererDescriptor,
        ));
        throw this.combineFailure(error, closed.error, failureError);
      }
    });
  }

  private async startBrowserMatch(request: RedAlertCreatingRequest, session: Session, signal: AbortSignal): Promise<RedAlertMatch> {
    const state = this.currentState(session);
    if (state?.match?.status === "active") {
      throw new MatchControllerError("this Agent session already owns a current real browser match");
    }
    const transport = this.requireBrowserTransport();
    if (state?.status === "creating") {
      if (transport.hasPending(String(session.id))) {
        throw new MatchControllerError("this Agent session already has a browser match creation in flight");
      }
      const interrupted = Object.assign(
        new Error("the previous browser match creation was interrupted before the Host received a result"),
        { code: "BROWSER_COMMAND_INTERRUPTED" },
      );
      await this.appendState(session, failureState(
        "creating",
        interrupted,
        undefined,
        state.request,
        state.identity,
        this.resourceArchive,
        this.rendererDescriptor,
      ));
    }
    if (request.opponentType === "supalosa") throw new MatchControllerError("the real browser adapter supports noop or normal opponents");
    const identity = {
      matchId: randomUUID(),
      sessionId: String(session.id),
      seat: request.myCountry,
      tick: 0 as const,
    };
    await this.appendState(session, creatingState(request, identity, this.resourceArchive, this.rendererDescriptor));
    try {
      const receipt = await transport.dispatch(session, {
        matchId: identity.matchId,
        seat: identity.seat,
        expectedTick: 0,
        kind: "create-match",
        request: {
          map: request.map,
          myCountry: request.myCountry,
          opponents: request.opponents,
          opponentType: request.opponentType,
          gameSpeed: request.gameSpeed,
        },
      }, signal);
      const view = this.browserView(receipt, identity.matchId, undefined, request.decisionPeriod);
      return this.commitBrowserMatch(session, view, { sessionId: identity.sessionId, seat: identity.seat });
    } catch (error) {
      const failureError = await this.appendFailure(session, failureState("creating", error, undefined, request, identity, this.resourceArchive, this.rendererDescriptor));
      throw this.combineFailure(error, failureError);
    }
  }

  private async actBrowserMatch(
    args: { readonly matchId: string; readonly orders: readonly unknown[] },
    session: Session,
    signal: AbortSignal,
  ): Promise<RedAlertMatch> {
    const previous = this.requireActiveBrowserMatch(session, args.matchId);
    try {
      const receipt = await this.requireBrowserTransport().dispatch(session, {
        matchId: previous.matchId,
        seat: previous.seat ?? previous.myCountry,
        expectedTick: previous.tick,
        kind: "orders",
        orders: args.orders as readonly BrowserOrder[],
      }, signal);
      const view = this.browserView(receipt, previous.matchId, previous, this.defaults.decisionPeriod, args.orders as readonly BrowserOrder[]);
      return this.commitBrowserMatch(session, view, { sessionId: String(session.id), seat: previous.seat ?? previous.myCountry });
    } catch (error) {
      const failureError = await this.appendFailure(session, failureState("running", error, previous, undefined, { sessionId: String(session.id), seat: previous.seat ?? previous.myCountry }, this.resourceArchive, this.rendererDescriptor));
      throw this.combineFailure(error, failureError);
    }
  }

  private async readBrowserMatch(matchId: string, session: Session, signal: AbortSignal): Promise<RedAlertMatch> {
    const previous = this.requireActiveBrowserMatch(session, matchId);
    try {
      const receipt = await this.requireBrowserTransport().dispatch(session, {
        matchId,
        seat: previous.seat ?? previous.myCountry,
        expectedTick: previous.tick,
        kind: "observe",
      }, signal);
      const view = this.browserView(receipt, matchId, previous, this.defaults.decisionPeriod);
      return this.commitBrowserMatch(session, view, { sessionId: String(session.id), seat: previous.seat ?? previous.myCountry });
    } catch (error) {
      const failureError = await this.appendFailure(session, failureState("reading", error, previous, undefined, { sessionId: String(session.id), seat: previous.seat ?? previous.myCountry }, this.resourceArchive, this.rendererDescriptor));
      throw this.combineFailure(error, failureError);
    }
  }

  private async stopBrowserMatch(matchId: string, session: Session, signal: AbortSignal): Promise<RedAlertMatch> {
    const previous = this.requireActiveBrowserMatch(session, matchId);
    try {
      const receipt = await this.requireBrowserTransport().dispatch(session, {
        matchId,
        seat: previous.seat ?? previous.myCountry,
        expectedTick: previous.tick,
        kind: "stop-match",
      }, signal);
      const view = this.browserView(receipt, matchId, previous, this.defaults.decisionPeriod);
      return this.commitBrowserMatch(session, view, { sessionId: String(session.id), seat: previous.seat ?? previous.myCountry });
    } catch (error) {
      const failureError = await this.appendFailure(session, failureState("stopping", error, previous, undefined, { sessionId: String(session.id), seat: previous.seat ?? previous.myCountry }, this.resourceArchive, this.rendererDescriptor));
      throw this.combineFailure(error, failureError);
    }
  }

  private requireActiveBrowserMatch(session: Session, matchId: string): RedAlertMatch {
    const match = this.currentMatch(session);
    if (match === undefined || match.matchId !== matchId || match.status !== "active") {
      throw new MatchControllerError("red-alert browser command requires the current active matchId");
    }
    return match;
  }

  private async commitBrowserMatch(
    session: Session,
    view: MatchView,
    identity: RedAlertMatchIdentity,
  ): Promise<RedAlertMatch> {
    const state = stateFromMatch(view, identity, this.resourceArchive, this.rendererDescriptor);
    if (state.match === undefined) throw new MatchControllerError("real browser state omitted its projected match");
    await this.appendState(session, state);
    const strategyReview = this.strategyReviewHint(session, state.match.matchId);
    return strategyReview === undefined ? state.match : { ...state.match, strategyReview } as RedAlertMatch;
  }

  private browserView(
    receipt: BrowserCommandReceipt,
    matchId: string,
    previous: RedAlertMatch | undefined,
    decisionPeriod: number,
    orders: readonly BrowserOrder[] = [],
  ): MatchView {
    if (!receipt.ok) throw new MatchControllerError(receipt.detail);
    if (receipt.observation === undefined || receipt.match === undefined) throw new MatchControllerError("real browser receipt omitted its atomic fair match snapshot");
    if (receipt.observation.tick !== receipt.tick || receipt.match.myCountry !== receipt.seat) throw new MatchControllerError("real browser receipt identity is inconsistent");
    const tick = receipt.tick;
    const phase = tick < 3_000 ? "early" : tick < 9_000 ? "mid" : "late";
    const commandReceipts = orders.map(order => ({ ok: true, order, detail: receipt.detail }) as MatchView["receipts"][number]);
    return {
      matchId,
      map: receipt.match.map,
      mapSize: receipt.match.mapSize,
      myCountry: receipt.match.myCountry,
      status: receipt.match.status,
      tick,
      cycle: previous === undefined ? 0 : previous.cycle + 1,
      view: { mode: "offline", realUiAvailable: false },
      observation: receipt.observation,
      facts: {
        gameTimeSec: tick / Math.max(1, decisionPeriod),
        phase,
        self: receipt.match.self,
        visibleEnemyGroups: receipt.observation.visibleEnemies.length,
        lastSeenEnemyGroups: receipt.observation.lastSeenEnemies.length,
        visibleNeutralGroups: receipt.observation.visibleNeutralObjects.length,
      },
      receipts: [...(previous?.receipts ?? []), ...commandReceipts],
      placements: previous?.placements ?? [],
      replaySaved: false,
    };
  }

  private requireToolGroupState(agent: Agent): MutableToolGroupState {
    const state = this.toolGroupStates.get(agent);
    if (state === undefined) throw new MatchControllerError("red-alert tool group state is not installed for this Agent");
    return state;
  }

  private decodeRuleIds(name: string, values: readonly unknown[]): StrategyRuleId[] {
    if (!Array.isArray(values) || values.length > this.strategyOptions.maxRules) {
      throw new MatchControllerError(`red-alert ${name} must contain at most ${this.strategyOptions.maxRules} rule ids`);
    }
    if (!values.every(isStrategyRuleId)) throw new MatchControllerError(`red-alert ${name} contains an unknown rule id`);
    const unique = [...new Set(values)] as StrategyRuleId[];
    if (unique.length !== values.length) throw new MatchControllerError(`red-alert ${name} contains duplicate rule ids`);
    return unique;
  }

  private installToolGroupState(agent: Agent): void {
    if (this.toolGroupStates.has(agent)) return;
    const state: MutableToolGroupState = {
      agent,
      session: agent.session,
      selected: restoreSelectedGroups(agent.session, agent),
      deniedNames: [],
      phase: this.phaseFor(agent.session),
      restriction: undefined,
    };
    try {
      state.restriction = agent.ctx.tools.restrict({ deny: this.deniedNamesFor(state.selected, state.phase) });
      state.deniedNames = this.deniedNamesFor(state.selected, state.phase);
      this.toolGroupStates.set(agent, state);
    } catch (error) {
      state.restriction?.();
      throw error;
    }
  }

  private uninstallToolGroupState(agent: Agent): void {
    const state = this.toolGroupStates.get(agent);
    if (state === undefined) return;
    this.toolGroupStates.delete(agent);
    state.restriction?.();
    state.restriction = undefined;
  }

  private assertGroupToolAccess(toolName: string, exec: ToolRunContext): void {
    const agent = exec.agent;
    if (agent === undefined) throw new MatchControllerError("red-alert tools require an owning Agent");
    const state = this.requireToolGroupState(agent);
    const entry = TOOL_MANIFEST.find(candidate => candidate.tool === toolName);
    if (entry === undefined || !entry.implemented || !this.registeredDeferredToolNames.has(toolName)) {
      throw new MatchControllerError(`red-alert tool is not implemented: ${toolName}`);
    }
    const phase = this.phaseFor(agent.session);
    this.refreshToolGroupVisibility(state, phase);
    if (!state.selected.has(entry.group) || !this.manifestAllowsPhase(entry, phase)) {
      throw new MatchControllerError(`red-alert tool ${toolName} is not loaded for phase ${phase}`);
    }
  }

  private phaseFor(session: Session): RedAlertPhase {
    const state = this.ctx.sessionProjections.snapshot(session).values.redAlert as RedAlertState | undefined;
    if (state === undefined || state.status === "empty") return "catalog-only";
    if (state.status === "creating") return "lobby-ready";
    if (state.status === "error") {
      if (state.failure?.recoverable === true && state.match?.status === "active") return "running";
      if (state.failure?.recoverable === true && state.failure.phase === "creating" && state.match === undefined) return "catalog-only";
      return "error";
    }
    if (state.match?.status === "finished") return "ended";
    if (state.status === "stopped") return "stopped";
    return "running";
  }

  private groupCanLoad(group: RedAlertGroupId, phase: RedAlertPhase): boolean {
    if (group === "strategy/learning") return phase === "catalog-only" || phase === "ended";
    if (group === "lobby/setup") return phase === "catalog-only" || phase === "lobby-ready" || phase === "ended";
    if (group === "observation" || group === "lifecycle/replay") return phase !== "catalog-only" && phase !== "lobby-ready";
    return phase === "running";
  }

  private manifestAllowsPhase(entry: Pick<ToolManifestEntry, "tool" | "phase">, phase: RedAlertPhase): boolean {
    if (entry.tool === "red_alert_start" && (phase === "lobby-ready" || phase === "ended")) return true;
    if (entry.phase === "all") return phase !== "catalog-only" && phase !== "lobby-ready";
    return entry.phase === phase;
  }

  private deniedNamesFor(selected: ReadonlySet<RedAlertGroupId>, phase: RedAlertPhase): string[] {
    return [...this.registeredDeferredToolNames]
      .filter(toolName => {
        const entry = TOOL_MANIFEST.find(candidate => candidate.tool === toolName);
        return entry === undefined || !selected.has(entry.group) || !this.manifestAllowsPhase(entry, phase);
      })
      .sort();
  }

  private refreshToolGroupVisibility(state: MutableToolGroupState, phase: RedAlertPhase): void {
    const nextDeniedNames = this.deniedNamesFor(state.selected, phase);
    if (state.deniedNames.length === nextDeniedNames.length
      && state.deniedNames.every((name, index) => name === nextDeniedNames[index])) {
      state.phase = phase;
      return;
    }
    this.replaceToolGroupRestriction(state, nextDeniedNames);
    state.phase = phase;
  }

  private replaceToolGroupRestriction(state: MutableToolGroupState, nextDeniedNames: readonly string[]): void {
    const previous = state.restriction;
    const next = state.agent.ctx.tools.restrict({ deny: [...nextDeniedNames] });
    try {
      previous?.();
    } catch (error) {
      next();
      throw error;
    }
    state.restriction = next;
    state.deniedNames = [...nextDeniedNames];
  }

  private restoreToolGroupRestriction(state: MutableToolGroupState, previousDeniedNames: readonly string[]): void {
    this.replaceToolGroupRestriction(state, previousDeniedNames);
  }

  private groupLoadResult(
    state: MutableToolGroupState,
    group: RedAlertGroupId,
    phase: RedAlertPhase,
    status: "loaded" | "already_loaded",
  ): Record<string, unknown> {
    const entries = TOOL_MANIFEST.filter(entry => entry.group === group);
    const registeredTools = entries
      .filter(entry => entry.implemented && this.registeredDeferredToolNames.has(entry.tool))
      .map(entry => entry.tool);
    const pendingTools = entries
      .filter(entry => !entry.implemented || !this.registeredDeferredToolNames.has(entry.tool))
      .map(entry => entry.tool);
    const pendingOnly = registeredTools.length === 0;
    const availableTools = registeredTools.filter((toolName) => {
      const entry = TOOL_MANIFEST.find(candidate => candidate.tool === toolName);
      return entry !== undefined && this.manifestAllowsPhase(entry, phase);
    });
    return {
      status: pendingOnly ? status === "already_loaded" ? "already_selected_pending" : "selected_pending" : status,
      groupId: group,
      phase,
      selectedGroupIds: [...state.selected].sort(),
      schemaState: pendingOnly ? "pending-client-adapter" : "loaded",
      registeredTools,
      availableTools,
      phaseDeferredTools: registeredTools.filter(toolName => !availableTools.includes(toolName)),
      pendingTools,
    };
  }

  private async appendGroupRollback(
    session: Session,
    agent: Agent,
    group: RedAlertGroupId,
    phase: RedAlertPhase,
    originalError: unknown,
  ): Promise<void> {
    const entries = TOOL_MANIFEST.filter(entry => entry.group === group);
    try {
      session.append(RED_ALERT_TOOL_GROUP_EVENT, {
        version: 1,
        agentId: String(agent.id),
        sessionId: String(session.id),
        groupId: group,
        phase,
        methodKeys: entries.flatMap(entry => entry.methodKeys).sort(),
        schemaState: entries.some(entry => entry.implemented && this.registeredDeferredToolNames.has(entry.tool))
          ? "loaded"
          : "pending-client-adapter",
        outcome: "rollback",
      });
      await this.ctx.sessions.flush(session);
    } catch (rollbackError) {
      this.ctx.logger.error(rollbackError);
      throw this.combineFailure(originalError, rollbackError);
    }
  }

  private ownerOfAgent(agent: Agent): MatchOwner {
    return { agentId: String(agent.id), sessionId: String(agent.session.id) };
  }

  private agentForSession(sessionId: string): Agent | undefined {
    return this.ctx.agents.get(sessionId as SessionId);
  }

  private trackAgentDisposal(owner: MatchOwner): Promise<void> {
    const cleanup = this.serialize(owner.sessionId, new AbortController().signal, async () => {
      const results = await Promise.allSettled([
        this.controller?.stopOwner(owner) ?? Promise.resolve(),
        this.browserTransport?.cleanupSession(owner.sessionId) ?? Promise.resolve(),
      ]);
      const errors = results.flatMap((result) => result.status === "rejected" ? [result.reason] : []);
      if (errors.length === 1) throw errors[0];
      if (errors.length > 1) throw new AggregateError(errors, "red-alert Agent cleanup failed");
    });
    let tracked: Promise<void>;
    tracked = cleanup.then(
      () => {
        this.pendingAgentDisposals.delete(tracked);
      },
      (error: unknown) => {
        this.agentDisposalErrors.push(error);
        this.ctx.logger.error(error);
        this.pendingAgentDisposals.delete(tracked);
        throw error;
      },
    );
    this.pendingAgentDisposals.add(tracked);
    return tracked;
  }

  private async waitForAgentDisposals(): Promise<void> {
    while (this.pendingAgentDisposals.size > 0) {
      await Promise.allSettled(this.pendingAgentDisposals);
    }
  }

  private withSession<T>(exec: ToolRunContext, operation: (owner: MatchOwner, session: Session) => Promise<T>): Promise<T> {
    const owner = this.ownerOf(exec);
    const session = exec.agent?.session;
    if (session === undefined) throw new MatchControllerError("red-alert tools require an owning session");
    return this.serialize(owner.sessionId, exec.signal, () => operation(owner, session));
  }

  private async appendState(session: Session, state: RedAlertState): Promise<void> {
    session.append(RED_ALERT_EVENT, state);
    if (this.strategyOptions.enabled) {
      const episode = deriveStrategyEpisode(session, state, this.strategyOptions);
      if (episode !== undefined) session.append(RED_ALERT_STRATEGY_EPISODE_EVENT, episode);
    }
    await this.ctx.sessions.flush(session);
    this.refreshToolGroupVisibilityForSession(session);
  }

  private strategyReviewHint(session: Session, matchId: string): Record<string, unknown> | undefined {
    const episode = strategyEpisodeForReview(session, matchId);
    if (episode === undefined || strategyReviewForMatch(session, matchId) !== undefined) return undefined;
    return {
      matchId,
      candidateRuleIds: episode.candidates.map(candidate => candidate.ruleId),
      candidates: episode.candidates,
      requiredTool: "red_alert_review_match",
    };
  }

  private refreshToolGroupVisibilityForSession(session: Session): void {
    const phase = this.phaseFor(session);
    for (const state of this.toolGroupStates.values()) {
      if (state.session === session) this.refreshToolGroupVisibility(state, phase);
    }
  }

  private async appendFailure(session: Session, state: RedAlertState): Promise<unknown> {
    try {
      await this.appendState(session, state);
      return undefined;
    } catch (error) {
      this.ctx.logger.error(error);
      return error;
    }
  }

  private async commitOperation(
    session: Session,
    owner: MatchOwner,
    view: MatchView,
    phase: "running" | "stopping",
    request?: RedAlertCreatingRequest,
  ): Promise<MatchView> {
    try {
      await this.appendState(session, stateFromMatch(view, { sessionId: String(session.id), seat: view.myCountry }, this.resourceArchive, this.rendererDescriptor));
      return view;
    } catch (error) {
      const closed = await this.closeAfterFailure(owner, view.matchId);
      const fallback = closed.view ?? view;
      const failureError = await this.appendFailure(session, failureState(
        phase,
        error,
        fallback,
        request,
        { sessionId: String(session.id), seat: fallback.myCountry },
        this.resourceArchive,
        this.rendererDescriptor,
      ));
      throw this.combineFailure(error, closed.error, failureError);
    }
  }

  private async closeAfterFailure(owner: MatchOwner, matchId: string): Promise<{ view?: MatchView; error?: unknown }> {
    try {
      return { view: await this.requireLegacyController().stop(owner, matchId, new AbortController().signal) };
    } catch (error) {
      this.ctx.logger.error(error);
      return { error };
    }
  }

  private currentMatch(session: Session): RedAlertMatch | undefined {
    return this.currentState(session)?.match;
  }

  private requireLegacyController(): MatchController {
    if (this.controller === undefined) throw new MatchControllerError("headless controller is disabled for the real browser authority");
    return this.controller;
  }

  private requireBrowserTransport(): BrowserCommandTransport {
    if (this.browserTransport === undefined) throw new MatchControllerError("real browser command transport is unavailable");
    return this.browserTransport;
  }

  private currentState(session: Session): RedAlertState | undefined {
    return this.ctx.sessionProjections.snapshot(session).values["redAlert"] as RedAlertState | undefined;
  }

  private combineFailure(...errors: unknown[]): unknown {
    const present = errors.filter((error): error is {} => error !== undefined);
    if (present.length === 1) return present[0];
    return new AggregateError(present, "red-alert operation, state commit, or cleanup failed");
  }

  private async waitForSessionOperations(): Promise<void> {
    while (this.sessionTails.size > 0) await Promise.allSettled(this.sessionTails.values());
  }

  private async serialize<T>(sessionId: string, signal: AbortSignal, operation: () => Promise<T>): Promise<T> {
    const previous = this.sessionTails.get(sessionId) ?? Promise.resolve();
    let current: Promise<T>;
    current = previous.catch(() => undefined).then(() => {
      if (signal.aborted) {
        const error = signal.reason instanceof Error ? signal.reason : new Error("red-alert operation aborted");
        error.name = "AbortError";
        throw error;
      }
      return operation();
    });
    const tail = current.then(() => undefined, () => undefined);
    this.sessionTails.set(sessionId, tail);
    try {
      return await current;
    } finally {
      if (this.sessionTails.get(sessionId) === tail) this.sessionTails.delete(sessionId);
    }
  }
}

/** Apply the service and optional user-confirmed loopback renderer host. */
export async function apply(ctx: Context, config: Config): Promise<void> {
  await registerHostSessionEventVocabulary();
  if (config.rendererDistDir !== undefined) {
    ctx.inject(["webServer"], async (webCtx) => {
      if (!supportsHostConnectionRpc(webCtx.get("connection", false))) new RedAlertCompatConnectionService(webCtx);
      let rendererHost: RendererHostService | undefined;
      await webCtx.plugin(RendererHostService, {
        rendererDistDir: config.rendererDistDir as string,
        rendererPort: config.rendererPort,
        onReady: (service) => { rendererHost = service; },
      });
      if (rendererHost === undefined || rendererHost.url === undefined) {
        throw new Error("red-alert renderer host did not become ready");
      }
      await webCtx.plugin(MatchService, { ...config, rendererHost });
    });
    return;
  }
  await ctx.plugin(MatchService, config);
}
