import { defineTool, type ToolDefinition, type ToolRunContext } from "@deepseek-ai/dsh-tools";
import type { JsonValue } from "@deepseek-ai/dsh-session";
import type { MatchService } from "./index.ts";
import { RED_ALERT_GROUPS } from "./tool-policy.ts";
import { STRATEGY_RULE_IDS } from "./strategy-learning.ts";
import { FIELD_MANUAL_FACTIONS, FIELD_MANUAL_TOPICS } from "./field-manual.ts";

const ORDER_SCHEMA = {
  type: "object",
  additionalProperties: false,
  properties: {
    action: {
      type: "string",
      enum: ["move", "attackMove", "attackTarget", "retreat", "deploy"],
      required: true,
    },
    target: { type: "string" },
    qty: { type: "integer" },
    units: { type: "string", description: "Model-selected owned units from the latest observation. Prefer exact numeric ids joined by commas for micro-control; refresh once and remove stale ids if ownership changed." },
    x: { type: "integer" },
    y: { type: "integer" },
    contact: { type: "string", description: "Exact current-visible enemy id for attackTarget. A last-seen contact may only supply frozen coordinates to attackMove." },
    reason: { type: "string", description: "Short tactical reason chosen by the model and retained in the command log." },
  },
} as const;

const JSON_OUTPUT = { type: "json" } as const;

function renderJson(_args: unknown, value: JsonValue): { type: "text"; text: string }[] {
  return [{ type: "text", text: JSON.stringify(value) }];
}

function closeParameters(definition: ToolDefinition): ToolDefinition {
  const parameters = definition.parameters as {
    readonly properties: Record<string, unknown>;
    readonly required?: readonly string[];
  };
  const closedParameters = {
    ...parameters,
    additionalProperties: false,
  };
  const execute = definition.execute;
  return {
    ...definition,
    parameters: closedParameters,
    async execute(args: unknown, exec: ToolRunContext): Promise<unknown> {
      if (typeof args !== "object" || args === null || Array.isArray(args)) {
        throw new Error("tool arguments must be a JSON object");
      }
      const unknownKeys = Object.keys(args).filter((key) => !Object.hasOwn(parameters.properties, key));
      if (unknownKeys.length > 0) {
        throw new Error(`unknown tool argument: ${unknownKeys.join(", ")}`);
      }
      return execute(args, exec);
    },
  };
}

/** Build two bootstrap tools and exact deferred game tools owned by one MatchService. */
export function createMatchTools(service: MatchService): ToolDefinition[] {
  const capabilities = closeParameters(defineTool({
    name: "red_alert_capabilities",
    description: "List the red-alert capability groups and the groups selected for this Agent session.",
    parameters: {},
    output: { schema: JSON_OUTPUT, render: renderJson },
    execute: async (_args, exec) => (await service.capabilities(exec)) as unknown as JsonValue,
  }));

  const loadGroup = closeParameters(defineTool({
    name: "red_alert_load_group",
    description: "Load one exact red-alert tool group for this Agent session when the current match phase permits it.",
    parameters: {
      group: { type: "string", enum: RED_ALERT_GROUPS.filter(group => group !== "bootstrap/capability"), required: true },
      matchId: { type: "string" },
    },
    output: { schema: JSON_OUTPUT, render: renderJson },
    execute: async (args, exec) => (await service.loadGroup(args, exec)) as unknown as JsonValue,
  }));

  const strategyBrief = closeParameters(defineTool({
    name: "red_alert_strategy_brief",
    description: "Load the short audited strategy learned from prior fog-safe matches for one map, country, and opponent type before creating a new match.",
    parameters: {
      map: { type: "string" },
      myCountry: { type: "string" },
      opponentType: { type: "string", enum: ["noop", "supalosa", "normal"] },
    },
    output: { schema: JSON_OUTPUT, render: renderJson },
    execute: async (args, exec) => (await service.runGroupTool(
      "red_alert_strategy_brief",
      exec,
      () => service.strategyBrief(args, exec),
    )) as unknown as JsonValue,
  }));

  const fieldManual = closeParameters(defineTool({
    name: "red_alert_field_manual",
    description: "Load one compact built-in Red Alert 2 page for exact structure ids, unit roles, openings, or combat tactics before creating a match.",
    parameters: {
      topic: { type: "string", enum: FIELD_MANUAL_TOPICS, required: true },
      faction: { type: "string", enum: FIELD_MANUAL_FACTIONS, required: true },
    },
    output: { schema: JSON_OUTPUT, render: renderJson },
    execute: async (args, exec) => (await service.runGroupTool(
      "red_alert_field_manual",
      exec,
      () => service.fieldManual(args, exec),
    )) as unknown as JsonValue,
  }));

  const reviewMatch = closeParameters(defineTool({
    name: "red_alert_review_match",
    description: "After a natural match result, adopt or reject only the episode's bounded lesson candidates so later matches can improve without free-form prompt injection.",
    parameters: {
      matchId: { type: "string", required: true },
      adoptedRuleIds: { type: "array", items: { type: "string", enum: STRATEGY_RULE_IDS }, required: true },
      rejectedRuleIds: { type: "array", items: { type: "string", enum: STRATEGY_RULE_IDS }, required: true },
    },
    output: { schema: JSON_OUTPUT, render: renderJson },
    execute: async (args, exec) => (await service.runGroupTool(
      "red_alert_review_match",
      exec,
      () => service.reviewMatch(args, exec),
    )) as unknown as JsonValue,
  }));

  const start = closeParameters(defineTool({
    name: "red_alert_start",
    description: "Create one real browser match for this Agent session and return its first fog-safe observation. Only one match may be active, but after a natural terminal result and structured review this tool can create the next match in the same Chat with a new matchId. Omit map to use the configured current map; never invent a map name such as default. If first-run local game files are requested, wait for the user import and retry this same tool once.",
    parameters: {
      map: { type: "string" },
      myCountry: { type: "string" },
      opponents: { type: "integer" },
      opponentType: { type: "string", enum: ["noop", "supalosa", "normal"] },
      gameSpeed: { type: "integer", enum: [0, 1, 2, 3, 4, 5, 6], description: "Game speed from 0 (slowest, 10 ticks/s) through 6 (fastest, 60 ticks/s); 2 is the plugin default and original 15 ticks/s pace." },
      decisionPeriod: { type: "integer" },
      maxTicks: { type: "integer" },
    },
    output: { schema: JSON_OUTPUT, render: renderJson },
    execute: async (args, exec) => (await service.runGroupTool("red_alert_start", exec, () => service.start(args, exec))) as unknown as JsonValue,
  }));

  const unitOrder = closeParameters(defineTool({
    name: "red_alert_unit_order",
    description: "Execute the model's ordered micro-control batch. The plugin validates and forwards exactly these movement, focus-fire, retreat, or deploy decisions; it never chooses targets or adds background orders. Put independent groups in separate orders within this one call. The whole batch fails closed if any selected id is stale or an attackTarget is not currently visible.",
    parameters: {
      matchId: { type: "string", required: true },
      orders: { type: "array", description: "One model decision may contain multiple ordered actions, such as retreating damaged armor while other exact units focus fire or attack-move.", items: ORDER_SCHEMA, required: true },
    },
    output: { schema: JSON_OUTPUT, render: renderJson },
    execute: async (args, exec) => (await service.runGroupTool("red_alert_unit_order", exec, () => service.act(args, exec))) as unknown as JsonValue,
  }));

  const status = closeParameters(defineTool({
    name: "red_alert_status",
    description: "Read a fresh fog-safe observation from this Agent session's current match.",
    parameters: {
      matchId: { type: "string", required: true },
    },
    output: { schema: JSON_OUTPUT, render: renderJson },
    execute: async (args, exec) => (await service.runGroupTool("red_alert_status", exec, () => service.status(args, exec))) as unknown as JsonValue,
  }));

  const stop = closeParameters(defineTool({
    name: "red_alert_stop",
    description: "Stop this Agent session's current match; repeated calls are safe.",
    parameters: {
      matchId: { type: "string", required: true },
    },
    output: { schema: JSON_OUTPUT, render: renderJson },
    execute: async (args, exec) => (await service.runGroupTool("red_alert_stop", exec, () => service.stop(args, exec))) as unknown as JsonValue,
  }));

  const browserTool = (definition: {
    readonly name: string;
    readonly description: string;
    readonly parameters: Record<string, unknown>;
  }): ToolDefinition => closeParameters(defineTool({
    name: definition.name,
    description: definition.description,
    parameters: definition.parameters as never,
    output: { schema: JSON_OUTPUT, render: renderJson },
    execute: async (args, exec) => (await service.runGroupTool(definition.name, exec, () => service.browserTool({ tool: definition.name, ...args } as never, exec))) as unknown as JsonValue,
  }));

  const matchId = { type: "string", required: true } as const;
  const exactBrowserTools = [
    browserTool({ name: "red_alert_lobby_map", description: "Read public map metadata and only this seat's own starting location.", parameters: { matchId } }),
    browserTool({ name: "red_alert_lobby_players", description: "List public player seats without enemy economy or starting locations.", parameters: { matchId } }),
    browserTool({ name: "red_alert_observe", description: "Read a fresh fog-safe observation for this seat.", parameters: { matchId } }),
    browserTool({ name: "red_alert_map", description: "Read public map metadata and an optional current-visible tile rectangle. When supplied, x, y, width, and height are all required and width and height must be 1 through 16.", parameters: { matchId, x: { type: "integer" }, y: { type: "integer" }, width: { type: "integer" }, height: { type: "integer" } } }),
    browserTool({ name: "red_alert_resources", description: "Read ore and gems only in a current-visible rectangle whose width and height are 1 through 16.", parameters: { matchId, x: { type: "integer", required: true }, y: { type: "integer", required: true }, width: { type: "integer", required: true }, height: { type: "integer", required: true } } }),
    browserTool({ name: "red_alert_rules", description: "Read the small public rules subset required for legal play.", parameters: { matchId } }),
    browserTool({ name: "red_alert_production_catalog", description: "List objects this seat can currently produce.", parameters: { matchId } }),
    browserTool({ name: "red_alert_production_status", description: "Read this seat's production queues. Queue status is 0 idle, 1 active, 2 on hold, or 3 ready; a structure may be placed only when its matching queue item is status 3.", parameters: { matchId } }),
    browserTool({ name: "red_alert_production", description: "Queue, cancel, pause, or resume this seat's production. queueType must be 0 through 5 and quantity must be 1 through 99.", parameters: { matchId, operation: { type: "string", enum: ["queue", "cancel", "pause", "resume"], required: true }, queueType: { type: "integer", required: true }, name: { type: "string" }, quantity: { type: "integer" } } }),
    browserTool({ name: "red_alert_construction_catalog", description: "List currently available buildings and their public placement footprint.", parameters: { matchId } }),
    browserTool({ name: "red_alert_construction", description: "Place a completed building near a requested current-visible anchor, returning the nearest legal current-visible foundation, or sell or repair one currently owned building.", parameters: { matchId, operation: { type: "string", enum: ["place", "sell", "repair"], required: true }, name: { type: "string" }, objectId: { type: "integer" }, x: { type: "integer" }, y: { type: "integer" } } }),
    browserTool({ name: "red_alert_diplomacy", description: "Read public alliance facts or toggle this seat's alliance with one public player.", parameters: { matchId, player: { type: "string" }, allied: { type: "boolean" } } }),
    browserTool({ name: "red_alert_superweapons", description: "Read this seat's superweapons or activate one at a legal map target.", parameters: { matchId, type: { type: "integer" }, x: { type: "integer" }, y: { type: "integer" }, x2: { type: "integer" }, y2: { type: "integer" } } }),
  ];

  return [capabilities, loadGroup, fieldManual, strategyBrief, reviewMatch, start, ...exactBrowserTools, unitOrder, status, stop];
}
