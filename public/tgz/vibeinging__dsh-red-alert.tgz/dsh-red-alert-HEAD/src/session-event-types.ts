/** Every durable event written by this external plugin. */
export const RED_ALERT_SESSION_EVENT_TYPES = Object.freeze([
  "red-alert/state",
  "red-alert/tool-group-selection",
  "red-alert/field-manual",
  "red-alert/strategy-brief",
  "red-alert/strategy-episode",
  "red-alert/strategy-review",
  "red-alert/browser-command-admitted",
  "red-alert/browser-command-published",
  "red-alert/browser-command-result",
  "red-alert/browser-command-result-published",
] as const);
