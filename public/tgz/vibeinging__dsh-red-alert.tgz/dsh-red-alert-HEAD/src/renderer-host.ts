import { createReadStream, existsSync, realpathSync, statSync } from "node:fs";
import { createServer, type IncomingMessage, type ServerResponse } from "node:http";
import path from "node:path";
import { pipeline } from "node:stream/promises";
import { Service, type Context } from "@deepseek-ai/cordis";
import type { WebServer } from "@deepseek-ai/dsh-host-webserver";
import { RED_ALERT_RENDERER_LOOPBACK_HOST } from "./browser-command-protocol.ts";

/** Loopback-only static server path; it is not a DSH host route. */
export const RED_ALERT_RENDERER_ROUTE = "/" as const;

/** Validated configuration for the user-provided renderer server. */
export interface RendererHostConfig {
  readonly rendererDistDir: string;
  /** Zero asks the OS for a loopback port; the live port is exposed only by Connection RPC. */
  readonly rendererPort?: number;
  /** Internal startup handoff used by the owning plugin across isolated Cordis scopes. */
  readonly onReady?: (service: RendererHostService) => void;
}

const MIME_TYPES: Readonly<Record<string, string>> = {
  ".css": "text/css; charset=utf-8",
  ".7z": "application/x-7z-compressed",
  ".csf": "application/octet-stream",
  ".gif": "image/gif",
  ".html": "text/html; charset=utf-8",
  ".ini": "text/plain; charset=utf-8",
  ".jpeg": "image/jpeg",
  ".jpg": "image/jpeg",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".mix": "application/octet-stream",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".wasm": "application/wasm",
  ".webp": "image/webp",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
};

const STATIC_HEADERS = {
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff",
} as const;
const RED_ALERT_RENDERER_BIND_HOST = "127.0.0.1" as const;

function frameAncestors(parentOrigin: string): string {
  let origin: URL;
  try {
    origin = new URL(parentOrigin);
  } catch {
    throw new Error("rendererParentOrigin must be an absolute origin");
  }
  if (origin.origin === "null" || origin.username !== "" || origin.password !== "" || origin.pathname !== "/" || origin.search !== "" || origin.hash !== "") {
    throw new Error("rendererParentOrigin must contain only scheme, host and port");
  }
  if (origin.protocol !== "http:" && origin.protocol !== "https:") throw new Error("rendererParentOrigin must use http or https");
  return origin.origin;
}

/** Validate an explicit renderer directory without scanning or copying it. */
export function resolveRendererDistDir(value: string): string {
  if (typeof value !== "string" || value.length === 0 || !path.isAbsolute(value)) throw new Error("red-alert requires an absolute config.rendererDistDir");
  if (!existsSync(value) || !statSync(value).isDirectory()) throw new Error("red-alert config.rendererDistDir is not an existing directory");
  return realpathSync(value);
}

/** Validate the loopback port used by the isolated companion server. */
export function resolveRendererPort(value: number | undefined): number {
  const port = value ?? 0;
  if (!Number.isSafeInteger(port) || port < 0 || port > 65535) throw new Error("rendererPort must be an integer from 0 through 65535");
  return port;
}

function safeRelativePath(urlPath: string): string {
  let decoded: string;
  let previous = urlPath;
  try {
    for (let round = 0; round < 4; round += 1) {
      decoded = decodeURIComponent(previous);
      if (decoded === previous) break;
      previous = decoded;
    }
    decoded = previous;
  } catch {
    throw new Error("renderer path encoding is invalid");
  }
  if (decoded.includes("\0")) throw new Error("renderer path contains NUL");
  if (decoded.includes("\\")) throw new Error("renderer path contains a forbidden separator");
  if (decoded.includes("%")) throw new Error("renderer path encoding is too deep");
  const segments = decoded.split("/").filter(Boolean);
  if (segments.some((segment) => segment === "..")) throw new Error("renderer path traversal is forbidden");
  const relative = path.posix.join(...segments);
  if (relative === "" || relative === ".") return "index.html";
  if (relative.startsWith("../") || path.posix.isAbsolute(relative)) throw new Error("renderer path escapes its root");
  return relative;
}

function safeRendererFile(root: string, urlPath: string): string | undefined {
  let relative: string;
  try {
    relative = safeRelativePath(urlPath);
  } catch {
    return undefined;
  }
  const candidate = path.resolve(root, relative);
  if (!candidate.startsWith(`${root}${path.sep}`)) return undefined;
  if (!existsSync(candidate)) return undefined;
  let real: string;
  try {
    real = realpathSync(candidate);
  } catch {
    return undefined;
  }
  if (real !== root && !real.startsWith(`${root}${path.sep}`)) return undefined;
  try {
    if (!statSync(real).isFile()) return undefined;
  } catch {
    return undefined;
  }
  return real;
}

function csp(parentOrigin: string): string {
  return [
    "default-src 'self'",
    "script-src 'self' 'wasm-unsafe-eval'",
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob:",
    "font-src 'self' data:",
    "connect-src 'self'",
    "worker-src 'self' blob:",
    `frame-ancestors ${parentOrigin}`,
  ].join("; ");
}

function writeStaticError(response: ServerResponse, status: number, headers: Readonly<Record<string, string>>): void {
  if (response.headersSent) {
    response.destroy();
    return;
  }
  response.writeHead(status, {
    ...headers,
    "Content-Type": "text/plain; charset=utf-8",
  });
  response.end(status === 404 ? "renderer file was not found" : "renderer request was rejected");
}

function rendererSecurityHeaders(parentOrigin: string): Readonly<Record<string, string>> {
  const ancestors = frameAncestors(parentOrigin);
  return {
    ...STATIC_HEADERS,
    "Content-Security-Policy": csp(ancestors),
  };
}

function rendererHostHeader(port: number): string {
  if (!Number.isSafeInteger(port) || port < 1 || port > 65535) throw new Error("renderer server port is invalid");
  return `${RED_ALERT_RENDERER_LOOPBACK_HOST}:${port}`;
}

function validateRendererHostHeader(value: string): void {
  const prefix = `${RED_ALERT_RENDERER_LOOPBACK_HOST}:`;
  const portText = value.slice(prefix.length);
  if (!value.startsWith(prefix) || !/^[1-9][0-9]{0,4}$/.test(portText)) throw new Error("renderer server host must be the exact isolated loopback host and port");
  const port = Number(portText);
  if (!Number.isSafeInteger(port) || port < 1 || port > 65535) throw new Error("renderer server port is invalid");
}

/** Create the isolated static handler; unknown paths never fall through to a DSH index. */
export function createRendererStaticHandler(rendererDistDir: string, parentOrigin: string, expectedHost: string): (request: IncomingMessage, response: ServerResponse) => Promise<void> {
  const root = resolveRendererDistDir(rendererDistDir);
  const securityHeaders = rendererSecurityHeaders(parentOrigin);
  validateRendererHostHeader(expectedHost);
  return async (request, response) => {
    if (request.headers.host !== expectedHost) {
      writeStaticError(response, 400, securityHeaders);
      return;
    }
    if (request.method !== "GET" && request.method !== "HEAD") {
      response.writeHead(405, { ...securityHeaders, Allow: "GET, HEAD" });
      response.end();
      return;
    }
    let pathname: string;
    try {
      pathname = new URL(request.url ?? "/", "http://renderer.invalid").pathname;
    } catch {
      writeStaticError(response, 400, securityHeaders);
      return;
    }
    const file = safeRendererFile(root, pathname);
    if (file === undefined || file.endsWith(".map")) {
      writeStaticError(response, 404, securityHeaders);
      return;
    }
    const contentType = MIME_TYPES[path.extname(file).toLowerCase()];
    if (contentType === undefined) {
      writeStaticError(response, 415, securityHeaders);
      return;
    }
    let size: number;
    try {
      size = statSync(file).size;
    } catch {
      writeStaticError(response, 404, securityHeaders);
      return;
    }
    response.writeHead(200, {
      ...securityHeaders,
      "Content-Length": String(size),
      "Content-Type": contentType,
    });
    if (request.method === "HEAD") {
      response.end();
      return;
    }
    await pipeline(createReadStream(file), response);
  };
}

/** Root-owned loopback server for a user-provided real renderer build. */
export class RendererHostService extends Service {
  readonly rendererDistDir: string;
  readonly rendererPort: number;
  readonly rendererParentOrigin: string;
  private server: ReturnType<typeof createServer> | undefined;
  private urlValue: string | undefined;
  private readonly onReady: ((service: RendererHostService) => void) | undefined;

  constructor(ctx: Context, config: RendererHostConfig) {
    super(ctx, "redAlertRendererHost");
    this.rendererDistDir = resolveRendererDistDir(config.rendererDistDir);
    this.rendererPort = resolveRendererPort(config.rendererPort);
    this.onReady = config.onReady;
    const webServer = ctx.get("webServer", false) as WebServer | undefined;
    if (webServer === undefined) throw new Error("red-alert renderer requires the DSH Web Profile webServer service");
    if (webServer.host !== "127.0.0.1" || !Number.isSafeInteger(webServer.port) || webServer.port < 1 || webServer.port > 65535) {
      throw new Error("red-alert renderer requires a DSH Web server bound to 127.0.0.1");
    }
    this.rendererParentOrigin = `http://127.0.0.1:${webServer.port}`;
  }

  get url(): string | undefined {
    return this.urlValue;
  }

  async [Service.init](): Promise<void> {
    let handler: ReturnType<typeof createRendererStaticHandler> | undefined;
    const bootHeaders = rendererSecurityHeaders(this.rendererParentOrigin);
    const server = createServer((request, response) => {
      if (handler === undefined) {
        writeStaticError(response, 503, bootHeaders);
        return;
      }
      handler(request, response).catch(() => {
        if (!response.headersSent) writeStaticError(response, 400, bootHeaders);
        else response.destroy();
      });
    });
    this.server = server;
    await new Promise<void>((resolve, reject) => {
      const onError = () => { server.off("error", onError); reject(new Error("renderer loopback server failed to listen")); };
      server.once("error", onError);
      server.listen(this.rendererPort, RED_ALERT_RENDERER_BIND_HOST, () => {
        server.off("error", onError);
        const address = server.address();
        if (address === null || typeof address === "string") {
          reject(new Error("renderer loopback server did not expose a port"));
          return;
        }
        this.urlValue = `http://${RED_ALERT_RENDERER_LOOPBACK_HOST}:${address.port}/`;
        handler = createRendererStaticHandler(this.rendererDistDir, this.rendererParentOrigin, rendererHostHeader(address.port));
        this.onReady?.(this);
        server.on("error", () => {
          this.ctx.logger.error(new Error("red-alert renderer loopback server failed"));
        });
        resolve();
      });
    });
    this.ctx.effect(() => async () => {
      server.closeAllConnections();
      await new Promise<void>((resolve) => {
        if (!server.listening) {
          resolve();
          return;
        }
        server.close(() => resolve());
      });
    }, "red-alert renderer loopback server");
  }
}

/** Plugin object for the optional user-provided loopback renderer server. */
export const rendererHostPlugin = {
  name: "red-alert-renderer-host",
  inject: ["webServer"],
  apply(ctx: Context, config: RendererHostConfig): void {
    ctx.plugin(RendererHostService, config);
  },
};
