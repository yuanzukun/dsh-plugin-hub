import { randomUUID } from "node:crypto";
import type { HostConnectionHandle } from "@deepseek-ai/dsh-client-connection";
import type { RpcResult } from "@deepseek-ai/dsh-client-connection/client";
import type { Session } from "@deepseek-ai/dsh-session";
import {
  RED_ALERT_BROWSER_CHANNEL,
  RED_ALERT_BROWSER_COMMAND_EVENT,
  RED_ALERT_BROWSER_COMMAND_PUBLISHED_EVENT,
  RED_ALERT_BROWSER_COMMAND_RESULT_EVENT,
  RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT,
  browserRpcError,
  decodeBrowserCommand,
  decodeBrowserLeaseRegisterRequest,
  decodeBrowserLeaseReleaseRequest,
  decodeBrowserRendererConfigRequest,
  decodeBrowserReceipt,
  decodeBrowserCommandResult,
  decodeBrowserCommandResultPublicationEvent,
  validateBrowserCommandReceipt,
  type BrowserCommandResultPublicationEvent,
  type BrowserCommandEnvelope,
  type BrowserCommandReceipt,
  type BrowserCommandResultEvent,
  type BrowserLeaseValue,
  type BrowserRendererConfigValue,
  type BrowserCreateMatchRequest,
  type BrowserGameToolRequest,
  type BrowserOrder,
  type BrowserReceiptRequest,
} from "./browser-command-protocol.ts";

/** Current authoritative match identity exposed to the browser transport. */
export interface BrowserMatchAuthority {
  readonly matchId: string;
  readonly seat: string;
  readonly tick: number;
  readonly status: "creating" | "active" | "finished" | "stopped";
}

/** Input accepted by the Host outbox; requestId and protocol identity are Host-owned. */
interface BrowserCommandInputIdentity {
  readonly matchId: string;
  readonly seat: string;
  readonly expectedTick: number;
}

export type BrowserCommandInput = BrowserCommandInputIdentity & (
  | { readonly kind: "create-match"; readonly request: BrowserCreateMatchRequest }
  | { readonly kind: "orders"; readonly orders: readonly BrowserOrder[] }
  | { readonly kind: "tool"; readonly request: BrowserGameToolRequest }
  | { readonly kind: "observe" }
  | { readonly kind: "stop-match" }
);

export interface BrowserCommandTransportOptions {
  readonly connection: HostConnectionHandle;
  readonly flush: (session: Session) => Promise<void>;
  readonly isSessionOwner: (sessionId: string) => boolean;
  readonly resolveAuthority: (sessionId: string) => BrowserMatchAuthority | undefined;
  readonly resolveSession: (sessionId: string) => Session | undefined;
  readonly timeoutMs: number;
  readonly createMatchTimeoutMs?: number;
  readonly logger?: Pick<Console, "error">;
  readonly requestId?: () => string;
  /** Resolve the current loopback renderer endpoint without persisting its port. */
  readonly resolveRendererConfig?: (sessionId: string) => BrowserRendererConfigValue | undefined;
}

/** Error raised by the Host outbox without exposing engine objects. */
export class BrowserCommandTransportError extends Error {
  constructor(readonly code: string, message: string) {
    super(message);
    this.name = "BrowserCommandTransportError";
  }
}

interface LeaseRecord {
  readonly clientInstanceId: string;
  readonly matchId: string;
  readonly seat: string;
  readonly leaseToken: string;
}

interface PendingCommand {
  readonly session: Session;
  readonly command: BrowserCommandEnvelope;
  readonly resolve: (receipt: BrowserCommandReceipt) => void;
  readonly reject: (error: unknown) => void;
  published: boolean;
  abortRequested: boolean;
  finalizing: boolean;
  admission?: Promise<void>;
  admissionError?: unknown;
  finalization?: Promise<void>;
  timer?: ReturnType<typeof setTimeout>;
  cleanup?: () => void;
}

type RpcValue<T> = RpcResult<T>;

function rpcOk<T>(value: T): RpcValue<T> {
  return { ok: true, value };
}

function boundedMessage(_error: unknown, fallback: string): string {
  return fallback.slice(0, 240);
}

function stableDiagnostic(code: string, message: string): string {
  return `red-alert ${code}: ${message}`;
}

function errorCode(error: unknown, fallback: string): string {
  if (error instanceof BrowserCommandTransportError) return error.code;
  return fallback;
}

function sameJson(left: unknown, right: unknown): boolean {
  return JSON.stringify(left) === JSON.stringify(right);
}

/**
 * Host-side command outbox and official Connection RPC registry.
 *
 * This class owns no engine state. It only appends safe command/result events,
 * waits for the durable flush boundary, and hands validated receipts back to
 * the caller that admitted the command.
 */
export class BrowserCommandTransport {
  private readonly connection: HostConnectionHandle;
  private readonly flush: BrowserCommandTransportOptions["flush"];
  private readonly isSessionOwner: BrowserCommandTransportOptions["isSessionOwner"];
  private readonly resolveAuthority: BrowserCommandTransportOptions["resolveAuthority"];
  private readonly resolveSession: BrowserCommandTransportOptions["resolveSession"];
  private readonly timeoutMs: number;
  private readonly createMatchTimeoutMs: number;
  private readonly logger: Pick<Console, "error">;
  private readonly requestIdFactory: () => string;
  private readonly resolveRendererConfig: BrowserCommandTransportOptions["resolveRendererConfig"];
  private readonly pending = new Map<string, PendingCommand>();
  private readonly leases = new Map<string, LeaseRecord>();
  private readonly sessionCleanupPromises = new Map<string, Promise<void>>();
  private readonly sessionFinalizations = new Map<string, Set<Promise<void>>>();
  private unregister: (() => Promise<void>) | undefined;
  private disposePromise: Promise<void> | undefined;
  private started = false;
  private disposed = false;

  constructor(options: BrowserCommandTransportOptions) {
    if (!Number.isSafeInteger(options.timeoutMs) || options.timeoutMs < 1) throw new BrowserCommandTransportError("CONFIG", "browser command timeout must be a positive integer");
    if (options.createMatchTimeoutMs !== undefined && (!Number.isSafeInteger(options.createMatchTimeoutMs) || options.createMatchTimeoutMs < 1)) {
      throw new BrowserCommandTransportError("CONFIG", "browser create-match timeout must be a positive integer");
    }
    this.connection = options.connection;
    this.flush = options.flush;
    this.isSessionOwner = options.isSessionOwner;
    this.resolveAuthority = options.resolveAuthority;
    this.resolveSession = options.resolveSession;
    this.timeoutMs = options.timeoutMs;
    this.createMatchTimeoutMs = options.createMatchTimeoutMs ?? options.timeoutMs;
    this.logger = options.logger ?? console;
    this.requestIdFactory = options.requestId ?? randomUUID;
    this.resolveRendererConfig = options.resolveRendererConfig;
  }

  /** Register the plugin-owned `/red-alert` channel with loopback authority. */
  start(): void {
    if (this.disposed) throw new BrowserCommandTransportError("DISPOSED", "browser command transport is disposed");
    if (this.started) return;
    this.unregister = this.connection.rpc.handle(
      RED_ALERT_BROWSER_CHANNEL,
      (endpoint, payload, signal) => this.handleRpc(endpoint, payload, signal),
      { authority: "loopback" },
    );
    this.started = true;
  }

  /** Return whether this Host process still owns one live command for the session. */
  hasPending(sessionId: string): boolean {
    return this.pending.has(sessionId);
  }

  /** Close the channel and fail every pending command deterministically. */
  dispose(): Promise<void> {
    if (this.disposePromise !== undefined) return this.disposePromise;
    this.disposePromise = this.disposeInternal();
    return this.disposePromise;
  }

  private async disposeInternal(): Promise<void> {
    this.disposed = true;
    const unregister = this.unregister;
    this.unregister = undefined;
    const errors: unknown[] = [];
    if (unregister !== undefined) {
      try {
        await unregister();
      } catch (error) {
        errors.push(error);
      }
    }
    const sessionIds = new Set<string>([
      ...this.pending.keys(),
      ...this.leases.keys(),
      ...this.sessionCleanupPromises.keys(),
      ...this.sessionFinalizations.keys(),
    ]);
    const cleanups = await Promise.allSettled([...sessionIds].map((sessionId) => this.cleanupSession(sessionId, "TRANSPORT_DISPOSED")));
    for (const result of cleanups) if (result.status === "rejected") errors.push(result.reason);
    this.started = false;
    if (errors.length === 1) throw errors[0];
    if (errors.length > 1) throw new AggregateError(errors, "red-alert browser transport disposal failed");
  }

  /**
   * Append and flush one command, then wait for the matching browser receipt.
   * One owning session can have only one pending command.
   */
  async dispatch(session: Session, input: BrowserCommandInput, signal: AbortSignal): Promise<BrowserCommandReceipt> {
    if (this.disposed) throw new BrowserCommandTransportError("DISPOSED", "browser command transport is disposed");
    if (signal.aborted) throw new BrowserCommandTransportError("CANCELLED", "browser command was cancelled before admission");
    const sessionId = String(session.id);
    if (!this.isSessionOwner(sessionId)) throw new BrowserCommandTransportError("UNAUTHORIZED", "browser command session is not owned by the current Agent");
    if (this.pending.has(sessionId)) throw new BrowserCommandTransportError("BUSY", "one browser command is already in flight for this session");
    const authority = this.resolveAuthority(sessionId);
    if (authority === undefined) throw new BrowserCommandTransportError("NO_ACTIVE_MATCH", "browser command requires a current match");
    if (input.kind === "create-match" ? authority.status !== "creating" : authority.status !== "active") {
      throw new BrowserCommandTransportError("INVALID_PHASE", `browser ${input.kind} command is not allowed during ${authority.status}`);
    }
    if (input.matchId !== authority.matchId || input.seat !== authority.seat || input.expectedTick > authority.tick) throw new BrowserCommandTransportError("STALE_IDENTITY", "browser command identity or expected tick is stale");

    const command = decodeBrowserCommand({
      protocolVersion: 1,
      requestId: this.requestIdFactory(),
      sessionId,
      matchId: input.matchId,
      seat: input.seat,
      expectedTick: input.expectedTick,
      kind: input.kind,
      ...(input.kind === "create-match" || input.kind === "tool" ? { request: input.request } : input.kind === "orders" ? { orders: input.orders } : {}),
    });
    const result = await new Promise<BrowserCommandReceipt>((resolve, reject) => {
      const pending: PendingCommand = { session, command, resolve, reject, published: false, abortRequested: false, finalizing: false };
      this.pending.set(sessionId, pending);
      const onAbort = () => {
        if (this.pending.get(sessionId) !== pending) return;
        if (!pending.published) {
          pending.abortRequested = true;
          return;
        }
        void this.finalizeFailure(pending, "cancelled", "CANCELLED", "browser command was cancelled").catch(() => this.logger.error(stableDiagnostic("RESULT_COMMIT_FAILED", "browser command result could not be durably committed")));
      };
      signal.addEventListener("abort", onAbort, { once: true });
      pending.cleanup = () => signal.removeEventListener("abort", onAbort);
      pending.admission = this.admit(pending).catch((error: unknown) => {
        pending.admissionError = error;
        if (this.pending.get(sessionId) !== pending) return;
        this.pending.delete(sessionId);
        pending.cleanup?.();
        pending.reject(error);
      });
      void pending.admission;
    });
    return result;
  }

  /** Cancel one session's browser work, persist its failure, and release its lease. */
  cleanupSession(sessionId: string, reason: "SESSION_DISPOSED" | "TRANSPORT_DISPOSED" = "SESSION_DISPOSED"): Promise<void> {
    const existing = this.sessionCleanupPromises.get(sessionId);
    if (existing !== undefined) return existing;
    const cleanup = this.cleanupSessionInternal(sessionId, reason);
    this.sessionCleanupPromises.set(sessionId, cleanup);
    void cleanup.then(
      () => { if (this.sessionCleanupPromises.get(sessionId) === cleanup) this.sessionCleanupPromises.delete(sessionId); },
      () => { if (this.sessionCleanupPromises.get(sessionId) === cleanup) this.sessionCleanupPromises.delete(sessionId); },
    );
    return cleanup;
  }

  private async cleanupSessionInternal(sessionId: string, reason: "SESSION_DISPOSED" | "TRANSPORT_DISPOSED"): Promise<void> {
    const errors: unknown[] = [];
    const addError = (error: unknown): void => {
      if (!errors.includes(error)) errors.push(error);
    };
    try {
      const pending = this.pending.get(sessionId);
      if (pending !== undefined) {
        pending.abortRequested = true;
        if (pending.admission !== undefined) {
          try {
            await pending.admission;
          } catch (error) {
            addError(error);
          }
        }
        if (pending.admissionError !== undefined) addError(pending.admissionError);
        if (pending.finalization !== undefined) {
          try {
            await pending.finalization;
          } catch (error) {
            addError(error);
          }
        }
        const current = this.pending.get(sessionId);
        if (current !== undefined) {
          try {
            await this.finalizeFailure(current, "cancelled", reason, reason === "TRANSPORT_DISPOSED" ? "browser command transport was disposed" : "browser session was disposed");
          } catch (error) {
            addError(error);
          }
        }
      }
      for (const error of await this.waitForSessionFinalizations(sessionId)) addError(error);
    } finally {
      this.leases.delete(sessionId);
    }
    if (errors.length === 1) throw errors[0];
    if (errors.length > 1) throw new AggregateError(errors, "red-alert browser session cleanup failed");
  }

  private async admit(pending: PendingCommand): Promise<void> {
    let appended = false;
    try {
      pending.session.append(RED_ALERT_BROWSER_COMMAND_EVENT, pending.command);
      appended = true;
      await this.flush(pending.session);
    } catch (error) {
      this.logger.error(stableDiagnostic("ADMISSION_FAILED", "browser command admission failed"));
      if (appended) {
        await this.tryRecordFailure(pending, "failed", errorCode(error, "ADMISSION_FAILED"), boundedMessage(error, "browser command admission failed"));
      }
      throw new BrowserCommandTransportError("ADMISSION_FAILED", "browser command admission failed");
    }
    if (this.pending.get(pending.command.sessionId) !== pending) return;
    if (this.disposed || pending.abortRequested) {
      const code = this.disposed ? "TRANSPORT_DISPOSED" : "CANCELLED";
      const message = this.disposed ? "browser command transport was disposed before publication" : "browser command was cancelled before publication";
      await this.finalizeFailure(pending, "cancelled", code, message);
      return;
    }
    try {
      pending.session.append(RED_ALERT_BROWSER_COMMAND_PUBLISHED_EVENT, {
        protocolVersion: pending.command.protocolVersion,
        requestId: pending.command.requestId,
        sessionId: pending.command.sessionId,
        matchId: pending.command.matchId,
        seat: pending.command.seat,
        expectedTick: pending.command.expectedTick,
      });
      pending.published = true;
      const timeoutMs = pending.command.kind === "create-match" ? this.createMatchTimeoutMs : this.timeoutMs;
      pending.timer = setTimeout(() => {
        void this.finalizeFailure(pending, "failed", "TIMEOUT", "browser command receipt timed out").catch(() => this.logger.error(stableDiagnostic("RESULT_COMMIT_FAILED", "browser command result could not be durably committed")));
      }, timeoutMs);
    } catch (error) {
      this.logger.error(stableDiagnostic("ADMISSION_FAILED", "browser command admission failed"));
      if (appended) {
        await this.tryRecordFailure(pending, "failed", errorCode(error, "ADMISSION_FAILED"), boundedMessage(error, "browser command admission failed"));
      }
      throw new BrowserCommandTransportError("ADMISSION_FAILED", "browser command admission failed");
    }
  }

  private async handleRpc(endpoint: string, payload: unknown, signal: AbortSignal): Promise<RpcValue<unknown>> {
    if (this.disposed) return browserRpcError("DISPOSED", "browser command transport is disposed");
    if (signal.aborted) return browserRpcError("CANCELLED", "browser RPC request was cancelled");
    try {
      if (endpoint === "lease/register") return await this.registerLease(payload);
      if (endpoint === "lease/release") return await this.releaseLease(payload);
      if (endpoint === "renderer/config") return await this.rendererConfig(payload);
      if (endpoint === "receipt") return await this.acceptReceipt(payload);
      return browserRpcError("UNKNOWN_ENDPOINT", "red-alert browser endpoint is not supported");
    } catch (error) {
      const code = error instanceof BrowserCommandTransportError ? error.code : "INVALID_REQUEST";
      return browserRpcError(code, boundedMessage(error, "red-alert browser RPC request failed"));
    }
  }

  private async registerLease(payload: unknown): Promise<RpcValue<BrowserLeaseValue>> {
    const request = decodeBrowserLeaseRegisterRequest(payload);
    this.assertOwnerAndAuthority(request.sessionId, request.matchId, request.seat);
    const existing = this.leases.get(request.sessionId);
    if (existing !== undefined) {
      if (existing.clientInstanceId === request.clientInstanceId) {
        if (existing.matchId !== request.matchId || existing.seat !== request.seat) throw new BrowserCommandTransportError("STALE_IDENTITY", "browser lease identity is stale");
        return rpcOk({ protocolVersion: 1, sessionId: request.sessionId, matchId: existing.matchId, seat: existing.seat, leaseToken: existing.leaseToken });
      }
      const finalizations = this.sessionFinalizations.get(request.sessionId);
      if (this.pending.has(request.sessionId) || this.sessionCleanupPromises.has(request.sessionId) || (finalizations?.size ?? 0) > 0) {
        throw new BrowserCommandTransportError("LEASE_BUSY", "another browser client owns an in-flight session lease");
      }
    }
    const lease: LeaseRecord = {
      clientInstanceId: request.clientInstanceId,
      matchId: request.matchId,
      seat: request.seat,
      leaseToken: randomUUID(),
    };
    this.leases.set(request.sessionId, lease);
    return rpcOk({ protocolVersion: 1, sessionId: request.sessionId, matchId: lease.matchId, seat: lease.seat, leaseToken: lease.leaseToken });
  }

  private async rendererConfig(payload: unknown): Promise<RpcValue<BrowserRendererConfigValue>> {
    const request = decodeBrowserRendererConfigRequest(payload);
    this.assertOwnerAndAuthority(request.sessionId, request.matchId, request.seat);
    const lease = this.leases.get(request.sessionId);
    if (lease === undefined || lease.leaseToken !== request.leaseToken || lease.matchId !== request.matchId || lease.seat !== request.seat) throw new BrowserCommandTransportError("LEASE_INVALID", "browser renderer config lease is invalid");
    const config = this.resolveRendererConfig?.(request.sessionId);
    if (config === undefined) throw new BrowserCommandTransportError("RENDERER_UNAVAILABLE", "renderer configuration is unavailable");
    if (config.sessionId !== request.sessionId || config.matchId !== request.matchId || config.seat !== request.seat) throw new BrowserCommandTransportError("STALE_IDENTITY", "renderer configuration identity is stale");
    return rpcOk(config);
  }

  private async releaseLease(payload: unknown): Promise<RpcValue<{ readonly released: true }>> {
    const request = decodeBrowserLeaseReleaseRequest(payload);
    const existing = this.leases.get(request.sessionId);
    if (existing === undefined) return rpcOk({ released: true });
    if (existing.leaseToken !== request.leaseToken) throw new BrowserCommandTransportError("LEASE_INVALID", "browser lease token is invalid");
    this.leases.delete(request.sessionId);
    return rpcOk({ released: true });
  }

  private async acceptReceipt(payload: unknown): Promise<RpcValue<unknown>> {
    const request = decodeBrowserReceipt(payload);
    this.assertOwnerAndAuthority(request.sessionId, request.matchId, request.seat);
    const lease = this.leases.get(request.sessionId);
    if (lease === undefined || lease.leaseToken !== request.leaseToken || lease.matchId !== request.matchId || lease.seat !== request.seat) throw new BrowserCommandTransportError("LEASE_INVALID", "browser receipt lease is invalid");
    const pending = this.pending.get(request.sessionId);
    if (pending === undefined) {
      const replay = this.findCompleted(request.sessionId, request.requestId);
      if (replay?.status === "completed") {
        if (!sameJson(replay.receipt, this.withoutLease(request))) throw new BrowserCommandTransportError("DUPLICATE_MISMATCH", "duplicate browser receipt differs from the committed result");
        return rpcOk({ accepted: true, replayed: true, receipt: replay.receipt });
      }
      throw new BrowserCommandTransportError("NOT_PENDING", "browser command request is not pending");
    }
    if (!pending.published) throw new BrowserCommandTransportError("NOT_PUBLISHED", "browser command is not published yet");
    if (pending.command.requestId !== request.requestId || pending.command.sessionId !== request.sessionId || pending.command.matchId !== request.matchId || pending.command.seat !== request.seat) throw new BrowserCommandTransportError("IDENTITY", "browser receipt does not match the pending command");
    if (request.tick < pending.command.expectedTick) throw new BrowserCommandTransportError("STALE_TICK", "browser receipt tick is older than the command tick");
    if (pending.finalizing) throw new BrowserCommandTransportError("FINALIZING", "browser command result is already being committed");
    const receipt = validateBrowserCommandReceipt(pending.command, this.withoutLease(request));
    await this.finalizeReceipt(pending, receipt);
    return rpcOk({ accepted: true, replayed: false, receipt });
  }

  private withoutLease(request: BrowserReceiptRequest): BrowserCommandReceipt {
    const { leaseToken: _leaseToken, ...receipt } = request;
    return receipt;
  }

  private assertOwnerAndAuthority(sessionId: string, matchId: string, seat: string): BrowserMatchAuthority {
    if (!this.isSessionOwner(sessionId)) throw new BrowserCommandTransportError("UNAUTHORIZED", "browser session is not owned by the current Agent");
    const authority = this.resolveAuthority(sessionId);
    if (authority === undefined || (authority.status !== "creating" && authority.status !== "active")) throw new BrowserCommandTransportError("NO_ACTIVE_MATCH", "browser session has no current match");
    if (authority.matchId !== matchId || authority.seat !== seat) throw new BrowserCommandTransportError("STALE_IDENTITY", "browser identity does not match the active match");
    return authority;
  }

  private async finalizeReceipt(pending: PendingCommand, receipt: BrowserCommandReceipt): Promise<void> {
    if (pending.finalizing) throw new BrowserCommandTransportError("FINALIZING", "browser command result is already being committed");
    pending.finalizing = true;
    const finalization = (async () => {
      try {
        await this.commitResult(pending, { status: "completed", receipt });
        pending.resolve(receipt);
      } catch (error) {
        pending.reject(error);
        throw error;
      }
    })();
    pending.finalization = finalization;
    this.trackFinalization(pending, finalization);
    await finalization;
  }

  private async finalizeFailure(pending: PendingCommand, status: "failed" | "cancelled", code: string, message: string): Promise<void> {
    if (pending.finalizing) {
      if (pending.finalization !== undefined) await pending.finalization;
      return;
    }
    pending.finalizing = true;
    const finalization = (async () => {
      try {
        await this.commitResult(pending, { status, failure: { code, message: message.slice(0, 240) } });
        pending.reject(new BrowserCommandTransportError(code, message));
      } catch (error) {
        pending.reject(error);
        throw error;
      }
    })();
    pending.finalization = finalization;
    this.trackFinalization(pending, finalization);
    await finalization;
  }

  private trackFinalization(pending: PendingCommand, finalization: Promise<void>): void {
    const finalizations = this.sessionFinalizations.get(pending.command.sessionId) ?? new Set<Promise<void>>();
    finalizations.add(finalization);
    this.sessionFinalizations.set(pending.command.sessionId, finalizations);
    const remove = (): void => {
      finalizations.delete(finalization);
      if (finalizations.size === 0 && this.sessionFinalizations.get(pending.command.sessionId) === finalizations) {
        this.sessionFinalizations.delete(pending.command.sessionId);
      }
    };
    void finalization.then(remove, remove);
  }

  private async waitForSessionFinalizations(sessionId: string): Promise<unknown[]> {
    const errors: unknown[] = [];
    while (true) {
      const finalizations = this.sessionFinalizations.get(sessionId);
      if (finalizations === undefined || finalizations.size === 0) return errors;
      const results = await Promise.allSettled(finalizations);
      for (const result of results) if (result.status === "rejected") errors.push(result.reason);
    }
  }

  private async tryRecordFailure(pending: PendingCommand, status: "failed" | "cancelled", code: string, message: string): Promise<void> {
    try {
      const result: BrowserCommandResultEvent = {
        protocolVersion: 1,
        requestId: pending.command.requestId,
        sessionId: pending.command.sessionId,
        matchId: pending.command.matchId,
        seat: pending.command.seat,
        command: pending.command,
        status,
        failure: { code, message },
      };
      await this.appendResultAndMarker(pending.session, result);
    } catch {
      this.logger.error(stableDiagnostic("RESULT_COMMIT_FAILED", "browser command result could not be durably committed"));
    }
  }

  private async commitResult(
    pending: PendingCommand,
    result: { readonly status: "completed"; readonly receipt: BrowserCommandReceipt } | { readonly status: "failed" | "cancelled"; readonly failure: { readonly code: string; readonly message: string } },
  ): Promise<void> {
    const event: BrowserCommandResultEvent = result.status === "completed"
      ? {
          protocolVersion: 1,
          requestId: pending.command.requestId,
          sessionId: pending.command.sessionId,
          matchId: pending.command.matchId,
          seat: pending.command.seat,
          command: pending.command,
          status: "completed",
          receipt: result.receipt,
        }
      : {
          protocolVersion: 1,
          requestId: pending.command.requestId,
          sessionId: pending.command.sessionId,
          matchId: pending.command.matchId,
          seat: pending.command.seat,
          command: pending.command,
          status: result.status,
          failure: result.failure,
        };
    try {
      await this.appendResultAndMarker(pending.session, event);
    } catch {
      this.pending.delete(pending.command.sessionId);
      if (pending.timer !== undefined) clearTimeout(pending.timer);
      pending.cleanup?.();
      this.logger.error(stableDiagnostic("RESULT_COMMIT_FAILED", "browser command result could not be durably committed"));
      throw new BrowserCommandTransportError("RESULT_COMMIT_FAILED", "browser command result could not be durably committed");
    }
    this.pending.delete(pending.command.sessionId);
    if (pending.timer !== undefined) clearTimeout(pending.timer);
    pending.cleanup?.();
  }

  private async appendResultAndMarker(session: Session, result: BrowserCommandResultEvent): Promise<void> {
    session.append(RED_ALERT_BROWSER_COMMAND_RESULT_EVENT, result);
    await this.flush(session);
    const marker: BrowserCommandResultPublicationEvent = {
      protocolVersion: result.protocolVersion,
      requestId: result.requestId,
      sessionId: result.sessionId,
      matchId: result.matchId,
      seat: result.seat,
      status: result.status,
    };
    session.append(RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT, marker);
  }

  private findCompleted(sessionId: string, requestId: string): BrowserCommandResultEvent | undefined {
    const session = this.resolveSession(sessionId);
    if (session === undefined) return undefined;
    const events = [...session.events];
    for (let markerIndex = events.length - 1; markerIndex >= 0; markerIndex -= 1) {
      const markerEvent = events[markerIndex];
      if (markerEvent.type !== RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT) continue;
      let marker: BrowserCommandResultPublicationEvent;
      try {
        marker = decodeBrowserCommandResultPublicationEvent(markerEvent.data);
      } catch {
        continue;
      }
      if (marker.requestId !== requestId || marker.status !== "completed") continue;
      for (let resultIndex = markerIndex - 1; resultIndex >= 0; resultIndex -= 1) {
        const resultEvent = events[resultIndex];
        if (resultEvent.type !== RED_ALERT_BROWSER_COMMAND_RESULT_EVENT) continue;
        let result: BrowserCommandResultEvent;
        try {
          result = decodeBrowserCommandResult(resultEvent.data);
        } catch {
          return undefined;
        }
        if (result.requestId !== requestId) continue;
        if (result.status !== "completed"
          || result.protocolVersion !== marker.protocolVersion
          || result.sessionId !== marker.sessionId
          || result.matchId !== marker.matchId
          || result.seat !== marker.seat) return undefined;
        return result;
      }
    }
    return undefined;
  }
}
