import { z as zod } from "zod";
import type { SessionEvent } from "@deepseek-ai/dsh-session";
import type { ProjectionDefinition } from "@deepseek-ai/dsh-session-projection";
import type { FogSafeContact, FogSafeObservation } from "../packages/game-host/src/fog-safe-observation.ts";
import type { MatchView } from "../packages/game-host/src/match-controller.ts";
import type { Receipt } from "../packages/game-host/src/orders.ts";
import { DEFAULT_RESOURCE_ARCHIVE, type ResourceArchiveDescriptor } from "./resource-config.ts";
import {
  RED_ALERT_BROWSER_COMMAND_EVENT,
  RED_ALERT_BROWSER_COMMAND_PROJECTION,
  RED_ALERT_BROWSER_COMMAND_PUBLISHED_EVENT,
  RED_ALERT_BROWSER_COMMAND_RESULT_EVENT,
  RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT,
  decodeBrowserCommandEvent,
  decodeBrowserCommandPublicationEvent,
  decodeBrowserCommandResult,
  decodeBrowserCommandResultPublicationEvent,
  projectBrowserCommandResult,
  type BrowserCommandEnvelope,
  type BrowserCommandPublicationEvent,
  type BrowserCommandProjectionFoldState,
  type BrowserCommandProjectionState,
  type BrowserCommandResultEvent,
} from "./browser-command-protocol.ts";

/** The one durable event type emitted by the red-alert tool surface. */
export const RED_ALERT_EVENT = "red-alert/state" as const;
/** The client projection key paired with {@link RED_ALERT_EVENT}. */
export const RED_ALERT_PROJECTION = "redAlert" as const;

export type RedAlertStateStatus = "empty" | "creating" | "running" | "stopped" | "error";

/** Page capability for the isolated real browser renderer. */
export interface RedAlertRendererDescriptor {
  readonly mode: "loopback";
  readonly enabled: true;
  readonly sourceLabel: string;
  /** Browser-only wait budget for mounting the session adapter; absent in older events. */
  readonly adapterAttachTimeoutMs?: number;
}

/** Historical or headless projection view. Old events may still include a renderer descriptor. */
export interface RedAlertOfflineView {
  readonly mode: "offline";
  readonly realUiAvailable: false;
  /** Optional for replaying pre-import-contract events. */
  readonly resourceArchive?: ResourceArchiveDescriptor;
  readonly renderer?: RedAlertRendererDescriptor;
}

/** Current view when the compatible client is the match authority. */
export interface RedAlertBrowserView {
  readonly mode: "real-browser";
  readonly realUiAvailable: true;
  readonly resourceArchive?: ResourceArchiveDescriptor;
  readonly renderer: RedAlertRendererDescriptor;
}

export type RedAlertView = RedAlertOfflineView | RedAlertBrowserView;

/** Request data retained while an engine is being created. */
export interface RedAlertCreatingRequest {
  readonly map: string;
  readonly myCountry: string;
  readonly opponents: number;
  readonly opponentType: "noop" | "supalosa" | "normal";
  /** Optional while replaying events written before configurable game speed. */
  readonly gameSpeed?: number;
  readonly decisionPeriod: number;
  readonly maxTicks: number;
}

/** Fair match data shown by both the host projection and the browser page. */
export type RedAlertMatch = Omit<MatchView, "replayPath" | "view"> & {
  readonly view: RedAlertView;
} & Partial<RedAlertMatchIdentity>;

/** Identity needed to bind the browser renderer to the owning DSH session. */
export interface RedAlertMatchIdentity {
  readonly sessionId: string;
  readonly seat: string;
}

/** Stable identity published before the browser starts the real match. */
export interface RedAlertCreatingIdentity extends RedAlertMatchIdentity {
  readonly matchId: string;
  readonly tick: 0;
}

/** Recoverable tool failure metadata; it carries no engine-only fields. */
export interface RedAlertFailure {
  readonly phase: "creating" | "running" | "stopping" | "reading";
  readonly code: string;
  readonly message: string;
  readonly recoverable: boolean;
}

/** Whole post-operation state written to the session event log. */
export interface RedAlertState {
  readonly status: RedAlertStateStatus;
  readonly view: RedAlertView;
  readonly request?: RedAlertCreatingRequest;
  readonly identity?: RedAlertCreatingIdentity;
  readonly match?: RedAlertMatch;
  readonly failure?: RedAlertFailure;
}

declare module "@deepseek-ai/dsh-session" {
  interface SessionEventMap {
    /** Complete post-operation fair red-alert state; event.seq supplies ordering. */
    "red-alert/state": RedAlertState;
  }
}

declare module "@deepseek-ai/dsh-session/types" {
  interface SessionEventMap {
    /** Complete red-alert state; event.seq remains envelope-only. */
    "red-alert/state": RedAlertState;
  }
}

declare module "@deepseek-ai/dsh-session-projection/types" {
  interface SessionProjectionMap {
    /** Whole current red-alert state for the current DSH session. */
    redAlert: RedAlertState;
  }
  interface SessionProjectionStateMap {
    /** Whole current red-alert fold state for the current DSH session. */
    redAlert: RedAlertState;
  }
}

const resourceArchiveSchema = zod.strictObject({
  id: zod.string().min(1),
  url: zod.string().url(),
  byteLength: zod.number().int().positive(),
  sha256: zod.string().regex(/^[a-f0-9]{64}$/),
  version: zod.string().min(1),
  sourceLabel: zod.string().min(1),
  licenseNotice: zod.string().min(1),
});

const rendererDescriptorSchema = zod.strictObject({
  mode: zod.literal("loopback"),
  enabled: zod.literal(true),
  sourceLabel: zod.string().min(1),
  adapterAttachTimeoutMs: zod.number().int().positive().optional(),
});

const viewSchema = zod.discriminatedUnion("mode", [
  zod.strictObject({
    mode: zod.literal("offline"),
    realUiAvailable: zod.literal(false),
    resourceArchive: resourceArchiveSchema.optional(),
    renderer: rendererDescriptorSchema.optional(),
  }),
  zod.strictObject({
    mode: zod.literal("real-browser"),
    realUiAvailable: zod.literal(true),
    resourceArchive: resourceArchiveSchema.optional(),
    renderer: rendererDescriptorSchema,
  }),
]);

const mapSizeSchema = zod.strictObject({
  width: zod.number().positive(),
  height: zod.number().positive(),
});

const contactSchema = zod.strictObject({
  id: zod.number().int(),
  unitType: zod.string(),
  label: zod.string(),
  kind: zod.string(),
  position: zod.strictObject({ x: zod.number(), y: zod.number() }),
  hpPct: zod.number(),
  observedAtTick: zod.number().int(),
  source: zod.enum(["visible", "last-seen"]),
});

const observationSchema = zod.strictObject({
  tick: zod.number().int(),
  ownUnits: zod.array(contactSchema),
  visibleEnemies: zod.array(contactSchema),
  lastSeenEnemies: zod.array(contactSchema),
  visibleNeutralObjects: zod.array(contactSchema),
});

const powerSchema = zod.strictObject({
  total: zod.number(),
  drain: zod.number(),
  isLowPower: zod.boolean(),
});

const factsSchema = zod.strictObject({
  gameTimeSec: zod.number(),
  phase: zod.enum(["early", "mid", "late"]),
  self: zod.strictObject({
    credits: zod.number(),
    power: powerSchema,
    defeated: zod.boolean(),
  }),
  visibleEnemyGroups: zod.number().int().nonnegative(),
  lastSeenEnemyGroups: zod.number().int().nonnegative(),
  visibleNeutralGroups: zod.number().int().nonnegative(),
});

const receiptSchema = zod.strictObject({
  ok: zod.boolean(),
  order: zod.strictObject({
    action: zod.enum(["build", "train", "cancel", "move", "attackMove", "attackTarget", "retreat", "deploy"]),
  }).passthrough(),
  detail: zod.string(),
}) as unknown as zod.ZodType<Receipt>;

const matchSchema = zod.strictObject({
  matchId: zod.string().min(1),
  sessionId: zod.string().min(1).optional(),
  seat: zod.string().min(1).optional(),
  map: zod.string().min(1),
  mapSize: mapSizeSchema,
  myCountry: zod.string().min(1),
  status: zod.enum(["active", "finished", "stopped"]),
  tick: zod.number().int().nonnegative(),
  cycle: zod.number().int().nonnegative(),
  view: viewSchema,
  observation: observationSchema,
  facts: factsSchema,
  receipts: zod.array(receiptSchema),
  placements: zod.array(zod.string()),
  replaySaved: zod.boolean(),
});

const requestSchema = zod.strictObject({
  map: zod.string().min(1),
  myCountry: zod.string().min(1),
  opponents: zod.number().int().positive(),
  opponentType: zod.enum(["noop", "supalosa", "normal"]),
  gameSpeed: zod.number().int().min(0).max(6).optional(),
  decisionPeriod: zod.number().int().positive(),
  maxTicks: zod.number().int().positive(),
});

const creatingIdentitySchema = zod.strictObject({
  matchId: zod.string().min(1),
  sessionId: zod.string().min(1),
  seat: zod.string().min(1),
  tick: zod.literal(0),
});

const failureSchema = zod.strictObject({
  phase: zod.enum(["creating", "running", "stopping", "reading"]),
  code: zod.string().min(1),
  message: zod.string().min(1),
  recoverable: zod.boolean(),
});

const browserOrderSchema = zod.strictObject({
  action: zod.enum(["build", "train", "cancel", "move", "attackMove", "attackTarget", "retreat", "deploy"]),
  target: zod.string().optional(),
  qty: zod.number().int().positive().optional(),
  units: zod.string().optional(),
  x: zod.number().int().optional(),
  y: zod.number().int().optional(),
  contact: zod.string().optional(),
  reason: zod.string().max(512).optional(),
});

const browserCommandIdentitySchema = {
  protocolVersion: zod.literal(1),
  requestId: zod.string().min(1),
  sessionId: zod.string().min(1),
  matchId: zod.string().min(1),
  seat: zod.string().min(1),
  expectedTick: zod.number().int().nonnegative(),
};

const browserGameToolRequestSchema = zod.discriminatedUnion("tool", [
  zod.strictObject({ tool: zod.literal("red_alert_lobby_map") }),
  zod.strictObject({ tool: zod.literal("red_alert_lobby_players") }),
  zod.strictObject({ tool: zod.literal("red_alert_observe") }),
  zod.strictObject({ tool: zod.literal("red_alert_rules") }),
  zod.strictObject({ tool: zod.literal("red_alert_production_catalog") }),
  zod.strictObject({ tool: zod.literal("red_alert_production_status") }),
  zod.strictObject({ tool: zod.literal("red_alert_construction_catalog") }),
  zod.strictObject({ tool: zod.literal("red_alert_map"), x: zod.number().int().optional(), y: zod.number().int().optional(), width: zod.number().int().positive().optional(), height: zod.number().int().positive().optional() }),
  zod.strictObject({ tool: zod.literal("red_alert_resources"), x: zod.number().int(), y: zod.number().int(), width: zod.number().int().positive(), height: zod.number().int().positive() }),
  zod.strictObject({ tool: zod.literal("red_alert_production"), operation: zod.enum(["queue", "cancel", "pause", "resume"]), queueType: zod.number().int().min(0).max(5), name: zod.string().min(1).optional(), quantity: zod.number().int().min(1).max(99).optional() }),
  zod.strictObject({ tool: zod.literal("red_alert_construction"), operation: zod.enum(["place", "sell", "repair"]), name: zod.string().min(1).optional(), objectId: zod.number().int().nonnegative().optional(), x: zod.number().int().optional(), y: zod.number().int().optional() }),
  zod.strictObject({ tool: zod.literal("red_alert_diplomacy"), player: zod.string().min(1).optional(), allied: zod.boolean().optional() }),
  zod.strictObject({ tool: zod.literal("red_alert_superweapons"), type: zod.number().int().optional(), x: zod.number().int().optional(), y: zod.number().int().optional(), x2: zod.number().int().optional(), y2: zod.number().int().optional() }),
]);

const browserCommandSchema = zod.discriminatedUnion("kind", [
  zod.strictObject({ ...browserCommandIdentitySchema, kind: zod.literal("create-match"), request: zod.strictObject({
    map: zod.string().min(1).optional(),
    myCountry: zod.string().min(1),
    opponents: zod.number().int().min(1).max(7),
    opponentType: zod.enum(["noop", "normal"]),
    gameSpeed: zod.number().int().min(0).max(6).optional(),
  }) }),
  zod.strictObject({ ...browserCommandIdentitySchema, kind: zod.literal("orders"), orders: zod.array(browserOrderSchema) }),
  zod.strictObject({ ...browserCommandIdentitySchema, kind: zod.literal("tool"), request: browserGameToolRequestSchema }),
  zod.strictObject({ ...browserCommandIdentitySchema, kind: zod.literal("observe") }),
  zod.strictObject({ ...browserCommandIdentitySchema, kind: zod.literal("stop-match") }),
]);

const browserMatchSnapshotSchema = zod.strictObject({
  map: zod.string().min(1),
  mapSize: mapSizeSchema,
  myCountry: zod.string().min(1),
  status: zod.enum(["active", "finished", "stopped"]),
  self: factsSchema.shape.self,
});

const browserReceiptSchema = zod.strictObject({
  protocolVersion: zod.literal(1),
  requestId: zod.string().min(1),
  sessionId: zod.string().min(1),
  matchId: zod.string().min(1),
  seat: zod.string().min(1),
  tick: zod.number().int().nonnegative(),
  ok: zod.boolean(),
  detail: zod.string().max(512),
  observation: observationSchema.optional(),
  match: browserMatchSnapshotSchema.optional(),
  toolResult: zod.json().optional(),
});

const browserFailureSchema = zod.strictObject({
  code: zod.string().min(1),
  message: zod.string().max(512),
});

const browserCommandProjectionSchema = zod.discriminatedUnion("status", [
  zod.strictObject({ status: zod.literal("idle") }),
  zod.strictObject({ status: zod.literal("pending"), command: browserCommandSchema }),
  zod.strictObject({ status: zod.literal("completed"), command: browserCommandSchema, receipt: browserReceiptSchema }),
  zod.strictObject({ status: zod.literal("failed"), command: browserCommandSchema, failure: browserFailureSchema }),
  zod.strictObject({ status: zod.literal("cancelled"), command: browserCommandSchema, failure: browserFailureSchema }),
]) as unknown as zod.ZodType<BrowserCommandProjectionState>;

const browserCommandResultEventSchema = zod.discriminatedUnion("status", [
  zod.strictObject({
    protocolVersion: zod.literal(1),
    requestId: zod.string().min(1),
    sessionId: zod.string().min(1),
    matchId: zod.string().min(1),
    seat: zod.string().min(1),
    command: browserCommandSchema,
    status: zod.literal("completed"),
    receipt: browserReceiptSchema,
  }),
  zod.strictObject({
    protocolVersion: zod.literal(1),
    requestId: zod.string().min(1),
    sessionId: zod.string().min(1),
    matchId: zod.string().min(1),
    seat: zod.string().min(1),
    command: browserCommandSchema,
    status: zod.enum(["failed", "cancelled"]),
    failure: browserFailureSchema,
  }),
]) as unknown as zod.ZodType<BrowserCommandResultEvent>;

const browserCommandProjectionFoldSchema = zod.strictObject({
  visible: browserCommandProjectionSchema,
  admitted: browserCommandSchema.optional(),
  admittedResult: browserCommandResultEventSchema.optional(),
}) as unknown as zod.ZodType<BrowserCommandProjectionFoldState>;

/** Runtime schema used at the host-to-client projection boundary. */
export const redAlertProjectionSchema = zod.discriminatedUnion("status", [
  zod.strictObject({ status: zod.literal("empty"), view: viewSchema }),
  zod.strictObject({ status: zod.literal("creating"), view: viewSchema, request: requestSchema, identity: creatingIdentitySchema }),
  zod.strictObject({ status: zod.literal("running"), view: viewSchema, match: matchSchema }),
  zod.strictObject({ status: zod.literal("stopped"), view: viewSchema, match: matchSchema }),
  zod.strictObject({
    status: zod.literal("error"),
    view: viewSchema,
    identity: creatingIdentitySchema.optional(),
    match: matchSchema.optional(),
    request: requestSchema.optional(),
    failure: failureSchema,
  }),
]) as unknown as zod.ZodType<RedAlertState>;

/** Build truthful page metadata for the active match authority. */
function redAlertView(
  resourceArchive: ResourceArchiveDescriptor = DEFAULT_RESOURCE_ARCHIVE,
  renderer?: RedAlertRendererDescriptor,
): RedAlertView {
  if (renderer !== undefined) return { mode: "real-browser", realUiAvailable: true, resourceArchive, renderer };
  return { mode: "offline", realUiAvailable: false, resourceArchive };
}

/** Return the empty projection value for a new or projection-less session. */
export function emptyRedAlertState(
  resourceArchive: ResourceArchiveDescriptor = DEFAULT_RESOURCE_ARCHIVE,
  renderer?: RedAlertRendererDescriptor,
): RedAlertState {
  return { status: "empty", view: redAlertView(resourceArchive, renderer) };
}

/** Convert a controller view into the browser-safe whole match value. */
export function redAlertMatch(
  view: MatchView | RedAlertMatch,
  identity?: RedAlertMatchIdentity,
  projectedView?: RedAlertView,
): RedAlertMatch {
  const { replayPath: _replayPath, advanced: _advanced, ...match } = view as MatchView & { readonly advanced?: boolean };
  const result = { ...match, view: projectedView ?? view.view } as RedAlertMatch;
  return identity === undefined ? result : { ...result, ...identity };
}

/** Convert a completed controller operation into its lifecycle projection. */
export function stateFromMatch(
  view: MatchView,
  identity?: RedAlertMatchIdentity,
  resourceArchive: ResourceArchiveDescriptor = DEFAULT_RESOURCE_ARCHIVE,
  renderer?: RedAlertRendererDescriptor,
): RedAlertState {
  const projectionView = redAlertView(resourceArchive, renderer);
  return {
    status: view.status === "active" ? "running" : "stopped",
    view: projectionView,
    match: redAlertMatch(view, identity, renderer === undefined ? undefined : projectionView),
  };
}

/** Build a durable creating state before the engine is touched. */
export function creatingState(
  request: RedAlertCreatingRequest,
  identity: RedAlertCreatingIdentity,
  resourceArchive: ResourceArchiveDescriptor = DEFAULT_RESOURCE_ARCHIVE,
  renderer?: RedAlertRendererDescriptor,
): RedAlertState {
  return { status: "creating", view: redAlertView(resourceArchive, renderer), request, identity };
}

/** Convert an arbitrary thrown value into a bounded user-visible failure. */
export function failureState(
  phase: RedAlertFailure["phase"],
  error: unknown,
  match?: MatchView | RedAlertMatch,
  request?: RedAlertCreatingRequest,
  identity?: RedAlertMatchIdentity,
  resourceArchive: ResourceArchiveDescriptor = DEFAULT_RESOURCE_ARCHIVE,
  renderer?: RedAlertRendererDescriptor,
): RedAlertState {
  const code = error instanceof Error && "code" in error && typeof error.code === "string" ? error.code : "RED_ALERT_OPERATION";
  const message = error instanceof Error ? error.message : String(error);
  const projectionView = redAlertView(resourceArchive, renderer);
  return {
    status: "error",
    view: projectionView,
    ...(request === undefined ? {} : { request }),
    ...(match === undefined && identity !== undefined ? { identity: identity as RedAlertCreatingIdentity } : {}),
    ...(match === undefined ? {} : { match: redAlertMatch(match, identity, renderer === undefined ? undefined : projectionView) }),
    failure: { phase, code, message: message.slice(0, 240), recoverable: true },
  };
}

/** Pure session-event fold used by the host registry and keyless tests. */
export function applyRedAlertProjection(state: RedAlertState, event: SessionEvent): RedAlertState {
  if (event.type !== RED_ALERT_EVENT) return state;
  return (event as SessionEvent<"red-alert/state">).data;
}

/** Official DSH projection definition for the `redAlert` client key. */
export const redAlertProjection = {
  key: RED_ALERT_PROJECTION,
  stateSchema: redAlertProjectionSchema,
  init: emptyRedAlertState,
  apply: applyRedAlertProjection,
  wire: {
    viewSchema: redAlertProjectionSchema,
    view: state => state,
  },
  stateVersion: 1,
} satisfies ProjectionDefinition<"redAlert", RedAlertState>;

/** Empty browser command fold; admitted command data stays hidden until its marker. */
export function emptyBrowserCommandProjection(): BrowserCommandProjectionFoldState {
  return { visible: { status: "idle" } };
}

function samePublication(command: BrowserCommandEnvelope, publication: BrowserCommandPublicationEvent): boolean {
  return command.protocolVersion === publication.protocolVersion
    && command.requestId === publication.requestId
    && command.sessionId === publication.sessionId
    && command.matchId === publication.matchId
    && command.seat === publication.seat
    && command.expectedTick === publication.expectedTick;
}

function sameResultPublication(
  result: BrowserCommandResultEvent,
  publication: ReturnType<typeof decodeBrowserCommandResultPublicationEvent>,
): boolean {
  return result.protocolVersion === publication.protocolVersion
    && result.requestId === publication.requestId
    && result.sessionId === publication.sessionId
    && result.matchId === publication.matchId
    && result.seat === publication.seat
    && result.status === publication.status;
}

function commandOfVisibleState(state: BrowserCommandProjectionState): BrowserCommandEnvelope | undefined {
  return state.status === "idle" ? undefined : state.command;
}

/** Pure fold for the Host-to-browser command projection. Malformed history fails closed. */
export function applyBrowserCommandProjection(state: BrowserCommandProjectionFoldState, event: SessionEvent): BrowserCommandProjectionFoldState {
  if (event.type === RED_ALERT_BROWSER_COMMAND_EVENT) {
    try {
      return { visible: state.visible, admitted: decodeBrowserCommandEvent(event.data) };
    } catch {
      return state;
    }
  }
  if (event.type === RED_ALERT_BROWSER_COMMAND_PUBLISHED_EVENT) {
    try {
      const publication = decodeBrowserCommandPublicationEvent(event.data);
      if (state.admitted === undefined || !samePublication(state.admitted, publication)) return state;
      return { visible: { status: "pending", command: state.admitted }, admitted: state.admitted };
    } catch {
      return state;
    }
  }
  if (event.type === RED_ALERT_BROWSER_COMMAND_RESULT_EVENT) {
    try {
      const result = decodeBrowserCommandResult(event.data);
      const expected = state.admitted ?? commandOfVisibleState(state.visible);
      if (expected === undefined || state.visible.status !== "pending" || !samePublication(expected, result.command)) return state;
      return { ...state, admittedResult: result };
    } catch {
      return state;
    }
  }
  if (event.type === RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT) {
    try {
      const publication = decodeBrowserCommandResultPublicationEvent(event.data);
      const result = state.admittedResult;
      if (result === undefined || state.visible.status !== "pending" || !sameResultPublication(result, publication)) return state;
      if (!samePublication(state.visible.command, result.command)) return state;
      return { visible: projectBrowserCommandResult(result) };
    } catch {
      return state;
    }
  }
  return state;
}

/** Official DSH projection definition consumed by the client command root. */
export const redAlertCommandProjection = {
  key: RED_ALERT_BROWSER_COMMAND_PROJECTION,
  stateSchema: browserCommandProjectionFoldSchema,
  init: emptyBrowserCommandProjection,
  apply: applyBrowserCommandProjection,
  wire: {
    viewSchema: browserCommandProjectionSchema,
    view: state => state.visible,
  },
  stateVersion: 3,
} satisfies ProjectionDefinition<typeof RED_ALERT_BROWSER_COMMAND_PROJECTION, BrowserCommandProjectionFoldState>;

/** Keep the imported types visible to declaration emit without a second wire shape. */
export type { FogSafeContact, FogSafeObservation, Receipt };
