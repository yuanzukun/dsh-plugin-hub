import type { BrowserCommandReceipt } from "./browser-command-protocol.ts";

/** Maximum contacts retained in each compact model-facing command collection. */
export const MAX_COMMAND_VIEW_CONTACTS = 128;

function compactContacts(contacts: NonNullable<BrowserCommandReceipt["observation"]>["ownUnits"]): {
  readonly total: number;
  readonly truncated: boolean;
  readonly contacts: readonly {
    readonly id: number;
    readonly type: string;
    readonly kind: string;
    readonly x: number;
    readonly y: number;
    readonly hpPct: number;
    readonly observedAtTick: number;
  }[];
} {
  return {
    total: contacts.length,
    truncated: contacts.length > MAX_COMMAND_VIEW_CONTACTS,
    contacts: contacts.slice(0, MAX_COMMAND_VIEW_CONTACTS).map(contact => ({
      id: contact.id,
      type: contact.unitType,
      kind: contact.kind,
      x: contact.position.x,
      y: contact.position.y,
      hpPct: contact.hpPct,
      observedAtTick: contact.observedAtTick,
    })),
  };
}

/** Build the compact fair state attached to exact browser tool results. */
export function compactCommandView(receipt: BrowserCommandReceipt): Record<string, unknown> | undefined {
  if (receipt.observation === undefined || receipt.match === undefined) return undefined;
  return {
    tick: receipt.tick,
    status: receipt.match.status,
    self: receipt.match.self,
    own: compactContacts(receipt.observation.ownUnits),
    visibleEnemies: compactContacts(receipt.observation.visibleEnemies),
    lastSeenEnemies: compactContacts(receipt.observation.lastSeenEnemies),
  };
}
