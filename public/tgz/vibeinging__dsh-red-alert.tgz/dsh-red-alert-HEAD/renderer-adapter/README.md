# Compatible renderer adapter

This directory contains the source patch used to turn the pinned GPLv3-compatible Red Alert 2 Web client into the DSH renderer companion.

- Upstream: `https://github.com/huangkaoya/redalert2.git`
- Pinned commit: `8c07f1092b2a9e8d8605ed49ef46d77b6c3ea367`
- Patch license: `GPL-3.0-only`, matching the upstream `LICENSE`
- Game assets: not included; renderer preparation never downloads them

Run `pnpm prepare:renderer -- /absolute/output/directory`. The command clones the pinned source into a new directory, checks the exact commit, applies `patches/redalert2-8c07f109.patch.gz.base64` and `patches/redalert2-auto-local-resource.patch`, runs the companion test, and builds `dist/`. It invokes exact `bun@1.3.14` through `pnpm dlx`, so users do not install global Bun. It refuses to reuse or overwrite an existing destination. The compressed artifact is only a gzip-base64 representation of a normal Git patch; decode it with `base64 --decode | gzip --decompress` when reviewing it manually. The second patch is plain text and restricts automatic first import to the fixed same-origin setup archive.

After the build, run `dsh-red-alert-setup --download-resources` to print the declared third-party source and rights notice, verify the pinned size and SHA-256, and save the archive locally for automatic first import. Omitting the flag keeps the real client's visible local-archive selector. Manual integrations may configure `rendererDistDir` directly. The plugin package, repository, and renderer-preparation command do not copy, publish, or embed the archive.
