import { defineConfig } from 'tsdown'

/** Build the node runtime, invariant companion, and DSH browser client face. */
export default defineConfig([
  {
    entry: ['lib/types/src/index.js'],
    outDir: 'lib',
    format: ['esm'],
    platform: 'node',
    target: 'es2024',
    fixedExtension: false,
    dts: false,
    clean: false,
  },
  {
    entry: ['lib/types/src/invariant.js'],
    outDir: 'lib',
    format: ['esm'],
    platform: 'node',
    target: 'es2024',
    fixedExtension: false,
    dts: false,
    clean: false,
  },
  {
    entry: { client: "src/client/index.tsx" },
    outDir: "lib",
    format: ["cjs"],
    platform: "browser",
    target: "es2020",
    fixedExtension: false,
    dts: false,
    sourcemap: true,
    clean: false,
    external: ["react", "react/jsx-runtime"],
    outputOptions: {
      entryFileNames: "client.cjs",
      banner: "window.__ModuleLoader__.load({ id: \"@vibeinging/dsh-red-alert\", factory: (platformRequire) => {",
      footer: "return module.exports; } });",
      intro: "var module = { exports: {} }; var exports = module.exports; const require = (specifier) => platformRequire(specifier === \"@deepseek-ai/cordis\" ? \"cordis\" : specifier);",
    },
  },
])
