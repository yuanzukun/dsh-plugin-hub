/**
 * 单位字典层：rules.ini 内部名 → LLM 可读语义。
 * 语义标注基于 rules.ini 属性核对（cost/strength/speed/prereq），非记忆臆测。
 */
export interface LexEntry {
    name: string;
    label: string;
    kind: "building" | "infantry" | "vehicle" | "aircraft" | "neutral";
    cost: number;
    note?: string;
}
export declare const LEXICON: Map<string, LexEntry>;
/** 注入 prompt 的紧凑字典文本 */
export declare function lexiconText(): string;
