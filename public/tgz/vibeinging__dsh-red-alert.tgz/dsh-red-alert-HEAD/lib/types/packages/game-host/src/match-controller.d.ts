import { FogSafeObservation } from "./fog-safe-observation.js";
import { Receipt } from "./orders.js";
import { Snapshot } from "./snapshot.js";
/** Identity carried by a DSH tool call and checked as a pair. */
export interface MatchOwner {
    readonly agentId: string;
    readonly sessionId: string;
}
/** User-selectable offline engine settings. */
export interface StartMatchRequest {
    readonly map: string;
    readonly myCountry: string;
    readonly opponents: number;
    readonly opponentType: "noop" | "supalosa";
    readonly decisionPeriod: number;
    readonly maxTicks: number;
}
/** Product-safe result returned by every match operation. */
export interface MatchView {
    readonly matchId: string;
    readonly map: string;
    readonly mapSize: {
        readonly width: number;
        readonly height: number;
    };
    readonly myCountry: string;
    readonly status: "active" | "finished" | "stopped";
    readonly tick: number;
    readonly cycle: number;
    readonly view: {
        readonly mode: "offline";
        readonly realUiAvailable: false;
    };
    readonly observation: FogSafeObservation;
    readonly facts: {
        readonly gameTimeSec: number;
        readonly phase: Snapshot["phase"];
        readonly self: Snapshot["self"];
        readonly visibleEnemyGroups: number;
        readonly lastSeenEnemyGroups: number;
        readonly visibleNeutralGroups: number;
    };
    readonly receipts: readonly Receipt[];
    readonly placements: readonly string[];
    readonly replaySaved: boolean;
    readonly replayPath?: string;
}
/** Result of applying a command batch and moving to the next decision point. */
export interface ActMatchResult extends MatchView {
    readonly advanced: true;
}
/** A failed match request is safe to expose to the tool result. */
export declare class MatchControllerError extends Error {
    readonly code = "RED_ALERT_MATCH";
}
/**
 * Owns the offline engine lifecycle for DSH sessions.
 *
 * The controller deliberately receives only an owner identity from the DSH
 * adapter. It never treats a match id as an authorization token.
 */
export declare class MatchController {
    private readonly assetsDir;
    private readonly records;
    private readonly activeBySession;
    private readonly sessionTails;
    private disposed;
    constructor(assetsDir: string);
    /** Start one offline match and advance it to its first fair observation. */
    start(owner: MatchOwner, request: StartMatchRequest, signal: AbortSignal): Promise<MatchView>;
    /** Apply commands, then advance exactly one bounded decision window. */
    act(owner: MatchOwner, matchId: string, orders: readonly unknown[], signal: AbortSignal): Promise<ActMatchResult>;
    /** Return the last committed observation without advancing the engine. */
    status(owner: MatchOwner, matchId: string, signal: AbortSignal): Promise<MatchView>;
    /** Save and close one match; a repeated stop is intentionally idempotent. */
    stop(owner: MatchOwner, matchId: string, signal: AbortSignal): Promise<MatchView>;
    /** Stop all matches owned by one exact Agent/session pair after prior session work settles. */
    stopOwner(owner: MatchOwner): Promise<void>;
    /** Stop every owned match before the plugin fiber is released, preserving cleanup failures. */
    dispose(): Promise<void>;
    /** Snapshot the owned relationships for the package invariant companion. */
    assertInvariants(fail: (message: string) => never): void;
    /** Validate the exact fair observation materialized in a successful tool result. */
    assertToolOutput(value: unknown, fail: (message: string) => never): void;
    private resolveRequest;
    private createOpponents;
    private advanceGame;
    private advanceRecord;
    private refresh;
    private currentApi;
    private updateFinishedState;
    private requireOwned;
    private closeRecord;
    private assertFairOutput;
    private assertFairObservation;
    private serialize;
    private view;
}
