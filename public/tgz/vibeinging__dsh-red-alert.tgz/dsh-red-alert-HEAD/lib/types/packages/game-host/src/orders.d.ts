import { GameApi } from "@chronodivide/game-api";
/**
 * 指令翻译器：LLM 高层 JSON 指令 → 引擎调用。
 *
 * 引擎约束（实测）：每个生产队列同一时刻只接受一项，生产中再排队会被静默吞掉。
 * 因此桥维护 pending 缓冲：build/train 指令先进缓冲，pumpQueues() 按引擎节奏逐项消费。
 * 单位指令以"单位类型"为编队（v1），LLM 不接触裸 unit id。
 */
export type Order = {
    action: "build";
    target: string;
    reason?: string;
} | {
    action: "train";
    target: string;
    qty: number;
    reason?: string;
} | {
    action: "cancel";
    target: string;
    qty: number;
    reason?: string;
} | {
    action: "attackMove";
    units: string;
    x: number;
    y: number;
    reason?: string;
} | {
    action: "move";
    units: string;
    x: number;
    y: number;
    reason?: string;
} | {
    action: "attackTarget";
    units: string;
    contact: string;
    reason?: string;
} | {
    action: "retreat";
    units: string;
    reason?: string;
} | {
    action: "deploy";
    units: string;
    reason?: string;
};
export interface Receipt {
    ok: boolean;
    order: Order;
    detail: string;
}
/** 注入 prompt 的指令协议文本 */
export declare function orderProtocolText(): string;
export declare class OrderTranslator {
    private selfName;
    private actions;
    private production;
    private pendingBuilds;
    private pendingUnits;
    constructor(selfName: string, actions: any, // ActionsApi
    production: any);
    /** Production API used by the fair snapshot builder without exposing queues. */
    productionApi(): any;
    /** LLM 可见的 pending 状态（进快照） */
    pendingSummary(): {
        builds: string[];
        units: {
            queue: string;
            name: string;
            qty: number;
        }[];
    };
    /** 基础执行器：MCV 展开 + Ready 建筑放置 + pending 消费（每 15 tick 调用） */
    pumpQueues(game: GameApi): string[];
    /** 引擎侧可用性预检：prereq 不满足时 queueForProduction 会被静默吞掉 */
    private isAvailableNow;
    private queueData;
    /** 空闲 MCV 自动展开（没有基地一切排队都会被静默吞掉） */
    private ensureMcvDeployed;
    /** 从基地质心螺旋向外找合法放置位 */
    private findPlacement;
    private baseCenter;
    applyOrders(game: GameApi, orders: unknown[]): Receipt[];
    private applyOne;
    private unitIdsByType;
    private queueTypeFor;
    private objectTypeFor;
}
