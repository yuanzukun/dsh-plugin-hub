import { GameApi } from "@chronodivide/game-api";
import { FogSafeObservation, ObservationSource } from "./fog-safe-observation.js";
/** 聚合层快照：LLM 指挥官每决策周期看到的视图（schema v1 聚合层实现） */
export interface GroupInfo {
    unitType: string;
    label: string;
    count: number;
    avgHpPct: number;
    centroid: {
        x: number;
        y: number;
    };
    totalValue: number;
    ids: number[];
}
export interface ContactGroup {
    unitType: string;
    label: string;
    count: number;
    avgHpPct: number;
    centroid: {
        x: number;
        y: number;
    };
    ids: number[];
    source: ObservationSource;
    observedAtTick: number;
}
export interface Snapshot {
    tick: number;
    gameTimeSec: number;
    phase: "early" | "mid" | "late";
    self: {
        credits: number;
        power: {
            total: number;
            drain: number;
            isLowPower: boolean;
        };
        defeated: boolean;
    };
    buildings: {
        unitType: string;
        label: string;
        count: number;
        hpPct: number;
    }[];
    ownCombatGroups: GroupInfo[];
    economy: {
        harvesters: number;
        harvesterIdleHint: number;
        refineries: number;
    };
    enemyContacts: ContactGroup[];
    lastSeenEnemyContacts: ContactGroup[];
    visibleNeutralObjects: ContactGroup[];
    production: Record<string, {
        status: string;
        items: {
            name: string;
            qty: number;
        }[];
    }>;
    pending: {
        builds: string[];
        units: string[];
    };
    events: string[];
}
export declare function buildSnapshot(game: GameApi, selfName: string, production: any, prevIds: Set<number>, prevEnemyTypes: Set<string>, pending: {
    builds: string[];
    units: {
        queue: string;
        name: string;
        qty: number;
    }[];
} | undefined, observation: FogSafeObservation): Snapshot;
/** 快照 → LLM prompt 紧凑文本（不含 ids，指挥官不操作裸 id）。 */
export declare function snapshotText(s: Snapshot): string;
