import { Bot, GameApi, ApiEvent } from "@chronodivide/game-api";
/**
 * LLM 指挥官的 bot 壳：本身不做决策（决策在 host 主循环的 update 间隙），
 * 只负责捕获 GameApi 引用与雷达事件缓冲。
 */
export declare class LLMCommanderBot extends Bot {
    lastGameApi: GameApi | null;
    radarEvents: string[];
    constructor(name: string, country: string);
    onGameTick(game: GameApi): void;
    onGameEvent(ev: ApiEvent, game: GameApi): void;
    /** 0.75 无公开 context getter，经 any 取 BotContext { game, player, logger } */
    playerApi(): any | null;
}
