import { UnitData } from "@chronodivide/game-api";
export type ObservationSource = "visible" | "last-seen";
export interface FogObservationApi {
    getCurrentTick(): number;
    getVisibleUnits(playerName: string, type: "self" | "hostile" | "enemy"): number[];
    getUnitData(unitId: number): UnitData | undefined;
}
export interface FogSafeContact {
    id: number;
    unitType: string;
    label: string;
    kind: string;
    position: {
        x: number;
        y: number;
    };
    hpPct: number;
    observedAtTick: number;
    source: ObservationSource;
}
export interface FogSafeObservation {
    tick: number;
    ownUnits: FogSafeContact[];
    visibleEnemies: FogSafeContact[];
    lastSeenEnemies: FogSafeContact[];
    visibleNeutralObjects: FogSafeContact[];
}
export declare class FogSafetyError extends Error {
    constructor(message: string);
}
/**
 * Projects the current player's visible units, enemies, and neutral objects,
 * and retains enemy contacts without refreshing them while they are hidden.
 */
export declare class FogSafeProjector {
    private readonly lastSeen;
    project(game: FogObservationApi, selfName: string): FogSafeObservation;
}
/**
 * Runs a product operation only after the fog projection and its subset check
 * succeed. A projection failure rejects before the callback can run.
 */
export declare function withFogSafeObservation<T>(projector: FogSafeProjector, game: FogObservationApi, selfName: string, operation: (observation: FogSafeObservation) => T | Promise<T>): Promise<{
    observation: FogSafeObservation;
    result: T;
}>;
