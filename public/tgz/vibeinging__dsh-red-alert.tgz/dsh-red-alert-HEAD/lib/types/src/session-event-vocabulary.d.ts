export { RED_ALERT_SESSION_EVENT_TYPES } from "./session-event-types.ts";
/**
 * Register the plugin's durable vocabulary with the exact DSH host runtime.
 *
 * DSH 0.1.1-rc.2 exports the persistence vocabulary as a read-only type but
 * does not yet expose an external-plugin registration service. Its concrete
 * runtime value is an extensible Set. The plugin resolves the host's own
 * dsh-session instance through @deepseek-ai/dsh instead of mutating the SDK
 * copy bundled into this package. Failure is load-time and loud so a session
 * is never written that the same installed host cannot restore.
 */
export declare function registerHostSessionEventVocabulary(): Promise<void>;
