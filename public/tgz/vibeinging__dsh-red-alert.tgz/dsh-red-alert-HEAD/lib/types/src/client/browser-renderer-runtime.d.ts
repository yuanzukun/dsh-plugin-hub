import { type BrowserCommandEnvelope, type BrowserCommandReceipt } from "../browser-command-protocol.ts";
import { type RendererBridgeState, type RendererIdentity } from "./renderer-bridge.ts";
import { type CompanionOriginOptions } from "./companion-origin.ts";
import type { BrowserAdapterRegistry, BrowserMatchAdapter } from "./browser-command-consumer.ts";
/** Runtime identity used for the renderer and the Host command envelope. */
export type BrowserRendererIdentity = RendererIdentity;
/** Public loopback endpoint metadata; it exposes no renderer or engine state. */
export interface BrowserRendererEndpoint {
    readonly url: string;
    readonly port: number;
}
/** Adapter extension owned by the client root; it never owns the DSH tab. */
export interface BrowserRendererAdapter extends BrowserMatchAdapter {
    /** Endpoint metadata used to reuse a root-owned adapter after view remount. */
    readonly endpoint?: BrowserRendererEndpoint;
    readonly state?: BrowserRendererState;
    /** Test whether this adapter is already bound to the exact live match identity. */
    matchesIdentity?(identity: BrowserRendererIdentity): boolean;
    /** Subscribe to live adapter state; the disposer must remove the listener. */
    subscribeState?(listener: (state: BrowserRendererState) => void): () => void;
    attachRenderer(container: HTMLElement, identity: BrowserRendererIdentity): Promise<void>;
    detachRenderer(container: HTMLElement): Promise<void>;
    dispose(): Promise<void>;
}
export type BrowserRendererState = RendererBridgeState | "unavailable";
/** Stable client-side error for an unavailable or invalid renderer. */
export declare class BrowserRendererError extends Error {
    readonly code: "CONFIG" | "IDENTITY" | "NOT_ATTACHED" | "DISPOSED" | "LOAD_FAILED" | "STALE_TICK";
    constructor(code: "CONFIG" | "IDENTITY" | "NOT_ATTACHED" | "DISPOSED" | "LOAD_FAILED" | "STALE_TICK", message: string);
}
/**
 * Adapter for a user-provided real client served by the plugin-owned loopback
 * server. The iframe stays in a root-owned connected host; the view only
 * changes that host's position and visibility.
 */
export declare class LoopbackRendererAdapter implements BrowserRendererAdapter {
    readonly endpoint: BrowserRendererEndpoint;
    private readonly parent;
    private readonly url;
    private readonly loadTimeoutMs;
    private frame;
    private frameHost;
    private bridge;
    private identity;
    private readonly commandInFlight;
    private readonly completedCommands;
    private readonly commandDrains;
    private readonly stateListeners;
    private latestObservation;
    private attachOperation;
    private attachGeneration;
    private resizeObserver;
    private observedContainer;
    private geometrySync;
    private attachedContainer;
    private disposed;
    private disposePromise;
    private stateValue;
    constructor(options: {
        readonly url: string;
        readonly parentOrigin: string;
        readonly origin?: CompanionOriginOptions;
        readonly parentWindow?: Window;
        readonly loadTimeoutMs?: number;
    });
    get state(): BrowserRendererState;
    matchesIdentity(identity: BrowserRendererIdentity): boolean;
    subscribeState(listener: (state: BrowserRendererState) => void): () => void;
    attachRenderer(container: HTMLElement, identity: BrowserRendererIdentity): Promise<void>;
    /** Hide the fixed host and cancel only unfinished attachment work. */
    detachRenderer(container: HTMLElement): Promise<void>;
    command(command: BrowserCommandEnvelope, signal: AbortSignal): Promise<BrowserCommandReceipt>;
    private waitUntilReady;
    dispose(): Promise<void>;
    private disposeInternal;
    private attachInternal;
    private invalidateAttachment;
    private assertGeneration;
    private ensureFrame;
    private showFrame;
    private startGeometrySync;
    private showFrameGeometry;
    private stopGeometrySync;
    private resetForIdentity;
    private connectWithTimeout;
    private disposeBridge;
    private setState;
    private awaitCommandDrains;
    private waitForLoad;
}
/** Root-owned runtime that keeps adapters alive when React tabs are switched. */
export declare class BrowserRendererRuntime {
    private readonly registry;
    private readonly owned;
    private readonly removalDrains;
    private disposed;
    private disposePromise;
    constructor(registry: BrowserAdapterRegistry);
    register(sessionId: string, adapter: BrowserRendererAdapter): () => Promise<void>;
    registerLoopback(sessionId: string, options: ConstructorParameters<typeof LoopbackRendererAdapter>[0]): {
        readonly adapter: LoopbackRendererAdapter;
        readonly remove: () => Promise<void>;
    };
    get(sessionId: string): BrowserRendererAdapter | undefined;
    /** Read the current renderer lifecycle state without exposing renderer data. */
    getState(sessionId: string): BrowserRendererState;
    /** Read the current adapter endpoint without exposing renderer or engine state. */
    getEndpoint(sessionId: string): BrowserRendererEndpoint | undefined;
    /** Test whether the session adapter is already bound to the exact live match. */
    matchesIdentity(sessionId: string, identity: BrowserRendererIdentity): boolean;
    /** Subscribe to one session's renderer lifecycle; a missing subscription is a no-op. */
    subscribeState(sessionId: string, listener: (state: BrowserRendererState) => void): () => void;
    attach(sessionId: string, container: HTMLElement, identity: BrowserRendererIdentity): Promise<void>;
    detach(sessionId: string, container: HTMLElement): Promise<void>;
    /** Remove one session-owned adapter at the root lifecycle boundary. */
    removeSession(sessionId: string): Promise<void>;
    dispose(): Promise<void>;
    private remove;
    private disposeInternal;
}
