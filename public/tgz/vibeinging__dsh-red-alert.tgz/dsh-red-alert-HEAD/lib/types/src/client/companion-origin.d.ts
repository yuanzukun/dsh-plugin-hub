/** Options for the explicitly configured local companion exception. */
export interface CompanionOriginOptions {
    readonly loopbackPort?: number;
    readonly allowLoopback?: boolean;
}
/** Stable error raised when a companion URL is outside the configured boundary. */
export declare class CompanionOriginError extends Error {
    constructor(message: string);
}
/**
 * Resolve a user-confirmed URL for the plugin-owned companion server. Only an
 * explicit http loopback address with the configured numeric port is accepted.
 * The dedicated loopback host also keeps the real game cross-site from DSH so
 * game-engine work cannot block Chat and live command receipts.
 */
export declare function resolveCompanionUrl(rawUrl: string, parentOrigin: string, options?: CompanionOriginOptions): URL;
/** Return true only for the exact origin/source pair accepted by the bridge. */
export declare function isCompanionMessageOrigin(actualOrigin: string, expectedOrigin: string): boolean;
