import { type BrowserMatchSnapshot, type BrowserGameToolRequest, type BrowserToolValue, type FogSafeObservation } from "../browser-command-protocol.ts";
/** Protocol version for the plugin-owned loopback companion boundary. */
export declare const RENDERER_PROTOCOL_VERSION: 1;
export type RendererBridgeState = "idle" | "connecting" | "ready" | "disconnected" | "error" | "disposed";
export interface RendererIdentity {
    readonly sessionId: string;
    readonly matchId: string;
    readonly seat: string;
    readonly tick: number;
}
/** Minimal message-event surface used by Window and keyless bridge tests. */
export interface RendererMessageEvent {
    readonly origin: string;
    readonly source: unknown;
    readonly data: unknown;
}
/** Same-browser message transport; the caller binds it to one loopback iframe window. */
export interface RendererMessageEndpoint {
    postMessage(message: unknown, targetOrigin: string): void;
    addEventListener(type: "message", listener: (event: RendererMessageEvent) => void): void;
    removeEventListener(type: "message", listener: (event: RendererMessageEvent) => void): void;
}
export type RendererOrderAction = "build" | "train" | "cancel" | "move" | "attackMove" | "attackTarget" | "retreat" | "deploy";
export interface RendererOrder {
    readonly action: RendererOrderAction;
    readonly target?: string;
    readonly qty?: number;
    readonly units?: string;
    readonly x?: number;
    readonly y?: number;
    readonly contact?: string;
    readonly reason?: string;
}
/** Strict commands accepted by the real renderer companion. */
export type RendererCommand = {
    readonly type: "create-match";
    readonly map?: string;
    readonly myCountry: string;
    readonly opponents: number;
    readonly opponentType: "noop" | "normal";
    readonly gameSpeed?: number;
} | {
    readonly type: "orders";
    readonly orders: readonly RendererOrder[];
} | {
    readonly type: "tool";
    readonly request: BrowserGameToolRequest;
} | {
    readonly type: "observe";
} | {
    readonly type: "stop-match";
};
export interface RendererCommandReceipt {
    readonly requestId: string;
    readonly tick: number;
    readonly ok: true;
    readonly detail: string;
    /** The renderer's atomic post-command fair observation, when supplied. */
    readonly observation?: FogSafeObservation;
    readonly match?: BrowserMatchSnapshot;
    readonly toolResult?: BrowserToolValue;
}
export type RendererBridgeErrorCode = "INVALID_MESSAGE" | "NOT_READY" | "DISCONNECTED" | "CANCELLED" | "DISPOSED" | "COMMAND_REJECTED" | "PROTOCOL";
/** A bounded error from the renderer bridge boundary. */
export declare class RendererBridgeError extends Error {
    readonly code: RendererBridgeErrorCode;
    constructor(code: RendererBridgeErrorCode, message: string);
}
export interface RendererBridgeOptions {
    readonly endpoint: RendererMessageEndpoint;
    readonly targetOrigin: string;
    readonly identity: RendererIdentity;
    readonly expectedSource?: unknown;
    /** Attach the message listener immediately for non-React consumers; browser views use attach in an effect. */
    readonly autoAttach?: boolean;
    readonly onObservation?: (observation: FogSafeObservation, tick: number) => void;
    readonly onStateChange?: (state: RendererBridgeState) => void;
}
/** Decode only the strict fair-observation shape accepted from a renderer. */
export declare function decodeRendererObservation(value: unknown): FogSafeObservation;
/**
 * Owns the loopback companion protocol for one session, match and seat.
 * It never accepts renderer state other than a strict FogSafeObservation.
 */
export declare class RendererBridge {
    private readonly endpoint;
    private readonly targetOrigin;
    private readonly identity;
    private readonly expectedSource;
    private readonly onObservation?;
    private readonly onStateChange?;
    private readonly listener;
    private readonly pendingCommands;
    private currentTickValue;
    private requestNumber;
    private stateValue;
    private connectPending;
    private connectPromise;
    private lastErrorValue;
    private attached;
    constructor(options: RendererBridgeOptions);
    get state(): RendererBridgeState;
    get currentTick(): number;
    get lastError(): RendererBridgeError | undefined;
    /** Attach the transport listener; safe to call more than once. */
    attach(): void;
    /** Start or repeat the loopback companion handshake. */
    connect(signal?: AbortSignal): Promise<void>;
    /** Send a bounded order command after the renderer handshake is ready. */
    sendCommand(command: RendererCommand, signal?: AbortSignal): Promise<RendererCommandReceipt>;
    /** Cancel one pending command and notify the renderer adapter. */
    cancel(requestId: string): boolean;
    /** Validate and dispatch one browser message; false means it was rejected. */
    handleMessage(event: RendererMessageEvent): boolean;
    /** Stop all transport activity and reject every pending operation. */
    dispose(): void;
    private acceptTick;
    private rejectPending;
    private rejectConnect;
    private setState;
    private nextRequestId;
    private message;
    private post;
}
