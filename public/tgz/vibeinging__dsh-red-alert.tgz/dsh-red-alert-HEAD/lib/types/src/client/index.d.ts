import type { Context } from "@deepseek-ai/cordis";
import type { ConvViewProps } from "@deepseek-ai/dsh-client-ui-conversation/client";
import type { PropsRuntime } from "@deepseek-ai/dsh-client-ui-slots";
import type { ILayout } from "@deepseek-ai/dsh-client-ui-layout/client";
import { type BrowserResourceProvider } from "./resource-provider.ts";
import type { ResourceArchiveDescriptor } from "../resource-config.ts";
import { BrowserCommandClientService } from "./browser-command-consumer.ts";
export { BrowserAdapterRegistry, BrowserCommandClientService } from "./browser-command-consumer.ts";
export type { BrowserMatchAdapter } from "./browser-command-consumer.ts";
export { BrowserRendererError, BrowserRendererRuntime, LoopbackRendererAdapter, } from "./browser-renderer-runtime.ts";
export type { BrowserRendererAdapter, BrowserRendererEndpoint, BrowserRendererIdentity, BrowserRendererState, } from "./browser-renderer-runtime.ts";
declare module "@deepseek-ai/cordis" {
    interface Context {
        redAlertBrowserCommands: BrowserCommandClientService;
    }
}
export type { RedAlertState } from "../projection.ts";
/** The client face is loaded after the shared DSH slot and runtime services. */
export declare const inject: string[];
export interface ResourceImportPanelProps {
    readonly provider: BrowserResourceProvider | undefined;
    readonly descriptor?: ResourceArchiveDescriptor;
}
/** User-confirmed resource import controls; construction never starts a download. */
export declare function ResourceImportPanel({ provider, descriptor }: ResourceImportPanelProps): JSX.Element;
/** Reusable real-client battlefield body with a fair projection fallback. */
export declare function RedAlertView({ useProjection, rendererService }: ConvViewProps & {
    readonly rendererService?: BrowserCommandClientService;
}): JSX.Element;
type RedAlertBattlefieldDockProps = PropsRuntime<"conversation.session.header.actions"> & {
    readonly layout: ILayout;
    readonly rendererService?: BrowserCommandClientService;
};
/** Session-header control and persistent right-side battlefield beside the canonical Chat view. */
export declare function RedAlertBattlefieldDock({ useProjection, layout, rendererService }: RedAlertBattlefieldDockProps): JSX.Element;
/** Register the right-side battlefield without replacing the canonical DSH Chat view. */
export declare function apply(ctx: Context): void;
