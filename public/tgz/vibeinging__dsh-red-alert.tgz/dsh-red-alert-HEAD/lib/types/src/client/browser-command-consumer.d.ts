import { Service, type Context } from "@deepseek-ai/cordis";
import { BrowserRendererRuntime } from "./browser-renderer-runtime.ts";
import type { ClientConnectionRpc } from "@deepseek-ai/dsh-client-connection/client";
import type { ISessions } from "@deepseek-ai/dsh-client-runtime/client";
import { type BrowserCommandEnvelope, type BrowserRendererConfigValue } from "../browser-command-protocol.ts";
/** Minimum adapter seam owned by the plugin; real renderer code remains pending. */
export interface BrowserMatchAdapter {
    /**
     * Apply one safe command to the same browser game instance.
     *
     * The adapter must observe the signal and settle promptly after abort. Client
     * teardown waits for this promise before releasing the session lease, so a
     * renderer that ignores abort cannot be represented as quiescent.
     */
    command(command: BrowserCommandEnvelope, signal: AbortSignal): Promise<unknown>;
}
/** Registry used by the client root to attach a browser adapter without coupling it to a tab. */
export declare class BrowserAdapterRegistry {
    private readonly adapters;
    private readonly listeners;
    /** Register one adapter for one session; a different live adapter cannot take over. */
    register(sessionId: string, adapter: BrowserMatchAdapter): () => void;
    /** Resolve the adapter for a session without exposing any engine state. */
    get(sessionId: string): BrowserMatchAdapter | undefined;
    /** Wait until the exact session adapter attaches, the deadline expires, or the caller aborts. */
    waitFor(sessionId: string, deadlineMs: number, signal: AbortSignal): Promise<BrowserMatchAdapter | undefined>;
    /** Subscribe the root consumer to adapter attach/detach changes. */
    subscribe(listener: () => void): () => void;
    /** Number of root consumers currently subscribed to registry changes. */
    get listenerCount(): number;
    private changed;
}
export interface BrowserSessionIdentity {
    readonly sessionId: string;
    readonly matchId: string;
    readonly seat: string;
    readonly tick: number;
}
/** Error used by the client consumer after the official RPC result is decoded. */
export declare class BrowserCommandClientError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
/**
 * Root client consumer. It follows the current DSH session and command
 * projection even when no red-alert tab is mounted.
 */
export declare class BrowserCommandClientConsumer {
    private readonly rpc;
    private readonly sessions;
    readonly adapters: BrowserAdapterRegistry;
    private readonly clientInstanceId;
    private readonly processed;
    private readonly inFlight;
    private listDisposer;
    private commandDisposer;
    private stateDisposer;
    private adapterDisposer;
    private sessionId;
    private commandFace;
    private stateFace;
    private lease;
    private leaseRequest;
    private readonly leaseDrains;
    private generation;
    private started;
    private disposed;
    private disposePromise;
    constructor(options: {
        readonly rpc: ClientConnectionRpc;
        readonly sessions: ISessions;
        readonly adapters?: BrowserAdapterRegistry;
        readonly clientInstanceId?: string;
    });
    /** Begin following the current session and adapter registry. */
    start(): void;
    /** Re-read the current projection after a Connection reconnect. */
    reconcile(): Promise<void>;
    /** Release subscriptions, adapter work and the current Host lease. */
    dispose(): Promise<void>;
    private disposeInternal;
    private syncSession;
    private reconcileInternal;
    /** Read live loopback renderer config through the current leased Connection. */
    rendererConfig(identity: BrowserSessionIdentity): Promise<BrowserRendererConfigValue>;
    private ensureLease;
    private abortLeaseRequest;
    private enqueueLeaseDrain;
    private execute;
    private perform;
    private validateReceipt;
    private failureReceipt;
    private sendReceipt;
    private sendReceiptOnce;
    private cancelRequests;
    private releaseLease;
}
/** Client service wrapper; its lifetime is independent from any red-alert React view. */
export declare class BrowserCommandClientService extends Service {
    static inject: string[];
    readonly consumer: BrowserCommandClientConsumer;
    readonly adapters: BrowserAdapterRegistry;
    readonly renderer: BrowserRendererRuntime;
    private disposePromise;
    private rendererSessionCleanup;
    private readonly rendererSessionErrors;
    private readonly rendererBootstraps;
    private readonly rendererBootstrapContainers;
    constructor(ctx: Context, options?: {
        readonly rpc: ClientConnectionRpc;
        readonly sessions: ISessions;
        readonly clientInstanceId?: string;
    });
    /** Resolve the live loopback renderer endpoint for the current leased session. */
    rendererConfig(identity: BrowserSessionIdentity): Promise<BrowserRendererConfigValue>;
    /** Ensure the real renderer exists even while the user is on the Chat tab. */
    ensureRenderer(identity: BrowserSessionIdentity): Promise<void>;
    private ensureRendererInternal;
    /** Release the root consumer explicitly for tests and host lifecycle teardown. */
    dispose(): Promise<void>;
}
