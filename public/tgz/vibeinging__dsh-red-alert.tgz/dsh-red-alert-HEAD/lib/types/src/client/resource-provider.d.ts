/**
 * Browser-side resource acquisition for an explicitly requested renderer import.
 * The provider stores only the verified archive; it never starts a download on construction.
 */
import { type ResourceArchiveConfig, type ResourceArchiveDescriptor } from "../resource-config.ts";
export { DEFAULT_RESOURCE_ARCHIVE, resolveResourceArchiveDescriptor } from "../resource-config.ts";
export type { ResourceArchiveConfig, ResourceArchiveDescriptor } from "../resource-config.ts";
export interface StoredResourceArchive {
    readonly id: string;
    readonly bytes: ArrayBuffer;
    readonly byteLength: number;
    readonly sha256: string;
    readonly storedAt: number;
}
/** Storage seam used by the provider so browser persistence is testable without a second database. */
export interface ResourceStorage {
    read(id: string): Promise<StoredResourceArchive | undefined>;
    write(record: StoredResourceArchive): Promise<void>;
    remove(id: string): Promise<void>;
}
/** A Cache Storage implementation suitable for the DSH browser client. */
export declare class CacheStorageResourceStorage implements ResourceStorage {
    private readonly cacheStorage;
    private readonly cacheName;
    constructor(cacheStorage: CacheStorage, cacheName?: string);
    read(id: string): Promise<StoredResourceArchive | undefined>;
    write(record: StoredResourceArchive): Promise<void>;
    remove(id: string): Promise<void>;
    private cacheKey;
}
export type ResourceProviderStatus = {
    readonly state: "missing";
} | {
    readonly state: "invalid";
    readonly reason: string;
} | {
    readonly state: "ready";
    readonly storedAt: number;
};
export interface ResourceImportResult {
    readonly source: "cache" | "network";
    readonly resourceId: string;
    readonly byteLength: number;
    readonly sha256: string;
    readonly storedAt: number;
}
export interface ResourceDownloadProgress {
    readonly phase: "downloading" | "verifying" | "storing";
    readonly receivedBytes: number;
    readonly totalBytes: number;
    readonly percent: number;
}
export interface ResourceDownloadOptions {
    readonly signal?: AbortSignal;
    readonly onProgress?: (progress: ResourceDownloadProgress) => void;
}
export interface ResourceProviderOptions {
    readonly storage: ResourceStorage;
    readonly fetch?: typeof fetch;
    readonly digest?: (bytes: ArrayBuffer) => Promise<string>;
    readonly now?: () => number;
}
/** Build a browser provider from the plugin's public archive configuration. */
export declare function createBrowserResourceProvider(config?: ResourceArchiveConfig, options?: Omit<ResourceProviderOptions, "storage"> & {
    readonly cacheStorage?: CacheStorage;
    readonly cacheName?: string;
}): BrowserResourceProvider | undefined;
/** Raised when a downloaded or cached archive does not match its declared descriptor. */
export declare class ResourceIntegrityError extends Error {
    constructor(message: string);
}
/**
 * Fetch, verify, and persist one declared archive. Callers must invoke the method from a user action.
 */
export declare class BrowserResourceProvider {
    readonly descriptor: ResourceArchiveDescriptor;
    private readonly storage;
    private readonly fetchImpl;
    private readonly digest;
    private readonly now;
    constructor(descriptor: ResourceArchiveDescriptor, options: ResourceProviderOptions);
    status(): Promise<ResourceProviderStatus>;
    downloadAndVerify(options?: ResourceDownloadOptions): Promise<ResourceImportResult>;
    /** Return the verified archive for an adapter; raw bytes never enter a DSH session event. */
    openVerifiedArchive(): Promise<Blob>;
    clear(): Promise<void>;
    private readResponse;
    private verify;
    private result;
}
export type RendererEntryDecision = "required" | "allowed" | "excluded" | "ignored";
export declare const REQUIRED_RENDERER_ENTRIES: readonly ["ra2.mix", "language.mix", "multi.mix"];
/** Classify top-level archive entries before a renderer adapter imports them. */
export declare function classifyRendererEntry(entryName: string): RendererEntryDecision;
export declare function selectRendererEntries(entryNames: readonly string[]): {
    readonly selected: readonly string[];
    readonly excluded: readonly string[];
    readonly missing: readonly string[];
};
