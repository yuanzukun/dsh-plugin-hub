import type { HostConnectionHandle } from "@deepseek-ai/dsh-client-connection";
import type { Session } from "@deepseek-ai/dsh-session";
import { type BrowserCommandReceipt, type BrowserRendererConfigValue, type BrowserCreateMatchRequest, type BrowserGameToolRequest, type BrowserOrder } from "./browser-command-protocol.ts";
/** Current authoritative match identity exposed to the browser transport. */
export interface BrowserMatchAuthority {
    readonly matchId: string;
    readonly seat: string;
    readonly tick: number;
    readonly status: "creating" | "active" | "finished" | "stopped";
}
/** Input accepted by the Host outbox; requestId and protocol identity are Host-owned. */
interface BrowserCommandInputIdentity {
    readonly matchId: string;
    readonly seat: string;
    readonly expectedTick: number;
}
export type BrowserCommandInput = BrowserCommandInputIdentity & ({
    readonly kind: "create-match";
    readonly request: BrowserCreateMatchRequest;
} | {
    readonly kind: "orders";
    readonly orders: readonly BrowserOrder[];
} | {
    readonly kind: "tool";
    readonly request: BrowserGameToolRequest;
} | {
    readonly kind: "observe";
} | {
    readonly kind: "stop-match";
});
export interface BrowserCommandTransportOptions {
    readonly connection: HostConnectionHandle;
    readonly flush: (session: Session) => Promise<void>;
    readonly isSessionOwner: (sessionId: string) => boolean;
    readonly resolveAuthority: (sessionId: string) => BrowserMatchAuthority | undefined;
    readonly resolveSession: (sessionId: string) => Session | undefined;
    readonly timeoutMs: number;
    readonly createMatchTimeoutMs?: number;
    readonly logger?: Pick<Console, "error">;
    readonly requestId?: () => string;
    /** Resolve the current loopback renderer endpoint without persisting its port. */
    readonly resolveRendererConfig?: (sessionId: string) => BrowserRendererConfigValue | undefined;
}
/** Error raised by the Host outbox without exposing engine objects. */
export declare class BrowserCommandTransportError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
/**
 * Host-side command outbox and official Connection RPC registry.
 *
 * This class owns no engine state. It only appends safe command/result events,
 * waits for the durable flush boundary, and hands validated receipts back to
 * the caller that admitted the command.
 */
export declare class BrowserCommandTransport {
    private readonly connection;
    private readonly flush;
    private readonly isSessionOwner;
    private readonly resolveAuthority;
    private readonly resolveSession;
    private readonly timeoutMs;
    private readonly createMatchTimeoutMs;
    private readonly logger;
    private readonly requestIdFactory;
    private readonly resolveRendererConfig;
    private readonly pending;
    private readonly leases;
    private readonly sessionCleanupPromises;
    private readonly sessionFinalizations;
    private unregister;
    private disposePromise;
    private started;
    private disposed;
    constructor(options: BrowserCommandTransportOptions);
    /** Register the plugin-owned `/red-alert` channel with loopback authority. */
    start(): void;
    /** Return whether this Host process still owns one live command for the session. */
    hasPending(sessionId: string): boolean;
    /** Close the channel and fail every pending command deterministically. */
    dispose(): Promise<void>;
    private disposeInternal;
    /**
     * Append and flush one command, then wait for the matching browser receipt.
     * One owning session can have only one pending command.
     */
    dispatch(session: Session, input: BrowserCommandInput, signal: AbortSignal): Promise<BrowserCommandReceipt>;
    /** Cancel one session's browser work, persist its failure, and release its lease. */
    cleanupSession(sessionId: string, reason?: "SESSION_DISPOSED" | "TRANSPORT_DISPOSED"): Promise<void>;
    private cleanupSessionInternal;
    private admit;
    private handleRpc;
    private registerLease;
    private rendererConfig;
    private releaseLease;
    private acceptReceipt;
    private withoutLease;
    private assertOwnerAndAuthority;
    private finalizeReceipt;
    private finalizeFailure;
    private trackFinalization;
    private waitForSessionFinalizations;
    private tryRecordFailure;
    private commitResult;
    private appendResultAndMarker;
    private findCompleted;
}
export {};
