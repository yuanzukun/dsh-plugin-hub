import { z as zod } from "zod";
import type { SessionEvent } from "@deepseek-ai/dsh-session";
import type { FogSafeContact, FogSafeObservation } from "../packages/game-host/src/fog-safe-observation.ts";
import type { MatchView } from "../packages/game-host/src/match-controller.ts";
import type { Receipt } from "../packages/game-host/src/orders.ts";
import { type ResourceArchiveDescriptor } from "./resource-config.ts";
import { type BrowserCommandProjectionFoldState, type BrowserCommandProjectionState } from "./browser-command-protocol.ts";
/** The one durable event type emitted by the red-alert tool surface. */
export declare const RED_ALERT_EVENT: "red-alert/state";
/** The client projection key paired with {@link RED_ALERT_EVENT}. */
export declare const RED_ALERT_PROJECTION: "redAlert";
export type RedAlertStateStatus = "empty" | "creating" | "running" | "stopped" | "error";
/** Page capability for the isolated real browser renderer. */
export interface RedAlertRendererDescriptor {
    readonly mode: "loopback";
    readonly enabled: true;
    readonly sourceLabel: string;
    /** Browser-only wait budget for mounting the session adapter; absent in older events. */
    readonly adapterAttachTimeoutMs?: number;
}
/** Historical or headless projection view. Old events may still include a renderer descriptor. */
export interface RedAlertOfflineView {
    readonly mode: "offline";
    readonly realUiAvailable: false;
    /** Optional for replaying pre-import-contract events. */
    readonly resourceArchive?: ResourceArchiveDescriptor;
    readonly renderer?: RedAlertRendererDescriptor;
}
/** Current view when the compatible client is the match authority. */
export interface RedAlertBrowserView {
    readonly mode: "real-browser";
    readonly realUiAvailable: true;
    readonly resourceArchive?: ResourceArchiveDescriptor;
    readonly renderer: RedAlertRendererDescriptor;
}
export type RedAlertView = RedAlertOfflineView | RedAlertBrowserView;
/** Request data retained while an engine is being created. */
export interface RedAlertCreatingRequest {
    readonly map: string;
    readonly myCountry: string;
    readonly opponents: number;
    readonly opponentType: "noop" | "supalosa" | "normal";
    /** Optional while replaying events written before configurable game speed. */
    readonly gameSpeed?: number;
    readonly decisionPeriod: number;
    readonly maxTicks: number;
}
/** Fair match data shown by both the host projection and the browser page. */
export type RedAlertMatch = Omit<MatchView, "replayPath" | "view"> & {
    readonly view: RedAlertView;
} & Partial<RedAlertMatchIdentity>;
/** Identity needed to bind the browser renderer to the owning DSH session. */
export interface RedAlertMatchIdentity {
    readonly sessionId: string;
    readonly seat: string;
}
/** Stable identity published before the browser starts the real match. */
export interface RedAlertCreatingIdentity extends RedAlertMatchIdentity {
    readonly matchId: string;
    readonly tick: 0;
}
/** Recoverable tool failure metadata; it carries no engine-only fields. */
export interface RedAlertFailure {
    readonly phase: "creating" | "running" | "stopping" | "reading";
    readonly code: string;
    readonly message: string;
    readonly recoverable: boolean;
}
/** Whole post-operation state written to the session event log. */
export interface RedAlertState {
    readonly status: RedAlertStateStatus;
    readonly view: RedAlertView;
    readonly request?: RedAlertCreatingRequest;
    readonly identity?: RedAlertCreatingIdentity;
    readonly match?: RedAlertMatch;
    readonly failure?: RedAlertFailure;
}
declare module "@deepseek-ai/dsh-session" {
    interface SessionEventMap {
        /** Complete post-operation fair red-alert state; event.seq supplies ordering. */
        "red-alert/state": RedAlertState;
    }
}
declare module "@deepseek-ai/dsh-session/types" {
    interface SessionEventMap {
        /** Complete red-alert state; event.seq remains envelope-only. */
        "red-alert/state": RedAlertState;
    }
}
declare module "@deepseek-ai/dsh-session-projection/types" {
    interface SessionProjectionMap {
        /** Whole current red-alert state for the current DSH session. */
        redAlert: RedAlertState;
    }
    interface SessionProjectionStateMap {
        /** Whole current red-alert fold state for the current DSH session. */
        redAlert: RedAlertState;
    }
}
/** Runtime schema used at the host-to-client projection boundary. */
export declare const redAlertProjectionSchema: zod.ZodType<RedAlertState>;
/** Return the empty projection value for a new or projection-less session. */
export declare function emptyRedAlertState(resourceArchive?: ResourceArchiveDescriptor, renderer?: RedAlertRendererDescriptor): RedAlertState;
/** Convert a controller view into the browser-safe whole match value. */
export declare function redAlertMatch(view: MatchView | RedAlertMatch, identity?: RedAlertMatchIdentity, projectedView?: RedAlertView): RedAlertMatch;
/** Convert a completed controller operation into its lifecycle projection. */
export declare function stateFromMatch(view: MatchView, identity?: RedAlertMatchIdentity, resourceArchive?: ResourceArchiveDescriptor, renderer?: RedAlertRendererDescriptor): RedAlertState;
/** Build a durable creating state before the engine is touched. */
export declare function creatingState(request: RedAlertCreatingRequest, identity: RedAlertCreatingIdentity, resourceArchive?: ResourceArchiveDescriptor, renderer?: RedAlertRendererDescriptor): RedAlertState;
/** Convert an arbitrary thrown value into a bounded user-visible failure. */
export declare function failureState(phase: RedAlertFailure["phase"], error: unknown, match?: MatchView | RedAlertMatch, request?: RedAlertCreatingRequest, identity?: RedAlertMatchIdentity, resourceArchive?: ResourceArchiveDescriptor, renderer?: RedAlertRendererDescriptor): RedAlertState;
/** Pure session-event fold used by the host registry and keyless tests. */
export declare function applyRedAlertProjection(state: RedAlertState, event: SessionEvent): RedAlertState;
/** Official DSH projection definition for the `redAlert` client key. */
export declare const redAlertProjection: {
    key: "redAlert";
    stateSchema: zod.ZodType<RedAlertState, unknown, zod.core.$ZodTypeInternals<RedAlertState, unknown>>;
    init: typeof emptyRedAlertState;
    apply: typeof applyRedAlertProjection;
    wire: {
        viewSchema: zod.ZodType<RedAlertState, unknown, zod.core.$ZodTypeInternals<RedAlertState, unknown>>;
        view: (state: NoInfer<RedAlertState>) => RedAlertState;
    };
    stateVersion: number;
};
/** Empty browser command fold; admitted command data stays hidden until its marker. */
export declare function emptyBrowserCommandProjection(): BrowserCommandProjectionFoldState;
/** Pure fold for the Host-to-browser command projection. Malformed history fails closed. */
export declare function applyBrowserCommandProjection(state: BrowserCommandProjectionFoldState, event: SessionEvent): BrowserCommandProjectionFoldState;
/** Official DSH projection definition consumed by the client command root. */
export declare const redAlertCommandProjection: {
    key: "redAlertCommand";
    stateSchema: zod.ZodType<BrowserCommandProjectionFoldState, unknown, zod.core.$ZodTypeInternals<BrowserCommandProjectionFoldState, unknown>>;
    init: typeof emptyBrowserCommandProjection;
    apply: typeof applyBrowserCommandProjection;
    wire: {
        viewSchema: zod.ZodType<BrowserCommandProjectionState, unknown, zod.core.$ZodTypeInternals<BrowserCommandProjectionState, unknown>>;
        view: (state: NoInfer<BrowserCommandProjectionFoldState>) => BrowserCommandProjectionState;
    };
    stateVersion: number;
};
/** Keep the imported types visible to declaration emit without a second wire shape. */
export type { FogSafeContact, FogSafeObservation, Receipt };
