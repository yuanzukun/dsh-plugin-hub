import { type ToolDefinition } from "@deepseek-ai/dsh-tools";
import type { MatchService } from "./index.ts";
/** Build two bootstrap tools and exact deferred game tools owned by one MatchService. */
export declare function createMatchTools(service: MatchService): ToolDefinition[];
