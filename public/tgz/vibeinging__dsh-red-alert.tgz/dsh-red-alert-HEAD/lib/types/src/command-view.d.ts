import type { BrowserCommandReceipt } from "./browser-command-protocol.ts";
/** Maximum contacts retained in each compact model-facing command collection. */
export declare const MAX_COMMAND_VIEW_CONTACTS = 128;
/** Build the compact fair state attached to exact browser tool results. */
export declare function compactCommandView(receipt: BrowserCommandReceipt): Record<string, unknown> | undefined;
