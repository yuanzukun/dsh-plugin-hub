import { Context, Service } from "@deepseek-ai/cordis";
import z from "@deepseek-ai/schemastery";
import type { Session } from "@deepseek-ai/dsh-session";
import type { ToolRunContext } from "@deepseek-ai/dsh-tools";
import { MatchController, MatchOwner } from "../packages/game-host/src/match-controller.ts";
import type { MatchView } from "../packages/game-host/src/match-controller.ts";
import { type ResourceArchiveDescriptor } from "./resource-config.ts";
import type { RedAlertMatch } from "./projection.ts";
import { type RedAlertGroupId } from "./tool-policy.ts";
import { BrowserCommandTransport } from "./browser-command-transport.ts";
import { type BrowserGameToolRequest } from "./browser-command-protocol.ts";
import { RendererHostService } from "./renderer-host.ts";
import { type FieldManualFaction, type FieldManualTopic } from "./field-manual.ts";
export { RED_ALERT_SESSION_EVENT_TYPES, registerHostSessionEventVocabulary, } from "./session-event-vocabulary.ts";
declare module "@deepseek-ai/cordis" {
    interface Context {
        redAlert: MatchService;
    }
}
/** Runtime configuration for the external DSH bundle. */
export interface Config {
    readonly assetsDir?: string;
    readonly defaultMap?: string;
    readonly defaultCountry?: string;
    readonly defaultOpponents?: number;
    readonly defaultOpponentType?: string;
    readonly defaultGameSpeed?: number;
    readonly enableOpeningDoctrine?: boolean;
    readonly enableAutoLearning?: boolean;
    readonly strategyHistoryLimit?: number;
    readonly strategyMaxRules?: number;
    readonly maxLearnedDefenders?: number;
    readonly decisionPeriod?: number;
    readonly maxTicks?: number;
    readonly resourceArchiveUrl?: string;
    readonly resourceArchiveSize?: number;
    readonly resourceArchiveSha256?: string;
    readonly browserAdapterAttachTimeoutMs?: number;
    readonly browserCommandTimeoutMs?: number;
    readonly browserCreateMatchTimeoutMs?: number;
    readonly rendererDistDir?: string;
    readonly rendererPort?: number;
}
/** Load-time schema; headless assets are optional when a real renderer is configured. */
export declare const Config: z<Config>;
/** Cordis plugin name. */
export declare const name = "red-alert";
/** Services required before the session-owned tool layer is installed. */
export declare const inject: string[];
/** Session defaults shared by the bootstrap loader and deferred match tools. */
export interface MatchDefaults {
    readonly map: string;
    readonly myCountry: string;
    readonly opponents: number;
    readonly opponentType: "noop" | "supalosa" | "normal";
    readonly gameSpeed: number;
    readonly decisionPeriod: number;
    readonly maxTicks: number;
}
interface MatchServiceConfig extends Config {
    readonly rendererHost?: RendererHostService;
}
/** Service that binds each DSH Agent session to one headless or real browser match authority. */
export declare class MatchService extends Service {
    static inject: string[];
    readonly controller: MatchController | undefined;
    /** Browser authority transport; headless compatibility mode does not use it. */
    readonly browserTransport: BrowserCommandTransport | undefined;
    readonly defaults: MatchDefaults;
    readonly resourceArchive: ResourceArchiveDescriptor;
    readonly rendererDescriptor: import("./projection.ts").RedAlertRendererDescriptor | undefined;
    private readonly sessionTails;
    private readonly pendingAgentDisposals;
    private readonly agentDisposalErrors;
    private readonly toolGroupStates;
    private readonly registeredDeferredToolNames;
    private readonly strategyOptions;
    /** Check the owned headless records or the current browser-backed session projections. */
    assertInvariants(fail: (message: string) => never): void;
    /** Check a successful model-visible result against the current authoritative session projection. */
    assertToolOutput(value: unknown, session: Session | undefined, fail: (message: string) => never): void;
    constructor(ctx: Context, config: MatchServiceConfig);
    /** Convert a DSH execution to an exact Agent/session ownership pair. */
    ownerOf(exec: ToolRunContext): MatchOwner;
    /** Recheck ownership, group selection, and the current phase before a legacy tool runs. */
    runGroupTool<T>(toolName: string, exec: ToolRunContext, operation: () => Promise<T>): Promise<T>;
    /** Return the model-visible capability catalog for one owning Agent session. */
    capabilities(exec: ToolRunContext): Promise<Record<string, unknown>>;
    /** Load one exact group and durably commit its selection with rollback on failure. */
    loadGroup(args: {
        readonly group: RedAlertGroupId;
        readonly matchId?: string;
    }, exec: ToolRunContext): Promise<Record<string, unknown>>;
    /** Record and return the bounded strategy learned for a future match selector. */
    strategyBrief(args: {
        readonly map?: string;
        readonly myCountry?: string;
        readonly opponentType?: "noop" | "supalosa" | "normal";
    }, exec: ToolRunContext): Promise<Record<string, unknown>>;
    /** Record and return one compact built-in battlefield manual page. */
    fieldManual(args: {
        readonly topic: FieldManualTopic;
        readonly faction: FieldManualFaction;
    }, exec: ToolRunContext): Promise<Record<string, unknown>>;
    /** Persist one model verdict over the current finished match's closed candidates. */
    reviewMatch(args: {
        readonly matchId: string;
        readonly adoptedRuleIds: readonly unknown[];
        readonly rejectedRuleIds: readonly unknown[];
    }, exec: ToolRunContext): Promise<Record<string, unknown>>;
    /** Start using only the defaults and validated model arguments. */
    start(args: {
        readonly map?: string;
        readonly myCountry?: string;
        readonly opponents?: number;
        readonly opponentType?: "noop" | "supalosa" | "normal";
        readonly gameSpeed?: number;
        readonly decisionPeriod?: number;
        readonly maxTicks?: number;
    }, exec: ToolRunContext): Promise<MatchView | RedAlertMatch>;
    /** Apply commands for the exact owner. */
    act(args: {
        readonly matchId: string;
        readonly orders: readonly unknown[];
    }, exec: ToolRunContext): Promise<MatchView | RedAlertMatch>;
    /** Read state without advancing. */
    status(args: {
        readonly matchId: string;
    }, exec: ToolRunContext): Promise<MatchView | RedAlertMatch>;
    /** Execute one exact fair browser-backed game tool and durably commit its post-call observation. */
    browserTool(args: {
        readonly matchId: string;
    } & BrowserGameToolRequest, exec: ToolRunContext): Promise<Record<string, unknown>>;
    /** Save and stop the exact owner's match. */
    stop(args: {
        readonly matchId: string;
    }, exec: ToolRunContext): Promise<MatchView | RedAlertMatch>;
    private startBrowserMatch;
    private actBrowserMatch;
    private readBrowserMatch;
    private stopBrowserMatch;
    private requireActiveBrowserMatch;
    private commitBrowserMatch;
    private browserView;
    private requireToolGroupState;
    private decodeRuleIds;
    private installToolGroupState;
    private uninstallToolGroupState;
    private assertGroupToolAccess;
    private phaseFor;
    private groupCanLoad;
    private manifestAllowsPhase;
    private deniedNamesFor;
    private refreshToolGroupVisibility;
    private replaceToolGroupRestriction;
    private restoreToolGroupRestriction;
    private groupLoadResult;
    private appendGroupRollback;
    private ownerOfAgent;
    private agentForSession;
    private trackAgentDisposal;
    private waitForAgentDisposals;
    private withSession;
    private appendState;
    private strategyReviewHint;
    private refreshToolGroupVisibilityForSession;
    private appendFailure;
    private commitOperation;
    private closeAfterFailure;
    private currentMatch;
    private requireLegacyController;
    private requireBrowserTransport;
    private currentState;
    private combineFailure;
    private waitForSessionOperations;
    private serialize;
}
/** Apply the service and optional user-confirmed loopback renderer host. */
export declare function apply(ctx: Context, config: Config): Promise<void>;
