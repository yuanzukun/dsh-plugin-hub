import type { Session } from "@deepseek-ai/dsh-session";
import { type RedAlertState } from "./projection.ts";
/** Durable event written once when a natural match reaches an engine result. */
export declare const RED_ALERT_STRATEGY_EPISODE_EVENT: "red-alert/strategy-episode";
/** Durable model-facing strategy brief applied before a later match. */
export declare const RED_ALERT_STRATEGY_BRIEF_EVENT: "red-alert/strategy-brief";
/** Durable structured verdict selected by the model after reviewing an episode. */
export declare const RED_ALERT_STRATEGY_REVIEW_EVENT: "red-alert/strategy-review";
/** Closed lessons keep learned prompt text bounded and auditable. */
export declare const STRATEGY_RULE_IDS: readonly ["rush-defender-target", "anti-infantry-defense", "armor-before-contact", "fresh-owned-ids", "act-before-reread", "sustain-model-attacks"];
export type StrategyRuleId = typeof STRATEGY_RULE_IDS[number];
/** Evidence retained from one fog-safe match without raw world or hidden enemy data. */
export interface StrategyEpisode {
    readonly version: 1;
    readonly sessionId: string;
    readonly matchId: string;
    readonly map: string;
    readonly myCountry: string;
    readonly opponentType: "noop" | "supalosa" | "normal";
    readonly gameSpeed: number;
    readonly result: "victory" | "defeat";
    readonly finalTick: number;
    readonly gameTimeSec: number;
    readonly metrics: {
        readonly maxVisibleEnemies: number;
        readonly maxVisibleEnemyInfantry: number;
        readonly maxOwnedCombatUnits: number;
        readonly firstVisibleEnemyTick?: number;
        readonly firstArmoredUnitTick?: number;
        readonly readCommands: number;
        readonly actionCommands: number;
        readonly staleOwnershipFailures: number;
        readonly unitOrderBatches: number;
        readonly issuedUnitOrders: number;
        readonly multiOrderBatches: number;
        readonly attackOrderBatches: number;
        readonly retreatOrderBatches: number;
    };
    readonly candidates: readonly StrategyCandidate[];
}
/** One deterministic lesson candidate supported by bounded match evidence. */
export interface StrategyCandidate {
    readonly ruleId: StrategyRuleId;
    readonly evidenceTick: number;
    readonly evidence: string;
    readonly target?: number;
}
/** Model verdict over candidates from its own finished match. */
export interface StrategyReview {
    readonly version: 1;
    readonly sessionId: string;
    readonly matchId: string;
    readonly adoptedRuleIds: readonly StrategyRuleId[];
    readonly rejectedRuleIds: readonly StrategyRuleId[];
}
/** Bounded learned rule returned to a later model turn. */
export interface StrategyBriefRule {
    readonly ruleId: StrategyRuleId;
    readonly status: "confirmed" | "experimental";
    readonly confidence: number;
    readonly evidenceMatches: number;
    readonly instruction: string;
}
/** Exact strategy query and result recorded before it reaches a model. */
export interface StrategyBrief {
    readonly version: 1;
    readonly sessionId: string;
    readonly query: {
        readonly map: string;
        readonly myCountry: string;
        readonly opponentType: "noop" | "supalosa" | "normal";
    };
    readonly rules: readonly StrategyBriefRule[];
    readonly sourceMatchIds: readonly string[];
}
declare module "@deepseek-ai/dsh-session" {
    interface SessionEventMap {
        /** Fog-safe metrics and lesson candidates from one natural match result. */
        "red-alert/strategy-episode": StrategyEpisode;
        /** Exact learned brief exposed to a later model turn. */
        "red-alert/strategy-brief": StrategyBrief;
        /** Model-selected verdict over one episode's closed lesson candidates. */
        "red-alert/strategy-review": StrategyReview;
    }
}
declare module "@deepseek-ai/dsh-session/types" {
    interface SessionEventMap {
        /** Fog-safe metrics and lesson candidates from one natural match result. */
        "red-alert/strategy-episode": StrategyEpisode;
        /** Exact learned brief exposed to a later model turn. */
        "red-alert/strategy-brief": StrategyBrief;
        /** Model-selected verdict over one episode's closed lesson candidates. */
        "red-alert/strategy-review": StrategyReview;
    }
}
interface StrategyLearningOptions {
    readonly maxLearnedDefenders: number;
    readonly historyLimit: number;
    readonly maxRules: number;
}
/** Derive one bounded episode from durable fair state and command events. */
export declare function deriveStrategyEpisode(session: Pick<Session, "id" | "events">, finalState: RedAlertState, options: Pick<StrategyLearningOptions, "maxLearnedDefenders">): StrategyEpisode | undefined;
/** Fold prior episode and review events into a short selector-specific strategy. */
export declare function deriveStrategyBrief(sessionId: string, sessions: readonly Pick<Session, "events">[], query: StrategyBrief["query"], options: Pick<StrategyLearningOptions, "historyLimit" | "maxRules">): StrategyBrief;
/** Return the current session's exact episode when it is ready for model review. */
export declare function strategyEpisodeForReview(session: Pick<Session, "events">, matchId: string): StrategyEpisode | undefined;
/** Return an existing structured review for idempotent tool execution. */
export declare function strategyReviewForMatch(session: Pick<Session, "events">, matchId: string): StrategyReview | undefined;
/** Validate a closed lesson id from a model-facing JSON boundary. */
export declare function isStrategyRuleId(value: unknown): value is StrategyRuleId;
export {};
