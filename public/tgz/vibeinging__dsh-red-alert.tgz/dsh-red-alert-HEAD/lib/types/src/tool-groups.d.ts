import type { Agent } from "@deepseek-ai/dsh-agent";
import type { Session } from "@deepseek-ai/dsh-session";
import { type RedAlertGroupId, type RedAlertPhase } from "./tool-policy.ts";
/** The durable event that records one red-alert group selection transition. */
export declare const RED_ALERT_TOOL_GROUP_EVENT: "red-alert/tool-group-selection";
/** Versions of the durable group-selection payload supported by the decoder. */
export type ToolGroupSelectionVersion = 0 | 1;
export type ToolGroupSelectionOutcome = "committed" | "rollback";
export type ToolGroupSchemaState = "loaded" | "pending-client-adapter";
export interface RedAlertToolGroupSelection {
    readonly version: ToolGroupSelectionVersion;
    readonly agentId: string;
    readonly sessionId: string;
    readonly groupId: RedAlertGroupId;
    readonly phase: RedAlertPhase;
    readonly methodKeys: readonly string[];
    readonly schemaState: ToolGroupSchemaState;
    readonly outcome: ToolGroupSelectionOutcome;
}
declare module "@deepseek-ai/dsh-session" {
    interface SessionEventMap {
        /** A red-alert group selection transition; event.seq remains envelope-only. */
        "red-alert/tool-group-selection": RedAlertToolGroupSelection;
    }
}
declare module "@deepseek-ai/dsh-session/types" {
    interface SessionEventMap {
        /** A red-alert group selection transition; event.seq remains envelope-only. */
        "red-alert/tool-group-selection": RedAlertToolGroupSelection;
    }
}
export interface RedAlertToolGroupState {
    readonly agent: Agent;
    readonly session: Session;
    readonly selected: Set<RedAlertGroupId>;
    readonly deniedNames: readonly string[];
    readonly phase: RedAlertPhase;
    readonly restriction?: () => void;
}
/** Decode one versioned or legacy durable group-selection payload at the persistence boundary. */
export declare function decodeToolGroupSelection(value: unknown): RedAlertToolGroupSelection;
/** Validate every red-alert group event before runtime or invariant consumers use it. */
export declare function validateToolGroupSelectionLog(session: Session): void;
/** Return all tool names owned by a deferred red-alert group. */
export declare function deferredNamesForGroup(group: RedAlertGroupId): readonly string[];
/** Return only registered tool names owned by a deferred group. */
export declare function registeredNamesForGroup(group: RedAlertGroupId, registeredNames: ReadonlySet<string>): readonly string[];
/** Return the event sequence's committed group selection for one exact owner pair. */
export declare function restoreSelectedGroups(session: Session, agent: Agent): Set<RedAlertGroupId>;
