/** Public archive metadata shared by the host configuration and browser face. */
export interface ResourceArchiveDescriptor {
    readonly id: string;
    readonly url: string;
    readonly byteLength: number;
    readonly sha256: string;
    readonly version: string;
    readonly sourceLabel: string;
    readonly licenseNotice: string;
}
/** Configuration overrides for the user-triggered browser resource import. */
export interface ResourceArchiveConfig {
    readonly resourceArchiveUrl?: string;
    readonly resourceArchiveSize?: number;
    readonly resourceArchiveSha256?: string;
    readonly resourceArchiveVersion?: string;
    readonly resourceArchiveSourceLabel?: string;
    readonly resourceArchiveLicenseNotice?: string;
}
/** The public RA2WEB candidate recorded by the compatibility client's config.ini. */
export declare const DEFAULT_RESOURCE_ARCHIVE: ResourceArchiveDescriptor;
/** Resolve and validate the public archive descriptor without performing network I/O. */
export declare function resolveResourceArchiveDescriptor(config?: ResourceArchiveConfig): ResourceArchiveDescriptor;
