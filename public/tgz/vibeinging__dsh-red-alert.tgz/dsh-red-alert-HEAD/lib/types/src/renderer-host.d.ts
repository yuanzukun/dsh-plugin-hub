import { type IncomingMessage, type ServerResponse } from "node:http";
import { Service, type Context } from "@deepseek-ai/cordis";
/** Loopback-only static server path; it is not a DSH host route. */
export declare const RED_ALERT_RENDERER_ROUTE: "/";
/** Validated configuration for the user-provided renderer server. */
export interface RendererHostConfig {
    readonly rendererDistDir: string;
    /** Zero asks the OS for a loopback port; the live port is exposed only by Connection RPC. */
    readonly rendererPort?: number;
    /** Internal startup handoff used by the owning plugin across isolated Cordis scopes. */
    readonly onReady?: (service: RendererHostService) => void;
}
/** Validate an explicit renderer directory without scanning or copying it. */
export declare function resolveRendererDistDir(value: string): string;
/** Validate the loopback port used by the isolated companion server. */
export declare function resolveRendererPort(value: number | undefined): number;
/** Create the isolated static handler; unknown paths never fall through to a DSH index. */
export declare function createRendererStaticHandler(rendererDistDir: string, parentOrigin: string, expectedHost: string): (request: IncomingMessage, response: ServerResponse) => Promise<void>;
/** Root-owned loopback server for a user-provided real renderer build. */
export declare class RendererHostService extends Service {
    readonly rendererDistDir: string;
    readonly rendererPort: number;
    readonly rendererParentOrigin: string;
    private server;
    private urlValue;
    private readonly onReady;
    constructor(ctx: Context, config: RendererHostConfig);
    get url(): string | undefined;
    [Service.init](): Promise<void>;
}
/** Plugin object for the optional user-provided loopback renderer server. */
export declare const rendererHostPlugin: {
    name: string;
    inject: string[];
    apply(ctx: Context, config: RendererHostConfig): void;
};
