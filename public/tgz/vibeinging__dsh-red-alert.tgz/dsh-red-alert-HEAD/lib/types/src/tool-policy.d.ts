/**
 * Typed red-alert tool groups and the single policy inventory for the locked
 * Chrono Divide game-api surface.
 */
export declare const RED_ALERT_GROUPS: readonly ["bootstrap/capability", "strategy/learning", "lobby/setup", "observation", "production/economy", "construction", "units/combat", "diplomacy/comms", "superweapon", "lifecycle/replay"];
export type RedAlertGroupId = typeof RED_ALERT_GROUPS[number];
export type MethodOwner = "PublicApi" | "GameInstanceApi" | "GameApi" | "MapApi" | "PlayerApi" | "ProductionApi" | "ActionsApi";
export type MethodDecision = "allow-wrapper" | "internal-only" | "deny";
export type MethodAvailability = "current-headless-wrapper" | "real-browser-wrapper" | "pending-client-adapter" | "not-exposed";
export type RedAlertPhase = "catalog-only" | "lobby-ready" | "lobby-created" | "running" | "ended" | "stopped" | "error";
export interface MethodPolicy {
    readonly methodKey: string;
    readonly owner: MethodOwner;
    readonly method: string;
    readonly signature: string;
    readonly overload: number;
    readonly decision: MethodDecision;
    readonly availability: MethodAvailability;
    readonly tool: string | undefined;
    readonly group: RedAlertGroupId | "internal";
    readonly phase: RedAlertPhase | "never";
    readonly fairnessRule: string;
}
export interface ToolManifestEntry {
    readonly tool: string;
    readonly group: RedAlertGroupId;
    readonly phase: RedAlertPhase | "all";
    readonly methodKeys: readonly string[];
    readonly schemaId: string;
    readonly sessionEvent: "red-alert/state" | "red-alert/tool-group-selection" | "red-alert/field-manual" | "red-alert/strategy-brief" | "red-alert/strategy-review";
    readonly implemented: boolean;
    readonly testId: string;
    readonly pendingReason?: string;
    readonly legacyCrossGroup?: true;
}
export declare function methodKey(owner: MethodOwner, method: string, overload?: number): string;
export declare const METHOD_POLICY: readonly MethodPolicy[];
export declare const TOOL_MANIFEST: readonly ToolManifestEntry[];
export declare const IMPLEMENTED_TOOL_NAMES: string[];
export declare const DEFERRED_TOOL_NAMES: string[];
export declare function methodPolicy(methodKeyValue: string): MethodPolicy | undefined;
export declare function toolsForGroup(group: RedAlertGroupId): readonly ToolManifestEntry[];
export declare function policyForTool(toolName: string): readonly MethodPolicy[];
