import type { Context } from "@deepseek-ai/cordis";
/** Cordis companion plugin name. */
export declare const name = "red-alert-invariant";
/** The runtime service must be present before relationship checks install. */
export declare const inject: string[];
/** Register the package-owned active-match and fair-output checks. */
export declare const apply: (ctx: Context) => Promise<() => void>;
