import { Service, type Context } from "@deepseek-ai/cordis";
import type { HostConnectionHandle, HostConnectionRpc } from "@deepseek-ai/dsh-client-connection";
declare module "@deepseek-ai/cordis" {
    interface Context {
        redAlertCompatConnection: RedAlertCompatConnectionService;
    }
}
/** Detect the generic Host RPC seam instead of trusting the service name alone. */
export declare function supportsHostConnectionRpc(value: unknown): value is HostConnectionHandle;
/** Plugin-owned loopback RPC carrier used when the active Web connection does not expose RPC. */
export declare class RedAlertCompatConnectionService extends Service implements HostConnectionHandle {
    constructor(ctx: Context);
    /** Register one isolated loopback channel without replacing DSH's shared `/api`. */
    get rpc(): HostConnectionRpc;
    private register;
}
