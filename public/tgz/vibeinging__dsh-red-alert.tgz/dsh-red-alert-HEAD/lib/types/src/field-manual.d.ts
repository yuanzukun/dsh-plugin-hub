/** Durable event containing the exact built-in manual page exposed to the model. */
export declare const RED_ALERT_FIELD_MANUAL_EVENT: "red-alert/field-manual";
/** Small manual topics that can be loaded independently before a match. */
export declare const FIELD_MANUAL_TOPICS: readonly ["structures", "infantry", "vehicles-air", "opening", "combat"];
/** Faction filter accepted by the built-in manual. */
export declare const FIELD_MANUAL_FACTIONS: readonly ["soviet", "allied", "general"];
/** One independently loadable built-in manual topic. */
export type FieldManualTopic = typeof FIELD_MANUAL_TOPICS[number];
/** One faction filter for a manual topic. */
export type FieldManualFaction = typeof FIELD_MANUAL_FACTIONS[number];
/** One rules.ini-backed unit or structure summary. */
export interface FieldManualEntry {
    readonly id: string;
    readonly name: string;
    readonly faction: FieldManualFaction;
    readonly cost: number;
    readonly prerequisites: readonly string[];
    readonly role: string;
    readonly use: string;
    readonly warning?: string;
}
/** Exact manual page recorded before it reaches the model. */
export interface FieldManualPage {
    readonly version: 1;
    readonly sessionId: string;
    readonly topic: FieldManualTopic;
    readonly faction: FieldManualFaction;
    readonly title: string;
    readonly rules: readonly string[];
    readonly entries: readonly FieldManualEntry[];
    readonly sources: readonly {
        readonly kind: "ruleset" | "guide" | "battle-review";
        readonly label: string;
    }[];
    readonly fairness: string;
}
declare module "@deepseek-ai/dsh-session" {
    interface SessionEventMap {
        /** Exact built-in battlefield manual page exposed to the model. */
        "red-alert/field-manual": FieldManualPage;
    }
}
declare module "@deepseek-ai/dsh-session/types" {
    interface SessionEventMap {
        /** Exact built-in battlefield manual page exposed to the model. */
        "red-alert/field-manual": FieldManualPage;
    }
}
/** Build one compact manual page from audited static data. */
export declare function createFieldManualPage(sessionId: string, topic: FieldManualTopic, faction: FieldManualFaction): FieldManualPage;
