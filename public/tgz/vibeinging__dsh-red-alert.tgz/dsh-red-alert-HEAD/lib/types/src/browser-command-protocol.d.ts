import type { SessionEvent } from "@deepseek-ai/dsh-session";
import type { RpcResult } from "@deepseek-ai/dsh-client-connection/client";
import type { FogSafeContact, FogSafeObservation } from "../packages/game-host/src/fog-safe-observation.ts";
/** Fixed version for the DSH Host-to-browser red-alert command channel. */
export declare const BROWSER_TRANSPORT_PROTOCOL_VERSION: 1;
/** Dedicated loopback host kept cross-site from the DSH Web origin. */
export declare const RED_ALERT_RENDERER_LOOPBACK_HOST: "localhost";
/** Maximum number of orders accepted in one loopback command payload. */
export declare const MAX_BROWSER_ORDERS = 256;
/** Maximum contacts accepted in each fair-observation collection; not a combined total. */
export declare const MAX_BROWSER_OBSERVATION_CONTACTS = 4096;
/** Official Connection RPC channel owned by this external plugin. */
export declare const RED_ALERT_BROWSER_CHANNEL: "/red-alert";
/** Durable first-phase event carrying one browser command into the outbox. */
export declare const RED_ALERT_BROWSER_COMMAND_EVENT: "red-alert/browser-command-admitted";
/** Publication marker emitted only after the admitted command has flushed. */
export declare const RED_ALERT_BROWSER_COMMAND_PUBLISHED_EVENT: "red-alert/browser-command-published";
/** Durable first-phase event carrying a safe result; it is not visible until its marker. */
export declare const RED_ALERT_BROWSER_COMMAND_RESULT_EVENT: "red-alert/browser-command-result";
/** Publication marker emitted only after the full result has flushed. */
export declare const RED_ALERT_BROWSER_COMMAND_RESULT_PUBLISHED_EVENT: "red-alert/browser-command-result-published";
/** Client projection key for the latest browser command state. */
export declare const RED_ALERT_BROWSER_COMMAND_PROJECTION: "redAlertCommand";
export type BrowserOrderAction = "build" | "train" | "cancel" | "move" | "attackMove" | "attackTarget" | "retreat" | "deploy";
/** The only order fields that may cross the Host/browser boundary in D3. */
export interface BrowserOrder {
    readonly action: BrowserOrderAction;
    readonly target?: string;
    readonly qty?: number;
    readonly units?: string;
    readonly x?: number;
    readonly y?: number;
    readonly contact?: string;
    readonly reason?: string;
}
export interface BrowserCreateMatchRequest {
    readonly map?: string;
    readonly myCountry: string;
    readonly opponents: number;
    readonly opponentType: "noop" | "normal";
    readonly gameSpeed?: number;
}
/** Exact safe game operations carried after a model-facing group tool validates its schema. */
export type BrowserGameToolRequest = {
    readonly tool: "red_alert_lobby_map";
} | {
    readonly tool: "red_alert_lobby_players";
} | {
    readonly tool: "red_alert_observe";
} | {
    readonly tool: "red_alert_map";
    readonly x?: number;
    readonly y?: number;
    readonly width?: number;
    readonly height?: number;
} | {
    readonly tool: "red_alert_resources";
    readonly x: number;
    readonly y: number;
    readonly width: number;
    readonly height: number;
} | {
    readonly tool: "red_alert_rules";
} | {
    readonly tool: "red_alert_production_catalog";
} | {
    readonly tool: "red_alert_production_status";
} | {
    readonly tool: "red_alert_production";
    readonly operation: "queue" | "cancel" | "pause" | "resume";
    readonly queueType: number;
    readonly name?: string;
    readonly quantity?: number;
} | {
    readonly tool: "red_alert_construction_catalog";
} | {
    readonly tool: "red_alert_construction";
    readonly operation: "place" | "sell" | "repair";
    readonly name?: string;
    readonly objectId?: number;
    readonly x?: number;
    readonly y?: number;
} | {
    readonly tool: "red_alert_diplomacy";
    readonly player?: string;
    readonly allied?: boolean;
} | {
    readonly tool: "red_alert_superweapons";
    readonly type?: number;
    readonly x?: number;
    readonly y?: number;
    readonly x2?: number;
    readonly y2?: number;
};
/** Recursively bounded plain JSON returned by one exact renderer tool. */
export type BrowserToolValue = null | boolean | number | string | readonly BrowserToolValue[] | {
    readonly [key: string]: BrowserToolValue;
};
interface BrowserCommandIdentity {
    readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
    readonly requestId: string;
    readonly sessionId: string;
    readonly matchId: string;
    readonly seat: string;
    readonly expectedTick: number;
}
/** An opaque, identity-bound command retained by the durable outbox. */
export type BrowserCommandEnvelope = BrowserCommandIdentity & ({
    readonly kind: "create-match";
    readonly request: BrowserCreateMatchRequest;
} | {
    readonly kind: "orders";
    readonly orders: readonly BrowserOrder[];
} | {
    readonly kind: "tool";
    readonly request: BrowserGameToolRequest;
} | {
    readonly kind: "observe";
} | {
    readonly kind: "stop-match";
});
/** Marker that makes an already-flushed command visible to the browser projection. */
export interface BrowserCommandPublicationEvent {
    readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
    readonly requestId: string;
    readonly sessionId: string;
    readonly matchId: string;
    readonly seat: string;
    readonly expectedTick: number;
}
/** Marker that exposes a previously flushed browser command result. */
export interface BrowserCommandResultPublicationEvent {
    readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
    readonly requestId: string;
    readonly sessionId: string;
    readonly matchId: string;
    readonly seat: string;
    readonly status: "completed" | "failed" | "cancelled";
}
/** Safe receipt returned by a browser adapter; no engine object is allowed. */
export interface BrowserCommandReceipt {
    readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
    readonly requestId: string;
    readonly sessionId: string;
    readonly matchId: string;
    readonly seat: string;
    readonly tick: number;
    readonly ok: boolean;
    readonly detail: string;
    readonly observation?: FogSafeObservation;
    readonly match?: BrowserMatchSnapshot;
    readonly toolResult?: BrowserToolValue;
}
/** Public match facts returned atomically with a fair browser observation. */
export interface BrowserMatchSnapshot {
    readonly map: string;
    readonly mapSize: {
        readonly width: number;
        readonly height: number;
    };
    readonly myCountry: string;
    readonly status: "active" | "finished" | "stopped";
    readonly self: {
        readonly credits: number;
        readonly power: {
            readonly total: number;
            readonly drain: number;
            readonly isLowPower: boolean;
        };
        readonly defeated: boolean;
    };
}
/** Host-side lease registration request. The token is never part of this payload. */
export interface BrowserLeaseRegisterRequest {
    readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
    readonly sessionId: string;
    readonly matchId: string;
    readonly seat: string;
    readonly clientInstanceId: string;
}
/** Host response containing the in-memory-only lease token. */
export interface BrowserLeaseValue {
    readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
    readonly sessionId: string;
    readonly matchId: string;
    readonly seat: string;
    readonly leaseToken: string;
}
/** Idempotent release request for the in-memory browser lease. */
export interface BrowserLeaseReleaseRequest {
    readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
    readonly sessionId: string;
    readonly leaseToken: string;
}
/** Live renderer config request; the lease binds it to the current session. */
export interface BrowserRendererConfigRequest {
    readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
    readonly sessionId: string;
    readonly matchId: string;
    readonly seat: string;
    readonly leaseToken: string;
}
/** Public live renderer endpoint; it contains no local filesystem path. */
export interface BrowserRendererConfigValue {
    readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
    readonly sessionId: string;
    readonly matchId: string;
    readonly seat: string;
    readonly url: string;
    readonly port: number;
}
/** Browser receipt RPC payload. The lease token is accepted and discarded at the Host boundary. */
export interface BrowserReceiptRequest extends BrowserCommandReceipt {
    readonly leaseToken: string;
}
export interface BrowserCommandFailure {
    readonly code: string;
    readonly message: string;
}
/** Wire state represented by the browser command projection. */
export type BrowserCommandProjectionState = {
    readonly status: "idle";
} | {
    readonly status: "pending";
    readonly command: BrowserCommandEnvelope;
} | {
    readonly status: "completed";
    readonly command: BrowserCommandEnvelope;
    readonly receipt: BrowserCommandReceipt;
} | {
    readonly status: "failed";
    readonly command: BrowserCommandEnvelope;
    readonly failure: BrowserCommandFailure;
} | {
    readonly status: "cancelled";
    readonly command: BrowserCommandEnvelope;
    readonly failure: BrowserCommandFailure;
};
/** Durable admitted-command event data. SessionEvent.seq remains the only event version. */
export type BrowserCommandEvent = BrowserCommandEnvelope;
/** Internal plain-JSON fold state; the admitted command is hidden by `view` until published. */
export interface BrowserCommandProjectionFoldState {
    readonly visible: BrowserCommandProjectionState;
    readonly admitted?: BrowserCommandEnvelope;
    readonly admittedResult?: BrowserCommandResultEvent;
}
/** Durable admitted-result event data. It repeats only safe command identity and fields, never a revision or token. */
export type BrowserCommandResultEvent = {
    readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
    readonly requestId: string;
    readonly sessionId: string;
    readonly matchId: string;
    readonly seat: string;
    readonly command: BrowserCommandEnvelope;
    readonly status: "completed";
    readonly receipt: BrowserCommandReceipt;
} | {
    readonly protocolVersion: typeof BROWSER_TRANSPORT_PROTOCOL_VERSION;
    readonly requestId: string;
    readonly sessionId: string;
    readonly matchId: string;
    readonly seat: string;
    readonly command: BrowserCommandEnvelope;
    readonly status: "failed" | "cancelled";
    readonly failure: BrowserCommandFailure;
};
/** Durable result marker data; the full result remains in the preceding admitted event. */
export type BrowserCommandResultMarkerEvent = BrowserCommandResultPublicationEvent;
declare module "@deepseek-ai/dsh-session" {
    interface SessionEventMap {
        /** One safe command admitted to the browser outbox; it is not visible until the marker. */
        "red-alert/browser-command-admitted": BrowserCommandEvent;
        /** Makes an already-flushed command visible to the browser projection. */
        "red-alert/browser-command-published": BrowserCommandPublicationEvent;
        /** One safe browser command outcome admitted by the Host; it is not visible until its marker. */
        "red-alert/browser-command-result": BrowserCommandResultEvent;
        /** Makes an already-flushed browser command outcome visible to the projection. */
        "red-alert/browser-command-result-published": BrowserCommandResultPublicationEvent;
    }
}
declare module "@deepseek-ai/dsh-session/types" {
    interface SessionEventMap {
        /** One safe command admitted to the browser outbox; it is not visible until the marker. */
        "red-alert/browser-command-admitted": BrowserCommandEvent;
        /** Makes an already-flushed command visible to the browser projection. */
        "red-alert/browser-command-published": BrowserCommandPublicationEvent;
        /** One safe browser command outcome admitted by the Host; it is not visible until its marker. */
        "red-alert/browser-command-result": BrowserCommandResultEvent;
        /** Makes an already-flushed browser command outcome visible to the projection. */
        "red-alert/browser-command-result-published": BrowserCommandResultPublicationEvent;
    }
}
declare module "@deepseek-ai/dsh-session-projection/types" {
    interface SessionProjectionMap {
        /** Latest browser command state for the current DSH session. */
        redAlertCommand: BrowserCommandProjectionState;
    }
    interface SessionProjectionStateMap {
        /** Internal durable fold state; admitted values stay hidden until publication. */
        redAlertCommand: BrowserCommandProjectionFoldState;
    }
}
export type BrowserProtocolErrorCode = "INVALID_MESSAGE" | "PROTOCOL" | "IDENTITY" | "LEASE";
/** Bounded protocol error used before any engine or RPC error can cross the boundary. */
export declare class BrowserProtocolError extends Error {
    readonly code: BrowserProtocolErrorCode;
    constructor(code: BrowserProtocolErrorCode, message: string);
}
/** Validate a renderer tool result before it becomes durable or model-visible. */
export declare function decodeBrowserToolValue(value: unknown): BrowserToolValue;
/** Validate one renderer result against the exact tool that produced it. */
export declare function decodeBrowserToolResult(request: BrowserGameToolRequest, value: unknown): BrowserToolValue;
export declare function decodeBrowserMatchSnapshot(value: unknown): BrowserMatchSnapshot;
/** Decode the only observation shape that may be placed in a browser receipt. */
export declare function decodeBrowserObservation(value: unknown): FogSafeObservation;
/** Decode a safe command envelope from a durable projection or adapter boundary. */
export declare function decodeBrowserCommand(value: unknown): BrowserCommandEnvelope;
/** Decode a strict lease registration request. */
export declare function decodeBrowserLeaseRequest(value: unknown): BrowserLeaseRegisterRequest;
/** Compatibility-named alias used by the Host transport endpoint. */
export declare const decodeBrowserLeaseRegisterRequest: typeof decodeBrowserLeaseRequest;
/** Decode the opaque lease value returned by the Host. */
export declare function decodeBrowserLeaseValue(value: unknown): BrowserLeaseValue;
/** Decode a strict lease release request. */
export declare function decodeBrowserLeaseReleaseRequest(value: unknown): BrowserLeaseReleaseRequest;
/** Decode a lease-bound live renderer config request. */
export declare function decodeBrowserRendererConfigRequest(value: unknown): BrowserRendererConfigRequest;
/** Decode a loopback-only live renderer config value. */
export declare function decodeBrowserRendererConfigValue(value: unknown): BrowserRendererConfigValue;
/** Decode the receipt accepted by the Host. Lease tokens are checked separately. */
export declare function decodeBrowserReceipt(value: unknown): BrowserReceiptRequest;
/** Decode a safe receipt without the in-memory lease token. */
export declare function decodeBrowserCommandReceipt(value: unknown): BrowserCommandReceipt;
/** Enforce the command/result relationship before a receipt becomes durable or model-visible. */
export declare function validateBrowserCommandReceipt(command: BrowserCommandEnvelope, receipt: BrowserCommandReceipt): BrowserCommandReceipt;
/** Decode a persisted admitted failed or completed command result. */
export declare function decodeBrowserCommandResult(value: unknown): BrowserCommandResultEvent;
/** Decode the marker that exposes a previously flushed command result. */
export declare function decodeBrowserCommandResultPublicationEvent(value: unknown): BrowserCommandResultPublicationEvent;
/** Decode the durable command event without accepting lease or engine fields. */
export declare function decodeBrowserCommandEvent(value: unknown): BrowserCommandEvent;
/** Decode the marker that exposes only a previously admitted command. */
export declare function decodeBrowserCommandPublicationEvent(value: unknown): BrowserCommandPublicationEvent;
/** Convert a completed result into the client projection state. */
export declare function projectBrowserCommandResult(result: BrowserCommandResultEvent): BrowserCommandProjectionState;
/** Runtime guard for an exact projection value read from the DSH client store. */
export declare function decodeBrowserCommandProjection(value: unknown): BrowserCommandProjectionState;
/** Build a bounded protocol failure for the official Connection RpcResult shape. */
export declare function browserRpcError(code: string, message: string): RpcResult<never>;
/** Keep event types visible to declaration emit without importing a second runtime. */
export type { FogSafeContact, FogSafeObservation, SessionEvent };
