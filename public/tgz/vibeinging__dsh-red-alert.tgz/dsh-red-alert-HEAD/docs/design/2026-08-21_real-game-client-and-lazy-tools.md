# 真实红警客户端与按需工具设计

状态：当前实现设计，2026-08-23。历史 spike 结论保留在 `docs/reports/`，本文只描述已经接入正式插件的结构。

## 1. 总体结构

```text
DSH Profile
  |
  +-- @vibeinging/dsh-red-alert Host
  |     +-- MatchService
  |     +-- lazy ToolRegistry
  |     +-- Session event / projection
  |     +-- BrowserCommandTransport
  |     `-- plugin-owned loopback renderer server
  |
  +-- DSH Web client
        +-- canonical Chat workspace
        |     +-- user/model/tool transcript
        |     `-- composer
        +-- right battlefield dock
        |     `-- sandboxed cross-origin iframe
        `-- BrowserCommandClientService
                 |
                 `-- FormalRendererCompanion
                        +-- compatible RA2 Web engine
                        +-- CurrentLos
                        `-- FogSafeObservation
```

MatchService 是 DSH 侧唯一对局所有者。兼容客户端中的引擎是实际游戏真相，右栏画面和工具动作都由这一个实例产生。历史离线 MatchController 只保留兼容路径，配置真实 renderer 后不能替代浏览器 authority。

## 2. 不浸入式 DSH 挂载

- `package.json` 通过 `dsh.bundle.patch` 指向 `cordis.patch.yml`。
- patch 只插入插件 Host、官方 invariants 服务和插件 invariant companion。
- session projection、client connection、conversation 和 Web server 都使用官方 NPM SDK。
- Host/client 构建不引用 `~/.dsh/source/current` 或其他 DSH 源码 checkout。
- dual-face 包公开 `.`、`./client`、`./invariant`、`./package.json` 和 `./cordis.patch.yml`。
- client handoff id 与 NPM package id 相同，DSH ClientModuleHost 从 Profile 安装位置解析。

renderer 不进入 DSH origin。Host 在 `127.0.0.1` 启动插件自己的静态 server，只接受精确 Host、GET/HEAD 和安全路径。实际端口通过当前 live connection 返回，不进入模型、Chat 或 session 日志。

## 3. 兼容客户端交付

正式仓库不复制第三方源码树，而保存以下可审查材料：

- 上游地址：`https://github.com/huangkaoya/redalert2.git`
- 锁定提交：`8c07f1092b2a9e8d8605ed49ef46d77b6c3ea367`
- adapter 补丁：`renderer-adapter/patches/redalert2-8c07f109.patch.gz.base64`
- 补丁门禁：`scripts/check-renderer-adapter.mjs`
- 一键准备：`scripts/prepare-compatible-renderer.mjs`

准备脚本在新目录 clone 锁定提交，校验 SHA，应用主 adapter 和同源自动资源补丁，运行 companion 专项测试并构建 `dist/`。脚本拒绝已有目录，因此不会静默覆盖用户源码。客户端代码和补丁为 GPLv3；renderer 准备本身不下载游戏素材。

## 4. 用户资源导入

推荐路径由用户或安装模型明确执行带 `--download-resources` 的 setup。setup 先打印第三方地址、固定大小、SHA-256 和权利提示，再流式下载到 `$DSH_HOME/red-alert/renderer-v5/dist`，校验通过后才改名为正式本地归档。renderer 首次只自动接受自己的固定同源路径，并让正在等待的建局继续执行；嵌入 DSH 时静音启动，不用音频授权弹窗阻塞首次建局。

未传下载参数时不发生素材网络请求，兼容客户端保留可见的本地归档入口。最小清单只包含 `RA2.MIX`、`LANGUAGE.MIX`、`MULTI.MIX`；音乐、Taunts、电影、`exe` 和 `dll` 不需要。旧父页面 resource provider 仍只负责非真实 renderer 的浏览器缓存展示，不再作为真实兼容客户端的主要导入路径。

## 5. 浏览器身份和消息协议

每个 bridge 消息都带：

- `protocolVersion`
- `sessionId`
- `matchId`
- `seat`
- `tick`

RendererBridge 同时校验精确 origin、`event.source === iframe.contentWindow`、连接状态和单调 tick。只有 `ready` 状态可以接受观察和命令回执；hello、ready、error、disconnected 的状态转移受限。已取消 AbortSignal 在 postMessage 前直接返回 `CANCELLED`。

Host 命令使用两段发布：

1. 追加 `red-alert/browser-command-admitted` 并 flush。
2. 追加 `red-alert/browser-command-published`，client 才看到 pending。

结果同样使用两段发布：

1. 追加 `red-alert/browser-command-result` 并 flush。
2. 追加 `red-alert/browser-command-result-published`，Host 才结算工具。

半完成、晚到、不同身份或旧 tick 的回执全部失败关闭。原始 adapter 异常不会进入模型或日志，只返回稳定 code 和通用文案。

## 6. UI 生命周期

插件不注册与 Chat 平级的红警 conversation view，而是通过官方 layout SDK 在原生 Chat 右侧打开战场 dock。Chat 的用户输入、模型输出和工具调用始终留在中间区域；顶部“战场”动作只控制右栏展开、放大和收起。RendererContainer 只在 React effect 中创建 bridge、attach 和 connect，cleanup 时 dispose。

关键规则：

- 展开、放大或收起右栏不把 Chat 换成另一个页面，也不卸载 iframe。
- 对局中用户可用左键拖动画面、点击或拖动小地图、方向键和滚轮移动观战镜头；嵌入模式屏蔽选择、生产和战斗输入，不能绕过 Chat 替模型下命令。
- 可恢复 `error` 且 match 仍 active 时，继续显示同一个 MatchView。
- client root 在可恢复 error 中仍保留 match identity，并继续消费同一 session 的命令。
- 命令拒绝不会让 bridge 离开 ready。
- endpoint 改变或 adapter dispose 后才重建。

因此一次错误不会把右栏对局和 Chat 工具拆成两局。

## 7. 公平观察

FormalRendererCompanion 位于受信的兼容客户端内部，可以读取 world 以计算 LOS，但出边界的数据只能通过 `FogSafeObservation` 白名单。

```text
engine world
   |
   +-- CurrentLos: own and legal allied living vision sources
   |       +-- sight radius
   |       +-- transient shroud
   |       `-- tile occupation
   |
   +-- visible now --------------------> visibleEnemies
   |
   +-- visible -> hidden transition ---> frozen lastSeenEnemies
   |
   `-- hidden/raw/debug --------------> blocked
```

当前可见对象才可复制合法字段。伪装对象在未被合法识破前先由 `isModelObservable` 阻断，不能通过真实 id、owner、type、name、tile 或 health 反推身份。

迷雾外销毁不会通过 `liveWorldIds` 清理 last-seen；如果销毁时仍可见，则对象从 current visible 移除并保留最后合法观察。renderer filter 和 bridge 使用同一 CurrentLos。

建筑放置执行以下步骤：

1. 从模型给出的当前可见 anchor 开始，以最近距离搜索最多 12 格。
2. 用 `gameApi.mapApi.getTile` 解析候选。
3. 确认完整地基矩形每一格都在 CurrentLos。
4. 才调用 `canPlaceBuilding`。
5. 调用 `placeBuilding` 并返回引擎实际接受的精确 `placement`。

这个设计不会为了找到可放位置而扫描或暴露迷雾内地形。

## 8. 方法策略和精确工具

`src/tool-policy.ts` 是唯一方法表。`check:tool-policy` 读取锁定 game-api declaration AST，核对七个 owner：

- `PublicApi`
- `GameInstanceApi`
- `GameApi`
- `MapApi`
- `PlayerApi`
- `ProductionApi`
- `ActionsApi`

85 个公开声明全部有决定。允许的引擎能力和插件自有学习能力映射到 22 个 manifest 项；全量 getter、debug、原始 ini、随机数、内部 pathfinding 和未过滤对象方法为 internal/deny。

目标不是把每个底层函数逐个裸露给模型，而是让每个正常玩家能力都有最小、可验证、不会泄漏隐藏状态的精确 wrapper。

## 9. 按需组加载

初始全局 registry 包含 22 个 manifest 工具，但当前 Agent 的模型 schema 只允许两个 bootstrap 工具。`red_alert_load_group` 的原子流程为：

1. 验证 group、session owner 和当前 phase。
2. 计算该组已实现工具和有序唯一 methodKeys。
3. append 并 flush version 1 的 `red-alert/tool-group-selection`。
4. 发布该组 schema 和 phase restriction。
5. 任一步失败则回滚原集合并记录失败。

decoder 接受历史无 version 的 v0，拒绝未知版本、未知字段、损坏数据、未知方法和跨组方法。恢复时从 session log 重放选择，再按当前 phase 重新收紧。

`red_alert_act` 已删除。production、construction、units、diplomacy 和 superweapon 都有独立 wrapper。

`red_alert_unit_order` 只执行模型给出的有序 `orders[]`。插件不得启动后台战术循环，也不得自动观察、选择目标、拆分编队、撤退或进攻；模型必须从最新 `commandView` 亲自选择精确己方 ID、当前可见目标或合法 last-seen 坐标。Host 和 renderer 只做 schema、身份、所有权、当前可见性和 tick 校验。

## 10. 工具与对局阶段

| 阶段 | 可加载能力 |
| --- | --- |
| catalog-only | bootstrap、strategy brief、lobby create |
| lobby-ready / lobby-created | 公开地图和席位准备 |
| running | observation、units、production、construction、diplomacy、superweapon |
| ended | structured strategy review、下一局 lobby create、status 和允许的生命周期查询 |
| stopped | status、stop 和允许的生命周期查询；不生成自然终局 episode |
| recoverable error + active match | 保持 running 精确工具，用于同局恢复 |

每次工具调用都再次检查 owning session、`matchId`、seat 和 phase；只靠 schema 隐藏不是安全边界。

## 10.1 自动学习和紧凑命令结果

自然终局状态写入时，Host 在同一次 flush 中从当前 session 的公平状态和已准入命令事件派生 `red-alert/strategy-episode`。episode 只保留结果、公开选择器、最大当前可见敌军数、最大己方战斗单位数、首次接敌、首次装甲、读写命令数、失效所有权错误以及模型提交的单位批次、order、攻击和撤退计数，不读取 renderer raw world。

候选经验只能取 `rush-defender-target`、`anti-infantry-defense`、`armor-before-contact`、`fresh-owned-ids`、`act-before-reread` 和 `sustain-model-attacks`。模型通过 ended 阶段的 `red_alert_review_match` 提交采用和拒绝集合；未知值、重复值、交叉集合和重复改写都失败关闭。未复核的单局规则只以 experimental 返回；模型采用或至少两局重复证据后才标为 confirmed。

新 session 的第一局在 catalog-only 阶段加载 `strategy/learning` 后调用 `red_alert_strategy_brief`。同一 Chat 的自然终局先调用 `red_alert_review_match`，再使用它返回的 `nextMatchBrief` 调用 `red_alert_start`；Host 释放旧 match lease、为新 `matchId` 重新绑定 root renderer，并保留同一 session 的可审计历史。Host 只按地图、己方阵营和对手类型读取最多 `strategyHistoryLimit` 局，返回最多 `strategyMaxRules` 条规则，并把实际 brief 写入 session 日志。

真实精确工具的原子 receipt 同时产生 `commandView`。每类接触最多 128 项，保留 id、type、kind、位置、生命值和观察 tick；当前可见和 last-seen 的来源仍是同一个 `FogSafeObservation`。它只减少重复 status、observe 和 catalog 往返，不改变 session 单 pending 顺序。

## 11. 已验证状态

真实 DSH Profile 中：

- 初始只见 bootstrap，组选择事件 version 1 且 `outcome=committed`。
- Chat 创建的 match 与 iframe、bridge 和引擎 match 一致。
- 单位移动、SMCV 部署、NAPOWR 排队和建筑放置作用于同一局。
- 建筑工具在 tick 5093 返回 `placement={x:134,y:77}`，最终 tick 5207 的公平观察中出现 `NAPOWR`。
- 右栏显示真实地图、HUD、小地图、战争迷雾、单位和建筑，中间 Chat 同屏显示模型输出和用户输入。

完整证据见[最终验收报告](../reports/2026-08-22_dsh-real-client-final-acceptance.md)。

## 12. 保留边界

- 同一 client 生命周期内 requestId exactly-once；跨浏览器或 Host 崩溃的 pending command 不作 exactly-once 承诺。
- 历史离线 controller 和 debug 投影可以用于测试，但不能替代真实页面。
- 不分发 EA 素材，不把开源客户端许可误当成素材许可。
- 不修改 DSH 源码，不自动提交、推送或发布。
