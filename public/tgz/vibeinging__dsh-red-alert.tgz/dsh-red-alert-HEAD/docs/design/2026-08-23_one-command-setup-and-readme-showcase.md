# One-command setup and README showcase

## Goal

The repository landing page must show the assembled product before its internal architecture: a real Red Alert 2-compatible battlefield in the DSH right panel, the model's reasoning and tool calls in canonical Chat, user steering, fair fog-of-war observations, and evidence-based post-match learning.

## README media contract

README media uses full 1440 by 900 DSH screenshots rather than cropped game-only images. Each image keeps the DSH sidebar, Chat surface, user input area, model output, and right-side battlefield visible so the page does not imply that a standalone renderer or a debug view is the accepted product.

The three checked-in WebP images under `docs/readme-media/` cover a running long match, live command execution, and a natural defeat followed by structured review. Their captions state that the game resources came from the user's local import. The repository and NPM package do not include Red Alert 2 art, sound, movie, executable, or DLL assets. The media directory is intentionally separate from the ignored root game-resource directories.

## Setup contract

`pnpm run setup -- --profile <name> --download-resources` is the convenient entry point for a user who already has a working DSH Web Profile and NPM access to the official `@deepseek-ai/*` SDK packages. It does not bootstrap DSH itself. Omitting `--download-resources` keeps the visible local-archive fallback and performs no game-resource network request.

The command checks pnpm and the DSH CLI, validates the selected base Profile through `--dump-default-config` without loading a previously mounted broken user plugin, installs the locked repository dependencies in source mode, builds the plugin, prepares the locked compatible renderer when a usable renderer is not already present, mounts this repository through the official `dsh plugin` Profile command, and verifies that the final resolved Profile contains `@vibeinging/dsh-red-alert`. First preparation checks Git and runs exact `bun@1.3.14` through `pnpm dlx`; users do not install global Bun. A prepared renderer is reused only when its marker matches the locked upstream URL and commit, and reuse does not check Git or Bun.

The command stores the selected Profile, package identity, absolute renderer distribution path, one stable loopback renderer port, and verified local archive metadata in `$DSH_HOME/red-alert/install.json`. `pnpm exec dsh-red-alert` or the source-checkout `pnpm run dsh` validates that state and launches the selected Profile with `RA_RENDERER_DIST_DIR` and `RA_RENDERER_PORT`; it does not copy settings into a DSH source checkout or write runtime state inside `node_modules`. The launcher removes an explicit `--open`, deduplicates `--no-open`, and always passes one final `--no-open`, so it only prints the DSH address and cannot create browser tabs. Setup reuses the previous valid port for the same Profile even when the compatible renderer directory changes between adapter revisions, or selects the first free port from 4317 through 4367. The stable origin preserves browser-imported resources across upgrades and restarts.

The explicit download flag prints the RA2WEB candidate URL, exact byte length, pinned SHA-256, and rights notice before fetching. Node downloads the response into a unique `.part` file, rejects a missing or changed Content-Length before streaming, enforces the byte ceiling during streaming, verifies the final digest, and only then renames it to `renderer-v5/dist/dsh-red-alert-resource.7z`. Any failure removes the unfinished file. The NPM package and repository never contain the archive.

The adapter revision adds a fixed same-origin resource path to the compatible client. On the first resource prompt it issues a HEAD request and auto-selects only `/dsh-red-alert-resource.7z` on the current renderer origin with no query or fragment. It attempts this path once. Missing content or a failed import falls back to the visible local selector, preventing a retry loop. Public third-party URLs never satisfy the automatic-import boundary. Because create-match has a configurable 600000 ms timeout, separate from the 120000 ms normal command timeout, a verified local import can finish initial extraction and resume the same pending create without requiring a second Chat request.

## Failure behavior

Setup stops at the first failed prerequisite or command. The pre-mount Profile check excludes user plugin layers, so an installed plugin that fails for missing renderer environment cannot block its own repair. A missing DSH command names the exact supported package version. Missing Git is reported only during first renderer preparation. Dependency failures call out that an NPM 404 for `@deepseek-ai` means the current account lacks the required official SDK package. An existing but incomplete renderer directory is never overwritten; the user must choose a new directory or remove the incomplete directory themselves. Adapter revision 5 uses the new default `$DSH_HOME/red-alert/renderer-v5` directory, so earlier renderer revisions are preserved while setup builds camera-only viewer controls and blocks user UI actions from entering the match. An unavailable explicit renderer port also fails before Profile mutation; users may choose another port with `--renderer-port`.

Starting the mounted plugin through ordinary `dsh web` cannot supply the renderer and early session-vocabulary environment owned by the Red Alert launcher. The load-time error therefore names setup and `pnpm exec dsh-red-alert` as the recovery path. The launcher prints the exact resource URL and setup command before DSH starts when verified resource state is absent. The public Profile patch no longer exposes the legacy `RA_ASSETS_DIR` headless variable.

`--dry-run` validates the Profile name and prints the exact command plan, target state file, and renderer environment without running external commands or changing files. Profile names accept only letters, numbers, dot, underscore, and hyphen, and cannot start with punctuation.

## Release boundary

The setup path improves installation inside the external-plugin boundary. The public plugin and NPM package use `GPL-3.0-only`, while EA game assets remain excluded. Version `0.1.2` intentionally targets only `@deepseek-ai/dsh@0.1.1-rc.2`; older DSH release candidates are not supported. The published package declares its browser entry through `dsh.client`, stores setup state under `$DSH_HOME/red-alert`, and can prepare and mount itself without rebuilding inside `node_modules`.
