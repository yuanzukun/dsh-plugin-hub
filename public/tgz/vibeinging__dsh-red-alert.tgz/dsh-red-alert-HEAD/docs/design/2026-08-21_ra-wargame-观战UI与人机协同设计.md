# 观战 UI 与人机协同推演（统帅训令）设计

> 日期：2026-08-21
> 上游：[完整技术方案](./2026-08-21_ra-wargame-ai红警兵棋推演完整方案.md)、[产品形态](./2026-08-21_ra-wargame-产品形态与预期效果.md)
> 本轮需求：对局 UI 可视化 + 部署设计 + **统帅训令**（人经自然语言干涉 AI，人不直接控制兵员）

## 一、产品形态：人机协同观战台

```
┌──────────────────────────────────────────┬───────────────────┐
│                                          │ 红方 dsv4flash  │
│         战场态势图（Canvas 2D）            │   资金 5230 电力   │
│   建筑方块 / 兵力圆点 / 敌接触红色标记      │   ▂▃▅▇ 生产队列   │
│   （敌单位仅显示可见 —— 战争迷雾真实）      │ ─────────────────│
│                                          │ 决策流（侧栏）   │
│   [AI 思考中…] 指示灯（决策周期暂停时）     │  t3240 训令      │
│                                          │   "注意金钱，该建   │
│                                          │    电厂了"          │
│                                          │  t3240 assessment  │
│                                          │  t3240 orders×5    │
│                                          │  …                 │
├──────────────────────────────────────────┴───────────────────┤
│ 统帅训令输入框：[使用三路进军________] [下发]  （AI 下轮必读） │
└──────────────────────────────────────────────────────────────┘
```

### 统帅训令协议（核心约束：人不直接控兵）
- 人 → 输入框 → WS → 训令队列 → **注入下一决策周期 prompt 的 [统帅训令] 段**
- AI 指挥官自主解读为指令（可采纳/可结合态势调整，须在 assessment 回应训令）
- 人看不到的敌人，训令也无能为力（战争迷雾公平性：AI 只按自己可见态势执行）
- 设计动机：保持"可解释、可干预"两条产品原则 —— 干预是给意图，不是夺权

## 二、架构

```
浏览器 (web/index.html, 单文件零构建)
  │ WS ↑ 战场帧(每15t)/决策帧(每周期)/状态   │ WS ↓ 统帅训令
  │ HTTP GET / (静态页)                      │
┌─▼──────────────────────────────────────────┐
│ game-host 进程（serve 模式）                 │
│  ├ http server (静态 UI)                    │
│  ├ ws broadcast: battlefield frames         │
│  ├ directive queue（训令去重/上限 5 条待处理）│
│  ├ 主循环（不变）+ 每决策周期携带训令         │
│  │   LLM 思考期间推 thinking 状态帧          │
│  └ Chrono Divide headless 引擎（进程内）     │
└─────────────────────────────────────────────┘
```

- **服务内嵌**：不起独立后端 —— game-host 单进程既是引擎又是 server（本地/单容器部署最简）
- **帧协议**（WS JSON）：
  - `{type:"battle", tick, units:[{id,name,side,x,y,hpPct,kind}], buildings, thinking?:bool}`
  - `{type:"decision", tick, cycle, assessment, orders, receipts, directives}`
  - `{type:"meta", mapW, mapH, players}`（连接时一次）
  - `{type:"end", stats}`
  - 客户端 ← `{type:"directive", text}`（统帅训令，服务器回执 ack）
- **渲染决策**：自绘 2D 俯视网格（兵棋推演视图），不做等距游戏渲染 —— 推演观战要的是态势清晰而非画面仿真；回放级画面留给 Chrono Divide 客户端放 .rpl（M2 后期接）

## 三、部署设计

### 本地开发（当前实现）
```sh
RA_COMMANDER=dsh RA_OPPONENT=supalosa RA_SERVE=1 pnpm --filter @ra-wargame/game-host run match
# → http://localhost:7860 观战 + 训令
```

### 单容器（云部署，Docker）
```
Dockerfile: node:24-slim
  COPY ra-wargame + assets(mix, 3MB, 需挂载或私有源)
  CMD: node serve (RA_COMMANDER=dsh)
```
- 无状态（对局产物落 artifacts 卷）
- 端口：7860（HTTP+WS 同端口）
- 密钥：DEEPSEEK 凭据走 dsh 容器内 ~/.dsh（secret 挂载）
- 资源：单局 1 vCPU / 512MB 足够（模拟侧开销可忽略，LLM 在云端）
- 限制：并发对局 = 并容器（每局一进程，K8s Job / docker compose scale）

### 云端拓扑（多局并发，M3）
```
LB → N × wargame-pod（每 pod 一局，WS 长连）
     ↑ 训令/观战路由按 matchId
dsh Runtime（共享，凭据集中）
```

## 四、实现清单（本轮）

1. `serve.ts`：HTTP 静态 + WS 广播 + 训令队列（game-host 内）
2. `web/index.html`：canvas 战场 + 决策侧栏 + 训令输入框（零构建单文件）
3. `Commander.decide(snapshot, directives)`：DshCommander prompt 注入 [统帅训令] 段；MockCommander 忽略
4. `run-match.ts`：serve 模式（RA_SERVE=1），主循环推帧，决策周期带训令
5. 验证：mock 对局 + 浏览器观战 + 训令注入端到端
