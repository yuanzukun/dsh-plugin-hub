# RA-Wargame：基于原版 DSH 的 AI 红警兵棋推演平台 — 完整方案

> 日期：2026-08-21
> 前置调研：[网页版红警开源调研](../research/2026-08-21_网页版红警开源调研与dsh结合ai兵棋推演可行性.md)
> 结论：**可行，技术疑点已全部源码级确认。**

## 0. 一句话方案

用 **Chrono Divide headless Game API** 做确定性的红警 2 模拟引擎，用**原版 DeepSeek Harness（dsh）**做 AI 指挥官的 agent 运行时，中间写一个**游戏桥（game-host）**负责"战场快照 → LLM 决策 → 指令翻译"，实现 AI vs AI / AI vs 人的红警兵棋推演，产出决策日志与回放。

**不基于桌面版（dsh-app/Electron）**：只用原版 dsh 的公开扩展面（headless CLI / MCP client / ACP），不 fork、不改 dsh 源码。游戏侧为独立项目。

## 1. 目标与非目标

### 目标
1. AI 指挥官（dsv4flash，2~3 s/决策）能完整打完一局红警 2，对内置 AI / 规则 bot 有胜负结果
2. 双 AI 对推（红蓝双方独立 dsh 会话、可配不同人格与战略风格）
3. 全程可复盘：每一步决策（快照 + 指令 + 理由）落盘，对齐 Chrono Divide 回放文件
4. 推演可分叉：利用 dsh session fork，从同一战局状态推演不同决策分支并对比
5. 真人可参战：Chrono Divide online 模式下人机实时对抗

### 非目标
- 不做新的游戏客户端/UI（复用 Chrono Divide 引擎与其网页客户端放回放）
- 不追求 LLM 微操单兵（微操默认规则化，LLM 只到编队级指令）
- 不做官方服务器大规模在线对战（M3 之前不碰 xwol 在线基础设施）

## 2. 两侧事实（已源码级确认）

### 2.1 游戏侧：@chronodivide/game-api@0.78（npm 包，TS）

| 能力 | API | 要点 |
|---|---|---|
| 驱动 | `PublicApi.init(mixDir)` → `createGame(opts)` | offline 模式纯沙盒，自带 `headless-mix.zip` 最小资源，**无需原版 RA2** |
| 模拟控制 | `GameInstanceApi.update(): Promise<void>`、`isFinished()` | **host 逐 turn 推进且是 async** —— LLM 思考期间不调 update 即天然暂停，无实时性冲突 |
| bot 接入 | `Bot` 基类：`onGameStart/onGameTick(gameApi)` | 同步 void 回调，只做轻量记账；决策在 host 循环层做 |
| 读状态 | `getPlayerData()`（credits/power/country/startLocation）、`getVisibleUnits(type, filter)`（self/allied/hostile/enemy + 规则过滤器）、`getUnitData(id)`、production 队列、radar 事件流 | 战争迷雾由 `getVisibleUnits("enemy")` 天然强制 —— LLM 只能看到该看的 |
| 下指令 | `placeBuilding` / `queueForProduction`(+unqueue/pause/resume) / `orderUnits(ids, orderType, targetUnit|rx,ry)` / `activateSuperWeapon` / `sellObject` / `toggleAlliance` / `sayAll` | 全同步，host 层随意调用 |
| 产物 | `saveReplay(dir)`、`getPlayerStats()` | 回放文件 + 战后统计，复盘素材现成 |
| 节奏 | 自然速率 15 tick/s；offline 模拟"以最快速度"跑 | offline 无实时约束，决策周期按 tick 计：战术 30~45 tick、战略 150~450 tick |

参考实现：Supalosa bot（monorepo：bot + driver，含 vitest 整局测试、两张测试地图）。

### 2.2 Agent 侧：原版 dsh（~/.dsh/source/current，Cordis 插件架构，"一切皆插件"）

| 扩展点 | 形态 | 适用 |
|---|---|---|
| headless | `dsh --profile headless "task" --output-format json` — one-shot：跑完一 turn、打印、退出；每次全新 session | M1：每个决策周期一次调用，零耦合 |
| MCP client | `@deepseek-ai/dsh-mcp-client` 插件，stdio/streamable-http 连任意外部 MCP server，工具名 `mcp__<server>__<name>` | M2：游戏桥作为 MCP server 暴露 tool |
| ACP | `pnpm run demo:acp` — Agent Client Protocol 自动化服务器，外部程序驱动长驻交互会话 | M2：orchestrator 驱动有记忆的指挥官会话 |
| 自定义 tool 插件 | Cordis 插件内 `ctx.tools.register(ToolDefinition)`，schema 自动进 system prompt | M3：去掉 MCP 间接层 |
| 会话能力 | 持久化/恢复/fork/查询、上下文压缩、subagent、遥测 | fork → 分支推演；压缩 → 长局记忆 |

模型：dsv4flash，单次决策 2~3 s —— 对应战术周期 30~45 tick（2~3 s 游戏时间），节奏匹配。

## 3. 总体架构

```
┌─────────────────────────────── Orchestrator CLI ───────────────────────────────┐
│  ra-wargame run --red dsh:dsv4flash --blue builtin-ai --map simple-1v1          │
│  ra-wargame replay <match-dir>   │  ra-wargame fork <match-dir>@<cycle>        │
└──────┬─────────────────────────────────────────────────────────────────────────┘
       │
┌──────▼───────────────── game-host（核心，TS 包） ───────────────────────────────┐
│                                                                                 │
│   main loop: while (!instance.isFinished()) {                                   │
│     await instance.update()                    // 逐 turn，天然可暂停            │
│     if (tick % tacticalPeriod == 0) {                                           │
│        snapshot = SnapshotBuilder.build(gameApi)   // 战场快照（聚合、降维）     │
│        orders   = await Commander.decide(snapshot) // → dsh（LLM 指挥官）        │
│        OrderTranslator.apply(orders, actionsApi)   // 高层指令 → 引擎调用        │
│        DecisionLog.append(cycle, snapshot, orders) // 决策留痕                  │
│     }                                                                           │
│   }                                                                             │
│   saveReplay(); exportStats();                                                  │
│                                                                                 │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌────────────────────┐      │
│  │LLMCommanderBot│ │SnapshotBuilder│ │OrderTranslator│ │DecisionLog(JSONL) │      │
│  │extends Bot    │ │快照 schema     │ │指令 schema+校验│ │+回放对齐          │      │
│  └──────────────┘ └──────────────┘ └──────────────┘ └────────────────────┘      │
└──────┬──────────────────────────────────┬───────────────────────────────────────┘
       │ M1: subprocess                    │ M2+: MCP server (stdio/http)
       ▼                                  ▼
┌─────────────────┐              ┌─────────────────────┐
│ dsh --profile    │              │ dsh profile:        │
│ headless "…"     │              │ dsh-base +          │
│ --output-format  │              │ dsh-mcp-client →    │
│ json             │              │ game-host MCP tools │
│ (one-shot/周期)   │              │ (ACP 长驻会话)       │
└─────────────────┘              └─────────────────────┘
```

**职责边界**：游戏桥拥有模拟与全部游戏 IO；dsh 只做"读快照 → 推理 → 出指令 JSON"，通过公开扩展面接入，两侧可独立演进。

## 4. 组件设计

### 4.1 game-host（TS 包，monorepo 根）

**LLMCommanderBot（extends Bot）**
- `onGameStart/onGameTick` 只做同步轻量记账（编队维护、事件缓冲），不做决策
- 编队管理器（FormationRegistry）：把己方作战单位按类型/区域聚成 group（如 `G1: rhino×8 @sector-D3`），LLM 只操作 group id，不碰裸 unit id —— 这是 token 经济性与指令稳定性的关键
- 决策由 host 主循环在 `update()` 间隙发起（见架构图）

**SnapshotBuilder — 战场快照 schema（LLM 输入）**

分层聚合，常规局目标 < 2K tokens：

```yaml
snapshot:
  tick, gamePhase: early|mid|late
  self: { credits, power{total,drain,isLowPower}, country, radarOn }
  economy: { harvesters{idle,harvesting,queued}, refineryCount, oreFields: [{sector, contended}] }
  military:
    ownGroups: [{groupId, unitType, count, avgHpPct, sector, stance, mission?}]
    enemyContacts: [{unitType, count, sector, firstSeenTick, threat}]   # 仅 getVisibleUnits("enemy")
    lostUnits: {own, enemy}                                             # 本周期战损
  production: { queues: {vehicles: {status, items[{name,qty}]}}, buildPowerReady: bool }
  map: { size, sectors: "热力图摘要(控制权/威胁)", landmarks: [ore,oils,bridges] }
  events: [最近 N 条 radar 事件 + 上一周期指令执行结果反馈]
  history: [最近 K 条决策摘要（意图+结果）]    # M1 无状态模式的记忆载体
```

**OrderTranslator — 指令 schema（LLM 输出）**

JSON schema 约束（headless 模式用 prompt+校验，M2 用 tool 参数 schema 强约束）：

```yaml
orders:
  - economy: { place_building: {name, sectorHint} } | sell | toggle_repair
  - production: { queue: {unitName, qty} | unqueue | pause | resume, rationale }
  - military: { groupOp: {groupId, op: attack_move|move|attack_target|guard|scatter|retreat,
               destSector | targetContactId} }        # 编队级
  - intel: { scout: {sector} }
  - superweapon: { launch: {type, sector} }
  - meta: { stance: aggressive|defensive|expansion, taunt: string?, yield: bool? }
  every order carries: { reason: string, confidence: 0..1, horizon: tactical|strategic }
```

- 校验失败 → 单条丢弃并反馈到下周期 `events`，不整包重试（省一次 LLM 往返）
- `reason` 是推演复盘与训练指挥官 prompt 的核心素材

**DecisionLog**：每周期一行 JSONL（快照指纹 + 完整指令 + 理由 + 引擎执行回执），`saveReplay()` 的回放文件与之按 tick 对齐。

**决策节奏（StrategyClock）**
- 战术周期 30~45 tick（≈2~3 s 游戏时间）→ 触发 dsv4flash 一次
- 战略周期 150~450 tick → 同一次调用内输出 `horizon: strategic` 指令，不另开调用
- offline 模式"最快速度"只受 LLM 真实耗时限制：一局 20 分钟游戏时间 ≈ 400 战术周期 ≈ 20~30 分钟真实时间（dsv4flash 2~3 s/次）

### 4.2 Commander 适配层（game-host 内的模块，M1/M2 双实现）

**M1 — headless-per-cycle（先跑通）**
- 每周期 `spawn` 一次 `dsh --profile headless --output-format json "<指挥官 prompt>"`
- prompt = 角色设定（国家/风格/教义）+ 快照 + 历史摘要环形缓冲（最近 K 周期）
- 无跨周期 session，记忆全靠 prompt 携带 —— 简单、可审计、无状态漂移
- 产物即 dsh session 记录（遥测/回放天然可用）

**M2 — MCP server + ACP 长驻会话（产品形态）**
- game-host 内置 MCP server（stdio 或 streamable-http），暴露 tools：
  - `mcp__ra__get_snapshot`（当前/指定周期快照）
  - `mcp__ra__submit_orders`（schema 强约束提交）
  - `mcp__ra__get_battle_history`（查询历史）
  - `mcp__ra__get_match_meta`（地图/规则/对手信息）
- dsh profile（`ra-commander`）= dsh-base + dsh-mcp-client（stdio 指向 game-host）
- orchestrator 经 ACP 驱动该 profile 的长驻会话：指挥官有连续记忆、上下文压缩由 dsh 托管、支持 fork
- 一次会话打多局 → 指挥官有"战役级"经验积累

**M3 — 原生 Cordis 插件（可选优化）**
- `ctx.tools.register()` 直接注册游戏 tool，免 MCP 序列化开销；仅当 M2 出现性能/表达力瓶颈时做

### 4.3 Orchestrator CLI

- `ra-wargame run`：配置对局（双方 commander 后端：`dsh:dsv4flash` / `builtin` / `rulebot:supalosa` / `human:online`）、地图、规则项、种子；产出 `match-<id>/`（replay + decisions.jsonl + stats + 双方 dsh session id）
- `ra-wargame replay`：起本地静态服务，Chrono Divide 网页客户端加载回放 + 决策侧栏（当前周期快照/指令/理由）
- `ra-wargame fork <match>@<cycle> --as red`：以该周期快照为起点、dsh session fork 出新分支，推演"如果当时……"
- `ra-wargame tournament`：N 局循环赛， Elo 记分（M3 之后）

### 4.4 项目结构（独立仓库，不进 dsh）

```
ra-wargame/
├── package.json                # pnpm monorepo
├── packages/
│   ├── game-host/              # 引擎桥：循环、Bot、快照、指令、DecisionLog、MCP server
│   ├── commanders/             # commander 适配：dsh-headless / dsh-mcp / builtin / rulebot 适配器
│   └── orchestrator/           # CLI：run / replay / fork / tournament
├── profiles/
│   └── ra-commander/           # dsh profile：dsh-base + dsh-mcp-client→game-host
├── assets/maps/                # 测试地图（driver 自带 2 张起步）
└── docs/
```

依赖锁定：`@chronodivide/game-api` 锁 0.78.x（该项目活跃迭代中）；dsh 走已装 CLI（0.0.1），不 vendor。

## 5. 关键数据流（一个战术周期）

```
tick≈T: host 停止 update
  → SnapshotBuilder: GameApi 聚合 → snapshot(<2K tok)
  → Commander(M1): dsh headless prompt(角色+snapshot+history) ──2~3s──> orders JSON
  → 校验: schema 通过的进执行队列；失败项 → 下周期 events 反馈
  → OrderTranslator: production→queueForProduction / military→orderUnits(group) / ...
  → DecisionLog: {cycle, tick, snapshotHash, orders, receipts}
  → 恢复 update() 循环
```

## 6. 里程碑

| 阶段 | 内容 | 出口标准 | 预估 |
|---|---|---|---|
| M0 环境验证（完成） | clone Supalosa driver，跑通整局 vitest；`headless-mix.zip` 单位覆盖面确认；dump 首份真实快照 | 一张真实快照定稿 schema v1 | 1~2 天（已完成，见下） |
| M1 闭环（完成） | game-host 主循环 + M1 commander + DecisionLog；dsv4flash vs SupalosaBot 完整一局 | 打满一局出 replay+决策日志；AI 至少会开局基建+出兵 | 3~5 天（已完成，见下） |
| M2 推演形态 | MCP server + ra-commander profile + ACP 驱动；双 AI 对推；replay CLI | 红 blue 均为 dsh 会话的一局完整复盘可放 | 1~2 周 |
| M3 深化 | session fork 分支推演、online 真人模式、tournament/Elo、指挥官人格库 | fork 出 ≥2 分支并对比；真人打完一局 | 持续 |

### M1 完成纪要（2026-08-21，验收局 `ra-wargame/artifacts/match-1787292996540/`）

- **闭环全通**：dsv4flash（经 `dsh demo:headless --output-format json`）指挥红苏军 vs SupalosaBot，t5430 完整打完（120 决策周期 / 63.6 分钟墙钟 / 164 条指令 **0 失败**），产出 decisions.jsonl + battle-report.txt + 回放
- **指挥质量**：标准开局一轮排齐；主动出狗侦察；接敌威胁分级正确（"9 兵游荡未攻→守势发育"）；危机止损（"砍次要建筑提前战车厂"）；末轮自诊"待建队列排序错误已重排"
- **败因（M2 改进项）**：建造链串行 + 矿场 t1665 才落地 → 经济未起飞全程无兵，被步兵 rush 打崩。改进：快照提供预计落地时间、build 指令支持优先级、开局教义注入
- **实测数据**：LLM 周期 8~90s（均值 ~20s，dsh 冷启动+推理）；模拟侧开销可忽略
- **引擎三坑（桥已内置对策）**：①MCV 未展开一切排队静默失败→自动展开 ②生产队列同时刻只收一项→pending 缓冲按节奏消费 ③前置不满足排队静默失败→`getAvailableObjects` 预检不丢项

### M0 完成纪要（2026-08-21，项目已建：`~/PersonalProjects/ra-wargame`）

- **全链路验证通过**：Supalosa driver 整局 vitest；独立项目烟测（init→createGame→update→saveReplay）；真实对局 dump（SupalosaBot Iraq 3802 tick 胜 NoopBot）
- **性能实测**：offline 模拟 ~4400 tick/秒（快实时 ~300 倍）—— 推演瓶颈 100% 在 LLM 侧；烟测 2000 tick <0.1s，CI 整局回归可行（1 秒/局）
- **资源**：`headless-mix.zip` 为原版文件子集（仅 temperate 地形 + 2 张 1v1 测试图），零原版安装跑通；已拷入 `ra-wargame/assets/`（gitignore）
- **tick 语义修正**：速度档 6 = 60 tick/实时秒，但 **1 游戏秒 = 15 tick** —— 决策周期按游戏秒定义（战术周期 = 30~45 tick = 2~3 游戏秒）
- **版本决策**：锁 `@chronodivide/game-api@0.75.0`（与 SupalosaBot 编译目标一致）；0.78 新增 `GameInstanceApi.gameApi` getter，升级后可移除"从 bot 回调捕获 GameApi"的兼容写法
- **快照 schema v1 关键修订**（基于真实 dump）：
  - 单位名为 rules.ini 内部名（`NACNST`/`NAREFN`/`E2`/`SMCV`…）→ **新增单位字典层（unitLexicon）**：快照附常用单位→语义（苏军基地/矿场/动员兵/MCV）映射，冷门单位由 dsh 会话内按需查 `getRulesIni`
  - 快照体积实测：中期 3KB/终局 15KB —— 聚合到编队粒度后 token 预算充足
  - 战争迷雾、生产队列（`NAREFN×1 Active`）、电力（150/10）、敌 MCV 位置 (62,39) 均按预期可见

## 7. 风险与对策

| 风险 | 对策 |
|---|---|
| 快照 token 膨胀（大兵团/多矿区） | 聚合到编队/扇区粒度；`events/history` 环形缓冲截断；M2 后交给 dsh 上下文压缩 |
| LLM 输出格式漂移 | JSON schema 校验 + 单条丢弃 + 下周期反馈；M2 改 tool 参数原生约束；不做整包重试 |
| 决策延迟抖动 | offline 模式无实时约束；online 模式缓存上周期意图 + 超时沿用 |
| headless-mix 资源不全（缺单位/地图） | M0 专项验证；缺则自备 RA2 资源（仅本地研究用，不分发） |
| game-api 迭代破坏兼容 | 锁 0.78.x；升级走整局回归（vitest 模式照抄 Supalosa） |
| 素材版权 | 引擎/SDK 开源但 RA2 素材不开源：产物（replay/日志/代码）不含素材，可公开；素材目录 gitignore |
| dsh 内测期接口变动 | 只用 headless CLI/MCP/ACP 三个最稳定公开面；dsh-app 桌面版的集成经验可参考但不依赖 |

## 8. 与"桌面版路线"的差异（为什么选原版）

- 桌面版（dsh-app）是 Electron 发行形态，主窗口绑官方 web UI，集成点在宿主进程；对局推演需要的是**无头、可脚本化、可多实例**的 agent 运行时 —— 原版 dsh CLI/ACP/MCP 天生就是
- 双 AI 对推要并行两个指挥官会话，原版 profile 机制直接支持多实例；桌面版会被 UI 生命周期拖累
- session fork / 上下文压缩等推演核心能力是 dsh 内核能力，原版直接可用
