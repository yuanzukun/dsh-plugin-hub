# D4 兼容客户端与 DSH 主页面接入设计

> 状态：已实现并通过真实 DSH Profile、真实浏览器和真实模型对战验收。

## 目标

DSH 红警标签直接承载实际运行的红警 2 兼容客户端。页面不再添加插件标题、状态卡或协议说明，真实战场是主内容；Chat、Host、客户端 bridge、renderer 和模型席位绑定同一个 session、match、seat 和 tick。

模型只读取当前席位可见的结构化引擎数据。隐藏敌方、敌方经济、敌方出生点、原始世界对象、debug 全图和 Canvas 像素不会进入 DSH 工具结果。

## 外部插件边界

插件只使用官方 `@deepseek-ai/*` NPM SDK、`cordis.patch.yml` 和 Profile。DSH 源码 checkout、内置 Profile、vendor 和启动器不属于插件写入范围。

兼容客户端通过插件自己的第二个 loopback 静态 server 提供，只绑定 `127.0.0.1`。它不把第三方 renderer 放进 DSH origin，也不使用不能嵌入的远程页面。

```text
DSH Chat/tool
    -> Host BrowserCommandTransport
    -> durable session command/result events
    -> live Connection RPC
    -> BrowserCommandClientService
    -> fixed iframe and formal renderer companion
    -> same real browser match and combatant seat
    -> atomic command receipt and fair observation
```

## Renderer 来源与资源

仓库保存锁定上游 commit 的可审查 GPLv3 adapter 补丁，不保存兼容客户端构建产物或红警 2 素材。`pnpm prepare:renderer` 克隆锁定源码、检查 SHA、应用补丁、运行 companion 专项测试并构建新 `dist/`，且拒绝覆盖已有目录。

首次使用推荐由用户或安装模型明确运行 `dsh-red-alert-setup --download-resources`。setup 打印固定第三方地址、大小、SHA-256 和权利提示，下载到本机 `$DSH_HOME` 并校验后，由同源 renderer 自动导入，原建局继续等待而不是要求 Chat 重试。嵌入 DSH 的 renderer 静音启动，不显示会阻塞主选单的音频授权弹窗；独立打开客户端时仍保留用户授权流程。未传参数时不下载，兼容客户端仍允许选择自己有权使用的本地 7z。已验证的最小归档只含 `RA2.MIX`、`LANGUAGE.MIX` 和 `MULTI.MIX`；音乐、Taunts、电影、`exe` 和 `dll` 不进入最小导入。归档不复制到插件仓库或 NPM 包。

## 连接和身份

Host 从 DSH Web 的 `127.0.0.1` origin 派生 renderer parent origin，并通过 live RPC 返回当前 session 的 loopback URL。URL、端口和 lease 不写入 durable state、Chat、模型或日志。

renderer 依赖 Web Profile 的 `webServer`，但插件入口只注册 Cordis 动态注入，不等待这个可选服务的回调完成。这样 Loader 可以先完成 Web server provider 的装载，再在子 scope 启动 renderer host 和 `MatchService`，不会形成“插件等待 webServer、Loader 又等待插件”的启动互等。renderer 配置错误仍在子 scope 首次可解析时明确报错。

iframe 只接受精确 origin、精确 `contentWindow` source、protocol version、session、match、seat 和非未来 tick。身份变化、页面导航、连接 generation 变化或 adapter dispose 都要求重新握手；旧回执和旧回调不能修改新 session。浏览器崩溃留下的空闲 lease 可以被同 session 的新客户端接管，但存在 pending command、结果提交或清理时必须拒绝接管。

用户明确确认前，红警标签不创建 iframe，也不执行兼容客户端代码。确认后，root service 持有固定 iframe；红警和 Chat 标签切换只改变挂载位置，不创建第二个游戏实例。

## 命令和结束状态

每条模型动作先写入 session command event 并完成持久 flush，再通过 live RPC 交给同浏览器实例。renderer 返回实际执行 tick、精确工具结果、对局状态和同 tick 的公平观察；Host 持久写入结果后才向模型返回。

浏览器建局、首次资源加载和地图初始化使用 120 秒命令超时。取消、超时、重复 requestId、错误 lease、错误身份、隐藏字段和晚到回执都失败关闭。

如果建局命令已经持久写入 identity，但浏览器回执超时，projection 使用 `status=error`、`failure.phase=creating` 和 `recoverable=true` 表达可恢复建局。Host authority、renderer config RPC 和浏览器 consumer 都继续使用该 identity；UI 保留 iframe 和重试入口，不把它误判成无活动对局，也不复用旧 endpoint。

GameScreen 进入自然胜负结算时，companion 在释放引擎绑定前冻结最后一份公平观察和 `finished` 对局快照。结束后只允许读取这份冻结观察，生产、建设、单位和其他命令全部拒绝；刷新 bridge 或切换标签不会重新读取已销毁的世界对象。

finished 对局保留已注册 iframe，让主页面继续显示兼容客户端的真实结算页。显式 `red_alert_stop` 才进入 stopped 并移除可执行 renderer。

## 公平观察

CurrentLos 使用本方和合法盟友的存活视觉来源、sight、临时 shroud 和 tile occupation。renderer 可见性与模型投影共用这项判断。

`visibleEnemies` 只包含当前视野内敌人。敌人离开全部合法视觉来源后转入 `lastSeenEnemies`，位置、生命值和 `observedAtTick` 冻结；迷雾外销毁不会通过全图存在性扫描更新或删除这条记录。未识破 disguise 在字段复制前完全省略。

攻击目标在执行时重新从当前 `visibleEnemies` 解析。建筑放置只搜索请求点附近整个地基都处于当前视野内的合法位置。任何可见性计算、身份或解码失败都会拒绝命令，不降级读取隐藏状态。

## 按需工具

模型初始只看到 `red_alert_capabilities` 和 `red_alert_load_group`。lobby、观察、单位、生产、建设、外交、超武和生命周期工具按 session、对局阶段和精确组加载；选择事件持久化并 flush 后，工具 schema 才进入模型请求。

`red_alert_act` 不存在。每个动作使用精确 wrapper，公开 game-api 声明必须在 `METHOD_POLICY` 中明确允许或拒绝，危险方法和 debug 方法保持不可见。

## 验收

完成条件由 [最终验收报告](../reports/2026-08-22_dsh-real-client-final-acceptance.md) 记录。真实 DSH 主页面、真实模型普通 AI 对战、同局身份、终局冻结、公平观察、按需工具、外部 Profile 挂载、一键 renderer 准备和完整插件检查均已通过，`RA_READY=1`。
