# DSH 真实红警主页面与公平 AI 需求

状态：已实现并完成真实 DSH 验收，2026-08-23。

## 1. 目标

交付一个可挂载到 DeepSeek Harness（DSH）的外部插件：

- DSH 中间区域保留原生 Chat，右栏显示真实可玩的红警 2 兼容 Web 客户端。
- Chat 负责创建对战、下达用户指令并显示模型判断和工具回执。
- Chat、工具和右栏控制同一个浏览器实例、同一个对局和同一个 AI 席位。
- 模型优先读取引擎结构化数据，但只能读取该 AI 席位在战争迷雾规则下已经合法发现的信息。
- 游戏能力按组、按 session、按阶段加载，避免把全部 schema 一次放入模型上下文。
- 只通过官方 NPM SDK、Profile 和 `cordis.patch.yml` 挂载，不修改 DSH 源码。

## 2. 用户体验需求

### 2.1 Chat 与右侧战场

1. 新 session 默认显示原生 Chat，顶部提供“战场”按钮展开、放大或收起右栏；不注册与 Chat 平级的红警标签。
2. 右侧战场主体必须是实际游戏 renderer，包含地图、单位、建筑、动画、战争迷雾、HUD 和小地图。
3. Canvas 战术图、SVG 投影、截图、视频、回放或另一个 headless 对局不能作为右侧战场。
4. Chat 必须持续显示用户输入、模型输出、工具调用和可继续输入的 composer；右栏变化不能卸载同一个 iframe、游戏引擎或对局。
5. 对局运行中，用户必须能用左键拖动、迷你地图、方向键和滚轮移动真实客户端镜头；这些输入只能改变观战视角，不能选择单位、生产或发出战斗命令。
6. 连接失败、命令拒绝和可恢复错误不能卸载 renderer；页面应允许在同一 match 上恢复。

### 2.2 Chat 控制

1. 用户可以在 Chat 中创建 1v1 对战。
2. 模型可以查看公开地图和席位信息，开始对局，观察，移动、攻击、部署，管理生产，放置、出售和修理建筑，控制外交和超武，并停止对局。
3. 每个工具必须校验 owning session、agent、`matchId`、seat、阶段和 tick。
4. 工具返回必须来自真实浏览器对局，不得另开隐藏 headless 对局代替。
5. 精确动作失败必须返回稳定错误；失败后 adapter 保持 ready，后续合法命令仍可继续。
6. 战术决策必须由当前真实模型产生；插件不得在后台自动观察、选目标、拆分编队、撤退或发动进攻。
7. 单次模型工具调用必须允许按顺序提交多条单位命令，使模型能在同一个公平快照上亲自完成多编队微操。

## 3. 公平 AI 需求

### 3.1 唯一模型观察

模型可见战场对象只允许来自 `FogSafeObservation`：

- `ownUnits`
- `visibleEnemies`
- `lastSeenEnemies`
- `visibleNeutralObjects`

### 3.2 当前视野

1. 敌军和中立对象只有在绑定席位当前 LOS 内才可进入观察。
2. renderer 和模型 bridge 必须使用同一套 current-LOS 判断。
3. 隐藏对象即使仍存在于引擎 world，也不能进入 bridge。
4. 首帧必须失败关闭；不能先泄漏一帧再等待过滤。
5. 合法盟友只在游戏规则允许共享视野时作为视觉来源。

### 3.3 最后发现

1. 敌人从可见变为隐藏后，可以保留最后一次合法观察。
2. 隐藏期间的坐标、生命值、类型和 `observedAtTick` 必须冻结。
3. 敌人在迷雾外销毁时，不能用全图存在性扫描清掉或更新最后发现。
4. 重新进入视野后才可用新观察更新。

### 3.4 禁止数据

以下内容不得注册给模型，也不得进入 session event、projection、日志或工具结果：

- `getAllUnits`、`getDebugStateDump` 和未过滤对象查询。
- 敌方出生点、经济、生产、科技、全图资源和隐藏对象 ID。
- 原始 world dump、debug overlay、观察者全图、Canvas 像素和 replay referee 数据。
- 尚未合法识破的伪装单位真实身份。

建筑放置搜索也属于观察边界：候选地基的全部格子必须处于当前视野内，才可以调用合法放置检查。

## 4. 工具需求

### 4.1 分组

工具必须分为：

1. `bootstrap/capability`
2. `strategy/learning`
3. `lobby/setup`
4. `observation`
5. `production/economy`
6. `construction`
7. `units/combat`
8. `diplomacy/comms`
9. `superweapon`
10. `lifecycle/replay`

### 4.2 按需加载

1. 初始模型请求只显示 `red_alert_capabilities` 和 `red_alert_load_group`。
2. group 选择必须先写入并 flush `red-alert/tool-group-selection`，然后才能发布 schema。
3. 持久记录损坏、未知版本、未知方法或跨组方法时必须失败关闭。
4. 阶段变化必须重新收紧工具权限；已加载不等于任何阶段都能调用。
5. 组加载失败必须回滚可见集合，不能留下半组 schema。
6. 旧聚合工具 `red_alert_act` 不得存在。

### 4.3 方法覆盖

1. 锁定的 `@chronodivide/game-api@0.75.0` 公共声明必须全部分类为 `allow-wrapper`、`internal-only` 或 `deny`。
2. 允许的方法必须映射到精确工具、JSON schema、阶段、工具组和测试。
3. internal/deny 方法不得进入模型 schema。
4. declaration 发生新增、删除、签名或 overload 漂移时，构建门禁必须失败。

当前覆盖：85 个公共声明，22 个 manifest 项。

### 4.4 自动增强和命令节奏

1. 新对局默认 `gameSpeed=2`，双方共享 15 tick/s；模型可以显式选择 0 到 6，但不能只改变一方速度。
2. 真实精确工具结果必须附带同一原子回执产生的紧凑 `commandView`，不得为压缩而读取新的全图数据。
3. 自然终局必须自动写入一个 `red-alert/strategy-episode`；手动停止、失败状态和重复终局不得产生新 episode。
4. episode 只能来自持久 `red-alert/state`、已准入浏览器命令和安全结果，只保存封闭指标和候选规则 ID。
5. `red_alert_review_match` 只能采用或拒绝本局候选 ID，未知 ID、重复 ID、交叉采用和拒绝必须失败关闭。
6. `red_alert_strategy_brief` 按地图、己方阵营和对手类型聚合有限历史，并把实际返回内容记录为 session event。
7. `red_alert_field_manual` 只按主题和阵营返回一页公开静态知识，实际页面进入 session event，不得混入任何实时隐藏战场数据。
8. 自动学习不得修改模型权重、DSH 设置、插件源文件或自由文本 system prompt。
9. episode 可以统计模型实际提交的单位批次、order、攻击和撤退数量，但不得把插件生成的战术命令伪装成模型操作；插件后台战术命令数必须始终为 0。

## 5. 同局身份需求

每条开始、观察和动作命令都必须携带并验证：

- `sessionId`
- `matchId`
- `seat`
- `expectedTick`
- 递增的 request/tick 身份

Host、client consumer、renderer bridge 和兼容客户端必须使用同一身份。不同 origin、window source、协议版本、session、match、seat、旧 tick 或晚到回执全部拒绝。

## 6. 资源和许可需求

1. 插件、补丁、NPM 包和 GitHub 仓库不得包含或发布 EA 游戏素材；一键 setup 只有在用户明确传入 `--download-resources` 时，才可从 README 写明的第三方地址下载固定摘要的归档到本机 `$DSH_HOME`。
2. 兼容客户端从锁定的开源源码构建，补丁使用与上游相同的 `GPL-3.0-only`。
3. 用户的明确授权可以是运行带 `--download-resources` 的 setup，也可以是在浏览器中选择自己有权使用的本地归档；不得静默下载。
4. 已验证的最小归档只需要 `RA2.MIX`、`LANGUAGE.MIX`、`MULTI.MIX`。
5. `theme.mix`、音乐、Taunts、电影、`exe` 和 `dll` 必须排除或保持禁用。
6. 自动下载必须在流式写入前检查声明大小，在写入中限制最大字节数，结束后校验 SHA-256，失败删除临时文件；renderer 只自动接受固定同源路径且只尝试一次，随后回到可见本地入口。
7. 开源客户端不代表游戏素材自动进入公有领域；项目不得以“专利期已过”作为分发素材的依据。
8. 嵌入 DSH 的 renderer 必须静音启动，不得用音频授权弹窗阻塞主选单或首次建局；独立客户端仍由用户决定是否启用声音。

## 7. DSH 外部插件需求

1. 包名为 `@vibeinging/dsh-red-alert`，通过 `dsh.bundle.patch` 挂载。
2. Host 和 client 只依赖官方 `@deepseek-ai/*` NPM SDK。
3. 不允许 `file:`、`link:`、workspace 或 TypeScript path 指向 DSH 源码 checkout。
4. 不修改 DSH `packages/`、`vendor/`、内置 Profile 或启动器。
5. renderer 由插件自己的 `127.0.0.1` 静态服务提供，不注册 DSH same-origin 路由。
6. iframe 必须使用精确 loopback origin、精确 `contentWindow` source 和 sandbox。
7. 卸载插件后不保留 DSH 内置代码修改。

## 8. 可靠性需求

1. 命令和结果使用 session event 记录，模型可见成功必须可以从日志重建。
2. 已取消 signal 不得发送 hello 或命令。
3. 超时、断连、session 切换和 dispose 必须等待正在执行的 adapter promise 收敛。
4. 同一 client 生命周期内，同一 requestId 不得重复执行。
5. 浏览器或 Host 进程崩溃后的 pending command 不承诺跨进程 exactly-once；恢复必须失败关闭。
6. 可恢复错误不能释放当前 match identity，也不能让 UI 卸载 iframe。
7. 浏览器崩溃后的空闲 client lease 可以由同 session 的新页面接管；存在 pending command、结果提交或清理时不得接管。
8. `failure.phase=creating` 且 `recoverable=true` 的错误必须保留当前 identity；Host renderer 配置、命令准入和浏览器 consumer 必须允许同一建局继续，其他错误仍失败关闭。
9. renderer 对 `webServer` 的动态依赖不得阻塞外层插件加载；DSH Loader 必须先完成 provider 装载，再在注入 scope 启动 renderer host 和对局服务。
10. 首次资源导入和客户端启动使用独立、可配置的 600000 ms 建局超时；普通浏览器战术命令保持独立、可配置的 120000 ms 超时。

## 9. 验收指标

```text
RA_READY = min(PROFILE, FOG, VISUAL, TOOL_COVERAGE,
               LAZY_LOAD, SAME_MATCH, DSH_CONTRACT, REGRESSION)
```

每项只能为 0 或 1，所有项为 1 才能完成。

| 指标 | 验收条件 |
| --- | --- |
| `PROFILE` | 真实 DSH Profile 挂载外部插件，DSH checkout 零写入 |
| `FOG` | 当前 LOS、last-seen 冻结、隐藏删除、边界拒绝和 10 局审计通过 |
| `VISUAL` | DSH 右栏显示真实地图、迷雾、HUD、小地图和实际单位建筑，中间 Chat 同屏显示模型输出和用户输入，实跑超过 1500 tick |
| `TOOL_COVERAGE` | 85 个公开声明全部分类，允许方法有精确 wrapper，危险方法不可见 |
| `LAZY_LOAD` | 初始仅 bootstrap，选择持久化后才加载精确组 schema |
| `SAME_MATCH` | Chat、tools、bridge、engine、renderer 绑定同一 session/match/seat/tick |
| `DSH_CONTRACT` | 官方 SDK、bundle patch、client handoff、projection 和 loopback transport 通过 |
| `REGRESSION` | 完整插件检查、adapter 构建测试、公平审计和包检查通过 |

2026-08-22 正式结果：八项均为 1，`RA_READY=1`。证据见[最终验收报告](../reports/2026-08-22_dsh-real-client-final-acceptance.md)。

## 10. 不在当前承诺内

- 不分发游戏素材。
- 不提供公网房间、账号、排位或正式在线服务。
- 不承诺跨浏览器或 Host 进程崩溃的命令 exactly-once。
- 不把观察者全图或多模态截图识别当作公平 AI 数据源。
- 不自动提交、推送、发布 npm 包或修改 DSH 源码。
