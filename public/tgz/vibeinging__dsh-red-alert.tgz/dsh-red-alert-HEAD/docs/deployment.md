# RA-Wargame 部署方案

> 日期：2026-08-21。当前推荐路径：**本地开发模式**；容器化已给出参考实现，限制见 §3。

## 1. 本地开发 / 单机演示（当前主路径）

```sh
cd ra-wargame && pnpm install

# AI 对局 + 观战台（浏览器打开 http://localhost:7860）
RA_COMMANDER=dsh RA_OPPONENT=supalosa RA_SERVE=1 \
  pnpm --filter @ra-wargame/game-host run match

# 冒烟（脚本指挥官 + 慢速，观战调试）
RA_COMMANDER=mock RA_OPPONENT=noop RA_SERVE=1 RA_TICK_DELAY_MS=15 \
  pnpm --filter @ra-wargame/game-host run match
```

环境变量一览：

| 变量 | 默认 | 说明 |
|---|---|---|
| `RA_SERVE` | 0 | 1 = 启动观战台（HTTP+WS 同端口） |
| `RA_PORT` | 7860 | 观战台端口 |
| `RA_COMMANDER` | mock | `dsh`（dsv4flash 真指挥官）/ `mock` |
| `RA_OPPONENT` | supalosa | `supalosa` / `noop` |
| `RA_DECISION_PERIOD` | 45 | 决策周期（tick），1 游戏秒 = 15 tick |
| `RA_MAX_TICKS` / `RA_MAX_CYCLES` | 6000 / 500 | 对局上限 |
| `RA_TICK_DELAY_MS` | 0 | 观战调试用每 tick 延迟 |
| `RA_DSH_SOURCE` | ~/.dsh/source/current | dsh 源码仓（demo:headless 入口） |

**依赖前提**：本机已装 dsh（`~/.dsh/source/current`）且 DeepSeek 凭据已配置（deepseek-official provider）。

## 2. 单容器部署（Docker）

`Dockerfile`（参考实现）：

```dockerfile
FROM node:24-slim
RUN corepack enable
WORKDIR /app
COPY package.json pnpm-workspace.yaml ./
COPY packages/game-host packages/game-host
RUN cd packages/game-host && npm install --no-audit --no-fund
# assets（headless mix ~11MB + 地图）：建议运行时挂载，避免素材进镜像层
EXPOSE 7860
CMD ["npx", "tsx", "src/run-match.ts"]
```

`docker-compose.yml`：

```yaml
services:
  wargame:
    build: .
    ports: ["7860:7860"]
    volumes:
      - ./assets:/app/assets                      # headless 资源
      - ~/.dsh/source:/root/.dsh/source:ro        # dsh 源码仓（demo:headless）
      - dsh-state:/root/.dsh                      # dsh 凭据/会话（secret 首次注入）
      - ./artifacts:/app/artifacts                # 对局产物
    environment:
      RA_COMMANDER: dsh
      RA_OPPONENT: supalosa
      RA_SERVE: "1"
volumes:
  dsh-state:
```

资源画像：单局 1 vCPU / 512MB 足够（模拟 ~4400 tick/s，LLM 推理在云端 DeepSeek 侧）。
并发模型：**每局一进程一容器**（compose `--scale` / K8s Job），WS 长连按端口直连，无需 LB 粘性的额外设计（单局单容器内闭环）。

## 3. 已知限制（容器化）

- **dsh 是源码仓形态**（非 npm 全局包）：镜像内需完整 `~/.dsh/source` 检出 + pnpm 依赖 + DeepSeek 凭据注入。官方未提供容器镜像前，这是容器化的主要摩擦点；本地模式无此问题
- **素材版权**：`assets/`（原版文件子集）不入镜像层，挂载或私有源分发
- **WS 观战无鉴权**：当前监听 localhost；公网部署需前置反代 + 鉴权（推荐 caddy/nginx + basic auth，M2 补内置 token）

## 4. 云端拓扑（M3 多局并发）

```
入口 LB (wss 路由 by matchId)
  └ N × wargame-pod（每 pod 一局：引擎+决策+观战台）
     └ 共享：DeepSeek API（凭据集中管理）
     └ 对局产物 → 对象存储（decisions.jsonl / replay / 战报）
编排：K8s Job（一局一 Job，产物上传后退出）；观战 URL = /match/{id} → Service 直通 pod
```
