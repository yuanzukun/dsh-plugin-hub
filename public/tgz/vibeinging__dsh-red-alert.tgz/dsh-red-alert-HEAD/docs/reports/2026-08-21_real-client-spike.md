# 真实客户端可运行 Spike 报告

> 历史说明：本报告只记录 2026-08-21 的临时 spike，当时的 `正式集成 BLOCKED` 结论已被后续正式实现和真实 DSH 验收解除。当前状态与完成指标以[2026-08-22 最终验收报告](2026-08-22_dsh-real-client-final-acceptance.md)为准；下文原始证据和当时结论保持不改。

状态：`D2 SPIKE PASS / D2.1 HISTORICAL BLOCKED / D2.2 BASIC CURRENT-LOS SPIKE PASS / D2.3 OBSERVABLE-SEMANTICS PARTIAL-BLOCKED / D2.4 PARTIAL-BLOCKED / 正式集成 BLOCKED`。在锁定的兼容客户端临时 checkout 中补上了按 seat 计算的 transient current LOS，并让真实 renderer 过滤和 bridge 观察共用该关系；自然隐藏、发现、重叠视野、撤离冻结和重连的基础 current-LOS 转场已通过。D2.3 增加了生命周期和新对象首帧的保守处理；D2.4 修复了迷雾外死亡清理泄漏，并让未识破 disguise 在模型边界直接 omit。锁定场景仍没有实际发生的隐形、伪装或合法探测转场，完整 fairness 仍是 BLOCKED。D2.1 仍记录原始上游 `MapShroud` 仅表达永久探索状态的阻断事实；D2.2-D2.4 都是未接入 DSH 的临时 adapter 证据，不计 `VISUAL` 或 `SAME_MATCH`。

本报告记录 D1、D2、D2.1、D2.2、D2.3 和 D2.4 的可重复核验。临时源码、依赖、浏览器状态、日志和截图均留在 `/private/tmp`，没有复制到本仓库；没有修改 DSH 源码 checkout、vendor、assets 或正式代码。

## 结论

官方路径仍不能继续：`game.chronodivide.com` 的响应头禁止被跨源 DSH 页面嵌入，公开 Game API 只有 headless/offline 引擎接口，没有把 offline `GameInstanceApi` 接到官方浏览器 renderer 的公开入口，也不支持两个程序化 Bot 进入同一 online game。

兼容路径的 D1/D2/D2.2-D2.4 临时纵切已通过部分门槛：`huangkaoya/redalert2` 的真实 Three.js renderer 使用临时最小 MIX 集进入地图，显示真实地形、战争迷雾、单位和 HUD；临时 bridge 让被控 seat 通过真实 `orderUnits` 命令控制同一 browser game instance。D2.2 在 adapter 内以本方和合法盟友的存活视觉来源、单位 sight、地形 tile 占用和 tick 重建 transient current LOS；D2.3 又把生命周期、world spawn/remove 和 wire 字段白名单纳入同一投影边界；D2.4 去掉了全局 world 存在性对 lastSeen 的删除，并在未识破 disguise 时于模型边界完全 omit。renderer 对象可见性、选择层级和 bridge 敌情观察共用该判断。自然运行已证明基础 current-LOS 的首帧拒绝、发现、重叠视野、撤离后的 last-seen 冻结和重连保持；D2.4 还证明迷雾外销毁后 lastSeen 冻结、当前可见销毁后无 visible 敌情，但真实隐形/伪装/探测转场未在该场景出现。该 bridge、LOS 层和浏览器 harness 只存在于 `/private/tmp`，没有接入 DSH，也没有把第三方源码或素材复制进本仓库。

正式集成仍不能继续：Workflow C 已在外部插件内提供 plugin-owned renderer container 和 bridge protocol seam；缺口是可依法挂载的兼容客户端 adapter，以及 DSH 工具到同一 browser instance 的生产 transport。D2.2-D2.4 的命令调用来自本地 Playwright harness，不是真实外部 LLM 或 DSH tool call，所以它只证明兼容客户端的可替换 adapter/LOS 方向可行，不清除 `VISUAL` 或 `SAME_MATCH`。

补充资源证据：兼容客户端当前 commit 的 `public/config.ini` 明确给出公开入口 `gameResArchiveUrl=https://download.ra2web.com/full-pack.7z`。该入口的 HEAD 响应为 `200`、`application/x-7z-compressed`、`140,316,786` bytes，`last-modified` 为 `2024-09-30`。根任务随后仅在 `/private/tmp` 做了临时下载和清单核验，记录 SHA-256 为 `3119b300794839ab597df556df8718c0a0a28fe89648ddced1c3790d801cb646`，清单含 `RA2.MIX`、`LANGUAGE.MIX`、`MULTI.MIX`、`MAPS`、`MOVIES`、`THEME.MIX`、`Taunts` 以及 exe/dll；该包和素材没有进入本仓库。入口的真实性、内容完整性和许可仍需根任务继续核验，不能把公开 URL 直接当作可复制或可分发授权。

因此阶段 0 的技术结论是“兼容 renderer bridge 可继续研究”，而正式 DSH 产品结论仍为 `BLOCKED`；不能把构建成功或独立临时页面成功当作 DSH 主页面验收。

## 环境、版本和临时证据

- 日期：2026-08-21，Asia/Shanghai。
- 临时根目录：`/private/tmp/dsh-ra-client-spike.AX4U7I`；该目录可被清理，不是交付物。
- 兼容客户端仓库：`https://github.com/huangkaoya/redalert2`。
- 兼容客户端基线 commit：`8c07f1092b2a9e8d8605ed49ef46d77b6c3ea367`，commit 时间为 `2026-06-23T08:27:56+08:00`；clone 后基线 `git status --short` 为空，D2.2 临时 patch 之后工作树按下列文件有意变脏，未提交上游。
- 临时运行工具：Bun `1.3.14`，Vite `8.0.1`，React `19.2.4`，Three `0.183.2`，Playwright `1.58.2`。
- 官方包核对：`@chronodivide/game-api@0.75.0`；registry 当前 latest 为 `0.78.0`，本轮也下载并读取了 `0.78.0`。
- 0.75.0 tarball shasum：`7710864899e6d36215e877cd70c289927ecaf54c`。
- 0.78.0 tarball shasum：`d712602c31e649a81a037fbb00ba59cb1ad3c21c`。
- 兼容客户端资源配置：`public/config.ini` 的 `gameResArchiveUrl` 指向 `https://download.ra2web.com/full-pack.7z`；本报告只记录入口，不把资源包纳入正式仓库。
- D2.2 临时源码：`src/spike/CurrentLos.ts`、`src/spike/RedAlertD2Bridge.ts`、`src/gui/screen/game/WorldView.ts`、`src/gui/screen/game/GameScreen.ts`；均只在临时 checkout 修改。
- 临时证据汇总：`/private/tmp/dsh-ra-client-spike.AX4U7I/evidence-summary.txt`。
- 初始资源导入页截图：`/private/tmp/dsh-ra-client-spike.AX4U7I/initial-annotated.png`。
- 资源失败截图：`/private/tmp/dsh-ra-client-spike.AX4U7I/resource-import-failure.png`。

临时证据会随系统清理而消失，正式报告只保留路径和可重复命令，不把这些文件当作正式资源或产品资产。

## D2 真实同浏览器纵切

D2 使用上游精确 commit `8c07f1092b2a9e8d8605ed49ef46d77b6c3ea367`，在同一个真实浏览器游戏实例内启动 `Player 1` 对战一个内置 `DummyBot`。`Player 1` 不是人工点击，也没有真实 LLM；Playwright harness 通过临时 bridge 代表模型 seat 发送 `orderUnits`，因此本节是 renderer/bridge 技术证据，不是 DSH 工具验收。

临时资源输入为 `/private/tmp/ra2web-d1.aba9YH/minimal-archive.7z`，大小 `138,838,693` bytes，SHA-256 为 `18b1f878a7efa7cc77c98cd1344e94ec79e8e2b0f1976d45b66b799d1b422b09`。归档只包含 `RA2.MIX`、`LANGUAGE.MIX`、`MULTI.MIX`；未抽取或加载 `THEME.MIX`、Taunts、movies、exe、dll。该文件只用于临时验证，没有进入插件或正式 assets。

原始 D2 bridge 观察入口曾调用 `GameApi.getVisibleUnits(seat, "self"|"enemy"|"hostile")`；D2.2 版本已移除产品敌情对这两个永久 shroud API 的依赖：本方仍只从 `getVisibleUnits(seat, "self")` 读取，敌方和中立只从临时 `CurrentLos` 的当前可见对象集合读取，再对已过滤 ID 调用 `getUnitData` 缩减字段。`CurrentLos.getVisibleHostileObjects()` 内部确实调用 `game.getWorld().getAllObjects()`，完整对象图只留在受信 adapter 内部，用于逐对象过滤；bridge 只序列化白名单安全字段，测试审计 helper 也不把 raw object 送入 wire。可见中立仍按当前 hostile 对象减去敌方 combatant 的关系得到。

临时 bridge 的上游接缝和改动如下：

- `GameScreen.onGameStart`：在真实页面启动后安装 bridge，并把它加入页面 dispose 集合。
- `ActionsApi.orderUnits`、`SoloPlayTurnManager.doGameTurn`：使用真实 ActionQueue 消费命令；实际适配修复把 wire 层字符串 unit id 校验并转换为上游需要的安全整数 id。
- `GameApi`、`MapShroud`、`MapShroudTrait`：提供 seat 绑定、地图 tile、对象生命周期和 tick；D2.2 的 `CurrentLos` 用新的 transient `MapShroud` 累加存活本方/合法盟友视觉源的 sight，不修改 `game.mapShroudTrait`。`MapShroud.unrevealAround` 只由临时 synthetic helper 调用，D2.2 自然分支没有调用它。
- `BotManager`/`DummyBot`：作为同局对手，不作为模型观察来源。

临时源码改动为 `/private/tmp/dsh-ra-client-spike.AX4U7I/redalert2/src/spike/CurrentLos.ts`、`src/spike/RedAlertD2Bridge.ts`、`src/gui/screen/game/WorldView.ts` 和 `src/gui/screen/game/GameScreen.ts`，并使用 `/private/tmp/ra2web-d1.aba9YH/run-d2.ts` 作为 Playwright harness。没有修改上游正式提交、DSH checkout、本仓库代码或资源。

关键 D2 证据来自 `/private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d2-final-state.json`：

| 阶段 | sessionId | matchId | seat | tick | 观察结果 |
| --- | --- | --- | --- | ---: | --- |
| 初始隐藏 | `ra2-session-00e67f2b-a923-4ff3-b22d-a58eb7f43ae6` | `0` | `Player 1` | `208` | `ownUnits` 只有 `AMCV`；敌方可见、last-seen 和中立均为空；sentinel `1044` 的坐标和血量不在敌情观察中。 |
| bridge 移动后 | 同上 | `0` | `Player 1` | `1570` | `AMCV` 从 `(135,80)` 移到 `(78,115)`；敌方 `GACNST#1044` 在 `(70,117)` 以 `source=visible` 出现，`observedAtTick=1570`。 |
| synthetic 重新遮蔽后 | 同上 | `0` | `Player 1` | `2993` | 上游 `MapShroud.unrevealAround` 仅在测试 helper 中重新遮蔽已探索敌方区域；`visibleEnemies=[]`，`lastSeenEnemies` 保留 `(70,117)`、`hp=1000`、`observedAtTick=2993`。这不是自然战争迷雾证据。 |
| 冻结观察 | 同上 | `0` | `Player 1` | `3113` | tick 前进但 last-seen 对象逐字段不变，`observedAtTick` 仍为 `2993`。 |
| bridge 重连 | 同上 | `0` | `Player 1` | `3113` | `disconnect()` 后快照被拒绝，`connect()` 后恢复同一 session/match/seat 和 last-seen 观察。 |

该兼容客户端的公开 `MapShroud` 将已经探索的格子保留为 `Explored`，普通移动离开后不会自然回到 `Unexplored`。因此 D2.1 上表的“离开视野”与冻结只属于 synthetic audit；D2.2 已证明可以在不改永久 shroud 的临时层重建基础 current LOS，但正式移植和 D2.3 的隐形、伪装、生命周期及视觉对象语义仍未完成。

D2 的真实页面截图为 `/private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d2-real-game-command.png`，可见实际地图、AMCV、战争迷雾和原生 HUD。页面没有使用 SVG、Canvas 绘制假战场、截图、视频或 replay 代替 renderer；页面使用的 Canvas 是兼容客户端自身 Three.js renderer 的输出。

## D2.1 当前 LOS 与已探索状态核对

D2.1 的结论是 `fairness=BLOCKED`。D2.1 只在 `/private/tmp` 运行，保留 D1 的真实页面和 D2 的同局命令事实，但不把 synthetic audit 的冻结结果提升为自然公平通过。

### Adapter 的实际可见性来源

临时 adapter `/private/tmp/dsh-ra-client-spike.AX4U7I/redalert2/src/spike/RedAlertD2Bridge.ts:155-193` 使用 `GameApi.getVisibleUnits(seat, "self")`、`getVisibleUnits(seat, "enemy")` 和 `getVisibleUnits(seat, "hostile")`；敌情 unit 详情只对这些返回的 ID 调用 `getUnitData`，可见中立由 `hostile - enemy` 得出。该 bridge 的 `:306-380` 测试 helper 才会扫描 `game.getWorld().getAllObjects()` 和调用 `unrevealAround`，这些路径不在产品观察或命令函数中。

上游 `src/game/api/GameApi.ts:127-161` 的 `enemy` 和 `hostile` 实现读取 `game.mapShroudTrait.getPlayerShroud(player)`，再以 `map.tileOccupation.calculateTilesForGameObject(...).some(tile => !playerShroud.isShrouded(tile, obj.tileElevation))` 判定对象可见。`src/game/map/MapShroud.ts:143-145` 的 `isShrouded` 只有在 shroud type 为 `Unexplored` 时返回 true；`ShroudType.Explored` 和 `TemporaryReveal` 都被当作非 shrouded，因此这是持久已探索状态，不是当前 LOS 查询。

### Renderer 使用的同一关系

真实 renderer 在 `src/gui/screen/game/WorldView.ts:82-105` 取得 seat 的 `MapShroud` 并传给 `MapRenderable`；`src/engine/renderable/entity/map/MapShroudLayer.ts:237-283` 根据 `Unexplored` 生成 shroud overlay。交互路径在 `src/gui/screen/game/worldInteraction/MapHoverHandler.ts:103-147` 先从 `EntityIntersectHelper` 取对象，再以同一个 `shroud.isShrouded` 清除隐藏对象；`src/engine/util/EntityIntersectHelper.ts:155-186` 本身只遍历 Three.js 对象的 `visible` 层级，没有额外的当前 LOS 集合。`src/engine/RenderableManager.ts:64-71` 还会为 world 的全部对象创建 renderable，因此未找到 renderer 维护的 per-player current-visible object 集合。

`src/game/trait/MapShroudTrait.ts:41-48` 为每个 combatant 创建 shroud，`:59-67` 每 tick 更新；`src/game/map/MapShroud.ts:225-255` 把 reveal invalidation 写入 `Explored`，而 `:193-200` 的 `unrevealAround` 是显式测试/工具式重置，不是单位离开视野时的自然转换。由此确认 adapter 与 renderer 使用了同一上游 shroud 关系，但该关系本身不能满足“当前可见”和“曾探索”分离的公平合同。

### 自然行为运行证据

命令为 `RA2_D2_NATURAL_ONLY=1 bun run run-d2.ts`，在受控主机运行，且该分支没有调用 `unrevealAround`。证据文件为 `/private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d2-natural-state.json`、`/private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d2-natural-after-retreat.png` 和 `/private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d2-console.log`。

自然运行的 `sessionId` 为 `ra2-session-932b5a0f-fa07-4b67-a14e-4ebbe683d8a5`、`matchId=0`、`seat=Player 1`。初始 tick `206` 时敌方 sentinel `1044`（`NACNST`，`@@AI2@@`，`(134,79)`，`hp=1000`）不在观察中；本方移动命令在 tick `206` 接受，tick `1646` 到达区域后 sentinel 以 `source=visible` 出现。随后本方撤回，在 tick `2959` 已回到 `(73,117)` 附近，但 `visibleEnemies` 仍包含 sentinel `(134,79)`，`source=visible`、`observedAtTick=2959`，`lastSeenEnemies=[]`。这不是自然的“离开当前视野后转 last-seen”，所以公平门禁明确为 `BLOCKED`。

该自然运行没有证明客户端一定永远不能提供更强的视野层，只证明锁定 commit、公开 API 和原始 renderer 接缝没有可重复的当前 LOS 关系。D2.2 已证明在临时 adapter 内实现 transient per-seat current LOS 的技术可行性；正式移植、可观察对象语义和生产 transport 仍待完成，不能把该客户端接入模型观察路径，也不能提升 `VISUAL`、`SAME_MATCH` 或 `RA_READY`。

## D2.2 临时 per-seat current LOS 跟踪层

D2.2 在同一个临时 checkout 内实现了最小 current LOS adapter，用于验证“当前可见”和“永久探索”可以在 renderer/bridge 共用一条关系。它不是上游已有 API，也不是正式插件代码；它只证明在明确的公开对象生命周期和 sight 字段之上可以继续做技术 spike。

实现位置和边界如下：

- `src/spike/CurrentLos.ts:7-41` 每次 refresh 从地图 tiles 新建 transient `MapShroud`，只遍历本 seat 和 `game.alliances.getAllies(seat)` 中未被判负、未销毁、已生成、非运输中的科技对象，并用对象 `sight`、引擎 `revealFrom`、地形高度和 tile occupation 建立当前可见集合；不写入 `game.mapShroudTrait` 的永久探索状态。
- `src/spike/CurrentLos.ts:29-58` 以 transient map 判断敌方和中立对象；己方及合法盟友始终属于可用观察对象，非科技对象默认不可作为敌情；`:78-128` 的逐视觉源核对只用于临时审计，使用和产品 predicate 相同的 sight/tile 关系。
- `src/spike/CurrentLos.ts:135-213` 的 `CurrentLosRendererFilter` 在 constructor 和 `create3DObject` 中先执行隐藏，再首次 refresh；`currentMap` 未初始化时 `isObjectVisible` 对非己方、非盟友对象返回 false。它修改真实 renderable 的 `visible`，因此同一顶层对象也不会进入 `EntityIntersectHelper` 的选择遍历。
- `src/gui/screen/game/WorldView.ts:96-103` 在真实 `RenderableManager` 创建后挂载该 filter；`src/gui/screen/game/GameScreen.ts:690-692` 把同一个 `CurrentLos` 实例传给 bridge。
- `src/spike/RedAlertD2Bridge.ts:157-228` 在每次快照读取前刷新 current LOS；敌方只从过滤后的对象集合读取安全字段，`seenEnemies` 只在当前可见时更新，转为 last-seen 后冻结坐标、血量和 `observedAtTick`。`losReadyBeforeSnapshot=false` 时敌情为空，不把未初始化状态送进 bridge。
- `src/spike/CurrentLos.ts:134-139` 的 `getWorld().getAllObjects()` 是受信 adapter 内的对象图扫描，随后立即套用 seat、生命周期、cloak 和 current-LOS 过滤；`src/spike/RedAlertD2Bridge.ts:181-222` 只从已过滤对象读取并白名单化 `id/owner/type/name/tile/hitPoints`，`assertSafeUnit` 拒绝其他字段。D2.4 已移除 bridge 中按 raw world 存在性删除 `seenEnemies` 的逻辑；lastSeen 不因迷雾外移除而消失，保留到 bridge/match 生命周期结束。视觉源覆盖列表和寻路辅助仍只属于临时审计；这些路径不把 raw object 暴露给 bridge wire、DSH 或模型。

首帧门禁没有通过等待来掩盖泄漏。Playwright 在 `waitForRealGame()` 返回后立即读取隐藏哨兵的 renderable 和 bridge observation，证据日志为 `/private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d2-overlap-final.log` 与 `d2-natural-final.log` 中的 `hidden-sentinel-first-frame`、`first-frame-hidden-sentinel-not-in-observation`；两次均为 `exists=true, visible=false`，且哨兵 ID、owner、坐标和血量不在敌情观察中。随后三秒后的重复断言仍为隐藏。

### 重叠视觉源真实运行

命令为：

```sh
RA2_D2_OVERLAP_ONLY=1 bun run /private/tmp/ra2web-d1.aba9YH/run-d2.ts > /private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d2-overlap-final.log 2>&1
```

该局使用真实 `mp03t4.map`、本方 `Player 1`、两个内置 AI 和最低正常单位配置 `unitCount=5`，不是 mock game。结构化证据为 `/private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d2-overlap-state.json`，真实页面截图为 `/private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d2-overlap-after-retreat.png`。

| 阶段 | tick | 结果 |
| --- | ---: | --- |
| 首帧 | 启动首帧 | 敌方 `NACNST#1833` 在 `(87,30)`，真实 renderable `visible=false`，bridge 无该对象。 |
| 两个视觉源到达 | `1180` | 同一 session `ra2-session-90aa654b-ae2c-4e5e-9330-70b586d9fda5`、match `0`、seat `Player 1`；真实移动命令在 tick `225` 接受；`1809` 和 `1810` 同时覆盖哨兵，敌方 `source=visible`。 |
| 第一源撤离 | `1379` | `1809` 由真实 `orderUnits` 移到 `(67,32)`，哨兵仍 `source=visible`；逐源 LOS 集合只有 `1810`，renderer 仍可见。 |
| 两源撤离 | `1542` | `1810` 由真实 `orderUnits` 移到 `(101,33)`；哨兵没有覆盖源，renderer `visible=false`，bridge 转为 `source=last-seen`，坐标 `(87,30)`、血量 `1000`，`observedAtTick=1522`。 |
| 冻结 | `1663` | tick 前进，哨兵 last-seen 的坐标、血量和 `observedAtTick=1522` 逐字段不变。期间其他敌方对象可能自然重新进入视野，但不刷新该哨兵。 |
| 重连 | `1663` | bridge `disconnect()` 时快照被拒绝，`connect()` 后同一 session/match/seat 恢复，哨兵 last-seen 与冻结快照一致。 |

### 单源自然隐藏到发现再撤离

命令为：

```sh
RA2_D2_NATURAL_ONLY=1 bun run /private/tmp/ra2web-d1.aba9YH/run-d2.ts > /private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d2-natural-final.log 2>&1
```

证据文件为 `/private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d2-natural-state.json`、`d2-natural-revealed.png` 和 `d2-natural-after-retreat.png`。该局 session 为 `ra2-session-03d0169e-1e2e-44c1-9d1a-e6da0ef903d0`，match `0`，seat `Player 1`；隐藏 `NACNST#1830` 在 `(87,30)`，初始 tick `223`，本方真实移动后 tick `1758` 进入当前 LOS 并以 `source=visible` 出现，撤离后 tick `3395` 敌方列表为空、renderer 隐藏、last-seen 的最后观察 tick 为 `1892`，tick `3516` 冻结检查和重连均保持同一数据。该自然分支没有调用 `unrevealAround`、debug/global/full-map getter 来制造转场。

D2.2 仍不是正式产品公平门禁：current LOS 是本临时 adapter 对公开引擎对象图的补层，尚未在 DSH 外部 bundle 内运行，也没有证明兼容客户端上游会稳定提供这组字段作为长期 API。D2.2 可称基础 sight/current-LOS spike pass；完整 fairness 还需要 D2.3/D2.4 的可观察对象语义。正式集成前仍需将该 adapter 合同固定、完成许可/资源决策，并在同一 DSH Web 主页面证明工具、renderer、seat、match 和公平观察链路；因此 `VISUAL`、`SAME_MATCH` 和 `RA_READY` 保持为 `0`。

## D2.3 可观察语义与生命周期 fail-closed

D2.3 继续只在 `/private/tmp/dsh-ra-client-spike.AX4U7I/redalert2` 做临时 patch 和真实浏览器运行。结论是 `PARTIAL-BLOCKED`：临时层已经把引擎生命周期、cloak/disguise 状态、可观察身份和新对象首帧收口到保守投影，但本轮没有真实发生的隐形、伪装、合法探测或“已观察后销毁”转场，因此不能声称完整 fairness 通过。

### 上游事实和投影边界

锁定 commit 的 renderer 语义提供了必须跟随的事实来源：`src/engine/renderable/entity/plugin/ObjectCloakPlugin.ts:16-24` 会按 `cloakableTrait.isCloaked()` 和本 seat 的 shared-intel 状态切换 renderable visibility；`src/game/trait/SharedDetectCloakTrait.ts:102-118` 用 detector 的 `sensorsSight` 和 tile distance 使合法探测对象 `uncloak`。`src/engine/renderable/entity/plugin/VehicleDisguisePlugin.ts:77-101` 和 `src/engine/renderable/entity/plugin/InfantryDisguisePlugin.ts:25-54,63-68` 按 shared intel、`sharedDetectDisguiseTrait` 和 disguise rules 决定显示形态、owner 和 UI name；`src/game/trait/SharedDetectDisguiseTrait.ts:97-130` 维护 per-seat 的已识破集合。`src/game/Game.ts:593-637` 和 `src/game/World.ts:19-31` 说明 limbo/unlimbo 以及 world spawn/remove 的顺序，world 事件发生在后续完整 `onSpawn` 流程前，所以新对象在首帧必须默认拒绝。

临时 `CurrentLos` 的 seat-authoritative 投影在 `src/spike/CurrentLos.ts:43-98,134-199` 实施以下顺序：对象必须存活、已生成、不在 limbo、不在 warped-out、没有 `rules.invisibleInGame`；敌方必须是 Techno、通过 transient current LOS 且不处于未被检测的 cloak 状态。未识破 disguise 时，`isModelObservable()` 返回 false，bridge 在读取任何 identity、tile 或 health 前直接 omit；只有 seat 的 `sharedDetectDisguiseTrait` 已合法识破后，才允许进入安全投影。`src/spike/RedAlertD2Bridge.ts:78-122,181-238` 用 `projectFogSafeUnit(data, modelObservable)` 和字段白名单断言；隐藏对象的 raw id、owner、type、name、tile、health 不进入 snapshot。该层把 renderer/selection 的 top-level Techno visibility 与 bridge 使用的 `getRendererDecision()` 绑定到同一 predicate；`src/spike/CurrentLos.ts:213-347` 对 world spawn 先 invalidate、立即 apply deny，再等待下一次 authoritative refresh。

### 对象分类

| 分类 | 当前处理 | 观察/渲染边界 | 证据状态 |
| --- | --- | --- | --- |
| `seat-observable` | 敌方 Techno 需通过 current LOS、生命周期和 cloak/detection 过滤；己方及合法盟友按 seat 规则保留。 | 进入 bridge 的 FogSafeObservation；selection 使用同一 top-level visibility。 | 基础 LOS 和首帧/移除已运行；cloak/disguise 自然转场未出现。 |
| `visual-only` | 非 Techno 投射物、效果等保留兼容客户端原生视觉，不进入模型观察。 | 不得从该类生成敌情字段；当前没有把所有 non-Techno 粗暴 hidden。 | 正常战斗效果的独立 smoke 尚未完成，正式接入仍受阻。 |
| `always-hidden` | 未初始化、未生成、destroyed、disposed、limbo、warped-out、`invisibleInGame` 的对象拒绝渲染、选择和当前观察。 | 不进入当前 bridge observation；已确认过的 lastSeen 不由 world 存在性删除。 | 新 spawn、remove 和静态生命周期核对已覆盖；D2.4 补了迷雾外及当前可见销毁。 |
| `undetected-disguise` | renderer 仍遵循引擎的伪装外观；模型边界在复制任何字段前 omit。 | 不进入 visibleEnemies、lastSeen 更新或 neutral/friendly 数组；合法识破后才允许真实身份。 | 纯逻辑边界测试 2/2；真实自然伪装/探测转场仍 BLOCKED。 |

### D2.3 真实运行证据

命令为：

```sh
RA2_D23_INSPECT_ONLY=1 bun run /private/tmp/ra2web-d1.aba9YH/run-d2.ts > /private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d23-inspect.log 2>&1
```

退出码为 `0`，结构化结果为 `/private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d23-inspect-state.json`，运行 session 为 `ra2-session-33ec5cb0-8f78-46ae-bd38-4df09479eaf0`、`matchId=0`、`seat=Player 1`、最终 tick `582`。首帧隐藏哨兵 `1828` 的 renderable 存在但 `visible=false`，日志同时记录 bridge observation 不含该 ID。该断言在等待后续 tick 之前执行。

| 场景 | 运行证据 | 结论 |
| --- | --- | --- |
| 运行中 hostile spawn | world spawn 事件记录 hostile `GACNST#1833` 在 `initialized=false` 时 `reason=lifecycle`；最终 `rendererVisible=false`、`modelVisible=false`。同批 `NACNST#1832` 属于合法盟友，renderable 可见但 model observation 仍未收录，因此未把盟友误记为 hidden-enemy 证据。 | 新 hostile 对象没有进入 renderer/selection/bridge 的可见敌情路径。 |
| remove 后清理 | `SMCV#1817`、`AMCV#1826` 的 remove 检查均为 `rendererExists=false`、`modelVisible=false`。 | 该证据只说明从未可见/当前不可见对象不进入 current observation 或 renderer；不证明 lastSeen 清理，D2.4 专门验证迷雾外移除后 lastSeen 保留。 |
| cloak/disguise/detector | 本局所有候选的 `cloakable=false`、`cloaked=false`、`disguisable=false`、`disguised=false`；没有可用合法 detector transition。 | `BLOCKED`，只完成了源码语义核对和保守代码路径，不能声称“无探测隐形缺席、探测后出现、伪装身份恢复”已运行通过。 |
| limbo/warped/invisible | 投影代码对 `limboData`、`warpedOutTrait.isActive()`、`rules.invisibleInGame` fail-closed；本轮没有真实状态切换样本。 | `PARTIAL-BLOCKED`，需自然生命周期样本。 |

因此 D2.3 只证明“基础 current-LOS + 生命周期 fail-closed + raw world scan 在受信 adapter 内收口”的技术方向。D2.4 进一步修复了迷雾外死亡泄漏并补上了 disguise omit 边界，但没有证明完整 renderer 规则、隐形/伪装/探测自然转场以及投射物/效果的视觉语义；完整 fairness 仍为 `BLOCKED`。

## D2.4 lastSeen 与 disguise fail-closed 修复

D2.4 仍只修改临时 checkout 和临时 Playwright harness，正式插件没有生产 transport 变化。修复点如下：

- 删除 `RedAlertD2Bridge.getSnapshot()` 中以 `game.getWorld().getAllObjects()` 建立 `liveWorldIds` 并删除 `seenEnemies` 的逻辑。已观察敌人在当前 LOS 外被移除或销毁时，lastSeen 保留原始 `id/owner/type/name/tile/hitPoints/observedAtTick`；当前最小策略是保留到 bridge/match 生命周期结束，不通过重新扫描全图猜测死亡。
- `CurrentLos.isModelObservable()` 只在没有未识破 disguise 时放行；bridge 先检查该结果，再调用 `getUnitData` 和 `projectFogSafeUnit`。未识破对象不会进入 `visibleEnemies`、lastSeen 更新、neutral 或 friendly 数组，不发送真实稳定 ID、owner、type、name、tile 或 health。renderer 仍由上游 disguise plugin 显示伪装外观。
- 新增临时 `projectFogSafeUnit(data, modelObservable)` 边界函数和 2 个纯逻辑测试；`modelObservable=false` 时返回 `undefined`，`true` 时才允许安全字段白名单投影。该测试证明边界行为，不冒充真实自然 disguise/detector 转场。

### 迷雾外销毁冻结证据

命令为：

```sh
RA2_D24_LASTSEEN_REMOVE_ONLY=1 bun run /private/tmp/ra2web-d1.aba9YH/run-d2.ts > /private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d24-last-seen-remove.log 2>&1
```

结构化证据为 `/private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d24-last-seen-remove-state.json`，session `ra2-session-ca11ff8d-49ab-4998-beab-9ce01ac878c2`、`matchId=0`、`seat=Player 1`。真实运行先在 tick `1738` 观察 `GACNST#1824`，tick `3329` 本 seat 已离开其当前 LOS，`visibleEnemies=[]`、覆盖视觉源为空，lastSeen 的 `observedAtTick=1828`。随后临时审计调用真实引擎 `destroyObject`，对象 `stillInWorld=false`；tick `3453` 读取到的 `visibleEnemies=[]`，lastSeen 仍逐字段等于移除前快照，`observedAtTick`、坐标和血量均未变化。

### 当前可见销毁证据

命令为：

```sh
RA2_D24_VISIBLE_REMOVE_ONLY=1 bun run /private/tmp/ra2web-d1.aba9YH/run-d2.ts > /private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d24-visible-remove.log 2>&1
```

结构化证据为 `/private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d24-visible-remove-state.json`，session `ra2-session-0ef93c2b-fe6d-4488-9a04-40f5f72a1127`、`matchId=0`、`seat=Player 1`。`MTNK#1828` 在 tick `1858` 为 `source=visible`，临时真实引擎销毁后 tick `2010` 的 `visibleEnemies` 不再包含该 ID；lastSeen 可保留最后确认快照。这只证明当前可见销毁不会残留 visible 敌情，不把 lastSeen 删除当作公平信号。

### disguise 边界证据和剩余阻塞

临时测试命令为：

```sh
bun test ./tests/d2-bridge-boundary.test.ts
```

结果为 `2 pass, 0 fail`：未识破 disguise 的 raw fixture 在模型投影前返回 `undefined`，断言中没有真实 ID、owner、type、tile 或 health；模拟已合法识破时才允许白名单字段进入投影。当前锁定对局的候选仍全部 `cloakable=false`、`disguisable=false`，没有自然隐形、伪装或合法探测转场，因此真实规则继续 `BLOCKED`。D2.4 也没有验证对局结束时的清理事件或投射物/效果的正常视觉 smoke；这些不能由本轮受控 remove 或纯逻辑测试替代。

## 实际命令和结果

### 官方页面和 API

```sh
curl -k -sS -D - -o /dev/null https://game.chronodivide.com/
npm view @chronodivide/game-api@0.75.0 version dist.tarball engines --json
npm view @chronodivide/game-api version dist-tags --json
npm pack @chronodivide/game-api@0.75.0 --pack-destination /private/tmp/dsh-ra-client-spike.AX4U7I
npm pack @chronodivide/game-api@0.78.0 --pack-destination /private/tmp/dsh-ra-client-spike.AX4U7I
```

结果：registry 下载成功；0.75.0 要求 Node `>=20`，0.78.0 是当前 latest。官方页面响应为 `HTTP/2 200`，但同时返回：

```text
content-security-policy: frame-ancestors 'self'; base-uri 'self'; object-src 'none'
x-frame-options: SAMEORIGIN
```

这两个约束都不允许 `game.chronodivide.com` 被不同源的 DSH Web 页面作为 iframe 或同类嵌入内容使用。它不阻止用户单独打开官方页面，但不满足“DSH 主页面就是该真实页面”。

### 兼容客户端

```sh
git clone https://github.com/huangkaoya/redalert2.git /private/tmp/dsh-ra-client-spike.AX4U7I/redalert2
git -C /private/tmp/dsh-ra-client-spike.AX4U7I/redalert2 rev-parse HEAD
git -C /private/tmp/dsh-ra-client-spike.AX4U7I/redalert2 status --short
bun install
bun run build
bun --bun ./node_modules/vite/bin/vite.js --config vite.http.config.ts
RA2_D2_OVERLAP_ONLY=1 bun run /private/tmp/ra2web-d1.aba9YH/run-d2.ts > /private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d2-overlap-final.log 2>&1
RA2_D2_NATURAL_ONLY=1 bun run /private/tmp/ra2web-d1.aba9YH/run-d2.ts > /private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d2-natural-final.log 2>&1
RA2_D23_INSPECT_ONLY=1 bun run /private/tmp/ra2web-d1.aba9YH/run-d2.ts > /private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d23-inspect.log 2>&1
bun test ./tests/d2-bridge-boundary.test.ts
RA2_D24_LASTSEEN_REMOVE_ONLY=1 bun run /private/tmp/ra2web-d1.aba9YH/run-d2.ts > /private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d24-last-seen-remove.log 2>&1
RA2_D24_VISIBLE_REMOVE_ONLY=1 bun run /private/tmp/ra2web-d1.aba9YH/run-d2.ts > /private/tmp/ra2web-d1.aba9YH/playwright-evidence-d2/d24-visible-remove.log 2>&1
bun run build
bun --bun tsc -p tsconfig.build.json --pretty false
```

结果：clone、依赖安装和生产构建通过。构建输出为 `1222 modules transformed`，构建耗时约 `540ms`，同时有 7z-wasm Node 模块外置、CommonJS 和大 chunk 警告。临时 `vite.http.config.ts` 只为绕开上游 HTTPS 开发配置并允许读取现有资源目录，放在临时 clone 内，没有修改上游提交。

D2.2 两条 Playwright 命令、D2.3 inspect 和两条 D2.4 受控浏览器命令均以退出码 `0` 完成；D2.4 结构化证据证明迷雾外销毁不改变 lastSeen，当前可见销毁不留下 visible 敌情。`bun test ./tests/d2-bridge-boundary.test.ts` 为 `2 pass, 0 fail`。本轮 `bun run build` 通过，输出 `1224 modules transformed`；`bun --bun tsc -p tsconfig.build.json --pretty false` 以退出码 `2` 结束，诊断全部来自上游已有 `src/tools/*Tester.ts` 的类型基线错误；没有报 `CurrentLos.ts`、`RedAlertD2Bridge.ts`、`WorldView.ts` 或 `GameScreen.ts` 的新增诊断。

浏览器打开 `http://127.0.0.1:4174/` 后，真实 renderer 启动并显示资源导入页。将现有 assets 通过本地浏览器文件输入注入，没有上传到外部服务，结果为：

```text
GameResFileNotFoundError: local.mix
GameResImporter.importSplashImage
GameResImporter.importMixArchive
GameResImporter.import
GameRes.init
Application.main
```

当前正式仓库资源检查：`assets/ra2.mix`、`assets/local.mix`、`assets/language.mix` 均为 74 bytes 的 stub。错误发生在 `ra2.mix` 内部所需的 `local.mix` 查找，说明仅把同名顶层文件一起选择并不能补齐嵌套资源。浏览器没有进入一局，所以没有声称看到地图、单位、建筑、动画或战争迷雾。

随后对兼容客户端配置和公开资源入口做了只读核对：

```sh
rg -n "gameResArchiveUrl" /private/tmp/dsh-ra-client-spike.AX4U7I/redalert2/public/config.ini
curl -sSIL https://download.ra2web.com/full-pack.7z
```

结果为配置项 `gameResArchiveUrl=https://download.ra2web.com/full-pack.7z`，入口返回 `200`、`application/x-7z-compressed`、`140,316,786` bytes，最后修改时间为 `2024-09-30`。这修正了“没有网站素材源”的旧表述：现在已找到公开资源入口，但它不等于本机已有合法输入，也不等于插件可以直接复制或分发素材。

## 本机合法资源只读发现

本轮只用 Spotlight `mdfind -onlyin` 和 `find -maxdepth 6` 检查 `/Users/Four/Documents`、`/Users/Four/Downloads`、`/Users/Four/Applications`、`/Users/Four/Games` 与 `/Users/Four/PersonalProjects`，查找 `ra2.mix`、`local.mix`、`language.mix`、`game.exe`、`ra2.exe` 和 `Red Alert 2.app`。没有发现完整候选安装目录或资源集；唯一命中是本仓库 `assets/` 下的三个 74-byte stub。没有读取资源内容，没有复制、移动、上传或修改素材。下一步需要用户提供一个合法资源输入路径；输入可以是安装目录、兼容客户端可识别的完整 MIX 集或明确许可的替代素材包。

这项本机搜索结论只表示“没有找到本机候选输入”，不表示公开网站没有资源入口。`public/config.ini` 的 `full-pack.7z` 是兼容客户端声明的公开下载入口；本轮不自动下载、不复制到插件，也不把入口本身计为 `VISUAL`。若采用用户首次使用时的明确下载/导入流程，资源 provider 必须让 URL、大小、hash/版本和许可提示可审计，并把下载后的数据留在浏览器或用户选择的运行时存储中。

## 官方路径核验

一手来源：

- [官方 game-api-playground](https://github.com/chronodivide/game-api-playground) 的 README 把 Game API 说明为 headless、isolated command-line environment，并区分离线多 AI 和在线 AI 对真人。
- [官方 @chronodivide/game-api 包](https://www.npmjs.com/package/@chronodivide/game-api)；本轮直接读取 0.75.0 与 0.78.0 tarball 中的 `dist/index.d.ts` 和 `dist/index.js`。
- [Chrono Divide 官方页面](https://game.chronodivide.com/)。

| 核验项 | 状态 | 证据 |
| --- | --- | --- |
| 官方页面可被 DSH 跨源嵌入 | `FAIL` | `frame-ancestors 'self'` 与 `X-Frame-Options: SAMEORIGIN`。 |
| 0.75.0 离线真实引擎可运行多个程序化 Bot | `PASS` | `CreateOfflineOpts.agents: Bot[]`；README 说明离线局由多个 computer-controlled agents 对战。 |
| offline GameInstanceApi 接入官方 renderer | `FAIL` | 公开 `GameInstanceApi` 只有 `update`、状态/统计、replay、debug dump、dispose 等接口；没有 renderer attach、canvas handoff 或 browser session binding。见 0.75.0/0.78.0 `dist/index.d.ts` 的 `GameInstanceApi`。 |
| 两个程序化 Bot 进入同一个官方 online game | `FAIL` | 当前 0.78.0 的 `CreateOnlineOpts.agents` 是 `[Bot, ...Agent[]]`，公开注释明确 online 只有一个 AI 且必须是第一个；0.75.0 同样是单 Bot 形态。 |
| 外部 DSH 工具控制官方 browser client 的同一 match | `FAIL` | `onGameCreate(joinUrls)` 只能返回 Agent 的加入 URL，没有把第二个 Agent 变成 Bot、连接 DSH 工具命令或绑定公平观察视角的公开扩展点。 |
| 官方 online 继续验证所需凭据 | `BLOCKED` | 0.75.0 合同使用 `serverUrl`、`clientUrl`、`botPassword`；0.78.0 改为 `xwolApiUrl`、`clientUrl`、`apiKey`。本轮没有读取、打印或写入任何账号、密钥或 token。 |

0.75.0 关键类型位置：`CreateOfflineOpts` 在 `dist/index.d.ts:258-261`，`CreateOnlineOpts` 在 `:263-279`，`GameApi` 在 `:337-400`，`GameInstanceApi` 在 `:402-421`，`PublicApi` 在 `:1111-1128`。0.78.0 保持同一 renderer/same-match 结论，且把 online 合同明确写成单一 AI。

## 兼容客户端核验

一手来源：

- [huangkaoya/redalert2 README](https://github.com/huangkaoya/redalert2#readme)。
- [huangkaoya/redalert2 LICENSE](https://github.com/huangkaoya/redalert2/blob/main/LICENSE)。

| 核验项 | 状态 | 证据 |
| --- | --- | --- |
| 当前公开仓库可 clone、版本可重现 | `PASS` | commit `8c07f1092b2a9e8d8605ed49ef46d77b6c3ea367`，工作树干净。 |
| 真实 renderer 依赖可安装并构建 | `PASS` | `bun install` 与 `bun run build` 通过；项目是 React、Vite、Three.js 客户端。 |
| 客户端声明的公开资源入口可定位 | `PASS` | `public/config.ini` 指向 `full-pack.7z`；HEAD 为 200 和 140,316,786 bytes。内容与许可仍待核验，不计入真实对局证据。 |
| 正式仓库现有 assets 能启动一局真实画面 | `BLOCKED` | 正式仓库的三个关键 mix 文件仍只是 74-byte stub；D1 使用的是 `/private/tmp` 的临时最小资源归档。 |
| 临时资源进入地图并看到单位、建筑、动画、战争迷雾 | `PASS` | D1/D2 真实页面截图显示地形、水岸、基地、单位、HUD、计时器、小地图和战争迷雾；证据留在 `/private/tmp/ra2web-d1.aba9YH/playwright-evidence/06-real-game-success.png` 与 `playwright-evidence-d2/d2-real-game-command.png`。 |
| 在同一 browser game instance 创建 skirmish、选 AI、发移动命令 | `PASS` | D2 临时 bridge 绑定 `Player 1` combatant seat，同一 renderer 对局由 `ActionsApi.orderUnits` 消费命令；这不是 DSH 工具或真实 LLM 验收。 |
| 现有 tester 能证明 DSH 同局控制 | `FAIL` | `LiveInteractionTester.ts:846-873` 在浏览器内直接调用 `GameFactory.create`；`:898-946` 建立 `WorldView`/`WorldInteraction`；`:1631-1643` 直接调用 `game.update()`；`:1870-1905` 直接创建并加入 `AttackMoveOrder`。它还依赖 `/api/live-interaction` 和 `window.__ra2debug`，不能作为模型输入或 DSH 同局合同。 |
| 可直接复用的结构化公平观察接口 | `BLOCKED` | 源码内部有 `MapShroud`、`isVisibleTile` 和 game object，但没有面向外部 DSH 的结构化观察协议；debug 对象和全量引擎对象不能进入模型路径。本轮未使用它们构造模型观察。 |

上游当前 commit 的 package scripts 与 README 仍引用 `scripts/live-interaction-runtime.mjs`、`scripts/skirmish-flow.mjs` 等文件，但 `git ls-tree` 和工作树均没有 `scripts/` 目录。这是该精确 commit 的可复现性缺口，不能用 README 中不存在的入口声称自动化通过。

## 七项硬证据汇总

| 证据 | 状态 | 当前证据边界 |
| --- | --- | --- |
| `renderer` | `PASS` | D1/D2.2 临时页面已进入兼容客户端真实 renderer；D2.2 首帧和撤离后的真实 renderable 过滤通过；官方页面仍不能跨源嵌入，正式 DSH 主页面仍 `BLOCKED`。 |
| `same-match` | `PASS` | D2.2 临时 bridge 命令、引擎观察和页面 renderer 绑定同一 browser game instance、session、match、seat 和 tick；尚未接入 DSH，因此不计正式 `SAME_MATCH`。 |
| `control` | `PASS` | D2.2 `ActionsApi.orderUnits` 真实改变同局本方单位位置，并自然触发 LOS 转场；调用来自临时 Playwright bridge，不是 DSH 工具或真实 LLM。 |
| `fairness` | `PARTIAL / D2.4 BLOCKED` | D2.2 只证明基础 current-LOS；D2.3/D2.4 已覆盖首帧、spawn/remove、生命周期 fail-closed、迷雾外 lastSeen 冻结、当前可见销毁无 visible 残留和 raw-to-safe/disguise omit 边界，但锁定场景没有真实 cloak/disguise/detector 转场，投射物/效果视觉语义也未独立验证。 |
| `reconnect` | `PARTIAL` | 临时 bridge 的 disconnect/connect 保持同一 session/match/seat；尚未验证 DSH Web 页面刷新/重连，也未满足公平观察门禁。 |
| `license` | `BLOCKED` | 事实是上游包含 GPL-3.0；README 记录非商业限制、RA2WEB 权利要求和 EA 素材权利。还需要用户/法务确认是否有完整资源和分发授权；本报告不作法律判断。官方 npm API 包的 metadata 为 `UNLICENSED`，也不等于取得 renderer 或素材授权。 |
| `reproducibility` | `PARTIAL` | 锁定 commit、临时最小资源、命令和 Playwright 证据可重跑 D1-D2.4；正式仓库资源、DSH 接入和完整公平门禁仍未通过。 |

## 许可证和资源事实

兼容仓库 `LICENSE` 是 GPL-3.0。README 同时写明：项目基于对 Chrono Divide/RA2WEB 的分析，商业使用需得到 RA2WEB 负责人许可，EA 游戏和素材有各自权利，使用者需要合法拥有游戏副本；README 还说明 Chrono Divide 原作者没有公开官方客户端源码。上述均是来源中的事实记录，不是本报告的法律判断。

因此，合法资源输入、兼容客户端使用授权和未来分发方式仍是独立门禁。资源输入可以是合法 RA2 安装目录、兼容客户端可识别的完整 MIX 集，或有明确分发许可的替代素材包；当前三种 stub 不满足启动要求。在这些事项明确前，不复制资源、不上传资源、不把兼容客户端代码或素材纳入 dsh-red-alert。

补充权利事实：EA 2025 Modding Guidelines 仍将 art、music 等内容的权利归于 EA；非商业 Mod 也只是可撤销的有限许可，并明确禁止包含 C&C 游戏音乐。开源客户端代码、公开下载入口和用户触发的运行时导入都不等于素材进入公版或取得分发授权。因此后续实现应默认无音乐路径，不导入或使用 `THEME.MIX`、`Taunts`、电影和可执行文件；如果当前 importer 强制要求 `theme.mix`，应先改 adapter/资源清单使其可选，并把该改造作为 renderer bridge 的首个阻塞点。这里记录规则事实，不作法律意见。

## 指标和下一步门槛

本轮保持：

```text
PROFILE=1
FOG=1
DSH_CONTRACT=1
REGRESSION=1
VISUAL=0
TOOL_COVERAGE=0
LAZY_LOAD=0
GROUP_LOADER_READY=0
SAME_MATCH=0
RA_READY=min(PROFILE,FOG,VISUAL,TOOL_COVERAGE,LAZY_LOAD,SAME_MATCH,DSH_CONTRACT,REGRESSION)=0
```

最小下一步不是把 SVG、Canvas、截图、视频或 replay 接入主页面，而是先满足下列一个真实路径：

1. 官方提供可嵌入或受支持的真实 client renderer、同局双程序 Bot、外部控制和可重连视角合同，并提供继续在线验证所需的安全凭据。
2. 采用用户明确触发的资源 provider：默认 URL 可配置为兼容客户端的 `full-pack.7z` 入口，先展示来源、大小、hash/版本和许可提示，再只导入进图所需的最小数据；不导入音乐、Taunts、电影或可执行文件。若 importer 仍强制 `theme.mix`，先完成 adapter 改造，再在同一 browser instance 中证明建局、AI seat、命令、结构化 fog-safe observation 和重连。

兼容路径在进入正式 DSH 接入前还必须完成 D2.4 之后的可观察语义：D2.2 已证明临时 per-seat current LOS 的技术可行性，D2.4 已修复迷雾外 lastSeen 死亡泄漏并建立 disguise omit 边界，但仍需在合法 adapter 中验证 cloak/disguise/detector 自然转场、limbo/warped/invisible 生命周期、对局结束清理和 visual-only 效果边界；仅有 `MapShroud` 的已探索判定和 synthetic `unrevealAround` 不足以通过。

在任一门槛满足前，不实现 DSH renderer 接入，不创建伪造 `joinUrl`，不把当前离线 fair observation projection 写成真实 Chrono Divide 客户端。
