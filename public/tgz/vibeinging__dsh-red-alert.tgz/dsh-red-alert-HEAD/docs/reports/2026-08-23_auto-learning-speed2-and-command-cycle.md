# DSH 红警自动学习、速度 2 和指挥周期增强报告

状态：实现、专项测试和完整插件回归通过；三局速度 2 真实模型实测已完成，结果和截图见[三局学习实测报告](2026-08-23_speed2-three-match-learning-series.md)，尚无胜局，因此不声称胜率已经提高。

## 1. 结论

插件已增加赛后自动增强，但它不是在线训练模型权重。自然胜负落地时，Host 会从当前 DSH session 的公平状态和已准入命令结果派生一个结构化 episode；模型只能采用或拒绝本局返回的封闭候选规则；下一局按地图、己方阵营和对手类型读取短策略。

新对局默认速度由 0 改为 2，即兼容引擎基础 15 tick/s。所有真实精确工具结果增加同一原子 receipt 生成的 `commandView`，让模型在一个决策周期内直接连续执行建设、生产、维修和单位命令，减少 status、observe 和目录的重复往返。

这些改动能减少插件造成的等待和重复读取，但不能保证外部模型的网络、排队和推理耗时一定比人更快，也不能在没有真实复赛前声称更准确或已经战胜普通 AI。

## 2. 自动学习合同

新增持久事件：

- `red-alert/strategy-episode`：自然终局自动写入一次。
- `red-alert/strategy-review`：模型对候选 ID 的采用和拒绝。
- `red-alert/strategy-brief`：下一局实际暴露给模型的短策略。

episode 只包含地图、己方阵营、对手类型、速度、结果、终局时间、最大当前可见敌军、最大当前可见敌方步兵、最大己方战斗单位、首次接敌、首次装甲、读写命令数和所有权失效错误。它不读取或保存 renderer raw world、敌方隐藏出生点、敌方经济、隐藏对象或 Canvas 像素。

封闭候选规则只有：

- `rush-defender-target`
- `anti-infantry-defense`
- `armor-before-contact`
- `fresh-owned-ids`
- `act-before-reread`

单局未复核候选以 experimental 返回；模型采用或同类证据至少重复两局后标为 confirmed。明确拒绝且没有更多证据的单局规则不会进入后续 brief。规则历史和输出数量有 Profile 上限，默认读取 20 局、返回 6 条。

## 3. 按需和阶段边界

`strategy/learning` 是独立按需组。catalog-only 阶段只显示 `red_alert_strategy_brief`，自然终局 ended 阶段只显示 `red_alert_review_match`，running 和手动 stopped 阶段均不开放学习工具。初始 Agent 仍只看到 `red_alert_capabilities` 和 `red_alert_load_group`。

每个 review 必须引用当前 session 的自然终局 match，并且 adopted、rejected 必须是本局候选的有序唯一子集。未知 ID、重复 ID、交叉集合和已提交后的不同改写都会失败关闭。

## 4. 指挥周期

每个真实精确工具结果现在附带：

- 当前 tick 和 match status。
- 本方 credits、power 和 defeated 状态。
- 最多 128 个己方接触。
- 最多 128 个当前可见敌方接触。
- 最多 128 个冻结 last-seen 接触。

每项只保留 id、type、kind、位置、生命值和 observedAtTick。数据直接来自工具回执已经包含的 `FogSafeObservation`，不会为了压缩结果再扫描一次引擎。system prompt 要求模型使用同 tick 的 `commandView` 直接行动，并在一轮中连续执行全部独立合法调用。

unit order 仍支持一次最多 256 条命令。production 和 construction 仍是精确单操作并按 session 串行，不把有前后依赖的引擎调用改成无序并发，也不恢复跨组 `red_alert_act`。

## 5. 配置

- `defaultGameSpeed=2`
- `enableAutoLearning=true`
- `strategyHistoryLimit=20`
- `strategyMaxRules=6`
- `maxLearnedDefenders=24`

速度可由每局 `red_alert_start.gameSpeed` 或 Profile 覆盖为 0 到 6。自动学习可以关闭；关闭后不写 episode，brief 返回空规则，review 拒绝执行。

## 6. 证据和剩余验收

已通过的专项证据：

- `pnpm run typecheck:tests`
- `pnpm vitest run tests/strategy-learning.test.ts tests/command-view.test.ts tests/loader-composition.test.ts --reporter=verbose`：23/23
- DSH Loader 真实组合验证默认速度 2、初始短策略、自然终局 episode、ended 阶段 review 和 review 事件持久化。
- 命令视图边界验证每类 128 项上限、截断标记和 display-only 字段删除。
- `pnpm run check`：17 个插件测试文件、126 个插件测试全部通过；game-host 10 个测试通过；10 局公平审计 `leakCount=0`；21 项 manifest 策略门禁、renderer adapter、构建和 publint 均通过。

实现完成指标：

```text
AUTO_ENHANCEMENT_IMPLEMENTED = min(EVENTS, CLOSED_RULES, LAZY_GROUP,
                                  COMMAND_VIEW, SPEED2, REGRESSION)
                            = min(1, 1, 1, 1, 1, 1)
                            = 1
```

仍待真实效果验收：

- 在 DSH 原生 Chat 与右栏真实客户端中执行一局速度 2、真实模型、normal AI 的自然终局复赛。
- 用固定条件的多局结果判断胜率，而不是用单局或专项测试判断“比人更准”。

`REAL_SPEED2_REMATCH=1`、`WIN_RATE_EVIDENCE=0`。三局实测均使用 `DSH_TELEMETRY_DISABLED=1` 启动；前两局自然战败并提交赛后 review，第三局在评测边界仍未结束。

本轮没有修改 DSH checkout、兼容客户端源码、素材、Profile，也没有提交或推送。
