# DSH Web 红警投影验收报告（旧方案，不满足当前主画面要求）

> 日期：2026-08-21
>
> 当前结论：旧方案不符合“红警游戏主画面”要求。本报告保留 DSH Web 投影链路证据，但不计入 `UI_SYNC`；当前 `UI_SYNC=0`、`DSH_UI_READY=0`、`VISUAL=0`、`RA_READY=0`。

## 验收范围

本报告记录真实 DSH Web 中同一 session 的 Chat 工具调用、session event、host projection、标签更新和浏览器刷新恢复。原验收对象是 DSH 外部插件的公平离线战术投影；该页面属于战术态势面板，不是红警游戏主画面，也不是真实 Chrono Divide 原生客户端，因此不满足当前 UI 验收要求。

本轮没有使用真实外部 LLM、真实在线 Chrono Divide 页面或网络账号。隔离环境中的本地 keyless mock LLM 只负责稳定发起真实的 `red_alert_start` 工具调用，不访问网络，不读取秘密，也不代表外部模型验收。

## 环境

| 项目 | 值 |
|---|---|
| DSH 类型 | 真实 DSH Web |
| DSH_HOME | `/private/tmp/dsh-ra-ui-review.1ENUkm` |
| 插件 | 当前构建的 `@deepseek-ai/dsh-red-alert` 外部 bundle |
| 页面数据源 | DSH session projection，客户端通过 `useProjection("redAlert")` 读取 |
| 测试驱动 | 本地 keyless mock LLM，仅驱动真实工具调用 |
| 网络与秘密 | 未访问网络，未读取或写入秘密 |

## 验收步骤与证据

1. 在 Chat 输入“创建一场 1v1 离线对战”。真实消息流显示工具调用 `red_alert_start · simple-1v1-no-preview.map`，助手返回“离线推演已创建，红警战场页已同步。”
2. 工具完成后，真实 DSH Web 自动选中第一个标签“红警战场”；第二个标签是“对话”（Chat），第三个标签是 `Trajectory`。
3. 红警战场页显示运行中状态、`matchId=7031021b-e69f-4836-aa93-0b0fdbc83cd2`、`map=simple-1v1-no-preview.map`、`mapSize=100x100`、`Russians` 和 `tick=1`。我方观察只有 `SMCV at 37,63 hp100`；`visibleEnemies`、`lastSeenEnemies` 和 `visibleNeutralObjects` 均为空。
4. 点击“对话”后可以看到同一 session 的上述工具调用；停留在“对话”时没有被默认页控制器抢回。手动选择“对话”并刷新后，仍然选择“对话”。
5. 切回“红警战场”并刷新后，仍恢复同一 `matchId`、tick 和公平观察，证明页面从权威 session projection 恢复，而不是从浏览器缓存重建对局。
6. session `session-3530c70c-cd31-4ff4-9a49-8f4beb1d89cb` 的持久日志包含 seq21 `creating`、seq22 `running red-alert/state` 和 seq23 `tool/result`。`running` 事件只包含公平 observation，没有 `enemyStartLocation`。
7. 当前端口 60786 的 browser console log 为空。旧端口的断开 warning 属于此前已停止服务的陈旧日志，不计入本轮结果。
8. 目视结果为深色工业战术风格，页面明确标注“离线推演”“非真实 Chrono Divide 客户端”和“只显示战争迷雾安全投影”；composer 保留在页面底部。但该结果是战术态势投影，不是红警游戏主画面。

## 公平与分发边界

页面显示的单位和敌情只来自公平 session projection；本轮 DOM 观察未出现隐藏敌军、出生点或全量引擎字段。日志中的 `running` 事件也未出现 `enemyStartLocation`。

本报告不把 DSH Web 的离线投影、旧调试 Canvas、赛后回放或真人对 AI 页面计为 `VISUAL=1`。`VISUAL` 仍需要官方支持的双程序 Bot、同一实时 AI 对 AI 对局、至少 1500 tick 的原生 Chrono Divide 页面以及刷新或重连不显示全图的证据。

## 指标结论

| 指标 | 结果 | 证据 |
|---|---:|---|
| `PROFILE` | `1` | 隔离 Profile 的官方安装、启动和移除验收已通过 |
| `FOG` | `1` | 10 局真实 Chrono offline 公平审计通过，`leakCount=0`，注入反例阻断决策回调 |
| `UI_SYNC` | `0` | 旧方案只证明真实 DSH Web 的 Chat、工具、事件、projection、标签更新和刷新恢复链路；页面不是红警游戏主画面 |
| `DSH_CONTRACT` | `1` | 外部 bundle、Loader、生命周期、构建和规则门禁已通过 |
| `REGRESSION` | `1` | 离线 smoke、现有测试和构建产物检查已通过 |
| `DSH_UI_READY` | `0` | `min(1, 1, 0, 1, 1) = 0` |
| `VISUAL` | `0` | 官方真实 Chrono Divide 双程序 Bot 原生页面仍未满足合同 |
| `RA_READY` | `0` | `min(1, 1, 0, 1, 1) = 0` |

## 限制

本轮旧方案证明的是 DSH Web 外部插件的真实离线投影同步链路，不证明红警游戏主画面，不证明真实外部 LLM 行为，不证明在线 Chrono Divide 服务能力，也不证明原生页面 1500 tick 的观战和重连能力。

验收记录覆盖一局 `red_alert_start` 的真实浏览器链路和首个观察点 `tick=1`；10 局公平引擎审计属于独立的 `FOG` 证据，不应与本轮 DSH Web UI 验收混为一谈。

相关合同见 [需求文档](../specs/2026-08-21_real-ra-ui-fog-safe-ai-requirements.md) 和 [执行计划](../plans/2026-08-21_dsh-red-alert-plugin-execution-and-review-plan.md)。原生页面能力阻塞见 [Chrono 页面阻塞报告](2026-08-21_chrono-real-ui-blocker.md)。
