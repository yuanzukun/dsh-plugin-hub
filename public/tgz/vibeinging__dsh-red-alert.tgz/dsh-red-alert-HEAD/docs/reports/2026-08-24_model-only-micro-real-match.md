# DSH 红警纯模型微操真实对局报告

状态：DONE_WITH_FAILURE_EVIDENCE。真实兼容客户端完成了一局自然终局；DeepSeek-V4-Pro 亲自进行建设、生产、观察和单位命令，没有后台规则指挥器。结果为 6 分 49 秒战败，证明当前链路可以真实开局和复盘，但纯模型的决策速度与命令可靠性仍达不到可玩要求。

## 1. 测试条件

- 使用从 npm 安装形态打包出的 `@vibeinging/dsh-red-alert@0.1.2`，挂载到隔离的 `@deepseek-ai/dsh@0.1.1-rc.2` Profile。
- DSH 原生 Chat、模型消息、工具调用和右侧真实红警 2 兼容客户端在同一页面运行；全程只使用一个浏览器标签。
- 模型为 `DeepSeek-V4-Pro High`。
- 地图为 `mp02t2.map`（岛屿之战（2）），己方为 `Russians`，对手为 1 个 normal AI，游戏速度为 2。
- 模型只读取绑定座位的公平观察。游戏中没有后台循环替模型选择单位、目标、撤退点或攻击时机。
- `red_alert_unit_order` 只负责执行模型提供的精确 ID 命令；本轮没有人为接管战斗单位。

## 2. 终局结果

| 项目 | 结果 |
|---|---|
| Match ID | `8b2b9ccf-4d12-4ce7-bda7-7b732f0131fe` |
| 引擎状态 | `finished`，本方战败 |
| 游戏时间 | `0:06:49` |
| 终局 tick | `6134` |
| 普通 AI | 385 分，25 摧毁，9 损失 |
| Player 1 | 45 分，9 摧毁，33 损失 |
| 本方终局单位 | 0 |

模型完成了 MCV 展开、电厂、矿场和兵营，并生产了一批动员兵。敌方首批 8 名步兵到达时，本方电厂只剩约 41% 生命，战车工厂尚未落地。敌方可见步兵峰值达到约 30，本方战斗单位峰值为 15。

## 3. 纯模型微操证据

模型在同一个 Chat 中自行加载 `structures`、`opening`、`combat` 手册和按需工具组，然后调用 `red_alert_start`、`red_alert_observe`、生产、建造和 `red_alert_unit_order`。没有启动后台规则指挥器。

本轮也暴露了纯模型实时指挥的核心瓶颈：

- 单轮共 47 个步骤，模型用时 10 分 34 秒，而游戏只用 6 分 49 秒结束。
- 模型在矿场建造期间多次按信用额变化重复读取 `red_alert_production_status` 和 `red_alert_observe`，没有把等待时间用于并行的侦察与防守准备。
- 第一批敌军抵达前，本方没有装甲单位；模型看到敌军后才转入应急防守。
- 战斗中模型确实尝试通过 `red_alert_unit_order` 控制部队，但适配器随后系统性返回 `ADAPTER_COMMAND_FAILED`，生产、维修和哨戒炮放置也出现相同错误。
- 哨戒炮已经处于 ready 状态，但连续 4 次无法放置；这属于命令适配问题，不能简单归因于战术选择。

因此，本局不能证明“模型已经会微操”。它证明了模型是实际命令来源，也证明了当前实现还缺少足够快的决策周期、失败预算、命令错误明细和稳定的战斗阶段适配。

## 4. 赛后学习

自然终局后，模型调用 `red_alert_review_match`，只采用引擎返回的候选规则，没有虚构胜利：

- `anti-infantry-defense`：慢扩张前优先完成低成本反步兵防御。
- `armor-before-contact`：首次可见进攻前完成战车工厂和最小装甲编队。
- `rush-defender-target`：首波进攻被击退前维持足够的守家战斗单位。

三条规则的初始置信度均为 0.77，并持久化到下一局的 `strategy_brief`。这是可审计的经验规则积累，不是修改模型权重。

## 5. 后续优化优先级

1. 将模型决策周期从“每个状态单独思考一次”改为“一次观察生成一个批量行动计划”，目标是每 2 至 5 秒完成一次战斗决策。
2. 等待中的生产只在预计完成时间检查一次；同时准备下一座建筑、侦察路线和防守编队。
3. 为每类命令返回可行动的错误码，例如过期 ID、不可放置地块、单位已死亡或比赛已结束，禁止全部折叠成 `ADAPTER_COMMAND_FAILED`。
4. 同一动作失败两次后必须刷新一次公平观察并选择替代动作，不能无限重试。
5. 下一轮验收要求至少一局自然胜利，并保存模型批量 `orders`、可见交战画面、终局计分和赛后规则写入证据。

## 6. 截图证据

- 真实开局和第一座电厂：`03-real-match-start.png`
- 敌军进攻、模型命令失败与右侧战场：`05b-defense-with-battlefield.png`
- 自然终局计分：`06-natural-result.png`
- 模型败局复盘与终局同屏：`07-model-review-and-result.png`

证据根目录为 `/private/tmp/dsh-ra-model-micro.8YuO3T/evidence`。这些是本机临时验收材料，不进入 npm 发布包。

## 7. 指标

```text
REAL_MATCH_NATURAL_FINISH=1
MODEL_IS_COMMAND_SOURCE=1
BACKGROUND_COMMANDER=0
FULL_DSH_SCREENSHOT_EVIDENCE=1
POSTGAME_RULE_COMMIT=1
ADAPTER_COMMAND_RELIABILITY=0
MODEL_MICRO_READY=0
NATURAL_VICTORY=0
```

本轮没有修改 DSH checkout、兼容客户端源码、游戏素材，也没有提交或推送。

## 8. Renderer v5 复跑

同日使用 `dsh-red-alert-renderer-v5` 在同一个 DSH 标签页重新跑了一整局。模型仍为 `DeepSeek-V4-Pro High`，配置仍为 Russians、1 个 normal AI、`mp02t2.map`、gameSpeed 2；右栏同时显示真实客户端和“左键拖动观战”状态，没有启动后台规则指挥器。

| 项目 | 结果 |
|---|---|
| Match ID | `fa7980a5-b48b-43bb-8dc1-9a86422efaa4` |
| 引擎状态 | `finished`，本方战败 |
| 游戏时间 | `0:06:12` |
| 终局 tick | `5579` |
| 普通 AI | 300 分，17 摧毁，5 损失 |
| Player 1 | 25 分，5 摧毁，22 损失 |
| DSH 模型回合 | 41 步；LLM 7 分 7 秒；工具 1 分 4 秒；总用时 8 分 11 秒 |

这一局比上一局更早并行排队战车工厂、哨戒机枪、军犬和动员兵，首波接敌时画面中已有多座建筑和一批守军。模型仍在生产阶段花了过多时间分析和等待；接敌后又出现系统性的 `ADAPTER_COMMAND_FAILED`，导致批量集火、继续生产和防御放置没有可靠执行。战车工厂尚未落地，装甲单位仍为 0，最终以 5:17 的摧毁交换比失败。

终局后 `red_alert_review_match` 已提交，`anti-infantry-defense`、`armor-before-contact`、`rush-defender-target` 三条规则的置信度升至 0.95，`evidenceMatches=2`。这再次证明规则能持久积累，但也说明仅增加复盘规则无法解决模型实时决策延迟和命令适配器失效。

整页截图保存于 `/private/tmp/dsh-red-alert-viewer-v5-evidence`：

- `01-opening.png`：建局、真实客户端和模型工具调用同屏。
- `02-early-base.png`：电厂与基地前期建设。
- `03-mid-expansion.png`：矿场、兵营、守军和模型生产调用。
- `04-first-contact.png`：双方步兵在基地西侧接敌。
- `05-result.png`：真实客户端自然失败计分。
- `06-review.png`：模型终局复盘、已写入规则和右侧计分同屏。

复跑指标保持 `MODEL_MICRO_READY=0`、`NATURAL_VICTORY=0`、`ADAPTER_COMMAND_RELIABILITY=0`。Renderer v5 解决了观战入口和页面可见性，没有解决战斗命令可靠性与模型回合速度。

## 9. Renderer 错误重试修复

复跑后切回一个停在 `creating` 的旧 Chat 时，右侧战场进入 `renderer adapter 报告错误`。只读检查确认 DSH Host 仍监听 `127.0.0.1:3080`，renderer Host 仍监听 `127.0.0.1:4318`，并且 `http://localhost:4318/` 能正常返回真实兼容客户端首页；故障位于页面内的 adapter 生命周期，而不是服务退出或 endpoint 丢失。

旧实现的“重试连接本地 renderer”会继续复用处于 `error` 或 `disconnected` 状态的 root adapter。兼容客户端把 session、match 和 seat 身份绑定到 iframe 页面生命周期；只重建消息桥而不重建旧 iframe，可能继续遇到旧身份并重复握手失败。修复后，健康 adapter 在 Chat remount 时仍会复用；明确失败的 adapter 会先完整 drain 和 dispose，再按当前 live config 注册新的 loopback adapter，从而用全新 iframe 完成握手。

回归测试先证明旧实现没有调用 `removeSession`，随后验证修复后的失败 adapter 会被销毁并重新注册。该修复不改变战争迷雾投影、模型命令权限或 endpoint 安全边界。

## 10. 终局重连与同 Chat 下一局修复

第二次现场复核确认上一节只覆盖了运行中 adapter 失败，没有覆盖 DSH 服务重启后重新打开自然终局 Chat。Host 的 live renderer 配置按安全合同只接受 `creating` 或 `active` match；旧终局是 `finished`，页面却仍显示“重试连接本地 renderer”，所以每次点击都会被 Host 以 `NO_ACTIVE_MATCH` 拒绝并再次显示同一个泛化错误。

修复后，没有仍存活 adapter 的终局页面显示“上一局已经结束”，不再提供必然失败的重连按钮；同一浏览器中仍存活的终局画面继续保留。模型完成结构化复盘后，`lobby/setup` 的 `red_alert_start` 会在 ended 阶段重新可见，同一 Chat 可以创建新的 `matchId`。客户端先释放旧 match lease，root renderer 再按新身份重载兼容客户端，避免旧 lease 或旧 iframe 身份污染下一局。

新增回归分别覆盖终局刷新不发 live config、同 session 旧 lease 释放顺序、root renderer 新 match 身份重绑，以及一次自然终局和 review 后同一 Agent session 成功开始第二局。这个修复只允许顺序对局；同一 session 仍然不能同时持有两个 active match。
