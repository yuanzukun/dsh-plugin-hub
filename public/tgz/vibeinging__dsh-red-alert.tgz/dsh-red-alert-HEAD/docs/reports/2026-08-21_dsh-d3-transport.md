# D3 Host 到浏览器 transport 当前证据

状态：D3 只交付外部插件内的安全 transport 机制，真实兼容客户端 adapter、真实游戏画面、完整工具 wrapper 和生产级跨重启恢复尚未交付；`VISUAL=0`、`SAME_MATCH=0`、`TOOL_COVERAGE=0`、`LAZY_LOAD=0`、`GROUP_LOADER_READY=0`、`RA_READY=0`。

Host 通过官方 `@deepseek-ai/dsh-client-connection@0.0.1-rc.1` 注册 loopback `/red-alert` channel，命令和结果都使用 admitted event 加 publication marker 的两阶段 session event。admitted command 先 flush 且 projection 保持 `idle`，command marker 之后才产生 `pending`；完整 result、failure 或 cancellation 先 append 并 flush，projection 仍保持 `pending`，严格匹配 request/session/match/seat/status 的 result marker 之后才产生终态，Host promise/RPC 也只在 marker append 后结算。result marker 本轮不单独 flush，marker 后立即崩溃的 replay/recovery 边界列为 D4。命令、回执、lease、session、match、seat 和 tick 均经过严格边界校验，token 不进入 session event、projection、模型输出或日志。

Host admission 和 browser decoder 对 `orders` 共同限制为最多 `256` 项；`257` 项在首次 session append 前立即拒绝并产生零事件。receipt observation 的 `ownUnits`、`visibleEnemies`、`lastSeenEnemies` 和 `visibleNeutralObjects` 各自最多 `4096` 个联系人，这是每集合上限而不是四集合合计上限。

client root service 不依赖红警标签是否显示，按当前 session 消费 command projection。adapter 调用前登记运行中的 promise，同一 `BrowserCommandClientConsumer` 生命周期内的并发 reconcile 共享一次执行；取消、超时、session switch 和 dispose 等待 adapter、订阅、channel 和 lease drain。Host 全局 dispose 复用每个 session 的 cleanup drain，等待 admission、result finalization 和 lease 清理结束或报告失败后才返回。`BrowserMatchAdapter` 当前只提供 `command(command, signal)` seam，要求 adapter 在 abort 后尽快 settle；start/status/stop/renderer attach 属于 D4。

构建后的 `./client` 公开导出 `BrowserMatchAdapter`、`BrowserAdapterRegistry` 和 `BrowserCommandClientService`，并声明 `ctx.redAlertBrowserCommands` 的 client service 类型；packed Profile 风格 smoke 验证运行时导出可达。adapter 抛出的原始异常和 Host admission/flush 内部异常不会返回 caller，也不会进入 logger、receipt、session event 或 projection；日志、caller 和持久边界只保留固定诊断、稳定 code 和通用文案。

## 可复现证据

| 范围 | 命令 | 结果 |
|---|---|---|
| Host/client transport 专项 | `pnpm vitest run tests/browser-command-transport.test.ts --reporter=verbose` | 34/34 通过 |
| Loader 组合 | `pnpm vitest run tests/loader-composition.test.ts --reporter=verbose` | 15/15 通过 |
| client Loader 激活 | `pnpm vitest run tests/client-loader-activation.test.ts --reporter=verbose` | 1/1 通过 |

专项覆盖 admission flush 边界、全局 dispose 等待慢 admission、取消结果 flush 失败不重复追加 result、result-admitted/result-marker 顺序、乱序和未知字段 fail closed、双重 dispose、unregister 失败清理、timeout/abort、晚到和不同回执、lease 身份、客户端重复 projection、session 隔离、同一 consumer 的 adapter exactly-once、Cordis `connection/reset` 事件重放、caller/事件/RPC 原始错误文案脱敏、官方 Connection RPC 解码和 assembled Host Session/SessionProjectionRegistry projection 顺序。

## 恢复边界

同一页面 connection generation 收到官方 `connection/reset` 后，仍存活的 consumer 会重新协调当前 projection；同一 consumer 生命周期内的并发 reconcile 不重复调用 adapter。浏览器刷新或 client root 重建会产生新的内存 `clientInstanceId`，D3 没有 lease takeover；Host/client 重启后 pending projection 也没有 durable adapter idempotency，不能安全判断命令是否已经执行。不得使用 `localStorage` 作为权威，因此页面刷新、client 重建和 Host/client 重启后的恢复与 exactly-once 是 D4 BLOCKED。

本报告不把 fake adapter、assembled transport、旧 DSH Web 态势投影、SVG/Canvas、截图、回放或构建成功写成真实红警页面或同局验收。真实兼容客户端 adapter、资源抽取、实际地图和 DSH Web 主页面接入仍需后续独立证据。
