# Renderer v5 可拖动观战验收

## 结论

Renderer revision 5 已实现嵌入 DSH 时的可拖动观战模式。对局中用户可用左键、中键或右键拖动画面，可点击或拖动小地图，也可用方向键和滚轮移动镜头。上述输入只改变本地视角，不能把选择、生产、建造、维修、出售、编队或战斗动作写入对局。模型仍通过可审计的 DSH 工具调用控制游戏。

本轮没有修改 DSH 源码，没有把第三方源码、构建产物或游戏素材复制进插件仓库，也没有提交或推送。

## 实现边界

- `WorldInteraction` 在通过正式 companion 握手的嵌入模式下，把左、中、右键拖动统一映射为镜头平移。
- 小地图左键和右键只调用镜头定位，不执行单位命令。
- 方向键仍可滚动画面；普通键盘命令和游戏内聊天输入被关闭。
- 左键拖动不再进入框选，松开鼠标不执行默认动作。
- `CombatantUi.pushAction` 在嵌入观战模式下 fail closed，阻止生产栏、建造、维修、出售、联盟和命令栏等 UI 动作进入 action queue。
- 普通独立客户端不启用该限制，保留原有游戏输入。
- DSH 右栏的活动状态显示“左键拖动观战”，README 中英文版同步说明操作和模型控制边界。

## 验证证据

- `pnpm run check:renderer-adapter`: 通过，16 个受控上游路径，锁定 commit `8c07f1092b2a9e8d8605ed49ef46d77b6c3ea367`。
- `pnpm run check:rules`: 通过，50 个插件文件和 29 个产品文件。
- `pnpm vitest run tests/client-default-view.test.ts tests/setup-dsh.test.ts --reporter=verbose`: 2 个测试文件、10 个测试全部通过。
- `pnpm run typecheck`: 通过。
- `pnpm run typecheck:tests`: 通过。
- `pnpm run lint`: 通过。
- `git diff --check`: 通过。
- 从锁定上游提交全新准备 `/private/tmp/dsh-red-alert-viewer-v5-20260824`: companion 12/12 测试通过，Vite 转换 1225 个模块并构建成功，marker 为 `dsh-red-alert-renderer-v5`。

构建仅出现上游已有的 CommonJS、动态导入和大 chunk 警告，命令退出码为 0。

## 浏览器验收状态

隔离 DSH 环境启动前，唯一的应用内浏览器标签页先进入了浏览器自带的 `ERR_CONNECTION_REFUSED` 数据页。服务恢复后，浏览器安全策略拒绝从该数据页自动导航回 `http://127.0.0.1:3080/`。本轮遵守单标签页和浏览器安全策略，没有新开更多标签、没有切换浏览器，也没有绕过策略。因此代码、测试和全新构建已通过，但本轮没有把鼠标拖动后的整页截图记为真实浏览器验收证据。

交付时隔离 Profile 已切到 `/private/tmp/dsh-red-alert-viewer-v5-20260824/dist`，`http://127.0.0.1:3080/` 返回 HTTP 200，启动器没有创建新标签页。用户只需在现有 DSH 标签页手动重新加载一次。页面进入活动对局后，右栏状态会显示“左键拖动观战”，可直接拖动验证镜头移动。
