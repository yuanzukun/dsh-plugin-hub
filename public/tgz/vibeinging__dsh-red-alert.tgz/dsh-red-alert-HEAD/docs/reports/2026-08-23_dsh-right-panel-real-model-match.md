# DSH Chat 右栏真实模型对局报告

状态：真实 DSH Web、真实模型和真实兼容客户端验收完成，2026-08-23。本报告不把构建、静态测试或独立 renderer 截图当成 DSH 整页验收。

## 1. 结论

插件已改为中间保留 DSH 原生 Chat、右侧显示真实红警 2 兼容客户端，不再注册与 Chat 平级的红警页面。用户输入框、模型思考、工具调用、运行统计和右栏游戏画面可以同时看到，顶部“战场”按钮支持展开、放大和收起右栏。

真实对局使用 `DeepSeek-V4-Flash High`、Russians、一个兼容客户端 `normal` AI、`mp02t2.map` 和 `gameSpeed=0`。对局从创建运行到引擎自然结束，最终 tick 6044、游戏时间 402.9 秒、我方 `defeated=true`；失败结果如实保留，不把完成一局写成获胜。

## 2. DSH 外部插件边界

正式改动只在 `/Users/Four/PersonalProjects/dsh/dsh-red-alert`。UI 通过官方 `@deepseek-ai/dsh-client-ui-layout` SDK 挂到 conversation header action 和右侧 layout，不修改 `/Users/Four/.dsh/source/current`、DSH Web 源码、内置 Profile、vendor 或游戏素材。

插件不替换 Chat，不复制 composer，也不创建第二套消息流。右栏只承载同一 session 的 renderer；Chat 仍由 DSH 自己渲染和记录用户消息、模型消息、工具事件与统计。

## 3. 启动时序修复

真实模型可能先发出 `red_alert_start`，右栏 renderer 随后才完成挂载。client consumer 因此会在同一 session 的 adapter 附加预算内等待，而不是立刻返回 `ADAPTER_UNAVAILABLE`。

等待预算保存在 `RedAlertRendererDescriptor.adapterAttachTimeoutMs`，属于浏览器 UI 状态。绝对 deadline 不进入 `BrowserCommandEnvelope`，真实游戏命令仍保持严格的 protocol、request、session、match、seat、tick、kind 和 request/orders 字段，避免把调度信息传入严格 renderer schema。

专项 `tests/browser-command-transport.test.ts` 共 42 个测试通过，其中覆盖延迟附加成功、超时失败关闭、listener 清理、exactly-once、重连、取消和 session 切换。

## 4. 整页布局证据

验收视口为 1440×900。左侧为 DSH session 列表，中间为原生 Chat 与输入框，右侧战场约从 x=1079 开始、宽 361 像素；游戏 iframe 使用同一 browser instance，并在放大或收起操作中保持 session identity。

截图目录为 `/private/tmp/ra2web-d1.aba9YH/playwright-evidence-dsh-right-chat-success-20260823`，共保存 28 组整页、右栏和游戏区域截图。没有把含第三方游戏美术的截图复制进开源插件仓库。

代表性整页截图：

- `03-opening-dsh-command-center.png`：Chat 显示创建参数、MCV 展开和按需工具组，右栏显示开局基地与战争迷雾。
- `20-battle-4-dsh-command-center.png`：Chat 显示当前可见敌军、我方损失、补兵和 attackMove，右栏显示同一 tick 的基地交战。
- `28-battle-12-dsh-command-center.png`：Chat 显示 `status=finished`、`self.defeated=true` 和 `MATCH_FINISHED`，右栏显示兼容客户端真实失败结算页。

## 5. 对局事实

| 项目 | 结果 |
| --- | --- |
| matchId | `50f494fe-38d9-41c4-bba4-169f4757df8c` |
| 地图 | `mp02t2.map`，200×200 |
| 我方 | Russians |
| 对手 | 1× `normal` AI |
| 速度 | `gameSpeed=0`，双方共用 10 tick/s |
| 模型 | `DeepSeek-V4-Flash High` |
| 过程 | 17 turns、130 steps、LLM 7m38s、工具 12.3s |
| 终局 | tick 6044、402.9 秒、`finished`、`self.defeated=true` |

模型实际执行了 MCV 展开、电厂和兵营建设、E2 步兵生产、编队侦察、批量 attackMove、当前可见敌军攻击和建筑维修。普通 AI 的军犬与 E1 只有进入我方合法视野后才出现在模型观察中；单位在观察后被消灭或敌人离开当前视野时，后续命令由 adapter 按当前所有权和可见性失败关闭。

## 6. 败局学习

模型多次把 `building is not ready for placement by this seat` 误判成 adapter 故障，跳过了“先 production queue、等 status 3 ready、再 construction place”的真实生产时序。矿场和战车工厂没有形成，normal AI 持续增援步兵后摧毁兵营、电厂和建造厂。

开局 system prompt 已据此补充严格建筑时序，并增加测试锁定提示合同。该改动代表从本次失败形成的可审查策略修正；跨对局自动 episode、战后 review 和 StrategyProfile 仍是后续能力，当前不能声称已经自动持续学习或已经提升胜率。

## 7. 验收边界

- 真实模型、真实 DSH Chat、真实 renderer、normal AI 和自然终局已通过。
- Chat 与右栏同屏、用户可继续输入、模型输出和工具步骤可见已通过。
- 启动时 adapter 延迟附加和严格命令边界已通过专项测试与真实启动。
- 本局结果是失败；新的 ready 时序教义尚未用第二局胜率复验。
- 截图和最小 MIX 归档只留在 `/private/tmp`，未进入正式仓库。
- 没有 commit、push 或发布。
