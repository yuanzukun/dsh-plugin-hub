# DSH 红警速度 2 三局学习实测报告

状态：DONE_WITH_CONCERNS。三局真实模型对战已完成评测，前两局自然战败，第三局在评测边界仍未结束；自动学习跨局生效，但没有胜局，不能声称胜率已提高。

## 1. 测试条件

- DSH 原生 Chat 和右栏真实兼容客户端在同一整页中运行，模型为 `DeepSeek-V4-Flash High`。
- 地图为 `mp02t2.map`，己方为 Russians，对手为 normal compatible AI。
- 游戏速度为 2，对应 15 tick/s。
- 资源由用户本地导入；运行时设置 `DSH_TELEMETRY_DISABLED=1`。
- 模型只能读取绑定座位的 `FogSafeObservation`、当前可见敌军和冻结的 last-seen，不读取隐藏出生点、敌方经济、renderer raw world 或 Canvas 像素。
- 共保留 142 张 DSH 整页截图，页面同时包含模型消息、工具调用和真实游戏画面。

## 2. 三局结果

| 局次 | Match ID | 结果 | 最终或观察 tick | 主要表现 | 赛后学习 |
|---|---|---|---:|---|---|
| 1 | `9302b1ae-3850-4074-bb81-273144e5c18b` | 战败 | 5564 | 完成 MCV、电厂、矿场和兵营；己方峰值 15 个防守单位，对方约 29 个；接敌前没有装甲 | 自然终局后采用 4 条规则，置信度均为 0.77 |
| 2 | `d1d385a0-9121-4f6e-8d59-b1d82c102efa` | 战败 | 12995 | 读取上一局 4 条规则；完成完整基地链、战车工厂和 3 辆坦克；存活 tick 为第一局的 2.34 倍 | 自然终局后将 `anti-infantry-defense` 和 `armor-before-contact` 提高到 0.95 |
| 3 | `295d447c-0e88-4c30-bcda-2b8bfff8b3bd` | 评测边界仍在进行 | 24090 | 基地和生产链仍完整；有 1 个碉堡、2 个矿车、61 个 E2、2 辆重伤 Rhino；约消灭 30 个 E1、1 条军犬和 4 辆 MTNK | 成功读取前两局规则；由于没有自然终局，不写赛后 review |

第三局侦察到约 `(104-105, 95-96)` 的敌方区域来自单个侦察单位的当前合法视野，不是隐藏地图数据。

## 3. 自动学习证据

第一局开始时策略 brief 为空。第一局战败后，模型采用 `rush-defender-target`、`anti-infantry-defense`、`armor-before-contact` 和 `act-before-reread`，每条置信度为 0.77。

第二局开始时读取到上述四条规则。第二局战败后的结构化 review 再次确认反步兵防御和接敌前装甲，使两条规则的置信度提高到 0.95，其余两条保持 0.77。

第三局开始时读取到两条 0.95 和两条 0.77 的短策略。这证明策略事件能在 Profile 中跨局持久化并进入下一局模型上下文，但它只是可审计的经验规则，不是模型权重训练。

## 4. 观察到的改善和问题

可以确认的改善是存活时间、基地完整度和防守兵力：第一局 tick 5564 战败，第二局 tick 12995 战败，第三局到 tick 24090 仍在作战。三局不是固定随机种子，而且第三局没有结束，因此这些变化不能换算成胜率。

主要执行问题：

- 队列不变时仍重复读取状态，浪费决策周期。
- 战斗中继续使用过期单位 ID，导致命令失败或无效。
- 多次重试当前不可放置的建筑，尤其是 sentry placement，缺少失败预算和替代动作。
- 过量排队 E2 挤占矿场和坦克资源；第三局达到 61 个 E2 时关键经济项目仍在等待。
- 第二局手动移动矿车后采矿停滞，经济链中断。
- `red_alert_rules` 多次返回 `ADAPTER_COMMAND_FAILED`；部分生产取消返回 `browser production item is required`。

下一轮应把“高置信度规则”改为带失败预算的行动约束：同一建筑放置连续失败后立即换位置或换方案；每个决策周期先执行最多一组可独立并行的动作，再读取一次新状态；设置步兵、矿车和装甲的资源保留线，避免单一队列耗尽资金。

## 5. 截图证据

- 第一局交战：`match-1/13-turn-5-running-dsh-command-center.png`
- 第一局自然终局和 review：`match-1/16-turn-6-complete-dsh-command-center.png`
- 第二局首辆 HTNK 和基地状态：`match-2/17-turn-7-running-dsh-command-center.png`
- 第二局自然终局和 review：`match-2/30-turn-13-complete-dsh-command-center.png`
- 第三局较强防守状态：`match-3/54-turn-25-complete-dsh-command-center.png`
- 第三局评测边界：`match-3/60-turn-28-complete-dsh-command-center.png`

证据根目录为 `/private/tmp/ra2web-d1.aba9YH/playwright-evidence-dsh-speed2-learning-series-final-20260823`，核对摘要为其中的 `series-summary-verified.json`。这些是本机临时验收材料，不是发布包内容。

## 6. 指标

```text
REAL_SPEED2_REMATCH=1
AUTO_LEARNING_PERSISTENCE=1
FULL_DSH_SCREENSHOT_EVIDENCE=1
NATURAL_FINISH_REVIEW=1
SERIES_VICTORY=0
WIN_RATE_EVIDENCE=0
```

本轮没有修改 DSH checkout、兼容客户端源码、素材或 Profile，也没有提交或推送。
