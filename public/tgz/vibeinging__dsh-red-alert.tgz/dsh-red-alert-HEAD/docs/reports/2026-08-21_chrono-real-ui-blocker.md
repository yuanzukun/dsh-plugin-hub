# Chrono Divide 真实页面阻塞报告

状态：阶段 4 官方能力核验完成，`VISUAL=0`，因此 `RA_READY=0`。

本报告只判断官方公开 Game API 和真实 Chrono Divide 页面是否能满足“两个程序化 AI 同局、同一 AI 视角、战争迷雾、刷新或重连不展示全图”的硬门槛，没有把离线 Canvas、回放或真人对 AI 当作替代证据。

## 版本和一手来源

插件当前锁定 `@chronodivide/game-api@0.75.0`，类型文件为 `node_modules/@chronodivide/game-api/dist/index.d.ts`，在线配置字段是 `serverUrl`、`clientUrl` 和 `botPassword`。

官方 npm registry 当前最新版本是 `@chronodivide/game-api@0.78.0`，查询结果为 `dist.integrity=sha512-7IwqGOdHTbtAJUpzPICEsGYN2Kwk3GOCtSwJZvZY9l5LH/shiYwT4ornI0DgUiGRtUNX+BReUrvpG6kGgC/WMA==`，官方 tarball 为 `https://registry.npmjs.org/@chronodivide/game-api/-/game-api-0.78.0.tgz`。

官方 npm 包和 README：[https://www.npmjs.com/package/%40chronodivide/game-api?activeTab=readme](https://www.npmjs.com/package/%40chronodivide/game-api?activeTab=readme)。

官方 Game API 样板：[chronodivide/game-api-playground](https://github.com/chronodivide/game-api-playground)，其 README 说明离线模式可以由多个计算机 Agent 对战，在线模式是 AI 对真人。

官方产品入口：[Chrono Divide](https://chronodivide.com/)；官方浏览器客户端：[game.chronodivide.com](https://game.chronodivide.com/)。

## 官方类型和入口证据

在 0.75.0 和 0.78.0 的 `dist/index.d.ts` 中，`Agent` 只有 `name` 和可选 `country` 数据字段，类型注释说明省略 `country` 表示观察者；它没有 Bot 的 tick 回调、命令接口或程序生命周期。

离线合同是 `CreateOfflineOpts.agents: Bot[]`，因此离线多 AI 真实引擎局是受支持的。

在线合同是 `CreateOnlineOpts.agents: [Bot, ...Agent[]]`，第一个位置是唯一程序化 Bot，其余位置是 Agent；公开 `PublicApi.createGame` 类型注释明确写出在线模式只能有一个 AI，且该 AI 必须是第一个元素。

运行入口是官方包导出的 `cdapi.createGame({ online: true, ... })`；0.75.0 使用 `serverUrl`、`clientUrl`、`botPassword`，0.78.0 使用 `xwolApiUrl`、`clientUrl`、`apiKey`，页面连接地址通过 `onGameCreate` 回调取得。

在线合同提供 `onGameCreate?(joinUrls: Map<Agent, string>)`，它能为 Agent 提供页面加入地址，但没有把第二个 Agent 变成 Bot、把程序化决策回调接到页面连接、或保证重连后仍绑定某个 AI 视角的公开扩展点。

0.78.0 将在线认证改为 `xwolApiUrl`、`clientUrl` 和 `apiKey`，替代 0.75.0 的 `serverUrl`、`botPassword` 和 `nonInteractive`；这只是认证合同变化，没有增加第二个程序化 Bot。0.78.0 还要求在线客户端预先安装地图，不能用自动地图传输替代页面验收。

结论是：官方公开合同没有两个程序化 Bot 同时进入同一在线局的路径。Agent 的观察者形式可以产生页面连接数据，但它仍然是客户端连接位，不是第二个可由 DSH 驱动的 AI；通过浏览器或私有客户端注入来补齐这一点会超出外部插件和官方 API 边界。

## 可重复检查

仓库新增 `scripts/check-chrono-online-contract.mjs`，脚本只读取目标 Game API 包的 `package.json` 和 `dist/index.d.ts`，不连接 DSH 源码，也不启动在线局。

检查当前插件锁定版本：

```sh
pnpm run check:chrono-online
```

检查官方最新 tarball：

```sh
chrono_tmp_dir="$(mktemp -d)"
npm pack @chronodivide/game-api@0.78.0 --pack-destination "$chrono_tmp_dir" --ignore-scripts --registry=https://registry.npmjs.org
tar -xzf "$chrono_tmp_dir/@chronodivide-game-api-0.78.0.tgz" -C "$chrono_tmp_dir"
CHRONO_GAME_API_ROOT="$chrono_tmp_dir/package" node scripts/check-chrono-online-contract.mjs
```

两次检查都应输出 `schema=chrono-online-contract-v1`、`onlineAgentsHaveSingleBotHead=true`、`onlineDocsLimitToOneAi=true`、`supportsTwoProgrammaticBots=false` 和 `ok=true`；当前版本的认证形态应为 `legacy-server-bot-password`，0.78.0 应为 `xwol-api-key`。

registry 版本和完整性查询：

```sh
npm view @chronodivide/game-api version dist-tags.latest dist.integrity dist.tarball --json --registry=https://registry.npmjs.org
```

## 三项不能替代 VISUAL 的证据

1. `packages/game-host/web/index.html` 和 `serve.ts` 是插件自己的离线调试投影，只绘制插件输出的 frame，不是官方 Chrono Divide 客户端连接；它们不能证明同一在线局的客户端状态、用户 AI 视角或战争迷雾。
2. `.rpl` 回放可以由官方页面导入并回看完整画面，但它是赛后数据，不是同一局实时运行 1500 tick，也不能证明刷新或重连时页面继续保持公平视角。
3. 官方在线合同支持一个 Bot 对真人；即使提供账号、页面加入地址并完成真人对 AI，也不能证明两个程序化 AI 同局，因此不能将 `VISUAL` 记为 1。

## Gateway 决定和最小外部条件

本阶段不实现 Gateway，因为外部插件无法通过官方 API 创建缺失的第二个程序化 Bot；实现一个 loopback 地址或返回一个 join URL 会掩盖这个阻塞，也不能产生有效的 1500 tick AI 对 AI 页面证据。

若后续官方提供双 Bot 合同，或用户明确接受官方支持的 Bot 对真人验收，最小外部条件是 XWOL API key、官方 API URL、官方 client URL、Bot 账号及页面连接账号、0.78.0 要求的预装地图，以及能够实际运行 1500 tick、刷新或重连并检查同一 AI 视角和战争迷雾的测试环境；凭据只能从环境或安全存储读取，不进入工具结果和 session log。

本阶段没有创建伪造 `joinUrl`，没有修改在线工具，不修改 DSH 源码，不注入 Chrono Divide 私有客户端，没有写入账号或密钥。
