# 战场快照 Schema v1（公平观察层）

> 2026-08-21 阶段 1 已完成公平观察层。本文定义 LLM 指挥官和当前调试侧栏可以使用的产品观察边界；`dump-snapshot.ts` 仍是 referee/debug 工具，不得作为产品观察输入。

## 公平观察层（当前实现）

`FogSafeProjector` 是敌情和中立对象的唯一产品入口，输出结构如下：

```text
FogSafeObservation {
  tick: number
  ownUnits: FogSafeContact[]
  visibleEnemies: FogSafeContact[]
  lastSeenEnemies: FogSafeContact[]
  visibleNeutralObjects: FogSafeContact[]
}

FogSafeContact {
  id: number
  unitType: string
  label: string
  kind: string
  position: { x: number; y: number }
  hpPct: number
  observedAtTick: number
  source: "visible" | "last-seen"
}
```

约束：

- 当前敌军 ID 只来自 `getVisibleUnits(self, "enemy")`。
- 当前可见中立对象严格使用 `getVisibleUnits(self, "hostile") - getVisibleUnits(self, "enemy")`，产品 AI/UI 路径不调用全量 `getNeutralUnits()`。
- `lastSeenEnemies` 只在敌军可见时更新；隐藏期间位置、血量、数量和存活状态冻结。
- 再次进入视野时才用当前 `getUnitData()` 刷新，并把 `source` 改回 `visible`。
- 敌军 ID 不是 hostile ID 的子集、可见 API 抛错或可见单位资料缺失时，投影直接抛错，不调用指挥官，也不回退到全局列表。
- 产品快照不再包含敌方出生点，也不在提示词中生成出生点方向。

## DSH 外部 bundle 适配（阶段 2）

`@vibeinging/dsh-red-alert` 只把这份公平观察和离线引擎状态通过标准工具结果交给 DSH。`red_alert_start` 返回第一观察点，`red_alert_act` 返回命令回执和下一观察点，`red_alert_status` 只读，`red_alert_stop` 保存并关闭对局；结果明确标记 `view.mode=offline` 和 `realUiAvailable=false`，不包含伪造的在线入口。

工具生命周期按 Agent session 隔离。一个 session 不能同时持有两个 active match，matchId 必须与 Agent 和 session 所有权同时匹配；Agent 释放或插件 teardown 时，所属对局进入保存和关闭流程。观察输出在运行时再次检查 visible enemy 子集、可见中立集合差和 source 标记，检查失败会阻断结果。

侧栏帧保留 `source` 和 `observedAtTick`。页面只对 `source=last-seen` 使用低透明度虚线和“最后发现”标签，不把冻结坐标绘制成当前可见敌军。

DSH 红警主标签使用 session projection 的完整公平观察绘制 SVG 战术地图；公开 `mapSize` 只来自 `GameApi.map.getRealMapSize()`，不从全量地图状态推导。Chat 是同一 session 的第二控制标签，浏览器只通过 `useProjection("redAlert")` 恢复状态。

## referee/debug 原始数据

`dump-snapshot.ts` 可以继续输出全量玩家、出生点、全局中立对象和超级武器，用于离线调试和反作弊对照；这些字段不进入 `buildSnapshot()`、`snapshotText()`、`buildBattleFrame()` 或指挥官路径。

## 聚合层（当前实现）

在公平观察层之上，`buildSnapshot()` 生成指挥官视图：

- `ownCombatGroups`：我方单位按 rules.ini 内部名聚合。
- `enemyContacts`：当前可见敌军聚合，并保留 `source=visible` 与 `observedAtTick`。
- `lastSeenEnemyContacts`：隐藏敌军的最后已知聚合，位置、血量和观察 tick 冻结。
- `visibleNeutralObjects`：当前可见中立对象聚合，来源只能是 hostile 与 enemy 的集合差。
- `events`：相邻决策周期的我方损失、新增单位和新发现敌情。

## 单位字典层（unitLexicon，v1 新增设计）

快照/指令中的单位名是 rules.ini 内部名，LLM 不可直接理解。字典层提供映射：

| 内部名 | 语义 | 类别 |
|---|---|---|
| NACNST / GACNST | 苏军/盟军 基地 | 建筑 |
| NAPOWR / GAPOWR | 电厂 | 建筑 |
| NAREFN / GAREFN | 矿场 | 建筑 |
| NAHAND / GAPILE | 兵营 | 建筑 |
| NAWEAP / GAWEAP | 战车工厂 | 建筑 |
| E2 / E1 | 动员兵 / 美国大兵 | 步兵 |
| DOG | 军犬 | 步兵 |
| SMCV / AMCVC | 苏军/盟军 MCV | 载具 |
| HARV / CMIN / WMIN | 采矿车 | 载具 |

- 字典以 prompt 前缀注入（约 300 token，常用 ~60 单位）
- 冷门单位：commander 经 tool 查 `getRulesIni`（M2 起）；M1 先扩字典到本地图全量
- 字典数据源：`assets/rules.ini` 解析生成（脚本化，M1 落地）

## 指令 schema v1（对照）

见技术方案 §4.1 OrderTranslator。v1 实测约束：
- 建筑摆放指令必须带 `sectorHint`（全图合法位扫描由桥执行，`canPlaceBuilding` 校验）
- 单位指令引用聚合层 `groupId`，不引用裸 unit id
