# DSH Red Alert 插件执行与复查计划

状态：计划已完成，2026-08-22。开发、复查和验收均在当前项目中完成；没有修改 DSH 源码，没有提交或推送。

## 1. 唯一完成指标

```text
RA_READY = min(PROFILE, FOG, VISUAL, TOOL_COVERAGE,
               LAZY_LOAD, SAME_MATCH, DSH_CONTRACT, REGRESSION)
```

八项只能取 0 或 1。任何一项为 0，整体就是 0。

最终结果：

```text
RA_READY = min(1, 1, 1, 1, 1, 1, 1, 1) = 1
```

## 2. 完成阶段

### 阶段 A：真实客户端可行性

完成内容：

- 证明官方 `game.chronodivide.com` 不能跨源 iframe 嵌入。
- 证明 `@chronodivide/game-api` 是 headless API，不自带可挂载 renderer。
- 锁定 GPLv3 兼容客户端提交 `8c07f1092b2a9e8d8605ed49ef46d77b6c3ea367`。
- 用用户自己的最小 7z 归档进入真实地图、HUD 和小地图。

该阶段只决定路线，不计正式指标。

### 阶段 B：工具策略与按需加载

完成内容：

- 85 个 game-api 公共声明全部分类。
- 22 个 manifest 项与真实注册集合双向校验，其中战场手册作为插件自有静态知识工具不映射隐藏引擎方法。
- 删除跨组 `red_alert_act`，拆成精确 wrapper。
- version 1 持久 group selection、v0 恢复、fail-closed decoder 和 rollback。
- 初始只显示 capability/loader，阶段变化重新收紧。

完成指标：`TOOL_COVERAGE=1`、`LAZY_LOAD=1`。

### 阶段 C：DSH 外部 transport 和 Chat 右栏容器

完成内容：

- 官方 SDK dual-face Host/client bundle。
- plugin-owned loopback renderer server。
- 严格 origin/source/session/match/seat/tick bridge。
- 两段 command/result session event。
- client root consumer、lease、取消、超时和 dispose。
- 可恢复 error 不卸载 iframe，不释放 active match identity。
- 通过官方 layout SDK 在原生 Chat 右侧注册战场 dock，不修改 DSH 源码，不增加平级红警 conversation view。

完成指标：`PROFILE=1`、`DSH_CONTRACT=1`。

### 阶段 D：公平兼容客户端 adapter

完成内容：

- CurrentLos 与 renderer 共用。
- 首帧隐藏对象失败关闭。
- visible 到 last-seen 的冻结转场。
- 迷雾外销毁不更新或清理 last-seen。
- 未识破 disguise 在字段复制前阻断。
- 当前可见地基内的最近合法建筑放置。
- 锁定源码补丁和一键准备流程。

完成指标：`FOG=1`。

### 阶段 E：真实 DSH 端到端验收

完成内容：

- 外部插件挂载到真实 DSH Profile。
- 用户在浏览器中导入只含三个 MIX 的资源归档。
- Chat 创建真实 1v1，并加载 lobby、observation、units、production 和 construction 组。
- 同局完成单位移动、SMCV 部署、NAPOWR 排队和放置。
- 右栏显示真实地图、战争迷雾、HUD、小地图、单位和建筑，中间 Chat 同屏显示真实模型输出和用户输入。
- 展开、放大和收起右栏保持同一个 iframe。
- 2026-08-23 真实模型对 normal AI 的慢速对局运行到引擎自然结束 tick 6044。

完成指标：`VISUAL=1`、`SAME_MATCH=1`。

### 阶段 F：最终回归和文档

完成内容：

- 从空目录执行一键 renderer 准备。
- renderer adapter gate、7/7 companion 测试和 1224 模块构建通过。
- 插件完整 `pnpm run check` 通过。
- README、需求、设计、计划和最终验收报告同步。

完成指标：`REGRESSION=1`、`RA_READY=1`。

### 阶段 G：赛后学习和指挥节奏增强

完成内容：

- 新对局默认速度改为 2，仍允许 0 到 6 且双方共享同一速度。
- 新增 `strategy/learning` 按需组、自动终局 episode、结构化 review 和下局 brief。
- 候选规则使用封闭 ID，不让自由文本或隐藏数据进入长期策略。
- 真实精确工具结果附带同一原子 receipt 生成的紧凑 `commandView`，减少重复读取。
- system prompt 明确模型是唯一战术决策者，要求模型在一个决策周期内亲自选择精确单位和目标，并在一个 `orders[]` 中连续执行全部独立合法微操；插件不运行后台规则 commander。
- episode 统计模型亲自提交的单位批次、order、攻击批次和撤退批次，终局后先 review 再总结。

实现证据由策略纯函数、DSH Loader 生命周期、命令视图边界和完整 `pnpm run check` 提供；真实速度 2 复赛和胜率提升必须另行取得真实对局证据，不能由静态测试代替。

## 3. 指标证据

| 指标 | 结果 | 必须保留的证据 |
| --- | --- | --- |
| `PROFILE` | 1 | 真实 Profile 安装、启动和 DSH checkout 零写入 |
| `FOG` | 1 | 10 局 audit `leakCount=0`、真实 LOS/last-seen 边界测试 |
| `VISUAL` | 1 | DSH 整页截图同时包含原生 Chat、用户输入、模型输出、工具步骤和右栏真实地图，终局 tick 6044 |
| `TOOL_COVERAGE` | 1 | 85 declarations、22 manifest、无 `red_alert_act` |
| `LAZY_LOAD` | 1 | 初始 schema 与 durable group selection 日志 |
| `SAME_MATCH` | 1 | session/match/seat/tick 与 tool receipt 链 |
| `DSH_CONTRACT` | 1 | built client/Profile smoke、projection/transport 测试 |
| `REGRESSION` | 1 | 完整 check 和全新 renderer prep |

证据总表见[最终验收报告](../reports/2026-08-22_dsh-real-client-final-acceptance.md)。

## 4. 复查规则

- 静态检查、单元测试、构建、真实浏览器和真实 DSH 是不同证据层，不能互相代替。
- 历史 spike 的 `BLOCKED` 结论只描述当时状态；只有正式仓库接线和真实 DSH 证据可以提升指标。
- 工具结果以 session log 为准，截图只证明页面显示。
- FOG 以结构化观察和边界审计为准，不能用“画面看起来有迷雾”代替。
- 未包含素材、未修改 DSH checkout、未提交和未推送必须继续检查。

## 5. 后续维护门禁

以下任一变化必须重新把相关指标置为 0，直到新证据完成：

- game-api 版本或 declaration 变化。
- renderer 上游提交或补丁变化。
- FogSafeObservation、CurrentLos 或 last-seen 字段变化。
- session event、projection、bridge protocol 或 identity 变化。
- 工具组、schema、phase 或 wrapper 变化。
- Profile、官方 SDK 版本或 client handoff 变化。

公开发布前还需要项目所有者单独决定顶层仓库许可、发布渠道和素材使用说明。这不影响当前本地外部插件的功能完成状态。
