import { createHash } from "node:crypto";
import { createReadStream, createWriteStream, existsSync, renameSync, statSync, unlinkSync } from "node:fs";
import { Readable, Transform } from "node:stream";
import { pipeline } from "node:stream/promises";

/** Return whether a local file exactly matches one declared archive. */
export async function fileMatchesArchive(file, descriptor) {
  if (!existsSync(file)) return false;
  try {
    const stats = statSync(file);
    if (!stats.isFile() || stats.size !== descriptor.byteLength) return false;
    const hash = createHash("sha256");
    for await (const chunk of createReadStream(file)) hash.update(chunk);
    return hash.digest("hex") === descriptor.sha256;
  } catch {
    return false;
  }
}

/** Stream one declared archive to disk and publish it only after size and digest checks. */
export async function downloadVerifiedArchive(descriptor, target, options = {}) {
  if (await fileMatchesArchive(target, descriptor)) return { reused: true };
  const fetchImpl = options.fetchImpl ?? fetch;
  const response = await fetchImpl(descriptor.url, { redirect: "error" });
  if (!response.ok || response.body === null) throw new Error(`resource download failed with HTTP ${response.status}`);
  const declaredLength = Number(response.headers.get("content-length"));
  if (declaredLength !== descriptor.byteLength) {
    throw new Error(`resource content-length mismatch: expected ${descriptor.byteLength}, got ${response.headers.get("content-length") ?? "missing"}`);
  }

  const temporary = `${target}.${process.pid}.${Date.now()}.part`;
  let received = 0;
  const hash = createHash("sha256");
  const verifier = new Transform({
    transform(chunk, _encoding, callback) {
      received += chunk.length;
      if (received > descriptor.byteLength) {
        callback(new Error(`resource exceeds declared size ${descriptor.byteLength}`));
        return;
      }
      hash.update(chunk);
      callback(undefined, chunk);
    },
  });
  try {
    await pipeline(Readable.fromWeb(response.body), verifier, createWriteStream(temporary, { flags: "wx" }));
    if (received !== descriptor.byteLength) throw new Error(`resource size mismatch: expected ${descriptor.byteLength}, got ${received}`);
    const digest = hash.digest("hex");
    if (digest !== descriptor.sha256) throw new Error(`resource SHA-256 mismatch: expected ${descriptor.sha256}, got ${digest}`);
    let rejectedPath;
    if (existsSync(target)) {
      rejectedPath = `${target}.rejected-${Date.now()}`;
      renameSync(target, rejectedPath);
    }
    renameSync(temporary, target);
    return { reused: false, ...(rejectedPath === undefined ? {} : { rejectedPath }) };
  } catch (error) {
    if (existsSync(temporary)) unlinkSync(temporary);
    throw error;
  }
}
