#!/usr/bin/env node

import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { createServer } from "node:net";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { downloadVerifiedArchive, fileMatchesArchive } from "./resource-download.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const packageManifest = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8"));
const packageName = packageManifest.name;
const packageVersion = packageManifest.version;
const sourceCheckout = existsSync(path.join(root, "src", "index.ts")) && existsSync(path.join(root, "pnpm-lock.yaml"));
const dshHome = path.resolve(process.env.DSH_HOME ?? path.join(homedir(), ".dsh"));
const statePath = path.join(dshHome, "red-alert", "install.json");
const profilePattern = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;
const rendererMarkerSchema = "dsh-red-alert-renderer-v5";
const rendererUpstream = "https://github.com/huangkaoya/redalert2.git";
const rendererCommit = "8c07f1092b2a9e8d8605ed49ef46d77b6c3ea367";
const requiredDshVersion = "0.1.1-rc.2";
const resourceArchive = {
  url: "https://download.ra2web.com/full-pack.7z",
  byteLength: 140_316_786,
  sha256: "3119b300794839ab597df556df8718c0a0a28fe89648ddced1c3790d801cb646",
  fileName: "dsh-red-alert-resource.7z",
  rendererUrl: "/dsh-red-alert-resource.7z",
};

function usage() {
  return `Prepare DSH Red Alert from the published package or a source checkout.

Usage:
  pnpm run setup -- --profile <name> [--download-resources] [--renderer-dir <path>] [--dry-run]

Options:
  --profile <name>       Existing DSH Web Profile. Default: web
  --renderer-dir <path>  New or already prepared compatible client directory.
                         Default: $DSH_HOME/red-alert/renderer-v5
  --download-resources   Download the declared RA2WEB archive after printing its
                         source, size, SHA-256, and rights notice. The verified
                         archive stays under $DSH_HOME and is never published.
                         Source: ${resourceArchive.url}
  --renderer-port <port> Stable loopback port used by the compatible client.
                         Default: reuse the last setup or select 4317-4367.
  --package-spec <spec>  Advanced: mount this exact package path or specifier.
                         Default: the current source checkout or published version.
  --dry-run              Print the exact plan without changing files.
  --help                 Show this help.

This command does not install DSH or modify a DSH source checkout. It downloads
no Red Alert 2 game assets unless --download-resources is explicitly present.
That flag authorizes only the exact source and digest printed by this command;
you remain responsible for confirming your right to use the archive. Setup uses
an exact temporary Bun tool through pnpm dlx only
when the compatible renderer must be prepared for the first time; no global Bun
installation is required. This release requires @deepseek-ai/dsh ${requiredDshVersion}.
The selected base Profile must exist. A previously mounted broken user plugin
does not block setup recovery. Your npm account must be able to install the
official @deepseek-ai SDK packages.`;
}

function fail(message) {
  console.error(`setup failed: ${message}`);
  process.exit(1);
}

function parseArgs(argv) {
  const options = {
    profile: "web",
    rendererDir: path.join(dshHome, "red-alert", "renderer-v5"),
    rendererPort: undefined,
    packageSpec: undefined,
    downloadResources: false,
    dryRun: false,
  };
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === "--") continue;
    if (arg === "--help" || arg === "-h") return { ...options, help: true };
    if (arg === "--dry-run") {
      options.dryRun = true;
      continue;
    }
    if (arg === "--download-resources") {
      options.downloadResources = true;
      continue;
    }
    if (arg === "--profile") {
      const value = argv[index + 1];
      if (value === undefined) fail("--profile requires a value");
      options.profile = value;
      index += 1;
      continue;
    }
    if (arg === "--renderer-dir") {
      const value = argv[index + 1];
      if (value === undefined) fail("--renderer-dir requires a value");
      options.rendererDir = path.resolve(value);
      index += 1;
      continue;
    }
    if (arg === "--renderer-port") {
      const value = argv[index + 1];
      if (value === undefined || !/^[0-9]+$/.test(value)) fail("--renderer-port requires an integer from 1 through 65535");
      const port = Number(value);
      if (!Number.isSafeInteger(port) || port < 1 || port > 65535) fail("--renderer-port requires an integer from 1 through 65535");
      options.rendererPort = port;
      index += 1;
      continue;
    }
    if (arg === "--package-spec") {
      const value = argv[index + 1];
      if (value === undefined || value.length === 0) fail("--package-spec requires a value");
      options.packageSpec = value;
      index += 1;
      continue;
    }
    fail(`unknown argument ${JSON.stringify(arg)}`);
  }
  return options;
}

function quote(value) {
  if (/^[A-Za-z0-9_./:@+-]+$/.test(value)) return value;
  return `'${value.replaceAll("'", "'\\''")}'`;
}

function commandText(command, args) {
  return [command, ...args].map(quote).join(" ");
}

function run(command, args, options = {}) {
  console.log(`> ${commandText(command, args)}`);
  const result = spawnSync(command, args, {
    cwd: options.cwd ?? root,
    env: options.env ?? process.env,
    encoding: "utf8",
    stdio: options.capture ? ["ignore", "pipe", "pipe"] : "inherit",
  });
  if (result.error !== undefined) {
    if (result.error.code === "ENOENT" && options.missing !== undefined) fail(options.missing);
    fail(`${command} could not start: ${result.error.message}`);
  }
  if (result.status !== 0) {
    if (options.capture && process.env.DSH_RED_ALERT_SETUP_DEBUG === "1") {
      if (result.stdout) process.stdout.write(result.stdout);
      if (result.stderr) process.stderr.write(result.stderr);
    }
    fail(options.failure ?? `${commandText(command, args)} exited with ${result.status}`);
  }
  return result.stdout ?? "";
}

function readReusableRendererPort(profile) {
  if (!existsSync(statePath)) return undefined;
  try {
    const state = JSON.parse(readFileSync(statePath, "utf8"));
    if (state?.schema !== "dsh-red-alert-install-v1" || state.profile !== profile) return undefined;
    return Number.isSafeInteger(state.rendererPort) && state.rendererPort >= 1 && state.rendererPort <= 65535
      ? state.rendererPort
      : undefined;
  } catch {
    return undefined;
  }
}

async function resourceArchiveIsReady(rendererDistDir) {
  const file = path.join(rendererDistDir, resourceArchive.fileName);
  return await fileMatchesArchive(file, resourceArchive);
}

function configureRendererResource(rendererDistDir, ready) {
  const configPath = path.join(rendererDistDir, "config.ini");
  if (!existsSync(configPath)) fail(`renderer build is missing ${configPath}`);
  const current = readFileSync(configPath, "utf8");
  const desiredUrl = ready ? resourceArchive.rendererUrl : resourceArchive.url;
  const linePattern = /^(\s*gameResArchiveUrl\s*=\s*).*$/m;
  if (!linePattern.test(current)) fail("renderer config.ini is missing gameResArchiveUrl");
  const configured = current.replace(linePattern, `$1${desiredUrl}`);
  if (configured !== current) writeFileSync(configPath, configured);
}

async function downloadResourceArchive(rendererDistDir) {
  const target = path.join(rendererDistDir, resourceArchive.fileName);
  if (await resourceArchiveIsReady(rendererDistDir)) {
    console.log(`Reusing verified resource archive at ${target}`);
    configureRendererResource(rendererDistDir, true);
    return;
  }
  console.log("Resource download requested by --download-resources.");
  console.log(`Source: ${resourceArchive.url}`);
  console.log(`Expected bytes: ${resourceArchive.byteLength}`);
  console.log(`Expected SHA-256: ${resourceArchive.sha256}`);
  console.log("Rights notice: this public endpoint is a convenience source, not a grant of rights to EA or third-party game assets.");
  console.log("Continue only if you have the right to obtain and use these resources.");
  const result = await downloadVerifiedArchive(resourceArchive, target);
  if (result.rejectedPath !== undefined) console.warn(`Preserved the previous invalid resource path at ${result.rejectedPath}`);
  configureRendererResource(rendererDistDir, true);
  console.log(`Verified resource archive saved at ${target}`);
}

function rendererIsReady(rendererDir) {
  const rendererDistDir = path.join(rendererDir, "dist");
  const rendererEntry = path.join(rendererDistDir, "index.html");
  const rendererMarkerPath = path.join(rendererDir, ".dsh-red-alert-renderer.json");
  if (!existsSync(rendererEntry)) {
    if (existsSync(rendererDir)) {
      fail(`renderer directory already exists but ${rendererEntry} is missing; choose a new --renderer-dir or remove the incomplete directory yourself`);
    }
    return false;
  }
  let marker;
  try {
    marker = JSON.parse(readFileSync(rendererMarkerPath, "utf8"));
  } catch (error) {
    fail(`renderer exists but its preparation marker is missing or invalid: ${error instanceof Error ? error.message : String(error)}`);
  }
  if (marker?.schema !== rendererMarkerSchema || marker.upstream !== rendererUpstream || marker.commit !== rendererCommit) {
    fail("renderer preparation marker does not match the locked compatible client");
  }
  return true;
}

async function portIsAvailable(port) {
  return new Promise((resolve) => {
    const server = createServer();
    server.unref();
    server.once("error", () => resolve(false));
    server.listen({ host: "127.0.0.1", port, exclusive: true }, () => {
      server.close(() => resolve(true));
    });
  });
}

async function selectRendererPort(explicitPort, reusablePort) {
  if (explicitPort !== undefined) {
    if (!await portIsAvailable(explicitPort)) fail(`renderer port ${explicitPort} is already in use`);
    return explicitPort;
  }
  if (reusablePort !== undefined && await portIsAvailable(reusablePort)) return reusablePort;
  for (let port = 4317; port <= 4367; port += 1) {
    if (await portIsAvailable(port)) return port;
  }
  fail("no free renderer port was found from 4317 through 4367; pass --renderer-port with a free loopback port");
}

function printPlan(profile, rendererDir, rendererPort, packageSpec, reuseRenderer, downloadResources) {
  const rendererDistDir = path.join(rendererDir, "dist");
  const mountSpec = packageSpec ?? (sourceCheckout ? `file:${root}` : `${packageName}@${packageVersion}`);
  const commands = [
    ["pnpm", ["--version"]],
    ["dsh", ["--version"]],
    ["dsh", ["--profile", profile, "--dump-default-config"]],
    ...(sourceCheckout ? [
      ["pnpm", ["install", "--frozen-lockfile"]],
      ["pnpm", ["run", "build"]],
    ] : []),
    ...(reuseRenderer ? [] : [
      ["git", ["--version"]],
      ["pnpm", ["dlx", "bun@1.3.14", "--version"]],
      [process.execPath, [path.join(root, "scripts", "prepare-compatible-renderer.mjs"), rendererDir]],
    ]),
    ["dsh", ["plugin", "--profile", profile, "add", "-w", mountSpec, "--save-exact", "--ignore-scripts"]],
    ["dsh", ["--profile", profile, "--dump-config"]],
  ];
  console.log("Dry run. No files or Profile state will be changed.");
  for (const [command, args] of commands) console.log(`> ${commandText(command, args)}`);
  console.log(`Would write ${statePath}`);
  console.log(`Would launch with RA_RENDERER_DIST_DIR=${rendererDistDir}`);
  console.log(`Would launch with RA_RENDERER_PORT=${rendererPort ?? "a stable free port selected from 4317-4367"}`);
  if (downloadResources) {
    console.log(`Would download ${resourceArchive.url}`);
    console.log(`Would require SHA-256 ${resourceArchive.sha256}`);
    console.log(`Would save the verified archive as ${path.join(rendererDistDir, resourceArchive.fileName)}`);
  } else {
    console.log("Would not download game resources; the compatible client's visible local-import fallback remains available.");
  }
}

const options = parseArgs(process.argv.slice(2));
if (options.help) {
  console.log(usage());
  process.exit(0);
}
if (!profilePattern.test(options.profile)) {
  fail("profile must contain only letters, numbers, dot, underscore, or hyphen, and cannot start with punctuation");
}

const rendererDistDir = path.join(options.rendererDir, "dist");
const reusableRendererPort = readReusableRendererPort(options.profile);
const reuseRenderer = rendererIsReady(options.rendererDir);

if (options.dryRun) {
  printPlan(options.profile, options.rendererDir, options.rendererPort ?? reusableRendererPort, options.packageSpec, reuseRenderer, options.downloadResources);
  process.exit(0);
}
const rendererPort = await selectRendererPort(options.rendererPort, reusableRendererPort);

run("pnpm", ["--version"], { missing: "pnpm is required. Install pnpm, reopen the terminal, and rerun the same setup command." });
const dshVersion = run("dsh", ["--version"], {
  capture: true,
  missing: `The dsh command is unavailable. Install @deepseek-ai/dsh@${requiredDshVersion} in this directory, then rerun setup.`,
}).trim();
if (dshVersion !== requiredDshVersion) {
  fail(`this release requires dsh ${requiredDshVersion}, but the active command reports ${JSON.stringify(dshVersion)}`);
}
run("dsh", ["--profile", options.profile, "--dump-default-config"], {
  capture: true,
  failure: `DSH Profile ${JSON.stringify(options.profile)} is unavailable. Create a working DSH Web Profile first.`,
});
if (sourceCheckout) {
  run("pnpm", ["install", "--frozen-lockfile"], {
    failure: "dependency installation failed. A 404 for @deepseek-ai means this npm account cannot access the required official DSH SDK package.",
  });
  run("pnpm", ["run", "build"]);
} else if (!existsSync(path.join(root, "lib", "index.js")) || !existsSync(path.join(root, "lib", "client.cjs"))) {
  fail("the installed package is missing its built Host or browser entry");
}

if (reuseRenderer) {
  console.log(`Reusing compatible client at ${rendererDistDir}`);
} else {
  run("git", ["--version"], {
    missing: "Git is required only for the first renderer preparation. Install Git, reopen the terminal, and rerun the same setup command.",
  });
  run(process.execPath, [path.join(root, "scripts", "prepare-compatible-renderer.mjs"), options.rendererDir]);
}

let resourcesReady = false;
try {
  resourcesReady = await resourceArchiveIsReady(rendererDistDir);
  if (options.downloadResources) {
    await downloadResourceArchive(rendererDistDir);
    resourcesReady = true;
  }
} catch (error) {
  fail(`resource preparation failed: ${error instanceof Error ? error.message : String(error)}`);
}
configureRendererResource(rendererDistDir, resourcesReady);

const mountSpec = options.packageSpec ?? (sourceCheckout ? `file:${root}` : `${packageName}@${packageVersion}`);
run("dsh", ["plugin", "--profile", options.profile, "add", "-w", mountSpec, "--save-exact", "--ignore-scripts"]);
const verifiedConfig = run("dsh", ["--profile", options.profile, "--dump-config"], {
  capture: true,
  env: { ...process.env, RA_RENDERER_DIST_DIR: rendererDistDir, RA_RENDERER_PORT: String(rendererPort) },
  failure: "the Profile did not load after mounting the plugin",
});
if (!verifiedConfig.includes(packageName)) {
  fail(`the Profile loaded, but its resolved config does not contain ${packageName}`);
}

mkdirSync(path.dirname(statePath), { recursive: true });
writeFileSync(statePath, `${JSON.stringify({
  schema: "dsh-red-alert-install-v1",
  profile: options.profile,
  rendererDistDir,
  rendererPort,
  packageName,
  packageVersion,
  resourceArchive: resourcesReady ? {
    url: resourceArchive.url,
    byteLength: resourceArchive.byteLength,
    sha256: resourceArchive.sha256,
    file: path.join(rendererDistDir, resourceArchive.fileName),
  } : undefined,
}, null, 2)}\n`);

console.log("DSH Red Alert is ready.");
console.log(sourceCheckout ? "Start it with: pnpm run dsh" : "Start it with: pnpm exec dsh-red-alert");
console.log(`The compatible client will reuse loopback port ${rendererPort} so its browser-only game files survive restarts.`);
if (resourcesReady) {
  console.log("The first client launch will import the verified local archive automatically; an in-progress create-match can continue without a file picker.");
} else {
  console.log("Automatic resources are not prepared. Rerun setup with --download-resources, or use the visible local-archive picker in the battlefield panel.");
}
