/** Build launcher arguments while enforcing the no-browser-open boundary. */
export function buildDshLaunchArgs(profile, args) {
  const forwarded = args.filter((arg) => arg !== "--" && arg !== "--open" && arg !== "--no-open");
  return ["--profile", profile, ...forwarded, "--no-open"];
}
