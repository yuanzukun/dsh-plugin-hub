import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { gunzipSync } from "node:zlib";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const commit = "8c07f1092b2a9e8d8605ed49ef46d77b6c3ea367";
const patchPath = path.join(root, "renderer-adapter", "patches", `redalert2-${commit.slice(0, 8)}.patch.gz.base64`);
const patch = gunzipSync(Buffer.from(readFileSync(patchPath, "utf8").trim(), "base64")).toString("utf8");
const resourcePatch = readFileSync(path.join(root, "renderer-adapter", "patches", "redalert2-auto-local-resource.patch"), "utf8");
const viewerControlsPatch = readFileSync(path.join(root, "renderer-adapter", "patches", "redalert2-viewer-controls.patch"), "utf8");
const resourceAdditions = resourcePatch.split("\n")
  .filter((line) => line.startsWith("+") && !line.startsWith("+++"))
  .map((line) => line.slice(1))
  .join("\n");
const prepareScript = readFileSync(path.join(root, "scripts", "prepare-compatible-renderer.mjs"), "utf8");
const setupScript = readFileSync(path.join(root, "scripts", "setup-dsh.mjs"), "utf8");

const expectedPaths = new Set([
  "src/Gui.ts",
  "src/dsh/CurrentLos.ts",
  "src/dsh/FormalRendererCompanion.ts",
  "src/dsh/FormalRendererResource.ts",
  "src/engine/gameRes/GameResImporter.ts",
  "src/engine/gameRes/GameRes.ts",
  "src/gui/component/GameResBoxApi.tsx",
  "src/gui/component/GameResForm.tsx",
  "src/gui/screen/game/GameScreen.ts",
  "src/gui/screen/game/CombatantUi.tsx",
  "src/gui/screen/game/WorldView.ts",
  "src/gui/screen/game/worldInteraction/WorldInteraction.ts",
  "src/gui/screen/mainMenu/MainMenuRootScreen.ts",
  "src/gui/screen/mainMenu/lobby/SkirmishScreen.ts",
  "src/main.tsx",
  "tests/formal-renderer-companion.test.ts",
]);
const actualPaths = new Set([
  ...[...patch.matchAll(/^diff --git a\/(.+?) b\/(.+)$/gm)].map((match) => {
    if (match[1] !== match[2]) throw new Error(`renderer patch renames a path: ${match[1]} -> ${match[2]}`);
    return match[1];
  }),
  ...[...resourcePatch.matchAll(/^\+\+\+ b\/(.+)$/gm)].map((match) => match[1]),
  ...[...viewerControlsPatch.matchAll(/^\+\+\+ b\/(.+)$/gm)].map((match) => match[1]),
]);

if (actualPaths.size !== expectedPaths.size || [...actualPaths].some((entry) => !expectedPaths.has(entry))) {
  throw new Error(`renderer patch path set changed: ${[...actualPaths].sort().join(", ")}`);
}
if (patch.includes("GIT binary patch") || resourcePatch.includes("GIT binary patch") || viewerControlsPatch.includes("GIT binary patch") || [...actualPaths].some((entry) => /^(?:assets|dist|public|vendor)\//.test(entry))) {
  throw new Error("renderer adapter must not contain built output, vendored source, game assets, or binary patches");
}
if (!patch.includes("SPDX-License-Identifier: GPL-3.0-only") || !resourcePatch.includes("SPDX-License-Identifier: GPL-3.0-only")) {
  throw new Error("renderer companion source must carry its GPL-3.0-only identifier");
}
if (!resourceAdditions.includes("formalResourceMiB(downloadedBytes)")
  || resourceAdditions.includes("formatBytes(downloadedBytes)")) {
  throw new Error("renderer resource progress must pass numeric MiB values to sprintf templates");
}
if (!viewerControlsPatch.includes("isFormalRendererViewer")
  || !viewerControlsPatch.includes("event.isTouch || this.viewerOnly")
  || !viewerControlsPatch.includes("this.minimapHandler.panToTile(tile)")
  || !viewerControlsPatch.includes("!this.viewerOnly && !this.currentMode")
  || !viewerControlsPatch.includes("private readonly viewerOnly = isFormalRendererViewer()")
  || !viewerControlsPatch.includes("private pushAction(actionType: ActionType")
  || !viewerControlsPatch.includes("if (this.viewerOnly)")) {
  throw new Error("renderer viewer controls must provide camera-only drag and minimap navigation");
}
if (!prepareScript.includes(`const COMMIT = ${JSON.stringify(commit)}`)
  || !prepareScript.includes('const UPSTREAM = "https://github.com/huangkaoya/redalert2.git"')) {
  throw new Error("renderer preparation script must pin the reviewed upstream and commit");
}
if (!prepareScript.includes('const MARKER_SCHEMA = "dsh-red-alert-renderer-v5"')
  || !prepareScript.includes('path.join(destination, ".dsh-red-alert-renderer.json")')
  || !prepareScript.includes('redalert2-viewer-controls.patch')
  || !setupScript.includes(`const rendererCommit = ${JSON.stringify(commit)}`)
  || !setupScript.includes('const rendererMarkerSchema = "dsh-red-alert-renderer-v5"')) {
  throw new Error("renderer preparation and setup scripts must share the locked renderer marker contract");
}
if (/\.dsh\/source|test-zhu1090093659|RA_ASSETS_DIR/.test(prepareScript)) {
  throw new Error("renderer preparation script must not depend on or modify a DSH checkout or server-side asset directory");
}

console.log(`renderer adapter gate passed (${actualPaths.size} source paths, ${Buffer.byteLength(patch) + Buffer.byteLength(resourcePatch) + Buffer.byteLength(viewerControlsPatch)} patch bytes, commit ${commit})`);
