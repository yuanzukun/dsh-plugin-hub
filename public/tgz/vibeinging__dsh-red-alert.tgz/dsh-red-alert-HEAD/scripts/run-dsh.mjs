#!/usr/bin/env node

import { existsSync, readFileSync } from "node:fs";
import { homedir } from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath, pathToFileURL } from "node:url";
import { buildDshLaunchArgs } from "./run-dsh-args.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const sourceCheckout = existsSync(path.join(root, "src", "index.ts")) && existsSync(path.join(root, "pnpm-lock.yaml"));
const dshHome = path.resolve(process.env.DSH_HOME ?? path.join(homedir(), ".dsh"));
const statePath = path.join(dshHome, "red-alert", "install.json");
const profilePattern = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;

function fail(message) {
  console.error(`launch failed: ${message}`);
  console.error(sourceCheckout
    ? "Run pnpm run setup -- --profile <name> first."
    : "Run pnpm exec dsh-red-alert-setup --profile <name> first.");
  process.exit(1);
}

if (!existsSync(statePath)) fail(`${statePath} does not exist`);

let state;
try {
  state = JSON.parse(readFileSync(statePath, "utf8"));
} catch (error) {
  fail(`${statePath} is not valid JSON: ${error instanceof Error ? error.message : String(error)}`);
}

if (state?.schema !== "dsh-red-alert-install-v1") fail("install state has an unsupported schema");
if (typeof state.profile !== "string" || !profilePattern.test(state.profile)) fail("install state has an invalid Profile name");
if (typeof state.rendererDistDir !== "string" || !path.isAbsolute(state.rendererDistDir)) fail("install state has an invalid renderer path");
if (!existsSync(path.join(state.rendererDistDir, "index.html"))) fail("the prepared renderer is missing dist/index.html");
if (!Number.isSafeInteger(state.rendererPort) || state.rendererPort < 1 || state.rendererPort > 65535) {
  fail("install state has no stable renderer port; rerun dsh-red-alert-setup");
}
const preparedResourceFile = typeof state.resourceArchive?.file === "string" && path.isAbsolute(state.resourceArchive.file)
  ? state.resourceArchive.file
  : undefined;
if (preparedResourceFile === undefined || !existsSync(preparedResourceFile)) {
  console.warn("Red Alert resources are not prepared for automatic first use.");
  console.warn("Declared source: https://download.ra2web.com/full-pack.7z");
  console.warn(sourceCheckout
    ? "Before creating the first match, stop DSH and run: pnpm run setup -- --profile <name> --download-resources"
    : "Before creating the first match, stop DSH and run: pnpm exec dsh-red-alert-setup --profile <name> --download-resources");
  console.warn("The command prints and verifies the exact size and SHA-256 before the compatible client imports the archive. The visible local-file picker remains available as a fallback.");
}

const launchArgs = buildDshLaunchArgs(state.profile, process.argv.slice(2));
const profileDir = path.join(dshHome, "profiles", state.profile);
const preloadPath = path.join(root, "scripts", "session-vocabulary-loader.mjs");
const preloadOption = `--import=${pathToFileURL(preloadPath).href}`;
const nodeOptions = [process.env.NODE_OPTIONS, preloadOption].filter((value) => typeof value === "string" && value.length > 0).join(" ");
const childEnv = {
  ...process.env,
  NODE_OPTIONS: nodeOptions,
  RA_DSH_PROFILE_DIR: profileDir,
  RA_RENDERER_DIST_DIR: state.rendererDistDir,
  RA_RENDERER_PORT: String(state.rendererPort),
};
const result = spawnSync("dsh", launchArgs, {
  cwd: root,
  env: childEnv,
  stdio: "inherit",
});
if (result.error !== undefined) fail(`dsh could not start: ${result.error.message}`);
if (result.signal !== null) {
  console.error(`dsh stopped by signal ${result.signal}`);
  process.exit(1);
}
process.exit(result.status ?? 1);
