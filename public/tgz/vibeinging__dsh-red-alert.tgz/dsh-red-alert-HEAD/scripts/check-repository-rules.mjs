import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const packagePath = path.join(root, "package.json");
const packageJson = JSON.parse(readFileSync(packagePath, "utf8"));
const errors = [];

function fail(message) {
  errors.push(message);
}

function read(relativePath) {
  return readFileSync(path.join(root, relativePath), "utf8");
}

function walk(relativePath) {
  const absolutePath = path.join(root, relativePath);
  const stat = statSync(absolutePath);
  if (stat.isFile()) return [relativePath];
  const result = [];
  for (const entry of readdirSync(absolutePath, { withFileTypes: true })) {
    const child = path.join(relativePath, entry.name);
    if (entry.isDirectory() && [".git", ".runtime", "node_modules", "vendor", "assets", "artifacts"].includes(entry.name)) continue;
    if (entry.isSymbolicLink()) continue;
    result.push(...walk(child));
  }
  return result;
}

function assertEqual(actual, expected, label) {
  if (actual !== expected) fail(`${label}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
}

assertEqual(packageJson.name, "@vibeinging/dsh-red-alert", "package name");
assertEqual(packageJson.private, false, "package private flag");
assertEqual(packageJson.license, "GPL-3.0-only", "package license");
assertEqual(packageJson.publishConfig?.access, "public", "package publish access");
assertEqual(packageJson.publishConfig?.registry, "https://registry.npmjs.org/", "package publish registry");
assertEqual(packageJson.version, "0.1.3", "package release version");
assertEqual(packageJson.bin?.["dsh-red-alert"], "scripts/run-dsh.mjs", "launch bin");
assertEqual(packageJson.bin?.["dsh-red-alert-prepare-renderer"], "scripts/prepare-compatible-renderer.mjs", "renderer preparation bin");
assertEqual(packageJson.bin?.["dsh-red-alert-setup"], "scripts/setup-dsh.mjs", "setup bin");
if (!read("LICENSE").startsWith("                    GNU GENERAL PUBLIC LICENSE\n                       Version 3, 29 June 2007\n")) {
  fail("LICENSE must contain the canonical GNU GPL version 3 text");
}
if (packageJson.engines?.node === undefined) fail("package must declare a Node engine");
if (typeof packageJson.packageManager !== "string" || !packageJson.packageManager.startsWith("pnpm@")) fail("package must declare a pnpm packageManager");
assertEqual(packageJson.dsh?.bundle?.patch, "./cordis.patch.yml", "dsh.bundle.patch");
assertEqual(packageJson.dsh?.client?.platform, "web", "dsh.client.platform");
if (!read("cordis.patch.yml").includes("rendererPort: !!js 'process.env.RA_RENDERER_PORT ? Number(process.env.RA_RENDERER_PORT) : undefined'")) {
  fail("cordis.patch.yml must decode the stable renderer port as a number");
}
if (!read("scripts/run-dsh.mjs").includes("RA_DSH_PROFILE_DIR: profileDir")) {
  fail("run-dsh.mjs must bind SDK resolution to the mounted DSH Profile");
}
if (!read("scripts/run-dsh.mjs").includes("NODE_OPTIONS: nodeOptions")) {
  fail("run-dsh.mjs must register external event vocabulary before DSH persistence loads");
}
if (!read("scripts/run-dsh.mjs").includes("buildDshLaunchArgs(state.profile, process.argv.slice(2))")
  || !read("scripts/run-dsh-args.mjs").includes('["--profile", profile, ...forwarded, "--no-open"]')) {
  fail("the Red Alert launcher must always disable automatic browser opening");
}
if (!Array.isArray(packageJson.dsh?.client?.inject) || packageJson.dsh.client.inject.length === 0) {
  fail("dsh.client.inject must declare the latest DSH browser package dependencies");
}
if (packageJson.dshClient !== undefined) fail("legacy top-level dshClient is not loaded by the latest DSH release");
const exported = packageJson.exports ?? {};
if (!exported["."] || !exported["./invariant"] || !exported["./client"] || exported["./package.json"] !== "./package.json" || exported["./cordis.patch.yml"] !== "./cordis.patch.yml") {
  fail("exports must contain the public entry, invariant, client, package.json, and patch paths");
}
if (JSON.stringify(exported).match(/(?:["']\.\.?\/)src\/|packages\/game-host|vendor|node_modules/)) {
  fail("exports must not point at source, vendor, or node_modules paths");
}
const files = packageJson.files ?? [];
if (!files.includes("lib/*.js") || !files.includes("lib/*.cjs") || !files.includes("lib/types/**/*.d.ts") || !files.includes("lib/types/src/session-event-types.js") || !files.includes("package.json") || !files.includes("cordis.patch.yml")) {
  fail("files must include the package manifest, built JavaScript, client CJS, declarations, and cordis patch");
}
if (!files.includes("README.en.md")) fail("files must include the English README");
if (!files.includes("LICENSE") || !files.includes("docs/readme-media/*.webp") || !files.includes("docs/reports/*.md")) {
  fail("files must include the license, README media, and linked reports");
}
if (!files.includes("scripts/setup-dsh.mjs") || !files.includes("scripts/run-dsh.mjs") || !files.includes("scripts/run-dsh-args.mjs") || !files.includes("scripts/session-vocabulary-loader.mjs")) {
  fail("files must include the setup and launch commands");
}
assertEqual(packageJson.scripts?.setup, "node scripts/setup-dsh.mjs", "setup script");
assertEqual(packageJson.scripts?.dsh, "node scripts/run-dsh.mjs", "dsh launch script");
for (const scriptName of Object.keys(packageJson.scripts ?? {})) {
  if (/^(?:pre|post)?(?:publish|prepare|pack)$/i.test(scriptName)) fail(`forbidden package lifecycle script: ${scriptName}`);
}

const dependencySections = ["dependencies", "devDependencies", "peerDependencies", "optionalDependencies"];
for (const section of dependencySections) {
  for (const [name, spec] of Object.entries(packageJson[section] ?? {})) {
    if (typeof spec === "string" && /^(?:file|link|workspace):/.test(spec)) {
      fail(`${section}.${name} uses a local protocol: ${spec}`);
    }
  }
}
assertEqual(JSON.stringify(packageJson.peerDependencies), JSON.stringify({ "@deepseek-ai/dsh": "0.1.1-rc.2" }), "latest-only DSH peer contract");
assertEqual(packageJson.devDependencies?.["@deepseek-ai/dsh"], "0.1.1-rc.2", "development DSH version");
if (packageJson.peerDependenciesMeta !== undefined) fail("the required latest DSH peer must not be optional");
for (const [name, spec] of Object.entries(packageJson.devDependencies ?? {})) {
  if (name.startsWith("@deepseek-ai/dsh-") && spec !== "0.1.1-rc.2") {
    fail(`${name} must match the latest DSH SDK family`);
  }
}

assertEqual(read(".npmrc").trim(), "@deepseek-ai:registry=https://registry.npmjs.org/", ".npmrc");
const ignoredPaths = new Set(read(".gitignore").split(/\r?\n/).filter(Boolean));
for (const requiredPath of ["assets/", "artifacts/", "vendor/", ".runtime/"]) {
  if (!ignoredPaths.has(requiredPath)) fail(`.gitignore must exclude ${requiredPath}`);
}
const readme = read("README.md");
const englishReadme = read("README.en.md");
for (const screenshot of [
  "docs/readme-media/real-ai-battlefield.webp",
  "docs/readme-media/live-command.webp",
  "docs/readme-media/post-match-learning.webp",
]) {
  const publicUrl = `https://raw.githubusercontent.com/vibeinging/dsh-red-alert/main/${screenshot}`;
  if (!readme.includes(`](${publicUrl})`)) fail(`README.md must embed public ${screenshot}`);
  if (!englishReadme.includes(`](${publicUrl})`)) fail(`README.en.md must embed public ${screenshot}`);
  if (!existsSync(path.join(root, screenshot))) fail(`${screenshot} is missing`);
}
if (!readme.includes("pnpm run setup -- --profile web") || !readme.includes("pnpm run dsh")) {
  fail("README.md must document the setup and launch commands");
}
if (!readme.includes("[English](README.en.md)") || !englishReadme.includes("[简体中文](README.md)")) {
  fail("README language links must be reciprocal");
}
if (!englishReadme.includes("pnpm run setup -- --profile web") || !englishReadme.includes("pnpm run dsh")) {
  fail("README.en.md must document the setup and launch commands");
}
if (readme.includes("不是 Codex 插件")) fail("README.md must describe the DSH plugin positively");
if (!readme.includes("@vibeinging/dsh-red-alert@0.1.3") || !englishReadme.includes("@vibeinging/dsh-red-alert@0.1.3")) {
  fail("both READMEs must document the exact public NPM package");
}
if (!readme.includes("@deepseek-ai/dsh@0.1.1-rc.2") || !englishReadme.includes("@deepseek-ai/dsh@0.1.1-rc.2")) {
  fail("both READMEs must document the latest-only DSH contract");
}
if (!read("scripts/setup-dsh.mjs").includes('const requiredDshVersion = "0.1.1-rc.2";')) {
  fail("setup must reject DSH versions outside the published compatibility target");
}
const setupScript = read("scripts/setup-dsh.mjs");
const resourceDownloadScript = read("scripts/resource-download.mjs");
for (const required of [
  "--download-resources",
  "https://download.ra2web.com/full-pack.7z",
  "140_316_786",
  "3119b300794839ab597df556df8718c0a0a28fe89648ddced1c3790d801cb646",
  "renderer-v5",
]) {
  if (!setupScript.includes(required)) fail(`setup resource contract is missing ${required}`);
}
if (!resourceDownloadScript.includes('createWriteStream(temporary, { flags: "wx" })')
  || !resourceDownloadScript.includes("resource content-length mismatch")
  || !resourceDownloadScript.includes("resource SHA-256 mismatch")) {
  fail("setup resource download must stream into an exclusive temporary file and fail closed on size and digest changes");
}
for (const content of [readme, englishReadme]) {
  if (!content.includes("--download-resources")
    || !content.includes("](https://download.ra2web.com/full-pack.7z)")
    || !content.includes("3119b300794839ab597df556df8718c0a0a28fe89648ddced1c3790d801cb646")) {
    fail("both READMEs must document the explicit resource command, linked source, and pinned digest");
  }
}
const patch = read("cordis.patch.yml");
if (/RA_ASSETS_DIR|assetsDir:/.test(patch)) fail("cordis.patch.yml must not expose the legacy headless asset directory");
if (!read("scripts/prepare-compatible-renderer.mjs").includes('["dlx", BUN_PACKAGE')) {
  fail("renderer preparation must use the exact pnpm dlx Bun tool instead of requiring a global Bun install");
}
const patchNames = [...patch.matchAll(/name:\s*['"]?([^\s'"]+)/g)].map((match) => match[1]);
if (patchNames.length !== 3 || patchNames.some((name) => !["@deepseek-ai/dsh-invariants", "@vibeinging/dsh-red-alert", "@vibeinging/dsh-red-alert/invariant"].includes(name))) {
  fail("cordis.patch.yml may insert only the official invariant service and red-alert entries; DSH Web supplies session-projection");
}

const pluginFiles = ["src", "tests", "package.json", "tsconfig.json", "tsdown.config.ts", "cordis.patch.yml"]
  .flatMap((relativePath) => walk(relativePath));
const productFiles = ["src", "packages/game-host/src/snapshot.ts", "packages/game-host/src/fog-safe-observation.ts", "packages/game-host/web/index.html", "README.md", "README.en.md", "docs/snapshot-schema-v1.md"]
  .flatMap((relativePath) => walk(relativePath));
const productObservationFiles = ["src", "packages/game-host/src/snapshot.ts", "packages/game-host/src/fog-safe-observation.ts", "packages/game-host/web/index.html", "README.md", "README.en.md"]
  .flatMap((relativePath) => walk(relativePath))
  .filter((relativePath) => relativePath !== "src/tool-policy.ts");
const sourceCheckoutRefs = /test-zhu1090093659|dsh-agent-budget\/node_modules|dsh-tool-search\/node_modules|\.dsh\/source\/current|(?:^|[/])vendor[/]/;
for (const relativePath of pluginFiles) {
  const content = read(relativePath);
  if (sourceCheckoutRefs.test(content)) fail(`${relativePath} references a DSH source checkout or sample node_modules`);
  if (relativePath === "package.json" && /(?:^|[\s"'])(?:file|link|workspace):/.test(content)) fail("package.json contains a local dependency protocol");
}

const declaredPackages = new Set([packageJson.name, ...dependencySections.flatMap((section) => Object.keys(packageJson[section] ?? {}))]);
const importPattern = /(?:from\s*|import\s*\(|import\s+type\s+)["'](@deepseek-ai\/[^"']+)["']/g;
for (const relativePath of ["src", "tests"].flatMap((relativePath) => walk(relativePath))) {
  const content = read(relativePath);
  for (const match of content.matchAll(importPattern)) {
    const specifier = match[1];
    const packageName = specifier.split("/").slice(0, 2).join("/");
    if (packageName !== packageJson.name && !declaredPackages.has(packageName)) {
      fail(`${relativePath} imports undeclared DSH package ${specifier}`);
    }
  }
}

const emojiPattern = /(?:\p{Emoji_Presentation}|\p{Extended_Pictographic}|\uFE0F|\u200D|[\u{1F1E6}-\u{1F1FF}])/u;
const textExtensions = new Set([".css", ".html", ".js", ".json", ".md", ".mjs", ".ts", ".txt", ".yml", ".yaml"]);
for (const relativePath of walk(".")) {
  if (!textExtensions.has(path.extname(relativePath)) && path.basename(relativePath) !== ".npmrc") continue;
  if (emojiPattern.test(read(relativePath))) fail(`${relativePath} contains an emoji character`);
}

for (const relativePath of productFiles) {
  const content = read(relativePath);
  if (/enemyStartLocation|敌基地方向/.test(content)) fail(`${relativePath} contains hidden enemy start information`);
}
for (const relativePath of productObservationFiles) {
  if (/getNeutralUnits\s*\(/.test(read(relativePath))) fail(`${relativePath} uses the forbidden full neutral-unit API`);
}

const rootSource = ["src"].flatMap((relativePath) => walk(relativePath)).map((relativePath) => read(relativePath)).join("\n");
if (/DshCommander|execFile/.test(rootSource)) fail("the external plugin source must not launch the legacy DSH commander");
const clientSource = read("src/client/index.tsx");
const clientInject = clientSource.match(/export const inject\s*=\s*\[([\s\S]*?)\]/);
if (clientInject === null || /@deepseek-ai\//.test(clientInject[1])) {
  fail("src/client runtime inject must contain Cordis service names, not @deepseek-ai package names");
}
if (clientInject !== null && !/['"]slots['"]/.test(clientInject[1])) {
  fail("src/client runtime inject must require the slots service");
}
if (clientInject !== null && !/['"]layout['"]/.test(clientInject[1])) {
  fail("src/client runtime inject must require the official layout service");
}
if (!/from\s+["']@deepseek-ai\/dsh-client-ui-layout\/client["']/.test(clientSource)
  || !/slots\.inject\(["']conversation\.session\.header\.actions["']/.test(clientSource)
  || !/id:\s*["']red-alert-battlefield["']/.test(clientSource)
  || !/layout\.openDetails\(\)/.test(clientSource)
  || !/layout\.closeDetails\(\)/.test(clientSource)
  || !/aria-label=["']红警 2 右侧战场["']/.test(clientSource)
  || /views\.register\(["']red-alert["']/.test(clientSource)
  || /actions\.setView\(["']red-alert["']\)/.test(clientSource)) {
  fail("red-alert UI must use the official right-side layout beside canonical Chat without registering a parallel conversation view");
}

if (errors.length > 0) {
  console.error(errors.map((error) => `rule failure: ${error}`).join("\n"));
  process.exitCode = 1;
} else {
  console.log(`repository rules passed (${pluginFiles.length} plugin files, ${productFiles.length} product files)`);
}
