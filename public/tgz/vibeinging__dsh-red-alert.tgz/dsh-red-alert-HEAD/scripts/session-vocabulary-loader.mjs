import { existsSync, realpathSync } from "node:fs";
import { createRequire } from "node:module";
import path from "node:path";
import { pathToFileURL } from "node:url";

import { RED_ALERT_SESSION_EVENT_TYPES } from "../lib/types/src/session-event-types.js";

// DSH 0.1.1-rc.2 has no downstream event-vocabulary registration service.
// Register before the CLI imports persistence so historical plugin sessions
// remain readable after a process restart.
const profileDir = process.env.RA_DSH_PROFILE_DIR;
const profilePluginEntry = profileDir === undefined
  ? undefined
  : path.join(profileDir, "node_modules", "@vibeinging", "dsh-red-alert", "lib", "index.js");
if (profilePluginEntry === undefined || !existsSync(profilePluginEntry)) {
  throw new Error("red-alert cannot resolve its physical DSH Profile installation");
}
const candidateRequires = [createRequire(import.meta.url), createRequire(realpathSync(profilePluginEntry))];
const sessionEntries = new Set();
for (const candidateRequire of candidateRequires) {
  const dshPackagePath = candidateRequire.resolve("@deepseek-ai/dsh/package.json");
  const hostRequire = createRequire(dshPackagePath);
  sessionEntries.add(realpathSync(hostRequire.resolve("@deepseek-ai/dsh-session")));
}
for (const sessionEntry of sessionEntries) {
  const hostSession = await import(pathToFileURL(sessionEntry).href);
  const known = hostSession.KNOWN_SESSION_EVENT_TYPES;
  const add = known?.add;
  if (known === undefined || typeof add !== "function") {
    throw new Error("red-alert requires the DSH 0.1.1-rc.2 session vocabulary contract");
  }
  for (const type of RED_ALERT_SESSION_EVENT_TYPES) add.call(known, type);
  for (const type of RED_ALERT_SESSION_EVENT_TYPES) {
    if (!known.has(type)) throw new Error(`red-alert could not register session event type: ${type}`);
  }
}
