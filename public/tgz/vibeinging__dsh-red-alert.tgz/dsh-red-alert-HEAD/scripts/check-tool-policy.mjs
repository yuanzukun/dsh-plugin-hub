import { readFileSync } from "node:fs";
import path from "node:path";
import ts from "typescript";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const packageDir = path.join(root, "node_modules", "@chronodivide", "game-api");
const packageJson = JSON.parse(readFileSync(path.join(packageDir, "package.json"), "utf8"));
const declarationPath = path.join(packageDir, "dist", "index.d.ts");
const declaration = readFileSync(declarationPath, "utf8");
const source = ts.createSourceFile(declarationPath, declaration, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
const policySourcePath = path.join(root, "src", "tool-policy.ts");
const policySource = readFileSync(policySourcePath, "utf8");
const policyModule = await import(`data:text/javascript;base64,${Buffer.from(ts.transpileModule(policySource, {
  compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022 },
}).outputText).toString("base64")}`);

const owners = new Set([
  "PublicApi",
  "GameInstanceApi",
  "GameApi",
  "MapApi",
  "PlayerApi",
  "ProductionApi",
  "ActionsApi",
]);
const errors = [];
const fail = message => errors.push(message);

if (packageJson.version !== "0.75.0") fail(`game-api compatibility gate requires 0.75.0, got ${packageJson.version}`);

function memberName(member) {
  if (member.name === undefined || ts.isPrivateIdentifier(member.name)) return undefined;
  return member.name.getText(source);
}

function isPublic(member) {
  const flags = ts.getCombinedModifierFlags(member);
  return (flags & (ts.ModifierFlags.Private | ts.ModifierFlags.Protected)) === 0;
}

const actual = [];
for (const statement of source.statements) {
  if (!ts.isClassDeclaration(statement) || statement.name === undefined || !owners.has(statement.name.text)) continue;
  const occurrences = new Map();
  for (const member of statement.members) {
    if (ts.isConstructorDeclaration(member) || !isPublic(member)) continue;
    const name = memberName(member);
    if (name === undefined) continue;
    const overload = occurrences.get(name) ?? 0;
    occurrences.set(name, overload + 1);
    actual.push(`${statement.name.text}::${name}::${overload}`);
  }
}

const policy = policyModule.METHOD_POLICY;
const manifest = policyModule.TOOL_MANIFEST;
const policyKeys = policy.map(entry => entry.methodKey);
const actualSet = new Set(actual);
const policySet = new Set(policyKeys);
if (policyKeys.length !== policySet.size) fail("METHOD_POLICY contains duplicate method keys");
for (const key of actualSet) if (!policySet.has(key)) fail(`public SDK method is unclassified: ${key}`);
for (const key of policySet) if (!actualSet.has(key)) fail(`METHOD_POLICY contains a method absent from locked SDK surface: ${key}`);
if (actual.length !== policyKeys.length) fail(`SDK surface count mismatch: declarations=${actual.length}, policy=${policyKeys.length}`);

const manifestByTool = new Map();
for (const entry of manifest) {
  if (manifestByTool.has(entry.tool)) fail(`TOOL_MANIFEST repeats ${entry.tool}`);
  manifestByTool.set(entry.tool, entry);
  if (entry.schemaId.length === 0 || entry.testId.length === 0) fail(`TOOL_MANIFEST entry ${entry.tool} lacks schema/test identity`);
}
for (const entry of policy) {
  if (!owners.has(entry.owner)) fail(`unknown METHOD_POLICY owner ${entry.owner}`);
  if (entry.decision === "deny" || entry.decision === "internal-only") {
    if (entry.tool !== undefined || entry.group !== "internal" || entry.phase !== "never") {
      fail(`forbidden method ${entry.methodKey} must not have a tool, group, or phase`);
    }
    continue;
  }
  if (entry.tool === undefined || entry.group === "internal" || entry.phase === "never") {
    fail(`allowed method ${entry.methodKey} is missing tool/group/phase`);
    continue;
  }
  const tool = manifestByTool.get(entry.tool);
  if (tool === undefined) {
    fail(`allowed method ${entry.methodKey} points at missing tool ${entry.tool}`);
    continue;
  }
  if (!tool.methodKeys.includes(entry.methodKey)) fail(`tool ${entry.tool} omits allowed method ${entry.methodKey}`);
}
for (const entry of manifest) {
  for (const key of entry.methodKeys) {
    const policyEntry = policy.find(candidate => candidate.methodKey === key);
    if (policyEntry === undefined) fail(`tool ${entry.tool} references unknown method ${key}`);
    else if (policyEntry.decision !== "allow-wrapper" || policyEntry.tool !== entry.tool) {
      fail(`tool ${entry.tool} references forbidden or differently-owned method ${key}`);
    }
  }
  if (entry.implemented && !policyModule.IMPLEMENTED_TOOL_NAMES.includes(entry.tool)
    && entry.group !== "bootstrap/capability") {
    fail(`implemented tool ${entry.tool} is absent from implementation inventory`);
  }
}
if (manifestByTool.has("red_alert_act")) fail("legacy red_alert_act must be absent after exact wrapper split");
for (const entry of manifest) if (entry.legacyCrossGroup === true) fail(`${entry.tool} must not cross lazy groups`);
const unitOrder = manifestByTool.get("red_alert_unit_order");
if (unitOrder === undefined || unitOrder.group !== "units/combat") fail("red_alert_unit_order must belong only to units/combat");
const forbiddenUnitOrderMethods = new Set([
  "ActionsApi::queueForProduction::0",
  "ActionsApi::unqueueFromProduction::0",
  "GameApi::canPlaceBuilding::0",
  "ActionsApi::placeBuilding::0",
]);
for (const key of unitOrder?.methodKeys ?? []) if (forbiddenUnitOrderMethods.has(key)) fail(`red_alert_unit_order crosses into another group through ${key}`);

if (errors.length > 0) {
  console.error(errors.map(error => `tool-policy failure: ${error}`).join("\n"));
  process.exitCode = 1;
} else {
  console.log(`tool-policy passed (game-api ${packageJson.version}, ${actual.length} public declarations, ${manifest.length} manifest entries)`);
}
