export interface VerifiedArchiveDescriptor {
  readonly url: string;
  readonly byteLength: number;
  readonly sha256: string;
}

export interface VerifiedArchiveResult {
  readonly reused: boolean;
  readonly rejectedPath?: string;
}

export interface VerifiedArchiveDownloadOptions {
  readonly fetchImpl?: typeof fetch;
}

export function fileMatchesArchive(file: string, descriptor: VerifiedArchiveDescriptor): Promise<boolean>;

export function downloadVerifiedArchive(
  descriptor: VerifiedArchiveDescriptor,
  target: string,
  options?: VerifiedArchiveDownloadOptions,
): Promise<VerifiedArchiveResult>;
