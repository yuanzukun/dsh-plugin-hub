import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const repositoryRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const packageRoot = path.resolve(
  process.env.CHRONO_GAME_API_ROOT ?? path.join(repositoryRoot, "node_modules/@chronodivide/game-api"),
);
const packageJson = JSON.parse(readFileSync(path.join(packageRoot, "package.json"), "utf8"));
const declarations = readFileSync(path.join(packageRoot, "dist/index.d.ts"), "utf8");
const agentDeclaration = declarations.match(/export declare interface Agent\s*\{([\s\S]*?)\n\}/)?.[1] ?? "";
const onlineDeclaration = declarations.match(
  /export declare interface CreateOnlineOpts[\s\S]*?\n\}/,
)?.[0] ?? "";

const contract = {
  packageName: packageJson.name,
  packageVersion: packageJson.version,
  declarationPath: path.join(packageRoot, "dist/index.d.ts"),
  agentIsDataOnly:
    /\bname:\s*string;/.test(agentDeclaration) &&
    /\bcountry\?:\s*string;/.test(agentDeclaration) &&
    !/\([^)]*\):/.test(agentDeclaration),
  onlineAgentsHaveSingleBotHead: /agents:\s*\[Bot,\s*\.\.\.Agent\[\]\];/.test(onlineDeclaration),
  onlineDocsLimitToOneAi: /there can be only one AI agent/i.test(declarations),
  observerCountryOmission: /Omit for observers/i.test(agentDeclaration),
  joinUrlCallback: /onGameCreate\?\(joinUrls:\s*Map<Agent,\s*string>\)/.test(onlineDeclaration),
  credentialShape: /xwolApiUrl:\s*string;[\s\S]*?apiKey:\s*string;/.test(onlineDeclaration)
    ? "xwol-api-key"
    : /serverUrl:\s*string;[\s\S]*?botPassword:\s*string;/.test(onlineDeclaration)
      ? "legacy-server-bot-password"
      : "unknown",
  supportsTwoProgrammaticBots: false,
};

const failures = [
  ["packageName", contract.packageName === "@chronodivide/game-api"],
  ["packageVersion", typeof contract.packageVersion === "string" && contract.packageVersion.length > 0],
  ["agentIsDataOnly", contract.agentIsDataOnly],
  ["onlineAgentsHaveSingleBotHead", contract.onlineAgentsHaveSingleBotHead],
  ["onlineDocsLimitToOneAi", contract.onlineDocsLimitToOneAi],
  ["observerCountryOmission", contract.observerCountryOmission],
  ["joinUrlCallback", contract.joinUrlCallback],
  ["credentialShape", contract.credentialShape !== "unknown"],
].filter(([, passed]) => !passed)
  .map(([name]) => name);

const result = {
  schema: "chrono-online-contract-v1",
  packageRoot,
  contract,
  ok: failures.length === 0,
  failures,
};

console.log(JSON.stringify(result, null, 2));
if (failures.length > 0) process.exitCode = 1;
