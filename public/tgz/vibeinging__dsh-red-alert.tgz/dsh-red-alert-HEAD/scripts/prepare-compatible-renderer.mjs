#!/usr/bin/env node

import { existsSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import { gunzipSync } from "node:zlib";

const UPSTREAM = "https://github.com/huangkaoya/redalert2.git";
const COMMIT = "8c07f1092b2a9e8d8605ed49ef46d77b6c3ea367";
const MARKER_SCHEMA = "dsh-red-alert-renderer-v5";
const BUN_PACKAGE = "bun@1.3.14";
const PATCH = fileURLToPath(new URL("../renderer-adapter/patches/redalert2-8c07f109.patch.gz.base64", import.meta.url));
const RESOURCE_PATCH = fileURLToPath(new URL("../renderer-adapter/patches/redalert2-auto-local-resource.patch", import.meta.url));
const VIEWER_CONTROLS_PATCH = fileURLToPath(new URL("../renderer-adapter/patches/redalert2-viewer-controls.patch", import.meta.url));

function run(command, args, cwd, input, missingMessage) {
  const result = spawnSync(command, args, input === undefined
    ? { cwd, stdio: "inherit" }
    : { cwd, input, stdio: ["pipe", "inherit", "inherit"] });
  if (result.error !== undefined) {
    if (result.error.code === "ENOENT" && missingMessage !== undefined) throw new Error(missingMessage);
    throw result.error;
  }
  if (result.status !== 0) throw new Error(`${command} ${args.join(" ")} failed with exit code ${result.status ?? "unknown"}`);
}

function output(command, args, cwd) {
  const result = spawnSync(command, args, { cwd, encoding: "utf8" });
  if (result.error !== undefined) throw result.error;
  if (result.status !== 0) throw new Error(`${command} ${args.join(" ")} failed with exit code ${result.status ?? "unknown"}`);
  return result.stdout.trim();
}

const args = process.argv.slice(2).filter((value) => value !== "--");
if (args.length > 1) throw new Error("prepare:renderer accepts exactly one destination");
const destinationArg = args[0];
if (destinationArg === undefined || destinationArg === "--help" || destinationArg === "-h") {
  console.log("Usage: dsh-red-alert-prepare-renderer /absolute/new/directory");
  process.exit(destinationArg === undefined ? 1 : 0);
}

const destination = path.resolve(destinationArg);
if (!path.isAbsolute(destinationArg)) throw new Error("renderer destination must be an absolute path");
if (destination === path.parse(destination).root) throw new Error("renderer destination must not be a filesystem root");
if (existsSync(destination)) throw new Error(`renderer destination already exists and will not be overwritten: ${destination}`);

run("git", ["clone", "--filter=blob:none", "--no-checkout", UPSTREAM, destination], undefined, undefined,
  "Git is required only for the first renderer preparation. Install Git, reopen the terminal, and rerun the same setup command.");
run("git", ["checkout", "--detach", COMMIT], destination);
const actualCommit = output("git", ["rev-parse", "HEAD"], destination);
if (actualCommit !== COMMIT) throw new Error(`renderer commit mismatch: ${actualCommit}`);
const patchData = gunzipSync(Buffer.from(readFileSync(PATCH, "utf8").trim(), "base64"));
run("git", ["apply", "--check", "-"], destination, patchData);
run("git", ["apply", "-"], destination, patchData);
const resourcePatchData = readFileSync(RESOURCE_PATCH);
run("git", ["apply", "--check", "-"], destination, resourcePatchData);
run("git", ["apply", "-"], destination, resourcePatchData);
const viewerControlsPatchData = readFileSync(VIEWER_CONTROLS_PATCH);
run("git", ["apply", "--check", "-"], destination, viewerControlsPatchData);
run("git", ["apply", "-"], destination, viewerControlsPatchData);
console.log(`Using exact ${BUN_PACKAGE} through pnpm dlx; no global Bun installation is required.`);
run("pnpm", ["dlx", BUN_PACKAGE, "install", "--frozen-lockfile"], destination, undefined,
  "pnpm is required to run the pinned Bun build tool. Install pnpm and rerun the same setup command.");
run("pnpm", ["dlx", BUN_PACKAGE, "test", "./tests/formal-renderer-companion.test.ts"], destination);
run("pnpm", ["dlx", BUN_PACKAGE, "run", "build"], destination);

const dist = path.join(destination, "dist");
if (!existsSync(path.join(dist, "index.html"))) throw new Error("renderer build did not create dist/index.html");
writeFileSync(path.join(destination, ".dsh-red-alert-renderer.json"), `${JSON.stringify({
  schema: MARKER_SCHEMA,
  upstream: UPSTREAM,
  commit: COMMIT,
}, null, 2)}\n`);
console.log(`Renderer ready at ${dist}. Run dsh-red-alert-setup to save it for normal launches.`);
