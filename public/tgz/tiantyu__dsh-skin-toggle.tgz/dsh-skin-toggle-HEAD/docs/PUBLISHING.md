# Publishing / 发布指南

## 版本与仓库

- 所有版本都发布到同一仓库：https://github.com/tiantyu/dsh-skin-toggle
- `main` 分支始终是**最新代码**；每个版本打一个 `vX.Y.Z` tag 并创建 GitHub Release（附打包 tarball）。
- 版本号遵循语义化：`package.json` 的 `version` 是唯一事实来源，发版前先改它。

## 发布流程

1. 更新 `package.json` 的 `version`、`CHANGELOG.md`，本地验证：

   ```powershell
   node --check lib/client.js
   node tests/skin-manager.test.js
   ```

2. 打包（npm pack，输出到 `dsh-skin-toggle-dist/`）：

   ```powershell
   npm pack --pack-destination D:\harness\dsh-skin-toggle-dist
   ```

3. 推送到 GitHub（本机 git 直连 GitHub 不通，走 REST API 重放本地历史：
   `node D:\harness\code\.dsh-tools\push-history.mjs`，token 经 `GH_TOKEN` 环境变量传入）。

4. 创建 Release 并上传 tarball：
   `node D:\harness\code\.dsh-tools\publish-github.mjs`（v0.1.0 用的脚本；新版本按 tag 名更新）。

5. 验证：`https://github.com/tiantyu/dsh-skin-toggle/releases` 出现新版本与附件。

## 插件市场

- 已设置 `dsh-plugin` topic：dshfind / dsh-plugin-marketplace / WhaleHub 等自动收录。
- awesome-dsh-plugin（人工精选）：`dsh plugin add https://github.com/tiantyu/dsh-skin-toggle` 可安装；
  投稿 = PR 新增 `data/plugins/tiantyu__dsh-skin-toggle.yml`（category: `theme`），
  仓库需满 1 天且提交数 ≥ 10（本仓库已满足提交数）。
- 未发布 npm（`@dsh-external` scope 不属于作者）；如需 npm 分发改名为无 scope 包名后发布。
