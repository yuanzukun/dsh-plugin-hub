// Smoke test for D:\harness\dsh-skin-toggle\lib\client.js (skin manager v0.3, purely visual)
// using a minimal fake DOM. Asserts the loader is only ever READ (never update()).
const fs = require('fs');
const path = require('path');
const vm = require('vm');

let failures = 0;
function assert(cond, msg) {
  if (cond) { console.log('  PASS:', msg); }
  else { failures++; console.error('  FAIL:', msg); }
}

// ---------- fake DOM ----------
function makeDataset(el) {
  const toAttr = (k) => 'data-' + String(k).replace(/[A-Z]/g, (c) => '-' + c.toLowerCase());
  const target = {};
  return new Proxy(target, {
    get(t, prop) {
      if (typeof prop !== 'string') return t[prop];
      if (prop in t) return t[prop];
      const a = el.attrs[toAttr(prop)];
      return a !== undefined ? a : undefined;
    },
    set(t, prop, value) {
      if (typeof prop !== 'string') return false;
      t[prop] = value;
      if (value === undefined || value === null) delete el.attrs[toAttr(prop)];
      else el.attrs[toAttr(prop)] = value;
      return true;
    },
    deleteProperty(t, prop) {
      delete t[prop];
      delete el.attrs[toAttr(prop)];
      return true;
    },
  });
}

function makeEl(tag) {
  const el = {
    tagName: String(tag).toUpperCase(),
    children: [],
    style: {},
    attrs: {},
    textContent: '',
    _listeners: {},
    parentNode: null,
    appendChild(c) { this.children.push(c); c.parentNode = this; return c; },
    remove() {
      if (this.id && doc && doc._byId && doc._byId[this.id] === this) delete doc._byId[this.id];
      if (this.parentNode) {
        const i = this.parentNode.children.indexOf(this);
        if (i >= 0) this.parentNode.children.splice(i, 1);
        this.parentNode = null;
      }
    },
    contains(other) { return other === this || this.children.some((c) => c.contains(other)); },
    setAttribute(k, v) { this.attrs[k] = String(v); },
    getAttribute(k) { return Object.prototype.hasOwnProperty.call(this.attrs, k) ? this.attrs[k] : null; },
    removeAttribute(k) { delete this.attrs[k]; },
    hasAttribute(k) { return Object.prototype.hasOwnProperty.call(this.attrs, k); },
    addEventListener(type, fn) { (this._listeners[type] = this._listeners[type] || []).push(fn); },
    removeEventListener(type, fn) {
      const l = this._listeners[type] || [];
      const i = l.indexOf(fn);
      if (i >= 0) l.splice(i, 1);
    },
    fire(type, event) {
      const ev = event || {};
      ev.target = ev.target || this;
      ev.preventDefault = ev.preventDefault || (() => { ev._prevented = true; });
      (this._listeners[type] || []).slice().forEach((fn) => fn.call(this, ev));
      return ev;
    },
    click() { return this.fire('click'); },
    getBoundingClientRect() {
      const left = parseFloat(this.style.left) || 0;
      const top = parseFloat(this.style.top) || 0;
      return { left, top, width: 36, height: 36, right: left + 36, bottom: top + 36 };
    },
    setPointerCapture() {},
    releasePointerCapture() {},
  };
  Object.defineProperty(el, 'className', {
    get() { return this.attrs['class'] || ''; },
    set(v) { this.attrs['class'] = v; },
  });
  Object.defineProperty(el, 'dataset', { get() { return makeDataset(el); } });
  return el;
}

const doc = { body: makeEl('body'), head: makeEl('head'), _byId: {}, _docListeners: {} };
doc.createElement = (t) => makeEl(t);
doc.getElementById = (id) => {
  if (doc._byId[id]) return doc._byId[id];
  const find = (els) => {
    for (const e of els) {
      if (e.attrs && e.attrs.id === id) return e;
      const sub = find(e.children || []);
      if (sub) return sub;
    }
    return null;
  };
  return find([doc.body, doc.head]);
};
doc.addEventListener = (type, fn) => { (doc._docListeners[type] = doc._docListeners[type] || []).push(fn); };
doc.removeEventListener = (type, fn) => {
  const l = doc._docListeners[type] || [];
  const i = l.indexOf(fn);
  if (i >= 0) l.splice(i, 1);
};
doc.dispatch = (type, event) => {
  const ev = event || {};
  ev.target = ev.target || doc.body;
  (doc._docListeners[type] || []).slice().forEach((fn) => fn.call(doc, ev));
  return ev;
};
const origHeadAppend = doc.head.appendChild.bind(doc.head);
doc.head.appendChild = (c) => { if (c && c.id) doc._byId[c.id] = c; return origHeadAppend(c); };
const origBodyAppend = doc.body.appendChild.bind(doc.body);
doc.body.appendChild = (c) => { if (c && c.id) doc._byId[c.id] = c; return origBodyAppend(c); };

const storage = {};
const localStorage = {
  getItem: (k) => (k in storage ? storage[k] : null),
  setItem: (k, v) => { storage[k] = String(v); },
  removeItem: (k) => { delete storage[k]; },
};

// ---------- load the client bundle ----------
let handoff = null;
const window = { __ModuleLoader__: { load: (h) => { handoff = h; } }, innerWidth: 1280, innerHeight: 800 };
global.window = window;
global.document = doc;
global.localStorage = localStorage;

const code = fs.readFileSync(path.join(__dirname, '..', 'lib', 'client.js'), 'utf8');
vm.runInThisContext(code, { filename: 'client.js' });
assert(handoff !== null, 'bundle registered via window.__ModuleLoader__.load');
assert(handoff.id === 'dsh-skin-toggle', 'module id matches package name');

const mod = handoff.factory(() => { throw new Error('unexpected require call'); });
assert(typeof mod.apply === 'function', 'factory exports apply()');

// ---------- fake skin entries (read-only; update() must never be called) ----------
function makeSkinEntry(moduleName) {
  const entry = { options: { name: moduleName }, _updates: [] };
  entry.update = function (opts) { this._updates.push(opts); return Promise.resolve(); };
  return entry;
}

function makeCtx(entries) {
  const disposers = [];
  const ctx = {
    loader: { entries: () => entries },
    effect(fn) { disposers.push(fn); return () => {}; },
    _disposers: disposers,
  };
  return ctx;
}

function resetDom() {
  doc.body.attrs = {};
  doc.body.children = [];
  doc.head.children = [];
  doc._byId = {};
  doc._docListeners = {};
}

function findButton() { return doc.body.children.find((c) => c.tagName === 'BUTTON'); }
function findPanel() { return doc.body.children.find((c) => (c.attrs['class'] || '').indexOf('dsh-skin-manager-panel') !== -1); }
function stateRules() {
  const st = doc.getElementById('dsh-skin-toggle-state-style');
  return st ? st.textContent : null;
}

// ---------- scenario helpers ----------
const maid = makeSkinEntry('@dsh-external/dsh-client-ui-skin-maid-atelier');
const miku = makeSkinEntry('@linxin666/dsh-client-ui-skin-miku');
const sidebar = { options: { name: 'dsh-better-sidebar' } }; // not a skin
const skinCenter = makeSkinEntry('dsh-client-ui-skin-center'); // excluded

let lastDispose = null;

function setup(initialStorage, initiallyRenderedSkin) {
  // dispose the previous instance so its re-assert interval stops
  if (lastDispose) { try { lastDispose(); } catch (_e) { /* ignore */ } lastDispose = null; }
  resetDom();
  for (const k of Object.keys(storage)) delete storage[k];
  for (const k of Object.keys(initialStorage || {})) storage[k] = initialStorage[k];
  // simulate the installed skin's apply() having run at boot (body gate attr present)
  if (initiallyRenderedSkin) doc.body.setAttribute('data-dsh-' + initiallyRenderedSkin, '');
  const ctx = makeCtx([maid, miku, sidebar, skinCenter]);
  mod.apply(ctx);
  lastDispose = () => ctx._disposers.forEach((fn) => { const d = fn(); if (typeof d === 'function') d(); });
  return ctx;
}

// ---------- test 1: boot with maid rendered, saved default ----------
console.log('\n[test 1] boot: saved default → clean default page');
setup({ 'dsh-skin-manager:active': '' }, 'maid-atelier');
const btn = findButton();
assert(!!btn, 'button appended to body');
assert(btn.textContent === '\ud83d\udc0b', 'button shows whale emoji');
assert(btn.dataset.off === 'true', 'button shows off state (default)');
assert(doc.body.hasAttribute('data-dsh-skin-manager-default'), 'default hide layer applied');
assert(!doc.body.hasAttribute('data-dsh-maid-atelier'), 'maid gate attr removed (CSS de-scoped)');
assert(maid._updates.length === 0 && miku._updates.length === 0, 'loader entries never updated (read-only)');

console.log('\n[test 2] right-click panel lists skins; select maid-atelier');
btn.fire('contextmenu', {});
const panel = findPanel();
assert(!!panel, 'panel opened');
const rows = panel.children.filter((c) => c.attrs['data-skin-manager-row'] !== undefined);
assert(rows.length === 3, 'panel lists 默认 + 2 skins (skin-center excluded), got ' + rows.length);
const rowTexts = rows.map((r) => r.children[r.children.length - 1].textContent);
assert(rowTexts[0] === '默认（无皮肤）', 'first row is default');
assert(panel.children.some((c) => c.attrs['data-skin-manager-diag'] !== undefined), 'panel shows diagnostics line');
const maidRow = rows.find((r) => r.children[r.children.length - 1].textContent === 'maid-atelier');
maidRow.click();
assert(findPanel() === undefined, 'panel closed after selection');
assert(!doc.body.hasAttribute('data-dsh-skin-manager-default'), 'default layer removed');
assert(doc.body.hasAttribute('data-dsh-maid-atelier'), 'maid gate attr present (skin shown)');
assert(btn.dataset.off === undefined, 'button shows active state');
assert(storage['dsh-skin-manager:active'] === 'maid-atelier', 'state persisted');

console.log('\n[test 3] switch to miku (mutual exclusion)');
btn.fire('contextmenu', {});
const mikuRow = findPanel().children.filter((c) => c.attrs['data-skin-manager-row'] !== undefined)
  .find((r) => r.children[r.children.length - 1].textContent === 'miku');
mikuRow.click();
assert(!doc.body.hasAttribute('data-dsh-maid-atelier'), 'maid gate attr removed');
assert(doc.body.hasAttribute('data-dsh-miku'), 'miku gate attr present');
const rules3 = stateRules();
assert(rules3.indexOf("[data-skin-owner='maid-atelier']") !== -1, 'hide rule for maid chrome present');
assert(rules3.indexOf("data-skin-owner='miku'") === -1, 'no hide rule for miku');
assert(!doc.body.hasAttribute('data-dsh-skin-manager-default'), 'no default layer');
assert(maid._updates.length === 0 && miku._updates.length === 0, 'still no loader mutations');

console.log('\n[test 4] left click → back to default');
btn.click();
assert(doc.body.hasAttribute('data-dsh-skin-manager-default'), 'default layer applied');
assert(!doc.body.hasAttribute('data-dsh-miku'), 'miku gate attr removed');
assert(storage['dsh-skin-manager:active'] === '', 'state persisted as default');
assert(btn.dataset.off === 'true', 'button shows off state');

// ---------- test 5: panel close behaviors ----------
console.log('\n[test 5] panel close via outside click and Escape');
btn.fire('contextmenu', {});
assert(!!findPanel(), 'panel reopened');
doc.dispatch('click', { target: doc.body });
assert(findPanel() === undefined, 'panel closes on outside click');
btn.fire('contextmenu', {});
assert(!!findPanel(), 'panel reopened again');
doc.dispatch('keydown', { key: 'Escape' });
assert(findPanel() === undefined, 'panel closes on Escape');

// ---------- test 6: boot restore saved skin ----------
console.log('\n[test 6] boot restore saved skin');
setup({ 'dsh-skin-manager:active': 'miku' }, 'maid-atelier'); // page boots with maid rendered
assert(doc.body.hasAttribute('data-dsh-miku'), 'saved miku shown');
assert(!doc.body.hasAttribute('data-dsh-maid-atelier'), 'maid hidden');
assert(!doc.body.hasAttribute('data-dsh-skin-manager-default'), 'no default layer');

console.log('\n[test 7] boot restore saved default');
setup({ 'dsh-skin-manager:active': '' }, 'maid-atelier');
assert(doc.body.hasAttribute('data-dsh-skin-manager-default'), 'default hide layer applied at boot');
assert(!doc.body.hasAttribute('data-dsh-maid-atelier'), 'maid de-scoped at boot');

console.log('\n[test 8] legacy key migration (old "off" == default)');
setup({ 'dsh-skin-toggle:maid-atelier': 'off' }, 'maid-atelier');
assert(doc.body.hasAttribute('data-dsh-skin-manager-default'), 'legacy off migrated to default');
assert(storage['dsh-skin-manager:active'] === '', 'new key written');

// ---------- test 9: no skins installed ----------
console.log('\n[test 9] no skins installed');
if (lastDispose) { try { lastDispose(); } catch (_e) { /* ignore */ } lastDispose = null; }
resetDom();
for (const k of Object.keys(storage)) delete storage[k];
const ctx9 = makeCtx([sidebar]);
mod.apply(ctx9);
const btn9 = findButton();
assert(!!btn9, 'button still appears');
btn9.fire('contextmenu', {});
assert(!!findPanel(), 'panel opens');
assert(findPanel().children.some((c) => c.attrs['data-skin-manager-empty'] !== undefined), 'panel shows empty notice');
btn9.click();
assert(doc.body.hasAttribute('data-dsh-skin-manager-default'), 'left click still works (default)');

// ---------- test 10: first run derives current skin ----------
console.log('\n[test 10] first run keeps the currently rendered skin');
if (lastDispose) { try { lastDispose(); } catch (_e) { /* ignore */ } lastDispose = null; }
resetDom();
for (const k of Object.keys(storage)) delete storage[k];
doc.body.setAttribute('data-dsh-maid-atelier', '');
const ctx10 = makeCtx([maid, miku, sidebar, skinCenter]);
mod.apply(ctx10);
assert(storage['dsh-skin-manager:active'] === 'maid-atelier', 'first run persisted the rendered skin');
assert(doc.body.hasAttribute('data-dsh-maid-atelier'), 'rendered skin kept');
assert(!doc.body.hasAttribute('data-dsh-skin-manager-default'), 'no default layer on first run');

// ---------- test 11: disposer cleanup ----------
console.log('\n[test 11] plugin dispose removes its DOM');
const d11 = ctx10._disposers[0]();
d11();
assert(!doc.body.children.includes(findButton()), 'dispose: button removed');
assert(doc.getElementById('dsh-skin-toggle-style') === null, 'dispose: static style removed');
assert(doc.getElementById('dsh-skin-toggle-state-style') === null, 'dispose: state style removed');

// ---------- test 12: drag the button ----------
console.log('\n[test 12] drag moves the button and suppresses the click');
if (lastDispose) { try { lastDispose(); } catch (_e) { /* ignore */ } lastDispose = null; }
resetDom();
for (const k of Object.keys(storage)) delete storage[k];
doc.body.setAttribute('data-dsh-maid-atelier', ''); // maid rendered
const ctx12 = makeCtx([maid, miku, sidebar, skinCenter]);
mod.apply(ctx12);
lastDispose = () => ctx12._disposers.forEach((fn) => { const d = fn(); if (typeof d === 'function') d(); });
const btn12 = findButton();
assert(!!btn12, 'button present');
assert(!btn12.style.left, 'button starts at CSS default position (no inline left)');

btn12.fire('pointerdown', { button: 0, pointerId: 1, clientX: 200, clientY: 150 });
btn12.fire('pointermove', { pointerId: 1, clientX: 240, clientY: 180 }); // > threshold
btn12.fire('pointerup', { pointerId: 1, clientX: 240, clientY: 180 });
assert(btn12.style.left === '40px' && btn12.style.top === '30px', 'button moved by the drag delta (clamped ok): ' + btn12.style.left + ',' + btn12.style.top);
assert(btn12.style.right === 'auto', 'inline right cleared after drag');
const savedPos = JSON.parse(storage['dsh-skin-manager:pos'] || 'null');
assert(!!savedPos && savedPos.left === '40px' && savedPos.top === '30px', 'drag position persisted to localStorage');
assert(storage['dsh-skin-manager:active'] === undefined || storage['dsh-skin-manager:active'] === 'maid-atelier', 'skin state untouched by drag');
btn12.click();
assert(!doc.body.hasAttribute('data-dsh-skin-manager-default'), 'click after drag is suppressed (skin NOT reset)');
assert(btn12.dataset.off === undefined, 'button still shows active state after suppressed click');

// ---------- test 13: click (no drag) still works ----------
console.log('\n[test 13] plain click (no drag) still applies default');
btn12.fire('pointerdown', { button: 0, pointerId: 2, clientX: 100, clientY: 100 });
btn12.fire('pointerup', { pointerId: 2, clientX: 101, clientY: 101 }); // under threshold → not a drag
btn12.click();
assert(doc.body.hasAttribute('data-dsh-skin-manager-default'), 'plain click applied default');
assert(storage['dsh-skin-manager:active'] === '', 'default persisted');

// ---------- test 14: right-click still opens panel; position restored at boot ----------
console.log('\n[test 14] right-click opens panel; saved position restored on boot');
btn12.fire('contextmenu', {});
assert(!!findPanel(), 'panel opens on right-click after drag');
btn12.fire('click', {});
if (lastDispose) { try { lastDispose(); } catch (_e) { /* ignore */ } lastDispose = null; }
resetDom();
for (const k of Object.keys(storage)) delete storage[k];
storage['dsh-skin-manager:pos'] = JSON.stringify({ left: '500px', top: '300px' });
doc.body.setAttribute('data-dsh-maid-atelier', '');
const ctx14 = makeCtx([maid, miku, sidebar, skinCenter]);
mod.apply(ctx14);
const btn14 = findButton();
assert(btn14.style.left === '500px' && btn14.style.top === '300px', 'saved drag position restored at boot');

console.log(failures === 0 ? '\nALL TESTS PASSED' : `\n${failures} TEST(S) FAILED`);
process.exit(failures === 0 ? 0 : 1);
