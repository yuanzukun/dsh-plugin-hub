# Changelog

All notable changes to dsh-skin-toggle.

## [0.4.0] - 2026-08-17

### Added
- 🐋 按钮可**任意拖动**：按住左键拖到 WebUI 内任意位置，松手固定并记住位置（localStorage），刷新后保持。
- 右键面板改为**跟随按钮定位**（拖到哪儿面板开在哪儿，靠近视口边缘时自动翻转）。

## [0.3.0] - 2026-08-17

### Fixed
- 改为**纯视觉管理**：不再调用 `entry.update({disabled})` 修改 Loader 条目（该机制在客户端运行时不可靠，
  曾导致默认状态残留皮肤边框、切换时皮肤重复执行）。现在只控制显隐：目标皮肤保留门控属性
  `data-dsh-<id>`，其余皮肤移除门控属性并注入 `[data-skin-owner]` 隐藏规则；默认状态移除全部门控属性
  并抬起 `data-dsh-skin-manager-default` 隐藏层。
- 默认状态隐藏层不再误隐藏按钮自身（`data-skin-owner` 选择器排除 `dsh-skin-toggle`）。
- 新增面板内诊断行与启动重述（约 9 秒），修复皮肤与本插件的加载顺序竞态。

## [0.2.0] - 2026-08-16

### Added
- 升级为**皮肤管理器**：右键按钮弹出面板，列出所有已安装皮肤（按脚手架命名约定
  `dsh-client-ui-skin-<id>` 自动检测），点选即切换，皮肤互斥；左键恢复默认皮肤。
- 兼容旧版 localStorage 状态迁移。

## [0.1.0] - 2026-08-15

### Added
- 初始版本：单皮肤（maid-atelier）即时开关按钮，右上角 🐋，点击切换默认/皮肤。

[0.4.0]: https://github.com/tiantyu/dsh-skin-toggle/releases/tag/v0.4.0
[0.3.0]: https://github.com/tiantyu/dsh-skin-toggle/releases/tag/v0.3.0
[0.2.0]: https://github.com/tiantyu/dsh-skin-toggle/releases/tag/v0.2.0
[0.1.0]: https://github.com/tiantyu/dsh-skin-toggle/releases/tag/v0.1.0
