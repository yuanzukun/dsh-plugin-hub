import { test } from 'node:test'
import assert from 'node:assert/strict'
import { isLoopbackRequest, readJsonBody, writeJson } from '../lib/http-utils.js'

/** 构造最小 mock request。 */
function mockReq({ remoteAddress = '127.0.0.1', host = '127.0.0.1:3080', omitHost = false, secFetchSite, origin } = {}) {
  const headers = {}
  if (!omitHost) headers.host = host
  if (secFetchSite !== undefined) headers['sec-fetch-site'] = secFetchSite
  if (origin !== undefined) headers.origin = origin
  return { socket: { remoteAddress }, headers }
}

// ---- isLoopbackRequest：回环防护 ----

test('isLoopbackRequest: 127.0.0.1 + 本地 host → true', () => {
  assert.equal(isLoopbackRequest(mockReq()), true)
})

test('isLoopbackRequest: ::1 + localhost host → true', () => {
  assert.equal(isLoopbackRequest(mockReq({ remoteAddress: '::1', host: 'localhost:3080' })), true)
})

test('isLoopbackRequest: ::ffff:127.0.0.1 → true', () => {
  assert.equal(isLoopbackRequest(mockReq({ remoteAddress: '::ffff:127.0.0.1' })), true)
})

test('isLoopbackRequest: 非回环地址 → false', () => {
  assert.equal(isLoopbackRequest(mockReq({ remoteAddress: '192.168.1.5' })), false)
})

test('isLoopbackRequest: host 非本地主机名 → false', () => {
  assert.equal(isLoopbackRequest(mockReq({ host: 'evil.example.com' })), false)
})

test('isLoopbackRequest: host 缺失 → false', () => {
  assert.equal(isLoopbackRequest(mockReq({ omitHost: true })), false)
})

test('isLoopbackRequest: sec-fetch-site cross-site → false', () => {
  assert.equal(isLoopbackRequest(mockReq({ secFetchSite: 'cross-site' })), false)
})

test('isLoopbackRequest: 同源 origin → true', () => {
  assert.equal(isLoopbackRequest(mockReq({ origin: 'http://127.0.0.1:3080' })), true)
})

test('isLoopbackRequest: 跨源 origin → false', () => {
  assert.equal(isLoopbackRequest(mockReq({ origin: 'http://evil.example.com' })), false)
})

test('isLoopbackRequest: 无 origin（非浏览器）→ true', () => {
  assert.equal(isLoopbackRequest(mockReq({ origin: undefined })), true)
})

// ---- writeJson ----

test('writeJson: 写 200 JSON 响应（content-type + payload）', () => {
  const calls = []
  const res = {
    writeHead(status, headers) { calls.push(['head', status, headers]) },
    end(payload) { calls.push(['end', payload]) },
  }
  writeJson(res, 200, { ok: true })
  assert.equal(calls[0][0], 'head')
  assert.equal(calls[0][1], 200)
  assert.equal(calls[0][2]['content-type'], 'application/json; charset=utf-8')
  assert.match(calls[1][1], /"ok":true/)
})

test('writeJson: 支持 403/400 等状态码', () => {
  const calls = []
  const res = { writeHead(s) { calls.push(s) }, end() {} }
  writeJson(res, 403, { error: 'forbidden' })
  assert.equal(calls[0], 403)
})

// ---- readJsonBody ----

test('readJsonBody: 解析合法 JSON → object', async () => {
  const req = (async function* () { yield Buffer.from('{"url":"http://x"}') })()
  const body = await readJsonBody(req)
  assert.deepEqual(body, { url: 'http://x' })
})

test('readJsonBody: 分块拼接解析', async () => {
  const req = (async function* () {
    yield Buffer.from('{"ur')
    yield Buffer.from('l":"http://x"}')
  })()
  assert.deepEqual(await readJsonBody(req), { url: 'http://x' })
})

test('readJsonBody: 非法 JSON → undefined', async () => {
  const req = (async function* () { yield Buffer.from('not json') })()
  assert.equal(await readJsonBody(req), undefined)
})

test('readJsonBody: 超过 64KB → undefined', async () => {
  const req = (async function* () { yield Buffer.alloc(70 * 1024, 'a') })()
  assert.equal(await readJsonBody(req), undefined)
})

test('readJsonBody: 非 object JSON（如数组）→ undefined', async () => {
  const req = (async function* () { yield Buffer.from('[1,2]') })()
  assert.equal(await readJsonBody(req), undefined)
})
