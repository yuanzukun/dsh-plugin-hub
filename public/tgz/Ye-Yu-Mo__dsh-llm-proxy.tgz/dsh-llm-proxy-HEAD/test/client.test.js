// test/client.test.js — client half 的契约测试（mock 浏览器环境，不做真实 UI 渲染）
// TODO-M2 说明 client factory 格式不做 node 单测，以集成验证为准；这里把「可测契约」
// 提出来覆盖：load 契约、factory 形状、settings.section 注册、组件渲染结构。
import { test } from 'node:test'
import assert from 'node:assert/strict'

// ---- 模拟浏览器环境 ----
let loaded = null
globalThis.window = {
  __ModuleLoader__: {
    load: (spec) => { loaded = spec },
  },
}

// mock react：createElement 返回描述树，useState/useEffect 可调用
function mockReact() {
  return {
    useState: (init) => [typeof init === 'function' ? init() : init, () => {}],
    useEffect: () => {},
    createElement: (type, props, ...children) => ({ type, props: props || {}, children }),
  }
}

// 执行 client.js（副作用：调用 window.__ModuleLoader__.load）
await import('../lib/client.js')

test('client: load 注册 id 为 dsh-llm-proxy 且带 factory', () => {
  assert.ok(loaded, 'load 应被调用')
  assert.equal(loaded.id, 'dsh-llm-proxy')
  assert.equal(typeof loaded.factory, 'function')
})

test('client: factory 返回 { apply, inject: [slots, settingsScope] }', () => {
  const moduleExports = loaded.factory((name) => {
    if (name === 'react') return mockReact()
    throw new Error(`unexpected require: ${name}`)
  })
  assert.equal(typeof moduleExports.apply, 'function')
  assert.deepEqual(moduleExports.inject, ['slots', 'settingsScope'])
})

test('client: apply 注册 settings.section cell（id/order/label/inject 契约）', () => {
  const captures = []
  const scopeValue = { value: { enabled: false, url: '', noProxy: ['localhost'] }, mode: 'disk', writable: true, revision: 1 }
  const mockScope = {
    getSnapshot: () => scopeValue,
    set: async () => {},
    load: async () => {},
    subscribe: () => () => {},
    dispose: () => {},
  }
  const ctx = {
    settingsScope: {
      bind: (opts) => {
        assert.equal(opts.namespace, 'llm-proxy')
        return mockScope
      },
    },
    slots: {
      inject: (name, fn) => { captures.push({ name, fn }) },
      register: (opts, Component) => { captures.push({ registered: opts, Component }) ; return () => {} },
    },
  }
  const moduleExports = loaded.factory((name) => {
    if (name === 'react') return mockReact()
    throw new Error(`unexpected require: ${name}`)
  })
  moduleExports.apply(ctx)

  const injectCall = captures.find((c) => c.name === 'settings.section')
  assert.ok(injectCall, '应 inject settings.section 插槽')
  // 执行 inject 回调 → register
  injectCall.fn()
  const reg = captures.find((c) => c.registered)
  assert.ok(reg, 'inject 回调应触发 register')
  assert.equal(reg.registered.name, 'settings.section')
  assert.equal(reg.registered.id, 'llm-proxy')
  assert.equal(reg.registered.order, 5)
  assert.equal(reg.registered.label, 'LLM 代理')
  // inject 面提供 scope
  const injected = reg.registered.inject()
  assert.ok(injected.scope, 'inject 面应提供 scope')
})

test('client: 组件渲染产生表单结构（标题/URL 输入/保存/测试按钮）', () => {
  const captures = []
  const scopeValue = { value: { enabled: true, url: 'http://127.0.0.1:7891', noProxy: ['localhost'] }, mode: 'disk', writable: true, revision: 1 }
  const mockScope = {
    getSnapshot: () => scopeValue,
    set: async () => {},
    load: async () => {},
    subscribe: () => () => {},
    dispose: () => {},
  }
  const ctx = {
    settingsScope: { bind: () => mockScope },
    slots: {
      inject: (name, fn) => { captures.push({ name, fn }) },
      register: (opts, Component) => { captures.push({ registered: opts, Component }); return () => {} },
    },
  }
  const moduleExports = loaded.factory((name) => {
    if (name === 'react') return mockReact()
    throw new Error(`unexpected require: ${name}`)
  })
  moduleExports.apply(ctx)
  // inject 回调在插槽渲染时才执行：手动触发以获得 register 捕获
  const injectCall = captures.find((c) => c.name === 'settings.section')
  injectCall.fn()
  const reg = captures.find((c) => c.registered)
  const injected = reg.registered.inject()
  const tree = reg.Component(injected)

  // 遍历描述树收集文本与控件
  const texts = []
  const controls = []
  const walk = (node) => {
    if (node === null || node === undefined) return
    if (typeof node === 'string' || typeof node === 'number') { texts.push(String(node)); return }
    if (typeof node !== 'object') return
    if (typeof node.type === 'string') controls.push(node.type)
    if (node.props && typeof node.props.children === 'string') texts.push(node.props.children)
    if (Array.isArray(node.children)) node.children.forEach(walk)
    if (node.props && Array.isArray(node.props.children)) node.props.children.forEach(walk)
  }
  walk(tree)

  assert.ok(texts.includes('LLM 代理'), '应渲染标题文本')
  assert.ok(texts.includes('代理 URL'), '应渲染 URL 字段标签')
  assert.ok(controls.includes('input'), '应渲染 input')
  assert.ok(controls.includes('button'), '应渲染 button')
  assert.ok(texts.includes('保存') || texts.some((t) => t.includes('保存')), '应渲染保存按钮')
})
