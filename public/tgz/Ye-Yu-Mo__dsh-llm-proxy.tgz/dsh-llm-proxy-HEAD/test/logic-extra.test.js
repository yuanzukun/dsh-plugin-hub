import { test } from 'node:test'
import assert from 'node:assert/strict'
import { effectiveMode } from '../lib/logic.js'

// ---- effectiveMode：生效状态推导（设置代理优先 → env 次之 → 直连兜底） ----

test('effectiveMode: enabled + 合法 url → setting', () => {
  assert.deepEqual(effectiveMode({ enabled: true, url: 'http://127.0.0.1:7891' }), { mode: 'setting', url: 'http://127.0.0.1:7891' })
})

test('effectiveMode: enabled + 合法 url 优先于 env（即使 env 存在）', () => {
  assert.deepEqual(
    effectiveMode({ enabled: true, url: 'http://127.0.0.1:7891' }, { HTTPS_PROXY: 'http://env:8080' }),
    { mode: 'setting', url: 'http://127.0.0.1:7891' },
  )
})

test('effectiveMode: enabled 但 url 非法 + env 存在 → env（非法 url 不生效）', () => {
  assert.deepEqual(effectiveMode({ enabled: true, url: 'ftp://x' }, { HTTPS_PROXY: 'http://env:8080' }), { mode: 'env', url: 'http://env:8080' })
})

test('effectiveMode: 未启用 + env.HTTPS_PROXY → env', () => {
  assert.deepEqual(effectiveMode({ enabled: false }, { HTTPS_PROXY: 'http://env:8080' }), { mode: 'env', url: 'http://env:8080' })
})

test('effectiveMode: env 小写 https_proxy → env', () => {
  assert.deepEqual(effectiveMode({}, { https_proxy: 'http://env:8080' }), { mode: 'env', url: 'http://env:8080' })
})

test('effectiveMode: http_proxy 小写 → env', () => {
  assert.deepEqual(effectiveMode({}, { http_proxy: 'http://env:8080' }), { mode: 'env', url: 'http://env:8080' })
})

test('effectiveMode: env 优先级 HTTPS_PROXY > http_proxy', () => {
  assert.deepEqual(effectiveMode({}, { HTTPS_PROXY: 'http://a', http_proxy: 'http://b' }), { mode: 'env', url: 'http://a' })
})

test('effectiveMode: 都无 → direct', () => {
  assert.deepEqual(effectiveMode({ enabled: false }, {}), { mode: 'direct' })
})

test('effectiveMode: enabled:false 但 url 有值 + 无 env → direct（url 不生效）', () => {
  assert.deepEqual(effectiveMode({ enabled: false, url: 'http://127.0.0.1:7891' }), { mode: 'direct' })
})

test('effectiveMode: env 参数注入，不读真实 process.env', () => {
  // env 是注入参数：即使传入空 env，也不该读 process.env（process.env 可能有 HTTPS_PROXY）
  assert.deepEqual(effectiveMode({}, {}), { mode: 'direct' })
  assert.deepEqual(effectiveMode({}, { HTTPS_PROXY: 'http://injected' }), { mode: 'env', url: 'http://injected' })
})
