import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  DEFAULT_NO_PROXY,
  URL_RE,
  configKey,
  effectiveMode,
  normalizeConfig,
  noProxyValue,
  shouldApplyProxy,
} from '../lib/logic.js'

// ---- normalizeConfig：缺省/默认值 ----

test('normalizeConfig(undefined) 回退默认：enabled=false, url="", noProxy=默认', () => {
  const n = normalizeConfig(undefined)
  assert.equal(n.enabled, false)
  assert.equal(n.url, '')
  assert.deepEqual(n.noProxy, DEFAULT_NO_PROXY)
})

test('normalizeConfig({}) 同样回退默认', () => {
  const n = normalizeConfig({})
  assert.equal(n.enabled, false)
  assert.equal(n.url, '')
  assert.deepEqual(n.noProxy, DEFAULT_NO_PROXY)
})

test('normalizeConfig 返回新数组，不共享默认引用（防修改污染）', () => {
  const n = normalizeConfig({})
  n.noProxy.push('evil')
  const m = normalizeConfig({})
  assert.deepEqual(m.noProxy, DEFAULT_NO_PROXY)
})

test('默认 noProxy 保护本地流量：含 localhost / 127.0.0.1 / ::1', () => {
  for (const host of ['localhost', '127.0.0.1', '::1']) {
    assert.ok(DEFAULT_NO_PROXY.includes(host), `默认 noProxy 应包含 ${host}`)
  }
})

// ---- normalizeConfig：字段归一化 ----

test('normalizeConfig 对 url 做 trim', () => {
  const n = normalizeConfig({ enabled: true, url: '  http://127.0.0.1:7891  ' })
  assert.equal(n.url, 'http://127.0.0.1:7891')
})

test('normalizeConfig 过滤 noProxy 中的非字符串元素', () => {
  const n = normalizeConfig({ noProxy: ['a', 123, null, 'b', undefined] })
  assert.deepEqual(n.noProxy, ['a', 'b'])
})

test('normalizeConfig 空 noProxy 数组回退默认', () => {
  const n = normalizeConfig({ noProxy: [] })
  assert.deepEqual(n.noProxy, DEFAULT_NO_PROXY)
})

test('normalizeConfig 非数组 noProxy 回退默认', () => {
  const n = normalizeConfig({ noProxy: 'localhost' })
  assert.deepEqual(n.noProxy, DEFAULT_NO_PROXY)
})

// ---- shouldApplyProxy：是否应应用代理 ----

test('shouldApplyProxy: enabled + 合法 http URL → true', () => {
  assert.equal(shouldApplyProxy({ enabled: true, url: 'http://127.0.0.1:7891' }), true)
})

test('shouldApplyProxy: enabled + 合法 https URL → true', () => {
  assert.equal(shouldApplyProxy({ enabled: true, url: 'https://proxy.example.com:8080' }), true)
})

test('shouldApplyProxy: enabled 但 url 为空 → false（恢复基线）', () => {
  assert.equal(shouldApplyProxy({ enabled: true, url: '' }), false)
})

test('shouldApplyProxy: enabled 但 url 全空白 → false（trim 后为空）', () => {
  assert.equal(shouldApplyProxy({ enabled: true, url: '   ' }), false)
})

test('shouldApplyProxy: 非法 scheme（ftp://）→ false', () => {
  assert.equal(shouldApplyProxy({ enabled: true, url: 'ftp://proxy.example.com' }), false)
})

test('shouldApplyProxy: 无 scheme（localhost:7891）→ false', () => {
  assert.equal(shouldApplyProxy({ enabled: true, url: 'localhost:7891' }), false)
})

test('shouldApplyProxy: enabled=false 但 url 有值 → false（恢复基线）', () => {
  assert.equal(shouldApplyProxy({ enabled: false, url: 'http://127.0.0.1:7891' }), false)
})

test('shouldApplyProxy: enabled 缺省但 url 有值 → false', () => {
  assert.equal(shouldApplyProxy({ url: 'http://127.0.0.1:7891' }), false)
})

// ---- configKey：幂等跳过判定 ----

test('configKey: 相同配置两次 → 相同 key（热切换幂等跳过）', () => {
  const a = { enabled: true, url: 'http://127.0.0.1:7891', noProxy: ['localhost', '127.0.0.1'] }
  assert.equal(configKey(a), configKey({ ...a }))
})

test('configKey: 配置等价（url 空白差异归一化后）→ 相同 key', () => {
  assert.equal(
    configKey({ enabled: true, url: ' http://127.0.0.1:7891 ' }),
    configKey({ enabled: true, url: 'http://127.0.0.1:7891' }),
  )
})

test('configKey: enabled 不同 → key 不同', () => {
  assert.notEqual(
    configKey({ enabled: true, url: 'http://127.0.0.1:7891' }),
    configKey({ enabled: false, url: 'http://127.0.0.1:7891' }),
  )
})

test('configKey: url 不同 → key 不同', () => {
  assert.notEqual(
    configKey({ enabled: true, url: 'http://127.0.0.1:7891' }),
    configKey({ enabled: true, url: 'http://127.0.0.1:7892' }),
  )
})

test('configKey: noProxy 顺序不同 → key 不同（join 顺序敏感，按实现定义）', () => {
  assert.notEqual(
    configKey({ noProxy: ['a', 'b'] }),
    configKey({ noProxy: ['b', 'a'] }),
  )
})

// ---- noProxyValue：数组 → EnvHttpProxyAgent 字符串 ----

test('noProxyValue: 数组 → 逗号分隔字符串（EnvHttpProxyAgent 要求）', () => {
  assert.equal(noProxyValue(['localhost', '127.0.0.1', '::1']), 'localhost,127.0.0.1,::1')
})

test('noProxyValue: 空配置 → 默认 noProxy 字符串', () => {
  assert.equal(noProxyValue([]), 'localhost,127.0.0.1,::1')
})

// ---- URL_RE ----

test('URL_RE: 匹配 http/https（大小写不敏感），不匹配其他 scheme', () => {
  assert.ok(URL_RE.test('http://x'))
  assert.ok(URL_RE.test('HTTP://x'))
  assert.ok(URL_RE.test('https://x'))
  assert.ok(!URL_RE.test('ftp://x'))
  assert.ok(!URL_RE.test('x'))
})
