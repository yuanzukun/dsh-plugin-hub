# dsh-calm

[![DSH Market](https://raw.githubusercontent.com/2BingLing/dsh-market/master/assets/readme/badge-top-rated.svg)](https://dsh.market/)

> DeepSeek Harness 插件：**情绪检查点与修复（Emotional Checkpoint & Repair）**。
> 用户骂街时不硬抗、也不装没事——进入安抚模式修复关系；用户愿意继续时，
> 把争吵段落折叠封存、注入结论总结，回到干净上下文继续任务。
>
> 适配 DSH `>=0.2.0-rc.1`（开发者预览期，破坏性变更会跟进适配）。

## 工作流

1. **触发判定** —— `agent/pre-step`（请求派发前）拿到"尚未落库"的用户消息，做确定性分类：
   `abuse`（辱骂）/ `noise`（无实质噪音）/ `mixed`（骂中带任务）/ `substantive`（任务/继续信号）/ `distress`（求助信号，安全例外）。
2. **安抚模式** —— 同轮向消息批次注入一条 calm 注记（承接情绪、不辩解、确认真实意图）；
   同时 `tools.guard` 机械拦下写类/命令类工具（只读工具放行）。
3. **恢复（剪 + 总结）** —— 用户给出实质指令后：
   - 追加一条带 `surfaceOp: replace` 的总结消息（元数据记入 `source.calm`，含折叠范围与轮数），把争吵段从**模型可见面**剪掉；
   - **会话日志一行不删**（封存 = 日志保留 + 可见面遮蔽，和 compaction 同源机制）。
4. **终止（滚动窗口）** —— 安抚中连续 N 轮（默认 5，可配）无实质内容：
   折叠封存 + `pre-step` 返回 `{kind:'reject'}` 机械结束本次会话；用户新开会话可继续，文件与进度不受影响。
5. **访问策略** —— 模型可用 `open_sealed` 工具带理由调阅封存记录：
   默认**脱敏版**（掩掉辱骂内容、保留事实）；原文需 `allowRawSealedRead: true`；
   每次调阅留痕（`subtype: read`）。模型也可用 `end_conversation` 主动结束会话。
6. **跨重启** —— 进行中的安抚状态由日志（`subtype: soothe` 的 calm 消息）自动重建，进程重启不失忆。

## 安装

**GitHub 直装（推荐，国内网络可直连，无需 npm 账号）**：

```sh
dsh plugin --profile web add 'https://codeload.github.com/wobenshiwomu/dsh-calm/tar.gz/v0.1.0'
```

或在图形界面：侧栏「插件」→ 添加插件 → 填上面这条 URL。装完重启 DSH 生效。
URL 末段的 `v0.1.0` 是版本标签；升级时换成本仓库的新版本标签重装即可。

**npm 渠道（尚未上架）**：上架后即可 `dsh plugin --profile web add dsh-calm`。

**本地源码挂载**（开发用，改代码即热重载）：

在 profile 的用户层 `~/.dsh/profiles/<名>/cordis.patch.yml` 里按**绝对路径**挂载插件入口：

```yaml
- insert:
    - id: dsh-calm
      name: '/绝对路径/到/dsh-calm/src/index.mjs'
      config: { window: 5, enableTermination: true, allowRawSealedRead: false }
```

保存后重启 DSH 生效；也可把这段 YAML 存为独立文件，用 `dsh web --patch ./该文件.yml` 启动测试实例。

## 配置

| 键 | 默认 | 说明 |
|---|---|---|
| `window` | `5` | 滚动窗口：安抚中连续多少轮无实质内容后结束会话 |
| `enableTermination` | `true` | 是否启用"救不动就结束" |
| `denyPattern` | `bash\|shell\|pwsh\|write\|edit\|...` | 安抚模式下被临时拦下的工具名正则 |
| `allowRawSealedRead` | `false` | 是否允许模型直接读取封存原文 |

## 审计记录（都在会话日志里，导出即可复盘）

审计元数据存放在 calm 消息的 `source.calm` 字段。不引入自定义事件类型的原因：DSH 读取器只接受已知事件类型或带 `ignorable` 标记的记录，而当前版本 `session.append()` 未向插件开放该标记，自定义类型会让会话日志变得不可读；`user/message.source` 是浅校验、原样保留的天然审计位。

- `subtype: soothe` —— 进入安抚模式（checkpoint、时间、是否含求助信号）
- `subtype: sealed` —— 折叠封存（模式 resolved、折叠范围 shadowedSeqs、轮数）
- `subtype: terminated` —— 会话终止（原因、未被采纳的结尾文本）
- `subtype: read` —— 模型调阅封存记录（id、理由、是否请求原文）
- `subtype: reminder` —— 结束后的低频提醒

## 已知边界

- 总结目前是**启发式摘录**（回收争吵段里非辱骂的用户陈述 + 状态说明）；接 LLM 总结是预留的升级点。
- 折叠区间遵守 dsh-session 的"受保护头"契约（不会覆盖系统提示首节点）；折叠若被拒绝会**退化为普通追加**（审计记录优先落库，避免状态重建把会话锁进安抚模式）。
- 会话"无前情"（一开口就是骂）时恢复，总结会如实说明没有可回收的任务上下文，模型不会凭空假设旧任务。
- **KV/前缀缓存**：依赖框架与供应商的前缀缓存自动命中，插件不需要也不应该手动管理 KV；回退后仅被剪段失效。
- 不负责**文件状态回滚**：建议搭配 `dsh-rewind`（用户手动后悔药）使用。
- 判定为规则分类器（确定性裁判）；升级小模型分类器时只需替换 `classify()`。

## 测试

```sh
npm install   # 首次：安装测试所需的宿主依赖（@deepseek-ai/dsh-llm 等）
npm test      # 仿真测试：分类/安抚/滚动窗口/剪+总结/闸门/封存策略/跨重启（53 项断言）
```
