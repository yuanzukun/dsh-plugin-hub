<div align="center">

# Command Code quota for DeepSeek Harness

**Your 5-hour, weekly and monthly credit windows, in the sidebar — right above Settings.**

No browser tab, no login, no guessing how much of the plan is left.

[![Check](https://github.com/Jovan1666/dsh-commandcode-quota/actions/workflows/check.yml/badge.svg)](https://github.com/Jovan1666/dsh-commandcode-quota/actions/workflows/check.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![DeepSeek Harness](https://img.shields.io/badge/DeepSeek%20Harness-plugin-4D6BFE)](https://github.com/deepseek-ai/deepseek-harness)
[![dsh](https://img.shields.io/badge/dsh-%3E%3D0.1.5--rc.1-blue)](#requirements)
[![PRs welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](#contributing)

<img src="assets/screenshot.png" alt="The quota card in the sidebar: light rail, light expanded, dark expanded" width="820">

</div>

---

## What you get

| | |
|---|---|
| **Three windows, one glance** | 5-hour, weekly and monthly, shortest first — so the tightest limit is where your eye lands |
| **Percentage first** | The headline rounds to a whole percent, exactly like the Command Code dashboard, so the card and the website never disagree |
| **Money where it matters** | Used and remaining for the monthly allowance; exact figures for every row on hover |
| **Instant, then live** | The card is on screen about 2 ms after a restart, and live about a second later |
| **Quiet when it should be** | No Command Code account? The card does not render at all — and if you just want the sidebar to yourself, switch it off from Settings |
| **Bilingual** | The card follows your DSH interface language (中文 / English) |
| **Per-model allowances** | What this plan gives each model, in Settings — the models you configured first |

Everything is read from **your own account's data** — window count, caps and percentages come from the API, never assumed. GOAT, Pro, Provider, Max and Teams work; a plan that reports no rolling windows simply renders no rows. (The $1 **Go** tier is the exception — it has no API access, so the card has nothing to render there.)

## Check your dsh version first

**This plugin needs dsh `0.1.5-rc.1` or newer — `>=0.1.5-rc.1`, not `^0.1.5-rc.1`.** The caret is the trap: under semver `^0.1.5` means `>=0.1.5 <0.2.0`, so it would read as *excluding* the 0.2.x line this plugin is running on today. Verified against **`0.2.1-rc.3`** (the current desktop nightly, 2026-10-26); on anything older than 0.1.5-rc.1 it crashes at startup:

```
Error: failed to apply loader entry commandcode-quota:
Cannot read properties of undefined (reading 'register')
```

The `ctx.connection.fetch` seam it relies on does not exist in older releases. Check before you install:

```sh
dsh --version          # needs 0.1.5-rc.1 or newer; 0.2.1-rc.3 is what this was verified on
npm i -g @deepseek-ai/dsh@latest
```

The desktop client does not put `dsh` on your `PATH`; its version is in the app's own About/Settings panel, and the nightly channel currently publishes `0.2.1-rc.3`. The npm package trails it slightly (`0.2.1-rc.2` at the time of writing), so `npm i -g …@latest` and the desktop installer can legitimately show different last digits — both satisfy the requirement above.

Note that the plugin's offline checks also **pass** on an older dsh — they never start dsh. So "the checks are green" does not mean it will work once installed, and the same is true of this README's prose: the numbers in it were read from the version above, not from yours. `node scripts/check.mjs` prints how many checks it actually ran.

## Install

```sh
dsh plugin --profile web add github:Jovan1666/dsh-commandcode-quota
```

Then restart `dsh web` and reload the browser page. That is the whole setup — no configuration file, no API key to paste: if Command Code is already a provider in your DSH settings, the plugin finds it.

The package declares a bundle patch (`dsh.bundle.patch` → its `cordis.patch.yml`), so `dsh plugin add` registers the plugin row for you. **Do not also append that row to your profile's `cordis.patch.yml`.** Two layers inserting the same loader id make dsh refuse to start: `duplicate loader entry id: commandcode-quota`. The row belongs to the manual install below, where no bundle layer exists.

<details>
<summary>Other ways to install, and how to remove it</summary>

**From a local clone**

```sh
git clone https://github.com/Jovan1666/dsh-commandcode-quota
dsh plugin --profile web add ./dsh-commandcode-quota
```

**Manually, without pnpm** — link the folder into the profile's `node_modules`, then register the row yourself, since nothing else will:

```yaml
# $DSH_HOME/profiles/web/cordis.patch.yml
- insert:
    - id: commandcode-quota
      name: "dsh-commandcode-quota"
```

A freshly created profile ends that file with `[]`. **Replace the `[]`** — appending a sequence under it is not valid YAML, and the profile will not load.

```sh
# macOS / Linux  ($DSH_HOME defaults to $HOME/.dsh)
ln -s "$PWD/dsh-commandcode-quota" "${DSH_HOME:-$HOME/.dsh}/profiles/web/node_modules/dsh-commandcode-quota"
```

```powershell
# Windows  ($env:DSH_HOME defaults to $env:USERPROFILE\.dsh)
$dsh = if ($env:DSH_HOME) { $env:DSH_HOME } else { "$env:USERPROFILE\.dsh" }
New-Item -ItemType Junction -Path "$dsh\profiles\web\node_modules\dsh-commandcode-quota" -Target "$PWD\dsh-commandcode-quota"
```

**To remove it:** `dsh plugin --profile web remove dsh-commandcode-quota` drops the package and the bundle layer that registers it; a manual install instead deletes the `cordis.patch.yml` row. Restart `dsh web` either way. To clear the cached snapshot too, delete `$DSH_HOME/dsh-commandcode-quota/`.

</details>

### Desktop client

The Electron desktop client owns its profile: `dsh --profile desktop …` refuses to run with `profile "desktop" is managed exclusively by the Electron application`, so the `dsh plugin` route is unavailable there and the wiring has to be done by hand. There are two shapes, and **the app's own profile uses the first one**:

**Declared in the profile (no loader row).** Add the package to `$dsh\profiles\desktop\package.json` — a `link:` dependency plus the name in the profile's bundle list — and let the package's own bundle patch register it:

```jsonc
{
  "dependencies": {
    "dsh-commandcode-quota": "link:C:/path/to/dsh-commandcode-quota"
  },
  "dsh": {
    "profile": {
      "bundles": [
        "@deepseek-ai/dsh-base",
        "@deepseek-ai/dsh-web-app",
        "dsh-commandcode-quota"          // ← the registration comes from here
      ]
    }
  }
}
```

Make sure the folder reaches `node_modules` as well — the profile resolves the `link:` through it:

```powershell
$dsh = if ($env:DSH_HOME) { $env:DSH_HOME } else { "$env:USERPROFILE\.dsh" }
New-Item -ItemType Directory -Force -Path "$dsh\profiles\desktop\node_modules" | Out-Null
New-Item -ItemType Junction `
  -Path "$dsh\profiles\desktop\node_modules\dsh-commandcode-quota" `
  -Target "C:\path\to\dsh-commandcode-quota"
```

Restart the desktop app. **Do not add an `insert` row as well** — the bundle layer already registers the loader id, and a second one is the `duplicate loader entry id: commandcode-quota` failure described above.

**Manually, with a loader row** — only when the package is *not* in the profile's `bundles` list. Then nothing else will register it, so the row is required:

```yaml
# $dsh\profiles\desktop\cordis.patch.yml
- insert:
    - id: commandcode-quota
      name: "dsh-commandcode-quota"
```

Restart the desktop app. If the plugin does not appear, check the row is there exactly once and that the junction above exists — those are the only two things the loader needs.

> Keep whatever you add to that file **ASCII-only**. The app regenerates the profile on its own: an `insert` entry added by hand survives, but a non-ASCII comment on it comes back mangled.

## Why it appears before you look

The card used to wait out a full upstream round trip before drawing anything, and a restarted dsh has nothing cached — which is exactly the "it takes a moment to show up" feeling. Measured against the live API with `node preview/latency.mjs`:

| | |
|---|---|
| First answer after a restart, snapshot on disk | **~2 ms** |
| First answer after a restart, no snapshot yet | ~1.4 s |
| The four endpoints requested one after another | ~2.3 s |
| The four endpoints requested together | ~1.2 s |

Two things make the difference:

1. **All four endpoints are requested at once.** `whoami` used to be awaited on its own — about 590 ms of pure waiting, to learn an org id that personal accounts never report.
2. **The last good report is kept on disk.** A cold start answers with it immediately — dimmed, and labelled with how old it is — while a live read runs behind it. The card re-asks 3 seconds later instead of waiting out the usual minute, so the numbers are live by the time you have read them.

## How to read the card

| Window | What it means | On GOAT |
|---|---|---|
| **5-hour** | Rolling burst limit — one long session cannot drain the month | `$14` |
| **Weekly** | Rolling 7-day limit | `$35` |
| **Monthly** | The billing period's credit allowance | `$70` |

Each row shows the **used percentage** (green below 60 %, amber below 85 %, red above), a meter in the same colour, and a **reset countdown**. The chip is only the duration, in the UI language, so it does not push the percentage out of a 200 px row: `59分` / `3时05分` / `6天9时` in Chinese, `59m` / `3h 05m` / `6d 9h` in English. “Resets in” and the clock time stay on the hover. Click the card for the monthly allowance in money, the remaining credit, the request count and the token totals. Collapse the sidebar and the card becomes a 36 px badge showing which window is **most constrained**, and that window’s percentage.

### Reading the numbers

- Percentages are `used ÷ (used + remaining)`, read live from the API. `preview/e2e-live.mjs` asserts that identity against a real account on demand.
- The headline rounds to a whole percent, the same way the dashboard does. That is why the website can say `100%` while the exact share is `99.84%` — same data, two roundings. The exact figure and the money are one hover away.
- The monthly cap is the sum of two figures from two different endpoints. Across a billing-period rollover or a plan change those two can describe different periods, and the sum would look plausible while being wrong by tens of percent. The plan's nominal allowance is the sanity check; when a read fails it, the host reports **no percentage at all** and the card says why. The next refresh corrects it.

### What the card deliberately leaves out

The sidebar is about 200 px of content width, and a laptop screen makes small type smaller still. So the card answers one question well — *how deep am I?* — instead of laying out everything the API returns:

- **Money only for the monthly allowance.** The 5-hour and weekly windows are pass/fail gates, not budgets; their dollar rows told a user nothing they could act on. Hover still shows exact figures.
- **No pace verdict, no burn-rate forecast.** "Over pace" cannot be acted on by someone who has work to do, and a projected exhaustion date assumes a constant burn rate that credit usage never has. The host still exposes `projection` in its JSON for scripts.
- **Nothing silent.** A row that disappears because its endpoint failed says so; a failure with nothing to fall back on says what went wrong in one readable line, with the full diagnostic text on hover.

## Per-model allowances, in Settings

The card answers *how deep am I*. **Settings → Quota & card** answers the other question: *what would this plan give me if I only ever called this model?* — and holds the switch that decides whether the card exists at all.

**Use another model and want the sidebar back?** The first panel in that section has a switch: **Show the quota card in the sidebar**. Turn it off and the card (and its collapsed rail badge) disappears from the bottom-left immediately — no reload, no restart — and the choice is remembered across restarts. Turn it back on whenever you want the numbers again. Nothing about the account changes; it is a display preference, stored in the plugin's own directory (`$DSH_HOME/dsh-commandcode-quota/settings.json`) and never sent anywhere.

Every model the plan can call, with requests per 5 hours, per week and per month — the models you configured in DSH first. Above the table sits the plan-level headline (`GOAT · $70 · ~75K requests`): a different figure on a different basis, labelled so the two are never read as one number.

The figures are the vendor's, not ours. Each plan page publishes a per-model monthly budget, that model's per-token rates and the request shape the estimate assumes; the page itself computes the counts in the browser. The plugin reproduces that arithmetic and rounds exactly like the site (`Number(x.toPrecision(3))`). `tests/catalog.test.mjs` pins the outcome against the numbers the vendor's own pages render — every model row of all four plan pages, plus the pricing page's availability and plan-level tables — and the offline baseline stores the inputs those rows were computed from, so the arithmetic can be re-checked without the network. (This paragraph used to quote a row count. It went stale twice, so it no longer quotes one: run `node scripts/verify.mjs` and read the `catalog` suite's own numbers instead.)

**It asks only when it has to.** The docs pages ignore conditional requests (the server hands out an ETag and then answers `200` to `If-None-Match` — there is no 304 branch to lean on), so the plugin does the check itself: `HEAD` for the page's ETag, 0 bytes, and only a real change downloads a body (about 200 KB, ~37 KB compressed). A check runs when you open the section and the local copy is over a day old, or when you press **Check for updates**; the sidebar card never triggers one. A baseline ships inside the plugin, so a first run — or a machine with no network — still shows figures, labelled *baseline, not synced yet*.

**Opening the section never waits for that check.** The section paints from local data immediately, the check runs behind the answer, and the page says *checking the official data in the background* until the fresh numbers land — which they do on their own, because the section comes back for the result instead of leaving you to press the button again. Measured with a simulated 300 ms round trip, serving the panel went from **1.6 s to 0.32 s**, and a card poll from **22 KB to 1.06 KB** (the catalog used to ride along on every answer; the card never reads it). The check's own HTTP is two round trips instead of four — both page probes go out together — and a check that finds nothing new costs two 0-byte probes. If a check leaves the local copy unchanged, the next one waits a few seconds (and a failed day-long check is not retried on every mount), so a panel left open cannot turn into a request loop.

Where the plan page lists no figure at all, the pricing page's own calculator fills it in: same allowance, same rates, and a request shape derived from the provider exactly the way the site derives it (those rows are tagged *derived*). A model the vendor gives away reads `Free`.

Nothing is guessed where the vendor is silent. A model neither page prices reads `—`, never `0`; a plan with no per-model page of its own says so instead of borrowing another tier's numbers (Ultra is shown from Max's table and labelled an inference); a failed check keeps the previous figures and prints how old they are.

## The `/quota` command

Type `/quota` in a conversation to print the same report as text:

```text
Command Code · GOAT (active)
5-hour 1.4% used · resets in 3h17m
Weekly 12.8% used · resets in 6d7h
Monthly 99.8% used · $70.11 / $70.23 · $0.11 left · resets in 7d22h
5,000 requests · 100% success · in 210.0M / out 4.20M
```

It reads the same cached report the card does, so a slash invocation costs no extra upstream requests — and unlike the card, it never answers from a stale snapshot: typing a command means asking for the current numbers. Its text is English; the card is the bilingual surface.

## Requirements

- **DeepSeek Harness** `>=0.1.5-rc.1` — verified on `0.2.1-rc.3`. The plugin uses framework seams that are not a stable public API yet; see [Compatibility](#compatibility).
- The **web** profile. The card mounts into the browser sidebar through the `connection` service, which only the web app composes — a headless or CLI profile has nowhere to put it.
- A **Command Code** account with API access. Every plan except the `$1` **Go** tier includes it; see [Getting a Command Code plan](#getting-a-command-code-plan).
- Node.js 18+ — only for the optional CLI and the development scripts.

## Getting a Command Code plan

The card reads any Command Code plan that has API access. This plugin was built against **GOAT**: `$10/month`, which buys `$70` of credits, gated at `$14` per 5-hour window and `$35` per rolling week.

GOAT is the tier that suits an agent harness. Command Code's own estimate for **DeepSeek V4 Flash** on that allowance is **~154,000 requests a month** (~30,800 per 5-hour window, ~76,900 per week), because flash-tier models bill at roughly `$0.15` input / `$0.60` output per million tokens with cache reads at `$0.003`. A coding agent spends its budget on exactly those calls: many small turns, most of the context re-read from cache. Tens of thousands of tool-calling turns a month is ordinary work, and at that price the window caps and the monthly allowance are what run out — not the request count.

Two caveats on those numbers, both from the same page: the request counts assume a typical agent turn of ~800 fresh input tokens, ~50,000 cache-read tokens and 125–200 output tokens, so a run that carries a large repo context drains the allowance faster; and DeepSeek is billed by time of day, with peak hours priced higher (01:00–04:00 and 06:00–10:00 UTC, Mon–Fri). Command Code states that allowances can change at any time — [the pricing page](https://commandcode.ai/docs/resources/pricing-limits) is authoritative, and the figures above are what it said on 2026-09-19.

### Subscribing

1. Sign in at [commandcode.ai](https://commandcode.ai/) and open [Pricing](https://commandcode.ai/pricing), or Studio → Billing.
2. Choose **GOAT** and check out. Card payments run through Stripe; **Alipay is supported** on the USD-denominated plans and sets up automatic renewal, which is worth knowing before the first invoice. UnionPay is not listed.
3. In Studio, open **API keys → Generate**. The key looks like `user_…`, not `sk-…`.
4. Hand it to dsh. Settings → Models takes a provider interactively; by file, add a route to `$DSH_HOME/settings.yaml`:

   ```yaml
   llm-pi-ai:
     providers:
       command-code-goat:
         apiKeyEnv: COMMAND_CODE_GOAT_API_KEY
         api: openai-completions
         baseURL: https://api.commandcode.ai/provider/v1
         models:
           - id: deepseek/deepseek-v4.1-flash
             contextWindow: 1000000
             input: ["text", "image"]
   ```

   Keep the key itself out of the file: put it in the environment, or in `$DSH_HOME/.credentials.yaml` under `refs.COMMAND_CODE_GOAT_API_KEY`. Nothing else is needed — [Credentials](#credentials) is how the card finds this same route, which is why installing the plugin never asks for a key.

### Before you subscribe

- **Go (`$1`) has no API access.** All four quota endpoints answer 404, which the plugin reports as "this plan has no API access" rather than as an error it can retry.
- **The 5-hour and weekly windows start at your first request**, not at a calendar boundary, and switching plans clears both of them. The card shows the reset times the API reports instead of computing them from a period start.
- **One account per person.** The terms forbid sharing, reselling, or rotating keys across accounts, and a violation puts every account involved at risk of a permanent ban.
- **Other tiers, same card.** `$20` **Pro** (`$80` of credits) is the same shape with more headroom and `$100` / `$200` **Max** scale it again. The `$15` **Provider** plan is metered API access with no rolling windows, so the card shows the balance and no window rows.

## Credentials

The API key never reaches the browser. The host resolves it in this order and reports which source won:

1. An explicitly passed key (the CLI's `--key`).
2. **Discovered from your own `$DSH_HOME/settings.yaml`** — any provider route whose `baseURL` points at `commandcode.ai`. The plugin reads that route's literal `apiKey` or its `apiKeyEnv`, then resolves the name through the environment and `$DSH_HOME/.credentials.yaml`. The provider's host is kept (a staging host or proxy works), but only its origin: the quota endpoints live at the host root, not under the provider's `/provider/v1` path.
3. Environment variables: `COMMANDCODE_API_KEY`, `COMMAND_CODE_API_KEY`, `CMD_API_KEY`, then **any** variable whose name contains `commandcode`.
4. Those same names inside `$DSH_HOME/.credentials.yaml` (`refs.<NAME>`).
5. `~/.commandcode/auth.json`, the official `command-code` CLI's login state.

Step 2 is what makes this work for other people: it follows **your** provider configuration instead of hardcoding one naming convention.

<details>
<summary><strong>How it works</strong> — endpoints, seams, and the one that bit us</summary>

```mermaid
flowchart LR
  A["Sidebar card<br/>(browser half)"] -->|"POST /api/cc-quota/report<br/>same origin, session cookie"| B["Host half<br/>(15 s cache + disk snapshot)"]
  B -->|"four read-only GETs, in parallel"| C["Command Code API<br/>/alpha/*"]
```

| Endpoint | Used for |
|---|---|
| `/alpha/whoami` | Account name, org id |
| `/alpha/usage/summary` | Credits used this period, requests, success rate, tokens |
| `/alpha/billing/credits` | Remaining credits, the 5-hour and weekly windows |
| `/alpha/billing/subscriptions` | Plan id, status, billing-period start and end |

Each endpoint degrades on its own: one failure is recorded in the report's `failures`, is shown on the card as a muted line, and the rest still render. All four failing raises one error with the most specific code — including "this plan has no API access" when all four answer 404.

</details>

## Compatibility

The plugin depends on framework seams that are not a stable public API yet. Each is pinned to what `dsh 0.2.1-rc.3` actually exposes — the current desktop nightly, re-checked on 2026-10-26; the same seams were first verified against `0.1.5-rc.1`, and none of them moved in between:

| Seam | Used for |
|---|---|
| `sidebar.footer.action` slot | The seat above Settings, in both sidebar widths |
| `ctx.slots.register({ name, id, order, inject }, Component)` | Contributing the card |
| `ctx.connection.rpc.call(channel, endpoint, payload, signal)` | The browser side of the request |
| `ctx.connection.fetch.register({ path, methods, requestBody, fetch })` | The host side of the route |
| `ctx.get('commands')` + `commands.register({ name, description, handler })` | The optional `/quota` command |
| `dsh.client` manifest + `exports["./client"]` | Client-bundle discovery, served at `/plugins/<id>/client.js` |

> **Why an exact Fetch route instead of `connection.rpc.handle`?** `rpc.handle` mounts its channel through `owner.webServer`, where `owner` is the Connection service's own context — which never injects `webServer`. Calling it from any other plugin throws `cannot get property "webServer" without inject`, whatever the caller injects. `connection.fetch.register` only writes the route table, works from any plugin fiber, and inherits the shared `/api` transport's Host/Origin fence and browser-session cookie. (First observed on 0.1.5-rc.1; the same `owner.webServer.register(route)` mount is still in `dsh-client-connection` on 0.2.1-rc.3, so the exact route is still the only one that works.)

If a future dsh release changes one of these, the plugin fails loudly at load rather than silently rendering nothing.

## Standalone CLI

The same data layer ships as a zero-dependency read-only CLI — useful on a headless machine, or for checking a second account:

```sh
node cli/cli.mjs              # render once
node cli/cli.mjs --watch 60   # refresh every 60 seconds
node cli/cli.mjs --json       # normalized report for scripts
node cli/cli.mjs --help
```

```text
Command Code · GOAT（individual-goat） · Jovan1666
key: $DSH_HOME/.credentials.yaml → refs.COMMAND_CODE_GOAT_API_KEY

5 小时     ---------------------------- 1.4%
           今天 21:55 重置（2 小时 4 分后）

每周       ####------------------------ 12.8%
           09-24 01:51 重置（6 天 6 小时后）

月度额度   ############################ 99.8% · $70.11 / $70.23
           剩余 $0.11 · 09-25 17:08 重置（7 天 21 小时后）
本周期  5,000 请求 · 成功率 100% · in 210.0M / out 4.20M tokens
```

Shown with `--ascii`, and deliberately so: the default bars are drawn with full-height block glyphs, which sit flush against the text line beside them in many code fonts — in this very README the weekly bar merged with the 5-hour countdown above it. `#` and `-` are ordinary glyphs and travel everywhere. There are also no rule lines and no right-aligned columns, so every line stands on its own instead of depending on character-cell widths.

Flags: `--json`, `--watch [seconds]`, `--ascii`, `--color` / `--no-color`, `--base <url>`, `--timeout <ms>` (default 30 s; `COMMANDCODE_QUOTA_TIMEOUT_MS` overrides it), `--key <key>`.

The CLI's human-readable output is Chinese; `--json` is language-neutral and is the interface to script against. It follows the card's presentation rules — money on the monthly allowance only, no pace verdict and no burn-rate forecast (those remain in the JSON).

## Troubleshooting

| Symptom | What it means |
|---|---|
| No card at all | This host has no Command Code provider configured, so the plugin stays invisible by design. Check Settings → Models. |
| The settings section says *baseline, not synced yet* | Nothing has been fetched on this machine yet — a fresh install, an offline host, or a check that has not run. Press **Check for updates**; what you are reading is the copy shipped with the plugin, dated by its check time. |
| **Check for updates** returns instantly and nothing changes | That is the good case: the 0-byte `HEAD` found the page's ETag unchanged, so no body was downloaded. The status line shows when the last check happened. |
| The card shows an error | The card says what it can ("cannot reach Command Code", "the API key was rejected"); hover it for the full diagnostic text. |
| A line under the rows saying **N reading(s) unavailable** (`3 项数据这次没取到`) | N of the four upstream readings did not count this time. Each endpoint gets 30 s (`COMMANDCODE_QUOTA_TIMEOUT_MS` moves that, in ms, 1 s–120 s); past it the reading is dropped rather than shown, and the usual cause is Command Code itself being slow — on 2026-09-30 its own `server-timing` header reported 14 s for `/alpha/usage/summary` while `/alpha/billing/credits` answered in 43 ms. Hover the card to see which endpoint failed; the next poll retries on its own. A missing monthly row on the same card is the same cause, one endpoint over. |
| `/plugins/dsh-commandcode-quota/client.js` returns 404 | The client bundle was not composed. Check that `package.json` declares `dsh.client.platform === "web"` and `exports["./client"]`. On the desktop client this probe proves nothing: even a built-in bundle such as `dsh-client-ui-sidebar` returns 404 there, because the desktop renderer does not fetch its bundles from that HTTP server. |
| A change to `client.js` did nothing | Reload the page — the bundle is read from disk per request. Changes to `index.js` or `quota.mjs` need a `dsh web` restart (Node caches modules). |
| Numbers are dimmed | The host answered with its last snapshot, or a refresh failed. The age is printed underneath, and it corrects itself on the next refresh. |
| Everything reads `—` | The account reported no windows for that plan, or a read is still in flight. |
| The panel is empty after removing Command Code | Intended — the plugin does not show a snapshot for a provider you no longer have. |

## Privacy

- Your API key stays on the host. The browser never receives it; it only receives the normalized report over the same-origin `/api` transport, which is fenced to loopback and requires this process's browser-session cookie.
- The plugin talks only to your Command Code account's API. No telemetry, no analytics, no third-party endpoints.
- The only local file written is the last-report snapshot at `$DSH_HOME/dsh-commandcode-quota/last-report.json`. It holds the figures the card shows — never the key, and only a short digest of the key, used to check that the snapshot belongs to the account currently configured. Delete it any time; the plugin recreates it.
- Apart from that snapshot, every refresh is a live read of four read-only endpoints.

## Development

```sh
# 1. React is needed only by the component test and the preview page
mkdir .devdeps && cd .devdeps && npm init -y && npm install react@18 react-dom@18 && cd ..

# 2. Everything at once — one verdict, no network, no real credentials
node scripts/check.mjs            # release check: static + secret scan + every suite below
node scripts/verify.mjs           # add --live to also hit a real account
node scripts/verify.mjs --quiet   # one summary line per suite
```

It prints one line per suite — the suite's name, its check count, and the milliseconds it took — then a total, and exits non-zero if any suite failed. The counts are deliberately not reproduced here: they grow with every behaviour that gets a check, and a copied block of them is stale the moment somebody adds one.

| Script | What it does |
|---|---|
| `node scripts/check.mjs` | The release check: every JSON file parses, every `.js`/`.mjs` passes `node --check`, no credential or machine-specific path is committed, then every suite below |
| `node scripts/verify.mjs` | Every suite, one exit code. `--live` adds two suites that read a real account |
| `node scripts/audit.mjs` | Scans for credential-shaped or machine-specific content before committing |
| `node preview/latency.mjs` | Where the first paint's time goes: per-endpoint timings and the cold-start contrast |
| `node preview/build.mjs` | Renders the real `client.js` into a mock sidebar (light/dark, collapsed/expanded; `--with-snapshot` adds the restart state) for a headless screenshot — no `dsh` restart needed |
| `node preview/e2e-live.mjs` | One live read: prints the `/quota` text and asserts `used + remaining = cap` |
| `node preview/e2e-watch.mjs 6 20` | Samples a live account six times and asserts the numbers stay consistent while they move |

Determinism is checked by repetition, not by reading the code: `for i in 1 2 3 4 5; do node scripts/verify.mjs --quiet; done` should print the same total every time.

## Known limitations

- **Polling, not push.** The panel refreshes every 60 seconds (15 seconds while a window is approaching its cap, and never once a window is spent), with a 15-second host cache on top. Credit changes can lag by up to a minute.
- **No per-model allowance breakdown.** Command Code allocates a per-model share of the monthly budget, but the `/alpha` endpoints do not expose that table, so the card reports the total only.
- **No history.** Every read is a live snapshot; nothing is stored except the one cached report.
- **Command Code only.** This does not replace DSH's own local token statistics (`$DSH_HOME/dsh-usage/`).
- **The catalog follows one plan at a time.** A check fetches the page for the plan you are on, plus the shared pricing page that maps plans to models and carries the plan-level estimate — not every tier's page. Switch plans and the next check picks the new one up.
- **Provider and Teams publish no per-model table.** Both show the plan-level figure only (Provider is metered, Teams publishes one number). Ultra has no page of its own; it is shown from Max's table and labelled as an inference.
- **The vendor's own latency is the read's deadline.** Healthy, all four endpoints answer in about a second; each gets 30 s before its reading is dropped, and `COMMANDCODE_QUOTA_TIMEOUT_MS` overrides that. A dropped reading is never filled in with an older number: the card says how many are missing and names them on hover.
- **Framework seams.** See [Compatibility](#compatibility) — a future dsh release will need a look.

## Contributing

Issues and pull requests are welcome. Before opening a PR, run `node scripts/check.mjs` — it should be green, and a new behaviour should come with a check that would have failed before it.

## License

MIT — see [LICENSE](LICENSE).

<div align="center">
<sub>中文说明见 <a href="README.zh-CN.md">README.zh-CN.md</a></sub>
</div>
