/**
 * Offline test for the credential and route discovery in `plugin/quota.mjs`.
 *
 * This is the "does it work for someone else" suite: every case builds a fresh
 * temp DSH home with its own settings and credential files, then asserts the
 * lookup follows *that* user's naming rather than ours.
 *
 * Run: node test-quota.mjs
 */

import assert from 'node:assert/strict'
import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const { DEFAULT_TIMEOUT_MS, TIMEOUT_ENV_NAME, resolveApiKey, discoverRoutes, resolveTimeoutMs, subscriptionPlanInfo } = await import(
  `../quota.mjs?t=${String(Date.now())}`
)

let passed = 0
const check = (label, fn) => {
  fn()
  passed += 1
  console.log(`  ok  ${label}`)
}

/** Build a throwaway DSH home. */
function makeHome({ settings, credentials } = {}) {
  const dir = mkdtempSync(path.join(os.tmpdir(), 'cc-quota-test-'))
  if (settings !== undefined) writeFileSync(path.join(dir, 'settings.yaml'), settings, 'utf8')
  if (credentials !== undefined) writeFileSync(path.join(dir, '.credentials.yaml'), credentials, 'utf8')
  return dir
}

/** An isolated `home` that never resolves a real user profile. */
const NO_HOME = path.join(os.tmpdir(), 'cc-quota-no-such-home')

const SETTINGS_ONE_ROUTE = `ui-onboarding:
  welcomeNoticeVersion: 2026-08-13.1
llm-pi-ai:
  providers:
    command-code-goat:
      displayName: 我的 Command Code
      apiKeyEnv: MY_CUSTOM_KEY
      api: openai-completions
      baseURL: https://api.commandcode.ai/provider/v1
      models:
        - id: deepseek/deepseek-v4-flash
          name: DeepSeek V4 Flash
agent-loop:
  maxParallelToolCalls: 1000
`

console.log('route discovery')
{
  check('finds a commandcode route and keeps its sibling fields', () => {
    const routes = discoverRoutes(SETTINGS_ONE_ROUTE)
    assert.equal(routes.length, 1)
    assert.equal(routes[0].baseURL, 'https://api.commandcode.ai/provider/v1')
    assert.equal(routes[0].keyRef, 'MY_CUSTOM_KEY')
    assert.equal(routes[0].apiKey, undefined)
    assert.deepEqual(routes[0].models, ['deepseek/deepseek-v4-flash'])
  })
  check('ignores routes pointing somewhere else', () => {
    const routes = discoverRoutes(`llm-pi-ai:
  providers:
    deepseek-official:
      apiKeyEnv: DEEPSEEK_API_KEY
      baseURL: https://api.deepseek.com
    cc:
      apiKeyEnv: CC_KEY
      baseURL: https://api.commandcode.ai
`)
    assert.equal(routes.length, 1)
    assert.equal(routes[0].keyRef, 'CC_KEY')
  })
  check('a nested models list does not end the block', () => {
    const routes = discoverRoutes(`llm-pi-ai:
  providers:
    cc:
      baseURL: https://api.commandcode.ai/provider/v1
      models:
        - id: a/b
          name: A
          apiKeyEnv: NOT_THIS_ONE
      apiKeyEnv: REAL_KEY
`)
    assert.equal(routes.length, 1)
    assert.equal(routes[0].keyRef, 'REAL_KEY')
    assert.deepEqual(routes[0].models, ['a/b'])
  })
  check('a sibling key between baseURL and models does not drop the models', () => {
    const routes = discoverRoutes(`llm-pi-ai:
  providers:
    cc:
      baseURL: https://api.commandcode.ai/provider/v1
      apiKeyEnv: MY_KEY
      models:
        - id: deepseek/deepseek-v4.1-flash
          name: Flash
`)
    assert.deepEqual(routes[0].models, ['deepseek/deepseek-v4.1-flash'])
    assert.equal(routes[0].keyRef, 'MY_KEY')
  })
  check('models listed before baseURL still count', () => {
    const routes = discoverRoutes(`llm-pi-ai:
  providers:
    cc:
      models:
        - id: deepseek/deepseek-v4.1-pro
      apiKeyEnv: MY_KEY
      baseURL: https://api.commandcode.ai/provider/v1
`)
    assert.deepEqual(routes[0].models, ['deepseek/deepseek-v4.1-pro'])
  })
  check('a later sibling route terminates the previous block', () => {
    const routes = discoverRoutes(`llm-pi-ai:
  providers:
    one:
      apiKeyEnv: FIRST
      baseURL: https://api.commandcode.ai
    two:
      apiKeyEnv: SECOND
      baseURL: https://api.commandcode.ai/provider/v1
`)
    assert.deepEqual(routes.map((route) => route.keyRef), ['FIRST', 'SECOND'])
  })
}

console.log('credential resolution follows the user config, not our naming')
{
  check('resolves the apiKeyEnv the user configured, from the credential store', () => {
    const home = makeHome({
      settings: SETTINGS_ONE_ROUTE,
      credentials: 'version: 1\nrefs:\n  MY_CUSTOM_KEY: user_from_store\n',
    })
    const hit = resolveApiKey({ env: {}, dshHome: home, home: NO_HOME })
    assert.equal(hit.key, 'user_from_store')
    assert.match(hit.source, /refs\.MY_CUSTOM_KEY/)
    // The provider baseURL carries a path, but `/alpha/*` lives at the host root.
    assert.equal(hit.apiBase, 'https://api.commandcode.ai')
    rmSync(home, { recursive: true, force: true })
  })
  check('keeps the host the user chose but drops its path', () => {
    const home = makeHome({
      settings: `llm-pi-ai:
  providers:
    cc:
      apiKeyEnv: STAGING_KEY
      baseURL: https://staging.commandcode.ai/provider/v1
`,
    })
    const hit = resolveApiKey({ env: { STAGING_KEY: 'user_staging' }, dshHome: home, home: NO_HOME })
    assert.equal(hit.apiBase, 'https://staging.commandcode.ai')
    rmSync(home, { recursive: true, force: true })
  })
  check('prefers the environment over the credential store for that same name', () => {
    const home = makeHome({
      settings: SETTINGS_ONE_ROUTE,
      credentials: 'version: 1\nrefs:\n  MY_CUSTOM_KEY: user_from_store\n',
    })
    const hit = resolveApiKey({ env: { MY_CUSTOM_KEY: 'user_from_env' }, dshHome: home, home: NO_HOME })
    assert.equal(hit.key, 'user_from_env')
    assert.match(hit.source, /环境变量 MY_CUSTOM_KEY/)
    rmSync(home, { recursive: true, force: true })
  })
  check('accepts a literal apiKey written into the provider row', () => {
    const home = makeHome({
      settings: `llm-pi-ai:
  providers:
    cc:
      apiKey: user_literal
      baseURL: https://api.commandcode.ai
`,
    })
    const hit = resolveApiKey({ env: {}, dshHome: home, home: NO_HOME })
    assert.equal(hit.key, 'user_literal')
    rmSync(home, { recursive: true, force: true })
  })
  check('a route for another host does not shadow the generic fallbacks', () => {
    const home = makeHome({
      settings: `llm-pi-ai:
  providers:
    deepseek-official:
      apiKeyEnv: DEEPSEEK_API_KEY
      baseURL: https://api.deepseek.com
`,
    })
    const hit = resolveApiKey({ env: { COMMANDCODE_API_KEY: 'demo-generic' }, dshHome: home, home: NO_HOME })
    assert.equal(hit.key, 'demo-generic')
    assert.equal(hit.apiBase, undefined, 'no discovered base when the route is not Command Code')
    rmSync(home, { recursive: true, force: true })
  })
  check('any environment variable named after Command Code is accepted', () => {
    const hit = resolveApiKey({ env: { SOMETHING_COMMANDCODE_TOKEN: 'demo-named' }, dshHome: NO_HOME, home: NO_HOME })
    assert.equal(hit.key, 'demo-named')
    assert.match(hit.source, /SOMETHING_COMMANDCODE_TOKEN/)
  })
  check('falls back to the official CLI login file', () => {
    const home = mkdtempSync(path.join(os.tmpdir(), 'cc-quota-test-'))
    mkdirSync(path.join(home, '.commandcode'), { recursive: true })
    writeFileSync(path.join(home, '.commandcode', 'auth.json'), JSON.stringify({ apiKey: 'demo-cli-login' }), 'utf8')
    const hit = resolveApiKey({ env: {}, dshHome: NO_HOME, home })
    assert.equal(hit.key, 'demo-cli-login')
    rmSync(home, { recursive: true, force: true })
  })
  check('nothing configured names the fix instead of failing silently', () => {
    assert.throws(
      () => resolveApiKey({ env: {}, dshHome: NO_HOME, home: NO_HOME }),
      (error) => error.code === 'MISSING_CREDENTIAL' && /provider/.test(error.message),
    )
  })
  check('an explicit key still wins over everything', () => {
    const home = makeHome({ settings: SETTINGS_ONE_ROUTE, credentials: 'version: 1\nrefs:\n  MY_CUSTOM_KEY: user_store\n' })
    const hit = resolveApiKey({ apiKey: 'demo-explicit', env: { MY_CUSTOM_KEY: 'user_env' }, dshHome: home, home: NO_HOME })
    assert.equal(hit.key, 'demo-explicit')
    rmSync(home, { recursive: true, force: true })
  })
}

console.log('a desktop (Electron) host keeps its config in a patch layer, not settings.yaml')
{
  // The desktop app migrates `settings.yaml` to `settings.yaml.imported` on first
  // run and writes user settings into the patch layers from then on. Reading only
  // `settings.yaml` made every desktop install answer `configured: false`, and the
  // card then stayed invisible with nothing in the UI to diagnose.
  const PATCH_ONE_ROUTE = `- id: llm-pi-ai
  name: "@deepseek-ai/dsh-llm-pi-ai"
  config:
    providers:
      command-code-goat:
        displayName: my command code
        apiKeyEnv: MY_CUSTOM_KEY
        api: openai-completions
        baseURL: https://api.commandcode.ai/provider/v1
        models:
          - id: deepseek/deepseek-v4-flash
            name: DeepSeek V4 Flash
- id: agent-default-model
  name: "@deepseek-ai/dsh-agent-default-model"
  config:
    provider: command-code-goat
`

  check('the patch shape yields the same route fields as settings.yaml', () => {
    const routes = discoverRoutes(PATCH_ONE_ROUTE)
    assert.equal(routes.length, 1)
    assert.equal(routes[0].baseURL, 'https://api.commandcode.ai/provider/v1')
    assert.equal(routes[0].keyRef, 'MY_CUSTOM_KEY')
  })
  check('discovers the route from profiles/<name>/cordis.patch.yml', () => {
    const home = makeHome({ credentials: 'version: 1\nrefs:\n  MY_CUSTOM_KEY: user_from_patch\n' })
    const dir = path.join(home, 'profiles', 'desktop')
    mkdirSync(dir, { recursive: true })
    writeFileSync(path.join(dir, 'cordis.patch.yml'), PATCH_ONE_ROUTE, 'utf8')
    const hit = resolveApiKey({ env: {}, dshHome: home, home: NO_HOME })
    assert.equal(hit.key, 'user_from_patch')
    // The route was found in the patch: without it the lookup would have fallen
    // through to the generic names and failed outright.
    assert.equal(hit.apiBase, 'https://api.commandcode.ai')
    assert.match(hit.source, /refs\.MY_CUSTOM_KEY/)
    rmSync(home, { recursive: true, force: true })
  })
  check('discovers the route from the home-level cordis.patch.yml', () => {
    const home = makeHome({ credentials: 'version: 1\nrefs:\n  MY_CUSTOM_KEY: user_from_home_patch\n' })
    writeFileSync(path.join(home, 'cordis.patch.yml'), PATCH_ONE_ROUTE, 'utf8')
    const hit = resolveApiKey({ env: {}, dshHome: home, home: NO_HOME })
    assert.equal(hit.key, 'user_from_home_patch')
    assert.equal(hit.apiBase, 'https://api.commandcode.ai')
    rmSync(home, { recursive: true, force: true })
  })
  check('settings.yaml still wins when both carry a route', () => {
    const home = makeHome({
      settings: SETTINGS_ONE_ROUTE,
      credentials: 'version: 1\nrefs:\n  MY_CUSTOM_KEY: user_from_settings\n  PATCH_KEY: user_from_patch\n',
    })
    const dir = path.join(home, 'profiles', 'desktop')
    mkdirSync(dir, { recursive: true })
    writeFileSync(path.join(dir, 'cordis.patch.yml'), PATCH_ONE_ROUTE.replace('MY_CUSTOM_KEY', 'PATCH_KEY'), 'utf8')
    const hit = resolveApiKey({ env: {}, dshHome: home, home: NO_HOME })
    assert.equal(hit.key, 'user_from_settings')
    rmSync(home, { recursive: true, force: true })
  })
}

console.log('how long a read may take')
{
  check('the default deadline leaves room for a slow vendor', () => {
    // 2026-09-30: the vendor's own `server-timing` self-reported `total;dur=14018.0`
    // for `/alpha/usage/summary` while `/alpha/billing/credits` answered in 43ms.
    // A deadline at or below that turned three slow-but-alive endpoints into lost
    // rows — the card's "3 项数据这次没取到".
    assert.ok(DEFAULT_TIMEOUT_MS >= 30_000, `the default deadline is ${DEFAULT_TIMEOUT_MS}ms`)
  })
  check('the environment can move the deadline within its bounds', () => {
    assert.equal(resolveTimeoutMs({ env: { [TIMEOUT_ENV_NAME]: '45000' } }), 45_000)
    assert.equal(resolveTimeoutMs({ env: { [TIMEOUT_ENV_NAME]: '1000' } }), 1_000)
    assert.equal(resolveTimeoutMs({ env: { [TIMEOUT_ENV_NAME]: '120000' } }), 120_000)
  })
  check('an explicit value wins over the environment', () => {
    assert.equal(resolveTimeoutMs({ timeoutMs: 5_000, env: { [TIMEOUT_ENV_NAME]: '45000' } }), 5_000)
  })
  check('a typo, an empty value or an out-of-range one falls back to the default', () => {
    for (const raw of ['', '   ', 'abc', 'NaN', 'Infinity', '0', '-5', '999', '120001']) {
      assert.equal(
        resolveTimeoutMs({ env: { [TIMEOUT_ENV_NAME]: raw } }),
        DEFAULT_TIMEOUT_MS,
        `raw=${JSON.stringify(raw)} was accepted`,
      )
    }
  })
  check('the deadline variable is never mistaken for an API key', () => {
    // The last-resort scan treats any environment name containing "commandcode" as
    // a key. This knob matches that pattern, and taken as a key it would send
    // "30000" to Command Code as a Bearer token.
    assert.throws(
      () => resolveApiKey({ env: { [TIMEOUT_ENV_NAME]: '30000' }, dshHome: NO_HOME, home: NO_HOME }),
      (error) => error.code === 'MISSING_CREDENTIAL',
    )
  })
  check('a real key still resolves alongside the deadline variable', () => {
    const hit = resolveApiKey({ env: { COMMANDCODE_API_KEY: 'demo-key', [TIMEOUT_ENV_NAME]: '30000' }, dshHome: NO_HOME, home: NO_HOME })
    assert.equal(hit.key, 'demo-key')
  })
}

console.log('plan table covers every published tier')
{
  check('resolves each shipped planId, longest prefix first', () => {
    assert.equal(subscriptionPlanInfo('individual-go')?.name, 'Go')
    assert.equal(subscriptionPlanInfo('individual-goat')?.name, 'GOAT')
    assert.equal(subscriptionPlanInfo('individual-pro')?.name, 'Pro')
    assert.equal(subscriptionPlanInfo('individual-pro-v1')?.name, 'Pro')
    assert.equal(subscriptionPlanInfo('individual-pro-v1')?.monthlyCredits, 80)
    assert.equal(subscriptionPlanInfo('individual-provider')?.name, 'Provider')
    assert.equal(subscriptionPlanInfo('individual-max')?.name, 'Max')
    assert.equal(subscriptionPlanInfo('individual-ultra')?.name, 'Ultra')
    assert.equal(subscriptionPlanInfo('teams-pro')?.name, 'Teams Pro')
  })
  check('an unknown planId degrades to the raw id rather than guessing', () => {
    assert.equal(subscriptionPlanInfo('individual-something-new'), undefined)
  })
}

console.log('a credential reference that is not a variable name')
{
  // `apiKeyEnv` is interpolated into the credential-file pattern. A regex
  // metacharacter there would match the first unrelated row and hand *that*
  // provider's key to Command Code.
  const home = makeHome({
    settings: 'llm-pi-ai:\n  providers:\n    cc:\n      apiKeyEnv: .*\n      api: openai-completions\n      baseURL: https://api.commandcode.ai/provider/v1\n',
    credentials: 'refs:\n  OTHER_PROVIDER_KEY: sk-not-yours\n',
  })
  check('is refused rather than matching another provider key', () => {
    assert.throws(
      () => resolveApiKey({ env: {}, home, dshHome: home }),
      (error) => error.code === 'MISSING_CREDENTIAL' && /apiKeyEnv/.test(error.message),
    )
  })
  rmSync(home, { recursive: true, force: true })
}

console.log('a plan id the table does not carry')
{
  check('matches no entry, so it sets no allowance baseline', () => {
    // Prefix matching let `individual-pro-v2` inherit `individual-pro`'s 30 and
    // then veto its own percentage for the whole period.
    assert.equal(subscriptionPlanInfo('individual-pro-v2'), undefined)
    assert.equal(subscriptionPlanInfo('individual-goat')?.monthlyCredits, 70)
  })
}

console.log(`\n${passed} checks passed`)
