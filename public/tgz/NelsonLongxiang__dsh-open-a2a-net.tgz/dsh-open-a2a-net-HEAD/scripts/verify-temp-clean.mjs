#!/usr/bin/env node
/** Test lifecycle gate: run unchanged commands with an owned empty temp root; leaks fail before cleanup. */
import { mkdtempSync, readdirSync, rmSync, lstatSync, mkdirSync, existsSync, realpathSync } from 'node:fs'
import { join } from 'node:path'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'
const custom = process.argv.slice(2)
if (custom[0] === '--') custom.shift()
const external = custom.length > 0
const command = external ? custom.shift() : process.execPath
const args = external ? custom : process.env.npm_execpath ? [process.env.npm_execpath, 'run', 'verify:core'] : undefined
if (!args) throw Error('run with pnpm verify, or pass -- <executable> <arguments>')
// Resolve from this entrypoint, never an inherited/system-temp prefix or another checkout.
const repo = realpathSync(fileURLToPath(new URL('..', import.meta.url)))
const projectTmp = join(repo, 'tmp'), runs = join(projectTmp, 'test-runs')
for (const directory of [projectTmp, runs]) {
  if (existsSync(directory) && lstatSync(directory).isSymbolicLink()) throw Error('test temp parent must not be a link: ' + directory)
  mkdirSync(directory, { recursive: true })
}
const root = mkdtempSync(join(runs, 'run-'))
const yglHome = join(root, 'superagent-ygl'), dshHome = join(root, 'dsh-home')
let status = 1, signal = null, remaining = [], cleanupError, runnerError
try {
  const child = spawn(command, args, { stdio: 'inherit', env: { ...process.env, TMPDIR: root, TEMP: root, TMP: root, DSH_HOME: dshHome, A2A_TEST_YGL_HOME: yglHome, NODE_DISABLE_COMPILE_CACHE: '1' } })
  const settled = await new Promise((resolve, reject) => { child.once('error', reject); child.once('close', (code, sig) => resolve({ code, sig })) })
  status = settled.code ?? 1; signal = settled.sig
  // Only these exact runner-created home boundaries are intentional; never inherit a real host's state.
  // Arbitrary siblings still fail, and a substituted home never authorizes traversal of its target.
  for (const [home, label] of [[yglHome, 'ygl'], [dshHome, 'DSH']]) if (existsSync(home)) {
    if (lstatSync(home).isSymbolicLink()) throw Error('owned ' + label + ' home replaced by link')
    rmSync(home, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 })
  }
  remaining = readdirSync(root)
  if (remaining.length) {
    status = 1
    const inspect = (dir, depth = 0) => readdirSync(dir).flatMap(name => { const path = join(dir,name); return depth < 3 && lstatSync(path).isDirectory() && !lstatSync(path).isSymbolicLink() ? [{ path }, ...inspect(path,depth+1)] : [{ path }] })
    console.log('[temp-clean-residue] ' + JSON.stringify(inspect(root)))
  }
} catch (error) {
  status = 1; runnerError = String(error)
  console.error('[temp-clean-error] ' + runnerError)
} finally {
  // This gate owns this exact mkdtemp result, not old directories with matching prefixes.
  try { rmSync(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 }) }
  catch (error) { cleanupError = String(error); status = 1 }
  console.log('[temp-clean] ' + JSON.stringify({ root, remaining, entries: remaining.length, status, signal, ...(cleanupError ? { cleanupError } : {}), ...(runnerError ? { runnerError } : {}) }))
}
process.exitCode = status
