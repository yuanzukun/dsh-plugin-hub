# 发布纪律（release discipline）

> 2026-10-21 立，源自 K3 测试章前瞻（cordis 事故线收尾）：两项与「锁重生成 × 环境策略」
> 交互的坑，已实测咬人，故入档为纪律。

> 2026-11-10（#569）：预览版从 npm 回读、核对通过后，立即单独提交一次「记录已发布」：把该版本一节的标题改成「已发布到 npm 的 preview 标签」，并写上状态行（标签指向的提交、npm 发布时间、shasum、integrity、回读结果）。不要等到下一版发版时才顺手改。

## 0.8.1-preview.27（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-20）：标签 `v0.8.1-preview.27` 指向 0c4579c（发版 PR #750）。2026-11-20T05:11:57Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `68c0853a824c6750e8e658d6c7db7f492fc9dc42`，integrity `sha512-idegAfchHix8FJv8sfOwiQ5PmKEamgYw7aNOZmRFU2yQPchFmHt6uqoVo+Szw2DlX4nPxgrS0kGMNxFPqOB4Gg==`。从 npmjs 回读的包与审计过的包逐字节相同（sha256 `2badf0733309d4d669440f3a61c6b5b384c1e2649882dbb563a48393513380c5`）。GitHub Release 为 prerelease。未发布到 Gitea。

- 本版按属主 2026-11-19「Release without #709」准备。只发布到 npm 的 `preview` 标签，`latest` 保持 0.7.0；发版与节点安装/激活是两回事，本席不部署生产实例。
- 基线：master 合入 next/0.8 `a9cc84fa5e124c0a8f870642e1fd827c4995a422`（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.26 只有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md) 的「preview.27 补充」。本版改了 `originClaimWindow` 的默认值，把两个团队范围开关合成一个，并新增几处持久化；升级前先看下面「行为变化与升级注意」。

### 修复与改进

#### A2A 投递与回执

- **已写好的回执不会因投递失败而丢失（#708）**：
  - 会话写出的终态回执连同原投递 ID，先存进本机账本，再去投递。
  - 投递结果不明时，只按原传输查询对账；不新发一次 POST，不换 ID 重发，不重做原业务。
  - 投进 CLI 信箱的回执先写一条预写记录；写失败或重启后，只补完那一次结算，不再插入第二份。
  - 已经答复、但回执还没确认交付的任务，与「还没做完」的催办分开处理。接收会话空闲时收到一次 `[A2A receipt delivery blocked]` 提示，每条只发一次，不需要回执。
  - `a2a_tasks` 的行多出 `receiptRecovery`，取值为 `retained`、`blocked`、`legacy-unknown`、`corrupt`。旧版本留下的、没有保存回执原文的行显示 `legacy-unknown`，不会按摘要重造回执。
- **投递对应窗口满了能看到（#746、#747，#713 阶段 A）**：
  - 每台宿主保留的任务投递对应记录上限是 512 条、保留 24 小时。窗口满时的拒收文案不变，另带 `code: 'correspondence-capacity'`，拒收发生在任何入队之前。
  - `a2a_status` 新增一行 `Delivery correspondence`：已占用数与上限、任务占用数、已过期未清数、最早可能到期时间，窗口满时标 `FULL`。宿主状态面新增 `deliveryCapacity`。两处都只有计数，不含任务、会话或消息 ID。
  - 这个拒收从本机同步/异步投递、线上同步/异步响应、客户端解码，一直到多宿主汇总，全程以 `refusal` 字段带着（`notSent: true`）。提示写明这次什么都没发出、最早可能到期时间不保证有空位，也不要靠取消任务、换 ID 或改投别的席位腾位置。
  - 汇总多个候选宿主时，只有这是唯一一个失败才带 `refusal`；否则只给 `capacityRefusals` 计数。
- **`a2a_probe` 给出四值判定（#729）**：
  - 每个实际探测过的行新增 `verdict`，取值为 `reachable`、`slow`、`rejected`、`unreachable`。
  - 新增可选参数 `maxLatencyMs`，默认 2000，上限 60000。`slow` 表示对方应答了但超时，这种行仍是 `reachable: true`。
  - 被团队范围拒绝、没有实际探测的地址不给 `verdict`。
  - 同时关闭 #61、#63，各项最终结论写进协议文档。
- **同机画布队友可以按句柄互发（#741）**：出站范围检查以前只把远端画布成员映射成句柄，本机成员仍按会话 id 比对，所以同机两个画布队友按句柄互发会被拒，以前要靠共享名册才能通过。现在与入站准入一致，两种写法都认。
- **OriginClaim 关窗度量，重启后也不清零（#727，#64 第二步）**：
  - 三个计数 `legacy`、`unbound`、`boundMiss` 按 UTC 日写进 `<a2a home>/origin-claim-window.json`，保留 30 天。
  - 宿主状态面新增 `originClaimWindow { since, zeroStreakDays, days }`；`a2a-net status` 在 `claims` 下新增 `window` 行。
  - 宿主没运行的日子会中断连续天数，每次重启也都会中断。

#### superagent 团队

- **已批准、但没发出去的外发请求可以找回（#705）**：
  - 团队页把「核对原外发」「恢复原批准外发」与工单重派分开。两个操作只有浏览器属主能做，只接受原卡片和原 task，不能换目标、原文或发送身份。
  - 新提出的外发请求会保存原批准信息（批准时间、团队、原文）和每次发送尝试。恢复前重新核对：原批准、提议人、原目标与原文、工单仍开着、A2A 来源开着且没暂停。
  - 只有在任何转发之前就失败、能证明「没发出」的尝试，才允许再发。结果未知、记录缺失或已过期，都不算可以再发；账本里还有这条请求的行时也不再发。
  - 没有原批准信息的旧失败记录不能自动恢复。这类记录另有一条单次恢复通路：发送方属主先核账，接收方属主再确认，许可最长 1 小时、只能用一次，不建立长期链接或成员关系。
  - A2A 来源关着或暂停时，批准会在保存决定之前就被拒，原卡片保留，重新打开来源后可以再批。
- **排队的工单说明在等什么（#744）**：
  - 状态的 `executor.queued`、`superagent_read` 和 `a2a_ticket_read` 给出每张排队工单的原因：`member-busy`、`member-absent`、`no-repo-member`、`repo-busy`、`all-busy`、`at-cap`、`delivery-refused`、`launch-stalled`、`paused`。
  - 排队超过安静时限的工单进入健康检查，按成员或仓库合并成一条 `tickets-queued`，附数量和最早一张；团队页和右栏横幅同步显示。
  - `superagent_assign` 的说明改为：还没开工的工单随时可以改派给任何成员。行为本身没变。
- **投递途中结束的安静回合不再丢（#745，#742）**：成员的输入还在投递时结束回合，这个回合结束以前会被丢掉，`maxConcurrent=1` 时成员闲着却一直占着团队唯一的执行槽。现在投递完成后，若投递没失败、绑定没变、没有未送达的输入，并且那个回合确实已读到这次输入，就补结算这个回合；否则由输入唤醒的新回合自己结算。
- **普通成员可以提议新需求（#718，#717）**：`a2a_ticket_request` 加入成员工具，提议只进总工候选，接不接、派给谁仍由总工决定。提议不会结束、停止或改派提议人手上的工单；每个提议人最多 5 条未结。远端成员经已有的签名转发通道提议；Pi 席位不能提议。
- **总工能读文件，成员预设补上 goal 与 present（#736）**：
  - 总工的工具白名单加入 `read`、`glob`、`grep`、`skill`。预设补挂 `dsh-tool-fs-search`，去掉原来挂着却从来调不了的 bash、pwsh、jobs；写文件、编辑和执行命令仍然全部拒绝。
  - 成员和观察者预设补挂 `dsh-command-goal`、`dsh-tool-goal`、`dsh-tool-present`。
- **总工人设写进沟通渠道规则（#707）**：总工预设人设里直接写明普通 A2A 请求、同队远端成员、经批准的外发求助、已登记的子团队各走哪条路，不再依赖总工默认读不到的技能参考。三个角色的人设都追加了同一段说明：团队的 CLI 信箱只是已批准团队传输的实现，不能拿来绕开角色、批准或接收方准入。新增技能参考 `superagent-communication.md`。
- **ygl-trees 按已装版本出卡，各团队有自己的 kb scope（#739）**：
  - 宿主启动时读取 `ygl-trees --version`，结果放进团队状态的 `ygl`。0.123.0 起派单卡去掉 `project use` 一步；低于 0.123.0 或读不到版本时，卡片和以前逐字相同；低于 0.126.0 时记一条警告。
  - 0.126.0 起，团队的 kb scope 是 `bench:team-<画布名>`。成员写笔记时带上 scope，搜索时先搜本团队，再搜划分 scope 之前的旧笔记；旧笔记不迁移。
  - 团队项目已存在时不再重复执行 `project new`；成员和观察者人设去掉「没有合适的项目就自己建」。
- **两处启动和调度故障（#740）**：成员结束回合时，读作业列表不再因丢失接收对象而抛错，持有的等待中工单能正常挂起，下一张工单可以拿到执行槽。卡片缓存提前到恢复已加载会话的角色之前初始化，堵住 #617/#628 同类启动故障的另一个入口。
- **按宿主时钟计时（#721、#723）**：决策卡记录按宿主时钟修剪已决卡片（保留 30 天），`health()` 默认也用宿主时钟。生产里宿主时钟就是真实时间，行为不变；注入时钟的宿主和测试从此一致。
- **团队回执以本机账本为准（#741）**：每个请求在本机账本里都有 inbound 行。已确认或已结清的不再重发，重启后也一样；仍欠着的不管过了多久都补发，不再依赖 8 天期限。账本里没有这一行时，退回原来的内存记录和期限。
- **组队顾问可以请成员离开（#741）**：staffing 新增 `member.retire {team, seatId}`。只接受组队顾问的蓝图，默认需要确认，可以撤回；不动总工、远端成员和正在做工单的成员。market 来源仍然拒绝。

#### 工作台与画布

- **在板面上把多个团队组成 root 团队（#716、#734，#650）**：
  - 多选团队框后按 G 或点工具栏「建队」，依次执行：新建画布 → 设为 root → 加入总工 → 登记 superagent 团队 → 逐个加子团队。
  - 每一步都用服务端回读的状态核对；遇到拒绝、超时或「答应了但看不到效果」就停下，已完成的步骤保留，不回删、不整串重放，原因写在对话框和对应的框上。
  - 框菜单新增「加入 root「R」」，作为拖进 root 的键盘操作。子团队卡片的样式选择器改正，以前一直没有生效。
  - 服务端：画布 `create` 支持 `requireNew`，同名已存在时拒绝，回复新增 `created`。`/__dsh_a2a/state` 的 `canvas.teams[]` 新增 `superagentTeam`，`peerOrg[].org[]` 带上对端的 `superagentTeam` 和 `root` 标记，本机会话行新增 `preset`。
- **工作台加成员不再被轮询打断（#737）**：
  - 加入子菜单、成员表单的草稿、焦点和进行中状态，在状态轮询后都保留；重复点击只发一次请求。
  - 失败原因以文本显示在表单里；只有明确收到 `{ok:true}` 才算成功。
  - 不同主机上同名的会话不再被合成一行；提交前重新核对来源，来源已离网或变了就不发请求，请你重新选择。
  - 本机下拉框只列已入网的会话。新建团队对话框只建画布团队，不再提供名册选项。

#### 文档、测试与工具

- 文档：技能参考五份核对改正（#515、#520、#541、#546、#547），CLI 收件钩子示例（#728），12 份设计稿加实现核对说明（#730），修正指向已搬走文件的路径（#726），两处发布记录措辞更正（#743、#749），README 加 Superagent 原创示意插图（#704）。
- 测试与工具：测试不再留下临时目录（#712），补两组单测（#720、#738），验证采集器的溯源与归档绑定（#732），仓库目录规范与 `verify:layout`（#699）。

### 行为变化与升级注意

- **`originClaimWindow` 默认改为 `false`（#725，#64 第一步）**：不带 OriginClaim 信封的投递和日志请求现在以 `untrusted-origin` 拒收，与签名失败同一个码。配置里没写这个键也按关闭处理。需要临时放开就写 `originClaimWindow: true`，不用改代码。带签名的请求不受影响；`originClaimUnboundWindow` 不变，要等 #727 的度量在所有宿主上连续 7 天为零才关。
- **团队范围合成一个开关 `teamScope`（#741）**：
  - 路由和信息面的团队范围由同一个 `teamScope` 管，属主面板改动后两半同时生效，`whoami` 报告 `teamScope`。**在面板上关掉它，会同时放开路由**。
  - `teamScopeRouting`、`teamScopeInfo` 已弃用，只在没写 `teamScope` 时读，各管各的一半，现有配置的含义不变。其中任一个写成 `false` 而没有 `teamScope` 时，启动时记一条弃用警告。
  - 属主面板现在写 `teamScope`；home 层 `cordis.patch.yml` 里原有的 `teamScopeInfo` 行保留不动，但写了 `teamScope` 后就不再读它。控制接口仍接受旧字段 `teamScopeInfo`，按 `teamScope` 处理。
- **名册自入队退役（#741）**：删除工具 `a2a_team_join`、`a2a_team_leave`；看板只建画布团队；`roster-op` 拒绝 `create` 和 `add-member`，只保留缩减和解散。已有名册本版仍然认，名册数据、`teamJoinAllowlist` 和面板里的名单编辑计划在下一个版本删除。
- **删除的接口（#741）**：分组 `/__dsh_a2a/groups` 和会话的 group 字段删除（0.6.6 起已弃用）。superagent 控制接口删除三个只回一句提示的动作：`add-remote-member`、`remove-remote-member`、`serve-team`。`a2a_tool_request` 只给总工用，从成员工具中移除。
- **CLI `report` 改名 `tell-host`（#741）**：旧名本版仍可用，会提示已弃用。
- **JPFILE-PART 分件一律拒收（#733，#91）**：只要消息含 `[JPFILE-PART`，投递进会话之前就拒，返回 `-32008`，原因 `file-channel-required`，响应带 `advice.reason: use-file-channel`。被拒的分件不占发送方限流名额。原来的 `file-parts-exceeded`、`file-part-invalid`、`file-part-duplicate` 三个原因码删除。文件请改走文件通道。
- **线上响应新增 `refusal`（#747）**：投递对应窗口满时，异步响应、同步失败投影和汇总结果多出 `refusal` 或 `capacityRefusals` 字段。数值协议码不变（仍是 -32000 / -32004），重试和故障转移顺序不变。
- **账本新增回执保护（#708）**：
  - 账本 `tasks.json` 新增顶层字段 `receiptOutbox`、`dispatchReservations`；CLI 信箱 `cli-deposits.json` 新增 `receiptCommits`，现在改为原子写入、权限 0600。
  - 保存着回执原文的行不会被挤出欠账簿；欠账簿（64 行）被这类行和发出前预留的位置占满时，新工作以 `receipt-protected task capacity full; no new work admitted` 拒收。
  - CLI 信箱的回执预写记录最多 64 条，记满待处理记录时，回执投递以 `receipt mailbox journal capacity full` 拒收。
  - 存储损坏时拒绝自动重放回执（`RECEIPT_STORAGE_CORRUPT`），不按空处理。
- **外发恢复的持久化（#705）**：团队的 `outbound.json` 记录新增原批准信息和发送尝试；新增 `<a2a home>/request-recovery.json`（最多 128 条，旁边会有一个短时的 `.lock`）；幂等记录新增 `delivery: 'not-sent'` 和 `receiptDelivery` 证据字段。新增属主控制路由 `/__dsh_a2a/request-recovery`。用原 task 锚定的已批准发送，不会换成新 task 再悄悄路由；反向评审者的准入不再被当作外发授权。
- **团队预设变化（#707、#718、#736、#739）**：随包的 `cordis.patch.yml` 改了总工、成员、观察者的人设和挂载的插件，详见上文。

### 本版已披露限制

- 0.8.1-preview.26 一节列出的限制仍然适用。
- 不含 #709（按会话限制未消费的对账提醒）和 #748（成员和观察者默认 code 模式），两者仍未合入。
- #713 阶段 B（窗口确实满了以后怎么处理）仍待属主决定；本版只让满窗口看得见、拒收带类型，上限和保留时长没变。
- 只在项目测试里验证过、没有在真实宿主上验收的：#708 的回执保存与补送、#746/#747 的容量拒收（mesh 测试每台主机只有一个会话，本机异步那条分支只有单测覆盖）、#725/#727 的关窗与度量、#733 的分件拒收、#744/#745 的队列原因和回合结算、#718 的成员提议、#741 的整批改动、#729 的四值探测。#736 没有在真实 DSH 会话里确认 goal/present 出现在成员工具列表中。#716 的截图来自静态演示页，不是现场验收。#91 关单前还差一次跨主机的 `file send` / `file fetch` 现场验收。
- #705 的候选 `eb3f7dea` 在一次受控部署上完成过限定范围的原请求恢复验收；此后合入前又追加了提交，合入头本身没有再做现场验收。这不是全量、RC 或运维验收。
- #708 合入头的非作者结论是限定范围的代码复审 PASS，不是完整默认测试、RC 或运维验收；作者在早一些的候选上跑完整默认测试时仍有失败记录（24 个超时、1 个 Windows 权限断言）。Windows 上回执日志文件的权限读到的是 666 而不是 0600，隐私契约未定（#731）。
- 旧版本留下的、已答复但没保存回执原文的行不能自动补送，只能按原 task 人工核账。
- 没有原批准信息的旧外发失败记录不能自动恢复。

## 0.8.1-preview.26（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-17 记录）：标签 `v0.8.1-preview.26` 指向发布合并提交 `e28eba14fa4c472702be7c9e03734bc08f281a6d`（发版 PR #706，与评审头 `f0a3c60e` 同树 `1bb2dbff`）。2026-11-14T18:52:25Z 由开发席发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `3670596fa8be6391118204966214e77ac4266b06`，integrity `sha512-RId0pgdkRDILM7wzBkur2pJ8YPAiPh5CrE02x3Xd/eUOMBUNtCXmOTwfl8ku+qYJyiPc7SoiRe2K7Ot+vaia8Q==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。按 #569 本应发布后立即记录，本次延后到 11-17 补记。

- 本版按属主 2026-11-14「Yes, publish」准备。只发布到 npm 的 `preview` 标签，`latest` 保持 0.7.0；发版与节点安装/激活是两回事，本席不部署生产实例。
- 基线：master 合入 next/0.8 `a680279c24e468c253a64341bc6297f1a5811caa`（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.25 只有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。升级后只需重启，不用改配置。

### 修复与改进

- **能路由的协作者，目录里也看得到（#703）**：对端宿主自己的画布里，若某个会话与本机已入网的会话同组，`a2a_teams` 现在列出它并标 `[shared via <画布>]`，`a2a_status` 保留它的路由记录。只认该会话所在宿主自己的画布，比路由准入更严；只放宽信息面，路由准入不变。
- **范围拒绝说清缺哪一侧（#703）**：`a2a_probe` 被拒和 `a2a_teams` 隐藏条目时，提示刚重启的宿主可能还没读到对端名片，否则双方都没声明对方，并说明要由任一侧属主在工作台画布里把双方放进同一团队。
- **工作台「协作提示」（#703）**：宿主状态新增 `scopeHints`，列出对端画布里与本机会话同组、但本机尚未声明的远端会话；工作台工具栏「未入网」旁出现「协作提示(N)」，每条提供「加入本机「<画布>」」（以带密钥指纹的引用，走既有画布添加成员与校验）或「先让 <会话> 入网」。只是建议，每次点击都是属主自己的写入。

### 本版已披露限制

- 0.8.1-preview.25 一节列出的限制仍然适用。
- #703 的非作者评审是静态代码评审（精确头 PASS）；测试证据来自作者侧 gate。真实两宿主上的提示与一键加入还没验收。

## 0.8.1-preview.25（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-14）：标签 `v0.8.1-preview.25` 指向发布合并提交 `6ca847560f9bc90c17be64e9558f830a4abf5113`（发版 PR #702）；干净双构建候选 `0b3ffbb4560927d6150fd138b4412810d8ac316c` 与最终文件树相同。npmjs 发布时间 `2026-11-14T12:58:55.681Z`，`dist-tags.preview=0.8.1-preview.25`，`latest` 仍是 0.7.0。包为 375 文件／1,390,758 字节；shasum `251057c09af331db663ae54d16ba7a4eb9bd86b3`，SHA256 `caff9b4e8412a7307e1b4e1081745490e09fda8fa7cd6226f9751e7f6bd68768`，integrity `sha512-0Of8Ydd8uEZShdJIGl+3ABoyrmNmp7xs5ZPWPpL63+8Z0RBlJ6JSySTgCgKD47m4tlH2rWtp4JqQjHbfTGArtQ==`。公共 npm 下载回读与审计原始 tgz 逐字节一致；GitHub prerelease 附同一原包且服务端摘要相同。发布后元数据和 tgz 曾短暂返回 404，已等待至可见，未重复 publish。未发布到 Gitea，未安装或激活任何节点。

- 本版按属主 2026-11-14「继续合并发布新的预览版，我安排远程进行测试」指令准备。只发布到 npm 的 `preview` 标签，`latest` 保持 0.7.0；发版与节点安装/激活是两回事，本席不部署生产实例。
- 基线：master `e470262e6f97fd06eee7889a3f95ea6c26713865` 合入 next/0.8 `53463095d2f4a78e0283ceba982516b8340f4ab9`；后者已合入 owner-proof PR #691。发布合并提交、原始 tgz 和完整性信息在发版 PR 中钉定。
- 升级、回退及远程验收照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。真实远程浏览器验收由属主另行安排，不能把以下本机夹具检查当成远程通过。

### 修复与改进

- **域名／转发端口下浏览器主人误拒（#691）**：把原始请求交给 DSH Host Connection `admit`，只接受宿主浏览器主人 Peer；不再把 Cookie 重放到 loopback。Host/Origin 与 Cookie 验签仍由宿主负责；匿名、伪造、过期、错端口与 API 身份不替代浏览器主人。缺少该宿主能力时明确以 503 / `owner-auth-unavailable` 拒绝，不回退无登录放行。决策、决策附件、规则保存、GitHub 名单同步和编制操作共用这个门。
- **全量目录含不可达缓存行时的输出校验（#700）**：`a2a_teams` 声明 `unreachable` 字段，只投影已声明的公开字段，并显示 `[unreachable: last card]`。对端恢复后一次列表成功不能替代失联缓存行回归。
- **按任务冻结 intake 来源（#697）**：来源首次按任务保存 caller、团队、主机和 key；后续同句柄主机不能复活旧任务准入。Source 的 admission 查询携带并签入 task id，无任务、未知任务或出生链接已撤销时拒绝该 intake 复核。
- **CLI report 不接收回执正文（#701）**：拒绝把 `[A2A receipt]` 误发到 report 包装通道，提示使用正式 `receipt` 入口。本改动不清理或伪造已存在的旧账本行。

### 检查与已披露限制

- #691 集成头 `6b403aefb8aa44f356ad81a28b7dd827ff52d751`：类型/文档/构建/架构检查 rc=0；95 项专项通过；真实 DSH 0.2.2-rc.1 Host Connection 的本机 HTTP/HTTPS 两场景通过（证书校验开启，仅内存合成凭据），不是生产域名验收。
- 完整 Windows 工程门禁仍 rc=1（2534 通过 / 23 失败 / 8 跳过）；原失败集串行复跑后 230 通过 / 1 失败 / 1 跳过，另有 shadow 清理 EPERM。Windows 文件模式 0666 与 0600 断言、旧 Vitest ygl 临时残留未豁免；构建布局 3 项通过、nexus 410 项通过。发布树的构建及包检查另在发版 PR 留证，不能沿用源头数字冒称全量绿。
- 后续评审结论：`direct-2bffca4c` 已归档，非作者 `dsh/446ce672` 对 #691 精确头 `6b403aefb8aa44f356ad81a28b7dd827ff52d751`／tree `bb20b458f01427e3060ed6fdc058ae3b2a7d05bb` 给出增量静态代码评审 PASS，未发现新增阻断项。该结论在属主指令合并源 PR 后收到；不等于评审方跑过测试、发版候选或包独立复核，也不是 RC/spec-validator、远程浏览器或运维验收 PASS。原包内的候选时说明未回改、包未重建，本记录单独记后续事实。
- 生产团队配置下的热重载初始化异常尚未由此修复；远程激活前先安排一致性备份及可恢复方式。建议先用已确认不存在的 `diagnostic-nonexistent-<uuid>` 决策 ID 验证：原生域名登录有效后，决策接口返回 HTTP 200 / `stale` 表示通过鉴权且未确认真实卡片；无效凭据、外来来源仍须拒绝。

## 0.8.1-preview.24（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-14）：标签 `v0.8.1-preview.24` 指向 0b3b922（发版 PR #695）。2026-11-14T06:44:26Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `f89f50fce4ac476435f5380f92ecaa589dcdbd14`，integrity `sha512-PJb5aeo9synSjWjj9vT+5cZH03NnIqs8fosvIFOXh8sQMyfumKf7XfhnEN+/wgnkmh/VNzfZQh9Xkd3iLaofiA==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.23 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。升级后只需重启，不用改配置。

### 新功能

- **文件通道授权可列出、可撤回（#692）**：
  - 新工具 `a2a_file_grants {}` 列出本会话自己发出、仍有效的授权，以及暂存区占用和上限；`a2a_file_revoke { sha256, to }` 撤回其中一条。某个文件不再有任何授权时立即删除、腾出空间。
  - 只能撤自己发出的授权：撤别人的授权和撤不存在的授权，回答都是 `not-found`。
  - 授权上记下所属任务，以及对方取件的次数和首次取件时间；`a2a_file_send` 新增可选 `task_id`。
  - CLI：`a2a-net file grants [--json]`、`a2a-net file revoke <sha256> <to>`；请求须带与请求体绑定的 CLI 身份签名，未签名返回 403。
- **入站任务正文可读回（#693）**：
  - 投递给会话的任务原文在本机保存一份（单条最多 64 KiB，最多 512 条，保留 72 小时，文件权限 0600）。
  - 新工具 `a2a_task_read { task_id }`：接收会话可读回原文，读后账本记为已消费；其他会话读取时与查无此任务的回答相同。
  - 以插话方式投递、却一直没被会话读进去的任务，会在会话空闲时以原发送方身份补送一次；已经在宿主队列里的任务不补送。
- **Pi 席位一侧（pi platform PR-C，#688）**：
  - `a2a-net publish --pi-seat` 在身份自己签名的名片上声明 `piSeat`；`a2a-net ticket report|ack|handback|idle|read|error` 以该身份向主机报告工单进展。
  - `a2a-net pi install` 把随包附带的 Pi 扩展 `a2a-seat` 装进 `~/.pi/agent/extensions/`。扩展轮询席位邮箱，把团队派的活交给 Pi 会话，并回报已读、空闲和出错；加入团队仍由主人在画布上添加。
- **成员用席位令牌调用市场 MCP（#690）**：
  - 主机用节点密钥签名，按成员席位向市场换取一小时的令牌，只存在内存里，快到期时重新换取。
  - 市场的工具以 `team__<server>__<tool>` 作为成员工具，由主机以调用成员自己的席位令牌调用；属主手填的长期令牌已移除，换不到令牌时调用失败并说明原因，不会退回长期令牌。

### 本版已披露限制

- 0.8.1-preview.23 一节列出的限制仍然适用，但「Pi 席位暂时不能真正接单」一条由 #688 取代。
- Pi 扩展还没有在真实 Pi 运行时里验证过；主目录在另一台主机上的 Pi 席位仍不支持。
- 席位令牌需要市场第七阶段的换取接口；在市场一侧上线、并在市场登记本主机之前，团队 MCP 工具会报 `token-unavailable`。与真实市场接口的联调还没做。

## 0.8.1-preview.23（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-13）：标签 `v0.8.1-preview.23` 指向 3f5ab61（发版 PR #687）。2026-11-13T12:00:54Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `0872e7565582ffe4d5b659870f00b4e3edf2cd47`，integrity `sha512-srcHlqJLuiRECQhhXf7Nk6ty6WxqKAHSAELufELHHpH4yfYCR14S99XGIKc6Y9DBcLr91o4Cc86d2lT6Suj6pw==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.22 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。升级后只需重启，不用改配置。

### 新功能

- **Pi 席位可以成为团队成员（主机侧，pi platform PR-B，#685）**：
  - 自己签名的名片上声明了 `capabilities.piSeat`、并寄存在本机的 CLI 身份，可以加入团队画布；其他 CLI 身份仍按请求方拒绝，拒绝原因写明是本机没有寄存，还是没有 `piSeat` 声明。
  - 加入时钉住该席位寄存名片的公钥；再次加入不会替换已钉住的公钥，移除席位时一并忘掉。
  - 派单送进该席位的 CLI 邮箱；寄存过期或换了公钥，就按原有的「投递失败」处理。
  - 团队接口只认该席位钉住公钥签名、且与请求体绑定的 CLI 声明。Pi 席位不能代表主人发起规则变更；席位被移除后，在途工单的停止指令只按当初派单用的公钥投递，不会转到会话。

### 本版已披露限制

- 0.8.1-preview.22 一节列出的限制仍然适用。
- Pi 席位这一侧（CLI 的 `ticket` 子命令、扩展和 `pi install`）还没有发布：本版只有主机侧，Pi 席位暂时不能真正接单干活。
- 主目录在另一台主机上的 Pi 席位暂不支持。

## 0.8.1-preview.22（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-13）：标签 `v0.8.1-preview.22` 指向 bd44217（发版 PR #684）。2026-11-13T11:30:44Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `549e43fd760104cbc2ca71ff3417ae0302282294`，integrity `sha512-E0+2LO+zhkGjPwPBEA36G/yUWggZaTs0NYhX67iGAkfMgQy0OQ0IcuMsYpVRGJDz6DZGS1Exh5HAh4Q12Y19AQ==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.21 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。升级后只需重启，不用改配置。

### 修复

- **工作台左侧栏刷新后保持原样（#682）**：
  - 停在「团队」时刷新，等团队状态到达后回到「团队」，不再停在「目录」；数据模式下隐藏过的标签同样会回到原选择。
  - 「团队」角标计入所有团队待你处理的工单，以前只算当前显示的团队。
  - 还没发出的回答、追加和需求按团队和需求保存在本浏览器里，刷新后还在，发出后清掉。

### 本版已披露限制

- 0.8.1-preview.21 一节列出的限制仍然适用。
- 刷新后团队状态到达前（约一秒），侧栏先显示「目录」，随后回到「团队」。
- 草稿只保存在当前浏览器里，换浏览器或设备看不到。

## 0.8.1-preview.21（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-13）：标签 `v0.8.1-preview.21` 指向 5eb6e34（发版 PR #681）。2026-11-13T10:13:12Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `56e2c37db8780508ea0494dac3d72c01be5e2910`，integrity `sha512-dILVfQSBN59Kwh4WwOfydOv8yoxBaJlbNtvhG8+3HquarXjli+2upGJ6LZLwdvnsFOIbeRr7u5Xzae8clgfQZQ==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.20 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。升级后只需重启，不用改配置。

### 新功能

- **团队页需求的回执回到团队页（#677）**：在会话右栏「团队」页给其他实例的团队提需求，回执（确认、进度、提问、结果）显示在团队页的「发往其他实例的需求」里，不再作为新消息进入会话、唤醒模型。回执照常在账本里结清；本机结清检查拒掉的回执标「未核实」。
- **名单外发送方的需求等主人决定（M12，#678）**：发送方不在团队 A2A 名单上的需求，不再直接拒收，而是给接收方主人一张决策卡：
  - 「接这一单」：这一条作为明确需求进门，由总工重新判断；
  - 「接这一单，并把发送方加进名单」：同上，并把发送方加进 `bots.a2a`；
  - 「不接」：发送方收到拒收回执。

  等待期间发送方收到确认回执。限额：每个发送方同时一张、全队十张、消息不超过一天；其余照旧拒收。
- **画布卡片不再重叠（#679）**：在工作台画布上放下一张卡片时，它留在原处，被压住的卡片自动让到最近的空位，一次「撤销」两者一起还原；「整理成员」「一键重排」和首次加载也会把重叠的卡片分开。

### 修复

- 总工判断超时（引擎记为「不可用」）、且没有重新排队的 A2A 消息，过 30 分钟宽限后给发送方发 `failed` 回执，请对方重发；以前这类消息没有任何结局，发送方一直等（#680）。宽限期内主人仍可「重新判断」。

### 文档

- superagent pi platform 设计稿（#676）。

### 本版已披露限制

- 0.8.1-preview.20 一节列出的限制仍然适用。
- 对方在团队页回执里提的问题，目前只能在团队页看到，不能在那里回答。
- 名单外需求先挂卡、后被接下并开单时，发送方不会再收到「已接为工单」的确认；结果回执照常发送。

## 0.8.1-preview.20（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-13）：标签 `v0.8.1-preview.20` 指向 20ae116（发版 PR #674）。2026-11-13T04:38:17Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `57b4972cb0358e91dc90931e15bbacd4ca93c219`，integrity `sha512-xXSAKtmzct/ZLUZHlvk0vonDDWYxTLTl8p8Z/jD0MkxToXQjvbvNsZQbw07L1jOOkiGmH3bsXyzKg68d7lxGzA==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。
- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.19 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。升级后只需重启，不用改配置。

### 新功能

- **组队顾问蓝图（BS2，#670）**：组队顾问用 `superagent_blueprint_propose` 起草蓝图，即一批编制变更，并给出差异（每个规则集"现在 / 改为"）。
  - 主人在顾问会话里本人打字同意之后，`superagent_blueprint_apply` 才让宿主执行，而且这条消息要晚于蓝图。转达的、定时的、代输入的消息一律不算（#673）。
  - 改已有团队仍要等该团队的确认卡。
  - `superagent_blueprint_withdraw` 撤回尚未执行的蓝图。
  - 蓝图写入或撤销的每个规则集，历史里各留一行；起草后规则若被改过，整份蓝图拒绝执行；失败时倒序撤销。
  - 顾问先问清建队目标和仓库，再起草。

### 修复

- 编制变更写规则时，修订号只前进一次（#671，#672）。

### 本版已披露限制

- 0.8.1-preview.19 一节列出的限制仍然适用，但"组队顾问只能盘点和给建议"一条已由本版解决。

## 0.8.1-preview.19（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-13）：标签 `v0.8.1-preview.19` 指向 679de3a（发版 PR #668）。2026-11-13T02:32:14Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `73990d6338a0dc3ad4a53b77a77be2c93a4cf8b6`，integrity `sha512-NXLYtkyJn+TnuEGEvoWDg+pUOYZ6EA2ZTzzAzhqNNHdnJHsMZCAhA5lDMe/C2WJ17OgGO1ZB0FtdbDhDaDBgbw==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。
- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.18 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。升级后只需重启，不用改配置。

### 新功能

- **组队顾问（[设计](design/superagent-builder.md)，属主 11-13 批准）第一步：预设和只读盘点**（#667）。
  - 主人在新预设 `superagent-builder` 下建的会话就是组队顾问。它不在任何团队里，不接单也不派单。宿主只放行它盘点组织、读规则模板和读文件这几样工具。
  - `superagent_org_read` 给出团队、总工、成员（按席位）、角色和接单规则、根团队和子团队、空闲会话、编制账本。凭据、MCP、工具授权、白名单、GitHub 设置、命令路径一律不出现。
  - `superagent_rule_templates` 给出 8 套起步规则，都从测试宿主上实际跑过的团队提炼。
- **编制变更核心 S1a**（#666）：宿主执行编制变更，即建团队、加成员（可带档案）、改团队、派单或成员规则，走的是画布和团队路由原有的检查。
  - 有账本，同一变更按 id 去重。
  - 本机主人发起的变更须主人同意；改已有团队还要那个团队的确认卡。
  - 失败时倒序撤销；撤销也失败时标记为部分完成，并提 P1 卡。
  - 主人路由 `/__dsh_a2a/superagent/staffing` 须在已登录的界面里操作。
- **根团队画布看板**（#660）：可以把团队设为或取消根团队；子团队卡片显示在办数、名额和状态（含"待子团队登记""不可达"），名额可加减；画出根团队到子团队的派发连线。
- **团队健康**提示总工回合失败，比如模型额度用完（#656）。

### 修复

- 等待中的决策卡不再被"提需求"区域挡住，读失败也会显示出来，不再像"没有卡"（#657）。
- 子团队给另一台宿主上的根团队回执时，改用团队身份发送，跨宿主的结果能回到根票（#659）。
- 宿主重载时，晚到的 Web 服务回调在已停的上下文里放弃，不再让整个宿主退出（#662）。
- 凭据访问留痕补上团队身份私钥（cli.json）、宿主状态目录、profile 配置和 ygl 数据库（#663）。

### 文档

- 团队会话不再要求单独系统用户（属主 11-12 取消），团队 MCP 设计改为单用户版本（#661）。
- 编制变更设计获批（#626）；组队顾问设计（#664）。

### 本版已披露限制

- 0.8.1-preview.18 一节列出的限制仍然适用，但"子团队路由额度耗尽时根团队看不到提示"已部分解决：子团队宿主能看到提示，根团队这一侧仍然看不到。
- 组队顾问在本版只能盘点和给建议，不能提交蓝图（BS2 待做）。
- 编制变更不含撤团队、撤成员、换模板，只用已有会话。
- 团队成员与宿主同一系统用户，读得到团队身份私钥和节点私钥。属主已接受这个风险，靠凭据留痕发现。

## 0.8.1-preview.18（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-12）：标签 `v0.8.1-preview.18` 指向 f17025c（发版 PR #655）。2026-11-12T11:56:38Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `49cfa1c8593b629208b0b9ab6744d089722fffe8`，integrity `sha512-YvUqx0oRJoMO3FDzCt5RV09EfqjQtA2pPjKsyLECUxluYfLTQ5SThOkt17CQ1/w3I13dRBGoSJtZQel1k9GaRA==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。
- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.17 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。升级后只需重启，不用改配置。

### 新功能：根团队（[设计](design/superagent-root-team.md)，属主已批准）

- 根团队的成员是其他 superagent 团队，不是会话（#646、#649）。
  - 在画布上用 `set-root` 把一个团队标成根团队，再用 `add-team` 加子团队；每个子团队可同时接的票数默认 3，可设 1–16。
  - 根路由像指名成员那样指名子团队。宿主用根团队自己的 A2A 身份把票发给子团队。
  - 子团队的回执推进根票：提问转给根的请求方，完成或失败就是根票的结果，拒绝时票退回根路由重选。
- 根团队身份在名片上声明它能接什么：`progressReceipts`、`directedSeats`、`reworkReturns`（#652）。子团队的进度会作为根票的进度传给根的请求方。
- 跑 superagent 的宿主在自己的名片上声明会读指派行：`directedSeats`、`reworkReturns`（#653）。
- 跨宿主登记（#652、#654）：
  - 子团队宿主的属主执行 `admit-root`，把根团队身份登记为团队画布的请求方，并钉住根的家宿主。请求方不算成员，不接活，也不出现在名册里。
  - 根宿主执行 `add-team` 时，从子宿主名片读出子团队身份，同样登记为请求方。
  - 两边的转发范围互相包含对方：根能发给自己的子团队，子团队能发给登记过的根。
  - 顺序：先在子宿主 `admit-root`，再在根宿主 `add-team`，然后再派单。
- `sdk/wire`（#647）：给请求方用的线协议 SDK，不需要凭证。它负责解析和生成指派行、回执、名册，以及判断对方是否声明了某项能力。

### 修复

- 获批的外发名片就是团队身份的发送范围（#648）。
- 根团队给子团队派单时不再先做审核用的准入预检（#651）。以前这个预检对画布地址总是答"不准入"，结果根什么都发不出去。
- 根团队身份声明的能力一变就重新发布名片（#652）。
- 根宿主重启后不再把同一张票重新派给子团队（#654）。子团队在自己的宿主上照常工作，根票的分派跨重启保持运行。

### 本版已披露限制

- 0.8.1-preview.17 一节列出的限制仍然适用。
- 根团队的画布看板（根团队框、子团队卡片、拖放）还没做，目前只能用 `/__dsh_a2a/canvas` 接口操作。
- 跨宿主时，子团队交回结果这一步还没在测试宿主上实测。派单和确认回执已实测通过。
- 如果回答在两边链接都建好之前就发出并被拒，它的 task id 已被占用，之后不会再发。所以要按上面的顺序登记。
- 子团队的路由模型额度用完时，根团队这边看不到任何健康提示。

## 0.8.1-preview.17（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-12）：标签 `v0.8.1-preview.17` 指向 9474094（发版 PR #642）。2026-11-12T05:44:57Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `a7fc3fbcbc3ce78b7d5fc5531408517fa7538898`，integrity `sha512-2kIk4DFyZFeukcwkr36Z+Cns8pJwblqDCbfDZZUDW4aoqMQJmgA2DG4n8IdTUPrBwK+eh7L+zoga1yW5hu1DTQ==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.16 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。升级后只需重启，不用改配置。
- 接工作台市场的节点要升到本版或更高：工作台市场上线清单把它列为节点侧前置。

### 修复

- 宿主重启后不再停推团队名册（#640）。名册的推送对象是画布上确认过的、名片声明了 `teamRoster` 的远端成员，这两项都从宿主内存里的名片缓存读。重启会清空这份缓存，以前只有碰巧的动作（对方发来消息、有人读宿主状态）才会把名片拉回来；测试宿主重启后因此两个半小时没推名册。现在宿主每次看团队（每 10 秒）都先经缓存刷新一遍对等节点的名片，每个对等节点最多每分钟真拉一次，刷新出错只记日志、不影响推送。在测试宿主上，重启后 21 秒、没有人读状态，名册就恢复了推送。

### 本版已披露限制

- 0.8.1-preview.16 一节列出的限制仍然适用。

## 0.8.1-preview.16（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-12）：标签 `v0.8.1-preview.16` 指向 9c4c6e0（发版 PR #639）。2026-11-12T04:57:35Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `58457685b41ac3055cfa60ec1ddf12bed293d6e3`，integrity `sha512-l9YqLbpazFkLsuHktGNc6Wa5s7nVNHirZ6KBBhE+k1qKtjelTPxxIqCfP4CW3EBk+AwlsLWC+BWRpG15wb6nzw==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.15 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。升级后只需重启，不用改配置。

### 修复

- 宿主声明了 `originClaimUrl`（在隧道或代理之后）时，团队以自身名义发出的对外请求被本机转发闸拒绝（#638）。团队 CLI 走本机回环拨号，签名的受众是回环地址，而这类宿主不认回环受众，签名只算未绑定，转发闸因此在派发前拒绝；#635 的续期重试对它无效。
  - CLI 新增环境变量 `A2A_CLAIM_AUDIENCE`（只取 origin）：设置后，签名的受众用它代替实际拨号的地址；`a2a-net status` 显示 `signed for <origin>`。
  - superagent 把它设为宿主自己名片的 origin，团队身份的签名因此绑定到本宿主。不新增回环别名，不改 `originClaimUrl` / `originClaimAudiences`。
  - 转发闸的两种拒绝分开说明：「no bound CLI signature」（改拨号地址或 `originClaimAudiences`）和「not an online local CLI deposit」（执行 `a2a-net publish`）；#635 的续期重试只在后一种时触发。线上错误码不变。

### 本版已披露限制

- 0.8.1-preview.15 一节列出的限制仍然适用。
- 升级前已失败的对外请求不会自动重发；升级后由总工沿原批准记录恢复，或重新提卡。

## 0.8.1-preview.15（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-12）：标签 `v0.8.1-preview.15` 指向 20f6fa6（发版 PR #636）。2026-11-12T03:16:51Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `1c5131abfd95e795a2fc22a23dfd73ead56dbc7c`，integrity `sha512-/M17Tt6UTIfA3jL8hTp6fr0IR70npn5FMH57KNFlzDIm2YKL8JrfoQd5JtLEooEx3DAQR9omw26M3bvlyVP8VQ==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.14 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。
- 本版的新功能经属主在评审席会话确认（2026-11-11），并在本机市场试联（3084 测试宿主 × 工作台市场试联实例）上实测过打回重做和团队名册。

### 新功能

- 指名派工与打回重做，宿主直接执行，不靠规则文字（#627，设计 `docs/design/superagent-named-dispatch.md`）。请求正文第一行写派工行 `[A2A dispatch] {json}`；只认签名来信、画布上钉住公钥的远端成员、且其名片声明了对应能力：
  - `for`（能力 `directedSeats`）指名一个席位。总工只判接不接，接下后宿主交给指名的席位，席位忙就排队；席位不在团队、不在线或句柄失效时，宿主问请求方「等」还是「换人」（`attention-<task>-<id>`，选项固定），不自行改派。拆单时子项默认交给指名的席位。
  - `rework`（能力 `reworkReturns`，`{"of": "<被打回的那次交付的任务号>"}`）由宿主直接接成新工单「打回重做：<最初原单标题>」，交给做被打回那张单的成员；连着打回几次标题不叠加（#630）。
  - 每个席位有稳定的 `seatId`（`seat-<8 位十六进制>`），会话被替换后不变，总工也有（#632）；名册和回执的 `by` 都带上它（#634，`--by-seat-id`）。属主用 `POST /__dsh_a2a/superagent {action:'move-seat', from, to}` 把席位移到替换它的会话上。
- 名册的 `name` 和回执的 `by.name` 只给纯名字，不再带宿主拼上的「 (<句柄前 8 位>)」（#632）。
- 团队页（工作台左栏 superagent 团队）：切换团队后、新团队的状态到达前不显示旧团队的内容；当前团队和子页刷新后保留；团队选择器标出其他团队待你处理的数量（#624）。
- 左栏「规划」标签改名「待办」：它是网络的待办行动清单，与规划画布无关（#631）。

### 修复

- 获批的对外请求被本机宿主拒绝时，记录真实原因、下一步和任务号（原来只剩「exited 1:」）；因团队身份的 CLI 户口过期被拒时，先续期再重发一次（#635）。
- 以下只影响 preview.14 之后的 next/0.8，未发布过：席位同步在启动的第一轮读画布导致插件启动失败（#628）；派工行在宿主存储的网络投递头下读不到（#629）；「等 / 换人」的答复改为只读所选的选项，名字或其他字段里的「等」不再误判（#633）。

### 本版已披露限制

- 0.8.1-preview.14 一节列出的限制仍然适用。
- 指名派工（`for`）只在单元测试里走过；市场侧尚未声明 `directedSeats`。打回重做和名册已在本机市场试联上实测。
- 编制变更（市场提议、节点执行）只有设计稿（#626），待属主评审，未实现。
- 市场与团队的对应按名册的 `(host, team)`，`team` 是团队的画布地址；市场绑定里存的若是总工句柄（旧写法），该团队不能指名。

## 0.8.1-preview.14（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-11）：标签 `v0.8.1-preview.14` 指向 6118094（发版 PR #623）。2026-11-11T19:19:36Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `2dd68832fd38b9cea0243a6b1e5551be90e62ba4`，integrity `sha512-wcgywCAZB1+9TnZJykPX23KDF7AsBpHNiWTcCg/arVIk7N7N9oqR8JENyperpkI1x2BSQBUscAslM2mmB2NuKg==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.13 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。
- 本版来自本机市场试联（3084 测试宿主 × 工作台市场试联实例）中发现的问题和属主的裁定。

### 新功能

- 总工按需求拆单（#619、#620、#622，设计 `docs/design/superagent-split.md`；属主裁定：只在需求明确要求分项时拆）：
  - 总工新工具 `superagent_split`：`asked` 必须是需求原话（宿主核对，找不到就拒绝 `not-asked`），2–6 项。
  - 原请求成为只协调的主工单，不派给成员；每一项是一张子工单，可指定成员。子工单不单独发确认、进展和正式回执；子工单的提问照样到请求方的任务上，答复交回提问的那一项。
  - 全部子项结束后只有一条结果回执：全部完成为 `completed`，开头「全部子项完成」；有一项未完成为 `failed`，开头「部分完成（有子项未完成）」并逐项写明。无论这条回执由总工还是宿主发出，都带上 `tickets`（每项的席位、状态、结局）。
  - 候选卡片上的团队规则同步改为「一个请求一张票，除非需求本身明确要求分项」。
- 回执的 `by` 带上 `role`（`router` / `member` / `observer`），请求方可以只把成员当作承接人（#611）。
- 回执的 `artifacts` 每项可带 `title`（给人看的显示文字）；`--artifacts` 也收 JSON 数组（#615）。
- 成员提问回到请求方时带上选项和推荐项（`question.options` / `question.default`），请求方可以给人可点的选项（#616）。
- 凭据访问留痕（#612）：团队人设写明只用宿主交给的工具和凭据，不找、不读、不用别的；宿主记录团队会话触及凭据文件、带 Authorization 的请求或别的会话文件的调用（只记类别、工具和遮蔽过的预览，不记读到的内容），并给属主提 P1 决策卡。只记录，不拦截。

### 修复

- 列在团队 bot 名单上的画布远端成员（例如工作台市场、对等团队的发送身份）不再被当成工人派单（#610）。preview.13 上把对等团队加成远端成员时，本地成员一忙就会往它派单并每 30 秒重试。
- 有在办工单的团队宿主在 #611 之后启动失败（取接手人角色时在开机时读画布）（#617；只影响 preview.13 之后的 next/0.8，未发布过）。

### 文档

- 团队会话用单独的系统用户（属主裁定；部署指南 `docs/archive/ops/superagent-team-user.md`，#613）。
- 团队 MCP 的正式做法设计稿（令牌只在团队宿主进程里，成员经宿主代调；#614，未实现）。
- 接市场清单补充：bot 名单、接单规则、回信身份、画布变更通知、打回重做规则（#608、#621）。

### 本版已披露限制

- 0.8.1-preview.13 一节列出的限制仍然适用（`progressOff` 无界面开关、成员不填 `artifacts`）。
- 团队会话的沙箱只限写不限读；凭据访问留痕只记录不拦截，真正限读要按 `docs/archive/ops/superagent-team-user.md` 用单独的系统用户部署（该指南尚未在节点上从头走过）。
- 拆单只在本机试联和单元测试里走过；总工是否在需求要求时拆，仍取决于总工照规则判断，宿主只核对「需求确实要求了」。
- 团队 MCP 尚未实现：在单独的系统用户落地之前，不给团队发 MCP 令牌。

## 0.8.1-preview.13（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-11）：标签 `v0.8.1-preview.13` 指向 145aa2d（发版 PR #607）。2026-11-11T14:40:17Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `0b3dbbfcacfe469dbaf86f8a24c4d30b3750cdab`，integrity `sha512-47+4RNNa/rmifRn37QQYYJPb6jPFvDVap7j4h4UaxT+EmU92eTiB55GJnZfSlS6Rti6rfxyfQZ4zMP9mAKnDFg==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.12 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。
- 这一版是 superagent 团队接工作台市场的节点侧：节点怎么接见 [superagent 团队接工作台市场](ops/superagent-market-team.md)（#602）。

### 新功能

- 回执带上接手人、产出和结构化提问（#603，设计 `docs/design/receipt-envelope-fields.md`）：
  - 回执信封新增 `by`（接手的席位）、`artifacts`（产出在请求方系统里的编号）；`attention` 回执可带 `question`（提问编号、问题、可选答法、缺省项）。旧版本读取方忽略这些字段。
  - 带 `question` 的提问走自己的任务号 `attention-<task>-<提问编号>`，不结清原派工，可以问多次；结果仍走 `receipt-<task>`，带可机读的结局。
  - `a2a-net receipt` 和团队宿主出口认同一组开关：`--by`、`--artifacts`、`--question-id`/`--options`/`--default`。
  - superagent 团队的成员提问改用这种回执，不再走要回执、占名额的跟进路由；确认、提问和结果回执都写明接手的席位，工单结束后写的是做事的成员。
- 进展回执与轻路径（#605，设计 `docs/design/superagent-market-progress-roster.md` P1/P2）：
  - 新增 `progress` 回执（任务号 `progress-<task>-<n>`）：排队（前面几件）、在做、等待、卡住，谁在做，请求拆成了哪些工单；不结清原派工，原派工的过期时间重新计算。只发给钉了公钥、名片声明 `progressReceipts` 的调用方；限频；团队设置 `progressOff` 可关。
  - 轻路径：请求方在自己那张工单的对话里接着发的消息，由宿主直接挂到工单交给成员，不再经总工判定；别人在同一对话里发的仍由总工判。内置的 superagent 引擎没有改动。
- 名册上报（#606，P3）：团队宿主每 5 分钟、以及席位变化 30 秒后，给画布上钉了公钥、名片声明 `teamRoster` 的远端成员发一份名册（`[A2A roster]`：席位、名称、画布地址、角色、在线、手上几件、排队几件），不欠回执、不占名额。

### 修复

- 请求方的答复被转进工单、同时被总工判为「不接」时，不再先回「已转给成员」、再回一条矛盾的「团队未接」（#601）；送到成员手里的消息，即便工单结束时被放回，也在工单结束时回执结局。

### 本版已披露限制

- 0.8.1-preview.12 一节列出的限制仍然适用。
- 进展回执和名册要对端名片声明能力、并作为画布远端成员钉了公钥；本版只在单元测试里走过发送一侧，没有和真实的市场对端联调。
- `progressOff` 目前只能经设置接口或设置文件改，工作台设置页还没有开关。
- 任务号太长（`attention-<task>-<提问编号>` 超过 80 字符）时，提问退回旧的跟进路由。
- superagent 自己还不填 `artifacts`：成员报告里没有产出字段。

## 0.8.1-preview.12（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-11）：标签 `v0.8.1-preview.12` 指向 b222802（发版 PR #599）。2026-11-11T12:07:20Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `a35b2e4c03763205371edd6dc9625e9975e143c7`，integrity `sha512-OcEZMbJ7t6OtFjhSL3TkGEfCIHoBYSi8G7kUDjWRvKdea9oHltAeGCjm9nEnphWUSe9M0SV0yMGdyFde4wYLgw==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.11 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。

### 新功能

- 向属主汇报的规范成为团队默认（#598，设计 `docs/design/superagent-owner-reporting.md`）：此前只在一位成员的自有规则里生效，其余成员只是草案。
  - 总工、成员、观察者的人设都写明：交给属主的只能是可执行建议或决策单，不交开放式问题、背景叙述或「需要更多信息」，缺口先自行缩小；建议写明动作、对象、责任入口，并标明建议／已授权／已执行；用名称不用哈希编号；进展只在改变行动或裁决时汇报；要人回答的问题只能通过工单报告的提问状态或决策卡提出，写在正文里的不算。
  - 宿主强制：总工/观察者的决策卡必须写理由（成员的工单提问卡走 `a2a_ticket_report` 的 question 路径，没有 `reason` 字段，宿主只校验选项、推荐与级别）；裁决即终局——总工或观察者就属主已裁决的同一问题再提卡，会被拒绝并带回当时的裁决（健康提醒、工具申请、对外请求不受这一条约束）。

### 本版已披露限制

- 0.8.1-preview.11 一节列出的限制仍然适用。
- 人设里的规范是给模型的说明，宿主无法逐条检查；成员偏离时，属主可用成员规则纠正。
- 「裁决即终局」按问题原文精确匹配：换个说法问同一件事仍会提上来，由属主拒绝。
- 这一版没有在界面里驱动总工会话实测「再提被拒」；这条逻辑在单元测试里用真实的宿主和工具链路走过。

## 0.8.1-preview.11（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-11）：标签 `v0.8.1-preview.11` 指向 625c809（发版 PR #596）。2026-11-11T11:48:06Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `afab19ea92426206ba1e5be75a5fec545a8748e5`，integrity `sha512-7Tqy8TBMVzI+QihMAaF8RAIlVvCsfeF2wfYUMx+0M+TCsbU4/hzyvQJdWIv80r52NN33Mz7PZlOLt67A/ZV03Q==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.10 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)；团队接工作台市场 MCP、在团队预设之外挂 ygl-trees MCP，见新的 [superagent MCP 运维指南](ops/superagent-mcp.md)（#592）。

### 新功能

- 成员和观察者默认可用主机上的全部工具（#595）：属主装的插件、接入的 MCP 服务不用再逐个放行。一律挡住的只有越出团队的工具：开新会话和子代理、插件管理、在界面里等人回答、A2A 发送和入队退队、别的角色的团队工具、超出本角色的 `mcp__ygl__*`。属主可在团队设置「成员和观察者禁用的工具」里再收紧（只有属主能改）；成员被挡时不再弹决策卡。总工不变，仍用自己那组工具、放行列表和 P0 申请卡。
- 团队向其他团队发请求（#591）：总工可为任何在办工单、成员和观察者可为自己手上的工单调用 `a2a_outbound_request`，提一张 P0 决策卡，写明对方地址、要发的原文和理由。属主批准，或由属主在设置「审批人」里指定的成员/观察者用 `a2a_decision_decide` 写明理由代批（不能批自己提的卡）。批准后由宿主以团队的 A2A 身份发出原文，对方的正式回执作为备注回到原工单。每张工单最多 3 个在途请求；需要团队的 A2A 来源已打开。
- 每个团队一个 ygl-trees 项目（#590）：宿主为每个团队自动建项目 `team-<画布名>`，派单卡写明它，成员先为本会话选中再读写，不再新建项目；总工的候选卡也写明，供 `kb search` 用。新团队不再卡在第一次写入（`no project selected`）。

### 修复

- 回执重发遇到 `-32003`（对方已记过这个任务）时（#593）：先向对方查询这个任务——已完成，或对方没有查询接口（例如工作台市场），算已送达；仍在途则继续重试；对方记为失败则算失败。此前会一直重试到次数用完。
- 一个在高负载下偶发失败的跨实例中继测试改为确定性（#594，只改测试）。

### 本版已披露限制

- 0.8.1-preview.10 一节列出的限制仍然适用。
- #595 之后，成员能用主机上的全部非越界工具：主机上装哪些插件、接哪些 MCP，由属主把关。旧的「成员和观察者额外放行的工具」不再起作用（成员本来就都能用），总工的放行列表照旧。
- 审批人是 agent：让它代批，是用属主的注意力换速度；每次决定都记下决定人和理由，属主可随时在设置里撤掉审批人。
- 团队项目需要宿主 PATH 上有 `ygl-trees`；没有时什么也不建，团队照常工作，只是没有记忆工具。
- 对外请求、团队项目、默认放行都在测试机上实测过：对外请求走了三轮（审批人按编号批、审批人自己找到卡批、属主在团队页批），三轮的回执都回到了原工单；对方是同一台测试机上的普通会话，跨主机的对外请求还没实测。

## 0.8.1-preview.10（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-11）：标签 `v0.8.1-preview.10` 指向 de996d1（发版 PR #588）。2026-11-11T05:33:10Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `9b300444ad8759cc030174e506e97696955f5daa`，integrity `sha512-7diUT440eYVaWkxoAMt3cHujabaKziMjnmxv2qqmhuSR5DRUbsfdOUa1Jdzfcemn48zr6nJLffIieo6x1u3K1g==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.9 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。

### 修复

- 绕过 ygl-trees 的「ambiguous project」（#587）：ygl-trees 的 MCP 在 `agent brief` 和 `project show` 上丢掉显式的 project（ygl-trees#260，0.122.0 仍在），工作区里有多个项目时，每张工单的第一步都会失败。派单卡写明报错补救：遇到这个报错，先用 `mcp__ygl__write domain project action use` 为本会话选中项目，再调一次（每个团队会话有自己的选择，不影响其他会话）；人设是预防式写法：先为本会话选中团队项目，每次调用都带 project。总工只读，改用带 project 的 `kb search`。

### 本版已披露限制

- 0.8.1-preview.9 一节列出的限制仍然适用。
- 这是人设和派单卡文字的变化，绕过办法在测试机上由成员自行验证过（先 `project use` 再 `agent brief`）；ygl-trees#260 修复并在各主机升级后，这几处会删掉。
- 不用团队预设、自行挂载 ygl-trees MCP 的会话没有独立的 `YGL_SESSION`，在那里 `project use` 会影响共用默认选择的其他进程，不建议照做。

## 0.8.1-preview.9（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-11）：标签 `v0.8.1-preview.9` 指向 c89c48b（发版 PR #585）。2026-11-11T05:15:05Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `7b8938ab9b388233eff342df9ac150c0f40c70bf`，integrity `sha512-6ZCEGAjFPdKgfQI2/nbAKvGpMD0XKQYjc7cLeTt+vqo21OZBY8bMQasFQmkuSWTTcIMBJKT1Y8Fk8Akt+ZINiw==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.8 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。

### 修复

- 总工或成员缺了团队工具时自动补回（#584）：角色会话的工具清单按同步那一刻会话里看得到的工具计算，并一直缓存到角色变化。若某次同步发生在本插件的团队工具（如 `superagent_*`）还看不到的时候（例如主机重启、恢复会话时），总工会一直看不到派单工具，重启和重新保存设置都不能恢复。现在清单缺了本插件的团队工具时，会在该会话下一轮开始时重新计算；清单完整时不重算。缺工具时日志记一次 `does not see …`。

### 本版已披露限制

- 0.8.1-preview.8 一节列出的限制仍然适用。
- 测试机上没有复现出"同步那一刻看不到团队工具"的现场；本修复在测试机上验证的是重启后总工照常用 `superagent_route` 接单，没有缺工具的警告。已经缺工具的总工会话，升级后在该会话里正常发一轮消息即可补回。

## 0.8.1-preview.8（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-11）：标签 `v0.8.1-preview.8` 指向 ce9b5c0（发版 PR #582）。2026-11-11T03:33:16Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `2714da281f284d5c27b1fdd31cfb45dd456adee9`，integrity `sha512-45xXREpBCzdR0efJIjHY3PwcQgSMEQViONnd7xofebdGWXAlDUgnDNJ54Rlq7J8vWz1c2H/3ZM6ngg7nlyS+XQ==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.7 有下列改动，都是 DSH 版本兼容修复。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。

### 修复

- 在 DSH 0.2.1 上也能用定时工具（#579）：DSH 0.2.1 的定时工具是 `schedule_create` / `schedule_list` / `schedule_update` / `schedule_delete`，没有 `target` 参数，任务固定属于调用的会话；DSH 0.2.2 是 `schedule_create` / `schedule_edit` / `schedule_list` / `schedule_view`，`target` 必填。此前团队会话的守卫要求 `target: this_session`，在 0.2.1 上每次创建都被拒，`update` / `delete` 也被隐藏。现在不带 `target` 放行，显式写其他 target 仍拒绝，两代的工具名都在角色清单里。
- `a2a-network` 技能能加载了（#580、#581）：0.8.1-preview.4 起技能能出现在列表里，但每次加载都报 `loaded skill "a2a-network" source must be a string`，DSH 0.2.1 和 0.2.2 都是如此。注册时补上了 DSH 要求的 `source`。

### 本版已披露限制

- 0.8.1-preview.7 一节列出的限制仍然适用。
- 定时工具在 DSH 0.2.2 的测试机上验证过（成员建、列、查本会话任务）；DSH 0.2.1 上没有在测试机复现，验收方法：不带 `target` 创建，`schedule_list` 读回 id，`schedule_update` 后 id 不变，`schedule_delete` 后列表里没有。
- 技能加载在 DSH 0.2.2 的测试机上验证过（修复前报错、修复后返回技能正文）。

## 0.8.1-preview.7（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-10）：标签 `v0.8.1-preview.7` 指向 1515f8b（发版 PR #577）。2026-11-10T17:06:55Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `7bf03aabf1e620a775c7ca071f44691c6a2ac32a`，integrity `sha512-Gf/8UblYfXdIzPcx130WfJ648iqKZNsi6dOGFxxN1gbJ04EGNpFzvGaqztIM+zNjz+rTzQu8KfuLwiMFxx5rjQ==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.6 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。

### 修复

- 运行中新建的团队，总工看不到 `superagent_*`（#576）：新团队在进入团队登记之前就通知了工具列表，总工因此一直按"不在团队里"处理，普通工具被拒，派单工具又不显示。现在团队登记之后会再通知一次。升级前已经卡住的会话，升级后在团队页对该团队重新保存一次设置即可恢复。
- 团队 ygl-trees 工作区由宿主创建（#576）：`db init` 不在 MCP 里，总工没有 shell，成员的 shell 又只能访问自己的目录，所以没人能建库，ygl 工具一律回答没有数据库。现在宿主启动时，如果团队工作区（`SUPERAGENT_YGL_HOME`，未设则为主目录下的 `.ygl-trees-superagent`）没有数据库，就自己执行 `ygl-trees db init`。宿主的 PATH 上没有 `ygl-trees` 时什么也不做。
- 人设说明（#576）：`ygl` 只是 MCP 服务器名，命令是 `ygl-trees`；缺库由宿主处理；总工缺 `superagent_*` 工具时只说一次，不再用其他工具试探。
- CLI 的 `whoami` / `publish` 打印可直接打开的身份卡地址（#571）。

### 新功能

- 申请角色以外的工具（#575）：团队会话调用了角色不允许、但可以放行的工具，或者用新工具 `a2a_tool_request` 按名申请时，宿主给属主提一张 P0 决策卡，属主必须明确选择。批准后该工具写进团队设置 `extraTools`，立即对该团队的成员和观察者（或总工）生效；拒绝后 24 小时内不再询问。团队页设置里可以看到并撤回已放行的工具。跨出团队边界的工具（路由、发文件、入队退队、子代理、其他会话、ygl 与定时任务工具）永远不能申请。

### 内部

- `src/index.ts`、`src/superagent/host/index.ts` 回到行数棘轮之内（#573）；S 层监督材料 v24 不再把 vendored 上游计入模块上限（#574）。没有行为变化。

### 本版已披露限制

- 0.8.1-preview.6 一节列出的限制仍然适用。
- 放行工具背后的插件是否可信由属主判断，宿主无法核实它是否在沙箱里；决策卡写明这一点，并默认推荐拒绝。工具申请在测试机上走通了申请、批准、撤回；放行后成员会话里工具立即可见，由单元测试覆盖。
- 宿主建库只在启动时做；改了 `SUPERAGENT_YGL_HOME` 要等下次重启才会建。
- 工作台市场已能聚合 ygl-trees MCP，但本版仍由预设直接启动 `ygl-trees mcp`，还没切到市场。

## 0.8.1-preview.6（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-10）：标签 `v0.8.1-preview.6` 指向 f0309d6（发版 PR #568）。2026-11-10T11:15:07Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `5f3ed3b3df3f94cd398ee00a8eee746d219f790a`，integrity `sha512-PkCv0A65YLqxQFbLDD/7XJtPAGj7Om4D46QjhaGObmUtyYuVuX/+bivtdfvg1SIGuhrg2B4dnjeEi/w0MrNDtg==`。从 npmjs 回读的包与审计过的包逐字节相同。GitHub Release 为 prerelease。未发布到 Gitea。

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.5 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。

### 新功能

- 派单卡写明 ygl-trees 步骤（#558）：成员手上有 ygl 写工具时，派单卡里写明开工先 brief、过程中记依据、ready 前 `kb add`；`a2a_ticket_report` 新增 `ygl` 参数，ready 时没填会被提醒一次，第二次照收。
- 团队独立的 ygl-trees 工作区（#560）：团队写入 `SUPERAGENT_YGL_HOME`，没设就用主目录下的 `.ygl-trees-superagent`，不再写进属主的个人工作区；每个团队会话的 ygl-trees 服务有自己的会话身份。部署后先用 `ygl-trees db init` 建一次这个工作区。
- 团队页搜索与设置保存历史（#561）：按文字、id、链接、`#尾号` 查需求和工单；每次保存设置都记下谁、何时、改了哪些字段。
- 自检主动提醒（#562）：每 15 分钟自检一次，出现新问题就给属主提一张 P2 决策卡，同一问题不重复提，问题消失后自动收回。
- GitHub Issue 接单（#565）：团队设置打开 `sources.github` 并列出仓库后，点名 `@superagent` 或打 `superagent` 标签的新 Issue 成为需求，只认 `allowed.github` 里的账号；回复以 `[superagent]` 写回 Issue；`allowed.github` 可从仓库协作者同步（只加不删）。改 GitHub 相关设置需要属主登录。
- 可编辑的两段提示词（#567）："沟通方式"和"交付要求"可在团队页补充，各 4000 字以内，和预设冲突时以预设为准；修改需要属主登录。
- 总工、成员分别选模型（#566）：团队设置里分别指定，宿主在保存设置、成员加入、会话加载时切换；每个会话最近一次的切换结果（含失败原因）显示在团队状态里。

### 本版已披露限制

- 0.8.1-preview.5 一节列出的限制仍然适用，其中"成员按人设使用 ygl-trees 不可靠"一条已由 #558 改善，现场试单验证过完整闭环。
- 团队页搜索、设置保存历史（#561）、主动提醒（#562）、可编辑提示词（#567）有单元测试和前端测试，没有在测试机上完整走过界面。
- 切换模型时，DSH 会同时把该模型存为这个实例新会话的默认模型（DSH 自身行为）。团队跑在专用配置里，影响只限于团队实例。模型和推理强度要是 DSH 支持的组合，不支持的会失败，原因显示在团队状态里。
- GitHub Issue 接单需要宿主上的 `gh` 已登录，并且对列出的仓库有读取和评论权限；每分钟轮询一次，失败后退避，最长 15 分钟。新开的 PR、默认分支 CI 还不会成为需求。

## 0.8.1-preview.5（预览版，已发布到 npm 的 preview 标签）

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.4 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。

### 新功能

- 工单准备命令与并发上限（#552）：团队设置里可以填一条准备命令，派单前在成员的工作区里运行（失败按派单失败重试）；可以限制同时进行的工单数，只拦新派的单。
- 团队自检（#552）：总工或成员的会话没加载、工单 60 分钟没有动静时，右栏顶部显示提示；宿主启动唤醒会话期间不报（#553）。
- 右栏合成一个视图（#553）：待决策的卡片放在提需求输入框上方，不用再切标签页。
- 团队会话的定时任务（#554）：总工、成员、观察者都能用 DSH 的定时工具，但只能给自己的会话排；到点送进来的消息不算属主本人的话。
- `a2a_whoami` 对所有角色开放；新增只读的 `a2a_ticket_read`：成员只看自己手上的工单，观察者还能看本团队的工单和最近的决定（#554）。
- 决策卡可以附文件（#557）：总工、观察者提卡，以及成员带问题汇报时，可以把自己工作区里的文件附上（最多 16 个），卡上列出来，属主可以直接下载；属主做决定时也可以上传或拖入文件，引用行随决定交给总工或接单成员。
- ygl-trees 作为团队记忆（#555、#556）：三个预设挂上 ygl-trees 的 MCP 服务（`ygl-trees mcp`，宿主 PATH 上要有 `ygl-trees`）。总工只能读，开单前先查以前的工作；成员和观察者还能写、验证、体检，开工先 brief，过程中记依据，完成前记下可复用的经验，并在报告里写明 id。

### 本版已披露限制

- 0.8.1-preview.3 一节列出的限制仍然适用（其中两条已在 preview.4 解决）。
- 每个会话最多 2 个活跃定时任务目前只靠人设约束，宿主没有硬限制。
- 宿主 PATH 上没有 `ygl-trees` 时，团队会话拿不到 ygl 工具，只会说明调不到；插件不负责安装 ygl-trees。会话 shell 里的 ygl-trees CLI 受沙箱限制，只能用自己目录里的工作区。
- 决策卡上的文件走文件通道，只保留 24 小时；过期后卡上仍列着，下载会提示已过期。
- 成员按人设使用 ygl-trees 不可靠：现场试单中总工查了 ygl-trees，成员没有用。把步骤写进派单卡的改进（#558）不在本版。
- 准备命令、并发上限和右栏合并视图有组件测试和集成测试，现场验收没有做完。

## 0.8.1-preview.4（预览版，已发布到 npm 的 preview 标签）

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.3 有下列改动。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。

### 修复

- `a2a-network` 技能重新出现在 DSH 的技能列表里（#550）。之前插件读不到技能服务，注册被静默跳过。

### 改进（#549）

- 决策卡归档修剪：已决定的卡保留 30 天、最多最新 500 张，工单结束的成员卡清掉，等待中的卡不删。
- 画布页标出本实例所有团队的画布和角色，不再只标团队页当前选中的那支。

### 本版已披露限制

- 0.8.1-preview.3 一节列出的限制仍然适用，其中「画布页的角色标记只跟随团队页当前选中的团队」「决策卡没有归档修剪」两条本版已解决。

## 0.8.1-preview.3（预览版，已发布到 npm 的 preview 标签）

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.2 新增下列功能。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。

### 观察者（#530、#531）

- 新预设 `superagent-observer`：加入画布团队后是成员，多一个开单工具。开的单交总工接单派发。

### 右栏（#533–#535、#543、#544）

- DSH 右栏新增「提需求」：选团队、写需求，可上传或一次拖入多个文件。
- 右栏新增「待决策」：决策卡带选项、推荐项和级别 P0–P3。P2、P3 可一键批准，P0、P1 必须选定后确认。
- 总工的建议、观察者的提议和成员的提问都用决策卡。总工和观察者的卡决定后成为属主的需求，成员的卡回到原工单。

### 多团队（#536、#539、#540）

- 同一 DSH 实例可以跑多支团队，团队页可切换和新增。原团队的数据不动，不带 `teamId` 的调用仍指原团队。
- 右栏可以选已建链实例上的团队。跨实例发送算当前会话的消息，对方按自己的规则处理，不算属主本人。

### 直接对话（#537、#538、#542）

- 在总工会话里提工作需求直接开单，不再先确认；结果也写回对话。
- 属主直接跟成员、观察者对话不需要工单，也不再影响成员手上的工单。这一项修了一个缺陷：持单时的聊天回复曾被记成工单的 `waiting` 汇报。

### 文件通道

- 授权给画布团队的文件，同主机的画布成员现在能拉取（#534）。之前会返回 `not-granted`。

### 本版已披露限制

- 0.8.1-preview.1 和 preview.2 列出的限制全部仍然适用。
- 属主决定先发版：本版发布时，全量回归还在跑；现场验收 12 项已全部通过。回归结果记在发版 PR 上。
- 真人从访达拖入文件、两台真实主机之间的跨实例发送，只有组件测试和集成测试，还没有现场验收。
- 总工必须用决策卡提建议靠提示词约束，宿主拦不住文字建议。决策卡的级别由发起方标注。
- 画布页的角色标记只跟随团队页当前选中的团队。
- 决策卡目前没有归档修剪。

## 0.8.1-preview.2（预览版，已发布到 npm 的 preview 标签）

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对已发布的 0.8.1-preview.1，新增默认开启、团队页编辑入口、成员规则与派单规则。npm 上用 `preview` 标签发布，`latest` 不动，要装必须写明版本号。
- 默认行为变化：没写 `superagent` 这个键的主机升级后会运行团队引擎，空转到绑定团队为止；不想要的主机配 `superagent: false`。
- 升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。验收结果记在发版 PR 上。

### superagent 团队默认开启（属主 2026-11-09）

- `superagent` 默认从 `false` 改为 `true`：不用改配置、不用重启，属主在画布上组队并在「团队」页绑定即可。想关的主机配 `superagent: false`。
- 没绑定团队的主机上，引擎只是空转，不接单、不开团队地址、不发任何消息；会多出 `<a2a home>/superagent/` 目录和可用的「团队」页。
- 不在团队里的会话看不到团队的 8 个工具（`superagent_*`、`a2a_ticket_*`）；会话成为总工或成员时才显示。
- 独立的 `a2a-net serve` 节点没有会话，始终不跑引擎。

### 成员规则、派单规则与属主批准（设计 superagent-router-owner-asks）

- 每个成员有自己的角色和接单规则，总工有团队接单规则和派单规则。候选卡片列出成员的角色、规则和忙闲；成员设了角色或规则后，总工接单必须点名成员，工单只等这个成员。
- 规则在对话里改：成员只能提议自己的，总工只能提议团队的；你本人回复之后才生效。接单模式、机器名单等只有你能改。
- 总工会话里说「帮我开个工单」，总工把你的原话提交成需求，走正常接单流程。
- 「团队」页展示每个成员的角色、规则、待确认的修改和最近修改，也可以直接编辑；页面改规则需要已登录的 DSH 界面。

### 团队页的编辑入口（#525）

- 「团队 → 设置」可以编辑接单规则、允许发需求的机器、成员的仓库、PR 上算人的 GitHub 账号、送审地址。保存时只写改过的项。

### 本版已披露限制

- 0.8.1-preview.1 一节列出的限制全部仍然适用。
- 程序只能证明属主在提议之后说过话，同意还是拒绝由模型理解；每次生效都记录提议和属主的原话，页面上看得到。
- 页面改规则靠 DSH 界面的登录；和界面同一系统用户、能读到登录 cookie 的进程不在这项检查的防护范围内。对话改规则不受影响。

## 0.8.1-preview.1（预览版，已发布到 npm 的 preview 标签）

- 状态（2026-11-09）：标签 `v0.8.1-preview.1` 指向 4efc1f6。2026-11-09T06:40:21Z 发布到 npmjs，dist-tag 为 `preview`，`latest` 仍是 0.7.0。shasum `e962e8e52433ddc09b6aab246d396d1d9e36702d`，integrity `sha512-ERj1ydkRiWgO3rYcf7bQCManbnYQiGfBn3Iv9d8rS/jG5OZMD5rGZdmFeV4Kzr+oopgR2ZKvm4h56LT2ffwWfw==`。从 npmjs 回读的包与审计过的包逐字节相同。未发布到 Gitea 私仓。
- 安装时写死版本号，并显式指定作用域 registry：`--@nelsonlongxiang:registry=https://registry.npmjs.org/`。
- 下文是发布前的候选说明，原样保留。


- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。这是 0.8.1 的预览版：npm 上用 `preview` 标签发布，`latest` 不动，要装必须写明版本号。相对已打标签、未发布的 v0.8.0（d691926 → 3fd979f），合入 #425–#522。CLI、回执协议、账本与信箱格式都不变；改动集中在可选的 superagent 团队，另有两处移除（见下）。
- **0.8.0 不发布，由 0.8.1 取代。** v0.8.0 标签保留不改写；npmjs 上从 0.7.0 直接到本预览版。0.8.0 一节的全部内容都包含在本版里，升级、回退照 [0.8.1 升级检查](ops/0.8.1-upgrade-check.md)。
- 默认不变：不配置 `superagent: true` 的宿主不受 superagent 改动影响；native-teams 桥与办公室舞台的移除对所有宿主生效。本节是候选说明；版本号就位不等于发布或部署授权。
- 验收：每条现场验收的结果记在发版 PR 上。

### 工单跟随 PR，并可送审（#516、#517、#519，设计 [superagent-pr-follow](design/superagent-pr-follow.md)）

- 成员用 `a2a_ticket_report` 的 `pull_request` 报告它开的 PR 后，工单等到这个 PR 合并或关闭才结束，等待期间不占成员。请求方在此期间收到的是确认（acknowledged），PR 结束后才收到正式结果。
- 团队宿主用运维者登录好的 `gh` 读这些 PR（60 秒一轮，读失败退避到 15 分钟，并显示在「团队」页；读失败不会结束工单）。插件不存令牌。
- PR 上的新评论和评审会送回工单的成员。只有 `allowed.github` 里的登录名算人，默认为空。
- 成员用 `a2a_ticket_ack` 接手 PR 上人写的评论时只做记录，不往 PR 上发内容；接手后工单等成员报告完才结束，没接手的评论在工单结束时交给总工（#519）。
- 设置 `reviewer`（一个 A2A 地址，须在属主的链接集内）后，每个工单的 PR 在每个新 head 上都发一次送审请求，只带 PR 引用。评审结果显示在「团队」页和工单上，只供合并的人参考：成员和宿主都不会合并。

### superagent 团队：现场运行修复（#494–#501）

- 暂停团队会同时暂停派工；团队画布由属主管理，舰队的画布操作不能改已绑定的团队画布（#494）。
- 成员的槽位跟随它的回合；`a2a_ticket_report` 必须写明工单号（#495）。
- 属主可以在「团队」页回答 agent 发起的工单的提问；从终端（`a2a-net` 经属主凭据）提的需求算普通消息，不算人；后续消息先确认，工单结束时再给正式结局（#496）。
- 团队宿主改了 `dshHome` 时也能读会话日志；规划视图给远端成员标「成员 · 仓库（远端）」（#497）。
- 成员的例行步骤自己选默认值，只把必须由人决定的事提上来（#498）。
- 规划视图的节点卡片加高到 68px，分三行显示名字、角色、描述和工作状态，角色标签不再把成员的名字挤掉（#521、#522）。已保存的布局不用动；上下间距小于 68px 的卡片可能略有重叠，「一键重排」按新高度排列。
- 写错工单号或候选号会被拒绝，并列出当前开着的编号（#499）。observe 模式下，总工按卡片的写法把「本来会接」的候选判成 accept 并写明规则（#501）。

### CLI（#513）

- 空的环境变量按未设置处理；`report` 发到 CLI 所在主机的 zone。

### 移除 native-teams 桥
- `@nelsonlongxiang/dsh-native-teams` 早已弃用，对接它的桥一并移除：`nativeTeamsA2a` 服务接口、`src/teams-bridge.ts`、`src/legacy/teams-bridge-inbound.ts`、路由里的三处分支、目录里的注册表行，以及配置 `nativeTeamsInbound` 和 `nativeRoundWaitMs`（配置里还写着这两项的主机要删掉）。
- 接收端仍认老节点回复里的 `bridge: 'native-teams'` 标记：0.7.0 及更早、开着这座桥的对端，其轮次不发回执，不记成欠账。

### 许可证与办公室舞台（#470、#471）
- 包内现带 `LICENSE`（MIT）、`THIRD_PARTY_NOTICES.md` 与 `docs/licenses/`。
- **移除办公室舞台 `/__dsh_a2a_canvas`**：`stage/` 子包、`assets/stageDist` 与该路由一并删除。它自工作台上线后没有入口，只是展示页，也是 LimeZu 贴图等第三方义务的来源。组队、规划板和 `/__dsh_a2a/canvas-layout` 不受影响。书签指向该地址的用户请改用工作台 `/__dsh_a2a_nexus/`。0.7.0 及更早的发布版和此前的 git 历史仍含这部分内容。

### 属主重判与总工备注（设计 superagent-reevaluate-note）
- 属主可让总工重新判断一条被拒的需求：团队页「提需求」的线上「重新判断」，控制面 `{ action: 'reevaluate', trigger_id }`，或 `a2a-net superagent reevaluate <trigger id>`。总工收到时卡片标明是复判。已经拿到正式结局的 A2A 消息不重判（任务已结清，请发送方重发）。
- 总工新工具 `superagent_note`：给在办工单的成员补一条事实（成员收到「note from the router」），只告知、不授权。
- 总工预设人设与 #456 后的卡片口径对齐：重复请求并入，不再接第二张。

### 配置承诺按文档生效（属主裁定 #453、#454）
- `asyncNudgeDelayMs: 0` 现在真的关闭催办（此前 0 会立刻催办，与 README 和配置注释相反）。已配成 0 的主机升级后不再催办。
- 属主面板热改 `teamScopeInfo` 后，`a2a_status` 与 `a2a_probe` 也立即按新值收窄或放开（此前只有 `a2a_teams` 即时，另两个读启动值）。

### superagent 总工看得见自己读到的东西（总工判断力验收）
- 修正：superagent 各工具此前只把「ok」交给模型，总工用 `superagent_read` 读到的工单与候选、`superagent_route` 的工单号和被拒项都看不见。现在模型看到调用返回的内容（JSON，超过 12,000 字符截断并注明）。
- 候选卡片列出团队在其他会话线上的在办工单（最多 20 张，新的在前）；与在办工单重复的请求要并入（`attach`），不再接成第二张。
- 候选卡片写明：人只提问、不要求干活时，用 `superagent_reply`（`answer`）回答后仍要用 `superagent_route` 判为 `ignore`；每个候选都以一条 route 结束，否则到期后回来重判。
- 总工转问（`superagent_reply` 的 `attention`）：发给人的只有正文；正文里没有成员问题原文时，宿主把原题放在正文前面，人在自己的会话线上就能看到要回答什么（验收 RJ8）。
- 团队设置改动会告诉受影响的在办工单（上游 PolicyEffect）：工单所依据的规则改了或关了、团队不再接 agent 发起的工作（接收模式不是 auto）、请求方不再被允许发起工作——成员收到一条用文字写明的 `[superagent input]`；只告知，不停止也不扩大工单。此前宿主改设置时不告诉在办工单。

### superagent 团队：智能体预设（#432、#437、#438）

- 插件在 bundle 层随附两个智能体预设：`superagent-router`（总工：文件只读，前台命令与等待最多 5 秒，不开子代理）和 `superagent-member`（成员：工作工具，前台命令 5 秒后转后台，不开子代理），改编自上游 dsh-superagent 的主会话与执行器预设。角色边界由预设本身决定，不靠卡片里的提示词。
- 宿主在保存设置、画布加成员、`serve` 时核对：总工或成员的会话跑在别的预设上就拒绝；为别的团队服务的会话不是成员预设时不接新活（停止仍可达），状态报 `servesProblem`。未加载的会话、或宿主没有预设注册表时不检查。

### superagent 团队：团队就是一支画布团队（v5，#441–#447）

- 属主在画布上组队（总工与成员，本机或其他主机），在「团队」页绑定画布并从中指定总工；成员从画布读出、不再在设置里点名，`add-remote-member` 取消（远端成员就是画布远端槽，公钥由画布钉住）。画布增删成员即成员池增删；工单进行中被移出的成员收到停止通知，工单在另一成员上重派。一个会话只担一个团队角色。
- 团队的 A2A 地址就是画布地址 `<zone>/canvas/<名字>`（其他主机写 `@<fp8>`）。发到这里的请求进团队信箱、不落成员会话；团队的回执和后续由宿主进程面代团队发出（`onBehalfOf` 按请求方原样拼写），请求方账本按 host-face 结清。直接发给团队内部句柄被拒（`[superagent-team-address]`）；同步路由立即答复已送达。
- 其他主机上声明了团队的会话可向团队画布提需求（需要团队宿主属主以画布远端引用建立链接）；请求方主机只把团队的代发回执当作那一条请求的答复接收。
- 成员主机按画布 id 为团队服务：`serve { team: '<zone>/canvas/<名字>@<fp8>' }` 取代 `serve-team`。
- 规划视图标出团队画布（「superagent 团队」）和总工、成员的角色与仓库。
- 设计记录见 [superagent-v5-canvas-team](design/superagent-v5-canvas-team.md)。

### 从 0.8.0 之前的团队升级

- 升级后团队处于未绑定：存着的总工保留，存着的成员池丢弃，在途工作留在原成员上不动。属主在画布上组队并绑定后恢复；请求方改用画布地址；成员主机用 `serve { team }` 重新服务。

### superagent 团队：运维负载暴露的问题（#427–#436）

在本机运维团队（真实仓库的文档核对工单）上跑出来的问题，逐个修复：
- 团队地址收到的每条 A2A 消息都有正式结局：不接的（observe、名单外、agent 不能给的停止、总工忽略）收到带原因的 `rejected` 回执；作为后续送进工单的，在成员拿到后收到 `completed` 回执。此前这些消息在发送方一侧只能变成死信（#431）。
- 成员按仓库分工：设置里给成员标 `repos`，总工接单时写明仓库，工单只派给该仓库的成员、排队时不挡后面的工单（#429）。
- 派工卡片：worktree 建在 `.worktrees/<工单>` 并写进 `.git/info/exclude`，在成员沙箱之内（#434、#436）；成员自己报完成或 dropped 后不再收到「已不归你」，省掉一整轮模型调用（#436）。
- 总工卡片写明「一个需求一张工单、不拆、不写计划」优先于其他技能里的路由说法（#427）；成员提问的答复按真实 attention id 识别（#428）。
- 工作台「团队」页：轮询不再每 3 秒重建页面（不丢点击、焦点和输入）（#425）。
- 测试：等待统一用 `vi.waitFor`（#426）。文档核对的 worker PR：README_zh 的安装与「你能得到什么」两节按代码改正（#430、#433）。

### 0.8.1 已披露限制

- 0.8.0 一节列出的限制全部仍然适用。
- 预览版尚未在两台真实机器之间验收：跨主机成员的现场验收是同一台机器上的两个宿主进程。
- 工单跟随 PR 依赖团队宿主上已登录、能读到目标仓库的 `gh`；读不到时工单保持打开，「团队」页显示原因。
- 总工和成员都是长期会话，上下文会一直增长，插件不主动压缩或换会话，靠宿主自身的压缩。验收环境里总工跑到约 53 万 token（配置的上下文窗口为 100 万）时还没有压缩，单步耗时没有因此明显变长；几个大上下文会话同时用一个模型服务时，单步会到几分钟。
- 一次批量并入工单的多条消息，成员只看到第一条的正文。
- 成员报告转给总工的那一步不持久，团队宿主此时重启会丢这一次转告（工单和报告本身还在）。
- A2A 线上的往来不在「团队」页显示。总工接单时写的备注和名字不会带到工单上。工单结束不通知总工。
- 跨主机成员拿不到团队授予的文件。上游的 `dismiss`、`unsubscribe`、`markUnrelated`、`followForContext` 未接入。
- 预设核对依赖宿主的预设注册表（`agentPresets.inspectCompositions`）；没有时不拦截，只靠角色工具守卫。
- 画布团队由团队宿主独有；多主机共有一支画布团队不在本版。
- 名片 `superagentTeam` 是未签名发现数据，只放宽请求方自己的发送侧范围；送达与结清仍由目录（按名片归属）和团队宿主的准入、请求方的回执核对决定。
- 机器（A2A 机器名单）发起的工单，成员的提问回到请求方的 A2A 会话；请求方是机器时，系统里没有人能回答，工单停在「待你回答」，没有超时或升级。运维使用时把需要人裁定的问题放到人所在的地方（如仓库 issue）。

## 0.8.0（已打标签，未发布，由 0.8.1 取代）

- 基线：next/0.8 合入 master 后的合并提交（候选提交在发版 PR 里写明）。相对 v0.7.0 合入 #372、#375、#376–#423。选 minor：新增 CLI 命令与回执信封的 `disposition` 键（对外契约变化），新增可选的 superagent 团队。
- 默认不变：不配置 `superagent: true` 的宿主不加载团队引擎、不建团队地址、不改路由。
- 升级、回退与可复现打包见 [0.8.0 升级检查](ops/0.8.0-upgrade-check.md)。本节是候选说明；版本号就位不等于发布或部署授权，tag、发布与部署另行安排。

### superagent 团队（可选，`superagent: true`；#409–#422）

按 superagent 自身的定义实现：领域层是原样内置的上游引擎（`src/superagent/upstream/`，钉住 8c32a9d，`scripts/superagent-upstream.mjs` 守住逐字节一致），a2a 只做传输层。

- 一个需求一张工单：总工（router）只决定接不接、结不结，不拆任务、不写计划；成员是属主指定的固定会话池，一人一个名额，满了排队，从不新开会话（#410、#413）。
- 需求来源：工作台「团队」页和 `a2a-net superagent request`（属主凭证，明确授权）；A2A 团队地址由宿主持有的 CLI 身份承接，按机器名单与接单模式（off / observe / auto + 规则）判定，接收不占目标名额（#411、#412）。
- 跨主机成员：派工与报告是钉住公钥的签名宿主间请求；未签名或签名不符一律拒绝并计数（#414、#417）。
- 角色工具：总工只见 `superagent_*`，成员只见工作工具与 `a2a_ticket_*`，由宿主全局守卫执行；可见性按会话自己的作用域收窄（#415、#418）。
- 人的追问按 trigger id 被成员接下（`a2a_ticket_ack` / `a2a_ticket_handback`），成员读到即标记；工单结束时仍未读的追问交总工评估，不丢（#419）。机器的消息只作上下文，不能经成员以 dropped 结束工单（#420）。
- 请求方确认：机器的请求成为工单时，团队发一张 `acknowledged` 回执（任务 `ack-<task>`）。请求方的欠账不结清，退出队列计数，过期改为确认后 7 天。工单出结果前的回复（成员提问、通知）作为同一会话的后续消息发出，正式回执留给结果；工单不经结果就结束（停止、关闭或总工未转发）时，宿主自己补发结束回执（#421、#422）。
- 工作台「团队」页：待你处理、需求、工单、团队、设置五个视图（#416）。
- 验收：判据 v4 共 31 条（需求→工单、固定成员池、结果回到原线程、追问、排队、问答、拒绝与计数、跨实例成员、CLI 与机器、请求方欠账的确认与过期），两个实例上的全新一轮全部通过；运行与归档留在验证器工作区。

### CLI 与回执（#379–#399）
- `a2a-net inbox --after <cursor>`：调用方自持游标的可重放读取，报告被上限挤出的条数（#379）。
- `a2a-net route --json` 附 `class: sent | gone | retry`（#381）。
- `a2a-net thread <context_id>`：按 context 只读读取一段往来（入向邮件 + 本身份发出的路由），分页（p1-context-read）。宿主从这一版起在每条 CLI 邮件上记 `task_id`、`context_id`，wire 面投递到邮箱的应答也带回 `context_id`；老宿主投递的邮件没有这两个字段，`thread` 计入 `unscoped`。CLI 在身份目录下新增 `sent.jsonl` 发件日志（0600，1 MiB 轮转一代，只在本机）。
- `a2a-net receipt <task_id> [--attention] <一句话>`：CLI 身份发正式回执的唯一命令（p1-receipt-cmd，回执语义变化，S14）。回执 v2 信封新增可分支键 `disposition`（`result` / `attention`，闭集），既有 `outcome` 不变；attention 回执结清原任务但不写 outcome，账本归档行、`tasks --json`、`a2a_tasks`、CLI 信箱里的回执行都带 `disposition`，attention 行显示为 `unclassified`，不显示 completed。回执走固定 task id `receipt-<task_id>`，一个任务只有一张回执。旧主机忽略这个新键，仍按头行结清。见 [receipt-envelope-v2](protocol/receipt-envelope-v2.md) §2a。
- CLI 信箱行新增 `proof` 与 `receipt_for`（p1-mail-proof，S18）：宿主把它接收投递时已算出的来源校验结论（wire 面与正文头一致；本地面为 `in-process`）和回执所回答的 task id 写成字段，读者不再解析正文。快照恢复时 `proof` 只收已知取值。`thread` 的入向条目一并带出。准入与正文头不变。
- superagent Source 的类型基础（p2 设计 G2）：`src/superagent/source-types.ts` 声明 a2a Source 所用的最小结构类型；`src/superagent/upstream/` 放一份 superagent 类型快照（钉住提交 8c32a9d，MIT，许可全文随快照），`src/superagent/contract.ts` 在类型检查里把两边对齐，运行时契约测试核对 `key`、`threadKey`、`health`。不引入 superagent 的构建链或 npm 包，构建和测试都不拉取上游。尚无 Source 插件代码。
- superagent a2a Source 插件 `./a2a-watch`（p2a-source-code）：独立导出入口；0.8.0 起由 superagent 团队宿主在 `superagent: true` 时承载（#412），其余宿主仍不加载它。以下为其最初（影子阶段）的说明：影子模式只有 observe，Channel 拒绝所有地址，从不回发；可信来源只认信箱行 `proof` 为 origin-claim 或 in-process。只合入 next/0.8，不随版本发布、不上节点；上节点运行（p2b）另须属主选定节点并经全局放行。接入说明见 [superagent-a2a-watch](design/superagent-a2a-watch.md)。

### 路由（#372、#375、#405）

- 进程内投给普通 CLI 信箱的消息不再记欠账（#405）。
- followup 抛异常后的宿主接纳观察：只有本次预留的精确会话/MessageId 出现在该会话 inbox 或事件流，才返回 DELIVERED 与 `acceptance:inserted`，提示后续未确认、原 task 对账；不代表消费或完成。证明不了仍失败并带 `acceptance:unknown`，提示“接纳状态未知，请用原 task id 对账，不要换 id 重派”，新调用方停止候选 failover；已知插入前拒绝不改。契约与旧客户端限制见[接纳观察](protocol/followup-admission.md)。不新增状态，0.2.2-rc.1 仅源码判断、未运行验证，不进入0.7.0。
- 已披露限制（#375，全局 2026-11-06）：返回 `acceptance:"inserted"` 时，主机已接纳输入；但如果接收方没有出生行（例如出生提交失败），这一笔不会触发 nudge，也不会挂自动回执，只能由人按原 task id 人工对账。
- 节点升级说明（#375）：旧主机（0.7.0 及更早）不认识 `acceptance:"unknown"`，收到后仍可能 failover 到其他候选目标。新主机才会停止 failover，并提示“接纳状态未知，请用原 task id 对账，不要换 id 重派”。建议调用方和接收方两端都升级。

- 普通 Agent 同步等待的主机占位输出（flush 超时、会话 dead、aborted / failed 读取轮、textless）返回已有 `TASK_STATE_DELIVERED` 且不带 `reply_final`。CLI 与 `a2a_route` 同步路径提示“已送达、未得到最终答复，请按 task id 对账”，不是失败重投或完成。已有出生/自动回执的 forwarded sync 带 `receipt:routed` 并保欠账；plain sync 不新建出生/自动回执，带 `receipt:none`，调用方记可见 receiptless 行而不计欠债。除明确 `receipt:none` 的非债兼容路径外，只有复用现有阅读轮归属得到的真实 own-turn final 才允许把普通同步答复当已付。native-teams 权威 round 与 CLI mailbox 接纳语义不扩大变更。
- 新版 CLI 的 sync 转发等待超时由原来的非 0 退出码改为退出码 0，并提示“已送达、未得到最终答复，请按 task id 对账”，依赖退出码判断成败的脚本需要据此调整。
- HTTP 等待和自动回执用途分离：等待到期不删除后续 receipt 归属跟踪；后者按原任务终态、取消、TTL 或卸载清理。晚到真实读取轮 final 仍走同一固定身份回执和原有有限退避；占位、未消费、已关闭的空/失败读取轮不生成正式回执，不采用其他任务/后续轮输出。#351 提醒只提示本人对账，不新造正式回执。
- 旧客户端兼容：0.7.0 及更早 CLI 收到这种含 `result.text` 的 DELIVERED 同步响应时会打印回复并在 stderr 提示未 settled，通常退出0，不自动重投；旧 `a2a_route` 返回 `ok:true` 和 DELIVERED，保留可路由回调的欠账，但旧 `trackOwedTask` 不识别 plain sync 新的 `receipt:none`，仍可能挂幽灵债；因此普通同步两端也应同步升级，不能仅凭旧文案当完成。旧版没有新的明确中文同步对账提示。如果走旧客户端的 `delivered:true` 分支，其文案可能仍称 async；以状态/task id 对账，不能把主机文字当业务完成。旧转发 home 若误收到旧对端的无 `reply_final` COMPLETED 仍可能按旧规则 receiptless，因此建议两端同步升级；本候选不改0.7.0已构建字节或代替后续发版授权。
- 边界见[同步回复契约](protocol/synchronous-reply-contract.md)。同步回复片段不涉及 followup 泛化 throw 的接纳未知（本节另列接纳观察候选）；#369已覆盖窗口、不自动补出生及重启不恢复补发定时器等边界不变。不新增任务状态，不 tag / publish / 部署。

### 工作台（#407、#416）

- 「节点」面板的行内按钮不再被挤出可见区（#407）；「团队」页见上。

### 0.8.0 已披露限制

- 请求方确认需要两端都是 0.8.0：0.7.0 及更早的请求方宿主不认识 `acknowledged`，会把确认当普通回执直接结清，之后的结果作为迟到回执更新。建议团队宿主和请求方宿主同时升级。
- 回退到 0.7.0：0.7.0 读得出 0.8.0 写的全部欠账与信箱行；一旦 0.7.0 写过账本，`acknowledgedAt` 与归档行的 `disposition` 丢失，已确认的欠账回到 24 小时过期（按派发时间算）。信箱行的新字段 0.7.0 原样保留。`<a2a home>/superagent/` 目录 0.7.0 不读也不删。
- 角色工具的可见性收窄依赖宿主工具运行时的 `restrict` 与会话作用域；缺这两样时只靠全局守卫拒绝调用（日志记一条），不隐藏工具。
- 结束回执：工单以完成、合并或 dropped 结束而总工 5 分钟内没转发结果时，宿主补发的结束回执只带结局和最新报告摘要，不是总工写的结果。

## 0.7.0（已发布；部署后核对已结案）

- 状态（2026-11-07）：标签 `v0.7.0` 指向 c12c299。2026-11-07T02:33:53Z 发布到 npmjs，shasum `3e633c89a8064707707aa72b495fd2f05c29f093`，integrity `sha512-Jmv/nlADKLV07maFfDszvjCfYC3n1fKvxUj25cjdQV9hjeyQb014ac+M0DmuUWAyP2OYIqyRdW+Grx/EKCdn0Q==`。在没有作用域 registry 配置的机器上做过两次独立回读，字节都与验收包一致。
- 安装时请写死版本号，并显式指定作用域 registry：`--@nelsonlongxiang:registry=https://registry.npmjs.org/`（作用域 registry 配置会覆盖 `--registry`）。
- 下文是发布前的候选说明，原样保留。


基线 8a0403d，相对 v0.6.43 为 54 个提交、19 个 first-parent 提交。全局选择 minor 版本：本版改变入站准入、任务投递及失败时的对外契约。高档发版材料须非作者精确头 PASS 后报全局，回复后才能合入；版本就位不等于发布或部署授权。不碰凭证，不补生产积压。

升级/回退与只读核对步骤见 [0.7.0 升级检查](ops/0.7.0-upgrade-check.md)。以下汇总 #353–#370 已合入变更，保留已披露限制；其中 issue 号与实现 PR 号范围并非每一个都有独立产品变更。

### #364 入站校验完成边界

- 带任一 OriginClaim 字段必须在本请求内完成有界校验；失败、超时、名片读取不成功先拒绝，返回明确错误，不退化为无信封放行。带成员句柄或同 zone 声明且有信封的请求必须 bound，v1 unbound 不获该放行。
- 当前准入使用 fresh card，不用旧发现缓存代替当前签名验证；卡读取及正文均受本地预算约束。完全无信封的旧兼容窗口本版没有自动关闭，仍由 originClaimWindow 与原迁移计划管理。不能把“必须 bound”误读为本版强关了所有旧无信封入口。
- 主机所写完整签名与目的端 audience/路径/正文保持绑定；本版不要求给 teamless 原接收会话额外入团才能支付其自身任务回执。

### #353 / #354 / #358① 解码和账本提交

- 会话日志解码在分配输出前施加上界，压缩输入不能借先分配后检查突破上界；超限显式失败，不静默生成截断的伪内容。
- tasks 以临时文件写入、fsync、原子 rename 提交；失败恢复最近成功账本快照并 fail closed，不伪结算或送出成功确认。只有 EPERM/EBUSY rename 瞬态错误作毫秒级有界重试，其他错误及耗尽继续失败。
- 回滚边界是账本自身，不是跨 Agent/HTTP/幂等存储的总事务。[附带状态清单](ops/358-rollback-side-state.md) 与下列 receiverBookkeeping 契约明确不确定观察；诊断不等于业务成功。

### 路由接纳与接收方记账观察

- 已接纳但接收方出生行提交失败时明确 `receiverBookkeeping:failed`，仍是已投递而非已完成；CLI/a2a_route 提示“已送达、接收方记账失败，请对账，不要重派”。调用方保原债，不按同步 final 结清。
- state/status 展示孤儿映射计数和运行时安全失败诊断；用途元数据区分业务任务与 receipt-only occurrence，不新增任务状态。旧用途未知不逆造任务。
- 不自动补记出生，不重投已接纳工作；恢复磁盘/重启后仍需原 task 对账。[路由契约](protocol/route-bookkeeping-observation.md) 明确兼容、恢复与保留窗口限制。
- 回执消息（`[A2A receipt] task …`）到达接收方时不再挂自动回执；自动回执改为只在入站出生行提交成功之后、且仅对非回执消息挂起。未记账的投递不会凭空产生自动回执（与 #141「回执不欠回执」一致）。
- 本节是 0.7.0 已合入的候选契约，不代表生产部署授权。

### #357 暂时失败的回执补发

| caller档结果 | 旧行为 | 本修订 |
|---|---|---|
| 503且正文明确账本写失败；校验未完成错误码；超时/连接失败 | 进入owner回执阶梯，可能本机结清 | 保持pending + receipt-undelivered，owner只收非回执通知，主机有界退避重发 |
| 授权/未知任务等永久拒绝 | 原回执阶梯 | 保持原阶梯，不新增重试；对端settlementRefused仍不是caller支付成功 |
| 对端已接收、确认答复丢失 | 无固定身份，可能重复投递 | 同一transport身份及正文重发，当前来源与已完成关联确认后不重复送入会话 |

- 自动补发仅由主机执行，间隔1/2/4/8/16/30秒，最多初次加6次；耗尽/插件停用停止，欠账仍可见，重启不自动恢复本实例重试定时器。固定transport身份和正文，不改业务task id，不把owner通知当正式回执。
- 对端离线等连接类失败以前可能经owner档立即本机结清；现在先按累计约61秒的退避间隔重试（另加每次网络等待时间），耗尽后保持pending + receipt-undelivered，由#351空闲提醒继续催会话本人；不会仅因离线而本机结清。等待正常到期即注销上下文清理effect，卸载时取消尚未结束的定时器。
- #351仍只提醒本人对账，主机补发不增加reminderAttempts或nudge计数。预算耗尽不代表已结清。
- 此为 0.7.0 对外结算语义变化；本准备阶段不发布、部署或补历史积压。

### #355 + #358②

- 状态面与 `a2a-net status` 文本/JSON新增 `nudgeEscalations`：queued、unavailable、failed及最近观察时间/安全错误码；计数为本次插件实例内观察，重启归零，不代表任务完成或消息已消费。queued是prompt调用已成功返回（明确拒绝计failed），未返回的请求不伪记成功。
- `ledgerPersistence` 同步进入 status 工具和 CLI 文本/JSON；失败显眼标识，诊断仅时间与允许的错误码，不含路径/正文。进入失败态警告一次，成功提交清除诊断后可再次告警。nudge缺接口和失败告警仅team/nudgeRef/安全码。
- #355/#358②本身只加观测，不改提醒调度/投递、结算、准入、账本回滚或执行名额。#358③清单列出已围栏与另案边界，不能因发布说明覆盖就关整单。

### #362 关联回执返回

- 恢复原任务绑定的正式回执返回，保留当前来源校验、冻结接收者与返回目标检查；普通投递权限不扩大。
- 本地已答而回执未确认的欠账显式显示 `receiptDelivery:receipt-undelivered`，状态与 CLI JSON 持久可查；不把 answeredAt 当送达证明，不改变原执行名额语义。
- 历史积压不靠该修订补结；发布物复核前不因候选合入而关闭 issue。

### #356 带来源的 followup 投递

- 任务同机/跨机、同步/异步均通过 `Agent.followup` 保来源排到独立下一轮；冷会话先走原 resolver。缺方法明确拒绝，不退回 steer、不排裸 kind:user。空闲对账提醒及本机发送方警示一并切换 sourced followup；提醒原空闲门/计数规则不变。
- 原子保存 taskId/MessageId/完整SessionId 对应，写失败不投递；已入队但最后记账未确认时保 reserved/unknown，不盲重发。未消费撤单用 updateQueue remove；竞态已claim与已消费任务仍即时steer停工。撤单保持结账优先：原cancel提交后通知尽力而为。新对端用原caller/key/body绑定控制，旧对端发原无task_id文本通知；目标消失或通知失败仍清caller行，但不假称消息已移除。任务投递缺followup仍明确拒绝，绝非steer兜底。
- 双端账本保存 consumed 观察，state/tasks/CLI 显 consumed 或 delivered-unconsumed。发送方只是本次peer答复快照，接收方可在确切claim后更新；未提供字段的旧peer仍未知。3条名额、receipt授权、15秒同步预算/-32005、S5/305/306归属不放宽。
- 旧reminder lastResult blocked不再是可写类型，旧盘按metadata-reset第3次/2h长退避恢复；只在业务终态停止。这是 0.7.0 minor 契约变化，生产部署和存量操作另报；本准备阶段不发布/部署/补现网积压。

### #351 持久空闲对账提醒

- 主机仅在真实空闲时以带 A2A 来源/血缘的 followup 提醒会话本人逐条对账；忙时不注入、不计次。每会话多条欠账合并一条，原文 brief 最多160字符；不读日志代补、不发 ack、不自动撤单或结算。
- 次数/接纳观察、最近时间与下次提醒持久保存，前几次退避，第三次后长间隔约2小时持续提醒；直到原pending进入既有终态才结束。多次未对账可见并给本机发送方一次警示，不新增远端推送端点。
- 提醒不是任务、不产生欠账/不释放名额；3条上限、queuedFor计法、回执格式/授权、同步预算及消费轮归属不变。0.7.0 已随 #356 切为 sourced followup（仍只在真实 idle 触发），不裸排 kind:user。
- 提醒reserve先原子提交，写盘失败内部catch、不发送，状态显安全时间/错误码。元数据兼容旧账但无法唯一定位目标时只诊断；不触碰现有生产积压。代码合并/候选不代表生产部署授权。

### #334 / #350 同周期画布来源确认

- 新增普通会话成员 `zone/id8@fp8` 来源选择器与完整 SPKI 公钥锚；本机会话 picker 仍存完整 id，跨主机编辑不再新写未确认裸句柄。远端必须是已有可路由 seed/delegate 且当前有效名片能证明所选 host 的成员；minimal/离线/第三方无法验证时可见拒绝，不强取隐藏字段。
- 工作台逐槽位“确认来源”带 revision/原成员/原 owner CAS，原子替换保顺序并迁移暂停原因；确认不等于恢复，rejoin/普通重复 add 不确权也不恢复。已钉来源不能静默换 key；需要操作者检查后显式删除旧槽位，再添加有证明的新来源。
- 来源不明的历史裸成员在默认兼容窗口内保留旧读法，显示“来源未确认/兼容推断中”与统计；窗口关闭时不路由不授权，暂停始终无效。默认值仍 true，不按时间自动关闭、不替属主翻转。
- qualified 路由先选完整 owner key，再把 plain handle 发给选中且声明来源能力的 host；旧 host 可见拒绝并提示升级，不剥后缀向任意候选回退。CLI deposit/home、canvas-team @fp8 与旧债规则保持独立。
- 已有远端 `zone/id8@fp8` 槽位若没有 `memberOwners` 完整公钥锚，升级后即使兼容窗口开启也不算有效成员；它不会自动获来源，须由操作者逐槽确认。兼容窗口只保留历史裸 handle，不覆盖这类缺锚 qualified 记录。
- 不从升级回溯修复已丢成员；持久化仍用 v2/首次备份/磁盘 CAS。回滚须停写恢复备份，不准降级覆写。生产未部署。

## 0. 0.6.43 升级提示

**画布成员暂停（#335 / #338，数据安全修复）**：

- 本机 leave、archive 与按 session id 移除成员，不再根据卡片缓存推断删除裸句柄：只删本机精确 id / 无歧义的本机 @fp8；推断裸槽位保留并持久暂停。暂停后不路由、不授权、不计有效成员，也不经 rejoin/重复 add/重启恢复，须在工作台检查队伍后由操作者显式恢复或删除。
- #334 上线前，对端用裸 handle 删除属主按完整 session id 存的本机成员会可见失败（`ok:false`、成员保留），需要到属主本机明确删除；不再根据缓存推断连带删另一个槽位。
- `canvasLegacyBareMembers` 默认 `true` 保持未暂停裸成员的旧推断；state 有存量、实际解析、碰撞告警、暂停数与 epoch。当前不自动翻默认，不完成 #334 的来源确认或 qualified 路由。
- 首次写入 canvas formatVersion=2 前留 `.pre-v2` 备份；暂停与成员同文件原子提交、磁盘版本冲突拒写。暂停写失败会拒绝撤销成功回报，并暂时关闭本进程画布有效成员服务；修复文件后重启再检查。回滚旧版本须停写恢复备份，不能直接降级覆写。

**其他**：

- **fleet-canvas-op 非 2xx 一律按失败**（#320 / #326）：对端回 3xx/5xx 时，即使 JSON 体写着 `ok:true`，本机也报告失败并带状态码。
- **file fetch 认 home 声明的别名**（#332 / #333）：文件引用的来源若命中 home 自己声明的地址（`ownerHost` 或 `originClaimAudiences`），CLI 改从 home 的 URL 拉取，不再因同一主机的局域网 / Tailscale 双地址而拒绝；CLI 身份校验不放宽。
- **构建可复现**（#330 / #331）：浏览器 bundle 与 sourcemap 不再嵌入机器绝对路径；Windows 与 macOS 打出的包内文件 208/208 逐字节一致。
- **测试稳定性**（#325 / #329）：Windows 默认并发下的计时与 I/O 用例改为不依赖墙钟。
- 验证器：release-audit v2 新增 A8 判据（#336），评审席在同一候选上本地打的包与发布包的包内文件必须逐字节一致；本版起正式使用。

## 0. 0.6.42 升级提示

- **#312 名片隐藏内网引荐拓扑**：匿名、无效/过期签名以及与本机无关系的自签名陌生人均拿不到 `peers`。提供引荐须 OriginClaim 验签通过，且调用方是本机 `config.peers` 的显式 seed（根地址按 origin、挂载地址精确匹配），或既有 operator link 已成立；完整会话/组织字段仍须原完整名片链接门。现代签名取卡与双seed自举保留；仅匿名爬卡或未被对端seed/link的客户端须显式配置所需seed或建立链接，不提供恢复匿名拓扑的开关。签名 `discovery=1` 只减信息，有限回拨核同key/team，拓扑缓存不覆盖完整名片。
- **主机 team 兼容边界**：主机 `team` 必须满足 `^[a-z0-9-]+$`，不支持含斜杠的 `zone/canvas` 身份。启动会 warn，但不改配置、不拒启动或放宽签名形状；此类主机应迁到例如 `zone-canvas`。合法会话/画布路由名不因此改写，委派与签名核心不变。
- **打包换行一致**（#321）：新增 `.gitattributes`，文本一律检出为 LF，二进制资源不做换行转换。从这一版起，Windows 与其他平台打出的包应逐字节一致（构建时嵌入的源码路径注释除外）。打包机若是 Windows 上的旧工作树，需要先刷新检出，新规则才会生效。

## 0. 0.6.41 升级提示

- **安全（尽快升级）：对端请求不再跟随重定向**（#318 评审 R4）。以前所有对端请求都会跟随 3xx，`X-API-Key`（舰队 key 或链路 key）和签名头会被带到 `Location` 指向的主机；任何一个对端回一个跨源 302，就能把 key 引到第三方。0.6.40 及更早版本都有这个问题。现在所有对端请求都在 `peerFetch` 统一设置 `redirect: 'manual'`，3xx 一律按 HTTP 失败处理。**升级须知**：`peers` 里写的地址必须是对端的最终地址。例如走 Caddy 的节点要写 `https://域名`；写 `http://域名` 会因为被 301 到 https 而连不上。
- **#306 同步答复绑定消费任务的轮次**：带 task id 的同步请求只取真正读到该任务的轮次的答复，不再把目标正在处理的其他工作或下一轮的文字当成答案。同步等待与自动回执采用相同归属窗口；没有 task id 的旧调用仍使用原回落行为。
- **忙碌目标会有更多诚实的超时**：若真实答复超过既有 15 秒传输窗口，调用方可能收到 `-32005` / DELIVERED-UNSETTLED，而不是一段无关文字。投递不因此撤销；沿原 task id 对账，使用 async + inbox 等真实回执，切勿因超时新发任务。窗口和准入默认值不变。
- 回执仍完整保存；同步确实取得本任务的完成答复后，后续同任务回执继续按 #305 标记 `sync-answered`，不丢弃。placeholder、未消费及失败轮次不作为本任务完成证据。
- **链路 key `linkKeys`**（#317）：按对端单独配置 key，公网节点不必持有舰队 apiKey 也能互联。发往 `linkKeys` 里某个 origin 的请求带该链路 key；本机对端接口只在调用方 OriginClaim 验签通过、绑定到本次请求（受众绑定的 v2 信封，不接受只有 v1 的信封或挪用到别的路径的信封）、且签名者正是该 origin 时接受链路 key，POST 还要求 Sig3 绑定请求体；控制路由一律不接受。两端都要升级到 0.6.41，并配置同一把链路 key。不配置 `linkKeys` 的主机行为不变。
- **远端会话日志读取带上 key 和签名**（#318 评审 R2）：工作台读取对端会话日志的代理请求以前既不带 key 也不签名，对开了 key 的对端一直会 401。现在会带 OriginClaim，以及按目标选出的 key。
- 验证器：`scripts/verify-probe.mjs --release-audit` 留存发布物证据（#319），可以在发布后核对候选 SHA、tgz 哈希、文件清单、3081 验收以及两个 registry 回读的字节是否一致。

## 0. 0.6.40 升级提示

- **安全：反代转发的请求不再享受回环信任**（#308）。0.6.39 及更早版本里，同机反向代理（Caddy、nginx、隧道代理）以 `127.0.0.1` 连接节点，所有公网请求都被当成本机：配了 key 的主机会把 apiKey 写进工作台 HTML，没配 key 的主机控制面对公网完全开放。现在请求只要带 `X-Forwarded-For`、`Forwarded` 或 `X-Real-IP`，就不给回环信任；经代理带 key 访问照常可用。**对外开放的节点请尽快升级。** nginx 必须设置 `proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;`，Caddy 默认会带。经 pocket 隧道打开工作台不受影响（pocket 不写转发头）。
- **本机 IPv4 的选择改为局域网优先**（#311 / #313）。自动推导的 `lanIp` 按 RFC1918 → 其他非内部地址 → CGNAT（100.64/10，例如 Tailscale）排序，以前是取第一块网卡的地址；显式配置的 `originClaimUrl` 仍最优先。对端互联徽章把 `originClaimAudiences` 也算作本机地址。
  - **双网卡主机升级须知**：装了 Tailscale 的主机（如 .156），升级后名片地址和签名信封里的 `callerUrl` 会从 Tailscale 地址变回局域网地址。经 Tailscale 拨号的调用方（CLI、对端）会被计入 `boundMiss`，#64 关窗后会被拒；把 Tailscale 地址写进 `peers` 的对端，徽章会变回 stranger。解决办法：在该主机配置 `originClaimAudiences: ['http://<Tailscale 地址>:<端口>']`，升级后用 `a2a-net status` 的 `claims` 行（`boundMissInbound` 不再增长）以及 `peers[].link` 确认。
- **同步已答的转发，回执标为重复，内容不丢**（#298 / #305）。目标端只对“读到该任务那一轮”的最终答复带上 wire 字段 `reply_final: true`；home 把这份答复完整写回 CLI 后，同一成员发来、未被拒的回执原文照收，但标记为 `dup: "sync-answered"`，`a2a-net inbox` 折成一行显示，`--json` 给出整行。0.6.39 及更早的目标端不会发 `reply_final`，它们的回执一律不标记。
- **早到回执最多等 60 秒**（#298 / #300），等不到就按正常规则结算。这一项实际已随 npm 上的 0.6.39 包发出，见下节“发布偏差”。
- 测试与文档：CLI 子进程不再继承操作者的 `A2A_*` 环境（#303 / #304）；serve 测试的 Windows 路径断言（#310）；独立节点部署手册 `docs/guides/standalone-node.md`（#307，含公网 HTTPS 前置）。
- 无配置默认值变化；不需要回滚预案。

## 0. 0.6.39 升级提示（#282 做减法 S1–S3）

- **canvas 带属主指纹的 id**（S2）：`a2a-net teams` 以及状态面的 `canvas.teams[].id`、`peerOrg[].org[].id`，现在把 canvas 行显示为 `<zone>/canvas/<name>@<fp8>`（属主名片公钥的指纹）。`teams --json` 的 `team` 字段也是这个 id，读这个字段的脚本请按需取 `@` 之前的部分。不带后缀的旧写法路由行为不变。新建 canvas 不能再以 `@<8 位十六进制>` 结尾；已存在的同名 canvas 照常加载，用完整 id 访问。
- **同队即授权**（S3）：CLI 转发到远端 canvas 时，home 只需链接 canvas 的**属主主机**，不再要求逐个链接接收成员。成员回执只有满足以下全部条件才放行进 CLI 信箱并结算：来自转发出生时冻结的接收成员；由选中对端的名片公钥签名；签名为绑定请求体的 Sig3。因此**属主主机须 ≥ 0.6.37**，否则回执退回旧规则，需要链接成员。未链接成员发来的自由消息照旧需要链接。
- **拒绝给下一步**（S1）：转发、排队已满、准入、防刷屏的拒绝新增 `next` 字段，CLI 打印为 `[route] next: …`。拒绝原文与错误码不变；幂等 409 的响应体是冻结接口，未改。
- **独立网络节点 `a2a-net serve`**（#295）：不依赖 DSH 实例运行网络层，包括名片、对端目录、CLI 户口与信箱、一跳转发、canvas 归属、任务账本、状态面和工作台。它不托管 AI 会话，投递会话仍转发给 DSH 宿主。安装需要一组固定版本的运行时依赖，`installLine` 给出完整的 `npm i` 行（npm 上的 `latest` 标签较旧，不能用）。绑定 `0.0.0.0` 时必须配 `apiKey`。用法见 `references/cli.md`。
- **#291 兼容 harness ≥0.2.2-rc**：宿主的 `AgentRegistry` 没有 `roots()` 时，改用 `list()` 按委托深度过滤，会话发布和恢复不再因 TypeError 回滚（历史会话从列表消失的事故）。旧宿主语义不变。
- 本版无配置默认值变化，无需回滚预案。

**发布偏差（如实记录）**：npm 与 Gitea 上的 0.6.39 tgz（`dist.shasum 4799aa78…`）不是从 tag `v0.6.39`（bc8f423）打包的，而是从合并后的 master a2389ba 打包的，所以包内多了两样东西：
- #300：早到的转发回执等出生最多 60 秒，超时后照常结算。已评审并合入 master，行为是收紧。
- `nexus-stage/scripts/__pycache__/mockhost.cpython-312.pyc`：一个无害的多余文件。

tag 不移动，发布物也不撤回。0.6.40 起改为从候选 SHA 的干净检出打包，见 docs/release-gate.md。

## 0. 0.6.38 转发默认值升级提示

- **状态面 `boundMissRecent`**（#273，#64 关窗前置，0.6.38 起）：列出谁的绑定签名对不上、拨的是哪个 origin，`a2a-net status` 的 `claims` 下显示 `miss` 行。把列出的 origin 加进对应主机的 `originClaimAudiences`。

从 0.6.38 起，未显式配置 `forwardDirect` 的宿主会默认启用已实现的一跳 CLI 转发。0.6.37 及以前默认关闭；已有显式 `false` 保持关闭。升级不会新建链接或扩大作用域，仍须已验签、在线的本机 CLI 户口、发送作用域、双方运营者链接、DEFAULT-1 跳数预算；入站带 Guard 或 isolated 主机不转发。

**回滚默认行为**：属主在相同配置层显式设 `forwardDirect: false`，再按宿主既有的安全生效流程应用；无需倒退发行包或删除队成员。升级和配置生效由属主安排，不由会话自重启生产。不要随此升级把 settlementAuth 默认切 enforce；#272 必须先经独立评审。长转发任务推荐 async + inbox，15 秒 sync 超时不代表未投递。#275：启用 enforce 前先核对状态面的 `settlement.enforceBlockers` 为空；0.6.34–0.6.37 的旧转发 canvas 欠账缺接收成员事实时，拒绝的是 enforce 模式而非插件启动：运行态退回 observe 保持在线并记 error，状态面 settlement.mode=observe、enforceRefused:{reason,blockers} 列启动拒因和 task id，CLI tasks --json 原样带回（tasks/status 文本也可见）；保持 observe 对账处理（含 dead 未结行），不写回持久配置且清账后不自动升档，不得用当前画布成员补造旧授权。

## 1. cordis 归一 override 的单一归属纪律

overrides **只在 `pnpm-workspace.yaml#overrides`**（pnpm ≥11.24 读取）：

```yaml
'@deepseek-ai/cordis': 4.0.5
'@deepseek-ai/cordis-plugin-loader': 1.0.5
```

动机：图内 102 个 dsh-\* 包 peer 钉死 cordis 精确 4.0.1、61 个插件线 peer 要求 ~4.0.4，
范围互斥——无 override 的任何锁重生成都会双实例回潮（类型增广裂解 → 干净检出必红，
事故 0e32ae1）。锁重生成后以
`grep -cE "^@deepseek-ai\+cordis@4" node_modules/.pnpm`（期望 1）复核。

沿革：2026-10-21 立规时为「`package.json#pnpm.overrides`（pnpm <11.24 读取）+ workspace.yaml 双文件同值」。
**2026-10-25 起 `package.json#pnpm` 镜像退役**（gh#46 修复轮 a3a57b8）：pnpm 11.28 的 verify-deps
在该字段存在时拒跑一切 pnpm 脚本，且舰队三机已归一 pnpm 11.28.5、无 pre-11.24 读者。
现行约束（监督 S7 机器核对）：`package.json` **不得**再出现 `pnpm` 字段；`packageManager`
钉 `pnpm@11.28.5`，`engines.pnpm` 为 `>=11.24 <12`。

## 2. minimumReleaseAge × 锁重生成发布窗口

锁重生成会把「窗口期内的新版包」写进锁（如 fast-uri@3.1.9）；此后**所有**干净检出
`pnpm install --frozen-lockfile` 都被 minimum-release-age 策略拦死——不是缓存问题，
是策略按锁内版本的发布时间判定。

纪律：
- 候选期/发布窗口内做干净检出安装，统一带 `--config.minimum-release-age=0`；
- 无法带 flag 的环境（CI 模板等）：把窗口期新包加进 `pnpm-workspace.yaml`
  的 `minimumReleaseAgeExclude` 列表（现列 dsh-\* 0.1.2-alpha.3 六件）；
- 锁重生成提交前，本机跑一次干净检出 frozen install 复核（gold standard）。
