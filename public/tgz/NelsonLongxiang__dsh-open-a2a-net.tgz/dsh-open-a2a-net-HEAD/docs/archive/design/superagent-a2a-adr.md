# ADR：a2a-net 作为 superagent 的跨节点端口实现

状态：已接受，并分阶段实施中（见[实施计划](superagent-a2a-plan.md)）。配套文档：[接入规格](../../design/superagent-a2a-spec.md)。本版（r8）按 2026-11-07 的属主裁定修订，涉及 S21、S25–S27、S33、S36、S38。

实现核对（2026-11-18，next/0.8 `44907c00`）：p1 系列（#379–#398）和 p3（#402）已交付。后续形态已被改写：v4 把执行器内置进引擎（#409–#419），v5 改用画布团队（#441–#446），送审由 pr-follow 落地（#516、#517、#519）。本 ADR 作为来历保留，现行设计见 [v5 画布团队](../../design/superagent-v5-canvas-team.md) 和 [router-owner-asks](../../design/superagent-router-owner-asks.md)。

## 上下文

dsh-superagent 是单仓库、单主机的工作智能体：从 Source 接活，经 Eval 授权开工单，交给 Executor 执行，经 Channel 回复。它不负责节点发现、调用方身份真伪和跨主机投递；它的架构文档还把「Trigger 字段可信度」列为开放问题。

dsh-open-a2a-net 已经有签名身份、入站校验（失败即拒绝）、正式回执、账本守恒、强制对账和每目标 3 笔欠账的背压。

两者分工天然互补。属主的判断是：a2a-net 就是为 superagent 准备的基础设施。

协作规范 v1.18 规定，一个项目最多只有开发、评审两个角色，项目内的 A2A 只用于送审和上报（S37）。

## 决策

把 a2a-net 接成 superagent 的 **a2a Source**（入站和回发），不改它的领域模型，也不 fork 它。superagent 用本地执行器完成工作，不经 A2A 向远端席位派工；A2A 外发只有三种：回执与 attention、送审、上报（S38）。

a2a-net 一侧只补读取面、观察面，以及由宿主强制执行的声明：
- 调用方自持游标的可重放读取（`inbox --after`）、发送结果分类（`class`）、按 context 读取对话（`thread`）；
- 信箱行上的结构化事实：`proof`（宿主如何证明调用方）、`admission`（宿主准入时命中的规则），以及签名的准入复查入口；
- 正式回执命令 `receipt`：带 `disposition`、`--outcome`，回执走固定 id；
- 信箱欠回执声明 `publish --owes`：家宿主对已声明的身份回「已投递」，调用方记欠账，并受名额约束。

**信任**：可信来源为 {origin-claim, in-process, cli-identity}，且调用方必须在属主建立的链接集内（S36）。由 Source 的 scope 做确定性判定；superagent 以 auto 模式加唯一一条规则接单，强度为 inferred（S21）。

不新增任务状态，不放宽背压。每个阶段先过非作者评审和全局放行；影子模式运行满 7 天无异常、并通过 spec run 验收之后，才处理真实请求。

## 后果

正面：
- superagent 获得跨节点的可信身份和可对账的投递；派给它的请求进入强制对账，并受背压约束（S33）。
- 信任锚统一为属主建立的链接，消除了「同宿主 CLI 比外主机 CLI 更不受信」的倒挂（S35、S36）。
- 不做远端派工，L2 回环风险基本消失（S38）。

负面：
- 新增一个专用 CLI 身份需要运维，包括户口续期和信箱容量。
- attention 要借「回执 + 新任务」来表达，往返多一次。
- 每次回发前要多一次准入复查调用。
- 正式回执在 ready 时发出；如果工单之后又被放弃，这个结局只能用新任务告知（已知局限）。
- reply 模式要求 superagent 完成 setup，需要属主提供 GitHub 部署配置。

推迟项：
- 送审与上报通道（p4，另行设计）；
- 信箱 64 行上限是否调整；
- 欠回执的行被挤出时，是否通知调用方；
- Source 户口迁家时，入站行归谁；
- Gitea 等镜像通道。

已裁定（见[规格第 6 节](../../design/superagent-a2a-spec.md)）：S13（2026-11-06）；S21、S25、S26、S27、S33、S36、S38（2026-11-07）。
