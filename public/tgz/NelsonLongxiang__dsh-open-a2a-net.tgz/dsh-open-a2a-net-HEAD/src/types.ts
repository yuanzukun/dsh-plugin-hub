/**
 * Wire and configuration vocabulary for the A2A client extension.
 * @module @nelsonlongxiang/dsh-open-a2a-net/types
 */

/** One peer node's agent card — the decentralized discovery record. */
export interface A2aPeerCard {
  /** Human-facing peer name. */
  readonly name: string
  /** The team this peer exposes. */
  readonly team: string
  /** The peer's session id (diagnostics and signing identity). */
  readonly session: string
  /** Capability flags the peer published, verbatim. */
  readonly capabilities: unknown
  /** Epoch ms after which the card is stale; enforced at every parse. */
  readonly expiresAt: number
  /**
   * Card URLs of other nodes the publisher knows (discovery referrals).
   * Unsigned and optional: a referral is fetched and verified as its own
   * card before it is trusted, so its integrity is checked at that fetch,
   * not by this card's signature.
   */
  readonly peers?: readonly string[]
  /**
   * gh#41 fleet planning: this host's own canvas-team organization, served
   * fresh on the FULL card (linked callers only) — each entry names a team
   * and its member handles so any linked peer's board can render the org.
   */
  readonly canvasOrg?: ReadonlyArray<{ name: string; team: string; members: readonly string[] }>
  /**
   * Joined session teams this peer currently dispatches. Unsigned and
   * optional: served fresh at read time, each entry is a team name the
   * peer's `/a2a/direct` endpoint routes to that session, with the
   * session's title and recent-activity excerpt as facts.
   */
  readonly sessionTeams?: readonly A2aSessionTeamInfo[]
  /**
   * Team-roster declarations this peer's joined session nodes published
   * (`node` = the session's `<team>/<agentId8>` handle). Unsigned and
   * optional: served fresh at read time like `sessionTeams`, so a team's
   * cross-host roster rebuilds as the union of member declarations (the
   * reader half of the team-roster model — docs/design/team-roster-model.md).
   */
  readonly teamMemberships?: readonly A2aTeamMembership[]
  /**
   * The publishing host's LAN IPv4. Unsigned and optional: served fresh, it
   * lets peers group and tell machines apart in a same-team fleet.
   */
  readonly lanIp?: string
  /**
   * The publishing plugin's package version. Unsigned and optional: served
   * fresh like `lanIp`, it lets operators audit a fleet's actual running
   * builds without visiting each host.
   */
  readonly version?: string
  /** Base64 SPKI DER of the signing node's Ed25519 public key. */
  readonly publicKey: string
  /**
   * Zone records delegating names to other zones. Signed with the card: a
   * record is an authority claim over the name (GNS DELEGATE semantics),
   * unlike the unsigned `peers` referral hints.
   */
  readonly records?: readonly ZoneRecord[]
  /** Base64 Ed25519 signature over the card's committed fields. */
  readonly signature: string
}

/** One joined session team advertised on a peer's card. */
export interface A2aSessionTeamInfo {
  /** Session team name (`<team>/<agentId8>`); the route target. */
  readonly team: string
  /** Human seatName when configured, otherwise the session title at read time. */
  readonly name: string
  readonly seatName?: string
  /** One-line excerpt of the session's newest user or assistant text. */
  readonly description: string
  /** CLI deposit status, explicitly online/offline on full host cards; absent on ordinary sessions. */
  readonly offline?: boolean
  /** The session's working directory, when the publishing node shares it. */
  readonly workspace?: string
}

/** One team-roster declaration on a peer's card: session node → team. */
export interface A2aTeamMembership {
  /** The declaring session node's handle (`<team>/<agentId8>`). */
  readonly node: string
  /** The declared routable team name. */
  readonly team: string
}

/**
 * One zone record: a delegation of a name into another zone. The delegating
 * zone's card signature commits the record, so only the zone key holder can
 * publish or retire the name.
 */
export interface ZoneRecord {
  readonly type: 'delegate'
  /** The delegated name; resolves zone-relatively. */
  readonly name: string
  /** Base URL of the zone the name resolves in. */
  readonly url: string
  /**
   * Expected base64 SPKI public key of the target zone's card. When bound,
   * a target card whose key differs fails resolution closed.
   */
  readonly publicKey?: string
}

/** Canonical `a2a_route` success value. */
export interface A2aRouteOk {
  /** Actual member face returned by a forwarded peer delivery. */
  readonly deliveredTo?: string
  /**
   * #298: the peer declares `result.text` is the member's own final reply — never a host-authored placeholder
   * (flush timeout, dead session), a bridge round or a delivered marker. Absent from older peers.
   */
  readonly replyFinal?: true
  readonly ok: true
  readonly team: string
  /** Reply text the remote team produced. */
  readonly reply: string
  /** The answering peer's task id (diagnostics). */
  readonly task_id: string
  /** Context id for continuing this conversation in a later `a2a_route` call. */
  readonly context_id: string
  readonly task_status: string
  /**
   * Delivered-shape only (wait:false): whether the target's driver had
   * started a turn by the delivery probe. `false` means the message is
   * queued (a busy turn holds the inbox) or the wake was latched — the
   * delivered≠consumed distinction the async-stall analysis (§三 F1) made
   * the honest signal for; a re-check via a2a_status or the context id is
   * the caller's follow-up, not a retry.
   */
  readonly consumed?: boolean
  /**
   * Present when the result rode the native-teams bridge: its rounds emit
   * no A2A receipt in this slice, so callers must not book the row as
   * receipt-owed (`trackOwedTask` skips it).
   */
  readonly bridge?: 'native-teams'
  /** The peer's explicit receipt contract, when provided. */
  readonly receipt?: 'none' | 'routed' | 'mailbox'
  /**
   * gh#141: the peer refused the settlement the delivered message carried
   * (its enforce verdict, `settlement: {status: 'refused'}` on the wire,
   * #139) — the delivery landed, the debt it named stays owed there.
   */
  readonly settlementRefused?: true
}

/** Canonical `a2a_route` failure value. */
export interface A2aRouteError {
  /** A forwarded receipt never promises another receipt, including uncertain waits. */
  readonly receipt?: 'none'
  readonly ok: false
  /** Peer or transport failure text. */
  readonly error: string
  /**
   * Wall-clock ms from dispatch to abort/failure. Present on transport-level
   * failures only — pins the wait-window measurement instead of a feeling.
   */
  readonly abortElapsedMs?: number
  /** True when THIS client's own reply-wait budget fired (vs caller signal / peer refusal). */
  readonly ownBudgetExhausted?: boolean
  /** A2A JSON-RPC-style code when the peer supplied one. */
  readonly code?: number
  readonly task_id?: string
  /** One actionable next step for the caller (#282 S1); absent when nothing the caller can do helps. */
  readonly next?: string
}

/** Canonical `a2a_route` value: success or explicit failure. */
export type A2aRouteResult = A2aRouteOk | A2aRouteError
