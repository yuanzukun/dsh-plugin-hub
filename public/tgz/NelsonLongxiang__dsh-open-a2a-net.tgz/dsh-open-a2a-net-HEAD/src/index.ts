/**
 * A2A node extension (decentralized topology): registers the `a2a_teams` and
 * `a2a_route` model tools over verified peer agent cards and direct peer
 * routes, publishes this node's card and joined session teams, and dispatches
 * inbound direct routes into live agent sessions.
 * @module @nelsonlongxiang/dsh-open-a2a-net
 */

import { createHash, createPrivateKey, createPublicKey, generateKeyPairSync, randomBytes, sign as edSign, timingSafeEqual, verify as edVerify } from 'node:crypto'
import { existsSync, mkdirSync, readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { networkInterfaces } from 'node:os'
import { dirname, join } from 'node:path'
import { resolveDshHome } from '@deepseek-ai/dsh-home-paths'
// The package own version, read from package.json at load time so the
// panel never drifts from the manifest the installer actually resolved.
const PLUGIN_VERSION: string = String(JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')).version)

/**
 * Fix 1 (能发即能收): resolve the caller's routable label for one routed
 * dispatch. Priority: the joined session's node team > the exempt initiator
 * face (the NODE team — bare, team-name routable) > the session label (not
 * routable; the dispatch registers receiptless per fix 2).
 */
export function resolveCallerLabel(input: {
  joined: boolean
  initiatorFace: boolean
  nodeTeam: string
  joinedTeam?: string
  sessionLabel?: string
}): string | undefined {
  if (input.joined && input.joinedTeam !== undefined) return input.joinedTeam
  if (input.initiatorFace) return input.nodeTeam
  return input.sessionLabel
}
import { signCard, verifyCard, type CardCore } from './card.ts'
import { GroupStore } from './group-store.ts'
import { CanvasStore, isRemoteMemberRef, validRemoteMemberRef } from './canvas-store.ts'
import { decodeSessionLog, extractTranscript, TRANSCRIPT_DEFAULT_LIMIT, TRANSCRIPT_MAX_FILE_BYTES, TRANSCRIPT_MAX_LIMIT } from './session-transcript.ts'
import { LayoutStore } from './layout-store.ts'
import { fileURLToPath } from 'node:url'
import { JoinedSessions } from './joined-store.ts'
import { ExposureStore } from './exposure-store.ts'
import { applyOwnerSettings, type OwnerSettings } from './owner-settings.ts'
import { CliDepositStore } from './cli-deposit.ts'
import { TeamMembershipStore } from './team-store.ts'
import { PeerStore } from './peer-store.ts'
import { SelfReferralFilter } from './self-suppress.ts'
import { resolveStageMount } from './stage-mount.ts'
import { TaskLedger, TASK_STALE_TTL_MS, SUMMARY_CAP, ARCHIVE_CAP, archivedEndedBy, briefOf, type ReceiptResolvedInfo } from './task-ledger.ts'
import { formatReceipt, parseReceipt } from './receipt.ts'
import { runReceiptLadder } from './receipt-ladder.ts'
import { IdempotencyStore, WIRE_ERROR_IDEMPOTENCY_CONFLICT, WIRE_ERROR_REPLAY_REJECTED, peerPayloadFingerprint, type IdempotencyStats } from './idempotency-store.ts'
import { resolveZone, type ZoneCardFetch } from './zone.ts'
import { registerA2aNetworkSkill } from './skill-registration.ts'
import type { Context } from '@deepseek-ai/cordis'
// Type-only: the vendored timer plugin's declaration merging is what puts
// `ctx.timer` on Context; the runtime service is mounted by app compositions.
import type { } from '@deepseek-ai/cordis-plugin-timer'
// Type-only: the vendored loader plugin's declaration merging is what puts
// `ctx.loader` on Context; the loader is mounted by app compositions.
import type { } from '@deepseek-ai/cordis-plugin-loader'
// Type-only: the web server package's declaration merging puts `ctx.webServer`
// on Context; the listener is mounted by the composition.
import type WebServer from '@deepseek-ai/dsh-host-webserver'
// Type-only: the session-title service's declaration merging puts
// `ctx.sessionTitle` on Context; the service is mounted by app compositions.
import type { } from '@deepseek-ai/dsh-session-title'
// Type-only: the session-persistence service's declaration merging puts
// `ctx.sessionPersistence` on Context; the provider is mounted by app
// compositions and stays optional here (cold listing degrades without it).
import type { } from '@deepseek-ai/dsh-session-persistence'
// Type-only: the session controller's declaration merging puts
// `ctx.sessionController` on Context; the service is mounted by app
// compositions and stays optional here (boot wake and wake-on-route
// degrade without it). It is the successor wake face after core removed
// the api gateway package (4f00a8b82a).
import type { } from '@deepseek-ai/dsh-api-session-controller'
import type { IncomingMessage, ServerResponse } from 'node:http'
import s from '@deepseek-ai/schemastery'
import { defineTool } from '@deepseek-ai/dsh-tools'
// JsonValue is declared locally instead of imported from @deepseek-ai/dsh-tools
// or dsh-session: those packages re-export the type through a dsh-session
// index.d.ts `export type { JsonValue } from './json.ts'` chain that breaks
// intermittently in fresh installs (TS2614 flip-flopping under concurrent
// store mutation, 2026-09-01, f2daa7b passed gates 15:0x and failed on the
// same tree 60 minutes later). The only consumer in this repo is this file —
// inlining removes the cross-package resolution race surface entirely.
type JsonValue = null | boolean | number | string | JsonValue[] | { [key: string]: JsonValue }
import { MessageId } from '@deepseek-ai/dsh-llm'

// The a2a relay producer's own message-source kind: upstream 0.1.7 removed the
// shared catch-all 'plugin' kind, so producers declare their own. Historical
// sessions carrying the old 'plugin' kind still deserialize (unknown kinds
// pass through) — only this producer's new writes use the owned kind.
declare module '@deepseek-ai/dsh-llm' {
  interface MessageSourceMap {
    'a2a-relay': { kind: 'a2a-relay' } & import('@deepseek-ai/dsh-llm').ContextFormed & {
      /** The sending peer's routable label (team or session), when known.
       * ui-chat's relay context body renders "来自 X" + the full text from
       * this field; without it the row falls back to an opaque body. */
      senderSessionId?: string
    }
  }
}
import type { Agent } from '@deepseek-ai/dsh-agent'
import { SessionId } from '@deepseek-ai/dsh-session'
import { A2aClient, type A2aFetch, type A2aSchedule, type CardFetchOutcome } from './a2a-client.ts'
import { MAX_LAYOUT_BODY_BYTES, WIRE_ERROR_PAYLOAD_TOO_LARGE, withinRouteBodyCap } from './transport-caps.ts'
import type { A2aPeerCard, A2aRouteResult, ZoneRecord } from './types.ts'
import { NATIVE_TEAMS_A2A_FACE_KEY, type NativeTeamsBridgeFace } from './teams-bridge.ts'

export type * from './types.ts'
export { A2aClient } from './a2a-client.ts'
export type { A2aClientOptions, A2aFetch, A2aSchedule } from './a2a-client.ts'
export { NATIVE_TEAMS_A2A_FACE_KEY } from './teams-bridge.ts'
export type { NativeTeamsBridgeFace, TeamsBridgeResolveInfo, TeamsBridgeSubmitOutcome, TeamsBridgeSubmitRequest } from './teams-bridge.ts'
export type { ReceiptResolvedInfo } from './task-ledger.ts'

// P2 seam: every correlated receipt is announced on this event for peer
// plugins that track async submissions natively (native-teams settles its
// outstanding `startRoundAsync` rounds from it). Payload vocabulary lives in
// ReceiptResolvedInfo; emission is fire-and-forget at both receipt arrival
// points (the direct endpoint and the local dispatch relay).
declare module '@deepseek-ai/cordis' {
  interface Events {
    'a2a/receipt-resolved'(payload: ReceiptResolvedInfo): void
  }
}

export const name = 'a2a'

export const inject = ['tools', 'timer', 'systemPrompt']

/** One signed zone delegation published on this node's agent card. */
export interface DelegateConfig {
  /** The delegated name; resolves zone-relatively at route time. */
  readonly name: string
  /** Base URL of the zone the name resolves in. */
  readonly url: string
  /** Base64 SPKI DER binding to the target zone's card key; `''` leaves the delegation unbound. */
  readonly publicKey: string
}

/** Deployment-varying A2A node facts; every field has a declared default. */
export interface Config {
  /** `X-API-Key` value sent on peer requests and required by the control routes; empty disables the header. */
  readonly apiKey: string
  /**
   * This node's caller label. `''` (the default) derives `dsh-host-<8 hex>`
   * from a per-home node id created on first use, so two deployments mounting
   * defaults do not collide while a persisted home keeps the label stable
   * across restarts.
   */
  readonly session: string
  /** Team name this node exposes for direct routing. */
  readonly team: string
  /** S4 fix 3: audit (default) or refuse host-side (agent-less) routing calls. */
  readonly gateAgentLessCalls: 'audit' | 'refuse'
  /**
   * Publish this node's `/.well-known/agent-card.json` on the shared web
   * server (peer discovery). Requires the web server in the composition;
   * the card carries this node's team, capabilities, referral list, and
   * joined session teams so peers find it without a central directory.
   */
  readonly announce: boolean
  /** Human-facing name published on the agent card. */
  readonly agentName: string
  /**
   * Base URLs of seed peer nodes. `a2a_teams` lists teams discovered from
   * the peers' agent cards and `a2a_route` connects to the owning peer's
   * `/a2a/direct` endpoint. The list is a seed set: referral URLs learned
   * from fetched cards join a bounded, quality-scored peer store persisted
   * at `<dsh-home>/a2a/peers.json`.
   */
  readonly peers: string[]
  /**
   * Zone delegation records published (signed) on this node's agent card:
   * each entry publishes `name` as resolvable in the zone at `url`, so a
   * route for `name` walks the delegation chain (at most 5 hops, cycles
   * fail closed).
   */
  readonly delegates: DelegateConfig[]
  /**
   * gh#9+gh#10 OriginClaim window (docs/protocol/delivery-origin-auth.md §4):
   * while true (default), a delivery/log request with NO envelope still
   * walks N3 admission and increments the legacyInbound warn metric; when
   * the operator closes it (post fleet flip), an absent envelope rejects
   * `untrusted-origin` — same code as a failed signature (M1: a
   * self-asserted already-linked name must not pass on shape alone).
   */
  readonly originClaimWindow: boolean
  /**
   * #19 D2: card-face sessionTeams excerpt exposure — 'full' | 'masked'
   * | 'off' (owner-level; default full). See the schema comment.
   */
  readonly exposureExcerpt: 'full' | 'masked' | 'off'
  /**
   * Override for the OriginClaim callerUrl anchor. Loopback-bound hosts
   * behind a pocket tunnel must name the card URL peers can actually
   * fetch (e.g. http://192.168.3.157:13080); empty uses the web server's
   * own address.
   */
  readonly originClaimUrl: string
  /**
   * gh#8 (N9) escape hatch: when true, team-name resolution also considers
   * the referral-learned peer tail (the legacy whole-store basis) instead
   * of the seeded/delegate subset only. Default false — a team name binds
   * to hosts the operator linked; fleets relying on referral discovery for
   * routing migrate by adding explicit seeds, then leave this off.
   */
  readonly referralTeamResolution: boolean
  /**
   * Harness home slice for the node keypair and peer store; `''` (the
   * default) uses the process DSH home. The Ed25519 key lives at
   * `<home>/a2a/node-key.pem` and is generated on first announce; a
   * persisted key keeps the node's card identity stable across restarts.
   */
  readonly dshHome: string
  /**
   * Agent-card validity. Announce re-signs at TTL/4 so three lost refreshes
   * still leave a live card; a node silent for one TTL disappears from every
   * peer's discovery without manual eviction.
   */
  readonly cardTtlMs: number
  /**
   * Enable per-session A2A nodes: each live top-level session can join the
   * network explicitly — label `<session>-<agentId8>`, team
   * `<team>/<agentId8>`, node facts carrying the session title and a
   * recent-activity excerpt. Joining is opt-in through the sidebar control's
   * host routes; joined teams ride this node's card and dispatch through
   * its `/a2a/direct` endpoint.
   */
  readonly sessionNodes: boolean
  /**
   * Prewarm every cold joined session's agent after the plugin mounts (dev
   * boxes and always-on collaboration hosts that restart often: the network
   * state returns without opening each session). Each wake materializes a
   * full agent — a main-thread log replay — so the prewarm is deferred,
   * foreground-yielding, and cancellable (see `wakePrewarmDelayMs` /
   * `wakePrewarmQuietMs`); the default stays off for deployments that would
   * rather pay on demand (wake-on-route and the sidebar's wake button remain
   * available either way).
   */
  readonly wakeJoinedOnBoot: boolean
  /**
   * Idle delay between loader settlement and the first boot prewarm wake:
   * boot traffic gets a clear window before any log replay starts. `0`
   * restores the old fire-at-settle behavior.
   */
  readonly wakePrewarmDelayMs: number
  /**
   * Foreground quiet window: a wake/route demand inside this window (or any
   * outbound route still in flight) postpones the next prewarm step. Panel
   * polls never count. `0` disables the yield.
   */
  readonly wakePrewarmQuietMs: number
  /**
   * Pause between consecutive boot prewarm wakes. Each wake replays a full
   * session log — the zstd decode yields the event loop only every 500ms —
   * so unbounded concurrent wakes of several huge logs starve every request
   * for tens of seconds after a restart. The serial queue with this pause
   * keeps the preheat while capping decode saturation, and wake-on-route
   * never waits on this queue.
   */
  readonly wakeBootStaggerMs: number
  /**
   * F8: continuous desired-state reconciliation. The boot prewarm is a
   * one-shot queue; the reconciler re-derives the due set every tick and
   * wakes one cold intent per pass — covering post-boot drift, failed
   * wakes, and gateways that mounted late. Default on.
   */
  readonly wakeReconcile: boolean
  /** Cadence between reconciliation ticks (floored at 50ms). */
  readonly wakeReconcileIntervalMs: number
  /** First-retry delay after a failed reconcile wake; doubles per attempt. */
  readonly wakeReconcileBackoffBaseMs: number
  /** Backoff ceiling; corrupt-log rows park as needs-repair and never retry. */
  readonly wakeReconcileMaxBackoffMs: number
  /**
   * S4: joinable-team patterns for a2a_team_join — exact names or
   * trailing-`*` prefixes. Empty list denies every join (default).
   */
  readonly teamJoinAllowlist: string[]
  /** S3 (queued): team-scoped routing admission. Enforcement off by default. */
  readonly teamScopeRouting: boolean
  /**
   * S5 (owner directive 2026-10-20): information-plane scoping — the
   * read-only fleet tools (a2a_teams / a2a_status / a2a_probe) disclose
   * only teams joined by this host's nodes (the union of local roster
   * declarations). [this host] rows stay visible; a2a_tasks (this host's
   * own ledger) stays unscoped. Set false for the open plane.
   */
  readonly teamScopeInfo: boolean
  /**
   * Peer boundary model (docs/design/peer-boundary-model.md) — connection
   * layer: an empty list keeps the historical open-referral posture; a
   * non-empty list admits a referral only when its host matches an entry
   * (exact host[:port], bare domain suffix, or full URL). Seeds from
   * `peers` are owner-configured and unaffected.
   */
  readonly peerAllowlist: string[]
  /**
   * Peer boundary model — connection layer: when false, referral URLs are
   * neither learned nor offered; the tracked set stays the configured seed
   * set for the lifetime of the config that named them.
   */
  readonly referralLearning: boolean

  /**
   * v0.5.23 (async-stall): see the schema comment on asyncNudgeDelayMs.
   */
  readonly asyncNudgeDelayMs: number
  /**
   * How long the state route serves the cold-row id set from cache before
   * re-enumerating the persistence layer. The panel polls every 2s; the
   * default keeps one full enumeration per 5s instead of one per poll.
   */
  readonly stateColdRowsTtlMs: number
  /**
   * Serve window for a verified peer card from the shared cache. Cards are
   * signed for days and re-signed at TTL/4, so 60s is semantically safe; a
   * peer that restarts with a fresh card is picked up on the next window.
   */
  readonly cardCacheTtlMs: number
  /** Shorter window for unreachable/invalid cards, so a revived peer reappears quickly. */
  readonly cardCacheNegativeTtlMs: number
  /**
   * Serve window for the panel\x27s remote rows. The refresh itself rides the
   * shared card cache, so this is pure sweep cadence: how often real
   * network activity happens while the panel polls every 2s.
   */
  readonly remoteRowsTtlMs: number
  /**
   * `final` reply budget: how long an inbound direct route waits for the
   * session's next assistant message before answering with a timeout
   * notice. Without it a session that never idles (or never produces text)
   * leaves the caller hanging until `routeTimeoutMs` expires.
   */
  readonly flushTimeoutMs: number
  /**
   * `a2a_route` execution budget: how long a call may plausibly wait for a
   * remote session's reply (default 30 minutes).
   */
  readonly routeTimeoutMs: number
  /**
   * Age at which an unsettled async task auto-dead-letters (exits the owed
   * view, disarms the nudge, still settles on a late receipt). Default
   * 24h; the mesh anomaly suite injects sub-second windows to exercise the
   * dead-letter → revival lifecycle without wall-clock waits.
   */
  readonly taskStaleTtlMs: number
  /**
   * Opt-in native-teams inbound bridge: when composed with
   * `@nelsonlongxiang/dsh-native-teams`, a routed team name that its
   * registry classifies as an unambiguous local claim dispatches through
   * its authoritative routing seam (`/a2a/direct`, the outbound A2A tools,
   * and the directory listing). Off by default — exposing every registered
   * team to the network is an operator decision (exposure-grants
   * governance: grants are deliberate, never ambient). Dispatcher-level
   * only: inbound callers address the team, never its individual members
   * (members stay visible-not-addressable).
   */
  readonly nativeTeamsInbound?: boolean
  /**
   * Reply-wait budget for one native-teams round (the bridge's answer
   * deadline, mirroring the steer path's 180s deadline). A round still
   * running past it answers the honest delivered-unsettled shape instead
   * of parking the caller; the round itself keeps going.
   */
  readonly nativeRoundWaitMs?: number
}

/** Schemastery configuration for the A2A client plugin row. */
export const Config: s<Config> = s.object({
  apiKey: s.string().default(''),
  session: s.string().default(''),
  team: s.string().default('dsh'),
  /** S4 fix ③: host-side (agent-less) routing calls — audit them (default) or refuse outright. */
  gateAgentLessCalls: s.union(['audit', 'refuse'] as const).default('audit'),
  announce: s.boolean().default(false),
  agentName: s.string().default('DeepSeek Harness A2A node'),
  peers: s.array(s.string()).default([]),
  delegates: s.array(s.object({ name: s.string(), url: s.string(), publicKey: s.string().default('') })).default([]),
  dshHome: s.string().default(''),
  sessionNodes: s.boolean().default(true),
  wakeJoinedOnBoot: s.boolean().default(false),
  wakePrewarmDelayMs: s.number().default(10_000),
  wakePrewarmQuietMs: s.number().default(5_000),
  wakeBootStaggerMs: s.number().default(3_000),
  wakeReconcile: s.boolean().default(true),
  wakeReconcileIntervalMs: s.number().default(60_000),
  wakeReconcileBackoffBaseMs: s.number().default(5_000),
  wakeReconcileMaxBackoffMs: s.number().default(600_000),
  /**
   * S4: the joinable-team curation list. A model calling a2a_team_join may
   * only declare membership in a team matching one of these patterns — an
   * exact name or a trailing-`*` prefix (`dsh/canvas/*`). Default empty:
   * the owner's no-self-join ruling, institutionalized as default-deny;
   * a refused join carries guidance instead of failing silently.
   */
  teamJoinAllowlist: s.array(s.string()).default([]),
  /**
   * S3 (phase-2 default, owner ruling 2026-09-01): route dispatch checks
   * caller↔target shared team membership before addressing — a session
   * with no declared team has no network (the unteamed-peer defect the
   * owner reproduced on 4080 and locally). Fleet compatibility rides the
   * roster capability flag (0.5.44 cards advertise roster:true; older
   * peers read as legacy). Set false to restore the open outbound seam.
   */
  teamScopeRouting: s.boolean().default(true),
  /**
   * S5 (default-on, owner directive 2026-10-20): the information-plane
   * tools answer from the joined-team scope only — a2a_teams lists
   * [this host] rows plus peer rows serving a joined team (note field
   * explains the scope); a2a_status narrows peers / in-flight / activity
   * to that scope (local traffic and idempotency aggregates stay);
   * a2a_probe sweeps serving peers and refuses a single URL whose
   * verified card cannot prove service. A host whose nodes declare no
   * teams keeps host-internal facts only. Set false to restore
   * fleet-wide disclosure.
   */
  teamScopeInfo: s.boolean().default(true),

  /**
   * Peer boundary model — connection layer: an empty list keeps the
   * historical open-referral posture; a non-empty list admits a referral
   * only when its host matches an entry (exact host[:port], bare domain
   * suffix, or full URL). Seeds from `peers` are owner-configured and
   * unaffected.
   */
  peerAllowlist: s.array(s.string()).default([]),

  /**
   * Peer boundary model — connection layer: when false, referral URLs are
   * neither learned nor offered; the tracked set stays the configured seed
   * set for the lifetime of the config that named them.
   */
  referralLearning: s.boolean().default(true),

  /**
   * gh#8 (N9): team-name resolution rides the operator-established peer
   * basis (config seeds + delegates) only; the referral-learned tail's
   * self-published card claims do not bind team names. Set true to restore
   * the legacy whole-store basis (fleet migration window).
   */
  referralTeamResolution: s.boolean().default(false),

  /**
   * #19 D2 (ruling final, owner-level knob): how much of a session team's
   * activity EXCERPT the card face publishes in sessionTeams descriptions.
   * 'full' (default) keeps the verbatim tail excerpt; 'masked' truncates
   * to a shape-only prefix; 'off' omits the description field entirely.
   * Titles and team handles stay in every tier — the knob is the excerpt,
   * not the listing.
   */
  exposureExcerpt: s.union(['full', 'masked', 'off'] as const).default('full'),

  /**
   * gh#9+gh#10 OriginClaim window: absent envelopes still walk N3 during
   * the window (counted as legacyInbound); closing it rejects them like
   * failed signatures. See docs/protocol/delivery-origin-auth.md §4.
   */
  originClaimWindow: s.boolean().default(true),
  /** OriginClaim callerUrl override for pocket-tunneled hosts; '' = auto. */
  originClaimUrl: s.string().default(''),

  /**
   * v0.5.23 (async-stall): delay before a delivered-but-unconsumed async
   * route re-wakes its target with a one-line nudge (defect
   * t-mt6nd0sq-hxuhj6). 0 disables the nudge entirely.
   */
  asyncNudgeDelayMs: s.number().default(120_000),
  stateColdRowsTtlMs: s.number().default(5_000),
  cardCacheTtlMs: s.number().default(60_000),
  cardCacheNegativeTtlMs: s.number().default(30_000),
  remoteRowsTtlMs: s.number().default(15_000),
  cardTtlMs: s.number().default(172_800_000),
  flushTimeoutMs: s.number().default(300_000),
  routeTimeoutMs: s.number().default(1_800_000),
  taskStaleTtlMs: s.number().default(TASK_STALE_TTL_MS),
  nativeTeamsInbound: s.boolean().default(false),
  nativeRoundWaitMs: s.number().default(180_000),
})

/** Model-facing text for one route result. */
function renderRoute(_args: unknown, value: Record<string, JsonValue>): { type: 'text'; text: string }[] {
  const result = value as unknown as A2aRouteResult
  const text = result.ok
    ? [
      `Team ${result.team} replied (task ${result.task_id}, status ${result.task_status}, context ${result.context_id}):`,
      result.reply,
    ].join('\n')
    : `A2A route failed${result.code === undefined ? '' : ` (code ${String(result.code)})`}: ${result.error}`
  return [{ type: 'text', text }]
}

/**
 * Register the outbound peer tools, the direct-route endpoint, and (when
 * composed) the announced card and session-node control surface.
 * @param ctx - registrant context carrying the tool registry and timer.
 * @param config - deployment's A2A node facts.
 */
/**
 * gh#9 control-face leniency audit (docs/protocol/delivery-origin-auth.md
 * §10): a keyless host that runs session nodes rides loopback leniency for
 * every control write — on a host that grants sessions a shell that is a
 * speed bump, not authentication. Pure logic so the boot warning is
 * testable without a mount.
 * @param apiKey - the configured API key ('' disables header auth).
 * @param sessionNodes - whether session nodes are enabled.
 * @returns the warning to log, or undefined.
 */
export function controlFaceLeniencyWarning(apiKey: string, sessionNodes: boolean): string | undefined {
  return apiKey === '' && sessionNodes
    ? 'a2a: control-face leniency — apiKey is empty and session nodes are enabled: on a host that grants sessions a shell, loopback trust is a speed bump, not authentication (gh#9 N7). Set apiKey for the control-plane norm; see docs/protocol/delivery-origin-auth.md §10'
    : undefined
}

/**
 * Exposure audit for unauthenticated direct deliveries (defect card F4, the
 * zero-risk slice). `/a2a/direct` carries no per-call caller identity yet
 * (docs/protocol/delivery-origin-auth.md stays best-effort until the
 * OriginClaim envelope lands), so with an empty `apiKey` every process that
 * can reach this host's ports can steer every joined session. A node that
 * only talks to loopback peers (same-host collaboration) is not exposed;
 * one seeded with non-loopback peers is, and the operator should either set
 * `apiKey` or accept the exposure deliberately.
 * @param peers - the configured seed peer URLs.
 * @param apiKey - the configured API key ('' disables header auth).
 * @returns the non-loopback seed peers and, when they coincide with an
 *   empty key, the boot warning to log.
 */
export function directDeliveryExposure(
  peers: readonly string[],
  apiKey: string,
): { nonLoopbackPeers: string[]; warning: string | undefined } {  const nonLoopbackPeers = peers.filter((peer) => {
    try {
      const { hostname } = new URL(peer)
      const host = hostname.replace(/^\[|\]$/g, '').toLowerCase()
      return !(host === 'localhost' || host.endsWith('.localhost') || host === '::1' || /^127\./.test(host))
    } catch {
      return false // a malformed seed URL says nothing about exposure
    }
  })
  const warning =
    nonLoopbackPeers.length > 0 && apiKey === ''
      ? 'a2a: apiKey empty with non-loopback peers — the open posture is deliberate: /a2a/direct and /a2a/log admit by caller identity (N3 records), not by key, and any reachable peer can attempt delivery; set apiKey to require X-API-Key on BOTH the control routes and the peer faces (gh#7 V2 closed the delivery-face gap)'
      : undefined
  return { nonLoopbackPeers, warning }
}

export function apply(ctx: Context, config: Config): void {
  const logger = ctx.logger('a2a')
  // Plugin-owned agent skill (obelisk pattern): the packaged SKILL.md rides
  // the standard DSH skill catalog through ctx.skills; uninstall is implicit
  // — the registration disposer unwinds with the fiber, so the skill lives
  // and dies with the plugin. Presence-guarded: hosts without the skills
  // service simply don't get the guidance surface.
  try {
    registerA2aNetworkSkill(ctx)
  } catch (error) {
    logger.warn('a2a skill surface unavailable: %s', String(error))
  }
  // Lifecycle guidance section (owner directive 2026-09-02): the network is
  // self-service — a session that needs cross-session or cross-node work may
  // join, team up (prefer joining an existing fitting team, create as
  // fallback), and is expected to leave both once the task is done and no
  // work is pending. Static section (tool-guidance band, 100-199): the rules
  // are stable for the fiber lifetime; current membership state belongs to
  // the a2a_teams tool, not the prompt.
  ctx.systemPrompt.section({
    name: 'a2a:lifecycle',
    order: 150,
    text: [
      '## A2A Network Lifecycle',
      '',
      'The A2A network is self-service. When a task needs cross-session or cross-node collaboration, you may join the network and team up:',
      '',
      '- **Joining**: call `a2a_teams` to discover reachable teams and nodes. Outbound routing NEVER requires join — the session that originates a task is always exempt (initiator face); join buys presence, discovery, and being routed to. Joining itself is a host-side human control (the GUI sidebar A2A panel); check your state anytime with `a2a_whoami`.',
      '- **Teaming**: prefer joining an existing team that fits the task (visible via `a2a_teams`); create a new team (canvas team) only as a fallback when no existing team fits. A node may participate in multiple teams; collaboration happens inside teams.',
      '- **Hygiene**: when your task is complete and no work is pending, leave your teams and the network — stale joined nodes and abandoned teams are network debt. Rejoining later is cheap.',
      '- **Boundaries**: an unjoined session can still route out (initiator face) and report (`a2a_report`), but has no presence — it is invisible to peer discovery and cannot be routed to. Membership is visible; leaving removes you from peer discovery too. Team-scoped admission (`teamScopeRouting`) applies to joined session callers, never to the originating face.',
    ].join('\n'),
  })
  // F4 slice: say the quiet part at boot instead of leaving the exposure to
  // be discovered from a ledger full of unexplained steering.
  const exposure = directDeliveryExposure(config.peers, config.apiKey)
  if (exposure.warning !== undefined) logger.warn(exposure.warning)
  // gh#9 control-face norm (docs/protocol/delivery-origin-auth.md §10): on a
  // host that runs agent sessions WITHOUT an apiKey, the loopback leniency
  // is a speed bump, not a gate — a session with a shell reaches every
  // control write. Name it at boot so the operator configures with eyes
  // open; the GUI key plumbing rides the same release.
  const leniencyWarning = controlFaceLeniencyWarning(config.apiKey ?? '', config.sessionNodes === true)
  if (leniencyWarning !== undefined) logger.warn(leniencyWarning)
  // The production seams: Node's globals. Tests inject their own A2aClient
  // seams through src/a2a-client.ts directly. During fiber teardown the timer
  // service is already gone; a timer armed then belongs to nobody, so the
  // arming fails closed (callback never fires).
  const schedule: A2aSchedule = (callback, delayMs) => {
    try {
      return ctx.timer.timeout(callback, delayMs)
    } catch {
      /* v8 ignore next 2 -- reachable only when the timer service is disposed
         mid-flight; the client owns no teardown-time arming site anymore, so
         no test can drive this without re-adding a teardown unregister. */
      return () => {}
    }
  }
  const fetchImpl: A2aFetch = (url, init) => globalThis.fetch(url, init)

  /** Constant-time secret comparison: hash both sides to equal-length digests. */
  function secretEqual(a: string, b: string): boolean {
    const digestA = createHash('sha256').update(a).digest()
    const digestB = createHash('sha256').update(b).digest()
    return timingSafeEqual(digestA, digestB)
  }

  /**
   * No-key trust for the control routes (gh#7 N1, V1): ONLY a loopback
   * socket — header-only trust (Sec-Fetch-Site, Origin) admitted any
   * reachable process that forged two headers. Deployments that must
   * drive control routes from off-host set apiKey; the local GUI and
   * operator CLIs ride loopback as before. A cross-site page is still
   * rejected even on loopback binds (the web-app restart-control rule).
   * @param req - the inbound control request.
   * @returns whether the caller is trusted without a key.
   */
  function controlTrustedWithoutKey(req: IncomingMessage): boolean {
    // gh#7 N1 (V1): header-only trust is NOT authentication — Sec-Fetch-Site
    // and Origin are attacker-written bytes. Without a key, only a loopback
    // socket is trusted (the local GUI and operator CLIs); a cross-site
    // page is still rejected even on loopback binds. Off-host control
    // callers must present apiKey.
    const site = req.headers['sec-fetch-site']
    if (typeof site === 'string' && site !== 'same-origin' && site !== 'none') return false
    const remote = req.socket.remoteAddress
    return remote === '127.0.0.1' || remote === '::1' || remote === '::ffff:127.0.0.1'
  }

  /**
   * Control-route authorization. With `apiKey` set, the `X-API-Key` header
   * (or `api_key` query, for non-browser clients) must match in constant
   * time. With no key, the same-origin/loopback trust applies — the explicit
   * exposure assumption: an empty-key deployment accepts control from its
   * own page and from loopback, and from nothing else.
   * @param req - the inbound control request.
   * @returns whether the request may drive the control routes.
   */
  function controlAuthorized(req: IncomingMessage): boolean {
    if (config.apiKey !== '') {
      const presented = String(req.headers['x-api-key'] ?? new URL(req.url ?? '/', 'http://x').searchParams.get('api_key') ?? '')
      return secretEqual(presented, config.apiKey)
    }
    return controlTrustedWithoutKey(req)
  }

  /**
   * Answer an unauthorized control request: 401 names the missing key,
   * 403 names the untrusted origin.
   * @param req - the inbound request.
   * @param res - the response.
   */
  function rejectControl(req: IncomingMessage, res: ServerResponse): void {
    void req
    const code = config.apiKey !== '' ? 401 : 403
    const payload = JSON.stringify({ error: config.apiKey !== '' ? 'unauthorized: X-API-Key required' : 'forbidden: untrusted origin' })
    res.writeHead(code, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
    res.end(payload)
  }

  /**
   * Wrap one control handler with the authorization guard.
   * @param handler - the route's inner handler.
   * @returns the guarded handler.
   */
  function controlRoute(handler: (req: IncomingMessage, res: ServerResponse) => void): (req: IncomingMessage, res: ServerResponse) => void {
    return (req: IncomingMessage, res: ServerResponse): void => {
      if (!controlAuthorized(req)) {
        rejectControl(req, res)
        return
      }
      handler(req, res)
    }
  }

  /**
   * Read one JSON object body and hand it to the handler; malformed input
   * answers 400. Bounded like the direct endpoint's reader.
   * @param req - the inbound request.
   * @param res - the response for the malformed-body rejection.
   * @param use - receives the parsed body.
   */
  // Wire code for boundary-refused corrupted text. -32004 is intentionally
  // left as a reservation gap for the client-abort telemetry family seen in
  // the wild; this lands at -32005 (cluster-C error-code registry).
  const WIRE_ERROR_TEXT_CORRUPTED = -32005

  /**
   * Boundary guard for undecodable text (consumed by the readJsonBody
   * guard): U+FFFD is produced by a lossy decoder upstream of us — the bytes
   * arrived already destroyed, so storing them would only immortalize
   * garbage names and excerpts.
   */
  function anyReplacementChar(value: unknown): boolean {
    if (typeof value === 'string') return value.includes('\uFFFD')
    if (Array.isArray(value)) return value.some(entry => anyReplacementChar(entry))
    if (value !== null && typeof value === 'object') {
      return Object.values(value).some(entry => anyReplacementChar(entry))
    }
    return false
  }

  function readJsonBody(req: IncomingMessage, res: ServerResponse, use: (body: { readonly id?: unknown; readonly name?: unknown; readonly action?: unknown }) => void, maxBytes = 10_000): void {
    const chunks: Buffer[] = []
    let size = 0
    // Same contract as the direct endpoint's reader (B5 enforcement): an
    // oversized body is rejected, never truncated and never connection-
    // killed mid-read — buffering stops at the crossing chunk, the stream
    // drains to `end`, and the client receives one structured 413 (the old
    // behavior tore the socket down with no diagnosis at all). The default
    // keeps the historical 10 KiB control cap; the layout save route passes
    // MAX_LAYOUT_BODY_BYTES because a full-fleet document legitimately
    // exceeds it (LayoutStore still clamps every value server-side).
    let overflowed = false
    const declared = Number.parseInt(String(req.headers['content-length'] ?? ''), 10)
    if (Number.isFinite(declared) && declared > maxBytes) overflowed = true
    req.on('data', (chunk: Buffer) => {
      if (overflowed) return
      const next = size + chunk.length
      if (next > maxBytes) {
        overflowed = true
        chunks.length = 0
        return
      }
      size = next
      chunks.push(chunk)
    })
    req.on('end', () => {
      if (overflowed) {
        if (!res.writableEnded && !res.headersSent) {
          const payload = JSON.stringify({ error: 'payload too large', code: WIRE_ERROR_PAYLOAD_TOO_LARGE })
          res.writeHead(413, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
          res.end(payload)
        }
        return
      }
      let body: { readonly id?: unknown }
      try {
        body = JSON.parse(Buffer.concat(chunks).toString('utf8')) as typeof body
      } catch {
        const payload = JSON.stringify({ error: 'malformed body' })
        res.writeHead(400, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
        res.end(payload)
        return
      }
      // P0 garbled-text guard (panel mojibake report): U+FFFD means the
      // sender's encoder destroyed the text BEFORE the wire. Persisting it
      // immortalizes the loss and re-displays garbage forever — refuse at
      // the boundary so corruption never reaches any store.
      if (anyReplacementChar(body)) {
        const payload = JSON.stringify({
          error: 'text contains undecodable characters (U+FFFD) — fix the sender encoding and retry',
          code: WIRE_ERROR_TEXT_CORRUPTED,
        })
        res.writeHead(422, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
        res.end(payload)
        return
      }
      use(body)
    })
  }

  /**
   * The web server is a sibling row, not a declared injection, so in a Loader
   * tree it can activate after this row: the optional read waits for the tree
   * to settle (immediate in a hand-built context with no Loader). The
   * callback runs at most once and never after this fiber's teardown.
   * @param use - receives the webServer service when the settled tree has one.
   * @param onAbsent - runs when the settled tree has no webServer.
   */
  function whenWebServerSettled(use: (webServer: WebServer) => void, onAbsent?: () => void): void {
    const read = (): void => {
      const webServer = ctx.get('webServer')
      if (webServer !== undefined) use(webServer)
      else onAbsent?.()
    }
    const settled = ctx.get('loader')?.await()
    if (settled === undefined) read()
    else void settled.then(() => {
      if (ctx.fiber.uid !== null) read()
    }, () => {
      // A failed boot never mounts the web server row; the absent path stays
      // silent so a dying tree logs its own failure once.
    })
  }

  // Slice 2: the configured peer list is a seed set; referral URLs learned
  // from fetched cards join a bounded, quality-scored store persisted under
  // the same home as the node key.
  const home = config.dshHome === '' ? resolveDshHome() : resolveDshHome(config.dshHome)
  const peerStore = new PeerStore(config.peers, join(home, 'a2a', 'peers.json'))
  // Peer boundary model (docs/design/peer-boundary-model.md) — connection
  // layer. referralLearning off freezes the seed set: referrals are neither
  // learned nor offered. A non-empty peerAllowlist admits a referral only
  // when its host matches an entry (exact host[:port], bare domain suffix,
  // or the full URL); the seeds are owner-configured and unaffected.
  const peerAdmissible = (url: string): boolean => {
    // `=== false` and the ?? [] tolerate compositions built without the
    // schema defaults (older hosts, test literals): an absent gate is open.
    if (config.referralLearning === false) return false
    if ((config.peerAllowlist ?? []).length === 0) return true
    let host = url
    try {
      host = new URL(url).host
    } catch {
      /* a non-URL string is judged raw against the entries */
    }
    return config.peerAllowlist.some((entry) => {
      if (entry === url || entry === host) return true
      const domain = entry.startsWith('.') ? entry : `.${entry}`
      return host.endsWith(domain)
    })
  }
  // Graceful disposal lands the debounced peer state on disk before a
  // restart reads it back (fiber teardown awaits effect disposers).
  ctx.effect(() => () => peerStore.flush())
  // Slice 3: an unset session derives from a per-home node id, and the
  // configured delegations become signed zone records on every card.
  const session = config.session === '' ? deriveSession(home) : config.session
  const records: ZoneRecord[] = config.delegates.map(delegate => ({
    type: 'delegate' as const,
    name: delegate.name,
    url: delegate.url,
    ...(delegate.publicKey !== '' ? { publicKey: delegate.publicKey } : {}),
  }))

  const nodePrivateKey = loadOrCreateNodeKey(join(home, 'a2a', 'node-key.pem'))
  /** Our own card URL once the web server settles — the OriginClaim anchor. */
  let ownCardUrl = ''
  /**
   * The OriginClaim envelope headers (gh#9+gh#10): canonical form
   * JSON.stringify([caller, callerUrl, ts]) signed with the node card key.
   * Shared by the a2a client (every peer request) and verifyOriginClaim's
   * own verification fetch (REVIEW M2: the cold-cache fetch must carry the
   * envelope so a zone/id8 caller derives from the FULL card — a bare-zone
   * caller derives from the minimal card's team either way).
   */
  function originClaimHeaders(): Record<string, string> {
    const ts = Date.now()
    const signature = edSign(undefined, Buffer.from(JSON.stringify([config.team, ownCardUrl, ts]), 'utf8'), nodePrivateKey).toString('base64')
    return {
      'X-A2A-Caller': config.team,
      'X-A2A-Caller-Url': ownCardUrl,
      'X-A2A-Caller-Ts': String(ts),
      'X-A2A-Caller-Sig': signature,
    }
  }
  const client = new A2aClient({
    apiKey: config.apiKey,
    sessionId: session,
    cardCaller: config.team,
    // gh#9+gh#10 OriginClaim (docs/protocol/delivery-origin-auth.md): every
    // peer request carries a verifiable origin — canonical form is the
    // ruled JSON.stringify([caller, callerUrl, ts]), signed with the node
    // card key (single identity anchor). Until the server settles the URL
    // is unknown; the signer returns plain naming for that brief window.
    originClaim: originClaimHeaders,
    schedule,
    fetch: fetchImpl,
  })

  // Persisted join intent: a join is a user gesture over a durable session,
  // but the node it mounts dies with the session's Agent — page reloads and
  // host restarts silently dropped every join. The store remounts the node
  // whenever the Agent comes back, until the user leaves.
  const joinedSessions = new JoinedSessions(join(home, 'a2a', 'joined.json'))
  // #19 D3/D4: per-session exposure tiers — 'linked' floor (the absence
  // default, so existing members transfer automatically) with a voluntary
  // 'fleet' opt-up. D4 (成文): group visibility = strictest member tier;
  // v1 ships no group-level knob by design.
  const exposureStore = new ExposureStore(join(home, 'a2a', 'exposure.json'))
  // gh#34 owner three-key panel hot-apply state: allowlist and teamScopeInfo
  // are read at call time, so the panel's write applies WITHOUT a restart;
  // announce is boot-time publishing (restart pending flag for the UI).
  let ownerAllowlist: string[] = [...(config.teamJoinAllowlist ?? [])]
  // Truthiness matches the ORIGINAL read site (`if (config.teamScopeInfo)`):
  // literal compositions without the schema default carry undefined, which
  // reads as the OPEN plane — `!== false` would silently scope them.
  let ownerTeamScopeInfo = config.teamScopeInfo === true
  let ownerAnnounceRestartPending = false
  // S2: node-declared team memberships — the roster half of the
  // team-roster iteration. Joins ride the allowlist-gated tools; the store
  // is the durable declaration the card publishes and the state face reads.
  const teamMemberships = new TeamMembershipStore(join(home, 'a2a', 'teams.json'))
  // gh#45 CLI 户口: deposited CLI identities (one key, multiple registrations,
  // ≤4h online by owner ruling — expiry auto-deregisters).
  const cliDeposits = new CliDepositStore(join(home, 'a2a', 'cli-deposits.json'))
  // S4 audit ring, hoisted beside the stores: the boot-settlement prune runs
  // before the tools section initializes, and it records archive-prune events.
  const teamAuditRing: Array<{ at: number; action: 'join' | 'leave' | 'archive-prune' | 'agent-less'; team: string; id: string; ok: boolean; reason?: string }> = []
  const recordTeamAudit = (action: 'join' | 'leave' | 'archive-prune' | 'agent-less', team: string, id: string, ok: boolean, reason?: string): void => {
    teamAuditRing.push({ at: Date.now(), action, team, id, ok, ...(reason !== undefined ? { reason } : {}) })
    if (teamAuditRing.length > 32) teamAuditRing.splice(0, teamAuditRing.length - 32)
  }

  /**
   * Recent routing activity for the network panel: a bounded ring of the
   * latest inbound and outbound route outcomes, newest last. The state route
   * serves a copy; the panel derives unread badges from new entries.
   */
  interface RouteActivityEntry {
    readonly ts: number
    readonly dir: 'in' | 'out'
    readonly team: string
    readonly peer: string
    readonly ok: boolean
  }
  const ACTIVITY_CAP = 20
  const recentActivity: RouteActivityEntry[] = []
  /**
   * In-flight outbound routes: a route registers on dial and unregisters on
   * settlement, so the panel can show collaboration in progress ("who is
   * waiting on whom") — the state route serves a snapshot.
   */
  interface InFlightRoute {
    readonly id: number
    readonly team: string
    readonly peer: string
    readonly startedAt: number
  }
  const inFlightRoutes = new Map<number, InFlightRoute>()
  let inFlightSeq = 0
  const beginRoute = (team: string, peer: string): number => {
    const id = ++inFlightSeq
    inFlightRoutes.set(id, { id, team, peer, startedAt: Date.now() })
    return id
  }
  const endRoute = (id: number): void => { inFlightRoutes.delete(id) }
  const recordActivity = (dir: 'in' | 'out', team: string, peer: string, ok: boolean): void => {
    recentActivity.push({ ts: Date.now(), dir, team, peer, ok })
    if (recentActivity.length > ACTIVITY_CAP) recentActivity.splice(0, recentActivity.length - ACTIVITY_CAP)
  }

  /**
   * This host's primary LAN IPv4 (first non-internal address), computed once:
   * a node fact the card and state route publish so peers and operators can
   * tell machines apart in a same-team fleet. Empty when no external address
   * exists (loopback-only deployments).
   */
  const lanIp = (() => {
    for (const entries of Object.values(networkInterfaces())) {
      for (const entry of entries ?? []) {
        if (entry.family === 'IPv4' && !entry.internal) return entry.address
      }
    }
    return ''
  })()

  // Session groups: user-named buckets for the panel's session listing,
  // persisted beside the join intents so they survive restarts.
  // Deprecated as of 0.6.6 — canvas teams are the grouping face now; this
  // store only stays readable for old panels.
  const groupStore = new GroupStore(join(home, 'a2a', 'groups.json'))
  // Canvas teams: user-composed multi-member routing groups. A session node
  // may sit in many teams; routing to <team>/canvas/<name> resolves the
  // first live member or wakes the first cold one (member order = priority).
  const canvasStore = new CanvasStore(join(home, 'a2a', 'canvas.json'))
  // Spatial presentation state for the full-page stage (contract v2).
  const layoutStore = new LayoutStore(join(home, 'a2a', 'canvas-layout.json'))

  // The async-task ledger: every route that leaves a task owed a receipt is
  // queryable here, and the correlating `[A2A receipt] task <id>` message
  // resolves it — the caller-side half of the receipt contract, persisted so
  // a restart does not orphan the reconciliation.
  const taskLedger = new TaskLedger(join(home, 'a2a', 'tasks.json'), { staleTtlMs: config.taskStaleTtlMs })
  // Unjoined-node reporting ingress (design: docs/design/unjoined-report-ingress.md):
  // a one-way signal channel for sessions with no network membership — a
  // fallen-off or never-joined session reports "I exist / I have a task"
  // here. It grants no presence: reports land in a bounded ring the state
  // route serves, never in any routable surface.
  const reportRing: Array<{ at: number; level: 'info' | 'warning' | 'error'; message: string; session: string; task?: string }> = []
  const reportLastAt = new Map<string, number>()
  // Quick-dispatch face (0.6.9): the workbench POSTs /__dsh_a2a/dispatch as a
  // human gesture; the window keeps a runaway page (or a stuck autorefresh)
  // from flooding the mesh. Keyed by client address, mirror of reportLastAt.
  const dispatchLastAt = new Map<string, number>()
/** Fix ④ loop circuit-breaker: session+text-hash → accepted-report timestamps (10min window). */
const reportLoopRing = new Map<string, number[]>()

  /**
   * Settle one message through the ledger and announce what it correlated
   * on `a2a/receipt-resolved` — the seam peer plugins (native-teams)
   * consume to settle their outstanding async submissions. Fence honesty:
   * the try/catch contains SYNCHRONOUS listener throws (cordis dispatch is
   * synchronous, so a throw lands here and the routing path survives); an
   * ASYNC listener that rejects escapes as an unhandled rejection and is
   * the consumer's own discipline — keep seam listeners synchronous.
   * @param message - the inbound or relayed message text.
   */
  function settleAndAnnounce(message: string): void {
    // W7 slice-2 hook 3: a receipt that correlates an id THIS node's
    // idempotency ledger claimed records the receipt's human line as that
    // key's outcome. Parsed DIRECTLY off the receipt codec — a claimed key
    // usually is NOT in the owed book (the claim lives on the receiving
    // side, the owed book on the dispatcher side), so the ledger's own
    // correlation would never reach it. `summary` is the one-line text;
    // the envelope's controlled-vocabulary outcome is never a product and
    // must not be recorded as one. First-write wins inside the store, so a
    // late receipt never overwrites a precise sync-hook record.
    const parsed = parseReceipt(message)
    if (parsed !== null && parsed.taskId !== '') {
      const line = parsed.summary.trim()
      if (line !== '') {
        idempotencyStore.recordOutcome(parsed.taskId, { status: 'completed', reply: line.slice(0, SUMMARY_CAP) })
      }
    }
    const resolved = taskLedger.resolveFromMessage(message)
    if (resolved === undefined) {
      // F5 (settlement integrity): the formal envelope missed — an inbound
      // message that still echoes a pending task id means the peer
      // demonstrably responded to it, which settles the debt even when the
      // receipt formality never rode the reply.
      const echoed = taskLedger.resolveEcho(message)
      if (echoed.length > 0) {
        logger.info(`a2a: ${String(echoed.length)} pending task(s) settled by content echo (${echoed.join(', ')})`)
      }
      return
    }
    try {
      ctx.emit('a2a/receipt-resolved', resolved)
    } catch (error) {
      logger.warn(`a2a: receipt-resolved listener rejected: ${String(error)}`)
    }
  }

  // Server-side idempotency keys (work-order P3): a caller-born task id
  // executes at most once inside the 24h window — same-key replays answer
  // refused-but-idempotent, same-key different-payload answers conflict.
  const idempotencyStore = new IdempotencyStore(join(home, 'a2a', 'idempotency.json'))

  // Unmasked-identity suppression: gossip mirrors peer lists back and forth,
  // so a URL whose fetch just proved it serves this node — or an already
  // tracked node (an alias spelling) — keeps coming home as an inbound
  // referral; see src/self-suppress.ts for the shape of the fix.
  const selfReferrals = new SelfReferralFilter()

  // Session nodes: every joined top-level session is its own addressable
  // team (label `<session>-<agentId8>`, team `<team>/<agentId8>`). Joining
  // is a local fact: the entry dispatches `/a2a/direct` routes and rides
  // the announced card's unsigned sessionTeams listing.
  const sessionNodes = new Map<string, Agent>()
  // Live top-level agents: the join surface's candidates and the cold-row
  // complement (apply scope — the direct-route wake below reads it too).
  const liveRoots = new Map<string, Agent>()
  // Last foreground wake/route demand (epoch ms): boot prewarm steps yield
  // while demand keeps arriving inside the quiet window. Panel polls never
  // touch this — they are constant and would starve warming forever.
  let lastWakeDemandAt = 0

  /**
   * The wake face, when composed: materializing a persisted session's agent
   * (log replay plus composed preset world) is web-app knowledge, so both
   * wake paths ride the one service that owns it. The successor of the
   * removed api gateway package (core 4f00a8b82a) is the session
   * controller's `resolveAgent` — resolve-or-resume, with failures
   * reported as a result value instead of a rejection.
   */
  interface WakeFace {
    resolveAgent(sessionId: SessionId): Promise<{ readonly agent?: Agent; readonly error?: { readonly message?: string } }>
  }
  const wakeFace = (): WakeFace | undefined => {
    const controller = ctx.get('sessionController') as { resolveAgent?: WakeFace['resolveAgent'] } | undefined
    return typeof controller?.resolveAgent === 'function' ? controller as WakeFace : undefined
  }
  const materialize = (id: string): Promise<Agent> | undefined => {
    const face = wakeFace()
    if (face === undefined) return undefined
    // The successor face reports failure as a result value; re-throw it so
    // every caller's rejection policy (reconciler backoff, route error)
    // keeps working unchanged.
    return face.resolveAgent(SessionId(id)).then(result => {
      if (result.agent !== undefined) return result.agent
      throw new Error(`materialize refused: ${result.error?.message ?? 'unknown session resolution failure'}`)
    })
  }

  // Per-id single-flight: a materialization is a full log replay (seconds of
  // main-thread decode for a large session), so two wake paths converging on
  // one cold id — a route arriving while boot prewarm is already replaying it —
  // must join the in-flight replay, not stack a second one. Rejections
  // propagate to every waiter (each caller keeps its own error policy); the
  // map entry clears in `finally` so a later wake can retry after a failure.
  const materializeInFlight = new Map<string, Promise<Agent>>()
  const materializeOnce = (id: string): Promise<Agent> | undefined => {
    const inFlight = materializeInFlight.get(id)
    if (inFlight !== undefined) return inFlight
    const started = materialize(id)
    if (started === undefined) return undefined
    const flight = started.finally(() => {
      if (materializeInFlight.get(id) === flight) materializeInFlight.delete(id)
    })
    materializeInFlight.set(id, flight)
    return flight
  }

  /**
   * Why a cold-team wake produced no flight — the failure shapes the
   * route error must tell apart (the misleading single text cost hours of
   * double-host diagnosis on 2026-08-31, and again on 2026-09-01 when the
   * archived shape read as "no cold match" across two hosts): `no-match`
   * means the team names no cold joined session; `no-face` means one
   * matched but this host composes no wake face, so the wake could never
   * have succeeded; `archived` means one matched but archive is closure —
   * the session restores from the workspace archive, the route does not.
   */
  type ColdWake =
    | { readonly kind: 'flight'; readonly flight: Promise<Agent> }
    | { readonly kind: 'no-face' }
    | { readonly kind: 'archived' }
    | { readonly kind: 'no-match' }

  /**
   * Wake one cold joined session on demand — the route-triggered half:
   * the join consented to network reachability, so a route addressed to
   * its team pays the wake rather than failing.
   * @param team - the routed team name.
   * @param skipId - the dispatching session's id (issue #41): a canvas
   * team's cold tier skips the initiator — waking the author would loop the
   * dispatch home. Bare session-team matches ignore it (an exact team match
   * is the addressed target by definition).
   * @returns the wake outcome: a flight, or the reason none was started.
   */
  const wakeColdTeam = (team: string, skipId?: string): ColdWake => {
    // F7 (wake-intent self-heal): a boot-time transient can prune the
    // in-memory intent while joined.json still holds it (memory/file
    // divergence — the live repro on 0.5.40). The persisted file is the
    // durable source of the user's gesture: if the in-memory match fails,
    // reload once and retry before giving up.
    const matchJoined = (): string | undefined =>
      joinedSessions.list().find(entry => !liveRoots.has(entry) && `${config.team}/${id8(entry)}` === team)
    let aliasId = matchJoined()
    if (aliasId === undefined) {
      joinedSessions.reload()
      aliasId = matchJoined()
    }
    // Canvas teams wake their first cold joined member (member order is
    // the routing priority; an archived member never wakes; the initiator
    // itself is skipped — issue #41, the self-route rule on canvas tiers).
    const id = aliasId ?? canvasColdMemberId(parseCanvasTeamName(team), skipId)
    // An archived session never wakes: archive is closure, not sleep — to
    // the caller the team simply has no wakeable match.
    if (id === undefined) return { kind: 'no-match' }
    // An archived match is its own honest signal: the intent and the session
    // both exist — archive closure is why the wake refuses (the archived
    // shape reading as "no cold match" cost a double-host diagnosis on
    // 2026-09-01). Restoring the session, not retrying the route, is the fix.
    if (archivedSessionFilter()?.(id) === true) return { kind: 'archived' }
    // Route demand is foreground: boot prewarm yields to it for a quiet window.
    lastWakeDemandAt = Date.now()
    const flight = materializeOnce(id)
    return flight === undefined ? { kind: 'no-face' } : { kind: 'flight', flight }
  }

  /** Route-error text for a team with no live node and no wakeable cold match. */
  const noColdMatchText = (team: string): string =>
    `No live DSH session node accepts team "${team}" and no cold joined session matches it.`
  /** Route-error text for the matched-but-archived shape: archive is
   *  closure, so the honest answer names the restore remedy instead of
   *  claiming "no cold match". */
  const archivedColdMatchText = (team: string): string =>
    `A cold joined session matches team "${team}" but it is archived — archive is closure, so archived sessions never wake. Restore the session from the workspace archive to make it routable.`
  /** Route-error text for the matched-but-unwakeable shape: names the missing
   *  face and the manual remedy instead of claiming "no cold match". */
  const noWakeFaceText = (team: string): string =>
    `No live DSH session node accepts team "${team}"; a cold joined session matches but this host composes no wake face (sessionController.resolveAgent) — open the session once to make it live.`

  /**
   * The workspace registry's archived set, when composed. Archiving is a
   * registry state — the session store stays — so this list is the one
   * authoritative archive signal. Read structurally: the registry is an
   * optional neighbor, not a dependency.
   */
  function archivedSessionFilter(): ((id: string) => boolean) | undefined {
    const registry = (ctx as unknown as { get(name: string): unknown }).get('workspaceRegistry') as { archivedSessionIds?: readonly unknown[] } | undefined
    if (registry === undefined || !Array.isArray(registry.archivedSessionIds)) return undefined
    const archived = new Set(registry.archivedSessionIds.map(String))
    return (id: string): boolean => archived.has(id)
  }

  /**
   * Archived sessions leave the node network: archive is closure, so the
   * persisted join intent goes, a mounted live node unmounts, and the next
   * listing stops advertising the team. Runs at boot settlement and on every
   * state read — the panel's poll makes a mid-session archive disappear
   * within one poll interval.
   */
  const pruneArchivedJoins = (): void => {
    const isArchived = archivedSessionFilter()
    if (isArchived === undefined) return
    for (const id of joinedSessions.list()) {
      if (!isArchived(id)) continue
      sessionNodes.delete(id)
      // The archived session's JOIN INTENT is retained: deleting it was the
      // 3081 wake-defect root cause (a transient archived-window reading
      // wiped intents at boot, and cold sessions then never woke — "no cold
      // joined session matches"). Safety without the deletion: wake refuses
      // archived intents (:804), card assembly and the state cold rows filter
      // them, the reconciler skips them, and JOIN_CAP bounds the file.
      canvasStore.dropMember(id)
      // S2 consistency: an archived node's roster declarations die with it
      // — a left node keeps no team membership.
      teamMemberships.dropSession(id)
      // S4 audit face: record the prune-visible event (silent intent
      // deletion is exactly what made this incident hard to evidence).
      recordTeamAudit('archive-prune', `archived node pruned from join surface: ${id8(id)}`, id, true)
      logger.info(`a2a: archived session ${id8(id)} left the node network (intent retained)`)
    }
  }

  /**
   * Lifecycle revalidation for canvas membership: a member is legitimate
   * only while it is live on the network (a mounted session node) or while
   * a join intent is remembered. The control route enforces this at write
   * time, but canvas.json is a plain file — an external edit (or a join
   * intent that vanished between restarts) can leave a stale id behind.
   * Routing is already safe by construction (live resolution needs a
   * mounted node; cold wake needs the remembered intent), so this sweep is
   * hygiene, not a security backstop: it drops dead ids at the same seams
   * the archive prune runs (boot settlement and the state poll).
   */
  const pruneCanvasMemberships = (): void => {
    for (const name of canvasStore.list()) {
      for (const id of canvasStore.membersOf(name)) {
        // Remote member refs (zone-qualified team handles) have no local
        // join intent by design — their liveness is the directory's question
        // at route time, so the prune never touches them.
        if (isRemoteMemberRef(id)) continue
        if (sessionNodes.has(id) || joinedSessions.has(id)) continue
        canvasStore.removeMember(name, id)
        logger.info(`a2a: canvas team "${name}" dropped stale member ${id8(id)} (no live node, no join intent)`)
      }
    }
  }

  /**
   * The short id suffix session-node labels and teams key on. Web agents
   * carry `SessionId`-branded ids whose first 8 characters are the literal
   * `session-` prefix — every node would share one team — so the brand
   * strips before the slice. Imported sessions (`import-<uuid>`) keep the
   * `import-` prefix plus the uuid's first 8 hex chars: a bare 8-char slice
   * would collapse the whole import family into 16 possible ids (the uuid's
   * 8th char), which collides as soon as several sessions are imported.
   */
  function id8(id: string): string {
    const bare = id.replace(/^session-/, '')
    const imported = bare.match(/^import-([0-9a-fA-F]+)/)
    if (imported !== null) return `import-${imported[1]!.slice(0, 8)}`
    return bare.slice(0, 8)
  }

  /** The 8-char suffix of one agent's id. */
  function agentId8(agent: Agent): string {
    return id8(String(agent.id))
  }

  /** The session node's wire label. */
  function sessionLabelOf(agent: Agent): string {
    return `${session}-${agentId8(agent)}`
  }

  /** The session node's team name. */
  function sessionTeamOf(agent: Agent): string {
    return `${config.team}/${agentId8(agent)}`
  }

  /**
   * Resolve the live agent a session-node team names, when that node exists.
   * @param team - the routed team name.
   * @returns the node's agent, or undefined for any other team.
   */
  function resolveAgentForTeam(team: string): Agent | undefined {
    const prefix = `${config.team}/`
    if (!team.startsWith(prefix)) return undefined
    const suffix = team.slice(prefix.length)
    return [...sessionNodes.values()].find(agent => agentId8(agent) === suffix)
  }

  /**
   * The canvas team's wire name: `<team>/canvas/<name>`. The extra path
   * segment can never collide with a node alias (`<team>/<id8>`), so the
   * two namespaces coexist without reservation tables.
   */
  const canvasTeamOf = (name: string): string => `${config.team}/canvas/${name}`

  /** The canvas team name a routed team string names, when it exists. */
  const parseCanvasTeamName = (team: string): string | undefined => {
    const prefix = `${config.team}/canvas/`
    if (!team.startsWith(prefix)) return undefined
    const name = team.slice(prefix.length)
    return canvasStore.hasTeam(name) ? name : undefined
  }

  /**
   * The canvas team's first live member agent (member order = priority).
   * `skipId` (issue #41, self-route rule on the canvas tiers): the
   * dispatching session's own id — a live initiator occupying a member slot
   * must not capture the dispatch, or the message only echoes home. Inbound
   * faces pass no skip (a remote caller never equals a local member id).
   */
  function canvasLiveAgent(name: string | undefined, skipId?: string): Agent | undefined {
    if (name === undefined) return undefined
    for (const id of canvasStore.membersOf(name)) {
      if (id === skipId) continue
      const agent = sessionNodes.get(id)
      if (agent !== undefined) return agent
    }
    return undefined
  }

  /**
   * The canvas team's first cold joined member id — the wake candidate.
   * Cold means: joined intent remembered, no live root, not archived.
   * `skipId` skips the initiating session for the same self-route reason as
   * {@link canvasLiveAgent}: waking the initiator would only loop the
   * dispatch back to its author.
   */
  function canvasColdMemberId(name: string | undefined, skipId?: string): string | undefined {
    if (name === undefined) return undefined
    const isArchived = archivedSessionFilter()
    return canvasStore.membersOf(name).find(id =>
      id !== skipId && joinedSessions.has(id) && !liveRoots.has(id) && isArchived?.(id) !== true)
  }

  /**
   * Human-facing node facts for one session: the session title (fallback:
   * the node label), a one-line recent-activity excerpt, and the session's
   * working directory (from the durable session header — a storage fact
   * read fresh, never baked into any prompt).
   * @param agent - the session the facts describe.
   * @returns the name/description/workspace triple the card and state route serve.
   */
  // The title service derives its answer from the session log, so calling
  // it per agent per panel poll re-derives 24 titles every 2s on a busy
  // host. Memoize per agent with the same fingerprint the excerpt cache
  // uses (event count + tail identity): a title only changes when the log
  // grows or its tail event object changes.
  const titleCache = new WeakMap<Agent, { length: number; tail: unknown; title: string | undefined }>()

  /**
   * Session events accessor, dual-API hardened (d42fe125 hot-fix finding on
   * 4080: alpha.4 removed the `.events` accessor — the null guard alone
   * kept the host alive but silently broke titles). Resolution order:
   * alpha.4 `snapshotEvents()` (argument-less full frozen snapshot) →
   * legacy `.events` array → empty. An unattached session yields empty.
   */
  /** Minimal event shape the title/activity/receipt-flush readers need. */
  type SessionEventLike = {
    readonly type?: string
    readonly data?: { readonly message?: { readonly content?: ReadonlyArray<{ readonly type?: string; readonly text?: string }> } }
  }

  function sessionEventsOf(agent: Agent): readonly (SessionEventLike | undefined)[] {
    // The cast widens to BOTH faces of the accessor: alpha.4 hosts expose
    // `snapshotEvents()`, legacy hosts the `.events` array — the ambient
    // `Session` type names whichever face its own package rev shipped, so
    // the legacy read below needs the widened member to stay type-honest
    // without a behavioural change.
    const session = agent.session as (typeof agent.session & { snapshotEvents?: () => readonly unknown[]; events?: readonly (SessionEventLike | undefined)[] }) | undefined
    if (session === undefined) return []
    if (typeof session.snapshotEvents === 'function') {
      try {
        const snapshot = session.snapshotEvents()
        if (Array.isArray(snapshot)) return snapshot as readonly (SessionEventLike | undefined)[]
      } catch { /* fall through to the legacy accessor */ }
    }
    return Array.isArray(session.events) ? (session.events as readonly (SessionEventLike | undefined)[]) : []
  }

  function sessionTitleOf(agent: Agent): string | undefined {
    const events = sessionEventsOf(agent)
    const length = events.length
    const tail = length > 0 ? events[length - 1] : undefined
    const cached = titleCache.get(agent)
    if (cached !== undefined && cached.length === length && cached.tail === tail) return cached.title
    const title = ctx.get('sessionTitle')?.get(agent.session)?.title
    // An undefined answer is transient (service not yet ready on a cold
    // wake) - caching it would pin the miss until the log grows again.
    // Read-through instead: the title service is cheap, and the next poll
    // picks up the real title as soon as the service can produce one.
    if (title !== undefined) titleCache.set(agent, { length, tail, title })
    return title
  }

  /**
   * Legacy prewarm probe title (frozen historical marker): the pre-0.5.45
   * prewarm steered this exact message into cold sessions to force their
   * first model call, and the session-title service derived those sessions'
   * titles from it — permanently, for seats that never chatted since. The
   * injector was removed at 6f13847 (the wake now rides
   * sessionController.resolveAgent with no message), so the string is a
   * frozen residue: exact-equality matching cannot drift and cannot mis-hit
   * a real user message (peer boundary model, docs/design/peer-boundary-
   * model.md §Layer 2 provenance).
   */
  const LEGACY_PREWARM_PROBE_TITLE = '[prewarm] 请回复 ok。'

  function nodeMetadataOf(agent: Agent): { name: string; description: string; workspace?: string } {
    const title = sessionTitleOf(agent)
    const cwd = (agent.session as { header?: { cwd?: string } }).header?.cwd
    // Display-layer fallback (pure presentation, zero data mutation): a title
    // that IS the legacy probe reads as machine junk in every directory and
    // card — surface the stable seat label instead. The session-title
    // service's stored value is untouched.
    const displayTitle =
      title !== undefined && title !== '' && title !== LEGACY_PREWARM_PROBE_TITLE ? title : undefined
    return {
      name: displayTitle !== undefined ? displayTitle : sessionLabelOf(agent),
      description: recentActivityOf(agent),
      ...(cwd !== undefined && cwd !== '' ? { workspace: cwd } : {}),
    }
  }

  /**
   * One line of recent activity: the newest user or assistant text,
   * whitespace-collapsed and truncated.
   * @param agent - the session whose event log is scanned.
   * @returns the excerpt, or a placeholder for a fresh session.
   */
  // Memoized per agent: quiet sessions with no text events would otherwise
  // rescan their whole (multi-MB) event arrays on every panel poll. The
  // cache invalidates when the log grows or its tail event object changes;
  // the backward scan itself stops after RECENT_ACTIVITY_SCAN_LIMIT events
  // so a textless log costs one bounded pass, not a full walk.
  const recentActivityCache = new WeakMap<Agent, { length: number; tail: unknown; value: string }>()
  const RECENT_ACTIVITY_SCAN_LIMIT = 500

  function recentActivityOf(agent: Agent): string {
    const events = sessionEventsOf(agent)
    const length = events.length
    const tail = length > 0 ? events[length - 1] : undefined
    const cached = recentActivityCache.get(agent)
    if (cached !== undefined && cached.length === length && cached.tail === tail) return cached.value
    const value = scanRecentActivity(events.filter((event): event is { type?: string } => event !== undefined))
    recentActivityCache.set(agent, { length, tail, value })
    return value
  }

  function scanRecentActivity(events: readonly ({ type?: string } | undefined)[]): string {
    const floor = Math.max(0, events.length - RECENT_ACTIVITY_SCAN_LIMIT)
    for (let index = events.length - 1; index >= floor; index -= 1) {
      const event = events[index]
      if (event === undefined) continue
      const blocks = event.type === 'user/message'
        ? (event as { data: { content: Array<{ type: string; text?: string }> } }).data.content
        : event.type === 'assistant/message'
          ? (event as { data: { message: { content: Array<{ type: string; text?: string }> } } }).data.message.content
          : undefined
      const text = blocks
        ?.filter((block): block is { type: 'text'; text: string } => block.type === 'text')
        .map(block => block.text)
        .join(' ')
        .replace(/\s+/g, ' ')
        .trim()
      if (text !== undefined && text !== '') return text.slice(0, 160)
    }
    return 'no activity yet'
  }

  /**
   * #19 D2: apply the owner-level excerpt knob to a session-team
   * description at the card face. 'full' keeps the verbatim excerpt;
   * 'masked' reduces to a shape-only prefix (16 chars — enough to
   * recognize, not enough to read); 'off' omits the field entirely.
   */
  function exposureDescription(description: string): string | undefined {
    if (config.exposureExcerpt === 'off') return undefined
    if (config.exposureExcerpt === 'masked') return `${description.slice(0, 16)}${description.length > 16 ? '…' : ''}`
    return description
  }

  /**
   * Join one live top-level session: its team dispatches direct routes and
   * rides the announced card from this moment.
   * @param agent - the session to join.
   */
  function mountSessionNode(agent: Agent): void {
    sessionNodes.set(String(agent.id), agent)
  }

  if (config.sessionNodes) {
    // Track live top-level sessions for the join surface; joining is
    // explicit (the sidebar control), never automatic. A throwing
    // agent/created listener vetoes publication, so tracking is strictly
    // side-effect-only.
    ctx.on('agent/created', ({ agent }) => {
      const agents = ctx.get('agents')
      if (agents === undefined || !agents.roots().some(root => root.id === agent.id)) return undefined
      liveRoots.set(String(agent.id), agent)
      if (joinedSessions.has(String(agent.id))) mountSessionNode(agent)
      return undefined
    })
    ctx.on('agent/disposed', ({ agent }) => {
      liveRoots.delete(String(agent.id))
      // Disposal unmounts the runtime node; the persisted intent stays for
      // the remount above (leave is the only intent remover).
      sessionNodes.delete(String(agent.id))
    })
    for (const agent of ctx.get('agents')?.roots() ?? []) {
      liveRoots.set(String(agent.id), agent)
      if (joinedSessions.has(String(agent.id))) mountSessionNode(agent)
    }

    /** F-observability: the boot prewarm's lifecycle, surfaced on the state route (F: prewarm not running was invisible). */
    const prewarmStatus: {
      state: 'off' | 'skipped:no-wake-face' | 'draining' | 'done' | 'cancelled'
      attempted: number
      woken: number
      failed: Array<{ id: string; error: string }>
    } = { state: 'off', attempted: 0, woken: 0, failed: [] }

    // F8: continuous desired-state reconciliation. The boot prewarm is a
    // one-shot snapshot over a queue — a session that goes cold later, a
    // wake that failed once, or a gateway absent at that instant never got
    // a second look (the live shapes behind "auto-wake is crippled":
    // silent stalls, unretried failures, post-boot drift). The reconciler
    // re-derives the due set every tick from the join intents and wakes at
    // most one id per pass, with per-id exponential backoff and a parked
    // needs-repair state for corrupt logs. Scoped beside prewarmStatus:
    // the state route reads both, and its cancel flag is its own.
    const reconcileStatus: {
      state: 'off' | 'idle' | 'draining'
      lastTickAt: number
      lastChecked: number
      woken: number
      rows: Array<{ id: string; error: string; attempts: number; nextRetryAt: number; needsRepair: boolean }>
    } = { state: 'off', lastTickAt: 0, lastChecked: 0, woken: 0, rows: [] }
    const reconcileFailures = new Map<string, { attempts: number; nextRetryAt: number; error: string; needsRepair: boolean }>()
    const CORRUPT_LOG_SIGNATURE = /corrupt/i
    const RECONCILE_YIELD_MS = 1_000
    const recordWakeFailure = (id: string, error: string): void => {
      const attempts = (reconcileFailures.get(id)?.attempts ?? 0) + 1
      const needsRepair = CORRUPT_LOG_SIGNATURE.test(error)
      const backoff = needsRepair
        ? // Re-armable slow probe: corrupt rows re-check at the cap cadence
          // instead of parking forever — a repaired log re-materializes on
          // its own and clears the flag, and the row stays flagged until
          // then. The old never-retry park left repaired sessions cold
          // forever with no observable way back.
          Math.max(config.wakeReconcileMaxBackoffMs, config.wakeReconcileBackoffBaseMs)
        : Math.min(
          Math.max(config.wakeReconcileBackoffBaseMs, 1) * 2 ** Math.min(attempts - 1, 20),
          Math.max(config.wakeReconcileMaxBackoffMs, config.wakeReconcileBackoffBaseMs),
        )
      reconcileFailures.set(id, { attempts, nextRetryAt: Date.now() + backoff, error, needsRepair })
    }
    let reconcileCancelled = false
    ctx.effect(() => () => {
      reconcileCancelled = true
    })
    let reconcilePostponed = 0
    const reconcileTick = (): void => {
      if (reconcileCancelled || ctx.fiber.uid === null) return
      const interval = Math.max(50, config.wakeReconcileIntervalMs)
      if (!config.wakeReconcile || wakeFace() === undefined) {
        // Late-mounting wake face: keep the cadence so a session controller
        // that appears after apply still starts reconciling (the P3
        // apply-time snapshot lesson, on a loop instead of a one-shot).
        reconcileStatus.state = 'off'
        schedule(reconcileTick, interval)
        return
      }
      const now = Date.now()
      for (const id of reconcileFailures.keys()) {
        if (liveRoots.has(id) || !joinedSessions.has(id)) reconcileFailures.delete(id)
      }
      const due = joinedSessions.list().filter(id =>
        !liveRoots.has(id)
        && joinedSessions.has(id)
        && archivedSessionFilter()?.(id) !== true
        && !materializeInFlight.has(id)
        && (reconcileFailures.get(id)?.nextRetryAt ?? 0) <= now)
      reconcileStatus.lastTickAt = now
      reconcileStatus.lastChecked = due.length
      reconcileStatus.rows = [...reconcileFailures.entries()]
        .map(([rowId, row]) => ({ id: rowId, error: row.error, attempts: row.attempts, nextRetryAt: row.nextRetryAt, needsRepair: row.needsRepair }))
      if (due.length === 0) {
        reconcileStatus.state = 'idle'
        schedule(reconcileTick, interval)
        return
      }
      // Foreground demand postpones a pass — but at most five one-second
      // yields per pass, then the reconciler proceeds anyway. The boot
      // prewarm could starve forever under steady traffic; a convergence
      // loop must not.
      if ((Date.now() - lastWakeDemandAt < config.wakePrewarmQuietMs || inFlightRoutes.size > 0) && reconcilePostponed < 5) {
        reconcilePostponed += 1
        schedule(reconcileTick, RECONCILE_YIELD_MS)
        return
      }
      reconcilePostponed = 0
      reconcileStatus.state = 'draining'
      const id = due[0]!
      const flight = materializeOnce(id)
      if (flight === undefined) {
        // The shape that silently killed the boot prewarm mid-queue: here
        // it records a reason and the next pass re-derives the set.
        recordWakeFailure(id, 'materializer-unavailable')
        schedule(reconcileTick, Math.min(RECONCILE_YIELD_MS, interval))
        return
      }
      void flight
        .then(() => {
          reconcileFailures.delete(id)
          reconcileStatus.woken += 1
        })
        .catch(error => {
          recordWakeFailure(id, String(error).slice(0, 200))
          logger.warn(`reconcile wake of ${id} failed: ${String(error).slice(0, 200)}`)
        })
        .finally(() => {
          // A quick re-check after each attempt keeps a multi-id drain
          // moving at the yield cadence; the interval cadence resumes as
          // soon as a pass finds nothing due.
          if (!reconcileCancelled && ctx.fiber.uid !== null) schedule(reconcileTick, Math.min(RECONCILE_YIELD_MS, interval))
        })
    }

    {
      // Archive pruning and boot wake both ride the loader tree's
      // settlement: the workspace registry and the api gateway may activate
      // after this row in the same tree, and an apply-time snapshot would
      // see neither. Archived intents prune first — an archived session
      // must never wake — and pruning runs even with the wake off.
      // Prewarm lifecycle: cancelled at fiber teardown so a mid-queue reload
      // or dispose never lets the old instance's queue keep waking sessions.
      let prewarmCancelled = false
      /** Retry cadence while foreground demand holds the prewarm back. */
      const PREWARM_YIELD_RETRY_MS = 1_000
      const pruneThenWake = (): void => {
        pruneArchivedJoins()
        pruneCanvasMemberships()
        // F8: the reconciler runs regardless of the boot prewarm flag —
        // it is the durable convergence loop, not a boot-time courtesy.
        if (config.wakeReconcile) schedule(reconcileTick, Math.max(50, config.wakeReconcileIntervalMs))
        if (!config.wakeJoinedOnBoot) {
          prewarmStatus.state = 'off'
          return
        }
        if (wakeFace() === undefined) {
          // F-observability: this skip used to be console-only — the state
          // route now carries it so a dead prewarm is a reading, not a rumor.
          prewarmStatus.state = 'skipped:no-wake-face'
          logger.warn('wakeJoinedOnBoot is on but no wake face (sessionController) is composed; cold joined sessions stay asleep')
          return
        }
        // Low-priority prewarm instead of an eager serial chain: each wake
        // is a full main-thread log replay (the decode yields the loop only
        // every ~500ms), so waking every cold join at settlement starved
        // web requests for minutes on hosts with many large joined logs.
        // Three properties make the prewarm safe:
        //   deferred — nothing replays until wakePrewarmDelayMs after the
        //     tree settles, giving boot traffic a clear window;
        //   yielding — a foreground demand (a wake/route inside
        //     wakePrewarmQuietMs, or any outbound route in flight)
        //     postpones the next step; panel polls never count (they are
        //     constant and would starve warming forever);
        //   cancellable — disposal (reload, teardown) stops the queue; the
        //     timer seam itself fails closed after the timer service is gone.
        // Per-tick rechecks skip ids another path already woke, archived,
        // or left since queuing; the remount listener joins each node the
        // moment its woken agent publishes, and a failed wake keeps the cold
        // row and its intent. Wake-on-route and manual opens never queue.
        prewarmCancelled = false
        const ids = joinedSessions.list()
        prewarmStatus.state = 'draining'
        let index = 0
        const step = (): void => {
          if (prewarmCancelled || ctx.fiber.uid === null) {
            prewarmStatus.state = 'cancelled'
            return
          }
          while (index < ids.length
            && (liveRoots.has(ids[index]!) || !joinedSessions.has(ids[index]!) || archivedSessionFilter()?.(ids[index]!) === true)) index += 1
          if (index >= ids.length) {
            prewarmStatus.state = 'done'
            return
          }
          const foregroundBusy = Date.now() - lastWakeDemandAt < config.wakePrewarmQuietMs || inFlightRoutes.size > 0
          if (foregroundBusy) {
            schedule(step, PREWARM_YIELD_RETRY_MS)
            return
          }
          const id = ids[index++]!
          prewarmStatus.attempted += 1
          const startedAt = Date.now()
          const flight = materializeOnce(id)
          if (flight === undefined) {
            prewarmStatus.failed.push({ id, error: 'materializer-unavailable' })
            // F8 fix: a bare return here used to kill the drain mid-queue —
            // the remaining ids never got a pass and the state stayed
            // 'draining' forever (the silent-stall shape). Record the
            // failure, keep the queue moving.
            recordWakeFailure(id, 'materializer-unavailable')
            schedule(step, config.wakeBootStaggerMs)
            return
          }
          void flight
            .catch(error => {
              prewarmStatus.failed.push({ id, error: String(error).slice(0, 200) })
              // Feed the reconciler's backoff bookkeeping so a boot-time
              // failure does not get hammered again without a pause.
              recordWakeFailure(id, String(error).slice(0, 200))
              logger.warn(`boot wake of ${id} failed: ${String(error)}`)
            })
            .then(() => {
              prewarmStatus.woken += 1
              logger.info(`a2a: boot prewarm ${id8(id)} settled in ${String(Date.now() - startedAt)}ms (${String(ids.length - index)} left)`)
              if (!prewarmCancelled && ctx.fiber.uid !== null) schedule(step, config.wakeBootStaggerMs)
            })
        }
        schedule(step, config.wakePrewarmDelayMs)
      }
      ctx.effect(() => () => {
        prewarmCancelled = true
      })
      const settled = ctx.get('loader')?.await()
      if (settled === undefined) pruneThenWake()
      else void settled.then(() => {
        if (ctx.fiber.uid !== null) pruneThenWake()
      }, () => {
        // A failed boot never wakes anything; the dying tree logs its own
        // failure once.
      })
    }

    // Cold-row ids are the expensive half of the state read: enumerating
    // the persistence layer walks every stored session's metadata, and the
    // panel polls this route every 2s. Stale-while-revalidate: the first
    // read after boot pays one enumeration to seed the snapshot; every later
    // read serves the snapshot synchronously (fresh within the TTL, stale
    // past it while a single-flight background refresh runs) — the polled
    // handler never blocks on the persistence layer again. A rejecting list
    // degrades to the previous snapshot instead of an unhandled rejection.
    let coldRowsCache: { at: number; ids: Set<string> } | undefined
    let coldRowsRefresh: Promise<void> | undefined
    const refreshColdIds = (): Promise<void> => {
      if (coldRowsRefresh !== undefined) return coldRowsRefresh
      const persistence = ctx.get('sessionPersistence')
      if (persistence === undefined) return Promise.resolve()
      coldRowsRefresh = persistence.list()
        .then(headers => {
          // The header's `id` is a runtime fact of every generation; the
          // alpha.4 persistence type simply stopped naming it, so read it
          // through a widened shape instead of trusting the ambient type.
          coldRowsCache = { at: Date.now(), ids: new Set(headers.map(header => String((header as { id?: unknown }).id))) }
        })
        .catch(() => {
          // Keep serving the last snapshot; the next expiry retries.
        })
        .finally(() => {
          coldRowsRefresh = undefined
        })
      return coldRowsRefresh
    }
    const coldJoinedIds = async (): Promise<Set<string>> => {
      if (coldRowsCache === undefined) {
        await refreshColdIds()
        // The refresh assigns inside a closure, so the outer narrowing does
        // not follow it — re-read through an explicitly typed view.
        return (coldRowsCache as { ids: Set<string> } | undefined)?.ids ?? new Set<string>()
      }
      if (Date.now() - coldRowsCache.at >= config.stateColdRowsTtlMs) void refreshColdIds()
      return coldRowsCache.ids
    }

    // Peer-side rows for the panel, grouped there by origin: the sweep is
    // real network work, so a shared window serves the 2s panel poll without
    // hammering peers. The state read answers synchronously from the cache
    // (never awaiting inside the handler) and kicks a background refresh when
    // stale — the next poll picks the fresh rows up. With the shared card
    // cache serving the sweep\x27s fetches, the window length is pure cadence:
    // remoteRowsTtlMs (default 15s) spaces the real network activity while
    // staying well inside a peer restart\x27s noticeability. Single-flight: a
    // refresh already in flight serves every poll that arrives before it
    // settles — no stacked sweeps.
    let remoteRowsCache: { at: number; rows: { team: string; name: string; origin?: string; via?: string; workspace?: string; legacy?: boolean; teams?: readonly string[] }[] } | undefined
    let remoteRowsInFlight: Promise<void> | undefined
    const refreshRemoteRows = (): void => {
      const now = Date.now()
      if (remoteRowsCache !== undefined && now - remoteRowsCache.at < config.remoteRowsTtlMs) return
      if (remoteRowsInFlight !== undefined) return
      remoteRowsInFlight = listDirectoryTeams(false)
        .then(all => {
          remoteRowsCache = {
            at: now,
            rows: all
              .filter(row => row.local !== true)
              .map(row => ({ team: row.team, name: row.name, ...(row.origin !== undefined ? { origin: row.origin } : {}), ...(row.via !== undefined ? { via: row.via } : {}), ...(row.workspace !== undefined ? { workspace: row.workspace } : {}), ...(row.legacy === true ? { legacy: true } : {}), ...(row.teams !== undefined && row.teams.length > 0 ? { teams: [...row.teams] } : {}) })),
          }
        })
        .catch(() => {})
        .finally(() => {
          remoteRowsInFlight = undefined
        })
    }
    whenWebServerSettled((webServer) => {
      ctx.effect(() => webServer.register({
        kind: 'exact',
        path: '/__dsh_a2a/state',
        handler: controlRoute((_req: IncomingMessage, res: ServerResponse) => {
          void (async () => {
            const t0 = Date.now()
            // The panel polls this route: pruning here makes a mid-session
            // archive leave the network within one poll interval, no restart
            // required.
            pruneArchivedJoins()
            pruneCanvasMemberships()
            const tPrune = Date.now()
            const assignments = groupStore.all()
            const groupOf = (id: string): string | undefined => {
              const name = assignments[id]
              return name === undefined ? undefined : name
            }
            // Archived sessions are closed: the GUI hides them everywhere, so
            // the panel must not re-list them as join surface rows — joined
            // or not. (The prune above already took their join intents; this
            // covers never-joined live roots and any intent a restart left.)
            const isArchived = archivedSessionFilter()
            const tFacts0 = Date.now()
            const sessions: Array<Record<string, unknown>> = [...liveRoots.values()]
              .filter(agent => isArchived?.(String(agent.id)) !== true)
              .map(agent => ({
                id: String(agent.id),
                label: sessionLabelOf(agent),
                team: sessionTeamOf(agent),
                ...nodeMetadataOf(agent),
                joined: sessionNodes.has(String(agent.id)),
                live: true,
                teams: [...teamMemberships.teamsOf(String(agent.id))],
                // #19 D3: the session's exposure tier (linked floor /
                // fleet opt-up) — readable on the state face.
                exposure: exposureStore.tierOf(String(agent.id)),
                ...(canvasStore.teamsOf(String(agent.id)).length > 0 ? { canvasTeams: [...canvasStore.teamsOf(String(agent.id))] } : {}),
                ...(groupOf(String(agent.id)) !== undefined ? { group: groupOf(String(agent.id)) } : {}),
              }))
            // Cold joined sessions: a remembered intent whose Agent is not
            // back yet (host restarted, session not opened). The row carries
            // no facts — the Web client merges the session title from its
            // own list — and wakes through the normal session-open path,
            // after which the remount above joins it automatically.
            // Cold rows only exist when a joined intent lacks a live agent;
            // with all intents live (or none) the persistence layer is never
            // asked and the handler stays synchronous to its response.
            const tFacts1 = Date.now()
            const coldCandidates = joinedSessions.list().filter(id => !liveRoots.has(id))
            const persistence = ctx.get('sessionPersistence')
            const persisted = persistence !== undefined && coldCandidates.length > 0 ? await coldJoinedIds() : new Set<string>()
            const tCold = Date.now()
            for (const id of coldCandidates) {
              // Archived intents are retained on disk (an archived window is
              // transient; the 3081 wake defect came from deleting them), so
              // the join surface must skip them here instead.
              if (!persisted.has(id) || isArchived?.(id) === true) continue
              sessions.push({
                id,
                label: `${session}-${id8(id)}`,
                team: `${config.team}/${id8(id)}`,
                joined: true,
                live: false,
                teams: [...teamMemberships.teamsOf(id)],
                ...(canvasStore.teamsOf(id).length > 0 ? { canvasTeams: [...canvasStore.teamsOf(id)] } : {}),
                ...(groupOf(id) !== undefined ? { group: groupOf(id) } : {}),
              })
            }
            const body = JSON.stringify({
              nodes: true,
              version: PLUGIN_VERSION,
              sessions,
              groups: groupStore.list(),
              canvas: {
                teams: canvasStore.list().map(name => ({
                  name,
                  team: canvasTeamOf(name),
                  members: canvasStore.membersOf(name).map(id => {
                    // Dual shape: local members report this zone's join/live
                    // facts; remote refs are opaque team handles — the state
                    // face passes them through with remote:true for the
                    // workbench's member chips and pickers.
                    if (isRemoteMemberRef(id)) {
                      return { id, team: id, remote: true }
                    }
                    return {
                      id,
                      team: `${config.team}/${id8(id)}`,
                      joined: sessionNodes.has(id) || joinedSessions.has(id),
                      live: sessionNodes.has(id),
                    }
                  }),
                })),
              },
              host: lanIp === '' ? {} : { lanIp },
              // gh#20 W-C (host rail): each peer row also carries its display
              // name and version from the warm card (absent until a fetch),
              // and the last-contact timestamp for the health lamp. W-A's
              // link/verified ride along for the badge.
              peers: peerStore.list().map(url => {
                const card = cardCache.get(url)?.card
                const lastContact = peerStore.lastContact(url)
                const lastContactOk = peerStore.lastContactOk(url)
                return {
                  url,
                  score: peerStore.score(url),
                  ...(card?.name !== undefined && card.name !== '' ? { name: card.name } : {}),
                  ...(typeof card?.version === 'string' && card.version !== '' ? { version: card.version } : {}),
                  ...(lastContact !== undefined ? { lastContactAt: lastContact } : {}),
                  ...(lastContactOk !== undefined ? { lastContactOk } : {}),
                  ...peerLinkState(url),
                }
              }),
              remote: (refreshRemoteRows(), (remoteRowsCache?.rows ?? []).map(row => {
                const canvasTeams = canvasStore.teamsOf(row.team)
                return canvasTeams.length > 0 ? { ...row, canvasTeams: [...canvasTeams] } : row
              })),
              activity: recentActivity.slice(),
              inFlight: [...inFlightRoutes.values()].map(route => ({
                team: route.team,
                peer: route.peer,
                startedAt: route.startedAt,
              })),
              // Owed receipts: pending rows only — the cross-turn waits the
              // in-flight ring cannot show. Dead-lettered rows ride their own
              // list and settled ones just a count, all additive so the panel
              // keeps rendering plain owed rows until it learns the tiers.
              tasks: taskLedger.list()
                .filter(task => task.status === 'pending')
                .map(task => ({
                  taskId: task.taskId, team: task.team, peer: task.peer, startedAt: task.startedAt, status: task.status,
                  direction: task.direction ?? 'outbound', receiptExpected: task.receiptExpected !== false,
                  // The dispatch brief rides every row: a task id and a team
                  // say nothing about WHAT is owed — supervision cannot tell
                  // a nudge from an abandon without it.
                  ...(task.brief !== undefined ? { brief: task.brief } : {}),
                  // C-ruling bucket split: a pending row is settleable while
                  // it is young, expected, and answerable; past the stale
                  // hour it is conversational noise waiting on the dead TTL.
                  settleable: task.receiptExpected !== false && Date.now() - task.startedAt < 60 * 60_000,
                })),
              // C face: the stale/conversational tail as a count, so the
              // panel can render only truly settleable debt.
              tasksStaleCount: taskLedger.list().filter(task => task.status === 'pending' && (task.receiptExpected === false || Date.now() - task.startedAt >= 60 * 60_000)).length,
              tasksDead: taskLedger.list()
                .filter(task => task.status === 'dead')
                .map(task => ({ taskId: task.taskId, team: task.team, peer: task.peer, startedAt: task.startedAt, deadAt: task.deadAt ?? task.startedAt, reason: task.reason ?? 'unspecified', ...(task.brief !== undefined ? { brief: task.brief } : {}), ...(task.direction !== undefined ? { direction: task.direction } : {}) })),
              // gh#31: per-task outcomes for rows that LEFT the ledger — the
              // chat drawer used to guess (settled, abandoned or cancelled).
              // Bounded to the archive (≤64), newest first, with the
              // controlled-vocabulary verdict each row settled by.
              // gh#31 follow-up: archive() is already newest first (settles
              // prepend), so the projection keeps that order — the earlier
              // .reverse() served it oldest first. Each row also says HOW it
              // ended (endedBy: abandon and cancel both record outcome
              // 'abandoned', and so does a peer's own 'abandoned' receipt),
              // whether a receipt came after the caller ended it (late), and
              // its direction when known.
              archived: taskLedger.archive().slice(0, ARCHIVE_CAP).map(row => ({
                taskId: row.taskId,
                team: row.team,
                peer: row.peer,
                startedAt: row.startedAt,
                resolvedAt: row.resolvedAt,
                outcome: row.outcome ?? 'unclassified',
                endedBy: archivedEndedBy(row),
                ...(row.direction !== undefined ? { direction: row.direction } : {}),
                ...(row.lateReceiptAt !== undefined ? { late: true } : {}),
                ...(row.brief !== undefined ? { brief: row.brief } : {}),
                ...(row.summary !== undefined && row.summary !== '' ? { summary: row.summary.slice(0, 160) } : {}),
              })),
              archivedCount: taskLedger.archive().length,
              // Ledger density face: the settled archive split by verdict, so
              // the workbench can say WHICH way those rows settled instead of
              // just how many. Additive and bounded (outcome vocabulary is a
              // closed set); rows without an envelope outcome count as
              // 'unclassified' rather than being dropped.
              archivedSplit: (() => {
                const split: Record<string, number> = {}
                for (const row of taskLedger.archive()) {
                  const key = row.outcome ?? 'unclassified'
                  split[key] = (split[key] ?? 0) + 1
                }
                return split
              })(),
              // 0.5.36 observability: the idempotency window aggregate —
              // window occupancy, outcome split, and cumulative claim-verdict
              // counters (the data the UNIQUE-ization decision waits on).
              // Read-only; no fingerprints cross here (they are /a2a/query's
              // only auth material).
              idempotency: idempotencyStore.stats(),
              // gh#41 fleet planning: each tracked peer's published canvas
              // org (full-card canvasOrg) from the warm card cache — the
              // board renders REMOTE team frames from this. Absent until a
              // linked fetch warmed the card.
              peerOrg: peerStore.list().map(url => {
                const card = cardCache.get(url)?.card
                const org = (card as { canvasOrg?: unknown } | undefined)?.canvasOrg
                return Array.isArray(org)
                  ? { url, org: org.filter((e): e is { name: unknown; team: unknown; members: unknown } => e !== null && typeof e === 'object')
                      .map(e => ({ name: typeof e.name === 'string' ? e.name : '', team: typeof e.team === 'string' ? e.team : '', members: Array.isArray(e.members) ? e.members.filter((m): m is string => typeof m === 'string') : [] }))
                      .filter(e => e.team !== '') }
                  : { url, org: [] }
              }),
              // gh#9+gh#10 M1: envelope-absent deliveries during the
              // OriginClaim window — the operator watches this drain to
              // zero before closing the window.
              legacyInbound: legacyInboundCount,
              // F-observability: the boot prewarm's lifecycle — a dead or
              // skipped prewarm is the root shape behind "cold rows pile up
              // after restart" and must be readable, not a console rumor.
              prewarm: { ...prewarmStatus, failed: [...prewarmStatus.failed] },
              // F8 observability: reconciliation cadence, wake outcomes,
              // and per-row failure reasons with backoff and the parked
              // needs-repair state — the cold row's "why am I still cold".
              reconcile: { ...reconcileStatus, rows: [...reconcileStatus.rows] },
              // S1: flat node registry — local sessions and remote card
              // nodes in one table, zone-qualified team handles as the
              // stable cross-host addresses. Local ids are the session
              // UUIDs; remote ids are the publishing team handles. (The
              // `nodes` boolean above is the capability flag the panel
              // already consumes; this face rides its own key.)
              registry: {
                nodes: [
                  ...sessions.map(row => ({
                    id: String(row.id),
                    label: String(row.label ?? ''),
                    team: String(row.team ?? ''),
                    zone: config.team,
                    live: row.live === true,
                    joined: row.joined === true,
                    ...(typeof row.workspace === 'string' && row.workspace !== '' ? { workspace: row.workspace } : {}),
                    teams: [...teamMemberships.teamsOf(String(row.id))],
                  })),
                  ...(remoteRowsCache?.rows ?? []).map(row => ({
                    id: String(row.team),
                    label: String(row.name ?? ''),
                    team: String(row.team),
                    zone: String(row.team).split('/')[0] ?? config.team,
                    host: String(row.origin ?? ''),
                    ...(row.workspace !== undefined && row.workspace !== '' ? { workspace: row.workspace } : {}),
                    ...(row.legacy === true ? { legacy: true } : {}),
                    teams: [...(row.teams ?? [])],
                    remote: true,
                  })),
                ],
                // S2: local team rosters rebuilt from member declarations.
                teams: (() => {
                  const roster = new Map<string, string[]>()
                  for (const entry of teamMemberships.list()) {
                    for (const team of entry.teams) {
                      const members = roster.get(team) ?? []
                      members.push(entry.session)
                      roster.set(team, members)
                    }
                  }
                  return [...roster.entries()].map(([team, members]) => ({
                    team,
                    members,
                    live: members.filter(member => liveRoots.has(member)).length,
                  }))
                })(),
                // S4 audit face: join/leave attempts with outcomes — the
                // queryable half that rotating log lines cannot be.
                teamAudit: [...teamAuditRing],
              },
              // Unjoined-node reports: the one-way signal ring (design:
              // docs/design/unjoined-report-ingress.md), newest first.
              reports: [...reportRing].reverse(),
            })
            res.writeHead(200, {
              'Content-Type': 'application/json',
              'Content-Length': Buffer.byteLength(body),
              // Phase timing (ms since request start): prune / live-row facts /
              // cold-rows enumeration. Diagnostic for the poll-latency question.
              'X-A2A-Timing': `prune=${tPrune - t0};facts=${tFacts1 - tFacts0};cold=${tCold - tFacts1};total=${Date.now() - t0}`,
            })
            res.end(body)
          })()
        }),
      }), 'a2a: session-node state route')
      ctx.effect(() => webServer.register({
        kind: 'exact',
        path: '/__dsh_a2a/join',
        handler: controlRoute((req: IncomingMessage, res: ServerResponse) => {
          readJsonBody(req, res, (body) => {
            const agent = typeof body.id === 'string' ? liveRoots.get(body.id) : undefined
            if (agent === undefined) {
              const payload = JSON.stringify({ error: 'no live session with that id' })
              res.writeHead(404, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
              res.end(payload)
              return
            }
            mountSessionNode(agent)
            joinedSessions.add(String(agent.id))
            const payload = JSON.stringify({ id: body.id, label: sessionLabelOf(agent), team: sessionTeamOf(agent) })
            res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
            res.end(payload)
          })
        }),
      }), 'a2a: session-node join route')
      ctx.effect(() => webServer.register({
        kind: 'exact',
        path: '/__dsh_a2a/leave',
        handler: controlRoute((req: IncomingMessage, res: ServerResponse) => {
          readJsonBody(req, res, (body) => {
            const id = typeof body.id === 'string' ? body.id : ''
            if (id !== '') sessionNodes.delete(id)
            joinedSessions.remove(id)
            // Leaving the network leaves every canvas team too: membership
            // without join consent would be a routing backdoor. Team
            // roster declarations die the same way (S2 consistency).
            canvasStore.dropMember(id)
            teamMemberships.dropSession(id)
            const payload = JSON.stringify({ id })
            res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
            res.end(payload)
          })
        }),
      }), 'a2a: session-node leave route')
      // gh#45 CLI 户口 control face (loopback/key gated like every write):
      // publish (deposit a signed CLI card, ≤4h by ruling), revoke, list,
      // and mailbox readout — the CLI polls this while alive.
      ctx.effect(() => webServer.register({
        kind: 'exact',
        path: '/__dsh_a2a/cli-deposit',
        handler: controlRoute((req: IncomingMessage, res: ServerResponse) => {
          readJsonBody(req, res, (body) => {
            const action = (body as { action?: unknown }).action
            let payload: string
            if (action === 'publish') {
              const card = typeof (body as { card?: unknown }).card === 'string' ? (body as { card: string }).card : ''
              const out = cliDeposits.deposit(card)
              payload = JSON.stringify(out.ok
                ? { ok: true, handle: out.handle, expiresAt: out.expiresAt, cardUrl: `${ownCardUrl}/a2a/cli/${encodeURIComponent(out.handle)}` }
                : { ok: false, error: out.error })
            } else if (action === 'revoke') {
              payload = JSON.stringify({ ok: cliDeposits.revoke(typeof (body as { handle?: unknown }).handle === 'string' ? (body as { handle: string }).handle : '') })
            } else if (action === 'inbox') {
              const handle = typeof (body as { handle?: unknown }).handle === 'string' ? (body as { handle: string }).handle : ''
              payload = JSON.stringify({ ok: true, mail: cliDeposits.readMail(handle) })
            } else {
              payload = JSON.stringify({ ok: true, deposits: cliDeposits.list().map(row => ({ handle: row.handle, name: row.name, depositedAt: row.depositedAt, expiresAt: row.expiresAt })) })
            }
            res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
            res.end(payload)
          })
        }),
      }), 'a2a: cli-deposit route')
      // gh#41 fleet planning relay: the GUI asks THIS host to regulate a
      // REMOTE peer's canvas team. The node key never leaves the server —
      // the relay stamps the OriginClaim envelope and forwards to the
      // peer's /a2a/canvas-op face; the peer's link gate authorizes.
      ctx.effect(() => webServer.register({
        kind: 'exact',
        path: '/__dsh_a2a/fleet-canvas-op',
        handler: controlRoute((req: IncomingMessage, res: ServerResponse) => {
          readJsonBody(req, res, async (body) => {
            const { peer, op, name, id } = body as { peer?: unknown; op?: unknown; name?: unknown; id?: unknown }
            const peerUrl = typeof peer === 'string' ? peer : ''
            const opV = typeof op === 'string' ? op : ''
            const nameV = typeof name === 'string' ? name : ''
            const idV = typeof id === 'string' ? id : ''
            const send = (payload: string): void => {
              res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
              res.end(payload)
            }
            if (peerUrl === '' || !/^https?:\/\//.test(peerUrl) || !['create', 'add-member', 'remove-member'].includes(opV) || (opV !== 'create' && nameV === '')) {
              send(JSON.stringify({ ok: false, error: 'peer (http url), op (create | add-member | remove-member), and name are required' }))
              return
            }
            if (!peerStore.list().includes(peerUrl)) {
              send(JSON.stringify({ ok: false, error: `peer ${peerUrl} is not tracked — regulate tracked peers only` }))
              return
            }
            try {
              const target = peerUrl.replace(/\/$/, '') + '/a2a/canvas-op'
              const reply = await globalThis.fetch(target, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', ...originClaimHeaders() },
                body: JSON.stringify({ op: opV, name: nameV, ...(opV !== 'create' ? { id: idV } : {}) }),
                signal: AbortSignal.timeout(15_000),
              })
              const raw = await reply.text()
              try {
                const out = JSON.parse(raw) as Record<string, unknown>
                send(JSON.stringify(out))
              } catch {
                // A non-JSON reply is a peer WITHOUT the canvas-op face (a
                // pre-gh41 build) or a proxy page — name the shape honestly.
                send(JSON.stringify({ ok: false, error: `peer ${peerUrl} answered HTTP ${String(reply.status)} without JSON — it likely runs a build without the fleet canvas-op face (pre gh#41); upgrade it, or regulate its teams on that host directly` }))
              }
            } catch (error) {
              send(JSON.stringify({ ok: false, error: `fleet op failed: ${error instanceof Error ? error.message : String(error)}` }))
            }
          })
        }),
      }), 'a2a: fleet-canvas-op relay route')
      // gh#34 owner three-key panel: the remote build-out unlock knobs,
      // surfaced as a control face instead of "翻配置文件". GET reads the
      // effective values; POST writes the HOME patch layer (the
      // authoritative surface) AND hot-applies the two call-time keys
      // (teamJoinAllowlist / teamScopeInfo); announce is boot-time
      // publishing, so its change lands on the next host restart and the
      // reply says so. Same key gate as every write face.
      ctx.effect(() => webServer.register({
        kind: 'exact',
        path: '/__dsh_a2a/owner-settings',
        handler: controlRoute((req: IncomingMessage, res: ServerResponse) => {
          if (req.method === 'GET') {
            const payload = JSON.stringify({
              ok: true,
              teamJoinAllowlist: [...ownerAllowlist],
              teamScopeInfo: ownerTeamScopeInfo,
              announce: config.announce === true,
              announceRestartPending: ownerAnnounceRestartPending,
            })
            res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
            res.end(payload)
            return
          }
          readJsonBody(req, res, (rawBody) => {
            const body = rawBody as Record<string, unknown>
            const changes: OwnerSettings = {}
            if (Array.isArray(body.teamJoinAllowlist)) {
              const list = (body.teamJoinAllowlist as unknown[]).filter((name): name is string => typeof name === 'string' && name !== '' && name.length <= 128)
              changes.teamJoinAllowlist = [...new Set(list)]
            }
            if (typeof body.teamScopeInfo === 'boolean') changes.teamScopeInfo = body.teamScopeInfo
            if (typeof body.announce === 'boolean') changes.announce = body.announce
            if (Object.keys(changes).length === 0) {
              const payload = JSON.stringify({ ok: false, error: 'no recognized keys: teamJoinAllowlist (string[]), teamScopeInfo (bool), announce (bool)' })
              res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
              res.end(payload)
              return
            }
            try {
              const patchPath = join(home, 'cordis.patch.yml')
              const current = existsSync(patchPath) ? readFileSync(patchPath, 'utf8') : ''
              const { yaml, restartNeeded } = applyOwnerSettings(current, changes)
              mkdirSync(home, { recursive: true })
              writeFileSync(patchPath, yaml, 'utf8')
              // Hot-apply the two call-time keys.
              if (changes.teamJoinAllowlist !== undefined) ownerAllowlist = [...changes.teamJoinAllowlist]
              if (changes.teamScopeInfo !== undefined) ownerTeamScopeInfo = changes.teamScopeInfo
              if (changes.announce !== undefined && changes.announce !== (config.announce === true)) ownerAnnounceRestartPending = true
              if (changes.announce !== undefined && changes.announce === (config.announce === true)) ownerAnnounceRestartPending = false
              logger.info(`a2a: owner settings updated (${Object.keys(changes).join(', ')}${restartNeeded ? ' — restart pending for announce' : ''})`)
              const payload = JSON.stringify({ ok: true, restartNeeded, keys: Object.keys(changes) })
              res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
              res.end(payload)
            } catch (error) {
              const payload = JSON.stringify({ ok: false, error: `patch-layer write failed: ${error instanceof Error ? error.message : String(error)}` })
              res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
              res.end(payload)
            }
          })
        }),
      }), 'a2a: owner-settings route')
      // Groups control: create/remove named groups and assign sessions to
      // them (an empty name unassigns). Same guard as join/leave — the
      // group taxonomy enumerates session ids, so it stays behind the key.
      // Deprecated as of 0.6.6 (canvas teams supersede manual grouping);
      // kept working for old panels.
      ctx.effect(() => webServer.register({
        kind: 'exact',
        path: '/__dsh_a2a/groups',
        handler: controlRoute((req: IncomingMessage, res: ServerResponse) => {
          readJsonBody(req, res, (body) => {
            const action = body.action
            let payload: string
            if (action === 'create') {
              const name = typeof body.name === 'string' ? body.name : ''
              const stored = groupStore.create(name)
              payload = JSON.stringify(stored === undefined ? { ok: false, error: 'invalid name or group cap reached' } : { ok: true, name: stored, groups: groupStore.list() })
            } else if (action === 'remove') {
              const name = typeof body.name === 'string' ? body.name : ''
              payload = JSON.stringify({ ok: groupStore.remove(name), groups: groupStore.list() })
            } else if (action === 'assign') {
              const id = typeof body.id === 'string' ? body.id : ''
              const name = typeof body.name === 'string' ? body.name : undefined
              if (id === '' || name === undefined) {
                payload = JSON.stringify({ ok: false, error: 'id and name are required' })
              } else {
                payload = JSON.stringify({ ok: groupStore.assign(id, name), groups: groupStore.list() })
              }
            } else {
              payload = JSON.stringify({ ok: false, error: 'unknown action' })
            }
            res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
            res.end(payload)
          })
        }),
      }), 'a2a: session-group route')
      // Canvas control: create/remove named multi-member teams and manage
      // membership. Same key guard as join/leave — membership enumerates
      // session ids. A member must be a joined session (live node or
      // remembered intent): canvas routing only reaches sessions the user
      // put on the network by gesture — no routing backdoor over unjoined
      // sessions.
      ctx.effect(() => webServer.register({
        kind: 'exact',
        path: '/__dsh_a2a/canvas',
        handler: controlRoute((req: IncomingMessage, res: ServerResponse) => {
          readJsonBody(req, res, (body) => {
            const action = body.action
            let payload: string
            if (action === 'create') {
              const name = typeof body.name === 'string' ? body.name : ''
              const stored = canvasStore.create(name)
              payload = JSON.stringify(stored === undefined ? { ok: false, error: 'invalid name or team cap reached' } : { ok: true, name: stored, teams: canvasStore.list() })
            } else if (action === 'remove') {
              const name = typeof body.name === 'string' ? body.name : ''
              payload = JSON.stringify({ ok: canvasStore.remove(name), teams: canvasStore.list() })
            } else if (action === 'add-member') {
              const name = typeof body.name === 'string' ? body.name : ''
              const id = typeof body.id === 'string' ? body.id : ''
              // Dual member shape: a local session id must be a joined node;
              // a remote ref is a zone-qualified team handle whose shape this
              // gate checks and whose existence the UI picker (directory
              // rows) vouches for. Humans compose both via the workbench.
              const memberValid = isRemoteMemberRef(id)
                ? validRemoteMemberRef(id)
                : id !== '' && (sessionNodes.has(id) || joinedSessions.has(id))
              if (name === '' || !memberValid) {
                payload = JSON.stringify({ ok: false, error: 'name and a member (joined session id, or a zone-qualified remote team handle like zone/a1b2c3d4) are required' })
              } else {
                canvasStore.create(name)
                payload = JSON.stringify({ ok: canvasStore.addMember(name, id), teams: canvasStore.list(), members: canvasStore.membersOf(name) })
              }
            } else if (action === 'remove-member') {
              const name = typeof body.name === 'string' ? body.name : ''
              const id = typeof body.id === 'string' ? body.id : ''
              if (name === '' || id === '') {
                payload = JSON.stringify({ ok: false, error: 'name and id are required' })
              } else {
                payload = JSON.stringify({ ok: canvasStore.removeMember(name, id), teams: canvasStore.list(), members: canvasStore.membersOf(name) })
              }
            } else {
              payload = JSON.stringify({ ok: false, error: 'unknown action' })
            }
            res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
            res.end(payload)
          })
        }),
      }), 'a2a: session-canvas route')
      // Layout face (contract v2): whole-document GET + save/reset for the
      // stage's spatial presentation state. Validated/clamped server-side by
      // LayoutStore so a buggy client cannot poison persisted geometry.
      ctx.effect(() => webServer.register({
        kind: 'exact',
        path: '/__dsh_a2a/canvas-layout',
        handler: controlRoute((req: IncomingMessage, res: ServerResponse) => {
          if (req.method === 'GET') {
            const payload = JSON.stringify({ ok: true, layout: layoutStore.get() })
            res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
            res.end(payload)
            return
          }
          readJsonBody(req, res, (body) => {
            const action = (body as { action?: unknown }).action
            if (action === 'reset') {
              layoutStore.reset()
              const payload = JSON.stringify({ ok: true, layout: null })
              res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
              res.end(payload)
              return
            }
            if (action === 'save') {
              const accepted = layoutStore.save((body as { layout?: unknown }).layout)
              const payload = JSON.stringify(accepted ? { ok: true, layout: layoutStore.get() } : { ok: false, error: 'payload is not a version-1 layout document' })
              res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
              res.end(payload)
              return
            }
            const payload = JSON.stringify({ ok: false, error: 'unknown action' })
            res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
            res.end(payload)
          }, MAX_LAYOUT_BODY_BYTES)
        }),
      }), 'a2a: canvas-layout route')
      // The dsh-a2a-munder-difflin floor stage: a same-origin full-page
      // surface adapted from the Munder Difflin office renderer (stage/,
      // NOTICE). Serves the built Vite tree with a traversal-guarded map.
      ctx.effect(() => webServer.register({
        kind: 'prefix',
        path: '/__dsh_a2a_canvas',
        handler: (req: IncomingMessage, res: ServerResponse) => {
          const rootDir = fileURLToPath(new URL('../assets/stageDist', import.meta.url))
          // Directory-classic resolution: the bare mount 301s onto itself
          // with a slash, so the shell's `./assets` references resolve
          // inside this tree instead of 404ing against the web root.
          const MOUNT = '/__dsh_a2a_canvas'
          const resolved = resolveStageMount(req.url ?? '/', MOUNT)
          if (resolved.redirectTo !== undefined) {
            res.writeHead(301, { Location: resolved.redirectTo, 'Cache-Control': 'no-store', 'X-A2A-Stage': 'redirect' })
            res.end()
            return
          }
          const rel = decodeURIComponent(resolved.rel).replace(/\\/g, '/')
          if (rel.includes('..')) {
            res.writeHead(403, { 'Content-Type': 'text/plain', 'X-A2A-Stage': 'traversal' })
            res.end()
            return
          }
          try {
            const file = readFileSync(join(rootDir, rel))
            const ext = rel.slice(rel.lastIndexOf('.') + 1)
            const types: Record<string, string> = {
              html: 'text/html; charset=utf-8',
              js: 'text/javascript; charset=utf-8',
              mjs: 'text/javascript; charset=utf-8',
              css: 'text/css; charset=utf-8',
              png: 'image/png',
              json: 'application/json; charset=utf-8',
              svg: 'image/svg+xml',
            }
            res.writeHead(200, { 'Content-Type': types[ext] ?? 'application/octet-stream', 'Cache-Control': 'no-store', 'X-A2A-Stage': 'ok:' + ext })
            res.end(file)
          } catch (err) {
            res.writeHead(404, { 'Content-Type': 'text/plain', 'X-A2A-Stage': 'miss' })
            res.end('stage-miss rel=' + rel + ' rootDir=' + rootDir + ' err=' + String(err))
          }
        },
      }), 'a2a: canvas-stage page')
      // The dsh-a2a-nexus stage: Three.js infinite-canvas topology viewer.
      // Serves the built Vite tree from assets/nexusDist with a traversal-
      // guarded file map (same discipline as canvas-stage).
      ctx.effect(() => webServer.register({
        kind: 'prefix',
        path: '/__dsh_a2a_nexus',
        handler: (req: IncomingMessage, res: ServerResponse) => {
          const rootDirNexus = fileURLToPath(new URL('../assets/nexusDist', import.meta.url))
          // Same directory-classic resolution as the canvas mount: the bare
          // `/__dsh_a2a_nexus` form used to serve the shell verbatim, whose
          // `./assets` then 404'd at the web root — a silent black viewer.
          const MOUNT = '/__dsh_a2a_nexus'
          const resolved = resolveStageMount(req.url ?? '/', MOUNT)
          if (resolved.redirectTo !== undefined) {
            res.writeHead(301, { Location: resolved.redirectTo, 'Cache-Control': 'no-store' })
            res.end()
            return
          }
          const rel = decodeURIComponent(resolved.rel).replace(/\\/g, '/')
          if (rel.includes('..')) {
            res.writeHead(403, { 'Content-Type': 'text/plain' })
            res.end()
            return
          }
          try {
            const file = readFileSync(join(rootDirNexus, rel))
            const ext = rel.slice(rel.lastIndexOf('.') + 1)
            const types: Record<string, string> = {
              html: 'text/html; charset=utf-8',
              js: 'text/javascript; charset=utf-8',
              mjs: 'text/javascript; charset=utf-8',
              css: 'text/css; charset=utf-8',
              png: 'image/png',
              json: 'application/json; charset=utf-8',
              svg: 'image/svg+xml',
            }
            res.writeHead(200, { 'Content-Type': types[ext] ?? 'application/octet-stream', 'Cache-Control': 'no-store' })
            // gh#9 §10 GUI key plumbing (REVIEW M3 fix): the shell learns
            // the control-plane key ONLY on the loopback leniency face —
            // a remote bare GET of the page serves the shell WITHOUT the
            // key (the reviewer proved the pre-fix shape leaked the
            // credential to any network-reachable fetcher on a
            // 0.0.0.0-bound host, contradicting §10's purpose). Loopback
            // localhost is exactly §10.2's stated leniency posture; keyed
            // hosts behind tunnels use originClaimUrl-style operator
            // plumbing instead.
            if (ext === 'html' && config.apiKey !== '' && controlTrustedWithoutKey(req)) {
              const injected = file.toString('utf8').replace('</head>', `<script>window.__DSH_A2A_KEY__=${JSON.stringify(config.apiKey)};</script></head>`)
              res.end(Buffer.from(injected, 'utf8'))
              return
            }
            res.end(file)
          } catch {
            res.writeHead(404, { 'Content-Type': 'text/plain' })
            res.end()
          }
        },
      }), 'a2a: nexus-stage page')
    })
  }

  if (config.announce) {
    whenWebServerSettled((webServer) => {
      const privateKey = nodePrivateKey
      // The OriginClaim anchor URL: explicit config wins (loopback-bound
      // hosts behind a pocket tunnel must name their reachable card URL),
      // else the web server's own address.
      const bound = (webServer as { host?: '127.0.0.1' | '0.0.0.0' }).host
      const urlOverride = config.originClaimUrl ?? ''
      const reachHost = urlOverride !== '' ? '' : bound === '0.0.0.0' && lanIp !== '' ? lanIp : '127.0.0.1'
      ownCardUrl = urlOverride !== '' ? urlOverride : `http://${reachHost}:${String((webServer as { port: number }).port)}`
      const cardCore = (): CardCore => ({
        name: config.agentName,
        session,
        team: config.team,
        // async: wait:false is honored (steer + delivered, no final hold);
        // the signed capability turns async dialing into a deterministic
        // check instead of a timeout race against pre-0.5.2 peers.
        // roster: the team-roster face (a2a_team_join/leave, card
        // teamMemberships, team-scope routing admission) ships — peers read
        // its absence as a pre-roster legacy node (0.5.43 and older).
        capabilities: { route: true, async: true, roster: true },
        expiresAt: Date.now() + config.cardTtlMs,
        ...(records.length > 0 ? { records: [...records] } : {}),
      })
      let currentCard = signCard(cardCore(), privateKey)
      // Re-sign at TTL/4: four publication opportunities per validity window
      // tolerate three lost refreshes (GNUnet zonemaster cadence).
      const refresh = ctx.timer.interval(() => {
        currentCard = signCard(cardCore(), privateKey)
      }, Math.max(1, Math.floor(config.cardTtlMs / 4)))
      ctx.effect(() => webServer.register({
        kind: 'exact',
        path: '/.well-known/agent-card.json',
        // gh#9+gh#10: the FULL card now requires a VERIFIED OriginClaim
        // envelope (four headers, card-key signature) — the v1 shape-only
        // named face (self-asserted zone via ?caller_session=/header)
        // closed with the envelope flip: shape NEVER substitutes for
        // signature (ruling's no-dual-track). Everything else gets the
        // MINIMAL discovery card.
        handler: async (req: IncomingMessage, res: ServerResponse) => {
          const send = (named: boolean, body_: string): void => {
            res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body_) })
            res.end(body_)
            void named
          }
          const claim = await verifyOriginClaim(req)
          // W3 (#18 half-side, 0.6.25): a VERIFIED envelope proves the
          // caller holds a real node key — it does not prove a relationship
          // with THIS host. The full card (sessionTeams/rosters =
          // collaboration facts) additionally requires a LINK (same-host
          // membership, canvas remote ref, or the caller's own card seeding
          // us — see callerLinkedToThisHost). An unlinked-but-verified
          // stranger gets the MINIMAL discovery card, #18 X1's shape.
          // Interaction with the OriginClaim narrowing: the caller is a
          // bare zone; linkage judges that zone face against our canvas
          // remote refs, joined handles, and the caller card's peers.
          const named = claim.ok && callerLinkedToThisHost(claim.caller, claim.ok ? claim.callerUrl : '', claim.ok ? claim.card : undefined)
          // gh#7 G1 (review-seat R2 ruling): the card serves two faces.
          // A NAMED caller — ?caller_session= or the X-A2A-Caller header in
          // the zone or zone/id8 shape — gets the FULL card. An anonymous
          // fetcher (or an invalid shape, fail-closed) gets the MINIMAL
          // card: name/team/session/capabilities/records/peers/signature
          // stay (discovery, gossip, delegation, capability negotiation
          // unbroken), while sessionTeams/teamMemberships/lanIp are
          // omitted — session membership and rosters are collaboration
          // facts, not discovery facts. Named determination does NOT
          // require a shared team: demanding roster symmetry before the
          // roster exchange would self-lock (ruling text). The signature
          // covers the same signed core either way; only the unsigned
          // served-fresh fields differ.
          const cardUrl = new URL(req.url ?? '/', 'http://x')
          void cardUrl
          // The unsigned peers and sessionTeams fields carry this node's
          // current peer set and joined sessions at serve time (between
          // re-signs), so each card read spreads the publisher's latest
          // view of the network. `version` and `lanIp` are likewise
          // unsigned served-fresh facts: fleet auditability without SSH.
          // Cold joined teams (intent remembered, agent not loaded) are
          // advertised too: their routes are wake-on-route's to honor, and
          // without the listing a cross-node caller has no candidate and
          // the wake never fires.
          const isArchived = archivedSessionFilter()
          // Discovery invisibility for unjoined sessions (owner ruling B,
          // 2026-09-02): an unjoined session node is not advertised at all —
          // peers neither see it in the card's sessionTeams nor can address
          // it through the directory. Visibility follows membership: join
          // and the node appears; leave and it vanishes from discovery.
          const isJoinedNode = (agent: Agent): boolean => {
            try {
              return joinedSessions.list().includes(agent.id)
            } catch {
              return false
            }
          }
          // #19 D2: the excerpt knob rides the served-fresh rows at the
          // card face — live nodes (nodeMetadataOf description) and cold
          // rows alike. 'off' omits the field (undefined drops out).
          const exposureRow = (team: string, meta: Record<string, unknown>): Record<string, unknown> => {
            const { description, ...rest } = meta as { description?: string }
            const excerpt = exposureDescription(description ?? '')
            return { team, ...rest, ...(excerpt !== undefined ? { description: excerpt } : {}) }
          }
          const sessionTeams = [
            ...[...sessionNodes.values()].filter(isJoinedNode).map(agent => exposureRow(sessionTeamOf(agent), nodeMetadataOf(agent) as unknown as Record<string, unknown>)),
            ...joinedSessions.list()
              .filter(id => !liveRoots.has(id) && isArchived?.(id) !== true)
              .map(id => exposureRow(`${config.team}/${id8(id)}`, { name: `${session}-${id8(id)}`, description: 'cold — not loaded; routing here wakes the session' })),
            // gh#45/47: deposited CLI identities publish as directory rows —
            // the fleet sees them as member cards (draggable = the operator
            // link). Their "zone" is the agent-name. gh#47: an EXPIRED
            // deposit stays as an OFFLINE row (tombstone) so the board keeps
            // the member card grayed-but-present and canvas refs never
            // dangle silently; re-publish (same handle) un-tombstones.
            ...cliDeposits.directoryRows().map(row => exposureRow(row.team, { name: row.name, description: row.description })),
          ]
          const memberships = teamMemberships.list().flatMap(entry =>
            entry.teams.map(team => ({ node: `${config.team}/${id8(entry.session)}`, team })))
          const body = JSON.stringify({
            ...currentCard,
            peers: peerStore.list(),
            ...(named && sessionTeams.length > 0 ? { sessionTeams } : {}),
            ...(named && memberships.length > 0 ? { teamMemberships: memberships } : {}),
            // gh#41 fleet planning (owner ruling: any peer composes and
            // regulates): the host's own canvas org rides the FULL card as a
            // served-fresh unsigned field — linked peers render each other's
            // team structure on the planning board; the minimal face omits
            // it exactly like sessionTeams. Members are CANONICALIZED to
            // zone/id8 handles (local session ids translate to the node's
            // session-team handle) — one form on the wire, so readers never
            // mix id/handle shapes (owner: 数据对不上).
            ...(named ? { canvasOrg: canvasStore.list().map(name => ({ name, team: canvasTeamOf(name), members: canvasStore.membersOf(name).map(id => sessionNodes.has(id) || joinedSessions.has(id) ? `${config.team}/${id8(id)}` : id) })) } : {}),
            ...(named && lanIp !== '' ? { lanIp } : {}),
            ...(PLUGIN_VERSION !== '' ? { version: PLUGIN_VERSION } : {}),
            description: `A2A node exposing team ${config.team}${named ? '' : ' (minimal card — OriginClaim envelope required for the full card: X-A2A-Caller/-Url/-Ts/-Sig signed with your card key)'}`,
          })
          send(named, body)
        },
      }), 'a2a: agent card route')
      ctx.effect(() => refresh, 'a2a: card refresh timer')
    }, () => {
      logger.warn('announce is on but no web server is composed; the agent card is not published')
    })
  }
  /**
   * Resolve the live agent for inbound steering: the initiator when
   * recoverable, else the first root.
   * @returns the agent, or undefined when no agent is live.
   */
  function liveAgent(): Agent | undefined {
    const agents = ctx.get('agents')
    if (agents === undefined) return undefined
    try {
      return agents.requireInitiator()
    } catch {
      const roots = agents.roots()
      return roots.length > 0 ? roots[0] : undefined
    }
  }

  /** Whether `caller` names exactly this agent's own session team — the
   * self-route shape. The bare-team fallback must never deliver a session's
   * dispatch back into itself: the sender would watch its own message
   * arrive as an [A2A direct], and armReceiptAutosend would bounce its
   * confused "this is just an echo" reply back as a synthetic receipt —
   * delivered:true plus a receipt for work nobody did (defect 2026-10-18:
   * the ygl-trees monitor self-echo). */
  function callerIsAgent(agent: Agent, caller: string): boolean {
    return caller === `${config.team}/${agentId8(agent)}`
  }

  /** Honest refusal text for the self-route shape, shared by the sync and
   * transport faces so both failures read identically. */
  const selfRouteText = (team: string): string =>
    `Self-route refused: team "${team}" resolves to the issuing session itself — dispatching would loop your own message back to you (echo plus a synthetic auto-receipt). Route a concrete session team (e.g. ${team}/<id8>), a canvas team, or do the work inline.`

  /**
   * Steer one relay-form user message into the agent; the caller owns
   * rejection handling.
   * @param agent - the steering target.
   * @param text - the fully formatted relay message.
   * @param sender - the sending peer's routable label, recorded on the source
   * so ui-chat renders the relay body ("来自 X" + full text) instead of an
   * opaque row; omitted when the sender is not meaningfully addressable.
   */
  function steerRelay(agent: Agent, text: string, sender?: string): void {
    agent.steer({
      id: MessageId(`a2a-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`),
      role: 'user',
      content: [{ type: 'text', text }],
      source: { kind: 'a2a-relay', form: 'relay', ...(sender === undefined ? {} : { senderSessionId: sender }) },
    })
  }

  /** The cooperative stop-notice text, shared by the tasks/cancel control
   * route and the transport face's cancel half (one contract, one wording). */
  function cancelNoticeText(taskId: string, reason?: string): string {
    return `[A2A cancel] (task ${taskId}) the caller cancelled this task${reason !== undefined && reason !== '' ? `: ${reason}` : ''}. Stop any work tied to it and acknowledge via [A2A receipt] task ${taskId} cancelled.`
  }

  /**
   * v0.5.23 (async-stall): whether the steered agent actually left idle. A
   * steer on an idle driver flips status to running within the same tick
   * (wakeDriver sets the phase synchronously before kick); still-idle after
   * the steer means the wake was latched (maintenance/abort window) or the
   * driver never claimed it — the delivered-but-stalled shape the defect
   * ticket documented. The probe reads status once, immediately: a message
   * already consumed back to idle reads false-negative-conservative, which
   * only arms the harmless nudge below.
   * @param agent - the steered target.
   * @returns true when the driver shows running (or already errored past the
   * claim, which consumption also implies); false when it stayed idle.
   */
  function probeConsumption(agent: Agent, taskId: string): boolean {
    void taskId
    try {
      return agent.status === 'running'
    } catch {
      return false
    }
  }

  /**
   * F5 (settlement integrity): whether a receipt routed at this target can
   * actually land. A session team resolves locally (a joined live node) —
   * receipts flow. Anything else carrying the process-label shape
   * (`dsh-host-<8hex>-<rand>`, the node's own label form) resolves to no
   * session and appears in no card directory: every receipt routed at it
   * strands, which is exactly the 08-30 debt pile (six full replies given,
   * zero receipts settled). Those deliveries are born fire-and-forget.
   * Unknown labels stay receipt-expected (conservative — losing a receivable
   * receipt is worse than chasing a stranded one).
   * @param receiptTarget - the callback address or caller label.
   * @returns the expectation verdict for the delivery.
   */
  function receiptExpectationOf(receiptTarget: string): 'receivable' | 'process-label' {
    if (resolveAgentForTeam(receiptTarget) !== undefined) return 'receivable'
    if (/^dsh-host-[0-9a-f]{8}-/.test(receiptTarget)) return 'process-label'
    return 'receivable'
  }

  /**
   * v0.5.23 (async-stall): one delayed nudge per session while a task stays
   * unconsumed. The steer above parked the message; a latched wake replays
   * only at convergence, and a dropped one never does — the nudge re-steers
   * a one-line prompt after the delay, which productizes the manual
   * recovery this defect needed (a synchronous probe re-woke the session).
   * F2' (receipt-settlement): arming is unconditional and the per-session
   * single-flight is a bounded budget (initial delay + one re-arm) instead
   * of a one-shot — a target busy on its own turn at delay time used to
   * drop the shot entirely. At budget expiry the escalation climbs to the
   * host's queue-mode prompt seam when composed: queue-mode enqueues past
   * the maintenance latch that eats steers (08-30 evidence: queue woke a
   * session within 90s where steer stayed silent). No seam composed ⇒ the
   * escalation degrades to a no-op and the ledger row keeps the debt
   * visible for /a2a/query follow-ups.
   */
  const nudgeBudget = new Map<string, number>()
  const escalateQueuePrompt = (agent: Agent, team: string, taskId: string): void => {
    // Queue-mode prompt seam: the session controller owns prompt admission
    // (successor of the removed api gateway's prompt face).
    const controller = ctx.get('sessionController') as
      | { prompt?: (request: {
          requestId: string
          sessionId: Agent['id']
          mode: 'queue' | 'steer'
          content: ReadonlyArray<{ type: 'text'; text: string }>
        }, signal: AbortSignal) => Promise<unknown> }
      | undefined
    if (typeof controller?.prompt !== 'function') return
    logger.info(`a2a: async nudge escalates to queue-mode prompt for ${team} (task ${taskId})`)
    try {
      void controller.prompt({
        requestId: `a2a-nudge-${taskId}`,
        sessionId: agent.id,
        mode: 'queue',
        content: [{ type: 'text', text: `[A2A nudge] (task ${taskId}) your earlier routed message was delivered while this session could not start a turn — please consume the inbox backlog now (ignore if there is nothing pending).` }],
      }, new AbortController().signal).catch(() => {})
    } catch {
      /* queueing is best-effort: the ledger row keeps the debt visible */
    }
  }
  function armAsyncNudge(agent: Agent, team: string, taskId: string, delayMs: number): void {
    const key = String(agent.id)
    const spent = nudgeBudget.get(key)
    if (spent !== undefined && spent > 1) return
    nudgeBudget.set(key, spent ?? 0)
    const timer = setTimeout(() => {
      if (!taskLedger.isPending(taskId)) {
        nudgeBudget.delete(key)
        return
      }
      if (agent.status !== 'idle') {
        // Busy on its own turn (or wedged): spend the bounded re-arm, then
        // climb to the queue-mode seam. Re-resolve on the steer path below
        // only — a busy target needs the queue, not another steer.
        const spent = nudgeBudget.get(key) ?? 0
        if (spent < 1) {
          nudgeBudget.set(key, spent + 1)
          armAsyncNudge(agent, team, taskId, delayMs)
          return
        }
        nudgeBudget.delete(key)
        escalateQueuePrompt(agent, team, taskId)
        return
      }
      nudgeBudget.delete(key)
      // Re-resolve rather than reusing the delivered agent: a session-node
      // entry captured at delivery may have been disposed since (a stale
      // reference steers a dead object — no error, no log growth, exactly
      // the stall this nudge exists to recover). The registry lookup returns
      // the current live node, or the wake path materializes the session
      // afresh.
      const fresh = resolveAgentForTeam(team) ?? agent
      logger.info(`a2a: async nudge re-waking ${team} (task ${taskId} delivered but not consumed)`)
      steerRelay(fresh, `[A2A nudge] (task ${taskId}) your earlier routed message was delivered while this session could not start a turn — please consume the inbox backlog now.`)
    }, delayMs)
    ctx.effect(() => () => clearTimeout(timer), `a2a: async nudge ${taskId}`)
  }

  /**
   * Receipt auto-synthesis (backlog root fix): an async delivery used to rely
   * on the target model choosing to route a "[A2A receipt] task <id>" message
   * back — a pure convention the models almost never honored, so the owed
   * book filled to TASK_CAP with receipts that would never come. The host
   * already owns the machinery to know when the steered turn produced a final
   * reply (the same final-waiter the sync wait uses), so the receipt is now
   * synthesized host-side: on the target's next final text, one loopback async
   * dispatch returns the receipt to the caller's routable team. Idempotent via
   * isPending (settled/archived/superseded tasks never double-send), and
   * receipts themselves are never tracked as new debts.
   */
  const receiptWarnAt = new Map<string, number>()

  function armReceiptAutosend(target: Agent, taskId: string, callerTeam: string | undefined, deliveredText: string): void {
    if (!callerTeam || callerTeam === '') return
    // Never synthesize a receipt for a receipt: answering an envelope by mail
    // would ping-pong both ledgers.
    if (deliveredText.startsWith('[A2A receipt] task ')) return
    // Belt and braces for the self-route shape: when the receipt target
    // names the steered agent itself, the waiter's reply would bounce back
    // to the sender as a synthetic receipt for its own task. The delivery
    // guards refuse that shape outright; this keeps the receipt half dead
    // even if a future path reopens it.
    if (callerTeam === `${config.team}/${agentId8(target)}`) return
    registerFinalWaiter(target, (finalText, placeholder) => {
      // W7 slice-2: a host-authored placeholder (flush timeout, dead
      // session) must not synthesize a COMPLETION receipt — a wedged
      // session has no product, and hook 3 would otherwise ledger the
      // placeholder as one on the same-node loop-back.
      if (placeholder === true) return
      // Idempotency: a row THIS ledger tracks must still be pending
      // (settled/dead rows never re-send). A foreign task id (an inbound
      // route the caller tracks on ITS node) has no local row — the final
      // waiter itself fires at most once per armed task, which is the dedup.
      const row = taskLedger.list().find(entry => entry.taskId === taskId)
      if (row !== undefined && row.status !== 'pending') return
      const summary = `${finalText.trim().replace(/\s+/g, ' ').slice(0, SUMMARY_CAP) || 'done'} (auto)`
      // v2 envelope projection: header stays byte-compatible for every
      // legacy correlator; the machine JSON rides exactly one following line.
      const receipt = formatReceipt(taskId, summary, { outcome: 'completed', idempotencyKey: taskId })
      // Three-tier hard order (work-order P2): caller lane first; on failure
      // escalate ONCE to the owner mailbox — the outcome never evaporates
      // just because the original waiter died. Archive holds truth regardless.
      // The deliver closure is a FULL dispatch (local first, then the
      // directory walk with failover, throwing when nothing delivers): the
      // callback address may be another node's team, and a local-only
      // closure would silently no-op there — runReceiptLadder reads a
      // settled undefined as tier-1 success, so the receipt would vanish
      // without a log.
      void runReceiptLadder(
        {
          deliver: (team) => dispatchAnywhere(team, receipt, session, undefined, new AbortController().signal, true) as Promise<void>,
          ownerTeam: config.team,
          log: (stage, error) => {
            // N2 (observability): throttled per task to avoid ping-pong noise.
            const key = `receipt:${taskId}`
            if ((receiptWarnAt.get(key) ?? 0) + 60_000 > Date.now()) return
            receiptWarnAt.set(key, Date.now())
            logger.warn(`a2a: receipt autosend ${stage} for task ${taskId} failed: ${String(error).slice(0, 120)}`)
          },
        },
        callerTeam,
      ).catch(() => {
        // Ladder exhausted: the throttled breadcrumbs above already said why.
      })
    })
  }

  /**
   * Register one final-reply waiter for the agent and arm its flush timeout.
   * @param agent - the agent whose next assistant message answers the waiter.
   * @param answer - how the waiter's reply is delivered.
   * @returns the registered waiter (for callers that may retract it).
   */
  function registerFinalWaiter(agent: Agent, answer: (text: string, placeholder?: boolean) => void): FinalWaiter {
    const key = String(agent.id)
    const waiter: FinalWaiter = { answer, sinceEvents: sessionEventsOf(agent).length }
    waiter.timeoutDisposer = armFlushTimeout(key, waiter)
    pendingFinals.set(key, [...(pendingFinals.get(key) ?? []), waiter])
    return waiter
  }

  /**
   * Steer one direct route request into a live agent and resolve with its
   * final reply (final semantics always: the HTTP caller has no other
   * channel to learn the reply). A bridge round that outlived the reply
   * window answers with `status: TASK_STATE_DELIVERED` + the `bridge`
   * marker instead of a (false) completion.
   * @param taskId - the correlation key the steered receipt header carries.
   */
  async function routeIntoAgent(team: string, message: string, caller: string, taskId?: string): Promise<
    { ok: true; reply: string; status?: string; bridge?: 'native-teams'; placeholder?: boolean } | { ok: false; error: string }
  > {
    const agent = resolveAgentForTeam(team) ?? canvasLiveAgent(parseCanvasTeamName(team))
    if (agent !== undefined) {
      return routeIntoAgentFor(agent, team, message, caller, taskId)
    }
    // Wake-on-route: a cold joined team materializes on demand, then steers.
    const wake = wakeColdTeam(team)
    if (wake.kind === 'flight') {
      return wake.flight.then(
        agent => routeIntoAgentFor(agent, team, message, caller, taskId),
        (error: unknown) => ({ ok: false, error: `waking the session for team "${team}" failed: ${String(error)}` }) as const,
      )
    }
    // Native-teams inbound bridge (opt-in): a registry team claims the
    // handle and dispatches through its authoritative seam. Checked before
    // the bare-team fallback — a team named exactly like this node's team
    // resolves to the registry's claim, not the initiator redirect.
    if (config.nativeTeamsInbound === true) {
      const prepared = await nativeTeamsPrepare(team)
      if (prepared.ok) {
        const bridged = await nativeTeamsRound(prepared, team, caller, message, taskId)
        if (bridged.ok) {
          if (bridged.settled) return { ok: true, reply: bridged.reply }
          return { ok: true, reply: bridged.reply, status: 'TASK_STATE_DELIVERED', bridge: 'native-teams' }
        }
        return { ok: false, error: bridged.error }
      }
    }
    // Only the bare process team falls back to the live (initiator) agent.
    // A session-node-shaped team that misses is an error, never a silent
    // redirect: a mistyped or stale short id must not reach another session
    // through the initiator fallback. A bare-team route whose caller IS the
    // resolved agent is refused outright: the initiator is the routing
    // session itself, so delivering would only loop the dispatch home.
    if (team === config.team) {
      const live = liveAgent()
      if (live !== undefined) {
        if (callerIsAgent(live, caller)) return { ok: false, error: selfRouteText(team) }
        return routeIntoAgentFor(live, team, message, caller, taskId)
      }
      return { ok: false, error: 'No live DSH agent is available to accept this message.' }
    }
    return { ok: false, error: wake.kind === 'no-face' ? noWakeFaceText(team) : wake.kind === 'archived' ? archivedColdMatchText(team) : noColdMatchText(team) }
  }

  /**
   * Steer one direct route request into one named agent and resolve with its
   * final reply.
   * @param agent - the session-node agent the request addresses.
   * @param team - team name the caller routed to (diagnostics).
   * @param message - request text.
   * @param caller - caller label for the steered prefix.
   * @returns the agent's final reply, or the explicit failure.
   */
  function routeIntoAgentFor(agent: Agent, team: string, message: string, caller: string, taskId?: string): Promise<
    { ok: true; reply: string; placeholder?: boolean } | { ok: false; error: string }
  > {
    return new Promise((resolve) => {
      const waiter = registerFinalWaiter(agent, (text, placeholder) => {
        resolve({ ok: true, reply: text, ...(placeholder === true ? { placeholder: true } : {}) })
      })
      // The header names the sender first: `caller` is the routing node's
      // own label (the session that issued the route), while `team` is this
      // request's target — showing the target as "remote team" hid the
      // actual origin behind the receiver's own team name. The task id, when
      // the caller supplied one, rides the header so an "[A2A receipt] task
      // <id>" answer correlates with the caller's own route result.
      const from = caller === '' ? 'an unknown node' : caller
      const taskPrefix = taskId === undefined ? '' : `(task ${taskId}) `
      const text = `[A2A direct] ${taskPrefix}${fromClause(from)} (routed to ${team}) sent:

${message}`
      try {
        steerRelay(agent, text, caller === '' ? undefined : caller)
      } catch (error) {
        // The waiter was registered above, so the key always holds it; the
        // map-of-arrays stays a plain read.
        const key = String(agent.id)
        const entries = pendingFinals.get(key) as FinalWaiter[]
        const kept = entries.filter(entry => entry !== waiter)
        if (kept.length === 0) pendingFinals.delete(key)
        else pendingFinals.set(key, kept)
        waiter.timeoutDisposer?.()
        resolve({ ok: false, error: `The DSH session rejected the message: ${String(error)}` })
      }
    })
  }

  // ── Native-teams inbound bridge (opt-in: config.nativeTeamsInbound) ──
  //
  // Structural probe of the sibling registry (plugins never value-import
  // each other): when @nelsonlongxiang/dsh-native-teams is composed, its
  // `teams` service can classify a team name across planes (describeTarget)
  // and start a routed round through the same authoritative chain the
  // interactive route tools use (startRound). Absent registry, unmounted
  // seam, or an ambiguous / remote-plane answer all decline the bridge —
  // the standard resolution chain keeps its verdict. Dispatch is
  // dispatcher-level only: inbound callers address the team, never its
  // individual members (members stay visible-not-addressable).
  //
  // Precedence on every path (local tools and HTTP inbound alike): session
  // node → canvas team → cold joined wake → native-teams claim → bare team
  // fallback. Rounds are bounded like the steer path: a 180s reply-wait
  // deadline releases the caller while the round keeps running, and the
  // caller's abort (where one exists) cancels the round through its own
  // signal. Rounds emit no A2A receipt in this slice, so their results
  // carry the `bridge` marker and callers must not book them as
  // receipt-owed.
  interface BridgeTeamsDescriptor {
    readonly plane: 'local' | 'a2a'
    readonly ambiguous?: boolean
    readonly localLabel?: string
  }
  interface BridgeTeamsRegistry {
    listTeams(): Array<{ name: string; description: string }>
    describeTarget(handle: string): Promise<BridgeTeamsDescriptor>
    startRound(args: { team?: string; message: string }, parent: { id: string; session: { events?: readonly unknown[] } }, signal: AbortSignal): Promise<string>
  }

  function teamsRegistry(): BridgeTeamsRegistry | undefined {
    const candidate = (ctx as unknown as { get(name: string): unknown }).get('teams') as Partial<BridgeTeamsRegistry> | undefined
    if (candidate === undefined || candidate === null) return undefined
    if (typeof candidate.describeTarget !== 'function' || typeof candidate.startRound !== 'function' || typeof candidate.listTeams !== 'function') return undefined
    return candidate as BridgeTeamsRegistry
  }

  /** Reply-wait parity with the steer path's 180s deadline: native-teams
   * rounds settle on their own cadence, but a wedged seam must not park a
   * caller past a bounded window (config.nativeRoundWaitMs). */
  /** The claim table changes at registry-edit cadence: a short memo dedupes
   * the double probe (callers pre-check, the round re-verifies) without
   * pretending the answer is permanent. */
  const BRIDGE_CLAIM_TTL_MS = 5_000
  const bridgeClaimCache = new Map<string, { at: number; claimed: boolean }>()
  const bridgeTimers = new Set<ReturnType<typeof setTimeout>>()
  ctx.effect(() => () => {
    for (const timer of bridgeTimers) clearTimeout(timer)
  })

  /**
   * Whether the native-teams registry claims `team` as an unambiguous local
   * target, memoized for {@link BRIDGE_CLAIM_TTL_MS}. Ordinary misses never
   * throw (the D2 query contract); anything that does throw is treated as a
   * miss — the bridge is a guest here. The memo is skipped entirely while
   * the bridge is off, so the flag gates the probe itself.
   */
  async function nativeTeamsClaims(team: string): Promise<boolean> {
    if (config.nativeTeamsInbound !== true) return false
    const cached = bridgeClaimCache.get(team)
    if (cached !== undefined && Date.now() - cached.at < BRIDGE_CLAIM_TTL_MS) return cached.claimed
    const teams = teamsRegistry()
    let claimed = false
    if (teams !== undefined) {
      try {
        const descriptor = await teams.describeTarget(team)
        claimed = descriptor.plane === 'local' && descriptor.ambiguous !== true && descriptor.localLabel !== undefined
      } catch {
        claimed = false
      }
    }
    bridgeClaimCache.set(team, { at: Date.now(), claimed })
    // Bounded memo: probe-miss names accumulate one tiny row each; past a
    // generous cap, drop the whole table (a cold re-probe costs one local
    // describeTarget call).
    if (bridgeClaimCache.size > 512) bridgeClaimCache.clear()
    return claimed
  }

  type NativeTeamsPrepared =
    | { readonly ok: true; readonly teams: BridgeTeamsRegistry; readonly parent: { id: string; session: { events?: readonly unknown[] } } }
    | { readonly ok: false; readonly reason: 'not-claimed' }
    | { readonly ok: false; readonly reason: 'error'; readonly error: string }

  /**
   * Resolve everything the round needs BEFORE any caller is told the
   * dispatch happened: the claim, the seam, and a parent initiator. The
   * `error` variant is the only fast-failure shape — `not-claimed` simply
   * hands the address back to the standard resolution chain.
   */
  async function nativeTeamsPrepare(team: string): Promise<NativeTeamsPrepared> {
    if (!await nativeTeamsClaims(team)) return { ok: false, reason: 'not-claimed' }
    const teams = teamsRegistry()
    if (teams === undefined) return { ok: false, reason: 'not-claimed' }
    const parent = liveAgent()
    if (parent === undefined) return { ok: false, reason: 'error', error: 'No live DSH initiator is available to parent the native-teams round.' }
    // The alpha.4 Session face dropped the events member (the widened
    // BridgeTeamsRegistry accepts it optional) — the raw Agent carries the
    // ambient Session whose shape no longer overlaps, so project through the
    // widened structural face explicitly (type-level only; the runtime value
    // is the same live agent).
    const parentFace = parent as unknown as { id: string; session: { events?: readonly unknown[] } }
    return { ok: true, teams, parent: parentFace }
  }

  /** The A2A envelope rides the round message so the dispatcher sees the network origin. */
  function bridgeEnvelope(team: string, caller: string, message: string, taskId: string | undefined): string {
    const from = caller === '' ? 'an unknown node' : caller
    const taskPrefix = taskId === undefined ? '' : `(task ${taskId}) `
    return `[A2A direct] ${taskPrefix}${fromClause(from)} (routed to ${team}) sent:\n\n${message}`
  }

  type NativeTeamsRoundOutcome =
    | { readonly ok: true; readonly reply: string; readonly settled: boolean }
    | { readonly ok: false; readonly error: string; readonly phase?: 'pre-dispatch'; readonly aborted?: boolean }

  /** The projection for a round that outlived the reply window: unlike the
   * steer deadline's text, this must NOT promise a receipt — native-teams
   * rounds route none in this slice. */
  function bridgeUnsettledReply(team: string): string {
    return `The native-teams round for "${team}" is still running past the reply window; it was delivered and keeps going. Native-teams rounds route no A2A receipt in this slice — reconcile with a follow-up route (continuity rides the team's own durable round chain).`
  }

  /**
   * Fire the round and wait, bounded. The caller's signal (when it has one)
   * cancels the round itself; the deadline releases the caller with the
   * unsettled projection while the round keeps running detached.
   * @param prepared - a ready dispatch (claim, seam, parent) from {@link nativeTeamsPrepare}.
   */
  async function nativeTeamsRound(prepared: Extract<NativeTeamsPrepared, { ok: true }>, team: string, caller: string, message: string, taskId: string | undefined, external?: AbortSignal): Promise<NativeTeamsRoundOutcome> {
    const controller = new AbortController()
    // One listener, always removed after the race: an external abort cancels
    // the round through its own controller.
    const onExternalAbort = (): void => { controller.abort() }
    if (external !== undefined) {
      if (external.aborted) controller.abort()
      else external.addEventListener('abort', onExternalAbort)
    }
    if (controller.signal.aborted) return { ok: false, error: 'aborted before the native-teams round was dispatched', phase: 'pre-dispatch' }
    let roundError: unknown
    type Verdict = { readonly kind: 'settled'; readonly reply: string } | { readonly kind: 'failed' } | { readonly kind: 'deadline' } | { readonly kind: 'aborted' }
    let deadlineTimer: ReturnType<typeof setTimeout> | undefined
    const deadline = new Promise<Verdict>(resolve => {
      deadlineTimer = setTimeout(() => {
        if (deadlineTimer !== undefined) bridgeTimers.delete(deadlineTimer)
        resolve({ kind: 'deadline' })
      }, config.nativeRoundWaitMs ?? 180_000)
      deadlineTimer.unref?.()
      bridgeTimers.add(deadlineTimer)
    })
    const verdict = await Promise.race([
      prepared.teams.startRound({ team, message: bridgeEnvelope(team, caller, message, taskId) }, prepared.parent, controller.signal).then(
        (reply): Verdict => ({ kind: 'settled', reply }),
        (error: unknown): Verdict => { roundError = error; return { kind: 'failed' } },
      ),
      deadline,
      new Promise<Verdict>(resolve => {
        if (controller.signal.aborted) resolve({ kind: 'aborted' })
        else controller.signal.addEventListener('abort', () => resolve({ kind: 'aborted' }), { once: true })
      }),
    ])
    // Hygiene: the losing deadline timer stops here (not 180s later), and
    // the external-signal listener does not outlive the round.
    if (deadlineTimer !== undefined) {
      clearTimeout(deadlineTimer)
      bridgeTimers.delete(deadlineTimer)
    }
    if (external !== undefined) external.removeEventListener('abort', onExternalAbort)
    if (verdict.kind === 'settled') return { ok: true, reply: verdict.reply, settled: true }
    if (verdict.kind === 'deadline') return { ok: true, reply: bridgeUnsettledReply(team), settled: false }
    if (verdict.kind === 'aborted') return { ok: false, error: `the wait for the native-teams round "${team}" was aborted (the round was cancelled with it)`, aborted: true }
    return { ok: false, error: `the native-teams round for "${team}" failed: ${String(roundError)}` }
  }

  /* ── gh#9+gh#10 OriginClaim (docs/protocol/delivery-origin-auth.md).
     Envelope: X-A2A-Caller / -Url / -Ts / -Sig — canonical form is
     JSON.stringify([caller, callerUrl, ts]) (R2), signed with the CALLER'S
     CARD KEY; verification fetches the caller's card at callerUrl through
     our own enveloped memoized fetch (R1: our fetches are full-form by
     construction — the client stamps the envelope on every GET), then
     verifies the signature against THAT card's key and derives the caller
     name from the card (team or a published session team). ts skew ±5 min,
     stateless (no nonce ring — ruling refinement). Fail-closed everywhere. */
  const ORIGIN_CLAIM_SKEW_MS = 5 * 60_000
  /** legacyInbound warn metric (M1): envelope-absent deliveries during the
   *  window — the operator watches the tail drain before closing it. */
  let legacyInboundCount = 0
  const originClaimCallerShape = /^[a-z0-9-]+$/i
  async function verifyOriginClaim(req: IncomingMessage): Promise<{ ok: true; caller: string; callerUrl: string; card: A2aPeerCard } | { ok: false; reason: 'absent' | 'bad-caller-shape' | 'bad-ts' | 'no-card' | 'bad-sig' | 'not-derivable' }> {
    const caller = String(req.headers['x-a2a-caller'] ?? '')
    const callerUrl = String(req.headers['x-a2a-caller-url'] ?? '')
    const ts = Number(req.headers['x-a2a-caller-ts'] ?? '')
    const signature = String(req.headers['x-a2a-caller-sig'] ?? '')
    if (caller === '' || callerUrl === '' || !Number.isFinite(ts) || ts <= 0 || signature === '') return { ok: false, reason: 'absent' }
    if (!originClaimCallerShape.test(caller)) return { ok: false, reason: 'bad-caller-shape' }
    if (Math.abs(Date.now() - ts) > ORIGIN_CLAIM_SKEW_MS) return { ok: false, reason: 'bad-ts' }
    // Fetch the caller's card PLAIN (REVIEW M2 third-round ruling: the
    // envelope names a BARE ZONE, and derivation is the exact match
    // card.team === caller below — both ride the minimal card's signed
    // core, so a single envelope-less fetch suffices). An envelope-less
    // request returns immediately without recursing (the enveloped variant
    // re-opened mutual recursion); a warm full-form cache entry (R1)
    // short-circuits the fetch entirely.
    let card: A2aPeerCard | undefined = cardCache.get(callerUrl)?.card
    if (card === undefined) {
      try {
        // callerUrl is the caller's BASE URL — the card lives at the
        // well-known path under it.
        const cardUrl = callerUrl.endsWith('/') ? `${callerUrl}.well-known/agent-card.json` : `${callerUrl}/.well-known/agent-card.json`
        const response = await fetchImpl(cardUrl, { method: 'GET', headers: {} })
        const text = await response.text()
        const verdict = verifyCard(JSON.parse(text), Date.now())
        if (verdict.ok) card = verdict.card
        else (req as IncomingMessage & { __claimDbg?: unknown }).__claimDbg = { stage: 'verify', reason: verdict.reason, head: text.slice(0, 100) }
      } catch (error) {
        ;(req as IncomingMessage & { __claimDbg?: unknown }).__claimDbg = { stage: 'fetch', error: error instanceof Error ? error.message : String(error) }
        card = undefined
      }
    }
    if (card === undefined) return { ok: false, reason: 'no-card' }
    try {
      const publicKey = createPublicKey({ key: Buffer.from(card.publicKey, 'base64'), format: 'der', type: 'spki' })
      const valid = edVerify(undefined, Buffer.from(JSON.stringify([caller, callerUrl, ts]), 'utf8'), publicKey, Buffer.from(signature, 'base64'))
      if (!valid) return { ok: false, reason: 'bad-sig' }
    } catch {
      return { ok: false, reason: 'bad-sig' }
    }
    // Derivation (REVIEW M2, third-round ruling — shape narrowed to bare
    // zone): card.team === caller EXACT match. A zone/id8 envelope is
    // rejected as bad-caller-shape at the gate — session-level identity
    // rides the body's caller_session, judged by N3/S3 against the PUBLISHED
    // roster. (The prefix-derivation variant admitted an impersonation
    // chain: a same-zone foreign host signs the target's session handle
    // with its own key — prefix matches, signature verifies, full card
    // serves, and N3 then judges the body by the impersonated roster.
    // Fleet senders stamp bare zone only; the narrowed shape kills the
    // false rejections AND the impersonation vector with zero recursion.)
    if (card.team !== caller) {
      return { ok: false, reason: 'not-derivable' }
    }
    return { ok: true, caller, callerUrl, card }
  }

  /**
   * W3 (#18 half-side): is a VERIFIED caller LINKED to this host? Key
   * possession proves the caller is a real host; it says nothing about a
   * relationship with US. The full card carries collaboration facts
   * (sessionTeams/rosters), so it additionally requires a link:
   *   1. same-host membership — the caller's card URL origin equals OUR
   *      card URL origin (the loopback self-fetch face: true self is an
   *      ORIGIN equality; zone-name equality carries no identity in a
   *      single-zone fleet), or one of our session pseudo-handles;
   *   2. a canvas remote ref — the EXACT handle only (#19 D1, ruling
   *      final: the zone-sibling variant was a blanket fallback that any
   *      one ref opened to a whole zone's hosts in single-zone fleets; the
   *      operator names THAT node, that node links);
   *   3. BILATERAL seeding (review M1 fix): our config.peers contains the
   *      caller's URL **and** the caller's card (fetched fresh during
   *      verification) carries our origin among its peers — both
   *      operators made the gesture, each on their own side. The single-
   *      sided card-claims variant was a hole the reviewer's adversarial
   *      probe walked through (one config.peers line → full card with
   *      zero commitment from us): peers is an unsigned served-fresh
   *      field, exactly the self-description trust class N3/V5 abolished.
   *      Our operator's config anchors; the card shadow corroborates.
   */
  function callerLinkedToThisHost(caller: string, callerUrl: string, callerCard: A2aPeerCard | undefined): boolean {
    // Basis 1, same-host membership (review second-round M-fix): "self" is
    // an ORIGIN equality, not a zone-name equality. `caller === config.team`
    // granted unconditionally in a single-zone fleet (the deployment
    // reality: every host named 'dsh') — any verified caller naming the
    // shared zone string was "us". True self is the loopback self-fetch
    // face: the caller's card URL origin equals OUR card URL origin.
    try {
      if (callerUrl !== '' && new URL(callerUrl).origin === new URL(ownCardUrl).origin) return true
    } catch { /* malformed callerUrl — falls through to the record bases */ }
    for (const id of joinedSessions.list()) {
      if (`${config.team}/${id8(id)}` === caller) return true
    }
    // #19 D1 (ruling final): canvas remote refs admit by EXACT HANDLE only.
    // The zone-sibling variant (`refZone === zone`) was a blanket fallback —
    // in a single-zone fleet any one ref linked the whole zone face, the
    // exact trust shape the exposure ruling removed. Exact handle in, the
    // operator named THAT node.
    for (const name of canvasStore.list()) {
      for (const ref of canvasStore.remoteMembersOf(name)) {
        if (ref === caller) return true
      }
    }
    // Basis 3, BILATERAL (review M1 fix): OUR config.peers seeds a URL
    // whose origin matches the caller's card URL, AND the caller's card
    // reciprocates by carrying OUR origin among its peers — both
    // operators made the gesture, each on their own side. The single-
    // sided card-claims variant was a hole the reviewer's adversarial
    // probe walked through (one config.peers line on the CALLER → full
    // card with zero commitment from us): peers is an unsigned
    // served-fresh field, exactly the self-description trust class
    // N3/V5 abolished. Our operator's own config anchors; the card
    // shadow only corroborates.
    if (callerCard !== undefined && ownCardUrl !== '') {
      const ourOrigin = new URL(ownCardUrl).origin
      const callerOrigin = new URL(callerUrl).origin
      const weSeedThem = config.peers.some(peer => {
        try { return new URL(peer).origin === callerOrigin } catch { return false }
      })
      const theySeedUs = (callerCard.peers ?? []).some(peer => {
        try { return new URL(peer).origin === ourOrigin } catch { return false }
      })
      if (weSeedThem && theySeedUs) return true
    }
    return false
  }

  /* ── Inbound admission shared by the peer faces (/a2a/direct,
     /a2a/log) and — since the boundary-hardening wave (W1) — the LOCAL
     dispatch candidate: caller_session is the protocol contract.
     Anonymous is refused, and admission is decided by THIS host's own
     records — never by the caller's self-description (gh#7 N3, V3/V5).
     Returns the refusal detail, or undefined when admissible. */

  /**
   * W1/W2 shared-team admission core (pure over the host's stores): a
   * same-zone zone/id8 caller passes when it holds a team this host's
   * records also hold. The caller's basis is its roster declarations UNION
   * its canvas memberships (W2②: canvas teammates share a team by being in
   * the team — the roster is not the only link record); the host's basis is
   * the routable set (bare zone, joined handles, canvas names) union other
   * sessions' declarations. Used by both the inbound faces and the local
   * dispatch candidate so the two paths can never diverge.
   */
  function sameZoneSharedTeamRefusal(caller: string, targetTeam?: string): string | undefined {
    const declared = new Set<string>()
    let callerSessionId: string | undefined
    for (const entry of teamMemberships.list()) {
      if (`${config.team}/${id8(entry.session)}` === caller) {
        callerSessionId = entry.session
        for (const t of entry.teams) declared.add(t)
      }
    }
    // W2②: canvas membership is a link record too — the caller's session
    // sitting in a canvas team declares that team as much as a roster line.
    if (callerSessionId === undefined) {
      for (const id of joinedSessions.list()) {
        if (`${config.team}/${id8(id)}` === caller) { callerSessionId = id; break }
      }
    }
    if (callerSessionId !== undefined) {
      for (const name of canvasStore.teamsOf(callerSessionId)) declared.add(canvasTeamOf(name))
    } else {
      // Issue #43: a same-zone handle that resolves to NO local session is a
      // CROSS-HOST member (two nodes sharing one zone name — the fleet's
      // common `dsh` spelling). The canvas link record exists on this host
      // as a REMOTE MEMBER REF the operator added; the foreign-zone branch
      // (a2aCallerRefusal) already honors that basis — the same-zone path
      // must too, or a linked remote member is refused as teamless. The
      // trust basis is unchanged: this host's operator-composed canvas,
      // never the caller's self-description (V5).
      for (const name of canvasStore.list()) {
        if (canvasStore.remoteMembersOf(name).includes(caller)) declared.add(canvasTeamOf(name))
      }
      // gh#71 fix ②: the warm card cache's peer canvasOrg is the same-zone
      // cross-host basis too — an org entry naming BOTH the caller's handle
      // and one of THIS host's own handles is a shared team (双向识别: the
      // composition gesture happened on the other host's board; both ends
      // are named). Read-only over the cache; a caller org that never names
      // an own handle still refuses (V5 preserved).
      const ownHandles = new Set<string>([config.team, ...joinedSessions.list().map(id => `${config.team}/${id8(id)}`)])
      for (const cached of cardCache.values()) {
        const org = (cached.card as { canvasOrg?: Array<{ team?: unknown; members?: unknown }> } | undefined)?.canvasOrg
        if (!Array.isArray(org)) continue
        for (const e of org) {
          if (typeof e.team !== 'string' || e.team === '' || !Array.isArray(e.members)) continue
          if (e.members.includes(caller) && e.members.some(m => typeof m === 'string' && ownHandles.has(m))) declared.add(e.team)
        }
      }
    }
    const routable = new Set<string>([config.team])
    for (const id of joinedSessions.list()) routable.add(`${config.team}/${id8(id)}`)
    for (const name of canvasStore.list()) routable.add(canvasTeamOf(name))
    const otherLocalDeclarations = new Set<string>()
    for (const entry of teamMemberships.list()) {
      if (`${config.team}/${id8(entry.session)}` === caller) continue
      for (const t of entry.teams) otherLocalDeclarations.add(t)
    }
    const shared = [...declared].some(t => routable.has(t) || otherLocalDeclarations.has(t))
    // F5 (gh#26, attribute-owner ruling): same-host admission needs a
    // TARGET-level intersection — a canvas member used to reach ANY session
    // team on this host through a host-level link alone. The target's link
    // set = its roster declarations ∪ its canvas teams. EXCEPTION (ruling,
    // 成文): the PROCESS face (target === config.team) is the owner face,
    // not a member face — any shared team clears it.
    if (targetTeam !== undefined && targetTeam !== config.team) {
      let targetLinks: Set<string> | undefined
      const targetId8 = targetTeam.startsWith(`${config.team}/`) ? targetTeam.slice(config.team.length + 1) : undefined
      if (targetId8 !== undefined) {
        // Only a KNOWN local session earns target-level judgement; an
        // unresolvable handle (archived/foreign spelling) keeps the
        // host-level basis — an empty target set must not refuse everyone.
        // The handle carries the id8 SLICE, so resolve it back to the
        // session id before asking the stores (canvas teamsOf keys by id).
        const targetSession = joinedSessions.list().find(sessionId => id8(sessionId) === targetId8)
          ?? teamMemberships.list().find(entry => id8(entry.session) === targetId8)?.session
        if (targetSession !== undefined) {
          targetLinks = new Set<string>()
          for (const entry of teamMemberships.list()) {
            if (entry.session === targetSession) for (const t of entry.teams) targetLinks.add(t)
          }
          for (const name of canvasStore.teamsOf(targetSession)) targetLinks.add(canvasTeamOf(name))
          // gh#71 fix ②: the warm cache's org basis at target level too —
          // an org entry naming BOTH the caller and the target handle is
          // the shared team (same 双向识别 rule as the host-level basis).
          for (const cached of cardCache.values()) {
            const org = (cached.card as { canvasOrg?: Array<{ team?: unknown; members?: unknown }> } | undefined)?.canvasOrg
            if (!Array.isArray(org)) continue
            for (const e of org) {
              if (typeof e.team !== 'string' || e.team === '' || !Array.isArray(e.members)) continue
              if (e.members.includes(caller) && e.members.includes(targetTeam)) targetLinks.add(e.team)
            }
          }
        }
      } else {
        const canvasName = canvasStore.list().find(name => canvasTeamOf(name) === targetTeam)
        if (canvasName !== undefined) {
          targetLinks = new Set<string>([targetTeam])
          for (const memberId of canvasStore.membersOf(canvasName)) {
            for (const entry of teamMemberships.list()) if (entry.session === memberId) for (const t of entry.teams) targetLinks.add(t)
          }
        }
      }
      if (targetLinks !== undefined) {
        if ([...declared].some(t => targetLinks!.has(t))) return undefined
        return declared.size === 0
          ? `caller "${caller}" declares no team membership on this host's roster — a teamless node has no network (S3 phase-3 admission). Declare a shared team on both ends, or route through a teamed member.`
          : `caller "${caller}" shares no team with target "${targetTeam}" — declared [${[...declared].join(', ')}], target links [${[...targetLinks].join(', ')}] (F5 target-level admission: a host-level link alone does not open every session team).`
      }
      // Unresolvable target (foreign/zone delegation): host-level basis.
    }
    if (shared) return undefined
    return declared.size === 0
      ? `caller "${caller}" declares no team membership on this host's roster — a teamless node has no network (S3 phase-3 admission). Declare a shared team on both ends, or route through a teamed member.`
      : `caller "${caller}" declares teams [${[...declared].join(', ')}] — none is routable on this node (shared-team admission). Declare a shared team on both ends, or route through a teamed member.`
  }

  /**
   * W1: does a caller label fall under the joined-face admission gate? The
   * zone/id8 shape with THIS zone names a joined session node — the face
   * the boundary-hardening wave closes. The initiator face (bare node
   * team) and foreign-zone labels are judged elsewhere (F1b host-face
   * rules; the foreign branch below) and stay untouched.
   */
  const joinedFaceCallerShape = /^[a-z0-9-]+\/[0-9a-f]{8}$/i
  function joinedFaceAdmissionRefusal(callerSession: string | undefined, targetTeam?: string): string | undefined {
    if (callerSession === undefined || callerSession === '') return undefined
    if (!joinedFaceCallerShape.test(callerSession)) return undefined
    if (callerSession.slice(0, callerSession.indexOf('/')) !== config.team) return undefined
    return sameZoneSharedTeamRefusal(callerSession, targetTeam)
  }

  function a2aCallerRefusal(caller: string, targetTeam?: string): string | undefined {
    if (!config.teamScopeRouting) return undefined
    if (caller === '') {
      return 'caller_session is required — anonymous deliveries are refused (S3 phase-3b). Pass caller_session as <zone>/<id8>.'
    }
    // Host face: the node's own bare zone team is a host fact, always
    // admissible to itself.
    if (caller === config.team) return undefined
    const zoneShaped = /^[a-z0-9-]+\/[0-9a-f]{8}$/i.test(caller)
    if (zoneShaped) {
      const callerZone = caller.slice(0, caller.indexOf('/'))
      if (callerZone === config.team) {
        // Same-zone handle: the W1/W2 shared admission core — roster
        // declarations UNION canvas memberships against this host's
        // records (canvas names are link records too; see the helper).
        // F5: the routed team rides along so admission can require a
        // TARGET-level intersection.
        return sameZoneSharedTeamRefusal(caller, targetTeam)
      }
      // Foreign-zone handle (N3/N4): admitted ONLY through this host's
      // operator-established cross-host links — a canvas remote member ref
      // the operator added by hand. The card cache used to be a basis; a
      // card is the CALLER'S own claim about itself (V5: any host could
      // declare the target's team on its own card and self-serve
      // admission), so it no longer decides anything here. First-contact
      // learn-and-admit dies with it.
      for (const name of canvasStore.list()) {
        if (canvasStore.remoteMembersOf(name).includes(caller)) return undefined
      }
      return `caller "${caller}" has no operator-established link on this node — cross-host admission requires a canvas remote membership this host's operator added (N3/N4: the caller's own card claims are self-description, not links). Ask this host's operator to add the member in the A2A workbench, or route through a linked member.`
    }
    // Free-form label (not zone/id8): only THIS host's own node facts — a
    // joined session id, its zone-qualified pseudo-handle (id8 passes
    // short ids through, so dsh/agent-1 is a local shape), or a live
    // node's label. Anything else is an unverifiable self-description
    // (V3: 'anyone-at-all' used to pass).
    if (joinedSessions.list().includes(caller)) return undefined
    for (const id of joinedSessions.list()) {
      if (`${config.team}/${id8(id)}` === caller) return undefined
    }
    for (const agent of sessionNodes.values()) {
      if (String(agent.id) === caller) return undefined
    }
    // gh#45: a DEPOSITED CLI handle is a published node fact of this host
    // (the card's sessionTeams carries it; the envelope's zone derivation
    // already proved the CLI key on the wire face's own verify). The
    // handle is <agent-name>/<uuid16> — not zone/id8-shaped, hence this
    // branch, but it is as much a fact as a joined session.
    if (cliDeposits.get(caller) !== undefined) return undefined
    return `caller_session "${caller}" matches no node fact on this host (joined session id, live node label, or deposited CLI handle) — free-form caller labels are self-description and are not admissible (N3). Pass caller_session as <zone>/<id8> with an operator-established link.`
  }

  /* ── Session-log read faces (shared by the local control route and the
     peer /a2a/log face): both answer from <dshHome>/sessions with
     identical semantics — artifact existence is the only gate (archived
     and never-joined sessions stay readable), caps mirror
     session-transcript.ts. */
  function scanSessionLogList(): Array<{ id: string; mtimeMs: number; sizeBytes: number }> {
    const rows: Array<{ id: string; mtimeMs: number; sizeBytes: number }> = []
    const sessionsRoot = join(home, 'sessions')
    if (!existsSync(sessionsRoot)) return rows
    for (const bucket of readdirSync(sessionsRoot, { withFileTypes: true })) {
      if (!bucket.isDirectory()) continue
      for (const child of readdirSync(join(sessionsRoot, bucket.name), { withFileTypes: true })) {
        if (!child.isDirectory()) continue
        const dir = join(sessionsRoot, bucket.name, child.name)
        const files = readdirSync(dir).filter(name => name.startsWith('session.') && (name.endsWith('.jsonl.zstd') || name.endsWith('.jsonl')))
        if (files.length === 0) continue
        let newest: { mtimeMs: number; sizeBytes: number } | undefined
        for (const name of files) {
          const st = statSync(join(dir, name))
          if (newest === undefined || st.mtimeMs > newest.mtimeMs) newest = { mtimeMs: st.mtimeMs, sizeBytes: st.size }
        }
        if (newest !== undefined) rows.push({ id: child.name, ...newest })
      }
    }
    rows.sort((a, b) => b.mtimeMs - a.mtimeMs)
    return rows
  }

  function readSessionLogTail(id: string, limit: number): { ok: true; id: string; messages: Array<{ role: string; text: string; time?: number }> } | { ok: false; error: string } {
    const sessionsRoot = join(home, 'sessions')
    let logPath: string | undefined
    if (existsSync(sessionsRoot)) {
      for (const entry of readdirSync(sessionsRoot, { withFileTypes: true })) {
        if (!entry.isDirectory()) continue
        const candidate = join(sessionsRoot, entry.name, id)
        if (!existsSync(candidate)) continue
        const files = readdirSync(candidate).filter(name => name.startsWith('session.') && (name.endsWith('.jsonl.zstd') || name.endsWith('.jsonl')))
        // Generation artifacts: session.v{N}.jsonl[.zstd] is the newest
        // format generation — read the highest N, preferring zstd at the
        // same generation.
        const generation = (name: string): number => Number(name.match(/\.v(\d+)\./)?.[1] ?? 0)
        const rank = (name: string): number => generation(name) * 2 + (name.endsWith('.zstd') ? 1 : 0)
        files.sort((a, b) => rank(b) - rank(a))
        logPath = files[0] !== undefined ? join(candidate, files[0]) : undefined
        break
      }
    }
    if (logPath === undefined) return { ok: false, error: 'no log artifact for this session' }
    const stat = statSync(logPath)
    if (stat.size > TRANSCRIPT_MAX_FILE_BYTES) return { ok: false, error: 'session log exceeds the size cap' }
    const entries = extractTranscript(decodeSessionLog(readFileSync(logPath)), limit)
    return { ok: true, id, messages: entries.map(entry => ({ role: entry.role, text: entry.text, ...(entry.time !== undefined ? { time: entry.time } : {}) })) }
  }

  whenWebServerSettled((webServer) => {
    // gh#45 CLI 户口卡面 (peer face, unsigned card serve): the deposited
    // CLI's SIGNED card is served verbatim under its own base URL — an
    // OriginClaim verification of a CLI envelope fetches exactly here
    // (callerUrl + /.well-known/agent-card.json). Expired or unknown
    // handles 404 (auto-deregistered — the identity is dead until
    // re-publish).
    ctx.effect(() => webServer.register({
      kind: 'prefix',
      path: '/a2a/cli',
      handler: (req: IncomingMessage, res: ServerResponse) => {
        const MOUNT = '/a2a/cli'
        const rest = (req.url ?? '').slice(MOUNT.length)
        const m = /^\/([^/]+)\/\.well-known\/agent-card\.json$/.exec(rest)
        if (req.method !== 'GET' || m === null) {
          res.writeHead(404, { 'Content-Type': 'text/plain' })
          res.end()
          return
        }
        const handle = decodeURIComponent(m[1]!)
        const row = cliDeposits.get(handle)
        if (row === undefined) {
          res.writeHead(404, { 'Content-Type': 'text/plain' })
          res.end()
          return
        }
        res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' })
        res.end(row.cardJson)
      },
    }), 'a2a: cli deposit card face')

    // gh#41 fleet planning, peer-write face: a LINKED peer may regulate this
    // host's canvas teams (create / add-member / remove-member) with a
    // VERIFIED OriginClaim envelope. The owner's ruling: any peer composes
    // and regulates the whole fleet — the bilateral/operator link IS the
    // authorization, the envelope proves the key, and every op lands in the
    // activity ring + host log for audit. Unlinked or unsigned callers get
    // a refusal, never a mutation.
    ctx.effect(() => webServer.register({
      kind: 'exact',
      path: '/a2a/canvas-op',
      handler: async (req: IncomingMessage, res: ServerResponse) => {
        const send = (status: number, payload: string): void => {
          res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
          res.end(payload)
        }
        if (req.method !== 'POST') { send(200, JSON.stringify({ ok: false, error: 'POST required' })); return }
        const chunks: Buffer[] = []
        let size = 0
        req.on('data', (chunk: Buffer) => { size += chunk.length; if (size > 16 * 1024) { chunks.length = 0; return } chunks.push(chunk) })
        req.on('end', () => {
          void (async () => {
            try {
              const body = JSON.parse(Buffer.concat(chunks).toString('utf8')) as { op?: unknown; name?: unknown; id?: unknown }
              const claim = await verifyOriginClaim(req)
              if (!claim.ok) {
                logger.warn(`a2a: canvas-op claim failed (${claim.reason}) — caller=${String(req.headers['x-a2a-caller'] ?? '')} url=${String(req.headers['x-a2a-caller-url'] ?? '')} ts=${String(req.headers['x-a2a-caller-ts'] ?? '')}`)
                send(200, JSON.stringify({ ok: false, error: `untrusted-origin: OriginClaim verification failed (${claim.reason}) — canvas regulation requires a signed envelope`, code: -32000 }))
                return
              }
              if (!callerLinkedToThisHost(claim.caller, claim.callerUrl, claim.card)) {
                recordActivity('in', 'fleet-canvas', claim.caller, false)
                send(200, JSON.stringify({ ok: false, error: `caller "${claim.caller}" is not linked to this host — canvas regulation requires the operator link (bilateral seed, canvas ref, or same-host membership)` }))
                return
              }
              const op = body.op
              const name = typeof body.name === 'string' ? body.name : ''
              const id = typeof body.id === 'string' ? body.id : ''
              let payload: { ok: boolean; members?: readonly string[]; error?: string }
              if (op === 'create') {
                const stored = canvasStore.create(name)
                payload = stored === undefined ? { ok: false, error: 'invalid name or team cap reached' } : { ok: true, members: canvasStore.membersOf(stored) }
              } else if (op === 'add-member') {
                const memberValid = isRemoteMemberRef(id) ? validRemoteMemberRef(id) : id !== '' && (sessionNodes.has(id) || joinedSessions.has(id))
                payload = name === '' || !memberValid
                  ? { ok: false, error: 'name and a member (joined session id, or a zone-qualified remote team handle) are required' }
                  : (canvasStore.create(name), { ok: canvasStore.addMember(name, id), members: canvasStore.membersOf(name) })
              } else if (op === 'remove-member') {
                payload = { ok: name !== '' && canvasStore.removeMember(name, id), members: name !== '' ? canvasStore.membersOf(name) : undefined }
              } else {
                payload = { ok: false, error: 'op must be create | add-member | remove-member' }
              }
              recordActivity('in', 'fleet-canvas', `${claim.caller}:${String(op)}`, payload.ok)
              logger.info(`a2a: fleet canvas op from ${claim.caller} (${String(op)} ${name}${id !== '' ? ` ${id}` : ''}) -> ${payload.ok ? 'applied' : `refused: ${payload.error ?? '?'}`}`)
              send(200, JSON.stringify(payload))
            } catch (error) {
              send(200, JSON.stringify({ ok: false, error: `canvas-op failed: ${error instanceof Error ? error.message : String(error)}` }))
            }
          })()
        })
      },
    }), 'a2a: fleet canvas-op peer route')

    ctx.effect(() => webServer.register({
      kind: 'exact',
      path: '/a2a/direct',
      handler: async (req: IncomingMessage, res: ServerResponse) => {
        const chunks: Buffer[] = []
        let size = 0
        // B5 enforcement: 512 KiB hard cap. An oversized body is rejected,
        // never truncated and never connection-killed mid-read — buffering
        // stops at the crossing chunk, the stream drains to `end`, and the
        // peer receives one structured 413 with a wire error code (the old
        // behavior tore the socket down with no diagnosis at all).
        let overflowed = false
        const declared = Number.parseInt(String(req.headers['content-length'] ?? ''), 10)
        if (Number.isFinite(declared) && !withinRouteBodyCap(declared)) overflowed = true
        req.on('data', (chunk: Buffer) => {
          if (overflowed) return
          const next = size + chunk.length
          if (!withinRouteBodyCap(next)) {
            overflowed = true
            chunks.length = 0
            return
          }
          size = next
          chunks.push(chunk)
        })
        /* v8 ignore next 6 -- client aborts surface as 'close' via the shared
           webServer's per-request guard; a raw req 'error' needs a malformed
           HTTP stream the webServer rejects before this handler exists */
        req.on('error', () => {
          if (!res.headersSent) {
            res.writeHead(400)
            res.end()
          }
        })
        req.on('end', async () => {
          if (overflowed) {
            if (!res.writableEnded && !res.headersSent) {
              const payload = JSON.stringify({ error: 'payload too large', code: WIRE_ERROR_PAYLOAD_TOO_LARGE })
              res.writeHead(413, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
              res.end(payload)
            }
            return
          }
          let body: {
            readonly team?: unknown
            readonly message?: unknown
            readonly context_id?: unknown
            readonly caller_session?: unknown
            readonly callback?: unknown
            readonly wait?: unknown
            readonly task_id?: unknown
          }
          try {
            body = JSON.parse(Buffer.concat(chunks).toString('utf8')) as typeof body
          } catch {
            const payload = JSON.stringify({ error: 'malformed body', code: -32000 })
            res.writeHead(400, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
            res.end(payload)
            return
          }
          // V2 (gh#7, S1): the delivery face honors the apiKey gate exactly
          // like the control face — a configured key without this header
          // used to let anyone reachable steer sessions while the control
          // routes demanded the key, making it decorative for delivery.
          // Empty-key deployments keep the documented open posture.
          if (config.apiKey !== '') {
            const presented = String(req.headers['x-api-key'] ?? '')
            if (!secretEqual(presented, config.apiKey)) {
              const payload = JSON.stringify({ error: 'unauthorized: X-API-Key required on the delivery face (apiKey is configured)', code: -32000 })
              res.writeHead(401, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
              res.end(payload)
              return
            }
          }
          const team = typeof body.team === 'string' ? body.team : ''
          const message = typeof body.message === 'string' ? body.message : ''
          const caller = typeof body.caller_session === 'string' ? body.caller_session : ''
          // P2 receipt-callback: where THIS node's receipt should route on
          // the caller's side — the caller knows its routable address best
          // (a joined session's node team, e.g. via the transport face's
          // callbackTarget mapping). Bounded; absent → the caller label
          // plays its usual role.
          const callback = typeof body.callback === 'string' && body.callback !== '' && body.callback.length <= 128 ? body.callback : ''
          const noWait = body.wait === false
          const contextId = typeof body.context_id === 'string' && body.context_id !== '' ? body.context_id : `ctx-${Math.random().toString(16).slice(2, 10)}`
          // The caller-born task id (idempotency key): echo it when present
          // so the receipt header correlates with the caller's own result;
          // pre-0.5.3 callers carry none and this node mints one.
          const taskId = typeof body.task_id === 'string' && body.task_id !== '' ? body.task_id : `direct-${Math.random().toString(16).slice(2, 10)}`
          if (team === '' || message === '') {
            const payload = JSON.stringify({ error: 'team and message are required', code: -32000 })
            res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
            res.end(payload)
            return
          }
          // Phase-3 admission (owner ruling 2026-09-01, decision-seat
          // filed): an inbound direct delivery must show a SHARED team.
          // Local-zone callers are judged synchronously and exactly — the
          // declaration lives in this host's own roster store, so the
          // Anonymous-delivery refusal (S3 phase-3b, test-seat finding
          // direct-001649ab): a delivery with NO caller_session field
          // skips the admission gate entirely (nothing to judge) — that
          // anonymous hole let any local process or reachable peer inject
          // into a live session. The protocol contract is caller_session;
          // its absence is now refused instead of silently waved through.
          // (0.6.15: the rule now lives in a2aCallerRefusal so the
          // read-only /a2a/log face admits callers by exactly the same
          // standard as message delivery.)
          const callerRefusal = a2aCallerRefusal(caller, team)
          if (callerRefusal !== undefined) {
            recordActivity('in', team, caller === '' ? 'anonymous' : caller, false)
            const payload = JSON.stringify({ error: callerRefusal, code: -32000, team, task_status: 'TASK_STATE_FAILED' })
            res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
            res.end(payload)
            return
          }
          // gh#9+gh#10 OriginClaim on the delivery face (M1): an envelope
          // that is present but unverifiable rejects untrusted-origin; an
          // ABSENT envelope during the window walks on with a counted
          // legacyInbound warn (the operator watches the tail drain), and
          // after the window closes it rejects like a failed signature —
          // N3 proves a NAME's linkability, never key possession.
          const claim = await verifyOriginClaim(req)
          if (!claim.ok) {
            if (claim.reason !== 'absent' || config.originClaimWindow === false) {
              recordActivity('in', team, caller, false)
              const payload = JSON.stringify({ error: `untrusted-origin: OriginClaim verification failed (${claim.reason}) — present a signed envelope (X-A2A-Caller/-Url/-Ts/-Sig with your card key) or upgrade your node`, code: -32000, team, task_status: 'TASK_STATE_FAILED' })
              res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
              res.end(payload)
              return
            }
            legacyInboundCount += 1
          }

          // Server-side idempotency (P3/B3): one key, one execution inside
          // the window. Same key + same payload fingerprint ⇒ replay (409,
          // -32003, replay:true — the prior attempt stays authoritative);
          // same key + different payload ⇒ hard conflict (409, -32002).
          // Checked BEFORE any steering or ledger correlation: a replay must
          // never re-enter the target session, no matter how it settles.
          const idemFingerprint = peerPayloadFingerprint({ caller, message, noWait, team })
          const idemVerdict = idempotencyStore.claim(taskId, idemFingerprint)
          if (idemVerdict !== 'fresh') {
            const replay = idemVerdict === 'replay'
            // 0.5.36 observability: conflict = caller bug (graph-loop prompt
            // minting / key management) — warn loudly so it is never misread
            // as the normal-depth-defense zero-traffic shape. Replays stay
            // silent by design.
            if (!replay) logger.warn(`a2a: idempotency CONFLICT on task ${taskId.slice(0, 80)} — same key reused with a different payload (caller bug; never auto-retry)`)
            const payload = JSON.stringify({
              error: replay ? 'duplicate task id within the idempotency window' : 'task id reused with a different payload',
              code: replay ? WIRE_ERROR_REPLAY_REJECTED : WIRE_ERROR_IDEMPOTENCY_CONFLICT,
              task_id: taskId,
              replay,
            })
            res.writeHead(409, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
            res.end(payload)
            return
          }
          // The caller-side receipt correlation: a message shaped as a
          // receipt resolves the task it echoes, whichever wait semantics
          // carried it here. Correlation is bookkeeping only — the message
          // steers on exactly as before.
          settleAndAnnounce(message)
          // gh#45 CLI mailbox (wire face): a delivery targeting a DEPOSITED
          // CLI handle never resolves a session and never wakes — it lands
          // in the deposit's mailbox and answers delivered. Placement here
          // keeps the idempotency claim (above) exactly as for sessions.
          const cliRow = cliDeposits.get(team)
          if (cliRow !== undefined) {
            cliDeposits.mail(team, caller, message)
            recordActivity('in', team, caller, true)
            logger.info(`a2a: cli mailbox delivery for ${team} (from ${caller})`)
            const payload = JSON.stringify({ routed: true, delivered: true, receipt: 'mailbox', team, task_id: taskId, task_status: 'TASK_STATE_COMPLETED', note: `delivered to the mailbox of ${team} — the CLI polls while online` })
            res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
            res.end(payload)
            return
          }
          // Inbound routing is foreground demand: boot prewarm yields for a
          // quiet window around it.
          lastWakeDemandAt = Date.now()
          // wait:false delivers without the final-reply hold: steer resolves
          // synchronously inside routeIntoAgentFor, so by the time the agent
          // lookup settles the message is already in — answer delivered and
          // let the receipt contract carry the reply.
          if (noWait) {
            // Issue #41 companion fix: the no-wait inbound branch resolved
            // only bare session teams — a canvas team delivery (wait:false)
            // fell through to the cold tier and answered a bogus
            // no-match although a live member existed. Same resolution as
            // the waiting face (routeIntoAgent), and likewise NO initiator
            // skip: the wire face delivers faithfully to the first live
            // member, whoever the caller is.
            const agent = resolveAgentForTeam(team) ?? canvasLiveAgent(parseCanvasTeamName(team))
            const wake = agent !== undefined ? undefined : wakeColdTeam(team)
            const deliver = (target: Agent): void => {
              const from = caller === '' ? 'an unknown node' : caller
              // The receipt target: the caller's callback address when it
              // supplied one (a session node team — wake-on-route covers a
              // cold one), else the caller label as before.
              const receiptTarget = callback !== '' ? callback : from
              try {
                // The receipt header carries the task id: the target echoes
                // it verbatim in "[A2A receipt] task <id> ...", closing the
                // correlation loop with the caller's own route result.
                // F1' (consumed-probe prior-running): capture the pre-steer
                // status first — a target that was already running (its own
                // turn / a brand-new session's activation window) reads
                // `running` after the steer whether or not our wake was
                // latched, so the post-steer read alone would answer a false
                // consumed:true and strand the message.
                const runningBeforeSteer = probeConsumption(target, taskId)
                steerRelay(target, `[A2A direct] (task ${taskId}) ${fromClause(from)} (routed to ${team}) sent:\n\n${message}\n\n(When done, route your outcome back with one call — a2a_route { team: "${receiptTarget}", message: "[A2A receipt] task ${taskId} <one-line outcome>" }.)`, from === 'an unknown node' ? undefined : from)
                recordActivity('in', team, caller, true)
                armReceiptAutosend(target, taskId, receiptTarget, message)
                // v0.5.23 (async-stall): "delivered" only proves the steer call
                // returned — not that a turn started. An idle-phase steer wakes
                // the driver, but a maintenance/abort window latches the wake for
                // replay that may never fire (defect t-mt6nd0sq-hxuhj6: seven
                // delivered:true routes with zero log growth). Probe the driver
                // shortly after: running means the message is being consumed;
                // still-idle means the wake was latched or dropped — surface that
                // honestly and arm a delayed nudge retry below.
                // F1': a prior-running target never trusts the single
                // post-steer read — answer consumed:false conservatively and
                // arm the nudge (a false negative costs one harmless nudge; a
                // false positive strands the delivered message).
                // F2' (receipt-settlement): the delivery is born into the
                // ledger — an inbound row owes a receipt only this node can
                // produce, and before this row existed the nudge's isPending
                // gate no-op'd for exactly the deliveries that stall (08-30:
                // zero ledger records for latched activations). Arming is
                // unconditional now; settlement evidence disarms in the
                // callback.
                const consumedProbe = runningBeforeSteer ? false : probeConsumption(target, taskId)
                // F5 (settlement integrity): the debt gate — a process-label
                // caller cannot receive receipts, so this delivery is born
                // fire-and-forget (receiptExpected:false, answered as
                // receipt:"none") instead of manufacturing a debt nobody can
                // settle. The row itself stays: stall visibility and the
                // nudge still apply to the TARGET side.
                const receiptExpectation = receiptExpectationOf(receiptTarget)
                taskLedger.trackInbound(taskId, team, receiptTarget, contextId === '' ? undefined : contextId, receiptExpectation !== 'process-label', briefOf(message))
                armAsyncNudge(target, team, taskId, config.asyncNudgeDelayMs)
                const payload = JSON.stringify({
                  routed: true,
                  delivered: true,
                  team,
                  session,
                  task_id: taskId,
                  context_id: contextId,
                  task_status: 'TASK_STATE_DELIVERED',
                  artifacts: [],
                  consumed: consumedProbe,
                  receipt: receiptExpectation === 'process-label' ? 'none' : 'routed',
                })
                res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
                res.end(payload)
              } catch (error) {
                recordActivity('in', team, caller, false)
                const payload = JSON.stringify({ error: `The DSH session rejected the message: ${String(error)}`, code: -32000, team, task_id: taskId, task_status: 'TASK_STATE_FAILED' })
                res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
                res.end(payload)
              }
            }
            if (agent !== undefined) { deliver(agent); return }
            if (wake?.kind === 'flight') {
              void wake.flight.then(deliver, (error: unknown) => {
                recordActivity('in', team, caller, false)
                const payload = JSON.stringify({ error: `waking the session for team "${team}" failed: ${String(error)}`, code: -32000, team, task_status: 'TASK_STATE_FAILED' })
                res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
                res.end(payload)
              })
              return
            }
            // Remaining candidates need one async classification (the
            // native-teams bridge), so the tail answers inside an IIFE.
            void (async () => {
              // Native-teams inbound bridge (opt-in): prepare BEFORE answering
              // delivered — claim, seam, and parent initiator are everything
              // that can fail fast, and a phantom dispatch must never answer
              // success. Past prepare, the round fires detached (noWait means
              // delivery, not settlement); its late outcome corrects the
              // activity ring and the log.
              const standardMiss = (): void => {
                if (team === config.team) {
                  const live = liveAgent()
                  if (live !== undefined) {
                    // Self-route refusal (mirrors the sync face): a caller
                    // naming the very agent the fallback resolves to must
                    // get an honest failure, never its own dispatch echoed
                    // home plus an auto-receipt for work nobody did.
                    if (callerIsAgent(live, caller)) {
                      recordActivity('in', team, caller, false)
                      const payload = JSON.stringify({ error: selfRouteText(team), code: -32000, team, task_status: 'TASK_STATE_FAILED' })
                      res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
                      res.end(payload)
                      return
                    }
                    deliver(live); return
                  }
                }
                const payload = JSON.stringify({ error: wake?.kind === 'no-face' ? noWakeFaceText(team) : wake?.kind === 'archived' ? archivedColdMatchText(team) : noColdMatchText(team), code: -32000, team, task_status: 'TASK_STATE_FAILED' })
                res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
                res.end(payload)
              }
              const prepared = await nativeTeamsPrepare(team)
              if (!prepared.ok) {
                if (prepared.reason === 'error') {
                  recordActivity('in', team, caller, false)
                  const payload = JSON.stringify({ error: prepared.error, code: -32000, team, task_status: 'TASK_STATE_FAILED' })
                  res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
                  res.end(payload)
                  return
                }
                standardMiss()
                return
              }
              recordActivity('in', team, caller, true)
              void nativeTeamsRound(prepared, team, caller, message, taskId)
                .then(outcome => {
                  if (!outcome.ok) {
                    recordActivity('in', team, caller, false)
                    logger.warn(`a2a: detached native-teams round for "${team}" failed: ${outcome.error}`)
                  }
                  // W7 slice-2 hook 2: only a genuinely settled detached round
                  // records an outcome. The deadline's settled:false
                  // projection is a placeholder, not a product — the same
                  // ruling as hook 1's DELIVERED skip; placeholder prose never
                  // enters the ledger a replay could adopt from.
                  if (taskId !== '') {
                    if (!outcome.ok) idempotencyStore.recordOutcome(taskId, { status: 'failed', error: outcome.error })
                    else if (outcome.settled) idempotencyStore.recordOutcome(taskId, { status: 'completed', reply: outcome.reply })
                  }
                })
              const payload = JSON.stringify({ routed: true, delivered: true, team, session, task_id: taskId, context_id: contextId, task_status: 'TASK_STATE_DELIVERED', artifacts: [], consumed: false, bridge: 'native-teams' })
              res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
              res.end(payload)
            })()
            return
          }
          void routeIntoAgent(team, message, caller, taskId).then((outcome) => {
            recordActivity('in', team, caller, outcome.ok)
            // W7 slice-2 hook 1: record the settled outcome on the claim row.
            // Ruling: a non-COMPLETED status (TASK_STATE_DELIVERED — the
            // bridge-round deadline placeholder, ABORTED_WAIT likewise) is
            // NOT a settled outcome, and neither is a host-authored
            // placeholder on the reply channel (flush timeout, dead session)
            // — the row stays pending, because an adopted replay must never
            // settle a node on placeholder text (the exact hazard W7 gap B
            // closed, barred from resurrecting through the outcome ledger).
            if (taskId !== '') {
              if (!outcome.ok) {
                idempotencyStore.recordOutcome(taskId, { status: 'failed', error: outcome.error })
              } else if (outcome.placeholder === true) {
                // placeholder prose never enters the ledger
              } else if (outcome.status === undefined || outcome.status === 'TASK_STATE_COMPLETED') {
                idempotencyStore.recordOutcome(taskId, { status: 'completed', reply: outcome.reply })
              }
            }
            const payload = outcome.ok
              ? JSON.stringify({
                routed: true,
                team,
                session,
                result: { text: outcome.reply },
                task_id: taskId,
                context_id: contextId,
                task_status: outcome.status ?? 'TASK_STATE_COMPLETED',
                artifacts: [],
                // The bridge marker rides the wire so the caller's
                // trackOwedTask skips a receipt-less native round — without
                // it, a cross-node unsettled round books an unpayable owed
                // row and re-creates the TASK_CAP backlog.
                ...(outcome.bridge !== undefined ? { bridge: outcome.bridge } : {}),
              })
              : JSON.stringify({ error: outcome.error, code: -32000, team, task_id: taskId, task_status: 'TASK_STATE_FAILED' })
            res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
            res.end(payload)
          })
        })
      },
    }), 'a2a: direct route endpoint')

    // 0.6.15: the read-only peer log face — a peer asks for THIS node's
    // session transcript tail (or, without id, the readable-session
    // listing) so a remote workbench can show "what has this node been
    // talking about". Admission is a2aCallerRefusal — exactly the rule
    // /a2a/direct applies to message delivery: caller_session required,
    // zone/id8 callers judged on shared teams. Read semantics are the
    // local /__dsh_a2a/session-log face verbatim (artifact existence is
    // the only gate; archived and never-joined sessions stay readable;
    // caps mirror session-transcript.ts). Nothing here steers a session,
    // claims a task, or writes state — the only side effects are the
    // activity-ring record and the admission path's background
    // directory learn.
    ctx.effect(() => webServer.register({
      kind: 'exact',
      path: '/a2a/log',
      handler: async (req: IncomingMessage, res: ServerResponse) => {
        const send = (status: number, body: Record<string, JsonValue>): void => {
          const payload = JSON.stringify(body)
          res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
          res.end(payload)
        }
        if (req.method !== 'GET') {
          send(405, { ok: false, error: 'GET is the only method on this face' })
          return
        }
        // V2 (gh#7, S1): the read-only log face rides the same apiKey gate
        // as delivery — a configured key must be presented here too.
        if (config.apiKey !== '') {
          const presented = String(req.headers['x-api-key'] ?? '')
          if (!secretEqual(presented, config.apiKey)) {
            send(401, { ok: false, error: 'unauthorized: X-API-Key required (apiKey is configured)', code: -32000 })
            return
          }
        }
        const url = new URL(req.url ?? '/', 'http://x')
        const caller = url.searchParams.get('caller_session') ?? ''
        const id = url.searchParams.get('id') ?? ''
        const limitArg = Number(url.searchParams.get('limit') ?? TRANSCRIPT_DEFAULT_LIMIT)
        const limit = Number.isFinite(limitArg) ? Math.max(1, Math.min(TRANSCRIPT_MAX_LIMIT, Math.floor(limitArg))) : TRANSCRIPT_DEFAULT_LIMIT
        const refusal = a2aCallerRefusal(caller)
        if (refusal !== undefined) {
          recordActivity('in', 'log', caller === '' ? 'anonymous' : caller, false)
          send(200, { ok: false, error: refusal, code: -32000 })
          return
        }
        // gh#9+gh#10: the log face reuses the exact OriginClaim
        // verification (§8.3) — same window semantics as delivery.
        const logClaim = await verifyOriginClaim(req)
        if (!logClaim.ok) {
          if (logClaim.reason !== 'absent' || config.originClaimWindow === false) {
            recordActivity('in', 'log', caller, false)
            send(200, { ok: false, error: `untrusted-origin: OriginClaim verification failed (${logClaim.reason}) — present a signed envelope or upgrade your node`, code: -32000 })
            return
          }
          legacyInboundCount += 1
        }
        recordActivity('in', 'log', caller, true)
        if (id.includes('/') || id.includes('\\') || id.includes('..')) {
          send(200, { ok: false, error: 'id is required' })
          return
        }
        if (id === '') {
          try {
            const rows = scanSessionLogList()
            send(200, { ok: true, count: rows.length, sessions: rows.slice(0, 50) })
          } catch (error) {
            send(200, { ok: false, error: `transcript list failed: ${error instanceof Error ? error.message : String(error)}` })
          }
          return
        }
        try {
          const tail = readSessionLogTail(id, limit)
          if (!tail.ok) send(200, { ok: false, error: tail.error })
          else send(200, { ok: true, id: tail.id, count: tail.messages.length, messages: tail.messages })
        } catch (error) {
          send(200, { ok: false, error: `transcript failed: ${error instanceof Error ? error.message : String(error)}` })
        }
      },
    }), 'a2a: peer log face endpoint')
  })

  whenWebServerSettled((webServer) => {
    // W7 slice 2: the S1 outcome-retrieval surface — a READ-ONLY lookup of
    // one claimed task's settled outcome. The body carries ONLY the task id
    // and the submit payload's fingerprint (peerPayloadFingerprint, the
    // gate's own shared implementation): the fingerprint match is the
    // authorization, and the fan-out probe never leaks the original message
    // to peers that never saw it. Constant-200 semantics — a query NEVER
    // produces a wire error code (the frozen -32002/-32003 vocabulary stays
    // submit-only), never claims, never steers, never enters a session: the
    // gate's "verdict before steer" has its mirror in "a query executes
    // nothing". Malformed fields degrade to unknown-task rather than
    // guessing; an unparseable body answers 400 like /a2a/direct.
    ctx.effect(() => webServer.register({
      kind: 'exact',
      path: '/a2a/query',
      handler: (req: IncomingMessage, res: ServerResponse) => {
        const chunks: Buffer[] = []
        let size = 0
        let overflowed = false
        req.on('data', (chunk: Buffer) => {
          if (overflowed) return
          const next = size + chunk.length
          if (next > 65_536) {
            overflowed = true
            chunks.length = 0
            return
          }
          size = next
          chunks.push(chunk)
        })
        req.on('error', () => {
          if (!res.headersSent) {
            res.writeHead(400)
            res.end()
          }
        })
        req.on('end', () => {
          if (overflowed) {
            if (!res.writableEnded && !res.headersSent) {
              const payload = JSON.stringify({ error: 'payload too large', code: WIRE_ERROR_PAYLOAD_TOO_LARGE })
              res.writeHead(413, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
              res.end(payload)
            }
            return
          }
          let body: {
            readonly task_id?: unknown
            readonly fingerprint?: unknown
          }
          try {
            body = JSON.parse(Buffer.concat(chunks).toString('utf8')) as typeof body
          } catch {
            const payload = JSON.stringify({ error: 'malformed body', code: -32000 })
            res.writeHead(400, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
            res.end(payload)
            return
          }
          const taskId = typeof body.task_id === 'string' ? body.task_id : ''
          const fingerprint = typeof body.fingerprint === 'string' ? body.fingerprint : ''
          const verdict = taskId === '' || fingerprint === ''
            ? { found: false as const, reason: 'unknown-task' as const }
            : idempotencyStore.query(taskId, fingerprint)
          const payload = JSON.stringify(
            verdict.found
              ? verdict.status === 'pending'
                ? { found: true, status: 'pending', task_id: taskId }
                : verdict.status === 'completed'
                  ? {
                    found: true,
                    status: 'completed',
                    reply: verdict.reply,
                    settled_at: new Date(verdict.settledAt).toISOString(),
                    task_id: taskId,
                    ...(verdict.truncated === true ? { truncated: true } : {}),
                  }
                  : {
                    found: true,
                    status: 'failed',
                    error: verdict.error,
                    settled_at: new Date(verdict.settledAt).toISOString(),
                    task_id: taskId,
                    ...(verdict.truncated === true ? { truncated: true } : {}),
                  }
              : { found: false, reason: verdict.reason, task_id: taskId },
          )
          res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
          res.end(payload)
        })
      },
    }), 'a2a: query endpoint')
  })

  whenWebServerSettled((webServer) => {
    // Task-ledger control: explicit caller-side abandonment of one owed
    // async task — the orchestrator's give-up path (work-order P1a).
    // Deliberately OUTSIDE the sessionNodes gate: every async route tracks
    // its task whether or not this node exposes joinable sessions. Rides the
    // standard control guard; structured outcome vocabulary
    // {cleared|already-terminal|unknown}; idempotent; never throws.
    ctx.effect(() => webServer.register({
      kind: 'exact',
      path: '/__dsh_a2a/tasks/abandon',
      handler: controlRoute((req: IncomingMessage, res: ServerResponse) => {
        readJsonBody(req, res, (body) => {
          const fields = body as Record<string, unknown>
          const taskId = typeof fields.task_id === 'string' ? fields.task_id : ''
          const reason = typeof fields.reason === 'string' ? fields.reason : undefined
          const result = taskLedger.abandon(taskId, reason)
          const payload = JSON.stringify(result)
          res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
          res.end(payload)
        })
      }),
    }), 'a2a: task abandon route')
  })

  whenWebServerSettled((webServer) => {
    // Cooperative cancellation (work-order P1b): end the owed row AND, when
    // it pointed at a live local target, steer a stop notice so a running
    // turn wraps up instead of burning budget on an orphaned task. Standard
    // control guard; total outcome vocabulary like the abandon sibling.
    ctx.effect(() => webServer.register({
      kind: 'exact',
      path: '/__dsh_a2a/tasks/cancel',
      handler: controlRoute((req: IncomingMessage, res: ServerResponse) => {
        readJsonBody(req, res, (body) => {
          const fields = body as Record<string, unknown>
          const taskId = typeof fields.task_id === 'string' ? fields.task_id : ''
          const reason = typeof fields.reason === 'string' ? fields.reason : undefined
          const result = taskLedger.cancel(taskId, reason)
          let steered = false
          if (result.outcome === 'cleared' && result.team !== undefined) {
            const live = resolveAgentForTeam(result.team)
              ?? canvasLiveAgent(parseCanvasTeamName(result.team))
              ?? (result.team === config.team ? liveAgent() : undefined)
            if (live !== undefined) {
              try {
                steerRelay(live, cancelNoticeText(taskId, reason))
                steered = true
              } catch {
                // Bookkeeping already settled; steering is best-effort only.
              }
            }
          }
          const payload = JSON.stringify({ ...result, steered })
          res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
          res.end(payload)
        })
      }),
    }), 'a2a: task cancel route')

    // Quick dispatch (0.6.9, design docs/design/quick-dispatch-l3.md): a
    // human at the workbench sends one message to a team without opening a
    // session. Host face by construction — it rides the same routing trunk
    // as a2a_route with no agent: the agent-less audit gate applies, the
    // join gate exempts it (a human gesture, not a session), and the caller
    // label is the bare node team so the target can answer. Async is fixed
    // (fire-and-forget with the receipt contract); the HTTP wait is bounded
    // well under routeTimeoutMs because delivery, not the answer, is what
    // this face returns. Guards: the standard control-plane trust (same
    // origin / loopback / apiKey), a 4000-char message cap, and a 5s
    // per-client window — a human cannot click faster than that.
    ctx.effect(() => webServer.register({
      kind: 'exact',
      path: '/__dsh_a2a/dispatch',
      handler: controlRoute((req: IncomingMessage, res: ServerResponse) => {
        readJsonBody(req, res, async (body) => {
          const fields = body as Record<string, unknown>
          const message = typeof fields.message === 'string' ? fields.message.trim() : ''
          const target = typeof fields.team === 'string' ? fields.team.trim() : ''
          const client = req.socket.remoteAddress ?? 'unknown'
          const now = Date.now()
          let result: Record<string, JsonValue>
          if (target === '' || message === '') {
            result = { ok: false, error: 'team and message are required' }
          } else if (message.length > 4000) {
            result = { ok: false, error: 'message exceeds the 4000-char cap' }
          } else if (now - (dispatchLastAt.get(client) ?? 0) < 5_000) {
            result = { ok: false, error: 'rate limited: one quick dispatch per 5s per client' }
          } else {
            dispatchLastAt.set(client, now)
            try {
              // gh#36: a quick dispatch rides a LIVE joined session's node
              // team as its caller face when one exists — receipts then
              // route back to that session and the owner SEES the answer in
              // its chat drawer. Bare-zone callers (the old shape) cannot
              // receive: the receipt ladder failed every lane and the owner
              // read it as 派发异常没有收信. No live session keeps the
              // host face (the reply's reconciliation note still applies).
              const liveJoined = joinedSessions.list().find(id => liveRoots.has(id))
              const hostFace = liveJoined !== undefined ? `${config.team}/${id8(liveJoined)}` : config.team
              result = await routeTrunk({ team: target, message, async: true }, undefined, AbortSignal.timeout(20_000), hostFace)
            } catch (error) {
              result = { ok: false, error: `dispatch failed: ${error instanceof Error ? error.message : String(error)}` }
            }
          }
          const payload = JSON.stringify(result)
          res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
          res.end(payload)
        })
      }),
    }), 'a2a: quick-dispatch route')

    // Session transcript reader (0.6.11): the workbench inspector shows the
    // tail of a LOCAL node's own conversation log inline — owner ruling
    // 2026-10-20 banned navigation, and reading is the need jumps used to
    // serve. The id gate is artifact existence under this host's sessions
    // tree — reading is a host-workbench concern, not a network-membership
    // concern, so archived and never-joined sessions stay readable while the
    // network faces keep their own visibility rules. Path shape is still
    // checked (no '/', '\', '..') and the tree never leaves <dshHome>/sessions.
    // Without an id the same face lists readable sessions (newest activity
    // first, capped) so the workbench directory can offer log rows even when
    // the network directory shows none. Caps mirror session-transcript.ts.
    ctx.effect(() => webServer.register({
      kind: 'exact',
      path: '/__dsh_a2a/session-log',
      handler: controlRoute((req: IncomingMessage, res: ServerResponse) => {
        const url = new URL(req.url ?? '/', 'http://x')
        const id = url.searchParams.get('id') ?? ''
        const limitArg = Number(url.searchParams.get('limit') ?? TRANSCRIPT_DEFAULT_LIMIT)
        const limit = Number.isFinite(limitArg) ? Math.max(1, Math.min(TRANSCRIPT_MAX_LIMIT, Math.floor(limitArg))) : TRANSCRIPT_DEFAULT_LIMIT
        let result: Record<string, JsonValue>
        if (id.includes('/') || id.includes('\\') || id.includes('..')) {
          result = { ok: false, error: 'id is required' }
        } else if (id === '') {
          // Listing face: every session directory holding a log artifact.
          try {
            const rows = scanSessionLogList()
            result = { ok: true, count: rows.length, sessions: rows.slice(0, 50) }
          } catch (error) {
            result = { ok: false, error: `transcript list failed: ${error instanceof Error ? error.message : String(error)}` }
          }
        } else {
          try {
            const tail = readSessionLogTail(id, limit)
            if (!tail.ok) result = { ok: false, error: tail.error }
            else result = { ok: true, id: tail.id, count: tail.messages.length, messages: tail.messages }
          } catch (error) {
            result = { ok: false, error: `transcript failed: ${error instanceof Error ? error.message : String(error)}` }
          }
        }
        const payload = JSON.stringify(result)
        res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
        res.end(payload)
      }),
    }), 'a2a: session-log route')

    // 0.6.15: the local proxy for REMOTE session logs. The workbench runs
    // in this host's browser page, so cross-host reads must originate from
    // this host (no CORS, one trust boundary). ?team=<zone/id8> resolves
    // directory candidates that publish that team (same walk as routing);
    // ?peer=<base-url> targets one tracked peer directly and MUST name a
    // URL already in the peer store — the proxy never fetches an
    // arbitrary address. The caller label we present is config.team (this
    // node's own zone handle, the same host face quick-dispatch uses).
    ctx.effect(() => webServer.register({
      kind: 'exact',
      path: '/__dsh_a2a/remote-session-log',
      handler: controlRoute(async (req: IncomingMessage, res: ServerResponse) => {
        const url = new URL(req.url ?? '/', 'http://x')
        const team = url.searchParams.get('team') ?? ''
        const peer = url.searchParams.get('peer') ?? ''
        const id = url.searchParams.get('id') ?? ''
        const limitArg = Number(url.searchParams.get('limit') ?? TRANSCRIPT_DEFAULT_LIMIT)
        const limit = Number.isFinite(limitArg) ? Math.max(1, Math.min(TRANSCRIPT_MAX_LIMIT, Math.floor(limitArg))) : TRANSCRIPT_DEFAULT_LIMIT
        const finish = (body: Record<string, JsonValue>): void => {
          const payload = JSON.stringify(body)
          res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
          res.end(payload)
        }
        if (id.includes('/') || id.includes('\\') || id.includes('..')) {
          finish({ ok: false, error: 'id is required' })
          return
        }
        const trackedPeers = new Set(peerStore.list().map(entry => entry.replace(/\/+$/, '')))
        let targets: string[]
        if (peer !== '') {
          const normalized = peer.replace(/\/+$/, '')
          if (!trackedPeers.has(normalized)) {
            finish({ ok: false, error: 'unknown peer on this node — the proxy only reads tracked peers' })
            return
          }
          targets = [normalized]
        } else if (team !== '') {
          const failures: string[] = []
          targets = await directoryPeerCandidates(memoizedCardFetch(), team, failures)
          if (targets.length === 0) {
            finish({ ok: false, error: `no directory candidate publishes team "${team}"${failures.length > 0 ? ` (${failures.slice(0, 3).join('; ')})` : ''}` })
            return
          }
        } else {
          finish({ ok: false, error: 'team or peer is required' })
          return
        }
        // 0.6.16: a team-handle read without an explicit id names a NODE, not
        // a session. The handle suffix (zone/<id8>) is the first 8 hex of the
        // peer-side session id (sessionTeamOf), so resolve the listing once
        // and pick that session — bare zone teams fall back to the newest.
        // An explicit id (peer drill) short-circuits this.
        let resolvedId = id
        if (resolvedId === '' && team !== '') {
          const suffix = team.includes('/') ? team.slice(team.lastIndexOf('/') + 1) : ''
          for (const base of targets) {
            const listUrl = new URL('/a2a/log', base)
            listUrl.searchParams.set('caller_session', config.team)
            try {
              const listResponse = await globalThis.fetch(listUrl, { signal: AbortSignal.timeout(5000), headers: { accept: 'application/json' } })
              const listBody = await listResponse.json().catch(() => ({ ok: false, error: `peer answered HTTP ${listResponse.status}` })) as { ok?: boolean; error?: string; sessions?: Array<{ id: string }> }
              if (listResponse.ok && listBody.ok === true && Array.isArray(listBody.sessions)) {
                const picked = suffix !== '' ? listBody.sessions.find(row => row.id.includes(suffix)) : listBody.sessions[0]
                if (picked !== undefined) {
                  resolvedId = picked.id
                  break
                }
              }
            } catch {
              // listing failed on this candidate — the tail attempt below
              // will surface the honest error for the same base
            }
          }
          if (resolvedId === '') {
            finish({ ok: false, error: `no readable session on this peer matches "${team}"` })
            return
          }
        }
        const attempts: string[] = []
        for (const base of targets) {
          const target = new URL('/a2a/log', base)
          target.searchParams.set('caller_session', config.team)
          if (resolvedId !== '') target.searchParams.set('id', resolvedId)
          target.searchParams.set('limit', String(limit))
          try {
            const response = await globalThis.fetch(target, { signal: AbortSignal.timeout(5000), headers: { accept: 'application/json' } })
            const body = await response.json().catch(() => ({ ok: false, error: `peer answered HTTP ${response.status}` })) as { ok?: boolean; error?: string }
            if (response.ok && body.ok === true) {
              finish({ ...body, via: base } as Record<string, JsonValue>)
              return
            }
            attempts.push(`${base}: ${body.error ?? `HTTP ${response.status}`}`)
          } catch (error) {
            attempts.push(`${base}: ${error instanceof Error ? error.message : String(error)}`)
          }
        }
        finish({ ok: false, error: `remote log unavailable — ${attempts.join(' | ')}` })
      }),
    }), 'a2a: remote-session-log proxy route')
  })

  /**
   * Settle one card-fetch outcome into the peer store and the plain card:
   * the fetch is itself the reachability check — a miss degrades the peer, a
   * verified card raises it and offers its referral list to the store. A
   * peer offered mid-iteration is fetched on a later tool call, so gossip
   * converges across calls.
   * @param peer - base URL of the peer the outcome belongs to.
   * @param outcome - the detailed fetch outcome (probe and discovery share it).
   * @returns the verified card, or undefined when the peer is unreachable, rejected, a self-referral, or a dropped alias.
   */
  function settlePeerCard(peer: string, outcome: CardFetchOutcome): A2aPeerCard | undefined {
    if (!outcome.ok) {
      peerStore.noteFailure(peer)
      return undefined
    }
    // A self-referral learned from a peer's card (the peer lists this node's
    // URL back at it) must not track the node as its own peer: the node would
    // list its own teams as remote rows and offer its own URL onward. The
    // signed card session is the identity check — no URL guessing.
    if (outcome.card.session === session) {
      // Remember the alias so mirrored referral lists stop re-offering it
      // between fetches (the drop alone flickers in and out of the store).
      selfReferrals.remember(peer)
      peerStore.drop(peer)
      return undefined
    }
    // Alias collapse (same-node dedup): one node reaches the fleet under
    // several spellings — loopback vs LAN IP vs hostname — and different
    // gossip sources list different ones, so the store accumulates several
    // peers for one node and the plan canvas renders one card per spelling.
    // The signed card session is the node identity: when another tracked
    // peer already serves it, keep the stronger entry (seed, then score),
    // learn the identity on it, and forget the alias. The suppression
    // window stops the dropped spelling from riding the next gossip round
    // straight back in. A seed alias is config-owned: drop() refuses it and
    // both spellings stay, exactly as the owner configured.
    const known = peerStore.bySession(outcome.card.session)
    if (known !== undefined && known !== peer) {
      const keep = (peerStore.score(known) ?? 0) >= (peerStore.score(peer) ?? 0) ? known : peer
      const alias = keep === known ? peer : known
      peerStore.drop(alias)
      selfReferrals.remember(alias)
      peerStore.learnSession(keep, outcome.card.session)
      peerStore.noteSuccess(keep)
      return outcome.card
    }
    peerStore.noteSuccess(peer)
    peerStore.learnSession(peer, outcome.card.session)
    for (const referral of outcome.card.peers ?? []) {
      if (!selfReferrals.shouldOffer(referral)) continue
      if (!peerAdmissible(referral)) continue
      peerStore.offer(referral)
    }
    return outcome.card
  }

  /**
   * Fetch one peer's card and settle it into the store (discovery path).
   * @param peer - base URL of the peer to visit.
   * @returns the verified card, or undefined when the peer is unreachable or serves an invalid card.
   */
  async function fetchPeerCard(peer: string): Promise<A2aPeerCard | undefined> {
    return settlePeerCard(peer, await client.fetchCardDetail(peer))
  }

  /**
   * Apply-scope shared card cache: every caller (teams listing, route
   * candidate walks, panel sweeps) shares one TTL window per URL, so a
   * poll-happy consumer cannot re-fetch a peer's card — or re-punish a dead
   * one — more than once per window. Cards live for days and re-sign at
   * TTL/4, so a 60s serve window is semantically safe. Negative results
   * (unreachable/invalid) cache for a shorter window so a restarting peer
   * reappears quickly. Scoring stays with the real network fetch only: a
   * cache hit never re-scores, which is what keeps the debounced peer-store
   * writes rare. Concurrent callers for one URL join a single in-flight
   * fetch (single-flight) instead of racing N requests.
   */
  interface CardCacheEntry { at: number; card: A2aPeerCard | undefined }
  const cardCache = new Map<string, CardCacheEntry>()
  const cardCacheInFlight = new Map<string, Promise<A2aPeerCard | undefined>>()

  /**
   * The from-line display name (owner ruling, claim 8ea4150f94): a bare
   * routing handle (`dsh/74555a36`) carries zero semantics for the reader.
   * Resolve what the handle NAMES, cheaply and read-only:
   *   1. a local handle — a joined/live session id, its zone/id8 pseudo-team,
   *      or a live node label → nodeMetadataOf(agent).name (the session-title
   *      product, exactly what the directory shows);
   *   2. a remote bare-zone caller → the warmest cached card whose team
   *      equals the zone (the publisher's own card NAME is the display name);
   *   3. a remote zone/id8 caller → the cached card whose sessionTeams row
   *      matches the handle → that row's name;
   *   4. nothing resolves → '' (the from line stays bare — no false names).
   * Read-only over warm caches: never fetches, so a cold cache degrades to
   * the bare handle, never to a stall.
   */
  function callerDisplayName(caller: string): string {
    if (caller === '' || caller === 'an unknown node') return ''
    // Local: joined/live session facts on THIS host.
    for (const [id, agent] of sessionNodes) {
      if (id === caller || sessionLabelOf(agent) === caller || `${config.team}/${id8(id)}` === caller) {
        return nodeMetadataOf(agent).name
      }
    }
    for (const [id, agent] of liveRoots) {
      if (id === caller || sessionLabelOf(agent) === caller || `${config.team}/${id8(id)}` === caller) {
        return nodeMetadataOf(agent).name
      }
    }
    // Remote: warm card cache only.
    const zone = caller.includes('/') ? caller.slice(0, caller.indexOf('/')) : caller
    let zoneName = ''
    for (const entry of cardCache.values()) {
      const card = entry.card
      if (card === undefined) continue
      if (card.team === zone && zoneName === '') zoneName = card.name
      if (caller.includes('/')) {
        const row = (card.sessionTeams ?? []).find(item => item.team === caller)
        if (row !== undefined && row.name !== '') return row.name
      }
    }
    if (!caller.includes('/') && zoneName !== '') return zoneName
    return ''
  }

  /** The from clause with the display name in full-width parens when resolved. */
  function fromClause(from: string): string {
    const display = callerDisplayName(from)
    return `from "${from}"${display !== '' ? `（${display}）` : ''}`
  }

  /**
   * gh#20 W-A: THIS host's view of one tracked peer's link state (the
   * mirror of callerLinkedToThisHost, judged from our side about THEM):
   *   · linked — bilateral seeding (our config.peers carries a URL of the
   *     peer's origin AND the peer's card carries ours), or a canvas remote
   *     ref naming the peer's zone or one of its session teams;
   *   · stranger — no operator-established basis (a verified key is not a
   *     relationship);
   *   · verified — we hold a signature-valid cached card (the badge's
   *     tick/cross: reachable-and-authentic vs unknown/bad).
   * NOTE (gh#20 review observation, ruling-accepted): the UI's third
   * colour — fleet blue — has no v1 data source: a peer's #19 exposure
   * tier is that host's state-face private fact and is NOT published on
   * its card, so we cannot classify a peer as fleet-visible. The badge
   * renders two colours (linked green / stranger gray) and the blue slot
   * lights up the day the card face carries a tier field (or an
   * a2a_exposure state query is added to fetch it).
   * Pure over warm caches and config; never fetches.
   */
  function peerLinkState(peerUrl: string): { link: 'linked' | 'stranger'; verified: boolean } {
    const cached = cardCache.get(peerUrl)?.card
    const verified = cached !== undefined
    const zone = cached?.team ?? ''
    const handles = new Set<string>()
    if (zone !== '') handles.add(zone)
    for (const row of cached?.sessionTeams ?? []) handles.add(row.team)
    let linked = false
    // Basis 1: bilateral seeds (origin match both ways).
    if (cached !== undefined && ownCardUrl !== '') {
      try {
        const peerOrigin = new URL(peerUrl).origin
        const ourOrigin = new URL(ownCardUrl).origin
        const weSeedThem = config.peers.some(peer => {
          try { return new URL(peer).origin === peerOrigin } catch { return false }
        })
        const theySeedUs = (cached.peers ?? []).some(peer => {
          try { return new URL(peer).origin === ourOrigin } catch { return false }
        })
        if (weSeedThem && theySeedUs) linked = true
      } catch { /* malformed peer URL — falls through to the canvas basis */ }
    }
    // Basis 2: a canvas remote ref names the peer's zone or one of its
    // session teams. Exact-handle match first (the admission basis); the
    // ref's ZONE prefix against card.team accepts the common compose form
    // (the operator added the peer's session-team handle; we see the
    // minimal card without sessionTeams until linked — display-level
    // zone matching is exact-host here: the ref names a handle of THAT
    // zone, and the tracked peer IS that zone's card).
    if (!linked && handles.size > 0 && zone !== '') {
      outer: for (const name of canvasStore.list()) {
        for (const ref of canvasStore.remoteMembersOf(name)) {
          if (handles.has(ref)) { linked = true; break outer }
          const refZone = ref.includes('/') ? ref.slice(0, ref.indexOf('/')) : ref
          if (refZone === zone) { linked = true; break outer }
        }
      }
    }
    return { link: linked ? 'linked' : 'stranger', verified }
  }

  function cachedCardFetch(url: string): Promise<A2aPeerCard | undefined> {
    const hit = cardCache.get(url)
    const now = Date.now()
    if (hit !== undefined && now - hit.at < (hit.card !== undefined ? config.cardCacheTtlMs : config.cardCacheNegativeTtlMs)) {
      return Promise.resolve(hit.card)
    }
    const inFlight = cardCacheInFlight.get(url)
    if (inFlight !== undefined) return inFlight
    const fetch = fetchPeerCard(url)
      .then(card => {
        cardCache.set(url, { at: Date.now(), card })
        return card
      })
      .finally(() => {
        cardCacheInFlight.delete(url)
      })
    cardCacheInFlight.set(url, fetch)
    return fetch
  }

  /**
   * Kept for the per-call semantics the route tool documents (one fetch per
   * zone per call): it now reads through the shared cache, so a second call
   * within the window is free but the first always reflects live state.
   */
  function memoizedCardFetch(): ZoneCardFetch {
    const seen = new Set<string>()
    return async (url: string) => {
      if (seen.has(url)) return cardCache.get(url)?.card
      seen.add(url)
      return cachedCardFetch(url)
    }
  }

  /**
   * v0.5.24 (join-gate): a session that has not joined the A2A network may
   * not use its outbound tools. Joining is a user gesture (the sidebar
   * control) — never automatic, never proxied — so an unjoined session's
   * model must be told plainly instead of silently failing routes. The gate
   * only applies to in-session calls (an agent context exists); host-side
   * service invocations without an agent (e.g. the taskboard marquee's
   * joined-caller identity) pass through untouched, and a joined session
   * (sessionNodes carries its id) is exempt. appliesToA2aTools returns the
   * refusal error object, or undefined when the call may proceed.
   */
  /**
   * Whether this agent is the process's own initiator session — the face the
   * join gate exempts (it IS the node: its team is config.team, so anything
   * it can send, this node can receive). Shared by the join gate and the
   * route's caller-label resolution (fix ①, 能发即能收).
   */
  const exemptInitiatorFace = (agent: { id: unknown }): boolean => {
    if (sessionNodes.has(String(agent.id))) return false
    try {
      return ctx.get('agents')?.requireInitiator() === agent
    } catch { /* no initiator in this fiber — a guest stays gated */ }
    return false
  }

  const a2aJoinGateRefusal = (exec: { agent?: { id: unknown } } | undefined): void => {
    const agent = exec?.agent
    if (agent === undefined) return
    if (sessionNodes.has(String(agent.id))) return
    if (exemptInitiatorFace(agent)) return
    // A thrown tool error renders as the model-visible failure surface —
    // loud, structured, and schema-free (no success shape is produced).
    throw new Error('你被禁止使用 a2a 网络：本会话未加入 A2A 网络（join 是用户手势）。Join via the sidebar control to enable, then retry.')
  }

  // S4: team-membership tools — node-declared rosters under the owner's
  // allowlist curation. Joining is a network-visible declaration (the card
  // publishes it), so the default allowlist denies everything: a refused
  // join says why and names the curation surface instead of failing
  // silently. Leaving is always allowed — it only shrinks exposure.
  // S4 audit: every join/leave attempt — allowed or refused — lands in
  // a bounded ring the state route serves (the ring itself is declared with
  // the stores: the boot-settlement prune records before this section
  // initializes). Refusals are the audit-worthy half (each one is widening
  // pressure on the allowlist); log lines rotate away, this face is queryable.
  // gh#11 (N7, operator directive: team creation is a human act): only an
  // EXACT allowlist entry authorizes a join — each exact name is a
  // deliberate operator act of creation. Wildcard/prefix patterns match
  // nothing at join time: a pattern pre-authorizing every future name
  // under it would let a model mint teams nobody created. Pattern entries
  // remain readable (whoami shows them) but carry no mint rights.
  const teamJoinExactAllowed = (team: string): boolean =>
    ownerAllowlist.includes(team)
  const teamJoinPatternMatches = (team: string): boolean =>
    ownerAllowlist.some(pattern => {
      if (pattern === '*') return true
      if (pattern.endsWith('*')) {
        // Boundary: the wildcard consumes at most the remainder of one
        // '/'-delimited segment — `dsh*` matches `dsh/agent-1`, never
        // `dshield`; `dsh/canvas/*` matches the canvas subtree only.
        const prefix = pattern.slice(0, -1)
        return team.startsWith(prefix) && (prefix.endsWith('/') || (team.length > prefix.length && team[prefix.length] === '/'))
      }
      return team === pattern
    })
  const joinedNodeOrNone = (id: string): string | undefined =>
    joinedSessions.has(id) || sessionNodes.has(id) ? id : undefined

  // K3 feedback P0 (2026-10-20): a session could appear in a2a_teams, route
  // fine, and still be refused by a2a_team_join — with no way to ask "what am
  // I, actually?". whoami is that one-call answer. Deliberately NOT gated by
  // a2aJoinGateRefusal: the unjoined session is precisely the caller that
  // needs it.
  ctx.tools.register(defineTool({
    name: 'a2a_whoami',
    description:
      'One-call self-introspection on this host\'s A2A network: the calling session\'s node id, joined/live '
      + 'state, routable team handle, declared team memberships (roster + canvas), the owner\'s teamJoinAllowlist, '
      + 'the teamScopeRouting switch, and this node\'s most recent refused join/leave attempts with reasons. '
      + 'Note: outbound routing never requires join — the originating session is always exempt (initiator face); '
      + 'join buys presence, discovery, and being routed to.',
    parameters: {},
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          ok: { type: 'boolean', required: true },
          face: { type: 'string', required: true, description: 'session | host' },
          node: {
            type: 'object',
            additionalProperties: true,
            description: 'id, joined, live, and the routable team handle (zone/id8) once joined.',
          },
          teams: {
            type: 'object',
            additionalProperties: true,
            description: 'roster: allowlisted teams declared via a2a_team_join; canvas: workbench-assigned teams.',
          },
          allowlist: {
            type: 'object',
            additionalProperties: true,
            description: 'The owner-curated teamJoinAllowlist patterns and their net effect (deny-all / curated / allow-all).',
          },
          teamScopeRouting: { type: 'boolean' },
          note: { type: 'string', description: 'What join does and does not gate, in one sentence.' },
          lastRefusals: {
            type: 'array',
            description: 'Most recent refused join/leave attempts for this node (newest first, ≤3), with reason codes.',
            items: { type: 'object', additionalProperties: true },
          },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.face === 'host'
          ? `Host face on team ${String((value.node as Record<string, unknown> | undefined)?.team ?? '?')}: routing rides the bare node team (能发即能收)`
          : `Node ${String((value.node as Record<string, unknown> | undefined)?.id ?? '?')}: joined=${String((value.node as Record<string, unknown> | undefined)?.joined)}, live=${String((value.node as Record<string, unknown> | undefined)?.live)}; roster teams: ${((value.teams as Record<string, unknown> | undefined)?.roster as string[] | undefined ?? []).join(', ') || 'none'}; canvas: ${((value.teams as Record<string, unknown> | undefined)?.canvas as string[] | undefined ?? []).join(', ') || 'none'}; allowlist effect: ${String((value.allowlist as Record<string, unknown> | undefined)?.effect ?? '?')}`,
      }],
    },
    presentCall: () => ({ card: 'generic', title: 'A2A whoami', kind: 'other', rawInput: null }),
    execute: async (_args, exec): Promise<{
      ok: boolean
      face: string
      node?: Record<string, JsonValue>
      teams?: Record<string, JsonValue>
      allowlist?: Record<string, JsonValue>
      teamScopeRouting?: boolean
      lastRefusals?: Array<Record<string, JsonValue>>
      note?: string
    }> => {
      const agentId = exec?.agent !== undefined ? String(exec.agent.id) : ''
      if (agentId === '') {
        return {
          ok: true,
          face: 'host',
          node: { team: config.team },
          note: 'host face — routing rides the bare node team (能发即能收); joins are session-node concerns',
        }
      }
      const joined = joinedSessions.has(agentId)
      const live = sessionNodes.has(agentId)
      const refusals = teamAuditRing
        .filter(entry => entry.id === agentId && !entry.ok)
        .slice(-3)
        .reverse()
        .map(entry => ({ at: entry.at, action: entry.action, team: entry.team, reason: entry.reason ?? '' }))
      const patterns = [...ownerAllowlist]
      return {
        ok: true,
        face: 'session',
        node: {
          id: agentId,
          ...(joined ? { team: `${config.team}/${id8(agentId)}` } : {}),
          joined,
          live,
        },
        teams: {
          roster: [...teamMemberships.teamsOf(agentId)],
          canvas: [...canvasStore.teamsOf(agentId)],
        },
        allowlist: {
          patterns,
          effect: patterns.length === 0 ? 'deny-all (empty allowlist refuses every join)' : patterns.includes('*') ? 'allow-all' : 'curated',
        },
        teamScopeRouting: config.teamScopeRouting === true,
        ...(refusals.length > 0 ? { lastRefusals: refusals } : {}),
        note: joined
          ? 'join buys presence + being routed to; outbound routing needs no join (initiator face is exempt)'
          : 'NOT joined: no presence/discovery and cannot be routed to; outbound routing still works (initiator face), and joining is a host-side human control (GUI sidebar A2A panel)',
      }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'a2a_team_join',
    description:
      'Declare one of this host\'s joined session nodes a member of a routable team '
      + '(node-declared roster; the host card publishes it and peers rebuild team rosters as the union of '
      + 'member declarations). Gated by the owner\'s teamJoinAllowlist — an empty list denies every join; '
      + 'patterns are exact names or trailing-`*` prefixes. Canvas teams are out of scope here: their '
      + 'membership is assigned by hand in the A2A workbench, and the tool refuses `/canvas/` names. '
      + 'Collaboration itself stays within teams (team-scoped routing is the separate teamScopeRouting switch).',
    parameters: {
      team: { type: 'string', description: 'The routable team to join (full form, e.g. dsh/review-gate).' },
      id: { type: 'string', description: 'The joined session node id on this host that declares the membership.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          ok: { type: 'boolean', required: true },
          team: { type: 'string' },
          id: { type: 'string' },
          teams: { type: 'array', items: { type: 'string' } },
          error: { type: 'string', description: 'Refusal reason when ok is false: unknown node or team not allowlisted.' },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.ok === true
          ? `Node ${String(value.id)} joined team ${String(value.team)}; its teams: ${Array.isArray(value.teams) ? value.teams.join(', ') : String(value.team)}`
          : `Join refused: ${String(value.error)}`,
      }],
    },
    presentCall: () => ({ card: 'generic', title: 'A2A team join', kind: 'other', rawInput: null }),
    execute: async (args, exec): Promise<{ ok: boolean; team?: string; id?: string; teams?: string[]; error?: string }> => {
      a2aJoinGateRefusal(exec)
      const team = String(args.team ?? '').trim()
      const id = String(args.id ?? '').trim()
      if (team === '' || id === '') {
        const reason = '[BAD_ARGUMENTS] both team and id are required'
        recordTeamAudit('join', team, id, false, reason)
        return { ok: false, error: reason }
      }
      if (joinedNodeOrNone(id) === undefined) {
        // K3 feedback (2026-10-20): reason code + a step the MODEL can take.
        // The old text pointed at a sidebar control and a CLI — neither is
        // executable by a session agent. Joining is a host-side human
        // control; the model's executable step is to ask its operator and
        // to self-check state with a2a_whoami.
        const reason = `[NOT_JOINED] session ${id} is not a joined node on this host — network joining is a host-side human control (the GUI sidebar A2A panel), so relay the request to your human operator; once the node is joined, retry this declaration. Your current state (joined/live, teams, allowlist) is one a2a_whoami call away`
        recordTeamAudit('join', team, id, false, reason)
        return { ok: false, error: reason }
      }
      // V4 (gh#7, N2): a model tool changes membership for the CALLING
      // session only — agent-1 declaring agent-2 into a team was an agent
      // creating a link for another node, published to the whole fleet via
      // the card. The host face (agent-less, operator surface) may still
      // act for any joined node.
      if (exec?.agent !== undefined && String(exec.agent.id) !== id) {
        const reason = `[NOT_SELF] a model tool may only declare membership for its own session node (${String(exec.agent.id)}) — membership for other nodes is your operator's gesture (the workbench or the host face); N2: agents use links, they do not create them for others`
        recordTeamAudit('join', team, id, false, reason)
        return { ok: false, error: reason }
      }
      // Unified teaming (0.6.6): canvas teams are the human-composed surface.
      // A session may not self-join one through the roster tool — membership
      // there is assigned by hand, so the refusal names the surface where the
      // assignment happens. Any `/canvas/` name (this zone's or a peer's) is
      // refused: remote canvas membership is the owning host's store, and a
      // roster declaration here would neither feed it nor be read by it.
      if (team.includes('/canvas/')) {
        const reason = `[CANVAS_TEAM] team "${team}" is a canvas team — canvas membership is assigned by hand in the A2A workbench (open /__dsh_a2a_nexus/, pick the team, add or remove members there); the roster tool manages allowlisted teams only. If this membership must change now, relay the request to your human operator`
        recordTeamAudit('join', team, id, false, reason)
        return { ok: false, error: reason }
      }
      if (!teamJoinExactAllowed(team)) {
        const reason = teamJoinPatternMatches(team)
          ? `[PATTERN_NO_MINT] team "${team}" matches only a wildcard/pattern entry of this host's teamJoinAllowlist — patterns carry no mint rights (gh#11/N7: team creation is a human act); ask the owner to add the EXACT team name, which is the act of creating it`
          : `[ALLOWLIST_DENY] team "${team}" is not in this host's teamJoinAllowlist — the owner curates joinable teams with exact names (patterns match nothing at join time; human-composed groups live in the workbench's canvas teams); ask them to add the exact name. The live list is visible in a2a_whoami`
        recordTeamAudit('join', team, id, false, reason)
        return { ok: false, error: reason }
      }
      teamMemberships.add(id, team)
      recordTeamAudit('join', team, id, true)
      logger.info(`a2a: ${id8(id)} declared membership in ${team}`)
      return { ok: true, team, id, teams: [...teamMemberships.teamsOf(id)] }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'a2a_team_leave',
    description:
      'Retract one team-membership declaration previously made by a2a_team_join. Always allowed — leaving only '
      + 'shrinks the node\'s visible collaboration surface.',
    parameters: {
      team: { type: 'string', description: 'The routable team to leave.' },
      id: { type: 'string', description: 'The session node id retracting the membership.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          ok: { type: 'boolean', required: true },
          team: { type: 'string' },
          id: { type: 'string' },
          teams: { type: 'array', items: { type: 'string' } },
          error: { type: 'string', description: 'Refusal reason when ok is false: node unknown or membership absent.' },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.ok === true
          ? `Node ${String(value.id)} left team ${String(value.team)}; remaining teams: ${Array.isArray(value.teams) && value.teams.length > 0 ? value.teams.join(', ') : 'none'}`
          : `Leave refused: ${String(value.error)}`,
      }],
    },
    presentCall: () => ({ card: 'generic', title: 'A2A team leave', kind: 'other', rawInput: null }),
    execute: async (args, exec): Promise<{ ok: boolean; team?: string; id?: string; teams?: string[]; error?: string }> => {
      a2aJoinGateRefusal(exec)
      const team = String(args.team ?? '').trim()
      const id = String(args.id ?? '').trim()
      if (team === '' || id === '') {
        recordTeamAudit('leave', team, id, false, 'both team and id are required')
        return { ok: false, error: 'both team and id are required' }
      }
      if (joinedNodeOrNone(id) === undefined) {
        const reason = `[NOT_JOINED] session ${id} is not a joined node on this host — check current state with a2a_whoami`
        recordTeamAudit('leave', team, id, false, reason)
        return { ok: false, error: reason }
      }
      // V4 (gh#7, N2): same self-only rule as join — narrowing another
      // node's surface is still a link change by a third party.
      if (exec?.agent !== undefined && String(exec.agent.id) !== id) {
        const reason = `[NOT_SELF] a model tool may only retract membership for its own session node (${String(exec.agent.id)}); N2 — use links, do not reshape another node's`
        recordTeamAudit('leave', team, id, false, reason)
        return { ok: false, error: reason }
      }
      if (!teamMemberships.teamsOf(id).includes(team)) {
        const reason = `session ${id} declares no membership in "${team}" — nothing to leave`
        recordTeamAudit('leave', team, id, false, reason)
        return { ok: false, error: reason }
      }
      teamMemberships.remove(id, team)
      recordTeamAudit('leave', team, id, true)
      logger.info(`a2a: ${id8(id)} retracted membership in ${team}`)
      return { ok: true, team, id, teams: [...teamMemberships.teamsOf(id)] }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'a2a_exposure',
    description:
      '#19 exposure tiers: set THIS session\'s network visibility. \'linked\' (the default '
      + 'floor) — visible to linked callers per the card-face link gate; \'fleet\' — a voluntary '
      + 'opt-UP making the session\'s team visible to any fleet peer. Members may raise and lower '
      + 'their own tier freely; nothing exists below linked (no private tier in v1), and group '
      + 'visibility always derives from the strictest member (no group knobs). Requires the '
      + 'session to be joined to the network.',
    parameters: {
      tier: { type: 'string', enum: ['linked', 'fleet'], required: true, description: 'The exposure tier to set for this session.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          ok: { type: 'boolean', required: true },
          id: { type: 'string' },
          tier: { type: 'string' },
          error: { type: 'string', description: 'Refusal reason when ok is false (not joined, or no agent context).' },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.ok === true
          ? `Session ${String(value.id)} exposure tier set to ${String(value.tier)}`
          : `Exposure refused: ${String(value.error)}`,
      }],
    },
    presentCall: () => ({ card: 'generic', title: 'A2A exposure tier', kind: 'other', rawInput: null }),
    execute: async (args, exec): Promise<{ ok: boolean; id?: string; tier?: string; error?: string }> => {
      const agent = exec.agent
      if (agent === undefined) {
        return { ok: false, error: 'no agent context — the exposure tier is a per-session fact; call from a session' }
      }
      const id = String(agent.id)
      if (!joinedSessions.has(id)) {
        return { ok: false, error: 'session is not joined to the A2A network — join first (the sidebar control or the host join route)' }
      }
      const tier = args.tier === 'fleet' ? 'fleet' : 'linked'
      exposureStore.setTier(id, tier)
      logger.info(`a2a: ${id8(id)} exposure tier -> ${tier}`)
      return { ok: true, id, tier }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'a2a_report',
    description:
      'Report a task or status to this host\'s A2A network — the ONE ingress a session WITHOUT network '
      + 'membership may use (deliberately exempt from the join gate: one-way reporting grants no presence, '
      + 'no discovery, no routing rights; the report lands in the state face\'s reports ring for '
      + 'supervision to read and act on, e.g. adopt or re-join the reporter). Use when you are off the '
      + 'mesh and need to say so. Rate limited to one report per 30s per session; messages cap at 4000 chars.',
    parameters: {
      message: { type: 'string', required: true, description: 'The report text (≤4000 chars).' },
      level: { type: 'string', enum: ['info', 'warning', 'error'], description: 'Severity; error also warns the host log.' },
      task: { type: 'string', description: 'Optional task reference (id/link).' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          ok: { type: 'boolean', required: true },
          reportId: { type: 'string' },
          error: { type: 'string', description: 'Refusal reason when ok is false (empty message, over-cap, or rate limited).' },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.ok === true ? `Report registered (${String(value.reportId)})` : `Report refused: ${String(value.error)}`,
      }],
    },
    presentCall: () => ({ card: 'generic', title: 'A2A report', kind: 'other', rawInput: null }),
    execute: async (args, exec): Promise<{ ok: boolean; reportId?: string; error?: string }> => {
      // Deliberately NO a2aJoinGateRefusal: reporting is the one thing an
      // unjoined session may do — that is the tool's entire purpose.
      const message = String(args.message ?? '').trim()
      if (message === '') return { ok: false, error: 'message is required' }
      if (message.length > 4000) return { ok: false, error: 'message exceeds the 4000-char cap' }
      const session = exec?.agent !== undefined ? String(exec.agent.id) : 'host'
      const now = Date.now()
      const last = reportLastAt.get(session) ?? 0
      if (now - last < 30_000) return { ok: false, error: 'rate limited: one report per 30s per session' }
      // Fix ④ (loop circuit-breaker, d44efa9f pattern): the SAME session
      // reporting the SAME text ≥3 times inside a 10-minute window is a
      // loop, not a situation — refuse with a named reason and audit the
      // ring (the first copies go through; the bounded ring self-expires).
      const loopKey = `${session}:${createHash('sha256').update(message).digest('hex').slice(0, 16)}`
      const loopWindow = (reportLoopRing.get(loopKey) ?? []).filter(at => now - at < 600_000)
      if (loopWindow.length >= 3) {
        recordTeamAudit('agent-less', 'a2a_report', session, false, 'loop detected: 3 identical reports in 10min')
        return { ok: false, error: '循环检测：同会话同文 10 分钟内已上报 3 次，本 report 熔断拒绝。若确需再报请变更内容或等窗口滑出' }
      }
      loopWindow.push(now)
      reportLoopRing.set(loopKey, loopWindow)
      reportLastAt.set(session, now)
      const level = args.level === 'error' || args.level === 'warning' ? args.level : 'info'
      const reportId = `report-${Math.random().toString(16).slice(2, 10)}`
      reportRing.push({
        at: now,
        level,
        message: message.slice(0, 4000),
        session,
        ...(typeof args.task === 'string' && args.task.trim() !== '' ? { task: args.task.trim() } : {}),
      })
      if (reportRing.length > 64) reportRing.splice(0, reportRing.length - 64)
      if (level === 'error') logger.warn(`a2a report (${id8(session)}): ${message.slice(0, 200)}`)
      return { ok: true, reportId }
    },
  }))

  // S5 (owner directive 2026-10-20): information-plane scoping. The host's
  // joined-team scope is the union of every local node's roster
  // declarations — a host-level set, not per-session: supervisor seats need
  // the cross-team overview, and 「加入的团队」 reads as the teams this
  // host's nodes joined. The information-plane tools (a2a_teams /
  // a2a_status / a2a_probe) disclose remote facts only inside that scope;
  // a2a_tasks — this host's own dispatch ledger and receipt-reconciliation
  // surface, including initiator-exempt dispatches — stays unscoped by
  // ruling (its rows name teams this host itself routed to, never a fleet
  // census).
  const joinedTeamScope = (): ReadonlySet<string> => {
    const joined = new Set<string>()
    for (const entry of teamMemberships.list()) {
      for (const team of entry.teams) joined.add(team)
    }
    // G4 (review artifact 688c0354d3 v2): canvas membership is join intent
    // too. This host's canvas teams — and every member handle they name
    // (remote zone-qualified handles as-is, local session ids as their
    // session-team handle) — belong to the scope, so canvas teammates stay
    // visible to each other under teamScopeInfo instead of the roster-only
    // reading splitting them apart.
    for (const name of canvasStore.list()) {
      joined.add(canvasTeamOf(name))
      for (const member of canvasStore.membersOf(name)) {
        joined.add(member.includes('/') ? member : `${config.team}/${id8(member)}`)
      }
    }
    return joined
  }
  /**
   * Whether a peer card proves service to any joined team — its own zone
   * team, a published session team, or any roster declaration. A card that
   * proves nothing serves nothing: under scoping it is withheld, which is
   * the legacy-peer cost the directive accepts (pre-roster peers cannot
   * prove service either way).
   */
  const cardServesJoined = (card: A2aPeerCard, joined: ReadonlySet<string>): boolean =>
    joined.has(card.team)
    || (card.sessionTeams ?? []).some(entry => joined.has(entry.team))
    || (card.teamMemberships ?? []).some(membership => joined.has(membership.team))

  ctx.tools.register(defineTool({
    name: 'a2a_teams',
    description:
      'List or search reachable A2A teams: this host\'s own process team and joined session nodes first (marked [this host], '
      + 'routable over loopback — same-host collaboration needs no peers), then teams across the tracked peer network '
      + 'with owner label, a recent-activity excerpt, the publishing host (origin: node label + LAN IP — the natural '
      + 'grouping when a fleet spans machines), and the session\'s working directory when shared. Pass query to filter '
      + 'by keyword (case-insensitive substring over team name, title, excerpt, origin, or workspace) — searching '
      + 'discovers one extra referral hop within the call. Canvas teams (<team>/canvas/<name>, user-composed multi-member groups) '
      + 'list as local rows; routing to one resolves the first live member or wakes the first cold one — the dispatching session '
      + 'itself is skipped on the local tiers, falling through to the other members (issue #41: a member routing to its own group '
      + 'never loops home). '
      + 'While teamScopeInfo is on (default), the listing follows YOUR collaboration circle: remote rows serve only teams joined by this host\'s nodes, and [this host] session rows show only your own row, your canvas teams, and sessions sharing a team with you — an exposed node id invites mis-routing, so the directory does not advertise strangers. The owner\'s GUI panel keeps the full plane; teamScopeInfo: false opens it for tools too. '
      + 'Call this before a2a_route to pick a target team.',
    parameters: {
      query: { type: 'string', description: 'Optional keyword filter (case-insensitive substring over team/name/description).' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          ok: { type: 'boolean', required: true },
          query: { type: 'string', description: 'The filter applied, empty when unfiltered.' },
          teams: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                team: { type: 'string', required: true },
                session: { type: 'string', required: true },
                name: { type: 'string', required: true },
                description: { type: 'string', required: true },
                local: { type: 'boolean', description: 'true when the team is served by this host (loopback candidate).' },
                origin: { type: 'string', description: 'The publishing host (node session label, LAN IP when known) — the natural grouping for fleet rows.' },
                via: { type: 'string', description: 'The peer URL this row was discovered through (host:port), when it came from a peer card.' },
                workspace: { type: 'string', description: 'The session\'s working directory, when shared.' },
                legacy: { type: 'boolean', description: 'true when the publishing node advertises no roster capability (pre-roster peer).' },
                teams: { type: 'array', items: { type: 'string' }, description: 'Roster teams the node declared for this handle (card teamMemberships).' },
              },
            },
          },
          note: { type: 'string', description: 'Present while teamScopeInfo scoping is on: the joined-team scope plus how many rows outside YOUR collaboration circle were withheld (remote/local split; the process team, your own row, and your canvas teams always show).' },
        },
      },
      render: (args, value) => [{
        type: 'text',
        text: (value.teams.length === 0
          ? `No A2A teams${(value.query ?? '') === '' ? '' : ` matching "${String(args.query)}"`} are currently reachable.`
          : value.teams.map(team => `- ${team.team}${team.local === true ? ' [this host]' : ''}${team.name === '' ? '' : ` (${team.name})`}${team.description === '' ? '' : ` — ${team.description}`}${typeof team.origin === 'string' && team.origin !== '' && team.local !== true ? ` @ ${team.origin}` : ''}${typeof team.workspace === 'string' && team.workspace !== '' ? ` [${team.workspace}]` : ''}`).join('\n'))
          + (value.note === undefined ? '' : `\n${value.note}`),
      }],
    },
    presentCall: args => ({ card: 'generic', title: args.query === undefined || args.query === '' ? 'List reachable A2A teams' : `Search A2A teams: ${args.query}`, kind: 'other', rawInput: args }),
    execute: async (args: { query?: string }, exec): Promise<{ ok: boolean; query: string; teams: DirectoryTeamRow[]; note?: string }> => {
      a2aJoinGateRefusal(exec)
      const query = args.query?.trim().toLowerCase() ?? ''
      let teams = await listDirectoryTeams(query !== '')
      // S5: remote rows survive only when they serve a joined team (the
      // row's own name or any roster declaration it carries); local rows
      // are host-internal facts and always survive. The note keeps the
      // model from reading a scoped listing as an empty fleet.
      let note: string | undefined
      if (ownerTeamScopeInfo) {
        const joined = joinedTeamScope()
        const remoteBefore = teams.filter(row => row.local !== true).length
        teams = teams.filter(row => row.local === true || joined.has(row.team) || (row.teams ?? []).some(name => joined.has(name)))
        const hiddenRemote = remoteBefore - teams.filter(row => row.local !== true).length
        // gh#39 (owner ruling: the listing ADVERTISES targets — an exposed
        // node id invites a session with no collaboration relationship to
        // route at it): [this host] session rows follow the CALLER's
        // collaboration circle. The host's own GUI/panel keeps the full
        // plane (the owner's eyes); the model-tool face is scoped.
        let hiddenLocal = 0
        const callerAgent = exec.agent
        if (callerAgent !== undefined) {
          const callerId = String(callerAgent.id)
          const ownHandle = sessionTeamOf(callerAgent)
          const myCanvas = new Set(canvasStore.teamsOf(callerId))
          const myRoster = new Set(teamMemberships.teamsOf(callerId))
          const before = teams.length
          teams = teams.filter(row => {
            if (row.local !== true) return true
            if (row.team === config.team || row.team === ownHandle) return true
            if (row.team.startsWith(`${config.team}/canvas/`)) return myCanvas.has(row.name)
            // Another session's team row: visible only when we share a
            // canvas or a declared team with that session.
            const targetId8 = row.team.slice(config.team.length + 1)
            const target = [...sessionNodes.values()].find(agent => id8(String(agent.id)) === targetId8)
            if (target === undefined) return true // unresolvable: keep (host fact)
            const targetId = String(target.id)
            const shares = [...canvasStore.teamsOf(targetId)].some(name => myCanvas.has(name))
              || [...teamMemberships.teamsOf(targetId)].some(name => myRoster.has(name))
            return shares
          })
          hiddenLocal = before - teams.length
        }
        const hidden = hiddenRemote + hiddenLocal
        note = `teamScopeInfo on: ${String(joined.size)} joined team${joined.size === 1 ? '' : 's'} on this host — ${String(hidden)} row${hidden === 1 ? '' : 's'} outside your collaboration circle withheld (${String(hiddenRemote)} remote, ${String(hiddenLocal)} local [this host] session rows; the process team, your own row, and your canvas teams always show). To widen the scope: a human composes the shared canvas team (the board drag), the owner adds the EXACT team name to teamJoinAllowlist (patterns carry no mint rights, gh#11), or the owner sets teamScopeInfo: false for the open plane`
      }
      if (query === '') return { ok: true, query: '', teams, ...(note !== undefined ? { note } : {}) }
      const matches = (team: DirectoryTeamRow): boolean =>
        team.team.toLowerCase().includes(query) || team.name.toLowerCase().includes(query) || team.description.toLowerCase().includes(query)
        || team.session.toLowerCase().includes(query)
        || (team.origin ?? '').toLowerCase().includes(query) || (team.workspace ?? '').toLowerCase().includes(query) || (team.via ?? '').toLowerCase().includes(query)
      return { ok: true, query, teams: teams.filter(matches), ...(note !== undefined ? { note } : {}) }
    },
  }))

  /**
   * The directory's listing: this host's own teams lead (the loopback
   * candidates a2a_route dials first) — the process team, then every joined
   * live session node with its title and activity facts; then every tracked
   * peer card's own team plus its joined session teams. Delegated names are
   * not listed — only names a tracked zone publishes directly appear;
   * delegations resolve at route time (a resolvable delegation always
   * aliases a listed team, so rows for them would repeat).
   *
   * Discovery is gossip: each fetch offers the card's referrals to the
   * store, and mid-iteration offers are normally fetched on the next call.
   * A search pass chases one extra hop within the call — after the first
   * sweep, peers that were newly offered get their own card fetched — so a
   * keyword hunt reaches sessions the previous call had not yet gossiped,
   * while staying bounded (one extra sweep, still under the store cap).
   * @param expand - chase one referral hop beyond the current store walk.
   */
  type DirectoryTeamRow = { team: string; session: string; name: string; description: string; local?: boolean; origin?: string; workspace?: string; via?: string; legacy?: boolean; teams?: string[] }
  async function listDirectoryTeams(expand: boolean): Promise<DirectoryTeamRow[]> {
    const localOrigin = lanIp === '' ? `${session} [this host]` : `${session} [this host, ${lanIp}]`
    const teams: DirectoryTeamRow[] = [
      { team: config.team, session, name: config.agentName, description: '', local: true, origin: localOrigin },
      ...[...sessionNodes.values()].map(agent => ({
        team: sessionTeamOf(agent),
        session,
        ...nodeMetadataOf(agent),
        local: true,
        origin: localOrigin,
      })),
      // Canvas teams: user-composed multi-member rows. Member count and live
      // count are the facts a caller needs before routing — resolution picks
      // the first live member at route time.
      ...canvasStore.list().map(name => {
        const members = canvasStore.membersOf(name)
        const live = members.filter(id => sessionNodes.has(id)).length
        return {
          team: canvasTeamOf(name),
          session,
          name,
          description: `canvas team — ${members.length} member${members.length === 1 ? '' : 's'}, ${live} live`,
          local: true,
          origin: localOrigin,
        }
      }),
      // Native-teams registry rows (opt-in bridge): local teams this node
      // can dispatch inbound. They list only when the operator opted in —
      // registry presence alone is never network exposure.
      ...(config.nativeTeamsInbound === true
        ? (teamsRegistry()?.listTeams() ?? []).map(entry => ({
          team: entry.name,
          session,
          name: entry.name,
          description: entry.description,
          local: true,
          origin: localOrigin,
        }))
        : []),
    ]
    const fetch = memoizedCardFetch()
    // Collect per peer in store order (concurrent fetches, ordered merge):
    // the listing's row order follows the peer store's preference order,
    // independent of fetch completion timing.
    const collectPeer = async (peer: string): Promise<DirectoryTeamRow[]> => {
      const card = await fetch(peer)
      if (card === undefined) return []
      // The origin fields (publisher session label + LAN IP) are natural
      // grouping dimensions: a fleet's rows cluster by the host that owns
      // them, no manual grouping required.
      const origin = card.lanIp !== undefined ? `${card.session} (${card.lanIp})` : card.session
      // via = the peer URL the card was fetched from: the panel shows which
      // host:port each remote row came from, so an unknown node is traceable
      // to its publishing endpoint at a glance.
      // legacy: the publisher's card carries no roster capability — a
      // pre-roster node (0.5.43-). Rows from it are marked so the fleet
      // audit (and the phase-2 teamed-only default flip) knows which peers
      // never grow the roster face.
      const legacy = (card.capabilities as { roster?: unknown } | undefined)?.roster !== true
      const rows: DirectoryTeamRow[] = [
        { team: card.team, session: card.session, name: card.name, description: '', origin, via: peer, ...(legacy ? { legacy } : {}) },
      ]
      // Roster reader half: the card's unsigned teamMemberships map each
      // published session team to its declared roster teams, so a remote
      // node's teamed/teamless state is visible without visiting its host.
      const rosterOf = new Map<string, string[]>()
      for (const membership of card.teamMemberships ?? []) {
        const list = rosterOf.get(membership.node) ?? []
        list.push(membership.team)
        rosterOf.set(membership.node, list)
      }
      for (const entry of card.sessionTeams ?? []) {
        const declared = rosterOf.get(entry.team)
        rows.push({ team: entry.team, session: card.session, name: entry.name, description: entry.description, origin, via: peer, ...(entry.workspace !== undefined ? { workspace: entry.workspace } : {}), ...(legacy ? { legacy } : {}), ...(declared !== undefined && declared.length > 0 ? { teams: declared } : {}) })
      }
      return rows
    }
    // Bounded-concurrency sweep (mapBounded keeps row order by index, so the
    // listing still follows the peer store's preference order): a cold cache
    // must not open up to PEER_CAP simultaneous card fetches at once.
    const sweep = async (peers: readonly string[]): Promise<void> => {
      const collected = await mapBounded(peers, SWEEP_CONCURRENCY, collectPeer)
      for (const rows of collected) teams.push(...rows)
    }
    const before = peerStore.list()
    await sweep(before)
    if (expand) {
      // One extra hop: only peers the first sweep's referrals newly offered,
      // collected once each — the memo keeps already-fetched URLs free.
      const fresh = peerStore.list().filter(peer => !before.includes(peer))
      if (fresh.length > 0) await sweep(fresh)
    }
    return teams
  }

  /**
   * Whether one caller label can receive network traffic back. Composite
   * `<zone>/<id>` shapes route anywhere (N1); bare zone names resolve to a
   * live initiator per host, so cross-host they would steer whichever node
   * shares the name — treated as unroutable everywhere.
   */
  function routableCallerLabel(callerSession: string | undefined): boolean {
    return callerSession !== undefined &&
      (/[a-z0-9-]+\/[0-9a-f]{8}$/i.test(callerSession) || /[a-z0-9-]+\/[a-z0-9]{4,}$/i.test(callerSession))
  }

  /**
   * Why an async route from such a caller cannot expect its receipt: the
   * autosend arm skips it and the steered hint is omitted, so the debt has
   * no paying path — say so at dispatch time instead of silently stranding
   * a pending row.
   */
  function unroutableCallerNote(label: string): string {
    return `\n(Note: caller label "${label}" is not network-routable, so the target cannot auto-send a receipt back to you — reconcile via context_id follow-ups instead.)`
  }

  /**
   * Track one routed task in the ledger when its result leaves it owed a
   * receipt: ONLY an explicitly async dispatch (fire-and-forget) owes one —
   * a synchronous wait released early (TASK_STATE_ABORTED_WAIT) is a
   * conversational exchange, and booking it as owed filled the ledger with
   * conversation noise no receipt can ever settle (A-ruling, 2026-09-01
   * decision seat: sync Q&A must not enter pending; only real
   * receipt-awaiting rows stay on the book). A synchronous completion
   * already carries its answer and owes nothing.
   */
  const trackOwedTask = (taskId: string, team: string, peer: string, result: A2aRouteResult, callbackAddress?: string, brief?: string): void => {
    if (!result.ok) return
    // Native-teams bridge rounds emit no A2A receipt in this slice: booking
    // them as receipt-owed would fill the owed book with rows no receipt can
    // ever settle (evicting genuinely receivable peer rows past TASK_CAP).
    if (result.bridge !== undefined) return
    if (result.task_status !== 'TASK_STATE_DELIVERED') return
    // Fix ② (ghost-debt stop): a delivered async dispatch with no routable
    // callback address can never be settled — register it receiptless
    // (visible, non-debt; reconcile via context_id) instead of stranding a
    // row whose only exit was the dead-letter sweep (57 dead letters, half
    // this shape).
    if (callbackAddress === undefined) {
      taskLedger.trackReceiptless(taskId, team, peer, result.context_id === '' ? undefined : result.context_id, brief)
      return
    }
    taskLedger.track(taskId, team, peer, result.context_id === '' ? undefined : result.context_id, brief)
  }

  /**
   * Build the -32004 verdict. The error string is the calling model's ONLY
   * context for its next decision, so it must carry the failure class, the
   * local reason (the most diagnostic fact: "not joined" vs "no live node"
   * vs a wake failure), nearby advertised teams for typo/wrong-seat catches,
   * and actions the CALLING model can actually take. Joining is the target
   * session's own gesture — the verdict relays that request instead of
   * instructing the caller to perform it (and never cites tooling the
   * caller does not have).
   */
/**
 * Fix 1 (能发即能收): resolve the caller's routable label for one routed
 * dispatch. Priority: the joined session's node team > the exempt initiator
 * face (the NODE team — bare, team-name routable) > the session label (not
 * routable; the dispatch registers receiptless per fix 2).
 */
const routeVerdict = (team: string, failures: readonly string[], candidateCount: number): { ok: false; error: string; code: number } => {
    if (candidateCount > 0) {
      return {
        ok: false,
        error: `team "${team}" failed on every candidate: ${failures.join('; ')} — enumerate live alternatives with a2a_teams instead of retrying unchanged`,
        code: -32004,
      }
    }
    const remote = failures.filter(entry => !entry.startsWith('local: '))
    const suffix = team.slice(team.indexOf('/') + 1)
    const near = [...new Set([
      ...joinedSessions.list().map(id => `${config.team}/${id8(id)}`),
      ...[...sessionNodes.values()].map(agent => sessionTeamOf(agent)),
      ...canvasStore.list().map(name => `${config.team}/canvas/${name}`),
      config.team,
    ])].filter(candidate => {
      if (candidate === team) return false
      const candidateSuffix = candidate.slice(candidate.indexOf('/') + 1)
      return candidate.includes(suffix) || suffix.includes(candidateSuffix) || candidateSuffix.startsWith(suffix.slice(0, 4))
    }).slice(0, 3)
    const lines = [
      `team "${team}" is not published by any configured peer${remote.length > 0 ? ` (unresolved delegations: ${remote.join('; ')})` : ''}`,
      ...failures.filter(entry => entry.startsWith('local: ')).map(entry => `local reason: ${entry.slice('local: '.length)}`),
      near.length > 0 ? `nearby advertised teams: ${near.join(', ')}` : undefined,
      'next: enumerate live alternatives with a2a_teams; do not retry unchanged; joining is the target session\'s own gesture (its sidebar) — relay that request to the human',
    ].filter((line): line is string => line !== undefined)
    return { ok: false, error: lines.join(' — '), code: -32004 }
  }

  ctx.tools.register(defineTool({
    name: 'a2a_route',
    description:
      'Route a message to a remote A2A team on the peer network and await its reply. '
      + 'Pick the team with a2a_teams first. Team names also resolve through peers\' signed zone '
      + 'delegation records (zone-relative, at most 5 hops). Reuse context_id from a previous reply '
      + 'to continue that conversation. The call blocks until the remote team responds, which may take minutes — '
      + 'pass async for long-running tasks: delivery returns immediately and the target routes a receipt '
      + '(message starting "[A2A receipt] task <task_id> <outcome summary>") back to your team.',
    parameters: {
      team: { type: 'string', required: true, description: 'Target team name, from a2a_teams.' },
      message: { type: 'string', required: true, description: 'The request text to send. For long verdict-style payloads, split into parts and label each "1/N", "2/N"… so the receiver can reassemble.' },
      context_id: { type: 'string', description: 'Context id from a previous a2a_route reply, to continue that conversation.' },
      async: { type: 'boolean', description: 'Fire-and-forget: deliver and return immediately (delivered:true + task_id) without waiting for the target\'s reply. The target answers by routing a receipt — a message starting "[A2A receipt] task <task_id> <outcome summary>" — back to your team (visible in a2a_status activity), or follow up with the context_id. Prefer async for long-running tasks (minutes to hours).' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: true,
      },
      render: renderRoute,
    },
    timeoutMs: config.routeTimeoutMs,
    presentCall: args => ({ card: 'generic', title: `A2A route → ${args.team}`, kind: 'other', rawInput: args }),
    execute: async (args: { team: string; message: string; context_id?: string; async?: boolean }, exec): Promise<Record<string, JsonValue>> => {
      // Owner ruling (tool-layer interception): the PROCESS face (bare
      // zone === config.team) keeps its host-level EXEMPTION on the network
      // admission layer — receipts, quick dispatch and host-side routing
      // still target it internally — but a MODEL TOOL call must not address
      // it: the machine's own mailbox is not a member face, and letting a
      // session route there would turn the host entrance into a group-free
      // hop. Host-face entry (agent-less control routes, receipt ladders)
      // never passes through this tool and stays untouched.
      const requestedTeam = String(args.team ?? '').trim()
      if (exec.agent !== undefined && requestedTeam === config.team) {
        return {
          ok: false,
          error: `the process face "${config.team}" is the host's own mailbox — model tools must target a member face. Route to a session team handle ("${config.team}/<id8>" from a2a_teams) or a canvas team; receipts and quick dispatch reach the host face on their own paths.`,
          code: -32000,
        }
      }
      return routeTrunk(args, exec.agent, exec.signal)
    },
  }))

  /**
   * The routing trunk (0.6.9): the one failover sequence behind both the
   * a2a_route tool (agent face) and the quick-dispatch control route (host
   * face, no agent). Gates — agent-less audit, join gate, team-scoped
   * routing — then caller-label resolution, local dispatch, the canvas
   * remote-member seam, and the directory walk. Faces differ only in who
   * the caller is; the delivery semantics stay identical by construction.
   * The host face (agent === undefined) rides the bare node team as its
   * caller label — the "能发即能收" invariant: whatever it addresses can
   * answer it with one route.
   */
  async function routeTrunk(args: { team: string; message: string; context_id?: string; async?: boolean }, agent: Agent | undefined, signal: AbortSignal, hostCaller?: string): Promise<Record<string, JsonValue>> {
      // Fix ③ (S4 audit): host-side calls carry no agent identity — every one
      // lands in the team audit ring, and the owner can flip the gate from
      // 'audit' to 'refuse' (config gateAgentLessCalls) when the operator
      // face should not be a routing principal at all.
      if (agent === undefined) {
        recordTeamAudit('agent-less', String(args.team ?? ''), 'host', true,
          config.gateAgentLessCalls === 'refuse' ? 'refused by gateAgentLessCalls' : 'audited (default)')
        if (config.gateAgentLessCalls === 'refuse') {
          return {
            ok: false,
            error: 'gateAgentLessCalls=refuse: host-side (agent-less) routing is disabled by configuration — route from a joined session instead',
          }
        }
      }
      // The caller identity travels as a routable team (the calling session's
      // node team when it has joined, else the node label), so the receiver
      // can answer with one a2a_route instead of an unroutable display label.
      a2aJoinGateRefusal(agent === undefined ? undefined : { agent })
      // S3 (team-scoped routing, off by default): when the owner turns it
      // on, collaboration happens inside teams. A session caller must have
      // declared membership in the target team before it may address it,
      // and a caller with no teams at all has no network — a teamless node
      // is, by the same ruling, an unjoined one. Host-side calls (no agent)
      // and the initiator face stay exempt, like the join gate; discovery
      // (a2a_teams) stays open so a teamless node can still see what to join.
      if (config.teamScopeRouting && agent !== undefined) {
        const scopeCaller = String(agent.id)
        let initiator = false
        try {
          initiator = ctx.get('agents')?.requireInitiator() === agent
        } catch { /* no initiator in this fiber */ }
        if (!initiator) {
          const callerTeams = teamMemberships.teamsOf(scopeCaller)
          const team = String(args.team ?? '').trim()
          // gh#71: the SHARED-CANVAS basis and the warm cache's peer-org
          // basis (an org entry naming BOTH the caller and the target
          // handle) count as declared here too — the same link the
          // admission core honors on the receiving side; without this the
          // tool face refused routes the canvas itself had authorized.
          // Canvas members mix two shapes: LOCAL sessions sit by session
          // id, cross-host members by zone/id8 handle — match either.
          const callerHandle = `${config.team}/${id8(scopeCaller)}`
          // gh#45 末修 (66abc2cf defect): a CANVAS GROUP NAME target
          // (`<team>/canvas/<name>`) never matches member handles — a
          // whole-group dispatch from a group member was refused. The
          // group's own team handle (canvasTeamOf(name)) is the match
          // (the caller sits in the very group being addressed).
          const sharedCanvas = canvasStore.list().some(name => {
            const members = canvasStore.membersOf(name)
            const inGroup = members.includes(scopeCaller) || members.includes(callerHandle)
            return inGroup ? members.includes(team) || canvasTeamOf(name) === team : false
          })
          let orgShared = false
          for (const cached of cardCache.values()) {
            const org = (cached.card as { canvasOrg?: Array<{ team?: unknown; members?: unknown }> } | undefined)?.canvasOrg
            if (!Array.isArray(org)) continue
            for (const e of org) {
              if (typeof e.team !== 'string' || e.team === '' || !Array.isArray(e.members)) continue
              const inOrg = e.members.includes(scopeCaller) || e.members.includes(callerHandle)
              if (inOrg && (e.members.includes(team) || e.team === team)) { orgShared = true; break }
            }
            if (orgShared) break
          }
          if (callerTeams.length === 0 && !sharedCanvas && !orgShared) {
            return {
              ok: false,
              error: `team-scoped routing is on and this session (${id8(scopeCaller)}) has declared no team membership — a teamless node has no network. Declare one with a2a_team_join (subject to the owner's teamJoinAllowlist)`,
            }
          }
          if (!callerTeams.includes(team) && !sharedCanvas && !orgShared) {
            return {
              ok: false,
              error: `team-scoped routing is on: routing to "${team}" requires declared membership. This session's teams: ${callerTeams.join(', ')}. a2a_team_join can declare it (subject to the owner's teamJoinAllowlist)`,
            }
          }
        }
      }
      let callerSession = resolveCallerLabel({
        joined: agent !== undefined && sessionNodes.has(String(agent.id)),
        initiatorFace: agent !== undefined && exemptInitiatorFace(agent),
        nodeTeam: config.team,
        joinedTeam: agent === undefined ? undefined : sessionTeamOf(agent),
        sessionLabel: agent === undefined ? undefined : sessionLabelOf(agent),
      })
      // The quick-dispatch control face (0.6.9) passes the bare node team
      // explicitly: receipts address it and land on the team face (the
      // "能发即能收" invariant). Agent-less TOOL calls keep the legacy
      // fallback (the node session label) — apply.spec pins it.
      if (agent === undefined && hostCaller !== undefined) callerSession = hostCaller
      // P2 receipt-callback: the caller's routable address rides the wire so
      // a peer routes its receipt to THIS session's node team (not to
      // wherever its caller-label heuristics land). The bare node team is
      // team-name routable on the target even though it lacks the /hash
      // suffix the regex demands — accepted explicitly here.
      const callbackAddress = routableCallerLabel(callerSession) || callerSession === config.team
        ? callerSession
        : undefined
      const fetch = memoizedCardFetch()
      // The task id is born at the caller (idempotency key semantics): both
      // dispatchers carry the one id, the peer request echoes it, and the
      // steered receipt header names it — so "[A2A receipt] task <id>" from
      // the target correlates with the route's own result verbatim.
      const taskId = `direct-${Math.random().toString(16).slice(2, 10)}`
      // Candidate order: this host's own teams first (an in-process steer —
      // cheapest possible and immune to nested-signal aborts), then direct
      // publishers, then zone delegations, deduplicated by URL.
      const failures: string[] = []
      const outcome = await dispatchLocalCandidate(args.team, args.message, callerSession, args.context_id, signal, args.async === true, taskId, callbackAddress, agent === undefined ? undefined : String(agent.id))
      if (outcome !== undefined) {
        if (outcome.ok) {
          trackOwedTask(taskId, args.team, 'local', outcome, callbackAddress, briefOf(args.message))
          return outcome as unknown as Record<string, JsonValue>
        }
        failures.push(`local: ${outcome.error}`)
      }
      // Failover seam for canvas teams: after the local tiers miss, the
      // canvas team's remote members (zone-qualified team handles) are dialed
      // in member order — the same priority rule the local live/cold tiers
      // follow. Each remote handle is a routable team name on its own host,
      // so the directory walk runs per target and the candidate pool is the
      // union in member order. Non-canvas teams keep the single-walk shape
      // unchanged. The ledger stays keyed to the canvas team the caller
      // named; the peer request carries the member handle it must resolve.
      const canvasName = parseCanvasTeamName(args.team)
      const remoteTargets = canvasName !== undefined ? canvasStore.remoteMembersOf(canvasName) : []
      const targets = remoteTargets.length > 0 ? [...remoteTargets] : [args.team]
      if (remoteTargets.length > 0) {
        failures.push(`local: canvas team "${args.team}" has no live or wakeable local member`)
      } else if (canvasName !== undefined && canvasStore.hasTeam(canvasName)) {
        // Issue #41: no remote members and no usable local tier — the only
        // remaining candidate shape is the initiator itself, and routing
        // there would loop. Name it instead of letting the directory walk
        // report an unrelated miss.
        failures.push(`local: canvas team "${args.team}" has no live or wakeable member besides the initiating session — routing to a canvas team whose only member is the caller itself would loop; target another member's team handle directly`)
      }
      const candidatePool: Array<{ candidate: string; target: string }> = []
      for (const target of targets) {
        for (const candidate of await directoryPeerCandidates(fetch, target, failures)) {
          candidatePool.push({ candidate, target })
        }
      }
      // Failover: try every candidate in order — an offline path falls back
      // to the next alternate without a caller-visible error; only
      // exhaustion surfaces, with each candidate's reason.
      for (const { candidate, target } of candidatePool) {
        // Capability gate: wait:false only dials peers whose signed card
        // declares async — against a pre-0.5.2 peer the flag would silently
        // degrade into a minutes-long blocking hold (an async intent must
        // never turn into a surprise wait). The memo keeps the card fetch
        // free after the directory walk.
        let peerAsync = false
        if (args.async === true) {
          const card = await fetch(candidate)
          const caps = card?.capabilities as { async?: unknown } | undefined
          peerAsync = card !== undefined && caps?.async === true
        }
        const result = await dispatchPeerCandidate(candidate, target, args.message, args.context_id, signal, callerSession, peerAsync, taskId, callbackAddress)
        if (result.ok || signal.aborted) {
          if (result.ok) trackOwedTask(taskId, args.team, candidate, result, callbackAddress, briefOf(args.message))
          const notes: string[] = []
          if (result.ok && args.async === true && result.task_status === 'TASK_STATE_DELIVERED' && !routableCallerLabel(callerSession)) {
            notes.push(unroutableCallerNote(String(callerSession ?? session)))
          }
          if (result.ok && args.async === true && !peerAsync) {
            notes.push('\n(Note: the peer does not advertise async; the call waited synchronously.)')
          }
          if (result.ok && notes.length > 0) {
            return { ...result, team: args.team, reply: `${result.reply}${notes.join('')}` } as unknown as Record<string, JsonValue>
          }
          return { ...result, ...(result.ok ? { team: args.team } : {}) } as unknown as Record<string, JsonValue>
        }
        failures.push(`${candidate}: ${result.error}`)
      }
      if (failures.length > 0) logger.warn(`route to team "${args.team}" exhausted its candidates: ${failures.join('; ')}`)
      return routeVerdict(args.team, failures, candidatePool.length)
  }

  /**
   * The route dispatcher's local half: same-host candidates dial in-process,
   * not over loopback HTTP — a loopback fetch nests the final wait inside the
   * caller's own tool signal, and when that turn budget aborts, the abort
   * surfaces as the peer's failure even though delivery succeeded. The turn
   * signal still races the wait; on abort the honest result reports delivery
   * without a reply. Results use the canonical A2aRouteOk shape — the wire
   * route shape renders as "failed: undefined" through the tool renderer.
   * @param asyncMode - deliver without waiting: the steer fires, the
   * registered waiter still flushes (harmlessly) into the settled promise,
   * and the caller gets the delivered shape with the receipt contract.
   * @returns the canonical result, or undefined when the team is not local.
   */
  async function dispatchLocalCandidate(team: string, message: string, callerSession: string | undefined, contextId: string | undefined, signal: AbortSignal, asyncMode = false, taskIdFromCaller?: string, callbackAddress?: string, originAgentId?: string): Promise<A2aRouteResult | undefined> {
    const webServer = ctx.get('webServer')
    // W1 (boundary hardening): the local in-process candidate is an
    // admission seam like any other — a JOINED session (zone/id8 caller
    // face) must clear the same shared-team admission /a2a/direct applies,
    // or a teamless local node could route to any session team by riding
    // the cheapest path. The initiator face (bare node team) and
    // foreign-zone labels are NOT gated here (F1b host-face rules, R-C
    // pending) — only the joined face closes.
    const joinedRefusal = joinedFaceAdmissionRefusal(callerSession, team)
    if (joinedRefusal !== undefined) {
      recordActivity('out', team, callerSession ?? 'local', false)
      return { ok: false, error: joinedRefusal, code: -32000 }
    }
    const canvasName = parseCanvasTeamName(team)
    // Issue #41 shape note: the caller label is the WIRE form (<zone>/<id8>
    // or a session label) and quick-dispatch BORROWS a live session's team
    // as its host face — so the label alone cannot tell an initiating agent
    // from a borrowed one. The exemption keys on the ORIGINATING agent's id
    // (same shape as a member slot) passed down by routeTrunk; the host face
    // passes none and never exempts.
    const callerNodeId = originAgentId
    let teamIsLocal = team === config.team
      || resolveAgentForTeam(team) !== undefined
      || joinedSessions.list().some(id => `${config.team}/${id8(id)}` === team)
      // Issue #41 (self-route rule on canvas tiers): the initiator's own
      // member slot never makes the team local — an exempt local tier must
      // fall through to the remote members instead of echoing home.
      || (canvasName !== undefined && (canvasLiveAgent(canvasName, callerNodeId) !== undefined || canvasColdMemberId(canvasName, callerNodeId) !== undefined))
    // gh#45 CLI mailbox: a delivery targeting a DEPOSITED CLI handle is
    // local by definition — it lands in the deposit's mailbox (the CLI
    // polls while alive; receipts and messages never wake anything).
    const cliRow = cliDeposits.get(team)
    if (cliRow !== undefined) {
      cliDeposits.mail(team, callerSession ?? 'unknown', message)
      recordActivity('in', team, callerSession ?? 'peer', true)
      logger.info(`a2a: cli mailbox delivery for ${team} (from ${callerSession ?? 'unknown'})`)
      return { ok: true, team, reply: `delivered to the mailbox of ${team} — the CLI polls while online`, task_id: taskIdFromCaller ?? '', context_id: contextId ?? '', task_status: 'TASK_STATE_COMPLETED' }
    }
    // The native-teams claim probe is an await: pay it only when the four
    // cheap synchronous locality checks missed (a registry team is a local
    // candidate even though no session node backs it).
    if (!teamIsLocal && team !== config.team) teamIsLocal = await nativeTeamsClaims(team)
    if (!teamIsLocal || webServer === undefined) return undefined
    // A receipt relayed between same-host sessions (the answering session
    // routing its `[A2A receipt]` back over the in-process candidate)
    // correlates here too — same contract, no HTTP on the path.
    settleAndAnnounce(message)
    const taskId = taskIdFromCaller ?? `direct-${Math.random().toString(16).slice(2, 10)}`
    const flight = beginRoute(team, 'local')
    if (asyncMode) {
      // Delivery means the message is IN, not merely enqueued: a cold team
      // materializes first (the wake settles, or fails honestly), then the
      // steer fires, then delivered answers. The receipt header carries the
      // task id so the target can echo it back verbatim.
      // Issue #41: the canvas live tier skips the initiating session, so a
      // dispatch from a member never resolves back to its author.
      const agent = resolveAgentForTeam(team) ?? canvasLiveAgent(canvasName, callerNodeId)
      const wake = agent !== undefined ? undefined : wakeColdTeam(team, callerNodeId)
      let woken: Promise<Agent> | undefined = agent !== undefined
        ? Promise.resolve(agent)
        : wake?.kind === 'flight' ? wake.flight : undefined
      if (woken === undefined) {
        // Bridge BEFORE the bare-team fallback — claim beats the initiator
        // redirect, the same rule routeIntoAgent follows (a bare team name
        // claimed by the registry must not fork its destination by wait
        // semantics). Prepare-first: claim, seam, and parent initiator are
        // everything that can fail fast, so a phantom delivery never answers
        // success. The fire is truly detached (no caller signal — the turn
        // ending must not silently retract an already-announced delivery);
        // rounds emit no receipt in this slice (the `bridge` marker keeps
        // the caller's ledger honest).
        const prepared = await nativeTeamsPrepare(team)
        if (prepared.ok) {
          endRoute(flight)
          recordActivity('out', team, 'local', true)
          void nativeTeamsRound(prepared, team, callerSession ?? session, message, taskId)
            .then(outcome => {
              if (!outcome.ok) {
                recordActivity('out', team, 'local', false)
                logger.warn(`a2a: detached native-teams round for "${team}" failed: ${outcome.error}`)
              }
            })
          return {
            ok: true,
            team,
            reply: `Delivered to ${team} (async native-teams round dispatched). The round settles through the team's own routing chain; it routes no A2A receipt in this slice — reconcile via context_id follow-ups.`,
            task_id: taskId,
            context_id: contextId ?? `ctx-${Math.random().toString(16).slice(2, 10)}`,
            task_status: 'TASK_STATE_DELIVERED',
            bridge: 'native-teams',
          }
        }
        if (prepared.reason === 'error') {
          endRoute(flight)
          recordActivity('out', team, 'local', false)
          return { ok: false, error: prepared.error, code: -32000 }
        }
        // Claim declined: the bare process team still steers the live initiator.
        const live = team === config.team ? liveAgent() : undefined
        if (live !== undefined && callerIsAgent(live, callerSession ?? session)) {
          // Self-route refusal (same rule as the sync faces): the initiator
          // resolving to the routing session itself means the dispatch would
          // only echo home and arm a synthetic receipt for work nobody does.
          endRoute(flight)
          recordActivity('out', team, 'local', false)
          return { ok: false, error: selfRouteText(team), code: -32000 }
        }
        if (live === undefined) {
          endRoute(flight)
          return { ok: false, error: wake?.kind === 'no-face' ? noWakeFaceText(team) : wake?.kind === 'archived' ? archivedColdMatchText(team) : noColdMatchText(team), code: -32000 }
        }
        woken = Promise.resolve(live)
      }
      try {
        const target = await woken
        // N1 (review seat 7e4cf94a): dashed composite labels are NOT routable;
        // accept only <zone>/<short-id> shapes so envelopes stop bouncing -32004.
        // An explicit callback address (P2) wins over the caller-label
        // derivation: it is the submitting session's own node team.
        const routable = routableCallerLabel(callerSession)
        const callerTeam = callbackAddress !== undefined && callbackAddress !== ''
          ? callbackAddress
          : routable ? callerSession : undefined
        const receiptHint = callerTeam === undefined ? '' : `\n\n(When done, route your outcome back with one call — a2a_route { team: "${callerTeam}", message: "[A2A receipt] task ${taskId} <one-line outcome>" }.)`
        steerRelay(target, `[A2A direct] (task ${taskId}) ${fromClause(callerSession ?? session)} (routed to ${team}) sent:\n\n${message}${receiptHint}`, callerTeam)
        armReceiptAutosend(target, taskId, callerTeam, message)
        endRoute(flight)
        recordActivity('out', team, 'local', true)
        return {
          ok: true,
          team,
          reply: `Delivered to ${team} (async). The target routes a receipt — a message starting "[A2A receipt] task ${taskId} <outcome summary>" — back to your team when done; watch a2a_status activity or follow up with the context id.${routable ? '' : unroutableCallerNote(String(callerSession ?? session))}`,
          task_id: taskId,
          context_id: contextId ?? `ctx-${Math.random().toString(16).slice(2, 10)}`,
          task_status: 'TASK_STATE_DELIVERED',
        }
      } catch (error) {
        endRoute(flight)
        recordActivity('out', team, 'local', false)
        return { ok: false, error: `waking or steering the session for team "${team}" failed: ${String(error)}`, code: -32000 }
      }
    }
    if (!asyncMode) {
      // Bridge only on a steer-path miss, matching the documented chain
      // (session node → canvas → cold wake → native-teams claim → bare): a
      // registry claim must never shadow a live local session team. The
      // caller's abort cancels the round through its own signal; the 180s
      // deadline restores the bound the steer machinery observes.
      // Issue #41: same initiator exemption on the sync path — the canvas
      // live/cold tiers skip the dispatching session before steerable is
      // decided, so a self-member falls through to remote members.
      const steerable = resolveAgentForTeam(team) !== undefined
        || canvasLiveAgent(canvasName, callerNodeId) !== undefined
        || joinedSessions.list().some(id => `${config.team}/${id8(id)}` === team)
        || wakeColdTeam(team, callerNodeId).kind === 'flight'
      if (!steerable && team !== config.team) {
        const prepared = await nativeTeamsPrepare(team)
        if (prepared.ok) {
          const outcome = await nativeTeamsRound(prepared, team, callerSession ?? session, message, taskId, signal)
          endRoute(flight)
          if (!outcome.ok) {
            // The aborted-wait shape is earned only by an actual round
            // cancellation (the caller's abort reached the seam). A
            // pre-dispatch abort means the message never left the node, and
            // a failed round means it never answered — both answer the
            // honest error instead of claiming a delivery.
            if (outcome.aborted === true) {
              recordActivity('out', team, 'local', true)
              return {
                ok: true,
                team,
                reply: `The message was delivered to ${team} (native-teams round), but the wait was aborted (the round was cancelled with it).`,
                task_id: taskId,
                context_id: contextId ?? `ctx-${Math.random().toString(16).slice(2, 10)}`,
                task_status: 'TASK_STATE_ABORTED_WAIT',
                bridge: 'native-teams',
              }
            }
            recordActivity('out', team, 'local', false)
            return { ok: false, error: outcome.error, code: -32000 }
          }
          recordActivity('out', team, 'local', true)
          return {
            ok: true,
            team,
            reply: outcome.reply,
            task_id: taskId,
            context_id: contextId ?? `ctx-${Math.random().toString(16).slice(2, 10)}`,
            task_status: outcome.settled ? 'TASK_STATE_COMPLETED' : 'TASK_STATE_DELIVERED',
            ...(outcome.settled ? {} : { bridge: 'native-teams' as const }),
          }
        }
        if (prepared.reason === 'error') {
          endRoute(flight)
          recordActivity('out', team, 'local', false)
          return { ok: false, error: prepared.error, code: -32000 }
        }
      }
    }
    const wait = routeIntoAgent(team, message, callerSession ?? session, taskId)
    const aborted = new Promise<never>((_, reject) => {
      signal.addEventListener('abort', () => { reject(new Error('aborted')) }, { once: true })
    })
    // A reply wait without a deadline parks the caller's whole turn forever
    // when the target session answers on its own (slow or never) cadence. The
    // deadline turns that into the same honest delivered shape the abort path
    // returns: the receipt contract carries the follow-up, the caller keeps
    // moving.
    const REPLY_WAIT_MS = 180_000
    const expired = new Promise<never>((_, reject) => {
      const timer = setTimeout(() => { reject(new Error('reply-wait-timeout')) }, REPLY_WAIT_MS)
      timer.unref?.()
      const done = (): void => { clearTimeout(timer); signal.removeEventListener('abort', onAbort) }
      const onAbort = (): void => done()
      signal.addEventListener('abort', onAbort, { once: true })
      wait.then(done, done)
    })
    let outcome: Awaited<ReturnType<typeof routeIntoAgent>>
    try {
      outcome = await Promise.race([wait, aborted, expired])
    } catch (error) {
      if (String(error).includes('reply-wait-timeout')) {
        endRoute(flight)
        recordActivity('out', team, 'local', true)
        return {
          ok: true,
          team,
          reply: `The message was delivered to ${team}, but no reply arrived within ${Math.round(REPLY_WAIT_MS / 1000)}s (the target session answers on its own cadence). It routes a receipt, a message starting "[A2A receipt] task ${taskId}", back to your team when done; check a2a_status activity or follow up with the context id.`,
          task_id: taskId,
          context_id: contextId ?? `ctx-${Math.random().toString(16).slice(2, 10)}`,
          task_status: 'TASK_STATE_DELIVERED',
        }
      }
      endRoute(flight)
      recordActivity('out', team, 'local', true)
      return {
        ok: true,
        team,
        reply: `The message was delivered to ${team}, but the wait for its reply was aborted (the target session answers on its own cadence; route again with the context id).`,
        task_id: taskId,
        context_id: contextId ?? `ctx-${Math.random().toString(16).slice(2, 10)}`,
        task_status: 'TASK_STATE_ABORTED_WAIT',
      }
    }
    endRoute(flight)
    recordActivity('out', team, 'local', outcome.ok)
    if (outcome.ok) {
      return {
        ok: true,
        team,
        reply: outcome.reply,
        task_id: taskId,
        context_id: contextId ?? `ctx-${Math.random().toString(16).slice(2, 10)}`,
        task_status: outcome.status ?? 'TASK_STATE_COMPLETED',
        ...(outcome.bridge !== undefined ? { bridge: outcome.bridge } : {}),
      }
    }
    return { ok: false, error: outcome.error, code: -32000 }
  }

  /**
   * The route dispatcher's peer half: one candidate dial with the in-flight
   * registration and activity-ring record the panel reads. Async mode sends
   * wait:false — the peer steers and answers delivered immediately (its
   * 0.5.2+ handler), so cross-host long tasks ride the receipt contract
   * exactly like same-host ones; older peers that ignore the flag simply
   * keep the blocking wait (graceful degradation).
   */
  async function dispatchPeerCandidate(url: string, team: string, message: string, contextId: string | undefined, signal: AbortSignal, callerSession: string | undefined, asyncMode = false, taskIdFromCaller?: string, callbackAddress?: string): Promise<A2aRouteResult> {
    const flight = beginRoute(team, url)
    const result = await client.routeDirect(url, team, message, contextId, signal, callerSession, asyncMode, taskIdFromCaller, callbackAddress)
    endRoute(flight)
    recordActivity('out', team, url, result.ok)
    // F1 half-transaction compensation (t-mth5gmxy): the client's 15s budget
    // firing on a SYNC route leaves the transaction half-done — the delivery
    // landed and the peer keeps executing. One query round-trip asks the
    // peer for the real state; completed upgrades to the honest result,
    // failed becomes the real failure, anything else stays the honest
    // DELIVERED-UNSETTLED (-32005) with the query instruction.
    if (!asyncMode && !result.ok && result.code === -32005 && taskIdFromCaller !== undefined && taskIdFromCaller !== '') {
      const fingerprint = peerPayloadFingerprint({ caller: callerSession ?? session, message, noWait: false, team })
      const answer = await client.queryOutcome(url, taskIdFromCaller, fingerprint, signal)
      if (answer?.found === true && answer.status === 'completed') {
        return {
          ok: true,
          team,
          reply: `${answer.reply}\n\n(The direct wait hit its ${'15s'} transport budget; this answer is the peer's settled outcome, recovered through the task query.)`,
          task_id: taskIdFromCaller,
          context_id: contextId ?? '',
          task_status: 'TASK_STATE_COMPLETED',
        }
      }
      if (answer?.found === true && answer.status === 'failed') {
        return { ok: false, error: answer.error, code: -32000, task_id: taskIdFromCaller }
      }
    }
    return result
  }

  /**
   * Full dispatch for background senders (the receipt autosend): local
   * first, then the directory walk with per-candidate failover. Unlike
   * {@link dispatchLocalCandidate}, a team that is not ours is NOT treated
   * as a silent non-route — the walk either delivers or THROWS, so the
   * receipt ladder can distinguish "delivered" from "no route" and its
   * owner escalation actually fires for cross-node callback addresses.
   */
  async function dispatchAnywhere(team: string, message: string, callerSession: string | undefined, contextId: string | undefined, signal: AbortSignal, asyncMode: boolean, taskId?: string): Promise<void> {
    const local = await dispatchLocalCandidate(team, message, callerSession, contextId, signal, asyncMode, taskId)
    if (local !== undefined) {
      if (!local.ok) throw new Error(local.error)
      return
    }
    const failures: string[] = []
    const candidates = await directoryPeerCandidates(memoizedCardFetch(), team, failures)
    if (candidates.length === 0) {
      throw new Error(`no route to "${team}": not a local team and not published by any tracked peer`)
    }
    let lastError = 'no candidate delivered'
    for (const candidate of candidates) {
      const result = await dispatchPeerCandidate(candidate, team, message, contextId, signal, callerSession, asyncMode, taskId)
      if (result.ok) return
      lastError = result.error
      if (signal.aborted) break
    }
    throw new Error(`delivery to "${team}" failed on every candidate: ${lastError}`)
  }

  /**
   * The directory's candidate walk for one team: direct publishers first,
   * then every tracked zone's delegation resolutions (cycle/depth/key-binding
   * failures are configuration bugs: closed, logged, and surfaced into
   * {@link failures}), deduplicated by URL. Both passes run their per-peer
   * fetches concurrently under a small cap: a serial walk of a store full of
   * cold-cache dead peers pays their HTTP timeouts one after another (worst
   * case cap × 15s), while a bounded concurrent walk pays one timeout window.
   */
  const CANDIDATE_CONCURRENCY = 6
  /** Concurrent card fetches in one directory sweep (cold-cache burst bound). */
  const SWEEP_CONCURRENCY = 6
  async function mapBounded<T, R>(items: readonly T[], limit: number, task: (item: T) => Promise<R>): Promise<R[]> {
    const results = new Array<R>(items.length)
    let next = 0
    const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
      while (next < items.length) {
        const index = next
        next += 1
        results[index] = await task(items[index] as T)
      }
    })
    await Promise.all(workers)
    return results
  }

  async function directoryPeerCandidates(fetch: (url: string) => Promise<A2aPeerCard | undefined>, team: string, failures: string[]): Promise<string[]> {
    // gh#8 (N9): a team name resolves only to hosts an operator linked —
    // the seeded subset of the peer store (config seeds, eviction-immune)
    // plus the delegate records (config-time operator acts). The
    // referral-learned tail stays in the store for probing and visibility,
    // but its self-published card claims no longer bind team names
    // (gh#8: a squatter two gossip hops away captured routes by naming
    // itself after the target). referralTeamResolution restores the legacy
    // whole-store basis for fleets mid-migration.
    const peers = config.referralTeamResolution === true ? peerStore.list() : [...new Set([...peerStore.listSeeded(), ...config.delegates.map(delegate => delegate.url)])]
    const candidates: string[] = []
    const cards = await mapBounded(peers, CANDIDATE_CONCURRENCY, async peer => ({ peer, card: await fetch(peer) }))
    for (const entry of cards) {
      if (entry.card === undefined) continue
      if (entry.card.team === team || (entry.card.sessionTeams ?? []).some(item => item.team === team)) candidates.push(entry.peer)
    }
    const resolutions = await mapBounded(peers, CANDIDATE_CONCURRENCY, async peer => ({ peer, outcome: await resolveZone(fetch, peer, team) }))
    for (const { peer, outcome } of resolutions) {
      if (outcome.ok) {
        if (!candidates.includes(outcome.url)) candidates.push(outcome.url)
        continue
      }
      if (outcome.reason === 'not-found' || outcome.reason === 'unreachable') continue
      failures.push(`${peer} ${outcome.reason}: ${outcome.detail}`)
    }
    return candidates
  }

  // ── Outbound transport face: the `nativeTeamsA2a` bridge ─────────────
  //
  // Contract: @nelsonlongxiang/dsh-native-teams/src/a2a-face.ts (0.14.0,
  // structural mirror in src/teams-bridge.ts). This plugin mounts the
  // implementation under the face's frozen service key — protocol
  // primitives live on the protocol face (three-party consensus), and
  // native-teams probes it presence-guarded (unmounted ⇒ local-only
  // routing, never a crash). The face ships only what this plugin already
  // does for a2a_route: resolve via the ONE directory walk (same matcher
  // submit uses — no drift-prone double implementation), submit via the
  // direct-route dispatcher (per-candidate async gate, failover included),
  // cancel via the cooperative stop-notice. It exposes nothing new — only
  // teams the tracked peer network already publishes resolve here.
  const bridgeFace: NativeTeamsBridgeFace = {
    resolve: async (handle) => {
      const failures: string[] = []
      const candidates = await directoryPeerCandidates(memoizedCardFetch(), handle, failures)
      if (candidates.length === 0) return undefined
      return { kind: 'node', hops: 1, url: candidates[0] }
    },
    submit: async (request, signal) => {
      const abort = signal ?? new AbortController().signal
      const failures: string[] = []
      const fetch = memoizedCardFetch()
      const candidates = await directoryPeerCandidates(fetch, request.handle, failures)
      if (candidates.length === 0) {
        throw new Error(`team "${request.handle}" is not published by any tracked peer${failures.length === 0 ? '' : ` (unresolved delegations: ${failures.join('; ')})`}`)
      }
      // The caller-born task id (B3): the orchestrator's dedup key IS the
      // wire task id, so the peer's echo correlates with the caller's ledger.
      const taskId = request.idempotencyKey !== undefined && request.idempotencyKey !== ''
        ? request.idempotencyKey
        : `direct-${Math.random().toString(16).slice(2, 10)}`
      // P2 receipt-callback: the receipt routes back to the submitting
      // session's own node team, but ONLY when that session is a joined
      // node. Without a joined parent there is no routable address that
      // means "this session" on the peer — omitting the callback keeps the
      // P1 behavior (the caller label cannot resolve on the peer, so the
      // receipt is lost honestly); falling back to `config.team` would be
      // actively harmful: a same-named peer resolves it LOCAL-first and the
      // receipt steers the peer's own initiator, never leaving that host.
      let callbackAddress: string | undefined
      if (request.callbackTarget) {
        const parent = request.callbackTarget.parentSessionId
        if (sessionNodes.has(parent) || joinedSessions.has(parent)) callbackAddress = `${config.team}/${id8(parent)}`
      }
      for (const candidate of candidates) {
        // Capability gate per candidate, like a2a_route's loop: a
        // delivery:async submit never dials a peer whose signed card does
        // not declare async — failover must not silently degrade into the
        // minutes-long blocking wait the gate exists to prevent.
        let peerAsync = false
        if (request.delivery === 'async') {
          const card = await fetch(candidate)
          peerAsync = (card?.capabilities as { async?: unknown } | undefined)?.async === true
        }
        const result = await dispatchPeerCandidate(candidate, request.handle, request.message, request.contextId, abort, session, request.delivery === 'async' && peerAsync, taskId, callbackAddress)
        if (!result.ok) {
          // Idempotency verdicts (B3) are terminal, not failover: a replay
          // says the prior attempt at THIS peer stays authoritative —
          // re-dispatching the same dedup key at another peer would execute
          // the task twice; a conflict is a caller bug (same key, different
          // payload) and must surface as a failure, not a redirect.
          if (result.code === WIRE_ERROR_REPLAY_REJECTED) {
            // async: acceptance IS the honest outcome — the submission is
            // fire-and-forget and the prior attempt settles via the receipt
            // contract.
            if (request.delivery === 'async') {
              return { kind: 'accepted', taskId, acceptedAt: new Date().toISOString(), contextId: request.contextId ?? '' }
            }
            // sync (W7 recovery table, S1): a sync caller cannot consume an
            // acceptance — its verdict contract needs round text, and the
            // handle-ack prose would settle a null verdict as a normal node.
            // Throw instead, and the frozen -32003 literal MUST ride the
            // message: structured codes have no survival channel through the
            // downstream submitFailedError wrap (message-only), so the
            // graph-loop classifier's probeText match on the code value is
            // the only programmatic channel (adjudicated exception to
            // "message 禁止下游解析").
            throw new Error(`A2A submit for "${request.handle}" replayed at the peer's idempotency ledger (task ${taskId} duplicate within the idempotency window, -32003: the prior attempt stays authoritative — fail-closed; outcome retrieval needs a query face)`)
          }
          if (result.code === WIRE_ERROR_IDEMPOTENCY_CONFLICT) {
            // -32002 literal on the message: same classification channel as the sync replay above.
            throw new Error(`A2A submit for "${request.handle}" conflicts at the peer's idempotency ledger (task ${taskId} reused with a different payload, -32002)`)
          }
          if (abort.aborted) break
          continue
        }
        trackOwedTask(taskId, request.handle, candidate, result, callbackAddress, briefOf(request.message))
        const contextId = request.contextId ?? (result.context_id !== '' ? result.context_id : `ctx-${Math.random().toString(16).slice(2, 10)}`)
        if (result.task_status === 'TASK_STATE_COMPLETED') {
          return { kind: 'completed', text: result.reply, taskId, contextId }
        }
        // DELIVERED / ABORTED_WAIT: the message is in and the receipt
        // contract carries the outcome — the face maps both to the
        // accepted shape (the submission stays visible in a2a_tasks).
        return { kind: 'accepted', taskId, acceptedAt: new Date().toISOString(), contextId }
      }
      throw new Error(`A2A submit for "${request.handle}" failed on every candidate`)
    },
    queryOutcome: async (request, signal) => {
      const abort = signal ?? new AbortController().signal
      if (request.taskId === '') return undefined
      const failures: string[] = []
      const fetch = memoizedCardFetch()
      const candidates = await directoryPeerCandidates(fetch, request.handle, failures)
      // No candidate to ask: no increment of information — undefined, never
      // a synthetic verdict.
      if (candidates.length === 0) return undefined
      let mismatch = false
      let answeredUnknown = false
      for (const candidate of candidates) {
        // A caller cancel mid-fan-out ends the probe: answers collected
        // before the abort must not aggregate into a verdict the caller
        // already walked away from.
        if (abort.aborted) return undefined
        // Recompute the fingerprint EXACTLY as the submit pass computed it:
        // the same shared implementation, and the same per-candidate async
        // gate (delivery async × that peer's declared capability). Sync
        // delivery — every graph-loop dispatch — is noWait:false throughout.
        let peerAsync = false
        if (request.delivery === 'async') {
          const card = await fetch(candidate)
          peerAsync = (card?.capabilities as { async?: unknown } | undefined)?.async === true
        }
        const fingerprint = peerPayloadFingerprint({ caller: session, message: request.message, noWait: request.delivery === 'async' && peerAsync, team: request.handle })
        const answer = await client.queryOutcome(candidate, request.taskId, fingerprint, abort)
        if (answer === undefined) continue // transport miss — probe the next candidate (read-only fan-out)
        if (!answer.found) {
          if (answer.reason === 'payload-mismatch') mismatch = true
          else answeredUnknown = true
          continue
        }
        return answer
      }
      // A mismatch anywhere wins the aggregation: the key exists at a peer
      // with a different payload — the most diagnostic negative there is.
      if (mismatch) return { found: false, reason: 'payload-mismatch' }
      if (answeredUnknown) return { found: false, reason: 'unknown-task' }
      return undefined
    },
    cancel: async (ref, reason) => {
      const taskId = ref.taskId
      if (taskId === undefined || taskId === '') return false
      const row = taskLedger.list().find(entry => entry.taskId === taskId)
      if (row === undefined) return false
      const notice = cancelNoticeText(taskId, reason)
      if (row.peer === 'local') {
        // Mirror the tasks/cancel control route: the cooperative stop-notice
        // steers the live local target, not just the ledger row. The target
        // resolution spans every kind the dispatcher can book — session
        // node, canvas team, bare process team — a row's team is whatever
        // the dispatch accepted, so the cancel must accept the same set.
        const live = resolveAgentForTeam(row.team)
          ?? canvasLiveAgent(parseCanvasTeamName(row.team))
          ?? (row.team === config.team ? liveAgent() : undefined)
        if (live !== undefined) {
          try {
            steerRelay(live, notice)
          } catch {
            // Bookkeeping below settles regardless; steering is best-effort.
          }
        }
      } else {
        // Peers do NOT track inbound task ids (the owed ledger's writer runs
        // on the dispatcher side), so the peer's ledger-cancel route would
        // deterministically answer 'unknown'. Drive the stop-notice through
        // the wire to the team itself instead. The notice deliberately
        // carries NO task_id: the original id is already claimed at the
        // peer's idempotency ledger with a different payload, so reusing it
        // would 409-conflict before any steer happens (a bodyless key is
        // always fresh there). The original id rides the notice text.
        const result = await client.routeDirect(row.peer, row.team, notice, undefined, undefined, session, true)
        if (!result.ok) {
          logger.warn(`a2a: cancel stop-notice for task ${taskId} failed to deliver to ${row.team}: ${result.error}`)
        }
      }
      return taskLedger.cancel(taskId, reason).outcome === 'cleared'
    },
  }
  ctx.reflect.provide(NATIVE_TEAMS_A2A_FACE_KEY, bridgeFace)

  ctx.tools.register(defineTool({
    name: 'a2a_status',
    description:
      'Read-only A2A network health: the tracked peer fleet with quality scores, routes currently in flight '
      + '(who is waiting on whom), and the recent routing activity ring (inbound and outbound outcomes). '
      + 'Includes the idempotency window occupancy (claims, replays, conflicts) behind the UNIQUE-ization '
      + 'traffic watch. '
      + 'While teamScopeInfo is on (default), peers / in-flight / activity narrow to the joined-team scope — local traffic and idempotency aggregates stay. '
      + 'Use it to observe an ongoing collaboration or diagnose delivery instead of re-routing.',
    parameters: {},
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          ok: { type: 'boolean', required: true },
          peers: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                url: { type: 'string', required: true },
                score: { type: 'number' },
              },
            },
          },
          inFlight: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                team: { type: 'string', required: true },
                peer: { type: 'string', required: true },
                startedAt: { type: 'number', required: true },
              },
            },
          },
          activity: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                ts: { type: 'number', required: true },
                dir: { type: 'string', required: true },
                team: { type: 'string', required: true },
                peer: { type: 'string', required: true },
                ok: { type: 'boolean', required: true },
              },
            },
          },
          idempotency: {
            type: 'object',
            additionalProperties: false,
            required: true,
            properties: {
              window: { type: 'number', required: true },
              cap: { type: 'number', required: true },
              pending: { type: 'number', required: true },
              settled: { type: 'number', required: true },
              claimsFresh: { type: 'number', required: true },
              replays: { type: 'number', required: true },
              conflicts: { type: 'number', required: true },
            },
          },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: [
          ...(value.inFlight.length === 0 ? [] : ['In flight:']),
          ...value.inFlight.map((route: { team: string; peer: string }) => `  → ${route.team} via ${route.peer === 'local' ? 'this host' : route.peer}`),
          `Peers (${String(value.peers.length)}):`,
          ...value.peers.map((peer: { url: string; score?: number }) => `  ${peer.url}${typeof peer.score === 'number' ? ` (score ${String(Math.round(peer.score))})` : ''}`),
          `Idempotency window: ${String(value.idempotency.window)}/${String(value.idempotency.cap)} (pending ${String(value.idempotency.pending)}, settled ${String(value.idempotency.settled)}) — claims ${String(value.idempotency.claimsFresh)}, replays ${String(value.idempotency.replays)}, conflicts ${String(value.idempotency.conflicts)}`,
          ...(value.activity.length === 0 ? [] : ['Recent routes:']),
          ...[...value.activity].reverse().slice(0, 10).map((entry: { dir: string; team: string; ok: boolean }) => `  ${entry.dir === 'in' ? '←' : '→'} ${entry.team} ${entry.ok ? 'ok' : 'failed'}`),
        ].join('\n'),
      }],
    },
    presentCall: () => ({ card: 'generic', title: 'A2A network status', kind: 'other', rawInput: null }),
    execute: async (_args, exec): Promise<{
      ok: boolean
      peers: { url: string; score?: number }[]
      inFlight: { team: string; peer: string; startedAt: number }[]
      activity: RouteActivityEntry[]
      idempotency: IdempotencyStats
    }> => {
      a2aJoinGateRefusal(exec)
      // S5 open plane: the unscoped snapshot, as before.
      if (!config.teamScopeInfo) {
        return {
          ok: true,
          peers: peerStore.list().map(url => ({ url, score: peerStore.score(url) })),
          inFlight: [...inFlightRoutes.values()].map(route => ({ team: route.team, peer: route.peer, startedAt: route.startedAt })),
          activity: recentActivity.slice(),
          idempotency: idempotencyStore.stats(),
        }
      }
      // S5 scoped plane: the tracked fleet narrows to peers whose verified
      // card serves a joined team (bounded-concurrency memoized fetch — a
      // warm sweep costs no extra round trips); routing facts keep
      // host-internal traffic (peer 'local') and drop remote rows whose
      // team is outside the scope, so cross-fleet collaborations stay
      // unread here. The idempotency aggregate is host machinery, not
      // attribution — it stays unscoped like the ledger it serves.
      const joined = joinedTeamScope()
      const visibleTeams = new Set(joined)
      for (const agent of sessionNodes.values()) {
        if (teamMemberships.teamsOf(String(agent.id)).some(team => joined.has(team))) visibleTeams.add(sessionTeamOf(agent))
      }
      // The host's own process-team face is host-internal ALWAYS — a
      // zero-roster host must still see inbound deliveries and outbound
      // attempts addressed to itself (review M2: gating this on
      // joined.size > 0 self-blinded exactly that traffic).
      visibleTeams.add(config.team)
      // G2 (review artifact 688c0354d3 v2): the host-synthetic face rows —
      // the /a2a/log telemetry records under the synthetic team label
      // 'log' (recordActivity('in', 'log', caller) on both admission
      // outcomes) — are THIS host's own face facts, not fleet observation.
      // Scoping filtered them like foreign traffic and hid the host's own
      // inbound log-face telemetry from its own supervisor; they pass.
      visibleTeams.add('log')
      const fetch = memoizedCardFetch()
      const peerRows = await mapBounded(peerStore.list(), SWEEP_CONCURRENCY, async (url: string): Promise<{ url: string; score?: number } | undefined> => {
        const card = await fetch(url)
        return card !== undefined && cardServesJoined(card, joined) ? { url, score: peerStore.score(url) } : undefined
      })
      const peers = peerRows.filter((row): row is { url: string; score?: number } => row !== undefined)
      const inScope = (entry: { team: string; peer: string }): boolean => entry.peer === 'local' || visibleTeams.has(entry.team)
      return {
        ok: true,
        peers,
        inFlight: [...inFlightRoutes.values()].map(route => ({ team: route.team, peer: route.peer, startedAt: route.startedAt })).filter(inScope),
        activity: recentActivity.filter(inScope),
        idempotency: idempotencyStore.stats(),
      }
    },
  }))

  /** Human duration for a ledger row: how long a task has been owed or took. */
  const describeAge = (ms: number): string => {
    const minutes = Math.floor(ms / 60_000)
    if (minutes < 1) return 'under a minute'
    if (minutes < 60) return `${String(minutes)}m`
    return `${String(Math.floor(minutes / 60))}h${minutes % 60 === 0 ? '' : `${String(minutes % 60)}m`}`
  }

  // S5 ruling: a2a_tasks stays unscoped — it is this host's own dispatch
  // ledger (pending / dead / archived), the receipt-reconciliation surface
  // for work this host itself routed, initiator-exempt dispatches included.
  // Its rows name teams this host already talked to; reading them back is
  // bookkeeping, not fleet disclosure.
  ctx.tools.register(defineTool({
    name: 'a2a_tasks',
    description:
      'Read-only three-tier ledger of routed A2A tasks: pending rows still owed a receipt, rows '
      + 'auto-dead-lettered past the stale TTL, and the bounded archive of correlated '
      + '`[A2A receipt] task <task_id>` outcomes. Use it to reconcile dispatched async work instead of '
      + 're-routing to ask for progress.',
    parameters: {},
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          ok: { type: 'boolean', required: true },
          tasks: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                taskId: { type: 'string', required: true },
                team: { type: 'string', required: true },
                peer: { type: 'string', required: true },
                startedAt: { type: 'number', required: true },
                contextId: { type: 'string' },
                brief: { type: 'string' },
                status: { type: 'string', required: true },
                deadAt: { type: 'number' },
                direction: { type: 'string', enum: ['inbound', 'outbound'] },
                receiptExpected: { type: 'boolean' },
                reason: { type: 'string', enum: ['fire-forget', 'unconsumed'] },
              },
            },
          },
          archive: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                taskId: { type: 'string', required: true },
                team: { type: 'string', required: true },
                startedAt: { type: 'number', required: true },
                resolvedAt: { type: 'number', required: true },
                summary: { type: 'string' },
                brief: { type: 'string' },
              },
            },
          },
          archivedTotal: { type: 'number', required: true },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.tasks.length === 0 && value.archivedTotal === 0
          ? 'No routed tasks are owed a receipt.'
          : [
            ...(() => {
              // C-ruling split (2026-09-01 decision seat): only young,
              // receipt-expected pending rows are settleable debt — the
              // stale tail is conversational noise waiting on the dead
              // TTL; count it, don't list it.
              const pending = value.tasks.filter((task: { status: string }) => task.status === 'pending')
              const settleable = pending.filter((task: { receiptExpected?: boolean; startedAt: number }) => task.receiptExpected !== false && Date.now() - task.startedAt < 60 * 60_000)
              const staleCount = pending.length - settleable.length
              return [
                ...(settleable.length > 0 ? ['Owed receipts:'] : []),
                ...settleable.map((task: { taskId: string; team: string; peer: string; startedAt: number; contextId?: string; brief?: string }) => {
                  const context = task.contextId === undefined || task.contextId === '' ? '' : `, follow-up context ${task.contextId}`
                  const brief = task.brief === undefined || task.brief === '' ? '' : ` — "${task.brief}"`
                  return `  - ${task.taskId}${brief} → ${task.team} (via ${task.peer === 'local' ? 'this host' : task.peer}), waiting ${describeAge(Date.now() - task.startedAt)}${context}`
                }),
                ...(staleCount > 0 ? [`Delivered conversationally without a formal receipt (${String(staleCount)}) — not debts; they auto-dead-letter at the stale TTL.`] : []),
              ]
            })(),
            ...(value.tasks.some((task: { status: string }) => task.status === 'dead') ? ['Dead-lettered (auto-flagged past the stale TTL; a revived target can still settle with a late receipt):'] : []),
            ...value.tasks.filter((task: { status: string }) => task.status === 'dead').map((task: { taskId: string; team: string; peer: string; startedAt: number; contextId?: string; brief?: string }) => {
              const context = task.contextId === undefined || task.contextId === '' ? '' : `, follow-up context ${task.contextId}`
              const brief = task.brief === undefined || task.brief === '' ? '' : ` — "${task.brief}"`
              return `  - ${task.taskId}${brief} → ${task.team} (via ${task.peer === 'local' ? 'this host' : task.peer}), dispatched ${describeAge(Date.now() - task.startedAt)} ago${context}`
            }),
            ...(value.archivedTotal > 0 ? [`Archived (${String(value.archivedTotal)}), most recent first:`] : []),
            ...value.archive.map((entry: { taskId: string; team: string; startedAt: number; resolvedAt: number; summary?: string; brief?: string }) => {
              const brief = entry.brief === undefined || entry.brief === '' ? '' : ` — "${entry.brief}"`
              return `  - ${entry.taskId}${brief} → ${entry.team}: after ${describeAge(entry.resolvedAt - entry.startedAt)}, ${entry.summary === undefined || entry.summary === '' ? 'resolved' : entry.summary}`
            }),
            ...(value.archivedTotal > value.archive.length ? [`  (+${String(value.archivedTotal - value.archive.length)} older not shown)`] : []),
          ].join('\n'),
      }],
    },
    presentCall: () => ({ card: 'generic', title: 'A2A task ledger', kind: 'other', rawInput: null }),
    execute: async (_args, exec): Promise<{ ok: boolean; tasks: { taskId: string; team: string; peer: string; startedAt: number; contextId?: string; brief?: string; status: 'pending' | 'dead'; deadAt?: number; reason?: 'fire-forget' | 'unconsumed'; direction?: 'inbound' | 'outbound'; receiptExpected?: boolean }[]; archive: { taskId: string; team: string; startedAt: number; resolvedAt: number; summary?: string; brief?: string }[]; archivedTotal: number }> => {
      a2aJoinGateRefusal(exec)
      const archiveAll = taskLedger.archive()
      return {
        ok: true,
        tasks: taskLedger.list().map(task => ({ ...task })),
        archive: archiveAll.slice(0, 5).map(({ taskId, team, startedAt, resolvedAt, summary, brief }) => ({ taskId, team, startedAt, resolvedAt, ...(summary !== undefined && summary !== '' ? { summary } : {}), ...(brief !== undefined ? { brief } : {}) })),
        archivedTotal: archiveAll.length,
      }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'a2a_probe',
    description:
      'Probe the tracked peer fleet for reachability and round-trip latency: one verified-card fetch per peer '
      + '(the same fetch discovery uses), reporting reachable peers with their team and latency and unreachable '
      + 'ones with the failure reason. Pass url to probe one target instead of the whole fleet. '
      + 'While teamScopeInfo is on (default), the sweep covers only peers serving a joined team, and a single URL is refused unless its verified card proves service. '
      + 'Use it before dispatching verification work or when routes fail over, instead of guessing which node is down.',
    parameters: {
      url: { type: 'string', description: 'Optional single peer base URL to probe; empty probes every tracked peer.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          ok: { type: 'boolean', required: true },
          results: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                url: { type: 'string', required: true },
                reachable: { type: 'boolean', required: true },
                ms: { type: 'number', description: 'Round-trip of the card fetch, reachable or not.' },
                team: { type: 'string', description: 'The team the peer publishes, when reachable.' },
                error: { type: 'string', description: 'Why the peer is unreachable.' },
              },
            },
          },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.results.length === 0
          ? 'No peers are tracked; add seeds or let referrals arrive.'
          : [
            `Fleet probe (${String(value.results.length)}): ${String(value.results.filter((row: { reachable: boolean }) => row.reachable).length)} reachable, ${String(value.results.filter((row: { reachable: boolean }) => !row.reachable).length)} down`,
            ...value.results.map((row: { url: string; reachable: boolean; ms?: number; team?: string; error?: string }) =>
              `  ${row.reachable ? '✓' : '✗'} ${row.url}${row.reachable ? ` (team ${String(row.team)}, ${String(row.ms)}ms)` : ` (${String(row.error)})`}`),
          ].join('\n'),
      }],
    },
    presentCall: args => ({ card: 'generic', title: args.url === undefined || args.url === '' ? 'Probe the A2A fleet' : `Probe A2A peer: ${args.url}`, kind: 'other', rawInput: args }),
    execute: async (args: { url?: string }, exec): Promise<{ ok: boolean; results: { url: string; reachable: boolean; ms: number; team?: string; error?: string }[] }> => {
      a2aJoinGateRefusal(exec)
      const probeOne = async (url: string): Promise<{ url: string; reachable: boolean; ms: number; team?: string; error?: string }> => {
        const startedAt = Date.now()
        const outcome = await client.fetchCardDetail(url)
        const ms = Date.now() - startedAt
        // The fetch is the probe: settling it moves the peer's quality score
        // and learns its referrals, exactly like a discovery sweep would,
        // while the outcome's stage names the failure for the report.
        const card = settlePeerCard(url, outcome)
        if (card !== undefined) {
          // gh#71 fix ①: a successful full-face fetch persists into the warm
          // cache — the probe is often the FIRST contact (no directory sweep
          // has run), and the state face's peerOrg reads exactly this cache.
          cardCache.set(url, { at: Date.now(), card })
          return { url, reachable: true, ms, team: card.team }
        }
        if (outcome.ok) return { url, reachable: false, ms, error: 'dropped: the card lists this node back as its own referral' }
        return outcome.stage === 'unreachable'
          ? { url, reachable: false, ms, error: `unreachable: ${outcome.detail}` }
          : { url, reachable: false, ms, error: `rejected: ${outcome.reason} card` }
      }
      // S5: a reachability report is fleet disclosure too. The sweep probes
      // only peers whose verified card serves a joined team (memoized —
      // warm cards cost nothing); a single-URL probe needs proof of service
      // — a FRESH card, or a stale cached one: a peer that once served a
      // joined team and is now down gets the normal down report (that
      // reachability fact belongs to the team), while a URL that never
      // proved service is refused without a probe (its reachability is
      // exactly the fact scoping withholds).
      const joined = joinedTeamScope()
      const fetch = memoizedCardFetch()
      const serves = async (url: string): Promise<boolean> => {
        const card = await fetch(url)
        return card !== undefined && cardServesJoined(card, joined)
      }
      if (args.url !== undefined && args.url !== '') {
        if (config.teamScopeInfo && !(await serves(args.url))) {
          const stale = cardCache.get(args.url)?.card
          if (stale !== undefined && cardServesJoined(stale, joined)) {
            // Was serving, now unverifiable fresh — probe and report the
            // down state through the normal path.
            return { ok: true, results: await Promise.all([args.url].map(probeOne)) }
          }
          return { ok: true, results: [{ url: args.url, reachable: false, ms: 0, error: stale === undefined
            ? 'refused (not probed): teamScopeInfo on — no verified card for this URL proves service to a joined team'
            : 'refused (not probed): teamScopeInfo on — this URL\'s verified card shows no team joined by this host\'s nodes' }] }
        }
        return { ok: true, results: await Promise.all([args.url].map(probeOne)) }
      }
      const targets = config.teamScopeInfo
        ? await mapBounded(peerStore.list(), SWEEP_CONCURRENCY, async (url: string) => await serves(url) ? url : undefined).then(rows => rows.filter((url): url is string => url !== undefined))
        : peerStore.list()
      // Promise.all keeps the report in the store's preference order.
      return { ok: true, results: await Promise.all(targets.map(probeOne)) }
    },
  }))

  /**
   * Steering targets awaiting a final reply, keyed by agent session id. Each
   * entry remembers the request id to answer and the log length when the
   * message was steered, so the flush reads only fresh assistant output.
   */
  interface FinalWaiter {
    /** @param placeholder - true when the text is a host-authored
     * stand-in (flush timeout, dead session), NOT the session's product. */
    readonly answer: (text: string, placeholder?: boolean) => void
    readonly sinceEvents: number
    timeoutDisposer?: () => void
  }
  const pendingFinals = new Map<string, FinalWaiter[]>()
  const armFlushTimeout = (agentId: string, waiter: FinalWaiter): (() => void) => {
    return ctx.timer.timeout(() => {
      const entries = pendingFinals.get(agentId)
      if (entries === undefined) return
      const kept = entries.filter(entry => entry !== waiter)
      if (kept.length === 0) pendingFinals.delete(agentId)
      else pendingFinals.set(agentId, kept)
      waiter.answer('The DSH session produced no final reply within the configured window.', true)
    }, config.flushTimeoutMs)
  }

  function flushFinals(agentId: string): void {
    const entries = pendingFinals.get(agentId)
    if (entries === undefined || entries.length === 0) return
    const agent = ctx.get('agents')?.get(SessionId(agentId))
    if (agent === undefined) {
      for (const entry of entries) {
        entry.timeoutDisposer?.()
        entry.answer('The target DSH session is no longer live.', true)
      }
      pendingFinals.delete(agentId)
      return
    }
    const events = sessionEventsOf(agent)
    const floor = Math.min(...entries.map(entry => entry.sinceEvents))
    let reply = ''
    for (let index = events.length - 1; index >= floor; index--) {
      const event = events[index]
      if (event === undefined || event.type !== 'assistant/message') continue
      const content = event.data?.message?.content
      if (content === undefined) continue
      reply = content
        .filter((block): block is { type: 'text'; text: string } => block.type === 'text' && typeof block.text === 'string')
        .map(block => block.text)
        .join('\n')
      break
    }
    if (reply !== '') {
      for (const entry of entries) entry.answer(reply)
      pendingFinals.delete(agentId)
    }
  }

  // Every inbound route is a direct route (final semantics), so the idle
  // flush listens unconditionally — an empty pendingFinals map makes it a
  // no-op. Node facts need no refresh here: the card serves them fresh at
  // read time.
  ctx.on('agent/status', (payload) => {
    if (payload.status === 'idle') flushFinals(String(payload.agent.id))
  })
}

/**
 * Load the node's Ed25519 private key, generating and persisting it on first
 * use. The key IS the node's card identity: a persisted key keeps signatures
 * verifiable across restarts, which is why storage lands with the announce
 * config surface rather than after it.
 * @param path - absolute PEM path (`<dsh-home>/a2a/node-key.pem`).
 * @returns the private key used to sign every published card.
 */
function loadOrCreateNodeKey(path: string): ReturnType<typeof generateKeyPairSync>['privateKey'] {
  if (existsSync(path)) {
    return createPrivateKey(readFileSync(path, 'utf8'))
  }
  const { privateKey } = generateKeyPairSync('ed25519')
  mkdirSync(dirname(path), { recursive: true })
  writeFileSync(path, privateKey.export({ format: 'pem', type: 'pkcs8' }), { mode: 0o600 })
  return privateKey
}

/**
 * Derive the default wire session label from a per-home node id: eight hex
 * characters generated once, so two deployments mounting defaults do not
 * collide while a persisted home keeps the label stable across restarts.
 * @param home - resolved harness home.
 * @returns the derived session label (`dsh-host-<8 hex>`).
 */
function deriveSession(home: string): string {
  const path = join(home, 'a2a', 'node-id')
  if (existsSync(path)) return `dsh-host-${readFileSync(path, 'utf8').trim()}`
  const id = randomBytes(4).toString('hex')
  mkdirSync(dirname(path), { recursive: true })
  writeFileSync(path, `${id}\n`, { mode: 0o600 })
  return `dsh-host-${id}`
}
