/**
 * CLI 户口登记处 (gh#45, owner rulings 2026-10-24):
 *   ① handle = <agent-name>/<uuid·8B (16 hex)> — the name is custom, the
 *      suffix is forced 16-hex by shape gate;
 *   ② one key, multiple registrations — v1: the local home host;
 *   ③ deposit TTL: default AND max 4h — expiry auto-deregisters (the CLI
 *      vanishes from the card face and the directory; re-publish returns).
 *
 * The deposit is the CLI's "household registration": the home host serves
 * the CLI's SIGNED card at /a2a/cli/<handle>/.well-known/agent-card.json
 * (an OriginClaim fetch of the CLI envelope lands exactly there), lists
 * the handle in its own card's sessionTeams (so the whole fleet sees the
 * CLI as a member card — draggable into canvas teams = the operator link),
 * and holds a mailbox for inbound deliveries (receipts land here; the CLI
 * polls while alive).
 */
import { createPublicKey, randomUUID, verify } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { verifyCard } from './card.ts'
import type { ReceiptDisposition } from './receipt.ts'
import type { AdmissionRule, AuthProof } from './task-auth.ts'

/** Owner ruling ③: the default AND maximum online window. */
export const CLI_DEPOSIT_TTL_MS = 4 * 60 * 60 * 1000

/**
 * gh#47 tombstone bound: expired deposits stay visible as OFFLINE rows
 * (newest TOMBSTONE_CAP keep their handle/name so team refs never dangle
 * silently) — the owner manages CLI nodes like session nodes.
 */
export const CLI_TOMBSTONE_CAP = 16

/** Owner ruling ①: <agent-name>/<uuid·8B>. The name is [a-z0-9-]{1,32}. */
export const CLI_HANDLE_RE = /^([a-z0-9-]{1,32})\/([0-9a-f]{16})$/

/** One deposited CLI identity. */
export interface CliDeposit {
  readonly handle: string
  /** The bare agent-name zone (card.team). */
  readonly name: string
  /** The CLI's signed card, verbatim wire JSON (served back as-is). */
  readonly cardJson: string
  readonly depositedAt: number
  readonly expiresAt: number
  /**
   * gh#47 tombstone: set when the deposit expired — the row stays (offline)
   * so the directory/board keeps the member visible and team refs never
   * dangle silently. A re-publish (same handle, same key) un-tombstones.
   */
  expiredAt?: number
}

/** One mailbox entry for a deposited handle. */
export interface CliMail {
  readonly at: number
  readonly from: string
  readonly text: string
  /**
   * gh#113: the entry's place in its handle's mailbox — 1, 2, 3, … in
   * arrival order, never reused, kept across restarts. A reader that keeps
   * the last seq it read sees exactly what is new, and any gap below
   * `oldest_seq` is mail the cap pushed out before it was read.
   */
  readonly seq: number
  /** gh#113: set when `text` was cut to MAILBOX_TEXT_CAP; `chars` is the original length. */
  readonly truncated?: true
  readonly chars?: number
  /**
   * #298: a receipt for a forward this host already answered synchronously — the CLI got the reply on the
   * HTTP answer, so this copy is a duplicate. Kept in full (never dropped); readers may fold it.
   */
  readonly dup?: 'sync-answered'
  /**
   * superagent p1-context-read: the delivery's task and conversation, as the host saw them —
   * `a2a thread <context_id>` reads a conversation back from these. Absent on rows mailed
   * before the field existed, and on deliveries that carried none.
   */
  readonly task_id?: string
  readonly context_id?: string
  /** p1-receipt-cmd: a receipt's envelope disposition (result / attention), so a reader branches on a field, never the text. */
  readonly disposition?: ReceiptDisposition
  /**
   * p1-mail-proof (S18): how the host proved the caller when it took the delivery — the verdict the
   * wire face already writes into the text header, as a field, so a reader never parses the text.
   * The local face is in-process. Absent on rows mailed before the field existed.
   */
  readonly proof?: AuthProof
  /** p1-mail-proof: the task id this row's receipt answers, when the row is a receipt. */
  readonly receipt_for?: string
  /**
   * superagent p1-mail-admission: the admission rule the host matched when it took the delivery (task-auth.ts
   * AdmissionRule) — the name only, never its basis, so a reader learns how the caller was let in without the topology.
   */
  readonly admission?: AdmissionRule
}

/** p1-mail-proof: the AuthProof values a restored row may carry (task-auth.ts); anything else is dropped. */
const MAIL_PROOFS = ['origin-claim', 'claim-mismatch', 'legacy-window', 'unbound', 'cli-identity', 'in-process', 'none'] as const satisfies readonly AuthProof[]
/**
 * p1-mail-admission: the AdmissionRule names a restored row may carry (task-auth.ts); anything else is dropped. Kept
 * literal like MAIL_PROOFS (no runtime import back into task-auth); a unit test pins it to task-auth's full set.
 */
export const MAIL_ADMISSIONS = ['scope-off', 'host-face', 'local-exempt', 'roster-shared', 'canvas-shared', 'remote-ref-samezone', 'remote-ref-foreign', 'remote-ref-cli', 'peer-org', 'node-fact', 'cli-deposit'] as const satisfies readonly AdmissionRule[]

/**
 * Both lists cover their whole union: `satisfies` above keeps each entry a real value; these fail to compile when
 * task-auth gains a proof or a rule the list does not carry (which a restored row would then silently lose).
 */
type Missing<All, Listed> = Exclude<All, Listed>
const MAIL_PROOFS_COMPLETE: Missing<AuthProof, typeof MAIL_PROOFS[number]> extends never ? true : never = true
const MAIL_ADMISSIONS_COMPLETE: Missing<AdmissionRule, typeof MAIL_ADMISSIONS[number]> extends never ? true : never = true
void MAIL_PROOFS_COMPLETE; void MAIL_ADMISSIONS_COMPLETE

/** p1-context-read: the task and conversation a mailbox delivery belongs to (empty strings are dropped). */
export interface CliMailThread {
  readonly taskId?: string
  readonly contextId?: string
  readonly disposition?: ReceiptDisposition
  readonly proof?: AuthProof
  readonly receiptFor?: string
  readonly admission?: AdmissionRule
}

/** gh#113: one mailbox read — the rows plus what a reader needs to notice loss. */
export interface CliMailbox {
  /** Newest first, as before gh#113. */
  readonly mail: readonly CliMail[]
  /** Changes when the store starts empty (no snapshot, or a corrupt one): seq restarted at 1. */
  readonly epoch: string
  /** The seq the next delivery will get; `next_seq - 1` is the newest ever written. */
  readonly next_seq: number
  /** The oldest seq still held, or `next_seq` when the mailbox is empty. */
  readonly oldest_seq: number
  /** Entries the cap pushed out for this handle, all time. */
  readonly dropped: number
}

interface Snapshot {
  deposits: CliDeposit[]
  mailbox: Record<string, CliMail[]>
  /** gh#113: absent in pre-gh#113 snapshots. */
  epoch?: string
  nextSeq?: Record<string, number>
  dropped?: Record<string, number>
  truncated?: Record<string, number>
}

/** A fresh mailbox epoch: any reader's seq cursor from another epoch is void. */
const newEpoch = (): string => randomUUID().replace(/-/g, '').slice(0, 12)

const isSeq = (n: unknown): n is number => typeof n === 'number' && Number.isInteger(n) && n >= 1

/** p1-mail-proof: a damaged snapshot never promotes a row's proof — an unknown value (or a non-string receipt_for) is dropped. */
function sanitizeMail(m: CliMail): CliMail {
  const { proof, receipt_for: receiptFor, admission, ...rest } = m as CliMail & { proof?: unknown; receipt_for?: unknown; admission?: unknown }
  return {
    ...rest,
    ...(typeof proof === 'string' && (MAIL_PROOFS as readonly string[]).includes(proof) ? { proof: proof as AuthProof } : {}),
    ...(typeof receiptFor === 'string' && receiptFor !== '' ? { receipt_for: receiptFor } : {}),
    // p1-mail-admission: likewise an admission value outside the rule set is dropped, never kept as a link.
    ...(typeof admission === 'string' && (MAIL_ADMISSIONS as readonly string[]).includes(admission) ? { admission: admission as AdmissionRule } : {}),
  }
}

/** The public key a stored card was published with ('' when it does not parse: never equal to a verified key, so fail-closed). */
const publicKeyOf = (cardJson: string): string => {
  try {
    const key = (JSON.parse(cardJson) as { publicKey?: unknown } | null)?.publicKey
    return typeof key === 'string' ? key : ''
  } catch {
    return ''
  }
}

/**
 * superagent p1-mail-admission (M-2): the bytes a CLI identity signs to ask its home host how a caller would be admitted
 * to it. The CLI builds the same array (cli/a2a.mjs); a unit test pins the two together.
 */
export const admissionQueryPayload = (handle: string, caller: string, ingress: 'local' | 'wire', ts: number): string =>
  JSON.stringify(['a2a-admission', handle, caller, ingress, ts])

/** How far an admission query's timestamp may stray from this host's clock (the OriginClaim window). */
export const ADMISSION_QUERY_WINDOW_MS = 300_000

/**
 * Whether an admission query really comes from `handle` itself: signed with the key its LIVE deposit was published
 * with, fresh, over exactly these fields. Anything else is refused — so a holder of the control key cannot ask about
 * another identity's links (global review of the p1-mail-admission design).
 */
export function verifyAdmissionQuery(cardJson: string | undefined, q: { handle: string; caller: string; ingress: 'local' | 'wire'; ts: number; sig: string }, now: number): boolean {
  if (cardJson === undefined || !Number.isFinite(q.ts) || Math.abs(now - q.ts) > ADMISSION_QUERY_WINDOW_MS || q.sig === '') return false
  const key = publicKeyOf(cardJson)
  if (key === '') return false
  try {
    const publicKey = createPublicKey({ key: Buffer.from(key, 'base64'), format: 'der', type: 'spki' })
    return verify(null, Buffer.from(admissionQueryPayload(q.handle, q.caller, q.ingress, q.ts)), publicKey, Buffer.from(q.sig, 'base64'))
  } catch {
    return false
  }
}

export const MAILBOX_CAP = 64
export const MAILBOX_TEXT_CAP = 4000

export class CliDepositStore {
  private deposits = new Map<string, CliDeposit>()
  private mailbox = new Map<string, CliMail[]>()
  private nextSeq = new Map<string, number>()
  private dropped = new Map<string, number>()
  private truncated = new Map<string, number>()
  private epoch = newEpoch()
  /** gh#113 review: true while the last write failed — the epoch on disk no longer matches memory. */
  private unpersisted = false
  private now: () => number

  constructor(private readonly path: string, options?: { now?: () => number }) {
    this.now = options?.now ?? (() => Date.now())
    this.restore()
  }

  /** Deposit (or refresh) one CLI card. TTL is clamped to the 4h ruling. */
  deposit(cardJson: string): { ok: true; handle: string; expiresAt: number } | { ok: false; error: string } {
    let parsed: unknown
    try {
      parsed = JSON.parse(cardJson)
    } catch {
      return { ok: false, error: 'card is not JSON' }
    }
    const verdict = verifyCard(parsed, this.now())
    if (!verdict.ok) return { ok: false, error: `card verification failed (${verdict.reason})` }
    if (typeof verdict.card.team !== 'string' || !CLI_HANDLE_RE.test(verdict.card.team)) {
      return { ok: false, error: `card.team must be the CLI handle <agent-name>/<uuid16hex>, got "${String(verdict.card.team)}"` }
    }
    const handle = verdict.card.team
    const name = CLI_HANDLE_RE.exec(handle)![1]!
    if (verdict.card.team !== `${name}/${CLI_HANDLE_RE.exec(handle)![2]}`) return { ok: false, error: 'handle mismatch' }
    const ttl = Math.min(CLI_DEPOSIT_TTL_MS, CLI_DEPOSIT_TTL_MS)
    const at = this.now()
    const prior = this.deposits.get(handle)
    // gh#137: same handle, same key. A live deposit or a tombstone pins the
    // handle to the key it was published with; a different key is refused
    // until the old deposit is revoked explicitly (a2a revoke), so a swap is
    // a visible act, never a silent overwrite (an `init --force` collision).
    if (prior !== undefined && publicKeyOf(prior.cardJson) !== verdict.card.publicKey) {
      return { ok: false, error: `handle ${handle} is held by another key (${prior.expiredAt !== undefined ? 'offline' : 'live'} deposit) — revoke it first (a2a revoke), then publish` }
    }
    // gh#47: a re-publish un-tombstones (expiredAt clears) and refreshes
    // the card — same handle, same key, back online.
    const row: CliDeposit = { handle, name, cardJson, depositedAt: at, expiresAt: at + ttl }
    this.deposits.set(handle, row)
    this.pruneTombstones()
    this.persist()
    return { ok: true, handle, expiresAt: row.expiresAt }
  }

  revoke(handle: string): boolean {
    const had = this.deposits.delete(handle)
    if (had) this.persist()
    return had
  }

  /** Active deposits (sweeping expired ones — ruling ③ auto-deregister). */
  /** LIVE deposits only (tombstones excluded — the control list is the
   *  online roster; offline rows ride directoryRows for the board). */
  list(): readonly CliDeposit[] {
    this.sweep()
    return [...this.deposits.values()].filter(row => row.expiredAt === undefined && row.expiresAt > this.now())
  }

  get(handle: string): CliDeposit | undefined {
    const row = this.deposits.get(handle)
    if (row === undefined) return undefined
    if (row.expiresAt <= this.now()) {
      if (row.expiredAt === undefined) {
        // gh#47: expire into a TOMBSTONE (offline) instead of deleting —
        // the handle stays visible; only the LIVE row is gone.
        this.markExpired(row)
      }
      return undefined
    }
    return row
  }

  /** Card-serve rows: LIVE deposits only (an expired card 404s). */
  cardRows(): Array<{ team: string; name: string; description: string }> {
    return this.list().filter(row => row.expiredAt === undefined && row.expiresAt > this.now())
      .map(row => ({ team: row.handle, name: row.name, description: `cli — deposited identity (no wake; mailbox)${row.expiredAt !== undefined ? ' [offline]' : ''}` }))
  }

  /**
   * gh#47 directory rows: LIVE + TOMBSTONE (offline) — the board renders
   * offline member cards grayed but PRESENT, so a canvas ref to an expired
   * CLI never dangles silently. Re-publish un-tombstones (same handle).
   */
  directoryRows(): Array<{ team: string; name: string; description: string; offline: boolean }> {
    this.sweep()
    const rows = [...this.deposits.values()]
      .map(row => row.expiresAt <= this.now()
        ? (row.expiredAt === undefined ? this.markExpired(row) : row)
        : row)
    return rows.map(row => ({
      team: row.handle,
      name: row.name,
      description: row.expiredAt !== undefined
        ? 'cli — offline (deposit expired; re-publish to return)'
        : 'cli — deposited identity (no wake; mailbox)',
      offline: row.expiredAt !== undefined,
    }))
  }

  /**
   * superagent p1-mailbox-owes (S33): the live deposit's signed card declares it owes a receipt for what its mailbox
   * takes (`capabilities.owes === true`). Read from the verified card kept verbatim, so it survives a restart and a
   * re-publish without the flag withdraws it.
   */
  owes(handle: string): boolean {
    const row = this.get(handle)
    if (row === undefined) return false
    try {
      const capabilities = (JSON.parse(row.cardJson) as { capabilities?: unknown } | null)?.capabilities
      return typeof capabilities === 'object' && capabilities !== null && (capabilities as { owes?: unknown }).owes === true
    } catch {
      return false
    }
  }

  /** Add one row to `handle`'s mailbox; returns the rows the cap pushed out by this delivery (oldest last), for their owed books. */
  mail(handle: string, from: string, text: string, dup?: 'sync-answered', thread?: CliMailThread): readonly CliMail[] {
    const list = this.mailbox.get(handle) ?? []
    const seq = this.nextSeq.get(handle) ?? 1
    this.nextSeq.set(handle, seq + 1)
    const cut = text.length > MAILBOX_TEXT_CAP
    if (cut) this.truncated.set(handle, (this.truncated.get(handle) ?? 0) + 1)
    list.unshift({ at: this.now(), from, text: cut ? text.slice(0, MAILBOX_TEXT_CAP) : text, seq, ...(cut ? { truncated: true as const, chars: text.length } : {}), ...(dup !== undefined ? { dup } : {}),
      ...(thread?.taskId ? { task_id: thread.taskId } : {}), ...(thread?.contextId ? { context_id: thread.contextId } : {}),
      ...(thread?.disposition !== undefined ? { disposition: thread.disposition } : {}),
      ...(thread?.proof !== undefined ? { proof: thread.proof } : {}), ...(thread?.receiptFor ? { receipt_for: thread.receiptFor } : {}),
      ...(thread?.admission !== undefined ? { admission: thread.admission } : {}) })
    // gh#113: the cap still holds, but what it pushes out is counted, not lost silently.
    if (list.length > MAILBOX_CAP) this.dropped.set(handle, (this.dropped.get(handle) ?? 0) + list.length - MAILBOX_CAP)
    this.mailbox.set(handle, list.slice(0, MAILBOX_CAP))
    this.persist()
    return list.slice(MAILBOX_CAP)
  }

  readMail(handle: string): readonly CliMail[] {
    return [...(this.mailbox.get(handle) ?? [])]
  }

  /** gh#113: the mailbox with its seq bounds and loss counter; `afterSeq` keeps only newer rows. */
  readMailbox(handle: string, afterSeq?: number): CliMailbox {
    const all = this.mailbox.get(handle) ?? []
    const next = this.nextSeq.get(handle) ?? 1
    return {
      mail: afterSeq === undefined ? [...all] : all.filter(m => m.seq > afterSeq),
      epoch: this.epoch,
      next_seq: next,
      oldest_seq: all.length === 0 ? next : Math.min(...all.map(m => m.seq)),
      dropped: this.dropped.get(handle) ?? 0,
    }
  }

  /** gh#113: fleet-wide loss counters for the state face (the team verifier reads them). */
  mailStats(): { dropped: number; truncated: number } {
    let dropped = 0
    let truncated = 0
    for (const n of this.dropped.values()) dropped += n
    for (const n of this.truncated.values()) truncated += n
    return { dropped, truncated }
  }

  private sweep(): void {
    const now = this.now()
    for (const [handle, row] of this.deposits) {
      if (row.expiresAt <= now && row.expiredAt === undefined) this.markExpired(row)
    }
  }

  /** Mark one row expired (tombstone) and persist. */
  private markExpired(row: CliDeposit): CliDeposit {
    const tomb: CliDeposit = { ...row, expiredAt: this.now() }
    this.deposits.set(tomb.handle, tomb)
    this.pruneTombstones()
    this.persist()
    return tomb
  }

  /** Keep at most TOMBSTONE_CAP offline rows — oldest evictions fall off. */
  private pruneTombstones(): void {
    const tombstones = [...this.deposits.values()].filter(row => row.expiredAt !== undefined)
    if (tombstones.length <= CLI_TOMBSTONE_CAP) return
    tombstones.sort((a, b) => (a.expiredAt ?? 0) - (b.expiredAt ?? 0))
    for (let i = 0; i < tombstones.length - CLI_TOMBSTONE_CAP; i += 1) this.deposits.delete(tombstones[i]!.handle)
  }

  private persist(): void {
    const mailbox: Record<string, CliMail[]> = {}
    for (const [handle, list] of this.mailbox) mailbox[handle] = [...list]
    const snapshot: Snapshot = {
      deposits: [...this.deposits.values()], mailbox, epoch: this.epoch,
      nextSeq: Object.fromEntries(this.nextSeq), dropped: Object.fromEntries(this.dropped), truncated: Object.fromEntries(this.truncated),
    }
    try {
      mkdirSync(join(this.path, '..'), { recursive: true })
      writeFileSync(this.path, JSON.stringify(snapshot), 'utf8')
      this.unpersisted = false
    } catch {
      // Persistence stays best-effort (re-publishes self-heal), but a seq
      // handed out from memory must never be handed out again after a
      // restart under the same epoch: the disk still holds the older
      // nextSeq, so a reader holding a newer seq would skip new mail.
      // Leave the epoch on disk behind — readers of this memory-only run
      // fall back to their `at` cursor after a restart (gh#113 review P2).
      if (!this.unpersisted) {
        this.unpersisted = true
        this.epoch = newEpoch()
      }
    }
  }

  private restore(): void {
    if (this.path === '' || !existsSync(this.path)) return
    try {
      const snapshot = JSON.parse(readFileSync(this.path, 'utf8')) as Partial<Snapshot>
      for (const row of snapshot.deposits ?? []) {
        if (typeof row?.handle === 'string' && typeof row.cardJson === 'string' && typeof row.expiresAt === 'number') {
          this.deposits.set(row.handle, row as CliDeposit)
        }
      }
      // The epoch is kept only when the seq record that goes with it survived:
      // an epoch without nextSeq would restart seq at 1 under the same name.
      let keepEpoch = typeof snapshot.epoch === 'string' && snapshot.epoch !== '' && snapshot.nextSeq !== null && typeof snapshot.nextSeq === 'object'
      const counts = (record: unknown, into: Map<string, number>): boolean => {
        let clean = true
        for (const [handle, n] of Object.entries(record ?? {})) {
          if (typeof n === 'number' && Number.isInteger(n) && n >= 0) into.set(handle, n)
          else clean = false
        }
        return clean
      }
      // A nextSeq value we cannot read, or a mailbox handle with no nextSeq,
      // could hand out seq again under the kept epoch: start a new one.
      if (!counts(snapshot.nextSeq, this.nextSeq)) keepEpoch = false
      for (const handle of Object.keys(snapshot.mailbox ?? {})) if (!this.nextSeq.has(handle)) keepEpoch = false
      counts(snapshot.dropped, this.dropped)
      counts(snapshot.truncated, this.truncated)
      let renumbered = false
      for (const [handle, list] of Object.entries(snapshot.mailbox ?? {})) {
        if (!Array.isArray(list)) continue
        const rows = list.filter((m): m is CliMail => m !== null && typeof m === 'object').map(sanitizeMail)
        const seqs = rows.map(m => m.seq)
        const sound = seqs.every(isSeq) && new Set(seqs).size === seqs.length &&
          seqs.every((n, i) => i === 0 || n < seqs[i - 1]!) && (this.nextSeq.get(handle) ?? 0) > Math.max(0, ...seqs)
        if (sound) { this.mailbox.set(handle, rows); continue }
        // A pre-gh#113 snapshot (no seq), or one whose seqs are not unique
        // positive integers in newest-first order: number the whole handle
        // afresh, oldest first, under a new epoch.
        renumbered = true
        const numbered = [...rows].reverse().map((m, i) => ({ ...m, seq: i + 1 })).reverse()
        this.mailbox.set(handle, numbered)
        this.nextSeq.set(handle, numbered.length + 1)
      }
      if (renumbered) keepEpoch = false
      if (keepEpoch) this.epoch = snapshot.epoch!
      this.sweep()
      // Pin the epoch (and any renumbering) on disk now, so it does not change on every start.
      if (!keepEpoch) this.persist()
    } catch {
      // corrupt file: start empty (re-publish heals)
    }
  }
}
