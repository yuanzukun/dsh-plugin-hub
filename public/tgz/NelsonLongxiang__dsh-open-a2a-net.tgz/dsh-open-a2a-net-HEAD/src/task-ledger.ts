/**
 * Persisted async-task ledger (`<dsh-home>/a2a/tasks.json`). The receipt
 * contract makes the target answer a fire-and-forget route with a message
 * starting `[A2A receipt] task <task_id> <outcome summary>`, but the caller
 * had no book to reconcile against — pending tasks were unqueryable and a
 * restart forgot them all. The ledger keeps one record per routed task that
 * is still owed a reply, correlates the receipt by its task id, and persists
 * so a node restart does not orphan the reconciliation.
 *
 * Three-tier book (v0.5.29): the owed book holds only unsettled rows —
 * `pending`, or `dead` once a row sits past {@link TASK_STALE_TTL_MS} (swept
 * lazily on every entry point, never timer-driven — this host restarts too
 * often for in-memory timers). Dead rows exit the owed view and disarm the
 * async nudge via {@link TaskLedger.isPending}, yet still settle on a late
 * receipt. Every settled row leaves the owed book for the bounded archive,
 * so resolution history stops being silently evicted by the {@link TASK_CAP}
 * slice (the evidence-loss defect behind the "the ledger keeps growing"
 * illusion: settlements vanished while debts piled up).
 * @module @nelsonlongxiang/dsh-open-a2a-net/task-ledger
 */

import { parseAuthorization, type AuthProof, type ChainRole, type SettlementReason, type SettlementVerdict, type TaskAuthorization } from './task-auth.ts'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname } from 'node:path'
import { parseReceipt, RECEIPT_OUTCOMES, type ReceiptOutcomeV2 } from './receipt.ts'

/**
 * Caller-ended summaries (abandon / cancel) share one isolation law: late
 * receipts never rewrite the verdict — they only stamp lateReceiptAt, and
 * the projected outcome collapses to 'abandoned'.
 */
const CALLER_ENDED_PREFIX = /^caller-(abandoned|cancelled)/

/** Hard cap on the owed book (pending + dead-lettered rows, most recent first). */
export const TASK_CAP = 64

/** Hard cap on the settled archive (most recent kept). */
export const ARCHIVE_CAP = 64

/** Longest receipt summary kept on a record (multi-line outcomes collapse). */
export const SUMMARY_CAP = 200

/**
 * Longest dispatch brief kept per row. A ledger row without its payload is
 * unreadable to supervision — "direct-8f3a1c2b → dsh/ec4ce7f8, 3h old" says
 * nothing about whether to nudge, abandon, or read the receipt. The brief is
 * the first non-empty line of the message, capped; the full body never enters
 * the ledger (it can be arbitrarily large and may quote another session's log).
 */
export const BRIEF_CAP = 120

/** Reduce a dispatch body to one readable line: first non-empty line, collapsed, capped. */
export function briefOf(message: string | undefined): string | undefined {
  if (message === undefined) return undefined
  for (const raw of message.split('\n')) {
    const line = raw.trim().replace(/\s+/g, ' ')
    if (line !== '') return line.length <= BRIEF_CAP ? line : `${line.slice(0, BRIEF_CAP - 1)}…`
  }
  return undefined
}

/**
 * Age at which an unsettled task auto-dead-letters. A dead row exits the
 * owed view, disarms its async-nudge retry (a cold session cannot consume a
 * re-steer anyway), and still accepts a late receipt from a revived target.
 * Injectable per instance so tests can use short windows; sweeping stays
 * lazy — every read/write entry point sweeps first.
 */
export const TASK_STALE_TTL_MS = 24 * 60 * 60_000

/**
 * The receipt correlation template now lives in `receipt.ts` (shared codec
 * for header + v2 envelope line). This ledger consumes `parseReceipt` so
 * human summaries and machine projections can never drift apart again.
 */

/** Lifecycle of a tracked outbound task inside the owed book. */
export type TaskStatus = 'pending' | 'dead'

/** F5 layer-3: why a dead row aged out (stamped by the sweep at flip time). */
export type DeadReason = 'fire-forget' | 'unconsumed'

/** gh#31: which archive path ended a row — a receipt, a content echo, or the caller. */
export type ArchiveEnd = 'receipt' | 'echo' | 'abandoned' | 'cancelled' | 'evicted'

const ARCHIVE_ENDS: readonly string[] = ['receipt', 'echo', 'abandoned', 'cancelled', 'evicted']

/** Summary marker {@link TaskLedger.resolveEcho} writes on echo-settled rows. */
const ECHO_SUMMARY = '(settled by content echo)'

/**
 * #114 S3: who really sent one outbound task — the routing session, the
 * agent-less host face, or a native-teams bridge submitter. Before this
 * field every outbound row was attributable only to the host ("home"), so
 * same-host seats could not be told apart.
 */
export interface Sender {
  readonly kind: 'session' | 'host' | 'bridge'
  /**
   * A session's `<zone>/<id8>` node team, the host process label, or the
   * bridge submitter. Group senders by `kind:id`, never by `id` alone: a host
   * label set by hand may look like a session handle.
   */
  readonly id: string
  /**
   * Host senders only: the label the call borrowed on the wire when it
   * differs from {@link id} (quick dispatch rides a live joined session's
   * team). Display context, never a bucket key.
   */
  readonly face?: string
}

const SENDER_KINDS: readonly string[] = ['session', 'host', 'bridge']

/** Longest sender id kept; anything longer is malformed, not truncated. */
export const SENDER_ID_CAP = 256

/**
 * Restore-side allowlist for one persisted sender: a well-formed value comes
 * back as a fresh object holding only kind, id and (when present) face; anything else is dropped whole (the row
 * itself survives — a bad sender never costs the debt record).
 * @param raw - the persisted value.
 * @returns the sender, or undefined when absent or malformed.
 */
export function parseSender(raw: unknown): Sender | undefined {
  if (raw === null || typeof raw !== 'object' || Array.isArray(raw)) return undefined
  const { kind, id, face } = raw as Record<string, unknown>
  if (typeof kind !== 'string' || !SENDER_KINDS.includes(kind)) return undefined
  if (typeof id !== 'string' || id === '' || id.length > SENDER_ID_CAP) return undefined
  if (face !== undefined && (typeof face !== 'string' || face === '' || face.length > SENDER_ID_CAP)) return undefined
  // `face` belongs to host senders only; on any other kind it is dropped, the sender kept.
  return { kind: kind as Sender['kind'], id, ...(face !== undefined && kind === 'host' ? { face } : {}) }
}

/**
 * Spread helper for restore: `{ sender }` when the persisted value parses and
 * the row is not inbound (an inbound row's originator is its caller, never a
 * sender this host recorded), else nothing.
 */
function withSender(raw: unknown, direction: unknown): { sender?: Sender } {
  if (direction === 'inbound') return {}
  const sender = parseSender(raw)
  return sender === undefined ? {} : { sender }
}

/**
 * #114 S2: `{ auth }` when a persisted INBOUND row carries a record that
 * parses whole (parseAuthorization) and belongs to THIS row — its target is
 * the row's team and its receipt target the row's peer — else nothing: the
 * row survives as a pre-S2 row, never with a partially adopted or borrowed
 * record.
 */
function withAuth(raw: unknown, entry: { direction?: unknown; team?: unknown; peer?: unknown }, now: number): { auth?: TaskAuthorization } {
  if (entry.direction !== 'inbound' && entry.direction !== 'outbound') return {}
  const auth = parseAuthorization(raw, now)
  if (auth === undefined || auth.target !== entry.team) return {}
  if (entry.direction === 'inbound') return auth.ingress === 'wire' && `local:${auth.receipt_target}` === entry.peer ? { auth } : {}
  // #139: an outbound row carries only its local-candidate admission.
  return auth.ingress === 'local' && entry.peer === 'local' ? { auth } : {}
}

/** #139: the routing facts settlement reads, copied between a row and its archive entry. */
function routingOf(row: Pick<TaskRecord, 'peerKey' | 'peerHost' | 'deliveredTo'>): Pick<TaskRecord, 'peerKey' | 'peerHost' | 'deliveredTo'> {
  return {
    ...(row.peerKey !== undefined ? { peerKey: row.peerKey } : {}),
    ...(row.peerHost !== undefined ? { peerHost: row.peerHost } : {}),
    ...(row.deliveredTo !== undefined ? { deliveredTo: row.deliveredTo } : {}),
  }
}

/** #139: what an outbound row is born with besides its sender. */
export interface OutboundBirth {
  /** The local-candidate admission (ingress local); kept only on a row whose peer is 'local'. */
  readonly auth?: TaskAuthorization
  readonly peerKey?: string
  readonly peerHost?: string
  readonly deliveredTo?: string
}

/** The facts of one outbound birth that fit the row (see {@link withRouting} for the same shape on restore). */
function birthFacts(peer: string, birth: OutboundBirth | undefined): Pick<TaskRecord, 'auth' | 'peerKey' | 'peerHost' | 'deliveredTo'> {
  if (birth === undefined) return {}
  const fact = (v: string | undefined): v is string => v !== undefined && v !== '' && v.length <= ROUTING_FACT_CAP
  const remote = peer !== 'local' && !peer.startsWith('local:')
  return {
    ...(!remote && birth.auth !== undefined && birth.auth.ingress === 'local' ? { auth: birth.auth } : {}),
    ...(remote && fact(birth.peerKey) ? { peerKey: birth.peerKey } : {}),
    ...(remote && fact(birth.peerHost) ? { peerHost: birth.peerHost } : {}),
    ...(fact(birth.deliveredTo) ? { deliveredTo: birth.deliveredTo } : {}),
  }
}

/** Bound on a persisted routing fact; anything longer (or empty, or not a string) is dropped on restore. */
const ROUTING_FACT_CAP = 256

/**
 * #139: restore-side allowlist for the routing facts. Each is kept only in
 * its shape — a non-empty string within the cap — and the peer facts only on
 * a remote outbound row; anything else is dropped (the row survives as one
 * born before the fields, judged by current membership and origin).
 */
function withRouting(entry: Record<string, unknown>): Pick<TaskRecord, 'peerKey' | 'peerHost' | 'deliveredTo'> {
  const fact = (v: unknown): v is string => typeof v === 'string' && v !== '' && v.length <= ROUTING_FACT_CAP
  const remoteOutbound = entry.direction === 'outbound' && typeof entry.peer === 'string' && entry.peer !== 'local' && !entry.peer.startsWith('local:')
  return {
    ...(remoteOutbound && fact(entry.peerKey) ? { peerKey: entry.peerKey } : {}),
    ...(remoteOutbound && fact(entry.peerHost) ? { peerHost: entry.peerHost } : {}),
    ...(fact(entry.deliveredTo) ? { deliveredTo: entry.deliveredTo } : {}),
  }
}

/** One tracked outbound task still in the owed book (unsettled). */
export interface TaskRecord {
  readonly taskId: string
  readonly team: string
  readonly peer: string
  readonly startedAt: number
  /**
   * Which side of the wire this row serves: 'outbound' (this node sent and
   * awaits a receipt) or 'inbound' (this node received and owes one).
   * Absent on rows persisted before F2' — those are outbound by birth.
   */
  readonly direction?: 'inbound' | 'outbound'
  /**
   * F5: whether a receipt is actually owed. Absent ⇒ true (back-compat).
   * `false` marks fire-and-forget deliveries — the caller's label could not
   * receive a receipt at dispatch (process-form label), so no debt was born
   * and supervision must not chase this row.
   */
  readonly receiptExpected?: boolean
  /** The conversation the delivery steered, for follow-up routes. */
  readonly contextId?: string
  /**
   * Head of the dispatched message (first non-empty line, {@link BRIEF_CAP}).
   * What the row is ABOUT — the fact that makes the ledger readable without
   * replaying the conversation. Absent on rows persisted before this field.
   */
  readonly brief?: string
  /** #114 S3: the real sender of an outbound row (absent on inbound rows and rows persisted before the field). */
  readonly sender?: Sender
  /**
   * #114 S2: the immutable authorization the row was born with — an inbound
   * row's wire admission, or (#139) an outbound row's local-candidate
   * admission (`ingress: 'local'`). Absent on remote outbound and older rows.
   */
  readonly auth?: TaskAuthorization
  /** #139: the public key of the peer card a remote outbound row was dispatched to. */
  readonly peerKey?: string
  /** #139: that card's session label (the peer host's process label). */
  readonly peerHost?: string
  /** #139: the member that actually received the task (canvas / bare-zone deliveries). */
  readonly deliveredTo?: string
  status: TaskStatus
  /** When the row was swept to dead-letter (absent while pending). */
  deadAt?: number
  /**
   * F5 layer-3: why the row aged out. 'fire-forget' — a receiptExpected:false
   * row expiring is expected bookkeeping, not a failure; 'unconsumed' — a
   * receipt-owed row never settled, the actionable stale shape. Absent on
   * dead rows persisted before this field (rendered as 'unspecified').
   */
  reason?: DeadReason
}

/** One settled task kept for audit, with its receipt-correlated outcome. */
export interface ArchivedRecord {
  readonly taskId: string
  readonly team: string
  readonly peer: string
  readonly startedAt: number
  readonly contextId?: string
  readonly resolvedAt: number
  readonly summary?: string
  /** Head of the dispatched message that this row settled (see {@link TaskRecord.brief}). */
  readonly brief?: string
  /** Controlled vocabulary verdict when the settling receipt carried a v2 envelope; forced 'abandoned' for caller-abandoned rows. */
  readonly outcome?: ReceiptOutcomeV2 | 'abandoned'
  /** Remote-turn wall-clock cost, when the settling envelope carried it. */
  readonly elapsedMs?: number
  /**
   * When a receipt arrived for an explicitly abandoned row ({@link TaskLedger.abandon}).
   * Orphan isolation: the abandonment outcome stays verbatim; the late answer is
   * recorded as metadata only, never promoted to resolution.
   */
  readonly lateReceiptAt?: number
  /**
   * gh#31: which archive path ended the row, recorded at archive time. Absent
   * on rows archived before the field — {@link archivedEndedBy} derives it.
   */
  readonly endedBy?: ArchiveEnd
  /** gh#31: which side of the wire the row served, copied from the owed row (absent on rows archived before the field). */
  readonly direction?: 'inbound' | 'outbound'
  /**
   * gh#68: copied from the owed row when it awaited no receipt, so a tidied
   * fire-forget expiry is not read as a send we gave up on. Only `false` is
   * ever stored; absent means a receipt was owed (or the row predates the field).
   */
  readonly receiptExpected?: false
  /** #114 S3: copied from the owed row (absent on inbound rows and rows archived before the field). */
  readonly sender?: Sender
  /** #114 S2: carried over from the live row unchanged. */
  readonly auth?: TaskAuthorization
  /** #139: carried over from the live row unchanged (a late receipt is judged against them). */
  readonly peerKey?: string
  readonly peerHost?: string
  readonly deliveredTo?: string
  /** #114 S4: who settled the row (receipt and echo ends), and their chain role. */
  readonly settledBy?: SettledBy
}

/**
 * How one archived row ended (gh#31). The recorded field wins; legacy rows
 * fall back to the summary markers this ledger writes itself. The fallback
 * reads a receipt-settled row's summary, which is the peer's text, so it is
 * only as exact as the legacy data allows.
 * @param row - the archived record.
 * @returns the archive path that ended it.
 */
export function archivedEndedBy(row: ArchivedRecord): ArchiveEnd {
  if (row.endedBy !== undefined) return row.endedBy
  const summary = row.summary ?? ''
  if (summary.startsWith('caller-cancelled')) return 'cancelled'
  if (summary.startsWith('caller-abandoned')) return 'abandoned'
  if (summary === ECHO_SUMMARY) return 'echo'
  return 'receipt'
}

/** Result of an explicit caller-side abandon. Total and never-thrown. */
export type AbandonOutcome = 'cleared' | 'already-terminal' | 'unknown'

/** Structured verdict for one {@link TaskLedger.abandon} call (consumer contract: idempotent). */
export interface AbandonResult {
  readonly outcome: AbandonOutcome
  readonly taskId: string
  /** Settle time: fresh abandonment's clock tick, or the already-settled row's original resolvedAt. */
  readonly archivedAt?: number
}

/** Result of a cooperative {@link TaskLedger.cancel}; adds routing facts for the notify half. */
export interface CancelledResult extends AbandonResult {
  /** Team the ended row addressed — the route layer reaches a live local target through it. */
  readonly team?: string
  readonly contextId?: string
}

/** Per-instance knobs; defaults come from the exported constants. */
export interface TaskLedgerOptions {
  /** Stale-TTL override (tests inject short windows); defaults to {@link TASK_STALE_TTL_MS}. */
  staleTtlMs?: number
  /** Archive capacity override; defaults to {@link ARCHIVE_CAP}. */
  archiveCap?: number
  /**
   * Clock injection for tests: every sweep/TTL decision reads the time from
   * here. Defaults to Date.now. Injecting a steppable clock makes the stale
   * transition deterministic - no real sleeps to race under load.
   */
  now?: () => number
}

/**
 * What one correlated receipt settled — the payload of the
 * `a2a/receipt-resolved` event, emitted for consumers that react to receipt
 * arrivals (P2: native-teams settles its outstanding async submissions from
 * this seam). `outcome` carries the v2 envelope's controlled-vocabulary
 * verdict when the receipt rode one; `late` marks a receipt answering a
 * dead-lettered row (revival) or an abandoned row (arrival recorded) — a
 * healthy row's duplicate receipt refreshes the archive with NO marker.
 */
export interface ReceiptResolvedInfo {
  readonly taskId: string
  /** The team the task was routed to (as the dispatcher recorded it). */
  readonly team: string
  /** The peer (or `'local'`) the task was dispatched through. */
  readonly peer: string
  /** v2 envelope outcome, when the receipt rode one. */
  readonly outcome?: string
  /** One-line outcome summary, when the receipt carried one. */
  readonly summary?: string
  /** True when the receipt answered a dead-lettered or abandoned row. */
  readonly late?: boolean
}

/** The persisted ledger document: the owed book plus its settled archive. */
export interface TaskLedgerSnapshot {
  readonly tasks: readonly TaskRecord[]
  readonly archived?: readonly ArchivedRecord[]
  /** #114 S4: the bounded ring of refused / would-be-refused settlements. */
  readonly settlementRefusals?: readonly SettlementRefusalRecord[]
  /** #114 S4: monotonic count of every refusal noted. */
  readonly settlementRefusalsTotal?: number
}

/** #114 S4: who settled an archived row, and how they stood on its authorization chain. */
export interface SettledBy {
  readonly caller: string
  readonly chain_role: ChainRole | 'off-chain'
}

/** #114 S4: one settlement the judgement refused (enforce) or would have refused (observe). */
export interface SettlementRefusalRecord {
  readonly taskId: string
  readonly at: number
  readonly settler: { readonly caller: string; readonly proof: AuthProof; readonly ingress: 'wire' | 'local' }
  readonly reason: SettlementReason
  /** The receipt's first line, bounded. */
  readonly head: string
  /** true: the settlement was refused (enforce); false: recorded only (observe). */
  readonly enforced: boolean
  /** Repeats of the same (task, settler, reason) folded into this entry, so a flood cannot push older evidence out (review of PR #140 P2-4). */
  readonly count: number
}

/** Bound on ids and callers kept in settlement records; longer values are cut on write and refused on restore. */
const SETTLEMENT_ID_CAP = 256

/** Bound of the refusal ring (design §4.4). */
export const SETTLEMENT_REFUSAL_CAP = 64

/**
 * #114 S4: how the ledger asks whether a settler may settle a row. `check`
 * is the pure judgement (task-auth.ts judgeSettlement) bound to this
 * receipt's facts; `enforce` decides whether an off-chain verdict blocks
 * the settlement or is only recorded.
 */
export interface SettlementJudge {
  readonly enforce: boolean
  readonly settler: SettlementRefusalRecord['settler']
  check(row: Pick<TaskRecord, 'team' | 'peer' | 'direction' | 'auth' | 'peerKey' | 'peerHost' | 'deliveredTo'>, echo: boolean): SettlementVerdict
}

const SETTLEMENT_REASONS: readonly string[] = ['settler-off-chain', 'settler-unverified', 'on-behalf-mismatch', 'echo-off-chain']
const CHAIN_ROLES: readonly string[] = ['target', 'target-member', 'host-face', 'compat', 'legacy', 'off-chain']
const PROOF_VALUES: readonly string[] = ['origin-claim', 'claim-mismatch', 'legacy-window', 'in-process', 'none']

/** Restore-side allowlist for settledBy: whole or nothing. */
function withSettledBy(raw: unknown): { settledBy?: SettledBy } {
  if (raw === null || typeof raw !== 'object') return {}
  const r = raw as Record<string, unknown>
  if (typeof r.caller !== 'string' || r.caller.length > SETTLEMENT_ID_CAP || typeof r.chain_role !== 'string' || !CHAIN_ROLES.includes(r.chain_role)) return {}
  return { settledBy: { caller: r.caller, chain_role: r.chain_role as SettledBy['chain_role'] } }
}

/** Restore-side allowlist for one refusal record: whole or nothing. */
function parseRefusal(raw: unknown): SettlementRefusalRecord | undefined {
  if (raw === null || typeof raw !== 'object') return undefined
  const r = raw as Record<string, unknown>
  const st = r.settler as Record<string, unknown> | null | undefined
  if (typeof r.taskId !== 'string' || r.taskId === '' || r.taskId.length > SETTLEMENT_ID_CAP || typeof r.at !== 'number' || !Number.isFinite(r.at)) return undefined
  if (typeof r.reason !== 'string' || !SETTLEMENT_REASONS.includes(r.reason) || typeof r.head !== 'string' || typeof r.enforced !== 'boolean') return undefined
  if (st === null || typeof st !== 'object' || typeof st.caller !== 'string' || st.caller.length > SETTLEMENT_ID_CAP || typeof st.proof !== 'string' || !PROOF_VALUES.includes(st.proof) || (st.ingress !== 'wire' && st.ingress !== 'local')) return undefined
  const count = r.count === undefined ? 1 : r.count
  if (typeof count !== 'number' || !Number.isInteger(count) || count < 1) return undefined
  return { taskId: r.taskId, at: r.at, settler: { caller: st.caller, proof: st.proof as AuthProof, ingress: st.ingress }, reason: r.reason as SettlementReason, head: r.head.slice(0, SUMMARY_CAP), enforced: r.enforced, count }
}

/**
 * Bounded outbound-task ledger with whole-file persistence. Pure of any
 * routing knowledge: callers {@link track} a task when a route leaves it
 * owed a receipt and feed every inbound/relayed message through
 * {@link resolveFromMessage} for correlation.
 */
export class TaskLedger {
  /** Owed-book rows, most recently tracked first; settled rows leave here. */
  private tasks: TaskRecord[] = []
  /** Settled rows, most recently resolved first; bounded by the archive cap. */
  private archived: ArchivedRecord[] = []
  /** #114 S4: refused / would-be-refused settlements, newest first. */
  private refusals: SettlementRefusalRecord[] = []
  /** #114 S4: every refusal ever noted (monotonic; survives the ring's bound). */
  private refusalsTotal = 0
  private readonly staleTtlMs: number
  private readonly archiveCap: number
  /** Injectable clock (option `now`). */
  private readonly now: () => number

  /**
   * @param path - persistence file (`<dsh-home>/a2a/tasks.json`); empty = no persistence.
   * @param options - TTL/capacity overrides; defaults come from the exported constants.
   */
  constructor(private readonly path: string, options?: TaskLedgerOptions) {
    this.staleTtlMs = options?.staleTtlMs ?? TASK_STALE_TTL_MS
    this.archiveCap = options?.archiveCap ?? ARCHIVE_CAP
    this.now = options?.now ?? (() => Date.now())
    this.restore()
  }

  /**
   * Every unsettled task (pending + dead-lettered), most recently tracked first.
   * Sweeping runs first, so an overdue pending row reports as dead here.
   * @returns the owed-book records.
   */
  list(): readonly TaskRecord[] {
    this.sweep(this.now())
    return [...this.tasks]
  }

  /**
   * The settled archive, most recently resolved first. Rows land here the
   * moment their receipt correlates and stay until the archive cap evicts
   * the oldest — receipts keep correlating against them, so a repeat or a
   * delayed duplicate refreshes instead of resolving nothing.
   * @returns the archived records.
   */
  archive(): readonly ArchivedRecord[] {
    return [...this.archived]
  }

  /**
   * Remember one outbound task owed a receipt, most-recent first, bounded by
   * {@link TASK_CAP} over the owed book only (settled rows live in the
   * archive, never silently evicted). A task id is caller-born and
   * single-use: a known id in either tier keeps its first record verbatim.
   * @param taskId - the correlation key the receipt echoes.
   * @param team - the team the route addressed.
   * @param peer - the candidate that accepted the delivery ('local' or URL).
   * @param contextId - the delivery's conversation id, kept for follow-up routes (empty omits it).
   */
  /**
   * Fix ② (ghost-debt stop): register one delivered async dispatch whose
   * callback address could not be resolved — the row stays VISIBLE (the
   * ledger is honest) but carries receiptExpected:false, so neither the
   * owed book nor the settleable bucket ever counts it. Reconciliation is
   * via context_id follow-ups (the dispatch reply already says so).
   * Idempotent by task id like {@link track}.
   */
  trackReceiptless(taskId: string, team: string, peer: string, contextId?: string, brief?: string, sender?: Sender, birth?: OutboundBirth): void {
    if (taskId === '') return
    this.sweep(this.now())
    if (this.tasks.some(entry => entry.taskId === taskId)) return
    if (this.archived.some(entry => entry.taskId === taskId)) return
    this.tasks = [{
      taskId,
      team,
      peer,
      startedAt: this.now(),
      direction: 'outbound' as const,
      receiptExpected: false,
      ...(contextId !== undefined && contextId !== '' ? { contextId } : {}),
      ...(brief !== undefined && brief !== '' ? { brief } : {}),
      ...(sender !== undefined ? { sender } : {}),
      ...birthFacts(peer, birth),
      status: 'pending' as const,
    }, ...this.tasks]
    this.trimOwed()
    this.persist()
  }

  track(taskId: string, team: string, peer: string, contextId?: string, brief?: string, sender?: Sender, birth?: OutboundBirth): void {
    if (taskId === '') return
    this.sweep(this.now())
    if (this.tasks.some(entry => entry.taskId === taskId)) return
    if (this.archived.some(entry => entry.taskId === taskId)) return
    this.tasks = [{
      taskId,
      team,
      peer,
      startedAt: this.now(),
      direction: 'outbound' as const,
      ...(contextId !== undefined && contextId !== '' ? { contextId } : {}),
      ...(brief !== undefined && brief !== '' ? { brief } : {}),
      ...(sender !== undefined ? { sender } : {}),
      ...birthFacts(peer, birth),
      status: 'pending' as const,
    }, ...this.tasks]
    this.trimOwed()
    this.persist()
  }

  /**
   * F2' (receipt-settlement): remember one INBOUND delivery owed a receipt —
   * this node is the settlement debtor here: the caller waits for a receipt
   * only this target can produce. Before this row type existed, inbound
   * deliveries were born ledger-less, so the async nudge's isPending gate
   * no-op'd for exactly the deliveries that stall (08-30 evidence: zero
   * ledger records for latched activations). Idempotent by task id like
   * {@link track}.
   * @param taskId - the correlation key the caller's task was born with.
   * @param team - the team the delivery addressed (this node's).
   * @param from - the caller's receipt target (label or callback address).
   * @param contextId - the delivery's conversation id, kept for follow-up routes (empty omits it).
   */
  trackInbound(taskId: string, team: string, from: string, contextId?: string, receiptExpected?: boolean, brief?: string, auth?: TaskAuthorization, deliveredTo?: string): void {
    if (taskId === '') return
    this.sweep(this.now())
    if (this.tasks.some(entry => entry.taskId === taskId)) return
    if (this.archived.some(entry => entry.taskId === taskId)) return
    this.tasks = [{
      taskId,
      team,
      peer: `local:${from}`,
      startedAt: this.now(),
      direction: 'inbound' as const,
      ...(receiptExpected === false ? { receiptExpected: false } : {}),
      ...(contextId !== undefined && contextId !== '' ? { contextId } : {}),
      ...(brief !== undefined && brief !== '' ? { brief } : {}),
      // #114 S2: frozen at birth; a replayed id never reaches here (first record wins above).
      ...(auth !== undefined ? { auth } : {}),
      ...(deliveredTo !== undefined && deliveredTo !== '' ? { deliveredTo: deliveredTo.slice(0, ROUTING_FACT_CAP) } : {}),
      status: 'pending' as const,
    }, ...this.tasks]
    this.trimOwed()
    this.persist()
  }

  /**
   * v0.5.23 (async-stall): whether a tracked task still owes its receipt.
   * The async nudge consults this — a resolved or dead-lettered task
   * disarms its retry (re-steering a session that could not start a turn
   * past its own stale window is noise, not recovery).
   * @param taskId - the correlation key the receipt echoes.
   * @returns true when the task is tracked pending inside its TTL.
   */
  isPending(taskId: string): boolean {
    const record = this.tasks.find(entry => entry.taskId === taskId)
    if (record === undefined || record.status !== 'pending') return false
    return this.now() - record.startedAt <= this.staleTtlMs
  }

  /**
   * Caller-side give-up (work-order P1a): clears one owed row into the
   * archive under a `caller-abandoned` outcome so waiters stop occupying the
   * remote budget and the three-tier book stays honest about who ended it.
   * NOT cooperative cancellation — the remote may still be working. A late
   * receipt against an abandoned row lands as orphan metadata
   * ({@link ArchivedRecord.lateReceiptAt}) without rewriting the decision.
   * Idempotent and total per the consumer contract: repeat calls and unknown
   * ids return stable structured outcomes, never throw.
   * @param taskId - the correlation key to abandon.
   * @param reason - optional short cause, folded into the archived summary.
   * @returns `{outcome:'cleared'}` when a pending/dead row was settled now,
   * `'already-terminal'` when the archive already held the task's end,
   * `'unknown'` when neither tier ever saw the id.
   */
  abandon(taskId: string, reason?: string): AbandonResult {
    if (taskId === '') return { outcome: 'unknown', taskId }
    this.sweep(this.now())
    const record = this.tasks.find(entry => entry.taskId === taskId)
    if (record !== undefined) {
      this.tasks = this.tasks.filter(entry => entry.taskId !== taskId)
      const resolvedAt = this.now()
      const cause = reason === undefined || reason === '' ? '' : `: ${reason.slice(0, SUMMARY_CAP - 'caller-abandoned:'.length)}`
      this.archiveSettled({
        taskId: record.taskId,
        team: record.team,
        peer: record.peer,
        startedAt: record.startedAt,
        ...(record.contextId !== undefined ? { contextId: record.contextId } : {}),
        ...(record.brief !== undefined ? { brief: record.brief } : {}),
        resolvedAt,
        summary: `caller-abandoned${cause}`,
        outcome: 'abandoned',
        endedBy: 'abandoned',
        ...(record.direction !== undefined ? { direction: record.direction } : {}),
        ...(record.receiptExpected === false ? { receiptExpected: false as const } : {}),
        ...(record.sender !== undefined ? { sender: record.sender } : {}),
        ...(record.auth !== undefined ? { auth: record.auth } : {}),
        ...routingOf(record),
      })
      this.persist()
      return { outcome: 'cleared', taskId, archivedAt: resolvedAt }
    }
    const settled = this.archived.find(entry => entry.taskId === taskId)
    if (settled === undefined) return { outcome: 'unknown', taskId }
    return { outcome: 'already-terminal', taskId, archivedAt: settled.resolvedAt }
  }

  /**
   * Cooperative cancellation (work-order P1b): ends one owed row like
   * {@link abandon} but marks it `caller-cancelled` so downstream tooling
   * tells "stopped waiting" from "ordered a stop". Implemented standalone
   * (not via a shared endTask core) deliberately: abandon() is already
   * reviewed semantics on this stack — touching it would ripple re-review;
   * the ~20 duplicated lines buy a frozen reviewed surface.
   * Cross-node targets degrade honestly: no reachable lane ⇒ no notify —
   * the route layer reads team/contextId from here for its best-effort
   * steer, which is the documented boundary until origin-auth lands.
   */
  cancel(taskId: string, reason?: string): CancelledResult {
    if (taskId === '') return { outcome: 'unknown', taskId }
    this.sweep(this.now())
    const record = this.tasks.find(entry => entry.taskId === taskId)
    if (record !== undefined) {
      this.tasks = this.tasks.filter(entry => entry.taskId !== taskId)
      const resolvedAt = this.now()
      const cause = reason === undefined || reason === '' ? '' : `: ${reason.slice(0, SUMMARY_CAP - 'caller-cancelled:'.length)}`
      this.archiveSettled({
        taskId: record.taskId,
        team: record.team,
        peer: record.peer,
        startedAt: record.startedAt,
        ...(record.contextId !== undefined ? { contextId: record.contextId } : {}),
        ...(record.brief !== undefined ? { brief: record.brief } : {}),
        resolvedAt,
        summary: `caller-cancelled${cause}`,
        outcome: 'abandoned',
        endedBy: 'cancelled',
        ...(record.direction !== undefined ? { direction: record.direction } : {}),
        ...(record.receiptExpected === false ? { receiptExpected: false as const } : {}),
        ...(record.sender !== undefined ? { sender: record.sender } : {}),
        ...(record.auth !== undefined ? { auth: record.auth } : {}),
        ...routingOf(record),
      })
      this.persist()
      return {
        outcome: 'cleared',
        taskId,
        archivedAt: resolvedAt,
        team: record.team,
        ...(record.contextId !== undefined ? { contextId: record.contextId } : {}),
      }
    }
    const settled = this.archived.find(entry => entry.taskId === taskId)
    if (settled === undefined) return { outcome: 'unknown', taskId }
    return { outcome: 'already-terminal', taskId, archivedAt: settled.resolvedAt }
  }

  /**
   * Correlate one message against the ledger: a receipt (message starting
   * `[A2A receipt] task <id> …`) settles its task into the archive, keeping
   * the outcome summary; a repeat or late receipt refreshes that archived
   * record with the latest outcome. A dead-lettered row revives through this
   * same path when a revived target finally answers.
   * @param message - the inbound or relayed message text.
   * @param only - gh#141: settle the named row only when it passes this test;
   *   with a test, a row that fails it or is already archived correlates nothing.
   * @returns what the receipt settled, or `undefined` when the message
   *   correlated nothing.
   */
  resolveFromMessage(message: string, judge?: SettlementJudge, only?: (record: TaskRecord) => boolean): ReceiptResolvedInfo | undefined {
    const parsed = parseReceipt(message)
    if (parsed === null) return undefined
    const taskId = parsed.taskId
    const summary = parsed.summary.trim().slice(0, SUMMARY_CAP)    // Controlled vocabulary only: a foreign outcome string never lands here.
    const envelopeOutcome =
      parsed.envelope?.outcome !== undefined ? (parsed.envelope.outcome as ReceiptOutcomeV2) : undefined
    const elapsedMs = parsed.envelope?.elapsedMs
    this.sweep(this.now())
    const record = this.tasks.find(entry => entry.taskId === taskId)
    if (only !== undefined && (record === undefined || !only(record))) return undefined
    if (record !== undefined) {
      // #114 S4: judge the settler before the row moves; enforce keeps a refused row owed.
      const verdict = judge?.check(record, false)
      if (verdict !== undefined && !verdict.ok) {
        this.noteRefusal(taskId, judge!, verdict.reason, message)
        if (judge!.enforce) { this.persist(); return undefined }
      }
      this.tasks = this.tasks.filter(entry => entry.taskId !== taskId)
      this.archiveSettled({
        taskId: record.taskId,
        team: record.team,
        peer: record.peer,
        startedAt: record.startedAt,
        ...(record.contextId !== undefined ? { contextId: record.contextId } : {}),
        ...(record.brief !== undefined ? { brief: record.brief } : {}),
        resolvedAt: this.now(),
        ...(summary !== '' ? { summary } : {}),
        ...(envelopeOutcome !== undefined ? { outcome: envelopeOutcome } : {}),
        ...(elapsedMs !== undefined ? { elapsedMs } : {}),
        endedBy: 'receipt',
        ...(record.direction !== undefined ? { direction: record.direction } : {}),
        ...(record.receiptExpected === false ? { receiptExpected: false as const } : {}),
        ...(record.sender !== undefined ? { sender: record.sender } : {}),
        ...(record.auth !== undefined ? { auth: record.auth } : {}),
        ...routingOf(record),
        ...(verdict !== undefined ? { settledBy: { caller: judge!.settler.caller.slice(0, SETTLEMENT_ID_CAP), chain_role: verdict.ok ? verdict.role : 'off-chain' } } : {}),
      })
      this.persist()
      return {
        taskId,
        team: record.team,
        peer: record.peer,
        // A dead row still lives in the tasks array (the sweep only flips
        // status): its receipt is a revival — the late marker's first form.
        ...(record.status === 'dead' ? { late: true } : {}),
        ...(envelopeOutcome !== undefined ? { outcome: envelopeOutcome } : {}),
        ...(summary !== '' ? { summary } : {}),
      }
    }
    const settled = this.archived.find(entry => entry.taskId === taskId)
    if (settled === undefined) return undefined
    // #114 S4 (review of PR #140 P2-3): a late receipt is judged too. Under
    // enforce, an off-chain one only marks that an answer came late — it
    // never rewrites the settled summary or outcome.
    const lateVerdict = judge?.check(settled, false)
    if (lateVerdict !== undefined && !lateVerdict.ok) {
      this.noteRefusal(taskId, judge!, lateVerdict.reason, message)
      if (judge!.enforce) {
        this.archived = [{ ...settled, lateReceiptAt: this.now() }, ...this.archived.filter(entry => entry.taskId !== taskId)]
        this.persist()
        return undefined
      }
    }
    // Orphan isolation: a receipt for an explicitly abandoned row must not
    // rewrite the abandonment outcome — the caller stopped waiting by choice.
    // Record that the target did answer later; keep the decision verbatim and
    // pin the projected verdict to 'abandoned'.
    // gh#31: the recorded end wins; the summary prefix only decides legacy
    // rows (a receipt-settled row's summary is the peer's own text).
    const callerEnded = settled.endedBy !== undefined
      ? settled.endedBy === 'abandoned' || settled.endedBy === 'cancelled'
      : CALLER_ENDED_PREFIX.test(settled.summary ?? '')
    this.archived = [
      {
        ...settled,
        ...(callerEnded
          ? { lateReceiptAt: this.now(), outcome: 'abandoned' as const }
          : {
              resolvedAt: this.now(),
              ...(summary !== '' ? { summary } : {}),
              ...(envelopeOutcome !== undefined ? { outcome: envelopeOutcome } : {}),
            }),
      },
      ...this.archived.filter(entry => entry.taskId !== taskId),
    ]
    this.persist()
    return {
      taskId,
      team: settled.team,
      peer: settled.peer,
      ...(envelopeOutcome !== undefined ? { outcome: envelopeOutcome } : {}),
      ...(summary !== '' ? { summary } : {}),
      // The late marker's second form: the caller had already moved on
      // (abandonment recorded verbatim). A HEALTHY row's duplicate refresh
      // is neither dead-lettered nor abandoned — it carries no marker.
      ...(callerEnded ? { late: true } : {}),
    }
  }

  /**
   * F5 (settlement integrity): settle pending rows by CONTENT ECHO — an
   * inbound message that references `task <id>` of a pending row counts as
   * the peer demonstrably responding to that task, even when the formal
   * `[A2A receipt]` envelope never rode the reply (the 08-30 shape: content
   * answered, formality lost). The receipt envelope keeps precedence: this
   * runs only when {@link resolveFromMessage} correlated nothing. Echo-
   * settled rows archive with a marker summary so the audit trail shows
   * they were echoes, not envelopes.
   * @param message - the inbound message text.
   * @returns the task ids this message settled (usually none or one).
   */
  resolveEcho(message: string, judge?: SettlementJudge): string[] {
    const settled: string[] = []
    let refused = false
    this.sweep(this.now())
    for (const record of [...this.tasks]) {
      if (record.status !== 'pending') continue
      if (!message.includes(`task ${record.taskId}`)) continue
      // #114 S4: an echo is weak evidence — only an on-chain settler's echo counts under enforce.
      const verdict = judge?.check(record, true)
      if (verdict !== undefined && !verdict.ok) {
        this.noteRefusal(record.taskId, judge!, verdict.reason, message)
        refused = true
        if (judge!.enforce) continue
      }
      this.tasks = this.tasks.filter(entry => entry.taskId !== record.taskId)
      this.archiveSettled({
        taskId: record.taskId,
        team: record.team,
        peer: record.peer,
        startedAt: record.startedAt,
        ...(record.contextId !== undefined ? { contextId: record.contextId } : {}),
        resolvedAt: this.now(),
        summary: ECHO_SUMMARY,
        endedBy: 'echo',
        ...(record.direction !== undefined ? { direction: record.direction } : {}),
        ...(record.receiptExpected === false ? { receiptExpected: false as const } : {}),
        ...(record.sender !== undefined ? { sender: record.sender } : {}),
        ...(record.auth !== undefined ? { auth: record.auth } : {}),
        ...routingOf(record),
        ...(verdict !== undefined ? { settledBy: { caller: judge!.settler.caller.slice(0, SETTLEMENT_ID_CAP), chain_role: verdict.ok ? verdict.role : 'off-chain' } } : {}),
      })
      settled.push(record.taskId)
    }
    if (settled.length > 0 || refused) this.persist()
    return settled
  }

  /** #114 S4: the owed row for a task id, if any (read-only; for the settlement gate). */
  find(taskId: string): TaskRecord | undefined {
    return this.tasks.find(entry => entry.taskId === taskId)
  }

  /** #114 S4: refused / would-be-refused settlements, newest first. */
  settlementRefusals(): readonly SettlementRefusalRecord[] {
    return [...this.refusals]
  }

  /** #114 S4: every refusal ever noted, including those folded or pushed out of the ring. */
  settlementRefusalsTotal(): number {
    return this.refusalsTotal
  }

  /**
   * Record one refused / would-be-refused settlement in the bounded ring
   * (persisted by the caller). A repeat of the same (task, settler, reason)
   * folds into its entry and moves it to the head, so one row's flood cannot
   * push other evidence out.
   */
  private noteRefusal(taskId: string, judge: SettlementJudge, reason: SettlementReason, message: string): void {
    const head = (message.split('\n')[0] ?? '').slice(0, SUMMARY_CAP)
    const id = taskId.slice(0, SETTLEMENT_ID_CAP)
    const settler = { ...judge.settler, caller: judge.settler.caller.slice(0, SETTLEMENT_ID_CAP) }
    const same = (r: SettlementRefusalRecord): boolean => r.taskId === id && r.settler.caller === settler.caller && r.reason === reason && r.enforced === judge.enforce
    const prior = this.refusals.find(same)
    this.refusalsTotal += 1
    this.refusals = [{ taskId: id, at: this.now(), settler, reason, head, enforced: judge.enforce, count: (prior?.count ?? 0) + 1 }, ...this.refusals.filter(r => !same(r))].slice(0, SETTLEMENT_REFUSAL_CAP)
  }

  /** Move one settled record to the archive head, trimming at the cap. */
  private archiveSettled(record: ArchivedRecord): void {
    this.archived = [record, ...this.archived].slice(0, this.archiveCap)
  }

  /**
   * gh#86 (chief order direct-4f596524): when the owed book exceeds
   * TASK_CAP, the overflow rows go to the ARCHIVE as evicted - visible
   * for audit, never silently dropped. The review seat's recommendation,
   * chief-endorsed: the silent cap slice lost the oldest pending rows
   * with no trace. L8 criterion: zero silently-dropped.
   */
  private trimOwed(): void {
    if (this.tasks.length <= TASK_CAP) return
    const overflow = this.tasks.slice(TASK_CAP)
    this.tasks = this.tasks.slice(0, TASK_CAP)
    const now = this.now()
    for (const row of overflow) {
      this.archiveSettled({
        taskId: row.taskId,
        team: row.team,
        peer: row.peer,
        startedAt: row.startedAt,
        ...(row.contextId !== undefined ? { contextId: row.contextId } : {}),
        resolvedAt: now,
        ...(row.brief !== undefined ? { brief: row.brief } : {}),
        endedBy: 'evicted' as const,
        ...(row.direction !== undefined ? { direction: row.direction } : {}),
        ...(row.sender !== undefined ? { sender: row.sender } : {}),
        ...(row.auth !== undefined ? { auth: row.auth } : {}),
        ...routingOf(row),
      })
    }
  }

  /** Lazy dead-letter sweep: overdue pending rows flip status, at most once. */
  private sweep(now: number): void {
    let changed = false
    for (const entry of this.tasks) {
      if (entry.status === 'pending' && now - entry.startedAt > this.staleTtlMs) {
        entry.status = 'dead'
        entry.deadAt = now
        // F5 layer-3: stamp WHY the row aged — a fire-and-forget row
        // (receiptExpected:false) expiring is expected bookkeeping; a
        // receipt-owed row expiring means the settlement chain failed for
        // that delivery and deserves supervision attention.
        entry.reason = entry.receiptExpected === false ? 'fire-forget' : 'unconsumed'
        changed = true
      }
    }
    if (changed) this.persist()
  }

  /** Load a persisted snapshot on construction, if present. */
  private restore(): void {
    if (this.path === '' || !existsSync(this.path)) return
    try {
      const snapshot = JSON.parse(readFileSync(this.path, 'utf8')) as Partial<TaskLedgerSnapshot> | null
      const entries = snapshot?.tasks
      const restored: TaskRecord[] = []
      if (Array.isArray(entries)) {
        for (const raw of entries) {
          // Unparsed on purpose: the legacy shape carries a 'resolved' status
          // and inline outcome fields that TaskRecord no longer declares.
          const entry = raw as Record<string, unknown> | null
          if (typeof entry?.taskId !== 'string' || entry.taskId === '') continue
          // Legacy two-state files carried resolved rows inline; they migrate
          // into the archive so pre-upgrade outcomes survive the upgrade.
          if (entry.status === 'resolved') {
            this.archived.push({
              taskId: entry.taskId,
              team: typeof entry.team === 'string' ? entry.team : '',
              peer: typeof entry.peer === 'string' ? entry.peer : '',
              startedAt: typeof entry.startedAt === 'number' && Number.isFinite(entry.startedAt) ? entry.startedAt : this.now(),
              ...(typeof entry.contextId === 'string' && entry.contextId !== '' ? { contextId: entry.contextId } : {}),
              ...(typeof entry.brief === 'string' && entry.brief !== '' ? { brief: entry.brief } : {}),
              resolvedAt: typeof entry.resolvedAt === 'number' && Number.isFinite(entry.resolvedAt) ? entry.resolvedAt : this.now(),
              ...(typeof entry.summary === 'string' && entry.summary !== '' ? { summary: entry.summary } : {}),
              ...(typeof entry.outcome === 'string' && (RECEIPT_OUTCOMES as readonly string[]).includes(entry.outcome) ? { outcome: entry.outcome as ReceiptOutcomeV2 } : {}),
              ...(typeof entry.lateReceiptAt === 'number' && Number.isFinite(entry.lateReceiptAt) ? { lateReceiptAt: entry.lateReceiptAt } : {}),
              ...(typeof entry.endedBy === 'string' && ARCHIVE_ENDS.includes(entry.endedBy) ? { endedBy: entry.endedBy as ArchiveEnd } : {}),
              ...(entry.direction === 'inbound' || entry.direction === 'outbound' ? { direction: entry.direction } : {}),
              ...(entry.receiptExpected === false ? { receiptExpected: false as const } : {}),
              ...withSender(entry.sender, entry.direction),
              ...withAuth(entry.auth, entry, this.now()),
            ...withRouting(entry as Record<string, unknown>),
              ...withSettledBy((entry as { settledBy?: unknown }).settledBy),
            })
            continue
          }
          restored.push({
            taskId: entry.taskId,
            team: typeof entry.team === 'string' ? entry.team : '',
            peer: typeof entry.peer === 'string' ? entry.peer : '',
            startedAt: typeof entry.startedAt === 'number' && Number.isFinite(entry.startedAt) ? entry.startedAt : this.now(),
            ...(typeof entry.contextId === 'string' && entry.contextId !== '' ? { contextId: entry.contextId } : {}),
            ...(typeof entry.brief === 'string' && entry.brief !== '' ? { brief: entry.brief } : {}),
            // gh#31: both sides round-trip — /state omits direction only when
            // it is unknown, so a restored outbound row must not lose it.
            ...(entry.direction === 'inbound' || entry.direction === 'outbound' ? { direction: entry.direction } : {}),
            ...(entry.receiptExpected === false ? { receiptExpected: false } : {}),
            // #114 S3: a malformed sender is dropped whole; the row survives.
            ...withSender(entry.sender, entry.direction),
            ...withAuth(entry.auth, entry, this.now()),
            ...withRouting(entry as Record<string, unknown>),
            status: entry.status === 'dead' ? 'dead' : 'pending',
            ...(entry.status === 'dead'
              ? {
                  deadAt: typeof entry.deadAt === 'number' && Number.isFinite(entry.deadAt) ? entry.deadAt : this.now(),
                  ...(entry.reason === 'fire-forget' || entry.reason === 'unconsumed' ? { reason: entry.reason } : {}),
                }
              : {}),
          })
        }
      }
      const legacyArchive = snapshot?.archived
      if (Array.isArray(legacyArchive)) {
        for (const raw of legacyArchive) {
          const entry = raw as Partial<ArchivedRecord> | null
          if (typeof entry?.taskId !== 'string' || entry.taskId === '') continue
          if (this.archived.some(existing => existing.taskId === entry.taskId)) continue
          this.archived.push({
            taskId: entry.taskId,
            team: typeof entry.team === 'string' ? entry.team : '',
            peer: typeof entry.peer === 'string' ? entry.peer : '',
            startedAt: typeof entry.startedAt === 'number' && Number.isFinite(entry.startedAt) ? entry.startedAt : this.now(),
            ...(typeof entry.contextId === 'string' && entry.contextId !== '' ? { contextId: entry.contextId } : {}),
            ...(typeof entry.brief === 'string' && entry.brief !== '' ? { brief: entry.brief } : {}),
            resolvedAt: typeof entry.resolvedAt === 'number' && Number.isFinite(entry.resolvedAt) ? entry.resolvedAt : this.now(),
            ...(typeof entry.summary === 'string' && entry.summary !== '' ? { summary: entry.summary } : {}),
            ...(typeof entry.outcome === 'string' && (RECEIPT_OUTCOMES as readonly string[]).includes(entry.outcome) ? { outcome: entry.outcome as ReceiptOutcomeV2 } : {}),
            ...(typeof entry.lateReceiptAt === 'number' && Number.isFinite(entry.lateReceiptAt) ? { lateReceiptAt: entry.lateReceiptAt } : {}),
            ...(typeof entry.endedBy === 'string' && ARCHIVE_ENDS.includes(entry.endedBy) ? { endedBy: entry.endedBy as ArchiveEnd } : {}),
            ...(entry.direction === 'inbound' || entry.direction === 'outbound' ? { direction: entry.direction } : {}),
            ...(entry.receiptExpected === false ? { receiptExpected: false as const } : {}),
            ...withSender(entry.sender, entry.direction),
            ...withAuth(entry.auth, entry, this.now()),
            ...withRouting(entry as Record<string, unknown>),
            ...withSettledBy((entry as { settledBy?: unknown }).settledBy),
          })
        }
      }
      this.tasks = restored.slice(0, TASK_CAP)
      this.archived = this.archived.slice(0, this.archiveCap)
      const refusals = (snapshot as { settlementRefusals?: unknown } | null)?.settlementRefusals
      if (Array.isArray(refusals)) this.refusals = refusals.map(parseRefusal).filter((r): r is SettlementRefusalRecord => r !== undefined).slice(0, SETTLEMENT_REFUSAL_CAP)
      const total = (snapshot as { settlementRefusalsTotal?: unknown } | null)?.settlementRefusalsTotal
      this.refusalsTotal = Math.max(typeof total === 'number' && Number.isInteger(total) && total >= 0 ? total : 0, this.refusals.reduce((n, r) => n + r.count, 0))
    } catch {
      // A corrupt ledger is not fatal: routing never depends on it; the
      // reconciliation simply starts fresh.
    }
  }

  /** Persist the ledger (no-op when no path was configured). */
  private persist(): void {
    if (this.path === '') return
    try {
      mkdirSync(dirname(this.path), { recursive: true })
      const snapshot: TaskLedgerSnapshot = {
        tasks: this.tasks.map(task => ({ ...task })),
        ...(this.archived.length > 0 ? { archived: this.archived.map(entry => ({ ...entry })) } : {}),
        ...(this.refusals.length > 0 ? { settlementRefusals: this.refusals.map(entry => ({ ...entry, settler: { ...entry.settler } })) } : {}),
        ...(this.refusalsTotal > 0 ? { settlementRefusalsTotal: this.refusalsTotal } : {}),
      }
      writeFileSync(this.path, JSON.stringify(snapshot), { mode: 0o600 })
    } catch {
      // An unwritable home must not break routing; the ledger degrades to
      // memory-only.
    }
  }
}