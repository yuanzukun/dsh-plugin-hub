/**
 * Persisted canvas teams: user-composed multi-member routing groups under
 * the a2a home (`a2a/canvas.json`). A canvas team is a named set of member
 * references in one of two shapes: a local session id (a joined session
 * node on this host) or a remote team handle (`<zone>/<id8>`, a session
 * node published by a peer — one member may sit in many teams). Routing to
 * `<team>/canvas/<name>` resolves the first live local member, wakes the
 * first cold local one, then falls through to the remote members in order
 * (the directory resolves their handles; remote nodes never wake from
 * here). The dispatching session itself is exempt from the local tiers
 * (issue #41: the self-route rule extends to canvas — an initiator
 * occupying a member slot never captures its own dispatch, which would
 * only echo home; the seam lives in the dispatch layer, the store stays
 * pure). Membership order is the routing priority (member list order),
 * preserved verbatim on disk. Plain JSON, one writer (the control routes),
 * read fresh by the state route.
 * @module @nelsonlongxiang/dsh-open-a2a-net/canvas-store
 */

import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname } from 'node:path'
import { CLI_HANDLE_RE } from './cli-deposit.ts'

/** On-disk shape: ordered team entries, each an ordered member id list. */
export interface CanvasSnapshot {
  readonly teams: ReadonlyArray<{ readonly name: string; readonly members: readonly string[] }>
  /** Pinned CLI handle -> linked home origin (only while some canvas team holds the handle). */
  readonly cliHome?: Readonly<Record<string, string>>
}

/** Upper bounds: a canvas taxonomy, not a database. */
export const CANVAS_TEAM_CAP = 64
export const CANVAS_MEMBER_CAP = 32

/** Longest accepted team name (same budget as group names). */
export const CANVAS_NAME_MAX = 40

/**
 * Whether one member entry references a remote node rather than a local
 * session id. Remote refs are zone-qualified team handles (`<zone>/<id8>`),
 * so the '/'-test is deterministic: local session ids (`session-<uuid>`,
 * `import-<uuid>`) never contain one, and canvas team names — the only other
 * strings in a member slot — are barred from '/' at creation.
 */
export function isRemoteMemberRef(id: string): boolean {
  return id.includes('/')
}

/**
 * Shape-gate for a remote member reference at the control-route seam: at
 * least one '/'-delimited segment on each side, no whitespace. The registry
 * cross-check lives in the UI (the picker offers discovered rows only);
 * this gate keeps malformed strings out of the persisted file.
 */
export function validRemoteMemberRef(id: string): boolean {
  const trimmed = id.trim()
  return trimmed === id && isRemoteMemberRef(id) && !/\s/.test(id)
    && !id.startsWith('/') && !id.endsWith('/') && !id.includes('//')
}

function validName(raw: string): string | undefined {
  const clean = raw.trim()
  if (clean === '' || clean.length > CANVAS_NAME_MAX) return undefined
  // '/' would nest the wire namespace (<team>/canvas/a/b); pure digits would
  // reorder under JSON.parse's integer-like key ordering if the store ever
  // migrated to a keyed map — both stay out now.
  if (clean.includes('/') || /^\d+$/.test(clean)) return undefined
  return clean
}

/**
 * Bounded canvas-team store with last-write-wins persistence. Pure of any
 * registry knowledge: callers validate join state and resolve members.
 */
export class CanvasStore {
  /** Team entries in creation order; members in add order (routing priority). */
  private teams: Array<{ name: string; members: string[] }> = []
  private cliHome: Record<string, string> = {}
  private readonly path: string
  private readonly listeners = new Set<() => void>()

  /**
   * @param path - the snapshot file; an empty path keeps the store in memory.
   */
  constructor(path: string) {
    this.path = path
    this.restore()
  }

  /**
   * Observe changes: the listener runs after every write that changed the
   * store (never on restore). A throwing listener cannot break the write.
   * @param listener - called with no arguments.
   * @returns the unsubscribe function.
   */
  onChange(listener: () => void): () => void {
    this.listeners.add(listener)
    return () => { this.listeners.delete(listener) }
  }

  /** Load a persisted snapshot, if present and well-formed. */
  private restore(): void {
    if (this.path === '' || !existsSync(this.path)) return
    try {
      const snapshot = JSON.parse(readFileSync(this.path, 'utf8')) as Partial<CanvasSnapshot> | null
      if (!Array.isArray(snapshot?.teams)) return
      const kept: Array<{ name: string; members: string[] }> = []
      for (const entry of snapshot.teams) {
        if (entry === null || typeof entry !== 'object') continue
        if (validName(String(entry.name)) === undefined) continue
        const members = Array.isArray(entry.members)
          ? entry.members.filter((id: unknown): id is string => typeof id === 'string' && id !== '').slice(0, CANVAS_MEMBER_CAP)
          : []
        if (kept.some(t => t.name === entry.name)) continue
        kept.push({ name: String(entry.name), members })
      }
      this.teams = kept.slice(0, CANVAS_TEAM_CAP)
      if (snapshot.cliHome !== null && typeof snapshot.cliHome === 'object' && !Array.isArray(snapshot.cliHome)) {
        for (const [handle, home] of Object.entries(snapshot.cliHome)) {
          if (CLI_HANDLE_RE.test(handle) && typeof home === 'string' && validHomeOrigin(home) && this.teams.some(t => t.members.includes(handle))) this.cliHome[handle] = home
        }
      }
    } catch {
      // A corrupt store is not fatal: the user re-creates teams; routing
      // names simply stop resolving until then.
    }
  }

  /** Persist the current snapshot (no-op without a path), then tell the listeners. */
  private persist(): void {
    this.write()
    for (const listener of this.listeners) {
      try { listener() } catch { /* a listener's failure is its own */ }
    }
  }

  private write(): void {
    if (this.path === '') return
    try {
      mkdirSync(dirname(this.path), { recursive: true })
      const snapshot: CanvasSnapshot = { teams: this.teams.map(t => ({ name: t.name, members: [...t.members] })), ...(Object.keys(this.cliHome).length > 0 ? { cliHome: { ...this.cliHome } } : {}) }
      writeFileSync(this.path, JSON.stringify(snapshot), { mode: 0o600 })
    } catch {
      // An unwritable home must not break the canvas; the store degrades to
      // memory-only.
    }
  }

  /** Every team name, in creation order. */
  list(): readonly string[] {
    return this.teams.map(t => t.name)
  }

  /** Whether the named team exists. */
  hasTeam(name: string): boolean {
    return this.teams.some(t => t.name === name)
  }

  /** The named team's member ids in routing-priority order (a copy). */
  membersOf(name: string): readonly string[] {
    const entry = this.teams.find(t => t.name === name)
    return entry === undefined ? [] : [...entry.members]
  }

  /** Frozen, operator-linked CLI home; undefined means unknown or ambiguous. */
  cliHomeOf(handle: string): string | undefined { return this.cliHome[handle] }
  pinnedCliHomes(): ReadonlyArray<readonly [string, string]> { return Object.entries(this.cliHome) }

  /**
   * The named team's remote member refs (zone-qualified team handles) in
   * routing-priority order — the failover tier after the local live/cold
   * tiers miss. Shape test only: whether the handle currently resolves is
   * the directory's question at route time, not the store's.
   */
  remoteMembersOf(name: string): readonly string[] {
    return this.membersOf(name).filter(isRemoteMemberRef)
  }

  /** Every team name the id is a member of, in team creation order. */
  teamsOf(id: string): readonly string[] {
    return this.teams.filter(t => t.members.includes(id)).map(t => t.name)
  }

  /**
   * Create a named team; whitespace trims, duplicates are idempotent, and
   * the cap rejects a team beyond {@link CANVAS_TEAM_CAP}.
   * @param name - the raw user-supplied name.
   * @returns the stored name, or undefined when rejected.
   */
  create(name: string): string | undefined {
    const clean = validName(name)
    if (clean === undefined) return undefined
    if (this.hasTeam(clean)) return clean
    if (this.teams.length >= CANVAS_TEAM_CAP) return undefined
    this.teams.push({ name: clean, members: [] })
    this.persist()
    return clean
  }

  /**
   * Delete a team (with its memberships).
   * @param name - the team name.
   */
  remove(name: string): boolean {
    const index = this.teams.findIndex(t => t.name === name)
    if (index < 0) return false
    const [removed] = this.teams.splice(index, 1)
    for (const id of removed!.members) this.forgetUnusedHome(id)
    this.persist()
    return true
  }

  /**
   * Add one member (idempotent; duplicates keep the original priority slot).
   * The team must exist — callers create it first so the cap applies once.
   * @param name - the existing team name.
   * @param id - the member session id.
   */
  addMember(name: string, id: string, home?: string, options: { replaceHome?: boolean } = {}): boolean {
    if (id === '' || (home !== undefined && (!CLI_HANDLE_RE.test(id) || !validHomeOrigin(home)))) return false
    if (home !== undefined && this.cliHome[id] !== undefined && this.cliHome[id] !== home && options.replaceHome !== true) return false
    const entry = this.teams.find(t => t.name === name)
    if (entry === undefined) return false
    if (entry.members.includes(id)) {
      if (home !== undefined && this.cliHome[id] !== home) { this.cliHome[id] = home; this.persist() }
      return true
    }
    if (entry.members.length >= CANVAS_MEMBER_CAP) return false
    entry.members.push(id)
    if (home !== undefined) this.cliHome[id] = home
    this.persist()
    return true
  }

  /**
   * Remove one member from one team (a no-op when absent).
   */
  removeMember(name: string, id: string): boolean {
    const entry = this.teams.find(t => t.name === name)
    if (entry === undefined) return false
    const index = entry.members.indexOf(id)
    if (index < 0) return false
    entry.members.splice(index, 1)
    this.forgetUnusedHome(id)
    this.persist()
    return true
  }

  private forgetUnusedHome(id: string): void {
    if (!this.teams.some(team => team.members.includes(id))) delete this.cliHome[id]
  }

  /**
   * Drop one id from every team — the leave and archive paths: a session
   * leaving the network keeps no canvas membership anywhere.
   * @param id - the departing session id.
   */
  dropMember(id: string): void {
    let dirty = false
    for (const entry of this.teams) {
      const index = entry.members.indexOf(id)
      if (index >= 0) {
        entry.members.splice(index, 1)
        dirty = true
      }
    }
    if (dirty) { this.forgetUnusedHome(id); this.persist() }
  }
}

/** One policy predicate for local and signed-remote canvas creation. */
export function canvasNameReserved(raw: string, zone: string, allowlist: readonly string[], roster: { membersOf(team: string): readonly string[] }): boolean {
  const name = raw.trim()
  const team = `${zone}/${name}`
  return name.startsWith('roster:') || allowlist.includes(team) || roster.membersOf(team).length > 0
}

function validHomeOrigin(raw: string): boolean {
  try { const url = new URL(raw); return (url.protocol === 'http:' || url.protocol === 'https:') && url.origin === raw }
  catch { return false }
}
