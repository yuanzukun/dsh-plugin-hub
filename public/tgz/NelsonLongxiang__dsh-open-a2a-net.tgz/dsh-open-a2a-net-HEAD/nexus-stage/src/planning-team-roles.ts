/**
 * Design v5 (D6): the planning view shows which canvas is the superagent team and who plays which role in it.
 *
 * The planning view stays unaware of superagent: it hands its frame and card elements to `decorate` after each render,
 * and the 团队 poll hands the team's state to `update`. The bound canvas's frame is marked `superagent 团队`; the router's
 * card says 总工, each member's card says 成员 (and its repository), a member on another host adding （远端）.
 * The role has a line of its own between the name and the description, so neither crowds the other out of the 172px card.
 * @module nexus-stage/planning-team-roles
 */
import type { SaState } from './wb-superagent'

/** Who plays which role in the bound team canvas, read from the team's state. */
export interface TeamRoles {
  readonly canvas: string
  readonly router?: string
  /** Each local member's session id, with its repository when the owner named one. */
  readonly members: ReadonlyMap<string, string | undefined>
  /** The local members who may also open tickets. */
  readonly observers: ReadonlySet<string>
  /** Each remote member by its planning card id, with its repository when the owner named one. */
  readonly remote: ReadonlyMap<string, string | undefined>
  /** Each member's role and rules, by planning card id, for its tooltip. */
  readonly tips: ReadonlyMap<string, string>
}

/** The planning card id of a remote member ref (see planning-member-handles). */
const remoteCardId = (ref: string): string => `member-${ref.replace(/[^a-z0-9-]/gi, '-')}`

/** What a member's tooltip adds: its role and enabled rules. */
const profileTip = (profile: { readonly role?: string; readonly rules: ReadonlyArray<{ readonly name: string; readonly text: string; readonly enabled: boolean }> } | undefined): string =>
  profile === undefined ? '' : [...(profile.role !== undefined ? [`角色：${profile.role}`] : []), ...profile.rules.filter(r => r.enabled).map(r => `规则 ${r.name}：${r.text}`)].join('\n')

export function teamRolesOf(state: SaState | null): TeamRoles | undefined {
  const s = state?.settings
  if (s === undefined || s.canvas === undefined) return undefined
  return { canvas: s.canvas, ...(s.router !== undefined ? { router: s.router } : {}), members: new Map(s.members.map(id => [id, s.repos?.[id]])), observers: new Set(s.observers ?? []), remote: new Map(s.remoteMembers.map(r => [remoteCardId(r.ref), s.repos?.[r.ref]])), tips: new Map([...s.members.map(id => [id, profileTip(s.profiles?.[id])] as const), ...s.remoteMembers.map(r => [remoteCardId(r.ref), profileTip(s.profiles?.[r.ref])] as const)].filter(([, tip]) => tip !== '')) }
}

/** What the badge shows of a role: the repository without its owner. The tooltip has it whole. */
export const roleLabel = (text: string): string => text.replace(/ · [^/（]+\//, ' · ')

/** The role badge a card shows, if any. */
export function roleText(roles: TeamRoles | undefined, id: string): string | undefined {
  if (roles === undefined) return undefined
  if (roles.router === id) return '总工'
  if (roles.remote.has(id)) { const repo = roles.remote.get(id); return repo !== undefined ? `成员 · ${repo}（远端）` : '成员（远端）' }
  if (!roles.members.has(id)) return undefined
  const repo = roles.members.get(id), name = roles.observers.has(id) ? '观察者' : '成员'
  return repo !== undefined ? `${name} · ${repo}` : name
}

export interface TeamRoleDecorator {
  /** The teams' latest states: every team on this instance (null: this host runs no team). */
  update(states: SaState | null | readonly SaState[]): void
  /** The planning view rendered: mark its frames and cards. */
  decorate(frames: ReadonlyMap<string, HTMLElement>, nodes: ReadonlyMap<string, HTMLElement>): void
}

export function createTeamRoleDecorator(): TeamRoleDecorator {
  let teams: readonly TeamRoles[] = []
  /** A card has one role across all teams (one session, one team role), so the first team that names it is the one. */
  const roleOf = (id: string): { text: string; tip?: string } | undefined => {
    for (const roles of teams) { const text = roleText(roles, id); if (text !== undefined) return { text, ...(roles.tips.has(id) ? { tip: roles.tips.get(id)! } : {}) } }
    return undefined
  }
  let frames: ReadonlyMap<string, HTMLElement> | undefined
  let nodes: ReadonlyMap<string, HTMLElement> | undefined
  const badge = (host: Element, cls: string, text: string | undefined, tip?: string): void => {
    let el = host.querySelector<HTMLElement>(`:scope > .${cls}`)
    if (text === undefined) { el?.remove(); return }
    if (el === null) { el = document.createElement('span'); el.className = cls; host.appendChild(el) }
    if (el.textContent !== text) el.textContent = text
    if (tip !== undefined && el.title !== tip) el.title = tip
  }
  const apply = (): void => {
    for (const [name, el] of frames ?? []) {
      const team = teams.some(roles => roles.canvas === name)
      el.classList.toggle('is-superagent-team', team)
      const head = el.querySelector('.p-frame-head')
      if (head !== null) badge(head, 'sa-team', team ? 'superagent 团队' : undefined)
    }
    for (const [id, el] of nodes ?? []) {
      const role = roleOf(id), text = role?.text
      el.classList.toggle('is-superagent-router', text === '总工')
      el.classList.toggle('is-superagent-member', text?.startsWith('成员') === true || text?.startsWith('观察者') === true)
      badge(el, 'sa-role', text === undefined ? undefined : roleLabel(text), text)
      // The card's own tooltip is written on each render, before this runs: add to it once.
      const tip = role?.tip
      if (tip !== undefined && !el.title.endsWith(tip)) el.title = `${el.title}\n${tip}`
    }
  }
  return {
    update(states) {
      const list = states === null ? [] : 'settings' in states ? [states as SaState] : [...states as readonly SaState[]]
      teams = list.flatMap(state => { const roles = teamRolesOf(state); return roles === undefined ? [] : [roles] })
      apply()
    },
    decorate(f, n) { frames = f; nodes = n; apply() },
  }
}
