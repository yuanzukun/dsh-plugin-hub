/**
 * #120 (#114 S2): the immutable authorization record of an inbound row —
 * one constructor, frozen; a strict all-or-nothing restore allowlist; born
 * on inbound rows only, kept by first-record-wins, carried through every
 * archive path; a pre-S2 tasks.json loads unchanged.
 */
import { mkdtempSync } from '../temp-dirs.ts'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { describe, expect, it } from 'vitest'
import { AUTH_BASIS_CAP, AUTH_CLOCK_SKEW_MS, AUTH_STRING_CAP, buildAuthorization, claimCovers, parseAuthorization, type TaskAuthorization } from '../../src/task-auth.ts'
import { TaskLedger } from '../../src/task-ledger.ts'

const HANDLE = 'ops-cli/a1b2c3d4e5f60718'

function ledgerPath(): string {
  return join(mkdtempSync(join(tmpdir(), 'dsh-a2a-auth-')), 'a2a', 'tasks.json')
}

function writeSnapshot(path: string, snapshot: unknown): void {
  mkdirSync(dirname(path), { recursive: true })
  writeFileSync(path, JSON.stringify(snapshot))
}

const AUTH: TaskAuthorization = buildAuthorization(
  { ok: true, via: 'canvas-member', rule: 'canvas-shared', basis: ['dsh/canvas/ops', 'peer-org:dsh/canvas/far'] },
  {
    caller: 'dsh/aaaaaaaa', proof: 'origin-claim', claim: { caller: 'dsh', origin: 'http://100.64.0.10:13080' },
    ingress: 'wire', allowlistVersion: 'al1:0123456789abcdef', target: 'dsh/bbbbbbbb', receiptTarget: 'dsh/aaaaaaaa',
    receivedAt: 1_700_000_000_000, targetBusy: true,
  },
)

describe('#120 buildAuthorization / parseAuthorization', () => {
  it('builds a frozen record (nested values too) with via derived from the rule', () => {
    expect(AUTH).toEqual({
      v: 1, caller: 'dsh/aaaaaaaa', proof: 'origin-claim', claim: { caller: 'dsh', origin: 'http://100.64.0.10:13080' },
      ingress: 'wire', via: 'canvas-member', admission_rule: 'canvas-shared', basis: ['dsh/canvas/ops', 'peer-org:dsh/canvas/far'],
      allowlist_version: 'al1:0123456789abcdef', target: 'dsh/bbbbbbbb', receipt_target: 'dsh/aaaaaaaa', received_at: 1_700_000_000_000, target_busy: true,
    })
    expect(Object.isFrozen(AUTH)).toBe(true)
    expect(Object.isFrozen(AUTH.basis)).toBe(true)
    expect(Object.isFrozen(AUTH.claim)).toBe(true)
    const quiet = buildAuthorization({ ok: true, via: 'cli-deposit', rule: 'cli-deposit', basis: [] }, { caller: 'x', proof: 'legacy-window', ingress: 'wire', allowlistVersion: 'al1:0123456789abcdef', target: 't', receiptTarget: 'x', receivedAt: 1 })
    expect(quiet).not.toHaveProperty('claim')
    expect(quiet).not.toHaveProperty('target_busy')
  })

  it('remote CLI stores a distinct carrier_url, preserving the existing via enum and rejecting forged restore', () => {
    const auth = buildAuthorization({ ok: true, via: 'canvas-member', rule: 'remote-ref-cli', basis: ['dsh/canvas/ops'] }, {
      caller: HANDLE, proof: 'origin-claim', claim: { caller: 'home-zone', origin: 'https://home.example' }, carrierUrl: 'https://home.example',
      ingress: 'wire', allowlistVersion: 'al1:0123456789abcdef', target: 'dsh/aaaaaaaa', receiptTarget: HANDLE, receivedAt: 1,
    })
    expect(auth.via).toBe('canvas-member')
    expect(auth.carrier_url).toBe('https://home.example')
    expect(parseAuthorization(JSON.parse(JSON.stringify(auth)))).toEqual(auth)
    for (const variant of [
      { ...auth, carrier_url: undefined }, { ...auth, carrier_url: 'https://other.example' },
      { ...auth, carrier_url: 'https://home.example/path' }, { ...auth, proof: 'legacy-window' },
      { ...auth, via: 'open' },
    ]) expect(parseAuthorization(variant)).toBeUndefined()
  })

  it('round-trips through JSON exactly, including a claim-mismatch record', () => {
    expect(parseAuthorization(JSON.parse(JSON.stringify(AUTH)))).toEqual(AUTH)
    const mismatch = buildAuthorization({ ok: true, via: 'host-face', rule: 'host-face', basis: [] }, {
      caller: 'dsh', proof: 'claim-mismatch', claim: { caller: 'far', origin: 'http://far' }, ingress: 'wire',
      allowlistVersion: 'al1:0123456789abcdef', target: 'dsh/bbbbbbbb', receiptTarget: 'dsh', receivedAt: 1,
    })
    expect(parseAuthorization(JSON.parse(JSON.stringify(mismatch)))).toEqual(mismatch)
  })

  it('round-trips low-trust unbound and deposited-CLI claims through restore', () => {
    for (const proof of ['unbound', 'cli-identity'] as const) {
      const caller = proof === 'cli-identity' ? HANDLE : 'market/aaaaaaaa'
      const claimCaller = proof === 'cli-identity' ? HANDLE : 'market'
      const rule = proof === 'cli-identity' ? 'cli-deposit' : 'scope-off'
      const via = proof === 'cli-identity' ? 'cli-deposit' : 'open'
      const auth = buildAuthorization({ ok: true, via, rule, basis: [] }, {
        caller, proof, claim: { caller: claimCaller, origin: 'https://issuer.example' }, ingress: 'wire',
        allowlistVersion: 'al1:0123456789abcdef', target: 'dsh/bbbbbbbb', receiptTarget: caller, receivedAt: 1,
      })
      expect(parseAuthorization(JSON.parse(JSON.stringify(auth)))).toEqual(auth)
    }
  })

  it('claimCovers: the same zone, or a handle under it — never a prefix without the slash', () => {
    expect(claimCovers('dsh', 'dsh')).toBe(true)
    expect(claimCovers('dsh/aaaaaaaa', 'dsh')).toBe(true)
    expect(claimCovers('ops-cli/a1b2c3d4e5f60718', 'ops-cli')).toBe(true)
    expect(claimCovers('dsh', 'far')).toBe(false)
    expect(claimCovers('dshx/aaaaaaaa', 'dsh')).toBe(false)
    expect(claimCovers('dsh', '')).toBe(false)
  })

  it('drops the whole record when any field is out of its closed set or bounds — never a partial adoption', () => {
    const json = JSON.parse(JSON.stringify(AUTH)) as Record<string, unknown>
    const bad: Array<Record<string, unknown>> = [
      { ...json, v: 2 },
      { ...json, proof: 'trust-me' },
      { ...json, ingress: 'relay' },
      { ...json, admission_rule: 'anyone' },
      { ...json, via: 'open' }, // via must be the rule's own basis
      { ...json, basis: 'dsh/canvas/ops' },
      { ...json, basis: Array.from({ length: AUTH_BASIS_CAP + 1 }, (_, i) => `t${String(i)}`) },
      { ...json, basis: [''] },
      { ...json, allowlist_version: 'al2:0123456789abcdef' },
      { ...json, target: '' },
      { ...json, caller: 'x'.repeat(AUTH_STRING_CAP + 1) },
      { ...json, received_at: -1 },
      { ...json, target_busy: false },
      { ...json, claim: undefined }, // origin-claim without its claim
      { ...json, proof: 'none' }, // claims cannot accompany a proof that has no claim evidence
      { ...json, claim: { caller: 'dsh' } },
      // Review of PR #134 P2: combinations admission could never have produced.
      { ...json, caller: '' }, // admission refuses anonymous callers
      { ...json, receipt_target: '' },
      { ...json, basis: [] }, // a shared-team rule with no shared team
      { ...json, basis: ['dsh/canvas/ops', 'dsh/canvas/ops'] },
      { ...json, admission_rule: 'cli-deposit', via: 'cli-deposit' }, // a non-shared rule with a basis
      { ...json, proof: 'in-process', claim: undefined }, // in-process on the wire
      { ...json, ingress: 'local' }, // local is in-process only
      { ...json, admission_rule: 'local-exempt', via: 'host-face', basis: [], proof: 'legacy-window', claim: undefined },
      { ...json, received_at: Date.now() + AUTH_CLOCK_SKEW_MS + 60_000 },
      { ...json, received_at: 1.5 },
      // Review of PR #134 P1: coverage, not the record, decides origin-claim vs claim-mismatch.
      { ...json, claim: { caller: 'far', origin: 'http://far' } },
      { ...json, proof: 'origin-claim', claim: { caller: 'far', origin: 'http://far' } },
    ]
    for (const raw of bad) expect(parseAuthorization(raw), JSON.stringify(raw)).toBeUndefined()
    expect(parseAuthorization(null)).toBeUndefined()
    expect(parseAuthorization([AUTH])).toBeUndefined()
  })
})

describe('#120 auth on ledger rows', () => {
  it('is born on inbound rows; a replayed id keeps the first record', () => {
    const ledger = new TaskLedger('')
    ledger.trackInbound('direct-in', 'dsh/bbbbbbbb', 'dsh/aaaaaaaa', undefined, true, 'b', AUTH)
    const other = buildAuthorization({ ok: true, via: 'open', rule: 'scope-off', basis: [] }, { caller: 'dsh/zzzzzzzz', proof: 'none', ingress: 'wire', allowlistVersion: 'al1:ffffffffffffffff', target: 'dsh/bbbbbbbb', receiptTarget: 'dsh/zzzzzzzz', receivedAt: 2 })
    ledger.trackInbound('direct-in', 'dsh/bbbbbbbb', 'dsh/zzzzzzzz', undefined, true, 'b', other)
    expect(ledger.list()).toHaveLength(1)
    expect(ledger.list()[0]?.auth).toBe(AUTH)
    ledger.trackInbound('direct-plain', 'dsh/bbbbbbbb', 'dsh/aaaaaaaa')
    expect(ledger.list().find(r => r.taskId === 'direct-plain')).not.toHaveProperty('auth')
  })

  it('is carried through archiving (receipt, abandon) and round-trips persistence', () => {
    const path = ledgerPath()
    const first = new TaskLedger(path)
    first.trackInbound('direct-r', 'dsh/bbbbbbbb', 'dsh/aaaaaaaa', undefined, true, 'b', AUTH)
    first.trackInbound('direct-ab', 'dsh/bbbbbbbb', 'dsh/aaaaaaaa', undefined, true, 'b', AUTH)
    first.trackInbound('direct-live', 'dsh/bbbbbbbb', 'dsh/aaaaaaaa', undefined, true, 'b', AUTH)
    first.resolveFromMessage('[A2A receipt] task direct-r done')
    first.abandon('direct-ab')
    const archived = new Map(first.archive().map(row => [row.taskId, row]))
    expect(archived.get('direct-r')?.auth).toEqual(AUTH)
    expect(archived.get('direct-ab')?.auth).toEqual(AUTH)
    const second = new TaskLedger(path)
    expect(second.list().find(r => r.taskId === 'direct-live')?.auth).toEqual(AUTH)
    expect(new Map(second.archive().map(row => [row.taskId, row])).get('direct-r')?.auth).toEqual(AUTH)
  })

  it('unbound and cli-identity claims survive a TaskLedger restart without gaining origin trust', () => {
    const path = ledgerPath()
    const lowTrust = (proof: 'unbound' | 'cli-identity'): TaskAuthorization => {
      const cli = proof === 'cli-identity'
      const caller = cli ? HANDLE : 'market/aaaaaaaa'
      const rule = cli ? 'cli-deposit' : 'scope-off'
      const via = cli ? 'cli-deposit' : 'open'
      return buildAuthorization({ ok: true, via, rule, basis: [] }, {
        caller, proof, claim: { caller: cli ? HANDLE : 'market', origin: 'https://issuer.example' }, ingress: 'wire', allowlistVersion: 'al1:0123456789abcdef', target: 'dsh/bbbbbbbb', receiptTarget: caller, receivedAt: 1,
      })
    }
    const first = new TaskLedger(path)
    for (const proof of ['unbound', 'cli-identity'] as const) {
      const auth = lowTrust(proof)
      const taskId = `direct-restore-${proof}`
      first.trackInbound(taskId, 'dsh/bbbbbbbb', auth.caller, undefined, true, 'first', auth)
      expect(new TaskLedger(path).list().find(row => row.taskId === taskId)?.auth).toEqual(auth)
    }
  })

  it('re-review P3: restore bounds received_at by the ledger\'s own clock, not the wall clock', () => {
    const path = ledgerPath()
    const ahead = Date.now() + 10 * 24 * 60 * 60 * 1000
    const born = buildAuthorization({ ok: true, via: 'cli-deposit', rule: 'cli-deposit', basis: [] }, {
      caller: 'ops-cli/a1b2c3d4e5f60718', proof: 'legacy-window', ingress: 'wire', allowlistVersion: 'al1:0123456789abcdef',
      target: 'dsh/bbbbbbbb', receiptTarget: 'ops-cli/a1b2c3d4e5f60718', receivedAt: ahead,
    })
    new TaskLedger(path, { now: () => ahead }).trackInbound('direct-clock', 'dsh/bbbbbbbb', 'ops-cli/a1b2c3d4e5f60718', undefined, true, 'b', born)
    expect(new TaskLedger(path, { now: () => ahead }).list()[0]?.auth).toEqual(born)
  })

  it('restore drops a record that belongs to another row (target or receipt target differ)', () => {
    const path = ledgerPath()
    const good = JSON.parse(JSON.stringify(AUTH)) as Record<string, unknown>
    writeSnapshot(path, {
      tasks: [
        { taskId: 'direct-t', team: 'dsh/cccccccc', peer: 'local:dsh/aaaaaaaa', startedAt: Date.now(), status: 'pending', direction: 'inbound', auth: good },
        { taskId: 'direct-p', team: 'dsh/bbbbbbbb', peer: 'local:dsh/zzzzzzzz', startedAt: Date.now(), status: 'pending', direction: 'inbound', auth: good },
        { taskId: 'direct-ok', team: 'dsh/bbbbbbbb', peer: 'local:dsh/aaaaaaaa', startedAt: Date.now(), status: 'pending', direction: 'inbound', auth: good },
      ],
      archived: [],
    })
    const byId = new Map(new TaskLedger(path).list().map(row => [row.taskId, row]))
    expect(byId.get('direct-t')).not.toHaveProperty('auth')
    expect(byId.get('direct-p')).not.toHaveProperty('auth')
    expect(byId.get('direct-ok')?.auth).toEqual(AUTH)
  })

  it('restore drops a malformed record whole and keeps the row; outbound rows never take one; pre-S2 files load unchanged', () => {
    const path = ledgerPath()
    const good = JSON.parse(JSON.stringify(AUTH)) as Record<string, unknown>
    writeSnapshot(path, {
      tasks: [
        { taskId: 'direct-bad', team: 'dsh/bbbbbbbb', peer: 'local:dsh/aaaaaaaa', startedAt: Date.now(), status: 'pending', direction: 'inbound', auth: { ...good, proof: 'trust-me' } },
        { taskId: 'direct-out', team: 'ops', peer: 'local', startedAt: Date.now(), status: 'pending', auth: good },
        { taskId: 'direct-old', team: 'dsh/bbbbbbbb', peer: 'local:dsh/aaaaaaaa', startedAt: Date.now(), status: 'pending', direction: 'inbound' },
      ],
      archived: [],
    })
    const ledger = new TaskLedger(path)
    const byId = new Map(ledger.list().map(row => [row.taskId, row]))
    expect(byId.get('direct-bad')).toBeDefined()
    expect(byId.get('direct-bad')).not.toHaveProperty('auth')
    expect(byId.get('direct-out')).not.toHaveProperty('auth')
    expect(byId.get('direct-old')).not.toHaveProperty('auth')
    // The next write carries no trace of the dropped record.
    ledger.trackInbound('direct-new', 'dsh/bbbbbbbb', 'dsh/aaaaaaaa')
    expect(readFileSync(path, 'utf8')).not.toContain('trust-me')
  })
})
