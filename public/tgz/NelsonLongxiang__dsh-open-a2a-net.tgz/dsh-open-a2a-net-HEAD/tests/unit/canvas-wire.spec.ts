/**
 * The canvas wire over an injected transport: sequencing (create → add per
 * id, first failure stops), notice classification (error verbatim,
 * error-less ok:false requires state-proven idempotence, transport throws, HTTP
 * >= 400), the reorder op channel, and per-team serialization with
 * cross-team parallelism.
 */
import { describe, expect, it } from 'vitest'
import { createCanvasWire, type CanvasWireResult } from '../../nexus-stage/src/canvas-wire.ts'

interface Fixture {
  bodies: unknown[]
  notices: Array<{ kind: 'error' | 'info'; text: string }>
  respond: (res: CanvasWireResult | 'throw') => Promise<void>
  settleAll: () => Promise<void>
}

function fixture(auto?: CanvasWireResult): { f: Fixture; wire: ReturnType<typeof createCanvasWire> } {
  const f: Fixture = {
    bodies: [],
    notices: [],
    respond: async () => {},
    settleAll: async () => {},
  }
  let release: ((res: CanvasWireResult | 'throw') => void) | undefined
  const wire = createCanvasWire({
    send: (body) => new Promise<CanvasWireResult>((resolve, reject) => {
      f.bodies.push(body)
      if (auto !== undefined) resolve(auto)
      else release = (res) => { if (res === 'throw') reject(new Error('network down')); else resolve(res) }
    }),
    onNotice: (kind, text) => { f.notices.push({ kind, text }) },
  })
  f.respond = async (res) => {
    // The queue task (and its send) may not have run yet — wait for the
    // release to appear before resolving, or the respond is lost.
    for (let i = 0; i < 50 && release === undefined; i++) await Promise.resolve()
    release?.(res)
    release = undefined
    await Promise.resolve()
    await Promise.resolve()
    await Promise.resolve()
  }
  f.settleAll = async () => {
    for (let i = 0; i < 24; i++) await Promise.resolve()
  }
  return { f, wire }
}

const ok: CanvasWireResult = { status: 200, body: { ok: true, teams: [] } }

describe('canvas wire', () => {
  it('sequences create → add-member per id, in order', async () => {
    const { f, wire } = fixture(ok)
    const done = wire.createTeam('采购', ['a', 'b'])
    await f.respond(ok)
    expect(await done).toBe(true)
    expect(f.bodies).toEqual([
      { action: 'create', name: '采购' },
      { action: 'add-member', name: '采购', id: 'a' },
      { action: 'add-member', name: '采购', id: 'b' },
    ])
  })

  it('surfaces a create rejection verbatim and never sends member adds', async () => {
    const { f, wire } = fixture({ status: 200, body: { ok: false, error: 'invalid name or team cap reached' } })
    const done = wire.createTeam('a/b', ['x', 'y'])
    await f.respond({ status: 200, body: { ok: false, error: 'invalid name or team cap reached' } })
    expect(await done).toBe(false)
    expect(f.notices).toEqual([{ kind: 'error', text: 'invalid name or team cap reached' }])
    expect(f.bodies).toHaveLength(1) // no add-member attempts
  })

  it('stops the serial adds on the first failing member', async () => {
    const { f, wire } = fixture()
    const done = wire.addMembers('甲', ['a', 'bad', 'c'])
    await f.respond(ok) // 'a' goes through
    await f.respond({ status: 200, body: { ok: false, error: 'name and a joined session id are required' } })
    expect(await done).toBe(false)
    expect(f.bodies).toHaveLength(2) // a ok, bad refused, c never sent
    expect(f.notices).toEqual([{ kind: 'error', text: 'name and a joined session id are required' }])
  })

  it('treats error-less ok:false as idempotent success, silently', async () => {
    const { f, wire } = fixture({ status: 200, body: { ok: false, teams: [], members: [] } })
    expect(await wire.removeTeam('不存在')).toBe(true)
    expect(await wire.removeMembers('甲', ['ghost'])).toBe(true)
    expect(f.notices).toEqual([])
  })

  it('gh108: a bare false member-cap refusal is NOT a successful join', async () => {
    const { f, wire } = fixture({ status: 200, body: { ok: false, teams: ['甲'], members: ['existing'] } })
    expect(await wire.addMembers('甲', ['new-member'])).toBe(false)
    expect(f.notices[0]?.kind).toBe('error')
  })

  it('gh108: a missing or malformed success body is not proof of a write', async () => {
    const { f, wire } = fixture({ status: 200, body: {} })
    expect(await wire.createTeam('新队', [])).toBe(false)
    expect(f.notices).toHaveLength(1)
  })

  it('gh108: a null JSON body is a visible refusal, not an uncaught action failure', async () => {
    const { f, wire } = fixture({ status: 200, body: null as unknown as CanvasWireResult['body'] })
    expect(await wire.createTeam('新队', [])).toBe(false)
    expect(f.notices[0]?.kind).toBe('error')
  })

  it.each(['a', { includes: true }, [null]])('gh108: malformed membership proof %s cannot acknowledge a join', async members => {
    const { f, wire } = fixture({ status: 200, body: { ok: false, members } as unknown as CanvasWireResult['body'] })
    expect(await wire.addMembers('甲', ['a'])).toBe(false)
    expect(f.notices[0]?.kind).toBe('error')
  })

  it('gh108: malformed team list cannot acknowledge a dissolve', async () => {
    const { f, wire } = fixture({ status: 200, body: { ok: false, teams: 'other' } as unknown as CanvasWireResult['body'] })
    expect(await wire.removeTeam('甲')).toBe(false)
    expect(f.notices[0]?.kind).toBe('error')
  })

  it('gh108: an acknowledged duplicate member is a verified idempotent join', async () => {
    const { f, wire } = fixture({ status: 200, body: { ok: false, teams: ['甲'], members: ['a'] } })
    expect(await wire.addMembers('甲', ['a'])).toBe(true)
    expect(f.notices).toEqual([])
  })

  it('gh108: a cap refusal never authorizes destructive compensation from a local created hint', async () => {
    const { f, wire } = fixture()
    const result = wire.createTeam('新队', ['a'], true)
    await f.respond(ok)
    await f.respond({ status: 200, body: { ok: false, teams: ['新队'], members: [] } })
    expect(await result).toBe(false)
    expect(f.bodies).toEqual([{ action: 'create', name: '新队' }, { action: 'add-member', name: '新队', id: 'a' }])
  })

  it('classifies transport throws and bare HTTP errors', async () => {
    const { f, wire } = fixture()
    const first = wire.removeTeam('甲')
    await f.respond('throw')
    expect(await first).toBe(false)
    expect(f.notices[0]).toEqual({ kind: 'error', text: '画布不可达：network down' })

    const second = wire.removeTeam('甲')
    await f.respond({ status: 400, body: { error: 'malformed body' } })
    expect(await second).toBe(false)
    expect(f.notices[1]).toEqual({ kind: 'error', text: 'malformed body' })

    const third = wire.removeTeam('甲')
    await f.respond({ status: 500, body: {} })
    expect(await third).toBe(false)
    expect(f.notices[2]).toEqual({ kind: 'error', text: 'HTTP 500' })
  })

  it('runs roster ops in order (reorder channel)', async () => {
    const { f, wire } = fixture(ok)
    const done = wire.runRosterOps('甲', [
      { op: 'remove', id: 'c' }, { op: 'add', id: 'c' },
    ])
    await f.respond(ok)
    await f.respond(ok)
    expect(await done).toBe(true)
    expect(f.bodies).toEqual([
      { action: 'remove-member', name: '甲', id: 'c' },
      { action: 'add-member', name: '甲', id: 'c' },
    ])
  })

  it('serializes same-team ops but lets other teams run in parallel', async () => {
    let releaseA: (() => void) | undefined
    let seenWhileBlocked: string[] = []
    const wire = createCanvasWire({
      send: (body) => new Promise<CanvasWireResult>((resolve) => {
        const b = body as { name?: string }
        if (b.name === '甲' && !releaseA) {
          releaseA = () => resolve({ status: 200, body: { ok: true } })
        } else if (b.name === '甲') {
          // Same-team second request: must not exist until the first settles.
          seenWhileBlocked.push('甲-second')
          resolve({ status: 200, body: { ok: true } })
        } else {
          seenWhileBlocked.push(String(b.name))
          resolve({ status: 200, body: { ok: true } })
        }
      }),
      onNotice: () => {},
    })
    const first = wire.addMembers('甲', ['a'])
    // Wait a microtask: the first 甲 request is in flight, unresolved.
    await Promise.resolve()
    const queued = wire.addMembers('甲', ['b'])
    const other = wire.addMembers('乙', ['x'])
    await other
    expect(seenWhileBlocked).toContain('乙') // cross-team ran in parallel
    expect(seenWhileBlocked).not.toContain('甲-second')
    releaseA?.()
    await first
    await queued
    expect(seenWhileBlocked).toContain('甲-second') // queued until the first settled
    expect(wire.hasPending()).toBe(false)
  })

  it('create-team keeps server state on first-add failure even when the local model said created=true', async () => {
    const { f, wire } = fixture()
    const done = wire.createTeam('新队', ['a', 'b'], true)
    await f.respond(ok) // create ok
    await f.respond({ status: 200, body: { ok: false, error: 'name and a joined session id are required' } }) // first add fails
    expect(await done).toBe(false)
    expect(f.bodies).toHaveLength(2) // create + refused add, NO remove of unowned data
    expect(f.notices).toHaveLength(1) // the original error, verbatim
  })

  it('a pre-existing team is NOT removed on first-add failure (created=false)', async () => {
    const { f, wire } = fixture()
    const done = wire.createTeam('旧队', ['a', 'b'], false)
    await f.respond(ok)
    await f.respond({ status: 200, body: { ok: false, error: 'name and a joined session id are required' } })
    expect(await done).toBe(false)
    expect(f.bodies).toHaveLength(2) // no compensating remove over user data
  })

  it('a mid-sequence failure keeps genuinely joined members (no ghost remove)', async () => {
    const { f, wire } = fixture()
    const done = wire.createTeam('新队', ['a', 'b'], true)
    await f.respond(ok) // create
    await f.respond(ok) // first add succeeded — the team is no longer empty
    await f.respond({ status: 200, body: { ok: false, error: 'x' } }) // second add fails
    expect(await done).toBe(false)
    expect(f.bodies).toHaveLength(3)
    expect(f.bodies[2]).toEqual({ action: 'add-member', name: '新队', id: 'b' }) // no remove emitted
  })

  it('hasPending tracks in-flight work', async () => {
    const { f, wire } = fixture()
    expect(wire.hasPending()).toBe(false)
    const done = wire.addMembers('甲', ['a'])
    expect(wire.hasPending()).toBe(true)
    await f.respond(ok)
    await done
    expect(wire.hasPending()).toBe(false)
  })
})
