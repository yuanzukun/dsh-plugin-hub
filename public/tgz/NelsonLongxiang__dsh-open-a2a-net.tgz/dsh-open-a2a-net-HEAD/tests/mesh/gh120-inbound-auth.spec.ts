// @vitest-environment node
/**
 * #114 S2 on a real host: an inbound /a2a/direct delivery is born with its
 * immutable authorization record — the caller, how its identity was proven,
 * the rule and basis that admitted it, and the allowlist version at that
 * instant — /state shows it, a replay of the id cannot overwrite it, and a
 * restart restores it whole.
 */
import { describe, expect, it, vi, beforeEach, afterEach } from 'vitest'
import { generateKeyPairSync } from 'node:crypto'
import { createServer } from 'node:http'
import { bootNode, reservePort, steerText, tmpHome } from './harness.ts'
import { signCard } from '../../src/card.ts'
import { signOriginClaim } from '../../src/origin-claim.ts'

const { privateKey } = generateKeyPairSync('ed25519')
const HANDLE = 'ops-cli/a1b2c3d4e5f60718'
const TARGET = 'dsh/01234567'

beforeEach(() => {
  vi.stubGlobal('WebSocket', function throwOnSocket() { throw new Error('no socket') })
})
afterEach(() => { vi.unstubAllGlobals() })

const post = async (url: string, body: unknown, headers: Record<string, string> = {}): Promise<{ status: number; body: Record<string, any> }> =>
  await globalThis.fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body) })
    .then(async r => ({ status: r.status, body: await r.json().catch(() => ({})) as Record<string, any> }))

describe('#114 S2 inbound authorization record (real host)', () => {
  it('born on the row, shown on /state, not overwritten by a replay, restored whole after a restart', async () => {
    const port = await reservePort()
    const home = tmpHome()
    let a = await bootNode({ name: 'A', session: 'mesh-gh120', team: 'dsh', sessionNodes: true, teamScopeRouting: true, port, home })
    try {
      expect((await post(`${a.baseUrl}/__dsh_a2a/join`, { id: 'session-0123456789abcdef' })).status).toBe(200)
      const card = signCard({ name: 'ops-cli', session: 'cli-ops-cli', team: HANDLE, capabilities: { route: true, async: true }, expiresAt: Date.now() + 172_800_000 }, privateKey)
      expect((await post(`${a.baseUrl}/__dsh_a2a/cli-deposit`, { action: 'publish', card: JSON.stringify(card) })).body.ok).toBe(true)
      // An envelope-less CLI-deposit delivery is intentionally legacy; valid CLI signatures are covered by gh133.
      const body = { team: TARGET, message: 'signed task', caller_session: HANDLE, wait: false, task_id: 'direct-aaaa00000001' }
      const sent = await post(`${a.baseUrl}/a2a/direct`, body)
      expect(sent.body, JSON.stringify(sent.body)).toMatchObject({ delivered: true })

      // A keep-alive socket to the pre-restart server may be reset once: read again.
      const rowOf = async (taskId: string): Promise<Record<string, any> | undefined> => {
        for (let attempt = 0; ; attempt += 1) {
          try {
            return ((await globalThis.fetch(`${a.baseUrl}/__dsh_a2a/state`).then(async r => await r.json())) as { tasks: Array<Record<string, any>> }).tasks.find(t => t.taskId === taskId)
          } catch (error) {
            if (attempt >= 3) throw error
            await new Promise(resolve => setTimeout(resolve, 50))
          }
        }
      }
      const row = await rowOf('direct-aaaa00000001')
      expect(row?.direction).toBe('inbound')
      expect(row?.auth).toMatchObject({
        v: 1,
        caller: HANDLE,
        proof: 'legacy-window',
        ingress: 'wire',
        via: 'cli-deposit',
        admission_rule: 'cli-deposit',
        basis: [],
        target: TARGET,
        receipt_target: HANDLE,
      })
      expect(row?.auth.claim).toBeUndefined()
      expect(row?.auth.allowlist_version).toMatch(/^al1:[0-9a-f]{16}$/)
      expect(typeof row?.auth.received_at).toBe('number')

      // A replay of the id (same payload) is refused and leaves the record as it was born.
      expect((await post(`${a.baseUrl}/a2a/direct`, body)).status).toBe(409)
      expect((await rowOf('direct-aaaa00000001'))?.auth).toEqual(row?.auth)

      // A second task while a canvas exists: the version moves with the records it hashes.
      expect((await post(`${a.baseUrl}/__dsh_a2a/canvas`, { action: 'create', name: 'ops' })).body.ok).toBe(true)
      expect((await post(`${a.baseUrl}/a2a/direct`, { ...body, message: 'second task', task_id: 'direct-aaaa00000002' })).body.delivered).toBe(true)
      expect((await rowOf('direct-aaaa00000002'))?.auth.allowlist_version).not.toBe(row?.auth.allowlist_version)

      const born = row?.auth.allowlist_version as string

      await a.dispose()
      a = await bootNode({ name: 'A', session: 'mesh-gh120', team: 'dsh', sessionNodes: true, teamScopeRouting: true, port, home })
      expect((await rowOf('direct-aaaa00000001'))?.auth).toEqual(row?.auth)
      expect((await rowOf('direct-aaaa00000001'))?.auth.allowlist_version).toBe(born)
    } finally {
      await a.dispose()
    }
  }, 60_000)

  it('review of PR #134 P1: origin-claim only when the signed zone covers the caller; otherwise claim-mismatch', async () => {
    // A foreign host's card, signed with its own key (correct OriginClaim header names).
    const far = generateKeyPairSync('ed25519').privateKey
    const card = signCard({ name: 'far', session: 'far-s', team: 'far', capabilities: { route: true }, expiresAt: Date.now() + 3_600_000 }, far)
    const marketKey = generateKeyPairSync('ed25519').privateKey
    const marketCard = signCard({ name: 'market', session: 'market-s', team: 'market', capabilities: { route: true }, expiresAt: Date.now() + 3_600_000 }, marketKey)
    const srv = createServer((_req, res) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(card)) })
    await new Promise<void>(resolve => srv.listen(0, '127.0.0.1', () => resolve()))
    const farUrl = `http://127.0.0.1:${String((srv.address() as { port: number }).port)}`
    const a = await bootNode({ name: 'A', session: 'mesh-gh120-claim', team: 'dsh', sessionNodes: true, teamScopeRouting: true, port: await reservePort(), home: tmpHome() })
    try {
      expect((await post(`${a.baseUrl}/__dsh_a2a/join`, { id: 'session-0123456789abcdef' })).status).toBe(200)
      // The operator links far/aaaaaaaa as a remote member (N3/N4).
      expect((await post(`${a.baseUrl}/__dsh_a2a/canvas`, { action: 'create', name: 'ops' })).body.ok).toBe(true)
      expect((await post(`${a.baseUrl}/__dsh_a2a/canvas`, { action: 'add-member', name: 'ops', id: 'market/aaaaaaaa' })).body.ok).toBe(true)
      const marketServer = createServer((_req, res) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(marketCard)) })
      await new Promise<void>(resolve => marketServer.listen(0, '127.0.0.1', resolve))
      const marketUrl = `http://127.0.0.1:${String((marketServer.address() as { port: number }).port)}`
      const signed = (audience = a.baseUrl, claimCaller = 'market', callerUrl = marketUrl): Record<string, string> =>
        signOriginClaim({ url: `${audience}/a2a/direct`, method: 'POST' }, { caller: claimCaller, callerUrl, privateKey: marketKey, unbound: true, now: Date.now() })
      // Owed rows and settled ones alike (a receipt may settle a row before it is read).
      const rows = async (): Promise<Array<Record<string, any>>> => {
        const state = (await globalThis.fetch(`${a.baseUrl}/__dsh_a2a/state`).then(async r => await r.json())) as { tasks: Array<Record<string, any>>; archived?: Array<Record<string, any>> }
        return [...state.tasks, ...(state.archived ?? [])]
      }

      const covered = await post(`${a.baseUrl}/a2a/direct`, { team: TARGET, message: 'covered', caller_session: 'market/aaaaaaaa', wait: false, task_id: 'direct-claim0001' }, signed())
      expect(covered.body.delivered, JSON.stringify(covered.body)).toBe(true)
      expect(JSON.parse(steerText(a.steered[a.steered.length - 1])).content[0].text).toMatch(/^\[A2A direct\] \(task direct-claim0001\) 已验证来源 \S+ from/)
      expect((await rows()).find(t => t.taskId === 'direct-claim0001')?.auth).toMatchObject({
        caller: 'market/aaaaaaaa', proof: 'origin-claim', claim: { caller: 'market', origin: new URL(marketUrl).origin },
        via: 'canvas-member', admission_rule: 'remote-ref-foreign', basis: ['dsh/canvas/ops'],
      })

      const waited = await post(`${a.baseUrl}/a2a/direct`, { team: TARGET, message: 'waited event', caller_session: 'market/aaaaaaaa', wait: true, task_id: 'direct-boundwait01' }, signed())
      expect(waited.body.routed, JSON.stringify(waited.body)).toBe(true)
      expect(JSON.parse(steerText(a.steered[a.steered.length - 1])).content[0].text).toMatch(/^\[A2A direct\] \(task direct-boundwait01\) 已验证来源 \S+ from/ )

      // A same-origin subpath card still serves a key-valid identity for delivery, but is never granted origin-level proof.
      const pathUrl = `${marketUrl}/apps/market`
      const prefixed = await post(`${a.baseUrl}/a2a/direct`, { team: TARGET, message: 'prefixed origin', caller_session: 'market/aaaaaaaa', wait: false, task_id: 'direct-prefix0001' }, signed(a.baseUrl, 'market', pathUrl))
      expect(prefixed.body.delivered, JSON.stringify(prefixed.body)).toBe(true)
      expect(JSON.parse(steerText(a.steered[a.steered.length - 1])).content[0].text).toContain('未验证（claim-mismatch）')
      expect((await rows()).find(t => t.taskId === 'direct-prefix0001')?.auth).toMatchObject({ proof: 'claim-mismatch', caller: 'market/aaaaaaaa' })

      // Replaying the same v1 signature with another body is accepted only as unbound proof; v1 does not sign target or body.
      const v1 = signed()
      delete v1['X-A2A-Caller-Aud']
      delete v1['X-A2A-Caller-Sig2']
      for (const [taskId, message] of [['direct-v1replay01', 'first body'], ['direct-v1replay02', 'changed replay body']]) {
        const replay = await post(`${a.baseUrl}/a2a/direct`, { team: TARGET, message, caller_session: 'market/aaaaaaaa', wait: false, task_id: taskId }, v1)
        expect(replay.body.delivered, JSON.stringify(replay.body)).toBe(true)
        expect((await rows()).find(t => t.taskId === taskId)?.auth).toMatchObject({ proof: 'unbound', caller: 'market/aaaaaaaa' })
      }
      expect(JSON.parse(steerText(a.steered[a.steered.length - 1])).content[0].text).toContain('未验证（unbound）')

      // The signed zone "market" does not cover the host face "dsh": delivered (admission is unchanged), but never recorded as proven.
      const mismatched = await post(`${a.baseUrl}/a2a/direct`, { team: TARGET, message: 'mismatch', caller_session: 'dsh', wait: false, task_id: 'direct-claim0002' }, signed(a.baseUrl, 'market'))
      expect(mismatched.body.delivered, JSON.stringify(mismatched.body)).toBe(true)
      expect(JSON.parse(steerText(a.steered[a.steered.length - 1])).content[0].text).toContain('未验证（claim-mismatch）')
      expect((await rows()).find(t => t.taskId === 'direct-claim0002')?.auth).toMatchObject({
        caller: 'dsh', proof: 'claim-mismatch', claim: { caller: 'market' }, admission_rule: 'host-face',
      })

      // Round 2: a card that self-signs THIS host's zone name from another origin is still not the host face.
      const impostor = signCard({ name: 'dsh', session: 'imp-s', team: 'dsh', capabilities: { route: true }, expiresAt: Date.now() + 3_600_000 }, far)
      const imp = createServer((_req, res) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(impostor)) })
      await new Promise<void>(resolve => imp.listen(0, '127.0.0.1', () => resolve()))
      try {
        const impUrl = `http://127.0.0.1:${String((imp.address() as { port: number }).port)}`
        const env = signOriginClaim({ url: `${a.baseUrl}/a2a/direct`, method: 'POST' }, { caller: 'dsh', callerUrl: impUrl, privateKey: far, unbound: false, now: Date.now() })
        const sent = await post(`${a.baseUrl}/a2a/direct`, { team: TARGET, message: 'impostor', caller_session: 'dsh', wait: false, task_id: 'direct-claim0003' }, env)
        expect(sent.body.delivered, JSON.stringify(sent.body)).toBe(true)
        expect(JSON.parse(steerText(a.steered[a.steered.length - 1])).content[0].text).toContain('未验证（claim-mismatch）')
        expect((await rows()).find(t => t.taskId === 'direct-claim0003')?.auth).toMatchObject({ caller: 'dsh', proof: 'claim-mismatch', claim: { caller: 'dsh', origin: new URL(impUrl).origin }, admission_rule: 'host-face' })
      } finally {
        imp.close()
      }
    } finally {
      await a.dispose()
      srv.close()
    }
  }, 60_000)
})
