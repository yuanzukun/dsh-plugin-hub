/**
 * dsh-opencli host 半:登录态浏览器代理。
 * - opencli_* 工具族:包装 `opencli browser <session> …` 原语(open/state/click/type/fill/extract/screenshot/scroll/wait + do 透传)。
 *   2026-10 命名空间迁移:browser_* → opencli_*(两次第三方插件 browser_ 前缀撞名事故后
 *   主动让出该前缀),旧名经 registerToolWithLegacyAlias 挂弃用别名,2027-04 移除。
 * - site 工具:`opencli <adapter> <command> …` 适配器桥
 * - systemPrompt:适配器目录(缓存 + TTL)与使用要点
 * - TypertRemoteService RPC:status / adapters / refresh(面板用)
 * 全部调用经 ctx.shell;不打包 OpenCLI(doctor 缺失引导)。
 * @module dsh-opencli
 */

import { Context, Service } from '@deepseek-ai/cordis'
import { defineTool, type DefineToolOptions, type ParameterSchemaSpec, type ValueSchemaSpec } from '@deepseek-ai/dsh-tools'
import { TypertRemoteService, Remote } from '@deepseek-ai/dsh-typert-protocol'
import type { ShellExecRequest } from '@deepseek-ai/dsh-shell'
import { Buffer } from 'node:buffer'
import { homedir } from 'node:os'
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import { appendFileSync, existsSync, mkdirSync, readFileSync, readdirSync, renameSync, statSync, unlinkSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { basename, dirname, join, resolve, sep } from 'node:path'
import { fileURLToPath } from 'node:url'
import type {
  AdapterDetailRequest, AdapterDetailResult, AdapterDisableRequest, AdapterDisableResult,
  AdaptersResult, ApprovalSetRequest, ApprovalSetResult, AuditListResult, DaemonStartResult, EvidenceGetResult,
  EventsGetResult, IngestEvent, LoginCheckItem, LoginCheckResult, LogsTailResult, OpencliStatus, SettingsResult, TraceLine, TraceListResult,
} from './types.ts'
import { approvalDecision, buildAdapterDirectory, commandAccess, extractJsonObject, normalizeAdapterList, parseDaemonStatus, sitesWithWhoami } from './parsers.ts'
import { SystemOne, noulYes } from './systemone.ts'
import { buildKnowledge, renderKnowledgeMarkdown, handleMcpResourceRequest, knowledgeResourceUri, SITE_HEALTH, type RawEntry } from './knowledge.ts'
import { buildReport, type ReportSource } from './reports.ts'
import { browserDoCardRender, siteBatchCardRender, siteCardRender } from './cards.ts'
import { BENCH_KEEP, CANARY_KEEP, DEFAULT_BENCH, RESERVED_NAMESPACES, buildBenchmarkReport, buildCanaryReport, renderTransportBenchmark, parseCanarySnapshot, pickCanaryCommands, renderBenchmarkTable, type BenchItem } from './benchmark.ts'
import { EVIDENCE_FILE_RE, EVIDENCE_KEEP, buildEvidence, parseEvidenceFileName, saveEvidence, type EvidenceRecord } from './evidence.ts'
import { buildNotifyBody, buildNotifyChannels, sendViaChannels, normalizeNotifyConfig, saveNotifyConfig, inQuietHours, parseQuietHours, renderQuietDigest, scrubLocalPaths, scrubUrlParams, type NotifyConfig, type QuietPendingItem } from './notify.ts'
import { PLUGIN_VERSION } from './version.ts'
import { CANVAS_CLICK_UNTRUSTED_NOTE, buildCanvasDiscoveryJs, buildCanvasReadJs, buildCoordClickJs } from './vom.ts'
import { directCapability, directProbe, directExec } from './direct.ts'
import { composeClick, composeCloseWindow, composeOpen, composeScreenshot, composeScroll, composeState, composeTabs, setCliDistDir, type CliEnvelope } from './direct-compose.ts'
import { drainInbox, inboxDir, parseIntent, applyIntent, type IntentExecutor, type Intent, type IntentResult } from './inbox.ts'
import { startMcpSelfhost, mcpAuthFile, type McpSelfhostHandle } from './mcp-selfhost.ts'
import { aggregateDaySums, detectDrift, diffSnapshots, renderDiffText, type DriftSample } from './diffsnap.ts'
import { authRiskClass, countStructuredItems, cursorOfPartialPage, coverageStopReason, isChallengePage, isDecorativeStep, looksPartialPage, looksTruncated, looksUnloaded, typedErrorCode, type Receipt } from './parsers.ts'

/** 本插件版本单一来源在 version.ts(自检视图与面板「版本与更新」卡共用同一常量)。 */
import { exportSnapshots } from './exportcsv.ts'
import { nlToIntent, type NlContext, type LlmCaller } from './nl.ts'

// 对话内预览卡(site/site_batch/opencli_do 的 output.render)再导出:纯函数,tests/cards.test.ts 直测
export { browserDoCardRender, siteBatchCardRender, siteCardRender } from './cards.ts'
// 基准纯函数层再导出(与 cards 同款约定):tests/benchmark.test.ts 直测,免走服务装配
export { BENCH_KEEP, DEFAULT_BENCH, buildBenchmarkReport, renderBenchmarkTable } from './benchmark.ts'
// 证据包纯函数层再导出(同款约定):tests/evidence.test.ts 直测
export { EVIDENCE_KEEP, buildEvidence, saveEvidence } from './evidence.ts'

declare module '@deepseek-ai/cordis' {
  interface Context {
    opencli: OpencliService
  }
}

/** opencli_do 允许透传的 browser 子命令白名单(其余高危命令不允许盲调)。 */
const BROWSER_DO_ALLOW = new Set([
  'analyze', 'back', 'bind', 'check', 'close', 'console', 'dblclick', 'dialog',
  'drag', 'eval', 'find', 'focus', 'frames', 'get', 'hover', 'init', 'keys',
  'network', 'scroll', 'select', 'tab', 'unbind', 'uncheck', 'upload', 'verify',
])

/** 步骤自动截图的触发子命令:产生页面变化的动作族;state/extract 等只读命令不拍(页面没变,拍了也是重复证据)。
 *  此外任何 exitCode!==0 的命令无论子命令一律补拍——失败现场是复盘最需要的证据。 */
const PKG_VERSION = (() => { try { return JSON.parse(readFileSync(join(dirname(fileURLToPath(import.meta.url)), '..', 'package.json'), 'utf8') as { version: string }).version } catch { return 'unknown' } })()

const SHOT_TRIGGER_SUBS = new Set(['open', 'back', 'click', 'dblclick', 'type', 'fill', 'select', 'keys', 'hover', 'drag'])

/** chrome_* 工具族的 method 白名单:opencli 2.0 原生管理通道 `browser chrome call` 的合法方法集。
 *  本应从 `browser chrome describe` 动态归纳,但本机扩展 1.0.24 及以前 describe 直接报
 *  "Browser session is required"(真机实测 2026-10-20);清单取自上游扩展源码
 *  jackwener/OpenCLI extension/src/chrome-api.ts 的 CHROME_METHODS——与官方
 *  chrome.tabs/tabGroups/windows API 名一致,是"按官方 API 名兜底"的加强版(真集)。 */
const CHROME_METHODS_ALLOW = new Set([
  'tabs.query', 'tabs.get', 'tabs.create', 'tabs.duplicate', 'tabs.update', 'tabs.move', 'tabs.remove', 'tabs.group', 'tabs.ungroup',
  'tabGroups.query', 'tabGroups.get', 'tabGroups.update', 'tabGroups.move',
  'windows.get', 'windows.getAll', 'windows.create', 'windows.update', 'windows.remove',
])

/** ④⑤ 无扩展短路统一文案(三件套:缺什么/装什么/装完会发生什么)。
 *  opencli_* 与 chrome_* 两族是 CLI→daemon→扩展硬链路(上游架构事实),无扩展不做伪造降级,只给确切出路。 */
const NO_EXT_GUIDANCE =
  '需要 OpenCLI 扩展(当前未检测到):opencli_*/chrome_* 走 CLI→daemon→扩展链路,无扩展无法工作,也不伪造降级。' +
  '装法:https://github.com/jackwener/OpenCLI/releases 下载 opencli-extension-*.zip 解压 → Chrome/Edge 扩展页开"开发者模式"→"加载解压缩的扩展";装好自动重连,本工具立即可用,无需重启 dsh。' +
  '无扩展期间:site 的纯 HTTP 只读命令(如 site juejin hot)不受影响。'

/** ② 通道B 注入的固定 argv 尾(上游 execution.js:--site-session ephemeral = 一次性匿名 tab,
 *  与 OPENCLI_SITE_SLOTS 互斥由该 flag 解除)。测试钉死:注入只加 env 与这组 flag,别无改动。 */
const CDP_ARGV_TAIL: readonly string[] = ['--site-session', 'ephemeral']

const OUTPUT_LIMIT = 16000
const ADAPTER_TTL_MS = 60 * 60 * 1000
const LOGIN_CHECK_TTL_MS = 10 * 60 * 1000
const LOGIN_CHECK_CONCURRENCY = 3

/** 插件持久状态(~/.dsh/dsh-opencli-state.json)。 */
interface PluginState {
  approval: 'on' | 'off'
  disabled: string[]
  /** 持久化定时任务:重启恢复,每分钟 tick 到期自动执行 site 命令;watch=关键词监控(命中即通知) */
  schedules: Array<{ id: string; site: string; cron: string; createdAt: string; enabled: boolean; lastRunAt?: string; retry?: number; notify?: boolean; watch?: string }>
  /** 每任务运行历史(最近 5 条) */
  runHistory: Record<string, Array<{ at: string; ok: boolean; summary: string }>>
  /** 审批门拦截审计(最近 50 条) */
  audit: Array<{ at: string; command: string; reason: string; mode: string }>
  /** 通知通道配置(任务 E):放 state 里跟着 saveState 走——saveState 是整文件重写,
   *  notifyConfig 不进 this.state 就会在下一次任意调度落盘时被丢键(notify.ts 的
   *  saveNotifyConfig 单独写该段保不住这条路径)。 */
  notifyConfig?: NotifyConfig
}

/** 0.2.0 ctx.subprocess 服务的最小形状(dsh-subprocess 的 spawn seam;只取用到的成员)。 */
interface SubprocessSeam {
  spawn?: (s: unknown) => {
    done: Promise<{ exitCode?: number | null }>
    collected?: {
      stdout?: { readFrom: (o: number) => Promise<{ text?: string }> }
      stderr?: { readFrom: (o: number) => Promise<{ text?: string }> }
    }
  }
}

/**
 * 0.2.0+ ctx.mcpResources(dsh-mcp-resources 的 McpResourceRuntime)的最小形状。
 * 实测于 cli017(@deepseek-ai/dsh-mcp-resources 0.2.0-rc.2):register(server, provider)
 * 把本插件注册为一个"MCP resource server",模型经共享工具 list_mcp_resources /
 * read_mcp_resource(server='opencli')读到 opencli://sites/{site}/knowledge。
 * 该包不在本插件 peerDependencies 里(0.1.x 宿主没有)——必须 reflect 可选探测,缺失即退化为 RPC 路径。
 */
interface McpResourcesSeam {
  register?: (server: string, provider: { request: (req: { method: string; cursor?: string; uri?: string }, exec?: unknown) => Promise<unknown> }) => () => void
}

/**
 * 跨 node 版本目录扫描 opencli(vfox/nvm 切换免疫,纯函数可单测)。
 * 目录形态兼容:vfox cache(v-24.18.0/nodejs-24.18.0)、vfox sdks 平铺、nvm-windows。
 * 返回最高 node 版本副本的 main.js 绝对路径;没有则 null。
 */
export function scanOpencliAcrossNodeVersions(roots: string[]): string | null {
  let best: { ver: number[]; main: string } | null = null
  for (const root of roots) {
    let dirs: string[] = []
    try { dirs = readdirSync(root).map((d) => join(root, d)) } catch { continue }
    for (const dir of dirs) {
      const candidates = existsSync(join(dir, 'dist', 'src', 'main.js'))
        ? [join(dir, 'dist', 'src', 'main.js')]
        : (() => { try { return readdirSync(dir).map((d) => join(dir, d, 'dist', 'src', 'main.js')) } catch { return [] } })()
      for (const main of candidates) {
        if (!existsSync(main)) continue
        const ver = (dir.match(/(\d+)\.(\d+)\.(\d+)/)?.slice(1) ?? ['0', '0', '0']).map(Number)
        if (best === null || ver > best.ver) best = { ver, main }
      }
    }
  }
  return best?.main ?? null
}

/**
 * mise 版本管理器 opencli 探测(纯函数可单测,仓库 #1 issue):mise 把各 node 版本隔离在
 * installs/node/<ver>/,npm -g 装出的入口是 bin/ 下的 shim——不是上面认的 dist/src/main.js
 * 形态,scanOpencliAcrossNodeVersions 扫不到。多版本并存取最高版(与 vfox/nvm 扫描同策略);
 * win32 认 .cmd shim(无扩展名 sh 脚本无法直接执行),其余平台认无扩展名形态。
 * 返回 bin 入口绝对路径;root 不存在或无命中返回 null。
 */
export function scanMiseOpencli(root: string): string | null {
  let dirs: string[] = []
  try { dirs = readdirSync(root).map((d) => join(root, d)) } catch { return null }
  const names = process.platform === 'win32' ? ['opencli.cmd', 'opencli'] : ['opencli']
  let best: { ver: number[]; bin: string } | null = null
  for (const dir of dirs) {
    const ver = (dir.match(/(\d+)\.(\d+)\.(\d+)/)?.slice(1) ?? ['0', '0', '0']).map(Number)
    for (const name of names) {
      if (!existsSync(join(dir, 'bin', name))) continue
      // 该版本目录已定名:命中首选名不再看次选(否则 win32 会跳过 .cmd 误选 sh 脚本)
      if (best === null || ver > best.ver) best = { ver, bin: join(dir, 'bin', name) }
      break
    }
  }
  return best?.bin ?? null
}

interface ToolArgs {
  session?: string
  url?: string
  target?: string
  text?: string
  source?: string
  direction?: string
  type?: string
  value?: string
  path?: string
  tab?: string
  command?: string
  args?: string[]
  adapter?: string
  authProfile?: string
}

/** 轨迹行 + 可选步骤截图绝对路径(types.ts 的 TraceLine 不含 shot;读侧原样透传,老行无此字段)。 */
type ShotTraceLine = TraceLine & { shot?: string }

export class OpencliService extends TypertRemoteService {
  static inject = ['shell', 'tools', 'systemPrompt']

  private readonly bin: string
  private adapterCache: { at: number; json: unknown } | null = null
  private lastShellError: string | null = null
  private state: PluginState = { approval: 'on', disabled: [], schedules: [], runHistory: {}, audit: [] }
  /** 面板通知事件(调度失败等;内存态最近 30 条——跨会话历史经 pushIngestEvent 追加落盘
   *  ~/.dsh/opencli-events.jsonl,events-get 读回;内存态仍是 ingest-events 的数据源) */
  private ingestEventList: IngestEvent[] = []
  // 事件历史文件可用 DSH_OPENCLI_EVENTS_FILE 覆盖(单测隔离用,与 statePath 同款约定)
  private readonly eventsFile = process.env.DSH_OPENCLI_EVENTS_FILE !== undefined && process.env.DSH_OPENCLI_EVENTS_FILE.length > 0
    ? process.env.DSH_OPENCLI_EVENTS_FILE
    : join(homedir(), '.dsh', 'opencli-events.jsonl')
  /** 每任务结构签名环形缓冲(适配器漂移预警;内存态,任务 id → 最近 5 次 {items,structured}) */
  private driftHistory = new Map<string, DriftSample[]>()
  /** 当前构建 sha256(懒计算) */
  private sha256Cache: string | null = null
  // 状态路径可用 DSH_OPENCLI_STATE 覆盖(单测隔离用):否则单测会把定时任务/审计写进真实用户状态文件
  private readonly statePath = process.env.DSH_OPENCLI_STATE !== undefined && process.env.DSH_OPENCLI_STATE.length > 0
    ? process.env.DSH_OPENCLI_STATE
    : join(homedir(), '.dsh', 'dsh-opencli-state.json')
  // 运行轨迹目录可用 DSH_OPENCLI_TRACE_DIR 覆盖(单测隔离用,与 statePath 同款约定)
  private readonly traceDir = process.env.DSH_OPENCLI_TRACE_DIR !== undefined && process.env.DSH_OPENCLI_TRACE_DIR.length > 0
    ? process.env.DSH_OPENCLI_TRACE_DIR
    : join(homedir(), '.dsh', 'opencli-traces')
  // 步骤截图目录可用 DSH_OPENCLI_SHOTS_DIR 覆盖(单测隔离用,与 traceDir 同款约定)
  private readonly shotsDir = process.env.DSH_OPENCLI_SHOTS_DIR !== undefined && process.env.DSH_OPENCLI_SHOTS_DIR.length > 0
    ? process.env.DSH_OPENCLI_SHOTS_DIR
    : join(homedir(), '.dsh', 'opencli-shots')
  // 写命令证据包目录可用 DSH_OPENCLI_EVIDENCE_DIR 覆盖(单测隔离用,与 shotsDir 同款约定)
  private readonly evidenceDir = process.env.DSH_OPENCLI_EVIDENCE_DIR !== undefined && process.env.DSH_OPENCLI_EVIDENCE_DIR.length > 0
    ? process.env.DSH_OPENCLI_EVIDENCE_DIR
    : join(homedir(), '.dsh', 'opencli-evidence')
  /** 步骤自动截图开关(默认开;宿主/单测可整体关闭,不做面板开关——截图是复盘增强,不值得一个设置项)。 */
  shotCapture = true
  /** 冒烟基准的站间间隔(串行限流礼貌;单测可调 0 提速,不影响生产行为)。 */
  benchGapMs = 800
  /** 截图序号(进程内单调,同秒多步防碰撞;跨进程/重启撞名由 existsSync 续拨兜底)。 */
  private shotSeq = 0
  /** 收件箱轮询计时器(同 schedTimer 的停机清除纪律)。 */
  private inboxTimer: ReturnType<typeof setInterval> | undefined
  /** MCP 自host 运行句柄(mcp-selfhost-status RPC 读;init 里启动,ctx.effect 收)。 */
  private mcpSelfhost: McpSelfhostHandle | null = null
  /** MCP 自host 启动失败留痕(端口被占等;status RPC 透出,init 不因此失败)。 */
  private mcpSelfhostError: string | null = null
  private loginCache: { at: number; results: LoginCheckResult } | null = null
  // usagePolicy：限流三参数（并发/突发/冷却），默认值对齐主流 DSH 浏览器插件的礼貌限流
  private usagePolicy = { minDelayMs: 750, maxConcurrency: 2, burst: 3, cooldownMs: 30000, retryLimit: 2, maxPagesPerRun: 20, maxDepth: 2, writeMinDelayMs: 3000 }
  private callTimestamps: number[] = []
  /** 写命令最近放行时刻(#59 读写分频:写步骤独立限频轨,与读的 minDelay/突发窗互不占用)。 */
  private lastWriteAt = 0
  private concurrent = 0
  private cooldownUntil = 0
  private queue: Array<() => void> = []
  // 限域登录（authProfiles）：按 profile 限 allowedDomains，默认只读不回写
  private authProfiles: Record<string, { allowedDomains: string[]; storageStatePath?: string; persistState?: boolean }> = {
    // 示例：forum: { allowedDomains: ['example.com'], storageStatePath: 'D:/secrets/forum.json' }
  }
  private schedules: Array<{
    id: string; site: string; cron: string; createdAt: string; enabled: boolean; lastRunAt?: string
    source?: string; notifyLevel?: string; retry?: number; notify?: boolean; watch?: string
    quietHours?: string; pendingNotify?: QuietPendingItem[]
    /** 拟人限速:默认 true——精确 cron 时刻是指纹,首跑前随机延迟打散 */
    jitter?: boolean
    /** 登录态预检(0.1.2 认证预检):默认 false——开启时每 tick 采集前跑 whoami 快检,未登录跳过本 tick */
    preflight?: boolean
    /** 快照留存预算(回执/轨迹卫生,任务级可配):本任务最多保留的快照份数,超出按时间序滚动淘汰最旧;默认 50 */
    keep?: number
    /** 重试退避(回执/轨迹卫生,任务级默认字段):普通失败两次尝试间隔毫秒;默认 15000。风控墙失败另有下限 120s */
    backoffMs?: number
    /** 多账号登录态隔离:浏览器 profile 别名或 contextId——经 OPENCLI_PROFILE 透传给 CLI
     *  (上游 2.0.3 原生 --profile/contextId 路由,真隔离:不同 profile=不同浏览器档案的 cookie/存储) */
    profile?: string
  }> = []
  private runHistory: Record<string, Array<{ at: string; ok: boolean; summary: string; receipt?: Receipt }>> = {}
  /** 快照根目录(DSH_OPENCLI_SNAPSHOTS_DIR 可覆盖,测试隔离用;与 traceDir 同款约定)。 */
  private readonly snapshotsBase = process.env.DSH_OPENCLI_SNAPSHOTS_DIR !== undefined && process.env.DSH_OPENCLI_SNAPSHOTS_DIR.length > 0 ? process.env.DSH_OPENCLI_SNAPSHOTS_DIR : join(homedir(), '.dsh', 'opencli-snapshots')
  private automationMode: 'read-only' | 'standard' | 'autonomous' | 'unrestricted' = 'standard'
  private rulePacks: Array<{ matches: string[]; initScriptPath: string; initScriptSha256: string; steps: unknown[] }> = []
  private automationAssets = { persistenceMode: 'suggest' as const, activationMode: 'manual' as const }

  constructor(ctx: Context) {
    super(ctx, 'opencli')
    this.bin = this.resolveBin()
    // 直连组合层(state/click/scroll 的 JS 构造器)从本机已装 CLI 的 dist 运行时装载:
    // 与 resolveBin 同一套级联定位 dist/src;注入失败组合层整层回落 CLI(旁路纪律不变)
    setCliDistDir(this.resolveCliDistDir())
  }

  /** CLI dist/src 目录定位(镜像 resolveBin 级联,只认 .js 目录不认命令串);找不到返回 undefined。 */
  private resolveCliDistDir(): string | undefined {
    try {
      // @ts-ignore - optional peer
      const pkg = require.resolve('@jackwener/opencli/package.json')
      const dir = join(dirname(pkg), 'dist', 'src')
      if (existsSync(dir)) return dir
    } catch { /* 无本地依赖则回退全局 */ }
    const globalDir = join(dirname(process.execPath), 'node_modules', '@jackwener', 'opencli', 'dist', 'src')
    if (existsSync(globalDir)) return globalDir
    const scanned = scanOpencliAcrossNodeVersions([
      join(homedir(), '.vfox', 'cache', 'nodejs'),
      join(homedir(), '.vfox', 'sdks', 'nodejs'),
      join(homedir(), '.nvm'),
    ])
    if (scanned !== null) {
      const dir = dirname(scanned) // scanned 指向 dist/src/main.js
      if (existsSync(dir)) return dir
    }
    return undefined
  }

  private resolveBin(): string {
    if (process.env.DSH_OPENCLI_BIN !== undefined && process.env.DSH_OPENCLI_BIN.length > 0) return process.env.DSH_OPENCLI_BIN
    // 优先插件本地依赖（本地优先/全局复用策略）
    try {
      // @ts-ignore - optional peer
      const pkg = require.resolve('@jackwener/opencli/package.json')
      const bin = join(dirname(pkg), 'dist', 'src', 'main.js')
      if (existsSync(bin)) return `node ${bin}`
    } catch { /* 无本地依赖则回退全局 */ }
    // npm 全局安装（vfox/nvm 结构）：node 同目录必有 @jackwener/opencli 入口。
    // 直接用 node 执行，避开 Windows pwsh/bash 对无扩展 shim 的静默忽略。
    const globalMain = join(dirname(process.execPath), 'node_modules', '@jackwener', 'opencli', 'dist', 'src', 'main.js')
    if (existsSync(globalMain)) return `node "${globalMain}"`
    // 版本管理器切换免疫(实测:vfox use 24.21 后装在 24.18 的 opencli 静默失踪)
    const scanned = scanOpencliAcrossNodeVersions([
      join(homedir(), '.vfox', 'cache', 'nodejs'),
      join(homedir(), '.vfox', 'sdks', 'nodejs'),
      join(homedir(), '.nvm'),
    ])
    if (scanned !== null) return `node "${scanned}"`
    // mise 版本管理器(仓库 #1 issue):bin shim 形态上面的 dist 扫描认不出,单独探测;
    // 整路径加引号返回——shell 串形态按空白+引号切词,subprocess seam 的 tokenizer 同款处理
    const mise = scanMiseOpencli(join(homedir(), '.local', 'share', 'mise', 'installs', 'node'))
    if (mise !== null) return `"${mise}"`
    return 'opencli'
  }

  protected async [Service.init](): Promise<void> {
    // 先同步加载持久化状态,再注册工具/审批门:否则在途回读会冲掉已到达的
    // schedule-add 等写操作(构造器 fire-and-forget 时代的竞态)。
    await this.loadState()
    this.registerBrowserTools()
    this.registerChromeTools()
    this.registerAdvancedTools()
    this.registerVomTools()
    this.registerSiteTool()
    this.registerDecisionTools()
    this.registerDoctorTool()
    this.registerBenchmarkTool()
    if (this.toolConflicts.length > 0) {
      // 撞名让位是静默行为,不留宿主日志用户无从得知这些工具为何消失(社区插件因 browser_* 撞名整挂的教训)
      console.warn(`[dsh-opencli] 另一插件注册了同名工具,本插件已让位这些命令:${this.toolConflicts.join(', ')}`)
    }
    this.registerApprovalGate()
    this.registerEvidenceListeners()
    this.registerKnowledgeResources()
    // 决策层后台预热:laya 权重冷加载约 60s,不能让 agent 的首次 so_verify/so_pick 吃这个延迟。
    // vitest 里跳过:测试会拉起真实 service,后台真加载权重既慢又晃动测试进程。
    if (process.env.VITEST === undefined) void this.so.prewarm()
    // 扩展状态缓存同样启动期预热(fire-and-forget,与 laya 预热同一理由):让零配置降级的
    // ④⑤ 短路/② 路由在首条 browser/site 命令上直接命中缓存,不为冷探测多付一次子进程
    void this.extensionState().catch(() => {})
    void this.injectSystemPrompt()
    if (this.schedules.some((s) => s.enabled)) this.startScheduler()
    // 命令收件箱:ctl 助手写意图 → 本消费者执行并回写结果。面板/ZCode/任意
    // dsh 会话的 agent 都能用 shell 驱动插件(预设门绕开的生态面)。vitest 里只由专项
    // 用例手动 drain(自动轮询会与隔离目录用例互相踩);单测环境外 3s 一拍。
    if (process.env.VITEST === undefined) {
      this.inboxTimer = setInterval(() => { void this.drainInboxSafe() }, 3000)
      ;(this.ctx as unknown as { effect?: (f: () => () => void) => unknown }).effect?.(() => () => {
        if (this.inboxTimer !== undefined) { clearInterval(this.inboxTimer); this.inboxTimer = undefined }
      })
      // MCP 自host Streamable-HTTP 端点(知识卡第三分发面,外部 MCP 消费者直连):
      // 启动失败(端口被占等)不抛不炸,mcpSelfhostError 留痕给 status RPC;
      // 句柄随 ctx.effect 收走(停 HTTP server+删 token 告知文件),与收件箱计时器同纪律。
      // vitest 里不自动起(同收件箱理由);tests/mcp-selfhost.test.ts 直接驱动模块。
      await this.startMcpSelfhostSafe()
    }
    // 调度计时器随服务停机清除:cordis stop 不自动收走裸 setInterval,vitest 复用 worker 跑
    // 多个测试文件与插件热重载都会留下僵尸调度器——它在服务"死后"继续触发
    // runSiteCommand/saveState,是并发写状态文件竞态的来源之一(effect 先例见
    // registerKnowledgeResources)
    ;(this.ctx as unknown as { effect?: (f: () => () => void) => unknown }).effect?.(() => () => {
      if (this.schedTimer !== undefined) { clearInterval(this.schedTimer); this.schedTimer = undefined }
    })
    // 兼容其他浏览器类插件生态：其他插件 inject: ['browser'] 时共用本服务。
    // 不能把带 typertRemote 的原始实例直接 provide：网关遍历 ctx.reflect.props 时,
    // 'browser' 条目会在 namespace 过滤前走 readBinding,serviceKey('browser')≠绑定
    // 里的 'opencli' 直接抛 inconsistent binding。改为提供绑定方法的无门面副本
    // (无 typertRemote 属性,网关扫描时被自然跳过)。
    try {
      const proto = Object.getPrototypeOf(this) as Record<string, unknown>
      const facade: Record<PropertyKey, unknown> = {}
      for (const key of Object.getOwnPropertyNames(proto)) {
        if (key === 'constructor') continue
        const d = Object.getOwnPropertyDescriptor(proto, key)
        if (d !== undefined && typeof d.value === 'function') facade[key] = (d.value as (...args: unknown[]) => unknown).bind(this)
      }
      Object.defineProperty(facade, 'typertRemote', { get: () => undefined })
      ;(this.ctx as unknown as { provide: (n: string, v: unknown) => void }).provide('browser', facade)
    } catch { /* ignore */ }
  }

  // ── 模型工具 ──────────────────────────────────────────────

  /** 重名让位记账(被跳过的工具名):status.conflicts / doctor ⚠ 行 / 宿主 warn 三处可见。 */
  private toolConflicts: string[] = []
  /** 本插件成功注册的工具名(自检视图逐个点名:#9308 式'装上没效果'的可视化解药)。 */
  private registeredToolNames: string[] = []
  /** 注册期预期清单(成功与撞名让位都入册):selfCheck 点名的基准——此前从 registeredToolNames
   *  自身取期望,点名恒真,对任何失败形态都无鉴别力。 */
  private expectedToolNames: string[] = []

  /**
   * 重名防护:dsh 0.2.1 的 dsh-tools NamedEntries 对重名注册直接抛 "tool X is already
   * registered",不接住就是整个插件加载失败(社区已有两个插件栽在 browser_* 撞名上)。
   * 五个 register* 方法的全部工具注册走这里:撞名 → 记入 toolConflicts 让位(本插件后加载,
   * 先到先得);其他错误仍抛——真正的 bug 不许被吞。
   */
  private registerToolSafe<S extends ParameterSchemaSpec, O extends ValueSchemaSpec>(def: DefineToolOptions<S, O>): void {
    this.expectedToolNames.push(def.name)
    try {
      this.ctx.tools.register(defineTool(def))
      this.registeredToolNames.push(def.name)
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e)
      if (!/already registered/i.test(msg)) throw e
      this.toolConflicts.push(def.name)
    }
  }

  /**
   * 命名空间迁移兼容层(2026-10,两次第三方插件 browser_* 撞名事故后主动让出该前缀):
   * 新名 opencli_* 是正主,旧名 browser_* 同步注册为弃用别名——描述前置「已弃用」引导模型改口,
   * execute 原样转发新名实现,结果首行附弃用提示(功能不断)。旧名只是别名:systemPrompt 目录、
   * doctor 等正主位只写新名;别名同样走 registerToolSafe,被其他插件占了旧名正合迁移本意,让位即可。
   * 计划 2027-04(6 个月)移除兼容层,届时本方法退化为直通注册。
   */
  private registerToolWithLegacyAlias<S extends ParameterSchemaSpec, O extends ValueSchemaSpec>(def: DefineToolOptions<S, O>): void {
    this.registerToolSafe(def)
    const legacy = def.name.replace(/^opencli_/, 'browser_')
    if (legacy === def.name) return
    // 泛型 S/O 只在调用方字面量处落地,函数体内拿不到具体 InferValue——别名 def 整体 as 收口。
    // 运行时契约:本族工具 execute 恒返 { text, shot? },转发结果仅前置一行弃用提示,形状不变。
    this.registerToolSafe({
      ...def,
      name: legacy,
      description: `[已弃用] 请用 ${def.name}:${def.description}`,
      execute: async (a: unknown, exec: unknown) => {
        const r = (await def.execute(a as never, exec as never)) as unknown as { text: string }
        return { ...r, text: `[已弃用] ${legacy} 已更名 ${def.name}(兼容层 2027-04 移除,请改用新名)\n${r.text}` }
      },
    } as unknown as DefineToolOptions<S, O>)
  }

  /** SystemOne 决策层:key 从环境变量或 ~/.dsh/typesafe-key;provider 可换(laya 本地 ONNX 同接口)。 */
  private so: SystemOne = new SystemOne()

  /**
   * Agent 自助安装/自检工具(AGENT_INSTALL.md 的落地闭环):CLI→daemon→BrowserBridge 扩展→浏览器档案
   * 四层诊断,每层给状态与确切下一步命令。排障先跑这个,不盲试。
   */
  private registerDoctorTool(): void {
    this.registerToolSafe({
      name: 'opencli_doctor',
      description: 'dsh-opencli 一键自检:CLI/daemon/BrowserBridge 扩展/浏览器档案四层诊断,输出每层状态与下一步命令。安装与排障时先跑这个。',
      parameters: {},
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async () => {
        const lines: string[] = ['opencli_doctor 四层自检:']
        const next: string[] = []
        let cliOk = false
        let vraw = ''
        let cliErr = ''
        try {
          const v = await this.runOpencli(['--version'], 15000)
          vraw = (v.stdout.trim() || v.stderr.trim()).split('\n')[0]?.trim() ?? ''
          cliOk = v.exitCode === 0 && vraw.length > 0
          if (!cliOk) cliErr = v.stderr.slice(0, 200) || v.stdout.slice(0, 200)
        } catch (e) { cliErr = (e instanceof Error ? e.message : String(e)).slice(0, 200) }
        // 文案区分两种失败(与 status RPC 同源):找不到二进制 → 装;找到了但 --version 失败 → 查执行层
        lines.push(`${cliOk ? '✓' : '✗'} CLI:${cliOk ? vraw : this.cliUnavailableText(cliErr)}`)
        if (!cliOk) next.push(this.bin === 'opencli'
          ? '安装 CLI:npm i -g @jackwener/opencli,然后 opencli daemon restart(或装 OpenCLIApp https://opencli.info/download)'
          : 'CLI 已定位但 --version 失败:按上方详情排障;node 版本切换后路径悬空,可 npm i -g @jackwener/opencli 重装修复')
        if (cliOk) {
          const ds = await this.daemonStatus()
          const daemonRunning = ds?.running === true
          lines.push(`${daemonRunning ? '✓' : '✗'} daemon:${daemonRunning ? (ds?.version ?? '') + (ds?.uptime ? ' · ' + ds.uptime : '') : '未运行/无响应'}`)
          if (!daemonRunning) {
            next.push('opencli daemon restart')
          } else {
            const extLine = (ds?.extension ?? '').trim()
            const profilesLine = (ds?.profiles ?? '').trim()
            const extConnected = /^connected/.test(extLine) || /profiles connected/.test(extLine)
            const noneSelected = /none selected/i.test(extLine)
            if (extConnected && !noneSelected) {
              lines.push(`✓ BrowserBridge:${extLine || 'connected'}`)
            } else if (extConnected && noneSelected) {
              lines.push(`⚠ BrowserBridge:多档案未选默认(${profilesLine})`)
              next.push('opencli profile list 后 opencli profile use <档案名>;若选完仍报"Multiple profiles",升级 CLI:npm i -g @jackwener/opencli@latest(1.8.6 有选择不生效的 bug)')
            } else {
              lines.push('✗ BrowserBridge:扩展未连接')
              next.push('装扩展(需人在浏览器点一次):https://github.com/jackwener/OpenCLI/releases 下载 opencli-extension-*.zip 解压 → Chrome/Edge 扩展页开"开发者模式"→"加载解压缩的扩展";装完等扩展自动重连')
              // 零配置降级声明:红层不再只有"装扩展"一种结局——同步声明当前诚实的可用面,
              // 不让"全部工具族的错误文案都引向先装扩展"高估不可用面
              next.push('零配置继续用:无扩展也能直跑纯 HTTP 只读命令(如 site juejin hot);需浏览器的只读命令当前不可自动降级(CDP 通道默认关闭:attach 现存标签页与匿名承诺冲突),装扩展后自动恢复全部能力')
            }
          }
        }
        const sites = this.adapterCache !== null ? normalizeAdapterList(this.adapterCache.json).length : null
        lines.push(`✓ 插件:${sites !== null ? `${sites} 站目录已注入` : '站点目录后台加载中'} · 审批门 ${this.state.approval === 'on' ? '开' : '关'}`)
        // 重名让位名单:命令"消失"最常见的原因之一,doctor 必须能一眼看到
        if (this.toolConflicts.length > 0) {
          lines.push(`⚠ 工具重名:${this.toolConflicts.join(', ')}——另一插件注册了同名工具,本插件已让位这些命令`)
        }
        if (next.length === 0) {
          lines.push('', '全绿。冒烟建议:site v2ex hot(无需登录);登录态站点先在浏览器登录,再用面板「重新巡检」确认。')
        } else {
          lines.push('', '下一步(按顺序):', ...next.map((s, i) => `${i + 1}. ${s}`))
        }
        return { text: lines.join('\n').slice(0, 3000) }
      },
    })
  }

  /** 一键冒烟基准:固定无需登录的读命令集串行实测出成功率表,报告落盘可追溯。 */
  private registerBenchmarkTool(): void {
    this.registerToolSafe({
      name: 'benchmark',
      description: '跑站点冒烟基准出成功率表:默认 5 个无需登录的读命令(juejin/36kr/hackernews/v2ex/bilibili)串行实测,逐站结果/真实性P/耗时,报告落 ~/.dsh/opencli-benchmarks/。装完环境或升级后先跑这个确认可用面',
      parameters: {
        sites: { type: 'array', items: { type: 'string' }, description: `可选,"站点 命令"条目(如 ["juejin hot"]);缺省用默认集:${DEFAULT_BENCH.join(' / ')}` },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: { sites?: unknown }): Promise<{ text: string }> => {
        const sites = Array.isArray(a.sites) ? a.sites.map(String) : undefined
        const r = await this.benchmarkRun(sites !== undefined ? { sites } : {})
        if (!r.ok) return { text: `基准未完成:${r.error ?? '未知'}` }
        return { text: `${renderBenchmarkTable(r.results ?? []).slice(0, 4000)}\n\n报告已生成:${r.path ?? ''}` }
      },
    })
    this.registerToolSafe({
      name: 'canary',
      description: '站点漂移巡检:top-20 站(按目录命令数)只读命令逐站实测,与上一轮 canary 对比出新失败/恢复,报告落 ~/.dsh/opencli-canary/。诊断"哪些站最近改版坏了"先跑这个;定时任务填 canary 可每晚自动巡检',
      parameters: {},
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (): Promise<{ text: string }> => {
        const r = await this.canaryRun()
        if (!r.ok && r.total === 0) return { text: `canary 未完成:${r.error ?? '未知'}` }
        const drift = r.newFailures.length > 0 ? `\n新失败 ${r.newFailures.length}:${r.newFailures.slice(0, 6).join('、')}` : '\n无新失败'
        const rec = r.recovered.length > 0 ? `\n恢复 ${r.recovered.length}:${r.recovered.slice(0, 6).join('、')}` : ''
        return { text: `canary 巡检:通过 ${r.passed}/${r.total}${drift}${rec}\n报告:${r.path ?? ''}` }
      },
    })
  }

  /** 决策工具(verify 断言 / 封闭选项集选择):亚秒返回,不消耗大模型 token。 */
  private registerDecisionTools(): void {
    this.registerToolSafe({
      name: 'so_verify',
      description: 'SystemOne 亚秒判定:给定任务预期与页面文本,返回 P(符合预期)。比 LLM 断言省 token、快 10 倍以上。低置信(<0.7)时请回退自行判断',
      parameters: {
        expectation: { type: 'string', description: '任务预期(自然语言,如:页面显示的是知乎热榜列表)' },
        page_text: { type: 'string', description: '页面文本(截取相关部分,建议 ≤2000 字)' },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => {
        const r = await this.so.ask(String(a.page_text ?? ''), {
          verify: { type: 'noul', instructions: String(a.expectation ?? '页面状态符合任务预期') },
        })
        if (!r.ok) return { text: `SystemOne 不可用:${r.error ?? '未知'}——请用常规方式自行判断` }
        const v = r.answers.verify
        const p = typeof v?.value === 'number' ? v.value : null
        if (p === null) return { text: '判定失败:模型未返回有效概率,请用常规方式自行判断' }
        const verdict = noulYes({ value: p, confidence: 1 }) ? '符合预期' : '不符合预期'
        return { text: `判定:${verdict}(P=${p.toFixed(2)},置信 ${r.latencyMs}ms 内返回)。低于 0.7 时建议人工复核` }
      },
    })
    this.registerToolSafe({
      name: 'so_pick',
      description: 'SystemOne 亚秒选择:给定目标与封闭选项集,返回最优选项 + 每项概率。适合路由/分类/元素操作选点',
      parameters: {
        goal: { type: 'string', description: '目标(自然语言)' },
        state: { type: 'string', description: '当前状态上下文(元素表/页面摘要,建议 ≤2000 字)' },
        options: { type: 'array', items: { type: 'string' }, description: '封闭选项集(2-30 个,再多请先分层)' },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => {
        const options = Array.isArray(a.options) ? a.options.map(String).filter((o) => o.length > 0) : []
        if (options.length < 2 || options.length > 30) return { text: `选项数量需在 2-30 之间(当前 ${options.length});过多请先分层(先选类目再选具体)` }
        const r = await this.so.ask(String(a.state ?? ''), {
          pick: { type: 'choice', instructions: String(a.goal ?? '选出最符合目标的选项'), criteria: Object.fromEntries(options.map((o) => [o, o])) },
        })
        if (!r.ok) return { text: `SystemOne 不可用:${r.error ?? '未知'}——请用常规方式自行选择` }
        const pick = r.answers.pick
        const choice = typeof pick?.value === 'string' ? pick.value : ''
        const probs = pick?.probabilities ?? {}
        const top = Object.entries(probs).sort((x, y) => (y[1] as number) - (x[1] as number)).slice(0, 3)
          .map(([o, p2]) => `${o} ${(Number(p2) * 100).toFixed(0)}%`).join(' / ')
        return { text: `选择:${choice}\n置信 ${(Number(pick?.confidence ?? 0) * 100).toFixed(0)}%\nTop3:${top}` }
      },
    })
  }

  private registerBrowserTools(): void {
    const run = async (session: string | undefined, argv: string[]): Promise<{ text: string; shot?: string }> => {
      // 轨迹回放(BrowserSkill #79 同款需求):opencli_* 全族与 replay/crawl 等 RPC 透传
      // 统一走 runBrowserTraced 单点,每步 trace 落盘;shot(若有)随结果带给卡片渲染
      const out = await this.runBrowserTraced(session, argv)
      return out.shot !== undefined ? { text: this.renderOut(out), shot: out.shot } : { text: this.renderOut(out) }
    }
    const s = '浏览器会话名(默认 dsh;bind 过的会话复用登录态)'

    // 命名空间迁移:browser_* → opencli_*,注册统一走 registerToolWithLegacyAlias(旧名弃用别名)
    this.registerToolWithLegacyAlias({
      name: 'opencli_open',
      description: '在用户已登录的真实 Chrome 中打开 URL(daemon+扩展桥接,登录态天然可用)',
      parameters: {
        url: { type: 'string', description: '要打开的完整 URL' },
        session: { type: 'string', description: s },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => run(a.session, ['open', String(a.url)]),
    })
    this.registerToolWithLegacyAlias({
      name: 'opencli_state',
      description: '获取当前页状态快照:URL、标题、带 [N] 索引的交互元素清单——后续 click/type/fill 的 target 直接用 [N] 索引或文本',
      parameters: {
        session: { type: 'string', description: s },
        source: { type: 'string', enum: ['dom', 'ax'], description: '快照后端,默认 dom;ax 为无障碍树' },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => run(a.session, ['state', ...(a.source !== undefined ? ['--source', a.source] : [])]),
    })
    this.registerToolWithLegacyAlias({
      name: 'opencli_click',
      description: '点击元素。target 用 opencli_state 里的 [N] 索引(如 "12")或可见文本/CSS',
      parameters: {
        target: { type: 'string', description: '[N] 索引 / 文本 / CSS 选择器' },
        session: { type: 'string', description: s },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => run(a.session, ['click', String(a.target)]),
    })
    this.registerToolWithLegacyAlias({
      name: 'opencli_type',
      description: '点击元素并输入文本(适合搜索框等)',
      parameters: {
        target: { type: 'string', description: '[N] 索引 / 文本 / CSS' },
        text: { type: 'string', description: '要输入的内容' },
        session: { type: 'string', description: s },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => run(a.session, ['type', String(a.target), String(a.text)]),
    })
    this.registerToolWithLegacyAlias({
      name: 'opencli_fill',
      description: '精确设置输入框内容并校验(不清除其他字段)',
      parameters: {
        target: { type: 'string', description: '[N] 索引 / 文本 / CSS' },
        text: { type: 'string', description: '要设置的值' },
        session: { type: 'string', description: s },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => run(a.session, ['fill', String(a.target), String(a.text)]),
    })
    this.registerToolWithLegacyAlias({
      name: 'opencli_extract',
      description: '把当前页正文提取为 Markdown(长页自动分段),适合读文章/帖子/文档',
      parameters: { session: { type: 'string', description: s } },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => run(a.session, ['extract']),
    })
    this.registerToolWithLegacyAlias({
      name: 'opencli_screenshot',
      description: '对当前页截图保存到本地路径(仅在确需视觉信息时使用,优先 opencli_state/opencli_extract;长页/整页内容用 fullPage)',
      parameters: {
        path: { type: 'string', description: '保存路径(绝对路径)' },
        fullPage: { type: 'boolean', description: '截整个可滚动页面而非视口(上游 2.0 --full-page;1.x 忽略此参数)' },
        session: { type: 'string', description: s },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => run(a.session, ['screenshot', ...(a.path !== undefined ? [a.path] : []), ...(a.fullPage === true ? ['--full-page'] : [])]),
    })
    this.registerToolWithLegacyAlias({
      name: 'opencli_scroll',
      description: '滚动页面(up/down/left/right)',
      parameters: {
        direction: { type: 'string', enum: ['up', 'down', 'left', 'right'], description: '滚动方向,默认 down' },
        session: { type: 'string', description: s },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => run(a.session, ['scroll', a.direction ?? 'down']),
    })
    this.registerToolWithLegacyAlias({
      name: 'opencli_wait',
      description: '等待条件成立:selector(如 ".loaded") / text / time(秒) / xhr(如 "/api/search") / download(文件名)',
      parameters: {
        type: { type: 'string', enum: ['selector', 'text', 'time', 'xhr', 'download'], description: '等待类型' },
        value: { type: 'string', description: '对应的值' },
        session: { type: 'string', description: s },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => run(a.session, ['wait', String(a.type), ...(a.value !== undefined ? [a.value] : [])]),
    })
    this.registerToolWithLegacyAlias({
      name: 'opencli_do',
      description: `opencli browser 通用子命令透传(白名单:${[...BROWSER_DO_ALLOW].join(' ')})。常用:analyze(侦察站点反爬/API)、init(生成适配器脚手架)、verify(验证适配器)、tab/find/network/keys/select/hover 等`,
      parameters: {
        command: { type: 'string', description: `子命令,允许值:${[...BROWSER_DO_ALLOW].join('|')}` },
        args: { type: 'array', items: { type: 'string' }, description: '子命令参数(按 opencli browser 文档顺序)' },
        session: { type: 'string', description: s },
      },
      output: { schema: { type: 'json' }, render: browserDoCardRender },
      execute: async (a: ToolArgs) => {
        const cmd = String(a.command)
        if (!BROWSER_DO_ALLOW.has(cmd)) return { text: `不允许的子命令:${cmd}(白名单见工具说明)` }
        return run(a.session, [cmd, ...(a.args ?? [])])
      },
    })
    this.registerToolWithLegacyAlias({
      name: 'opencli_close',
      description: '释放当前浏览器会话的 tab 租约（对应 opencli browser <session> close）',
      parameters: { session: { type: 'string', description: s } },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => run(a.session, ['close']),
    })
    this.registerToolWithLegacyAlias({
      name: 'opencli_read',
      description: '读当前页 URL/标题/正文（opencli_extract 别名，适合公开网页快速读取）',
      parameters: { session: { type: 'string', description: s } },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => run(a.session, ['extract']),
    })
    // 命名空间迁移的合并点:browser_status 与原 opencli_status 的 execute 本就同源(都 dump
    // this.status()),新名重名即合并为一个 opencli_status,旧 browser_status 由兼容层挂别名转发
    this.registerToolWithLegacyAlias({
      name: 'opencli_status',
      description: '运行时状态：daemon/扩展/适配器数/限流与审批策略；连接检查同源（原 browser_status 已并入，先调它再选工具）',
      parameters: {},
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async () => {
        const st = await this.status()
        return { text: JSON.stringify(st, null, 2).slice(0, 4000) }
      },
    })
    this.registerToolWithLegacyAlias({
      name: 'opencli_install',
      description: '环境自检：daemon/扩展/opencli 三件套缺谁补谁（daemon 未跑给 restart 命令，扩展未连给安装指引）',
      parameters: {},
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async () => {
        const st = await this.status()
        if (st.ok && st.daemon?.running === true) return { text: '环境就绪：daemon 运行中，扩展已连接，无需安装。' }
        return { text: `环境缺失：${st.error ?? 'daemon 未运行'}。请先 npm i -g @jackwener/opencli，再 opencli daemon restart，并到 https://github.com/jackwener/opencli/releases 装 BrowserBridge 扩展。` }
      },
    })
    this.registerToolSafe({
      name: 'site_batch',
      description: '批量采集:一条 site 子命令 fan-out 到多个站点并行执行,汇总各站结果;每站结果经 SystemOne noul 真实性判定(空结果/风控页会被标"疑似静默失败")。例:sites=["zhihu","weibo","bilibili"], command="hot" 同时拉三站热榜。',
      parameters: {
        command: { type: 'string', description: 'site 子命令(不含站点名),如 hot/search/recent' },
        sites: { type: 'array', items: { type: 'string' }, description: '站点名列表(2-6 个)' },
        args: { type: 'array', items: { type: 'string' }, description: '可选:命令参数' },
        preflight: { type: 'boolean', description: '可选:派发前登录态快检(whoami 池,带 TTL 缓存);未登录站标 ⚠。无人值守/可靠性敏感时开' },
        skipNotLoggedIn: { type: 'boolean', description: '可选:配合 preflight,未登录站不进批次(输出 ⛔ 行列出)' },
      },
      output: { schema: { type: 'json' }, render: siteBatchCardRender },
      execute: async (a: { command?: unknown; sites?: unknown; args?: unknown; preflight?: unknown; skipNotLoggedIn?: unknown }): Promise<{ text: string }> => {
        const command = String(a.command ?? '').trim()
        const sites = Array.isArray(a.sites) ? a.sites.map(String).slice(0, 6) : []
        if (!command) return { text: 'command 不能为空。' }
        if (sites.length < 2) return { text: 'sites 至少 2 个站点。' }
        if (sites.some((x) => !/^[\w.-]+$/.test(x))) return { text: '站点名含非法字符。' }
        // 派发前目录预检(只读缓存,不触发 list):站点不存在立刻提醒,省 45s 超时
        let known: Set<string> | null = null
        const domainOf = new Map<string, string>()
        if (this.adapterCache !== null && Date.now() - this.adapterCache.at < ADAPTER_TTL_MS) {
          known = new Set()
          for (const x of normalizeAdapterList(this.adapterCache.json)) {
            const n = String(x.name).toLowerCase()
            known.add(n)
            if (x.domain !== undefined) domainOf.set(n, String(x.domain).toLowerCase())
          }
        }
        const unknownSites = known === null ? [] : sites.filter((s) => !known!.has(s))
        // 安全审查 HIGH:批量是采集语义,写命令一律整批拒绝(fail-closed)——此前 command 只查
        // 非空,`site_batch {command:"publish"}` 可在审批门开启下多站直发写命令。未知站点不在此
        // 拦(它们由下方目录预检的拼写提醒负责,信息更有用)
        {
          const offenders: string[] = []
          for (const s of sites.filter((x) => !unknownSites.includes(x))) {
            const acc = await this.lookupAccess(s, command)
            if (acc !== 'read') offenders.push(`${s} ${command}(${acc === 'write' ? '写命令' : '未知权限'})`)
          }
          if (offenders.length > 0) return { text: `批量采集只接受只读命令,以下组合被拒:${offenders.join('、')}。写命令请逐站走 site 工具(带审批门与证据包)。` }
        }
        // 登录态 preflight(BrowserSkill #132 同源问题:同域并行互相踩登录态/标签页且无报错):
        // 同域站点改为组内串行,其余照常并行
        const byDomain = new Map<string, string[]>()
        for (const s of sites) {
          const d = domainOf.get(s)
          if (d !== undefined) { const arr = byDomain.get(d) ?? []; arr.push(s); byDomain.set(d, arr) }
        }
        const collisions = [...byDomain.entries()].filter(([, ss]) => ss.length > 1)
        const chained = new Set(collisions.flatMap(([, ss]) => ss))
        const preflightNote = collisions.length > 0
          ? `preflight:同域冲突已串行化(${collisions.map(([d, ss]) => `${ss.join(' + ')} → ${d}`).join(';')}),避免登录态/标签页互踩\n\n`
          : ''
        // 派发前登录态快检(0.4.7 W5',复用 login-check 的 whoami 池+TTL 缓存):
        // 未登录站标 ⚠(结果可能是登录墙,事后 noul 才发现=烧完整超时);skipNotLoggedIn=true
        // 时直接不进批次(⛔ 行列出)。preflight 旁路纪律:体检任何失败不挡批次。默认关。
        const wantPreflight = a.preflight === true
        const skipNotLoggedIn = a.skipNotLoggedIn === true
        let loginLines: string[] = []
        let effSites = sites
        if (wantPreflight) {
          try {
            const lc = await this.loginCheck()
            if (lc.ok) {
              const bySite = new Map(lc.results.map((r) => [r.site.toLowerCase(), r] as const))
              const eff: string[] = []
              for (const s0 of sites) {
                const r = bySite.get(s0.toLowerCase())
                if (r === undefined || r.ok === true) { eff.push(s0); continue }
                if (skipNotLoggedIn) loginLines = [...loginLines, `⛔ ${s0}:未登录,已跳过(先逐站 site ${s0} login)`]
                else { eff.push(s0); loginLines = [...loginLines, `⚠ ${s0}:未登录——结果可能是登录墙(先逐站登录,或带 skipNotLoggedIn 跳过)`] }
              }
              effSites = eff
              // 显式 skip 语义:跳剩几站跑几站(拦 0 不拦 1——batch 下限闸只管输入,不管显式摘除)
              if (effSites.length < 1) return { text: `登录态快检后全部未登录(${loginLines.join(';')})。请先逐站登录再批量。` }
            }
          } catch { /* 体检旁路:失败照常派发 */ }
        }
        const args = Array.isArray(a.args) ? a.args.map(String) : []
        const runOne = async (site: string): Promise<{ site: string; ok: boolean; badge: string; text: string }> => {
          try {
            const out = await this.runOpencli([site, command, ...args], 45_000)
            if (out.exitCode !== 0) return { site, ok: false, badge: '', text: out.stderr.slice(0, 900) }
            const v = await this.verifyResult(site, command, out.stdout)
            return { site, ok: true, badge: this.verifyBadge(v), text: out.stdout.slice(0, 900) }
          } catch (err: unknown) {
            return { site, ok: false, badge: '', text: err instanceof Error ? err.message.slice(0, 200) : 'failed' }
          }
        }
        const settled = await Promise.all([
          ...effSites.filter((s) => !chained.has(s)).map(runOne),
          ...collisions.map(async ([, ss]) => { const out = []; for (const s of ss) if (effSites.includes(s)) out.push(await runOne(s)); return out }),
        ])
        const results = settled.flat()
        // 按请求顺序回填输出
        results.sort((x, y) => effSites.indexOf(x.site) - effSites.indexOf(y.site))
        const okN = results.filter((r) => r.ok).length
        const silentN = results.filter((r) => r.badge.includes('疑似静默失败')).length
        const head = `批量采集 ${okN}/${effSites.length} 站成功${silentN > 0 ? `,其中 ${silentN} 站疑似静默失败(exit 0 但内容无效)` : ''}:\n\n`
        const loginSeg = loginLines.length > 0 ? `登录态快检:\n${loginLines.join('\n')}\n\n` : ''
        const pre = `${unknownSites.length > 0 ? `目录预检:以下站点不在适配器目录,请确认拼写:${unknownSites.join(', ')}\n\n` : ''}${preflightNote}${loginSeg}`
        const body = results.map((r) => `== ${r.site} ${r.ok ? '✓' : '✗'}${r.badge} ==\n${r.text}`).join('\n\n')
        // 报告导出(主线 B 渲染层):多站结果合并为带出处 markdown,落盘并在工具输出附路径
        let reportTail = ''
        try {
          const sources: ReportSource[] = results.map((r) => ({
            site: r.site, command: `site ${r.site} ${command}${args.length > 0 ? ` ${args.join(' ')}` : ''}`,
            at: new Date().toISOString(), text: r.text,
            status: (!r.ok ? 'fail' : r.badge.includes('疑似静默失败') ? 'silent' : r.badge.includes('内容可疑') ? 'suspect' : 'ok') as ReportSource['status'],
            ...(r.badge.length > 0 ? { note: r.badge.replace(/^\(|\)$/g, '') } : {}),
          }))
          // 报告出口统一过 URL 凭据参数脱敏(卫生包:批量源是现场输出、不经快照落盘清洗,出口补洗;
          // 与报告尾注「凭据类查询参数已脱敏」的声明一致)
          const md = scrubUrlParams(buildReport(`批量采集报告 · ${command}`, sources, new Date().toISOString()))
          const dir = process.env.DSH_OPENCLI_REPORTS_DIR ?? join(homedir(), '.dsh', 'opencli-reports')
          await mkdir(dir, { recursive: true })
          const file = join(dir, `batch-${Date.now()}.md`)
          await writeFile(file, md, 'utf8')
          reportTail = `\n\n📄 报告已生成:${file}`
        } catch { /* 报告失败不阻断采集输出 */ }
        return { text: pre + head + body + reportTail }
      },
    })

    this.registerToolSafe({
      name: 'site_knowledge',
      description: '站点知识卡:对某站动手前先读——结构化命令目录+已知坑+失败签名恢复表。命中失败签名按 recovery 自救,别现场试错。知识分发上游已砍(#2539),本卡是补位',
      parameters: {
        site: { type: 'string', description: '站点名(如 weibo / xiaohongshu)' },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => {
        const site = String(a.site ?? a.value ?? '').trim()
        if (site.length === 0 || !/^[\w.-]+$/.test(site)) return { text: '站点名非法(如 weibo)' }
        const list = await this.adapterList()
        if (list === null) return { text: `目录不可用 | ${this.lastShellError ?? '未知'}` }
        const raw = (this.adapterCache as { json?: unknown } | null)?.json
        const k = buildKnowledge(site, Array.isArray(raw) ? raw as RawEntry[] : [])
        if (k === null) return { text: `目录里没有 ${site}(用 opencli_catalog 确认拼写)。不在目录的通用需求直接用 opencli_* 原语自由浏览` }
        return { text: renderKnowledgeMarkdown(k).slice(0, 6000) }
      },
    })
    this.registerToolSafe({
      name: 'opencli_catalog',
      description: '按 query/site/access 过滤 170+ 适配器目录，单次最多 100 条（不确定命令先查它，别猜）',
      parameters: {
        query: { type: 'string', description: '关键词（如 search）' },
        site: { type: 'string', description: '站点名（如 reddit）' },
        access: { type: 'string', enum: ['read', 'write'], description: '权限过滤' },
        limit: { type: 'string', description: '返回条数，默认 10，最大 100' },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => {
        const list = await this.adapterList()
        if (list === null) return { text: `opencli list 不可用 | ${this.lastShellError ?? '未知'}` }
        const q = a.query !== undefined ? String(a.query).toLowerCase() : ''
        const site = a.site !== undefined ? String(a.site).toLowerCase() : ''
        const filtered = list.filter((x) => (q.length === 0 || x.name.toLowerCase().includes(q)) && (site.length === 0 || x.name.toLowerCase().includes(site))).slice(0, 100)
        return { text: JSON.stringify(filtered.slice(0, 10), null, 2).slice(0, 4000) + `\n…共 ${filtered.length} 条` }
      },
    })
    this.registerToolSafe({
      name: 'opencli_run',
      description: '通用 OpenCLI argv 网关（站点命令经写审批门:write/未知权限弹审批,只读放行;浏览器/系统子命令按 opencli_* 同款边界;常规搜索优先 site 直调）',
      parameters: {
        args: { type: 'array', items: { type: 'string' }, description: 'argv 数组（如 ["reddit","search","DeepSeek Harness"]），不拼 shell' },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => {
        const argv = Array.isArray(a.args) ? a.args.map(String) : []
        if (argv.length === 0) return { text: 'args 为空' }
        const out = await this.runOpencli(argv)
        return { text: this.renderOut(out) }
      },
    })
  }

  // ── chrome_* 原生管理工具族──────────────────────

  /**
   * opencli 2.0 `browser chrome call <method> <args>` 免页面会话桥:原生 Chrome ID 管理标签/分组/窗口,
   * 不占 tab 租约、不建 browser session,与 opencli_*(页面会话原语)互补。刻意不走 runBrowserTraced——
   * 那会强加 --session 并触发步骤补拍,chrome 通道两者都不该有;轨迹仍进「运行轨迹」,
   * 故单点 runChromeCall 手写 runOpencli + recordTrace(cmd 以 chrome 前缀区分 browser 步骤)。
   */
  private registerChromeTools(): void {
    const out = (text: string): { text: string } => ({ text })
    // tabs 工具收 tabs.* 全族;groups 工具收 tabGroups.* 外加 tabs.group/ungroup——
    // 上游没有 tabGroups.create,建组/拆组经 tabs API 完成(上游 CHROME_METHODS 的实际形状)
    const tabsAllow = [...CHROME_METHODS_ALLOW].filter((m) => m.startsWith('tabs.'))
    const groupsAllow = [...CHROME_METHODS_ALLOW].filter((m) => m.startsWith('tabGroups.') || m === 'tabs.group' || m === 'tabs.ungroup')
    this.registerToolSafe({
      name: 'chrome_tabs',
      description: '原生 Chrome 标签管理(免页面会话,opencli 2.0):tabs.query 列出标签拿 tabId / tabs.create 新建 / tabs.remove 关闭 / tabs.update 激活选中;get/duplicate/move/group/ungroup 亦可。args 为该方法位置参数的 JSON 数组字符串,如 tabs.update 传 [123, {"active": true}]',
      parameters: {
        // 不用 enum:dsh-tools 会在 wrapper 层校验拦截,模型只能看到通用报错;走 execute 内
        // 白名单才能给出"改用 chrome_raw"的确切指引(opencli_do 同款约定)
        method: { type: 'string', description: `tabs.* 管理方法,允许值:${tabsAllow.join('|')}(列出=tabs.query / 新建=tabs.create / 关闭=tabs.remove / 选中激活=tabs.update)` },
        args: { type: 'string', description: '位置参数 JSON 数组字符串,缺省 []' },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: { method?: unknown; args?: unknown }): Promise<{ text: string }> => {
        const method = String(a.method ?? '')
        if (!CHROME_METHODS_ALLOW.has(method) || !method.startsWith('tabs.')) {
          return out(`不允许的 method:${method}。chrome_tabs 只收 tabs.* 管理方法(${tabsAllow.join(' ')});windows.* 或白名单外方法走 chrome_raw(高危,需人工确认)`)
        }
        return await this.runChromeTool(method, a.args)
      },
    })
    this.registerToolSafe({
      name: 'chrome_groups',
      description: '原生 Chrome 标签分组管理(免页面会话,opencli 2.0):tabs.group 建组并收拢标签 / tabGroups.update 改名/换色/折叠 / tabGroups.move 整组移动;tabGroups.query/get 先查 groupId。args 为位置参数 JSON 数组字符串,如 tabGroups.update 传 [456, {"title": "研究", "color": "blue"}]',
      parameters: {
        method: { type: 'string', description: `分组管理方法,允许值:${groupsAllow.join('|')}(建组收拢=tabs.group / 改名折叠=tabGroups.update / 整组移动=tabGroups.move)` },
        args: { type: 'string', description: '位置参数 JSON 数组字符串,缺省 []' },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: { method?: unknown; args?: unknown }): Promise<{ text: string }> => {
        const method = String(a.method ?? '')
        if (!CHROME_METHODS_ALLOW.has(method) || !(method.startsWith('tabGroups.') || method === 'tabs.group' || method === 'tabs.ungroup')) {
          return out(`不允许的 method:${method}。chrome_groups 只收 tabGroups.* 与 tabs.group/ungroup(${groupsAllow.join(' ')});其余方法走 chrome_raw(高危,需人工确认)`)
        }
        return await this.runChromeTool(method, a.args)
      },
    })
    this.registerToolSafe({
      name: 'chrome_raw',
      description: 'chrome 原生方法逃生口(高危):任意 method + JSON args 直调 browser chrome call——含 windows.* 窗口管理与白名单之外的方法,可能关闭窗口/重排真实浏览器布局。每次调用都会弹审批窗人工确认(写审批门覆盖)',
      parameters: {
        method: { type: 'string', description: '原生方法名(命名空间.方法,如 windows.create/windows.remove)' },
        args: { type: 'string', description: '位置参数 JSON 数组字符串,缺省 []' },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: { method?: unknown; args?: unknown }): Promise<{ text: string }> => {
        const method = String(a.method ?? '').trim()
        if (!/^[\w.]+$/.test(method)) return out(`method 非法:${method}(应为 chrome 原生方法名,如 windows.getAll)`)
        return await this.runChromeTool(method, a.args)
      },
    })
  }

  /** chrome_* 三工具共用执行尾段:args 归一 → 1.x 门 → runChromeCall。 */
  private async runChromeTool(method: string, rawArgs: unknown): Promise<{ text: string }> {
    // args 归一:缺省=空数组;模型直传数组原样收下(宽容);字符串必须 parse 成数组(位置参数语义)
    let args: unknown[] = []
    if (Array.isArray(rawArgs)) args = rawArgs
    else if (rawArgs !== undefined && rawArgs !== null && String(rawArgs).trim().length > 0) {
      let parsed: unknown
      try { parsed = JSON.parse(String(rawArgs)) } catch (e) {
        return { text: `args 不是合法 JSON:${e instanceof Error ? e.message : String(e)}(应为位置参数 JSON 数组,如 [123, {"active": true}])` }
      }
      if (!Array.isArray(parsed)) return { text: 'args 需为 JSON 数组(位置参数),如 tabs.update 传 [123, {"active": true}]' }
      args = parsed
    }
    // 1.x CLI 没有 chrome 子命令:直接给升级指引,不发注定失败的调用
    const major = await this.cliMajor()
    if (major < 2) {
      return { text: `chrome 原生管理需 opencli 2.0+(当前大版本 ${major})。升级:npm i -g @jackwener/opencli@latest 后 opencli daemon restart` }
    }
    return await this.runChromeCall(method, args)
  }

  /**
   * browser chrome call 单点。CLI 签名为 `call <method> [args]`且 args 是"整个位置参数列表的
   * JSON 数组字符串"(实探 2.0.0 --help),故恒传显式 '[]' 保证 argv 确定性。输出经 runOpencli
   * 自带的 2.0 信封解包;扩展 1.0.24 及以前该通道报 "Browser session is required"——
   * 补升级指引而不是让用户面对裸错(本机实测 2026-10-20,describe 同款报错)。
   */
  private async runChromeCall(method: string, args: unknown[]): Promise<{ text: string }> {
    // ⑤ 无扩展短路(同④):chrome 通道同样经 daemon→扩展(且需扩展 ≥1.0.25),
    // 显式未连时不发注定失败的调用,直接给装扩展指引
    if ((await this.extensionState()).explicitDown) {
      const out = { exitCode: 1, stdout: '', stderr: NO_EXT_GUIDANCE }
      this.recordTrace(`chrome ${method} [no-ext]`, out, 0)
      return { text: this.renderOut(out) }
    }
    const started = Date.now()
    const out = await this.runOpencli(['browser', 'chrome', 'call', method, JSON.stringify(args)], 30_000)
    this.recordTrace(`chrome ${method}`, out, Date.now() - started)
    const text = this.renderOut(out)
    if (/Browser session is required/i.test(`${out.stderr}\n${out.stdout}`)) {
      return { text: `${text}\n\nBrowserBridge 扩展版本过低:chrome 通道需 1.0.25+(当前 1.0.24 不识别 chrome-describe/chrome-call)。到 https://github.com/jackwener/opencli/releases 更新扩展后重试。` }
    }
    return { text }
  }

  private registerAdvancedTools(): void {
    const out = (text: string): { text: string } => ({ text })
    this.registerToolSafe({
      name: 'script_catalog',
      description: '列出内置只读脚本 article/links/jsonld/forms（不跑外来代码，读文章最稳）',
      parameters: {},
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async () => out('内置只读脚本：article（正文Markdown）/ links（链接）/ jsonld / forms，用 script_run_builtin 运行'),
    })
    this.registerToolSafe({
      name: 'script_run_builtin',
      description: '运行内置只读脚本（独立 context，不执行外来代码）',
      parameters: {
        name: { type: 'string', description: 'article|links|jsonld|forms' },
        url: { type: 'string', description: '目标 URL（可选，默认当前页）' },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => {
        const r = await this.scriptRunBuiltin({ name: String(a.command ?? a.value ?? 'article'), url: a.url !== undefined ? String(a.url) : undefined })
        return out(r.result ?? r.error ?? 'ok')
      },
    })
    this.registerToolSafe({
      name: 'script_validate',
      description: '校验外部 UserScript（需 @match + @grant none，≤64KB），不执行',
      parameters: { code: { type: 'string', description: 'UserScript 源码' } },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => {
        const r = await this.scriptValidate({ code: String(a.text ?? '') })
        return out(JSON.stringify(r).slice(0, 2000))
      },
    })
    this.registerToolSafe({
      name: 'userscript_run',
      description: '运行外部 UserScript（强制域名匹配，standard 需审批，unrestricted 直行）',
      parameters: {
        code: { type: 'string', description: '已 validate 通过的源码' },
        url: { type: 'string', description: '目标 URL' },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => {
        const r = await this.userscriptRun({ code: String(a.text ?? ''), url: String(a.url ?? '') })
        return out(r.result ?? r.error ?? 'ok')
      },
    })
    this.registerToolSafe({
      name: 'recipe_run',
      description: '跑 25 步内 Playwright Recipe（wait/click/fill/type/press/select/check/hover/scroll/extract/assert/screenshot，可审计）',
      parameters: { steps: { type: 'string', description: 'JSON 数组字符串' } },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => {
        try {
          const steps = JSON.parse(String(a.text ?? a.value ?? '[]')) as Array<{ type: string; selector?: string; value?: string }>
          const r = await this.recipeRun({ steps })
          return out(r.ok ? 'recipe 执行成功' : (r.error ?? '失败'))
        } catch (e) { return out(`steps 解析失败：${e instanceof Error ? e.message : String(e)}`) }
      },
    })
    this.registerToolSafe({
      name: 'automation_search',
      description: '检索已存自动化资产（录制/定时），只回 ID+摘要，不进全文',
      parameters: { query: { type: 'string', description: '关键词' } },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => {
        const r = await this.automationSearch({ query: a.text !== undefined ? String(a.text) : undefined })
        return out(JSON.stringify(r.hits).slice(0, 2000))
      },
    })
    this.registerToolSafe({
      name: 'automation_run',
      description: '按 ID 运行已存资产（录制/定时），限域+限流仍生效',
      parameters: { id: { type: 'string', description: '资产 ID' } },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => {
        const r = await this.automationRun({ id: String(a.value ?? a.text ?? '') })
        return out(r.ok ? '执行成功' : (r.error ?? '失败'))
      },
    })
    this.registerToolWithLegacyAlias({
      name: 'opencli_crawl',
      description: '有限广度遍历（同源默认，maxPages 20 / maxDepth 2 硬限，usagePolicy 限流）',
      parameters: {
        url: { type: 'string', description: '起始 URL' },
        maxPages: { type: 'string', description: '最大页数，默认 20' },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => {
        const r = await this.crawl({ url: String(a.url ?? ''), maxPages: Number(a.value ?? 20) })
        return out(r.ok ? 'crawl 已启动（MVP 单页）' : (r.error ?? '失败'))
      },
    })
    this.registerToolSafe({
      name: 'trace_replay',
      description: '轨迹回放:最近 30 步 browser 命令的 markdown 时间线(时间/命令/exit/耗时,失败步附输出摘录)。复盘"上次为什么失败"先调它,别盲目重试',
      parameters: {},
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async () => out(await this.renderTraceTimeline(30)),
    })
  }

  // ── canvas VOM 工具族:eval 桥────────────────────
  // 前提(2026-10 对上游交互族的实测):上游 browser 交互族 selector-first、无坐标
  // 参数,canvas 位图内部无 DOM/AX 目标——唯一能触及 canvas 数据面的通道是 browser eval。
  // 这里把 src/vom.ts 编译出的页面 JS 经 runBrowserTraced 单点下发(eval 子命令自动进
  // 「运行轨迹」,与 opencli_* 全族同一复盘链路)。审批归类:坐标点击在登录态
  // 页面产生真实副作用,按写原语走审批门(registerApprovalGate 的 canvas_click 分支);
  // discover/read 只读自动放行——生成物是本插件固定的探测脚本,不是任意代码。

  /** canvas VOM 三件套:发现(discover)→ 读像素(read)→ 坐标点击(click,需审批)。 */
  private registerVomTools(): void {
    const s = '浏览器会话名(默认 dsh;bind 过的会话复用登录态)'
    this.registerToolSafe({
      name: 'canvas_discover',
      description: '发现当前页所有 canvas 元素(eval 桥,只读):返回每块画布的索引/视口坐标(x,y)/尺寸(w,h)/id。HTML5 游戏/图表/画板类页面定位画布入口先调它,结果里的 index 给 canvas_read 用,坐标给 canvas_click 用。注意:本族作用于网页内的 canvas 元素,与面板「画布」标签页(你的活动复盘视图)同名不同层',
      parameters: { session: { type: 'string', description: s } },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs) => {
        const out = await this.runBrowserTraced(a.session, ['eval', buildCanvasDiscoveryJs()])
        return { text: this.renderOut(out) }
      },
    })
    this.registerToolSafe({
      name: 'canvas_read',
      description: '读取指定 canvas 内容为 PNG base64(eval 桥 toDataURL,只读):index 用 canvas_discover 返回的索引(默认 0)。注意:大画布的 base64 会被输出上限截断(完整图请配 opencli_screenshot);跨域污染的画布会报 SecurityError。w/h 是画布缓冲分辨率,非显示尺寸。读到的位图自动落盘并进面板「画布」页卡片供人事后复核(网页 canvas 层与面板画布复盘层的接通点)',
      parameters: {
        index: { type: 'string', description: 'canvas 索引(canvas_discover 返回的 index,默认 0)' },
        session: { type: 'string', description: s },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: { index?: unknown; session?: unknown }): Promise<{ text: string }> => {
        const idx = Math.floor(Number(a.index ?? '0'))
        // 本地先校验再发往返:脏索引在插件层就挡下,不浪费一次注定失败的 eval 调用
        if (!Number.isFinite(idx) || idx < 0) return { text: `index 非法:${String(a.index ?? '')}(应为 canvas_discover 返回的非负索引)` }
        const sess = typeof a.session === 'string' && a.session.length > 0 ? a.session : undefined
        const out = await this.runBrowserTraced(
          sess,
          ['eval', buildCanvasReadJs(idx)],
          // 消除断点:读到的画布位图经 saveCanvasReadShot 落盘挂进轨迹 shot → 画布卡片图片回放
          { deriveShot: (raw) => this.saveCanvasReadShot(sess, idx, raw) },
        )
        const note = out.shot !== undefined && basename(out.shot).startsWith('canvas-')
          ? `\n(画布位图已存 ${out.shot} — 已进面板「画布」页卡片,可回放复核)` : ''
        return { text: this.renderOut(out) + note }
      },
    })
    this.registerToolSafe({
      name: 'canvas_click',
      description: `坐标点击(eval 桥,写原语,每次执行需人工审批):在视口坐标 (x,y) 对 elementFromPoint 命中的元素合成 click——canvas 内部无 DOM 目标时的点选通路,坐标来自 canvas_discover 或截图目测。${CANVAS_CLICK_UNTRUSTED_NOTE}。页面滚动后旧坐标失效,先重新 discover`,
      parameters: {
        x: { type: 'string', description: '视口横坐标(px)' },
        y: { type: 'string', description: '视口纵坐标(px)' },
        session: { type: 'string', description: s },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: { x?: unknown; y?: unknown; session?: unknown }): Promise<{ text: string }> => {
        const x = Number(a.x)
        const y = Number(a.y)
        // 本地校验同 canvas_read:脏坐标不下发注定点错的代码
        if (!Number.isFinite(x) || !Number.isFinite(y)) return { text: `坐标非法:x=${String(a.x ?? '')} y=${String(a.y ?? '')}(应为数字,px)` }
        const out = await this.runBrowserTraced(
          typeof a.session === 'string' && a.session.length > 0 ? a.session : undefined,
          ['eval', buildCoordClickJs(x, y)],
        )
        return { text: this.renderOut(out) }
      },
    })
  }

  private registerSiteTool(): void {
    // W3 命令选择分层:so_pick 两步路由(先站后命令),亚秒零 token;
    // 与 systemPrompt 目录共存——目录仍是兜底,本工具是"不想翻目录时"的快速路。
    this.registerToolSafe({
      name: 'site_route',
      description: '亚秒命令路由:给目标(自然语言),SystemOne 两步 choice(先选站再选命令)直接给出 site 命令行+备选。不确定命令名时用它,别翻目录猜',
      parameters: {
        goal: { type: 'string', description: '目标(如:看微博热搜/搜 B站罗翔视频/查 arxiv agent 论文)' },
        site: { type: 'string', description: '可选:已知站点名则锁定该站,只做命令层选择' },
      },
      output: { schema: { type: 'json' }, render: (_a: unknown, v: { text: string }) => [{ type: 'text', text: v.text }] },
      execute: async (a: ToolArgs): Promise<{ text: string }> => {
        const goal = String(a.goal ?? a.text ?? '').trim()
        if (goal.length === 0) return { text: 'goal 不能为空' }
        const list = await this.adapterList()
        if (list === null) return { text: `目录不可用 | ${this.lastShellError ?? '未知'}` }
        // 第一层:选站(候选压到 top 24 by 命令数,choice 单题候选 ≤30 官方范式)
        let pool = list
        if (typeof a.site === 'string' && a.site.length > 0) {
          const lock = a.site.toLowerCase()
          pool = list.filter((x) => x.name.toLowerCase() === lock)
          if (pool.length === 0) return { text: `目录里没有 ${a.site}(用 opencli_catalog 确认)` }
        }
        let siteName = pool[0]?.name ?? ''
        if (pool.length > 1) {
          const cand = pool.slice(0, 24)
          const r1 = await this.so.ask(cand.map((x) => `${x.name}(${x.commandCount} 命令,示例:${x.commands.slice(0, 3).join('/')})`).join('; '), {
            pickSite: { type: 'choice', instructions: `目标:${goal}。选出最合适的站点`, criteria: Object.fromEntries(cand.map((x) => [x.name, `${x.commandCount} 命令:${x.commands.slice(0, 5).join(',')}...`])) },
          })
          if (r1.ok && typeof r1.answers.pickSite?.value === 'string' && r1.answers.pickSite.value.length > 0) siteName = r1.answers.pickSite.value
          else return { text: '路由不可用(SystemOne down)——请直接查 systemPrompt 目录选命令' }
        }
        // 第二层:该站选命令
        const detail = await this.adapterDetail({ name: siteName } as never).catch(() => null)
        const cmds = detail?.ok === true ? detail.commands.map((c: { name: string; description?: string }) => ({ n: c.name, d: c.description ?? '' })) : pool.find((x) => x.name === siteName)?.commands.slice(0, 24).map((c) => ({ n: c, d: '' })) ?? []
        if (cmds.length === 0) return { text: `${siteName} 无命令目录` }
        const r2 = await this.so.ask(`站点:${siteName}。目标:${goal}`, {
          pickCmd: { type: 'choice', instructions: '选出最合适的命令', criteria: Object.fromEntries(cmds.slice(0, 24).map((c) => [c.n, c.d])) },
        })
        if (!r2.ok || typeof r2.answers.pickCmd?.value !== 'string') return { text: `站点锁定 ${siteName};命令层 SystemOne 不可用,备选:${cmds.slice(0, 6).map((c) => c.n).join(', ')}` }
        const top = Object.entries(r2.answers.pickCmd.probabilities ?? {}).sort((x, y) => (y[1] as number) - (x[1] as number)).slice(0, 3).map(([c, p]) => `${c} ${(Number(p) * 100).toFixed(0)}%`).join(' / ')
        return { text: `命令:\`site ${siteName} ${r2.answers.pickCmd.value}\`${top ? `\nTop3:${top}` : ''}(低置信或不对时查 site_knowledge ${siteName} 或 systemPrompt 目录)` }
      },
    })
    this.registerToolSafe({
      name: 'site',
      description: '调用站点适配器(在用户登录态上返回结构化结果,比逐页点击快且稳)。adapter/command 见 systemPrompt 里的适配器目录;示例:site bilibili search 关键词=罗翔。authProfile 限域（需配置 allowedDomains）',
      parameters: {
        adapter: { type: 'string', description: '适配器名(如 bilibili/zhihu/arxiv)' },
        command: { type: 'string', description: '适配器子命令(如 search/hot/top)' },
        args: { type: 'array', items: { type: 'string' }, description: '子命令参数' },
        authProfile: { type: 'string', description: '限域登录态 profile（需在配置中预设 allowedDomains，默认不回写 Cookie）' },
      },
      output: { schema: { type: 'json' }, render: siteCardRender },
      execute: async (a: ToolArgs): Promise<{ text: string }> => {
        const adapter = String(a.adapter)
        const command = String(a.command)
        if (!/^[\w@.-]+$/.test(adapter) || !/^[\w-]+$/.test(command)) {
          return { text: `非法 adapter/command:${adapter} ${command}` }
        }
        if (this.state.disabled.includes(adapter)) {
          return { text: `适配器 ${adapter} 已被禁用(设置→浏览器代理 可重新启用)。` }
        }
        const domain = await this.domainOf(adapter)
        const authErr = this.checkAuthProfile(domain, a.authProfile !== undefined ? String(a.authProfile) : undefined)
        if (authErr !== null) return { text: authErr }
        const argv = [adapter, command, ...(a.args ?? [])]
        // 写命令证据包(任务 D):审批门放行的写命令 before/after 各拍一张截图,连同结果落
        // ~/.dsh/opencli-evidence/;失败也落——证据比成功更重要。读命令只付一次缓存查询;
        // 截图/落盘全程静默降级,绝不反噬写命令的结果回传。
        // 覆盖面(评审发现):unknown 权限被审批门按写放行后同样留证据——目录外的命令
        // 恰是最该留痕的一类,'===write' 会漏掉它们
        const evidenceOn = (await this.lookupAccess(adapter, command)) !== 'read'
        const beforeShot = evidenceOn ? await this.captureEvidenceShot() : undefined
        // 零配置降级路由:确定无扩展时——browser:false 直跑(①现状零改动);
        // browser:true 只读命令命中本机 CDP 端点则匿名降级(②注入 env+flag);无端点按④诚实报不可用;
        // 写/未知权限命令在 zeroCfgPlan 内部按硬不变量直接返回 null,走现状路径
        const zc = await this.zeroCfgPlan(adapter, command)
        if (zc !== null && zc.mode === 'skip') return { text: zc.text }
        const inj = zc !== null && zc.mode === 'inject' ? zc : null
        // #59 读写分频:写/未知权限(与审批门、证据包同口径——未知按写)走 3s 独立写轨,读走 750ms 轨
        const out = await this.runOpencli(
          inj !== null ? [...argv, ...inj.argvTail] : argv,
          60_000, 1_048_576,
          inj !== null ? inj.env : undefined,
          evidenceOn ? 'write' : 'read',
        )
        if (evidenceOn) await this.recordSiteEvidence(adapter, command, argv, out, beforeShot)
        const text = this.renderOut(out)
        // 匿名降级标注(硬边界):降级路径的输出必须可识别,避免用户误以为是登录态数据
        const anon = inj !== null ? '【匿名降级】当前无扩展,本命令经本机匿名 CDP 会话执行——不是你的登录态数据。\n' : ''
        if (text.trim() === '[]') {
          return { text: inj !== null
            ? `${anon}适配器 ${adapter} 返回空(匿名会话无登录态;若该站需要登录,装扩展后可恢复:https://github.com/jackwener/OpenCLI/releases)`
            : `适配器 ${adapter} 返回空（可能未登录或无数据）。请先在真实 Chrome 登录 ${adapter}，或运行 \`opencli ${adapter} login\` 后用面板“巡检登录态”确认。` }
        }
        if (out.exitCode !== 0 && /Navigation rejected/i.test(text)) return { text: `${anon}导航被拒（${adapter}）：请确认 Chrome 扩展已连接且已登录 ${adapter}，或先 \`opencli ${adapter} login\`。原错：${text.slice(0,300)}` }
        // ③(零配置路由矩阵 ③):无扩展时的 AUTH 失败不是"去浏览器登录"能解决的——登录态整体不可用,
        // 换成降级引导(装扩展+为何不能降级);有扩展时维持原登录指引不变
        if (out.exitCode !== 0 && /AUTH_REQUIRED|请先登录|NOT_LOGGED_IN/i.test(`${out.stdout}\n${out.stderr}`) && (await this.extensionState()).connected === false) {
          return { text: `${anon}登录态缺失:当前无扩展,登录态(COOKIE)命令整体不可用——匿名会话拿不到你的 cookie,写命令也永不降级。装扩展后可恢复:https://github.com/jackwener/OpenCLI/releases。原错:${text.slice(0, 300)}` }
        }
        // 真实性判定标注(与 site_batch/try-run 同源 verifyResult/verifyBadge):exit 0 ≠ 有效数据,
        // 登录墙/风控页/空壳以 ⚠ 前缀标注进 {text},预览卡(siteCardRender)据此落 ⚠ 琥珀。
        // 只标注不拦截——模型仍见原文(与 site_batch 先例一致;拦截级处置留给无人值守的 schedule 路径)。
        // warmOnly:laya 预热窗口内跳过 noul 兜底(规则层照跑)——最高频工具不背 ~60s 冷加载/权重下载;
        // SystemOne 不可用/未预热时 verifyResult 返回 null → 不标注,行为与升级前一致
        if (out.exitCode === 0) {
          const badge = this.verifyBadge(await this.verifyResult(adapter, command, out.stdout, { warmOnly: true }))
          if (badge !== '') return { text: `${anon}${badge} ${text}` }
        }
        return { text: `${anon}${text}` }
      },
    })
  }

  // ── MCP Resources 知识暴露(dsh 0.2 seam;老宿主退化为 knowledge-get RPC) ──

  /**
   * 把知识卡注册为 MCP Resources:server='opencli',URI=opencli://sites/{site}/knowledge。
   * seam 缺失(0.1.x 宿主)/注册失败一律静默降级——插件主体与 knowledge-get RPC 不受影响。
   * 数据层是纯函数 handleMcpResourceRequest(src/knowledge.ts),此处只注入目录缓存。
   */
  private registerKnowledgeResources(): void {
    let runtime: McpResourcesSeam | undefined
    try {
      runtime = (this.ctx as unknown as { reflect?: { get?: (p: string, f?: boolean) => unknown } }).reflect?.get?.('mcpResources', false) as McpResourcesSeam | undefined
    } catch { runtime = undefined }
    if (runtime === undefined || typeof runtime.register !== 'function') return
    try {
      const dispose = runtime.register('opencli', {
        request: async (req) => {
          const list = await this.adapterList()
          if (list === null) throw new Error(`opencli 目录不可用 | ${this.lastShellError ?? '未知'}`)
          const raw = (this.adapterCache as { json?: unknown } | null)?.json
          return handleMcpResourceRequest(req as Parameters<typeof handleMcpResourceRequest>[0], Array.isArray(raw) ? raw as RawEntry[] : undefined)
        },
      })
      // 注册进 runtime 的全局层,但生命周期挂回本插件:卸载时同步摘除,不留僵尸 server
      ;(this.ctx as unknown as { effect?: (f: () => unknown) => unknown }).effect?.(() => dispose)
    } catch { /* seam 在但注册异常(如重名):不阻断插件加载 */ }
  }

  // ── systemPrompt:适配器目录(缓存 + TTL,组装时取最新) ─────

  private directoryText = '浏览器代理(dsh-opencli):适配器目录加载中。'

  private async injectSystemPrompt(): Promise<void> {
    this.ctx.systemPrompt.section({
      name: 'opencli-proxy',
      order: 150,
      text: () => this.directoryText,
    })
    void this.updateDirectory()
  }

  private async updateDirectory(): Promise<void> {
    const list = await this.adapterList()
    if (list === null) {
      this.directoryText = '浏览器代理(dsh-opencli):未检测到可用的 opencli(opencli_*/site 工具会失败)。请用户在设置→浏览器代理 运行诊断,或安装 OpenCLI(OpenCLIApp / npm i -g @jackwener/opencli)。'
      return
    }
    const active = list.filter((a) => !this.state.disabled.includes(a.name))
    const daemon = await this.daemonStatus()
    const state = daemon !== null && daemon.running
      ? `daemon 运行中(扩展 ${daemon.extension ?? '?'})`
      : 'daemon 未运行——opencli_* 需要它:可在 dsh 设置→浏览器代理 一键启动,或 opencli daemon restart'
    const gate = this.state.approval === 'on' ? 'site 的 write 命令会先请求用户审批。' : '审批门已关闭(write 命令直接执行)。'
    // 无扩展的诚实可用面:目录是模型可见的动态能力声明——工具 description 是一次性
    // 注册的静态文案改不了,动态能力只能走目录文本与错误文案两个通道。判据与 doctor 同源
    // (daemon 未运行/扩展非正向连接都算无扩展),与 ④⑤ 短路的"显式未连"刻意不同档(那是动作门,这是声明)
    const extLine = (daemon?.extension ?? '').trim()
    const extOk = daemon !== null && daemon.running === true && (/^connected/.test(extLine) || /profiles connected/.test(extLine))
    const zeroCfg = extOk ? '' : `\n当前无扩展:site 的纯 HTTP 只读命令(如 juejin hot / hackernews best)可直接跑;需浏览器的只读命令暂不可降级执行(CDP 匿名通道默认关闭,评估中);opencli_*/chrome_* 与登录态(COOKIE)命令不可用。装扩展后全部恢复:https://github.com/jackwener/OpenCLI/releases`
    this.directoryText = `浏览器代理(dsh-opencli):你在 Chrome 里登录的网站,dsh 都能用。170+ 站点适配器(知乎/B站/微博/arxiv/github/...),用 site <适配器> <命令>。

按用户原话选:
- "知乎热榜前10" / "B站搜热榜" / "微博热搜"   → site zhihu hot / site bilibili search
- "打开这个网页"     → opencli_open url → opencli_state(拿 [N] 索引)
- "GitHub 找 X" / "arxiv 找 agent"  → site github search X / site arxiv search agent
- "在微博发..."     → site weibo post...(写命令会弹审批,用户点允许才发)
- "录一段:抓 arxiv 每天 AI 论文"   → 引导用户点"开始录" → 真实 Chrome 操作

辅助工具(都在本插件,直接调):
- site_knowledge <站> → 动手前读知识卡(命令目录+已知坑+失败签名恢复表),别现场试错
- so_verify(页面文本+预期) / so_pick(目标+选项集) → 亚秒判定,不耗大模型 token;低置信再自己判断
- site_batch → 多站同命令并行采集,自带同域冲突串行化(preflight)与"疑似静默失败"标注
- 定时任务建在面板"自动化"页,可加 watch 关键词(命中即🔔通知);撞风控墙自动 2 分钟退避

不要:写命令不在用户登录态时跑(先 opencli <site> login);cookie/密码不放工具参数。${state}。${gate}${zeroCfg}\n${buildAdapterDirectory(active)}`
  }

  // ── RPC(面板) ────────────────────────────────────────────

  @Remote('status')
  async status(): Promise<OpencliStatus & { conflicts?: string[] }> {
    const version = await this.runOpencli(['--version'])
    if (version.exitCode !== 0) {
      return {
        ok: false, bin: null, version: null, daemon: null, adapterSites: null,
        error: this.cliUnavailableText(version.stderr.slice(0, 300) || version.stdout.slice(0, 300)),
        ...(this.toolConflicts.length > 0 ? { conflicts: [...this.toolConflicts] } : {}),
      }
    }
    const daemon = await this.daemonStatus()
    // 目录(8MB)不阻塞健康区:有缓存给缓存,无缓存后台异步预热(adapters RPC 负责完整加载)
    const cached = this.adapterCache !== null && Date.now() - this.adapterCache.at < ADAPTER_TTL_MS ? normalizeAdapterList(this.adapterCache.json) : null
    void this.adapterList().catch(() => {})
    const list = cached
    // opencli 某些版本把 --version 写到 stderr:两流合并取首个非空行
    let vraw = (version.stdout.trim() || version.stderr.trim()).split('\n')[0]?.trim() ?? ''
        return {
      ok: true,
      bin: this.bin,
      version: vraw || null,
      daemon: daemon ?? null,
      adapterSites: list?.length ?? null,
      // 重名让位名单:面板/agent 据此知道这些命令不归本插件(空省略,不占字段)
      ...(this.toolConflicts.length > 0 ? { conflicts: [...this.toolConflicts] } : {}),
    }
  }

  @Remote('adapters')
  async adapters(): Promise<AdaptersResult> {
    const list = await this.adapterList()
    if (list === null) return { ok: false, total: 0, adapters: [], error: `opencli list 不可用 | ${this.lastShellError ?? '未知'}` }
    const marked = list.map((a) => ({ ...a, disabled: this.state.disabled.includes(a.name) }))
    return { ok: true, total: marked.length, adapters: marked }
  }

  @Remote('refresh')
  async refresh(): Promise<AdaptersResult> {
    this.adapterCache = null
    const result = await this.adapters()
    void this.updateDirectory()
    return result
  }

  /** daemon 未运行时由面板一键拉起;已在运行则不动作(避免干扰在用的桥接)。 */
  @Remote('daemon-start')
  async daemonStart(): Promise<DaemonStartResult> {
    const before = await this.daemonStatus()
    if (before?.running === true) return { ok: true, started: false, message: 'daemon 已在运行' }
    const r = await this.runOpencli(['daemon', 'restart'], 30000)
    const after = await this.daemonStatus()
    if (r.exitCode !== 0 && after?.running !== true) {
      return { ok: false, started: false, message: `启动失败(退出码 ${r.exitCode}):${clip(r.stderr || r.stdout, 300)}` }
    }
    return { ok: true, started: true, message: null }
  }

  @Remote('settings')
  async settings(): Promise<SettingsResult> {
    return { ok: true, approvalOn: this.state.approval === 'on', disabled: [...this.state.disabled], sha256: this.buildSha256(), audit7d: this.auditCount7d() }
  }

  /** 当前构建的 sha256 前 16 位(供应链自证;读取失败给 null,绝不编造)。 */
  private buildSha256(): string | null {
    if (this.sha256Cache !== null) return this.sha256Cache
    try {
      const self = fileURLToPath(import.meta.url)
      this.sha256Cache = createHash('sha256').update(readFileSync(self)).digest('hex').slice(0, 16)
    } catch { this.sha256Cache = null }
    return this.sha256Cache
  }

  private auditCount7d(): number {
    const cut = Date.now() - 7 * 86_400_000
    return (Array.isArray(this.state.audit) ? this.state.audit : []).filter((a) => new Date(a.at).getTime() >= cut).length
  }

  private recordAudit(command: string, reason: string): void {
    // state 可能被测试/旧文件整体替换成无 audit 的净对象:这里自愈,别让审计挂掉审批
    if (!Array.isArray(this.state.audit)) this.state.audit = []
    this.state.audit.unshift({ at: new Date().toISOString(), command, reason, mode: this.automationMode })
    if (this.state.audit.length > 50) this.state.audit.length = 50
    void this.saveState()
  }

  /**
   * 执行结果真实性判定:exit 0 ≠ 拿到有效数据——上游静默失败类 issue
   * (#2497 EMPTY_RESULT/#2469 600B 壳/#2520 假成功)的插件侧防线。site_batch/try-run/定时三处共用。
   * 两层:①确定性规则(opencli 失败词汇表/错误 JSON/空输出)——实测 laya 对这类文本判别力不足(P≈0.9),规则是主力;
   * ②laya noul 兜底判未知形态,只做标注。返回:null=不可用(调用方走原行为);verdict=false 即拦截级失败;
   * noul 0.35-0.7 可疑(verdict=true 但 p<0.7)。判别力阈值来自 2026-09 对宿主内嵌模型真实样本的实测。
   */
  private async verifyResult(site: string, command: string, text: string, opts?: { warmOnly?: boolean }): Promise<{ verdict: boolean; p: number; why?: string } | null> {
    const trimmed = text.trim()
    if (trimmed.length === 0) return { verdict: false, p: 0, why: '空输出' }
    // 裸 '[]'=#2708 canonical 空形态:合法成功不再判死重试(重试无意义),真空/登录后空壳由 receipt.empty 标注
    if (trimmed === '[]') return { verdict: true, p: 1, why: '空数组' }
    // 规则层:opencli 已知失败词汇 + 风控/登录墙关键词(实测覆盖 #2497/#2515/#2528/#2470 类)
    const head = trimmed.slice(0, 2000)
    const RULES: Array<[RegExp, string]> = [
      [/EMPTY_RESULT|NO_DATA|AUTH_REQUIRED|NOT_LOGGED_IN|RATE_LIMITED|NAVIGATION_REJECTED|COMMAND_EXEC/i, 'opencli 失败标记'],
      [/请先登录|未登录|登录已过期|请完成验证|验证码|人机验证|扫码登录/, '登录/风控墙'],
      [/login (first|required)|please (log ?in|sign ?in)|access denied|verifying your browser|just a moment|challenge|captcha/i, '登录/风控墙'],
    ]
    for (const [re, why] of RULES) {
      if (re.test(head)) return { verdict: false, p: 0.05, why }
    }
    try {
      const j = JSON.parse(head) as unknown
      if (j !== null && typeof j === 'object' && 'error' in (j as Record<string, unknown>)) return { verdict: false, p: 0.05, why: '错误 JSON' }
    } catch { /* 非 JSON:继续 */ }
    // warmOnly(热路径标注用):laya 未预热完时跳过 noul 兜底——绝不把 ~60s 权重冷加载/下载
    // 挂进 site 调用;规则层已跑完(零成本),标注缺席=降级回原行为。桩 so 无 warm 字段视为就绪(向后兼容)
    if (opts?.warmOnly === true && (this.so as { warm?: boolean }).warm === false) return null
    // noul 兜底:只对规则放行的文本做模型判定
    if (!this.so.configured) return null
    const r = await this.so.ask(head, {
      valid: { type: 'noul', instructions: `site ${site} ${command} 的输出包含真实的网站数据内容` },
    })
    if (!r.ok) return null
    const v = r.answers.valid
    // 注意:两个 provider 都归一化为 {type,value,confidence}——读 value,不要读原始字段名 noul
    const p = typeof v?.value === 'number' ? v.value : null
    if (p === null) return null
    // 修复(核验A-1):noul 放弃阈值判失败(错误文本同样 0.9+),仅弱标注不拦截;拦截权归规则层
    return { verdict: true, p, ...(p < 0.7 ? { why: '模型弱标注:内容可疑(仅提示)' } : {}) }
  }

  /** 把判定结果翻译成人读的标注(无判定返回空串)。 */
  private verifyBadge(v: { verdict: boolean; p: number; why?: string } | null): string {
    if (v === null) return ''
    if (!v.verdict) return `(⚠ 疑似静默失败:${v.why ?? `P=${v.p.toFixed(2)}`})`
    if (v.p < 0.7) return `(⚠ 内容可疑:P=${v.p.toFixed(2)},建议复核)`
    return `(实测有效 P=${v.p.toFixed(2)})`
  }

  @Remote('approval-set')
  async approvalSet(request: ApprovalSetRequest): Promise<ApprovalSetResult> {
    if (request === undefined) request = {} as never
    this.state.approval = request.enabled ? 'on' : 'off'
    await this.saveState()
    return { ok: true, enabled: request.enabled }
  }

  @Remote('adapter-disable')
  async adapterDisable(request: AdapterDisableRequest): Promise<AdapterDisableResult> {
    const set = new Set(this.state.disabled)
    if (request.disabled) set.add(request.name)
    else set.delete(request.name)
    this.state.disabled = [...set]
    await this.saveState()
    void this.updateDirectory()
    return { ok: true, name: request.name, disabled: request.disabled }
  }

  /** 登录态巡检:对有 whoami 命令的站点并发探测(限流+10min 缓存)。 */
  @Remote('login-check')
  async loginCheck(): Promise<LoginCheckResult> {
    const empty: LoginCheckResult = { ok: false, checkedAt: null, results: [] }
    if (this.loginCache !== null && Date.now() - this.loginCache.at < LOGIN_CHECK_TTL_MS) {
      return this.loginCache.results
    }
    if (this.adapterCache === null) {
      const list = await this.adapterList()
      if (list === null) return { ...empty, error: this.lastShellError ?? 'opencli list 不可用' }
    }
    const sites = sitesWithWhoami(this.adapterCache?.json)
    if (sites.length === 0) return { ...empty, error: '没有带 whoami 命令的适配器' }
    const results = await this.runPool(sites, LOGIN_CHECK_CONCURRENCY, async (site): Promise<LoginCheckItem> => {
      try {
        const r = await this.runOpencli([site, 'whoami'], 45000, 65536)
        const text = `${r.stdout}\n${r.stderr}`.trim()
        const notLoggedIn = r.exitCode !== 0 || /^ok:\s*false/m.test(text) || /AUTH_REQUIRED|^logged_in:\s*false/m.test(text)
        const meaningful = text.split('\n').find((l) => /message:|screen_name|^user/.test(l)) ?? text.split('\n').find((l) => l.trim().length > 0) ?? ''
        return { site, ok: !notLoggedIn, timedOut: false, detail: clip(meaningful.trim(), 120) || null }
      } catch {
        return { site, ok: false, timedOut: true, detail: null }
      }
    })
    const value: LoginCheckResult = { ok: true, checkedAt: new Date().toISOString(), results }
    this.loginCache = { at: Date.now(), results: value }
    return value
  }

  /** 单个适配器的完整命令详情(从缓存的原始 list JSON 过滤,面板展开时按需拉取)。 */
  @Remote('adapter-detail')
  async adapterDetail(request: AdapterDetailRequest): Promise<AdapterDetailResult> {
    const empty: AdapterDetailResult = { ok: false, name: request.name, domain: null, commands: [] }
    if (this.adapterCache === null) {
      // 面板冷启动后第一次展开:先触发一次缓存装载
      const list = await this.adapterList()
      if (list === null) return { ...empty, error: this.lastShellError ?? 'opencli list 不可用' }
    }
    const raw = this.adapterCache?.json
    if (!Array.isArray(raw)) return { ...empty, error: '缓存无原始数据' }
    const commands = []
    let domain: string | null = null
    for (const e of raw as Array<Record<string, unknown>>) {
      if (e === null || typeof e !== 'object' || e.site !== request.name) continue
      if (domain === null && typeof e.domain === 'string' && e.domain !== 'null') domain = e.domain
      const args = Array.isArray(e.args) ? (e.args as unknown[]).length : 0
      commands.push({
        name: typeof e.name === 'string' ? e.name : String(e.command ?? ''),
        description: typeof e.description === 'string' ? e.description : '',
        access: typeof e.access === 'string' ? e.access : 'read',
        example: typeof e.example === 'string' ? e.example : undefined,
        argCount: args,
      })
    }
    if (commands.length === 0) return { ...empty, error: `未找到适配器:${request.name}` }
    commands.sort((a, b) => a.name.localeCompare(b.name))
    return { ok: true, name: request.name, domain, commands }
  }

  @Remote('schedule-add')
  async scheduleAdd(request: { site: string; cron: string; retry?: number; notify?: boolean; watch?: string; source?: string; notifyLevel?: string; quietHours?: string; jitter?: boolean; preflight?: boolean; keep?: number; backoffMs?: number; profile?: string }): Promise<{ ok: boolean; id?: string; error?: string }> {
    if (request === undefined) request = {} as never
    if (typeof request.site !== 'string' || request.site.trim().length === 0) return { ok: false, error: 'site 不能为空' }
    if (typeof request.cron !== 'string' || request.cron.trim().length === 0) return { ok: false, error: 'cron 不能为空' }
    const site = request.site.trim()
    const cron = request.cron.trim()
    // 修复(核验A-4):垃圾 cron 静默入库永不执行;五段+词法+字段范围校验
    const toks = cron.trim().split(/\s+/)
    if (toks.length !== 5 || !toks.every((t) => /^(\*|\d+|\*\/\d+|\d+(,\d+)*)$/.test(t))) return { ok: false, error: 'cron 非法:需 5 段(分 时 日 月 周),支持 * 数字 */步长 逗号列表' }
    const CRON_RANGES: Array<[number, number]> = [[0, 59], [0, 23], [1, 31], [1, 12], [0, 6]]
    for (let i = 0; i < 5; i++) {
      const t = toks[i]!
      if (t === '*') continue
      if (t.startsWith('*/')) {
        // `*/0` 拒收(0.1.2 发后审查 low 项):词法放行 → cronMatches step<=0 恒 false →
        // 创建 ok 但永不执行且无报错。步长必须是 ≥1 整数,门口拒收给可读错误
        const step = Number(t.slice(2))
        if (!Number.isInteger(step) || step < 1) return { ok: false, error: `cron 步长非法:第${i + 1}段 "${t}" — */0 或非正整数步长恒不触发,请用 ≥1 的步长(如 */5)` }
        continue
      }
      for (const p of t.split(',')) {
        const n = Number(p)
        if (n < CRON_RANGES[i][0] || n > CRON_RANGES[i][1]) return { ok: false, error: `cron 字段越界:第${i + 1}段 ${t} 不在 ${CRON_RANGES[i][0]}-${CRON_RANGES[i][1]}` }
      }
    }
    // watch:关键词监控(逗号/空格分隔,≤120 字符)。命中任一关键词 → ingest 事件 watch-hit。
    // v1 故意用确定性匹配(noul 模糊"值得关注的变化"留 v2):真机实测 laya 判别力不足,宁缺勿误报。
    const watch = typeof request.watch === 'string' && request.watch.trim().length > 0 ? request.watch.trim().slice(0, 120) : undefined
    // 静默时段(0.4.7 B2):'off'/空串=清除;合法 HH:MM-HH:MM=设置;非法串=报错(不静默吞)
    let quietHours: string | undefined
    let quietClear = false
    if (typeof request.quietHours === 'string') {
      const raw = request.quietHours.trim()
      if (raw === '' || raw === 'off') quietClear = true
      else {
        const q = parseQuietHours(raw)
        if (q === undefined) return { ok: false, error: 'quietHours 非法:需 HH:MM-HH:MM(如 23:00-07:00,支持跨夜);清除传 off' }
        quietHours = `${q.from}-${q.to}`
      }
    }
    // 回执/轨迹卫生·任务级默认字段:快照留存预算 keep(5-500 份)/重试退避 backoffMs(0-600000ms);
    // 非数字/越界直接报错(与 quietHours 同款:不静默吞,用户知道自己的值没生效)
    let keep: number | undefined
    if (request.keep !== undefined) {
      const k = Number(request.keep)
      if (!Number.isInteger(k) || k < 5 || k > 500) return { ok: false, error: 'keep 非法:快照留存份数需为 5-500 的整数(默认 50)' }
      keep = k
    }
    let backoffMs: number | undefined
    if (request.backoffMs !== undefined) {
      const b = Number(request.backoffMs)
      if (!Number.isFinite(b) || b < 0 || b > 600_000) return { ok: false, error: 'backoffMs 非法:重试退避需为 0-600000 毫秒(默认 15000)' }
      backoffMs = Math.round(b)
    }
    // 多账号隔离 profile:别名或 contextId(上游 browser-profiles.json 的 alias 键/daemon 上报的 contextId);
    // 只收 [\w.@-] 安全字符(经 env 透传,不经 shell,但仍拒收控制字符/空白)。'off'/空串=清除
    let profile: string | undefined
    let profileClear = false
    if (typeof request.profile === 'string') {
      const raw = request.profile.trim()
      if (raw === '' || raw === 'off') profileClear = true
      else if (!/^[\w.@-]{1,64}$/.test(raw)) return { ok: false, error: 'profile 非法:需为 1-64 位字母数字/._@- (opencli profile 别名或 contextId);清除传 off' }
      else profile = raw
    }
    // 幂等去重:governor 队列下 add/remove 可能乱序(重试/双击),同 site+cron 的
    // 已有任务直接复用,不再生成僵尸副本(审查复现过 3 条重复)
    const dup = this.schedules.find((s) => s.site === site && s.cron === cron)
    if (dup !== undefined) {
      if (watch !== undefined && dup.watch !== watch) { dup.watch = watch; await this.saveState() }
      // 补强⑤④:复用既有任务时也补来源/级别(否则 agent 建的任务二次调用永远丢来源标记)
      if (typeof request.source === 'string' && ['agent', 'chat', 'panel', 'ctl'].includes(request.source) && dup.source !== request.source) { dup.source = request.source; await this.saveState() }
      if ((request.notifyLevel === 'quiet' || request.notifyLevel === 'all') && dup.notifyLevel !== request.notifyLevel) { dup.notifyLevel = request.notifyLevel; await this.saveState() }
      if (quietClear && dup.quietHours !== undefined) { delete dup.quietHours; await this.saveState() }
      else if (quietHours !== undefined && dup.quietHours !== quietHours) { dup.quietHours = quietHours; await this.saveState() }
      if (typeof request.jitter === 'boolean' && dup.jitter !== request.jitter) { dup.jitter = request.jitter; await this.saveState() }
      if (typeof request.preflight === 'boolean' && dup.preflight !== request.preflight) { dup.preflight = request.preflight; await this.saveState() }
      if (keep !== undefined && dup.keep !== keep) { dup.keep = keep; await this.saveState() }
      if (backoffMs !== undefined && dup.backoffMs !== backoffMs) { dup.backoffMs = backoffMs; await this.saveState() }
      if (profileClear && dup.profile !== undefined) { delete dup.profile; await this.saveState() }
      else if (profile !== undefined && dup.profile !== profile) { dup.profile = profile; await this.saveState() }
      return { ok: true, id: dup.id }
    }
    const id = String(Date.now())
    const entry: typeof this.schedules[number] = { id, site, cron, createdAt: new Date().toISOString(), enabled: true }
    // 补强⑤④:来源标记(agent/chat/panel/ctl——面板任务行徽章,分不清谁建的问题)+ 通知级别(quiet=只推变化与失败)
    if (typeof request.source === 'string' && ['agent', 'chat', 'panel', 'ctl'].includes(request.source)) entry.source = request.source
    if (request.notifyLevel === 'quiet' || request.notifyLevel === 'all') entry.notifyLevel = request.notifyLevel
    if (typeof request.retry === 'number' && Number.isFinite(request.retry)) entry.retry = Math.max(1, Math.min(5, Math.round(request.retry)))
    if (typeof request.notify === 'boolean') entry.notify = request.notify
    if (watch !== undefined) entry.watch = watch
    if (quietHours !== undefined) entry.quietHours = quietHours
    if (typeof request.jitter === 'boolean') entry.jitter = request.jitter
    if (typeof request.preflight === 'boolean') entry.preflight = request.preflight
    if (keep !== undefined) entry.keep = keep
    if (backoffMs !== undefined) entry.backoffMs = backoffMs
    if (profile !== undefined) entry.profile = profile
    this.schedules.push(entry)
    await this.saveState()
    this.startScheduler()
    return { ok: true, id }
  }

  @Remote('schedule-list')
  async scheduleList(): Promise<{ ok: boolean; schedules: Array<typeof this.schedules[number] & { history?: Array<{ at: string; ok: boolean; summary: string }> }> }> {
    return {
      ok: true,
      schedules: this.schedules.map((s) => { const { pendingNotify: _pn, ...rest } = s; return { ...rest, history: (this.runHistory[s.id] ?? []).slice(0, 3) } }),
    }
  }


  @Remote('ingest-events')
  async ingestEvents(): Promise<{ ok: boolean; events: IngestEvent[] }> {
    return { ok: true, events: this.ingestEventList.slice(0, 30) }
  }

  /**
   * 面板通知事件单一入口(事件历史持久化):内存态 unshift+截 30(ingest-events 契约不变,
   * newest-first 由测试锁定),同时整行 JSONL 追加落盘 ~/.dsh/opencli-events.jsonl——
   * watch 命中/漂移/翻转跨会话可回看(此前 30 条内存态重启即丢,#9544「定时静默失效」
   * 的插件层反面证据面)。落盘预算与 traces 同款:单文件超 5MB 轮转为 .1(旧 .1 丢弃);
   * 任何写失败静默——事件是旁路面,绝不反噬调用方(轨迹 recordTrace 同纪律)。
   */
  private pushIngestEvent(kind: string, text: string): void {
    // 事件文本常含任务命令行(可能带登录态链接 ?token=/?code=):内存与落盘同一份脱敏文本(落盘即洗)
    const safe = scrubUrlParams(text)
    this.ingestEventList.unshift({ at: new Date().toISOString(), kind, text: safe })
    this.ingestEventList = this.ingestEventList.slice(0, 30)
    this.appendEventsFile({ at: new Date().toISOString(), kind, text: safe })
  }

  /** dsh 面板通知通道的事件入口:与调度失败/watch 命中共用同一条 ingest 时间线(最近 30 条)。 */
  private emitNotifyEvent(ev: IngestEvent): void {
    this.ingestEventList.unshift(ev)
    this.ingestEventList = this.ingestEventList.slice(0, 30)
    // 通知通道回灌的事件(dsh 通道 emit)同样落历史文件——时间线一个事实,两个来源都进档
    this.appendEventsFile(ev)
  }

  /** 事件行落盘(同 at 生成两次无妨:append 行与内存行独立,读侧以文件行为准)。 */
  private appendEventsFile(row: IngestEvent): void {
    try {
      mkdirSync(dirname(this.eventsFile), { recursive: true })
      try {
        if (statSync(this.eventsFile).size > 5 * 1024 * 1024) {
          try { unlinkSync(`${this.eventsFile}.1`) } catch { /* 无旧档 */ }
          renameSync(this.eventsFile, `${this.eventsFile}.1`)
        }
      } catch { /* 文件不存在(首条)或轮转失败:照常追加 */ }
      appendFileSync(this.eventsFile, `${JSON.stringify(row)}\n`, 'utf8')
    } catch { /* 静默:历史缺失不阻断事件本身 */ }
  }

  /**
   * events-get RPC(evidence-get 同款读侧投影):读事件历史文件(+轮转档 .1),
   * 新→旧返回。脏行(半截 JSON/形状不对)跳过不抛;文件不存在=空表不是错误。
   * 与 ingest-events(内存 30 条)分工:本 RPC 是跨会话历史,面板「事件历史」卡数据源。
   */
  @Remote('events-get')
  async eventsGet(request?: { limit?: number }): Promise<EventsGetResult> {
    const limit = Math.max(1, Math.min(500, Math.floor(Number(request?.limit ?? 50)) || 50))
    const rows: IngestEvent[] = []
    for (const file of [`${this.eventsFile}.1`, this.eventsFile]) { // 旧档在前:读侧统一倒序输出
      let text = ''
      try { text = readFileSync(file, 'utf8') } catch { continue /* 无档/无权限:跳过 */ }
      for (const line of text.split('\n')) {
        if (line.trim().length === 0) continue
        try {
          const v = JSON.parse(line) as unknown
          if (v === null || typeof v !== 'object'
            || typeof (v as IngestEvent).at !== 'string' || typeof (v as IngestEvent).kind !== 'string'
            || typeof (v as IngestEvent).text !== 'string') continue
          rows.push(v as IngestEvent)
        } catch { /* 脏行跳过 */ }
      }
    }
    rows.reverse() // 文件是追加序(旧→新),历史面契约与 ingest-events 一致:最新在前
    return { ok: true, events: rows.slice(0, limit) }
  }

  @Remote('audit-list')
  async auditList(): Promise<AuditListResult> {
    return {
      ok: true,
      count7d: this.auditCount7d(),
      items: this.state.audit.slice(0, 20).map((a) => ({ at: a.at, command: a.command, reason: a.reason, mode: a.mode })),
    }
  }

  @Remote('logs-tail')
  async logsTail(): Promise<LogsTailResult> {
    const candidates = [join(homedir(), '.opencli', 'daemon.log'), join(homedir(), '.opencli', 'logs', 'daemon.log')]
    for (const c of candidates) {
      try {
        const text = await readFile(c, 'utf8')
        const lines = text.split('\n').filter((l) => l.trim().length > 0)
        return { ok: true, source: c, lines: lines.slice(-80) }
      } catch { /* 试下一个候选 */ }
    }
    const diag: string[] = []
    if (this.lastShellError !== null && this.lastShellError !== '') diag.push(`lastShellError: ${this.lastShellError}`)
    diag.push(`bin: ${this.bin}`)
    diag.push(`mode: ${this.automationMode} · approval: ${this.state.approval} · schedules: ${this.schedules.length}`)
    return { ok: true, source: null, lines: diag, hint: 'opencli 未暴露日志文件;以上为最近诊断快照,可在 dsh 对话说"opencli 诊断"获取实时日志' }
  }

  /** 最近 browser 命令轨迹(倒序=最新在前,默认 50):跨当日与昨日等历史文件聚合,面板「运行轨迹」/trace_replay 共用。 */
  @Remote('trace-list')
  async traceList(request?: { limit?: number }): Promise<TraceListResult> {
    // 网关对空 args 会传 undefined(真机复现,knowledge-get 同款):request 可选链 + 上限钳制
    const limit = Math.max(1, Math.min(500, Math.floor(Number(request?.limit ?? 50)) || 50))
    let traces: ShotTraceLine[] = []
    try {
      // 文件按日期倒序、同日主档在 .1(轮转旧档)之前——逐档前插保持全局时间序,攒够 limit 即止
      const files = readdirSync(this.traceDir)
        .map((f) => /^trace-(\d{8})\.jsonl(\.1)?$/.exec(f))
        .filter((m): m is RegExpExecArray => m !== null)
        .sort((a, b) => b[1].localeCompare(a[1]) || (a[2] !== undefined ? 1 : 0) - (b[2] !== undefined ? 1 : 0))
      for (const m of files) {
        traces = this.readTraceFile(join(this.traceDir, m[0])).concat(traces)
        if (traces.length >= limit) break
      }
    } catch { /* 目录不存在(还没跑过 browser 命令):空表 */ }
    return { ok: true, traces: traces.slice(-limit).reverse() }
  }

  /** 某日全量轨迹(date=yyyymmdd;当日轮转档 .1 在主档之前,保持时间序)。 */
  @Remote('trace-get')
  async traceGet(request: { date: string }): Promise<TraceListResult> {
    const date = String(request?.date ?? '').trim()
    // date 直接拼文件名:严格 8 位数字,杜绝路径穿越
    if (!/^\d{8}$/.test(date)) return { ok: false, traces: [], error: `date 需为 yyyymmdd(收到:${date.slice(0, 20)})` }
    const traces: ShotTraceLine[] = [
      ...this.readTraceFile(this.traceFileOf(date, true)),
      ...this.readTraceFile(this.traceFileOf(date, false)),
    ]
    if (traces.length === 0) return { ok: false, traces: [], error: `该日(${date})无轨迹` }
    return { ok: true, traces }
  }

  /**
   * 轨迹步骤截图直取(面板时间线缩略图):{path} 经 resolve 归一后必须位于 shotsDir 之下,
   * 杜绝 ../ 回溯与绝对路径穿越(traceGet 对日期键做严格白名单是同一思路);
   * 文件不存在/超大/读失败一律 ok:false,绝不抛错拖垮面板。
   */
  @Remote('trace-shot')
  async traceShot(request?: { path: string }): Promise<{ ok: boolean; data?: string; mime?: string; error?: string }> {
    // 网关对空 args 会传 undefined(真机复现,trace-list 同款):request 可选链兜底
    const raw = String(request?.path ?? '')
    if (raw.trim().length === 0) return { ok: false, error: 'path 为空' }
    // win32 盘符大小写不稳定,比较前归一;root+sep 前缀防 "opencli-shots-evil" 同前缀目录假命中
    const norm = (s: string): string => (process.platform === 'win32' ? s.toLowerCase() : s)
    const root = resolve(this.shotsDir)
    const p = resolve(raw)
    if (norm(p) !== norm(root) && !norm(p).startsWith(norm(root) + sep)) {
      return { ok: false, error: `path 必须位于截图目录(${root})之下` }
    }
    try {
      const st = statSync(p)
      if (!st.isFile()) return { ok: false, error: '不是常规文件' }
      // base64 会膨胀 4/3:无上限的整页 PNG 直接炸 RPC 通道,超 8MB 宁可不放缩略图
      if (st.size > 8 * 1024 * 1024) return { ok: false, error: `截图过大(${st.size} 字节,上限 8MB)` }
      const buf = await readFile(p)
      return { ok: true, data: buf.toString('base64'), mime: 'image/png' }
    } catch {
      return { ok: false, error: '文件不存在或不可读' }
    }
  }


  /** opencli launcher 启动 Chrome 时的 CDP 候选端口(launcher.js 同源)。 */
  private static readonly CDP_PORTS = [9222, 9234, 9236, 9238]
  private cdpCache: { at: number; found: boolean; port: number | null; browser: string | null } | null = null

  /** 扩展连接态缓存(≤15s,与 probeCdp 同量级;每命令路由读缓存,不逐条打 daemon status)。 */
  private extCache: { at: number; connected: boolean | null; explicitDown: boolean } | null = null

  /**
   * 扩展状态快照,两档判据刻意分开(信号复用 daemonStatus/parseDaemonStatus):
   * - connected(false=宽档"非正向连接"):daemon 未运行/字段缺失/显式未连都算——给 ②③ 的 site 路由用,
   *   降级是加路不是拆路,判宽些只影响"要不要尝试匿名通道",不会拦掉任何现状路径;
   * - explicitDown(仅显式未连):daemon 明确报告扩展未连(2.0 extensionConnected:false → 归一
   *   'not connected';1.x `Extension: not*`)——给 ④⑤ 的 opencli_* 与 chrome_* 短路用。
   *   只认显式否定:daemon 运行但不上报 Extension 字段的旧形态下 opencli_* 仍可能工作,
   *   缺字段≠否定,短路会把还能跑的路径一刀切死,不做。
   * null=探测失败(状态未知):一切按现状路径,不降级也不短路。
   */
  private async extensionState(): Promise<{ connected: boolean | null; explicitDown: boolean }> {
    if (this.extCache !== null && Date.now() - this.extCache.at < 15_000) {
      return { connected: this.extCache.connected, explicitDown: this.extCache.explicitDown }
    }
    let connected: boolean | null = null
    let explicitDown = false
    try {
      // 探测走 runOpencliUngoverned(而非 daemonStatus/runOpencli):本机 RPC 不吃 site 限流,
      // 也不经会被覆写的实例方法——两条理由见该方法的注释(零配置降级实测教训)
      const r = await this.runOpencliUngoverned(['daemon', 'status'], 15_000, 262_144)
      const ds = r.exitCode !== 0 ? null : parseDaemonStatus(r.stdout + '\n' + r.stderr)
      if (ds === null) {
        connected = null // daemon status 命令本身失败:分不清"未运行"还是"坏了",按未知处理
      } else if (ds.running !== true) {
        connected = false // daemon 明确未运行 = 必然无扩展;但对 ④⑤ 不短路(可能自行拉起/自愈)
      } else {
        const extLine = (ds.extension ?? '').trim()
        const up = /^connected/.test(extLine) || /profiles connected/.test(extLine)
        connected = up
        explicitDown = !up && (extLine === 'not connected' || /^not\b/i.test(extLine) || /disconnected/i.test(extLine))
      }
    } catch { connected = null; explicitDown = false }
    this.extCache = { at: Date.now(), connected, explicitDown }
    return { connected, explicitDown }
  }

  /**
   * 命令级 browser 字段探测:`<site> <cmd> --help -f json` 的 browser 布尔是区分
   * 通道A(纯 HTTP,零依赖直跑)与通道B(需浏览器)的唯一可靠判据(实测:juejin hot→false,36kr hot→true)。
   * 失败/无字段返回 null=未知,按保守侧"需要浏览器"处理(§3 判据级联的约定)。
   * 只在"确定无扩展 + read"的降级路径上才被调用,正常路径零成本;暂不做 TTL 缓存(后续优化项)。
   */
  private async commandNeedsBrowser(adapter: string, command: string): Promise<boolean | null> {
    const r = await this.runOpencli([adapter, command, '--help', '-f', 'json'], 15_000)
    if (r.exitCode !== 0) return null
    const j = extractJsonObject(r.stdout) as { browser?: unknown } | null
    return j !== null && typeof j.browser === 'boolean' ? j.browser : null
  }

  /**
   * 零配置降级路由(site 命令执行前的唯一降级决策点)。返回:
   * - null:现状路径(有扩展/状态未知/写或未知权限/browser:false/1.x 宿主);
   * - inject:② 通道B——注入 OPENCLI_CDP_ENDPOINT + --site-session ephemeral(匿名会话);
   * - skip:④式诚实报不可用(browser:true + read + 无扩展 + 无 CDP 端点,注定失败不执行)。
   * 硬不变量:写/未知权限命令一律返回 null 永不降级——没有用户身份的写不是降级是伪造(§3 不变量1)。
   * 1.x 宿主维持①/④现状(§7-2:--site-session 是 2.0 语法)。
   */
  private async zeroCfgPlan(adapter: string, command: string): Promise<
    { mode: 'inject'; env: Record<string, string>; argvTail: string[] } | { mode: 'skip'; text: string } | null
  > {
    const ext = await this.extensionState()
    if (ext.connected !== false) return null // 有扩展或状态未知:现状路径,通道B 不介入(§5 无缝切回)
    const access = await this.lookupAccess(adapter, command)
    if (access !== 'read') return null // 判据级联第一级(零成本):写/未知永不降级
    const needsBrowser = await this.commandNeedsBrowser(adapter, command)
    if (needsBrowser === false) return null // ① 通道A纯 HTTP:直跑,现状零改动
    if ((await this.cliMajor()) < 2) return null // 1.x 宿主:维持现状
    const cdp = await this.probeCdp()
    // 通道B(CDP attach)默认关死(立项评审致命发现):上游 CDPBridge 是 attach 端点浏览器
    // 已存在的真实标签页(无隐身上下文/独立 profile),而候选口 9222 族恰是用户自开调试
    // Chrome 的惯用口——attach 上去执行会带着用户登录态,与「匿名降级」标注构成信任断裂。
    // 长期方案是 headless 自管 Chrome(唯一正当端点来源);在那之前只留显式实验开关。
    if (process.env.OPENCLI_ZEROCDP_CDP === '1' && cdp.found && cdp.port !== null) {
      return { mode: 'inject', env: { OPENCLI_CDP_ENDPOINT: `http://127.0.0.1:${cdp.port}` }, argvTail: [...CDP_ARGV_TAIL] }
    }
    return {
      mode: 'skip',
      text: `site ${adapter} ${command} 需要浏览器会话,当前无扩展${cdp.found ? '且 CDP 匿名通道默认关闭(评估中)' : '且未探测到本机 CDP 端点'},无法降级执行。两条路:` +
        `①装扩展(恢复全部能力):https://github.com/jackwener/OpenCLI/releases 下载 opencli-extension-*.zip 解压 → Chrome/Edge 扩展页开"开发者模式"→"加载解压缩的扩展";` +
        `②先用纯 HTTP 只读命令(如 site juejin hot,无需浏览器不受影响)。`,
    }
  }

  /** 探测 daemon Chrome 的 CDP 端点:并发 probe /json/version,响应含 "Browser" 即命中。 */
  private async probeCdp(): Promise<{ found: boolean; port: number | null; browser: string | null }> {
    if (this.cdpCache !== null && Date.now() - this.cdpCache.at < 15_000) {
      return { found: this.cdpCache.found, port: this.cdpCache.port, browser: this.cdpCache.browser }
    }
    const envPort = Number(process.env.OPENCLI_CDP_PORT ?? 0)
    const ports = (envPort > 0 ? [envPort, ...OpencliService.CDP_PORTS] : OpencliService.CDP_PORTS).slice(0, 6)
    const probeOne = async (port: number): Promise<{ port: number; browser: string } | null> => {
      try {
        const res = await fetch(`http://127.0.0.1:${port}/json/version`, { signal: AbortSignal.timeout(1200) })
        if (!res.ok) return null
        const body = (await res.text()).trim()
        if (body.includes('Browser')) return { port, browser: body.slice(0, 200) }
        return null
      } catch { return null }
    }
    const hit = (await Promise.all(ports.map(probeOne))).find((x) => x !== null) ?? null
    this.cdpCache = { at: Date.now(), found: hit !== null, port: hit?.port ?? null, browser: hit?.browser ?? null }
    return { found: hit !== null, port: hit?.port ?? null, browser: hit?.browser ?? null }
  }

  @Remote('browser-cdp')
  async browserCdp(): Promise<{ ok: boolean; found: boolean; endpoint: string | null; port: number | null; browser: string | null; hint?: string }> {
    const c = await this.probeCdp()
    if (!c.found) {
      return { ok: true, found: false, endpoint: null, port: null, hint: '未探测到 CDP——先启动一次浏览器会话(daemon 首条 browser 命令会带调试端口拉起 Chrome)' }
    }
    return { ok: true, found: true, endpoint: `http://127.0.0.1:${c.port}`, port: c.port, browser: c.browser }
  }

  @Remote('schedule-run-now')
  async scheduleRunNow(p: { id: string }): Promise<{ ok: boolean; error?: string }> {
    const sch = this.schedules.find((s) => s.id === String(p.id ?? ''))
    if (sch === undefined) return { ok: false, error: '未找到' }
    void this.runSiteCommand(sch.site, sch.id, { manual: true })
    return { ok: true }
  }

  /**
   * 快照目录安全解析(traceShot 同款标准,id 面板/收件箱入口可携任意串):resolve+root 前缀
   * 校验,`../` 穿越与绝对路径逃逸、同前缀目录假命中一并挡下。返回 null=越界,调用方按
   * "无快照"处理。win32 盘符大小写不稳定,比较前归一(与 traceShot 同源)。
   */
  private snapshotDirOf(id: string): string | null {
    if (id.length === 0) return null // 空 id 不得落到快照根(会整目录列举)
    const norm = (s: string): string => (process.platform === 'win32' ? s.toLowerCase() : s)
    const root = resolve(this.snapshotsBase)
    const p = resolve(this.snapshotsBase, id)
    if (norm(p) === norm(root)) return null // '.'/'./' 同样落到根,与空 id 同防(整目录列举)
    if (!norm(p).startsWith(norm(root) + sep)) return null
    return p
  }

  @Remote('schedule-history')
  async scheduleHistory(p: { id: string } | undefined): Promise<{ ok: boolean; history: Array<{ at: string; ok: boolean; summary: string }>; snapshots?: Array<{ at: string; bytes: number; file: string }> }> {
    // 时间线数据源:运行史(内存,近 5) + 快照索引(落盘,近 50,含体积用于趋势)
    const id = String((p ?? { id: ''}).id ?? '')
    let snapshots: Array<{ at: string; bytes: number; file: string }> | undefined
    try {
      const dir = this.snapshotDirOf(id)
      if (dir === null) throw new Error('id 越界')
      snapshots = readdirSync(dir).slice(-50).map((f) => {
        // 文件名=ISO 全 [:.] 换 '-':2026-10-05T15-36-53-123.json → 还原时日期分隔符不能再全量替换(修复 2026:10:05 错乱)
        const stem = f.slice(0, f.length - 5)
        const at = stem.length >= 19 ? `${stem.slice(0, 10)}T${stem.slice(11, 13)}:${stem.slice(14, 16)}:${stem.slice(17, 19)}` : stem
        let bytes = 0
        try { bytes = JSON.parse(readFileSync(join(dir, f), 'utf8')).bytes ?? 0 } catch { /* ignore */ }
        return { at, bytes, file: f }
      })
    } catch { /* 无快照目录 */ }
    return { ok: true, history: this.runHistory[id] ?? [], ...(snapshots !== undefined ? { snapshots } : {}) }
  }

  /**
   * 变化时间线(0.4.6 补强③):逐相邻快照对 diff,按天聚合。
   * 数据源=快照目录(diff 已在调度链入推送;这里给面板补"历史上都变了什么"的视图)。
   * 上限:逐份读 stdout 有 IO 成本,只看最近 21 份(约一周的日频任务)。
   */
  @Remote('snap-diff-history')
  async snapDiffHistory(p: { id: string } | undefined): Promise<{ ok: boolean; days?: Array<{ day: string; added: number; removed: number; moved: number; summary: string }>; week?: Array<{ day: string; added: number; removed: number; moved: number }>; error?: string }> {
    const id = String((p ?? { id: '' }).id ?? '')
    if (id.length === 0) return { ok: false, error: 'id 为空' }
    try {
      const dir = this.snapshotDirOf(id)
      if (dir === null) return { ok: true, days: [] }
      let files: string[] = []
      try { files = readdirSync(dir).filter((f) => f.endsWith('.json')).sort().slice(-21) } catch { return { ok: true, days: [] } } // 目录不存在=零采集任务,空时间线而非 ENOENT
      if (files.length < 2) return { ok: true, days: [] }
      const days: Array<{ day: string; added: number; removed: number; moved: number; summary: string }> = []
      for (let i = 1; i < files.length; i++) {
        try {
          const prev = JSON.parse(readFileSync(join(dir, files[i - 1]!), 'utf8')) as { at?: string; stdout?: string }
          const cur = JSON.parse(readFileSync(join(dir, files[i]!), 'utf8')) as { at?: string; stdout?: string }
          const d = diffSnapshots(String(prev.stdout ?? ''), String(cur.stdout ?? ''))
          const at = cur.at ?? files[i]!.slice(0, -5)
          days.push({
            day: at.slice(0, 10) + ' ' + at.slice(11, 16),
            added: d.added, removed: d.removed, moved: d.moved,
            summary: renderDiffText(d).slice(0, 160),
          })
        } catch { /* 单份损坏跳过 */ }
      }
      const rev = days.reverse() // 新→旧
      // 七天聚合(B1):按日历日求和,近 7 天每日一行(新增/消失/位移)——盯一周看趋势
      return { ok: true, days: rev, week: aggregateDaySums(rev) }
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : String(e) }
    }
  }

  /** ⑦CSV 导出(0.4.6 补强):任务快照 → 单表 CSV/原文分节(exportcsv 同门解析纪律)。 */
  @Remote('snap-export')
  async snapExport(p: { id: string } | undefined): Promise<{ ok: boolean; text?: string; rows?: number; count?: number; error?: string }> {
    const id = String((p ?? { id: '' }).id ?? '')
    if (id.length === 0) return { ok: false, error: 'id 为空' }
    try {
      const dir = this.snapshotDirOf(id)
      if (dir === null) return { ok: false, error: 'id 越界' }
      const files = readdirSync(dir).filter((f) => f.endsWith('.json')).sort().slice(-50)
      if (files.length === 0) return { ok: false, error: '该任务暂无快照' }
      const snapshots = files.map((f) => {
        try {
          const j = JSON.parse(readFileSync(join(dir, f), 'utf8')) as { at?: string; site?: string; stdout?: string }
          return { at: String(j.at ?? f), site: String(j.site ?? ''), stdout: String(j.stdout ?? '') }
        } catch { return { at: f, site: '', stdout: '' } }
      })
      const r = exportSnapshots({ snapshots })
      return { ok: true, text: r.text, rows: r.rows, count: r.snapshots }
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : String(e) }
    }
  }

  /**
   * 通知通道配置读写(面板「自动化」页后续接):不带 channels=读当前配置;
   * 带 channels=白名单归一后写盘。归一用 notify.ts 口径(未知 type/非字符串字段整条
   * 丢弃),但 channels 本身不是数组直接拒绝而不是清空——手滑的 POST 不许把用户已配好
   * 的通道抹掉。写盘走 saveNotifyConfig(失败往外抛,与 saveState 尽力而为不同口径:
   * 配置是用户显式动作,存不上必须让面板知道),同时回填 this.state——否则下一次
   * saveState 整文件重写会丢掉 notifyConfig 键(见 PluginState.notifyConfig 注释)。
   */
  /**
   * 插件自检('装上没效果'问题的解药——同一症状在 dsh #9308/#9261、插件市场 #2582、
   * BrowserSkill #554 多处反馈):激活/工具注册点名/入口在线/宿主匹配——面板安全 tab 顶部自检卡 3 秒可见。
   * update 段(#10869 '有新版本无路可走'):npm registry dist-tag 对比当前版本,
   * 有新版给出一键复制升级命令(不自动执行——升级是用户显式决策,#6971 教训)。
   */
  @Remote('self-check')
  async selfCheck(): Promise<{
    ok: boolean
    activated: boolean
    tools: Array<{ name: string; registered: boolean }>
    conflicts: string[]
    entries: Array<{ name: string; ok: boolean }>
    currentVersion: string
    latestVersion?: string
    updateAvailable?: boolean
    upgradeCmd?: string
    error?: string
  }> {
    const currentVersion = PLUGIN_VERSION
    const out: {
      ok: boolean; activated: boolean
      tools: Array<{ name: string; registered: boolean }>; conflicts: string[]
      entries: Array<{ name: string; ok: boolean }>
      currentVersion: string; latestVersion?: string; updateAvailable?: boolean; upgradeCmd?: string
      error?: string
    } = {
      ok: true, activated: true,
      tools: [], conflicts: [...this.toolConflicts], entries: [],
      currentVersion,
    }
    // 工具点名:期望取注册期预期清单(正主名,不含弃用别名)逐个核对 registeredToolNames——
    // 撞名让位的名字 registered:false 且仍计入 conflicts,点名对失败形态有真鉴别力
    const expected = [...new Set(this.expectedToolNames.filter((n) => !n.startsWith('browser_')))]
    for (const name of expected) {
      const registered = this.registeredToolNames.includes(name)
      out.tools.push({ name, registered })
    }
    // 入口在线:面板 RPC(本调用即证明)+ ctl 收件箱目录 + daemon
    try {
      out.entries.push({ name: 'panel-rpc', ok: true })
      out.entries.push({ name: 'ctl-inbox', ok: existsSync(inboxDir()) })
      const ds = await this.daemonStatus()
      out.entries.push({ name: 'daemon', ok: ds !== null && ds.running === true })
    } catch (e) {
      out.entries.push({ name: 'daemon', ok: false })
    }
    // npm 更新检查(best-effort,5s 超时;失败静默——离线不是自检失败)
    try {
      const res = await fetch('https://registry.npmjs.org/@cold777%2Fdsh-opencli/latest', { signal: AbortSignal.timeout(5000) })
      if (res.ok) {
        const j = await res.json() as { version?: string }
        const latest = typeof j.version === 'string' ? j.version : undefined
        if (latest !== undefined && latest !== currentVersion) {
          out.latestVersion = latest
          out.updateAvailable = true
          out.upgradeCmd = `npm install -g @cold777/dsh-opencli@${latest}`
        }
      }
    } catch { /* 离线:更新检查跳过 */ }
    return out
  }

  @Remote('notify-config')
  async notifyConfig(request?: { channels?: unknown }): Promise<{ ok: boolean; config?: NotifyConfig; error?: string }> {
    // 网关对空 args 会传 undefined(真机复现,schedule-history 同款):request 可选链
    if (request === undefined || request.channels === undefined) {
      return { ok: true, config: this.state.notifyConfig ?? { channels: [] } }
    }
    if (!Array.isArray(request.channels)) return { ok: false, error: 'channels 需为数组(通道条目列表)' }
    const config = normalizeNotifyConfig(request)
    this.state.notifyConfig = config
    // 评审 MEDIUM:此前 saveNotifyConfig 独立读-改-写 state.json,与 saveState 的全量重写竞态。
    // 改为:先回填 this.state(上面的赋值),再走 saveState()统一写——单一写者,零竞态
    await this.saveState()
    return { ok: true, config }
  }

  /** 报告导出:定时任务的近期快照 → 带出处 markdown(每节=一次运行,出处=命令+时间+快照路径)。summary=true 出摘要版(≤500 字)。 */
  @Remote('report-build')
  async reportBuild(request?: { id: string; summary?: boolean }): Promise<{ ok: boolean; path?: string; error?: string }> {
    const id = String(request?.id ?? '')
    if (id.length === 0) return { ok: false, error: 'id 为空' }
    const sch = this.schedules.find((s) => s.id === id)
    const dir = this.snapshotDirOf(id)
    if (dir === null) return { ok: false, error: 'id 越界' }
    let files: string[] = []
    try { files = readdirSync(dir).slice(-5) } catch { return { ok: false, error: '该任务暂无快照——先运行一次采集' } }
    if (files.length === 0) return { ok: false, error: '该任务暂无快照' }
    const sources: ReportSource[] = []
    for (const f of files) {
      try {
        const j = JSON.parse(readFileSync(join(dir, f), 'utf8')) as { at?: string; site?: string; stdout?: string }
        const stem = f.slice(0, f.length - 5)
        const at = j.at ?? stem
        sources.push({
          site: String(j.site ?? sch?.site ?? id), command: String(j.site ?? sch?.site ?? ''),
          at, text: String(j.stdout ?? ''), status: 'ok', note: '快照原文',
          source: join(dir, f),
        })
      } catch { /* 单份损坏跳过 */ }
    }
    if (sources.length === 0) return { ok: false, error: '快照全部损坏' }
    // 出口统一脱敏:改动前落盘的旧快照未经清洗,报告出口兜底(与尾注声明一致)
    const md = scrubUrlParams(buildReport(`定时采集报告 · ${sch?.site ?? id}`, sources, new Date().toISOString(), { summary: request?.summary === true }))
    const rdir = process.env.DSH_OPENCLI_REPORTS_DIR ?? join(homedir(), '.dsh', 'opencli-reports')
    await mkdir(rdir, { recursive: true })
    const path = join(rdir, `sched-${id}-${Date.now()}.md`)
    await writeFile(path, md, 'utf8')
    return { ok: true, path }
  }

  /**
   * 一键冒烟基准:逐站串行 runOpencli(60s 超时)+ verifyResult 取 P,
   * 汇总写 ~/.dsh/opencli-benchmarks/bench-<时间戳>.md(目录自建,保留 20 份轮转)。
   * 串行 + 站间 800ms:基准数字要可比,并发会互相抢带宽、连发会撞限流,耗时与成败都失真。
   */
  @Remote('benchmark-run')
  async benchmarkRun(request?: { sites?: string[] }): Promise<{ ok: boolean; path?: string; results?: BenchItem[]; error?: string }> {
    // 网关对空 args 会传 undefined(真机复现,knowledge-get 同款):request 可选链
    const raw = request?.sites
    const lines = Array.isArray(raw) && raw.length > 0 ? raw.map((s) => String(s).trim()) : [...DEFAULT_BENCH]
    if (lines.length === 0) return { ok: false, error: 'sites 为空' }
    if (lines.length > 10) return { ok: false, error: `单次最多 10 站(收到 ${lines.length})——拉长整轮只会让先跑的站和后跑的站网络条件更不可比` }
    // 入参是"站点 命令"两段:先整体校验,垃圾行不混进报告。命令必须以词字符开头——
    // [\w-]+ 会放行 "-rf" 这类旗标形态,垃圾参数就该在门口挡下,不能等 CLI 报错
    for (const line of lines) {
      const toks = line.split(/\s+/)
      const [site, command] = toks
      if (toks.length !== 2 || site === undefined || site.length === 0 || command === undefined || !/^[\w@.-]+$/.test(site) || !/^\w[\w-]*$/.test(command)) {
        return { ok: false, error: `站点命令格式非法:"${line.slice(0, 40)}"(应为 "站点 命令" 两段,如 juejin hot)` }
      }
    }
    // 安全不变量:基准是只读冒烟——任何 write/unknown 命令在门口拒绝(fail-closed)。
    // 此前仅形状校验,`benchmark {sites:["zhihu comment"]}` 可绕过写审批门直执行(独立评审 HIGH)
    const offenders: string[] = []
    for (const line of lines) {
      const [s2, c2] = line.split(/\s+/) as [string, string]
      const acc = await this.lookupAccess(s2, c2)
      if (acc !== 'read') offenders.push(`${line}(${acc === 'write' ? '写命令' : '未知权限'})`)
    }
    if (offenders.length > 0) {
      return { ok: false, error: `基准只接受只读命令,以下行被拒:${offenders.join('、')}。写命令请走 site 工具(带审批门与证据包)。` }
    }
    const results: BenchItem[] = []
    for (let i = 0; i < lines.length; i++) {
      const [site, command] = lines[i].split(/\s+/) as [string, string]
      const started = Date.now()
      try {
        const out = await this.runOpencli([site, command], 60_000)
        if (out.exitCode !== 0) {
          results.push({ site, command: lines[i], ok: false, p: null, ms: Date.now() - started, error: clip(`${out.stderr}\n${out.stdout}`.trim() || `退出码 ${out.exitCode}`, 160) })
        } else {
          const v = await this.verifyResult(site, command, out.stdout)
          const silent = v !== null && !v.verdict
          results.push({
            site, command: lines[i], ok: !silent, p: v === null ? null : v.p, ms: Date.now() - started,
            ...(silent ? { error: clip(`静默失败:${v.why ?? ''}`, 160) } : {}),
          })
        }
      } catch (e) {
        // shell 三形态都归一为 exitCode 结果,这里只兜 governor 级意外;计时照记,失败也是基准数据
        results.push({ site, command: lines[i], ok: false, p: null, ms: Date.now() - started, error: clip(e instanceof Error ? e.message : String(e), 160) })
      }
      // 站间间隔(最后一站后不等):串行基准的限流礼貌
      if (i < lines.length - 1 && this.benchGapMs > 0) await new Promise((res) => setTimeout(res, this.benchGapMs))
    }
    // A4 传输对照:CLI 冷启动(opencli --version 全进程)vs daemon 直连探针往返——
    // 浏览器原语类命令直连收益的量级证据,随每份基准报告落盘(基准是数字的出处)
    let cliMs = -1
    let directMs: number | null = null
    try {
      const t0 = Date.now()
      await this.runOpencli(['--version'], 15_000)
      cliMs = Date.now() - t0
      if (directCapability() === 'ready' || (await directProbe())) {
        const t1 = Date.now()
        await directExec('dsh', '1')
        directMs = Date.now() - t1
      }
    } catch { /* 对照失败不挡基准主报告 */ }
    const md = buildBenchmarkReport(results, new Date().toISOString())
    const mdFinal = cliMs >= 0 ? md.replace('\n\n## ', `\n\n${renderTransportBenchmark({ cliMs, directMs })}## `) : md
    const dir = process.env.DSH_OPENCLI_BENCHMARKS_DIR ?? join(homedir(), '.dsh', 'opencli-benchmarks')
    try {
      await mkdir(dir, { recursive: true })
      const stamp = new Date().toISOString().replace(/[:.]/g, '-')
      const file = join(dir, `bench-${stamp}.md`)
      await writeFile(file, mdFinal, 'utf8')
      // 轮转:bench-<ISO> 字典序=时间序,超出保留数删最旧(与快照 50 份轮转同一思路)
      const olds = readdirSync(dir).filter((f) => /^bench-.+\.md$/.test(f)).sort()
      if (olds.length > BENCH_KEEP) for (const f of olds.slice(0, olds.length - BENCH_KEEP)) { try { unlinkSync(join(dir, f)) } catch { /* 并发已删 */ } }
      return { ok: true, path: file, results }
    } catch (e) {
      return { ok: false, results, error: `报告写出失败:${e instanceof Error ? e.message : String(e)}` }
    }
  }

  @Remote('schedule-toggle')
  async scheduleToggle(request: { id: string; enabled: boolean }): Promise<{ ok: boolean; error?: string }> {
    if (request === undefined) request = {} as never
    const hit = this.schedules.find((s) => s.id === String(request.id ?? ''))
    if (hit === undefined) return { ok: false, error: '未找到' }
    hit.enabled = request.enabled !== false
    await this.saveState()
    if (hit.enabled) this.startScheduler()
    return { ok: true }
  }

  /** 知识包导出:全部/指定站的知识卡写 ~\.dsh\opencli-knowledge\,可分享/进版本库。
   * 上游 #2539 砍掉 sitemap 分发后的第三方补位;在线路径见 registerKnowledgeResources(MCP Resources)与 knowledge-get RPC。 */
  @Remote('knowledge-export')
  async knowledgeExport(request?: { sites?: string[] }): Promise<{ ok: boolean; paths?: string[]; error?: string }> {
    const list = await this.adapterList()
    if (list === null) return { ok: false, error: `目录不可用 | ${this.lastShellError ?? '未知'}` }
    const raw = (this.adapterCache as { json?: unknown } | null)?.json
    const entries = Array.isArray(raw) ? raw as RawEntry[] : []
    if (entries.length === 0) return { ok: false, error: '目录缓存为空' }
    // 网关对空 args 会传 undefined(真机复现):request 必须可选链
    const reqSites = request?.sites
    if (request !== undefined && Array.isArray(request.sites) && request.sites.length === 0) return { ok: false, error: 'sites 为空数组——空选择不支持,省略 sites 才全量导出' }
    const requested = Array.isArray(reqSites) && reqSites.length > 0
      ? reqSites.map((s) => String(s).trim().toLowerCase()).filter((s) => s.length > 0)
      : [...new Set(entries.map((e) => (e.site ?? e.command?.split('/')[0] ?? '').toLowerCase()).filter((s) => s.length > 0))]
    const dir = join(homedir(), '.dsh', 'opencli-knowledge')
    const paths: string[] = []
    const at = new Date().toISOString()
    for (const site of requested.slice(0, 200)) {
      const k = buildKnowledge(site, entries, at)
      if (k === null) continue
      const file = join(dir, `${site}.md`)
      try {
        await mkdir(dir, { recursive: true })
        await writeFile(file, renderKnowledgeMarkdown(k), 'utf8')
        paths.push(file)
      } catch { /* 单站写失败不阻断其余 */ }
    }
    if (paths.length === 0) return { ok: false, error: '没有可导出的站点(目录为空或站点名不匹配)' }
    return { ok: true, paths }
  }

  /**
   * 知识卡直取 RPC(面板/外部可调,不经模型会话):sites 缺省返回健康度异常(degraded/notice)
   * 且在目录内的站。MCP resources seam 不可用的 0.1.x 宿主上的等价路径(机制与迁移路径见仓库开发文档)。
   */
  @Remote('knowledge-get')
  async knowledgeGet(request?: { sites?: string[] }): Promise<{ ok: boolean; cards?: Array<{ site: string; uri: string; markdown: string }>; error?: string }> {
    const list = await this.adapterList()
    if (list === null) return { ok: false, error: `目录不可用 | ${this.lastShellError ?? '未知'}` }
    const raw = (this.adapterCache as { json?: unknown } | null)?.json
    const entries = Array.isArray(raw) ? raw as RawEntry[] : []
    if (entries.length === 0) return { ok: false, error: '目录缓存为空' }
    // 网关对空 args 会传 undefined(真机复现):request 必须可选链;同名站去重(大小写归一后可能重复)
    const reqSites = request?.sites
    const requested = Array.isArray(reqSites) && reqSites.length > 0
      ? [...new Set(reqSites.map((s) => String(s).trim().toLowerCase()).filter((s) => s.length > 0))]
      : [...new Set(Object.entries(SITE_HEALTH).filter(([, h]) => h.status === 'degraded' || h.status === 'notice')
          .map(([s]) => s)
          .filter((s) => entries.some((e) => (e.site ?? e.command?.split('/')[0] ?? '').toLowerCase() === s)))]
    const cards: Array<{ site: string; uri: string; markdown: string }> = []
    for (const site of requested.slice(0, 30)) {
      const k = buildKnowledge(site, entries)
      if (k === null) continue
      cards.push({ site, uri: knowledgeResourceUri(site), markdown: renderKnowledgeMarkdown(k) })
    }
    if (cards.length === 0) return { ok: false, error: '没有可返回的知识卡(目录为空或站点名不匹配)' }
    return { ok: true, cards }
  }

  /**
   * MCP 自host 端点状态(面板/ctl 可见性:外部消费者直连的 url+token 从告知文件拿)。
   * 只读投影:token 本体不回传(在 ~/.dsh/opencli-mcp-auth.json,文件权限即边界)。
   */
  @Remote('mcp-selfhost-status')
  async mcpSelfhostStatus(): Promise<{ ok: boolean; running: boolean; url?: string; port?: number; tokenSource?: string; authFile: string; tools?: Array<{ name: string; description: string }>; error?: string }> {
    if (this.mcpSelfhost !== null) {
      return { ok: true, running: true, url: this.mcpSelfhost.url, port: this.mcpSelfhost.port, tokenSource: this.mcpSelfhost.tokenSource, authFile: mcpAuthFile(), tools: this.mcpSelfhost.tools }
    }
    return { ok: true, running: false, authFile: mcpAuthFile(), ...(this.mcpSelfhostError !== null ? { error: this.mcpSelfhostError } : {}) }
  }

  /** MCP 自host 启动(init 专用,awaited):失败留痕不抛;句柄随 ctx.effect 收(收件箱计时器同款)。 */
  private async startMcpSelfhostSafe(): Promise<void> {
    const r = await startMcpSelfhost({ entriesProvider: () => (this.adapterCache as { json?: unknown } | null)?.json })
    if (!r.ok) {
      this.mcpSelfhostError = r.error
      console.warn(`[dsh-opencli] ${r.error}(外部 MCP 消费者直连不可用,插件其余功能不受影响;可用 DSH_OPENCLI_MCP_PORT 换端口)`)
      return
    }
    this.mcpSelfhost = r.handle
    ;(this.ctx as unknown as { effect?: (f: () => () => void) => unknown }).effect?.(() => () => {
      void r.handle.stop()
      if (this.mcpSelfhost === r.handle) this.mcpSelfhost = null
    })
  }

  @Remote('schedule-remove')
  async scheduleRemove(request: { id: string }): Promise<{ ok: boolean; error?: string }> {
    if (request === undefined) request = {} as never
    const i = this.schedules.findIndex((s) => s.id === String(request.id ?? ''))
    if (i < 0) return { ok: false, error: '未找到' }
    this.schedules.splice(i, 1)
    delete this.runHistory[String(request.id ?? '')]
    await this.saveState()
    return { ok: true }
  }

  /**
   * NL 意图映射:自然语言 → ctl 同款闭集意图(经宿主 llm)。显式按钮触发——
   * 花的是用户自己的模型额度,且映射结果必须过预览卡确认,不做黑箱执行。
   * llm 服务缺席(web 之外的宿主)→ ok:false 带指引;模型输出不合法 → ok:false(绝不猜测补全)。
   */
  @Remote('nl-intent')
  async nlIntent(request: { text: string }): Promise<{ ok: boolean; explanation?: string; intent?: Intent; error?: string }> {
    const text = String(request?.text ?? '')
    if (text.trim().length === 0) return { ok: false, error: '输入为空' }
    // 动态取用(不 static inject:裸 Context 测试宿主没有 llm,inject 会让插件整装失败)
    const llm = (this.ctx as unknown as { get?: (n: string) => unknown }).get?.('llm') as
      | { stream: (o: Record<string, unknown>) => AsyncIterable<unknown> }
      | undefined
    if (llm === undefined) return { ok: false, error: '宿主未提供 llm 服务(NL 指挥台需要 dsh web 宿主)' }
    const selection = (this.ctx as unknown as { get?: (n: string) => unknown }).get?.('agentDefaultModel') as
      | { currentSelection?: () => { provider: string; model: string } }
      | undefined
    let provider: string | undefined
    let model: string | undefined
    try { const s = selection?.currentSelection?.(); if (s !== undefined) { provider = s.provider; model = s.model } } catch { /* 用 llm 默认路由 */ }
    // 热门站点命令:适配器目录蒸馏(已有缓存)的前 30 条零参命令
    const commands = this.hotCommands(30)
    const ctxNl: NlContext = {
      commands,
      schedules: this.schedules.slice(0, 20).map((s) => ({ id: s.id, site: s.site })),
      channels: (this.state.notifyConfig?.channels ?? []).map((c) => c.type),
    }
    // 候选路由:默认选择优先,401/403(key 失效)时轮试其他已注册 provider。
    // 模型名来源(按序):① llm.resolveModelInfo(provider, undefined)(适配器有默认则用);
    // ② llm.listModels(provider) 首项(panel 添加 provider 时注册的模型清单,如 minimax-cn
    //   的 MiniMax-M3.1-Flash——pi-ai 无"default model"语义,undefined model 必炸,真机踩过)。
    const candidates: Array<{ provider?: string; model?: string }> = []
    if (provider !== undefined && model !== undefined) candidates.push({ provider, model })
    try {
      const llmX = llm as unknown as { listProviders?: () => Array<{ id?: string; name?: string }>; resolveModelInfo?: (p: string, m?: string) => Promise<{ id?: string }>; listModels?: (p: string) => Promise<Array<{ id?: string }>> }
      const providers = llmX.listProviders?.() ?? []
      for (const p of providers) {
        const id = p.id ?? p.name
        if (id === undefined || candidates.some((c) => c.provider === id)) continue
        let pushed = false
        try {
          const info = await llmX.resolveModelInfo?.(id, undefined)
          const mid = typeof info?.id === 'string' && info.id.length > 0 ? info.id : undefined
          if (mid !== undefined) { candidates.push({ provider: id, model: mid }); pushed = true }
        } catch { /* 无默认语义的适配器(如 pi-ai)会炸——fallthrough 到模型清单 */ }
        if (!pushed) {
          try {
            const models = await llmX.listModels?.(id)
            const mid = Array.isArray(models) && models.length > 0 && typeof models[0]!.id === 'string' ? models[0]!.id : undefined
            candidates.push({ provider: id, ...(mid !== undefined ? { model: mid } : {}) })
          } catch { candidates.push({ provider: id }) }
        }
      }
    } catch { /* 只有默认路由可用 */ }
    let raw = ''
    let llmErr = ''
    const call: LlmCaller = async (system, user) => {
      let lastErr: Error | null = null
      const tried: string[] = []
      for (const route of candidates.length > 0 ? candidates : [{}]) {
        // 无 model 的候选跳过(pi-ai 对 undefined model 报 UNKNOWN_MODEL,真机踩过)——
        // 只信 resolveModelInfo 成功解析出确切模型的
        if (route.provider !== undefined && route.model === undefined) { tried.push(route.provider + '(无默认模型,跳)'); continue }
        raw = ''
        try {
          const stream = llm.stream({
            ...(route.provider !== undefined ? { provider: route.provider, model: route.model } : {}),
            system,
            messages: [{ role: 'user', content: [{ type: 'text', text: user }] }],
            temperature: 0,
          })
          for await (const chunk of stream) {
            const c = chunk as { type?: string; text?: string; reason?: { kind?: string; failure?: { code?: string; message?: string } } }
            if (c.type === 'text-delta' && typeof c.text === 'string') raw += c.text
            if (c.type === 'finish' && (c.reason?.kind === 'error' || c.reason?.kind === 'aborted')) {
              throw new Error(`llm ${c.reason?.kind}: ${c.reason?.failure?.code ?? ''} ${c.reason?.failure?.message ?? ''}`)
            }
          }
          if (raw.trim().length > 0) return raw
          lastErr = new Error('空输出')
          tried.push((route.provider ?? 'default') + '(空输出)')
        } catch (e) {
          lastErr = e instanceof Error ? e : new Error(String(e))
          tried.push((route.provider ?? 'default') + '(' + lastErr.message.slice(0, 40) + ')')
        }
      }
      llmErr = lastErr !== null ? lastErr.message.slice(0, 200) : '无可用路由'
      // 带轮试轨迹:用户能看到试过哪些路由、各为什么失败(诊断不再靠猜)
      llmErr = tried.length > 0 ? llmErr + ' [轮试:' + tried.join(' → ') + ']' : llmErr
      throw lastErr ?? new Error('无可用路由')
    }
    const r = await nlToIntent(call, text, ctxNl)
    if (r === null) {
      if (llmErr.length > 0) return { ok: false, error: '映射失败:llm 调用出错 ' + llmErr + '(可在面板 Models 页检查模型 key)' }
      if (raw.trim().length === 0) return { ok: false, error: '映射失败:llm 无文本输出(路由/额度问题?宿主模型会话可正常对话则重试)' }
      return { ok: false, error: '映射失败:模型输出未通过闭集校验。原始输出头:' + raw.slice(0, 160).replace(/\n/g, ' ') + ' ——可换更明确的说法,或用命令模式/ctl' }
    }
    return { ok: true, explanation: r.explanation, intent: r.intent }
  }

  /** 热门站点命令(目录蒸馏,零参命令优先,给 NL 映射当候选)。 */
  private hotCommands(limit: number): string[] {
    const out: string[] = []
    const dir = (this.adapterCache as { json?: unknown } | null)?.json as { sites?: Array<{ name: string; commands?: Array<{ name: string; args?: string[] }> }> } | undefined
    for (const site of dir?.sites ?? []) {
      for (const c of site.commands ?? []) {
        if ((c.args ?? []).length === 0) {
          out.push(`site ${site.name} ${c.name}`)
          if (out.length >= limit) return out
        }
      }
    }
    return out
  }

  @Remote('try-run')
  async tryRun(request: { line: string }): Promise<{ ok: boolean; text?: string; error?: string }> {
    if (request === undefined) request = {} as never
    const line = String(request.line ?? '').trim()
    if (!line) return { ok: false, error: '命令为空' }
    const [head, ...rest] = line.split(/\s+/)
    if (head !== 'site' || rest.length < 2) return { ok: false, error: '只支持 site <适配器> <命令> [参数...]，如：site arxiv recent cs.AI' }
    const [adapter, command, ...args] = rest as string[]
    if (!/^[\w@.-]+$/.test(adapter) || !/^[\w-]+$/.test(command)) return { ok: false, error: `非法 adapter/command:${adapter} ${command}` }
    if (this.state.disabled.includes(adapter)) return { ok: false, error: `适配器 ${adapter} 已被禁用` }
    const out = await this.runOpencli([adapter, command, ...args])
    const text = this.renderOut(out)
    if (out.exitCode !== 0) {
      // 修复(核验A-3):exit≠0 原样透传原始 YAML,绕过统一恢复指引。归类+附插件层指引
      const raw = out.stdout + out.stderr
      // ③(零配置路由矩阵 ③):无扩展时的 AUTH 失败换降级引导——登录态整体不可用,不是"去登录"能解决的;
      // 有扩展时维持原文案。前缀「登录态缺失」保持不变(hardening A-3 归类锚点)
      const kind = /BROWSER_CONNECT|extension not connected/i.test(raw) ? '扩展未连接——请打开 Chrome 并启用 OpenCLI 扩展(装法见 https://github.com/jackwener/opencli/releases),再在面板「总览」巡检登录态'
        : /AUTH_REQUIRED|请先登录|NOT_LOGGED_IN/i.test(raw)
          ? ((await this.extensionState()).connected === false
              ? '登录态缺失:当前无扩展,登录态(COOKIE)命令整体不可用——匿名降级拿不到你的 cookie(写命令永不降级);装扩展后可恢复:https://github.com/jackwener/OpenCLI/releases'
              : '登录态缺失——先在真实 Chrome 登录该站或运行 opencli <site> login')
        : /验证码|captcha|Verifying your browser/i.test(raw) ? '风控墙——停止自动化,冷却后人工过盾,写操作务必低频'
        : null
      return { ok: false, error: kind !== null ? '【' + kind + '】原始输出:' + text.slice(0, 300) : text }
    }
    // 真实性判定:exit 0 也可能拿到空结果/风控页/登录提示(上游静默失败类的面板侧防线)
    const v = await this.verifyResult(adapter, command, out.stdout)
    if (v !== null && !v.verdict) {
      return { ok: false, error: `适配器 ${adapter} 返回的内容被判定无效(P=${v.p.toFixed(2)},${v.why ?? '内容异常'})。请先在真实 Chrome 登录 ${adapter},或运行 \`opencli ${adapter} login\` 后用面板“巡检登录态”确认。原文:${text.slice(0, 300)}` }
    }
    const badge = this.verifyBadge(v)
    return { ok: true, text: badge ? `${badge} ${text}` : text }
  }

  @Remote('replay')
  async replay(request: { step: string; session?: string; skipDecorative?: boolean }): Promise<{ ok: boolean; error?: string; skipped?: 'decorative' }> {
    const step = typeof request.step === 'string' ? request.step.trim() : ''
    if (step.length === 0) return { ok: false, error: 'step 为空' }
    // #59 补完:装饰性步骤(scroll/hover,只改 CSS/视觉状态)回放可整体跳过——调用方显式
    // skipDecorative:true 才跳;跳过不执行、不落轨迹,结果带 skipped:'decorative' 如实标注
    // (数据读写步骤永不归入装饰类,isDecorativeStep 只认 scroll/hover 两个动词)
    if (request.skipDecorative === true && isDecorativeStep(step)) return { ok: true, skipped: 'decorative' }
    // MVP：仅回显步骤，真实回放走 site/opencli_* 透传（与 client 的 localStorage 录制互补）
    const [head, ...rest] = step.split(' ')
    if (head === 'site' && rest.length >= 2) {
      const [adapter, command, ...args] = rest
      if (adapter !== undefined && command !== undefined) {
        const out = await this.runOpencli([adapter, command, ...args])
        return { ok: out.exitCode === 0, error: out.exitCode !== 0 ? this.renderOut(out) : undefined }
      }
    }
    // 命名空间迁移(2026-10):步骤头 opencli_* 是正主;browser_* 旧头继续收——localStorage
    // 里的历史录制不会随迁移改写,旧步骤必须仍然可回放
    const ns = head.startsWith('opencli_') ? 'opencli_' : head.startsWith('browser_') ? 'browser_' : null
    if (ns !== null) {
      // 0.4.7:session 可选(dsh 默认)——差分基准等自动化用独立会话,不碰用户活页
      const sess = typeof request.session === 'string' && request.session.trim().length > 0 ? request.session.trim() : 'dsh'
      const out = await this.runBrowserTraced(sess, [head.slice(ns.length), ...rest])
      return { ok: out.exitCode === 0, error: out.exitCode !== 0 ? this.renderOut(out) : undefined }
    }
    return { ok: false, error: `未知步骤:${step}` }
  }

  // L3 高级自动化：脚本/配方/泛爬（对齐社区同类插件的高级工具面，MVP 桩 + 透传）
  @Remote('script-catalog')
  async scriptCatalog(): Promise<{ ok: boolean; scripts: Array<{ name: string; sha256: string; description: string }> }> {
    return { ok: true, scripts: [
      { name: 'article', sha256: 'builtin-article', description: '只读：提取正文为 Markdown' },
      { name: 'links', sha256: 'builtin-links', description: '只读：提取页面链接' },
      { name: 'jsonld', sha256: 'builtin-jsonld', description: '只读：提取 JSON-LD' },
      { name: 'forms', sha256: 'builtin-forms', description: '只读：提取表单结构' },
    ] }
  }
  @Remote('script-run-builtin')
  async scriptRunBuiltin(request: { name: string; url?: string }): Promise<{ ok: boolean; result?: string; error?: string }> {
    const name = String(request.name ?? '')
    if (!['article','links','jsonld','forms'].includes(name)) return { ok: false, error: `未知内置脚本:${name}` }
    // 透传为 browser extract 变体(经 runBrowserTraced 落轨迹)
    const out = await this.runBrowserTraced('dsh', ['extract', ...(request.url !== undefined ? [request.url] : [])])
    return { ok: out.exitCode === 0, result: this.renderOut(out), error: out.exitCode !== 0 ? this.renderOut(out) : undefined }
  }
  @Remote('crawl')
  async crawl(request: { url: string; maxPages?: number; maxDepth?: number }): Promise<{ ok: boolean; error?: string }> {
    const url = String(request.url ?? '').trim()
    if (url.length === 0) return { ok: false, error: 'url 为空' }
    const maxPages = Math.min(Number(request.maxPages ?? 20), this.usagePolicy.maxPagesPerRun ?? 20)
    // MVP：单页提取，真实广度遍历后续接 opencli_crawl(经 runBrowserTraced 落轨迹)
    const out = await this.runBrowserTraced('dsh', ['open', url])
    if (out.exitCode !== 0) return { ok: false, error: this.renderOut(out) }
    return { ok: true }
  }

  @Remote('script-validate')
  async scriptValidate(request: { code: string }): Promise<{ ok: boolean; meta?: { name: string; match: string; grant: string }; error?: string }> {
    const code = String(request.code ?? '')
    if (!code.includes('@match') || !code.includes('@grant none')) return { ok: false, error: '需包含 @match + @grant none' }
    if (code.length > 64 * 1024) return { ok: false, error: '源码 >64KB' }
    const m = code.match(/@match\s+(\S+)/)?.[1] ?? ''
    return { ok: true, meta: { name: code.match(/@name\s+(.+)/)?.[1]?.trim() ?? 'unnamed', match: m, grant: 'none' } }
  }
  @Remote('userscript-run')
  async userscriptRun(request: { code: string; url: string }): Promise<{ ok: boolean; result?: string; error?: string }> {
    const v = await this.scriptValidate({ code: String(request.code ?? '') })
    if (!v.ok) return { ok: false, error: v.error }
    if (this.automationMode !== 'unrestricted') return { ok: false, error: '需 unrestricted 模式或审批（当前 ' + this.automationMode + '）' }
    const out = await this.runBrowserTraced('dsh', ['eval', String(request.code ?? '').slice(0, 200)])
    return { ok: out.exitCode === 0, result: this.renderOut(out) }
  }
  @Remote('recipe-run')
  async recipeRun(request: { steps: Array<{ type: string; selector?: string; value?: string }> }): Promise<{ ok: boolean; error?: string }> {
    const steps = Array.isArray(request.steps) ? request.steps : []
    if (steps.length === 0 || steps.length > 25) return { ok: false, error: 'steps 1-25' }
    for (const s of steps) {
      const t = String((s as Record<string,unknown>).type ?? '')
      if (!['wait','click','fill','type','press','select','check','hover','scroll','extract','assert','screenshot'].includes(t)) return { ok: false, error: `未知步骤:${t}` }
      // MVP：逐条透传为 opencli_*（抽取/点击等）
      const sel = (s as Record<string,unknown>).selector !== undefined ? String((s as Record<string,unknown>).selector) : undefined
      const val = (s as Record<string,unknown>).value !== undefined ? String((s as Record<string,unknown>).value) : undefined
      const argv = [t, ...(sel !== undefined ? [sel] : []), ...(val !== undefined ? [val] : [])]
      const out = await this.runBrowserTraced('dsh', argv)
      if (out.exitCode !== 0) return { ok: false, error: this.renderOut(out) }
    }
    return { ok: true }
  }
  @Remote('automation-search')
  async automationSearch(request: { query?: string }): Promise<{ ok: boolean; hits: Array<{ id: string; name: string }> }> {
    const q = String(request.query ?? '').toLowerCase()
    const hits = this.schedules.filter((s) => s.site.toLowerCase().includes(q) || q.length === 0).slice(0, 5).map((s) => ({ id: s.id, name: s.site }))
    return { ok: true, hits }
  }
  @Remote('automation-develop')
  async automationDevelop(request: { action: string; id?: string; code?: string }): Promise<{ ok: boolean; error?: string }> {
    if (request.action === 'get' && typeof request.id === 'string') {
      const hit = this.schedules.find((s) => s.id === request.id)
      return hit !== undefined ? { ok: true } : { ok: false, error: '未找到' }
    }
    if (request.action === 'save') return { ok: true }
    if (request.action === 'validate') return { ok: true }
    if (request.action === 'test') return { ok: true }
    return { ok: false, error: `未知 action:${String(request.action)}` }
  }
  @Remote('automation-run')
  async automationRun(request: { id: string }): Promise<{ ok: boolean; error?: string }> {
    const hit = this.schedules.find((s) => s.id === String(request.id ?? ''))
    if (hit === undefined) return { ok: false, error: '未找到' }
    return this.replay({ step: `site ${hit.site}` })
  }

  @Remote('automation-mode-get')
  async automationModeGet(): Promise<{ ok: boolean; mode: string }> {
    return { ok: true, mode: this.automationMode }
  }
  @Remote('automation-mode-set')
  async automationModeSet(request: { mode: string }): Promise<{ ok: boolean; error?: string }> {
    const m = String(request.mode ?? '')
    if (!['read-only','standard','autonomous','unrestricted'].includes(m)) return { ok: false, error: `未知模式:${m}` }
    this.automationMode = m as typeof this.automationMode
    return { ok: true }
  }

  @Remote('promote-recording')
  async promoteRecording(request: { name: string; steps: string[]; minRuns?: number; minSessions?: number }): Promise<{ ok: boolean; recipeId?: string; error?: string }> {
    const name = String(request.name ?? '').trim()
    if (!name) return { ok: false, error: 'name 必填' }
    if (!Array.isArray(request.steps) || request.steps.length === 0) return { ok: false, error: 'steps 必填' }
    const id = `rec-${Date.now()}`
    const recipe = {
      kind: 'recipe', id, name, status: 'draft', revision: 1,
      domains: [], tags: ['auto-promoted'],
      inputNames: [], createdAt: new Date().toISOString(),
      source: 'recording', originalSteps: request.steps,
    }
    return { ok: true, recipeId: id }
  }

  @Remote('install-opencli-skill')
  async installOpencliSkill(): Promise<{ ok: boolean; path?: string; error?: string }> {
    // 写 ~\.dsh\opencli-skill-inbox.md 让 dsh 助手读
    const path = `${homedir()}\\.dsh\\opencli-skill-inbox.md`
    const body = [
      '# opencli-skill 装清单',
      '',
      '1. 找到 opencli 仓的 skills 目录:',
      '   `~/.vfox/sdks/nodejs/node_modules/@jackwener/opencli/skills/`',
      '2. 把它复制到 dsh 技能目录:',
      '   `cp -r ~/.vfox/sdks/nodejs/node_modules/@jackwener/opencli/skills/* ~/.dsh/skills/`',
      '3. 重启 dsh web',
      '4. 验证:在 dsh 对话框说"加载 opencli-usage skill"',
      '',
      '完成后:你（dsh 助手）即可调用 opencli 的 6 个 skill（adapter-author / autofix / browser / browser-sitemap / sitemap-author / usage）',
    ].join('\n')
    try {
      const { writeFile, mkdir } = await import('node:fs/promises')
      await mkdir(`${homedir()}\\.dsh`, { recursive: true })
      await writeFile(path, body, 'utf8')
      return { ok: true, path }
    } catch (e) { return { ok: false, error: String(e) } }
  }
  @Remote('rulepacks-list')
  async rulePacksList(): Promise<{ ok: boolean; packs: typeof this.rulePacks }> {
    return { ok: true, packs: [...this.rulePacks] }
  }
  @Remote('rulepacks-set')
  async rulePacksSet(request: { packs: typeof this.rulePacks }): Promise<{ ok: boolean; error?: string }> {
    if (!Array.isArray(request.packs)) return { ok: false, error: 'packs 需为数组' }
    for (const p of request.packs) {
      if (typeof (p as Record<string, unknown>).initScriptSha256 !== 'string' || String((p as Record<string,unknown>).initScriptSha256).length !== 64) return { ok: false, error: 'initScriptSha256 需 64 位' }
      const s = (p as Record<string,unknown>).initScriptPath
      if (typeof s !== 'string' || s.length === 0) return { ok: false, error: 'initScriptPath 不能为空' }
    }
    this.rulePacks = request.packs as typeof this.rulePacks
    return { ok: true }
  }

  /** R1 审批门:site 的 write 命令(发帖/点赞/下单等)先经 dsh 原生审批(ask→allowed-once)。
   * 任何异常一律放行给 next(),绝不因审批门自身故障阻塞工具。 */
  private registerApprovalGate(): void {
    this.ctx.on('tools/pre-execute', async (exec, next) => {
      try {
        if (this.automationMode === 'unrestricted') return await next()
        // 通用 argv 网关的写审批(安全审查 HIGH:描述宣称走审批,实际 execute 直通,
        // `opencli_run {args:["weibo","publish"]}` 可绕门直执行写命令):站点形态两段 argv
        // 按目录查权限,write/未知一律 ask(fail-closed);浏览器/系统命名空间按 opencli_* 同款边界放行
        if (exec.name === 'opencli_run') {
          const arr = Array.isArray(((exec.arguments ?? {}) as { args?: unknown }).args) ? (((exec.arguments ?? {}) as { args?: unknown }).args as unknown[]).map(String) : []
          const [a0, a1] = arr
          // 评审 HIGH(第三入口):opencli_run {args:["browser","eval",...]} 经 RESERVED_NAMESPACES 跳过站点检查
          // → eval 规则只匹配 opencli_do/browser_do 工具名 → approvalDecision 对非 site 恒 allow = 零审批执行任意 JS。
          // 修法:browser 命名空间下遇 eval 子命令同样 ask(eval=写原语,不因入口不同而降级)
          if (a0 === 'browser' && a1 === 'eval') {
            const reason = 'opencli_run browser eval 在登录态页面执行任意 JavaScript,等价于写原语,需人工确认。'
            this.recordAudit('opencli_run browser eval', reason)
            return { kind: 'ask', reason }
          }
          if (a0 !== undefined && a1 !== undefined && !RESERVED_NAMESPACES.has(a0) && a0 !== 'list' && a0 !== 'help' && !a0.startsWith('--')) {
            const acc = await this.lookupAccess(a0, a1)
            if (acc !== 'read') {
              const reason = `opencli_run ${a0} ${a1} 是写命令或未知权限(${acc})——会在登录态浏览器真实执行,需人工确认。`
              this.recordAudit(`opencli_run ${a0} ${a1}`, reason)
              return { kind: 'ask', reason }
            }
          }
        }
        // opencli_do eval 在登录态页面执行任意 JS,等价写原语——与 userscript-run 的门对齐,
        // 不再裸放(安全审查 MEDIUM:同能力双标)。新旧两名都拦:兼容层的转发发生在 execute 层,
        // pre-execute 只见原始工具名,旧名 browser_do 不设防就是 eval 的绕门通道
        if ((exec.name === 'opencli_do' || exec.name === 'browser_do') && String(((exec.arguments ?? {}) as { command?: unknown }).command ?? '') === 'eval') {
          const reason = `${exec.name} eval 在登录态页面执行任意 JavaScript,等价于写原语(可发帖/点赞/改数据),需人工确认。`
          this.recordAudit(`${exec.name} eval`, reason)
          return { kind: 'ask', reason }
        }
        // chrome_raw 是高危逃生口:无条件走人工审批,兑现描述里"人工确认"的承诺
        // (独立评审发现:此前描述承诺审批但 pre-execute 无任何设防)
        if (exec.name === 'chrome_raw') {
          const m = String(((exec.arguments ?? {}) as { method?: unknown }).method ?? '?')
          const reason = `chrome_raw ${m} 直调 Chrome 原生 API——可能改动真实浏览器的窗口/标签布局,需人工确认。`
          this.recordAudit(`chrome_raw ${m}`, reason)
          return { kind: 'ask', reason }
        }
        // canvas_click 坐标点击按写原语审批(坐标点击在用户
        // 登录态浏览器里产生真实副作用);且点击目标由坐标在页面运行时动态命中,不像
        // selector 目标那样可静态审计——与 opencli_do eval 同款门,不裸放
        if (exec.name === 'canvas_click') {
          const c = (exec.arguments ?? {}) as { x?: unknown; y?: unknown }
          const cx = String(c.x ?? '?')
          const cy = String(c.y ?? '?')
          const reason = `canvas_click (${cx},${cy}) 坐标点击会在登录态页面真实执行(等价写原语,目标不可静态审计),需人工确认。`
          this.recordAudit(`canvas_click ${cx} ${cy}`, reason)
          return { kind: 'ask', reason }
        }
        const a = (exec.arguments ?? {}) as { adapter?: unknown; command?: unknown }
        const argsOk = typeof a.adapter === 'string' && typeof a.command === 'string' && a.adapter.length > 0 && a.command.length > 0
        if (this.automationMode === 'read-only' && exec.name === 'site' && argsOk) {
          const acc = await this.lookupAccess(a.adapter as string, a.command as string)
          if (acc !== 'read') {
            const roReason = `只读模式：site ${String(a.adapter)} ${String(a.command)} 为写操作，已拦截。`
            this.recordAudit(`site ${String(a.adapter)} ${String(a.command)}`, roReason)
            return { kind: 'ask', reason: roReason }
          }
          return await next()
        }
        // 只在确有可能 ask 时才付出缓存查询成本;其余情况 access 传占位值,判定函数自会放行
        const needsAccess = exec.name === 'site' && this.state.approval === 'on' && argsOk && !this.state.disabled.includes(a.adapter)
        const access = needsAccess ? await this.lookupAccess(a.adapter as string, a.command as string) : 'unknown'
        const decision = approvalDecision(this.state.approval === 'on', this.state.disabled, exec.name, a.adapter, a.command, access)
        if (decision === 'allow') return await next()
        const reason = decision === 'ask-write'
          ? `site ${String(a.adapter)} ${String(a.command)} 是写操作——会在你的登录态浏览器里真实执行(发帖/点赞/下单/改数据)。`
          : `site ${String(a.adapter)} ${String(a.command)} 未能确认权限类型,按写操作审批。`
        this.recordAudit(`site ${String(a.adapter)} ${String(a.command)}`, reason)
        return { kind: 'ask', reason }
      } catch {
        return await next()
      }
    })
  }

  private async lookupAccess(adapter: string, command: string): Promise<'read' | 'write' | 'unknown'> {
    if (this.adapterCache === null) await this.adapterList()
    return commandAccess(this.adapterCache?.json, adapter, command)
  }


  /** canary 漂移巡检:top-20 站只读命令逐站跑,与上一轮 canary 报告对比出新失败/恢复。
   * 产物 ~/.dsh/opencli-canary/canary-<时间戳>.md(保留 14 份);可被定时任务
   * 以命令 "canary" 每晚触发——站点改版漂移当天可见,不依赖上游 issue 猜健康度。 */
  @Remote('canary-run')
  async canaryRun(): Promise<{ ok: boolean; total: number; passed: number; newFailures: string[]; recovered: string[]; path?: string; error?: string }> {
    const list = await this.adapterList()
    if (list === null) return { ok: false, total: 0, passed: 0, newFailures: [], recovered: [], error: this.lastShellError ?? '目录不可用' }
    const lines = pickCanaryCommands(list)
    if (lines.length === 0) return { ok: false, total: 0, passed: 0, newFailures: [], recovered: [], error: '目录无只读命令' }
    const results: BenchItem[] = []
    for (let i = 0; i < lines.length; i++) {
      const [site, command] = lines[i]!.split(/\s+/) as [string, string]
      // 防御性只读门(安全审查 MEDIUM):pickCanaryCommands 按热词名挑命令不查权限——
      // 若上游目录某条 hot 词命名命令实为 write,这里挡住,绝不无人值守执行写命令
      if ((await this.lookupAccess(site, command)) !== 'read') {
        results.push({ site, command: lines[i]!, ok: false, p: null, ms: 0, error: '目录标记为非只读,防御性跳过' })
        continue
      }
      const started = Date.now()
      try {
        const out = await this.runOpencli([site, command], 45_000)
        if (out.exitCode !== 0) {
          results.push({ site, command: lines[i]!, ok: false, p: null, ms: Date.now() - started, error: clip((out.stderr || out.stdout).trim().slice(0, 120) || `退出码 ${out.exitCode}`, 120) })
        } else {
          const v = await this.verifyResult(site, command, out.stdout)
          const silent = v !== null && !v.verdict
          results.push({ site, command: lines[i]!, ok: !silent, p: v === null ? null : v.p, ms: Date.now() - started, ...(silent ? { error: clip(`静默失败:${v.why ?? ''}`, 120) } : {}) })
        }
      } catch (e) {
        results.push({ site, command: lines[i]!, ok: false, p: null, ms: Date.now() - started, error: clip(e instanceof Error ? e.message : String(e), 120) })
      }
      if (i < lines.length - 1 && this.benchGapMs > 0) await new Promise((res) => setTimeout(res, this.benchGapMs))
    }
    const dir = process.env.DSH_OPENCLI_CANARY_DIR ?? join(homedir(), '.dsh', 'opencli-canary')
    let prevText: string | null = null
    try {
      mkdirSync(dir, { recursive: true })
      const olds = readdirSync(dir).filter((f) => /^canary-.+\.md$/.test(f)).sort()
      prevText = olds.length > 0 ? await readFile(join(dir, olds[olds.length - 1]!), 'utf8') : null
    } catch { /* 首跑或目录不可读:无基线 */ }
    const prev = parseCanarySnapshot(prevText)
    const md = buildCanaryReport(results, prev, new Date().toISOString())
    const stamp = new Date().toISOString().replace(/[:.]/g, '-')
    const file = join(dir, `canary-${stamp}.md`)
    try {
      await writeFile(file, md, 'utf8')
      const olds = readdirSync(dir).filter((f) => /^canary-.+\.md$/.test(f)).sort()
      if (olds.length > CANARY_KEEP) for (const f of olds.slice(0, olds.length - CANARY_KEEP)) { try { unlinkSync(join(dir, f)) } catch { /* 忽略 */ } }
    } catch { /* 落盘失败不改变结论 */ }
    const failedCmds = new Set(results.filter((x) => !x.ok).map((x) => x.command))
    const prevMap = prev
    const newFailures = results.filter((x) => !x.ok && prevMap.get(x.command) === true).map((x) => x.command)
    const recovered = results.filter((x) => x.ok && prevMap.get(x.command) === false).map((x) => x.command)
    const passed = results.filter((x) => x.ok).length
    return { ok: failedCmds.size === 0, total: results.length, passed, newFailures, recovered, path: file }
  }

  // ── 写操作证据包──────────────────────────────────

  /** 审批拒绝在 host 落地的最终文本特征(dsh-tools serviceAsk 的四种非授权拒绝 + 本插件
   *  审批门的写操作/只读拦截理由——无审批服务时 ask.reason 会原样成为拒绝文本)。
   *  以 host 真实字符串为准(dsh-tools/lib/index.js 的 serviceAsk),别凭记忆改写。 */
  private static readonly APPROVAL_DENIED_RE = /requires approval|the user rejected tool|was cancelled|是写操作|只读模式/

  /**
   * 证据包专用截图:force 必拍,落盘/防碰撞/跨版本 argv 形态全复用 captureStepShot(A-core);
   * 合成 exitCode:1 结果是双保险——即使 force 语义被改,失败命令的补拍路径仍然成立。
   * 会话固定 dsh(site 适配器经 daemon 自己的浏览器跑,插件侧只有默认会话可拍,近似但聊胜于无)。
   */
  private async captureEvidenceShot(): Promise<string | undefined> {
    return await this.captureStepShot('dsh', ['evidence'], { exitCode: 1, stdout: '', stderr: '' }, await this.cliMajor(), true)
  }

  /** 放行写命令的证据落盘:after 截图 → buildEvidence → saveEvidence(100 份轮转)。失败也落。 */
  private async recordSiteEvidence(adapter: string, command: string, argv: string[], out: { exitCode: number; stdout: string; stderr: string }, beforeShot?: string): Promise<void> {
    try {
      const afterShot = await this.captureEvidenceShot()
      await saveEvidence(this.evidenceDir, buildEvidence({
        command: `site ${adapter} ${command}`,
        argv,
        approval: { mode: this.state.approval, reason: null },
        beforeShot: beforeShot ?? null,
        afterShot: afterShot ?? null,
        result: { exitCode: out.exitCode, head: `${out.stdout}\n${out.stderr}`.trim().slice(0, 200) },
        site: adapter,
      }))
    } catch { /* 证据失败不阻断命令结果 */ }
  }

  /** 被拒写命令的证据落盘:命令从未执行,无截图可言,result 记 -1 + 拒绝理由原文。 */
  private async recordBlockedEvidence(adapter: string, command: string, args: string[], denial: string): Promise<void> {
    try {
      await saveEvidence(this.evidenceDir, buildEvidence({
        command: `site ${adapter} ${command}`,
        argv: [adapter, command, ...args],
        approval: { mode: this.state.approval, reason: 'blocked' },
        beforeShot: null,
        afterShot: null,
        result: { exitCode: -1, head: denial.slice(0, 200) },
        site: adapter,
      }))
    } catch { /* 静默 */ }
  }

  /**
   * 审批拒绝监听:被拒的写命令执行体根本不会跑(site execute 无从得知),唯一
   * 可见点是 tools/post-execute 收到的 isError 结果——host 把 serviceAsk 的拒绝落成
   * error.message(派发前拒绝也走这条 waterfall,dsh-tools finalizeScheduledExecution)。
   * 命中拒绝特征且目录确认为写命令 → 补一包 approval.reason='blocked'。观察者姿态:
   * 异常自吞、恒回 next(),绝不改变门后行为。
   */
  private registerEvidenceListeners(): void {
    this.ctx.on('tools/post-execute', async (exec, result, next) => {
      try {
        if (exec.name === 'site' && result.isError) {
          const a = (exec.arguments ?? {}) as { adapter?: unknown; command?: unknown; args?: unknown }
          if (typeof a.adapter === 'string' && typeof a.command === 'string') {
            const denial = result.error.message
            if (OpencliService.APPROVAL_DENIED_RE.test(denial) && (await this.lookupAccess(a.adapter, a.command)) !== 'read') {
              await this.recordBlockedEvidence(a.adapter, a.command, Array.isArray(a.args) ? a.args.map(String) : [], denial)
            }
          }
        }
      } catch { /* 证据失败不改变门后行为 */ }
      return await next()
    })
  }

  /** 最近写命令证据包:文件名即元数据(时间戳+站点),不读全文;倒序取前 20。 */
  @Remote('evidence-list')
  async evidenceList(): Promise<{ ok: boolean; items: Array<{ file: string; at: string; site: string; bytes: number }> }> {
    try {
      const names = readdirSync(this.evidenceDir).filter((f) => EVIDENCE_FILE_RE.test(f)).sort().reverse().slice(0, 20)
      const items: Array<{ file: string; at: string; site: string; bytes: number }> = []
      for (const f of names) {
        const meta = parseEvidenceFileName(f)
        if (meta === null) continue
        let bytes = 0
        try { bytes = statSync(join(this.evidenceDir, f)).size } catch { /* 竞态已删:0 兜底 */ }
        items.push({ file: join(this.evidenceDir, f), at: meta.at, site: meta.site, bytes })
      }
      return { ok: true, items }
    } catch {
      // 目录不存在(还没跑过写命令):空表(traceList 同款),不是错误
      return { ok: true, items: [] }
    }
  }

  /**
   * 证据包读侧全字段(画布证据卡,evidence-list 的读全文版):文件名只给 时间/站点,
   * 面板证据卡要 command/结论/双截图/免责行——读 JSON 全文出结构化投影(types.ts 的
   * EvidenceGetItem)。verdict 三值映射:approval.reason='blocked' 最优先(命令从未执行,
   * 不许被 exit 码改写成失败),其次 exitCode===0 → ok,其余 → fail。
   * 半截/已删的脏文件跳过不炸整表;目录不存在回空表(evidence-list 同款)。
   */
  @Remote('evidence-get')
  async evidenceGet(request?: { limit?: number }): Promise<EvidenceGetResult> {
    try {
      // 网关对空 args 会传 undefined(trace-list 同款):可选链 + 钳制,上限 EVIDENCE_KEEP(再多目录里也没有)
      const limit = Math.max(1, Math.min(EVIDENCE_KEEP, Math.floor(Number(request?.limit ?? 20)) || 20))
      const names = readdirSync(this.evidenceDir).filter((f) => EVIDENCE_FILE_RE.test(f)).sort().reverse().slice(0, limit)
      const items: EvidenceGetResult['items'] = []
      for (const f of names) {
        const meta = parseEvidenceFileName(f)
        if (meta === null) continue
        let rec: EvidenceRecord
        try { rec = JSON.parse(readFileSync(join(this.evidenceDir, f), 'utf8')) as EvidenceRecord } catch { continue /* 竞态已删/半截 JSON:宁缺毋炸 */ }
        const verdict = rec.approval?.reason === 'blocked' ? 'blocked' as const : (Number(rec.result?.exitCode) === 0 ? 'ok' as const : 'fail' as const)
        items.push({
          file: join(this.evidenceDir, f),
          at: meta.at,
          adapter: meta.site,
          command: String(rec.command ?? ''),
          verdict,
          // 可选字段省键(与画布数据层"省字段"契约同款):无截图/null 不给空串占位
          ...(typeof rec.beforeShot === 'string' && rec.beforeShot.length > 0 ? { beforeShot: rec.beforeShot } : {}),
          ...(typeof rec.afterShot === 'string' && rec.afterShot.length > 0 ? { afterShot: rec.afterShot } : {}),
          ...(typeof rec.shotNote === 'string' && rec.shotNote.length > 0 ? { note: rec.shotNote } : {}),
        })
      }
      return { ok: true, items }
    } catch {
      // 目录不存在(还没跑过写命令):空表(evidence-list 同款),不是错误
      return { ok: true, items: [] }
    }
  }

  // ── 基础设施 ──────────────────────────────────────────────

  /**
   * 读写分频(#59 补完):读步骤维持 750ms 级礼貌限流;写步骤走独立限频轨——
   * 距上一次写命令不足 writeMinDelayMs(默认 3s)时等足差额。读高频不抬写节奏,
   * 写谨慎也不拖慢读采集;两类步骤的时间预算互不占用。
   */
  private async acquireGovernor(kind: 'read' | 'write' = 'read'): Promise<void> {
    // 冷却期
    const now = Date.now()
    if (now < this.cooldownUntil) await new Promise((res) => setTimeout(res, this.cooldownUntil - now))
    // 并发闸:槽满时入队。唤醒后**重查**——release 唤醒(resolver 已出队)到被唤者真正
    // ++ 之间隔着微任务,期间新到者会同步抢走槽位;直增会让并发短暂超 max(0.1.2 发后
    // 审查 low:同构脚本实测 max=2 短暂达 3)。重查只看 concurrent,不看 queue.length:
    // 被唤者若因「队里还有人」再入队,队列只会无限轮转无人出列(livelock,单测实测);
    // 槽位空出时晚到者直接拿槽属礼貌限流的预期行为,不在此处补 FIFO 公平。
    while (this.concurrent >= this.usagePolicy.maxConcurrency) {
      await new Promise<void>((res) => { this.queue.push(res) })
    }
    this.concurrent++
    // 写独立限频轨:等足 writeMinDelayMs 差额(读轨不动;DSH_OPENCLI_WRITE_MIN_DELAY_MS 调,0=关)。
    // 预约式计时:先把"本写起跑时刻"记进 lastWriteAt 再睡——maxConcurrency=2 下两个写并发到达,
    // 后到者按前者的预约时刻顺延,起跑仍错开 ≥writeMin(礼貌限流语义,与读轨同为节奏而非硬闸)
    if (kind === 'write') {
      const rawW = Number(process.env.DSH_OPENCLI_WRITE_MIN_DELAY_MS ?? this.usagePolicy.writeMinDelayMs)
      const writeMin = Number.isFinite(rawW) && rawW >= 0 ? rawW : this.usagePolicy.writeMinDelayMs
      const t = Date.now() // 排队等槽后现取,不复用入口时刻(否则排过队的写会多等)
      const wait = this.lastWriteAt > 0 ? Math.max(0, writeMin - (t - this.lastWriteAt)) : 0
      this.lastWriteAt = t + wait
      if (wait > 0) await new Promise((res) => setTimeout(res, wait))
    }
    // 突发 + minDelay
    const burstWindow = 1000
    this.callTimestamps = this.callTimestamps.filter((t) => Date.now() - t < burstWindow)
    if (this.callTimestamps.length >= this.usagePolicy.burst) {
      const oldest = this.callTimestamps[0] ?? 0
      const wait = burstWindow - (Date.now() - oldest)
      if (wait > 0) await new Promise((res) => setTimeout(res, wait))
    }
    const last = this.callTimestamps[this.callTimestamps.length - 1]
    if (last !== undefined) {
      const delay = this.usagePolicy.minDelayMs - (Date.now() - last)
      if (delay > 0) await new Promise((res) => setTimeout(res, delay))
    }
  }
  private releaseGovernor(kind: 'read' | 'write' = 'read'): void {
    // 写轨以"上一写结束"与"已预约起跑"较晚者为基准(结束晚于预约=长命令,间隔从结束起算)
    if (kind === 'write') this.lastWriteAt = Math.max(this.lastWriteAt, Date.now())
    this.concurrent = Math.max(0, this.concurrent - 1)
    this.callTimestamps.push(Date.now())
    const next = this.queue.shift()
    if (next !== undefined) next()
  }
  private noteRateLimit(text: string): void {
    if (/429|502|503|504|Retry-After/i.test(text)) this.cooldownUntil = Date.now() + this.usagePolicy.cooldownMs
  }
  private async domainOf(adapter: string): Promise<string | null> {
    const list = await this.adapterList()
    const hit = list?.find((a) => a.name === adapter)
    return hit?.domain ?? null
  }
  private checkAuthProfile(domain: string | null, authProfile?: string): string | null {
    if (authProfile === undefined || authProfile.length === 0) return null
    const prof = this.authProfiles[authProfile]
    if (prof === undefined) return `未知 authProfile:${authProfile}`
    if (domain === null || domain === 'null' || domain === 'localhost' || domain === '127.0.0.1') return null
    if (!prof.allowedDomains.some((d) => domain === d || domain.endsWith(`.${d}`))) return `authProfile ${authProfile} 不允许访问域 ${domain}（允许：${prof.allowedDomains.join(', ')}）`
    return null
  }

  /** shell 调用形态(跨版本自探测锁定):resolved=shell.resolve(spec) 后执行;direct=直传 spec;array=command 传 argv 数组。 */
  private shellMode: 'resolved' | 'direct' | 'array' | null = null
  /** 调度去重 marker(键=任务id:分钟键,值=入册时刻;每启动周期有效,不落盘;此前寄生
   *  runHistory 造成 5055 键无限累积)。上限+过期淘汰对齐 runHistory 自愈先例:条目只在
   *  当个 tick 有意义,过期(>10 分钟)即删,超上限再裁最旧——常驻进程不再无限累积。 */
  private schedMarkers = new Map<string, number>()
  /** schedMarkers 存活上限(条);过期线 10 分钟(一次 tick 最多 15s,余量充裕)。 */
  private static readonly SCHED_MARKER_CAP = 2000
  private static readonly SCHED_MARKER_TTL_MS = 10 * 60 * 1000
  /** 超时后等子进程收尾的清理宽限(回执/轨迹卫生「cancel+有界清理」的有界部分;默认 5s,
   *  DSH_OPENCLI_CLEANUP_GRACE_MS 可调,与 JITTER/CHALLENGE_WAIT/SELFHEAL_BACKOFF 同款 env 约定)。 */
  private static cleanupGraceMs(): number {
    const v = process.env.DSH_OPENCLI_CLEANUP_GRACE_MS
    const raw = v === undefined || v.trim() === '' ? Number.NaN : Number(v) // 空串不当 0(Number('')===0 陷阱)
    return Number.isFinite(raw) && raw >= 0 ? Math.min(Math.round(raw), 60_000) : 5_000
  }

  /** marker 入册 + 过期/超限淘汰(插入序=时间序,裁最旧)。 */
  private addSchedMarker(key: string): void {
    const now = Date.now()
    this.schedMarkers.set(key, now)
    if (this.schedMarkers.size <= OpencliService.SCHED_MARKER_CAP) {
      for (const [k, at] of this.schedMarkers) {
        if (now - at <= OpencliService.SCHED_MARKER_TTL_MS) break // Map 迭代按插入序:遇到未过期即可停
        this.schedMarkers.delete(k)
      }
      return
    }
    let excess = this.schedMarkers.size - OpencliService.SCHED_MARKER_CAP
    for (const [k] of this.schedMarkers) {
      if (excess <= 0) break
      this.schedMarkers.delete(k)
      excess--
    }
  }

  /**
   * 0.2.0+ 原生执行:ctx.subprocess.spawn(argv)(官方 bash 工具同款 seam;
   * 旧 ctx.shell.execute 在 0.2.0 需要 sandbox policy 管线,插件直调已不可靠)。
   * 返回 null = 该 seam 不可用,调用方回落老路径。
   */
  private async runSubprocess(argv: string[], timeoutMs: number, stdoutMaxBytes: number, env?: Record<string, string>): Promise<{ exitCode: number; stdout: string; stderr: string } | null> {
    // 不能把 'subprocess' 放进 static inject:cordis 对声明服务做加载期解析,0.1.x 宿主没有它会
    // 让整个插件加载失败。改走 reflect 旁路(可选读取,缺失即 undefined→回落老 shell 路径)。
    let sub: SubprocessSeam | undefined
    try {
      sub = (this.ctx as unknown as { reflect?: { get?: (p: string, f?: boolean) => unknown } }).reflect?.get?.('subprocess', false) as SubprocessSeam | undefined
    } catch { return null }
    if (sub === undefined || typeof sub.spawn !== 'function') return null
    // bin 形态:裸命令 / node "<main.js>" / env 覆盖——按空白+引号切 argv
    const argv0 = this.bin === 'opencli'
      ? ['opencli']
      : (this.bin.match(/(?:[^\s"]+|"[^"]*")+/g) ?? [this.bin]).map((s) => s.replace(/^"|"$/g, ''))
    const h = sub.spawn({
      argv: [...argv0, ...argv],
      cwd: homedir(),
      stdio: { stdin: 'ignore', stdout: { maxBytes: stdoutMaxBytes }, stderr: { maxBytes: 262_144 } },
      graceMs: 1_000,
      signal: AbortSignal.timeout(timeoutMs),
      // env 显式条目与擦净后的父环境合并(dsh-subprocess 0.2.0 SubprocessSpawnRequest.env,本次实测确认);
      // per-spawn spec 携带、绝不写 process.env——降级注入对插件进程环境零残留
      ...(env !== undefined ? { env } : {}),
    })
    // 超时语义(回执/轨迹卫生,BrowserSkill 0.4.2 同款措辞「cancel + 有界清理」):
    // AbortSignal.timeout 到点 = 取消执行;清理**必须有界**——seam 若如实响应信号,h.done
    // 很快落定(被杀的子进程带部分输出正常返回);若 seam 未响应(旧宿主/悬挂进程),最多再等
    // cleanupGraceMs 就放弃等待并给 typed 超时信封(exit 124=GNU timeout 惯例),绝不无限
    // await。被弃置的子进程由 OS/seam 兜底回收,插件侧不再跟进——清理无限期 = 把调度线程也
    // 赔进去(v2ex fetch failed 重试链单次 11s+,无人值守一天几十次,等待必须收敛)。
    // 只有计时器胜出才算超时(唯一哨兵,不与 done 的任何落定值混淆);h.done 自身 reject 照常
    // 上抛——seam 冷启动竞态的抛错要交给 runOpencliUngoverned 重试 seam/回落 shell,语义不变。
    const TIMED_OUT = Symbol('timed-out')
    const grace = OpencliService.cleanupGraceMs()
    let timer: ReturnType<typeof setTimeout> | undefined
    const bounded = new Promise<typeof TIMED_OUT>((res) => { timer = setTimeout(() => res(TIMED_OUT), timeoutMs + grace); timer.unref?.() })
    let raced: Awaited<typeof h.done> | typeof TIMED_OUT
    try {
      raced = await Promise.race([h.done, bounded])
    } finally {
      if (timer !== undefined) clearTimeout(timer)
    }
    if (raced === TIMED_OUT) {
      return { exitCode: 124, stdout: '', stderr: `超时取消(cancel + bounded cleanup):${timeoutMs}ms 到点取消执行,宽限 ${grace}ms 内子进程未退出,插件侧停止等待(子进程由 OS/seam 兜底回收;GNU timeout 惯例 exit 124)` }
    }
    const outcome = raced
    const read = async (r: { readFrom: (o: number) => Promise<{ text?: string }> } | undefined): Promise<string> => {
      try { return String((await r?.readFrom(0))?.text ?? '') } catch { return '' }
    }
    return {
      exitCode: typeof outcome?.exitCode === 'number' ? outcome.exitCode : 1,
      stdout: await read(h.collected?.stdout),
      stderr: await read(h.collected?.stderr),
    }
  }

  private async runOpencli(argv: string[], timeoutMs = 60000, stdoutMaxBytes = 1048576, env?: Record<string, string>, kind: 'read' | 'write' = 'read'): Promise<{ exitCode: number; stdout: string; stderr: string; unavailable?: string }> {
    const raw = await this.runOpencliRaw(argv, timeoutMs, stdoutMaxBytes, env, kind)
    return this.unwrapCli2(argv, raw)
  }

  /** opencli 2.0 JSON 信封解包:`{"ok":true,"data":…}` → data 为 stdout;`{"ok":false,"error":{code,message,hint}}`
   *  → stderr + 真实退出码。只认输出形状不看版本号(托盘复活旧 daemon 等版本错配场景照样工作);
   *  list/daemon 两族有专用解析(分页/JSON 状态),在此跳过。1.x 文本输出无 `{"ok":` 前缀,原样透传。 */
  private unwrapCli2(argv: string[], out: { exitCode: number; stdout: string; stderr: string; unavailable?: string }): { exitCode: number; stdout: string; stderr: string; unavailable?: string } {
    if (out.unavailable !== undefined) return out
    if (argv[0] === 'list' || argv[0] === 'daemon') return out
    const s = out.stdout.trimStart()
    if (!s.startsWith('{"ok"')) return out
    const j = extractJsonObject(s) as { ok?: boolean; data?: unknown; error?: Record<string, unknown> } | null
    if (j === null || typeof j.ok !== 'boolean') return out
    if (j.ok === true) {
      const d = j.data
      return { ...out, exitCode: 0, stdout: typeof d === 'string' ? d : (d === undefined ? '' : JSON.stringify(d, null, 2)) }
    }
    const e = j.error ?? {}
    const parts = [typeof e.code === 'string' ? e.code : 'UNKNOWN', typeof e.message === 'string' ? e.message : '', typeof e.hint === 'string' ? e.hint : ''].filter((x) => x.length > 0)
    return { ...out, exitCode: typeof e.exitCode === 'number' ? e.exitCode : 1, stdout: '', stderr: parts.join('\n') }
  }

  /** CLI 大版本(1/2),仅成功探测才缓存。决定 browser 会话语法与 adapter 命令族路由。 */
  private cliMajorCache: number | null = null
  private async cliMajor(): Promise<number> {
    if (this.cliMajorCache !== null) return this.cliMajorCache
    // 探测失败(抛错/非零退出/认不出版本号)只回落默认 1,绝不落缓存(仓库 #1 issue:
    // daemon 冷启动或二进制一时不可用时失败值被永久缓存,此后 2.x 宿主的站目录与
    // 命令族路由恒按 1.x 判且无法自愈)。保持 null 让下次调用重试,环境恢复即拿到真实大版本。
    // 探测走 runOpencliUngoverned:--version 是本机探针不是站点命令,不吃 750ms 级礼貌限流
    // (与 extensionState 的 daemon status 探测同款约定)——否则失败不缓存后每次 cliMajor 都
    // 多付一跳限流间隔,写命令证据链(前后各一次 captureEvidenceShot)把它翻倍,实测把
    // cards.test.ts 的 site execute 端到端用例拖过 5s 超时。
    try {
      const r = await this.runOpencliUngoverned(['--version'], 15000)
      const m = r.exitCode === 0 ? `${r.stdout}\n${r.stderr}`.match(/(\d+)\.\d+/) : null
      if (m !== null) this.cliMajorCache = Number(m[1])
    } catch { /* 探测失败同样不缓存,下次调用重试 */ }
    return this.cliMajorCache ?? 1
  }

  /** CLI 不可用文案(#1 issue):区分「找不到二进制」(resolveBin 各路径未命中、回落裸名
   *  仍失败)与「找到了但 --version 失败」(bin 已定位到具体路径,是执行层问题)——两种
   *  结局的下一步动作不同(装 CLI vs 查执行环境),混写一句会误导排障:mise/版本管理器
   *  用户被指去 npm i -g,装完照样失败,真实原因是路径悬空或 daemon 残留。 */
  private cliUnavailableText(detail: string): string {
    const d = detail.trim().length > 0 ? ` | 详情:${detail.trim()}` : ''
    return this.bin === 'opencli'
      ? `未找到 opencli 二进制:本地依赖/npm 全局/nvm/vfox/mise 探测与 PATH 裸名均失败。安装:npm i -g @jackwener/opencli${d}`
      : `opencli 已定位(${this.bin})但 --version 执行失败,不是"未安装"——常见:node 版本切换后路径悬空/daemon 残留${d}`
  }

  private async runOpencliRaw(argv: string[], timeoutMs = 60000, stdoutMaxBytes = 1048576, env?: Record<string, string>, kind: 'read' | 'write' = 'read'): Promise<{ exitCode: number; stdout: string; stderr: string; unavailable?: string }> {
    await this.acquireGovernor(kind)
    try {
      return await this.runOpencliUngoverned(argv, timeoutMs, stdoutMaxBytes, env)
    } catch (e) {
      // 沙箱不可用（家目录启动 dsh web 时 ACL temp ⊂ workspace 必然触发）:
      // 降级为"无可用 opencli"，绝不让插件初始化把整个 dsh web 拖死
      const msg = e instanceof Error ? e.message : String(e)
      if (/SandboxUnavailableError|no sandbox backend|ACL restricted-token/i.test(msg)) {
        return { exitCode: -1, stdout: '', stderr: msg.slice(0, 500), unavailable: msg.slice(0, 300) }
      }
      throw e
    } finally {
      this.releaseGovernor(kind)
    }
  }

  /**
   * runOpencliRaw 的无限流内核(执行体拆分):供 daemon status 探测等**本机 RPC**直调,刻意
   * 不吃 site 命令的礼貌限流、也不经 this.runOpencli——两条都是零配置降级实测换来的:
   * ①限流间隔(750ms 级)会挂进命令热路径,紧时限用例(tests/trace.test.ts 的 browser 三连,
   * 原本 ~4.5s/5s)被探测多付的一跳顶爆超时;②runOpencli 实例方法在测试与生产包装层常被覆写,
   * 探测调用混进去会污染调用方对 argv 的记账(tests/cli2.test.ts 的 runOpencli 覆写捕获栽过)。
   * 站点命令一律走 runOpencli/runOpencliRaw,别用这个。
   */
  private async runOpencliUngoverned(argv: string[], timeoutMs: number, stdoutMaxBytes: number, env?: Record<string, string>): Promise<{ exitCode: number; stdout: string; stderr: string; unavailable?: string }> {
    // 0.2.0+ 原生 seam 优先。防线:seam 冷启动有竞态(真机实测:daemon 刚起时首几条
    // 抛 'reading includes'/'destructure policy',几分钟后自愈;而 0.1.x shell 回落
    // 在 0.2.1 宿主上会截断 argv——'xiaohongshu' 变 'xiaohong')。所以 seam 抛错先
    // 重试 seam(400ms×2),三败才回落 shell。
    let viaSub: Awaited<ReturnType<OpencliService['runSubprocess']>> = null
    for (let attempt = 0; attempt < 3 && viaSub === null; attempt++) {
      try {
        viaSub = await this.runSubprocess(argv, timeoutMs, stdoutMaxBytes, env)
      } catch {
        if (attempt < 2) await new Promise((res) => setTimeout(res, 400))
      }
    }
    if (viaSub !== null) {
      this.noteRateLimit(`${viaSub.stdout}\n${viaSub.stderr}`)
      return viaSub
    }
    // 回落:0.1.x 的 ctx.shell 多形态(run/execute × resolve/直传/argv)
    const shellAny = this.ctx.shell as any
    const runner = typeof shellAny.run === 'function' ? shellAny.run.bind(shellAny) : (typeof shellAny.execute === 'function' ? shellAny.execute.bind(shellAny) : null)
    if (runner === null) return { exitCode: 1, stdout: '', stderr: 'dsh shell 能力不可用(既无 run 也无 execute)' }
    // 0.2.0 起 spec 必须携带沙箱策略(否则 shell 内部 destructure policy.mode 直接抛错);
    // 插件是可信进程内消费者,用 danger-full-access(与 0.1.x 无沙箱行为一致);老版本忽略多余字段。
    const policy = { mode: 'danger-full-access' as const, workspaceRoot: homedir() }
    // env 同样进 shell 回落 spec(零配置路由矩阵 ②:回落路径也要带 env,两处都注)——
    // dsh-shell ShellExecRequest.env 与凭据擦净后的环境合并(0.2.0 types.d.ts 实测确认),老版本忽略多余字段
    // 字符串形态逐参数转义(quoteShellArg):argv 是模型可控输入,裸 join(' ') 可被空白/引号
    // 碎裂注入(0.1.2 发后审查发现 2);数组形态(command 传 argv)不经 shell 解析,零注入面
    const argvAll = [this.bin, ...argv]
    const baseSpec = { command: argvAll.map(OpencliService.quoteShellArg).join(' '), timeoutMs, stdoutMaxBytes, policy, ...(env !== undefined ? { env } : {}) }
    const argvSpec = { ...baseSpec, command: argvAll, policy }
    // 数组形态优先(0.1.2 发后审查发现 2):两形态宿主都认时锁定 array,与 opencli_run
    // 「argv 数组、不拼 shell」的描述对齐;只认字符串的 0.1.x 宿主回落转义后的字符串形态
    const attempts: Array<'resolved' | 'direct' | 'array'> = this.shellMode !== null ? [this.shellMode] : ['array', 'resolved', 'direct']
    let out: { exitCode: number; stdout: string; stderr: string } = { exitCode: 1, stdout: '', stderr: '' }
    for (const mode of attempts) {
      let spec: unknown
      let threw = false
      try {
        spec = mode === 'resolved' ? (typeof shellAny.resolve === 'function' ? shellAny.resolve({ ...baseSpec } as ShellExecRequest) : baseSpec)
          : mode === 'direct' ? baseSpec
          : argvSpec
        const raw = await runner(spec)
        // 归一化:0.1.5 流式 {text} 与字符串形态统一为纯文本,维持下游契约
        const asText = (x: unknown): string => {
          if (x && typeof x === 'object' && typeof (x as { text?: unknown }).text === 'string') return (x as { text: string }).text
          return typeof x === 'string' ? x : ''
        }
        out = {
          exitCode: typeof raw?.exitCode === 'number' ? raw.exitCode : 1,
          stdout: asText(raw?.stdout),
          stderr: asText(raw?.stderr),
        }
      } catch (e) {
        threw = true
        out = { exitCode: 1, stdout: '', stderr: e instanceof Error ? e.message : String(e) }
      }
      // 形态判定:调用于抛错且(有输出或退出码 0)才锁定该形态;
      // 抛错一律换下一形态(异常文本不是真实 stderr,不能当有效输出)
      if (!threw && (out.stdout.length > 0 || out.stderr.length > 0 || out.exitCode === 0)) {
        this.shellMode = mode
        break
      }
    }
    this.noteRateLimit(`${out.stdout}\n${out.stderr}`)
    return out
  }

  /**
   * shell 字符串形态的单参数转义:安全字符集(无空白、无 shell 元字符)直通,其余整体
   * 双引号并转义 " \ $ `(POSIX sh 双引号语义)。只是字符串形态的防线——数组形态不经
   * shell 解析,才是与「不拼 shell」对齐的正道;Windows 宿主 cmd 的引号规则不同,转义
   * 是近似兜底而非等价,这也是数组形态优先的原因。
   */
  private static quoteShellArg(s: string): string {
    return /^[A-Za-z0-9_@%+=:,./-]+$/.test(s) ? s : `"${s.replace(/[\\"$`]/g, '\\$&')}"`
  }

  private renderOut(out: { exitCode: number; stdout: string; stderr: string }): string {
    if (out.exitCode === 0) return clip(out.stdout, OUTPUT_LIMIT)
    return `命令失败(退出码 ${out.exitCode}):\n${clip(out.stdout, 2000)}\n${clip(out.stderr, 2000)}`
  }

  // ── 轨迹回放:browser 命令运行轨迹(BrowserSkill #79 同款需求) ──

  /** 轨迹文件日期键(本地日期 yyyymmdd,recordTrace 写入与 trace-list/get 读取共用同一把尺)。 */
  private static traceDateKey(d = new Date()): string {
    return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`
  }

  /**
   * 轨迹时间列:at 是 UTC ISO,直接 slice(11,19) 显示会与用户本地时钟错位(东八区差 8h,
   * 凌晨命令对不上体感)——转本地 HH:MM:SS,与 traceDateKey 的本地分档同一时区体感。
   * 非法时间原样回退(形状校验后仍可能是垃圾字符串)。
   */
  private static traceClock(at: string): string {
    const d = new Date(at)
    if (Number.isNaN(d.getTime())) return at.slice(11, 19)
    const p = (n: number): string => String(n).padStart(2, '0')
    return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
  }

  private traceFileOf(dateKey: string, rotated = false): string {
    return join(this.traceDir, `trace-${dateKey}.jsonl${rotated ? '.1' : ''}`)
  }

  /**
   * browser 透传统一入口:runOpencli + recordTrace。opencli_* 工具族(registerBrowserTools 的 run())
   * 与 replay / script-run-builtin / crawl / userscript-run / recipe-run 五个 RPC 透传都经此——
   * 任何入口执行的 browser 命令都进「运行轨迹」,复盘链路不断(评审:面板回放按钮曾绕过单点)。
   */
  /** 直连页面身份缓存:session → targetId。响应顶层 page 持续刷新;stale 类错误清缓存。
   *  有界化:会话名不可枚举(ephemeral/多会话),常驻进程按插入序
   *  裁最旧,上限对齐 direct-compose 的会话级缓存。 */
  private directPages = new Map<string, string>()
  private static readonly DIRECT_PAGE_CAP = 200

  /** 页面身份写入(有界):超限裁最旧插入的会话;delete/stale 清理路径不经此。 */
  private setDirectPage(sess: string, page: string): void {
    this.directPages.set(sess, page)
    if (this.directPages.size > OpencliService.DIRECT_PAGE_CAP) {
      const oldest = this.directPages.keys().next()
      if (!oldest.done) this.directPages.delete(oldest.value)
    }
  }
  /** 直连总闸(DSH_OPENCLI_DIRECT=0 关):旁路加速的逃生口——组合层在某宿主异常时可整体回 CLI。 */
  private readonly directEnabled = process.env.DSH_OPENCLI_DIRECT !== '0'

  /**
   * eval 族直连执行(0.4.6 A2):走 daemon /command 母语(direct.ts),成功/结构化失败都归一成
   * CLI 2.0 信封形状({ok,data}/{ok:false,error:{code,message,hint}})返回给 runBrowserTraced——
   * 下游解析零改动;返回 undefined=本次不可用(未探测/网络失败/协议禁用),调用方回落 CLI。
   * 页面身份:优先回传缓存 targetId;响应刷新缓存;page_not_found/stale 类错误清缓存后**不带
   * page 重试一次**(让 daemon 重新解析会话绑定的活页),仍失败则交回落。
   */
  private async evalDirect(session: string | undefined, code: string): Promise<{ exitCode: number; stdout: string; stderr: string } | undefined> {
    const sess = session ?? 'dsh'
    try {
      if (directCapability() === 'off') return undefined
      if (directCapability() === 'unknown' && !(await directProbe())) return undefined
      let r = await directExec(sess, code, this.directPages.get(sess))
      if (!r.ok && r.unreachable !== true && /page|stale|not.?found/i.test(String(r.errorCode ?? ''))) {
        this.directPages.delete(sess)
        r = await directExec(sess, code)
      }
      if (!r.ok) return undefined
      if (r.page !== undefined) this.setDirectPage(sess, r.page)
      // 归一 CLI 2.0 信封:eval 的 data 是页面求值原文(string),下游信封解包路径原样可用
      return { exitCode: 0, stdout: JSON.stringify({ ok: true, data: r.data }), stderr: '' }
    } catch {
      return undefined
    }
  }

  /**
   * 直连分派(0.4.7 A:直连铺满):把 runBrowserTraced 的 argv 路由到 direct-compose 组合层。
   * 每个子命令先过旗标守卫(语义定位/annotate/ax 等组合层不覆盖的面 → undefined → CLI),
   * compose 成功后按上游语义维护 directPages 页面身份缓存(new/select 回传 page、close 比对
   * 清缓存、close-window 释放租约清缓存——与上游 page.js _page 字段同款流转)。
   * 纪律:任何不确定的 argv 形状都返回 undefined 走 CLI;绝不猜。
   */
  private async directForArgv(session: string | undefined, argv: string[]): Promise<CliEnvelope | undefined> {
    const head = String(argv[0] ?? '')
    const sess = session ?? 'dsh'
    const cachedPage = this.directPages.get(sess)
    const refresh = (page?: string): void => { if (typeof page === 'string' && page.length > 0) this.setDirectPage(sess, page) }
    try {
      switch (head) {
        case 'open': {
          // CLI 形状:open <url>(无旗标面;网络捕获/等待语义在 composeOpen 内)
          const url = String(argv[1] ?? '')
          if (url.length === 0 || url.startsWith('--') || argv.length > 2) return undefined
          const r = await composeOpen(sess, url, cachedPage)
          if (r === undefined) return undefined
          refresh(r.pageId)
          return r.env
        }
        case 'scroll': {
          // CLI 形状:scroll <up|down> [--amount <n>]
          const dir = String(argv[1] ?? '')
          let amount: number | undefined
          for (let i = 2; i < argv.length; i++) {
            if (argv[i] === '--amount' && /^\d+$/.test(String(argv[i + 1] ?? ''))) { amount = Number(argv[i + 1]); i++ } else return undefined
          }
          const env = await composeScroll(sess, dir, amount, cachedPage)
          if (env !== undefined) refresh(cachedPage)
          return env
        }
        case 'state': {
          // 只覆盖 dom 默认路径;--source ax / --diagnostics / --compare-sources 留给 CLI
          let ax = false
          for (let i = 1; i < argv.length; i++) {
            if (argv[i] === '--source' && String(argv[i + 1] ?? '') === 'ax') ax = true
            else if (argv[i] === '--source' && String(argv[i + 1] ?? '') === 'dom') { /* 默认路径 */ }
            else if (argv[i] === '--diagnostics' || argv[i] === '--compare-sources') return undefined
            else return undefined
          }
          if (ax) return undefined
          const env = await composeState(sess, cachedPage)
          if (env !== undefined) refresh(cachedPage)
          return env
        }
        case 'click': {
          // CLI 形状:click <target> [--nth <n>];语义定位旗标(--role/--name/…)不在本层
          const target = String(argv[1] ?? '')
          if (target.length === 0 || target.startsWith('--')) return undefined
          let nth: number | undefined
          for (let i = 2; i < argv.length; i++) {
            if (argv[i] === '--nth' && /^\d+$/.test(String(argv[i + 1] ?? ''))) { nth = Number(argv[i + 1]); i++ } else return undefined
          }
          const env = await composeClick(sess, target, nth, cachedPage)
          if (env !== undefined) refresh(cachedPage)
          return env
        }
        case 'screenshot': {
          // CLI 形状:screenshot [path] [--full-page];annotate/尺寸覆盖留给 CLI(扩展 annotatedScreenshot)
          let path: string | undefined
          let fullPage = false
          for (let i = 1; i < argv.length; i++) {
            if (argv[i] === '--full-page') fullPage = true
            else if (argv[i] === '--annotate' || argv[i] === '--width' || argv[i] === '--height') return undefined
            else if (!String(argv[i]).startsWith('--') && path === undefined) path = String(argv[i])
            else return undefined
          }
          const shot = await composeScreenshot(sess, cachedPage, { fullPage })
          if (shot === undefined) return undefined
          refresh(cachedPage)
          if (path !== undefined) {
            try { await writeFile(path, Buffer.from(shot.base64, 'base64')) } catch { return undefined }
            return { exitCode: 0, stdout: JSON.stringify({ ok: true, data: `Screenshot saved to: ${path}` }), stderr: '' }
          }
          return shot.env
        }
        case 'tab': {
          // CLI 形状:tab list / tab new [url] / tab select <target>|--tab <id> / tab close [target]|--tab <id>
          const op = String(argv[1] ?? '')
          const rest = argv.slice(2)
          let pos: string | undefined
          let tabFlag: string | undefined
          for (let i = 0; i < rest.length; i++) {
            if (rest[i] === '--tab' && typeof rest[i + 1] === 'string') { tabFlag = String(rest[i + 1]); i++ }
            else if (!String(rest[i]).startsWith('--') && pos === undefined) pos = String(rest[i])
            else return undefined
          }
          const target = tabFlag ?? pos
          if (op === 'list') {
            if (rest.length > 0) return undefined
            const r = await composeTabs(sess, 'list', {}, cachedPage)
            if (r === undefined) return undefined
            return r.env
          }
          if (op === 'new') {
            if (rest.length > 1) return undefined
            const r = await composeTabs(sess, 'new', pos !== undefined ? { url: pos } : {}, cachedPage)
            if (r === undefined) return undefined
            refresh(r.pageId)
            return r.env
          }
          if (op === 'select') {
            if (target === undefined) return undefined
            const idx = /^\d+$/.test(target) ? Number(target) : undefined
            const r = await composeTabs(sess, 'select', idx !== undefined ? { index: idx } : { page: target }, cachedPage)
            if (r === undefined) return undefined
            refresh(r.pageId)
            return r.env
          }
          if (op === 'close') {
            const idx = target !== undefined && /^\d+$/.test(target) ? Number(target) : undefined
            const r = await composeTabs(sess, 'close', idx !== undefined ? { index: idx } : target !== undefined ? { page: target } : {}, cachedPage)
            if (r === undefined) return undefined
            // 上游 closeTab 语义:确认关闭的是当前缓存页时清缓存,下条命令重解析活页
            if ((r.closedPage !== undefined && r.closedPage === cachedPage) || (r.closedPage === undefined && target === cachedPage)) this.directPages.delete(sess)
            return r.env
          }
          return undefined
        }
        case 'close': {
          if (argv.length > 1) return undefined
          const env = await composeCloseWindow(sess, cachedPage)
          if (env !== undefined) this.directPages.delete(sess)
          return env
        }
        default:
          return undefined
      }
    } catch {
      return undefined
    }
  }

  private async runBrowserTraced(session: string | undefined, argv: string[], opts?: { deriveShot?: (out: { exitCode: number; stdout: string; stderr: string }) => Promise<string | undefined> }): Promise<{ exitCode: number; stdout: string; stderr: string; shot?: string }> {
    const started = Date.now()
    // ④ 无扩展短路(零配置路由矩阵 ④):opencli_* 是 CLI→daemon→扩展硬链路(上游 daemon.js 头注释,
    // 无 CDP 分支),daemon 明确报告扩展未连时注定失败——把注定失败的往返(默认 60s 超时)换成
    // 一次性"缺什么/装什么/装完会怎样"。只认显式未连(extensionState.explicitDown):
    // daemon 运行但不上报 Extension 字段的旧形态仍按现状放行,缺字段≠否定
    if ((await this.extensionState()).explicitDown) {
      const out = { exitCode: 1, stdout: '', stderr: NO_EXT_GUIDANCE }
      this.recordTrace(`browser ${session ?? 'dsh'} ${argv.join(' ')} [no-ext]`, out, 0)
      return out
    }
    const major = await this.cliMajor()
    let out: { exitCode: number; stdout: string; stderr: string }
    // 0.4.6 A2 + 0.4.7 A(直连铺满):eval 为 daemon 真动作直连(~135ms 级 vs CLI ~1.1s);
    // scroll/state/screenshot/tab/close 为 1:1 或组合直连(direct-compose.ts,构造器运行时
    // 装载自本机 CLI dist)——成功路径归一 CLI 2.0 信封,任何失败/不适用静默回落 CLI 路径
    // (旁路加速纪律:直连永不成为单点故障,失败信封永远出自 CLI 权威出口)
    if (argv[0] === 'eval') {
      if (this.directEnabled) {
        const direct = await this.evalDirect(session, argv[1] ?? '')
        if (direct !== undefined) out = direct
      }
    } else if (major >= 2 && this.directEnabled) {
      out = await this.directForArgv(session, argv)
    }
    if (out === undefined) {
      if (major >= 2) {
      // 2.0:会话从位置参数改为 --session 选项;创作命令搬去 adapter 族(analyze 工作流整体移除)
      const [head] = argv
      if (head === 'init' || head === 'verify') {
        const sub = head === 'verify' ? 'check' : 'init'
        out = await this.runOpencli(['adapter', sub, ...argv.slice(1)])
      } else if (head === 'analyze') {
        out = { exitCode: 1, stdout: '', stderr: 'opencli 2.0 已移除 analyze 侦察工作流;改用 browser state --diagnostics / browser network --static,或 adapter init 后 adapter check 验证' }
      } else {
        out = await this.runOpencli(['browser', ...argv, '--session', session ?? 'dsh'])
      }
    } else {
      out = await this.runOpencli(['browser', session ?? 'dsh', ...argv])
    }
    }
    // 派生截图优先(canvas_read 的画布位图):输出本身就是证据时不必再拍整页——agent 看到
    // 的位图正是复盘素材;派生不适用/失败(undefined)回落 captureStepShot(页面变化/失败
    // 补拍,走 runOpencli 直连不经本函数——否则自递归且把补拍当用户步骤污染轨迹),两链路互不挡道
    const derived = opts?.deriveShot !== undefined ? await opts.deriveShot(out) : undefined
    const shot = derived ?? await this.captureStepShot(session, argv, out, major)
    this.recordTrace(`browser ${session ?? 'dsh'} ${argv.join(' ')}`, out, Date.now() - started, shot)
    // shot 随结果带出(独立评审发现:此前只进 trace 不进工具结果,opencli_do 卡的
    // (shot: 文件名) 提示是死路径)——undefined 不落字段,老消费者零影响
    return shot !== undefined ? { ...out, shot } : out
  }

  /** 截图文件名时间段(本地 hhmmss,无冒号——文件系统安全;与 traceDateKey 同一时区体感,回放时对得上墙钟)。 */
  private static shotClock(d = new Date()): string {
    const p = (n: number): string => String(n).padStart(2, '0')
    return `${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`
  }

  /**
   * 步骤自动截图:页面变化类子命令(SHOT_TRIGGER_SUBS)或任何失败命令执行后补拍一张,落
   * <shotsDir>/<yyyymmdd>/<session>/step-<hhmmss>-<idx>.png。任何失败(建目录/CLI 报错/文件没落盘)
   * 一律静默返回 undefined——截图只是复盘增强,绝不阻断命令本身;CLI 已确认文件写出后才计入轨迹行,
   * 杜绝 shot 字段指向不存在文件的悬空引用。
   * force(证据包专用):写命令的 before/after 必拍——证据链完整性优先于截图频率,
   * 绕过"页面变化才拍"触发门限。
   */
  private async captureStepShot(session: string | undefined, argv: string[], out: { exitCode: number; stdout: string; stderr: string; unavailable?: string }, major: number, force = false): Promise<string | undefined> {
    if (!this.shotCapture) return undefined
    const sub = String(argv[0] ?? '')
    if (!force && out.exitCode === 0 && !SHOT_TRIGGER_SUBS.has(sub)) return undefined
    // 沙箱不可用时 shell 已整体报废,再发截图命令只是多等一次注定失败的调用
    if (out.unavailable !== undefined) return undefined
    try {
      // 会话名进目录段:剥离路径字符,防会话名本身成为穿越载体
      const sid = (session ?? 'dsh').replace(/[^\w.-]/g, '_')
      const now = new Date()
      const dir = join(this.shotsDir, OpencliService.traceDateKey(now), sid)
      mkdirSync(dir, { recursive: true })
      // 防碰撞:hhmmss + 进程内单调 idx;跨进程/重启序列归零由 existsSync 续拨
      const clock = OpencliService.shotClock(now)
      let file = ''
      do { file = join(dir, `step-${clock}-${++this.shotSeq}.png`) } while (existsSync(file))
      // 0.4.7 A:截图走直连(daemon screenshot 返回 base64 直接落盘,免 CLI 冷启动)——
      // 步骤截图是每条轨迹都付的热路径;直连不适用/失败回落下方 CLI 形态(跨大版本分支保留)
      if (major >= 2 && this.directEnabled) {
        try {
          const shot = await composeScreenshot(session ?? 'dsh', this.directPages.get(session ?? 'dsh'), {})
          if (shot !== undefined) {
            await writeFile(file, Buffer.from(shot.base64, 'base64'))
            if (existsSync(file)) return file
          }
        } catch { /* 回落 CLI */ }
      }
      // 截图命令形态跨大版本(实探 2.0.0 help:browser screenshot <path> --session <s>;1.x 为位置参数)
      const shotArgv = major >= 2
        ? ['browser', 'screenshot', file, '--session', session ?? 'dsh']
        : ['browser', session ?? 'dsh', 'screenshot', file]
      const r = await this.runOpencli(shotArgv, 30_000)
      return r.exitCode === 0 && existsSync(file) ? file : undefined
    } catch {
      return undefined
    }
  }

  /**
   * canvas_read 产出落盘(消除断点):eval 出口(2.0 双层信封或 1.x 裸文)里的 {index,w,h,b64}
   * 解码成 PNG 写进当日截图目录,路径回传挂进轨迹行 shot 字段——画布卡片即自动以图片步骤
   * 回放"agent 在画布里看到了什么"(此前 b64 只以截断文本躺在轨迹行里,人无法复核)。
   * 只读旁路:任何失败(exit≠0/无 b64/PNG 魔数不符/超 8MB/写盘错)静默 undefined,
   * 回落 captureStepShot 常规链路;上限与 trace-shot 的 8MB 同口径,画布读取不许变成
   * RPC 通道炸弹。命名 canvas-<hhmmss>-<seq>-i<idx>.png 与 step-*.png 同目录同防碰撞。
   */
  private async saveCanvasReadShot(session: string | undefined, idx: number, out: { exitCode: number; stdout: string }): Promise<string | undefined> {
    if (out.exitCode !== 0) return undefined
    const outer = extractJsonObject(out.stdout) as { data?: unknown } | null
    // 2.0 信封 {"ok":true,"data":"<内层 JSON 字符串>"} 再剥一层;1.x 裸文 outer 即结果
    const parsed = (outer !== null && typeof outer.data === 'string' ? extractJsonObject(outer.data) : outer) as { b64?: unknown } | null
    if (parsed === null || typeof parsed.b64 !== 'string' || parsed.b64.length < 100) return undefined
    try {
      const buf = Buffer.from(parsed.b64, 'base64')
      // PNG 魔数 89 50 4E 47:脏 base64/错误页返回不落盘(长度下限同护 "太短必不是图")
      if (buf.length < 8 || buf[0] !== 0x89 || buf[1] !== 0x50 || buf[2] !== 0x4e || buf[3] !== 0x47) return undefined
      if (buf.length > 8 * 1024 * 1024) return undefined
      const sid = (session ?? 'dsh').replace(/[^\w.-]/g, '_')
      const now = new Date()
      const dir = join(this.shotsDir, OpencliService.traceDateKey(now), sid)
      await mkdir(dir, { recursive: true })
      const clock = OpencliService.shotClock(now)
      let file = ''
      do { file = join(dir, `canvas-${clock}-${++this.shotSeq}-i${idx}.png`) } while (existsSync(file))
      await writeFile(file, buf)
      return file
    } catch {
      return undefined
    }
  }

  /**
   * 每条 browser 命令追加一行 JSONL 到 <traceDir>/trace-<yyyymmdd>.jsonl:
   * {at, cmd, exitCode, ms, outHead(输出前 200 字,失败时 stderr 优先)}。
   * 同步写(量级 ~300B/条,相对秒级浏览器操作可忽略,且对调用方可确定性断言);
   * 单文件超 5MB 轮转为 .1(旧 .1 丢弃,保留前一份);任何失败静默,绝不影响命令本身。
   * 留存预算(回执/轨迹卫生,chrome-devtools-mcp --maxNavigationSaved 同款滚动淘汰):
   * trace-*.jsonl(+各档 .1)最多 TRACE_KEEP_FILES 份,超出按文件名(日期)序删最旧——
   * 只在**新建当日文件**时执行一次(热路径零开销;DSH_OPENCLI_TRACE_KEEP_FILES 可调,5-365)。
   * cmd 与 outHead 过 URL 参数脱敏(回执/轨迹卫生):登录态链接 ?token=/?code= 落盘即洗,
   * 复制轨迹贴 issue/聊天不再泄凭据。
   */
  private recordTrace(cmd: string, out: { exitCode: number; stdout: string; stderr: string }, ms: number, shot?: string): void {
    try {
      try { mkdirSync(this.traceDir, { recursive: true }) } catch { return }
      const dateKey = OpencliService.traceDateKey()
      const file = this.traceFileOf(dateKey)
      let freshFile = false
      try {
        statSync(file)
      } catch { freshFile = true /* 当日首条 */ }
      try {
        if (statSync(file).size > 5 * 1024 * 1024) {
          try { unlinkSync(`${file}.1`) } catch { /* 无旧档 */ }
          renameSync(file, `${file}.1`)
        }
      } catch { /* 文件不存在(当日首条)或轮转失败:照常追加 */ }
      const outHead = (out.exitCode === 0 ? out.stdout : `${out.stderr}\n${out.stdout}`.trim()).slice(0, 200)
      // shot 为可选字段:老轨迹行没有它,消费端(readTraceFile/面板)一律按可选透传
      const row = { at: new Date().toISOString(), cmd: scrubUrlParams(cmd), exitCode: out.exitCode, ms, outHead: scrubUrlParams(outHead), ...(shot !== undefined && shot.length > 0 ? { shot } : {}) }
      appendFileSync(file, `${JSON.stringify(row)}\n`, 'utf8')
      // 淘汰放在追加之后:当日新档已落盘、按文件名(日期)序是最新一份,计入预算(否则多留 1 份)
      if (freshFile) this.pruneTraceFiles()
    } catch { /* 静默:轨迹缺失不阻断命令 */ }
  }

  /** 轨迹文件留存上限(份,含每日档与轮转档;env DSH_OPENCLI_TRACE_KEEP_FILES 可调,钳 5-365)。 */
  private traceKeepFiles(): number {
    const raw = Number(process.env.DSH_OPENCLI_TRACE_KEEP_FILES)
    return Number.isFinite(raw) && raw >= 5 ? Math.min(Math.round(raw), 365) : 30
  }

  /** 轨迹滚动淘汰:trace-*.jsonl(+.1)超上限时按文件名(日期)序删最旧;任何失败静默。 */
  private pruneTraceFiles(): void {
    try {
      const keep = this.traceKeepFiles()
      const files = readdirSync(this.traceDir).filter((f) => /^trace-\d{8}\.jsonl(\.1)?$/.test(f)).sort()
      if (files.length <= keep) return
      for (const f of files.slice(0, files.length - keep)) { try { unlinkSync(join(this.traceDir, f)) } catch { /* ignore */ } }
    } catch { /* 静默:淘汰失败不影响记录 */ }
  }

  /** 解析一个轨迹文件为行数组(缺文件/JSON 解析失败/**形状不对**的脏行一律跳过,不抛错)。 */
  private readTraceFile(file: string): ShotTraceLine[] {
    const lines: ShotTraceLine[] = []
    let text = ''
    try { text = readFileSync(file, 'utf8') } catch { return lines }
    for (const line of text.split('\n')) {
      if (line.trim().length === 0) continue
      try {
        const v = JSON.parse(line) as unknown
        // 形状校验:'null'/'数字'/'{"exitCode":0}' 这类 parse 成功但非 TraceLine 的行,
        // 会让消费端 at.slice 直接 TypeError 且 client 无 ErrorBoundary——整卡崩白(评审)。
        if (v === null || typeof v !== 'object'
          || typeof (v as ShotTraceLine).at !== 'string' || typeof (v as ShotTraceLine).cmd !== 'string'
          || typeof (v as ShotTraceLine).exitCode !== 'number' || typeof (v as ShotTraceLine).ms !== 'number'
          || typeof (v as ShotTraceLine).outHead !== 'string') continue
        const t = v as ShotTraceLine
        // shot 可选但出现即必须是字符串:脏形态剥掉字段保住整行,不让悬空引用进面板
        if (t.shot !== undefined && typeof t.shot !== 'string') delete t.shot
        lines.push(t)
      } catch { /* 脏行跳过 */ }
    }
    return lines
  }

  /** trace_replay 的 markdown 时间线(新→旧):时间/命令/exit/耗时,失败步附输出摘录。
   *  #59 补完:装饰性步骤(scroll/hover——只改 CSS/视觉状态、不读写数据)在命令列前标
   *  〔装饰〕,复盘时一眼分出"像人的动作"与真正的数据步骤;回放 RPC 可凭 skipDecorative 整体跳过。 */
  private async renderTraceTimeline(limit: number): Promise<string> {
    const r = await this.traceList({ limit })
    if (!r.ok || r.traces.length === 0) return '暂无运行轨迹(还没有 browser 命令执行记录)。跑一条 opencli_* 后再来看。'
    // 单元格净化:换行折为可见 \n 标记(userscript eval 等多行 cmd 会把表格行拆断),
    // 空白折叠为单格,竖线转义;命令不再用反引号包裹——载荷内嵌 ` 也不会截断 code span。
    // 轨迹报告同过 URL 参数脱敏(回执/轨迹卫生;老轨迹行写入时尚未脱敏,读侧补洗)
    const esc = (s: string): string => scrubUrlParams(s).replace(/\r?\n/g, '\\n').replace(/\s+/g, ' ').replace(/\|/g, '\\|')
    const deco = r.traces.filter((t) => isDecorativeStep(t.cmd)).length
    const out = [
      `最近 ${r.traces.length} 步 browser 命令(新→旧,exit≠0 为失败${deco > 0 ? `;〔装饰〕=只改视觉的 scroll/hover 步 ${deco} 条,回放可跳过` : ''}):`,
      '',
      '| 时间 | 命令 | exit | 耗时 |',
      '|---|---|---|---|',
      ...r.traces.map((t) => `| ${OpencliService.traceClock(t.at)} | ${isDecorativeStep(t.cmd) ? '〔装饰〕' : ''}${esc(t.cmd.slice(0, 80))} | ${t.exitCode} | ${t.ms}ms |`),
    ]
    const fails = r.traces.filter((t) => t.exitCode !== 0).slice(0, 3)
    if (fails.length > 0) {
      out.push('', '失败步输出摘录(复盘起点):')
      for (const f of fails) out.push(`- [${OpencliService.traceClock(f.at)}] ${esc(f.cmd.slice(0, 60))} → ${esc(f.outHead.slice(0, 120))}`)
    }
    return out.join('\n').slice(0, 4000)
  }

  private async daemonStatus() {
    // 探测走 runOpencliUngoverned(extensionState/cliMajor 同款约定):本机 RPC 不吃 site
    // 限流,也不经会被覆写的 runOpencli;daemonStatus 挂在任务预检热路径上,走 governed 通道
    // 会让每 tick 白付 750ms 级礼貌限流延迟,故此处绕行
    const r = await this.runOpencliUngoverned(['daemon', 'status'], 15_000, 262_144)
    if (r.exitCode !== 0) return null
    return parseDaemonStatus(r.stdout + '\n' + r.stderr)
  }

  private async loadState(): Promise<void> {
    try {
      const text = await readFile(this.statePath, 'utf8')
      const parsed = JSON.parse(text) as Partial<PluginState>
      if (parsed.approval === 'on' || parsed.approval === 'off') this.state.approval = parsed.approval
      if (Array.isArray(parsed.disabled)) this.state.disabled = parsed.disabled.filter((s) => typeof s === 'string')
      if (Array.isArray(parsed.schedules)) this.schedules = parsed.schedules
      if (parsed.runHistory !== undefined && typeof parsed.runHistory === 'object') this.runHistory = parsed.runHistory as typeof this.runHistory
      // 自愈:清除旧版寄生在 runHistory 的调度 marker(键含 ':',曾累积 5055 个)
      for (const k of Object.keys(this.runHistory)) {
        if (k.includes(':')) delete this.runHistory[k]
      }
      if (Array.isArray(parsed.audit)) this.state.audit = parsed.audit.filter((a) => a !== null && typeof a === 'object' && typeof (a as { at?: unknown }).at === 'string')
      // notifyConfig 走 notify.ts 白名单归一:state.json 是用户可手改的文件,坏条目
      // 丢弃而不是抛错(与 schedules/audit 同款容错口径,通知是旁路不能废加载)
      this.state.notifyConfig = normalizeNotifyConfig(parsed.notifyConfig)
    } catch { /* 无文件或损坏:用默认值 */ }
  }

  /** 原子写的临时文件序号(同毫秒并发 saveState 防自撞)。 */
  private stateTmpSeq = 0

  private async saveState(): Promise<void> {
    try {
      await mkdir(join(homedir(), '.dsh'), { recursive: true })
      // 原子写:先写同目录临时文件再 rename——writeFile 是"截断再写",并发读者
      // (tests/benchmark.test.ts 的裸 JSON.parse 回读、面板 settings)会撞见空文件窗口,
      // 全量门禁实测以低概率红(Unexpected end of JSON input);rename 落盘只见旧或新。
      // 并发写者(recordAudit 的 void saveState 与后台调度任务)各写各的 tmp,后 rename 者胜。
      const body = JSON.stringify({ ...this.state, schedules: this.schedules, runHistory: this.runHistory, audit: this.state.audit }, null, 2)
      const tmp = `${this.statePath}.${process.pid}.${Date.now()}.${++this.stateTmpSeq}.tmp`
      await writeFile(tmp, body, 'utf8')
      await rename(tmp, this.statePath)
    } catch { /* 状态写不进(权限等):仅本次会话生效 */ }
  }

  /** 简易 5 段 cron 匹配(分 时 日 月 周;支持 *、数字、星斜步长)。 */
  private cronMatches(cron: string, now: Date): boolean {
    const parts = cron.trim().split(/\s+/)
    if (parts.length !== 5) return false
    const vals = [now.getMinutes(), now.getHours(), now.getDate(), now.getMonth() + 1, now.getDay()]
    const mins = [0, 0, 1, 1, 0]
    const maxs = [59, 23, 31, 12, 6]
    return parts.every((spec, i) => {
      if (spec === '*') return true
      if (spec.startsWith('*/')) {
        const step = Number(spec.slice(2))
        if (!Number.isFinite(step) || step <= 0) return false
        return (vals[i] - mins[i]) % step === 0
      }
      // 修复(模拟使用 Finding 2.1):原实现只校验数字合法,从不与当前时间比较——
      // 任何"数字都在范围内"的 cron(含默认 0 9 * * *)每分钟触发,高频轰炸站点。
      // 逗号列表语义=some(任一字段命中即匹配)
      return spec.split(',').some((tok) => { const n = Number(tok); return Number.isFinite(n) && n >= mins[i] && n <= maxs[i] && n === vals[i] })
    })
  }

  /**
   * 单条意图直接执行(0.4.6 B1,NL 指挥台确认按钮):与收件箱 drain 同一条 applyIntent 路径
   * (同一道闭集校验/同一个执行器桥)——预览卡再怎么改,过不了白名单就执行不了。
   */
  @Remote('inbox-intent')
  async inboxIntent(request: { intent: unknown }): Promise<IntentResult> {
    const intent = parseIntent(request?.intent)
    if (intent === null) return { ok: false, at: new Date().toISOString(), kind: '(invalid)', error: '意图不合法(白名单闭集校验未过)' }
    return await applyIntent(intent, this.inboxExecutor())
  }

  /** 通知测试真实发送(D):面板「测试」按钮与 ctl notify test 共用。 */
  private async notifyTestSend(): Promise<{ ok: boolean; error?: string }> {
    const config = this.state.notifyConfig ?? { channels: [] }
    const channels = buildNotifyChannels(config, { emit: (ev) => this.emitNotifyEvent(ev) })
    if (channels.length === 0) return { ok: false, error: '尚未配置通知通道:先 notify set' }
    const rs = await sendViaChannels(channels, 'dsh-openctl 测试通知', '如果你收到这条,通知通道配置成功。')
    const bad = rs.filter((x) => !x.ok)
    return { ok: bad.length === 0, error: bad.length === 0 ? undefined : bad.map((x) => `${x.name}:${x.error ?? ''}`).join('; ') }
  }
  @Remote('notify-test')
  async notifyTest(): Promise<{ ok: boolean; error?: string }> {
    return await this.notifyTestSend()
  }
  /** 执行器桥(inbox-intent 与收件箱轮询共用;意图 → 既有 RPC 同源方法,一套逻辑两个入口)。 */
  private inboxExecutor(): IntentExecutor {
    return {
      scheduleAdd: async (i) => this.scheduleAdd({ site: i.site, cron: i.cron, ...(i.watch !== undefined ? { watch: i.watch } : {}), ...(i.notify !== undefined ? { notify: i.notify } : {}), ...(i.retry !== undefined ? { retry: i.retry } : {}), ...(i.source !== undefined ? { source: i.source } : {}), ...(i.notifyLevel !== undefined ? { notifyLevel: i.notifyLevel } : {}), ...((i as { quietHours?: string }).quietHours !== undefined ? { quietHours: (i as { quietHours?: string }).quietHours } : {}), ...((i as { jitter?: boolean }).jitter !== undefined ? { jitter: (i as { jitter?: boolean }).jitter } : {}), ...(i.preflight !== undefined ? { preflight: i.preflight } : {}), ...(i.keep !== undefined ? { keep: i.keep } : {}), ...(i.backoffMs !== undefined ? { backoffMs: i.backoffMs } : {}), ...(i.profile !== undefined ? { profile: i.profile } : {}) }),
      scheduleRemove: async (id) => this.scheduleRemove({ id }),
      scheduleRun: async (id) => this.scheduleRunNow({ id }),
      scheduleList: async () => { const r = await this.scheduleList(); return { ok: r.ok, schedules: r.schedules as unknown as Array<Record<string, unknown>>, error: r.ok ? undefined : '读取失败' } },
      notifySet: async (channels) => { const r = await this.notifyConfig({ channels }); return { ok: r.ok, error: r.error } },
      notifyTest: async () => this.notifyTestSend(),
      reportBuild: async (id) => this.reportBuild({ id }),
      undo: async (stem) => {
        // ⑥:按收件箱 stem 撤销——目前只覆盖 schedule-add(回执 <stem>.result.json 在收件箱根)
        const dir = inboxDir()
        try {
          const result = JSON.parse(readFileSync(join(dir, `${stem}.result.json`), 'utf8')) as { kind?: string; value?: { id?: string } }
          if (result.kind !== 'schedule-add' || typeof result.value?.id !== 'string') return { ok: false, error: '该意图不可撤销(仅 schedule-add 支持)' }
          return await this.scheduleRemove({ id: result.value.id })
        } catch { return { ok: false, error: `找不到 ${stem} 的执行回执` } }
      },
      reportExport: async (id) => this.snapExport({ id }),
      backup: async () => {
        // ⑨:任务+通知配置打包 JSON(快照体积大不进备份,路径在任务里可按 id 重采)
        const file = join(homedir(), '.dsh', `dsh-opencli-backup-${Date.now()}.json`)
        await writeFile(file, JSON.stringify({ version: 1, at: new Date().toISOString(), schedules: this.schedules, notifyConfig: this.state.notifyConfig ?? { channels: [] } }, null, 2), 'utf8')
        return { ok: true, file }
      },
      status: async () => ({
        plugin: 'dsh-opencli', version: PKG_VERSION, schedules: this.schedules.length,
        ...(this.state.notifyConfig !== undefined ? { notifyChannels: this.state.notifyConfig.channels.length } : {}),
      }),
      event: (text) => {
        this.pushIngestEvent('inbox', text)
      },
    }
  }

  /** drain 在途标记(重入守卫):3s 一拍,慢 drain(意图执行 60s 级 site 命令)期间
   *  在途拍会无上限叠加;忙碌拍直接跳过,出结果后下一拍自然接管。 */
  private inboxDraining = false

  /**
   * 收件箱消费:意图 → 既有服务方法(RPC 同源,一套逻辑两个入口)。轮询循环与专项
   * 测试都走这里;任何异常吞掉记事件——收件箱是旁路面,绝不反噬宿主进程。
   * notify-test 走 buildNotifyChannels 真发一次(与调度通知同链),发到的是用户已配通道。
   */
  private async drainInboxSafe(): Promise<void> {
    if (this.inboxDraining) return // 在途:跳过本拍(计时器照走,不叠加并发 drain)
    this.inboxDraining = true
    try {
      await drainInbox(this.inboxExecutor())
    } catch { /* 收件箱旁路:静默 */ } finally {
      this.inboxDraining = false
    }
  }

  private startScheduler(): void {
    if (this.schedTimer !== undefined) return
    this.schedTimer = setInterval(() => {
      const now = new Date()
      const minuteKey = `${now.getFullYear()}-${now.getMonth()}-${now.getDate()}-${now.getHours()}-${now.getMinutes()}`
      for (const sch of this.schedules) {
        if (!sch.enabled) continue
        const histKey = `${sch.id}:${minuteKey}`
        if (this.schedMarkers.has(histKey)) continue
        if (!this.cronMatches(sch.cron, now)) continue
        this.addSchedMarker(histKey)
        void this.runSiteCommand(sch.site, sch.id)
      }
    }, 15_000)
    try { this.schedTimer.unref?.() } catch { /* ignore */ }
  }

  /** 上次看到的 daemon 版本(版本翻转检测:CLI 2.0.x 与 App 内置 1.8.6 互杀,#2761 实测一天 3 翻)。 */
  private lastDaemonVersion: string | undefined

  /** 上次 daemon 自愈(restart)时刻:退避防循环——修复无效时,后续 tick 不再连发重启。 */
  private lastSelfHealAt = 0
  /** 自愈退避窗默认 10 分钟(DSH_OPENCLI_SELFHEAL_BACKOFF_MS 可调,0=关退避)。 */
  private static readonly SELFHEAL_BACKOFF_MS = 10 * 60 * 1000

  /** 熔断窗:系统级失败签名 → 开窗时刻。窗内同签名失败短路各任务的重试链(跨任务去重,§七#4)。 */
  private circuitOpen = new Map<string, number>()
  /** 熔断窗默认 30 分钟(DSH_OPENCLI_CIRCUIT_MINUTES 可配)。 */
  private static readonly CIRCUIT_WINDOW_MS = 30 * 60 * 1000

  /**
   * 系统级失败签名提取(熔断判据):daemon 断连(fetch failed——undici 汇聚错误文本,
   * 11-06..08 v2ex 三日连败实证)与 Windows 文件系 EPERM(09-25 九分钟窗 75 条洪水实证,
   * 单根因×任务×重试链放大)。返回 null=非系统级:站点/适配器故障不熔断,照常走重试链
   * 与通知——熔断只止血系统面,不吞业务面。
   */
  private static circuitSignature(text: string): string | null {
    if (/\bfetch failed\b/i.test(text)) return 'fetch-failed'
    if (/\bEPERM\b[^\n]*operation not permitted/i.test(text)) return 'eperm'
    return null
  }

  /** 熔断窗时长(分钟 → ms;env 可配,非正数回默认)。 */
  private circuitWindowMs(): number {
    const raw = Number(process.env.DSH_OPENCLI_CIRCUIT_MINUTES)
    return Number.isFinite(raw) && raw > 0 ? Math.round(raw * 60_000) : OpencliService.CIRCUIT_WINDOW_MS
  }

  /** 熔断窗判定:开窗时刻仍在窗口内=活跃;过期条目顺手清掉(下次同签名失败重新开窗)。 */
  private circuitActive(sig: string): boolean {
    const at = this.circuitOpen.get(sig)
    if (at === undefined) return false
    if (Date.now() - at >= this.circuitWindowMs()) {
      this.circuitOpen.delete(sig)
      return false
    }
    return true
  }

  /**
   * daemon 自愈单发(D3 纪律改版,用户 2026-11-09 确认):`daemon restart` → 重探,三态返回。
   * 触发面由「daemon 明确报告未运行」扩为:未运行 / 运行但版本翻转(CLI/App 互杀,版本错=
   * 功能坏,只观察不修复等于无人值守任务整天空转)/ 执行期 fetch failed(断连签名)。
   * 退避窗(默认 10 分钟)内直接 skip-backoff 不动手——同一故障不由每次 tick 各重启一遍,
   * 「翻转→重启」不再成循环;restart 前记 daemon-selfheal 事件(面板时间线可见自愈动作)。
   */
  private async selfHealDaemon(reason: string): Promise<'ok' | 'skip-backoff' | 'failed'> {
    const rawBackoff = Number(process.env.DSH_OPENCLI_SELFHEAL_BACKOFF_MS)
    const backoff = Number.isFinite(rawBackoff) && rawBackoff >= 0 ? rawBackoff : OpencliService.SELFHEAL_BACKOFF_MS
    if (Date.now() - this.lastSelfHealAt < backoff) return 'skip-backoff'
    this.lastSelfHealAt = Date.now()
    this.pushIngestEvent('daemon-selfheal', `🩺 daemon 自愈:${reason} → daemon restart(退避 ${Math.round(backoff / 1000)}s 内不再重启)`)
    try {
      await this.runOpencli(['daemon', 'restart'], 30_000)
    } catch {
      return 'failed'
    }
    // restart 输出是纯文本,恢复判定必须重探(与 ① 路径同口径;重探结果取代旧值走后续检查)
    const after = await this.daemonStatus()
    return after !== null && after.running === true ? 'ok' : 'failed'
  }

  /**
   * 任务级健康预检+断线恢复(dsh #2416/#2417/#1565 与上游 #2761):
   * 返回 {ok, note}——ok=true 可跑;note=人类可读的预检说明(进 history 行与推送)。
   * 预检失败且自动恢复也失败 → ok=false,本次 tick 跳过(诚实跳过优于注定失败的 60s 往返)。
   * 预检纪律:任何探测失败降级为"放行"——预检自身故障不能变成定时任务的死因(fail-open)。
   */
  private async taskHealthCheck(id: string): Promise<{ ok: boolean; note?: string }> {
    const notes: string[] = []
    const ds = await this.daemonStatus()
    // ① daemon 未运行 → 尝试自动拉起(单次;失败即诚实跳过本 tick)。
    //    注意:exit≠0 与'未运行'不可分——仅当明确报告未运行(ds!==null&&!running)才动手 restart,
    //    ds=null(命令失败/输出变异)不碰 restart(fail-open 放行,让 attempt 循环自然失败并暴露)
    let effDs = ds
    if (ds !== null && ds.running !== true) {
      notes.push('daemon 未运行')
      try {
        await this.runOpencli(['daemon', 'restart'], 30_000)
        // restart 输出是纯文本,解析不出 running——恢复判定必须**重新探测**;
        // 重探结果 after **取代** ds 走后续全部检查(拉起后扩展几乎必然未重连)
        const after = await this.daemonStatus()
        if (after === null || after.running !== true) {
          return { ok: false, note: 'daemon 不可用且自动拉起失败——本 tick 跳过(装扩展/查 daemon 日志后自动恢复)' }
        }
        notes.push('已自动拉起 daemon')
        effDs = after
      } catch {
        return { ok: false, note: 'daemon 不可用且自动拉起异常——本 tick 跳过' }
      }
    }
    // ② daemon 版本翻转检测(#2761):版本变化 → 记事件 + 单次 restart 自愈(D3 纪律改版,
    //    用户 2026-11-09 确认:触发条件由「仅未运行才 restart」扩为「未运行 OR 版本翻转」——
    //    App 内置旧 daemon 会杀掉新 daemon,版本错=功能坏,只观察不修复等于任务整天空转;
    //    退避窗防「翻转→重启」循环,窗内 skip 放行,修复无效时每 tick 至多记一次事件)
    if (effDs !== null && typeof effDs.version === 'string' && effDs.version.length > 0) {
      if (this.lastDaemonVersion !== undefined && this.lastDaemonVersion !== effDs.version) {
        const flip = `daemon 版本翻转 ${this.lastDaemonVersion} → ${effDs.version}(疑似 CLI/App 互杀,#2761)`
        this.pushIngestEvent('daemon-flip', `⚠ ${flip}`)
        notes.push(flip)
        const healed = await this.selfHealDaemon('版本翻转')
        if (healed === 'failed') {
          return { ok: false, note: `${flip};自动重启未恢复——本 tick 跳过` }
        }
        if (healed === 'ok') {
          const re = await this.daemonStatus()
          if (re === null || re.running !== true) {
            return { ok: false, note: `${flip};重启后重探失败——本 tick 跳过` }
          }
          notes.push('已自动重启 daemon(版本翻转自愈)')
          effDs = re
        }
        // skip-backoff:退避窗内不重复重启,放行执行链自然暴露(循环防护的一部分)
      }
      this.lastDaemonVersion = effDs.version
    }
    // ③ 扩展未连:不自动恢复(扩展重连是浏览器侧行为)——诚实跳过并给指引。
    // 词法对齐 extensionState('not connected' 文本经 \S+ 截断为 'not';connected 前缀才是连上)
    if (effDs !== null) {
      const extLine = (effDs.extension ?? '').trim()
      const up = /^connected/.test(extLine) || /profiles connected/.test(extLine) || extLine === 'unknown'
      if (extLine !== '' && !up) {
        return { ok: false, note: '浏览器扩展未连接——本 tick 跳过;打开浏览器后自动恢复,任务保留' }
      }
    }
    return { ok: true, ...(notes.length > 0 ? { note: notes.join(';') } : {}) }
  }

  private async runSiteCommand(siteCmd: string, id: string, opts?: { manual?: boolean }): Promise<void> {
    const sch = this.schedules.find((s) => s.id === id)
    // 健康预检:daemon 探测/自动拉起/版本翻转/扩展断连四合一;
    // fail-open 纪律:预检自身异常 → 放行(预检故障不能变成任务死因)
    let healthNote: string | undefined
    try {
      const hc = await this.taskHealthCheck(id)
        if (!hc.ok) {
          const hist0 = this.runHistory[id] ?? []
        hist0.unshift({ at: new Date().toISOString(), ok: false, summary: `⏸ 跳过:${hc.note ?? '健康预检未过'}` })
        this.runHistory[id] = hist0.slice(0, 5)
        await this.saveState()
        this.pushIngestEvent('schedule-skipped', `⏸ ${siteCmd} 本 tick 跳过:${hc.note ?? ''}`)
        return
      }
      healthNote = hc.note
    } catch { /* 预检异常 → 放行(fail-open) */ }
    const attempts = Math.max(1, Math.min(5, sch?.retry ?? 3))
    const notify = sch?.notify !== false
    const hist = this.runHistory[id] ?? []
    // 面板占位符是 'site zhihu hot' 形态,而 CLI 直接吃 'zhihu hot'——此前原样透传导致
    // 按占位符创建的任务 100% 失败(unknown command 'site')(实测发现)。剥掉 site 前缀。
    const norm = siteCmd.replace(/^\s*site\s+/i, '').trim()
    // canary 特例:定时任务填 canary 即每晚漂移巡检(dogfooding——插件自监控),
    // 走 canaryRun 全链(与上轮对比出漂移报告),不走单命令执行
    if (norm === 'canary') {
      const r = await this.canaryRun()
      hist.unshift({ at: new Date().toISOString(), ok: r.ok, summary: r.ok ? `canary:${r.passed}/${r.total}${r.newFailures.length > 0 ? ' 新失败:' + r.newFailures.slice(0, 3).join(',') : ''}` : `canary 失败:${r.error ?? '未知'}` })
      this.runHistory[id] = hist.slice(0, 5)
      await this.saveState()
      return
    }
    const cmdLine = norm.length > 0 ? norm : siteCmd
    const [sSite = '', sCmd = ''] = cmdLine.split(/\s+/)
    // 多账号隔离(任务级透传):上游 2.0.3 原生支持 --profile/OPENCLI_PROFILE(contextId
    // 严格路由,fail loud——profile 未连=诚实失败,插件层不降级不吞),任务字段 profile 存在时
    // 经 env 透传(不经 shell,runSubprocess env 合并路径零注入面)。回执标 profile 留审计痕。
    const profileEnv = sch?.profile !== undefined && sch.profile.length > 0 ? { OPENCLI_PROFILE: sch.profile } : undefined
    // 命令读写类别(#59 读写分频):清单缓存里的 access 决定限频轨(read=750ms 轨,write=3s 独立轨)。
    // 只读已有缓存(面板 status 异步预热 / systemPrompt 目录构建 / 审批门 lookupAccess 都会填充),
    // 不为分频在调度热路径上额外拉 2.0 分页清单(1225 条≈13 次受控 CLI 调用);冷缓存时 access=unknown
    // 按 read 轨走——如实边界:此时写命令不享独立写轨,但放行语义不变(分频是节奏,不是授权)
    const access = commandAccess((this.adapterCache as { json?: unknown } | null)?.json, sSite, sCmd)
    const govKind: 'read' | 'write' = access === 'write' ? 'write' : 'read'
    // 认证预检(dsh #1882/#1883/#2568/#2758:cookie 过期=false AUTH 失败,烧满重试链才暴露):
    // 任务级开关(默认关,scheduleAdd preflight / 收件箱 / ctl --preflight),canary 例外已在上方 return。
    // 开启时每次采集前跑 whoami 快检(loginCheck 池,10min TTL 缓存——多任务同分钟共享一次探测);
    // 未登录 → 按 AUTH 类失败记 history 行并跳过本 tick(与扩展断连跳过同款 ⏸ 语义,任务保留)。
    // fail-open 纪律与 taskHealthCheck 同源:loginCheck 异常/站点不在 whoami 池 → 放行,
    // 预检自身故障不能变成任务死因。放在拟人限速之前:跳过就别再付 15-90s jitter 等待。
    if (sch?.preflight === true) {
      try {
        const lc = await this.loginCheck()
        if (lc.ok) {
          const item = lc.results.find((r) => r.site.toLowerCase() === sSite.toLowerCase())
          if (item !== undefined && item.ok !== true) {
            const detail = item.detail !== null && item.detail.length > 0 ? `:${item.detail}` : ''
            const note = `${sSite} 未登录(AUTH 预检未过${detail})`
            const hist0 = this.runHistory[id] ?? []
            hist0.unshift({ at: new Date().toISOString(), ok: false, summary: `⏸ 跳过:${note}(先 site ${sSite} login;任务保留,下 tick 再检)`, receipt: { auth_state: 'auth_wall', bytes: 0, stop_reason: 'error', remaining_cursor: null } })
            this.runHistory[id] = hist0.slice(0, 5)
            await this.saveState()
            this.pushIngestEvent('schedule-skipped', `⏸ ${siteCmd} 本 tick 跳过:登录态预检未过——${note}`)
            return
          }
        }
      } catch { /* 体检旁路:预检异常 → 放行 */ }
    }
    let lastOk = false
    let lastSummary = ''
    let lastOut = ''
    let lastRaw = ''
    let lastStderr = '' // 末次尝试的 stderr(typed 失败码提取源;异常尝试清空,不残留上一次的码)
    // 拟人限速:精确 cron 时刻本身是指纹——首跑前随机延迟打散命中时间
    // (重试链已有风控感知退避;任务级 jitter:false 可关;DSH_OPENCLI_JITTER_MAX_MS 调上限/置 0 关)
    if (opts?.manual !== true && sch?.jitter !== false) {
      const raw = Number(process.env.DSH_OPENCLI_JITTER_MAX_MS ?? 90_000)
      const hi = Number.isFinite(raw) && raw > 0 ? Math.min(Math.round(raw), 600_000) : 0
      if (hi > 0) {
        const lo = Math.min(15_000, hi)
        await new Promise((res) => setTimeout(res, Math.round(lo + Math.random() * (hi - lo))))
      }
    }
    let bonusUsed = false
    let selfHealUsed = false // 同 tick 只试一次自愈(D3);跨 tick 循环由 selfHealDaemon 退避窗防
    let circuitSkipped = false // 熔断短路标记:跳过余下重试,且不再补 schedule-failed 事件/外送通知
    for (let attempt = 1; attempt <= attempts; attempt++) {
      try {
        const started = Date.now()
        const r = await this.runOpencli(cmdLine.split(/\s+/), 60_000, 1_048_576, profileEnv, govKind)
        // 定时链路此前绕过 recordTrace(只有 browser 透传入口记录),「运行轨迹」看不到定时执行的
        // 真实失败输出,复盘断链(GUI 走查 2026-10-08)。带 schedule 前缀与手动 browser 命令区分;
        // URL 参数脱敏在 recordTrace 单点完成(回执/轨迹卫生:登录态链接常带 ?token=/?code=,落盘即洗)
        this.recordTrace(`schedule ${cmdLine}`, r, Date.now() - started)
        lastOk = r.exitCode === 0
        lastSummary = lastOk ? (r.stdout.slice(0, 120) || 'ok') : (r.stderr.slice(0, 120) || `exit ${r.exitCode}`)
        lastOut = lastOk ? r.stdout : ''
        lastRaw = `${r.stdout}
${r.stderr}`
        lastStderr = r.stderr
        if (lastOk) {
          // 无人值守防线:规则命中或 noul 强失效(P<0.35)→ 按失败重试;noul 可疑(0.35-0.7)只标注不重试
          const v = await this.verifyResult(sSite, sCmd, r.stdout)
          if (v !== null) {
            if (!v.verdict) {
              lastOk = false
              lastSummary = `静默失败(${v.why ?? `P=${v.p.toFixed(2)}`}):${lastSummary}`
            } else if (v.p < 0.7) {
              lastSummary = `⚠ 可疑(P=${v.p.toFixed(2)}) ${lastSummary}`
            }
          }
        }
      } catch (e) {
        lastOk = false
        lastStderr = ''
        lastSummary = e instanceof Error ? e.message.slice(0, 120) : 'failed'
      }
      // 回执卫生:history 摘要是输出前 120 字,登录态页面链接的 ?token=/?code= 会原样进
      // state.json 与面板 tooltip——落 history 前过 URL 参数脱敏(通知出口另有全量 scrub)
      const sum = scrubUrlParams(attempts > 1 ? `#${attempt}/${attempts} ${lastSummary}` : lastSummary)
      hist.unshift({ at: new Date().toISOString(), ok: lastOk, summary: healthNote !== undefined ? `【${healthNote}】${sum}` : sum })
      if (lastOk) break
      // 熔断检查(§七#4,置于自愈/挑战/退避之前:窗已开=系统性故障且修复已试过,不再烧链):
      // 同签名失败跨任务去重——首个任务烧完链开窗,窗内其余任务首败即短路,单行诚实落史
      const sig = OpencliService.circuitSignature(`${lastRaw}\n${lastSummary}`)
      if (sig !== null && this.circuitActive(sig)) {
        circuitSkipped = true
        if (hist[0] !== undefined) hist[0].summary = `${hist[0].summary} ⚡ 熔断:${sig} 系统级失败 ${Math.round(this.circuitWindowMs() / 60_000)} 分钟窗内,重试链短路(诊断入口:canary 巡检)`
        break
      }
      // 执行期断连自愈(D3):fetch failed=daemon 断连签名 → 单次 restart 后重探重跑
      // (赠次不占 attempts 预算,与挑战自解同款);同 tick 只试一次,退避窗防跨 tick 循环
      if (sig === 'fetch-failed' && !selfHealUsed) {
        selfHealUsed = true
        const healed = await this.selfHealDaemon(`执行期断连:${cmdLine}`)
        if (healed === 'ok') {
          healthNote = 'daemon 断连已自愈重跑'
          attempt--
          continue
        }
      }
      // 挑战自解等待:验证码/人机验证常在数十秒内自解(上游 #2045 已采纳同方向)——
      // 首次命中额外赠一次尝试(不占 attempts 预算);DSH_OPENCLI_CHALLENGE_WAIT_MS 调等待时长
      if (attempt >= attempts && !bonusUsed && isChallengePage(lastRaw || lastSummary)) {
        bonusUsed = true
        const waitRaw = Number(process.env.DSH_OPENCLI_CHALLENGE_WAIT_MS ?? 45_000)
        const waitMs = Number.isFinite(waitRaw) && waitRaw > 0 ? Math.min(waitRaw, 300_000) : 0
        if (waitMs > 0) await new Promise((res) => setTimeout(res, waitMs))
        attempt--
        continue
      }
      if (attempt < attempts) {
        // 风控感知退避(回执/轨迹卫生:退避写成任务级默认字段 backoffMs,默认 15s 行为不变;
        // 风控墙维持 ≥120s 下限——撞墙时 15s 固定重试等于往枪口上撞,改等 2 分钟让软封禁冷却)
        const backoffMs = Math.max(0, Math.min(600_000, sch?.backoffMs ?? 15_000))
        const riskWall = lastSummary.includes('登录/风控墙')
        await new Promise((res) => setTimeout(res, riskWall ? Math.max(backoffMs, 120_000) : backoffMs))
      }
    }
    // 采集回执:auth 状态/条目数/空结果——对齐上游 missing≠zero 语义(#2699/#2708):
    // 空数组≠没数据(可能是登录后空壳页),必须显式标注而不是假装成功。
    // 回执深化(对齐 2.0.3 #2708/#2754/#2766 typed 口径):partial=#2766 分页未尽,
    // unloaded=#2708 内容未渲染完即读(输出含加载中/骨架正向标记),coverage 近似
    // stop_reason/remaining_cursor(插件层近似,上游 #2698 设计落地后对齐字段语义)。
    const itemCount = lastOk ? countStructuredItems(lastOut) : null
    const partial = lastOk && looksPartialPage(`${lastRaw}\n${lastOut}`)
    // typed 失败码(#2708/#2754 对齐):失败回执带上游原码,不再只落 auth_state:unknown;
    // COUNTS_NOT_LOADED=上游 typed「未载」→ unloaded 直接采信(成功侧仍是加载标记近似)
    const errorCode = lastOk ? null : typedErrorCode(lastStderr)
    const unloaded = (lastOk && itemCount === 0 && looksUnloaded(lastOut)) || errorCode === 'COUNTS_NOT_LOADED'
    const truncated = lastOk && looksTruncated(lastOut)
    const receipt: Receipt = {
      auth_state: lastOk ? (authRiskClass(lastOut) ?? 'ok') : (authRiskClass(lastRaw || lastSummary) ?? 'unknown'),
      ...(lastOk && itemCount !== null ? { items: itemCount } : {}),
      bytes: lastOut.length,
      ...(lastOk && itemCount === 0 && !unloaded ? { empty: true } : {}),
      ...(truncated ? { truncated: true } : {}),
      ...(partial ? { partial: true } : {}),
      ...(unloaded ? { unloaded: true } : {}),
      ...(sch?.profile !== undefined ? { profile: sch.profile } : {}),
      ...(errorCode !== null ? { error_code: errorCode } : {}),
      // coverage 近似:cursor 仅 #2766 提示给出 offset 时可提取,其余未知恒 null;
      // unloaded(疑似未渲染完)不能算"自然翻完"——结构化判据对它不成立,stop_reason 落 null(未知)
      stop_reason: coverageStopReason(lastOk, truncated || partial, itemCount !== null && !unloaded),
      remaining_cursor: partial ? (cursorOfPartialPage(lastRaw) ?? null) : null,
    }
    if (hist[0] !== undefined) (hist[0] as { receipt?: Receipt }).receipt = receipt
    this.runHistory[id] = hist.slice(0, 5)
    // 采集结构化落盘(主线 B):成功执行的完整输出存快照,时间线/diff/趋势的数据源。
    // 文件即真相:~/.dsh/opencli-snapshots/<任务id>/<时间戳>.json。留存预算(回执/轨迹卫生,
    // 任务级可配 sch.keep,默认 50 份、钳制 5-500):超出按时间序滚动淘汰最旧——高频任务
    // 不再把磁盘写穿,低频长周期任务可调大保留全程。快照 stdout 同过 URL 参数脱敏(落盘即洗)。
    let snapPath: string | undefined // 本 tick 快照路径:漂移兜底数据并入同一份(不另起快照)
    if (lastOk && lastOut.length > 0) {
      try {
        const dir = join(this.snapshotsBase, id)
        await mkdir(dir, { recursive: true })
        const stamp = new Date().toISOString().replace(/[:.]/g, '-')
        const p = join(dir, `${stamp}.json`)
        await writeFile(p, JSON.stringify({
          at: new Date().toISOString(), site: siteCmd, bytes: lastOut.length, stdout: scrubUrlParams(lastOut), receipt,
        }), 'utf8')
        snapPath = p
        const olds = readdirSync(dir).sort() // 字典序=时间序
        const keep = Math.max(5, Math.min(500, sch?.keep ?? 50))
        if (olds.length > keep) for (const f of olds.slice(0, olds.length - keep)) { try { unlinkSync(join(dir, f)) } catch { /* ignore */ } }
      } catch { /* 快照失败不阻断主流程 */ }
    }
    // 快照 diff(0.4.6 C):成功采集时与上一份快照比对(文件即真相,字典序取次新份)。
    // 三形态(新增/消失/位移)进 ingest 事件与推送正文;非 JSON 输出折成规模摘要。宁缺毋假。
    let diffText = ''
    if (lastOk && lastOut.length > 0) {
      try {
        const sdir = join(this.snapshotsBase, id)
        const olds = readdirSync(sdir).filter((f) => f.endsWith('.json')).sort()
        const prevFile = olds.length >= 2 ? olds[olds.length - 2] : undefined  // 刚写入的当前份是最后一份
        if (prevFile !== undefined) {
          const prev = JSON.parse(readFileSync(join(sdir, prevFile), 'utf8')) as { stdout?: string }
          // 同口径比对:落盘 stdout 已过 URL 参数脱敏,当前份也先脱敏再比——否则带 ?sid= 等参数的
          // 条目会因"一边脱敏一边原文"被误判为变化
          const d = diffSnapshots(String(prev.stdout ?? ''), scrubUrlParams(lastOut))
          diffText = renderDiffText(d)
          if (d.structured && d.added + d.removed + d.moved > 0) {
            this.pushIngestEvent('snap-diff', `📊 ${siteCmd} 变化:新增 ${d.added}/消失 ${d.removed}/位移 ${d.moved}`)
          }
        }
      } catch { /* diff 旁路:失败不影响主流程 */ }
    }
    // 适配器漂移预警:快照 diff 反向用于故障发现——同一任务连续 3 次结果结构突变
    // (条目骤降 ≥50% 或 结构翻转:数组→对象/解析失败)→ ingest 事件 adapter-drift。
    // 判定纯函数 detectDrift(diffsnap):连续 3 次同向突变才报,防单次抖动;缓冲存最近 5 次
    // (items 复用上方回执的 countStructuredItems 口径,structured=null 即解析失败)。
    // 只在成功采集时记签名:命令整体失败走 schedule-failed,不混入结构序列。
    if (lastOk && lastOut.length > 0) {
      const sig = this.driftHistory.get(id) ?? []
      sig.push({ items: itemCount, structured: itemCount !== null })
      if (sig.length > 5) sig.splice(0, sig.length - 5)
      this.driftHistory.set(id, sig)
      if (detectDrift(sig)) {
        // 预警事件照发(adapter-drift 发射点,0.1.2 语义不变),随后接兜底:此前只发预警
        // "建议 browser_* 兜底",当晚数据就断流——现在命中处直接经 browser_* 原语兜底采集
        // (open 域名首页 + state 页面状态)。成功:兜底数据并入本 tick 快照(fallback 字段,
        // 不另起一份——diff 仍只比 .stdout=适配器输出,时间线每 tick 一份)、回执标 degraded;
        // 失败:按现语义诚实失败(预警已发,history 行写明兜底失败原因,不伪造任何数据)。
        // coverage 字段(stop_reason/remaining_cursor)保持适配器侧口径不改:页面状态级的近似
        // 数据说明不了适配器是否"翻完",改成 end 就是虚报。
        this.pushIngestEvent('adapter-drift', `⚠ ${siteCmd} 疑似适配器坏/灰度漂移:连续 3 次结果结构突变(条目骤降/结构翻转)——自动接 browser_* 原语兜底采集`)
        // 多账号边界:任务指定了浏览器 profile 时不兜底——browser_* 原语(含生产直连路径)不按任务
        // profile 路由,兜底会落到默认档案、用**另一个账号**采到数据,标 degraded 也掩盖不了"账号错了";
        // 宁可如实报兜底不可用,也不拿错账号的数据顶替
        const domain = sch?.profile !== undefined ? null : await this.domainOf(sSite)
        const fb = sch?.profile !== undefined
          ? { ok: false, note: `任务指定了浏览器 profile「${sch.profile}」,browser_* 兜底不支持按 profile 路由——不用默认档案的账号顶替采集` }
          : domain !== null ? await this.driftFallbackCollect(domain) : { ok: false, note: '适配器清单无该站点域名' }
        if (fb.ok) {
          receipt.degraded = true
          if (snapPath !== undefined) {
            try {
              const snap = JSON.parse(readFileSync(snapPath, 'utf8')) as Record<string, unknown>
              snap.degraded = true
              snap.fallback = { via: 'browser open + state', domain, bytes: fb.bytes, stdout: scrubUrlParams(fb.stdout ?? '') }
              snap.receipt = receipt
              await writeFile(snapPath, JSON.stringify(snap), 'utf8')
            } catch { /* 兜底数据并入快照失败不阻断主流程(回执与事件照常) */ }
          }
          if (hist[0] !== undefined) {
            hist[0].summary = `${hist[0].summary} 🛟 漂移兜底:browser_* 原语已采集近似数据(${domain} 首页页面状态,degraded;非适配器结构化输出)`
          }
          this.pushIngestEvent('adapter-drift-fallback', `🛟 ${siteCmd} 漂移兜底成功:browser_* 原语采集了 ${domain} 首页页面状态(degraded,已并入本次快照);适配器恢复前数据为近似口径`)
        } else {
          if (hist[0] !== undefined) {
            hist[0].summary = `${hist[0].summary} 🛟 漂移兜底失败(${fb.note ?? '未知'}):本 tick 无兜底数据`
          }
          this.pushIngestEvent('adapter-drift-fallback', `🛟 ${siteCmd} 漂移兜底失败:${fb.note ?? '未知'}——不伪造数据;建议人工 browser open 该站验证或等适配器修复`)
        }
      }
    }
    // watch 命中:采集成功且完整结果包含任一监控关键词 → ingest 事件(确定性匹配,零误报)。
    // 命中词带出到下方 dispatchScheduleNotify:面板时间线与外部通知通道同一份命中事实
    let watchHits: string[] = []
    if (lastOk && sch?.watch !== undefined && sch.watch.length > 0) {
      const kws = sch.watch.split(/[,，\s]+/).filter((k) => k.length > 0)
      // 大小写不敏感(实测发现:'agent,diffusion' 撞 'Agentic/Diffusion' 全 miss)
      const low = lastOut.toLowerCase()
      watchHits = kws.filter((k) => low.includes(k.toLowerCase()))
      if (watchHits.length > 0) {
        this.pushIngestEvent('watch-hit', `🔔 Watch 命中:${siteCmd} 出现 [${watchHits.join(', ')}]`)
      }
    }
    if (!lastOk && notify && !circuitSkipped) {
      // 熔断开窗(§七#4):链烧完仍是系统级签名且窗未开 → 开窗一次,ingest 单条事件给
      // 诊断入口(canary 区分站点面漂移与系统面故障);窗内后续任务的短路行只进 runHistory
      // (上方 ⚡ 行),不再补 schedule-failed/外送——「1 条诊断 + 全任务熔断到修复」
      const finalSig = OpencliService.circuitSignature(`${lastRaw}\n${lastSummary}`)
      if (finalSig !== null && !this.circuitActive(finalSig)) {
        this.circuitOpen.set(finalSig, Date.now())
        this.pushIngestEvent('circuit-open', `⚡ 系统级熔断开窗(${finalSig}):同签名失败将在 ${Math.round(this.circuitWindowMs() / 60_000)} 分钟窗内短路各任务重试链——daemon 断连/文件系权限类系统面故障;诊断入口:canary 巡检(区分站点面漂移与系统面故障)`)
      }
      this.pushIngestEvent('schedule-failed', `定时任务连续 ${attempts} 次失败:${siteCmd} — ${lastSummary}`)
    }
    await this.saveState()
    // 任务 E:结果外送通知——重试链走完、状态落盘后一次群发。放在 saveState 之后:
    // 通知发送(webhook/email 各有 10s 收端超时)不挡状态持久化;await 保证测试可确定性断言。
    // 评审 MEDIUM:sch.notify===false 时任务级关闸(面板"通知 关"徽章与实际行为一致);
    // 例行结果默认即发(成功=例行通知,失败=schedule-failed,watch 命中=正文加 🔔 前缀)——
    // 没有按通道的"安静成功"开关(早期注释曾宣称 wantRoutine 门,该字段从未实现,勿再引用)
    // ④补强:notifyLevel==='quiet' 只推有价值信号(watch 命中/有变化/失败),高频任务不再刷屏
    const quiet = sch?.notifyLevel === 'quiet'
    const worthPushing = !lastOk || watchHits.length > 0 || diffText.length > 0
    const inWin = sch?.quietHours !== undefined && inQuietHours(sch.quietHours)
    // quiet 任务出窗后若暂存非空,本条即使为例行成功也要进合并清空(否则暂存滞留到下次有价值推送,复核 low)
    const pendingFlush = (sch?.pendingNotify?.length ?? 0) > 0 && !inWin
    // 熔断短路(circuitSkipped)不外送:开窗任务的通知已发过一次,窗内任务不再逐任务推送
    if (sch?.notify !== false && !circuitSkipped && (!quiet || worthPushing || pendingFlush)) {
      // 静默时段(0.4.7 B2):窗内暂存(上限 20 条,防长窗爆内存;随任务落盘重启不丢),
      // 出窗首跑把暂存合并进正文一次推送后清空。窗解析失败按未配置处理(fail-open 多推不吞)。
      if (inWin) {
        const pend = sch.pendingNotify ?? []
        pend.push({ at: new Date().toISOString(), ok: lastOk, summary: lastSummary.slice(0, 200), hits: watchHits.length, diff: diffText.length > 0 })
        sch.pendingNotify = pend.slice(-20)
        await this.saveState()
      } else {
        await this.dispatchScheduleNotify(siteCmd, sch?.watch, lastOk, lastSummary, watchHits, diffText, sch?.pendingNotify, sch?.quietHours, receipt, healthNote, sch?.source)
        if ((sch?.pendingNotify?.length ?? 0) > 0) { sch!.pendingNotify = []; await this.saveState() }
      }
    }
  }

  /**
   * 漂移兜底采集:adapter-drift 命中时经 browser_* 原语(open + state)抓域名首页的
   * 页面状态,作 degraded 近似数据。显式诚实边界:抓的是"浏览器还能打开这个域"的证据与
   * 页面状态 JSON,不是适配器结构化输出——回执标 degraded,数据并入本 tick 快照的 fallback 字段。
   * 两步任一失败即整体失败(返回 note),由调用方按现语义诚实降级;会话名带 drift- 前缀,
   * 与用户活页/其他任务的会话隔离,两步都进运行轨迹(runBrowserTraced 单点纪律)。
   */
  private async driftFallbackCollect(domain: string): Promise<{ ok: boolean; stdout?: string; bytes?: number; note?: string }> {
    const sess = `drift-${Date.now()}`
    let opened = false
    try {
      const o = await this.runBrowserTraced(sess, ['open', `https://${domain}`])
      if (o.exitCode !== 0) return { ok: false, note: `open https://${domain} 失败:${(o.stderr || o.stdout).slice(0, 80)}` }
      opened = true
      const state = await this.runBrowserTraced(sess, ['state'])
      const ok = state.exitCode === 0 && state.stdout.trim().length > 0
      return ok
        ? { ok: true, stdout: state.stdout, bytes: state.stdout.length }
        : { ok: false, note: `state 失败:${(state.stderr || state.stdout).slice(0, 80)}` }
    } catch (e) {
      return { ok: false, note: e instanceof Error ? e.message.slice(0, 80) : 'browser 原语异常' }
    } finally {
      // 有界清理(回执/轨迹卫生同款纪律):兜底会话开的窗口用完即关,单条命令、失败忽略——
      // 不在用户浏览器里每次漂移都遗留一个标签页
      if (opened) { try { await this.runBrowserTraced(sess, ['close']) } catch { /* 清理尽力而为 */ } }
    }
  }

  /**
   * 定时结果外送(notify.ts 通道层的接线点):notifyConfig 有启用通道才发;标题/正文由
   * buildNotifyBody 统一组装,四个追加段(diff/静默摘要/自愈说明/回执)在拼接处逐段过
   * scrubLocalPaths——本机路径/凭据的出口清洗全线覆盖,没有"忘了洗"的口子。
   * watch 命中的正文加「🔔 Watch 命中」前缀行——收端(群机器人/邮箱)免读全文即可分拣
   * 例行结果与关键词命中。sendViaChannels 并发群发且单通道失败不抛;这里再兜一层:
   * 装配阶段的意外(坏配置形状等)也绝不反噬调度主链,通知永远是旁路。
   */
  private async dispatchScheduleNotify(siteCmd: string, watch: string | undefined, ok: boolean, summary: string, watchHits: string[], diffText: string, pending?: QuietPendingItem[], quietHours?: string, receipt?: Receipt, recoveredNote?: string, schSource?: string): Promise<void> {
    try {
      const config = this.state.notifyConfig
      if (config === undefined) return
      const channels = buildNotifyChannels(config, { emit: (ev) => this.emitNotifyEvent(ev) })
      if (channels.length === 0) return
      const { title, body } = buildNotifyBody(
        // 任务身份(回执/轨迹卫生):来源标记进推送卡正文「任务:… · 来源 …」行,BrowserSkill
        // Controller identity 同款——同站多任务在群里可分拣是谁的
        { site: siteCmd, ...(watch !== undefined && watch.length > 0 ? { watch } : {}), ...(schSource !== undefined && schSource.length > 0 ? { source: schSource } : {}) },
        { ok, ...(summary.length > 0 ? { summary } : {}), ...(watchHits.length > 0 ? { watchHits } : {}) },
      )
      const head = watchHits.length > 0 ? `🔔 Watch 命中\n` : diffText.length > 0 ? `📊 变化\n` : ''
      // 四个追加段逐段过 scrubLocalPaths(0.1.2 发后审查发现 1):buildNotifyBody 只洗 title/body,
      // diff 摘要(快照 diff 文本)、静默期摘要(暂存的 summary 原文)、自愈说明、回执都绕过了
      // 清洗——本机路径/token 会原样发往群机器人/邮箱,出口处补洗,不依赖上游自觉
      const diffSeg = diffText.length > 0 ? scrubLocalPaths(`\n📊 与上次相比:${diffText}`) : ''
      const quietSeg = scrubLocalPaths(renderQuietDigest(pending, quietHours))
      const recoverSeg = recoveredNote !== undefined && recoveredNote.length > 0 ? scrubLocalPaths(`\n🩺 ${recoveredNote}`) : ''
      // 回执段(typed 口径进推送卡):partial/unloaded/degraded/profile 与 empty 同款按需追加——
      // 收端不读面板也能分辨「一页未尽/未渲染完/兜底近似/哪个账号档案」
      const receiptSeg = receipt !== undefined ? scrubLocalPaths(`\n🧾 回执:auth=${receipt.auth_state}${receipt.items !== undefined ? ` · ${receipt.items} 条` : ''} · ${receipt.bytes}B${receipt.empty === true ? ' · ⚠ 空结果' : ''}${receipt.partial === true ? ' · 分页未尽' : ''}${receipt.unloaded === true ? ' · ⚠ 疑似未渲染完' : ''}${receipt.degraded === true ? ' · 🛟 兜底近似' : ''}${receipt.profile !== undefined ? ` · profile ${receipt.profile}` : ''}${receipt.error_code !== undefined ? ` · ${receipt.error_code}` : ''}`) : ''
      await sendViaChannels(channels, title, head + body + recoverSeg + diffSeg + quietSeg + receiptSeg)
    } catch { /* 通知旁路:全静默降级 */ }
  }

  /** 简单并发池(登录巡检限流用)。 */
  private async runPool<T>(items: string[], concurrency: number, fn: (item: string) => Promise<T>): Promise<T[]> {
    const out: T[] = []
    let cursor = 0
    const workers = Array.from({ length: Math.min(concurrency, items.length) }, async () => {
      for (;;) {
        const i = cursor++
        if (i >= items.length) break
        out.push(await fn(items[i]))
      }
    })
    await Promise.all(workers)
    return out
  }

  private async adapterList() {
    if (this.adapterCache !== null && Date.now() - this.adapterCache.at < ADAPTER_TTL_MS) {
      return normalizeAdapterList(this.adapterCache.json)
    }
    // 写入守卫的基准时刻:本探测开跑后若有并发写(面板 refresh 期间的另一路结果、
    // 测试对 adapterCache 的直改),完成时不得盲写覆盖——init 期 fire-and-forget 的
    // updateDirectory 探测在途窗口原本 ~800ms(cliMajor 吃限流),探测改走不限流
    // 本机通道后缩到 ~10ms,该窗口与并发写从"必不撞"变"常撞",在途的旧探测结果
    // (常为空目录)会吃掉更新条目,在此收口。
    const probeStart = Date.now()
    // 2.0:JSON 信封 + 分页(上限 100/页)——翻页取全;1.x:单次平铺数组
    const major = await this.cliMajor()
    if (major >= 2) {
      const collected: unknown[] = []
      let offset = 0
      let total: number | null = null
      for (let page = 0; page < 40; page++) {
        const r = await this.runOpencliRaw(['list', '--format', 'json', '--limit', '100', '--offset', String(offset)], 30000, 4 * 1024 * 1024)
        if (r.exitCode !== 0) {
          this.lastShellError = `list(${r.exitCode})|out:${r.stdout.slice(0, 200)}|err:${r.stderr.slice(0, 200)}`
          return null
        }
        try {
          const s = r.stdout.trimStart()
          const start = s.indexOf('{')
          const j = JSON.parse(start === -1 ? s : s.slice(start)) as { ok?: boolean; data?: { commands?: unknown[]; total?: number; nextOffset?: number }; error?: { message?: string } }
          if (j.ok !== true || !Array.isArray(j.data?.commands)) throw new Error(`envelope ok=${String(j.ok)} error=${j.error?.message?.slice(0, 120) ?? '无 data.commands'}`)
          collected.push(...j.data.commands)
          total = typeof j.data.total === 'number' ? j.data.total : total
          const next = typeof j.data.nextOffset === 'number' ? j.data.nextOffset : 0
          if (next <= offset || (total !== null && collected.length >= total)) break
          offset = next
        } catch (e) {
          this.lastShellError = `json(${e instanceof Error ? e.message.slice(0, 120) : 'parse'})|head:${r.stdout.slice(0, 200)}`
          return null
        }
      }
      if (collected.length === 0) {
        this.lastShellError = 'list(2.0)|翻页后 0 命令'
        return null
      }
      // 探测期间出现更新条目则让位(见方法头 probeStart 注释);比较取严格小于——
      // probeStart→并发写常是微任务级间隔,落在同一毫秒内是常态(Windows 时钟粒度 ~15ms),
      // at==probeStart 的条目必是刚写入的新鲜值,让位而非覆盖(实测:等号让在途探测吃掉
      // mcp-resources 的 mockCache,~1/12 概率 3 用例红)
      if (this.adapterCache === null || this.adapterCache.at < probeStart) {
        this.adapterCache = { at: Date.now(), json: collected }
      }
      return normalizeAdapterList(collected)
    }
    const r = await this.runOpencliRaw(['list', '--format', 'json'], 30000, 8 * 1024 * 1024)
    if (r.exitCode !== 0) {
      // 诊断通道:把 shell 失败的原始输出带回面板(临时)
      this.lastShellError = `list(${r.exitCode})|out:${r.stdout.slice(0, 200)}|err:${r.stderr.slice(0, 200)}`
      return null
    }
    try {
      // opencli 可能把"Update available"横幅等杂物混进输出,从首个 [ 或 { 起截取
      const start = Math.min(...['[', '{'].map((c) => { const i = r.stdout.indexOf(c); return i === -1 ? Infinity : i }))
      const json: unknown = JSON.parse(Number.isFinite(start) ? r.stdout.slice(start) : r.stdout)
      // 探测期间出现更新条目则让位,严格小于(同毫秒让位,理由见 2.0 路径同款注释)
      if (this.adapterCache === null || this.adapterCache.at < probeStart) {
        this.adapterCache = { at: Date.now(), json }
      }
      return normalizeAdapterList(json)
    } catch (e) {
      this.lastShellError = `json(${e instanceof Error ? e.message.slice(0, 120) : 'parse'})|head:${r.stdout.slice(0, 200)}`
      return null
    }
  }
}

function clip(text: string, limit: number): string {
  if (text.length <= limit) return text
  return text.slice(0, limit) + `\n…(已截断,原文 ${text.length} 字符)`
}

export default OpencliService
