/**
 * dsh-opencli 浏览器半 v0.4:设置页「浏览器代理」——按 2026-09 施工图重排。
 * 五 tab(总览/命令/自动化/安全与设置/画布)+ 状态机四态 + 真数据真 RPC(零 emoji)。
 * 视觉:冷灰深色 + #4A9EFF 界面强调,品牌鲸标(DS 鲸 × CLI 提示符),统一线性图标 sprite。
 * 施工注记(详见 .design/06-状态机规格):基宽 800 自适应;响应式按容器;host v0.4 新增
 * audit-list / logs-tail / schedule-run-now / sha256 / 定时重试通知均已接线。
 * @module dsh-opencli/client
 */

import { createElement, useEffect, useRef, useState } from 'react'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type {
  AdapterDetailResult, AdapterDisableResult, AdapterInfo, AdaptersResult, ApprovalSetResult,
  AuditListResult, DaemonStartResult, IngestEvent, LoginCheckItem, LoginCheckResult, LogsTailResult, OpencliStatus, SettingsResult,
  TraceLine, TraceListResult,
} from './types.ts'
import { siteIconOf } from './site-icons.ts'
import { healthOf } from './knowledge.ts'
// 画布数据层(纯函数,任务 G):聚合/合并/分页全在这——client 只管取数与投影
import { buildCanvasData, CANVAS_PAGE_DEFAULT, type CanvasCard, type SnapshotMeta } from './canvas.ts'

export const inject = ['slots']

const DSH_URL = 'http://127.0.0.1:3080'
const RELEASES_URL = 'https://github.com/IKEASven69/dsh-opencli/releases'

type Lang = 'zh' | 'en'

/* desc 的站点数落成字面量 180:旧模板串引用了未声明变量 status——浏览器里偶然解析成
   window.status(字符串,恒回退 180),Node 一 import 即 ReferenceError;首启向导纯函数
   要随本模块进 vitest(tests/onboarding.test.ts),模块级求值必须纯净。 */
const STR = {
  zh: {
    title: 'OpenCLI 浏览器代理',
    desc: '驱动你登录态的真实浏览器 · 170+ 站 / 200+ 命令一步式执行 · 由 OpenCLI daemon 驱动',
    tabOverview: '总览', tabCommands: '命令', tabAuto: '自动化', tabSec: '安全与设置', tabCanvas: '画布',
    daemonRunning: '运行中', daemonDown: '未运行', daemonStale: '失联', bridgeOn: '已连接', bridgeOff: '未连接',
    recheck: '重新巡检', checking: '巡检中…', diagAll: '一切正常', detail: '详情',
    tryT: '试试看', trySub: '在对话里直接说,或先在这里跑一条 · 点右侧快捷/命令徽章 → 填入输入框',
    nlT: '自然语言指挥台', nlSub: '一句话描述你想做的事,确认后由插件执行(用你当前的模型,一次调用)',
    nlPh: '例:每天早9点把掘金热榜存档,AI 相关的推送给我', nlGo: '映射', nlMapping: '映射中…',
    nlApply: '确认执行', nlDiscard: '放弃', nlNoExpl: '(模型未给说明)', nlErrNoLlm: '宿主未提供 llm 服务(需要 dsh web 宿主)', nlApplied: '✓ 已执行', nfUrlPh: 'webhook URL(钉钉加签可带 &secret=…)', nfSave: '保存通道', nfTest: '测试', nfSaved: '✓ 通道已保存', nfTestOk: '✓ 测试消息已送达', nfTestFail: '✗ 测试失败',
    run: '运行', running: '跑这', copy: '复制', rerun: '重跑', copied: '已复制',
    quickT: '实用快捷', quickSub: '点击 → 填入输入框;Ctrl+Enter 直接跑',
    loginT: '登录态巡检', loginSub: '绿=已登 黄=超时 红=未登 · 状态条只亮灯,操作在这里',
    online: '在线', expired: '失效', unknown: '未知', timeout: '超时', openLogin: '打开登录',
    secT: '安全中心', secSub: '写操作全部经过你批准', lastBlocked: '最近拦截',
    gateOn: '开启', gateOff: '关闭', gateLabel: '写审批门', gateDesc: '写命令(发帖/点赞/下单)先弹审批,你点「允许」才执行;权限不明的命令一律按写处理',
    gateOnLabel: '已开启', gateOffLabel: '已关闭',
    modeReadOnly: '所有写命令直接拒绝,零打扰', modeStandard: '写命令逐条审批(推荐)',
    modeAuto: '白名单站点自动放行,其余审批', modeUnres: '全部放行(不建议)',
    auditT: '拦截审计', auditEmpty: '近 7 天没有拦截记录', auditN: (n: number) => `近 7 天拦截 ${n} 次`,
    proofT: '供应链自证', proofSub: '本插件的安全边界,可核查',
    proofNoTelemetry: '无遥测上传', proofNoCurl: '无 curl | sh', proofFailClosed: '写命令 fail-closed',
    proofClip: '输出截断防注入', proofRel: '来源 GitHub Releases', verified: '已核验',
    rateT: '限流与限域', rateSub: '保护你的账号不被风控',
    shaLine: 'sha256(本构建)', verT: '版本与更新', verNow: '当前', channel: '渠道 stable',
    checkUpd: '检查更新', upToDate: '已是最新', updAvail: '可更新到', updMarket: '经 dsh-market Update API',
    updFallback: '未装市场插件 → GitHub Releases 检查', updating: '检查中…',
    cmdT: '命令', cmdSearch: '搜索站点或命令,如:热榜 / search / bilibili',
    cmdFmt: '点命令行 → 复制调用格式;禁用适配器会即时从 systemPrompt 收缩目录(需确认)',
    knowExp: '导出知识卡', knowExpDo: '导出中…',
    timeline: '时间线', reportBtn: '生成报告', tlT: '采集快照趋势', tlSub: '每根柱 = 一次成功采集(体积=内容规模)', tlEmpty: '暂无快照——到点采集后这里会长出来', tlN: (n: number) => `${n} 份快照`, tlTotal: '累计', tlFlow: '画布卡片流(本站近 24h,替代运行史文本)',
    // 画布(任务 H+I+J):全活动卡片流;文案与色调口径见 canvasCardTone/CANVAS_SUSPECT_P
    canvasT: '活动画布', canvasSub: '轨迹 / 写操作 / 定时采集聚合为卡片 · 点卡片展开步骤回放 · 拖拽平移,滚轮缩放 · canvas_read 读到的网页画布位图会以图片步骤出现在卡片里',
    canvasEmpty: '暂无活动——跑一条命令或到点采集后,这里会长出卡片',
    canvasZoomIn: '放大', canvasZoomOut: '缩小', canvasReplay: '步骤回放', canvasMore: '加载更多',
    canvasCardsN: (n: number) => `${n} 张卡`, canvasNoShot: '无截图', canvasSuspect: '低分通过',
    canvasSuspectTip: '判定分低(0.7≤P<0.8),建议复核', cvTypeSite: '写操作', cvTypeBrowser: '浏览器', cvTypeSchedule: '定时采集',
    healthDegraded: '已知受损', healthNotice: '注意', healthIssueT: (d: string) => `上游 issue 实测(${d});点击行展开命令,受损命令优先用 opencli_* 兜底`,
    disable: '禁用', enable: '启用', commandsN: (n: number) => `${n} 命令`,
    autoT: '定时任务', autoNew: '新建', autoSub: '持久化到 dsh.schedule,重启不丢 · 失败按策略重试并通知',
    depDaemon: 'daemon 未运行——定时任务暂停执行,恢复后自动补跑', fix: '一键修复',
    last: '上次', next: '下次', retryN: (n: number) => `重试 ×${n}`, notifyOn: '通知 开', notifyOff: '通知 关',
    runNow: '立即跑', running2: '执行中…', del: '删', create: '创建',
    recT: '录制回放', recSub: '录制 site / opencli 步骤,一键回放', recStart: '开始录制', recStop: '停止录制',
    recName: '录制名,如:每日知识采集', recStep: '一条步骤,如:site zhihu hot', recAdd: '+ 加步骤', replay: '回放',
    traceT: '运行轨迹', traceSub: '每条 browser 命令逐步落盘(~/.dsh/opencli-traces),复盘"上次为什么失败"', traceEmpty: '暂无轨迹——跑一条 browser 命令后这里会长出来',
    assetT: '资产库', assetSub: '脚本 / 配方 / 规则包', assetSearch: '搜资产(如:arxiv)', assetSearchBtn: '搜索',
    builtinT: '内置脚本', recipes: '配方', rulepacks: '规则包', browse: '浏览全部',
    v4host: 'v4 host 新增;v0.3.8 已有增删/开关/立即跑',
    diagT: '诊断', diagSub: '最近一次 shell/解析失败原文,给修复与反馈用', copyDiag: '复制诊断', viewLog: '查看日志',
    noLog: 'opencli 未暴露日志文件;以下为最近诊断快照',
    more: '更多', guide: '安装引导', guideD: '装 BrowserBridge 扩展 / 启动 daemon',
    profileT: 'profile 说明', profileD: '登录态来自你日常浏览器,与 dsh 内置浏览器无关',
    jump: '跳转 dsh 设置', jumpD: '在对话里管理插件', open: '打开',
    setupT: '未检测到 opencli —— 三步接入', loading: '检测中…',
    step1: '安装 opencli CLI', step1c: 'npm i -g @jackwener/opencli(官方一等公民路径)',
    step2: '启动 daemon,装 Chrome 扩展', step2c: 'opencli daemon restart',
    step3: '回到这里点「刷新/诊断」',
    obT: '首启向导', obSub: '四层自检:CLI → daemon → BrowserBridge → 登录态;逐层修复,全绿后本卡自动隐藏',
    obCliOk: 'opencli CLI 已就绪', obCliBad: '未检测到 opencli CLI', obCliFix: '复制安装命令',
    obBridgeHint: '从 GitHub Releases 下载 BrowserBridge 扩展,到 Chrome 扩展页开发者模式加载,再回面板重巡检',
    obRelBtn: '打开 Releases',
    // 零配置降级可用面(设计 §2.2-2):无扩展时的黄色状态行——向导不再只有"装扩展"一种结局
    obZeroCfgN: (n: number) => `降级可用面:${n} 个站的只读命令无扩展也能跑(匿名);opencli_*/chrome_* 暂不可用`,
    obZeroCfgNa: '降级可用面:部分只读命令无扩展也能跑(匿名);opencli_*/chrome_* 暂不可用',
    obLoginOk: '登录态正常', obLoginPart: '登录态部分失效', obLoginBad: '登录巡检全红', obLoginNa: '尚未巡检登录态',
    siteEmpty: '适配器返回空(可能未登录或无数据)。请先在真实 Chrome 登录后重试。',
    guideS1: '安装 opencli CLI:npm i -g @jackwener/opencli',
    guideS2: '启动 daemon(opencli daemon restart),Chrome 装 BrowserBridge 扩展并登录常用站',
    guideS3: '回到本面板看健康区全绿,即可在对话里用 site / opencli_* 命令',
    profileBody1: '登录态来自你日常使用的 Chrome:插件经 OpenCLI daemon + BrowserBridge 扩展驱动「你已登录」的真实浏览器,',
    profileBody2: '与 dsh 内置浏览器无关;Cookie/会话留在本机,不经过任何第三方。',
    bridgeT: '登录态桥(Browser Use)',
    bridgeSub: '把 dsh 官方 Browser Use 接到你登录态的 Chrome:探测 opencli daemon Chrome 的 CDP 端点,填入 Chrome DevTools MCP 的 endpoint(mode: attach)即可。',
    bridgeEp: 'CDP 端点',
    bridgeNone: '未探测到 CDP —— 先启动一次浏览器会话(面板「启动 daemon」后跑一条 browser 命令)',
    bridgeCopyEp: '复制端点',
    bridgeCopyCfg: '复制桥接配置',
    bridgeWarn: '⚠ 官方自动化不经过 opencli 审批门;CDP 开放 = 本机进程可控该浏览器',
    needLogin: 'daemon 未运行或浏览器桥未连接——点「启动 daemon」后重试',
    errReq: '请求失败', confirmDisable: (n: string) => `禁用 ${n}?目录将即时从 systemPrompt 收缩。`,
    enNote: '双语:i18n key 施工(zh 默认)', statesNote: '四态:检测中/正常/依赖缺失/RPC错误 —— 详见 .design/06 状态机规格',
  },
  en: {
    title: 'OpenCLI Browser Proxy',
    desc: 'Drive your logged-in real browser · 170+ sites / 200+ commands one-shot · powered by the OpenCLI daemon',
    tabOverview: 'Overview', tabCommands: 'Commands', tabAuto: 'Automation', tabSec: 'Security', tabCanvas: 'Canvas',
    daemonRunning: 'running', daemonDown: 'not running', daemonStale: 'stale', bridgeOn: 'connected', bridgeOff: 'not connected',
    recheck: 'Re-check', checking: 'checking…', diagAll: 'All good', detail: 'detail',
    tryT: 'Try it', trySub: 'Say it in chat, or run one here · click a quick pick/command badge to fill the input',
    nlT: 'Natural-language console', nlSub: 'Describe what you want in one line, review the mapped intent, then apply (uses your current model, one call)',
    nlPh: 'e.g. archive juejin hot every day at 9am and ping me on AI news', nlGo: 'Map', nlMapping: 'Mapping…',
    nlApply: 'Apply', nlDiscard: 'Discard', nlNoExpl: '(no explanation from model)', nlErrNoLlm: 'Host provides no llm service (dsh web host required)', nlApplied: '✓ applied', nfUrlPh: 'webhook URL (dingtalk secret via &secret=…)', nfSave: 'Save', nfTest: 'Test', nfSaved: '✓ channel saved', nfTestOk: '✓ test delivered', nfTestFail: '✗ test failed',
    run: 'Run', running: 'Run', copy: 'Copy', rerun: 'Re-run', copied: 'Copied',
    quickT: 'Quick picks', quickSub: 'Click → fill the input; Ctrl+Enter to run',
    loginT: 'Login check', loginSub: 'green=logged-in yellow=timeout red=expired · status bar shows dots, actions live here',
    online: 'online', expired: 'expired', unknown: 'unknown', timeout: 'timeout', openLogin: 'Open login',
    secT: 'Security center', secSub: 'Every write goes through your approval', lastBlocked: 'Blocked (7d)',
    gateOn: 'On', gateOff: 'Off', gateLabel: 'Write approval gate', gateDesc: 'Writes (post/like/order) ask first — nothing runs until you allow; unknown-access commands are treated as writes',
    gateOnLabel: 'On', gateOffLabel: 'Off',
    modeReadOnly: 'All writes rejected, zero interruptions', modeStandard: 'Each write asks (recommended)',
    modeAuto: 'Whitelisted sites auto-run, rest ask', modeUnres: 'Allow all (not recommended)',
    auditT: 'Interception audit', auditEmpty: 'No interceptions in 7 days', auditN: (n: number) => `${n} blocked in 7 days`,
    proofT: 'Supply-chain self-attestation', proofSub: 'This plugin\u2019s security boundary, verifiable',
    proofNoTelemetry: 'no telemetry', proofNoCurl: 'no curl | sh', proofFailClosed: 'writes fail-closed',
    proofClip: 'output clipped anti-injection', proofRel: 'from GitHub Releases', verified: 'verified',
    rateT: 'Rate limit & domain fence', rateSub: 'Protects your accounts from bot controls',
    shaLine: 'sha256 (this build)', verT: 'Version & updates', verNow: 'current', channel: 'channel stable',
    checkUpd: 'Check updates', upToDate: 'up to date', updAvail: 'update available:', updMarket: 'via dsh-market Update API',
    updFallback: 'market plugin absent → check GitHub Releases', updating: 'checking…',
    cmdT: 'Commands', cmdSearch: 'Search sites or commands, e.g. trending / search / bilibili',
    cmdFmt: 'Click a command row → copy call format; disabling a adapter shrinks the systemPrompt catalog (confirm first)',
    knowExp: 'Export knowledge cards', knowExpDo: 'Exporting…',
    timeline: 'Timeline', reportBtn: 'Build report', tlT: 'Collection snapshot trend', tlSub: 'Each bar = one successful collection (size = content scale)', tlEmpty: 'No snapshots yet — they grow after scheduled runs', tlN: (n: number) => `${n} snapshots`, tlTotal: 'total', tlFlow: 'Canvas card flow (this site, last 24h — replaces text history)',
    canvasT: 'Activity canvas', canvasSub: 'Traces, write evidence and scheduled runs as cards · click a card to replay its steps · drag to pan, wheel to zoom · canvas_read bitmaps show up as image steps',
    canvasEmpty: 'No activity yet — cards appear after your first command or scheduled run',
    canvasZoomIn: 'Zoom in', canvasZoomOut: 'Zoom out', canvasReplay: 'Step replay', canvasMore: 'Load more',
    canvasCardsN: (n: number) => `${n} cards`, canvasNoShot: 'no screenshot', canvasSuspect: 'weak pass',
    canvasSuspectTip: 'low verification score (0.7≤P<0.8), worth a review', cvTypeSite: 'write', cvTypeBrowser: 'browser', cvTypeSchedule: 'schedule',
    healthDegraded: 'degraded', healthNotice: 'notice', healthIssueT: (d: string) => `confirmed upstream issues (${d}); expand the row, prefer opencli_* fallback for broken commands`,
    disable: 'Disable', enable: 'Enable', commandsN: (n: number) => `${n} cmds`,
    autoT: 'Schedules', autoNew: 'New', autoSub: 'Persisted to dsh.schedule, survives restart · retries then notifies on failure',
    depDaemon: 'daemon not running — schedules paused, will catch up when it returns', fix: 'Fix',
    last: 'last', next: 'next', retryN: (n: number) => `retry ×${n}`, notifyOn: 'notify on', notifyOff: 'notify off',
    runNow: 'Run now', running2: 'running…', del: 'Del', create: 'Create',
    recT: 'Record & replay', recSub: 'Record site / opencli steps, replay in one click', recStart: 'Record', recStop: 'Stop',
    recName: 'name, e.g. daily knowledge', recStep: 'one step, e.g. site zhihu hot', recAdd: '+ add step', replay: 'Replay',
    traceT: 'Run trace', traceSub: 'every browser command logged to ~/.dsh/opencli-traces — replay why the last run failed', traceEmpty: 'No traces yet — they appear after the first browser command',
    assetT: 'Assets', assetSub: 'scripts / recipes / rulepacks', assetSearch: 'search assets (e.g. arxiv)', assetSearchBtn: 'Search',
    builtinT: 'Builtin scripts', recipes: 'recipes', rulepacks: 'rulepacks', browse: 'Browse all',
    v4host: 'v4 host additions; add/toggle/run-now RPCs shipped in v0.3.8',
    diagT: 'Diagnostics', diagSub: 'raw last shell/parse failure, for fixes and bug reports', copyDiag: 'Copy diagnostics', viewLog: 'View log',
    noLog: 'opencli exposes no log file; latest diagnostic snapshot below',
    more: 'More', guide: 'Setup guide', guideD: 'Install BrowserBridge extension / start daemon',
    profileT: 'profile note', profileD: 'Logins come from your everyday browser, unrelated to the built-in dsh browser',
    jump: 'Open dsh settings', jumpD: 'Manage plugins from chat', open: 'Open',
    setupT: 'opencli not detected — 3 steps to connect', loading: 'detecting…',
    step1: 'Install opencli CLI', step1c: 'npm i -g @jackwener/opencli',
    step2: 'Start daemon, install Chrome extension', step2c: 'opencli daemon restart',
    step3: 'Come back and hit Refresh',
    obT: 'Onboarding wizard', obSub: 'Four-layer self-check: CLI → daemon → BrowserBridge → logins; fix layer by layer, this card hides itself once all green',
    obCliOk: 'opencli CLI ready', obCliBad: 'opencli CLI not detected', obCliFix: 'Copy install command',
    obBridgeHint: 'Download the BrowserBridge extension from GitHub Releases, load it on the Chrome extensions page in developer mode, then re-check here',
    obRelBtn: 'Open Releases',
    obZeroCfgN: (n: number) => `Degraded mode: read-only commands on ${n} sites still run without the extension (anonymous); opencli_*/chrome_* unavailable`,
    obZeroCfgNa: 'Degraded mode: some read-only commands still run without the extension (anonymous); opencli_*/chrome_* unavailable',
    obLoginOk: 'Logins healthy', obLoginPart: 'Some logins failed', obLoginBad: 'All login checks failed', obLoginNa: 'Login check not run yet',
    siteEmpty: 'Adapter returned empty (not logged in?). Log in on real Chrome first.',
    guideS1: 'Install opencli CLI: npm i -g @jackwener/opencli',
    guideS2: 'Start the daemon (opencli daemon restart), install the BrowserBridge Chrome extension and log in to your sites',
    guideS3: 'Back here — when the health card is all green, use site / opencli_* commands in chat',
    profileBody1: 'Logins come from your everyday Chrome: the plugin drives your already-logged-in browser via the OpenCLI daemon + BrowserBridge extension,',
    profileBody2: 'unrelated to the built-in dsh browser; cookies stay on this machine and never touch third parties.',
    bridgeT: 'Login-state bridge (Browser Use)',
    bridgeSub: 'Attach official Browser Use to your logged-in Chrome: probe the daemon Chrome CDP endpoint and fill it into the Chrome DevTools MCP endpoint (mode: attach).',
    bridgeEp: 'CDP endpoint',
    bridgeNone: 'No CDP found — start a browser session first (run Start daemon, then a browser command)',
    bridgeCopyEp: 'Copy endpoint',
    bridgeCopyCfg: 'Copy bridge config',
    bridgeWarn: '⚠ Official automation bypasses the opencli approval gate; an open CDP lets local processes control this browser',
    needLogin: 'daemon down or browser bridge not connected — click Start daemon and retry',
    errReq: 'request failed', confirmDisable: (n: string) => `Disable ${n}? The catalog shrinks from systemPrompt immediately.`,
    enNote: 'i18n keys throughout (zh default)', statesNote: 'four states: loading/ok/dependency/error — see .design/06',
  },
} as const

type StrKey = keyof typeof STR.zh

interface SchedItem { id: string; site: string; cron: string; createdAt: string; enabled: boolean; retry?: number; notify?: boolean; watch?: string; history?: Array<{ at: string; ok: boolean; summary: string }> }
interface AssetHit { id: string; name: string }
interface BuiltinScript { name: string; sha256: string; description: string }
interface ToastMsg { msg: string; ok: boolean }
interface Recording { id: string; name: string; steps: string[]; createdAt: string }

async function rpc<T>(method: string, args: Record<string, unknown> = {}): Promise<{ ok: boolean; value?: T; error?: { message: string } }> {
  try {
    const res = await fetch(`/api/opencli/${method}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'client-request',
        rpcId: (globalThis.crypto?.randomUUID?.() ?? String(Date.now() + Math.random())),
        method: `opencli/${method}`,
        payload: { args },
      }),
    })
    const msg = await res.json() as { result?: { ok: boolean; value?: T; error?: { message?: string } } }
    if (msg.result !== undefined && msg.result.ok) return { ok: true, value: msg.result.value }
    return { ok: false, error: { message: msg.result?.error?.message ?? `HTTP ${res.status}` } }
  } catch (e) {
    return { ok: false, error: { message: e instanceof Error ? e.message : String(e) } }
  }
}

async function copyText(text: string): Promise<boolean> {
  try {
    const clip = (globalThis as { navigator?: { clipboard?: { writeText?: (t: string) => Promise<void> } } }).navigator?.clipboard
    if (clip?.writeText !== undefined) { await clip.writeText(text); return true }
  } catch { /* fall through */ }
  try {
    const ta = document.createElement('textarea')
    ta.value = text
    ta.style.position = 'fixed'
    ta.style.opacity = '0'
    document.body.appendChild(ta)
    ta.select()
    const ok = document.execCommand('copy')
    document.body.removeChild(ta)
    return ok
  } catch { return false }
}

/* ── 统一线性图标 sprite(1.8 描边圆角)+ 品牌鲸标 ── */
const SPRITE = `<svg width="0" height="0" style="position:absolute">
<symbol id="i4-play" viewBox="0 0 24 24"><polygon points="6 3 20 12 6 21 6 3" /></symbol>
<symbol id="i4-sparkles" viewBox="0 0 24 24"><path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3z"/><path d="M19 15l.9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9L19 15z"/></symbol>
<symbol id="i4-zap" viewBox="0 0 24 24"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z" /></symbol>
<symbol id="i4-activity" viewBox="0 0 24 24"><path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" /></symbol>
<symbol id="i4-clock" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" />
  <polyline points="12 6 12 12 16 14" /></symbol>
<symbol id="i4-rec" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" />
  <circle cx="12" cy="12" r="1" /></symbol>
<symbol id="i4-layers" viewBox="0 0 24 24"><path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z" />
  <path d="M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12" />
  <path d="M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17" /></symbol>
<symbol id="i4-shield" viewBox="0 0 24 24"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
  <path d="m9 12 2 2 4-4" /></symbol>
<symbol id="i4-sliders" viewBox="0 0 24 24"><line x1="21" x2="14" y1="4" y2="4" />
  <line x1="10" x2="3" y1="4" y2="4" />
  <line x1="21" x2="12" y1="12" y2="12" />
  <line x1="8" x2="3" y1="12" y2="12" />
  <line x1="21" x2="16" y1="20" y2="20" />
  <line x1="12" x2="3" y1="20" y2="20" />
  <line x1="14" x2="14" y1="2" y2="6" />
  <line x1="8" x2="8" y1="10" y2="14" />
  <line x1="16" x2="16" y1="18" y2="22" /></symbol>
<symbol id="i4-plus" viewBox="0 0 24 24"><path d="M5 12h14" />
  <path d="M12 5v14" /></symbol>
<symbol id="i4-refresh" viewBox="0 0 24 24"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
  <path d="M21 3v5h-5" />
  <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
  <path d="M8 16H3v5" /></symbol>
<symbol id="i4-search" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8" />
  <path d="m21 21-4.3-4.3" /></symbol>
<symbol id="i4-chev-r" viewBox="0 0 24 24"><path d="m9 18 6-6-6-6" /></symbol>
<symbol id="i4-chev-d" viewBox="0 0 24 24"><path d="m6 9 6 6 6-6" /></symbol>
<symbol id="i4-alert" viewBox="0 0 24 24"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3" />
  <path d="M12 9v4" />
  <path d="M12 17h.01" /></symbol>
<symbol id="i4-check-c" viewBox="0 0 24 24"><path d="M21.801 10A10 10 0 1 1 17 3.335" />
  <path d="m9 11 3 3L22 4" /></symbol>
<symbol id="i4-ext" viewBox="0 0 24 24"><path d="M15 3h6v6" />
  <path d="M10 14 21 3" />
  <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /></symbol>
<symbol id="i4-info" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" />
  <path d="M12 16v-4" />
  <path d="M12 8h.01" /></symbol>
<symbol id="i4-monitor" viewBox="0 0 24 24"><rect x="2" y="3" rx="2" />
  <line x1="8" x2="16" y1="21" y2="21" />
  <line x1="12" x2="12" y1="17" y2="21" /></symbol>
<symbol id="i4-copy" viewBox="0 0 24 24"><rect x="8" y="8" rx="2" ry="2" />
  <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" /></symbol>
<symbol id="i4-book" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" /><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" /></symbol>
</svg>`

type IconName = 'play' | 'zap' | 'activity' | 'clock' | 'rec' | 'layers' | 'shield' | 'sliders' | 'plus' | 'refresh' | 'search' | 'chev-r' | 'chev-d' | 'alert' | 'check-c' | 'ext' | 'info' | 'monitor' | 'copy' | 'brand' | 'book' | 'sparkles'


const ava = (site: string, px = 26): ReturnType<typeof createElement> => {
  const b = siteIconOf(site)
  const inner = b !== null
    ? createElement('svg', { viewBox: '0 0 24 24', width: px - 12, height: px - 12, dangerouslySetInnerHTML: { __html: `<path fill="#fff" d="${b.p}"/>` } })
    : createElement('span', { style: { fontSize: String(px * 0.4) + 'px' } }, site.replace('site ', '').slice(0, 2))
  const style = b !== null ? { background: b.c } : { background: '#313845' }
  return createElement('span', { className: 'o4-ava', style }, inner)
}

const ic = (name: IconName, sm = false): ReturnType<typeof createElement> =>
  createElement('svg', { className: sm ? 'o4ic o4ic-s' : 'o4ic', dangerouslySetInnerHTML: { __html: `<use href="#i4-${name}"/>` } })

/* ── v0.4 样式:基宽 800 自适应;冷灰深色 + #4A9EFF ── */
const CSS = `
/* ── 设计 token 层(0.4.6 B3):色板/字阶/间距/圆角/阴影/动效时长,全面板唯一出处 ── */
.o4 {
  --c-bg: rgba(255,255,255,.03);
  --c-bg-2: rgba(255,255,255,.055);
  --c-line: rgba(255,255,255,.07);
  --c-line-2: rgba(255,255,255,.13);
  --c-fg: #F9FAFB;
  --c-fg-dim: rgba(249,250,251,.62);
  --c-fg-faint: rgba(249,250,251,.38);
  --c-accent: #5B8DEF;
  --c-accent-soft: rgba(91,141,239,.14);
  --c-ok: #34C77B;
  --c-ok-soft: rgba(52,199,123,.13);
  --c-warn: #E8A13C;
  --c-warn-soft: rgba(232,161,60,.14);
  --c-err: #E5534B;
  --c-err-soft: rgba(229,83,75,.14);
  --r-sm: 8px; --r-md: 12px; --r-lg: 16px;
  --sh-1: 0 1px 2px rgba(0,0,0,.4);
  --sh-2: 0 4px 16px rgba(0,0,0,.35);
  --sh-pop: 0 12px 40px rgba(0,0,0,.5);
  --t-fast: 120ms; --t-med: 220ms; --t-slow: 420ms;
  --ease: cubic-bezier(.32,.72,.28,1);
  --ease-spring: cubic-bezier(.34,1.4,.5,1);
}
/* 动效基建:入场 stagger(卡片依次浮起)/浮起反馈/骨架屏呼吸;reduced-motion 全关 */
@keyframes o4-rise { from { opacity:0; transform:translateY(10px) scale(.985) } to { opacity:1; transform:none } }
@keyframes o4-skeleton { 0%,100% { opacity:.35 } 50% { opacity:.75 } }
@keyframes o4-breath { 0%,100% { box-shadow:0 0 0 0 var(--c-accent-soft) } 50% { box-shadow:0 0 0 6px transparent } }
.o4 [data-anim] { animation:o4-rise var(--t-slow) var(--ease) both; }
.o4 [data-anim] > * { animation:inherit; }
.o4 .o4-skel { background:var(--c-bg-2); border-radius:var(--r-sm); animation:o4-skeleton 1.4s ease-in-out infinite; }
.o4 .o4-running { animation:o4-breath 2s var(--ease) infinite; }
@media (prefers-reduced-motion: reduce) {
  .o4 [data-anim], .o4 [data-anim] > *, .o4 .o4-skel, .o4 .o4-running { animation:none !important; }
  .o4 * { transition-duration:0ms !important; }
}
.o4-nlprev { margin-top:9px; background:var(--c-accent-soft); border:1px solid var(--c-accent); border-radius:var(--r-md); padding:12px 14px; display:flex; flex-direction:column; gap:8px; box-shadow:var(--sh-2); }
.o4-card { transition:transform var(--t-fast) var(--ease), box-shadow var(--t-med) var(--ease), border-color var(--t-med) var(--ease); }
.o4-card:hover { transform:translateY(-1px); box-shadow:var(--sh-2); border-color:var(--c-line-2); }
.o4 { width:100%; max-width:640px; margin:0 auto; display:flex; flex-direction:column; gap:11px; font-family:-apple-system,'Segoe UI','Microsoft YaHei',system-ui,sans-serif; color:var(--c-fg); position:relative; }
.o4 ::-webkit-scrollbar { width:7px; height:7px; }
.o4 ::-webkit-scrollbar-thumb { background:rgba(255,255,255,.12); border-radius:4px; }
.o4 ::-webkit-scrollbar-thumb:hover { background:rgba(255,255,255,.2); }
.o4 ::-webkit-scrollbar-track { background:transparent; }

.o4ic { width:15px; height:15px; stroke:currentColor; fill:none; stroke-width:2; stroke-linecap:round; stroke-linejoin:round; flex:none; }
.o4ic-s { width:13px; height:13px; }
.o4-head { display:flex; align-items:center; gap:12px; padding:15px 17px; background:rgba(255,255,255,.03); border:1px solid rgba(255,255,255,.07); border-radius:14px; flex-wrap:wrap; box-shadow:0 1px 2px rgba(0,0,0,.4), inset 0 1px 0 rgba(255,255,255,.04); backdrop-filter:blur(10px); }
.o4-logo { width:44px; height:44px; border-radius:13px; display:flex; align-items:center; justify-content:center; flex:none; box-shadow:0 0 0 1px rgba(255,255,255,.08), 0 6px 20px -6px rgba(0,149,255,.35); }
.o4-h1 { font-size:17px; font-weight:700; white-space:nowrap; letter-spacing:.2px; background:#F9FAFB; -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent; }
.o4-desc { font-size:11px; color:rgba(249,250,251,.55); margin-top:3px; line-height:1.55; }
.o4-hr { margin-left:auto; display:flex; align-items:center; gap:7px; flex:none; }
.o4-vchip { font-size:11px; color:rgba(249,250,251,.38); border:1px solid rgba(255,255,255,.07); border-radius:999px; padding:3px 9px; }
.o4-seg { display:flex; background:rgba(15,17,21,.7); border:1px solid rgba(255,255,255,.08); border-radius:9px; padding:2px; }
.o4-seg button { border:0; background:transparent; color:rgba(249,250,251,.55); font-size:11.5px; padding:4px 11px; border-radius:7px; cursor:pointer; white-space:nowrap; transition:all .18s ease; }
.o4-seg button.on { background:linear-gradient(135deg,#4D6BFE,#4D6BFE); color:#fff; box-shadow:0 2px 8px -2px rgba(77,107,254,.5); }
.o4-seg button:not(.on):hover { color:#F9FAFB; }
.o4-tabs { display:flex; gap:3px; background:rgba(0,0,0,.18); border:1px solid rgba(255,255,255,.06); border-radius:11px; padding:3px; backdrop-filter:blur(10px); box-shadow:inset 0 1px 3px rgba(0,0,0,.28); }
.o4-tabs button { flex:1; border:0; background:transparent; color:rgba(249,250,251,.5); font-size:12.5px; padding:7.5px 0; border-radius:8px; cursor:pointer; transition:color .15s ease, background-color .15s ease, box-shadow .15s ease; }
.o4-tabs button:hover { color:#F9FAFB; background:rgba(255,255,255,.045); }
.o4-tabs button.on { background:linear-gradient(180deg,rgba(77,107,254,.22),rgba(77,107,254,.13)); color:#fff; font-weight:600; box-shadow:inset 0 0 0 1px rgba(77,107,254,.4), inset 0 1px 0 rgba(255,255,255,.07), 0 2px 8px -3px rgba(0,0,0,.5); }
.o4-status { display:flex; align-items:center; gap:6px; flex-wrap:wrap; padding:8px 12px; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.06); border-radius:12px; backdrop-filter:blur(10px); }
.o4-chip { display:inline-flex; align-items:center; gap:5px; font-size:11px; color:rgba(249,250,251,.55); background:rgba(255,255,255,.05); border:1px solid rgba(255,255,255,.05); border-radius:999px; padding:3px 9px; transition:border-color .18s ease; }
.o4-chip:hover { border-color:rgba(255,255,255,.14); }
.o4-chip img { width:12px; height:12px; border-radius:3px; }
.o4-chip .o4ic { width:12px; height:12px; }
.o4-dot { width:7px; height:7px; border-radius:50%; flex:none; }
.o4-dot.g { background:#34C759; box-shadow:0 0 6px rgba(52,199,89,.8); }
.o4-dot.r { background:#FF453A; box-shadow:0 0 6px rgba(255,69,58,.6); }
.o4-dot.y { background:#FF9F0A; } .o4-dot.n { background:rgba(255,255,255,.14); }
.o4-sep { width:1px; height:14px; background:rgba(255,255,255,.08); }
.o4-diag { display:flex; align-items:center; gap:9px; padding:9px 13px; border-radius:12px; font-size:12px; cursor:pointer; transition:filter .18s ease; }
.o4-diag:hover { filter:brightness(1.12); }
.o4-diag.ok { background:rgba(52,199,89,.07); border:1px solid rgba(52,199,89,.25); color:#7FD89A; }
.o4-diag.bad { background:rgba(255,69,58,.07); border:1px solid rgba(255,69,58,.3); color:#FF8D85; }
.o4-diag .o4arr { margin-left:auto; color:rgba(249,250,251,.38); display:flex; align-items:center; gap:4px; }
.o4-card { position:relative; background:linear-gradient(180deg,rgba(255,255,255,.055),rgba(255,255,255,.035)); border:1px solid rgba(255,255,255,.07); border-radius:13px; padding:13px 15px; box-shadow:0 1px 2px rgba(0,0,0,.25), inset 0 1px 0 rgba(255,255,255,.045); transition:border-color .16s ease, box-shadow .16s ease; }
.o4-card:hover { border-color:rgba(255,255,255,.13); box-shadow:0 3px 12px -2px rgba(0,0,0,.4), inset 0 1px 0 rgba(255,255,255,.06); }
.o4-card + .o4-card { margin-top:11px; }
.o4-h3 { font-size:13.5px; font-weight:600; display:flex; align-items:center; gap:8px; letter-spacing:.2px; }
.o4-h3 .rt { margin-left:auto; display:flex; align-items:center; gap:8px; }
.o4-sub { font-size:11.5px; color:rgba(249,250,251,.58); margin:4px 0 10px; line-height:1.55; }
.o4-miniico { width:24px; height:24px; border-radius:8px; background:rgba(77,107,254,.14); border:1px solid rgba(77,107,254,.35); color:#8B9AFF; display:inline-flex; align-items:center; justify-content:center; flex:none; }
.o4-btn { border:0; border-radius:9px; background:linear-gradient(135deg,#4D6BFE,#4263D9); color:#fff; font-size:12px; padding:6px 14px; cursor:pointer; font-weight:600; display:inline-flex; align-items:center; gap:6px; transition:background-color .15s ease, box-shadow .15s ease, transform .15s ease; box-shadow:0 2px 10px -3px rgba(77,107,254,.45), inset 0 1px 0 rgba(255,255,255,.18); }
.o4-btn:hover { background:linear-gradient(135deg,#5E7BF0,#4D6BFE); transform:translateY(-1px); box-shadow:0 4px 14px -3px rgba(77,107,254,.5); }
.o4-btn:active { transform:translateY(0); }
.o4-btn.ghost { background:rgba(255,255,255,.045); border:1px solid rgba(255,255,255,.09); color:rgba(249,250,251,.75); font-weight:500; box-shadow:none; }
.o4-btn.ghost:hover { background:rgba(255,255,255,.08); border-color:rgba(255,255,255,.16); color:#F9FAFB; transform:translateY(-1px); }
.o4-btn.sm { padding:4px 10px; font-size:11.5px; }
.o4-btn:disabled { opacity:.5; cursor:default; transform:none; }
.o4-in { flex:1; min-width:0; background:rgba(0,0,0,.24); border:1px solid rgba(255,255,255,.1); color:#F9FAFB; border-radius:9px; padding:7px 11px; font-size:12.5px; transition:border-color .15s ease, box-shadow .15s ease; }
.o4-in:focus { outline:none; border-color:rgba(77,107,254,.6); box-shadow:0 0 0 3px rgba(77,107,254,.16); }
.o4-in.mono { font-family:ui-monospace,Consolas,monospace; }
.o4-in::placeholder { color:rgba(249,250,251,.3); }
.o4-tryout { margin-top:9px; background:rgba(0,0,0,.24); border:1px solid rgba(255,255,255,.06); border-radius:10px; padding:10px 12px; font:11.5px/1.7 ui-monospace,Consolas,monospace; color:rgba(249,250,251,.72); white-space:pre-wrap; word-break:break-word; max-height:200px; overflow:auto; box-shadow:inset 0 2px 8px rgba(0,0,0,.4); }
.o4-tryout::-webkit-scrollbar { width:6px; }
.o4-tryout::-webkit-scrollbar-thumb { background:rgba(255,255,255,.1); border-radius:3px; }
.o4-tryout .k { color:rgba(249,250,251,.38); }
.o4-tryout .lnk { color:#4D6BFE; cursor:pointer; }
.o4-tryout .lnk:hover { text-decoration:underline; }
.o4-qrow { display:flex; align-items:center; gap:8px; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.05); border-radius:9px; padding:8px 11px; font-size:12px; cursor:pointer; transition:all .16s ease; }
.o4-qrow:hover { border-color:rgba(77,107,254,.4); background:rgba(77,107,254,.07); transform:translateX(2px); }
.o4-qrow .mono { font-family:ui-monospace,Consolas,monospace; color:rgba(249,250,251,.6); font-size:10.5px; margin-left:auto; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:55%; }
.o4-sites { display:flex; flex-wrap:wrap; gap:7px; }
.o4-site { display:flex; align-items:center; gap:7px; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.05); border-radius:10px; padding:5px 10px 5px 5px; font-size:12px; transition:border-color .16s ease; }
.o4-site:hover { border-color:rgba(255,255,255,.14); }
.o4-ava { width:26px; height:26px; border-radius:8px; display:flex; align-items:center; justify-content:center; flex:none; box-shadow:inset 0 0 0 1px rgba(255,255,255,.12); }
.o4-ava img { width:15px; height:15px; }
.o4-st { font-size:10.5px; }
.o4-off { opacity:.55; }
.o4-sec { border:1px solid rgba(74,158,255,.3); background:linear-gradient(160deg,rgba(77,107,254,.1),rgba(74,158,255,.02) 55%); border-radius:14px; padding:14px 15px; box-shadow:0 8px 30px -14px rgba(77,107,254,.22); }
.o4-shield { width:44px; height:44px; border-radius:13px; background:rgba(52,199,89,.1); border:1px solid rgba(52,199,89,.35); color:#4DDB7A; display:flex; align-items:center; justify-content:center; flex:none;  }
.o4-shield .o4ic { width:21px; height:21px; }
.o4-cells { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:9px; }
.o4-cell { background:rgba(0,0,0,.18); border:1px solid rgba(255,255,255,.05); border-radius:10px; padding:8px 11px; transition:border-color .16s ease; }
.o4-cell:hover { border-color:rgba(255,255,255,.12); }
.o4-cell .l { font-size:10.5px; color:rgba(249,250,251,.38); margin-bottom:2px; }
.o4-cell .v { font-size:12.5px; font-weight:600; }
.o4-cell .v.on { color:#4DDB7A; }
.o4-cell .v.mut { color:rgba(249,250,251,.55); font-weight:400; font-size:11px; }
.o4-proof { display:flex; gap:6px; margin-top:10px; flex-wrap:wrap; }
.o4-proof span { display:inline-flex; align-items:center; gap:4px; font-size:10.5px; color:#7FD89A; background:rgba(52,199,89,.08); border:1px solid rgba(52,199,89,.2); border-radius:999px; padding:2.5px 9px; transition:all .16s ease; }
.o4-proof span:hover { background:rgba(52,199,89,.14); }
.o4-proof .o4ic { width:10px; height:10px; stroke-width:2.5; }
.o4-modes { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:8px; }
.o4-mode { position:relative; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.06); border-radius:10px; padding:9px 11px; cursor:pointer; transition:all .18s ease; }
.o4-mode:hover { border-color:rgba(255,255,255,.16); }
.o4-mode.on { border-color:rgba(77,107,254,.45); background:linear-gradient(160deg,rgba(77,107,254,.14),rgba(77,107,254,.05));  }
.o4-mode .mi { display:flex; align-items:center; gap:6px; margin-bottom:2px; color:rgba(249,250,251,.55); }
.o4-mode.on .mi { color:#8B9AFF; }
.o4-mode b { font-size:12px; }
.o4-mode span { font-size:10px; color:rgba(249,250,251,.52); line-height:1.45; display:block; margin-top:2px; }
.o4-mode .o4-mchk { position:absolute; top:7px; right:7px; width:15px; height:15px; border-radius:50%; background:linear-gradient(135deg,#4D6BFE,#4263D9); color:#fff; display:none; align-items:center; justify-content:center; box-shadow:0 2px 6px -1px rgba(77,107,254,.5); font-size:0; line-height:0; margin-top:0; }
.o4-mode.on .o4-mchk { display:flex; }
.o4-sw { width:36px; height:20px; border-radius:999px; background:rgba(255,255,255,.14); position:relative; flex:none; cursor:pointer; border:0; padding:0; transition:background .2s ease; }
.o4-sw::after { content:""; position:absolute; width:16px; height:16px; border-radius:50%; background:#fff; top:2px; left:2px; transition:left .2s cubic-bezier(.4,0,.2,1); box-shadow:0 1px 3px rgba(0,0,0,.4); }
.o4-sw.on { background:#34C759; }
.o4-sw.on::after { left:18px; }
.o4-row { display:flex; align-items:center; gap:8px; flex-wrap:wrap; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.05); border-radius:11px; padding:8px 11px; transition:all .16s ease; }
.o4-row:hover { border-color:rgba(255,255,255,.13); background:rgba(255,255,255,.05); }
.o4-row .grow { flex:1; min-width:0; }
.o4-tt { font-size:12.5px; font-weight:600; display:flex; align-items:center; gap:5px; flex-wrap:wrap; }
.o4-dd { font-size:11px; color:rgba(249,250,251,.38); margin-top:1px; }
.o4-hpts { display:flex; gap:3px; align-items:center; }
.o4-hp { width:7px; height:7px; border-radius:50%; background:#34C759; }
.o4-hp.f { background:#FF453A; }
.o4-hp.w { background:#FFB340; }
.o4-hp.n { background:rgba(255,255,255,.1); }
.o4-bdg { display:inline-flex; align-items:center; gap:4px; font-size:10px; border-radius:6px; padding:2px 7px; border:1px solid rgba(255,255,255,.08); color:rgba(249,250,251,.55); background:rgba(31,36,45,.8); }
.o4-bdg.w { color:#FFB340; border-color:rgba(255,179,64,.3); background:rgba(255,179,64,.07); }
.o4-bdg.r { color:#FF8D85; border-color:rgba(255,69,58,.3); background:rgba(255,69,58,.07); }
.o4-bdg.b { color:#8B9AFF; border-color:rgba(77,107,254,.35); background:rgba(77,107,254,.12); }
.o4-bdg.b:hover { background:rgba(77,107,254,.2); }
.o4-bdg .hn2 { font-style:normal; font-size:8.5px; color:#C58AF9; margin-left:4px; font-family:ui-monospace,monospace; }
.o4-cron { font:10.5px ui-monospace,Consolas,monospace; color:rgba(249,250,251,.55); background:rgba(0,0,0,.22); border:1px solid rgba(255,255,255,.07); border-radius:6px; padding:2px 7px; }
.o4-stat { display:flex; align-items:center; justify-content:space-between; gap:10px; padding:7.5px 0; border-bottom:1px solid rgba(255,255,255,.05); font-size:12px; }
.o4-stat:last-child { border-bottom:0; padding-bottom:2px; }
.o4-stat span { color:rgba(249,250,251,.55); }
.o4-stat b { font:500 11.5px ui-monospace,Consolas,monospace; color:rgba(249,250,251,.85); }
.o4-vrow { display:flex; align-items:center; gap:8px; padding:6px 0; border-bottom:1px solid rgba(255,255,255,.05); font-size:12px; }
.o4-vrow:last-child { border-bottom:0; padding-bottom:2px; }
.o4-vrow .o4ic { color:#4DDB7A; width:12px; height:12px; }
.o4-vrow em { margin-left:auto; font-style:normal; font-size:9.5px; color:#4DDB7A; border:1px solid rgba(52,199,89,.28); border-radius:999px; padding:1px 7px; flex:none; }
.o4-hash { display:inline-block; font:10.5px ui-monospace,Consolas,monospace; color:rgba(249,250,251,.38); background:rgba(0,0,0,.2); border:1px solid rgba(255,255,255,.06); border-radius:7px; padding:3px 9px; margin-top:8px; }
.o4-audit { display:flex; align-items:center; gap:8px; margin-top:11px; background:rgba(0,0,0,.18); border:1px solid rgba(255,255,255,.06); border-radius:10px; padding:8px 12px; font-size:11.5px; color:rgba(249,250,251,.55); flex-wrap:wrap; }
.o4-audit .lnk { margin-left:auto; color:#8B9AFF; display:flex; align-items:center; gap:4px; cursor:pointer; font-size:11.5px; }
.o4-acc { display:flex; align-items:center; gap:9px; padding:10px 13px; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.05); border-radius:11px; margin-bottom:8px; font-size:12.5px; color:rgba(249,250,251,.55); cursor:pointer; transition:all .16s ease; }
.o4-acc:hover { border-color:rgba(255,255,255,.13); color:#F9FAFB; }
.o4-acc b { color:#F9FAFB; font-weight:600; }
.o4-acc .o4arr { margin-left:auto; color:rgba(249,250,251,.38); display:flex; align-items:center; gap:5px; font-size:11.5px; }
.o4-diagopen { background:rgba(255,255,255,.045); border:1px solid rgba(255,69,58,.35); border-radius:13px; overflow:hidden;  }
.o4-diagopen .bar { display:flex; align-items:center; gap:8px; padding:10px 13px; background:rgba(255,69,58,.08); font-size:12px; color:#FF8D85; }
.o4-diagopen .bar .o4arr { margin-left:auto; color:rgba(249,250,251,.38); display:flex; align-items:center; gap:4px; }
.o4-diagopen .body { padding:11px 13px; font-size:11.5px; color:rgba(249,250,251,.55); }
.o4-kv { display:grid; grid-template-columns:105px 1fr; gap:3px 11px; font:11px/1.7 ui-monospace,Consolas,monospace; }
.o4-kv .k { color:rgba(249,250,251,.38); }
.o4-kv .v { color:rgba(249,250,251,.85); word-break:break-all; }
.o4-fixrow { display:flex; gap:8px; margin-top:9px; }
.o4-load { color:rgba(249,250,251,.58); font-size:12px; padding:10px 0; }
.o4-skel { height:11px; border-radius:5px; background:linear-gradient(90deg,#1F242D,#262C37,#1F242D); background-size:200% 100%; animation:o4shimmer 1.4s linear infinite; margin:7px 0; }
@keyframes o4shimmer { from { background-position:200% 0; } to { background-position:-200% 0; } }
.o4-note { font-size:10.5px; color:rgba(249,250,251,.38); margin-top:8px; line-height:1.6; }
/* premium 3:审美精修 */
.o4 button:focus-visible, .o4 [role='button']:focus-visible { outline:2px solid rgba(77,107,254,.55); outline-offset:2px; border-radius:8px; }
.o4-h3::after { content:""; flex:1; height:1px; margin-left:10px; background:linear-gradient(90deg,rgba(255,255,255,.09),transparent); }
.o4-h3 .rt::after { content:""; flex:none; }
.o4-cell { border-left:2px solid transparent; transition:border-left-color .18s ease, background .18s ease; }
.o4-cell:hover { border-left-color:#4D6BFE; background:rgba(255,255,255,.03); }
.o4-sub { letter-spacing:.1px; }
.o4-note::before { content:"※ "; }

/* premium 2:入场动画(阶梯式) */
.o4 > * { animation: o4in .5s cubic-bezier(.22,1,.36,1) backwards; }
.o4 > *:nth-child(1) { animation-delay: .03s; }
.o4 > *:nth-child(2) { animation-delay: .09s; }
.o4 > *:nth-child(3) { animation-delay: .15s; }
.o4 > *:nth-child(4) { animation-delay: .21s; }
.o4 > *:nth-child(5) { animation-delay: .27s; }
.o4 > *:nth-child(n+6) { animation-delay: .33s; }
@keyframes o4in { from { opacity: 0; transform: translateY(12px) scale(.995); } }
/* 卡片顶部高光(光落在上边缘) */
.o4-card, .o4-sec { position: relative; overflow: hidden; }
.o4-card::before, .o4-sec::before { content:""; position:absolute; top:0; left:12%; right:12%; height:1px;
  background:linear-gradient(90deg, transparent, rgba(255,255,255,.16), transparent); pointer-events:none; }
/* hero 健康卡:渐变网格底 + 大状态 */
.o4-hero { background:
  radial-gradient(ellipse at 85% -20%, rgba(77,107,254,.2), transparent 55%),
  radial-gradient(ellipse at 0% 120%, rgba(52,199,89,.10), transparent 50%),
  linear-gradient(180deg,#1D222B,#181C23);
  border:1px solid rgba(74,158,255,.28); border-radius:14px; padding:16px 17px;
  box-shadow:inset 0 1px 0 rgba(255,255,255,.05); }
.o4-hero .o4-big { font-size:26px; font-weight:700; letter-spacing:.3px; display:flex; align-items:center; gap:10px; line-height:1.1; }
.o4-hero .o4-big .o4-vchip { font-size:11px; }
.o4-pulse { width:12px; height:12px; border-radius:50%; background:#34C759; position:relative; flex:none; box-shadow:0 0 8px rgba(52,199,89,.55); }
.o4-pulse::after { content:""; position:absolute; inset:-5px; border-radius:50%; border:2px solid rgba(52,199,89,.45); animation:o4ping 1.8s ease-out infinite; }
@keyframes o4ping { from { transform:scale(.55); opacity:1; } to { transform:scale(1.7); opacity:0; } }
.o4-hero .o4-cell .v.big { font-size:21px; font-weight:700; display:flex; align-items:baseline; gap:5px; }
.o4-hero .o4-cell .v.big small { font-size:11px; font-weight:500; color:rgba(249,250,251,.38); }
.o4-cell .v.dim { color:rgba(249,250,251,.38); font-weight:500; }

/* 画布(任务 H+I+J):viewport 滚动平移(不走 transform——逐帧重排所有卡片,性能差)+ zoom state 控卡宽 */
.o4-cvwrap { position:relative; overflow:auto; border:1px solid rgba(255,255,255,.06); border-radius:11px; background:rgba(0,0,0,.22); cursor:grab; box-shadow:inset 0 2px 8px rgba(0,0,0,.35); }
.o4-cvwrap.drag { cursor:grabbing; }
.o4-cvflow { display:flex; flex-wrap:wrap; gap:8px; padding:10px; width:max-content; min-width:100%; min-height:100%; align-content:flex-start; }
.o4-cvcard { display:flex; flex-direction:column; gap:6px; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08); border-radius:10px; padding:8px 9px; position:relative; cursor:pointer; transition:border-color .16s ease, box-shadow .16s ease, background .16s ease; }
.o4-cvcard:hover { background:rgba(255,255,255,.06); box-shadow:0 4px 14px -6px rgba(0,0,0,.5); }
.o4-cvcard.open { background:rgba(18,21,27,.97); box-shadow:0 12px 32px -10px rgba(0,0,0,.7); }
.o4-cvsteps { display:flex; flex-direction:column; gap:5px; border-top:1px solid rgba(255,255,255,.08); padding-top:6px; }

.o4-toast { position:fixed; right:16px; bottom:16px; background:#34C759; color:#06210D; font-size:12px; font-weight:600; border-radius:10px; padding:9px 15px; z-index:50; box-shadow:0 8px 24px -6px rgba(52,199,89,.5); animation:o4toast .25s ease; }
@keyframes o4toast { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:none; } }
`

function Panel(): ReturnType<typeof createElement> {
  const [lang, setLang] = useState<Lang>('zh')
  const t = (k: StrKey): string => (STR[lang][k] ?? STR.zh[k]) as string
  const [tab, setTab] = useState<'ov' | 'cmd' | 'auto' | 'sec' | 'cv'>('ov')
  const [phase, setPhase] = useState<'loading' | 'ready'>('loading')
  const [status, setStatus] = useState<OpencliStatus | null>(null)
  const [settings, setSettings] = useState<SettingsResult | null>(null)
  const [adapters, setAdapters] = useState<AdapterInfo[] | null>(null)
  const [schedules, setSchedules] = useState<SchedItem[]>([])
  const [autoMode, setAutoMode] = useState('standard')
  const [audit, setAudit] = useState<AuditListResult | null>(null)
  const [ingest, setIngest] = useState<IngestEvent[] | null>(null)
  const [login, setLogin] = useState<LoginCheckResult | null>(null)
  const [checking, setChecking] = useState(false)
  const [toast, setToast] = useState<ToastMsg | null>(null)
  // 试试看
  const [runInput, setRunInput] = useState('site zhihu hot')
  const [running, setRunning] = useState(false)
  const [runOut, setRunOut] = useState<{ cmd: string; text: string; ok: boolean } | null>(null)
  // NL 指挥台(B1):输入→nl-intent→预览卡(逐字段可改)→确认投递 inbox 消费
  const [nlInput, setNlInput] = useState('')
  const [nlBusy, setNlBusy] = useState(false)
  const [nlErr, setNlErr] = useState('')
  const [nlPreview, setNlPreview] = useState<{ explanation: string; intent: Record<string, unknown> } | null>(null)
  const [nlDone, setNlDone] = useState('')
  // 命令
  const [query, setQuery] = useState('')
  const [details, setDetails] = useState<Record<string, AdapterDetailResult>>({})
  const [copied, setCopied] = useState<string | null>(null)
  // 自动化
  // 通知通道(D):平台下拉+URL+测试按钮(ctl notify set/test 的面板同款)
  const [nfPlatform, setNfPlatform] = useState('feishu')
  const [nfUrl, setNfUrl] = useState('')
  const [nfBusy, setNfBusy] = useState(false)
  const [schedSite, setSchedSite] = useState('')
  const [schedCron, setSchedCron] = useState('0 9 * * *')
  const [schedWatch, setSchedWatch] = useState('')
  const [schedBusy, setSchedBusy] = useState(false)
  const [recordings, setRecordings] = useState<Recording[]>(() => {
    try { return JSON.parse(localStorage.getItem('dsh-opencli-recordings') ?? '[]') as Recording[] } catch { return [] }
  })
  const [isRec, setIsRec] = useState(false)
  const [recName, setRecName] = useState('')
  const [recSteps, setRecSteps] = useState<string[]>([])
  const [assetHits, setAssetHits] = useState<AssetHit[] | null>(null)
  const [assetBusy, setAssetBusy] = useState(false)
  const [scripts, setScripts] = useState<BuiltinScript[] | null>(null)
  const [diagOpen, setDiagOpen] = useState(false)
  const [logTail, setLogTail] = useState<LogsTailResult | null>(null)
  const [starting, setStarting] = useState(false)
  const [updState, setUpdState] = useState<'idle' | 'checking' | 'latest' | string>('idle')
  const [msgInput, setMsgInput] = useState('')
  const [cdp, setCdp] = useState<{ found: boolean; endpoint: string | null; hint?: string } | null>(null)
  const [accOpen, setAccOpen] = useState<string | null>(null)
  const [toastQ, setToastQ] = useState(0)

  const t2 = (k: keyof typeof STR.zh): string => (STR[lang][k] ?? STR.zh[k]) as string

  const showToast = (msg: string, ok: boolean): void => {
    setToast({ msg, ok })
    setToastQ((q) => q + 1)
    window.setTimeout(() => { setToast((cur) => (cur !== null && cur.msg === msg ? null : cur)) }, 1800)
  }

  // SWR v2:面板数据 localStorage 暂存——重开面板秒显上次数据,后台 RPC 刷新覆盖。
  // v1 回滚教训:损坏缓存曾致空白面板,这里 try/catch 全包 + 结构校验 + 版本键,任何异常静默丢弃走正常加载。
  const SWR_KEY = 'o4swr.v2'
  const swrHydrate = (): void => {
    try {
      const raw = localStorage.getItem(SWR_KEY)
      if (raw === null) return
      const j = JSON.parse(raw) as { status?: OpencliStatus; adapters?: AdapterInfo[]; at?: number }
      if (typeof j.at === 'number' && Date.now() - j.at < 12 * 3600_000) {
        if (j.status !== null && typeof j.status === 'object') setStatus(j.status)
        if (Array.isArray(j.adapters) && j.adapters.length > 0) setAdapters(j.adapters)
      }
    } catch { /* 损坏缓存:丢弃 */ }
  }
  const swrPersist = (st: OpencliStatus | null, ad: AdapterInfo[] | null): void => {
    try {
      if (st === null || ad === null || ad.length === 0) return
      localStorage.setItem(SWR_KEY, JSON.stringify({ status: st, adapters: ad, at: Date.now() }))
    } catch { /* 配额/隐私模式:忽略 */ }
  }

  const reload = async (): Promise<void> => {
    const [st, se, ad, mode, sch, au] = await Promise.all([
      rpc<OpencliStatus>('status'),
      rpc<SettingsResult>('settings'),
      rpc<AdaptersResult>('adapters'),
      rpc<{ mode: string }>('automation-mode-get'),
      rpc<{ schedules: SchedItem[] }>('schedule-list'),
      rpc<AuditListResult>('audit-list'),
    ])
    if (st.ok && st.value !== undefined) setStatus(st.value)
    if (se.ok && se.value !== undefined) setSettings(se.value)
    if (ad.ok && ad.value !== undefined && ad.value.ok) setAdapters(ad.value.adapters)
    if (mode.ok && mode.value !== undefined) setAutoMode(mode.value.mode)
    if (sch.ok && sch.value !== undefined) setSchedules(sch.value.schedules)
    if (au.ok && au.value !== undefined) setAudit(au.value)
    setPhase('ready')
    // SWR:新鲜数据落缓存(status/adapters 是最慢的两块——目录 8MB)
    swrPersist(st.ok && st.value !== undefined ? st.value : null, ad.ok && ad.value !== undefined && ad.value.ok ? ad.value.adapters : null)
  }

  useEffect(() => { swrHydrate(); void reload() }, [])
  // watch 命中可见性:挂载时拉一次 ingest-events(总览健康区下 🔔 徽章行的数据源);
  // 拉取失败静默保持 null → 不渲染该行,绝不占错误位
  useEffect(() => {
    void rpc<{ ok: boolean; events: IngestEvent[] }>('ingest-events').then((r) => {
      if (r.ok && r.value !== undefined && Array.isArray(r.value.events)) setIngest(r.value.events)
    })
  }, [])
  // 进入自动化 tab 即拉任务列表:此前仅在增删改后拉取,面板重开/刷新后已有任务不显示(真机复现)
  useEffect(() => { if (tab === 'auto') void loadSchedules() }, [tab])
  useEffect(() => { if (tab === 'sec' && cdp === null) { void rpc<{ found: boolean; endpoint: string | null; hint?: string }>('browser-cdp').then((r) => { if (r.ok && r.value !== undefined) setCdp(r.value) }) } }, [tab, cdp])

  const runLoginCheck = async (): Promise<void> => {
    if (checking) return
    setChecking(true)
    const r = await rpc<LoginCheckResult>('login-check')
    setLogin(r.ok && r.value !== undefined ? r.value : { ok: false, checkedAt: null, results: [], error: r.error?.message ?? t2('errReq') })
    setChecking(false)
  }

  const startDaemon = async (): Promise<void> => {
    if (starting) return
    setStarting(true)
    const r = await rpc<DaemonStartResult>('daemon-start')
    setStarting(false)
    showToast(r.ok && r.value?.ok ? (r.value.message ?? 'ok') : (r.ok ? (r.value?.message ?? t2('errReq')) : (r.error?.message ?? t2('errReq'))), r.ok && r.value?.ok === true)
    await reload()
  }

  const setApproval = async (enabled: boolean): Promise<void> => {
    const r = await rpc<ApprovalSetResult>('approval-set', { request: { enabled } })
    if (r.ok && r.value !== undefined && r.value.ok) setSettings((s) => (s === null ? null : { ...s, approvalOn: enabled }))
  }

  const setMode = async (mode: string): Promise<void> => {
    const r = await rpc('automation-mode-set', { request: { mode } } as unknown as Record<string, unknown>)
    if (r.ok) setAutoMode(mode)
  }

  const runDemo = async (cmd?: string): Promise<void> => {
    const line = (cmd ?? runInput).trim()
    if (line.length === 0 || running) return
    setRunning(true)
    const r = await rpc<{ text?: string; error?: string }>('try-run', { request: { line } } as unknown as Record<string, unknown>)
    setRunning(false)
    if (r.ok && r.value !== undefined && r.value.ok) setRunOut({ cmd: line, text: r.value.text ?? '', ok: true })
    else {
      const msg = r.ok ? (r.value?.error ?? '') : (r.error?.message ?? t2('errReq'))
      setRunOut({ cmd: line, text: msg, ok: false })
    }
  }

  const fillInput = (cmd: string): void => { setRunInput(cmd); setTab('ov') }
  // NL 指挥台(B1):映射→预览→确认(投递 inbox 消费——与 ctl 完全同一条可信/审计链)
  const INT_FIELDS: Array<[string, string]> = [
    ['kind', '类型'], ['site', '站点命令'], ['cron', '频率(cron)'], ['watch', '盯的关键词'],
    ['notify', '通知'], ['retry', '重试'], ['id', '任务 id'], ['channels', '通道'],
  ]
  const nlFieldRows = (intent: Record<string, unknown>, set: (k: string, v: unknown) => void): ReturnType<typeof createElement>[] =>
    INT_FIELDS.filter(([k]) => intent[k] !== undefined).map(([k, label]) => {
      const v = intent[k]
      const text = typeof v === 'object' ? JSON.stringify(v) : String(v)
      return createElement('div', { key: k, style: { display: 'flex', gap: '8px', alignItems: 'center' } },
        createElement('span', { style: { flex: 'none', width: '86px', fontSize: '11.5px', color: 'var(--c-fg-dim)' } }, label),
        typeof v === 'object' || text.length > 42
          ? createElement('textarea', { className: 'o4-in mono', style: { flex: '1', minHeight: '30px', fontSize: '11.5px' }, value: text, onChange: (e: { target: { value: string } }) => { if (k === 'channels') { try { set(k, JSON.parse(e.target.value)) } catch { /* JSON 未写完,不更新 */ } } else set(k, e.target.value) } })
          : createElement('input', { className: 'o4-in mono', style: { flex: '1' }, value: text, onChange: (e: { target: { value: string } }) => set(k, e.target.value) }),
      )
    })
  const runNl = async (): Promise<void> => {
    const text = nlInput.trim()
    if (text.length === 0 || nlBusy) return
    setNlBusy(true); setNlErr(''); setNlPreview(null); setNlDone('')
    const r = await rpc<{ ok: boolean; explanation?: string; intent?: Record<string, unknown>; error?: string }>('nl-intent', { request: { text } } as unknown as Record<string, unknown>)
    setNlBusy(false)
    const v = r.value
    if (!r.ok || v === undefined || v.ok !== true || v.intent === undefined) {
      setNlErr(v?.error ?? r.error?.message ?? t2('nlErrNoLlm'))
      return
    }
    setNlPreview({ explanation: v.explanation ?? '', intent: v.intent })
  }
  const applyNl = async (): Promise<void> => {
    if (nlPreview === null || nlBusy) return
    setNlBusy(true); setNlErr('')
    const r = await rpc<{ ok: boolean; error?: string }>('inbox-intent', { request: { intent: nlPreview.intent } } as unknown as Record<string, unknown>)
    setNlBusy(false)
    if (r.ok && r.value?.ok !== false) {
      setNlDone(t2('nlApplied')); setNlPreview(null); setNlInput('')
    } else {
      setNlErr(r.value?.error ?? r.error?.message ?? '执行失败')
    }
  }

  const toggleDisable = async (name: string, disabled: boolean): Promise<void> => {
    if (disabled === false || window.confirm(t2('confirmDisable')(name))) {
      const r = await rpc<AdapterDisableResult>('adapter-disable', { request: { name, disabled } })
      if (r.ok && r.value !== undefined && r.value.ok) setAdapters((prev) => (prev === null ? prev : prev.map((a) => (a.name === name ? { ...a, disabled } : a))))
    }
  }

  const copyCmd = async (key: string, text: string): Promise<void> => {
    const ok = await copyText(text)
    if (ok) { setCopied(key); window.setTimeout(() => setCopied((c) => (c === key ? null : c)), 1400) }
  }

  const expandDetail = async (name: string): Promise<void> => {
    if (details[name] !== undefined) return
    const r = await rpc<AdapterDetailResult>('adapter-detail', { request: { name } })
    if (r.ok && r.value !== undefined) setDetails((d) => ({ ...d, [name]: r.value as AdapterDetailResult }))
  }

  const loadSchedules = async (): Promise<void> => {
    const r = await rpc<{ schedules: SchedItem[] }>('schedule-list')
    if (r.ok && r.value !== undefined) setSchedules(r.value.schedules)
  }
  const addSchedule = async (): Promise<void> => {
    if (schedSite.trim().length === 0 || schedBusy) return
    setSchedBusy(true)
    const watch = schedWatch.trim()
    const r = await rpc<{ id?: string; error?: string }>('schedule-add', { request: { site: schedSite.trim(), cron: schedCron, retry: 3, notify: true, ...(watch.length > 0 ? { watch } : {}) } } as unknown as Record<string, unknown>)
    setSchedBusy(false)
    if (r.ok) { setSchedSite(''); setSchedWatch(''); void loadSchedules() } else showToast(r.error?.message ?? t2('errReq'), false)
  }
  // 通知通道(D):保存当前所选平台通道;测试按钮发一条真实测试消息(用户配置的通道)。
  // dingtalk secret 支持钉在 URL query(secret=...)——保存原样,发送时由适配层处理。
  const saveNotify = async (): Promise<void> => {
    if (nfBusy || nfUrl.trim().length === 0) return
    setNfBusy(true)
    const cfg = await rpc<{ config?: { channels: Array<Record<string, unknown>> } }>('notify-config')
    const channels = (cfg.value?.config?.channels ?? []).filter((c) => c.type !== 'webhook')
    channels.push({ type: 'webhook', url: nfUrl.trim(), enabled: true, platform: nfPlatform })
    const r = await rpc<{ ok: boolean; error?: string }>('notify-config', { request: { channels } } as unknown as Record<string, unknown>)
    setNfBusy(false)
    showToast(r.ok && (r.value?.ok !== false) ? t2('nfSaved') : (r.value?.error ?? t2('errReq')), r.ok)
  }
  const testNotify = async (): Promise<void> => {
    if (nfBusy) return
    setNfBusy(true)
    const r = await rpc<{ ok: boolean; error?: string }>('notify-test')
    setNfBusy(false)
    showToast(r.ok && (r.value?.ok !== false) ? t2('nfTestOk') : (r.value?.error ?? t2('nfTestFail')), r.ok && (r.value?.ok !== false))
  }
  const toggleSchedule = async (id: string, enabled: boolean): Promise<void> => {
    const r = await rpc('schedule-toggle', { request: { id, enabled } } as unknown as Record<string, unknown>)
    if (r.ok) void loadSchedules()
  }
  const removeSchedule = async (id: string): Promise<void> => {
    const r = await rpc('schedule-remove', { request: { id } } as unknown as Record<string, unknown>)
    if (r.ok) void loadSchedules()
  }
  const exportKnowledge = async (): Promise<void> => {
    showToast(t2('knowExpDo'), true)
    const r = await rpc<{ paths?: string[] }>('knowledge-export', {} as unknown as Record<string, unknown>)
    const n = r.value?.paths?.length ?? 0
    showToast(r.ok && n > 0 ? `✓ ${n} 张知识卡 → ~/.dsh/opencli-knowledge/` : (r.error?.message ?? t2('errReq')), r.ok && n > 0)
  }
  const [timelineFor, setTimelineFor] = useState<string | null>(null)
  const toggleTimeline = (id: string): void => setTimelineFor(timelineFor === id ? null : id)
  const runScheduleNow = async (id: string): Promise<void> => {
    const r = await rpc('schedule-run-now', { p: { id } } as unknown as Record<string, unknown>)
    showToast(r.ok ? 'run now ✓' : (r.error?.message ?? t2('errReq')), r.ok)
    // 重试链路(默认 3 次 × 15s 退避,风控墙 2min)远长于单次刷新窗口——此前只在 +2.5s 刷一次,
    // 行内"上次/计数"整个周期停在旧值,与时间线的失败记录自相矛盾(GUI 走查 2026-10-08)。
    // 分散刷新覆盖完整重试周期;schedule-list 是幂等轻量 RPC,多刷无副作用。
    for (const ms of [2_500, 20_000, 40_000, 70_000, 100_000, 130_000, 160_000, 200_000, 240_000]) {
      window.setTimeout(() => { void loadSchedules() }, ms)
    }
  }

  const persistRecordings = (next: Recording[]): void => {
    setRecordings(next)
    try { localStorage.setItem('dsh-opencli-recordings', JSON.stringify(next)) } catch { /* ignore */ }
  }
  const replayRecording = async (id: string): Promise<void> => {
    const rec = recordings.find((x) => x.id === id)
    if (rec === undefined) return
    for (const step of rec.steps) {
      const s = step.trim()
      if (s.length === 0) continue
      // 命名空间迁移(2026-10):步骤头 opencli_* 是正主;browser_* 旧头继续收——localStorage
      // 里的历史录制不随迁移改写,旧步骤必须仍然可回放
      if (s.startsWith('opencli_') || s.startsWith('browser_')) await rpc('replay', { request: { step: s } } as unknown as Record<string, unknown>)
      else await rpc('try-run', { request: { line: s } } as unknown as Record<string, unknown>)
    }
    showToast('replay ✓', true)
  }
  const promoteRecording = async (id: string): Promise<void> => {
    const rec = recordings.find((x) => x.id === id)
    if (rec === undefined) return
    await rpc('promote-recording', { request: { name: rec.name, steps: rec.steps } } as unknown as Record<string, unknown>)
    void searchAssets('')
  }

  const searchAssets = async (q: string): Promise<void> => {
    if (assetBusy) return
    setAssetBusy(true)
    const r = await rpc<{ hits: AssetHit[] }>('automation-search', { request: { query: q } } as unknown as Record<string, unknown>)
    setAssetBusy(false)
    if (r.ok && r.value !== undefined) setAssetHits(r.value.hits)
  }
  const loadScripts = async (): Promise<void> => {
    if (scripts !== null) return
    const r = await rpc<{ scripts: BuiltinScript[] }>('script-catalog')
    if (r.ok && r.value !== undefined) setScripts(r.value.scripts)
  }

  const openDiag = async (): Promise<void> => {
    setDiagOpen((v) => !v)
    if (!diagOpen && logTail === null) {
      const r = await rpc<LogsTailResult>('logs-tail')
      if (r.ok && r.value !== undefined) setLogTail(r.value)
    }
  }

  const checkUpdate = async (): Promise<void> => {
    setUpdState('checking')
    try {
      const cap = await fetch('/dsh-market/api/v1/capabilities')
      if (cap.ok) {
        const upd = await fetch('/dsh-market/api/v1/updates?name=dsh-opencli')
        if (upd.ok) {
          const j = JSON.parse(await upd.text()) as { result?: { value?: { targetVersion?: string; isForwardUpdate?: boolean } } }
          const target = j.result?.value?.targetVersion
          setUpdState(target !== undefined && target !== '' ? `${t2('updAvail')} ${target}` : t2('upToDate'))
          return
        }
      }
    } catch { /* 未装市场 → 降级 */ }
    setUpdState(t2('updFallback'))
  }

  const loginResults = login?.results ?? []
  const daemonUp = status?.daemon?.running === true
  const binOk = status?.ok === true && status.bin !== null
  const loading = phase === 'loading'

  const chip = (icon: string | null, label: string, state: 'g' | 'r' | 'y' | 'n', tip?: string): ReturnType<typeof createElement> =>
    createElement('span', { className: 'o4-chip', title: tip },
      icon !== null ? createElement('img', { src: icon, alt: '' }) : null,
      label,
      createElement('span', { className: `o4-dot ${state}` }),
    )

  /* ── 总览 ── */
  const renderOverview = (): ReturnType<typeof createElement> => {
    const daemonOff = !daemonUp
    // 最近一条 watch 命中(ingest-events,倒序取首个 kind=watch-hit;无命中不渲染)
    const watchHit = (ingest ?? []).find((e) => e.kind === 'watch-hit') ?? null
    return createElement('div', null,
      // 首启向导(置顶):任一层未就绪才渲染,门槛判定在纯函数里(全绿不占位)
      shouldShowOnboarding({ status, loginResults })
        ? createElement(OnboardingWizard, {
            lang, status, adapters, loginResults, starting, running,
            onFixDaemon: () => { void startDaemon() },
            onOpenLogin: (site) => { void runDemo(`site ${site} login`) },
            onCopyCliInstall: () => { void copyText('npm i -g @jackwener/opencli').then((ok) => showToast(ok ? t2('copied') : t2('errReq'), ok)) },
          })
        : null,
      // NL 指挥台(0.4.6 B1,总览主行动):一句话 → 意图预览卡(逐字段可改)→ 确认执行
      createElement('div', { className: 'o4-card', 'data-anim': '' },
        createElement('div', { className: 'o4-h3' },
          createElement('span', { className: 'o4-miniico' }, ic('sparkles', true)),
          t2('nlT'),
          nlDone !== '' ? createElement('span', { className: 'rt', style: { color: 'var(--c-ok)', fontSize: '12px' } }, nlDone) : null,
        ),
        createElement('div', { className: 'o4-sub' }, t2('nlSub')),
        createElement('div', { style: { display: 'flex', gap: '8px' } },
          createElement('input', {
            className: 'o4-in', value: nlInput,
            placeholder: t2('nlPh'),
            onChange: (e: { target: { value: string } }) => { setNlInput(e.target.value); setNlErr(''); setNlDone('') },
            onKeyDown: (e: { key: string }) => { if (e.key === 'Enter' && !nlBusy) void runNl() },
          }),
          createElement('button', { className: 'o4-btn', disabled: nlBusy || nlInput.trim().length === 0, onClick: () => { void runNl() } }, nlBusy ? t2('nlMapping') : t2('nlGo')),
        ),
        nlErr !== '' ? createElement('div', { className: 'o4-sub', style: { color: 'var(--c-err)' } }, nlErr) : null,
        nlPreview !== null
          ? createElement('div', { className: 'o4-nlprev', 'data-anim': '' },
              createElement('div', { className: 'o4-sub' }, nlPreview.explanation || t2('nlNoExpl')),
              ...nlFieldRows(nlPreview.intent, (k, v) => {
                setNlPreview((p) => (p === null ? p : { ...p, intent: { ...p.intent, [k]: v } }))
              }),
              createElement('div', { style: { display: 'flex', gap: '8px', marginTop: '4px' } },
                createElement('button', { className: 'o4-btn', disabled: nlBusy, onClick: () => { void applyNl() } }, t2('nlApply')),
                createElement('button', { className: 'o4-btn ghost sm', onClick: () => { setNlPreview(null); setNlInput('') } }, t2('nlDiscard')),
              ),
            )
          : null,
      ),
      // 试试看(通栏)
      createElement('div', { className: 'o4-card' },
        createElement('div', { className: 'o4-h3' },
          createElement('span', { className: 'o4-miniico' }, ic('play', true)),
          t2('tryT'),
          createElement('span', { className: 'rt' },
            createElement('button', { className: 'o4-btn', disabled: running || !binOk, onClick: () => { void runDemo() } }, running ? t2('running2') : t2('run')),
          ),
        ),
        createElement('div', { className: 'o4-sub' }, t2('trySub')),
        createElement('div', { style: { display: 'flex', gap: '8px' } },
          createElement('input', { className: 'o4-in mono', value: runInput, placeholder: 'site zhihu hot', onChange: (e: { target: { value: string } }) => setRunInput(e.target.value), onKeyDown: (e: { key: string }) => { if (e.key === 'Enter') void runDemo() } }),
          createElement('button', { className: 'o4-btn ghost sm', onClick: () => { void copyText(runInput).then((ok) => showToast(ok ? t2('copied') : t2('errReq'), ok)) } }, t2('copy')),
          createElement('button', { className: 'o4-btn ghost sm', disabled: running, onClick: () => { void runDemo() } }, t2('rerun')),
        ),
        runOut !== null
          ? createElement('div', { className: 'o4-tryout' },
              createElement('span', { className: 'k' }, `$ ${runOut.cmd}\n`),
              runOut.text.length > 0 ? runOut.text : (runOut.ok ? '—' : t2('siteEmpty')),
              createElement('div', null,
                createElement('span', { className: 'lnk', onClick: () => { void copyText(`${runOut.cmd}\n${runOut.text}`) } }, t2('copy')), ' ',
                createElement('span', { className: 'lnk', onClick: () => { void runDemo(runOut.cmd) } }, t2('rerun')),
              ),
            )
          : null,
      ),
      // 快捷 + 巡检
      createElement('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(300px,1fr))', gap: '12px' } },
        createElement('div', { className: 'o4-card' },
          createElement('div', { className: 'o4-h3' }, createElement('span', { className: 'o4-miniico' }, ic('zap', true)), t2('quickT')),
          createElement('div', { className: 'o4-sub' }, t2('quickSub')),
          createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: '7px' } },
            ...[['知乎热榜', 'site zhihu hot'], ['B站搜索', 'site bilibili search'], ['GitHub 通知', 'site github notifications'], ['三站热榜', 'site_batch hot']].map(([label, cmd]) =>
              createElement('div', { key: cmd, className: 'o4-qrow', onClick: () => fillInput(cmd) },
                label, createElement('span', { className: 'mono' }, cmd), createElement('span', { className: 'o4arr', style: { color: '#5F6873', display: 'flex' } }, ic('chev-r', true)),
              )),
          ),
        ),
        createElement('div', { className: 'o4-card' },
          createElement('div', { className: 'o4-h3' }, createElement('span', { className: 'o4-miniico' }, ic('activity', true)), t2('loginT')),
          createElement('div', { className: 'o4-sub' }, t2('loginSub')),
          createElement('div', { className: 'o4-sites' },
            loginResults.length === 0
              ? createElement('span', { className: 'o4-chip' }, createElement('span', { className: 'o4-dot n' }), t2('unknown'))
              : loginResults.map((r) => createElement('span', { key: r.site, className: `o4-site${r.ok ? '' : ' o4-off'}` },
                  ava(r.site, 24),
                  r.site,
                  createElement('span', { className: 'o4-st', style: { color: r.ok ? '#34C759' : (r.timedOut ? '#FF9F0A' : '#FF453A') } }, r.ok ? t2('online') : (r.timedOut ? t2('timeout') : t2('expired'))),
                )),
          ),
          createElement('div', { style: { marginTop: '10px', display: 'flex', gap: '8px' } },
            createElement('button', { className: 'o4-btn ghost sm', disabled: checking, onClick: () => { void runLoginCheck() } }, ic('refresh', true), checking ? t2('checking') : t2('recheck')),
          ),
        ),
      ),
      // 健康卡 → hero(daemon 离线时降级为修复态)
      createElement('div', { className: 'o4-hero' },
        createElement('div', { style: { display: 'flex', alignItems: 'center', gap: '11px', marginBottom: '13px' } },
          status === null
            ? createElement('span', { className: 'o4-dot n' })
            : (daemonUp ? createElement('span', { className: 'o4-pulse' }) : createElement('span', { className: 'o4-dot r', style: { width: '12px', height: '12px' } })),
          createElement('div', { className: 'o4-big' },
            status === null ? t2('loading') : (daemonUp ? 'daemon ' + t2('daemonRunning') : 'daemon ' + t2('daemonDown')),
            status?.version ? createElement('span', { className: 'o4-vchip' }, 'v' + String(status.version).replace(/^v/, '')) : null,
          ),
          createElement('button', { className: 'o4-btn ghost sm', style: { marginLeft: 'auto' }, disabled: starting, onClick: () => { void startDaemon() } },
            ic('refresh', true), starting ? '…' : t2('fix')),
        ),
        createElement('div', { className: 'o4-cells' },
          createElement('div', { className: 'o4-cell' }, createElement('div', { className: 'l' }, 'sites'), createElement('div', { className: 'v big' }, status === null ? '…' : String(adapters?.length ?? 0), createElement('small', null, '站'))),
          createElement('div', { className: 'o4-cell' }, createElement('div', { className: 'l' }, 'Chrome 扩展'), createElement('div', { className: `v big${status?.daemon?.extension === 'connected' ? ' on' : ''}` , style: status?.daemon?.extension === 'connected' ? { fontSize: '15px' } : { fontSize: '13px', color: '#5F6873', fontWeight: 500 } }, status === null ? '…' : (status.daemon?.extension ?? t2('unknown')))),
          createElement('div', { className: 'o4-cell' }, createElement('div', { className: 'l' }, '审计(7d)'), createElement('div', { className: 'v big' }, String(audit?.count7d ?? 0), createElement('small', null, '次拦截'))),
          createElement('div', { className: 'o4-cell' }, createElement('div', { className: 'l' }, '自动化模式'), createElement('div', { className: 'v', style: { fontSize: '14px' } }, autoMode)),
        ),
        status?.ok === false && status.error !== undefined
          ? createElement('div', { className: 'o4-tryout', style: { marginTop: '9px' } }, status.error)
          : null,
        daemonOff || !binOk
          ? createElement('div', { style: { marginTop: '10px' } }, createElement('button', { className: 'o4-btn', disabled: starting, onClick: () => { void startDaemon() } }, ic('refresh', true), starting ? '…' : t2('fix')))
          : null,
      ),
      // watch 命中可见性:健康区下最近一条 🔔 徽章行(事件文本自带 🔔 前缀,点击跳自动化 tab)
      watchHit !== null
        ? createElement('div', { className: 'o4-bdg w', style: { display: 'flex', width: 'fit-content', maxWidth: '100%', fontSize: '11px', padding: '5px 11px', borderRadius: '9px', cursor: 'pointer', gap: '6px' }, title: watchHit.text, onClick: () => setTab('auto') },
            createElement('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } },
              `${traceClock(watchHit.at)} · ${watchHit.text.length > 96 ? `${watchHit.text.slice(0, 96)}…` : watchHit.text}`),
            createElement('span', { style: { display: 'flex', flex: 'none' } }, ic('chev-r', true)),
          )
        : null,
      // 安全中心摘要
      createElement('div', { className: 'o4-sec' },
        createElement('div', { style: { display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '10px' } },
          createElement('div', { className: 'o4-shield' }, ic('shield')),
          createElement('div', { style: { flex: '1' } },
            createElement('div', { style: { fontSize: '14px', fontWeight: '600' } }, t2('secT')),
            createElement('div', { className: 'o4-sub', style: { margin: '2px 0 0' } }, t2('secSub'),
              audit !== null && audit.count7d > 0 ? ` · ${t2('lastBlocked')} ${audit.count7d}` : ''),
          ),
          createElement('button', { className: 'o4-btn ghost sm', onClick: () => setTab('sec') }, t2('tabSec'), ic('chev-r', true)),
        ),
        createElement('div', { className: 'o4-cells' },
          createElement('div', { className: 'o4-cell' }, createElement('div', { className: 'l' }, t2('gateLabel')), createElement('div', { className: `v${settings?.approvalOn === true ? ' on' : ''}` }, settings?.approvalOn === true ? t2('gateOn') : t2('gateOff'))),
          createElement('div', { className: 'o4-cell' }, createElement('div', { className: 'l' }, t2('tabAuto')), createElement('div', { className: 'v' }, autoMode)),
          createElement('div', { className: 'o4-cell' }, createElement('div', { className: 'l' }, t2('rateT')), createElement('div', { className: 'v mut' }, '750ms · ×2 · 30s')),
          createElement('div', { className: 'o4-cell' }, createElement('div', { className: 'l' }, t2('lastBlocked')), createElement('div', { className: 'v' }, String(audit?.count7d ?? 0))),
        ),
        createElement('div', { className: 'o4-proof' },
          ...[t2('proofNoTelemetry'), t2('proofNoCurl'), t2('proofFailClosed'), t2('proofClip'), t2('proofRel')].map((p) =>
            createElement('span', { key: p }, ic('check-c'), p)),
        ),
      ),
      // 更多(手风琴全部可用)
      createElement('div', null,
        createElement('div', { style: { fontSize: '12px', color: '#5F6873', margin: '2px 2px 8px' } }, t2('more')),
        accOpen === 'guide' ? createElement('div', { className: 'o4-card', style: { marginBottom: '8px' } },
          createElement('div', { className: 'o4-stat' }, createElement('span', null, '1 · ', t2('guideS1')), createElement('button', { className: 'o4-btn ghost sm', onClick: () => { void copyText('npm i -g @jackwener/opencli').then((ok) => showToast(ok ? t2('copied') : t2('errReq'), ok)) } }, t2('copy'))),
          createElement('div', { className: 'o4-stat' }, createElement('span', null, '2 · ', t2('guideS2')), createElement('button', { className: 'o4-btn sm', disabled: starting, onClick: () => { void startDaemon() } }, starting ? '…' : t2('run'))),
          createElement('div', { className: 'o4-stat' }, createElement('span', null, '3 · ', t2('guideS3'))),
          createElement('div', { className: 'o4-note' }, 'DSH_OPENCLI_BIN / opencli.cmd(Windows pwsh)'),
        ) : null,
        accOpen === 'profile' ? createElement('div', { className: 'o4-card', style: { marginBottom: '8px' } },
          createElement('div', { style: { fontSize: '12px', color: '#9AA3AD', lineHeight: '1.8' } },
            t2('profileBody1'), createElement('br'), t2('profileBody2')),
        ) : null,
        createElement('div', { className: 'o4-acc', onClick: () => setAccOpen(accOpen === 'guide' ? null : 'guide') },
          createElement('b', null, t2('guide')), `—— ${t2('guideD')}`,
          createElement('span', { className: 'o4arr' }, accOpen === 'guide' ? t2('gateOff') : t2('detail'), accOpen === 'guide' ? ic('chev-d', true) : ic('chev-r', true))),
        createElement('div', { className: 'o4-acc', onClick: () => setAccOpen(accOpen === 'profile' ? null : 'profile') },
          createElement('b', null, t2('profileT')), `—— ${t2('profileD')}`,
          createElement('span', { className: 'o4arr' }, accOpen === 'profile' ? t2('gateOff') : t2('detail'), accOpen === 'profile' ? ic('chev-d', true) : ic('chev-r', true))),
        createElement('div', { className: 'o4-acc', onClick: () => { window.open(DSH_URL, '_blank') } },
          createElement('b', null, t2('jump')), `—— ${t2('jumpD')}`,
          createElement('span', { className: 'o4arr' }, t2('open'), ic('ext', true))),
      ),
      daemonOff && !loading
        ? createElement('div', { className: 'o4-diag bad', onClick: () => { void startDaemon() } },
            ic('alert', true), t2('depDaemon'),
            createElement('span', { className: 'o4arr' }, t2('fix'), ic('chev-r', true)),
          )
        : null,
    )
  }

  /* ── 命令 ── */
  const renderCommands = (): ReturnType<typeof createElement> => {
    const q = query.trim().toLowerCase()
    const filtered = (adapters ?? []).filter((a) => q.length === 0 || a.name.toLowerCase().includes(q) || a.commands.some((c) => c.toLowerCase().includes(q)) || (a.sample ?? '').toLowerCase().includes(q))
    return createElement('div', null,
      createElement('div', { style: { display: 'flex', gap: '9px', alignItems: 'center', marginBottom: '6px' } },
        createElement('div', { style: { flex: '1', display: 'flex', alignItems: 'center', gap: '8px', background: '#14171C', border: '1px solid #313845', borderRadius: '9px', padding: '0 12px' } },
          createElement('span', { style: { color: '#5F6873', display: 'flex' } }, ic('search', true)),
          createElement('input', { className: 'o4-in', style: { border: '0', padding: '8px 0' }, placeholder: t2('cmdSearch'), value: query, onChange: (e: { target: { value: string } }) => setQuery(e.target.value) }),
        ),
        createElement('span', { style: { fontSize: '11.5px', color: '#5F6873' } }, `${adapters?.length ?? 0} · ${(adapters ?? []).filter((a) => a.disabled !== true).length}`),
        createElement('button', { className: 'o4-btn ghost sm', title: t2('knowExp'), onClick: () => { void exportKnowledge() } }, ic('book', true), t2('knowExp')),
      ),
      createElement('div', { className: 'o4-note', style: { margin: '0 0 10px' } }, t2('cmdFmt')),
      createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } },
        loading ? createElement('div', { className: 'o4-load' }, t2('loading')) : null,
        !loading && filtered.map((a) => {
          const detail = details[a.name]
          // 站点健康度徽章:degraded=琥珀"已知受损"(title 列 issues),notice=灰"注意";
          // unsupported 不渲染(本就不在目录);正常站不入表也不占位——不给"没有消息"付 UI 成本
          const h = healthOf(a.name)
          const hBadge = h !== null && h.status === 'degraded'
            ? createElement('span', { className: 'o4-bdg w', title: `${t2('healthIssueT')(h.updated)}\n${h.issues.join('\n')}` }, `⚠ ${t2('healthDegraded')}`)
            : h !== null && h.status === 'notice'
              ? createElement('span', { className: 'o4-bdg', title: `${t2('healthIssueT')(h.updated)}\n${h.issues.join('\n')}` }, t2('healthNotice'))
              : null
          return createElement('div', { key: a.name },
            createElement('div', { className: `o4-row${a.disabled === true ? ' o4-off' : ''}`, onClick: () => { void expandDetail(a.name) } },
              ava(a.name),
              createElement('div', { className: 'grow' },
                createElement('div', { className: 'o4-tt' }, a.name, ' ', a.commands.slice(0, 3).map((c) => createElement('span', { key: c, className: 'o4-bdg b', title: `site ${a.name} ${c} — 点击复制`, onClick: (e: { stopPropagation: () => void }) => { e.stopPropagation(); fillInput(`site ${a.name} ${c}`) } }, c))),
                createElement('div', { className: 'o4-dd' }, t2('commandsN')(a.commandCount), a.disabled === true ? ' · disabled' : ''),
              ),
              hBadge,
              a.disabled === true ? null : createElement('span', { className: 'o4-bdg w' }, `write ${a.kinds.filter((k) => k === 'write').length}`),
              createElement('button', { className: 'o4-btn ghost sm', onClick: (e: { stopPropagation: () => void }) => { e.stopPropagation(); void toggleDisable(a.name, a.disabled !== true) } }, a.disabled === true ? t2('enable') : t2('disable')),
            ),
            details[a.name] !== undefined
              ? createElement('div', { className: 'o4-card', style: { marginTop: '6px', padding: '8px 12px' } },
                  detail === undefined
                    ? createElement('div', { className: 'o4-load' }, t2('loading'))
                    : detail.ok
                      ? detail.commands.map((c) => {
                          const cmdText = `site ${a.name} ${c.name}`
                          const key = `${a.name}:${c.name}`
                          return createElement('div', { key: c.name, className: 'o4-qrow', title: `${cmdText}\n${c.description}`, onClick: () => { void copyCmd(key, cmdText) } },
                            createElement('span', null, c.name),
                            createElement('span', { className: 'o4-bdg', style: { marginLeft: '6px' } }, c.access),
                            createElement('span', { style: { color: '#5F6873', fontSize: '11px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: '1' } }, c.description),
                            copied === key ? createElement('span', { className: 'o4-bdg b' }, t2('copied')) : createElement('span', { style: { color: '#5F6873', display: 'flex' } }, ic('copy', true)),
                          )
                        })
                      : createElement('div', { className: 'o4-load' }, detail.error ?? t2('errReq')),
                )
              : null,
          )
        }),
        !loading && filtered.length === 0 ? createElement('div', { className: 'o4-load' }, '—') : null,
      ),
    )
  }

  /* ── 自动化 ── */
  const renderAutomation = (): ReturnType<typeof createElement> => {
    return createElement('div', null,
      createElement('div', { className: 'o4-card' },
        createElement('div', { className: 'o4-h3' },
          createElement('span', { className: 'o4-miniico' }, ic('clock', true)), t2('autoT'),
          createElement('span', { className: 'rt' }, createElement('button', { className: 'o4-btn sm', onClick: () => fillInput('') }, ic('plus', true), t2('autoNew'))),
        ),
        createElement('div', { className: 'o4-sub' }, t2('autoSub')),
        !daemonUp ? createElement('div', { className: 'o4-diag bad', style: { marginBottom: '9px' }, onClick: () => { void startDaemon() } }, ic('alert', true), t2('depDaemon'), createElement('span', { className: 'o4arr' }, t2('fix'), ic('chev-r', true))) : null,
        createElement('div', { style: { display: 'flex', gap: '8px', marginBottom: '10px', flexWrap: 'wrap' } },
          createElement('input', { className: 'o4-in', placeholder: 'site zhihu hot', value: schedSite, onChange: (e: { target: { value: string } }) => setSchedSite(e.target.value) }),
          createElement('input', { className: 'o4-in mono', style: { maxWidth: '110px' }, placeholder: 'cron', value: schedCron, onChange: (e: { target: { value: string } }) => setSchedCron(e.target.value) }),
          createElement('input', { className: 'o4-in', style: { maxWidth: '172px' }, placeholder: '🔔 watch 关键词', title: '逗号分隔,命中即通知', value: schedWatch, onChange: (e: { target: { value: string } }) => setSchedWatch(e.target.value) }),
          createElement('button', { className: 'o4-btn sm', disabled: schedBusy, onClick: () => { void addSchedule() } }, t2('create')),
        ),
        // 通知通道节(D):平台下拉+URL+保存+测试(与 ctl notify set/test 同链)
        createElement('div', { style: { display: 'flex', gap: '8px', marginBottom: '10px', flexWrap: 'wrap', alignItems: 'center' } },
          createElement('select', { className: 'o4-in', style: { maxWidth: '108px' }, value: nfPlatform, onChange: (e: { target: { value: string } }) => setNfPlatform(e.target.value) },
            ...([['feishu', '飞书'], ['dingtalk', '钉钉'], ['wecom', '企业微信'], ['telegram', 'Telegram'], ['generic', '通用']] as Array<[string, string]>).map(([v, label]) => createElement('option', { key: v, value: v }, label))),
          createElement('input', { className: 'o4-in mono', style: { flex: '1', minWidth: '160px' }, placeholder: t2('nfUrlPh'), value: nfUrl, onChange: (e: { target: { value: string } }) => setNfUrl(e.target.value) }),
          createElement('button', { className: 'o4-btn sm', disabled: nfBusy || nfUrl.trim().length === 0, onClick: () => { void saveNotify() } }, t2('nfSave')),
          createElement('button', { className: 'o4-btn ghost sm', disabled: nfBusy, onClick: () => { void testNotify() } }, t2('nfTest')),
        ),
        createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } },
          schedules.length === 0 ? createElement('div', { className: 'o4-load' }, '—') : null,
          schedules.map((s) => {
            const hist = s.history ?? []
            const dots = [0, 1, 2, 3, 4].map((i) => {
              const h = hist[i]
              // 静默失败(真实性判定拦截,exit 0 但内容无效)用琥珀区分硬失败(红)
              const cls = h === undefined ? ' n' : h.ok ? '' : h.summary.includes('静默失败') || h.summary.includes('⚠') ? ' w' : ' f'
              return createElement('span', { key: i, className: `o4-hp${cls}`, title: h?.summary ?? '' })
            })
            const okN = hist.filter((h) => h.ok).length
            return createElement('div', { key: s.id, className: 'o4-row' },
              ava(s.site.replace('site ', '').split(/\s+/)[0]),
              createElement('div', { className: 'grow', style: { minWidth: '140px' } },
                createElement('div', { className: 'o4-tt' }, s.site),
                s.watch !== undefined ? createElement('div', { className: 'o4-bdg w', style: { marginTop: '3px', display: 'inline-flex' } }, `🔔 ${s.watch}`) : null,
              ),
              createElement('span', { className: 'o4-hpts' }, dots),
              createElement('button', { className: 'o4-sw' + (s.enabled ? ' on' : ''), title: s.enabled ? 'enabled' : 'disabled', onClick: () => { void toggleSchedule(s.id, !s.enabled) } }),
              createElement('div', { className: 'meta' },
                createElement('span', { className: 'o4-cron' }, s.cron),
                createElement('span', null, `${t2('last')} ${hist[0]?.at?.slice(5, 16) ?? '—'}`,
                  // verdict 真实着色:空史不挂符号;有失败全红 ✗;有成功绿 ✓——此前恒亮 ✓,
                  // 与时间线红失败行同屏自相矛盾(GUI 走查 2026-10-08)
                  createElement('span', { style: { color: hist.length === 0 ? 'inherit' : (okN > 0 ? '#34C759' : '#FF6B63') } },
                    ` · ${okN}/${hist.length || 0}${hist.length === 0 ? '' : (okN > 0 ? ' ✓' : ' ✗')}`)),
                createElement('span', { className: 'o4-bdg b' }, t2('retryN')(s.retry ?? 3)),
                createElement('span', { className: 'o4-bdg' }, s.notify === false ? t2('notifyOff') : t2('notifyOn')),
                createElement('span', { style: { flex: '1' } }),
                createElement('button', { className: 'o4-btn ghost sm', onClick: () => { void runScheduleNow(s.id) } }, t2('runNow')),
                createElement(TimelineToggle, { id: s.id, lang, label: t2('timeline'), site: s.site }),
                createElement('button', { className: 'o4-btn ghost sm', onClick: () => { void removeSchedule(s.id) } }, t2('del')),
              ),
                          )
          }),
        ),
        createElement('div', { className: 'o4-note' }, t2('v4host')),
      ),
      // 运行轨迹:browser 命令全量 JSONL 落盘的时间线(轨迹回放,模块级组件经 props 拿 lang)
      createElement(TracePanel, { lang }),
      createElement('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(300px,1fr))', gap: '12px' } },
        createElement('div', { className: 'o4-card' },
          createElement('div', { className: 'o4-h3' }, createElement('span', { className: 'o4-miniico' }, ic('rec', true)), t2('recT')),
          createElement('div', { className: 'o4-sub' }, t2('recSub')),
          createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } },
            recordings.map((rec) => createElement('div', { key: rec.id, className: 'o4-row' },
              createElement('div', { className: 'grow' },
                createElement('div', { className: 'o4-tt' }, rec.name),
                createElement('div', { className: 'o4-dd' }, `${rec.steps.length} 步 · ${rec.steps[0] ?? ''}`),
              ),
              createElement('button', { className: 'o4-btn ghost sm', onClick: () => { void replayRecording(rec.id) } }, t2('replay')),
              createElement('button', { className: 'o4-btn ghost sm', onClick: () => { void promoteRecording(rec.id) } }, '→'),
            )),
          ),
          isRec
            ? createElement('div', { style: { marginTop: '9px', display: 'flex', gap: '6px', flexWrap: 'wrap' } },
                createElement('input', { className: 'o4-in', style: { maxWidth: '150px' }, placeholder: t2('recName'), value: recName, onChange: (e: { target: { value: string } }) => setRecName(e.target.value) }),
                createElement('input', { className: 'o4-in', style: { maxWidth: '190px' }, placeholder: t2('recStep'), value: recSteps[recSteps.length - 1] ?? '', onChange: (e: { target: { value: string } }) => setRecSteps([...recSteps.slice(0, -1), e.target.value]) }),
                createElement('button', { className: 'o4-btn ghost sm', onClick: () => setRecSteps([...recSteps, '']) }, t2('recAdd')),
                createElement('button', { className: 'o4-btn sm', onClick: () => { setIsRec(false) } }, t2('recStop')),
              )
            : createElement('div', { style: { marginTop: '9px' } }, createElement('button', { className: 'o4-btn ghost sm', onClick: () => { setIsRec(true); setRecSteps([]) } }, ic('rec', true), t2('recStart'))),
        ),
        createElement('div', { className: 'o4-card' },
          createElement('div', { className: 'o4-h3' }, createElement('span', { className: 'o4-miniico' }, ic('layers', true)), t2('assetT')),
          createElement('div', { className: 'o4-sub' }, t2('assetSub')),
          createElement('div', { style: { display: 'flex', gap: '7px', marginBottom: '9px' } },
            createElement('input', { className: 'o4-in', placeholder: t2('assetSearch'), onChange: (e: { target: { value: string } }) => { if (e.target.value.length >= 2) void searchAssets(e.target.value) } }),
            createElement('button', { className: 'o4-btn ghost sm', onClick: () => { void loadScripts() } }, t2('browse')),
          ),
          createElement('div', { className: 'o4-cells', style: { gridTemplateColumns: 'repeat(3,1fr)' } },
            createElement('div', { className: 'o4-cell' }, createElement('div', { className: 'l' }, t2('builtinT')), createElement('div', { className: 'v' }, String(scripts?.length ?? '—'))),
            createElement('div', { className: 'o4-cell' }, createElement('div', { className: 'l' }, t2('recipes')), createElement('div', { className: 'v' }, String(assetHits?.length ?? '—'))),
            createElement('div', { className: 'o4-cell' }, createElement('div', { className: 'l' }, t2('rulepacks')), createElement('div', { className: 'v' }, '—')),
          ),
        ),
      ),
    )
  }

  /* ── 安全与设置 ── */
  const renderSecurity = (): ReturnType<typeof createElement> => {
    const modes: Array<[string, string, IconName]> = [
      ['read-only', t2('modeReadOnly'), 'activity'],
      ['standard', t2('modeStandard'), 'shield'],
      ['autonomous', t2('modeAuto'), 'zap'],
      ['unrestricted', t2('modeUnres'), 'alert'],
    ]
    const diagText = `bin: ${status?.bin ?? '—'} | version: ${status?.version ?? '—'} | mode: ${autoMode} | approval: ${settings?.approvalOn === true ? 'on' : 'off'} | daemon: ${daemonUp ? 'running' : 'down'}`
    return createElement('div', null,
      createElement('div', { className: 'o4-sec' },
        createElement('div', { style: { display: 'flex', alignItems: 'flex-start', gap: '12px', marginBottom: '12px' } },
          createElement('div', { className: 'o4-shield' }, ic('shield')),
          createElement('div', { style: { flex: '1' } },
            createElement('div', { style: { fontSize: '14px', fontWeight: '600' } }, t2('gateLabel')),
            createElement('div', { className: 'o4-sub', style: { margin: '3px 0 0' } }, t2('gateDesc')),
          ),
          createElement('div', { style: { textAlign: 'center' } },
            createElement('button', { className: `o4-sw${settings?.approvalOn === true ? ' on' : ''}`, style: { transform: 'scale(1.12)' }, onClick: () => { void setApproval(!(settings?.approvalOn === true)) } }),
            createElement('div', { style: { fontSize: '10px', color: settings?.approvalOn === true ? '#34C759' : '#5F6873', marginTop: '4px' } }, settings?.approvalOn === true ? t2('gateOnLabel') : t2('gateOffLabel')),
          ),
        ),
        createElement('div', { className: 'o4-modes' },
          modes.map(([m, desc, icon]) => createElement('div', { key: m, className: `o4-mode${autoMode === m ? ' on' : ''}`, onClick: () => { void setMode(m) } },
            createElement('span', { className: 'mi' }, ic(icon as IconName, true), createElement('b', null, m)),
            createElement('span', null, desc),
            createElement('span', { className: 'o4-mchk' }, ic('check-c', true)),
          )),
        ),
      ),
      createElement('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(320px,1fr))', gap: '12px', marginBottom: '12px' } },
        createElement('div', { className: 'o4-card' },
          createElement('div', { className: 'o4-h3' }, createElement('span', { className: 'o4-miniico' }, ic('sliders', true)), t2('rateT')),
          createElement('div', { className: 'o4-sub' }, t2('rateSub')),
          createElement('div', { className: 'o4-stat' }, createElement('span', null, 'minDelay'), createElement('b', null, '750 ms')),
          createElement('div', { className: 'o4-stat' }, createElement('span', null, 'maxConcurrency'), createElement('b', null, '2')),
          createElement('div', { className: 'o4-stat' }, createElement('span', null, 'burst / cooldown'), createElement('b', null, '3 / 30 s')),
          createElement('div', { className: 'o4-stat' }, createElement('span', null, 'maxPagesPerRun'), createElement('b', null, '20')),
          createElement('div', { className: 'o4-stat' }, createElement('span', null, 'authProfiles'), createElement('b', null, 'allowedDomains ✓')),
        ),
        createElement('div', { className: 'o4-card' },
          createElement('div', { className: 'o4-h3' }, createElement('span', { className: 'o4-miniico' }, ic('check-c', true)), t2('proofT')),
          createElement('div', { className: 'o4-sub' }, t2('proofSub')),
          ...[t2('proofNoTelemetry'), t2('proofNoCurl'), t2('proofFailClosed'), t2('proofClip'), t2('proofRel')].map((p) =>
            createElement('div', { key: p, className: 'o4-vrow' }, ic('check-c'), createElement('span', null, p), createElement('em', null, t2('verified')))),
          createElement('span', { className: 'o4-hash' }, `${t2('shaLine')}: ${settings?.sha256 ?? '—'}`),
        ),
      ),
      createElement('div', { className: 'o4-card', style: { marginBottom: '11px' } },
        createElement('div', { className: 'o4-h3' }, createElement('span', { className: 'o4-miniico' }, ic('ext', true)), t2('bridgeT')),
        createElement('div', { className: 'o4-sub' }, t2('bridgeSub')),
        createElement('div', { className: 'o4-kv' },
          createElement('span', { className: 'k' }, t2('bridgeEp')),
          createElement('span', { className: 'v' }, cdp && cdp.found ? cdp.endpoint : t2('bridgeNone')),
        ),
        cdp && cdp.found ? createElement('div', { className: 'o4-fixrow' },
          createElement('button', { className: 'o4-btn ghost sm', onClick: () => { void copyText(String(cdp.endpoint)).then((ok) => showToast(ok ? t2('copied') : t2('errReq'), ok)) } }, t2('bridgeCopyEp')),
          createElement('button', { className: 'o4-btn ghost sm', onClick: () => {
            const nl = String.fromCharCode(10);
            const cfg = "- name: '@deepseek-ai/dsh-browser-use'" + nl + "- name: '@deepseek-ai/dsh-experimental-browser-use-chrome-devtools-mcp'" + nl + "  config:" + nl + "    mode: attach" + nl + "    endpoint: " + String(cdp.endpoint);
            void copyText(cfg).then((ok) => showToast(ok ? t2('copied') : t2('errReq'), ok));
          } }, t2('bridgeCopyCfg')),
        ) : null,
        createElement('div', { className: 'o4-note' }, t2('bridgeWarn')),
      ),
            createElement('div', { className: 'o4-card', style: { display: 'flex', alignItems: 'center', gap: '11px', marginBottom: '12px' } },
        createElement('span', { className: 'o4-miniico' }, ic('refresh', true)),
        createElement('div', { style: { flex: '1' } },
          createElement('div', { style: { fontSize: '12.5px', fontWeight: '600' } }, t2('verT')),
          createElement('div', { style: { fontSize: '11px', color: '#5F6873' } }, `${t2('verNow')} v0.4.1 · ${t2('channel')} · ${t2('updMarket')}`),
        ),
        createElement('span', { className: 'o4-bdg' }, typeof updState === 'string' && updState !== 'idle' && updState !== 'checking' ? updState : t2('upToDate')),
        createElement('button', { className: 'o4-btn ghost sm', disabled: updState === 'checking', onClick: () => { void checkUpdate() } }, updState === 'checking' ? t2('updating') : t2('checkUpd')),
        createElement('button', { className: 'o4-btn ghost sm', onClick: () => { window.open(RELEASES_URL, '_blank') } }, ic('ext', true)),
      ),
      diagOpen
        ? createElement('div', { className: 'o4-diagopen' },
            createElement('div', { className: 'bar' }, ic('alert', true), t2('diagT'), createElement('span', { className: 'o4arr', onClick: () => { void openDiag() } }, t2('detail'), ic('chev-d', true))),
            createElement('div', { className: 'body' },
              createElement('div', { className: 'o4-kv' },
                createElement('span', { className: 'k' }, t2('diagSub')),
                createElement('span', { className: 'v' }, logTail?.hint ?? t2('noLog')),
              ),
              createElement('div', { className: 'o4-tryout', style: { marginTop: '8px' } }, (logTail?.lines ?? []).join('\n') || diagText),
              createElement('div', { className: 'o4-fixrow' },
                createElement('button', { className: 'o4-btn sm', onClick: () => { void startDaemon() } }, t2('fix')),
                createElement('button', { className: 'o4-btn ghost sm', onClick: () => { void copyText(diagText + '\n' + (logTail?.lines ?? []).join('\n')) } }, t2('copyDiag')),
              ),
            ),
          )
        : createElement('div', { className: 'o4-diag ok', onClick: () => { void openDiag() } }, ic('check-c', true), t2('diagAll'), createElement('span', { className: 'o4arr' }, t2('detail'), ic('chev-d', true))),
      createElement('div', null,
        createElement('div', { className: 'o4-acc', onClick: () => { void openDiag() } }, createElement('b', null, t2('guide')), `—— ${t2('guideD')}`, createElement('span', { className: 'o4arr' }, t2('detail'), ic('chev-r', true))),
        createElement('div', { className: 'o4-acc' }, createElement('b', null, t2('profileT')), `—— ${t2('profileD')}`, createElement('span', { className: 'o4arr' }, t2('detail'), ic('chev-r', true))),
      ),
    )
  }

  const loadingBlock = (): ReturnType<typeof createElement> =>
    createElement('div', { className: 'o4-card' },
      createElement('div', { className: 'o4-load' }, t2('loading')),
      createElement('div', { className: 'o4-skel' }), createElement('div', { className: 'o4-skel', style: { width: '70%' } }), createElement('div', { className: 'o4-skel', style: { width: '85%' } }),
    )

  return createElement('div', null,
    createElement('div', { style: { display: 'none' }, dangerouslySetInnerHTML: { __html: SPRITE } }),
    createElement('style', null, CSS),
    createElement('div', { className: 'o4' },
      // 页头(品牌鲸标)
      createElement('div', { className: 'o4-head' },
        createElement('div', { className: 'o4-logo', title: 'OpenCLI × DeepSeek', dangerouslySetInnerHTML: { __html:
          '<svg viewBox="0 0 64 64" width="46" height="46"><rect width="64" height="64" rx="14" fill="#0a0a0f"/><defs><linearGradient id="o4gl" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#00e5a0"/><stop offset=".5" stop-color="#00b4d8"/><stop offset="1" stop-color="#7b61ff"/></linearGradient></defs>' +
          '<path fill="#fff" fill-rule="evenodd" transform="translate(14,23) scale(1.5)" d="M23.748 4.651c-.254-.124-.364.113-.512.233-.051.04-.094.09-.137.137-.372.397-.806.657-1.373.626-.829-.046-1.537.214-2.163.848-.133-.782-.575-1.248-1.247-1.548-.352-.155-.708-.311-.955-.65-.172-.24-.219-.509-.305-.774-.055-.16-.11-.323-.293-.35-.2-.031-.278.136-.356.276-.313.572-.434 1.202-.422 1.84.027 1.436.633 2.58 1.838 3.393.137.094.172.187.129.323-.082.28-.18.553-.266.833-.055.179-.137.218-.328.14a5.5 5.5 0 0 1-1.737-1.179c-.857-.828-1.631-1.743-2.597-2.46a12 12 0 0 0-.689-.47c-.985-.957.13-1.743.387-1.836.27-.098.094-.433-.778-.428-.872.003-1.67.295-2.687.685a3 3 0 0 1-.465.136 9.6 9.6 0 0 0-2.883-.101c-1.885.21-3.39 1.1-4.497 2.622C.082 8.776-.231 10.854.152 13.02c.403 2.284 1.568 4.175 3.36 5.653 1.857 1.533 3.997 2.284 6.438 2.14 1.482-.085 3.132-.284 4.994-1.86.47.234.962.328 1.78.398.629.058 1.235-.031 1.705-.129.735-.155.684-.836.418-.961-2.155-1.004-1.682-.595-2.112-.926 1.095-1.295 2.768-3.598 3.284-6.733.05-.346.115-.834.108-1.114-.004-.171.035-.238.23-.257a4.2 4.2 0 0 0 1.545-.475c1.397-.763 1.96-2.016 2.093-3.517.02-.23-.004-.467-.247-.588M11.58 18.168c-2.088-1.642-3.101-2.183-3.52-2.16-.39.024-.32.472-.234.763.09.288.207.487.371.74.114.167.192.416-.113.603-.673.416-1.842-.14-1.897-.168-1.361-.801-2.5-1.86-3.301-3.306-.775-1.393-1.225-2.888-1.299-4.482-.02-.385.094-.522.477-.592a4.7 4.7 0 0 1 1.53-.038c2.131.311 3.946 1.264 5.467 2.774.868.86 1.525 1.887 2.202 2.89.72 1.066 1.494 2.082 2.48 2.915.348.291.626.513.892.677-.802.09-2.14.109-3.055-.615zm1.001-6.44a.306.306 0 0 1 .415-.287.3.3 0 0 1 .113.074.3.3 0 0 1 .086.214c0 .17-.136.307-.308.307a.303.303 0 0 1-.306-.307m3.11 1.596c-.2.081-.4.151-.591.16a1.25 1.25 0 0 1-.798-.254c-.274-.23-.47-.358-.551-.758a1.7 1.7 0 0 1 .015-.588c.07-.327-.007-.537-.238-.727-.188-.156-.426-.199-.689-.199a.6.6 0 0 1-.254-.078.253.253 0 0 1-.114-.358 1 1 0 0 1 .192-.21c.356-.202.767-.136 1.146.016.352.144.618.408 1.001.782.392.451.462.576.685.915.176.264.336.536.446.848.066.194-.02.353-.25.45"/>' +
          '<path d="M9 10.5 L15.5 15 L9 19.5" fill="none" stroke="url(#o4gl)" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/><rect x="18.5" y="10.5" width="3.6" height="9" rx="1.1" fill="url(#o4gl)"/></svg>' } }),
        createElement('div', null,
          createElement('div', { className: 'o4-h1' }, t2('title')),
          createElement('div', { className: 'o4-desc' }, t2('desc')),
        ),
        createElement('div', { className: 'o4-hr' },
          createElement('div', { className: 'o4-seg' },
            createElement('button', { className: lang === 'zh' ? 'on' : '', onClick: () => setLang('zh') }, '中文'),
            createElement('button', { className: lang === 'en' ? 'on' : '', onClick: () => setLang('en') }, 'EN'),
          ),
        ),
      ),
      // Tabs(第五个 tab「画布」:全活动卡片流,任务 H+I+J)
      createElement('div', { className: 'o4-tabs' },
        ...([['ov', t2('tabOverview')], ['cmd', t2('tabCommands')], ['auto', t2('tabAuto')], ['sec', t2('tabSec')], ['cv', t2('tabCanvas')]] as Array<[string, string]>).map(([k, label]) =>
          createElement('button', { key: k, className: tab === k ? 'on' : '', onClick: () => setTab(k as typeof tab) }, label)),
      ),
      // 状态条(指示灯)
      createElement('div', { className: 'o4-status' },
        createElement('span', { className: 'o4-chip', title: `daemon ${status === null ? t2('loading') : (daemonUp ? t2('daemonRunning') : t2('daemonDown'))}` }, createElement('span', { className: `o4-dot ${status === null ? 'n' : (daemonUp ? 'g' : 'r')}` }), 'daemon'),
        createElement('span', { className: 'o4-chip', title: `BrowserBridge ${status?.daemon?.extension ?? t2('unknown')}` }, createElement('span', { className: `o4-dot ${status?.daemon?.extension === 'connected' ? 'g' : 'n'}` }), 'Bridge'),
        createElement('span', { className: 'o4-chip', title: 'Chrome' }, ic('monitor', true)),
        createElement('span', { className: 'o4-sep' }),
        ...(loginResults.length > 0
          ? loginResults.map((r) => chip(null, r.site, r.ok ? 'g' : (r.timedOut ? 'y' : 'r'), `${r.site}: ${r.ok ? t2('online') : (r.timedOut ? t2('timeout') : t2('expired'))}${r.detail !== null ? ` · ${r.detail}` : ''}`))
          : [chip(null, 'zhihu', 'n'), chip(null, 'bilibili', 'n'), chip(null, 'github', 'n')]),
        createElement('span', { className: 'o4-chip', style: { marginLeft: 'auto', cursor: 'pointer', boxSizing: 'border-box', height: '23px', justifyContent: 'center' }, onClick: () => { void runLoginCheck() }, title: t2('recheck') }, ic('refresh', true)),
      ),
      // 诊断条
      createElement('div', { className: `o4-diag ${status === null ? 'ok' : (daemonUp && binOk ? 'ok' : 'bad')}`, onClick: () => { void openDiag() } },
        ic(status === null ? 'refresh' : (daemonUp && binOk ? 'check-c' : 'alert'), true),
        status === null ? t2('loading') : (daemonUp && binOk ? t2('diagAll') : t2('depDaemon')),
        createElement('span', { className: 'o4arr' }, t2('detail'), ic('chev-d', true)),
      ),
      // 内容
      loading
        ? loadingBlock()
        : tab === 'ov' ? renderOverview() : tab === 'cmd' ? renderCommands() : tab === 'auto' ? renderAutomation() : tab === 'cv' ? createElement(CanvasPanel, { lang }) : renderSecurity(),
    ),
    toast !== null ? createElement('div', { className: 'o4-toast', style: { background: toast.ok ? '#4DDB7A' : '#FF453A' } }, toast.msg) : null,
  )
}

export function apply(ctx: ClientContext): void {
  ctx.slots.inject('settings.section', () => ctx.slots.register(
    { name: 'settings.section', id: 'opencli-proxy', order: 41, label: '浏览器代理' },
    () => createElement(Panel),
  ))
}

/* ── 步骤截图墙(轨迹行/时间线行共用):trace-shot RPC 直取 base64 缩略图 ── */

/** 轨迹行 + 可选步骤截图绝对路径(types.ts 的 TraceLine 不含 shot——宿主读侧原样透传,
 *  老行无此字段;与 src/index.ts 的 ShotTraceLine 同款可选约定,types.ts 不动)。 */
type ShotTraceLine = TraceLine & { shot?: string }

/** trace-shot 结果的模块级缓存:path → Promise(成功 {data,mime} / 失败 null)。
 *  缓存 Promise 而非结果:并发挂载同路径缩略图时共享同一在途请求,绝无二次 RPC。
 *  时间线 15s 轮询会重挂行组件(key 含序号,新行插入即整体移位),组件级 state 兜不住
 *  "同一行只加载一次";失败也缓存——面板会话内文件不会凭空长出来,重试只是白撞通道。 */
const shotCache = new Map<string, Promise<{ data: string; mime: string } | null>>()

function fetchShot(path: string): Promise<{ data: string; mime: string } | null> {
  const hit = shotCache.get(path)
  if (hit !== undefined) return hit
  // mime 兜底 image/png:宿主 trace-shot 落的就是 PNG(screenshot 命令 .png 扩展名),缺省防御
  const p = rpc<{ ok: boolean; data?: string; mime?: string }>('trace-shot', { request: { path } }).then((r) =>
    r.ok && r.value?.ok === true && typeof r.value.data === 'string' && r.value.data.length > 0
      ? { data: r.value.data, mime: typeof r.value.mime === 'string' && r.value.mime.length > 0 ? r.value.mime : 'image/png' }
      : null)
  shotCache.set(path, p)
  // 封顶淘汰(评审发现:模块级缓存无上界,长驻面板持续累积 base64 大串):插入序近似 LRU,
  // 单条约可达 ~10MB(8MB 文件 base64),40 条已远超一次时间线的可视需要
  if (shotCache.size > 40) {
    const oldest = shotCache.keys().next().value
    if (oldest !== undefined) shotCache.delete(oldest)
  }
  return p
}

/**
 * 步骤截图缩略图:默认 48px 圆角小图(画布缩放经 px 传放大/缩小的边长);失败静默占位色块
 * (绝不占错误位——截图只是复盘增强);点击切全尺寸(height auto / maxHeight 420px)再点收起,
 * 纯前端状态不发请求。onClick stopPropagation:轨迹行点击是展开输出摘录,放大缩略图不该误触。
 */
function ShotThumb(props: { path: string; px?: number }): ReturnType<typeof createElement> {
  const { path, px = 48 } = props
  // undefined=加载中 / null=失败占位 / 对象=可渲染
  const [shot, setShot] = useState<{ data: string; mime: string } | null | undefined>(undefined)
  const [zoom, setZoom] = useState(false)
  useEffect(() => {
    let alive = true
    void fetchShot(path).then((s) => { if (alive) setShot(s) })
    return () => { alive = false }
  }, [path])
  if (shot === null) {
    return createElement('span', { title: '截图不可用', style: { width: `${px}px`, height: `${px}px`, borderRadius: '6px', background: 'rgba(255,255,255,.08)', flex: 'none' } })
  }
  if (shot === undefined) {
    return createElement('span', { style: { width: `${px}px`, height: `${px}px`, borderRadius: '6px', background: 'rgba(255,255,255,.05)', flex: 'none' } })
  }
  return createElement('img', {
    src: `data:${shot.mime};base64,${shot.data}`,
    alt: '',
    title: zoom ? '收起' : '放大',
    onClick: (e: { stopPropagation: () => void }) => { e.stopPropagation(); setZoom(!zoom) },
    style: zoom
      ? { height: 'auto', maxHeight: '420px', maxWidth: '100%', borderRadius: '8px', cursor: 'zoom-out', flex: 'none', objectFit: 'contain' }
      : { height: `${px}px`, borderRadius: '6px', cursor: 'zoom-in', flex: 'none' },
  })
}

/** 时间线历史行:宿主 schedule-history 契约为 {at,ok,summary}(评审清理:曾有可选 shot
 *  字段但宿主从不发送——site 命令在 daemon 浏览器执行,插件侧截图只会拍到无关页面,死代码已删)。 */
interface HistRow { at: string; ok: boolean; summary: string }

/** 时间线面板:某定时任务的快照趋势(体积=采集规模的粗代理)+ 画布卡片流(时间线融合,任务 I)。
 *  数据源 schedule-history;卡片流来自画布页装配(fetchCanvasPage 复用)按站点过滤——
 *  旧时间线是画布的一个"趋势视角":柱状图看规模走势,卡片流看每步现场。 */
/** 行内时间线开关:按钮+面板自带局部状态(不依赖父组件 state,杜绝跨实例展开失效)。 */
function TimelineToggle(props: { id: string; lang: Lang; label: string; site: string }): ReturnType<typeof createElement> {
  const { id, lang, label, site } = props
  const [open, setOpen] = useState(false)
  const tt = (k: keyof typeof STR.zh): string => (STR[lang][k] ?? STR.zh[k]) as string
  return createElement('div', { style: { display: 'contents' } },
    createElement('button', { className: 'o4-btn ghost sm', onClick: () => setOpen(!open) }, label),
    open ? createElement(TimelinePanel, { id, lang, site }) : null,
  )
}

function TimelinePanel(props: { id: string; lang: Lang; site: string }): ReturnType<typeof createElement> {
  const { id, lang, site } = props
  // 模块级组件拿不到 Panel 内部的 t2/lang——经 props 自建同款查表
  const tt = (k: keyof typeof STR.zh): string => (STR[lang][k] ?? STR.zh[k]) as string
  const [snaps, setSnaps] = useState<Array<{ at: string; bytes: number; file: string }> | null>(null)
  const [hist, setHist] = useState<HistRow[]>([])
  const [err, setErr] = useState('')
  // 画布卡片流(时间线融合):本站近 24h 活动卡。挂载取一次——卡流是历史快照,15s 轮询
  // 刷的是运行史/趋势柱;轨迹文件在运行中追加,重开面板即见,不值得为此每 15s 重拉全量源
  const [flow, setFlow] = useState<CanvasCard[] | null>(null)
  useEffect(() => {
    let alive = true
    void fetchCanvasPage(0).then((cards) => { if (alive) setFlow(cards) })
    return () => { alive = false }
  }, [])
  useEffect(() => {
    let alive = true
    const load = async (): Promise<void> => {
      const r = await rpc<{ history: HistRow[]; snapshots?: Array<{ at: string; bytes: number; file: string }> }>('schedule-history', { p: { id } } as unknown as Record<string, unknown>)
      if (!alive) return
      if (r.ok) { setHist(r.value?.history ?? []); setSnaps(r.value?.snapshots ?? []) } else setErr(r.error?.message ?? 'err')
    }
    void load()
    // 展开期间 15s 轮询:立即跑的重试链路最长 ~2.5min,不轮询则面板停在打开瞬间的旧史
    const timer = window.setInterval(() => { void load() }, 15_000)
    return () => { alive = false; window.clearInterval(timer) }
  }, [id])
  if (err.length > 0) return createElement('div', { className: 'o4-card', style: { padding: '8px 12px', margin: '4px 0 8px', borderRadius: '10px', flex: '1 1 100%' } }, createElement('div', { className: 'o4-load' }, err))
  const bars = snaps ?? []
  const maxB = Math.max(1, ...bars.map((b) => b.bytes))
  // 卡片流:有本站卡(近 24h)→ 替代纯文本历史行;无 → 保留文本史兜底(轨迹轮转/为空时
  // 不空窗——快照可以比轨迹活得久,时间线不能因此断流)
  const flowCards = cardsForSite(flow, site).slice(0, 6)
  // flex:'1 1 100%' 独占整行——toggle 用 display:contents 把本卡塞进 .o4-row flex 行,
  // 不占满则被挤到行右侧溢出对话框裁切(GUI 走查 2026-10-08)
  return createElement('div', { className: 'o4-card', style: { padding: '10px 12px', margin: '4px 0 8px', borderRadius: '10px', flex: '1 1 100%' } },
    createElement('div', { className: 'o4-h3', style: { fontSize: '12px' } }, ic('activity', true), tt('tlT'),
      createElement('span', { style: { marginLeft: 'auto' } },
        createElement('button', { className: 'o4-btn ghost sm', onClick: () => { void (async () => { const r = await rpc<{ path?: string }>('report-build', { request: { id } } as unknown as Record<string, unknown>); window.setTimeout(() => {}, 0); void navigator.clipboard?.writeText(String(r.value?.path ?? '')).catch(() => {}) })() } }, tt('reportBtn')))),
    createElement('div', { className: 'o4-sub', style: { margin: '3px 0 8px' } }, tt('tlSub')),
    createElement('div', { style: { display: 'flex', alignItems: 'flex-end', gap: '3px', height: '46px', marginBottom: '6px' } },
      bars.length === 0 ? createElement('div', { className: 'o4-load' }, tt('tlEmpty')) : null,
      bars.slice(-30).map((b, i) => createElement('div', {
        key: b.file, title: `${b.at.slice(0, 19).replace('T', ' ')} · ${(b.bytes / 1024).toFixed(1)} KB`,
        style: { flex: '1', minWidth: '4px', height: `${Math.max(6, Math.round((b.bytes / maxB) * 44))}px`, background: 'linear-gradient(180deg,#4D6BFE,#4263D9)', borderRadius: '2px 2px 0 0', opacity: 0.55 + (i % 5) * 0.09 },
      })),
    ),
    createElement('div', { style: { fontSize: '10px', color: '#5F6873' } }, bars.length > 0 ? `${tt('tlN')(bars.length)} · ${(bars.reduce((s, b) => s + b.bytes, 0) / 1024).toFixed(0)} KB ${tt('tlTotal')}` : ''),
    flowCards.length > 0
      ? createElement('div', { style: { marginTop: '8px' } },
          createElement('div', { style: { fontSize: '10px', color: '#5F6873', margin: '0 0 4px' } }, tt('tlFlow')),
          createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: '4px' } },
            ...flowCards.map((c) => {
              const tone = canvasCardTone(c)
              return createElement('div', { key: c.id, title: `${c.command ?? c.id}\n${c.at}`, style: { display: 'flex', gap: '6px', alignItems: 'center', background: 'rgba(255,255,255,.03)', border: '1px solid rgba(255,255,255,.05)', borderRadius: '8px', padding: '4px 7px' } },
                createElement('span', { className: `o4-dot ${tone === 'ok' ? 'g' : (tone === 'fail' ? 'r' : 'y')}`, style: { flex: 'none' } }),
                createElement('span', { style: { flex: 'none', fontSize: '10px', color: '#5F6873', fontFamily: 'ui-monospace,Consolas,monospace' } }, canvasStamp(c.at)),
                c.shot !== undefined && c.shot.length > 0 ? createElement(ShotThumb, { path: c.shot, px: 28 }) : null,
                createElement('span', { style: { flex: '1', minWidth: '0', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: '10.5px', fontFamily: 'ui-monospace,Consolas,monospace', color: 'rgba(249,250,251,.72)' } }, c.command ?? c.id),
                c.ms > 0 ? createElement('span', { style: { flex: 'none', fontSize: '10px', color: '#5F6873' } }, `${c.ms}ms`) : null,
              )
            }),
          ),
        )
      : createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: '2px', marginTop: '8px' } },
          ...hist.slice(0, 5).map((h, i) => createElement('div', { key: i, style: { fontSize: '10.5px', color: 'rgba(249,250,251,.6)', display: 'flex', gap: '6px', alignItems: 'center' } },
            createElement('span', null, h.at.slice(5, 16).replace('T', ' ')),
            createElement('span', { style: { color: h.ok ? '#34C759' : '#FF8D85', flex: '1', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }, h.summary || (h.ok ? 'ok' : 'fail')),
          )),
        ),
  )
}

/** 运行轨迹卡:browser 命令逐步 JSONL 落盘的时间线(时间/命令/exit 色点/耗时),点行展开输出摘录。数据源 trace-list。 */
/** at 是 UTC ISO:直接 slice 会与本地时钟错位(东八区差 8h),显示前转本地 HH:MM:SS(非法时间原样回退)。 */
const traceClock = (iso: string): string => {
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso.slice(11, 19)
  const p = (n: number): string => String(n).padStart(2, '0')
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
}

function TracePanel(props: { lang: Lang }): ReturnType<typeof createElement> {
  const { lang } = props
  // 模块级组件拿不到 Panel 内部的 t2/lang——经 props 自建同款查表(TimelinePanel 先例)
  const tt = (k: keyof typeof STR.zh): string => (STR[lang][k] ?? STR.zh[k]) as string
  const [rows, setRows] = useState<ShotTraceLine[] | null>(null)
  const [err, setErr] = useState('')
  const [openIdx, setOpenIdx] = useState<number | null>(null)
  const [busy, setBusy] = useState(false)
  const load = async (): Promise<void> => {
    if (busy) return
    setBusy(true)
    const r = await rpc<TraceListResult>('trace-list', { request: { limit: 50 } })
    setBusy(false)
    if (r.ok && r.value !== undefined && r.value.ok) { setRows(r.value.traces); setErr('') }
    else setErr(r.ok ? (r.value?.error ?? tt('errReq')) : (r.error?.message ?? tt('errReq')))
  }
  useEffect(() => {
    let alive = true
    void (async () => {
      const r = await rpc<TraceListResult>('trace-list', { request: { limit: 50 } })
      if (!alive) return
      if (r.ok && r.value !== undefined && r.value.ok) setRows(r.value.traces)
      else setErr(r.ok ? (r.value?.error ?? tt('errReq')) : (r.error?.message ?? tt('errReq')))
    })()
    return () => { alive = false }
  }, [])
  return createElement('div', { className: 'o4-card' },
    createElement('div', { className: 'o4-h3' },
      createElement('span', { className: 'o4-miniico' }, ic('activity', true)), tt('traceT'),
      createElement('span', { className: 'rt' }, createElement('button', { className: 'o4-btn ghost sm', disabled: busy, onClick: () => { void load() } }, ic('refresh', true), busy ? tt('checking') : tt('recheck'))),
    ),
    createElement('div', { className: 'o4-sub' }, tt('traceSub')),
    err.length > 0 ? createElement('div', { className: 'o4-load' }, err) : null,
    rows !== null && rows.length === 0 && err.length === 0 ? createElement('div', { className: 'o4-load' }, tt('traceEmpty')) : null,
    rows === null && err.length === 0 ? createElement('div', { className: 'o4-load' }, tt('loading')) : null,
    createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: '6px' } },
      ...(rows ?? []).slice(0, 50).map((r, i) => {
        // 步骤截图:轨迹行的可选 shot 绝对路径;标记用文字 [图](零 emoji 规则),缩略图点击可放大
        const shot = typeof r.shot === 'string' && r.shot.length > 0 ? r.shot : null
        return createElement('div', { key: `${r.at}-${i}`, style: { display: 'contents' } },
        createElement('div', { className: 'o4-qrow', style: { alignItems: 'center' }, title: `${r.cmd}\n${r.at}`, onClick: () => { setOpenIdx(openIdx === i ? null : i) } },
          createElement('span', { className: `o4-dot ${r.exitCode === 0 ? 'g' : 'r'}`, style: { flex: 'none' } }),
          createElement('span', { style: { flex: 'none', fontSize: '10.5px', color: '#5F6873', fontFamily: 'ui-monospace,Consolas,monospace' } }, traceClock(r.at)),
          shot !== null ? createElement('span', { title: '本步自动截图', style: { flex: 'none', fontSize: '10.5px', color: '#8B9AFF', fontFamily: 'ui-monospace,Consolas,monospace' } }, '[图]') : null,
          shot !== null ? createElement(ShotThumb, { path: shot }) : null,
          createElement('span', { style: { flex: '1', minWidth: '0', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: '11px', fontFamily: 'ui-monospace,Consolas,monospace', color: 'rgba(249,250,251,.75)' } }, r.cmd),
          createElement('span', { className: 'o4-bdg', style: { flex: 'none' } }, `exit ${r.exitCode}`),
          createElement('span', { style: { flex: 'none', fontSize: '10.5px', color: '#5F6873' } }, `${r.ms}ms`),
          createElement('span', { style: { color: '#5F6873', display: 'flex', flex: 'none' } }, ic(openIdx === i ? 'chev-d' : 'chev-r', true)),
        ),
        openIdx === i ? createElement('div', { className: 'o4-tryout', style: { marginTop: '-2px', marginBottom: '4px' } },
          r.outHead.length > 0 ? r.outHead : '—') : null,
      ) })
    ),
  )
}

/* ── 画布纯函数(任务 H+I+J,导出供 tests/canvas.test.ts 直接单测;组件渲染部分留给
       GUI 人工验收——client 侧无组件测试基建,shouldShowOnboarding 先例) ── */

/** 黄档阈值:SystemOne 判定门是 0.7(低于即"内容可疑",canvas.ts 的 P 捕获只认"实测有效"
 *  标注,故画布见到的 p 恒 ≥0.7);0.7~0.8 属"低分飘过"——面板侧黄档提示复核。
 *  纯展示口径,不拦截任何执行(拦截权归宿主判定门)。 */
export const CANVAS_SUSPECT_P = 0.8

/** 卡片状态色档:红 fail(ok=false,任一步失败/被拒)/ 黄 warn(exit 成功但判定分低)/ 绿 ok。
 *  fail 优先:失败卡的 P 值无意义,不许绿灯掩盖失败。 */
export function canvasCardTone(c: CanvasCard): 'ok' | 'fail' | 'warn' {
  if (!c.ok) return 'fail'
  if (c.p !== null && c.p < CANVAS_SUSPECT_P) return 'warn'
  return 'ok'
}

/** 展开回放的步骤序列:合并卡带 steps 逐字用;单步卡(数据层省字段)从卡面字段合成一步——
 *  展开交互对两类卡一致,用户不该关心"这卡是几步合并出来的"。 */
export function stepsOfCard(c: CanvasCard): Array<{ cmd: string; ok: boolean; ms: number; shot?: string }> {
  if (c.steps !== undefined) return c.steps
  return [{ cmd: c.command ?? c.id, ok: c.ok, ms: c.ms, ...(c.shot !== undefined && c.shot.length > 0 ? { shot: c.shot } : {}) }]
}

/** 时间线融合过滤:取属于某站点(定时任务行首词)的卡。schedule/evidence 卡的 site 都是
 *  首词形态(数据层契约),browser 卡无站点天然排除;输入容忍 'site zhihu hot' 前缀与整行命令。 */
export function cardsForSite(cards: ReadonlyArray<CanvasCard> | null | undefined, site: string): CanvasCard[] {
  const key = site.trim().replace(/^site\s+/, '').split(/\s+/)[0] ?? ''
  if (key.length === 0) return []
  return (cards ?? []).filter((c) => c.site === key)
}

/** 画布渲染门槛:有卡才渲染卡片流,空走 canvasEmpty 占位(shouldShowOnboarding 同款纯函数门槛)。 */
export function shouldRenderCanvasFlow(cards: ReadonlyArray<CanvasCard> | null | undefined): boolean {
  return Array.isArray(cards) && cards.length > 0
}

/** 缩放步进:0.5~2.0 闭区间、step 0.1;×10 取整杀浮点漂移(0.7 连 +0.1 三次必须 =1.0,
 *  不然按钮禁用判断(zoom>=2)会因 1.9999… 永不触发)。 */
export function nextZoom(z: number, dir: number): number {
  return Math.round(Math.min(2, Math.max(0.5, z + dir * 0.1)) * 10) / 10
}

/** 卡片时间戳:本地时区 MM-DD HH:MM(at 是 UTC ISO,直接 slice 与本地时钟错位——
 *  traceClock 同款教训,画布带上日期因为卡片跨天)。非法时间原样截断兜底。 */
const canvasStamp = (iso: string): string => {
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso.slice(0, 16).replace('T', ' ')
  const p = (n: number): string => String(n).padStart(2, '0')
  return `${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`
}

/**
 * 画布页装配:现有 RPC 拼 buildCanvasData(任务 G 纯数据层)的三源之二——
 * trace-list(轨迹,含步骤截图路径)+ schedule-list × schedule-history(列目录 zip 出
 * SnapshotMeta:目录项给 at/bytes/file,站点命令原文来自任务行,canvas.ts 头注约定的拼法)。
 * 证据源缺席:evidence-list 只回文件元数据(无 command/exit/截图),臆造 ok 会给写操作卡
 * 假染色——宁缺毋假;宿主侧 canvas RPC 接线后此处一处换成单 RPC 即全源。
 * 全防御:rpc 永不 reject、buildCanvasData 脏输入不抛,本函数恒出数组(空页=翻页到底,非错误)。
 */
async function fetchCanvasPage(offset: number): Promise<CanvasCard[]> {
  const [tr, sch] = await Promise.all([
    rpc<TraceListResult>('trace-list', { request: { limit: 500 } }),
    rpc<{ schedules: SchedItem[] }>('schedule-list'),
  ])
  const traces = tr.ok && tr.value?.ok === true && Array.isArray(tr.value.traces) ? tr.value.traces : []
  const snaps: SnapshotMeta[] = []
  // 快照 zip 封顶 20 个任务:每个任务一发 schedule-history,任务表失控时不让画布拖垮面板
  const schedules = sch.ok && Array.isArray(sch.value?.schedules) ? sch.value.schedules.slice(0, 20) : []
  if (schedules.length > 0) {
    const hs = await Promise.all(schedules.map((s) =>
      rpc<{ snapshots?: Array<{ at: string; bytes: number; file: string }> }>('schedule-history', { p: { id: s.id } } as unknown as Record<string, unknown>)))
    schedules.forEach((s, i) => {
      const siteCmd = s.site.replace(/^site\s+/, '')
      for (const sp of hs[i]?.value?.snapshots ?? []) {
        snaps.push({ at: sp.at, site: siteCmd, bytes: sp.bytes, file: sp.file })
      }
    })
  }
  return buildCanvasData(traces, [], snaps, undefined, { offset, limit: CANVAS_PAGE_DEFAULT })
}

/**
 * 画布面板(第五个 tab):全活动卡片流。
 * 平移:viewport overflow:auto,拖拽改 scrollLeft/scrollTop(不走 transform——每帧重排
 *   全部卡片,卡片多了肉眼可见地卡);
 * 缩放:zoom state 控卡宽/缩略图边长(0.5~2.0,step 0.1),滚轮走 native listener
 *   ({passive:false})——React 根委托把 wheel 注册成 passive,preventDefault 无效会连滚
 *   外层滚动区;
 * 分页:每页 50 张由数据层管(buildCanvasData offset/limit),"加载更多"按页累加(单次
 *   渲染批次恒 ≤50),截图缩略图复用 shotCache(ShotThumb 现成链路);
 * 展开:点卡片展开完整步骤序列(stepsOfCard),再点收起;拖拽位移 >3px 后的 click 视为
 *   拖拽不吃点击(movedRef 判定);展开态 zIndex 提升盖住邻卡。
 */
function CanvasPanel(props: { lang: Lang }): ReturnType<typeof createElement> {
  const { lang } = props
  // 模块级组件拿不到 Panel 内部的 t2/lang——经 props 自建同款查表(TimelinePanel 先例)
  const tt = (k: keyof typeof STR.zh): string => (STR[lang][k] ?? STR.zh[k]) as string
  const [cards, setCards] = useState<CanvasCard[] | null>(null)
  const [busy, setBusy] = useState(false)
  const [offset, setOffset] = useState(0)
  const [zoom, setZoom] = useState(1)
  const [openId, setOpenId] = useState<string | null>(null)
  const [more, setMore] = useState(false)
  const [dragging, setDragging] = useState(false)
  // 拖拽几何进 ref 不进 state:mousemove 每帧 setState 会把整画布重渲染一遍(恰恰是要避免的开销)
  const wrapRef = useRef<HTMLDivElement | null>(null)
  const dragRef = useRef<{ x: number; y: number; sl: number; st: number } | null>(null)
  const movedRef = useRef(false)

  const loadPage = async (off: number, append: boolean): Promise<void> => {
    if (busy) return
    setBusy(true)
    const page = await fetchCanvasPage(off)
    setBusy(false)
    if (append) {
      // 追加页按 id 去重:两次拉取间新运行落盘会让 offset 窗口右移,重卡比丢卡更扎眼
      const seen = new Set((cards ?? []).map((c) => c.id))
      setCards([...(cards ?? []), ...page.filter((c) => !seen.has(c.id))])
    } else {
      setCards(page)
      setOpenId(null)
    }
    // 满页才可能有下一页(offset 作用于过滤后全集,数据层契约)
    setMore(page.length >= CANVAS_PAGE_DEFAULT)
  }

  useEffect(() => { void loadPage(0, false) }, [])
  useEffect(() => {
    const el = wrapRef.current
    if (el === null) return
    const onWheel = (e: WheelEvent): void => {
      if (e.deltaY === 0) return
      e.preventDefault()
      setZoom((z) => nextZoom(z, e.deltaY < 0 ? 1 : -1))
    }
    el.addEventListener('wheel', onWheel, { passive: false })
    return () => { el.removeEventListener('wheel', onWheel) }
  }, [])

  // ── 拖拽平移(几何见上注;mouseleave 兜底 mouseup——拖出容器即停,不悬挂 grab 光标) ──
  const onMouseDown = (e: { button: number; clientX: number; clientY: number; preventDefault: () => void }): void => {
    if (e.button !== 0) return
    const el = wrapRef.current
    if (el === null) return
    e.preventDefault()
    movedRef.current = false
    dragRef.current = { x: e.clientX, y: e.clientY, sl: el.scrollLeft, st: el.scrollTop }
    setDragging(true)
  }
  const onMouseMove = (e: { clientX: number; clientY: number }): void => {
    const d = dragRef.current
    const el = wrapRef.current
    if (d === null || el === null) return
    const dx = e.clientX - d.x
    const dy = e.clientY - d.y
    // 3px 阈值:手抖不算拖拽,click 照常触发;过阈值的拖拽末尾 click 要吞掉
    if (Math.abs(dx) + Math.abs(dy) > 3) movedRef.current = true
    el.scrollLeft = d.sl - dx
    el.scrollTop = d.st - dy
  }
  const endDrag = (): void => {
    dragRef.current = null
    setDragging(false)
  }

  const zw = Math.round(220 * zoom)
  const zt = Math.max(24, Math.round(48 * zoom))

  const cardEl = (c: CanvasCard): ReturnType<typeof createElement> => {
    const tone = canvasCardTone(c)
    const open = openId === c.id
    return createElement('div', {
      key: c.id,
      className: `o4-cvcard${open ? ' open' : ''}`,
      style: { width: `${zw}px`, borderColor: tone === 'ok' ? 'rgba(52,199,89,.5)' : (tone === 'fail' ? 'rgba(255,69,58,.55)' : 'rgba(255,159,10,.55)'), ...(open ? { zIndex: 3 } : {}) },
      title: `${c.command ?? c.id}\n${c.at}`,
      onClick: () => { if (movedRef.current) return; setOpenId(open ? null : c.id) },
    },
      // 卡头:类型徽章 + 站点(有则)+ 本地时间
      createElement('div', { style: { display: 'flex', alignItems: 'center', gap: '5px' } },
        createElement('span', { className: 'o4-bdg' }, c.type === 'site' ? tt('cvTypeSite') : (c.type === 'schedule' ? tt('cvTypeSchedule') : tt('cvTypeBrowser'))),
        c.site !== undefined ? createElement('span', { style: { fontSize: '10.5px', color: 'rgba(249,250,251,.6)' } }, c.site) : null,
        createElement('span', { style: { marginLeft: 'auto', fontSize: '10px', color: '#5F6873', fontFamily: 'ui-monospace,Consolas,monospace', flex: 'none' } }, canvasStamp(c.at)),
      ),
      // 缩略图(无截图=状态着色占位块)+ 命令(三行截断,全句进 title)
      createElement('div', { style: { display: 'flex', gap: '7px', alignItems: 'flex-start' } },
        c.shot !== undefined && c.shot.length > 0
          ? createElement(ShotThumb, { path: c.shot, px: zt })
          : createElement('span', { title: tt('canvasNoShot'), style: { width: `${zt}px`, height: `${zt}px`, borderRadius: '6px', flex: 'none', background: tone === 'fail' ? 'rgba(255,69,58,.12)' : (tone === 'warn' ? 'rgba(255,159,10,.1)' : 'rgba(77,107,254,.1)') } }),
        createElement('span', { style: { fontSize: '10.5px', fontFamily: 'ui-monospace,Consolas,monospace', color: 'rgba(249,250,251,.78)', wordBreak: 'break-all', display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden' } }, c.command ?? c.id),
      ),
      // 卡脚:状态点 + 耗时 + P 值(黄档附复核提示)
      createElement('div', { style: { display: 'flex', alignItems: 'center', gap: '6px', fontSize: '10px', color: '#5F6873', flexWrap: 'wrap' } },
        createElement('span', { className: `o4-dot ${tone === 'ok' ? 'g' : (tone === 'fail' ? 'r' : 'y')}` }),
        c.ms > 0 ? createElement('span', null, `${c.ms}ms`) : null,
        c.p !== null ? createElement('span', { title: tt('canvasSuspectTip') }, `P=${c.p.toFixed(2)}`) : null,
        tone === 'warn' ? createElement('span', { title: tt('canvasSuspectTip'), style: { color: '#FFB340' } }, tt('canvasSuspect')) : null,
      ),
      // 展开回放:完整步骤序列(缩略图+命令+耗时+exit 状态色),再点收起
      open ? createElement('div', { className: 'o4-cvsteps' },
        createElement('div', { style: { fontSize: '10px', color: '#8B9AFF' } }, tt('canvasReplay')),
        ...stepsOfCard(c).map((s, i) => createElement('div', { key: i, style: { display: 'flex', gap: '6px', alignItems: 'center' } },
          createElement('span', { className: `o4-dot ${s.ok ? 'g' : 'r'}`, style: { flex: 'none' } }),
          s.shot !== undefined && s.shot.length > 0
            ? createElement(ShotThumb, { path: s.shot, px: 36 })
            : createElement('span', { title: tt('canvasNoShot'), style: { width: '36px', height: '36px', borderRadius: '6px', background: 'rgba(255,255,255,.05)', flex: 'none' } }),
          createElement('span', { style: { flex: '1', minWidth: '0', fontSize: '10px', fontFamily: 'ui-monospace,Consolas,monospace', color: 'rgba(249,250,251,.72)', wordBreak: 'break-all' } }, s.cmd),
          s.ms > 0 ? createElement('span', { style: { fontSize: '10px', color: '#5F6873', flex: 'none' } }, `${s.ms}ms`) : null,
        )),
      ) : null,
    )
  }

  return createElement('div', { className: 'o4-card' },
    createElement('div', { className: 'o4-h3' },
      createElement('span', { className: 'o4-miniico' }, ic('layers', true)), tt('canvasT'),
      createElement('span', { className: 'rt' },
        createElement('span', { style: { fontSize: '11px', color: '#5F6873', marginRight: '4px' } }, tt('canvasCardsN')(cards?.length ?? 0)),
        createElement('button', { className: 'o4-btn ghost sm', title: tt('canvasZoomOut'), disabled: zoom <= 0.5, onClick: () => setZoom(nextZoom(zoom, -1)) }, '-'),
        createElement('span', { style: { fontSize: '11px', color: '#5F6873', margin: '0 2px', minWidth: '34px', textAlign: 'center' } }, `${Math.round(zoom * 100)}%`),
        createElement('button', { className: 'o4-btn ghost sm', title: tt('canvasZoomIn'), disabled: zoom >= 2, onClick: () => setZoom(nextZoom(zoom, 1)) }, '+'),
        createElement('button', { className: 'o4-btn ghost sm', disabled: busy, onClick: () => { setOffset(0); void loadPage(0, false) } }, ic('refresh', true), busy ? tt('checking') : tt('recheck')),
      ),
    ),
    createElement('div', { className: 'o4-sub' }, tt('canvasSub')),
    createElement('div', {
      ref: wrapRef,
      className: `o4-cvwrap${dragging ? ' drag' : ''}`,
      style: { height: '340px', userSelect: 'none' },
      onMouseDown, onMouseMove, onMouseUp: endDrag, onMouseLeave: endDrag,
    },
      cards === null
        ? createElement('div', { style: { padding: '12px', width: '70%' } },
            createElement('div', { className: 'o4-load' }, tt('loading')),
            createElement('div', { className: 'o4-skel' }), createElement('div', { className: 'o4-skel', style: { width: '70%' } }),
          )
        : shouldRenderCanvasFlow(cards)
          ? createElement('div', { className: 'o4-cvflow' }, ...cards.map(cardEl))
          : createElement('div', { className: 'o4-load', style: { padding: '14px' } }, tt('canvasEmpty')),
    ),
    more
      ? createElement('div', { style: { display: 'flex', justifyContent: 'center', marginTop: '9px' } },
          createElement('button', { className: 'o4-btn ghost sm', disabled: busy, onClick: () => { const next = offset + CANVAS_PAGE_DEFAULT; setOffset(next); void loadPage(next, true) } }, busy ? tt('checking') : tt('canvasMore')),
        )
      : null,
  )
}

/** 首启向导卡:总览顶部四层 checklist(CLI→daemon→BrowserBridge→登录态),每层一行"状态点+文案+修复动作"。
 *  渲染门槛在调用侧由纯函数 shouldShowOnboarding 判定(全绿不占位);修复动作全部复用现有链路——
 *  daemon 层=daemon-start 一键修复(与 hero 卡同一回调),Bridge 层=装扩展指引(Releases 链接),
 *  CLI 层=复制安装命令(与"安装引导"手风琴同一命令),登录层=对带 login 命令的站跑 `site <站> login`(浏览器开登录页)。
 *  模块级组件拿不到 Panel 内部 state——数据与回调经 props 传入(TimelinePanel 先例)。 */
function OnboardingWizard(props: {
  lang: Lang
  status: OpencliStatus | null
  adapters: AdapterInfo[] | null
  loginResults: LoginCheckItem[]
  starting: boolean
  running: boolean
  onFixDaemon: () => void
  onOpenLogin: (site: string) => void
  onCopyCliInstall: () => void
}): ReturnType<typeof createElement> {
  const { lang, status, adapters, loginResults, starting, running, onFixDaemon, onOpenLogin, onCopyCliInstall } = props
  // 模块级组件拿不到 Panel 内部的 t2/lang——经 props 自建同款查表(TimelinePanel 先例)
  const tt = (k: keyof typeof STR.zh): string => (STR[lang][k] ?? STR.zh[k]) as string
  // 四层判定与状态条/hero 卡同一数据源(status RPC + login-check),不引入第二套口径
  const cliOk = status?.ok === true && status.bin !== null
  const daemonUp = status?.daemon?.running === true
  const bridgeOn = status?.daemon?.extension === 'connected'
  // 零配置降级可用面的显示判据比红点更严:扩展确已连(如多档案未选的 'connected, none selected')
  // 不显示,避免"扩展在却劝降级"的误导;正则口径与 host 侧 doctor 的 extConnected 同源
  const extRaw = status?.daemon?.extension ?? ''
  const extConnected = /^connected/.test(extRaw) || /profiles connected/.test(extRaw)
  const loginOk = loginResults.length > 0 && loginResults.every((r) => r.ok === true)
  const loginAllRed = loginResults.length > 0 && loginResults.every((r) => r.ok !== true)
  const loginDot: 'g' | 'r' | 'y' | 'n' = loginOk ? 'g' : (loginAllRed ? 'r' : (loginResults.length === 0 ? 'n' : 'y'))
  const loginText = loginOk ? tt('obLoginOk') : (loginAllRed ? tt('obLoginBad') : (loginResults.length === 0 ? tt('obLoginNa') : tt('obLoginPart')))
  // 登录层站点:目录里带 login 命令的站(纯函数过滤);封顶 24 防大目录把卡撑爆(输出截断防膨胀同款纪律)
  const loginSitesAll = loginSitesFromAdapters(adapters)
  const loginSites = loginSitesAll.slice(0, 24)
  const loginHidden = loginSitesAll.length - loginSites.length
  const ver = status?.version != null && status.version !== '' ? ' · v' + String(status.version).replace(/^v/, '') : ''
  const row = (key: string, dot: 'g' | 'r' | 'y' | 'n', text: string, action: ReturnType<typeof createElement> | null): ReturnType<typeof createElement> =>
    createElement('div', { key, className: 'o4-row' },
      createElement('span', { className: `o4-dot ${dot}` }),
      createElement('div', { className: 'grow' }, createElement('div', { className: 'o4-tt' }, text)),
      action,
    )
  return createElement('div', { className: 'o4-card' },
    createElement('div', { className: 'o4-h3' }, createElement('span', { className: 'o4-miniico' }, ic('zap', true)), tt('obT')),
    createElement('div', { className: 'o4-sub' }, tt('obSub')),
    row('cli', cliOk ? 'g' : 'r', cliOk ? tt('obCliOk') + ver : tt('obCliBad'),
      cliOk ? null : createElement('button', { className: 'o4-btn ghost sm', onClick: onCopyCliInstall }, tt('obCliFix'))),
    row('daemon', daemonUp ? 'g' : 'r', 'daemon ' + (daemonUp ? tt('daemonRunning') : tt('daemonDown')),
      daemonUp ? null : createElement('button', { className: 'o4-btn sm', disabled: starting, onClick: onFixDaemon }, starting ? '…' : tt('fix'))),
    row('bridge', bridgeOn ? 'g' : 'r', 'BrowserBridge ' + (bridgeOn ? tt('bridgeOn') : tt('bridgeOff')),
      bridgeOn ? null : createElement('button', { className: 'o4-btn ghost sm', onClick: () => { window.open(RELEASES_URL, '_blank') } }, ic('ext', true), tt('obRelBtn'))),
    !bridgeOn ? createElement('div', { className: 'o4-note' }, tt('obBridgeHint')) : null,
    // 降级可用面黄行(设计 §2.2-2):bridge 红时声明"现在还能跑什么",向导不再只有"装扩展"一种结局;
    // 目录未载入时用无数字文案,不给猜出来的 N
    !bridgeOn && !extConnected
      ? row('zerocfg', 'y', adapters !== null ? tt('obZeroCfgN')(readonlySiteCount(adapters)) : tt('obZeroCfgNa'), null)
      : null,
    row('login', loginDot, loginText, null),
    // 登录层修复动作:每个可登录站一枚「打开登录」按钮 → try-run 跑 `site <站> login`,浏览器会开登录页
    loginSites.length > 0
      ? createElement('div', { className: 'o4-sites', style: { marginTop: '2px' } },
          ...loginSites.map((s) => createElement('span', { key: s.site, className: 'o4-site' },
            ava(s.site, 24),
            s.site,
            createElement('button', { className: 'o4-btn ghost sm', disabled: running, onClick: () => onOpenLogin(s.site) }, tt('openLogin')),
          )),
          loginHidden > 0 ? createElement('span', { className: 'o4-chip' }, `+${loginHidden}`) : null,
        )
      : null,
  )
}

/* ── 首启向导纯函数:渲染门槛与登录站过滤(导出供 tests/onboarding.test.ts 直接单测;
     组件渲染部分留给 GUI 人工验收——client 侧无组件测试基建) ── */

/** 首启向导渲染门槛:daemon 未运行 / BrowserBridge 未连接 / 登录巡检全红,任一命中即渲染;
 *  全绿(或登录尚未巡检且其余两层绿)不渲染。status 为 null(status RPC 失败)按 daemon 未运行
 *  处理——面板数据失明本身就是需要向导接管的状态。 */
export function shouldShowOnboarding(p: { status: OpencliStatus | null; loginResults: ReadonlyArray<{ ok: boolean }> }): boolean {
  const daemonUp = p.status?.daemon?.running === true
  const bridgeOn = p.status?.daemon?.extension === 'connected'
  const allRed = p.loginResults.length > 0 && p.loginResults.every((r) => r.ok !== true)
  return !daemonUp || !bridgeOn || allRed
}

/** 登录层候选站:adapters 目录里 commands 精确含 'login' 的站(精确匹配——避免 login_qr 之类
 *  衍生命令生成跑不通的 `site <站> login`);返回站名 + 可直接交给 try-run 的命令行。 */
export function loginSitesFromAdapters(adapters: ReadonlyArray<AdapterInfo> | null): Array<{ site: string; line: string }> {
  return (adapters ?? []).filter((a) => a.commands.includes('login')).map((a) => ({ site: a.name, line: `site ${a.name} login` }))
}

/** 零配置降级可用面(纯函数,导出供 tests/zerocfg.test.ts):无扩展时仍有只读命令的站点数。
 *  kinds 是 normalizeAdapterList 聚合的每站 access 集合,含 'read' 即计入——只做正向提示不做门控
 *  (设计 §2.1:漏标不该挡住一个实际能跑的命令,数字只用于"还能跑什么"的声明)。 */
export function readonlySiteCount(adapters: ReadonlyArray<AdapterInfo> | null): number {
  return (adapters ?? []).filter((a) => (a.kinds ?? []).includes('read')).length
}
