## 0.1.1 — 2026-11-04

> **版本轨统一**:自本版起 GitHub release 版本号与 npm 一致(此前的 0.4.x 为 GitHub 侧旧版本轨;
> npm 0.1.0 即原 0.4.6 同码,历史条目保留原名不改)。

> 直连铺满 + 场景批:浏览器原语族全量 daemon 直连(实测最高 118x),通知静默时段/级别 UI、
> 七天变化聚合、CSV diff 列、批量派发前登录态快检。486 单元全绿;真机八原语差分基准 8/8
> 形状一致;全功能矩阵 26/26、GUI 九幕 26/26、canvas 7/7(宿主 dsh 0.2.2-alpha.3 + OpenCLI CLI/daemon 2.0.2)。

### A. 直连铺满(全原语族)
- **direct-compose 组合层**:0.4.6 只接了 eval;本期 state/click/scroll/open/screenshot/tab/close 全部直连。上游事实(2.0.2 dist 源码级核对):state/click/scroll 不是 daemon 动作,是 CLI 本地用 JS 串构造器经 exec 组合——本层**运行时装载本机已装 CLI 的构造器模块**(永不内嵌副本,上游改 JS 自动跟上),只复刻薄编排(click=page.click 链:resolve→CDP scrollIntoView→hit-test→CDP 原生点击→el.click 兜底;open=会话捕获启动+navigate+2s 落定+拦截器兜底)
- 纪律:只在成功路径归一 CLI 2.0 信封,任何失败/旗标不认识→CLI 兜底出权威错误(TargetError 的 candidates/hint);页面身份缓存与上游 page.js 同款流转;`DSH_OPENCLI_DIRECT=0` 总闸逃生
- **真机差分基准**(两阶段隔离,session=bench):state **57.8x**(1142→37ms)/ tab list **118.7x** / scroll **57x** / tab new **7.9x** / tab close **8.8x** / screenshot **4.7x** / open 1.9x / click 1.4x;八原语信封形状逐字段一致 8/8
- 步骤截图直连化:每条轨迹都付的热路径(captureStepShot)免 CLI 冷启动

### B. 场景批
- **通知静默时段**(B2):任务级 quietHours(HH:MM-HH:MM,支持跨夜)——窗内通知暂存(上限 20,随任务落盘),出窗首跑合并 😴 摘要段一次推送;解析失败 fail-open;全链:面板表单+任务行预设下拉+schedule-add 幂等更新+inbox 闭集+ctl `--quiet-hours`
- **通知级别 UI**(B3):任务行 notifyLevel 下拉(all/quiet),0.4.6 后端能力首次有面板面
- **七天变化聚合**(B1):变化面板顶部七日条(每日一行 新增/消失/位移);CSV 导出新增 `_diff` 列(diffItemMarks 按身份键逐条标记 new/gone/moved #a→#b,完整无截断——entries 有 20 条上限故单独实现)
- **批量派发前登录态快检**(W5'):site_batch 加 `preflight`/`skipNotLoggedIn`——未登录站标 ⚠ 或摘除(⛔),复用 login-check 的 whoami 池+TTL 缓存;默认关(交互式首查 15-45s 不可接受),无人值守显式开

### C. 工程与分发
- OpenCLI CLI/daemon 升级 2.0.2(扩展 1.0.26 对齐);dsh 0.2.2-alpha.3 适配(插件 peer 范围天然放行,唯一断裂=换 scoped 包名时漏改的 cordis.patch.yml,已修)
- npm keywords 补 `deepseek-harness`(自动收录渠道触发词)/`scheduled-watch`/`change-alerting`(生态空白第一叙事);README 中英加包名说明行(无作用域名被占的搜索防守)与「与其他 browser 插件的选型」段(只讲路线不点名)

### 兼容与验收
- dsh 0.2.2-alpha.3(latest 为 0.2.1-rc.5,alpha 为开发线;宿主兼容门实测 includePrerelease 对比运行时主版本,peer `>=0.1.1-rc.2 <0.3.0-0` 天然放行)
- 真机:全功能矩阵 26/26 + GUI 九幕 26/26 + canvas 7/7 + 直连差分基准 8/8;单元 486/486(+32)

## 0.4.6 — 2026-10-30

> 人机协同与引擎大版本:自然语言指挥台 + daemon 直连传输 + 生态接入(任何 dsh 会话一句话驱动插件)。
> 450 测试全绿;GUI 真机走查通过;直连延迟真机实证(同命令 87ms vs CLI 1040ms,12×)。

### 自然语言指挥台(B1+B3,总览主行动)
- **nl-intent**:一句话 → 闭集意图(经宿主 ctx.llm;路由候选=默认选择+已注册 provider 轮试,每条先解析适配器默认模型);模型输出必须过 parseIntent 闭集门,**不合法绝不猜测补全**;失败分诊三种(llm 出错/空输出/闭集拒绝+原文头),各带可行动指引
- **预览卡**:映射结果逐字段可改,确认执行走 inbox-intent(与 ctl 同一条 applyIntent 白名单/审计链,改什么都过不了门);命令模式(试试看)完整保留,双模式并存
- 模型额度诚实:映射是显式按钮触发,一次调用;不做后台自动映射

### 生态接入层(F1+F2,预设门的正解)
- **dsh-opencli-ctl**(npm bin):schedule add/list/run/remove · notify set/test · report build · status;写白名单意图 JSON 到 `~/.dsh/opencli-inbox/`,插件消费者(3s 轮询+停机清除)执行并回写结果,ctl 默认同步等待拿 JSON——**面板聊天等任何有 shell 的 dsh 会话**一句话即可驱动插件全能力
- 意图安全:闭集校验(八 kind,多余字段拒绝,绝不 eval)/单文件 16KB+队列 200 条上限/claim 占位防并发/processed 轮转 100;每次消费落 ingest 事件(面板时间线可见)
- **SKILL.md 全面重写**:场景路由手册(一句话→动作表/ctl 命令面/工具速查/适配器创作/边界如实),面板与 CLI 会话通吃

### daemon 直连传输(A1+A2+A4)
- **direct.ts**:`POST /command` + X-OpenCLI 头,动作族 exec/navigate/tabs/screenshot;能力探测三态(unknown/ready/off),协议形状不认识整层禁用;**永不抛错,任何失败静默回落 CLI**(旁路加速不成为单点)
- eval 族接入 runBrowserTraced:归一 CLI 2.0 信封下游零改动;页面身份缓存(响应 page 持续刷新,stale 类错误清缓存无 page 重试一次)
- **传输对照进基准报告**(A4):CLI 冷启动 vs 直连往返双实测,加速比随每份报告落盘
- 真机:direct-real-test 8/8(导航→discover→像素级 read→click 全走直连);延迟对照 87ms vs 1040ms

### 快照差异推送(C,盯变化独占区深化)
- diffsnap 纯函数:JSON 数组逐条比对(新增/消失/位移≥3 位),包装 {data/items/list/results} 认得,非 JSON 折规模摘要**绝不臆造**;条目身份 id/title/url 优先退化归一文本
- 调度链接入:成功采集自动 diff 上一份快照,📊 snap-diff 事件+推送正文尾接"与上次相比"段;与 watch 🔔 并存

### 通知渠道平台预设(D)
- channels.ts 五平台载荷:飞书/钉钉(加签=timestamp+secret HMAC-SHA256,secret 可钉 URL 发送时拼且不落日志)/企微/Telegram(chat_id 从 query 提取)/generic(0.4.5 信封不变);platformOk 细判 200 体内平台错误码
- WebhookChannel 平台化(URL 推断兜底);面板自动化 tab 通知通道节:平台下拉+URL+保存+**测试按钮**(与 ctl notify test 同链,诚实回报成败)

### 面板设计系统与动效(B3)
- 设计 token 层:色板/圆角/阴影/动效时长缓动收进 CSS 变量(此前 97 处散落色值);卡片 hover 浮起/入场 stagger/骨架屏呼吸/运行态呼吸灯,全 transform+opacity 不触重排;**prefers-reduced-motion 全关**(可访问性)

### 工程加固(E)
- 工具输出 schema 真调用一致性测试:全注册表 38 工具逐一登记(只读 OUTPUT_KEYS/写类 EXEMPT),新工具漏登记 CI 直接红——宿主 additionalProperties:false 只在真调用时校验,直调 execute 测不出(竞品踩坑实录),机器化排雷

### 场景补强(同版重发:从使用场景倒推九缺口)
- **新手引导**:试试看失败(站名拼错)→ 自动带 3 条最接近的真实命令,点击直接跑
- **变化时间线**:任务行「📊 变化」展开,按天看 +新增/-消失/位移(逐相邻快照 diff 聚合)
- **通知级别**:`notifyLevel quiet` 只推命中/变化/失败,高频任务不再例行刷屏(默认 all 不变)
- **CSV 导出**:任务一键导出剪贴板(RFC4180 转义,_at/_site 出处列;非 JSON 输出原文分节);`ctl report export`;
- **来源徽章**:任务行标注 agent/chat/panel/ctl 创建来源;**undo**:按收件箱 stem 撤销误建任务;**backup**:任务+通知配置打包 JSON
- **动态快捷**:每次刷新从站点目录抽 6 个站点示例——170+ 站都被看见

### npm 首发
- `@cold777/dsh-opencli@0.1.0` 发布至 npm(作用域包,与同名竞品以用户名前缀区分);`npm i -g @cold777/dsh-opencli` 即装,自动带 `dsh-opencli-ctl` 命令面;发布包经敏感扫描(本机用户名零残留——运行时正则改拼接构造)

### 兼容与验收
- OpenCLI 2.0 双版本兼容延续;22 项套件 dsh 0.2.1-rc.5 全过
- dsh 面板聊天会话不装载插件 agent 工具属 dsh 预设作用域架构(RESEARCH-20261030),0.4.6 的 ctl/inbox 生态层即其正解

## 0.4.5 — 2026-10-30

> 数据产品大版本:定时采集 → 真实性判定 → 快照落盘 → 推送通知 → 带出处报告 → 画布回放,闭环全线贯通。
> 399 测试全绿;22 项套件在 dsh 0.2.1-rc.5 全过(宿主版本随套件记录)。

### 推送闭环(新)
- **通知通道层**:Webhook / Email(SMTP)/ dsh 面板三通道并发群发,单通道失败不拖累其他;出口 scrubLocalPaths 清洗(送达载荷实测无本机路径/用户名)
- **watch 命中推送**:关键词命中 → 🔔 正文前缀,与面板事件流同一份命中事实
- 修复:notify 开关原先无效(sch.notify !== false 关闸)与 saveNotifyConfig 双写竞态(统一走 saveState)
- 真机验证:本地接收器收真 POST 11/11;坏 email 通道(SMTP 连拒)容错 6/6,配置测后还原

### 无限画布(新,面板第五 tab)
- 轨迹/写操作证据/定时快照三源聚合为卡片流:拖拽平移、滚轮缩放、点卡展开步骤回放、分页加载
- 时间线=画布的单站趋势视角(快照规模柱状图 + 本站 24h 卡片流)

### canvas VOM 三件套(新,eval 桥)
- canvas_discover/read/click 触达网页内无 DOM 节点的位图画布(图表/游戏/画板);click 为写原语走人工审批
- **canvas_read 位图落盘进画布**(0.4.5 内接通):读到的 PNG 自动挂轨迹 shot 字段 → 画布卡片图片步骤,人可回放 agent 看到了什么;两层 canvas(网页 canvas 元素层 vs 面板复盘层)在工具描述/面板/README 三处说清
- 真机验证:部署包字节级抽取 eval 桥 11/11(含像素级 #d00 采样);真实 daemon 信封喂部署包函数缝合测试 6/6

### 命名空间迁移
- browser_* → opencli_*(上游两次撞名后主动让出 browser_ 前缀);旧名挂弃用别名(描述前置弃用标记,转发新名,计划 2027-04 移除)

### 安全与正确性(交叉评审 7 发现全修)
- HIGH:opencli_run 经 browser eval 绕门第三入口 → 同类拦截
- MEDIUM:notify 开关无效 → 任务级关闸;saveNotifyConfig 双写竞态 → 单一写者;SKILL/catalog 旧名残留 → 全量迁移
- LOW:SMTP socket 泄漏(单步超时+finally 清理);cards/knowledge 注释修正
- 另修 wantRoutine 幽灵注释(宣称的例行开关从未存在于配置模型,注释改为与实现一致)

### 兼容与验收
- OpenCLI 2.0 双版本兼容(信封/--session/分页/daemon JSON/目录形态,按形状嗅探不按版本号)
- 22 项套件在 dsh 0.2.1-rc.5 全过(0.2.1-rc.1→rc.5 无需适配改动)
- dsh 面板聊天会话不装载插件 agent 工具属 dsh 预设作用域架构,已记入 README FAQ 与 docs/RESEARCH-20261030

## 0.4.4 — 2026-10-22

> 交叉审查四视角(正确性/安全/测试真实性/事实核对)24 条唯一发现全修;301 测试 + 22 项套件(含宿主版本记录)全绿。

### 安全(安全审查:2 HIGH 2 MEDIUM + 机检器漏网)
- **opencli_run 写命令绕门(HIGH)**:描述曾宣称"走审批"而 execute 直通——站点形态 argv 现进写审批门(write/未知→ask,浏览器/系统命名空间按 browser_* 边界)
- **site_batch 多站写命令零检查(HIGH)**:整批 fail-closed 拒绝,未知站点仍走拼写提醒
- **canary 防御性只读门(MEDIUM)**:热词伪装写命令夜间无人值守拦截
- **browser_do eval 对齐 userscript-run 门(MEDIUM)**:登录页任意 JS=写原语,进人工审批
- **presubmit 机检器三漏网**:细粒度 PAT(github_pat_)/长 TLD 邮箱/小写路径与行尾内部目录,实证回归

### 正确性(正确性审查)
- **零配置过期承诺收回(HIGH)**:通道B(CDP attach)默认关死后,doctor/systemPrompt/面板三处文案同步收回"匿名降级"承诺,skip 文案不再谎称"未探测到端点"(端点在但通道关闭时如实说)
- **parseDaemonStatus 缺字段语义**:extensionConnected 缺失归一为 unknown 而非 not connected——explicitDown 只认显式否定,browser_* 不被一刀切死

### 对外交付体系(2026-10-19 事故)
- **提交前机检器**:隐私(本机身份/路径/会话id/token/邮箱/内部目录)全 FAIL 拦截+数字声明强制溯源+删除事实检测;#8007 真实翻车文本回归(180+×2 与被删前提均被当场抓住)
- **站点数对齐上游 manifest**:180+→170+(注册表维护者 fkysly 纠正,#8007 事故全记录见 docs/LESSON-20261020-registry.md)
- 「录屏回放」全仓正名「轨迹回放」

### 功能补齐
- browser_screenshot 透传 --full-page(上游 2.0 全页截图);browser_do 白名单补 scroll
- canary 漂移巡检真机三轮调试(heredoc 反斜杠吞噬 argv 碎片化/选站 kinds 索引不对齐/seam 冷启动竞态)后可用:top-20 零参热榜命令,漂移对比实证(小红书新失败被准确捕获)

### 测试
- 审批门安全不变量套件:攻击表 20 形态+200 次可复现 fuzz(allow⟹只读)+独立通道+豁免边界;lib 捆绑陈旧守卫(vitest globalSetup,lib 落后 src 即红)
- 301 全绿(180→234→259→264→266→282→290→301);21 项套件+宿主版本记录 22/22

## 0.4.3 — 2026-10-17

> GUI 走查五连修 + 登录态真数据链路全线贯通(详见 `docs/FIX-20261008-GUI走查修复.md`)。
> 本版起随 GitHub Release 双资产发布(版本名 + 固定名 dsh-opencli.tgz,注册表浮动地址自动吃到最新)。

### 修复
- **定时行内状态不更新**:立即跑后"上次/计数"整个重试周期(~2.5min)停在旧值——分散刷新 2.5s~240s 覆盖完整重试链;时间线展开期间 15s 轮询
- **行内 verdict 恒亮 ✓**:与时间线红失败行同屏矛盾——空史无符号/有成功绿 ✓/全失败红 ✗
- **时间线卡片溢出裁切**:`.o4-row` 允许换行 + 卡片 `flex:1 1 100%` 独占整行
- **刷新芯片与文字芯片不齐**:`boxSizing:border-box` + 等高 23px
- **占位文字对比度**:`.o4-load` 0.38 → 0.58
- **定时执行不落「运行轨迹」**:`runSiteCommand` 补 `recordTrace`(带 `schedule` 前缀与手动 browser 命令区分),复盘链路闭合

### 验证
- 159/159 测试绿;21 项审查套件全 PASS;**登录态真数据端到端验收通过**:浏览器扩展桥(v1.8.8)→ try-run 真实热榜(SystemOne 判定 P=0.91)→ 登录巡检真实 cookie 诊断 → 定时采集 15s 回填 → 快照落盘 → 时间线渲染 → 带出处报告生成,全程经产品面 RPC
- dsh 0.2.0-rc.2(latest)四接缝(subprocess/mcpResources/网关信封/settings.section)全工作;0.2.1-rc.1 依赖面比对无断裂迹象,stable 后跑回归

### 测试
- trace-get 断言改 browser 子集相对顺序(定时链路写 trace 后绝对首条假设失效);watch 用例新增"定时执行落 trace"回归断言;新增 e2e-real-data.cjs 真数据验收脚本

## 0.4.2 — 2026-10-08

> ⚠️ **升级必读:插件更新后必须重启 dsh daemon 才生效**(长驻进程不热加载插件构建)。

### 新功能
- **轨迹回放**:browser_* 全族命令自动落盘 trace(~/.dsh/opencli-traces,jsonl+5MB 轮转);trace-list/trace-get RPC;**trace_replay 工具**(agent 复盘"上次为什么失败",跨日聚合+本地时区);面板「运行轨迹」卡(红绿状态点/耗时/展开原文)
- **对话内任务预览卡片**:site/site_batch/browser_do 输出结构化渲染(命令块+四态状态色 ✓✗⚠+汇总表+原文围栏,0.2 视觉)
- **报告导出(带出处)**:buildReport 纯渲染层——多站/定时快照合并为 markdown,每节**出处三元组(命令+时间+快照路径)+判定结论**,尾部"数据源与缺口声明"逐条列失败/静默失败/缺席,**零模型介入**;site_batch 自动落盘+report-build RPC+面板「生成报告」按钮
- **站点健康度**:上游 issue 实测数据(小红书/instagram 受损等)驱动命令页徽章+知识卡健康段,受损站自动提示 browser 兜底
- **MCP Resources 知识暴露**:dsh 0.2 ctx.mcpResources seam——opencli://sites/{site}/knowledge 资源;0.1.x 走 knowledge-get RPC 双路径
- **W3 分层命令路由 site_route**:SystemOne 两步 choice(先站后命令,≤24 候选)亚秒出命令行+Top3 概率
- **采集快照+时间线**:定时成功执行存结构化快照(50 份轮转);schedule-history 快照索引;面板时间线趋势柱状图+运行史
- **watch 关键词监控增强**:命中事件总览可见,大小写不敏感
- **SWR 面板缓存 v2**:重开秒显上次数据(损坏缓存全防护:try/catch+结构校验+版本键+12h 过期)
- **知识外移**:pitfalls/健康度独立为 knowledge/*.json 数据文件(知识更新不动代码)

### 样式(0.2 视觉对齐)
- tab 激活态品牌蓝渐变+内描边+顶部高光;卡片渐变表面+顶光+悬浮投影;输入框品牌焦点环;细滚动条;次要文字对比度提升;四档模式对勾语义修复;watch/健康徽章/轨迹卡/时间线全套新组件样式

### 性能
- laya 权重激活期后台预热(冷加载 60s 不再砸首次调用);卡片去 transform 降绘制;目录缓存+快路径

### 可靠性修复(全部经独立子代理真机复核)
- **[HIGH] cron 调度器从不与当前时间比较**——数字合法即每分钟触发,对站点高频轰炸(历史 state 累积 5055 个 marker 实锤);修复+字段越界拒收+逗号列表语义
- **任务 site 前缀剥离**:按面板占位符创建的任务此前 100% 失败(unknown command site)
- **laya noul 放弃阈值判失败**(实测错误文本同样 0.9+,拦截权收归确定性规则层;真数据 0.66-0.77 安全通过)
- **try-run exit≠0 恢复链**:扩展未连/登录缺失/风控墙归类+统一中文指引,不再裸 YAML 46 秒
- **opencli_catalog 过滤参数全失效修复**(query/site 真正生效)
- schedule-add cron 五段校验+越界拒绝;调度 marker 独立 Set 不落盘+loadState 自愈 5055 键
- 7 个 RPC 空 request 守卫;knowledge-export 空 sites 报错;快照时间戳 ISO 还原;EN 站点数动态化
- resolveBin 版本切换免疫(vfox/nvm 多版本目录扫描,活跃版本切走自动找回 opencli)
- 逗号运算符吞行/TimelinePanel 作用域/schedule-history 形参名 三连根因修复(时间线不渲染缺口)

### 工程与文档
- 159 单测(0.4.1 时 74);审查套件 21 项;竞品监控脚本 competitor-watch.cjs;PM-RESEARCH 竞品全景(官方注册表 4412 条实测);SKILL.md 全工具速查;部署断层教训入档

# 更新日志

格式参考 Keep a Changelog;版本与 GitHub Releases 一一对应。

## 0.4.1 — 2026-10-03
### dsh 0.2.0 适配(双版本兼容:0.1.5 与 0.2.0 同时 20/20)
- **新增 ctx.subprocess 原生执行路径**:0.2.0 把命令执行迁到 subprocess seam(官方 bash 工具同款),旧 ctx.shell.execute 需要沙箱 policy 管线且插件直调不可靠;经 reflect 旁路可选读取(刻意不放 static inject——cordis 对声明服务做加载期解析,0.1.x 宿主没有 subprocess 服务会导致整个插件加载失败)
- 0.1.x 回落路径升级为多形态自探测:resolve包裹/直传/argv数组,锁定首个真实产生输出的形态(异常文本不再被误当有效输出);spec 携带 danger-full-access 沙箱策略(可信进程内消费者,与 0.1.x 无沙箱行为一致)
- 适配事实清单:0.2.0 强制校验插件 peerDependencies(我们的宽范围 >=0.1.1-rc.2 <0.3.0-0 过闸,写死 ^0.1.x 的插件被拒载);0.2.0 对 patch 引用未安装 bundle 的 profile **静默退出**(0.1.5 容忍)——升级前自查 cordis.patch.yml;0.1.7+ 定时任务默认关闭(与我们无关,定时是自带实现)
- 审查套件健康检查改环境自适应(健康态"一切正常"/降级态"daemon 未运行"两态都算渲染成功)
- 验收:0.2.0-rc.2 全套 RPC+面板四 tab+179 知识卡导出 20/20;0.1.5-rc.1 回归 20/20;74 单测绿

### Agent 发现性与 1.8.8 跟进
- **SKILL.md 全工具速查表**:site/site_knowledge/site_batch/browser 原语/so_verify/so_pick 各自的使用时机 + 失败自救签名 + 无人值守说明
- **systemPrompt 注入更新**:目录文本新增辅助工具段(site_knowledge 先读/so_verify/so_pick 亚秒判定/site_batch preflight/watch 关键词+风控退避),agent 零配置发现新能力
- **上游 1.8.8 升级完成**(undici CVE 修复;站点 176→180):审查套件全过,插件兼容
- 审查套件 19→**20 项**:新增 knowledge-export RPC 真值(179 张卡真机导出)+ watch 关键词落盘;站点计数改为动态断言(不再钉死 176)
- 修复 knowledge-export 空 args 崩溃:**网关对空 args 传 undefined**,handler 参数必须可选链(真机 gateway/internal 复现)
- dsh017 profile 依赖从 GitHub tarball 切本地 file:tarball(网络不可靠);dsh 0.1.7-alpha.1 兼容实测进行中

### 登录态 preflight + 面板知识卡入口
- **site_batch 登录态 preflight**:派发前按目录 domain 字段检测同域冲突(如 twitter + x 同属 twitter.com),同域站点自动改为组内串行并注明——对冲"同域并行互相踩登录态/标签页且无报错"(BrowserSkill #132,其用户求 preflight 而不得)
- 面板命令页新增「导出知识卡」按钮(knowledge-export RPC,toast 报告导出数量与路径)
- 修复 package.json description 双重编码乱码("登录态浏览器代理"曾显示为"鐧诲綍鎬佹祻…"),dsh-market 拉取的描述曾为乱码;补双语描述+keywords(score 合法抬分项)
- 修复 puppeteer-core 误入 runtime dependencies(构建工具,回 devDependencies,免得跟着插件装进商店)
- 74 测试绿,审查 19/19

### 站点知识包(P1:上游 #2539 砍掉 sitemap/CLI hub 后的知识分发真空)
- 新增 agent 工具 `site_knowledge <站>`:动手前读"地形图"——该站全部结构化命令(read/write 标记)+已知坑(风控/登录/改版,人工种子覆盖微博/B站/知乎/小红书/豆瓣/淘宝/京东/YouTube 等)+**失败签名恢复表**(EMPTY_RESULT/风控墙/429/NAVIGATION_REJECTED → 含义 → 恢复动作),命中签名按表自救,不现场试错
- 新增 `knowledge-export` RPC:全部/指定站知识卡导出为 markdown 到 `~/.dsh/opencli-knowledge/`,可分享、可进版本库;dsh 0.1.6+ MCP Resources 将复用同一数据源
- 知识三源:opencli 目录(实时)/失败签名表(与执行真实性层同源)/pitfalls 种子(宁缺勿造,未知站为空)
- 依据:browser-use #5841"每次会话从零重学站点"(10 评论正式提案)+ 上游退出知识分发
- README 补「固定命令 × 任意网页原语」双模式呈现(PM 调研 t/1225086 弃用理由);测试 64→72

### 风控感知退避(PM 调研直接驱动)
- 定时任务重试命中登录/风控墙时,重试间隔从 15s 提到 **2 分钟**(软封禁冷却);其他失败维持 15s
- 依据:小红书自动化封号是中文用户最真实恐惧(V2EX 两起封号帖;上游 30 天 3 个 XHS 风控 commit),撞墙后立刻重试等于加重风控信号

### Watch 关键词监控(主线 B 第一片,登录态数据产品)
- 定时任务新增 `watch` 字段(关键词,逗号/空格分隔,≤120 字符):每次采集成功后做确定性匹配,命中任一关键词 → ingest 事件 `watch-hit`(🔔 通知)
- 场景:微博热搜监控"出现'放假安排'就通知"/价格监控/舆情关键词——填 dsh-market 微博插件生态空白(≈0 个专用插件)
- v1 故意用确定性匹配,零误报;noul 模糊"值得关注的变化"判定留 v2(真机实测 laya 判别力不足,宁缺勿误报)
- 面板:自动化 tab 创建表单新增 watch 输入框;任务行内 🔔 徽章展示监控词
- schedule-add 幂等去重升级:重复 add 更新 watch 字段而非新建僵尸副本

### 执行真实性层(“失败要说真话”——W2 落地)
- 新增 `verifyResult` 两层判定,三处执行面共用:**site_batch**(每站结果标注 实测有效/疑似静默失败,汇总计数;派发前目录预检拼写错误)、**try-run**(面板“试试看”:空结果/风控页/登录墙直接报 ok:false 并给原因,不再假成功)、**定时任务**(规则命中或 noul 强失效按失败重试,可疑只标注)
- 第一层为确定性规则(opencli 失败词汇 EMPTY_RESULT/AUTH_REQUIRED/NAVIGATION_REJECTED + 登录墙/风控关键词 + 错误 JSON),零推理、零延迟
- 第二层 laya noul 兜底判未知形态;**真机实测:laya 对明显错误文本判别力不足(P≈0.9)**,故只对规则放行的文本做模型判定、可疑仅标注——判别数据见 docs/USER-NEEDS-RESEARCH-20260925.md
- 修复:typesafe/laya 两 provider 应答归一化不一致(choice/noul/score → 统一 {type,value,confidence}),此前 laya(默认 provider)下 so_verify/so_pick 运行时读不到结果、整层静默失效
- SystemOne 不可用时全部路径降级为原行为,零功能损失;测试 53→61 全绿

### SystemOne 决策层(亚秒决策,不耗大模型 token)
- 新增 agent 工具 `so_verify`(noul 断言:P(页面符合预期),亚秒)与 `so_pick`(choice:封闭选项集选点,2-30 项,返回 Top3 概率);低置信/不可用时提示回退常规判断,零功能损失
- provider 三选一:**laya**(默认,@receptron/laya 本地 ONNX,免费/离线/隐私,懒加载——未装权重时优雅降级)/ **typesafe**(官方 Jev API,key 取 `TYPESAFE_API_KEY` 或 `~/.dsh/typesafe-key`)/ passthrough
- 构建管线:@receptron/onnxruntime 原生模块标记 external,保持运行时动态导入(插件自带 node_modules 解析)

## 0.4.0 — 2026-09-18

### 面板(四 tab 重排:总览 / 命令 / 自动化 / 安全与设置)
- 品牌 fusion 标(OpenCLI `>_` × DeepSeek 官方鲸)+ Lucide 全套线性图标 + 48 站点官方品牌图标(品牌色圆角块)
- 健康区 hero 化:脉冲状态灯 + 大数字统计(站点/扩展/审计/模式)+ 渐变网格底
- 状态机四态:检测中骨架屏 / 正常 / 依赖缺失(一键修复)/ 错误(内嵌诊断,永不弹窗)
- 命令页:官方站点图标 + 命令徽章(点击复制调用格式)+ 禁用即时收缩目录
- 定时任务:两行布局 + 重试 ×3 + 通知 + 立即跑 + 运行历史圆点 + daemon 离线横幅
- 安全与设置:审批门 hero + 四档模式 + 限流限域清单 + 供应链自证(构建 sha256)+ 登录态桥(Browser Use)+ 版本与更新
- 章节手风琴全部可用(安装引导三步带复制/启动按钮;profile 说明)
- 配色与 dsh 原生融合(采样弹窗真实色:中性锌灰表面 + DeepSeek 蓝 #4D6BFE)
- 中英双语;全组件微交互(hover/focus/入场阶梯动画)

### host
- 新增 `browser-cdp`(探测 daemon Chrome 的 CDP 端点,登录态桥前置)
- 新增 `audit-list`(审批门拦截审计,近 7 天计数 + 最近 20 条)
- 新增 `logs-tail`(日志查看;opencli 未暴露日志文件时降级为诊断快照)
- `settings` 返回构建 sha256 + 审计计数
- 定时失败重试 ×3(15s 间隔)+ 通知事件;修复 `ingest-events` 未声明字段
- `status` 版本解析合并 stderr;健康区不再被 8MB 目录阻塞(后台异步预热)

### 修复
- **Windows:ctx.shell 为 pwsh 执行器**,无扩展 shim 静默不执行——`DSH_OPENCLI_BIN` 必须用 `.cmd`
- `runHistory` 未声明字段导致 scheduleList 崩溃;构造器 loadState 竞态冲掉定时任务
- 面板 12 处 RPC 形参包裹,适配 0.1.5 网关严格校验

## 0.3.8 — 2026-09-17
- 12 处面板 RPC 形参包裹(同上,提前修复部分);全权审查套件 19 项(`full-review.cjs`)

## 0.3.7 — 2026-09-16
- 修复 0.3.6 构建产物缺失:site_batch / 定时运行历史 / browser 门面进入 lib
- `runHistory` 字段声明 + loadState 竞态两处根治
- README 重写;站点品牌图标素材库

## 0.3.6 — 2026-09-15
- 定时任务持久化 + 真执行(dsh.schedule);site_batch 批量采集
- ⚠ 该版构建产物不完整(缺上述功能),建议直接使用 0.3.7+

## 0.3.5 / 0.3.4 — 2026-09-14
- browser 兼容门面(防 inconsistent binding);probeCDP 前置;限流与限域
