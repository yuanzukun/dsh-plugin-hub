import { test, mock } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, readFile, writeFile, rm } from 'node:fs/promises'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { apply } from '../lib/index.js'
import { extractImages, selectImageApi, imageConfig, callMultimodalApi } from '../lib/image-protocols.js'
import { classifyImageModel, mergeCatalog, fetchModelCatalog } from '../lib/model-catalog.js'

const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aYpQAAAAASUVORK5CYII=', 'base64')
const portraitPrompt = 'A full-body portrait of Zhi preserving her side braid and three woven luminous filaments.'
const target = { key: 'fixture-key', baseUrl: 'https://fixture.invalid/v1' }

function tools(services = {}) {
  const definitions = new Map()
  apply({ tools: { register(def) { definitions.set(def.name, def) } }, get(name) { return services[name] } }, {})
  return definitions
}

// Inspect the real registered output schema, not a copied schema or an unchecked snapshot.
function checkSchema(value, schema) {
  if (schema.type === 'object') {
    assert.equal(typeof value, 'object')
    for (const key of schema.required ?? []) assert.ok(Object.hasOwn(value, key), key)
    for (const [key, item] of Object.entries(value)) {
      if (schema.additionalProperties === false) assert.ok(Object.hasOwn(schema.properties, key), `undeclared field: ${key}`)
      if (schema.properties?.[key]) checkSchema(item, schema.properties[key])
    }
  } else if (schema.type === 'array') {
    assert.ok(Array.isArray(value))
    for (const item of value) checkSchema(item, schema.items)
  } else if (schema.type === 'integer') {
    assert.ok(Number.isInteger(value))
    if (schema.minimum !== undefined) assert.ok(value >= schema.minimum)
  } else if (schema.type === 'string') assert.equal(typeof value, 'string')
}

for (const name of ['image_generate', 'image_edit']) {
  test(`${name}: 4K source dimensions survive strict output validation and rendering`, async (t) => {
    const dir = await mkdtemp(join(tmpdir(), 'image-tool-test-'))
    t.after(() => rm(dir, { recursive: true, force: true }))
    const original = join(dir, 'reference.png')
    await writeFile(original, PNG)
    const ref = { attachmentId: 'sha256:fixture', mediaType: 'image/jpeg', bytes: 123,
      width: 1536, height: 2730, name: 'portrait.png', originalDimensions: { width: 2160, height: 3840 } }
    const definitions = tools({ attachments: { saveImages: async () => [ref] } })
    const def = definitions.get(name)
    process.env.IMAGE_TOOL_FIXTURE_KEY = 'fixture-key'
    t.after(() => { delete process.env.IMAGE_TOOL_FIXTURE_KEY })
    const fetchMock = mock.method(globalThis, 'fetch', async (_url, init) => {
      if (name === 'image_edit') assert.equal(init.body.getAll('image').length, 1)
      return Response.json({ data: [{ b64_json: PNG.toString('base64') }] })
    })
    t.after(() => fetchMock.mock.restore())
    const result = await def.execute({ prompt: portraitPrompt, base_url: target.baseUrl,
      api_key_env: 'IMAGE_TOOL_FIXTURE_KEY', model: 'models/gemini-3-pro-image-preview', api: 'images',
      size: '2160x3840', save_dir: dir, ...(name === 'image_edit' ? { image_path: original } : {}) })
    checkSchema(result, def.output.schema)
    assert.equal(def.output.schema.properties.images.items.additionalProperties, false)
    assert.equal(def.output.schema.properties.images.items.properties.originalDimensions.additionalProperties, false)
    assert.deepEqual(result.images[0].originalDimensions, { width: 2160, height: 3840 })
    assert.match(result.summary, /original 2160x3840; preview 1536x2730/)
    assert.equal(result.files.length, 1)
    assert.ok(result.files[0].startsWith(dir))
    assert.deepEqual(await readFile(result.files[0]), PNG)
    assert.deepEqual(await readFile(original), PNG)
    assert.equal(def.output.render({}, result)[1].attachment, ref)
    assert.throws(() => checkSchema({ ...ref, surprise: true }, def.output.schema.properties.images.items), /undeclared/)
    assert.equal(fetchMock.mock.callCount(), 1)
  })
}

test('discovery recognizes missing image families without mistaking vision input for image output', () => {
  for (const id of ['gemini-2.5-flash-image', 'gemini-3-pro-image-preview', 'nano-banana-2-4k',
    'grok-imagine-image', 'dall-e-3', 'imagen-4.0-generate-001', 'flux-1.1-pro', 'qwen-image-edit', 'gpt-image-2.5-flare']) {
    assert.equal(classifyImageModel(id)?.basis, 'name', id)
  }
  assert.equal(classifyImageModel({ id: 'unknown-generator', architecture: { output_modalities: ['image'] } }).basis, 'metadata')
  assert.equal(classifyImageModel({ id: 'custom-model', supported_endpoint_types: ['openai-image'] }).basis, 'metadata')
  assert.equal(classifyImageModel({ id: 'vision-reader', input_modalities: ['text', 'image'] }), undefined)
  assert.equal(classifyImageModel({ id: 'gemini-2.5-pro', supportedGenerationMethods: ['generateContent'] }), undefined)
  assert.equal(classifyImageModel({ id: 'gpt-image-text-alias', output_modalities: ['text'] }), undefined)
})

test('catalog/config union keeps unknown models and configured-only aliases', () => {
  const records = mergeCatalog([{ id: 'unknown-model' }, { id: 'shared', output_modalities: ['text'] }],
    [{ id: 'gemini-3-pro-image-preview' }, { id: 'shared', output_modalities: ['image'] }])
  assert.deepEqual(records.map((v) => v.id), ['unknown-model', 'shared', 'gemini-3-pro-image-preview'])
  assert.equal(records[2].source, 'config-only')
  assert.equal(classifyImageModel(records[1]), undefined)
})

test('provider query lists every model, differentiates evidence, and uses environment credentials', async (t) => {
  process.env.IMAGE_TOOL_FIXTURE_KEY = 'fixture-key'
  t.after(() => { delete process.env.IMAGE_TOOL_FIXTURE_KEY })
  const llm = { listConfigurableProviders: () => [
    { provider: 'group-a', settingsNs: 'fixture', settingsPath: ['a'] },
    { provider: 'group-b', settingsNs: 'fixture', settingsPath: ['b'] },
  ] }
  const settings = { describe: () => [{ ns: 'fixture', value: {
    a: { baseURL: target.baseUrl, apiKeyEnv: 'IMAGE_TOOL_FIXTURE_KEY', models: [{ id: 'gemini-3-pro-image-preview' }] },
    b: { baseURL: target.baseUrl, apiKeyEnv: 'UNUSED_KEY', models: [] },
  } }] }
  const fetchMock = mock.method(globalThis, 'fetch', async (url, init) => {
    assert.equal(url, `${target.baseUrl}/models`)
    assert.equal(init.headers.Authorization, 'Bearer fixture-key')
    return Response.json({ data: [{ id: 'unknown-model' }, { id: 'gpt-image-2' },
      { id: 'custom-image', output_modalities: ['image'] }] })
  })
  t.after(() => fetchMock.mock.restore())
  const def = tools({ llm, settings }).get('image_providers')
  const result = await def.execute({ provider: 'group-a', probe: true })
  checkSchema(result, def.output.schema)
  assert.match(result.summary, /unknown-model.*未确认图像输出/)
  assert.match(result.summary, /gemini-3-pro-image-preview.*仅配置/)
  assert.match(result.summary, /custom-image.*输出\/端点元数据/)
  assert.match(result.summary, /gpt-image-2.*名称推断/)
  assert.match(result.summary, /同地址其他 provider：group-b/)
  assert.doesNotMatch(result.summary, /fixture-key/)
  assert.equal(fetchMock.mock.callCount(), 1)
})

test('native model catalog paginates and does not leak API keys into the URL', async (t) => {
  const fetchMock = mock.method(globalThis, 'fetch', async (url, init) => {
    assert.equal(init.headers['x-goog-api-key'], target.key)
    assert.ok(!url.includes(target.key))
    return url.includes('pageToken=next')
      ? Response.json({ models: [{ name: 'models/gemini-3-pro-image-preview' }] })
      : Response.json({ models: [{ name: 'models/gemini-2.5-flash-image' }], nextPageToken: 'next' })
  })
  t.after(() => fetchMock.mock.restore())
  const result = await fetchModelCatalog({ baseUrl: 'https://fixture.invalid', key: target.key, api: 'gemini' })
  assert.equal(result.url, 'https://fixture.invalid/v1beta/models')
  assert.equal(result.models.length, 2)
  assert.equal(fetchMock.mock.callCount(), 2)
})

test('malformed model catalog is a failure, not zero available models', async (t) => {
  const fetchMock = mock.method(globalThis, 'fetch', async () => Response.json({ error: 'not a catalog' }))
  t.after(() => fetchMock.mock.restore())
  await assert.rejects(fetchModelCatalog({ baseUrl: target.baseUrl, key: target.key }), /no model array/)
})

test('automatic routing and explicit override remain predictable', () => {
  assert.equal(selectImageApi('auto', 'gpt-image-2'), 'images')
  assert.equal(selectImageApi('auto', 'gemini-3-pro-image-preview'), 'chat')
  assert.equal(selectImageApi('auto', 'gemini-3-pro-image-preview', 'google-generative-ai'), 'gemini')
  assert.equal(selectImageApi('images', 'nano-banana-2'), 'images')
  assert.throws(() => selectImageApi('not-a-protocol', 'gpt-image-2'), /unsupported api/)
})

test('size maps to a standard ratio; resolution is an explicit model-dependent tier', () => {
  assert.deepEqual(imageConfig('2160x3840', '4K'), { aspectRatio: '9:16', imageSize: '4K' })
  assert.deepEqual(imageConfig('1024x1024'), { aspectRatio: '1:1' })
  assert.throws(() => imageConfig('1234x1000'), /aspect ratio/)
  assert.throws(() => imageConfig('0x0'), /positive/)
})

for (const api of ['chat', 'gemini']) {
  test(`${api}: all reference images are sent and generated inline images are extracted`, async (t) => {
    const fetchMock = mock.method(globalThis, 'fetch', async (url, init) => {
      const body = JSON.parse(init.body)
      if (api === 'chat') {
        assert.equal(url, `${target.baseUrl}/chat/completions`)
        assert.equal(body.messages[0].content.filter((v) => v.type === 'image_url').length, 2)
        assert.deepEqual(body.image_config, { aspect_ratio: '9:16', image_size: '4K' })
        assert.equal(body.stream, false)
        return Response.json({ choices: [{ message: { images: [{ image_url: { url: `data:image/png;base64,${PNG.toString('base64')}` } }] } }] })
      }
      assert.equal(url, `${target.baseUrl}/models/gemini-3-pro-image-preview:generateContent`)
      assert.equal(init.headers['x-goog-api-key'], target.key)
      assert.equal(body.contents[0].parts.filter((v) => v.inlineData).length, 2)
      assert.deepEqual(body.generationConfig.imageConfig, { aspectRatio: '9:16', imageSize: '4K' })
      return Response.json({ candidates: [{ content: { parts: [{ inlineData: { mimeType: 'image/png', data: PNG.toString('base64') } }] } }] })
    })
    t.after(() => fetchMock.mock.restore())
    const result = await callMultimodalApi({ api, model: 'gemini-3-pro-image-preview', prompt: portraitPrompt,
      count: 1, size: '2160x3840', resolution: '4K', target,
      images: [{ data: PNG, mediaType: 'image/png' }, { data: PNG, mediaType: 'image/png' }] })
    assert.deepEqual(result.images[0].data, PNG)
    assert.equal(fetchMock.mock.callCount(), 1)
  })
}

test('chat/gemini reject unsupported count and alpha before any paid request', async (t) => {
  const fetchMock = mock.method(globalThis, 'fetch', () => { throw new Error('must not send') })
  t.after(() => fetchMock.mock.restore())
  for (const api of ['chat', 'gemini']) {
    await assert.rejects(callMultimodalApi({ api, model: 'gemini-image', count: 2, target }), /count=1/)
    await assert.rejects(callMultimodalApi({ api, model: 'gemini-image', count: 1, transparent: true, target }), /transparent/)
  }
  assert.equal(fetchMock.mock.callCount(), 0)
})

test('upstream failures are not retried or routed to a second paid endpoint', async (t) => {
  const fetchMock = mock.method(globalThis, 'fetch', async () => Response.json({ error: { message: 'group not enabled' } }, { status: 403 }))
  t.after(() => fetchMock.mock.restore())
  await assert.rejects(callMultimodalApi({ api: 'chat', model: 'nano-banana-2', count: 1, target }), /HTTP 403.*not retried/)
  assert.equal(fetchMock.mock.callCount(), 1)
})

test('result downloads never receive the model API credential', async (t) => {
  const fetchMock = mock.method(globalThis, 'fetch', async (_url, init) => {
    assert.equal(init.headers, undefined)
    return new Response(PNG, { headers: { 'Content-Type': 'image/png' } })
  })
  t.after(() => fetchMock.mock.restore())
  const images = await extractImages({ data: [{ url: 'https://fixture.invalid/portrait.png' }] })
  assert.deepEqual(images[0].data, PNG)
})

test('JPEG base64 is not mislabeled PNG and Markdown/inline_data variants are supported', async () => {
  const jpeg = Buffer.from([255, 216, 255, 224, 0, 0])
  assert.equal((await extractImages({ data: [{ b64_json: jpeg.toString('base64') }] }))[0].mediaType, 'image/jpeg')
  const markdown = await extractImages({ choices: [{ message: { content: `![Zhi](data:image/png;base64,${PNG.toString('base64')})` } }] })
  assert.deepEqual(markdown[0].data, PNG)
  const native = await extractImages({ candidates: [{ content: { parts: [{ inline_data: { mime_type: 'image/png', data: PNG.toString('base64') } }] } }] })
  assert.deepEqual(native[0].data, PNG)
})

test('refusal stays useful without echoing a large model payload', async () => {
  await assert.rejects(extractImages({ candidates: [{ finishReason: 'SAFETY' }], hidden: 'x'.repeat(100000) }), /no image data \(SAFETY\)/)
})
