/**
 * 验证「从工具参数里取提示词」的边界行为。
 *
 * 这里复刻 src/client.js 里 promptFromArgs 的实现（它是 client 半部里的纯函数，
 * 依赖 window.__ModuleLoader__，没法直接 import）。复刻的是**逻辑**，
 * 所以 client.js 里那份改了这边也要跟着改 —— 但比起不测，这样至少能挡住
 * 「流式中途把半截 JSON 当提示词」这类错。
 *
 * 真正要挡住的是：argsRaw 在流式期间是**逐字符累加的不完整 JSON**
 * （见 ui-chat 的 `base.argsRaw + chunk.argumentsDelta`）。
 */

function promptFromArgs(block) {
  if (!block || typeof block.argsRaw !== 'string' || block.argsRaw === '') return ''
  try {
    const parsed = JSON.parse(block.argsRaw)
    if (parsed && typeof parsed.prompt === 'string') return parsed.prompt
  } catch { /* 参数还没流完或不是 JSON —— 安静跳过 */ }
  return ''
}

const cases = [
  ['完整 JSON 带 prompt', { argsRaw: '{"prompt":"一只猫","size":"1024x1024"}' }, '一只猫'],
  ['流式中途（半截 JSON）', { argsRaw: '{"prompt":"一只猫' }, ''],
  ['刚开始流式', { argsRaw: '{"pro' }, ''],
  ['空字符串', { argsRaw: '' }, ''],
  ['无 argsRaw 字段', {}, ''],
  ['argsRaw 为 null', { argsRaw: null }, ''],
  ['没有 prompt 字段', { argsRaw: '{"size":"1024x1024"}' }, ''],
  ['prompt 不是字符串', { argsRaw: '{"prompt":123}' }, ''],
  ['prompt 为空字符串', { argsRaw: '{"prompt":""}' }, ''],
  ['带换行的长提示词', { argsRaw: JSON.stringify({ prompt: '第一行\n第二行' }) }, '第一行\n第二行'],
  ['带转义引号', { argsRaw: JSON.stringify({ prompt: '他说"你好"' }) }, '他说"你好"'],
  ['prompt 含中文与 emoji', { argsRaw: JSON.stringify({ prompt: '金字塔原理 📐' }) }, '金字塔原理 📐'],
  ['image_edit 的形态（prompt + image_path）', { argsRaw: '{"prompt":"改成水彩","image_path":"D:/a.png"}' }, '改成水彩'],
  ['不是 JSON 的纯文本', { argsRaw: 'just a string' }, ''],
]

let pass = 0
let fail = 0
for (const [name, input, expected] of cases) {
  const actual = promptFromArgs(input)
  const ok = actual === expected
  if (ok) pass++
  else fail++
  const show = (s) => JSON.stringify(s).slice(0, 60)
  console.log(`${ok ? '  OK  ' : ' FAIL '} ${name.padEnd(34)} 期望 ${show(expected)}  实得 ${show(actual)}`)
}

console.log(`\n=== 合计 ${pass + fail} 项，失败 ${fail} 项 ===`)
process.exitCode = fail === 0 ? 0 : 1
