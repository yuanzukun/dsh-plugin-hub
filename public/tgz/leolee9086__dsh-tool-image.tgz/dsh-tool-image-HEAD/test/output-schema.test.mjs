import { test } from 'node:test'
import assert from 'node:assert/strict'
import { apply } from '../lib/index.js'

// 宿主的输出契约只接受这个 JSON Schema 子集。注册工具前校验契约本身，
// 与“返回值是否符合契约”分开检查，避免 minimum 等未支持字段导致整组工具失效。
// 保持插件独立：测试不导入 DSH 内部包；实际部署校验器另行验证。
const OUTPUT_KEYWORDS = new Set([
  'type', 'oneOf', 'properties', 'required', 'additionalProperties', 'items', 'enum', 'const',
  'description', 'title', 'default', 'examples',
])

function checkOutputKeywords(schema, path = 'schema') {
  for (const key of Object.keys(schema)) {
    assert.ok(OUTPUT_KEYWORDS.has(key), `${path}.${key}: unsupported output keyword`)
  }
  for (const [name, child] of Object.entries(schema.properties ?? {})) {
    checkOutputKeywords(child, `${path}.properties.${name}`)
  }
  if (schema.items !== undefined) checkOutputKeywords(schema.items, `${path}.items`)
  for (const [index, child] of (schema.oneOf ?? []).entries()) {
    checkOutputKeywords(child, `${path}.oneOf[${index}]`)
  }
}

// 负例证明检查会深入图像元数据，不能只检查顶层或仅验证结果值。
test('output schema contract rejects unsupported nested minimum', () => {
  const schema = { type: 'object', properties: {
    images: { type: 'array', items: { type: 'object', properties: {
      originalDimensions: { type: 'object', properties: {
        width: { type: 'integer', minimum: 1 },
      } },
    } } },
  } }
  assert.throws(() => checkOutputKeywords(schema),
    /schema\.properties\.images\.items\.properties\.originalDimensions\.properties\.width\.minimum/)
})

test('output schema contract permits registration of all three image tools', () => {
  const names = []
  apply({
    tools: {
      register(definition) {
        checkOutputKeywords(definition.output.schema)
        names.push(definition.name)
        // 原图尺寸仍是严格声明的宽高整数；修复不能删除这项信息来躲过校验。
        const dimensions = definition.output.schema.properties.images.items.properties.originalDimensions
        assert.equal(dimensions.type, 'object')
        assert.equal(dimensions.additionalProperties, false)
        assert.deepEqual(dimensions.required, ['width', 'height'])
        assert.equal(dimensions.properties.width.type, 'integer')
        assert.equal(dimensions.properties.height.type, 'integer')
      },
    },
    get() { return undefined },
  }, {})
  assert.deepEqual(names, ['image_generate', 'image_edit', 'image_providers'])
})
