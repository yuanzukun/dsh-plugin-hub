// src/client.js — dsh-tool-image 的浏览器半部（手写 ModuleLoader 格式，零构建）。
//
// 干什么：认领 image_generate / image_edit 两个工具名的专属工具卡，
// 把结果里的 image attachment 渲染成真正的 <img>。产品的通用卡片只会把
// content 拍平成裸 JSON，看不到图，所以这两个工具必须自带一张卡。
//
// 图片字节经 owner props 的 loadImage（会话授权 loader）解析成 URL ——
// 本文件不 import 任何附件实现、也不处理 URL 授权，与产品的图卡契约一致。
//
// 刻意不声明 tool.call.images 子槽位：那个槽位只能被一个 entry 声明，
// 已由产品自带的 read_image 卡占用，再声明会在加载时抛错。所以这里
// 直接拿 loadImage 自己画。
//
// 注意：id 必须与 package.json 的 name 完全一致（client-modules 的 graph
// entry id 与 __ModuleLoader__ 注册 id 强制相等）。
window.__ModuleLoader__.load({
	id: "dsh-tool-image",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });

		// React 从平台模块表取。不同加载路径可能给回 namespace 或 default，
		// 统一成"有 createElement 的那个"，实在没有再退到全局。
		var reactNs = require("react");
		var React = (reactNs && reactNs.createElement) ? reactNs
			: (reactNs && reactNs.default && reactNs.default.createElement) ? reactNs.default
			: globalThis.React;

		const inject = ["slots"];

		// ── 主题 token 语义别名（与同机其它客户端卡一致，不写死颜色） ──
		const T = {
			line: "var(--dsw-alias-line-default, #e8e8e8)",
			fillSecondary: "var(--dsw-alias-fill-secondary, #fff)",
			fillPrimary: "var(--dsw-alias-fill-primary, #fff)",
			ink: "var(--dsw-alias-label-primary)",
			inkSecondary: "var(--dsw-alias-label-secondary)",
			inkTertiary: "var(--dsw-alias-label-tertiary)",
			mono: "var(--dsw-font-markdown-code-block-small, ui-monospace, monospace)",
			accent: "#056de8",
			error: "var(--dsw-alias-state-error-primary, #c5221f)",
		};

		// 透明底素材必须看得见透明区，所以图片底下垫棋盘格，
		// 否则 PNG 的透明区域会被当成白底，看不出抠得干不干净。
		const CHECKER = {
			backgroundColor: "#f7f7f7",
			backgroundImage: "linear-gradient(45deg, #dcdcdc 25%, transparent 25%),"
				+ "linear-gradient(-45deg, #dcdcdc 25%, transparent 25%),"
				+ "linear-gradient(45deg, transparent 75%, #dcdcdc 75%),"
				+ "linear-gradient(-45deg, transparent 75%, #dcdcdc 75%)",
			backgroundSize: "16px 16px",
			backgroundPosition: "0 0, 0 8px, 8px -8px, -8px 0",
		};

		// ── 样式（纯 inline，浏览器半部零构建） ──
		const S = {
			shell: {
				display: "flex", flexDirection: "column", width: "100%", minWidth: 0,
				borderRadius: 12, border: `1px solid ${T.line}`, background: T.fillSecondary,
				overflow: "hidden", boxSizing: "border-box",
			},
			head: {
				display: "flex", alignItems: "center", gap: 8, padding: "10px 14px", minWidth: 0,
				background: T.fillPrimary, borderBottom: `1px solid ${T.line}`,
			},
			icon: {
				width: 22, height: 22, borderRadius: 6, display: "flex", alignItems: "center",
				justifyContent: "center", flex: "none", color: "#fff", background: T.accent,
				fontSize: 12, fontWeight: 800, lineHeight: "22px",
			},
			title: {
				fontSize: 13, fontWeight: 700, color: T.ink, minWidth: 0,
				whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
			},
			count: { fontSize: 12, color: T.inkTertiary, flex: "none", marginLeft: "auto" },
			body: { padding: 12, display: "flex", flexDirection: "column", gap: 10, minWidth: 0 },
			cell: { display: "flex", flexDirection: "column", gap: 4, minWidth: 0 },
			img: {
				width: "100%", height: "auto", borderRadius: 8, display: "block",
				border: `1px solid ${T.line}`, ...CHECKER,
			},
			caption: {
				fontSize: 11, lineHeight: "16px", color: T.inkTertiary, fontFamily: T.mono,
				wordBreak: "break-all",
			},
			hint: { fontSize: 12, lineHeight: "18px", color: T.inkSecondary },
			error: { fontSize: 12, lineHeight: "18px", color: T.error, fontFamily: T.mono, wordBreak: "break-all" },
			// 复制按钮：做成"文字化小按钮"而不是实心按钮 —— 卡片主信息是图，
			// 按钮不该抢视线，但又要一眼看得见、点得到。
			copyBtn: {
				flex: "none", marginLeft: "auto", padding: "3px 10px", borderRadius: 6,
				border: `1px solid ${T.line}`, background: "transparent", color: T.inkSecondary,
				fontSize: 11, lineHeight: "16px", fontFamily: "inherit", cursor: "pointer",
				whiteSpace: "nowrap", userSelect: "none",
			},
			copyBtnDone: { color: T.accent, borderColor: T.accent },
			// 图片行上的小按钮（复制图片 / 存文件）：比头部按钮更轻 ——
			// 它挨着 caption 的等宽小字，做重了会吵。
			miniBtn: {
				flex: "none", padding: "2px 8px", borderRadius: 5,
				border: `1px solid ${T.line}`, background: "transparent", color: T.inkTertiary,
				fontSize: 11, lineHeight: "15px", fontFamily: "inherit", cursor: "pointer",
				whiteSpace: "nowrap", userSelect: "none",
			},
			miniBtnDone: { color: T.accent, borderColor: T.accent },
			miniBtnOff: { opacity: 0.5, cursor: "default" },
			// caption 行：左边文件名与尺寸，右边两个小按钮，窄卡片上允许换行
			captionRow: { display: "flex", alignItems: "center", gap: 6, minWidth: 0, flexWrap: "wrap" },
			captionText: { flex: "1 1 auto", minWidth: 0 },
			feedback: { fontSize: 11, lineHeight: "15px", color: T.inkSecondary, flex: "none" },
		};

		/**
		 * 从原始工具参数里取出提示词。
		 *
		 * 为什么读 argsRaw 而不是等 content：提示词只存在于**参数**里，工具结果是图片，
		 * 不含提示词。argsRaw 是模型生成的 JSON 字符串（未经校验），所以必须容错 ——
		 * 解析失败就当作没有提示词，而不是把整段原始文本当提示词展示（那反而误导）。
		 * 另外运行中的调用 argsRaw 可能还不完整，解析失败自然就不会显示按钮。
		 */
		function promptFromArgs(block) {
			if (!block || typeof block.argsRaw !== "string" || block.argsRaw === "") return "";
			try {
				const parsed = JSON.parse(block.argsRaw);
				if (parsed && typeof parsed.prompt === "string") return parsed.prompt;
			} catch (e) { /* 参数还没流完或不是 JSON —— 安静跳过 */ }
			return "";
		}

		/**
		 * 复制到剪贴板。
		 *
		 * 优先用 navigator.clipboard；它要求安全上下文，而 dsh web 走的是
		 * http://127.0.0.1（浏览器视为可信来源），所以正常路径可用。
		 * 但用户也可能从局域网 IP 打开，那时这个 API 不存在 —— 退回到
		 * 临时的 textarea + execCommand('copy')，覆盖非安全上下文的情况。
		 */
		function copyText(text) {
			if (!text) return Promise.resolve(false);
			if (typeof navigator !== "undefined" && navigator.clipboard && navigator.clipboard.writeText) {
				return navigator.clipboard.writeText(text).then(() => true, () => copyViaTextarea(text));
			}
			return Promise.resolve(copyViaTextarea(text));
		}

		function copyViaTextarea(text) {
			try {
				const el = document.createElement("textarea");
				el.value = text;
				// 放在视口内但透明、无位移，避免 iOS 上因 element 不可见而复制失败
				el.setAttribute("readonly", "");
				el.style.position = "fixed";
				el.style.top = "0";
				el.style.left = "0";
				el.style.width = "1px";
				el.style.height = "1px";
				el.style.padding = "0";
				el.style.border = "none";
				el.style.outline = "none";
				el.style.boxShadow = "none";
				el.style.background = "transparent";
				el.style.opacity = "0";
				document.body.appendChild(el);
				const selection = document.getSelection();
				const previous = selection && selection.rangeCount > 0 ? selection.getRangeAt(0) : null;
				el.select();
				const ok = document.execCommand("copy");
				document.body.removeChild(el);
				// 还原用户原本的选区：不还原的话会清掉他正在选的内容
				if (previous && selection) { selection.removeAllRanges(); selection.addRange(previous); }
				return ok;
			} catch (e) {
				return false;
			}
		}

		/**
		 * 把图片字节从对象 URL 取回来，供剪贴板 / 存文件用。
		 *
		 * 为什么还要再取一次：卡片手里只有 loadImage 给的对象 URL，而剪贴板要的是真实字节。
		 * 这是一次内存读取（blob: URL 不发网络请求），web 端和桌面端都没有跨源问题。
		 */
		function blobFromUrl(url) {
			return fetch(url).then((res) => {
				if (!res.ok) throw new Error("HTTP " + res.status);
				return res.blob();
			});
		}

		/**
		 * 把一张图片写进系统剪贴板 —— 复制的是图本身，能直接粘进 PPT、微信、文档。
		 *
		 * 三条能力要求，缺一条就返回 false 交给调用方回退：
		 *   1) 安全上下文（navigator.clipboard 存在）。web 端从 http://127.0.0.1 打开时成立，
		 *      桌面端 dsh-app:// 协议注册时带了 secure 也成立；但从局域网 IP 打开就不成立。
		 *   2) 有 ClipboardItem 和 clipboard.write（Chromium 76+ / Electron 都有）。
		 *   3) 权限放行：桌面端主窗口只管控 media 权限，其余一律放行，所以这里不会被拦。
		 * 失败一律吞掉异常返回 false —— 调用方要能退化成"存文件"，而不是只弹一句错误。
		 */
		function writeImageToClipboard(blob) {
			const clip = typeof navigator === "undefined" ? undefined : navigator.clipboard;
			const Item = typeof window === "undefined" ? undefined : window.ClipboardItem;
			if (!clip || typeof clip.write !== "function" || typeof Item !== "function") {
				return Promise.resolve(false);
			}
			// 剪贴板只认它认识的图片 MIME；取不到就按 png（gpt-image 系默认出的就是 png）
			const type = blob && blob.type ? blob.type : "image/png";
			try {
				return clip.write([new Item({ [type]: blob })]).then(() => true, () => false);
			} catch (e) {
				return Promise.resolve(false);
			}
		}

		/** 按图片类型补文件扩展名。 */
		function extensionFor(type) {
			if (type === "image/jpeg") return "jpg";
			if (type === "image/webp") return "webp";
			if (type === "image/gif") return "gif";
			return "png";
		}

		/** 存文件的文件名：沿用附件名，扩展名按真实字节类型纠正。 */
		function fileNameFor(att, blob) {
			const raw = att && typeof att.name === "string" && att.name !== "" ? att.name : "image";
			const stem = raw.replace(/\.[A-Za-z0-9]+$/, "") || "image";
			return stem + "." + extensionFor(blob && blob.type);
		}

		/**
		 * 把字节存成文件 —— 复制图片不可用时的回退出口（非安全上下文、老浏览器、权限被拒）。
		 * 桌面端同样有效：dsh-app:// 是标准协议，普通 <a download> 由 Electron 自己接管落盘。
		 */
		function downloadBlob(blob, name) {
			try {
				const url = URL.createObjectURL(blob);
				const a = document.createElement("a");
				a.href = url;
				a.download = name;
				a.style.display = "none";
				document.body.appendChild(a);
				a.click();
				document.body.removeChild(a);
				// 立刻 revoke 会让下载来不及读取数据，留一段时间再释放
				setTimeout(() => URL.revokeObjectURL(url), 20000);
				return true;
			} catch (e) {
				return false;
			}
		}

		// 从 settled ToolCallBlock 的 content 数组里提取全部 { type:'image', attachment }。
		// 等价于产品 imageCardModel 的提取步；浏览器半部没有模块解析能力，
		// 因此在这里用纯函数复刻，输入输出都来自会话事件的 wire 值。
		function imageAttachments(block) {
			const content = block && block.content;
			if (!Array.isArray(content)) return [];
			return content
				.filter((b) => b && b.type === "image" && b.attachment)
				.map((b) => b.attachment);
		}

		/** 取附件引用上的一个数值字段，缺省返回 undefined。 */
		function num(att, key) {
			const v = att && att[key];
			return typeof v === "number" ? v : undefined;
		}

		/** 图片按钮的反馈文案。 */
		const NOTE_TEXT = { copied: "已复制", saved: "已存文件", failed: "没能复制，也没存成" };

		function ImageView(props) {
			const block = props.block;
			const atts = imageAttachments(block);
			const loadImage = props.loadImage;
			const isEdit = props.toolName === "image_edit";
			const [urls, setUrls] = React.useState([]);
			const [blobs, setBlobs] = React.useState([]);
			const [err, setErr] = React.useState("");
			const [loading, setLoading] = React.useState(true);
			// 每张图各自的按钮反馈，按索引存：'copied' | 'saved' | 'failed'
			const [note, setNote] = React.useState({});

			React.useEffect(() => {
				let alive = true;
				if (atts.length === 0) { setLoading(false); return undefined; }
				if (typeof loadImage !== "function") {
					setErr("loadImage 不可用"); setLoading(false);
					return undefined;
				}
				setLoading(true); setErr(""); setBlobs([]); setNote({});
				Promise.all(atts.map((att) => loadImage(att)))
					.then((us) => {
						if (!alive) return;
						setUrls(us); setLoading(false);
						// 再把字节取回来供复制/存文件用：分两步是为了让图先显示出来，
						// 取字节失败也不该影响看图（失败的那张按钮会保持不可用）。
						Promise.all(us.map((u) => blobFromUrl(u).catch(() => null)))
							.then((bs) => { if (alive) setBlobs(bs); });
					})
					.catch((e) => {
						if (!alive) return;
						setErr(String((e && e.message) || e)); setLoading(false);
					});
				return () => { alive = false; };
			}, [atts.length, block]);

			// ToolCallBlock 是判别联合：RunningToolCall（运行中）| ToolResultNode（已结算）。
			// 已结算的节点带 kind === "tool-result"；运行中的没有 kind 字段。
			// 必须区分这两者，否则「正在生成」会被渲染成「没有返回图片」——把进行中误报成失败。
			const settled = block && block.kind === "tool-result"
			const running = !settled

			// 提示词只存在于工具参数里，与图片结果无关，算一次即可。
			// 运行中 argsRaw 还不完整 → 解析不出 → 按钮不出现；结算后才出现。
			const prompt = React.useMemo(() => promptFromArgs(block), [block]);
			const [copied, setCopied] = React.useState(false);
			// 记住计时器句柄，卸载时清掉：否则组件已卸载还 setState，React 会警告
			const copyTimer = React.useRef(null);
			React.useEffect(() => () => {
				if (copyTimer.current !== null) clearTimeout(copyTimer.current);
			}, []);

			const handleCopy = React.useCallback(() => {
				copyText(prompt).then((ok) => {
					if (!ok) return;
					setCopied(true);
					if (copyTimer.current !== null) clearTimeout(copyTimer.current);
					// 1.6 秒后复原：足够看见反馈，又不会一直占着"已复制"的状态
					copyTimer.current = setTimeout(() => setCopied(false), 1600);
				});
			}, [prompt]);

			// 每张图一个反馈计时器，按索引记；卸载时一起清掉
			const noteTimers = React.useRef({});
			React.useEffect(() => () => {
				for (const key of Object.keys(noteTimers.current)) clearTimeout(noteTimers.current[key]);
			}, []);

			const flash = React.useCallback((index, state) => {
				setNote((prev) => ({ ...prev, [index]: state }));
				if (noteTimers.current[index] !== undefined) clearTimeout(noteTimers.current[index]);
				noteTimers.current[index] = setTimeout(() => {
					setNote((prev) => {
						const next = { ...prev };
						delete next[index];
						return next;
					});
				}, 2000);
			}, []);

			/**
			 * 复制这张图。两端都能走：
			 *   - web 端从 http://127.0.0.1 打开 ⇒ 安全上下文 ⇒ clipboard.write 可用；
			 *   - 桌面端 dsh-app:// 注册为 secure、主窗口权限一律放行 ⇒ 同样可用。
			 * 从局域网 IP 打开（非安全上下文）或浏览器不支持图片剪贴板时，writeImageToClipboard
			 * 返回 false，这里直接退化成存文件 —— 让用户拿到东西，而不是白点一下。
			 */
			const handleCopyImage = React.useCallback((index) => {
				const blob = blobs[index];
				if (!blob) return;
				writeImageToClipboard(blob).then((ok) => {
					if (ok) { flash(index, "copied"); return; }
					const saved = downloadBlob(blob, fileNameFor(atts[index], blob));
					flash(index, saved ? "saved" : "failed");
				});
			}, [blobs, atts, flash]);

			const handleSaveImage = React.useCallback((index) => {
				const blob = blobs[index];
				if (!blob) return;
				flash(index, downloadBlob(blob, fileNameFor(atts[index], blob)) ? "saved" : "failed");
			}, [blobs, atts, flash]);

			let body;
			if (running && atts.length === 0) {
				// 生成需要几十秒，这段时间必须明确告知"在做"，而不是让用户以为失败了
				body = React.createElement("div", { style: S.hint }, isEdit ? "正在处理图片…" : "正在生成图片…");
			} else if (err) {
				body = React.createElement("div", { style: S.error }, "图片读取失败：" + err);
			} else if (loading && atts.length > 0) {
				body = React.createElement("div", { style: S.hint }, "正在加载图片…");
			} else if (atts.length === 0) {
				// 到这里就真的是已结算且没有图片附件了（例如调用报错、或只返回了文字）
				body = React.createElement("div", { style: S.hint }, "（这次调用没有返回图片）");
			} else {
				const grid = {
					display: "grid",
					gridTemplateColumns: atts.length > 1 ? "repeat(2, minmax(0, 1fr))" : "minmax(0, 1fr)",
					gap: 10,
					minWidth: 0,
				};
				body = React.createElement("div", { style: grid }, atts.map((att, i) => {
					const w = num(att, "width");
					const h = num(att, "height");
					const caption = (att.name || "image") + (w === undefined ? "" : `  ${w}x${h}`);
					const hasBlob = Boolean(blobs[i]);
					const state = note[i];
					return React.createElement("div", {
						key: String(i) + String(att.attachmentId || ""),
						style: S.cell,
					},
						React.createElement("img", { src: urls[i], alt: att.name || "生成图", style: S.img }),
						React.createElement("div", { style: S.captionRow },
							React.createElement("span", { style: { ...S.caption, ...S.captionText } }, caption),
							state === undefined
								? null
								: React.createElement("span", { style: S.feedback }, NOTE_TEXT[state]),
							React.createElement("button", {
								type: "button",
								disabled: !hasBlob,
								style: hasBlob
									? (state === "copied" ? { ...S.miniBtn, ...S.miniBtnDone } : S.miniBtn)
									: { ...S.miniBtn, ...S.miniBtnOff },
								title: hasBlob
									? "复制这张图（可直接粘进 PPT、微信、文档）"
									: "图片字节还在准备……",
								onClick: () => handleCopyImage(i),
							}, "复制图片"),
							React.createElement("button", {
								type: "button",
								disabled: !hasBlob,
								style: hasBlob ? S.miniBtn : { ...S.miniBtn, ...S.miniBtnOff },
								title: hasBlob ? "把这张图存成文件" : "图片字节还在准备……",
								onClick: () => handleSaveImage(i),
							}, "存文件"),
						),
					);
				}));
			}

			return React.createElement("div", { style: S.shell },
				React.createElement("div", { style: S.head },
					React.createElement("span", { style: S.icon }, "图"),
					React.createElement("span", { style: S.title }, isEdit ? "参考改图" : "生成图片"),
					atts.length > 0
						? React.createElement("span", { style: S.count }, atts.length + " 张")
						: null,
					// 复制提示词：拿生成这张图用的 prompt 去改或复用。
					// 只在真的解析出提示词时才显示 —— 没提示词却给个按钮，点了没内容是更差的体验。
					prompt
						? React.createElement("button", {
							type: "button",
							style: copied ? { ...S.copyBtn, ...S.copyBtnDone } : S.copyBtn,
							title: copied ? "已复制到剪贴板" : "复制生成这张图用的提示词",
							onClick: handleCopy,
						}, copied ? "已复制" : "复制提示词")
						: null,
				),
				React.createElement("div", { style: S.body }, body),
			);
		}

		/** 本包认领的两个工具名，各自一张同样的卡。 */
		const KEYS = ["image_generate", "image_edit"];

		exports.apply = function apply(ctx) {
			const stops = [];
			for (const key of KEYS) {
				// slots.inject 等到槽位真的被声明再注册，随 caller fiber 的生命周期清理。
				stops.push(ctx.slots.inject("tool.call.toolview", () =>
					ctx.slots.register({ name: "tool.call.toolview", key: key }, ImageView)));
			}
			return function dispose() {
				for (const stop of stops) { if (typeof stop === "function") stop(); }
			};
		};
		exports.inject = inject;
		return module.exports;
	},
});
