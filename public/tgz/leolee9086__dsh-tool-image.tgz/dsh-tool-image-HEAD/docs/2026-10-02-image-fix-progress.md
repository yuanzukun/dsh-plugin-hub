# Image tool repair progress

## Checkpoint

- Time: 2026-10-02; latest clock sample 21:23:39 +08:00, Asia/Shanghai.
- Location: D:\dev\dsh-tool-image. The desktop profile node_modules/dsh-tool-image junction targets this repository. git status was clean before this work. Installed runtime version: 0.2.0-rc.2 (runtime.json). No background jobs.
- Intent: repair image_edit success being rejected by strict output schema after attachment normalization; improve image model discovery and transport adaptation, as requested by brother.
- Result: code and tests written, NOT YET EXECUTED; documentation and runtime reload remain pending. Do not claim tested or live.

## Changes So Far

- lib/index.js: added strictly typed optional originalDimensions {width,height} to image output schema while keeping additionalProperties=false; summary distinguishes original and normalized preview sizes.
- lib/index.js: imports new protocol and catalog helpers. Existing images endpoint flow stays intact; dispatches chat/gemini with explicit api override or auto suggestion. Added api and resolution tool params. Added safe filename sanitization for native models/gemini-* IDs. Captures provider api and safe declared model leaves. Provider query uses environment key before file fallback, unions catalog and config entries, shows unknown models by default, marks metadata versus name evidence, and lists same-baseURL sibling providers. Native directory protocol selectable, paginated. Query descriptions no longer claim a directory proves site-wide support/permission.
- lib/image-protocols.js (new): chat/completions and native Gemini generateContent requests, multiple reference image inputs, ratio/tier options, parsing OpenAI image data, chat images/content/Markdown, native inlineData/inline_data, safe image URL downloads without forwarding API credentials. Native x-goog-api-key header, no key in URL. Reject count>1 and alpha for chat/native before sending, no paid fallback/retry. MIME sniffing handles JPEG base64 correctly.
- lib/model-catalog.js (new): output metadata first; expanded Gemini image/nano-banana/dall-e/grok-imagine-image/etc name hints; vision input or generateContent alone not treated as image output. Catalog/config union preserves unknown IDs and config-only aliases; native Google model pagination with repeated-token guard; malformed model lists fail explicitly.
- test/image-tool.test.mjs (new): production tool registration/schema inspected; fake network, ephemeral test directories. Covers large image ref metadata for generate/edit, rendering and file safety, union and evidence, env credentials and sibling warning, native pagination, malformed catalogs, routing, ratios, multimodal reference requests, reject unsupported options before fetch, no paid retry, no key forwarding, JPEG/Markdown/native parsers, safety refusal. All tests still unrun.
- test/prompt-copy.test.mjs existing remains unchanged.

## Evidence

Installed runtime attachment local implementation (read ASAR virtual paths with Electron fs because read tool cannot access them) returns optional originalDimensions only when preview width/height differs from source. Shape verified exactly {width:detected.width,height:detected.height}. Package dsh-attachment-local/lib/index.js lines 330-348. Default preview pixel budget 2048*2048. This is why 4K only failed output validation, while lower-resolution tool results did not.

AIHub full read-only directory audit using the existing plugin's credential resolver, WITHOUT reading or displaying secrets directly: /models and /v1/models both return 22 records under AIHUB_IMAGE_ONLY_API_KEY, whose raw fields are id,object,created,owned_by,type,display_name. Six IDs match current gpt-image family: 1,1.5,2,2.5,2.5-flare,2.5-sunburst. Ordinary AIHUB_API_KEY directory reports23records/3gpt-image names. Native /v1beta/models using existing Authorization returns400: API key group platform is not gemini. Therefore no evidence these current credentials list all site families; key group matters. Brother says there are more image models, so do not insist these six are the site's complete offerings. Adaptation is broadened, but Gemini permission or paid generation is NOT verified.

Public web_search failed HTTP402 DeepSeek insufficient balance. Did not alter search settings or retry paid search.

## Next Work

1. Add package.json scripts.test = node --test test/*.test.mjs (no dependencies needed), then run pnpm test in this repo. Fix failures before claiming anything. Do not install at workspace root.
2. Review implementations: parsing robustness, native Imagen unsupported path distinction, prompt/options validation, image dedup behavior possibly reducing returned count, normalizer metadata schema, no unwanted automatic requests. Catalog/OpenAI pagination uncertainty should be visible instead of claiming completeness. All manual edits use edit/write, read before modification.
3. Update README (currently misleading old defaults/credential assumptions and HMR claims) and package description to current APIs/limits, retain sponsorship footer. Add metadata docs.
4. git diff --check, tests, production import/check. Optional replay existing saved4K bytes against a local fixture and fresh strict schema, never regenerate paid output for this regression. Plugin has no build scripts; lib/index.js is the actual entry, new lib modules shipped by files declaration already.
5. Host code requires restart_harness approved at END of tool flow, after saving complete checkpoint. Do not promise live before restart and distinctive image_providers output verifies newly loaded version. Current tools still old registered schema. Current running GUI URL http://127.0.0.1:19387. Do not start another server.

## Deliverable Already Completed

[4K Zhi portrait](<D:/dev/织的形象/2026-10-02-4K立绘/2026-10-02T12-59-50-gpt-image-2-1.png>) actual2160x3840, approx8.9MB. The preview is1536x2730 JPEG; original PNG is not overwritten. Source profile ref [original](<C:/Users/al765/.dsh/.agent-presets/cordis-no-subagents/assets/zhi/立绘-写实.png>)1024x1536. Same face, brown eyes, mole, black side braid with gold/cyan/lavender filaments, dark-blue top; added charcoal trousers and black short boots, full body visible. [Prompt](<D:/dev/织的形象/prompts/13-2026-10-02-4K全身立绘.md>) and [acceptance](<D:/dev/织的形象/2026-10-02-4K立绘/2026-10-02-4K立绘验收.md>) exist. Final answer still needs show main image/link alongside fix results.

Meaningful test loads rule is remembered via session_blocks_remember: even capability tests must create something useful. New actual web generations would use Zhi assets, not disposable samples. Present tests are offline mocks and spend no image credits.

Earlier complete checkpoint [here](<D:/dev/aihub-image-tests/2026-10-02/2026-10-02-210313-生图插件修复检查点.md>). Loaded skills: dsh-general,memos,character-ip,cordis-plugin-development,dsh-plugin-development. Skills have already been read. No Cordis composition changes. No credentials or deployment presets modified. Need keep concise commentary every ~30 seconds and record time/location/intent/result at boundaries.
