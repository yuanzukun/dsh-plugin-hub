/**
 * cau-portal L2：文章原文阅读（阶段4 第4步 批②/③）。
 * 面包屑（来源 → 栏目 → 标题）+ 标题/来源/时间 + AI 摘要框 + deadline 高亮 +
 * 正文全文（pre-wrap）+ 查看原文（新标签）+ 上一篇/下一篇 +
 * 加入/取消关注（无上限）+ 待办类文章的 留存/归档。
 * 数据：data/articles/<id>.json（经数据层读取；ai 已内联在文章文件）。
 */
import { useEffect, useMemo, useState } from 'react'
import {
  readArticleMeta,
  cacheFollowArticle,
  loadFollow,
  saveFollow,
  loadDeadlineOps,
  setDeadlineOp,
  isFollowed,
  isPruned,
  isMine,
  addMine,
  removeMine,
  enrichArticle,
  loadSettings,
  loadModules,
  siteOfItem,
  siteColorOf,
} from './data'
import { addAttached, removeAttached, hasAttached } from './bus'
import { Ic } from './icons'

const idOf = (it: { article_id?: string; url?: string }) => it.article_id || it.url || ''

/** 统一门户（tp_up）→ 专属界面（不标注「正文未抓取」） */
const isPortal = (u?: string) => /tp_up/.test(String(u || ''))

/**
 * 「正文即附件」页（苏迪 wp_pdf_player 等）：正文位置没有一个字，只有一个附件播放器。
 * 2026-09-21 起这类页不再谎报「正文未抓取」，而是如实说明正文是哪个附件（不抽附件内文字）。
 */
const attLabel = (kind?: string) => (kind === 'pdf' ? 'PDF 附件' : kind === 'doc' ? '文档附件' : kind === 'video' ? '视频附件' : '附件')

function fmt(iso: string | null | undefined): string {
  if (!iso) return ''
  return String(iso)
}

export function ArticleView(props: {
  articleId: string
  siteName?: string
  columnName?: string
  onBack: () => void
  onOpenArticle: (id: string, siblings?: { id: string; title: string }[], index?: number) => void
  siblings?: { id: string; title: string }[]
  index?: number
  onTitle?: (title: string) => void
}) {
  const { articleId, siteName, columnName, onBack, onOpenArticle, siblings, index, onTitle } = props
  const mods = useMemo(() => loadModules(), [])
  const [art, setArt] = useState<any | null>(null)
  const [phase, setPhase] = useState<'loading' | 'ready' | 'error'>('loading')
  const [followed, setFollowed] = useState(false)
  const [deadlineOp, setDeadlineOpState] = useState<string | null>(null)
  const [aiBusy, setAiBusy] = useState(false)
  const [aiOut, setAiOut] = useState<any | null>(null)
  const [aiErr, setAiErr] = useState('')
  const [fromCache, setFromCache] = useState(false)
  const [mined, setMined] = useState(() => isMine(articleId))

  const reload = async () => {
    setPhase('loading')
    setAiOut(null)
    setAiErr('')
    const r = await readArticleMeta(articleId)
    if (!r) {
      setPhase('error')
      return
    }
    setArt(r.article)
    setFromCache(r.cached)
    setPhase('ready')
    setFollowed(isFollowed(articleId))
    setDeadlineOpState(loadDeadlineOps()[articleId] || null)
    setQuoted(hasAttached(articleId))
    // autoAttach：打开文章时自动附加阅读上下文（设置 → 面板偏好；已手动引用的不重复）
    try {
      if (loadSettings().autoAttach && !hasAttached(articleId) && r.article.title) {
        addAttached({ id: articleId, title: r.article.title, source: r.article.source || siteName || '' })
        setQuoted(true)
      }
    } catch {
      /* 附加失败不影响阅读 */
    }
    if (r.article.title) onTitle?.(r.article.title)
  }

  useEffect(() => {
    void reload()
  }, [articleId])

  const runEnrich = async () => {
    setAiBusy(true)
    setAiErr('')
    const s = loadSettings()
    const out = await enrichArticle(articleId, {
      provider: s.monitorModel?.provider,
      model: s.monitorModel?.model,
    })
    setAiBusy(false)
    if (out?.ok) setAiOut(out.result)
    else setAiErr(String(out?.error || '加工失败'))
  }

  // 引用到对话：追加这篇（可多篇）；点击切换引用/取消
  const [quoted, setQuoted] = useState(false)
  const attachToChat = () => {
    if (!art?.title) return
    if (hasAttached(articleId)) {
      removeAttached(articleId)
      setQuoted(false)
    } else {
      addAttached({ id: articleId, title: art.title, source: art.source || siteName || '' })
      setQuoted(true)
    }
  }

  const toggleFollowNow = () => {
    const cur = loadFollow()
    const idx = cur.findIndex((x) => x.id === articleId)
    let next: typeof cur
    if (idx >= 0) next = cur.filter((x) => x.id !== articleId)
    else
      next = [
        { id: articleId, title: art?.title || '', url: art?.url || '', time: art?.time || null, source: art?.source || '', column: columnName || '', importance: art?.ai?.importance, summary: art?.ai?.summary },
        ...cur,
      ]
    saveFollow(next)
    setFollowed(idx < 0)
    // 关注 → 存整篇本地快照（云端保留期外仍可读）；取消 → 清除快照
    cacheFollowArticle(articleId, idx < 0 ? art : null)
  }

  const hasDeadline = !!(art?.ai?.deadline && art?.ai?.deadline.date)
  const op = deadlineOp || ''

  const toggleMineNow = async () => {
    if (isMine(articleId)) {
      removeMine(articleId)
      setMined(false)
    } else {
      await addMine(articleId, {
        title: art?.ai?.deadline?.item || art?.title || '事项',
        articleTitle: art?.title,
        url: art?.url || '',
        deadline: hasDeadline ? art.ai.deadline.date : undefined,
        source: art?.source || '',
        column: columnName || '',
      })
      setMined(true)
    }
  }

  /** 该来源的主题色：设了就把本页所有「品牌绿」（AI 摘要条、小标签、按钮…）换成它的颜色 */
  const srcColor = useMemo(() => (art?.url ? siteColorOf(siteOfItem(art)) : ''), [art])

  return (
    <div
      className={'dsh-cau_view' + (srcColor ? ' dsh-cau_siteAccent' : '')}
      style={srcColor ? ({ '--cau-site-base': srcColor } as any) : undefined}
    >
      <div className="dsh-cau_bread">
        <button type="button" className="dsh-cau_backBtn" onClick={onBack}>
          <Ic n="chevLeft" />
          返回
        </button>
        <span className="dsh-cau_breadPath">
          {[siteName || art?.source, columnName].filter(Boolean).join(' · ')}
        </span>
      </div>

      {phase === 'loading' && (
        <div className="dsh-cau_loading">
          <span className="dsh-cau_spinner" />
          <span>加载中…</span>
        </div>
      )}
      {phase === 'error' && (
        <div className="dsh-cau_msg">
          <div className="dsh-cau_msgText">
            {isPruned(articleId)
              ? '该数据已被删除（数据管理模式）。'
              : '文章读取失败（正文可能尚未抓取入库，或已被删除）。'}
          </div>
          {art && art.url ? (
            <a className="dsh-cau_msgBtn" href={art.url} target="_blank" rel="noreferrer">
              查看原文
            </a>
          ) : null}
          <button type="button" className="dsh-cau_msgBtn" onClick={() => void reload()}>
            重试
          </button>
        </div>
      )}

      {phase === 'ready' && art && (
        <>
          <h1 className="dsh-cau_atitle">{art.title || '(无标题)'}</h1>
          <div className="dsh-cau_ameta">
            {isPortal(art?.url) && <span className="dsh-cau_portalTag">校内平台</span>}
            {art.source && <span>{art.source}</span>}
            {art.time && <span>{fmt(art.time)}</span>}
            {art.is_image_only && <span className="dsh-cau_aimgTag">纯图公告</span>}
            {art.is_attachment_only && <span className="dsh-cau_aimgTag">{attLabel(art.attachment?.kind)}</span>}
            {fromCache && <span className="dsh-cau_acacheTag">本地缓存</span>}
          </div>

          {mods.ai && art.ai?.summary && (
            <div className="dsh-cau_asummary">
              <div className="dsh-cau_asumHead">
                <span className="dsh-cau_secMark" />
                <span>AI 摘要</span>
              </div>
              <div className="dsh-cau_asumText">{art.ai.summary}</div>
            </div>
          )}

          {mods.ai && !art.ai?.summary && !aiOut && (
            <div className="dsh-cau_asummary">
              <div className="dsh-cau_asumHead">
                <span className="dsh-cau_secMark" />
                <span>AI 摘要</span>
              </div>
              <div className="dsh-cau_asumText dsh-cau_empty">本文暂无 AI 加工（摘要/分类/重要度/deadline）。</div>
              <div className="dsh-cau_aactions">
                <button type="button" className="dsh-cau_aBtn" disabled={aiBusy} onClick={() => void runEnrich()}>
                  {aiBusy ? '加工中…' : (<><Ic n="sparkle" />AI 补摘要</>)}
                </button>
              </div>
              {aiErr && <div className="dsh-cau_setErr">{aiErr}</div>}
            </div>
          )}

          {mods.ai && aiOut && (
            <div className="dsh-cau_asummary">
              <div className="dsh-cau_asumHead">
                <span className="dsh-cau_secMark" />
                <span>AI 摘要（本次会话内生成）</span>
              </div>
              {aiOut.summary && <div className="dsh-cau_asumText">{aiOut.summary}</div>}
              <div className="dsh-cau_ameta">
                {aiOut.category && <span>分类：{aiOut.category}</span>}
                {aiOut.importance && <span>重要度：{aiOut.importance}</span>}
                {aiOut.deadline_note && <span className="dsh-cau_setErr">{aiOut.deadline_note}</span>}
              </div>
            </div>
          )}

          {hasDeadline && (
            <div className="dsh-cau_adeadline">
              <span className="dsh-cau_adeadlineIcon">
                <Ic n="clock" />
              </span>
              <span className="dsh-cau_adeadlineItem">{art.ai.deadline.item}</span>
              <span className="dsh-cau_adeadlineDate">{art.ai.deadline.date}</span>
              {art.ai.deadline.evidence && <span className="dsh-cau_adeadlineEv">「{art.ai.deadline.evidence}」</span>}
            </div>
          )}

          {/* 同一份通知里的其它截止（2026-10-20 补）：主项进待办，附项只在这里展示，避免待办被撑长 */}
          {hasDeadline && Array.isArray(art.ai.deadlines_extra) && art.ai.deadlines_extra.length > 0 && (
            <div className="dsh-cau_adeadlineMore">
              <span className="dsh-cau_adeadlineMoreTitle">同一通知里的其它截止</span>
              {(art.ai.deadlines_extra as any[]).map((x: any) => (
                <div className="dsh-cau_adeadlineMoreRow" key={`${x.date}|${x.item}`}>
                  <span className="dsh-cau_adeadlineMoreDate">{x.date}</span>
                  <span className="dsh-cau_adeadlineMoreItem">{x.item}</span>
                </div>
              ))}
            </div>
          )}

          <div className="dsh-cau_abody">
            {isPortal(art?.url) ? (
              <div className="dsh-cau_portalCard">
                <div className="dsh-cau_portalCardTitle">
                  <Ic n="idCard" />
                  校内平台通知
                </div>
                <div className="dsh-cau_portalCardDesc">
                  本篇来自<b>统一门户</b>（校内平台），正文在门户内、需登录后查看。为保护个人敏感信息（名单、成绩、学籍等不受控），
                  插件按隐私原则<b>不收录正文</b>，只保留标题、来源与 AI 摘要。
                </div>
                <div className="dsh-cau_aactions">
                  {art.url && (
                    <a className="dsh-cau_aBtn dsh-cau_aBtnPrimary" href={art.url} target="_blank" rel="noreferrer">
                      <Ic n="ext" />
                      新标签打开门户原文
                    </a>
                  )}
                </div>
              </div>
            ) : (
              art.body || (
                <span className="dsh-cau_empty">
                  {art.is_attachment_only ? (
                    <>
                      本文正文为{attLabel(art.attachment?.kind)}
                      {art.attachment?.name ? `：${art.attachment.name}` : ''}，本插件不抽取附件内的文字。请点「查看原文」查看。
                    </>
                  ) : (
                    '正文未抓取。请点「查看原文」。'
                  )}
                </span>
              )
            )}
          </div>

          <div className="dsh-cau_aactions">
            {art.url && (
              <a className="dsh-cau_aBtn" href={art.url} target="_blank" rel="noreferrer">
                查看原文
                <Ic n="ext" />
              </a>
            )}
            {mods.context && (
              <button
                type="button"
                className={'dsh-cau_aBtn' + (quoted ? ' dsh-cau_aBtnOn' : ' dsh-cau_aBtnPrimary')}
                onClick={attachToChat}
              >
                {quoted ? '已引用 ✓（点此取消）' : '引用到对话'}
              </button>
            )}
            {mods.deadline && (
              <button
                type="button"
                className={'dsh-cau_aBtn' + (followed ? ' dsh-cau_aBtnOn' : '')}
                onClick={toggleFollowNow}
              >
                <Ic n={followed ? 'starFill' : 'star'} />
                {followed ? '已关注' : '加入关注'}
              </button>
            )}
            {hasDeadline && (
              <>
                <button
                  type="button"
                  className={'dsh-cau_aBtn' + (mined ? ' dsh-cau_aBtnOn' : '')}
                  onClick={() => void toggleMineNow()}
                >
                  <Ic n={mined ? 'starFill' : 'star'} />
                  {mined ? '已在我的事项' : '我的事项'}
                </button>
                <button
                  type="button"
                  className={'dsh-cau_aBtn' + (op === 'archive' ? ' dsh-cau_aBtnOn' : '')}
                  onClick={() => setDeadlineOpState(setDeadlineOp(articleId, op === 'archive' ? null : 'archive')[articleId] || null)}
                >
                  归档
                </button>
              </>
            )}
          </div>

          {(siblings && siblings.length > 1) && (
            <div className="dsh-cau_anav">
              {index != null && index > 0 ? (
                <button
                  type="button"
                  className="dsh-cau_anavBtn"
                  onClick={() => onOpenArticle(siblings[index - 1].id, siblings, index - 1)}
                >
                  <Ic n="chevLeft" />
                  上一篇
                </button>
              ) : (
                <span />
              )}
              {index != null && index < siblings.length - 1 ? (
                <button
                  type="button"
                  className="dsh-cau_anavBtn"
                  onClick={() => onOpenArticle(siblings[index + 1].id, siblings, index + 1)}
                >
                  下一篇
                  <Ic n="chevRight" />
                </button>
              ) : (
                <span />
              )}
            </div>
          )}
        </>
      )}
    </div>
  )
}
