/**
 * cau-portal L0：首页聚合（阶段4 第4步 批②/③）。
 * 待办截止卡（能手动 留存/归档；点击→原文；「归档 n」入口回溯）+ 要闻（AI 重要，上限10、可加入关注）+
 * 关注栏（无上限）+ 栏目频道（可点进学院/栏目专栏，列出全部推文）+ 快捷入口。
 * 数据：index.json + summary.json（缓存由调用方/本组件直接读云端，量小）。
 */
import { useEffect, useMemo, useState } from 'react'
import {
  readCloudJson,
  loadFollow,
  saveFollow,
  loadDeadlineOps,
  isPruned,
  loadModules,
  loadChannels,
  siteShown,
  columnShown,
  siteOfItem,
  loadSiteDirectory,
  groupOfItem,
  siteGroupOf,
  siteNameOf,
  GROUP_LABEL,
  type SiteGroup,
  type DirSite,
  loadMine,
  removeMine,
  updateMine,
  addCustomMine,
  mineDeadlineOf,
  migrateMineFromPin,
  loadRules,
  matchRules,
  daysLeft,
} from './data'
import { Empty } from './empty'
import { Ic } from './icons'
import { fmtCn } from './news-row'

type DeadlineItem = { item: string; date: string; title: string; article_id?: string; url?: string; column?: string; source?: string; time?: string | null }

export function HomeView(props: {
  onOpenColumn: (site: string, column: string | null) => void
  onOpenArticle: (id: string, siblings: { id: string; title: string }[], index: number) => void
  onViewArchive: () => void
  onViewFollow: () => void
  onViewDeadlines: () => void
  onViewNews: () => void
}) {
  const { onOpenColumn, onOpenArticle, onViewArchive, onViewFollow, onViewDeadlines, onViewNews } = props
  const [phase, setPhase] = useState<'loading' | 'maybe-token' | 'error' | 'ready'>('loading')
  /** 站点目录（sites.json 配置 + index.json 数据合并）——「栏目频道」的清单来源 */
  const [dir, setDir] = useState<DirSite[]>([])
  const [summary, setSummary] = useState<any>(null)
  const [follow, setFollow] = useState<any[]>(() => loadFollow())
  const [ops, setOps] = useState<Record<string, any>>(() => loadDeadlineOps())
  const [mine, setMine] = useState<Record<string, any>>(() => loadMine())
  const [mineEdit, setMineEdit] = useState<{ id: string | null; name: string; date: string; url: string } | null>(null)

  const startMineEdit = (id?: string) => {
    setMineEdit(getMineEditDraft(id))
  }
  const getMineEditDraft = (id?: string) => {
    if (id) {
      const m = loadMine()[id]
      const shown = mineRows.find((r: any) => r.id === id)
      return { id, name: shown?.title || m?.title || '', date: mineDeadlineOf(m) || '', url: m?.article_url || '' }
    }
    return { id: null, name: '', date: '', url: '' }
  }
  const [needToken, setNeedToken] = useState(false)
  const mods = useMemo(() => loadModules(), [])
  /** 栏目频道订阅（设置 → 栏目频道管理）；黑名单语义，缺省全开 */
  const channels = useMemo(() => loadChannels(), [])

  const load = async () => {
    setPhase('loading')
    const [idx, sum, directory] = await Promise.all([
      readCloudJson('data/index.json'),
      readCloudJson('data/summary.json'),
      loadSiteDirectory(),
    ])
    setDir(Array.isArray(directory) ? directory : [])
    if (!idx && !sum) {
      setNeedToken(true)
      setPhase('maybe-token')
      return
    }
    setSummary(sum)
    migrateMineFromPin()
    setMine(loadMine())
    setPhase('ready')
  }

  useEffect(() => {
    void load()
  }, [])

  /** 全部重要条目（已排除被清理/归档的） */
  const importantAll = useMemo(
    () =>
      (summary?.important || []).filter(
        (it: any) => !isPruned(it.article_id || it.url) && ops[it.article_id || it.url] !== 'archive',
      ),
    [summary, ops],
  )

  /**
   * 要闻口径：被「栏目频道管理」关掉的站点，其条目不再进「要闻」「今日要览」与未读计数。
   * 只影响首页呈现——数据照抓、AI 照加工、待办/关注/归档与 MCP 查询都不受影响。
   * 依赖 dir：站点目录（含各站 baseUrl）加载完成后要重算一次，否则新接入站点的归属认不出来。
   */
  const important = useMemo(
    () => importantAll.filter((it: any) => siteShown(channels, siteOfItem(it))),
    [importantAll, channels, dir],
  )

  /** 首页「栏目频道」可见站点：订阅开关过滤；清单来自站点目录（配置驱动）
   *  → 刚添加、还没抓到的来源也会出现（标「尚未抓取」）；校内平台在开源版标「不可用」并禁用 */
  const channelSites = useMemo(() => dir.filter((s: DirSite) => siteShown(channels, s.id)), [dir, channels])
  /** 三组来源（校内平台 / 校内其他 / 校外来源）—— 校外来源单独成组，避免挤占本校通知的视线 */
  const sitesByGroup = useMemo(() => {
    const out: Record<SiteGroup, DirSite[]> = { portal: [], campus: [], external: [] }
    for (const s of channelSites) out[siteGroupOf(s.id)].push(s)
    return out
  }, [channelSites, dir])

  /** 要闻：首页只放一行入口，点进二级页看完整列表（2026-09-14 用户拍板）；这里只算各组条数 */
  const isPortalIt = (it: any) => /tp_up/.test(String(it.url || ''))
  const newsCounts = useMemo(() => {
    const out: Record<SiteGroup, number> = { portal: 0, campus: 0, external: 0 }
    for (const it of important) {
      if (!mods.portal && isPortalIt(it)) continue
      out[groupOfItem(it)]++
    }
    return out
  }, [important, mods.portal, dir])
  const newsTotal = newsCounts.portal + newsCounts.campus + newsCounts.external


  /** 我的事项：精选大卡（标题/日期快照 + 云端 deadline 富集；含已过期） */
  const mineRows = useMemo(() => {
    const dlById = new Map((summary?.deadlines || []).map((d: any) => [d.article_id || d.url, d]))
    return Object.entries(mine)
      .map(([id, m]: any) => {
        const d = dlById.get(id)
        const date = mineDeadlineOf(m) || d?.date || null
        // 事项名语义：m.task=true 用 m.title（用户给定）；旧记录优先 AI 提取的事项名 d.item
        const title = m.task ? m.title || d?.item : d?.item || m.title || d?.title || '(事项)'
        return { id, title, date, column: m.column || d?.column || '', artUrl: m.article_url || d?.url || '', artTitle: d?.title || '' }
      })
      .sort((a: any, b: any) => String(b.date || '9999-12-31').localeCompare(String(a.date || '9999-12-31')))
  }, [mine, summary])

  /** 全部未过期截止数（未归档） */
  const allDeadlines = useMemo(
    () => (summary?.deadlines || []).filter((d: DeadlineItem) => ops[d.article_id || d.url] !== 'archive').length,
    [summary, ops],
  )

  // ---------- 今日要览（主动察觉层：高重要新进 · 3天内截止 · 关注规则命中） ----------
  const watchRules = useMemo(() => loadRules().filter((r) => r.enabled), [])
  const overview = useMemo(() => {
    const imp = important.filter((it: any) => mods.portal || !isPortalIt(it))
    const cut = Date.now() - 3 * 86400000
    const recentOk = (t: any) => {
      const x = Date.parse(String(t || ''))
      return !Number.isFinite(x) || x >= cut
    }
    const high = imp.filter((it: any) => it.importance === '高' && recentOk(it.time))
    const hits = imp.filter((it: any) => matchRules(watchRules, it).length > 0 && recentOk(it.time))
    const dueSoon = (summary?.deadlines || []).filter((d: any) => ops[d.article_id || d.url] !== 'archive').filter((d: any) => {
      const n = daysLeft(d.date)
      return Number.isFinite(n) && n >= 0 && n <= 3
    })
    const top = [...high.map((it: any) => ({ ...it, tag: 'high' })), ...hits.map((it: any) => ({ ...it, tag: 'hit' }))]
      .filter((v: any, i: number, arr: any[]) => arr.findIndex((x) => (x.article_id || x.url) === (v.article_id || v.url)) === i)
      .slice(0, 3)
    return { high: high.length, due: dueSoon.length, hits: hits.length, top }
  }, [summary, important, watchRules, mods.portal])

  const archiveCount = useMemo(
    () => (summary?.deadlines || []).filter((d: DeadlineItem) => ops[d.article_id || d.url] === 'archive').length,
    [summary, ops],
  )

  /** 打开文章：40 位 hex id → 面板内阅读；否则（无正文条目/自定义事项）新标签开原文 */
  const openArt = (it: any, sibs: { id: string; title: string }[], index: number) => {
    const id = it.article_id || it.url
    if (id && /^[0-9a-f]{40}$/.test(id.replace(/\.json$/, ''))) onOpenArticle(id, sibs, index)
    else if (it.url) window.open(it.url, '_blank', 'noopener')
  }

  const toggleFollow = (it: any) => {
    const cur = loadFollow()
    const idx = cur.findIndex((x) => x.id === it.id)
    let next: any[]
    if (idx >= 0) next = cur.filter((x) => x.id !== it.id)
    else next = [{ id: it.id, title: it.title, url: it.url, time: it.time, source: it.source, column: it.column, importance: it.importance, summary: it.summary }, ...cur]
    saveFollow(next)
    setFollow(next)
  }

  /**
   * 栏目频道分组（校内平台 / 校内其他 / 校外来源共用）。
   * 新添加、还没抓到的来源：栏目名照显（来自 sites.json），但不显示条目数，另加一句「尚未抓取」。
   */

  /**
   * 栏目频道分组（学院 / 教务处 / 校新闻网共用）。
   * split=true 时在底部加一条细分割线——校内平台与其余来源在首页要有一点点视觉分隔；
   * 开源版不提供统一门户（校内平台），该行渲染为禁用 +「不可用」标签。
   * 新添加、还没抓到的来源：栏目名照显（来自 sites.json），但不显示条目数，另加一句「尚未抓取」。
   */
  const colGroup = (site: any, split?: boolean) => {
    const off = site.id === 'portal'
    return (
      <div className={'dsh-cau_colGroup' + (split ? ' dsh-cau_colGroupSplit' : '')} key={site.id}>
        <button
          type="button"
          className={'dsh-cau_colSiteBtn' + (off ? ' dsh-cau_dis' : '')}
          disabled={off}
          onClick={() => !off && onOpenColumn(site.id, null)}
        >
          {siteNameOf(site.id) || site.name} ›{off && <span className="dsh-cau_disTag">不可用</span>}
        </button>
        {!off && (
          <div className="dsh-cau_colChips">
            {(site.columns || [])
              .filter((c: any) => columnShown(channels, site.id, c.key))
              .map((c: any) => (
                <button key={c.key} type="button" className="dsh-cau_chip dsh-cau_chipBtn" onClick={() => onOpenColumn(site.id, c.key)}>
                  {c.name}
                  {typeof c.items === 'number' && c.items > 0 && <em className="dsh-cau_chipCount">{c.items}</em>}
                </button>
              ))}
          </div>
        )}
        {!off && site.pending && <div className="dsh-cau_colPending">尚未抓取 · 下一轮抓取后出现条目</div>}
      </div>
    )
  }

  return (
    <div className="dsh-cau_view">
      {phase === 'loading' && (
        <div className="dsh-cau_loading">
          <span className="dsh-cau_spinner" />
          <span>加载中…</span>
        </div>
      )}
      {phase === 'maybe-token' && (
        <div className="dsh-cau_msg">
          <div className="dsh-cau_msgText">需要 GitHub 只读令牌才能读取云端数据。</div>
          <button type="button" className="dsh-cau_msgBtn dsh-cau_msgBtnPrimary" onClick={() => void load()}>
            去配置
          </button>
        </div>
      )}
      {phase === 'error' && (
        <div className="dsh-cau_msg">
          <div className="dsh-cau_msgText">云端读取失败。</div>
          <button type="button" className="dsh-cau_msgBtn" onClick={() => void load()}>
            重试
          </button>
        </div>
      )}
      {phase === 'ready' && (
        <>
          {!summary && <div className="dsh-cau_hint">聚合数据生成中…栏目与快捷入口仍可用。</div>}
          {(summary?.summaryReason === 'missing' || summary?.summaryReason === 'error') && (
            <div className="dsh-cau_hint">待办与要闻聚合暂不可用（云端 summary.json 未就绪），其余功能正常。</div>
          )}

          {/* 今日要览：打开面板第一眼（高重要新进 · 即将截止 · 关注规则命中） */}
          {(overview.high > 0 || overview.due > 0 || overview.hits > 0) && (
            <div className="dsh-cau_ov">
              <span className="dsh-cau_ovTitle">
                <Ic n="sparkle" />
                今日要览
              </span>
              {overview.high > 0 && <span className="dsh-cau_ovChip hl">高重要新进 {overview.high}</span>}
              {overview.due > 0 && (
                <span className="dsh-cau_ovChip due">
                  <Ic n="clock" />3 天内截止 {overview.due}
                </span>
              )}
              {overview.hits > 0 && (
                <span className="dsh-cau_ovChip hit">
                  <Ic n="target" />命中关注 {overview.hits}
                </span>
              )}
              {overview.top.length > 0 && (
                <div className="dsh-cau_ovList">
                  {overview.top.map((it: any) => (
                    <span key={String(it.article_id || it.url)} className="dsh-cau_ovRow" onClick={() => openArt(it, [], 0)}>
                      <em>{it.tag === 'high' ? '高' : <Ic n="target" />}</em>
                      {groupOfItem(it) === 'external' && (
                        <span className="dsh-cau_ovTag" title="校外来源（外校，仅供保研等长期关注；与本校通知分开展示）">
                          校外
                        </span>
                      )}
                      <span className="dsh-cau_ovTitleTxt">{it.title}</span>
                      <i>{[it.column, it.source].filter(Boolean).join(' · ')}</i>
                    </span>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* 我的事项（人工精选大卡） + 全部待办入口 */}
          {mods.deadline && (
            <div className="dsh-cau_sec">
              <div className="dsh-cau_secHead">
                <span className="dsh-cau_secMark" />
                <span className="dsh-cau_secTitle">
                  <Ic n="star" />
                  我的事项
                </span>
                <span className="dsh-cau_secLine" />
                <span className="dsh-cau_secActs">
                  <button type="button" className="dsh-cau_textBtn" onClick={() => startMineEdit()}>
                    <Ic n="plus" />自定义事项
                  </button>
                  {allDeadlines > 0 && (
                    <button type="button" className="dsh-cau_textBtn" onClick={onViewDeadlines}>
                      全部待办 {allDeadlines} ›
                    </button>
                  )}
                </span>
              </div>
              {mineRows.length === 0 ? (
                <Empty icon={<Ic n="note" />} main="还没有我的事项" sub="点「+ 自定义事项」直接记录要办的事；或在「全部待办」/文章页点「我的事项」精选（附原文链接）" />
              ) : (
                <div className="dsh-cau_mineGrid">
                  {mineRows.map(({ id, title, date, column, artUrl, artTitle }: any) => {
                    const mm = /^\d{4}-(\d{1,2})-(\d{1,2})/.exec(String(date || ''))
                    const n = date ? daysLeft(String(date)) : Number.NaN
                    const expired = Number.isFinite(n) && n < 0
                    const urgent = Number.isFinite(n) && n >= 0 && n <= 3
                    const canArticle = !String(id).startsWith('custom-')
                    return (
                      <div key={id} className={'dsh-cau_mineCard' + (expired ? ' expired' : urgent ? (n <= 1 ? ' due' : ' soon') : '')}>
                        <div className="dsh-cau_mineDate">
                          {mm ? (
                            <>
                              <span className="dsh-cau_mineDay">{+mm[2]}</span>
                              <span className="dsh-cau_mineYM">{+mm[1]}月</span>
                            </>
                          ) : (
                            <span className="dsh-cau_mineYM">未设日期</span>
                          )}
                          <span className="dsh-cau_mineCount">{!Number.isFinite(n) ? '—' : expired ? '已过期' : n === 0 ? '今天' : `剩 ${n} 天`}</span>
                        </div>
                        <div className="dsh-cau_mineTitle" title={title}>
                          {title}
                        </div>
                        {artTitle && artTitle !== title && (
                          <div className="dsh-cau_mineSrc" title={artTitle}>
                            {artTitle}
                          </div>
                        )}
                        <div className="dsh-cau_mineFoot">
                          {column && <span className="dsh-cau_mineCol">{column}</span>}
                          {!column && <span />}
                          <span className="dsh-cau_mineActs">
                            {artUrl && canArticle && (
                              <button
                                type="button"
                                className="dsh-cau_mineArt"
                                title="打开对应文章"
                                onClick={(e) => {
                                  e.stopPropagation()
                                  if (id) openArt({ article_id: id, url: artUrl }, [], 0)
                                }}
                              >
                                原文
                                <Ic n="ext" />
                              </button>
                            )}
                            <button
                              type="button"
                              className="dsh-cau_textBtn"
                              onClick={(e) => {
                                e.stopPropagation()
                                startMineEdit(id)
                              }}
                            >
                              <Ic n="edit" />编辑
                            </button>
                            <button
                              type="button"
                              className="dsh-cau_textBtn"
                              onClick={(e) => {
                                e.stopPropagation()
                                removeMine(id)
                                setMine(loadMine())
                              }}
                            >
                              <Ic n="close" />移出
                            </button>
                          </span>
                        </div>
                        {mineEdit && (mineEdit.id || '') === id && (
                          <div className="dsh-cau_mineEdit" onClick={(e) => e.stopPropagation()}>
                            <label className="dsh-cau_mineLabel">
                              <span>事项名（点此修改，如「土地学院2027推免生报名」）</span>
                              <input className="dsh-cau_setInput" value={mineEdit.name} onChange={(e) => setMineEdit({ ...mineEdit, name: e.target.value })} />
                            </label>
                            <div className="dsh-cau_mineEditRow">
                              <label className="dsh-cau_mineLabel">
                                <span>截止日期</span>
                                <input className="dsh-cau_setInput" type="date" value={mineEdit.date} onChange={(e) => setMineEdit({ ...mineEdit, date: e.target.value })} />
                              </label>
                              <label className="dsh-cau_mineLabel">
                                <span>原文链接（可空）</span>
                                <input className="dsh-cau_setInput" value={mineEdit.url} onChange={(e) => setMineEdit({ ...mineEdit, url: e.target.value })} />
                              </label>
                            </div>
                            <div className="dsh-cau_mineEditRow">
                              <button
                                type="button"
                                className="dsh-cau_textBtn dsh-cau_on"
                                onClick={() => {
                                  if (mineEdit.id) updateMine(mineEdit.id, { title: mineEdit.name, url: mineEdit.url, deadline: mineEdit.date })
                                  else if (mineEdit.name.trim()) addCustomMine({ title: mineEdit.name.trim(), deadline: mineEdit.date, url: mineEdit.url })
                                  setMine(loadMine())
                                  setMineEdit(null)
                                }}
                              >
                                保存
                              </button>
                              <button type="button" className="dsh-cau_textBtn" onClick={() => setMineEdit(null)}>
                                取消
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              )}
              {mineEdit && !mineEdit.id && (
                <div className="dsh-cau_mineEdit dsh-cau_mineEditNew">
                  <label className="dsh-cau_mineLabel">
                    <span>事项名（要做什么，如「土地学院2027推免生报名」）</span>
                    <input className="dsh-cau_setInput" value={mineEdit.name} onChange={(e) => setMineEdit({ ...mineEdit, name: e.target.value })} />
                  </label>
                  <div className="dsh-cau_mineEditRow">
                    <label className="dsh-cau_mineLabel">
                      <span>截止日期（可空）</span>
                      <input className="dsh-cau_setInput" type="date" value={mineEdit.date} onChange={(e) => setMineEdit({ ...mineEdit, date: e.target.value })} />
                    </label>
                    <label className="dsh-cau_mineLabel">
                      <span>原文链接（可空）</span>
                      <input className="dsh-cau_setInput" value={mineEdit.url} onChange={(e) => setMineEdit({ ...mineEdit, url: e.target.value })} />
                    </label>
                  </div>
                  <div className="dsh-cau_mineEditRow">
                    <button
                      type="button"
                      className="dsh-cau_textBtn dsh-cau_on"
                      onClick={() => {
                        if (mineEdit.name.trim()) {
                          addCustomMine({ title: mineEdit.name.trim(), deadline: mineEdit.date, url: mineEdit.url })
                          setMine(loadMine())
                          setMineEdit(null)
                        }
                      }}
                    >
                      保存
                    </button>
                    <button type="button" className="dsh-cau_textBtn" onClick={() => setMineEdit(null)}>
                      取消
                    </button>
                  </div>
                </div>
              )}
              <div className="dsh-cau_deadlineEntry">
                <span className="dsh-cau_deadlineEntryMain" role="button" onClick={onViewDeadlines}>
                  <Ic n="clipboard" />
                  全部待办（含所有截止事项）
                  <span className="dsh-cau_deadlineEntryArrow">筛选与查看 ›</span>
                </span>
                {archiveCount > 0 && (
                  <button type="button" className="dsh-cau_textBtn" onClick={onViewArchive}>
                    归档 {archiveCount}
                  </button>
                )}
              </div>
            </div>
          )}

          {/*
            要闻入口（2026-09-14 用户拍板：完整列表移到二级页）。
            为什么：浙大/北大这类外校来源是为保研关注的，条目一多会把农大自己的通知挤掉；
            首页只留这一行（带本校/校外条数），点进去才看列表。
          */}
          <div className="dsh-cau_sec">
            <div className="dsh-cau_secHead">
              <span className="dsh-cau_secMark" />
              <span className="dsh-cau_secTitle">
                <Ic n="flame" />
                要闻
              </span>
              <span className="dsh-cau_secLine" />
            </div>
            <button type="button" className="dsh-cau_newsEntry" onClick={onViewNews} title="点开看完整要闻（按来源分三栏）">
              <span className="dsh-cau_newsEntryIcon">
                <Ic n="flame" />
              </span>
              <span className="dsh-cau_newsEntryBody">
                <span className="dsh-cau_newsEntryTop">
                  <span className="dsh-cau_newsEntryTitle">要闻</span>
                  <span className="dsh-cau_newsEntryCount">{newsTotal} 条 · 点开查看</span>
                </span>
                <span className="dsh-cau_newsEntryMeta">
                  {mods.portal && (
                    <span className="dsh-cau_newsChip">
                      <Ic n="bank" />
                      校内平台 {newsCounts.portal}
                    </span>
                  )}
                  <span className="dsh-cau_newsChip">
                    <Ic n="books" />
                    校内其他 {newsCounts.campus}
                  </span>
                  <span className="dsh-cau_newsChip dsh-cau_newsChipExt">
                    <Ic n="ext" />
                    校外来源 {newsCounts.external}
                  </span>
                </span>
              </span>
              <span className="dsh-cau_newsEntryArrow">
                <Ic n="chevRight" />
              </span>
            </button>
          </div>

          {/* 关注栏 */}
          {mods.deadline && (
          <div className="dsh-cau_sec">
            <div className="dsh-cau_secHead">
              <span className="dsh-cau_secMark" />
              <span className="dsh-cau_secTitle">
                <Ic n="bookmark" />
                关注
              </span>
              <span className="dsh-cau_secLine" />
              {follow.length > 0 && (
                <button type="button" className="dsh-cau_textBtn" onClick={onViewFollow}>
                  查看全部 {follow.length}
                </button>
              )}
            </div>
            <div className="dsh-cau_card">
              {follow.length === 0 && <Empty icon={<Ic n="bookmark" />} main="还没有关注内容" sub="在文章里点「加入关注」，重要内容集中在这，不设上限" />}
              {follow.slice(0, 5).map((it) => (
                <div className="dsh-cau_row" key={it.id}>
                  <span className="dsh-cau_rowMain" onClick={() => onOpenArticle(it.id, follow.map((x) => ({ id: x.id, title: x.title })), 0)}>
                    <span className="dsh-cau_rowTitle">{it.title}</span>
                    <span className="dsh-cau_rowMeta">{[it.column, it.source, fmtCn(it.time)].filter(Boolean).join(' · ')}</span>
                  </span>
                  <button type="button" className="dsh-cau_followBtn dsh-cau_on" title="取消关注" onClick={() => toggleFollow(it)}>
                    <Ic n="starFill" />
                  </button>
                </div>
              ))}
            </div>
          </div>
          )}

          {/* 栏目频道 */}
          <div className="dsh-cau_sec">
            <div className="dsh-cau_secHead">
              <span className="dsh-cau_secMark" />
              <span className="dsh-cau_secTitle">
                <Ic n="books" />
                栏目频道
              </span>
              <span className="dsh-cau_secLine" />
            </div>
            {(['portal', 'campus', 'external'] as SiteGroup[]).map((g: SiteGroup) =>
              sitesByGroup[g].length === 0 ? null : (
                <div className="dsh-cau_group" key={g}>
                  <div className="dsh-cau_groupHead">
                    <span className="dsh-cau_groupIcon">
                      <Ic n={g === 'portal' ? 'bank' : g === 'campus' ? 'books' : 'ext'} />
                    </span>
                    <span className="dsh-cau_groupTitle">{GROUP_LABEL[g]}</span>
                    <em>{sitesByGroup[g].length} 个来源</em>
                    <span className="dsh-cau_secLine" />
                  </div>
                  {sitesByGroup[g].map((site: any) => colGroup(site))}
                </div>
              ),
            )}
            {channelSites.length === 0 && (
              <Empty
                icon={<Ic n="books" />}
                main="所有来源都已关闭"
                sub="到「设置 → 栏目频道管理」把要看的栏目重新打开即可，数据一直都在"
              />
            )}
          </div>

          {/* 快捷入口 */}
          <div className="dsh-cau_sec">
            <div className="dsh-cau_secHead">
              <span className="dsh-cau_secMark" />
              <span className="dsh-cau_secTitle">
                <Ic n="link" />
                快捷入口
              </span>
              <span className="dsh-cau_secLine" />
            </div>
            <div className="dsh-cau_quick">
              <a className="dsh-cau_quickLink" href="https://one.cau.edu.cn" target="_blank" rel="noreferrer">统一门户<Ic n="ext" /></a>
              <a className="dsh-cau_quickLink" href="https://clst.cau.edu.cn" target="_blank" rel="noreferrer">学院官网<Ic n="ext" /></a>
              <a className="dsh-cau_quickLink" href="https://jwc.cau.edu.cn" target="_blank" rel="noreferrer">教务处<Ic n="ext" /></a>
              <a className="dsh-cau_quickLink" href="https://news.cau.edu.cn" target="_blank" rel="noreferrer">校新闻网<Ic n="ext" /></a>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
