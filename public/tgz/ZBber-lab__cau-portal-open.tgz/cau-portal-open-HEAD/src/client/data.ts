/**
 * cau-portal 客户端数据层（阶段4 第3步）：
 * - localStorage 设置（键约定 dsh.cau-portal.*；githubToken 仅存本机）
 * - GitHub Contents API 读取 data/ 下文件（直连优先，服务端 /api/cau/data 代理兜底）
 */

export type SettingsV1 = {
  /** 只读细粒度 PAT（Contents: Read，仅本机 localStorage） */
  githubToken?: string
  /** AI 加工/监控模型（独立配置槽，与主对话模型解耦；null=用服务端默认） */
  monitorModel?: { provider: string; model: string } | null
  /** 打开文章自动附加阅读上下文（阶段6 消费，默认开） */
  autoAttach?: boolean
  /** 各 key/令牌的过期日（YYYY-MM-DD），用于时限提醒；键约定如 github/bridge/push */
  keyExpiries?: Record<string, string>
  /** 面板「固定」开关（固定后点外部/Esc 不关闭，仅 ✕ 关） */
  panelPinned?: boolean
  /** 系统通知开关（命中关注规则/高重要时弹浏览器通知；默认关） */
  notifyOn?: boolean
  /** 数据仓库（owner/repo；空=未配置 —— 必须在「设置 → 数据源」填写，不再有内置默认仓）。开源后安装者填自己的数据仓。 */
  dataRepo?: string
}

const SETTINGS_KEY = 'dsh.cau-portal.settings.v1'
/**
 * 内置默认数据仓**已删除**（2026-09-30 #1，Codex 报告的问题 #1）：不配置就是"未配置"，
 * 绝不静默去读别人的仓（旧默认值 `ZBber-lab/cau-portal` 恰好等于作者自己的仓，把 bug 遮住了）。
 */
const DEFAULT_DATA_REPO = ''
const GH_BRANCH = 'main'

/** 当前数据仓库（owner/repo）：兼容完整 URL（`https://` 可省）/ `.git` 后缀 / 末尾斜杠；**未配置返回 ''**
 *  ⚠️ 归一化规则有**三份拷贝**（这里、服务端 `src/index.ts`、`tools/mcp/index.mjs`）——改一处
 *  必须三处一起改、逐字一致；**先删末尾 `/` 再删 `.git`** 的顺序是关键（否则 `…/r.git/` 漏成
 *  `…/r.git` → 404）。本文件会被内联多份，注释尽量短。 */
export function dataRepo(): string {
  try {
    const r = String(loadSettings().dataRepo || '')
      .trim()
      .replace(/^(?:https?:\/\/)?(?:www\.)?github\.com\//i, '')
      .replace(/\/+$/, '')
      .replace(/\.git$/i, '')
      .replace(/\/+$/, '')
      .trim()
    if (r && /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(r)) return r
  } catch {
    /* 忽略 */
  }
  return DEFAULT_DATA_REPO
}

/** 取数据仓（owner/repo）；**未配置时抛可操作错误** —— 客户端读取/写入的统一入口 */
function requireDataRepo(): string {
  const r = dataRepo()
  if (!r) throw new Error('请先配置数据仓库（设置 → 数据源）')
  return r
}

export function loadSettings(): SettingsV1 {
  try {
    return JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}')
  } catch {
    return {}
  }
}

export function saveSettings(s: SettingsV1) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(s))
  } catch {
    /* 隐私模式等写入失败时静默 */
  }
}

// ---- 数据仓配置（2026-09-30 #1）----
// 面板「设置 → 数据源」填一次 → 经服务端 PUT /api/cau/config 写进本机共享存储
// `<profile>\cau-portal-store\config.json` → MCP 与 tools/ 每次调用现读（5 秒缓存）。
// 从此**不必**再在 profile 的 `cordis.patch.yml` 里给 mcp-cau 的 env 手写 CAU_GITHUB_REPO。
// （**推送那一步在 `settings.tsx`**：`scheduleDataRepoConfig()` 只有设置页用，放这里会被内联多份。）

/** 读服务端那份数据仓配置（旧服务端没有这条路由时静默返回"未配置"） */
export async function fetchServerDataRepo(): Promise<{ configured: boolean; dataRepo: string; branch: string }> {
  try {
    const res = await fetch('/api/cau/config')
    const j: any = await res.json().catch(() => null)
    if (j?.ok) return { configured: !!j.configured, dataRepo: String(j.dataRepo || ''), branch: String(j.branch || 'main') }
  } catch {
    /* 静默 */
  }
  return { configured: false, dataRepo: '', branch: 'main' }
}

/**
 * 打开面板/设置时回读：本地 `dataRepo` 为空则用服务端那份回填（"缺什么补什么"，与令牌一致）。
 * @returns 是否真的补进来了（true 时调用方要重挂载视图，让各视图用新仓库重新取数）
 */
export async function adoptServerDataRepo(): Promise<boolean> {
  const cur = loadSettings()
  if (String(cur.dataRepo || '').trim()) return false
  const srv = await fetchServerDataRepo()
  if (!srv.dataRepo) return false
  // ⚠️ 回填前重读一次（Codex 2026-09-30 复审 #3b）：await 期间用户可能已在设置页输入仓名，
  // 拿 GET 前的旧快照回填会覆盖它（设置页那份已修，这条父组件路径上一批漏了）。
  const now = loadSettings()
  if (String(now.dataRepo || '').trim()) return false
  saveSettings({ ...now, dataRepo: srv.dataRepo })
  return true
}

async function ghFetchText(rel: string, token: string): Promise<string> {
  const res = await fetch(`https://api.github.com/repos/${requireDataRepo()}/contents/${rel}?ref=${GH_BRANCH}`, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/vnd.github.raw',
      'User-Agent': 'cau-portal-panel',
    },
  })
  if (!res.ok) throw new Error(`GitHub ${res.status}`)
  return res.text()
}

async function serverProxyText(rel: string, token: string): Promise<string> {
  const res = await fetch('/api/cau/data', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path: rel, token, repo: requireDataRepo() }),
  })
  let data: any = null
  try {
    data = await res.json()
  } catch {
    /* fallthrough */
  }
  if (!res.ok || !data?.ok) throw new Error(data?.error || `proxy ${res.status}`)
  return data.text
}

/** 读取 data/ 下相对子路径的文本；未配置令牌时抛错。
 * 多令牌故障转移：依次尝试启用的令牌，仅鉴权类错误（401/403）换下一枚；
 * 404（文件不存在）等非鉴权错误不换令牌；全部失败后走服务端代理兜底。 */
export async function readCloudText(rel: string, token?: string): Promise<string> {
  if (!loadModules().cloud) throw new Error('数据源已在设置中禁用')
  requireDataRepo() // 未配置数据仓 → 明确报错，不拼空仓地址（2026-09-30 #1）
  const tokens = (token ? [token] : activeTokenValues()).filter(Boolean)
  if (!tokens.length) throw new Error('未配置 GitHub 只读令牌')
  let lastErr: unknown = null
  for (const t of tokens) {
    try {
      return await ghFetchText(rel, t)
    } catch (e: any) {
      lastErr = e
      const m = String(e?.message || e)
      if (!/(401|403|Bad credentials|Unauthorized)/i.test(m)) break
    }
  }
  try {
    return await serverProxyText(rel, tokens[0])
  } catch (e) {
    throw lastErr || e
  }
}

export async function readCloudJson<T = any>(rel: string, token?: string): Promise<T | null> {
  try {
    return JSON.parse(await readCloudText(rel, token))
  } catch {
    return null
  }
}

// ---- 数据管理：删除请求队列（面板勾选 → 云端 data/prune-request.json，下轮抓取执行）----
// 客户端只读令牌本身含 Contents 读写，写清单文件与读同权限边界；删除动作由 Actions 在下轮
// crawl 中执行（router 逻辑见 tools/scraper/prune.mjs），无并发冲突。

export type PruneRequest = { version: number; requested_at: string | null; ids: string[] }

const PRUNE_REQUEST_REL = 'data/prune-request.json'
const PRUNED_KEY = 'dsh.cau-portal.pruned.v1'

/** 读取 GitHub 文件元信息（sha + 解码文本）；文件不存在返回空 */
async function ghFetchShaAndText(rel: string, token: string): Promise<{ sha: string; text: string }> {
  const res = await fetch(`https://api.github.com/repos/${requireDataRepo()}/contents/${rel}?ref=${GH_BRANCH}`, {
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github+json', 'User-Agent': 'cau-portal-panel' },
  })
  if (res.status === 404) return { sha: '', text: '' }
  if (!res.ok) throw new Error(`GitHub ${res.status}`)
  const j = await res.json()
  let text = ''
  try {
    text = decodeURIComponent(escape(atob(String(j.content || ''))))
  } catch { /* base64 解码失败：忽略 */ }
  return { sha: String(j.sha || ''), text }
}

/** 写 GitHub 文件（Contents API PUT；存在时带 sha 防覆盖） */
async function ghPutText(rel: string, token: string, content: string, sha: string): Promise<void> {
  const body: any = {
    message: 'data: prune request (panel)',
    content: btoa(unescape(encodeURIComponent(content))),
    branch: GH_BRANCH,
  }
  if (sha) body.sha = sha
  const res = await fetch(`https://api.github.com/repos/${requireDataRepo()}/contents/${rel}`, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/vnd.github+json',
      'Content-Type': 'application/json',
      'User-Agent': 'cau-portal-panel',
    },
    body: JSON.stringify(body),
  })
  if (!res.ok) throw new Error(`GitHub write ${res.status}`)
}

/** 本机「已删除」集合（删除后立即隐藏；键 dsh.cau-portal.pruned.v1） */
export function loadPrunedSet(): string[] {
  try {
    const v = JSON.parse(localStorage.getItem(PRUNED_KEY) || '[]')
    return Array.isArray(v) ? v.filter((x) => typeof x === 'string') : []
  } catch {
    return []
  }
}

function savePrunedSet(ids: string[]) {
  try {
    localStorage.setItem(PRUNED_KEY, JSON.stringify(ids.slice(-5000)))
  } catch {
    /* 静默 */
  }
}

/** 该条目是否已被删除（本地软过滤用；id 为文章 base 或 URL） */
export function isPruned(id: string): boolean {
  return loadPrunedSet().includes(id)
}

/**
 * 提交删除请求：条目 id（文章文件名 xxxx.json 或 URL）写入云端清单（合并去重），
 * 并记入本机已删集合。云端将在下轮抓取（≤2 小时）真正删除。
 */
export async function queuePruneRequest(newIds: string[], token?: string): Promise<{ ok: boolean; total: number; error?: string }> {
  const t = token || activeTokenValues()[0]
  if (!t) return { ok: false, total: 0, error: '未配置 GitHub 令牌' }
  const clean = (newIds || []).filter((x) => typeof x === 'string' && x)
  if (!clean.length) return { ok: false, total: 0, error: '未选择要删除的数据' }
  try {
    const meta = await ghFetchShaAndText(PRUNE_REQUEST_REL, t)
    let prev: string[] = []
    try {
      const p = JSON.parse(meta.text)
      if (Array.isArray(p?.ids)) prev = p.ids.filter((x: any) => typeof x === 'string')
    } catch { /* 旧/坏清单按空处理 */ }
    const merged = [...new Set([...prev, ...clean])]
    await ghPutText(PRUNE_REQUEST_REL, t, JSON.stringify({ version: 1, requested_at: new Date().toISOString(), ids: merged }, null, 2), meta.sha)
    savePrunedSet([...new Set([...loadPrunedSet(), ...clean])])
    return { ok: true, total: merged.length }
  } catch (e: any) {
    return { ok: false, total: 0, error: String(e?.message || e) }
  }
}

// ---- 功能模块开关（设置页分组卡片右上角；键 dsh.cau-portal.modules.v1）----

export type ModuleKey = 'ai' | 'context' | 'deadline' | 'cloud' | 'portal'

const MODULES_KEY = 'dsh.cau-portal.modules.v1'

export const DEFAULT_MODULES: Record<ModuleKey, boolean> = {
  ai: true,
  context: true,
  deadline: true,
  cloud: true,
  portal: true,
}

export function loadModules(): Record<ModuleKey, boolean> {
  try {
    const v = JSON.parse(localStorage.getItem(MODULES_KEY) || '{}')
    return { ...DEFAULT_MODULES, ...(v && typeof v === 'object' ? v : {}) }
  } catch {
    return { ...DEFAULT_MODULES }
  }
}

export function saveModules(m: Record<ModuleKey, boolean>) {
  try {
    localStorage.setItem(MODULES_KEY, JSON.stringify(m))
  } catch {
    /* 静默 */
  }
}

// ---- 栏目频道订阅（设置页「栏目频道管理」；键 dsh.cau-portal.channels.v1）----
// 语义 = **黑名单**：只有被显式关掉（false）的站点/栏目才隐藏，未记录的一律视为开启。
// 站点清单来自「站点目录」（见下：sites.json 配置 + index.json 数据），配置一推送就可见，
// 因此新接入的站点默认就是显示的，不需要用户手动打开，做到「添加即生效」。
// columns 目前未启用（本次只做站点级），但格式先留好，将来细化到栏目级不用改存储格式。

export type ChannelConfig = { version: number; sites: Record<string, boolean>; columns: Record<string, boolean> }

const CHANNELS_KEY = 'dsh.cau-portal.channels.v1'

export const DEFAULT_CHANNELS: ChannelConfig = { version: 1, sites: {}, columns: {} }

export function loadChannels(): ChannelConfig {
  try {
    const v = JSON.parse(localStorage.getItem(CHANNELS_KEY) || '{}')
    if (v && typeof v === 'object') {
      return {
        version: 1,
        sites: v.sites && typeof v.sites === 'object' ? v.sites : {},
        columns: v.columns && typeof v.columns === 'object' ? v.columns : {},
      }
    }
  } catch {
    /* 静默：损坏则回退全开 */
  }
  return { version: 1, sites: {}, columns: {} }
}

export function saveChannels(c: ChannelConfig) {
  try {
    localStorage.setItem(CHANNELS_KEY, JSON.stringify({ version: 1, sites: c?.sites || {}, columns: c?.columns || {} }))
  } catch {
    /* 静默 */
  }
}

/** 站点是否显示：只有显式 false 才隐藏 */
export function siteShown(c: ChannelConfig | null | undefined, siteId: string): boolean {
  if (!siteId) return true
  return c?.sites?.[siteId] !== false
}

/** 栏目是否显示：站点开关优先，再看栏目级（本次未开放栏目级 UI，预留） */
export function columnShown(c: ChannelConfig | null | undefined, siteId: string, columnKey: string): boolean {
  if (!siteShown(c, siteId)) return false
  if (!columnKey) return true
  return c?.columns?.[`${siteId}:${columnKey}`] !== false
}

/**
 * 从一个条目（summary.important / deadlines 的元素）推断它属于哪个站点 id。
 * **先按「站点目录」里的 baseUrl host 匹配** —— 这样「添加栏目」新接入的站点也认得出来
 * （否则新站点条目的 siteOfItem 恒为 ''，用户在「栏目频道管理」里把它关掉会关不掉）；
 * 再退回内置 host 表（目录缓存还没建立时兜底）。认不出来时返回 ''（调用方按「显示」处理）。
 */
export function siteOfItem(it: any): string {
  const url = String(it?.url || '')
  if (!url) return ''
  if (/tp_up|one\.cau\.edu\.cn/.test(url)) return 'portal'
  for (const s of loadSiteDirCache()) {
    const h = hostOf(s.baseUrl)
    if (h && url.includes(h)) return s.id
  }
  if (/clst\.cau\.edu\.cn/.test(url)) return 'clst'
  if (/jwc\.cau\.edu\.cn/.test(url)) return 'jwc'
  if (/news\.cau\.edu\.cn/.test(url)) return 'news'
  return ''
}

// ---- 站点目录（**配置驱动**）----
// 首页「栏目频道」、设置「栏目频道管理」、栏目页的站点清单**以仓库 `sites.json` 为权威**，
// `data/index.json` 只用来补条目数。原因（2026-09-13 用户指出）：index.json 由 Actions 抓完才算出来，
// 若清单取自它，新来源要等下一轮抓取（≤2h）才出现；而「添加」这个动作本身已经说明来源存在了。
// 因此配置一推送（sites.json），来源与它的栏目就应立刻可见（标「尚未抓取」），抓完再自动补上条目数。
// 目录会缓存到 localStorage，供 siteOfItem / 原文链接等**同步**场景使用（云端读取是异步的）。
// sites.json 读不到（如数据仓与代码仓分离）时退回纯 index.json，行为与旧版一致，不会变空白。

export type DirColumn = { key: string; name: string; items: number; latest_date: string | null; pending: boolean }
/**
 * 来源分组（2026-09-14 用户拍板）：校内平台（统一门户）/ 校内其他（农大各站）/ 校外来源（浙大、北大等）。
 * 分组写在 `sites.json` 的站点上（`group`），**缺省 = campus** —— 新接入的农大来源不用额外填；
 * 外校来源在接入时显式写 `"group": "external"`（「添加栏目」skill 里有这一步）。
 */
export type SiteGroup = 'portal' | 'campus' | 'external'
export type DirSite = { id: string; name: string; baseUrl: string; columns: DirColumn[]; items: number; pending: boolean; group?: SiteGroup }

export const GROUP_ORDER: SiteGroup[] = ['portal', 'campus', 'external']
export const GROUP_LABEL: Record<SiteGroup, string> = { portal: '校内平台', campus: '校内其他', external: '校外来源' }

const SITEDIR_KEY = 'dsh.cau-portal.sitedir.v1'

/** 站点目录缓存（同步可读；未建立时返回空数组） */
export function loadSiteDirCache(): DirSite[] {
  try {
    const v = JSON.parse(localStorage.getItem(SITEDIR_KEY) || '[]')
    return Array.isArray(v) ? (v as DirSite[]) : []
  } catch {
    return []
  }
}

function saveSiteDirCache(list: DirSite[]) {
  try {
    localStorage.setItem(SITEDIR_KEY, JSON.stringify(list))
  } catch {
    /* 静默 */
  }
}

function hostOf(baseUrl: string): string {
  try {
    return new URL(String(baseUrl)).hostname
  } catch {
    return ''
  }
}

/** 站点 id → baseUrl（用于把 feed 里的相对路径拼成原文链接；目录里查不到返回空） */
export function siteBaseUrl(siteId: string): string {
  return loadSiteDirCache().find((s) => s.id === siteId)?.baseUrl || ''
}

/** 站点 id → 分组；**本机覆盖优先**，其次 sites.json 的 group，最后按「校内其他」 */
export function siteGroupOf(siteId: string): SiteGroup {
  if (!siteId) return 'campus'
  const ov = loadSiteGroupOverrides()[siteId]
  if (ov) return ov
  if (siteId === 'portal') return 'portal'
  const g = loadSiteDirCache().find((s) => s.id === siteId)?.group
  return g === 'external' ? 'external' : g === 'portal' ? 'portal' : 'campus'
}

// ---- 来源分组：本机覆盖（设置 → 栏目频道管理；键 dsh.cau-portal.sitegroups.v1）----
// sites.json 里的 group 是「接入时定下的云端口径」；这里存**本机**的调整，优先级更高。
// 改完刷新即生效：不动数据仓、不需要写权限、也不影响别人（2026-09-14 用户拍板）。
const SITE_GROUPS_KEY = 'dsh.cau-portal.sitegroups.v1'

export function loadSiteGroupOverrides(): Record<string, SiteGroup> {
  try {
    const v = JSON.parse(localStorage.getItem(SITE_GROUPS_KEY) || '{}')
    if (!v || typeof v !== 'object') return {}
    const out: Record<string, SiteGroup> = {}
    for (const [k, g] of Object.entries(v as Record<string, unknown>)) {
      if (g === 'portal' || g === 'campus' || g === 'external') out[k] = g
    }
    return out
  } catch {
    return {}
  }
}

/** 设置某站点的分组；传 null 清除本机覆盖（回到 sites.json 的口径） */
export function saveSiteGroupOverride(siteId: string, g: SiteGroup | null) {
  try {
    const cur = loadSiteGroupOverrides()
    if (g) cur[siteId] = g
    else delete cur[siteId]
    localStorage.setItem(SITE_GROUPS_KEY, JSON.stringify(cur))
  } catch {
    /* 静默 */
  }
}

// ---- 来源主题色（本机；键 dsh.cau-portal.sitecolors.v1）----
// 只改「这个来源相关的颜色」：该来源页面里**原本是品牌绿**的部分（AI 摘要条、未读点、选中标签、
// 按钮…）换成它的颜色；**面板整体的品牌绿与白/灰等中性色不变**（2026-09-14 用户纠正过一次）。
const SITE_COLORS_KEY = 'dsh.cau-portal.sitecolors.v1'

/** 预设色板：收敛的中性色，浅色/深色下都看得清；value='' 表示「默认绿」（清除覆盖） */
export const SITE_COLOR_PRESETS: { key: string; name: string; value: string }[] = [
  { key: 'brand', name: '默认绿', value: '' },
  { key: 'indigo', name: '靛蓝', value: '#2f5fd0' },
  { key: 'teal', name: '青', value: '#0f7f7f' },
  { key: 'brick', name: '赭红', value: '#b0453a' },
  { key: 'violet', name: '紫', value: '#6d4fd0' },
  { key: 'slate', name: '石墨', value: '#4b5563' },
]

export function loadSiteColors(): Record<string, string> {
  try {
    const v = JSON.parse(localStorage.getItem(SITE_COLORS_KEY) || '{}')
    if (!v || typeof v !== 'object') return {}
    const out: Record<string, string> = {}
    for (const [k, c] of Object.entries(v as Record<string, unknown>)) {
      if (typeof c === 'string' && /^#[0-9a-f]{6}$/i.test(c)) out[k] = c
    }
    return out
  } catch {
    return {}
  }
}

/** 设置某来源的主题色；传 null/空 清除覆盖（回到面板品牌绿） */
export function saveSiteColor(siteId: string, color: string | null) {
  try {
    const cur = loadSiteColors()
    if (color && /^#[0-9a-f]{6}$/i.test(color)) cur[siteId] = color
    else delete cur[siteId]
    localStorage.setItem(SITE_COLORS_KEY, JSON.stringify(cur))
  } catch {
    /* 静默 */
  }
}

/** 某来源的主题色；未设置返回 ''（调用方按默认品牌绿处理） */
export function siteColorOf(siteId: string): string {
  return siteId ? loadSiteColors()[siteId] || '' : ''
}

// ---- 来源显示名：本机覆盖（设置 → 栏目频道管理「编辑」；键 dsh.cau-portal.sitenames.v1）----
// 只改**本机显示**的名字（首页栏目频道、栏目页标题、管理列表），不动数据仓、不影响别人。
const SITE_NAMES_KEY = 'dsh.cau-portal.sitenames.v1'

export function loadSiteNames(): Record<string, string> {
  try {
    const v = JSON.parse(localStorage.getItem(SITE_NAMES_KEY) || '{}')
    if (!v || typeof v !== 'object') return {}
    const out: Record<string, string> = {}
    for (const [k, n] of Object.entries(v as Record<string, unknown>)) {
      const s = String(n ?? '').trim()
      if (s) out[k] = s.slice(0, 40)
    }
    return out
  } catch {
    return {}
  }
}

/** 设置某来源的显示名；传 null/空 清除覆盖 */
export function saveSiteName(siteId: string, name: string | null) {
  try {
    const cur = loadSiteNames()
    const s = String(name ?? '').trim()
    if (s) cur[siteId] = s.slice(0, 40)
    else delete cur[siteId]
    localStorage.setItem(SITE_NAMES_KEY, JSON.stringify(cur))
  } catch {
    /* 静默 */
  }
}

/** 某来源的本机显示名；未设置返回 ''（调用方回退到目录/配置里的名字） */
export function siteNameOf(siteId: string): string {
  return siteId ? loadSiteNames()[siteId] || '' : ''
}

/** 条目 → 分组（门户条目按 URL 认；其余按站点目录的 group） */
export function groupOfItem(it: any): SiteGroup {
  const url = String(it?.url || '')
  if (/tp_up|one\.cau\.edu\.cn/.test(url)) return siteGroupOf('portal')
  const sid = siteOfItem(it)
  if (sid) return siteGroupOf(sid)
  // 认不出站点（目录缓存还没建立 / 跨站跳转的条目）：农大域名按本校算，其余按「校外来源」——
  // 宁可把认不出的归到校外，也不要让它们冒充本校通知挤进首页（2026-09-14 用户关注点）
  if (!url) return 'campus'
  return /(^|\.)cau\.edu\.cn/i.test(url) ? 'campus' : 'external'
}

function mergeDirSite(id: string, name: string, baseUrl: string, cfgColumns: any, data: any, group?: SiteGroup): DirSite {
  const dataCols: any[] = Array.isArray(data?.columns) ? data.columns : []
  const byKey = new Map<string, any>(dataCols.map((c: any) => [c.key, c]))
  const columns: DirColumn[] = []
  for (const c of Array.isArray(cfgColumns) ? cfgColumns : []) {
    if (!c?.key) continue
    const hit = byKey.get(c.key)
    columns.push({
      key: c.key,
      name: c.name || hit?.name || c.key,
      items: typeof hit?.items === 'number' ? hit.items : 0,
      latest_date: hit?.latest_date ?? null,
      pending: !hit,
    })
  }
  // 数据里有、配置里没有的栏目（门户等由后端注入）也补上
  for (const c of dataCols) {
    if (!c?.key || columns.some((x) => x.key === c.key)) continue
    columns.push({ key: c.key, name: c.name || c.key, items: c.items ?? 0, latest_date: c.latest_date ?? null, pending: false })
  }
  const items = columns.reduce((n, c) => n + (c.items || 0), 0)
  return { id, name: name || data?.name || id, baseUrl: baseUrl || '', columns, items, pending: items === 0, ...(group ? { group } : {}) }
}

/** 读云端站点目录（sites.json 配置 + index.json 数据合并）；成功后刷新本地缓存 */
export async function loadSiteDirectory(): Promise<DirSite[]> {
  const [cfg, idx] = await Promise.all([readCloudJson('sites.json'), readCloudJson('data/index.json')])
  const cfgSites: any[] = Array.isArray(cfg?.sites) ? cfg.sites : []
  const dataSites: any[] = Array.isArray(idx?.sites) ? idx.sites : []
  const byId = new Map<string, any>(dataSites.map((s: any) => [s.id, s]))
  const out: DirSite[] = []
  for (const s of cfgSites) {
    if (!s?.id) continue
    const g = s.group === 'external' ? 'external' : s.group === 'portal' ? 'portal' : s.group === 'campus' ? 'campus' : undefined
    out.push(mergeDirSite(s.id, s.name, s.baseUrl, s.columns, byId.get(s.id), g as SiteGroup | undefined))
  }
  const seen = new Set(out.map((s) => s.id))
  for (const d of dataSites) if (d?.id && !seen.has(d.id)) out.push(mergeDirSite(d.id, d.name, '', null, d))
  // 只有拿到配置（或本来没有缓存）时才覆盖缓存 —— 避免用「无 baseUrl 的退化目录」冲掉好数据
  if (out.length && (cfgSites.length || !loadSiteDirCache().length)) saveSiteDirCache(out)
  return out
}

// ---- 令牌登记（设置页令牌管理；键 dsh.cau-portal.tokens.v1，兼容旧 githubToken/keyExpiries）----

export type TokenRecord = {
  id: string
  name: string
  usage: string
  value: string
  expires: string
  adminUrl: string
  enabled: boolean
}

const TOKENS_KEY = 'dsh.cau-portal.tokens.v1'

export function loadTokens(): TokenRecord[] {
  try {
    const v = JSON.parse(localStorage.getItem(TOKENS_KEY) || 'null')
    if (Array.isArray(v)) return v.filter((x) => x && typeof x.id === 'string')
  } catch {
    /* fallthrough */
  }
  // 旧版迁移（展示层读取，不主动重写存储）
  const s = loadSettings()
  const legacy: TokenRecord[] = []
  if (s.githubToken)
    legacy.push({ id: 'github-read', name: 'GitHub 数据令牌', usage: '读取云端数据（面板/MCP）', value: s.githubToken, expires: s.keyExpiries?.github || '', adminUrl: 'https://github.com/settings/personal-access-tokens', enabled: true })
  if (s.keyExpiries?.bridge)
    legacy.push({ id: 'bridge', name: '调度桥令牌', usage: 'cron-job.org 触发 Actions（登记过期日，值不在本机）', value: '', expires: s.keyExpiries.bridge, adminUrl: 'https://github.com/settings/personal-access-tokens', enabled: true })
  if (s.keyExpiries?.push)
    legacy.push({ id: 'push', name: '推送令牌（临时）', usage: '本地推送脚本用（登记过期日，值不在本机）', value: '', expires: s.keyExpiries.push, adminUrl: 'https://github.com/settings/personal-access-tokens', enabled: true })
  return legacy
}

export function saveTokens(list: TokenRecord[]) {
  try {
    localStorage.setItem(TOKENS_KEY, JSON.stringify(list))
  } catch {
    /* 静默 */
  }
}

/** 启用的、有值的令牌值集合 */
export function activeTokenValues(): string[] {
  return loadTokens()
    .filter((t) => t.enabled && t.value)
    .map((t) => t.value)
}

// ---- 已读状态（localStorage；键 dsh.cau-portal.read.v1，存文章 id 数组）----

const READ_KEY = 'dsh.cau-portal.read.v1'

export function loadReadSet(): string[] {
  try {
    const v = JSON.parse(localStorage.getItem(READ_KEY) || '[]')
    return Array.isArray(v) ? v.filter((x) => typeof x === 'string') : []
  } catch {
    return []
  }
}

function saveReadSet(ids: string[]) {
  try {
    localStorage.setItem(READ_KEY, JSON.stringify(ids))
  } catch {
    /* 隐私模式等写入失败时静默 */
  }
}

/** 标记单条已读；返回最新已读集合 */
export function markRead(id: string): string[] {
  const cur = loadReadSet()
  if (!id || cur.includes(id)) return cur
  const next = [...cur, id]
  saveReadSet(next)
  return next
}

/** 批量标记已读；返回最新已读集合 */
export function markAllRead(ids: string[]): string[] {
  const cur = loadReadSet()
  const next = [...cur]
  for (const id of ids) if (id && !next.includes(id)) next.push(id)
  saveReadSet(next)
  return next
}

// ---- 关注列表（localStorage；键 dsh.cau-portal.follow.v1，无上限）----
// 存文章元数据快照，关注视图零请求即可渲染；点击可进原文（article_id 落在已存正文则读，否则开原文链接）

export type FollowItem = {
  id: string
  title: string
  url: string
  time?: string | null
  source?: string
  column?: string
  importance?: string
  summary?: string
}

const FOLLOW_KEY = 'dsh.cau-portal.follow.v1'

let _followTitlesRepaired = false

export function loadFollow(): FollowItem[] {
  // 一次性修复：早期「我的事项」同步进关注时把条目名当做了关注标题，这里用关注缓存里的新闻标题纠正
  if (!_followTitlesRepaired) {
    _followTitlesRepaired = true
    repairFollowTitles()
  }
  try {
    const v = JSON.parse(localStorage.getItem(FOLLOW_KEY) || '[]')
    return Array.isArray(v) ? v.filter((x) => x && typeof x.id === 'string') : []
  } catch {
    return []
  }
}

export function saveFollow(list: FollowItem[]) {
  try {
    localStorage.setItem(FOLLOW_KEY, JSON.stringify(list))
  } catch {
    /* 静默 */
  }
}

/**
 * 一次性修复关注条目标题：凡是关注缓存里能拿到新闻标题、且与当前存储标题不同的，
 * 说明是早期 bug（存成了事项名「报名」之类）→ 纠正为新闻标题。
 * 关注区始终应显示新闻标题，因此纠正总是安全；合法条目（标题本就=新闻标题）不变。
 */
function repairFollowTitles() {
  try {
    const v = JSON.parse(localStorage.getItem(FOLLOW_KEY) || '[]')
    if (!Array.isArray(v)) return
    let changed = false
    const next = v.map((it: FollowItem) => {
      if (!it || typeof it.id !== 'string' || !it.title) return it
      // 只用关注缓存（本机快照）里的新闻标题；无缓存则保持原样
      const cachedTitle = readFollowCache(it.id)?.title
      if (cachedTitle && cachedTitle !== it.title) {
        changed = true
        return { ...it, title: cachedTitle }
      }
      return it
    })
    if (changed) saveFollow(next)
  } catch {
    /* 静默 */
  }
}

/** 加入/取消关注；返回最新关注列表 */
export function toggleFollow(item: FollowItem): FollowItem[] {
  const cur = loadFollow()
  const idx = cur.findIndex((x) => x.id === item.id)
  let next: FollowItem[]
  if (idx >= 0) next = [...cur.slice(0, idx), ...cur.slice(idx + 1)]
  else next = [item, ...cur]
  saveFollow(next)
  return next
}

export function isFollowed(id: string): boolean {
  return loadFollow().some((x) => x.id === id)
}

// ---- 关注文章本地缓存（键 dsh.cau-portal.followcache.v1）----
// 云端数据只保留近 N 天（tools/scraper/prune.mjs 裁剪）；关注时把整篇快照存本机，
// 云端裁剪后关注文章仍可完整阅读（文章页显示「本地缓存」徽标），无需云同步。

export type FollowCacheEntry = { cached_at: number; article: any }

const FOLLOW_CACHE_KEY = 'dsh.cau-portal.followcache.v1'

export function loadFollowCacheAll(): Record<string, FollowCacheEntry> {
  try {
    const v = JSON.parse(localStorage.getItem(FOLLOW_CACHE_KEY) || '{}')
    return v && typeof v === 'object' ? v : {}
  } catch {
    return {}
  }
}

function saveFollowCacheAll(m: Record<string, FollowCacheEntry>) {
  try {
    localStorage.setItem(FOLLOW_CACHE_KEY, JSON.stringify(m))
  } catch {
    /* 静默（配额不足时丢弃缓存，不影响主体功能） */
  }
}

/** 关注时存整篇快照；传 null 则清除（取消关注时调用） */
export function cacheFollowArticle(id: string, article: any | null) {
  const m = loadFollowCacheAll()
  if (article) m[id] = { cached_at: Date.now(), article }
  else delete m[id]
  saveFollowCacheAll(m)
}

/** 读单篇关注缓存（无则 null） */
export function readFollowCache(id: string): any | null {
  return loadFollowCacheAll()[id]?.article ?? null
}

// ---- 待办留存/归档（localStorage；键 dsh.cau-portal.deadline.v1，article_id → 'pin'|'archive'|null）----
// 用户手动决定某条待办是「保留(驻留)」还是「归档」；不同人关注不同

/**
 * 剩余天数（以本地今天 0 点为基准，整天对齐）；非法/无法解析日期返回 NaN。
 * 全项目唯一实现：首页我的事项/今日要览与待办中心共用同一口径。
 */
export function daysLeft(date: string): number {
  if (!/^\d{4}-\d{1,2}-\d{1,2}/.test(String(date || ''))) return Number.NaN
  const d = Date.parse(date)
  if (!Number.isFinite(d)) return Number.NaN
  const day0 = new Date()
  day0.setHours(0, 0, 0, 0)
  return Math.round((d - day0.getTime()) / 86400000)
}

export type DeadlineOp = 'pin' | 'archive' | null

const DEADLINE_KEY = 'dsh.cau-portal.deadline.v1'

export function loadDeadlineOps(): Record<string, DeadlineOp> {
  try {
    const v = JSON.parse(localStorage.getItem(DEADLINE_KEY) || '{}')
    return v && typeof v === 'object' ? v : {}
  } catch {
    return {}
  }
}

function saveDeadlineOps(m: Record<string, DeadlineOp>) {
  try {
    localStorage.setItem(DEADLINE_KEY, JSON.stringify(m))
  } catch {
    /* 静默 */
  }
}

/** 设置某条待办操作（pin/archive/null=默认）；返回最新映射 */
export function setDeadlineOp(id: string, op: DeadlineOp): Record<string, DeadlineOp> {
  const m = loadDeadlineOps()
  if (op == null) delete m[id]
  else m[id] = op
  saveDeadlineOps(m)
  return m
}

// ---- 我的事项（人工精选待办；键 dsh.cau-portal.mine.v1）----
// 语义：用户从待办列表/文章页「⭐ 我的事项」加入；大卡展示、大号截止日期；
// 加入时自动同步进关注列表；支持自定义截止时间（仅显示层覆盖 AI 提取值）；
// 过期仍保留显示（灰+已过期）直至用户手动移除。

export type MineItem = {
  added_at: number
  /** 事项名（"要做什么"），如「推免生报名」；非文章标题 */
  title: string
  /** 关联原文链接（可为空；自定义事项可后补/无） */
  article_url?: string
  source?: string
  column?: string
  /** 原（AI 提取）截止日 YYYY-MM-DD */
  deadline?: string
  /** 自定义截止日（覆盖 deadline；仅本机显示层） */
  custom_deadline?: string
  /** 纯自定义事项（无关联文章） */
  custom?: boolean
  /** title 是否为事项名语义（true=用户给定/事项名；false/undefined=旧记录，显示时优先 AI 事项名） */
  task?: boolean
}

const MINE_KEY = 'dsh.cau-portal.mine.v1'

export function loadMine(): Record<string, MineItem> {
  try {
    const v = JSON.parse(localStorage.getItem(MINE_KEY) || '{}')
    return v && typeof v === 'object' ? v : {}
  } catch {
    return {}
  }
}

function saveMine(m: Record<string, MineItem>) {
  try {
    localStorage.setItem(MINE_KEY, JSON.stringify(m))
  } catch {
    /* 静默 */
  }
}

/** 从旧版 deadlineOps 的 pin 迁移（一次性） */
export function migrateMineFromPin() {
  const m = loadMine()
  const ops = loadDeadlineOps()
  let changed = false
  for (const [id, op] of Object.entries(ops)) {
    if (op === 'pin' && !m[id]) {
      m[id] = { added_at: Date.now(), title: '', url: '' }
      changed = true
    }
  }
  if (changed) saveMine(m)
}

export function isMine(id: string): boolean {
  return !!loadMine()[id]
}

/** 加入我的事项（title=事项名；同步进关注列表 + 异步补本地全文快照）。
 * 关注区显示「新闻标题」而非事项名：articleTitle 传入新闻标题，缺失时回退 item.title。 */
export async function addMine(id: string, item: { title: string; articleTitle?: string; url?: string; deadline?: string; source?: string; column?: string; custom?: boolean }): Promise<void> {
  migrateMineFromPin()
  const m = loadMine()
  if (!m[id]) {
    m[id] = { added_at: Date.now(), title: item.title, article_url: item.url || undefined, deadline: item.deadline, source: item.source, column: item.column, custom: item.custom || false, task: true }
    saveMine(m)
  }
  // 同步进关注列表（有关联文章时；无上限；重复自动去重）
  // 关注条目 title = 新闻标题（用户给定事项名只用于「我的事项」），保证关注区显示的是新闻名
  if (item.url) {
    const cur = loadFollow()
    if (!cur.some((x) => x.id === id)) {
      saveFollow([{ id, title: item.articleTitle || item.title, url: item.url, time: null, source: item.source, column: item.column, importance: undefined, summary: undefined }, ...cur])
    }
  }
  // 异步补本地全文快照（成功则缓存，失败静默）
  if (item.url && /^[0-9a-f]{40}$/.test(String(id))) {
    try {
      const art = await readArticle(id)
      if (art) cacheFollowArticle(id, art)
    } catch {
      /* 静默 */
    }
  }
}

/** 纯自定义事项（无关联文章也可；id 生成 custom-*） */
export function addCustomMine(item: { title: string; deadline?: string; url?: string }): string {
  migrateMineFromPin()
  const id = `custom-${Date.now().toString(36)}`
  const m = loadMine()
  m[id] = { added_at: Date.now(), title: item.title || '新事项', article_url: item.url || undefined, custom_deadline: item.deadline || undefined, custom: true, task: true }
  saveMine(m)
  return id
}

/** 更新我的事项（事项名/原文链接/自定义截止日） */
export function updateMine(id: string, patch: { title?: string; url?: string; deadline?: string }): void {
  const m = loadMine()
  if (!m[id]) return
  if (patch.title !== undefined) {
    m[id].title = patch.title
    m[id].task = true
  }
  if (patch.url !== undefined) m[id].article_url = patch.url || undefined
  if (patch.deadline !== undefined) m[id].custom_deadline = patch.deadline || undefined
  saveMine(m)
}

/** 移出我的事项（不影响关注列表，关注须在关注区另行取消） */
export function removeMine(id: string) {
  const m = loadMine()
  if (!m[id]) return
  delete m[id]
  saveMine(m)
}

/** 自定义截止日（空串=恢复 AI 提取值） */
export function setMineDeadline(id: string, date: string) {
  const m = loadMine()
  if (!m[id]) return
  m[id].custom_deadline = date || undefined
  saveMine(m)
}

/** 显示用截止日：custom 优先 */
export function mineDeadlineOf(m: MineItem): string | null {
  return m.custom_deadline || m.deadline || null
}

// ---- 便捷读取：文章 / 栏目 feed（相对 data/）----

/** 读取文章（含缓存兜底）：云端无（已过保留期/404）时回退本地关注缓存；失败返回 null */
export function readArticle(id: string, token?: string): Promise<any | null> {
  if (!id) return Promise.resolve(null)
  return readArticleMeta(id, token).then((r) => r?.article ?? null)
}

/** 读取文章并标记来源：{article, cached}（cached=true 表示来自本地关注缓存） */
export async function readArticleMeta(id: string, token?: string): Promise<{ article: any; cached: boolean } | null> {
  if (!id) return null
  try {
    const art = await readCloudJson(`data/articles/${id}.json`, token)
    if (art) return { article: art, cached: false }
  } catch {
    /* 网络/解析异常 → 走本地缓存兜底 */
  }
  const cached = readFollowCache(id)
  if (cached) return { article: cached, cached: true }
  return null
}

/** 读取某栏目 feed（data/feed/<site>__<column>.json） */
export function readFeed(site: string, column: string, token?: string): Promise<any | null> {
  if (!site || !column) return Promise.resolve(null)
  return readCloudJson(`data/feed/${site}__${column}.json`, token)
}

// ---- 按需加工 + 本机用量日志（localStorage；键 dsh.cau-portal.usage.v1）----
// 云端 usage.jsonl 记 enrich 管道用量（角色 enrich，读取见 settings.tsx）；
// 本机日志记面板按需加工（角色 on-demand），仅存本机、只留最近 500 条。

export type UsageRecord = {
  ts: string
  role: 'on-demand'
  provider: string
  model: string
  article: string
  prompt_tokens: number
  completion_tokens: number
  cached_tokens: number
}

const USAGE_KEY = 'dsh.cau-portal.usage.v1'

export function loadUsageLog(): UsageRecord[] {
  try {
    const v = JSON.parse(localStorage.getItem(USAGE_KEY) || '[]')
    return Array.isArray(v) ? v.filter((x) => x && typeof x.ts === 'string') : []
  } catch {
    return []
  }
}

function saveUsageLog(list: UsageRecord[]) {
  try {
    localStorage.setItem(USAGE_KEY, JSON.stringify(list.slice(-500)))
  } catch {
    /* 静默 */
  }
}

export function appendUsageLog(rec: UsageRecord) {
  saveUsageLog([...loadUsageLog(), rec])
}

/** 近 N 天用量按角色聚合（兼容两种字段名） */
export function summarizeUsage(rows: { ts: string; role: string; prompt_tokens?: number; completion_tokens?: number; cached_tokens?: number; cost_yuan?: number; inputTokens?: number; outputTokens?: number; cacheReadTokens?: number }[], days = 30) {
  const cutoff = Date.now() - days * 86400e3
  const agg: Record<string, { calls: number; prompt: number; completion: number; cached: number; cost: number }> = {}
  for (const r of rows) {
    const ts = Date.parse(String(r.ts || ''))
    if (!Number.isNaN(ts) && ts < cutoff) continue
    const role = String(r.role || 'other')
    const a = (agg[role] ||= { calls: 0, prompt: 0, completion: 0, cached: 0, cost: 0 })
    a.calls += 1
    a.prompt += r.prompt_tokens ?? r.inputTokens ?? 0
    a.completion += r.completion_tokens ?? r.outputTokens ?? 0
    a.cached += r.cached_tokens ?? r.cacheReadTokens ?? 0
    a.cost += typeof r.cost_yuan === 'number' ? r.cost_yuan : 0
  }
  return agg
}

// ---- 设置页：用量按日聚合 + 全局提醒 ----

export type UsageRow = {
  ts: string
  role: string
  prompt?: number
  completion?: number
  cached?: number
  cost?: number
  inputTokens?: number
  outputTokens?: number
  cacheReadTokens?: number
  /** 云端 usage.jsonl 原始字段（下划线命名） */
  prompt_tokens?: number
  completion_tokens?: number
  cached_tokens?: number
  cost_yuan?: number
}

/** 合并云端 usage.jsonl（角色 enrich）与本机按需日志（on-demand） */
export async function loadUsageRows(): Promise<UsageRow[]> {
  const rows: UsageRow[] = []
  try {
    const text = await readCloudText('data/usage.jsonl')
    for (const line of String(text).split('\n')) {
      if (!line.trim()) continue
      try {
        const o = JSON.parse(line)
        rows.push({ ...o, role: o.role || 'enrich' })
      } catch {
        /* 跳过坏行 */
      }
    }
  } catch {
    /* 云端可能不存在 */
  }
  for (const r of loadUsageLog()) rows.push(r)
  return rows
}

const localDay = (v: string | number | Date) => new Date(v).toLocaleDateString('en-CA')

/** 近 N 天按日聚合（补齐无数据天；metric: calls|prompt|completion|cost） */
export function buildDailyUsage(rows: UsageRow[], days: number, metric: 'calls' | 'prompt' | 'completion' | 'cost'): { label: string; value: number }[] {
  const map: Record<string, { label: string; calls: number; prompt: number; completion: number; cost: number }> = {}
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(Date.now() - i * 86400e3)
    map[localDay(d)] = { label: d.toISOString().slice(5, 10), calls: 0, prompt: 0, completion: 0, cost: 0 }
  }
  for (const r of rows) {
    const k = r.ts ? localDay(r.ts) : ''
    const slot = map[k]
    if (!slot) continue
    slot.calls += 1
    slot.prompt += r.prompt ?? r.prompt_tokens ?? r.inputTokens ?? 0
    slot.completion += r.completion ?? r.completion_tokens ?? r.outputTokens ?? 0
    slot.cost += Number(r.cost ?? r.cost_yuan ?? 0)
  }
  return Object.values(map).map((v) => ({ label: v.label, value: v[metric] }))
}

/** 全局配置提醒：error=基本需求不满足（红条）；warn=注意项（黄条） */
export function computeAlerts(): { level: 'error' | 'warn'; text: string; page?: string }[] {
  const out: { level: 'error' | 'warn'; text: string; page?: string }[] = []
  const mods = loadModules()
  const tokens = loadTokens()
  const hasActiveValue = tokens.some((t) => t.enabled && t.value)
  if (!hasActiveValue) out.push({ level: 'error', text: '未配置有效令牌：面板无法读取云端数据（设置 → 令牌管理）', page: 'tokens' })
  // 数据仓未配置（2026-09-30 #1：内置默认仓已删除）→ 红条 + 一键去「数据源」子页
  if (!dataRepo()) out.push({ level: 'error', text: '请先配置数据仓库（设置 → 数据源）', page: 'cloud' })
  if (!mods.cloud) out.push({ level: 'error', text: '数据源已禁用：插件将无法读取云端数据', page: 'cloud' })
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  for (const t of tokens) {
    if (!t.enabled) continue // 停用的令牌不参与到期提醒
    if (!t.expires) continue
    const d = Date.parse(t.expires)
    if (!Number.isFinite(d)) continue
    const left = Math.floor((d - Date.now()) / 86400e3)
    if (left < 0) out.push({ level: 'error', text: `令牌「${t.name}」已过期（${t.expires}），请前往续期`, page: 'tokens' })
    else if (left <= 30) out.push({ level: 'warn', text: `令牌「${t.name}」将于 ${left} 天后过期（${t.expires}）`, page: 'tokens' })
  }
  if (!mods.ai) out.push({ level: 'warn', text: 'AI 摘要已禁用：文章页不显示摘要与补摘要', page: 'ai' })
  if (!mods.context) out.push({ level: 'warn', text: '引用协同已禁用：引用按钮与上下文条已隐藏', page: 'prefs' })
  if (!mods.deadline) out.push({ level: 'warn', text: '待办与关注已禁用：首页不显示待办卡/关注入口', page: 'follow' })
  // 系统通知：开启但未授权/被拒 → 提醒授权路径（避免"开了不响"的错觉）
  const s = loadSettings()
  if (s.notifyOn) {
    const perm = typeof Notification !== 'undefined' ? Notification.permission : 'unsupported'
    if (perm === 'default') out.push({ level: 'warn', text: '系统通知已开启但尚未授权：设置 → 待办提醒 · 关注 → 点「请求通知授权」', page: 'follow' })
    else if (perm === 'denied') out.push({ level: 'warn', text: '系统通知已开启但被浏览器拒绝：请在浏览器站点设置中允许通知', page: 'follow' })
    else if (perm === 'unsupported') out.push({ level: 'warn', text: '系统通知已开启，但当前浏览器不支持通知 API', page: 'follow' })
  }
  // 过期日登记（settings.keyExpiries 独立键）：不被令牌列表覆盖的键提醒（如 github-read/bridge）
  const keyExp = s.keyExpiries || {}
  const tokenDates = new Set(tokens.map((t) => t.expires).filter(Boolean))
  for (const [k, exp] of Object.entries(keyExp)) {
    if (!exp || tokenDates.has(exp)) continue
    const d = Date.parse(exp)
    if (!Number.isFinite(d)) continue
    const left = Math.floor((d - Date.now()) / 86400e3)
    if (left < 0) out.push({ level: 'error', text: `凭据「${k}」已过期（${exp}），请前往 GitHub 续期`, page: 'tokens' })
    else if (left <= 30) out.push({ level: 'warn', text: `凭据「${k}」将于 ${left} 天后过期（${exp}）`, page: 'tokens' })
  }
  return out
}

/**
 * 调用服务端 /api/cau/enrich 按需加工（浏览器不存 API key）；
 * 成功时记一条本机用量日志；返回 {ok, result, tokens, ...} 或 {ok:false, error}。
 */
export async function enrichArticle(id: string, opts?: { provider?: string; model?: string }): Promise<any> {
  const art = await readArticle(id)
  if (!art) return { ok: false, error: '文章读取失败（正文未入库）' }
  const body = typeof art.body === 'string' ? art.body : ''
  if (!body) return { ok: false, error: '文章正文为空，无法加工' }
  let data: any = null
  try {
    const res = await fetch('/api/cau/enrich', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: art.title,
        content: body.slice(0, 6000),
        time: art.time || art.published || '',
        source: art.source || art.site_name || '',
        provider: opts?.provider,
        model: opts?.model,
      }),
    })
    data = await res.json()
  } catch (error: any) {
    return { ok: false, error: String(error?.message || error) }
  }
  if (data?.ok && data.tokens) {
    appendUsageLog({
      ts: new Date().toISOString(),
      role: 'on-demand',
      provider: data.provider || opts?.provider || '',
      model: data.model || opts?.model || '',
      article: id,
      prompt_tokens: data.tokens.promptTokens ?? data.tokens.inputTokens ?? 0,
      completion_tokens: data.tokens.completionTokens ?? data.tokens.outputTokens ?? 0,
      cached_tokens: data.tokens.cacheReadTokens ?? 0,
    })
  }
  return data
}

// ---- 关注规则（关键词/来源订阅；键 dsh.cau-portal.rules.v1）----
export type WatchRule = {
  id: string
  /** 关键词（匹配标题/来源/栏目，忽略大小写） */
  keyword: string
  /** 来源/部门包含（可空=不限） */
  source?: string
  /** 重要度下限：'高'=只要高；'中'=高或中；可空=不限 */
  minImportance?: '高' | '中'
  enabled: boolean
}
const RULES_KEY = 'dsh.cau-portal.rules.v1'
export function loadRules(): WatchRule[] {
  try {
    const v = JSON.parse(localStorage.getItem(RULES_KEY) || '[]')
    return Array.isArray(v) ? v.filter((r) => r && r.id && r.keyword) : []
  } catch { return [] }
}
export function saveRules(list: WatchRule[]) {
  try { localStorage.setItem(RULES_KEY, JSON.stringify(list.slice(0, 60))) } catch { /* 静默 */ }
}
export function newRuleId() { return 'r-' + Math.random().toString(36).slice(2, 9) }

/** 规则命中：keyword（标题/来源/站点名/栏目名/栏目key 任一含，忽略大小写）+ source 含（来源/站点名）+ 重要度下限。
 *  字段口径与 tools/email/report.mjs 的 matchRule 对齐：面板🎯 与邮件日报🎯 命中一致。 */
export function matchRules(
  rules: WatchRule[],
  item: { title?: string; source?: string; site_name?: string; column?: string; column_name?: string; importance?: string },
): WatchRule[] {
  if (!rules || !rules.length) return []
  const hay = `${item.title || ''} ${item.source || ''} ${item.site_name || ''} ${item.column_name || ''} ${item.column || ''}`.toLowerCase()
  const srcHay = `${item.source || ''} ${item.site_name || ''}`.toLowerCase()
  return rules.filter((r) => {
    if (!r.enabled || !r.keyword) return false
    if (!hay.includes(r.keyword.toLowerCase())) return false
    if (r.source && !srcHay.includes(r.source.toLowerCase())) return false
    if (r.minImportance === '高' && item.importance !== '高') return false
    if (r.minImportance === '中' && item.importance !== '高' && item.importance !== '中') return false
    return true
  })
}

// ---- 面板内搜索（2026-09-22 用户要「待办里加搜索」）----
/**
 * 匹配规则：空格分隔多关键词、**全部命中**才算（与 MCP `search_news` 同口径），大小写不敏感。
 * 放在 data.ts 而不是新开模块：`panel-deadlines.tsx` 与 `panel-news.tsx` 都已 import 这里，
 * 而 build.mjs 的内联器**不做模块去重**（新模块会被两个页面各复制一份，白涨 bundle）。
 */
export function matchQuery(text: string, query: string): boolean {
  const q = String(query || '').trim().toLowerCase()
  if (!q) return true
  const hay = String(text || '').toLowerCase()
  return q.split(/\s+/).every((k) => hay.includes(k))
}

// ---- 通知去重水位（键 dsh.cau-portal.notifyseen.v1：已通知过的条目 id）----
const NOTIFY_SEEN_KEY = 'dsh.cau-portal.notifyseen.v1'
export function loadNotifySeen(): Set<string> {
  try { return new Set(JSON.parse(localStorage.getItem(NOTIFY_SEEN_KEY) || '[]')) } catch { return new Set() }
}
export function saveNotifySeen(ids: Set<string>) {
  try { localStorage.setItem(NOTIFY_SEEN_KEY, JSON.stringify([...ids].slice(-400))) } catch { /* 静默 */ }
}

/**
 * 计算本次应通知的条目（供系统通知轮询）：
 * - importance 高 且 3 天内发布，或命中关注规则（同样 3 天内发布）
 * - id 不在 seen（已通知过的不重复）
 */
export function computeNewAlerts(summary: any, rules: WatchRule[], seen: Set<string>): any[] {
  const items: any[] = summary?.important || []
  const out: any[] = []
  const limit = Date.now() - 72 * 3600 * 1000
  for (const it of items) {
    const id = it.article_id || it.url
    if (!id || seen.has(id)) continue
    const t = Date.parse(String(it.time || ''))
    if (!Number.isFinite(t) || t < limit) continue
    const ruleHit = matchRules(rules, it).length > 0
    if (it.importance !== '高' && !ruleHit) continue
    out.push({ ...it, id, rule_hit: ruleHit })
    if (out.length >= 5) break
  }
  return out
}
