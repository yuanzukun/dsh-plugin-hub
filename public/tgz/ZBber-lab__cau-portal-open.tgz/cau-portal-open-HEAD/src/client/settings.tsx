/**
 * cau-portal 设置页（2026-09-01 结构重设计：方案C 分组卡片墙 + 语义统一）：
 * 首页 = 3 组分组卡片（智能与数据 / 通知与关注 / 面板行为）＋ 顶部提醒条（红=基本需求不满足 / 黄=注意）。
 *   开关语义统一：功能卡（AI/数据源/待办/引用协同/邮件）首页即有总开关；凭据卡（令牌/门户账号，淡底）无开关只显状态。
 * 子页（卡片↔子页严格 1:1；页头下内联本模块相关提醒，另有其他模块问题时显示可点击计数 chip 回首页）：
 *   ① AI 加工·模型配置（模型选择 + 用量柱状图 7/30/90 天 + 指标切换 + 分账表 + 按需补摘要说明）
 *   ② 令牌管理（多令牌登记：值/过期日/剩余天数/快捷跳转 GitHub 管理页/逐枚开关）
 *   ③ 面板偏好·引用协同（自动附加 + 引用协同开关 + 面板固定）  ④ 待办提醒·关注（模块开关 + 关注规则 + 系统通知）
 *   ⑤ 数据源（GitHub 云端 + 统一门户开关 + 连通检查）  ⑥ 每日邮件报告  ⑦ 门户账号（开源版不可用 + 重要链接）
 * 全部纯客户端（localStorage），浏览器刷新生效。
 */
import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react'
import {
  loadSettings,
  saveSettings,
  fetchServerDataRepo,
  readCloudText,
  loadModules,
  saveModules,
  loadChannels,
  saveChannels,
  siteShown,
  loadSiteDirectory,
  siteGroupOf,
  saveSiteGroupOverride,
  siteColorOf,
  saveSiteColor,
  siteNameOf,
  saveSiteName,
  SITE_COLOR_PRESETS,
  GROUP_ORDER,
  GROUP_LABEL,
  type SiteGroup,
  loadTokens,
  saveTokens,
  loadUsageRows,
  buildDailyUsage,
  summarizeUsage,
  computeAlerts,
  loadRules,
  saveRules,
  newRuleId,
  type WatchRule,
  type TokenRecord,
  type ModuleKey,
  type ChannelConfig,
  type DirSite,
} from './data'
import { getCtx } from './ctx'
import { Ic } from './icons'
import { requestDraft, getDraftAck, subscribeBus } from './bus'

const noop = () => {}

export const SETTINGS_CSS = `
.dsh-cau_set{display:flex;flex-direction:column;gap:14px;padding:16px 0 24px;max-width:640px;width:100%;min-width:0;overflow-x:hidden}
/* ---- 提醒条 ---- */
.dsh-cau_alert{display:flex;align-items:flex-start;gap:8px;padding:9px 12px;border-radius:10px;font-size:12px;line-height:17px}
.dsh-cau_alert.error{border:1px solid color-mix(in srgb,var(--cau-err) 45%,transparent);background:color-mix(in srgb,var(--cau-err) 10%,transparent);color:var(--cau-err)}
.dsh-cau_alert.warn{border:1px solid color-mix(in srgb,var(--cau-warn) 45%,transparent);background:color-mix(in srgb,var(--cau-warn) 10%,transparent);color:var(--cau-warn)}
.dsh-cau_alertDot{flex:none;width:8px;height:8px;margin-top:4px;border-radius:50%;background:currentColor}
/* ---- 分组 ---- */
.dsh-cau_setGroup{display:flex;flex-direction:column;gap:10px}
.dsh-cau_setGroupTitle{display:flex;align-items:center;gap:8px;padding:2px 2px 0;font-size:11px;font-weight:600;letter-spacing:.07em;color:var(--cau-ink3)}
.dsh-cau_setGroupTitle::after{content:"";flex:1;height:1px;background:var(--cau-line-soft)}
/* ---- 分组卡片 ---- */
.dsh-cau_cards{display:flex;flex-direction:column;gap:10px}
.dsh-cau_setCard{display:flex;align-items:center;gap:10px;padding:12px 14px;border:1px solid var(--cau-line-soft);border-radius:var(--cau-r-m);background:color-mix(in srgb,var(--dsw-specific-menu,#fff) 26%,transparent);box-shadow:0 1px 2px rgba(10,15,22,.03);cursor:pointer;transition:border-color .12s ease}
.dsh-cau_setCard:hover{border-color:var(--cau-brand-a55)}
.dsh-cau_setCardAlt{background:var(--cau-fill)}
.dsh-cau_cardMain{flex:1;min-width:0;display:flex;flex-direction:column;gap:4px}
.dsh-cau_cardName{display:flex;align-items:center;gap:7px;font-size:13px;font-weight:600;color:var(--cau-ink)}
.dsh-cau_cardIcon{flex:none;display:flex;color:var(--cau-brand)}
.dsh-cau_cardIcon svg{width:15px;height:15px}
.dsh-cau_cardDesc{font-size:11px;line-height:16px;color:var(--cau-ink3)}
.dsh-cau_cardBadge{flex:none;font-size:11px;padding:2px 7px;border-radius:999px;white-space:nowrap}
.dsh-cau_cardBadge.ok{background:color-mix(in srgb,var(--cau-ok) 14%,transparent);color:var(--cau-ok)}
.dsh-cau_cardBadge.warn{background:color-mix(in srgb,var(--cau-warn) 14%,transparent);color:var(--cau-warn)}
.dsh-cau_cardBadge.off{background:var(--cau-fill);color:var(--cau-ink3)}
.dsh-cau_cardBadge.err{background:color-mix(in srgb,var(--cau-err) 14%,transparent);color:var(--cau-err)}
/* ---- 开关 ---- */
.dsh-cau_switch{flex:none;position:relative;width:34px;height:20px;border:1px solid var(--cau-line);border-radius:999px;background:var(--cau-fill);cursor:pointer;transition:background .15s ease,border-color .15s ease}
.dsh-cau_switch span{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;background:var(--cau-ink3);transition:transform .15s ease,background .15s ease}
.dsh-cau_switch.on{border-color:var(--cau-brand-a55);background:var(--cau-brand-a22)}
.dsh-cau_switch.on span{transform:translateX(14px);background:var(--cau-brand)}
/* ---- 子页 ---- */
.dsh-cau_setPageHead{display:flex;align-items:center;gap:8px;margin-bottom:2px}
.dsh-cau_setSubBack{flex:none;display:inline-flex;align-items:center;gap:3px;height:28px;padding:0 11px;border:1px solid var(--cau-line);border-radius:999px;background:transparent;color:var(--cau-brand);font-size:12px;cursor:pointer}
.dsh-cau_setSubBack:hover{background:var(--cau-brand-a9)}
.dsh-cau_setSubBack svg{width:12px;height:12px}
.dsh-cau_setBlocks{display:flex;flex-direction:column;gap:14px}
.dsh-cau_setBlock{display:flex;flex-direction:column;gap:8px}
.dsh-cau_setTitle{display:flex;align-items:center;gap:7px;font-size:13px;font-weight:600;color:var(--cau-ink)}
.dsh-cau_setTitle::before{content:"";flex:none;width:2px;height:12px;border-radius:2px;background:var(--cau-brand)}
.dsh-cau_setTitle svg{width:13px;height:13px;color:var(--cau-brand)}
.dsh-cau_setDesc{font-size:12px;line-height:17px;color:var(--cau-ink3)}
.dsh-cau_setRow{display:flex;align-items:center;gap:10px;flex-wrap:wrap;min-width:0}
.dsh-cau_mineLabel{display:flex;flex-direction:column;gap:4px;margin:0}
.dsh-cau_mineLabel span{font-size:11px;line-height:16px;color:var(--cau-ink3)}
.dsh-cau_mineLabel .dsh-cau_setSelect{width:100%;flex:none}
.dsh-cau_setLabel{flex:1;min-width:0;font-size:13px;color:var(--cau-ink2)}
.dsh-cau_setInput{box-sizing:border-box;width:100%;height:32px;padding:0 10px;border:1px solid var(--cau-line);border-radius:var(--cau-r-s);background:transparent;color:var(--cau-ink);font-size:12px;outline:none}
.dsh-cau_setInput:focus{border-color:var(--cau-brand)}
.dsh-cau_setSelect{box-sizing:border-box;min-width:0;flex:1;height:32px;padding:0 8px;border:1px solid var(--cau-line);border-radius:var(--cau-r-s);background:var(--dsw-specific-menu,#1b1e24);color:var(--cau-ink);font-size:12px;outline:none;cursor:pointer}
.dsh-cau_setBtn{flex:none;display:inline-flex;align-items:center;gap:5px;height:32px;padding:0 14px;border:1px solid var(--cau-line);border-radius:10px;background:transparent;color:var(--cau-ink);font-size:12px;cursor:pointer}
.dsh-cau_setBtn:hover{border-color:var(--cau-brand-a35);color:var(--cau-brand);background:var(--cau-brand-a6)}
.dsh-cau_setBtn svg{width:12px;height:12px}
.dsh-cau_setBtn:disabled{opacity:.45;cursor:default}
.dsh-cau_setBtn.danger{border-color:color-mix(in srgb,var(--cau-err) 45%,transparent);color:var(--cau-err)}
.dsh-cau_setBtn.danger:hover{background:color-mix(in srgb,var(--cau-err) 8%,transparent)}
.dsh-cau_setHint{font-size:11px;line-height:16px;color:var(--cau-ink3)}
.dsh-cau_setOk{font-size:12px;color:var(--cau-ok)}
.dsh-cau_setErr{font-size:12px;color:var(--cau-err)}
.dsh-cau_setWarn{font-size:12px;line-height:17px;color:var(--cau-warn)}
.dsh-cau_setOther{display:inline-flex;align-items:center;gap:4px;height:24px;padding:0 10px;border:1px solid color-mix(in srgb,var(--cau-warn) 40%,transparent);border-radius:999px;background:color-mix(in srgb,var(--cau-warn) 8%,transparent);color:var(--cau-warn);font-size:11px;cursor:pointer}
.dsh-cau_setOther:hover{background:color-mix(in srgb,var(--cau-warn) 14%,transparent)}
.dsh-cau_setCheck{display:flex;align-items:center;gap:8px;font-size:13px;color:var(--cau-ink2);cursor:pointer}
.dsh-cau_setCheck input{accent-color:var(--cau-brand)}
.dsh-cau_infoCard{display:flex;flex-direction:column;gap:6px;padding:10px 12px;border:1px solid var(--cau-line-soft);border-radius:10px;background:var(--cau-fill)}
/* ---- 用量图 ---- */
.dsh-cau_chart{display:block;width:100%;height:150px;color:var(--cau-ink2)}
.dsh-cau_setChip{height:24px;padding:0 11px;border:1px solid var(--cau-line);border-radius:999px;background:transparent;color:var(--cau-ink2);font-size:11px;cursor:pointer}
.dsh-cau_setChip.on{background:var(--cau-brand-a12);border-color:var(--cau-brand);color:var(--cau-brand)}
.dsh-cau_usageTable{width:100%;border-collapse:collapse;font-size:12px;color:var(--cau-ink2)}
.dsh-cau_usageTable th,.dsh-cau_usageTable td{padding:6px 8px;border-bottom:1px solid var(--cau-line-soft);text-align:right;white-space:nowrap}
.dsh-cau_usageTable th:first-child,.dsh-cau_usageTable td:first-child{text-align:left}
.dsh-cau_usageTable th{color:var(--cau-ink3);font-weight:500}
/* ---- 令牌 ---- */
.dsh-cau_tokList{display:flex;flex-direction:column;gap:8px}
.dsh-cau_tok{display:flex;align-items:center;gap:10px;padding:10px 12px;border:1px solid var(--cau-line-soft);border-radius:var(--cau-r-m)}
.dsh-cau_tokMain{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}
.dsh-cau_tokName{display:flex;align-items:center;gap:6px;font-size:13px;font-weight:600;color:var(--cau-ink)}
.dsh-cau_tokMeta{display:flex;flex-wrap:wrap;gap:8px;font-size:11px;color:var(--cau-ink3)}
.dsh-cau_tokActs{display:flex;gap:6px;flex:none}
.dsh-cau_tokBtn{flex:none;display:inline-flex;align-items:center;gap:3px;height:26px;padding:0 9px;border:1px solid var(--cau-line);border-radius:var(--cau-r-s);background:transparent;color:var(--cau-ink2);font-size:11px;cursor:pointer;text-decoration:none}
.dsh-cau_tokBtn:hover{border-color:var(--cau-brand-a35);color:var(--cau-brand);background:var(--cau-brand-a6)}
.dsh-cau_tokBtn svg{width:11px;height:11px}
.dsh-cau_tokBtn.danger{color:var(--cau-err);border-color:color-mix(in srgb,var(--cau-err) 40%,transparent)}
.dsh-cau_tokBtn.danger:hover{background:color-mix(in srgb,var(--cau-err) 8%,transparent)}
.dsh-cau_links{display:flex;flex-wrap:wrap;gap:8px;margin-top:4px}
.dsh-cau_link{display:inline-flex;align-items:center;gap:4px;padding:5px 10px;border:1px solid var(--cau-line);border-radius:var(--cau-r-s);background:transparent;color:var(--cau-ink2);font-size:11px;text-decoration:none;cursor:pointer}
.dsh-cau_link:hover{border-color:var(--cau-brand-a35);color:var(--cau-brand);background:var(--cau-brand-a6)}
.dsh-cau_link svg{width:11px;height:11px}
`

const ROLE_LABEL: Record<string, string> = {
  enrich: '爬虫管道加工',
  'on-demand': '面板按需加工',
  monitor: '监控',
  other: '其他',
}

function fmtNum(n: number): string {
  if (n >= 1e6) return (n / 1e6).toFixed(2) + 'M'
  if (n >= 1e4) return (n / 1e4).toFixed(1) + 'w'
  return String(n)
}

function daysUntil(dateStr: string | undefined): number | null {
  if (!dateStr) return null
  const d = new Date(dateStr)
  if (Number.isNaN(d.getTime())) return null
  return Math.ceil((d.getTime() - Date.now()) / 86400e3)
}

function expiryBadge(expires: string): { cls: string; text: string } {
  const n = daysUntil(expires)
  if (n == null) return { cls: 'dsh-cau_setHint', text: '未设过期日' }
  if (n < 0) return { cls: 'dsh-cau_setErr', text: `已过期 ${-n} 天` }
  if (n <= 30) return { cls: 'dsh-cau_setWarn', text: `${n} 天后过期` }
  return { cls: 'dsh-cau_setOk', text: `${n} 天后过期` }
}

/**
 * 「添加栏目」：把用户填的名称/网址编成一段请求，交给主对话（智能体）去探测并接入。
 * 只填聊天输入框、不自动发送 —— 用户是最终确认人（设计点②，2026-09-13 拍板）。
 * 前缀标记 `〔cau:add-column〕` 供 cau-portal-add-column skill 识别意图。
 * 2026-09-14 按实测教训补强：必须用 probe.mjs（肉眼判 CMS 误报过两次）、逐栏目报表、
 * 先修解析器缺陷再写配置、不要动 data/、推送先私有后公有、接入后要在 Actions 环境复验。
 */
function buildAddPrompt(name: string, url: string): string {
  const u = /^https?:\/\//i.test(url) ? url : `https://${url}`
  return [
    '〔cau:add-column〕给「农大门户」插件接入一个新来源：',
    `· 名称：${name || '（未填，请按站点标题推断）'}`,
    `· 网址：${u}`,
    '',
    `请先跑 \`node tools/scraper/probe.mjs ${u}\` 探测（不要只靠肉眼读网页判断 CMS），然后**只报告、先别改任何文件**：`,
    '1. CMS 类型与判断依据（博达 boda / 苏迪 sudy / 校新闻网 / 自研 / 需登录）',
    '2. 逐栏目一张表：栏目名 + id 或 path + 列表条目数 + 页数 + 最新一篇日期 + 正文抽样字数 + 是否受限（限校内 IP / 需登录）或已停更',
    '3. 哪些栏目**不建议接**及原因（停更 / 静态页 / 图集 / 多个栏目指向同一列表）',
    '4. 结论三选一：能直接接 / 需要写解析器（说明工作量）/ 接不了（说明原因）',
    '',
    '三条硬要求：',
    '· 若探测中发现解析器缺陷（例如条目里混进了站点导航链接），先报告并单独修，**不要带着 bug 写配置**',
    '· 等我确认后再写进 sites.json；**非本校来源要标 `"group": "external"`**（面板会归到「校外来源」，不挤占本校通知）；**不要动 data/**；推送顺序永远是**先私有仓 ZBber-lab/cau-portal → 再公有仓 cau-portal-open**',
    '· 接入后要验证「在 GitHub Actions 环境里也抓得到」—— 本机成功 ≠ 线上成功（跨网失败会写空 feed）',
  ].join('\n')
}

const KEY_LINKS: { key: string; label: string; url: string }[] = [
  { key: 'github-read', label: 'GitHub 令牌管理', url: 'https://github.com/settings/personal-access-tokens' },
  { key: 'repo', label: '数据仓库', url: 'https://github.com/ZBber-lab/cau-portal' },
  { key: 'actions', label: '定时抓取 Actions', url: 'https://github.com/ZBber-lab/cau-portal/actions' },
  { key: 'cron', label: 'cron-job.org', url: 'https://console.cron-job.org/jobs' },
  { key: 'ds', label: 'DeepSeek 平台', url: 'https://platform.deepseek.com' },
  { key: 'portal', label: '统一门户', url: 'https://one.cau.edu.cn' },
]

/** 自绘 SVG 柱状图（无图表库依赖） */
function BarChart({ items, unit }: { items: { label: string; value: number }[]; unit: string }) {
  const W = 460
  const H = 150
  const PAD = 8
  const BASE = 24
  const TOP = 24
  const max = Math.max(1, ...items.map((i) => i.value))
  const n = items.length
  const step = Math.max(1, Math.ceil(n / 10))
  const slot = (W - PAD * 2) / n
  const bw = Math.max(2, slot - 3)
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="dsh-cau_chart" role="img" aria-label="用量柱状图">
      <line x1={PAD} y1={H - BASE} x2={W - PAD} y2={H - BASE} stroke="currentColor" opacity=".25" />
      <text x={PAD} y={14} fontSize="10" fill="currentColor" opacity=".6">
        max {fmtNum(max)} {unit}
      </text>
      {items.map((it, i) => {
        const h = Math.max(1.5, (it.value / max) * (H - BASE - TOP - 10))
        const x = PAD + i * slot + (slot - bw) / 2
        const on = it.value > 0
        return (
          <g key={i}>
            <rect x={x} y={H - BASE - h} width={bw} height={h} rx={2} fill={on ? 'var(--cau-brand)' : 'currentColor'} opacity={on ? 1 : 0.12}>
              <title>{`${it.label}：${fmtNum(it.value)} ${unit}`}</title>
            </rect>
            {i % step === 0 && (
              <text x={x + bw / 2} y={H - 8} fontSize="9" fill="currentColor" opacity=".55" textAnchor="middle">
                {it.label}
              </text>
            )}
          </g>
        )
      })}
    </svg>
  )
}

function Toggle({ on, onToggle, label }: { on: boolean; onToggle: () => void; label: string }) {
  return (
    <button type="button" className={'dsh-cau_switch' + (on ? ' on' : '')} aria-pressed={on} aria-label={label} title={on ? '点击禁用' : '点击启用'} onClick={(e) => { e.stopPropagation(); onToggle() }}>
      <span />
    </button>
  )
}

export function CauSettings(props: any) {
  const _ctx = getCtx() || {}
  const sessions = props.sessions ?? _ctx.sessions
  const modelDirectories = props.modelDirectories ?? _ctx.modelDirectories

  const [page, setPage] = useState<'home' | 'ai' | 'tokens' | 'prefs' | 'follow' | 'cloud' | 'security' | 'mail' | 'channels'>('home')
  const [settings, setSettings] = useState(() => loadSettings())
  const [mods, setMods] = useState(() => loadModules())
  const [channels, setChannels] = useState<ChannelConfig>(() => loadChannels())
  const [siteList, setSiteList] = useState<DirSite[] | null>(null)
  const [tokens, setTokens] = useState<TokenRecord[]>(() => loadTokens())
  const [savedFlash, setSavedFlash] = useState(false)

  // 栏目频道管理：站点清单**以仓库 sites.json 为权威**（index.json 只补条目数）
  // → 新来源「添加」推送后，哪怕 Actions 还没抓到一条数据，也会立刻出现在这里（标「尚未抓取」）
  useEffect(() => {
    let alive = true
    void loadSiteDirectory()
      .then((list) => {
        if (alive) setSiteList(list)
      })
      .catch(() => {
        if (alive) setSiteList([])
      })
    return () => {
      alive = false
    }
  }, [])

  const upd = (next: any) => {
    setSettings(next)
    saveSettings(next)
    // 数据源改动 → 防抖 600ms 同步到本机共享存储 config.json（MCP 与面板共用同一份，不用再写 profile env）
    if (String(next?.dataRepo ?? '') !== String(settings?.dataRepo ?? '')) scheduleDataRepoConfig(next?.dataRepo)
  }
  const toggleMod = (k: ModuleKey) => {
    const next = { ...mods, [k]: !mods[k] }
    setMods(next)
    saveModules(next)
  }

  // 数据仓配置（2026-09-30 #1）：打开设置时回读本机共享存储那份 config.json；
  // 本地 dataRepo 为空则回填（"缺什么补什么"）—— 换客户端/重装后不用再手填一次。
  // ⚠️ 回填前**必须重读一次当前设置**（2026-09-30 边界修复 #3b）：这个 effect 的 await 期间
  // 用户可能已经开始打字，旧写法直接 `setSettings({...cur, dataRepo: srv.dataRepo})` 会把
  // 用户刚输入的仓名覆盖掉（而且还会 saveSettings 落盘）。只在"现在仍为空"时才回填。
  useEffect(() => {
    void (async () => {
      const cur = loadSettings()
      if (String(cur.dataRepo || '').trim()) return
      const srv = await fetchServerDataRepo()
      if (!srv.dataRepo) return
      const now = loadSettings()
      if (String(now.dataRepo || '').trim()) return // 用户已填 → 不覆盖
      const next = { ...now, dataRepo: srv.dataRepo }
      setSettings(next)
      saveSettings(next)
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  /** 令牌同步状态：面板设置是「唯一入口」，保存后写进本机共享存储，MCP 与工具脚本现读它 */
  const [tokenSync, setTokenSync] = useState<{ ok: boolean; text: string } | null>(null)
  /** 数据仓同步状态（`PUT /api/cau/config` 的结果）：失败必须让用户看见（旧版静默吞掉） */
  const [dataRepoSync, setDataRepoSync] = useState<{ ok: boolean; text: string } | null>(null)

  /**
   * 把数据仓配置推给服务端（防抖 600ms → 服务端写本机共享存储 `config.json`，MCP 现读）。
   * `onStatus` 让设置页把**失败**也显示出来（2026-09-30 边界修复 #2）：旧实现 `.catch(()=>{})`
   * 且不查 `res.ok`，400/500/旧服务端无此路由（404）全被静默吞掉，界面却说"填一次即可"。
   * **放在本文件而不是 `data.ts`**：data.ts 会被内联多份，而这里只被内联两份 —— 本函数只有
   * 设置页用，摆在这儿能少几份拷贝（规则 12/23 的 bundle 纪律）。
   */
  const dataRepoSyncTimer = useRef<any>(null)
  /** 请求代次（Codex 2026-09-30 复审 #3c）：**旧 PUT 的响应可能晚于新 PUT 返回**，
   *  只有最新代次允许更新同步提示，否则会出现"已经失败却显示已同步"。 */
  const dataRepoSyncSeq = useRef(0)
  const scheduleDataRepoConfig = (repo: string) => {
    if (dataRepoSyncTimer.current) clearTimeout(dataRepoSyncTimer.current)
    const seq = ++dataRepoSyncSeq.current
    const setStatus = (s: { ok: boolean; text: string }) => {
      if (seq === dataRepoSyncSeq.current) setDataRepoSync(s)
    }
    dataRepoSyncTimer.current = setTimeout(() => {
      dataRepoSyncTimer.current = null
      void (async () => {
        try {
          const res = await fetch('/api/cau/config', {
            method: 'PUT',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ dataRepo: String(repo || '').trim() }),
          })
          const j: any = await res.json().catch(() => null)
          if (res.ok && j?.ok) {
            setStatus({
              ok: true,
              text: j.configured ? `已同步到本机共享存储（${j.dataRepo}）· MCP 与工具脚本立即可用` : '已清除本机数据仓配置',
            })
            return
          }
          if (res.status === 404) {
            // 旧服务端没有 /api/cau/config：浏览器里填的仓 MCP 读不到（文案与令牌通道一致）
            setStatus({ ok: false, text: '本机配置路由不可用（请重启 dsh web / 桌面版，让插件服务端加载新路由）' })
            return
          }
          setStatus({ ok: false, text: `同步失败：${j?.error || res.status}` })
        } catch (e: any) {
          setStatus({ ok: false, text: `同步失败：${String(e?.message || e)}` })
        }
      })()
    }, 600)
  }

  /**
   * 把令牌同步到本机共享存储（`<profile>\cau-portal-store\token.json`）。
   * 走插件服务端路由 `/api/cau/token`——浏览器不能写本地文件，服务端可以。
   * 取「第一条启用的、有值的」登记为准；都没有则清除本机那份。
   */
  const syncTokenToServer = async (list: TokenRecord[]) => {
    const active = list.find((t) => t.enabled && String(t.value || '').trim())
    try {
      const res = await fetch('/api/cau/token', {
        method: active ? 'PUT' : 'DELETE',
        headers: active ? { 'content-type': 'application/json' } : undefined,
        body: active ? JSON.stringify({ token: String(active.value).trim() }) : undefined,
      })
      const j: any = await res.json().catch(() => null)
      if (j?.ok) {
        setTokenSync({ ok: true, text: active ? `已同步到本机（${j.masked || ''}）· MCP 与脚本立即可用` : '已清除本机令牌' })
      } else {
        setTokenSync({ ok: false, text: `同步失败：${j?.error || res.status}` })
      }
    } catch (e: any) {
      setTokenSync({ ok: false, text: `同步失败：${String(e?.message || e)}` })
    }
  }

  // 首次进入设置页：若本机存储里还没有令牌、而浏览器里已有 → 自动补一次迁移（老用户无感）
  useEffect(() => {
    void (async () => {
      try {
        const res = await fetch('/api/cau/token')
        const j: any = await res.json().catch(() => null)
        if (!j?.ok) {
          setTokenSync({ ok: false, text: '本机令牌路由不可用（需重启 dsh web 让插件服务端加载新路由）' })
          return
        }
        if (!j.configured) {
          const local = loadTokens().find((t) => t.enabled && String(t.value || '').trim())
          if (local) await syncTokenToServer(loadTokens())
        } else {
          setTokenSync({ ok: true, text: `本机已配置（${j.masked}）` })
        }
      } catch {
        /* 静默：面板自身用浏览器里的令牌，不受影响 */
      }
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const persistTokens = (next: TokenRecord[]) => {
    setTokens(next)
    saveTokens(next)
    void syncTokenToServer(next)
  }

  const persistChannels = (next: ChannelConfig) => {
    setChannels(next)
    saveChannels(next)
    flash()
  }
  const toggleSite = (id: string) =>
    persistChannels({ ...channels, sites: { ...channels.sites, [id]: !siteShown(channels, id) } })
  const resetChannels = () => persistChannels({ version: 1, sites: {}, columns: {} })

  /** 来源「名称 / 标签 / 主题色」是本机设置（localStorage）；这里放编辑器的草稿状态，点「完成」才写入 */
  const [editId, setEditId] = useState<string | null>(null)
  const [draft, setDraft] = useState<{ name: string; group: SiteGroup; color: string } | null>(null)
  const openEditor = (s: any) => {
    setEditId(s.id)
    setDraft({ name: siteNameOf(s.id) || s.name || '', group: siteGroupOf(s.id), color: siteColorOf(s.id) })
  }
  const closeEditor = () => {
    setEditId(null)
    setDraft(null)
  }
  /** 保存：名称与「目录里的原名」相同就存空（等于没改）；分组与主题色直接写本机 */
  const saveSource = (id: string, baseName: string) => {
    if (!draft) return
    const n = String(draft.name || '').trim()
    saveSiteName(id, !n || n === String(baseName || '').trim() ? null : n)
    saveSiteGroupOverride(id, draft.group)
    saveSiteColor(id, draft.color || null)
    closeEditor()
  }
  const resetSource = (id: string) => {
    saveSiteName(id, null)
    saveSiteGroupOverride(id, null)
    saveSiteColor(id, null)
    closeEditor()
  }

  // 「添加栏目」：填名称+网址 → 经总线把请求填进主聊天输入框（只填不发送）；draftAck 回执判断是否真填上了
  const [addName, setAddName] = useState('')
  const [addUrl, setAddUrl] = useState('')
  const [addSeq, setAddSeq] = useState(0)
  const draftAck = useSyncExternalStore(subscribeBus, getDraftAck)
  const addFilled = addSeq > 0 && draftAck >= addSeq
  const addNow = () => setAddSeq(requestDraft(buildAddPrompt(addName.trim(), addUrl.trim())))

  /** 可管理的站点（校内平台不在此管理，仍由「数据源」子页的统一门户开关控制） */
  const managedSites = (siteList || []).filter((s: any) => s.id !== 'portal')
  const hiddenSites = managedSites.filter((s: any) => !siteShown(channels, s.id)).length
  const channelBadge =
    siteList === null
      ? { cls: 'off', text: '读取中…' }
      : hiddenSites > 0
        ? { cls: 'warn', text: `已关 ${hiddenSites}/${managedSites.length}` }
        : { cls: 'ok', text: `全部 ${managedSites.length} 个` }

  const alerts = useMemo(() => computeAlerts(), [mods, tokens, settings])

  const flash = () => {
    setSavedFlash(true)
    window.setTimeout(() => setSavedFlash(false), 2000)
  }

  // ---------- 子页：AI 加工 · 模型配置 ----------
  const subList = (cb: () => void) => {
    try {
      return sessions?.list ? sessions.list.subscribe(cb) : noop
    } catch {
      return noop
    }
  }
  const snapList = () => {
    try {
      return sessions?.list?.getSnapshot()
    } catch {
      return undefined
    }
  }
  const listSnap = useSyncExternalStore(subList, snapList)
  const sessionId: string | undefined = listSnap?.current
  const [groups, setGroups] = useState<any[]>([])
  const [modelState, setModelState] = useState<'idle' | 'loading' | 'ok' | 'fail'>('idle')
  const [modelNote, setModelNote] = useState('')

  const loadModelDir = async () => {
    setModelState('loading')
    setModelNote('')
    if (!sessionId || !modelDirectories) {
      setModelState('fail')
      setModelNote('当前没有打开的会话，或模型目录服务不可用')
      return
    }
    let d: any = null
    try {
      d = modelDirectories.directoryFor(sessionId)
    } catch {
      setModelState('fail')
      setModelNote('当前会话无法解析模型目录')
      return
    }
    let settled = false
    const timer = window.setTimeout(() => {
      if (settled) return
      settled = true
      setModelState('fail')
      setModelNote('模型目录未响应（将使用服务端默认模型）')
    }, 6000)
    try {
      await d.load()
      settled = true
      window.clearTimeout(timer)
      setGroups(d.store?.getSnapshot()?.groups || [])
      setModelState('ok')
    } catch {
      settled = true
      window.clearTimeout(timer)
      setModelState('fail')
      setModelNote('模型目录加载失败（将使用服务端默认模型）')
    }
  }

  const monitor = settings.monitorModel || null
  const selGroup = groups.find((g) => g.id === monitor?.provider) || groups[0] || null
  const selModel = selGroup?.models?.find((m: any) => m.id === monitor?.model) || null
  const pickModel = (provider: string, model: string) => {
    upd({ ...settings, monitorModel: { provider, model } })
    flash()
  }

  // 用量
  const [rows, setRows] = useState<any[] | null>(null)
  const [metric, setMetric] = useState<'calls' | 'prompt' | 'completion' | 'cost'>('calls')
  const [days, setDays] = useState(30)
  useEffect(() => {
    let alive = true
    void loadUsageRows().then((r) => {
      if (alive) setRows(r)
    })
    return () => {
      alive = false
    }
  }, [])
  const daily = useMemo(() => (rows ? buildDailyUsage(rows, days, metric) : []), [rows, days, metric])
  const byRole = useMemo(() => (rows ? summarizeUsage(rows, days) : null), [rows, days])
  const METRIC_UNIT: Record<string, string> = { calls: '次', prompt: '输入tok', completion: '输出tok', cost: '元' }

  // ---------- 子页：令牌管理 ----------
  const [tokEditing, setTokEditing] = useState<string | null>(null)
  const [tokDraft, setTokDraft] = useState({ id: '', name: '', usage: '', value: '', expires: '', adminUrl: 'https://github.com/settings/personal-access-tokens', enabled: true })
  const startEdit = (t?: TokenRecord) => {
    if (t) {
      setTokEditing(t.id)
      setTokDraft({ ...t })
    } else {
      setTokEditing('new')
      setTokDraft({ id: '', name: '', usage: '', value: '', expires: '', adminUrl: 'https://github.com/settings/personal-access-tokens', enabled: true })
    }
  }
  const saveTokDraft = () => {
    const d = tokDraft
    if (!d.name.trim()) return
    const rec: TokenRecord = { ...d, id: d.id || `tok-${Date.now().toString(36)}`, value: d.value || '' }
    const next = tokEditing && tokEditing !== 'new' ? tokens.map((t) => (t.id === tokEditing ? rec : t)) : [...tokens, rec]
    persistTokens(next)
    setTokEditing(null)
    flash()
  }
  const removeTok = (id: string) => {
    if (!window.confirm('删除该令牌登记？（令牌值仅本机，删除后不可恢复）')) return
    persistTokens(tokens.filter((t) => t.id !== id))
  }
  const toggleTok = (id: string) => persistTokens(tokens.map((t) => (t.id === id ? { ...t, enabled: !t.enabled } : t)))

  // ---------- 子页：数据源连通检查 ----------
  const [cloudState, setCloudState] = useState<'idle' | 'loading' | 'ok' | 'fail'>('idle')
  const [cloudMsg, setCloudMsg] = useState('')
  const checkCloud = async () => {
    setCloudState('loading')
    setCloudMsg('')
    try {
      const text = await readCloudText('data/index.json')
      const j = JSON.parse(text)
      setCloudState('ok')
      setCloudMsg(`已连通 ✓ 数据更新至 ${j.last_updated || '未知'}，条目 ${j.stats?.total_items ?? '?'} 条 / 正文 ${j.stats?.articles_stored ?? '?'} 篇`)
    } catch (e: any) {
      setCloudState('fail')
      setCloudMsg(String(e?.message || e))
    }
  }

  // ---------- 每日邮件报告（阶段6） ----------
  const fetchEmailStatus = async () => {
    try {
      const r = await fetch('/api/cau/email/status')
      const j = await r.json()
      if (j && j.ok !== false) {
        setMailCfg((c) => ({
          ...c,
          enabled: !!j.enabled,
          sender: j.sender || c.sender,
          recipient: j.recipient || c.recipient || j.sender || c.sender,
          sendTime: j.sendTime || c.sendTime,
          hasCode: !!j.hasCode,
          provider: j.provider ? String(j.provider) : '',
        }))
      }
    } catch (e: any) {
      /* 服务端不可用时保持现状 */
    }
  }
  const [mailCfg, setMailCfg] = useState({ enabled: false, sender: '', authCode: '', recipient: '', sendTime: '08:00', hasCode: false, provider: '', rulesCount: 0 })
  const [mailState, setMailState] = useState<'idle' | 'loading' | 'ok' | 'fail'>('idle')
  const [mailMsg, setMailMsg] = useState('')
  const [mailLast, setMailLast] = useState<string>('')
  const refreshMailInfo = async () => {
    await fetchEmailStatus()
    try {
      const r = await fetch('/api/cau/email/status')
      const j = await r.json()
      if (j && j.ok !== false) {
        setMailLast(
          j.last_sent
            ? `上次发送：${new Date(j.last_sent).toLocaleString('zh-CN', { hour12: false })}（${j.last_mode === 'test' ? '测试' : '日报'}）${j.last_ok === false ? ' · 失败：' + (j.last_error || '未知原因') : ' · 成功'}`
            : '尚未发送过（启用后每天 ' + (j.sendTime || '08:00') + ' 自动发送；测试按钮可先试发）',
        )
        setMailCfg((c) => ({ ...c, rulesCount: j.rulesCount || 0, provider: j.provider || c.provider }))
      }
    } catch (e: any) {
      /* 忽略 */
    }
  }
  const doMailSave = async (enabledOverride?: boolean) => {
    const enabled = enabledOverride ?? mailCfg.enabled
    setMailState('loading')
    setMailMsg('')
    try {
      const r = await fetch('/api/cau/email/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          enabled,
          sender: mailCfg.sender,
          authCode: mailCfg.authCode,
          recipient: mailCfg.recipient,
          sendTime: mailCfg.sendTime,
        }),
      })
      const j = await r.json()
      if (j?.ok) {
        setMailState('ok')
        setMailMsg(enabled ? '已保存并启用：每天 ' + (j.sendTime || mailCfg.sendTime) + ' 自动发送（错过时间开机自动补发）；建议点「测试发送」确认' : '已保存（未启用）')
        setMailCfg((c) => ({ ...c, authCode: '' }))
        void refreshMailInfo()
      } else {
        setMailState('fail')
        setMailMsg(j?.error || '保存失败')
      }
    } catch (e: any) {
      setMailState('fail')
      setMailMsg('服务端不可用：' + String(e?.message || e))
    }
  }
  const doMailToggle = async () => {
    const next = !mailCfg.enabled
    // 未配置就启用 → 直接引导去配置
    if (next && !mailCfg.sender) {
      setPage('mail')
      setMailState('fail')
      setMailMsg('启用前请先填写发件邮箱与授权码')
      return
    }
    try {
      const r = await fetch('/api/cau/email/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: next }),
      })
      const j = await r.json()
      if (j?.ok) {
        setMailCfg((c) => ({ ...c, enabled: !!j.enabled }))
        setMailState(next ? 'ok' : 'idle')
        setMailMsg(next ? '已启用：每天 ' + (j.sendTime || mailCfg.sendTime) + ' 自动发送（错过时间开机补发）' : '已禁用：日报暂停（配置保留）')
      } else {
        setMailState('fail')
        setMailMsg((j?.error || '切换失败') + '（可进页面查看/修复）')
      }
    } catch (e: any) {
      setMailState('fail')
      setMailMsg('服务端不可用：' + String(e?.message || e))
    }
  }
  const doMailTest = async () => {
    setMailState('loading')
    setMailMsg('发送中（30 秒内）…')
    try {
      const r = await fetch('/api/cau/email/test', { method: 'POST' })
      const j = await r.json()
      if (j?.ok) {
        setMailState('ok')
        setMailMsg(`测试邮件已发出：「${j.subject || '农大门户日报'}」→ 请查看收件箱（含垃圾箱）`)
      } else {
        setMailState('fail')
        setMailMsg('发送失败：' + (j?.error || '未知错误') + '（常见：授权码错误 / 服务商被封 / 收件地址不对）')
      }
      void refreshMailInfo()
    } catch (e: any) {
      setMailState('fail')
      setMailMsg('请求失败：' + String(e?.message || e))
    }
  }
  // 关注规则变化 → 同步快照给服务端（邮件的「关注命中」段用）；静默失败
  const syncRulesToEmail = (next: WatchRule[]) => {
    try {
      void fetch('/api/cau/email/rules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rules: next.filter((r) => r.enabled !== false && r.keyword) }),
      })
    } catch (e: any) {
      /* 忽略 */
    }
  }
  useEffect(() => {
    void fetchEmailStatus()
  }, [])

  // ---------- 关注规则 + 系统通知 ----------
  const [rules, setRules] = useState<WatchRule[]>(() => loadRules())
  const [ruleDraft, setRuleDraft] = useState<{ keyword: string; source: string; minImportance: string }>({ keyword: '', source: '', minImportance: '' })
  const [notifyStatus, setNotifyStatus] = useState<string>(() => (typeof Notification !== 'undefined' ? Notification.permission : 'unsupported'))
  const persistRules = (next: WatchRule[]) => {
    setRules(next)
    saveRules(next)
    syncRulesToEmail(next)
  }
  const addRule = () => {
    const k = ruleDraft.keyword.trim()
    if (!k) return
    persistRules([
      ...rules,
      {
        id: newRuleId(),
        keyword: k.slice(0, 30),
        source: ruleDraft.source.trim().slice(0, 30) || undefined,
        minImportance: ruleDraft.minImportance ? (ruleDraft.minImportance as '高' | '中') : undefined,
        enabled: true,
      },
    ])
    setRuleDraft({ keyword: '', source: '', minImportance: '' })
  }

  // ---------- 首页卡片 ----------
  const tokBadge = (() => {
    const err = tokens.some((t) => t.enabled && t.expires && daysUntil(t.expires) != null && daysUntil(t.expires)! < 0)
    const warn = tokens.some((t) => t.enabled && t.expires && daysUntil(t.expires)! <= 30 && daysUntil(t.expires)! >= 0)
    const active = tokens.filter((t) => t.enabled && t.value).length
    return err ? { cls: 'err', text: `${active} 枚在用 · ⚠ 已过期` } : warn ? { cls: 'warn', text: `${active} 枚在用 · ⚠ 临期` } : { cls: 'ok', text: `${active} 枚在用` }
  })()

  // ---------- 首页分组卡片（功能卡有开关；凭据卡无开关、淡底区分）----------
  type CardDef = { key: ModuleKey | null; icon: string; name: string; desc: string; badge: { cls: string; text: string }; need: boolean; page: 'ai' | 'tokens' | 'prefs' | 'follow' | 'cloud' | 'security' | 'mail' | 'channels'; alt?: boolean }
  const cardGroups: { title: string; cards: CardDef[] }[] = [
    {
      title: '智能与数据',
      cards: [
        {
          key: 'ai',
          icon: 'robot',
          name: 'AI 加工 · 模型配置',
          desc: '模型选择 + 用量柱状图（7/30/90 天，次数/token/费用切换）',
          badge: monitor ? { cls: 'ok', text: monitor.model } : { cls: 'warn', text: '未指定模型' },
          need: mods.ai,
          page: 'ai',
        },
        {
          key: 'cloud',
          icon: 'database',
          name: '数据源',
          desc: 'GitHub 云端数据（每 2 小时自动更新）；统一门户 · 校内通知开关在页面内',
          badge: mods.cloud ? { cls: 'ok', text: '已连接云端' } : { cls: 'err', text: '已禁用! 插件无数据' },
          need: mods.cloud,
          page: 'cloud',
        },
        {
          key: null,
          icon: 'books',
          name: '栏目频道管理',
          desc: '首页「栏目频道」「要闻」「今日要览」显示哪些来源；关闭只是不显示，数据照抓',
          badge: channelBadge,
          need: true,
          page: 'channels',
          alt: true,
        },
        {
          key: null,
          icon: 'key',
          name: '令牌管理',
          desc: 'GitHub / 调度桥等令牌：过期日期、剩余天数、一键跳转 GitHub 管理页',
          badge: tokBadge,
          need: true,
          page: 'tokens',
          alt: true,
        },
        {
          key: null,
          icon: 'lock',
          name: '统一门户 · 账号',
          desc: '由于安全考量，该功能在开源工具中不可用',
          badge: { cls: 'warn', text: '不可用' },
          need: true,
          page: 'security',
          alt: true,
        },
      ],
    },
    {
      title: '通知与关注',
      cards: [
        {
          key: 'deadline',
          icon: 'clock',
          name: '待办提醒 · 关注',
          desc: '首页待办卡（截止提醒）、关注规则（关键词订阅）与系统通知',
          badge: mods.deadline ? { cls: 'ok', text: '已启用' } : { cls: 'off', text: '已禁用' },
          need: mods.deadline,
          page: 'follow',
        },
        {
          key: null,
          icon: 'mail',
          name: '每日邮件报告',
          desc: '每天 8:00 自动推送今日摘要到邮箱（错过自动补发）；授权码仅存本机',
          badge: mailCfg.enabled ? { cls: 'ok', text: '已启用' } : mailCfg.sender ? { cls: 'warn', text: '未启用' } : { cls: 'off', text: '未配置' },
          need: true,
          page: 'mail',
        },
      ],
    },
    {
      title: '面板行为',
      cards: [
        {
          key: 'context',
          icon: 'chat',
          name: '面板偏好 · 引用协同',
          desc: '自动附加阅读上下文、引用到对话（上下文条/工具卡片）；面板固定',
          badge: mods.context ? { cls: 'ok', text: '引用协同开' } : { cls: 'off', text: '已禁用' },
          need: mods.context,
          page: 'prefs',
        },
      ],
    },
  ]

  // ---------- 渲染 ----------
  if (page === 'home') {
    return (
      <div className="dsh-cau_set">
        {alerts.map((a, i) => (
          <div key={i} className={`dsh-cau_alert ${a.level}`}>
            <span className="dsh-cau_alertDot" />
            <span>{a.text}</span>
          </div>
        ))}
        <div className="dsh-cau_setDesc">按组管理功能与凭据：功能卡可直接开关，凭据卡（淡底）进入维护；关键项缺失会在此提醒。</div>
        {cardGroups.map((g) => (
          <div key={g.title} className="dsh-cau_setGroup">
            <div className="dsh-cau_setGroupTitle">{g.title}</div>
            <div className="dsh-cau_cards">
              {g.cards.map((c) => (
                <div key={c.name} className={'dsh-cau_setCard' + (c.alt ? ' dsh-cau_setCardAlt' : '')} role="button" tabIndex={0} onClick={() => setPage(c.page)} onKeyDown={(e) => e.key === 'Enter' && setPage(c.page)}>
                  <div className="dsh-cau_cardMain">
                    <span className="dsh-cau_cardName">
                      <span className="dsh-cau_cardIcon">
                        <Ic n={c.icon} />
                      </span>
                      {c.name}
                      <span className={`dsh-cau_cardBadge ${c.badge.cls}`}>{c.badge.text}</span>
                    </span>
                    <span className="dsh-cau_cardDesc">{c.desc}</span>
                  </div>
                  {c.key ? <Toggle on={mods[c.key]} onToggle={() => toggleMod(c.key)} label={`切换 ${c.name}`} /> : c.page === 'mail' ? <Toggle on={mailCfg.enabled} onToggle={() => void doMailToggle()} label="切换 每日邮件报告" /> : null}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    )
  }

  const pageAlerts = alerts.filter((a) => a.page === page)
  const otherCount = alerts.length - pageAlerts.length

  return (
    <div className="dsh-cau_set">
      <div className="dsh-cau_setPageHead">
        <button type="button" className="dsh-cau_setSubBack" onClick={() => setPage('home')}>
          <Ic n="chevLeft" />
          返回
        </button>
        <div className="dsh-cau_setTitle" style={{ margin: 0 }}>
          {page === 'ai' ? 'AI 加工 · 模型配置' : page === 'tokens' ? '令牌管理' : page === 'prefs' ? '面板偏好 · 引用协同' : page === 'follow' ? '待办提醒 · 关注' : page === 'cloud' ? '数据源' : page === 'mail' ? '每日邮件报告' : page === 'channels' ? '栏目频道管理' : '统一门户 · 账号'}
        </div>
        {otherCount > 0 && (
          <button type="button" className="dsh-cau_setOther" title="返回设置首页查看全部提醒" onClick={() => setPage('home')}>
            ⚠ 另有 {otherCount} 项问题
          </button>
        )}
      </div>
      {pageAlerts.map((a, i) => (
        <div key={i} className={`dsh-cau_alert ${a.level}`}>
          <span className="dsh-cau_alertDot" />
          <span>{a.text}</span>
        </div>
      ))}

      {page === 'ai' && (
        <div className="dsh-cau_setBlocks">
          <div className="dsh-cau_setBlock">
            <div className="dsh-cau_setTitle">模型选择</div>
            <div className="dsh-cau_setDesc">独立配置槽：用于面板按需加工（AI 摘要/分类/重要度/deadline）与后续监控，与主对话模型互不影响。换模型只影响之后的加工，数据无需重爬。</div>
            {!sessionId || !modelDirectories ? (
              <div className="dsh-cau_setHint">{!modelDirectories ? '模型目录服务不可用（按需加工将使用服务端默认模型）。' : '当前没有打开的会话——打开一个会话后即可从 DSH 模型目录中选择。'}</div>
            ) : modelState === 'loading' ? (
              <div className="dsh-cau_setRow">
                <span className="dsh-cau_setHint">模型目录加载中…</span>
                <button type="button" className="dsh-cau_setBtn" onClick={() => void loadModelDir()}>刷新</button>
              </div>
            ) : modelState === 'fail' ? (
              <div className="dsh-cau_setRow">
                <span className="dsh-cau_setErr">{modelNote}</span>
                <button type="button" className="dsh-cau_setBtn" onClick={() => void loadModelDir()}>重试</button>
              </div>
            ) : modelState === 'ok' && groups.length === 0 ? (
              <div className="dsh-cau_setRow">
                <span className="dsh-cau_setHint">模型目录为空（检查 provider 配置后重试）。</span>
                <button type="button" className="dsh-cau_setBtn" onClick={() => void loadModelDir()}>刷新</button>
              </div>
            ) : modelState === 'ok' ? (
              <>
                <div className="dsh-cau_setRow">
                  <select className="dsh-cau_setSelect" value={selGroup?.id || ''} onChange={(e) => { const g = groups.find((x) => x.id === e.target.value); if (g?.models?.length) pickModel(g.id, g.models[0].id) }}>
                    {groups.map((g) => (
                      <option key={g.id} value={g.id}>{g.name}</option>
                    ))}
                  </select>
                  {selGroup?.models?.length ? (
                    <select className="dsh-cau_setSelect" value={selModel?.id || selGroup.models[0].id} onChange={(e) => pickModel(selGroup.id, e.target.value)}>
                      {selGroup.models.map((m: any) => (
                        <option key={m.id} value={m.id}>{m.name || m.id}</option>
                      ))}
                    </select>
                  ) : null}
                </div>
                <div className="dsh-cau_setHint">当前：{monitor ? `${monitor.provider} / ${monitor.model}` : '未指定（按需加工使用服务端默认 deepseek-v4-flash）'}</div>
              </>
            ) : (
              <div className="dsh-cau_setRow">
                <span className="dsh-cau_setHint">{monitor ? `当前：${monitor.provider} / ${monitor.model}` : '未指定（按需加工使用服务端默认 deepseek-v4-flash）'}</span>
                <button type="button" className="dsh-cau_setBtn" onClick={() => void loadModelDir()}>加载模型目录</button>
              </div>
            )}
            {savedFlash && <span className="dsh-cau_setOk">已保存 ✓</span>}
          </div>

          <div className="dsh-cau_setBlock">
            <div className="dsh-cau_setTitle">模型用量 · 柱状图</div>
            <div className="dsh-cau_setDesc">默认近 30 天；时间跨度与指标可切换（云端管道 + 本机按需合计）。</div>
            <div className="dsh-cau_chips">
              {[7, 30, 90].map((d) => (
                <button key={d} type="button" className={'dsh-cau_setChip' + (days === d ? ' on' : '')} onClick={() => setDays(d)}>
                  {d} 天
                </button>
              ))}
            </div>
            <div className="dsh-cau_chips">
              {(['calls', 'prompt', 'completion', 'cost'] as const).map((m) => (
                <button key={m} type="button" className={'dsh-cau_setChip' + (metric === m ? ' on' : '')} onClick={() => setMetric(m)}>
                  {METRIC_UNIT[m]}
                </button>
              ))}
            </div>
            {rows === null ? (
              <div className="dsh-cau_setHint">加载用量中…</div>
            ) : daily.length === 0 || !daily.some((d) => d.value > 0) ? (
              <div className="dsh-cau_setHint">近 {days} 天暂无用量记录（AI 加工尚未触发或用时不足）。</div>
            ) : (
              <BarChart items={daily} unit={METRIC_UNIT[metric]} />
            )}
            {byRole && Object.keys(byRole).length > 0 && (
              <>
                <table className="dsh-cau_usageTable">
                  <thead>
                    <tr>
                      <th>角色</th>
                      <th>次数</th>
                      <th>输入</th>
                      <th>输出</th>
                      <th>缓存读</th>
                      <th>金额(元)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(byRole).map(([role, v]) => (
                      <tr key={role}>
                        <td>{ROLE_LABEL[role] || role}</td>
                        <td>{v.calls}</td>
                        <td>{fmtNum(v.prompt)}</td>
                        <td>{fmtNum(v.completion)}</td>
                        <td>{fmtNum(v.cached)}</td>
                        <td>{v.cost ? v.cost.toFixed(4) : '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <div className="dsh-cau_setHint">金额仅对 DeepSeek 附带的计价调用显示；「刷新」后更新。</div>
              </>
            )}
          </div>

          <div className="dsh-cau_setBlock">
            <div className="dsh-cau_setTitle">按需补摘要</div>
            <div className="dsh-cau_infoCard">
              <span className="dsh-cau_setDesc">文章页对未加工的文章提供「AI 补摘要」：调用插件服务端路由（DSH 已配置的模型），浏览器不存任何 API key；结果仅本次会话内显示，不回写云端。</span>
              <span className="dsh-cau_setHint">触发位置：文章阅读页摘要区（无 AI 摘要时出现按钮）。禁用本模块后按钮隐藏。</span>
            </div>
          </div>
        </div>
      )}

      {page === 'tokens' && (
        <div className="dsh-cau_setBlocks">
          <div className="dsh-cau_setBlock">
            <div className="dsh-cau_setTitle">令牌登记</div>
            <div className="dsh-cau_setDesc">每枚令牌可选启用/禁用；「值」仅存本机浏览器；过期日期用于到期提醒；「管理」跳转 GitHub 令牌管理页。停用全部令牌 = 面板无数据（顶部红条提醒）。</div>
            <div className="dsh-cau_setDesc">
              保存后会自动同步到 <b>本机共享存储</b>（<code>cau-portal-store\token.json</code>）—— MCP 工具、每日邮件报告都读它，
              <b>改这里即全链路生效，不用再改配置文件、也不用重启 dsh web</b>。
            </div>
            {tokenSync && (
              <div className={'dsh-cau_setHint' + (tokenSync.ok ? '' : ' dsh-cau_hintErr')}>{tokenSync.ok ? '✓ ' : '✕ '}{tokenSync.text}</div>
            )}
            <div className="dsh-cau_tokList">
              {tokens.length === 0 && <div className="dsh-cau_setHint">暂未登记令牌。请添加 GitHub 数据令牌（细粒度 PAT，Contents: Read，私有数据仓）。</div>}
              {tokens.map((t) => {
                const eb = expiryBadge(t.expires)
                return (
                  <div key={t.id} className="dsh-cau_tok">
                    <Toggle on={t.enabled} onToggle={() => toggleTok(t.id)} label={`${t.name} 启用`} />
                    <div className="dsh-cau_tokMain">
                      <span className="dsh-cau_tokName">
                        {t.name}
                        {!t.enabled && <span className="dsh-cau_cardBadge off">已停用</span>}
                        {!t.value && t.expires && <span className="dsh-cau_cardBadge warn">仅登记过期日</span>}
                      </span>
                      <span className="dsh-cau_tokMeta">
                        {t.usage && <span>{t.usage}</span>}
                        {t.expires && (
                          <span className={eb.cls}>
                            过期 {t.expires} · {eb.text}
                          </span>
                        )}
                      </span>
                    </div>
                    <div className="dsh-cau_tokActs">
                      {t.adminUrl && (
                        <a className="dsh-cau_tokBtn" href={t.adminUrl} target="_blank" rel="noreferrer">
                          管理
                          <Ic n="ext" />
                        </a>
                      )}
                      <button type="button" className="dsh-cau_tokBtn" onClick={() => startEdit(t)}>
                        编辑
                      </button>
                      <button type="button" className="dsh-cau_tokBtn danger" onClick={() => removeTok(t.id)}>
                        删除
                      </button>
                    </div>
                  </div>
                )
              })}
            </div>
            {!tokEditing ? (
              <div className="dsh-cau_setRow">
                <button type="button" className="dsh-cau_setBtn" onClick={() => startEdit()}>
                  <Ic n="plus" />
                  添加令牌
                </button>
              </div>
            ) : (
              <div className="dsh-cau_infoCard">
                <div className="dsh-cau_setTitle" style={{ fontSize: 12 }}>{tokEditing && tokEditing !== 'new' ? '编辑令牌' : '添加令牌'}</div>
                <div className="dsh-cau_setRow">
                  <input className="dsh-cau_setInput" placeholder="名称（如 GitHub 数据令牌）" value={tokDraft.name} onChange={(e) => setTokDraft({ ...tokDraft, name: e.target.value })} />
                </div>
                <div className="dsh-cau_setRow">
                  <input className="dsh-cau_setInput" placeholder="用途说明（如 读取云端数据）" value={tokDraft.usage} onChange={(e) => setTokDraft({ ...tokDraft, usage: e.target.value })} />
                </div>
                <div className="dsh-cau_setRow">
                  <input className="dsh-cau_setInput" type="password" placeholder="令牌值（仅本机；仅登记过期日的可留空）" value={tokDraft.value} onChange={(e) => setTokDraft({ ...tokDraft, value: e.target.value })} spellCheck={false} />
                </div>
                <div className="dsh-cau_setRow">
                  <input className="dsh-cau_setInput" style={{ maxWidth: 170 }} type="date" value={tokDraft.expires} onChange={(e) => setTokDraft({ ...tokDraft, expires: e.target.value })} />
                  <input className="dsh-cau_setInput" placeholder="管理页 URL（默认 GitHub 令牌页）" value={tokDraft.adminUrl} onChange={(e) => setTokDraft({ ...tokDraft, adminUrl: e.target.value })} />
                </div>
                <div className="dsh-cau_setRow">
                  <button type="button" className="dsh-cau_setBtn" disabled={!tokDraft.name.trim()} onClick={saveTokDraft}>
                    保存
                  </button>
                  <button type="button" className="dsh-cau_setBtn" onClick={() => setTokEditing(null)}>
                    取消
                  </button>
                </div>
              </div>
            )}
            {savedFlash && <span className="dsh-cau_setOk">已保存 ✓</span>}
          </div>
        </div>
      )}

      {page === 'prefs' && (
        <div className="dsh-cau_setBlocks">
          <div className="dsh-cau_setBlock">
            <div className="dsh-cau_setTitle">阅读上下文引用</div>
            <label className="dsh-cau_setCheck">
              <input type="checkbox" checked={!!settings.autoAttach} onChange={(e) => upd({ ...settings, autoAttach: e.target.checked })} />
              打开文章时自动附加阅读上下文（发送提问时作为引用材料）
            </label>
            <div className="dsh-cau_infoCard">
              <span className="dsh-cau_setDesc">文章阅读页点「<b>引用到对话</b>」→ 文章作为上下文引用到聊天输入框上方（chip），草稿注入标记行；发送后自动解除。关闭本模块（卡片开关）后引用按钮与上下文条隐藏。</span>
            </div>
          </div>
          <div className="dsh-cau_setBlock">
            <div className="dsh-cau_setTitle">面板固定</div>
            <label className="dsh-cau_setCheck">
              <input type="checkbox" checked={!!settings.panelPinned} onChange={(e) => upd({ ...settings, panelPinned: e.target.checked })} />
              固定面板（点击外部/Esc 不关闭，仅 ✕ 关闭）
            </label>
            <div className="dsh-cau_setHint">与面板头部图钉是同一状态；已打开的面板在下次打开时生效。</div>
          </div>
        </div>
      )}

      {page === 'follow' && (
        <div className="dsh-cau_setBlocks">
          <div className="dsh-cau_setBlock">
            <div className="dsh-cau_setRow" style={{ gap: 8 }}>
              <div className="dsh-cau_setTitle" style={{ margin: 0 }}>
                <Ic n="clock" />
                待办提醒 · 关注
              </div>
              <Toggle on={mods.deadline} onToggle={() => toggleMod('deadline')} label="切换 待办提醒 · 关注" />
            </div>
            <div className="dsh-cau_setDesc">首页「待办卡」展示未过期截止事项（≤7 天），支持留存/归档；关注无上限，文章页点星标加入。关闭本模块后待办卡与关注入口隐藏。</div>
          </div>
          <div className="dsh-cau_setBlock">
            <div className="dsh-cau_setTitle">
              <Ic n="target" />
              关注规则（关键词/来源订阅）
            </div>
            <div className="dsh-cau_setDesc">命中的通知在首页「今日要览」标出、可触发系统通知（下方开关）。规则保存于本机浏览器；关键示例：推免、选课、奖学金、成绩、土地学院、教务处…</div>
            <div className="dsh-cau_tokList">
              {rules.length === 0 && <div className="dsh-cau_setHint">暂无规则。添加关键词后会标出所有来源命中的条目（多规则取并集）。</div>}
              {rules.map((r) => (
                <div key={r.id} className="dsh-cau_tok">
                  <div className="dsh-cau_tokMain">
                    <span className="dsh-cau_tokName">
                      {r.keyword}
                      {!r.enabled && <span className="dsh-cau_cardBadge off">已停用</span>}
                    </span>
                    <span className="dsh-cau_tokMeta">
                      {r.source ? `来源含「${r.source}」` : '全部来源'}
                      {r.minImportance ? ` · 重要度≥${r.minImportance === '高' ? '高' : '高/中'}` : ' · 不限重要度'}
                    </span>
                  </div>
                  <div className="dsh-cau_tokActs">
                    <button type="button" className="dsh-cau_tokBtn" onClick={() => persistRules(rules.map((x) => (x.id === r.id ? { ...x, enabled: !x.enabled } : x)))}>
                      {r.enabled ? '停用' : '启用'}
                    </button>
                    <button type="button" className="dsh-cau_tokBtn danger" onClick={() => persistRules(rules.filter((x) => x.id !== r.id))}>
                      删除
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <div className="dsh-cau_infoCard">
              <label className="dsh-cau_mineLabel">
                <span>关键词（必填，如 推免 / 选课 / 奖学金）</span>
                <input className="dsh-cau_setInput" placeholder="如：推免 / 选课 / 奖学金 / 土地学院" value={ruleDraft.keyword} onChange={(e) => setRuleDraft({ ...ruleDraft, keyword: e.target.value })} />
              </label>
              <label className="dsh-cau_mineLabel">
                <span>来源包含（可空，如 教务处 / 团委 / 土地）</span>
                <input className="dsh-cau_setInput" placeholder="可空（如 教务处 / 团委 / 土地）" value={ruleDraft.source} onChange={(e) => setRuleDraft({ ...ruleDraft, source: e.target.value })} />
              </label>
              <label className="dsh-cau_mineLabel">
                <span>重要度下限（不限 / 高或中 / 只要高）</span>
                <select className="dsh-cau_setSelect" value={ruleDraft.minImportance} onChange={(e) => setRuleDraft({ ...ruleDraft, minImportance: e.target.value })}>
                  <option value="">不限重要度</option>
                  <option value="中">高或中</option>
                  <option value="高">只要高</option>
                </select>
              </label>
              <div className="dsh-cau_setRow">
                <button type="button" className="dsh-cau_setBtn" disabled={!ruleDraft.keyword.trim()} onClick={addRule}>
                  添加规则
                </button>
                {rules.length > 0 && (
                  <button type="button" className="dsh-cau_setBtn danger" onClick={() => persistRules([])}>
                    清空全部
                  </button>
                )}
              </div>
            </div>
          </div>
          <div className="dsh-cau_setBlock">
            <div className="dsh-cau_setTitle">
              <Ic n="bell" />
              系统通知（可选）
            </div>
            <div className="dsh-cau_setDesc">页面开着（不限是否打开面板）时每 10 分钟检查：命中关注规则或新增高重要通知即弹系统通知。首次需点「请求通知授权」。</div>
            <label className="dsh-cau_setCheck">
              <input type="checkbox" checked={!!settings.notifyOn} onChange={(e) => upd({ ...settings, notifyOn: e.target.checked })} />
              启用系统通知
            </label>
            <div className="dsh-cau_setRow">
              <button
                type="button"
                className="dsh-cau_setBtn"
                onClick={() => {
                  if (typeof Notification === 'undefined') return
                  Notification.requestPermission().then((p) => setNotifyStatus(p))
                }}
              >
                请求通知授权
              </button>
              <span className="dsh-cau_setHint">
                {notifyStatus === 'granted' ? '已授权 ✓' : notifyStatus === 'denied' ? '已被拒绝（需在浏览器站点设置中允许通知）' : notifyStatus === 'unsupported' ? '当前环境不支持通知' : '未授权'}
              </span>
            </div>
          </div>
        </div>
      )}

      {page === 'cloud' && (
        <div className="dsh-cau_setBlocks">
          <div className="dsh-cau_setBlock">
            <div className="dsh-cau_setRow" style={{ gap: 8 }}>
              <div className="dsh-cau_setTitle" style={{ margin: 0 }}>
                <Ic n="database" />
                数据源 · GitHub 云端
              </div>
              <Toggle on={mods.cloud} onToggle={() => toggleMod('cloud')} label="切换 数据源" />
            </div>
            <div className="dsh-cau_setDesc">
              数据存于 GitHub 仓库的 `data/`（每 2 小时抓取+AI 加工并提交）；面板与 MCP 直接读云端。<b>这里填一次即可</b>——保存后自动写进本机 `cau-portal-store\config.json`，对话里的 MCP 查询用同一个仓（不必再改 profile 的 `cordis.patch.yml`）。关闭本开关将完全停止数据读取（顶部红条提醒）。
<label className="dsh-cau_setLabel" htmlFor="cauDataRepo">数据仓库（owner/repo）</label>
<input id="cauDataRepo" className="dsh-cau_setInput" value={settings.dataRepo || ''} onChange={(e) => upd({ ...settings, dataRepo: e.target.value })} placeholder="如 your-name/cau-data（必填）" spellCheck={false} autoComplete="off" />
<div className="dsh-cau_setHint">指向含 `data/` 与爬虫产物的仓库；读取/写入用「令牌管理」页配置的令牌。支持填完整 GitHub 链接。<b>留空 = 未配置</b>（顶部红条提醒；MCP 也会提示「请先配置数据仓库」）。</div>
            {dataRepoSync && (
              <div className={'dsh-cau_setHint' + (dataRepoSync.ok ? '' : ' dsh-cau_hintErr')}>
                {dataRepoSync.ok ? '✓ ' : '✕ '}
                {dataRepoSync.text}
              </div>
            )}
            </div>
            <div className="dsh-cau_setRow">
              <button type="button" className="dsh-cau_setBtn" disabled={cloudState === 'loading'} onClick={() => void checkCloud()}>
                {cloudState === 'loading' ? '检查中…' : '连通性检查'}
              </button>
              {cloudState === 'ok' && <span className="dsh-cau_setOk">{cloudMsg}</span>}
              {cloudState === 'fail' && <span className="dsh-cau_setErr">{cloudMsg}</span>}
            </div>
            <div className="dsh-cau_links">
              {KEY_LINKS.slice(0, 3).map((l) => (
                <a className="dsh-cau_link" key={l.key} href={l.url} target="_blank" rel="noreferrer">
                  {l.label}
                  <Ic n="ext" />
                </a>
              ))}
            </div>
          </div>
          <div className="dsh-cau_setBlock">
            <div className="dsh-cau_setRow" style={{ gap: 8 }}>
              <div className="dsh-cau_setTitle" style={{ margin: 0 }}>
                <Ic n="bank" />
                统一门户 · 校内通知
              </div>
              <Toggle on={mods.portal} onToggle={() => toggleMod('portal')} label="切换 统一门户" />
            </div>
            <div className="dsh-cau_setDesc">
              门户数据来自统一门户（one.cau.edu.cn），需登录校园网/SSO 看原文（账号入口见首页「统一门户 · 账号」）。关闭此开关后，面板隐藏门户通知（要闻 / 栏目 / 待办 / 未读计数）；对话查询不受影响。默认开启。
            </div>
          </div>
        </div>
      )}

      {page === 'channels' && (
        <div className="dsh-cau_setBlocks">
          <div className="dsh-cau_setBlock">
            <div className="dsh-cau_setTitle">
              <Ic n="books" />
              首页显示哪些来源
            </div>
            <div className="dsh-cau_setDesc">
              关掉的来源不再出现在首页「栏目频道」「要闻」和「今日要览」里（未读计数同步）。<b>只是不显示</b>——数据照常抓取、AI 照常加工，待办、关注、归档与对话查询都不受影响；重新打开立刻恢复，不用等下一次抓取。
            </div>
            <div className="dsh-cau_tokList">
              {siteList === null && <div className="dsh-cau_setHint">读取站点目录中…</div>}
              {siteList !== null && managedSites.length === 0 && (
                <div className="dsh-cau_setHint">读不到站点目录（请先到「数据源」子页确认连通性 / 令牌）。</div>
              )}
              {managedSites.map((s: any) => {
                const on = siteShown(channels, s.id)
                const cols = (s.columns || []) as any[]
                const items = typeof s.items === 'number' ? s.items : cols.reduce((n: number, c: any) => n + (typeof c.items === 'number' ? c.items : 0), 0)
                return (
                  <div key={s.id} className="dsh-cau_tok">
                    <Toggle on={on} onToggle={() => toggleSite(s.id)} label={`切换 ${siteNameOf(s.id) || s.name}`} />
                    <div className="dsh-cau_tokMain">
                      <span className="dsh-cau_tokName">
                        {siteNameOf(s.id) || s.name}
                        {siteNameOf(s.id) && (
                          <span className="dsh-cau_cardBadge" title="名称是本机改的（可在「编辑」里还原）">
                            本机名称
                          </span>
                        )}
                        {!on && <span className="dsh-cau_cardBadge off">已关闭</span>}
                        {s.pending && (
                          <span className="dsh-cau_cardBadge off" title="配置已就位，等下一轮抓取后出现条目">
                            尚未抓取
                          </span>
                        )}
                      </span>
                      <span className="dsh-cau_tokMeta">
                        <span>{cols.map((c: any) => c.name).join(' · ') || '—'}</span>
                        <span>
                          {cols.length} 个栏目 · {s.pending ? '尚未抓取' : `${items} 条`}
                        </span>
                      </span>
                      {/* 当前配置一览（紧凑只读）+「编辑」入口：名称 / 标签（首页分组）/ 主题色 */}
                      <div className="dsh-cau_srcRowFoot">
                        <span className="dsh-cau_srcTag">{GROUP_LABEL[siteGroupOf(s.id)]}</span>
                        <span className="dsh-cau_srcDotPreview" style={{ background: siteColorOf(s.id) || 'var(--cau-brand)' }} />
                        <button
                          type="button"
                          className="dsh-cau_textBtn"
                          onClick={() => (editId === s.id ? closeEditor() : openEditor(s))}
                        >
                          <Ic n={editId === s.id ? 'close' : 'edit'} />
                          {editId === s.id ? '收起' : '编辑'}
                        </button>
                      </div>
                      {editId === s.id && draft && (
                        <div className="dsh-cau_srcEditor">
                          <label className="dsh-cau_srcField">
                            <span className="dsh-cau_srcFieldLabel">名称</span>
                            <input
                              className="dsh-cau_setInput"
                              style={{ flex: '1 1 160px' }}
                              value={draft.name}
                              placeholder={s.name}
                              onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                            />
                          </label>
                          <div className="dsh-cau_srcField">
                            <span className="dsh-cau_srcFieldLabel">标签</span>
                            <span className="dsh-cau_segGroup" role="group" aria-label="首页分组">
                              {GROUP_ORDER.map((g: SiteGroup) => (
                                <button
                                  key={g}
                                  type="button"
                                  className={'dsh-cau_seg' + (draft.group === g ? ' dsh-cau_segOn' : '')}
                                  onClick={() => setDraft({ ...draft, group: g })}
                                >
                                  {GROUP_LABEL[g]}
                                </button>
                              ))}
                            </span>
                          </div>
                          <div className="dsh-cau_srcField">
                            <span className="dsh-cau_srcFieldLabel">颜色</span>
                            <span className="dsh-cau_swatches" role="group" aria-label="来源主题色">
                              {SITE_COLOR_PRESETS.map((p) => (
                                <button
                                  key={p.key}
                                  type="button"
                                  title={p.name}
                                  aria-label={p.name}
                                  className={'dsh-cau_swatch' + ((draft.color || '') === p.value ? ' dsh-cau_swatchOn' : '')}
                                  style={p.value ? { background: p.value } : { background: 'var(--cau-brand)' }}
                                  onClick={() => setDraft({ ...draft, color: p.value })}
                                />
                              ))}
                            </span>
                          </div>
                          <div className="dsh-cau_srcEditorFoot">
                            <button type="button" className="dsh-cau_textBtn" onClick={() => resetSource(s.id)}>
                              <Ic n="undo" />
                              还原默认
                            </button>
                            <span className="dsh-cau_srcSpacer" />
                            <button type="button" className="dsh-cau_textBtn" onClick={closeEditor}>
                              取消
                            </button>
                            <button type="button" className="dsh-cau_setBtn" onClick={() => saveSource(s.id, s.name)}>
                              完成
                            </button>
                          </div>
                          <div className="dsh-cau_srcEditorHint">
                            颜色只替换<b>该来源页面里原本是品牌绿</b>的部分（AI 摘要条、未读点、选中标签、按钮…）；
                            白色/灰色的文字与描边不跟着变。
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
            <div className="dsh-cau_setRow">
              <button type="button" className="dsh-cau_setBtn" disabled={hiddenSites === 0} onClick={resetChannels}>
                <Ic n="undo" />
                恢复默认（全部显示）
              </button>
            </div>
            <div className="dsh-cau_setHint">
              语义是「黑名单」：只有被你关掉的来源才隐藏。<b>以后新接入的站点/栏目默认就是显示的</b>，接入后会自动出现在这个列表里，不需要手动打开。
            </div>
          </div>

          <div className="dsh-cau_setBlock">
            <div className="dsh-cau_setTitle">
              <Ic n="plus" />
              添加新来源
            </div>
            <div className="dsh-cau_setDesc">
              填名称和网址 → 点「添加到聊天框」，一段请求会放进<b>主聊天输入框</b>（<b>不会自动发送</b>）。你按发送后，智能体会先探测这个站点能不能直接接入、有哪些栏目，把结论报告给你；<b>你确认之后</b>它才写入配置、推送并开始抓取 —— 之后这个列表和首页会自动多出来源，不需要在这里手动打开。
            </div>
            <div className="dsh-cau_setRow">
              <input
                className="dsh-cau_setInput"
                style={{ flex: '1 1 150px' }}
                placeholder="名称（如 校团委）"
                value={addName}
                onChange={(e) => setAddName(e.target.value)}
              />
              <input
                className="dsh-cau_setInput"
                style={{ flex: '2 1 210px' }}
                placeholder="网址（如 https://youth.cau.edu.cn）"
                value={addUrl}
                onChange={(e) => setAddUrl(e.target.value)}
                spellCheck={false}
                autoComplete="off"
              />
              <button type="button" className="dsh-cau_setBtn" disabled={!addUrl.trim()} onClick={addNow}>
                <Ic n="plus" />
                添加到聊天框
              </button>
            </div>
            {addSeq > 0 &&
              (addFilled ? (
                <div className="dsh-cau_setOk">✓ 已填入下方聊天输入框（只填不发送）—— 确认无误后按发送即可，本面板可以留着。</div>
              ) : (
                <div className="dsh-cau_setHint">已排队：当前没有打开的会话，等你打开一个会话后会自动填进输入框。</div>
              ))}
            <div className="dsh-cau_setHint">
              站点能不能接取决于它的建站系统：校内多数站点是博达 CMS（只需登记站点 + 栏目 id，最省事）；自研站点要单独写解析器；需要登录的（如统一门户）不走这里。
            </div>
          </div>

          <div className="dsh-cau_setBlock">
            <div className="dsh-cau_setTitle">
              <Ic n="bank" />
              校内平台不在这里管理
            </div>
            <div className="dsh-cau_infoCard">
              <span className="dsh-cau_setDesc">
                统一门户「校内通知」要登录校园门户，属于数据源 / 凭据范畴，开关仍在「数据源」子页（当前<b>{mods.portal ? '已开启' : '已关闭'}</b>）。首页上它与学院/教务/新闻网之间有一条细分割线区分。开源版不提供统一门户抓取，该来源在首页标「不可用」。
              </span>
              <div className="dsh-cau_setRow">
                <button type="button" className="dsh-cau_setBtn" onClick={() => setPage('cloud')}>
                  <Ic n="bank" />
                  去「数据源」管理统一门户
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {page === 'mail' && (
        <div className="dsh-cau_setBlocks">
          <div className="dsh-cau_setBlock">
            <div className="dsh-cau_setTitle">
              <Ic n="mail" />
              每日报告邮件
            </div>
            <div className="dsh-cau_setDesc">
              每天 <b>{mailCfg.sendTime}</b> 自动把「今日高重要通知 + 3 天内截止 + 命中关注规则 + 昨日回顾」推送到你的邮箱；若发送时间已过才开机，会自动<b>补发</b>。发件与收件可填同一个邮箱（自己发给自己）。授权码只存本机（仓库外），不会上传或显示在日志里。
            </div>
            <label className="dsh-cau_setLabel" htmlFor="cauMailSender">发件邮箱（如 QQ 号@qq.com）</label>
            <input
              id="cauMailSender"
              className="dsh-cau_setInput"
              value={mailCfg.sender}
              onChange={(e) => setMailCfg({ ...mailCfg, sender: e.target.value })}
              placeholder="如 [REDACTED-EMAIL]（QQ/163/Outlook/农大邮箱均可）"
              autoComplete="off"
              spellCheck={false}
            />
            {mailCfg.provider && <div className="dsh-cau_setHint">已识别服务商：{mailCfg.provider}（SMTP 自动配置，无需手填）</div>}
            <label className="dsh-cau_setLabel" htmlFor="cauMailCode">邮箱授权码 {mailCfg.hasCode ? '（已保存；留空则不修改）' : ''}</label>
            <input
              id="cauMailCode"
              className="dsh-cau_setInput"
              type="password"
              value={mailCfg.authCode}
              onChange={(e) => setMailCfg({ ...mailCfg, authCode: e.target.value })}
              placeholder={mailCfg.hasCode ? '已保存授权码，留空保持不变' : 'QQ 邮箱：设置→账户→开启 SMTP→生成授权码'}
              autoComplete="new-password"
            />
            <label className="dsh-cau_setLabel" htmlFor="cauMailTo">收件邮箱（留空 = 发件邮箱）</label>
            <input
              id="cauMailTo"
              className="dsh-cau_setInput"
              value={mailCfg.recipient}
              onChange={(e) => setMailCfg({ ...mailCfg, recipient: e.target.value })}
              placeholder="留空则发给自己（与发件邮箱相同）"
              autoComplete="off"
              spellCheck={false}
            />
            <label className="dsh-cau_setLabel" htmlFor="cauMailTime">发送时间（本机时间，默认 08:00）</label>
            <input id="cauMailTime" className="dsh-cau_setInput" type="time" value={mailCfg.sendTime} onChange={(e) => setMailCfg({ ...mailCfg, sendTime: e.target.value || '08:00' })} />
            <label className="dsh-cau_setCheck">
              <input type="checkbox" checked={mailCfg.enabled} onChange={(e) => setMailCfg({ ...mailCfg, enabled: e.target.checked })} />
              启用每日邮件报告（保存后立即生效：次日 {mailCfg.sendTime || '08:00'} 起自动发送）
            </label>
            <div className="dsh-cau_setRow">
              <button type="button" className="dsh-cau_setBtn" disabled={mailState === 'loading'} onClick={() => void doMailSave()}>
                {mailState === 'loading' ? '保存中…' : (<><Ic n="check" />保存配置</>)}
              </button>
              <button type="button" className="dsh-cau_setBtn" disabled={mailState === 'loading'} onClick={() => void doMailTest()}>
                <Ic n="mail" />
                测试发送
              </button>
              <button type="button" className="dsh-cau_setBtn" onClick={() => void refreshMailInfo()}>
                刷新状态
              </button>
            </div>
            {mailState === 'loading' && mailMsg && <span className="dsh-cau_setWarn">{mailMsg}</span>}
            {mailState === 'ok' && <span className="dsh-cau_setOk">{mailMsg}</span>}
            {mailState === 'fail' && <span className="dsh-cau_setErr">{mailMsg}</span>}
            {mailState === 'idle' && mailMsg && <span className="dsh-cau_setHint">{mailMsg}</span>}
            {mailLast && <div className="dsh-cau_setHint">{mailLast}</div>}
            <div className="dsh-cau_infoCard">
              <span className="dsh-cau_setDesc">
                关注规则已同步 {mailCfg.rulesCount} 条给报告；改规则后自动更新。找不到邮箱授权码？最常用路径——
                <b>QQ 邮箱</b>：网页版 → 设置 → 账户 → 开启「SMTP 服务」→ 按提示发短信后生成 16 位授权码（不是 QQ 密码）。
                <b>163</b>：设置 → POP3/SMTP/IMAP → 开启 SMTP → 客户端授权密码。
              </span>
            </div>
          </div>
        </div>
      )}

      {page === 'security' && (
        <div className="dsh-cau_setBlocks">
          <div className="dsh-cau_setBlock">
            <div className="dsh-cau_setTitle">统一门户 · 账号</div>
            <div className="dsh-cau_infoCard" style={{ alignItems: 'center' }}>
              <span className="dsh-cau_setDesc">由于安全考量，统一门户登录功能在开源版本中<b>不可用</b>。该功能涉及访问校内系统与凭据处理，为避免违反校园信息系统使用规定，未包含在开源工具中。</span>
            </div>
          </div>
          <div className="dsh-cau_setBlock">
            <div className="dsh-cau_setTitle">密钥与重要链接</div>
            <div className="dsh-cau_setDesc">常用页面一键直达；令牌详情与过期日在「令牌管理」页维护。</div>
            <div className="dsh-cau_links">
              {KEY_LINKS.map((l) => (
                <a className="dsh-cau_link" key={l.key} href={l.url} target="_blank" rel="noreferrer">
                  {l.label}
                  <Ic n="ext" />
                </a>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
