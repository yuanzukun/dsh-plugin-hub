import {
  ProviderSetupError,
  type ProviderAuthMethod,
  type ProviderInstanceId,
} from "@t3tools/contracts";
import type { AcpRegistrySettings } from "../settings.ts";
import * as Crypto from "effect/Crypto";
import * as Cause from "effect/Cause";
import * as Deferred from "effect/Deferred";
import * as Effect from "effect/Effect";
import * as Exit from "effect/Exit";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import * as Queue from "effect/Queue";
import * as Result from "effect/Result";
import * as Scope from "effect/Scope";
import * as ChildProcessSpawner from "effect/process/ChildProcessSpawner";
import * as Schema from "effect/Schema";
import type * as AcpSchema from "effect-acp/compat";
import * as EffectAcpErrors from "effect-acp/errors";

import * as PtyAdapter from "@t3tools/shared/PtyAdapter";
import * as ProviderAuthFlow from "@t3tools/provider-core/server/providerAuthFlow";
import { normalizeAcpRegistryAuthMethods, normalizeAcpRegistryWebUrl } from "./probe.ts";
import * as AcpRegistrySupport from "./AcpRegistrySupport.ts";
import * as AcpRegistryRuntimeCoordinator from "./AcpRegistryRuntimeCoordinator.ts";
import * as AcpSessionRuntime from "@t3tools/provider-acp/server/AcpSessionRuntime";
import { sanitizeAcpStderrExcerpt } from "@t3tools/provider-acp/server/stderr";

const isAcpRequestError = Schema.is(EffectAcpErrors.AcpRequestError);

const MAX_ERROR_MESSAGE_LENGTH = 500;

export const formatFailureDetail = (detail: string, cause?: unknown): string => {
  const unwrapped = Cause.isCause(cause) ? Cause.squash(cause) : cause;
  if (isAcpRequestError(unwrapped)) {
    let message = unwrapped.errorMessage.trim();
    const data = unwrapped.data;
    const extra = typeof data === "object" && data !== null && "details" in data && typeof data.details === "string"
      ? data.details.trim() : "";
    if (extra && !message.includes(extra)) message = `${message}: ${extra}`;
    message = sanitizeAcpStderrExcerpt(message, "")
      .replace(/(https?:\/\/)[^\s/@]+:[^\s/@]+@/gi, "$1[redacted]@")
      .replace(/((?:access_token|refresh_token|api_key|password|client_secret)["']?\s*[:=]\s*["']?)[^\s"'&,)]+/gi, "$1[redacted]")
      .replace(/(https?:\/\/[^\s?#]+)[?#][^\s]*/gi, "$1?[redacted]");
    if (message.length > MAX_ERROR_MESSAGE_LENGTH) {
      message = `${message.slice(0, MAX_ERROR_MESSAGE_LENGTH).trimEnd()}…`;
    }
    if (message.length > 0) {
      const trimmed = detail.trimEnd();
      const prefix = trimmed.endsWith(".") ? `${trimmed} ` : `${trimmed}. `;
      return `${prefix}${message}`;
    }
  }
  return detail;
};

type Runtime = Pick<
  AcpSessionRuntime.AcpSessionRuntime["Service"],
  "initialize" | "authenticate" | "start" | "handleElicitation" | "handleUnknownExtNotification" | "logout"
>;

export const makeAcpRegistryAuth = Effect.fn("makeAcpRegistryAuth")(function* (options: {
  readonly instanceId: ProviderInstanceId;
  readonly settings: AcpRegistrySettings;
  readonly cwd: string;
  readonly environment: NodeJS.ProcessEnv;
  readonly onChanged: (authenticated: boolean) => Effect.Effect<void>;
  readonly makeRuntime?: (
    spawn: AcpSessionRuntime.AcpSpawnInput,
  ) => Effect.Effect<Runtime, ProviderSetupError, Scope.Scope>;
}) {
  const catalog = yield* AcpRegistrySupport.AcpRegistryCatalog;
  const spawner = yield* ChildProcessSpawner.ChildProcessSpawner;
  const crypto = yield* Crypto.Crypto;
  const pty = yield* Effect.serviceOption(PtyAdapter.PtyAdapter);
  const coordinator = yield* Effect.serviceOption(
    AcpRegistryRuntimeCoordinator.AcpRegistryRuntimeCoordinator,
  );
  const agentKey =
    options.settings.source === "local" ? `local:${options.instanceId}` : options.settings.agentId;
  const failure = (operation: string, detail: string, cause?: unknown) =>
    new ProviderSetupError({
      instanceId: options.instanceId,
      operation,
      detail: formatFailureDetail(detail, cause),
      cause,
    });
  const resolve = catalog
    .resolve(options.settings, options.cwd, options.environment)
    .pipe(
      Effect.mapError((cause) =>
        failure("start", "Could not prepare the selected ACP agent.", cause),
      ),
    );
  const makeRuntime =
    options.makeRuntime ??
    ((spawn) =>
      Effect.gen(function* () {
        const context = yield* Layer.build(
          AcpSessionRuntime.layer({
            spawn,
            cwd: options.cwd,
            authenticateOnAuthRequired: false,
            clientCapabilities: {
              auth: { terminal: Option.isSome(pty) },
              elicitation: { url: {} },
              fs: { readTextFile: false, writeTextFile: false },
              terminal: false,
            },
            clientInfo: { name: "t3-code-provider-auth", version: "0.0.0" },
          }).pipe(
            Layer.provide(
              Layer.mergeAll(
                Layer.succeed(ChildProcessSpawner.ChildProcessSpawner, spawner),
                Layer.succeed(Crypto.Crypto, crypto),
              ),
            ),
          ),
        );
        return yield* Effect.service(AcpSessionRuntime.AcpSessionRuntime).pipe(
          Effect.provide(context),
        );
      }).pipe(
        Effect.mapError((cause) =>
          failure("start", "Could not start the selected ACP agent.", cause),
        ),
      ));

  let knownMethods:
    | { readonly version: string | null; readonly methods: ReadonlyArray<ProviderAuthMethod> }
    | undefined;
  const discoverMethods = Effect.scoped(
    Effect.gen(function* () {
      const inspected = yield* catalog
        .inspect(options.settings, options.environment)
        .pipe(
          Effect.mapError((cause) =>
            failure("methods", "Could not inspect the selected ACP agent.", cause),
          ),
        );
      if (inspected.status !== "ready")
        return yield* failure("methods", "Prepare this ACP agent before signing in.");
      // Path overrides can change in place; cache discovery only for registry versions.
      if (inspected.version !== null && knownMethods?.version === inspected.version)
        return knownMethods.methods;
      const resolved = yield* resolve;
      const runtime = yield* makeRuntime(resolved.spawn);
      const initialized = yield* runtime
        .initialize()
        .pipe(
          Effect.mapError((cause) =>
            failure("methods", "Could not discover this agent's sign-in methods.", cause),
          ),
        );
      const advertised = normalizeAcpRegistryAuthMethods(initialized.authMethods)
        .filter(
          (method) => method.id.length <= 128 && (method.type !== "terminal" || Option.isSome(pty)),
        )
        .slice(0, 32)
        .map((method) => ({
          id: method.id,
          name: method.name,
          description: method.description,
          type: method.type === "env_var" ? ("credentials" as const) : method.type,
          ...(method.envVarNames ? { envVarNames: method.envVarNames } : {}),
          ...(method.link ? { link: method.link } : {}),
        }));
      knownMethods = { version: inspected.version, methods: advertised };
      return advertised;
    }),
  ).pipe(
    Effect.timeoutOrElse({
      duration: "30 seconds",
      orElse: () =>
        Effect.fail(failure("methods", "The ACP agent did not advertise sign-in methods in time.")),
    }),
  );

  const methods = Option.isSome(coordinator)
    ? coordinator.value
        .runBackgroundProbe(agentKey, discoverMethods)
        .pipe(
          Effect.flatMap((result) =>
            Effect.fromOption(result, () =>
              failure(
                "methods",
                "Sign-in discovery was interrupted by an active provider session. Try again.",
              ),
            ),
          ),
        )
    : discoverMethods;

  const runTerminal = Effect.fnUntraced(function* (
    resolved: AcpRegistrySupport.ResolvedAcpRegistryAgent,
    method: Extract<AcpSchema.AuthMethod, { readonly type: "terminal" }>,
    context: ProviderAuthFlow.ProviderAuthFlowContext,
  ) {
    if (Option.isNone(pty))
      return yield* failure(
        "start",
        "Interactive provider login is unavailable on this environment.",
      );
    const exited = yield* Deferred.make<number>();
    const output = yield* Queue.sliding<string>(64);
    const process = yield* pty.value
      .spawn({
        shell: resolved.spawn.command,
        args: [...resolved.spawn.args, ...(method.args ?? [])],
        cwd: options.cwd,
        cols: 80,
        rows: 24,
        env: { ...options.environment, ...resolved.spawn.env, ...method.env },
      })
      .pipe(
        Effect.mapError((cause) =>
          failure("start", "Could not open the provider sign-in terminal.", cause),
        ),
      );
    const detachData = process.onData((data) => {
      Queue.offerUnsafe(output, data.slice(-16_384));
    });
    const detachExit = process.onExit(({ exitCode }) => {
      Deferred.doneUnsafe(exited, Effect.succeed(exitCode));
    });
    yield* Effect.addFinalizer(() =>
      Effect.sync(() => {
        detachData();
        detachExit();
        try {
          process.kill();
        } catch {}
      }),
    );
    let transcript = "";
    let outputOffset = 0;
    const update = () =>
      context.setInteraction(
        { type: "terminal", id: "terminal", output: transcript, outputOffset },
        (response) =>
          response.type === "terminal"
            ? Effect.try({
                try: () => {
                  if (response.size) process.resize(response.size.cols, response.size.rows);
                  if (response.data) process.write(response.data);
                },
                catch: () =>
                  failure("respond", "The provider sign-in terminal is no longer available."),
              })
            : Effect.void,
      );
    yield* update();
    yield* Queue.take(output).pipe(
      Effect.flatMap((data) => {
        outputOffset += data.length;
        transcript = (transcript + data).slice(-16_384);
        return update();
      }),
      Effect.forever,
      Effect.forkScoped,
    );
    if ((yield* Deferred.await(exited)) !== 0)
      return yield* failure("start", "The provider login command did not finish successfully.");
  });

  const authenticate = Effect.fn("AcpRegistryAuth.authenticate")(function* (
    methodId: string,
    context: ProviderAuthFlow.ProviderAuthFlowContext,
  ) {
    if (!options.settings.enabled)
      return yield* failure("start", "Enable this provider before signing in.");
    const login = Effect.scoped(
      Effect.gen(function* () {
        const resolved = yield* resolve;
        const runtimeScope = yield* Scope.make();
        yield* Effect.addFinalizer(() => Scope.close(runtimeScope, Exit.void));
        const runtime = yield* makeRuntime(resolved.spawn).pipe(
          Effect.provideService(Scope.Scope, runtimeScope),
        );
        yield* runtime.handleUnknownExtNotification((method, params) => {
          // This vendor extension is a browser handoff, not proof of auth.
          // Standard ACP URL elicitation continues to use explicit consent.
          if (method !== "_codebuddy.ai/authUrl" || typeof params !== "object" || params === null)
            return Effect.void;
          const authUrl = (params as { authUrl?: unknown }).authUrl;
          const url = typeof authUrl === "string" ? normalizeAcpRegistryWebUrl(authUrl) : undefined;
          return url ? context.setInteraction({ type: "browser", id: "agent-browser-handoff", url, requiresConsent: false }) : Effect.void;
        });
        yield* runtime.handleElicitation((request) =>
          Effect.gen(function* () {
            if (
              request.mode !== "url" ||
              !("url" in request) ||
              !("elicitationId" in request) ||
              typeof request.url !== "string" ||
              typeof request.elicitationId !== "string"
            )
              return { action: "decline" } as const;
            const url = normalizeAcpRegistryWebUrl(request.url);
            const id = request.elicitationId.trim();
            if (!url || !id || id.length > 128) return { action: "decline" } as const;
            const consent = yield* Deferred.make<boolean>();
            yield* context.setInteraction(
              { type: "browser", id, url, requiresConsent: true },
              (response) =>
                response.type === "browser"
                  ? Deferred.succeed(consent, response.action === "accept").pipe(Effect.asVoid)
                  : Effect.void,
            );
            return (yield* Deferred.await(consent))
              ? ({ action: "accept" } as const)
              : ({ action: "decline" } as const);
          }),
        );
        const initialized = yield* runtime
          .initialize()
          .pipe(
            Effect.mapError((cause) =>
              failure("start", "Could not initialize the selected ACP agent.", cause),
            ),
          );
        const method = initialized.authMethods?.find((method) => method.id === methodId);
        if (!method)
          return yield* failure("start", "The agent no longer advertises this sign-in method.");
        if (!context.forceReauthentication) {
          // Some ACP agents interpret authenticate as "log out, then sign in".
          // A missing host confirmation must not destroy valid native credentials.
          const existing = yield* runtime.start().pipe(Effect.result);
          if (Result.isSuccess(existing)) return;
          if (!isAcpRequestError(existing.failure) || existing.failure.code !== -32000)
            return yield* failure("verify", "Could not verify the existing agent session.", existing.failure);
        }
        if (method.type === "terminal") {
          yield* Scope.close(runtimeScope, Exit.void);
          yield* runTerminal(resolved, method, context).pipe(Effect.scoped);
          // Terminal login is a separate invocation. Reconnect after it exits so
          // the ACP process reads the credentials its login command persisted.
          const verifiedRuntime = yield* makeRuntime(resolved.spawn);
          yield* context.verifying;
          yield* verifiedRuntime
            .start()
            .pipe(
              Effect.mapError((cause) =>
                failure(
                  "verify",
                  "The provider could not create a session after terminal sign-in.",
                  cause,
                ),
              ),
            );
        } else {
          if (method.type === undefined || method.type === "agent") {
            if (!runtime.authenticate)
              return yield* failure("start", "This runtime does not support explicit ACP sign-in.");
            yield* runtime
              .authenticate(methodId)
              .pipe(
                Effect.mapError((cause) =>
                  failure("start", "The ACP agent could not complete sign-in.", cause),
                ),
              );
          }
          // Legacy env_var methods use the secret-backed environment fields in
          // provider settings. Never send their ID to authenticate.
          yield* context.verifying;
          yield* runtime
            .start()
            .pipe(
              Effect.mapError((cause) =>
                failure("verify", "The provider could not create a session after sign-in.", cause),
              ),
            );
        }
      }),
    );
    yield* Option.isSome(coordinator)
      ? coordinator.value.withForegroundStartup(agentKey, login)
      : login;
    yield* options.onChanged(true);
  });
  const logout = Effect.scoped(
    Effect.gen(function* () {
      const resolved = yield* resolve;
      const runtime = yield* makeRuntime(resolved.spawn);
      yield* runtime.logout.pipe(
        Effect.mapError((cause) =>
          failure(
            "logout",
            "This ACP agent could not sign out. It may not advertise logout support.",
            cause,
          ),
        ),
      );
    }),
  ).pipe(
    Effect.timeoutOrElse({
      duration: "60 seconds",
      orElse: () =>
        Effect.fail(failure("logout", "The ACP agent did not finish signing out in time.")),
    }),
  );
  const signOut = (
    Option.isSome(coordinator) ? coordinator.value.withForegroundStartup(agentKey, logout) : logout
  ).pipe(Effect.andThen(options.onChanged(false)));
  return yield* ProviderAuthFlow.make({
    instanceId: options.instanceId,
    // ACP omits credential scope; assume an agent's instances share credentials in this environment.
    credentialBinding: { owner: "provider", key: `acp:${agentKey}` },
    methods,
    ...(options.settings.authMethodId ? { defaultMethodId: options.settings.authMethodId } : {}),
    authenticate,
    logout: signOut,
  });
});
