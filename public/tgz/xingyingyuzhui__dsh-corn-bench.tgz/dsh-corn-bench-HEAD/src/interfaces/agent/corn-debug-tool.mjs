// @ts-check

import { finalizeAgentCommandResult } from '../../application/commands/lossless-json.mjs'
import { dispatchCornDebugCommand } from '../../infrastructure/host/corn-host-client.mjs'

export const DEBUG_TOOL_ACTIONS = new Set([
  'status',
  'start',
  'stop',
  'run',
  'pause',
  'step',
  'breakpoint',
  'watchpoint',
  'inspect',
  'evaluate',
  'snapshot',
  'reset',
  'verify',
])

/**
 * @param {any} agent
 * @returns {string}
 */
export const cwdOf = (agent) => {
  const session = agent?.session
  const header = session?.header
  return header?.cwd ? String(header.cwd) : ''
}

/**
 * @param {any} agent
 * @returns {string}
 */
export const sessionIdOf = (agent) => {
  const session = agent?.session
  const header = session?.header
  if (header?.id) return String(header.id)
  if (session?.id) return String(session.id)
  return ''
}

/**
 * Factory for the `corn_debug` agent tool.
 * Provides isolated firmware runtime debugging capabilities without raw GDB/OpenOCD exposure.
 * Parity with ADR-013 & Phase 5 Section 9.2.
 *
 * @param {string} home
 */
export function cornDebugTool(home) {
  return {
    name: 'corn_debug',
    description:
      'Firmware runtime debugging tool. Controls and inspects embedded targets via GDB and OpenOCD hardware backend. ' +
      'status: query current debug session, target run state, call stack, breakpoints, and watchpoints. ' +
      'start: start hardware debug session for current workspace firmware artifact. ' +
      'stop: stop active debug session and release hardware probe lease. ' +
      'run: resume target execution (continue). ' +
      'pause: interrupt/halt running target. ' +
      'step: single step (over/into/out). ' +
      'breakpoint: set, remove, or list line/function breakpoints. ' +
      'watchpoint: set data watchpoint on memory expression to catch unexpected modifications. ' +
      'inspect: inspect registers, call stack, local variables, or target memory. ' +
      'evaluate: evaluate C expression in current scope. ' +
      'snapshot: capture forensic snapshot of current target state. ' +
      'reset: reset target CPU and halt. ' +
      'verify: execute closed-loop verification scenario against target firmware and Modbus telemetry. ' +
      'ok is true only when status=pass. status=fail means valid data did not meet an expectation; ' +
      'status=error with errorCode=VERIFY_UNVERIFIABLE means some assertions had no trustworthy data ' +
      '(assertions[].outcome=unverifiable with reason, counted in unverifiableCount) and must not be read as pass. ' +
      'A stable-for-duration durationMs longer than the effective timeoutMs is rejected with INVALID_FIELD. ' +
      'Verify reads only points and alarms visible to this session; static point config values are never data. ' +
      'When a visible point has no usable runtime value, verify performs one real Modbus read that leaves the ' +
      'normal read trace (task, frames, values, journal); a busy or failed read is READ_FAILED, not retried.',
    parameters: {
      type: 'object',
      additionalProperties: false,
      required: ['action'],
      properties: {
        action: {
          type: 'string',
          enum: [...DEBUG_TOOL_ACTIONS],
          description: [...DEBUG_TOOL_ACTIONS].join(' | '),
        },
        backend: {
          type: 'string',
          enum: ['gdb-openocd'],
          description: 'Debug backend (default: gdb-openocd)',
        },
        file: { type: 'string', description: 'Source file for breakpoint' },
        line: { type: 'number', description: 'Source line number for breakpoint' },
        function: { type: 'string', description: 'Function name for breakpoint' },
        expression: { type: 'string', description: 'Expression for watchpoint or evaluate' },
        access: {
          type: 'string',
          enum: ['write', 'read', 'readWrite'],
          description: 'Watchpoint access type (default: write)',
        },
        breakpointId: { type: 'string', description: 'Breakpoint ID to remove' },
        watchpointId: { type: 'string', description: 'Watchpoint ID to remove' },
        stepType: {
          type: 'string',
          enum: ['over', 'into', 'out'],
          description: 'Step mode (default: over)',
        },
        frame: { type: 'number', description: 'Stack frame level for evaluate or inspect' },
        include: {
          type: 'string',
          enum: ['all', 'stack', 'locals', 'registers', 'memory'],
          description: 'Scope of inspection',
        },
        address: { type: 'string', description: 'Memory address to read (e.g. 0x20000000)' },
        length: { type: 'number', description: 'Number of bytes to read from memory' },
        snapshotId: { type: 'string', description: 'Snapshot ID to retrieve or reference' },
        op: { type: 'string', description: 'Sub-operation (e.g. get, list, remove)' },
        reason: { type: 'string', description: 'Reason for diagnostic snapshot' },
        scenario: { type: 'object', description: 'Verification scenario specification' },
        scenarioName: { type: 'string', description: 'Verification scenario name' },
        timeoutMs: { type: 'number', description: 'Timeout in milliseconds for verification' },
        commandId: { type: 'string', description: 'Idempotency key' },
      },
    },
    output: {
      schema: { type: 'object', additionalProperties: true },
      /**
       * @param {any} _args
       * @param {any} value
       */
      render(_args, value) {
        return [{ type: 'text', text: JSON.stringify(value, null, 2) }]
      },
    },
    timeoutMs: 620000,
    /**
     * @param {any} args
     * @param {any} [exec]
     */
    async execute(args, exec) {
      const agent = exec?.agent
      const signal = exec?.signal
      if (signal?.aborted) {
        return finalizeAgentCommandResult({ ok: false, cancelled: true, error: '已取消' }, 'agent')
      }
      return finalizeAgentCommandResult(
        await dispatchCornDebugCommand({
          home,
          cwd: cwdOf(agent),
          action: args?.action,
          payload: args || {},
          source: 'agent',
          sessionId: sessionIdOf(agent),
          signal,
          commandId: args?.commandId,
          requireHost: true,
        }),
        'agent',
      )
    },
  }
}
