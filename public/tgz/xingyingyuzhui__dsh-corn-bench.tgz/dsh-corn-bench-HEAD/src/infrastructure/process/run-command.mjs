// @ts-check
import { execFile, spawnSync } from 'node:child_process'
import { existsSync } from 'node:fs'
import { basename, dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const RUNTIME_DIR = join(dirname(fileURLToPath(import.meta.url)), '../../..', 'runtime')
/** @type {Record<string, string>} */
const SCRIPTS = {}

/**
 * @typedef {{
 *   signal?: AbortSignal,
 *   timeoutMs?: number,
 *   maxBuffer?: number,
 *   cwd?: string,
 *   env?: NodeJS.ProcessEnv,
 * }} ExecOpts
 */

/**
 * @param {unknown} pythonBin
 * @param {readonly string[]} extra
 */
const pythonArgv = (pythonBin, extra) => {
  const name = basename(String(pythonBin).replace(/\\/g, '/')).toLowerCase()
  const prefix = name === 'py' || name === 'py.exe' ? ['-3'] : []
  return prefix.concat(extra)
}

/** @param {unknown} text */
const parseJsonStdout = (text) => {
  const raw = String(text || '').trim()
  if (!raw) return { error: '脚本没有输出' }
  try {
    return { data: JSON.parse(raw) }
  } catch {
    const start = raw.lastIndexOf('{')
    const end = raw.lastIndexOf('}')
    if (start >= 0 && end > start) {
      try {
        return { data: JSON.parse(raw.slice(start, end + 1)) }
      } catch {
        /* fall through */
      }
    }
    return { error: '脚本输出不是 JSON', preview: raw.slice(0, 400) }
  }
}

/** @param {number | undefined} pid */
export const killProcessTree = (pid) => {
  if (!pid || pid <= 0) return
  if (process.platform === 'win32') {
    spawnSync('taskkill', ['/PID', String(pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true })
    return
  }
  try {
    process.kill(pid, 'SIGTERM')
  } catch {
    /* already gone */
  }
}

/**
 * @param {string} bin
 * @param {readonly string[]} args
 * @param {ExecOpts} [opts]
 */
export const runExecFile = (bin, args, opts = {}) =>
  new Promise((resolve, reject) => {
    const signal = opts.signal
    if (signal && signal.aborted) {
      resolve({
        exitCode: 1,
        timedOut: false,
        cancelled: true,
        stdout: '',
        stderr: '已取消',
      })
      return
    }
    let cancelled = false
    let timedOut = false
    let settled = false
    /** @type {import('node:child_process').ChildProcess | undefined} */
    let child
    const finish = () => {
      if (settled) return
      settled = true
    }
    const onAbort = () => {
      cancelled = true
      if (child) killProcessTree(child.pid)
    }
    if (signal) signal.addEventListener('abort', onAbort, { once: true })
    // execFile's built-in timeout only kills the direct child; route expiry
    // through killProcessTree so grandchildren like UV4.exe die with it.
    const timeoutMs = opts.timeoutMs || 0
    const killer =
      timeoutMs > 0
        ? setTimeout(() => {
            timedOut = true
            if (child) killProcessTree(child.pid)
          }, timeoutMs)
        : null
    child = execFile(
      bin,
      args,
      {
        maxBuffer: opts.maxBuffer || 1024 * 1024,
        windowsHide: true,
        encoding: 'utf8',
        cwd: opts.cwd,
        env: opts.env || process.env,
      },
      (error, stdout, stderr) => {
        if (killer) clearTimeout(killer)
        if (signal) signal.removeEventListener('abort', onAbort)
        if (error && error.code === 'ENOENT') {
          finish()
          reject(new Error('无法启动: ' + bin))
          return
        }
        finish()
        resolve({
          exitCode: error ? (typeof error.code === 'number' ? error.code : 1) : 0,
          timedOut,
          cancelled,
          stdout: String(stdout || ''),
          stderr: String(stderr || (error && error.message) || ''),
        })
      },
    )
  })

/**
 * @param {unknown} pythonBin
 * @param {string} scriptName
 * @param {readonly string[]} args
 * @param {ExecOpts} [opts]
 */
export const runPythonScript = async (pythonBin, scriptName, args, opts = {}) => {
  if (!pythonBin) return { ok: false, error: '未绑定 Python' }
  const bin = /** @type {string} */ (pythonBin)
  if (!existsSync(bin)) return { ok: false, error: 'Python 路径不存在: ' + pythonBin }
  const script = SCRIPTS[scriptName]
  if (!script || !existsSync(script)) return { ok: false, error: '脚本不存在: ' + scriptName }
  if (opts.signal && opts.signal.aborted) return { ok: false, cancelled: true, error: '已取消' }
  const argv = pythonArgv(bin, [script, ...args])
  const ran = await runExecFile(bin, argv, {
    timeoutMs: opts.timeoutMs || 30000,
    cwd: opts.cwd,
    signal: opts.signal,
  })
  if (ran.cancelled) return { ok: false, cancelled: true, error: '已取消', exitCode: ran.exitCode }
  if (ran.timedOut) return { ok: false, error: '脚本超时' }
  const parsed = parseJsonStdout(ran.stdout)
  if (parsed.error) {
    const errText = (ran.stderr || parsed.preview || parsed.error).slice(0, 400)
    return { ok: false, error: parsed.error + (errText ? ': ' + errText : ''), exitCode: ran.exitCode }
  }
  const data = parsed.data
  if (data && data.status === 'error') {
    const message = data.error && data.error.message ? data.error.message : '脚本失败'
    return { ok: false, error: message, result: data, exitCode: ran.exitCode }
  }
  return { ok: true, result: data, exitCode: ran.exitCode }
}

export const _internal = { pythonArgv, parseJsonStdout, SCRIPTS, RUNTIME_DIR, killProcessTree }
