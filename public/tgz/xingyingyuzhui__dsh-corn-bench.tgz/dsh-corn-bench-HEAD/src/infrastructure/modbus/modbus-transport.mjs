// @ts-check
import { normalizeModbus } from '../../domain/modbus/modbus-migration.mjs'
import { getCornIoBroker } from './io-broker.mjs'
import { clampTimeoutMs, endpointFingerprint, ioError, toEndpoint, validateIoRequest } from '../../domain/modbus/io-contract.mjs'
import { forgetSimConnection, overlaySimRead, rememberSimWrite } from './sim-register-bank.mjs'

/**
 * @typedef {{ id?: string, connectionId?: string, role?: string, enabled?: boolean, sim?: boolean, conn?: { sim?: boolean, mode?: string } }} TransportConnection
 * @typedef {{ id?: string, unitId?: unknown }} TransportDevice
 * @typedef {{ fc?: unknown, address?: unknown, count?: number }} TransportBatch
 * @typedef {{ address?: unknown, function?: unknown }} TransportPoint
 * @typedef {{
 *   cwd?: unknown,
 *   connection?: TransportConnection,
 *   device?: TransportDevice,
 *   batch?: TransportBatch,
 *   point?: TransportPoint,
 *   values?: unknown,
 *   timeoutMs?: unknown,
 *   configVersion?: unknown,
 *   fc?: unknown,
 *   source?: unknown,
 * }} TransportBuildInput
 * @typedef {{
 *   endpoint?: { sim?: boolean, mode?: string },
 *   address?: unknown,
 *   count?: number,
 *   functionCode?: unknown,
 *   values?: unknown,
 *   cwd?: unknown,
 *   connectionId?: unknown,
 *   since?: unknown,
 *   max?: unknown,
 * }} TransportRequest
 * @typedef {{ sim?: boolean, signal?: AbortSignal }} TransportCallOpts
 * @typedef {{ code?: unknown, message?: unknown, frames?: unknown, transactionId?: unknown, durationMs?: unknown }} ThrownIo
 */

/**
 * @param {unknown} error
 * @returns {ThrownIo & { raw: unknown }}
 */
function thrownIo(error) {
  if (!error || typeof error !== 'object') return { raw: error }
  return { raw: error, .../** @type {ThrownIo} */ (error) }
}

/** @param {Record<string, unknown>} request @returns {TransportRequest} */
function asRequest(request) {
  return /** @type {TransportRequest} */ (request)
}

/** @param {Record<string, unknown>} [opts] @returns {TransportCallOpts} */
function asOpts(opts) {
  return /** @type {TransportCallOpts} */ (opts || {})
}

let simSeq = 0
const nextSimTx = () => 'sim:' + ++simSeq
let reqSeq = 0
const nextReqId = () => 'req-' + Date.now().toString(36) + '-' + ++reqSeq

const nowMs = () => {
  if (typeof performance !== 'undefined' && performance.now) return performance.now()
  return Number(process.hrtime.bigint()) / 1e6
}

/** @param {TransportBuildInput} input */
export const toReadRequest = ({ cwd, connection, device, batch, timeoutMs, configVersion, source }) => {
  const endpoint = toEndpoint(connection)
  const unitId = Math.trunc(Number(device && device.unitId))
  return {
    v: 1,
    op: 'modbus.read',
    cwd,
    connectionId: connection && (connection.id || connection.connectionId),
    deviceId: device && device.id,
    endpoint,
    unitId,
    functionCode: Number(batch && batch.fc),
    address: Number(batch && batch.address),
    count: Number(batch && batch.count),
    timeoutMs: clampTimeoutMs(timeoutMs, 1000),
    configVersion: Number(configVersion) || 0,
    source: source === 'agent' ? 'agent' : source === 'polling' ? 'polling' : 'manual',
  }
}

/** @param {TransportBuildInput} input */
export const toWriteRequest = ({ cwd, connection, device, point, values, timeoutMs, configVersion, fc, source }) => {
  const endpoint = toEndpoint(connection)
  const unitId = Math.trunc(Number(device && device.unitId))
  return {
    v: 1,
    op: 'modbus.write',
    cwd,
    connectionId: connection && (connection.id || connection.connectionId),
    deviceId: device && device.id,
    endpoint,
    unitId,
    functionCode: Number(fc || (point && point.function)),
    address: Number(point && point.address),
    values: Array.isArray(values) ? values : [values],
    timeoutMs: clampTimeoutMs(timeoutMs, 1000),
    configVersion: Number(configVersion) || 0,
    source: source === 'agent' ? 'agent' : source === 'polling' ? 'polling' : 'manual',
  }
}

/**
 * @param {{ address?: unknown, count?: number }} batch
 * @param {unknown} [fc]
 */
const simRaw = (batch, fc = 3) => {
  const tick = Math.floor(Date.now() / 1000)
  return Array.from({ length: batch.count ?? 0 }, (_, i) => {
    const addr = Number(batch.address || 0) + i
    if (fc === 1 || fc === 2) {
      return (Math.floor(tick / 4) + addr) % 2 === 0 ? 1 : 0
    }
    if (addr === 0) {
      // Temperature ~ 25.0 C (with scale 0.1 -> raw ~ 250)
      return Math.round(250 + 15 * Math.sin(tick * 0.1 + addr))
    }
    if (addr === 1) {
      // Pressure ~ 0.50 MPa (with scale 0.01 -> raw ~ 50)
      return Math.round(50 + 8 * Math.sin(tick * 0.12 + addr))
    }
    if (addr === 2) {
      // Liquid level ~ 60 % (with scale 1 -> raw ~ 60)
      return Math.round(60 + 12 * Math.sin(tick * 0.08 + addr))
    }
    if (addr === 3) {
      // Valve opening ~ 50 % (with scale 1 -> raw ~ 50)
      return Math.round(50 + 15 * Math.sin(tick * 0.15 + addr))
    }
    const base = ((addr * 43 + 120) % 500) + 50
    const delta = Math.round((base * 0.06 + 5) * Math.sin(tick * 0.1 + addr))
    return Math.max(0, Math.min(65535, base + delta))
  })
}

/** @param {unknown} prevModbus @param {unknown} nextModbus */
export function changedConnectionIds(prevModbus, nextModbus) {
  const prev = normalizeModbus(prevModbus || {})
  const next = normalizeModbus(nextModbus || {})
  const prevConnections = /** @type {TransportConnection[]} */ (prev.connections || [])
  const nextConnections = /** @type {TransportConnection[]} */ (next.connections || [])
  const ids = []
  for (const old of prevConnections) {
    const neu = nextConnections.find((item) => item.id === old.id)
    if (!neu) {
      ids.push(old.id)
      continue
    }
    if (neu.enabled === false && old.enabled !== false) {
      ids.push(old.id)
      continue
    }
    if (!!(neu.conn && neu.conn.sim) && !(old.conn && old.conn.sim)) {
      ids.push(old.id)
      continue
    }
    if (endpointFingerprint(toEndpoint(old)) !== endpointFingerprint(toEndpoint(neu))) ids.push(old.id)
  }
  return ids
}

/**
 * @param {unknown} cwd
 * @param {unknown} ids
 * @param {{ transport?: ReturnType<typeof createModbusTransport> }} [extra]
 */
export function notifyConnectionRelease(cwd, ids, extra = {}) {
  const list = Array.isArray(ids) ? ids.filter(Boolean) : []
  if (!cwd || !list.length) return
  const transport = extra.transport || createModbusTransport()
  for (const id of list) {
    forgetSimConnection(cwd, id)
    void transport.releaseConnection({ cwd, connectionId: id }).catch(() => {})
  }
}

/**
 * @param {{ broker?: ReturnType<typeof getCornIoBroker> }} [options]
 */
export function createModbusTransport({ broker = getCornIoBroker() } = {}) {
  /**
   * @param {Record<string, unknown>} payload
   * @param {Record<string, unknown>} [opts]
   */
  const call = async (payload, opts) => {
    const body =
      payload && typeof payload === 'object' ? (payload.id ? payload : { ...payload, id: nextReqId() }) : payload
    const checked = validateIoRequest(body)
    if (!checked.ok) return { ok: false, error: checked.error }
    try {
      const ran = await broker.request(body, opts)
      if (ran && ran.ok === false) {
        return {
          ok: false,
          error: ran.error,
          frames: ran.frames,
          transactionId: ran.transactionId,
          durationMs: ran.durationMs,
        }
      }
      return ran
    } catch (error) {
      const thrown = thrownIo(error)
      return {
        ok: false,
        error: thrown.code ? thrown.raw : ioError('IO_RUNTIME_UNAVAILABLE', String(thrown.message || error)),
        frames: thrown.frames,
        transactionId: thrown.transactionId,
        durationMs: thrown.durationMs,
      }
    }
  }

  return {
    toEndpoint,
    endpointFingerprint,
    toReadRequest,
    toWriteRequest,
    async health() {
      return broker.health()
    },
    /**
     * @param {Record<string, unknown>} request
     * @param {Record<string, unknown>} [opts]
     */
    async read(request, opts = {}) {
      const req = asRequest(request)
      const options = asOpts(opts)
      if (options.sim || req.endpoint?.sim) {
        const t0 = nowMs()
        const data = overlaySimRead(req, simRaw({ address: req.address, count: req.count }, req.functionCode))
        return {
          ok: true,
          data,
          durationMs: Math.max(0, Math.round(nowMs() - t0)),
          transactionId: nextSimTx(),
          frames: {
            requestHex: '',
            responseHex: '',
            frameFormat: req.endpoint && req.endpoint.mode === 'tcp' ? 'tcp-normalized' : 'rtu-adu',
            request: 'SIM TX ' + req.functionCode + '@' + req.address + '×' + req.count,
            response: 'SIM RX ' + data.slice(0, 3).join(','),
          },
        }
      }
      return call(request, opts)
    },
    /**
     * @param {Record<string, unknown>} request
     * @param {Record<string, unknown>} [opts]
     */
    async write(request, opts = {}) {
      const req = asRequest(request)
      const options = asOpts(opts)
      if (options.sim || req.endpoint?.sim) {
        const t0 = nowMs()
        rememberSimWrite(req)
        return {
          ok: true,
          data: req.values,
          durationMs: Math.max(0, Math.round(nowMs() - t0)),
          transactionId: nextSimTx(),
          frames: {
            requestHex: '',
            responseHex: '',
            frameFormat: req.endpoint && req.endpoint.mode === 'tcp' ? 'tcp-normalized' : 'rtu-adu',
            request: 'SIM TX ' + req.functionCode + '@' + req.address,
            response: 'SIM RX ' + (Array.isArray(req.values) ? req.values.join(',') : ''),
          },
        }
      }
      return call(request, opts)
    },
    /**
     * @param {Record<string, unknown>} request
     * @param {Record<string, unknown>} [opts]
     */
    async openConnection(request, opts = {}) {
      return call({ v: 1, op: 'connection.open', ...request }, opts)
    },
    /**
     * @param {Record<string, unknown>} request
     * @param {Record<string, unknown>} [opts]
     */
    async closeConnection(request, opts = {}) {
      const state = broker && typeof broker.getState === 'function' ? broker.getState() : ''
      if (!state || state === 'idle' || state === 'stopped' || state === 'stopping') {
        return { ok: true, skipped: true, data: { state: 'disconnected' } }
      }
      return call({ v: 1, op: 'connection.close', cwd: request.cwd, connectionId: request.connectionId }, opts)
    },
    /**
     * @param {Record<string, unknown>} request
     * @param {Record<string, unknown>} [opts]
     */
    async listConnections(request, opts = {}) {
      const state = broker && typeof broker.getState === 'function' ? broker.getState() : ''
      if (!state || state === 'idle' || state === 'stopped') {
        return { ok: true, data: { connections: [] } }
      }
      return call({ v: 1, op: 'connection.status', cwd: request.cwd, connectionId: request.connectionId || '' }, opts)
    },
    /**
     * @param {Record<string, unknown>} request
     * @param {Record<string, unknown>} [opts]
     */
    async captureFeed(request, opts = {}) {
      const state = broker && typeof broker.getState === 'function' ? broker.getState() : ''
      if (!state || state === 'idle' || state === 'stopped') {
        return { ok: true, data: { open: false, lines: [], lastId: 0 } }
      }
      return call(
        {
          v: 1,
          op: 'serial.capture.feed',
          cwd: request.cwd,
          connectionId: request.connectionId || '',
          since: request.since,
          max: request.max,
        },
        opts,
      )
    },
    /**
     * @param {Record<string, unknown>} request
     * @param {Record<string, unknown>} [opts]
     */
    async releaseConnection(request, opts = {}) {
      return this.closeConnection(request, opts)
    },
    brokerState() {
      return broker && typeof broker.getState === 'function' ? broker.getState() : 'idle'
    },
    async stop() {
      if (broker && typeof broker.stop === 'function') await broker.stop()
    },
  }
}
