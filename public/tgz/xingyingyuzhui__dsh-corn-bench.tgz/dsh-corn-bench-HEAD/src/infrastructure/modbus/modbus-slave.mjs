// @ts-check
import { createServer } from 'node:net'
import { applyPointWrite, segmentCovering, simulateRaw } from '../../domain/modbus/point-legacy-segments.mjs'

/**
 * @typedef {{ id?: string, function?: number, address?: number, count?: number }} SlaveSegment
 * @typedef {{ segmentId?: string, address?: number, value?: number | boolean | null }} SlaveValue
 * @typedef {{
 *   id?: string,
 *   host?: string,
 *   tcpPort?: number,
 *   role?: string,
 *   listen?: boolean,
 *   mode?: string,
 *   sim?: boolean,
 *   segments?: SlaveSegment[],
 *   values?: SlaveValue[],
 *   listening?: boolean,
 *   listenError?: string,
 * }} SlaveDevice
 * @typedef {(fn: number, address: number, values: number[], at: number) => void} SlaveWrite
 * @typedef {import('node:net').Server & {
 *   dshHost: string,
 *   dshPort: number,
 *   dshGet: (() => SlaveDevice | null | undefined) | null,
 *   dshOnWrite: SlaveWrite | null,
 *   dshSockets: Set<import('node:net').Socket>,
 * }} SlaveServer
 * @typedef {{ devices?: SlaveDevice[], activeId?: string }} SlaveModbus
 */

// Task6: stable frameId/transactionId - slave also generates rich frame fields for Task6
export const SCHEMA_VERSION = 3
/**
 * @param {unknown} trans
 * @param {unknown} unit
 * @param {unknown} at
 */
const genFrameId = (trans, unit, at) => `slave:${trans}:${unit}:${at}`
/** @param {unknown} trans @param {unknown} unit */
const genTxId = (trans, unit) => `tx-slave:${trans}:${unit}`

/** @type {Map<string, SlaveServer>} */
const servers = new Map()
/** @type {Map<string, string>} */
const listenErrors = new Map()

/**
 * @param {unknown} error
 * @returns {string}
 */
function thrownText(error) {
  if (error && typeof error === 'object' && 'message' in error) {
    const message = /** @type {{ message?: unknown }} */ (error).message
    return String(message || error)
  }
  return String(error)
}

/** @param {import('node:net').Server} server @returns {SlaveServer} */
function asSlaveServer(server) {
  return /** @type {SlaveServer} */ (server)
}

/** @param {unknown} cwd @param {unknown} deviceId */
const keyOf = (cwd, deviceId) => String(cwd) + ':' + String(deviceId)

/** @param {Buffer} buf @param {number} offset */
const u16 = (buf, offset) => buf.readUInt16BE(offset)

/** @param {number} fc @param {number} code */
const exception = (fc, code) => Buffer.from([fc | 0x80, code])

/**
 * @param {SlaveDevice} device
 * @param {number} fn
 * @param {number} at
 */
const bankOf = (device, fn, at) => {
  /** @type {Map<number, number | boolean>} */
  const values = new Map()
  const segments = Array.isArray(device.segments) ? device.segments : []
  for (const segment of segments) {
    if (Number(segment.function) !== fn) continue
    const recs = Array.isArray(device.values) ? device.values : []
    const raw = device.sim ? simulateRaw(segment, at) : null
    const count = /** @type {number} */ (segment.count)
    const base = /** @type {number} */ (segment.address)
    for (let i = 0; i < count; i++) {
      const address = base + i
      const rec = recs.find((item) => item.segmentId === segment.id && item.address === address)
      /** @type {number | boolean} */
      let value = 0
      if (raw) value = raw[i]
      else if (rec && rec.value !== null && rec.value !== undefined) value = rec.value
      values.set(address, value)
    }
  }
  return values
}

/**
 * @param {Map<number, number | boolean>} bank
 * @param {number} addr
 * @param {number} qty
 */
const readBits = (bank, addr, qty) => {
  const bytes = Math.ceil(qty / 8)
  const out = Buffer.alloc(2 + bytes)
  out[0] = 1
  out[1] = bytes
  for (let i = 0; i < qty; i++) {
    const on = bank.get(addr + i) ? 1 : 0
    if (on) out[2 + (i >> 3)] |= 1 << (i & 7)
  }
  return out
}

/**
 * @param {Map<number, number | boolean>} bank
 * @param {number} addr
 * @param {number} qty
 * @param {number} fc
 */
const readRegs = (bank, addr, qty, fc) => {
  const out = Buffer.alloc(2 + qty * 2)
  out[0] = fc
  out[1] = qty * 2
  for (let i = 0; i < qty; i++) {
    const n = Number(bank.get(addr + i) || 0) & 0xffff
    out.writeUInt16BE(n, 2 + i * 2)
  }
  return out
}

/**
 * @param {SlaveDevice} device
 * @param {Buffer} pdu
 * @param {number} [at]
 * @param {SlaveWrite | null} [onWrite]
 */
export const handlePdu = (device, pdu, at = Date.now(), onWrite = null) => {
  if (!pdu || pdu.length < 1) return exception(0, 1)
  const fc = pdu[0]
  if (fc === 5 || fc === 6) {
    if (pdu.length < 5) return exception(fc, 3)
    const addr = u16(pdu, 1)
    const raw = u16(pdu, 3)
    const value = fc === 5 ? (raw === 0xff00 ? 1 : raw === 0x0000 ? 0 : -1) : raw
    if (value < 0) return exception(fc, 3)
    return writePoints(device, fc, addr, [value], at, onWrite, raw)
  }
  if (fc === 15 || fc === 16) {
    if (pdu.length < 6) return exception(fc, 3)
    const addr = u16(pdu, 1)
    const qty = u16(pdu, 3)
    const byteCount = pdu[5]
    if (qty < 1) return exception(fc, 3)
    if (fc === 15 && qty > 1968) return exception(fc, 3)
    if (fc === 16 && qty > 123) return exception(fc, 3)
    if (byteCount !== (fc === 15 ? Math.ceil(qty / 8) : qty * 2)) return exception(fc, 3)
    if (pdu.length < 6 + byteCount) return exception(fc, 3)
    const values = []
    for (let i = 0; i < qty; i++) {
      if (fc === 15) values.push((pdu[6 + (i >> 3)] >> (i & 7)) & 1)
      else values.push(u16(pdu, 6 + i * 2))
    }
    return writePoints(device, fc, addr, values, at, onWrite, qty)
  }
  if (pdu.length < 5) return exception(fc, 3)
  const addr = u16(pdu, 1)
  const qty = u16(pdu, 3)
  if (qty < 1 || qty > 125) return exception(fc, 3)
  if (fc === 1 || fc === 2) return readBits(bankOf(device, fc, at), addr, qty)
  if (fc === 3 || fc === 4) return readRegs(bankOf(device, fc, at), addr, qty, fc)
  return exception(fc, 1)
}

/**
 * @param {SlaveDevice} device
 * @param {number} fc
 * @param {number} address
 * @param {number[]} values
 * @param {number} at
 * @param {SlaveWrite | null} onWrite
 * @param {number} echoWord
 */
const writePoints = (device, fc, address, values, at, onWrite, echoWord) => {
  const fn = fc === 5 || fc === 15 ? 1 : 3
  const segments = Array.isArray(device.segments) ? device.segments : []
  for (let i = 0; i < values.length; i++) {
    if (!segmentCovering(segments, fn, address + i)) return exception(fc, 2)
  }
  if (typeof onWrite === 'function') onWrite(fn, address, values, at)
  const out = Buffer.alloc(5)
  out[0] = fc
  out.writeUInt16BE(address, 1)
  out.writeUInt16BE(echoWord & 0xffff, 3)
  return out
}

/**
 * @param {number} trans
 * @param {number} unit
 * @param {Buffer} pdu
 */
const frameResponse = (trans, unit, pdu) => {
  const out = Buffer.alloc(7 + pdu.length)
  out.writeUInt16BE(trans, 0)
  out.writeUInt16BE(0, 2)
  out.writeUInt16BE(1 + pdu.length, 4)
  out[6] = unit
  pdu.copy(out, 7)
  return out
}

/**
 * @param {unknown} cwd
 * @param {SlaveDevice} device
 * @param {(() => SlaveDevice | null | undefined) | null} getDevice
 * @param {SlaveWrite | null} [onWrite]
 */
export const startDeviceSlave = (cwd, device, getDevice, onWrite = null) => {
  const id = keyOf(cwd, device.id)
  const host = device.host || '127.0.0.1'
  const port = Number(device.tcpPort) || 1502
  const prev = servers.get(id)
  if (prev && prev.dshHost === host && prev.dshPort === port && prev.listening) {
    prev.dshGet = getDevice
    prev.dshOnWrite = onWrite
    listenErrors.delete(id)
    return Promise.resolve({ ok: true, host, port, deviceId: device.id, reused: true })
  }
  if (prev) {
    closeServer(prev)
    servers.delete(id)
  }
  const server = asSlaveServer(createServer((socket) => {
    server.dshSockets.add(socket)
    socket.on('close', () => {
      server.dshSockets.delete(socket)
    })
    let buf = Buffer.alloc(0)
    socket.on('data', (/** @type {Buffer} */ chunk) => {
      buf = Buffer.concat([buf, chunk])
      while (buf.length >= 8) {
        const len = buf.readUInt16BE(4)
        if (len < 2 || buf.length < 6 + len) break
        const trans = buf.readUInt16BE(0)
        const unit = buf[6]
        const pdu = buf.subarray(7, 6 + len)
        buf = buf.subarray(6 + len)
        const getter = server.dshGet || getDevice
        const current = typeof getter === 'function' ? getter() : device
        // The device vanished (removed/role changed): never answer with stale
        // data — drop the connection so the master reconnects or errors out.
        if (!current) {
          socket.destroy()
          return
        }
        const resp = handlePdu(current, pdu, Date.now(), server.dshOnWrite)
        socket.write(frameResponse(trans, unit, resp))
      }
    })
    socket.on('error', () => {
      /* drop */
    })
  }))
  server.dshHost = host
  server.dshPort = port
  server.dshGet = getDevice
  server.dshOnWrite = onWrite
  server.dshSockets = new Set()
  return new Promise((resolve, reject) => {
    server.once('error', reject)
    server.listen(port, host, () => {
      listenErrors.delete(id)
      servers.set(id, server)
      resolve({ ok: true, host, port, deviceId: device.id })
    })
  })
}

/** @param {SlaveServer} server */
const closeServer = (server) => {
  try {
    server.close()
  } catch {
    /* already closed */
  }
  for (const socket of server.dshSockets || []) {
    try {
      socket.destroy()
    } catch {
      /* ignore */
    }
  }
}

/** @param {unknown} cwd @param {unknown} deviceId */
export const stopDeviceSlave = (cwd, deviceId) => {
  const id = keyOf(cwd, deviceId)
  const server = servers.get(id)
  if (!server) return
  closeServer(server)
  servers.delete(id)
  listenErrors.delete(id)
}

export const stopAllSlaves = () => {
  for (const server of servers.values()) {
    closeServer(server)
  }
  servers.clear()
  listenErrors.clear()
}

/**
 * @param {unknown} cwd
 * @param {{ modbus?: SlaveModbus }} workspace
 */
export const withListenRuntime = (cwd, workspace) => {
  const modbus = workspace && workspace.modbus && typeof workspace.modbus === 'object' ? workspace.modbus : {}
  const devices = Array.isArray(modbus.devices)
    ? modbus.devices.map((item) => {
        if (item.role !== 'slave' || !item.listen) return { ...item, listening: false, listenError: '' }
        const id = keyOf(cwd, item.id)
        const server = servers.get(id)
        const listening = !!(server && server.listening)
        const err = listenErrors.get(id) || ''
        return { ...item, listening, listenError: listening ? '' : err || '未监听' }
      })
    : []
  const active = devices.find((item) => item.id === modbus.activeId) || devices[0]
  return {
    ...workspace,
    modbus: {
      ...modbus,
      devices,
      listening: !!(active && active.listening),
      listenError: active && active.listenError ? active.listenError : '',
    },
  }
}

/**
 * @param {unknown} cwd
 * @param {SlaveModbus | null | undefined} modbus
 * @param {(() => SlaveModbus | null | undefined) | null | undefined} getModbus
 * @param {((deviceId: unknown, fn: number, address: number, values: number[], at: number) => void) | null} [onWrite]
 */
export const syncDeviceSlaves = async (cwd, modbus, getModbus, onWrite = null) => {
  const devices = modbus && Array.isArray(modbus.devices) ? modbus.devices : []
  const want = new Set()
  const errors = []
  for (const device of devices) {
    if (device.role !== 'slave' || !device.listen || device.mode !== 'tcp') continue
    want.add(device.id)
    try {
      await startDeviceSlave(
        cwd,
        device,
        () => {
          const live = getModbus ? getModbus() : modbus
          const list = live && Array.isArray(live.devices) ? live.devices : []
          return list.find((item) => item.id === device.id) || device
        },
        onWrite ? (fn, address, values, at) => onWrite(device.id, fn, address, values, at) : null,
      )
      listenErrors.delete(keyOf(cwd, device.id))
    } catch (error) {
      const message = thrownText(error).slice(0, 180)
      listenErrors.set(keyOf(cwd, device.id), message)
      errors.push(message)
    }
  }
  for (const [id, server] of servers) {
    if (!String(id).startsWith(String(cwd) + ':')) continue
    const deviceId = id.slice(String(cwd).length + 1)
    if (want.has(deviceId)) continue
    closeServer(server)
    servers.delete(id)
    listenErrors.delete(id)
  }
  return { ok: errors.length === 0, error: errors[0] || '', errors }
}

export const _internal = { handlePdu, servers, listenErrors, keyOf }
