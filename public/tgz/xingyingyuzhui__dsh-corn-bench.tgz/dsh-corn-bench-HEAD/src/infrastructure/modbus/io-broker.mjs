// @ts-check
import { spawn } from 'node:child_process'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { capabilitiesFromHealth, idleIoSnapshot } from '../../domain/modbus/io-capability.mjs'
import {
  IO_HANDSHAKE_MS,
  IO_MAX_LINE,
  IO_PROTOCOL_V,
  IO_RUNTIME_PACKAGES,
  clampTimeoutMs,
  decodeNdjsonLine,
  encodeNdjson,
  ioError,
  sanitizeIoError,
} from '../../domain/modbus/io-contract.mjs'
import { killProcessTree } from '../process/run-command.mjs'
import { asMessage, settlePending, thrownText } from './io-broker-settle.mjs'

/** @typedef {import('../../types/io-broker.d.ts').IoWorkerProcess} IoWorkerProcess */
/** @typedef {import('../../types/io-broker.d.ts').IoMessage} IoMessage */
/** @typedef {import('../../types/io-broker.d.ts').PendingEntry} PendingEntry */
/** @typedef {import('../../types/io-broker.d.ts').IoErrorShape} IoErrorShape */
/** @typedef {import('../../types/io-broker.d.ts').IoRequestOpts} IoRequestOpts */
/** @typedef {import('../../types/io-broker.d.ts').IoBrokerOptions} IoBrokerOptions */

const DEFAULT_WORKER = join(dirname(fileURLToPath(import.meta.url)), '../../../runtime/corn-io-worker.mjs')
/** Driver timeout and this deadline used to be equal, so the broker cancel closed the shared port before the driver could report MODBUS_TIMEOUT. */
export const BROKER_GRACE_MS = 1500
const OUTBOUND_CAP = 32
const RESTART_WINDOW_MS = 60_000
const STDERR_CAP = 4000

/** @param {IoBrokerOptions} [options] */
export function createCornIoBroker(options = {}) {
  const workerPath = options.workerPath || DEFAULT_WORKER
  const execPath = options.execPath || process.execPath
  const env = options.env || process.env
  let child = /** @type {IoWorkerProcess | null} */ (null)
  let state = 'idle'
  let workerEpoch = 0
  let seq = 0
  let stdoutBuf = ''
  let stderrTail = ''
  let lastError = /** @type {IoErrorShape | null} */ (null)
  let cachedCaps = idleIoSnapshot().capabilities
  const pending = /** @type {Map<string, PendingEntry>} */ (new Map())
  const startingQueue = /** @type {PendingEntry[]} */ ([])
  const outbound = /** @type {string[]} */ ([])
  let draining = false
  let lastCrashAt = 0
  let healthCache = /** @type {Record<string, unknown> | null} */ (null)
  let stopping = /** @type {Promise<void> | null} */ (null)

  const nextId = () => 'req-' + Date.now().toString(36) + '-' + ++seq

  const writeStdin = (/** @type {Record<string, unknown>} */ obj) => {
    if (!child || !child.stdin || child.stdin.destroyed) return false
    const line = encodeNdjson(obj)
    if (draining || outbound.length) {
      if (outbound.length >= OUTBOUND_CAP) return false
      outbound.push(line)
      return true
    }
    let ok = true
    try {
      ok = child.stdin.write(line)
    } catch {
      return false
    }
    if (!ok) {
      draining = true
      child.stdin.once('drain', () => {
        draining = false
        while (outbound.length && child && child.stdin && !child.stdin.destroyed) {
          const next = /** @type {string} */ (outbound.shift())
          let more = true
          try {
            more = child.stdin.write(next)
          } catch {
            break
          }
          if (!more) {
            draining = true
            child.stdin.once('drain', () => {
              draining = false
            })
            break
          }
        }
      })
    }
    return true
  }

  const sendCancel = (/** @type {string} */ targetId) => {
    if (!targetId) return
    writeStdin({ v: IO_PROTOCOL_V, id: nextId(), op: 'cancel', targetId })
  }

  const failAll = (/** @type {unknown} */ error, withCancel = false) => {
    const err = sanitizeIoError(error)
    lastError = err
    for (const [id, entry] of pending) {
      pending.delete(id)
      if (withCancel) sendCancel(id)
      settlePending(entry, { ok: false, error: err })
    }
    const queued = startingQueue.splice(0)
    for (const item of queued) item.reject(err)
    outbound.length = 0
  }

  const handleLine = (/** @type {string} */ line) => {
    const parsed = decodeNdjsonLine(line)
    if (!parsed.ok) {
      killWorker(ioError('PROTOCOL_VIOLATION', parsed.error.message))
      return
    }
    const msg = asMessage(parsed.value)
    if (!msg || typeof msg.id !== 'string') return
    const entry = pending.get(msg.id)
    if (!entry) return
    pending.delete(msg.id)
    if (msg.ok === true) {
      settlePending(entry, { ok: true, ...msg })
    } else {
      settlePending(entry, {
        ok: false,
        error: sanitizeIoError(msg.error),
        frames: msg.frames,
        transactionId: msg.transactionId,
        durationMs: msg.durationMs,
      })
    }
  }

  const onStdout = (/** @type {unknown} */ chunk) => {
    stdoutBuf += String(chunk || '')
    let idx
    while ((idx = stdoutBuf.indexOf('\n')) >= 0) {
      const line = stdoutBuf.slice(0, idx)
      stdoutBuf = stdoutBuf.slice(idx + 1)
      if (Buffer.byteLength(line) > IO_MAX_LINE) {
        killWorker(ioError('PROTOCOL_VIOLATION', '报文超过 64 KiB'))
        return
      }
      handleLine(line)
    }
    if (Buffer.byteLength(stdoutBuf) > IO_MAX_LINE) {
      killWorker(ioError('PROTOCOL_VIOLATION', '报文超过 64 KiB'))
    }
  }

  const killWorker = (/** @type {unknown} */ error) => {
    const childRef = child
    child = null
    state = error ? 'unhealthy' : 'stopped'
    lastError = sanitizeIoError(error || ioError('IO_RUNTIME_CRASHED', 'I/O 运行时已停止'))
    cachedCaps = {
      modbusTcp: 'unavailable',
      modbusRtu: 'unavailable',
      serialMonitor: 'unavailable',
    }
    failAll(lastError)
    if (childRef && childRef.pid) killProcessTree(childRef.pid)
    healthCache = null
  }

  const spawnWorker = () =>
    new Promise((resolve, reject) => {
      if (state === 'ready' && child) {
        resolve(healthCache)
        return
      }
      if (state === 'unhealthy' && Date.now() - lastCrashAt < RESTART_WINDOW_MS) {
        reject(ioError('IO_RUNTIME_UNAVAILABLE', 'I/O 运行时熔断中'))
        return
      }
      state = 'starting'
      workerEpoch += 1
      const epoch = workerEpoch
      let proc = /** @type {IoWorkerProcess | undefined} */ (undefined)
      try {
        proc = /** @type {IoWorkerProcess} */ (spawn(execPath, [workerPath], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true, env }))
      } catch (error) {
        state = 'unhealthy'
        lastCrashAt = Date.now()
        lastError = ioError('IO_RUNTIME_UNAVAILABLE', thrownText(error))
        reject(lastError)
        return
      }
      child = proc
      proc.stdin.on('error', (error) => {
        if (workerEpoch !== epoch) return
        lastError = ioError('IO_RUNTIME_UNAVAILABLE', thrownText(error))
        killWorker(lastError)
      })
      if (typeof options.onWorker === 'function') options.onWorker(proc)
      stdoutBuf = ''
      stderrTail = ''
      draining = false
      outbound.length = 0
      proc.stdout.setEncoding('utf8')
      proc.stdout.on('data', onStdout)
      proc.stderr.setEncoding('utf8')
      proc.stderr.on('data', (/** @type {unknown} */ chunk) => {
        stderrTail = (stderrTail + String(chunk || '')).slice(-STDERR_CAP)
      })
      proc.on('error', (error) => {
        if (workerEpoch !== epoch) return
        lastCrashAt = Date.now()
        lastError = ioError('IO_RUNTIME_UNAVAILABLE', thrownText(error))
        killWorker(lastError)
      })
      proc.on('exit', () => {
        if (workerEpoch !== epoch) return
        lastCrashAt = Date.now()
        killWorker(ioError('IO_RUNTIME_CRASHED', 'I/O 运行时退出'))
      })
      const handshakeId = 'health-' + epoch
      const timer = setTimeout(() => {
        pending.delete(handshakeId)
        lastCrashAt = Date.now()
        lastError = ioError('IO_RUNTIME_UNAVAILABLE', 'I/O 运行时握手超时')
        killWorker(lastError)
        reject(lastError)
      }, IO_HANDSHAKE_MS)
      pending.set(handshakeId, {
        resolve: (value) => {
          const msg = asMessage(value)
          clearTimeout(timer)
          const data = msg && msg.data ? msg.data : {}
          if (Number(data.protocol) !== IO_PROTOCOL_V || Number(msg.v) !== IO_PROTOCOL_V) {
            lastCrashAt = Date.now()
            lastError = ioError('PROTOCOL_VIOLATION', '协议版本不符')
            killWorker(lastError)
            reject(lastError)
            return
          }
          healthCache = data
          cachedCaps = capabilitiesFromHealth(data)
          lastError = null
          state = 'ready'
          resolve(data)
          const queued = startingQueue.splice(0)
          for (const item of queued) item.resolve()
        },
        reject: (/** @type {unknown} */ error) => {
          clearTimeout(timer)
          lastCrashAt = Date.now()
          state = 'unhealthy'
          lastError = sanitizeIoError(error)
          reject(lastError)
        },
        timer,
        abortCleanup: () => {},
        workerEpoch: epoch,
        settled: false,
      })
      if (!writeStdin({ v: IO_PROTOCOL_V, id: handshakeId, op: 'health' })) {
        clearTimeout(timer)
        pending.delete(handshakeId)
        lastCrashAt = Date.now()
        lastError = ioError('IO_RUNTIME_UNAVAILABLE', '无法写入 I/O 运行时')
        killWorker(lastError)
        reject(lastError)
      }
    })

  const ensureReady = () => {
    if (state === 'ready' && child) return Promise.resolve(healthCache)
    if (state === 'starting') {
      return new Promise((resolve, reject) => {
        if (startingQueue.length >= OUTBOUND_CAP) {
          reject(ioError('IO_BACKPRESSURE', 'I/O 运行时正忙'))
          return
        }
        startingQueue.push({
          resolve: () => resolve(healthCache),
          reject,
        })
      })
    }
    return spawnWorker()
  }

  const request = async (/** @type {Record<string, unknown>} */ payload, /** @type {IoRequestOpts} */ opts = {}) => {
    await ensureReady()
    if (state !== 'ready' || !child) {
      throw ioError('IO_RUNTIME_UNAVAILABLE', 'I/O 运行时不可用')
    }
    if (pending.size >= OUTBOUND_CAP) {
      throw ioError('IO_BACKPRESSURE', 'I/O 队列已满')
    }
    const id = /** @type {string} */ (payload.id || nextId())
    const timeoutMs = clampTimeoutMs(opts.timeoutMs, payload.timeoutMs || 8000) + BROKER_GRACE_MS
    const signal = opts.signal
    const epoch = workerEpoch
    return new Promise((resolve, reject) => {
      let cancelSent = false
      const sendCancelOnce = () => {
        if (cancelSent) return
        cancelSent = true
        sendCancel(id)
      }
      const abortCleanup = () => {
        if (signal) signal.removeEventListener('abort', onAbort)
      }
      const finish = (/** @type {string} */ error, /** @type {string} */ code) => {
        if (entry.settled) return
        pending.delete(id)
        sendCancelOnce()
        settlePending(entry, { ok: false, error: ioError(code, error) })
      }
      const onAbort = () => finish('已取消', 'CANCELLED')
      const timer = setTimeout(() => finish('I/O 超时', 'MODBUS_TIMEOUT'), timeoutMs)
      const entry = {
        resolve: (/** @type {unknown} */ value) => resolve(asMessage(value)),
        reject,
        timer,
        abortCleanup,
        workerEpoch: epoch,
        settled: false,
      }
      pending.set(id, entry)
      if (signal) {
        if (signal.aborted) {
          onAbort()
          return
        }
        signal.addEventListener('abort', onAbort, { once: true })
      }
      if (!writeStdin({ v: IO_PROTOCOL_V, ...payload, id })) {
        pending.delete(id)
        settlePending(entry, { ok: false, error: ioError('IO_BACKPRESSURE', 'I/O 队列已满') })
      }
    })
  }

  const stop = async (reason = 'plugin-dispose') => {
    if (stopping) return stopping
    if (state === 'idle' || state === 'stopped') return
    state = 'stopping'
    stopping = (async () => {
      failAll(ioError('CANCELLED', 'I/O 运行时停止: ' + reason), true)
      const proc = child
      if (proc) {
        writeStdin({ v: IO_PROTOCOL_V, id: nextId(), op: 'shutdown' })
        await new Promise((resolve) => {
          const t = setTimeout(() => {
            if (proc.pid) killProcessTree(proc.pid)
            resolve(undefined)
          }, 1500)
          proc.once('exit', () => {
            clearTimeout(t)
            resolve(undefined)
          })
        })
      }
      child = null
      state = 'stopped'
      stopping = null
      cachedCaps = idleIoSnapshot().capabilities
    })()
    return stopping
  }

  return {
    request,
    sendCancel,
    async health() {
      try {
        const data = await ensureReady()
        return { ok: true, data }
      } catch (error) {
        return { ok: false, error: sanitizeIoError(error) }
      }
    },
    snapshot() {
      return {
        state,
        pid: (child && child.pid) || 0,
        protocol: IO_PROTOCOL_V,
        packages: { ...IO_RUNTIME_PACKAGES },
        capabilities: { ...cachedCaps },
        lastError,
        stderrTail: stderrTail.slice(0, STDERR_CAP),
      }
    },
    stop,
    getState: () => state,
    pendingSize: () => pending.size,
    pid: () => (child && child.pid) || 0,
  }
}

let singleton = /** @type {ReturnType<typeof createCornIoBroker> | null} */ (null)
/** @param {IoBrokerOptions & { broker?: NonNullable<typeof singleton> }} [options] */
export function getCornIoBroker(options = {}) {
  if (options.broker) return options.broker
  if (!singleton) singleton = createCornIoBroker(options)
  return singleton
}

export async function stopCornIoBroker(reason = 'plugin-dispose') {
  if (!singleton) return
  const current = singleton
  singleton = null
  await current.stop(reason)
}
