import { createCornFetchPost } from '../../infrastructure/host/corn-rpc-client.mjs'
import { subscribeFocus } from '../common/focus-store.mjs'
import { migrateLegacyStorage } from '../common/legacy-storage.mjs'
import { getActiveScope } from '../common/session-scope.mjs'
import { createHmiView } from '../hmi/hmi-page.mjs'
import { COPY, NS } from '../i18n/copy.mjs'
import { interpolate, tWith } from '../i18n/translate.mjs'
import { createSettingsPage } from '../settings/settings-page.mjs'
import { registerSettings } from '../settings/register-settings.mjs'
import { ATTR, CSS } from '../styles/index.mjs'
import { wrapCornPage } from '../workspace/corn-page-boundary.mjs'
import { MONITOR_SECTIONS, VIEW_HMI, VIEW_MONITOR } from '../workspace/corn-route.mjs'
import { requestOpenView, requestOpenViewFromScope, routeAgentFocus } from '../workspace/corn-view-request.mjs'
import { createDebugWorkspace } from '../workspace/debug-workspace.mjs'
import { createMonitorWorkspace } from '../workspace/monitor-workspace.mjs'
import { registerView } from './register-view.mjs'

export function apply(ctx) {
  if (!ctx.connection) {
    throw new Error('dsh-corn-bench: Client requires ctx.connection')
  }

  if (typeof window !== 'undefined') migrateLegacyStorage(window.localStorage)

  const React = require('react')
  const slots = ctx.slots
  if (slots == null || React == null) return

  const doc = typeof document === 'undefined' ? null : document
  let styleTag = null
  if (doc && doc.head) {
    styleTag = doc.createElement('style')
    styleTag.setAttribute(ATTR, '')
    // Vendor CSS (gridstack) is injected by the build as DvbVendorCss.
    styleTag.textContent = CSS + (typeof DvbVendorCss === 'string' ? '\n' + DvbVendorCss : '')
    doc.head.appendChild(styleTag)
    doc.body.setAttribute(ATTR, '')
  }

  let localeDispose = function () {}
  if (ctx.locale) {
    if (typeof ctx.locale.register !== 'function') {
      throw new Error('dsh-corn-bench: injected locale is missing register()')
    }
    localeDispose = ctx.locale.register(NS, COPY) || function () {}
  }

  function t(key, params) {
    return interpolate(tWith(ctx, key, params), params)
  }
  const localeSubscribe =
    ctx.locale && typeof ctx.locale.subscribe === 'function' ? (fn) => ctx.locale.subscribe(fn) : null

  // Stage 1: shared Connection Fetch (Web + Desktop). Relative /api path; no localhost.
  const post = createCornFetchPost()

  function openHmi(target) {
    requestOpenViewFromScope(VIEW_HMI, { section: '', target: target || {}, source: 'manual' })
  }

  function openFrames() {
    requestOpenViewFromScope(VIEW_MONITOR, {
      section: MONITOR_SECTIONS.FRAMES,
      source: 'manual',
    })
  }

  const localeHooks = { localeSubscribe }
  const SettingsPage = createSettingsPage(React, t, post, { getScope: getActiveScope })
  const DebugWorkspace = wrapCornPage(React, createDebugWorkspace(React, t, post, localeHooks), 'debug', t)
  const HmiView = wrapCornPage(React, createHmiView(React, t, post), 'hmi', t)
  const MonitorWorkspace = wrapCornPage(
    React,
    createMonitorWorkspace(React, t, post, { openHmi, openFrames, ...localeHooks }),
    'monitor',
    t,
  )
  const stopSettings = registerSettings(ctx, React, t, SettingsPage)
  const stopView = registerView(ctx, React, t, DebugWorkspace, HmiView, MonitorWorkspace)

  const lastRouteKeyBySession = new Map()
  const applyFocus = (fs, changedCwd) => {
    const routed = routeAgentFocus(fs, changedCwd, lastRouteKeyBySession)
    if (routed.action === 'open') {
      requestOpenView(routed.props, routed.request.viewId, routed.request)
    }
  }
  const focusUnsub = subscribeFocus('', (fs, cwd) => applyFocus(fs, cwd))

  ctx.effect(() => {
    return function () {
      try {
        focusUnsub()
      } catch {}
      localeDispose()
      if (typeof stopSettings === 'function') stopSettings()
      if (typeof stopView === 'function') stopView()
      if (styleTag != null) styleTag.remove()
      if (doc) doc.body.removeAttribute(ATTR)
    }
  })
}

apply.inject = ['slots', 'locale', 'connection']
