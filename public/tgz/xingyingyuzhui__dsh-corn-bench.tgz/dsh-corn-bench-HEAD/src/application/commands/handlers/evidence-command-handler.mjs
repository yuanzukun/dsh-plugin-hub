// @ts-check
import { ERROR_CODES } from '../../../domain/modbus/errors.mjs'
import { appendEvidence } from '../../modbus/evidence-append-service.mjs'
import { buildEvidenceRefs } from '../../modbus/evidence-service.mjs'
import { listFrames, requestFocus } from '../../modbus/index.mjs'
import { focusGet, timelineList } from '../agent-observe-queries.mjs'

/**
 * @param {any} home
 * @param {any} args
 * @param {any} room
 * @param {any} origin
 * @param {any} _opts
 * @returns {Promise<object | null>}
 */
export async function handleEvidenceCommand(home, args, room, origin, _opts) {
  const action = args?.action

  if (action === 'frames') {
    const cid =
      typeof args.connectionId === 'string'
        ? args.connectionId
        : typeof args.connId === 'string'
          ? args.connId
          : undefined
    const did = typeof args.deviceId === 'string' ? args.deviceId : undefined
    const fid = typeof args.frameId === 'string' ? args.frameId : typeof args.id === 'string' ? args.id : undefined
    const ran = listFrames(home, room.cwd, {
      source: origin.source,
      sessionId: origin.sessionId,
      connectionId: cid,
      connId: cid,
      deviceId: did,
      frameId: fid,
      limit: args.limit,
      offset: args.offset,
    })
    return { action, ...ran }
  }

  if (action === 'focus.get') {
    return focusGet(home, room.cwd, origin)
  }

  if (action === 'timeline.list') {
    return timelineList(home, room.cwd, args, origin)
  }

  if (action === 'focus') {
    const target = args.target ||
      args.focus || {
        connectionId: args.connectionId || args.connId,
        deviceId: args.deviceId,
        pointId: args.pointId,
        frameId: args.frameId,
        trendKey: args.trendKey,
        alarmId: args.alarmId,
        visualizationId: args.visualizationId,
        kind: args.kind,
      }
    const ran = await requestFocus(
      home,
      room.cwd,
      {
        target,
        tempWatchIds: args.tempWatchIds || args.tempWatch,
        evidence: args.evidence,
        badgeOnly: args.badgeOnly,
        foreground: args.foreground,
      },
      { source: origin.source, sessionId: origin.sessionId },
    )
    return { action, ...ran }
  }

  if (action === 'evidence') {
    for (const field of ['kind', 'id']) {
      if (args[field] != null && args[field] !== '') {
        return {
          ok: false,
          action,
          errorCode: ERROR_CODES.INVALID_FIELD,
          error: `${field} 不适用于 evidence 顶层`,
          hint: '查事件用 timeline.list；追加证据用 evidence:[{kind,id,...}]；不带 evidence 为只读列出引用',
          retryable: false,
          details: { field, action, supportedBy: ['evidence[].kind', 'evidence[].id'] },
        }
      }
    }
    const raw = args.evidence
    if (raw !== undefined && !Array.isArray(raw)) {
      return { ok: false, action, errorCode: ERROR_CODES.INVALID_FIELD, error: 'evidence 必须是数组' }
    }
    if (Array.isArray(raw) && raw.length) {
      const appended = await appendEvidence(home, room.cwd, raw, origin.sessionId)
      if (!appended.ok) return { action, ...appended }
    }
    const listed = buildEvidenceRefs(home, room.cwd, origin.sessionId)
    if (!listed.ok) return { action, ...listed }
    return { ok: true, action, evidence: listed.evidence, configVersion: listed.pack.configVersion || 1 }
  }

  return null
}
