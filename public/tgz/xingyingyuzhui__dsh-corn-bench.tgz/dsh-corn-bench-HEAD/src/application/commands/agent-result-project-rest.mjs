// @ts-check
import { createHash } from 'node:crypto'
import { AGENT_FRAMES_MAX_LIMIT, AGENT_TEXT_CAPS, utf8ByteLength } from './agent-result-caps.mjs'
import { enforceBudget, pickSafetyFields } from './agent-result-project-status-read.mjs'

const ALARM_PAGE_DEFAULT = 40

const RESULT_TOO_LARGE_HINT =
  '单条记录超过 Agent 输出上限，当前查询无法完整返回；请到 Corn UI 查看/导出该记录'

/**
 * Keep an identifier inside the error body. Extreme ids become a short fingerprint.
 * @param {string} id
 */
export function boundedRecordId(id) {
  const text = String(id || '')
  if (Buffer.byteLength(text, 'utf8') <= 96) return text
  return createHash('sha256').update(text).digest('hex').slice(0, 16)
}

/**
 * Single record does not fit the Agent output cap. The record is not consumed.
 * @param {{
 *   action: string,
 *   commandId?: string,
 *   total: number,
 *   alarmId?: string,
 *   eventId?: string,
 * }} fields
 */
export function resultTooLarge(fields) {
  /** @type {Record<string, unknown>} */
  const out = {
    ok: false,
    action: fields.action,
    errorCode: 'RESULT_TOO_LARGE',
    error: RESULT_TOO_LARGE_HINT,
    hint: RESULT_TOO_LARGE_HINT,
    overrun: true,
    truncated: true,
    retryable: false,
    returned: 0,
    nextCursor: null,
    total: fields.total,
  }
  if (fields.commandId) out.commandId = fields.commandId
  if (fields.alarmId != null) out.alarmId = boundedRecordId(fields.alarmId)
  if (fields.eventId != null) out.eventId = boundedRecordId(fields.eventId)
  return out
}

/**
 * @param {any} result
 */
/**
 * @param {any} result
 */
export function projectConfig(result) {
  const projected = {
    ...pickSafetyFields(result),
    previousConfigVersion: result.previousConfigVersion,
    nextConfigVersion: result.nextConfigVersion,
    configVersion: result.configVersion,
    changedIds: result.changedIds,
    changedPointIds: result.changedPointIds,
    changedVisualizationIds: result.changedVisualizationIds,
    affectedVisualizations: result.affectedVisualizations,
    affectedAlarms: result.affectedAlarms,
    postCommitWarnings: result.postCommitWarnings,
    layout: result.layout,
    summary: result.summary,
    connectionId: result.connectionId,
    deviceId: result.deviceId,
    published: result.published,
    revoked: result.revoked,
  }
  return enforceBudget(
    projected,
    AGENT_TEXT_CAPS.threePointConfigCommitBytes,
    'config 超预算：用 points list / visualization get 分项读取',
    (p) => ({
      ...p,
      postCommitWarnings: (p.postCommitWarnings || []).slice(0, 3),
      affectedVisualizations: (p.affectedVisualizations || []).slice(0, 8),
      affectedAlarms: (p.affectedAlarms || []).slice(0, 8),
    }),
  )
}

/**
 * @param {any} args
 * @param {any} result
 */
export function projectFrames(args, result) {
  /** @type {any[]} */
  const allFrames = Array.isArray(result.frames) ? result.frames : []
  const total = Number.isFinite(Number(result.total)) ? Number(result.total) : allFrames.length
  const requested = Number(args?.limit)
  const limit = Math.max(
    1,
    Math.min(
      AGENT_FRAMES_MAX_LIMIT,
      Number.isFinite(requested) && requested > 0 ? Math.trunc(requested) : allFrames.length || 50,
    ),
  )
  const offset = Math.max(0, Number(args?.offset) || 0)
  // `offset` is live-list pagination counted from the newest end (see listFrames);
  // it does NOT guarantee snapshot consistency during concurrent collection.
  const page = allFrames.slice(0, limit)
  const cap = AGENT_TEXT_CAPS.framesBytes

  /**
   * @param {any[]} frames
   * @param {number} returned
   * @param {string | null} nextCursor
   * @param {boolean | undefined} truncated
   * @param {Record<string, unknown>} [extra]
   */
  const build = (frames, returned, nextCursor, truncated, extra) => ({
    ...pickSafetyFields(result),
    ...extra,
    frames,
    total,
    returned,
    nextCursor,
    limit,
    connectionId: result.connectionId,
    deviceId: result.deviceId,
    configVersion: result.configVersion,
    frame: result.frame,
    stale: result.stale,
    warning: result.warning,
    truncated,
  })

  if (page.length === 0) {
    const nextCursor = offset < total ? String(offset) : null
    return build([], 0, nextCursor, nextCursor != null || undefined)
  }

  // Keep the tail continuous k so `offset+k` points at the next older batch.
  // Metadata is derived from k: returned === frames.length always.
  for (let k = page.length; k >= 1; k--) {
    const frames = page.slice(-k)
    const nextOffset = offset + k
    const nextCursor = nextOffset < total ? String(nextOffset) : null
    const truncated = nextCursor != null || page.length > k || undefined
    const projected = build(frames, k, nextCursor, truncated)
    if (utf8ByteLength(projected) <= cap) return projected
  }

  // Even one frame exceeds budget: surface frameId + target + overrun (not an empty ok page).
  const culprit = page[page.length - 1]
  const frameId = (culprit && (culprit.frameId || culprit.id)) || ''
  const skipOffset = offset + 1
  const nextCursor = skipOffset < total ? String(skipOffset) : null
  const stub = [{ frameId, id: frameId, overrun: true }]
  const extra = {
    frameId,
    overrun: true,
    hint: '单条报文超预算：用 frameId 单查',
  }
  const projected = build(stub, stub.length, nextCursor, true, extra)
  if (utf8ByteLength(projected) <= cap) return projected

  return {
    ...pickSafetyFields(result),
    connectionId: result.connectionId,
    deviceId: result.deviceId,
    configVersion: result.configVersion,
    total,
    limit,
    frames: [],
    returned: 0,
    nextCursor: skipOffset < total ? String(skipOffset) : null,
    truncated: true,
    frameId,
    overrun: true,
    hint: '单条报文超预算：用 frameId 单查',
  }
}

/**
 * Build one series with a continuous newest suffix of `keep` samples.
 * keep=0 is explicit empty — `slice(-0)` would return the entire array.
 * @param {any} series
 * @param {number} keep
 */
function buildSeriesPage(series, keep) {
  const all = Array.isArray(series.samples) ? series.samples : []
  const k = Number.isFinite(keep) && keep > 0 ? Math.trunc(keep) : 0
  const samples = k > 0 ? all.slice(-k) : []
  const count = Number(series.count) || all.length
  return {
    pointId: series.pointId,
    name: series.name,
    connectionId: series.connectionId,
    deviceId: series.deviceId,
    unit: series.unit,
    count,
    returned: samples.length,
    samples,
    hasMore: count > samples.length,
    oldestReturnedAt: samples.length ? Number(samples[0][0]) || 0 : null,
    ...(series.dataStatus ? { dataStatus: series.dataStatus } : {}),
  }
}

/**
 * @param {any[]} projectedSeries
 * @param {number | undefined} limit
 * @param {any} trend
 * @param {any} result
 */
function assembleTrendResult(projectedSeries, limit, trend, result) {
  const total = projectedSeries.reduce((n, s) => n + (Number(s.count) || 0), 0)
  const returned = projectedSeries.reduce((n, s) => n + s.samples.length, 0)
  return {
    ...pickSafetyFields(result),
    trend: {
      ...trend,
      series: projectedSeries,
      total,
      returned,
      // Not a Host-parsed cursor: agents page with pointIds + end=oldestReturnedAt-1.
      nextCursor: null,
      limit: Number.isFinite(limit) && Number(limit) > 0 ? Math.trunc(Number(limit)) : undefined,
    },
  }
}

/**
 * @param {any} args
 * @param {any} result
 */
export function projectTrend(args, result) {
  const trend = result.trend && typeof result.trend === 'object' ? { ...result.trend } : {}
  /** @type {any[]} */
  const series = Array.isArray(trend.series) ? trend.series : []
  const argsLimit = Number(args?.limit)
  const hostLimit = Number(trend.limit)
  const effectiveLimit = Number.isFinite(argsLimit) && argsLimit > 0
    ? Math.trunc(argsLimit)
    : Number.isFinite(hostLimit) && hostLimit > 0
      ? Math.trunc(hostLimit)
      : undefined
  const cap = AGENT_TEXT_CAPS.trendBytes
  // Enforce per-series limit at projection (defense against a buggy Host over-return).
  const full = series.map((/** @type {any} */ s) => {
    const count = Number(s?.count) || (Array.isArray(s?.samples) ? s.samples.length : 0)
    let samples = Array.isArray(s?.samples) ? s.samples : []
    if (effectiveLimit != null) samples = samples.slice(-effectiveLimit)
    return { ...s, count, samples }
  })
  const maxKeep = Math.max(0, ...full.map((s) => s.samples.length))
  // Non-empty input must keep at least one newest sample per non-empty series —
  // keep=0 is only legal when the source data is truly empty.
  const minKeep = maxKeep > 0 ? 1 : 0
  for (let keep = maxKeep; keep >= minKeep; keep--) {
    const projectedSeries = full.map((s) => buildSeriesPage(s, keep))
    const page = assembleTrendResult(projectedSeries, effectiveLimit, trend, result)
    const candidate = projectedSeries.some((s) => s.hasMore) ? { ...page, truncated: true } : page
    if (utf8ByteLength(candidate) <= cap) return candidate
  }
  // Metadata + one newest sample per non-empty series still does not fit:
  // degraded overrun result (allowed to exceed normal cap) — never a fake empty ok page.
  const one = full.map((s) => buildSeriesPage(s, s.samples.length ? 1 : 0))
  return {
    ...assembleTrendResult(one, effectiveLimit, trend, result),
    truncated: true,
    overrun: true,
    hint: 'trend 超预算：缩小 pointIds 或精简元数据（至少保留每条序列最新样本）',
  }
}

/**
 * @param {string} id
 * @param {any} row
 * @param {{ detail?: boolean }} [opts]
 */
function projectAlarmRow(id, row, opts = {}) {
  const alarm = row && typeof row === 'object' ? row : {}
  const current = alarm.current ?? alarm.value ?? alarm.raw
  const trigger = alarm.trigger ?? alarm.triggerValue ?? alarm.threshold
  const group = String(alarm.group || '')
  const isComm = group === 'comm' || String(id).startsWith('comm:')
  const pointId = isComm ? '' : String(alarm.pointId || '')
  /** @type {Record<string, unknown>} */
  const base = {
    id,
    condition: alarm.condition ?? '',
    group: group || '',
    pointId,
    connectionId: alarm.connectionId ?? '',
    deviceId: alarm.deviceId ?? '',
    current,
    value: current,
    trigger,
    threshold: trigger,
    severity: alarm.severity ?? '',
    quality: alarm.quality ?? '',
    status: alarm.status ?? '',
    firstAt: alarm.firstAt ?? 0,
    lastAt: alarm.lastAt ?? 0,
    occurredAt: alarm.occurredAt || alarm.at || alarm.firedAt || alarm.eventAt || alarm.firstAt || 0,
    clearedAt: alarm.clearedAt || alarm.recoveredAt || 0,
    recoveredAt: alarm.recoveredAt ?? 0,
    frameId: alarm.frameId || '',
    transactionId: alarm.transactionId || '',
    kind: alarm.kind ?? '',
    acknowledged: alarm.acknowledged === true,
    ackedAt: Number(alarm.ackedAt) > 0 ? Number(alarm.ackedAt) : 0,
    ackedBy: typeof alarm.ackedBy === 'string' ? alarm.ackedBy : '',
    count: Number(alarm.count) > 0 ? Number(alarm.count) : 0,
  }
  if (opts.detail) {
    base.durationMs = Number(alarm.durationMs) > 0 ? Number(alarm.durationMs) : 0
    base.suggestedAt = Number(alarm.suggestedAt) > 0 ? Number(alarm.suggestedAt) : 0
    base.suggestedBy = typeof alarm.suggestedBy === 'string' ? alarm.suggestedBy : ''
    base.taskId = typeof alarm.taskId === 'string' ? alarm.taskId : ''
    base.suppressUntil = Number(alarm.suppressUntil) > 0 ? Number(alarm.suppressUntil) : 0
    base.pendingSince = Number(alarm.pendingSince) > 0 ? Number(alarm.pendingSince) : 0
  }
  return base
}

/**
 * @param {any} args
 * @param {any} result
 */
export function projectAlarm(args, result) {
  const alarms = result.alarms && typeof result.alarms === 'object' ? result.alarms : {}
  const alarmId = typeof args?.alarmId === 'string' ? args.alarmId.trim() : ''
  const pageLimit = Math.max(1, Math.min(ALARM_PAGE_DEFAULT, Number(args?.limit) || ALARM_PAGE_DEFAULT))
  const pageOffset = Math.max(0, Number(args?.offset) || 0)
  const cap = AGENT_TEXT_CAPS.alarmBytes
  const commandId = typeof result.commandId === 'string' ? result.commandId : ''

  /**
   * @param {Record<string, ReturnType<typeof projectAlarmRow>>} projectedAlarms
   * @param {number} total
   * @param {number} returned
   * @param {string | null} nextCursor
   * @param {boolean} [truncated]
   */
  const build = (projectedAlarms, total, returned, nextCursor, truncated) => ({
    ...pickSafetyFields(result),
    connectionId: result.connectionId,
    configVersion: result.configVersion,
    alarms: projectedAlarms,
    alarmCount: total,
    total,
    returned,
    nextCursor,
    subscription: result.subscription,
    ...(truncated ? { truncated: true } : {}),
  })

  if (alarmId) {
    const hit = alarms[alarmId]
    if (!hit) {
      return build({}, Object.keys(alarms).length, 0, null)
    }
    const projected = build({ [alarmId]: projectAlarmRow(alarmId, hit, { detail: true }) }, 1, 1, null)
    if (utf8ByteLength(projected) <= cap) return projected
    return resultTooLarge({ action: 'alarm', commandId, total: 1, alarmId })
  }

  const entries = Object.entries(alarms)
  const total = entries.length
  const slice = entries.slice(pageOffset, pageOffset + pageLimit)
  if (!slice.length) return build({}, total, 0, null)

  for (let k = slice.length; k >= 1; k -= 1) {
    const kept = slice.slice(0, k)
    const projectedAlarms = Object.fromEntries(kept.map(([id, row]) => [id, projectAlarmRow(id, row)]))
    const nextCursor = pageOffset + k < total ? String(pageOffset + k) : null
    const truncated = k < slice.length || nextCursor !== null
    const projected = build(projectedAlarms, total, k, nextCursor, truncated)
    if (utf8ByteLength(projected) <= cap) return projected
  }

  return resultTooLarge({
    action: 'alarm',
    commandId,
    total,
    alarmId: slice[0][0],
  })
}

/**
 * @param {any} args
 * @param {any} result
 * @returns {any}
 */

