// @ts-check
import { createHash } from 'node:crypto'
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { dirname, isAbsolute, join } from 'node:path'
import { loadBindings as defaultLoadBindings } from '../../infrastructure/store/bindings-store.mjs'
import { loadWorkspace as defaultLoadWorkspace } from '../../infrastructure/store/workspace-store.mjs'
import { createDebugLaunchSpec } from '../../domain/debug/debug-launch-spec.mjs'
import { DEBUG_ERRORS, DebugError } from '../../domain/debug/errors.mjs'
import {
  DEFAULT_OPENOCD_INTERFACE,
  DEFAULT_OPENOCD_TARGET,
  resolveOpenOcdProfile,
} from '../../domain/flash/openocd-profile.mjs'
import { allocateLoopbackPort } from '../../infrastructure/network/loopback-port.mjs'

/**
 * Common artifact candidate folders to search in embedded projects.
 *
 * Keil MDK writes to `Objects/` **next to the .uvprojx**, not next to the
 * workspace root, so `findFirmwareArtifacts` searches the project directory
 * first and falls back to the workspace root.
 */
const COMMON_ARTIFACT_DIRS = [
  'build',
  'Objects',
  'Objects/Release',
  'Objects/Debug',
  'out',
  'bin',
  'Debug',
  'debug',
  'Release',
  'release',
  'cmake-build-debug',
  'cmake-build-release',
  'MDK-ARM',
  'mdk-arm',
  '.',
]

/** Firmware artifact extensions we recognise (Keil `.axf`, GCC/IAR `.elf`). */
const ARTIFACT_EXTENSIONS = ['.axf', '.elf']

/**
 * Searches for firmware artifact (.axf or .elf) within workspace cwd.
 * @param {string} cwd
 * @returns {string[]} List of absolute paths to candidate firmware files
 */
/**
 * Collects firmware artifacts directly inside one root directory.
 *
 * @param {string} root
 * @returns {string[]}
 */
function collectArtifactsUnder(root) {
  if (!root || !existsSync(root)) return []
  /** @type {string[]} */
  const out = []
  for (const relDir of COMMON_ARTIFACT_DIRS) {
    const dir = relDir === '.' ? root : join(root, relDir)
    if (!existsSync(dir)) continue

    try {
      const entries = readdirSync(dir)
      for (const entry of entries) {
        const lower = entry.toLowerCase()
        if (!ARTIFACT_EXTENSIONS.some((ext) => lower.endsWith(ext))) continue
        const full = join(dir, entry)
        try {
          const st = statSync(full)
          if (st.isFile()) {
            out.push(full)
          }
        } catch {
          /* ignore inaccessible */
        }
      }
    } catch {
      /* ignore read errors */
    }
  }
  return out
}

/**
 * Searches for firmware artifact (.axf / .elf) within a workspace.
 *
 * Search roots, in order:
 *   1. the directory holding the Keil project file (.uvprojx), when known —
 *      Keil resolves `Objects/` relative to the project, so a project nested in
 *      `MDK-ARM/` is invisible to a workspace-root-only scan;
 *   2. the workspace cwd, as a fallback for CMake/Make projects.
 *
 * @param {string} cwd
 * @param {{ projectPath?: string }} [options]
 * @returns {string[]} List of absolute paths to candidate firmware files
 */
export function findFirmwareArtifacts(cwd, options = {}) {
  if (!cwd || !existsSync(cwd)) return []

  /** @type {string[]} */
  const roots = []
  const projectPath = String(options.projectPath || '').trim()
  if (projectPath) {
    roots.push(dirname(projectPath))
  }
  roots.push(cwd)

  /** @type {string[]} */
  const candidates = []
  for (const root of roots) {
    candidates.push(...collectArtifactsUnder(root))
  }

  // Deduplicate
  return Array.from(new Set(candidates))
}

/**
 * Computes SHA256 of file at path.
 * @param {string} filePath
 * @returns {string}
 */
export function computeFileSha256(filePath) {
  if (!filePath || !existsSync(filePath)) return ''
  try {
    const buf = readFileSync(filePath)
    return createHash('sha256').update(buf).digest('hex')
  } catch {
    return ''
  }
}

/**
 * Default getter for last successful build result from workspace.
 *
 * @param {string} cwd
 * @param {{ home?: string, workspace?: any }} [opts]
 * @returns {{
 *   projectPath?: string,
 *   targetName?: string,
 *   artifactPath?: string,
 *   artifactSha256?: string,
 *   builtAt?: number,
 *   success?: boolean,
 * } | null}
 */
export function defaultGetLastBuildResult(cwd, opts = {}) {
  const ws =
    opts.workspace || (typeof defaultLoadWorkspace === 'function' ? defaultLoadWorkspace(opts.home, cwd) : null)
  if (!ws) return null

  // 1. Check explicit buildResult stored on workspace.keil
  if (ws.keil?.buildResult?.success) {
    return ws.keil.buildResult
  }

  // 2. Check newest ok build task with download path
  const tasks = Array.isArray(ws.tasks) ? ws.tasks : []
  const okBuildTask = tasks
    .slice()
    .reverse()
    .find((/** @type {any} */ t) => t && t.type === 'build' && t.status === 'ok')

  if (okBuildTask && ws.keil?.download) {
    return {
      projectPath: ws.keil.project || '',
      targetName: ws.keil.target || '',
      artifactPath: ws.keil.download,
      artifactSha256: ws.keil.buildResult?.artifactSha256 || '',
      builtAt: okBuildTask.endedAt || okBuildTask.startedAt || 0,
      success: true,
    }
  }

  return null
}

/**
 * Resolves full launch specification for a debug session, prioritizing:
 * 1. current workspace project/target
 * 2. last successful BuildResult
 * 3. current artifact hash re-check
 * 4. settings bindings
 * 5. shared OpenOCD profile
 * 6. dynamic loopback port
 * 7. mtime artifact scan fallback
 *
 * @param {import('../../types/debug-launch.d.ts').DebugLaunchRequest} request
 * @param {{
 *   home?: string,
 *   loadWorkspace?: (home?: string, cwd?: string) => any,
 *   loadBindings?: (home?: string) => any,
 *   getLastBuildResult?: (cwd: string, opts?: any) => any,
 *   resolveOpenOcdProfile?: typeof resolveOpenOcdProfile,
 *   portAllocator?: typeof allocateLoopbackPort,
 *   artifactFinder?: typeof findFirmwareArtifacts,
 * }} [deps]
 * @returns {Promise<import('../../types/debug-launch.d.ts').ResolvedLaunchSpec & { spec: ReturnType<typeof createDebugLaunchSpec>, resolutionMethod?: string }>}
 */
export async function resolveDebugLaunchSpec(request, deps = {}) {
  const cwd = String(request.cwd || process.cwd()).trim()
  const home = deps.home
  const backend = request.backend || 'gdb-openocd'
  const targetSpec = request.targetSpec || {}

  const loadWorkspace = deps.loadWorkspace || defaultLoadWorkspace
  const loadBindings = deps.loadBindings || defaultLoadBindings
  const getLastBuildResult = deps.getLastBuildResult || defaultGetLastBuildResult
  const portAllocator = deps.portAllocator || allocateLoopbackPort
  const artifactFinder = deps.artifactFinder || findFirmwareArtifacts
  const profileResolver = deps.resolveOpenOcdProfile || resolveOpenOcdProfile

  let ws = null
  let wsError = ''
  try {
    ws = loadWorkspace(home, cwd)
  } catch (err) {
    ws = null
    wsError = err instanceof Error ? err.message : String(err)
  }

  /** @type {Record<string, any>} */
  let bindings = {}
  let bindingsError = ''
  try {
    bindings = loadBindings(home) || {}
  } catch (err) {
    bindings = {}
    bindingsError = err instanceof Error ? err.message : String(err)
  }

  // A missing home is the single most likely reason bindings come back empty.
  // Without this note the failure is indistinguishable from "user configured
  // nothing", which is exactly how the binding feature stayed broken unnoticed.
  if (!home) {
    bindingsError = bindingsError || '未提供 home，无法读取 Corn 绑定配置'
  }

  // 1. Current workspace project & target
  const projectPath = String(targetSpec.projectPath || ws?.keil?.project || '').trim()
  const targetName = String(targetSpec.targetName || ws?.keil?.target || '').trim()

  let artifactPath = targetSpec.artifactPath ? String(targetSpec.artifactPath).trim() : ''
  let artifactSha256 = targetSpec.artifactSha256 ? String(targetSpec.artifactSha256).trim() : ''
  let source = 'auto-resolved'
  let resolutionMethod = 'auto'
  /** @type {string[]} */
  let artifactCandidates = []

  // 2. Check last successful BuildResult if artifact not explicitly given
  if (!artifactPath) {
    const buildResult = getLastBuildResult(cwd, { home, workspace: ws })
    if (buildResult?.success) {
      const matchProject = !projectPath || !buildResult.projectPath || buildResult.projectPath === projectPath
      const matchTarget = !targetName || !buildResult.targetName || buildResult.targetName === targetName
      if (matchProject && matchTarget && buildResult.artifactPath && existsSync(buildResult.artifactPath)) {
        const currentSha = computeFileSha256(buildResult.artifactPath)
        if (buildResult.artifactSha256 && currentSha && buildResult.artifactSha256 !== currentSha) {
          throw new DebugError(
            DEBUG_ERRORS.ARTIFACT_DRIFT,
            '固件产物已发生变更 (SHA256 不一致)，请重新执行 Keil 编译',
            { storedSha256: buildResult.artifactSha256, currentSha256: currentSha },
          )
        }
        artifactPath = buildResult.artifactPath
        artifactSha256 = currentSha || buildResult.artifactSha256 || ''
        resolutionMethod = 'build-result'
      }
    }
  }

  // 3. Current artifact hash check if artifactPath is provided
  if (artifactPath) {
    if (!isAbsolute(artifactPath)) {
      artifactPath = join(cwd, artifactPath)
    }
    if (existsSync(artifactPath)) {
      source = resolutionMethod === 'build-result' ? 'auto-resolved' : 'explicit'
      resolutionMethod = resolutionMethod === 'build-result' ? 'build-result' : 'explicit'
      const diskSha = computeFileSha256(artifactPath)
      if (artifactSha256 && diskSha && artifactSha256 !== diskSha) {
        throw new DebugError(DEBUG_ERRORS.ARTIFACT_DRIFT, '指定的固件哈希与磁盘文件不匹配，请重新确认或编译', {
          expectedSha256: artifactSha256,
          currentSha256: diskSha,
        })
      }
      artifactSha256 = diskSha || artifactSha256
    } else {
      // A launch is always pinned to bytes on disk; a hash alone proves nothing.
      throw new DebugError(DEBUG_ERRORS.TARGET_SPEC_INVALID, `指定的固件产物不存在: ${artifactPath}`)
    }
  } else if (artifactSha256) {
    throw new DebugError(
      DEBUG_ERRORS.TARGET_SPEC_INVALID,
      '只提供了固件 SHA256，缺少固件路径。请指定 artifactPath 或先执行 Keil 编译。',
    )
  } else if (!existsSync(cwd)) {
    throw new DebugError(DEBUG_ERRORS.TARGET_SPEC_INVALID, `工作区目录不存在: ${cwd}`)
  } else {
    // 7. Fallback: Auto-detect artifact from workspace via mtime scan.
    //    Search the Keil project directory first — `Objects/` lives next to the
    //    .uvprojx, which is not necessarily the workspace root.
    const found = artifactFinder(cwd, { projectPath })
    artifactCandidates = found
    if (found.length === 0) {
      throw new DebugError(
        DEBUG_ERRORS.TARGET_SPEC_INVALID,
        '未在工作区找到固件产物 (.axf / .elf)。请先执行 Keil 编译或构建固件，或在启动参数中明确指定 artifactPath。',
      )
    }
    if (found.length === 1) {
      artifactPath = found[0]
      artifactSha256 = computeFileSha256(artifactPath)
      source = 'auto-resolved'
      resolutionMethod = 'mtime-scan'
    } else {
      // Multiple candidates: pick newest by mtime
      let newestPath = found[0]
      let newestTime = 0
      for (const p of found) {
        try {
          const st = statSync(p)
          if (st.mtimeMs > newestTime) {
            newestTime = st.mtimeMs
            newestPath = p
          }
        } catch {
          /* ignore */
        }
      }
      artifactPath = newestPath
      artifactSha256 = computeFileSha256(artifactPath)
      source = 'auto-resolved'
      resolutionMethod = 'mtime-scan'
    }
  }

  // 4. Settings bindings: resolve tool paths. Executables come only from the
  //    user's Settings → Corn bindings, never from the launch request, so a
  //    caller (Agent included) cannot choose what gets spawned.
  const openocdBin = bindings.openocd ? String(bindings.openocd).trim() : 'openocd'

  const gdbBin = bindings.gdb
    ? String(bindings.gdb).trim()
    : bindings['arm-none-eabi-gdb']
      ? String(bindings['arm-none-eabi-gdb']).trim()
      : 'arm-none-eabi-gdb'

  const uv4Bin = bindings.uv4 ? String(bindings.uv4).trim() : ''

  // 5. Shared OpenOCD profile: resolve interface and target
  let interfaceName = DEFAULT_OPENOCD_INTERFACE
  let target = DEFAULT_OPENOCD_TARGET

  if (backend === 'gdb-openocd') {
    const profileRes = profileResolver(
      { interfaceName: targetSpec.interfaceName, target: targetSpec.target },
      {
        interface: ws?.keil?.flash?.interface || bindings.interface,
        target: ws?.keil?.flash?.target || bindings.target,
      },
    )
    if (!profileRes.ok) {
      // The whitelist is the only thing standing between caller text and the
      // OpenOCD argv; it holds whether or not the workspace exists.
      throw new DebugError(DEBUG_ERRORS.TARGET_SPEC_INVALID, profileRes.error)
    }
    interfaceName = profileRes.interfaceName
    target = profileRes.target
  } else {
    interfaceName = String(targetSpec.interfaceName || '')
    target = String(targetSpec.target || '')
  }

  const probeSerial = targetSpec.probeSerial ? String(targetSpec.probeSerial).trim() : undefined

  // 6. Dynamic loopback port
  const preferredPort = Number(targetSpec.gdbPort) || 0
  const gdbPort = await portAllocator(preferredPort)

  // Canonical domain launch spec
  const spec = createDebugLaunchSpec({
    backend,
    workspace: { cwd },
    project: { path: projectPath, targetName },
    artifact: { path: artifactPath, sha256: artifactSha256 },
    tools: { gdbBin, openocdBin, uv4Bin },
    hardware: { interfaceName, openocdTarget: target, probeSerial },
    transport: { gdbPort },
  })

  return {
    backend,
    source: /** @type {'explicit' | 'auto-resolved'} */ (source === 'explicit' ? 'explicit' : 'auto-resolved'),
    resolutionMethod,
    projectPath,
    targetName,
    targetSpec: {
      ...targetSpec,
      projectPath,
      targetName,
      artifactPath,
      artifactSha256,
      gdbPort,
      openocdBin,
      gdbBin,
      uv4Bin,
      interfaceName,
      target,
      probeSerial,
      cwd,
    },
    spec,
    /**
     * Why workspace / bindings came back empty. Surfaced so a misconfigured
     * `home` or a corrupt bindings.json is distinguishable from "user has not
     * configured anything".
     */
    diagnostics: {
      home: home || '',
      wsError,
      bindingsError,
      artifactCandidates: Array.from(artifactCandidates),
    },
  }
}
