// `node scripts/smoke-client.cjs` — load the built client bundle outside a
// browser: stub the module loader, react, and document, run apply(), then
// render every registered component once. Catches registration mistakes and
// render-time ReferenceErrors without needing a DOM.
const path = require('node:path')

const bundlePath = process.argv[2] || path.join(__dirname, '..', 'lib', 'client.js')

let loaded = null
global.window = {
  __ModuleLoader__: {
    load(options) {
      loaded = options
    },
  },
}

global.document = {
  createElement: () => ({ setAttribute() {}, remove() {} }),
  head: { appendChild() {} },
}

const h = (type, props, ...children) => ({ type, props: props || {}, children })
let seed = []
let seedCursor = 0
function nextSeeded(initial) {
  if (seedCursor >= seed.length) return typeof initial === 'function' ? initial() : initial
  const value = seed[seedCursor]
  seedCursor += 1
  return value
}
function expand(node, depth) {
  if (depth > 40 || node === null || node === undefined || typeof node !== 'object') return node
  if (Array.isArray(node)) return node.map((one) => expand(one, depth + 1))
  const { type, props, children } = node
  if (typeof type === 'function') {
    return expand(type(Object.assign({}, props, { children: children.length === 1 ? children[0] : children })), depth + 1)
  }
  return Object.assign({}, node, { children: expand(children, depth + 1) })
}
function collectText(node, out) {
  if (node === null || node === undefined || typeof node === 'boolean') return out
  if (typeof node === 'string' || typeof node === 'number') {
    out.push(String(node))
    return out
  }
  if (Array.isArray(node)) {
    for (const child of node) collectText(child, out)
    return out
  }
  if (typeof node === 'object') collectText(node.children, out)
  return out
}
const React = {
  createElement: h,
  Fragment: 'fragment',
  useState: (initial) => [nextSeeded(initial), () => {}],
  useCallback: (fn) => fn,
  useEffect: () => {},
  useMemo: (fn) => fn(),
  useRef: (value) => ({ current: value }),
}
const requireTable = (name) => {
  if (name === 'react') return React
  throw new Error(`unexpected module request: ${name}`)
}

require(path.resolve(bundlePath))

const problems = []
if (loaded === null) problems.push('bundle never called window.__ModuleLoader__.load')
if (loaded.id !== '@local/dsh-permission-manager') problems.push(`unexpected module id: ${loaded.id}`)

const mod = loaded.factory(requireTable)
if (typeof mod.apply !== 'function') problems.push('missing mod.apply')
if (mod.name !== 'dsh-permission-manager') problems.push(`unexpected mod.name: ${mod.name}`)

const registrations = []
const injections = []
let dispose = null
const ctx = {
  slots: {
    inject(name, callback) {
      injections.push(name)
      callback()
      return () => {}
    },
    register(spec, component) {
      registrations.push({ spec, component })
      return () => {}
    },
  },
}

let threw = null
try {
  dispose = mod.apply(ctx)
} catch (error) {
  threw = error
}
if (threw !== null) problems.push(`apply() threw: ${threw && threw.stack}`)
if (typeof dispose !== 'function') problems.push('apply() did not return a disposer')

const byName = new Map()
for (const row of registrations) {
  const name = row.spec.name
  if (!byName.has(name)) byName.set(name, [])
  byName.get(name).push(row)
  if (row.spec.id === undefined && row.spec.key === undefined) problems.push(`slot ${name} has neither id nor key`)
  if (name !== 'main' && typeof row.spec.order !== 'number') problems.push(`list slot ${name} has no numeric order`)
  if (typeof row.component !== 'function') problems.push(`slot ${name} has no component function`)
  if (name === 'main' && row.spec.key !== 'dsh-permission-manager') problems.push(`main key is ${row.spec.key}`)
  if (name === 'sidebar.panellist' && row.spec.id !== 'dsh-permission-manager') problems.push(`panellist id is ${row.spec.id}`)
}

for (const name of ['main', 'sidebar.panellist']) if (!byName.has(name)) problems.push(`slot ${name} was not registered`)
if (injections.length !== 1) problems.push(`expected 1 slot injection, saw ${injections.length}`)

function describe(node) {
  if (node === null || node === undefined) return String(node)
  if (typeof node === 'string') return JSON.stringify(node.slice(0, 40))
  if (typeof node === 'number' || typeof node === 'boolean') return String(node)
  if (Array.isArray(node)) return `[${node.length} children]`
  if (typeof node === 'object') {
    const tag = typeof node.type === 'string' ? node.type : String(node.type && node.type.name)
    return `<${tag}>`
  }
  return typeof node
}

const rendered = []
for (const [name, rows] of byName) {
  for (const row of rows) {
    try {
      const tree = name === 'sidebar.panellist' ? row.component({ size: 16, active: false }) : row.component({})
      let nodes = 0
      const deepRender = (node, depth) => {
        if (depth > 40 || node === null || node === undefined) return
        if (Array.isArray(node)) {
          for (const child of node) deepRender(child, depth + 1)
          return
        }
        if (typeof node !== 'object') return
        nodes += 1
        const { type, props, children } = node
        if (typeof type === 'function') {
          deepRender(type(Object.assign({}, props, { children: children.length === 1 ? children[0] : children })), depth + 1)
          return
        }
        deepRender(children, depth + 1)
      }
      deepRender(tree, 0)
      rendered.push(`${name}: ${describe(tree)} (${nodes} elements deep-rendered)`)
    } catch (error) {
      problems.push(`rendering ${name} threw: ${error && error.stack}`)
    }
  }
}

/* Phase two: populate every Page state the way the real fetch would, so the
   preset cards, the lock card and the conversation list all render. */
const sampleData = {
  profileDir: '/root/projects/.dsh/profiles/web',
  presets: [
    { value: 'read-only', name: 'read-only', description: '', configured: true },
    { value: 'workspace-write', name: 'workspace-write', description: '', configured: true },
    { value: 'danger-full-access', name: 'danger-full-access', description: '', configured: true },
  ],
  defaultOptions: ['read-only', 'workspace-write', 'danger-full-access'],
  defaultPreset: 'workspace-write',
  lock: true,
  lockedPreset: 'danger-full-access',
  sessions: [
    { id: 'session-946b3449', title: '帮我写一个插件', current: 'danger-full-access', events: 812 },
    { id: 'session-267ba3a5', title: '', current: 'workspace-write', events: 120 },
  ],
  truncated: false,
}
seed = [sampleData, null, null, '', true]
seedCursor = 0
const mainRow = (byName.get('main') || [])[0]
if (mainRow !== undefined) {
  try {
    const texts = collectText(expand(mainRow.component({}), 0), [])
    const joined = texts.join(' | ')
    console.log('populated branch text:', joined.slice(0, 700))
    if (!joined.includes('权限管理')) problems.push('populated branch never shows the headline')
    if (!joined.includes('完全权限')) problems.push('populated branch never shows the full-access option')
    if (!joined.includes('帮我写一个插件')) problems.push('populated branch never lists a conversation title')
    if (!joined.includes('session-946b3449')) problems.push('populated branch never lists a conversation id')
    if (!joined.includes('已锁定')) problems.push('populated branch never renders the locked state')
  } catch (error) {
    problems.push(`populated branch threw: ${error && error.stack}`)
  }
}
seed = []
seedCursor = 0

console.log('module id      :', loaded.id)
console.log('mod.name       :', mod.name)
console.log('injections     :', injections.join(', '))
console.log('registrations  :', registrations.map((row) => `${row.spec.name}#${row.spec.id || row.spec.key}@${row.spec.order}`).join(' | '))
console.log('rendered       :')
for (const line of rendered) console.log('  -', line)
console.log(problems.length === 0 ? 'SMOKE OK' : `SMOKE FAILED\n - ${problems.join('\n - ')}`)
process.exit(problems.length === 0 ? 0 : 1)
