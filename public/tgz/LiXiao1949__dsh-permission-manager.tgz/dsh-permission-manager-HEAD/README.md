# dsh-permission-manager

**DSH 权限管理面板** —— 侧边栏一键把全部对话的权限切成同一个模式，并可锁定给之后打开或新建的对话。

<p align="center">
  <b>作者</b> LiXiao1949 &nbsp;·&nbsp;
  <b>GitHub</b> <a href="https://github.com/LiXiao1949">github.com/LiXiao1949</a> &nbsp;·&nbsp;
  <b>QQ</b> 1640444672
</p>

| 项目信息 | |
| --- | --- |
| 项目名 | `dsh-permission-manager` |
| 包名 | `@local/dsh-permission-manager` |
| 版本 | 1.0.0 |
| 作者 | **LiXiao1949** |
| GitHub | <https://github.com/LiXiao1949> |
| 仓库 | <https://github.com/LiXiao1949/dsh-permission-manager> |
| QQ | **1640444672** |
| 反馈 | [Issues](https://github.com/LiXiao1949/dsh-permission-manager/issues) · QQ 1640444672 |
| 许可证 | MIT |

---

## 它做什么

侧边栏多一个「权限管理」入口，位置和**插件市场**、**自动化任务**并排（`sidebar.panellist` + `main`）。
里面可以一键把**所有对话**的权限切成同一个模式 —— 就是设置里那三种「权限预设」：

| 预设（键） | 面板显示 | 沙箱 | 审批 |
|---|---|---|---|
| `read-only` | 仅可查看 | 只读 | 每次都问 |
| `workspace-write` | 工作区内修改 | 可写工作区/临时目录 | 越界才问 |
| `danger-full-access` | **完全权限** | 任意路径可写 | 从不问 |

打开面板就能看到作者信息（LiXiao1949 · GitHub · QQ 1640444672）。

## 它改的是什么

不是自己维护一份状态，全部走 DSH 自带的两个服务：

- **已有对话**：`permissionPresets.set(session, preset)`。DSH 的沙箱模式与审批策略都是**会话日志里的折叠事件**（`sandbox/mode`、`approval/policy`），所以对活着的会话 append 一条就立即生效 —— 当前对话下一次工具调用就按新权限走，不用重启。
- **新对话**：`settings.mutate('permission', [{op:'set', path:['defaultPreset'], value: preset}])`，写进 profile 配置（`permission.defaultPreset`），重启后仍在，只影响之后新建的会话。
- **锁定模式**：在 profile 里存一个开关（`<profile>/.permission-manager/state.json`），打开后监听 `session/created`，**之后打开或新建的对话**也会自动切成锁定的那个权限 —— 这是「历史对话也一并接管」的那条路（没锁定时，未被加载的历史对话按自己的记录恢复）。

## 界面

```
权限管理
一键把全部对话的权限切成同一个模式 —— 沙箱与审批一起换
作者 LiXiao1949 | GitHub @LiXiao1949 | 项目仓库 dsh-permission-manager | QQ 1640444672
[新对话默认：工作区内修改] [锁定：关闭]                      [刷新]

一键应用到所有对话                                      [2 个对话]
  ○ 仅可查看      read-only
  ○ 工作区内修改  workspace-write
  ○ 完全权限      danger-full-access
  [✓] 同时设为「新对话」的默认权限
  这里改的是当前进程里已经加载的每一个对话…

新对话默认权限
  ○ 仅可查看 / ○ 工作区内修改 / ○ 完全权限

锁定模式                                          [开关]

对话列表
  帮我写一个插件        session-946b3449   [完全权限]  [仅可查看][工作区内修改][完全权限]
```

## 目录结构

```
dsh-permission-manager/
├── package.json          dsh.bundle.patch + dsh.client.platform=web + author 信息
├── cordis.patch.yml      插入 dsh-permission-manager 这一行 loader entry
├── assets/logo.svg       插件页图标
├── lib/
│   ├── index.js          host 半：等 webServer 就位后挂路由
│   ├── routes.js         /dsh-permission-manager/api/* 的 JSON 路由（/state 带 author 字段）
│   ├── http.js           同源/回环校验、JSON 收发
│   └── client.js         浏览器半：页面 + slot 注册 + 作者卡片
└── scripts/
    └── smoke-client.cjs  无浏览器的自测
```

## 接口（同源、走 host 的登录闸）

| 方法 | 路径 | 作用 |
|---|---|---|
| GET | `/dsh-permission-manager/api/state` | 预设表、新对话默认、锁定状态、对话列表（标题 + 当前权限）、**作者信息（author）** |
| POST | `/apply` `{preset, scope:'all'\|'session', sessionId?, alsoDefault?}` | 应用到全部 / 单个对话，可选同步新对话默认 |
| POST | `/default` `{preset}` | 只改新对话默认（写 profile 配置） |
| POST | `/lock` `{lock, preset?}` | 开/关锁定模式；开启时立刻应用到现有对话 |

所有接口先问 `connection.requestRejection()`（DSH 的浏览器登录/信任闸），再自己校一遍 Host / `sec-fetch-site` / Origin。

`/state` 里的作者信息长这样：

```json
{
  "author": {
    "name": "LiXiao1949",
    "github": "https://github.com/LiXiao1949",
    "repo": "https://github.com/LiXiao1949/dsh-permission-manager",
    "qq": "1640444672"
  }
}
```

## 安装自己

与 `@local/dsh-local-install` 同形：源目录先固化到 `<profile>/local-plugins/<名字>@<版本>`，再写一条 `link:` 依赖 + `node_modules` 符号链接 + bundles 条目。

```bash
git clone https://github.com/LiXiao1949/dsh-permission-manager.git
PROFILE=~/.dsh/profiles/web
cp -a dsh-permission-manager "$PROFILE/local-plugins/local-dsh-permission-manager@1.0.0"
ln -sfn "../../local-plugins/local-dsh-permission-manager@1.0.0" "$PROFILE/node_modules/@local/dsh-permission-manager"
# package.json dependencies 里加：
#   "@local/dsh-permission-manager": "link:<profile>/local-plugins/local-dsh-permission-manager@1.0.0"
# dsh.profile.bundles 里加 "@local/dsh-permission-manager"
```

host 半的路由在**进程启动时**挂载（只改 `lib/client.js` 刷新页面即可，改 `lib/routes.js`/`lib/index.js` 要重启一次 DSH）。

## 自测

```bash
node scripts/smoke-client.cjs   # 或 npm test
```

用假的 `window.__ModuleLoader__` / `react` / `document` 跑一遍：`apply()` 返回 disposer、`main` 与 `sidebar.panellist` 两个座位按预期注册、以及「有预设/有对话/已锁定」的数据下页面能不能渲染出内容（含作者卡片 LiXiao1949 · GitHub · QQ 1640444672）。

## 边界

- 只覆盖**当前进程里已经加载**的对话（DSH 的会话对象在打开时才进内存）。锁定模式补上「之后打开的」那一截。
- `Auto`（自动审查）在它没注册的部署里不会出现；`custom` 是派生状态，不可选。
- 完全权限 = 不弹审批 + 任意路径可写，跟设置里选「完全权限」等价。

## 联系作者

- **作者**：LiXiao1949
- **GitHub**：<https://github.com/LiXiao1949>
- **项目仓库**：<https://github.com/LiXiao1949/dsh-permission-manager>
- **QQ**：**1640444672**
- **问题反馈**：[开 Issue](https://github.com/LiXiao1949/dsh-permission-manager/issues) 或直接 QQ 找我

## 许可证

MIT © LiXiao1949
