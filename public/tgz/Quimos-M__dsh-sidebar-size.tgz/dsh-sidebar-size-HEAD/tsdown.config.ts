/**
 * dsh-sidebar-size 的 tsdown 配置。
 *
 * 产物：
 *   * `lib/index.js` —— host 半（插件本体，DSH Loader 装配用）；
 *   * `lib/client.js` —— 浏览器半（`window.__ModuleLoader__` 闭包工厂）。
 *
 * 纯逻辑模块（M2/M3/M4 等）在后续阶段按需加入入口，以便 `tests/` 用 node:test 直接
 * import 编译产物做纯逻辑验证；它们不进 package.json 的 exports。
 *
 * @module dsh-sidebar-size/tsdown.config
 */
import { clientBundle } from './build/tsdown.client.ts'

export default clientBundle('dsh-sidebar-size', [
  // host 半（插件本体）
  'src/index.ts',
  // 纯逻辑：供 tests/ 直接 import 编译产物做 node:test 验证
  'src/client/lifecycle.ts',
  'src/client/preferences.ts',
  'src/client/content-kind.ts',
  'src/client/width-table.ts',
  'src/client/width-store.ts',
  'src/client/controller.ts',
  'src/client/guard.ts',
  'src/client/status-report.ts',
])


