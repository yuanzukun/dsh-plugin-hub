/**
 * P07：设置项背后的控制器行为——按类型改值、重置、导出与导入预览/确认。
 *
 * 覆盖：
 *   * setWidthFor：只更新记录；改的正是当前生效的那一套才立刻应用；非法值与同值分别处理；
 *   * resetWidths：删除存储、清空内存、对齐修订并请求数值默认；删除失败时数据不变；
 *   * exportWidths / exportProblemData；
 *   * previewImport / commitImport：预览不改数据、整体错误与未来版本拒绝导入、预览过期拒绝确认、
 *     确认导入会显式替换受保护原文。
 *
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { createController } from '../lib/client/controller.js'
import { createRootLifecycle } from '../lib/client/lifecycle.js'
import { createWidthTable } from '../lib/client/width-table.js'

const PANEL = { sessionId: 'session-1', elementId: 'el-1' }
const settleMs = ms => new Promise(resolve => setTimeout(resolve, ms))

function makeHarness({ kind = 'files', perContent = true, clearFails = false } = {}) {
  const table = createWidthTable()
  const applied = []
  const cleaned = []
  const logs = []
  const writes = []
  const clears = []
  const listeners = { structure: new Set(), drag: new Set(), width: new Set() }
  const state = { presentation: 'push', kind }
  let protectedNotice = null

  let prefsSnapshot = { state: 'ready', enabled: true, perContent, revision: 1, writable: true, mode: 'host' }
  const prefsListeners = new Set()

  const store = {
    async readAll() { return { kind: 'empty' } },
    protect(text, reason) { protectedNotice = { text, reason } },
    async writeAll(value, options) {
      writes.push({ value, options: options ?? null })
      if (protectedNotice !== null && options?.replaceProtected !== true) {
        return { ok: false, durable: false, protected: true, reason: '受保护' }
      }
      if (options?.replaceProtected === true) protectedNotice = null
      return { ok: true, durable: true }
    },
    async clearAll() {
      clears.push(Date.now())
      if (clearFails) return { ok: false, durable: false, reason: '删除失败' }
      protectedNotice = null
      return { ok: true, durable: true }
    },
    getStatus: () => ({
      available: true,
      writable: true,
      protected: protectedNotice !== null,
      ...protectedNotice === null ? {} : { rawProblemText: protectedNotice.text, error: protectedNotice.reason },
    }),
  }

  const prefs = {
    getSnapshot: () => prefsSnapshot,
    subscribe(listener) { prefsListeners.add(listener); return () => prefsListeners.delete(listener) },
    async ensure() { return prefsSnapshot },
    async update(patch) {
      prefsSnapshot = { ...prefsSnapshot, ...patch, revision: prefsSnapshot.revision + 1 }
      for (const listener of prefsListeners) listener(prefsSnapshot)
      return { ok: true, snapshot: prefsSnapshot }
    },
    dispose() {},
  }

  const host = {
    readView: () => ({
      sessionId: 'session-1',
      panelIdentity: PANEL,
      expanded: state.presentation === 'push',
      presentation: state.presentation,
      framePx: 1280,
      observedPx: 576,
      activeDockContent: { sessionId: 'session-1', paneId: 'pane-0', tabId: 'tab1', kind: state.kind, contentId: 'f' },
      availability: { kind: 'ready' },
    }),
    observeStructure(listener) { listeners.structure.add(listener); return () => listeners.structure.delete(listener) },
    observeDrag(listener) { listeners.drag.add(listener); return () => listeners.drag.delete(listener) },
    observeWidth(listener) { listeners.width.add(listener); return () => listeners.width.delete(listener) },
    async readFinalDragSample() { return null },
    async applyWidth(px) { applied.push(px); return { status: 'applied', requestedPx: px, observedPx: px } },
    async restoreDefault(reason) { cleaned.push(reason); return { status: 'applied', requestedPx: 576, observedPx: 576, resetLevel: 'numeric' } },
    dispose() {},
  }

  const controller = createController({
    lifecycle: createRootLifecycle(),
    prefs, table, host, store,
    log: line => logs.push(line),
  })

  return {
    controller, table, applied, cleaned, logs, writes, clears, state,
    protectStore: (text, reason) => { protectedNotice = { text, reason } },
    emitWidth: (px) => {
      for (const listener of listeners.width) {
        listener({ px, panelIdentity: PANEL, pointerCommitSeq: 1, geometryGeneration: 5, phase: 'dragging', valid: true })
      }
    },
    startDrag: () => {
      for (const listener of listeners.drag) listener({ kind: 'pointer-down', pointerId: 1, panelIdentity: PANEL })
    },
  }
}

test('setWidthFor：改当前生效的类型会立刻应用，并安排落盘', async () => {
  const h = makeHarness()
  await h.controller.start()
  h.applied.length = 0
  h.writes.length = 0

  const result = await h.controller.setWidthFor('kind:files', 'split', 700)
  assert.equal(result.ok, true)
  assert.deepEqual(h.applied, [700], '当前类型应立刻应用')
  assert.equal(h.table.get('kind:files', 'split'), 700)

  await settleMs(350)
  assert.equal(h.writes.length, 1, '改值应安排落盘')
  assert.deepEqual(h.writes[0].value.split, { 'kind:files': 700 })
  await h.controller.dispose()
})

test('setWidthFor：改非当前类型只更新记录，不打扰当前宽度', async () => {
  const h = makeHarness()
  await h.controller.start()
  h.applied.length = 0

  const result = await h.controller.setWidthFor('kind:terminal', 'split', 640)
  assert.equal(result.ok, true)
  assert.deepEqual(h.applied, [], '不是当前类型就不应用')
  assert.equal(h.table.get('kind:terminal', 'split'), 640)
  await h.controller.dispose()
})

test('setWidthFor：非法值与同值分别被拒绝/视为无改动', async () => {
  const h = makeHarness()
  await h.controller.start()

  const tooSmall = await h.controller.setWidthFor('kind:files', 'split', 299)
  assert.equal(tooSmall.ok, false)
  assert.match(tooSmall.reason, /300/)

  const badKey = await h.controller.setWidthFor('bad-key', 'split', 700)
  assert.equal(badKey.ok, false)
  assert.match(badKey.reason, /内容类型/)

  h.writes.length = 0
  await h.controller.setWidthFor('kind:files', 'split', 700)
  await h.controller.setWidthFor('kind:files', 'split', 700)
  assert.equal(h.controller.getSnapshot().memoryRevision >= 1, true)
  const revisionAfterFirst = h.controller.getSnapshot().memoryRevision
  await h.controller.setWidthFor('kind:files', 'split', 700)
  assert.equal(h.controller.getSnapshot().memoryRevision, revisionAfterFirst, '同值不产生新修订')
  await h.controller.dispose()
})

test('setWidthFor：统一模式下改“所有内容”会应用到当前宽度', async () => {
  const h = makeHarness({ perContent: false })
  await h.controller.start()
  h.applied.length = 0

  const result = await h.controller.setWidthFor('', 'unified', 512)
  assert.equal(result.ok, true)
  assert.deepEqual(h.applied, [512])
  assert.equal(h.table.get('', 'unified'), 512)
  await h.controller.dispose()
})

test('resetWidths：删除存储、清空内存、对齐修订并请求数值默认', async () => {
  const h = makeHarness()
  await h.controller.start()
  h.table.set('kind:files', 'split', 700)
  h.table.set('', 'unified', 640)
  h.cleaned.length = 0
  h.writes.length = 0

  const result = await h.controller.resetWidths()
  assert.equal(result.ok, true)
  assert.equal(h.clears.length, 1, '应删除存储键')
  assert.deepEqual(h.table.serialize(), { schema: 1, split: {}, unified: null }, '内存表清空')
  assert.equal(h.controller.getSnapshot().dirty, false, '删除后不算未落盘')
  assert.equal(h.cleaned.at(-1), '重置已保存的宽度数据')
  assert.equal(h.controller.getSnapshot().lastAction.result.resetLevel, 'numeric')

  // 之后的空表不会再被写回（否则重置等于没做）
  await settleMs(350)
  assert.deepEqual(h.writes, [], '重置后不得写回空表')
  await h.controller.dispose()
})

test('resetWidths：删除失败时数据保持不变并如实报告', async () => {
  const h = makeHarness({ clearFails: true })
  await h.controller.start()
  h.table.set('kind:files', 'split', 700)

  const result = await h.controller.resetWidths()
  assert.equal(result.ok, false)
  assert.match(result.reason, /删除失败/)
  assert.equal(h.table.get('kind:files', 'split'), 700, '数据不变')
  await h.controller.dispose()
})

test('导出：正常数据可往返；保护状态下另有诊断原文导出', async () => {
  const h = makeHarness()
  await h.controller.start()
  h.table.set('kind:files', 'split', 704)
  h.table.set('', 'unified', 640)

  const exported = h.controller.exportWidths()
  assert.deepEqual(JSON.parse(exported.text), { schema: 1, split: { 'kind:files': 704 }, unified: 640 })
  assert.equal(h.controller.exportProblemData(), null, '没有保护时不给诊断原文')

  h.protectStore('{broken json', '解析失败')
  const problem = h.controller.exportProblemData()
  assert.equal(problem.text, '{broken json')
  assert.match(problem.reason, /解析失败/)
  await h.controller.dispose()
})

test('导入：预览不改数据；合法数据确认后被替换、落盘并应用', async () => {
  const h = makeHarness()
  await h.controller.start()
  const payload = JSON.stringify({ schema: 1, split: { 'kind:files': 655 }, unified: 600 })

  const preview = h.controller.previewImport(payload)
  assert.deepEqual(preview.splitKeys, ['kind:files'])
  assert.equal(preview.unified, 600)
  assert.deepEqual(preview.errors, [])
  assert.equal(h.table.get('kind:files', 'split'), null, '预览不改数据')

  h.applied.length = 0
  const committed = await h.controller.commitImport(preview.previewId)
  assert.equal(committed.ok, true)
  assert.equal(h.table.get('kind:files', 'split'), 655)
  assert.equal(h.table.get('', 'unified'), 600)
  assert.deepEqual(h.writes.at(-1).options, { replaceProtected: true }, '导入是显式替换')
  assert.deepEqual(h.applied.at(-1), 655, '导入后按当前内容应用')
  await h.controller.dispose()
})

test('导入：整体错误与未来版本都拒绝确认', async () => {
  const h = makeHarness()
  await h.controller.start()

  const broken = h.controller.previewImport('{not json')
  assert.equal(broken.errors.some(item => item.scope === 'root'), true)
  const refused = await h.controller.commitImport(broken.previewId)
  assert.equal(refused.ok, false)
  assert.match(refused.reason, /没有通过校验/)

  const future = h.controller.previewImport(JSON.stringify({ schema: 99, split: {}, unified: null }))
  assert.equal(future.unsupportedVersion, true)
  const futureRefused = await h.controller.commitImport(future.previewId)
  assert.equal(futureRefused.ok, false)
  await h.controller.dispose()
})

test('导入：预览之后数据变化则拒绝确认（要求重新预览）', async () => {
  const h = makeHarness()
  await h.controller.start()
  const preview = h.controller.previewImport(JSON.stringify({ schema: 1, split: { 'kind:files': 700 }, unified: null }))

  // 期间产生新的用户改动（数据修订号变化）
  h.startDrag()
  h.emitWidth(720)

  const refused = await h.controller.commitImport(preview.previewId)
  assert.equal(refused.ok, false)
  assert.match(refused.reason, /重新预览/)
  await h.controller.dispose()
})
