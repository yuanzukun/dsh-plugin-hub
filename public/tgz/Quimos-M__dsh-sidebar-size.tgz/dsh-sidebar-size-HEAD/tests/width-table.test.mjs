/**
 * M3 宽度表（src/client/width-table.ts）的纯逻辑验证。
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { createWidthTable, MIN_WIDTH } from '../lib/client/width-table.js'

test('空表的读取语义：split 缺键与 unified 未设置都返回 null', () => {
  const table = createWidthTable()
  assert.equal(table.get('kind:files', 'split'), null)
  assert.equal(table.get('kind:files', 'unified'), null)
  assert.deepEqual(table.entries('split'), [])
  assert.deepEqual(table.entries('unified'), [])
})

test('set / get：两套命名空间互不影响，相同值不算变化', () => {
  const table = createWidthTable()
  assert.equal(table.set('kind:files', 'split', 704), 'changed')
  assert.equal(table.set('kind:files', 'split', 704), 'rejected')
  assert.equal(table.set('kind:files', 'unified', 600), 'changed')

  assert.equal(table.get('kind:files', 'split'), 704)
  assert.equal(table.get('kind:files', 'unified'), 600)
  assert.equal(table.get('kind:text', 'unified'), 600)
  assert.equal(table.get('kind:text', 'split'), null)
})

test('非法键与非法宽度被拒绝，不写入', () => {
  const table = createWidthTable()
  assert.equal(table.set('files', 'split', 500), 'rejected')
  assert.equal(table.set('kind:', 'split', 500), 'rejected')
  assert.equal(table.set('kind:files', 'split', MIN_WIDTH - 1), 'rejected')
  assert.equal(table.set('kind:files', 'split', 500.5), 'rejected')
  assert.equal(table.set('kind:files', 'split', Number.NaN), 'rejected')
  assert.equal(table.set('kind:files', 'split', Number.POSITIVE_INFINITY), 'rejected')
  assert.equal(table.set('kind:files', 'split', MIN_WIDTH), 'changed')
  assert.deepEqual(table.entries('split'), [{ key: 'kind:files', kind: 'kind:files', px: MIN_WIDTH }])
})

test('unified 的 null 与 0 语义不同：null 表示未保存', () => {
  const table = createWidthTable()
  const parsed = table.parse({ schema: 1, split: {}, unified: null })
  assert.equal(parsed.table.unified, null)
  assert.equal(parsed.errors.length, 0)

  const zero = table.parse({ schema: 1, split: {}, unified: 0 })
  assert.equal(zero.table.unified, null)
  assert.equal(zero.errors.length, 1)
  assert.match(zero.errors[0].reason, /unified/)
})

test('unified 命名空间不依赖分类键：空键也能写入与读取', () => {
  const table = createWidthTable()
  assert.equal(table.set('', 'unified', 500), 'changed')
  assert.equal(table.get('', 'unified'), 500)
  assert.equal(table.get('kind:files', 'unified'), 500, '统一值对所有类型可见')
  assert.equal(table.set('', 'unified', 500), 'rejected', '同值不算变化')
  assert.equal(table.set('', 'unified', 299), 'rejected', '仍受下限约束')
  assert.deepEqual(table.entries('unified'), [{ key: '', kind: '', px: 500 }])

  // split 仍然要求合法键
  assert.equal(table.set('', 'split', 500), 'rejected')
  assert.equal(table.set('bad-key', 'split', 500), 'rejected')
})

test('parse 逐条剔除非法条目并报告，保留合法项', () => {
  const table = createWidthTable()
  const result = table.parse({
    schema: 1,
    split: {
      'kind:files': 704,
      'kind:text': 299,
      'bad-key': 700,
      'kind:terminal': 'wide',
      'kind:browser': 820,
    },
    unified: 640,
  })

  assert.deepEqual(Object.keys(result.table.split).sort(), ['kind:browser', 'kind:files'])
  assert.equal(result.table.unified, 640)
  assert.equal(result.errors.length, 3)
  assert.deepEqual(result.errors.map(error => error.key).sort(), ['bad-key', 'kind:terminal', 'kind:text'])
  assert.equal(result.unsupportedVersion, false)
})

test('整体损坏与版本不受支持走 root 错误 / unsupportedVersion', () => {
  const table = createWidthTable()

  const notObject = table.parse('nonsense')
  assert.equal(notObject.errors[0].scope, 'root')
  assert.equal(notObject.unsupportedVersion, false)

  const noSchema = table.parse({ split: {} })
  assert.equal(noSchema.errors[0].scope, 'root')

  const future = table.parse({ schema: 99, split: { 'kind:files': 700 }, unified: null })
  assert.equal(future.unsupportedVersion, true)
  assert.equal(future.errors[0].scope, 'root')
  assert.deepEqual(future.table.split, {})

  const older = table.parse({ schema: 0, split: {}, unified: null })
  assert.equal(older.unsupportedVersion, false)
  assert.equal(older.errors[0].scope, 'root')

  const splitNotObject = table.parse({ schema: 1, split: 5, unified: null })
  assert.equal(splitNotObject.errors[0].scope, 'root')
})

test('serialize → parse 往返保持数据；replace 只接受合法项', () => {
  const table = createWidthTable()
  table.set('kind:files', 'split', 704)
  table.set('kind:text', 'split', 618)
  table.set('kind:files', 'unified', 900)

  const snapshot = table.serialize()
  assert.deepEqual(snapshot, { schema: 1, split: { 'kind:files': 704, 'kind:text': 618 }, unified: 900 })

  const other = createWidthTable()
  const parsed = other.parse(snapshot)
  assert.equal(parsed.errors.length, 0)
  other.replace(parsed.table)
  assert.deepEqual(other.serialize(), snapshot)

  other.replace({ schema: 1, split: { bad: 700, 'kind:files': 500 }, unified: 100 })
  assert.deepEqual(other.serialize(), { schema: 1, split: { 'kind:files': 500 }, unified: null })
})

test('entries 返回只读快照：外部改数组不影响内部表；顺序稳定', () => {
  const table = createWidthTable()
  table.set('kind:text', 'split', 600)
  table.set('kind:files', 'split', 700)
  const entries = table.entries('split')
  assert.deepEqual(entries.map(entry => entry.key), ['kind:files', 'kind:text'])

  // 数组本身可变，但改它不应影响表。
  entries.length = 0
  assert.equal(table.get('kind:files', 'split'), 700)
})

test('clearAll 清空两套数据', () => {
  const table = createWidthTable()
  table.set('kind:files', 'split', 700)
  table.set('kind:files', 'unified', 800)
  table.clearAll()
  assert.deepEqual(table.serialize(), { schema: 1, split: {}, unified: null })
})

test('普通对象语义：特殊键不会污染原型链', () => {
  const table = createWidthTable()
  // 键本身必须符合分类键格式，因此真正的 __proto__ 键会被拒绝；
  // 这里验证即便数据里出现该形式，解析也不会改动对象原型。
  const result = table.parse({ schema: 1, split: { __proto__: 700, 'kind:files': 701 }, unified: null })
  assert.deepEqual(Object.keys(result.table.split), ['kind:files'])
  assert.equal(({}).px, undefined)
  assert.equal(table.get('kind:files', 'split'), null) // parse 不改动当前表
})
