/**
 * M2 分类键（src/client/content-kind.ts）的纯逻辑验证。
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { classify, decodeKind, describe, encodeKind, isContentKey } from '../lib/client/content-kind.js'

test('普通类型名生成稳定的键', () => {
  assert.equal(encodeKind('files'), 'kind:files')
  assert.equal(encodeKind('  text  '), 'kind:text')
})

test('需要转义的字符可逆，且键里不出现冒号或空白', () => {
  const tricky = 'a b:c/d%🦈'
  const key = encodeKind(tricky)
  assert.equal(key.startsWith('kind:'), true)
  assert.equal(key.slice(5).includes(':'), false)
  assert.equal(key.slice(5).includes(' '), false)
  assert.equal(decodeKind(key), tricky)
})

test('空串、非字符串与只有空白都不生成键（unavailable，不产生兜底记录）', () => {
  for (const value of ['', '   ', undefined, null, 42, {}]) {
    assert.equal(encodeKind(value), null)
  }
})

test('键格式校验拒绝非法形式', () => {
  assert.equal(isContentKey('kind:files'), true)
  assert.equal(isContentKey('files'), false)
  assert.equal(isContentKey('kind:'), false)
  assert.equal(isContentKey('kind:%ZZZZ'), false)
  assert.equal(isContentKey('kind:a:b'), false)
  assert.equal(isContentKey('kind:%0031'), true) // '1'
  assert.equal(decodeKind('kind:%0031'), '1')
})

test('classify 由活动内容得到键，读不到内容时 unavailable', () => {
  const keyed = classify({ sessionId: 's', paneId: 'p', tabId: 't', kind: 'files', contentId: 'x' })
  assert.equal(keyed.kind, 'keyed')
  assert.equal(keyed.kind === 'keyed' ? keyed.key : '', 'kind:files')

  assert.equal(classify(undefined).kind, 'unavailable')
  assert.equal(classify({ sessionId: 's', paneId: 'p', tabId: 't', kind: '', contentId: undefined }).kind, 'unavailable')
})

test('不同未知类型保留各自的键，不因显示文案相同而合并', () => {
  const left = encodeKind('third-party-a')
  const right = encodeKind('third-party-b')
  assert.notEqual(left, right)
  assert.equal(describe(left).labelFallback, '其他类型：third-party-a')
  assert.equal(describe(right).labelFallback, '其他类型：third-party-b')
})

test('已知类型给出中文名，非法键给出兜底文案', () => {
  assert.deepEqual(describe('kind:files'), { kind: 'files', labelFallback: '文件' })
  assert.deepEqual(describe('kind:terminal'), { kind: 'terminal', labelFallback: '终端' })
  assert.equal(describe('nonsense').labelFallback, '未知类型')
})
