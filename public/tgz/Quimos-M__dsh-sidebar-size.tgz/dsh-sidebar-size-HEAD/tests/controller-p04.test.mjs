/**
 * P04：拖拽 → 内存记忆 → 重开恢复（不落盘）的控制器行为验证。
 *
 * 用假 M1 发送真实拖拽信号与尺寸采样，验证：
 *   * 只有从手柄开始、且在提交窗口内的采样才进入内存表；
 *   * 环境来源（valid=false）不产生记录；
 *   * 手势中切换内容时归属仍是按下时的类型；
 *   * 抬起后的最终采样被采纳；
 *   * 重开右栏时从内存恢复（程序应用不产生新记录）；
 *   * 本阶段**不写持久化存储**（writeAll 从未被调用）。
 *
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { createController } from '../lib/client/controller.js'
import { createRootLifecycle } from '../lib/client/lifecycle.js'
import { createWidthTable } from '../lib/client/width-table.js'

const PANEL = { sessionId: 'session-1', elementId: 'el-1' }

function makeHarness({ presentation = 'push', kind = 'files' } = {}) {
  const table = createWidthTable()
  const writes = []
  const applied = []
  const cleaned = []
  const listeners = { structure: new Set(), drag: new Set(), width: new Set() }
  const state = { presentation, kind }

  const store = {
    async readAll() { return { kind: 'empty' } },
    protect() {},
    async writeAll(value) { writes.push(value); return { ok: true, durable: true } },
    async clearAll() { return { ok: true, durable: true } },
    getStatus: () => ({ available: true, writable: true, protected: false }),
  }

  const prefs = {
    getSnapshot: () => ({ state: 'ready', enabled: true, perContent: true, revision: 1, writable: true, mode: 'host' }),
    subscribe: () => () => {},
    async ensure() { return this.getSnapshot() },
    async update() { return { ok: true, snapshot: this.getSnapshot() } },
    dispose() {},
  }

  const host = {
    readView: () => ({
      sessionId: 'session-1',
      panelIdentity: PANEL,
      expanded: state.presentation === 'push',
      presentation: state.presentation,
      framePx: 1280,
      observedPx: 576,
      activeDockContent: state.kind === null
        ? undefined
        : { sessionId: 'session-1', paneId: 'pane-0', tabId: 'tab1', kind: state.kind, contentId: 'file:///a' },
      availability: { kind: 'ready' },
    }),
    observeStructure(listener) { listeners.structure.add(listener); return () => listeners.structure.delete(listener) },
    observeDrag(listener) { listeners.drag.add(listener); return () => listeners.drag.delete(listener) },
    observeWidth(listener) { listeners.width.add(listener); return () => listeners.width.delete(listener) },
    async readFinalDragSample() { return state.finalSample ?? null },
    async applyWidth(px) { applied.push(px); return { status: 'applied', requestedPx: px, observedPx: px } },
    async restoreDefault(reason) { cleaned.push(reason); return { status: 'applied', requestedPx: 576, observedPx: 576, resetLevel: 'numeric' } },
    dispose() {},
  }

  const logs = []
  const controller = createController({
    lifecycle: createRootLifecycle(),
    prefs,
    store,
    table,
    host,
    log: line => logs.push(line),
  })

  return {
    controller, table, writes, applied, cleaned, logs, state,
    emitDrag: signal => { for (const listener of listeners.drag) listener(signal) },
    emitWidth: sample => { for (const listener of listeners.width) listener(sample) },
    emitStructure: () => { for (const listener of listeners.structure) listener() },
    dragSignal: (kindName, pointerId = 1) => (
      kindName === 'pointer-down'
        ? { kind: 'pointer-down', pointerId, panelIdentity: PANEL }
        : { kind: kindName, pointerId }
    ),
    widthSample: (px, overrides = {}) => ({
      px,
      panelIdentity: PANEL,
      pointerCommitSeq: 1,
      geometryGeneration: 10,
      phase: 'dragging',
      valid: true,
      ...overrides,
    }),
  }
}

const settleMs = ms => new Promise(resolve => setTimeout(resolve, ms))

test('真实拖拽写入内存表，但本阶段不落盘', async () => {
  const h = makeHarness()
  await h.controller.start()

  h.emitDrag(h.dragSignal('pointer-down'))
  h.emitWidth(h.widthSample(700))
  h.emitWidth(h.widthSample(712))

  assert.equal(h.table.get('kind:files', 'split'), 712)
  assert.equal(h.controller.getSnapshot().dirty, true, '内存有改动应标记未落盘')
  assert.equal(h.writes.length, 0, '合并窗口内还没有落盘')
  assert.equal(h.controller.getSnapshot().savedEntries.length, 1)

  await h.controller.dispose()
})

test('环境来源采样（valid=false）不产生任何记录', async () => {
  const h = makeHarness()
  await h.controller.start()

  h.emitWidth(h.widthSample(900, { valid: false, pointerCommitSeq: null, phase: 'idle' }))
  assert.equal(h.table.get('kind:files', 'split'), null)

  // 没有 pointerdown 时，即使采样标记为 valid 也不接受。
  h.emitWidth(h.widthSample(880))
  assert.equal(h.table.get('kind:files', 'split'), null)

  await h.controller.dispose()
})

test('手势中切换内容：宽度仍记在按下时的类型上', async () => {
  const h = makeHarness({ kind: 'files' })
  await h.controller.start()

  h.emitDrag(h.dragSignal('pointer-down'))
  h.emitWidth(h.widthSample(650))
  // 手势进行中用户切到 terminal
  h.state.kind = 'terminal'
  h.emitWidth(h.widthSample(660))

  assert.equal(h.table.get('kind:files', 'split'), 660)
  assert.equal(h.table.get('kind:terminal', 'split'), null)

  await h.controller.dispose()
})

test('抬起后的最终采样被采纳，且不覆盖为环境值', async () => {
  const h = makeHarness()
  await h.controller.start()

  h.emitDrag(h.dragSignal('pointer-down'))
  h.emitWidth(h.widthSample(700))
  h.state.finalSample = h.widthSample(724, { phase: 'ending' })
  h.emitDrag(h.dragSignal('pointer-up'))

  await settleMs(400)
  assert.equal(h.table.get('kind:files', 'split'), 724, '抬起后的最终位置应写入')
  assert.ok(h.logs.some(line => line.includes('内存表更新')))

  await h.controller.dispose()
})

test('重开右栏时从内存恢复：程序应用不产生新记录', async () => {
  const h = makeHarness()
  await h.controller.start()

  h.emitDrag(h.dragSignal('pointer-down'))
  h.emitWidth(h.widthSample(688))
  h.emitDrag(h.dragSignal('pointer-up'))
  await settleMs(400) // 等 M4 的 Ending 窗口结束 + 手势结束冲刷
  h.applied.length = 0
  const writesAfterDrag = h.writes.length
  assert.equal(writesAfterDrag, 1, 'P05 起：手势结束会把这一条改动落盘一次')

  // 折叠再打开：结构变化触发重新结算，上升沿应恢复内存值。
  h.state.presentation = 'collapsed'
  h.emitStructure()
  h.state.presentation = 'push'
  h.emitStructure()
  await settleMs(20)

  assert.deepEqual(h.applied, [688], '应把内存里的宽度写回宿主')
  assert.equal(h.table.get('kind:files', 'split'), 688, '程序应用不改变记录')
  assert.equal(h.writes.length, writesAfterDrag, '程序应用不再写存储')

  await h.controller.dispose()
})

test('手势进行中不应用宽度（等手势结束再恢复）', async () => {
  const h = makeHarness()
  await h.controller.start()

  h.emitDrag(h.dragSignal('pointer-down'))
  h.emitWidth(h.widthSample(688))
  h.applied.length = 0

  // 手势尚未结束就折叠/展开：不应写宿主
  h.state.presentation = 'collapsed'
  h.emitStructure()
  h.state.presentation = 'push'
  h.emitStructure()
  await settleMs(20)
  assert.deepEqual(h.applied, [], '手势中不得应用宽度')

  h.emitDrag(h.dragSignal('pointer-up'))
  await settleMs(400)
  h.applied.length = 0
  h.state.presentation = 'collapsed'
  h.emitStructure()
  h.state.presentation = 'push'
  h.emitStructure()
  await settleMs(20)
  assert.deepEqual(h.applied, [688], '手势结束后的重新就绪应恢复内存值')

  await h.controller.dispose()
})

test('切换到没有记录的类型时请求数值默认，不沿用上一个类型的值', async () => {
  const h = makeHarness({ kind: 'files' })
  await h.controller.start()

  h.emitDrag(h.dragSignal('pointer-down'))
  h.emitWidth(h.widthSample(688))
  h.emitDrag(h.dragSignal('pointer-up'))
  await settleMs(400)
  h.applied.length = 0
  h.cleaned.length = 0

  h.state.kind = 'terminal'
  h.emitStructure()
  await settleMs(20)

  assert.deepEqual(h.cleaned.map(reason => reason.includes('没有该类型的记录')), [true])
  assert.deepEqual(h.applied, [], '没有记录时不应沿用其他类型的值')

  await h.controller.dispose()
})

test('P08：高频采样逐条更新内存，但日志按间隔收敛、结束时汇总一次', async () => {
  const h = makeHarness()
  await h.controller.start()
  h.logs.length = 0

  h.emitDrag(h.dragSignal('pointer-down'))
  for (let index = 0; index < 30; index += 1) h.emitWidth(h.widthSample(600 + index))

  const during = h.logs.filter(line => line.includes('内存表更新')).length
  assert.ok(during <= 2, `30 条逐帧采样只应产生很少日志行，实际 ${during}`)
  assert.equal(h.table.get('kind:files', 'split'), 629, '内存仍然逐条及时更新')

  h.emitDrag(h.dragSignal('pointer-up'))
  await settleMs(400)
  assert.ok(
    h.logs.some(line => line.includes('手势结束：共接受 30 条合法采样，最终 629px')),
    '手势结束要汇总一条，便于排查而不刷屏',
  )
  await h.controller.dispose()
})


