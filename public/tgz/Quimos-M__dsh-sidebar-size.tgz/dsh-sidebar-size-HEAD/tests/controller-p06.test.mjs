/**
 * P06：按内容区分与统一模式的两套记忆切换（实现规划 4.4 / S7—S10）。
 *
 * 覆盖：
 *   * 关闭区分功能：有统一值恢复统一值；没有则请求数值默认，**不搬用当前类型的值**；
 *   * 开启区分功能：按当前类型查记录；没有则请求默认，**不复制统一值**；
 *   * 两套数据互不覆盖（写入路径按采样时捕获的模式）；
 *   * 手势进行中切换模式会推迟到手势结束；
 *   * 切换后的落盘同时保留两套数据。
 *
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { createController } from '../lib/client/controller.js'
import { createRootLifecycle } from '../lib/client/lifecycle.js'
import { createWidthTable } from '../lib/client/width-table.js'

const PANEL = { sessionId: 'session-1', elementId: 'el-1' }
const settleMs = ms => new Promise(resolve => setTimeout(resolve, ms))

function makeHarness({ kind = 'files', perContent = true } = {}) {
  const table = createWidthTable()
  const applied = []
  const cleaned = []
  const logs = []
  const writes = []
  const listeners = { structure: new Set(), drag: new Set(), width: new Set() }
  const state = { presentation: 'push', kind, finalSample: null }

  // 注意：真实 M8 每次返回**新的**快照对象；这里必须保持同样的不可变语义，
  // 否则订阅回调里比较 previous/next 会看到同一个引用，模式切换就检测不到。
  let prefsSnapshot = { state: 'ready', enabled: true, perContent, revision: 1, writable: true, mode: 'host' }
  const prefsListeners = new Set()
  const prefs = {
    getSnapshot: () => prefsSnapshot,
    subscribe(listener) { prefsListeners.add(listener); return () => prefsListeners.delete(listener) },
    async ensure() { return prefsSnapshot },
    async update(patch) {
      prefsSnapshot = { ...prefsSnapshot, ...patch, revision: prefsSnapshot.revision + 1 }
      for (const listener of prefsListeners) listener(prefsSnapshot)
      return { ok: true, snapshot: prefsSnapshot }
    },
    dispose() {},
  }

  const host = {
    readView: () => ({
      sessionId: 'session-1',
      panelIdentity: PANEL,
      expanded: state.presentation === 'push',
      presentation: state.presentation,
      framePx: 1280,
      observedPx: 576,
      activeDockContent: { sessionId: 'session-1', paneId: 'pane-0', tabId: 'tab1', kind: state.kind, contentId: 'f' },
      availability: { kind: 'ready' },
    }),
    observeStructure(listener) { listeners.structure.add(listener); return () => listeners.structure.delete(listener) },
    observeDrag(listener) { listeners.drag.add(listener); return () => listeners.drag.delete(listener) },
    observeWidth(listener) { listeners.width.add(listener); return () => listeners.width.delete(listener) },
    async readFinalDragSample() { return state.finalSample },
    async applyWidth(px) { applied.push(px); return { status: 'applied', requestedPx: px, observedPx: px } },
    async restoreDefault(reason) { cleaned.push(reason); return { status: 'applied', requestedPx: 576, observedPx: 576, resetLevel: 'numeric' } },
    dispose() {},
  }

  const controller = createController({
    lifecycle: createRootLifecycle(),
    prefs, table, host,
    store: {
      async readAll() { return { kind: 'empty' } },
      protect() {},
      async writeAll(value) { writes.push(value); return { ok: true, durable: true } },
      async clearAll() { return { ok: true, durable: true } },
      getStatus: () => ({ available: true, writable: true, protected: false }),
    },
    log: line => logs.push(line),
  })

  return {
    controller, table, applied, cleaned, logs, writes, state, prefsSnapshot,
    setPerContent: async (next) => { await prefs.update({ perContent: next }) },
    emitStructure: () => { for (const listener of listeners.structure) listener() },
    startDrag: () => { for (const listener of listeners.drag) listener({ kind: 'pointer-down', pointerId: 1, panelIdentity: PANEL }) },
    endDrag: () => { for (const listener of listeners.drag) listener({ kind: 'pointer-up', pointerId: 1 }) },
    sample: (px, overrides = {}) => {
      for (const listener of listeners.width) {
        listener({ px, panelIdentity: PANEL, pointerCommitSeq: 1, geometryGeneration: 5, phase: 'dragging', valid: true, ...overrides })
      }
    },
    doDrag: async (px) => {
      for (const listener of listeners.drag) listener({ kind: 'pointer-down', pointerId: 1, panelIdentity: PANEL })
      for (const listener of listeners.width) {
        listener({ px, panelIdentity: PANEL, pointerCommitSeq: 1, geometryGeneration: 5, phase: 'dragging', valid: true })
      }
      for (const listener of listeners.drag) listener({ kind: 'pointer-up', pointerId: 1 })
      await settleMs(400)
    },
  }
}

test('关闭区分功能：已有统一值时恢复统一值，不用当前类型的值', async () => {
  const h = makeHarness()
  await h.controller.start()
  h.table.set('kind:files', 'split', 426)
  h.table.set('', 'unified', 500)
  h.applied.length = 0
  h.cleaned.length = 0

  await h.setPerContent(false)
  await settleMs(20)

  assert.deepEqual(h.applied, [500], '应恢复统一值')
  assert.equal(h.cleaned.length, 0, '有统一值就不该走默认')
  assert.equal(h.table.get('kind:files', 'split'), 426, '类型记录不受影响')
  await h.controller.dispose()
})

test('关闭区分功能且没有统一值：请求数值默认，不搬用类型值', async () => {
  const h = makeHarness()
  await h.controller.start()
  h.table.set('kind:files', 'split', 426)
  h.applied.length = 0
  h.cleaned.length = 0

  await h.setPerContent(false)
  await settleMs(20)

  assert.deepEqual(h.applied, [], '不得把当前类型的值当成统一值')
  assert.equal(h.cleaned.length, 1)
  assert.match(h.cleaned[0], /统一/)
  assert.equal(h.table.get('', 'unified'), null, '统一值仍为空')
  await h.controller.dispose()
})

test('开启区分功能：按当前类型恢复；没有该类型记录则默认，不复制统一值', async () => {
  const h = makeHarness({ perContent: false })
  await h.controller.start()
  h.table.set('', 'unified', 500)
  h.table.set('kind:files', 'split', 426)
  h.applied.length = 0
  h.cleaned.length = 0

  await h.setPerContent(true)
  await settleMs(20)
  assert.deepEqual(h.applied, [426], '恢复当前类型的记录')
  assert.equal(h.table.get('', 'unified'), 500, '统一值保留')

  // 换到没有记录的类型再切一次
  h.state.kind = 'terminal'
  h.emitStructure()
  await settleMs(20)
  h.applied.length = 0
  h.cleaned.length = 0
  await h.setPerContent(false) // 切到统一模式：有统一值 500，应用它是正确行为
  await settleMs(20)
  assert.deepEqual(h.applied, [500], '统一模式恢复统一值')

  h.applied.length = 0
  h.cleaned.length = 0
  await h.setPerContent(true) // 回到区分模式：terminal 没有记录
  await settleMs(20)
  assert.deepEqual(h.applied, [], 'terminal 没有记录，不得复制统一值')
  assert.equal(h.cleaned.length >= 1, true)
  assert.equal(h.table.get('kind:terminal', 'split'), null)
  await h.controller.dispose()
})

test('两套数据互不覆盖：各自模式下的拖拽写各自的命名空间', async () => {
  const h = makeHarness()
  await h.controller.start()

  await h.doDrag(426) // 区分模式 → split
  assert.deepEqual(h.table.serialize().split, { 'kind:files': 426 })
  assert.equal(h.table.serialize().unified, null)

  await h.setPerContent(false)
  await settleMs(20)
  await h.doDrag(511) // 统一模式 → unified
  const after = h.table.serialize()
  assert.equal(after.unified, 511, '统一模式写入 unified')
  assert.deepEqual(after.split, { 'kind:files': 426 }, '区分记录不被覆盖')

  await h.setPerContent(true)
  await settleMs(20)
  const final = h.table.serialize()
  assert.deepEqual(final.split, { 'kind:files': 426 })
  assert.equal(final.unified, 511)
  assert.equal(h.writes.at(-1).unified !== undefined, true, '落盘形状同时包含两套')
  await h.controller.dispose()
})

test('手势进行中切换模式：先按捕获的归属写完，再补做切换', async () => {
  const h = makeHarness()
  await h.controller.start()
  h.table.set('', 'unified', 500)
  h.applied.length = 0
  h.cleaned.length = 0

  h.startDrag()
  h.sample(700)
  await h.setPerContent(false) // 手势中点开关
  await settleMs(10)

  assert.equal(h.table.get('kind:files', 'split'), 700, '采样仍写按下时捕获的 split')
  assert.equal(h.table.get('', 'unified'), 500, '统一值未被覆盖')
  assert.deepEqual(h.applied, [], '手势中不应用宽度')

  h.endDrag()
  await settleMs(400)
  assert.ok(h.logs.some(line => line.includes('模式切换暂缓')), '切换被推迟')
  assert.equal(h.applied.at(-1), 500, '手势结束后补做统一模式的应用')
  await h.controller.dispose()
})
