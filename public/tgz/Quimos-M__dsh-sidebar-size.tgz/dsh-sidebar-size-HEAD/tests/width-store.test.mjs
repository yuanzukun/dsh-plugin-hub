/**
 * M5 显式存储（src/client/width-store.ts）的纯逻辑验证：正常路径与全部失败路径。
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { createWidthStore, WIDTHS_KEY } from '../lib/client/width-store.js'

/** 可控的假存储。 */
function makeStorage(initial = {}) {
  const data = new Map(Object.entries(initial))
  const calls = []
  let failGet = null
  let failSet = null
  let failRemove = null
  return {
    calls,
    data,
    storage: {
      getItem(key) {
        calls.push(['get', key])
        if (failGet !== null) throw failGet
        return data.has(key) ? data.get(key) : null
      },
      setItem(key, value) {
        calls.push(['set', key, value])
        if (failSet !== null) throw failSet
        data.set(key, value)
      },
      removeItem(key) {
        calls.push(['remove', key])
        if (failRemove !== null) throw failRemove
        data.delete(key)
      },
    },
    failWith({ get, set, remove }) {
      if (get !== undefined) failGet = get
      if (set !== undefined) failSet = set
      if (remove !== undefined) failRemove = remove
    },
  }
}

const SAMPLE = { schema: 1, split: { 'kind:files': 704 }, unified: null }

test('读取：空、已加载、存储不可用、读取抛错', async () => {
  const ok = makeStorage()
  const store = createWidthStore({ storage: ok.storage })
  assert.deepEqual(await store.readAll(), { kind: 'empty' })

  ok.data.set(WIDTHS_KEY, '{"schema":1}')
  assert.deepEqual(await store.readAll(), { kind: 'loaded', rawText: '{"schema":1}' })

  const missing = createWidthStore({ storage: undefined, key: 'x' })
  // 没有注入 storage 时退回 globalThis.localStorage（测试环境里不存在）
  const result = await missing.readAll()
  assert.equal(result.kind, 'unavailable')

  const broken = makeStorage()
  broken.failWith({ get: new Error('quota') })
  const brokenStore = createWidthStore({ storage: broken.storage })
  const failed = await brokenStore.readAll()
  assert.equal(failed.kind, 'unavailable')
  assert.match(failed.reason, /quota/)
  assert.equal(brokenStore.getStatus().available, true)
})

test('写入使用独占键并可通过读取拿回同一份数据', async () => {
  const fake = makeStorage()
  const store = createWidthStore({ storage: fake.storage })
  const written = await store.writeAll(SAMPLE)
  assert.equal(written.ok, true)
  assert.equal(written.durable, true)
  assert.deepEqual(fake.calls[0], ['set', WIDTHS_KEY, JSON.stringify(SAMPLE)])
  assert.deepEqual(await store.readAll(), { kind: 'loaded', rawText: JSON.stringify(SAMPLE) })
})

test('保护状态阻止普通写入，只有显式替换才放行', async () => {
  const fake = makeStorage()
  const store = createWidthStore({ storage: fake.storage })
  store.protect('{broken json', '解析失败')

  const status = store.getStatus()
  assert.equal(status.protected, true)
  assert.equal(status.rawProblemText, '{broken json')

  const blocked = await store.writeAll(SAMPLE)
  assert.equal(blocked.ok, false)
  assert.equal(blocked.protected, true)
  assert.match(blocked.reason, /受保护/)

  const replaced = await store.writeAll(SAMPLE, { replaceProtected: true })
  assert.equal(replaced.ok, true)
  assert.equal(store.getStatus().protected, false)
  assert.equal(store.getStatus().rawProblemText, undefined)
})

test('写入失败：报告原因且不解除保护', async () => {
  const fake = makeStorage()
  const store = createWidthStore({ storage: fake.storage })
  store.protect('{broken', '解析失败')
  fake.failWith({ set: new Error('quota exceeded') })

  const result = await store.writeAll(SAMPLE, { replaceProtected: true })
  assert.equal(result.ok, false)
  assert.equal(result.durable, false)
  assert.match(result.reason, /quota exceeded/)
  assert.equal(store.getStatus().protected, true)
  assert.equal(store.getStatus().error, 'quota exceeded')
})

test('清除：成功解除保护；失败保留原文且不报成功', async () => {
  const fake = makeStorage()
  const store = createWidthStore({ storage: fake.storage })
  store.protect('{broken', '解析失败')

  fake.failWith({ remove: new Error('denied') })
  const failed = await store.clearAll()
  assert.equal(failed.ok, false)
  assert.match(failed.reason, /denied/)
  assert.equal(store.getStatus().protected, true)
  assert.equal(store.getStatus().rawProblemText, '{broken')

  fake.failWith({ remove: null })
  const ok = await store.clearAll()
  assert.equal(ok.ok, true)
  assert.equal(ok.durable, true)
  assert.equal(store.getStatus().protected, false)
  assert.equal(fake.data.has(WIDTHS_KEY), false)
})

test('存储不可用时写入与清除都明确失败', async () => {
  const store = createWidthStore({ storage: undefined })
  const write = await store.writeAll(SAMPLE)
  assert.equal(write.ok, false)
  assert.match(write.reason, /localStorage/)
  const clear = await store.clearAll()
  assert.equal(clear.ok, false)
})

test('正式键名固定为 dsh-sidebar-size.widths.v1', () => {
  assert.equal(WIDTHS_KEY, 'dsh-sidebar-size.widths.v1')
})
