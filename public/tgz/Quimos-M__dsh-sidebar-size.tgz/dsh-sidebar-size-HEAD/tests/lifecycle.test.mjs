/**
 * 根生命周期（src/client/lifecycle.ts）的纯逻辑验证。
 *
 * 这一层检查不能证明插件能被 DSH 加载，只证明释放集合的规则本身正确：逆序释放、幂等、
 * 单个释放步骤抛错不影响其余资源、释放后登记的释放函数立即执行。
 *
 * 运行：`pnpm test`（node --test）。
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { createRootLifecycle } from '../lib/client/lifecycle.js'

test('未释放时登记的资源计入 pendingCount', () => {
  const lifecycle = createRootLifecycle()
  assert.equal(lifecycle.disposed, false)
  assert.equal(lifecycle.pendingCount, 0)
  lifecycle.addDisposer(() => {}, 'a')
  lifecycle.addDisposer(() => {}, 'b')
  assert.equal(lifecycle.pendingCount, 2)
})

test('释放时逆序调用全部释放函数，并清空集合', () => {
  const order = []
  const lifecycle = createRootLifecycle()
  lifecycle.addDisposer(() => order.push('first'), 'first')
  lifecycle.addDisposer(() => order.push('second'), 'second')
  lifecycle.addDisposer(() => order.push('third'), 'third')

  lifecycle.dispose()

  assert.deepEqual(order, ['third', 'second', 'first'])
  assert.equal(lifecycle.disposed, true)
  assert.equal(lifecycle.pendingCount, 0)
})

test('重复释放是幂等的（第二次不再调用任何释放函数）', () => {
  let calls = 0
  const lifecycle = createRootLifecycle()
  lifecycle.addDisposer(() => { calls += 1 }, 'counter')

  lifecycle.dispose()
  lifecycle.dispose()
  lifecycle.dispose()

  assert.equal(calls, 1)
})

test('单个释放函数抛错不影响其余资源，并报告一次', () => {
  const warnings = []
  const order = []
  const lifecycle = createRootLifecycle((message, error) => {
    warnings.push([message, String(error)])
  })
  lifecycle.addDisposer(() => order.push('outer-first'), 'outer-first')
  lifecycle.addDisposer(() => { throw new Error('boom') }, 'broken')
  lifecycle.addDisposer(() => order.push('outer-last'), 'outer-last')

  lifecycle.dispose()

  // 逆序：outer-last → broken（抛错）→ outer-first
  assert.deepEqual(order, ['outer-last', 'outer-first'])
  assert.equal(warnings.length, 1)
  assert.match(warnings[0][0], /broken/)
  assert.match(warnings[0][1], /boom/)
  assert.equal(lifecycle.disposed, true)
})

test('释放之后登记的资源立即释放，不留在已结束的生命周期上', () => {
  const order = []
  const lifecycle = createRootLifecycle()
  lifecycle.dispose()

  lifecycle.addDisposer(() => order.push('late'), 'late')

  assert.deepEqual(order, ['late'])
  assert.equal(lifecycle.pendingCount, 0)
})

test('释放函数抛错时也不外抛（调用方无需再包 try/catch）', () => {
  const lifecycle = createRootLifecycle(() => {
    throw new Error('warn 也失败')
  })
  lifecycle.addDisposer(() => { throw new Error('boom') }, 'broken')

  assert.doesNotThrow(() => lifecycle.dispose())
})
