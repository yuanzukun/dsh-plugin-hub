/**
 * P11 #3（D-002）的链与解析验证：`本类型记录 → 上级记录 → … → 根记录 → 默认`。
 *
 * 六条判据（规划案 §9.5）：①子无记录用父值 ②子有记录用子值 ③父无记录上溯到根
 * ④全链无记录落默认 ⑤解析只读（不落盘） ⑥未登记 kind 有确定行为。
 *
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { encodeKind, inheritanceChain, resolveWidth, ROOT_KIND } from '../lib/client/content-kind.js'

/** 用一张“记录表”造查表回调，并统计调用次数。 */
function table(records) {
  const calls = []
  return {
    calls,
    lookup: (key) => {
      calls.push(key)
      return Object.prototype.hasOwnProperty.call(records, key) ? records[key] : null
    },
  }
}

test('链：引导页为根，文件页在其下，文档类在文件页下；未登记 kind 挂根', () => {
  assert.equal(ROOT_KIND, 'guide')
  assert.deepEqual(inheritanceChain('kind:editor'), ['kind:files', 'kind:guide'])
  assert.deepEqual(inheritanceChain('kind:text'), ['kind:files', 'kind:guide'])
  assert.deepEqual(inheritanceChain('kind:files'), ['kind:guide'])
  assert.deepEqual(inheritanceChain('kind:guide'), [])
  // 终端/浏览器/第三方未登记 kind：上级 = 根
  for (const kind of ['terminal', 'browser', 'third-party-a']) {
    assert.deepEqual(inheritanceChain(`kind:${kind}`), ['kind:guide'], `${kind} 应挂在根下`)
  }
  // 带特殊字符的第三方 kind 必须经 encodeKind 转义后才能成为合法键（转义用小写十六进制）
  const escaped = encodeKind('better-sidebar:chat')
  assert.equal(escaped, 'kind:better-sidebar%003achat')
  assert.deepEqual(inheritanceChain(escaped), ['kind:guide'])
  // 手工拼接的裸冒号键不是合法键 → 没有链（这是正确行为，不是缺口）
  assert.deepEqual(inheritanceChain('kind:better-sidebar:chat'), [])
  // 非法键没有链
  assert.deepEqual(inheritanceChain('nonsense'), [])
  assert.deepEqual(inheritanceChain('kind:'), [])
})

test('判据①：子类型没有记录时用父类型的记录（继承，不落盘）', () => {
  const store = table({ 'kind:files': 400 })
  const result = resolveWidth({ key: 'kind:editor', own: null, lookup: store.lookup })
  assert.deepEqual(result, { value: 400, origin: 'inherited', fromKey: 'kind:files' })
  assert.deepEqual(store.calls, ['kind:files'], '找到就停，不再往上问')
})

test('判据②：子类型有记录时用自己的（不因父有记录而改变）', () => {
  const store = table({ 'kind:files': 400, 'kind:editor': 700 })
  const result = resolveWidth({ key: 'kind:editor', own: 700, lookup: store.lookup })
  assert.deepEqual(result, { value: 700, origin: 'own', fromKey: 'kind:editor' })
  assert.deepEqual(store.calls, [], '自身有记录时根本不需要查表')
})

test('判据③：父类型也没有记录时上溯到根（引导页）', () => {
  const store = table({ 'kind:guide': 400 })
  const result = resolveWidth({ key: 'kind:editor', own: null, lookup: store.lookup })
  assert.deepEqual(result, { value: 400, origin: 'inherited', fromKey: 'kind:guide' })
  assert.deepEqual(store.calls, ['kind:files', 'kind:guide'])
})

test('判据④：整条链都没有记录时落默认（value 为 null，由上层请求 DSH 默认）', () => {
  const store = table({ 'kind:terminal': 555 })
  const result = resolveWidth({ key: 'kind:editor', own: null, lookup: store.lookup })
  assert.deepEqual(result, { value: null, origin: 'default', fromKey: null }, '兄弟类型的记录不得被沿用')
  assert.equal(store.calls.includes('kind:terminal'), false, '绝不横向取兄弟类型的值')
})

test('判据⑤：解析只读——lookup 被调用但没有任何写入面', () => {
  const writes = []
  const lookup = (key) => {
    // 一个“会在被读时写东西”的替身：如果解析路径写表，这里会记录到
    return key === 'kind:guide' ? 400 : null
  }
  const result = resolveWidth({ key: 'kind:editor', own: null, lookup: (key) => { writes.push(key); return lookup(key) } })
  assert.equal(result.origin, 'inherited')
  assert.deepEqual(writes, ['kind:files', 'kind:guide'], '读取路径只“问”，不含任何“写”')
})

test('判据⑥：未登记 kind 的解析行为确定（继承根，找不到则默认）', () => {
  const withRoot = table({ 'kind:guide': 400 })
  assert.deepEqual(
    resolveWidth({ key: 'kind:third-party-a', own: null, lookup: withRoot.lookup }),
    { value: 400, origin: 'inherited', fromKey: 'kind:guide' },
  )
  const empty = table({})
  assert.deepEqual(
    resolveWidth({ key: 'kind:third-party-a', own: null, lookup: empty.lookup }),
    { value: null, origin: 'default', fromKey: null },
  )
})

test('边界：没有当前内容（key 为 null）时直接落默认，且 own 优先', () => {
  const store = table({ 'kind:guide': 400 })
  assert.deepEqual(
    resolveWidth({ key: null, own: null, lookup: store.lookup }),
    { value: null, origin: 'default', fromKey: null },
  )
  assert.deepEqual(
    resolveWidth({ key: null, own: 640, lookup: store.lookup }),
    { value: 640, origin: 'own', fromKey: null },
  )
})
