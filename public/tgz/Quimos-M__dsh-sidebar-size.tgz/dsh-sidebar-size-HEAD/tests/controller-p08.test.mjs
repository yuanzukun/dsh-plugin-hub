/**
 * P08：故障与边界情境的控制器行为（实现规划第 9 部分 E1—E21 中的可自动覆盖项）。
 *
 * 覆盖：
 *   * E11 布局约束：请求值与宿主实际值不同时保留意图，窗口变大后重试；未受约束则不重复应用；
 *   * E13 全屏：暂停正常宽度应用与保存，退出后按当前表恢复；
 *   * E14 正常列解算为 0 / 宿主折叠：不保存 0，重新可用后按当前表应用；
 *   * E20 旧异步任务晚到：已经在飞的写入先完成，随后才删除/替换，且不会被写回。
 *
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { createController } from '../lib/client/controller.js'
import { createRootLifecycle } from '../lib/client/lifecycle.js'
import { createWidthTable } from '../lib/client/width-table.js'

const PANEL = { sessionId: 'session-1', elementId: 'el-1' }
const settleMs = ms => new Promise(resolve => setTimeout(resolve, ms))

function makeHarness({ manualWrites = false, watchdogMs = null, writeDelayMs = 0 } = {}) {
  const table = createWidthTable()
  const applied = []
  const cleaned = []
  const logs = []
  const events = []
  const listeners = { structure: new Set(), drag: new Set(), width: new Set() }
  const state = { presentation: 'push', kind: 'files', framePx: 1280, observed: null, samplePx: null, healthy: true, canWrite: true }
  const pendingWrites = []

  const store = {
    async readAll() { return { kind: 'empty' } },
    protect() {},
    writeAll(value) {
      events.push({ kind: 'write', split: JSON.stringify(value.split) })
      if (manualWrites) return new Promise((resolve) => { pendingWrites.push({ value, resolve }) })
      // 有延迟但必然完成：用来制造“旧快照正在写”的窗口，又不会让测试挂住。
      if (writeDelayMs > 0) {
        return new Promise((resolve) => { setTimeout(() => resolve({ ok: true, durable: true }), writeDelayMs) })
      }
      return Promise.resolve({ ok: true, durable: true })
    },
    async clearAll() { events.push({ kind: 'clear' }); return { ok: true, durable: true } },
    getStatus: () => ({ available: true, writable: true, protected: false }),
  }

  let prefsSnapshot = { state: 'ready', enabled: true, perContent: true, revision: 1, writable: true, mode: 'host' }
  const prefs = {
    getSnapshot: () => prefsSnapshot,
    subscribe: () => () => {},
    async ensure() { return prefsSnapshot },
    async update(patch) { prefsSnapshot = { ...prefsSnapshot, ...patch }; return { ok: true, snapshot: prefsSnapshot } },
    dispose() {},
  }

  const host = {
    readView: () => ({
      sessionId: 'session-1',
      panelIdentity: PANEL,
      expanded: state.presentation === 'push',
      presentation: state.presentation,
      framePx: state.framePx,
      observedPx: state.observed ?? 600,
      activeDockContent: { sessionId: 'session-1', paneId: 'pane-0', tabId: 'tab1', kind: state.kind, contentId: 'f' },
      availability: { kind: 'ready' },
    }),
    observeStructure(listener) { listeners.structure.add(listener); return () => listeners.structure.delete(listener) },
    observeDrag(listener) { listeners.drag.add(listener); return () => listeners.drag.delete(listener) },
    observeWidth(listener) { listeners.width.add(listener); return () => listeners.width.delete(listener) },
    async readFinalDragSample() { return null },
    async applyWidth(px) {
      const observed = state.observed ?? px
      applied.push({ requested: px, observed })
      return { status: 'applied', requestedPx: px, observedPx: observed }
    },
    async restoreDefault(reason) { cleaned.push(reason); return { status: 'applied', requestedPx: 576, observedPx: 576, resetLevel: 'numeric' } },
    capability: () => ({
      canWriteWidth: state.canWrite,
      writePath: state.canWrite ? 'layout.panels.setRightbar' : null,
      hasLayoutService: true,
      hasSidebarRightService: true,
      hasObservableMounted: true,
      structureHealthy: state.healthy,
      structureNote: state.healthy ? null : '右栏展开却连续 3 次找不到正常面板或手柄',
      structureMisses: state.healthy ? 0 : 3,
    }),
    dispose() {},
  }

  const controller = createController({
    lifecycle: createRootLifecycle(),
    prefs, table, host, store,
    log: line => logs.push(line),
    ...watchdogMs === null ? {} : { gestureWatchdogMs: watchdogMs },
  })

  return {
    controller, table, applied, cleaned, logs, events, state, pendingWrites,
    emitStructure: () => { for (const listener of listeners.structure) listener() },
    doDrag: (px) => {
      for (const listener of listeners.drag) listener({ kind: 'pointer-down', pointerId: 1, panelIdentity: PANEL })
      for (const listener of listeners.width) {
        listener({ px, panelIdentity: PANEL, pointerCommitSeq: 1, geometryGeneration: 5, phase: 'dragging', valid: true })
      }
      for (const listener of listeners.drag) listener({ kind: 'pointer-up', pointerId: 1 })
    },
    completeWrite: (index) => { pendingWrites[index]?.resolve({ ok: true, durable: true }) },
    startDragOnly: () => {
      for (const listener of listeners.drag) listener({ kind: 'pointer-down', pointerId: 1, panelIdentity: PANEL })
    },
    emitDragCancel: (reason = '拖拽过程中手柄被移除或替换') => {
      for (const listener of listeners.drag) listener({ kind: 'cancelled', pointerId: 1, reason })
    },
    emitWidth: (px) => {
      for (const listener of listeners.width) {
        listener({ px, panelIdentity: PANEL, pointerCommitSeq: 1, geometryGeneration: 5, phase: 'dragging', valid: true })
      }
    },
  }
}

test('E11：宽度被布局约束时保留意图，窗口变大后重试', async () => {
  const h = makeHarness()
  h.state.observed = 600 // 当前窗口下宿主最多只能给到 600
  h.table.set('kind:files', 'split', 900)
  await h.controller.start()
  await settleMs(10)

  assert.deepEqual(h.applied.at(-1), { requested: 900, observed: 600 }, '启动时请求 900 但被约束到 600')
  assert.equal(h.table.get('kind:files', 'split'), 900, '内存表保留的是用户意图，不是被约束后的实际值')

  // 窗口变大：环境变化触发重新结算，应重试同一份意图。
  h.state.framePx = 1920
  h.state.observed = 900
  h.emitStructure()
  await settleMs(20)
  assert.deepEqual(h.applied.at(-1), { requested: 900, observed: 900 }, '窗口够宽后应重试并成功')
  assert.equal(h.table.get('kind:files', 'split'), 900)

  // 再次结构变化不应无限重试（这次 requested === observed）。
  const count = h.applied.length
  h.emitStructure()
  await settleMs(20)
  assert.equal(h.applied.length, count, '未受约束时不再重复应用')
  assert.ok(h.logs.some(line => line.includes('窗口变大')))
  await h.controller.dispose()
})

test('E13：全屏期间暂停应用与保存，退出后按当前表恢复', async () => {
  const h = makeHarness()
  h.table.set('kind:files', 'split', 700)
  await h.controller.start()
  await settleMs(10)

  h.state.presentation = 'fullscreen'
  h.emitStructure()
  await settleMs(10)
  assert.equal(h.controller.getSnapshot().state, 'paused', '全屏不是正常右栏')

  const appliedBefore = h.applied.length
  h.state.framePx = 1280
  h.emitStructure()
  await settleMs(10)
  assert.equal(h.applied.length, appliedBefore, '全屏期间不应用正常宽度')

  // 全屏期间的“采样”不应产生记录（真实环境里也不会带上正常面板身份）。
  h.doDrag(1100)
  assert.equal(h.table.get('kind:files', 'split'), 700, '不保存全屏尺寸')

  h.state.presentation = 'push'
  h.emitStructure()
  await settleMs(20)
  assert.equal(h.controller.getSnapshot().state, 'active')
  assert.deepEqual(h.applied.at(-1)?.requested, 700, '退出全屏后按当前表恢复')
  await h.controller.dispose()
})

test('E14：宽度解算为 0 或宿主折叠时不保存，重新可用后按当前表应用', async () => {
  const h = makeHarness()
  h.table.set('kind:files', 'split', 640)
  await h.controller.start()
  await settleMs(10)

  // 0 宽采样：即使被当作合法手势，也会被 M3 的下限拒绝。
  h.doDrag(0)
  assert.equal(h.table.get('kind:files', 'split'), 640, '不保存 0')

  h.state.presentation = 'collapsed'
  h.emitStructure()
  await settleMs(10)
  const appliedBefore = h.applied.length
  h.emitStructure()
  await settleMs(10)
  assert.equal(h.applied.length, appliedBefore, '折叠期间不应用')

  h.state.presentation = 'push'
  h.emitStructure()
  await settleMs(20)
  assert.equal(h.applied.at(-1)?.requested, 640)
  await h.controller.dispose()
})

test('P08-3：拖拽中目标被移除（取消）后手势结束，自动应用恢复', async () => {
  const h = makeHarness()
  h.table.set('kind:files', 'split', 700)
  await h.controller.start()
  await settleMs(10)

  h.state.presentation = 'collapsed'
  h.emitStructure()
  h.state.presentation = 'push'
  h.emitStructure()
  await settleMs(10)
  const beforeCancel = h.applied.length

  h.doDrag(640) // 手势结束会正常收尾
  await settleMs(400)
  assert.equal(h.table.get('kind:files', 'split'), 640, '手势内的采样仍然记录')

  // 直接发取消（M1 在目标被移除时就是这么发的）
  h.emitDragCancel()
  await settleMs(20)
  assert.ok(h.logs.some(line => line.includes('手势取消')))

  h.state.presentation = 'collapsed'
  h.emitStructure()
  h.state.presentation = 'push'
  h.emitStructure()
  await settleMs(20)
  assert.equal(h.applied.at(-1)?.requested, 640, '取消之后自动应用恢复')
  assert.ok(h.applied.length > beforeCancel)
  await h.controller.dispose()
})

test('P08-3：手势看门狗——长时间没有信号也不遗留拖拽状态', async () => {
  const h = makeHarness({ watchdogMs: 80 })
  h.table.set('kind:files', 'split', 700)
  await h.controller.start()
  await settleMs(10)

  // 只按下、不给任何后续信号：模拟目标被移除且宿主不再派发事件
  h.startDragOnly()
  await settleMs(250)

  assert.ok(h.logs.some(line => line.includes('手势看门狗')), '看门狗应结束手势')
  h.state.presentation = 'collapsed'
  h.emitStructure()
  h.state.presentation = 'push'
  h.emitStructure()
  await settleMs(20)
  assert.equal(h.applied.at(-1)?.requested, 700, '看门狗之后自动应用恢复')
  await h.controller.dispose()
})

test('P08-3：卸载时仍在手势中——先收尾再冲刷已接受的值', async () => {
  const h = makeHarness()
  await h.controller.start()
  h.events.length = 0

  h.startDragOnly()
  h.emitWidth(688)
  await h.controller.dispose()

  assert.equal(h.table.get('kind:files', 'split'), 688, '已接受的值保留')
  assert.equal(h.events.filter(event => event.kind === 'write').length, 1, '卸载时把已接受的值冲刷掉')
})

test('P08-3：导入与排队保存交错——旧快照不会在替换之后落盘', async () => {
  // 写入有 60ms 延迟但必然完成：用来制造“旧快照正在写”的窗口，又不让测试挂住。
  const h = makeHarness({ writeDelayMs: 60 })
  await h.controller.start()

  h.doDrag(720)
  await settleMs(280) // 合并保存已经发起，正在飞行中
  const preview = h.controller.previewImport(JSON.stringify({ schema: 1, split: { 'kind:files': 655 }, unified: null }))
  const committed = await h.controller.commitImport(preview.previewId)
  assert.equal(committed.ok, true)

  const writes = h.events.filter(event => event.kind === 'write')
  assert.ok(writes.length >= 2, `至少应有一次旧快照写入与一次导入写入，实际 ${writes.length}`)
  assert.equal(writes.at(-1).split, JSON.stringify({ 'kind:files': 655 }), '最后落盘的是导入的数据')

  const importIndex = writes.findIndex(event => event.split.includes('655'))
  assert.ok(importIndex >= 0, '应有一次导入写入')
  assert.ok(
    writes.slice(importIndex + 1).every(event => !event.split.includes('720')),
    '替换之后不得再写旧快照',
  )
  assert.equal(h.table.get('kind:files', 'split'), 655)
  await h.controller.dispose()
})
test('E2：结构契约降级时暂停自动应用，恢复后继续', async () => {
  const h = makeHarness()
  h.table.set('kind:files', 'split', 700)
  await h.controller.start()
  await settleMs(10)
  assert.equal(h.controller.getSnapshot().structureHealthy, true)
  assert.equal(h.applied.at(-1)?.requested, 700)

  // 结构契约被破坏：能力报告降级。
  h.state.healthy = false
  h.emitStructure()
  await settleMs(10)
  const snapshot = h.controller.getSnapshot()
  assert.equal(snapshot.structureHealthy, false)
  assert.match(snapshot.structureNote, /找不到正常面板/)
  assert.ok(h.logs.some(line => line.includes('结构契约降级')))

  // 降级期间即使出现“重新就绪”的上升沿也不应用。
  const appliedBefore = h.applied.length
  h.state.presentation = 'collapsed'
  h.emitStructure()
  h.state.presentation = 'push'
  h.emitStructure()
  await settleMs(20)
  assert.equal(h.applied.length, appliedBefore, '降级期间暂停自动应用')
  assert.equal(h.table.get('kind:files', 'split'), 700, '数据保留，用户仍可管理')

  // 结构恢复：重新就绪时按内存表继续应用。
  h.state.healthy = true
  h.emitStructure()
  await settleMs(10)
  assert.ok(h.logs.some(line => line.includes('结构契约恢复')))
  h.state.presentation = 'collapsed'
  h.emitStructure()
  h.state.presentation = 'push'
  h.emitStructure()
  await settleMs(20)
  assert.equal(h.applied.at(-1)?.requested, 700, '恢复后继续自动恢复')
  await h.controller.dispose()
})
test('E15：宽度写入口不可用时停止自动应用，但保存与数据管理仍可用', async () => {
  const h = makeHarness()
  h.state.canWrite = false
  h.table.set('kind:files', 'split', 700)
  await h.controller.start()
  await settleMs(20)

  assert.deepEqual(h.applied, [], '写入口不可用就不尝试应用')
  assert.ok(h.logs.some(line => line.includes('宽度写入口不可用')))

  // 用户拖拽的可靠保存仍然工作
  h.doDrag(712)
  await settleMs(400)
  assert.equal(h.table.get('kind:files', 'split'), 712, '用户改动仍然记录')
  assert.equal(h.events.filter(event => event.kind === 'write').length, 1, '仍然可以落盘')

  // 数据管理（导出）仍可用
  assert.deepEqual(JSON.parse(h.controller.exportWidths().text).split, { 'kind:files': 712 })
  await h.controller.dispose()
})

test('E20：已经在飞的写入先完成，随后才删除，且不会被写回', async () => {
  const h = makeHarness({ manualWrites: true })
  await h.controller.start()

  h.doDrag(720) // 手势结束会立刻冲刷 → 进入手动写入
  await settleMs(400)
  assert.equal(h.pendingWrites.length, 1, '有一个写入在飞')

  const resetPromise = h.controller.resetWidths()
  await settleMs(20)
  assert.equal(h.events.filter(event => event.kind === 'write').length, 1, '删除必须等写入完成')

  h.completeWrite(0)
  const reset = await resetPromise
  assert.equal(reset.ok, true)
  assert.deepEqual(h.events.map(event => event.kind), ['write', 'clear'], '写入完成后才删除')
  assert.deepEqual(h.table.serialize(), { schema: 1, split: {}, unified: null })

  await settleMs(400)
  assert.deepEqual(h.events.map(event => event.kind), ['write', 'clear'], '删除之后不得再写回旧数据')
  await h.controller.dispose()
})
