/**
 * P11 #3（D-002）在控制器层的集成验证。
 *
 * 覆盖规划案 §9.5 的判据⑤⑥与 D-002 的决定 3/4：
 *   * 继承**不落盘**：应用继承值时不得产生任何存储写入，表内容也不变；
 *   * 拖拽只写“当前最具体类型”：从继承状态拖一次，写入的是当前类型而不是被继承的上级；
 *   * 修改“当前内容正在继承的那一条”**立即应用**（Q21）；改无关类型只保存不应用；
 *   * 模式切换（统一 → 区分）**按链解析**（Q5），不是直接落 DSH 默认；
 *   * 日志要能看出“用的是自己的记录还是继承来的”。
 *
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { createController } from '../lib/client/controller.js'
import { createRootLifecycle } from '../lib/client/lifecycle.js'
import { createWidthTable } from '../lib/client/width-table.js'

const PANEL = { sessionId: 'session-1', elementId: 'el-1' }
const settleMs = ms => new Promise(resolve => setTimeout(resolve, ms))

function makeHarness({ kind = 'editor', perContent = true } = {}) {
  const table = createWidthTable()
  const applied = []
  const cleaned = []
  const logs = []
  const writes = []
  const listeners = { structure: new Set(), drag: new Set(), width: new Set() }
  const state = { presentation: 'push', kind }
  let prefsSnapshot = { state: 'ready', enabled: true, perContent, revision: 1, writable: true, mode: 'host' }
  const prefsListeners = new Set()

  const prefs = {
    getSnapshot: () => prefsSnapshot,
    subscribe(listener) { prefsListeners.add(listener); return () => prefsListeners.delete(listener) },
    async ensure() { return prefsSnapshot },
    async update(patch) {
      prefsSnapshot = { ...prefsSnapshot, ...patch, revision: prefsSnapshot.revision + 1 }
      for (const listener of prefsListeners) listener(prefsSnapshot)
      return { ok: true, snapshot: prefsSnapshot }
    },
    dispose() {},
  }

  const host = {
    readView: () => ({
      sessionId: 'session-1',
      panelIdentity: PANEL,
      expanded: state.presentation === 'push',
      presentation: state.presentation,
      framePx: 1280,
      observedPx: 576,
      activeDockContent: { sessionId: 'session-1', paneId: 'pane-0', tabId: 'tab1', kind: state.kind, contentId: 'f' },
      availability: { kind: 'ready' },
    }),
    observeStructure(listener) { listeners.structure.add(listener); return () => listeners.structure.delete(listener) },
    observeDrag(listener) { listeners.drag.add(listener); return () => listeners.drag.delete(listener) },
    observeWidth(listener) { listeners.width.add(listener); return () => listeners.width.delete(listener) },
    async readFinalDragSample() { return null },
    async applyWidth(px) { applied.push(px); return { status: 'applied', requestedPx: px, observedPx: px } },
    async restoreDefault(reason) { cleaned.push(reason); return { status: 'applied', requestedPx: 576, observedPx: 576, resetLevel: 'numeric' } },
    dispose() {},
  }

  const controller = createController({
    lifecycle: createRootLifecycle(),
    prefs, table, host,
    store: {
      async readAll() { return { kind: 'empty' } },
      protect() {},
      async writeAll(value) { writes.push(value); return { ok: true, durable: true } },
      async clearAll() { return { ok: true, durable: true } },
      getStatus: () => ({ available: true, writable: true, protected: false }),
    },
    log: line => logs.push(line),
  })

  return {
    controller, table, applied, cleaned, logs, writes, state, prefsSnapshot,
    setPerContent: async (next) => { await prefs.update({ perContent: next }) },
    emitStructure: () => { for (const listener of listeners.structure) listener() },
    doDrag: async (px) => {
      for (const listener of listeners.drag) listener({ kind: 'pointer-down', pointerId: 1, panelIdentity: PANEL })
      for (const listener of listeners.width) {
        listener({ px, panelIdentity: PANEL, pointerCommitSeq: 1, geometryGeneration: 5, phase: 'dragging', valid: true })
      }
      for (const listener of listeners.drag) listener({ kind: 'pointer-up', pointerId: 1 })
      await settleMs(400)
    },
  }
}

test('继承不落盘：应用继承值不产生写入，表内容不变', async () => {
  const h = makeHarness()
  h.table.set('kind:files', 'split', 400) // 上级（文件页）有记录
  await h.controller.start()
  await settleMs(10)
  h.applied.length = 0
  h.writes.length = 0
  h.cleaned.length = 0

  const result = await h.controller.applyForCurrentContent()
  assert.equal(result.status, 'applied')
  assert.deepEqual(h.applied, [400], '应用的是继承来的 400')
  assert.deepEqual(h.cleaned, [], '有继承值就不该落默认')
  assert.deepEqual(h.table.serialize().split, { 'kind:files': 400 }, '表里不能多出 editor 的记录')

  await settleMs(400)
  assert.deepEqual(h.writes, [], '继承不产生任何落盘')
  assert.ok(h.logs.some(line => line.includes('← 继承自 kind:files')), '日志要能看出是继承来的')
  await h.controller.dispose()
})

test('拖拽只写当前最具体类型：从继承状态拖一次，写入 editor 而不是 files', async () => {
  const h = makeHarness()
  h.table.set('kind:files', 'split', 400)
  await h.controller.start()
  await settleMs(10)

  await h.doDrag(700)
  assert.deepEqual(h.table.serialize().split, { 'kind:files': 400, 'kind:editor': 700 })
  assert.equal(h.controller.getSnapshot().lastAction.result.status, 'applied')
  await h.controller.dispose()
})

test('改“当前正在继承的那一条”立即应用；改无关类型只保存', async () => {
  const h = makeHarness()
  h.table.set('kind:files', 'split', 400)
  await h.controller.start()
  await settleMs(10)
  h.applied.length = 0

  // 当前内容 editor 正在继承 files：改 files 必须立即应用
  await h.controller.setWidthFor('kind:files', 'split', 450)
  assert.deepEqual(h.applied, [450], '改继承来源应立即应用到当前右栏')

  // 改一个与当前内容无关的类型（terminal 不在 editor 的链上）→ 只保存
  await h.controller.setWidthFor('kind:terminal', 'split', 500)
  assert.deepEqual(h.applied, [450], '无关类型不得触发应用')
  assert.equal(h.table.get('kind:terminal', 'split'), 500, '但仍然要保存')
  await h.controller.dispose()
})

test('当前内容自己有记录时，改上级不应触发应用', async () => {
  const h = makeHarness()
  h.table.set('kind:files', 'split', 400)
  h.table.set('kind:editor', 'split', 700) // 自己是明确的，不再继承
  await h.controller.start()
  await settleMs(10)
  h.applied.length = 0

  await h.controller.setWidthFor('kind:files', 'split', 450)
  assert.deepEqual(h.applied, [], '自己那一条才是生效的，改上级只保存')
  assert.equal(h.table.get('kind:files', 'split'), 450)
  await h.controller.dispose()
})

test('模式切换按链解析：从统一切回区分时用继承值，而不是 DSH 默认', async () => {
  const h = makeHarness({ perContent: false })
  h.table.set('kind:files', 'split', 400)
  h.table.set('', 'unified', 512)
  await h.controller.start()
  await settleMs(10)
  h.applied.length = 0
  h.cleaned.length = 0

  await h.setPerContent(true)
  await settleMs(20)

  assert.deepEqual(h.applied, [400], '当前内容 editor 无记录 → 继承 files 的 400')
  assert.deepEqual(h.cleaned, [], '有继承链可用时不该落默认')
  await h.controller.dispose()
})
