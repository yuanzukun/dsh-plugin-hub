/**
 * P11 #1 的纯逻辑验证：四态运行状态、当前尺寸来源、活动页签文案与日志报告。
 *
 * 重点用例：
 *   * 四态优先级（已关闭 > 未就绪 > 降级 > 正常）；
 *   * 降级的每一种触发面都要能被判出来（结构、写入口、设置不可写、原文保护、错误）；
 *   * 尺寸来源三态文案（本类型记录 / 继承自 X / DSH 默认），其中“继承”分支为 #3 预留；
 *   * 日志报告的**隐私硬约束**：不得包含会话 id 或文件路径。
 *
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import {
  DIAGNOSTICS_KEY,
  DIAGNOSTICS_ON,
  buildLogReport,
  deriveRunState,
  deriveWidthReport,
  describeActiveTab,
  diagnosticsEnabled,
  hostVersionOf,
} from '../lib/client/status-report.js'

/** 造一个“一切正常”的控制器快照；用不到的字段给中性值。 */
function keeper(overrides = {}) {
  return {
    state: 'active',
    prefsReady: true,
    enabled: true,
    perContent: true,
    savedEntries: [],
    unified: null,
    storageStatus: { available: true, writable: true, protected: false },
    dirty: false,
    storageReads: 1,
    writtenRevision: 1,
    memoryRevision: 1,
    structureHealthy: true,
    structureNote: null,
    lastAction: null,
    activeKey: 'kind:files',
    activeLabel: '文件',
    error: null,
    ...overrides,
  }
}

/** 造一个“已确认且可写”的设置快照。 */
function prefs(overrides = {}) {
  return { state: 'ready', enabled: true, perContent: true, revision: 1, writable: true, mode: 'host', ...overrides }
}

/** 造一个“写入口可用”的能力报告。 */
function capability(overrides = {}) {
  return {
    canWriteWidth: true,
    writePath: 'layout.panels.setRightbar',
    hasLayoutService: true,
    hasSidebarRightService: true,
    hasObservableMounted: true,
    structureHealthy: true,
    structureNote: null,
    structureMisses: 0,
    ...overrides,
  }
}

test('四态：总开关关闭优先于其它异常，判为“已关闭”', () => {
  const report = deriveRunState({
    keeper: keeper({ enabled: false, structureHealthy: false, error: '随便一个错误' }),
    prefs: prefs(),
    capability: capability({ canWriteWidth: false }),
  })
  assert.equal(report.state, 'disabled')
  assert.equal(report.label, '已关闭')
  assert.equal(report.reason, null, '用户意图不算异常，不该给原因')
})

test('四态：未接入 / 设置未就绪 / 等待面板都判为“未就绪”', () => {
  assert.equal(deriveRunState({ keeper: null, prefs: null, capability: null }).state, 'not-ready')
  assert.equal(deriveRunState({ keeper: keeper(), prefs: null, capability: capability() }).state, 'not-ready')
  assert.equal(
    deriveRunState({ keeper: keeper(), prefs: prefs({ state: 'loading' }), capability: capability() }).state,
    'not-ready',
  )
  for (const phase of ['init', 'prefs-waiting', 'waiting']) {
    const report = deriveRunState({ keeper: keeper({ state: phase }), prefs: prefs(), capability: capability() })
    assert.equal(report.state, 'not-ready', `阶段 ${phase} 应判为未就绪`)
    assert.match(report.reason, /右侧边栏/)
  }
})

test('四态：降级的五种触发面都能判出原因', () => {
  const cases = [
    [keeper({ structureHealthy: false, structureNote: '找不到正常面板' }), prefs(), capability(), /找不到正常面板/],
    [keeper(), prefs(), capability({ canWriteWidth: false }), /写入口不可用/],
    [keeper(), prefs({ writable: false }), capability(), /不可写/],
    [keeper(), prefs({ mode: 'memory' }), capability(), /不可写/],
    [keeper({ storageStatus: { available: true, writable: true, protected: true } }), prefs(), capability(), /原文受保护/],
    [keeper({ error: '保存失败：配额' }), prefs(), capability(), /配额/],
  ]
  for (const [keeperValue, prefsValue, capabilityValue, expected] of cases) {
    const report = deriveRunState({ keeper: keeperValue, prefs: prefsValue, capability: capabilityValue })
    assert.equal(report.state, 'degraded')
    assert.equal(report.label, '降级')
    assert.match(report.reason, expected)
  }
})

test('四态：没有异常时是“正常运行”，且 paused（面板收起）也算正常', () => {
  assert.equal(deriveRunState({ keeper: keeper(), prefs: prefs(), capability: capability() }).state, 'ok')
  assert.equal(
    deriveRunState({ keeper: keeper({ state: 'paused' }), prefs: prefs(), capability: capability() }).state,
    'ok',
  )
  // 能力报告缺失（实验替身）不应误判为降级
  assert.equal(deriveRunState({ keeper: keeper(), prefs: prefs(), capability: null }).state, 'ok')
})

test('活动页签文案：友好名 + kind 原值；读不到时明确说明', () => {
  assert.equal(describeActiveTab('文件', 'kind:files'), '文件（files）')
  assert.equal(describeActiveTab(null, 'kind:editor'), 'editor')
  assert.equal(describeActiveTab('文件', null), '读不到（分类不可用）')
  assert.equal(describeActiveTab('文件', ''), '读不到（分类不可用）')
})

test('尺寸来源：本类型记录 / 上级继承 / DSH 默认三态（#3 起走真实链）', () => {
  const entry = { key: 'kind:files', px: 540 }
  const own = deriveWidthReport({ keeper: keeper({ savedEntries: [entry] }), observedPx: 600 })
  assert.equal(own.origin, 'own')
  assert.equal(own.px, 540)
  assert.equal(own.text, '540px（本类型记录）')

  const fallback = deriveWidthReport({ keeper: keeper({ savedEntries: [] }), observedPx: 576 })
  assert.equal(fallback.origin, 'default')
  assert.equal(fallback.px, 576)
  assert.equal(fallback.text, '576px（DSH 默认）')
  assert.equal(fallback.fromKey, null)

  const unified = deriveWidthReport({ keeper: keeper({ perContent: false, unified: 512 }), observedPx: 576 })
  assert.equal(unified.origin, 'own')
  assert.equal(unified.text, '512px（本类型记录）')

  // 当前是 editor（无记录），父级 files 有记录 → 继承
  const inherited = deriveWidthReport({
    keeper: keeper({ activeKey: 'kind:editor', activeLabel: '文档', savedEntries: [{ key: 'kind:files', px: 400 }] }),
    observedPx: 576,
  })
  assert.equal(inherited.origin, 'inherited')
  assert.equal(inherited.px, 400)
  assert.equal(inherited.fromKey, 'kind:files')
  assert.equal(inherited.fromLabel, '文件')
  assert.equal(inherited.text, '400px（继承自 文件）')

  // 父级没有、根有 → 继承根
  const fromRoot = deriveWidthReport({
    keeper: keeper({ activeKey: 'kind:editor', savedEntries: [{ key: 'kind:guide', px: 420 }] }),
    observedPx: 576,
  })
  assert.equal(fromRoot.origin, 'inherited')
  assert.equal(fromRoot.fromKey, 'kind:guide')
  assert.equal(fromRoot.text, '420px（继承自 引导页）')

  const unreadable = deriveWidthReport({ keeper: null, observedPx: null })
  assert.equal(unreadable.text, '读不到')
})

test('日志报告：包含版本、宿主、状态与日志行', () => {
  const report = buildLogReport({
    pluginVersion: '0.1.1',
    exportedAt: '2026-10-04T15:00:00.000Z',
    userAgent: 'Mozilla/5.0 ... @deepseek-ai/dsh-desktop/0.2.0-rc.2 Chrome/152.0.0.0 Safari/537.36',
    viewportWidth: 1280,
    keeper: keeper({ savedEntries: [{ key: 'kind:files', px: 540 }], lastAction: { action: '自动：应用内存值', at: 'x', result: { status: 'applied', requestedPx: 540, observedPx: 540 } } }),
    prefs: prefs(),
    capability: capability(),
    activeTabText: '文件（files）',
    widthText: '540px（本类型记录）',
    logLines: ['+12345 控制器启动', '+12350 阶段 init → prefs-waiting'],
  })
  assert.match(report, /插件版本：0\.1\.1/)
  assert.match(report, /宿主：DSH 桌面 0\.2\.0-rc\.2/)
  assert.match(report, /视口宽：1280px/)
  assert.match(report, /运行状态：正常运行/)
  assert.match(report, /当前活动页签：文件（files）/)
  assert.match(report, /当前侧边栏尺寸：540px（本类型记录）/)
  assert.match(report, /已保存类型数：1/)
  assert.match(report, /\+12345 控制器启动/)
  assert.match(report, /最近一次动作：自动：应用内存值 → applied/)
})

test('日志报告：不得包含会话 id 与文件路径（隐私硬约束）', () => {
  const sessionId = 'session-e718f25b-5025-42ab-954d-3e495d2b2eaf'
  const report = buildLogReport({
    pluginVersion: '0.1.1',
    exportedAt: '2026-10-04T15:00:00.000Z',
    userAgent: 'dsh-desktop/0.2.0-rc.2',
    viewportWidth: 1280,
    // 即使快照里带着会话相关信息（这里刻意用不到的白名单字段），报告也不该出现它们
    keeper: keeper({ savedEntries: [{ key: 'kind:files', px: 540 }] }),
    prefs: prefs(),
    capability: capability(),
    activeTabText: '文件（files）',
    widthText: '540px（本类型记录）',
    logLines: ['+1 控制器启动', '+2 阶段 active → paused（collapsed）'],
  })
  assert.equal(report.includes(sessionId), false, '报告里不得出现会话 id')
  assert.equal(/[A-Za-z]:\\/.test(report), false, '报告里不得出现 Windows 文件路径')
  assert.equal(report.includes('contentId'), false)
  assert.equal(report.includes('.md'), false)
})

test('宿主版本解析与诊断开关判定', () => {
  assert.equal(hostVersionOf('x @deepseek-ai/dsh-desktop/0.2.0-rc.2 y'), 'DSH 桌面 0.2.0-rc.2')
  assert.equal(hostVersionOf(''), '未知')
  assert.equal(diagnosticsEnabled(DIAGNOSTICS_ON), true)
  assert.equal(diagnosticsEnabled('0'), false)
  assert.equal(diagnosticsEnabled(null), false)
  assert.equal(DIAGNOSTICS_KEY, 'dsh-sidebar-size.diagnostics')
})
