/**
 * M4 Guard（src/client/guard.ts）的纯逻辑验证：来源判定、提交归属与 Ending 规则。
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { createGuard } from '../lib/client/guard.js'

const PANEL = { sessionId: 'session-1', elementId: 'el-1' }

function context(overrides = {}) {
  return {
    pointerId: 1,
    panelIdentity: PANEL,
    sessionId: 'session-1',
    paneId: 'pane-0',
    tabId: 'tab1',
    key: 'kind:files',
    mode: 'split',
    generation: 3,
    ...overrides,
  }
}

function sample(overrides = {}) {
  return {
    px: 700,
    panelIdentity: PANEL,
    pointerCommitSeq: 1,
    geometryGeneration: 10,
    phase: 'dragging',
    valid: true,
    ...overrides,
  }
}

test('没有手势时任何采样都不被接受', () => {
  const guard = createGuard()
  assert.equal(guard.acceptSample(sample()), null)
  assert.equal(guard.lastRejection(), 'no-gesture')
  assert.equal(guard.canApply(), true)
})

test('程序/环境来源的采样（valid=false 或没有提交序号）被拒绝', () => {
  const guard = createGuard()
  assert.equal(guard.beginDrag(context()), 'accepted')
  assert.equal(guard.acceptSample(sample({ valid: false })), null)
  assert.equal(guard.lastRejection(), 'sample-invalid')
  assert.equal(guard.acceptSample(sample({ pointerCommitSeq: null })), null)
  assert.equal(guard.acceptedCount(), 0)
})

test('被接受的采样携带按下时固定的归属（键、模式、代次）', () => {
  const guard = createGuard()
  guard.beginDrag(context({ key: 'kind:terminal', mode: 'unified', generation: 7 }))
  const accepted = guard.acceptSample(sample({ px: 812 }))
  assert.deepEqual(accepted, { key: 'kind:terminal', mode: 'unified', px: 812, dragId: 1, generation: 7 })

  // 手势进行中重复按下会被拒绝（不会开启第二个手势）。
  assert.equal(guard.beginDrag(context()), 'rejected')
})

test('面板身份不一致的采样被拒绝', () => {
  const guard = createGuard()
  guard.beginDrag(context())
  assert.equal(guard.acceptSample(sample({ panelIdentity: { sessionId: 'session-1', elementId: 'el-9' } })), null)
  assert.equal(guard.lastRejection(), 'panel-mismatch')
})

test('手势期间几何代次变化后停止采纳新尺寸，但保留最后可信值', () => {
  const guard = createGuard()
  guard.beginDrag(context())
  const first = guard.acceptSample(sample({ px: 640, geometryGeneration: 10 }))
  assert.equal(first?.px, 640)

  assert.equal(guard.acceptSample(sample({ px: 700, geometryGeneration: 11 })), null)
  assert.equal(guard.lastRejection(), 'geometry-changed')
  assert.equal(guard.lastAccepted().px, 640)
  assert.equal(guard.acceptedCount(), 1)
})

test('抬起进入 Ending：继续接受同一提交的最终采样', () => {
  const guard = createGuard()
  guard.beginDrag(context())
  guard.acceptSample(sample({ px: 700, pointerCommitSeq: 1 }))
  guard.beginEnding({ kind: 'pointer-up', pointerId: 1 })
  assert.equal(guard.phase(), 'ending')
  assert.equal(guard.pointerUpSeen(), true)

  const final = guard.acceptSample(sample({ px: 712, pointerCommitSeq: 1, phase: 'ending' }))
  assert.equal(final?.px, 712)

  // 另一个提交的采样在 Ending 阶段不再被接受。
  assert.equal(guard.acceptSample(sample({ px: 900, pointerCommitSeq: 2, phase: 'ending' })), null)
  assert.equal(guard.lastRejection(), 'commit-mismatch')

  guard.finishDrag()
  assert.equal(guard.phase(), 'idle')
  assert.equal(guard.canApply(), true)
})

test('抬起后的正常捕获释放不取消已接受的最终采样', () => {
  const guard = createGuard()
  guard.beginDrag(context())
  guard.acceptSample(sample({ px: 700 }))
  guard.beginEnding({ kind: 'pointer-up', pointerId: 1 })
  guard.acceptSample(sample({ px: 705, phase: 'ending' }))

  guard.beginEnding({ kind: 'capture-released', pointerId: 1 })
  assert.equal(guard.phase(), 'ending')
  const kept = guard.lastAccepted()
  assert.equal(kept.px, 705)
})

test('尚未接受 pointerup 的意外捕获丢失按取消处理（手势结束，值保留）', () => {
  const guard = createGuard()
  guard.beginDrag(context())
  guard.acceptSample(sample({ px: 688 }))

  guard.beginEnding({ kind: 'capture-released', pointerId: 1 })
  assert.equal(guard.phase(), 'idle')
  assert.equal(guard.lastAccepted().px, 688, '取消不丢弃最后可信值')
})

test('pointercancel 与显式 cancel 都结束手势', () => {
  const cancelGuard = createGuard()
  cancelGuard.beginDrag(context())
  cancelGuard.beginEnding({ kind: 'cancelled', pointerId: 1, reason: 'pointercancel' })
  assert.equal(cancelGuard.phase(), 'idle')

  const explicit = createGuard()
  explicit.beginDrag(context())
  explicit.cancel('blur')
  assert.equal(explicit.phase(), 'idle')
  assert.equal(explicit.canApply(), true)
})

test('空键或空面板身份的手势被拒绝', () => {
  const guard = createGuard()
  assert.equal(guard.beginDrag(context({ key: '' })), 'rejected')
  assert.equal(guard.beginDrag(context({ panelIdentity: { sessionId: 's', elementId: '' } })), 'rejected')
  assert.equal(guard.canApply(), true)
})
