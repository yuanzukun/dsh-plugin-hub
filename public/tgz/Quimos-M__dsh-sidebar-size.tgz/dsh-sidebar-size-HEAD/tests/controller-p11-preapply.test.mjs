/**
 * P11 #2 预备应用的集成验证：在右栏**尚未就绪**时就把宽度偏好写好，让首帧直接用记录值。
 *
 * 覆盖规划案 §9.4 的全部边界：
 *   * 面板未就绪时写入（核心行为），且此时不得走权威应用路径；
 *   * 目标值经父链解析（含“读不到活动页签时用根记录兜底”）；
 *   * 拿到宿主设置确认值之前不写（冻结的首次确认闸门）、总开关关闭不写；
 *   * 链上没有记录不写（宿主自己会算默认值）；
 *   * 面板曾就绪过之后不再预备应用（交给权威路径）；
 *   * 同一目标幂等，目标变化才再写。
 *
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { createController } from '../lib/client/controller.js'
import { createRootLifecycle } from '../lib/client/lifecycle.js'
import { createWidthTable } from '../lib/client/width-table.js'

const PANEL = { sessionId: 'session-1', elementId: 'el-1' }
const settleMs = ms => new Promise(resolve => setTimeout(resolve, ms))

/**
 * 造一个可控制“面板是否就绪”的宿主替身，并记录预备应用调用。
 *
 * @param options - 初始设置确认值、服务侧活动页签与面板就绪状态。
 */
function makeHarness({ perContent = true, enabled = true, prefsState = 'ready', serviceKind, ready = false } = {}) {
  const table = createWidthTable()
  const preApplied = []
  const applied = []
  const logs = []
  let prefsSnapshot = { state: prefsState, enabled, perContent, revision: 1, writable: true, mode: 'host' }
  const prefsListeners = new Set()
  let structureListener = null
  let tabsListener = null
  let panelReady = ready

  const prefs = {
    getSnapshot: () => prefsSnapshot,
    subscribe(listener) { prefsListeners.add(listener); return () => prefsListeners.delete(listener) },
    async ensure() { return prefsSnapshot },
    async update(patch) {
      prefsSnapshot = { ...prefsSnapshot, ...patch, revision: prefsSnapshot.revision + 1 }
      for (const listener of prefsListeners) listener(prefsSnapshot)
      return { ok: true, snapshot: prefsSnapshot }
    },
    dispose() {},
  }

  const host = {
    readView: () => (panelReady
      ? {
        sessionId: 'session-1',
        panelIdentity: PANEL,
        expanded: true,
        presentation: 'push',
        framePx: 1280,
        observedPx: 576,
        activeDockContent: { sessionId: 'session-1', paneId: 'pane-0', tabId: 'tab1', kind: serviceKind ?? 'editor', contentId: 'f' },
        availability: { kind: 'ready' },
      }
      : {
        sessionId: 'session-1',
        panelIdentity: null,
        expanded: false,
        presentation: 'push',
        framePx: 1280,
        observedPx: null,
        activeDockContent: undefined,
        availability: { kind: 'waiting', reason: '找不到当前会话的正常右栏面板' },
      }),
    observeStructure(listener) { structureListener = listener; return () => { structureListener = null } },
    observeDrag() { return () => {} },
    observeWidth() { return () => {} },
    observeTabs(listener) { tabsListener = listener; return () => { tabsListener = null } },
    readServiceActiveContent: () => (serviceKind === undefined
      ? undefined
      : { sessionId: 'session-1', paneId: '', tabId: 'tab1', kind: serviceKind, contentId: 'f' }),
    preApplyWidth(px) { preApplied.push(px); return { ok: true } },
    async applyWidth(px) { applied.push(px); return { status: 'applied', requestedPx: px, observedPx: px } },
    async restoreDefault(reason) { return { status: 'applied', requestedPx: 576, observedPx: 576, resetLevel: 'numeric', reason } },
    async readFinalDragSample() { return null },
    capability: () => ({ canWriteWidth: true, structureHealthy: true, structureNote: null, hasTabsObservable: tabsListener !== null }),
    dispose() {},
  }

  const controller = createController({
    lifecycle: createRootLifecycle(),
    prefs, table, host,
    store: {
      async readAll() { return { kind: 'empty' } },
      protect() {},
      async writeAll() { return { ok: true, durable: true } },
      async clearAll() { return { ok: true, durable: true } },
      getStatus: () => ({ available: true, writable: true, protected: false }),
    },
    log: line => logs.push(line),
  })

  return {
    controller, table, preApplied, applied, logs,
    openPanel() { panelReady = true },
    fireStructure() { structureListener?.() },
    fireTabs() { tabsListener?.() },
    async setPrefs(patch) { await prefs.update(patch) },
  }
}

test('面板未就绪时就把记录值写好（首帧不再撑到默认）', async () => {
  const h = makeHarness({ serviceKind: 'editor', ready: false })
  h.table.set('kind:editor', 'split', 700)
  await h.controller.start()
  await settleMs(20)

  assert.deepEqual(h.preApplied, [700], '面板就绪前必须先写偏好')
  assert.deepEqual(h.applied, [], '此时权威路径不该也不能应用（面板未就绪）')
  assert.ok(h.logs.some(line => line.includes('预备应用：kind:editor = 700px')), '日志要留下预备应用记录')
  await h.controller.dispose()
})

test('预备应用的目标值经父链解析（未记录类型用上级值）', async () => {
  const h = makeHarness({ serviceKind: 'editor', ready: false })
  h.table.set('kind:guide', 'split', 400)
  await h.controller.start()
  await settleMs(20)

  assert.deepEqual(h.preApplied, [400])
  assert.ok(h.logs.some(line => line.includes('预备应用：kind:editor = 400px（继承自 引导页')))
  await h.controller.dispose()
})

test('读不到活动页签时用根记录兜底（从未打开过右栏的会话）', async () => {
  const h = makeHarness({ serviceKind: undefined, ready: false })
  h.table.set('kind:guide', 'split', 420)
  await h.controller.start()
  await settleMs(20)

  assert.deepEqual(h.preApplied, [420])
  assert.ok(h.logs.some(line => line.includes('根记录（无活动页签）')))
  await h.controller.dispose()
})

test('闸门：设置未确认 / 总开关关闭 / 链上无记录 都不预备应用', async () => {
  const gated = makeHarness({ serviceKind: 'editor', ready: false, prefsState: 'loading' })
  gated.table.set('kind:editor', 'split', 700)
  await gated.controller.start()
  await settleMs(20)
  assert.deepEqual(gated.preApplied, [], '拿到宿主确认值之前绝不写')
  await gated.controller.dispose()

  const disabled = makeHarness({ serviceKind: 'editor', ready: false, enabled: false })
  disabled.table.set('kind:editor', 'split', 700)
  await disabled.controller.start()
  await settleMs(20)
  assert.deepEqual(disabled.preApplied, [], '总开关关闭时不写')
  await disabled.controller.dispose()

  const empty = makeHarness({ serviceKind: 'editor', ready: false })
  await empty.controller.start()
  await settleMs(20)
  assert.deepEqual(empty.preApplied, [], '链上没有记录时交给宿主自己的默认值')
  await empty.controller.dispose()
})

test('幂等与切换：同一目标只写一次，目标变化才再写；面板就绪后不再预备应用', async () => {
  const h = makeHarness({ serviceKind: 'editor', ready: false })
  h.table.set('kind:editor', 'split', 700)
  await h.controller.start()
  await settleMs(20)
  assert.deepEqual(h.preApplied, [700])

  // 重复触发（结构变化 / 页签清单变化）不应重复写同一个值
  h.fireStructure()
  h.fireTabs()
  await settleMs(10)
  assert.deepEqual(h.preApplied, [700], '同一目标幂等')

  // 目标变化（用户改记录）→ 再写一次
  h.table.set('kind:editor', 'split', 500)
  h.fireTabs()
  await settleMs(10)
  assert.deepEqual(h.preApplied, [700, 500])

  // 面板就绪：权威路径接管，预备应用停止
  h.openPanel()
  h.fireStructure()
  await settleMs(20)
  assert.deepEqual(h.applied, [500], '就绪后由权威路径应用当前记录值')
  h.table.set('kind:editor', 'split', 640)
  h.fireTabs()
  await settleMs(10)
  assert.deepEqual(h.preApplied, [700, 500], '曾就绪过之后不再预备应用')
  await h.controller.dispose()
})
