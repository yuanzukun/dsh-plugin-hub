/**
 * P05：保存队列 / 合并写入 / 启动一次读取 的控制器行为验证。
 *
 * 覆盖：
 *   * 250ms 合并：多次采样只写一次，写入内容是最终快照；
 *   * 手势结束立即冲刷，不等合并计时；
 *   * 旧的成功结果不清除更新的内存改动（写入期间产生的新改动会再排一次）；
 *   * 写入失败保留内存与 dirty，成功重试后清除错误；
 *   * 原文保护状态下不写入、不重试打转；
 *   * 卸载前与总开关关闭前都冲刷已接受的改动；
 *   * 启动只读一次存储，之后的内容/结构变化不再读。
 *
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { createController } from '../lib/client/controller.js'
import { createRootLifecycle } from '../lib/client/lifecycle.js'
import { createWidthTable } from '../lib/client/width-table.js'

const PANEL = { sessionId: 'session-1', elementId: 'el-1' }
const settleMs = ms => new Promise(resolve => setTimeout(resolve, ms))

function makeHarness({ manualWrites = false, initialText = null, readFails = false } = {}) {
  const table = createWidthTable()
  const applied = []
  const cleaned = []
  const logs = []
  const listeners = { structure: new Set(), drag: new Set(), width: new Set() }
  const state = { presentation: 'push', kind: 'files', finalSample: null }
  const reads = { count: 0 }
  /** 手动模式下每个待完成的写入：{ value, resolve(结果) }。 */
  const pendingWrites = []
  const settledWrites = []
  let protectedNotice = null
  let writeMode = 'ok'

  const store = {
    async readAll() {
      reads.count += 1
      if (readFails) return { kind: 'unavailable', reason: 'storage down' }
      return initialText === null ? { kind: 'empty' } : { kind: 'loaded', rawText: initialText }
    },
    protect(rawText, reason) {
      protectedNotice = { rawText, reason }
    },
    writeAll(value) {
      if (!manualWrites) {
        if (writeMode === 'fail') return Promise.resolve({ ok: false, durable: false, reason: 'quota' })
        if (protectedNotice !== null) return Promise.resolve({ ok: false, durable: false, protected: true, reason: '受保护' })
        settledWrites.push(value)
        return Promise.resolve({ ok: true, durable: true })
      }
      return new Promise((resolve) => {
        pendingWrites.push({ value, resolve })
      })
    },
    async clearAll() { return { ok: true, durable: true } },
    getStatus: () => ({
      available: true,
      writable: true,
      protected: protectedNotice !== null,
      ...protectedNotice === null ? {} : { rawProblemText: protectedNotice.rawText },
    }),
  }

  const prefsSnapshot = { state: 'ready', enabled: true, perContent: true, revision: 1, writable: true, mode: 'host' }
  const prefsListeners = new Set()
  const prefs = {
    getSnapshot: () => prefsSnapshot,
    subscribe(listener) { prefsListeners.add(listener); return () => prefsListeners.delete(listener) },
    async ensure() { return prefsSnapshot },
    async update(patch) {
      Object.assign(prefsSnapshot, patch)
      for (const listener of prefsListeners) listener(prefsSnapshot)
      return { ok: true, snapshot: prefsSnapshot }
    },
    dispose() {},
  }

  const host = {
    readView: () => ({
      sessionId: 'session-1',
      panelIdentity: PANEL,
      expanded: state.presentation === 'push',
      presentation: state.presentation,
      framePx: 1280,
      observedPx: 576,
      activeDockContent: { sessionId: 'session-1', paneId: 'pane-0', tabId: 'tab1', kind: state.kind, contentId: 'f' },
      availability: { kind: 'ready' },
    }),
    observeStructure(listener) { listeners.structure.add(listener); return () => listeners.structure.delete(listener) },
    observeDrag(listener) { listeners.drag.add(listener); return () => listeners.drag.delete(listener) },
    observeWidth(listener) { listeners.width.add(listener); return () => listeners.width.delete(listener) },
    async readFinalDragSample() { return state.finalSample },
    async applyWidth(px) { applied.push(px); return { status: 'applied', requestedPx: px, observedPx: px } },
    async restoreDefault(reason) { cleaned.push(reason); return { status: 'applied', requestedPx: 576, observedPx: 576, resetLevel: 'numeric' } },
    dispose() {},
  }

  const controller = createController({
    lifecycle: createRootLifecycle(),
    prefs, store, table, host,
    log: line => logs.push(line),
  })

  return {
    controller, table, applied, cleaned, logs, state, reads, pendingWrites, settledWrites,
    setWriteMode: mode => { writeMode = mode },
    protectStore: (text, reason) => { protectedNotice = { rawText: text, reason } },
    emitDrag: signal => { for (const listener of listeners.drag) listener(signal) },
    emitWidth: sample => { for (const listener of listeners.width) listener(sample) },
    emitStructure: () => { for (const listener of listeners.structure) listener() },
    completeWrite: (index, result = { ok: true, durable: true }) => {
      const entry = pendingWrites[index]
      assert.ok(entry, `没有第 ${index} 个待完成写入`)
      entry.resolve(result)
    },
    dragSignal: (name, pointerId = 1) => (name === 'pointer-down'
      ? { kind: 'pointer-down', pointerId, panelIdentity: PANEL }
      : { kind: name, pointerId }),
    widthSample: (px, overrides = {}) => ({
      px, panelIdentity: PANEL, pointerCommitSeq: 1, geometryGeneration: 5, phase: 'dragging', valid: true, ...overrides,
    }),
    doDrag: async (px, { release = true } = {}) => {
      for (const listener of listeners.drag) listener({ kind: 'pointer-down', pointerId: 1, panelIdentity: PANEL })
      for (const listener of listeners.width) listener({ px, panelIdentity: PANEL, pointerCommitSeq: 1, geometryGeneration: 5, phase: 'dragging', valid: true })
      if (release) {
        for (const listener of listeners.drag) listener({ kind: 'pointer-up', pointerId: 1 })
        await settleMs(400)
      }
    },
  }
}

test('250ms 合并：多次采样只写一次，内容是最终快照', async () => {
  const h = makeHarness()
  await h.controller.start()
  h.settledWrites.length = 0

  h.emitDrag(h.dragSignal('pointer-down'))
  h.emitWidth(h.widthSample(700))
  h.emitWidth(h.widthSample(712))
  h.emitWidth(h.widthSample(724))

  assert.deepEqual(h.settledWrites, [], '合并窗口内不应写盘')
  await settleMs(350)

  assert.equal(h.settledWrites.length, 1, '三次采样合并成一次写入')
  assert.deepEqual(h.settledWrites[0], { schema: 1, split: { 'kind:files': 724 }, unified: null })
  assert.equal(h.controller.getSnapshot().dirty, false, '落盘后 dirty 清除')
  await h.controller.dispose()
})

test('手势结束立即冲刷，不等 250ms 合并计时', async () => {
  const h = makeHarness()
  await h.controller.start()
  h.settledWrites.length = 0

  h.state.finalSample = h.widthSample(730, { phase: 'ending' })
  await h.doDrag(700)

  assert.equal(h.settledWrites.length, 1, '手势结束即冲刷')
  assert.deepEqual(h.settledWrites[0].split, { 'kind:files': 730 })
  await h.controller.dispose()
})

test('旧的成功结果不清除更新的内存改动', async () => {
  const h = makeHarness({ manualWrites: true })
  await h.controller.start()

  h.emitDrag(h.dragSignal('pointer-down'))
  h.emitWidth(h.widthSample(700))
  await settleMs(300)
  assert.equal(h.pendingWrites.length, 1, '第一次写入在飞行中')

  // 写入未完成时又产生新值
  h.emitWidth(h.widthSample(760))
  h.completeWrite(0)
  await settleMs(20)
  assert.equal(h.controller.getSnapshot().dirty, true, '旧成功不能清掉新改动')

  await settleMs(300)
  assert.equal(h.pendingWrites.length, 2, '新改动会再排一次写入')
  assert.deepEqual(h.pendingWrites[1].value.split, { 'kind:files': 760 })
  h.completeWrite(1)
  await settleMs(20)
  assert.equal(h.controller.getSnapshot().dirty, false)
  await h.controller.dispose()
})

test('写入失败保留内存与 dirty，重试成功后清除错误', async () => {
  const h = makeHarness()
  await h.controller.start()
  h.setWriteMode('fail')

  h.emitDrag(h.dragSignal('pointer-down'))
  h.emitWidth(h.widthSample(704))
  await settleMs(350)

  const failed = h.controller.getSnapshot()
  assert.equal(failed.dirty, true, '失败后仍有未落盘改动')
  assert.match(failed.error, /保存失败/)
  assert.equal(h.table.get('kind:files', 'split'), 704, '内存表不受影响')

  h.setWriteMode('ok')
  h.emitWidth(h.widthSample(708))
  await settleMs(350)
  const recovered = h.controller.getSnapshot()
  assert.equal(recovered.dirty, false)
  assert.equal(recovered.error, null)
  assert.equal(h.table.get('kind:files', 'split'), 708)
  await h.controller.dispose()
})

test('原文保护状态下不写入，也不反复重试', async () => {
  const h = makeHarness()
  await h.controller.start()
  h.protectStore('{broken', '解析失败')

  h.emitDrag(h.dragSignal('pointer-down'))
  h.emitWidth(h.widthSample(700))
  await settleMs(400)
  const snapshot = h.controller.getSnapshot()
  assert.deepEqual(h.settledWrites, [], '受保护时不得覆盖原文')
  assert.equal(snapshot.storageStatus.protected, true)
  assert.equal(snapshot.dirty, true)
  await h.controller.dispose()
})

test('卸载前冲刷已接受的改动', async () => {
  const h = makeHarness()
  await h.controller.start()
  h.settledWrites.length = 0

  h.emitDrag(h.dragSignal('pointer-down'))
  h.emitWidth(h.widthSample(718))
  await h.controller.dispose() // 卸载会先冲刷
  assert.equal(h.settledWrites.length, 1)
  assert.deepEqual(h.settledWrites[0].split, { 'kind:files': 718 })
})

test('总开关关闭前冲刷已接受的改动', async () => {
  const h = makeHarness()
  await h.controller.start()
  h.settledWrites.length = 0

  h.emitDrag(h.dragSignal('pointer-down'))
  h.emitWidth(h.widthSample(722))
  await h.controller.setEnabled(false)

  assert.ok(h.settledWrites.some(value => value.split['kind:files'] === 722), '关闭前的收尾保存')
  assert.equal(h.controller.getSnapshot().state, 'dormant')
  await h.controller.dispose()
})

test('启动读取失败时拒绝写入，避免用空表覆盖已有数据', async () => {
  const h = makeHarness({ readFails: true })
  await h.controller.start()
  assert.match(h.controller.getSnapshot().error, /存储不可用/)

  h.emitDrag(h.dragSignal('pointer-down'))
  h.emitWidth(h.widthSample(700))
  await settleMs(400)

  assert.deepEqual(h.settledWrites, [], '读取失败期间不得写盘')
  assert.equal(h.controller.getSnapshot().dirty, true, '内存改动保留，等存储恢复')
  await h.controller.dispose()
})

test('空表不写盘（避免无意义的键与误覆盖）', async () => {
  const h = makeHarness()
  await h.controller.start()

  // 只有程序恢复（无任何用户记录）时不应产生写入
  h.emitStructure()
  await settleMs(400)
  assert.deepEqual(h.settledWrites, [], '空表不写')
  await h.controller.dispose()
})

test('启动读取成功后不把同一份数据原样写回', async () => {
  const h = makeHarness({ initialText: JSON.stringify({ schema: 1, split: { 'kind:files': 640 }, unified: null }) })
  await h.controller.start()
  const snapshot = h.controller.getSnapshot()
  assert.equal(snapshot.dirty, false, '读到什么就算什么已落盘')
  assert.equal(snapshot.writtenRevision, snapshot.memoryRevision)
  assert.equal(h.table.get('kind:files', 'split'), 640)

  await h.controller.dispose() // 卸载前的冲刷也不应产生写入
  assert.deepEqual(h.settledWrites, [], '没有改动就不写回')
})

test('启动只读一次；结构变化与内容切换不再读存储', async () => {
  const h = makeHarness({ initialText: JSON.stringify({ schema: 1, split: { 'kind:files': 640 }, unified: null }) })
  await h.controller.start()
  assert.equal(h.reads.count, 1, '启动读取一次')
  assert.equal(h.controller.getSnapshot().storageReads, 1)

  h.emitStructure()
  h.state.kind = 'terminal'
  h.emitStructure()
  h.state.presentation = 'collapsed'
  h.emitStructure()
  h.state.presentation = 'push'
  h.emitStructure()
  await settleMs(20)

  assert.equal(h.reads.count, 1, '之后不再读存储')
  assert.equal(h.table.get('kind:files', 'split'), 640, '启动恢复的是读到的值')
  await h.controller.dispose()
})

