/**
 * M6 控制器（src/client/controller.ts）的纯逻辑验证：装配顺序、阶段转换、总开关与释放。
 *
 * 用可编程的假 M8/M5/M1 代替真实服务；这一层不能证明真实宿主行为（那是 P02/P03 的目标环境验收）。
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { createController } from '../lib/client/controller.js'
import { createRootLifecycle } from '../lib/client/lifecycle.js'
import { createWidthTable } from '../lib/client/width-table.js'

/** 假 M8：可控快照与写入结果。 */
function makePrefs(initial = { state: 'loading', enabled: null, perContent: null }) {
  let snapshot = { revision: null, writable: true, mode: 'host', ...initial }
  const listeners = new Set()
  const updates = []
  let acceptUpdate = true
  return {
    updates,
    prefs: {
      getSnapshot: () => snapshot,
      subscribe(listener) {
        listeners.add(listener)
        return () => listeners.delete(listener)
      },
      async ensure() {
        return snapshot
      },
      async update(patch) {
        updates.push(patch)
        if (!acceptUpdate) return { ok: false, snapshot, reason: '宿主拒绝' }
        snapshot = { ...snapshot, ...patch, revision: (snapshot.revision ?? 0) + 1 }
        for (const listener of listeners) listener(snapshot)
        return { ok: true, snapshot }
      },
      dispose() {},
    },
    push(next) {
      snapshot = { ...snapshot, ...next }
      for (const listener of listeners) listener(snapshot)
    },
    rejectUpdates() {
      acceptUpdate = false
    },
  }
}

/** 假 M5：记录读取与保护调用。 */
function makeStore({ text = null, readFails = false } = {}) {
  const protects = []
  const writes = []
  let status = { available: true, writable: true, protected: false }
  return {
    protects,
    writes,
    store: {
      async readAll() {
        if (readFails) return { kind: 'unavailable', reason: 'storage down' }
        if (text === null) return { kind: 'empty' }
        return { kind: 'loaded', rawText: text }
      },
      protect(rawText, reason) {
        protects.push({ rawText, reason })
        status = { available: true, writable: true, protected: true, rawProblemText: rawText }
      },
      async writeAll(value) {
        writes.push(value)
        return { ok: true, durable: true }
      },
      async clearAll() {
        return { ok: true, durable: true }
      },
      getStatus: () => status,
    },
  }
}

/** 假 M1：可控视图、记录写入与默认清理次数。 */
function makeHost({ presentation = 'push', kind = 'files', availability = { kind: 'ready' } } = {}) {
  const applied = []
  const cleaned = []
  const structureListeners = new Set()
  let disposed = 0
  return {
    applied,
    cleaned,
    disposedCount: () => disposed,
    structureListenerCount: () => structureListeners.size,
    /** 取当前已登记的结构回调，供测试手动触发。 */
    triggerStructure: () => Array.from(structureListeners),
    host: {
      readView: () => ({
        sessionId: 'session-1',
        panelIdentity: { sessionId: 'session-1', elementId: 'el-1' },
        expanded: true,
        presentation,
        framePx: 1280,
        observedPx: 576,
        activeDockContent: kind === null ? undefined : { sessionId: 'session-1', paneId: 'pane-0', tabId: 'tab1', kind, contentId: 'file:///a.md' },
        availability,
      }),
      observeStructure(listener) {
        structureListeners.add(listener)
        return () => structureListeners.delete(listener)
      },
      async applyWidth(px) {
        applied.push(px)
        return { status: 'applied', requestedPx: px, observedPx: px }
      },
      async restoreDefault(reason) {
        cleaned.push(reason)
        return { status: 'applied', requestedPx: 576, observedPx: 576, resetLevel: 'numeric' }
      },
      dispose() {
        disposed += 1
      },
    },
  }
}

function makeController(options = {}) {
  const lifecycle = createRootLifecycle()
  const table = createWidthTable()
  const prefsFake = makePrefs(options.prefs ?? {})
  const storeFake = makeStore(options.store ?? {})
  const hostFake = makeHost(options.host ?? {})
  const logs = []
  const controller = createController({
    lifecycle,
    prefs: prefsFake.prefs,
    store: storeFake.store,
    table,
    host: options.withHost === false ? undefined : hostFake.host,
    log: line => logs.push(line),
  })
  return { controller, lifecycle, table, prefsFake, storeFake, hostFake, logs }
}

test('偏好未确认时进入 prefs-waiting，且拒绝改宽度', async () => {
  const { controller } = makeController()
  const snapshot = await controller.start()
  assert.equal(snapshot.state, 'prefs-waiting')
  assert.equal(snapshot.enabled, null)

  const result = await controller.applyForCurrentContent()
  assert.equal(result.status, 'deferred')
  assert.match(result.reason, /尚未确认/)
})

test('确认开启且宿主就绪时进入 active；没有记录则走数值默认', async () => {
  const { controller, hostFake } = makeController({
    prefs: { state: 'ready', enabled: true, perContent: true },
  })
  const snapshot = await controller.start()
  assert.equal(snapshot.state, 'active')
  assert.equal(snapshot.activeLabel, '文件')

  // P04 起：就绪的上升沿会自动按内存表恢复；没有记录时请求数值默认。
  assert.equal(hostFake.cleaned.length, 1)
  assert.match(hostFake.cleaned[0], /没有该类型的记录/)
  assert.deepEqual(hostFake.applied, [])

  const result = await controller.applyForCurrentContent()
  assert.equal(result.status, 'applied')
  assert.equal(hostFake.cleaned.length, 2, '显式动作再请求一次默认清理')
  assert.match(hostFake.cleaned[1], /当前类型没有记录/)
})

test('有记录时应用已保存值；unified 模式查统一值', async () => {
  const { controller, table, hostFake } = makeController({
    prefs: { state: 'ready', enabled: true, perContent: true },
  })
  table.set('kind:files', 'split', 704)
  table.set('kind:files', 'unified', 900)
  await controller.start()

  // 启动的上升沿已按内存表恢复一次，显式动作再应用一次同一个值。
  assert.deepEqual(hostFake.applied, [704])
  assert.equal((await controller.applyForCurrentContent()).status, 'applied')
  assert.deepEqual(hostFake.applied, [704, 704])
})

test('确认关闭时进入 dormant，并执行一次数值默认清理', async () => {
  const { controller, hostFake, prefsFake } = makeController({
    prefs: { state: 'ready', enabled: true, perContent: true },
  })
  await controller.start()
  assert.equal(controller.getSnapshot().state, 'active')

  prefsFake.push({ enabled: false })
  // 订阅回调是同步的；阶段应立刻进入 dormant（界面不等落盘与清理）。
  await Promise.resolve()
  assert.equal(controller.getSnapshot().state, 'dormant')

  // 随后是收尾冲刷与一次默认清理。
  await new Promise(resolve => setTimeout(resolve, 30))
  assert.ok(hostFake.cleaned.includes('总开关关闭'), '关闭时执行默认清理')
  assert.equal(hostFake.cleaned.at(-1), '总开关关闭')
  assert.equal(controller.getSnapshot().lastAction.result.resetLevel, 'numeric')
  assert.equal(hostFake.structureListenerCount(), 0, '关闭后不再观察结构')
})

test('关闭总开关时若右栏不可显示，则记 deferred 且不写宿主', async () => {
  const { controller, hostFake } = makeController({
    prefs: { state: 'ready', enabled: true, perContent: true },
    host: { presentation: 'collapsed' },
  })
  await controller.start()
  assert.equal(controller.getSnapshot().state, 'waiting')

  const result = await controller.setEnabled(false)
  assert.equal(result.ok, true)
  assert.equal(controller.getSnapshot().state, 'dormant')
  assert.deepEqual(hostFake.cleaned, [], '不可显示时不得强行清理')
  assert.equal(controller.getSnapshot().lastAction.result.status, 'deferred')
  assert.match(controller.getSnapshot().lastAction.result.reason, /不是正常停靠展示/)
})

test('总开关写入被宿主拒绝时不转换阶段', async () => {
  const { controller, prefsFake } = makeController({
    prefs: { state: 'ready', enabled: true, perContent: true },
  })
  await controller.start()
  prefsFake.rejectUpdates()

  const result = await controller.setEnabled(false)
  assert.equal(result.ok, false)
  assert.match(result.reason, /拒绝/)
  assert.equal(controller.getSnapshot().state, 'active')
})

test('损坏 JSON 与未来版本都保留原文并停止自动写入', async () => {
  const broken = makeController({ store: { text: '{not json' } })
  await broken.controller.start()
  assert.equal(broken.storeFake.protects.length, 1)
  assert.equal(broken.controller.getSnapshot().storageStatus.protected, true)
  assert.match(broken.controller.getSnapshot().error, /JSON/)

  const future = makeController({ store: { text: JSON.stringify({ schema: 99, split: {}, unified: null }) } })
  await future.controller.start()
  assert.equal(future.storeFake.protects.length, 1)
  assert.match(future.controller.getSnapshot().error, /版本/)
})

test('合法数据加载进内存表；非法条目被剔除但整体可用', async () => {
  const good = makeController({
    store: { text: JSON.stringify({ schema: 1, split: { 'kind:files': 704, bad: 700 }, unified: null }) },
    prefs: { state: 'ready', enabled: true, perContent: true },
  })
  await good.controller.start()
  assert.deepEqual(good.controller.getSnapshot().savedEntries, [{ key: 'kind:files', kind: 'kind:files', px: 704 }])
  assert.equal(good.storeFake.protects.length, 0)
  assert.ok(good.logs.some(line => line.includes('已剔除')))

  await good.controller.applyForCurrentContent()
  assert.deepEqual(good.hostFake.applied, [704, 704])
})

test('存储不可用时给出可见错误但控制器仍可用', async () => {
  const { controller } = makeController({ store: { readFails: true } })
  await controller.start()
  assert.match(controller.getSnapshot().error, /存储不可用/)
})

test('宿主不可显示时进入 waiting/paused，且应用动作被推迟', async () => {
  const collapsed = makeController({ prefs: { state: 'ready', enabled: true, perContent: true }, host: { presentation: 'collapsed' } })
  await collapsed.controller.start()
  assert.equal(collapsed.controller.getSnapshot().state, 'waiting')
  const result = await collapsed.controller.applyForCurrentContent()
  assert.equal(result.status, 'deferred')

  const fullscreen = makeController({ prefs: { state: 'ready', enabled: true, perContent: true }, host: { presentation: 'fullscreen' } })
  await fullscreen.controller.start()
  assert.equal(fullscreen.controller.getSnapshot().state, 'waiting')
  assert.equal((await fullscreen.controller.applyForCurrentContent()).status, 'deferred')
})

test('读不到活动内容类型时拒绝应用（不生成兜底记录）', async () => {
  const { controller } = makeController({
    prefs: { state: 'ready', enabled: true, perContent: true },
    host: { kind: null },
  })
  await controller.start()
  const result = await controller.applyForCurrentContent()
  assert.equal(result.status, 'deferred')
  assert.match(result.reason, /活动内容类型/)
})

test('接入与摘除宿主：摘除后阶段退回 waiting/dormant，且不再观察', async () => {
  const { controller, hostFake } = makeController({ prefs: { state: 'ready', enabled: true, perContent: true } })
  await controller.start()
  assert.equal(controller.getSnapshot().state, 'active')

  controller.detachHost()
  assert.equal(controller.getSnapshot().state, 'waiting')
  assert.equal(hostFake.structureListenerCount(), 0)

  controller.attachHost(hostFake.host)
  await Promise.resolve()
  assert.equal(controller.getSnapshot().state, 'active')
})

test('dispose 幂等：释放后所有动作不再生效', async () => {
  const { controller, hostFake, prefsFake } = makeController({ prefs: { state: 'ready', enabled: true, perContent: true } })
  await controller.start()

  await controller.dispose()
  await controller.dispose()
  assert.equal(controller.getSnapshot().state, 'disposed')
  assert.equal(hostFake.structureListenerCount(), 0)

  const applied = await controller.applyForCurrentContent()
  assert.equal(applied.status, 'unavailable')
  const toggled = await controller.setEnabled(false)
  assert.equal(toggled.ok, false)
  assert.deepEqual(prefsFake.updates, [], '释放后不再写设置')
})

test('构造函数传入的宿主也会被绑定：结构信号能让阶段从 waiting 推进到 active', async () => {
  const { controller, hostFake } = makeController({
    prefs: { state: 'ready', enabled: true, perContent: true },
    host: { presentation: 'collapsed' },
  })
  await controller.start()
  assert.equal(controller.getSnapshot().state, 'waiting')
  assert.equal(hostFake.structureListenerCount(), 1, '构造传入的宿主也要登记结构观察器')

  // 面板变为正常停靠后，结构变化会触发重新结算。
  hostFake.host.readView = () => ({
    sessionId: 'session-1',
    panelIdentity: { sessionId: 'session-1', elementId: 'el-1' },
    expanded: true,
    presentation: 'push',
    framePx: 1280,
    observedPx: 576,
    activeDockContent: { sessionId: 'session-1', paneId: 'pane-0', tabId: 'tab1', kind: 'files', contentId: 'file:///a.md' },
    availability: { kind: 'ready' },
  })
  // 触发已登记的结构回调（真实环境里由 MutationObserver 触发）。
  for (const listener of hostFake.triggerStructure()) listener()
  assert.equal(controller.getSnapshot().state, 'active')
})

test('订阅能收到阶段变化，且回调抛错不影响控制器', async () => {
  const { controller, prefsFake } = makeController()
  const seen = []
  controller.subscribe((snapshot) => {
    seen.push(snapshot.state)
    throw new Error('订阅方抛错')
  })
  await controller.start()
  prefsFake.push({ state: 'ready', enabled: true, perContent: true })
  await Promise.resolve()
  assert.ok(seen.includes('prefs-waiting'))
  assert.ok(seen.includes('active'))
})
