/**
 * P08 第四片：服务与配置异常、关闭路径与重复启动（实现规划 9.1 的 E5/E9/E12/E15 与 P08 第 6、7 条）。
 *
 * 覆盖：
 *   * 总开关在拖拽中被关闭：结束手势、冲刷已接受值、重新打开后自动应用不被拦；
 *   * 清理抛错：如实报告为 failed，不打断关闭流程，之后仍可重新启用；
 *   * 配置写入被拒绝 / 冲突：返回失败原因，阶段与已确认值保持不变（不伪装成功）；
 *   * 宿主服务失效与替换：进入等待、替换后重新就绪，且**不重读宽度存储**；
 *   * 重复启动与卸载后再启动：不重复登记观察器、不复活已释放的实例；
 *   * 读不到可靠活动内容：不开始手势、不产生记录。
 *
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { createController } from '../lib/client/controller.js'
import { createRootLifecycle } from '../lib/client/lifecycle.js'
import { createWidthTable } from '../lib/client/width-table.js'

const PANEL = { sessionId: 'session-1', elementId: 'el-1' }
const settleMs = ms => new Promise(resolve => setTimeout(resolve, ms))

function makeHarness({ activeContent = true, cleanupThrows = false } = {}) {
  const table = createWidthTable()
  const applied = []
  const cleaned = []
  const logs = []
  const writes = []
  const reads = { count: 0 }
  const listeners = { structure: new Set(), drag: new Set(), width: new Set() }
  const state = { presentation: 'push', kind: 'files', content: activeContent }
  let prefsSnapshot = { state: 'ready', enabled: true, perContent: true, revision: 1, writable: true, mode: 'host' }
  let updateResult = { ok: true }
  const prefsListeners = new Set()

  const store = {
    async readAll() { reads.count += 1; return { kind: 'empty' } },
    protect() {},
    async writeAll(value) { writes.push(value); return { ok: true, durable: true } },
    async clearAll() { return { ok: true, durable: true } },
    getStatus: () => ({ available: true, writable: true, protected: false }),
  }

  const prefs = {
    getSnapshot: () => prefsSnapshot,
    subscribe(listener) { prefsListeners.add(listener); return () => prefsListeners.delete(listener) },
    async ensure() { return prefsSnapshot },
    async update(patch) {
      if (!updateResult.ok) return { ok: false, reason: updateResult.reason, snapshot: prefsSnapshot }
      prefsSnapshot = { ...prefsSnapshot, ...patch, revision: prefsSnapshot.revision + 1 }
      for (const listener of prefsListeners) listener(prefsSnapshot)
      return { ok: true, snapshot: prefsSnapshot }
    },
    dispose() {},
  }

  const makeHost = (label) => ({
    label,
    readView: () => ({
      sessionId: 'session-1',
      panelIdentity: PANEL,
      expanded: state.presentation === 'push',
      presentation: state.presentation,
      framePx: 1280,
      observedPx: 576,
      activeDockContent: state.content
        ? { sessionId: 'session-1', paneId: 'pane-0', tabId: 'tab1', kind: state.kind, contentId: 'f' }
        : undefined,
      availability: { kind: 'ready' },
    }),
    observeStructure(listener) { listeners.structure.add(listener); return () => listeners.structure.delete(listener) },
    observeDrag(listener) { listeners.drag.add(listener); return () => listeners.drag.delete(listener) },
    observeWidth(listener) { listeners.width.add(listener); return () => listeners.width.delete(listener) },
    async readFinalDragSample() { return null },
    async applyWidth(px) { applied.push({ who: label, px }); return { status: 'applied', requestedPx: px, observedPx: px } },
    async restoreDefault(reason) {
      if (cleanupThrows) throw new Error('宿主清理异常')
      cleaned.push(reason)
      return { status: 'applied', requestedPx: 576, observedPx: 576, resetLevel: 'numeric' }
    },
    dispose() {},
  })

  const hostA = makeHost('A')
  const hostB = makeHost('B')
  const controller = createController({
    lifecycle: createRootLifecycle(),
    prefs, table, store, host: hostA,
    log: line => logs.push(line),
  })

  return {
    controller, table, applied, cleaned, logs, writes, reads, state, hostA, hostB,
    setUpdateFailure: (reason) => { updateResult = { ok: false, reason } },
    setUpdateOk: () => { updateResult = { ok: true } },
    listenerCount: () => listeners.structure.size + listeners.drag.size + listeners.width.size,
    emitStructure: () => { for (const listener of listeners.structure) listener() },
    startDrag: () => { for (const listener of listeners.drag) listener({ kind: 'pointer-down', pointerId: 1, panelIdentity: PANEL }) },
    endDrag: () => { for (const listener of listeners.drag) listener({ kind: 'pointer-up', pointerId: 1 }) },
    emitWidth: (px) => {
      for (const listener of listeners.width) {
        listener({ px, panelIdentity: PANEL, pointerCommitSeq: 1, geometryGeneration: 5, phase: 'dragging', valid: true })
      }
    },
  }
}

test('总开关在拖拽中被关闭：结束手势、冲刷已接受值、重开后自动应用不被拦', async () => {
  const h = makeHarness()
  h.table.set('kind:files', 'split', 700)
  await h.controller.start()
  await settleMs(10)

  h.startDrag()
  h.emitWidth(724)
  assert.equal(h.table.get('kind:files', 'split'), 724)

  const closed = await h.controller.setEnabled(false)
  assert.equal(closed.ok, true)
  assert.equal(h.controller.getSnapshot().state, 'dormant')
  assert.ok(h.logs.some(line => line.includes('仍有手势在进行')), '关闭时要结束手势')
  assert.equal(h.writes.at(-1)?.split['kind:files'], 724, '关闭前把已接受的值冲刷掉')
  assert.equal(h.cleaned.at(-1), '总开关关闭')

  // 重新打开：手势已结束，自动应用必须恢复（不会永远停在 dragging）
  h.applied.length = 0
  const reopened = await h.controller.setEnabled(true)
  assert.equal(reopened.ok, true)
  assert.equal(h.controller.getSnapshot().state, 'active')
  h.state.presentation = 'collapsed'
  h.emitStructure()
  h.state.presentation = 'push'
  h.emitStructure()
  await settleMs(20)
  assert.equal(h.applied.at(-1)?.px, 724, '重开后按内存表恢复')
  await h.controller.dispose()
})

test('清理抛错：如实报告为失败，不打断关闭流程，之后仍可重新启用', async () => {
  const h = makeHarness({ cleanupThrows: true })
  await h.controller.start()
  await settleMs(10)

  const closed = await h.controller.setEnabled(false)
  assert.equal(closed.ok, true, '关闭本身要成功')
  const snapshot = h.controller.getSnapshot()
  assert.equal(snapshot.state, 'dormant')
  assert.match(snapshot.error ?? '', /默认清理抛错/)
  assert.equal(snapshot.lastAction.result.status, 'failed')

  const reopened = await h.controller.setEnabled(true)
  assert.equal(reopened.ok, true)
  assert.equal(h.controller.getSnapshot().state, 'active', '清理失败不影响后续启用')
  await h.controller.dispose()
})

test('配置写入被拒绝 / 冲突：如实返回原因，阶段与已确认值不变', async () => {
  for (const reason of ['宿主拒绝写入', 'revision 冲突，请重试']) {
    const h = makeHarness()
    await h.controller.start()
    await settleMs(10)
    h.setUpdateFailure(reason)

    const result = await h.controller.setEnabled(false)
    assert.equal(result.ok, false)
    assert.equal(result.reason, reason, '要把宿主给出的原因原样带回')
    assert.equal(h.controller.getSnapshot().state, 'active', '写入没成功就不能改变阶段')
    assert.equal(h.controller.getSnapshot().enabled, true, '已确认值保持为 true')

    h.setUpdateOk()
    assert.equal((await h.controller.setEnabled(false)).ok, true)
    assert.equal(h.controller.getSnapshot().state, 'dormant')
    await h.controller.dispose()
  }
})

test('宿主服务失效与替换：进入等待、替换后重新就绪，且不重读宽度存储', async () => {
  const h = makeHarness()
  h.table.set('kind:files', 'split', 700)
  await h.controller.start()
  await settleMs(10)
  assert.equal(h.reads.count, 1)

  h.controller.detachHost()
  assert.equal(h.controller.getSnapshot().state, 'waiting')
  const appliedBefore = h.applied.length
  h.emitStructure()
  await settleMs(10)
  assert.equal(h.applied.length, appliedBefore, '没有宿主时不应用宽度')

  h.controller.attachHost(h.hostB)
  await settleMs(20)
  assert.equal(h.controller.getSnapshot().state, 'active')
  assert.equal(h.applied.at(-1)?.who, 'B', '替换后的宿主生效')
  assert.equal(h.applied.at(-1)?.px, 700)
  assert.equal(h.reads.count, 1, '替换宿主不重读宽度存储')
  await h.controller.dispose()
})

test('重复启动与卸载后再启动：不重复登记观察器、不复活已释放的实例', async () => {
  const h = makeHarness()
  const first = await h.controller.start()
  const second = await h.controller.start()
  assert.equal(first.state, 'active')
  assert.equal(second.state, 'active')
  assert.equal(h.logs.filter(line => line.includes('控制器启动')).length, 1, '启动只做一次')
  assert.equal(h.listenerCount(), 3, '结构/拖拽/尺寸观察器各一个')

  await h.controller.dispose()
  assert.equal(h.controller.getSnapshot().state, 'disposed')
  assert.equal(h.listenerCount(), 0)
  const afterDispose = await h.controller.start()
  assert.equal(afterDispose.state, 'disposed', '释放后不再复活')
  assert.equal(h.reads.count, 1)
})

test('读不到可靠活动内容：不开始手势、不产生记录', async () => {
  const h = makeHarness({ activeContent: false })
  await h.controller.start()
  await settleMs(10)

  h.startDrag()
  h.emitWidth(700)
  assert.equal(h.table.serialize().split['kind:files'], undefined, '读不到类型就不记录')
  assert.ok(h.logs.some(line => line.includes('拖拽按下被忽略')))
  await h.controller.dispose()
})
