/**
 * P12 回归：宿主在**注册观察器时同步回调**，插件也必须不自激。
 *
 * 背景：修复前 `settle()` 里的条件重绑与 M1“注册即同步通知”形成无界互递归，
 * 「关闭总开关 → 重新开启」时真机渲染进程直接崩溃（见 `docs/plans/P12-...-fix-plan.md`）。
 *
 * 本文件用**故意同步回调**的宿主替身把当时的触发条件固定下来：
 *   * 结构观察器注册时同步回调（1 次与多次两种）；
 *   * 页签观察器注册时同步回调；
 *   * 断言：不抛栈溢出、结构回调次数有界、重入闸门计数被记录、阶段仍能正确推进；
 *   * 并断言关闭 / 重新开启这条路径本身可用（`13e34c3` 的语义不能丢）。
 *
 * 修复前的代码在这组用例上会抛 `Maximum call stack size exceeded`（诊断脚本组合二已证实）。
 *
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { createController } from '../lib/client/controller.js'
import { createRootLifecycle } from '../lib/client/lifecycle.js'
import { createWidthTable } from '../lib/client/width-table.js'

const PANEL = { sessionId: 'session-1', elementId: 'el-1' }
const settleMs = ms => new Promise(resolve => setTimeout(resolve, ms))

/**
 * 造一个“注册时同步回调”的宿主替身。
 *
 * @param options - `syncStructureTimes` 每次注册结构观察器时同步回调的次数；
 *                  `syncTabs` 是否在注册页签观察器时同步回调；`ready` 面板是否就绪。
 */
function makeHarness({ syncStructureTimes = 1, syncTabs = false, ready = true } = {}) {
  const table = createWidthTable()
  const counters = { structureCallbacks: 0, tabCallbacks: 0, applyWidth: 0, preApplyWidth: 0, restoreDefault: 0, structureRegistrations: 0 }
  let prefsSnapshot = { state: 'ready', enabled: true, perContent: true, revision: 1, writable: true, mode: 'host' }
  const prefsListeners = new Set()
  const logs = []
  let structureListener = null
  let tabsListener = null
  let panelReady = ready

  const prefs = {
    getSnapshot: () => prefsSnapshot,
    subscribe(listener) { prefsListeners.add(listener); return () => prefsListeners.delete(listener) },
    async ensure() { return prefsSnapshot },
    async update(patch) {
      prefsSnapshot = { ...prefsSnapshot, ...patch, revision: prefsSnapshot.revision + 1 }
      for (const listener of prefsListeners) listener(prefsSnapshot)
      return { ok: true, snapshot: prefsSnapshot }
    },
    dispose() {},
  }

  const host = {
    readView: () => (panelReady
      ? {
        sessionId: 'session-1',
        panelIdentity: PANEL,
        expanded: true,
        presentation: 'push',
        framePx: 1280,
        observedPx: 520,
        activeDockContent: { sessionId: 'session-1', paneId: 'pane-0', tabId: 'tab1', kind: 'files', contentId: 'f' },
        availability: { kind: 'ready' },
      }
      : {
        sessionId: 'session-1',
        panelIdentity: null,
        expanded: false,
        presentation: 'push',
        framePx: 1280,
        observedPx: null,
        activeDockContent: undefined,
        availability: { kind: 'waiting', reason: '找不到当前会话的正常右栏面板' },
      }),
    observeStructure(listener) {
      structureListener = listener
      counters.structureRegistrations += 1
      // 关键：像修复前的 M1 那样**同步**回调（reconcile → notifyStructure 的行为）。
      for (let index = 0; index < syncStructureTimes; index += 1) {
        counters.structureCallbacks += 1
        listener()
      }
      return () => { structureListener = null }
    },
    observeDrag() { return () => {} },
    observeWidth() { return () => {} },
    observeTabs(listener) {
      tabsListener = listener
      if (syncTabs) { counters.tabCallbacks += 1; listener() }
      return () => { tabsListener = null }
    },
    readServiceActiveContent: () => ({ sessionId: 'session-1', paneId: '', tabId: 'tab1', kind: 'files', contentId: 'f' }),
    preApplyWidth(px) { counters.preApplyWidth += 1; return { ok: true } },
    async applyWidth(px) { counters.applyWidth += 1; return { status: 'applied', requestedPx: px, observedPx: px } },
    async restoreDefault() { counters.restoreDefault += 1; return { status: 'applied', requestedPx: 576, observedPx: 576, resetLevel: 'numeric' } },
    async readFinalDragSample() { return null },
    capability: () => ({ canWriteWidth: true, structureHealthy: true, structureNote: null, hasTabsObservable: tabsListener !== null }),
    structureStats: () => ({ listeners: structureListener === null ? 0 : 1, notifications: counters.structureCallbacks, refused: 0 }),
    dispose() {},
  }

  const controller = createController({
    lifecycle: createRootLifecycle(),
    prefs, table, host,
    store: {
      async readAll() { return { kind: 'empty' } },
      protect() {},
      async writeAll() { return { ok: true, durable: true } },
      async clearAll() { return { ok: true, durable: true } },
      getStatus: () => ({ available: true, writable: true, protected: false }),
    },
    log: (line) => { logs.push(line); if (logs.length > 400) logs.shift() },
  })

  return {
    controller, table, counters, logs,
    openPanel() { panelReady = true },
    fireStructure() { if (structureListener) { counters.structureCallbacks += 1; structureListener() } },
  }
}

test('注册期同步回调：启动不自激，阶段正常推进', async () => {
  const h = makeHarness({ syncStructureTimes: 1 })
  h.table.set('kind:files', 'split', 520)
  await h.controller.start()
  await settleMs(30)

  assert.equal(h.controller.getSnapshot().state, 'active')
  assert.ok(h.counters.structureCallbacks < 20, `结构回调次数应有界，实际 ${String(h.counters.structureCallbacks)}`)
  assert.ok(h.counters.applyWidth <= 3, '不应重复应用')
  await h.controller.dispose()
})

test('注册期同步回调：关闭 → 重新开启总开关不再自激（P12 核心回归）', async () => {
  const h = makeHarness({ syncStructureTimes: 1 })
  h.table.set('kind:files', 'split', 520)
  await h.controller.start()
  await settleMs(30)
  const before = { ...h.counters }

  await h.controller.setEnabled(false)
  await settleMs(20)
  assert.equal(h.controller.getSnapshot().state, 'dormant')

  await h.controller.setEnabled(true)
  await settleMs(60)

  const delta = {
    structureCallbacks: h.counters.structureCallbacks - before.structureCallbacks,
    structureRegistrations: h.counters.structureRegistrations - before.structureRegistrations,
    applyWidth: h.counters.applyWidth - before.applyWidth,
  }
  assert.ok(delta.structureCallbacks < 40, `重开后回调次数应有界，实际 ${JSON.stringify(delta)}`)
  assert.ok(delta.structureRegistrations <= 4, `重开后登记次数应有界，实际 ${JSON.stringify(delta)}`)
  // 闸门记录到重入（说明同步回调确实发生了，且被挡下而不是递归下去）
  assert.ok(h.controller.getSnapshot().settleReentries >= 1, '重入闸门应记录到被挡下的重入')
  // 状态仍能正确推进到 active（重开后观察器必须真的重新登记）
  assert.equal(h.controller.getSnapshot().state, 'active')
  assert.ok(h.logs.some(line => line.includes('结算重入被挡下')), '日志里应能看到重入被挡下')
  await h.controller.dispose()
})

test('注册期多次同步回调（更极端）：仍不自激且状态正确', async () => {
  const h = makeHarness({ syncStructureTimes: 3, syncTabs: true })
  h.table.set('kind:files', 'split', 520)
  await h.controller.start()
  await settleMs(30)
  await h.controller.setEnabled(false)
  await settleMs(20)
  await h.controller.setEnabled(true)
  await settleMs(60)

  assert.ok(h.counters.structureCallbacks < 80, `回调次数应有界，实际 ${String(h.counters.structureCallbacks)}`)
  assert.equal(h.controller.getSnapshot().state, 'active')
  await h.controller.dispose()
})

test('重开后拖拽与保存能力仍在（保住 13e34c3 的语义）', async () => {
  const h = makeHarness({ syncStructureTimes: 1 })
  h.table.set('kind:files', 'split', 520)
  await h.controller.start()
  await settleMs(20)
  await h.controller.setEnabled(false)
  await settleMs(20)
  await h.controller.setEnabled(true)
  await settleMs(20)

  // 重新登记后，显式应用仍应生效（观察器与状态机没有卡在 dormant/waiting）
  h.table.set('kind:files', 'split', 640)
  const result = await h.controller.applyForCurrentContent()
  assert.equal(result.status, 'applied')
  assert.ok(h.counters.applyWidth >= 1)
  await h.controller.dispose()
})
