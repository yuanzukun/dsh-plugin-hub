/**
 * P13 回归：重新开启总开关后必须恢复记录尺寸，且不得再出现"首帧默认值"的跳变。
 *
 * 两条被修缺陷：
 *   * A：`stopForDisabled` 未复位就绪标记 ⇒ 重开后的第一次就绪不算上升沿 ⇒ 权威应用不触发；
 *   * B：预备应用闸门是"一次性 everReady"⇒ 偏好被停用清理改坏后仍被挡住（并且幂等去重也会挡住补写）。
 *
 * 用例设计要点（P13 的教训）：**记录值必须与宿主默认值不同**（这里 437 vs 576），
 * 否则"恢复了"与"没恢复"在读数上不可区分——P12 的验收正是因此漏掉了本缺陷。
 *
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { createController } from '../lib/client/controller.js'
import { createRootLifecycle } from '../lib/client/lifecycle.js'
import { createWidthTable } from '../lib/client/width-table.js'

const PANEL = { sessionId: 'session-1', elementId: 'el-1' }
const RECORDED_PX = 437
const UNIFIED_PX = 500
const DEFAULT_PX = 576
const settleMs = ms => new Promise(resolve => setTimeout(resolve, ms))

/**
 * 造宿主替身：记录每一次 应用 / 默认清理 / 预备应用，并可切换面板是否就绪。
 *
 * @param options - `ready` 面板初始是否就绪；`perContent` 是否区分内容。
 */
function makeHarness({ ready = true, perContent = true } = {}) {
  const table = createWidthTable()
  const calls = { apply: [], restore: [], preApply: [] }
  const logs = []
  let prefsSnapshot = { state: 'ready', enabled: true, perContent, revision: 1, writable: true, mode: 'host' }
  const prefsListeners = new Set()
  let structureListener = null
  let panelReady = ready

  const prefs = {
    getSnapshot: () => prefsSnapshot,
    subscribe(listener) { prefsListeners.add(listener); return () => prefsListeners.delete(listener) },
    async ensure() { return prefsSnapshot },
    async update(patch) {
      prefsSnapshot = { ...prefsSnapshot, ...patch, revision: prefsSnapshot.revision + 1 }
      for (const listener of prefsListeners) listener(prefsSnapshot)
      return { ok: true, snapshot: prefsSnapshot }
    },
    dispose() {},
  }

  const readyView = () => ({
    sessionId: 'session-1',
    panelIdentity: PANEL,
    expanded: true,
    presentation: 'push',
    framePx: 1280,
    observedPx: DEFAULT_PX,
    activeDockContent: { sessionId: 'session-1', paneId: 'pane-0', tabId: 'tab1', kind: 'guide', contentId: 'g' },
    availability: { kind: 'ready' },
  })
  const waitingView = () => ({
    sessionId: 'session-1',
    panelIdentity: null,
    expanded: false,
    presentation: 'push',
    framePx: 1280,
    observedPx: null,
    activeDockContent: undefined,
    availability: { kind: 'waiting', reason: '找不到当前会话的正常右栏面板' },
  })

  const host = {
    readView: () => (panelReady ? readyView() : waitingView()),
    observeStructure(listener) { structureListener = listener; return () => { structureListener = null } },
    observeDrag() { return () => {} },
    observeWidth() { return () => {} },
    observeTabs() { return () => {} },
    readServiceActiveContent: () => ({ sessionId: 'session-1', paneId: '', tabId: 'tab1', kind: 'guide', contentId: 'g' }),
    preApplyWidth(px) { calls.preApply.push(px); return { ok: true } },
    async applyWidth(px) { calls.apply.push(px); return { status: 'applied', requestedPx: px, observedPx: px } },
    async restoreDefault() {
      calls.restore.push(DEFAULT_PX)
      return { status: 'applied', requestedPx: DEFAULT_PX, observedPx: DEFAULT_PX, resetLevel: 'numeric' }
    },
    async readFinalDragSample() { return null },
    capability: () => ({ canWriteWidth: true, structureHealthy: true, structureNote: null, hasTabsObservable: true }),
    structureStats: () => ({ listeners: 1, notifications: 0, refused: 0 }),
    dispose() {},
  }

  const controller = createController({
    lifecycle: createRootLifecycle(),
    prefs, table, host,
    store: {
      async readAll() { return { kind: 'empty' } },
      protect() {},
      async writeAll() { return { ok: true, durable: true } },
      async clearAll() { return { ok: true, durable: true } },
      getStatus: () => ({ available: true, writable: true, protected: false }),
    },
    log: (line) => { logs.push(line); if (logs.length > 300) logs.shift() },
  })

  return {
    controller, table, calls, logs,
    openPanel() { panelReady = true },
    closePanel() { panelReady = false },
    fireStructure() { structureListener?.() },
  }
}

test('修复回归：记录值 437 与默认 576 不同，且断言确实用得到这个差异', () => {
  assert.notEqual(RECORDED_PX, DEFAULT_PX, '记录值必须与默认值不同，否则判据无效（P13 教训）')
})

test('重开总开关（面板就绪）：无需手工重开即应用记录值（缺陷 A）', async () => {
  const h = makeHarness({ ready: true })
  h.table.set('kind:guide', 'split', RECORDED_PX)
  await h.controller.start()
  await settleMs(40)

  await h.controller.setEnabled(false)
  await settleMs(40)
  assert.deepEqual(h.calls.restore, [DEFAULT_PX], '停用时应做一次数值默认清理')
  const appliedBefore = h.calls.apply.length

  await h.controller.setEnabled(true)
  await settleMs(120)

  const appliedOnEnable = h.calls.apply.slice(appliedBefore)
  assert.ok(appliedOnEnable.includes(RECORDED_PX), `重开后应立即应用记录值 ${String(RECORDED_PX)}，实际 ${JSON.stringify(appliedOnEnable)}`)
  assert.equal(h.controller.getSnapshot().state, 'active')
  await h.controller.dispose()
})

test('重开总开关（面板收起）：预备应用必须把记录值补写回偏好（缺陷 B，含去重失效）', async () => {
  const h = makeHarness({ ready: false })
  h.table.set('kind:guide', 'split', RECORDED_PX)
  await h.controller.start()
  await settleMs(40)
  // 面板收起时启动：预备应用已经写过一次 437
  assert.deepEqual(h.calls.preApply, [RECORDED_PX], '收起状态下启动时应预备应用记录值')

  await h.controller.setEnabled(false)
  await settleMs(40)
  const preAppliedBefore = h.calls.preApply.length

  await h.controller.setEnabled(true)
  await settleMs(120)

  const preAppliedOnEnable = h.calls.preApply.slice(preAppliedBefore)
  assert.ok(
    preAppliedOnEnable.includes(RECORDED_PX),
    `停用清理改坏了偏好，重开时必须**再写一次**（幂等去重也要失效），实际 ${JSON.stringify(preAppliedOnEnable)}`,
  )
  // 面板收起时不该走权威应用（applyWidth 需要正常停靠展示）
  assert.deepEqual(h.calls.apply, [], '收起状态不应调用 applyWidth')
  await h.controller.dispose()
})

test('统一模式下同样恢复（用户报告两种模式都有问题）', async () => {
  const h = makeHarness({ ready: true, perContent: false })
  h.table.set('', 'unified', UNIFIED_PX)
  await h.controller.start()
  await settleMs(40)
  await h.controller.setEnabled(false)
  await settleMs(40)
  const appliedBefore = h.calls.apply.length

  await h.controller.setEnabled(true)
  await settleMs(120)

  assert.ok(
    h.calls.apply.slice(appliedBefore).includes(UNIFIED_PX),
    `统一模式重开后应恢复 ${String(UNIFIED_PX)}`,
  )
  await h.controller.dispose()
})

test('重开后从收起状态打开面板：首帧目标就是记录值（不依赖任何手工操作）', async () => {
  const h = makeHarness({ ready: false })
  h.table.set('kind:guide', 'split', RECORDED_PX)
  await h.controller.start()
  await settleMs(40)
  await h.controller.setEnabled(false)
  await settleMs(40)
  await h.controller.setEnabled(true)
  await settleMs(80)
  const appliedBefore = h.calls.apply.length

  // 用户打开右栏：面板就绪 → 权威路径应立刻应用记录值（上升沿）
  h.openPanel()
  h.fireStructure()
  await settleMs(120)

  assert.ok(
    h.calls.apply.slice(appliedBefore).includes(RECORDED_PX),
    '面板就绪时应应用记录值（这一次应用之前，偏好已由预备应用写成记录值，因此首帧即正确）',
  )
  await h.controller.dispose()
})

test('幂等：重开后重复的结构事件不会重复写偏好', async () => {
  const h = makeHarness({ ready: true })
  h.table.set('kind:guide', 'split', RECORDED_PX)
  await h.controller.start()
  await settleMs(40)
  await h.controller.setEnabled(false)
  await settleMs(40)
  await h.controller.setEnabled(true)
  await settleMs(120)
  const afterEnable = { apply: h.calls.apply.length, preApply: h.calls.preApply.length }

  for (let index = 0; index < 5; index += 1) { h.fireStructure(); await settleMs(10) }

  assert.equal(h.calls.apply.length, afterEnable.apply, '重复结构事件不应重复应用')
  assert.equal(h.calls.preApply.length, afterEnable.preApply, '重复结构事件不应重复预备应用')
  await h.controller.dispose()
})
