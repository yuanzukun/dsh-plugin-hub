/**
 * M8 Preferences（src/client/preferences.ts）的纯逻辑验证。
 *
 * 用一个可编程的假配置表单代替 `ctx.configForms`，验证：
 *   * 首次确认前不给出可用取值（enabled/perContent 为 null）；
 *   * 宿主接受的写入才更新确认值；
 *   * 宿主拒绝、传输抛错、不可用、memory 模式各自返回失败原因而不更新确认值；
 *   * 取值形状不符合预期时视为尚未确认；
 *   * 释放后不再通知订阅方。
 *
 * 这一层不能证明真实宿主设置通道可用（那属于 U4 的目标环境验证）。
 *
 * 运行：`pnpm test`
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { createPreferences } from '../lib/client/preferences.js'

/**
 * 造一个可控的假 ConfigForm。
 * @param initial 初始快照字段（覆盖默认值）。
 */
function makeForm(initial = {}) {
  let snapshot = {
    status: 'loading',
    value: undefined,
    base: undefined,
    user: undefined,
    revision: undefined,
    writable: true,
    mode: 'host',
    ...initial,
  }
  const listeners = new Set()
  const calls = []
  let setResult = true
  let setThrows = null

  return {
    calls,
    form: {
      getSnapshot: () => snapshot,
      subscribe(listener) {
        listeners.add(listener)
        return () => listeners.delete(listener)
      },
      async set(field, value) {
        calls.push({ field, value })
        if (setThrows !== null) throw setThrows
        if (setResult) {
          snapshot = { ...snapshot, value: { ...(snapshot.value ?? {}), [field]: value } }
          for (const listener of listeners) listener()
        }
        return setResult
      },
      async unset() { return true },
      async mutate() { return true },
    },
    push(next) {
      snapshot = { ...snapshot, ...next }
      for (const listener of listeners) listener()
    },
    setBehavior({ result, throws }) {
      if (result !== undefined) setResult = result
      if (throws !== undefined) setThrows = throws
    },
    listenerCount: () => listeners.size,
  }
}

function makeCtx(form) {
  return { configForms: { get: () => form } }
}

test('首次确认前不给出可用取值：loading 时两个开关都是 null', () => {
  const fake = makeForm()
  const prefs = createPreferences(makeCtx(fake.form))
  const snapshot = prefs.getSnapshot()
  assert.equal(snapshot.state, 'loading')
  assert.equal(snapshot.enabled, null)
  assert.equal(snapshot.perContent, null)
  prefs.dispose()
})

test('确认值到达后投影出两个布尔开关，并通知订阅方', () => {
  const fake = makeForm()
  const prefs = createPreferences(makeCtx(fake.form))
  const seen = []
  prefs.subscribe(snapshot => seen.push(snapshot.state))

  fake.push({ status: 'ready', value: { enabled: true, perContent: false }, revision: 3 })

  const snapshot = prefs.getSnapshot()
  assert.equal(snapshot.state, 'ready')
  assert.equal(snapshot.enabled, true)
  assert.equal(snapshot.perContent, false)
  assert.equal(snapshot.revision, 3)
  assert.deepEqual(seen, ['ready'])
  prefs.dispose()
})

test('尚未就绪时拒绝写入，不假装已生效', async () => {
  const fake = makeForm()
  const prefs = createPreferences(makeCtx(fake.form))
  const result = await prefs.update({ enabled: false })
  assert.equal(result.ok, false)
  assert.match(result.reason, /尚未就绪/)
  assert.equal(fake.calls.length, 0)
  prefs.dispose()
})

test('宿主接受的写入更新确认值', async () => {
  const fake = makeForm({ status: 'ready', value: { enabled: true, perContent: true }, revision: 1 })
  const prefs = createPreferences(makeCtx(fake.form))
  const result = await prefs.update({ perContent: false })
  assert.equal(result.ok, true)
  assert.deepEqual(fake.calls, [{ field: 'perContent', value: false }])
  assert.equal(prefs.getSnapshot().perContent, false)
  assert.equal(prefs.getSnapshot().enabled, true)
  prefs.dispose()
})

test('宿主拒绝写入时保留原确认值并给出原因', async () => {
  const fake = makeForm({ status: 'ready', value: { enabled: true, perContent: true }, revision: 1 })
  const prefs = createPreferences(makeCtx(fake.form))
  fake.setBehavior({ result: false })

  const result = await prefs.update({ enabled: false })

  assert.equal(result.ok, false)
  assert.match(result.reason, /拒绝/)
  assert.equal(prefs.getSnapshot().enabled, true)
  assert.match(prefs.getSnapshot().error, /拒绝/)
  prefs.dispose()
})

test('传输抛错被捕获，不更新确认值', async () => {
  const fake = makeForm({ status: 'ready', value: { enabled: true, perContent: true }, revision: 1 })
  const prefs = createPreferences(makeCtx(fake.form))
  fake.setBehavior({ throws: new Error('connection lost') })

  const result = await prefs.update({ enabled: false })

  assert.equal(result.ok, false)
  assert.match(result.reason, /connection lost/)
  assert.equal(prefs.getSnapshot().enabled, true)
  prefs.dispose()
})

test('ready 但取值形状不符合预期时视为尚未确认', () => {
  const fake = makeForm({ status: 'ready', value: { enabled: 'yes', perContent: 1 } })
  const prefs = createPreferences(makeCtx(fake.form))
  const snapshot = prefs.getSnapshot()
  assert.equal(snapshot.state, 'loading')
  assert.equal(snapshot.enabled, null)
  assert.match(snapshot.error, /布尔/)
  prefs.dispose()
})

test('服务不可用时拒绝写入并说明原因', async () => {
  const fake = makeForm({ status: 'unavailable', writable: false, mode: 'memory' })
  const prefs = createPreferences(makeCtx(fake.form))
  const result = await prefs.update({ enabled: false })
  assert.equal(result.ok, false)
  assert.match(result.reason, /不可用/)
  prefs.dispose()
})

test('memory 模式（不可写）拒绝写入', async () => {
  const fake = makeForm({ status: 'ready', value: { enabled: true, perContent: true }, writable: false, mode: 'memory' })
  const prefs = createPreferences(makeCtx(fake.form))
  const result = await prefs.update({ enabled: false })
  assert.equal(result.ok, false)
  assert.match(result.reason, /不可写/)
  assert.equal(prefs.getSnapshot().enabled, true)
  prefs.dispose()
})

test('ensure 在取值到达后返回 ready 快照', async () => {
  const fake = makeForm()
  const prefs = createPreferences(makeCtx(fake.form))
  const pending = prefs.ensure()
  fake.push({ status: 'ready', value: { enabled: false, perContent: true } })
  const snapshot = await pending
  assert.equal(snapshot.state, 'ready')
  assert.equal(snapshot.enabled, false)
  prefs.dispose()
})

test('释放后不再通知订阅方，且订阅返回空释放函数', () => {
  const fake = makeForm()
  const prefs = createPreferences(makeCtx(fake.form))
  const seen = []
  prefs.subscribe(() => seen.push('hit'))
  prefs.dispose()
  fake.push({ status: 'ready', value: { enabled: true, perContent: true } })
  assert.deepEqual(seen, [])
  assert.equal(fake.listenerCount(), 0)
})
