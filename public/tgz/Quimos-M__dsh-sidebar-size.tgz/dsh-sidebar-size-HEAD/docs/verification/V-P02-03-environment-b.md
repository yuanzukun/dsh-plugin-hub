# V-P02-03 · 环境 B（裸桌面 + dsh-better-sidebar@0.24.1）复验

本记录按《执行规划》4.2 的字段填写，是 V-P02-02（环境 A）在兼容性目标 2 上的对应取证。

| 字段 | 内容 |
|---|---|
| 记录编号 | V-P02-03 |
| 问题/测试号 | 兼容性目标 2（DSH v0.2.0-rc2 + better-sidebar v0.24.1）；U1、U4 的 B 侧复验；T04 的前置（kind 映射） |
| 代码版本 | 提交 `0607b1f` 的工作树，产物 `lib/client.js` |
| 构建产物 | `pnpm build`（tsdown 0.22.14） |
| 环境 | 独立实例 `E:\DSH-plugin\_verify\env-b`：独立 `DSH_HOME` + 独立 Electron `--user-data-dir`，profile bundle 层为 `@deepseek-ai/dsh-base`、`@deepseek-ai/dsh-web-app`、`dsh-better-sidebar@0.24.1`、`dsh-sidebar-size`（`link:`）；webserver 端口 19488，CDP 9224，启动带 `-NoOcclusionThrottle` |
| 起始条件 | 全新 home（无历史宽度数据、无历史会话）；首次启动后右侧边栏处于**折叠**状态 |
| 操作与预期 | ① 观察插件是否加载、设置分组是否出现；② 读 `configForms`；③ 打开右栏后点“应用这个宽度 = 600”；④ 观察活动内容 kind |
| 实际观察 | ① 设置里同时出现 better-sidebar 的「侧边卡片」与本插件的「侧边栏尺寸」，装配次数 1；宿主服务 `layout=有, sidebarRight=有`，`宽度写入口 = 可用（layout.panels.setRightbar）`；② `状态 ready（host）`、`enabled=true`、`perContent=true`、`revision=0`、可写；③ 应用后 `applied (requested=600, observed=600)`，面板显示 `push`、框架宽 1280、实测 600；④ 活动停靠内容 `kind=guide tab=tab2`（openTabs → kind 映射在 B 环境同样有效） |
| 结论 | **通过**：在兼容性目标 2 的组合下，插件能加载、能读设置、能写入宽度且宿主重算渲染；分类所需的“DOM 页签 id → 运行时 kind”映射可用（本实例当前显示的是 better-sidebar 的 guide 页签） |
| 后续动作 | P06 做 T04（md 与 csv/xlsx 在 B 下的实际 kind 差异）时复用本实例 |

## 本记录发现的 A/B 差异（重要）

**`ctx.layout.openRightbar(true, false)` 在环境 B 不足以让右栏显示出来**：B 里调用后诊断面仍显示
`collapsed / 收起`，M1 因此返回 `deferred`（拒绝在非正常停靠形态下写入），而 A 里同一调用能让面板变为
`push`。用界面自身的「打开右侧边栏」按钮后才进入 `push`。

影响与处置：

1. 本插件的设计**不依赖**用该动作打开右栏：只在“正常停靠且可见”时写入，折叠/全屏时按 `deferred`
   保留意图（这正是 E13/E14 要求的行为）。
2. 但“关闭总开关时执行一次默认清理”不能假设自己能把右栏打开再写；P03 的清理路径必须在
   `deferred` 时如实报告“暂不可写”，不得先强行打开右栏再写。
3. 该差异说明“显示右栏”在 B 下由 better-sidebar 自己的状态参与决定；M1 只读判断（`presentation`）
   不受影响，因为它读的是实际面板属性。

## B 环境的拖拽采样复验（补齐）

| 字段 | 内容 |
|---|---|
| 操作 | 关掉设置面板（它作为遮罩会盖住手柄，见下）→ 把窗口放大到 1600×900 → 用 `experiments/drag-trace.mjs` 分别向两个方向拖手柄 |
| 实际观察 | 缩小方向：面板 720 → 570，采样 `#14…#22 px=690…570 phase=dragging commit=3 valid=true`；放大方向：570 → 720，`#26…#35 px=585…720 phase=dragging commit=4 valid=true`；两次之间窗口缩放产生的采样是 `px=720/600 phase=idle commit=— valid=false` |
| 结论 | **通过**：B 环境下用户拖拽同样产生与指针提交关联的有效采样，环境来源仍被正确排除。U3 在两种目标组合下都成立 |

两条操作事实（对后续实验很重要）：

1. **右栏宽度受布局约束**：面板上限约为 `框架宽 − 左栏 − 中栏最小 400`。1280 宽窗口下右栏上限约 600，
   此时向两个方向的拖拽都可能“看起来无效”——第一次复验就是误落在这一点上。实验前应把窗口放大到有
   余量的尺寸。
2. **设置面板会盖住右栏手柄**：设置面板打开时，手柄中心命中的是一个无 class 的遮罩元素
   （`elementFromPoint` 返回它），合成拖拽无法到达宿主；关掉设置面板后命中的就是手柄本身。
   这解释了“设置开着时拖拽无效”，也说明手柄的可用性取决于当前是否有遮罩层。

## 尚未在 B 覆盖的内容

- T04 的 md / csv / xlsx 三种内容的实际 kind 对照（属于 P06）。
- 卸载/禁用后的资源释放（T30）。
