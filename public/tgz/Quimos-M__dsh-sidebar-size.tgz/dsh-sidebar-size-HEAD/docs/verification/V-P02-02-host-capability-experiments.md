# V-P02-02 · 宿主能力实验（环境 A：裸桌面 + 本插件）

本记录按《执行规划》4.2 的字段填写，覆盖 P02 实验序里的第 1—4、6—8 步在**环境 A** 的结果。
环境 B（加 dsh-better-sidebar@0.24.1）与 U2 的完整默认语义仍未做，见文末“仍未完成”。

## 环境（本记录全部结论的适用范围）

| 项目 | 值 |
|---|---|
| 宿主 | DSH 桌面端 `0.2.0-rc.2`（Electron 44 / 内嵌 Node 24.18.1） |
| profile | 独立实例 `<仓库外>\E:\DSH-plugin\_verify\env-a\home\profiles\desktop`，bundle 层只有 `@deepseek-ai/dsh-base`、`@deepseek-ai/dsh-web-app` 与本插件 → 即“裸本体” |
| 隔离方式 | 独立 `DSH_HOME`（profiles/sessions/storages）+ 独立 Electron `--user-data-dir`（因此 localStorage 独立）+ profile 层把 webserver 端口从桌面端硬编码的 19387 覆盖为 19487 |
| 观测方式 | 本机 CDP（`--remote-debugging-port=9223`，只连 127.0.0.1）+ 插件实验日志键 `dsh-sidebar-size.probe.log` |
| 凭据 | 该 home 自动生成的是**匿名本地凭据**（161 B），不含用户 API key；本记录不涉及模型调用 |
| 被测代码 | 提交 `dc58e84` 之后的工作树（M1 重绑定修复 + 提交窗口修复），构建产物 `lib/client.js` |
| 操作者 | 输入由 CDP `Input.dispatchMouseEvent` 驱动（等价真实鼠标事件），其余由脚本观察 |

**环境事实 1（必须记住）**：窗口被遮挡时 Chromium 认为页面 `hidden`，**渲染步骤不再运行**，
ResizeObserver 回调不投递，`Input.dispatchMouseEvent` 一次拖拽耗时可达 60 秒。此时插件“记录已开启
但零回调”，这不是插件缺陷。隔离实例启动时加了 `--disable-features=CalculateNativeWinOcclusion`
与 `--disable-backgrounding-occluded-windows`（`experiments/verify-instance.ps1 -NoOcclusionThrottle`）
后 `document.visibilityState === 'visible'`，拖拽耗时降到 0.8 秒。**不支持该开关的操作者必须让窗口
保持前台可见，否则尺寸采样不可信。**

## 结果 1：U1 —— 宽度写入口

| 字段 | 内容 |
|---|---|
| 操作与预期 | 在设置分组里点“应用这个宽度 = 600px”；预期：能调用则写入，不能调用则如实报 unavailable |
| 实际观察 | `applied`，且右侧边栏在屏幕上真的改变了宽度；诊断面显示“宽度写入口：可用（layout.panels.setRightbar）” |
| 结论 | **通过**。`ctx.layout` 的 `panels.setRightbar`（TS `private`、类型层不可达，见 V-P02-01）在运行时确实存在且可调用；宿主会按请求值重算并渲染 |
| 影响 | 规划的“乙级依赖 + 能力检测 + 失败隔离”方案成立；M1 继续按能力检测调用，绝不改 DOM 样式 |

## 结果 2：U4 —— 设置读取与写入

| 字段 | 内容 |
|---|---|
| 操作与预期 | ① 诊断面读 `configForms` 快照；② 依次写入 `perContent=false`、`perContent=true` |
| 实际观察 | ① `状态 ready（host）`、`enabled=true`、`perContent=true`、`revision=0`、可写；② `宿主接受 perContent=false；现确认值 enabled=true perContent=false revision=3`，随后 `perContent=true → revision=4`；操作者报告“本插件设置页按钮闪烁一次，设置界面整体无闪烁” |
| 结论 | **通过（读与写）**。volatile 字段经设置服务到达浏览器后是**平面布尔值**（取值形状校验通过），这也回答了 V-P01-01 留的问题；写入走 `ConfigForm.set`，宿主接受后 revision 递增，插件没有被重新装配 |
| 未测 | 写入后的**跨重启保留**与“宿主拒绝/冲突”路径（T29 的另一半） |

## 结果 3：U5 —— 存储范围

| 字段 | 内容 |
|---|---|
| 操作与预期 | 写实验键 `dsh-sidebar-size.probe.1` → 关闭并重新启动独立实例 → 读取 |
| 实际观察 | 重启后读回同一时间戳 `probe-2026-10-03T18:36:09.123Z`；CDP 读 `localStorage` 同时可见 `dsh.sessions.current`、`dsh.sidebar-right.v1.<sessionId>`、`dsh.workspace.view.v5` |
| 结论 | **通过（重启保留）**。主应用来源 `dsh-app://app/` 下的 localStorage 跨应用重启保留，且与当前正在使用的实例互不影响（两个实例的 `--user-data-dir` 不同） |
| 未测 | 移动包体目录后保留（U5 的另一半）、跨设备导入 |

**附带事实**：宿主自己把右栏页签布局存在同来源 localStorage 的 `dsh.sidebar-right.v1.<sessionId>`；
本插件不读不写该键（它属于 DSH + better-sidebar 的数据）。

## 结果 4：U3 —— 拖拽来源与最终采样

| 字段 | 内容 |
|---|---|
| 操作与预期 | 自动开始记录 → CDP 驱动一次真实拖拽（手柄横向 100px）→ 再真实改变窗口大小（Win32 `MoveWindow`） |
| 实际观察（实验日志原文，新→旧） | `#19 px=406 phase=idle commit=— valid=false`、`#18 px=769 phase=idle commit=— valid=false`、`#17 手势 capture-released`、`#16 手势 pointer-up`、`#15 px=769 phase=dragging commit=1 valid=true` … `#4 px=677 phase=dragging commit=1 valid=true`、`#3 手势 pointer-down`、`#2 px=669 phase=idle commit=— valid=false`、`#1 面板重绑定 el-1 展示=push 可用=ready` |
| 结论 | **观测层通过**：拖拽过程产生 12 条与同一次指针提交关联的采样（`commit=1`、`valid=true`），窗口缩放产生的采样是 `phase=idle`、无提交、`valid=false`，两者可区分；抬起后还观察到过 `phase=ending` 的最终采样（另一次拖拽的 #24/#25，`px=520`） |
| 本记录修正的缺陷 | ① 观察器曾绑定失败：`observeStructure` 先运行并标记“已绑定”，随后加入尺寸/拖拽监听时元素身份未变 → 两个观察器都没建立（表现为“记录中但零样本”）；② 抬起后 `dragPhase` 从未复位，导致随后的窗口缩放被标成 `phase=ending valid=true`。两处已修 |
| 交给 P04 的设计输入 | M4 不能只看“阶段”，必须按**指针提交**判定：采样要带提交序号，且只在“该提交仍可能产生归属尺寸”的窗口内有效；窗口结束（本实现取 400ms）后一律视为环境来源。同一提交可产生多条渲染回调，需按提交合并取稳定值 |

## 环境事实 2（对 M1/M7 生命周期的影响）

设置面板关闭/打开、会话切换与面板重建都会替换右栏面板或手柄节点。观察器与指针监听必须
**跟着元素走**（M1 现在在结构变化时 `reconcile()` 重绑定，并在日志里记录“面板重绑定”行），
否则会出现“记录已开启但零回调”。同一次核验里，设置面板关掉再打开后诊断面实例身份不变、
装配次数不变 → 关掉设置页**不会**重新装配插件；因此 M6 的“单根实例”设计成立，M7 只需在
挂载/卸载时管理自己的订阅与草稿。

## 结果 5：U2 —— 数值恢复与“未挂载”默认语义

脚本 `experiments/u2-protocol.mjs`（同一实例内一次跑完，未重载页面）：

| 步骤 | 操作 | 实测（`frame` / `panel` / 宿主公式值） |
|---|---|---|
| M0 | 本次启动从未打开过右栏（偏好为 null） | 1280 / 576 / 576 |
| A1 | 关闭 → 打开（框架宽 1280） | 1280 / 576 / 576 |
| A2 | 关闭 → 窗口改为 886 → 打开 | 886 / **486** / 399 |
| A3 | 调用「恢复默认（数值）」 | 886 / **399** / 399 |
| A4 | 窗口改为 1486（不重新调用恢复默认） | 1486 / **399** / 669 |
| A5 | 调用 `setRightbar(null)`（非契约）→ 关闭 → 窗口改 886 → 打开 | 886 / **300** / 399 |

**结论：S11 的“完整默认语义”在本版本不可达，只能记为部分满足（numeric）。** 依据三条：

1. **宿主的默认值只在“首次打开且偏好为 null”时计算一次，之后一直保留**（A1→A2：偏好被首次打开写成 576，
   窗口变小后保留 576、并按可用空间钳到 486，而不是按新框架宽重算 399）。也就是说“已经打开过侧边栏的
   实例”本来就不再跟随框架宽；“等同从未打开过”没有任何插件可用的手段能达到。
2. **数值恢复等于“在调用时刻套用宿主默认公式”**（A3=399=公式值），但它是固定数字：之后改窗口不会重算
   （A4 仍是 399，而按公式本应是 669）。
3. **写回 `null` 不是替代方案**：`setRightbar` 的契约只接受数字，实测写 null 会把偏好置于被钳到下限的
   状态（A5=300），比“保留一个合理数字”更差。

**这条结论要交给人决定（对应执行规划的 H03）**：是接受“数值恢复（在关闭/重置的当下等于宿主默认）”作为
首版行为并据此记录 S11 为部分满足，还是要求真正的“未挂载等价”而把该要求挂起等待宿主提供公开重置动作。

## 仍未完成（P02 剩余项）

1. **U2 的目标环境复验**：本轮的 U2 结论全部在环境 A 得到；环境 B（加 better-sidebar）是否同样如此
   尚未验证（better-sidebar 接管 `files` 页签是否影响布局默认值需要实测）。
2. **U6 的运行侧与共享依赖**：本记录证明了“链接安装的插件能被加载、设置分组出现、
   `@deepseek-ai/schemastery` 能从插件自身 node_modules 解析”，但还没有在**环境 B**
   （加 better-sidebar）里跑同一套实验，也没有验证 `pnpm pack` 后的产物形态。
3. **卸载/释放的运行侧验收**（T30）：还没有在宿主里禁用/卸载本插件并确认资源释放。
4. **窗口无法置前时的采样可信度**只能靠 `-NoOcclusionThrottle` 保证，仍未在“窗口真的在前台”
   的条件下复验一次。
5. **实验工具的一个限制**：连续多次 `location.reload()` 会触发模块系统的
   `duplicate factory registration`（日志见 `crash-*-web-boot.log`，`dsh-sidebar-size: import failed`），
   导致启动审计报“1 entry did not activate”。这是模块系统层面的现象，不是插件缺陷；实验应优先用
   整实例重启来获得干净状态。
