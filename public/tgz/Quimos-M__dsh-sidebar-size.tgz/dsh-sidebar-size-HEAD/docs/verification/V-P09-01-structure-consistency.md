# V-P09-01 · 文件与模块契约一致性检查（P09 第 1 步）

| 字段 | 内容 |
|---|---|
| 记录编号 | V-P09-01 |
| 问题/测试号 | P09 第 1 步（对实际文件与模块契约做一致性检查）；T34 的静态部分 |
| 代码版本 | `v0.1.0-beta.1` 之后的工作树 |
| 检查工具 | `node experiments/consistency-check.mjs`（只读；不修改任何文件） |
| 结果 | **12 项全部通过** |

## 一、检查结果

| 检查项 | 结果 | 说明 |
|---|---|---|
| 平台模块表可解析 | 通过 | 4 项：`@deepseek-ai/cordis`、`dsh-client-store`、`dsh-client-ui-slots`、`dsh-client-ui-primitives` |
| 客户端源码没有跨插件值导入 | 通过 | 无。跨插件的类型专用导入单独列出（信息项） |
| 类型专用外部导入已登记 | 通过（信息） | `index.ts` 引入 `dsh-client-ui-renderer/settings/sidebar-right/layout` 的 `/client` 子路径（仅类型）；`preferences.ts`、`settings-section.tsx` 引入 `dsh-client-ui-settings/client`（仅类型） |
| 客户端源码的依赖都在 `package.json` 里声明 | 通过 | 按包名归一后无缺失 |
| 宿主半不引入客户端专用模块 | 通过 | 无 |
| 客户端半不引入 Node 专用模块 | 通过 | 无 |
| 宿主入口存在 | 通过 | `lib/index.js` |
| 客户端导出声明存在 | 通过 | `./lib/client.js` |
| 客户端产物存在 | 通过 | `lib/client.js` |
| 客户端产物没有内联 React（T34） | 通过 | 未出现 `react.development`、`__SECRET_INTERNALS_…`、`ReactCurrentDispatcher`、`react-dom/client`；包大小 134.4 KB（UTF-8 字节） |
| 产物按平台模块表引用宿主提供模块 | 通过 | 产物中保留 `@deepseek-ai/dsh-client-ui-primitives` 的引用 |
| 仓库根目录没有临时文件 | 通过 | 无 |

## 二、结构与命名现状（检查时的实际文件）

```
src/index.ts                     宿主半：Config 声明（enabled / perContent，volatile）
src/client/index.ts              客户端半入口：注入、生命周期、设置分组注册
src/client/contracts.ts          仅类型的模块间契约（M1—M8 的输入输出）
src/client/host-bridge.ts        M1  右侧边栏读取/观察/写入 + 结构健康 + 拖拽取消
src/client/content-kind.ts       M2  分类键（kind: + %XXXX 转义）
src/client/width-table.ts        M3  双命名空间内存表（schema 1、逐条剔除、整体保护）
src/client/guard.ts              M4  拖拽来源判定（Idle/Dragging/Ending、提交归属、几何代次）
src/client/width-store.ts        M5  独占键读写、原样保护、清除
src/client/controller.ts         M6  根控制器（阶段、门控、保存队列、两套记忆、导入导出）
src/client/settings-section.tsx  M7  设置分组界面（四项设置 + 迁移 + 诊断）
src/client/preferences.ts        M8  宿主设置确认值（ConfigForms）
src/client/lifecycle.ts          释放集合（逆序、幂等、异常隔离）
src/client/diagnostics.ts        诊断面（能力/视图/设置/记录/存储探针与控制器日志）
build/web-platform.ts            平台模块表（冻结的 external 白名单）
build/tsdown.client.ts           客户端 bundle 约定 + 跨插件值导入闸门
```

**结论**：模块边界与文件命名和实现规划第 3 节的 M1—M8 对应，没有需要拆分的文件
（最大文件 `src/client/controller.ts` 51 KB，承担 M6 的单一职责）；本步**不需要**修改任何文件，
因此 P09 第 1 条要求的“组织整理单独提交”在本轮没有产生提交。

## 三、顺带发现并修复的问题

一致性检查本身没有失败项，但 T09 的宿主实验（启动时总开关已关闭）暴露了一次**多余写入**：
启动读到已有数据后，关闭路径的冲刷又把同一份内容原样写回去（日志 `保存成功：修订 0`）。

修正的是“已落盘修订”的语义：读取成功即代表**存储与当前内存内容一致**，因此读完后把
`writtenRevision` 对齐到当前修订、`dirty = false`。这样“没有改动就不写回”，
同时不影响任何真实改动（改动仍会推进修订并落盘）。新增一项测试锁定该行为
（`tests/controller-p05.test.mjs`：启动读取成功后不把同一份数据原样写回）。
