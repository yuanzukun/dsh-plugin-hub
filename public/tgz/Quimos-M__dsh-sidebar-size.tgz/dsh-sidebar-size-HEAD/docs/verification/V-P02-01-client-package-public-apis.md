# V-P02-01 · DSH 0.2.0-rc.2 四包客户端公共 API 核验（逐字摘录）

- 记录编号：V-P02-01。核验方式：读取本机 `node_modules/@deepseek-ai/*/lib/types/**/*.d.ts`
  （与桌面端 0.2.0-rc.2 同版本线的已发布包）。范围：`dsh-client-ui-slots`、
  `dsh-client-ui-sidebar-right`、`dsh-client-ui-layout`、`dsh-client-locale`。
- 本记录回答的问题：**本插件能在客户端调用哪些公共 API**，尤其是“有没有写右栏宽度的公共入口”。
- 结论（对 U1 的直接输入）：slots / sidebarRight / layout 三者都**没有**写右栏宽度偏好的公共入口；
  唯一写路径是 layout store 的内部 action `setRightbar`，挂在 `LayoutController.panels`（TS `private`）
  上。因此 U1 只能在运行时做“能力检测 + 显式调用 + 失败隔离”，不能按公共 API 使用。

> **同日后续核验的两处更正**
> 1. 第 1 节写“`dsh-client-ui-renderer` 未安装，`ctx.slots` 的类名与 `inject` 签名 not found”。
>    后续已把 `@deepseek-ai/dsh-client-ui-renderer@0.2.0-rc.2` 装为 devDependency 并核实：
>    - `lib/types/client/index.d.ts:27`：`Context.slots: SlotRegistry`；
>    - `lib/types/client/registry.d.ts:46`：`class SlotRegistry extends Service`；
>    - `lib/types/client/registry.d.ts:85`：`readonly register: SlotCore['register']`（原型方法，
>      cordis 代理把 `this.ctx` 绑定到**调用方**上下文，因此注册随插件 fiber 释放）；
>    - `lib/types/client/registry.d.ts:111`：`inject(key, callback: () => SlotInjectionEffect): () => void`
>      （槽位声明就绪时运行回调，声明折叠时释放回调效果）。
> 2. 第 1 节关于 `register` 的 `options.inject`：本文件抄录的两个重载成立，第二个重载的
>    `inject: (...args) => I` 即“业务注入面”，其返回值 `I` 并入组件 props。

所有引用路径都相对工作区根目录；行号为该文件的真实行号。未标注“public/private”的方法均在公共 `.d.ts` 里公开可见。

---

## 1. `@deepseek-ai/dsh-client-ui-slots`

**导入说明符**：只有一个入口 `.`，没有 `./client`。

```json
".": { "types": "./lib/types/index.d.ts", "default": "./lib/index.js" }
```
（`node_modules/@deepseek-ai/dsh-client-ui-slots/package.json`）

**关键结论：本包里没有 `ctx.slots` 服务类，也没有任何 `inject` 方法。** 本包是“纯核心”（"Slot registry pure core … Zero runtime dependencies"），只导出 `SlotCore` 类 + 类型。提供 `ctx.slots` 的运行时服务在 `@deepseek-ai/dsh-client-ui-renderer`（"the renderer-owned SlotRegistry service"，见 `lib/types/index.d.ts:527`），该包**未安装**在本工作区（`node_modules/@deepseek-ai/` 与整个 pnpm store 中均不存在），因此 `ctx.slots` 的类名与 `inject` 方法签名**not found / 无法核验**。`ctx.slots` 唯一被引用到的一处是 locale 的注释文字：`ctx.slots.installLocale`（`node_modules/@deepseek-ai/dsh-client-locale/lib/types/client/index.d.ts:95`），无类型定义。

### register 的精确签名

`node_modules/@deepseek-ai/dsh-client-ui-slots/lib/types/index.d.ts:789-791`（无 inject 重载）：

```ts
register<K extends keyof SlotMap & string, const EntryKey extends EntryKeyOf<K> = EntryKeyOf<K>, const D extends ChildrenDecl = Record<never, never>, H extends StoreDecl | undefined = undefined, M = never, N extends (keyof LocaleNamespaceMap & string) | undefined = undefined, C extends SlotComponent<never> = SlotComponent<never>>(options: BaseOptions<K, EntryKey, D, H, M, N> & {
    inject?: undefined;
}, component: C & SlotComponent<ComposedProps<K, NoInfer<EntryKey>, keyof NoInfer<D> & keyof SlotMap & string, HandleOf<NoInfer<H>>, object, NoInfer<M>, NoInfer<N>>> & RendersCheck<C, D>): () => void;
```

`:802-804`（带 inject 的重载）：

```ts
register<K extends keyof SlotMap & string, I extends object, const EntryKey extends EntryKeyOf<K> = EntryKeyOf<K>, const D extends ChildrenDecl = Record<never, never>, H extends StoreDecl | undefined = undefined, M = never, N extends (keyof LocaleNamespaceMap & string) | undefined = undefined, C extends SlotComponent<never> = SlotComponent<never>>(options: BaseOptions<K, EntryKey, D, H, M, N> & {
    inject: (...args: InjectParams<K, H>) => I;
}, component: C & SlotComponent<ComposedProps<K, NoInfer<EntryKey>, keyof NoInfer<D> & keyof SlotMap & string, HandleOf<NoInfer<H>>, I, NoInfer<M>, NoInfer<N>>> & RendersCheck<C, D>): () => void;
```

**返回类型就是裸 `() => void`（即 disposer），不是别名类型。**

### options 对象的字段（`BaseOptions`，`:597-613`）

```ts
type BaseOptions<K extends keyof SlotMap & string, EntryKey extends EntryKeyOf<K>, D extends ChildrenDecl, H, M = never, N = undefined> = {
    /** Target slot key (the entry contributes INTO this slot). */
    name: K;
    /** Child-slot declaration + render authorization + runtime spec, in one table. */
    children?: D;
    /** Store seat: a shared handle (apply-constructed) or an exclusive factory (framework-called per entry x scope). */
    store?: H;
    locale?: N;
    registrant?: string;
} & KindOptions<K, EntryKey, M>;
```

`KindOptions`（`:560-583`，逐字要点）：`kind: 'keyed'` → `{ key: EntryKey; priority?: number }`；`kind: 'list'` → `{ id: string; order?: number; label?: SlotLabel; priority?: number }`；`kind: 'chain'` → `{ select: ChainSelect<...>; priority?: number }`；其余 → `{ priority?: number }`。`SlotLabel`（`:555`）= `string | (() => string)`。

### `PropsRuntime<Name>` 与 `SlotMap`

```ts
/** Slot contract table. Owners extend via declaration merging; entries are {@link SlotEntryDef}. */
export interface SlotMap {
}
```
（`:16-18`）

```ts
export type PropsRuntime<K extends keyof SlotMap & string, EntryKey extends EntryKeyOf<K> = EntryKeyOf<K>> = OwnerOf<K> & KeyPropsOf<K, EntryKey> & SlotInjectFace<SlotInjectOf<K>> & ScopeStandardProps<ScopeOf<K>>;
```
（`:222`）

```ts
export interface SlotEntryDef {
    kind: SlotKind;
    scope: SlotScope;
    owner?: object;
    keyProps?: Record<string, object>;
    hookContext?: unknown;
    inject?: object;
}
```
（`:96-118`，已省注释）其中 `SlotKind = 'single' | 'list' | 'keyed' | 'chain'`（`:83`），`SlotScope = 'root' | 'session-maybe' | 'session'`（`:85`）。

注册者的组件 props 由框架合成，注册点要求的是它的**子集约束**而非直接写 `PropsRuntime`：

```ts
export type ComposedProps<K extends keyof SlotMap & string, EntryKey extends EntryKeyOf<K>, S extends keyof SlotMap & string, H, I extends object, M = never, N = undefined> = PropsRuntime<K, EntryKey> & PropsRenderSlots<S> & PropsRenderFactories & PropsStore<H> & InjectFace<I> & MatchedShare<SlotMap[K], M> & PropsLocale<N>;
```
（`:474`）

```ts
export type SlotComponent<P> = (props: P) => ReactNode;
```
（`:343`）

### disposer（注销）

- `register(...)` 返回 `() => void`；文档："@returns disposer removing the registration and its declarations (idempotent; stale disposers after a cascade are no-ops)"（`:786-787`）。
- `SlotCore.subscribe(key, fn): () => void`（`:871`）、`subscribeDeclaration`（`:882`）、`onMutate`（`:897`）、`onEntryError`（`:933`）、`subscribeFactory`（`:750`）同样返回 `() => void`。

### 同包其它已装类型（`store.d.ts` / `renderer.d.ts`）

- `node_modules/@deepseek-ai/dsh-client-ui-slots/lib/types/store.d.ts:2` 只做再导出：`ActionsDecl, BakedActions, BoundActions, DefineStore, HandleOf, MaybeSnapshotSelectorHook, PropsStore, SnapshotSelectorHook, StoreDecl, StoreFactory, StoreHandle, StoreInstance, StoreSpec`（来自 `@deepseek-ai/dsh-client-store`）。
- `renderer.d.ts` 定义 `HostObservable<T> = ObservableSnapshot<T>`（`:33`）、`LocaleFace`（`:19-31`）、`SlotRendererHost`（`:114`）、`SlotRenderer`（`:244`）、`StaleAuthorizationError`（`:254`）、`SlotOwnershipError`（`:261`）。
- 供参考：`node_modules/@deepseek-ai/dsh-client-store/lib/types/contract.d.ts:111-114` — `PropsStore<H>` 给出 `useStore: SnapshotSelectorHook<T>` 与 `actions: BakedActions<T, A>`。

**本插件可安全调用**：`ctx.slots` 在本工作区**无类型可依**（服务类不在已安装包里），只能依赖 `SlotCore.register(...)` 的两种重载与 `SlotMap`/`PropsRuntime` 声明合并；注册一个 slot 就用 `register`（返回 disposer 注销），本包内不存在 `inject` 成员。

---

## 2. `@deepseek-ai/dsh-client-ui-sidebar-right`

**导入说明符（类型）**：`@deepseek-ai/dsh-client-ui-sidebar-right/client`（`lib/types/client/index.d.ts`）。根入口 `lib/types/index.d.ts` 只有宿主半边 `export declare function apply(): void;`。

```json
"./client": { "types": "./lib/types/client/index.d.ts", "default": "./lib/client.js" }
```

### Context 合并（逐字）

`node_modules/@deepseek-ai/dsh-client-ui-sidebar-right/lib/types/client/index.d.ts:20-27`：

```ts
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Right-Sidebar navigation and presentation face. */
        sidebarRight: SidebarRightController;
        /** Right-Sidebar tab-type registry (stage one of a tab type's registration). */
        sidebarRightTabs: SidebarRightTabRegistry;
    }
}
```

注意 `ctx.sidebarRight` 的类型是**实现类** `SidebarRightController`，不是接口 `ISidebarRight`。

### `ISidebarRight`（公共面，`lib/types/client/service.d.ts:138-211`）

```ts
export interface ISidebarRight {
    readonly mounted: ObservableSnapshot<SessionId | undefined>;
    openResource(address: string, options?: SidebarRightOpenResourceOptions): void;
    openTab<K extends string>(kind: K, options?: SidebarRightOpenTabOptions<K>): void;
    close(tabId: TabId): void;
    active(): TabRecord | undefined;
    isExpanded(): boolean;
    toggleExpanded(): void;
    focus(tabId: TabId): void;
    split(paneId?: PaneId): PaneId | undefined;
    float(tabId: TabId, rect?: FloatRect): void;
    dock(paneId: PaneId): void;
}
```
（已删注释；`mounted` 文档见 `:139-148`，`active()` 文档见 `:174-178`，`isExpanded()` 见 `:179-183`。）

`openTabs` **不在 `ISidebarRight` 里**，只在实现类上：`service.d.ts:216-217`

```ts
    /** Open tab metadata across saved and adopted Sessions, independent of visible seats. */
    readonly openTabs: SidebarTabInventory['source'];
```

### 实现类 `SidebarRightController`（`:213-409`）的成员可见性

公共（无 `private`）：
```ts
export declare class SidebarRightController implements ISidebarRight {
    private readonly tabs;
    private readonly host;
    readonly openTabs: SidebarTabInventory['source'];
    readonly mounted: ObservableSnapshot<SessionId | undefined>;
    private readonly adopted;
    private readonly rooms;
    private readonly closeHandlers;
    registerCloseHandler(kind: string, handler: SidebarRightCloseHandler): () => void;
    readonly tabDomain: TabDomain;
    constructor(tabs: SidebarRightTabRegistry, pin: PinResource, host: SidebarRightHost, sessions: SidebarRightSessions);
    tabsIn(sessionId: SessionId): readonly TabRecord[];
    ... openResource/openTab/openResourceIn/openTabIn/closeIn ...
    private removeAfterCleanup; private placeResource; private placeTab; private place;
    close(tabId: TabId): void;
    active(): TabRecord | undefined;
    isExpanded(): boolean;
    toggleExpanded(): void;
    focus(tabId: TabId): void;
    focusedTarget(element?: Element | null): SidebarRightTarget | undefined;
    commandTarget(element?: Element | null): SidebarRightTarget | undefined;
    openTabFromTarget(kind: string, target: SidebarRightTarget): void;
    canCloseTarget(target: SidebarRightTarget): boolean;
    closeTarget(target: SidebarRightTarget): 'closed' | 'unavailable' | 'stale';
    isTargetCurrent(target: SidebarRightTarget): boolean;
    splitBlock(target: SidebarRightTarget): 'stale' | 'collapsed' | 'float' | 'empty' | 'budget' | 'width' | undefined;
    toggleFullscreen(target: SidebarRightTarget): void;
    split(paneId?: PaneId): PaneId | undefined;
    float(tabId: TabId, rect?: FloatRect): void;
    dock(paneId: PaneId): void;
    _undo(): void;
    _redo(): void;
    private screen; private mountedSurface; private canSplitPane; private actionsFor; private require;
}
```

要点：`openTabs` 与 `tabsIn(sessionId)`、`registerCloseHandler(...)`、`tabDomain`、`_undo()/_redo()` 都**不在 `ISidebarRight`** 中，其中 `openResourceIn` / `openTabIn` / `closeIn` 的注释明确写着 "Not part of `ISidebarRight`"（`:263`、`:272`、`:281`）；`_undo/_redo` 标注 `@internal Not part of the product`（`:383`）。`private` 成员（`screen`、`mountedSurface`、`canSplitPane`、`actionsFor`、`require`、`tabs`、`host`、`adopted`、`rooms`、`closeHandlers`）不可从类型层调用。

### tab 记录形状

`TabRecord` / `TabId` / `PaneId` / `FloatRect` 来自 **`@deepseek-ai/dsh-client-ui-dockkit`**，本工作区**未安装**（node_modules 与 pnpm store 中无该包），仅再导出：

```ts
export type { FloatRect, PaneId, TabId, TabRecord } from '@deepseek-ai/dsh-client-ui-dockkit';
```
（`lib/types/client/index.d.ts:13`）→ `TabRecord` 的字段定义 **not found（无法逐字引用）**。

可核验的“类四元组”形状是 `openTabs` 的元素类型 `SidebarRightOpenTab`（`lib/types/client/tab-inventory.d.ts:6-11`）：

```ts
export interface SidebarRightOpenTab {
    readonly sessionId: SessionId;
    readonly tabId: TabId;
    readonly kind: string;
    readonly contentId: string;
}
```
即提问中的 `{ sessionId, tabId, kind, contentId }` 确实存在，但**这是 `openTabs` 的元素类型，且四个字段全部必需（无 `?`）**，不是 `TabRecord`。`TabRecord` 另有一处用法可见其必含字段：`SidebarRightInjected.occurrence: (tab: Pick<TabRecord, 'id'>) => TabOccurrence`（`lib/types/client/shell/SidebarRight.d.ts:70`），以及 `SidebarRightTabInfo.tab: TabRecord & { refreshShortcut?: ...; visible: boolean; navigation: ...; signal: AbortSignal; actions: ... }`（`lib/types/client/contract/slots.d.ts:178-190`）。

### 是否存在写右栏宽度的公共成员

- `ctx.sidebarRight`（`SidebarRightController` / `ISidebarRight`）上：**不存在**任何 `setRightbar`、`rightbar`、`width`、`resize*` 成员。全文检索本包 `.d.ts` 只有注释里的 “width” 与 `splitBlock(...): ... | 'width'`（一个诊断字符串，不是写入口）。
- 本包 store 的 action 表 `SidebarRightActions`（`lib/types/client/stores.d.ts:91-111`）里也**没有**宽度 action：只有 `open/setExpanded/toggleExpanded/setMode/splitPane/openContent/duplicateTab/closeTab/focusTab/focusPane/placeTab/dropTab/floatTab/unfloatPane/moveFloat/resizeFloat/resizeSplit/undo/redo`。`resizeFloat`/`resizeSplit` 是**浮窗与分栏**尺寸，不是右栏宽度。
- `SidebarRightPresentation`（`shell/SidebarRight.d.ts:17-24`）只有 `shown`/`track`/`fullscreen` 三个布尔，且是**内部 inject 面** `syncPresentation(presentation)`（`:26-34`），不是公共宽度写入口。

**本插件可安全调用**：`ctx.sidebarRight` 的 `mounted`（`ObservableSnapshot<SessionId | undefined>`）、`active(): TabRecord | undefined`、`isExpanded()`、`toggleExpanded()`、`openTab/openResource/close/focus/split/float/dock`；`openTabs` 只有在把类型当作 `SidebarRightController`（`ctx.sidebarRight` 的声明类型）时才可见。宽度写入：**无公共 API**。

---

## 3. `@deepseek-ai/dsh-client-ui-layout`

**导入说明符（类型）**：`@deepseek-ai/dsh-client-ui-layout/client`（`lib/types/client/index.d.ts`）。根入口 `lib/types/index.d.ts` 只有 `export declare function apply(): void;`。

```json
"./client": { "types": "./lib/types/client/index.d.ts", "default": "./lib/client.js" }
```

### Context 合并（逐字）

`node_modules/@deepseek-ai/dsh-client-ui-layout/lib/types/client/index.d.ts:18-23`：

```ts
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The outward face only; the concrete service stays inside this plugin. */
        layout: import('./service.ts').ILayout;
    }
}
```

### `ILayout`（ctx.layout 的全部公共成员，`lib/types/client/service.d.ts:24-50`）

```ts
export interface ILayout {
    /** Selected central panel from the same root store used by `usePanelInfo`. */
    readonly panelInfo: HostObservable<PanelInfo>;
    selectPanel(panelId: MainPanelId | null): void;
    beginNavigation(): AbortSignal;
    /** Toggle the sidebar panel (closed ⟷ contract default width). */
    toggleSidebar(): void;
    openRightbar(track: boolean, fullscreen: boolean): void;
    /** Report the right panel as hidden: no track, no handle. */
    closeRightbar(): void;
}
```
（`PanelInfo` = `{ readonly activePanelId: MainPanelId | null }`，`:17-20`；`MainPanelId = Branded<'MainPanelId'>`，`:15`。）

**逐项对照提问：**
- 读右栏宽度**偏好**：`ILayout` 上**没有** —— 无 `rightbar`、无 `layoutInfo`、无 `rightbarWidth`。**not found**。
- 写右栏宽度：`ILayout` 上**没有** `setRightbar` / `resize`。唯一相关的右栏入口是 `openRightbar(track, fullscreen)`（只报告“是否占轨道 / 是否全屏”，注释 `:40-47`）与 `closeRightbar()`。
- 测量 frame/viewport：`ILayout` 上**没有**测量方法；`beginNavigation()` 只返回 `AbortSignal`。
- observable/store 访问器：只有 `readonly panelInfo: HostObservable<PanelInfo>`。没有 `layoutInfo`、没有 `panels`。

### 实现类 `LayoutController` 的 `private` 成员（“乙级依赖”候选）

`lib/types/client/service.d.ts:52-75`：

```ts
export declare class LayoutController implements ILayout {
    private readonly panels;
    private readonly hasMainPanel;
    readonly panelInfo: HostObservable<PanelInfo>;
    private navigation;
    constructor(panels: PanelActions, hasMainPanel: (id: MainPanelId) => boolean, panelInfo: HostObservable<PanelInfo>);
    selectPanel(panelId: MainPanelId | null): void;
    beginNavigation(): AbortSignal;
    dispose(): void;
    toggleSidebar(): void;
    openRightbar(track: boolean, fullscreen: boolean): void;
    closeRightbar(): void;
}
```
`private readonly panels` 正是布局 store 的绑定 action 集（`PanelActions = BoundActions<ReturnType<typeof createLayoutStore>>`，`:22`）——**宽度写入口 `setRightbar` / `setSidebar` 只能经它到达，而它是 `private`，类型层不可用**。

### `setRightbar` 的真实声明位置（非公共 API）

`lib/types/client/stores.d.ts:11-60`（**`export {}`，`LayoutState`/`LayoutInfo`/`LayoutActions` 均未导出**；只有 `createLayoutStore` 被导出，`lib/types/client/index.d.ts` 也没有再导出它）：

```ts
type LayoutInfo = {
    sidebar: number;
    viewportWidth: number;
    narrowExpanded: boolean;
    rightbar: number | null;
    rightbarShown: boolean;
    rightbarTrack: boolean;
    rightbarFullscreen: boolean;
    rightbarInstant: boolean;
};
```
```ts
type LayoutActions = {
    selectPanel: (draft: LayoutState, panelId: MainPanelId | null) => void;
    retainMainPanels: (draft: LayoutState, panelIds: readonly string[]) => void;
    setSidebar: (draft: LayoutState, px: number) => void;
    toggleSidebar: (draft: LayoutState) => void;
    setViewportWidth: (draft: LayoutState, width: number) => void;
    setRightbar: (draft: LayoutState, px: number) => void;
    openRightbar: (draft: LayoutState, track: boolean, fullscreen: boolean) => void;
    closeRightbar: (draft: LayoutState) => void;
};
```
（`createLayoutStore(): EngineStoreHandle<LayoutState, LayoutActions>`，`:70`。用户可见的 baked 形式是 `PropsStore<...>['actions']`：`node_modules/@deepseek-ai/dsh-client-store/lib/types/contract.d.ts:111-114`。）

**判定**：`setRightbar` / `setSidebar` 是**布局 store 的内部 action**，通过组件 props 的 `actions`（`AppFrameProps = ... & PropsStore<ReturnType<typeof createLayoutStore>> ...`，`client/AppFrame.d.ts:4`）与 `LayoutController.panels`（`private`）出现，**不是 `ctx.layout` 的公共 API**。`ctx.layout.panelInfo` 的注释也定性为 "The outward face only"（`client/index.d.ts:20`）。

### 框架本身怎么“量”宽度（只读常量与纯函数，可 import）

`lib/types/client/columns.d.ts`：`interface Columns { sidebar: number; center: number; rightbar: number }`（`:7-11`）；常量 `CENTER_MIN = 400`、`SIDEBAR_MIN = 264`、`SIDEBAR_MAX = 420`、`SIDEBAR_DEFAULT = 280`、`SIDEBAR_COLLAPSED = 56`、`SIDEBAR_AUTO_COLLAPSE = 1024`、`RIGHTBAR_MIN = 300`、`RIGHTBAR_MAX_RATIO = 0.7`、`RIGHTBAR_DEFAULT_RATIO = 0.45`（`:13-31`）；`clampWidth(px, min, max): number`（`:39`）；`computeColumns(viewport: number, sidebar: number, rightbar: number, collapsedWidth?: number): Columns`（`:50`）。

右栏 owner props（不是 ctx 成员）：`RightbarOwnerProps`（`client/index.d.ts:116-126`）= `{ width: number; viewportWidth: number; canShow: boolean }`，注释明确 "Resolved normal panel width in px, **not the saved preference**"。

**本插件可安全调用**：`ctx.layout.panelInfo`（只读 observable）、`selectPanel`、`beginNavigation`、`toggleSidebar`、`openRightbar/closeRightbar`（仅报告展示形态）。**宽度偏好既不可读也不可写**；`setRightbar` 属实现层 `private`/store 内部，本插件不得依赖。

---

## 4. `@deepseek-ai/dsh-client-locale`

**导入说明符（类型）**：`@deepseek-ai/dsh-client-locale/client`（`lib/types/client/index.d.ts`）。根入口 `lib/types/index.d.ts` 只有宿主侧 `Config`/`apply`。

```json
"./client": { "types": "./lib/types/client/index.d.ts", "default": "./lib/client.js" }
```

### Context 合并与事件（`lib/types/client/index.d.ts:57-72`）

```ts
declare module '@deepseek-ai/cordis' {
    interface Context {
        locale: LocaleRuntime;
    }
    interface Events {
        'locale/change'(snapshot: LocaleSnapshot): void;
    }
}
```

### `register` 的精确签名（两个重载，`index.d.ts:199` 与 `:209`）

```ts
register<N extends Extract<keyof LocaleNamespaceMap, string>>(ns: N, dicts: Record<BuiltInLocaleId, LocaleDictOf<N>>): () => void;
```
```ts
register(ns: string, locale: string, dict: LocaleDict): () => void;
```

- `BuiltInLocaleId = typeof LOCALE_IDS[number]`，`LOCALE_IDS = readonly ["zh", "en"]`（`node_modules/@deepseek-ai/dsh-client-locale/lib/types/locale-settings.d.ts:10-12`）——即类型化重载要求**两种内置语言都必须给全**，且键集必须与命名空间并表完全一致。
- `LocaleDict = Record<string, string>`（`client/index.d.ts:29`）。
- 两个重载都返回 `() => void`（"disposer removing every locale registered by this call (idempotent)"，`:197`）。

### 字典键的类型助手

```ts
/** Dictionary shape for a declared namespace: exactly the keys the namespace merged into {@link LocaleNamespaceMap} — a missing or extra key at a typed registration site is a compile error. */
export type LocaleDictOf<N extends keyof LocaleNamespaceMap & string> = Record<LocaleNamespaceMap[N] & string, string>;
```
（`node_modules/@deepseek-ai/dsh-client-ui-slots/lib/types/index.d.ts:73`，该类型住在 **ui-slots**，locale 只是 import 使用）

配套键域助手（同文件）：`LocaleKeysOf<N> = (LocaleNamespaceMap[N] & string) | CommonKeyOf`（`:59`）、`TranslateNS<N> = Translate<LocaleKeysOf<N>>`（`:67`）、`Translate<K> = (key: K, params?: Record<string, unknown>) => string`（`:45`）、`CommonKeyOf`（`:51-53`）。命名空间并表入口：`interface LocaleNamespaceMap {}`（`:30-31`），locale 包自己并入 `common: CommonKey` 与 `'settings.locale': SettingsLocaleKey`（`client/index.d.ts:20-27`），`CommonKey` 来自 `lib/types/locales/zh.ts` 并经 `client/index.d.ts:17` 再导出。

`bind`（同一服务，`:219` / `:226`）：`bind<N extends Extract<keyof LocaleNamespaceMap, string>>(ns: N): TranslateNS<N>;` 与 `bind(ns: string): Translate;`；另有 `getLocale(): LocaleSnapshot`（`:123`）、`getSnapshot(): LocaleSnapshot`（`:136`）、`subscribe(fn: () => void): () => void`（`:144`）、`setLocale(id: string): void`（`:157`）、`addLanguage(input: LanguageRegistration): () => void`（`:170`）、`resolveText(text: LocalizedText): string`（`:130`）。

**本插件可安全调用**：`ctx.locale.register(ns, dicts)`（声明命名空间后两语言齐全、返回 disposer）或三参无类型重载，`ctx.locale.bind(ns)` 取类型化 `t`，`getSnapshot/subscribe` 跟随语言切换；键集必须与 `LocaleNamespaceMap` 并表一致。

---

## 汇总（一行一条）

| 包 / 导入说明符 | 本插件可安全调用 | 不可用（absent / 非公共） |
|---|---|---|
| `@deepseek-ai/dsh-client-ui-slots` | `SlotCore.register(...)` 两重载（返回 `() => void` disposer）、`SlotMap`/`PropsRuntime` 声明合并、`subscribe/onMutate` 等 `() => void` 订阅 | 本包**无 `ctx.slots` 服务类、无 `inject` 方法**；该服务属未安装的 `dsh-client-ui-renderer` |
| `@deepseek-ai/dsh-client-ui-sidebar-right/client` | `ctx.sidebarRight.mounted`、`active()`、`isExpanded()`、`toggleExpanded()`、`openTab/openResource/close/focus/split/float/dock`；`openTabs`（声明类型为实现类时可见） | 无任何宽度写入口；`ISidebarRight` 无 `openTabs/tabsIn/registerCloseHandler`；`TabRecord` 定义位于未安装的 `dsh-client-ui-dockkit` |
| `@deepseek-ai/dsh-client-ui-layout/client` | `ctx.layout.panelInfo`（只读）、`selectPanel`、`beginNavigation`、`toggleSidebar`、`openRightbar/closeRightbar`；`columns.d.ts` 的 `computeColumns/clampWidth` 与 `RIGHTBAR_*` 常量 | `setRightbar`/`setSidebar`/`layoutInfo`/`rightbar` 均**不在 `ctx.layout`**；`setRightbar` 只在内部 store action 与 `LayoutController.panels`(`private`) 上 |
| `@deepseek-ai/dsh-client-locale/client` | `ctx.locale.register(ns, dicts)` / `register(ns, locale, dict)`、`bind(ns)`、`getSnapshot/subscribe`、`addLanguage` | 类型化 `register` 只接受 `BuiltInLocaleId`（`"zh" \| "en"`）；`LocaleDictOf` 类型住在 ui-slots |
