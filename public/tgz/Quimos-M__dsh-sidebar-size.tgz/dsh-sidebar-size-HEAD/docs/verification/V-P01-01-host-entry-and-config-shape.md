# V-P01-01 · host 入口加载与 Config 解析形状

本记录按《执行规划》4.2 的字段填写。它是**构建侧与本地实验证据**，不能证明插件能在目标桌面
加载或运行。

| 字段 | 内容 |
|---|---|
| 记录编号 | V-P01-01 |
| 问题/测试号 | P01 出口的构建侧证据；U6（构建与共享依赖）的一部分；U4（配置更新与形状）的前置事实 |
| 代码版本 | 被测提交 `4565a79`（P01 的 contracts 提交）。测试时工作区无未提交差异 |
| 构建产物 | `pnpm build`（tsdown 0.22.14，rolldown 1.2.12）。`lib/index.js` 974 B，`lib/client.js` 2537 B，`lib/client/lifecycle.js` 1259 B。SHA-256：index `DBB70FF3…6D3E19`、client `244326F6…9A8D61`、lifecycle `3798F51E…7FD94` |
| 环境 | 本机 Windows；DSH 桌面端 0.2.0-rc.2（**未挂载本插件、未运行**）；Node 24.21.0（DSH 自带运行时）、pnpm 11.7.0、TypeScript 5.9.3 |
| 起始条件 | 无持久数据；不涉及宿主配置；探针只 import 本仓库自己的 `lib/index.js` |
| 操作与预期 | 运行 `experiments/p01-host-entry-shape.mjs`；预期：产物可被 Node 加载，导出 `name`/`apply`/`Config`，`Config({})` 给出两个字段的解析结果 |
| 实际观察 | `name = sidebar-size`；`apply` 是函数；导出键为 `Config`/`apply`/`name`；`Config` 是 schema 函数；`Config({})` 的两个字段都是**对象**（带 `get` 与 `Symbol(cosmokit.volatile.write)` 的 cosmokit Volatile 引用），`JSON.stringify` 得到 `{}`；`Config.dict.enabled.meta = {"default":true,"volatile":true}` |
| 结论 | 构建侧通过：host 半产物可加载、导出形状正确、`@deepseek-ai/schemastery` 保持 external 并由依赖树解析。同时得到一个影响 M8 的事实（见下）。**运行期加载**（DSH 实际加载本插件、设置页出现两个开关）仍未测，留 P02 |
| 后续动作 | P02 用真实桌面确认：① 插件能被 Loader 加载且设置页出现两个开关；② `configForms` 快照里的 `value` 是否已把 volatile 引用解包为平面布尔值（U4）。M8 适配据此编写，并且无论线路形状如何都必须校验布尔类型、在首次确认值到达前不动作 |

## 一并得到的工程事实

1. **volatile 字段在 host 侧是包装对象，不是布尔值。** `Config({})` 返回 `{ enabled: Volatile, perContent: Volatile }`。因此 host 半不得把 `config.enabled` 当布尔值使用（本插件 host 半不读取这两个字段）。Loader 的 `loader/volatile-update` 路径依赖这些引用，所以 schema 必须由 DSH 的 `@deepseek-ai/schemastery` 构造，不能换成公共 `schemastery`。
2. **客户端 bundle 不含任何 React 副本。** `lib/client.js` 中不存在 `react` 字样：本阶段客户端半没有任何运行期值导入，只输出 `window.__ModuleLoader__.load({ id: "dsh-sidebar-size", factory })` 闭包工厂。
3. **释放规则已被测试固定。** `pnpm test` 6 项全部通过；其中一项测试在首次运行时发现了真实缺陷（告警回调自身抛错会从 `dispose()` 逸出），修复后 `dispose()` 对外承诺不抛错。
