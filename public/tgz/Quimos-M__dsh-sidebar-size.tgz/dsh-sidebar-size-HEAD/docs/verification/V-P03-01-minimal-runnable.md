# V-P03-01 · 工程最小可运行版本（P03 出口验收）

| 字段 | 内容 |
|---|---|
| 记录编号 | V-P03-01 |
| 问题/测试号 | P03 出口：A/B 中固定动作可操作、资源释放、首次设置未确认时不改宽度、总开关关闭的一次默认清理与恢复等级；T10 的数值层部分；S9 的开关存储边界复核 |
| 代码版本 | 提交 `13b1769` 的工作树，产物 `lib/client.js` |
| 构建产物 | `pnpm build`（tsdown 0.22.14，客户端产物 92.0 kB）；`pnpm test` 56 项全通过；`pnpm typecheck` 无错误 |
| 环境 | 环境 A（裸桌面 + 本插件，端口 19487）与环境 B（+ dsh-better-sidebar@0.24.1，端口 19488），均带 CDP 与 `-NoOcclusionThrottle` |
| 起始条件 | 两个实例的 home 里都没有宽度数据（`dsh-sidebar-size.widths.v1` 不存在）；偏好确认值 enabled=true、perContent=true |
| 操作与预期 | ① 打开诊断分组看阶段；② 打开右栏后点“应用当前内容”；③ 点“关闭总开关”；④ 点“打开总开关” |
| 实际观察（环境 A） | ① `阶段 active`、`当前内容 文件 / kind:files`；② `无记录 → 数值默认 → applied（恢复等级 numeric）`；③ `阶段 dormant`、`已确认 enabled=false`、`总开关关闭 → 数值默认清理 → applied（恢复等级 numeric）`；④ `阶段 active`、`enabled=true` |
| 实际观察（环境 B） | 同上，只是当前内容为 better-sidebar 的 `引导页 / kind:guide`（分类在 B 下同样成立） |
| 结论 | **通过**：P03 的四项出口（固定动作可操作、总开关关闭的一次清理、恢复等级如实标注、A/B 都可用）都有证据；“首次确认前不改宽度”由控制器测试覆盖（偏好为 loading 时应用动作返回 `deferred` 且不触碰宿主） |
| 后续动作 | 进入 P04（用户拖拽来源与内存记忆）；自动保存与按内容恢复不在 P03 范围内，已确认未实现 |

## 开关存储边界的复核（对应源码核验 S9）

关闭总开关后，验证实例 profile 的 `cordis.patch.yml` 里**只新增了本插件自己的条目**：

```yaml
- id: sidebar-size
  name: dsh-sidebar-size
  config:
    enabled: false
    perContent: true
```

其他条目（`agent-default-model`、`ui-settings-account`、`ui-chat`、`ui-settings`）未被改动。
把开关改回 schema 默认值（`enabled: true`）后，该覆盖**被移除**（条目从 patch 中消失），
环境恢复到“未覆盖”状态。这印证了两点：宽度数据与设置数据各自独立；插件只更新自己的条目。

## 本轮发现并修复的缺陷

**构造函数传入的宿主没有登记结构观察器**：`createController({ host })` 只保存了引用，没有订阅
`observeStructure`，因此面板从折叠变为正常停靠后，阶段一直停在 `waiting`（虽然显式动作因为
自己会读视图而仍然可用）。已改为在 `start()` 里补绑（`bindHost`），并补一项测试
（“构造函数传入的宿主也会被绑定：结构信号能让阶段从 waiting 推进到 active”）。
修复后在两个环境里阶段都能正确推进到 `active`。

## 阶段边界（本记录不代表已完成首版）

- 自动保存用户拖拽：**未实现**（P04）。
- 保存队列与持久化：**未实现**（P05；M5 已就绪但控制器尚未写入）。
- 按内容的自动恢复、两套记忆的切换：**未实现**（P06）。
- 四项设置界面、重置、导入导出：**未实现**（P07）。
- 总开关关闭的默认恢复只是 numeric，完整语义不可达（见 `D-001`）。
