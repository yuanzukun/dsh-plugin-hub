/**
 * 环境能力速查：对某个隔离实例跑一遍“加载 + 读取 + 写入 + 拖拽采样”的最小组合，
 * 用于在环境 A（裸桌面）与环境 B（加 dsh-better-sidebar）之间做同样的取证。
 *
 * 用法：node experiments/env-check.mjs <debugPort> <环境标签>
 *
 * 前置：该实例带调试端口与 -NoOcclusionThrottle 启动；脚本自己会设置 probe.autorun
 * 并重载一次页面（只重载一次，避免模块系统的 duplicate factory registration）。
 *
 * @module dsh-sidebar-size/experiments/env-check
 */
const port = process.argv[2] ?? '9223'
const label = process.argv[3] ?? 'env'

const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json()
const page = targets.find(target => target.type === 'page' && String(target.url).startsWith('dsh-app://'))
if (page?.webSocketDebuggerUrl === undefined) throw new Error('找不到 dsh-app 页面目标')

const socket = new WebSocket(page.webSocketDebuggerUrl)
await new Promise((resolve, reject) => {
  socket.addEventListener('open', () => resolve())
  socket.addEventListener('error', () => reject(new Error('调试连接失败')))
})

let nextId = 1
function send(method, params = {}) {
  const id = nextId++
  return new Promise((resolve, reject) => {
    const onMessage = (event) => {
      const message = JSON.parse(event.data)
      if (message.id !== id) return
      socket.removeEventListener('message', onMessage)
      if (message.error !== undefined) reject(new Error(`${method}: ${JSON.stringify(message.error)}`))
      else resolve(message.result)
    }
    socket.addEventListener('message', onMessage)
    socket.send(JSON.stringify({ id, method, params }))
  })
}

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms))

async function evaluate(expression) {
  const result = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true })
  if (result.exceptionDetails !== undefined) throw new Error(`表达式抛错：${JSON.stringify(result.exceptionDetails)}`)
  return result.result?.value
}

async function clickText(text) {
  const outcome = await evaluate(`(() => {
    const wanted = ${JSON.stringify(text)};
    const all = Array.from(document.querySelectorAll('*'));
    const exact = all.filter(el => (el.textContent || '').trim() === wanted);
    const target = (exact.length > 0 ? exact[exact.length - 1] : all.find(el => (el.textContent || '').trim().includes(wanted)));
    if (!target) return 'not-found';
    (target.closest('button, [role="button"], [role="menuitem"], [role="tab"], li') ?? target).click();
    return 'clicked';
  })()`)
  await sleep(500)
  return outcome
}

async function openSettingsSection() {
  const opened = await evaluate(`(() => {
    const hit = Array.from(document.querySelectorAll('[role="menuitem"], li, button'))
      .find(el => (el.textContent || '').trim().startsWith('设置'));
    if (hit) { hit.click(); return 'menu-item'; }
    const account = Array.from(document.querySelectorAll('button')).find(el => el.getAttribute('aria-label') === '账号菜单');
    if (!account) return 'no-account-button';
    account.click();
    return 'menu-opened';
  })()`)
  await sleep(800)
  if (opened === 'menu-opened') await clickText('设置')
  const section = await clickText('侧边栏尺寸')
  return `${String(opened)} / ${String(section)}`
}

/** 把诊断面板的可见文本按行读出来（界面是分行的“标签 值”布局）。 */
async function readPanelRows() {
  return evaluate(`(() => {
    const text = document.body.innerText || '';
    const start = text.indexOf('运行诊断');
    if (start < 0) return ['（找不到诊断面板）'];
    const slice = text.slice(start).split('\\n').map(line => line.trim()).filter(Boolean);
    return slice.slice(0, 34);
  })()`)
}

async function dragHandle(dx) {
  const box = await evaluate(`(() => {
    const el = document.querySelector('[data-side="rightbar"]');
    if (!el) return null;
    const r = el.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  })()`)
  if (box === null) return 'no-handle'
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: box.x, y: box.y, button: 'left', buttons: 1, clickCount: 1 })
  for (let step = 1; step <= 10; step++) {
    await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: box.x + (dx * step) / 10, y: box.y, button: 'left', buttons: 1 })
    await sleep(16)
  }
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: box.x + dx, y: box.y, button: 'left', buttons: 0, clickCount: 1 })
  await sleep(400)
  return 'dragged'
}

try {
  console.log(`# 环境 ${label}（调试端口 ${port}）`)

  const visibility = await evaluate('document.visibilityState')
  console.log(`页面可见性: ${String(visibility)}`)

  await evaluate("localStorage.setItem('dsh-sidebar-size.probe.autorun','1'); localStorage.removeItem('dsh-sidebar-size.probe.log'); location.reload(); 'ok'")
  await sleep(25000)

  console.log('\n## 1) 加载与拖拽采样')
  console.log(`拖拽: ${await dragHandle(-110)}`)
  const log = await evaluate("localStorage.getItem('dsh-sidebar-size.probe.log')")
  const lines = JSON.parse(log ?? '[]')
  console.log(`采样行数=${lines.length}`)
  for (const line of lines.slice(0, 6)) console.log(`  ${line}`)

  console.log('\n## 2) 设置分组读数')
  console.log(`打开设置: ${await openSettingsSection()}`)
  for (const row of await readPanelRows()) console.log(`  ${row}`)

  console.log('\n## 3) 显式写入（U1 在本次环境的复验）')
  console.log(`输入并点击应用: ${await clickText('应用这个宽度')}`)
  await sleep(1200)
  const after = await readPanelRows()
  for (const row of after.filter(row => row.includes(' → ') || row.includes('最近一次动作') || row.includes('结果说明'))) console.log(`  ${row}`)
} finally {
  socket.close()
}
