/**
 * P09 第 1 步：文件与模块契约一致性检查（只读，不修改任何文件）。
 *
 * 检查项：
 *   1. 客户端源码只从「平台模块表 + 相对同目录模块 + 类型专用导入」取依赖；
 *   2. 平台模块表覆盖了客户端源码里出现的全部 @deepseek-ai/* 说明符；
 *   3. 宿主半（src/index.ts）不引入任何客户端专用模块，反之亦然；
 *   4. package.json 的入口/导出与构建产物一致（构建后检查文件存在）；
 *   5. 构建产物里没有把 React 打进包（T34 的静态证据）；
 *   6. 仓库里没有误入的实验/临时文件（_verify 在仓库外）。
 *
 * 用法：node experiments/consistency-check.mjs
 *
 * @module dsh-sidebar-size/experiments/consistency-check
 */

import { readFileSync, existsSync, readdirSync } from 'node:fs'

const results = []
/** 记一条检查结果。 */
function check(name, ok, detail) {
  results.push({ name, ok, detail })
}

const platform = readFileSync('build/web-platform.ts', 'utf8')
const platformModules = [...platform.matchAll(/'(@deepseek-ai\/[^']+)'/g)].map(match => match[1])
check('平台模块表可解析', platformModules.length > 0, `共 ${platformModules.length} 项：${platformModules.join(', ')}`)

const clientFiles = readdirSync('src/client').filter(name => /\.tsx?$/.test(name))
const hostFiles = readdirSync('src').filter(name => /\.tsx?$/.test(name))

/** 取一个文件里的全部导入说明符。 */
function importsOf(path) {
  const text = readFileSync(path, 'utf8')
  const specs = []
  for (const match of text.matchAll(/^\s*import\s+(?:type\s+)?(?:[^'"]*?\s+from\s+)?['"]([^'"]+)['"]/gm)) {
    specs.push({ spec: match[1], typeOnly: /^\s*import\s+type\s/.test(match[0]) })
  }
  return specs
}

const packageJson = JSON.parse(readFileSync('package.json', 'utf8'))
const declared = new Set([
  ...Object.keys(packageJson.dependencies ?? {}),
  ...Object.keys(packageJson.peerDependencies ?? {}),
  ...Object.keys(packageJson.devDependencies ?? {}),
])

const unexpected = []
const undeclared = []
const typeOnlyForeign = []
/** 把 `@scope/name/sub` 归一成包名 `@scope/name`。 */
function packageNameOf(spec) {
  const parts = spec.split('/')
  return spec.startsWith('@') ? parts.slice(0, 2).join('/') : parts[0]
}
for (const file of clientFiles.map(name => `src/client/${name}`)) {
  for (const { spec, typeOnly } of importsOf(file)) {
    if (spec.startsWith('.')) continue
    if (spec === 'react' || spec === 'react-dom' || spec.startsWith('react/')) continue
    if (platformModules.includes(spec)) continue
    if (typeOnly) {
      typeOnlyForeign.push(`${file} → ${spec}`)
      continue
    }
    unexpected.push(`${file} → ${spec}`)
  }
  for (const { spec, typeOnly } of importsOf(file)) {
    if (spec.startsWith('.') || spec.startsWith('node:')) continue
    if (!declared.has(packageNameOf(spec))) undeclared.push(`${file} → ${spec}${typeOnly ? '（仅类型）' : ''}`)
  }
}
check('客户端源码没有跨插件值导入', unexpected.length === 0, unexpected.join('；') || '无')
check('类型专用外部导入已登记（仅信息，非失败）', true, typeOnlyForeign.join('；') || '无')
check('客户端源码的依赖都在 package.json 里声明', undeclared.length === 0, undeclared.join('；') || '无')

// 宿主半不引用客户端半
const hostImports = hostFiles.flatMap(name => importsOf(`src/${name}`).map(item => ({ file: `src/${name}`, ...item })))
const hostLeaks = hostImports.filter(item => item.spec.includes('/client/') || item.spec.includes('ui-'))
check('宿主半不引入客户端专用模块', hostLeaks.length === 0, hostLeaks.map(item => `${item.file} → ${item.spec}`).join('；') || '无')

// 客户端半不引入宿主半（node 专用）
const clientNodeLeaks = clientFiles
  .map(name => `src/client/${name}`)
  .flatMap(file => importsOf(file).filter(item => item.spec === 'node:fs' || item.spec === 'node:path').map(item => `${file} → ${item.spec}`))
check('客户端半不引入 Node 专用模块', clientNodeLeaks.length === 0, clientNodeLeaks.join('；') || '无')

// 入口与导出
const mainExists = existsSync(packageJson.main ?? '')
const clientExport = packageJson.exports?.['./client']
const clientPath = typeof clientExport === 'string' ? clientExport : clientExport?.import ?? clientExport?.require
check('宿主入口存在（构建后检查）', mainExists, packageJson.main ?? '（未声明）')
check('客户端导出声明存在', typeof clientPath === 'string', String(clientPath))
check('客户端产物存在（构建后检查）', typeof clientPath === 'string' && existsSync(clientPath), String(clientPath))

// React 没有被内联
if (existsSync('lib/client.js')) {
  const bundle = readFileSync('lib/client.js', 'utf8')
  const reactMarkers = ['react.development', '__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED', 'ReactCurrentDispatcher', 'react-dom/client']
  const inlined = reactMarkers.filter(marker => bundle.includes(marker))
  check('客户端产物没有内联 React（T34）', inlined.length === 0, inlined.join('；') || `包大小 ${(Buffer.byteLength(bundle, 'utf8') / 1024).toFixed(1)} KB`)
  const platformRefs = platformModules.filter(spec => bundle.includes(`"${spec}"`) || bundle.includes(`'${spec}'`))
  check('产物按平台模块表引用宿主提供模块', platformRefs.length > 0, platformRefs.join('；') || '（未在产物文本中直接出现说明符，需人工确认）')
} else {
  check('客户端产物存在以检查 React 内联', false, 'lib/client.js 不存在，请先 pnpm build')
}

// 仓库里不应出现临时/实验产物
const rootFiles = readdirSync('.').filter(name => /^(tmp|debug|scratch)/i.test(name))
check('仓库根目录没有临时文件', rootFiles.length === 0, rootFiles.join('；') || '无')

for (const item of results) {
  console.log(`${item.ok ? 'PASS' : 'FAIL'}  ${item.name}${item.detail === '' ? '' : ` — ${item.detail}`}`)
}
const failed = results.filter(item => !item.ok)
console.log(`\n共 ${results.length} 项，通过 ${results.length - failed.length} 项，失败 ${failed.length} 项`)
process.exit(failed.length === 0 ? 0 : 1)
