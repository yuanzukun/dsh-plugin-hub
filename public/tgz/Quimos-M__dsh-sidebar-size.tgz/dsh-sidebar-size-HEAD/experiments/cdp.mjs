/**
 * 通过 Chrome DevTools Protocol 观察（必要时驱动）独立验证实例的渲染进程。
 *
 * 用途：宿主能力实验里，DOM 结构、服务读数与浏览器存储都可以直接取到，不必让操作者
 * 手工复述界面文本；需要时也可以用 Input.* 触发真实输入事件。
 *
 * 前置：实例必须带 --remote-debugging-port=<port> 启动（见 experiments/verify-instance.ps1）。
 * 只连接 127.0.0.1，且只用于仓库之外的隔离实例，不接触正在使用的实例。
 *
 * 用法：
 *   node experiments/cdp.mjs <port> --targets
 *   node experiments/cdp.mjs <port> "document.querySelectorAll('[data-rightbar-col]').length"
 *   node experiments/cdp.mjs <port> --file <path-to-js>        # 从文件读取表达式（较长时用）
 *   node experiments/cdp.mjs <port> --drag "<selector>" <dx>   # 在元素中心发起一次真实鼠标拖拽
 *   node experiments/cdp.mjs <port> --viewport <width> <height> # 改变渲染视口（等价于改窗口大小）
 *   node experiments/cdp.mjs <port> --click "<按钮文本>"        # 点击文本匹配的按钮（含设置面板）
 *   node experiments/cdp.mjs <port> --close                    # 优雅退出实例（触发收尾冲刷与存储提交）
 *
 * @module dsh-sidebar-size/experiments/cdp
 */
import { readFileSync } from 'node:fs'

const [portArg, ...rest] = process.argv.slice(2)
if (portArg === undefined) {
  console.error('用法: node experiments/cdp.mjs <port> --targets | <expression> | --file <path>')
  process.exit(2)
}

/** 拉取调试目标列表。 */
async function targets(port) {
  const response = await fetch(`http://127.0.0.1:${port}/json/list`)
  if (!response.ok) throw new Error(`目标列表请求失败：HTTP ${response.status}`)
  return response.json()
}

const list = await targets(portArg)
if (rest[0] === '--close') {
  // 优雅退出：走浏览器级端点关闭，让 Electron 正常收尾（插件 flush + Chromium 提交存储）。
  const version = await (await fetch(`http://127.0.0.1:${portArg}/json/version`)).json()
  const browser = new WebSocket(version.webSocketDebuggerUrl)
  await new Promise((resolve, reject) => {
    browser.addEventListener('open', () => resolve())
    browser.addEventListener('error', () => reject(new Error('浏览器级连接失败')))
  })
  browser.send(JSON.stringify({ id: 1, method: 'Browser.close', params: {} }))
  await new Promise(resolve => setTimeout(resolve, 1500))
  console.log('已请求优雅退出')
  process.exit(0)
}
if (rest[0] === '--targets' || rest.length === 0) {  for (const target of list) {
    console.log(`${target.type}\t${target.url}\t${target.webSocketDebuggerUrl ?? ''}`)
  }
  process.exit(0)
}

const expression = rest[0] === '--file'
  ? readFileSync(rest[1], 'utf8')
  : rest.join(' ')

const page = list.find(target => target.type === 'page' && String(target.url).startsWith('dsh-app://'))
  ?? list.find(target => target.type === 'page')
if (page?.webSocketDebuggerUrl === undefined) {
  console.error('没有可用的页面目标；实例是否带 --remote-debugging-port 启动？')
  process.exit(1)
}

const socket = new WebSocket(page.webSocketDebuggerUrl)
await new Promise((resolve, reject) => {
  socket.addEventListener('open', () => resolve())
  socket.addEventListener('error', () => reject(new Error('调试连接失败')))
})

let nextId = 1
/** 发送一条 CDP 命令并等待结果。 */
function send(method, params = {}) {
  const id = nextId++
  return new Promise((resolve, reject) => {
    const onMessage = (event) => {
      const message = JSON.parse(event.data)
      if (message.id !== id) return
      socket.removeEventListener('message', onMessage)
      if (message.error !== undefined) reject(new Error(JSON.stringify(message.error)))
      else resolve(message.result)
    }
    socket.addEventListener('message', onMessage)
    socket.send(JSON.stringify({ id, method, params }))
  })
}

try {
  if (rest[0] === '--shortcut') {
    // 目的：驱动宿主自己的快捷键（例如 Ctrl+` 新建终端），比合成点击菜单项更可靠。
    const spec = rest[1] ?? 'ctrl+`'
    const parts = spec.split('+').map(part => part.trim().toLowerCase())
    const modifiers = (parts.includes('ctrl') ? 2 : 0)
      | (parts.includes('alt') ? 1 : 0)
      | (parts.includes('shift') ? 8 : 0)
      | (parts.includes('meta') ? 4 : 0)
    const name = parts[parts.length - 1]
    const table = {
      '`': { key: '`', code: 'Backquote', vk: 192 },
      p: { key: 'p', code: 'KeyP', vk: 80 },
      t: { key: 't', code: 'KeyT', vk: 84 },
      n: { key: 'n', code: 'KeyN', vk: 78 },
    }
    const info = table[name] ?? { key: name, code: `Key${name.toUpperCase()}`, vk: name.toUpperCase().charCodeAt(0) }
    const base = { modifiers, key: info.key, code: info.code, windowsVirtualKeyCode: info.vk, nativeVirtualKeyCode: info.vk }
    await send('Input.dispatchKeyEvent', { type: 'rawKeyDown', ...base })
    await send('Input.dispatchKeyEvent', { type: 'keyUp', ...base })
    await new Promise(resolve => setTimeout(resolve, 1500))
    console.log(`shortcut:${spec}`)
    process.exit(0)
  }
  if (rest[0] === '--drag') {
    const selector = rest[1]
    const dx = Number(rest[2] ?? -120)
    const box = await send('Runtime.evaluate', {
      expression: `(() => { const el = document.querySelector(${JSON.stringify(selector)}); if (!el) return null; const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; })()`,
      returnByValue: true,
    })
    const start = box.result?.value
    if (start === null || start === undefined) throw new Error(`找不到元素：${selector}`)
    const y = start.y
    await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: start.x, y, button: 'left', buttons: 1, clickCount: 1 })
    const steps = 12
    for (let step = 1; step <= steps; step++) {
      await send('Input.dispatchMouseEvent', {
        type: 'mouseMoved',
        x: start.x + (dx * step) / steps,
        y,
        button: 'left',
        buttons: 1,
      })
      await new Promise(resolve => setTimeout(resolve, 16))
    }
    await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: start.x + dx, y, button: 'left', buttons: 0, clickCount: 1 })
    await new Promise(resolve => setTimeout(resolve, 300))
    const after = await send('Runtime.evaluate', {
      expression: `(() => { const el = document.querySelector('[data-rightbar-col]'); return el ? Math.round(el.getBoundingClientRect().width) : null; })()`,
      returnByValue: true,
    })
    console.log(`拖拽完成 dx=${dx}；拖后右栏列宽 = ${String(after.result?.value)}`)
  } else if (rest[0] === '--click') {
    const wanted = rest[1]
    const result = await send('Runtime.evaluate', {
      expression: `(() => {
        const wanted = ${JSON.stringify(wanted)};
        const nodes = Array.from(document.querySelectorAll('button, [role="button"], [role="menuitem"], [role="tab"]'));
        const text = el => (el.textContent || '').trim();
        const label = el => (el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
        const hit = nodes.find(el => text(el) === wanted)
          ?? nodes.find(el => label(el) === wanted)
          ?? nodes.find(el => text(el).includes(wanted) || label(el).includes(wanted));
        if (!hit) return 'not-found';
        hit.click();
        return 'clicked:' + (text(hit) || label(hit) || '(icon)');
      })()`,
      returnByValue: true,
      userGesture: true,
    })
    console.log(String(result.result?.value))
  } else if (rest[0] === '--viewport') {
    await send('Emulation.setDeviceMetricsOverride', {
      width: Number(rest[1]),
      height: Number(rest[2] ?? 800),
      deviceScaleFactor: 1,
      mobile: false,
    })
    await new Promise(resolve => setTimeout(resolve, 300))
    console.log(`视口已改为 ${rest[1]}x${rest[2] ?? 800}`)
  } else {
    const result = await send('Runtime.evaluate', {
      expression,
      awaitPromise: true,
      returnByValue: true,
      userGesture: true,
    })
    if (result.exceptionDetails !== undefined) {
      console.error('表达式抛错：', JSON.stringify(result.exceptionDetails, null, 2))
      process.exit(1)
    }
    const value = result.result?.value
    console.log(typeof value === 'string' ? value : JSON.stringify(value, null, 2))
  }
} finally {
  socket.close()
}
