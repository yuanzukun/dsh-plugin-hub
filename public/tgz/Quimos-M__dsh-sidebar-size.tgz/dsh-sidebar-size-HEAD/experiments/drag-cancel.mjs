/**
 * 实验：拖拽过程中把手柄元素“移除”（模拟宿主重建面板），观察插件是否发出取消、是否遗留拖拽状态。
 *
 * 用途：E16 / P08 第 5 条的真实宿主取证。流程：
 *   1. 在手柄上按下并移动（真实指针事件，触发 M1 的手势开始）；
 *   2. 按住不放的同时移除手柄的 `data-side` 属性（等价于宿主换掉了手柄节点）；
 *   3. 触发一次 style 变化让 MutationObserver 跑 reconcile（解绑 → 取消）；
 *   4. 读控制器日志与阶段，再把属性放回去，验证自动恢复是否继续工作。
 *
 * 用法：node experiments/drag-cancel.mjs <调试端口>
 *
 * @module dsh-sidebar-size/experiments/drag-cancel
 */

const port = process.argv[2] ?? '9223'
const list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json()
const page = list.find(target => target.type === 'page' && String(target.url).startsWith('dsh-app://'))
  ?? list.find(target => target.type === 'page')
if (page?.webSocketDebuggerUrl === undefined) {
  console.error('没有可用的页面目标。')
  process.exit(1)
}

const socket = new WebSocket(page.webSocketDebuggerUrl)
await new Promise((resolve, reject) => {
  socket.addEventListener('open', () => resolve())
  socket.addEventListener('error', () => reject(new Error('调试连接失败')))
})

let nextId = 1
/** 发送一条 CDP 命令并等待结果。 */
function send(method, params = {}) {
  const id = nextId++
  return new Promise((resolve, reject) => {
    const onMessage = (event) => {
      const message = JSON.parse(event.data)
      if (message.id !== id) return
      socket.removeEventListener('message', onMessage)
      if (message.error !== undefined) reject(new Error(JSON.stringify(message.error)))
      else resolve(message.result)
    }
    socket.addEventListener('message', onMessage)
    socket.send(JSON.stringify({ id, method, params }))
  })
}

/** 在页面里求值并取回 JSON 值。 */
async function evaluate(expression) {
  const result = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  return result.result?.value
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))

// 清空日志，便于只看这次实验。
await evaluate("localStorage.setItem('dsh-sidebar-size.controller.log','[]'); 'cleared'")

const start = await evaluate(`(() => {
  const el = document.querySelector('[data-side="rightbar"]');
  if (!el) return null;
  const r = el.getBoundingClientRect();
  return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
})()`)
if (start === null) {
  console.log(JSON.stringify({ error: '找不到手柄' }))
  process.exit(1)
}

// 1) 按下并移动：真实手势开始
await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: start.x, y: start.y, button: 'left', buttons: 1, clickCount: 1 })
for (let step = 1; step <= 6; step += 1) {
  await send('Input.dispatchMouseEvent', {
    type: 'mouseMoved',
    x: start.x - step * 8,
    y: start.y,
    button: 'left',
    buttons: 1,
  })
  await sleep(16)
}
const duringDrag = await evaluate("JSON.parse(localStorage.getItem('dsh-sidebar-size.controller.log')||'[]').slice(-3)")

// 2) 按住不放，移除手柄属性；用 style 变化驱动 reconcile
const removed = await evaluate(`(() => {
  const el = document.querySelector('[data-side="rightbar"]');
  if (!el) return 'no-handle';
  el.id = 'probe-handle';
  el.removeAttribute('data-side');
  document.body.style.setProperty('--probe-tick', String(Date.now()));
  return 'removed';
})()`)
await sleep(300)
await evaluate("document.body.style.setProperty('--probe-tick', String(Date.now() + 1)); 'tick'")
await sleep(400)

const afterRemoval = await evaluate("JSON.parse(localStorage.getItem('dsh-sidebar-size.controller.log')||'[]').slice(-5)")

// 3) 放回属性，验证自动恢复继续工作
await evaluate(`(() => {
  const el = document.getElementById('probe-handle');
  if (el) { el.setAttribute('data-side', 'rightbar'); el.removeAttribute('id'); }
  document.body.style.setProperty('--probe-tick', String(Date.now() + 2));
  return 'restored';
})()`)
await sleep(400)

// 4) 归还指针（避免留下按下的鼠标状态）
await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: start.x - 48, y: start.y, button: 'left', buttons: 0, clickCount: 1 })
await sleep(300)

const final = await evaluate(`(() => {
  const rows = (document.body.innerText || '').split('\\n').map(line => line.trim()).filter(Boolean);
  return JSON.stringify({
    手柄数量: document.querySelectorAll('[data-side="rightbar"]').length,
    列宽: Math.round(document.querySelector('[data-rightbar-col]')?.getBoundingClientRect().width ?? -1),
    widthsKey: localStorage.getItem('dsh-sidebar-size.widths.v1'),
  });
})()`)

console.log(JSON.stringify({
  removed,
  手势中日志: duringDrag,
  移除后日志: afterRemoval,
  最终: JSON.parse(final),
  全部日志: await evaluate("JSON.parse(localStorage.getItem('dsh-sidebar-size.controller.log')||'[]')"),
}, null, 2))

socket.close()
