# 独立验证实例的准备脚本（P02 起的宿主能力实验用）。
#
# 为什么需要独立实例：桌面端把 Web 服务端口硬编码为 19387
# （@deepseek-ai/dsh-desktop-host/lib/index.js），且单实例锁绑定 Electron 的 userData；
# 要让验证实例与“正在使用的实例”并存且互不影响，必须同时改三样东西：
#   1. DSH_HOME            —— profiles / sessions / storages 独立
#   2. --user-data-dir     —— Electron(Chromium) 存储独立，因此 localStorage 独立
#   3. profile 用户层端口  —— 覆盖 webserver 条目，避开 19387
#
# 用法（本机路径固定，仅用于本工作区）：
#   pwsh -File experiments/verify-instance.ps1 -Name a -Port 19487
#   pwsh -File experiments/verify-instance.ps1 -Name b -Port 19488 -ExtraPackages dsh-better-sidebar@0.24.1
#   pwsh -File experiments/verify-instance.ps1 -Name a -Port 19487 -Launch
#   pwsh -File experiments/verify-instance.ps1 -Name a -Port 19487 -DebugPort 9223 -Launch
#
# 说明：
#   * 实例目录在仓库之外（E:\DSH-plugin\_verify\<name>），不进入版本库；
#   * profile 只在不存在时创建，已存在时不改动其 package.json 与 patch；
#   * 启动时清掉 ELECTRON_RUN_AS_NODE：DSH 自身子进程环境里带着它，会让 Electron
#     按 Node 模式启动并报 “bad option”；
#   * -DebugPort 给隔离实例加本机 CDP 调试端口（127.0.0.1），供 experiments/cdp.mjs
#     直接观察渲染进程（DOM/存储读数），避免让操作者手工复述界面文本。它只用于这个
#     隔离实例，绝不在正在使用的实例上启用。
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][string]$Name,
  [Parameter(Mandatory = $true)][int]$Port,
  [string[]]$ExtraPackages = @(),
  [int]$DebugPort = 0,
  [switch]$NoOcclusionThrottle,
  [switch]$SkipPluginInstall,
  [switch]$Launch
)

$ErrorActionPreference = 'Stop'

$exe = 'E:\DSH-Desktop\DeepSeek Harness.exe'
$cli = 'E:\DSH-Desktop\resources\app.asar\dsh\node_modules\@deepseek-ai\dsh-desktop-host\lib\cli.js'
$pluginPath = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$root = Join-Path 'E:\DSH-plugin\_verify' $Name
$dshHome = Join-Path $root 'home'
$profileDir = Join-Path $dshHome 'profiles\desktop'
$electronData = Join-Path $root 'electron'

# 与桌面端 initProfile() 等价的初始内容：全新 DSH_HOME 的 desktop profile 就是裸本体
# （@deepseek-ai/dsh-base + @deepseek-ai/dsh-web-app）。
if (-not (Test-Path (Join-Path $profileDir 'package.json'))) {
  New-Item -ItemType Directory -Force -Path $profileDir | Out-Null
  @'
{
  "name": "dsh-profile-desktop",
  "private": true,
  "dependencies": {},
  "dsh": {
    "profile": {
      "bundles": [
        "@deepseek-ai/dsh-base",
        "@deepseek-ai/dsh-web-app"
      ]
    }
  }
}
'@ | Set-Content -Path (Join-Path $profileDir 'package.json') -Encoding utf8NoBOM
  "init profile: $profileDir" | Write-Host
}

# 端口覆盖：桌面端 host 固定传 --port 19387，第二个实例必然 EADDRINUSE。
$patchFilePath = Join-Path $profileDir 'cordis.patch.yml'
if (-not (Test-Path $patchFilePath)) {
  @"
# 独立验证实例 $Name 的 profile 用户层（仓库之外，非项目交付物）。
# 覆盖 webserver 端口以避开桌面端硬编码的 19387。
- id: webserver
  name: '@deepseek-ai/dsh-host-webserver'
  config:
    host: 127.0.0.1
    port: $Port
    compression: gzip
    compressionLevel: 1
    compressionThresholdBytes: 1024
"@ | Set-Content -Path $patchFilePath -Encoding utf8NoBOM
  "write patch: $patchFilePath (port $Port)" | Write-Host
}

# 安装本插件与可选的其他插件（改 profile 的 package.json 与 bundle 列表）。
# T30（卸载验收）需要“不带插件启动”，此时用 -SkipPluginInstall，不再往 profile 里加回本插件。
$env:ELECTRON_RUN_AS_NODE = '1'
$env:DSH_HOME = $dshHome
$packages = @("link:$($pluginPath -replace '\\', '/')") + $ExtraPackages
if (-not $SkipPluginInstall) {
  # 用 Start-Process -Wait 明确取得退出码：直接调用时 $LASTEXITCODE 在某些宿主环境下为空。
  $cliArgs = @('--expose-internals', $cli, 'plugin', '--profile', 'desktop', 'add') + $packages
  $proc = Start-Process -FilePath $exe -ArgumentList $cliArgs -NoNewWindow -Wait -PassThru
  if ($proc.ExitCode -ne 0) { throw "plugin add 失败：exit $($proc.ExitCode)" }
}

if ($Launch) {
  Remove-Item Env:\ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue
  $env:DSH_HOME = $dshHome
  $launchArgs = @("--user-data-dir=$electronData")
  if ($DebugPort -gt 0) { $launchArgs += "--remote-debugging-port=$DebugPort" }
  if ($NoOcclusionThrottle) {
    # 被遮挡的窗口在 Chromium 里算 hidden：渲染步骤不再运行，ResizeObserver 回调不投递，
    # 输入派发也会被拖慢（实测一次拖拽 60 秒）。这只影响节流，不改变任何插件/宿主的布局逻辑；
    # 实验需要“窗口不在前台时仍能观察渲染结果”时启用它。
    $launchArgs += '--disable-features=CalculateNativeWinOcclusion'
    $launchArgs += '--disable-backgrounding-occluded-windows'
  }
  Start-Process -FilePath $exe -ArgumentList $launchArgs -PassThru |
    Select-Object Id, ProcessName | Format-Table -AutoSize
  $debugNote = if ($DebugPort -gt 0) { "，CDP 调试端口 $DebugPort" } else { '' }
  "启动实例 $Name：端口 $Port，home $dshHome，electron $electronData$debugNote" | Write-Host
}

