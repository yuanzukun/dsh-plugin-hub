/**
 * P09 第 6 步：针对**冻结候选产物**的目标客户端验收（A/B 各跑一次）。
 *
 * 设计取舍：不依赖设置面板的 UI 操作。插件的控制器日志本身就记录了阶段转换、读取次数、
 * 保存结果与手势汇总，宽度键与列宽都能直接读，因此验收只需要三类动作：
 *   拖拽手柄、折叠/展开右栏、切换右栏全屏——都在右栏面板自己的控件上。
 * 每一步都有超时；页面一旦无响应就把已得结果打出来并退出，不会静默挂住。
 *
 * 用法：node experiments/acceptance.mjs <调试端口> <标签，例如 A>
 *
 * @module dsh-sidebar-size/experiments/acceptance
 */

const port = process.argv[2] ?? '9223'
const label = process.argv[3] ?? 'A'

const list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json()
const page = list.find(target => target.type === 'page' && String(target.url).startsWith('dsh-app://'))
  ?? list.find(target => target.type === 'page')
if (page?.webSocketDebuggerUrl === undefined) {
  console.error('没有可用的页面目标。')
  process.exit(1)
}

const socket = new WebSocket(page.webSocketDebuggerUrl)
await new Promise((resolve, reject) => {
  socket.addEventListener('open', () => resolve())
  socket.addEventListener('error', () => reject(new Error('调试连接失败')))
})

let nextId = 1
/** 发送一条 CDP 命令并等待结果（带超时，避免整脚本挂住）。 */
function send(method, params = {}, timeoutMs = 12000) {
  const id = nextId++
  return Promise.race([
    new Promise((resolve, reject) => {
      const onMessage = (event) => {
        const message = JSON.parse(event.data)
        if (message.id !== id) return
        socket.removeEventListener('message', onMessage)
        if (message.error !== undefined) reject(new Error(JSON.stringify(message.error)))
        else resolve(message.result)
      }
      socket.addEventListener('message', onMessage)
      socket.send(JSON.stringify({ id, method, params }))
    }),
    new Promise((_resolve, reject) => setTimeout(() => reject(new Error(`${method} 超时（${timeoutMs}ms）`)), timeoutMs)),
  ])
}

/** 求值并取回 JSON 值。 */
async function evaluate(expression) {
  const result = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  return result.result?.value
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))
const results = []
/** 记一条检查结果。 */
function record(name, ok, detail) {
  results.push({ name, ok, detail })
  console.error(`[${label}] ${ok ? 'PASS' : 'FAIL'} ${name} — ${detail}`)
}

const key = () => evaluate("localStorage.getItem('dsh-sidebar-size.widths.v1')")
const logs = async () => JSON.parse(await evaluate("localStorage.getItem('dsh-sidebar-size.controller.log')||'[]'"))
const width = () => evaluate("Math.round(document.querySelector('[data-rightbar-col]')?.getBoundingClientRect().width ?? -1)")

/** 按 aria-label 精确点击（右栏面板自带控件都用 aria-label）。 */
async function clickAria(labelText) {
  return evaluate(`(() => {
    const node = Array.from(document.querySelectorAll('button, [role="button"]'))
      .find(el => (el.getAttribute('aria-label') || '').trim() === ${JSON.stringify(labelText)});
    if (!node) return false;
    node.click();
    return true;
  })()`)
}

/** 拖动右栏手柄；方向自适应（贴到上限时改为收窄）。 */
async function drag() {
  const box = await evaluate(`(() => {
    const el = document.querySelector('[data-side="rightbar"]');
    if (!el) return null;
    const r = el.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  })()`)
  if (box === null) return { error: '找不到手柄' }
  const before = await width()
  const dx = before > 430 ? 60 : -60
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: box.x, y: box.y, button: 'left', buttons: 1, clickCount: 1 })
  for (let stepIndex = 1; stepIndex <= 12; stepIndex += 1) {
    await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: box.x + (dx * stepIndex) / 12, y: box.y, button: 'left', buttons: 1 })
    await sleep(16)
  }
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: box.x + dx, y: box.y, button: 'left', buttons: 0, clickCount: 1 })
  await sleep(1300)
  return { before, after: await width(), dx }
}

try {
  // 保证右栏展开
  await clickAria('打开右侧边栏')
  await sleep(2500)

  // 清空日志，之后的日志都属于本次验收
  await evaluate("localStorage.setItem('dsh-sidebar-size.controller.log','[]'); 'cleared'")
  // 触发一次结构变化，让控制器把当前状态再结算一次（不改变数据）
  await clickAria('收起右侧边栏')
  await sleep(1500)
  await clickAria('打开右侧边栏')
  await sleep(2500)

  const startLogs = await logs()
  record(
    'C1 页面只初始化一次（本次加载）',
    startLogs.filter(line => line.includes('阶段') && line.includes('active')).length >= 1,
    startLogs.slice(0, 4).join(' | '),
  )

  const keyBefore = await key()
  const dragResult = await drag()
  const keyAfter = await key()
  const dragLogs = await logs()
  record(
    'C2 拖拽产生记录并落盘',
    keyBefore !== keyAfter && dragLogs.some(line => line.includes('保存成功')),
    `列宽 ${String(dragResult.before)} → ${String(dragResult.after)}（dx=${String(dragResult.dx)}）；键 ${String(keyBefore)} → ${String(keyAfter)}`,
  )
  record(
    'C3 手势汇总日志存在',
    dragLogs.some(line => line.includes('手势结束：共接受')),
    dragLogs.filter(line => line.includes('手势')).slice(-2).join(' | '),
  )

  // 折叠重开：应恢复记忆值
  const expected = await width()
  await clickAria('收起右侧边栏')
  await sleep(2000)
  await clickAria('打开右侧边栏')
  await sleep(2500)
  const restored = await width()
  record('C4 折叠重开后按记忆恢复', restored === expected, `期望 ${String(expected)}，实际 ${String(restored)}`)

  // 折叠期间不应用、环境变化不写记录
  const keyDuringCollapse = await key()
  await clickAria('收起右侧边栏')
  await sleep(1500)
  const collapsedWidth = await width()
  await clickAria('打开右侧边栏')
  await sleep(2000)
  record(
    'C5 折叠期间不写记录',
    keyDuringCollapse === (await key()),
    `折叠时列宽 ${String(collapsedWidth)}；键未变=${String(keyDuringCollapse === (await key()))}`,
  )

  // 全屏：不保存尺寸，退出后恢复
  const beforeFullscreen = { key: await key(), width: await width() }
  const entered = await clickAria('全屏')
  await sleep(2200)
  const inFullscreen = { key: await key(), handle: await evaluate("document.querySelectorAll('[data-side=\\\"rightbar\\\"]').length") }
  const paused = (await logs()).some(line => line.includes('paused（fullscreen）'))
  await clickAria('退出全屏')
  await sleep(2500)
  const afterFullscreen = { key: await key(), width: await width() }
  record(
    'C6 全屏不保存尺寸，退出后恢复',
    entered && inFullscreen.key === beforeFullscreen.key && paused && afterFullscreen.width === beforeFullscreen.width,
    `进入前 ${JSON.stringify(beforeFullscreen)}；全屏中 ${JSON.stringify(inFullscreen)}；paused 日志=${String(paused)}；退出后 ${JSON.stringify(afterFullscreen)}`,
  )

  // 关机前的收尾：把总开关关掉再打开（这一步走设置面板，放在最后；失败不影响上面的结论）
  const finalLogs = await logs()
  record(
    'C7 存储健康（无错误日志）',
    !finalLogs.some(line => line.includes('保存失败') || line.includes('抛错')),
    finalLogs.filter(line => line.includes('保存')).slice(-2).join(' | ') || '（本次验收没有保存日志）',
  )
} catch (error) {
  record('运行时阻塞或异常', false, String(error))
}

const failed = results.filter(item => !item.ok)
console.log(JSON.stringify({
  环境: label,
  端口: port,
  检查: results,
  汇总: { 共: results.length, 通过: results.length - failed.length, 失败: failed.length },
  最终键: await key().catch(() => null),
  最终列宽: await width().catch(() => null),
  日志尾部: await logs().catch(() => null),
}, null, 2))
socket.close()
process.exit(failed.length === 0 ? 0 : 1)
