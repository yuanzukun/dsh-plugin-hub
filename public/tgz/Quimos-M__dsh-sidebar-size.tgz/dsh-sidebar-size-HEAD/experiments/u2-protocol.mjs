/**
 * U2 最小对照实验：数值恢复 vs 未挂载的默认语义。
 *
 * 对照原理：宿主把右栏宽度偏好存在内存里，未设置时为 null，此时每次打开右栏都会按
 * `max(300, round(框架宽 × 0.45))` 现算；一旦写入数字（用户拖动，或我们调用恢复默认），
 * 这个偏好就固定下来，不再跟随框架宽度。于是“数值恢复”与“未挂载”在
 * 「折叠 → 改窗口 → 重新打开」这条路径上会给出不同结果。
 *
 * 前置：隔离实例已带调试端口启动，且设置分组「侧边栏尺寸」可用。
 * 用法：node experiments/u2-protocol.mjs <debugPort>
 *
 * @module dsh-sidebar-size/experiments/u2-protocol
 */
import { spawnSync } from 'node:child_process'

const port = process.argv[2] ?? '9223'

const response = await fetch(`http://127.0.0.1:${port}/json/list`)
const targets = await response.json()
const page = targets.find(target => target.type === 'page' && String(target.url).startsWith('dsh-app://'))
if (page?.webSocketDebuggerUrl === undefined) throw new Error('找不到 dsh-app 页面目标')

const socket = new WebSocket(page.webSocketDebuggerUrl)
await new Promise((resolve, reject) => {
  socket.addEventListener('open', () => resolve())
  socket.addEventListener('error', () => reject(new Error('调试连接失败')))
})

// Browser.* 命令只接受浏览器级端点，页面端点会报 method not found。
const version = await (await fetch(`http://127.0.0.1:${port}/json/version`)).json()
const browserSocket = new WebSocket(version.webSocketDebuggerUrl)
await new Promise((resolve, reject) => {
  browserSocket.addEventListener('open', () => resolve())
  browserSocket.addEventListener('error', () => reject(new Error('浏览器级调试连接失败')))
})

let nextId = 1
function sendOn(ws, method, params = {}) {
  const id = nextId++
  return new Promise((resolve, reject) => {
    const onMessage = (event) => {
      const message = JSON.parse(event.data)
      if (message.id !== id) return
      ws.removeEventListener('message', onMessage)
      if (message.error !== undefined) reject(new Error(`${method}: ${JSON.stringify(message.error)}`))
      else resolve(message.result)
    }
    ws.addEventListener('message', onMessage)
    ws.send(JSON.stringify({ id, method, params }))
  })
}

const send = (method, params) => sendOn(socket, method, params)
const sendBrowser = (method, params) => sendOn(browserSocket, method, params)

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms))

async function evaluate(expression) {
  const result = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true })
  if (result.exceptionDetails !== undefined) throw new Error(`表达式抛错：${JSON.stringify(result.exceptionDetails)}`)
  return result.result?.value
}

async function clickText(text) {
  const outcome = await evaluate(`(() => {
    const wanted = ${JSON.stringify(text)};
    const all = Array.from(document.querySelectorAll('*'));
    const exact = all.filter(el => (el.textContent || '').trim() === wanted);
    const target = (exact.length > 0 ? exact[exact.length - 1] : all.find(el => (el.textContent || '').trim().includes(wanted)));
    if (!target) return 'not-found';
    const clickable = target.closest('button, [role="button"], [role="menuitem"], [role="tab"], li') ?? target;
    clickable.click();
    return 'clicked';
  })()`)
  await sleep(500)
  return outcome
}

/** 打开设置面板：入口在账号菜单里（菜单项文本以“设置”开头）。菜单可能已开着，先探测。 */
async function openSettings() {
  const already = await evaluate(`(() => {
    const hit = Array.from(document.querySelectorAll('[role="menuitem"], li, button'))
      .find(el => (el.textContent || '').trim().startsWith('设置'));
    if (!hit) return 'menu-closed';
    hit.click();
    return 'clicked-menu-item';
  })()`)
  if (already === 'clicked-menu-item') {
    await sleep(800)
    return already
  }
  const account = await evaluate(`(() => {
    const button = Array.from(document.querySelectorAll('button')).find(el => el.getAttribute('aria-label') === '账号菜单');
    if (!button) return 'no-account-button';
    button.click();
    return 'menu-opened';
  })()`)
  await sleep(800)
  const picked = await clickText('设置')
  return `${String(account)} / ${String(picked)}`
}

/** 用 Win32 改真实窗口大小；Electron 的 CDP 不实现 Browser.getWindowForTarget。 */
function resizeWindow(width, height) {
  const script = [
    "$p = Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'DeepSeek*' -and $_.CommandLine -match 'env-a' -and $_.CommandLine -notmatch 'subprocess-local' -and $_.CommandLine -notmatch '--type=' } | Select-Object -First 1",
    "Add-Type -Namespace W -Name U -MemberDefinition '[DllImport(\"user32.dll\")] public static extern bool MoveWindow(IntPtr h, int x, int y, int w, int ht, bool repaint);'",
    `[W.U]::MoveWindow((Get-Process -Id $p.ProcessId).MainWindowHandle, 30, 30, ${width}, ${height}, $true) | Out-Null`,
  ].join('; ')
  spawnSync('pwsh', ['-NoLogo', '-NoProfile', '-Command', script], { stdio: 'ignore' })
  return new Promise(resolve => setTimeout(resolve, 1500))
}

async function measure(label) {
  const value = await evaluate(`(() => {
    const col = document.querySelector('[data-rightbar-col]');
    const frame = col ? col.parentElement : null;
    const panel = document.querySelector('[data-sidebar-right-panel]');
    const round = (n) => Math.round(n);
    const frameWidth = frame ? round(frame.getBoundingClientRect().width) : null;
    return {
      label: ${JSON.stringify(label)},
      inner: window.innerWidth,
      frame: frameWidth,
      col: col ? round(col.getBoundingClientRect().width) : null,
      panel: panel ? round(panel.getBoundingClientRect().width) : null,
      open: panel ? panel.hasAttribute('data-sidebar-right-open') : false,
      mode: panel ? panel.getAttribute('data-sidebar-right-panel') : null,
      expectedUnset: frameWidth === null ? null : Math.max(300, Math.round(frameWidth * 0.45)),
    };
  })()`)
  console.log(JSON.stringify(value))
  return value
}

try {
  console.log('# 打开设置分组')
  console.log(`账号菜单 → 设置: ${await openSettings()}`)
  console.log(`分组导航: ${await clickText('侧边栏尺寸')}`)

  console.log('\n# 阶段 0：初始状态（本次启动从未设置过宽度偏好）')
  await measure('M0 初始')

  console.log('\n# 阶段 1：未设置基线的行为（折叠 → 打开）')
  await clickText('关闭右栏')
  console.log(`打开右栏: ${await clickText('打开右栏（正常）')}`)
  await sleep(600)
  const a1 = await measure('A1 未设置@frame(初始)')

  console.log('\n# 阶段 2：未设置基线下改窗口再打开（预期跟随框架宽）')
  await clickText('关闭右栏')
  await resizeWindow(900, 700)
  console.log(`打开右栏: ${await clickText('打开右栏（正常）')}`)
  await sleep(600)
  const a2 = await measure('A2 未设置@frame(变小)')

  console.log('\n# 阶段 3：调用恢复默认（数值），当前窗口同上')
  console.log(`恢复默认: ${await clickText('恢复默认（数值）')}`)
  await sleep(900)
  const a3 = await measure('A3 数值恢复后@frame(变小)')

  console.log('\n# 阶段 4：数值恢复后把窗口改回较大（未挂载本应给出更大的默认值）')
  await clickText('关闭右栏')
  await resizeWindow(1500, 900)
  console.log(`打开右栏: ${await clickText('打开右栏（正常）')}`)
  await sleep(600)
  const a4 = await measure('A4 数值恢复后@frame(变大)')

  console.log('\n# 阶段 5：尝试把偏好写回 null（非契约），再走一次“折叠→改小→打开”')
  console.log(`写回 null: ${await clickText('尝试写回 null（非契约）')}`)
  await clickText('关闭右栏')
  await resizeWindow(900, 700)
  console.log(`打开右栏: ${await clickText('打开右栏（正常）')}`)
  await sleep(600)
  const a5 = await measure('A5 写回null后@frame(变小)')

  console.log('\n# 判定提示')
  console.log(`A1 vs 期望未设置值: ${a1.panel} vs ${a1.expectedUnset}`)
  console.log(`A2 vs 期望未设置值: ${a2.panel} vs ${a2.expectedUnset}`)
  console.log(`A3 vs A2（数值恢复应等于当前默认）: ${a3.panel} vs ${a2.panel}`)
  console.log(`A4 vs 期望未设置值（差 = 数值≠语义）: ${a4.panel} vs ${a4.expectedUnset}`)
  console.log(`A5 vs 期望未设置值（相等 = null 写回有效）: ${a5.panel} vs ${a5.expectedUnset}`)
} finally {
  socket.close()
  // 浏览器级连接不关会让进程不退出（脚本已输出全部结果却一直挂着）。
  browserSocket.close()
}

