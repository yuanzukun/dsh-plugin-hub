/**
 * 拖拽轨迹追踪：按住手柄后逐步移动，并在每一步读取宿主拖拽状态与面板宽度。
 * 用来区分“事件没到宿主”“宿主进入了拖拽状态但宽度没变”“宽度变了但采样没触发”。
 *
 * 用法：node experiments/drag-trace.mjs <debugPort> [dx] [steps]
 *
 * @module dsh-sidebar-size/experiments/drag-trace
 */
const port = process.argv[2] ?? '9223'
const dx = Number(process.argv[3] ?? -120)
const steps = Number(process.argv[4] ?? 12)

const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json()
const page = targets.find(target => target.type === 'page' && String(target.url).startsWith('dsh-app://'))
if (page?.webSocketDebuggerUrl === undefined) throw new Error('找不到 dsh-app 页面目标')

const socket = new WebSocket(page.webSocketDebuggerUrl)
await new Promise((resolve, reject) => {
  socket.addEventListener('open', () => resolve())
  socket.addEventListener('error', () => reject(new Error('调试连接失败')))
})

let nextId = 1
function send(method, params = {}) {
  const id = nextId++
  return new Promise((resolve, reject) => {
    const onMessage = (event) => {
      const message = JSON.parse(event.data)
      if (message.id !== id) return
      socket.removeEventListener('message', onMessage)
      if (message.error !== undefined) reject(new Error(`${method}: ${JSON.stringify(message.error)}`))
      else resolve(message.result)
    }
    socket.addEventListener('message', onMessage)
    socket.send(JSON.stringify({ id, method, params }))
  })
}

async function evaluate(expression) {
  const result = await send('Runtime.evaluate', { expression, returnByValue: true })
  return result.result?.value
}

const state = () => evaluate(`(() => {
  const handle = document.querySelector('[data-side="rightbar"]');
  const panel = document.querySelector('[data-sidebar-right-panel]');
  const col = document.querySelector('[data-rightbar-col]');
  return JSON.stringify({
    dragging: handle ? handle.getAttribute('data-dragging') : null,
    panel: panel ? Math.round(panel.getBoundingClientRect().width) : null,
    col: col ? Math.round(col.getBoundingClientRect().width) : null,
    inline: panel ? (panel.getAttribute('style') || '').slice(0, 32) : null,
  });
})()`)

try {
  const box = await evaluate(`(() => {
    const el = document.querySelector('[data-side="rightbar"]');
    if (!el) return null;
    const r = el.getBoundingClientRect();
    return JSON.stringify({ x: r.left + r.width / 2, y: r.top + r.height / 2 });
  })()`)
  if (box === null) throw new Error('没有手柄元素')
  const start = JSON.parse(box)
  console.log(`起点 ${Math.round(start.x)},${Math.round(start.y)}  初始 ${await state()}`)

  await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: start.x, y: start.y, button: 'left', buttons: 1, clickCount: 1 })
  await new Promise(resolve => setTimeout(resolve, 60))
  console.log(`按下后 ${await state()}`)

  for (let step = 1; step <= steps; step++) {
    await send('Input.dispatchMouseEvent', {
      type: 'mouseMoved',
      x: start.x + (dx * step) / steps,
      y: start.y,
      button: 'left',
      buttons: 1,
    })
    await new Promise(resolve => setTimeout(resolve, 40))
    if (step % 3 === 0 || step === steps) console.log(`  移动 ${step}/${steps} → ${await state()}`)
  }

  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: start.x + dx, y: start.y, button: 'left', buttons: 0, clickCount: 1 })
  await new Promise(resolve => setTimeout(resolve, 300))
  console.log(`松开后 ${await state()}`)
  console.log(`采样日志 ${await evaluate("localStorage.getItem('dsh-sidebar-size.probe.log')")}`)
} finally {
  socket.close()
}
