/**
 * 一次性本地探针：验证 host 半产物可被 Node 加载，并观察 Config 解析结果的实际形状。
 *
 * 目的：为 P01 出口提供“构建侧证据”，同时回答 U4 的第一部分问题——volatile 字段解析后
 * 是平面值还是包装对象。本探针**不接触 DSH**：只 `import` 本仓库自己构建出的
 * `lib/index.js`，用本机 Node 运行。
 *
 * 运行：`node experiments/p01-host-entry-shape.mjs`
 * 结果记录：docs/verification/V-P01-01-host-entry-and-config-shape.md
 */
const entry = new URL('../lib/index.js', import.meta.url)

const mod = await import(entry.href)

console.log('name =', mod.name)
console.log('apply 类型 =', typeof mod.apply)
console.log('导出键 =', Object.keys(mod))
console.log('Config 是 schema =', typeof mod.Config === 'function')

const parsed = mod.Config({})
console.log('Config({}) 结果键 =', Object.keys(parsed ?? {}))
for (const key of Object.keys(parsed ?? {})) {
  const value = parsed[key]
  console.log(`  ${key}: typeof=${typeof value} json=${JSON.stringify(value)}`)
}

const dict = mod.Config.dict
console.log('schema dict 键 =', Object.keys(dict ?? {}))
console.log('enabled 字段 meta =', JSON.stringify(dict?.enabled?.meta ?? null))
