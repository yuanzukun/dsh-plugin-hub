/**
 * dsh-sidebar-size —— host 半（DSH loader 侧）。
 *
 * 职责（本阶段仅到 P01）：
 *   1. 声明插件名与 Config；Config 的两个布尔字段就是用户可见的两个开关：
 *      `enabled`（总开关）与 `perContent`（是否按显示内容区分尺寸）。
 *   2. 为 DSH 设置服务提供这两个字段的 schema。字段标记为 volatile，使设置改动走
 *      Loader 的即时提交路径（loader/volatile-update），而不是重新挂载插件实例。
 *
 * 明确不做的事：
 *   - 不读写宽度数据（宽度表由客户端半经 M5 独占保存，host 半不接触）；
 *   - 不修改宿主配置文档，也不注册自己的设置命名空间；
 *   - `apply` 目前不产生任何副作用（不查 DOM、不写宽度、不注册观察器）。
 *
 * 两个关键约定来自固定版本源码核验（见 源码核验记录.md S9/S10、实现规划 2.3）：
 *   - schemastery 必须取自 DSH 的 `@deepseek-ai/schemastery`，不能取自公共
 *     `schemastery` 包：只有 DSH 的构建会把 `meta.volatile` 字段包装成 cosmokit
 *     的 Volatile 引用，Loader 的 volatile 提交路径依赖该引用；用公共包时写入会
 *     “报告成功但值不生效”。
 *   - `.volatile()` 返回的是副本，因此必须在构造 schema 时就使用它的返回值。
 *
 * @module dsh-sidebar-size
 */

import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'

/** 插件名（同时是 loader 诊断名）。 */
export const name = 'sidebar-size'

/**
 * 用户可见的两个开关的**序列化取值**形状。
 *
 * 这是设置服务往返、并最终到达客户端 `configForms` 快照的形状说明，不是
 * {@link Config} 的 schema 类型。
 *
 * 已实测的形状差异（证据：docs/verification/V-P01-01，本地导入产物所得）：
 * `Config({})` 返回的 volatile 字段**不是平面布尔值**，而是 cosmokit 的 Volatile 引用
 * （带 `get` 与 `Symbol(cosmokit.volatile.write)`），对它做 `JSON.stringify` 得到 `{}`。
 * Loader 的即时提交路径正是写入该引用，因此：
 *   - host 半不读取这两个字段（本文件确实不读），避免把引用对象当布尔值使用；
 *   - 客户端必须通过设置服务（`configForms` / `settings.describe`）读取已解包的取值，
 *     并在首次确认值到达前保持等待（P02 的 U4 实验负责确认线路上的实际形状）。
 */
export interface SidebarSizeConfig {
  /** 总开关：关闭后本插件不观察、不应用宽度，等同未挂载。 */
  enabled: boolean
  /** 区分内容开关：开启按显示内容分别记忆，关闭只保留一套统一宽度。 */
  perContent: boolean
}

/**
 * 本插件的 Loader 行 schema。
 *
 * 默认值都是 true：首次安装即开启按内容区分（需求与边界 6 的冻结决策）。两个字段
 * 均为 volatile，因此设置页的改动即时提交、不重挂载插件实例。
 */
export const Config = z.object({
  enabled: z.boolean().default(true).volatile(),
  perContent: z.boolean().default(true).volatile(),
})

/**
 * host 半装配。
 *
 * P01 阶段只保证“可被 Loader 加载”：不注册服务、不产生副作用、不持有资源。后续阶段
 * 在这里加入的每一件事都必须可释放（`ctx.effect` 或等价机制），并且失败只记录不外抛。
 *
 * @param ctx - host 上下文。
 * @param _config - Loader 按 {@link Config} 校验后的配置值。
 */
export function apply(ctx: Context, _config: SidebarSizeConfig): void {
  // P03 起：在此登记设置页策略与运行诊断所需的 host 侧资源。
  // 目前刻意保持空实现：入口可加载、可卸载，不产生任何宿主副作用。
  void ctx
}
