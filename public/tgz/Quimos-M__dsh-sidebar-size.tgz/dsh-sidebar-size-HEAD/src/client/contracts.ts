/**
 * dsh-sidebar-size —— 跨模块输入输出契约。
 *
 * 本文件**只声明类型，不含任何运行时代码**。它是实现规划第 6 部分（模块与接口）
 * 的可编译形式：M1 HostBridge / M2 ContentKind / M3 WidthTable / M4 Guard /
 * M5 WidthStore / M6 Controller / M8 Preferences 之间传递的每一种数据都先在这里
 * 固定名称与形状，随后各模块只按这些形状交互。
 *
 * 遵守的不变式（实现规划 4.3）：
 *   1. 用户意图（保存值）与宿主实际布局宽度分开，窗口变小不覆盖保存值；
 *   2. 一次用户保存只写 split 的某个键或 unified 一处；
 *   3. 只有从正常右栏手柄开始的真实拖拽产生用户记录；
 *   4. 延迟保存携带采样时固定的 key / mode / 上下文 / 代次；
 *   5. 已确认设置与界面草稿分开；
 *   6. M7 不直接操作宿主或存储，全部经 M6；
 *   7. 每次启动宽度持久化最多读取一次；
 *   8. 总开关关闭与卸载后不再观察、不再写宽度。
 *
 * @module dsh-sidebar-size/client/contracts
 */

/** 释放函数。释放注册、事件、计时或观察器；与“清空持久数据”无关。 */
export type Disposer = () => void

// ─────────────────────────────────────────────────────────── M1 HostBridge

/** 正常右栏的展示形态。 */
export type Presentation = 'push' | 'fullscreen' | 'collapsed' | 'hidden'

/** 当前绑定面板的身份：会话 + 面板元素。 */
export interface PanelIdentity {
  readonly sessionId: string
  /** 面板元素身份（同一会话内重新挂载会改变）。 */
  readonly elementId: string
}

/** 当前正常右栏的只读视图。framePx/observedPx 是测量值，不是宿主偏好值。 */
export interface HostView {
  readonly sessionId: string
  readonly panelIdentity: PanelIdentity | undefined
  readonly expanded: boolean
  readonly presentation: Presentation
  /** 框架元素实测宽度；未取得时为 null，此时不执行默认写入。 */
  readonly framePx: number | null
  /** 正常右栏列实测宽度；正常列不可显示时为 null 或 0。 */
  readonly observedPx: number | null
  readonly activeDockContent: ActiveContent | undefined
  readonly availability: HostAvailability
}

/** M1 报告的能力状态：ready 之外的状态都不产生保存，也不应用宽度。 */
export type HostAvailability =
  | { readonly kind: 'ready' }
  | { readonly kind: 'waiting'; readonly reason: string }
  | { readonly kind: 'unsupported'; readonly reason: string }
  | { readonly kind: 'error'; readonly reason: string }

/** 当前停靠面板中的活动内容。分类键由 M2 从 kind 构造，不使用 tabId 作键。 */
export interface ActiveContent {
  readonly sessionId: string
  readonly paneId: string
  readonly tabId: string
  readonly kind: string
  /** 页签内容标识（文件地址等）；首版保留但不用它细分尺寸。 */
  readonly contentId: string | undefined
}

/** 宽度写入结果。resetLevel 说明默认恢复到哪一层含义（见需求文档 S11）。 */
export interface ApplyResult {
  readonly status: 'applied' | 'deferred' | 'unavailable' | 'failed'
  readonly requestedPx?: number
  readonly observedPx?: number
  readonly resetLevel?: ResetLevel
  readonly reason?: string
}

/** numeric 仅表示写入了目标版本的默认数值；semantic 才等同于未挂载。 */
export type ResetLevel = 'numeric' | 'semantic'

/** 一次宽度采样：数值 + 证明它来自哪次指针提交/哪一代几何。 */
export interface WidthSample {
  readonly px: number
  readonly panelIdentity: PanelIdentity
  /** 该采样可关联的指针提交序号；无关联时为 null。 */
  readonly pointerCommitSeq: number | null
  /** 框架/左栏占用等几何代次；环境变化时递增。 */
  readonly geometryGeneration: number
  readonly phase: 'dragging' | 'ending' | 'idle'
  readonly valid: boolean
  readonly invalidReason?: string
}

/** 拖拽信号：区分正常抬起、抬手后的捕获释放与意外取消。 */
export type DragSignal =
  | { readonly kind: 'pointer-down'; readonly pointerId: number; readonly panelIdentity: PanelIdentity }
  | { readonly kind: 'pointer-up'; readonly pointerId: number }
  | { readonly kind: 'capture-released'; readonly pointerId: number }
  | { readonly kind: 'cancelled'; readonly pointerId: number; readonly reason: string }

/** M1 对外提供的宿主接入接口。 */
export interface HostBridge {
  readView(): HostView
  observeStructure(listener: () => void): Disposer
  observeWidth(listener: (sample: WidthSample) => void): Disposer
  observeDrag(listener: (signal: DragSignal) => void): Disposer
  applyWidth(px: number): Promise<ApplyResult>
  restoreDefault(reason: string): Promise<ApplyResult>
  /** 读取宿主最终提交的尺寸；可带上本次手势上下文用于诊断，不传也可。 */
  readFinalDragSample(context?: DragContext): Promise<WidthSample | null>
  /**
   * P11 #2 预备应用：在右栏**尚未渲染/尚未打开**时把宽度偏好写好。
   *
   * 与 {@link applyWidth} 的区别：`applyWidth` 要求面板已经是正常停靠展示（否则 deferred），
   * 而首帧问题的根源正是“面板还没渲染时写不进去”；本方法只做写入与失败隔离，不测量、
   * 不等待渲染，返回是否调用成功。它只写宽度偏好，不改变开关、不动存储。
   *
   * @param px - 目标像素值（调用方已按链解析并保证是有效宽度）。
   * @returns 是否成功调用宿主写入口；失败时给出原因。
   */
  preApplyWidth(px: number): { readonly ok: boolean; readonly reason?: string }
  /**
   * 读取**服务侧**的当前活动页签（`ctx.sidebarRight.active()`）。
   *
   * 与 `readView().activeDockContent`（DOM 面板）不同，它在面板未打开时也可能有值：
   * 只要该会话的 store 已被渲染运行时实例化（与是否展开无关），宿主恢复出来的活动页签就可读。
   *
   * @returns 活动页签信息；无法读取（含从未打开过右栏）时返回 undefined。
   */
  readServiceActiveContent(): ActiveContent | undefined
  /**
   * 订阅“打开的页签清单”变化（`ctx.sidebarRight.openTabs`，**乙级依赖**：该成员只在实现类上，
   * 不在 `ISidebarRight` 接口里）。
   *
   * 它是最好的“该会话 store 刚刚被实例化/播种”信号：adopt 时宿主会 `inventory.update → publish`，
   * 因此这个回调通常早于用户第一次展开右栏，从而让预备应用赶在首帧之前。
   *
   * @param listener - 变化回调。
   * @returns 取消订阅；该成员不可用时返回空函数（并让能力报告标出 `hasTabsObservable: false`）。
   */
  observeTabs(listener: () => void): Disposer
  /**
   * P12-E：结构观察器的可观测量（诊断块显示）。
   *
   * `listeners` 达到上限（M1 的 `MAX_STRUCTURE_LISTENERS`）后登记会被拒绝并在控制台报错——
   * 这是“重复登记”这类缺陷的早期可见信号。
   */
  structureStats(): { readonly listeners: number; readonly notifications: number; readonly refused: number }
  dispose(): void
}

// ───────────────────────────────────────────────────────── M2 ContentKind

/** 分类键：`kind:<转义后的类型名>`。构造集中在 M2 内部，其他模块不得拼接。 */
export type ContentKey = string

/** 分类结果：无法确定时返回 unavailable，不生成兜底记录。 */
export type Classification =
  | { readonly kind: 'keyed'; readonly key: ContentKey; readonly kindName: string }
  | { readonly kind: 'unavailable'; readonly reason: string }

/** 分类键的显示信息。 */
export interface ContentDescription {
  readonly kind: string
  readonly labelFallback: string
}

export interface ContentKind {
  classify(content: ActiveContent | undefined): Classification
  describe(key: ContentKey): ContentDescription
}

// ────────────────────────────────────────────────────────── M3 WidthTable

/** 数据版本。修改字段含义或键格式时递增，并给出迁移规则。 */
export const WIDTH_SCHEMA_VERSION = 1

/** 持久化形状（原样交给 M5 承载）。unified 为 null 表示未保存；0 另有含义。 */
export interface PersistedShape {
  readonly schema: number
  readonly split: Readonly<Record<ContentKey, number>>
  readonly unified: number | null
}

/** 一个已保存条目（只读快照，外部不能借此修改内部表）。 */
export interface WidthEntry {
  readonly key: ContentKey
  readonly kind: string
  readonly px: number
}

/** 解析结果：逐条剔除非法项，整体损坏或未来版本由调用者进入保护路径。 */
export interface ParseResult {
  readonly table: PersistedShape
  readonly errors: readonly ParseError[]
  readonly unsupportedVersion: boolean
}

export interface ParseError {
  readonly scope: 'root' | 'split'
  readonly key?: string
  readonly reason: string
}

/** 表操作结果。rejected 不回写任何数据。 */
export type TableWriteResult = 'changed' | 'rejected'

/** 内存宽度表。M3 是它的唯一修改者；M5 只负责把它写到介质。 */
export interface WidthTable {
  parse(value: unknown): ParseResult
  get(key: ContentKey, mode: Mode): number | null
  set(key: ContentKey, mode: Mode, px: number): TableWriteResult
  entries(mode: Mode): readonly WidthEntry[]
  replace(table: PersistedShape): void
  clearAll(): void
  serialize(): PersistedShape
}

/** 记忆命名空间。两套数据互不复制、互不覆盖。 */
export type Mode = 'split' | 'unified'

/**
 * M6 的运行阶段（实现规划 7.2）。
 *
 * - `init`：装配中；
 * - `prefs-waiting`：内存表已初始化，但还没有拿到宿主的第二个开关确认值——此时不改宽度；
 * - `dormant`：总开关已确认关闭；停止尺寸观察，保留设置入口与内存表；
 * - `waiting`：已启用，等待可用的正常右栏（服务迟到、面板未挂载、全屏/折叠都属此列）；
 * - `active`：正常右栏就绪，可以按当前内容应用宽度；
 * - `paused`：曾经就绪，但当前不可显示（折叠、全屏、隐藏、正常列为 0）；
 * - `disposed`：已卸载，之后不再观察也不再改宽度。
 */
export type KeeperState =
  | 'init'
  | 'prefs-waiting'
  | 'dormant'
  | 'waiting'
  | 'active'
  | 'paused'
  | 'disposed'

/** M6 对外暴露的可订阅快照（P03 阶段的最小集合）。 */
export interface KeeperSnapshot {
  readonly state: KeeperState
  readonly prefsReady: boolean
  readonly enabled: boolean | null
  readonly perContent: boolean | null
  /** 内存表里已保存的类型条目（只读快照）。 */
  readonly savedEntries: readonly WidthEntry[]
  readonly unified: number | null
  readonly storageStatus: StorageStatus
  readonly dirty: boolean
  /** 本次实例启动以来对宽度存储的读取次数（用于验收“启动只读一次”）。 */
  readonly storageReads: number
  /** 最近一次成功落盘的内存修订号；-1 表示从未写过。 */
  readonly writtenRevision: number
  /** 当前内存修订号。 */
  readonly memoryRevision: number
  /** E2：结构契约是否健康（降级时暂停自动应用，但保留数据管理与用户保存）。 */
  readonly structureHealthy: boolean
  /** E2：结构问题的原因说明；健康时为 null。 */
  readonly structureNote: string | null
  /** 最近一次显式动作的结果（诊断用）。 */
  readonly lastAction: { readonly action: string; readonly at: string; readonly result: ApplyResult } | null
  /** 当前内容上下文与它的分类结果。 */
  readonly activeKey: ContentKey | null
  readonly activeLabel: string | null
  readonly error: string | null
  /**
   * P12-E：被结算重入闸门挡下的次数（诊断可见）。
   *
   * 稳态应为 0：非 0 说明有观察器在注册时同步回调，或有人在结算过程中重复登记观察器。
   */
  readonly settleReentries: number
}

// ────────────────────────────────────────────────────────────── M4 Guard

/** 一次手势的固定归属：采样之后不再重新读取当前内容或当前模式。 */
export interface DragContext {
  readonly pointerId: number
  readonly panelIdentity: PanelIdentity
  readonly sessionId: string
  readonly paneId: string
  readonly tabId: string
  readonly key: ContentKey
  readonly mode: Mode
  readonly generation: number
}

/** 被接受的一次采样：携带固定归属，交给 M6 更新内存与排队保存。 */
export interface AcceptedSample {
  readonly key: ContentKey
  readonly mode: Mode
  readonly px: number
  readonly dragId: number
  readonly generation: number
}

/** 手势状态机。只依据 M1 提供的信号，不自行读取 DOM 或服务。 */
export interface Guard {
  beginDrag(context: DragContext): 'accepted' | 'rejected'
  acceptSample(sample: WidthSample): AcceptedSample | null
  beginEnding(signal: DragSignal): void
  finishDrag(): void
  canApply(): boolean
  cancel(reason: string): void
}

// ──────────────────────────────────────────────────────────── M5 WidthStore

/** 宽度持久化介质。M5 是唯一写入者，不拥有内存表。 */
export interface WidthStore {
  readAll(): Promise<ReadResult>
  protect(rawText: string, reason: string): void
  writeAll(value: PersistedShape, options?: WriteOptions): Promise<WriteResult>
  clearAll(): Promise<WriteResult>
  getStatus(): StorageStatus
}

export type ReadResult =
  | { readonly kind: 'empty' }
  | { readonly kind: 'loaded'; readonly rawText: string }
  | { readonly kind: 'unavailable'; readonly reason: string }

export interface WriteOptions {
  /** 默认 false；仅用于用户已确认的“替换受保护原文”导入。 */
  readonly replaceProtected?: boolean
}

/** durable 表示存储接口已接受持久化写入，不是断电级磁盘保证。 */
export interface WriteResult {
  readonly ok: boolean
  readonly reason?: string
  readonly durable: boolean
  readonly protected?: boolean
}

export interface StorageStatus {
  readonly available: boolean
  readonly writable: boolean
  readonly protected: boolean
  readonly error?: string
  /** 保护状态下未采用的原始文本，供诊断导出；不参与正常迁移导出。 */
  readonly rawProblemText?: string
}

// ─────────────────────────────────────────────────────────── M8 Preferences

/** 已确认的插件设置（来自宿主 Config 表单；草稿不属于这里）。 */
export interface PrefsSnapshot {
  readonly state: 'loading' | 'ready' | 'unavailable'
  /** 最后一次确认的总开关；null 表示尚未确认，任何调用者都不得按默认值动作。 */
  readonly enabled: boolean | null
  /** 最后一次确认的区分内容开关；null 含义同上。 */
  readonly perContent: boolean | null
  readonly revision: number | null
  readonly writable: boolean
  /** host = 与宿主设置文档同步；memory = 仅本进程有效（非本机页面）。 */
  readonly mode: 'host' | 'memory' | null
  readonly error?: string
}

export interface PrefsPatch {
  readonly enabled?: boolean
  readonly perContent?: boolean
}

export interface PrefsWriteResult {
  readonly ok: boolean
  readonly snapshot: PrefsSnapshot
  readonly reason?: string
}

/** 设置服务适配器：读取、订阅与异步更新，不保存宽度。 */
export interface Preferences {
  getSnapshot(): PrefsSnapshot
  subscribe(listener: (snapshot: PrefsSnapshot) => void): Disposer
  ensure(): Promise<PrefsSnapshot>
  update(patch: PrefsPatch): Promise<PrefsWriteResult>
  dispose(): void
}

// ───────────────────────────────────────────────────────────── M6 Controller

/** 设置界面需要的完整快照。 */
export interface SettingsSnapshot {
  readonly prefsReady: boolean
  readonly enabled: boolean
  readonly perContent: boolean
  readonly activeContent: ContentDescription | null
  readonly savedEntries: readonly WidthEntry[]
  readonly unifiedSet: boolean
  readonly storageStatus: StorageStatus
  readonly dirty: boolean
  readonly applyCapability: HostAvailability
  readonly defaultResetLevel: ResetLevel | null
  readonly busy: boolean
  readonly error: string | null
}

/** 导入预览：确认前只展示将要替换的范围，不改动任何数据。 */
export interface ImportPreview {
  readonly previewId: string
  readonly splitKeys: readonly ContentKey[]
  readonly unified: number | null
  readonly errors: readonly ParseError[]
  readonly unsupportedVersion: boolean
}

export interface ActionResult {
  readonly ok: boolean
  readonly reason?: string
}

/** 控制器：初始化、就绪、保存队列、应用、模式切换、数据管理与释放。 */
export interface Controller {
  start(): Promise<void>
  setEnabled(next: boolean): Promise<ActionResult>
  setPerContent(next: boolean): Promise<ActionResult>
  setWidthFor(key: ContentKey, mode: Mode, px: number): Promise<ActionResult>
  resetWidths(): Promise<ActionResult>
  exportWidths(): { readonly text: string; readonly dirty: boolean }
  exportProblemData(): { readonly text: string; readonly reason: string } | null
  previewImport(text: string): ImportPreview
  commitImport(previewId: string): Promise<ActionResult>
  getSnapshot(): SettingsSnapshot
  subscribe(listener: (snapshot: SettingsSnapshot) => void): Disposer
  dispose(): Promise<void>
}
