/**
 * M2 ContentKind —— 分类键的构造、拆解与显示标识（P03 起的纯逻辑部分）。
 *
 * 职责边界：
 *   * **键构造集中在这里**：任何模块都不得自行拼接 `kind:` 前缀或转义规则；
 *   * 由运行时读到的页签 `kind` 构造键；`contentId`（文件地址等）首版不参与分类，
 *     但保留在输入类型里，供将来的按扩展名细分使用；
 *   * 没有合法 kind（空串、读不到活动内容）时返回 unavailable，**不生成兜底记录**
 *     （否则一个瞬时空状态会被永久保存成一种“内容类型”）。
 *
 * 转义规则（v1）：仅保留 `A-Za-z0-9._-`，其余 UTF-16 码元一律写成 `%XXXX`（四位十六进制）。
 * 这样键里不会出现冒号、引号、空白或 `__proto__` 之类的特殊形式，也保证可逆。
 *
 * @module dsh-sidebar-size/client/content-kind
 */

import type { ActiveContent, Classification, ContentDescription, ContentKey } from './contracts.ts'

/** 分类键前缀。 */
export const KEY_PREFIX = 'kind:'

/** 已知类型的中文名称（只用于界面显示；未知类型保留自己的键并使用通用文案）。 */
const KNOWN_KIND_LABELS: Readonly<Record<string, string>> = {
  guide: '引导页',
  files: '文件',
  text: '文本预览',
  editor: '编辑器',
  terminal: '终端',
  browser: '浏览器',
  git: '文件变动',
  subagent: '任务管理',
  jobs: '任务',
  chat: '侧边对话',
  diff: '差异',
  preview: '预览',
}

/**
 * 内容层级的根（最上级内容页）。见决定记录 `docs/decisions/D-002-inherit-parent-width.md`。
 */
export const ROOT_KIND = 'guide'

/**
 * 内容层级的父级表（P11 #3 / D-002）。
 *
 * 为什么是**内置常量**而不是用户设置：父链是内容导航的客观结构（引导页 → 文件页 → 文档），
 * 不是用户偏好；做成设置项会平白扩大界面与持久化面（详见 D-002 的“为什么不选其它方案”）。
 *
 * 未在表里的 kind（含第三方页签注册的 kind）一律视为挂在根下，这样任何新类型都有确定行为，
 * 不需要随第三方插件更新这张表。
 */
const KIND_PARENTS: Readonly<Record<string, string | null>> = {
  guide: null,
  files: 'guide',
  editor: 'files',
  text: 'files',
}

/** 链的最大深度保护：表里理论上无环，这里仍给一个上限，避免任何意外导致死循环。 */
const MAX_CHAIN_DEPTH = 8

/**
 * 取某个 kind 的上级 kind。
 * @param kind - 运行时类型名。
 * @returns 上级 kind；根返回 null。
 */
function parentKindOf(kind: string): string | null {
  if (Object.prototype.hasOwnProperty.call(KIND_PARENTS, kind)) return KIND_PARENTS[kind] ?? null
  return kind === ROOT_KIND ? null : ROOT_KIND
}

/**
 * 一个内容键的继承链：从**直接上级**到根，按由近及远排序，**不含自身**。
 *
 * @param key - 当前内容的分类键。
 * @returns 上级键列表；键不合法时返回空数组。
 */
export function inheritanceChain(key: ContentKey): ContentKey[] {
  const kind = decodeKind(key)
  if (kind === null) return []
  const chain: ContentKey[] = []
  let current = parentKindOf(kind)
  let depth = 0
  while (current !== null && depth < MAX_CHAIN_DEPTH) {
    const encoded = encodeKind(current)
    if (encoded === null) break
    chain.push(encoded)
    current = parentKindOf(current)
    depth += 1
  }
  return chain
}

/** 链解析结果：值、来源与（继承时的）来源键。 */
export interface ChainResolution {
  readonly value: number | null
  readonly origin: 'own' | 'inherited' | 'default'
  readonly fromKey: ContentKey | null
}

/**
 * **唯一**的宽度解析函数：`本类型记录 → 上级记录 → … → 根记录 → 默认`。
 *
 * 所有应用路径（面板就绪后的自动应用、模式切换、布局约束重试、重置后的应用、导入后的应用、
 * 以及预备应用）都必须只经由它，否则会出现“界面显示一个值、日志说另一个值”的分裂。
 * 它**只读**：继承值永远不会因此落盘。
 *
 * @param input - 当前内容键、自身记录值与查表回调（回调只应返回显式记录）。
 * @returns 解析结果。
 */
export function resolveWidth(input: {
  readonly key: ContentKey | null
  readonly own: number | null
  readonly lookup: (key: ContentKey) => number | null
}): ChainResolution {
  if (input.own !== null) return { value: input.own, origin: 'own', fromKey: input.key }
  if (input.key === null) return { value: null, origin: 'default', fromKey: null }
  for (const ancestor of inheritanceChain(input.key)) {
    const value = input.lookup(ancestor)
    if (value !== null) return { value, origin: 'inherited', fromKey: ancestor }
  }
  return { value: null, origin: 'default', fromKey: null }
}

/**
 * 由一个运行时 kind 构造分类键。
 * @param kind - 宿主页签类型名。
 * @returns 键；kind 不是非空字符串时返回 null（表示 unavailable）。
 */
export function encodeKind(kind: unknown): ContentKey | null {
  if (typeof kind !== 'string') return null
  const trimmed = kind.trim()
  if (trimmed === '') return null
  return KEY_PREFIX + escapeKeyPart(trimmed)
}

/**
 * 把分类键还原成运行时 kind。
 * @param key - 分类键。
 * @returns kind；键格式不合法时返回 null。
 */
export function decodeKind(key: string): string | null {
  if (!isContentKey(key)) return null
  return unescapeKeyPart(key.slice(KEY_PREFIX.length))
}

/**
 * 判断一个字符串是否是本版本的合法分类键。
 * @param value - 待判断的值。
 * @returns 合法为 true。
 */
export function isContentKey(value: unknown): value is ContentKey {
  if (typeof value !== 'string' || !value.startsWith(KEY_PREFIX)) return false
  const body = value.slice(KEY_PREFIX.length)
  if (body === '') return false
  return unescapeKeyPart(body) !== null
}

/**
 * 由活动内容构造分类键。
 * @param content - M1 读到的活动内容；读不到时为 undefined。
 * @returns 分类结果；读不到合法 kind 时为 unavailable。
 */
export function classify(content: ActiveContent | undefined): Classification {
  if (content === undefined) return { kind: 'unavailable', reason: '没有可靠的活动停靠内容' }
  const key = encodeKind(content.kind)
  if (key === null) return { kind: 'unavailable', reason: '宿主没有给出可用的页签类型' }
  return { kind: 'keyed', key, kindName: content.kind.trim() }
}

/**
 * 分类键的显示信息。
 * @param key - 分类键。
 * @returns kind 与界面回退文案。
 */
export function describe(key: ContentKey): ContentDescription {
  const kind = decodeKind(key)
  if (kind === null) return { kind: '', labelFallback: '未知类型' }
  const label = KNOWN_KIND_LABELS[kind]
  return {
    kind,
    labelFallback: label === undefined ? `其他类型：${kind}` : label,
  }
}

/** 转义一个键片段。 */
function escapeKeyPart(text: string): string {
  let out = ''
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index] as string
    if (/^[A-Za-z0-9._-]$/.test(char)) {
      out += char
      continue
    }
    out += `%${text.charCodeAt(index).toString(16).padStart(4, '0')}`
  }
  return out
}

/** 反转义一个键片段；格式不合法时返回 null。 */
function unescapeKeyPart(text: string): string | null {
  let out = ''
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index] as string
    if (char !== '%') {
      if (!/^[A-Za-z0-9._-]$/.test(char)) return null
      out += char
      continue
    }
    const hex = text.slice(index + 1, index + 5)
    if (!/^[0-9a-fA-F]{4}$/.test(hex)) return null
    out += String.fromCharCode(Number.parseInt(hex, 16))
    index += 4
  }
  return out === '' ? null : out
}
