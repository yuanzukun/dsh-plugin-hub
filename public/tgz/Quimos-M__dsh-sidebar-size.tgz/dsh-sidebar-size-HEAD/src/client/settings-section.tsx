/**
 * M7 SettingsSection —— 「侧边栏尺寸」设置分组的正式界面（P07）。
 *
 * 提供需求里的四项设置：
 *   a. 总开关；
 *   b. 区分内容开关（附用户指定的原文提示）；
 *   c. 下拉栏：选择本插件已保存尺寸的内容类型并改值；
 *   d. 重置按钮（点击后弹出二次确认弹窗，文案按用户原话，逐字包含三行与加粗）。
 * 另提供数据迁移：导出正常数据、单独导出未采用的诊断原文、预览确认后导入。
 *
 * 约束：本组件只与 {@link DiagnosticsSurface}（进而只与 M6 控制器）交互，
 * 不直接访问宿主服务、存储或 DOM；诊断与实验区块保留在下方，供目标环境验收使用。
 *
 * @module dsh-sidebar-size/client/settings-section
 */

import type { ReactNode } from 'react'
import { useEffect, useState } from 'react'
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
// 仅类型：拉入 settings.section 槽位的 SlotMap 合并声明。
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import { Button, Input, Modal, Switch } from '@deepseek-ai/dsh-client-ui-primitives'
import type { ContentKey, ImportPreview, Mode } from './contracts.ts'
import { describe } from './content-kind.ts'
import type { DiagnosticsState, DiagnosticsSurface } from './diagnostics.ts'
import { deriveRunState, deriveWidthReport, describeActiveTab } from './status-report.ts'

/** 注册时通过 inject 面交给组件的业务对象。 */
export interface SidebarSizeSectionInjected {
  readonly diagnostics: DiagnosticsSurface
}

/** 分组组件的完整 props：槽位运行时（含 close）＋业务注入面。 */
export type SidebarSizeSectionProps = PropsRuntime<'settings.section'> & SidebarSizeSectionInjected

const cardStyle = {
  border: '1px solid var(--dsh-border, #3a3a3a)',
  borderRadius: 8,
  padding: '12px 14px',
  marginBottom: 12,
  lineHeight: 1.7,
  fontSize: 13,
} as const

const rowStyle = { display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' } as const
const labelStyle = { opacity: 0.65, minWidth: 148 } as const
const monoStyle = { fontFamily: 'ui-monospace, Consolas, monospace' } as const
const hintStyle = { opacity: 0.72, marginTop: 4, lineHeight: 1.6 } as const

/** 一行“名称：值”。 */
function Row({ label, children }: { label: string; children: ReactNode }): ReactNode {
  return (
    <div style={rowStyle}>
      <span style={labelStyle}>{label}</span>
      <span style={monoStyle}>{children}</span>
    </div>
  )
}

/** 把可选值渲染成文本。 */
function text(value: unknown): string {
  if (value === null || value === undefined) return '—'
  if (typeof value === 'string') return value === '' ? '（空）' : value
  return String(value)
}

/** 区分内容开关的提示文案（用户原话，逐字）。 */
const PER_CONTENT_NOTICE = '开启该功能时，插件会针对不同的显示内容区别保持尺寸；关闭该功能时，插件将会只保存一种侧边栏尺寸。该功能开启和关闭时侧边栏保存的尺寸数据并不互通，因此若您是第一次关闭该功能，您的侧边栏尺寸将会回到DSH的默认尺寸数值。'

/**
 * 上级继承的说明文案（P11 #3 / Q18，用户确认的措辞）。
 *
 * 与 {@link PER_CONTENT_NOTICE} 分开呈现：后者是用户原话、逐字不改，前者是本版本新增行为的说明。
 */
const INHERIT_NOTICE = '没有记录的内容会先沿用上级内容页的尺寸（引导页 → 文件页 → 文档），不会自动为它创建记录。'

export function SidebarSizeSection(props: SidebarSizeSectionProps): ReactNode {
  const { diagnostics } = props
  const [state, setState] = useState<DiagnosticsState>(() => diagnostics.getSnapshot())
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')
  const [draft, setDraft] = useState('600')
  const [selected, setSelected] = useState<ContentKey>('')
  const [confirmReset, setConfirmReset] = useState(false)
  const [exportText, setExportText] = useState('')
  const [importText, setImportText] = useState('')
  const [preview, setPreview] = useState<ImportPreview | null>(null)
  /** 日志报告文本框的内容（空串表示收起）。 */
  const [logText, setLogText] = useState('')

  useEffect(() => diagnostics.subscribe(() => setState(diagnostics.getSnapshot())), [diagnostics])

  const snapshot = state.keeper
  const keeper = diagnostics.keeper()
  /**
   * 只读呈现：宿主设置服务不可用（或处于 memory 模式）时，开关仍显示已确认值，
   * 但不允许改动——界面必须如实说明“改不了”，而不是假装写成功。
   */
  const settingsLocked = state.prefs === null || state.prefs.mode === 'memory' || state.prefs.writable === false
  const switchDisabled = busy || keeper === null || settingsLocked
  const switchTitle = keeper === null
    ? '宿主服务尚未就绪'
    : settingsLocked ? '宿主设置当前不可写（插件不会假装写入成功）' : undefined
  const mode: Mode = snapshot?.perContent === false ? 'unified' : 'split'
  const entries = snapshot?.savedEntries ?? []
  // 下拉项：区分模式列出已保存的类型；统一模式只有一项“所有内容”。
  const options = mode === 'unified'
    ? [{ key: '', label: '所有内容', px: snapshot?.unified ?? null }]
    : entries.map(entry => ({ key: entry.key, label: `${describe(entry.key).labelFallback}（${describe(entry.key).kind}）`, px: entry.px }))

  // 发布版只显示四态状态、当前活动页签与当前尺寸（P11 #1 Q9/Q13/Q19/Q23）；
  // 其余细节都在诊断门后（state.diagnosticsVisible）。尺寸来源在 #3 起走父链解析。
  const runState = deriveRunState({ keeper: snapshot, prefs: state.prefs, capability: state.capability })
  const activeTabText = describeActiveTab(snapshot?.activeLabel ?? null, snapshot?.activeKey ?? null)
  const widthReport = deriveWidthReport({ keeper: snapshot, observedPx: state.view?.observedPx ?? null })

  // 模式切换、内容切换或记录变化后，保证下拉选中项合法，并把已保存值填进输入框。
  // P11 #3 / Q22：当前内容没有自己的记录时，默认选中“正在供应尺寸的那一条”（继承来源），
  // 这样用户一眼看到“现在生效的是什么”，也能直接改它。
  useEffect(() => {
    const activeOwn = snapshot?.activeKey != null && options.some(option => option.key === snapshot.activeKey)
    const preferred = activeOwn
      ? snapshot?.activeKey
      : (widthReport.origin === 'inherited' ? widthReport.fromKey : undefined)
    const current = (preferred === undefined || preferred === null ? undefined : options.find(option => option.key === preferred))
      ?? options.find(option => option.key === selected)
      ?? options[0]
    if (current === undefined) {
      if (selected !== '') setSelected('')
      return
    }
    if (current.key !== selected) setSelected(current.key)
    if (current.px !== null) setDraft(String(current.px))
    // 只在选中项本身变化时同步草稿，避免覆盖用户正在输入的值。
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    mode,
    entries.map(entry => `${entry.key}:${String(entry.px)}`).join(','),
    snapshot?.unified,
    snapshot?.activeKey,
    widthReport.origin,
    widthReport.fromKey,
  ])

  async function run(action: () => Promise<unknown>): Promise<void> {
    setBusy(true)
    try {
      await action()
    } catch (error) {
      setMessage(`操作失败：${error instanceof Error ? error.message : String(error)}`)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div style={{ padding: '4px 2px' }}>
      <div style={cardStyle}>
        <div style={{ fontWeight: 600, marginBottom: 8 }}>侧边栏尺寸</div>

        <div style={{ ...rowStyle, justifyContent: 'space-between', marginBottom: 10 }}>
          <div>
            <div>总开关</div>
            <div style={hintStyle}>关闭后本插件不再观察、也不再调整侧边栏宽度，效果等同于未挂载。</div>
          </div>
          <Switch
            checked={snapshot?.enabled === true}
            disabled={switchDisabled}
            label="侧边栏尺寸总开关"
            title={switchTitle}
            onChange={next => { void run(async () => { await diagnostics.setMasterEnabled(next) }) }}
          />
        </div>

        <div style={{ ...rowStyle, justifyContent: 'space-between', marginBottom: 2 }}>
          <div>
            <div>按显示内容区分尺寸</div>
            <div style={hintStyle}>{PER_CONTENT_NOTICE}</div>
            <div style={hintStyle}>{INHERIT_NOTICE}</div>
          </div>
          <Switch
            checked={snapshot?.perContent === true}
            disabled={switchDisabled}
            label="按显示内容区分尺寸"
            title={switchTitle}
            onChange={next => { void run(async () => { await keeper?.setPerContent(next) }) }}
          />
        </div>
        {settingsLocked
          ? (
            <div style={{ ...hintStyle, marginTop: 6 }}>
              宿主设置当前不可写{state.prefs === null ? '（尚未就绪）' : `（模式：${state.prefs.mode}）`}：上面显示的是已确认值，改动不会被保存。
            </div>
          )
          : null}
      </div>

      <div style={cardStyle}>
        <div style={{ fontWeight: 600, marginBottom: 8 }}>已保存的宽度</div>
        <div style={{ ...rowStyle, marginBottom: 8 }}>
          <select
            aria-label="选择要修改的内容类型"
            value={selected}
            disabled={busy || keeper === null}
            onChange={(event) => {
              const key = event.target.value
              setSelected(key)
              const option = options.find(item => item.key === key)
              if (option?.px !== null && option?.px !== undefined) setDraft(String(option.px))
            }}
            style={{ minWidth: 220, padding: '4px 6px' }}
          >
            {options.length === 0
              ? <option value="">（还没有保存的记录）</option>
              : options.map(option => (
                <option key={option.key} value={option.key}>
                  {option.label}{option.px === null ? '（无记录）' : ` — ${String(option.px)}px`}
                </option>
              ))}
          </select>
          <Input
            aria-label="宽度（px）"
            value={draft}
            disabled={busy || keeper === null}
            inputMode="numeric"
            onChange={event => setDraft(event.target.value)}
            style={{ width: 96 }}
          />
          <span>px</span>
          <Button
            size="sm"
            variant="outline"
            disabled={busy || keeper === null || options.length === 0}
            onClick={() => {
              void run(async () => {
                const value = Number.parseInt(draft, 10)
                const result = await keeper?.setWidthFor(selected, mode, value)
                setMessage(result?.ok === true ? `已保存 ${selected === '' ? '所有内容' : selected} = ${String(value)}px` : `保存失败：${result?.reason ?? '未知原因'}`)
              })
            }}
          >
            保存这个宽度
          </Button>
        </div>
        <div style={hintStyle}>
          {mode === 'unified'
            ? '当前是统一模式：所有内容共用一份宽度，下拉里只有“所有内容”。'
            : '当前是按内容区分模式：每个页签类型各有一份宽度；没有记录的内容会先沿用上级内容页的尺寸（引导页 → 文件页 → 文档），不会自动为它创建记录。'}
        </div>
        {mode === 'unified' || widthReport.origin === 'own' ? null : (
          <div style={hintStyle}>
            {widthReport.origin === 'inherited'
              ? `当前内容没有自己的记录，正在继承「${widthReport.fromLabel ?? '上级内容页'}」的 ${String(widthReport.px ?? '—')}px（下拉已选中它，改它即立刻生效）。`
              : `当前内容还没有任何记录，使用 DSH 默认尺寸（${widthReport.px === null ? '读不到' : `${String(widthReport.px)}px`}）。`}
          </div>
        )}
      </div>

      <div style={cardStyle}>
        <div style={{ fontWeight: 600, marginBottom: 8 }}>数据迁移</div>
        <div style={{ ...rowStyle, marginBottom: 8 }}>
          <Button size="sm" variant="outline" disabled={keeper === null} onClick={() => setExportText(keeper?.exportWidths().text ?? '')}>
            导出当前数据
          </Button>
          {snapshot?.storageStatus.protected === true
            ? (
              <Button size="sm" variant="outline" onClick={() => setExportText(keeper?.exportProblemData()?.text ?? '')}>
                导出未采用的诊断原文
              </Button>
            )
            : null}
          <Button
            size="sm"
            variant="ghost"
            disabled={exportText === ''}
            onClick={() => { setExportText('') }}
          >
            收起导出内容
          </Button>
        </div>
        {exportText === ''
          ? null
          : (
            <textarea
              aria-label="导出的数据"
              readOnly
              value={exportText}
              rows={5}
              style={{ width: '100%', fontFamily: 'ui-monospace, Consolas, monospace', fontSize: 12, marginBottom: 8 }}
            />
          )}

        <textarea
          aria-label="要导入的数据"
          placeholder="把导出的 JSON 粘贴到这里，然后点“预览导入”"
          value={importText}
          rows={3}
          onChange={event => { setImportText(event.target.value); setPreview(null) }}
          style={{ width: '100%', fontFamily: 'ui-monospace, Consolas, monospace', fontSize: 12, marginBottom: 8 }}
        />
        <div style={{ ...rowStyle, marginBottom: 6 }}>
          <Button
            size="sm"
            variant="outline"
            disabled={keeper === null || importText.trim() === ''}
            onClick={() => {
              const next = keeper?.previewImport(importText) ?? null
              setPreview(next)
            }}
          >
            预览导入
          </Button>
          <Button
            size="sm"
            variant="primary"
            disabled={busy || keeper === null || preview === null || preview.unsupportedVersion || preview.errors.some(item => item.scope === 'root')}
            onClick={() => {
              void run(async () => {
                const result = await keeper?.commitImport(preview?.previewId ?? '')
                setMessage(result?.ok === true ? '导入已完成' : `导入失败：${result?.reason ?? '未知原因'}`)
                if (result?.ok === true) { setPreview(null); setImportText('') }
              })
            }}
          >
            确认导入
          </Button>
        </div>
        {preview === null
          ? null
          : (
            <div style={monoStyle}>
              <div>预览：{preview.splitKeys.length} 个类型记录{preview.unified === null ? '，统一值未设置' : `，统一值 ${String(preview.unified)}px`}</div>
              {preview.unsupportedVersion ? <div>数据版本高于本插件支持的版本，无法导入。</div> : null}
              {preview.errors.length === 0 ? <div>没有发现非法条目。</div> : (
                <div>
                  发现 {preview.errors.length} 处问题：
                  {preview.errors.slice(0, 6).map((item, index) => (
                    <div key={index}>{item.scope === 'root' ? '整体' : `条目 ${item.key ?? '?'}`}：{item.reason}</div>
                  ))}
                </div>
              )}
            </div>
          )}
      </div>

      <div style={cardStyle}>
        <div style={{ fontWeight: 600, marginBottom: 8 }}>重置</div>
        <div style={hintStyle}>清除本插件保存的侧边栏尺寸数据，并把当前侧边栏恢复为 DSH 的默认尺寸。</div>
        <div style={{ ...rowStyle, marginTop: 8 }}>
          <Button size="sm" variant="outline" disabled={busy || keeper === null} onClick={() => setConfirmReset(true)}>
            重置侧边栏尺寸数据
          </Button>
        </div>
      </div>

      <Modal
        open={confirmReset}
        onClose={() => setConfirmReset(false)}
        title="重置侧边栏尺寸数据"
        closeLabel="关闭"
        footer={(
          <div style={{ ...rowStyle, justifyContent: 'flex-end' }}>
            <Button variant="ghost" onClick={() => setConfirmReset(false)}>取消</Button>
            <Button
              variant="primary"
              disabled={busy}
              onClick={() => {
                void run(async () => {
                  const result = await keeper?.resetWidths()
                  setMessage(result?.ok === true ? '已重置保存的宽度数据' : `重置失败：${result?.reason ?? '未知原因'}`)
                  setConfirmReset(false)
                })
              }}
            >
              确认重置
            </Button>
          </div>
        )}
      >
        <p>该功能将会<strong>不可逆地</strong>清除插件原本保存的侧边栏尺寸数据</p>
        <p>如果您想要回到DSH的默认侧边栏尺寸，作者更推荐您关闭本插件的总开关</p>
        <p>您是否确认要重置侧边栏尺寸数据？</p>
      </Modal>

      {message === '' ? null : <div style={{ ...cardStyle, opacity: 0.9 }}>{message}</div>}

      <div style={cardStyle}>
        <div style={{ fontWeight: 600, marginBottom: 6 }}>运行状态</div>
        <Row label="状态">
          {runState.reason === null ? runState.label : `${runState.label}（${runState.reason}）`}
        </Row>
        <Row label="当前活动页签">{activeTabText}</Row>
        <Row label="当前侧边栏尺寸">{widthReport.text}</Row>
        <div style={{ ...rowStyle, marginTop: 8 }}>
          <Button
            size="sm"
            variant="outline"
            onClick={() => setLogText(diagnostics.logReport())}
          >
            导出运行日志
          </Button>
          {logText === '' ? null : (
            <Button size="sm" variant="ghost" onClick={() => setLogText('')}>收起日志</Button>
          )}
        </div>
        {logText === '' ? null : (
          <textarea
            aria-label="运行日志"
            readOnly
            value={logText}
            rows={12}
            style={{ width: '100%', fontFamily: 'ui-monospace, Consolas, monospace', fontSize: 12, marginTop: 8 }}
          />
        )}
      </div>

      {state.diagnosticsVisible ? <DiagnosticsBlocks state={state} diagnostics={diagnostics} /> : null}
    </div>
  )
}

/** 诊断与实验区块：目标环境验收用，正式设置不依赖它们。 */
function DiagnosticsBlocks({ state, diagnostics }: { state: DiagnosticsState; diagnostics: DiagnosticsSurface }): ReactNode {
  const [busy, setBusy] = useState(false)
  const [draft, setDraft] = useState('600')
  const capability = state.capability
  const view = state.view
  const prefs = state.prefs

  async function run(action: () => Promise<unknown>): Promise<void> {
    setBusy(true)
    try {
      await action()
    } catch (error) {
      console.warn('[dsh-sidebar-size] 诊断动作失败（已忽略）：', error)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div>
      <div style={cardStyle}>
        <div style={{ fontWeight: 600, marginBottom: 6 }}>控制器与存储细节（发布版隐藏）</div>
        <Row label="阶段">{state.keeper === null ? '未接入' : state.keeper.state}</Row>
        <Row label="当前模式">
          {state.keeper?.perContent === null || state.keeper === null
            ? '尚未确认'
            : state.keeper.perContent ? '区分内容（按类型各记一份）' : '统一（所有内容共用一份）'}
        </Row>
        <Row label="当前内容">
          {state.keeper?.activeKey === null || state.keeper === null
            ? '读不到（分类不可用）'
            : `${state.keeper.activeLabel ?? '—'} / ${state.keeper.activeKey}`}
        </Row>
        <Row label="已保存类型数 / 统一值">
          {state.keeper === null ? '—' : `${state.keeper.savedEntries.length} / ${text(state.keeper.unified)}`}
        </Row>
        <Row label="存储状态">
          {state.keeper === null
            ? '—'
            : `${state.keeper.storageStatus.available ? '可用' : '不可用'}`
              + `${state.keeper.storageStatus.protected ? '，原文受保护' : ''}`
              + `${state.keeper.dirty ? `，有未落盘改动（修订 ${state.keeper.memoryRevision} > 已落盘 ${state.keeper.writtenRevision}）` : '，已落盘'}`
              + `；启动读取 ${state.keeper.storageReads} 次`}
        </Row>
        <Row label="结构健康（E2）">
          {state.keeper === null
            ? '—'
            : state.keeper.structureHealthy
              ? '正常'
              : `降级：${state.keeper.structureNote ?? '找不到正常右栏面板或手柄'}`}
        </Row>
        {state.keeper?.error == null ? null : <Row label="错误">{state.keeper.error}</Row>}
        <Row label="最近一次动作">
          {state.keeper?.lastAction == null
            ? '尚未执行'
            : `${state.keeper.lastAction.action} → ${state.keeper.lastAction.result.status}`
              + `${state.keeper.lastAction.result.resetLevel === undefined ? '' : `（恢复等级 ${state.keeper.lastAction.result.resetLevel}）`}`}
        </Row>
      </div>

      <div style={cardStyle}>
        <div style={{ fontWeight: 600, marginBottom: 6 }}>运行诊断（P02 实验版）</div>
        <Row label="插件（client 半）">dsh-sidebar-size / sidebar-size-client</Row>
        <Row label="宿主条目 id">sidebar-size</Row>
        <Row label="实例身份 / 建立时间">{`${state.surfaceId} / ${state.surfaceCreatedAt}`}</Row>
        <Row label="装配次数（本次页面加载）">{state.applyCount}</Row>
        <Row label="宿主服务">
          {capability === null
            ? '未就绪（configForms / sidebarRight / layout 尚未全部可用）'
            : `layout=${capability.hasLayoutService ? '有' : '无'}, sidebarRight=${capability.hasSidebarRightService ? '有' : '无'}`}
        </Row>
        <Row label="宽度写入口">
          {capability === null
            ? '未知'
            : capability.canWriteWidth
              ? `可用（${text(capability.writePath)}）`
              : '不可用：ctx.layout 上没有可调用的宽度写入口'}
        </Row>
        <Row label="首帧预备应用（P11 #2）">
          {capability === null
            ? '未知'
            : capability.hasTabsObservable
              ? '可用（openTabs 观察器已绑定：首次打开右栏前即可写好偏好）'
              : '不可用：拿不到 openTabs 观察器，首次打开右栏时会先撑到 DSH 默认再回到记录值'}
        </Row>
        <Row label="结构监听器（P12-E）">
          {state.structureStats === null
            ? '未接入'
            : `${String(state.structureStats.listeners)} 个；通知 ${String(state.structureStats.notifications)} 次；`
              + `拒绝登记 ${String(state.structureStats.refused)} 次`}
        </Row>
        <Row label="结算重入（P12-E）">
          {state.keeper === null ? '—' : `${String(state.keeper.settleReentries)} 次（稳态应为 0）`}
        </Row>
      </div>

      <div style={cardStyle}>
        <div style={{ fontWeight: 600, marginBottom: 6 }}>设置确认值（来自宿主配置表单）</div>
        <Row label="状态">{prefs === null ? '未就绪' : `${prefs.state}（${text(prefs.mode)}）`}</Row>
        <Row label="总开关 enabled">{text(prefs?.enabled)}</Row>
        <Row label="区分内容 perContent">{text(prefs?.perContent)}</Row>
        <Row label="修订号 / 可写">{prefs === null ? '—' : `${text(prefs.revision)} / ${prefs.writable ? '可写' : '不可写'}`}</Row>
        {prefs?.error === undefined ? null : <Row label="设置错误">{prefs.error}</Row>}
      </div>

      <div style={cardStyle}>
        <div style={{ fontWeight: 600, marginBottom: 6 }}>当前右栏（M1 实测）</div>
        <Row label="会话 / 面板">{view === null ? '—' : `${text(view.sessionId)} / ${text(view.panelIdentity?.elementId)}`}</Row>
        <Row label="展示形态 / 展开">{view === null ? '—' : `${view.presentation} / ${view.expanded ? '展开' : '收起'}`}</Row>
        <Row label="框架宽 / 实测宽">{view === null ? '—' : `${text(view.framePx)} / ${text(view.observedPx)}`}</Row>
        <Row label="活动停靠内容">
          {view?.activeDockContent === undefined
            ? '读取不到（映射不到 kind 或没有活动停靠面板）'
            : `kind=${text(view.activeDockContent.kind)} tab=${text(view.activeDockContent.tabId)}`}
        </Row>
        <Row label="可用性">{view === null ? '—' : view.availability.kind + ('reason' in view.availability ? `（${view.availability.reason}）` : '')}</Row>
      </div>

      <div style={cardStyle}>
        <div style={{ fontWeight: 600, marginBottom: 6 }}>DOM 取证（选择器原样命中情况）</div>
        <Row label="右栏列数量 / 尺寸">{state.dom === null ? '—' : `${state.dom.columnCount} / ${state.dom.columnRect}`}</Row>
        <Row label="手柄数量">{state.dom === null ? '—' : state.dom.handleCount}</Row>
        <Row label="会话容器数量">{state.dom === null ? '—' : state.dom.sessionContainers}</Row>
        <Row label="面板数量">{state.dom === null ? '—' : state.dom.panels.length}</Row>
        {state.dom?.panels.map((panel, index) => (
          <Row key={index} label={`面板 ${index + 1}`}>{panel}</Row>
        ))}
        <Row label="停靠结构">{state.dom === null ? '—' : state.dom.dock}</Row>
        <Row label="openTabs">{state.dom === null ? '—' : state.dom.openTabs}</Row>
        <Row label="sidebarRight.mounted">{state.dom === null ? '—' : state.dom.mounted}</Row>
        <Row label="sidebarRight.isExpanded()">{state.dom === null ? '—' : state.dom.isExpanded}</Row>
      </div>

      <div style={cardStyle}>
        <div style={{ fontWeight: 600, marginBottom: 6 }}>显式实验动作（不会自动执行）</div>
        <div style={{ ...rowStyle, marginBottom: 8 }}>
          <input
            value={draft}
            onChange={event => setDraft(event.target.value)}
            inputMode="numeric"
            style={{ width: 90, padding: '4px 6px' }}
            aria-label="实验宽度（px）"
          />
          <span>px</span>
          <button type="button" disabled={busy} onClick={() => void run(() => diagnostics.applyWidth(Number.parseInt(draft, 10)))}>
            应用这个宽度
          </button>
          <button type="button" disabled={busy} onClick={() => void run(() => diagnostics.restoreDefault())}>
            恢复默认（数值）
          </button>
          <button type="button" disabled={busy} onClick={() => diagnostics.refresh()}>
            刷新读数
          </button>
        </div>
        <Row label="最近一次动作">
          {state.lastAction === null
            ? '尚未执行'
            : `${state.lastAction.action} → ${state.lastAction.result.status}`
              + ` (requested=${text(state.lastAction.result.requestedPx)}, observed=${text(state.lastAction.result.observedPx)}`
              + `${state.lastAction.result.resetLevel === undefined ? '' : `, resetLevel=${state.lastAction.result.resetLevel}`})`}
        </Row>
        {state.lastAction?.result.reason === undefined ? null : <Row label="结果说明">{state.lastAction.result.reason}</Row>}
      </div>

      <div style={cardStyle}>
        <div style={{ fontWeight: 600, marginBottom: 6 }}>U3 实验：记录尺寸与拖拽信号</div>
        <div style={{ ...rowStyle, marginBottom: 8 }}>
          <button type="button" disabled={busy} onClick={() => { setBusy(true); state.recording ? diagnostics.stopRecording() : diagnostics.startRecording(); setBusy(false) }}>
            {state.recording ? '停止记录' : '开始记录'}
          </button>
          <button type="button" onClick={() => diagnostics.clearSamples()}>清空</button>
          <span>当前：{state.recording ? '记录中' : '未记录'}</span>
        </div>
        {state.samples.length === 0
          ? <div style={{ opacity: 0.7 }}>开始记录后拖动右侧边栏手柄；这里会显示每次尺寸回调与手势信号。</div>
          : state.samples.map((line, index) => <div key={index} style={monoStyle}>{line}</div>)}
      </div>

      <div style={cardStyle}>
        <div style={{ fontWeight: 600, marginBottom: 6 }}>U2 实验：右栏开合与默认语义对照</div>
        <div style={{ ...rowStyle, marginBottom: 8 }}>
          <button type="button" onClick={() => diagnostics.closeRightbar()}>关闭右栏</button>
          <button type="button" onClick={() => diagnostics.openRightbar(false)}>打开右栏（正常）</button>
          <button type="button" onClick={() => diagnostics.openRightbar(true)}>打开右栏（全屏）</button>
          <button type="button" onClick={() => diagnostics.tryResetPreferenceToNull()}>尝试写回 null（非契约）</button>
        </div>
        <Row label="最近一次开合动作">{state.u2Action}</Row>
      </div>

      <div style={cardStyle}>
        <div style={{ fontWeight: 600, marginBottom: 6 }}>U4/U5 实验：开关写入与存储探针</div>
        <div style={{ ...rowStyle, marginBottom: 8 }}>
          <button type="button" disabled={busy} onClick={() => void run(async () => { await diagnostics.setPref('enabled', false) })}>enabled = false</button>
          <button type="button" disabled={busy} onClick={() => void run(async () => { await diagnostics.setPref('enabled', true) })}>enabled = true</button>
          <button type="button" onClick={() => diagnostics.probeWrite(`probe-${new Date().toISOString()}`)}>写入探针</button>
          <button type="button" onClick={() => diagnostics.probeRead()}>读取探针</button>
          <button type="button" onClick={() => diagnostics.probeClear()}>删除探针</button>
        </div>
        <Row label="设置写入">{state.prefsWrite}</Row>
        <Row label="探针读数">{state.probe}</Row>
      </div>

      <div style={cardStyle}>
        <div style={{ fontWeight: 600, marginBottom: 6 }}>控制器日志（最近 6 条）</div>
        {state.controllerLog.length === 0
          ? <div style={{ opacity: 0.7 }}>暂无日志。</div>
          : state.controllerLog.map((line, index) => <div key={index} style={monoStyle}>{line}</div>)}
      </div>
    </div>
  )
}
