/**
 * 诊断面（P02 实验级）—— 设置分组的观察数据与显式实验动作。
 *
 * **它不是 M6 控制器。** 这里没有保存队列、没有内容分类、没有模式切换：它的存在只是为了让
 * P02 的宿主能力实验（U1/U3/U4）有一个可见、可点击、可复述的界面。P03 接入 M6 后，本模块
 * 的职责会被控制器取代（届时删除或缩减为纯诊断视图）。
 *
 * 约束：
 *   * 不保存、不读取宽度存储；
 *   * 不自动应用宽度，只有用户在本分组里明确点击才调用 M1；
 *   * 宿主服务缺失时仍然可用（显示“未就绪”），因此它不依赖宿主服务的就绪时序。
 *
 * @module dsh-sidebar-size/client/diagnostics
 */

import type { ApplyResult, Disposer, HostBridge, HostView, KeeperSnapshot, Preferences, PrefsSnapshot } from './contracts.ts'
import type { DomProbe, HostCapability } from './host-bridge.ts'
import type { KeeperController } from './controller.ts'
import {
  DIAGNOSTICS_KEY,
  PLUGIN_VERSION,
  buildLogReport,
  deriveWidthReport,
  describeActiveTab,
  diagnosticsEnabled,
} from './status-report.ts'

/** 诊断面的可订阅快照。 */
export interface DiagnosticsState {
  /** 宿主宽度写入口的能力报告；宿主服务尚未就绪时为 null。 */
  readonly capability: HostCapability | null
  /** M1 读到的当前右栏视图；宿主服务尚未就绪时为 null。 */
  readonly view: HostView | null
  /** 原始 DOM 取证；宿主服务尚未就绪时为 null。 */
  readonly dom: DomProbe | null
  /** M8 的设置确认快照；宿主服务尚未就绪时为 null。 */
  readonly prefs: PrefsSnapshot | null
  /** M6 控制器的运行快照（阶段、内存表、存储状态、最近动作）。 */
  readonly keeper: KeeperSnapshot | null
  /** 最近一次显式实验动作及其结果。 */
  readonly lastAction: { readonly action: string; readonly at: string; readonly result: ApplyResult } | null
  /** 是否正在记录尺寸/拖拽信号（U3 实验）。 */
  readonly recording: boolean
  /** 已记录的信号行（最新在前，最多 24 行）。 */
  readonly samples: readonly string[]
  /** 采样内容的修订号；用于让订阅方知道样本列表变了（数组长度可能不变）。 */
  readonly samplesRevision: number
  /** 存储探针的最近读数（U5 实验）。 */
  readonly probe: string
  /** 设置写入实验的最近结果（U4 实验）。 */
  readonly prefsWrite: string
  /** 右栏开合实验的最近结果（U2 实验）。 */
  readonly u2Action: string
  /** 控制器最近几条日志（装配、阶段、保存队列与失败原因）。 */
  readonly controllerLog: readonly string[]
  /**
   * P12-E：结构观察器的可观测量（监听器数量、通知次数、被拒绝的登记次数）。
   *
   * 这是 P12 那类“重复登记 / 注册期同步回调”缺陷的早期可见信号：稳态下 `listeners` 是 1—2，
   * `refused` 恒为 0。
   */
  readonly structureStats: { readonly listeners: number; readonly notifications: number; readonly refused: number } | null
  /**
   * 诊断与实验区块是否渲染（P11 #1）。
   *
   * 由存储键 `dsh-sidebar-size.diagnostics` 决定：发布版默认隐藏，实验/验收时置 '1' 打开，
   * **不需要重启客户端**（同文档改动靠轮询、跨文档改动靠 storage 事件）。
   */
  readonly diagnosticsVisible: boolean
  /** 诊断面实例身份与创建时间：面板重新打开时若这两个值不变，说明插件没有被重新装配。 */
  readonly surfaceId: string
  readonly surfaceCreatedAt: string
  /** 本次页面加载中 client 插件被装配的次数（模块级计数，跨诊断面可见）。 */
  readonly applyCount: number
  /** 装配与读取过程中的说明；正常为空。 */
  readonly notes: readonly string[]
}

/** 已接入的宿主资源。 */
export interface DiagnosticsHost {
  readonly bridge: HostBridge & {
    capability(): HostCapability
    domReport(): DomProbe
    closeRightbar(): boolean
    openRightbar(fullscreen: boolean): boolean
    tryResetPreferenceToNull(): string
  }
  readonly prefs: Preferences
  /** P03 起接入的根控制器。 */
  readonly keeper: KeeperController
}

/** 设置分组使用的诊断接口。 */
export interface DiagnosticsSurface {
  getSnapshot(): DiagnosticsState
  subscribe(listener: () => void): Disposer
  /** 重新读取能力、视图与设置快照。 */
  refresh(): void
  /** 显式实验动作：把宽度写入宿主（依据 U1 的能力检测）。 */
  applyWidth(px: number): Promise<ApplyResult>
  /** 显式实验动作：按目标版本默认算法恢复数值。 */
  restoreDefault(): Promise<ApplyResult>
  /** U3 实验：开始/停止记录尺寸与拖拽信号。 */
  startRecording(): void
  stopRecording(): void
  clearSamples(): void
  /** U5 实验：独立实验键的写/读/删（绝不触碰正式宽度键）。 */
  probeWrite(text: string): string
  probeRead(): string
  probeClear(): string
  /** U4 实验：通过 M8 写入一个开关，返回结果说明。 */
  setPref(field: 'enabled' | 'perContent', value: boolean): Promise<string>
  /** U2 实验：调用宿主的公开右栏开合动作。 */
  closeRightbar(): string
  openRightbar(fullscreen: boolean): string
  /** U2 实验：尝试把宽度偏好写回 null（非契约调用，可失败）。 */
  tryResetPreferenceToNull(): string
  /** P03：总开关（经 M6，等待宿主确认后才转换阶段）。 */
  setMasterEnabled(next: boolean): Promise<string>
  /** P03：按当前内容应用已保存值或数值默认（显式动作，不自动执行）。 */
  applyForCurrent(): Promise<string>
  /** P03：一次数值默认清理（与总开关关闭时同一路径的显式版本）。 */
  restoreDefaultForCurrent(): Promise<string>
  /** 记录控制器日志（装配、阶段、保存队列与失败原因）；持久化到实验日志键便于排查。 */
  log(line: string): void
  /**
   * 生成可复制的日志报告（P11 #1 / Q12）：运行日志 + 状态快照 + 版本/环境。
   * **不含**会话 id、页签标题与文件路径。
   */
  logReport(): string
  /** 取当前接入的控制器（M6）；宿主服务未就绪时为 null。设置面板经它调用控制器方法。 */
  keeper(): KeeperController | null
  /** 宿主服务就绪时接入；再次接入会替换旧资源。 */
  attach(host: DiagnosticsHost): void
  /** 宿主服务失效时摘除（设置页仍然可用）。 */
  detach(): void
  dispose(): void
}

/** U5 实验使用的独立键；正式宽度键是 dsh-sidebar-size.widths.v1，实验绝不写它。 */
export const PROBE_KEY = 'dsh-sidebar-size.probe.1'

/**
 * 实验日志键：把 U3 记录到的行同时写进浏览器存储，便于实验者（或本机调试脚本）
 * 直接读取，而不必手工复述界面文本。它同样是实验键，不是正式宽度键，且只保留最近 60 行。
 */
export const PROBE_LOG_KEY = 'dsh-sidebar-size.probe.log'

/** 控制器日志键：装配、阶段、保存队列与失败原因，便于排查（同样只保留最近 60 行）。 */
export const CONTROLLER_LOG_KEY = 'dsh-sidebar-size.controller.log'

/**
 * 本次页面加载中 client 插件的装配次数。
 *
 * 模块级计数：客户端 bundle 在一次页面加载中只物化一次，因此这个数字能区分
 * “设置面板关掉又打开”（面板重挂载，计数不变）和“插件被重新装配”（计数增加）。
 * client 入口每次 apply 时调用 {@link markPluginApplied}。
 */
let applyCounter = 0

/** 记录一次 client 插件装配。 */
export function markPluginApplied(): void {
  applyCounter += 1
}

/** 读取当前装配次数。 */
function pluginApplyCount(): number {
  return applyCounter
}

/** 创建诊断面（与宿主服务无关，可先创建、后接入）。 */
export function createDiagnosticsSurface(): DiagnosticsSurface {
  const listeners = new Set<() => void>()
  const notes: string[] = []
  const controllerLog: string[] = []
  let host: DiagnosticsHost | null = null
  let hostDisposers: Disposer[] = []
  let recordingDisposers: Disposer[] = []
  const samples: string[] = []
  let recordingStartedAt = 0
  let sampleSeq = 0
  let samplesRevision = 0
  let lastPanelElementId = '—'
  const surfaceId = `surface-${Math.random().toString(36).slice(2, 8)}`
  const surfaceCreatedAt = new Date().toISOString()
  let state: DiagnosticsState = {
    capability: null,
    view: null,
    dom: null,
    prefs: null,
    keeper: null,
    lastAction: null,
    recording: false,
    samples: [],
    samplesRevision: 0,
    probe: '尚未读取',
    prefsWrite: '尚未执行',
    u2Action: '尚未执行',
    controllerLog: [],
    diagnosticsVisible: readDiagnosticsFlag(),
    structureStats: null,
    surfaceId,
    surfaceCreatedAt,
    applyCount: pluginApplyCount(),
    notes: [],
  }
  let disposed = false
  /** 诊断开关的轮询与 storage 监听（只在有订阅者时存在）。 */
  let watchTimer: ReturnType<typeof setInterval> | null = null
  let storageListener: (() => void) | null = null

  function publish(next: Partial<DiagnosticsState>): void {
    if (disposed) return
    const merged: DiagnosticsState = { ...state, ...next, samplesRevision, notes: [...notes] }
    if (sameState(state, merged)) return
    state = merged
    for (const listener of listeners) {
      try {
        listener()
      } catch (error) {
        console.warn('[dsh-sidebar-size] 诊断订阅回调抛错（已忽略）：', error)
      }
    }
  }

  function note(text: string): void {
    if (!notes.includes(text)) notes.push(text)
    publish({})
  }

  /**
   * 观察诊断开关（P11 #1）：存储键可能在面板打开期间被改动。
   *
   * 同文档内的改动（DevTools、调试脚本）**不会**触发 `storage` 事件，所以用 1s 轮询兜底；
   * 跨窗口/跨文档的改动由 `storage` 事件立即反映。轮询只在有订阅者时运行。
   */
  function syncDiagnosticsFlag(): void {
    publish({ diagnosticsVisible: readDiagnosticsFlag() })
  }

  function startDiagnosticsWatch(): void {
    if (watchTimer !== null) return
    watchTimer = setInterval(syncDiagnosticsFlag, 1000)
    const globals = globalThis as { addEventListener?: (type: string, listener: () => void) => void }
    storageListener = () => { syncDiagnosticsFlag() }
    globals.addEventListener?.('storage', storageListener)
    syncDiagnosticsFlag()
  }

  function stopDiagnosticsWatch(): void {
    if (watchTimer !== null) {
      clearInterval(watchTimer)
      watchTimer = null
    }
    if (storageListener !== null) {
      const globals = globalThis as { removeEventListener?: (type: string, listener: () => void) => void }
      globals.removeEventListener?.('storage', storageListener)
      storageListener = null
    }
  }

  function refresh(): void {
    if (disposed) return
    if (host === null) {
      publish({ capability: null, view: null, dom: null, prefs: null, keeper: null, structureStats: null })
      return
    }
    let view: HostView | null = null
    let dom: DomProbe | null = null
    try {
      view = host.bridge.readView()
      dom = host.bridge.domReport()
    } catch (error) {
      note(`读取宿主视图失败：${messageOf(error)}`)
    }
    // P12-E：结构观察器的可观测量（监听器数量、通知次数、被拒绝的登记次数）。
    let structureStats: DiagnosticsState['structureStats'] = null
    try {
      structureStats = host.bridge.structureStats()
    } catch (error) {
      note(`读取结构观察器统计失败：${messageOf(error)}`)
    }
    publish({
      capability: host.bridge.capability(),
      view,
      dom,
      prefs: host.prefs.getSnapshot(),
      keeper: host.keeper.getSnapshot(),
      structureStats,
    })
  }

  async function applyWidth(px: number): Promise<ApplyResult> {
    if (host === null) return { status: 'unavailable', requestedPx: px, reason: '宿主服务尚未就绪' }
    const result = await host.bridge.applyWidth(px)
    publish({ lastAction: { action: `应用宽度 ${px}px`, at: new Date().toISOString(), result } })
    return result
  }

  async function restoreDefault(): Promise<ApplyResult> {
    if (host === null) return { status: 'unavailable', reason: '宿主服务尚未就绪' }
    const result = await host.bridge.restoreDefault('诊断面板的显式实验动作')
    publish({ lastAction: { action: '恢复默认（数值）', at: new Date().toISOString(), result } })
    return result
  }

  function detach(): void {
    stopRecording()
    host = null
    for (const disposer of hostDisposers) {
      try {
        disposer()
      } catch {
        // 单个释放失败不影响诊断面。
      }
    }
    hostDisposers = []
    publish({ capability: null, view: null, dom: null, prefs: null, keeper: null })
  }

  /** U3 实验：把 M1 的尺寸/拖拽信号记成可读的行。 */
  function startRecording(): void {
    if (state.recording) return
    if (host === null) {
      // 不静默失败：把拒绝原因写进样本列表，界面上立刻可见。
      pushSample('记录未开始：宿主服务尚未就绪（layout / sidebarRight / configForms 未全部可用）')
      return
    }
    recordingStartedAt = Date.now()
    sampleSeq = 0
    samples.length = 0
    lastPanelElementId = '—'
    recordingDisposers = [
      host.bridge.observeWidth((sample) => pushSample(
        `#${++sampleSeq} +${Date.now() - recordingStartedAt}ms 尺寸 px=${sample.px}`
        + ` phase=${sample.phase} commit=${sample.pointerCommitSeq ?? '—'}`
        + ` gen=${sample.geometryGeneration} valid=${String(sample.valid)}`,
      )),
      host.bridge.observeDrag((signal) => pushSample(
        `#${++sampleSeq} +${Date.now() - recordingStartedAt}ms 手势 ${signal.kind}`
        + ('reason' in signal ? ` reason=${signal.reason}` : ''),
      )),
      // 结构信号只在“当前面板元素真的换了”时记一行：既拿到重绑定证据，又不会刷屏。
      host.bridge.observeStructure(() => {
        const view = host?.bridge.readView()
        const id = view?.panelIdentity?.elementId ?? '—'
        if (id === lastPanelElementId) return
        lastPanelElementId = id
        pushSample(`#${++sampleSeq} +${Date.now() - recordingStartedAt}ms 面板重绑定 ${id}`
          + ` 展示=${view?.presentation ?? '—'} 可用=${view?.availability.kind ?? '—'}`)
      }),
    ]
    samplesRevision += 1
    publish({ recording: true })
  }

  function stopRecording(): void {
    for (const disposer of recordingDisposers) {
      try {
        disposer()
      } catch {
        // 同上。
      }
    }
    recordingDisposers = []
    if (state.recording) publish({ recording: false })
  }

  function pushSample(line: string): void {
    samples.unshift(line)
    if (samples.length > 24) samples.length = 24
    samplesRevision += 1
    persistLog()
    publish({})
  }

  /** 把最近 60 行样本写入实验日志键（失败不影响功能）。 */
  function persistLog(): void {
    try {
      const storage = (globalThis as { localStorage?: Storage }).localStorage
      if (storage === undefined) return
      storage.setItem(PROBE_LOG_KEY, JSON.stringify(samples.slice(0, 60)))
    } catch {
      // 存储不可用时只影响证据留存，不影响记录本身。
    }
  }

  return {
    getSnapshot: () => state,
    subscribe(listener: () => void): Disposer {
      if (disposed) return () => {}
      listeners.add(listener)
      // 有订阅者（设置面板打开）时才开始观察诊断开关：面板关闭后不再轮询，避免常驻定时器。
      startDiagnosticsWatch()
      return () => {
        listeners.delete(listener)
        if (listeners.size === 0) stopDiagnosticsWatch()
      }
    },
    refresh,
    applyWidth,
    restoreDefault,
    startRecording,
    stopRecording,
    clearSamples(): void {
      samples.length = 0
      samplesRevision += 1
      publish({})
    },
    probeWrite(text: string): string {
      const result = withStorage((storage) => {
        storage.setItem(PROBE_KEY, text)
        return `已写入 ${PROBE_KEY} = ${text}`
      })
      publish({ probe: result })
      return result
    },
    probeRead(): string {
      const result = withStorage((storage) => {
        const value = storage.getItem(PROBE_KEY)
        return value === null ? `${PROBE_KEY} 不存在（可能已被清除，或换了存储范围）` : `读到 ${PROBE_KEY} = ${value}`
      })
      publish({ probe: result })
      return result
    },
    probeClear(): string {
      const result = withStorage((storage) => {
        storage.removeItem(PROBE_KEY)
        return `已删除 ${PROBE_KEY}`
      })
      publish({ probe: result })
      return result
    },
    async setPref(field: 'enabled' | 'perContent', value: boolean): Promise<string> {
      if (host === null) return '宿主服务尚未就绪'
      const result = await host.prefs.update({ [field]: value })
      const snapshot = host.prefs.getSnapshot()
      const line = result.ok
        ? `宿主接受 ${field}=${String(value)}；现确认值 enabled=${String(snapshot.enabled)} perContent=${String(snapshot.perContent)} revision=${String(snapshot.revision)}`
        : `写入失败：${result.reason ?? '未知原因'}`
      publish({ prefsWrite: line })
      refresh()
      return line
    },
    closeRightbar(): string {
      const ok = host?.bridge.closeRightbar() ?? false
      const line = ok ? '已调用 ctx.layout.closeRightbar()（宽度偏好应保留）' : '不可用：找不到 closeRightbar'
      publish({ u2Action: line })
      refresh()
      return line
    },
    openRightbar(fullscreen: boolean): string {
      const ok = host?.bridge.openRightbar(fullscreen) ?? false
      const line = ok
        ? `已调用 ctx.layout.openRightbar(true, ${String(fullscreen)})`
        : '不可用：找不到 openRightbar'
      publish({ u2Action: line })
      refresh()
      return line
    },
    tryResetPreferenceToNull(): string {
      const line = host?.bridge.tryResetPreferenceToNull() ?? '宿主服务尚未就绪'
      publish({ u2Action: line })
      refresh()
      return line
    },
    async setMasterEnabled(next: boolean): Promise<string> {
      if (host === null) return '宿主服务尚未就绪'
      const result = await host.keeper.setEnabled(next)
      const line = result.ok
        ? `总开关已确认 ${String(next)}；阶段 ${result.snapshot.state}`
        : `总开关写入失败：${result.reason ?? '未知原因'}`
      publish({ u2Action: line })
      refresh()
      return line
    },
    keeper(): KeeperController | null {
      return host?.keeper ?? null
    },
    async applyForCurrent(): Promise<string> {
      if (host === null) return '宿主服务尚未就绪'
      const result = await host.keeper.applyForCurrentContent()
      const line = `应用当前内容 → ${result.status}`
        + (result.requestedPx === undefined ? '' : ` (requested=${String(result.requestedPx)}`)
        + (result.observedPx === undefined ? '' : `, observed=${String(result.observedPx)}`)
        + (result.requestedPx === undefined ? '' : ')')
        + (result.resetLevel === undefined ? '' : ` resetLevel=${result.resetLevel}`)
        + (result.reason === undefined ? '' : ` reason=${result.reason}`)
      publish({ u2Action: line })
      refresh()
      return line
    },
    async restoreDefaultForCurrent(): Promise<string> {
      if (host === null) return '宿主服务尚未就绪'
      const result = await host.keeper.restoreDefaultForCurrent('诊断面板的显式数值恢复')
      const line = `数值恢复默认 → ${result.status}`
        + (result.resetLevel === undefined ? '' : ` resetLevel=${result.resetLevel}`)
        + (result.reason === undefined ? '' : ` reason=${result.reason}`)
      publish({ u2Action: line })
      refresh()
      return line
    },
    log(line: string): void {
      const stamped = `+${String(Date.now() % 100000)} ${line}`
      controllerLog.push(stamped)
      if (controllerLog.length > 60) controllerLog.shift()
      try {
        const storage = (globalThis as { localStorage?: Storage }).localStorage
        storage?.setItem(CONTROLLER_LOG_KEY, JSON.stringify(controllerLog))
      } catch {
        // 日志写入失败不影响功能。
      }
      publish({ controllerLog: [...controllerLog].slice(-6) })
    },
    logReport(): string {
      const keeper = host?.keeper.getSnapshot() ?? state.keeper
      const prefs = host?.prefs.getSnapshot() ?? state.prefs
      const capability = host?.bridge.capability() ?? state.capability
      const view = state.view
      const globals = globalThis as { navigator?: { userAgent?: string }, innerWidth?: number }
      return buildLogReport({
        pluginVersion: PLUGIN_VERSION,
        exportedAt: new Date().toISOString(),
        userAgent: globals.navigator?.userAgent ?? '',
        viewportWidth: typeof globals.innerWidth === 'number' ? globals.innerWidth : null,
        keeper,
        prefs,
        capability,
        activeTabText: describeActiveTab(keeper?.activeLabel ?? null, keeper?.activeKey ?? null),
        widthText: deriveWidthReport({ keeper, observedPx: view?.observedPx ?? null }).text,
        logLines: [...controllerLog],
      })
    },
    attach(next: DiagnosticsHost): void {
      if (disposed) return
      detach()
      host = next
      hostDisposers = [
        next.bridge.observeStructure(() => refresh()),
        next.prefs.subscribe(() => refresh()),
        next.keeper.subscribe(() => refresh()),
      ]
      refresh()
      // 实验开关：先在本机浏览器存储里把 dsh-sidebar-size.probe.autorun 设为 1，插件加载后
      // 自动开始记录，便于用调试脚本驱动输入并读取证据。默认不存在该键时行为不变。
      if (autoRunRequested()) startRecording()
    },
    detach,
    dispose(): void {
      if (disposed) return
      disposed = true
      listeners.clear()
      stopDiagnosticsWatch()
      detach()
    },
  }
}

/** 读取诊断开关（P11 #1）：只有值等于 '1' 时才渲染诊断与实验区块。 */
function readDiagnosticsFlag(): boolean {
  try {
    const storage = (globalThis as { localStorage?: Storage }).localStorage
    return diagnosticsEnabled(storage?.getItem(DIAGNOSTICS_KEY) ?? null)
  } catch {
    return false
  }
}

/** 是否由实验开关要求加载后自动开始记录。 */
function autoRunRequested(): boolean {
  try {
    const storage = (globalThis as { localStorage?: Storage }).localStorage
    return storage?.getItem('dsh-sidebar-size.probe.autorun') === '1'
  } catch {
    return false
  }
}

/** 在浏览器存储上执行一次探针操作；不可用时如实返回原因。 */
function withStorage(operation: (storage: Storage) => string): string {  try {
    const storage = (globalThis as { localStorage?: Storage }).localStorage
    if (storage === undefined) return 'localStorage 不可用'
    return operation(storage)
  } catch (error) {
    return `存储操作失败：${messageOf(error)}`
  }
}

function sameState(left: DiagnosticsState, right: DiagnosticsState): boolean {
  return left.capability === right.capability
    && left.view === right.view
    && left.dom === right.dom
    && left.prefs === right.prefs
    && left.keeper === right.keeper
    && left.lastAction === right.lastAction
    && left.recording === right.recording
    && left.samplesRevision === right.samplesRevision
    && left.probe === right.probe
    && left.prefsWrite === right.prefsWrite
    && left.u2Action === right.u2Action
    && left.controllerLog.join('|') === right.controllerLog.join('|')
    // P11 #1：诊断开关的变化必须能被发布出去，否则“免重启打开诊断块”会静默失效
    // （宿主验收曾因此失败：键改成 '1' 后界面没有任何反应）。
    && left.diagnosticsVisible === right.diagnosticsVisible
    // P12-E：结构观察器统计也要参与比较，否则“监听器数量增长”这类异常在界面上看不出来。
    && left.structureStats?.listeners === right.structureStats?.listeners
    && left.structureStats?.notifications === right.structureStats?.notifications
    && left.structureStats?.refused === right.structureStats?.refused
    && left.notes.length === right.notes.length
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

