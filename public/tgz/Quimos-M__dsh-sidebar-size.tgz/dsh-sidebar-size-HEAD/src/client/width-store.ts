/**
 * M5 WidthStore —— 宽度表的显式持久化：读取、写入、清除、故障报告与损坏原文保护。
 *
 * 职责边界：
 *   * M5 是宽度持久化的**唯一写入者**；它不拥有内存宽度表（那是 M3），也不决定内容类型；
 *   * 不做自动持久化：写入时机与顺序由 M6 的保存队列决定（因此不使用带 persist 的存储容器，
 *     避免出现第二个写入者）；
 *   * 只读原始文本，解析交给 M3；解析失败时由 M6 调用 {@link WidthStore.protect} 保留原文。
 *
 * 数据位置（实现规划 3.3）：主应用来源 `dsh-app://app/` 下的插件独占键
 * `dsh-sidebar-size.widths.v1`。物理文件由 Electron 的用户数据目录管理，不当作可复制的插件文件。
 *
 * @module dsh-sidebar-size/client/width-store
 */

import type { PersistedShape, ReadResult, StorageStatus, WidthStore, WriteOptions, WriteResult } from './contracts.ts'

/** 正式宽度键（独占；实验探针键与之分开）。 */
export const WIDTHS_KEY = 'dsh-sidebar-size.widths.v1'

/** 需要的最小存储接口；便于测试注入失败的实现。 */
export interface StorageLike {
  getItem(key: string): string | null
  setItem(key: string, value: string): void
  removeItem(key: string): void
}

/** 创建 M5 所需的依赖。 */
export interface WidthStoreDeps {
  /** 存储介质；缺省取 globalThis.localStorage。 */
  readonly storage?: StorageLike | undefined
  readonly key?: string
}

/** 创建显式宽度存储。 */
export function createWidthStore(deps: WidthStoreDeps = {}): WidthStore {
  const key = deps.key ?? WIDTHS_KEY
  let protectedRaw: string | null = null
  let protectedReason: string | undefined
  let lastError: string | undefined

  /** 取存储介质；不可用时返回 undefined。 */
  function storageOf(): StorageLike | undefined {
    if (deps.storage !== undefined) return deps.storage
    const candidate = (globalThis as { localStorage?: StorageLike }).localStorage
    return candidate
  }

  return {
    async readAll(): Promise<ReadResult> {
      const storage = storageOf()
      if (storage === undefined) {
        lastError = 'localStorage 不可用'
        return { kind: 'unavailable', reason: lastError }
      }
      try {
        const raw = storage.getItem(key)
        lastError = undefined
        if (raw === null) return { kind: 'empty' }
        return { kind: 'loaded', rawText: raw }
      } catch (error) {
        lastError = messageOf(error)
        return { kind: 'unavailable', reason: lastError }
      }
    },

    protect(rawText: string, reason: string): void {
      protectedRaw = rawText
      protectedReason = reason
    },

    async writeAll(value: PersistedShape, options: WriteOptions = {}): Promise<WriteResult> {
      if (protectedRaw !== null && options.replaceProtected !== true) {
        return { ok: false, durable: false, protected: true, reason: `原文受保护，普通写入被阻止：${protectedReason ?? '未知原因'}` }
      }
      const storage = storageOf()
      if (storage === undefined) {
        return { ok: false, durable: false, reason: 'localStorage 不可用' }
      }
      let text: string
      try {
        text = JSON.stringify(value)
      } catch (error) {
        return { ok: false, durable: false, reason: `序列化失败：${messageOf(error)}` }
      }
      try {
        storage.setItem(key, text)
      } catch (error) {
        lastError = messageOf(error)
        return { ok: false, durable: false, reason: lastError }
      }
      // 写入成功即解除保护（用户已显式替换或已成功覆盖为合法数据）。
      protectedRaw = null
      protectedReason = undefined
      lastError = undefined
      // durable 表示存储接口接受了持久化写入，不是断电级磁盘保证。
      return { ok: true, durable: true }
    },

    async clearAll(): Promise<WriteResult> {
      const storage = storageOf()
      if (storage === undefined) {
        return { ok: false, durable: false, reason: 'localStorage 不可用' }
      }
      try {
        storage.removeItem(key)
      } catch (error) {
        lastError = messageOf(error)
        // 删除失败：保留原文与保护状态，绝不报告“已清除”。
        return { ok: false, durable: false, reason: lastError, protected: protectedRaw !== null }
      }
      protectedRaw = null
      protectedReason = undefined
      lastError = undefined
      return { ok: true, durable: true }
    },

    getStatus(): StorageStatus {
      const storage = storageOf()
      const available = storage !== undefined
      return {
        available,
        writable: available,
        protected: protectedRaw !== null,
        ...lastError === undefined ? {} : { error: lastError },
        ...protectedRaw === null ? {} : { rawProblemText: protectedRaw },
      }
    },
  }
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}
