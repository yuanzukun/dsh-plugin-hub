/**
 * M6 Controller —— 根控制器：装配顺序、运行阶段、总开关与释放。
 *
 * 本阶段（P03）实现的职责：
 *   * 幂等的 `start()`：按实现规划 7.1 的顺序装配（偏好订阅 → 一次性读取宽度 → 首次确认后
 *     决定 Dormant 还是 Waiting）；
 *   * 运行阶段与就绪判断（`init` / `prefs-waiting` / `dormant` / `waiting` / `active` /
 *     `paused` / `disposed`）；
 *   * **首次确认前不改宽度**：偏好未确认时任何应用动作都被拒绝并说明原因；
 *   * 总开关关闭：增加运行代次、停止观察、执行**一次**默认清理，并如实报告恢复等级
 *     （目标版本只能做到 numeric，见决定记录 D-001）；
 *   * 幂等 `dispose()`：释放订阅、观察器与计时，之后忽略所有旧异步结果。
 *
 * 明确不在本阶段：自动保存用户拖拽（P04）、持久化保存队列（P05）、按内容的自动恢复（P06）、
 * 四项设置界面与重置/导入导出（P07）。本阶段的“应用”是**显式动作**（由设置分组里的实验按钮
 * 或后续阶段调用），不自动写入。
 *
 * @module dsh-sidebar-size/client/controller
 */

import type {
  ActiveContent,
  ApplyResult,
  ContentDescription,
  ContentKey,
  Disposer,
  DragSignal,
  HostView,
  KeeperSnapshot,
  KeeperState,
  Mode,
  ImportPreview,
  ParseError,
  PersistedShape,
  Preferences,
  PrefsSnapshot,
  WidthEntry,
  WidthSample,
  WidthStore,
  WidthTable,
} from './contracts.ts'
import { classify, describe, encodeKind, isContentKey, resolveWidth, ROOT_KIND } from './content-kind.ts'
import { isValidWidth, MIN_WIDTH } from './width-table.ts'
import { createGuard, type GuardProbe } from './guard.ts'
import type { HostCapability, DomProbe } from './host-bridge.ts'
import type { RootLifecycle } from './lifecycle.ts'

/** 控制器需要的最小宿主接入面（M1 的实现或实验替身）。 */
export interface ControllerHost {
  readView(): HostView
  observeStructure(listener: () => void): Disposer
  /** P04 起：观察手柄的真实拖拽信号。 */
  observeDrag?(listener: (signal: DragSignal) => void): Disposer
  /** P04 起：观察尺寸采样（携带指针提交窗口与几何代次）。 */
  observeWidth?(listener: (sample: WidthSample) => void): Disposer
  /** P04 起：抬起后读取宿主最终提交的尺寸。 */
  readFinalDragSample?(): Promise<WidthSample | null>
  /** E2：结构契约健康度（右栏展开却找不到面板/手柄时降级）。 */
  capability?(): HostCapability
  applyWidth(px: number): Promise<ApplyResult>
  restoreDefault(reason: string): Promise<ApplyResult>
  /**
   * P11 #2 预备应用：面板尚未渲染时把宽度偏好写好（M1 的 `preApplyWidth`）。
   * 实验替身可以不实现——缺省时预备应用整体跳过，行为与 0.1.0 一致。
   */
  preApplyWidth?(px: number): { readonly ok: boolean; readonly reason?: string }
  /** P11 #2：读取服务侧活动页签（面板未打开时也可能有值）。 */
  readServiceActiveContent?(): ActiveContent | undefined
  /** P11 #2：订阅“打开的页签清单”变化（乙级依赖 `sidebarRight.openTabs`）。 */
  observeTabs?(listener: () => void): Disposer
  dispose(): void
}

/** 创建控制器所需的依赖。 */
export interface ControllerDeps {
  readonly lifecycle: RootLifecycle
  readonly prefs: Preferences
  readonly store: WidthStore
  readonly table: WidthTable
  /** M1；宿主服务尚未就绪时可以后接入。 */
  readonly host?: ControllerHost | undefined
  /** 走标准错误输出以外的记录点（诊断面板会收集）。 */
  readonly log?: (line: string) => void
  /**
   * 手势看门狗：拖拽过程中长时间（默认 30s）收不到任何手势信号或尺寸采样时，强制结束手势并
   * 保存最后可信值。这是“不遗留永远拖拽状态”的最后一道保险（第一道是 M1 在目标被移除时发出的取消）。
   * 测试可以把它调小。
   */
  readonly gestureWatchdogMs?: number
}

/** 控制器对外的方法集合（P03 子集）。 */
export interface KeeperController {
  /** 幂等启动；返回启动完成时的快照。 */
  start(): Promise<KeeperSnapshot>
  getSnapshot(): KeeperSnapshot
  subscribe(listener: (snapshot: KeeperSnapshot) => void): Disposer
  /** 宿主服务就绪/失效时接入或摘除 M1。 */
  attachHost(host: ControllerHost): void
  detachHost(): void
  /** 总开关：经 M8 写入并等待宿主确认后才转换阶段。 */
  setEnabled(next: boolean): Promise<{ readonly ok: boolean; readonly reason?: string; readonly snapshot: KeeperSnapshot }>
  /** 显式应用动作（P03 的“固定动作”）：按当前内容应用已保存值或数值默认。 */
  applyForCurrentContent(): Promise<ApplyResult>
  /** 显式数值清理：调用宿主默认公式，报告恢复等级。 */
  restoreDefaultForCurrent(reason: string): Promise<ApplyResult>
  /** 区分内容开关（经 M8；切换流由偏好订阅统一处理）。 */
  setPerContent(next: boolean): Promise<{ readonly ok: boolean; readonly reason?: string; readonly snapshot: KeeperSnapshot }>
  /** 设置里改某个类型的宽度（只更新记录；改当前生效的那一套才立刻应用）。 */
  setWidthFor(key: ContentKey, mode: Mode, px: number): Promise<{ readonly ok: boolean; readonly reason?: string; readonly snapshot: KeeperSnapshot }>
  /** 重置已保存的宽度数据（调用方必须先完成二次确认）。 */
  resetWidths(): Promise<{ readonly ok: boolean; readonly reason?: string; readonly snapshot: KeeperSnapshot }>
  /** 导出当前合法内存表。 */
  exportWidths(): { readonly text: string; readonly dirty: boolean }
  /** 保护状态下导出未采用的原始数据；没有保护时返回 null。 */
  exportProblemData(): { readonly text: string; readonly reason: string } | null
  /** 预览导入（只校验，不改数据）。 */
  previewImport(text: string): ImportPreview
  /** 确认导入。 */
  commitImport(previewId: string): Promise<{ readonly ok: boolean; readonly reason?: string; readonly snapshot: KeeperSnapshot }>
  /** 诊断用：宿主能力报告（没有 M1 时为 null）。 */
  capability(): HostCapability | null
  domReport(): DomProbe | null
  /** 幂等释放。 */
  dispose(): Promise<void>
}

/** 模式选择：区分开关关闭时用 unified，开启时用 split。 */
function modeOf(perContent: boolean | null): Mode {
  return perContent === false ? 'unified' : 'split'
}

/**
 * 抬起后读取“宿主最终位置”的时刻（毫秒，相对 pointerup）。
 *
 * 必须在 M1 的提交窗口（`ENDING_WINDOW_MS = 400ms`）之内，否则采样的 `valid` 已经为 false、
 * 会被 M4 正确拒绝。两次采样之间让宿主完成最后一次布局提交。
 */
const ENDING_SAMPLE_DELAYS_MS = [120, 200] as const

/** 合并保存的等待时间：最后一次内存变化之后约 250ms 写一次（实现规划 0.3）。 */
const SAVE_DEBOUNCE_MS = 250

/** 高频道采样日志的最小间隔：内存逐条更新，日志最多每 500ms 一条。 */
const LOG_THROTTLE_MS = 500

/** 卸载前冲刷的时间上限：存储写入不返回时也不能让卸载挂住。 */
const UNLOAD_FLUSH_TIMEOUT_MS = 1200

export function createController(deps: ControllerDeps): KeeperController {
  const { lifecycle, prefs, store, table } = deps
  const listeners = new Set<(snapshot: KeeperSnapshot) => void>()

  let state: KeeperState = 'init'
  let host: ControllerHost | undefined = deps.host
  let prefsSnapshot: PrefsSnapshot | null = null
  let storageStatus = store.getStatus()
  let dirty = false
  let lastAction: KeeperSnapshot['lastAction'] = null
  let activeKey: ContentKey | null = null
  let activeDescription: ContentDescription | null = null
  let error: string | null = null
  let started = false
  let disposed = false
  /** 运行绑定代次：每次停用/重绑/卸载都递增，旧异步结果据此失效。 */
  let generation = 0
  /**
   * 数据修订号：每次内存表变化 +1；保存任务带着它提交，只有“写成功且修订号不比已落盘的新旧”
   * 才允许把 dirty 清掉——较旧的成功结果绝不能清除更新的内存改动。
   */
  let dataRevision = 0
  /** 最近一次成功落盘的内存修订号；-1 表示从未写过。 */
  let writtenRevision = -1
  /** 保存任务串行链：同一时刻只有一个存储写入；删除/替换也必须排在它后面。 */
  let saveChain: Promise<void> = Promise.resolve()
  /** 合并保存的计时器（最后变化后约 250ms）。 */
  let saveTimer: ReturnType<typeof setTimeout> | null = null
  /** 本次实例启动以来对宽度存储的读取次数。 */
  let storageReads = 0
  /**
   * 启动读取的结果。**只有成功读到（空或已加载）才允许写入**：读取失败时内存表是空的，
   * 若此时允许冲刷，就会用空表覆盖用户已有数据（规划要求“读取失败不谎称已加载、不写空表”）。
   */
  let readOutcome: 'pending' | 'empty' | 'loaded' | 'unavailable' = 'pending'
  let hostDisposers: Disposer[] = []
  /**
   * 正在执行/已完成的一次“总开关关闭”停止流程。
   *
   * 关闭可能来自两条路径：本插件的 `setEnabled(false)`，或用户在 DSH 自己的设置表单里改开关
   * （只会触发偏好订阅）。两条路径必须走同一段流程，且只能执行一次；重新开启后清空，
   * 使下一次关闭能再执行一次。
   */
  let stopPromise: Promise<void> | null = null
  /** M4：手势状态与来源判定。 */
  const guard: GuardProbe = createGuard()
  /** 自动恢复的去重标记：记住最近一次应用的内容键与数值。 */
  let lastAppliedKey: ContentKey | null = null
  let lastAppliedPx: number | null = null
  /** 上一次结算时正常右栏是否就绪（用于识别“重新打开”的上升沿）。 */
  let wasReady = false
  /**
   * P11 #2 / P13-B：宿主偏好当前是否**已知**与我们的记录目标一致。
   *
   * 这就是预备应用真正的闸门。早期版本用"本次页面加载中是否曾经就绪过"（`everReady`）来代替它，
   * 于是漏掉了"偏好被改坏但面板早就就绪过"的场景：停用总开关会做一次数值默认清理
   * （把宿主偏好覆盖成 DSH 默认值），重新开启时该闸门仍关着 ⇒ 记录值不会被预先写回 ⇒
   * 面板再次渲染时先显示默认值再跳变（P13 症状③）。
   *
   * 取值规则（全部显式赋值，不靠间接推断）：
   *   * 启动时为 false（偏好未知）；
   *   * 任一权威应用**成功**后为 true（见 {@link markPreferenceApplied}）；
   *   * `stopForDisabled` 的数值默认清理之后为 false（偏好已被改坏，必须在下次就绪前补写）。
   */
  let preferenceInSync = false
  /** P11 #2：最近一次预备应用的值与目标键，用于幂等去重。 */
  let lastPreApplied: { readonly px: number; readonly key: ContentKey | null } | null = null
  /**
   * P12-A：结算重入闸门。
   *
   * 观察器 API（M1）在**注册时**会通知监听器（现在改为微任务，但契约上仍可能同步），
   * 而 `settle()` 里有一句“观察器为空则重新登记”。若没有这个闸门，登记 → 同步回调 → 再 `settle()`
   * → 再登记……会形成无界互递归（P12 真机上导致渲染进程崩溃）。
   * 闸门只跳过**嵌套**调用：状态更新由最外层完成（嵌套时输入未变，结果一致）。
   */
  let settling = false
  /** P12-E：被闸门挡下的重入次数（诊断可见；稳态下应恒为 0）。 */
  let settleReentries = 0
  /** Ending 窗口的收尾计时器。 */
  let endingTimer: ReturnType<typeof setTimeout> | null = null
  /**
   * 安全执行一次宿主应用/清理：宿主服务失效、成员被移除或实现抛错都不能让插件崩掉，
   * 而要变成一条 failed 结果与可读诊断（E5/E15）。
   *
   * P13-B：权威路径写成功后，宿主偏好就与我们记录的目标一致了 ⇒ 标记 `preferenceInSync`，
   * 预备应用随之停用（避免与权威路径互相覆盖）。
   */
  async function safeHostApply(action: string, call: () => Promise<ApplyResult>): Promise<ApplyResult> {
    try {
      const result = await call()
      markPreferenceApplied(result)
      return result
    } catch (caught) {
      const reason = `${action} 抛错：${messageOf(caught)}`
      error = reason
      log(reason)
      return { status: 'failed', reason, resetLevel: 'numeric' }
    }
  }

  /** P13-B：宿主偏好已被写成已知值（只有真正写入成功才算）。 */
  function markPreferenceApplied(result: ApplyResult): void {
    if (result.status === 'applied') preferenceInSync = true
  }

  /** 安全读取宿主的结构能力报告（宿主可以是实验替身，没有 capability 就不判降级）。 */
  function safeCapability(candidate: ControllerHost): HostCapability | null {
    if (candidate.capability === undefined) return null
    try {
      return candidate.capability()
    } catch {
      return null
    }
  }

  /** 自动恢复是否正在执行（避免结构信号引发的重入）。 */
  let applyInFlight = false
  /**
   * 模式切换的代次：用户在设置里快速来回切换时，只有最后一次切换的应用结果算数。
   */
  let modeGeneration = 0
  /** 手势进行中被推迟的模式切换（手势结束后补做）。 */
  let pendingModeSwitch: boolean | null = null
  /** 导入预览：previewId → 校验结果与预览时的数据修订号。 */
  const pendingImports = new Map<string, { validated: PersistedShape | null; generation: number }>()
  let previewIdSeq = 0
  /** 本次手势接受过的采样条数与最终值（收尾时汇总一行日志，避免逐帧刷日志）。 */
  let gestureAccepted = 0
  let gestureLastPx: number | null = null
  let lastSampleLogAt = 0
  /**
   * E11：最近一次程序应用的请求值与宿主实际值。
   *
   * 若 `requestedPx !== observedPx`，说明宽度被布局约束（窗口太窄、左栏占用等）。这时**不能**
   * 把实际值当成用户意图；等框架变宽之后按同一份意图再试一次。
   */
  let lastApply: { key: ContentKey | null; mode: Mode; requestedPx: number | null; observedPx: number | null; framePx: number | null } | null = null
  /** 最近一次结算时读到的框架宽度（E11 比较用）。 */
  let currentFramePx: number | null = null
  /** 记录“因阶段/结构原因忽略采样”的最近原因，避免同一原因刷屏。 */
  let lastRejectedPhase: string | null = null
  /** 手势看门狗计时器（长时间没有任何手势信号时强制收尾）。 */
  let watchdogTimer: ReturnType<typeof setTimeout> | null = null
  /** 看门狗时长：默认 30s，测试可以调小（0 表示关闭）。 */
  const watchdogMs = deps.gestureWatchdogMs ?? 30000
  /** E2：结构契约健康度与原因（降级时暂停自动应用，但保留数据管理与用户保存）。 */
  let structureHealthy = true
  let structureNote: string | null = null

  /** 日志：既不外抛，也不影响状态。 */
  function log(line: string): void {
    try {
      deps.log?.(line)
    } catch {
      // 记录失败不影响控制器。
    }
  }

  function snapshot(): KeeperSnapshot {
    const entries: readonly WidthEntry[] = table.entries('split')
    return {
      state,
      prefsReady: prefsSnapshot?.state === 'ready',
      enabled: prefsSnapshot?.enabled ?? null,
      perContent: prefsSnapshot?.perContent ?? null,
      savedEntries: entries,
      unified: table.get('', 'unified'),
      storageStatus,
      dirty,
      storageReads,
      writtenRevision,
      memoryRevision: dataRevision,
      structureHealthy,
      structureNote,
      lastAction,
      activeKey,
      activeLabel: activeDescription?.labelFallback ?? null,
      error,
      settleReentries,
    }
  }

  function publish(): void {
    if (disposed) return
    const next = snapshot()
    for (const listener of Array.from(listeners)) {
      try {
        listener(next)
      } catch (caught) {
        log(`订阅回调抛错（已忽略）：${messageOf(caught)}`)
      }
    }
  }

  function setState(next: KeeperState, reason?: string): void {
    if (state === next) return
    log(`阶段 ${state} → ${next}${reason === undefined ? '' : `（${reason}）`}`)
    state = next
  }

  /**
   * 一次性读取宽度（实现规划 7.1 第 4 步）。与总开关无关：关闭时也要初始化内存表，
   * 之后重新开启只查内存，不再读存储。
   */
  async function readOnce(): Promise<void> {
    storageReads += 1
    const result = await store.readAll()
    storageStatus = store.getStatus()
    if (result.kind === 'empty') {
      readOutcome = 'empty'
      // 读成功即代表存储与当前内存状态一致（空表对空存储），不必再写回。
      writtenRevision = dataRevision
      dirty = false
      log('宽度存储为空：使用空表')
      return
    }
    if (result.kind === 'unavailable') {
      readOutcome = 'unavailable'
      error = `宽度存储不可用：${result.reason}（本次不会写入，避免用空表覆盖已有数据）`
      log(error)
      return
    }
    readOutcome = 'loaded'
    let parsedValue: unknown
    try {
      parsedValue = JSON.parse(result.rawText)
    } catch (caught) {
      const reason = `宽度数据不是合法 JSON：${messageOf(caught)}`
      store.protect(result.rawText, reason)
      storageStatus = store.getStatus()
      error = reason
      log(`${reason}（已保留原文，自动写入暂停）`)
      return
    }
    const parsed = table.parse(parsedValue)
    const rootError = parsed.errors.find(item => item.scope === 'root')
    if (rootError !== undefined || parsed.unsupportedVersion) {
      const reason = parsed.unsupportedVersion
        ? `宽度数据版本高于本插件支持：${rootError?.reason ?? ''}`
        : `宽度数据整体不可用：${rootError?.reason ?? '未知原因'}`
      store.protect(result.rawText, reason)
      storageStatus = store.getStatus()
      error = reason
      log(`${reason}（已保留原文，自动写入暂停）`)
      return
    }
    table.replace(parsed.table)
    // 读成功即代表“存储与这份内存内容一致”：把已落盘修订对齐，避免启动后把同一份数据原样写回。
    writtenRevision = dataRevision
    dirty = false
    if (parsed.errors.length > 0) {
      const detail = parsed.errors.map(item => `${item.key ?? '?'}: ${item.reason}`).join('；')
      log(`已剔除 ${String(parsed.errors.length)} 条非法宽度记录（${detail}）`)
    }
    log(`宽度表已加载：split ${String(table.entries('split').length)} 条，unified ${table.get('', 'unified') === null ? '未设置' : String(table.get('', 'unified'))}`)
  }

  /** 根据已确认偏好与当前宿主视图决定阶段（不改宽度）。 */
  function settle(): void {
    if (disposed) return
    // P12-A：重入闸门。观察器注册可能同步回调，没有它就会形成 settle ↔ 登记 的无界互递归。
    if (settling) {
      settleReentries += 1
      if (settleReentries === 1 || settleReentries % 50 === 0) {
        log(`结算重入被挡下（第 ${String(settleReentries)} 次）：这通常意味着有观察器在注册时同步回调`)
      }
      return
    }
    settling = true
    try {
      settleOnce()
    } finally {
      settling = false
    }
  }

  /** 结算主体：入口 {@link settle} 已负责重入保护。 */
  function settleOnce(): void {
    if (disposed) return
    if (prefsSnapshot?.state !== 'ready') {
      wasReady = false
      setState('prefs-waiting', '等待宿主设置确认值')
      publish()
      return
    }
    if (prefsSnapshot.enabled === false) {
      wasReady = false
      setState('dormant', '总开关已确认关闭')
      publish()
      return
    }
    // 已确认开启：允许下一次关闭再执行一次停止流程；观察器若在关闭时被解除，这里补回来
    // （否则重新打开总开关后插件不再观察任何东西，拖拽与保存都会静默失效）。
    stopPromise = null
    if (host !== undefined && hostDisposers.length === 0) bindHostObservers(host)
    if (host === undefined) {
      wasReady = false
      setState('waiting', '等待宿主服务')
      publish()
      return
    }
    let view: HostView
    try {
      view = host.readView()
    } catch (caught) {
      error = `读取宿主视图失败：${messageOf(caught)}`
      wasReady = false
      setState('waiting')
      publish()
      return
    }
    updateActiveContent(view)
    currentFramePx = view.framePx ?? null
    // E2：结构契约降级时暂停自动应用（数据管理与用户保存不受影响），并在日志里说明一次。
    const capability = safeCapability(host)
    const healthy = capability === null || capability.structureHealthy
    structureNote = capability?.structureNote ?? null
    if (healthy !== structureHealthy) {
      structureHealthy = healthy
      log(healthy
        ? '结构契约恢复：自动恢复继续'
        : `结构契约降级：${structureNote ?? '找不到正常右栏面板或手柄'}（自动恢复暂停）`)
    }
    if (view.availability.kind !== 'ready' || view.presentation !== 'push') {
      // 曾经就绪过就是 paused，否则仍在等待。
      wasReady = false
      setState(state === 'active' ? 'paused' : 'waiting', view.availability.kind === 'ready' ? view.presentation : view.availability.reason)
      publish()
      return
    }
    setState('active', '正常右栏就绪')
    const risingEdge = !wasReady
    wasReady = true
    publish()
    // 从内存表恢复：重新就绪的上升沿、内容变化，或（E11）窗口变大后重试被约束的宽度。
    const contentChanged = activeKey !== null && activeKey !== lastAppliedKey
    const frameRelaxed = lastApply !== null
      && lastApply.requestedPx !== null
      && lastApply.observedPx !== null
      && lastApply.requestedPx !== lastApply.observedPx
      && lastApply.framePx !== null
      && currentFramePx !== null
      && currentFramePx > lastApply.framePx
    if ((risingEdge || contentChanged || frameRelaxed) && guard.canApply()) {
      const reason = frameRelaxed && !risingEdge && !contentChanged
        ? '窗口变大，重试被布局约束的宽度'
        : risingEdge ? '正常右栏就绪' : '内容变化'
      if (frameRelaxed && !risingEdge && !contentChanged) {
        log(`窗口变大（${String(lastApply?.framePx ?? '?')} → ${String(currentFramePx ?? '?')}）：按内存意图重试 ${String(lastApply?.requestedPx ?? '?')}px`)
      }
      void applyFromMemory(reason)
    }
  }

  /**
   * 模式切换流（实现规划 4.4 / S7—S10）：
   *   * 关闭“区分内容”（切到 unified）：有统一值就恢复它；没有就请求目标版本数值默认——
   *     **不把当前类型的 split 值搬过来**；
   *   * 开启“区分内容”（切到 split）：按当前类型查 split；没有该类型记录就恢复默认——
   *     **不复制统一值**；
   *   * 两套数据在任何情况下都互不覆盖；切换瞬间就应用，不等下一次打开内容。
   */
  async function switchMode(toSplit: boolean, reason: string): Promise<void> {
    if (disposed) return
    if (!guard.canApply()) {
      pendingModeSwitch = toSplit
      log('模式切换暂缓：手势进行中，等手势结束后补做')
      return
    }
    if (host === undefined || prefsSnapshot?.enabled !== true) return
    modeGeneration += 1
    const generationAtSwitch = modeGeneration
    const saved = toSplit
      ? resolveWidth({
        key: activeKey,
        own: activeKey === null ? null : table.get(activeKey, 'split'),
        lookup: ancestor => table.get(ancestor, 'split'),
      }).value
      : table.get('', 'unified')
    lastAppliedKey = activeKey
    publish()
    const label = toSplit ? '区分内容' : '统一'
    if (saved === null) {
      if (host === undefined) return
      const result = await host.restoreDefault(`切换到${label}模式后没有可用记录（${reason}）`)
      if (disposed || generationAtSwitch !== modeGeneration) return
      record(`模式切换 → ${label} → 无记录 → 数值默认`, result)
      return
    }
    const hostAtSwitch = host
    if (hostAtSwitch === undefined) return
    const result = await safeHostApply('模式切换应用', () => hostAtSwitch.applyWidth(saved))
    if (disposed || generationAtSwitch !== modeGeneration) return
    record(`模式切换 → ${label} → 应用 ${String(saved)}px`, result)
  }

  /**
   * 按内存表应用当前内容的宽度（P04：不读也不写持久化存储）。
   *
   * 有记录就应用记录值；没有记录就请求目标版本的数值默认——这样“切到一个没有记录的类型”不会
   * 沿用上一个类型的宽度（实现规划 4.4）。程序应用不生成用户记录：M4 只接受真实手势采样。
   */
  async function applyFromMemory(reason: string): Promise<void> {
    if (disposed || applyInFlight || host === undefined || activeKey === null) return
    if (!guard.canApply()) return
    if (!structureHealthy) {
      if (lastRejectedPhase !== 'structure-degraded') {
        lastRejectedPhase = 'structure-degraded'
        log('结构契约降级：暂停自动应用，等待结构恢复')
      }
      return
    }
    // E15：宽度写入口不可访问（宿主不是预期版本、成员被移除）时停止自动应用并如实说明降级；
    // 用户拖拽的可靠保存与数据管理（导出/导入/重置）仍然可用。
    const writeCapability = safeCapability(host)
    if (writeCapability !== null && !writeCapability.canWriteWidth) {
      if (lastRejectedPhase !== 'no-write-path') {
        lastRejectedPhase = 'no-write-path'
        log('宽度写入口不可用：暂停自动应用（保存与数据管理仍可用）')
      }
      return
    }
    applyInFlight = true
    const hostAtApply = host
    try {
      const mode = modeOf(prefsSnapshot?.perContent ?? null)
      // P11 #3 / D-002：区分模式沿父链解析（本类型 → 上级 → … → 根 → 默认）；统一模式只有一份值。
      const resolution = mode === 'unified'
        ? { value: table.get('', 'unified'), origin: 'own' as const, fromKey: null }
        : resolveWidth({ key: activeKey, own: table.get(activeKey, 'split'), lookup: ancestor => table.get(ancestor, 'split') })
      const saved = resolution.value
      lastAppliedKey = activeKey
      if (saved === null) {
        const result = await safeHostApply('数值默认清理', () => hostAtApply.restoreDefault(`没有该类型的记录（${reason}）`))
        record(`自动：无记录 → 数值默认（${reason}）`, result)
        lastApply = {
          key: activeKey, mode, requestedPx: null,
          observedPx: result.observedPx ?? null, framePx: currentFramePx,
        }
        return
      }
      const result = await safeHostApply('应用宽度', () => hostAtApply.applyWidth(saved))
      if (resolution.origin === 'inherited') {
        const fromLabel = resolution.fromKey === null ? null : describe(resolution.fromKey).labelFallback
        record(`自动：应用继承值 ${String(saved)}px（继承自 ${fromLabel ?? '上级内容页'}）（${reason}）`, result)
        log(`自动应用：${activeKey} ← 继承自 ${String(resolution.fromKey)} = ${String(saved)}px，宿主实际 ${String(result.observedPx ?? '未知')}px（${reason}）`)
      } else {
        record(`自动：应用内存值 ${String(saved)}px（${reason}）`, result)
        log(`自动应用：${activeKey}（${mode}）= ${String(saved)}px，宿主实际 ${String(result.observedPx ?? '未知')}px（${reason}）`)
      }
      // E11：记下请求值与宿主实际值。若被布局约束（两者不同），窗口变大后要再试一次，
      // 而**不能**把被约束后的实际值当成用户意图写进内存表。
      lastApply = {
        key: activeKey, mode, requestedPx: saved,
        observedPx: result.observedPx ?? null, framePx: currentFramePx,
      }
    } finally {
      applyInFlight = false
    }
  }

  /** 读当前内容并分类（只更新快照，不做读写动作）。 */
  function updateActiveContent(view: HostView): void {
    const classified = classify(view.activeDockContent)
    if (classified.kind === 'keyed') {
      activeKey = classified.key
      activeDescription = describe(classified.key)
      return
    }
    activeKey = null
    activeDescription = null
  }

  /** 绑定宿主接入：清掉旧观察器、登记结构/拖拽/尺寸通知，并立即结算一次阶段。 */
  function bindHost(next: ControllerHost): void {
    for (const disposer of hostDisposers) safeCall(disposer)
    hostDisposers = []
    host = next
    generation += 1
    bindHostObservers(next)
    log('宿主接入已绑定')
    settle()
    // P12/Q2：预备应用改由显式触发点驱动（接入宿主、启动初始化、页签清单变化），
    // 不再挂在 settle() 顶部——避免每次结构事件都尝试读写偏好。
    preApply('宿主接入')
  }

  /** 只登记观察器（不含状态重置）：接入宿主、以及“关闭总开关后重新打开”时都要用到。 */
  function bindHostObservers(next: ControllerHost): void {
    hostDisposers.push(next.observeStructure(() => settle()))
    if (next.observeDrag !== undefined) hostDisposers.push(next.observeDrag(onDragSignal))
    if (next.observeWidth !== undefined) hostDisposers.push(next.observeWidth(onWidthSample))
    // P11 #2：页签清单变化通常发生在“该会话的 store 刚被实例化/播种”时，早于用户第一次展开右栏，
    // 因此这是预备应用最可靠的触发点。
    if (next.observeTabs !== undefined) hostDisposers.push(next.observeTabs(() => preApply('页签清单变化')))
  }

  /**
   * P11 #2 预备应用：在用户第一次展开右栏**之前**，把该会话的目标宽度偏好写好。
   *
   * 为什么需要它：宿主的宽度偏好是纯内存的，且 `openRightbar` 只在偏好为 null 时算一次默认值
   * （`??=`）。因此“等面板就绪再应用”必然晚于首帧，用户会看到先撑到默认再跳回记录值。
   * 这里在面板未渲染时就写入偏好，让首帧直接用我们的值。
   *
   * 边界：
   *   * 拿到宿主设置确认值之前绝不写（沿用冻结的首次确认闸门）；
   *   * 总开关关闭时不写；
   *   * 只在该次页面加载中“面板从未就绪过”时执行——面板就绪后由权威路径负责；
   *   * 链上没有记录时不写（宿主自己会算默认值，写了没有意义）；
   *   * 同一目标只写一次（幂等），避免与权威路径互相覆盖刷屏。
   *
   * @param reason - 触发来源，写进日志便于排查。
   */
  function preApply(reason: string): void {
    if (disposed || host === undefined) return
    if (prefsSnapshot === null || prefsSnapshot.state !== 'ready') return
    if (prefsSnapshot.enabled === false) return
    // P13-B：只有"偏好已知与记录一致"时才跳过；偏好被改坏（启动、停用清理后）必须补写。
    if (preferenceInSync) return
    if (host.preApplyWidth === undefined) return
    if (!guard.canApply()) return

    const mode = modeOf(prefsSnapshot.perContent)
    const serviceTab = host.readServiceActiveContent?.()
    const classified = serviceTab === undefined ? null : classify(serviceTab)
    let target: number | null
    let source: string
    let key: ContentKey | null = null

    if (classified !== null && classified.kind === 'keyed') {
      key = classified.key
      if (mode === 'unified') {
        target = table.get('', 'unified')
        source = '统一值'
      } else {
        const resolution = resolveWidth({
          key: classified.key,
          own: table.get(classified.key, 'split'),
          lookup: ancestor => table.get(ancestor, 'split'),
        })
        target = resolution.value
        source = resolution.origin === 'inherited'
          ? `继承自 ${describe(resolution.fromKey ?? '').labelFallback}`
          : '本类型记录'
      }
    } else {
      // 读不到活动页签（例如该会话从未打开过右栏）：用根记录兜底——展开时宿主会播种默认页
      // （引导页），因此根记录正是首帧该用的值。
      const rootKey = encodeKind(ROOT_KIND)
      if (mode === 'unified') {
        target = table.get('', 'unified')
        source = '统一值（无活动页签）'
      } else {
        target = rootKey === null ? null : table.get(rootKey, 'split')
        source = '根记录（无活动页签）'
      }
      key = rootKey
    }

    if (target === null) return
    if (lastPreApplied !== null && lastPreApplied.px === target && lastPreApplied.key === key) return

    const result = host.preApplyWidth(target)
    if (!result.ok) {
      log(`预备应用失败：${result.reason ?? '未知原因'}`)
      return
    }
    lastPreApplied = { px: target, key }
    log(`预备应用：${key ?? '（无活动页签）'} = ${String(target)}px（${source}；${reason}）`)
  }

  /**
   * 手柄信号：按下时固定本次手势的归属（内容键与模式），抬起/取消交给 M4 决定阶段。
   * 归属在按下时确定，因此手势中切换内容不会把宽度写到新类型上。
   */
  function onDragSignal(signal: DragSignal): void {
    if (disposed || host === undefined) return
    if (signal.kind === 'pointer-down') {
      const view = safeView(host)
      if (view === null) return
      const classified = classify(view.activeDockContent)
      if (classified.kind !== 'keyed') {
        log('拖拽按下被忽略：读不到可靠的活动内容类型')
        return
      }
      const mode = modeOf(prefsSnapshot?.perContent ?? null)
      const started = guard.beginDrag({
        pointerId: signal.pointerId,
        panelIdentity: signal.panelIdentity,
        sessionId: view.sessionId,
        paneId: view.activeDockContent?.paneId ?? '',
        tabId: view.activeDockContent?.tabId ?? '',
        key: classified.key,
        mode,
        generation,
      })
      if (started === 'accepted') armWatchdog()
      log(started === 'accepted' ? `手势开始：${classified.key}（模式 ${mode}）` : '手势被忽略：已有手势在进行')
      return
    }

    guard.beginEnding(signal)
    armWatchdog()
    if (signal.kind === 'pointer-up' || signal.kind === 'capture-released') scheduleEndingSample()
    if (signal.kind === 'cancelled') {
      clearEndingTimer()
      log(`手势取消：${signal.reason}`)
    }
    publish()
  }

  /** 尺寸采样：交给 M4 判断来源；被接受才写入内存表，并按 250ms 合并落盘。 */
  function onWidthSample(sample: WidthSample): void {
    if (disposed) return
    armWatchdog()
    // E13/E14：只有“正常右栏”期间才接受用户采样。全屏、折叠、面板解算为 0 或不可用期间一律
    // 暂停保存——否则一次全屏拖拽就会把 100vw 级的宽度写成这个类型的记忆。
    if (state !== 'active') {
      if (lastRejectedPhase !== state) {
        lastRejectedPhase = state
        log(`采样被忽略：当前不是正常右栏（阶段 ${state}），暂停保存`)
      }
      return
    }
    const accepted = guard.acceptSample(sample)
    if (accepted === null) return
    if (accepted.generation !== generation) return
    const result = table.set(accepted.key, accepted.mode, accepted.px)
    if (result === 'changed') {
      dataRevision += 1
      dirty = writtenRevision !== dataRevision
      gestureAccepted += 1
      gestureLastPx = accepted.px
      // 高频采样不逐帧写日志：第一条与之后每 LOG_THROTTLE_MS 最多一条，收尾时再汇总一次。
      const now = Date.now()
      if (gestureAccepted === 1 || now - lastSampleLogAt >= LOG_THROTTLE_MS) {
        lastSampleLogAt = now
        log(`内存表更新：${accepted.key}（${accepted.mode}）= ${String(accepted.px)}px（修订 ${String(dataRevision)}，本手势第 ${String(gestureAccepted)} 次）`)
      }
      publish()
      scheduleSave('采样合并')
    }
  }

  /**
   * 合并保存：最后一次内存变化之后约 250ms 写一次完整表快照；手势结束立即冲刷。
   * 写入始终串行（同一时刻只有一次存储写入）。
   */
  function scheduleSave(reason: string): void {
    if (disposed) return
    if (saveTimer !== null) clearTimeout(saveTimer)
    saveTimer = setTimeout(() => {
      saveTimer = null
      void flushSave(reason)
    }, SAVE_DEBOUNCE_MS)
  }

  /** 立即保存当前内存表快照（取消等待中的合并计时）。 */
  function flushSave(reason: string): Promise<void> {
    if (saveTimer !== null) {
      clearTimeout(saveTimer)
      saveTimer = null
    }
    // 捕获“本次要写的修订号与内容”：之后的新改动会带着更大的修订号进入下一次任务。
    const revision = dataRevision
    const value = table.serialize()
    saveChain = saveChain.then(async () => {
      if (readOutcome === 'pending' || readOutcome === 'unavailable') {
        log(`保存跳过：宽度数据尚未成功读取（${reason}）`)
        return
      }
      if (storageStatus.protected) {
        log(`保存跳过：原文处于保护状态（${reason}）`)
        return
      }
      // 空表不写：既避免无意义的键，也避免在“记录被清空”的场景下用空表覆盖旧数据
      // （清空是 M5.clearAll 的职责，不是写一张空表）。
      if (Object.keys(value.split).length === 0 && value.unified === null) {
        log(`保存跳过：内存表为空（${reason}）`)
        return
      }
      if (revision <= writtenRevision) {
        log(`保存跳过：修订 ${String(revision)} 已经落盘`)
        return
      }
      const result = await store.writeAll(value)
      storageStatus = store.getStatus()
      if (result.ok) {
        // 旧的成功结果不能清除更新的内存改动。
        if (revision > writtenRevision) writtenRevision = revision
        if (result.protected !== true) error = null
        log(`保存成功：修订 ${String(revision)}（${reason}）`)
      } else {
        error = `保存失败：${result.reason ?? '未知原因'}`
        log(`${error}（内存与内存表保留，稍后可重试）`)
      }
      dirty = writtenRevision !== dataRevision
      publish()
      // 写入期间又产生了新改动：再排一次（不会无限循环：内存稳定后就不再排）。
      if (dirty && !disposed && !storageStatus.protected) scheduleSave('写入期间又有改动')
    })
    return saveChain
  }

  /** 抬起后读取宿主最终提交的尺寸：必须在 M1 的提交窗口内（默认 400ms）。 */
  function scheduleEndingSample(): void {
    clearEndingTimer()
    if (host === undefined || host.readFinalDragSample === undefined) {
      guard.finishDrag()
      return
    }
    const scheduleGeneration = generation
    let index = 0
    const step = (): void => {
      if (disposed || generation !== scheduleGeneration) return
      void (async () => {
        const sample = await host?.readFinalDragSample?.() ?? null
        if (sample !== null) onWidthSample(sample)
        index += 1
        if (index < ENDING_SAMPLE_DELAYS_MS.length) {
          endingTimer = setTimeout(step, ENDING_SAMPLE_DELAYS_MS[index] as number)
          return
        }
        // 最后一次收尾采样之后再结束手势：此后的尺寸变化都不属于这次提交。
        guard.finishDrag()
        clearWatchdog()
        endingTimer = null
        if (gestureAccepted > 0) {
          log(`手势结束：共接受 ${String(gestureAccepted)} 条合法采样，最终 ${String(gestureLastPx)}px`)
          gestureAccepted = 0
          gestureLastPx = null
        }
        publish()
        // 手势结束立即冲刷：把本次拖拽的最终值落盘，不等合并计时。
        void flushSave('手势结束')
        // 手势期间被推迟的模式切换在这里补做。
        if (pendingModeSwitch !== null) {
          const next = pendingModeSwitch
          pendingModeSwitch = null
          void switchMode(next, '手势结束后补做模式切换')
        }
      })()
    }
    endingTimer = setTimeout(step, ENDING_SAMPLE_DELAYS_MS[0] as number)
  }

  function clearEndingTimer(): void {
    if (endingTimer === null) return
    clearTimeout(endingTimer)
    endingTimer = null
  }

  /**
   * 手势看门狗：只要还有手势在进行，就不断续期；长时间完全没有信号（例如目标被移除、
   * 宿主停止派发事件）时强制结束手势并冲刷最后可信值，保证不会遗留永远拖拽的状态。
   */
  function armWatchdog(): void {
    if (disposed || watchdogMs <= 0) return
    if (watchdogTimer !== null) clearTimeout(watchdogTimer)
    watchdogTimer = setTimeout(() => {
      watchdogTimer = null
      if (disposed || guard.phase() === 'idle') return
      log(`手势看门狗：${String(watchdogMs)}ms 内没有收到任何手势信号，结束手势并保存最后可信值`)
      guard.cancel('watchdog')
      publish()
      void flushSave('手势看门狗')
    }, watchdogMs)
  }

  function clearWatchdog(): void {
    if (watchdogTimer === null) return
    clearTimeout(watchdogTimer)
    watchdogTimer = null
  }

  return {
    async start(): Promise<KeeperSnapshot> {
      if (disposed) return snapshot()
      if (started) return snapshot()
      started = true
      log('控制器启动')

      // 1) 偏好订阅：先订阅再读，避免错过首次确认。
      const stopPrefs = prefs.subscribe((next) => {
        const previous = prefsSnapshot
        prefsSnapshot = next
        if (next.state === 'ready' && (previous?.enabled !== next.enabled || previous?.perContent !== next.perContent)) {
          log(`设置确认值更新：enabled=${String(next.enabled)} perContent=${String(next.perContent)}`)
        }
        // 用户在设置里切换“区分内容”开关：两套记忆互不复制，切换后立刻应用对应的一套。
        if (next.state === 'ready' && next.perContent !== null
          && previous?.state === 'ready' && previous.perContent !== null
          && previous.perContent !== next.perContent) {
          void switchMode(next.perContent, '设置里的区分内容开关发生变化')
        }
        // 用户可能在 DSH 自己的设置表单里关闭总开关：这条路径同样要停止观察并做一次默认清理。
        if (next.state === 'ready' && next.enabled === false && previous?.enabled !== false) {
          void stopForDisabled('总开关确认关闭')
          return
        }
        settle()
      })
      lifecycle.addDisposer(stopPrefs, 'prefs subscription')

      // 2) 一次性读取宽度（与总开关无关）。
      await readOnce()
      if (disposed) return snapshot()

      // 3) 如果宿主是构造时就传进来的，这里补上结构观察器（否则阶段永远不会随面板就绪推进）。
      if (host !== undefined && hostDisposers.length === 0) bindHost(host)

      // 4) 首次确认值：可能已经在快照里（ensure 会等到 ready 或超时）。
      prefsSnapshot = await prefs.ensure()
      if (disposed) return snapshot()
      settle()
      preApply('启动初始化')
      publish()
      return snapshot()
    },

    getSnapshot: snapshot,

    subscribe(listener: (snapshot: KeeperSnapshot) => void): Disposer {
      if (disposed) return () => {}
      listeners.add(listener)
      return () => {
        listeners.delete(listener)
      }
    },

    attachHost(next: ControllerHost): void {
      if (disposed) return
      bindHost(next)
    },

    detachHost(): void {
      for (const disposer of hostDisposers) safeCall(disposer)
      hostDisposers = []
      host = undefined
      generation += 1
      // 摘除接入等同于“右栏不再可用”：必须复位就绪标记，替换宿主后才会重新应用；
      // 若正处在拖拽中也要结束手势，否则永远停在 dragging（与关闭总开关同一类问题）。
      wasReady = false
      if (guard.phase() !== 'idle') {
        log(`宿主接入被摘除时仍有手势在进行（${guard.phase()}）：结束手势并保存最后可信值`)
        guard.cancel('宿主接入被摘除')
        clearEndingTimer()
        clearWatchdog()
      }
      if (!disposed) {
        setState(prefsSnapshot?.enabled === false ? 'dormant' : 'waiting', '宿主接入已摘除')
        publish()
      }
    },

    async setEnabled(next: boolean): Promise<{ ok: boolean; reason?: string; snapshot: KeeperSnapshot }> {
      if (disposed) return { ok: false, reason: '控制器已卸载', snapshot: snapshot() }
      const result = await prefs.update({ enabled: next })
      prefsSnapshot = result.snapshot
      if (!result.ok) {
        publish()
        return { ok: false, reason: result.reason, snapshot: snapshot() }
      }
      if (!next) await stopForDisabled('总开关关闭')
      else {
        settle()
        // 重新开启时若面板还没就绪过，这里把记录值先写进宿主偏好（已在就绪后由权威路径负责）。
        preApply('重新开启总开关')
      }
      publish()
      return { ok: true, snapshot: snapshot() }
    },

    async applyForCurrentContent(): Promise<ApplyResult> {
      const current = snapshot()
      if (current.state === 'disposed') return { status: 'unavailable', reason: '控制器已卸载' }
      if (current.state === 'prefs-waiting' || prefsSnapshot?.state !== 'ready') {
        return { status: 'deferred', reason: '设置尚未确认：本插件在拿到宿主确认值之前不改宽度' }
      }
      if (host === undefined) return { status: 'unavailable', reason: '宿主服务尚未就绪' }
      const view = host.readView()
      updateActiveContent(view)
      if (view.presentation !== 'push') {
        publish()
        return { status: 'deferred', reason: `当前不是正常停靠展示（${view.presentation}），暂不写入` }
      }
      const mode = modeOf(prefsSnapshot.perContent)
      if (activeKey === null) {
        publish()
        return { status: 'deferred', reason: '读不到可靠的活动内容类型，暂不写入' }
      }
      const resolution = mode === 'unified'
        ? { value: table.get('', 'unified'), origin: 'own' as const, fromKey: null }
        : resolveWidth({ key: activeKey, own: table.get(activeKey, 'split'), lookup: ancestor => table.get(ancestor, 'split') })
      const saved = resolution.value
      if (saved === null) {
        // 没有记录：按目标版本默认恢复（数值），不把默认值写进表。
        const result = await host.restoreDefault('当前类型没有记录')
        markPreferenceApplied(result)
        record('无记录 → 数值默认', result)
        return result
      }
      const result = await host.applyWidth(saved)
      markPreferenceApplied(result)
      record(
        resolution.origin === 'inherited'
          ? `应用继承值 ${String(saved)}px（继承自 ${describe(resolution.fromKey ?? '').labelFallback}）`
          : `应用已保存值 ${String(saved)}px`,
        result,
      )
      return result
    },

    async restoreDefaultForCurrent(reason: string): Promise<ApplyResult> {
      if (host === undefined) return { status: 'unavailable', reason: '宿主服务尚未就绪' }
      const result = await host.restoreDefault(reason)
      markPreferenceApplied(result)
      record('显式数值恢复默认', result)
      return result
    },

    /** 区分内容开关：写入经 M8，切换流由偏好订阅统一处理（单一变更入口）。 */
    async setPerContent(next: boolean): Promise<{ ok: boolean; reason?: string; snapshot: KeeperSnapshot }> {
      if (disposed) return { ok: false, reason: '控制器已卸载', snapshot: snapshot() }
      const result = await prefs.update({ perContent: next })
      prefsSnapshot = result.snapshot
      publish()
      return { ok: result.ok, ...result.reason === undefined ? {} : { reason: result.reason }, snapshot: snapshot() }
    },

    /**
     * 在设置里改某个类型的宽度（下拉 + 数值 + 保存）。
     * 只更新记录；若改的正是当前生效的那一套，才立刻请求应用。
     */
    async setWidthFor(key: ContentKey, mode: Mode, px: number): Promise<{ ok: boolean; reason?: string; snapshot: KeeperSnapshot }> {
      if (disposed) return { ok: false, reason: '控制器已卸载', snapshot: snapshot() }
      if (!isValidWidth(px)) return { ok: false, reason: `宽度必须是 ≥ ${String(MIN_WIDTH)} 的整数`, snapshot: snapshot() }
      if (mode === 'split' && !isContentKey(key)) return { ok: false, reason: '请选择要修改的内容类型', snapshot: snapshot() }

      if (table.set(key, mode, px) === 'rejected') {
        // 与已保存值相同：不产生改动，也不需要落盘。
        return { ok: true, snapshot: snapshot() }
      }
      dataRevision += 1
      dirty = writtenRevision !== dataRevision
      publish()
      scheduleSave('设置里改值')

      const currentMode = modeOf(prefsSnapshot?.perContent ?? null)
      // P11 #3 / Q21：“当前生效的那一套”现在还包括“当前内容正在继承的那一条”。
      // 判定用同一个解析函数：改完之后若当前内容的解析来源正好是刚改的键，就立即应用。
      const resolutionAfterEdit = currentMode === 'split' && activeKey !== null
        ? resolveWidth({ key: activeKey, own: table.get(activeKey, 'split'), lookup: ancestor => table.get(ancestor, 'split') })
        : null
      const effective = mode === currentMode && (
        mode === 'unified'
        || key === activeKey
        || (resolutionAfterEdit !== null && resolutionAfterEdit.origin === 'inherited' && resolutionAfterEdit.fromKey === key)
      )
      if (effective && host !== undefined && guard.canApply()) {
        const hostAtEdit = host
        const result = await safeHostApply('设置改值应用', () => hostAtEdit.applyWidth(px))
        if (activeKey !== null) lastAppliedKey = activeKey
        record(`设置改值 → 应用 ${String(px)}px`, result)
      }
      log(`设置改值：${key}（${mode}）= ${String(px)}px${effective ? '（当前生效，已请求应用）' : '（仅更新记录）'}`)
      return { ok: true, snapshot: snapshot() }
    },

    /**
     * 重置已保存的宽度数据（对应设置里的重置按钮；调用方必须先完成二次确认）。
     *
     * 顺序：取消等待中的合并保存 → 等已排队的写入结束 → 删除存储键 → 清空内存表 →
     * 对齐已落盘修订 → 请求一次数值默认。删除失败时数据保持不变并如实报告。
     */
    async resetWidths(): Promise<{ ok: boolean; reason?: string; snapshot: KeeperSnapshot }> {
      if (disposed) return { ok: false, reason: '控制器已卸载', snapshot: snapshot() }
      if (saveTimer !== null) {
        clearTimeout(saveTimer)
        saveTimer = null
      }
      try {
        await saveChain
      } catch {
        // 之前的写入失败不影响删除。
      }
      const cleared = await store.clearAll()
      storageStatus = store.getStatus()
      if (!cleared.ok) {
        error = `重置失败：${cleared.reason ?? '未知原因'}（数据保持不变）`
        publish()
        return { ok: false, reason: error, snapshot: snapshot() }
      }
      table.clearAll()
      dataRevision += 1
      writtenRevision = dataRevision
      dirty = false
      error = null
      modeGeneration += 1
      lastAppliedKey = null
      pendingImports.clear()
      publish()

      let result: ApplyResult = { status: 'deferred', reason: '宿主服务尚未就绪' }
      if (host !== undefined) {
        const hostAtReset = host
        result = await safeHostApply('重置清理', () => hostAtReset.restoreDefault('重置已保存的宽度数据'))
        record('重置 → 数值默认', result)
        // 防止紧接着的重新结算把这次默认当成“内容变化”再应用一次（那样也会覆盖上面的动作记录）。
        lastAppliedKey = activeKey
      }
      log(`重置完成：已清除宽度数据，恢复等级 ${result.resetLevel ?? '未执行'}`)
      return { ok: true, snapshot: snapshot() }
    },

    /** 导出当前合法内存表（不修改存储，也不解除保护）。 */
    exportWidths(): { text: string; dirty: boolean } {
      return { text: JSON.stringify(table.serialize(), null, 2), dirty }
    },

    /** 只在保护状态下提供“未采用的原始数据”供另存；没有保护时为 null。 */
    exportProblemData(): { text: string; reason: string } | null {
      const status = store.getStatus()
      if (!status.protected || status.rawProblemText === undefined) return null
      return { text: status.rawProblemText, reason: status.error ?? '原文未通过校验' }
    },

    /**
     * 预览导入：只校验与汇总，不改动任何数据；返回的 previewId 在数据发生变化后失效。
     */
    previewImport(text: string): ImportPreview {
      previewIdSeq += 1
      const previewId = `preview-${String(previewIdSeq)}`
      const errors: ParseError[] = []
      let unsupportedVersion = false
      let splitKeys: ContentKey[] = []
      let unified: number | null = null
      let validated: PersistedShape | null = null
      try {
        const parsed = table.parse(JSON.parse(text) as unknown)
        errors.push(...parsed.errors)
        unsupportedVersion = parsed.unsupportedVersion
        const fatal = unsupportedVersion || parsed.errors.some(item => item.scope === 'root')
        if (!fatal) {
          validated = parsed.table
          splitKeys = Object.keys(parsed.table.split).sort()
          unified = parsed.table.unified
        }
      } catch (caught) {
        errors.push({ scope: 'root', reason: `不是合法 JSON：${messageOf(caught)}` })
      }
      // 只保留最近 3 份预览，避免无界增长。
      pendingImports.set(previewId, { validated, generation: dataRevision })
      while (pendingImports.size > 3) {
        const oldest = pendingImports.keys().next().value
        if (oldest === undefined) break
        pendingImports.delete(oldest)
      }
      log(`导入预览 ${previewId}：${validated === null ? '未通过校验' : `split ${String(splitKeys.length)} 条`}${unsupportedVersion ? '（版本不受支持）' : ''}`)
      return { previewId, splitKeys, unified, errors, unsupportedVersion }
    },

    /** 确认导入：把预览里通过校验的表替换进内存并落盘（显式替换可覆盖受保护原文）。 */
    async commitImport(previewId: string): Promise<{ ok: boolean; reason?: string; snapshot: KeeperSnapshot }> {
      if (disposed) return { ok: false, reason: '控制器已卸载', snapshot: snapshot() }
      const pending = pendingImports.get(previewId)
      if (pending === undefined) return { ok: false, reason: '预览不存在或已过期，请重新预览', snapshot: snapshot() }
      if (pending.generation !== dataRevision) {
        return { ok: false, reason: '预览之后数据发生了变化，请重新预览再确认', snapshot: snapshot() }
      }
      if (pending.validated === null) {
        return { ok: false, reason: '这份数据没有通过校验，不能导入；可以改用“导出诊断原文”保留它', snapshot: snapshot() }
      }
      // E20：替换之前先取消等待中的合并保存，并等已经在飞的写入结束——否则旧快照可能在替换之后落盘。
      if (saveTimer !== null) {
        clearTimeout(saveTimer)
        saveTimer = null
      }
      try {
        await saveChain
      } catch {
        // 旧写入失败不影响这次替换。
      }
      table.replace(pending.validated)
      dataRevision += 1
      dirty = writtenRevision !== dataRevision
      publish()

      const write = await store.writeAll(table.serialize(), { replaceProtected: true })
      storageStatus = store.getStatus()
      if (write.ok) {
        writtenRevision = dataRevision
        dirty = false
        error = null
        log('导入已写入（受保护原文被显式替换）')
      } else {
        error = `导入写入失败：${write.reason ?? '未知原因'}`
        log(error)
      }
      publish()
      lastAppliedKey = null
      await applyFromMemory('导入之后')
      pendingImports.delete(previewId)
      return { ok: write.ok, ...write.ok ? {} : { reason: error ?? '写入失败' }, snapshot: snapshot() }
    },

    capability(): HostCapability | null {
      const candidate = host as { capability?: () => HostCapability } | undefined
      return candidate?.capability?.() ?? null
    },

    domReport(): DomProbe | null {
      const candidate = host as { domReport?: () => DomProbe } | undefined
      return candidate?.domReport?.() ?? null
    },

    async dispose(): Promise<void> {
      if (disposed) return
      // 卸载前尽力冲刷已接受但未落盘的改动（失败只记录，不阻塞释放）。
      // 存储写入可能永远不返回（配额告警、引擎挂起）：用时间上限保证卸载不会被它拖住。
      try {
        await Promise.race([
          flushSave('卸载前冲刷'),
          new Promise<void>((resolve) => { setTimeout(resolve, UNLOAD_FLUSH_TIMEOUT_MS) }),
        ])
      } catch (caught) {
        log(`卸载前冲刷失败（已忽略）：${messageOf(caught)}`)
      }
      disposed = true
      generation += 1
      modeGeneration += 1
      pendingModeSwitch = null
      clearEndingTimer()
      clearWatchdog()
      if (saveTimer !== null) {
        clearTimeout(saveTimer)
        saveTimer = null
      }
      guard.finishDrag()
      for (const disposer of hostDisposers) safeCall(disposer)
      hostDisposers = []
      host = undefined
      listeners.clear()
      setState('disposed', '释放')
      log('控制器已释放')
    },
  }

  /** 记录一次动作结果，供设置分组显示。 */
  function record(action: string, result: ApplyResult): void {
    lastAction = { action, at: new Date().toISOString(), result }
    publish()
  }

  /**
   * 总开关关闭时的停止流程（实现规划 7.3）：幂等，两条关闭路径共用。
   *   1) 增加运行代次；
   *   2) 结束时仍持有宿主接入时执行**一次**默认清理，并记录恢复等级；
   *   3) 解除观察，进入 Dormant（保留设置入口与内存表）。
   * 目标版本没有公开的重置动作，因此清理只能是 numeric（决定记录 D-001）。
   */
  function stopForDisabled(reason: string): Promise<void> {
    if (disposed) return Promise.resolve()
    if (stopPromise !== null) return stopPromise
    stopPromise = (async () => {
      generation += 1
      const hostAtStop = host
      // 先停止观察并进入 Dormant：界面与阶段不应等落盘。
      for (const disposer of hostDisposers) safeCall(disposer)
      hostDisposers = []
      // P13-A：停用与"摘除宿主接入"同类——对上层都意味着右栏不再可用，必须复位就绪标记
      // （对照 controller.ts 里 detachHost 的同一处理）。否则重新开启时 settleOnce 的
      // `risingEdge` 为 false，而 contentChanged/frameRelaxed 也不成立 ⇒ 记录值永远不会被重新应用，
      // 用户可见症状是"重开总开关后宽度停在停用时的默认清理值，必须关掉再打开右栏才恢复"。
      wasReady = false
      // 关闭时若正处在拖拽中，必须把这次手势结束掉：否则 M4 会一直停在 dragging，
      // 重新打开总开关后自动应用永远被拦（与“目标被移除”同一类问题）。
      if (guard.phase() !== 'idle') {
        log(`总开关关闭时仍有手势在进行（${guard.phase()}）：结束手势并保存最后可信值`)
        guard.cancel('总开关关闭')
      }
      clearEndingTimer()
      clearWatchdog()
      setState('dormant', reason)
      publish()

      // 已经把用户拖拽捕获下来的记录要收尾保存（旧归属、仍然合法）。
      try {
        await flushSave('总开关关闭前冲刷')
      } catch (caught) {
        log(`关闭前冲刷失败（已忽略）：${messageOf(caught)}`)
      }

      if (hostAtStop === undefined) {
        log('总开关关闭：没有可用的宿主接入，跳过默认清理')
        return
      }
      const view = safeView(hostAtStop)
      if (view === null || view.presentation !== 'push') {
        const result: ApplyResult = {
          status: 'deferred',
          resetLevel: 'numeric',
          reason: `关闭时右栏不是正常停靠展示（${view?.presentation ?? '读不到'}），暂不执行默认清理`,
        }
        record('总开关关闭 → 默认清理（暂不可写）', result)
        log(`总开关关闭：${result.reason ?? ''}`)
        return
      }
      // 清理也可能抛错（宿主服务失效）：如实报告，不让关闭流程或后续流程被异常打断。
      let result: ApplyResult
      try {
        result = await hostAtStop.restoreDefault('总开关关闭')
      } catch (caught) {
        result = { status: 'failed', resetLevel: 'numeric', reason: `默认清理抛错：${messageOf(caught)}` }
      }
      record('总开关关闭 → 数值默认清理', result)
      if (result.status === 'failed') {
        error = result.reason ?? '默认清理失败'
        log(`总开关关闭：${error}`)
      } else {
        log(`总开关关闭：默认清理结果 ${result.status}，恢复等级 ${result.resetLevel ?? '未知'}`)
      }
      // P13-B：这次清理把宿主偏好写成了 DSH 默认值（与记录不同），因此"偏好已同步"必须复位；
      // 重新开启时预备应用会先把记录值写回偏好，面板下次渲染的首帧即正确（不再跳变）。
      //
      // 同时必须清掉预备应用的幂等去重：启动时可能已经用同一个目标值写过一次偏好，
      // 而这次清理已经把它改坏——只清 `preferenceInSync` 而不清去重，重开时会被误判为
      // “这个值写过了”从而跳过补写，症状③（首帧默认值再跳变）仍会复现。
      preferenceInSync = false
      lastPreApplied = null
    })()
    return stopPromise
  }

  function safeView(candidate: ControllerHost): HostView | null {
    try {
      return candidate.readView()
    } catch {
      return null
    }
  }
}

function safeCall(disposer: Disposer): void {
  try {
    disposer()
  } catch (error) {
    try {
      console.warn('[dsh-sidebar-size] 释放回调抛错（已忽略）：', error)
    } catch {
      // 保持静默。
    }
  }
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}


