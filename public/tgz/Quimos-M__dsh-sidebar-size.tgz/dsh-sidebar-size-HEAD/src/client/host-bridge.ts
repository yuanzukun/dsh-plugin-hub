/**
 * M1 HostBridge —— 宿主接入适配器（P02 实验级实现）。
 *
 * 职责：定位真实的正常右栏、测量几何、读取当前停靠内容、观察结构与尺寸变化，并在宿主
 * **确实存在**宽度写入口时执行写入。本文件不保存宽度、不决定分类键、不判断手势来源
 * （那是 M3/M4/M6 的职责）。
 *
 * 关于依赖等级（依据固定版本类型核验，见 docs/源码核验-四包公共API.md）：
 *   * 甲级：`ctx.sidebarRight.mounted/isExpanded/active`、`ctx.layout.panelInfo` 等公开成员；
 *   * 乙级：宽度写入。**公共 API 里没有任何写右栏宽度的入口**——`ctx.layout` 只有
 *     `panelInfo/selectPanel/beginNavigation/toggleSidebar/openRightbar/closeRightbar`；
 *     `setRightbar` 只存在于未导出的 layout store actions，挂载在 `LayoutController.panels`
 *     （TS `private`，运行时仍是普通属性）。因此这里只做**能力检测 + 显式调用 + 失败隔离**，
 *     任何一步不成立就如实报告 `unavailable`，绝不改 DOM 样式、不模拟指针事件；
 *   * 丙级：DOM 属性（`data-rightbar-col`、`[data-side="rightbar"]`、
 *     `[data-sidebar-right-panel][data-sidebar-right-session]`、`data-dockkit-*`），
 *     选择器集中在本文件，便于版本变化时定位。
 *
 * 本阶段的定位：P02 的能力实验与只读观察面。自动保存与自动恢复（P04/P05）尚未接入。
 *
 * @module dsh-sidebar-size/client/host-bridge
 */

import type {
  ActiveContent,
  ApplyResult,
  Disposer,
  DragSignal,
  HostAvailability,
  HostBridge,
  HostView,
  PanelIdentity,
  Presentation,
  ResetLevel,
  WidthSample,
} from './contracts.ts'

/** 丙级选择器集中处。 */
const SELECTOR = {
  rightbarColumn: '[data-rightbar-col]',
  rightbarHandle: '[data-side="rightbar"]',
  rightbarPanel: '[data-sidebar-right-panel]',
  sessionContainer: '[data-sidebar-right-session]',
  dockPaneActive: '[data-dockkit-pane-active]',
  dockTab: '[data-dockkit-tab]',
} as const

/** 目标版本的首屏右栏默认比例与下限（源码核验 S2 / columns.ts）。 */
const RIGHTBAR_DEFAULT_RATIO = 0.45
const RIGHTBAR_MIN = 300

/**
 * 指针抬起后仍把尺寸采样算作“该次提交”的时间窗。宿主的 pointerup 收尾还会写最后一次位置，
 * 所以这段窗口内到达的采样可以关联到已提交的指针；窗口过后，任何尺寸变化都只能是环境来源。
 */
const ENDING_WINDOW_MS = 400

/** 面板元素的身份计数：同一会话内重新挂载会得到新的身份。 */
const elementIds = new WeakMap<Element, string>()
let elementIdSeq = 0

/** 一个元素的稳定身份标记。 */
function elementId(element: Element): string {
  const existing = elementIds.get(element)
  if (existing !== undefined) return existing
  elementIdSeq += 1
  const id = `el-${elementIdSeq}`
  elementIds.set(element, id)
  return id
}

/** 运行时可选服务的结构形状（能力检测用，不依赖未安装包的类型）。 */
interface LayoutProbe {
  readonly panelInfo?: unknown
  readonly panels?: { readonly setRightbar?: unknown }
  openRightbar?: unknown
  closeRightbar?: unknown
}

interface SidebarRightProbe {
  readonly mounted?: unknown
  readonly openTabs?: unknown
  active?: () => unknown
  isExpanded?: () => unknown
}

/** 创建 M1 所需的依赖。所有服务都以 unknown 传入，由本模块做能力检测。 */
export interface HostBridgeDeps {
  readonly document: Document
  readonly layout: unknown
  readonly sidebarRight: unknown
  /** 供测试注入的逐帧调度器；默认 requestAnimationFrame。 */
  readonly nextFrame?: () => Promise<void>
}

/** M1 的能力报告：诊断界面与实验记录都读它。 */
/** E2：连续多少次找不到正常面板/手柄后判定结构契约降级。 */
const MAX_STRUCTURE_MISSES = 3
/**
 * P12-E：结构监听器数量上限。正常只有控制器与诊断面 1—2 个；超过即视为重复登记缺陷。
 */
export const MAX_STRUCTURE_LISTENERS = 16

export interface HostCapability {
  /** 是否在 ctx.layout 上找到了可调用的宽度写入口。 */
  readonly canWriteWidth: boolean
  /** 写入入口的来源描述，例如 'layout.panels.setRightbar'。 */
  readonly writePath: string | null
  readonly hasLayoutService: boolean
  readonly hasSidebarRightService: boolean
  readonly hasObservableMounted: boolean
  /**
   * P11 #2：是否拿到了“打开的页签清单”观察器（乙级依赖 `sidebarRight.openTabs`）。
   * 为 false 时预备应用退化为“仅一次启动尝试”，首帧可能回到宿主默认值。
   */
  readonly hasTabsObservable: boolean
  /**
   * E2：结构契约是否健康——右栏处于展开状态却连续多次找不到正常面板或手柄时为 false。
   * 为 false 时自动恢复暂停（观察器保留，等结构恢复后自动继续），但不影响宿主自身使用。
   */
  readonly structureHealthy: boolean
  /** E2：结构问题的原因说明；健康时为 null。 */
  readonly structureNote: string | null
  /** E2：连续未命中次数（诊断用）。 */
  readonly structureMisses: number
}

/** 原始 DOM 取证：定位失败时用来区分“右侧边栏确实没显示”和“选择器/可见性判断不对”。 */
export interface DomProbe {
  readonly columnCount: number
  readonly columnRect: string
  readonly panels: readonly string[]
  readonly handleCount: number
  readonly sessionContainers: number
  /** 面板内部的停靠结构统计。 */
  readonly dock: string
  /** openTabs 的行数与首行内容。 */
  readonly openTabs: string
  readonly mounted: string
  readonly isExpanded: string
}

/**
 * 创建 M1 适配器。
 * @param deps - DOM 与宿主服务（可以是暂时缺失的服务）。
 * @returns HostBridge 实现，另有 capability() 与 currentDragPhase() 供诊断使用。
 */
export function createHostBridge(deps: HostBridgeDeps): HostBridge & {
  capability(): HostCapability
  currentDragPhase(): WidthSample['phase']
  domReport(): DomProbe
  /** U2 实验用：公开的右栏开合动作与一次非契约的“写回 null”尝试。 */
  closeRightbar(): boolean
  openRightbar(fullscreen: boolean): boolean
  tryResetPreferenceToNull(): string
} {
  const { document: doc } = deps
  const layout = asLayout(deps.layout)
  const sidebarRight = asSidebarRight(deps.sidebarRight)
  const nextFrame = deps.nextFrame ?? defaultNextFrame

  let geometryGeneration = 0
  /** 上一次的结构几何签名；只有环境变化才推进几何代次。 */
  let lastGeometrySignature = ''
  /** E2：连续“右栏展开却找不到正常面板/手柄”的次数。 */
  let structureMisses = 0
  /** P11 #2：是否成功拿到“打开的页签清单”观察器（乙级依赖 `openTabs`）。 */
  let tabsObservableAvailable = false
  /** P12-E：结构监听器数量上限与统计（诊断块可见）。 */
  let structureNotifications = 0
  let structureListenersRefused = 0
  let structureNotificationScheduled = false

  /**
   * 把一次结构通知推迟到微任务（P12-C）。同一轮里多次登记只安排一次。
   */
  function scheduleStructureNotification(): void {
    if (structureNotificationScheduled || disposed) return
    structureNotificationScheduled = true
    const run = (): void => {
      structureNotificationScheduled = false
      notifyStructure()
    }
    const globals = globalThis as { queueMicrotask?: (callback: () => void) => void }
    if (typeof globals.queueMicrotask === 'function') globals.queueMicrotask(run)
    else safeCall(() => { setTimeout(run, 0) })
  }
  let pointerCommitSeq = 0
  let disposed = false
  /** 最近一次出现在右栏手柄上的指针；用于把尺寸变化关联到一次指针提交。 */
  let activePointerId: number | null = null
  let dragPhase: WidthSample['phase'] = 'idle'
  /** 已开始的一次拖拽所对应的提交序号；Ending 阶段继续复用。 */
  let dragCommitSeq: number | null = null
  /**
   * 仍然可能产生归属尺寸的指针提交。抬起之后宿主还会写最后一次位置，因此这个标记保留一个
   * 短窗口（ENDING_WINDOW_MS）；窗口结束后必须清空，否则之后的窗口缩放/环境变化会被误标成
   * 用户拖拽（这正是 P02 实验里观察到的缺陷，M4 的归属判断依赖这里的事实是否干净）。
   */
  let pendingCommitSeq: number | null = null
  let endingTimer: ReturnType<typeof setTimeout> | null = null
  const disposers = new Set<Disposer>()

  // ── 观察与重绑定状态 ────────────────────────────────────────────────────────
  // 设置面板开关、会话切换、面板重建都会让“当前面板/手柄元素”变成新节点。观察器与事件监听
  // 必须跟着元素走，否则会挂在已脱离文档的旧节点上（表现就是“记录已开启但零回调”）。
  const widthListeners = new Set<(sample: WidthSample) => void>()
  const dragListeners = new Set<(signal: DragSignal) => void>()
  const structureListeners = new Set<() => void>()
  let boundPanel: Element | null = null
  let boundHandle: Element | null = null
  let boundFrame: Element | null = null
  let panelResize: ResizeObserver | null = null
  let frameResize: ResizeObserver | null = null
  let structureObserver: MutationObserver | null = null
  let handleCleanup: Disposer | null = null

  const capability = (): HostCapability => {
    const write = (layout?.panels as { setRightbar?: unknown } | undefined)?.setRightbar
    const canWrite = typeof write === 'function'
    return {
      canWriteWidth: canWrite,
      writePath: canWrite ? 'layout.panels.setRightbar' : null,
      hasLayoutService: layout !== undefined,
      hasSidebarRightService: sidebarRight !== undefined,
      hasObservableMounted: readObservable(sidebarRight?.mounted) !== UNAVAILABLE,
      hasTabsObservable: tabsObservableAvailable,
      structureHealthy: structureMisses < MAX_STRUCTURE_MISSES,
      structureNote: structureMisses < MAX_STRUCTURE_MISSES
        ? null
        : `右栏处于展开状态，但连续 ${String(structureMisses)} 次找不到正常面板或手柄：自动恢复暂停（等待结构恢复，宿主不受影响）`,
      structureMisses,
    }
  }

  /** 原始取证：把选择器命中的元素与它们的属性/尺寸如实报出来。 */
  const domReport = (): DomProbe => {    const columns = Array.from(doc.querySelectorAll(SELECTOR.rightbarColumn))
    const panels = Array.from(doc.querySelectorAll(SELECTOR.rightbarPanel))
    const first = columns[0]
    return {
      columnCount: columns.length,
      columnRect: first === undefined ? '—' : rectText(first),
      panels: panels.map((panel) => {
        const session = panel.getAttribute('data-sidebar-right-session')
        const mode = panel.getAttribute('data-sidebar-right-panel')
        const open = panel.hasAttribute('data-sidebar-right-open')
        const hidden = panel.closest('[hidden]') !== null
        return `session=${session ?? '—'} mode=${mode ?? '—'} open=${String(open)} hiddenAncestor=${String(hidden)} rect=${rectText(panel)}`
      }),
      handleCount: doc.querySelectorAll(SELECTOR.rightbarHandle).length,
      sessionContainers: doc.querySelectorAll(SELECTOR.sessionContainer).length,
      dock: dockProbe(doc.querySelector(SELECTOR.rightbarPanel)),
      openTabs: openTabsProbe(sidebarRight?.openTabs),
      mounted: describe(readObservable(sidebarRight?.mounted)),
      isExpanded: describe(safeValue(() => sidebarRight?.isExpanded?.())),
    }
  }

  /** 当前会话 id：优先服务通知，其次面板 DOM 属性。 */
  function currentSessionId(panel: Element | null): string | undefined {
    const fromService = readObservable(sidebarRight?.mounted)
    if (typeof fromService === 'string' && fromService.length > 0) return fromService
    const attr = panel?.getAttribute('data-sidebar-right-session')
    return attr === null || attr === undefined || attr === '' ? undefined : attr
  }

  /** 定位当前会话的真实面板元素（排除隐藏容器与浮窗）。 */
  function findPanel(sessionId: string | undefined): Element | null {
    const visible = Array.from(doc.querySelectorAll(SELECTOR.rightbarPanel)).filter(isVisible)
    if (sessionId !== undefined && sessionId !== '') {
      const exact = visible.find(candidate => candidate.getAttribute('data-sidebar-right-session') === sessionId)
      if (exact !== undefined) return exact
    }
    // 服务没给出会话、或给出的会话与 DOM 不一致时的降级：只接受“打开着的、可见的”面板。
    // 不做“取第一个 [data-sidebar-right-session]”这种匹配（那会把隐藏容器或浮窗选进来）。
    return visible.find(candidate => candidate.hasAttribute('data-sidebar-right-open')) ?? null
  }

  /** 正常右栏列（框架中为右栏预留的那一列）。 */
  function findColumn(): { column: Element; frame: Element } | null {
    const column = doc.querySelector(SELECTOR.rightbarColumn)
    if (column === null) return null
    const frame = column.parentElement
    return frame === null ? null : { column, frame }
  }

  function presentationOf(panel: Element | null): Presentation {
    if (panel === null) return 'hidden'
    const mode = panel.getAttribute('data-sidebar-right-panel')
    if (mode === 'fullscreen') return 'fullscreen'
    if (!panel.hasAttribute('data-sidebar-right-open')) return 'collapsed'
    return 'push'
  }

  function readView(): HostView {
    const panel = findPanel(readObservable(sidebarRight?.mounted) as string | undefined)
    const column = findColumn()
    const sessionId = currentSessionId(panel)
    const presentation = presentationOf(panel)
    const availability: HostAvailability = panel === null || column === null
      ? { kind: 'waiting', reason: panel === null ? '找不到当前会话的正常右栏面板' : '找不到正常右栏列' }
      : { kind: 'ready' }
    const identity: PanelIdentity | undefined = panel === null || sessionId === undefined
      ? undefined
      : { sessionId, elementId: elementId(panel) }

    return {
      sessionId: sessionId ?? '',
      panelIdentity: identity,
      expanded: readExpanded(panel),
      presentation,
      framePx: column === null ? null : round(column.frame.getBoundingClientRect().width),
      observedPx: panel === null ? null : measurePanelWidth(panel),
      activeDockContent: readActiveContent(panel, sessionId),
      availability,
    }
  }

  function readExpanded(panel: Element | null): boolean {
    const fromService = sidebarRight?.isExpanded?.()
    if (typeof fromService === 'boolean') return fromService
    return panel !== null && presentationOf(panel) === 'push'
  }

  /** 面板实际宽度：优先量测，避免把宿主偏好值误当测量值。 */
  function measurePanelWidth(panel: Element): number | null {
    const rect = panel.getBoundingClientRect().width
    if (Number.isFinite(rect) && rect > 0) return round(rect)
    const inline = Number.parseFloat(panel.getAttribute('style')?.match(/width:\s*([\d.]+)px/)?.[1] ?? '')
    return Number.isFinite(inline) && inline > 0 ? round(inline) : null
  }

  /** 当前停靠面板中的活动内容：先定位活动停靠面板，再取它的选中页签。 */
  function readActiveContent(panel: Element | null, sessionId: string | undefined): ActiveContent | undefined {
    if (panel === null || sessionId === undefined || sessionId === '') return undefined
    const panes = Array.from(panel.querySelectorAll(SELECTOR.dockPaneActive)).filter(isVisible)
    // 分栏时宿主只标记一个“活动”面板；一旦无法唯一判断（0 个或多个活动面板），就**暂停分类**，
    // 绝不把多个选中页签中的第一个当成当前类型（实现规划 P08 第 4 条）。
    if (panes.length !== 1) return undefined
    const pane = panes[0] as Element
    const selected = Array.from(pane.querySelectorAll(`${SELECTOR.dockTab}[aria-selected="true"]`)).filter(isVisible)
    // 同一个活动面板里也必须只有一个选中页签，否则同样无法唯一判断。
    if (selected.length !== 1) return undefined
    const tabId = (selected[0] as Element).getAttribute('data-dockkit-tab')
    if (tabId === null || tabId === undefined || tabId === '') return undefined
    const inventory = lookupTab(sessionId, tabId)
    const paneId = pane.getAttribute('data-dockkit-pane') ?? pane.id ?? 'pane-0'
    return {
      sessionId,
      paneId,
      tabId,
      kind: inventory?.kind ?? '',
      contentId: inventory?.contentId,
    }
  }

  /** 用 openTabs 把 DOM 的页签实例 id 映射回类型；映射不到时返回 undefined。 */
  function lookupTab(sessionId: string, tabId: string): { kind: string; contentId: string | undefined } | undefined {
    const source = sidebarRight?.openTabs
    const rows = toRows(source)
    for (const row of rows) {
      if (!isRecord(row)) continue
      if (row.sessionId !== sessionId || row.tabId !== tabId) continue
      if (typeof row.kind !== 'string') continue
      return { kind: row.kind, contentId: typeof row.contentId === 'string' ? row.contentId : undefined }
    }
    return undefined
  }

  /** 当前观察目标发出的尺寸采样（面板元素更换后仍由 reconcile 保证指向新节点）。 */
  function emitWidth(): void {
    if (disposed) return
    const panel = boundPanel
    const target = panel ?? findColumn()?.column ?? null
    if (target === null) return
    const width = panel === null ? round(target.getBoundingClientRect().width) : measurePanelWidth(panel)
    if (width === null) return
    // 没有会话身份就不产生采样：面板身份是后续归属判断的必要输入。
    const sessionId = currentSessionId(panel)
    if (sessionId === undefined) return
    const sample: WidthSample = {
      px: width,
      panelIdentity: { sessionId, elementId: elementId(target) },
      pointerCommitSeq: pendingCommitSeq,
      geometryGeneration,
      phase: dragPhase,
      // 采样只陈述事实：这一帧是否落在“仍可能产生归属尺寸”的指针提交窗口内。
      // 窗口之外（窗口缩放、面板重建、程序恢复）必须是 false，供 M4 直接拒绝。
      valid: pendingCommitSeq !== null,
    }
    for (const listener of Array.from(widthListeners)) safeCall(() => listener(sample))
  }

  /**
   * 结构观察器只做一次；几何代次只跟踪**环境**变化。
   *
   * 为什么不能每次结构变化都自增：宿主在拖拽过程中每帧都在改面板的 `style`（宽度），
   * 若每次都算“几何变了”，M4 会从第二条采样起就拒收，内存里只会留下拖拽的第一条采样
   * （P04 的环境实验正是这样暴露出来的）。这里用签名只比较框架宽、展示形态、面板身份、
   * 会话与展开状态；拖拽本身不改变它们。
   */
  function geometrySignature(): string {
    const column = findColumn()
    const panel = boundPanel
    const session = readObservable(sidebarRight?.mounted)
    return [
      column === null ? 'no-frame' : String(round(column.frame.getBoundingClientRect().width)),
      presentationOf(panel),
      panel === null ? 'no-panel' : elementId(panel),
      typeof session === 'string' ? session : 'no-session',
      safeValue(() => sidebarRight?.isExpanded?.()) === true ? 'expanded' : 'collapsed',
    ].join('|')
  }

  function notifyStructure(): void {
    if (disposed) return
    structureNotifications += 1
    const signature = geometrySignature()
    if (signature !== lastGeometrySignature) {
      lastGeometrySignature = signature
      geometryGeneration += 1
    }
    for (const listener of Array.from(structureListeners)) safeCall(listener)
  }

  /**
   * P12-E：注册期不再同步通知调用方。
   *
   * 背景（P12 定位）：`observeStructure` 过去直接调用 `reconcile()`，而 `reconcile()` 末尾会**同步**
   * 通知全部监听器；控制器在“结算（settle）过程中重新登记观察器”时，回调会重入 `settle()`，
   * 而那时登记用的 disposer 还没入列表 ⇒ 条件重绑再次成立 ⇒ 互递归（真机上渲染进程崩溃）。
   *
   * 现在把“对齐元素”和“通知监听器”分开：注册只做对齐，通知推迟到微任务（调用栈清空后），
   * 于是重入不再可能发生在登记动作内部；同时保留了“注册后能收到一次初始通知”的既有语义。
   */
  function reconcileStructureOnly(): void {
    reconcile({ notify: false })
  }

  /** 把监听/观察器对齐到当前的面板与手柄元素；元素换了或“该绑而没绑”时重绑定。 */
  function reconcile(options?: { readonly notify?: boolean }): void {
    if (disposed) return
    const sessionId = readObservable(sidebarRight?.mounted)
    const panel = findPanel(typeof sessionId === 'string' && sessionId.length > 0 ? sessionId : undefined)
    const handle = doc.querySelector(SELECTOR.rightbarHandle)

    // E2：右栏明明处于展开状态，却找不到正常面板或手柄——说明结构契约变了（不是“没打开”）。
    // 连续命中不到就降级：保留观察器（结构恢复后自动继续），但把能力标成不可用，让上层暂停自动恢复。
    const expanded = safeValue(() => sidebarRight?.isExpanded?.()) === true
    const missing = expanded && (panel === null || handle === null)
    structureMisses = missing ? structureMisses + 1 : 0

    const wantPanelResize = panel !== null && widthListeners.size > 0
    if (panel !== boundPanel || wantPanelResize !== (panelResize !== null)) {
      panelResize?.disconnect()
      panelResize = null
      boundPanel = panel
      if (wantPanelResize && panel !== null) {
        geometryGeneration += 1
        panelResize = new ResizeObserver(() => emitWidth())
        panelResize.observe(panel)
      }
    }

    const wantHandle = handle !== null && dragListeners.size > 0
    if (handle !== boundHandle || wantHandle !== (handleCleanup !== null)) {
      handleCleanup?.()
      handleCleanup = null
      boundHandle = handle
      if (wantHandle && handle !== null) {
        geometryGeneration += 1
        handleCleanup = bindHandle(handle)
      }
    }

    const frame = findColumn()?.frame ?? null
    if (frame !== boundFrame) {
      frameResize?.disconnect()
      frameResize = null
      boundFrame = frame
      if (frame !== null) {
        frameResize = new ResizeObserver(() => notifyStructure())
        frameResize.observe(frame)
      }
    }

    if (options?.notify !== false) notifyStructure()
  }

  /** 结构变化观察器只建一次。 */
  function ensureStructureObserver(): void {
    if (structureObserver !== null || disposed) return
    structureObserver = new MutationObserver(() => reconcile())
    structureObserver.observe(doc.documentElement, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ['data-sidebar-right-open', 'data-sidebar-right-panel', 'data-dockkit-pane-active', 'aria-selected', 'hidden', 'style'],
    })
  }

  function observeStructure(listener: () => void): Disposer {
    // P12-E：监听器数量护栏。正常只有 1—2 个（控制器 + 诊断），超过上限说明有人在重复登记——
    // 那是缺陷信号，必须留下可读证据而不是继续放大。
    if (structureListeners.size >= MAX_STRUCTURE_LISTENERS) {
      structureListenersRefused += 1
      if (structureListenersRefused === 1 || structureListenersRefused % 10 === 0) {
        console.error(
          `[dsh-sidebar-size] 结构监听器数量已达上限 ${String(MAX_STRUCTURE_LISTENERS)}，`
          + `拒绝第 ${String(structureListenersRefused)} 次登记（疑似重复登记缺陷，请在诊断块查看）`,
        )
      }
      return () => {}
    }
    structureListeners.add(listener)
    ensureStructureObserver()
    // 只对齐、不同步通知；初始通知推迟到微任务（见 reconcileStructureOnly 的说明）。
    reconcileStructureOnly()
    scheduleStructureNotification()
    return () => {
      structureListeners.delete(listener)
    }
  }

  function observeWidth(listener: (sample: WidthSample) => void): Disposer {
    widthListeners.add(listener)
    // 尺寸监听器是事件驱动的：注册时只需要对齐元素，不需要任何通知。
    reconcileStructureOnly()
    return () => {
      widthListeners.delete(listener)
    }
  }

  function observeDrag(listener: (signal: DragSignal) => void): Disposer {
    dragListeners.add(listener)
    reconcileStructureOnly()
    return () => {
      dragListeners.delete(listener)
    }
  }

  /** 清掉 Ending 计时器。 */
  function clearEndingTimer(): void {
    if (endingTimer === null) return
    clearTimeout(endingTimer)
    endingTimer = null
  }

  /** Ending 窗口结束后复位：此后的尺寸变化不再属于任何指针提交。 */
  function scheduleEndingClear(): void {
    clearEndingTimer()
    endingTimer = setTimeout(() => {
      endingTimer = null
      dragPhase = 'idle'
      activePointerId = null
      pendingCommitSeq = null
      dragCommitSeq = null
    }, ENDING_WINDOW_MS)
  }

  /** 把指针事件绑到一个手柄元素上；返回解绑函数。 */
  function bindHandle(handle: Element): Disposer {
    const emitDrag = (signal: DragSignal): void => {
      for (const listener of Array.from(dragListeners)) safeCall(() => listener(signal))
    }

    const onDown = (event: Event): void => {
      if (!(event instanceof PointerEvent) || event.button !== 0) return
      const panel = findPanel(readObservable(sidebarRight?.mounted) as string | undefined)
      if (panel === null) return
      const sessionId = currentSessionId(panel)
      if (sessionId === undefined) return
      activePointerId = event.pointerId
      pointerCommitSeq += 1
      dragCommitSeq = pointerCommitSeq
      pendingCommitSeq = pointerCommitSeq
      dragPhase = 'dragging'
      clearEndingTimer()
      emitDrag({
        kind: 'pointer-down',
        pointerId: event.pointerId,
        panelIdentity: { sessionId, elementId: elementId(panel) },
      })
    }
    const onUp = (event: Event): void => {
      if (!(event instanceof PointerEvent) || event.pointerId !== activePointerId) return
      dragPhase = 'ending'
      scheduleEndingClear()
      emitDrag({ kind: 'pointer-up', pointerId: event.pointerId })
    }
    const onCaptureReleased = (event: Event): void => {
      if (!(event instanceof PointerEvent) || event.pointerId !== activePointerId) return
      dragPhase = 'ending'
      scheduleEndingClear()
      emitDrag({ kind: 'capture-released', pointerId: event.pointerId })
    }
    const onCancel = (event: Event): void => {
      if (!(event instanceof PointerEvent) || event.pointerId !== activePointerId) return
      dragPhase = 'idle'
      activePointerId = null
      dragCommitSeq = null
      pendingCommitSeq = null
      clearEndingTimer()
      emitDrag({ kind: 'cancelled', pointerId: event.pointerId, reason: 'pointercancel' })
    }

    handle.addEventListener('pointerdown', onDown)
    // 抬起可能发生在手柄之外，因此挂在 document 的捕获阶段。
    doc.addEventListener('pointerup', onUp, true)
    handle.addEventListener('lostpointercapture', onCaptureReleased)
    handle.addEventListener('pointercancel', onCancel)

    return () => {
      handle.removeEventListener('pointerdown', onDown)
      doc.removeEventListener('pointerup', onUp, true)
      handle.removeEventListener('lostpointercapture', onCaptureReleased)
      handle.removeEventListener('pointercancel', onCancel)
      // 拖拽过程中手柄被移除或替换（面板重建、展示形态切换、宿主重渲染）：必须发出取消，
      // 否则 M4 会永远停在 dragging，自动恢复从此失效（实现规划 P08 第 5 条 / E16）。
      if (activePointerId !== null) {
        const pointerId = activePointerId
        activePointerId = null
        dragPhase = 'idle'
        dragCommitSeq = null
        pendingCommitSeq = null
        clearEndingTimer()
        emitDrag({ kind: 'cancelled', pointerId, reason: '拖拽过程中手柄被移除或替换' })
      }
    }
  }

  async function applyWidth(px: number): Promise<ApplyResult> {
    const write = (layout?.panels as { setRightbar?: unknown } | undefined)?.setRightbar
    if (typeof write !== 'function') {
      return { status: 'unavailable', requestedPx: px, reason: 'ctx.layout 上没有可调用的宽度写入口（乙级依赖不可用）' }
    }
    const before = readView()
    if (before.presentation !== 'push') {
      return { status: 'deferred', requestedPx: px, reason: `当前不是正常停靠展示（${before.presentation}），暂不写入` }
    }
    try {
      // 以 layout.panels 作为接收者调用：动作本身可能是绑定过的 store action。
      ;(write as (value: number) => void).call(layout?.panels, px)
    } catch (error) {
      return { status: 'failed', requestedPx: px, reason: `写入抛错：${messageOf(error)}` }
    }
    await nextFrame()
    await nextFrame()
    const after = readView()
    return {
      status: after.observedPx === null ? 'failed' : 'applied',
      requestedPx: px,
      ...after.observedPx === null ? {} : { observedPx: after.observedPx },
      reason: after.observedPx !== null && after.observedPx !== px
        ? '宿主按布局约束调整了实际宽度'
        : undefined,
    }
  }

  async function restoreDefault(reason: string): Promise<ApplyResult> {
    const frame = readView().framePx
    if (frame === null) {
      return { status: 'deferred', reason: `尚无有效框架宽度，无法计算目标版本默认值（${reason}）` }
    }
    // 目标版本默认：max(300, round(框架宽 × 0.45))（源码核验 S2）。这是数值适配，
    // 不等于“完整默认语义”，因此 resetLevel 只能是 numeric。
    const target = Math.max(RIGHTBAR_MIN, Math.round(frame * RIGHTBAR_DEFAULT_RATIO))
    const result = await applyWidth(target)
    const resetLevel: ResetLevel = 'numeric'
    return { ...result, resetLevel }
  }

  /**
   * 关闭右栏（公开动作 `ctx.layout.closeRightbar()`）。
   *
   * 只清除展示标记，**保留已设宽度偏好**（源码核验 S1）——这正是 U2 要考察的差别来源。
   * @returns 是否成功调用到宿主动作。
   */
  function closeRightbar(): boolean {
    const action = layout?.closeRightbar
    if (typeof action !== 'function') return false
    try {
      ;(action as () => void).call(layout)
      return true
    } catch {
      return false
    }
  }

  /**
   * 打开右栏（公开动作 `ctx.layout.openRightbar(track, fullscreen)`）。
   * @param fullscreen - 是否以全屏形态打开。
   * @returns 是否成功调用到宿主动作。
   */
  function openRightbar(fullscreen: boolean): boolean {
    const action = layout?.openRightbar
    if (typeof action !== 'function') return false
    try {
      ;(action as (track: boolean, fullscreen: boolean) => void).call(layout, true, fullscreen)
      return true
    } catch {
      return false
    }
  }

  /**
   * **实验专用**：尝试把宽度偏好写回 `null`，看是否能得到“未挂载”的语义。
   *
   * 这不是接口契约（源码核验 S1：`setRightbar` 只接受数字，传入 null 不属于契约），因此这里
   * 只把它当作一次可失败的实验：返回结果说明，不问对错；是否采用由人在 H03 决定。
   * @returns 结果说明文本。
   */
  function tryResetPreferenceToNull(): string {
    const write = (layout?.panels as { setRightbar?: unknown } | undefined)?.setRightbar
    if (typeof write !== 'function') return '不可用：找不到宽度写入口'
    try {
      ;(write as (value: unknown) => void).call(layout?.panels, null)
      return '已调用 setRightbar(null)（非契约调用，是否恢复未初始化语义需要重新打开右栏观察）'
    } catch (error) {
      return `setRightbar(null) 抛出：${messageOf(error)}`
    }
  }

  async function readFinalDragSample(): Promise<WidthSample | null> {    await nextFrame()
    const panel = findPanel(readObservable(sidebarRight?.mounted) as string | undefined)
    if (panel === null) return null
    const px = measurePanelWidth(panel)
    if (px === null) return null
    const sessionId = currentSessionId(panel)
    if (sessionId === undefined) return null
    return {
      px,
      panelIdentity: { sessionId, elementId: elementId(panel) },
      pointerCommitSeq: dragCommitSeq,
      geometryGeneration,
      phase: dragPhase,
      valid: dragPhase !== 'idle',
    }
  }

  /**
   * P11 #2 预备应用：面板未渲染时也能写入宽度偏好。
   *
   * 为什么单独一条路径：`applyWidth` 会先读视图并要求 `presentation === 'push'`（正常停靠展示），
   * 面板尚未打开时必然 deferred —— 而那正是首帧显示默认值的原因。这里只调用宿主写入口
   * （`layout.panels.setRightbar`，乙级依赖），不做测量、不等渲染。
   *
   * @param px - 目标像素值。
   * @returns 是否成功调用；失败时给出原因。
   */
  function preApplyWidth(px: number): { ok: boolean; reason?: string } {
    const write = (layout?.panels as { setRightbar?: unknown } | undefined)?.setRightbar
    if (typeof write !== 'function') {
      return { ok: false, reason: 'ctx.layout 上没有可调用的宽度写入口（乙级依赖不可用）' }
    }
    try {
      ;(write as (value: number) => void).call(layout?.panels, px)
      return { ok: true }
    } catch (error) {
      return { ok: false, reason: `写入抛错：${messageOf(error)}` }
    }
  }

  /**
   * 读取服务侧的当前活动页签（`ctx.sidebarRight.active()`）。
   *
   * 只读、只做形状校验：拿不到就返回 undefined，绝不猜测。
   * @returns 活动页签的内容身份；不可读时为 undefined。
   */
  function readServiceActiveContent(): ActiveContent | undefined {
    const sessionId = readObservable(sidebarRight?.mounted)
    if (typeof sessionId !== 'string' || sessionId === '') return undefined
    const tab = safeValue(() => {
      const read = sidebarRight?.active
      return typeof read === 'function' ? read.call(sidebarRight) : undefined
    })
    if (tab === undefined || tab === null || typeof tab !== 'object') return undefined
    const record = tab as { id?: unknown, kind?: unknown, contentId?: unknown }
    const tabId = typeof record.id === 'string' ? record.id : ''
    const kind = typeof record.kind === 'string' ? record.kind : ''
    if (tabId === '' || kind === '') return undefined
    return {
      sessionId,
      paneId: '',
      tabId,
      kind,
      contentId: typeof record.contentId === 'string' ? record.contentId : '',
    }
  }

  /**
   * 订阅“打开的页签清单”变化（乙级依赖，见 {@link HostBridge.observeTabs}）。
   * @param listener - 变化回调。
   * @returns 取消订阅。
   */
  function observeTabs(listener: () => void): Disposer {
    const source = sidebarRight?.openTabs as { subscribe?: unknown } | undefined
    if (source === undefined || typeof source.subscribe !== 'function') {
      tabsObservableAvailable = false
      return () => {}
    }
    tabsObservableAvailable = true
    const unsubscribe = safeValue(() => (source.subscribe as (fn: () => void) => unknown).call(source, listener))
    return () => {
      if (typeof unsubscribe === 'function') safeCall(unsubscribe as Disposer)
    }
  }

  function dispose(): void {
    if (disposed) return
    disposed = true
    clearEndingTimer()
    panelResize?.disconnect()
    frameResize?.disconnect()
    structureObserver?.disconnect()
    handleCleanup?.()
    panelResize = null
    frameResize = null
    structureObserver = null
    handleCleanup = null
    widthListeners.clear()
    dragListeners.clear()
    structureListeners.clear()
    for (const disposer of Array.from(disposers)) safeCall(disposer)
    disposers.clear()
  }

  return {
    readView,
    observeStructure: (listener) => track(disposers, observeStructure(listener)),
    observeWidth: (listener) => track(disposers, observeWidth(listener)),
    observeDrag: (listener) => track(disposers, observeDrag(listener)),
    applyWidth,
    restoreDefault,
    preApplyWidth,
    readServiceActiveContent,
    observeTabs: (listener) => track(disposers, observeTabs(listener)),
    readFinalDragSample: () => readFinalDragSample(),
    closeRightbar,
    openRightbar,
    tryResetPreferenceToNull,
    dispose,
    capability,
    currentDragPhase: () => dragPhase,
    domReport,
    structureStats: () => ({
      listeners: structureListeners.size,
      notifications: structureNotifications,
      refused: structureListenersRefused,
    }),
  }
}

/** 元素的测量尺寸文本。 */
function rectText(element: Element): string {
  const rect = element.getBoundingClientRect()
  return `${Math.round(rect.width)}×${Math.round(rect.height)}`
}

/** 面板内部的停靠结构统计（用于判断活动内容读取失败的环节）。 */
function dockProbe(panel: Element | null): string {
  if (panel === null) return '没有面板'
  const panes = panel.querySelectorAll(SELECTOR.dockPaneActive)
  const tabs = panel.querySelectorAll(SELECTOR.dockTab)
  const selected = panel.querySelectorAll(`${SELECTOR.dockTab}[aria-selected="true"]`)
  return `活动停靠面板=${panes.length} 页签=${tabs.length} 选中页签=${selected.length}`
}

/** openTabs 的行数与本项目的字段形状。 */
function openTabsProbe(source: unknown): string {
  const rows = toRows(source)
  if (rows.length === 0) return '0 行（或读不到）'
  const first = rows[0]
  const keys = isRecord(first) ? Object.keys(first).join(',') : typeof first
  return `${rows.length} 行；首行字段：${keys}`
}

/** 把任意值描述成一段短文本，供诊断显示。 */
function describe(value: unknown): string {
  if (value === UNAVAILABLE) return '读不到'
  if (value === undefined) return 'undefined'
  if (value === null) return 'null'
  if (typeof value === 'string') return value === '' ? '（空串）' : value
  if (typeof value === 'number' || typeof value === 'boolean') return String(value)
  try {
    return JSON.stringify(value) ?? String(value)
  } catch {
    return String(value)
  }
}

/** 读取可观察量的当前值；读不到返回 UNAVAILABLE。 */
const UNAVAILABLE = Symbol('unavailable')

function readObservable(source: unknown): unknown {
  if (source === undefined || source === null) return UNAVAILABLE
  if (typeof source === 'function') return safeValue(() => (source as () => unknown)())
  if (typeof source === 'object') {
    const candidate = source as { getSnapshot?: unknown; get?: unknown; value?: unknown; current?: unknown }
    // 固定版本的 ObservableSnapshot 只有 getSnapshot()（dsh-client-store/contract.d.ts）。
    if (typeof candidate.getSnapshot === 'function') {
      return safeValue(() => (candidate.getSnapshot as () => unknown)())
    }
    if (typeof candidate.get === 'function') return safeValue(() => (candidate.get as () => unknown)())
    if ('value' in candidate) return candidate.value
    if ('current' in candidate) return candidate.current
  }
  return source
}

/** 把 openTabs 之类的来源读成行数组。 */
function toRows(source: unknown): unknown[] {
  const value = readObservable(source)
  if (Array.isArray(value)) return value
  if (value !== UNAVAILABLE && value !== undefined && value !== null && typeof value === 'object') {
    const iterable = value as Iterable<unknown>
    if (typeof iterable[Symbol.iterator] === 'function') return Array.from(iterable)
  }
  return []
}

function safeValue(read: () => unknown): unknown {
  try {
    return read()
  } catch {
    return UNAVAILABLE
  }
}

/** 判断元素是否可见：自身或祖先带 hidden、或尺寸为 0 都算不可见。 */
function isVisible(element: Element): boolean {
  if (element.closest('[hidden]') !== null) return false
  const rect = element.getBoundingClientRect()
  return rect.width > 0 && rect.height > 0
}

function asLayout(value: unknown): LayoutProbe | undefined {
  return isRecord(value) ? value as LayoutProbe : undefined
}

function asSidebarRight(value: unknown): SidebarRightProbe | undefined {
  return isRecord(value) ? value as SidebarRightProbe : undefined
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null
}

function round(value: number): number {
  return Math.round(value)
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

/** 逐帧等待：让宿主的布局提交完成后再量测。 */
function defaultNextFrame(): Promise<void> {
  return new Promise<void>((resolve) => {
    if (typeof requestAnimationFrame === 'function') requestAnimationFrame(() => resolve())
    else setTimeout(resolve, 16)
  })
}

function safeCall(callback: () => void): void {
  try {
    callback()
  } catch (error) {
    try {
      console.warn('[dsh-sidebar-size] M1 回调抛错（已忽略）：', error)
    } catch {
      // 保持静默。
    }
  }
}

/** 把释放函数登记进集合，并返回一个同时移除登记的函数。 */
function track(disposers: Set<Disposer>, disposer: Disposer): Disposer {
  disposers.add(disposer)
  return () => {
    disposers.delete(disposer)
    safeCall(disposer)
  }
}
