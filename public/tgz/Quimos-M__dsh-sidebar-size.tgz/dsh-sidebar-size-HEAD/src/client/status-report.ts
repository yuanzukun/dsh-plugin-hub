/**
 * P11 #1：面向用户的运行状态、尺寸来源与日志报告（**纯函数**，便于自动测试）。
 *
 * 设计约束（来自规划案 §9.2）：
 *   * 发布版设置页只显示三件事：**是否正常运行**（四态）、**当前活动页签**、**当前侧边栏尺寸（带来源）**，
 *     外加一个可复制的日志文本框；
 *   * 诊断区块（DOM 取证、U2/U3/U4-U5 实验等）由 {@link DIAGNOSTICS_KEY} 控制是否渲染；
 *   * 本模块**不读 DOM、不读存储、不读宿主服务**，只把上层给的快照映射成文案，因此可以在 node 里直接测试；
 *   * 日志报告的可发送性是硬约束：**不得包含会话 id 与文件路径**（Q12）。
 *
 * @module dsh-sidebar-size/client/status-report
 */

import { describe, resolveWidth } from './content-kind.ts'
import type { ContentKey, KeeperSnapshot, PrefsSnapshot, WidthEntry } from './contracts.ts'
import type { HostCapability } from './host-bridge.ts'

/**
 * 诊断区块的显示开关键：值为 {@link DIAGNOSTICS_ON} 时渲染诊断与实验区块。
 *
 * 为什么放在浏览器存储里：诊断区块是发布版**隐藏而不删除**的验收工具（P11 Q1/Q8/Q20），
 * 存储键可以在不重启客户端的情况下切换；发布版默认（键不存在或值不同）不渲染。
 */
export const DIAGNOSTICS_KEY = 'dsh-sidebar-size.diagnostics'

/** 诊断开关的“打开”取值。 */
export const DIAGNOSTICS_ON = '1'

/**
 * 插件版本：构建期由 tsdown 的 `define` 注入（见 `build/tsdown.client.ts`），
 * 未注入时退回 'unknown'（用 `typeof` 判断，测试环境不会因未定义标识符抛错）。
 */
declare const __PLUGIN_VERSION__: string | undefined
export const PLUGIN_VERSION: string = typeof __PLUGIN_VERSION__ === 'string' ? __PLUGIN_VERSION__ : 'unknown'

/** 四态运行状态。 */
export type RunState = 'ok' | 'degraded' | 'not-ready' | 'disabled'

/** 运行状态报告。 */
export interface RunStateReport {
  readonly state: RunState
  /** 面向用户的中文标签。 */
  readonly label: string
  /** 非正常态的原因（正常态为 null）。 */
  readonly reason: string | null
}

/** 当前宽度的来源。 */
export type WidthOrigin = 'own' | 'inherited' | 'default'

/** 当前宽度报告。 */
export interface WidthReport {
  readonly px: number | null
  readonly origin: WidthOrigin
  /** 继承来源的显示名（仅 origin === 'inherited' 时非空）。 */
  readonly fromLabel: string | null
  /** 继承来源的分类键（仅 origin === 'inherited' 时非空）；设置页用它默认选中继承来源。 */
  readonly fromKey: ContentKey | null
  /** 面向用户的完整文案，例如 `540px（本类型记录）`。 */
  readonly text: string
}

const RUN_LABELS: Readonly<Record<RunState, string>> = {
  ok: '正常运行',
  degraded: '降级',
  'not-ready': '未就绪',
  disabled: '已关闭',
}

/**
 * 判定四态运行状态（优先级：已关闭 → 未就绪 → 降级 → 正常）。
 *
 * @param input - 控制器快照、设置快照与宽度写入口能力（都可能是 null，表示尚未就绪）。
 * @returns 状态标签与原因。
 */
export function deriveRunState(input: {
  readonly keeper: KeeperSnapshot | null
  readonly prefs: PrefsSnapshot | null
  readonly capability: HostCapability | null
}): RunStateReport {
  const { keeper, prefs, capability } = input

  // 1) 用户在设置里关掉了总开关：这是用户意图，不算异常。
  if (keeper !== null && keeper.enabled === false) {
    return { state: 'disabled', label: RUN_LABELS.disabled, reason: null }
  }

  // 2) 还没就绪：宿主服务未接入、设置确认值未读到、或控制器仍在等待。
  if (keeper === null) {
    return { state: 'not-ready', label: RUN_LABELS['not-ready'], reason: '宿主服务尚未接入' }
  }
  if (prefs === null || prefs.state !== 'ready') {
    return { state: 'not-ready', label: RUN_LABELS['not-ready'], reason: '设置确认值尚未就绪' }
  }
  if (keeper.state === 'init' || keeper.state === 'prefs-waiting' || keeper.state === 'waiting') {
    return { state: 'not-ready', label: RUN_LABELS['not-ready'], reason: '等待正常停靠的右侧边栏' }
  }

  // 3) 降级：能记录但当前不能自动应用（结构契约、写入口、设置可写性或存储保护）。
  if (!keeper.structureHealthy) {
    return { state: 'degraded', label: RUN_LABELS.degraded, reason: keeper.structureNote ?? '宿主结构契约异常，自动恢复暂停' }
  }
  if (capability !== null && !capability.canWriteWidth) {
    return { state: 'degraded', label: RUN_LABELS.degraded, reason: '宽度写入口不可用，自动恢复暂停' }
  }
  if (prefs.writable === false || prefs.mode === 'memory') {
    return { state: 'degraded', label: RUN_LABELS.degraded, reason: '宿主设置当前不可写' }
  }
  if (keeper.storageStatus.protected) {
    return { state: 'degraded', label: RUN_LABELS.degraded, reason: '宽度原文受保护，自动写入暂停' }
  }
  if (keeper.error !== null) {
    return { state: 'degraded', label: RUN_LABELS.degraded, reason: keeper.error }
  }

  return { state: 'ok', label: RUN_LABELS.ok, reason: null }
}

/**
 * 当前活动页签的文案：友好名 + kind 原值（P11 Q23）。读不到时给出明确说明。
 *
 * @param label - M2 给出的友好名（例如“文件”）。
 * @param key - 分类键（例如 `kind:files`）。
 * @returns 面向用户的文案。
 */
export function describeActiveTab(label: string | null, key: ContentKey | null): string {
  if (key === null || key === '') return '读不到（分类不可用）'
  const kind = key.startsWith('kind:') ? key.slice('kind:'.length) : key
  return label === null || label === '' ? kind : `${label}（${kind}）`
}

/**
 * 当前侧边栏尺寸与来源。
 *
 * P11 #3（D-002）起，区分模式沿父链解析：`本类型记录 → 上级记录 → … → 根记录 → DSH 默认`；
 * 统一模式仍只有一份值、不参与继承。解析用的查表回调只读 `savedEntries`，**继承值不会落盘**。
 *
 * @param input - 控制器快照与实际观测宽度。
 * @returns 宽度报告（数值 + 来源 + 文案）。
 */
export function deriveWidthReport(input: {
  readonly keeper: KeeperSnapshot | null
  readonly observedPx: number | null
}): WidthReport {
  const { keeper, observedPx } = input

  if (keeper === null) {
    return { px: observedPx, origin: 'default', fromLabel: null, fromKey: null, text: formatWidth(observedPx, 'default', null) }
  }
  // 统一模式：所有内容共用一份；未设置时走默认。
  if (keeper.perContent === false) {
    return keeper.unified === null
      ? { px: observedPx, origin: 'default', fromLabel: null, fromKey: null, text: formatWidth(observedPx, 'default', null) }
      : { px: keeper.unified, origin: 'own', fromLabel: null, fromKey: null, text: formatWidth(keeper.unified, 'own', null) }
  }

  const lookup = (candidate: ContentKey): number | null => {
    const found = keeper.savedEntries.find(item => item.key === candidate)
    return found === undefined ? null : found.px
  }
  const own = keeper.activeKey === null ? null : lookup(keeper.activeKey)
  const resolution = resolveWidth({ key: keeper.activeKey, own, lookup })

  if (resolution.origin === 'own') {
    return { px: resolution.value, origin: 'own', fromLabel: null, fromKey: null, text: formatWidth(resolution.value, 'own', null) }
  }
  if (resolution.origin === 'inherited' && resolution.fromKey !== null) {
    const fromLabel = describe(resolution.fromKey).labelFallback
    return {
      px: resolution.value,
      origin: 'inherited',
      fromLabel,
      fromKey: resolution.fromKey,
      text: formatWidth(resolution.value, 'inherited', fromLabel),
    }
  }
  return { px: observedPx, origin: 'default', fromLabel: null, fromKey: null, text: formatWidth(observedPx, 'default', null) }
}

/** 宽度文案：`540px（本类型记录 / 继承自 X / DSH 默认 / 读不到）`。 */
function formatWidth(px: number | null, origin: WidthOrigin, fromLabel: string | null): string {
  if (px === null) return '读不到'
  const suffix = origin === 'own'
    ? '本类型记录'
    : origin === 'inherited'
      ? `继承自 ${fromLabel ?? '上级内容页'}`
      : 'DSH 默认'
  return `${String(px)}px（${suffix}）`
}

/**
 * 生成可复制的日志报告（Q12：运行日志 + 状态快照 + 版本/环境）。
 *
 * **隐私约束**：调用方只传入白名单字段，函数内不会打印会话 id、页签标题或文件路径；
 * 如需变更内容，必须同步更新 `tests/status-report.test.mjs` 的“不得包含会话 id / 路径”用例。
 *
 * @param input - 版本、环境、快照与日志行。
 * @returns 纯文本报告。
 */
export function buildLogReport(input: {
  readonly pluginVersion: string
  readonly exportedAt: string
  readonly userAgent: string
  readonly viewportWidth: number | null
  readonly keeper: KeeperSnapshot | null
  readonly prefs: PrefsSnapshot | null
  readonly capability: HostCapability | null
  readonly activeTabText: string
  readonly widthText: string
  readonly logLines: readonly string[]
}): string {
  const run = deriveRunState({ keeper: input.keeper, prefs: input.prefs, capability: input.capability })
  const keeper = input.keeper
  const lines: string[] = [
    'dsh-sidebar-size 运行日志',
    `导出时间：${input.exportedAt}`,
    `插件版本：${input.pluginVersion}`,
    `宿主：${hostVersionOf(input.userAgent)}`,
    `视口宽：${input.viewportWidth === null ? '读不到' : `${String(input.viewportWidth)}px`}`,
    `运行状态：${run.label}${run.reason === null ? '' : `（${run.reason}）`}`,
    `阶段：${keeper === null ? '未接入' : keeper.state}`,
    `当前模式：${keeper === null || keeper.perContent === null ? '尚未确认' : keeper.perContent ? '区分内容' : '统一'}`,
    `当前活动页签：${input.activeTabText}`,
    `当前侧边栏尺寸：${input.widthText}`,
    `已保存类型数：${keeper === null ? '—' : String(keeper.savedEntries.length)}`,
    `统一值：${keeper === null || keeper.unified === null ? '未设置' : `${String(keeper.unified)}px`}`,
    `存储状态：${keeper === null
      ? '—'
      : `${keeper.storageStatus.available ? '可用' : '不可用'}`
        + `${keeper.storageStatus.protected ? '，原文受保护' : ''}`
        + `${keeper.dirty ? '，有未落盘改动' : '，已落盘'}`
        + `；启动读取 ${String(keeper.storageReads)} 次`}`,
    `结构健康：${keeper === null ? '—' : keeper.structureHealthy ? '正常' : `降级（${keeper.structureNote ?? '未知原因'}）`}`,
    `最近一次动作：${keeper?.lastAction == null
      ? '尚未执行'
      : `${keeper.lastAction.action} → ${keeper.lastAction.result.status}`
        + `${keeper.lastAction.result.resetLevel === undefined ? '' : `（恢复等级 ${keeper.lastAction.result.resetLevel}）`}`}`,
    `最近一次错误：${keeper?.error ?? '无'}`,
    '',
    `--- 控制器日志（最近 ${String(input.logLines.length)} 条，新的在后）---`,
    ...input.logLines,
  ]
  return lines.join('\n')
}

/** 从 UA 里取宿主版本（例如 `@deepseek-ai/dsh-desktop/0.2.0-rc.2`）；取不到时原样截断返回。 */
export function hostVersionOf(userAgent: string): string {
  const matched = /@deepseek-ai\/dsh-desktop\/([^\s;)]+)/.exec(userAgent)
  if (matched !== null) return `DSH 桌面 ${matched[1]}`
  return userAgent === '' ? '未知' : userAgent.slice(0, 120)
}

/**
 * 判断诊断区块是否应该渲染。
 *
 * @param raw - 存储键的原始值（未设置时为 null）。
 * @returns 值为 {@link DIAGNOSTICS_ON} 时为 true。
 */
export function diagnosticsEnabled(raw: string | null): boolean {
  return raw === DIAGNOSTICS_ON
}
