/**
 * 根生命周期与释放集合（实现规划 7.1/7.5 的最小实现）。
 *
 * 一个客户端插件实例只装配一个根生命周期。它负责两件事：
 *   1. 登记所有需要释放的资源（观察器、事件、计时、rAF、订阅、槽位贡献）；
 *   2. 提供幂等的 `dispose()`：重复调用复用同一个结束结果，任何一个释放步骤抛错都不阻止
 *      其余资源释放。
 *
 * 它**不是**控制器（M6）：这里不保存宽度表、不安排保存队列、不判断就绪状态。任务代次
 * （运行绑定代次、数据替换代次）也由 M6 持有（ST9）；本模块只提供实例身份与释放集合。
 *
 * @module dsh-sidebar-size/client/lifecycle
 */

import type { Disposer } from './contracts.ts'

/** 释放失败时的报告函数。默认走 console.warn，且保证自身不抛错。 */
export type LifecycleWarn = (message: string, error: unknown) => void

/** 根生命周期。 */
export interface RootLifecycle {
  /** 实例身份标记；用于日志与后续代次判断的基准。 */
  readonly id: string
  /** 是否已经释放。 */
  readonly disposed: boolean
  /** 已登记但尚未释放的资源数量（诊断用）。 */
  readonly pendingCount: number
  /**
   * 登记一个释放函数。
   * @param disposer - 释放函数。
   * @param label - 诊断标签，说明释放的是什么资源。
   */
  addDisposer(disposer: Disposer, label?: string): void
  /** 幂等释放：第一次调用真正释放，之后调用直接返回。 */
  dispose(): void
}

/** 收集本次运行登记的资源，并在释放时逐个隔离异常。 */
export function createRootLifecycle(warn: LifecycleWarn = defaultWarn): RootLifecycle {
  const id = `sidebar-size-${Math.random().toString(36).slice(2, 10)}`
  const entries: { disposer: Disposer; label: string }[] = []
  let disposed = false

  return {
    id,
    get disposed(): boolean {
      return disposed
    },
    get pendingCount(): number {
      return entries.length
    },
    addDisposer(disposer: Disposer, label = 'unnamed'): void {
      if (disposed) {
        // 释放之后再登记的资源立即释放，避免把它挂在一个已经结束的生命周期上。
        run(disposer, `${label} (registered after dispose)`, warn)
        return
      }
      entries.push({ disposer, label })
    },
    dispose(): void {
      if (disposed) return
      disposed = true
      // 逆序释放：后登记的资源可能依赖先登记的资源仍然存在。
      while (entries.length > 0) {
        const entry = entries.pop()
        if (entry !== undefined) run(entry.disposer, entry.label, warn)
      }
    },
  }
}

/** 执行一个释放函数，任何异常都只记录不外抛。 */
function run(disposer: Disposer, label: string, warn: LifecycleWarn): void {
  try {
    disposer()
  } catch (error) {
    try {
      warn(`释放资源失败（已忽略，继续释放其余资源）：${label}`, error)
    } catch {
      // 连报告方式本身都失败时也必须保持静默：dispose() 对外承诺不抛错。
    }
  }
}

/** 默认报告方式；自身也不允许抛错。 */
function defaultWarn(message: string, error: unknown): void {
  try {
    console.warn(`[dsh-sidebar-size] ${message}`, error)
  } catch {
    // 保持静默。
  }
}
