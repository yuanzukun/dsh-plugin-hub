/**
 * M3 WidthTable —— 内存宽度表：校验、查询、更新、枚举、替换、清空与序列化。
 *
 * 职责边界：
 *   * M3 是内存宽度表的**唯一修改者**；M5 只负责把序列化结果写到介质，不持有内存表；
 *   * 不直接持久化（什么时候写、写失败怎么办由 M6/M5 决定）；
 *   * 不读取当前模式偏好：`set(key, mode, px)` 的 mode 来自采样时捕获的归属。
 *
 * 数据结构（schema 1）：
 * ```json
 * { "schema": 1, "split": { "kind:files": 704 }, "unified": null }
 * ```
 *   * `unified: null` 表示“统一模式尚未保存”，**不能用 0 表示**（0 在布局里另有“不显示”的含义）；
 *   * `split` 缺少某个键表示该类型没有记录。
 *
 * 校验规则（实现规划 4.2）：
 *   * 整体必须是普通对象，`schema` 必须是受支持的版本；
 *   * `split` 必须是可枚举的普通对象，键必须是本版本的合法分类键；
 *   * 宽度必须是有限整数且不低于目标版本的正常列下限 300；保存值不以上一次当前窗口上限为界；
 *   * 非法条目**逐条剔除并报告**；整体结构损坏或版本不受支持时报告 `scope: 'root'` 的错误，
 *     由 M6 决定进入保护（保留原文、停止自动覆盖）。
 *
 * @module dsh-sidebar-size/client/width-table
 */

import { isContentKey } from './content-kind.ts'
import {
  WIDTH_SCHEMA_VERSION,
  type ContentKey,
  type Mode,
  type ParseError,
  type ParseResult,
  type PersistedShape,
  type TableWriteResult,
  type WidthEntry,
  type WidthTable,
} from './contracts.ts'

/** 目标版本正常右栏的下限（源码核验 S2 / columns.ts）。 */
export const MIN_WIDTH = 300

/** 无原型字典：外部键不参与原型链查找。 */
function emptyRecord<T>(): Record<string, T> {
  return Object.create(null) as Record<string, T>
}

/** 创建一个空表。 */
export function createWidthTable(): WidthTable {
  let split: Record<ContentKey, number> = emptyRecord<number>()
  let unified: number | null = null

  return {
    parse(value: unknown): ParseResult {
      const errors: ParseError[] = []
      if (!isPlainObject(value)) {
        return {
          table: { schema: WIDTH_SCHEMA_VERSION, split: {}, unified: null },
          errors: [{ scope: 'root', reason: '宽度数据不是对象' }],
          unsupportedVersion: false,
        }
      }

      const schema = (value as { schema?: unknown }).schema
      if (typeof schema !== 'number' || !Number.isInteger(schema)) {
        return {
          table: { schema: WIDTH_SCHEMA_VERSION, split: {}, unified: null },
          errors: [{ scope: 'root', reason: '缺少可识别的 schema 字段' }],
          unsupportedVersion: false,
        }
      }
      if (schema > WIDTH_SCHEMA_VERSION) {
        return {
          table: { schema: WIDTH_SCHEMA_VERSION, split: {}, unified: null },
          errors: [{ scope: 'root', reason: `数据版本 ${String(schema)} 高于本插件支持的 ${String(WIDTH_SCHEMA_VERSION)}` }],
          unsupportedVersion: true,
        }
      }
      if (schema < WIDTH_SCHEMA_VERSION) {
        return {
          table: { schema: WIDTH_SCHEMA_VERSION, split: {}, unified: null },
          errors: [{ scope: 'root', reason: `数据版本 ${String(schema)} 低于本插件支持的 ${String(WIDTH_SCHEMA_VERSION)}，没有迁移规则` }],
          unsupportedVersion: false,
        }
      }

      const splitValue = (value as { split?: unknown }).split
      const parsedSplit = emptyRecord<number>()
      if (splitValue !== undefined) {
        if (!isPlainObject(splitValue)) {
          errors.push({ scope: 'root', reason: 'split 不是对象' })
        } else {
          for (const [key, raw] of Object.entries(splitValue)) {
            if (!isContentKey(key)) {
              errors.push({ scope: 'split', key, reason: '键不是本版本的分类键格式' })
              continue
            }
            if (!isValidWidth(raw)) {
              errors.push({ scope: 'split', key, reason: `宽度必须是 ≥ ${String(MIN_WIDTH)} 的整数` })
              continue
            }
            parsedSplit[key] = raw
          }
        }
      }

      const unifiedValue = (value as { unified?: unknown }).unified
      let parsedUnified: number | null = null
      if (unifiedValue !== undefined && unifiedValue !== null) {
        if (isValidWidth(unifiedValue)) parsedUnified = unifiedValue
        else errors.push({ scope: 'root', reason: `unified 必须是 null 或 ≥ ${String(MIN_WIDTH)} 的整数` })
      }

      return {
        table: { schema: WIDTH_SCHEMA_VERSION, split: parsedSplit, unified: parsedUnified },
        errors,
        unsupportedVersion: false,
      }
    },

    get(key: ContentKey, mode: Mode): number | null {
      if (mode === 'unified') return unified
      const value = split[key]
      return value === undefined ? null : value
    },

    set(key: ContentKey, mode: Mode, px: number): TableWriteResult {
      if (!isValidWidth(px)) return 'rejected'
      // unified 命名空间没有键（所有内容共用一份），因此这一支不校验键。
      if (mode === 'unified') {
        if (unified === px) return 'rejected'
        unified = px
        return 'changed'
      }
      if (!isContentKey(key)) return 'rejected'
      if (split[key] === px) return 'rejected'
      split[key] = px
      return 'changed'
    },

    entries(mode: Mode): readonly WidthEntry[] {
      if (mode === 'unified') {
        return unified === null ? [] : [{ key: '', kind: '', px: unified }]
      }
      // 只读快照：外部拿到的数组不能反过来修改内部表。
      return Object.entries(split)
        .map(([key, px]) => ({ key, kind: key, px }))
        .sort((left, right) => (left.key < right.key ? -1 : left.key > right.key ? 1 : 0))
    },

    replace(table: PersistedShape): void {
      split = emptyRecord<number>()
      for (const [key, px] of Object.entries(table.split)) {
        if (isContentKey(key) && isValidWidth(px)) split[key] = px
      }
      unified = table.unified !== null && isValidWidth(table.unified) ? table.unified : null
    },

    clearAll(): void {
      split = emptyRecord<number>()
      unified = null
    },

    serialize(): PersistedShape {
      const plain: Record<ContentKey, number> = {}
      for (const [key, px] of Object.entries(split)) plain[key] = px
      return { schema: WIDTH_SCHEMA_VERSION, split: plain, unified }
    },
  }
}

/** 是否是普通对象（排除数组、null 与类实例）。 */
function isPlainObject(value: unknown): value is Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return false
  const prototype = Object.getPrototypeOf(value) as unknown
  return prototype === Object.prototype || prototype === null
}

/** 宽度是否合法：有限整数且不低于下限。 */
export function isValidWidth(value: unknown): value is number {
  return typeof value === 'number' && Number.isInteger(value) && value >= MIN_WIDTH
}
