/**
 * dsh-sidebar-size —— client 半（浏览器）入口。
 *
 * 装配三件事：
 *   1. 根生命周期（幂等释放、异常隔离）；
 *   2. 诊断面（P02 实验级的观察数据与显式实验动作，不是 M6）；
 *   3. 设置分组「侧边栏尺寸」的注册。
 *
 * 服务依赖分两层，原因是“设置页必须一直可用”：
 *   * 顶层 `inject` 只要 `slots`（注册设置分组所需，Web 组合里始终存在）；
 *   * 宿主服务（`configForms` / `sidebarRight` / `layout`）用**动态注入**：缺失或迟到时
 *     这一块不运行，设置页照旧显示“未就绪”，服务恢复后再接入。这样布局服务暂时不可用
 *     不会让整个设置入口消失。
 *
 * 运行期值**不 import 任何 DSH 内部模块**：所有 DSH 包都是 type-only（构建期擦除），
 * 能力一律通过 cordis 服务取得；因此客户端 bundle 的 external 只有平台模块表。
 *
 * @module dsh-sidebar-size/client
 */

import type { Context } from '@deepseek-ai/cordis'
// 仅类型：拉入 Context 上的 slots / configForms / sidebarRight / layout 服务声明。
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar-right/client'
import type {} from '@deepseek-ai/dsh-client-ui-layout/client'
import { createDiagnosticsSurface, markPluginApplied } from './diagnostics.ts'
import { createController } from './controller.ts'
import { createHostBridge } from './host-bridge.ts'
import { createRootLifecycle } from './lifecycle.ts'
import { createPreferences } from './preferences.ts'
import { createWidthTable } from './width-table.ts'
import { createWidthStore } from './width-store.ts'
import { SidebarSizeSection } from './settings-section.tsx'

/** client 半的插件名（与 host 半分开命名，便于诊断区分两侧）。 */
export const name = 'sidebar-size-client'

/** 注册设置分组所需的服务；宿主服务按动态注入处理，不在此列。 */
export const inject = ['slots']

/** 设置分组在导航里的标识与顺序。 */
const SECTION_ID = 'sidebar-size'
const SECTION_ORDER = 60

/**
 * 装配插件。
 * @param ctx - client 根上下文。
 */
export function apply(ctx: Context): void {
  try {
    markPluginApplied()
    const lifecycle = createRootLifecycle()
    ctx.effect(() => () => lifecycle.dispose(), 'dsh-sidebar-size: root lifecycle')

    const diagnostics = createDiagnosticsSurface()
    lifecycle.addDisposer(() => diagnostics.dispose(), 'diagnostics surface')

    // 宿主服务：可用时接入 M1/M8/M6，不可用时保持“未就绪”，设置页不受影响。
    ctx.inject(['configForms', 'sidebarRight', 'layout'], (sctx) => {
      sctx.effect(
        () => {
          const bridge = createHostBridge({
            document: globalThis.document,
            layout: sctx.layout,
            sidebarRight: sctx.sidebarRight,
          })
          const preferences = createPreferences(sctx)
          const table = createWidthTable()
          const store = createWidthStore()
          const keeper = createController({
            lifecycle,
            prefs: preferences,
            store,
            table,
            host: bridge,
            log: (line: string) => diagnostics.log(line),
          })
          lifecycle.addDisposer(() => { void keeper.dispose() }, 'controller')
          diagnostics.attach({ bridge, prefs: preferences, keeper })
          // 控制器的装配顺序由它自己保证（订阅偏好 → 一次性读取 → 首次确认后决定阶段）。
          void keeper.start()
          return () => {
            diagnostics.detach()
            void keeper.dispose()
            bridge.dispose()
            preferences.dispose()
          }
        },
        'dsh-sidebar-size: host assembly (M1/M8/M6)',
      )
    })

    // 设置分组：等待设置外壳声明该槽位后再注册；槽位消失时注册自动失效。
    ctx.effect(
      () => ctx.slots.inject('settings.section', () => ctx.slots.register({
        name: 'settings.section',
        id: SECTION_ID,
        order: SECTION_ORDER,
        // P07 接入 locale 词典后改为按语言返回；本阶段先用固定中文。
        label: '侧边栏尺寸',
        inject: () => ({ diagnostics }),
      }, SidebarSizeSection)),
      'dsh-sidebar-size: settings section',
    )
  } catch (error) {
    // client 插件抛错会打断整条客户端装配链，因此这里只记录、绝不上抛。
    warn(error)
  }
}

/** 装配失败只记录，保证 DSH 界面照常运行。 */
function warn(error: unknown): void {
  try {
    console.warn('[dsh-sidebar-size] client 装配失败（已忽略，界面照常）：', error)
  } catch {
    // 保持静默。
  }
}

