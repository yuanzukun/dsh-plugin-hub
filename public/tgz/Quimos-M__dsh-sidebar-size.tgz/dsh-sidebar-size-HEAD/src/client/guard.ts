/**
 * M4 Guard —— 判断一次尺寸变化是不是“用户对正常右栏的拖拽”，以及它属于哪一次提交。
 *
 * 职责边界：
 *   * 只依据 M1 提供的信号与采样做判断，**不读 DOM、不读服务、不写表**；
 *   * 输出“被接受的采样”（携带固定归属），由 M6 决定写内存表还是排队保存；
 *   * 不负责应用宽度（那是 M1/M6），也不负责持久化（M5）。
 *
 * 判据（实现规划 5.4）：
 *   1. 必须有一次从**正常右栏手柄**开始、被接受的真实指针按下；
 *   2. 采样必须落在“仍可能产生归属尺寸”的指针提交窗口内（`sample.valid` 与
 *      `pointerCommitSeq` 都由 M1 依据提交窗口给出）；
 *   3. 采样的面板身份必须与按下时的正常面板一致；
 *   4. 手势期间几何代次发生变化（窗口缩放、左栏占用变化、展示模式变化）就**停止采纳新尺寸**，
 *      保留最后可信值——环境变化不是用户意图；
 *   5. 抬起后保留 Ending 一段时间，让宿主 pointerup 的最后一次位置提交进来；之后正常到达的
 *      `capture-released` 不取消已经接受的 Ending 最终采样，只有**尚未**接受 pointerup 的
 *      意外捕获丢失才走取消路径。
 *
 * @module dsh-sidebar-size/client/guard
 */

import type { AcceptedSample, DragContext, DragSignal, Guard, WidthSample } from './contracts.ts'

/** 手势阶段。 */
export type GuardPhase = 'idle' | 'dragging' | 'ending'

/** 手势被拒绝的原因（诊断与实验记录用）。 */
export type GuardRejection =
  | 'no-gesture'
  | 'sample-invalid'
  | 'panel-mismatch'
  | 'commit-mismatch'
  | 'geometry-changed'

/** M4 对外接口（在通用 Guard 之外补充诊断读取）。 */
export interface GuardProbe extends Guard {
  phase(): GuardPhase
  /** 最近一次被拒绝的原因；没有拒绝过为 null。 */
  lastRejection(): GuardRejection | null
  /** 是否已经看到并接受了 pointerup（用于区分正常捕获释放与意外丢失）。 */
  pointerUpSeen(): boolean
  /** 最近一次被接受的采样。 */
  lastAccepted(): AcceptedSample | null
  /** 被接受的采样条数（诊断用）。 */
  acceptedCount(): number
}

export function createGuard(): GuardProbe {
  let phase: GuardPhase = 'idle'
  let context: DragContext | null = null
  let dragId = 0
  /** 本次手势第一个被接受采样的几何代次；之后不一致就说明环境变了。 */
  let gestureGeometry: number | null = null
  /** 本次手势的指针提交序号（由第一条被接受的采样确定）。 */
  let commit: number | null = null
  let sawPointerUp = false
  let lastSample: AcceptedSample | null = null
  let accepted = 0
  let rejection: GuardRejection | null = null

  function reject(reason: GuardRejection): null {
    rejection = reason
    return null
  }

  function reset(): void {
    phase = 'idle'
    context = null
    gestureGeometry = null
    commit = null
    sawPointerUp = false
  }

  return {
    beginDrag(next: DragContext): 'accepted' | 'rejected' {
      if (phase !== 'idle') return 'rejected'
      if (next.key === '' || next.panelIdentity.elementId === '') return 'rejected'
      dragId += 1
      context = next
      gestureGeometry = null
      commit = null
      sawPointerUp = false
      rejection = null
      phase = 'dragging'
      return 'accepted'
    },

    acceptSample(sample: WidthSample): AcceptedSample | null {
      if (phase === 'idle' || context === null) return reject('no-gesture')
      if (!sample.valid || sample.pointerCommitSeq === null) return reject('sample-invalid')
      if (sample.panelIdentity.elementId !== context.panelIdentity.elementId) return reject('panel-mismatch')
      // Ending 阶段只继续接受同一个指针提交的结果（宿主的最后一次位置提交）。
      if (phase === 'ending' && commit !== null && sample.pointerCommitSeq !== commit) return reject('commit-mismatch')
      // 手势开始后的第一条采样确定本次手势的几何代次；之后变化就停止采纳。
      if (gestureGeometry === null) {
        gestureGeometry = sample.geometryGeneration
        if (commit === null) commit = sample.pointerCommitSeq
      } else if (sample.geometryGeneration !== gestureGeometry) {
        return reject('geometry-changed')
      }

      const acceptedSample: AcceptedSample = {
        key: context.key,
        mode: context.mode,
        px: sample.px,
        dragId,
        generation: context.generation,
      }
      lastSample = acceptedSample
      accepted += 1
      rejection = null
      return acceptedSample
    },

    beginEnding(signal: DragSignal): void {
      if (phase === 'idle') return
      if (signal.kind === 'pointer-up') {
        sawPointerUp = true
        phase = 'ending'
        return
      }
      if (signal.kind === 'capture-released') {
        // 抬起之后正常到达的捕获释放：不取消已经接受的最终采样。
        if (sawPointerUp) {
          phase = 'ending'
          return
        }
        // 尚未接受 pointerup 的意外丢失：按取消路径处理（保留最后可信值）。
        reset()
        return
      }
      if (signal.kind === 'cancelled') reset()
      // pointer-down 不在这里改变阶段（由 beginDrag 单独处理）。
    },

    finishDrag(): void {
      reset()
    },

    canApply(): boolean {
      return phase === 'idle'
    },

    cancel(_reason: string): void {
      reset()
    },

    phase: () => phase,
    lastRejection: () => rejection,
    pointerUpSeen: () => sawPointerUp,
    lastAccepted: () => lastSample,
    acceptedCount: () => accepted,
  }
}
