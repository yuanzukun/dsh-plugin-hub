/**
 * M8 Preferences —— 宿主配置表单的客户端适配器。
 *
 * 职责：把 DSH 的共享配置表单（`ctx.configForms.get(entryId)`）适配成本项目需要的
 * “最后确认值 + 订阅 + 异步写入结果”。开关的值属于**宿主设置的确认状态**，不是界面草稿，
 * 也不是宽度数据。
 *
 * 明确不做的事：不保存宽度、不读取或写入宽度存储、不直接操作 localStorage 或 DOM。
 *
 * 依据固定版本类型（@deepseek-ai/dsh-client-ui-settings@0.2.0-rc.2 的
 * `lib/types/client/config-form-types.d.ts`）：
 *   getSnapshot(): { status: 'loading'|'ready'|'unavailable', value: T|undefined, base, user,
 *                    revision: number|undefined, writable, mode: 'host'|'memory' }
 *   subscribe(listener: () => void): () => void
 *   set(field: string, value: unknown): Promise<boolean>    // true = 宿主接受
 *   unset(field: string): Promise<boolean>
 *   mutate(ops, expectedRevision?): Promise<boolean>
 * 写入返回 false 表示宿主拒绝或跳过；传输失败会 reject，必须捕获。
 *
 * @module dsh-sidebar-size/client/preferences
 */

import type { Context } from '@deepseek-ai/cordis'
import type { ConfigForm, ConfigFormSnapshot } from '@deepseek-ai/dsh-client-ui-settings/client'
import type {
  Disposer,
  Preferences,
  PrefsPatch,
  PrefsSnapshot,
  PrefsWriteResult,
} from './contracts.ts'

/** 标准安装下的宿主条目 id；设置表单按该 id 定位（实现规划 2.3）。 */
export const STANDARD_ENTRY_ID = 'sidebar-size'

/** `ensure()` 等待首次确认值的最长时间；超时后返回当时的快照（通常仍是 loading）。 */
const ENSURE_TIMEOUT_MS = 10_000

/** 两个开关的确认取值。 */
interface SwitchValues {
  readonly enabled: boolean
  readonly perContent: boolean
}

/**
 * 创建 M8 适配器。
 * @param ctx - client 上下文（必须已经注入 configForms）。
 * @param entryId - 宿主条目 id，默认 {@link STANDARD_ENTRY_ID}。
 * @returns Preferences 接口实现。
 */
export function createPreferences(ctx: Context, entryId: string = STANDARD_ENTRY_ID): Preferences {
  const form: ConfigForm<unknown> = ctx.configForms.get<unknown>(entryId)
  const listeners = new Set<(snapshot: PrefsSnapshot) => void>()
  let disposed = false
  let current: PrefsSnapshot = project(form.getSnapshot(), undefined)

  /** 把宿主表单快照投影成本项目的设置快照。 */
  function project(raw: ConfigFormSnapshot<unknown>, error: string | undefined): PrefsSnapshot {
    const values = raw.status === 'ready' ? decodeValues(raw.value) : null
    const snapshot: PrefsSnapshot = {
      // 状态是 ready 但取值形状不合法时，视为尚未确认：不得按默认值动作。
      state: raw.status === 'ready' && values === null ? 'loading' : raw.status,
      enabled: values?.enabled ?? null,
      perContent: values?.perContent ?? null,
      revision: raw.revision ?? null,
      writable: raw.writable,
      mode: raw.mode,
    }
    const reason = error ?? (raw.status === 'ready' && values === null ? '宿主设置值形状不符合预期（需要两个布尔字段）' : undefined)
    return reason === undefined ? snapshot : { ...snapshot, error: reason }
  }

  /** 重新投影并通知订阅方（只有真的变化才通知）。 */
  function refresh(error?: string): void {
    if (disposed) return
    const next = project(form.getSnapshot(), error)
    if (sameSnapshot(current, next)) return
    current = next
    for (const listener of listeners) safeNotify(listener, next)
  }

  function subscribe(listener: (snapshot: PrefsSnapshot) => void): Disposer {
    if (disposed) return () => {}
    listeners.add(listener)
    return () => {
      listeners.delete(listener)
    }
  }

  async function ensure(): Promise<PrefsSnapshot> {
    if (current.state !== 'loading') return current
    await new Promise<void>((resolve) => {
      let settled = false
      const finish = (): void => {
        if (settled) return
        settled = true
        clearTimeout(timer)
        stop()
        resolve()
      }
      const timer = setTimeout(finish, ENSURE_TIMEOUT_MS)
      const stop = subscribe(() => {
        if (current.state !== 'loading') finish()
      })
      if (current.state !== 'loading') finish()
    })
    return current
  }

  async function update(patch: PrefsPatch): Promise<PrefsWriteResult> {
    const before = current
    if (before.state === 'unavailable') {
      return { ok: false, snapshot: before, reason: '设置服务不可用：本页面不连接宿主设置文档' }
    }
    if (before.state !== 'ready') {
      return { ok: false, snapshot: before, reason: '设置尚未就绪：还没有收到宿主的确认值' }
    }
    if (!before.writable) {
      return { ok: false, snapshot: before, reason: '宿主设置文档当前不可写（memory 模式）' }
    }

    const operations: [keyof SwitchValues, boolean][] = []
    if (patch.enabled !== undefined) operations.push(['enabled', patch.enabled])
    if (patch.perContent !== undefined) operations.push(['perContent', patch.perContent])
    if (operations.length === 0) return { ok: true, snapshot: before }

    try {
      for (const [field, value] of operations) {
        const accepted = await form.set(field, value)
        if (!accepted) {
          // 宿主拒绝：重新读取最新宿主值，不把草稿当作已生效。
          refresh(`宿主拒绝了 ${field} 的写入，已保留原确认值`)
          return { ok: false, snapshot: current, reason: `宿主拒绝写入 ${field}` }
        }
      }
    } catch (error) {
      refresh(`设置写入失败：${messageOf(error)}`)
      return { ok: false, snapshot: current, reason: `设置写入失败：${messageOf(error)}` }
    }

    refresh()
    return { ok: true, snapshot: current }
  }

  function dispose(): void {
    if (disposed) return
    disposed = true
    listeners.clear()
    unsubscribeForm()
  }

  const unsubscribeForm = form.subscribe(() => refresh())

  return {
    getSnapshot: () => current,
    subscribe,
    ensure,
    update,
    dispose,
  }
}

/** 校验并取出两个布尔开关；形状不合法时返回 null（视为尚未确认）。 */
function decodeValues(value: unknown): SwitchValues | null {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return null
  const record = value as Record<string, unknown>
  const enabled = record.enabled
  const perContent = record.perContent
  if (typeof enabled !== 'boolean' || typeof perContent !== 'boolean') return null
  return { enabled, perContent }
}

/** 快照是否需要通知订阅方。 */
function sameSnapshot(left: PrefsSnapshot, right: PrefsSnapshot): boolean {
  return left.state === right.state
    && left.enabled === right.enabled
    && left.perContent === right.perContent
    && left.revision === right.revision
    && left.writable === right.writable
    && left.mode === right.mode
    && left.error === right.error
}

/** 订阅方抛错不能影响其他订阅方与插件自身。 */
function safeNotify(listener: (snapshot: PrefsSnapshot) => void, snapshot: PrefsSnapshot): void {
  try {
    listener(snapshot)
  } catch (error) {
    try {
      console.warn('[dsh-sidebar-size] 设置订阅回调抛错（已忽略）：', error)
    } catch {
      // 保持静默。
    }
  }
}

/** 把未知异常转成一句可显示的原因。 */
function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}
