import { afterEach, expect, test, vi } from 'vitest'
import { markOfficialTurnNavigators, observeOfficialTurnNavigators } from '../src/client/official-turn-navigator.ts'

afterEach(() => {
  document.body.replaceChildren()
  delete document.documentElement.dataset.dcuOfficialTurnNavigatorSupported
  vi.restoreAllMocks()
})

function officialNavigator(): HTMLElement {
  const nav = document.createElement('nav')
  nav.style.setProperty('--turn-natural-height', '72px')
  const marks = document.createElement('div')
  const button = document.createElement('button')
  button.type = 'button'
  button.setAttribute('aria-label', '跳转到第 1 轮')
  marks.append(button)
  const tooltip = document.createElement('div')
  tooltip.role = 'tooltip'
  nav.append(marks, tooltip)
  return nav
}

test('实际官方导航不依赖宿主层级也能获得稳定标记', () => {
  const wrapper = document.createElement('section')
  const nested = document.createElement('aside')
  const nav = officialNavigator()
  nested.append(nav)
  wrapper.append(nested)
  document.body.append(wrapper)

  expect(markOfficialTurnNavigators(document)).toBe(1)
  expect(nav.dataset.dcuOfficialTurnNavigator).toBe('true')
  expect(nav.querySelector('button')?.dataset.dcuOfficialTurnMark).toBeUndefined()
  expect(nav.querySelector('[role="tooltip"]')?.getAttribute('data-dcu-official-turn-tooltip')).toBeNull()
})

test('普通导航不会被误认为官方轮次导航', () => {
  const nav = document.createElement('nav')
  nav.append(document.createElement('button'))
  document.body.append(nav)

  expect(markOfficialTurnNavigators(document)).toBe(0)
  expect(nav.hasAttribute('data-dcu-official-turn-navigator')).toBe(false)
})

test('0.1.7 官方导航不再内联高度变量时仍按刻度按钮识别', () => {
  const nav = document.createElement('nav')
  nav.setAttribute('aria-label', '轮次导航')
  const button = document.createElement('button')
  button.type = 'button'
  button.setAttribute('aria-label', '跳转到第 1 轮')
  button.dataset.index = '0'
  nav.append(button)
  document.body.append(nav)

  expect(markOfficialTurnNavigators(document)).toBe(1)
  expect(nav.dataset.dcuOfficialTurnNavigator).toBe('true')
})

test('带标签的侧栏导航没有轮次刻度时不会被标记', () => {
  const nav = document.createElement('nav')
  nav.setAttribute('aria-label', '主导航')
  const button = document.createElement('button')
  button.type = 'button'
  button.setAttribute('aria-label', '新任务')
  nav.append(button)
  document.body.append(nav)

  expect(markOfficialTurnNavigators(document)).toBe(0)
})

test('观察器会标记稍后挂载的官方导航并在停用时清理', async () => {
  const stop = observeOfficialTurnNavigators(document, async () => new Response(JSON.stringify({
    capabilities: { officialTurnNavigator: false },
  })))
  const nav = officialNavigator()
  document.body.append(nav)
  await new Promise(resolve => setTimeout(resolve, 20))

  expect(nav.dataset.dcuOfficialTurnNavigator).toBe('true')
  stop()
  expect(nav.hasAttribute('data-dcu-official-turn-navigator')).toBe(false)
})

test('运行时能力会独立关闭旧导航，避免私有 DOM 信号失效时双导航', async () => {
  const stop = observeOfficialTurnNavigators(document, async () => new Response(JSON.stringify({
    capabilities: { officialTurnNavigator: true },
  }), { status: 200 }))
  await new Promise(resolve => setTimeout(resolve, 0))

  expect(document.documentElement.dataset.dcuOfficialTurnNavigatorSupported).toBe('true')
  stop()
  expect(document.documentElement.hasAttribute('data-dcu-official-turn-navigator-supported')).toBe(false)
})

test('全局观察：任何 childList 变更都按帧调度（官方导航是懒挂载的）', async () => {
  document.body.append(officialNavigator())
  let queuedFrame: FrameRequestCallback | undefined
  const requestFrame = vi.spyOn(window, 'requestAnimationFrame').mockImplementation(callback => {
    queuedFrame = callback
    return 1
  })
  const stop = observeOfficialTurnNavigators(document, async () => new Response(JSON.stringify({
    capabilities: { officialTurnNavigator: false },
  })))
  expect(requestFrame).toHaveBeenCalledTimes(1)
  queuedFrame?.(0)

  // 2026-10-18：原先这条断言要求「插入无关 <p> 不调度」——正是这个优化造成漏检。
  // 实测宿主先插入空的 <div class="JXrxFq_slot">，19ms 后才把 nav 填进去；
  // 那次「填充」如果被过滤掉，官方导航就永远标不上，本插件会以为宿主没有官方刻度，
  // 自绘的那条便一直存在（视觉上就是「左右各一条索引栏」）。
  // 现在所有 childList 变更都会调度，rAF 已做合并，代价可忽略。
  document.body.append(document.createElement('p'))
  await Promise.resolve()
  expect(requestFrame).toHaveBeenCalledTimes(2)
  queuedFrame?.(0)

  document.body.append(officialNavigator())
  await Promise.resolve()
  expect(requestFrame).toHaveBeenCalledTimes(3)
  stop()
})
