import { createRequire } from 'node:module'
import type { SessionListState, SessionSummary } from '@deepseek-ai/dsh-api-session-controller/client'
import type { SessionId } from '@deepseek-ai/dsh-session/types'
import { act, createElement, type ReactNode } from 'react'
import { afterEach, expect, test, vi } from 'vitest'
import { ChannelBrowser } from '../src/client/ChannelBrowser.tsx'
import { CodexWorkspaceBrowser } from '../src/client/CodexWorkspaceBrowser.tsx'
import { ScheduleBrowser } from '../src/client/ScheduleBrowser.tsx'
import { WORKSPACE_GROUPS_STORAGE_KEY } from '../src/client/pinned-workspaces.ts'
import type { PendingInteractionSnapshot, UseSessionPendingInteraction, UseSessionStatus } from '../src/client/session-pending.ts'
import type { SessionStatusSnapshot } from '../src/client/session-host.ts'
import type { PendingInteractionKind } from '../src/client/session-pending.ts'
import { createWorkspaceShortcutSource } from '../src/client/workspace-shortcuts.ts'

const createRoot = (createRequire(import.meta.url)('react-dom/client') as {
  createRoot: (container: Element) => { render: (node: ReactNode) => void; unmount: () => void }
}).createRoot

const t = (key: string): string => ({
  'sessions.waitingAnswer': '等待回答',
  'sessions.waitingApproval': '等待审批',
  'sessions.planReview': '计划待审',
}[key] ?? key)

const sessionActions = {
  openSession: () => {},
  archiveSession: async () => {},
  deleteSession: async () => {},
  forkSession: async () => {},
  renameSession: async () => {},
}

const EMPTY_PENDING_INTERACTIONS: PendingInteractionSnapshot = new Map()
const useEmptyPendingInteractions: UseSessionPendingInteraction = selector => selector(EMPTY_PENDING_INTERACTIONS)

type LegacySessionSummary = SessionSummary & { pendingInteraction?: PendingInteractionKind }

function createSession(id: string, displayTitle: string, pendingInteraction: PendingInteractionKind | undefined): LegacySessionSummary {
  return {
    id: id as SessionId,
    displayTitle,
    running: true,
    pendingInteraction,
    blank: false,
    updatedAt: Date.parse('2026-09-01T00:00:00.000Z'),
    retainedBy: {},
  }
}

function createSessionStore(session: SessionSummary) {
  const state: SessionListState = {
    ids: [session.id],
    byId: { [session.id]: session },
    phase: 'ready',

    projectionsBySession: {},
  }
  return <T,>(selector: (snapshot: SessionListState) => T): T => selector(state)
}

function createPendingInteractionStore(sessionId: string, kind: PendingInteractionKind): UseSessionPendingInteraction {
  const state = new Map([[sessionId, { kind }]])
  return selector => selector(state)
}

function createSessionStatusStore(sessionId: string, kind: PendingInteractionKind): UseSessionStatus {
  const state: SessionStatusSnapshot = new Map([[sessionId, { pendingInteraction: { kind }, running: true }]])
  return selector => selector(state)
}

function createDataTransfer(): DataTransfer {
  const values = new Map<string, string>()
  return {
    effectAllowed: 'uninitialized',
    dropEffect: 'none',
    getData: (type: string) => values.get(type) ?? '',
    setData: (type: string, value: string) => { values.set(type, value) },
    setDragImage: () => {},
  } as unknown as DataTransfer
}

function dispatchDrag(target: Element, type: 'dragstart' | 'dragover' | 'dragleave' | 'dragend' | 'drop', dataTransfer: DataTransfer, relatedTarget?: EventTarget | null): void {
  const event = new Event(type, { bubbles: true, cancelable: true })
  Object.defineProperty(event, 'dataTransfer', { value: dataTransfer })
  Object.defineProperty(event, 'clientY', { value: 0 })
  if (relatedTarget !== undefined) Object.defineProperty(event, 'relatedTarget', { value: relatedTarget })
  target.dispatchEvent(event)
}

async function render(node: ReactNode) {
  const container = document.createElement('div')
  document.body.appendChild(container)
  const root = createRoot(container)
  await act(async () => {
    root.render(node)
    await Promise.resolve()
    await Promise.resolve()
  })
  return {
    container,
    dispose: async () => {
      await act(async () => { root.unmount() })
      container.remove()
    },
  }
}

test('添加工作区按钮随官方入口启停和快捷键目录实时更新', async () => {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
  const listeners = new Set<() => void>()
  const shortcutListeners = new Set<() => void>()
  let rows = [{ id: 'workspace.add', aria: 'Control+O' }]
  const request = vi.fn()
  const official = { locale: 'workspace', inject: () => ({
    requestAddWorkspace: request,
    closeAddWorkspace: () => {}, setDirectoryBusy: () => {}, createWorkspace: async () => ({ workspaceId: 'new' }),
    hooks: {
      workspaceShortcuts: { getSnapshot: () => ({ searchRequest: 0, addRequested: false }), subscribe: () => () => {} },
      shortcuts: { getSnapshot: () => rows, subscribe: (listener: () => void) => { shortcutListeners.add(listener); return () => { shortcutListeners.delete(listener) } } },
    },
  }) }
  let present = false
  const source = createWorkspaceShortcutSource({ entries: () => present ? [official] : [], subscribe: (_key, listener) => { listeners.add(listener); return () => { listeners.delete(listener) } } })
  const workspaces = { baselinesReady: true, archivedSessionIds: [], items: [] }
  const view = await render(createElement(CodexWorkspaceBrowser, {
    ...sessionActions, wide: true, useSessions: createSessionStore(createSession('unused', 'unused', undefined)),
    useSessionPendingInteraction: useEmptyPendingInteractions,
    useWorkspaces: (select: (snapshot: typeof workspaces) => unknown) => select(workspaces), t,
    workspaceShortcuts: source, deleteWorkspace: vi.fn(), insertSessionBefore: vi.fn(), insertWorkspaceBefore: vi.fn(), openPath: vi.fn(), renameWorkspace: vi.fn(), startSession: vi.fn(),
  } as never))
  const button = () => view.container.querySelector<HTMLButtonElement>('[aria-label="workspace.add"]')!
  try {
    expect(button().disabled).toBe(true)
    await act(async () => { present = true; for (const notify of listeners) notify() })
    expect(button().disabled).toBe(false)
    expect(button().getAttribute('aria-keyshortcuts')).toBe('Control+O')
    await act(async () => { rows = [{ id: 'workspace.add', aria: 'Alt+O' }]; for (const notify of shortcutListeners) notify() })
    expect(button().getAttribute('aria-keyshortcuts')).toBe('Alt+O')
    await act(async () => { button().click() })
    expect(request).toHaveBeenCalledTimes(1)
    await act(async () => { present = false; for (const notify of listeners) notify() })
    expect(button().disabled).toBe(true)
    expect(button().getAttribute('aria-keyshortcuts')).toBeNull()
  } finally {
    await view.dispose()
    source.dispose()
    expect(shortcutListeners.size).toBe(0)
  }
})

test('跨置顶、分组与未分组悬停不依赖 dragleave，结束清空所有落点', async () => {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
  const workspaceGroups = [{ id: 'first', title: 'First', workspaceIds: ['a', 'b'] }]
  const workspaces = { baselinesReady: true, archivedSessionIds: [], items: ['a', 'b', 'c'].map(id => ({ workspaceId: id, title: id, path: `D:/${id}`, sessionIds: [] })) }
  vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ exists: true, pinnedWorkspaceIds: ['a', 'c'], workspaceGroups }))))
  const view = await render(createElement(CodexWorkspaceBrowser, {
    ...sessionActions, wide: true, useSessions: createSessionStore(createSession('unused', 'unused', undefined)),
    useSessionPendingInteraction: useEmptyPendingInteractions,
    useWorkspaces: (selector: (snapshot: typeof workspaces) => unknown) => selector(workspaces), t,
    deleteWorkspace: vi.fn(), insertSessionBefore: vi.fn(), insertWorkspaceBefore: vi.fn(), openPath: vi.fn(), renameWorkspace: vi.fn(), startSession: vi.fn(),
  } as never))
  try {
    const pinned = view.container.querySelectorAll('.dcu-wb-pinned-list .dcu-wb-project-head')
    const group = view.container.querySelector('.dcu-wb-collection')!
    const ungrouped = view.container.querySelector('.dcu-wb-ungrouped')!
    const transfer = createDataTransfer()
    const markers = () => view.container.querySelectorAll('.dcu-wb-drop,.dcu-wb-group-order-drop,.dcu-wb-workspace-move-drop')
    await act(async () => { dispatchDrag(pinned[1]!, 'dragstart', transfer) })
    await act(async () => { dispatchDrag(pinned[0]!, 'dragover', transfer) })
    expect(markers()).toHaveLength(1)
    await act(async () => { dispatchDrag(group, 'dragover', transfer) })
    expect(markers()).toHaveLength(1)
    expect(group.classList.contains('dcu-wb-workspace-move-drop')).toBe(true)
    await act(async () => { dispatchDrag(pinned[0]!, 'dragover', transfer) })
    expect(markers()).toHaveLength(1)
    expect(group.classList.contains('dcu-wb-workspace-move-drop')).toBe(false)
    await act(async () => { dispatchDrag(ungrouped, 'dragover', transfer) })
    expect(markers().length).toBeLessThanOrEqual(1)
    await act(async () => { dispatchDrag(pinned[1]!, 'dragend', transfer) })
    expect(markers()).toHaveLength(0)
    expect(view.container.querySelector('.dcu-wb-drop-indicator')).toBeNull()
  } finally { await view.dispose() }
})

test('拖动项目时置顶末尾落点不得把项目分区顶下去', async () => {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
  const workspaces = { baselinesReady: true, archivedSessionIds: [], items: ['pinned', 'loose'].map(id => ({ workspaceId: id, title: id, path: `D:/${id}`, sessionIds: [] })) }
  vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ exists: true, pinnedWorkspaceIds: ['pinned'], workspaceGroups: [] }))))
  const view = await render(createElement(CodexWorkspaceBrowser, {
    ...sessionActions, wide: true, useSessions: createSessionStore(createSession('unused', 'unused', undefined)),
    useSessionPendingInteraction: useEmptyPendingInteractions,
    useWorkspaces: (selector: (snapshot: typeof workspaces) => unknown) => selector(workspaces), t,
    deleteWorkspace: vi.fn(), insertSessionBefore: vi.fn(), insertWorkspaceBefore: vi.fn(), openPath: vi.fn(), renameWorkspace: vi.fn(), startSession: vi.fn(),
  } as never))
  try {
    await act(async () => { await Promise.resolve(); await Promise.resolve() })
    const projects = view.container.querySelector<HTMLElement>('.dcu-wb-section[aria-label="workspace.projects"]')!
    const before = projects.offsetTop
    const transfer = createDataTransfer()
    await act(async () => { dispatchDrag(view.container.querySelectorAll('.dcu-wb-project-head')[1]!, 'dragstart', transfer) })
    const pinEnd = view.container.querySelector<HTMLElement>('.dcu-wb-pin-end')!
    expect(pinEnd).not.toBeNull()
    expect(getComputedStyle(pinEnd).position).toBe('absolute')
    expect(projects.offsetTop).toBe(before)
  } finally { await view.dispose() }
})

test('空置顶在 dragleave 清掉蓝线后仍能接收项目', async () => {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
  const workspaces = { baselinesReady: true, archivedSessionIds: [], items: ['alpha', 'beta'].map(id => ({ workspaceId: id, title: id, path: `D:/${id}`, sessionIds: [] })) }
  vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ exists: true, pinnedWorkspaceIds: [], workspaceGroups: [] }))))
  const view = await render(createElement(CodexWorkspaceBrowser, {
    ...sessionActions, wide: true, useSessions: createSessionStore(createSession('unused', 'unused', undefined)),
    useSessionPendingInteraction: useEmptyPendingInteractions,
    useWorkspaces: (selector: (snapshot: typeof workspaces) => unknown) => selector(workspaces), t,
    deleteWorkspace: vi.fn(), insertSessionBefore: vi.fn(), insertWorkspaceBefore: vi.fn(), openPath: vi.fn(), renameWorkspace: vi.fn(), startSession: vi.fn(),
  } as never))
  try {
    await act(async () => { await Promise.resolve(); await Promise.resolve() })
    const project = view.container.querySelector('.dcu-wb-project-head')!
    const pinned = view.container.querySelector('.dcu-wb-section[aria-label="workspace.pinned"]')!
    const empty = pinned.querySelector('.dcu-wb-empty')!
    const transfer = createDataTransfer()
    await act(async () => { dispatchDrag(project, 'dragstart', transfer) })
    await act(async () => { dispatchDrag(empty, 'dragover', transfer) })
    await act(async () => { dispatchDrag(pinned, 'dragleave', transfer, null) })
    await act(async () => { dispatchDrag(empty, 'drop', transfer) })
    expect(view.container.querySelector('.dcu-wb-pinned-list .dcu-wb-project-title')?.textContent).toBe('alpha')
    expect(view.container.querySelectorAll('.dcu-wb-section[aria-label="workspace.projects"] .dcu-wb-project-title')).toHaveLength(1)
  } finally { await view.dispose() }
})

test.each([401, 403, 503])('偏好读取 HTTP %s 保留本地分组并提示尚未同步', async status => {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
  const workspaceGroups = [{ id: 'cached', title: '本地分组', workspaceIds: [] }]
  window.localStorage.setItem(WORKSPACE_GROUPS_STORAGE_KEY, JSON.stringify({ version: 1, workspaceGroups, pendingHostSync: false }))
  vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status })))
  const workspaces = { baselinesReady: true, archivedSessionIds: [], items: [] }
  const view = await render(createElement(CodexWorkspaceBrowser, {
    ...sessionActions, wide: true, useSessions: createSessionStore(createSession('unused', 'unused', undefined)),
    useSessionPendingInteraction: useEmptyPendingInteractions,
    useWorkspaces: (selector: (snapshot: typeof workspaces) => unknown) => selector(workspaces), t,
    deleteWorkspace: vi.fn(), insertSessionBefore: vi.fn(), insertWorkspaceBefore: vi.fn(), openPath: vi.fn(), renameWorkspace: vi.fn(), startSession: vi.fn(),
  } as never))
  try {
    expect(view.container.querySelector('.dcu-wb-collection-title')?.textContent).toBe('本地分组')
    const message = view.container.querySelector('.dcu-wb-error[role="status"]')?.textContent
    expect(message).toContain('workspace.preferencesLocalOnly')
    expect(message).toContain(status === 401 ? 'errors.unauthorized' : status === 403 ? 'errors.forbidden' : 'errors.serviceUnavailable')
  } finally { await view.dispose() }
})

function expectPendingState(container: Element, title: string, kind: PendingInteractionKind, label: string): void {
  const row = [...container.querySelectorAll<HTMLElement>('.dcu-wb-session')]
    .find(candidate => candidate.querySelector('.dcu-wb-session-title')?.textContent === title)
  const pending = row?.querySelector<HTMLElement>('[data-state="warning"]')
  expect(pending?.dataset.pendingKind).toBe(kind)
  expect(pending?.textContent).toBe(label)
}

afterEach(() => {
  vi.unstubAllGlobals()
  window.localStorage.clear()
})

test('任务树从 SessionSummary 快照渲染等待回答状态', async () => {
  const session = createSession('workspace-session', '任务会话', 'question')
  const useSessions = createSessionStore(session)
  const workspaces = {
    baselinesReady: true,
    archivedSessionIds: [],
    items: [{ workspaceId: 'workspace-1', title: '测试项目', path: 'D:\\Workspace\\test', sessionIds: [session.id] }],
  }
  const useWorkspaces = <T,>(selector: (snapshot: typeof workspaces) => T): T => selector(workspaces)
  vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ exists: true, pinnedWorkspaceIds: [] }), {
    status: 200,
    headers: { 'content-type': 'application/json' },
  })))

  const view = await render(createElement(CodexWorkspaceBrowser, {
    ...sessionActions,
    wide: true,
    useSessions,
    useSessionPendingInteraction: useEmptyPendingInteractions,
    useWorkspaces,
    t,
    deleteWorkspace: async () => {},
    insertSessionBefore: async () => {},
    insertWorkspaceBefore: async () => {},
    openPath: async () => {},
    renameWorkspace: async () => {},
    startSession: () => {},
  } as never))
  try {
    expectPendingState(view.container, '任务会话', 'question', '等待回答')
  } finally {
    await view.dispose()
  }
})

test('任务树把会话拖到其他项目时先确认，取消不迁移且确认只执行一次', async () => {
  const session = createSession('move-session', '待移动会话', undefined)
  const targetSession = createSession('target-session', '目标项目会话', undefined)
  const sessionState: SessionListState = {
    ids: [session.id, targetSession.id],
    byId: { [session.id]: session, [targetSession.id]: targetSession },
    phase: 'ready',

    projectionsBySession: {},
  }
  const useSessions = <T,>(selector: (snapshot: SessionListState) => T): T => selector(sessionState)
  const workspaces = {
    baselinesReady: true,
    archivedSessionIds: [],
    items: [
      { workspaceId: 'source', title: '源项目', path: 'D:\\Workspace\\source', sessionIds: [session.id] },
      { workspaceId: 'target', title: '目标项目', path: 'D:\\Workspace\\target', sessionIds: [targetSession.id] },
    ],
  }
  const useWorkspaces = <T,>(selector: (snapshot: typeof workspaces) => T): T => selector(workspaces)
  const moveSession = vi.fn(async () => {})
  const insertSessionBefore = vi.fn(async () => {})
  vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ exists: true, pinnedWorkspaceIds: [] }), {
    status: 200,
    headers: { 'content-type': 'application/json' },
  })))

  const view = await render(createElement(CodexWorkspaceBrowser, {
    ...sessionActions,
    moveSession,
    wide: true,
    useSessions,
    useSessionPendingInteraction: useEmptyPendingInteractions,
    useWorkspaces,
    t,
    deleteWorkspace: async () => {},
    insertSessionBefore,
    insertWorkspaceBefore: async () => {},
    openPath: async () => {},
    renameWorkspace: async () => {},
    startSession: () => {},
  } as never))
  try {
    const sourceRow = [...view.container.querySelectorAll<HTMLElement>('.dcu-wb-session')]
      .find(row => row.querySelector('.dcu-wb-session-title')?.textContent === '待移动会话')
    const targetProject = [...view.container.querySelectorAll<HTMLElement>('.dcu-wb-project')]
      .find(project => project.querySelector('.dcu-wb-project-title')?.textContent === '目标项目')
    const targetSessionRow = [...targetProject!.querySelectorAll<HTMLElement>('.dcu-wb-session')]
      .find(row => row.querySelector('.dcu-wb-session-title')?.textContent === '目标项目会话')
    expect(sourceRow).toBeDefined()
    expect(targetProject).toBeDefined()
    expect(targetSessionRow).toBeDefined()
    const dataTransfer = createDataTransfer()

    await act(async () => { dispatchDrag(sourceRow!, 'dragstart', dataTransfer) })
    await act(async () => { dispatchDrag(targetSessionRow!, 'dragover', dataTransfer) })
    expect(targetProject?.classList.contains('dcu-wb-session-move-drop')).toBe(true)

    await act(async () => {
      dispatchDrag(targetSessionRow!, 'drop', dataTransfer)
      await Promise.resolve()
    })
    expect(moveSession).not.toHaveBeenCalled()
    expect(insertSessionBefore).not.toHaveBeenCalled()

    const cancelButton = [...document.querySelectorAll<HTMLButtonElement>('button')]
      .find(button => button.textContent === 'sessions.cancel')
    expect(document.querySelector('[role="dialog"]')?.textContent).toContain('sessions.moveConfirmTitle')
    expect(document.querySelector('[role="dialog"]')?.textContent).toContain('目标项目')
    expect(document.querySelector('[role="dialog"]')?.textContent).toContain('D:\\Workspace\\target')
    await act(async () => { cancelButton?.click() })
    expect(moveSession).not.toHaveBeenCalled()

    const secondDataTransfer = createDataTransfer()
    await act(async () => { dispatchDrag(sourceRow!, 'dragstart', secondDataTransfer) })
    await act(async () => { dispatchDrag(targetSessionRow!, 'drop', secondDataTransfer) })
    const confirmButton = [...document.querySelectorAll<HTMLButtonElement>('button')]
      .find(button => button.textContent === 'sessions.moveConfirmAction')
    await act(async () => {
      confirmButton?.click()
      await Promise.resolve()
    })
    expect(moveSession).toHaveBeenCalledTimes(1)
    expect(moveSession).toHaveBeenCalledWith('move-session', 'target')
  } finally {
    await view.dispose()
  }
})

test('项目跨分组拖动时高亮整个目标分组并保留精确插入', async () => {
  const sessionState: SessionListState = {
    ids: [],
    byId: {},
    phase: 'ready',

    projectionsBySession: {},
  }
  const useSessions = <T,>(selector: (snapshot: SessionListState) => T): T => selector(sessionState)
  const workspaces = {
    baselinesReady: true,
    archivedSessionIds: [],
    items: [
      { workspaceId: 'source', title: '源项目', path: 'D:\\Workspace\\source', sessionIds: [] as SessionId[] },
      { workspaceId: 'target', title: '目标项目', path: 'D:\\Workspace\\target', sessionIds: [] as SessionId[] },
      { workspaceId: 'ungrouped', title: '未分组项目', path: 'D:\\Workspace\\ungrouped', sessionIds: [] as SessionId[] },
    ],
  }
  const workspaceGroups = [
    { id: 'source-group', title: '源分组', workspaceIds: ['source'] },
    { id: 'target-group', title: '目标分组', workspaceIds: ['target'] },
  ]
  const useWorkspaces = <T,>(selector: (snapshot: typeof workspaces) => T): T => selector(workspaces)
  window.localStorage.setItem(WORKSPACE_GROUPS_STORAGE_KEY, JSON.stringify({ version: 1, workspaceGroups, pendingHostSync: false }))
  vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ exists: true, pinnedWorkspaceIds: [], workspaceGroups }), {
    status: 200,
    headers: { 'content-type': 'application/json' },
  })))

  const view = await render(createElement(CodexWorkspaceBrowser, {
    ...sessionActions,
    moveSession: async () => {},
    wide: true,
    useSessions,
    useSessionPendingInteraction: useEmptyPendingInteractions,
    useWorkspaces,
    t,
    deleteWorkspace: async () => {},
    insertSessionBefore: async () => {},
    insertWorkspaceBefore: async () => {},
    openPath: async () => {},
    renameWorkspace: async () => {},
    startSession: () => {},
  } as never))
  try {
    const sourceProject = [...view.container.querySelectorAll<HTMLElement>('.dcu-wb-project')]
      .find(project => project.querySelector('.dcu-wb-project-title')?.textContent === '源项目')
    const targetGroup = [...view.container.querySelectorAll<HTMLElement>('.dcu-wb-collection')]
      .find(group => group.querySelector('.dcu-wb-collection-label')?.textContent?.includes('目标分组'))
    const targetMember = targetGroup?.querySelector<HTMLElement>('[data-dcu-group-member]')
    expect(sourceProject).toBeDefined()
    expect(targetGroup).toBeDefined()
    expect(targetMember).toBeDefined()
    const dataTransfer = createDataTransfer()

    await act(async () => { dispatchDrag(sourceProject!.querySelector('.dcu-wb-project-head')!, 'dragstart', dataTransfer) })
    await act(async () => { dispatchDrag(targetMember!, 'dragover', dataTransfer) })
    expect(targetGroup?.classList.contains('dcu-wb-workspace-move-drop')).toBe(true)
    expect(targetMember?.classList.contains('dcu-wb-drop')).toBe(false)

    await act(async () => {
      dispatchDrag(targetMember!, 'drop', dataTransfer)
      await Promise.resolve()
    })
    const targetTitles = [...targetGroup!.querySelectorAll<HTMLElement>('.dcu-wb-project-title')].map(node => node.textContent)
    expect(targetTitles).toEqual(['源项目', '目标项目'])

    const sameGroupDraggedProject = [...targetGroup!.querySelectorAll<HTMLElement>('.dcu-wb-project')]
      .find(project => project.querySelector('.dcu-wb-project-title')?.textContent === '目标项目')
    const sameGroupTarget = [...targetGroup!.querySelectorAll<HTMLElement>('.dcu-wb-project')]
      .find(project => project.querySelector('.dcu-wb-project-title')?.textContent === '源项目')
      ?.closest<HTMLElement>('[data-dcu-group-member]')
    expect(sameGroupDraggedProject).toBeDefined()
    expect(sameGroupTarget).toBeDefined()
    const sameGroupDataTransfer = createDataTransfer()
    await act(async () => { dispatchDrag(sameGroupDraggedProject!.querySelector('.dcu-wb-project-head')!, 'dragstart', sameGroupDataTransfer) })
    await act(async () => { dispatchDrag(sameGroupTarget!, 'dragover', sameGroupDataTransfer) })
    expect(targetGroup?.classList.contains('dcu-wb-workspace-move-drop')).toBe(false)
    expect(sameGroupTarget?.classList.contains('dcu-wb-drop')).toBe(true)

    const ungroupedCollection = view.container.querySelector<HTMLElement>('.dcu-wb-ungrouped')
    const ungroupedTarget = ungroupedCollection?.querySelector<HTMLElement>('[data-dcu-ungrouped-member]')
    const sourceProjectInTarget = [...targetGroup!.querySelectorAll<HTMLElement>('.dcu-wb-project')]
      .find(project => project.querySelector('.dcu-wb-project-title')?.textContent === '源项目')
    expect(ungroupedCollection).toBeDefined()
    expect(ungroupedTarget).toBeDefined()
    expect(sourceProjectInTarget).toBeDefined()
    const ungroupedDataTransfer = createDataTransfer()
    await act(async () => { dispatchDrag(sourceProjectInTarget!.querySelector('.dcu-wb-project-head')!, 'dragstart', ungroupedDataTransfer) })
    await act(async () => { dispatchDrag(ungroupedTarget!, 'dragover', ungroupedDataTransfer) })
    expect(ungroupedCollection?.classList.contains('dcu-wb-workspace-move-drop')).toBe(true)
    expect(ungroupedTarget?.classList.contains('dcu-wb-drop')).toBe(false)
  } finally {
    await view.dispose()
  }
})

test('custom group menu renames without changing identity, membership, order or expansion', async () => {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
  vi.stubGlobal('matchMedia', () => ({ matches: true }))
  const workspaceGroups = [
    { id: 'first', title: 'First', workspaceIds: ['b', 'a'] },
    { id: 'second', title: 'Second', workspaceIds: [] },
  ]
  const workspaces = { baselinesReady: true, archivedSessionIds: [], items: ['a', 'b', 'c'].map(id => ({ workspaceId: id, title: id, path: `D:/${id}`, sessionIds: [] })) }
  const fetcher = vi.fn(async (_input: RequestInfo | URL, init?: RequestInit) => new Response(JSON.stringify(init?.method === 'PUT' ? {} : { exists: true, pinnedWorkspaceIds: [], workspaceGroups }), { status: 200 }))
  vi.stubGlobal('fetch', fetcher)
  window.localStorage.setItem(WORKSPACE_GROUPS_STORAGE_KEY, JSON.stringify({ version: 1, workspaceGroups, pendingHostSync: false }))
  const view = await render(createElement(CodexWorkspaceBrowser, {
    ...sessionActions, wide: true, useSessions: createSessionStore(createSession('unused', 'unused', undefined)),
    useSessionPendingInteraction: useEmptyPendingInteractions,
    useWorkspaces: (selector: (snapshot: typeof workspaces) => unknown) => selector(workspaces), t,
    deleteWorkspace: vi.fn(), insertSessionBefore: vi.fn(), insertWorkspaceBefore: vi.fn(), openPath: vi.fn(), renameWorkspace: vi.fn(), startSession: vi.fn(),
  } as never))
  const clickText = async (text: string) => {
    const button = [...document.querySelectorAll<HTMLElement>('button, [role="menuitem"]')].find(node => node.textContent === text)
    expect(button, text).toBeDefined()
    await act(async () => { button!.click() })
  }
  const cache = () => JSON.parse(window.localStorage.getItem(WORKSPACE_GROUPS_STORAGE_KEY)!).workspaceGroups
  const edit = async (value: string) => {
    const input = document.querySelector<HTMLInputElement>('[role="dialog"] input')!
    await act(async () => {
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(input, value)
      input.dispatchEvent(new Event('input', { bubbles: true }))
    })
    return input
  }
  try {
    const projects = view.container.querySelector('[aria-label="workspace.projects"]')!
    expect(projects.querySelector('.dcu-wb-section-head [aria-label="workspace.manageGroups"]')).toBeNull()
    expect(projects.querySelector('.dcu-wb-section-head [aria-label="workspace.createGroup"]')).not.toBeNull()
    expect(projects.querySelector('.dcu-wb-section-head [aria-label="workspace.add"]')).not.toBeNull()
    expect(projects.querySelector<HTMLButtonElement>('.dcu-wb-section-head [aria-label="workspace.add"]')!.disabled).toBe(true)
    const addWorkspaceFn = vi.fn()
    const viewWithAdd = await render(createElement(CodexWorkspaceBrowser, {
      ...sessionActions, wide: true, useSessions: createSessionStore(createSession('unused', 'unused', undefined)),
      useSessionPendingInteraction: useEmptyPendingInteractions,
      useWorkspaces: (selector: (snapshot: typeof workspaces) => unknown) => selector(workspaces), t,
      deleteWorkspace: vi.fn(), insertSessionBefore: vi.fn(), insertWorkspaceBefore: vi.fn(), openPath: vi.fn(), renameWorkspace: vi.fn(), startSession: vi.fn(),
      requestAddWorkspace: addWorkspaceFn,
      addWorkspaceShortcutAria: 'Control+O',
    } as never))
    try {
      const addBtn = viewWithAdd.container.querySelector<HTMLButtonElement>('.dcu-wb-section[aria-label="workspace.projects"] .dcu-wb-section-head [aria-label="workspace.add"]')!
      expect(addBtn).not.toBeNull()
      expect(addBtn.disabled).toBe(false)
      expect(addBtn.getAttribute('aria-keyshortcuts')).toBe('Control+O')
      await act(async () => { addBtn.click() })
      expect(addWorkspaceFn).toHaveBeenCalledTimes(1)
    } finally {
      await viewWithAdd.dispose()
    }
    expect(projects.querySelector('.dcu-wb-ungrouped [aria-haspopup]')).toBeNull()
    const first = projects.querySelector('.dcu-wb-collection')!
    const head = first.querySelector<HTMLElement>('.dcu-wb-collection-head')!
    // 点标签即点整行（标签现在只是 span，点击冒泡到 treeitem 的 onClick）。
    await act(async () => { first.querySelector<HTMLElement>('.dcu-wb-collection-label')!.click() })
    const menu = first.querySelector<HTMLButtonElement>('button[aria-haspopup="menu"]')!
    expect(menu).not.toBeNull()
    const transfer = createDataTransfer()
    await act(async () => { dispatchDrag(menu, 'dragstart', transfer); menu.click() })
    expect(transfer.effectAllowed).toBe('uninitialized')
    // 展开状态挂在 treeitem（head）上，不再挂在内部标签上——一行只允许一个 disclosure 控件。
    expect(head.getAttribute('aria-expanded')).toBe('false')
    const menuItem = document.querySelector<HTMLElement>('[role="menuitem"]')!
    await act(async () => { menuItem.focus(); menuItem.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })) })
    expect(document.querySelector('[role="menu"]')).toBeNull()
    expect(head.getAttribute('aria-expanded')).toBe('false')
    await act(async () => { menu.click() })
    await clickText('workspace.renameGroup')
    const input = document.querySelector<HTMLInputElement>('[role="dialog"] input')!
    expect(input.value).toBe('First')
    expect(document.activeElement).toBe(input)
    expect([input.selectionStart, input.selectionEnd]).toEqual([0, 5])
    await edit('  Renamed  ')
    await act(async () => { input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', isComposing: true, bubbles: true })) })
    expect(cache()).toEqual(workspaceGroups)
    expect(document.querySelector('[role="dialog"]')).not.toBeNull()
    await act(async () => { input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 229, bubbles: true })) })
    expect(cache()).toEqual(workspaceGroups)
    await act(async () => { input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true })) })
    const expected = [{ ...workspaceGroups[0], title: 'Renamed' }, workspaceGroups[1]]
    expect(cache()).toEqual(expected)
    expect(head.textContent).toContain('Renamed')
    expect(head.getAttribute('aria-expanded')).toBe('false')
    expect(fetcher.mock.calls.filter(([, init]) => init?.method === 'PUT').map(([, init]) => JSON.parse(String(init!.body))).at(-1)?.workspaceGroups).toEqual(expected)
    await act(async () => { menu.click() })
    await clickText('workspace.renameGroup')
    await edit('Cancelled')
    await clickText('sessions.cancel')
    expect(cache()).toEqual(expected)
    expect(document.activeElement).toBe(menu)
    const writesBeforeNoop = fetcher.mock.calls.filter(([, init]) => init?.method === 'PUT').length
    await act(async () => { menu.click() })
    await clickText('workspace.renameGroup')
    await clickText('sessions.save')
    expect(fetcher.mock.calls.filter(([, init]) => init?.method === 'PUT')).toHaveLength(writesBeforeNoop)
    expect(document.activeElement).toBe(menu)
    await act(async () => { menu.click() })
    await clickText('workspace.renameGroup')
    await edit('second')
    await clickText('sessions.save')
    expect(document.querySelector('[role="dialog"] [role="alert"]')).not.toBeNull()
    expect(cache()).toEqual(expected)
    await clickText('sessions.cancel')
    await act(async () => { menu.click() })
    await clickText('workspace.deleteGroupAction')
    expect(cache()).toEqual(expected)
    await clickText('sessions.cancel')
    expect(cache()).toEqual(expected)
    await act(async () => { menu.click() })
    await clickText('workspace.deleteGroupAction')
    await clickText('workspace.deleteGroupAction')
    expect(cache()).toEqual([workspaceGroups[1]])
    expect([...projects.querySelectorAll('.dcu-wb-ungrouped .dcu-wb-project-title')].map(node => node.textContent)).toEqual(['a', 'b', 'c'])
  } finally { await view.dispose() }
})

test.each(['cancel', 'escape'])('rename dismissal via %s restores focus when Host hydration removes the trigger', async dismissal => {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
  const workspaceGroups = [{ id: 'cached', title: 'Cached', workspaceIds: [] }]
  let resolveHost!: (response: Response) => void
  const hostResponse = new Promise<Response>(resolve => { resolveHost = resolve })
  const fetcher = vi.fn((_input: RequestInfo | URL, init?: RequestInit) => init?.method === 'PUT' ? Promise.resolve(new Response('{}')) : hostResponse)
  vi.stubGlobal('fetch', fetcher)
  window.localStorage.setItem(WORKSPACE_GROUPS_STORAGE_KEY, JSON.stringify({ version: 1, workspaceGroups, pendingHostSync: false }))
  const workspaces = { baselinesReady: true, archivedSessionIds: [], items: [] }
  const view = await render(createElement(CodexWorkspaceBrowser, {
    ...sessionActions, wide: true, useSessions: createSessionStore(createSession('unused', 'unused', undefined)),
    useSessionPendingInteraction: useEmptyPendingInteractions,
    useWorkspaces: (selector: (snapshot: typeof workspaces) => unknown) => selector(workspaces), t,
    deleteWorkspace: vi.fn(), insertSessionBefore: vi.fn(), insertWorkspaceBefore: vi.fn(), openPath: vi.fn(), renameWorkspace: vi.fn(), startSession: vi.fn(),
  } as never))
  try {
    const trigger = view.container.querySelector<HTMLButtonElement>('.dcu-wb-collection button[aria-haspopup="menu"]')!
    const fallbackButton = view.container.querySelector<HTMLButtonElement>('[aria-label="workspace.projects"] .dcu-wb-section-label')!
    await act(async () => { trigger.click() })
    await act(async () => { [...document.querySelectorAll<HTMLButtonElement>('[role="menuitem"]')].find(button => button.textContent === 'workspace.renameGroup')!.click() })
    const input = document.querySelector<HTMLInputElement>('[role="dialog"] input')!
    expect(document.activeElement).toBe(input)
    await act(async () => { resolveHost(new Response(JSON.stringify({ exists: true, pinnedWorkspaceIds: [], workspaceGroups: [] }))) })
    expect(trigger.isConnected).toBe(false)
    expect(document.querySelector('[role="dialog"]')).not.toBeNull()
    await act(async () => {
      if (dismissal === 'escape') input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }))
      else [...document.querySelectorAll<HTMLButtonElement>('[role="dialog"] button')].find(button => button.textContent === 'sessions.cancel')!.click()
    })
    expect(document.querySelector('[role="dialog"]')).toBeNull()
    expect(document.activeElement).toBe(fallbackButton)
    expect(JSON.parse(window.localStorage.getItem(WORKSPACE_GROUPS_STORAGE_KEY)!).workspaceGroups).toEqual([])
    expect(fetcher.mock.calls.filter(([, init]) => init?.method === 'PUT')).toHaveLength(0)
  } finally { await view.dispose() }
})

test.each(['create', 'rename'])('invalid group %s does not override a pending Host hydration', async action => {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
  const workspaceGroups = [
    { id: 'first', title: 'First', workspaceIds: [] },
    { id: 'second', title: 'Second', workspaceIds: [] },
  ]
  const hostGroups = [{ ...workspaceGroups[0], title: 'Host title' }, workspaceGroups[1]]
  let resolveHost!: (response: Response) => void
  const hostResponse = new Promise<Response>(resolve => { resolveHost = resolve })
  const fetcher = vi.fn((_input: RequestInfo | URL, init?: RequestInit) => init?.method === 'PUT' ? Promise.resolve(new Response('{}')) : hostResponse)
  vi.stubGlobal('fetch', fetcher)
  window.localStorage.setItem(WORKSPACE_GROUPS_STORAGE_KEY, JSON.stringify({ version: 1, workspaceGroups, pendingHostSync: false }))
  const workspaces = { baselinesReady: true, archivedSessionIds: [], items: [] }
  const view = await render(createElement(CodexWorkspaceBrowser, {
    ...sessionActions, wide: true, useSessions: createSessionStore(createSession('unused', 'unused', undefined)),
    useSessionPendingInteraction: useEmptyPendingInteractions,
    useWorkspaces: (selector: (snapshot: typeof workspaces) => unknown) => selector(workspaces), t,
    deleteWorkspace: vi.fn(), insertSessionBefore: vi.fn(), insertWorkspaceBefore: vi.fn(), openPath: vi.fn(), renameWorkspace: vi.fn(), startSession: vi.fn(),
  } as never))
  try {
    if (action === 'create') {
      await act(async () => { view.container.querySelector<HTMLButtonElement>('[aria-label="workspace.createGroup"]')!.click() })
    } else {
      await act(async () => { view.container.querySelector<HTMLButtonElement>('.dcu-wb-collection button[aria-haspopup="menu"]')!.click() })
      await act(async () => { [...document.querySelectorAll<HTMLButtonElement>('[role="menuitem"]')].find(button => button.textContent === 'workspace.renameGroup')!.click() })
    }
    const input = document.querySelector<HTMLInputElement>('[role="dialog"] input')!
    await act(async () => {
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(input, 'Second')
      input.dispatchEvent(new Event('input', { bubbles: true }))
    })
    await act(async () => { [...document.querySelectorAll<HTMLButtonElement>('[role="dialog"] button')].find(button => button.textContent === 'sessions.save')!.click() })
    expect(document.querySelector('[role="dialog"] [role="alert"]')).not.toBeNull()
    await act(async () => { resolveHost(new Response(JSON.stringify({ exists: true, pinnedWorkspaceIds: [], workspaceGroups: hostGroups }))) })
    const cache = JSON.parse(window.localStorage.getItem(WORKSPACE_GROUPS_STORAGE_KEY)!)
    expect(cache.workspaceGroups).toEqual(hostGroups)
    expect(cache.pendingHostSync).toBe(false)
    expect(fetcher.mock.calls.filter(([, init]) => init?.method === 'PUT')).toHaveLength(0)
  } finally { await view.dispose() }
})

test.each([{ isComposing: true }, { keyCode: 229 }])('Host 读取失败时新建分组保护输入法 Enter（%j），普通 Enter 仍可保存', async composing => {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
  const session = createSession('cached-workspace-session', '缓存任务会话', undefined)
  const useSessions = createSessionStore(session)
  const workspaces = {
    baselinesReady: true,
    archivedSessionIds: [],
    items: [{ workspaceId: 'cached-workspace', title: '缓存项目', path: 'D:\\Workspace\\cached', sessionIds: [session.id] }],
  }
  const useWorkspaces = <T,>(selector: (snapshot: typeof workspaces) => T): T => selector(workspaces)
  window.localStorage.setItem(WORKSPACE_GROUPS_STORAGE_KEY, JSON.stringify({
    version: 1,
    workspaceGroups: [{ id: 'cached-group', title: '缓存分组', workspaceIds: ['cached-workspace'] }],
    pendingHostSync: true,
  }))
  const fetcher = vi.fn(async (_input: RequestInfo | URL, init?: RequestInit) => {
    if (init?.method === 'GET') throw new Error('Host 暂时不可用')
    return new Response('{}', { status: 200 })
  })
  vi.stubGlobal('fetch', fetcher)

  const view = await render(createElement(CodexWorkspaceBrowser, {
    ...sessionActions,
    wide: true,
    useSessions,
    useSessionPendingInteraction: useEmptyPendingInteractions,
    useWorkspaces,
    t,
    deleteWorkspace: async () => {},
    insertSessionBefore: async () => {},
    insertWorkspaceBefore: async () => {},
    openPath: async () => {},
    renameWorkspace: async () => {},
    startSession: () => {},
  } as never))
  try {
    expect(view.container.querySelector('.dcu-wb-collection-label')?.textContent).toContain('缓存分组')

    const createButton = view.container.querySelector<HTMLButtonElement>('button[aria-label="workspace.createGroup"]')
    await act(async () => { createButton?.click() })
    const input = document.querySelector<HTMLInputElement>('input[aria-label="workspace.groupName"]')
    await act(async () => {
      const setValue = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set
      setValue?.call(input, '故障期间新建')
      input?.dispatchEvent(new Event('input', { bubbles: true }))
    })
    await act(async () => {
      input?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true, ...composing }))
    })
    expect(document.querySelector('[role="dialog"]')).not.toBeNull()
    expect(JSON.parse(window.localStorage.getItem(WORKSPACE_GROUPS_STORAGE_KEY) ?? '{}').workspaceGroups).toHaveLength(1)
    expect(fetcher.mock.calls.filter(([, init]) => init?.method === 'PUT')).toHaveLength(0)
    await act(async () => {
      input?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }))
      await Promise.resolve()
    })
    expect(document.querySelector('[role="dialog"]')).toBeNull()
    expect(fetcher.mock.calls.some(([, init]) => init?.method === 'PUT')).toBe(true)
    expect(JSON.parse(window.localStorage.getItem(WORKSPACE_GROUPS_STORAGE_KEY) ?? '{}').workspaceGroups).toHaveLength(2)
  } finally {
    await view.dispose()
  }
})

test('频道树从 SessionSummary 快照渲染等待审批状态', async () => {
  const session = createSession('im:test-channel', '频道会话快照', 'approval')
  const useSessions = createSessionStore(session)
  vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({
    groups: [{ id: 'wecom', label: '企业微信', sessions: [{ sessionId: session.id, title: '频道会话', running: true }] }],
  }), {
    status: 200,
    headers: { 'content-type': 'application/json' },
  })))

  const view = await render(createElement(ChannelBrowser, { ...sessionActions, useSessions, useSessionPendingInteraction: useEmptyPendingInteractions, t } as never))
  try {
    expectPendingState(view.container, '频道会话', 'approval', '等待审批')
  } finally {
    await view.dispose()
  }
})

test('定时树从 SessionSummary 快照渲染计划待审状态', async () => {
  const session = createSession('dsh-automation-session-review', '2026-09-01 08:00 - 日报任务', 'plan-review')
  const useSessions = createSessionStore(session)
  const workspaces = { archivedSessionIds: [] }
  const useWorkspaces = <T,>(selector: (snapshot: typeof workspaces) => T): T => selector(workspaces)

  const view = await render(createElement(ScheduleBrowser, {
    ...sessionActions,
    useSessions,
    useSessionPendingInteraction: useEmptyPendingInteractions,
    useWorkspaces,
    t,
  } as never))
  try {
    expectPendingState(view.container, session.displayTitle, 'plan-review', '计划待审')
  } finally {
    await view.dispose()
  }
})

test('任务树从待处理交互 Store 渲染等待审批状态', async () => {
  const session = createSession('workspace-store-session', '任务 Store 会话', undefined)
  const useSessions = createSessionStore(session)
  const useSessionPendingInteraction = createPendingInteractionStore(session.id, 'approval')
  const workspaces = {
    baselinesReady: true,
    archivedSessionIds: [],
    items: [{ workspaceId: 'workspace-store-1', title: 'Store 测试项目', path: 'D:\\Workspace\\store-test', sessionIds: [session.id] }],
  }
  const useWorkspaces = <T,>(selector: (snapshot: typeof workspaces) => T): T => selector(workspaces)
  vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ exists: true, pinnedWorkspaceIds: [] }), {
    status: 200,
    headers: { 'content-type': 'application/json' },
  })))

  const view = await render(createElement(CodexWorkspaceBrowser, {
    ...sessionActions,
    wide: true,
    useSessions,
    useSessionPendingInteraction,
    useWorkspaces,
    t,
    deleteWorkspace: async () => {},
    insertSessionBefore: async () => {},
    insertWorkspaceBefore: async () => {},
    openPath: async () => {},
    renameWorkspace: async () => {},
    startSession: () => {},
  } as never))
  try {
    expectPendingState(view.container, session.displayTitle, 'approval', '等待审批')
  } finally {
    await view.dispose()
  }
})

test('频道树从待处理交互 Store 渲染等待回答状态', async () => {
  const session = createSession('im:store-channel', '频道 Store 会话快照', undefined)
  const useSessions = createSessionStore(session)
  const useSessionPendingInteraction = createPendingInteractionStore(session.id, 'question')
  vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({
    groups: [{ id: 'wecom', label: '企业微信', sessions: [{ sessionId: session.id, title: '频道 Store 会话', running: true }] }],
  }), {
    status: 200,
    headers: { 'content-type': 'application/json' },
  })))

  const view = await render(createElement(ChannelBrowser, {
    ...sessionActions,
    useSessions,
    useSessionPendingInteraction,
    t,
  } as never))
  try {
    expectPendingState(view.container, '频道 Store 会话', 'question', '等待回答')
  } finally {
    await view.dispose()
  }
})

test('任务树在没有旧 pending Store 时从 SessionStatus 渲染等待审批', async () => {
  const session = createSession('workspace-status-session', '任务 Status 会话', undefined)
  const useSessions = createSessionStore(session)
  const useSessionStatus = createSessionStatusStore(session.id, 'approval')
  const workspaces = {
    baselinesReady: true,
    archivedSessionIds: [],
    items: [{ workspaceId: 'workspace-status-1', title: 'Status 测试项目', path: 'D:\\Workspace\\status-test', sessionIds: [session.id] }],
  }
  const useWorkspaces = <T,>(selector: (snapshot: typeof workspaces) => T): T => selector(workspaces)
  vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ exists: true, pinnedWorkspaceIds: [] }), {
    status: 200,
    headers: { 'content-type': 'application/json' },
  })))

  const view = await render(createElement(CodexWorkspaceBrowser, {
    ...sessionActions,
    wide: true,
    useSessions,
    useSessionStatus,
    useWorkspaces,
    t,
    deleteWorkspace: async () => {},
    insertSessionBefore: async () => {},
    insertWorkspaceBefore: async () => {},
    openPath: async () => {},
    renameWorkspace: async () => {},
    startSession: () => {},
  } as never))
  try {
    expectPendingState(view.container, session.displayTitle, 'approval', '等待审批')
  } finally {
    await view.dispose()
  }
})

test('定时树从待处理交互 Store 渲染计划待审状态', async () => {
  const session = createSession('dsh-automation-session-store-review', '2026-09-01 09:00 - Store 日报任务', undefined)
  const useSessions = createSessionStore(session)
  const useSessionPendingInteraction = createPendingInteractionStore(session.id, 'plan-review')
  const workspaces = { archivedSessionIds: [] }
  const useWorkspaces = <T,>(selector: (snapshot: typeof workspaces) => T): T => selector(workspaces)

  const view = await render(createElement(ScheduleBrowser, {
    ...sessionActions,
    useSessions,
    useSessionPendingInteraction,
    useWorkspaces,
    t,
  } as never))
  try {
    expectPendingState(view.container, session.displayTitle, 'plan-review', '计划待审')
  } finally {
    await view.dispose()
  }
})
