import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'

const browser = readFileSync(new URL('../src/client/CodexWorkspaceBrowser.tsx', import.meta.url), 'utf8')
const locales = readFileSync(new URL('../src/client/locales.ts', import.meta.url), 'utf8')
assert.match(browser, /\.dcu-wb-collection-head \.dcu-wb-more\{opacity:0;pointer-events:none\}/, 'group actions must be hidden while idle without reserving extra layout changes')
assert.match(browser, /\.dcu-wb-collection-head:hover \.dcu-wb-more/, 'group actions must be visible on hover')
assert.match(browser, /\.dcu-wb-collection-head:focus-within \.dcu-wb-more/, 'group actions must be visible with keyboard focus')
assert.match(browser, /@media \(pointer:coarse\).*\.dcu-wb-collection-head \.dcu-wb-more/, 'touch users must see group actions')
assert.doesNotMatch(browser, /workspace\.manageGroups/, 'Projects header must not have manage groups menu')
assert.match(browser, /\.dcu-wb-collection-title\{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap\}/, 'long group names must not push actions offscreen')
assert.match(browser, /\.dcu-wb-collection-actions\{flex-shrink:0;width:20px\}/, 'group action column must reserve a fixed width')
// 未分组计数与自定义分组对齐，且**不添加可交互操作**（actions 只是 aria-hidden 的空位）。
// 2026-10-14：标签从 button 改为 span——head div 才是可展开的 treeitem，内部再放
// 带 aria-expanded 的按钮等于一行两个 disclosure 控件。收尾标签随之变成 </span>。
assert.match(browser, /ungroupedGroups\.length\}<\/span>[\s\S]*?<\/span>\s*<span className="dcu-wb-collection-actions" aria-hidden="true" \/>/, 'ungrouped count must align with custom groups without adding an interactive action')

assert.match(browser, /workspaceGroups\.map\(renderWorkspaceCollection\)/, '项目区必须按集合标题渲染持久化分组')
assert.match(browser, /initialWorkspaceGroups = useMemo\(\(\) => readWorkspaceGroupsCache\(storage\(\)\), \[\]\)/, '分组首帧必须从浏览器同步缓存恢复')
assert.match(browser, /useState<WorkspaceGroup\[\]>\(\(\) => initialWorkspaceGroups\.workspaceGroups\)/, '分组状态必须使用同步缓存作为初始值')
assert.match(browser, /saveWorkspaceGroupsCache\(storage\(\), workspaceGroups, workspaceGroupsPendingHostSyncRef\.current\)/, '分组变化必须同步写入浏览器缓存')
// Host 读取失败后继续写回，由 session-tree-pending.integration.spec.ts 的真实交互验证。
assert.match(browser, /writeWorkspaceGroupDrag\(event\.dataTransfer, groupId, group\.title\)/, '分组标题必须写入独立的分组拖拽载荷')
// 2026-10-14：容器同时是 treeitem（可展开、可聚焦），拖拽源仍必须是它本身。
// 注意 `[^>]*` 在这里不能用——插进去的 onClick 里含 `=>`，会把「非 > 字符」提前截断。
assert.match(browser, /className=\{`dcu-wb-collection-head[^`]*`\} role="treeitem"/, '分组标题容器必须是 treeitem（可展开、可聚焦）')
assert.match(
  browser,
  /className=\{`dcu-wb-collection-head[^`]*`\}[\s\S]{0,700}?draggable onDragStart=\{\(event\) => \{ event\.stopPropagation\(\); setSessionDrag\(undefined\); setSessionDropTarget\(undefined\); setWorkspaceDragId\(undefined\)/,
  '分组标题容器必须作为唯一的原生拖拽源',
)
assert.doesNotMatch(browser, /className="dcu-wb-collection-label" draggable/, '分组标题按钮不得抢占 Chrome 的原生拖拽手势')
assert.match(browser, /\.dcu-wb-collection-head\[draggable=true\],[^}]*\.dcu-wb-collection-label\{cursor:grab\}/, '分组标题及其按钮必须显示可拖动光标')
assert.match(browser, /reorderDropBeforeId\(workspaceGroupIds, draggedGroupId, groupId,/, '分组拖动必须按标题上下半区计算精确落点')
assert.match(browser, /moveWorkspaceGroup\(current, draggedGroupId, beforeId\)/, '放下分组后必须更新持久化分组顺序')
assert.match(browser, /dcu-wb-group-order-drop/, '分组排序必须显示独立插入线反馈')
assert.doesNotMatch(browser, /dcu-wb-group-order-drop-after/, '分组末尾只能由未分组顶部显示一条插入线，不能重复绘制')
assert.match(browser, /return mountWorkspaceDropIndicator\(treeRef\.current\)/, '拖拽时必须挂载统一的几何定位绘制层')
assert.match(browser, /\.dcu-wb-tree\[data-drop-indicator=measured\] \.dcu-wb-drop::before,[^}]*\.dcu-wb-group-order-drop::before\{display:none\}/, '统一绘制期间必须禁用旧伪元素，避免重复蓝线')
assert.match(browser, /current\.beforeId === target\.beforeId \? current : target/, '重复的分组拖拽落点不得触发重复渲染')
assert.match(browser, /className=\{`dcu-wb-ungrouped[^`]*`\} onDragOver=/, '未分组必须可以作为将自定义分组移到末尾的落点')
assert.doesNotMatch(browser, /<div className=\{`dcu-wb-ungrouped[^`]*`\} draggable/, '未分组是固定系统分类，不得作为拖拽源')
assert.doesNotMatch(browser, /className="dcu-wb-collection-label" draggable aria-expanded=\{ungroupedExpanded\}/, '未分组标题按钮不得作为拖拽源')
assert.match(browser, /const regularGroups = groups\.items\.filter\(workspace => !projectPinned\(workspace\.workspaceId\)\)/, '项目区不得重复渲染置顶项目')
assert.match(browser, /setPinnedWorkspaceIds\(ids => ids\.filter\(id => id !== dragged\)\)/, '从置顶投放到项目区时必须取消置顶')
assert.match(browser, /workspaceGroups\.length > 0 && renderUngroupedCollection\(\)/, '仅在已有分组时显示未分组小节')
assert.match(browser, /const ungroupedExpandKey = 'workspace-group:ungrouped'/, '未分组小节必须使用独立且稳定的折叠状态键')
assert.match(browser, /<div className="dcu-wb-collection-head" role="treeitem" aria-expanded=\{ungroupedExpanded\}/, '未分组必须复用二级分类标题基础样式')
// 2026-10-14：展开状态改由 treeitem 承载。原先挂在内部按钮上，等于在同一行放两个
// disclosure 控件（按钮 + 树项），屏幕阅读器会读两遍、且两处状态可能不一致。
assert.match(browser, /<div className="dcu-wb-collection-head" role="treeitem" aria-expanded=\{ungroupedExpanded\}/, '未分组标题必须提供可访问的展开状态（挂在 treeitem 上）')
assert.doesNotMatch(browser, /className="dcu-wb-collection-label" aria-expanded=/, '展开状态不得同时挂在内部按钮上（一行只允许一个 disclosure 控件）')
// 标签必须是 span：head div 已是可展开的 treeitem，内部再放可聚焦按钮等于一行两个
// Tab 站（原先用 tabIndex={-1} 把按钮推出 Tab 序列，治标；现在结构性消除）。
assert.match(browser, /<span className="dcu-wb-collection-label">/, '集合标签必须是 span（不得是按钮）')
assert.doesNotMatch(browser, /<button[^>]*className="dcu-wb-collection-label"/, '集合标签不得是按钮——否则一行里有两个可聚焦控件')
// 指示箭头必须跟着 treeitem 的 aria-expanded 转（原先挂在内部标签上：标签改成 span 后会失效）。
assert.match(
  browser,
  /\.dcu-wb-collection-head\[aria-expanded=true\] \.dcu-wb-collection-label \.dcu-wb-section-caret\{transform:rotate\(90deg\)\}/,
  '分组展开箭头必须按 treeitem 的 aria-expanded 旋转（挂错位置会让箭头永远不转）',
)
assert.match(browser, /toggleGroup\(ungroupedExpandKey, true\)/, '未分组标题必须支持展开和收起')
assert.match(browser, /<DisclosureBody className="dcu-wb-collection-body" open=\{ungroupedExpanded\} role="group">/, '未分组项目必须复用统一折叠动画（折叠体带 role="group" 让 treeitem 归属成立）')
assert.doesNotMatch(browser, /dcu-wb-ungrouped-head/, '未分组不得保留与其他二级分类不一致的专用标题样式')
assert.match(browser, /assignWorkspaceToGroup\(current, dragged, groupId\)/, '拖入任意分组区域必须将项目归入该分组')
assert.match(browser, /className=\{`dcu-wb-collection[^`]*`\} key=\{group\.id\} onDragOver=/, '分组空白区域必须在冒泡阶段接收项目，不能抢占成员的精确落点')
assert.doesNotMatch(browser, /className="dcu-wb-collection" key=\{group\.id\} onDragOverCapture=/, '分组外层不得在捕获阶段接管全部项目拖拽')
assert.match(browser, /data-dcu-group-member[\s\S]*placeWorkspaceInGroup\(current, dragged, groupId, beforeId\)/, '跨分组拖到具体项目时必须同时更新归属和精确顺序')
assert.doesNotMatch(browser, /data-dcu-group-member[^\n]*onDragOverCapture=\{\(event\) => \{ if \(workspaceDragId === undefined\) return/, '分组成员精确落点不得只依赖 React 拖拽状态')
assert.match(browser, /if \(sourceGroupId === groupId\) \{ const lastId = memberIds\[memberIds\.length - 1\]; const beforeId = lastId === undefined \? null : reorderDropBeforeId\(memberIds, dragged, lastId, true\); setWorkspaceDropTarget\(beforeId === null \? undefined : \{ zone: 'group', groupId, beforeId \}\); return \}/, '项目拖回当前分组标题时必须显示本组末尾插入线，不能使用整组接管框')
assert.match(browser, /setWorkspaceDropTarget\(\{ zone: 'group', groupId, ontoGroup: true, crossGroup: true \}\)/, '只有跨分组拖入时才允许自定义分组显示整组接管框')
assert.doesNotMatch(browser, /groupDropActive/, '当前分组标题不得保留整组接管状态')
assert.match(browser, /className=\{`dcu-wb-ungrouped[^`]*`\} onDragOver=/, '未分组空白区域必须在冒泡阶段接收项目')
assert.doesNotMatch(browser, /className=\{`dcu-wb-ungrouped[^`]*`\} onDragOverCapture=/, '未分组外层不得在捕获阶段接管全部项目拖拽')
assert.match(browser, /data-dcu-ungrouped-member/, '未分组内的具体项目必须提供精确排序落点')
assert.doesNotMatch(browser, /data-dcu-ungrouped-member[^\n]*onDragOverCapture=\{\(event\) => \{ if \(workspaceDragId === undefined\) return/, '未分组成员精确落点不得只依赖 React 拖拽状态')
assert.match(browser, /if \(sourceGroupId === undefined\) \{ const lastId = ungroupedGroupIds\[ungroupedGroupIds\.length - 1\]; const beforeId = lastId === undefined \? null : reorderDropBeforeId\(ungroupedGroupIds, dragged, lastId, true\); setWorkspaceDropTarget\(beforeId === null \? undefined : \{ zone: 'ungrouped', beforeId \}\); return \}/, '未分组项目拖回未分组标题时必须显示末尾插入线')
assert.match(browser, /setWorkspaceDropTarget\(\{ zone: 'ungrouped', ontoSection: true, crossGroup: true \}\)/, '只有跨分组拖入时才允许未分组显示整组接管框')
assert.doesNotMatch(browser, /ungroupedDropActive/, '未分组标题不得为本组排序显示整组接管状态')
assert.match(browser, /assignWorkspaceToGroup\(current, dragged\)/, '放入未分组区域必须移除项目的分组归属')
assert.match(browser, /sameWorkspaceDropTarget\(workspaceDropTargetRef\.current, target\)/, '重复的拖拽目标不得触发重复渲染')
assert.match(browser, /moveWorkspaceGroupMember\(current, dragged, groupId, beforeId\)/, '同一分组内拖动项目必须调整分组内顺序')
assert.doesNotMatch(browser, /sourceGroupId !== groupId\) return/, '具体项目落点不得拒绝未分组或其他分组的项目')
assert.doesNotMatch(browser, /aria-label=\{t\('workspace\.addToGroup', \{ name: group\.title \}\)\}/, '分组标题不应提供添加项目快捷按钮')
assert.doesNotMatch(browser, /aria-label=\{t\('workspace\.deleteGroup', \{ name: group\.title \}\)\}/, '分组标题不应提供删除分组快捷按钮')
assert.doesNotMatch(browser, /\.dcu-wb-collection\{[^}]*background:/, '分组容器不应使用常驻卡片背景')
assert.match(browser, /id: 'moveToGroup'[\s\S]*submenu: moveTargets/, '项目菜单必须使用二级菜单选择目标分组')
assert.match(browser, /workspaceGroupMoveTargets\(workspaceGroups, workspaceId\)/, '项目菜单必须复用经过单元测试的目标分组计算')
assert.match(browser, /target\.title \?\? t\('workspace\.removeFromGroup'\)/, '未分组目标必须使用准确文案')
assert.match(browser, /assignWorkspaceToGroup\(current, workspaceId, groupId\)/, '移动到分组必须更新独立分组归属')
assert.match(browser, /const moveWorkspaceToGroup = \(workspaceId: string, groupId\?: string\): void =>[\s\S]*setPinnedWorkspaceIds\(ids => ids\.filter\(id => id !== workspaceId\)\)/, '通过菜单移动置顶项目时必须同步取消置顶')
assert.doesNotMatch(browser, /<Modal open=\{moveWorkspaceId !== undefined\}/, '移动到分组不得继续打开选择弹窗')
assert.match(browser, /deleteWorkspaceGroup\(current, deleteGroupId\)/, '删除分组必须仅解除归属')
assert.match(browser, /function CreateGroupIcon\(\) \{[\s\S]*<ZIconProjectAdd size=\{16\}/, '新建分组必须使用 16px 文件夹加号图标（图标语言已统一为 Lucide）')
assert.match(browser, /aria-label=\{t\('workspace.add'\)\}[\s\S]*?<AddWorkspaceIcon \/>/, '项目区添加工作区按钮必须使用工作区加号图标')
assert.match(browser, /aria-label=\{t\('workspace.createGroup'\)\}[\s\S]*?<CreateGroupIcon \/>/, '项目区新建分组按钮必须使用文件夹加号图标')
assert.doesNotMatch(browser, /aria-label=\{t\('workspace.createGroup'\)\}[\s\S]*?<IconPlusOutline16/, '项目区新建分组不得继续使用单独加号')
assert.doesNotMatch(browser, /IconPlusOutline16/, '工作区树不得再导入已替换的加号图标')
assert.match(browser, /submitCreateGroup/, '新建分组必须支持键盘提交')
assert.match(browser, /<Modal open=\{createGroupOpen\} onClose=\{\(\) => \{ setCreateGroupOpen\(false\); setGroupTitleDraft\(''\); setError\(undefined\) \}\}/, '关闭新建分组弹窗必须清理共享错误')
assert.match(browser, /setCreateGroupOpen\(false\); setGroupTitleDraft\(''\); setError\(undefined\)/, '取消新建分组必须清理共享错误')
assert.doesNotMatch(browser, /type MenuState = \{ id: string; type: 'workspace' \| 'session' \| 'group'/, '菜单状态不得保留未使用的分组类型')
assert.doesNotMatch(browser, /if \(dragged !== undefined\) \{[^\n]*if \(dragged === undefined\) return/, '项目放下处理不得保留不可达判断')
assert.match(locales, /'workspace\.projects': '项目'/, '侧栏必须沿用项目标题')
// 2026-10-13 起空态文案改为「状态 + 下一步」（见 tests/design-system.assert.ts 的签名细节）。
// 断言改为锁意图：必须说项目、不得说会话——不再锁死具体措辞，否则文案一改就红，等于把文案钉死。
assert.match(locales, /'workspace\.empty': '[^']*项目[^']*'/, '项目空态必须描述项目而不是会话')
assert.doesNotMatch(locales, /'workspace\.empty': '[^']*会话[^']*'/, '项目空态不得描述会话')
assert.match(locales, /'workspace\.moveToGroup': '移动到分组'/, '分组操作必须提供中文文案')

console.log('✓ workspace group UI assertions passed')
