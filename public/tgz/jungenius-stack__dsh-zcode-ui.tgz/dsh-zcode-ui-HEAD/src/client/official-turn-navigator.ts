import { CODEX_UI_API_ENDPOINTS } from '../business-api.ts'

const OFFICIAL_TURN_NAVIGATOR_ATTRIBUTE = 'data-dcu-official-turn-navigator'
// 仅用于清除旧版注入或热更新残留；新版不再给内部部件添加这些属性。
const OFFICIAL_TURN_MARK_ATTRIBUTE = 'data-dcu-official-turn-mark'
const OFFICIAL_TURN_TOOLTIP_ATTRIBUTE = 'data-dcu-official-turn-tooltip'
const OFFICIAL_TURN_NAVIGATOR_SUPPORTED_ATTRIBUTE = 'data-dcu-official-turn-navigator-supported'
const CAPABILITIES_ENDPOINT = `${CODEX_UI_API_ENDPOINTS.dependencies}?action=capabilities`

function isOfficialTurnNavigator(element: Element): element is HTMLElement {
  if (!(element instanceof HTMLElement) || element.tagName !== 'NAV') return false
  if (element.querySelector('button[type="button"][aria-label]') === null) return false
  // 0.1.5 把自然高度写进行内样式；0.1.7 去掉了这个变量，刻度按钮改为带 data-index。
  return element.style.getPropertyValue('--turn-natural-height') !== ''
    || element.querySelector('button[type="button"][data-index][aria-label]') !== null
}

/** 标记实际挂载的官方轮次导航，避免依赖宿主样式文件名或会话 DOM 层级。 */
export function markOfficialTurnNavigators(root: ParentNode = document): number {
  for (const element of root.querySelectorAll(`[${OFFICIAL_TURN_NAVIGATOR_ATTRIBUTE}]`)) {
    if (isOfficialTurnNavigator(element)) continue
    element.removeAttribute(OFFICIAL_TURN_NAVIGATOR_ATTRIBUTE)
    for (const part of element.querySelectorAll(`[${OFFICIAL_TURN_MARK_ATTRIBUTE}],[${OFFICIAL_TURN_TOOLTIP_ATTRIBUTE}]`)) {
      part.removeAttribute(OFFICIAL_TURN_MARK_ATTRIBUTE)
      part.removeAttribute(OFFICIAL_TURN_TOOLTIP_ATTRIBUTE)
    }
  }
  for (const element of root.querySelectorAll('nav')) {
    if (!isOfficialTurnNavigator(element)) continue
    element.setAttribute(OFFICIAL_TURN_NAVIGATOR_ATTRIBUTE, 'true')
  }
  return root.querySelectorAll(`[${OFFICIAL_TURN_NAVIGATOR_ATTRIBUTE}]`).length
}

function nodeTouchesTurnNavigator(node: Node): boolean {
  return node instanceof Element && (
    node.matches(`nav,[${OFFICIAL_TURN_NAVIGATOR_ATTRIBUTE}]`)
    || node.closest(`[${OFFICIAL_TURN_NAVIGATOR_ATTRIBUTE}]`) !== null
    || node.querySelector(`nav,[${OFFICIAL_TURN_NAVIGATOR_ATTRIBUTE}]`) !== null
  )
}

function nodeInsideTurnNavigator(node: Node): boolean {
  return node instanceof Element && (
    node.matches(`[${OFFICIAL_TURN_NAVIGATOR_ATTRIBUTE}]`)
    || node.closest(`[${OFFICIAL_TURN_NAVIGATOR_ATTRIBUTE}]`) !== null
  )
}

function turnNavigatorMutationRelevant(records: readonly MutationRecord[]): boolean {
  return records.some(record => record.type === 'attributes'
    ? record.target instanceof Element && record.target.matches('nav')
    : nodeInsideTurnNavigator(record.target)
      || [...record.addedNodes].some(nodeTouchesTurnNavigator)
      || [...record.removedNodes].some(nodeTouchesTurnNavigator))
}

async function runtimeSupportsOfficialTurnNavigator(fetchImpl: typeof fetch): Promise<boolean> {
  try {
    const response = await fetchImpl(CAPABILITIES_ENDPOINT, { cache: 'no-store' })
    if (!response.ok) return false
    const payload = await response.json() as unknown
    if (payload === null || typeof payload !== 'object') return false
    const capabilities = (payload as Record<string, unknown>).capabilities
    return capabilities !== null && typeof capabilities === 'object'
      && (capabilities as Record<string, unknown>).officialTurnNavigator === true
  } catch {
    return false
  }
}

/** 官方导航可能在会话切换后异步挂载；仅对相关变更按帧检测，并在停用时清理标记。 */
export function observeOfficialTurnNavigators(doc: Document = document, fetchImpl: typeof fetch = fetch): () => void {
  if (doc.body === null || doc.documentElement === null) return () => {}
  let active = true
  let frame: number | undefined
  const run = (): void => {
    frame = undefined
    markOfficialTurnNavigators(doc)
  }
  const schedule = (): void => {
    if (frame !== undefined) return
    frame = window.requestAnimationFrame(run)
  }
  // 2026-10-18：官方轮次导航是**懒挂载**的。实测点击会话后，先是 <div class="JXrxFq_slot">
  // 插入（此刻内部还是空的，querySelector('nav') 为 null），19ms 之后 nav 才被填进去。
  // 旧实现只在挂载瞬间判定一次，那一帧 nav 还不存在 → 永远标不上 → 本插件以为「宿主没有
  // 官方导航」，于是自绘的那条一直存在，视觉上就是「左右各一条索引栏」。
  // 因此只要 childList 有变更就调度一次（markOfficialTurnNavigators 本身是幂等的，
  // 且已被 rAF 合并），不再依赖那次注定落空的「插入节点自身匹配 nav」判定。
  const observer = new MutationObserver(records => {
    if (records.some(record => record.type === 'childList') || turnNavigatorMutationRelevant(records)) schedule()
  })
  observer.observe(doc.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style'] })
  schedule()
  void runtimeSupportsOfficialTurnNavigator(fetchImpl).then(supported => {
    if (!active) return
    if (supported) doc.documentElement.setAttribute(OFFICIAL_TURN_NAVIGATOR_SUPPORTED_ATTRIBUTE, 'true')
    else doc.documentElement.removeAttribute(OFFICIAL_TURN_NAVIGATOR_SUPPORTED_ATTRIBUTE)
    // 探测结果只决定 CSS 兜底属性；真正的互斥依赖 nav 上的标记，这里补跑一次避免竞态。
    schedule()
  })
  return () => {
    active = false
    observer.disconnect()
    if (frame !== undefined) window.cancelAnimationFrame(frame)
    doc.documentElement.removeAttribute(OFFICIAL_TURN_NAVIGATOR_SUPPORTED_ATTRIBUTE)
    for (const element of doc.querySelectorAll(`[${OFFICIAL_TURN_NAVIGATOR_ATTRIBUTE}],[${OFFICIAL_TURN_MARK_ATTRIBUTE}],[${OFFICIAL_TURN_TOOLTIP_ATTRIBUTE}]`)) {
      element.removeAttribute(OFFICIAL_TURN_NAVIGATOR_ATTRIBUTE)
      element.removeAttribute(OFFICIAL_TURN_MARK_ATTRIBUTE)
      element.removeAttribute(OFFICIAL_TURN_TOOLTIP_ATTRIBUTE)
    }
  }
}
