import type { Context } from '@deepseek-ai/cordis'
import type { SessionMigrationServices } from './session-migration.ts'

type HostTool = { name: string; description?: string }

type HttpRequest = {
  method?: string
  url?: string
  /** Node 原生请求头（小写键名），用于跨站请求判定。 */
  headers?: Record<string, string | string[] | undefined>
  [Symbol.asyncIterator]?: () => AsyncIterator<Uint8Array | string>
}
type HttpResponse = {
  writeHead: (status: number, headers?: Record<string, string>) => void
  end: (body?: string) => void
}

type HostServices = SessionMigrationServices & {
  webServer: { register: (route: { kind: 'exact'; path: string; handler: (request: HttpRequest, response: HttpResponse) => Promise<void> }) => () => void }
  tools: { schemas: (scope?: unknown) => readonly HostTool[] }
}

function requireService<T extends object>(ctx: Context, key: string, method: keyof T): T {
  const service = ctx.get(key) as unknown
  if (service === null || typeof service !== 'object' || typeof (service as Record<string, unknown>)[method as string] !== 'function') {
    throw new Error(`zcode-ui-for-dsh 需要宿主服务 “${key}.${String(method)}”`)
  }
  return service as T
}

/** 在唯一的宿主边界校验服务能力；宿主 API 变更时立即失败，不会静默返回 503。 */
export function hostServices(ctx: Context): HostServices {
  const emit = ctx.emit as unknown as (event: string, ...args: unknown[]) => void
  return {
    webServer: requireService<HostServices['webServer']>(ctx, 'webServer', 'register'),
    agents: requireService<HostServices['agents']>(ctx, 'agents', 'get'),
    sessions: requireService<HostServices['sessions']>(ctx, 'sessions', 'get'),
    sessionPersistence: requireService<HostServices['sessionPersistence']>(ctx, 'sessionPersistence', 'list'),
    tools: requireService<HostServices['tools']>(ctx, 'tools', 'schemas'),
    workspaceRegistry: requireService<HostServices['workspaceRegistry']>(ctx, 'workspaceRegistry', 'list'),
    sessionProjectionCache: ctx.get('sessionProjectionCache') as HostServices['sessionProjectionCache'],
    emit: (event, ...args) => { emit.call(ctx, event, ...args) },
    logger: {
      warn: message => { ctx.logger.warn('%s', message) },
      info: message => { ctx.logger.info('%s', message) },
    },
  }
}
