// dsh-update-checker · Host 半部分
// 使用方式：把本文件内容整体作为 cordis_define 的 code.host 使用。
// ---------------------------------------------------------------------------
// 职责：
//   1. 读取当前安装的 @deepseek-ai/dsh 版本（本地 package.json → npx 缓存扫描 → subprocess 探测）
//   2. 读取 npm registry 上的最新版本（web.fetch → node + npm-cli.js 兜底）
//   3. 通过 harness.handle('check-update') 暴露给 Client 半部分调用
// 隐私：网络请求仅指向公开 registry（registry.npmmirror.com / registry.npmjs.org），
//       不上传任何本地数据；本地仅读取 @deepseek-ai/dsh/package.json。
// 依赖：timer 为硬依赖（inject）；fs / web / subprocess 为可选能力，缺失时自动降级。
// ---------------------------------------------------------------------------
return {
  inject: ['timer'],
  apply(ctx) {
    const fs = ctx.get('fs')
    const web = ctx.get('web')
    const subprocess = ctx.get('subprocess')

    const hasFs = fs !== undefined
    const hasWeb = web !== undefined
    const hasSubprocess = subprocess !== undefined

    function note(log, source, error) {
      const message = String((error && error.message) || error)
      log.push(source + ': ' + message.slice(0, 180))
    }

    // 常见安装位置候选（相对路径按 harness 进程 cwd 解析）；可按需增删。
    const pkgPathCandidates = [
      'node_modules/@deepseek-ai/dsh/package.json',
      '/usr/local/lib/node_modules/@deepseek-ai/dsh/package.json',
      '/opt/homebrew/lib/node_modules/@deepseek-ai/dsh/package.json',
    ]

    // npx 缓存根候选（示例：Windows + nvm4w 的自定义缓存位置）。
    // 留空也可以：subprocess 兜底脚本会按环境变量自动探测常见缓存目录。
    const npxCacheRoots = [
      'D:/nodejs/npm_cache/_npx',
    ]

    async function versionFromFile(path) {
      const target = await fs.resolve(path, {})
      const text = await fs.readText(target)
      const pkg = JSON.parse(text)
      return typeof pkg.version === 'string' ? pkg.version : null
    }

    // subprocess 兜底：由 node 按环境变量探测 npm 缓存并读取 dsh 版本。
    const scanScript = [
      "const fs=require('fs'),path=require('path');",
      "const ver=(f)=>{try{return JSON.parse(fs.readFileSync(f,'utf8')).version}catch(e){return null}};",
      "const ls=(d)=>{try{return fs.readdirSync(d)}catch(e){return []}};",
      "const env=process.env||{};",
      "const roots=[];",
      "if(env.npm_config_cache)roots.push(env.npm_config_cache);",
      "if(env.LOCALAPPDATA)roots.push(path.join(env.LOCALAPPDATA,'npm-cache'));",
      "if(env.APPDATA)roots.push(path.join(env.APPDATA,'npm-cache'));",
      "if(env.HOME)roots.push(path.join(env.HOME,'.npm'));",
      "roots.push('/usr/local/lib/node_modules','/opt/homebrew/lib/node_modules');",
      "for(const root of roots){",
      "  const direct=ver(path.join(root,'@deepseek-ai','dsh','package.json'));",
      "  if(direct){console.log(direct);process.exit(0)}",
      "  for(const d of ls(path.join(root,'_npx'))){",
      "    const v=ver(path.join(root,'_npx',d,'node_modules','@deepseek-ai','dsh','package.json'));",
      "    if(v){console.log(v);process.exit(0)}",
      "  }",
      "}",
    ].join('')

    async function readCurrentVersion(log) {
      if (fs !== undefined) {
        for (const path of pkgPathCandidates) {
          try {
            const version = await versionFromFile(path)
            if (version) return version
          } catch (error) { note(log, 'fs ' + path, error) }
        }
        for (const root of npxCacheRoots) {
          try {
            const base = await fs.resolve(root, {})
            const entries = await fs.listDir(base)
            for (const entry of entries) {
              if (entry.type !== 'directory') continue
              try {
                const version = await versionFromFile(root + '/' + entry.name + '/node_modules/@deepseek-ai/dsh/package.json')
                if (version) return version
              } catch (error) { /* 单个缓存目录缺失属预期 */ }
            }
          } catch (error) { note(log, 'fs scan ' + root, error) }
        }
      }
      if (subprocess !== undefined) {
        try {
          const node = await subprocess.resolveExecutable('node')
          const handle = subprocess.spawn({
            argv: [node, '-e', scanScript],
            cwd: '/',
            stdio: { stdin: 'ignore', stdout: { maxBytes: 8192 }, stderr: { maxBytes: 8192 } },
            graceMs: 20000,
          })
          await handle.done
          const text = handle.collected.stdout.readFrom(0).text.trim()
          if (text) return text
          note(log, 'subprocess scan', new Error('no output'))
        } catch (error) { note(log, 'subprocess scan', error) }
      }
      return null
    }

    // npm-cli.js 的可能位置：Windows 在 node 目录的 node_modules 下，
    // macOS/Linux 在 node 目录的 lib/node_modules 下。
    function npmCliCandidates(nodePath) {
      const dir = nodePath.replace(/[\\/]node(\.exe)?$/, '')
      return [
        dir + '/node_modules/npm/bin/npm-cli.js',
        dir + '/lib/node_modules/npm/bin/npm-cli.js',
      ]
    }

    async function readLatestVersion(log) {
      const registryUrls = [
        'https://registry.npmmirror.com/@deepseek-ai%2fdsh/latest',
        'https://registry.npmjs.org/@deepseek-ai%2fdsh/latest',
      ]
      if (web !== undefined) {
        for (const url of registryUrls) {
          try {
            const result = await web.fetch({ url })
            if (result && result.statusCode === 200 && result.body && typeof result.body.content === 'string') {
              const manifest = JSON.parse(result.body.content)
              if (typeof manifest.version === 'string') return manifest.version
            }
            note(log, 'web.fetch ' + url, new Error('status ' + (result && result.statusCode)))
          } catch (error) { note(log, 'web.fetch ' + url, error) }
        }
      }
      if (subprocess !== undefined) {
        try {
          const node = await subprocess.resolveExecutable('node')
          for (const npmCli of npmCliCandidates(node)) {
            try {
              const handle = subprocess.spawn({
                argv: [node, npmCli, 'view', '@deepseek-ai/dsh', 'version'],
                cwd: '/',
                stdio: { stdin: 'ignore', stdout: { maxBytes: 8192 }, stderr: { maxBytes: 8192 } },
                graceMs: 45000,
              })
              const outcome = await handle.done
              if (outcome && outcome.exitCode === 0) {
                const text = handle.collected.stdout.readFrom(0).text.trim()
                const version = text.split(/\s+/).pop()
                if (version && /^\d/.test(version)) return version
                note(log, 'npm view', new Error('unparsed output: ' + text.slice(0, 120)))
              } else {
                const errText = handle.collected.stderr.readFrom(0).text.trim()
                note(log, 'npm view ' + npmCli, new Error('exit ' + (outcome && outcome.exitCode) + ' ' + errText.slice(0, 120)))
              }
            } catch (error) { note(log, 'npm view ' + npmCli, error) }
          }
        } catch (error) { note(log, 'npm view', error) }
      }
      return null
    }

    harness.handle('check-update', async () => {
      const currentLog = []
      const latestLog = []
      try {
        const result = await Promise.race([
          Promise.all([readCurrentVersion(currentLog), readLatestVersion(latestLog)]).then(([current, latest]) => ({ current, latest })),
          ctx.timeout(60000).then(() => { throw new Error('timeout') }),
        ])
        return { ...result, diag: { hasFs, hasWeb, hasSubprocess, currentLog, latestLog } }
      } catch (error) {
        return { current: null, latest: null, error: String((error && error.message) || error), diag: { hasFs, hasWeb, hasSubprocess, currentLog, latestLog } }
      }
    })
  },
}
