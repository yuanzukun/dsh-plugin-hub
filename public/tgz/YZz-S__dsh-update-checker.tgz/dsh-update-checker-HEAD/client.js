// dsh-update-checker · Client 半部分
// 使用方式：把本文件内容整体作为 cordis_define 的 code.client 使用。
// ---------------------------------------------------------------------------
// 职责：在会话顶栏动作区渲染版本徽章：
//   - 页面加载自动检查更新
//   - 已是最新 → 徽章显示“已经是最新版本”
//   - 有新版本 → 徽章显示“更新到 vX.Y.Z”并亮红点
//   - 检查失败 → 徽章变红显示“检查失败”，面板展示逐级诊断日志
//   - 点击徽章 → 重新检查并弹出对比面板（当前版本 / 最新版本 / 状态 / 升级指引）
// 说明：仅使用 React（createElement）、host.call、styles.insert 与 slots 服务，
//       无任何全局 DOM 操作；样式使用主题变量自动适配深浅色。
// ---------------------------------------------------------------------------
return {
  apply(ctx) {
    const slots = ctx.get('slots')
    if (slots === undefined) return

    styles.insert([
      '.dsh-upc-root{position:relative;display:inline-flex;align-items:center}',
      '.dsh-upc-badge{color:var(--dsw-alias-label-primary);cursor:pointer;background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l2);border-radius:8px;align-items:center;gap:5px;height:26px;padding:0 10px;font-family:inherit;font-size:12px;line-height:16px;display:inline-flex;position:relative;white-space:nowrap}',
      '.dsh-upc-badge:hover{background:var(--dsw-alias-interactive-bg-hover-solid)}',
      '.dsh-upc-badge-error{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary)}',
      '.dsh-upc-badgeLabel{font-family:ui-monospace,SFMono-Regular,Consolas,monospace}',
      '.dsh-upc-dot{position:absolute;top:-4px;right:-4px;width:10px;height:10px;background:var(--dsw-alias-state-error-primary);border:2px solid var(--dsw-alias-bg-base);border-radius:50%;box-sizing:content-box}',
      '.dsh-upc-panel{z-index:30;border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-base);width:420px;max-width:calc(100vw - 24px);max-height:70vh;box-shadow:var(--dsw-shadow-lv2);border-radius:12px;flex-direction:column;display:flex;position:fixed;overflow:hidden}',
      '.dsh-upc-header{box-sizing:border-box;border-bottom:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-base);flex:none;justify-content:space-between;align-items:center;min-height:44px;padding:10px 12px;display:flex}',
      '.dsh-upc-title{color:var(--dsw-alias-label-primary);font-size:13px;font-weight:500;line-height:20px}',
      '.dsh-upc-close{color:var(--dsw-alias-label-tertiary);cursor:pointer;background:0 0;border:none;border-radius:6px;width:24px;height:24px;font-size:16px;line-height:1;padding:0}',
      '.dsh-upc-close:hover{background:var(--dsw-alias-interactive-bg-hover-solid);color:var(--dsw-alias-label-primary)}',
      '.dsh-upc-body{flex:1;min-height:0;padding:4px 12px 12px;overflow-y:auto}',
      '.dsh-upc-row{justify-content:space-between;align-items:center;gap:12px;padding:6px 0;display:flex}',
      '.dsh-upc-rowLabel{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px}',
      '.dsh-upc-rowValue{color:var(--dsw-alias-label-primary);font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-size:12px;line-height:18px}',
      '.dsh-upc-status{margin:4px 0 0;font-size:12px;line-height:18px}',
      '.dsh-upc-tone-ok{color:var(--dsw-alias-state-success-primary)}',
      '.dsh-upc-tone-warn{color:var(--dsw-alias-state-warn-primary)}',
      '.dsh-upc-tone-error{color:var(--dsw-alias-state-error-primary)}',
      '.dsh-upc-tone-neutral{color:var(--dsw-alias-label-secondary)}',
      '.dsh-upc-hint{color:var(--dsw-alias-label-secondary);margin:8px 0 0;font-size:12px;line-height:18px}',
      '.dsh-upc-actions{justify-content:flex-end;gap:8px;margin-top:10px;display:flex}',
      '.dsh-upc-btn{color:var(--dsw-alias-label-primary);cursor:pointer;background:var(--dsw-alias-interactive-bg-hover);border:1px solid var(--dsw-alias-border-l1);border-radius:8px;padding:4px 12px;font-family:inherit;font-size:12px;line-height:20px}',
      '.dsh-upc-btn:hover{background:var(--dsw-alias-interactive-bg-hover-solid)}',
      '.dsh-upc-btn:disabled{opacity:.5;cursor:default}',
      '.dsh-upc-diag{margin-top:10px;border:1px dashed var(--dsw-alias-border-l2);border-radius:8px;background:var(--dsw-alias-bg-layer-1);padding:6px 8px;color:var(--dsw-alias-label-secondary);font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-size:10px;line-height:15px;max-height:140px;overflow:auto;white-space:pre-wrap;word-break:break-all}',
    ].join('\n'))

    function RefreshIcon() {
      return React.createElement('svg', {
        width: 13,
        height: 13,
        viewBox: '0 0 24 24',
        fill: 'none',
        stroke: 'currentColor',
        strokeWidth: 2,
        strokeLinecap: 'round',
        strokeLinejoin: 'round',
        'aria-hidden': true,
      },
        React.createElement('path', { d: 'M21 12a9 9 0 1 1-2.64-6.36' }),
        React.createElement('path', { d: 'M21 3v6h-6' }),
      )
    }

    function VersionRow(props) {
      return React.createElement('div', { className: 'dsh-upc-row' },
        React.createElement('span', { className: 'dsh-upc-rowLabel' }, props.label),
        React.createElement('span', { className: 'dsh-upc-rowValue' }, props.value),
      )
    }

    function UpdateBadge() {
      const [open, setOpen] = React.useState(false)
      const [checking, setChecking] = React.useState(false)
      const [result, setResult] = React.useState(null)
      const [error, setError] = React.useState(null)
      const [anchor, setAnchor] = React.useState(null)
      const badgeRef = React.useRef(null)

      const runCheck = React.useCallback(async (silent) => {
        if (!silent) setChecking(true)
        try {
          const data = await host.call('check-update', {})
          if (data && typeof data === 'object') {
            setResult(data)
            setError(typeof data.error === 'string' && data.error ? data.error : null)
          } else {
            setError('invalid response')
          }
        } catch (err) {
          setError(String((err && err.message) || err))
        } finally {
          if (!silent) setChecking(false)
        }
      }, [])

      // 页面加载（组件挂载）时自动检查一次
      React.useEffect(() => {
        runCheck(true)
      }, [runCheck])

      const current = result ? result.current : null
      const latest = result ? result.latest : null
      const newer = !!(current && latest && current !== latest)

      // 徽章文案：已是最新 → 显示“已经是最新版本”；有新版本 → “更新到 vX.Y.Z”
      const badgeText = checking && result === null
        ? '检查中…'
        : error !== null
          ? '检查失败'
          : current && latest
            ? (current === latest ? '已经是最新版本' : '更新到 v' + latest)
            : '检查更新'

      let statusText = '尚未检查'
      let statusTone = 'neutral'
      if (checking) {
        statusText = '正在检查更新…'
        statusTone = 'neutral'
      } else if (error !== null) {
        statusText = '检查失败：' + error
        statusTone = 'error'
      } else if (result) {
        if (!latest) {
          statusText = '无法获取最新版本'
          statusTone = 'warn'
        } else if (current && current === latest) {
          statusText = '已经是最新版本 ✓'
          statusTone = 'ok'
        } else if (current && current !== latest) {
          statusText = '发现新版本 v' + latest
          statusTone = 'warn'
        } else {
          statusText = '无法确定更新状态'
          statusTone = 'warn'
        }
      }

      const diag = result && result.diag
      const diagText = diag
        ? [
            'fs: ' + (diag.hasFs ? 'yes' : 'no') + '  web: ' + (diag.hasWeb ? 'yes' : 'no') + '  subprocess: ' + (diag.hasSubprocess ? 'yes' : 'no'),
            (diag.currentLog || []).map((line) => 'current | ' + line).join('\n'),
            (diag.latestLog || []).map((line) => 'latest   | ' + line).join('\n'),
          ].filter((line) => line.length > 0).join('\n')
        : ''

      const toggle = () => {
        const next = !open
        if (next) {
          const rect = badgeRef.current ? badgeRef.current.getBoundingClientRect() : null
          setAnchor(rect ? { top: rect.bottom + 6, left: rect.left } : { top: 12, left: 12 })
          runCheck(false)
        }
        setOpen(next)
      }

      const panelStyle = anchor ? { position: 'fixed', top: anchor.top, left: anchor.left } : undefined

      const panel = open && React.createElement('section', {
        className: 'dsh-upc-panel',
        style: panelStyle,
        role: 'dialog',
        'aria-label': 'DeepSeek Harness 更新检查',
      },
        React.createElement('header', { className: 'dsh-upc-header' },
          React.createElement('span', { className: 'dsh-upc-title' }, 'DeepSeek Harness 更新'),
          React.createElement('button', {
            type: 'button',
            className: 'dsh-upc-close',
            'aria-label': '关闭',
            onClick: () => setOpen(false),
          }, '×'),
        ),
        React.createElement('div', { className: 'dsh-upc-body' },
          React.createElement(VersionRow, { label: '当前版本', value: current || '未知' }),
          React.createElement(VersionRow, { label: '最新版本', value: latest || '未知' }),
          React.createElement('p', { className: 'dsh-upc-status dsh-upc-tone-' + statusTone }, statusText),
          newer && React.createElement('p', { className: 'dsh-upc-hint' },
            '升级方式：npm install -g @deepseek-ai/dsh@latest 后重启 dsh。'),
          diagText && React.createElement('pre', { className: 'dsh-upc-diag' }, diagText),
          React.createElement('div', { className: 'dsh-upc-actions' },
            React.createElement('button', {
              type: 'button',
              className: 'dsh-upc-btn',
              disabled: checking,
              onClick: () => runCheck(false),
            }, checking ? '检查中…' : '重新检查'),
          ),
        ),
      )

      return React.createElement('div', { className: 'dsh-upc-root' },
        panel,
        React.createElement('button', {
          type: 'button',
          ref: badgeRef,
          className: error !== null ? 'dsh-upc-badge dsh-upc-badge-error' : 'dsh-upc-badge',
          title: '检查 DeepSeek Harness 更新',
          'aria-label': '检查 DeepSeek Harness 更新',
          'aria-expanded': open,
          onClick: toggle,
        },
          React.createElement(RefreshIcon, null),
          React.createElement('span', { className: 'dsh-upc-badgeLabel' }, badgeText),
          newer && React.createElement('span', { className: 'dsh-upc-dot', title: '发现新版本：' + latest }),
        ),
      )
    }

    // 会话顶栏动作区（标题旁）——加法式注册，不替换任何自带 UI。
    slots.inject('conversation.session.header.actions', () => slots.register(
      { name: 'conversation.session.header.actions', id: 'dsh-update-check', order: 5, label: '检查更新' },
      UpdateBadge,
    ))
  },
}
