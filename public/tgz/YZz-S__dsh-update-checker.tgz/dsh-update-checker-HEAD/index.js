/**
 * dsh-update-checker — Host 半边（可安装的 dsh.bundle 插件）
 *
 * 职责：读取当前安装的 @deepseek-ai/dsh 版本、查询 npm registry 最新版本，
 * 并通过 /api/dsh-update-checker/check 路由提供给浏览器 Client 半边。
 *
 * 安装版（dsh plugin --profile web add ...）运行在宿主进程内：可直接使用
 * Node 内置模块与全局 fetch，因此不再需要动态插件（host.js）的
 * 子进程 node -e 探测方案。
 */
import { readFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'

export const name = 'dsh-update-checker'
export const inject = ['webServer']

const REGISTRY_URLS = [
  'https://registry.npmmirror.com/@deepseek-ai%2fdsh/latest',
  'https://registry.npmjs.org/@deepseek-ai%2fdsh/latest',
]

const CACHE_TTL_MS = 60 * 1000

function versionFromFile(file) {
  try {
    const pkg = JSON.parse(readFileSync(file, 'utf8'))
    return typeof pkg.version === 'string' ? pkg.version : null
  } catch (error) {
    return null
  }
}

function currentCandidates() {
  return [
    join(process.cwd(), 'node_modules', '@deepseek-ai', 'dsh', 'package.json'),
    '/usr/local/lib/node_modules/@deepseek-ai/dsh/package.json',
    '/opt/homebrew/lib/node_modules/@deepseek-ai/dsh/package.json',
  ]
}

function npmCacheRoots() {
  const env = process.env || {}
  const roots = []
  if (env.npm_config_cache) roots.push(env.npm_config_cache)
  if (env.LOCALAPPDATA) roots.push(join(env.LOCALAPPDATA, 'npm-cache'))
  if (env.APPDATA) roots.push(join(env.APPDATA, 'npm-cache'))
  if (env.HOME) roots.push(join(env.HOME, '.npm'))
  return roots
}

function readCurrentVersion(log) {
  for (const file of currentCandidates()) {
    const version = versionFromFile(file)
    if (version) {
      log.push('current: found ' + version + ' at ' + file)
      return version
    }
  }
  for (const root of npmCacheRoots()) {
    const npxDir = join(root, '_npx')
    let dirs = []
    try { dirs = readdirSync(npxDir) } catch (error) { continue }
    for (const dir of dirs) {
      const version = versionFromFile(join(npxDir, dir, 'node_modules', '@deepseek-ai', 'dsh', 'package.json'))
      if (version) {
        log.push('current: found ' + version + ' in npx cache ' + npxDir)
        return version
      }
    }
  }
  log.push('current: 未在任何候选路径找到 @deepseek-ai/dsh/package.json')
  return null
}

async function readLatestVersion(log) {
  for (const url of REGISTRY_URLS) {
    try {
      const ctl = new AbortController()
      const timer = setTimeout(() => ctl.abort(), 15000)
      const response = await fetch(url, { signal: ctl.signal, headers: { accept: 'application/json' } })
      clearTimeout(timer)
      if (response.status === 200) {
        const manifest = await response.json()
        if (manifest && typeof manifest.version === 'string') {
          log.push('latest: found ' + manifest.version + ' via ' + url)
          return manifest.version
        }
        log.push('latest: ' + url + ' 响应缺少 version 字段')
      } else {
        log.push('latest: ' + url + ' HTTP ' + response.status)
      }
    } catch (error) {
      log.push('latest: ' + url + ' ' + String((error && error.message) || error).slice(0, 160))
    }
  }
  return null
}

function json(res, status, body) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' })
  res.end(JSON.stringify(body))
}

export function apply(ctx) {
  let cache = null
  let cacheAt = 0

  async function check(force) {
    if (!force && cache !== null && Date.now() - cacheAt < CACHE_TTL_MS) return cache
    const currentLog = []
    const latestLog = []
    const current = readCurrentVersion(currentLog)
    const latest = await readLatestVersion(latestLog)
    const payload = { current, latest, diag: { currentLog, latestLog } }
    cache = payload
    cacheAt = Date.now()
    return payload
  }

  ctx.effect(() => {
    const dispose = ctx.webServer.register({
      kind: 'exact',
      path: '/api/dsh-update-checker/check',
      handler: async (req, res) => {
        if (req.method !== 'GET') {
          json(res, 405, { error: 'method-not-allowed' })
          return
        }
        const force = String(req.url || '').includes('force=1')
        const payload = await check(force)
        json(res, 200, payload)
      },
    })
    return () => dispose()
  }, 'dsh-update-checker: routes')
}
