window.__ModuleLoader__.load({
	id: "dsh-web-search-fetch",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
		let react_jsx_runtime = require("react/jsx-runtime");
        const React = require("react");
		let _deepseek_ai_dsh_client_store = require("@deepseek-ai/dsh-client-store");
		let _deepseek_ai_dsh_client_ui_primitives = require("@deepseek-ai/dsh-client-ui-primitives");
        //#region locales
        const zh = {
            servicesTitle: '服务与凭证', settingsTitle: '调用设置', advanced: '高级调用限制', advancedHint: '请求数、超时与正文长度',
            startGuide: '推荐服务与匿名额度', intro: '单入口搜索编排与 SiliconFlow 重排；AnySearch、Tavily 的官方匿名搜索与提取、Firecrawl 免钥提取与直接 HTTP 抓取无需密钥，Firecrawl 搜索仍需 API Key。请选择一种开始方式。',
            organizeHint: '合并多份正文，去重与互补，保留来源与差异。',
            autoPresetHint: '按本地结构化信号先派一路；结果不足时只补派一路。多路并发仅用于 multi 等显式预设。',
            singlePresetHint: '只调用一路搜索服务，返回该路结果，不合并、不加来源标记。',
            multiPresetHint: '并发调用参与范围内所有可用服务，合并结果并标注来源。',
            customPresetHint: '按服务开关、参与范围与调用限制执行。',
            freePresetHint: '只使用免密钥服务，仍受各服务额度与限流约束；Firecrawl 仅提取面免钥、参与免费提取，搜索仍需密钥；知乎需付费凭证，不参与。',
            invalidNumber: '请输入范围内的整数：', invalidControls: '请先修正调用限制', resetField: '撤销此项', range: '范围',

            title: '网络搜索与提取',
            startTitle: '选择开始方式', setupAuto: '使用自动预设', tryAnonymous: '直接体验匿名服务',
            setupAutoHint: '按本地结构化信号编排调用范围，不需要模型凭证。',
            tryAnonymousHint: '仅使用未配密钥的 AnySearch、Tavily 匿名额度、Firecrawl 免钥提取与直接 HTTP 抓取。选择后保存更改；匿名额度受限流约束。',
            anonymousUnavailable: '没有可用的匿名推荐服务：请检查端点覆盖、凭证状态或待保存的密钥。已有密钥不会被清除。',
            autoReady: '当前为自动预设：先派一路，结果不足时有界补派，无需额外凭证。',
            fixedReady: '当前使用固定预设，无需额外凭证。',
            modeLabel: '网页正文处理', organizeMode: '整理正文',
            presetLabel: '调用预设', autoPreset: '自动', singlePreset: '单通道', multiPreset: '多通道', customPreset: '自定义', freePreset: '免费接口',
            maxSearchServices: '每个查询的搜索服务上限', maxFetchServices: '每个 URL 的提取服务上限', maxRequests: '每次操作的 HTTP 请求上限',
            searchDeadlineMs: '搜索总限时（毫秒）', fetchDeadlineMs: '提取总限时（毫秒）', maxOutputChars: '整理输出上限（字符）',
            controlsHint: '整理保留原文和提取来源；差异不会自动判定真伪。请求上限包括重试与额度检查，不是金额上限。宿主 HTTP 抓取另有独立限制。',
            rerankTitle: '结果重排', rerankHint: '使用 SiliconFlow 对融合后的候选结果重排；未配置密钥或关闭时按融合顺序返回。', rerankModel: '重排模型',
            anysearch: 'AnySearch API Key', tavily: 'Tavily API Key', firecrawl: 'Firecrawl API Key', zhihu: '知乎 API Key',
            siliconflow: 'SiliconFlow API Key',
            anysearchBaseURL: 'AnySearch 端点', firecrawlBaseURL: 'Firecrawl 端点',
            anysearchZone: 'AnySearch 区域', zoneDefault: '默认（不发送）', zoneCn: '国内 (cn)', zoneIntl: '国际 (intl)',
            zoneHint: 'cn 偏好国内结果、intl 偏好国际结果；默认不发送 zone 字段。',
            baseURLHint: '留空使用官方端点；自定义端点需要密钥，且不再计入匿名额度。', baseURLPlaceholder: '留空使用官方端点',
            participateSearch: '参与搜索', participateFetch: '参与提取',
            keysHint: '留空保留原密钥。保存后只显示配置状态。', keyHint: '留空保留原密钥',
            'anysearch-service': 'AnySearch AI', 'tavily-service': 'Tavily', 'firecrawl-service': 'Firecrawl',
            'zhihu-service': '知乎', 'aihot-service': 'AIHOT', 'http-service': '直接 HTTP 抓取',
            all: '全部', search: '搜索', fetch: '提取', searchFetch: '搜索 · 提取', staticFetch: '静态资源提取', aiNews: 'AI 资讯搜索',
            anonymous: '匿名额度', anonymousPartial: '匿名提取', recommended: '推荐', enhancement: '可选增强', configured: '已配置', unconfigured: '未配密钥', partial: '部分配置', staged: '待保存', readOnly: '只读',
            checking: '读取中…', statusFailed: '状态未知', noKey: '无需密钥', configure: '配置', enable: '启用',
            searchLabel: '查找服务', searchPlaceholder: '搜索服务名称或用途', clearSearch: '清空搜索',
            statusFilter: '筛选配置状态', allStatus: '全部状态', needsKey: '未配置凭证', pending: '有未保存修改',
            servicesCount: '个服务', matches: '项匹配', noMatches: '没有匹配的服务',
            noMatchesHint: '试试其他关键词，或清除筛选条件。', resetFilters: '清除筛选',
            anysearchHint: '推荐服务。官方搜索与提取支持匿名额度，按 IP 限流；配置 API Key 后使用账户额度。自定义端点需要密钥。',
            tavilyHint: '推荐服务。官方 search / extract 支持匿名额度，受共享限流约束；配置 API Key 后使用账户额度。',
            firecrawlHint: '可选增强。网页提取（scrape）支持官方免钥免费层，无需 API Key；搜索仍受 IP 风控、需要 fc- 密钥，未配置时搜索路不参与调用。配置密钥后搜索与提取都使用账户额度。总开关控制搜索与提取，下方可分别选择参与范围。',
            zhihuHint: '可选增强。需要知乎开发者 API Key，提供站内与全网内容搜索，并可读取 zhihu.com/question/* 的回答摘要；不参与免费预设。',
            aihotHint: '默认启用的 AI 资讯源。搜索近 7 天 AI 资讯与热点，保留来源和署名。',
            aihotTerms: '使用范围：个人非商业、公益及组织内部使用；对外代理、收费或再分发须取得书面授权。',
            httpHint: '静态资源由 DSH HTTP 组件直接抓取，无需密钥。关闭后静态 URL 会报错，不会自动改走其他提取服务。',
            enableWarning: '此服务尚未启用。填写密钥后，记得打开右侧开关并保存。',
            missingWarning: '已启用，但凭证尚未配置；此路可能无法返回结果。',
            unavailable: '插件当前未加载，暂时无法配置。', readOnlyHint: '当前部署配置为只读。',
            saveFailed: '保存未全部完成。部分值可能已写入，草稿已保留，可重试。',
            save: '保存更改', saving: '保存中…', discard: '放弃更改', saved: '已保存，下一次调用生效',
            clean: '暂无待保存更改', dirty: '项未保存', refresh: '刷新凭证状态',
            quotaTitle: '额度', quotaRefresh: '刷新额度', quotaRefreshing: '刷新中…',
            quotaHint: '官方额度按各服务各自周期显示，不做折算；本地计数为插件观察值，重启后清零。',
            quotaChannelUnavailable: '额度数据通道不可用',
            quotaEstimate: '估算', quotaNeverRefreshed: '未刷新', quotaDisabled: '已停用（未探测）',
            quotaMonthly: '月额度', quotaDailyBj: '今日搜索', quotaDailyUtc: '今日',
            quotaRemaining: '剩余', quotaUsed: '已用', quotaLimit: '上限', quotaResetAt: '重置',
            quotaLocalCounts: '本地计数', quotaSuccess: '成功', quotaRateLimited: '限流', quotaQuotaFailures: '额度失败',
            quotaUnused: '今日未使用',
            firecrawlKeyless: '仅提取免钥，搜索需密钥',
            zhihuQuotaScope: '搜索两池合计，不含热榜/直答',
            quotaFootnote: '官方数值来自各服务额度端点；本地计数只统计插件观察到的调用，缓存命中与重启不计入。',
        };
        const en = {
            servicesTitle: 'Services & credentials', settingsTitle: 'Call settings', advanced: 'Advanced limits', advancedHint: 'Requests, deadlines and content length',
            startGuide: 'Recommended services and anonymous quotas', intro: 'Single-entry search orchestration with SiliconFlow reranking; official anonymous search and extraction from AnySearch and Tavily, keyless Firecrawl extraction and direct HTTP need no key. Firecrawl search still requires an API key. Choose how to start.',
            organizeHint: 'Combine extracts, remove duplicates and retain sources and differences.',
            autoPresetHint: 'Use local structured signals to start with one channel; if results are insufficient, add exactly one more. Fan-out remains for explicit presets such as multi.',
            singlePresetHint: 'Use exactly one search service and return its own results, with no merge and no source markers.',
            multiPresetHint: 'Fan out to every available service in scope, merge the results and mark their sources.',
            customPresetHint: 'Use service switches, participation and call limits.',
            freePresetHint: 'Use only keyless services, still subject to each service quota and rate limit. Firecrawl is keyless for extraction only and participates in free extraction; its search still requires a key; Zhihu needs a paid credential and is excluded.',
            invalidNumber: 'Enter an integer within ', invalidControls: 'Correct the call limits first', resetField: 'Undo this field', range: 'Range',

            title: 'Web search & fetch',
            startTitle: 'Choose how to start', setupAuto: 'Use the Auto preset', tryAnonymous: 'Try anonymous services',
            setupAutoHint: 'Orchestrate coverage from local structured signals; no model credentials are needed.',
            tryAnonymousHint: 'Use only keyless AnySearch and Tavily anonymous quotas, keyless Firecrawl extraction plus direct HTTP fetch. Save to apply; anonymous quotas are rate-limited.',
            anonymousUnavailable: 'No anonymous recommended service is available. Check endpoint overrides, credential status or unsaved keys. Existing keys are preserved.',
            autoReady: 'Auto starts with one channel and escalates once only when results are insufficient; no extra credentials are required.',
            fixedReady: 'A fixed preset is selected; no extra credentials are required.',
            modeLabel: 'Page content', organizeMode: 'Organize',
            presetLabel: 'Call preset', autoPreset: 'Auto', singlePreset: 'Single channel', multiPreset: 'Multi channel', customPreset: 'Custom', freePreset: 'Free APIs',
            maxSearchServices: 'Search services per query', maxFetchServices: 'Extraction services per URL', maxRequests: 'HTTP requests per operation',
            searchDeadlineMs: 'Search deadline (ms)', fetchDeadlineMs: 'Extraction deadline (ms)', maxOutputChars: 'Organized output limit (characters)',
            controlsHint: 'Retains original text and extraction provenance without deciding which variant is true. Request limits include retries and quota checks, not monetary costs. Host HTTP retrieval has separate limits.',
            rerankTitle: 'Result reranking', rerankHint: 'Rerank the fused candidates with SiliconFlow; without a key or when disabled, fused order is returned.', rerankModel: 'Rerank model',
            anysearch: 'AnySearch API key', tavily: 'Tavily API key', firecrawl: 'Firecrawl API key', zhihu: 'Zhihu API key',
            siliconflow: 'SiliconFlow API key',
            anysearchBaseURL: 'AnySearch endpoint', firecrawlBaseURL: 'Firecrawl endpoint',
            anysearchZone: 'AnySearch zone', zoneDefault: 'Default (not sent)', zoneCn: 'China (cn)', zoneIntl: 'International (intl)',
            zoneHint: 'cn prefers China results, intl prefers international; the zone field is omitted by default.',
            baseURLHint: 'Leave blank for the official endpoint. A custom endpoint requires a key and no longer counts as anonymous quota.', baseURLPlaceholder: 'Blank uses the official endpoint',
            participateSearch: 'Participate in search', participateFetch: 'Participate in extraction',
            keysHint: 'Leave blank to keep a key. Saved keys show status only.', keyHint: 'Leave blank to keep the key',
            'anysearch-service': 'AnySearch AI', 'tavily-service': 'Tavily', 'firecrawl-service': 'Firecrawl',
            'zhihu-service': 'Zhihu', 'aihot-service': 'AIHOT', 'http-service': 'Direct HTTP fetch',
            all: 'All', search: 'Search', fetch: 'Extraction', searchFetch: 'Search · Extraction', staticFetch: 'Static resources', aiNews: 'AI news search',
            anonymous: 'Anonymous quota', anonymousPartial: 'Anonymous fetch only', recommended: 'Recommended', enhancement: 'Optional', configured: 'Configured', unconfigured: 'Needs key', partial: 'Partially configured', staged: 'Unsaved', readOnly: 'Read-only',
            checking: 'Checking…', statusFailed: 'Status unknown', noKey: 'No key needed', configure: 'Configure', enable: 'Enable',
            searchLabel: 'Find a service', searchPlaceholder: 'Search by service or purpose', clearSearch: 'Clear search',
            statusFilter: 'Filter configuration status', allStatus: 'All statuses', needsKey: 'Needs credentials', pending: 'Unsaved changes',
            servicesCount: 'services', matches: 'matches', noMatches: 'No matching services',
            noMatchesHint: 'Try another keyword or clear the filters.', resetFilters: 'Clear filters',
            anysearchHint: 'Recommended. Official search and extraction support anonymous quotas with IP rate limits. A configured key uses account quotas; custom endpoints require a key.',
            tavilyHint: 'Recommended. Official search and extract support anonymous access with a shared rate limit. A configured key uses account quotas.',
            firecrawlHint: 'Optional. Official extraction (scrape) supports a keyless free tier and needs no API key; search is IP-risk-controlled and still requires an fc- key, so the search lane is not called without one. With a key, search and extraction use account credits. The switch controls both; select each capability below.',
            zhihuHint: 'Optional. Requires a Zhihu developer API key, searches site and web content and reads answer summaries for zhihu.com/question/*; excluded from the free preset.',
            aihotHint: 'Enabled by default. Search recent AI news and hot topics with attribution.',
            aihotTerms: 'Personal noncommercial, charitable and internal use; external proxies, paid use or redistribution require written authorization.',
            httpHint: 'DSH HTTP fetches static resources without a key. When disabled, static URLs return an error and do not switch to other extraction services.',
            enableWarning: 'This service is off. Enable it and save after entering a key.',
            missingWarning: 'Enabled without credentials. This source may not return results.',
            unavailable: 'The plugin is not loaded.', readOnlyHint: 'This deployment is read-only.',
            saveFailed: 'Some writes failed. Some may have succeeded. Drafts are preserved for retry.',
            save: 'Save changes', saving: 'Saving…', discard: 'Discard changes', saved: 'Saved; applies to the next call',
            clean: 'No unsaved changes', dirty: 'unsaved changes', refresh: 'Refresh credential status',
            quotaTitle: 'Quota', quotaRefresh: 'Refresh quota', quotaRefreshing: 'Refreshing…',
            quotaHint: 'Official quota uses each service period as-is; local counts are plugin observations that reset on restart.',
            quotaChannelUnavailable: 'Quota data channel unavailable',
            quotaEstimate: 'Estimated', quotaNeverRefreshed: 'Not refreshed', quotaDisabled: 'Disabled (not probed)',
            quotaMonthly: 'Monthly quota', quotaDailyBj: 'Search today', quotaDailyUtc: 'Today',
            quotaRemaining: 'Remaining', quotaUsed: 'Used', quotaLimit: 'Limit', quotaResetAt: 'Resets',
            quotaLocalCounts: 'Local counts', quotaSuccess: 'success', quotaRateLimited: 'rate-limited', quotaQuotaFailures: 'quota failures',
            quotaUnused: 'Unused today',
            firecrawlKeyless: 'Keyless extraction only; search requires a key',
            zhihuQuotaScope: 'Search pools combined; excludes hot list and direct answers',
            quotaFootnote: 'Official values come from each service quota endpoint; local counts cover only calls this plugin observed and reset on restart.',
        };
        //#endregion
		//#region surface
		/**
		* Namespace of this plugin's settings section. Spelled here rather than
		* imported: a client package must not depend on a Host package.
		*/
		const SETTINGS_NS = "web-search-fetch";
		/** Dictionary namespace owned by this plugin. */
		const NS = "settings.webSearchFetch";
        /** v0.3 调用预设；顺序即界面顺序。 */
        const PRESETS = ['auto', 'single', 'multi', 'custom', 'free'];
        /** SiliconFlow 重排模型（与 src/engines/registry.ts 的 RERANK_SERVICE.model 同步）。 */
        const RERANK_MODEL = 'BAAI/bge-reranker-v2-m3';
        /** 可用匿名额度的推荐服务（registry 中 auth==='keyless-fallback' 的引擎；直接 HTTP 另列，不参与本集合）。 */
        const ANONYMOUS_SERVICE_IDS = ['anysearch', 'tavily', 'firecrawl'];
        /**
        * v0.3 服务表：恰好注册表五引擎 + 直接 HTTP 抓取。
        * 客户端不能 import 宿主模块，故在此重述；测试把 id 集合钉回 registry。
        */
        const SERVICES = [
            { id: 'anysearch', mark: 'AS', capability: 'searchFetch', capabilities: ['search', 'fetch'], keys: ['anysearch'], free: true, keyless: true, auth: 'keyless-fallback', enabledByDefault: true },
            { id: 'tavily', mark: 'TV', capability: 'searchFetch', capabilities: ['search', 'fetch'], keys: ['tavily'], free: true, keyless: true, auth: 'keyless-fallback', enabledByDefault: true },
            { id: 'firecrawl', mark: 'FC', capability: 'searchFetch', capabilities: ['search', 'fetch'], keys: ['firecrawl'], free: true, keyless: true, keylessCapabilities: ['fetch'], auth: 'keyless-fallback', enabledByDefault: true },
            { id: 'zhihu', mark: 'ZH', capability: 'searchFetch', capabilities: ['search', 'fetch'], keys: ['zhihu'], free: false, keyless: false, auth: 'key', enabledByDefault: false },
            { id: 'aihot', mark: 'AI', capability: 'aiNews', capabilities: ['search', 'aihot-api'], keys: [], free: true, keyless: true, auth: 'anonymous', enabledByDefault: true },
            { id: 'http', mark: '↗', capability: 'staticFetch', capabilities: ['fetch'], keys: [], free: true, keyless: true, auth: 'anonymous', enabledByDefault: true },
        ];
        /** 额度周期标记（与装配层 src/index.ts 的 QUOTA_PERIODS 同步；测试钉回）。 */
        const QUOTA_PERIODS = {
            anysearch: 'daily-utc', tavily: 'monthly', firecrawl: 'monthly', zhihu: 'daily-bj', aihot: 'none',
        };
        /** 有官方额度端点的引擎（registry manifest endpoints.quota）；其余行只给估算。 */
        const QUOTA_OFFICIAL_IDS = ['tavily', 'firecrawl', 'zhihu'];
        /** 缺省开关：registry manifest 的 enabledByDefault；直接 HTTP 无 manifest，恒默认开。 */
        function defaultServiceEnabled(id) {
            return SERVICES.find(service => service.id === id)?.enabledByDefault ?? false;
        }
        /** 默认参与搜索的服务（registry 顺序中具备 search 能力的引擎）。 */
        function defaultSearchServices() {
            return SERVICES.filter(service => service.capabilities.includes('search')).map(service => service.id);
        }
        /** 默认参与提取的服务（HTTP 静态路径不受该列表控制）。 */
        function defaultFetchServices() {
            return SERVICES.filter(service => service.capabilities.includes('fetch') && service.id !== 'http').map(service => service.id);
        }
        /** 某服务在指定能力面是否免钥可用；keylessCapabilities 缺省表示全部能力。 */
        function keylessService(service, face) {
            return service.keyless === true
                && (service.keylessCapabilities === undefined || service.keylessCapabilities.includes(face));
        }
        /**
        * 调用限制：与 src/index.ts 的 Config 数值字段一一对应。
        * 上限取自 registry 默认名单长度（搜索 5、提取 4）。
        */
        const NUMBER_CONTROLS = {
            maxSearchServices: { initial: 5, min: 1, max: 5 },
            maxFetchServices: { initial: 4, min: 1, max: 4 },
            maxRequests: { initial: 32, min: 1, max: 256 },
            searchDeadlineMs: { initial: 15000, min: 1, max: 3600000 },
            fetchDeadlineMs: { initial: 50000, min: 1, max: 3600000 },
            maxOutputChars: { initial: 15000, min: 1000, max: 1000000 },
        };
        /**
        * 顶层配置字段（不在 controls 下）：端点覆盖与重排开关。
        * path 即设置页写回的配置路径。
        */
        const OPTION_FIELDS = {
            anysearchBaseURL: { kind: 'text', path: ['anysearchBaseURL'], initial: '' },
            anysearchZone: { kind: 'select', path: ['anysearchZone'], initial: '', options: ['', 'cn', 'intl'] },
            firecrawlBaseURL: { kind: 'text', path: ['firecrawlBaseURL'], initial: '' },
            rerankEnabled: { kind: 'boolean', path: ['rerank', 'enabled'], initial: true },
        };
		/**
		* v0.3 的五个凭证位，与 src/index.ts 的 Config 引用字段对应。
		*
		* 客户端不能 import 宿主模块，故在此重述；测试把引用集合钉回 Config 的默认值。
		* overridePaths 允许部署配置改写引用，defaultRef 是无改写时使用的环境变量名。
		*/
		const CREDENTIAL_SLOTS = [
			{"id": "anysearch", "overridePaths": [["anysearchApiKeyEnv"]], "defaultRef": "ANYSEARCH_API_KEY"},
			{"id": "tavily", "overridePaths": [["tavilyApiKeyEnv"]], "defaultRef": "TAVILY_API_KEY"},
			{"id": "firecrawl", "overridePaths": [["firecrawlApiKeyEnv"]], "defaultRef": "FIRECRAWL_API_KEY"},
			{"id": "zhihu", "overridePaths": [["zhihuApiKeyEnv"]], "defaultRef": "ZHIHU_API_KEY"},
			{"id": "siliconflow", "overridePaths": [["rerank", "apiKeyEnv"]], "defaultRef": "SILICONFLOW_API_KEY"}
		];
		/** DOM id of one slot's key field. */
		function slotDomId(id) {
			return `plugin-config-web-search-fetch-${id}`;
		}
		/** Read one config path out of a served settings section. */
		function readPath(root, path) {
			let node = root;
			for (const segment of path) {
				if (typeof node !== "object" || node === null) return void 0;
				node = node[segment];
			}
			return node;
		}
		/**
		* Resolve every slot to the reference the served section names.
		* @param value - the served settings value, or undefined before the first read.
		* @returns one `{ id, ref, refs }` per slot, in slot order.
		*/
		function resolveSlotRefs(value) {
            return CREDENTIAL_SLOTS.map(slot => {
                const ref = slot.overridePaths.map(path => readPath(value, path)).find(name => typeof name === 'string' && name.length) ?? slot.defaultRef;
                return { id: slot.id, ref, refs: [ref] };
            });
        }
		//#endregion
		//#region controller
		/**
		* The page's staged form over the `web-search-fetch` settings namespace and
		* the credentials domain.
		*
		* Service configuration and credential controls are deliberately kept apart.
		* The service credentials are credential values: their literal never rides a
		* response, so the page learns only whether one is configured, and writes
		* them through the credentials domain addressed by the reference the served
		* section names. One save covers both, and a blank key draft writes nothing,
		* which keeps the stored key rather than clearing it.
		*/
		var WebSearchFetchCardController = class {
			scope;
			ctx;
			store;
			unsubscribe;
            controlDrafts = new Map();
            numberDrafts = new Map();
            optionDrafts = new Map();
            keyDrafts = new Map();
            keyRefs = new Map();
            readGeneration = 0;
            quotaGeneration = 0;
            quotaPayload = undefined;
            quotaChannelError = false;
            quotaChannelErrorReason = '';
            quotaRefreshing = false;
            disposed = false;
			/** Revision the drafts were staged against, captured on the first stage. */
			baselineRevision;
			/** Configured/writable facts per slot id, never a value. */
			credentials = new Map();
			/** Reference each slot resolves to, as last read. */
			slotRefs = resolveSlotRefs(void 0);
			saving = false;
            discardAfterSave = false;
            failed = false;
            saved = false;
            view = { query: '', capability: 'all', status: 'all', expandedId: null, callSettingsOpen: false };
            /** 当前可匿名使用的推荐服务（未配密钥且未改写端点）。 */
            anonymousServices() {
                const state = { section: this.section() };
                return SERVICES.filter(service => ANONYMOUS_SERVICE_IDS.includes(service.id)
                    && anonymousService(service, state)
                    && !(service.id === 'anysearch' && this.optionDrafts.has('anysearchBaseURL'))
                    && !(service.id === 'firecrawl' && this.optionDrafts.has('firecrawlBaseURL'))
                    && service.keys.every(id => {
                        const info = this.credentials.get(id);
                        return info?.ready === true && !info.configured && !info.partial && !this.keyDrafts.has(id);
                    })).map(service => service.id);
            }
            /** 开场引导：切到自动预设，或把参与范围收窄到匿名推荐服务。 */
            chooseStart(choice) {
                if (!this.shell().available || !this.shell().writable || this.saving) return;
                if (choice === 'auto') {
                    if (this.controls().preset !== 'auto') this.editControl('preset', 'auto');
                    this.editView({ callSettingsOpen: true });
                    return;
                }
                if (choice !== 'anonymous') return;
                const services = this.anonymousServices();
                if (!services.length) return;
                this.editControl('preset', 'custom');
                // 按能力面分流：Firecrawl 只有提取免钥，不进入匿名的搜索参与列表。
                this.editControl('searchServices', SERVICES.filter(service => service.capabilities.includes('search') && services.includes(service.id) && keylessService(service, 'search')).map(service => service.id));
                this.editControl('fetchServices', SERVICES.filter(service => service.capabilities.includes('fetch') && service.id !== 'http' && services.includes(service.id) && keylessService(service, 'fetch')).map(service => service.id));
                this.editControl('serviceEnabled', Object.fromEntries(SERVICES.map(service => [service.id, services.includes(service.id) || service.id === 'http'])));
            }
            editView(next) {
                this.view = { ...this.view, ...next };
                this.publish();
            }
            toggleService(id) {
                this.editView({ expandedId: this.view.expandedId === id ? null : id });
            }
			/**
			* @param scope - the bound settings scope for the `web-search-fetch` namespace.
			* @param ctx - the page plugin's context, whose `remote.credentials`
			* namespace reads and writes the engine keys.
			*/
			constructor(scope, ctx) {
				this.scope = scope;
				this.ctx = ctx;
				this.store = _deepseek_ai_dsh_client_store.createSnapshotStore(this.projection());
				this.unsubscribe = scope.subscribe(() => {
					this.readCredentials();
					this.publish();
				});
				this.readCredentials();
			}
			/** The served settings section, or undefined before the first read. */
			section() {
				const snapshot = this.scope.getSnapshot();
				return snapshot.status === "ready" && typeof snapshot.value === "object" && snapshot.value !== null
					? snapshot.value
					: void 0;
			}
			/** The call-limited controls with served values and staged drafts applied. */
			controls() {
				return {
					preset: 'auto',
					...Object.fromEntries(Object.entries(NUMBER_CONTROLS).map(([name, spec]) => [name, spec.initial])),
					serviceEnabled: {},
					searchServices: defaultSearchServices(),
					fetchServices: defaultFetchServices(),
					...this.section()?.controls,
					...Object.fromEntries(this.controlDrafts),
				};
			}
			/** Whether a save would write anything for this service. */
			serviceEnabled(id, draft = true) {
				const section = this.section();
				const flags = draft ? this.controls().serviceEnabled : section?.controls?.serviceEnabled ?? {};
				return flags?.[id] ?? defaultServiceEnabled(id);
			}
			/** Read one top-level option as the card renders it. */
			optionField(name) {
				const spec = OPTION_FIELDS[name];
				const served = readPath(this.section(), spec.path);
				const value = served === undefined ? spec.initial : served;
				return {
					served: value,
					value: this.optionDrafts.has(name) ? this.optionDrafts.get(name) : value,
					dirty: this.optionDrafts.has(name),
				};
			}
			/** Stage one top-level option. */
			editOption(name, value) {
				if (this.saving || !Object.hasOwn(OPTION_FIELDS, name)) return;
				const spec = OPTION_FIELDS[name];
				if (spec.kind === 'boolean' ? typeof value !== 'boolean' : typeof value !== 'string') return;
				this.baselineRevision ??= this.scope.getSnapshot().revision;
				const served = readPath(this.section(), spec.path);
				const base = served === undefined ? spec.initial : served;
				if (JSON.stringify(base) === JSON.stringify(value)) this.optionDrafts.delete(name);
				else this.optionDrafts.set(name, value);
				this.failed = false;
				this.saved = false;
				this.publish();
			}
			numberField(name) {
				const spec = NUMBER_CONTROLS[name];
				const served = this.section()?.controls?.[name] ?? spec.initial;
				const text = this.numberDrafts.get(name) ?? String(this.controlDrafts.get(name) ?? served);
				const value = Number(text);
				return { text, servedText: String(served), min: spec.min, max: spec.max,
					dirty: this.numberDrafts.has(name) || this.controlDrafts.has(name),
					invalid: !/^\d+$/.test(text.trim()) || !Number.isSafeInteger(value) || value < spec.min || value > spec.max };
			}
			editNumber(name, text) {
				if (this.saving || !Object.hasOwn(NUMBER_CONTROLS, name)) return;
				this.baselineRevision ??= this.scope.getSnapshot().revision;
				this.numberDrafts.set(name, text);
				const field = this.numberField(name);
				if (field.invalid) this.controlDrafts.delete(name);
				else if (Number(text) === Number(field.servedText)) {
					this.numberDrafts.delete(name);
					this.controlDrafts.delete(name);
				} else this.controlDrafts.set(name, Number(text));
				this.failed = false;
				this.saved = false;
				this.publish();
			}
			/** Stage one non-numeric call control (preset, participation, switches). */
			editControl(name, value) {
				if (this.saving) return;
				if (name === 'preset' && !PRESETS.includes(value)) return;
				if (name === 'searchServices' || name === 'fetchServices') {
					const face = name === 'searchServices' ? 'search' : 'fetch';
					if (!Array.isArray(value) || value.some(id => !SERVICES.some(service => service.id === id && service.capabilities.includes(face)))) return;
				}
				if (name === 'serviceEnabled' && (value === null || typeof value !== 'object' || Array.isArray(value)
					|| Object.entries(value).some(([id, flag]) => !SERVICES.some(service => service.id === id) || typeof flag !== 'boolean'))) return;
				if (!['preset', 'searchServices', 'fetchServices', 'serviceEnabled'].includes(name)) return;
				this.baselineRevision ??= this.scope.getSnapshot().revision;
				const served = this.section()?.controls?.[name] ?? (name === 'preset' ? 'auto'
					: name === 'serviceEnabled' ? {}
					: name === 'searchServices' ? defaultSearchServices() : defaultFetchServices());
				if (JSON.stringify(served) === JSON.stringify(value)) this.controlDrafts.delete(name); else this.controlDrafts.set(name, value);
				this.failed = false; this.saved = false; this.publish();
			}
			/** The staged participation list for one face. */
			participationList(face) {
				return this.controls()[face === 'search' ? 'searchServices' : 'fetchServices'];
			}
			/** Whether this service's membership in one face differs from the served value. */
			participationDirty(id, face) {
				const key = face === 'search' ? 'searchServices' : 'fetchServices';
				const served = this.section()?.controls?.[key] ?? (face === 'search' ? defaultSearchServices() : defaultFetchServices());
				const current = this.controlDrafts.get(key) ?? served;
				return current.includes(id) !== served.includes(id);
			}
			editParticipation(id, face, enabled) {
				if (this.saving || typeof enabled !== 'boolean') return;
				const capability = face === 'search' || face === 'fetch' ? face : undefined;
				const service = SERVICES.find(item => item.id === id);
				if (!capability || !service || !service.capabilities.includes(capability)) return;
				const current = this.participationList(capability);
				this.editControl(capability === 'search' ? 'searchServices' : 'fetchServices',
					enabled ? [...new Set([...current, id])] : current.filter(value => value !== id));
			}
			serviceDirty(service) {
				if (service.keys.some(id => this.keyDrafts.has(id))) return true;
				if (service.id === 'anysearch' && this.optionDrafts.has('anysearchBaseURL')) return true;
				if (service.id === 'firecrawl' && this.optionDrafts.has('firecrawlBaseURL')) return true;
				if (this.serviceEnabled(service.id) !== this.serviceEnabled(service.id, false)) return true;
				return service.capabilities
					.filter(face => face === 'search' || face === 'fetch')
					.some(face => this.participationDirty(service.id, face));
			}
			matchesService(service) {
				const { query, capability, status } = this.view;
				const words = `${service.id} ${zh[service.id + '-service']} ${en[service.id + '-service']} ${zh[service.capability]} ${en[service.capability]}`.toLowerCase();
				return words.includes(query.trim().toLowerCase())
					&& (capability === 'all' || service.capabilities.includes(capability))
					&& (status === 'all' || status === 'pending' && this.serviceDirty(service)
						|| status === 'noKey' && service.keys.length === 0
						|| status === 'needsKey' && !anonymousService(service, { section: this.section() }) && service.keys.some(id => {
							const row = this.credentials.get(id);
							return row?.ready && !row.configured && !row.partial && !this.keyDrafts.has(id);
						}));
			}
			/**
			* Stage a key draft. A blank draft stages nothing, so saving leaves the
			* stored key alone instead of clearing it.
			* @param id - slot id.
			* @param text - what the user typed.
			*/
			editKey(id, text) {
                if (this.saving || !CREDENTIAL_SLOTS.some(slot => slot.id === id)) return;
				this.baselineRevision ??= this.scope.getSnapshot().revision;
				if (text.trim() === "") { this.keyDrafts.delete(id); this.keyRefs.delete(id); }
                else { this.keyDrafts.set(id, text.trim()); this.keyRefs.set(id, this.slotRefs.find(slot => slot.id === id)?.refs ?? []); }
				this.failed = false;
                this.saved = false;
				this.publish();
			}
			editService(id, enabled) {
				if (this.saving || typeof enabled !== 'boolean' || !SERVICES.some(service => service.id === id)) return;
				const served = this.section()?.controls?.serviceEnabled ?? {};
				const flags = { ...(this.controlDrafts.get('serviceEnabled') ?? served) };
				if (enabled === (served[id] ?? defaultServiceEnabled(id))) {
					if (Object.hasOwn(served, id)) flags[id] = served[id]; else delete flags[id];
				} else flags[id] = enabled;
				this.editControl('serviceEnabled', flags);
			}
			dirty() {
				return this.keyDrafts.size > 0 || this.controlDrafts.size > 0 || this.numberDrafts.size > 0 || this.optionDrafts.size > 0;
			}
			/**
			* Ask the credentials domain about the reference each slot resolves to.
			*
			* The answer is stored per slot: the section can change between the
			* request and its response, and two reads can settle out of order, so a
			* response is published only while it still answers for the references in
			* force.
			*/
			async readCredentials() {
				const generation = ++this.readGeneration;
                const refs = resolveSlotRefs(this.section());
                const names = [...new Set(refs.flatMap(slot => slot.refs))];
				let response;
				try {
					response = await this.ctx.remote.credentials.describe(names);
				} catch (_error) { response = { ok: false }; }
                if (this.disposed || generation !== this.readGeneration) return;
				const current = resolveSlotRefs(this.section());
				if (JSON.stringify(current) !== JSON.stringify(refs)) return;
				this.slotRefs = refs;
				const next = /* @__PURE__ */ new Map();
				for (const slot of refs) {
					const views = slot.refs.map(ref => response?.ok ? response.value?.[ref] : undefined);
					next.set(slot.id, {
						configured: views.every(view => view?.configured === true),
                        partial: views.some(view => view?.configured === true) && !views.every(view => view?.configured === true),
                        ready: response?.ok === true,
                        writable: views.every(view => view?.writable !== false)
					});
				}
				this.credentials = next;
				this.publish();
			}
			/** 额度通道读取：只取 get()，不触发探测。 */
			async readQuota() {
				return this.fetchQuota('get');
			}
			/** 手动刷新：返回的完整 payload 即发布，不再补调 get。 */
			async refreshQuota() {
				return this.fetchQuota('refresh');
			}
			/**
			* 宿主额度命名空间引用：由 apply 的动态 inject 回调注入。
			* cordis 的 ctx.remote.<ns> 属性访问是声明制（未声明抛
			* "cannot get property without inject"），存下引用后续调用不再过代理。
			*/
			attachQuotaService(panel) {
				this.quotaPanel = panel;
				this.readQuota();
			}
			async fetchQuota(method) {
				const panel = this.quotaPanel;
				if (panel === undefined || typeof panel[method] !== 'function') {
					this.failQuotaChannel('命名空间未就绪：panel=' + typeof this.quotaPanel + '，' + method + '=' + typeof panel?.[method]);
					return;
				}
				const generation = ++this.quotaGeneration;
				if (method === 'refresh') { this.quotaRefreshing = true; this.publish(); }
				let response;
				let reason = '';
				try { response = await panel[method](); } catch (error) { response = { ok: false }; reason = error?.message ?? String(error); }
				if (this.disposed || generation !== this.quotaGeneration) return;
				this.quotaRefreshing = false;
				if (response?.ok === true && response.value && Array.isArray(response.value.engines)) {
					this.quotaPayload = response.value;
					this.quotaChannelError = false;
					this.quotaChannelErrorReason = '';
				} else {
					this.quotaChannelError = true;
					this.quotaChannelErrorReason = reason || (response?.error?.message ?? JSON.stringify(response).slice(0, 300));
				}
				this.publish();
			}
			/** 通道失败只影响额度小节；两张设置面与凭证通道照常工作。 */
			failQuotaChannel(reason = '') {
				if (this.disposed) return;
				this.quotaRefreshing = false;
				this.quotaChannelError = true;
				this.quotaChannelErrorReason = reason;
				this.publish();
			}
			/**
			* Re-read after the Host reports a change to a reference this page watches.
			* @param ref - the reference the Host reports as changed.
			*/
			refreshCredential(ref) {
				if (!this.slotRefs.some(slot => slot.refs.includes(ref))) return;
				this.readCredentials();
			}
			/**
			* Write the staged edits, then re-read what the Host accepted.
			*
			* The settings mutation lands first, so a refused transport write leaves
			* the key drafts intact for correction; every key is then written through
			* the credentials domain. A key literal is passed straight through and is
			* never logged, echoed, or kept on this object beyond the staged draft.
			* @returns settlement after every write and the read-back.
			*/
			async save() {
				if (this.saving || this.shell().invalid) return;
				const snapshot = this.scope.getSnapshot();
				if (snapshot.writable !== true) return;
				const ops = [];
                ops.push(...[...this.controlDrafts].map(([name, value]) => ({ op: 'set', path: ['controls', name], value })));
                ops.push(...[...this.optionDrafts].map(([name, value]) => ({ op: 'set', path: OPTION_FIELDS[name].path, value })));
                // Keep the submitted references independent of a page closing during the write.
                const keys = [...this.keyDrafts].map(([id, text]) => [id, text, this.keyRefs.get(id)]);
				if (ops.length === 0 && keys.length === 0) return;
				this.saving = true;
				this.failed = false;
                this.saved = false;
				this.publish();
				let landed = true;
				try {
					if (ops.length > 0) {
						landed = await this.scope.mutate(ops, this.baselineRevision);
						if (landed) {
							// Accepted configuration is no longer a draft, even if a credential write fails.
							this.controlDrafts.clear();
							this.numberDrafts.clear();
							this.optionDrafts.clear();
							this.baselineRevision = this.scope.getSnapshot().revision;
						}
					}
					if (landed) {
						for (const [id, text, stagedRefs] of keys) {
							const refs = resolveSlotRefs(this.section()).find(slot => slot.id === id)?.refs ?? [];
							if (JSON.stringify(refs) !== JSON.stringify(stagedRefs)) { landed = false; continue; }
							for (const ref of refs) {
								const response = await this.ctx.remote.credentials.set(ref, text);
								if (response?.ok !== true) landed = false;
							}
						}
					}
				} catch (_error) {
					landed = false;
				} finally {
					if (landed) {
						this.keyDrafts.clear();
                        this.keyRefs.clear();
						this.baselineRevision = void 0;
					}
					this.failed = !landed;
                    this.saved = landed;
					this.saving = false;
                    if (this.discardAfterSave) {
                        this.clearDrafts();
                        this.discardAfterSave = false;
                        this.failed = false;
                        this.saved = false;
                    }
				}
				await this.readCredentials();
				this.publish();
			}
			/** Drop every staged edit. */
            clearDrafts() {
                this.keyDrafts.clear();
                this.keyRefs.clear();
                this.controlDrafts.clear();
                this.numberDrafts.clear();
                this.optionDrafts.clear();
                this.baselineRevision = undefined;
            }
            leave() {
                if (!this.saving) { this.discard(); return; }
                this.discardAfterSave = true;
                this.clearDrafts();
                this.publish();
            }
			discard() {
                if (this.saving) return;
				if (!this.dirty() && !this.failed) return;
				this.clearDrafts();
				this.failed = false;
                this.saved = false;
				this.publish();
			}
			/** The form frame's state: what the Host serves, and what a save would do. */
			shell() {
				const snapshot = this.scope.getSnapshot();
				return {
					available: snapshot.status === "ready",
					writable: snapshot.writable === true,
					dirty: this.dirty(),
					invalid: Object.keys(NUMBER_CONTROLS).some(name => this.numberField(name).invalid),
					saving: this.saving,
					failed: this.failed
				};
			}
			/** The card's whole render state. */
			projection() {
				this.slotRefs = resolveSlotRefs(this.section());
				return {
					...this.shell(),
                    anonymousServiceIds: this.anonymousServices(),
                    saved: this.saved,
                    controls: this.controls(),
                    numberFields: Object.fromEntries(Object.keys(NUMBER_CONTROLS).map(name => [name, this.numberField(name)])),
                    optionFields: Object.fromEntries(Object.keys(OPTION_FIELDS).map(name => [name, this.optionField(name)])),
                    view: { ...this.view },
                    visibleServiceIds: SERVICES.filter(service => this.matchesService(service)).map(service => service.id),
                    changedServiceIds: SERVICES.filter(service => this.serviceDirty(service)).map(service => service.id),
                    changeCount: this.keyDrafts.size + new Set([...this.controlDrafts.keys(), ...this.numberDrafts.keys(), ...this.optionDrafts.keys()]).size,
                    engines: Object.fromEntries(SERVICES.map(service => [service.id, this.serviceEnabled(service.id)])),
                    section: this.section(),
                    quota: {
                        channelError: this.quotaChannelError,
                        channelErrorReason: this.quotaChannelErrorReason || '',
                        refreshing: this.quotaRefreshing,
                        day: this.quotaPayload?.day,
                        engines: this.quotaPayload?.engines ?? [],
                    },
					keys: CREDENTIAL_SLOTS.map((slot) => {
						const draft = this.keyDrafts.get(slot.id) ?? "";
						const info = this.credentials.get(slot.id);
						return {
							id: slot.id,
							text: draft,
							staged: draft !== "",
                            ready: info?.ready,
							configured: info?.configured === true,
                            partial: info?.partial === true,
							writable: info?.writable !== false
						};
					})
				};
			}
			/** Publish the current projection to the card's store. */
			publish() {
                if (!this.dirty()) this.baselineRevision = undefined;
				this.store.set(this.projection());
			}
			/** Release the scope subscription. */
			dispose() {
                this.disposed = true;
                ++this.readGeneration;
				this.unsubscribe();
			}
		};
		//#endregion
        //#region card
        const SETTINGS_CSS = `
            .wsf-settings{color:var(--dsw-alias-label-primary);font:inherit;font-size:13px;line-height:1.5;min-inline-size:0;container-type:inline-size;display:flex;flex-direction:column}
            .wsf-settings p,.wsf-settings h3{margin-block:0}
            .wsf-settings :is(button,input,select,summary,a):focus-visible{outline:var(--dsw-focus-ring-width,2px) solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:2px}
            .wsf-muted{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:1.6;overflow-wrap:anywhere}
            .wsf-heading{display:flex;align-items:center;gap:12px;padding-block:12px 4px}
            .wsf-heading h3{font-size:13px;font-weight:600;flex:1;min-inline-size:0}
            .wsf-count{font-size:12px;color:var(--dsw-alias-label-tertiary);font-variant-numeric:tabular-nums}
            .wsf-preference{display:grid;gap:6px;padding-block:12px;border-block-end:.5px solid var(--dsw-alias-border-l2)}
            .wsf-setting-row{display:flex;align-items:center;flex-wrap:wrap;gap:8px 16px}
            .wsf-setting-label{font-weight:500;flex:1 1 70px}
            .wsf-select{box-sizing:border-box;inline-size:100%;min-inline-size:0;block-size:36px;padding-inline:10px;border:.5px solid var(--dsw-alias-border-l4);border-radius:var(--dsw-radius-md);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;cursor:pointer}
            .wsf-select:active{background:var(--dsw-alias-interactive-bg-hover)}
            .wsf-preset-compact{display:none}
            .wsf-setting-row [role=tablist]{max-inline-size:100%}
            .wsf-setting-row [role=tab]{padding-inline:12px}
            .wsf-call-settings>summary strong{font-weight:500}.wsf-current-settings{margin-inline-start:auto;color:var(--dsw-alias-label-tertiary);font-size:12px}.wsf-call-settings{border-block-end:.5px solid var(--dsw-alias-border-l2)}
            .wsf-advanced{border-block-end:.5px solid var(--dsw-alias-border-l2)}
            .wsf-call-settings>summary,.wsf-advanced>summary,.wsf-guide>summary{display:flex;align-items:center;gap:8px;list-style:none;cursor:pointer;border-radius:var(--dsw-radius-sm);padding-block:12px;user-select:none}
            .wsf-advanced>summary::-webkit-details-marker,.wsf-guide>summary::-webkit-details-marker{display:none}
            .wsf-disclosure-copy{display:grid;gap:2px;flex:1;min-inline-size:0}
            .wsf-disclosure-copy strong{font-weight:500}
            .wsf-chevron{flex:none;inline-size:16px;block-size:16px;display:grid;place-items:center;color:var(--dsw-alias-label-tertiary);font-size:17px;line-height:1}
            details[open]>summary .wsf-chevron{rotate:90deg}
            .wsf-control-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,210px),1fr));gap:0 16px}
            .wsf-controls-hint{padding-block:4px 12px}
            .wsf-guide{margin-block-end:10px;color:var(--dsw-alias-label-tertiary);font-size:12px}
            .wsf-guide>summary{padding-block:6px;justify-content:flex-start}
            .wsf-guide p{padding-block:4px 8px}
            .wsf-tools{display:flex;align-items:center;flex-wrap:wrap;gap:8px;margin-block-end:8px}
            .wsf-search{position:relative;flex:1 1 190px;min-inline-size:0}
            .wsf-search-field{box-sizing:border-box;inline-size:100%;padding-inline-end:36px}
            .wsf-search input::-webkit-search-cancel-button{display:none}
            .wsf-clear{position:absolute;inset-inline-end:2px;inset-block-start:2px;inline-size:28px;min-inline-size:28px;padding-inline:0!important}
            .wsf-status-filter{box-sizing:border-box;block-size:32px;max-inline-size:100%;padding-inline:10px;border:.5px solid var(--dsw-alias-border-l4);border-radius:var(--dsw-radius-md);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;font-size:12px}
            .wsf-filters{display:flex;align-items:center;flex-wrap:wrap;gap:4px;margin-block-end:8px}
            .wsf-filter{padding-inline:10px!important}
            .wsf-filter-count{margin-inline-start:6px;color:var(--dsw-alias-label-tertiary);font-size:11px;font-variant-numeric:tabular-nums}
            .wsf-results-count{margin-inline-start:auto;color:var(--dsw-alias-label-tertiary);font-size:12px;white-space:nowrap}
            .wsf-list{border-block-start:.5px solid var(--dsw-alias-border-l2)}
            .wsf-service{border-block-end:.5px solid var(--dsw-alias-border-l2);min-inline-size:0}
            .wsf-row{display:grid;grid-template-columns:minmax(0,1fr) auto 36px auto;align-items:center;gap:12px;min-block-size:58px}
            .wsf-row>[role=switch]{grid-column:3;grid-row:1;z-index:1}
            .wsf-open{grid-area:1/1/2/-1;display:grid;grid-template-columns:subgrid;align-items:center;gap:12px;min-inline-size:0;text-align:start;border:0;border-radius:var(--dsw-radius-sm);color:inherit;background:transparent;padding-block:10px;padding-inline:4px;cursor:pointer;font:inherit}
            .wsf-name{grid-column:1;min-inline-size:0}
            .wsf-name strong{display:block;font-size:13px;font-weight:500;overflow-wrap:anywhere}
            .wsf-name small{display:block;margin-block-start:2px;color:var(--dsw-alias-label-tertiary);font-size:11px}
            .wsf-state{grid-column:2;color:var(--dsw-alias-label-tertiary);font-size:11px;white-space:nowrap}
            .wsf-chevron{grid-column:-2/-1}
            .wsf-state[data-dirty=true]{color:var(--dsw-alias-label-secondary);font-weight:500}
            .wsf-detail{padding-block:2px 14px;padding-inline:4px;display:grid;gap:10px}
            .wsf-participation{display:flex;flex-wrap:wrap;gap:12px 20px}
            .wsf-notice{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:1.6;padding-block:8px}
            .wsf-empty{display:grid;justify-items:center;gap:8px;padding-block:32px;text-align:center}
            .wsf-empty h3{font-size:13px;font-weight:500}
            .wsf-footer{position:sticky;inset-block-end:0;z-index:1;display:flex;align-items:center;flex-wrap:wrap;gap:8px;padding-block:12px;border-block-start:.5px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-2)}
            .wsf-footer-status{flex:1 1 140px;min-inline-size:0;color:var(--dsw-alias-label-tertiary);font-size:12px}
            .wsf-footer-actions{display:flex;gap:8px;margin-inline-start:auto}
            .wsf-error{color:var(--dsw-alias-state-error-primary);font-size:12px;padding-block:8px}
            .wsf-link{min-block-size:28px;border:0;border-radius:var(--dsw-radius-sm);background:transparent;color:var(--dsw-alias-label-secondary);padding-inline:0;cursor:pointer;font:inherit;font-size:12px;text-decoration:underline;text-underline-offset:3px}
            .wsf-open:active,.wsf-call-settings>summary:active,.wsf-advanced>summary:active,.wsf-guide>summary:active,.wsf-link:active{background:var(--dsw-alias-interactive-bg-hover)}
            @media(hover:hover) and (pointer:fine){.wsf-open:hover,.wsf-call-settings>summary:hover,.wsf-advanced>summary:hover,.wsf-guide>summary:hover{background:var(--dsw-alias-interactive-bg-hover)}.wsf-link:hover{color:var(--dsw-alias-label-primary)}}
            @container(max-width:360px){.wsf-row,.wsf-open{gap:6px}.wsf-filters{gap:2px}.wsf-filter{padding-inline:8px!important}.wsf-filter-count{margin-inline-start:4px}.wsf-setting-row [role=tab]{padding-inline:8px}.wsf-preset-segments{display:none}.wsf-preset-compact{display:block}}
            .wsf-quota .wsf-heading{padding-block-end:0}
            .wsf-quota-list{border-block-start:.5px solid var(--dsw-alias-border-l2)}
            .wsf-quota-row{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:baseline;gap:2px 12px;padding-block:10px;border-block-end:.5px solid var(--dsw-alias-border-l2);min-inline-size:0}
            .wsf-quota-name{min-inline-size:0}
            .wsf-quota-name strong{display:block;font-size:13px;font-weight:500;overflow-wrap:anywhere}
            .wsf-quota-name small{display:block;color:var(--dsw-alias-label-tertiary);font-size:11px}
            .wsf-quota-state{color:var(--dsw-alias-label-secondary);font-size:12px;font-variant-numeric:tabular-nums;text-align:end;overflow-wrap:anywhere}
            .wsf-quota-detail,.wsf-quota-note{grid-column:1/-1;color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:1.6;overflow-wrap:anywhere}
            .wsf-quota-footnote{padding-block:8px 0}
            /* The host keeps a desktop sidebar on phones; scope its reflow to this active form. */
            @media(max-width:600px){
                [role=dialog]:has(.wsf-settings){flex-direction:column}
                [role=dialog]:has(.wsf-settings)>nav{inline-size:auto;flex-shrink:0;padding:12px}
                [role=dialog]:has(.wsf-settings)>nav>div:last-child{flex-direction:row;flex-wrap:wrap;gap:4px}
                [role=dialog]:has(.wsf-settings)>nav button{inline-size:auto}
                [role=dialog]:has(.wsf-settings)>nav+div{min-inline-size:0;min-block-size:0;inline-size:100%}
            }
        `;
        function KeyField({ t, row, disabled, onEdit, idPrefix = '' }) {
            const status = row.ready === undefined ? 'checking' : !row.ready ? 'statusFailed' : row.configured ? 'configured' : row.partial ? 'partial' : 'unconfigured';
            return react_jsx_runtime.jsx(_deepseek_ai_dsh_client_ui_primitives.SettingsSecretField, {
                id: idPrefix + slotDomId(row.id), label: t(row.id), hint: t('keyHint'), disabled: disabled || !row.writable,
                text: row.text, configured: row.configured,
                stateLabel: t(row.staged ? 'staged' : status) + (!row.writable ? ` · ${t('readOnly')}` : ''), onEdit,
            });
        }
        /** 匿名可用性：匿名两件套未改写端点时，未配密钥即走官方匿名额度。 */
        function anonymousService(service, state) {
            if (!ANONYMOUS_SERVICE_IDS.includes(service.id)) return false;
            const section = state.section ?? {};
            // 自定义端点不再走官方免钥额度：AnySearch 与 Firecrawl 覆盖端点时都要求配置密钥。
            if (service.id === 'anysearch') return !section.anysearchBaseURL;
            if (service.id === 'firecrawl') return !section.firecrawlBaseURL;
            return true;
        }
        function serviceStatus(service, state) {
            if (state.changedServiceIds.includes(service.id)) return 'staged';
            const rows = service.keys.map(id => state.keys.find(row => row.id === id));
            if (!rows.length) return 'noKey';
            if (rows.some(row => row.ready === undefined)) return 'checking';
            if (rows.some(row => !row.ready)) return 'statusFailed';
            if (rows.every(row => row.configured)) return 'configured';
            if (rows.some(row => row.partial)) return 'partial';
            if (anonymousService(service, state)) {
                const allFacesKeyless = service.capabilities.every(face => face === 'aihot-api' || keylessService(service, face));
                return allFacesKeyless ? 'anonymous' : 'anonymousPartial';
            }
            return rows.some(row => row.configured) ? 'partial' : 'unconfigured';
        }
        /** 官方额度数值文案：按 payload.period 标注周期，不折算。 */
        function officialQuotaText(t, official, period) {
            const parts = [];
            if (official.remaining !== undefined && official.limit !== undefined) parts.push(t('quotaRemaining') + ' ' + official.remaining + ' / ' + official.limit);
            else if (official.remaining !== undefined) parts.push(t('quotaRemaining') + ' ' + official.remaining);
            else if (official.used !== undefined && official.limit !== undefined) parts.push(t('quotaUsed') + ' ' + official.used + ' / ' + official.limit);
            else if (official.used !== undefined) parts.push(t('quotaUsed') + ' ' + official.used);
            else if (official.limit !== undefined) parts.push(t('quotaLimit') + ' ' + official.limit);
            else if (official.raw) parts.push(official.raw);
            if (!parts.length) parts.push(t('quotaEstimate'));
            const prefix = period === 'monthly' ? t('quotaMonthly') : period === 'daily-bj' ? t('quotaDailyBj') : period === 'daily-utc' ? t('quotaDailyUtc') : '';
            const reset = official.resetsAt ? ' · ' + t('quotaResetAt') + ' ' + official.resetsAt : '';
            return (prefix ? prefix + '：' : '') + parts.join(' · ') + reset;
        }
        /** 单行四态：停用 > 无端点估算 > 未刷新 > official 自身状态。 */
        function quotaRowState(service, row) {
            if (row !== undefined && row.enabled === false) return 'disabled';
            if (!QUOTA_OFFICIAL_IDS.includes(service.id)) return 'estimate';
            if (row === undefined || row.official === undefined) return 'never';
            return row.official.kind === 'ok' ? 'ok' : 'unavailable';
        }
        /** 本地账本文案：三计数全零显示「今日未使用」。 */
        function quotaLedgerText(t, ledger) {
            if (ledger === undefined) return undefined;
            if (ledger.success === 0 && ledger.rateLimited === 0 && ledger.quotaFailures === 0) return t('quotaUnused');
            return t('quotaLocalCounts') + '：' + t('quotaSuccess') + '=' + ledger.success
                + ' · ' + t('quotaRateLimited') + '=' + ledger.rateLimited
                + ' · ' + t('quotaQuotaFailures') + '=' + ledger.quotaFailures;
        }
        function WebSearchFetchCard(props) {
            const { t, editKey, chooseStart, editService, editControl, editNumber, editOption, editParticipation, editView, toggleService, refresh, refreshQuota, save, discard } = props;
            const state = props.useWebSearchFetch(snapshot => snapshot);
            const onDiscard = React.useRef(props.leave);
            onDiscard.current = props.leave;
            React.useEffect(() => () => onDiscard.current(), []);
            const disabled = !state.available || !state.writable || state.saving;
            const jsx = react_jsx_runtime.jsx, jsxs = react_jsx_runtime.jsxs;
            const ui = _deepseek_ai_dsh_client_ui_primitives;
            const visible = SERVICES.filter(service => state.visibleServiceIds.includes(service.id));
            const presetId = 'wsf-preset-' + state.controls.preset;
            const startStatus = state.controls.preset === 'auto' ? 'autoReady' : 'fixedReady';
            const rerankField = state.optionFields.rerankEnabled;
            const siliconflow = state.keys.find(row => row.id === 'siliconflow');
            return jsxs('form', { className: 'wsf-settings', 'aria-label': t('title'), 'aria-busy': state.saving,
                onSubmit: event => event.preventDefault(), children: [
                    jsx('style', { children: SETTINGS_CSS }),
                    !state.available && jsx('p', { role: 'status', className: 'wsf-notice', children: t('unavailable') }),
                    !state.writable && state.available && jsx('p', { className: 'wsf-notice', children: t('readOnlyHint') }),
                    jsxs('section', { className: 'wsf-preference', 'aria-label': t('startTitle'), children: [
                        jsx('h3', { children: t('startTitle') }),
                        jsx('p', { className: 'wsf-muted', children: t('intro') }),
                        jsx('p', { role: 'status', children: (state.dirty ? t('staged') + ' · ' : '') + t(startStatus) }),
                        jsx(ui.Button, { type: 'button', variant: 'outline', disabled, 'aria-controls': 'wsf-call-settings',
                            onClick: () => chooseStart('auto'), children: t('setupAuto') }),
                        jsx('p', { className: 'wsf-muted', children: t('setupAutoHint') }),
                        jsx(ui.Button, { type: 'button', variant: 'outline', disabled: disabled || !state.anonymousServiceIds.length,
                            onClick: () => chooseStart('anonymous'), children: t('tryAnonymous') }),
                        jsx('p', { className: 'wsf-muted', children: t(state.anonymousServiceIds.length ? 'tryAnonymousHint' : 'anonymousUnavailable') }),
                    ] }),
                    jsxs('details', { id: 'wsf-call-settings', className: 'wsf-call-settings', open: state.view.callSettingsOpen,
                        onToggle: event => { if (event.currentTarget.open !== state.view.callSettingsOpen) editView({ callSettingsOpen: event.currentTarget.open }); }, children: [
                        jsxs('summary', { children: [
                            jsx('strong', { children: t('settingsTitle') }),
                            jsx('span', { className: state.invalid ? 'wsf-current-settings wsf-error' : 'wsf-current-settings', children: state.invalid ? t('invalidControls') : t(state.controls.preset + 'Preset') + ' · ' + t('organizeMode') }),
                            jsx('span', { className: 'wsf-chevron', 'aria-hidden': true, children: '›' }),
                        ] }),
                    jsxs('div', { className: 'wsf-preference', children: [
                        jsxs('div', { className: 'wsf-setting-row', children: [
                            jsx('span', { className: 'wsf-setting-label', children: t('presetLabel') }),
                            jsx(ui.SegmentedControl, { id: 'wsf-preset', value: state.controls.preset,
                                className: 'wsf-preset-segments',
                                label: t('presetLabel'), disabled, onChange: value => editControl('preset', value),
                                options: PRESETS.map(value => ({ value, label: t(value + 'Preset') })) }),
                            jsx('select', { className: 'wsf-select wsf-preset-compact', 'aria-label': t('presetLabel'), disabled,
                                value: state.controls.preset, onChange: event => editControl('preset', event.target.value),
                                children: PRESETS.map(value => jsx('option', { value, children: t(value + 'Preset') }, value)) }),
                        ] }),
                        jsx('p', { id: presetId + '-panel', role: 'tabpanel', 'aria-labelledby': presetId, className: 'wsf-muted',
                            children: t(state.controls.preset + 'PresetHint') }),
                    ] }),
                    jsxs('div', { className: 'wsf-preference', children: [
                        jsxs('div', { className: 'wsf-setting-row', children: [
                            jsx('span', { className: 'wsf-setting-label', children: t('modeLabel') }),
                            jsx('span', { children: t('organizeMode') }),
                        ] }),
                        jsx('p', { className: 'wsf-muted', children: t('organizeHint') }),
                    ] }),
                    jsxs('details', { className: 'wsf-advanced', children: [
                        jsxs('summary', { children: [
                            jsxs('span', { className: 'wsf-disclosure-copy', children: [jsx('strong', { children: t('advanced') }), jsx('span', { className: state.invalid ? 'wsf-error' : 'wsf-muted', children: t(state.invalid ? 'invalidControls' : 'advancedHint') })] }),
                            jsx('span', { className: 'wsf-chevron', 'aria-hidden': true, children: '›' }),
                        ] }),
                        jsx('div', { className: 'wsf-control-grid', children: Object.keys(NUMBER_CONTROLS).map(name => {
                            const field = state.numberFields[name];
                            return jsx('div', { children: jsx(ui.SettingsValueField, {
                                id: 'wsf-limit-' + name, label: t(name), numeric: true, disabled,
                                text: field.text, invalid: field.invalid, overridden: field.dirty,
                                overriddenLabel: t('staged'), resetLabel: t('resetField'),
                                invalidLabel: t('invalidNumber') + field.min + '–' + field.max,
                                hint: t('range') + ': ' + field.min + '–' + field.max,
                                onEdit: text => editNumber(name, text), onReset: () => editNumber(name, field.servedText),
                            }) }, name);
                        }) }),
                        jsx('p', { className: 'wsf-muted wsf-controls-hint', children: t('controlsHint') }),
                    ] }),
                    jsxs('div', { className: 'wsf-preference', children: [
                        jsxs('div', { className: 'wsf-setting-row', children: [
                            jsx('span', { className: 'wsf-setting-label', children: t('rerankTitle') }),
                            jsx(ui.Switch, { label: t('rerankTitle'), checked: rerankField.value === true, disabled,
                                onChange: checked => editOption('rerankEnabled', checked) }),
                        ] }),
                        jsx('p', { className: 'wsf-muted', children: t('rerankHint') }),
                        jsx(KeyField, { t, row: siliconflow, disabled, onEdit: text => editKey('siliconflow', text) }),
                        jsxs('p', { className: 'wsf-muted', children: [t('rerankModel') + ': ', jsx('code', { children: RERANK_MODEL })] }),
                    ] }),
                    ] }),
                    jsxs('div', { className: 'wsf-heading', children: [
                        jsx('h3', { children: t('servicesTitle') }),
                        jsx('span', { className: 'wsf-count', children: SERVICES.length + ' ' + t('servicesCount') }),
                        jsx(ui.Button, { type: 'button', variant: 'ghost', size: 'sm', onClick: refresh, disabled: state.saving, children: t('refresh') }),
                    ] }),
                    jsxs('details', { className: 'wsf-guide', children: [
                        jsxs('summary', { children: [jsx('span', { className: 'wsf-chevron', 'aria-hidden': true, children: '›' }), t('startGuide')] }),
                        jsx('p', { children: t('intro') }),
                        jsx('p', { children: t('keysHint') }),
                    ] }),
                    jsxs('div', { className: 'wsf-tools', children: [
                        jsxs('div', { className: 'wsf-search', children: [
                            jsx(ui.Input, { className: 'wsf-search-field', type: 'search', 'aria-label': t('searchLabel'), placeholder: t('searchPlaceholder'), value: state.view.query,
                                onChange: event => editView({ query: event.target.value }) }),
                            state.view.query && jsx(ui.Button, { type: 'button', variant: 'ghost', size: 'sm', className: 'wsf-clear', 'aria-label': t('clearSearch'),
                                onClick: event => { editView({ query: '' }); event.currentTarget.closest('.wsf-search').querySelector('input').focus(); }, children: '×' }),
                        ] }),
                        jsx('select', { className: 'wsf-status-filter', 'aria-label': t('statusFilter'), value: state.view.status, onChange: event => editView({ status: event.target.value }),
                            children: ['all', 'needsKey', 'pending', 'noKey'].map(value => jsx('option', { value, children: t(value === 'all' ? 'allStatus' : value) }, value)) }),
                    ] }),
                    jsxs('div', { className: 'wsf-filters', role: 'group', 'aria-label': t('searchLabel'), children: [
                        ...['all', 'search', 'fetch'].map(capability => jsxs(ui.Button, { type: 'button', size: 'sm', variant: state.view.capability === capability ? 'outline' : 'ghost', className: 'wsf-filter',
                            'aria-pressed': state.view.capability === capability, onClick: () => editView({ capability }), children: [
                                t(capability), jsx('span', { className: 'wsf-filter-count', 'aria-hidden': true,
                                    children: SERVICES.filter(service => capability === 'all' || service.capabilities.includes(capability)).length }),
                            ] }, capability)),
                        jsx('span', { className: 'wsf-results-count', role: 'status', children: visible.length + ' ' + t('matches') }),
                    ] }),
                    jsx('div', { className: 'wsf-list', children: visible.length ? visible.map(service => {
                        const expanded = state.view.expandedId === service.id;
                        const status = serviceStatus(service, state);
                        const missingKey = service.keys.some(id => { const row = state.keys.find(row => row.id === id); return row.ready && !row.configured && !row.staged; });
                        const name = t(service.id + '-service');
                        const detailId = 'wsf-detail-' + service.id;
                        const baseURLName = service.id === 'anysearch' ? 'anysearchBaseURL' : service.id === 'firecrawl' ? 'firecrawlBaseURL' : undefined;
                        const baseURLField = baseURLName ? state.optionFields[baseURLName] : undefined;
                        return jsxs('section', { className: 'wsf-service', 'aria-label': name, children: [
                            jsxs('div', { className: 'wsf-row', children: [
                                jsxs('button', { type: 'button', className: 'wsf-open', 'aria-expanded': expanded,
                                    'aria-controls': detailId, 'aria-label': t('configure') + ' ' + name, onClick: () => toggleService(service.id), children: [
                                        jsxs('span', { className: 'wsf-name', children: [jsx('strong', { children: name }), jsx('small', { children: t(service.capability) + (ANONYMOUS_SERVICE_IDS.includes(service.id) ? ' · ' + t('recommended') : service.id === 'http' ? '' : ' · ' + t('enhancement')) })] }),
                                        jsx('span', { className: 'wsf-state', 'data-dirty': status === 'staged', children: t(status) }),
                                        jsx('span', { className: 'wsf-chevron', 'aria-hidden': true, children: expanded ? '⌄' : '›' }),
                                    ] }),
                                jsx(ui.Switch, { label: t('enable') + ' ' + name,
                                    checked: state.engines[service.id], disabled, onChange: checked => editService(service.id, checked) }),
                            ] }),
                            jsx('div', { id: detailId, hidden: !expanded, children: expanded && jsxs('div', { className: 'wsf-detail', children: [
                                jsx('p', { className: 'wsf-muted', children: t(service.id + 'Hint') }),
                                service.id !== 'http' && jsx('div', { className: 'wsf-participation', children: service.capabilities.filter(face => face === 'search' || face === 'fetch').map(face => {
                                    const allowed = state.controls.preset !== 'free' || keylessService(service, face);
                                    return jsx(ui.Checkbox, { disabled: disabled || !allowed, label: t(face === 'search' ? 'participateSearch' : 'participateFetch'),
                                        checked: allowed && state.controls[face === 'search' ? 'searchServices' : 'fetchServices'].includes(service.id),
                                        onChange: checked => editParticipation(service.id, face, checked) }, face);
                                }) }),
                                baseURLName && baseURLField && jsx('div', { children: [
                                    jsxs('div', { className: 'wsf-setting-row', children: [
                                        jsx('span', { className: 'wsf-setting-label', children: t(baseURLName) }),
                                        jsx(ui.Input, { type: 'text', 'aria-label': t(baseURLName), placeholder: t('baseURLPlaceholder'),
                                            value: baseURLField.value, disabled, onChange: event => editOption(baseURLName, event.target.value) }),
                                    ] }),
                                    jsx('p', { className: 'wsf-muted', children: t('baseURLHint') }),
                                ] }),
                                service.id === 'anysearch' && jsxs('div', { children: [
                                    jsxs('div', { className: 'wsf-setting-row', children: [
                                        jsx('span', { className: 'wsf-setting-label', children: t('anysearchZone') }),
                                        jsx('select', { className: 'wsf-select', 'aria-label': t('anysearchZone'), disabled,
                                            value: state.optionFields.anysearchZone.value,
                                            onChange: event => editOption('anysearchZone', event.target.value),
                                            children: OPTION_FIELDS.anysearchZone.options.map(value =>
                                                jsx('option', { value, children: value === '' ? t('zoneDefault') : value === 'cn' ? t('zoneCn') : t('zoneIntl') }, value)) }),
                                    ] }),
                                    jsx('p', { className: 'wsf-muted', children: t('zoneHint') }),
                                ] }),
                                service.id === 'aihot' && jsx('p', { className: 'wsf-muted', children: t('aihotTerms') }),
                                ...service.keys.map(id => jsx(KeyField, { t, row: state.keys.find(row => row.id === id), disabled, onEdit: text => editKey(id, text) }, id)),
                                service.keys.length > 0 && (!state.engines[service.id] || missingKey && !anonymousService(service, state))
                                    && jsx('p', { className: 'wsf-notice', children: t(!state.engines[service.id] ? 'enableWarning' : 'missingWarning') }),
                                service.keys.length > 0 && status === 'statusFailed' && jsx('button', { type: 'button', className: 'wsf-link', onClick: refresh, children: t('refresh') }),
                            ] }) }),
                        ] }, service.id);
                    }) : jsxs('div', { className: 'wsf-empty', children: [
                        jsx('h3', { children: t('noMatches') }), jsx('p', { className: 'wsf-muted', children: t('noMatchesHint') }),
                        jsx(ui.Button, { type: 'button', variant: 'outline', size: 'sm', onClick: () => editView({ query: '', capability: 'all', status: 'all' }), children: t('resetFilters') }),
                    ] }) }),
                    jsxs('section', { className: 'wsf-preference wsf-quota', 'aria-label': t('quotaTitle'), children: [
                        jsxs('div', { className: 'wsf-heading', children: [
                            jsx('h3', { children: t('quotaTitle') }),
                            jsx(ui.Button, { type: 'button', variant: 'ghost', size: 'sm', onClick: refreshQuota,
                                disabled: state.saving || state.quota.refreshing,
                                children: t(state.quota.refreshing ? 'quotaRefreshing' : 'quotaRefresh') }),
                        ] }),
                        jsx('p', { className: 'wsf-muted', children: t('quotaHint') }),
                        state.quota.channelError
                            ? jsx('p', { role: 'status', className: 'wsf-notice', children: t('quotaChannelUnavailable') + (state.quota.channelErrorReason ? '：' + state.quota.channelErrorReason : '') })
                            : jsxs('div', { className: 'wsf-quota-list', children: SERVICES.filter(service => service.id !== 'http').map(service => {
                                const row = state.quota.engines.find(item => item.id === service.id);
                                const quotaState = quotaRowState(service, row);
                                const name = t(service.id + '-service');
                                const status = serviceStatus(service, state);
                                const label = quotaState === 'disabled' ? t('quotaDisabled')
                                    : quotaState === 'estimate' ? t('quotaEstimate')
                                    : quotaState === 'never' ? t('quotaNeverRefreshed')
                                    : quotaState === 'unavailable' ? row.official.reason
                                    : officialQuotaText(t, row.official, row.period ?? QUOTA_PERIODS[service.id] ?? 'none');
                                const ledgerText = quotaLedgerText(t, row?.ledger);
                                const notes = [];
                                if (service.id === 'zhihu') notes.push(t('zhihuQuotaScope'));
                                if (service.id === 'firecrawl' && status === 'anonymousPartial') notes.push(t('firecrawlKeyless'));
                                return jsxs('div', { className: 'wsf-quota-row', 'data-quota-engine': service.id, 'data-quota-state': quotaState, children: [
                                    jsxs('span', { className: 'wsf-quota-name', children: [
                                        jsx('strong', { children: name }),
                                        jsx('small', { children: t(status) }),
                                    ] }),
                                    jsx('span', { className: 'wsf-quota-state', children: label }),
                                    ledgerText && jsx('span', { className: 'wsf-quota-detail', children: ledgerText }),
                                    ...notes.map(note => jsx('span', { className: 'wsf-quota-note', children: note })),
                                ] }, service.id);
                            }) }),
                        jsx('p', { className: 'wsf-muted wsf-quota-footnote', children: t('quotaFootnote') }),
                    ] }),
                    state.failed && jsx('p', { role: 'alert', className: 'wsf-error', children: t('saveFailed') }),
                    jsxs('div', { className: 'wsf-footer', children: [
                        jsx('p', { className: state.invalid ? 'wsf-footer-status wsf-error' : 'wsf-footer-status', role: 'status', children: state.invalid ? t('invalidControls') : state.saving ? t('saving') : state.dirty ? state.changeCount + ' ' + t('dirty') : state.saved ? t('saved') : t('clean') }),
                        jsxs('div', { className: 'wsf-footer-actions', children: [
                            jsx(ui.Button, { type: 'button', variant: 'ghost', size: 'sm', disabled: state.saving || !state.dirty, onClick: discard, children: t('discard') }),
                            jsx(ui.Button, { type: 'button', variant: 'primary', size: 'sm', disabled: disabled || !state.dirty || state.invalid, onClick: save, children: t(state.saving ? 'saving' : 'save') }),
                        ] }),
                    ] }),
                ] });
        }
        //#endregion
		//#region apply
		/** Required services (cordis fiber inject). */
		const inject = [ "slots", "locale", "remote", "remote.credentials", "connection", "configForms" ];
		/**
		* Mount this plugin's settings tab while the Host serves its namespace.
		*
		* The registration follows `configForms.whileServed`, so a deployment that
		* never composed this plugin shows no trace of the tab.
		* @param ctx - the browser plugin context.
		*/
		function apply(ctx) {
			const t = ctx.locale.bind(NS);
			ctx.effect(() => ctx.locale.register(NS, { zh, en }), "ui-settings-web-search-fetch: dictionaries");
			const card = new WebSearchFetchCardController(ctx.configForms.get(SETTINGS_NS), ctx);
			ctx.effect(() => () => {
				card.dispose();
			}, "ui-settings-web-search-fetch: form subscription");
			ctx.effect(() => ctx.remote.$on("credentials/reference-updated", (ref) => {
				card.refreshCredential(ref);
			}), "ui-settings-web-search-fetch: credential invalidations");
			// 额度数据通道：直调 connection.rpc（三方正路，与 dsh-plugin-subscriptions 同款），
			// 不经 $mount——其异步 effect 在真实插件 fiber 上不落定（T0 在裸 Context 上验证，
			// 覆盖不到 fiber 语义，真机实测发现挂起）。宿主侧 Typert 服务保留，端点
			// 'quotaPanel/<方法>'；线格式与网关客户端 unary 调用一致：{ args: {} } → RemoteResult。
			// 通道失败只影响额度小节（spec §4/R12）。
			{
				const rpc = ctx.connection?.rpc;
				if (rpc !== undefined && typeof rpc.call === 'function') {
					const call = method => rpc.call('/api', 'quotaPanel/' + method, { args: {} });
					card.attachQuotaService({ get: () => call('get'), refresh: () => call('refresh') });
				} else {
					card.failQuotaChannel('连接服务不可用');
				}
			}
			const bundleFace = () => ({
				hooks: { webSearchFetch: card.store },
				editKey: (id, text) => { card.editKey(id, text); },
				chooseStart: choice => card.chooseStart(choice),
				editView: (next) => card.editView(next),
				toggleService: (id) => card.toggleService(id),
				refresh: () => card.readCredentials(),
				refreshQuota: () => card.refreshQuota(),
				editService: (id, enabled) => card.editService(id, enabled),
				editControl: (name, value) => card.editControl(name, value),
				editNumber: (name, text) => card.editNumber(name, text),
				editOption: (name, value) => card.editOption(name, value),
				leave: () => card.leave(),
				editParticipation: (id, face, enabled) => card.editParticipation(id, face, enabled),
				save: () => card.save(),
				discard: () => { card.discard(); },
			});
			// 兜底入口：配置面未被宿主投影时（老宿主）仍提供 settings.section。
			// 根级 volatile 生效后 whileServed 会触发；原生 tab/bundle 是正式座位，
			// 此时释放兜底，避免同一页面出现重复入口。
			let sectionDispose;
			let servedByHost = false;
			const isDisposer = value => typeof value === 'function'
				|| (value !== undefined && value !== null && typeof value.dispose === 'function');
			const releaseSection = () => {
				const dispose = sectionDispose;
				sectionDispose = undefined;
				if (typeof dispose === 'function') dispose();
				else if (dispose !== undefined && dispose !== null && typeof dispose.dispose === 'function') dispose.dispose();
			};
			const markServed = () => {
				servedByHost = true;
				releaseSection();
			};
			ctx.effect(() => ctx.configForms.whileServed([SETTINGS_NS], () => {
				markServed();
				return ctx.slots.inject("settings.plugins.tab", () => ctx.slots.register({
					name: "settings.plugins.tab",
					id: "web-search-fetch",
					order: 20,
					label: () => t("title"),
					locale: NS,
					inject: bundleFace
				}, WebSearchFetchCard));
			}), "ui-settings-web-search-fetch: page");
			// rc.2 renders bundle configuration on the Plugins page, keyed by
			// package name. Keep the settings tab above for older hosts.
			ctx.effect(() => ctx.configForms.whileServed([SETTINGS_NS], () => {
				markServed();
				return ctx.slots.inject("plugins.bundle.config", () => ctx.slots.register({
					name: "plugins.bundle.config",
					key: "dsh-web-search-fetch",
					locale: NS,
					inject: bundleFace,
				}, WebSearchFetchCard));
			}), "ui-settings-web-search-fetch: bundle page");
			// settings.section 不依赖 configForms 投影（DSH-Store 与
			// dsh-plugin-subscriptions 同款注册方式），只作不可投影宿主的兜底。
			ctx.effect(() => {
				let registered;
				const injected = ctx.slots.inject("settings.section", () => {
					registered = ctx.slots.register({
						name: "settings.section",
						id: "web-search-fetch",
						order: 20,
						label: () => t("title"),
						locale: NS,
						inject: bundleFace
					}, WebSearchFetchCard);
					return registered;
				});
				// 兼容 inject 直接返回 disposer，以及返回 void、只有 register 返回 disposer 的宿主。
				sectionDispose = isDisposer(injected) ? injected : registered;
				if (servedByHost) releaseSection();
				return () => releaseSection();
			}, "ui-settings-web-search-fetch: settings section");
		}
		//#endregion
		/**
		* 测试面：只读导出的表面常量，供离线契约测试与 registry 比对。
		* 不参与运行时逻辑。
		*/
		const SURFACE = Object.freeze({
			serviceIds: Object.freeze(SERVICES.map(service => service.id)),
			credentialRefs: Object.freeze(CREDENTIAL_SLOTS.map(slot => slot.defaultRef)),
			presets: Object.freeze([...PRESETS]),
			freePresetServiceIds: Object.freeze(SERVICES.filter(service => service.id !== 'http' && service.capabilities.includes('search') && keylessService(service, 'search')).map(service => service.id)),
			freePresetFetchServiceIds: Object.freeze(SERVICES.filter(service => service.id !== 'http' && service.capabilities.includes('fetch') && keylessService(service, 'fetch')).map(service => service.id)),
			maxSearchServices: NUMBER_CONTROLS.maxSearchServices.max,
			maxFetchServices: NUMBER_CONTROLS.maxFetchServices.max,
			localeKeys: Object.freeze({ zh: Object.freeze(Object.keys(zh)), en: Object.freeze(Object.keys(en)) }),
			localeValues: Object.freeze({ zh: Object.freeze({ ...zh }), en: Object.freeze({ ...en }) }),
			rerankModel: RERANK_MODEL,
			quotaEngines: Object.freeze(SERVICES.filter(service => service.id !== 'http').map(service => Object.freeze({
				id: service.id,
				period: QUOTA_PERIODS[service.id],
				official: QUOTA_OFFICIAL_IDS.includes(service.id),
			}))),
			anonymousServiceIds: Object.freeze([...ANONYMOUS_SERVICE_IDS]),
			services: Object.freeze(SERVICES.map(service => Object.freeze({
				id: service.id,
				capabilities: Object.freeze([...service.capabilities]),
				free: service.free,
				keyless: service.keyless,
				keylessCapabilities: service.keylessCapabilities === undefined ? undefined : Object.freeze([...service.keylessCapabilities]),
				auth: service.auth,
				enabledByDefault: service.enabledByDefault,
			}))),
			credentialSlots: Object.freeze(CREDENTIAL_SLOTS.map(slot => Object.freeze({
				id: slot.id,
				overridePaths: Object.freeze(slot.overridePaths.map(path => Object.freeze([...path]))),
				defaultRef: slot.defaultRef,
			}))),
		});
		exports.NS = NS;
		exports.apply = apply;
		exports.inject = inject;
		exports.SURFACE = SURFACE;
		return module.exports;
	}
});
