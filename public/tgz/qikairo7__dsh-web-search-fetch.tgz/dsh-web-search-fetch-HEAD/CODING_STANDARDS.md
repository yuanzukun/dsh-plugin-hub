# CODING_STANDARDS.md

本文件是编码、测试与交付的操作标准；架构理由与完整说明见 [`docs/development.md`](docs/development.md) 与 [`DESIGN.md`](DESIGN.md)。代理开工先读 [`AGENTS.md`](AGENTS.md)。

环境：Node.js `^22.19.0 || >=24.0.0`，pnpm `12.10.1`。

## 结构

```text
src/index.ts       装配层：插件定义、配置、凭证解析、意图→引擎映射、provider 注册
src/search/        搜索编排：意图路由、缓存、派发、融合、重排、降级
src/fetch/         提取编排：URL 分流、两段式探测、正文整理、择优
src/engines/       引擎适配；registry.ts 是服务清单、端点、鉴权与服务级默认开关的唯一事实源
src/support/       横切机制：预算、熔断、额度、地址守卫、URL 归一
client/index.js    设置页客户端（原生 JS，由 DSH ModuleLoader 装载，不经 tsc）
test/              离线测试；architecture.test.ts 机器强制分层
scripts/           构建、门禁、真实探针、基准与打包脚本
lib/               Git 跟踪的编译产物（pnpm run build 生成，不手改）
docs/              文档；docs/agents/ 是代理细则，docs/adr/ 是决策记录
cordis.patch.yml   DSH bundle 装配补丁
```

- 依赖边界：装配层负责具体引擎实例化；`src/search/`、`src/fetch/`、`src/support/` 只依赖 `engines/contract`、`failure`、`http`、`registry` 这些契约/共享模块，不依赖具体适配器；具体适配器不依赖编排层。
- 分层红线：`src/search/`、`src/fetch/`、`src/support/` 不得 import 具体引擎模块，也不得出现五个引擎 id 的字面量；只允许 `engines/contract`、`failure`、`http`、`registry`。`test/architecture.test.ts` 会红。
- 服务清单只存在于 `src/engines/registry.ts`；设置页、服务级默认开关与 `free` 名单由 registry 派生；请求上限、超时与重排等 `Config` 默认值在装配层定义。客户端不能 import 宿主模块，保留一份服务表，由 `test/client-surface.test.ts` 与 registry 对齐。
- 新引擎接入：`src/engines/<id>.ts` + `registry.ts` 的 manifest + 装配层 `buildEngines` 一行；客户端服务表与架构测试按测试提示同步，编排层与支撑层零改动。
- `lib/` 是跟踪产物，只由 `pnpm run build` 生成；客户端改动仍用原生 JS，不引入 TypeScript 构建。
- 公开源码不写本机绝对路径、用户目录路径、凭证、日志、临时报告、`node_modules/`、`.scratch/`；本机细节只进 `LOCAL.md`（gitignored）。

## 代码

- TypeScript strict + NodeNext ESM；相对 import 必须带 `.js` 后缀；目标 ES2023。
- 沿用现有格式：2 空格缩进、单引号、无分号、多行尾随逗号。新增注释用中文，写约束和原因，不复述代码。
- 最小完整改动：单次使用的逻辑就近内联；出现第二个调用点再抽象；不提前拆 helper。
- 外部输入只在入口校验一次，内部靠类型系统流转；不层层判空或重复防御。几乎不会发生的边界、并发、异常，先说明概率与成本，经用户确认再加。
- 源文件保持 500 行或以下；测试、文档与 CSS 文件除外。本次改动导致源文件超限时，完成前拆分。
- 非必要不用 `try/catch`；能单函数清晰完成的不硬拆。
- 错误只用 `src/engines/failure.ts` 的 `EngineFailure` 九类词表；目标站失败是 `target-status`，引擎失败是 `provider-error`，不发明私有错误类型。
- `truncated` 逐层传播：任一层截断都置真并向上传。
- 状态与呈现分离：编排层产出 `Note` / `EngineFailure` 等结构化状态，中文文案集中在呈现处；测试锚状态字段，不锚整句文案。
- 反胶水：不逐字转发，不复制粘贴适配，同一清单只存在一次；每层只答一个问题。细则见 `docs/development.md` §2–§3。
- 编码任务按 `ponytail-DietrichGebert` 的 full 级别执行；复核用 `code-review` 双轴；Issue/PR 处理用 `issue-pipeline`；中文技术文档用 `tech-doc-style-chinese`。完整路由见 [`docs/agents/skill-routing.md`](docs/agents/skill-routing.md)。
- 新增运行时依赖先说明必要性、许可证与分发影响；引入外部代码同步更新 `NOTICE`。

## 命令

| 目的 | 命令 |
| --- | --- |
| 安装依赖 | `pnpm install --frozen-lockfile` |
| 构建到 `lib/` | `pnpm run build` |
| 本机挂载 | 先 `pnpm run build`，再 `dsh plugin --profile <profile> add link:<仓库绝对路径>` |
| 真实调用探针 | `pnpm run smoke:live`（在具备 DSH 与网络的环境运行，消耗额度前取得同意） |
| 发布候选包 | `pnpm run pack:candidate` |
| 全部测试 | `pnpm test` |
| 仅项目测试目录 | `pnpm exec vitest run --dir test` |
| 单个测试文件 | `pnpm exec vitest run test/search/router.test.ts` |
| 类型检查 | `pnpm run typecheck` |
| 仓库与文档门禁 | `pnpm run check:repository` |
| 完整门禁 | `pnpm run check` |
| 分发产物检查 | `pnpm run check:distribution`（先暂存 `lib/`） |
| 分发清单 | `npm pack --dry-run` |

- 挂载后重启宿主，再用原生 `web_search` / `web_fetch` 实际调用；`dsh --profile <profile> --dump-config` 只证明装载，不证明调用可用。
- 门禁以退出码判定，不看「输出里没搜到错误字样」；不要用裸管道或 `tail` 截断门禁输出。
- Vitest 的路径位置参数是子串匹配；单文件用完整路径，目录过滤在末尾加 `/`。
- 本地 `.scratch/` 有外部克隆时，`pnpm test` 会扫到它们的测试；用 `pnpm exec vitest run --dir test` 只跑本项目 `test/`。此时 `pnpm run check` 的测试段也会被污染；分项验证不能冒充完整 `check`，未跑完整 `check` 须标未验证并取得用户同意，CI 在干净检出跑完整 `check`。

## 测试与验收

- 测试一律离线：注入 fetcher/lookup 或用本地夹具，不碰真实服务、系统进程、线上环境。第三方响应夹具先读厂商官方 API 文档，并在注释里引用 URL。
- 修复 bug：先复现，再加回归测试；把修复就地还原后新测试必须红得指向该行为，恢复后必须绿。断言只认 bug 报告点名的单一可观察结果，不接受「两种结果都算过」。
- 行为断言至少一条从生产入口可达；合成腿测试只能作补充，注释写明边界。
- 不跳过慢测试，不用只读替代冒充门禁通过。
- 改动涉及外部服务行为、DSH 宿主交互或 UI 时，离线测试之外还要过真实调用；配置默认值与内部行为改动仍按行为改动验收；纯文档或纯内部重构且无外部行为变化时，用离线测试与新旧差异证据验收，并在 PR 写核对范围。UI 验收用真实界面截图，并在 PR 注明所用工具。

## 完成

- `pnpm run check` 退出码 0（构建、Vitest、类型检查、仓库门禁全部通过）；本地 `.scratch/` 污染测试扫描时，按命令节的替代组合验证并标未验证，是否跳过完整 `check` 由用户决定。
- 涉 `src/`：`lib/` 已重建并暂存；`pnpm run check:distribution` 通过；`git diff --exit-code -- lib` 干净。
- 行为修复有 revert-变红证据；断言指向 bug 报告点名的单一可观察结果。
- 行为或功能变化已同步 `README.md` 与 `docs/README.md` 列出的受影响文档面（`README.md`、`docs/configuration.md`、`GLOSSARY.md`、`DESIGN.md` 对应节）；spec 的需求、边界与决策回写 `DESIGN.md`、`GLOSSARY.md` 或 ADR。
- 分发文件变化时 `npm pack --dry-run` 清单正确。
- PR 正文四段：问题、最终行为、验证命令、未验证部分。PR 草稿前先完成独立复核，记录 base/candidate SHA 与 `PASS` 结论；审后新 push 不沿用旧结论。
- 提交包含本次改动所需的代码、测试、`lib/` 产物与文档；报告候选 SHA。没跑的检查列入未验证项；无法执行的检查标 `BLOCKED`，写清缺什么条件。

## 复核

复核在独立上下文（只读子代理或另一会话）对固定 SHA 进行，复核者不参与实现；审前审后核对仓库状态未变。结论写 `PASS` / `FAIL`，findings 附命令、退出码与 SHA。无法获得独立上下文时标明未验证，不能同会话自审冒充通过。

- Standards 轴：分层与依赖方向、registry 单一事实源、反胶水清单、错误模型、`truncated` 传播、代码风格。
- Spec 轴：逐条对照验收 Scenario，确认每个 `THEN` 有对应测试或探针证据。
- 测试咬合：bug 修复有 revert-变红；断言不是双结果；行为断言从生产入口可达，合成腿测试只能作补充。
- 隐藏字段：改动提前返回或空结果分支时，用旧构建与新构建、同一探针逐字段对照 `truncated`、操作说明等未跟踪字段。
- 分发与文档：`lib/` 与 `src/` 一致；`README.md`、`DESIGN.md`、`docs/configuration.md`、`GLOSSARY.md` 与实际行为一致；第三方夹具形状有官方文档依据。
- 同一改动最多 3 轮复核；第 3 轮仍 `FAIL` 就停下重审方案；第 2 轮起只报新增改动的问题，首轮已通过的部分不重复挑。
- 每合并 5 个 PR 或发版前，抽查 `README.md`、`DESIGN.md`、`docs/` 与已合并 PR 的一致性；合并数用 `gh pr list --state merged --limit 100` 核对。
