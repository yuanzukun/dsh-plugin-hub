import type { WebFetchResult } from '@deepseek-ai/dsh-web';
/** 探测结果被原样提供前必须达到的段落字符数。 */
export declare const PROBE_MIN_PARAGRAPH_CHARS = 400;
/**
 * 两段式判定的一个字段：原样结果所服务的 URL。
 * 探测是动态提取的默认路径——恰好花一次请求；
 * 当正文本身已是完整答案时直接返回页面自己的文本。
 */
export interface ProbeVerdict {
    /** 探测结果能否不加多路整理与标记直接返回。 */
    readonly sufficient: boolean;
    /** 探测不足的原因，供管线日志。 */
    readonly reason?: 'challenge' | 'target-mismatch' | 'non-2xx' | 'body-thin';
}
/**
 * 判定一次探测结果是否已是完整答案。
 *
 * 门槛刻意收窄：必须是请求目标的 `2xx`（允许同资源的 HTTPS 升级）、不是登录或挑战页、
 * 且至少带 {@link PROBE_MIN_PARAGRAPH_CHARS} 字符的普通段落。任何一项不足都升级到多路整理，
 * 由多路提取合并并加标记。
 * @param requestedUrl - 调用方请求的 URL。
 * @param result - 探测请求返回的结果。
 * @returns 判定；不足时带升级原因。
 */
export declare function probeVerdict(requestedUrl: string, result: WebFetchResult): ProbeVerdict;
/**
 * 两个 URL 是否指向同一资源。同资源的 HTTPS 升级可以接受（查询串、路径与端口必须一致）；
 * 其余变化都不算同一目标。
 */
export declare function sameResource(requested: string, returned: string): boolean;
