import { WebError, type WebFetchRequest, type WebFetchResult } from '@deepseek-ai/dsh-web';
import { type AddressLookup } from '../support/address-guard.js';
import type { OpContext } from '../support/budget.js';
import type { FetchPipelineLogger } from './aggregate.js';
import type { StaticHttpFetcher } from './provider.js';
import type { FetchRouteOptions } from './route.js';
interface TargetGuardOptions {
    readonly blockPrivateAddresses?: boolean;
    readonly route?: FetchRouteOptions;
    readonly lookup?: AddressLookup;
    readonly logger?: FetchPipelineLogger;
}
/** 私有目标不得抵达专用 API、适配器或任何第三方引擎。 */
export declare function guardFetchTarget(url: string, op: OpContext, options: TargetGuardOptions): Promise<void>;
/** 静态路：单次 HTTP 抓取，零引擎调用。 */
export declare function fetchStatic(request: WebFetchRequest, op: OpContext, http: StaticHttpFetcher | undefined): Promise<WebFetchResult>;
/** 操作自身取消 → seam 的取消码。 */
export declare function abortedError(signal: AbortSignal): WebError;
export {};
