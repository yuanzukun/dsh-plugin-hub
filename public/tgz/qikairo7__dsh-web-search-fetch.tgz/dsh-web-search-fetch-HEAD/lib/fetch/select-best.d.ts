import type { WebFetchResult } from '@deepseek-ai/dsh-web';
import type { FetchCandidate } from './types.js';
export type { FetchCandidate } from './types.js';
/** 长度分在多少字符时饱和。 */
export declare const LENGTH_SCORE_FULL_CHARS = 2000;
/** 长度分上限，在 {@link LENGTH_SCORE_FULL_CHARS} 字符时达到。 */
export declare const LENGTH_SCORE_MAX = 2;
/** 文本密度信号（文字字符 / 总字符）上限。 */
export declare const DENSITY_SCORE_MAX = 1;
/** slug 与标题匹配信号上限。 */
export declare const TITLE_MATCH_SCORE_MAX = 1.5;
/** 在正文头部多少字符内查找标题。 */
export declare const TITLE_WINDOW_CHARS = 500;
/** 没有显式权重的引擎使用的默认权重（v0.3：全部引擎同权）。 */
export declare const DEFAULT_ENGINE_WEIGHT = 2;
/** 进入选择的一个候选。 */
export interface ScoredCandidate extends FetchCandidate {
    readonly score: number;
    readonly breakdown: CandidateScoreBreakdown;
}
/** 候选得分背后的逐信号分解，供测试与日志。 */
export interface CandidateScoreBreakdown {
    readonly weight: number;
    readonly length: number;
    readonly density: number;
    readonly titleMatch: number;
}
/**
 * 候选是否算可用正文：200 但正文为空（或纯空白）无效、不计分。
 */
export declare function isUsableCandidate(result: WebFetchResult): boolean;
/** URL 最后一个路径段：分隔符归一为空格并小写。 */
export declare function extractUrlSlug(rawUrl: string): string;
/**
 * 正文的标题：在前 {@link TITLE_WINDOW_CHARS} 字符内取第一个 markdown 标题；
 * 否则取首个非空行。都没有时为空。
 */
export declare function extractBodyTitle(text: string): string;
/** 两个标题词元集合的 Jaccard 相似度；空输入得 0。 */
export declare function titleSimilarity(a: string, b: string): number;
/** 一致性指纹：正文 sha1 的前 8 位十六进制。 */
export declare function bodyFingerprint(text: string): string;
/**
 * 给一个候选打分：引擎权重 + 正文长度（封顶）+ 正文密度 + slug 与标题匹配。
 * 确定性纯函数，选择因此可复现。
 */
export declare function scoreCandidate(engineId: string, result: WebFetchResult, requestUrl: string, weights?: Readonly<Record<string, number>>): ScoredCandidate;
/**
 * 择优：取最高分的可用候选；平手时先到先得（引擎派发顺序）。
 * 空正文候选排除；只有没有任何可用候选时 `best` 才是 `undefined`。
 */
export declare function selectBestCandidate(requestUrl: string, candidates: readonly FetchCandidate[], weights?: Readonly<Record<string, number>>): {
    best: ScoredCandidate | undefined;
    scored: readonly ScoredCandidate[];
};
