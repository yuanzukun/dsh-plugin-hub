import type { Engine, EngineContext, EngineManifest } from '../engines/contract.js';
import { type EngineFailure } from '../engines/failure.js';
import type { OpContext } from '../support/budget.js';
import { type LaneLogSink } from '../support/lane-runner.js';
import type { LaneSettlement } from '../support/lane-settlement.js';
import type { FetchCandidate } from './types.js';
/** 提取管线日志汇（装配层映射到 ctx.logger）。 */
export interface FetchPipelineLogger {
    info(message: string): void;
    warn(message: string): void;
}
/** 装配层提供的引擎上下文构造器：凭证解析、端点覆盖、keyless 回退都归装配。 */
export type BuildEngineContext = (manifest: EngineManifest, op: OpContext, lane: {
    signal: AbortSignal;
    deadline: number;
    face: 'fetch' | 'quota';
}) => Promise<EngineContext>;
/** fetch 层兜底投影可能携带引擎违约上抛的原始 seam 码。 */
export interface FetchLaneFailure extends EngineFailure {
    readonly webCode?: string;
}
/** 一次成功、失败、超时或被取消的提取尝试。 */
export type ExtractionAttempt = {
    readonly kind: 'ok';
    readonly engineId: string;
    readonly candidate: FetchCandidate;
    readonly elapsedMs: number;
} | {
    readonly kind: 'failed';
    readonly engineId: string;
    readonly failure: EngineFailure;
    readonly code: string;
    readonly description: string;
    readonly elapsedMs: number;
} | {
    readonly kind: 'timeout';
    readonly engineId: string;
    readonly failure: EngineFailure;
    readonly code: 'WEB_FETCH_TIMEOUT';
    readonly description: string;
    readonly elapsedMs: number;
} | {
    readonly kind: 'aborted';
    readonly engineId: string;
};
export interface ExtractionAttemptOptions {
    readonly engine: Engine;
    readonly url: string;
    readonly op: OpContext;
    readonly buildContext: BuildEngineContext;
    readonly deadlineMs: number;
    /** 该路的上游取消信号；缺省只跟随操作信号。 */
    readonly signal?: AbortSignal;
    readonly settlement?: LaneSettlement;
    readonly logger?: FetchPipelineLogger;
    readonly now?: () => number;
}
/** 跑一次提取并结算；永不抛出，调用方按结局继续编排。 */
export declare function runExtractionAttempt(options: ExtractionAttemptOptions): Promise<ExtractionAttempt>;
/** 单路日志汇：带引擎前缀转发到管线 logger。 */
export declare function laneLogSink(logger: FetchPipelineLogger): LaneLogSink;
/**
 * 统一失败模型 → seam 的 WEB_* 码。
 * target-status 默认按目标站被拦；AnySearch HTTP 422 的普通提取失败仍归引擎侧，
 * 业务码 extract_target_blocked 优先。
 */
export declare function failureWebCode(failure: EngineFailure): string;
/** 引擎违反「不上抛」契约时的兜底投影：原始 WebError 码保真。 */
export declare function failureFromThrown(error: unknown): FetchLaneFailure;
