import { WebError } from '@deepseek-ai/dsh-web';
import type { WebFetchResult } from '@deepseek-ai/dsh-web';
import type { Engine, EngineContext, EngineManifest } from '../engines/contract.js';
import { type EngineFailure } from '../engines/failure.js';
import { type CircuitBreaker } from '../support/breaker.js';
import type { OpContext } from '../support/budget.js';
import type { FetchCandidate } from './types.js';
/** 单路提取默认 deadline（v0.2 DEFAULT_FETCH_ENGINE_TIMEOUT_MS = 45s）。 */
export declare const DEFAULT_FETCH_ENGINE_TIMEOUT_MS = 45000;
/** 提取管线日志汇（装配层映射到 ctx.logger）。 */
export interface FetchPipelineLogger {
    info(message: string): void;
    warn(message: string): void;
}
/** 装配层提供的引擎上下文构造器：凭证解析（异步、每操作）、端点覆盖、keyless 回退都归装配（AD2）。face 标明用途端点。 */
export type BuildEngineContext = (manifest: EngineManifest, op: OpContext, lane: {
    signal: AbortSignal;
    deadline: number;
    face: 'fetch' | 'quota';
}) => Promise<EngineContext>;
/** {@link aggregateDynamicFetch} 的入参。 */
export interface AggregateDynamicFetchOptions {
    /** 是否在「至少三路互补且有共同正文」后提前收掉慢渠道；auto 预设打开。 */
    readonly settleEarly?: boolean;
    /** 单页输出预算；缺省 {@link DEFAULT_MAX_OUTPUT_CHARS}。 */
    readonly maxOutputChars?: number;
    readonly url: string;
    /** registry 顺序的提取引擎表（只认 capabilities 含 fetch 且函数存在者由调用方过滤）。 */
    readonly engines: readonly Engine[];
    /** 显式操作上下文（预算、说明、deadline 判定）。 */
    readonly op: OpContext;
    readonly breaker?: CircuitBreaker;
    readonly buildContext: BuildEngineContext;
    readonly logger?: FetchPipelineLogger;
    /** 单路 deadline；缺省 {@link DEFAULT_FETCH_ENGINE_TIMEOUT_MS}。 */
    readonly perEngineTimeoutMs?: number;
    /**
     * 首路探测已取得的提取结果：作为普通候选并入整理，不再重复请求同一通道。
     */
    readonly seeds?: readonly FetchCandidate[];
    /** 结果已在 {@link seeds} 中的引擎；绝不重复派发。 */
    readonly skipEngineIds?: readonly string[];
    /** 时钟覆盖（测试）。 */
    readonly now?: () => number;
}
/** fetch 层兜底投影可能携带引擎违约上抛的原始 seam 码（EngineFailure 本身没有该字段）。 */
export interface FetchLaneFailure extends EngineFailure {
    readonly webCode?: string;
}
/**
 * AD6 投影：统一失败模型 → seam 的 WEB_* 码。
 * v0.3 引擎不携带 seam 码，按失败语义映射到最接近、最特异的一个：
 * - target-status：目标站级失败（403/404、extract_target_blocked）→ WEB_BLOCKED_URL；
 *   AnySearch HTTP 422 extract_failed 是引擎侧提取失败，归 WEB_PROVIDER_ERROR，不得进入
 *   target-rejected 组；但 422 载体上带 error_code=extract_target_blocked 时仍属目标站被拦，
 *   保持 WEB_BLOCKED_URL（业务码优先于状态码）。422 编码的 rank 也不得压过真实的
 *   WEB_FETCH_TIMEOUT / WEB_INVALID_URL（v0.2 test/fetch-aggregate.test.ts:509-528 的分组语义）。
 * - invalid → WEB_INVALID_URL；timeout → WEB_FETCH_TIMEOUT；aborted → WEB_ABORTED；
 *   其余引擎侧故障 → WEB_PROVIDER_ERROR。
 * 引擎违约上抛的 WebError 原始码优先（见 failureFromThrown）。
 */
export declare function failureWebCode(failure: EngineFailure): string;
/**
 * 引擎违反「不上抛」契约时的兜底投影：WebError 携带的具体 WEB_* 码必须保真
 * （v0.2 runLeg 的 `error instanceof WebError ? error.code` 同义），不能降级成
 * network/provider-error 后重映射。
 */
export declare function failureFromThrown(error: unknown): FetchLaneFailure;
/** 把一次引擎失败投影为 seam 错误（单通道路径与全败路径共用）。 */
export declare function failureWebError(failure: EngineFailure, label: string): WebError;
/**
 * 跑一个 URL 的动态路：并发派发每个未熔断引擎（每路独立 deadline）、转发熔断信号、
 * 只整理可用正文，且仅在全部引擎都失败后才抛错——错误码取观察到的最特异一个。
 */
export declare function aggregateDynamicFetch(options: AggregateDynamicFetchOptions): Promise<WebFetchResult>;
