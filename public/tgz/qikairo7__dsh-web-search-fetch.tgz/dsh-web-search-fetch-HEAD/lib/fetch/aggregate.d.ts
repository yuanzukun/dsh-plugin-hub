import type { WebFetchResult } from '@deepseek-ai/dsh-web';
import type { Engine } from '../engines/contract.js';
import type { CircuitBreaker } from '../support/breaker.js';
import type { OpContext } from '../support/budget.js';
import { LaneSettlement } from '../support/lane-settlement.js';
import { type BuildEngineContext, type FetchPipelineLogger } from './attempt.js';
import type { FetchCandidate } from './types.js';
export { failureFromThrown, failureWebCode } from './attempt.js';
export type { BuildEngineContext, FetchLaneFailure, FetchPipelineLogger } from './attempt.js';
/** 单路提取默认 deadline（45 秒）。 */
export declare const DEFAULT_FETCH_ENGINE_TIMEOUT_MS = 45000;
/** {@link aggregateDynamicFetch} 的入参。 */
export interface AggregateDynamicFetchOptions {
    /** 是否在「至少三路互补且有共同正文」后提前收掉慢渠道；provider 默认打开。 */
    readonly settleEarly?: boolean;
    /** 单页输出预算；缺省 {@link DEFAULT_MAX_OUTPUT_CHARS}。 */
    readonly maxOutputChars?: number;
    readonly url: string;
    /** registry 顺序的提取引擎表（只认 capabilities 含 fetch 且函数存在者由调用方过滤）。 */
    readonly engines: readonly Engine[];
    /** 显式操作上下文（预算、说明、deadline 判定）。 */
    readonly op: OpContext;
    readonly breaker?: CircuitBreaker;
    readonly buildContext: BuildEngineContext;
    readonly logger?: FetchPipelineLogger;
    /** 单路 deadline；缺省 {@link DEFAULT_FETCH_ENGINE_TIMEOUT_MS}。 */
    readonly perEngineTimeoutMs?: number;
    /**
     * 首路探测已取得的提取结果：作为普通候选并入整理，不再重复请求同一通道。
     */
    readonly seeds?: readonly FetchCandidate[];
    /** 结果已在 {@link seeds} 中的引擎；绝不重复派发。 */
    readonly skipEngineIds?: readonly string[];
    /** 时钟覆盖（测试）。 */
    readonly now?: () => number;
    /** 单路额度结算；缺省只喂熔断。 */
    readonly settlement?: LaneSettlement;
}
/**
 * 跑一个 URL 的动态路：并发派发每个未熔断引擎（每路独立 deadline）、转发熔断信号、
 * 只整理可用正文，且仅在全部引擎都失败后才抛错——错误码取观察到的最特异一个。
 */
export declare function aggregateDynamicFetch(options: AggregateDynamicFetchOptions): Promise<WebFetchResult>;
