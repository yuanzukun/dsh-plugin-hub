import type { EngineFetchOutcome, EngineResult } from '../engines/contract.js';
import type { LaneOutcomeKind } from '../search/aggregate.js';
import type { LaneLogSink } from '../support/lane-runner.js';
import type { FetchPipelineLogger } from './aggregate.js';
/** 单路日志汇：带引擎前缀转发到管线 logger。 */
export declare function laneLogSink(logger: FetchPipelineLogger): LaneLogSink;
/** 引擎结果 → 额度账本口径；其他失败返回 undefined（不入账）。 */
export declare function reportableLaneOutcome(result: EngineResult<EngineFetchOutcome>): LaneOutcomeKind | undefined;
