import type { WebFetchResult } from '@deepseek-ai/dsh-web';
/** 单路提取候选。 */
export interface FetchCandidate {
    readonly engineId: string;
    readonly result: WebFetchResult;
    readonly receivedAt?: string;
}
