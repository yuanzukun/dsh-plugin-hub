import type { WebFetchProvider, WebFetchRequest, WebFetchResult } from '@deepseek-ai/dsh-web';
import type { Engine, EngineContext } from '../engines/contract.js';
import type { AddressLookup } from '../support/address-guard.js';
import type { CircuitBreaker } from '../support/breaker.js';
import { type RuntimeControls } from '../support/budget.js';
import { type LaneOutcomeKind } from '../support/lane-settlement.js';
import { type BuildEngineContext, type FetchPipelineLogger } from './aggregate.js';
import { type FetchRouteOptions } from './route.js';
/** 两个 seam 注册表相互独立；id 与搜索面保持同值，便于宿主与日志辨认。 */
export declare const AGGREGATED_FETCH_PROVIDER_ID = "aggregated";
/** 首路探测的 deadline；默认文档化的 15s。 */
export declare const DEFAULT_PROBE_TIMEOUT_MS = 15000;
/** 静态路 HTTP 提取器的最小结构面；测试注入替身。 */
export interface StaticHttpFetcher {
    available(): boolean;
    fetch(request: WebFetchRequest, signal?: AbortSignal): Promise<WebFetchResult>;
}
/**
 * 专用读取 API（AIHOT 的 /api/v1/*）：结构化报告与同步操作优先于通用提取。
 * 返回 undefined 表示该 URL 不属于此 API 面，继续走通用提取。
 */
export interface DedicatedApiReader {
    readonly engineId: string;
    readApi(url: string, ctx: EngineContext): Promise<WebFetchResult | undefined>;
    /** 结果是否来自读取器缓存；缓存结果不重复计入额度或被熔断观察。 */
    isCached?(result: WebFetchResult): boolean;
}
export interface AggregatedFetchProviderOptions {
    /** 每次操作读取控制快照。 */
    resolveControls(): RuntimeControls;
    /** registry 顺序的引擎表（buildEngines 产物）。 */
    engines: readonly Engine[];
    /** 装配层提供的引擎上下文构造器（凭证、端点覆盖）。 */
    buildContext: BuildEngineContext;
    /** 静态路的 HTTP 提取器；省略时静态 URL 报 WEB_PROVIDER_ERROR。 */
    httpFetcher?: StaticHttpFetcher;
    /** 专用 API 读取器（按 engineId 绑定到 capabilities 含 aihot-api 的引擎）。 */
    apiReaders?: readonly DedicatedApiReader[];
    /** 凭证/可用性探测（可选）。 */
    ready?: (id: string, face: 'search' | 'fetch') => Promise<boolean>;
    /** 额度熔断器；broken 引擎在派发前跳过。 */
    breaker?: CircuitBreaker;
    /** 管线日志汇。 */
    logger?: FetchPipelineLogger;
    /** URL 感知路由参数；默认把静态扩展名交给 HTTP。 */
    route?: FetchRouteOptions;
    /** 动态路单路 deadline；默认 45s。 */
    perEngineTimeoutMs?: number;
    /**
     * 是否在任一引擎或适配器看到 URL 前拒绝已证实的本机/内网目标。默认 true；
     * fetch.staticDomains 主机豁免（内置 HTTP 提取器有自己的策略）。
     */
    blockPrivateAddresses?: boolean;
    /** 地址守卫的 DNS 解析器覆盖；默认系统解析器。 */
    lookup?: AddressLookup;
    /** 首路探测的 deadline；默认 15s。 */
    probeTimeoutMs?: number;
    /**
     * 单路结局回调（装配层注入本地额度账本；只在 success/rate-limited/quota 时调用）。
     * 探测路由 provider 上报，多路整理路由 ExtractionAttempt 上报。
     */
    onLaneOutcome?: (engineId: string, kind: LaneOutcomeKind) => void;
    /** 时钟覆盖（测试）。 */
    now?: () => number;
}
/**
 * 注册在 ctx.web 上的聚合提取 provider（id `aggregated`）。
 * 一次 fetch()：地址守卫 → 专用 API 面 → 静态/动态分流 → 两段式或单通道 → 多路整理。
 */
export declare class AggregatedFetchProvider implements WebFetchProvider {
    readonly id = "aggregated";
    /** 宿主 provider 目录元数据；title 是字符串，description 支持多语言。 */
    readonly title = "Aggregated Web Fetch (5 engines)";
    readonly description: {
        readonly en: "Two-stage fetch: a cheap probe first, escalating to multi-engine content organization that preserves sources and differences. Static files go through the built-in HTTP fetcher.";
        readonly zh: "两段式提取：先探测一路，正文不足再升级多引擎整理并保留来源与差异；静态文件走内置 HTTP 抓取。";
    };
    private readonly options;
    private readonly settlement;
    constructor(options: AggregatedFetchProviderOptions);
    /** 廉价本地可用性检查；没有静态提取器时动态引擎仍可用。 */
    available(): boolean;
    /**
     * 提取一个 URL。静态路直通注入的 HTTP 提取器；动态路扇出到提取引擎。
     * 两条路都把目标站非 2xx 当作结果（seam 契约），不抛错。
     */
    fetch(request: WebFetchRequest, signal?: AbortSignal): Promise<WebFetchResult>;
    private fetchOperation;
    private guardTarget;
    /**
     * AIHOT 专用 API 面：manifest 声明 aihot-api 的引擎优先处理结构化 URL。
     * 读取器由装配层注入；服务总开关、参与范围、熔断与凭证门控与通用提取一致。
     */
    private readDedicatedApi;
    private settleDedicatedApi;
    private fetchStatic;
    /**
     * 动态路：能力适用性路由 → 两段式提取。
     *
     * 能力适用性路由：声明了 fetchApplicable 且对本次 URL 命中的引擎是
     * 专属路（如知乎问题回答 API），优先派发并直接返回其正文；谓词不命中的引擎本轮完全不
     * 派发——不发请求，也不产生 invalid 失败污染聚合错误组。未声明谓词的引擎是通用路，顺序与
     * 选择逻辑不变。专属路全败时才降级通用路。
     */
    private fetchDynamic;
    /**
     * 专属路：按候选顺序尝试声明 fetchApplicable 的引擎，首个可用正文直接返回（不再进入通用路
     * 整理）。全部失败时返回最后一次失败，由调用方决定是否降级。
     */
    private fetchDedicated;
    /**
     * 首路探测：一次请求，不扇出。探测路走 ExtractionAttempt 的 deadline 竞速，这是
     * 忽略 signal 的引擎由调用方 deadline 竞速兜底的修复点。
     * 返回 undefined 表示没有可探测的通道；否则给出可直接提供的原文，
     * 或升级时可复用的种子与不得重复请求的引擎。
     */
    private probeFirst;
    /** 多路整理：探测不足或无可探测通道时的出口。 */
    private escalate;
    /** 首个可派发的通用提取引擎：与升级整理共用启用位、凭证与熔断选择。 */
    private firstEligibleEngine;
    /** 专属路候选：声明 fetchApplicable 且对本次 URL 命中的提取引擎。 */
    private selectDedicated;
    /**
     * 通用路候选（启用位、凭证存在性、熔断）：未声明 fetchApplicable 的提取引擎。
     */
    private selectGeneric;
    /**
     * 按能力适用性分流候选：谓词不命中的引擎本轮不进入任何候选池（不发请求、不产生 invalid
     * 失败）。谓词判定只消费引擎暴露的方法，fetch 层不认识具体引擎（R7 架构红线）。
     */
    private selectByApplicability;
    /** 跑一次提取：共享 deadline、失败投影与额度结算。 */
    private runAttempt;
    private get probeTimeoutMs();
    private serviceEnabled;
    private now;
}
