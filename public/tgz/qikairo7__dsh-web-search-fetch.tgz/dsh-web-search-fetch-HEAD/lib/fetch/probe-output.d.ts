import type { WebFetchRequest, WebFetchResult } from '@deepseek-ai/dsh-web';
/** 首路原文超出单页预算时，按完整内容块省略并标记 truncated。 */
export declare function serveProbeUnderBudget(request: WebFetchRequest, result: WebFetchResult, budget: number, requestCount: number): WebFetchResult;
