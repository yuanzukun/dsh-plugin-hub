import type { QueryAnalysis } from './router.js';
/** 一次搜索的缓存计划：是否可读写、TTL 与缓存键。 */
export interface SearchCachePolicy {
    /** 是否允许写入（也是命中的前提）。 */
    readonly cacheable: boolean;
    /** 本次是否允许读取（用户强制最新时仍写不读）。 */
    readonly readable: boolean;
    readonly ttlSeconds: number;
    readonly key: string;
}
/** 按意图与查询形态给出本次搜索的缓存计划。 */
export declare function searchCachePolicy(input: {
    readonly analysis: QueryAnalysis;
    readonly maxResults: number | undefined;
    /** 影响结果的实时配置指纹；设置变更后不复用旧缓存。 */
    readonly fingerprint?: string;
}): SearchCachePolicy;
