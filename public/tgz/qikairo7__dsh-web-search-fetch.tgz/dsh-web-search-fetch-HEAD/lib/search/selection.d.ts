import type { Engine } from '../engines/contract.js';
import type { OpContext } from '../support/budget.js';
import type { QueryAnalysis, SearchIntent } from './router.js';
/** 装配层注入的意图→引擎 id 映射；缺省 = 空映射，沿用 registry 顺序。 */
export type IntentEngines = (intent: SearchIntent, prefer?: QueryAnalysis['prefer']) => readonly string[];
/** 按意图映射排候选：映射内按给定顺序在前，未映射的按 registry 序排后。priority 为空表示无映射。 */
export declare function orderCandidates(engines: readonly Engine[], priority: readonly string[], registryOrder: readonly Engine[]): Engine[];
/** 把引擎投影成选择服务所需的 manifest 形状，并返回原始引擎。 */
export declare function selectSearchEngines(engines: readonly Engine[], op: OpContext, ready: ((id: string, face: 'search' | 'fetch') => Promise<boolean>) | undefined, capOverride?: number, noteSelection?: boolean, intent?: SearchIntent, intentOrder?: readonly string[]): Promise<readonly Engine[]>;
/** 热点榜：按意图映射序取第一个在选中池内且具备 hotTopics 的引擎（不只认首位）。 */
export declare function hotTopicsEngine(selected: readonly Engine[], route: QueryAnalysis, intentEngines: IntentEngines): Engine | undefined;
