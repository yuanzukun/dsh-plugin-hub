import type { Engine } from '../engines/contract.js';
import type { CircuitBreaker } from '../support/breaker.js';
import type { RuntimeControls } from '../support/budget.js';
import type { QueryAnalysis, SearchIntent } from './router.js';
import type { SearchCandidateSpec, SearchRouteCandidate } from './planner.js';
/** 装配层注入的抽象候选链；缺省 = 空链，由 registry 顺序补足。 */
export type SearchCandidateSource = (intent: SearchIntent, prefer?: QueryAnalysis['prefer']) => readonly SearchCandidateSpec[];
/** 规划输入 + 派发所需的引擎句柄；规划器只消费前面的抽象字段。 */
export interface SearchEngineCandidate extends SearchRouteCandidate {
    /** 该候选来自装配层候选链；末尾补足的 fallback 引擎为 false。 */
    readonly fromSpec: boolean;
    readonly engine: Engine;
}
export interface ResolveSearchCandidatesInput {
    readonly engines: readonly Engine[];
    readonly specs: readonly SearchCandidateSpec[];
    readonly controls: RuntimeControls;
    readonly breaker: CircuitBreaker;
    readonly ready?: (id: string, face: 'search' | 'fetch') => Promise<boolean>;
    /** 已派发候选 id；解析时直接排除，不进入规划器。 */
    readonly exclude?: ReadonlySet<string>;
    /** 已派发引擎 id；候选 id 与引擎 id 分离时也必须排除。 */
    readonly excludeEngines?: ReadonlySet<string>;
}
/** 把引擎表与装配层候选链投影成规划器输入，顺序保持不变。 */
export declare function resolveSearchCandidates(input: ResolveSearchCandidatesInput): Promise<readonly SearchEngineCandidate[]>;
