import type { QueryAnalysis } from './router.js';
import type { SearchInsufficiencyReason } from './sufficiency.js';
/** 规划与质量门规则版本；缓存键携带它，规则变化后旧条目自然失效。 */
export declare const SEARCH_PLANNER_VERSION = "1";
/** 候选在本次查询中的角色；当前只有榜单角色影响动作，其余角色保留来源语义。 */
export type SearchCandidateRole = 'chinese-generic' | 'community' | 'vertical' | 'news' | 'hot-list' | 'english' | 'developer' | 'fallback';
/** 规划器可消费的能力面。搜索能力由候选解析阶段过滤，规划器只额外关心热点。 */
export type SearchCandidateCapability = 'hot-topics';
/** 候选不可参与本轮规划的原因；这些原因进入稳定 reason。 */
export type SearchCandidateSkipCause = 'service-disabled' | 'not-configured' | 'breaker-open' | 'unavailable';
/** 装配层注入的抽象候选：不透明 id、角色与可选引擎绑定。 */
export interface SearchCandidateSpec {
    readonly id: string;
    readonly role: SearchCandidateRole;
    /** 绑定到具体引擎；缺省与 id 相同。规划器不读取此字段。 */
    readonly engineId?: string;
}
/** 规划器输入：候选事实，不含引擎句柄、凭证或端点。 */
export interface SearchRouteCandidate {
    readonly id: string;
    readonly role: SearchCandidateRole;
    readonly capabilities: readonly SearchCandidateCapability[];
    readonly skip?: SearchCandidateSkipCause;
}
/** 稳定 reason id；参数结构进入 provider content 的稳定契约。 */
export type SearchRouteReason = {
    readonly id: 'route-primary';
    readonly params: {
        readonly candidate: string;
        readonly available: number;
    };
} | {
    readonly id: 'route-skip';
    readonly params: {
        readonly candidate: string;
        readonly cause: SearchCandidateSkipCause;
    };
} | {
    readonly id: 'repair-evidence';
    readonly params: {
        readonly candidate: string;
        readonly gap: SearchInsufficiencyReason;
        readonly mode: 'supplement' | 'fallback';
    };
} | {
    readonly id: 'stop-quality';
} | {
    readonly id: 'stop-budget';
} | {
    readonly id: 'stop-deadline';
} | {
    readonly id: 'stop-exhausted';
};
export interface SearchRouteBudget {
    readonly deadlineReached: boolean;
    readonly remainingRequests: number;
}
export interface SearchRouteDecision<T extends SearchRouteCandidate = SearchRouteCandidate> {
    readonly candidate?: T;
    readonly action: 'search' | 'hot-topics';
    readonly reasons: readonly SearchRouteReason[];
}
/** 无状态规划器：有序候选、角色、能力面与可用性就是全部输入。 */
export declare class SearchRoutePlanner {
    /** 首轮只选一路；榜单角色且具备热点能力时才改走榜单。 */
    primary<T extends SearchRouteCandidate>(analysis: QueryAnalysis, candidates: readonly T[]): SearchRouteDecision<T>;
    /** 补派只选一路；已派发候选不再参加，其余跳过原因继续可见。 */
    repair<T extends SearchRouteCandidate>(input: {
        readonly candidates: readonly T[];
        readonly gap: SearchInsufficiencyReason;
        readonly mode: 'supplement' | 'fallback';
    }): SearchRouteDecision<T>;
    /** 停止原因按事实优先级：总限时 > 质量足够 > 请求预算 > 补派耗尽。 */
    stop(sufficient: boolean, budget: SearchRouteBudget): SearchRouteReason;
}
