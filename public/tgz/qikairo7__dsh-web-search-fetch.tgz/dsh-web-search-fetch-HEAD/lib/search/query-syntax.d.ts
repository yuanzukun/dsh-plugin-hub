import type { QueryOperator, QuerySyntax } from '../engines/contract.js';
export type { QueryOperator, QuerySyntax };
/**
 * 解析一条查询的 DeepSeek 风格操作符。
 * operators 按出现顺序保留全部操作符（含重复）与原样 token；
 * 视图字段同名操作符取最后一个值。不含操作符时 operators 为空、bareQuery 为折叠原文。
 */
export declare function parseQuerySyntax(query: string): QuerySyntax;
