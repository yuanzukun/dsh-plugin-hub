import type { QueryAnalysis } from './router.js';
/** 质量规则需要的候选最小形状；fuse.FusedCandidate 结构兼容。 */
export interface CandidateText {
    readonly url: string;
    readonly title?: string;
    readonly snippet?: string;
    readonly summary?: string;
}
/** 显式技术文档意图映射到项目官方文档站；不触发额外搜索的权威域另见 authorityHosts。 */
export declare function officialHosts(analysis: QueryAnalysis): string[];
export declare function authorityHosts(analysis: QueryAnalysis): readonly string[];
export declare function isOfficial(url: string, hosts: readonly string[]): boolean;
export declare function isAuthorityHost(url: string, analysis: QueryAnalysis): boolean;
/** 查询的可用词，按查询顺序（英文词与 CJK 连续段）。 */
export declare function queryTerms(query: string): string[];
/**
 * 一个查询词是否命中候选文本。
 * 英文词按字面出现。中文连续段不是词：「芯片新闻」是「芯片」+「新闻」，页面写成
 * 「芯片…新闻」「AI芯片最新资讯」；要求整段字面曾让这类池全被判不相关（P1-4）。
 * 三字及以上连续段在至少三分之二字符出现时也算命中；两字段保持字面（通常是一个词）。
 */
export declare function termMatches(term: string, text: string): boolean;
/** 承载主题的词：去掉时效与观点形态词。 */
export declare function topicTerms(terms: readonly string[]): string[];
/** 主题匹配防止无关的官方 API 页面仅凭主机名获胜。 */
export declare function topicMatches(analysis: QueryAnalysis, candidate: CandidateText): boolean;
/** 意图权威域优先重排：官方/权威域必须同时命中查询主题。 */
export declare function preferAuthority<T extends CandidateText>(analysis: QueryAnalysis, candidates: readonly T[]): T[];
/**
 * 一条来源的去重键。
 * 同一路径的斜杠变体按**标题**证据合并：页面名说明两条是同一篇文章，各路合法地返回它的
 * 不同摘录——要求摘录一致曾把真重复挡在合并外（P2-4）。不同非根路径保持相异（URL 是键的
 * 一部分）；标题不同的两页即使只差尾斜杠也保持相异。
 */
export declare function contentVariantKey(url: string, title?: string): string;
