import type { Engine, EngineSearchOutcome, VerticalRequest } from '../engines/contract.js';
import type { CircuitBreaker } from '../support/breaker.js';
import type { OpContext } from '../support/budget.js';
import { type LaneOutcome } from '../support/lane-runner.js';
import { type LaneOutcomeKind } from '../support/lane-settlement.js';
import type { SettlementWindow } from '../support/settle.js';
import type { BuildEngineContext, SearchLogSink } from './aggregate.js';
import type { QueryAnalysis } from './router.js';
type Outcome = LaneOutcome<EngineSearchOutcome>;
/** 派发器依赖：引擎表、熔断、上下文构造、日志与时限。 */
export interface LaneDispatcherOptions {
    readonly engines: readonly Engine[];
    readonly breaker: CircuitBreaker;
    readonly buildContext: BuildEngineContext;
    readonly logger: SearchLogSink;
    readonly maxFanoutMs: number;
    readonly rrfK: number;
    readonly now: () => number;
    readonly onLaneOutcome: ((engineId: string, kind: LaneOutcomeKind) => void) | undefined;
}
/** 一轮引擎派发的执行器：启动 lane、喂宽限窗口、提交结局结算。 */
export declare class LaneDispatcher {
    private readonly engines;
    private readonly buildContext;
    private readonly logger;
    private readonly maxFanoutMs;
    private readonly rrfK;
    private readonly now;
    private readonly settlement;
    constructor(options: LaneDispatcherOptions);
    /** 一轮派发：每路 runLane + acceptor 喂宽限窗口；窗口在此关闭。 */
    dispatchRound(lanes: readonly {
        engine: Engine;
        query: string;
        vertical?: VerticalRequest;
        wantAnswer?: boolean;
        freshness?: 'news';
    }[], window: SettlementWindow, analysis: QueryAnalysis, maxResults: number | undefined, op: OpContext, laneDeadlineMs?: number): Promise<Outcome[]>;
    /** 热点榜单路派发：与普通路共用 runLane 的超时/失败投影与熔断喂入。 */
    dispatchHotTopics(engine: Engine, window: SettlementWindow, op: OpContext): Promise<Outcome[]>;
    /**
     * 单路搜索 + 额度耗尽同槽降级（ADR-0001 §12 产品裁决）：keyless-fallback 引擎在带 key 调用
     * 遭遇 quota 失败时，用去掉 apiKey 的同一引擎上下文重试一次——仍在同一 lane、同一 deadline
     * 与请求预算内。auth 失败绝不降级（R6 原义：凭证无效不静默改匿名）。
     */
    private searchWithKeylessFallback;
    /** 逐路记录器：喂 SettlementWindow 的「足够」判定。 */
    private laneAcceptor;
    /** 引擎的上游分组（manifest 单一事实源）；未知引擎返回 undefined。 */
    private upstreamGroup;
}
export {};
