import type { QuerySyntax } from '../engines/contract.js';
import type { FusedCandidate } from './fuse.js';
import type { SearchIntent } from './router.js';
export type SearchInsufficiencyReason = 'empty' | 'official-source' | 'research-coverage' | 'fresh-date';
export interface SearchSufficiencyInput {
    readonly query: string;
    readonly intent: SearchIntent;
    readonly freshnessRequirement: 'normal' | 'high' | 'exact';
    readonly verificationRequirement: 'normal' | 'high';
    readonly syntax: QuerySyntax;
    readonly candidates: readonly FusedCandidate[];
    readonly hasAnswer: boolean;
    readonly maxResults?: number;
    readonly now: number;
}
export interface SearchSufficiencyDecision {
    readonly sufficient: boolean;
    readonly reason?: SearchInsufficiencyReason;
}
export declare function assessSearchSufficiency(input: SearchSufficiencyInput): SearchSufficiencyDecision;
