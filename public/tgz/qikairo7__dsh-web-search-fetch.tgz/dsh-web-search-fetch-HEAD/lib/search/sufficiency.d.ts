import type { SearchEvidence } from './evidence.js';
import type { QueryAnalysis } from './router.js';
export type SearchInsufficiencyReason = 'empty' | 'official-source' | 'research-coverage' | 'fresh-date';
export interface SearchSufficiencyInput {
    readonly analysis: QueryAnalysis;
    readonly evidence: SearchEvidence;
    readonly maxResults?: number;
}
export interface SearchSufficiencyDecision {
    readonly sufficient: boolean;
    readonly reason?: SearchInsufficiencyReason;
}
export declare function assessSearchSufficiency(input: SearchSufficiencyInput): SearchSufficiencyDecision;
