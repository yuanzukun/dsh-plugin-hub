import type { OpContext, RuntimeControls } from '../support/budget.js';
/** 参与服务选择的引擎最小形状（manifest 投影）。 */
export interface SelectableService {
    readonly id: string;
}
/**
 * 选择一次操作派发的服务。
 * @param items - 候选服务，派发顺序。
 * @param op - 操作上下文（控制快照 + 说明收集）。
 * @param face - 能力面。
 * @param ready - 凭证/可用性探测（可选）。
 * @param capOverride - 显式宽度覆盖（单通道结果不足补派等场景自报选择时用）。
 * @param noteSelection - false 时补派方自行记说明，不重复通用选择行。
 * @param intentOrder - 意图映射的引擎 id 顺序；提供时由它决定派发顺序，`searchServices`
 *   退为成员资格过滤；缺省时按用户 `searchServices` 顺序（未配置则保持进入顺序）。
 */
export declare function selectServices<T extends SelectableService>(items: readonly T[], op: OpContext, face: 'search' | 'fetch', ready?: (id: string, face: 'search' | 'fetch') => Promise<boolean>, capOverride?: number, noteSelection?: boolean, intentOrder?: readonly string[]): Promise<T[]>;
/**
 * 一次操作可派发的服务数。搜索首轮恒为一路，补派由质量评估触发（ADR-0002）。
 * 提取保留 URL 形状信号：两段式探测已先花 1 次请求，不足时再按宽度整理。
 */
export declare function resolveServiceCap(controls: RuntimeControls, face: 'search' | 'fetch', op?: OpContext, noteSelection?: boolean): number;
