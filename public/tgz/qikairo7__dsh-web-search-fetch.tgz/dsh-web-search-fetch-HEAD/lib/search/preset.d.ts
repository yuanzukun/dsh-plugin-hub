import type { OpContext, RuntimeControls } from '../support/budget.js';
import type { SearchIntent } from './router.js';
/** 参与服务选择的引擎最小形状（manifest 投影）。 */
export interface SelectableService {
    readonly id: string;
    /** 免费额度型（额度分档与免费名单展示用）；free 预设不使用此位，见 keyless。 */
    readonly free: boolean;
    /** 免密钥型：无需用户凭证即可调用；free 预设按此过滤。 */
    readonly keyless: boolean;
    /**
     * 可免钥调用的能力面；省略表示全部能力。
     * free 预设按当前 face 过滤：Firecrawl 只有 fetch 面免钥，search 不进入 free 预设。
     */
    readonly keylessCapabilities?: readonly string[];
}
/**
 * 选择一次操作派发的服务。
 * @param items - 候选服务（含 free/keyless 标记），派发顺序。
 * @param op - 操作上下文（控制快照 + 说明收集）。
 * @param face - 能力面。
 * @param ready - 凭证/可用性探测（可选）。
 * @param capOverride - 显式宽度覆盖（单通道空结果补派等场景自报选择时用）。
 * @param noteSelection - false 时补派方自行记说明，不重复通用选择行。
 * @param intent - 路由意图（仅搜索面 auto 宽度使用；缺省按单路处理）。
 * @param intentOrder - 意图映射的引擎 id 顺序；提供时由它决定派发顺序，`searchServices`
 *   退为成员资格过滤；缺省时按用户 `searchServices` 顺序（未配置则保持进入顺序）。
 */
export declare function selectServices<T extends SelectableService>(items: readonly T[], op: OpContext, face: 'search' | 'fetch', ready?: (id: string, face: 'search' | 'fetch') => Promise<boolean>, capOverride?: number, noteSelection?: boolean, intent?: SearchIntent, intentOrder?: readonly string[]): Promise<T[]>;
/**
 * 一次操作可派发的服务数。预设直接点名宽度（single=1 路、multi=全量）；
 * auto 消费路由意图：research/ai-news 倾向多路，其余意图单路（ADR-0001 §3）。
 * fetch 面保留 URL 形状信号：自动两段式探测已先花 1 次请求，普通页仍可在探测不足时展开。
 */
export declare function resolveAutoCap(controls: RuntimeControls, face: 'search' | 'fetch', op?: OpContext, intent?: SearchIntent, noteSelection?: boolean): number;
/** 本次操作的搜索宽度是否解析为单通道（自动档补派判定用）。 */
export declare function singleChannelSearch(intent: SearchIntent, controls: RuntimeControls): boolean;
/** 当前预设是否派发多路（宽限窗口是否可能提前收掉慢渠道）。 */
export declare function multiChannelPreset(controls: RuntimeControls): boolean;
