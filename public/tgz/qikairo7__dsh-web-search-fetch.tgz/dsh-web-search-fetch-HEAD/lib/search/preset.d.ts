import type { OpContext, RuntimeControls } from '../support/budget.js';
import type { SearchIntent } from './router.js';
/** 参与服务选择的引擎最小形状（manifest 投影）。 */
export interface SelectableService {
    readonly id: string;
    /** 免费额度型（额度分档与免费名单展示用）；free 预设不使用此位，见 keyless。 */
    readonly free: boolean;
    /** 免密钥型：无需用户凭证即可调用；free 预设按此过滤。 */
    readonly keyless: boolean;
    /**
     * 可免钥调用的能力面；省略表示全部能力。
     * free 预设按当前 face 过滤：Firecrawl 只有 fetch 面免钥，search 不进入 free 预设。
     */
    readonly keylessCapabilities?: readonly string[];
}
/**
 * 选择一次操作派发的服务。
 * @param items - 候选服务（含 free/keyless 标记），派发顺序。
 * @param op - 操作上下文（控制快照 + 说明收集）。
 * @param face - 能力面。
 * @param ready - 凭证/可用性探测（可选）。
 * @param capOverride - 显式宽度覆盖（单通道结果不足补派等场景自报选择时用）。
 * @param noteSelection - false 时补派方自行记说明，不重复通用选择行。
 * @param intent - 路由意图（仅保留给意图排序；auto 搜索宽度恒为单路）。
 * @param intentOrder - 意图映射的引擎 id 顺序；提供时由它决定派发顺序，`searchServices`
 *   退为成员资格过滤；缺省时按用户 `searchServices` 顺序（未配置则保持进入顺序）。
 */
export declare function selectServices<T extends SelectableService>(items: readonly T[], op: OpContext, face: 'search' | 'fetch', ready?: (id: string, face: 'search' | 'fetch') => Promise<boolean>, capOverride?: number, noteSelection?: boolean, intent?: SearchIntent, intentOrder?: readonly string[]): Promise<T[]>;
/** free 预设按能力面过滤；ready 与正式选择必须共用同一判定。 */
export declare function freePresetAllows(item: {
    readonly keyless?: boolean;
    readonly keylessCapabilities?: readonly string[];
}, controls: RuntimeControls, face: 'search' | 'fetch'): boolean;
/**
 * 一次操作可派发的服务数。预设直接点名宽度（single=1 路、multi=全量）；
 * auto 搜索首轮恒为单路，补派由质量评估触发（ADR-0002）。
 * fetch 面保留 URL 形状信号：自动两段式探测已先花 1 次请求，普通页仍可在探测不足时展开。
 */
export declare function resolveAutoCap(controls: RuntimeControls, face: 'search' | 'fetch', op?: OpContext, intent?: SearchIntent, noteSelection?: boolean): number;
/** 本次操作的搜索宽度是否解析为单通道（自动档补派判定用）。 */
export declare function singleChannelSearch(controls: RuntimeControls): boolean;
/** 当前预设是否派发多路（宽限窗口是否可能提前收掉慢渠道）。 */
export declare function multiChannelPreset(controls: RuntimeControls): boolean;
