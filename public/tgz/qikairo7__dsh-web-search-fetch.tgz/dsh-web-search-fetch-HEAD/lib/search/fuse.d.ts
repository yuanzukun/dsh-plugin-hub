import type { EngineSearchSource } from '../engines/contract.js';
/** 一路引擎的排名输出。 */
export interface EngineRanking {
    readonly engineId: string;
    readonly sources: readonly EngineSearchSource[];
    /** 上游分组（manifest.upstreamGroup 透传）：同组只计一路；缺省表示独立来源。 */
    readonly group?: string;
}
/** 融合候选：URL 键、RRF 分、贡献引擎、按字段择优合并的来源字段。 */
export interface FusedCandidate {
    readonly url: string;
    readonly score: number;
    readonly contributors: readonly string[];
    readonly title?: string;
    readonly snippet?: string;
    readonly summary?: string;
    readonly publishedAt?: string;
}
/**
 * 各引擎排名输出的 Reciprocal Rank Fusion。
 * score(d) = Σ_engines 1/(k + rank(d))，rank 在每路内 1 起、每路每键至多计一次
 * （一路内重复键按其最好名次计一次）。平手按首次出现序，输出对给定输入确定。
 * 相同键合并为一个候选：逐字段择优——更长 snippet/summary 胜、已有 title/publishedAt 胜、缺失字段从有它的副本补。
 */
export declare function rrfFuse(rankings: readonly EngineRanking[], k: number): FusedCandidate[];
/**
 * 丢弃与查询毫无关系的融合候选。
 * 两种形态：≥2 个主题词的查询按 topicMatches 判；单词查询一般放过（单词太薄，硬过滤会过度），
 * 但复合词不是单词——它拆成词段，只共享泛词段的候选不是答案，按词段多数判
 * （这就是 `mhovm-1984-…` 类乱码查询不再返回八张无关页、而 `deepseek-harness-guide` 仍匹配自己文档的原因）。
 * 时效限定词（最近/最新）先剔除再计数：以它开头的中文查询按主题判；
 * 剩余单一主题仍须命中——这让「最近的 AI 芯片新闻」保持相关，又不放天气页进来。
 */
export declare function relevantOnly(query: string, candidates: readonly FusedCandidate[]): FusedCandidate[];
