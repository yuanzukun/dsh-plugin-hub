import { WebError, type WebSearchResult, type WebSearchSource } from '@deepseek-ai/dsh-web';
import type { EngineSearchOutcome } from '../engines/contract.js';
import type { LaneOutcome } from '../support/lane-runner.js';
import type { SearchIntent } from './router.js';
import type { FusedCandidate } from './fuse.js';
import type { SearchInsufficiencyReason } from './sufficiency.js';
/** 搜索操作的统一单路结局（与编排层的 Outcome 同形）。 */
export type SearchOutcome = LaneOutcome<EngineSearchOutcome>;
/** 归因条目：引擎、贡献候选数、该路耗时（毫秒，可选）。 */
export interface AttributionEntry {
    readonly engine: string;
    readonly count: number;
    readonly elapsedMs?: number;
}
/** 单路说明状态词表（零结果说明用）。 */
export type LaneState = 'empty' | 'rate-limit' | 'quota-exhausted' | 'insufficient-credits' | 'timeout' | 'cancelled' | 'failed' | 'skipped';
/** 单路说明事实：引擎 + 状态 + 返回条数。 */
export interface LaneReport {
    readonly engineId: string;
    readonly state: LaneState;
    readonly returned: number;
}
/**
 * 结构化操作说明：id 是稳定标识符（测试与日志可依赖），params 是渲染所需的少量事实。
 * 中文句子不进入状态，只在 NOTE_TEXT 里。
 */
export type Note = {
    readonly id: 'hot-list';
} | {
    readonly id: 'ai-news-hot';
} | {
    readonly id: 'ai-news';
} | {
    readonly id: 'community-opinion';
} | {
    readonly id: 'vertical-data';
    readonly params: {
        readonly label: string;
    };
} | {
    readonly id: 'research';
} | {
    readonly id: 'english-web';
} | {
    readonly id: 'english-web-developer';
} | {
    readonly id: 'chinese-web';
} | {
    readonly id: 'cache-hit';
    readonly params: {
        readonly ageSeconds: number;
    };
} | {
    readonly id: 'vertical-unavailable';
} | {
    readonly id: 'vertical-missing-params';
    readonly params: {
        readonly missing: readonly string[];
    };
} | {
    readonly id: 'official-supplement';
    readonly params: {
        readonly count: number;
    };
} | {
    readonly id: 'early-cancel';
} | {
    readonly id: 'rerank-applied';
} | {
    readonly id: 'keyless-fallback';
} | {
    readonly id: 'vertical-degrade';
    readonly params: {
        readonly language: 'chinese' | 'english';
    };
} | {
    readonly id: 'hot-degrade';
    readonly params: {
        readonly language: 'chinese' | 'english';
    };
} | {
    readonly id: 'degrade-no-channel';
} | {
    readonly id: 'degrade-early-cancel';
} | {
    readonly id: 'escalate-no-channel';
} | {
    readonly id: 'escalate-budget-exhausted';
} | {
    readonly id: 'escalate-selected';
    readonly params: {
        readonly engine: string;
        readonly reason: SearchInsufficiencyReason;
        readonly selected: number;
    };
} | {
    readonly id: 'escalate-early-cancel';
} | {
    readonly id: 'quota-estimated';
    readonly params: {
        readonly engines: readonly string[];
    };
} | {
    readonly id: 'date-filtered';
    readonly params: {
        readonly omitted: number;
    };
} | {
    readonly id: 'domain-limit';
    readonly params: {
        readonly omitted: number;
    };
} | {
    readonly id: 'output-budget';
    readonly params: {
        readonly omitted: number;
    };
} | {
    readonly id: 'attribution';
    readonly params: {
        readonly entries: readonly AttributionEntry[];
    };
};
/** 全部用户可见操作说明的唯一文案表：新增 note 只改这里与 Note 联合类型。 */
export declare const NOTE_TEXT: {
    readonly [K in Note['id']]: (note: Extract<Note, {
        id: K;
    }>) => string;
};
/** 把一个结构化说明渲染成用户可见句子（唯一入口）。 */
export declare function renderNote(note: Note): string;
/** 缓存命中的返回形态：age 说明置于原 content 之前（原 content 可能含答案）。 */
export declare function cachedResult(result: WebSearchResult, ageSeconds: number): WebSearchResult;
/** 答案在前、处理说明在后（ADR-0001 §7）。 */
export declare function composeContent(answer: string | undefined, explanation: string): string;
/** 成功轮里的生成式答案（知乎直答等）：按派发序拼接。 */
export declare function successfulAnswers(outcomes: readonly SearchOutcome[]): string | undefined;
/** 任一成功路有非空 content 即视为有产出（垂直结构化数据走 content 通道）。 */
export declare function hasAnswer(outcomes: readonly SearchOutcome[]): boolean;
/** 正常结果的输出阶段输入（一次性，纯数据）。 */
export interface SearchOutputInput {
    readonly query: string;
    readonly intent: SearchIntent;
    readonly candidates: readonly FusedCandidate[];
    readonly maxResults: number | undefined;
    readonly maxOutputChars: number | undefined;
    readonly outcomes: readonly SearchOutcome[];
    readonly endedEarly: boolean;
    readonly deadlineReached: boolean;
    /** 输出阶段之前已收集的事实行（路由/选择/降级等，已渲染）。 */
    readonly notes: readonly string[];
    readonly requestCount: number;
}
/** 正常结果：来源裁剪、归因与说明、答案合并、truncated 汇总一次完成。 */
export interface SearchOutput {
    readonly sources: readonly WebSearchSource[];
    readonly content: string | undefined;
    readonly truncated: boolean;
    readonly notes: readonly string[];
}
/** 正常结果的输出阶段：aggregate 只在返回前调用一次。 */
export declare function buildSearchOutput(input: SearchOutputInput): SearchOutput;
/** 零结果输出阶段输入。 */
export interface EmptyOutputInput {
    readonly outcomes: readonly SearchOutcome[];
    readonly notes: readonly string[];
    readonly requestCount: number;
    readonly endedEarly: boolean;
    readonly deadlineReached: boolean;
}
/** 零结果输出阶段：逐路状态说明 + 答案 + truncated 汇总。 */
export declare function buildEmptyOutput(input: EmptyOutputInput): {
    readonly content: string;
    readonly truncated: boolean;
};
/** 用户可见的处理说明整句（唯一的说明框架）。 */
export declare function renderExplanation(notes: readonly string[], requestCount: number): string;
/** 日志用的事实行汇总（不带到用户 content）。 */
export declare function renderLogSummary(notes: readonly string[], requestCount: number): string;
/** 全部引擎失败时的错误。 */
export declare function allEnginesFailedError(outcomes: ReadonlyArray<SearchOutcome | {
    readonly kind: 'skipped';
    readonly engineId: string;
}>): WebError;
