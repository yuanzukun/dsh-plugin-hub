import type { WebSearchRequest } from '@deepseek-ai/dsh-web';
import type { Engine, EngineSearchOutcome } from '../engines/contract.js';
import type { CircuitBreaker } from '../support/breaker.js';
import type { OpContext } from '../support/budget.js';
import type { LaneOutcome } from '../support/lane-runner.js';
import { LaneDispatcher } from './dispatch.js';
import type { QueryAnalysis } from './router.js';
import { type IntentEngines } from './selection.js';
import type { SearchInsufficiencyReason } from './sufficiency.js';
type Outcome = LaneOutcome<EngineSearchOutcome>;
interface SearchRecoveryOptions {
    readonly engines: readonly Engine[];
    readonly breaker: CircuitBreaker;
    readonly ready: ((id: string, face: 'search' | 'fetch') => Promise<boolean>) | undefined;
    readonly intentEngines: IntentEngines;
    readonly dispatcher: LaneDispatcher;
    readonly logger: {
        info(message: string): void;
        warn(message: string): void;
    };
}
export declare class SearchRecovery {
    private readonly options;
    constructor(options: SearchRecoveryOptions);
    allowed(outcomes: readonly Outcome[], op: OpContext): boolean;
    degrade(request: WebSearchRequest, outcomes: readonly Outcome[], op: OpContext, specialized: 'hot' | 'vertical'): Promise<{
        outcomes: Outcome[];
        endedEarly: boolean;
    } | undefined>;
    escalate(request: WebSearchRequest, outcomes: readonly Outcome[], op: OpContext, route: QueryAnalysis, reason: SearchInsufficiencyReason): Promise<{
        outcomes: Outcome[];
        endedEarly: boolean;
    } | undefined>;
    private availableEngines;
    private noChannel;
    private dispatch;
}
export declare function recoverableFirstLane(outcomes: readonly Outcome[]): boolean;
export {};
