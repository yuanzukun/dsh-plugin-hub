import type { WebSearchResult } from '@deepseek-ai/dsh-web';
import { type SearchEvidence } from './evidence.js';
import type { QueryAnalysis } from './router.js';
type SearchQualityGap = 'relevance' | 'diversity' | 'date' | 'summary' | 'official';
export interface SearchQualityVerdict {
    /** 普通网页质量门是否适用；垂直数据与热榜不适用。 */
    readonly applicable: boolean;
    readonly sufficient: boolean;
    readonly gaps: readonly SearchQualityGap[];
}
/** 普通网页质量门；垂直数据按结构化响应与必填字段校验，不参与普通网页多样性判定。 */
export declare function assessSearchQuality(analysis: QueryAnalysis, evidence: SearchEvidence): SearchQualityVerdict;
/** 以最终结果来源构造同一质量门输入；缓存读写与搜索后评估共用。 */
export declare function assessResultQuality(analysis: QueryAnalysis, result: Pick<WebSearchResult, 'sources' | 'content'>, now: number): SearchQualityVerdict;
export {};
