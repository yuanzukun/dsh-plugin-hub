import type { FusedCandidate } from './fuse.js';
import type { QueryAnalysis } from './router.js';
export interface SearchEvidence {
    readonly candidates: readonly FusedCandidate[];
    readonly hasAnswer: boolean;
    /** 至少返回一条来源的成功路数量。 */
    readonly sourceLanes: number;
    /** 通过主题匹配的候选数；提前停止只认这些候选。 */
    readonly topicMatchedCandidates: number;
    readonly distinctHosts: number;
    readonly officialRequired: boolean;
    readonly officialMatch: boolean;
    readonly freshMatch: boolean;
}
export interface SearchEvidenceInput {
    readonly analysis: QueryAnalysis;
    readonly candidates: readonly FusedCandidate[];
    readonly hasAnswer: boolean;
    readonly sourceLanes: number;
    readonly now: number;
}
/** 从已融合、已治理的候选池生成本轮证据。 */
export declare function buildSearchEvidence(input: SearchEvidenceInput): SearchEvidence;
/**
 * 宽限窗口的提前停止条件：三路有来源，候选达到请求宽度，且显式/项目官方域已命中。
 * 这是延迟策略，不代表查询整体充分；整体补派由 assessSearchSufficiency 判定。
 */
export declare function shouldSettleEarly(evidence: SearchEvidence, maxResults: number | undefined): boolean;
