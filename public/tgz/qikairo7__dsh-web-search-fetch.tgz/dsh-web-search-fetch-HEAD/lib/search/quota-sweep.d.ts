import type { Engine, EngineContext, EngineManifest, QuotaReport } from '../engines/contract.js';
import { type CircuitBreaker } from '../support/breaker.js';
import type { OpContext } from '../support/budget.js';
interface QuotaSweepOptions {
    readonly enabled: boolean;
    readonly breaker: CircuitBreaker;
    readonly buildContext: (manifest: EngineManifest, op: OpContext, lane: {
        signal: AbortSignal;
        deadline: number;
        face: 'search' | 'quota';
    }) => Promise<EngineContext>;
    readonly logger: {
        warn(message: string): void;
    };
    readonly now: () => number;
    readonly onQuotaReport?: (engineId: string, report: QuotaReport) => void;
}
export declare class DailyQuotaSweeper {
    private readonly options;
    private checkedDay;
    constructor(options: QuotaSweepOptions);
    sweep(engines: readonly Engine[], op: OpContext): Promise<void>;
}
export {};
