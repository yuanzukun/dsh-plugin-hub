import type { EngineContext } from '../engines/contract.js';
import { type EngineFailure } from '../engines/failure.js';
import type { FusedCandidate } from './fuse.js';
export interface RerankOutcome {
    /** 重排后的候选（失败时原序返回）。 */
    readonly ordered: readonly FusedCandidate[];
    /** 是否真的经过了重排（false = 未启用或 fail-open）。 */
    readonly reranked: boolean;
    /** 操作说明事实行（呈现层拼中文）。 */
    readonly note?: string;
    /** fail-open 时的失败分类（供日志/熔断外层使用；重排不进引擎熔断）。 */
    readonly failure?: EngineFailure;
}
/**
 * 用 SiliconFlow bge-reranker-v2-m3 重排融合候选。
 * - 未配 key：直接返回原序（reranked:false，无 note——未启用不是事件）。
 * - 成功：按 relevance_score 降序，未被返回的候选按 RRF 序跟在后面（不丢结果，AD8 精神）。
 * - 失败（网络/限流/额度/解析）：fail-open 原序返回 + note，failure 供上层记录。
 */
export declare function rerankCandidates(ctx: EngineContext, query: string, candidates: readonly FusedCandidate[]): Promise<RerankOutcome>;
