import { type WebSearchProvider, type WebSearchRequest, type WebSearchResult } from '@deepseek-ai/dsh-web';
import type { Engine, EngineContext, EngineManifest, QuotaReport } from '../engines/contract.js';
import type { CircuitBreaker } from '../support/breaker.js';
import { type OpContext, type RuntimeControls } from '../support/budget.js';
import type { LaneOutcomeKind } from '../support/lane-settlement.js';
import { QueryCache } from '../support/query-cache.js';
import { type SearchCandidateSource } from './selection.js';
export declare const AGGREGATED_PROVIDER_ID = "aggregated";
/** 单路引擎默认 deadline（10 秒）。 */
export declare const DEFAULT_SEARCH_MAX_FANOUT_MS = 10000;
/** auto 首轮 8 秒，为一次质量不足后的补派预留总限时。 */
export declare const AUTO_FIRST_LANE_MS = 8000;
/** RRF 常数 k（标准 60）。 */
export declare const DEFAULT_RRF_K = 60;
export interface SearchLogSink {
    info(message: string): void;
    warn(message: string): void;
    error(message: string): void;
}
/** 装配层提供的引擎上下文构造器：凭证解析、端点覆盖、keyless 回退都归装配。face 标明用途端点。 */
export type BuildEngineContext = (manifest: EngineManifest, op: OpContext, lane: {
    signal: AbortSignal;
    deadline: number;
    face: 'search' | 'quota';
}) => Promise<EngineContext>;
export interface RerankOptions {
    /** 本次重排的密钥：禁用时返回 undefined；开关与密钥引用读同一次操作快照。 */
    resolve(op: OpContext): Promise<string | undefined>;
    /** fetch 注入（离线测试）。 */
    fetcher?: typeof fetch;
}
/** 垂直频道能力目录（装配层注入 AnysearchDomainCatalog 的薄接口）：校验 tag 是否存在与必填参数。 */
export interface VerticalCatalog {
    validate(tag: string, params?: Readonly<Record<string, string | number | boolean>>, budget?: {
        readonly signal?: AbortSignal;
        readonly countRequest?: () => boolean;
    }): Promise<{
        readonly exists: boolean;
        readonly missingRequired: readonly string[];
    }>;
}
export interface AggregatedSearchOptions {
    resolveControls(): RuntimeControls;
    /** registry 顺序的引擎表（buildEngines 产物）。 */
    engines: readonly Engine[];
    breaker: CircuitBreaker;
    buildContext: BuildEngineContext;
    /** 凭证/可用性探测（装配层注入；key-auth 引擎无有效凭证时不进派发）。 */
    ready?: (id: string, face: 'search' | 'fetch') => Promise<boolean>;
    logger?: SearchLogSink;
    maxFanoutMs?: number;
    rrfK?: number;
    rerank?: RerankOptions;
    /** 意图→抽象候选链（装配层注入；缺省=空链，沿用 registry 或用户搜索顺序）。 */
    routeCandidates?: SearchCandidateSource;
    /** 垂直 tag 目录校验（装配层注入；缺省不校验，按路由器的垂直请求派发）。 */
    verticalCatalog?: VerticalCatalog;
    /** 单路结局回调（装配层注入本地额度账本；只在 success/rate-limited/quota 时调用）。 */
    onLaneOutcome?: (engineId: string, kind: LaneOutcomeKind) => void;
    /**
     * 日检探测正常 resolve 时上报官方快照（含 available:false）。探测抛错不调用。
     * 装配层用它写官方快照仓；编排层不解释额度展示语义。
     */
    onQuotaReport?: (engineId: string, report: QuotaReport) => void;
    /** 额度日检（默认开）。 */
    quotaCheck?: boolean;
    now?: () => number;
    /** 查询缓存（缺省用注入时钟新建；测试可注入独立时钟的实例验证 TTL）。 */
    queryCache?: QueryCache;
    /** 影响搜索结果的实时配置指纹（装配层注入；设置变更后查询缓存键随之变化）。 */
    cacheFingerprint?: () => string;
}
/**
 * 注册在 ctx.web 上的搜索 provider（id `aggregated`）。
 * 一次 search()：额度日检 → 熔断过滤 → 首轮单路 → 相关性与充分性评估
 * → 结果不足时补派一路 → RRF 融合 → 重排 → 输出治理。
 */
export declare class AggregatedSearchProvider implements WebSearchProvider {
    readonly id = "aggregated";
    /** 宿主 provider 目录元数据；title 是字符串，description 支持多语言。 */
    readonly title = "Minimal-Sufficient Web Search";
    readonly description: {
        readonly en: "Analyzes each query locally, starts with the best-fitting engine, and adds one more source only when relevance, authority, coverage, or freshness is insufficient. Free tiers first; may use anonymous quotas.";
        readonly zh: "本地分析查询后先调用最合适的一路；仅在相关性、权威性、覆盖或时效不足时补派一路。免费额度优先，未配密钥时使用匿名额度。";
    };
    private readonly resolveControls;
    private readonly engines;
    private readonly breaker;
    private readonly buildContext;
    private readonly engineReady;
    private readonly logger;
    private readonly maxFanoutMs;
    private readonly rrfK;
    private readonly rerank;
    private readonly routeCandidates;
    private readonly planner;
    private readonly verticalCatalog;
    private readonly now;
    private readonly queryCache;
    private readonly cacheFingerprint;
    private readonly dispatcher;
    private readonly recovery;
    private readonly quotaSweeper;
    private readonly batchBudgets;
    constructor(options: AggregatedSearchOptions);
    /** 廉价本地可用性检查；凭证按调用解析，这里不答。 */
    available(): boolean;
    /** DSH 0.2.2 工具准入：至少一个已启用、未熔断且可用的搜索服务存在。 */
    ready(): Promise<boolean>;
    search(request: WebSearchRequest, signal?: AbortSignal): Promise<WebSearchResult>;
    private sharedBudget;
    private searchOperation;
    private noteStop;
    private deadlineError;
    private assessSufficiency;
    /** 垂直 tag 校验：目录拒绝或抛错都按不可用处理（fail-open 回通用路由）；请求预算由目录在发网络请求前消费。 */
    private verticalVerdict;
}
