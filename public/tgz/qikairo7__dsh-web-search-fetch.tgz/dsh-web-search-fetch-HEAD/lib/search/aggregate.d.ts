import { type WebSearchProvider, type WebSearchRequest, type WebSearchResult } from '@deepseek-ai/dsh-web';
import type { Engine, EngineContext, EngineManifest, QuotaReport } from '../engines/contract.js';
import { type CircuitBreaker } from '../support/breaker.js';
import { type OpContext, type RuntimeControls } from '../support/budget.js';
import { QueryCache } from '../support/query-cache.js';
import { type IntentEngines } from './selection.js';
export type { IntentEngines } from './selection.js';
export declare const AGGREGATED_PROVIDER_ID = "aggregated";
/** 单路引擎默认 deadline（v0.2 DEFAULT_SEARCH_MAX_FANOUT_MS = 10s）。 */
export declare const DEFAULT_SEARCH_MAX_FANOUT_MS = 10000;
/** RRF 常数 k（标准 60）。 */
export declare const DEFAULT_RRF_K = 60;
export interface SearchLogSink {
    info(message: string): void;
    warn(message: string): void;
    error(message: string): void;
}
/** 装配层提供的引擎上下文构造器：凭证解析（异步、每操作）、端点覆盖、keyless 回退都归装配（AD2）。face 标明用途端点。 */
export type BuildEngineContext = (manifest: EngineManifest, op: OpContext, lane: {
    signal: AbortSignal;
    deadline: number;
    face: 'search' | 'quota';
}) => Promise<EngineContext>;
export interface RerankOptions {
    /** 本次重排的密钥：禁用时返回 undefined；开关与密钥引用读同一次操作快照。 */
    resolve(op: OpContext): Promise<string | undefined>;
    /** fetch 注入（离线测试）。 */
    fetcher?: typeof fetch;
}
/** 单路结局的额度账本口径（v0.4）：只上报影响额度判断的三类，其余结局不入账。 */
export type LaneOutcomeKind = 'success' | 'rate-limited' | 'quota';
/** 垂直频道能力目录（装配层注入 AnysearchDomainCatalog 的薄接口）：校验 tag 是否存在与必填参数。 */
export interface VerticalCatalog {
    validate(tag: string, params?: Readonly<Record<string, string | number | boolean>>, budget?: {
        readonly signal?: AbortSignal;
        readonly countRequest?: () => boolean;
    }): Promise<{
        readonly exists: boolean;
        readonly missingRequired: readonly string[];
    }>;
}
export interface AggregatedSearchOptions {
    resolveControls(): RuntimeControls;
    /** registry 顺序的引擎表（buildEngines 产物）。 */
    engines: readonly Engine[];
    breaker: CircuitBreaker;
    buildContext: BuildEngineContext;
    /** 凭证/可用性探测（装配层注入；key-auth 引擎无有效凭证时不进派发）。 */
    ready?: (id: string, face: 'search' | 'fetch') => Promise<boolean>;
    logger?: SearchLogSink;
    maxFanoutMs?: number;
    rrfK?: number;
    rerank?: RerankOptions;
    /** 意图→有序引擎 id 列表（装配层注入；缺省=空映射，沿用 registry 顺序）。 */
    intentEngines?: IntentEngines;
    /** 垂直 tag 目录校验（装配层注入；缺省不校验，按路由器的垂直请求派发）。 */
    verticalCatalog?: VerticalCatalog;
    /** 单路结局回调（装配层注入本地额度账本；只在 success/rate-limited/quota 时调用）。 */
    onLaneOutcome?: (engineId: string, kind: LaneOutcomeKind) => void;
    /**
     * 日检探测正常 resolve 时上报官方快照（含 available:false）。探测抛错不调用。
     * 装配层用它写官方快照仓；编排层不解释额度展示语义。
     */
    onQuotaReport?: (engineId: string, report: QuotaReport) => void;
    /** 额度日检（默认开）。 */
    quotaCheck?: boolean;
    now?: () => number;
    /** 查询缓存（缺省用注入时钟新建；测试可注入独立时钟的实例验证 TTL）。 */
    queryCache?: QueryCache;
    /** 影响搜索结果的实时配置指纹（装配层注入；设置变更后查询缓存键随之变化）。 */
    cacheFingerprint?: () => string;
}
/**
 * 注册在 ctx.web 上的聚合搜索 provider（id `aggregated`）。
 * 一次 search()：额度日检 → 熔断过滤 → 服务选择 → 官方域补充 → 并发派发（宽限窗口）
 * → 去重 RRF 融合 → 相关性过滤 →（空结果且单通道 → 补派一次）→ 重排 → 官方优先 → 截断与说明。
 */
export declare class AggregatedSearchProvider implements WebSearchProvider {
    readonly id = "aggregated";
    /** 宿主 provider 目录元数据（master HEAD 的 WebProviderInfo 消费；0.2.1-rc.2 类型面无此字段，多余成员结构兼容）。 */
    readonly title: {
        readonly en: "Aggregated Web Search (5 engines)";
        readonly zh: "聚合网络搜索（五引擎）";
    };
    readonly description: {
        readonly en: "Routes each query to the engine that fits it best (Zhihu for Chinese, AnySearch verticals, Tavily/Firecrawl for English, AIHOT for AI news), then fuses results with RRF and optional SiliconFlow rerank. Free tiers first; may use anonymous quotas.";
        readonly zh: "按问题类型路由到最擅长的引擎（知乎中文、AnySearch 专业频道、Tavily/Firecrawl 英文、AIHOT 资讯），RRF 融合与可选 SiliconFlow 重排。免费额度优先，未配密钥时使用匿名额度。";
    };
    private readonly resolveControls;
    private readonly engines;
    private readonly breaker;
    private readonly buildContext;
    private readonly ready;
    private readonly logger;
    private readonly rrfK;
    private readonly rerank;
    private readonly intentEngines;
    private readonly verticalCatalog;
    private readonly quotaCheckEnabled;
    private readonly now;
    private readonly queryCache;
    private readonly cacheFingerprint;
    private readonly dispatcher;
    private readonly onQuotaReport;
    private quotaCheckedDay;
    constructor(options: AggregatedSearchOptions);
    /** 廉价本地可用性检查；凭证按调用解析，这里不答。 */
    available(): boolean;
    search(request: WebSearchRequest, signal?: AbortSignal): Promise<WebSearchResult>;
    private searchOperation;
    /** 垂直 tag 校验：目录拒绝或抛错都按不可用处理（fail-open 回通用路由）；请求预算由目录在发网络请求前消费。 */
    private verticalVerdict;
    /** 有界降级的前置条件：预算内、未取消、且失败不属于「不重试」类型。 */
    private degradationAllowed;
    /**
     * 有界降级（ADR-0001 §4）：垂直/热榜路由无可用结果时，按查询语言走通用路由重试一次。
     * 已派发过的引擎不重复（重试意义在换通道）；没有可用通道时只记说明。
     */
    private degradeRoute;
    /**
     * 单通道空结果补派（恰一次）。补派尊重预设服务表、启用位、凭证、服务上限与剩余请求预算，
     * 并自报选择说明（不重复首轮通用选择行）。
     */
    private escalateEmptySearch;
    /**
     * 额度日检：每个带 quota() 的引擎每本地日至多探测一次；先标记后探测，
     * 单个探测失败不会让管道整天重试；探测失败只记日志，不阻塞搜索（v0.2 语义原样，AD9 成真）。
     */
    private sweepDailyQuota;
}
