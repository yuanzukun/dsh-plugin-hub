import type { SearchIntent } from './router.js';
export interface DateGovernanceResult<T> {
    readonly candidates: readonly T[];
    readonly omitted: number;
}
export declare function governDates<T extends {
    readonly publishedAt?: string;
}>(query: string, intent: SearchIntent, candidates: readonly T[], now: number): DateGovernanceResult<T>;
