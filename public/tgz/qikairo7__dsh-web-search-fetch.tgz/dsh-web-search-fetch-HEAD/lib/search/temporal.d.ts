import type { QueryAnalysis } from './router.js';
export interface DateGovernanceResult<T> {
    readonly candidates: readonly T[];
    readonly omitted: number;
}
export declare function governDates<T extends {
    readonly publishedAt?: string;
}>(analysis: QueryAnalysis, candidates: readonly T[], now: number): DateGovernanceResult<T>;
