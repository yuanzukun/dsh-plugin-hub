import type { VerticalRequest } from '../engines/contract.js';
import { parseQuerySyntax } from './query-syntax.js';
import type { Note } from './output.js';
/** 检索意图（与方案表一一对应）。 */
export type SearchIntent = 'ai-news' | 'community-opinion' | 'hot-list' | 'vertical-data' | 'english-web' | 'research' | 'chinese-web';
/** 查询分析：意图、本地结构化信号与检索倾向；不点名任何引擎。 */
export interface QueryAnalysis {
    /** 原始查询；缓存与用户可见规则需要原文。 */
    readonly query: string;
    readonly intent: SearchIntent;
    /** 显式搜索语法与剥离后的查询主体。 */
    readonly syntax: ReturnType<typeof parseQuerySyntax>;
    /** 查询语言；无 CJK 且有拉丁字母时为英文，否则沿用中文默认路径。 */
    readonly language: 'chinese' | 'english';
    /** 本地规则提取的主题词；不是 NLP 实体识别。 */
    readonly topics: readonly string[];
    /** 本地规则提取的可用词（含时效/观点形态词），供相关性门槛使用。 */
    readonly terms: readonly string[];
    /** explicit 表示带 after:/before:；high 表示热点或 AI 资讯。 */
    readonly freshnessRequirement: 'normal' | 'high' | 'exact';
    /** 调研对比需要交叉验证，其余查询为普通验证。 */
    readonly verificationRequirement: 'normal' | 'high';
    /** 结构化取数请求（仅 vertical-data 意图携带）。 */
    readonly vertical?: VerticalRequest;
    /** 是否希望引擎附带生成式答案（社区观点意图置真）。 */
    readonly wantAnswer?: boolean;
    /** 是否直接取当下热点榜单而非普通搜索。 */
    readonly useHotTopics?: boolean;
    /** 网页检索的细分偏好：通用网页 / 开发者资料（装配层翻译成具体来源）。 */
    readonly prefer?: 'general-web' | 'developer';
    /** 用户可见说明素材：稳定 noteId + 可选 params（中文文案在 output.ts 的 NOTE_TEXT）。 */
    readonly note: Note;
}
/** 查询是否含 CJK 字符（编排层的通用路由语言判据复用此入口，避免第二份正则）。 */
export declare function hasCjk(text: string): boolean;
/**
 * 判定查询意图。规则全部本地确定性：同一查询永远得到同一决策。
 * 每个分支都产出一句用户语言的 note，供上层拼用户可见说明。
 */
export declare function routeSearchQuery(query: string): QueryAnalysis;
