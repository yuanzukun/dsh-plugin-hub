import type { WebSearchSource } from '@deepseek-ai/dsh-web';
import type { Engine } from '../engines/contract.js';
import { type FusedCandidate } from './fuse.js';
import type { SearchOutcome } from './output.js';
import type { QueryAnalysis } from './router.js';
/** 一路成功通道的排名输出。 */
export interface EngineRankingInput {
    readonly engineId: string;
    readonly sources: readonly WebSearchSource[];
    readonly group?: string;
}
/** 成功通道的排名输出（派发序），带上 manifest 的上游分组供融合前同组去重。 */
export declare function successfulRankings(outcomes: readonly SearchOutcome[], engines: readonly Engine[]): EngineRankingInput[];
/** 融合 + 相关性过滤成功的通道。 */
export declare function relevantCandidates(analysis: QueryAnalysis, rankings: readonly EngineRankingInput[], rrfK: number): FusedCandidate[];
