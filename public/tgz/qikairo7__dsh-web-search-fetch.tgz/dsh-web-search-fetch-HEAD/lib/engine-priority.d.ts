import type { QueryAnalysis, SearchIntent } from './search/router.js';
import type { SearchCandidateSpec } from './search/planner.js';
/** 意图与偏好 → 抽象候选链；引擎 id 只允许留在装配层。 */
export declare function intentSearchCandidates(intent: SearchIntent, prefer?: QueryAnalysis['prefer']): readonly SearchCandidateSpec[];
/**
 * 兼容导出：旧调用方按引擎 id 读取候选顺序。
 * 新装配路径使用 intentSearchCandidates；引擎知识仍只留在装配层。
 */
export declare function intentEnginePriority(intent: SearchIntent, prefer?: QueryAnalysis['prefer']): readonly string[];
