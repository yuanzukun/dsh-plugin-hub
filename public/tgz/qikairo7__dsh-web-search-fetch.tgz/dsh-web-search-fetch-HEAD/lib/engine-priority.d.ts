import type { QueryAnalysis, SearchIntent } from './search/router.js';
/** 意图 → 候选引擎 id 顺序；引擎知识只允许留在装配层。 */
export declare function intentEnginePriority(intent: SearchIntent, prefer?: QueryAnalysis['prefer']): readonly string[];
