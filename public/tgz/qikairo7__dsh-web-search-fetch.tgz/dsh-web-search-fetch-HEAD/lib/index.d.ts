import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { Dict, Volatile } from '@deepseek-ai/cosmokit';
import z from '@deepseek-ai/schemastery';
import type { Engine, EngineContext, EngineManifest } from './engines/contract.js';
import { type BuildEngineContext } from './search/aggregate.js';
import { intentEnginePriority } from './engine-priority.js';
import { OpContext, type RuntimeControls } from './support/budget.js';
import { CircuitBreaker } from './support/breaker.js';
import { QuotaLedger } from './support/quota-ledger.js';
import { QuotaPanelService, type PanelEngineManifest, type PanelPayload } from './support/quota-panel.js';
import { QuotaSnapshotStore } from './support/quota-snapshots.js';
/** 服务开关表（与 schemastery z.dict 同源的 Dict 形状；导出以使命令发射可命名该类型）。 */
export type ServiceSwitches = Dict<boolean>;
/** Cordis 插件名；保持稳定以避免已保存的宿主配置失效。 */
export declare const name = "web-search-fetch";
/** 能力接缝与凭证服务（凭证每操作解析，轮换即生效）。 */
export declare const inject: string[];
/** 参与搜索的默认服务 = registry 顺序里的 search 能力引擎。 */
export declare const DEFAULT_SEARCH_SERVICES: readonly string[];
/** 参与提取的默认服务 = registry 顺序里的 fetch 能力引擎。 */
export declare const DEFAULT_FETCH_SERVICES: readonly string[];
export interface Config {
    /** 运行时控制（设置页 volatile 快照）。 */
    controls?: Partial<RuntimeControls>;
    /** SiliconFlow 重排配置。 */
    rerank?: {
        enabled?: boolean;
        apiKeyEnv?: string;
    };
    /** 各引擎凭证引用（credential-ref）；未配置的 keyless-fallback 引擎走匿名额度。 */
    anysearchApiKeyEnv?: string;
    anysearchBaseURL?: string;
    /** AnySearch 搜索区域：'cn' 国内 / 'intl' 国际；空串与未设置等价，均不发送 zone 字段。 */
    anysearchZone?: 'cn' | 'intl' | '';
    tavilyApiKeyEnv?: string;
    firecrawlApiKeyEnv?: string;
    firecrawlBaseURL?: string;
    zhihuApiKeyEnv?: string;
}
/** 解析后的实时配置引用；每次操作读取一次 `config.get()` 快照。 */
export type ConfigRef = Volatile<Config>;
export declare const Config: z<NoInfer<Schemastery.ObjectS<NoInfer<{
    controls: z<Schemastery.ObjectS<NoInfer<{
        serviceEnabled: z<Dict<boolean, string>, Dict<boolean, string>, "defined">;
        searchServices: z<string[], string[], "defined">;
        fetchServices: z<string[], string[], "defined">;
        maxFetchServices: z<number, number, "defined">;
        maxRequests: z<number, number, "defined">;
        searchDeadlineMs: z<number, number, "defined">;
        fetchDeadlineMs: z<number, number, "defined">;
        maxOutputChars: z<number, number, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        serviceEnabled: z<Dict<boolean, string>, Dict<boolean, string>, "defined">;
        searchServices: z<string[], string[], "defined">;
        fetchServices: z<string[], string[], "defined">;
        maxFetchServices: z<number, number, "defined">;
        maxRequests: z<number, number, "defined">;
        searchDeadlineMs: z<number, number, "defined">;
        fetchDeadlineMs: z<number, number, "defined">;
        maxOutputChars: z<number, number, "defined">;
    }>>, "plain">;
    rerank: z<Schemastery.ObjectS<NoInfer<{
        enabled: z<boolean, boolean, "defined">;
        apiKeyEnv: z<string, string, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        enabled: z<boolean, boolean, "defined">;
        apiKeyEnv: z<string, string, "defined">;
    }>>, "plain">;
    anysearchApiKeyEnv: z<string, string, "defined">;
    anysearchBaseURL: z<string, string, "plain">;
    anysearchZone: z<"" | "cn" | "intl", "" | "cn" | "intl", "plain">;
    tavilyApiKeyEnv: z<string, string, "defined">;
    firecrawlApiKeyEnv: z<string, string, "defined">;
    firecrawlBaseURL: z<string, string, "plain">;
    zhihuApiKeyEnv: z<string, string, "defined">;
}>>>, NoInfer<Schemastery.ObjectT<NoInfer<{
    controls: z<Schemastery.ObjectS<NoInfer<{
        serviceEnabled: z<Dict<boolean, string>, Dict<boolean, string>, "defined">;
        searchServices: z<string[], string[], "defined">;
        fetchServices: z<string[], string[], "defined">;
        maxFetchServices: z<number, number, "defined">;
        maxRequests: z<number, number, "defined">;
        searchDeadlineMs: z<number, number, "defined">;
        fetchDeadlineMs: z<number, number, "defined">;
        maxOutputChars: z<number, number, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        serviceEnabled: z<Dict<boolean, string>, Dict<boolean, string>, "defined">;
        searchServices: z<string[], string[], "defined">;
        fetchServices: z<string[], string[], "defined">;
        maxFetchServices: z<number, number, "defined">;
        maxRequests: z<number, number, "defined">;
        searchDeadlineMs: z<number, number, "defined">;
        fetchDeadlineMs: z<number, number, "defined">;
        maxOutputChars: z<number, number, "defined">;
    }>>, "plain">;
    rerank: z<Schemastery.ObjectS<NoInfer<{
        enabled: z<boolean, boolean, "defined">;
        apiKeyEnv: z<string, string, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        enabled: z<boolean, boolean, "defined">;
        apiKeyEnv: z<string, string, "defined">;
    }>>, "plain">;
    anysearchApiKeyEnv: z<string, string, "defined">;
    anysearchBaseURL: z<string, string, "plain">;
    anysearchZone: z<"" | "cn" | "intl", "" | "cn" | "intl", "plain">;
    tavilyApiKeyEnv: z<string, string, "defined">;
    firecrawlApiKeyEnv: z<string, string, "defined">;
    firecrawlBaseURL: z<string, string, "plain">;
    zhihuApiKeyEnv: z<string, string, "defined">;
}>>>, "volatile">;
/** 构造引擎执行上下文：凭证每操作解析，端点按 lane.face 从 manifest 选择。 */
export declare function makeBuildContext(ctx: Context, config: ConfigRef): (manifest: EngineManifest, op: OpContext, lane: {
    signal: AbortSignal;
    deadline: number;
    face: "search" | "fetch" | "quota";
}) => Promise<EngineContext>;
export interface QuotaPanelRuntimeOptions {
    readonly engines: readonly Engine[];
    readonly ledger: QuotaLedger;
    readonly breaker: CircuitBreaker;
    readonly buildContext: BuildEngineContext;
    readonly resolveControls: () => RuntimeControls;
    readonly now?: () => number;
}
export interface QuotaPanelRuntime {
    readonly service: QuotaPanelService;
    readonly store: QuotaSnapshotStore;
    readonly manifests: readonly PanelEngineManifest[];
}
/**
 * 组装面板核心：探测闭包 = buildContext（凭证/端点/预算）+ engine.quota。
 * 凭证解析异常改抛 QuotaCredentialError（面板给固定原因、零请求、不连坐）；
 * 其余探测异常由面板归一为 unavailable 原因。
 */
export declare function createQuotaPanelRuntime(options: QuotaPanelRuntimeOptions): QuotaPanelRuntime;
export declare class QuotaPanelRemote extends TypertRemoteService {
    private readonly panel;
    constructor(ctx: Context, panel: QuotaPanelService);
    get(): PanelPayload;
    refresh(): Promise<PanelPayload>;
}
export { intentEnginePriority };
/** 影响搜索结果的配置指纹（不含凭证值）；设置变更后查询缓存键随之变化。 */
export declare function searchCacheFingerprint(value: Config): string;
/** 运行时控制快照：用户配置与 registry 默认开关合并（纯函数，供装配与离线测试）。 */
export declare function resolveControlsFrom(value: Config, defaultEnabled: Readonly<Record<string, boolean>>): RuntimeControls;
/** 本次搜索的重排密钥：开关与密钥引用来自同一次配置快照。 */
export declare function resolveRerankKey(ctx: Context, config: ConfigRef, op?: OpContext): Promise<string | undefined>;
export declare function apply(ctx: Context, config: ConfigRef): void;
