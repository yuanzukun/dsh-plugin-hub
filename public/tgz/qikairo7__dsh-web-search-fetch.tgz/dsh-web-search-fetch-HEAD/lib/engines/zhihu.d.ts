import type { Engine } from './contract.js';
import { type ZhihuEngineOptions } from './zhihu-shared.js';
export type { ZhihuEngineOptions } from './zhihu-shared.js';
/** 两个搜索面：global=全网，zhihu=知乎站内。 */
export type ZhihuSearchFace = 'global' | 'zhihu';
/**
 * 按查询意图选择搜索面：含「知乎」或 zhihu.com（含 site:zhihu.com，大小写不敏感）→ 站内，
 * 否则全网。纯函数，便于单测（验收 R4）。
 */
export declare function zhihuSearchFace(query: string): ZhihuSearchFace;
/**
 * 创建知乎引擎适配。manifest 直接引用 registry（AD1 单一事实源）；
 * 本适配有 search、fetch（问题回答读取）、hotTopics 与 quota。
 */
export declare function createZhihuEngine(options?: ZhihuEngineOptions): Engine;
