import type { EngineContext, EngineSearchRequest } from './contract.js';
import { type ZhihuEngineOptions } from './zhihu-shared.js';
/**
 * 调直答并返回文本。fail-open：网络错、HTTP 4xx/5xx、超时、预算耗尽、OpenAI 风格 error、
 * 空 choices/空 content 一律返回 undefined，不向调用方抛错，也不产生额外 note。
 * 预算由 engineJson → engineFetch 统一记账（每个 HTTP 请求一次 countRequest）。
 */
export declare function requestAnswer(apiKey: string, request: EngineSearchRequest, ctx: EngineContext, options: ZhihuEngineOptions): Promise<string | undefined>;
