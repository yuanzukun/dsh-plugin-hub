import type { Engine, EngineManifest } from './contract.js';
export declare const ANYSEARCH_MANIFEST: EngineManifest;
export declare const TAVILY_MANIFEST: EngineManifest;
export declare const FIRECRAWL_MANIFEST: EngineManifest;
export declare const ZHIHU_MANIFEST: EngineManifest;
export declare const AIHOT_MANIFEST: EngineManifest;
/** 全部引擎清单，注册顺序即默认派发顺序。 */
export declare const ENGINE_MANIFESTS: readonly EngineManifest[];
/**
 * SiliconFlow 重排服务（不是搜索引擎，不进 ENGINE_MANIFESTS）：
 * 契约依据 api-contracts/siliconflow.json——POST /v1/rerank（BAAI/bge-reranker-v2-m3，
 * RPM 2000 / TPM 500k）；余额端点 /v1/user/info 已停用且无替代，
 * 额度呈现用 GET /v1/models 做密钥有效性校验（不伪造余额数字）。
 */
export declare const RERANK_SERVICE: {
    readonly endpoint: "https://api.siliconflow.cn/v1/rerank";
    readonly modelsEndpoint: "https://api.siliconflow.cn/v1/models";
    readonly model: "BAAI/bge-reranker-v2-m3";
    /** 融合后送重排的候选上限（TPM 安全预算：30 × ~500 token ≈ 15k « 500k）。 */
    readonly topN: 30;
};
/** 注册表完整性（M0 测试将钉死）：manifest 声明的能力必须有对应适配函数。 */
export interface EngineRegistryDeps {
    readonly anysearch: Engine;
    readonly tavily: Engine;
    readonly firecrawl: Engine;
    readonly zhihu: Engine;
    readonly aihot: Engine;
}
/** 组装完整引擎表；装配层（index）调用，适配函数在各自模块实现。 */
export declare function buildEngines(deps: EngineRegistryDeps): readonly Engine[];
