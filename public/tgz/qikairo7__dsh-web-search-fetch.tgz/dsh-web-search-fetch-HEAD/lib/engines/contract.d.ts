import type { EngineFailure } from './failure.js';
/** DSH 0.2.2 每条来源的模型阅读摘要上限。 */
export declare const MAX_MODEL_SUMMARY_CHARS = 800;
/** 引擎能力位。aihot-api：AIHOT 专用读取 API（热点/事件/日报/周报/月报/精选），不参与通用网页提取。 */
export type EngineCapability = 'search' | 'fetch' | 'aihot-api';
/**
 * 鉴权模式：
 * - anonymous：无需凭证（AIHOT、直接 HTTP 抓取）。
 * - key：必须配置凭证。
 * - keyless-fallback：未配凭证时走官方匿名/公共额度（AnySearch、Tavily）；已配凭证则用账号模式，
 *   凭证失效不静默降级匿名。
 */
export type EngineAuthMode = 'anonymous' | 'key' | 'keyless-fallback';
/** 官方额度周期标记；none 表示没有官方额度端点。 */
export type EngineQuotaPeriod = 'daily-bj' | 'daily-utc' | 'monthly' | 'none';
/**
 * 引擎清单——全仓唯一服务事实源。
 * 设置面、客户端表、配置默认值、free 名单、凭证位全部从 registry 派生，禁止出现第二份清单。
 */
export interface EngineManifest {
    /** 稳定 id：熔断键、配置键、日志标签共用，不随版本重命名。 */
    readonly id: string;
    /** 设置页显示名。 */
    readonly label: string;
    readonly capabilities: readonly EngineCapability[];
    readonly auth: EngineAuthMode;
    /** DSH 凭证路径（auth !== 'anonymous' 时必填）。 */
    readonly credentialPath?: string;
    /** 免费额度型服务（额度分档展示用）；是否免钥见 keyless。 */
    readonly free?: boolean;
    /**
     * 免密钥型服务：无需用户凭证即可调用（AnySearch/Tavily 匿名额度、AIHOT 公共接口、
     * Firecrawl 的 keyless free tier）。与免费额度型是两个概念：免费额度型不等于免密钥。
     * 服务选择按此位判断能否在无用户密钥时参与。
     */
    readonly keyless?: boolean;
    /**
     * 可免钥调用的能力面（auth 为 keyless-fallback/anonymous 时生效）。
     * 省略表示该引擎全部能力都支持免钥；Firecrawl 只有 fetch 面存在 keyless free tier，
     * search 仍需 key，因此显式写 ['fetch']，按能力面过滤。
     */
    readonly keylessCapabilities?: readonly EngineCapability[];
    /**
     * 上游分组（同源去重）：共享同一上游索引/搜索后端的引擎填同一值。
     * 上游重叠度未实测前留空；rrfFuse 对同组只保留排名最好的一路，防「多源命中」假共识。
     */
    readonly upstreamGroup?: string;
    /** 新安装默认启用。 */
    readonly enabledByDefault?: boolean;
    /** 官方额度周期；有 quota 端点的引擎必须声明。 */
    readonly quotaPeriod?: EngineQuotaPeriod;
    /**
     * 引擎端点，可被用户配置覆盖。
     * 至少一个端点必须存在：装配层用它构造 EngineContext.endpoint。
     */
    readonly endpoints: {
        readonly search?: string;
        readonly fetch?: string;
        readonly quota?: string;
    };
}
/** 一个被解析出的查询操作符：解析值 + 原 token 逐字保留。 */
export interface QueryOperator {
    readonly kind: 'site' | '-site' | 'lang' | 'after' | 'before';
    /** 原 token 逐字保留：大小写、路径后缀、出现顺序都在，unsupported 回拼用。 */
    readonly raw: string;
    /** 解析值：域名（小写、剥路径后缀）或语言/日期原文。 */
    readonly value: string;
}
/**
 * 查询语法解析结果：DeepSeek 风格操作符的结构化形状。
 * operators 是全量事实（含原样 token）；domains/excludeDomains/language/after/before
 * 是便捷视图（同名操作符取最后一个值）。引擎映射用视图字段，回拼用 operators 里
 * unsupported 项的 raw（逐字、按原顺序），绝不静默丢弃或改写。
 */
export interface QuerySyntax {
    /** 全部操作符，按出现顺序，原样 token 随行。 */
    readonly operators: readonly QueryOperator[];
    /** site: 限定的域名（视图：全部 site 操作符的解析值）。 */
    readonly domains: readonly string[];
    /** -site: 排除的域名（视图）。 */
    readonly excludeDomains: readonly string[];
    /** lang: 语言（视图：最后一个 lang 操作符的值，含逗号分隔多值）。 */
    readonly language?: string;
    /** after: 起始日期（YYYY / YYYY-MM / YYYY-MM-DD）。 */
    readonly after?: string;
    /** before: 结束日期。 */
    readonly before?: string;
    /** 操作符移除后的查询文本（引号短语与 -词保留，空白折叠为单空格）。 */
    readonly bareQuery: string;
}
/** 一次搜索请求（引擎视角；与 ctx.web seam 的 WebSearchRequest 对齐）。 */
export interface EngineSearchRequest {
    readonly query: string;
    readonly maxResults: number;
    /** 解析后的查询操作符；编排器解析一次下发，引擎可选消费（不认就忽略，按 query 原文处理）。 */
    readonly syntax?: QuerySyntax;
    /** 热点/资讯查询提示：适配器可请求新闻索引并带回发布时间。 */
    readonly freshness?: 'news';
    /**
     * 垂直取数请求：路由器判定为结构化取数意图时下发
     * （tag 形如 finance.quote / academic.paper）；引擎不认则忽略、按通用搜索处理。
     * params 首版不做精确提取，垂直 query 自身支持语义匹配。
     */
    readonly vertical?: VerticalRequest;
    /**
     * 是否希望引擎附带生成式答案：路由器判定知乎意图时置真；
     * 引擎可选消费——有配额且成功时填充 outcome.content，失败 fail-open 不影响搜索。
     */
    readonly wantAnswer?: boolean;
}
/** 结构化取数的目标频道与可选参数（值域为标量，与 AnySearch 垂直 params 契约一致）。 */
export interface VerticalRequest {
    /** 完整 {domain}.{sub_domain} 标签，如 finance.quote、security.vuln。 */
    readonly tag: string;
    readonly params?: Readonly<Record<string, string | number | boolean>>;
}
/** 归一化来源条目——与 seam 的 WebSearchSource 同形；引擎不得发明额外字段。 */
export interface EngineSearchSource {
    readonly url: string;
    readonly title?: string;
    readonly snippet?: string;
    readonly summary?: string;
    readonly publishedAt?: string;
}
export interface EngineSearchOutcome {
    readonly sources: readonly EngineSearchSource[];
    /** 引擎侧截断过结果时必须置 true；truncated 逐层传播，任一 true 则最终 true。 */
    readonly truncated: boolean;
    /** 引擎生成的答案/摘要文本（对应 seam 的 content；没有则省略）。 */
    readonly content?: string;
}
export interface EngineFetchOutcome {
    /** 重定向后的最终 URL。 */
    readonly url: string;
    readonly statusCode: number;
    readonly body: {
        readonly kind: 'html' | 'text';
        readonly content: string;
    };
    readonly truncated: boolean;
}
/** 额度报告。无额度端点的引擎（AIHOT）返回 available:false 表示显式 N/A。 */
export interface QuotaReport {
    readonly engineId: string;
    readonly available: boolean;
    readonly used?: number;
    readonly limit?: number;
    readonly remaining?: number;
    readonly resetsAt?: string;
    /** 原始响应摘要（限长），供设置页展示。 */
    readonly raw?: string;
}
/**
 * 引擎执行上下文显式传递，不依赖 AsyncLocalStorage 隐式上下文。
 * 由装配/编排层构造；引擎不读全局配置、不直接访问 DSH 凭证。
 */
export interface EngineContext {
    readonly signal: AbortSignal;
    /** 操作 deadline 的绝对时间戳（ms）。 */
    readonly deadline: number;
    /** 解析后的凭证（key/keyless-fallback 引擎的账号模式；匿名模式省略）。 */
    readonly apiKey?: string;
    /** 本次调用的引擎端点（已应用用户覆盖）。 */
    readonly endpoint: string;
    /**
     * 请求预算记账：引擎发起的每个 HTTP 请求前调用；返回 false 表示预算耗尽，引擎应立即放弃
     * 并返回 network/aborted 类失败，而不是继续请求。
     */
    readonly countRequest: () => boolean;
}
/** 单路结果：成功与失败都收敛为数据，不向上抛。 */
export type EngineResult<T> = {
    ok: true;
    outcome: T;
} | {
    ok: false;
    failure: EngineFailure;
};
export type SearchFn = (req: EngineSearchRequest, ctx: EngineContext) => Promise<EngineResult<EngineSearchOutcome>>;
export type FetchFn = (url: string, ctx: EngineContext) => Promise<EngineResult<EngineFetchOutcome>>;
export type QuotaFn = (ctx: EngineContext) => Promise<QuotaReport>;
/**
 * 热点榜能力：无需查询词的当下议题清单（知乎热榜 100/日、AIHOT hot-topics 匿名）。
 * 引擎可选实现；路由器对「热点/热榜」类查询优先调用它而非普通搜索。
 */
export type HotTopicsFn = (ctx: EngineContext) => Promise<EngineResult<EngineSearchOutcome>>;
/**
 * 引擎 = 清单 + 可选能力函数。capabilities 描述设置面与装配；函数存在与否是运行时事实，
 * 装配层按两者交集注册（manifest 声明 search 但函数缺失属于注册表完整性错误，M0 测试钉死）。
 */
export interface Engine {
    readonly manifest: EngineManifest;
    readonly search?: SearchFn;
    readonly fetch?: FetchFn;
    /**
     * 提取适用性谓词（可选）：引擎声明自己只处理哪些 URL。fetch provider 把谓词命中的引擎
     * 当专属路优先派发；谓词返回 false 的引擎本轮不派发（不发请求、不产生 invalid 失败）；
     * 未声明该方法的引擎按通用提取路处理，顺序不变。谓词是运行时能力，不进 manifest 数据；
     * fetch 层只消费该方法、不认识具体引擎（R7 架构红线）。
     */
    readonly fetchApplicable?: (url: string) => boolean;
    readonly quota?: QuotaFn;
    /** 热点榜（可选）：无查询词的当下议题清单。 */
    readonly hotTopics?: HotTopicsFn;
}
