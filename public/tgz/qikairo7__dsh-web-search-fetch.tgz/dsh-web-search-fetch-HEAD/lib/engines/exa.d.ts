import type { Engine } from './contract.js';
export interface ExaEngineOptions {
    /** fetch 注入口：离线单测替身用；缺省全局 fetch。 */
    readonly fetcher?: typeof fetch;
}
export declare function createExaEngine(options?: ExaEngineOptions): Engine;
