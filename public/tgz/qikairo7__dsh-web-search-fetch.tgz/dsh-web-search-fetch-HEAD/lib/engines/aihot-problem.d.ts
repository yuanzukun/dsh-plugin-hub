import type { EngineHttpError } from './http.js';
/** Problem JSON 的稳定摘要：code/requestId 前置，避免被长度截断吃掉。 */
export declare function problemDetail(error: EngineHttpError): string | undefined;
/** Problem JSON 的 retryAfter（官方 OpenAPI：整数秒，仅 429/503）。 */
export declare function problemRetryAfterMs(error: EngineHttpError): number | undefined;
