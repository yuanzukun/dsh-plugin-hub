import type { EngineContext, EngineFetchOutcome, EngineResult } from './contract.js';
import { type ZhihuEngineOptions } from './zhihu-shared.js';
/**
 * 可处理性判定：仅 zhihu.com/question/<数字 id>（允许 /question/<id>/... 后缀与查询参数）。
 * 非问题 URL 返回 undefined——适配器不发请求、不消费预算，让其他提取引擎接管。
 */
export declare function zhihuQuestionId(rawUrl: string): string | undefined;
/**
 * fetch 面处理器：不适用 URL 或凭据缺失时都不发请求；请求/映射错误统一投影。
 * 预算记账由 engineJson → engineFetch 完成（每个 HTTP 请求一次 countRequest）。
 */
export declare function fetchQuestionAnswers(url: string, ctx: EngineContext, options: ZhihuEngineOptions): Promise<EngineResult<EngineFetchOutcome>>;
