import { type EngineFailure } from './failure.js';
/** 只声明映射用到的字段，其余字段按契约保留不读（不编造契约外字段名）。 */
export interface ZhihuEnvelope<T> {
    readonly Code?: number;
    readonly Message?: string;
    readonly Data?: T;
}
export interface ZhihuEngineOptions {
    /** fetch 注入口：离线单测替身用；缺省全局 fetch（经 engineJson 透传）。 */
    readonly fetcher?: typeof fetch;
    /** 覆盖请求 URL（本地替身服务器等）；只改请求地址，不改动 ZHIHU_MANIFEST。 */
    readonly endpointOverride?: string;
    /** 直答开关：默认开；false 时即使 request.wantAnswer 为真也不调用（显式关闭）。 */
    readonly answer?: boolean;
}
/** 契约要求的鉴权头；时间戳每次请求现取（服务端校验 ±10 分钟窗口）。 */
export declare function authHeaders(apiKey: string): Record<string, string>;
/** 把端点换成 manifest 里登记的路径，保留 origin/端口。 */
export declare function withPath(endpoint: string, path: string): URL;
export declare function asText(value: unknown): string | undefined;
export declare function asHttpUrl(value: unknown): string | undefined;
/**
 * envelope 非成功码 → 失败，按契约错误码表映射（api-contracts/zhihu.json errors）：
 * 20001 鉴权失败 → auth、10001 参数错误 → invalid、30001 频率限制 → rate-limited、
 * 90001 内部错误及其余未知码 → provider-error。detail 保留原始 Code/Message。
 */
export declare function envelopeFailure(envelope: ZhihuEnvelope<unknown>): EngineFailure | undefined;
