import type { EngineContext } from './contract.js';
import { type EngineFailure } from './failure.js';
/** 引擎 HTTP 层错误：wire 层唯一需要识别的异常类型。 */
export declare class EngineHttpError extends Error {
    readonly kind: 'budget' | 'aborted' | 'http' | 'network' | 'timeout' | 'parse';
    readonly status?: number | undefined;
    readonly detail?: string | undefined;
    readonly retryAfterMs?: number | undefined;
    /** 非 2xx 响应体（有界读取后）可解析为 JSON 时的解析值：业务错误码（anysearch error_code、知乎 Code、tavily failed_results）从这里取；超限或非 JSON 时为 undefined。 */
    readonly body?: unknown | undefined;
    /** 非 2xx 响应头：304 条件缓存需要读 304 自身的 Cache-Control/ETag。 */
    readonly headers?: Headers | undefined;
    constructor(kind: 'budget' | 'aborted' | 'http' | 'network' | 'timeout' | 'parse', status?: number | undefined, detail?: string | undefined, retryAfterMs?: number | undefined, 
    /** 非 2xx 响应体（有界读取后）可解析为 JSON 时的解析值：业务错误码（anysearch error_code、知乎 Code、tavily failed_results）从这里取；超限或非 JSON 时为 undefined。 */
    body?: unknown | undefined, 
    /** 非 2xx 响应头：304 条件缓存需要读 304 自身的 Cache-Control/ETag。 */
    headers?: Headers | undefined);
}
export interface EngineFetchInit extends Omit<RequestInit, 'signal'> {
    /** 单请求超时；缺省取「30s 与操作剩余 deadline 的较小者」。 */
    readonly timeoutMs?: number;
    /** fetch 注入口：离线单测替身用；缺省全局 fetch。 */
    readonly fetcher?: typeof fetch;
}
/**
 * 引擎拥有的 HTTP 请求：预算许可 → 信号合成（操作信号 + 单请求超时）→ fetch。
 * redirect 固定 'error'（v0.2 budgetedFetch 语义）：引擎 API 不应重定向。
 */
export declare function engineFetch(ctx: EngineContext, url: string, init?: EngineFetchInit): Promise<Response>;
/** JSON 版：非 JSON 的 2xx 响应按 parse 错误处理。 */
export declare function engineJson<T>(ctx: EngineContext, url: string, init?: EngineFetchInit): Promise<T>;
/**
 * 把 wire 层异常投影为统一失败模型（AD6）。
 * 429 → rate-limited（带 Retry-After）；402 → quota（402 语义由 breakerSignalOf 转日级 insufficient-credits）；
 * 401/403 → auth；单请求超时 → timeout；其余非 2xx → provider-error（引擎 API 的 404/422 是请求形状问题，不是目标站状态）。
 * 目标站状态（提取失败、目标 4xx）由各引擎从响应体内解析，不经此路径。
 */
export declare function projectHttpError(error: unknown): EngineFailure;
