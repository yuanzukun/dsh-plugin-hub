import type { EngineSearchRequest, EngineSearchSource } from './contract.js';
export interface ParsedItems {
    readonly sources: readonly EngineSearchSource[];
    readonly hasMore: boolean;
}
type JsonRecord = Record<string, unknown>;
/**
 * 查询语法接线：items API 只有 q 一个检索参数；全部操作符按 raw 原样回拼进 q。
 * syntax 缺省（直接调用引擎的旧入口）时沿用 query.trim()。
 */
export declare function outgoingQuery(request: EngineSearchRequest): string;
/** 组装 `/api/v1/items` 请求 URL；端点非法返回 undefined。 */
export declare function buildRequestUrl(base: string, query: string, maxResults: number): string | undefined;
/** 读取并校验 items 响应；返回字符串表示失败原因（不缓存）。 */
export declare function readItems(response: Response): Promise<ParsedItems | string>;
/** 按字节上限读取响应体；超限返回 undefined。 */
export declare function readBoundedText(response: Response, maxBytes: number): Promise<string | undefined>;
/** 结果截断按请求 maxResults 与上游 page.hasMore 取并。 */
export declare function toOutcome(parsed: ParsedItems, maxResults: number): {
    sources: EngineSearchSource[];
    truncated: boolean;
};
export declare function isRecord(value: unknown): value is JsonRecord;
export declare function isText(value: unknown): value is string;
export {};
