import type { HotTopicsFn } from './contract.js';
import { type ZhihuEngineOptions } from './zhihu-shared.js';
/**
 * Engine.hotTopics 处理器：缺凭证是配置错误（不发请求、不降级）；请求/映射错误统一投影。
 */
export declare function hotTopicsHandler(options: ZhihuEngineOptions): HotTopicsFn;
