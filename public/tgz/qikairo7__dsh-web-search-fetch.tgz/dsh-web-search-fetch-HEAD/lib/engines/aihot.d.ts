import { type WebFetchResult } from '@deepseek-ai/dsh-web';
import type { Engine, EngineContext } from './contract.js';
export interface AihotEngineOptions {
    /** 注入 fetcher（离线单测替身）；缺省全局 fetch。 */
    readonly fetcher?: typeof fetch;
    /** 覆盖请求 URL（不改 manifest，用于用户端点配置与测试替身）。 */
    readonly endpointOverride?: string;
}
/**
 * 创建 AIHOT 引擎：匿名只读，无 key 分支；搜索走 `/api/v1/items` 的关键词检索。
 * 缓存与冷却挂在引擎实例上，不是跨进程限流器。
 */
export declare function createAihotEngine(options?: AihotEngineOptions): Engine;
export interface AihotApiReaderOptions {
    /** 注入 fetcher（离线单测替身）；缺省全局 fetch。 */
    readonly fetcher?: typeof fetch;
}
/**
 * 与 src/fetch/provider.ts:51-54 的 DedicatedApiReader 结构兼容。
 * 引擎层不 import 提取层模块，故在此重复声明形状（字段与注释指向保持同步）。
 */
export interface AihotApiReader {
    readonly engineId: 'aihot';
    readApi(url: string, ctx: EngineContext): Promise<WebFetchResult | undefined>;
    isCached(result: WebFetchResult): boolean;
}
/**
 * 创建 AIHOT 专用读取器：只接管文档化的 /api/v1/* 只读端点与 agent Markdown 面；
 * 其余 URL 返回 undefined，调用方继续通用提取。
 *
 * 失败约定（对照 src/fetch/provider.ts 的 DedicatedApiReader 与 WebFetchProvider 契约）：
 * - 上游非 2xx 是可表示的资源状态，Problem JSON 原样保留 code/requestId/retryAfter，
 *   收敛为对应 statusCode 的 WebFetchResult（不上抛）；429/503 另按 EngineFailure 分类冷却；
 * - 传输/校验类失败无法用 WebFetchResult 表示，上抛路由化的 WebError（provider 不 catch，
 *   由 seam 统一处理），裸异常不外泄。
 */
export declare function createAihotApiReader(options?: AihotApiReaderOptions): AihotApiReader;
