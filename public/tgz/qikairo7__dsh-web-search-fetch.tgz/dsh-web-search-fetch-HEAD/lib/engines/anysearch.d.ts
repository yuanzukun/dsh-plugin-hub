import type { Engine } from './contract.js';
/** 按操作覆盖请求 URL；search 与 extract 端点不同，必须分开，避免一个操作静默发到另一个端点。 */
export interface AnysearchEndpointOverride {
    readonly search?: string;
    readonly fetch?: string;
}
export interface AnysearchEngineOptions {
    /** fetch 注入口：离线单测替身用；缺省全局 fetch。 */
    readonly fetcher?: typeof fetch;
    /** 按操作覆盖请求 URL；只影响本引擎发出的请求，不修改 manifest。 */
    readonly endpointOverride?: AnysearchEndpointOverride;
    /** 垂直与通用搜索共用的区域选择：设置后写进每个 search 请求体；缺省不发。 */
    readonly zone?: 'cn' | 'intl';
    /** 实时区域读取（设置页 volatile）；每次 search 求值，优先于 zone。 */
    readonly resolveZone?: () => 'cn' | 'intl' | undefined;
    /** 语言偏好默认值：syntax.language（lang: 操作符）优先于该默认（syntax 覆盖工厂）。 */
    readonly language?: string;
}
export declare function createAnysearchEngine(options?: AnysearchEngineOptions): Engine;
