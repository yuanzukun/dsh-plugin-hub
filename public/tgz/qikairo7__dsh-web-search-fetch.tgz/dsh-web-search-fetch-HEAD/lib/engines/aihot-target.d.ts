export interface ApiTarget {
    readonly url: string;
    readonly key: string;
    readonly markdown: boolean;
    readonly defaultTtlMs: number;
}
export declare const DEFAULT_CACHE_TTL_MS = 60000;
/** 只接管文档化的 https://aihot.news/api/v1/* 只读端点。 */
export declare function apiTarget(rawUrl: string): ApiTarget | undefined;
