import type { Engine } from './contract.js';
export interface TavilyEngineOptions {
    /** fetch 注入口：离线单测替身用；缺省全局 fetch。 */
    readonly fetcher?: typeof fetch;
    /** 只覆盖请求 URL（测试/自建代理用），不修改 manifest 中的端点。 */
    readonly endpointOverride?: string;
}
/** 创建 Tavily 引擎（search / fetch / quota 三面）。 */
export declare function createTavilyEngine(options?: TavilyEngineOptions): Engine;
