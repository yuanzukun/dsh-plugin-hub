export declare function clipSnippet(text: string): string;
export declare function asRecord(value: unknown): Record<string, unknown> | undefined;
export declare function asText(value: unknown): string | undefined;
export declare function asNumber(value: unknown): number | undefined;
/** seam 的 source 必须有绝对 http(s) URL；相对地址、ftp 等一律丢弃。 */
export declare function asHttpUrl(value: unknown): string | undefined;
