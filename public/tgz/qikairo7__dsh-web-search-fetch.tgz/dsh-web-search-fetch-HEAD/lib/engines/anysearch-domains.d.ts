/** 一个垂直子域的标签与参数定义（tag 即 /v1/search 的 tag 字段）。 */
export interface SubDomainInfo {
    readonly tag: string;
    readonly description: string;
    readonly params: ReadonlyArray<{
        readonly name: string;
        readonly description: string;
        readonly required: boolean;
    }>;
}
/** 一次能力发现调用的预算与取消上下文（编排层按操作注入；缺省不限制）。 */
export interface DomainDiscoveryBudget {
    /** 调用方操作信号；与内部超时合并。 */
    readonly signal?: AbortSignal;
    /** 每次网络请求写出前调用；返回 false 时立即放弃（不发起请求）。 */
    readonly countRequest?: () => boolean;
}
/** 垂直 tag 校验结果：是否存在 + 缺失的必填参数名。 */
export interface VerticalTagVerdict {
    readonly exists: boolean;
    readonly missingRequired: readonly string[];
}
export interface AnysearchDomainCatalogOptions {
    /** fetch 注入口：离线单测替身用；缺省全局 fetch。 */
    readonly fetcher?: typeof fetch;
    /** API 基址；默认公网端点。可传实时 getter（设置页 volatile 保存后下一次请求生效）。 */
    readonly baseUrl?: string | (() => string | undefined);
    /** 单个发现请求的超时（毫秒），默认 30s；防上游黑洞挂死搜索 deadline。 */
    readonly timeoutMs?: number;
    /** 缓存有效期（毫秒），默认 24h；<=0 表示每次调用都重新拉取。 */
    readonly ttlMs?: number;
    /** 时钟注入口：单测控制 TTL 用；缺省 Date.now。 */
    readonly now?: () => number;
    /** 可选 API key：提供时发现请求带 Authorization: Bearer，缺省匿名（契约记录匿名可用）。 */
    readonly apiKey?: string;
}
/**
 * 领域发现缓存：listTags 首次调用依次请求 /v1/domains 与 /v1/sub-domains，
 * 把 data.domains[].sub_domains[] 扁平化为 tag 列表并缓存 ttlMs。
 */
export declare class AnysearchDomainCatalog {
    private readonly fetcher;
    private readonly resolveBaseUrl;
    private readonly timeoutMs;
    private readonly ttlMs;
    private readonly now;
    private readonly apiKey;
    private cached;
    private inFlight;
    constructor(options?: AnysearchDomainCatalogOptions);
    /** 全部 {domain}.{sub_domain} 标签与参数定义；同一 baseUrl 的 TTL 内直接复用缓存。 */
    listTags(budget?: DomainDiscoveryBudget): Promise<readonly SubDomainInfo[]>;
    /**
     * 校验垂直 tag：是否存在，以及 params 定义中 required 的参数哪些没有提供。
     * 只按官方 required 位判断，不猜测条件必填（required=false 的语义由上游解释）。
     */
    validate(tag: string, params?: Readonly<Record<string, string | number | boolean>>, budget?: DomainDiscoveryBudget): Promise<VerticalTagVerdict>;
    private refresh;
    /** 发现请求（GET + 统一信封）；超时与拒绝重定向与 engineFetch 策略一致；非 2xx 只报状态码，不读取正文。 */
    private requestData;
}
