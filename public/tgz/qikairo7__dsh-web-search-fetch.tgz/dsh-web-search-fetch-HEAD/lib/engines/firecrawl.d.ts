import type { Engine } from './contract.js';
import { type FirecrawlEndpointOptions } from './firecrawl-url.js';
export interface FirecrawlEngineOptions {
    /** fetch 注入口：离线单测替身用；缺省全局 fetch。 */
    readonly fetcher?: typeof fetch;
    readonly endpointOverride?: FirecrawlEndpointOptions['endpointOverride'];
    /** 时间注入（离线测试相对日期）。 */
    readonly now?: () => number;
}
export declare function createFirecrawlEngine(options?: FirecrawlEngineOptions): Engine;
