import type { Engine } from './contract.js';
export interface FirecrawlEngineOptions {
    /** fetch 注入口：离线单测替身用；缺省全局 fetch。 */
    readonly fetcher?: typeof fetch;
    /** 代理域名/测试基点：覆盖请求 URL，不修改 manifest（支持 firecrawl 代理域名用户）。 */
    readonly endpointOverride?: string;
}
export declare function createFirecrawlEngine(options?: FirecrawlEngineOptions): Engine;
