import type { EngineContext } from './contract.js';
export type FirecrawlOperation = 'search' | 'fetch' | 'quota';
export interface FirecrawlEndpointOptions {
    readonly endpointOverride?: string;
}
export declare function resolveRequestUrl(operation: FirecrawlOperation, ctx: EngineContext, options: FirecrawlEndpointOptions): string | undefined;
