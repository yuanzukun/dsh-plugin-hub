/** 上游发布时间的共享归一化；只做确定性转换，不猜测不可精确换算的单位。 */
export interface DatePeriod {
    readonly year: number;
    readonly month: number;
    readonly day: number;
    readonly daySpecified: boolean;
}
export declare function publishedDateToIso(value: unknown): string | undefined;
export declare function relativePublishedDate(value: unknown, now: number): string | undefined;
export declare function parseDatePeriod(value: string): DatePeriod | undefined;
