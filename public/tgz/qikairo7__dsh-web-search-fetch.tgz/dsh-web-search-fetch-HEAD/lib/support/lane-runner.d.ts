import type { EngineResult } from '../engines/contract.js';
import type { EngineFailure } from '../engines/failure.js';
/** 单路结果：ok / failed / timeout / aborted（调用方取消）。 */
export type LaneOutcome<T> = {
    readonly kind: 'ok';
    readonly engineId: string;
    readonly result: T;
    readonly elapsedMs: number;
} | {
    readonly kind: 'failed';
    readonly engineId: string;
    readonly failure: EngineFailure;
    readonly elapsedMs: number;
} | {
    readonly kind: 'timeout';
    readonly engineId: string;
    readonly elapsedMs: number;
} | {
    readonly kind: 'aborted';
    readonly engineId: string;
};
/** 单路日志汇（编排层注入；不传即静默）。 */
export interface LaneLogSink {
    laneInfo(engineId: string, message: string): void;
    laneWarn(engineId: string, message: string): void;
}
export interface RunLaneOptions<T> {
    readonly engineId: string;
    /** 操作信号（取消/总限时）；每路信号是它与该路自身 deadline 的合成。 */
    readonly signal?: AbortSignal;
    /** 单路 deadline（毫秒）。 */
    readonly deadlineMs: number;
    /** 引擎工作：收到该路合成信号，返回收敛后的结果。 */
    readonly work: (signal: AbortSignal) => Promise<EngineResult<T>>;
    readonly log?: LaneLogSink;
    /** 时钟覆盖（测试）。 */
    readonly now?: () => number;
}
/**
 * 跑一路引擎调用，永不抛出。
 * 熔断跳过不在此处，由编排层在派发前过滤；
 * 本函数只负责单路执行语义。
 */
export declare function runLane<T>(options: RunLaneOptions<T>): Promise<LaneOutcome<T>>;
/** 把未知异常投影成 EngineFailure（引擎适配层兜底用；正常路径引擎自己投影）。 */
export declare function failureFromUnknown(error: unknown): EngineFailure;
