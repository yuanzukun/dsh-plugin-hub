import type { QuotaReport } from '../engines/contract.js';
import type { EngineFailure } from '../engines/failure.js';
/** 为什么一个引擎被移出轮换。 */
export type BreakerReason = 'rate-limit' | 'quota-exhausted' | 'insufficient-credits';
/**
 * 一条熔断输入。`rate-limit` 是冷却（Retry-After 语义），其余两个是日级耗尽信号
 * （断到本地次日零点）。
 */
export interface BreakerSignal {
    readonly kind: BreakerReason;
    /** Retry-After 提示（毫秒），仅 rate-limit 有意义。 */
    readonly retryAfterMs?: number;
}
/** 「这个引擎现在是否在轮换外」的回答。 */
export interface BreakerStatus {
    readonly broken: boolean;
    /** 恰在 broken=true 时出现。 */
    readonly reason?: BreakerReason;
    /** rate-limit：冷却结束时刻。 */
    readonly cooldownUntil?: number;
    /** 日级耗尽：下次本地零点。 */
    readonly resetAt?: number;
}
/** 每次熔断/恢复跃迁发出的结构化事件。 */
export type BreakerEvent = {
    readonly type: 'open';
    readonly engineId: string;
    readonly reason: BreakerReason;
    readonly at: number;
    readonly until: number;
} | {
    readonly type: 'recovery';
    readonly engineId: string;
    readonly reason: BreakerReason;
    readonly at: number;
};
export interface CircuitBreakerOptions {
    /** open/recovery 事件汇；上层映射到 ctx.logger，本模块不 import cordis。 */
    onEvent?: (event: BreakerEvent) => void;
    /** 唯一时钟；测试注入固定值，每个方法另接受逐调用 now。 */
    now?: () => number;
    /** 无 Retry-After 的裸 rate-limit 冷却时长，默认 60s。 */
    defaultRateLimitCooldownMs?: number;
    /** 指数退避上限，默认 1h。 */
    maxRateLimitCooldownMs?: number;
}
/**
 * 统一失败模型 → 熔断输入。
 * - rate-limited → 冷却（带 retryAfterMs 则按提示）
 * - quota：statusCode 402（额度/信用耗尽，如 Firecrawl）→ insufficient-credits 日级；其余 quota → quota-exhausted 日级
 * - 其余 kind 不产生熔断输入（aborted/invalid/target-status/auth 不是引擎健康信号）
 */
export declare function breakerSignalOf(failure: EngineFailure): BreakerSignal | undefined;
/**
 * 官方额度快照 → 熔断输入（日检与面板刷新共用）。
 * `available && remaining !== undefined && remaining <= 0` → 日级 quota-exhausted；
 * available:false（引擎自述 N/A）与 remaining 缺失（如 Tavily「不限」）都不是耗尽信号。
 */
export declare function quotaReportSignal(report: QuotaReport): BreakerSignal | undefined;
/** 默认裸 rate-limit 冷却。 */
export declare const DEFAULT_RATE_LIMIT_COOLDOWN_MS = 60000;
/** 指数退避上限。 */
export declare const MAX_RATE_LIMIT_COOLDOWN_MS = 3600000;
/** 严格晚于 nowMs 的下一个本地零点（含月/年翻转）。 */
export declare function nextLocalMidnight(nowMs: number): number;
/** 渲染单条熔断日志行（上层经 ctx.logger 写出）。 */
export declare function formatBreakerEvent(event: BreakerEvent): string;
export declare class CircuitBreaker {
    private readonly onEvent;
    private readonly clock;
    private readonly defaultCooldownMs;
    private readonly maxCooldownMs;
    private readonly engines;
    constructor(options?: CircuitBreakerOptions);
    /**
     * 记一条熔断信号并返回状态。
     * - rate-limit：按 retryAfterMs 冷却，缺省用短默认；冷却中重复触发按 hint × 2^(streak-1)
     *   指数退避（封顶 max）；hint<=0 撤销进行中的冷却。不降级日级熔断。
     * - quota-exhausted / insufficient-credits：断到本地零点；从冷却升级，当日幂等（首个原因胜出）。
     */
    recordSignal(engineId: string, signal: BreakerSignal, now?: number): BreakerStatus;
    /**
     * 解除一个引擎的日级额度熔断（面板刷新拿到健康官方快照时调用）。
     * 只删 quota-exhausted / insufficient-credits 条目并发 recovery；rate-limit 冷却原样保留。
     */
    clearDaily(engineId: string, now?: number): BreakerStatus;
    /** 引擎当前是否在轮换外；未知引擎不在。 */
    isBroken(engineId: string, now?: number): boolean;
    /**
     * 当前熔断状态；未知引擎安全返回 { broken: false }。
     * 落在期限之后的查询就地结算条目——恢复事件恰好发一次，因此熔断器不需要定时器。
     */
    status(engineId: string, now?: number): BreakerStatus;
    private emit;
}
