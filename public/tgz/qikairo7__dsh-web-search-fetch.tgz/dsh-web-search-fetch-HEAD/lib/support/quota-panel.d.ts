import type { Engine, EngineManifest, EngineQuotaPeriod, QuotaReport } from '../engines/contract.js';
import { type BreakerReason, type CircuitBreaker } from './breaker.js';
import type { QuotaLedger, QuotaLedgerCounts } from './quota-ledger.js';
import type { QuotaSnapshotStore } from './quota-snapshots.js';
/** 官方额度周期标记（引擎知识，由装配层映射后注入）。 */
export type QuotaPanelPeriod = EngineQuotaPeriod;
/** 面板的引擎事实：manifest + 装配层映射出的周期标记。 */
export type PanelEngineManifest = EngineManifest & {
    readonly period: QuotaPanelPeriod;
};
/** 官方额度视图：未刷新 = undefined；ok 带数值；unavailable 只带原因。 */
export type OfficialQuota = {
    readonly kind: 'ok';
    readonly used?: number;
    readonly limit?: number;
    readonly remaining?: number;
    readonly resetsAt?: string;
    readonly raw?: string;
    readonly fetchedAt: number;
} | {
    readonly kind: 'unavailable';
    readonly reason: string;
    readonly fetchedAt: number;
} | undefined;
export interface PanelEngineRow {
    readonly id: string;
    /** resolveEnabled() 派生（停用行由客户端标「已停用（未探测）」）。 */
    readonly enabled: boolean;
    readonly period: QuotaPanelPeriod;
    readonly official: OfficialQuota;
    /** 现取本地账本快照（按本地日滚动）。 */
    readonly ledger: QuotaLedgerCounts;
    /** 现取熔断状态；until = cooldownUntil ?? resetAt。 */
    readonly breaker: {
        readonly broken: boolean;
        readonly reason?: BreakerReason;
        readonly until?: number;
    };
}
export interface PanelPayload {
    /** 规范本地日 YYYY-MM-DD。 */
    readonly day: string;
    readonly engines: readonly PanelEngineRow[];
}
/** 单引擎探测硬超时默认值。 */
export declare const DEFAULT_QUOTA_PROBE_TIMEOUT_MS = 10000;
/** 一次 refresh 的总截止默认值。 */
export declare const DEFAULT_QUOTA_REFRESH_DEADLINE_MS = 15000;
export type QuotaProbe = (manifest: PanelEngineManifest, signal: AbortSignal) => Promise<QuotaReport>;
export interface QuotaPanelOptions {
    readonly engines: readonly Engine[];
    /** registry 顺序 + 装配层周期映射。 */
    readonly manifests: readonly PanelEngineManifest[];
    readonly ledger: QuotaLedger;
    readonly store: QuotaSnapshotStore;
    readonly breaker: CircuitBreaker;
    /** 服务开关快照（装配层由 resolveControls().serviceEnabled 派生）。 */
    readonly resolveEnabled: () => Readonly<Record<string, boolean>>;
    /** 装配侧闭包 = buildContext + engine.quota；凭证解析异常必须抛 {@link QuotaCredentialError}。 */
    readonly probe: QuotaProbe;
    readonly now?: () => number;
    /** 单引擎探测硬超时（测试注入短值）。 */
    readonly perEngineTimeoutMs?: number;
    /** 整次 refresh 总截止（测试注入短值）。 */
    readonly totalTimeoutMs?: number;
}
/**
 * 凭证服务不可用：装配侧 probe 在 buildContext/凭证解析抛错时改抛本错误，
 * 面板据此给出固定原因（零请求、不喂熔断、不连坐其他引擎）。
 */
export declare class QuotaCredentialError extends Error {
    constructor();
}
/**
 * 额度面板服务：get() 现取；refresh() 探测启用且带 quota() 的引擎后现组装返回。
 * 单飞：同引擎并发 refresh 共享同一个在途探测；硬超时：每引擎 10s、整次 15s。
 */
export declare class QuotaPanelService {
    private readonly manifests;
    private readonly ledger;
    private readonly store;
    private readonly breaker;
    private readonly resolveEnabled;
    private readonly probe;
    private readonly now;
    private readonly perEngineTimeoutMs;
    private readonly totalTimeoutMs;
    /** 有 quota() 的引擎 id 集（探测对象判定；停用与无端点均由装配层在此之外过滤）。 */
    private readonly quotaEngineIds;
    private readonly inFlight;
    constructor(options: QuotaPanelOptions);
    /** 现组装：day/ledger/breaker 全按调用时刻取（不缓存）。 */
    get(): PanelPayload;
    /** 探测启用且带 quota() 的引擎，写快照仓与熔断投影，然后现组装返回完整 payload。 */
    refresh(): Promise<PanelPayload>;
    /** 官方快照 → 熔断投影：耗尽开日级；健康且 remaining>0 解除日级（rate-limit 不动）。 */
    private applySnapshot;
    /** 单飞：per-engine 在途 Promise，并发 refresh 共享同一次探测结果。 */
    private runProbe;
    /** 每引擎硬超时与整次总截止竞速；到点 abort 探测信号并弃用结果。 */
    private probeWithinDeadlines;
    private isEnabled;
    private assemble;
}
