import type { WebSearchResult } from '@deepseek-ai/dsh-web';
/** 默认容量上限（条）。 */
export declare const DEFAULT_QUERY_CACHE_CAPACITY = 50;
export interface QueryCacheOptions {
    /** 容量上限，默认 50；非法值回退默认。 */
    capacity?: number;
    /** 唯一时钟，默认 Date.now；测试注入固定/可推进时钟。 */
    now?: () => number;
}
/** 一次命中：缓存结果 + 距写入时刻的整数秒数（向下取整，命中说明用）。 */
export interface QueryCacheHit {
    readonly result: WebSearchResult;
    readonly ageSeconds: number;
}
/** 归一查询：首尾去空白，内部连续空白折叠为一个空格。 */
export declare function normalizeQuery(query: string): string;
/**
 * 缓存键：归一 query + 意图 + site: 域名（排序后拼接）+ maxResults + 配置指纹。
 * 用 NUL 分隔，避免查询文本里恰好含意图名造成拼接歧义；域名排序让 site: 书写顺序不影响命中。
 * maxResults 参与键：同查询不同条数上限不得互相复用（结果切片不同）。
 * 配置指纹由编排层提供；配置变更后键变化，旧结果不再命中。
 * plannerVersion 由编排层提供；搜索规则或质量门升级后旧条目自然失效。
 * intent 是调用方传入的不透明标签，本层不解析其含义。
 */
export declare function queryCacheKey(query: string, intent: string, domains: readonly string[], maxResults?: number, fingerprint?: string, plannerVersion?: string): string;
/**
 * 精确匹配的查询结果缓存；不做语义缓存。
 * - TTL 由调用方按意图传入；`ttlSeconds <= 0` 表示该意图不缓存（不读也不写）。
 * - 命中刷新 LRU 次序；写入超过容量时淘汰最久未使用的一条。
 * - 过期条目在读取时惰性删除。
 */
export declare class QueryCache {
    private readonly entries;
    private readonly capacity;
    private readonly now;
    constructor(options?: QueryCacheOptions);
    /** 命中返回结果与年龄；过期即删除并按未命中处理。 */
    get(key: string, ttlSeconds: number): QueryCacheHit | undefined;
    /** 写入；同键覆盖并刷新时间戳。ttlSeconds <= 0 直接忽略。 */
    set(key: string, result: WebSearchResult, ttlSeconds: number): void;
    /** 当前条目数（测试与诊断用）。 */
    get size(): number;
}
