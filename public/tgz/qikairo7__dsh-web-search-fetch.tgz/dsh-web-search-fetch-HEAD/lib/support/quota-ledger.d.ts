/** 当日额度型失败达到该次数，视为该源本地耗尽（估算口径，不保证上游余额）。 */
export declare const LOCAL_QUOTA_FAILURE_THRESHOLD = 2;
/** 单引擎的本地计数快照（只读视图）。 */
export interface QuotaLedgerCounts {
    readonly success: number;
    readonly rateLimited: number;
    readonly quotaFailures: number;
    /** 本地日键（YYYY-M-D）；跨日自动清零。 */
    readonly day: string;
}
export interface QuotaLedgerOptions {
    /** 时钟注入口：单测控制日滚动用；缺省 Date.now。 */
    readonly now?: () => number;
}
/**
 * 本地额度账本：记录每引擎成功/限流/额度失败次数，按本地日滚动。
 * 不区分 search/fetch 面——同一引擎的额度由上游账号共享，任一面的额度失败都算数。
 */
export declare class QuotaLedger {
    private readonly now;
    private readonly entries;
    constructor(options?: QuotaLedgerOptions);
    recordSuccess(engineId: string): void;
    recordRateLimited(engineId: string): void;
    recordQuotaFailure(engineId: string): void;
    /**
     * 当日额度型失败是否已达「本地耗尽」阈值（默认 2 次）。
     * 估算 ≠ 上游余额：只说明本地连续观察到额度失败、值得当日跳过该源；
     * 上游可能已恢复，跨日后计数清零重新观察。
     */
    locallyExhausted(engineId: string, threshold?: number): boolean;
    /** 当前本地日的计数快照；未知引擎返回全零（不创建条目语义对调用方不可见）。 */
    snapshot(engineId: string): QuotaLedgerCounts;
    /** 取当日计数；跨日时以新的一天清零重建。 */
    private entry;
}
/** 本地日键（本地时区，与额度日检同一口径）。 */
export declare function localDayKey(nowMs: number): string;
