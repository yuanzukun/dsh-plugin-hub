/** 调用档（spec §3.4：balanced/deep 已删，select 模式已删）。 */
export type RuntimePreset = 'auto' | 'single' | 'multi' | 'custom' | 'free';
/** 一次操作的运行时控制快照（设置页控件 → 装配层构造）。 */
export interface RuntimeControls {
    /** 提取侧整理模式；v0.2 的 select 模式已删，字段保留给旧配置平滑读取。 */
    mode?: 'organize' | 'select';
    preset?: RuntimePreset;
    /** 自动档正在处理的请求类型与文本（自动预设 breadth 判定用）。 */
    request?: 'search' | 'fetch';
    requestText?: string;
    searchServices?: readonly string[];
    fetchServices?: readonly string[];
    serviceEnabled?: Readonly<Record<string, boolean>>;
    maxSearchServices?: number;
    maxFetchServices?: number;
    maxRequests?: number;
    searchDeadlineMs?: number;
    fetchDeadlineMs?: number;
    maxOutputChars?: number;
}
/** DSH 多查询批共享的请求预算；同一个 batch signal 下所有 provider 调用共同记账。 */
export declare class SharedRequestBudget {
    readonly maxRequests: number;
    private requests;
    constructor(maxRequests: number);
    get requestCount(): number;
    get remainingRequests(): number;
    acquire(): boolean;
}
/**
 * 一次 provider 操作的显式上下文：并发查询与重试彼此隔离。
 * notes 是结构化操作说明（AD4：呈现层负责拼中文文案，这里只收事实行）。
 */
export declare class OpContext {
    readonly controls: RuntimeControls;
    /** 操作合成信号（调用方取消 + 总限时）。 */
    readonly signal: AbortSignal;
    private readonly caller?;
    readonly notes: string[];
    private requests;
    private readonly sharedRequests?;
    readonly maxRequests: number;
    private closed;
    constructor(controls: RuntimeControls, signal: AbortSignal, caller: AbortSignal | undefined, maxRequests: number, sharedRequests?: SharedRequestBudget);
    get requestCount(): number;
    /** 操作还可派发的请求数；无预算上限时为 Infinity。 */
    get remainingRequests(): number;
    /** 追加一条操作说明事实行。 */
    note(text: string): void;
    /** 总限时是否已到（区别于调用方主动取消）。 */
    get deadlineReached(): boolean;
    /**
     * 请求预算记账：每个插件拥有的 HTTP 尝试在网络写出前先取许可。
     * @returns false 表示预算耗尽或操作已关闭，调用方必须放弃该请求。
     */
    countRequest(): boolean;
    /** 标记操作收尾：此后不再发放请求许可。 */
    close(): void;
}
/**
 * 建立一次操作：构造 deadline 信号与显式上下文，跑 work，把总限时/取消语义
 * （v0.2 runOperation 原样）套在外面。总限时到时 abort 感知的单路先完成微任务、
 * 返回幸存者；无响应的工作在下一个事件循环轮次被停住。
 */
export declare function runOperation<T>(controls: RuntimeControls, face: 'search' | 'fetch', caller: AbortSignal | undefined, work: (op: OpContext) => Promise<T>, sharedRequests?: SharedRequestBudget): Promise<T>;
/** 把操作请求文本挂到控制快照（自动预设 breadth 判定用）。 */
export declare function resolveRuntimeRequest(controls: RuntimeControls, request: 'search' | 'fetch', text: string): RuntimeControls;
/** 已取消的单路必须能结算，即使它注入的传输层忽略信号。 */
export declare function abortable<T>(work: Promise<T>, signal?: AbortSignal): Promise<T>;
