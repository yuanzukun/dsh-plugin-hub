/**
 * 把结果 URL 归一成去重键：每个 utm_* 参数丢弃，#fragment 丢弃，scheme/hostname 小写
 * （URL 本身已做），根路径归一使 '/' 与 '' 共键。其余参数与非根尾斜杠保持显著，
 * 仅下列已验证的 MDN / TypeScript 别名例外。
 * 不可解析的 URL 原样返回：去重可能因此漏并一次，但来源绝不被丢弃或改写成引擎没返回过的东西。
 */
export declare function normalizeSearchUrl(url: string): string;
