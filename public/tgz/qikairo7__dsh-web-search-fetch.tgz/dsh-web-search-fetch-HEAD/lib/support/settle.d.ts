export declare class SettlementWindow {
    private readonly controller;
    readonly signal: AbortSignal;
    private timer?;
    private readonly started;
    constructor(parent?: AbortSignal);
    get endedEarly(): boolean;
    observe(sufficient: boolean): void;
    finish(): void;
}
