import type { QuotaReport } from '../engines/contract.js';
/** 单引擎官方快照：ok 带官方数值字段；unavailable 只带原因。 */
export type QuotaSnapshot = {
    readonly kind: 'ok';
    readonly used?: number;
    readonly limit?: number;
    readonly remaining?: number;
    readonly resetsAt?: string;
    readonly raw?: string;
    readonly fetchedAt: number;
} | {
    readonly kind: 'unavailable';
    readonly reason: string;
    readonly fetchedAt: number;
};
export interface QuotaSnapshotStoreOptions {
    /** 时钟注入口：单测控制 fetchedAt；缺省 Date.now。 */
    readonly now?: () => number;
}
/**
 * 纯内存官方快照仓：注入时钟，不持久化（重启清零由面板脚注说明）。
 * 面板是唯一消费者；日检钩子与手动刷新都经 record() 归一，两态语义一致。
 */
export declare class QuotaSnapshotStore {
    private readonly now;
    private readonly entries;
    constructor(options?: QuotaSnapshotStoreOptions);
    /**
     * 写入一次正常 resolve 的探测结果：
     * available 且有数值 → ok；available:false 或无任何数值 → unavailable（reason 取 raw）。
     */
    record(engineId: string, report: QuotaReport): QuotaSnapshot;
    /** 写入探测失败/超时/凭证服务异常：不冒充官方数值，只留原因。 */
    recordUnavailable(engineId: string, reason: string): QuotaSnapshot;
    /** 最近一次快照；未知引擎返回 undefined（面板显示「未刷新」）。 */
    get(engineId: string): QuotaSnapshot | undefined;
}
