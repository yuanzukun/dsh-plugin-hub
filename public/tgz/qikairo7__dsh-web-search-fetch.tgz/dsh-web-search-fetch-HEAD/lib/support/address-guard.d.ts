import { WebError } from '@deepseek-ai/dsh-web';
/**
 * 一个文本地址是否为非公网目的地。只接受 unicast；ipaddr.js 报告的其余范围
 * （含终点无法钉死的翻译/隧道前缀）一律拒绝。非地址文本返回 false（不归本函数管）。
 */
export declare function isPrivateAddress(input: string): boolean;
/** 主机名 → 地址列表；解析失败为 undefined。 */
export type AddressLookup = (hostname: string) => Promise<readonly string[] | undefined>;
/** 默认解析器：操作系统解析器，一次性返回全部答案。 */
export declare const systemLookup: AddressLookup;
/** 一次守卫检查的结果。 */
export interface AddressGuardVerdict {
    /** 仅当目的地被证明非公网时为 false。 */
    readonly allowed: boolean;
    /** 作出判定的地址，供错误消息与日志。 */
    readonly address?: string;
    /** 无法作出判定时的原因。 */
    readonly reason?: 'unresolvable' | 'not-a-url' | 'exempt' | 'public';
}
/**
 * 判定一个 URL 是否可交给第三方提取引擎。
 * 不抛异常；操作取消时不再等待解析器。
 */
export declare function guardTargetAddress(rawUrl: string, options?: {
    exemptHosts?: readonly string[];
    lookup?: AddressLookup;
    signal?: AbortSignal;
}): Promise<AddressGuardVerdict>;
/** 用接缝自己的阻断码拒绝私有目的地。 */
export declare function blockedTargetError(rawUrl: string, address?: string): WebError;
