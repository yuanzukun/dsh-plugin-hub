import { type CircuitBreaker } from './breaker.js';
import type { LaneOutcome } from './lane-runner.js';
/** 单路结局的额度账本口径：只记录影响额度判断的三类。 */
export type LaneOutcomeKind = 'success' | 'rate-limited' | 'quota';
export type LaneOutcomeReporter = (engineId: string, kind: LaneOutcomeKind) => void;
/** 单路结局 → 额度账本口径；超时、取消与其他失败不入账。 */
export declare function ledgerKindOfOutcome<T>(outcome: LaneOutcome<T>): LaneOutcomeKind | undefined;
/** 单路收尾：先记额度，再把结构化失败喂给熔断。 */
export declare class LaneSettlement {
    private readonly report;
    private readonly breaker?;
    constructor(report: LaneOutcomeReporter | undefined, breaker?: CircuitBreaker | undefined);
    settle<T>(outcome: LaneOutcome<T>): void;
}
