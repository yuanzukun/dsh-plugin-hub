# 安全说明

本文描述当前交付 v0.4.4 的默认行为（2026-11-09 核对）。

## 凭证

插件配置只保存凭证引用名：`anysearchApiKeyEnv`、`tavilyApiKeyEnv`、`firecrawlApiKeyEnv`、`zhihuApiKeyEnv` 与 `rerank.apiKeyEnv`。凭证值由 DSH credentials 服务管理，每个 provider 操作异步解析一次，轮换后下一次操作生效。AIHOT 是匿名只读服务，没有凭证位。

客户端设置页只读取「是否已配置」的状态，不回传凭证字面量；留空的密钥草稿不会清除已保存的值；未保存的密钥草稿只存在于浏览器内存。不要将真实凭证提交到 Git、Issue、测试夹具或截图。

解析到的值若为空，或命中占位符保护集（引用名本身，如 `ANYSEARCH_API_KEY`、`TAVILY_API_KEY`、`FIRECRAWL_API_KEY`、`ZHIHU_API_KEY`、`SILICONFLOW_API_KEY`，以及示例值 `as_sk_your_key`、`tvly-YOUR_API_KEY`、`fc-your-key`），会按未配置处理，不发送，避免把配置字面量当成真钥。

鉴权模式：AnySearch 与 Tavily 未配 key 时走服务方匿名/keyless 公共额度；已配 key 后若凭证失效，只报 `auth`，不会静默降级匿名。Firecrawl 的提取面（`/v2/scrape`）在官方端点有免钥 free tier（受出口 IP 信誉门控），搜索面（`/v2/search`）仍需 `fc-` 密钥，自定义端点需配置密钥；配置密钥后若凭证失效，同样只报 `auth`，不会静默降级匿名。知乎必须配置 Access Secret。AIHOT 匿名只读。

当前暴露端点覆盖的只有 AnySearch（`anysearchBaseURL`）与 Firecrawl（`firecrawlBaseURL`）。自定义端点会收到对应鉴权头；AnySearch 未配 key 时该端点收到匿名请求。仅配置可信的 HTTPS 地址。插件 API 请求固定拒绝 HTTP 重定向，自定义端点需填写最终 API 地址；静态 HTTP 路径由宿主执行独立的重定向与地址校验策略，最多 5 次重定向。

## 外部请求

搜索查询会发送给已启用、已选中且未熔断的搜索服务。未配 key 的 AnySearch 与 Tavily 以匿名/keyless 方式发送；Firecrawl 的搜索面与知乎缺少凭证时该路在派发前被跳过，Firecrawl 的提取面在官方端点按免钥请求。动态提取会把完整目标 URL 发送给参与提取的第三方服务。URL 的查询参数可能包含私密数据，提交前需检查；来源说明会保留服务返回的 URL。

自动预设在动态提取时先向排在最前的一路引擎发送一次探测。结果为 2xx、返回目标与请求目标一致（允许同资源的 HTTPS 升级）、不是登录或挑战页，且普通段落不少于 400 字符时，直接返回该路原文，不再向其他提取服务发送 URL；否则升级为多路整理，已取得的这一路并入候选，不重复请求同一服务。

`rerank.enabled` 默认开启；配置 `SILICONFLOW_API_KEY` 后，融合后的前 30 条候选的标题与摘要（每条截断到 1,000 字符）以及查询文本会发送到 SiliconFlow `/v1/rerank`（模型 `BAAI/bge-reranker-v2-m3`）。重排失败按融合序返回（fail-open），不阻塞搜索；关闭开关或清空密钥即不发送。

带额度端点的引擎在搜索操作中按本地日检查一次额度。额度查询使用对应凭证、计入请求预算，是只读端点，服务方口径不消耗搜索额度。AnySearch 与 AIHOT 没有额度端点。

### 地址守卫

提取 provider 在操作开始后、AIHOT 专用 API 判定、URL 路由与引擎派发之前执行地址守卫。判定顺序：不可解析或非 HTTP(S) 的 URL 不在此拦截（随后交给静态路，由内置 HTTP 提取器给出 URL 校验）；字面量 IP 直接分类；主机名解析全部答案，任一答案落在非公网范围即拒绝。拒绝时以 `WEB_BLOCKED_URL` 结束本次提取，不向 AIHOT 专用 API、第三方提取引擎或静态 HTTP 发送该 URL。

非公网范围包括：未指定、广播、组播、链路本地、回环、私网、保留、运营商级 NAT、唯一本地、IPv4 映射、RFC 6145 / RFC 6052 转换、6to4、Teredo；只有 `unicast` 放行。解析失败不拦截；等待解析受操作信号约束，取消即停止等待。

豁免语义：守卫函数接受 `exemptHosts`（点界匹配，主机相等或其子域），provider 从路由选项的 `staticDomains` 注入；provider 另有 `blockPrivateAddresses: false` 可关闭整条守卫。当前 `Config` 没有 `fetch` 段，未暴露这两个参数，默认装配不注入豁免、保持守卫开启。因此发行行为是：所有提取 URL 在派发前都经过守卫，没有用户可配置的跳过开关。

守卫只覆盖插件自己发起的请求；第三方提取服务仍可能通过重定向或页面内资源访问其他地址。

### AIHOT 专用只读 API

AIHOT 专用读取器只接管 `https://aihot.news/api/v1/...` 的文档化只读路径（items、hot-topics、stories、codex-resets、dailies、weeklies、monthlies、selected、agent）。要求 HTTPS、主机名精确为 `aihot.news`、不带用户名/密码/端口，且路径命中白名单；其他 URL 继续走通用提取。JSON 与 Markdown 响应保留来源、canonical、attribution、原文链接、分页与增量字段；插件只读取被请求的一页，不自动翻页、不写入副本、不创建定时任务。429/503 按 Retry-After 冷却，不并发重试。

AIHOT 默认关闭；启用前应阅读其使用规则，见下文「已知边界」。

### 已知边界

知乎：搜索与额度查询带 `Authorization: Bearer <Access Secret>` 与 `X-Request-Timestamp`（秒级 Unix 时间戳，服务端校验 ±10 分钟窗口）。本机时钟偏移超过窗口会导致鉴权失败；插件不重试、不修改或伪造时间戳。

匿名额度：AnySearch 未配 key 时使用按来源 IP 限流的公共匿名额度（服务方契约）；共享 NAT 或出口 IP 会共享额度。Tavily 的 keyless 模式只覆盖 `/search` 与 `/extract`，`/usage` 必须带 key，因此匿名额度没有可查询数值；Firecrawl 只有提取面（`/v2/scrape`）在官方端点可免钥，受出口 IP 信誉门控、限额未公开，按实验性能力对待；搜索面（`/v2/search`）仍需 `fc-` 密钥，自定义端点需配置密钥，额度端点不支持免钥。AnySearch 匿名 402 的响应正文可能包含自动建号凭据，插件在失败详情与日志中丢弃该正文，只保留状态与固定说明。

AIHOT 是独立的公益资讯服务，插件默认关闭。个人非商业、公益非商业及组织内部使用可按其规则免费使用；对外商业产品、代理、转售、公开镜像或再分发需事先取得书面授权；须保留机器响应中的来源、canonical、attribution 与原文链接。插件的 MIT 许可不覆盖 AIHOT 数据服务。规则见 [AIHOT 使用规则](https://aihot.news/terms) 与 [NOTICE](./NOTICE)。

网页内容和搜索结果属于不可信输入，可能包含提示注入或错误信息。插件提供提取与排序，不验证内容真实性，也不执行网页中的指令。

## 日志与资源限制

插件日志记录服务状态、单路延迟、超时或失败原因、熔断事件、请求次数、返回正文长度与整理说明。错误详情截断到约 300 字符，可能保留服务方返回的文本；AnySearch 匿名 402 正文被显式丢弃。插件不把凭证值写入日志，但分享日志前仍需检查查询内容、私密 URL 与上游返回文本。

`controls.maxRequests` 默认 32（范围 1–256），限制每次操作的插件 HTTP 请求次数；每个引擎请求、额度查询与重排都经同一预算计数。它是请求预算，不是金额或账户额度上限。搜索总限时默认 15 秒，提取总限时默认 50 秒。

静态 HTTP 路径限制响应 5,000,000 字节、正文 100,000 字符，单请求超时 30 秒，最多 5 次重定向。AIHOT 搜索与专用 API 的响应读取上限为 1,000,000 字节；专用 API 文本上限为 100,000 字符。其他引擎的 JSON 响应没有统一的读取上限。

动态正文整理在转换前拒绝超过 1,000,000 字符或超过 2,000 块的输入；输出默认 15,000 字符（可配 1,000–1,000,000），按完整内容块省略并设置 `truncated`。

上述上限在收到响应后生效，不能限制收到响应前的网络缓冲。并发请求会消耗多个服务的额度。部署时应限制工具并发并评估响应体大小；插件面向受控 DSH 环境，不应作为未经访问控制的公共抓取服务。

## 漏洞报告

仓库已启用 GitHub Private vulnerability reporting。发现安全问题时，请使用[私密漏洞报告入口](https://github.com/qikairo7/dsh-web-search-fetch/security/advisories/new)，报告内容不公开。

若入口不可用，不要把可利用细节或私密数据放入公开 Issue；可提交不含这些细节的联系请求，待维护者提供私密沟通方式。报告应包含受影响版本、可复现条件、影响和脱敏复现材料。本项目暂未承诺固定安全响应时限。
