import { defineConfig } from 'vitest/config'

export default defineConfig({
  test: {
    include: ['test/**/*.test.ts'],
    coverage: {
      enabled: true,
      provider: 'v8',
      include: ['src/**/*.ts'],
      exclude: ['**/*.d.ts'],
      reporter: ['text-summary'],
      reportsDirectory: 'coverage',
      thresholds: {
        statements: 85,
        branches: 80,
        functions: 90,
        lines: 90,
      },
    },
  },
})
