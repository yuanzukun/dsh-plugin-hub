# 常见问题

本文按 v0.4.4 的代码事实核对（2026-11-09）。先看错误码与逐路状态，再按现象排查；文末列出核对所依据的源码位置。

## 先看错误码

| 错误码 | 典型来源 | 先查什么 |
| --- | --- | --- |
| `WEB_PROVIDER_ERROR` | 搜索全部通道失败或没有可派发通道；动态提取全部失败；整理后没有可用目标正文；AIHOT 专用 API 的传输或版本失败 | 看错误消息里的逐路状态或 `target-rejected` / `engine-unavailable` 分组 |
| `WEB_SEARCH_TIMEOUT` | 搜索操作总限时到，且没有任何成功通道 | `controls.searchDeadlineMs`、宿主工具超时、服务数量与请求预算 |
| `WEB_FETCH_TIMEOUT` | 提取操作总限时到且没有可用正文；单通道路径在限时内未返回 | `controls.fetchDeadlineMs`、单路 45 秒上限、首路探测 15 秒上限 |
| `WEB_ABORTED` | 调用方取消（宿主的工具超时或用户取消） | 宿主工具配置；这不是插件总限时，也不是服务故障 |
| `WEB_BLOCKED_URL` | 内网/本机地址被守卫拒绝；静态抓取非 2xx 且空正文；动态提取的目标级拒绝 | 地址目标、目标站状态、是否只有登录或挑战页 |
| `WEB_INVALID_URL` | URL 不是绝对 `http(s)`，或引擎判定输入非法 | 传入 URL、自定义端点、查询参数 |
| `WEB_FETCH_TOO_LARGE` | 单页输入超过 1,000,000 字符、内容块超过 2,000、结构化正文超过输出预算，或 AIHOT 专用 API 超过 100,000 字符 | 缩小目标页、提高 `controls.maxOutputChars`、缩小 AIHOT 的 `limit` |
| `WEB_UNSUPPORTED_CONTENT_TYPE` | 宿主 HTTP 提取器不接受响应类型；引擎违约上抛时保留原码 | 目标资源类型；改用动态提取服务 |

部分结果不会报错：搜索或提取已经拿到可用结果、只是未派发完全部通道时，返回结果并把 `truncated` 置为 `true`，说明里保留原因。只有一条结果都没有且操作总限时已到时，才分别返回 `WEB_SEARCH_TIMEOUT` / `WEB_FETCH_TIMEOUT`。

## 插件未加载或设置卡片未出现

确认安装目标与当前会话使用同一个 DSH profile。源码安装先运行 `pnpm run build`，使 `lib/index.js` 存在；检查装载配置中是否出现 `web-search-fetch`。插件向宿主注册两个 id 为 `aggregated` 的 provider，`web` 配置里应分别选择它们作为搜索与提取 provider；若宿主发现多个可用 provider 且没有明确选择，会报 `WEB_PROVIDER_AMBIGUOUS`。

设置卡片还依赖宿主提供的 settings、locale、UI 与 credentials 服务。仅后端装载不代表浏览器卡片可用；卡片显示“插件当前未加载”时，先确认当前会话装载的是这个 profile 与这个版本。

当前服务表只有五个引擎加直接 HTTP 抓取：AnySearch AI、Tavily、Firecrawl、知乎、AIHOT、`http`。旧版服务名不再出现在设置页，写进旧配置也不会重新创建对应引擎。

## 搜索返回 `WEB_PROVIDER_ERROR`

这个码表示搜索没有可用结果，不是“查询一定无解”。按消息分三种情况：

- 所有通道都失败：`Aggregated web search failed on every engine: <引擎> (<失败类型> <状态码>); ...`。失败类型包括 `rate-limited`、`quota`、`timeout`、`auth`、`invalid`、`network`、`provider-error` 等；已熔断的通道会写成 `(已熔断，跳过)`。
- 没有任何通道可派发：`Aggregated web search failed: no engine is configured`。检查服务总开关、`controls.searchServices`、预设与请求预算。
- 所有通道都返回了空结果或候选全被相关性过滤：不会报 `WEB_PROVIDER_ERROR`，而是返回空 `sources`，`content` 以 `未找到与查询相关的结果` 开头，并逐路点名状态：成功但无结果、成功返回 N 条但均与查询无关、限流、当日额度耗尽、余额不足、超时、被操作总限时取消、已熔断、请求失败。据此区分“查询无解”和“覆盖不足”。

空结果也会传播 `truncated`：任一路声明还有分页、宽限窗口提前取消未完成通道、或操作总限时已到时，`truncated` 为 `true`，说明里保留“操作总限时已到”或“宽限等待结束后提前取消未完成渠道”一行。

搜索成功时，`content` 可能包含这些说明：实际选择的服务数、服务数量上限、自动档判定为单/多通道、限定官方域名的补充检索、单通道空结果补派、宽限窗口提前结束、SiliconFlow 重排。说明是事实行，不是错误。

## 匿名额度、402 与额度熔断

`AnySearch AI` 与 `Tavily` 是 `keyless-fallback`：未配置密钥时走官方匿名额度，配置密钥后走账户额度；密钥失效不会静默降级匿名。

- AnySearch：匿名额度按 IP 限流，官方没有公开额度查询端点，`quota()` 不存在。HTTP 402 会投影为额度耗尽（`insufficient-credits`），详情里不保留上游正文（匿名 402 正文可能携带自动建号凭据）。持续 402 或匿名受限时配置 `ANYSEARCH_API_KEY`。
- Tavily：匿名请求携带 `x-tavily-access-mode: keyless`，没有 `Authorization`；`/usage` 必须带密钥，因此 keyless 模式的额度查询显式返回 N/A。HTTP 432/433 是套餐或 PAYGO 上限（额度耗尽），429 是限流，434 是 Flex tier 容量问题（按服务端错误处理，不是额度）。收到 432/433 或匿名共享限流时配置 `TAVILY_API_KEY`。
- Firecrawl：提取（`/v2/scrape`）在官方端点有 keyless free tier，未配置密钥时匿名请求，但同样受出口 IP 信誉门控（2026-11-08 实测同一网络：干净出口三次 200，VPN/代理特征出口 403 且官方文案要求注册免费 key，换节点或直连可恢复）；搜索（`/v2/search`）的 403 门控更稳定。未配置密钥时装配层在搜索面派发前跳过该路，适配器本身也不发请求并返回 `auth`。额度耗尽可能表现为 HTTP 402，也可能是 HTTP 200 但信封 `success:false` 且 `code` 含 `insufficient_credits`，两种都会进入额度熔断。`GET /v2/team/credit-usage` 的 `resetsAt` 取 `billingPeriodEnd`，只用于展示账期。
- 知乎：必须配置 `ZHIHU_API_KEY`。`GET /api/v1/quota` 汇总 `global_search` 与 `zhihu_search` 两项的 `TotalQuota`、`TotalUsed`、`RemainingQuota`；响应不含搜索额度项时返回 N/A，不伪造数字。
- AIHOT：匿名只读，没有额度端点，额度显式为 N/A；搜索面的 402 仍会投影为额度耗尽。AIHOT 搜索面的 401/403 按 `provider-error` 处理，不是缺少密钥，而是策略或授权拒绝。

熔断把额度失败分成两类，均停用到宿主时区的次日零点：

| 失败形状 | 熔断原因 | 恢复时间 |
| --- | --- | --- |
| HTTP 402（AnySearch、Tavily、AIHOT 等） | `insufficient-credits` | 本地次日零点 |
| Firecrawl 的 HTTP 200 额度信封、Tavily 432/433、其他非 402 的额度状态 | `quota-exhausted` | 本地次日零点 |
| 429 或引擎限流信号 | `rate-limit` | 按 `Retry-After` 的冷却期 |

额度熔断的额外规则：

- 搜索侧每个本地日只做一轮额度探测，范围是已启用且实现 `quota()` 的引擎（Tavily、Firecrawl、知乎），在选源之前执行、与当次选中的服务无关；`remaining <= 0` 时写入日级熔断，日志写 `当日额度已耗尽（remaining N），本次起停用`。当天一旦标记完成，后续搜索不再探测其他引擎；探测失败只记日志，不阻塞搜索，也不在当天重试。
- 熔断状态只在内存中，插件重启即清空；搜索与提取共用同一个熔断器（按引擎 id），任一面记录限流或额度信号后，该引擎在另一面也会被跳过。
- 恢复是惰性的：下一次操作读取状态时才发现到期并写恢复日志，没有后台定时器。
- 服务方的账期不一定等于宿主本地日期；即使 Firecrawl 显示 `billingPeriodEnd`，熔断仍按本地次日零点恢复。次日恢复尝试后如果额度仍未恢复，会再次熔断。
- 设置卡「额度」小节展示官方快照与本地计数，并提供「刷新额度」手动探测；日检与手动刷新共用同一快照仓。面板不自动轮询。

## 额度面板显示「未刷新」或 unavailable

设置卡「额度」小节每引擎一行，官方侧只有四种单结果：无端点 →「估算」；有端点但本次运行尚未取到快照 →「未刷新」；取到 → 数值与周期文案；探测失败 → 原因原文。另有服务停用 →「已停用（未探测）」，本地账本三项全零 →「今日未使用」。

- 「未刷新」：快照仓是进程内内存，重启后为空。打开设置页只读仓，不探测；等当日首次搜索的日检，或点击「刷新额度」。
- 「unavailable」且原因为 keyless 相关：Tavily 未配密钥时 `/usage` 必须带 key；Firecrawl 的额度端点不支持免钥。配置密钥后再刷新。
- 「unavailable」且原因为「凭证服务不可用」：面板解析凭证失败，此时零外发、不喂熔断，也不影响其他引擎；检查宿主凭证服务后重试。
- 「unavailable」且原因为「探测超时」：单引擎限时 10 秒、整次刷新总截止 15 秒；超时只影响该行，稍后重试。
- 「额度数据通道不可用」：宿主连接通道未就绪或面板服务未加载（客户端经 `connection.rpc` 直调 `quotaPanel/get` 与 `quotaPanel/refresh`）；设置页其余部分与凭证刷新不受影响。检查插件版本与宿主连接服务；T0 已验证的 `/quota` 命令样板保留为后备，本版未注册。
- 「已停用（未探测）」：服务开关关闭，面板不会探测该引擎。
- 刷新只解除日级额度熔断（官方快照 `remaining > 0` 时）；不会解除 `rate-limit` 冷却。

## Firecrawl 免钥免费层（实验性）

Firecrawl 的 `POST /v2/scrape` 在官方端点支持无密钥调用（2026-11-08 本机实测 200）：请求不带 `Authorization`，正文按 `data.markdown` 返回。边界：

- 搜索不走免钥：`POST /v2/search` 对代理/VPN 出口返回 403，官方错误文案要求注册免费 key；搜索面仍需 `fc-` 密钥。
- 额度端点不支持免钥：`GET /v2/team/credit-usage` 无 key 返回 401；适配器在无 key 时不发请求，返回 `available:false` 并注明 keyless。
- 免钥限额未公开、未主动压测；按实验性能力对待，不要让它承担关键流程。自定义 `firecrawlBaseURL` 不再计入官方免钥额度，必须配置密钥。

## 429 冷却与恢复

限流使用冷却而不是日级熔断：

- 优先采用响应头 `Retry-After`（秒数或 HTTP 日期）；没有该头时默认冷却 60 秒。
- 连续收到限流信号时，冷却时长按 `hint × 2^(连续次数-1)` 指数退避，封顶 1 小时。`Retry-After: 0` 会撤销进行中的冷却。
- 冷却期间若收到额度信号，会从 `rate-limit` 升级为日级额度熔断；冷却本身不会降级为日级。
- 单路超时不触发熔断；`auth`、`invalid`、`target-status`、调用取消也不触发。

日志形如：

- `[熔断] 引擎 <id> 已停用：触发原因 rate-limit，预计恢复 <ISO 时间>`
- `[熔断] 引擎 <id> 熔断恢复：原触发原因 rate-limit`

AIHOT 另有一层实例内冷却：429/503 使用 `Retry-After`，缺失时回退 Problem JSON 的 `retryAfter`，再缺失则 60 秒。冷却期间普通搜索直接返回上次的失败；缓存命中仍可返回已有内容。该冷却不是跨进程限流器。

## 知乎错误码 30001 与 20001

知乎搜索响应是 `{Code, Message, Data}` 信封，非 0 时按以下规则投影：

| Code | 投影 | 处理 |
| --- | --- | --- |
| `0` | 成功 | 正常读取 `Data.Items` |
| `20001` | `auth` | 检查 `ZHIHU_API_KEY` 是否有效、Access Secret 是否正确，以及本机时钟；`X-Request-Timestamp` 是秒级时间戳，服务端校验约 ±10 分钟时间窗，时钟偏差会导致鉴权失败 |
| `30001` | `rate-limited` | 频率限制，进入冷却并降低并发；不是额度耗尽 |
| `10001` | `invalid` | 查询或参数不合法 |
| `90001` 及其他未知码 | `provider-error` | 上游故障，按服务端错误处理 |

额度接口返回 `30001` 时不会抛错，而是 `available:false`，`raw` 里保留 `30001` 与上游消息。`Data` 为空数组表示没有配置搜索额度项，同样返回 N/A。

问题回答（`question_answers`）的 `30001` 与搜索面口径不同：问题回答与问题推荐共用「问题发现」日额度（默认 100/日，北京时间 00:00 重置），官方文档明确 `30001` 同时表示频率/并发限制或当日额度耗尽；提取面统一投影为 `quota`，让熔断与本地额度账本按额度失败处理，而不是短冷却。其余 Code 与搜索面一致（`20001` → `auth`、`10001` → `invalid`、`90001` 及其他 → `provider-error`）。

知乎按查询意图选择搜索面：查询含“知乎”或 `zhihu.com`（包括 `site:zhihu.com`，大小写与路径后缀不影响）时走 `/api/v1/content/zhihu_search`，否则走 `global_search`。站内面 `Count` 上限 10，全网面上限 20。

## 查询语法没有按预期过滤

查询操作符只有写成空格分隔的合法 token 才会被识别：`site:`、`-site:`、`lang:`、`after:`、`before:`。解析器只识别这五种；`site:` 后没有合法域名、日期形状不合法或其它写法会原样留在查询文本里，不会被删除。

不支持的操作符会“回拼”：把原 token 按原顺序、原大小写、原路径后缀逐字拼回查询文本。这意味着它被当作普通搜索词，不是过滤条件。各引擎的实际映射如下：

| 操作符 | AnySearch AI | Tavily | Firecrawl | 知乎 | AIHOT |
| --- | --- | --- | --- | --- | --- |
| `site:` | 回拼 | `include_domains` | `includeDomains` | 回拼 | 回拼 |
| `-site:` | 回拼 | `exclude_domains` | `excludeDomains` | 回拼 | 回拼 |
| `lang:` | `language` | `language` + `filter_by_language` | 回拼 | 回拼 | 回拼 |
| `after:` | 回拼 | `start_date` | 回拼 | 回拼 | 回拼 |
| `before:` | 回拼 | `end_date` | 回拼 | 回拼 | 回拼 |

补充规则：

- Tavily 的 `after:YYYY` 取当年 01-01，`after:YYYY-MM` 取当月 01，`after:YYYY-MM-DD` 校验后原样；`before:YYYY` 取上一年 12-31，`before:YYYY-MM` 取上月最后一日，`before:YYYY-MM-DD` 原样作为结束日期。非法日历值（例如 `after:2026-13`）按 unsupported 回拼。
- Tavily 的 `site:` 超过 300 个、`-site:` 超过 150 个会返回 `invalid`，不会静默截断或放宽过滤意图。
- Firecrawl 同时出现 `site:` 与 `-site:` 时，契约无法同时表达两类域名参数，因此两者都回拼、不发送任何域名参数。
- 知乎与 AIHOT 没有操作符原生参数，五种操作符全部回拼；知乎的搜索面选择仍用回拼前的原查询。AIHOT 回拼后按 2–200 个字符校验，超限返回 `invalid`。
- 所有操作符都被原生参数吸收、组合查询为空时，会退回调用方原始查询文本，避免发出空查询。
- 查询里显式写 `site:` 或 `-site:` 时不会再加“限定官方域名”的补充检索；`single` 预设也不会加。其它情况下，官方文档意图会为前一到两个已选服务各增加一次 `site:<官方域名>` 补充查询，并消耗请求预算。

## 重排没有生效或结果顺序没变

SiliconFlow 重排默认开启，但只有解析到有效密钥时才真正生效：

- 密钥引用由 `rerank.apiKeyEnv` 指定，默认 `SILICONFLOW_API_KEY`；`SILICONFLOW_API_KEY` 等占位字面量会被当成未配置。
- 只对 RRF 融合后的前 30 个候选调用 `BAAI/bge-reranker-v2-m3`，单次重排 deadline 为 5 秒；第 31 个及以后的候选保持融合顺序跟在后面，不丢结果。
- 成功时说明里出现 `结果经 SiliconFlow 重排服务排序。`。
- 失败是 fail-open：按融合顺序返回，说明里出现 `重排服务不可用（<失败类型>），按融合排序返回。`；返回空结果时写 `重排服务返回空结果，按融合序返回。`。重排失败不阻塞搜索，也不参与引擎熔断。
- 没有密钥或 `rerank.enabled: false` 时不会出现任何说明行；“没有重排说明”本身不是错误，也不代表重排失败。
- 重排只改变排序，不做过滤、不删除来源；失败时不要期待它会重试。

## 目标站返回 4xx，却报成服务不可用

各服务报告目标站状态的方式不同，决定非 2xx 是“结果”还是“错误”：

| 服务 | 目标站 4xx 的表现 | 插件结果 |
| --- | --- | --- |
| 静态 HTTP 路径 | 状态码与正文原样返回 | 有正文的非 2xx 是结果；非 2xx 且正文为空抛 `WEB_BLOCKED_URL` |
| Firecrawl | `data.metadata.statusCode` 原样透传 | `statusCode` 是目标站状态，仍是结果 |
| Tavily | `/extract` 用 `failed_results` 报告失败，不回报真实状态码 | 该路以 `target-status` 失败，状态码用 4xx 占位 400，详情明示“目标状态未知”；多路时其余路继续 |
| AnySearch AI | `extract_target_blocked` 等业务错误码优先于 HTTP 状态 | `extract_target_blocked` → `target-status`（常见 HTTP 403）；`invalid_extract_url`/400 → `invalid`；`extract_content_too_large` 或 `extract_unsupported_content` → `provider-error`；HTTP 422 `extract_failed` 是引擎侧提取失败，最终报 `WEB_PROVIDER_ERROR`，不会进入“目标被拒绝”组 |
| AIHOT 专用 API | 上游非 2xx 是资源状态 | 原样返回对应 `statusCode` 与 Problem JSON，不抛错；传输、版本、超限失败才报 `WEB_*` |

动态多路提取会把带正文的非 2xx 候选纳入整理，保留来源状态；空正文候选无效。自动预设的首路探测遇到非 2xx 会升级到多路整理；显式 `single` 预设则原样返回该通道的结果，因为用户明确只要这一路。

全部动态路都失败时，错误消息按两组列原因：

- `目标被拒绝 target-rejected`：`WEB_BLOCKED_URL`、`WEB_INVALID_URL`、`WEB_UNSUPPORTED_CONTENT_TYPE`、`WEB_FETCH_TOO_LARGE`。这类错误换链接或放宽限制才有用。
- `引擎不可用 engine-unavailable`：服务自身故障、额度问题、没有可表示状态的 502/422 等。这类错误换服务或稍后重试才有用。

错误码取观察到的“最特异”一个，顺序为 `WEB_BLOCKED_URL` > `WEB_INVALID_URL` > `WEB_FETCH_TOO_LARGE` > `WEB_UNSUPPORTED_CONTENT_TYPE` > `WEB_FETCH_TIMEOUT` > `WEB_PROVIDER_ERROR`。看分组比只看最外层码更能判断下一步。

## 动态网页提取失败，静态资源正常

静态路径不需要引擎凭证，由内置 HTTP 提取器直接抓取；动态路径需要至少一个可用的提取引擎。动态路全部失败时不会自动回退到 HTTP。

默认分流规则：

- 主机命中静态域名表（默认且当前为空）、或路径末段扩展名在内置表中时走静态 HTTP。内置表包括 `txt`、`text`、`xml`、`json`、`md`、`markdown`、`csv`、`tsv`、`rss`、`atom`、`yaml`、`yml`、`log`、`ini`、`toml`、`ics`、`vtt`、`srt`。
- 不可解析或非 `http(s)` 的 URL 也交给静态路径，由宿主 HTTP 提取器给出 `WEB_INVALID_URL`。
- 其余 URL 走动态提取，交给参与提取且未熔断的引擎。

自动预设的动态提取先做两段式：

- 只派发第一路，单路探测 deadline 为 15 秒；首路达到 `2xx`、返回目标一致（允许同资源的 HTTP→HTTPS 升级）、不是登录或挑战页、且普通段落不少于 400 字符时，直接返回该路原文，不加多路整理标记。
- 任一条件不满足就升级到多路整理，并把探测结果作为候选并入，不重复请求同一引擎。说明里会出现 `首路探测 <id> 失败/不足…，已转入多路整理。` 或 `首路 <id> 已取得完整正文，未派发其他提取服务。`
- 显式 `single` 预设只派发恰好一路，正文再薄也原样返回；通道失败默认直接抛错。`singleChannelEscalate` 在这个版本没有接入 `Config`，默认关闭。
- 多路整理在至少三路返回同标题、共享长段落且各有不少于 1,200 字符段落正文时，会在宽限窗口结束后提前取消慢渠道，结果标 `truncated` 并说明“未完成内容未纳入整理”。

没有可派发引擎时，错误分别是 `no extraction engines are configured`、`all extraction engines are broken`（`WEB_PROVIDER_ERROR`），单通道没有可用通道时是中文错误 `没有可用的提取通道：单通道预设未派发任何请求`。关闭 `http` 服务后，静态 URL 报 `WEB_PROVIDER_ERROR`，不会改走动态引擎；`fetchServices` 不控制 HTTP 静态路径。

AIHOT 的专用只读 API（`https://aihot.news/api/v1/*` 的文档化路径）在通用分流之前处理。它要求 AIHOT 服务已启用、在 `fetchServices` 中、未熔断；否则该 URL 会落到通用提取路径。默认 `fetchServices` 包含具备 `fetch` 能力的 AnySearch、Tavily、Firecrawl、知乎，AIHOT 不在其中；设置页也没有为 AIHOT 提供提取参与开关，因此要让专用 API 生效，需要在配置里把 `aihot` 加入 `fetchServices`（当前界面不提供该操作）。专用 API 返回原文 Markdown 或完整 JSON，不做正文整理；请求只读取被请求的那一页，不自动翻页。

## 内网地址拒绝与 `staticDomains` 豁免

动态提取在把 URL 交给任何第三方引擎之前执行地址守卫，顺序在 AIHOT 专用 API 判定、URL 适配器和静态/动态分流之前：

- 字面量 IP 直接分类；主机名先解析，任一答案落在回环、私网、链路本地、保留、组播、运营商级 NAT、唯一本地、IPv4 映射、转换或隧道前缀时，本次拒绝。
- 拒绝时返回 `WEB_BLOCKED_URL`，消息为 `目标地址（<地址>）属于本机或内网范围，已拒绝外发给第三方提取服务；…`，URL 不会发给任何引擎。
- 主机名解析失败不拦截：守卫无法证明它是内网，交由引擎自行报错。
- 守卫只覆盖插件自己发起的请求；第三方服务仍可能通过重定向或页面内资源访问其它地址。

提取层保留了 `staticDomains` 豁免：命中列表的主机跳过守卫，交给内置 HTTP 提取器按自身策略处理。但当前 `src/index.ts` `Config` 没有 `fetch` 字段，装配层也没有把 `route.staticDomains` 或 `blockPrivateAddresses` 传给提取 provider，因此当前版本无法通过设置页或 cordis 配置启用这项豁免，守卫实际固定开启。旧文档里的 `fetch.staticDomains`、`fetch.staticRouting`、`fetch.blockPrivateAddresses` 不要当作本版本可用的配置项。关闭 `http` 服务只影响静态路径，不会关闭守卫。

## 操作超时或取消

关键数值：

| 项目 | 默认值 |
| --- | --- |
| `controls.searchDeadlineMs` | 15,000 毫秒 |
| `controls.fetchDeadlineMs` | 50,000 毫秒 |
| 搜索单路 deadline | 10,000 毫秒 |
| 提取单路 deadline | 45,000 毫秒 |
| 自动预设首路探测 deadline | 15,000 毫秒 |
| `controls.maxRequests` | 32 次，含额度检查、重试和补充检索 |

- 插件总限时到时，已完成的路仍可返回；结果标 `truncated`，说明写 `操作总限时已到；返回已完成结果，未完成服务已取消。`。如果一条可用结果都没有，搜索报 `WEB_SEARCH_TIMEOUT`，提取报 `WEB_FETCH_TIMEOUT`。
- 调用方主动取消（包括宿主工具自己的超时）报 `WEB_ABORTED`，不是插件故障；不要把它当作服务不可用而继续重试。
- 单路超时只丢弃该路，其余路继续；超时不触发熔断。请求预算耗尽时，该请求不会发出，说明里写 `请求预算已用尽；未派发额外请求。`。
- 宿主工具层的超时与插件 `controls.*DeadlineMs` 是两套限制；宿主先取消时，插件看到的是调用方取消。排查时同时核对会话实际使用的工具配置，见[配置参考](./configuration.md)。

## 整理结果出现补充、差异或省略说明

动态多路提取默认做确定性整理，不调用语言模型，不改写原文，也不判断多个版本谁为真。输出里的补充片段、文本差异与 `body-thin` 说明是整理结果，不是提取失败：

- 「补充片段」是无法可靠对齐或某一路独有的章节；「文本差异」保留数字、否定词或段落顺序的原文变体；`body-thin` 表示参照正文不足 200 字符，可能不是完整正文。
- 多路来源会带 `F1:B2` 形式的内容块标记；只有一个来源时省略标记，避免重复。尾注 `## 提取来源与处理说明` 逐路列出服务与状态。
- 单页输出默认 15,000 字符（`controls.maxOutputChars`，范围 1,000–1,000,000）。超出时按完整内容块省略，置 `truncated` 并说明省略数量；代码围栏、正文段落与数据表格不裁断。清单类表格先按 20 行、4,000 字符裁剪。
- 单份输入超过 1,000,000 字符、超过 2,000 个内容块，或结构化 JSON/XML 超过输出预算时报 `WEB_FETCH_TOO_LARGE`，不会截断后当成功结果。
- 只有登录页、挑战页或目标不一致的返回时，整理报 `WEB_PROVIDER_ERROR`，消息点名服务与 `target-mismatch` / `login-or-challenge`；非 2xx 但带正文的目标页仍可作为来源保留并显示状态。
- 规则与限制的完整说明见[网页正文整理](./content-organization.md)。

## 保存设置后没有生效

设置页的保存提示是 `已保存，下一次调用生效`。插件在操作入口读取一次 `controls` 快照；凭证与端点在首次 lane 读取快照并在同一操作的并发 lane 间共享；`ready`、区域与垂直目录按调用时读取最新值。进行中的调用继续使用它开始时读取的控制快照。凭证值也是每次操作重新解析。以下情况会让“保存了但看起来没变”：

- 服务总开关 `controls.serviceEnabled` 未打开。发行默认配置关闭知乎与 AIHOT；这两家即使填了密钥也需要打开开关。
- 服务不在 `controls.searchServices` / `controls.fetchServices` 中，或被 `controls.maxSearchServices` / `maxFetchServices` 的数量上限挤出。搜索默认最多 5 路、提取默认最多 4 路；名单顺序也是派发优先级。
- 预设收窄了范围：`single` 只派发 1 路；`multi` 用满上限；`auto` 消费本地意图路由，仅「调研对比」（`research`）与「AI 资讯」（`ai-news`）意图多路，其余意图单路（以[配置参考](./configuration.md)的「调用预设」表为准）；`custom` 按名单与上限执行；`free` 只保留 registry 标记为免密钥的服务，并按能力面过滤——Firecrawl 只有提取参与，搜索仍需密钥；知乎不参与。
- `controls.maxRequests`、`searchDeadlineMs`、`fetchDeadlineMs`、`maxOutputChars` 过小，导致请求被预算或限时截断。
- 重排没有生效：确认 `rerank.enabled` 为真，并确认 `SILICONFLOW_API_KEY` 有值且不是占位符。
- 改的是宿主工具自己的超时与结果数，而不是插件的 `controls.*`；两者相互独立。

端点覆盖与凭证引用名（`anysearchBaseURL`、`firecrawlBaseURL`、`*ApiKeyEnv`）也在实时配置里：`Config` 是根级 volatile，装配层每次操作读取一次快照，保存后下一次调用生效，不需要重新装载插件或重启 profile。凭证值本身同样按操作解析，轮换后下一次调用即可生效。进行中的调用继续使用它开始时读取的控制快照；凭证与端点在同一操作的并发 lane 间共享快照，垂直目录发现按调用时读取最新引用。

## 设置显示已配置但请求仍认证失败

“已配置”只表示 DSH 凭证服务持有该引用的值，不代表服务认证成功。逐项检查：

- 引用名是否与实际保存的凭证一致；同一个 profile 与同一个插件配置才能看到同一个引用。
- 密钥格式与账号权限：Firecrawl 搜索需要 `fc-` 密钥（提取可走官方免钥层），知乎需要开发者 Access Secret；AnySearch/Tavily 的账号模式需要对应账户的有效密钥。
- 自定义端点会收到鉴权头，必须可信并支持 HTTPS；Firecrawl 无密钥时搜索不会降级匿名（提取仅在官方端点走免钥层，自定义端点仍需密钥），搜索面会在派发前被跳过；直接调用搜索适配器返回 `auth`。
- AnySearch 与 Tavily 未配置密钥时走匿名，但匿名额度受限或耗尽会分别表现为 402/432/433 或 429；这不是“密钥无效”，配置密钥即可切换账户额度。
- 知乎的鉴权失败还要检查本机时钟：请求头 `X-Request-Timestamp` 每次现取，服务端校验约 ±10 分钟时间窗。
- 占位符（例如 `ANYSEARCH_API_KEY`、`tvly-YOUR_API_KEY`、`fc-your-key`）会被当作未配置，不会发给服务。
- 在设置页留空密钥草稿会保留已有值，不会清除；要清除请使用宿主凭证管理功能。

## 卸载后出现插件覆盖警告

卸载后出现 `patch: entry "web-search-fetch" not found`，说明本地 patch 仍保留设置页保存的插件覆盖项。按[卸载与回滚](./lifecycle.md)移除该项并检查 `web` 的 provider；保留其它配置与共享凭证。

## 报告问题

提供所安装的插件版本、Node.js 与 DSH 版本、profile 类型、实际工具与错误码（例如 `WEB_PROVIDER_ERROR` 或 `WEB_BLOCKED_URL`）、可复现查询或公开示例 URL。日志先脱敏，不贴密钥、凭证文件或带访问令牌的 URL。安全问题按[安全说明](../SECURITY.md)报告。

## 代码依据

本文的行为口径核对自以下位置（2026-11-09，v0.4.4）：

- 引擎清单、端点、鉴权模式与额度端点：`src/engines/registry.ts`
- 装配、`Config` 默认值、凭证解析与端点覆盖：`src/index.ts`
- 搜索编排、空结果状态、补充检索、额度日检：`src/search/aggregate.ts`
- 查询语法解析与各引擎映射：`src/search/query-syntax.ts`、`src/engines/{anysearch,tavily,firecrawl,zhihu,aihot}.ts`
- 重排 fail-open：`src/search/rerank.ts`
- 熔断冷却与日级恢复：`src/support/breaker.ts`
- 提取分流、两段式、整理与错误分组：`src/fetch/provider.ts`、`src/fetch/aggregate.ts`、`src/fetch/document/organize.ts`
- 地址守卫与 `staticDomains` 豁免代码：`src/support/address-guard.ts`、`src/fetch/route.ts`
