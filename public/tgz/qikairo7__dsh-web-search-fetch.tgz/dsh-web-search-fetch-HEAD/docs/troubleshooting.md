# 排障

先看 [错误码目录](error-catalog.md)，再看设置页的服务开关、凭证状态和额度面板。历史真机证据见 [verification](verification)。

## 快速表

| 现象 | 常见原因 | 处理 |
| --- | --- | --- |
| 设置卡不出现 | 插件未加载或宿主没有 `web` / `credentials` 服务 | 运行 `dsh --profile <profile> --dump-config`，确认 `web-search-fetch` 和两个 `aggregated` provider。 |
| 工具可见但调用失败 | provider 未注册或不可用 | 确认至少一个服务启用且凭证满足；查看 `WEB_PROVIDER_UNAVAILABLE` 详情。 |
| `WEB_PROVIDER_ERROR` | 上游协议、网络或鉴权失败 | 打开设置页额度面板，换一个服务或检查密钥。 |
| `401` / `auth` | 密钥无效或引用名错误 | 重新保存凭证；密钥留空不会清空旧值。 |
| `402` / quota | 账号额度耗尽 | 等待重置，或配置其他服务；AnySearch 与 Tavily 会按规则尝试匿名额度一次。 |
| `429` / rate limited | 上游限流 | 引擎按 `Retry-After` 冷却；无提示时 60 秒，重复触发指数退避。 |
| 知乎时间窗错误 | 本机时钟偏差超过 ±10 分钟 | 校准系统时间后重试。 |
| 空结果 | 查询无匹配、相关性全过滤或覆盖不足 | 去掉过窄操作符；查看结果说明中的逐引擎状态。 |
| `WEB_BLOCKED_URL` | 目标是本机、内网或保留地址 | 守卫不可配置；如目标确为公网，检查 DNS 是否返回内网地址。 |
| 动态页失败但静态页正常 | 页面挑战、登录或目标拒绝引擎 | 更换提取服务或改用可直接访问的 URL。 |
| 结果顺序不变 | SiliconFlow 未配置、关闭或失败 | 重排失败时回退 RRF 序；确认 `rerank.enabled` 与密钥。 |
| 日期过滤不符合预期 | 上游未返回日期 | 未知日期保留但降权；显式窗口只过滤已知窗口外结果。 |
| 设置保存后仍旧行为 | 会话或操作仍使用旧快照 | 下一次调用生效；必要时创建新会话。 |
| 搜索或提取超时 | 上游慢或工具层预算不足 | 提高插件总限时，同时确认 `tool-web` 的工具超时更大。 |

## 检查顺序

1. `dsh --profile <profile> --dump-config`：确认插件与 provider 装载。
2. 设置页：确认服务开关、参与列表、凭证状态和额度。
3. 一次原生调用：分别验证 `web_search` 与 `web_fetch`。
4. 结果说明：查看引擎命中数、缓存年龄、截断、熔断和补派记录。
5. 需要真实复现时使用 `pnpm run smoke:live`，先确认额度消耗。

## 查询语法

语法解析只支持：

```text
site:example.com
-site:example.com
lang:zh
after:2026-01-01
before:2026-12-31
```

不支持原生参数的引擎会逐字回拼操作符。`before:` 是严格早于，`before:2026-01` 表示到 `2025-12-31`。

## 报告问题

普通问题使用 [GitHub Issues](https://github.com/qikairo7/dsh-web-search-fetch/issues)，包含：

- DSH 版本与本插件版本。
- profile 与操作系统。
- 脱敏查询或 URL。
- 错误码、结果说明和复现步骤。

安全问题使用 [私密漏洞报告](https://github.com/qikairo7/dsh-web-search-fetch/security/advisories/new)，不要公开可利用细节。
