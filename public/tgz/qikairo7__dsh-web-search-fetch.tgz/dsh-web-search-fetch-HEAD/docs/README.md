# 文档

常设文档按读者任务组织，不设流程卷宗。历史验收记录是冻结证据，只追加新文件，不改旧结论。

## 用户

| 任务 | 文档 |
| --- | --- |
| 安装与能力总览 | [../README.md](../README.md) |
| 配置服务、凭证、预算、额度 | [configuration.md](configuration.md) |
| 排查错误 | [troubleshooting.md](troubleshooting.md) |
| 理解整理后的正文 | [content-organization.md](content-organization.md) |
| 使用 AIHOT API | [aihot.md](aihot.md) |
| 卸载或回滚 | [lifecycle.md](lifecycle.md) |

## 开发

| 任务 | 文档 |
| --- | --- |
| 搭建环境、修改代码、运行测试 | [development.md](development.md) |
| 理解分层与数据流 | [architecture.md](architecture.md) |
| 核对 DSH 接缝 | [dsh-web-interface.md](dsh-web-interface.md) |
| 新增运行依赖 | [dependency-review.md](dependency-review.md) |
| 查术语 | [glossary.md](glossary.md) |
| 查历史架构决策 | [adr](adr) |
| 参与贡献 | [../CONTRIBUTING.md](../CONTRIBUTING.md) |

## 放置规则

- 使用问题写进 `troubleshooting.md`。
- 行为与架构写进 `architecture.md`。
- 配置字段与语义写进 `configuration.md`。
- 术语写进 `glossary.md`。
- 开发操作写进 `development.md`。
- 难以回退的架构决策写进 `adr/`。
- 真机证据写进 `verification/`，文件名含版本和日期。
- 本机路径、凭证和临时过程只写 `LOCAL.md`，该文件不入库。
