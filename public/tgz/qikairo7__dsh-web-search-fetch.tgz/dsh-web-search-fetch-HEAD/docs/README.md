# 文档索引

新文档先看「放置规则」，写完在本文件登记一行。所有文档简体中文、代码/命令/技术标识保持英文。

## 目录结构与放置规则

```
README.md            用户入口：是什么、怎么装、能力总览、付费基线对照
AGENTS.md            协作路由表（会话开工必读，指向各细则）
CONTRIBUTING.md      贡献流程与提交规范
docs/
  README.md          文档索引与放置规则（本文件）
  development.md     开发规范（分层/反胶水/测试/门禁——写代码前必读）
  dsh-web-interface.md  DSH web 五插件接口手册（工具层/服务层/付费API/设置页/旧版搜索）
  configuration.md   配置参考（Config 全字段 + 预设 + 语法翻译矩阵）
  troubleshooting.md 故障排查口径
  aihot.md           AIHOT 专用 API 与使用规则
  lifecycle.md       安装/卸载生命周期
  content-organization.md / dependency-review.md
                     正文整理规则与运行依赖审阅材料（依赖数据：dependency-inventory.json；冻结的历史评测与对照见 verification/）
  verification/      按版本验收记录 + 冻结的历史评测/GUI/生命周期记录（历史版本冻结不改；命名随历史批次不统一，属历史现状）
  assets/            文档引用的静态资源（截图/演示/数据）
  agents/            多代理协作细则（issue 流程、skill 路由——给代理看的，不是给用户看的）
  adr/               决策记录（ADR-0001：按查询意图路由搜索源的三段式架构）
DESIGN.md            架构说明（分层/管线/决策落位）
GLOSSARY.md          术语表（一词一段一落点）
SECURITY.md / NOTICE 安全承诺与第三方声明（含吸收来源署名）
LESSONS.md           错题本（返工教训，转正规则见文件开头）
LOCAL.md             本机专属（gitignored，不入库）
```

**放置规则**：用户使用问题进 `troubleshooting`；行为与架构进 `DESIGN`；新术语进 `GLOSSARY`；验收证据进 `verification/`（新卷不改旧卷）；工作流给代理的细则进 `docs/agents/`。一次功能更新同步它的所有既有文档面（README 能力表、configuration、GLOSSARY、DESIGN 对应节），这是合并门禁的一部分。

**索引维护**：新文档在本文件目录树与说明区各加一行；删除文档同步删行；`scripts/check-repository.mjs` 与 `scripts/check-wordlist.mjs` 校验链接、公开文件与关键名词表。
