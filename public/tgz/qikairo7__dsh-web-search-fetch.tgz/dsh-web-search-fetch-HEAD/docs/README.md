# 文档

常设文档按读者任务组织，不设流程卷宗。历史验收记录是冻结证据，只追加新文件，不改旧结论。

## 用户

| 任务 | 文档 |
| --- | --- |
| 安装与能力总览 | [../README.md](../README.md) |
| 查服务、端点与默认开关 | [engine-catalog.md](engine-catalog.md) |
| 查全部配置字段 | [config-catalog.md](config-catalog.md) |
| 查错误码 | [error-catalog.md](error-catalog.md) |
| 查看历史验收证据 | [verification/README.md](verification/README.md) |
| 配置服务、凭证、预算、额度 | [configuration.md](configuration.md) |
| 排查错误 | [troubleshooting.md](troubleshooting.md) |
| 理解整理后的正文 | [content-organization.md](content-organization.md) |
| 使用 AIHOT API | [aihot.md](aihot.md) |
| 升级到含破坏性变更的版本 | [upgrade/README.md](upgrade/README.md) |
| 卸载或回滚 | [lifecycle.md](lifecycle.md) |

## 开发

| 任务 | 文档 |
| --- | --- |
| 理解文档层级与写作规则 | [文档标准](AGENTS.md) |
| 搭建环境、修改代码、运行测试 | [development.md](development.md) |
| 理解测试策略 | [testing.md](testing.md) |
| 评审防御规则 | [defensive-patterns/README.md](defensive-patterns/README.md) |
| 理解项目职责、不变量与节点模型 | [foundation.md](foundation.md) |
| 查引擎、端点与默认开关 | [engine-catalog.md](engine-catalog.md) |
| 理解分层与数据流 | [architecture.md](architecture.md) |
| 查自动模块依赖图 | [module-graph.md](module-graph.md) |
| 理解文档驱动开发流程 | [workflow.md](workflow.md) |
| 按任务查找操作指南 | [cookbook/README.md](cookbook/README.md) |
| 新增搜索或提取引擎 | [cookbook/adding-an-engine.md](cookbook/adding-an-engine.md) |
| 新增提取路由 | [cookbook/adding-a-fetch-route.md](cookbook/adding-a-fetch-route.md) |
| 核对 DSH 接缝 | [dsh-web-interface.md](dsh-web-interface.md) |
| 新增运行依赖 | [dependency-review.md](dependency-review.md) |
| 查术语 | [glossary.md](glossary.md) |
| 查历史架构决策 | [adr/README.md](adr/README.md) |
| 参与贡献 | [../CONTRIBUTING.md](../CONTRIBUTING.md) |
| 复盘生产事故 | [postmortem/README.md](postmortem/README.md) |

文档层级、事实归属、写作规则和预算见 [AGENTS.md](AGENTS.md)。本文件只做读者任务索引。
