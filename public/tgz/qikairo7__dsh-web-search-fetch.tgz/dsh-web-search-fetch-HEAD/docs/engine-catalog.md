# 引擎目录

本文件由 `src/engines/registry.ts` 生成，不要手工编辑。运行 `pnpm run generate:engines` 更新。

## 搜索与提取引擎

| id | 名称 | 说明 | 能力 | 鉴权 | 凭证路径 | 默认启用 | 免费额度 | 免密钥 | 免密钥能力面 | 额度周期 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `anysearch` | AnySearch AI | 支持搜索与提取；未配置密钥时使用官方匿名额度。 | 搜索、提取 | 免密钥回退 | `anysearch` | 是 | 是 | 是 | 全部 | 每日（UTC） |
| `tavily` | Tavily | 支持搜索与提取；未配置密钥时使用 keyless 模式。 | 搜索、提取 | 免密钥回退 | `tavily` | 是 | 是 | 是 | 全部 | 每月 |
| `firecrawl` | Firecrawl | 搜索需要密钥；官方端点提取支持免密钥。 | 搜索、提取 | 免密钥回退 | `firecrawl` | 是 | 是 | 是 | 提取 | 每月 |
| `exa` | Exa Search Lite | 需要 Exa API key；只提供 Search Lite 搜索，默认不参与。 | 搜索 | 必须凭证 | `exa` | 否 | 是 | 否 | — | 无 |
| `zhihu` | 知乎 | 需要 Access Secret；提取只处理问题页回答。 | 搜索、提取 | 必须凭证 | `zhihu` | 否 | 否 | 否 | — | 每日（北京时间） |
| `aihot` | AIHOT | 匿名只读 AI 资讯源；搜索覆盖近 7 天。 | 搜索、AIHOT API | 匿名 | — | 是 | 是 | 是 | 全部 | 无 |

## 端点

| id | 搜索 | 提取 | 额度 |
| --- | --- | --- | --- |
| `anysearch` | `https://api.anysearch.com/v1/search` | `https://api.anysearch.com/v1/extract` | — |
| `tavily` | `https://api.tavily.com/search` | `https://api.tavily.com/extract` | `https://api.tavily.com/usage` |
| `firecrawl` | `https://api.firecrawl.dev/v2/search` | `https://api.firecrawl.dev/v2/scrape` | `https://api.firecrawl.dev/v2/team/credit-usage` |
| `exa` | `https://api.exa.ai/search` | — | — |
| `zhihu` | `https://developer.zhihu.com/api/v1/content/global_search` | `https://developer.zhihu.com/api/v1/content/question_answers` | `https://developer.zhihu.com/api/v1/quota` |
| `aihot` | `https://aihot.news/api/v1/items` | — | — |

部分引擎会在适配器内选择子路径或额外端点；上表只列 manifest 登记的主端点，行为见 [configuration.md](configuration.md) 和适配器测试。

## 直接 HTTP

直接 HTTP 是本地静态提取器，不属于 `ENGINE_MANIFESTS`；默认启用，只处理静态文件。

## 重排

SiliconFlow 重排不是搜索引擎，不进入 `ENGINE_MANIFESTS`；它与 `RERANK_SERVICE` 单独配置。

## 校验

运行 `pnpm run check:engines` 校验本文件是否仍与 registry 一致。
