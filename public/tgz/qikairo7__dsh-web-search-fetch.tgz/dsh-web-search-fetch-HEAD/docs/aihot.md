# AIHOT

AIHOT 是匿名只读的 AI 资讯源。启用 `serviceEnabled.aihot` 后，`web_search` 会把最近 7 天的 AI 资讯纳入融合。

专用读取 API 还需要把 `aihot` 加入 `controls.fetchServices`；默认提取列表不包含它。无需密钥、MCP 或额外模型工具。

## Agent 入口

首次使用时可让模型读取：

```text
https://aihot.news/api/v1/agent
```

常用地址：

| 需求 | URL |
| --- | --- |
| 最新精选或全部动态 | `https://aihot.news/api/v1/agent/latest?window=24h&limit=10` |
| 关键词搜索 | `https://aihot.news/api/v1/agent/search?q=DeepSeek&window=7d` |
| 当前热点 | `https://aihot.news/api/v1/agent/hot?limit=10` |
| 事件时间线 | `https://aihot.news/api/v1/agent/stories/{publicId}?limit=20` |
| 日报 | `https://aihot.news/api/v1/agent/daily` 或 `/daily/{date}` |
| 周报 | `https://aihot.news/api/v1/agent/weekly` 或 `/weekly/{week}` |
| 月报 | `https://aihot.news/api/v1/agent/monthly` 或 `/monthly/{month}` |
| Codex 重置 | `https://aihot.news/api/v1/agent/codex-resets` |

`publicId` 来自热点或事件响应，不要猜测。关键词需 URL 编码。Agent Markdown 面按需读取，不注入系统提示。

## JSON API

以下路径均以 `https://aihot.news` 开头：

| 能力 | 路径 |
| --- | --- |
| 资讯 | `/api/v1/items` |
| 热点 | `/api/v1/hot-topics` |
| 事件 | `/api/v1/stories/{publicId}` |
| 日报 | `/api/v1/dailies`、`/latest`、`/{date}` |
| 周报 | `/api/v1/weeklies`、`/latest`、`/{week}` |
| 月报 | `/api/v1/monthlies`、`/latest`、`/{month}` |
| 重置 | `/api/v1/codex-resets`、`/recent` |
| 精选快照 | `/api/v1/selected/snapshot` |
| 精选增量 | `/api/v1/selected/changes` |

返回保留 `publishedAt`、`discoveredAt`、原文链接、站内链接、来源署名、报告引用、分页和增量游标。插件只读取请求的一页，不自动翻页、不写副本、不创建定时任务。结构化 JSON 超过上限时报错，不截断后伪装成功。

## 节奏

- 普通接口默认缓存 60 秒，重置接口 10 分钟。
- 缓存过期后用 ETag 验证；304 复用已验证数据，200 替换数据，失败不回传过期正文。
- `429` 与 `503` 按 `Retry-After` 冷却，不并发重试。
- 缓存与冷却只属于当前插件实例，不是跨进程全局限流器。

## 使用条件

AIHOT 服务规则与本项目 MIT 代码许可相互独立。个人非商业、公益非商业及组织内部使用可按官方规则免费使用；对外商业代理、收费、转售、公开镜像或再分发需书面授权。须保留来源、canonical、attribution 和原文链接。

官方依据：[AIHOT 说明](https://aihot.news/llms.txt)、[OpenAPI](https://aihot.news/openapi-v1.json)、[使用规则](https://aihot.news/terms)。
