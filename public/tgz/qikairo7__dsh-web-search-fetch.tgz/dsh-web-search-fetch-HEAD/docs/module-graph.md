# 模块图

本文件由 `src/**/*.ts` 的相对 import 生成，不要手工编辑。运行 `pnpm run generate:module-graph` 更新。

```mermaid
flowchart LR
  N0["src/engine-priority.ts"]
  N1["src/engines"]
  N2["src/fetch"]
  N3["src/index.ts"]
  N4["src/search"]
  N5["src/support"]
  N0 -->|1| N4
  N1 -->|2| N5
  N2 -->|5| N1
  N2 -->|1| N4
  N2 -->|13| N5
  N3 -->|1| N0
  N3 -->|8| N1
  N3 -->|2| N2
  N3 -->|2| N4
  N3 -->|6| N5
  N4 -->|16| N1
  N4 -->|24| N5
  N5 -->|7| N1
```

| 从 | 到 | 边数 |
| --- | --- | ---: |
| src/engine-priority.ts | src/search | 1 |
| src/engines | src/support | 2 |
| src/fetch | src/engines | 5 |
| src/fetch | src/search | 1 |
| src/fetch | src/support | 13 |
| src/index.ts | src/engine-priority.ts | 1 |
| src/index.ts | src/engines | 8 |
| src/index.ts | src/fetch | 2 |
| src/index.ts | src/search | 2 |
| src/index.ts | src/support | 6 |
| src/search | src/engines | 16 |
| src/search | src/support | 24 |
| src/support | src/engines | 7 |
