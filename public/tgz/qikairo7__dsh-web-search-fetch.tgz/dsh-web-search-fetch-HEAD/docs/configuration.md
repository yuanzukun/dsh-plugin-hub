# 配置

契约以 [`src/index.ts`](../src/index.ts) 为准，服务清单以 [`src/engines/registry.ts`](../src/engines/registry.ts) 为准。完整字段、类型、默认值、约束和说明见 [config-catalog.md](config-catalog.md)。

配置根对象是 volatile 引用。保存后下一次操作生效；正在执行的操作继续使用进入时的快照。

## 字段目录

完整字段由 [config-catalog.md](config-catalog.md) 从 `src/index.ts` 的 `Config` schema 生成；本文件不再维护第二份字段表。凭证字段只保存引用名，实际值由 DSH credentials 解析。

## 自动调用

搜索先由本地结构化信号选择一路；无结果、官方域缺失、调研覆盖不足或 AI 资讯缺少近 7 天时间时，只补派一路。提取先探测一路；短页直接返回，复杂页升级多路整理。

插件不提供固定单通道、全量并发、自定义和免密钥调用预设。免密钥能力仍由各服务自身支持，匿名额度受服务方 IP、限流和账号策略约束。

## 服务与额度

服务、端点、鉴权和额度端点由 [engine-catalog.md](engine-catalog.md) 从 `src/engines/registry.ts` 生成；本文件不再维护第二份服务表。直接 HTTP 是本地静态提取器，不进入 registry。

当前包不内置插件设置页。配置直接写入 DSH profile；旧版本保存的配置仍会继续生效。额度服务只暴露可验证事实：

- Tavily、Firecrawl、知乎显示官方余额或周期。
- AnySearch 与 AIHOT 没有官方额度端点，显示本地估算。
- 只读额度快照不发起请求；显式刷新才发起请求。
- 每引擎刷新超时 10 秒，整次总截止 15 秒。
- 本地账本按日记录成功、限流、额度失败；进程重启后清零。

限流按 `Retry-After` 冷却，无提示时 60 秒；重复触发指数退避，上限 1 小时。额度耗尽熔断到本地次日零点。

搜索入口的每日额度检查只探测已启用且参与搜索的服务；整轮检查总截止 5 秒，超时后继续本轮搜索。

## 查询操作符

| 操作符 | Tavily | Firecrawl | AnySearch | 知乎 / AIHOT |
| --- | --- | --- | --- | --- |
| `site:example.com` | `include_domains` | `includeDomains` | 回拼原文 | 回拼原文 |
| `-site:example.com` | `exclude_domains` | `excludeDomains` | 回拼原文 | 回拼原文 |
| `lang:zh` | `language` | 回拼原文 | `language` | 回拼原文 |
| `after:2026-01` | `start_date` | 回拼原文 | 回拼原文 | 回拼原文 |
| `before:2026-01` | `end_date` | 回拼原文 | 回拼原文 | 回拼原文 |

规则：

- 不支持的操作符按原 token、大小写、路径后缀和顺序回拼。
- `before:` 是严格早于；`before:2026-01` 映射为 `2025-12-31`。
- Tavily 域名包含列表最多 300 个，排除列表最多 150 个；超限报错，不截断。
- Firecrawl 的包含与排除域名互斥；同时出现时全部回拼，不发送域名参数。
- 非法日期不映射，按原文回拼。

## 缓存

插件使用进程内查询缓存。缓存键包含归一查询、意图、`site:` 域名和 `maxResults`，容量 50 条。

| 意图 | TTL |
| --- | --- |
| AI 资讯 / 热点榜单 | 300 秒 |
| 结构化取数 | 900 秒 |
| 调研对比 | 不缓存 |
| 其他意图 | 1,800 秒 |

`after:`、`before:` 或「最新、今天、刚刚、实时」绕过读取。命中结果标注年龄，不消耗请求预算。

## 宿主工具预算

插件预算不覆盖 DSH 工具层超时。实际运行的 `tool-web` 实例应有足够余量：

```yaml
- id: tool-web
  config:
    fetch: true
    searchTimeoutMs: 60000
    fetchTimeoutMs: 90000
```

在 Web profile 中，`tool-web` 可能位于 agent preset 的 `config.plugins` 内。修改实际实例后创建新会话验证。
