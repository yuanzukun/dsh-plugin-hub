# 配置

契约以 [`src/index.ts`](../src/index.ts) 为准，服务清单以 [`src/engines/registry.ts`](../src/engines/registry.ts) 为准。以下为当前默认配置：

```yaml
- id: web-search-fetch
  config:
    controls:
      serviceEnabled:
        anysearch: true
        tavily: true
        firecrawl: true
        zhihu: false
        aihot: true
        http: true
      searchServices: [anysearch, tavily, firecrawl, zhihu, aihot]
      fetchServices: [anysearch, tavily, firecrawl, zhihu]
      maxFetchServices: 4
      maxRequests: 32
      searchDeadlineMs: 15000
      fetchDeadlineMs: 50000
      maxOutputChars: 15000
    rerank:
      enabled: true
      apiKeyEnv: SILICONFLOW_API_KEY
    anysearchApiKeyEnv: ANYSEARCH_API_KEY
    anysearchBaseURL: ''
    anysearchZone: ''
    tavilyApiKeyEnv: TAVILY_API_KEY
    firecrawlApiKeyEnv: FIRECRAWL_API_KEY
    firecrawlBaseURL: ''
    zhihuApiKeyEnv: ZHIHU_API_KEY
```

配置根对象是 volatile 引用。保存后下一次操作生效；正在执行的操作继续使用进入时的快照。

## 调用控制

| 字段 | 范围 | 默认 | 含义 |
| --- | --- | --- | --- |
| `controls.serviceEnabled` | 布尔字典 | registry 默认 | 服务总开关；知乎默认关闭。 |
| `controls.searchServices` | 服务 id 数组 | 五个搜索面 | 参与搜索的服务和候选顺序。 |
| `controls.fetchServices` | 服务 id 数组 | 四个提取面 | 参与动态提取的服务和顺序；静态 HTTP 不受它控制。 |
| `controls.maxFetchServices` | 1–4 | `4` | 单个 URL 最多调用的提取服务数。 |
| `controls.maxRequests` | 1–256 | `32` | 单次操作插件 HTTP 请求上限；多查询共享。 |
| `controls.searchDeadlineMs` | 1–3,600,000 | `15000` | 搜索操作总限时。 |
| `controls.fetchDeadlineMs` | 1–3,600,000 | `50000` | 提取操作总限时。 |
| `controls.maxOutputChars` | 1,000–1,000,000 | `15000` | 搜索来源列表与整理正文输出上限。 |

## 凭证与端点

| 字段 | 默认 | 说明 |
| --- | --- | --- |
| `anysearchApiKeyEnv` | `ANYSEARCH_API_KEY` | 未配置时使用官方匿名额度。 |
| `anysearchBaseURL` | 空 | 完整替换 AnySearch 搜索与提取请求地址。 |
| `anysearchZone` | 空 | `cn` 国内、`intl` 国际；空则不发送。 |
| `tavilyApiKeyEnv` | `TAVILY_API_KEY` | 未配置时使用 keyless 模式。 |
| `firecrawlApiKeyEnv` | `FIRECRAWL_API_KEY` | 搜索必需；官方端点提取可免钥。 |
| `firecrawlBaseURL` | 空 | 代理或自定义 Firecrawl 基地址。 |
| `zhihuApiKeyEnv` | `ZHIHU_API_KEY` | 启用知乎时必需。 |
| `rerank.enabled` | `true` | 未解析到 SiliconFlow 密钥时不会调用。 |
| `rerank.apiKeyEnv` | `SILICONFLOW_API_KEY` | SiliconFlow 凭证引用。 |

密钥值由 DSH credentials 管理。配置只保存引用名；留空的设置页输入框不会清空已有密钥。

## 自动调用

搜索先由本地结构化信号选择一路；无结果、官方域缺失、调研覆盖不足或 AI 资讯缺少近 7 天时间时，只补派一路。提取先探测一路；短页直接返回，复杂页升级多路整理。

插件不提供固定单通道、全量并发、自定义和免密钥调用预设。免密钥能力仍由各服务自身支持，匿名额度受服务方 IP、限流和账号策略约束。

## 服务与额度

| 服务 | 搜索端点 | 提取端点 | 额度端点 |
| --- | --- | --- | --- |
| AnySearch | `https://api.anysearch.com/v1/search` | `https://api.anysearch.com/v1/extract` | 无 |
| Tavily | `https://api.tavily.com/search` | `https://api.tavily.com/extract` | `https://api.tavily.com/usage` |
| Firecrawl | `https://api.firecrawl.dev/v2/search` | `https://api.firecrawl.dev/v2/scrape` | `https://api.firecrawl.dev/v2/team/credit-usage` |
| 知乎 | `global_search` / `zhihu_search` / `hot_list` / 直答 | `question_answers`，仅问题页 | `https://developer.zhihu.com/api/v1/quota` |
| AIHOT | `https://aihot.news/api/v1/items` | `https://aihot.news/api/v1/*` 专用只读 API | 无 |
| HTTP | — | DSH HTTP 提取器 | — |

额度面板只显示可验证事实：

- Tavily、Firecrawl、知乎显示官方余额或周期。
- AnySearch 与 AIHOT 没有官方额度端点，显示本地估算。
- 打开设置页只读缓存快照；点击「刷新额度」才发起请求。
- 每引擎刷新超时 10 秒，整次总截止 15 秒。
- 本地账本按日记录成功、限流、额度失败；进程重启后清零。

限流按 `Retry-After` 冷却，无提示时 60 秒；重复触发指数退避，上限 1 小时。额度耗尽熔断到本地次日零点。

搜索入口的每日额度检查只探测已启用且参与搜索的服务；整轮检查总截止 5 秒，超时后继续本轮搜索。

## 查询操作符

| 操作符 | Tavily | Firecrawl | AnySearch | 知乎 / AIHOT |
| --- | --- | --- | --- | --- |
| `site:example.com` | `include_domains` | `includeDomains` | 回拼原文 | 回拼原文 |
| `-site:example.com` | `exclude_domains` | `excludeDomains` | 回拼原文 | 回拼原文 |
| `lang:zh` | `language` | 回拼原文 | `language` | 回拼原文 |
| `after:2026-01` | `start_date` | 回拼原文 | 回拼原文 | 回拼原文 |
| `before:2026-01` | `end_date` | 回拼原文 | 回拼原文 | 回拼原文 |

规则：

- 不支持的操作符按原 token、大小写、路径后缀和顺序回拼。
- `before:` 是严格早于；`before:2026-01` 映射为 `2025-12-31`。
- Tavily 域名包含列表最多 300 个，排除列表最多 150 个；超限报错，不截断。
- Firecrawl 的包含与排除域名互斥；同时出现时全部回拼，不发送域名参数。
- 非法日期不映射，按原文回拼。

## 缓存

插件使用进程内查询缓存。缓存键包含归一查询、意图、`site:` 域名和 `maxResults`，容量 50 条。

| 意图 | TTL |
| --- | --- |
| AI 资讯 / 热点榜单 | 300 秒 |
| 结构化取数 | 900 秒 |
| 调研对比 | 不缓存 |
| 其他意图 | 1,800 秒 |

`after:`、`before:` 或「最新、今天、刚刚、实时」绕过读取。命中结果标注年龄，不消耗请求预算。

## 宿主工具预算

插件预算不覆盖 DSH 工具层超时。实际运行的 `tool-web` 实例应有足够余量：

```yaml
- id: tool-web
  config:
    fetch: true
    searchTimeoutMs: 60000
    fetchTimeoutMs: 90000
```

在 Web profile 中，`tool-web` 可能位于 agent preset 的 `config.plugins` 内。修改实际实例后创建新会话验证。
