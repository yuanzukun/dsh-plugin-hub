# 配置参考

本页是 v0.4.5 的全部配置面。契约以 [`src/index.ts`](../src/index.ts) 的 `Config` schema 为准，服务清单、能力、鉴权模式、端点与默认开关以 [`src/engines/registry.ts`](../src/engines/registry.ts) 为准，发行默认配置见 [`cordis.patch.yml`](../cordis.patch.yml)。插件以 `web-search-fetch` 注册，向 `ctx.web` 注册两个 id 为 `aggregated` 的 provider（搜索与提取各一）；`web_search` / `web_fetch` 工具由 DSH 提供。

示例展示发行默认配置的完整形状。未配置的可选字段使用 schema 默认值；字符串字段用空串表示「使用官方端点」，不要写 YAML `null`。

```yaml
- id: web-search-fetch
  config:
    controls:
      preset: auto
      serviceEnabled:
        anysearch: true
        tavily: true
        firecrawl: true
        zhihu: false
        aihot: false
        http: true
      searchServices: [anysearch, tavily, firecrawl, zhihu, aihot]
      fetchServices: [anysearch, tavily, firecrawl, zhihu]
      maxSearchServices: 5
      maxFetchServices: 4
      maxRequests: 32
      searchDeadlineMs: 15000
      fetchDeadlineMs: 50000
      maxOutputChars: 15000
    rerank:
      enabled: true
      apiKeyEnv: SILICONFLOW_API_KEY
    anysearchApiKeyEnv: ANYSEARCH_API_KEY
    tavilyApiKeyEnv: TAVILY_API_KEY
    firecrawlApiKeyEnv: FIRECRAWL_API_KEY
    zhihuApiKeyEnv: ZHIHU_API_KEY
    anysearchBaseURL: ''
    # anysearchZone: 'cn'      # 可选：'cn' 国内 / 'intl' 国际；缺省或空串不发送该字段
    firecrawlBaseURL: ''
```

## 顶层字段

`controls` 之外的字段如下。凭证引用字段使用 `credential-ref` 角色，写入的是引用名而不是密钥值。

| 路径 | 类型 | 默认值 | 约束 | 说明 |
| --- | --- | --- | --- | --- |
| `rerank.enabled` | 布尔 | `true` | — | SiliconFlow 重排开关；未配置密钥时自动不启用。 |
| `rerank.apiKeyEnv` | 字符串（credential-ref） | `SILICONFLOW_API_KEY` | — | 重排密钥引用名。 |
| `anysearchApiKeyEnv` | 字符串（credential-ref） | `ANYSEARCH_API_KEY` | — | `anysearch` 凭证引用。 |
| `anysearchBaseURL` | 字符串 | 空 | — | 端点覆盖；空串使用官方端点。 |
| `anysearchZone` | `'cn'` 或 `'intl'` | 空（不发送） | 二选一 | AnySearch 搜索区域偏好；空串与未设置等价，不发送 zone 字段。 |
| `tavilyApiKeyEnv` | 字符串（credential-ref） | `TAVILY_API_KEY` | — | `tavily` 凭证引用。 |
| `firecrawlApiKeyEnv` | 字符串（credential-ref） | `FIRECRAWL_API_KEY` | — | `firecrawl` 凭证引用。 |
| `firecrawlBaseURL` | 字符串 | 空 | — | 端点覆盖；空串使用官方端点。 |
| `zhihuApiKeyEnv` | 字符串（credential-ref） | `ZHIHU_API_KEY` | — | `zhihu` 凭证引用。 |

## 凭证与启用范围

密钥由 DSH credentials 服务在每次操作开始时异步解析，不缓存；轮换后的下一次操作即生效。配置文件和仓库只保存引用名，不保存密钥值。

| 服务 id | 显示名 | 能力 | 鉴权模式 | 默认凭证引用 | 发行默认开关 | 免费标记 |
| --- | --- | --- | --- | --- | --- | --- |
| `anysearch` | AnySearch AI | 搜索、提取 | keyless-fallback | `ANYSEARCH_API_KEY` | 开 | 是 |
| `tavily` | Tavily | 搜索、提取 | keyless-fallback | `TAVILY_API_KEY` | 开 | 是 |
| `firecrawl` | Firecrawl | 搜索、提取 | keyless-fallback（仅提取免钥） | `FIRECRAWL_API_KEY`（`fc-` 密钥） | 开 | 是 |
| `zhihu` | 知乎 | 搜索、提取 | key | `ZHIHU_API_KEY`（Access Secret） | 关 | 否 |
| `aihot` | AIHOT | AI 资讯搜索、专用读取 API | anonymous | 无 | 关 | 是 |
| `http` | 直接 HTTP 抓取 | 静态资源提取 | anonymous | 无 | 开 | 是 |

- **keyless-fallback（AnySearch、Tavily、Firecrawl）**：未配置密钥时按官方匿名/公共额度请求；配置了密钥则走账户模式。AnySearch 与 Tavily 的搜索、提取两个面都支持匿名；Firecrawl 只有提取（scrape）面走官方 keyless free tier，搜索面缺密钥时不发请求并报 `auth`。密钥已配置但失效时报 `auth` 失败，不会静默降级匿名。账号额度耗尽（`quota` 失败）时例外：搜索面同一路在同一 deadline 与请求预算内去掉密钥、按匿名额度重试一次，并在处理说明中标注（只对 search 面确实免钥的引擎生效）；`auth` 失败不降级。
- **key（知乎）**：必须配置密钥，搜索与问题回答提取都使用 `Authorization: Bearer <Access Secret>` 与秒级 `X-Request-Timestamp`。装配层在派发前按凭证就绪跳过缺少有效凭证的引擎；适配器本身在缺少密钥时不发请求，直接返回 `auth` 失败。Firecrawl 的搜索面同样需要密钥（按能力面就绪判定），提取面在官方端点走 keyless-fallback（自定义端点仍需密钥）。
- **anonymous（AIHOT、直接 HTTP）**：没有凭证位，也不读密钥。
- **免费标记与 `free` 预设不是同一概念**：`free` 位描述「免费额度型」服务；`free` 预设按 `keyless`（免密钥）过滤并按能力面收窄。Firecrawl 的提取面免钥、参与 `free` 的提取；搜索面需要密钥，不进入 `free` 的搜索面。
- **重排密钥**：`rerank.apiKeyEnv` 默认 `SILICONFLOW_API_KEY`；未配置时重排静默跳过，不影响搜索。

知乎搜索请求使用 `Authorization: Bearer <Access Secret>` 与秒级 `X-Request-Timestamp`，服务端校验时间窗。

以下字面量即使写入凭证位也视同未配置，不会被当成真钥发送：`ANYSEARCH_API_KEY`、`TAVILY_API_KEY`、`FIRECRAWL_API_KEY`、`ZHIHU_API_KEY`、`SILICONFLOW_API_KEY`、`as_sk_your_key`、`tvly-YOUR_API_KEY`、`fc-your-key`。

`controls.serviceEnabled` 是服务总开关（包括 `http`）。未写的服务取 registry 的 `enabledByDefault`：`zhihu`、`aihot` 默认关，`anysearch`、`tavily`、`firecrawl` 默认开，`http` 恒开；显式写入的开关覆盖默认值。发行默认配置关闭知乎与 AIHOT。关闭一个服务会停止它的全部能力，但不清除凭证、参与列表或端点覆盖，重新开启后沿用原配置。关闭 `http` 后，静态 URL 返回 `WEB_PROVIDER_ERROR`，不会自动改走其他提取服务。

## 调用控制

`controls` 是每次操作读取的运行时快照。整个 `Config` 是根级 volatile 实时引用：装配层只保留引用；`controls` 在操作入口读取一次，凭证与端点在首次 lane 读取并在同一操作的并发 lane 间共享，`ready`、区域与垂直目录按调用时读取最新值。设置页保存后下一次操作生效，不重挂插件或重启 profile。进行中的操作继续使用它开始时读取的控制快照。

| 字段 | 类型 | 默认值 | 约束 | 说明 |
| --- | --- | --- | --- | --- |
| `serviceEnabled` | 布尔字典 | 由 registry 派生 | — | 服务总开关；未写的服务取 registry 的 `enabledByDefault`，显式写入覆盖默认值；关闭后不派发该服务。 |
| `preset` | 枚举 | `auto` | `auto` / `single` / `multi` / `custom` / `free` | 调用范围策略。 |
| `searchServices` | 字符串数组 | `anysearch`、`tavily`、`firecrawl`、`zhihu`、`aihot` | — | 搜索参与列表；数组顺序即同轮派发优先级；有意图映射时该顺序仅作成员资格过滤，不决定派发优先级。 |
| `fetchServices` | 字符串数组 | `anysearch`、`tavily`、`firecrawl`、`zhihu` | — | 提取参与列表；直接 HTTP 静态路径不受它控制。zhihu 只处理 `zhihu.com/question/*`，其他 URL 不发请求。 |
| `maxSearchServices` | 正整数 | `5` | 1–5 | 每个查询首轮最多派发的搜索服务数。 |
| `maxFetchServices` | 正整数 | `4` | 1–4 | 每个 URL 最多派发的提取服务数。 |
| `maxRequests` | 正整数 | `32` | 1–256 | 每次操作的插件 HTTP 请求上限。 |
| `searchDeadlineMs` | 正整数 | `15000` | 1–3,600,000 | 搜索操作总限时（毫秒）。 |
| `fetchDeadlineMs` | 正整数 | `50000` | 1–3,600,000 | 提取操作总限时（毫秒）。 |
| `maxOutputChars` | 正整数 | `15000` | 1,000–1,000,000 | 搜索与单页整理输出上限（字符）；搜索按 title+snippet 估算，整理含来源与处理说明。 |

语义要点：

- `searchServices` / `fetchServices` 只接受对应能力的 id；空数组会禁用该面派发，并最终以 `WEB_PROVIDER_ERROR` 报「没有可用通道」。列表顺序决定同一轮内的派发优先级；搜索命中意图映射时，`searchServices` 的顺序仅作成员资格过滤，不决定派发优先级。服务能力与默认名单来自 registry。
- 搜索的首轮上限之外，单通道空结果补派会再选一轮，可能使一次操作接触的服务数超过 `maxSearchServices`；补派仍受 `maxRequests` 约束。
- `maxRequests` 统计搜索、提取、额度查询、重排与重试发出的每个插件 HTTP 请求。直接 HTTP 静态路径由宿主组件自行抓取，不经过这份预算记账；AIHOT 缓存命中不发请求，也不消耗预算。预算耗尽时，未发出的请求按失败处理并写入操作说明。
- 两个总限时到期时返回已完成结果并标记 `truncated`；没有任何可用结果时分别返回 `WEB_SEARCH_TIMEOUT` / `WEB_FETCH_TIMEOUT`。调用方主动取消始终返回 `WEB_ABORTED`。
- `maxOutputChars` 同时约束搜索与整理输出：搜索侧按候选的 title+snippet 字符数从尾部裁剪来源，置 `truncated` 并记省略条数；整理侧按完整内容块省略，不裁断代码围栏与段落；结构化 JSON／XML 超预算直接报错。提取侧的静态 HTTP、AIHOT 专用 API 与 `single` 预设返回的原文不受它裁剪。
- 正文处理模式固定为整理；配置面不暴露模式字段。

## 意图路由

`auto` 预设先由 [`router.ts`](../src/search/router.ts) 的本地确定性规则判定查询意图，再在装配层映射为来源顺序；路由器只判意图，不点名引擎。判定顺序即优先级：裸热点 → AI 资讯 → 社区观点 → 结构化取数 → 调研对比 → 英文网页 → 中文网页（默认）。

| 意图 | 判定线索（示例） | 来源顺序与行为 |
| --- | --- | --- |
| `hot-list` 热点榜单 | 「今天有什么新闻」「热榜」「热搜」等裸热点查询（剥除平台与填充词后没有主题；微博热搜等平台专属榜单除外） | 知乎 `hot_list` 优先，AIHOT `/api/v1/hot-topics` 兜底；命中时直接取榜单，不再发查询词 |
| `ai-news` AI 资讯 | AI/大模型/LLM/常见模型与厂商名 + 新闻/资讯/发布/进展/事件词；带热点词时取热点榜 | AIHOT 优先；不带热点词时走近 7 天资讯搜索 |
| `community-opinion` 知乎观点 | 知乎、怎么看、如何评价、经验 | 知乎优先；搜索同时并发调用知乎直答，答案进 `content`，失败静默跳过 |
| `vertical-data` 结构化取数 | 股价/财报/GDP/CPI/论文/专利/CVE/判例/航班/招聘/微博/Reddit 等 39 个垂直 tag | AnySearch 优先并下发 tag；tag 先校验存在性与必填参数，不合法按查询语言回落通用路由 |
| `research` 调研对比 | 对比、比较、综述、调研、盘点 | 不点名来源，按参与范围与 registry 顺序多路（上限 `maxSearchServices`） |
| `english-web` 英文网页 | 无 CJK 且含拉丁字母；开发者词细分 | 通用网页 Tavily→Firecrawl；开发者资料 Firecrawl→Tavily |
| `chinese-web` 中文网页 | 其余中文查询 | 知乎优先，其余来源按 registry 顺序排后 |

### 宽度与回落

- 宽度归预设：`auto` 仅 `research` 与 `ai-news` 多路，其余意图单路；`single` / `multi` / `custom` 覆盖自动宽度；`free` 另按免密钥过滤。
- 垂直目录：`GET /v1/domains` 与 `GET /v1/sub-domains` 每 24 小时刷新一次，装配层单次发现超时 5 秒，请求计入 `maxRequests`；校验 tag 是否存在、官方 `required` 参数是否齐全。缺失或目录不可用时记说明并按查询语言（含 CJK 为中文，否则英文）回落通用路由。
- 有界降级：垂直或热榜路由没有来源、也没有结构化 `content` 时，按查询语言换通用路由重试一次，排除已派发引擎；限流、额度、超时、取消不重试，每操作至多一次，受剩余预算与总限时约束。没有可降级通道时只记说明。

### 热榜与直答

- 知乎热榜 `hot_list` 每日 100 次（平台口径），返回榜单条目；AIHOT `hot-topics` 匿名、最多 10 条，作为热点意图的兜底。热榜路由直接返回榜单，不再带查询词。
- 知乎直答 `zhida` 每日 100 次（平台口径），仅在知乎观点意图、知乎引擎参与且凭证就绪时调用；与主搜索并发，答案写入结果 `content`，超时、失败、预算耗尽均静默跳过。
- 知乎额度端点只汇总 `global_search` 与 `zhihu_search`，不覆盖热榜与直答。热榜走独立 lane，其结局按成功/限流/额度失败进入本地额度账本；直答不单独入账，随知乎搜索 lane 的结局记录，直答自身失败静默跳过。

## 调用预设

| 预设 | 宽度与行为 |
| --- | --- |
| `auto` | 搜索消费意图路由：`research` / `ai-news` 多路（上限 `maxSearchServices`），其余意图单路；垂直/热榜路由另有有界降级。提取先做首路探测，不足再升级多路整理。 |
| `single` | 首轮恰好 1 路；首轮唯一一路成功但无相关结果时可补派一次多路。搜索不追加官方域补充检索；提取原样返回该路正文（不加来源标记、不受 `maxOutputChars` 裁剪）。该路失败时直接报错。 |
| `multi` | 在参与列表与总开关允许的服务中，按 `maxSearchServices` / `maxFetchServices` 并发派发。 |
| `custom` | 按总开关、参与列表与各项上限执行，不额外套用自动规则；宽度取同一上限。 |
| `free` | 按 registry 的 `keyless` 过滤并按能力面收窄：AnySearch、Tavily（搜索与提取）、AIHOT（需先启用，搜索）+ 直接 HTTP 静态抓取，以及 Firecrawl 的免钥提取面；Firecrawl 搜索仍需密钥，不进入 free 的搜索面；知乎不参与。 |

自动档的官方文档意图由 [`quality.ts`](../src/search/quality.ts) 的本地规则判定：显式 `site:`，或查询含「官方/文档/规范/official/documentation/docs/specification」且点名 Python、TypeScript、Node.js、JavaScript/MDN 相关对象、React、Rust、Go 时，映射到对应官方文档站。补充检索最多取两个官方域名，与该轮搜索并发，计入同一个 `maxRequests`；显式 `single` 或查询含 `site:` / `-site:` 时不追加。同一服务的补充查询不增加 RRF 票数。

中文查询含「政府」「政策」或「官方指南」时，主题匹配的 `gov.cn` 及其子域作为排序权威域参与官方优先与域名多样性豁免。该规则不追加搜索请求，也不改变自动档宽度。

预设只决定宽度与免密钥过滤；装配层另按凭证就绪跳过缺少有效凭证的 key 引擎，因此它们不会被选中。适配器本身在无密钥直接调用时仍返回 `auth`。

## 查询缓存

仅 `auto` 预设读写查询缓存；显式预设、显式日期操作符与不缓存意图直接绕过。

| 意图 | TTL |
| --- | --- |
| `ai-news`、`hot-list` | 300 秒 |
| `vertical-data` | 900 秒 |
| `research` | 不缓存 |
| `community-opinion`、`english-web`、`chinese-web` | 1,800 秒 |

- 缓存键 = 归一查询（去首尾空白、连续空白折叠）+ 意图 + `site:` 域名（排序后）+ `maxResults`；容量 50 条，LRU 淘汰，进程内有效。
- 读取绕过：显式预设（非 `auto`）、带 `after:` 或 `before:`、查询含「最新/今天/刚刚/实时」。写入不因「强制最新」绕过，但只在 `auto`、无日期操作符、TTL > 0 且最终结果有来源时写入。
- 命中返回原结果并在 `content` 前置 `（缓存命中，age N 秒）`；命中不产生上游请求，也不计入 `maxRequests`。
- 无来源的结果不写缓存（含仅结构化 `content` 的垂直结果），避免一次偶发空返回固定一个 TTL。

## 查询语法翻译（AD13）

搜索编排层先用 [`query-syntax.ts`](../src/search/query-syntax.ts) 把 DeepSeek 风格操作符解析为结构化字段，再下发给引擎。引擎原生支持就映射为参数，不支持就逐字回拼。

### 解析规则

- 按空白切分；识别 `site:`、`-site:`、`lang:`、`after:`、`before:` 五种操作符。
- `site:` / `-site:` 的值必须是至少带一个点的域名；可带路径后缀，解析值会转小写并剥掉路径。值不合法时原 token 留在普通查询文本里，不视为操作符。
- `lang:` 接受两个字母的语言码，也接受逗号分隔的多个语言码。
- `after:` / `before:` 接受 `YYYY`、`YYYY-MM`、`YYYY-MM-DD`。
- 引号短语与普通 `-词` 不解析，原样留在 `bareQuery`。`bareQuery` 的空白折叠为单空格。

### 映射矩阵

| 操作符 | Tavily | Firecrawl | AnySearch | 知乎 | AIHOT |
| --- | --- | --- | --- | --- | --- |
| `site:example.com` | `include_domains` | `includeDomains` | 回拼 raw | 回拼 raw | 回拼 raw |
| `-site:example.com` | `exclude_domains` | `excludeDomains` | 回拼 raw | 回拼 raw | 回拼 raw |
| `lang:zh` | `language` + `filter_by_language: true` | 回拼 raw | `language` | 回拼 raw | 回拼 raw |
| `after:2026-01` | `start_date` | 回拼 raw | 回拼 raw | 回拼 raw | 回拼 raw |
| `before:2026-01` | `end_date` | 回拼 raw | 回拼 raw | 回拼 raw | 回拼 raw |

Tavily 的日期会先规范化：`after:2026` → `2026-01-01`，`after:2026-01` → `2026-01-01`，完整日期做日历校验后原样；`before` 是严格早于：`before:2026` → `2025-12-31`，`before:2026-01` → `2025-12-31`，`before:2026-10` → `2026-09-30`。知乎按查询文本选择搜索面：含「知乎」或 `zhihu.com`（大小写不敏感）走站内 `zhihu_search`，否则走全网 `global_search`；面选择使用原查询，回拼不改变面选择。

### 六条裁决

1. **不支持就逐字回拼**：`operators[]` 保留每个操作符的原 token，包括大小写、路径后缀与出现顺序；不支持的项按原顺序接在 `bareQuery` 之后，不静默丢弃或改写。
2. **`before` 严格语义**：`before:YYYY-MM` 取上一个月最后一日，不把该月算进范围；与 `after` 的「含起始日」语义对称。
3. **域名超限报 `invalid`**：Tavily 的 `include_domains` 上限 300、`exclude_domains` 上限 150；超限时整条请求失败，不截断放宽用户的过滤意图。
4. **Firecrawl 域名互斥**：`site:` 映射 `includeDomains`，`-site:` 映射 `excludeDomains`；两者同时出现时契约无法表达，双方都按 raw 回拼且不发任何域名参数。`tbs` 虽有字段，但契约未细化编码，v0.3 不发明，`lang/after/before` 同样回拼。
5. **纯操作符查询不为空**：操作符全部移除或全部映射后组合文本为空时，退回原始查询文本，避免向引擎发空串。
6. **完整日期做日历校验**：非法日期（如 2 月 30 日）不映射，按 unsupported 逐字回拼。

## 额度与熔断

### 额度来源

| 服务 | 额度端点 | 报告字段 | 无密钥或不可用时 |
| --- | --- | --- | --- |
| Tavily | `GET /usage` | `key.limit` 为 null 时回退 `account.plan_limit`/`account.plan_usage` 配对；`remaining` 按同级配对计算；`key.limit` 与 `plan_limit` 均为显式 null 才表示不限；`raw` 附 `current_plan` | keyless 模式返回 N/A，不发请求（`/usage` 必须带 key） |
| Firecrawl | `GET /v2/team/credit-usage` | `remaining` = `remainingCredits`；`limit` = `planCredits`；`resetsAt` = `billingPeriodEnd` | 无密钥返回 N/A（keyless 免费层不支持额度端点），不发请求 |
| 知乎 | `GET /api/v1/quota` | 汇总 `global_search` 与 `zhihu_search` 两项的 `TotalUsed` / `TotalQuota` / `RemainingQuota`；不含热榜、直答与问题发现额度 | 无搜索额度项时返回 N/A |
| AnySearch | 无额度端点 | — | N/A |
| AIHOT | 无额度端点 | — | N/A |

额度探测是只读请求，不产生搜索或提取调用。知乎契约明确额度查询不消耗业务额度；Tavily 与 Firecrawl 的额度端点同样只读取用量。额度探测本身计入 `maxRequests`。

### 额度面板与手动刷新

设置卡「额度」小节逐引擎显示五行：AnySearch、Tavily、Firecrawl、知乎、AIHOT；直接 HTTP 不进面板。每行由官方快照仓的最近结果、本地额度账本的当日计数、服务开关与凭证状态组成，服务名沿用服务列表的 i18n 文案。

官方侧只有四种单结果（每行只显示其中一种）：

| 状态 | 显示 |
| --- | --- |
| 引擎没有官方额度端点（AnySearch、AIHOT） | 「估算」，不伪造数字 |
| 有端点、本次运行尚未取到快照 | 「未刷新」 |
| 取到可用快照 | 数值与周期文案：Tavily、Firecrawl 标注「月额度」；知乎标注「今日搜索」并注明「搜索两池合计，不含热榜/直答」 |
| 快照不可用或探测失败 | 原因原文（如 keyless 自述、「凭证服务不可用」、探测超时） |

服务停用时显示「已停用（未探测）」；本地账本三项计数全零时显示「今日未使用」。面板不自动轮询：打开设置页只读取快照仓，点击「刷新额度」才发起探测。

手动刷新语义：

- 探测对象 = 已启用且实现 `quota()` 的引擎（Tavily、Firecrawl、知乎）；停用与无端点引擎零请求。
- 单飞：同一引擎的并发刷新共享同一次在途探测，连续点击不叠加请求。
- 硬超时：每引擎 10 秒，整次刷新总截止 15 秒；超时的行显示原因，不阻塞其他引擎。
- 刷新以返回的完整快照直接更新面板，不再补发一次 `get()`；刷新期间按钮禁用。
- 官方快照 `available && remaining > 0` 时调用 `clearDaily` 解除该引擎当日的额度熔断并发恢复事件；`remaining <= 0` 继续喂入日级熔断；`rate-limit` 冷却不受影响。
- 本版不注册 `/quota` 斜杠命令：T0 已完成命令样板验证，因额度数据通道（客户端直调 `connection.rpc`，宿主侧 Typert 服务经 Gateway 提供端点）可用而保留为后备，不在装配层注册。

### 本地额度账本（估算）

- 每引擎按本地日记录成功、限流、额度失败次数；跨日清零，进程内有效。
- 同一本地日额度型失败达到 2 次即视为「本地耗尽」：后续选源跳过该引擎；搜索与提取共用同一账本（同一上游账号额度共享）。
- 这是对上游余额的估算，不是官方快照：只表示本地连续观察到额度失败；跨日或上游恢复后重新观察。无额度端点的源（AnySearch、AIHOT）只以本地计数参与判断。
- 账本不伪造剩余量：无额度端点的源在当日首次日检说明中标注「本地计数为估算」；官方快照与本地观察互补。

### 日检

- 每次搜索操作在选源之前执行日检；只有已启用且实现了 `quota()` 的引擎会被探测（Tavily、Firecrawl、知乎）。
- 同一 provider 实例每个本地日至多探测一次：先标记当天已检，再逐个探测；单个探测失败只记日志，不阻塞搜索，也不会让管道整天重试。
- 每个额度探测的单路限时为 10 秒，并受操作总限时约束。
- 返回 `remaining <= 0` 时，向该引擎喂入 `quota-exhausted`，熔断到本地次日零点；日检先于选源，因此当轮即跳过该引擎。
- 无额度端点的启用源在当日首次日检说明中标注为估算。日检正常 resolve 的官方快照（含显式 N/A）经 `onQuotaReport` 写入快照仓，供额度面板读取；抛错路径不上报。额度查询不自动轮询：搜索操作触发日检，设置页仅在打开时读快照、点击「刷新额度」时手动探测。

### 额度耗尽自动匿名

- 仅 `keyless-fallback` 引擎（AnySearch、Tavily）：带密钥调用返回 `quota` 失败时，同一次操作内用去掉 `apiKey` 的同一引擎上下文重试一次匿名请求。
- 重试仍在原 lane、原 deadline 与同一 `maxRequests` 预算内，只发生一次；说明行「额度耗尽，改用匿名额度。」进入 `content`。
- `auth`（密钥无效）、`rate-limited`、`invalid`、`timeout` 等失败不降级；`key` 与 `anonymous` 引擎没有这条路径。

### 熔断

搜索与提取共用同一个进程内熔断器，键为引擎 id；进程重启即清零。

- **限流冷却**：`rate-limited` 按 `Retry-After` 冷却，缺省 60 秒。冷却中再次触发按提示值 × 2^(连续次数−1) 指数退避，封顶 1 小时；提示值小于等于 0 时撤销冷却。
- **日级熔断**：`quota` 失败断到下一个本地零点；HTTP 402 归为 `insufficient-credits`，其余额度失败归为 `quota-exhausted`，恢复时间相同。日级熔断优先于冷却，当日重复信号幂等。
- **日级解除**：官方快照 `available && remaining > 0` 时，手动刷新调用 `clearDaily` 删除该引擎当日的日级条目并发恢复事件；`rate-limit` 冷却不受影响。
- 只有 `rate-limited` 与 `quota` 会喂入熔断。`auth`、`invalid`、`target-status`、`timeout`、`network` 不会把引擎移出轮换。
- 熔断状态惰性结算：没有定时器，下一次查询发现已过期时发出恢复事件并重新参与派发。
- 被熔断的引擎在派发前跳过；搜索与提取都会在操作说明或日志中记录跳过。全部引擎都不可用时返回 `WEB_PROVIDER_ERROR`。

## 端点与传输

| 服务 | 搜索端点 | 提取端点 | 额度端点 |
| --- | --- | --- | --- |
| AnySearch | `https://api.anysearch.com/v1/search` | `https://api.anysearch.com/v1/extract` | — |
| Tavily | `https://api.tavily.com/search` | `https://api.tavily.com/extract` | `https://api.tavily.com/usage` |
| Firecrawl | `https://api.firecrawl.dev/v2/search` | `https://api.firecrawl.dev/v2/scrape` | `https://api.firecrawl.dev/v2/team/credit-usage` |
| 知乎 | `https://developer.zhihu.com/api/v1/content/global_search` | — | `https://developer.zhihu.com/api/v1/quota` |
| AIHOT | `https://aihot.news/api/v1/items` | `/api/v1/*` 专用读取 API（仅 `aihot.news`） | — |
| 直接 HTTP | — | 由 DSH 的 HTTP 提取组件执行 | — |

只有两个端点覆盖字段：

- `anysearchBaseURL`：替换请求 URL 本身，不追加 `/v1/search` 或 `/v1/extract`。该值同时用于搜索与提取，因此自定义代理必须能按同一地址处理两种请求。留空使用 registry 端点。
- `firecrawlBaseURL`：可填完整端点，也可填代理域名或前缀。适配器按操作补全或替换 `/v2/search`、`/v2/scrape`、`/v2/team/credit-usage` 路径；传入本插件的另一个操作端点时，保留其 origin/前缀并只替换已知路径。留空使用官方端点。

`anysearchZone` 不是端点字段：`'cn'` 偏好国内结果、`'intl'` 偏好国际结果，直接写入搜索请求体；空串与未设置等价，均不发送该字段。设置页提供「默认（不发送）/ 国内 / 国际」三档选择。

Tavily、知乎、AIHOT 没有端点覆盖字段。自定义端点会把密钥发送到该地址，只应配置可信 API；自定义端点也不再属于官方匿名额度。插件对引擎 API 请求固定拒绝 HTTP 重定向（`redirect: 'error'`），避免额外请求绕过计数或把鉴权信息转交其他端点；自定义端点应填写最终 API 地址。

直接 HTTP 静态路径使用宿主组件的固定上限：响应体 5,000,000 字节、正文 100,000 字符、单请求 30 秒、最多 5 次重定向、默认 User-Agent。该路径不消耗插件请求预算，但受提取操作总限时约束。

地址守卫在所有第三方提取引擎与 AIHOT 专用 API 之前执行：字面地址直接判定，主机名先解析，任一答案为回环、私网、链路本地、保留、运营商级 NAT、唯一本地或转换/隧道前缀时，以 `WEB_BLOCKED_URL` 拒绝且不派发；解析失败不拦截。守卫固定启用，不提供豁免配置。

## 限制与预算语义

### 搜索

一次搜索的可观察流程：

1. 读取控制快照，判定查询意图；`auto` 预设先查查询缓存，命中直接返回。
2. 过滤已熔断引擎；对已启用且实现 `quota()` 的引擎执行本地日检（在选源之前），并用本地额度账本跳过当日估算耗尽的源。
3. 垂直取数先经 AnySearch 目录校验（存在性与必填参数）；不合法按查询语言回落通用路由并记说明。
4. 按意图映射排序来源，再按预设、总开关、参与列表、`free` 的免密钥过滤、凭证就绪与 `maxSearchServices` 选源；日检后再次过滤已熔断引擎。
5. 热点/热榜意图且映射序内有引擎具备 `hotTopics` 时直接取榜单（知乎 `hot_list` 优先，AIHOT `hot-topics` 兜底）；否则普通派发。官方文档意图追加最多两次限定域名检索（显式 `single` 或查询含 `site:` / `-site:` 时除外）。
6. 并发派发，每路固定 10 秒限时；宽限窗口在「足够结果」出现后 500 毫秒起、随启动时间递减、最多 1200 毫秒内收掉未完成渠道。
7. 按 URL 归一、上游分组去重（同组只留排名最好的一路）与 RRF 融合，`k = 60`；相同 URL 合并为一候选，字段择优（更长 snippet 胜，缺失字段补齐），再做相关性过滤。
8. 有界降级：垂直/热榜路由没有来源也没有结构化 `content` 时，按查询语言换通用路由重试一次；排除已派发引擎，限流、额度、超时、取消不重试，每操作至多一次。
9. 单通道（显式 `single`，或 `auto` 判为单通道）首轮无相关结果时，补派一次多路：排除已派发服务，按开关、参与列表、`maxSearchServices` 与剩余请求预算选择；失败、超时、取消或限流的路不补派，预算不足时不补派并写明原因。补派只发生一次。
10. 有 SiliconFlow 密钥且重排开启时，对融合后的前 30 个候选（title + snippet，单条截断到 1,000 字符）重排；超时 5 秒。成功时在说明中标记；未配置密钥时静默跳过；失败时按融合序返回并记 note，不阻塞搜索。
11. 输出治理：官方来源优先排序后，每域默认至多保留 2 条（主题匹配的官方文档域与中文政府权威域豁免，记省略数），按宿主 `maxResults` 截断（工具层默认 8，插件不提供该配置），再用 `maxOutputChars` 按 title+snippet 从尾部裁剪并记省略数；说明附引擎×命中数与耗时（前 3）。答案（知乎直答等）与处理说明合并进 `content`。

搜索结果的 `truncated` 在任一条件成立时为真：宽限窗口提前结束、操作总限时到期、任一成功引擎报告截断、排序后候选数超过 `maxResults`、或搜索输出预算裁剪。零结果时返回逐路状态说明（空返回、全被相关性过滤、限流、额度耗尽、超时、取消、熔断跳过），并区分「查询无解」与「覆盖不足」。

### 提取

- 操作总限时默认 50 秒；多路整理的每路固定 45 秒；自动预设的首路探测与 `single` 预设的唯一一路固定 15 秒。探测与单通道路都由 deadline 竞速，引擎即使忽略中止信号也会在到期时被丢弃。
- 分流顺序：地址守卫 → AIHOT 专用 API → 静态/动态路由。静态路由命中条件：URL 不可解析或非 HTTP(S)、主机在静态域名表（当前为空）、路径末段扩展名属于内置表。内置扩展名：`txt`、`text`、`xml`、`json`、`md`、`markdown`、`csv`、`tsv`、`rss`、`atom`、`yaml`、`yml`、`log`、`ini`、`toml`、`ics`、`vtt`、`srt`。其余（包括 PDF、HTML、无扩展名）走动态提取。
- 静态路只允许单次 HTTP 抓取。非 2xx 且正文为空时报 `WEB_BLOCKED_URL`，不伪装成空白成功页；非 2xx 但有正文按结果返回。
- 自动预设先探测第一路：结果需为 2xx、返回目标与请求目标一致（允许同资源 HTTP→HTTPS 升级）、不是登录/挑战页、段落不少于 400 字符。满足则直接返回原文；超过 `maxOutputChars` 时交给整理器按完整内容块省略并标 `truncated`。不足则升级多路整理，已取得的结果并入候选，不重复请求同一引擎。
- `single` 预设原样返回唯一一路正文，即使很薄或超过输出预算也不裁剪、不加来源标记；该路失败直接报错。
- `multi` / `custom` / `free` 不做首路探测，直接多路整理。
- 多路整理在至少三路返回同标题、共享长段落且各有不少于 1,200 字符段落正文时提前结束宽限窗口；宽限规则与搜索相同。整理输出受 `maxOutputChars` 约束，补充片段单条最多 1,200 字符、整节最多 4,000 字符；清单类表格先裁到前 20 行、最多 4,000 字符。
- 提取结果的 `truncated` 在宽限提前结束、整理输出超预算、操作总限时到期或任一路超时时为真。
- AIHOT 专用 API 命中时优先于通用提取，原样返回 Markdown 或 JSON，不进入正文整理，也不受 `maxOutputChars` 裁剪。

## AIHOT 可选 AI 资讯源

AIHOT 是匿名只读的垂直资讯源，无凭证位、无额度端点。启用方式：打开 `serviceEnabled.aihot`（或在设置页打开开关）。搜索覆盖最近 7 天，查询长度为 2–200 个 Unicode 字符，单次最多 100 条；请求参数固定 `mode=all`、`window=7d`，关键词为原始查询按操作符规则回拼后的文本。普通结果接口按 URL 缓存 60 秒，重置接口至少 10 分钟；429/503 按 `Retry-After` 冷却，不并发重试。

专用读取 API（热点、事件、日报、周报、月报、重置记录、精选快照与增量）还要求把 `aihot` 加入 `controls.fetchServices`（默认提取列表不含它）。它只接管 `https://aihot.news/api/v1/*` 的文档化只读路径；`/api/v1/agent` 返回 Markdown，其余路径返回完整 JSON。路径与示例见 [AIHOT 接入](./aihot.md)。用途限于个人非商业、公益与组织内部；对外代理、收费或再分发需书面授权。

## 设置页

设置页绑定 `web-search-fetch` 条目，写入以下路径：`controls.preset`、`controls.searchServices`、`controls.fetchServices`、`controls.serviceEnabled`、六个数值限制、`anysearchBaseURL`、`anysearchZone`、`firecrawlBaseURL`、`rerank.enabled`，以及五个凭证位（AnySearch、Tavily、Firecrawl、知乎、SiliconFlow）。正文处理固定显示「整理正文」，不提供模式切换。

保存后下一次操作读取新快照，无需重启或重挂插件；端点覆盖、`anysearchZone` 与 `rerank.enabled` 同样走实时引用。正在执行的操作继续使用原有预算与配置快照。密钥留空表示保留现值；保存成功不回显密钥，只显示配置状态。凭证状态只表示「已配置」，不代表 API 认证或服务健康。直接 HTTP 抓取没有凭证位。

匿名起步只对未配密钥仍可请求的服务成立：AnySearch 与 Tavily 走官方匿名额度，Firecrawl 的提取面走官方 keyless free tier；Firecrawl 搜索仍需 `fc-` 密钥，未配置时搜索路不参与派发。`free` 预设按同一免密钥口径并按能力面过滤（AnySearch、Tavily、AIHOT + 直接 HTTP，以及 Firecrawl 提取面），而不是按「免费额度」标记。设置页不自动轮询额度：打开时只读取官方快照仓，点击「刷新额度」才在设置页内探测；搜索操作仍会在选源之前按本地日执行日检。面板四态与刷新语义见「额度面板与手动刷新」。

## 工具超时配置

插件只配置自己的单路与操作总预算，不覆盖宿主工具层。宿主 `web_search` / `web_fetch` 的调用超时另算，应给实际运行的 `tool-web` 实例留足余量。例如（字段名以所用 DSH 版本为准）：

```yaml
- id: tool-web
  config:
    fetch: true
    searchTimeoutMs: 60000
    fetchTimeoutMs: 90000
```

在 Web profile 中，工具实例可能位于 agent preset 的 `config.plugins` 内。应修改实际实例的配置，并创建会话确认生效；只读 `--dump-config` 不能证明当前会话已经使用新预算。
