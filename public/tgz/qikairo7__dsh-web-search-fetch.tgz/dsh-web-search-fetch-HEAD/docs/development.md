# 开发指南

本文只保留能直接执行的工程约定。架构和数据流见 [architecture.md](architecture.md)，测试策略见 [testing.md](testing.md)，新增引擎见 [cookbook/adding-an-engine.md](cookbook/adding-an-engine.md)，新增提取路由见 [cookbook/adding-a-fetch-route.md](cookbook/adding-a-fetch-route.md)。

## 环境

| 工具 | 版本 |
| --- | --- |
| Node.js | `^22.19.0 || >=24.0.0` |
| pnpm | `12.10.1` |
| DSH | `>=0.2.2-rc.1` |

```sh
git clone https://github.com/qikairo7/dsh-web-search-fetch.git
cd dsh-web-search-fetch
pnpm install --frozen-lockfile
pnpm run hooks:install
pnpm run check
```

## 命令

提交前可用 `pnpm run change-scope -- --base <verified-base>` 查看按变更面选择的验证建议。

| 目的 | 命令 |
| --- | --- |
| 构建、测试、类型检查、仓库检查与生成物校验 | `pnpm run check` |
| 查看变更面和建议检查 | `pnpm run change-scope -- --base <verified-base>` |
| 校验文档治理 | `pnpm run check:docs` |
| 安装本地 Git hooks | `pnpm run hooks:install` |
| 生成引擎目录 | `pnpm run generate:engines` |
| 生成配置目录 | `pnpm run generate:config` |
| 生成错误码目录 | `pnpm run generate:errors` |
| 生成 DSH 接口字段 | `pnpm run generate:dsh-interface` |
| 生成架构模块图 | `pnpm run generate:module-graph` |
| 校验架构模块图 | `pnpm run check:module-graph` |
| 查询 npm 依赖安全公告 | `pnpm run check:advisories` |
| 冻结验收证据 | `pnpm run freeze:verification` |
| 冻结已归档 Note | `pnpm run freeze:archived` |
| 校验引擎目录 | `pnpm run check:engines` |
| 校验配置目录 | `pnpm run check:config` |
| 校验错误码目录 | `pnpm run check:errors` |
| 校验冻结证据 | `pnpm run check:freeze` |
| 校验源码中的文档引用 | `pnpm run check:doc-refs` |
| 校验文档中的 TypeScript 代码块 | `pnpm run check:doc-types` |
| 校验文档中的 Mermaid 语法 | `pnpm run check:mermaid` |
| 校验文档索引与 kind | `pnpm run check:doc-index` |
| 校验公共入口导出的 JSDoc | `pnpm run check:exports` |
| 校验 DSH 接口字段快照 | `pnpm run check:dsh-interface` |
| 校验 Skill 调用元数据 | `pnpm run check:skills` |
| 校验依赖清单与锁文件 | `pnpm run check:deps` |
| 校验包与文档版本一致 | `pnpm run check:version` |
| 校验发布包资产 allowlist | `pnpm run check:package` |
| 编译到 `lib/` | `pnpm run build` |
| 运行测试 | `pnpm test` |
| 运行覆盖率门禁 | `pnpm run check:coverage` |
| 运行单个测试 | `pnpm exec vitest run test/search/router.test.ts` |
| 检查源码与测试类型 | `pnpm run typecheck` |
| 检查公开文件、文档、源码引用、依赖、版本与源码行数 | `pnpm run check:repository` |
| 检查分发产物 | `pnpm run check:distribution` |
| 本机挂载 | `pnpm run build && dsh plugin --profile <profile> add link:<absolute-path>` |
| 手动宿主验收 | `pnpm run acceptance:host -- --profile <profile>`；只安装候选包并读取配置，不发起外部请求 |
| 真实调用 | `pnpm run smoke:live`，先取得付费额度确认 |
| 发布候选包 | `pnpm run pack:candidate` |

## 结构

```text
src/index.ts       插件装配、Config、凭证、默认参与列表、provider 注册
src/engine-priority.ts 装配层的意图 → 引擎候选顺序
src/engines/       引擎适配；registry.ts 是服务清单唯一事实源
src/search/        查询分析、证据、选源、派发、融合、重排、输出
src/fetch/         地址分流、ExtractionAttempt、两段式提取、多路正文整理
src/support/       预算、熔断、额度、单路结算、URL 归一、地址守卫
docs/engine-catalog.md 由 registry 生成的引擎、端点与默认开关目录
docs/config-catalog.md 由 Config 生成的字段、默认值与约束目录
docs/error-catalog.md 由 src 中的 WEB_* 字面量生成的错误码目录
scripts/           构建、检查与基准脚本
test/              离线测试
lib/               Git 跟踪的构建产物，不手改
```

## 编码

- 采用最小完整改动：单次使用的逻辑就近写，第二个调用点出现后再抽象。
- TypeScript strict、NodeNext ESM、目标 ES2023；相对 import 带 `.js` 后缀。
- `src/**/*.ts` 每个文件不超过 500 行；`pnpm run check:repository` 强制检查。
- 编排层不认识具体引擎：`src/search/`、`src/fetch/`、`src/support/` 不 import 具体适配器，不写引擎 id。
- 服务端点、鉴权、能力面、额度周期和默认开关只写在 `src/engines/registry.ts`。
- 引擎目录由 registry 生成；数量限制与凭证位以 Config 为准。
- 引擎边界统一返回 `EngineFailure`；目标站失败与引擎失败不混用。
- 任一层截断输出都置 `truncated: true` 并继续向上传播。
- 外部输入只在边界校验；类型系统已保证的内部值不重复判空。
- 不加防御分支、配置项或抽象来覆盖无人报告的极端场景。

## 测试

测试层级、模拟边界和证据要求见 [testing.md](testing.md)。日常命令见上表。

## 本地 hooks

`pnpm run hooks:install` 把 `core.hooksPath` 指向 `.githooks`。pre-commit 运行空白检查、`check:generated`、暂存一致性检查、生成物暂存检查、`check:docs` 和 `check:repository`；pre-push 运行 `check` 和 `check:distribution`。hooks 只减少反馈延迟，CI 仍拥有完整矩阵。

## 提交

1. 完成 实现、测试和受影响文档。
2. 运行 `pnpm run check`。
3. 改过 `src/` 时暂存重建后的 `lib/`，再跑 `pnpm run check:distribution`。
4. 本地提交。
5. 真实调用、GitHub 外发、合并 `main` 和发布按 [AGENTS.md](../AGENTS.md) 先取得确认。
