# 开发指南

本文只保留能直接执行的工程约定。架构和数据流见 [architecture.md](architecture.md)。

## 环境

| 工具 | 版本 |
| --- | --- |
| Node.js | `^22.19.0 || >=24.0.0` |
| pnpm | `12.10.1` |
| DSH | `>=0.2.2-rc.1` |

```sh
git clone https://github.com/qikairo7/dsh-web-search-fetch.git
cd dsh-web-search-fetch
pnpm install --frozen-lockfile
pnpm run check
```

## 命令

提交前可用 `pnpm run change-scope -- --base <verified-base>` 查看按变更面选择的验证建议。

| 目的 | 命令 |
| --- | --- |
| 构建、测试、类型检查、仓库检查 | `pnpm run check` |
| 查看变更面和建议检查 | `pnpm run change-scope -- --base <verified-base>` |
| 校验文档治理 | `pnpm run check:docs` |
| 编译到 `lib/` | `pnpm run build` |
| 运行测试 | `pnpm test` |
| 运行单个测试 | `pnpm exec vitest run test/search/router.test.ts` |
| 检查源码与测试类型 | `pnpm run typecheck` |
| 检查公开文件、文档与源码行数 | `pnpm run check:repository` |
| 检查分发产物 | `pnpm run check:distribution` |
| 本机挂载 | `pnpm run build && dsh plugin --profile <profile> add link:<absolute-path>` |
| 真实调用 | `pnpm run smoke:live`，先取得付费额度确认 |
| 发布候选包 | `pnpm run pack:candidate` |

## 结构

```text
src/index.ts       插件装配、Config、凭证、默认参与列表、provider 注册
src/engine-priority.ts 装配层的意图 → 引擎候选顺序
src/engines/       引擎适配；registry.ts 是服务清单唯一事实源
src/search/        查询分析、证据、选源、派发、融合、重排、输出
src/fetch/         地址分流、ExtractionAttempt、两段式提取、多路正文整理
src/support/       预算、熔断、额度、单路结算、URL 归一、地址守卫
client/index.js    设置页客户端；静态服务表面由测试钉住
scripts/           构建、检查与基准脚本
test/              离线测试
lib/               Git 跟踪的构建产物，不手改
```

## 编码

- 采用最小完整改动：单次使用的逻辑就近写，第二个调用点出现后再抽象。
- TypeScript strict、NodeNext ESM、目标 ES2023；相对 import 带 `.js` 后缀。
- `src/**/*.ts` 每个文件不超过 500 行；`pnpm run check:repository` 强制检查。
- 编排层不认识具体引擎：`src/search/`、`src/fetch/`、`src/support/` 不 import 具体适配器，不写引擎 id。
- 服务端点、鉴权、能力面、额度周期和默认开关只写在 `src/engines/registry.ts`。
- 设置页服务表、额度周期、数量限制与凭证位以 `client/index.js` 为准；`test/client-surface.test.ts` 钉住它与 registry / Config 的一致性。
- 引擎边界统一返回 `EngineFailure`；目标站失败与引擎失败不混用。
- 任一层截断输出都置 `truncated: true` 并继续向上传播。
- 外部输入只在边界校验；类型系统已保证的内部值不重复判空。
- 不加防御分支、配置项或抽象来覆盖无人报告的极端场景。

## 测试

- 默认离线：注入 fetcher、DNS lookup 或固定响应，不访问真实服务。
- 新增非平凡逻辑配一条能失败的测试；纯文案、不可观察内部重构不强行加测试。
- Bug 修复先找到可复现点，断言只认报告点名的单一结果。
- 行为测试尽量从 provider 生产入口出发；私有函数直测只作补充。
- 架构边界由 `test/architecture.test.ts` 强制。

## 提交

1. 完成 实现、测试和受影响文档。
2. 运行 `pnpm run check`。
3. 改过 `src/` 时暂存重建后的 `lib/`，再跑 `pnpm run check:distribution`。
4. 本地提交。
5. 真实调用、GitHub 外发、合并 `main` 和发布按 [AGENTS.md](../AGENTS.md) 先取得确认。
