# 新增引擎

本指南把一个外部服务接入 registry、文档和测试。先读 [foundation.md](../foundation.md)、[architecture.md](../architecture.md) 和 [testing.md](../testing.md)。

## 步骤

1. 新建 `src/engines/<id>.ts`，实现 `search`、`fetch` 或 `quota`。
2. 在 `src/engines/registry.ts` 声明唯一 manifest：`id`、`label`、`summary`、能力、鉴权、凭证路径、默认开关、额度周期和端点；把新引擎加进 `EngineRegistryDeps` 与 `buildEngines`。
3. 在 `src/index.ts` 注入适配器和凭证。
4. 运行 `pnpm run generate:engines` 生成 `docs/engine-catalog.md`；如果新增了 Config 字段，再运行 `pnpm run generate:config` 更新配置目录。
5. 添加 `test/engines/<id>.test.ts`，覆盖成功、失败和边界；把 id 加进 `test/architecture.test.ts` 的引擎清单。
6. 运行 `pnpm run check`；改过 `src/` 后提交重建的 `lib/`，再运行 `pnpm run check:distribution`。
7. 如果新增引擎涉及长期取舍、失败语义或公共契约，按 [workflow.md](../workflow.md) 写 Agent Note 或 ADR。

## 验收

- registry 与生成目录显示同一个 id、能力和默认开关。
- 搜索与提取编排层不需要为具体引擎改名或加分支。
- 离线测试覆盖成功、失败、超时或取消中的适用路径。
- `pnpm run check` 和 `pnpm run check:distribution` 通过；未运行项如实列出。

## 不做

- 不在 README 或配置文档手写第二份服务表。
- 不为新引擎改 `src/search/` 或 `src/fetch/` 的具体引擎分支。
- 不把真实调用、凭据或临时报告写进公开源码。
