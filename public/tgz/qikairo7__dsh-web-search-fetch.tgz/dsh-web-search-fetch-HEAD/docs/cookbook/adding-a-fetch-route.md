# 新增提取路由

本指南处理 URL 进入 `web_fetch` 之后的路线变化。先区分四种需求：

| 需求 | 入口 |
| --- | --- |
| 新增可直取的静态扩展名 | `src/fetch/route.ts` 的 `DEFAULT_STATIC_EXTENSIONS` |
| 新增专用只读 API（如 AIHOT） | `DedicatedApiReader` + `src/index.ts` 的 `apiReaders` |
| 新增分流分支（静态/动态之外） | `FetchRoute`、`classifyFetchRoute`、provider 分支；改变公共行为先写 ADR |
| 新增外部提取引擎 | 按 [adding-an-engine.md](adding-an-engine.md) |

所有路线先经过地址守卫；不得在路由或 provider 里绕过。

## 静态扩展名

1. 在 `src/fetch/route.ts` 的 `DEFAULT_STATIC_EXTENSIONS` 加扩展名。
2. 在 `test/fetch/route.test.ts` 加大小写、查询串和锚点用例。
3. 确认该类型确实由内置 HTTP 提取器直接读取；PDF、HTML 和未知页面默认继续走动态路。

## 专用只读 API

当前 provider 用 `aihot-api` 能力位识别专用 API 面；新增非 AIHOT API 时，先把能力位改成通用名称或新增能力位，并同步 registry、client 和测试。

1. 在引擎适配器旁实现 `DedicatedApiReader`：`engineId` 固定，`readApi(url, ctx)` 只接管自己声明的 URL；不匹配返回 `undefined`。
2. 读取器使用 `EngineContext` 的 `signal`、`deadline`、`endpoint`、`apiKey` 和 `countRequest()`；不直接读全局配置。
3. 上游非 2xx 若是可表示的资源状态，返回带 `statusCode` 的 `WebFetchResult`；传输、格式或版本错误上抛路由化 `WebError` 或统一失败。
4. 在 `src/index.ts` 把读取器加入 `apiReaders`；provider 会应用服务开关、`fetchServices`、熔断和 `ready` 凭证门控。
5. 在 `test/fetch/provider.test.ts` 覆盖：命中 API、未命中回退、服务关闭、熔断、缓存结果不重复结算。
6. 如果读取器有缓存，实现 `isCached`，并保证缓存结果不重复计入额度或熔断。

## 新增分流分支

1. 先写 ADR 或 proposed Agent Note，说明为什么现有 `static` / `dynamic` 不够。
2. 扩展 `FetchRoute` 和 `classifyFetchRoute`，保持纯函数；不在路由里发网络请求。
3. 在 `AggregatedFetchProvider.fetchOperation` 加显式分支；新分支仍使用 `ExtractionAttempt`、`LaneSettlement` 和统一 `WEB_*` 错误。
4. 更新 `test/fetch/route.test.ts`、`test/fetch/provider.test.ts` 和必要的 `test/fetch/aggregate.test.ts`。
5. 更新 [architecture.md](../architecture.md)、[foundation.md](../foundation.md) 和 [dsh-web-interface.md](../dsh-web-interface.md) 的 owning 段落。

## 验收

- URL 分类有能失败的离线测试；专用 API 的未命中路径确实回退。
- 地址守卫在任何第三方请求之前运行。
- 多路整理和首路探测仍受 `maxOutputChars` 约束；专用 API 读取器使用自己的文本上限和 API 契约。
- `pnpm run check` 通过；改过 `src/` 后提交重建的 `lib/`，再运行 `pnpm run check:distribution`。
- 真实服务行为变化时，先取得付费额度确认，并把证据写入 `docs/verification/`。
