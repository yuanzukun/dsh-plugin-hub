# Cookbook

按任务组织的操作指南。每个指南给出步骤和验证入口；设计理由放在 ADR 或 Agent Note。

| 任务 | 指南 |
| --- | --- |
| 新增搜索或提取引擎 | [adding-an-engine.md](adding-an-engine.md) |
| 新增提取路由 | [adding-a-fetch-route.md](adding-a-fetch-route.md) |
