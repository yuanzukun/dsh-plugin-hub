# 测试策略

本文定义测试层级、模拟边界和证据要求；命令和日常流程见 [development.md](development.md)。测试必须能失败，并通过可观察结果证明行为。

## 层级

### 离线单元测试

- `pnpm test` 运行 `test/` 下的 Vitest 测试。
- 默认不访问真实服务；注入 fetcher、DNS lookup、时钟或固定响应。
- 行为测试尽量从 provider 生产入口出发；私有函数直测只作补充。
- 架构边界由 `test/architecture.test.ts` 强制。
- 测试文件属于 `test/`，不把临时报告写进公开源码。

### 真实调用

- `pnpm run smoke:live` 只用于真实服务验证；先说明服务、预算和目的并取得付费额度确认。
- 真实调用记录写入 `docs/verification/`，文件名含版本和日期；旧记录只追加，不改结论。
- 凭据、认证头和 credential-bearing URL 不进入记录、日志或公开文件。

### 文档与生成物

- `pnpm run check:docs` 校验 Agent Note、Skill 元数据、行数与字符预算、来源、Mermaid 语法、段落换行、ADR 格式、冻结清单、文档索引/kind 和文档中的 TypeScript 代码块。
- `pnpm run check:repository` 校验公开文件、链接、标题、源码注释引用、公共入口导出 JSDoc、依赖清单、版本一致性和源码行数。
- `pnpm run check:engines` 校验引擎目录与设置页服务块，`pnpm run check:config` 校验配置目录，`pnpm run check:errors` 校验错误码目录；三者都要求与源码一致。
- `pnpm run check:freeze` 校验 [验收证据](verification/README.md) 和已归档 Note 的冻结清单；新增记录后运行 `pnpm run freeze:verification` 或 `pnpm run freeze:archived`。
- `pnpm run check:doc-types` 编译文档中的 `ts` fence；`pnpm run check:doc-refs` 校验源码注释里的文档路径，`pnpm run check:deps` 校验依赖清单，`pnpm run check:version` 校验包、README 和 DSH 接缝版本。
- `pnpm run check:dsh-interface` 校验 [DSH 接口字段快照](dsh-web-interface-fields.json) 与已安装类型一致。
- `pnpm run check:skills` 校验 Skill 的 Claude/Codex 调用策略；当前项目没有 `agents/openai.yaml`，因此没有活动配对。
- `pnpm run check:module-graph` 校验 [模块图](module-graph.md) 与 `src` 的相对 import 一致。
- `pnpm run check:advisories` 查询 npm Registry 的依赖公告；它需要网络，放在 CI 的依赖审计步骤，不进入离线 `check`。

## 规则

- 新增非平凡逻辑配一条能失败的离线测试。
- Bug 修复先找到可复现点，断言只认报告点名的单一结果。
- 断言外部状态或返回的失败对象；不信任 Agent 自报的“通过”。
- 覆盖取消、超时、部分成功和清理路径；不把 sleep 当同步。
- 测试拥有的资源在成功、失败、超时和重试后都释放。
- 纯文案、不可观察内部重构不强行加测试。
- 未运行的检查写成未运行，并把缺口写进交付说明。
- `pnpm run check:coverage` 用 V8 覆盖率运行行为测试 `test/**/*.test.ts`，并检查全局阈值：语句 85%、分支 80%、函数 90%、行 90%。它不追求 DSH 的 per-file 100%，也不把覆盖率数字当成行为正确性的唯一证据。

## 选择范围

- 提交前先运行 `pnpm run change-scope -- --base <verified-base>`。
- 普通改动运行 `pnpm run check`。
- 改 `src/` 后提交重建的 `lib/`，并运行 `pnpm run check:distribution`。
- 跨模块、公共接口、数据、生产或安全变化时，按 `change-scope` 的建议扩大检查。
