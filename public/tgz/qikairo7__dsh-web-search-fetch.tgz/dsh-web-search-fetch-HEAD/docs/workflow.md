# 文档驱动开发流程

本仓库用“当前契约 + 决策记录 + 可执行证据”约束开发。文档不是过程记录；它描述 `HEAD` 上真实存在的行为、限制和验证入口。

## 分层

| 材料 | 职责 |
| --- | --- |
| [AGENTS.md](../AGENTS.md) | 每次会话都需要遵守的短规则 |
| [README.md](README.md) | 文档入口和放置规则 |
| [architecture.md](architecture.md) | 当前架构和模块边界 |
| [adr](adr) | 已发布的架构决策 |
| [Agent Notes](../.agents/notes/README.md) | 开发流程决策，以及尚未提升为 ADR 的实施决策 |
| [development.md](development.md) | 环境、命令和日常验证 |
| `.agents/skills/` | 可复用的工作流入口 |

架构决策最终写入 `docs/adr/`。Agent Note 用于提案、实施中的取舍和流程决策；当一个决策成为长期架构契约时，在同一变更中提炼为 ADR，并在 Note 中链接它。

## Agent Note 生命周期

```text
proposed → implemented
proposed → rejected
implemented → archived
```

- `proposed/` 保存未实施提案，必须写清问题、方案、备选、验收条件和风险。
- `implemented/` 保存已落地决策，必须用现在时描述实际结果、备选和后果。
- `rejected/` 保存被否决的提案，防止重复走弯路。
- `archived/` 保存仍有历史价值但不再指导当前工作的实现记录；归档后不改内容。

只有会长期影响仓库行为、维护义务或验证策略的决策才写 Note。机械修改、局部实现和小 UI 调整不写。

## 变更闭环

1. 读取 [AGENTS.md](../AGENTS.md) 和受影响文档。
2. 判断是否需要 `proposed` Note 或 ADR。
3. 修改代码、测试和受影响文档，保持三者同一个变更。
4. 运行 `pnpm run change-scope -- --base <verified-base>` 获取验证建议。
5. 只执行能覆盖本次变更面的检查，不重复已通过的检查。
6. PR 描述记录动机、变更、证据、风险和 AI 参与阶段。
7. 实施后把提案 Note 改写为 `implemented`，或把架构契约提炼进 ADR。

## 文档规则

- 一个事实只有一个归属；其他位置只链接。
- 当前状态用现在时；历史只放在 ADR、Note、提交和验收记录中。
- 操作命令必须来自实际运行或项目脚本，不凭记忆编写。
- 当前源码、测试和常设文档只引用仓库内文件或官方来源；不得把 `.scratch` 研究文件当作当前事实源。
- 脚本注释描述当前行为；不写版本迁移、旧验收编号或任务图节点。
- 代码、配置、错误、公共行为和测试证据变更时，同步更新 owning 文档。
- 删除推理过程、评审对话、会话编号和“这次修改了什么”的叙述。
- `pnpm run check:docs` 校验 Agent Note、Skill 元数据和文档预算。

## 本地材料

- `.scratch` 是可丢弃工作区；不提交内容，也不把它当作当前契约来源。
- `.agents/worktrees/` 只存放本机会话 worktree；不进入仓库，也不参与公开源码检查。
- 研究克隆、旧基准输出、旧包体、临时测试报告和已结束 spike 在任务收尾时删除或送入回收站。
- `dev-loop/` 只保留仍被脚本读取的凭证、仍被冻结验收记录引用的证据，以及尚在当前任务中的材料。
- 本机路径、凭证和临时过程写 `LOCAL.md`，该文件不入库。

## Skill 路由

| 任务 | Skill |
| --- | --- |
| 创建或晋升 Agent Note | `agent-note-lifecycle` |
| 文档结构与事实归属 | `doc-governance` |
| 中文技术 prose 和契约覆盖 | `prose-contracts` |
| 清理过程叙述 | `trim-process-leakage` |
| 规则优先的 diff 评审 | `rule-first-review` |
| 选择最小充分验证 | `change-evidence` |
| PR 记录与 AI 参与声明 | `pr-record` |
| 寻找可删除的维护义务 | `find-simplifications` |
| 设计失败与恢复语义 | `failure-contracts` |
| 网络与外部服务测试可靠性 | `test-reliability` |
| 设计模型可见接口和 Skill | `agent-interface` |
| 选择项目工作流入口 | `ask-project` |
