# 文档驱动开发流程

本仓库用“当前契约 + 决策记录 + 可执行证据”约束开发。文档不是过程记录；它描述 `HEAD` 上真实存在的行为、限制和验证入口。

## 入口

每次会话先读根 [AGENTS.md](../AGENTS.md)。文档层级、事实归属和写作规则见 [docs/AGENTS.md](AGENTS.md)；产品不变量见 [foundation.md](foundation.md)；实现分层见 [architecture.md](architecture.md)；测试策略见 [testing.md](testing.md)。

架构决策最终写入 `docs/adr/`。Agent Note 用于提案、实施中的取舍和流程决策；当一个决策成为长期架构契约时，在同一变更中提炼为 ADR，并在 Note 中链接它。

## Agent Note 生命周期

```text
proposed → implemented
proposed → rejected
implemented → archived
```

- `proposed/` 保存未实施提案，必须写清问题、方案、备选、验收条件和风险。
- `implemented/` 保存已落地决策，必须用现在时描述实际结果、备选和后果。
- `rejected/` 保存被否决的提案，防止重复走弯路。
- `archived/` 保存仍有历史价值但不再指导当前工作的实现记录；归档后不改内容。

只有会长期影响仓库行为、维护义务或验证策略的决策才写 Note。机械修改、局部实现和小 UI 调整不写。

## 变更闭环

1. 读取根 [AGENTS.md](../AGENTS.md)、[docs/AGENTS.md](AGENTS.md) 和受影响文档。
2. 判断是否需要 `proposed` Note 或 ADR。
3. 修改代码、测试和受影响文档，保持三者同一个变更。
4. 运行 `pnpm run change-scope -- --base <verified-base>` 获取验证建议。
5. 按 [testing.md](testing.md) 选择能覆盖本次变更面的检查，不重复已通过的检查。
6. PR 描述记录动机、变更、证据、风险和 AI 参与阶段。
7. 实施后把提案 Note 改写为 `implemented`，或把架构契约提炼进 ADR。

PR 模板是评审载体，本地检查不验证其内容质量；模板要求的证据仍需在 PR 中实际填写。

## 文档规则

文档层级、事实归属、写作规则、生成物处理和预算见 [AGENTS.md](AGENTS.md)。本文件只定义变更流程。

## 与 DSH 的对应

本项目的文档驱动方案沿用 DSH 的机制，不复制其仓库规模定制的基础设施。

| DSH 材料 | 本项目 |
| --- | --- |
| 根 `AGENTS.md` + `docs/AGENTS.md` | 根 [AGENTS.md](../AGENTS.md) 放短规则，[docs/AGENTS.md](AGENTS.md) 放文档层级、写作和预算 |
| `architecture.md` / `subsystems/` | [foundation.md](foundation.md) 固定产品契约，[architecture.md](architecture.md) 固定实现分层 |
| 生成目录（tool/config/persistence catalog） | [engine-catalog.md](engine-catalog.md)、[config-catalog.md](config-catalog.md) 与 [error-catalog.md](error-catalog.md) 由源码生成 |
| 文档 kind 与索引 | `docs/doc-kinds.json`、`docs/doc-kind-exemplars.json` 与 `pnpm run check:doc-index` |
| 公共入口 JSDoc | `pnpm run check:exports` 校验 `src/index.ts` 与 `src/engines/contract.ts` 的导出声明 |
| Agent Notes | [.agents/notes](../.agents/notes/README.md) 的 proposed / implemented / rejected / archived 生命周期 |
| ADR | [adr](adr) 保存长期架构决策 |
| cookbook | [cookbook](cookbook/README.md) 保存按任务操作指南 |
| testing policy | [testing.md](testing.md) |
| defensive patterns | [defensive-patterns](defensive-patterns/README.md) 保存评审强制规则 |
| doc budgets / link / type / format gates | [scripts/doc-budgets.json](../scripts/doc-budgets.json)、`pnpm run check:docs`、`pnpm run check:repository` |
| lefthook pre-commit / pre-push | `.githooks/` + `pnpm run hooks:install`；pre-commit 跑生成物、文档与仓库检查，pre-push 跑完整 `check` 和分发检查 |
| change scope | `pnpm run change-scope` |
| Skills | `.agents/skills/` |
| verification | [verification/README.md](verification/README.md) 冻结真机证据 |
| postmortem | [postmortem/README.md](postmortem/README.md) 只收真实生产事故 |

没有复制：双语配对、文档网站投影和 subsystems 分层。它们服务 DSH 的仓库规模，当前项目用单层文档和按任务 cookbook。postmortem 只保留写入规则，不预建事件文件。

这套方案的验收点是：改代码时能回答“当前契约在哪、决策理由在哪、证据在哪、哪个脚本会失败”。如果任一问题没有 owning 文件，地基就还有缺口。

## 本地材料

- `.scratch` 是可丢弃工作区；不提交内容，也不把它当作当前契约来源。
- `.agents/worktrees/` 只存放本机会话 worktree；不进入仓库，也不参与公开源码检查。
- 研究克隆、旧基准输出、旧包体、临时测试报告和已结束 spike 在任务收尾时删除或送入回收站。
- `dev-loop/` 只保留仍被脚本读取的凭证、仍被冻结验收记录引用的证据，以及尚在当前任务中的材料。
- 本机路径、凭证和临时过程写 `LOCAL.md`，该文件不入库。

## Skill 路由

| 任务 | Skill |
| --- | --- |
| 创建或晋升 Agent Note | `agent-note-lifecycle` |
| 文档结构与事实归属 | `doc-governance` |
| 中文技术 prose 和契约覆盖 | `prose-contracts` |
| 清理过程叙述 | `trim-process-leakage` |
| 规则优先的 diff 评审 | `rule-first-review` |
| 选择最小充分验证 | `change-evidence` |
| PR 记录与 AI 参与声明 | `pr-record` |
| 寻找可删除的维护义务 | `find-simplifications` |
| 设计失败与恢复语义 | `failure-contracts` |
| 网络与外部服务测试可靠性 | `test-reliability` |
| 设计模型可见接口和 Skill | `agent-interface` |
| 选择项目工作流入口 | `ask-project` |
