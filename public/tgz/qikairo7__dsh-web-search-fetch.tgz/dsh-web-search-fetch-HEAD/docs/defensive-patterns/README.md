# 防御模式

本文件是评审时强制执行的规则，不是教程。每条规则说明必须成立的事实、审查判据和证据。

适用于会改变 `src/`、`client/`、配置、外部请求、失败处理、预算或输出的改动。

## 先守卫，再外发

本机、内网、链路本地、保留、转换和其他特殊地址不得到达第三方提取服务。

审查判据：地址守卫在专用 API、静态 HTTP 和动态提取之前运行；例外只允许明确配置的静态域名清单。

证据：`test/support/address-guard.test.ts`、`test/fetch/provider.test.ts`。

## 凭证只保存引用

配置、日志、错误和测试夹具不得出现实际密钥。

审查判据：配置只保存 `credential-ref`；示例只使用引用名；错误 `detail` 不拼接 Authorization 头。

证据：`docs/configuration.md`、`src/index.ts`、`test/engines/*.test.ts`。

## 外部失败在适配层收敛

编排层只读取 `EngineFailure`，不解析上游错误文案。

审查判据：HTTP/SDK 异常在适配器投影；`target-status`、`rate-limited`、`quota`、`auth`、`network` 不混用；失败后不继续执行依赖该结果的工作。

证据：`src/engines/failure.ts`、`test/engines/*.test.ts`。

## 预算与结算只有一个所有者

每个 HTTP 请求只计数一次，每个 lane 结局只结算一次。

审查判据：引擎发请求前调用 `countRequest()`；`LaneSettlement` 统一投影额度账本和熔断；超时、取消和缓存命中不重复计费。

证据：`test/support/lane-settlement.test.ts`、`test/search/quota-sweep.test.ts`。

## 输出按完整块截断

截断不得破坏代码块或段落，`truncated` 逐层传播。

审查判据：整理和探测路径按完整内容块省略；最终结果的 `truncated` 汇总所有路径；不静默丢弃来源或正文。

证据：`test/fetch/document.test.ts`、`test/fetch/provider.test.ts`。

## 并发与取消有明确结局

deadline、调用方取消和部分成功都必须有确定结局。

审查判据：`runOperation`、`SettlementWindow` 和 `LaneSettlement` 统一处理；不吞 `AbortError`；未完成路不进入整理结果；慢路被取消时标记 `truncated`。

证据：`test/search/aggregate.test.ts`、`test/fetch/aggregate.test.ts`。

## 评审入口

`rule-first-review` 先读本页和受影响调用点。新增例外必须在 ADR 或 Agent Note 中说明边界和批准条件。
