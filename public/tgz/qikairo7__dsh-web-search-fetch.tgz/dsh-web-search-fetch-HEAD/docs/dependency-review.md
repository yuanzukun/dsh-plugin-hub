# 运行依赖审阅材料

## 范围与状态

本文回应 [DSH Store #1415 的复检意见](https://github.com/AI-Scarlett/DSH-Store/issues/1415#issuecomment-6195716034)，提供 `0.2.11` 的作者侧分发修复与依赖材料；固定 Git 树缺少入口的问题已补齐。Store 的独立供应链审阅及准入决定仍待完成。

`0.2.11` 至 `0.2.20` 的版本流水是历史背景：期间完成 `0.2.12` 隔离安装与生命周期验证、`0.2.14` 正式 Web profile 升级与原生 `web_fetch` 验证，`0.2.16` 仅升级开发依赖到 DSH `0.2.1-alpha.5`、未改变直接运行依赖，`0.2.19` 增加 DeepSeek Search / Fetch 来源，`0.2.20` 新增直接运行依赖 `ipaddr.js@2.5.0`（本机与内网地址判定，版本与宿主 `dsh-web-fetch-http` 一致）。运行证据分别见[生命周期验收记录](./verification/profile-lifecycle-20261016.md)与[正式 profile 安装验证](./verification/formal-profile-v0.2.14-20261016.md)；`0.2.15` 的 alpha.4 适配证据以对应 Release 记录为准。运行证据与依赖审阅材料分别记录，均不替代 Store 的独立审阅。当前直接运行依赖以 `package.json` 为准，共 4 个，清单见下；`0.4.3` 起移除无使用点的遗留依赖 `fast-xml-parser@5.11.2`（v0.2 Bing RSS 时期引入，v0.3 移除该引擎后 `src`、`client`、`scripts`、`test` 均无使用点）。

[依赖清单](./dependency-inventory.json) 记录 2026-11-08 查询 npm 官方 Registry 得到的版本、来源仓库、许可证、tarball URL、SHA-512 integrity、安装脚本、源码构建脚本及公告响应。该快照生成于 `0.4.3`（移除 `fast-xml-parser` 之后），覆盖 4 个直接运行依赖及其锁定传递依赖，共 7 个包；宿主提供的 peer 依赖与开发依赖不在此范围内。当前依赖状态以 `package.json` 与锁文件为准，复核命令见下文。依赖清单和审阅边界不因版本号提升而自动免除复核。

Registry 元数据中的 integrity 与项目锁文件逐项一致，清单中的 7 个包均未声明 `preinstall`、`install`、`postinstall`。公共漏洞公告接口此次返回空对象，仅表示本次查询未返回公告。未验证发布者签名或 provenance，也未据此断言包内代码安全。本文及清单均不替代 Store 或其他审阅者的独立审计。

## 直接运行依赖

| 包与锁定版本 | 来源 | 本插件用途与审阅边界 |
| --- | --- | --- |
| `@deepseek-ai/schemastery@3.18.5` | [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) | 在 `src/index.ts` 声明配置 schema。上游官方命名空间是依赖来源，本插件包名不占用该命名空间。传递引入 cosmokit 与 Standard Schema 类型。 |
| `@joplin/turndown-plugin-gfm@1.0.68` | [Joplin GFM 插件](https://github.com/laurent22/joplin-turndown-plugin-gfm) | 在 `src/fetch/document/blocks.ts` 补充表格等 HTML 转换规则。npm 包带构建产物；源码 `prepare` 为 `npm run build`，安装本项目时不从依赖的 Git 源构建。 |
| `ipaddr.js@2.5.0` | [ipaddr.js](https://github.com/whitequark/ipaddr.js) | 在 `src/support/address-guard.ts` 判定本机与内网地址，作为派发第三方提取服务前的守卫。纯解析库，无网络访问、无安装脚本。与宿主 `dsh-web-fetch-http` 使用同一版本，避免两套地址分类规则。 |
| `turndown@7.2.4` | [Turndown](https://github.com/mixmark-io/turndown) | 在 `src/fetch/document/blocks.ts` 将 HTML 转成 Markdown，移除 script、style、noscript。通过 domino 解析 DOM，不执行页面脚本；这不等于对输出做安全过滤或验证内容可信度。 |

四个直接依赖均声明 MIT（按锁文件与 npm 元数据核对）。传递依赖中 `@mixmark-io/domino@2.2.0` 声明 BSD-2-Clause，其余声明 MIT；完整许可证及来源字段见清单。依赖不内联到插件编译文件，由包管理器安装并保留自身许可文件。

## 分发与权限

- `lib/` 包含 45 个 ESM 模块和 45 个类型声明，随固定 Git 提交提供。`client/index.js` 与 `cordis.patch.yml` 同时保留，安装方不需要执行 TypeScript 构建。
- 本插件没有 `preinstall`、`install`、`postinstall` 或 `prepare`。作者打包时的 `prepack` 运行本仓库清理脚本及 TypeScript 编译器；这与安装已生成的固定源码是不同操作。
- Bundle 的 `web` 行覆盖该配置层的整个 config，选择 `aggregated` 搜索／提取 provider；新增入口为 `web-search-fetch`。应用前应单独审阅配置覆盖对原有 provider 设置的影响。
- 插件代码以宿主进程权限运行。凭证读写、外部网络、自定义端点、日志与资源限制见[安全说明](../SECURITY.md)。依赖没有安装脚本，不表示运行时没有权限或风险。
- 保留 manifest 已有的精确兼容矩阵；未验证版本保持 `unknown`。原始审查范围是分发与离线回归，不包含实际 profile 安装、卸载、回滚或上架成功声明。后续独立完成的隔离生命周期、全服务矩阵和 `0.2.14` 正式 profile 升级见上文链接；它们不替代本页的依赖审阅。

## 复核方法

```sh
pnpm install --frozen-lockfile --ignore-scripts
pnpm run check:distribution
pnpm run check
git diff --exit-code -- lib
npm pack --dry-run --ignore-scripts
node scripts/audit-runtime-dependencies.mjs
```

最后一条命令只读取项目 manifest、锁文件并查询 npm 官方 Registry，将 JSON 输出到终端，不安装或执行第三方包。网络需经环境代理时，Node.js 24 可使用 `node --use-env-proxy scripts/audit-runtime-dependencies.mjs`。脚本会在来源、锁定 integrity 不一致或接口失败时退出失败；返回任何公告也会退出失败，交由审阅者进一步判断版本是否受影响。

pnpm 12 的锁文件含两个 YAML 文档：包管理器依赖和项目依赖。复核脚本使用 `parseAllDocuments` 并选择项目依赖文档，避免只检查包管理器。本次未将普通 `pnpm audit --prod` 的输出作为项目依赖已覆盖的证据。

CI 在构建前检查完整编译产物已进入 Git，构建后检查 `lib/` 与提交内容一致。该检查能防止缺失或陈旧产物；不能证明宿主运行效果或完成独立供应链审核。
