# 运行依赖

当前以 [`package.json`](../package.json) 和锁文件为准。依赖不内联进 `lib/`，由包管理器安装并保留各自许可。

## 直接依赖

| 依赖 | 版本 | 用途 |
| --- | --- | --- |
| `@deepseek-ai/schemastery` | `3.18.5` | 声明插件 Config schema。 |
| `@joplin/turndown-plugin-gfm` | `1.0.68` | HTML 转 Markdown 的 GFM 表格规则。 |
| `ipaddr.js` | `2.5.0` | 地址守卫判定本机、内网和保留地址。 |
| `turndown` | `7.2.4` | HTML 转 Markdown；不执行页面脚本。 |

四个直接依赖均声明 MIT。传递依赖 `@mixmark-io/domino` 为 BSD-2-Clause，其余为 MIT。完整版本、integrity、来源和许可快照见 [dependency-inventory.json](dependency-inventory.json)。

## 安装行为

- 插件安装时没有 `preinstall`、`install`、`postinstall` 或 `prepare`。
- 作者打包时的 `prepack` 只清理并编译本仓库。
- 分发包包含 `lib/`、`client/` 和 `cordis.patch.yml`，安装方不需要执行 TypeScript 构建。
- `cordis.patch.yml` 会覆盖 DSH `web` 配置中的搜索与提取 provider。

## 审阅

```sh
pnpm install --frozen-lockfile --ignore-scripts
pnpm run check
pnpm run check:deps
pnpm run check:advisories
pnpm run check:distribution
git diff --exit-code -- lib
node scripts/audit-runtime-dependencies.mjs > docs/dependency-inventory.json
```

`check:deps` 离线比较 `package.json`、锁文件与 [dependency-inventory.json](dependency-inventory.json)，不查询 Registry。最后一条命令读取 Registry 并查询公告；接口失败、来源不一致或返回公告时退出失败。网络需要代理时可用：

```sh
node --use-env-proxy scripts/audit-runtime-dependencies.mjs
```

本文和清单不替代 DSH Store 或其他独立供应链审阅。
