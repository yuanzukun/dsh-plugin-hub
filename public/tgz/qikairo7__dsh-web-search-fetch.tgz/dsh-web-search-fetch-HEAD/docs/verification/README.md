# 验收证据

`docs/verification/` 保存冻结的真机、GUI 和真实服务证据。这里的记录描述已经发生的观察，不是当前契约；当前行为仍以源码、测试和常设文档为准。

## 命名

- 记录使用 `v<version>-<topic>-<yyyymmdd>.md` 或既有历史命名。
- 截图、JSON 和原始输出放在 `assets/`，文件名带版本和日期。
- 不写凭证、认证头、私密 URL 或未脱敏日志。

## 冻结

新增记录后运行 `pnpm run freeze:verification`，提交脚本生成的 `scripts/verification-freeze.json`。

`pnpm run check:docs` 会校验清单中的文件仍存在且哈希未变，并拒绝从清单删除已封印条目。需要更正旧记录时，追加新的更正记录，不修改已冻结文件。

## 当前边界

旧记录可以引用当时的本地 `.scratch` 原始证据；这些路径不进入当前契约，也不要求在新环境重建。
