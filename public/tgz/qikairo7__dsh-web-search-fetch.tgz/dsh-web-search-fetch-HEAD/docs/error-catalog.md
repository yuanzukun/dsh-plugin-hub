# 错误码目录

本文件由 `src/**/*.ts` 中的 `WEB_*` 字符串生成，不要手工编辑。运行 `pnpm run generate:errors` 更新。

| 错误码 | 含义 | 出现位置 |
| --- | --- | --- |
| `WEB_ABORTED` | 调用方主动取消，未继续等待结果。 | `src/engines/aihot.ts`、`src/fetch/aggregate.ts`、`src/fetch/attempt.ts`、`src/fetch/guards.ts`、`src/search/aggregate.ts`、`src/support/budget.ts` |
| `WEB_BLOCKED_URL` | 地址守卫或目标站拒绝了该 URL。 | `src/fetch/aggregate.ts`、`src/fetch/attempt.ts`、`src/fetch/guards.ts`、`src/support/address-guard.ts` |
| `WEB_FETCH_TIMEOUT` | 提取在总限时或单路限时内未完成。 | `src/engines/aihot.ts`、`src/fetch/aggregate.ts`、`src/fetch/attempt.ts`、`src/support/budget.ts` |
| `WEB_FETCH_TOO_LARGE` | 输入或输出超过提取预算。 | `src/engines/aihot.ts`、`src/fetch/aggregate.ts`、`src/fetch/document/organize.ts` |
| `WEB_INVALID_URL` | URL 不可解析或不是 HTTP(S)。 | `src/engines/aihot.ts`、`src/fetch/aggregate.ts`、`src/fetch/attempt.ts` |
| `WEB_PROVIDER_ERROR` | provider 不可用、未配置或全部路径失败。 | `src/engines/aihot.ts`、`src/fetch/aggregate.ts`、`src/fetch/attempt.ts`、`src/fetch/document/organize.ts`、`src/fetch/guards.ts`、`src/search/output.ts` |
| `WEB_SEARCH_TIMEOUT` | 搜索在操作总限时内未完成。 | `src/search/aggregate.ts`、`src/support/budget.ts` |
| `WEB_UNSUPPORTED_CONTENT_TYPE` | 目标内容类型不受提取器支持。 | `src/fetch/aggregate.ts` |
