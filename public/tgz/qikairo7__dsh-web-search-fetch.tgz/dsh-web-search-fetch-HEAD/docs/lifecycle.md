# 安装生命周期

操作前停止目标 profile。只备份和修改目标 profile；其他 profile 可能共享配置或凭证。

## 安装

```sh
dsh plugin --profile <profile> add <package-url-or-file>
```

安装后重启 profile，并运行：

```sh
dsh --profile <profile> --dump-config
```

确认存在 `web-search-fetch`，且搜索与提取 provider 均为 `aggregated`。然后用原生 `web_search` 与 `web_fetch` 各调用一次；配置输出只证明装载。

## 升级前备份

保存以下内容：

- profile 的 `package.json`、锁文件和 `cordis.patch.yml`。
- 当前可用版本的安装包或 40 位 Git 提交。
- 安装前 `web` 条目的完整配置。
- home 级 patch 或额外 `--patch` 文件中的相关覆盖。

配置可能包含其他插件的信息，备份只保存在本地。

## 卸载

```sh
dsh plugin --profile <profile> remove dsh-web-search-fetch
```

然后：

1. 删除 `cordis.patch.yml` 中 `id: web-search-fetch` 的整项覆盖。
2. 恢复安装前的 `web.searchProvider` 与 `web.fetchProvider`。
3. 运行 `--dump-config`，确认没有本插件条目和覆盖警告。
4. 重启 profile，确认设置卡消失并验证原有工具。

DSH CLI 不会自动移除设置页保存过的覆盖项。遗留覆盖会在启动时报 `patch: entry "web-search-fetch" not found`。

卸载不删除 DSH credentials 中的凭证值；其他 profile 可能仍在使用同一引用。

## 回滚

```sh
dsh plugin --profile <profile> add file:./previous-version.tgz --ignore-scripts
```

随后恢复与旧版本配套的配置，运行 `--dump-config`，重启 profile 并实际调用两个原生工具。新版新增配置字段不一定被旧版识别；不要直接沿用新版全部配置。

历史安装、卸载和回滚证据见 [verification](verification)。
