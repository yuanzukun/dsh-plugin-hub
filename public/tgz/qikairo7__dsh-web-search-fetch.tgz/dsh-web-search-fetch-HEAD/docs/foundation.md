# 项目地基

本文固定插件的职责、不变量、节点模型、公共接缝和非目标。它是后续设计、实现与评审的入口；文档层级见 [AGENTS.md](AGENTS.md)，模块分层、文件和调用顺序见 [architecture.md](architecture.md)。改变本文约束时，先写 ADR 或 Agent Note，再改代码。

## 职责

插件在 DSH 原生 `web_search` / `web_fetch` 后面，把外部来源变成一次可预算、可解释、可停止的调用。

它是免费网页替代的检索路径编排器，不是搜索聚合器。普通查询先走本地意图规则选出的基线路径，证据不足时才有界补派；多来源融合只服务于已经发生的多路结果，不反向要求每查询固定并发全部来源。

插件不新增模型工具、不新增 MCP 服务、不启动常驻进程。宿主仍然只看到 `web_search` 和 `web_fetch`。

## 不变量

| 不变量 | 约束 | 所有者 |
| --- | --- | --- |
| 单一入口 | 只向 `ctx.web` 注册 id 为 `aggregated` 的搜索与提取 provider，不改变模型可见工具 | [dsh-web-interface.md](dsh-web-interface.md) |
| 基线路由 | 搜索意图由本地确定性规则判定；装配层按有序规则给出候选链，实际派发受配置、凭证、额度、熔断和预算约束 | [ADR-0005](adr/0005-search-intent-route-rules.md) |
| 有界执行 | 一次操作共享 `maxRequests`、总限时和输出上限；不无限重试 | [architecture.md](architecture.md) |
| 证据驱动 | 停止、补派和降级只消费 `QueryAnalysis` 与 `SearchEvidence`，不调用模型判断 | [architecture.md](architecture.md) |
| 可解释 | 每次补派、降级、缓存命中、截断和最终选源都有可观察说明；熔断跳过写入日志 | [architecture.md](architecture.md) |
| 单一事实源 | 引擎清单只来自 `src/engines/registry.ts`；配置字段只来自 `src/index.ts`；额度结算只来自 `LaneSettlement`；生成目录见 [engine-catalog.md](engine-catalog.md) 和 [config-catalog.md](config-catalog.md) | [development.md](development.md) |
| 边界收敛 | 编排层不认识具体引擎 id 或适配器；外部失败在适配层收敛为 `EngineFailure` | [architecture.md](architecture.md) |
| 凭证引用 | 配置只保存凭证引用名；实际密钥由 DSH credentials 解析，不写日志 | [configuration.md](configuration.md) |
| 先守卫后外发 | 本机、内网、链路本地、保留和特殊地址在第三方提取前拒绝 | [architecture.md](architecture.md) |
| 完整块输出 | 截断只发生在完整内容块边界；`truncated` 逐层向上传播 | [content-organization.md](content-organization.md) |
| 不仲裁事实 | 融合和正文整理不改写原文，不判断事实真伪，也不把多路一致当独立佐证 | [content-organization.md](content-organization.md) |

## 节点模型

一次调用由四类节点组成：

- 来源节点：一个外部服务适配器。一个节点只有一份 manifest、一套凭证、一套额度与失败语义。
- 算子节点：本地纯变换，例如查询分析、归一、过滤、融合、日期治理和正文整理。算子节点不发网络请求。
- 控制节点：来源选择、额度日检、熔断、缓存、充分性判断、补派和停止。控制节点决定下一条边。
- 出口节点：把最终结果交回 DSH provider seam。

SiliconFlow 重排是可选的外部算子；它只消费融合后的候选，失败时回退融合序，不参与来源路由。

节点之间只传显式数据。路由、预算、配置快照和说明通过 `OpContext` 或函数参数传递，不依赖隐式全局状态。

### 搜索路径

```mermaid
flowchart LR
  Q[web_search] --> A[查询分析]
  A --> C{缓存命中}
  C -->|是| O[输出]
  C -->|否| D[额度日检与熔断过滤]
  D --> S[来源选择]
  S --> L1[首轮单路]
  L1 --> E[SearchEvidence]
  E --> J{充分}
  J -->|是| F[融合与质量治理]
  J -->|否| L2[最多补派一路]
  L2 --> F
  F --> R[日期治理与可选重排]
  R --> T[输出预算与说明]
  T --> O
```

补派后只更新证据并继续输出，不重新进入充分性循环，避免同一操作反复升级。垂直取数和热点榜单是首轮单路的特化路由；它们无产出时按查询语言降级通用路由一次，不改变「一路优先」的宽度。

### 提取路径

```mermaid
flowchart LR
  U[web_fetch] --> G[地址守卫]
  G --> A{专用 API}
  A -->|是| R[专用读取器]
  A -->|否| S{静态文件}
  S -->|是| H[HTTP 提取器]
  S -->|否| D{专属提取路命中}
  D -->|是| X[专属提取]
  D -->|否| P[首路探测]
  X -->|全败| P
  P --> V{正文足够}
  V -->|是| O[输出]
  V -->|否| M[多路整理]
  M --> O
  R --> O
  H --> O
  X --> O
```

多路整理只在首路探测不足或没有可探测通道时发生。首路已经取得的候选并入整理，不重复请求同一通道。

### 边语义

| 结局 | 下一条边 |
| --- | --- |
| 成功且有可用结果 | 进入融合、日期治理和输出 |
| 空结果或证据不足 | 搜索补派一路；提取升级多路整理；受预算和限时约束 |
| `rate-limited` | 记录冷却，当前操作不重试该引擎；后续操作按熔断状态跳过 |
| `quota` | 记录额度失败，熔断到本地次日；搜索的带密钥调用只有在清单允许该能力面免钥时才匿名重试一次，提取不因额度失败自动改匿名 |
| `auth` | 直接报告凭证问题，不静默降级匿名 |
| `timeout` 或 `aborted` | 结算已完成结果；总限时到期时返回已有结果并标记 `truncated` |
| `invalid` 或 `target-status` | 归为目标问题，不把它当成引擎故障；提取全败时按最特异的 `WEB_*` 码报告，搜索全败统一 `WEB_PROVIDER_ERROR` |

## 公共接缝

| 接缝 | 当前契约 | 事实归属 |
| --- | --- | --- |
| DSH provider | `search({ query, maxResults })` 与 `fetch({ url })` 的请求、结果和 `WEB_*` 错误 | [dsh-web-interface.md](dsh-web-interface.md) |
| 引擎 | manifest、能力位、请求结果与 `EngineFailure` | `src/engines/contract.ts`、`src/engines/failure.ts` |
| 配置 | 字段、默认值、范围和保存语义 | [configuration.md](configuration.md)、`src/index.ts` |
| 额度结算 | 单路结局到额度账本与熔断信号的唯一映射 | `src/support/lane-settlement.ts` |
| 输出 | `sources[]` 的 `summary` 与 `publishedAt`，以及 `content`、`truncated` | [dsh-web-interface.md](dsh-web-interface.md) |

## 非目标

- 自建网页索引、爬虫或搜索后端。
- 判断事实真伪，或把多来源一致当成事实核验。
- 每次查询固定并发全部来源。
- 用模型决定路由、停止或补派。
- 新增模型工具、MCP 服务或常驻进程。
- 跨进程持久化额度账本；当前账本只活在进程内。
- 复刻 DeepSeek 官方 Search / Fetch 服务端能力。

## 验收场景

| 场景 | 可观察结果 | 证据 |
| --- | --- | --- |
| 普通查询 | 首轮只调用一路；没有不足原因时不补派 | `test/search/aggregate.test.ts` |
| 官方域缺失 | 最多补派一路，说明包含官方域缺口 | `test/search/sufficiency.test.ts`、`test/search/aggregate.test.ts` |
| 搜索全败 | 返回 `WEB_PROVIDER_ERROR` 或 `WEB_SEARCH_TIMEOUT`，不伪装成空结果成功 | `test/search/aggregate.test.ts` |
| 无效密钥 | 引擎失败归为 `auth`，不静默改用匿名额度 | `test/search/aggregate.test.ts` |
| 额度耗尽 | 写入本地账本并熔断；后续操作跳过该引擎 | `test/search/quota-sweep.test.ts` |
| 私网 URL | 在第三方请求前返回 `WEB_BLOCKED_URL` | `test/support/address-guard.test.ts` |
| 动态短页 | 先探测一路，再升级多路整理；输出按完整块截断 | `test/fetch/provider.test.ts`、`test/fetch/document.test.ts` |
| 配置保存 | 正在执行的操作继续使用旧快照；下一次操作读取新快照 | `test/live-config.test.ts` |

## 变更规则

新增来源节点时，新增适配器、registry manifest 和离线测试；搜索与提取编排层不需要为具体引擎改名或加分支。

新增或修改引擎时，运行 `pnpm run generate:engines`；不手改 README 服务清单或配置服务表。

新增算子节点时，保持纯本地、可离线测试，并把事实归属写进本文或 [architecture.md](architecture.md)。

改变本文不变量时，先在 `docs/adr/` 或 `.agents/notes/proposed/` 记录取舍，再在同一变更中更新代码、测试、本文和受影响文档。

公共行为、配置字段和输出字段变化时，更新各自的 owning 文档与能失败的测试；不把未验证的行为写成当前契约。
