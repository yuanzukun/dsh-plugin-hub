# 架构

项目职责、不变量、节点模型和非目标由 [foundation.md](foundation.md) 拥有；本文只描述实现分层、文件和调用顺序。

插件只有一个职责：在 DSH 原生 `web_search` / `web_fetch` 后面，把多个外部来源变成可预算、可解释的一次调用。

## 总览

```mermaid
flowchart LR
  Search[web_search] --> Route[语法解析与结构化查询信号]
  Route --> Select[额度、熔断与来源选择]
  Select --> Engines[首轮调用一路]
  Engines --> Assess[结果充分性评估]
  Assess -->|不足| Escalate[有界补派一路]
  Escalate --> Engines
  Assess -->|足够| Fuse[URL 归一与 RRF 融合]
  Fuse --> Quality[相关性、权威域与时间治理]
  Quality --> Rerank[可选 SiliconFlow 重排]
  Rerank --> Output[summary、publishedAt 与输出预算]

  Fetch[web_fetch] --> Guard[地址守卫]
  Guard --> API{AIHOT 专用 API?}
  API -->|是| Direct[Markdown / JSON 原样返回]
  API -->|否| Split{静态文件?}
  Split -->|是| HTTP[直接 HTTP]
  Split -->|否| Probe[首路探测]
  Probe --> Organize[多路正文整理]
  Organize --> Body[正文、来源与差异]
```

## 分层

```text
src/index.ts     装配层：Config、凭证、默认列表、provider 注册
src/engine-priority.ts  装配层搜索路由规则：按特异条件优先给出抽象候选链
src/engines/     引擎层：外部协议映射；registry 是服务清单唯一事实源
src/search/      搜索编排：QueryAnalysis 集中查询信号，SearchRoutePlanner 消费抽象候选元数据，SearchEvidence 集中停补证据
src/fetch/       提取编排：ExtractionAttempt 集中单路提取与结算
src/support/     横切机制：预算、熔断、额度、LaneSettlement、URL、地址守卫
```

依赖方向只能向下。`src/search/`、`src/fetch/`、`src/support/` 不得 import 具体引擎适配器，也不得写引擎 id。`test/architecture.test.ts` 强制这条边界。

## 搜索管线

1. 解析查询操作符：`site:`、`-site:`、`lang:`、`after:`、`before:`。
2. 在本地生成 `QueryAnalysis`：七类意图、语言、主题词、时效要求、验证要求、域名与日期语法；后续质量、缓存、日期与输出阶段都消费这一份分析，不重新解析查询。
3. 先查进程内缓存；键含规划器版本。命中按 Top5 质量门复核，低质量绕过并重搜；显式日期或新鲜词仍绕过读取。
4. 按 `engine-priority.ts` 的有序意图规则生成抽象候选链；候选解析层结合服务开关、就绪探测（装配层覆盖凭证与额度账本）和熔断状态标注可用性，`SearchRoutePlanner` 按候选角色、能力面与可用性选择来源，首轮只派一路。
5. 首轮单路最多 8 秒，为一次补派预留总限时；操作总限时默认 15 秒。
6. 相关性过滤后生成 `SearchEvidence`，含 Top5 的主题相关、不同域名、已知日期与超过 200 字符摘要计数；用同一组事实判断宽限停止与补派：无结果、官方域缺失、调研覆盖不足或 AI 资讯缺少近 7 天时间时，排除已用服务后只补派一路。
7. URL 归一后用 RRF 融合，`k = 60`；同一 URL 保留更完整的 `snippet` 与 `summary`。
8. 应用官方域、政府域、研究域和社区域排序；主题不匹配的权威域不保留。
9. 显式日期窗口过滤已知窗口外结果；热点与 AI 资讯优先 7 天内结果。
10. 配置 SiliconFlow 密钥时，把前 30 条候选交给 `BAAI/bge-reranker-v2-m3` 重排；失败时回退融合序。
11. 搜索面至少采样 5 条候选用于质量评估；输出按宿主 `maxResults` 与 `maxOutputChars` 裁剪，保留逐引擎命中数、缓存年龄、截断与补派原因。

垂直取数和热点榜单无产出时，按查询语言降级通用路由一次。单通道搜索结果不足时，排除已派发服务补派一路。两条路径都受同一请求预算约束，且每操作最多补派一次。

搜索处理说明中的稳定 reason id 与参数由 [dsh-web-interface.md](dsh-web-interface.md) 拥有；架构只要求规划器输出结构化 reason。

## 提取管线

1. 地址守卫先解析目标。除公网单播地址外，本机、内网、链路本地、保留、转换和其他特殊范围均返回 `WEB_BLOCKED_URL`，不外发给第三方。
2. `https://aihot.news/api/v1/*` 的文档化路径由 AIHOT 专用读取器接管，原样返回 Markdown 或 JSON。
3. 静态扩展名交给 DSH HTTP 提取器；单请求 30 秒，最多 5 次重定向。
4. 动态页先探测一路。每次引擎调用都是一个 `ExtractionAttempt`，统一处理 deadline、取消、空正文、失败码与额度结算；结果为 2xx、目标一致、非挑战页且段落不少于 400 字符时直接返回。
5. 探测不足时升级多路整理，每路默认 45 秒，操作总限时默认 50 秒；多路与探测共用 `ExtractionAttempt`。
6. 多份正文按标题路径和完整内容块对齐；相同块去重，独有块互补。
7. 标题、语言、版本或顺序不兼容的内容进入补充片段；登录页和挑战页不混入正文。
8. 输出按完整内容块受 `maxOutputChars` 约束；超限标记 `truncated`，不截断半个代码块或段落。

新增静态扩展、专用 API 或分流分支时，按 [cookbook/adding-a-fetch-route.md](cookbook/adding-a-fetch-route.md) 执行。

## 配置与凭证

Config 根对象是 schemastery volatile 引用。每次操作读取一次快照，并在同一操作的并发路之间共享；宿主配置更新后下一次操作生效。凭证只保存引用名，实际值由 DSH credentials 服务解析，不写入配置文件或日志。当前包不内置插件设置页。

字段和默认值见 [configuration.md](configuration.md)。

## 额度与熔断

- 每次操作有 `maxRequests` 上限；DSH 多查询共享同一份预算。
- Tavily、Firecrawl、知乎有官方额度端点；AnySearch 与 AIHOT 没有，不伪造余额。
- 本地账本按日记录成功、限流和额度失败，进程内保存，重启后清零。
- 限流按 `Retry-After` 冷却；无提示时 60 秒，重复触发指数退避，上限 1 小时。
- 额度耗尽熔断到本地次日零点；官方额度恢复后手动刷新可解除。
- AnySearch 与 Tavily 账号额度耗尽时，同一次操作可改用匿名额度重试一次；密钥无效不降级。
- `quotaPanel` Typert 远程诊断面提供 `get()` 与 `refresh()`；它是宿主侧额度服务，不依赖插件设置页。

## 错误模型

引擎在适配层把外部异常收敛为 `EngineFailure`。`LaneSettlement` 只依据结构化类型投影额度入账与熔断信号；编排层不解析错误文案。

提取全败时按「目标拒绝」和「引擎不可用」分组，优先返回最特异的 `WEB_*` 错误码。单路失败不阻止其他路返回结果。

## 新增引擎

按 [cookbook/adding-an-engine.md](cookbook/adding-an-engine.md) 执行。验收标准不变：搜索与提取编排层不需要为新增引擎修改，这是分层的验收标准。
