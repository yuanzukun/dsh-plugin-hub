# 配置目录

本文件由 `src/index.ts` 的 `Config` schema 生成，不要手工编辑。运行 `pnpm run generate:config` 更新。

| 字段 | 类型 | 默认 | 约束 | 说明 |
| --- | --- | --- | --- | --- |
| `controls.serviceEnabled` | `{ [key: string]: boolean }` | `{}` | — | 服务总开关；关闭后不派发该服务。 |
| `controls.searchServices` | `string[]` | `["anysearch","tavily","firecrawl","zhihu","aihot"]` | — | 搜索服务 ID 与调用优先级；有意图映射时该顺序仅作成员资格过滤，不决定派发优先级。 |
| `controls.fetchServices` | `string[]` | `["anysearch","tavily","firecrawl","zhihu"]` | — | 提取服务 ID 与调用优先级；HTTP 静态路径不受此列表控制。 |
| `controls.maxFetchServices` | `number` | `4` | 1–4 | 每个 URL 最多调用的提取服务数。 |
| `controls.maxRequests` | `number` | `32` | 1–256 | 每次操作的插件 HTTP 请求上限，含额度查询与重试。 |
| `controls.searchDeadlineMs` | `number` | `15000` | 1–3600000 | 搜索操作总限时（毫秒）。 |
| `controls.fetchDeadlineMs` | `number` | `50000` | 1–3600000 | 提取操作总限时（毫秒）。 |
| `controls.maxOutputChars` | `number` | `15000` | 1000–1000000 | 单页整理与搜索来源的输出上限：整理按完整内容块保留正文，搜索按 title+snippet 从尾部裁剪来源列表；均含来源与说明。 |
| `rerank.enabled` | `boolean` | `true` | — | SiliconFlow 重排开关；未配置密钥时自动不启用。 |
| `rerank.apiKeyEnv` | `string` | `SILICONFLOW_API_KEY` | 凭证引用 | SiliconFlow 密钥引用。 |
| `anysearchApiKeyEnv` | `string` | `ANYSEARCH_API_KEY` | 凭证引用 | AnySearch 凭证引用；未配置时使用官方匿名额度。 |
| `anysearchBaseURL` | `string` | 未设置 | — | AnySearch 搜索与提取端点覆盖；留空使用官方端点。 |
| `anysearchZone` | `"cn" / "intl" / ""` | 未设置 | — | AnySearch 区域；cn 国内、intl 国际，空则不发送。 |
| `tavilyApiKeyEnv` | `string` | `TAVILY_API_KEY` | 凭证引用 | Tavily 凭证引用；未配置时使用 keyless 模式。 |
| `firecrawlApiKeyEnv` | `string` | `FIRECRAWL_API_KEY` | 凭证引用 | Firecrawl 凭证引用；搜索需要密钥，官方端点提取可免钥。 |
| `firecrawlBaseURL` | `string` | 未设置 | — | Firecrawl 基地址覆盖；留空使用官方端点。 |
| `zhihuApiKeyEnv` | `string` | `ZHIHU_API_KEY` | 凭证引用 | 知乎凭证引用；启用知乎时必需。 |

`controls.serviceEnabled` 的 `{}` 表示由 registry 默认开关决定；`未设置` 表示 schema 没有默认值，运行时按空值或适配器默认处理。凭证字段只保存引用名，实际值由 DSH credentials 解析。
