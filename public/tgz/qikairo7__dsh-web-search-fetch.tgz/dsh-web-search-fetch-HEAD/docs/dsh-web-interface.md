# DSH 接口

本插件以 DSH 源码 `0.2.2-rc.1` 为行为目标，并用同版本 npm 包做类型检查。`pnpm run check:version` 校验本文、README、`docs/glossary.md` 与 `package.json` 的版本一致。若 DSH 接缝变化，先更新本文和对应测试，再改实现。

request/result 字段快照由 `pnpm run generate:dsh-interface` 从已安装的 `@deepseek-ai/dsh-web` 类型生成到 [dsh-web-interface-fields.json](dsh-web-interface-fields.json)；`pnpm run check:docs` 校验新鲜度。

## 插件装配

```ts
export const name = 'web-search-fetch'
export const inject = ['web', 'credentials']
```

插件向 `ctx.web` 注册两个 provider，id 均为 `aggregated`：

| 方法 | 请求 | 结果 |
| --- | --- | --- |
| `search()` | `{ query, maxResults }` | `{ content?, sources, truncated }` |
| `fetch()` | `{ url }` | `{ url, statusCode, body, truncated }` |

`sources[]` 支持 `url`、`title`、`snippet`、`summary`、`publishedAt`。`summary` 由 DSH 截断到 800 字符后进入模型输出；Web 卡片元数据只保留来源展示字段。

`content` 中的搜索处理说明保留稳定 reason id；宿主只接收字符串，结构化参数如下：

| reason id | 参数 |
| --- | --- |
| `route-primary` | `candidate`、`available` |
| `route-skip` | `candidate`、`cause`（service-disabled、not-configured、breaker-open、unavailable） |
| `repair-evidence` | `candidate`、`gap`（empty、official-source、research-coverage、fresh-date）、`mode`（supplement/fallback） |
| `stop-quality` / `stop-budget` / `stop-deadline` / `stop-exhausted` | 无 |

## 工具层

DSH `tool-web` 注册两个模型可见工具：

```text
web_search({ queries: string[] })
web_fetch({ url: string })
```

| 配置 | 默认 | 说明 |
| --- | --- | --- |
| `searchMaxResults` | 10 | 合并后的来源数量上限。 |
| `searchMaxQueries` | 10 | 单次调用查询数量上限。 |
| `searchSummaryMaxChars` | 800 | 单条来源摘要上限。 |
| `searchTimeoutMs` | 30000 | 搜索工具调用预算。 |
| `fetchTimeoutMs` | 30000 | 抓取工具调用预算。 |
| `fetchMaxOutputChars` | 200000 | 抓取输出渲染上限。 |

多查询在工具层去重后并发调用 provider，再按各查询名次轮询合并，按 URL 去重。任一查询失败时中止其余查询并抛出该错误。本插件的多查询调用共享同一个 `maxRequests` 预算。

npm 包与源码在 `0.2.2-rc.1` 附近存在默认值漂移：包类型仍可见来源 8、查询 4，源码目标是 10、10。本插件按源码目标实现，不依赖包默认值。

## provider 生命周期

provider 声明：

- `id`：稳定 id，本插件为 `aggregated`。
- `title` / `description`：设置与诊断文案。
- `ready()`：返回服务是否可用。密钥缺失、服务全关或无可用引擎时不可用。

工具注册与 provider 可用性分离。provider 缺失或不可用时工具仍可见，执行时返回结构化 `WebError`，例如 `WEB_PROVIDER_UNAVAILABLE`。

## Bundle 覆盖

`cordis.patch.yml` 将 DSH `web` 配置中的两个 provider 指到本插件：

```yaml
searchProvider: aggregated
fetchProvider: aggregated
```

这会覆盖同一配置层已有的 provider 选择。安装前应确认目标 profile 没有依赖其他搜索或提取 provider。

## 客户端界面

当前包不声明 DSH client 元数据，也不装载插件设置页。旧版本写入 profile 的 `web-search-fetch` 配置仍由服务端 Config 读取。

## 官方 Search / Fetch API

本插件不复刻 DeepSeek 官方 API 请求字段。官方 Search 请求只有 `query`、`count`、`ori_question`、`localization`、`need_content`；官方 Fetch 请求只有 `url`。

当前 DSH provider seam 只传 `{ query, maxResults }` 与 `{ url }`，因此本插件无法逐请求获得 `ori_question` 或 `localization`。这是宿主接口上限，不是适配遗漏。
