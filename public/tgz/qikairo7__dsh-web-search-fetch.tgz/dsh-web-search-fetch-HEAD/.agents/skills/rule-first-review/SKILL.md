---
name: rule-first-review
description: 先读取本仓库规则、架构契约和相关调用点，再语义评审本次 diff。
---

# Rule-first review

## Workflow

1. Verify the exact base and head. Run `pnpm run change-scope -- --base <verified-base>`.
2. Read [AGENTS.md](../../../AGENTS.md), [architecture.md](../../../docs/architecture.md), and every ADR or Agent Note owning the touched behavior.
3. Map changed paths to owning documents and tests before reading the diff.
4. Trace every changed interface to its callers, configuration, persisted settings, model-visible output, and tests.
5. Review implementation against requirements; do not judge it only against the diff's internal names.
6. Separate blockers from suggestions. Each finding states defect, location, impact, evidence, and fix.

## Review surfaces

- Search intent routing, engine selection, quota settlement, and failure classification.
- Fetch URL admission, provider fallback, extraction, and content organization.
- Configuration precedence, defaults, compatibility, and user-visible errors.
- Public exports and generated declarations in `lib/`.
- Documentation and generated artifacts.

## Blockers

- A required behavior has no failing-capable check.
- Error state can continue without establishing preconditions.
- Public behavior changes without documentation.
- A model-visible field or error loses information needed by the caller.
- Tests restate implementation or trust an agent's self-report.
