---
name: doc-governance
description: 创建、移动或审查本仓库常设文档，保证事实归属、当前状态、链接和验证入口准确。
---

# Document governance

## When

Use this skill when creating or restructuring documentation, package contracts, architecture prose, or release-facing guides.

## Workflow

1. Read [docs/README.md](../../../docs/README.md) for placement and [workflow.md](../../../docs/workflow.md) for governance.
2. Identify the single owning document for each fact.
3. Read the source, tests, configuration, and package manifest that define the behavior.
4. Write current behavior, prerequisites, limitations, failure behavior, and verification paths.
5. Link deeper or adjacent facts instead of restating them.
6. Run every command shown in the edited passage, or name the project script that owns that verification.
7. Run `pnpm run check:docs` and `pnpm run check:repository`.

## Placement

- User configuration and behavior belongs in `docs/configuration.md`.
- Runtime architecture belongs in `docs/architecture.md`.
- Stable architecture decisions belong in `docs/adr/`.
- Process and implementation trade-offs belong in `.agents/notes/`.
- Development operations belong in `docs/development.md`.
- User recovery procedures belong in `docs/troubleshooting.md`.

## Reject

- History narration in current-state documents.
- Duplicate inventories that can be generated or read from source.
- Promises that no test, script, or observed operation supports.
