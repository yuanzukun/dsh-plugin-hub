---
name: prose-contracts
description: 审查中文技术文档、注释、PR 文案和模型可见文本的完整契约覆盖与表达质量。
---

# Prose contracts

## When

Use this skill with `tech-doc-style-chinese` when writing or reviewing repository prose, JSDoc, comments, prompts, diagnostics, UI copy, PR bodies, or release notes.

## Required coverage

- Public APIs and configuration document defaults, limits, failure modes, side effects, and compatibility.
- Internal comments explain non-local structure, invariants, ownership, races, security boundaries, and surprising failure behavior.
- Tests explain only non-obvious design: why a fixture, real entry path, timeout, or indirect assertion is necessary.
- User documents state the task, prerequisites, observable outcome, likely failure, and recovery.
- Agent Notes retain unique rationale, alternatives, consequences, evidence, and known gaps.

## Workflow

1. Read the owning code or source document before changing prose.
2. Preserve every fact, condition, exception, limit, modal qualifier, and compatibility obligation.
3. Delete control-flow narration, review dialogue, process history, and duplicated rationale.
4. Use the project's fixed terminology and machine-readable identifiers verbatim.
5. Keep one paragraph on one physical line; do not hard-wrap Chinese prose.
6. Run the check that owns the changed surface, then `git diff --check`.

## Borderline

A rewrite is borderline only when two versions preserve all propositions but trade approved project principles. Present at most three versions, recommend one, and state the factual difference.
