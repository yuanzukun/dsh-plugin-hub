---
name: ask-project
description: 在本仓库内为当前请求选择合适的 Skill、文档和验证入口；用于路由不确定时，不用于已明确点名的任务。
---

# Ask project

## Scope

Use this skill when the next project workflow, document, or skill is unclear. Do not use it after the user explicitly names a skill or task.

## Workflow

1. Read [AGENTS.md](../../../AGENTS.md), then the [Skill routing table](../../../docs/workflow.md#skill-路由).
2. Classify the request as development, documentation, decision recording, review, validation, simplification, or release preparation.
3. Read the candidate skill's `SKILL.md` before explaining it or recommending that it be skipped.
4. For document placement, read [docs/README.md](../../../docs/README.md).
5. For source, configuration, build, test, or release requirements, follow the entry documents named by `AGENTS.md`.
6. If no skill owns the task, proceed directly with the owning code and document. Do not invent a workflow.

## Boundaries

- The routing table in `workflow.md` is the only inventory of project skills.
- `AGENTS.md` remains the authority for safety, approval, and completion requirements.
- This skill does not replace implementation, review, or validation skills.
