---
name: agent-note-lifecycle
description: 创建、晋升、否决或归档本仓库的 Agent Note，并保持决策记录与代码、测试、文档同步。
---

# Agent Note lifecycle

## When

Use this skill when a change creates a durable process decision, records a rejected alternative, or promotes a proposal to implemented reality. Do not create a note for mechanical local edits.

## Workflow

1. Read [the Note contract](../../notes/README.md) and [workflow.md](../../../docs/workflow.md).
2. Classify the decision as `architecture`, `process`, `feature`, `bug-fix`, `simplification`, or `testing`.
3. For an unresolved design, create `.agents/notes/proposed/<kind>/yyyy-mm-dd-topic.md` with Problem, Proposal, Alternatives considered, Acceptance criteria, and Risks.
4. Implement the accepted design in the same change as its code, tests, affected documentation, and note update.
5. Promote a shipped proposal by moving it to `implemented`, changing `Status`, and rewriting Proposal and Acceptance criteria into present-tense Decision and Consequences.
6. Reject an unresolved proposal by moving it to `rejected` and adding one reason to `Status`.
7. Archive an implemented note only when it no longer guides future work. Add `Archived: yyyy-mm-dd`; do not rewrite archived history.

## Rules

- A stable architecture contract belongs in [docs/adr](../../../docs/adr). The note links the ADR and retains implementation trade-offs.
- Implemented notes describe `HEAD`, not the authoring session.
- Update paths, symbols, defaults, and mechanisms whenever the owning implementation changes.
- Every note records genuine alternatives; never invent alternatives to satisfy the format.
- Run `pnpm run check:docs`.
