---
name: trim-process-leakage
description: 清理文档、注释和 Agent Note 中残留的会话过程、评审视角和过期变更叙述。
---

# Trim process leakage

## Detect

Prose leaks process when it is readable only from an authoring session rather than from `HEAD`. Common signals are:

- References to session numbers, review rounds, uncommitted drafts, or local scratch files.
- “This PR changes…”, “we used to…”, “no longer…”, or “a later branch will…”.
- Arguments addressed to a reviewer who has left.
- Control-flow narration of how the agent produced the result.
- Proposal or migration checklists inside an implemented record.

## Workflow

1. Establish the authorized scope; never edit archived notes or recorded evidence to make prose look cleaner.
2. For each passage, list its factual clauses.
3. Restate each durable clause as a current fact at `HEAD`.
4. Delete pure process residue with no factual clause.
5. Move decision history to an Agent Note, ADR, commit, or verification record when it must survive.
6. Update the owning source first, then generated or derived prose.
7. Run `pnpm run check:docs` and `pnpm run check:repository`.

## Do not delete

- Preconditions, failure modes, compatibility promises, security limits, or known gaps.
- Reproducible evidence in `docs/verification/`.
- Alternative designs that prevent a recurring wrong turn.
