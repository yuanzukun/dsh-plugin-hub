---
name: test-reliability
description: 设计和评审涉及网络、外部服务、超时、并发和异步清理的可靠离线测试。
---

# Test reliability

## Design

1. Name the real boundary being replaced: provider HTTP, DNS, clock, filesystem, credential store, or browser.
2. Keep the pipeline, routing, timeout, error projection, and settlement logic real; mock only the nondeterministic boundary.
3. Use deterministic statuses, headers, bodies, clocks, timers, and Abort signals.
4. Give every acquired resource an owner and dispose it on success, failure, timeout, and retry.
5. Test cancellation before, during, and after the observable side effect.
6. Assert external state or returned failure objects; do not trust an agent's self-report.
7. Add a negative control proving the check fails for the intended regression.

## Network tests

- Prefer recorded fixtures and injected fetchers for offline CI.
- Cover timeout, DNS failure, TLS failure, HTTP 429 and 5xx, malformed JSON, oversized bodies, and cancellation.
- Explicitly mark live tests and obtain paid-quota approval before running them.
- Never print credentials, authorization headers, cookies, or credential-bearing URLs.

## Reject

- sleeps used as synchronization.
- Shared ports, mutable global state, or unrestored environment.
- tests that pass when required behavior is absent.
- retry loops masking a flaky fixture.

Run the owning test repeatedly when timing or cancellation is involved, then report the repetition count.
