---
name: project-workflow
description: 通过 Codex 原生 multi-agent 工具编排本仓库的只读开发审计，并把结果交给确定性检查闭环。
---

# Project workflow

## When

Use this skill when the user asks for a project workflow, a broad repository audit, or routing is unclear. Do not use it for a named one-file task.

## Workflow

1. Verify the comparison base, then tell the user the workflow starts up to four read-only subagents and obtain approval; the run consumes model quota.
2. Require the current Codex session to expose `multi_agent_v1__spawn_agent`, `multi_agent_v1__wait_agent`, and `multi_agent_v1__close_agent`. If they are unavailable, say so and proceed directly from the owning documents; do not simulate parallel agents.
3. Spawn four read-only auditors in one dispatch batch:
   - Documentation: `AGENTS.md`, `docs/AGENTS.md`, `docs/README.md`, `docs/workflow.md`, owning documents, and generated catalogs.
   - Architecture: `docs/foundation.md`, `docs/architecture.md`, ADRs, module graph, and callers of changed surfaces.
   - Verification: `docs/testing.md`, package scripts, `scripts/change-scope.mjs`, and tests owning the changed behavior.
   - Simplification: active Agent Notes, protected contracts, duplicate representations, and callers that would remain after deletion.
4. Tell every child: do not modify files; return findings, repository-relative evidence, recommended checks, and uncertainties.
5. Wait once for all children with `multi_agent_v1__wait_agent`, then close every agent with `multi_agent_v1__close_agent`. If a report lacks a fact, inspect the owning file yourself.
6. Treat child reports as hypotheses. Verify each material finding against repository files before editing.
7. Apply the smallest complete change as the parent agent, then run `pnpm run change-scope -- --base <base>` and the recommended deterministic checks.

## Boundaries

- The workflow uses Codex's native agent tools and never enters plugin runtime dependencies.
- Child agents do not modify files or decide completion.
- `change-scope`, hooks, CI, and package scripts remain the executable evidence.
- Do not rerun a passing check merely because a child requested it.
