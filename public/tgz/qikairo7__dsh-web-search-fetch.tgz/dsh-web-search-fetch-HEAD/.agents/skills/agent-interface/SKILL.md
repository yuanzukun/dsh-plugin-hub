---
name: agent-interface
description: 设计模型可见的工具、Schema、Skill 描述和延迟加载上下文，降低误触发和 token 浪费。
---

# Agent interface

## Principles

- State purpose, actions, constraints, and destructive effects before detail.
- Keep one fact in one place and link its owner.
- Defer large references behind a precise retrieval path.
- Prefer bounded results with identifiers for follow-up reads.
- Measure whether deferred context reduces searches and mistakes, not just prompt tokens.

## Tool and schema design

1. Describe caller-visible behavior and returns, not implementation.
2. Put defaults, ranges, units, pairing, and deletion semantics on the owning parameter.
3. Preserve machine-readable names and compatibility obligations.
4. Explain retry, quota, timeout, partial success, and cancellation when callers must choose differently.
5. Add an invalid-input test for each new acceptance rule.

## Skill design

- One skill owns one routing problem.
- Description names explicit triggers and exclusions.
- Body states scope and required source documents, then workflow.
- Link project rules instead of copying them.
- Keep under the budget enforced by `check:docs`.

## Validate

For a new tool or skill, inspect the model-visible description and schema, run its focused tests, and run `pnpm run check:docs`.
