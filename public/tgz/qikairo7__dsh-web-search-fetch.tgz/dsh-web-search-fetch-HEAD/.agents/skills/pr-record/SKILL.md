---
name: pr-record
description: 撰写本仓库 PR 描述，记录动机、变更、验证、风险和 AI 参与阶段。
---

# PR record

## Structure

1. **动机**：用户问题或缺陷，不用实现细节开头。
2. **变更**：按用户可见行为、内部结构、文档和测试分组。
3. **验证**：列出实际运行的命令和结果；写明未运行项及原因。
4. **风险与回滚**：兼容性、配置迁移、额度影响、已知缺口和回滚方式。
5. **AI Usage**：按阶段记录 human-led、pair 或 agent-led，并写代表性和决策归属。

## AI Usage

| 阶段 | 记录 |
| --- | --- |
| 需求与设计 | 谁确定问题、约束、方案和取舍 |
| 实现 | 谁写代码、测试和文档；人修正了什么 |
| 验证 | 谁选择检查、解释失败和判断通过 |
| 评审 | 谁判断评审意见并决定采纳或反驳 |

Do not assign percentages without evidence. Do not claim a human reviewed work that was not reviewed.

## Rules

- Write external GitHub content in Simplified Chinese unless the user requests another language.
- Link the owning issue, Agent Note, ADR, benchmark, or verification record.
- Update the description after review fixes; replace stale claims instead of appending history.
- Never include credentials, local absolute paths, logs, or unpaid API usage.
