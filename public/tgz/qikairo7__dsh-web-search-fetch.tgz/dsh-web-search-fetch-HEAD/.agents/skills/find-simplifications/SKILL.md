---
name: find-simplifications
description: 寻找有证据支持的可删除维护义务，并区分删除、收窄行为和受保护设计。
---

# Find simplifications

## Scope

Use this skill for dead behavior, duplicate representations, speculative configuration, unnecessary adapters, stale tests, and prose that creates maintenance obligations.

## Workflow

1. Read [architecture.md](../../../docs/architecture.md), relevant ADRs, and active Agent Notes before judging a design.
2. Search exact symbols, config keys, discriminants, package exports, and callers with `rg`.
3. Trace each candidate from producer through transformations, authorization, persisted settings, and observable result.
4. Include tests, examples, generated declarations, docs, and package manifests; a declaration is not a shipped consumer.
5. Name what disappears, what remains, what capability is lost, and what compatibility changes.
6. Classify each candidate as removable, narrower public behavior, protected obligation, or insufficient evidence.
7. Record durable decisions with `agent-note-lifecycle`; implement only within the user's authorized scope.

## Reject

- A change only moves the same concept to another layer.
- A new gate is needed to keep duplicate definitions equal.
- Removal breaks a documented compatibility or failure guarantee.
- Deletion saves lines but increases states, branches, or callers.

## Validate

Run tests owning every deleted behavior. For public exports, run build, typecheck, tests, repository check, and distribution check.
