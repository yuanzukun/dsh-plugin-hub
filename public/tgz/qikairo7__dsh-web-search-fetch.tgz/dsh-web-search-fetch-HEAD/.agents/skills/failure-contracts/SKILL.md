---
name: failure-contracts
description: 设计和评审外部请求、IO、配置、预算与编排失败时的类型、状态和恢复语义。
---

# Failure contracts

## Workflow

1. Identify the trust boundary: config, user URL, provider API, subprocess, queue, cache, model JSON, or public API.
2. Define the failure kind, status, retry signal, partial result, and user-visible message.
3. State which component owns recovery: caller, engine adapter, orchestrator, circuit breaker, or user.
4. Preserve the cause and machine-readable fields needed for retry, quota accounting, or diagnostics.
5. Stop dependent work when preconditions no longer hold; do not silently continue with partial state.
6. Add an offline test for each new failure classification and at least one invalid input.

## Rules

- Normalize provider errors at the adapter boundary; do not leak provider-specific prose into orchestration state.
- Timeouts, cancellation, quota exhaustion, rate limits, DNS, TLS, HTTP status, and malformed payloads remain distinguishable when callers act differently.
- Retry only when idempotence and budget semantics are established.
- A caught error names the error and the reason the catch is local.
- Error copy states what happened, what remains true, and how the user recovers.

## Review

Trace both success and failure paths to settlement, circuit state, logging, model output, and persisted settings. Reject `catch` blocks that convert unknown state into success.
