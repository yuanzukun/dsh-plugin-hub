---
name: change-evidence
description: 根据本次 diff 选择最小充分的构建、测试、类型、文档和分发验证。
---

# Change evidence

## Workflow

1. Confirm the branch, working tree, live PR base, and head.
2. Run `pnpm run change-scope -- --base <verified-base>`.
3. Read the returned changed paths and checks. Add only checks justified by a path or semantic risk.
4. Prefer the owning test file or focused test name. Add adjacent tests when a shared contract changes.
5. Run each selected check once; do not repeat a passing check merely because commit or push follows.
6. Report exact commands and observed outcomes. State pending or skipped checks as pending or skipped.

## Selection

- `src/`: build, relevant tests, typecheck, and repository checks.
- `lib/`: rebuild and `check:distribution`.
- `docs/`, `AGENTS.md`, notes, or skills: `check:docs` and `check:repository`.
- Package client surface: `test/package-surface.test.ts`.
- Package or lockfile: build and distribution check.
- Public behavior: update affected docs in the same change.
- Network or external-service behavior: apply `test-reliability`.

## Full rehearsal

Run `pnpm run check` when a change crosses several layers, public packaging is uncertain, or focused checks disagree. CI may still own a broader matrix.
