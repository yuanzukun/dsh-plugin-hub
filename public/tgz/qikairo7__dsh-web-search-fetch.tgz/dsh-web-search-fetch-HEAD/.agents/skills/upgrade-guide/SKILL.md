---
name: upgrade-guide
description: 判断外部可见变更是否破坏既有用法，并为破坏性变更创建版本化迁移指南。
---

# Upgrade guide

## When

Use this skill when a change may break DSH integration, configuration, provider behavior, package entry points, or installation requirements.

## Workflow

1. Read [the upgrade guide contract](../../../docs/upgrade/README.md).
2. Name the old behavior, new behavior, and affected users or callers.
3. If no external action is required, record that conclusion in the PR; do not create a guide.
4. Create `docs/upgrade/v<version>-<topic>.md` using the required sections.
5. Link the guide from the upgrade index.
6. Run `pnpm run check:upgrades` and `pnpm run check:docs`.

## Boundaries

- Do not classify internal refactors or additive optional features as breaking.
- Do not defer a required guide to release preparation.
- Do not rewrite a guide from an already-released version.
