# Agent Note: Adopt Codex multi-agent development orchestration

Status: implemented

## Problem

The repository had useful deterministic gates, but broad development audits depended on one agent manually remembering every review surface. Documentation, architecture, verification, and simplification could be inspected unevenly.

## Decision

Development-side routing uses Codex native multi-agent tools through `project-workflow`. The parent agent spawns four read-only auditors in parallel, waits for their reports, verifies material findings against repository evidence, makes any changes itself, and runs `change-scope` plus deterministic checks. The old `ask-project` routing Skill is removed. The plugin runtime gains no dependency, tool, process, or public interface.

## Alternatives considered

**Retain `ask-project`.** It was cheaper for small tasks but left broad-audit coverage to manual recall.

**Use a DSH Workflow Engine script.** The current Codex host exposes direct multi-agent tools, so a stored JavaScript orchestration script would add a second workflow vocabulary without adding capability.

**Replace package scripts and CI with agent orchestration.** Agents coordinate review; they do not own deterministic shell evidence. Replacing gates would let model reports substitute for checks.

**Run children as writers.** Concurrent writers would contend on one worktree and obscure attribution.

## Consequences

Broad audits get four independent review surfaces while one parent agent owns edits and final judgement. Child agents are advisory and read-only. Codex sessions without native multi-agent tools report the limitation instead of simulating the workflow. Deterministic gates remain authoritative. A one-child read-only smoke test on the current Codex host confirmed direct agent summoning; the four-lane workflow itself remains ready for an explicitly approved full run.

## Testing

`test/project-workflow.test.mjs` checks the four audit lanes, required Codex tool names, read-only boundary, and deterministic evidence path. A one-child read-only Codex agent verified the contract by inspection. Repository checks cover Skill metadata, routing documentation, and repository hygiene.
