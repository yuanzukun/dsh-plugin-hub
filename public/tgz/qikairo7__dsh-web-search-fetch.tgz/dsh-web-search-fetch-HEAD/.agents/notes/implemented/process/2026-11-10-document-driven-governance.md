# Agent Note: Adopt document-driven repository governance

Status: implemented

## Problem

仓库已有架构文档、ADR 和测试门禁，但开发流程缺少一个统一生命周期来记录提案、实施取舍和被否决方案。重复讨论的风险会随着引擎、提取和配置面增加而上升。

## Decision

仓库采用项目级文档驱动治理：`docs/AGENTS.md` 定义文档层级、写作规则、生成物和预算；`docs/foundation.md` 是产品级当前契约的入口，常设文档从它分流；`docs/engine-catalog.md`、设置页服务块和 `docs/config-catalog.md` 分别由 registry 与 Config 生成；`docs/testing.md` 和 `docs/cookbook/` 分别拥有测试策略和操作指南；`docs/upgrade/` 只保存外部可见破坏性变更的迁移指南。Agent Note 记录长期决策和取舍，Skill 只做工作流路由，`check:docs` 与 `change-scope` 提供可执行约束。架构契约仍以 `docs/adr/` 为最终归属；Agent Note 负责提案、流程决策和实施期取舍。

## Alternatives considered

**只使用 ADR。** ADR 适合稳定架构决策，不适合提案、被否决方案和开发流程；继续只使用 ADR 会缺少生命周期。

**复制 DeepSeek Harness 的完整文档系统。** DSH 的双语配对、全量生成目录和网站投影服务其仓库规模。本仓库保留其事实归属、Note 生命周期和最小验证思想，只生成引擎目录这一份可执行投影，不复制其余基础设施。

**把所有内容继续放在 `architecture.md`。** 架构文档同时承担产品不变量、节点模型、模块图和调用顺序，读者和评审会混淆“必须守住的约束”与“实现位置”。地基文档把前者固定为入口，架构文档只保留后者。

**使用通用 spec-driven 工具。** 单次 change 工具不能维护仓库长期决策和文档同步；本仓库需要的是长期治理，而不是另一个任务清单。

## Consequences

长期决策必须说明备选方案和后果，减少重复讨论。文档、代码、测试、升级指南和 Note 在同一个变更中演进。`pnpm run check` 会运行 `check:docs`；流程文件、地基文档、测试策略、cookbook 和 Skill 本身也受预算与入口约束。升级指南结构由 `check:upgrades` 校验，但是否破坏仍由设计者和评审判断，门禁不猜测语义。
