# Agent Note: Adopt document-driven repository governance

Status: implemented

## Problem

仓库已有架构文档、ADR 和测试门禁，但开发流程缺少一个统一生命周期来记录提案、实施取舍和被否决方案。重复讨论的风险会随着引擎、提取和配置面增加而上升。

## Decision

仓库采用项目级文档驱动治理：常设文档描述当前契约，Agent Note 记录长期决策和取舍，Skill 只做工作流路由，`check:docs` 与 `change-scope` 提供可执行约束。架构契约仍以 `docs/adr/` 为最终归属；Agent Note 负责提案、流程决策和实施期取舍。

## Alternatives considered

**只使用 ADR。** ADR 适合稳定架构决策，不适合提案、被否决方案和开发流程；继续只使用 ADR 会缺少生命周期。

**复制 DeepSeek Harness 的完整文档系统。** DSH 的双语配对、生成目录和网站投影服务其仓库规模。本仓库保留其事实归属、Note 生命周期和最小验证思想，不复制不适用的基础设施。

**使用通用 spec-driven 工具。** 单次 change 工具不能维护仓库长期决策和文档同步；本仓库需要的是长期治理，而不是另一个任务清单。

## Consequences

长期决策必须说明备选方案和后果，减少重复讨论。文档、代码、测试和 Note 在同一个变更中演进。`pnpm run check` 会运行 `check:docs`；流程文件本身也受预算和格式约束。
