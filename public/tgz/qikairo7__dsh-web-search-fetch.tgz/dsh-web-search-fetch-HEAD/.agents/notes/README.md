# Agent Notes

Agent Note 记录会长期影响本仓库的流程决策、实施取舍和被否决方案。它保存代码、测试和常设文档无法表达的“为什么”和“放弃了什么”。

## 路径

```text
.agents/notes/{lifecycle}/{kind}/yyyy-mm-dd-topic.md
```

生命周期为 `proposed`、`implemented`、`rejected` 或 `archived`。类型为 `architecture`、`process`、`feature`、`bug-fix`、`simplification` 或 `testing`。

## 格式

文件第一行必须是：

```markdown
# Agent Note: <标题>
```

第 2 行和第 4 行必须是空行；第 3 行必须是唯一的 `Status:` 行。`proposed` 与 `implemented` 只写状态；`rejected` 写 `Status: rejected — <一句话原因>`；`archived` 保持 `Status: implemented`，第 5 行写 `Archived: yyyy-mm-dd`。正文第一个二级标题必须是 `## Problem`。

### proposed / rejected

必需章节：

```markdown
## Problem
## Proposal
## Alternatives considered
## Acceptance criteria
## Risks
```

### implemented / archived

必需章节：

```markdown
## Problem
## Decision
## Alternatives considered
## Consequences
```

`implemented` 描述当前事实，不保留提案清单。路径、符号、默认值和机制变化时，在同一个代码变更中更新对应 Note。

## 何时写

- 新增长期流程、验证策略或维护义务。
- 一个实现有多个可信方案，后续可能被重新讨论。
- 明确否决一个 tempting 方案。
- 架构决策还未稳定到应写入 ADR。

不写：

- 机械局部修改。
- 没有替代方案的过程记录。
- 临时验收报告。
- 可以直接由代码、测试或常设文档表达的当前行为。

## 归档

当一个 `implemented` Note 不再指导未来工作，把它完整移动到 `archived/<kind>/`，添加 `Archived:` 行并修复链接。归档记录是冻结历史，不再修改。

归档后运行 `pnpm run freeze:archived`，提交更新的 `scripts/archived-notes-freeze.json`。
