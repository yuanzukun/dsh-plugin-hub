/**
 * Pure projections for the engine catalog.
 *
 * The generator reads the compiled registry and writes the Markdown catalog.
 */

/**
 * Build the engine-catalog data.
 * @param {readonly import('../src/engines/contract.js').EngineManifest[]} manifests
 * @param {{ readonly model: string }} rerankService
 */
export function buildEngineCatalog(manifests, rerankService) {
  return {
    manifests,
    rerankModel: rerankService.model,
  }
}

/**
 * Render the generated Markdown catalog.
 * @param {ReturnType<typeof buildEngineCatalog>} catalog
 */
export function renderCatalog(catalog) {
  const engineRows = catalog.manifests.map(manifest => {
    const keylessScope = manifest.keyless !== true
      ? '—'
      : manifest.keylessCapabilities === undefined
        ? '全部'
        : manifest.keylessCapabilities.map(capabilityLabel).join('、')
    return `| ${code(manifest.id)} | ${manifest.label} | ${manifest.summary ?? '—'} | ${manifest.capabilities.map(capabilityLabel).join('、')} | ${authLabel(manifest.auth)} | ${manifest.credentialPath === undefined ? '—' : code(manifest.credentialPath)} | ${yesNo(manifest.enabledByDefault)} | ${yesNo(manifest.free)} | ${yesNo(manifest.keyless)} | ${keylessScope} | ${quotaLabel(manifest.quotaPeriod)} |`
  })
  const endpointRows = catalog.manifests.map(manifest =>
    `| ${code(manifest.id)} | ${endpoint(manifest.endpoints.search)} | ${endpoint(manifest.endpoints.fetch)} | ${endpoint(manifest.endpoints.quota)} |`)

  return `# 引擎目录

本文件由 \`src/engines/registry.ts\` 生成，不要手工编辑。运行 \`pnpm run generate:engines\` 更新。

## 搜索与提取引擎

| id | 名称 | 说明 | 能力 | 鉴权 | 凭证路径 | 默认启用 | 免费额度 | 免密钥 | 免密钥能力面 | 额度周期 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
${engineRows.join('\n')}

## 端点

| id | 搜索 | 提取 | 额度 |
| --- | --- | --- | --- |
${endpointRows.join('\n')}

部分引擎会在适配器内选择子路径或额外端点；上表只列 manifest 登记的主端点，行为见 [configuration.md](configuration.md) 和适配器测试。

## 直接 HTTP

直接 HTTP 是本地静态提取器，不属于 \`ENGINE_MANIFESTS\`；默认启用，只处理静态文件。

## 重排

SiliconFlow 重排不是搜索引擎，不进入 \`ENGINE_MANIFESTS\`；它与 \`RERANK_SERVICE\` 单独配置。

## 校验

运行 \`pnpm run check:engines\` 校验本文件是否仍与 registry 一致。
`
}

function code(value) {
  return `\`${value}\``
}

function endpoint(value) {
  return value === undefined ? '—' : code(value)
}

function yesNo(value) {
  return value === true ? '是' : '否'
}

function capabilityLabel(capability) {
  switch (capability) {
    case 'search':
      return '搜索'
    case 'fetch':
      return '提取'
    case 'aihot-api':
      return 'AIHOT API'
    default:
      throw new Error(`unknown capability ${capability}`)
  }
}

function authLabel(auth) {
  switch (auth) {
    case 'anonymous':
      return '匿名'
    case 'key':
      return '必须凭证'
    case 'keyless-fallback':
      return '免密钥回退'
    default:
      throw new Error(`unknown auth mode ${auth}`)
  }
}

function quotaLabel(period) {
  switch (period) {
    case 'daily-utc':
      return '每日（UTC）'
    case 'daily-bj':
      return '每日（北京时间）'
    case 'monthly':
      return '每月'
    case 'none':
    case undefined:
      return '无'
    default:
      throw new Error(`unknown quota period ${period}`)
  }
}
