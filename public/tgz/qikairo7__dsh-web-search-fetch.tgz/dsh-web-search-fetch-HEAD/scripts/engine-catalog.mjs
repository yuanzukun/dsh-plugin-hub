/**
 * Pure projections for the engine catalog.
 *
 * The generator reads the compiled registry, passes the manifests through
 * these functions, and writes the Markdown catalog plus the client surface.
 */

const INDENT = '        '
export const GENERATED_START = `${INDENT}//#region generated-engine-surface`
export const GENERATED_END = `${INDENT}//#endregion generated-engine-surface`

const HTTP_SERVICE = Object.freeze({
  id: 'http',
  capability: 'staticFetch',
  capabilities: Object.freeze(['fetch']),
  keys: Object.freeze([]),
  free: true,
  keyless: true,
  auth: 'anonymous',
  enabledByDefault: true,
})

/**
 * Build the data shared by the Markdown catalog and the client surface.
 * @param {readonly import('../src/engines/contract.js').EngineManifest[]} manifests
 * @param {{ readonly model: string }} rerankService
 */
export function buildEngineCatalog(manifests, rerankService) {
  return {
    manifests,
    services: [
      ...manifests.map(toService),
      { ...HTTP_SERVICE, capabilities: [...HTTP_SERVICE.capabilities], keys: [] },
    ],
    anonymousServiceIds: manifests
      .filter(manifest => manifest.auth === 'keyless-fallback')
      .map(manifest => manifest.id),
    quotaPeriods: Object.fromEntries(manifests.map(manifest => [manifest.id, manifest.quotaPeriod ?? 'none'])),
    quotaOfficialIds: manifests
      .filter(manifest => manifest.endpoints.quota !== undefined)
      .map(manifest => manifest.id),
    rerankModel: rerankService.model,
  }
}

/** @param {import('../src/engines/contract.js').EngineManifest} manifest */
function toService(manifest) {
  return {
    id: manifest.id,
    capability: capabilityKey(manifest),
    capabilities: [...manifest.capabilities],
    keys: manifest.credentialPath === undefined ? [] : [manifest.credentialPath],
    free: manifest.free === true,
    keyless: manifest.keyless === true,
    ...(manifest.keylessCapabilities === undefined
      ? {}
      : { keylessCapabilities: [...manifest.keylessCapabilities] }),
    auth: manifest.auth,
    enabledByDefault: manifest.enabledByDefault === true,
  }
}

/** @param {import('../src/engines/contract.js').EngineManifest} manifest */
function capabilityKey(manifest) {
  if (manifest.capabilities.includes('aihot-api')) return 'aiNews'
  const search = manifest.capabilities.includes('search')
  const fetch = manifest.capabilities.includes('fetch')
  if (search && fetch) return 'searchFetch'
  if (search) return 'search'
  if (fetch) return 'fetch'
  throw new Error(`engine ${manifest.id} has no supported capability`)
}

/**
 * Render the generated client block, including its markers.
 * @param {ReturnType<typeof buildEngineCatalog>} catalog
 */
export function renderClientSurface(catalog) {
  return [
    GENERATED_START,
    literal('RERANK_MODEL', catalog.rerankModel),
    literal('ANONYMOUS_SERVICE_IDS', catalog.anonymousServiceIds),
    literal('SERVICES', catalog.services),
    literal('QUOTA_PERIODS', catalog.quotaPeriods),
    literal('QUOTA_OFFICIAL_IDS', catalog.quotaOfficialIds),
    GENERATED_END,
  ].join('\n')
}

/** @param {string} name @param {unknown} value */
function literal(name, value) {
  const parts = JSON.stringify(value, null, 2).split('\n')
  const lines = [`${INDENT}const ${name} = ${parts.shift()}`]
  lines.push(...parts.map(line => `${INDENT}${line}`))
  lines[lines.length - 1] += ';'
  return lines.join('\n')
}

/**
 * Replace the marked client region and leave the rest of the file untouched.
 * @param {string} source
 * @param {string} block
 */
export function replaceGeneratedRegion(source, block) {
  const start = source.indexOf(GENERATED_START)
  const end = source.indexOf(GENERATED_END)
  if (start < 0 || end < start) {
    throw new Error('client/index.js is missing generated-engine-surface markers')
  }
  return `${source.slice(0, start)}${block}${source.slice(end + GENERATED_END.length)}`
}

/**
 * Render the generated Markdown catalog.
 * @param {ReturnType<typeof buildEngineCatalog>} catalog
 */
export function renderCatalog(catalog) {
  const engineRows = catalog.manifests.map(manifest => {
    const keylessScope = manifest.keyless !== true
      ? '—'
      : manifest.keylessCapabilities === undefined
        ? '全部'
        : manifest.keylessCapabilities.map(capabilityLabel).join('、')
    return `| ${code(manifest.id)} | ${manifest.label} | ${manifest.summary ?? '—'} | ${manifest.capabilities.map(capabilityLabel).join('、')} | ${authLabel(manifest.auth)} | ${manifest.credentialPath === undefined ? '—' : code(manifest.credentialPath)} | ${yesNo(manifest.enabledByDefault)} | ${yesNo(manifest.free)} | ${yesNo(manifest.keyless)} | ${keylessScope} | ${quotaLabel(manifest.quotaPeriod)} |`
  })
  const endpointRows = catalog.manifests.map(manifest =>
    `| ${code(manifest.id)} | ${endpoint(manifest.endpoints.search)} | ${endpoint(manifest.endpoints.fetch)} | ${endpoint(manifest.endpoints.quota)} |`)

  return `# 引擎目录

本文件与 \`client/index.js\` 的服务块由 \`src/engines/registry.ts\` 生成，不要手工编辑。运行 \`pnpm run generate:engines\` 更新。

## 搜索与提取引擎

| id | 名称 | 说明 | 能力 | 鉴权 | 凭证路径 | 默认启用 | 免费额度 | 免密钥 | 免密钥能力面 | 额度周期 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
${engineRows.join('\n')}

## 端点

| id | 搜索 | 提取 | 额度 |
| --- | --- | --- | --- |
${endpointRows.join('\n')}

部分引擎会在适配器内选择子路径或额外端点；上表只列 manifest 登记的主端点，行为见 [configuration.md](configuration.md) 和适配器测试。

## 直接 HTTP

直接 HTTP 是本地静态提取器，不属于 \`ENGINE_MANIFESTS\`；设置页单独列出，默认启用，只处理静态文件。

## 重排

SiliconFlow 重排不是搜索引擎，不进入 \`ENGINE_MANIFESTS\`；它与 \`RERANK_SERVICE\` 单独配置。

## 校验

运行 \`pnpm run check:engines\` 校验本文件与设置页生成块是否仍与 registry 一致。
`
}

function code(value) {
  return `\`${value}\``
}

function endpoint(value) {
  return value === undefined ? '—' : code(value)
}

function yesNo(value) {
  return value === true ? '是' : '否'
}

function capabilityLabel(capability) {
  switch (capability) {
    case 'search':
      return '搜索'
    case 'fetch':
      return '提取'
    case 'aihot-api':
      return 'AIHOT API'
    default:
      throw new Error(`unknown capability ${capability}`)
  }
}

function authLabel(auth) {
  switch (auth) {
    case 'anonymous':
      return '匿名'
    case 'key':
      return '必须凭证'
    case 'keyless-fallback':
      return '免密钥回退'
    default:
      throw new Error(`unknown auth mode ${auth}`)
  }
}

function quotaLabel(period) {
  switch (period) {
    case 'daily-utc':
      return '每日（UTC）'
    case 'daily-bj':
      return '每日（北京时间）'
    case 'monthly':
      return '每月'
    case 'none':
    case undefined:
      return '无'
    default:
      throw new Error(`unknown quota period ${period}`)
  }
}
