import { readFileSync, readdirSync, statSync } from 'node:fs'
import { dirname, relative, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { markdownDestinations } from './markdown-links.mjs'

const root = fileURLToPath(new URL('../', import.meta.url))
const kinds = new Set(['standard', 'index', 'decision', 'reference', 'architecture', 'generated', 'tutorial', 'policy', 'contract', 'incident-policy', 'evidence-policy', 'workflow'])

function files(dir) {
  return readdirSync(dir, { withFileTypes: true }).flatMap(entry => {
    const path = resolve(dir, entry.name)
    if (entry.isDirectory()) return files(path)
    return entry.name.endsWith('.md') ? [path] : []
  })
}

function authoredFiles() {
  return files(resolve(root, 'docs')).filter(path => {
    const name = relative(root, path).split('\\').join('/')
    return name === 'docs/verification/README.md' || !name.startsWith('docs/verification/')
  })
}

export function validateDocKinds(paths, manifest) {
  const errors = []
  const expected = new Set(paths)
  for (const path of paths) {
    const kind = manifest[path]
    if (kind === undefined) errors.push(`${path}: missing kind in docs/doc-kinds.json`)
    else if (!kinds.has(kind)) errors.push(`${path}: unknown kind ${kind}`)
  }
  for (const path of Object.keys(manifest)) {
    if (!expected.has(path)) errors.push(`${path}: stale kind entry`)
  }
  return errors
}

export function validateDocIndex(paths, indexes, baseRoot = root) {
  const errors = []
  const linked = new Set()
  for (const [index, source] of Object.entries(indexes)) {
    for (const destination of markdownDestinations(source)) {
      if (/^[a-z][a-z\d+.-]*:/i.test(destination.url) || destination.url.startsWith('/')) continue
      const target = resolve(dirname(index), destination.url.replace(/[#?].*$/, ''))
      linked.add(relative(baseRoot, target).split('\\').join('/'))
    }
  }
  for (const path of paths) {
    if (path !== 'docs/README.md' && !linked.has(path)) errors.push(`${path}: not linked from docs/README.md or docs/adr/README.md`)
  }
  return errors
}

export function validateDocKindExemplars(kindManifest, exemplars, paths) {
  const errors = []
  const used = new Set(Object.values(kindManifest))
  const available = new Set(paths)
  for (const kind of used) {
    const exemplar = exemplars[kind]
    if (exemplar === undefined) errors.push(`kind ${kind}: missing exemplar in docs/doc-kind-exemplars.json`)
    else if (!available.has(exemplar)) errors.push(`kind ${kind}: exemplar does not exist: ${exemplar}`)
  }
  for (const kind of Object.keys(exemplars)) {
    if (!used.has(kind)) errors.push(`kind ${kind}: exemplar has no authored document`)
  }
  return errors
}

function run() {
  const paths = authoredFiles().map(path => relative(root, path).split('\\').join('/'))
  const manifest = JSON.parse(readFileSync(resolve(root, 'docs/doc-kinds.json'), 'utf8'))
  const exemplars = JSON.parse(readFileSync(resolve(root, 'docs/doc-kind-exemplars.json'), 'utf8'))
  const indexes = Object.fromEntries(['docs/README.md', 'docs/adr/README.md']
    .map(path => [resolve(root, path), readFileSync(resolve(root, path), 'utf8')]))
  const errors = [
    ...validateDocKinds(paths, manifest),
    ...validateDocIndex(paths, indexes),
    ...validateDocKindExemplars(manifest, exemplars, paths),
  ]
  if (errors.length > 0) {
    for (const error of errors) console.error(error)
    process.exitCode = 1
    return
  }
  console.log(`Documentation index/kind check passed (${paths.length} documents).`)
}

if (process.argv[1] === fileURLToPath(import.meta.url)) run()
