import { existsSync, readFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { githubSlug, markdownHeadingLines, parseMarkdown, visitMarkdown } from './markdown.mjs'

export function markdownDestinations(source) {
  const destinations = []
  visitMarkdown(parseMarkdown(source), node => {
    if ((node.type === 'link' || node.type === 'image' || node.type === 'definition') && 'url' in node) {
      destinations.push({ url: node.url, line: node.position?.start.line ?? 0 })
    }
  })
  return destinations
}

export function markdownAnchors(source) {
  const tree = parseMarkdown(source)
  const anchors = new Set()
  const counts = new Map()
  for (const heading of markdownHeadingLines(source, tree)) {
    const base = githubSlug(heading.text)
    let result = base
    let bump = counts.get(base) ?? 0
    while (anchors.has(result)) {
      bump += 1
      result = `${base}-${bump}`
    }
    counts.set(base, bump)
    anchors.add(result)
  }
  visitMarkdown(tree, node => {
    if (node.type !== 'html') return
    const html = htmlOutsideComments(node.value)
    for (const match of html.matchAll(/<a id="([^"]+)"/g)) anchors.add(match[1])
  })
  return anchors
}

function htmlOutsideComments(html) {
  let outside = ''
  let index = 0
  while (index < html.length) {
    const start = html.indexOf('<!--', index)
    if (start < 0) return outside + html.slice(index)
    outside += html.slice(index, start)
    const end = html.indexOf('-->', start + 4)
    if (end < 0) return outside
    index = end + 3
  }
  return outside
}

function isExternal(url) {
  if (url.startsWith('//') || url.startsWith('/')) return true
  return /^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(url)
}

function pathPart(url) {
  const raw = url.replace(/[#?].*$/, '')
  try {
    return decodeURIComponent(raw)
  } catch {
    return raw
  }
}

function fragmentPart(url) {
  const hash = url.indexOf('#')
  if (hash < 0) return null
  const raw = url.slice(hash + 1).replace(/\?.*$/, '')
  try {
    return decodeURIComponent(raw)
  } catch {
    return raw
  }
}

/** @param {string} sourcePath @param {string} source @param {Map<string, string>} documentCache */
export function findBrokenLinks(sourcePath, source, documentCache = new Map()) {
  const violations = []
  const directory = dirname(sourcePath)
  for (const { url, line } of markdownDestinations(source)) {
    if (isExternal(url)) continue
    const target = pathPart(url)
    const resolved = target === '' ? sourcePath : resolve(directory, target)
    if (!existsSync(resolved)) {
      violations.push({ line, url, reason: 'target' })
      continue
    }
    const fragment = fragmentPart(url)
    if (fragment === null || !resolved.endsWith('.md')) continue
    const targetSource = documentCache.get(resolved) ?? readFileSync(resolved, 'utf8')
    documentCache.set(resolved, targetSource)
    if (!markdownAnchors(targetSource).has(fragment)) violations.push({ line, url, reason: 'anchor' })
  }
  return violations
}
