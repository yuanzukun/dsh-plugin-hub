import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('../', import.meta.url))

const pairs = [
  {
    trigger: 'src/engines/registry.ts',
    artifacts: ['docs/engine-catalog.md', 'client/index.js'],
  },
  {
    trigger: 'src/index.ts',
    artifacts: ['docs/config-catalog.md'],
  },
]

/** @param {{staged: Set<string>, changed: Set<string>}} input */
export function findMissingStaged({ staged, changed }) {
  const errors = []
  for (const { trigger, artifacts } of pairs) {
    if (!staged.has(trigger)) continue
    for (const artifact of artifacts) {
      if (changed.has(artifact) && !staged.has(artifact)) {
        errors.push(`${artifact}: stage the regenerated file with ${trigger}`)
      }
    }
  }
  if ([...staged].some((path) => path.startsWith('src/'))) {
    if (changed.has('docs/error-catalog.md') && !staged.has('docs/error-catalog.md')) {
      errors.push('docs/error-catalog.md: stage the regenerated file with src changes')
    }
    if (changed.has('docs/module-graph.md') && !staged.has('docs/module-graph.md')) {
      errors.push('docs/module-graph.md: stage the regenerated file with src changes')
    }
    for (const path of changed) {
      if (path.startsWith('lib/') && !staged.has(path)) {
        errors.push(`${path}: stage the rebuilt lib file with src changes`)
      }
    }
  }
  if (staged.has('package.json') || staged.has('pnpm-lock.yaml')) {
    if (changed.has('docs/dsh-web-interface-fields.json') && !staged.has('docs/dsh-web-interface-fields.json')) {
      errors.push('docs/dsh-web-interface-fields.json: stage the regenerated file with dependency changes')
    }
  }
  return errors
}

function names(args) {
  return new Set(
    execFileSync('git', args, { cwd: root, encoding: 'utf8' })
      .split(/\r?\n/)
      .filter(Boolean),
  )
}

function main() {
  const staged = names(['diff', '--cached', '--name-only', '--diff-filter=ACMR'])
  const changed = new Set([
    ...names(['diff', '--name-only']),
    ...names(['ls-files', '--others', '--exclude-standard']),
  ])
  const errors = findMissingStaged({ staged, changed })
  if (errors.length > 0) {
    for (const error of errors) console.error(error)
    process.exitCode = 1
    return
  }
  console.log('Staged generated artifacts check passed.')
}

if (process.argv[1] === fileURLToPath(import.meta.url)) main()
