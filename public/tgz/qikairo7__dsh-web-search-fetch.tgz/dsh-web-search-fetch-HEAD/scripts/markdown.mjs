import { fromMarkdown } from 'mdast-util-from-markdown'
import { gfmFromMarkdown } from 'mdast-util-gfm'
import { gfm } from 'micromark-extension-gfm'

export function parseMarkdown(source) {
  return fromMarkdown(source, {
    extensions: [gfm()],
    mdastExtensions: [gfmFromMarkdown()],
  })
}

export function visitMarkdown(node, visit) {
  if (visit(node) === false) return
  if ('children' in node) {
    for (const child of node.children) visitMarkdown(child, visit)
  }
}

export function markdownHeadingLines(source, tree = parseMarkdown(source)) {
  const headings = []
  visitMarkdown(tree, (node) => {
    if (node.type === 'heading' && node.position) {
      headings.push({
        line: node.position.start.line,
        text: textValue(node),
      })
    }
  })
  return headings
}

function textValue(node) {
  if ('value' in node) return node.value
  if ('children' in node) return node.children.map(textValue).join('')
  return ''
}

export function githubSlug(heading) {
  return heading.toLowerCase().replace(/[^\p{L}\p{N}_ -]/gu, '').replaceAll(' ', '-')
}
