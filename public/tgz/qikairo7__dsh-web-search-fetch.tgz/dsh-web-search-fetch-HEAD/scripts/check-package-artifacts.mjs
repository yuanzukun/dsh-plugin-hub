import { spawnSync } from 'node:child_process'
import { existsSync, readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('../', import.meta.url))
const baseFiles = new Set([
  'package.json',
  'README.md',
  'CONTRIBUTING.md',
  'SECURITY.md',
  'LICENSE',
  'NOTICE',
  'cordis.patch.yml',
  'docs/dependency-inventory.json',
  'docs/dsh-web-interface-fields.json',
])

export function validatePackageArtifacts(paths, allowedAssets) {
  const allowed = new Set(allowedAssets)
  const packedAssets = new Set(paths.filter(path => path.startsWith('docs/assets/')))
  const errors = []
  for (const asset of allowed) {
    if (!packedAssets.has(asset)) errors.push(`${asset}: allowlisted package asset is missing`)
  }
  for (const path of paths) {
    const isAsset = path.startsWith('docs/assets/')
    const allowedBase = baseFiles.has(path)
      || /^lib\/.+\.d\.ts$/.test(path)
      || /^lib\/.+\.js$/.test(path)
      || /^docs\/[^/]+\.md$/.test(path)
      || /^docs\/upgrade\/[^/]+\.md$/.test(path)
    if (isAsset) {
      if (!allowed.has(path)) errors.push(`${path}: package asset is not allowlisted`)
    } else if (!allowedBase) {
      errors.push(`${path}: unexpected package artifact`)
    }
  }
  return [...new Set(errors)]
}

function npmInvocation(args) {
  const cli = join(dirname(process.execPath), 'node_modules', 'npm', 'bin', 'npm-cli.js')
  return existsSync(cli)
    ? { command: process.execPath, args: [cli, ...args] }
    : { command: 'npm', args }
}

function packedPaths() {
  const npm = npmInvocation(['pack', '--dry-run', '--json', '--ignore-scripts'])
  const result = spawnSync(npm.command, npm.args, {
    cwd: root,
    encoding: 'utf8',
    maxBuffer: 16 * 1024 * 1024,
  })
  if (result.error) throw result.error
  if (result.status !== 0) {
    throw new Error(`npm pack failed with exit ${result.status}: ${result.stderr}`)
  }
  const manifest = JSON.parse(result.stdout)
  return manifest[0]?.files?.map(file => file.path) ?? manifest.files?.map(file => file.path) ?? []
}

function main() {
  const allowedAssets = JSON.parse(readFileSync(join(root, 'scripts/package-artifacts.json'), 'utf8'))
  const errors = validatePackageArtifacts(packedPaths(), allowedAssets)
  if (errors.length > 0) {
    for (const error of errors) console.error(error)
    process.exitCode = 1
    return
  }
  console.log('Package artifact allowlist check passed.')
}

if (process.argv[1] === fileURLToPath(import.meta.url)) main()
