import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

import { ENGINE_MANIFESTS, RERANK_SERVICE } from '../lib/engines/registry.js'
import { buildEngineCatalog, renderCatalog } from './engine-catalog.mjs'

const root = fileURLToPath(new URL('../', import.meta.url))
const catalogPath = join(root, 'docs/engine-catalog.md')
const check = process.argv.includes('--check')

const catalog = buildEngineCatalog(ENGINE_MANIFESTS, RERANK_SERVICE)
const catalogText = renderCatalog(catalog)

if (check) {
  const errors = []
  if (!existsSync(catalogPath)) errors.push('docs/engine-catalog.md is missing')
  else if (readFileSync(catalogPath, 'utf8') !== catalogText) errors.push('docs/engine-catalog.md is stale')

  for (const [file, link] of [
    ['README.md', 'docs/engine-catalog.md'],
    ['docs/configuration.md', 'engine-catalog.md'],
    ['docs/README.md', 'engine-catalog.md'],
  ]) {
    if (!readFileSync(join(root, file), 'utf8').includes(link)) {
      errors.push(`${file}: must link ${link}`)
    }
  }

  if (errors.length > 0) {
    for (const error of errors) console.error(error)
    console.error('Run pnpm run generate:engines and commit the generated file.')
    process.exitCode = 1
  } else {
    console.log('Engine catalog check passed.')
  }
} else {
  writeFileSync(catalogPath, catalogText)
  console.log('Engine catalog generated: docs/engine-catalog.md')
}
