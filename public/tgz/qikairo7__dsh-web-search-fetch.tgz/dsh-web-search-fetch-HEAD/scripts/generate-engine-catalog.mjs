import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

import { ENGINE_MANIFESTS, RERANK_SERVICE } from '../lib/engines/registry.js'
import {
  buildEngineCatalog,
  renderCatalog,
  renderClientSurface,
  replaceGeneratedRegion,
} from './engine-catalog.mjs'

const root = fileURLToPath(new URL('../', import.meta.url))
const catalogPath = join(root, 'docs/engine-catalog.md')
const clientPath = join(root, 'client/index.js')
const check = process.argv.includes('--check')

const catalog = buildEngineCatalog(ENGINE_MANIFESTS, RERANK_SERVICE)
const catalogText = renderCatalog(catalog)
const clientSource = readFileSync(clientPath, 'utf8')
const clientText = replaceGeneratedRegion(clientSource, renderClientSurface(catalog))

if (check) {
  const errors = []
  if (!existsSync(catalogPath)) errors.push('docs/engine-catalog.md is missing')
  else if (readFileSync(catalogPath, 'utf8') !== catalogText) errors.push('docs/engine-catalog.md is stale')
  if (clientText !== clientSource) errors.push('client/index.js generated engine surface is stale')

  for (const [file, link] of [
    ['README.md', 'docs/engine-catalog.md'],
    ['docs/configuration.md', 'engine-catalog.md'],
    ['docs/README.md', 'engine-catalog.md'],
  ]) {
    if (!readFileSync(join(root, file), 'utf8').includes(link)) {
      errors.push(`${file}: must link ${link}`)
    }
  }

  if (errors.length > 0) {
    for (const error of errors) console.error(error)
    console.error('Run pnpm run generate:engines and commit the generated files.')
    process.exitCode = 1
  } else {
    console.log('Engine catalog check passed.')
  }
} else {
  writeFileSync(catalogPath, catalogText)
  writeFileSync(clientPath, clientText)
  console.log('Engine catalog generated: docs/engine-catalog.md, client/index.js')
}
