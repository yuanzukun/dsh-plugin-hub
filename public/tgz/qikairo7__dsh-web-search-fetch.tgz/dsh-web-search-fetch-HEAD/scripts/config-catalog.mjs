/**
 * Pure projection for the full Config schema catalog.
 *
 * The generator reads the compiled Config schema and writes
 * docs/config-catalog.md. Leaf fields must carry a description.
 */

/** @param {{ readonly dict?: Record<string, unknown> }} schema */
export function collectConfigFields(schema) {
  const fields = []
  walk(schema, [], fields)
  if (fields.length === 0) throw new Error('Config has no fields')
  return fields
}

function walk(node, path, fields) {
  const children = Object.entries(node?.dict ?? {})
  if (children.length === 0) {
    if (path.length === 0) return
    const meta = node?.meta ?? {}
    if (typeof meta.description !== 'string' || meta.description.trim().length === 0) {
      throw new Error(`Config field ${path.join('.')} must have a description`)
    }
    fields.push({
      path: path.join('.'),
      type: typeLabel(node),
      default: formatDefault(meta.default),
      constraint: formatConstraint(meta),
      description: meta.description,
    })
    return
  }
  for (const [key, child] of children) walk(child, [...path, key], fields)
}

function typeLabel(node) {
  switch (node?.type) {
    case 'number':
      return 'number'
    case 'boolean':
      return 'boolean'
    case 'string':
      return 'string'
    case 'dict':
      return '{ [key: string]: boolean }'
    default:
      return String(node).replaceAll('|', '/')
  }
}

function formatDefault(value) {
  if (value === undefined) return '未设置'
  if (typeof value === 'string') return value === '' ? '空' : code(value)
  return code(JSON.stringify(value))
}

function formatConstraint(meta) {
  if (meta.role === 'credential-ref') return '凭证引用'
  if (typeof meta.min === 'number' && typeof meta.max === 'number') return `${meta.min}–${meta.max}`
  if (typeof meta.min === 'number') return `≥ ${meta.min}`
  if (typeof meta.max === 'number') return `≤ ${meta.max}`
  return '—'
}

/** @param {{ path: string, type: string, default: string, constraint: string, description: string }[]} fields */
export function renderConfigCatalog(fields) {
  const rows = fields.map(field =>
    `| ${code(field.path)} | ${code(field.type)} | ${field.default} | ${field.constraint} | ${escapeCell(field.description)} |`)
  return `# 配置目录

本文件由 \`src/index.ts\` 的 \`Config\` schema 生成，不要手工编辑。运行 \`pnpm run generate:config\` 更新。

| 字段 | 类型 | 默认 | 约束 | 说明 |
| --- | --- | --- | --- | --- |
${rows.join('\n')}

\`controls.serviceEnabled\` 的 \`{}\` 表示由 registry 默认开关决定；\`未设置\` 表示 schema 没有默认值，运行时按空值或适配器默认处理。凭证字段只保存引用名，实际值由 DSH credentials 解析。
`
}

function code(value) {
  return `\`${value}\``
}

function escapeCell(value) {
  return value.replaceAll('|', '\\|').replaceAll(/\r?\n/g, ' ')
}
