import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('../', import.meta.url))

/** @param {string[]} staged @param {Set<string>} changed */
export function findPartialStaged(staged, changed) {
  return staged
    .filter(path => changed.has(path))
    .map(path => `${path}: staged copy differs from the worktree; stage or restore the current content`)
}

function hasUnstaged(path) {
  try {
    execFileSync('git', ['diff', '--quiet', '--', path], { cwd: root, stdio: 'ignore' })
    return false
  } catch {
    return true
  }
}

function main() {
  const staged = execFileSync('git', ['diff', '--cached', '--name-only', '--diff-filter=ACMR'], {
    cwd: root,
    encoding: 'utf8',
  }).split(/\r?\n/).filter(Boolean)
  const changed = new Set(staged.filter(hasUnstaged))
  const errors = findPartialStaged(staged, changed)
  if (errors.length > 0) {
    for (const error of errors) console.error(error)
    process.exitCode = 1
    return
  }
  console.log('Staged worktree check passed.')
}

if (process.argv[1] === fileURLToPath(import.meta.url)) main()
