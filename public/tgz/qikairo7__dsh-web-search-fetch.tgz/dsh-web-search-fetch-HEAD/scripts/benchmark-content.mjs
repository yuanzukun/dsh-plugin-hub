import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import { aggregateDynamicFetch } from '../lib/fetch/aggregate.js';
import { OpContext } from '../lib/support/budget.js';

// Synthetic, fixed extracts: no network, credentials or external quality claims.
import { fixtures } from './content-fixtures.mjs';

const URL = 'https://example.com/offline-fixture';

/** 构造一路离线提取引擎：manifest 只声明 fetch 能力，fetch 返回固定正文。 */
function offlineEngine(engineId, content) {
  return {
    manifest: {
      id: engineId, label: engineId, capabilities: ['fetch'], auth: 'anonymous',
      endpoints: { fetch: URL },
    },
    fetch: async () => ({
      ok: true,
      outcome: { url: URL, statusCode: 200, body: { kind: 'text', content }, truncated: false },
    }),
  };
}

/** 显式操作上下文：脚本内不设并发预算，仅提供 aggregateDynamicFetch 需要的预算接口。 */
function operation() {
  return new OpContext(
    { preset: 'custom', maxOutputChars: 1_000_000 },
    new AbortController().signal,
    undefined,
    32,
  );
}

/** 装配层职责同 src/index.ts：按 lane 面提供端点与请求计数。 */
async function buildContext(manifest, op, lane) {
  return {
    signal: lane.signal,
    deadline: lane.deadline,
    endpoint: manifest.endpoints.fetch,
    countRequest: () => op.countRequest(),
  };
}

const rows = [];
for (const fixture of fixtures) {
  const engines = fixture.bodies.map((content, index) =>
    offlineEngine(['firecrawl', 'anysearch', 'tavily'][index], content));
  // 只保留 organize 整理模式；first 为单路基线。
  for (const mode of ['first', 'organize']) {
    const times = [];
    let output;
    for (let run = 0; run < 20; run++) {
      const start = performance.now();
      output = mode === 'first'
        ? { url: URL, statusCode: 200, body: { kind: 'text', content: fixture.bodies[0] }, truncated: false }
        : await aggregateDynamicFetch({ url: URL, engines, op: operation(), buildContext });
      times.push(performance.now() - start);
    }
    const content = output.body.content;
    const retained = fixture.markers.filter(marker => content.includes(marker)).length;
    const sharedOccurrences = content.split(fixture.shared).length - 1;
    if (mode === 'organize') {
      assert.equal(retained, fixture.markers.length, fixture.name);
      assert.equal(sharedOccurrences, 1, fixture.name);
      assert.match(content, /提取来源与处理说明/);
    }
    rows.push({
      fixture: fixture.name, mode, retained: `${retained}/${fixture.markers.length}`, sharedOccurrences,
      medianMs: Number(times.sort((a, b) => a - b)[10].toFixed(3)), chars: content.length,
    });
  }
}
console.log(JSON.stringify({ scope: 'synthetic offline extracts; no competitor or live API evaluation', rows }, null, 2));
