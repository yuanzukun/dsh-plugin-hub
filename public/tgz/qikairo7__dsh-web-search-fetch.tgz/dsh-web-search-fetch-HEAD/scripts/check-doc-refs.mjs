import { existsSync, readFileSync, readdirSync } from 'node:fs'
import { join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('../', import.meta.url))
const DOC_REF = /(?<![\w/])(?:docs|\.agents\/notes)\/[A-Za-z0-9._/-]+\.md/g

export function checkableSource(text, path) {
  if (!path.startsWith('test/')) return text
  return text.replace(/'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|`(?:\\.|[^`\\])*`/gu, '')
}

/** @param {string} text @param {string} path @param {(target: string) => boolean} exists */
export function validateDocRefs(text, path, exists = target => existsSync(join(root, target))) {
  const errors = []
  for (const match of text.matchAll(DOC_REF)) {
    const target = match[0]
    if (/(?:^|\/)NNNN-[a-z0-9-]+\.md$/iu.test(target)) continue
    if (!exists(target)) {
      errors.push(`${path}:${lineAt(text, match.index)}: missing ${target}`)
      continue
    }
    const rest = text.slice(match.index + target.length)
    if (/^\s*§\S+/.test(rest)) {
      errors.push(`${path}:${lineAt(text, match.index)}: section-number reference ${target} is not stable; link the document or an anchor`)
    }
  }
  return errors
}

function lineAt(text, index) {
  return text.slice(0, index).split(/\r?\n/).length
}

function files(dir) {
  return readdirSync(dir, { withFileTypes: true }).flatMap(entry => {
    const path = join(dir, entry.name)
    if (entry.isDirectory()) return files(path)
    return /\.(?:ts|js|mjs)$/.test(entry.name) ? [path] : []
  })
}

export function sourceFiles(rootDir) {
  return ['src', 'test', 'scripts'].flatMap(dir => {
    const path = join(rootDir, dir)
    return existsSync(path) ? files(path) : []
  })
}

function run() {
  const sources = sourceFiles(root)
  if (sources.length === 0) {
    console.error('Document reference check failed: no TypeScript sources found.')
    process.exitCode = 1
    return
  }
  const errors = sources.flatMap(path => {
    const name = relative(root, path).split('\\').join('/')
    return validateDocRefs(checkableSource(readFileSync(path, 'utf8'), name), name)
  })
  if (errors.length > 0) {
    for (const error of errors) console.error(error)
    process.exitCode = 1
    return
  }
  console.log(`Document reference check passed (${sources.length} source files).`)
}

if (process.argv[1] === fileURLToPath(import.meta.url)) run()
