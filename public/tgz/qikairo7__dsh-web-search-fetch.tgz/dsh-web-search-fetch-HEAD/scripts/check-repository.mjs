import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { join, relative, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { findBrokenLinks } from './markdown-links.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
// `AGENTS.md` and `.agents` are tracked agent configuration: they are part
// of the public source, so this check reads them and validates their links.
// Entries are matched against the path relative to the repository root, with
// `/` as the separator on every platform.
const skip = new Set(['.git', 'node_modules', 'lib', '.scratch', '.codegraph', '.agents/worktrees', 'coverage', '.pr-lens']);
const errors = [];
const files = [];
const legacyClientPattern = /(?:client\/index\.js|dsh\.client|client-surface|client\/\*\*\/\*\.js|\.\/client\b)/u;

function walk(dir) {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    const name = relative(root, path).split(sep).join('/');
    if (skip.has(name)) continue;
    if (entry.isSymbolicLink()) {
      errors.push(`Symlink is not allowed in the public source: ${name}`);
    } else if (entry.isDirectory()) {
      walk(path);
    } else {
      files.push(path);
    }
  }
}
walk(root);

function prose(text) {
  return text.replace(/^(`{3,}|~{3,})[^\n]*\n[\s\S]*?^\1\s*$/gm, '');
}

function isCurrentSurface(name) {
  if (name.startsWith('docs/adr/') || name.startsWith('docs/upgrade/') || name.startsWith('docs/verification/')) return false;
  if (name.startsWith('.agents/notes/')) return false;
  return name === 'package.json'
    || name === 'AGENTS.md'
    || name === 'README.md'
    || name === 'SECURITY.md'
    || name === 'CONTRIBUTING.md'
    || name.startsWith('src/')
    || name.startsWith('scripts/')
    || name.startsWith('.agents/skills/')
    || name.startsWith('docs/');
}

const documentCache = new Map();
for (const path of files) {
  const name = relative(root, path).split(sep).join('/');
  if (name !== '.env.example' && /(^|\/)(\.env(?:\..*)?|\.credentials\.ya?ml|.*\.(log|tgz))$/.test(name)) {
    errors.push(`Private or generated file in public source: ${name}`);
  }
  if (!/\.(md|ts|js|mjs|json|ya?ml)$/.test(path) || name === 'scripts/check-repository.mjs') continue;
  const text = readFileSync(path, 'utf-8');
  const lineCount = text === '' ? 0 : text.split(/\r?\n/).length - (text.endsWith('\n') ? 1 : 0);
  if (name.startsWith('src/') && name.endsWith('.ts') && lineCount > 500) {
    errors.push(`Source file exceeds 500 lines: ${name}`);
  }
  if (isCurrentSurface(name) && legacyClientPattern.test(text)) {
    errors.push(`Legacy client surface reference in current source: ${name}`);
  }
  if (/(?:[A-Za-z]:[\\/]Users[\\/]|待.{0,10}终审)/.test(text)) {
    errors.push(`Local development detail in public source: ${name}`);
  }
  if (!path.endsWith('.md')) continue;
  const body = prose(text);
  let level = 0;
  for (const heading of body.matchAll(/^(#{1,6})\s+/gm)) {
    const next = heading[1].length;
    if (next > level + 1) errors.push(`Skipped heading level: ${name}`);
    level = next;
  }
  for (const violation of findBrokenLinks(path, text, documentCache)) {
    errors.push(violation.reason === 'target'
      ? `Broken link in ${name}: ${violation.url}`
      : `Missing heading in ${name}: ${violation.url}`);
  }
}

const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf-8'));
for (const entry of [pkg.main, pkg.types, pkg.dsh.bundle.patch, 'LICENSE', 'NOTICE']) {
  if (!existsSync(join(root, entry))) errors.push(`Missing package entry: ${entry}`);
}
if (errors.length > 0) {
  for (const error of errors) console.error(error);
  process.exitCode = 1;
} else {
  console.log(`Repository check passed (${files.length} files; documentation links, headings, package entries, legacy-client references and source line limits).`);
}
