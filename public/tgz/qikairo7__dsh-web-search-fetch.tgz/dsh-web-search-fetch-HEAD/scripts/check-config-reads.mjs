// 实时配置读取守卫：装配层持有根级 volatile 引用，只允许 config.get() 读取快照。
// 任何 config.<字段> / config['字段'] 都会在装配时冻结值，导致设置保存后运行时不生效。
import { readdirSync, readFileSync } from 'node:fs'
import { join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'
import ts from 'typescript'

const root = fileURLToPath(new URL('../', import.meta.url))
const TARGET = 'src'

/** 递归列出 src 下的 TypeScript 源文件。 */
function sourceFiles(dir) {
  return readdirSync(dir, { withFileTypes: true }).flatMap(entry => {
    const path = join(dir, entry.name)
    if (entry.isDirectory()) return sourceFiles(path)
    return entry.isFile() && entry.name.endsWith('.ts') ? [path] : []
  })
}

/** 扫描一段源码中的直接配置字段访问；导出供自测复用。 */
export function scanSource(fileName, text) {
  const source = ts.createSourceFile(fileName, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS)
  const hits = []
  const visit = (node) => {
    if (ts.isPropertyAccessExpression(node)
      && ts.isIdentifier(node.expression)
      && node.expression.text === 'config'
      && node.name.text !== 'get') {
      const { line } = source.getLineAndCharacterOfPosition(node.getStart(source))
      hits.push({ line: line + 1, text: node.getText(source) })
    }
    if (ts.isElementAccessExpression(node)
      && ts.isIdentifier(node.expression)
      && node.expression.text === 'config') {
      const { line } = source.getLineAndCharacterOfPosition(node.getStart(source))
      hits.push({ line: line + 1, text: node.getText(source) })
    }
    ts.forEachChild(node, visit)
  }
  visit(source)
  return hits
}

if (process.argv.includes('--self-test')) {
  const cases = [
    ['const x = config.get().controls', 0],
    ['const x = config.controls', 1],
    ["const x = config['controls']", 1],
    ['const x = other.get().controls', 0],
    ['const config = 1; const x = config.value', 1],
  ]
  for (const [text, expected] of cases) {
    const hits = scanSource('self-test.ts', text)
    if (hits.length !== expected) {
      console.error('config-reads self-test failed', { text, expected, hits })
      process.exit(1)
    }
  }
  console.log('config-reads self-test passed')
  process.exit(0)
}

let failed = false
let scanned = 0
for (const path of sourceFiles(join(root, TARGET))) {
  scanned++
  const file = relative(root, path)
  for (const hit of scanSource(file, readFileSync(path, 'utf8'))) {
    console.error(`${file}:${hit.line}: ${hit.text}（实时配置必须用 config.get() 读取）`)
    failed = true
  }
}
if (scanned === 0) {
  console.error('config 实时引用检查失败：未找到 src 源文件（拒绝空扫描通过）。')
  process.exit(1)
}
if (failed) {
  console.error(`config 实时引用检查失败。`)
  process.exit(1)
}
console.log(`config 实时引用检查通过（${scanned} 个源文件）。`)
