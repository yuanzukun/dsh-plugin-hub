import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

import { buildLockClosure, compareInventory, readLock } from './dependency-inventory.mjs'

const root = fileURLToPath(new URL('../', import.meta.url))

function run() {
  const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'))
  const inventory = JSON.parse(readFileSync(join(root, 'docs/dependency-inventory.json'), 'utf8'))
  const lock = readLock(root)
  if (lock === undefined) throw new Error('cannot find the project lock document')
  const errors = compareInventory(pkg, inventory, buildLockClosure(pkg, lock))
  if (errors.length > 0) {
    for (const error of errors) console.error(error)
    console.error('Regenerate docs/dependency-inventory.json with `node scripts/audit-runtime-dependencies.mjs > docs/dependency-inventory.json` after reviewing the dependency change.')
    process.exitCode = 1
    return
  }
  console.log(`Dependency inventory check passed (${inventory.packages.length} packages).`)
}

run()
