import { readFileSync, readdirSync, statSync } from 'node:fs'
import { join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'
import { parseHTML } from 'linkedom'

import { parseMarkdown, visitMarkdown } from './markdown.mjs'

const root = fileURLToPath(new URL('../', import.meta.url))

export function extractMermaidBlocks(text, path) {
  const blocks = []
  visitMarkdown(parseMarkdown(text), node => {
    if (node.type === 'code' && node.lang === 'mermaid') {
      blocks.push({ path, line: node.position?.start.line ?? 0, source: node.value })
    }
  })
  return blocks
}

function files() {
  const found = []
  const walk = dir => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const path = join(dir, entry.name)
      if (entry.isDirectory()) {
        if (entry.name === 'archived' || entry.name === 'verification') continue
        walk(path)
      } else if (entry.name.endsWith('.md')) {
        found.push(path)
      }
    }
  }
  for (const dir of ['docs', '.agents/notes', '.agents/skills']) {
    const path = join(root, dir)
    if (statSync(path, { throwIfNoEntry: false })?.isDirectory()) walk(path)
  }
  for (const file of ['README.md', 'AGENTS.md']) found.push(join(root, file))
  return found
}

async function run() {
  const blocks = files().flatMap(path => {
    const name = relative(root, path).split('\\').join('/')
    return extractMermaidBlocks(readFileSync(path, 'utf8'), name)
  })
  if (blocks.length === 0) {
    console.log('Mermaid check passed (no diagrams).')
    return
  }
  const { window } = parseHTML('<!doctype html><html><body></body></html>')
  Object.defineProperty(globalThis, 'window', { value: window, configurable: true })
  Object.defineProperty(globalThis, 'document', { value: window.document, configurable: true })
  Object.defineProperty(globalThis, 'navigator', { value: window.navigator, configurable: true })
  const mermaid = (await import('mermaid')).default
  mermaid.initialize({ startOnLoad: false })
  const errors = []
  for (const block of blocks) {
    try {
      await mermaid.parse(block.source, { suppressErrors: false })
    } catch (error) {
      const message = error instanceof Error ? error.message.replace(/\s+/g, ' ').trim() : String(error)
      errors.push(`${block.path}:${block.line}: ${message}`)
    }
  }
  if (errors.length > 0) {
    for (const error of errors) console.error(error)
    process.exitCode = 1
    return
  }
  console.log(`Mermaid check passed (${blocks.length} block(s)).`)
}

if (process.argv[1] === fileURLToPath(import.meta.url)) await run()
