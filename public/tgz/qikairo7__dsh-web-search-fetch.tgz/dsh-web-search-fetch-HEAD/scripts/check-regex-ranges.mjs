// Unicode 区间正则检查：扫描前先跑内置断言；未转义的四位十六进制边界是字符字面量，不是码点范围。
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { trackedFiles } from './tracked-files.mjs'

const root = fileURLToPath(new URL('../', import.meta.url))
const SCAN = /\.(ts|js|mjs)$/
const SKIP_PREFIXES = ['lib/']
const SKIP_FILES = new Set(['scripts/check-regex-ranges.mjs'])
const BAD_RANGE = /\[[0-9a-f]{4}-[0-9a-f]{4}\]/i

export function scanText(text) {
  return text
    .split(/\r?\n/)
    .map((line, index) => ({ line: index + 1, text: line }))
    .filter(line => BAD_RANGE.test(line.text))
}

function verifyScanText() {
  const bad = scanText('const value = /[3400-9fff]/.test(text)')
  const good = scanText('const value = /[\\u3400-\\u9fff]/.test(text)')
  if (bad.length !== 1 || good.length !== 0) {
    console.error('regex range self-test failed', { bad, good })
    process.exit(1)
  }
}

if (process.argv.includes('--self-test')) {
  verifyScanText()
  console.log('Regex range self-test passed')
  process.exit(0)
}

verifyScanText()

let failed = false
let scanned = 0
for (const name of trackedFiles()) {
  if (!SCAN.test(name) || SKIP_FILES.has(name) || SKIP_PREFIXES.some(prefix => name.startsWith(prefix))) continue
  const path = join(root, name)
  if (!existsSync(path)) continue
  scanned++
  for (const hit of scanText(readFileSync(path, 'utf8'))) {
    console.error(`${name}:${hit.line}: use \\uXXXX-\\uYYYY for a Unicode range: ${hit.text.trim()}`)
    failed = true
  }
}
if (scanned === 0) {
  console.error('Regex range check failed: no source files found (empty scan is not success).')
  process.exitCode = 1
} else if (failed) process.exitCode = 1
else console.log(`Regex range check passed (${scanned} files).`)
