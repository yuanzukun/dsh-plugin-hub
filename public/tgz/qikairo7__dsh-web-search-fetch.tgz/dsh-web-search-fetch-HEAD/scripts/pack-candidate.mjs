import { spawnSync } from 'node:child_process'
import { mkdirSync } from 'node:fs'

const destination = '.scratch/packages'
mkdirSync(destination, { recursive: true })

const result = spawnSync('npm', ['pack', '--pack-destination', destination], {
  stdio: 'inherit',
  shell: process.platform === 'win32',
})
if (result.error) throw result.error
process.exit(result.status ?? 1)
