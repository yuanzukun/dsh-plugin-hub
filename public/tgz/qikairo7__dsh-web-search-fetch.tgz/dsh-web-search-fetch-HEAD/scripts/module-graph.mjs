import { readFileSync, readdirSync } from 'node:fs'
import { dirname, join, relative, resolve } from 'node:path'
import ts from 'typescript'

export function relativeImports(source, path) {
  const file = ts.createSourceFile(path, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS)
  const imports = []
  for (const statement of file.statements) {
    const specifier = statement.moduleSpecifier?.text
    if (specifier === undefined || !specifier.startsWith('.')) continue
    imports.push(resolve(dirname(path), specifier.replace(/\.js$/, '.ts')))
  }
  return imports
}

function files(dir) {
  return readdirSync(dir, { withFileTypes: true }).flatMap(entry => {
    const path = join(dir, entry.name)
    if (entry.isDirectory()) return files(path)
    return entry.name.endsWith('.ts') && !entry.name.endsWith('.d.ts') ? [path] : []
  })
}

function group(path, root) {
  const parts = relative(root, path).split('\\').join('/').split('/')
  return parts.length <= 2 ? parts.join('/') : parts.slice(0, 2).join('/')
}

export function buildModuleGraph(root) {
  const graph = new Map()
  for (const path of files(join(root, 'src'))) {
    const source = readFileSync(path, 'utf8')
    const from = group(path, root)
    const targets = relativeImports(source, path)
      .filter(target => target.endsWith('.ts'))
      .map(target => group(resolve(target), root))
      .filter(target => target !== from)
    for (const to of targets) {
      const key = `${from}\0${to}`
      graph.set(key, (graph.get(key) ?? 0) + 1)
    }
  }
  return [...graph.entries()]
    .map(([key, count]) => {
      const [from, to] = key.split('\0')
      return { from, to, count }
    })
    .sort((left, right) => {
      const leftKey = `${left.from}>${left.to}`
      const rightKey = `${right.from}>${right.to}`
      return leftKey < rightKey ? -1 : leftKey > rightKey ? 1 : 0
    })
}

export function renderModuleGraph(edges) {
  const nodes = [...new Set(edges.flatMap(edge => [edge.from, edge.to]))].sort()
  const ids = new Map(nodes.map((node, index) => [node, `N${index}`]))
  const lines = nodes.map(node => `  ${ids.get(node)}["${node}"]`)
  for (const edge of edges) lines.push(`  ${ids.get(edge.from)} -->|${edge.count}| ${ids.get(edge.to)}`)
  return `# 模块图

本文件由 \`src/**/*.ts\` 的相对 import 生成，不要手工编辑。运行 \`pnpm run generate:module-graph\` 更新。

\`\`\`mermaid
flowchart LR
${lines.join('\n')}
\`\`\`

| 从 | 到 | 边数 |
| --- | --- | ---: |
${edges.map(edge => `| ${edge.from} | ${edge.to} | ${edge.count} |`).join('\n')}
`
}
