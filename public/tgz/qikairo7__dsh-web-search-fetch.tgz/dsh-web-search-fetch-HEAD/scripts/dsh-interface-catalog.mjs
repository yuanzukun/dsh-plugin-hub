import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { createRequire } from 'node:module'
import ts from 'typescript'

const packageNames = [
  'WebSearchRequest',
  'WebSearchResult',
  'WebSearchSource',
  'WebFetchRequest',
  'WebFetchResult',
  'WebFetchBody',
  'WebSearchProvider',
  'WebFetchProvider',
]

export function extractInterfaceFacts(source, path, names = packageNames) {
  const file = ts.createSourceFile(path, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS)
  const facts = {}
  for (const node of file.statements) {
    if (!ts.isInterfaceDeclaration(node) && !ts.isTypeAliasDeclaration(node)) continue
    const name = node.name.text
    if (!names.includes(name)) continue
    if (ts.isTypeAliasDeclaration(node)) {
      facts[name] = { type: normalize(node.type.getText(file)) }
      continue
    }
    facts[name] = {
      members: node.members.map(member => {
        const memberName = member.name?.getText(file) ?? '<unnamed>'
        const optional = member.questionToken !== undefined
        const type = normalize(member.type?.getText(file) ?? 'unknown')
        return { name: memberName, optional, type }
      }),
    }
  }
  return facts
}

function normalize(text) {
  return text.replace(/\s+/g, ' ').trim()
}

export function readInstalledInterface() {
  const require = createRequire(import.meta.url)
  const entry = require.resolve('@deepseek-ai/dsh-web')
  const packageRoot = dirname(dirname(entry))
  const types = join(dirname(entry), 'types', 'types.d.ts')
  const packageJson = JSON.parse(readFileSync(join(packageRoot, 'package.json'), 'utf8'))
  return {
    packageName: '@deepseek-ai/dsh-web',
    packageVersion: packageJson.version,
    types: extractInterfaceFacts(readFileSync(types, 'utf8'), types),
  }
}
