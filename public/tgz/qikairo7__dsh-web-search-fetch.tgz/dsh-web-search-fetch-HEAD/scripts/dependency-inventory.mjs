import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { parseAllDocuments } from 'yaml'

/** Build the locked runtime closure without touching the registry. */
export function buildLockClosure(pkg, lock) {
  const direct = lock.importers['.'].dependencies
  for (const [name, version] of Object.entries(pkg.dependencies)) {
    if (direct[name]?.specifier !== version) throw new Error(`Manifest/lock mismatch: ${name}`)
  }
  const queue = Object.entries(pkg.dependencies).map(([name]) => [name, direct[name].version])
  const packages = new Map()
  while (queue.length > 0) {
    const [name, resolution] = queue.shift()
    const key = `${name}@${resolution}`
    if (packages.has(key)) continue
    const snapshot = lock.snapshots[key]
    if (snapshot === undefined) throw new Error(`Missing locked snapshot: ${key}`)
    const version = resolution.split('(')[0]
    const integrity = lock.packages[`${name}@${version}`]?.resolution.integrity
    if (integrity === undefined) throw new Error(`Missing integrity: ${key}`)
    packages.set(key, {
      name,
      version,
      direct: Object.hasOwn(pkg.dependencies, name),
      integrity,
    })
    queue.push(...Object.entries({ ...snapshot.dependencies, ...snapshot.optionalDependencies }))
  }
  return packages
}

/** Compare the committed inventory with package and lock facts. */
export function compareInventory(pkg, inventory, packages) {
  const errors = []
  if (inventory.packageName !== pkg.name) {
    errors.push(`dependency inventory packageName must be ${pkg.name}`)
  }
  if (inventory.packageVersion !== pkg.version) {
    errors.push(`dependency inventory packageVersion must be ${pkg.version}`)
  }
  const actual = new Map()
  for (const entry of inventory.packages ?? []) {
    const key = `${entry.name}@${entry.version}`
    if (actual.has(key)) errors.push(`dependency inventory has duplicate ${key}`)
    actual.set(key, entry)
  }
  for (const [key, expected] of packages) {
    const entry = actual.get(key)
    if (entry === undefined) {
      errors.push(`dependency inventory is missing ${key}`)
      continue
    }
    if (entry.direct !== expected.direct) errors.push(`dependency inventory direct flag is stale for ${key}`)
    if (entry.integrity !== expected.integrity) errors.push(`dependency inventory integrity is stale for ${key}`)
  }
  for (const key of actual.keys()) {
    if (!packages.has(key)) errors.push(`dependency inventory has stale ${key}`)
  }
  return errors
}

export function readLock(root) {
  const documents = parseAllDocuments(readFileSync(join(root, 'pnpm-lock.yaml'), 'utf8'))
  for (const document of documents) {
    if (document.errors.length > 0) throw document.errors[0]
  }
  return documents
    .map(document => document.toJSON())
    .find(value => value?.importers?.['.']?.dependencies !== undefined && value.snapshots !== undefined)
}
