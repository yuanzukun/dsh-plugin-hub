import { existsSync, readFileSync, readdirSync } from 'node:fs'
import { join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'
import { parse } from 'yaml'

const root = fileURLToPath(new URL('../', import.meta.url))

export function validateSkillInvocationMetadata(frontmatterText, metadataText, path) {
  const errors = []
  const skill = parse(frontmatterText)
  const metadata = parse(metadataText)
  if (typeof skill !== 'object' || skill === null || Array.isArray(skill)) {
    return [`${path}: SKILL.md frontmatter must be a YAML object`]
  }
  if (typeof metadata !== 'object' || metadata === null || Array.isArray(metadata)) {
    return [`${path}: agents/openai.yaml must be a YAML object`]
  }
  for (const field of ['disable-model-invocation', 'user-invocable']) {
    if (skill[field] !== undefined && typeof skill[field] !== 'boolean') {
      errors.push(`${path}: ${field} must be a boolean`)
    }
  }
  const policy = metadata.policy
  if (policy !== undefined && (typeof policy !== 'object' || policy === null || Array.isArray(policy))) {
    errors.push(`${path}: policy must be an object`)
  } else if (policy?.allow_implicit_invocation !== undefined && typeof policy.allow_implicit_invocation !== 'boolean') {
    errors.push(`${path}: policy.allow_implicit_invocation must be a boolean`)
  }
  const claudeManualOnly = skill['disable-model-invocation'] === true
  const codexManualOnly = policy?.allow_implicit_invocation === false
  if (claudeManualOnly !== codexManualOnly) {
    errors.push(`${path}: Claude manual-only=${claudeManualOnly} but Codex manual-only=${codexManualOnly}`)
  }
  if (claudeManualOnly && skill['user-invocable'] === false) {
    errors.push(`${path}: manual-only skills must remain user-invocable`)
  }
  return errors
}

function skillDirs() {
  const rootDir = join(root, '.agents/skills')
  if (!existsSync(rootDir)) return []
  return readdirSync(rootDir, { withFileTypes: true })
    .filter(entry => entry.isDirectory() && existsSync(join(rootDir, entry.name, 'agents/openai.yaml')))
}

function run() {
  const errors = []
  for (const dir of skillDirs()) {
    const skillPath = join(root, '.agents/skills', dir.name, 'SKILL.md')
    const metadataPath = join(root, '.agents/skills', dir.name, 'agents/openai.yaml')
    if (!existsSync(skillPath)) {
      errors.push(`${relative(root, metadataPath)}: missing sibling SKILL.md`)
      continue
    }
    const source = readFileSync(skillPath, 'utf8')
    const frontmatter = /^---\n([\s\S]*?)\n---\n/u.exec(source)?.[1]
    if (frontmatter === undefined) {
      errors.push(`${relative(root, skillPath)}: missing YAML frontmatter`)
      continue
    }
    errors.push(...validateSkillInvocationMetadata(frontmatter, readFileSync(metadataPath, 'utf8'), relative(root, skillPath)))
  }
  if (errors.length > 0) {
    for (const error of errors) console.error(error)
    process.exitCode = 1
    return
  }
  console.log(`Skill invocation metadata check passed (${skillDirs().length} pair(s)).`)
}

if (process.argv[1] === fileURLToPath(import.meta.url)) run()
