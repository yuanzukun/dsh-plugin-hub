import { readFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('../', import.meta.url))
const guideName = /^v(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)(?:-[0-9A-Za-z-]+)?-[a-z0-9]+(?:-[a-z0-9]+)*\.md$/u
const sections = ['## 变更', '## 迁移', '## 验证']

export function validateUpgradeGuide(source, path) {
  const errors = []
  if (!guideName.test(path.split('/').at(-1))) {
    return [`${path}: filename must be v<semver>-<kebab-case-topic>.md`]
  }
  if (!/^# v\d+\.\d+\.\d+(?:-[0-9A-Za-z-]+)?：.+/u.test(source.split(/\r?\n/, 1)[0] ?? '')) {
    errors.push(`${path}: first line must be '# v<semver>：<title>'`)
  }
  const actual = source.match(/^## .+$/gm) ?? []
  if (actual.join('\n') !== sections.join('\n')) {
    errors.push(`${path}: sections must be exactly ${sections.join(', ')}`)
  }
  return errors
}

export function collectUpgradeGuideViolations(rootDir) {
  const directory = join(rootDir, 'docs/upgrade')
  return readdirSync(directory, { withFileTypes: true })
    .filter(entry => entry.isFile() && entry.name.endsWith('.md') && entry.name !== 'README.md')
    .flatMap(entry => {
      const path = `docs/upgrade/${entry.name}`
      return validateUpgradeGuide(readFileSync(join(directory, entry.name), 'utf8'), path)
    })
}

function run() {
  const errors = collectUpgradeGuideViolations(root)
  if (errors.length > 0) {
    for (const error of errors) console.error(error)
    process.exitCode = 1
    return
  }
  console.log('Upgrade guide check passed.')
}

if (process.argv[1] === fileURLToPath(import.meta.url)) run()
