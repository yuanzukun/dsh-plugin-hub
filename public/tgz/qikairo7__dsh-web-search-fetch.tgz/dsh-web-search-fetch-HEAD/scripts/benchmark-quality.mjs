import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';
import { performance } from 'node:perf_hooks';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

import { AggregatedSearchProvider } from '../lib/search/aggregate.js';
import { AggregatedFetchProvider } from '../lib/fetch/provider.js';
import { aggregateDynamicFetch } from '../lib/fetch/aggregate.js';
import { CircuitBreaker } from '../lib/support/breaker.js';
import { OpContext } from '../lib/support/budget.js';
import {
  buildEngines, ENGINE_MANIFESTS, ANYSEARCH_MANIFEST, TAVILY_MANIFEST, FIRECRAWL_MANIFEST,
  ZHIHU_MANIFEST, AIHOT_MANIFEST,
} from '../lib/engines/registry.js';
import { createAnysearchEngine } from '../lib/engines/anysearch.js';
import { createTavilyEngine } from '../lib/engines/tavily.js';
import { createFirecrawlEngine } from '../lib/engines/firecrawl.js';
import { createZhihuEngine } from '../lib/engines/zhihu.js';
import { createAihotEngine } from '../lib/engines/aihot.js';
import { searchCases, longArticle, relevance, retention } from './quality-cases.mjs';

const URL = 'https://article.test/guide';
const SEARCH_SERVICES = ['anysearch', 'tavily', 'firecrawl'];
const FETCH_SERVICES = ['anysearch', 'tavily', 'firecrawl'];

/** 离线装配层上下文：不触网，只把 lane 信号与请求预算透给假引擎。 */
async function offlineBuildContext(manifest, op, lane) {
  return {
    signal: lane.signal,
    deadline: lane.deadline,
    endpoint: manifest.endpoints?.fetch ?? manifest.endpoints?.search ?? 'https://fixture.test',
    countRequest: () => op.countRequest(),
  };
}

/** 与原脚本同形的成本账本：离线只统计引擎调用次数。 */
function newCost() {
  return { requests: 0, completed: 0, cancelled: 0, byKind: {}, monetaryCost: null };
}

function countRequest(cost, kind) {
  cost.requests += 1;
  cost.byKind[kind] = (cost.byKind[kind] ?? 0) + 1;
}

/** 假搜索引擎：每次调用返回固定来源列表，并按调用次数记账。 */
function searchEngine(manifest, sources, cost) {
  return {
    manifest,
    async search() {
      countRequest(cost, 'search');
      cost.completed += 1;
      return { ok: true, outcome: { sources, truncated: false } };
    },
  };
}

/** 假提取引擎：固定正文；delayMs 用于验证宽限窗口的提前取消。 */
function fetchEngine(manifest, content, cost, delayMs = 0) {
  return {
    manifest,
    async fetch(_url, ctx) {
      countRequest(cost, 'extract');
      if (delayMs > 0) {
        try {
          await delay(delayMs, undefined, { signal: ctx.signal });
        } catch (error) {
          cost.cancelled += 1;
          throw error;
        }
      }
      if (ctx.signal.aborted) {
        cost.cancelled += 1;
        throw new DOMException('aborted', 'AbortError');
      }
      cost.completed += 1;
      return {
        ok: true,
        outcome: { url: URL, statusCode: 200, body: { kind: 'text', content }, truncated: false },
      };
    },
  };
}

/**
 * v0.4 主题过滤要求查询主题词命中候选文本；合成回放把查询词并入 snippet，
 * 让固定 judgments 进入融合排序。评分仍按文档 grade/URL，不看 snippet。
 */
function searchEnginesFor(item, cost) {
  const rotate = index => [item.documents[index], ...item.documents.filter((_, n) => n !== index)]
    .map(({ grade, ...source }) => ({ ...source, snippet: `${source.snippet ?? ''} ${item.query}` }));
  return buildEngines({
    anysearch: searchEngine(ANYSEARCH_MANIFEST, rotate(0), cost),
    tavily: searchEngine(TAVILY_MANIFEST, rotate(1), cost),
    firecrawl: searchEngine(FIRECRAWL_MANIFEST, rotate(2), cost),
    zhihu: { manifest: ZHIHU_MANIFEST },
    aihot: { manifest: AIHOT_MANIFEST },
  });
}

function offlineSearchProvider(engines) {
  return new AggregatedSearchProvider({
    resolveControls: () => ({
      preset: 'custom', searchServices: SEARCH_SERVICES, maxSearchServices: 3,
      maxRequests: 3, maxOutputChars: 100_000,
    }),
    engines,
    breaker: new CircuitBreaker(),
    buildContext: offlineBuildContext,
    quotaCheck: false,
  });
}

function fetchEnginesFor(contents, cost) {
  return buildEngines({
    anysearch: fetchEngine(ANYSEARCH_MANIFEST, contents[0] ?? '', cost),
    tavily: fetchEngine(TAVILY_MANIFEST, contents[1] ?? '', cost),
    firecrawl: fetchEngine(FIRECRAWL_MANIFEST, contents[2] ?? '', cost),
    zhihu: { manifest: ZHIHU_MANIFEST },
    aihot: { manifest: AIHOT_MANIFEST },
  });
}

function offlineFetchProvider(engines, maxOutputChars) {
  return new AggregatedFetchProvider({
    resolveControls: () => ({
      preset: 'multi', fetchServices: FETCH_SERVICES, maxFetchServices: 3,
      maxRequests: 10, fetchDeadlineMs: 10_000, maxOutputChars,
    }),
    engines,
    buildContext: offlineBuildContext,
    blockPrivateAddresses: false,
    perEngineTimeoutMs: 2_000,
  });
}

export async function evaluateQuality({ live = false } = {}) {
  const rows = [];
  const trial = async (id, category, make, inspect) => {
    const cost = newCost();
    const started = performance.now();
    const row = { id, category, scope: 'synthetic replay', status: 'PASS', cost };
    try {
      const result = await make(cost);
      Object.assign(row, inspect(result, cost), { truncated: result.truncated });
    } catch (error) {
      row.status = 'FAIL';
      row.errorCode = error.code ?? error.name;
      row.message = error.message;
    }
    row.ms = Math.round(performance.now() - started);
    rows.push(row);
  };

  for (const item of searchCases) {
    await trial(item.id, item.category, cost =>
      offlineSearchProvider(searchEnginesFor(item, cost)).search({ query: item.query, maxResults: 5 }),
    result => {
      const metrics = relevance(result.sources, item.documents);
      assert(metrics.precisionAt5 >= (item.category === 'news' ? 0.6 : 0.8),
        `${item.id} precision@5=${metrics.precisionAt5}`);
      assert(metrics.ndcgAt5 >= 0.9, `${item.id} ndcg@5=${metrics.ndcgAt5}`);
      const dated = result.sources.filter(source => source.publishedAt);
      return {
        ...metrics,
        ...(item.since ? {
          datedSources: dated.length,
          inWindowSources: dated.filter(source =>
            source.publishedAt >= item.since && source.publishedAt <= item.until).length,
        } : {}),
      };
    });
  }

  for (const variant of ['organize', 'budget']) {
    await trial(`long-chinese-${variant}`, 'long-article', cost =>
      offlineFetchProvider(fetchEnginesFor(longArticle.bodies, cost), variant === 'budget' ? 1_000 : 100_000)
        .fetch({ url: URL }),
    result => {
      const metrics = retention(result.body.content, longArticle.markers);
      if (variant === 'organize') assert.equal(metrics.markerRecall, 1);
      if (variant === 'budget') {
        assert(result.truncated);
        assert(metrics.markerRecall < 1);
      }
      const retainedSections = Array.from({ length: 60 }, (_, n) => `## 第 ${n + 1} 节`)
        .filter(marker => result.body.content.includes(marker)).length;
      if (variant !== 'budget') assert.equal(retainedSections, 60);
      return { ...metrics, retainedSections, sectionTotal: 60, bodyChars: result.body.content.length };
    });
  }

  const challenge = '# Just a moment...\n\nVerify you are human. Checking your browser before accessing the site. Enable JavaScript and cookies to continue.';
  for (const allBlocked of [false, true]) {
    await trial(allBlocked ? 'all-challenged' : 'challenge-with-article', 'challenge', async cost => {
      const contents = allBlocked
        ? [challenge, challenge, challenge]
        : [challenge, longArticle.bodies[0], longArticle.bodies[0]];
      try {
        return await offlineFetchProvider(fetchEnginesFor(contents, cost), 100_000).fetch({ url: URL });
      } catch (error) {
        if (allBlocked && error.code === 'WEB_PROVIDER_ERROR' && /没有可整理的目标网页正文/.test(error.message)) {
          return { rejected: true, code: error.code, truncated: false };
        }
        throw error;
      }
    }, result => {
      if (allBlocked) {
        assert.equal(result.rejected, true);
        return { challengeRejected: true };
      }
      assert(!result.body.content.includes('Verify you are human'));
      assert(result.body.content.includes('甲渠道独有的联络流程。'));
      return { challengeExcluded: true, articleRetained: true };
    });
  }

  // v0.4 宽限窗口：三路充分且互补后，慢渠道在宽限期结束时被取消。
  await trial('settle-early-slow-channel', 'slow-channel', async cost => {
    const slowManifest = {
      ...ZHIHU_MANIFEST, id: 'fixture-slow', label: 'fixture-slow',
      capabilities: ['fetch'], auth: 'anonymous',
    };
    const engines = [
      fetchEngine(ANYSEARCH_MANIFEST, longArticle.bodies[0], cost),
      fetchEngine(TAVILY_MANIFEST, longArticle.bodies[0], cost),
      fetchEngine(FIRECRAWL_MANIFEST, longArticle.bodies[0], cost),
      fetchEngine(slowManifest, longArticle.bodies[0], cost, 2_200),
    ];
    return aggregateDynamicFetch({
      url: URL, engines, settleEarly: true, perEngineTimeoutMs: 5_000,
      op: new OpContext({ preset: 'auto' }, new AbortController().signal, undefined, 32),
      buildContext: offlineBuildContext,
    });
  }, (result, cost) => {
    assert.equal(result.truncated, true);
    assert.equal(cost.cancelled, 1);
    return { settledEarly: true, slowCancelled: true };
  });

  if (live) rows.push(...await evaluateLive());
  return {
    schemaVersion: 1, generatedAt: new Date().toISOString(), node: process.version,
    commit: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
    workingTree: execFileSync('git', ['status', '--porcelain'], { encoding: 'utf8' }).trim() ? 'dirty' : 'clean',
    scope: 'Synthetic judgments test pipeline rules; live anonymous rows measure current availability and relevance proxies, not human relevance scores. Requests count dispatched attempts, including cancelled lanes; no currency estimate.',
    rows,
  };
}

async function evaluateLive() {
  const cost = { requests: 0, byKind: {} };
  const countedFetch = (input, init) => {
    cost.requests += 1;
    const kind = /\/(?:search|scrape|extract)$/.exec(new URL(String(input)).pathname)?.[0].slice(1) ?? 'other';
    cost.byKind[kind] = (cost.byKind[kind] ?? 0) + 1;
    return fetch(input, init);
  };
  const liveBuildContext = async (manifest, op, lane) => {
    const endpoint = lane.face === 'quota'
      ? manifest.endpoints.quota
      : lane.face === 'fetch' ? manifest.endpoints.fetch : manifest.endpoints.search;
    return {
      signal: lane.signal,
      deadline: lane.deadline,
      endpoint: endpoint ?? manifest.endpoints.search ?? 'https://invalid.local',
      countRequest: () => op.countRequest(),
    };
  };
  const engines = buildEngines({
    anysearch: createAnysearchEngine({ fetcher: countedFetch }),
    tavily: createTavilyEngine({ fetcher: countedFetch }),
    firecrawl: createFirecrawlEngine({ fetcher: countedFetch }),
    zhihu: createZhihuEngine({ fetcher: countedFetch }),
    aihot: createAihotEngine({ fetcher: countedFetch }),
  });
  // key-auth 引擎在匿名 live 模式下没有凭证，ready 直接排除；keyless-fallback 保持匿名可用。
  const ready = async id => {
    const manifest = ENGINE_MANIFESTS.find(entry => entry.id === id);
    return manifest === undefined || manifest.auth !== 'key';
  };
  const controls = {
    preset: 'custom', mode: 'organize',
    searchServices: ['anysearch', 'tavily', 'aihot'], fetchServices: ['anysearch', 'tavily'],
    maxSearchServices: 3, maxFetchServices: 2, maxRequests: 5, maxOutputChars: 50_000,
    searchDeadlineMs: 15_000, fetchDeadlineMs: 50_000,
  };
  const breaker = new CircuitBreaker();
  const search = new AggregatedSearchProvider({
    resolveControls: () => controls, engines, breaker, buildContext: liveBuildContext, ready, quotaCheck: false,
  });
  const extract = new AggregatedFetchProvider({
    resolveControls: () => controls, engines, buildContext: liveBuildContext, ready, breaker,
  });
  const today = new Date().toLocaleDateString('sv-SE', { timeZone: 'Asia/Shanghai' });
  const cases = [
    { id: 'live-chinese', query: 'Python asyncio TaskGroup 任务失败时如何取消其他任务 官方文档', terms: ['TaskGroup', '取消', 'cancel'] },
    { id: 'live-news', query: '嫦娥六号 2024年6月25日 返回器 着陆 官方消息', terms: ['嫦娥六号', '着陆', '返回器'] },
    { id: 'live-current-news', query: today + ' 人工智能 最新新闻', terms: ['人工智能', 'AI', '模型'], since: today },
    { id: 'live-long-article', url: 'https://docs.python.org/zh-cn/3/library/asyncio-task.html', markers: ['TaskGroup', 'create_task', 'shield', 'timeout', 'CancelledError'] },
  ];
  const rows = [];
  for (const item of cases) {
    cost.requests = 0;
    cost.byKind = {};
    const started = performance.now();
    const row = { id: item.id, scope: 'live anonymous core API', status: 'PASS', qualityStatus: 'PROXY_ONLY' };
    try {
      const result = item.url
        ? await extract.fetch({ url: item.url })
        : await search.search({ query: item.query, maxResults: 5 });
      assert(item.url
        ? result.statusCode >= 200 && result.statusCode < 300 && result.body.content.trim().length > 0
        : result.sources.length > 0, 'no usable output');
      row.truncated = result.truncated;
      if (item.url) Object.assign(row, retention(result.body.content, item.markers), { bodyChars: result.body.content.length });
      else {
        row.sourceCount = result.sources.length;
        row.topicMatchAt5 = result.sources.slice(0, 5)
          .filter(source => item.terms.some(term => `${source.title} ${source.snippet}`.toLowerCase().includes(term.toLowerCase()))).length / 5;
        row.urls = result.sources.map(source => source.url);
        row.datedSources = result.sources.filter(source => source.publishedAt).length;
        if (item.since) {
          row.inWindowSources = result.sources.filter(source => {
            const timestamp = Date.parse(source.publishedAt ?? '');
            return Number.isFinite(timestamp)
              && timestamp >= Date.parse(item.since + 'T00:00:00+08:00')
              && timestamp <= Date.now();
          }).length;
          row.freshnessStatus = row.datedSources === 0 ? 'UNKNOWN' : 'METADATA_ONLY';
        }
      }
    } catch (error) {
      row.status = 'FAIL';
      row.errorCode = error.code ?? error.name;
    }
    row.ms = Math.round(performance.now() - started);
    row.cost = { requests: cost.requests, byKind: { ...cost.byKind }, monetaryCost: null };
    rows.push(row);
  }
  return rows;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const outputIndex = process.argv.indexOf('--output');
  const report = await evaluateQuality({ live: process.argv.includes('--live') });
  if (outputIndex >= 0) {
    assert(process.argv[outputIndex + 1], '--output requires a filename');
    await writeFile(process.argv[outputIndex + 1], JSON.stringify(report, null, 2) + '\n');
  }
  console.log(JSON.stringify(report, null, 2));
  if (report.rows.some(row => row.status === 'FAIL')) process.exitCode = 1;
}
