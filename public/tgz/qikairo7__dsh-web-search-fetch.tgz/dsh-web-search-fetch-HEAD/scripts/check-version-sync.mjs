import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('../', import.meta.url))

export function checkVersionSync(pkg, documents) {
  const errors = []
  const dshVersions = [...new Set(Object.entries(pkg.devDependencies ?? {})
    .filter(([name]) => name.startsWith('@deepseek-ai/dsh-'))
    .map(([, version]) => version))]
  if (dshVersions.length !== 1) {
    errors.push(`DSH devDependencies must share one version, found ${dshVersions.join(', ')}`)
  }
  const dshVersion = dshVersions[0]
  if (dshVersion !== undefined) {
    for (const [path, text] of Object.entries(documents)) {
      if (path === 'docs/dsh-web-interface.md' || path === 'docs/glossary.md' || path === 'README.md') {
        if (!text.includes(dshVersion)) errors.push(`${path}: must mention DSH ${dshVersion}`)
      }
    }
    if (!String(pkg.engines?.dsh ?? '').includes(dshVersion)) {
      errors.push(`package.json: engines.dsh must include ${dshVersion}`)
    }
  }
  const current = /当前开发线为\s+`?([0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?)`?/.exec(documents['README.md'] ?? '')?.[1]
  if (current !== pkg.version) errors.push(`README.md: current development version must be ${pkg.version}`)
  return errors
}

function run() {
  const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'))
  const documents = Object.fromEntries(['README.md', 'docs/dsh-web-interface.md', 'docs/glossary.md']
    .map(path => [path, readFileSync(join(root, path), 'utf8')]))
  const errors = checkVersionSync(pkg, documents)
  if (errors.length > 0) {
    for (const error of errors) console.error(error)
    process.exitCode = 1
    return
  }
  console.log('Version sync check passed.')
}

run()
