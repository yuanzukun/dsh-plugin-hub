// 关键名词白名单校验：抓同长度替换式乱码（LESSONS.md 2026-11-07 教训）。
// 只扫描 git 索引与未忽略的新文件；--self-test 只跑内置断言。
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { trackedFiles } from './tracked-files.mjs'

const root = fileURLToPath(new URL('../', import.meta.url))
const SERVICE_NAMES = ['AnySearch', 'Tavily', 'Firecrawl', 'Zhihu', 'AIHOT', 'SiliconFlow', 'DeepSeek']
// 含 LESSONS.md 记录的原始乱码与仓库观测到的变体；新增/删除条目时同步 --self-test。
const KNOWN_BAD = new Set(['wuzxfdimz', 'xihxbjoxt', 'wkqzgityk', 'jxrggyywj', 'soxe', 'tlcdjxsdn'])
const MIN_FUZZY_LENGTH = 6
const SKIP_PREFIXES = ['lib/', 'docs/verification/', '.workflow-lite/', '.agents/']
const SKIP_FILES = new Set(['LESSONS.md', 'CLAUDE.md', 'scripts/check-wordlist.mjs'])
const SCAN = /\.(md|ts|js|mjs|json|ya?ml|html)$/

function tokens(text) {
  return text
    .split(/[^A-Za-z0-9]+/)
    .filter(Boolean)
    .flatMap(part => {
      const camel = part.split(/(?<=[a-z0-9])(?=[A-Z])/)
      if (camel.length === 1) return [part]
      const joined = camel.slice(1).map((segment, i) => camel[i] + segment)
      return [...new Set([part, ...camel, ...joined])]
    })
}

function hammingOne(a, b) {
  if (a.length !== b.length) return false
  let diff = 0
  for (let i = 0; i < a.length; i++) {
    if (a[i] !== b[i] && ++diff > 1) return false
  }
  return diff === 1
}

export function scanText(text) {
  const hits = []
  const lines = text.split(/\r?\n/)
  for (let i = 0; i < lines.length; i++) {
    for (const token of tokens(lines[i])) {
      const lower = token.toLowerCase()
      const bad = KNOWN_BAD.has(lower)
        || SERVICE_NAMES.some(name => name.length >= MIN_FUZZY_LENGTH && hammingOne(lower, name.toLowerCase()))
      if (bad) hits.push({ line: i + 1, token })
    }
  }
  return hits
}

if (process.argv.includes('--self-test')) {
  const cases = [
    ['see wuzxfdimz and XihXbjoxt and Wuzxfdimz', 3],
    ['FIRECRAWK_API_KEY and firecrawkApiKey and firecrawk-api', 3],
    ['anySearckClient siliconFlewClient DeepSeejClient', 3],
    ['aibot zhiku zhiwu zhifu zhixu zhiyu', 0],
    ['DeepSeej is a corrupted product name', 1],
    ['AnySearch Tavily Firecrawl Zhihu AIHOT SiliconFlow DeepSeek', 0],
    ['file.firecrawl is the correct field', 0],
  ]
  for (const [text, expected] of cases) {
    const hits = scanText(text)
    if (hits.length !== expected) {
      console.error('wordlist self-test failed', { text, expected, hits })
      process.exit(1)
    }
  }
  console.log('wordlist self-test passed')
  process.exit(0)
}

let failed = false
let scanned = 0
for (const name of trackedFiles()) {
  if (!SCAN.test(name) || SKIP_FILES.has(name)) continue
  if (SKIP_PREFIXES.some(prefix => name.startsWith(prefix))) continue
  const path = join(root, name)
  if (!existsSync(path)) continue
  scanned++
  for (const hit of scanText(readFileSync(path, 'utf8'))) {
    console.error(`${name}:${hit.line}: suspicious token "${hit.token}"`)
    failed = true
  }
}
if (failed) process.exitCode = 1
else console.log(`Wordlist check passed (${scanned} files).`)
