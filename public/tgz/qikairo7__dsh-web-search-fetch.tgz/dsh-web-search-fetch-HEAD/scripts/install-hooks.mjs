import { chmodSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('../', import.meta.url))
const hooks = ['.githooks/pre-commit', '.githooks/pre-push']

execFileSync('git', ['config', 'core.hooksPath', '.githooks'], { cwd: root, stdio: 'inherit' })
for (const hook of hooks) chmodSync(join(root, hook), 0o755)
console.log('Git hooks installed from .githooks.')
