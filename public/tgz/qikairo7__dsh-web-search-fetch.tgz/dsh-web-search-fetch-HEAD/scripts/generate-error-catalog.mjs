import { readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'

import { collectErrorCodes, renderErrorCatalog } from './error-catalog.mjs'

const root = fileURLToPath(new URL('../', import.meta.url))
const path = join(root, 'docs/error-catalog.md')
const sources = []

function walk(dir) {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const full = join(dir, entry.name)
    if (entry.isDirectory()) walk(full)
    else if (entry.name.endsWith('.ts') && !entry.name.endsWith('.d.ts')) {
      sources.push({
        path: relative(root, full).split('\\').join('/'),
        text: readFileSync(full, 'utf8'),
      })
    }
  }
}

walk(join(root, 'src'))
const catalog = renderErrorCatalog(collectErrorCodes(sources))
const check = process.argv.includes('--check')

if (check) {
  let current
  try {
    current = readFileSync(path, 'utf8')
  } catch {
    console.error('docs/error-catalog.md is missing')
    process.exitCode = 1
  }
  if (current !== undefined && current !== catalog) {
    console.error('docs/error-catalog.md is stale')
    console.error('Run pnpm run generate:errors and commit the generated catalog.')
    process.exitCode = 1
  }
  if (process.exitCode !== 1) console.log('Error catalog check passed.')
} else {
  writeFileSync(path, catalog)
  console.log('Error catalog generated: docs/error-catalog.md')
}
