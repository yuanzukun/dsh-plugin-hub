import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

import { Config } from '../lib/index.js'
import { collectConfigFields, renderConfigCatalog } from './config-catalog.mjs'

const root = fileURLToPath(new URL('../', import.meta.url))
const path = join(root, 'docs/config-catalog.md')
const catalog = renderConfigCatalog(collectConfigFields(Config))
const check = process.argv.includes('--check')

if (check) {
  const errors = []
  let current
  try {
    current = readFileSync(path, 'utf8')
  } catch {
    errors.push('docs/config-catalog.md is missing')
  }
  if (current !== undefined && current !== catalog) errors.push('docs/config-catalog.md is stale')
  for (const [file, link] of [
    ['docs/configuration.md', 'config-catalog.md'],
    ['docs/README.md', 'config-catalog.md'],
  ]) {
    if (!readFileSync(join(root, file), 'utf8').includes(link)) errors.push(`${file}: must link ${link}`)
  }
  if (errors.length > 0) {
    for (const error of errors) console.error(error)
    console.error('Run pnpm run generate:config and commit the generated catalog.')
    process.exitCode = 1
  } else {
    console.log('Config catalog check passed.')
  }
} else {
  writeFileSync(path, catalog)
  console.log('Config catalog generated: docs/config-catalog.md')
}
