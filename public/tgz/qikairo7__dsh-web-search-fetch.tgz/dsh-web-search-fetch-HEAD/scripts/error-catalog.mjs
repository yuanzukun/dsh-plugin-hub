/**
 * Generate the WEB_* error catalog from source string literals.
 *
 * The source remains the authority for code existence and locations; this
 * module owns the one-line meaning that reviewers and users need.
 */

const MEANINGS = {
  WEB_ABORTED: '调用方主动取消，未继续等待结果。',
  WEB_BLOCKED_URL: '地址守卫或目标站拒绝了该 URL。',
  WEB_FETCH_TIMEOUT: '提取在总限时或单路限时内未完成。',
  WEB_FETCH_TOO_LARGE: '输入或输出超过提取预算。',
  WEB_INVALID_URL: 'URL 不可解析或不是 HTTP(S)。',
  WEB_PROVIDER_ERROR: 'provider 不可用、未配置或全部路径失败。',
  WEB_SEARCH_TIMEOUT: '搜索在操作总限时内未完成。',
  WEB_UNSUPPORTED_CONTENT_TYPE: '目标内容类型不受提取器支持。',
}

/** @param {{ path: string, text: string }[]} sources */
export function collectErrorCodes(sources) {
  const found = new Map()
  for (const source of sources) {
    for (const match of source.text.matchAll(/['"](WEB_[A-Z_]+)['"]/g)) {
      const code = match[1]
      if (MEANINGS[code] === undefined) {
        throw new Error(`WEB error code ${code} in ${source.path} has no catalog meaning`)
      }
      const files = found.get(code) ?? new Set()
      files.add(source.path)
      found.set(code, files)
    }
  }
  return [...found.entries()]
    .sort(([left], [right]) => (left < right ? -1 : left > right ? 1 : 0))
    .map(([code, files]) => ({
      code,
      meaning: MEANINGS[code],
      locations: [...files].sort(),
    }))
}

/** @param {{ code: string, meaning: string, locations: string[] }[]} entries */
export function renderErrorCatalog(entries) {
  const rows = entries.map(entry =>
    `| ${code(entry.code)} | ${escapeCell(entry.meaning)} | ${entry.locations.map(code).join('、')} |`)
  return `# 错误码目录

本文件由 \`src/**/*.ts\` 中的 \`WEB_*\` 字符串生成，不要手工编辑。运行 \`pnpm run generate:errors\` 更新。

| 错误码 | 含义 | 出现位置 |
| --- | --- | --- |
${rows.join('\n')}
`
}

function code(value) {
  return `\`${value}\``
}

function escapeCell(value) {
  return value.replaceAll('|', '\\|').replaceAll(/\r?\n/g, ' ')
}
