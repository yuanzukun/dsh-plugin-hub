import { readFileSync, readdirSync } from 'node:fs'
import { join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'
import ts from 'typescript'

const root = fileURLToPath(new URL('../', import.meta.url))

export function missingExportJsdoc(source, path) {
  const file = ts.createSourceFile(path, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS)
  const errors = []
  for (const statement of file.statements) {
    const exported = ts.canHaveModifiers(statement)
      && ts.getModifiers(statement)?.some(modifier => modifier.kind === ts.SyntaxKind.ExportKeyword)
    if (!exported && !ts.isExportAssignment(statement)) continue
    const ranges = ts.getLeadingCommentRanges(source, statement.getFullStart()) ?? []
    if (!ranges.some(range => source.slice(range.pos, range.end).trimStart().startsWith('/**'))) {
      const line = file.getLineAndCharacterOfPosition(statement.getStart(file)).line + 1
      errors.push(`${path}:${line}: exported declaration needs a JSDoc comment`)
    }
  }
  return errors
}

function files(dir) {
  return readdirSync(dir, { withFileTypes: true }).flatMap(entry => {
    const path = join(dir, entry.name)
    if (entry.isDirectory()) return files(path)
    return entry.name.endsWith('.ts') && !entry.name.endsWith('.d.ts') ? [path] : []
  })
}

function run() {
  const publicFiles = new Set(['src/index.ts', 'src/engines/contract.ts'])
  const errors = files(join(root, 'src')).filter(path =>
    publicFiles.has(relative(root, path).split('\\').join('/'))).flatMap(path =>
    missingExportJsdoc(readFileSync(path, 'utf8'), relative(root, path).split('\\').join('/')))
  if (errors.length > 0) {
    for (const error of errors) console.error(error)
    process.exitCode = 1
    return
  }
  console.log('Export JSDoc check passed.')
}

if (process.argv[1] === fileURLToPath(import.meta.url)) run()
