import { readFileSync, readdirSync, statSync } from 'node:fs'
import { join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'
import ts from 'typescript'

const root = fileURLToPath(new URL('../', import.meta.url))

/** Extract fenced TypeScript blocks; `ts ignore-check` is the explicit opt-out. */
export function extractTsBlocks(text, path) {
  const blocks = []
  const lines = text.split(/\r?\n/)
  let fence = ''
  let start = -1
  let info = ''
  let body = []
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index]
    if (fence === '') {
      const opening = /^\s*```(ts|typescript)(?:\s+(ignore-check))?\s*$/.exec(line)
      if (opening) {
        fence = '```'
        start = index + 1
        info = opening[2] ?? ''
        body = []
      }
      continue
    }
    if (/^\s*```\s*$/.test(line)) {
      if (info !== 'ignore-check') blocks.push({ path, line: start, code: body.join('\n') })
      fence = ''
      continue
    }
    body.push(line)
  }
  if (fence !== '') blocks.push({ path, line: start, code: body.join('\n'), unclosed: true })
  return blocks
}

/** Compile blocks as virtual files against the project's TypeScript options. */
export function compileBlocks(blocks, rootDir = root) {
  if (blocks.length === 0) return []
  const configPath = join(rootDir, 'tsconfig.test.json')
  const config = ts.getParsedCommandLineOfConfigFile(configPath, {}, {
    ...ts.sys,
    getCurrentDirectory: () => rootDir,
    onUnRecoverableConfigFileDiagnostic: diagnostic => {
      throw new Error(ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'))
    },
  })
  if (config === undefined) throw new Error(`cannot parse ${configPath}`)
  const options = {
    ...config.options,
    noEmit: true,
    rootDir,
    noUnusedLocals: false,
    noUnusedParameters: false,
  }
  // shortcut: virtual blocks resolve imports from the repository root; add a doc-specific tsconfig if examples import siblings.
  const sources = new Map()
  for (const [index, block] of blocks.entries()) {
    const file = join(rootDir, '.doc-types', `block-${index}.ts`).replaceAll('\\', '/')
    sources.set(file, `${block.code}\n`)
  }
  const base = ts.createCompilerHost(options, true)
  const host = {
    ...base,
    fileExists: file => sources.has(file.replaceAll('\\', '/')) || base.fileExists(file),
    readFile: file => sources.get(file.replaceAll('\\', '/')) ?? base.readFile(file),
    getSourceFile: (file, languageVersion, onError, shouldCreateNewSourceFile) => {
      const source = sources.get(file.replaceAll('\\', '/'))
      return source === undefined
        ? base.getSourceFile(file, languageVersion, onError, shouldCreateNewSourceFile)
        : ts.createSourceFile(file.replaceAll('\\', '/'), source, languageVersion, true)
    },
    writeFile: () => {
      throw new Error('doc typecheck attempted to write output')
    },
  }
  const program = ts.createProgram([...sources.keys()], options, host)
  return ts.getPreEmitDiagnostics(program).map(diagnostic => {
    const text = ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n')
    if (diagnostic.file === undefined) return text
    const index = [...sources.keys()].indexOf(diagnostic.file.fileName.replaceAll('\\', '/'))
    const block = blocks[index]
    const position = diagnostic.file.getLineAndCharacterOfPosition(diagnostic.start ?? 0)
    return `${block?.path ?? diagnostic.file.fileName}:${(block?.line ?? 0) + position.line + 1}: ${text}`
  })
}

function markdownFiles() {
  const found = []
  const walk = dir => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const path = join(dir, entry.name)
      if (entry.isDirectory()) walk(path)
      else if (entry.name.endsWith('.md')) found.push(path)
    }
  }
  for (const dir of ['docs', '.agents/notes', '.agents/skills']) {
    const path = join(root, dir)
    if (statSync(path, { throwIfNoEntry: false })?.isDirectory()) walk(path)
  }
  for (const file of ['README.md', 'AGENTS.md']) found.push(join(root, file))
  return found.filter(path => !relative(root, path).split('\\').join('/').startsWith('docs/verification/')
    && !relative(root, path).split('\\').join('/').startsWith('.agents/notes/archived/'))
}

function run() {
  const blocks = markdownFiles().flatMap(path => {
    const name = relative(root, path).split('\\').join('/')
    return extractTsBlocks(readFileSync(path, 'utf8'), name)
  })
  const unclosed = blocks.filter(block => block.unclosed)
  const diagnostics = compileBlocks(blocks.filter(block => !block.unclosed))
  const errors = [
    ...unclosed.map(block => `${block.path}:${block.line}: TypeScript fence is not closed`),
    ...diagnostics,
  ]
  if (errors.length > 0) {
    for (const error of errors) console.error(error)
    process.exitCode = 1
    return
  }
  console.log(`Documentation TypeScript check passed (${blocks.length} block(s)).`)
}

if (process.argv[1] === fileURLToPath(import.meta.url)) run()
