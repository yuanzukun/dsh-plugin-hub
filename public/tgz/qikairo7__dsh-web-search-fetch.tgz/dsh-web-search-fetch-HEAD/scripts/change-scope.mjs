import { execFileSync } from 'node:child_process'

function argument(name) {
  const index = process.argv.indexOf(name)
  return index >= 0 ? process.argv.at(index + 1) : undefined
}

function git(args) {
  return execFileSync('git', args, { encoding: 'utf8' }).trim()
}

function checksFor(paths) {
  const checks = new Set(['pnpm run check:repository'])
  for (const path of paths) {
    if (path.startsWith('src/')) {
      checks.add('pnpm run build')
      checks.add('pnpm run test')
      checks.add('pnpm run typecheck')
    }
    if (path.startsWith('lib/')) {
      checks.add('pnpm run build')
      checks.add('pnpm run check:distribution')
    }
    if (path.startsWith('test/')) {
      checks.add('pnpm run test')
      checks.add('pnpm run typecheck')
    }
    if (path === 'package.json' || path === 'pnpm-lock.yaml') {
      checks.add('pnpm run build')
      checks.add('pnpm run check:distribution')
    }
    if (path.startsWith('docs/') || path === 'AGENTS.md' || path.startsWith('.agents/notes/') || path.startsWith('.agents/skills/')) {
      checks.add('pnpm run check:docs')
    }
    if (path.startsWith('client/')) {
      checks.add('pnpm run build')
      checks.add('pnpm exec vitest run test/client-surface.test.ts')
    }
    if (path === 'scripts/check-docs.mjs') checks.add('pnpm run check:docs')
  }
  return [...checks]
}

function diffEntries(args) {
  return git(args)
    .split(/\r?\n/)
    .filter(Boolean)
    .map((line) => {
      const [status, ...pathParts] = line.split('\t')
      return { status, path: pathParts.at(-1) }
    })
}

const base = argument('--base') ?? 'origin/main'
const head = argument('--head') ?? 'HEAD'
const mergeBase = git(['merge-base', base, head])
const committed = diffEntries(['diff', '--name-status', `${mergeBase}...${head}`])
const workingTree = [
  ...diffEntries(['diff', '--name-status', 'HEAD']),
  ...execFileSync('git', ['ls-files', '--others', '--exclude-standard', '-z'], { encoding: 'utf8' })
    .split('\0')
    .filter(Boolean)
    .map((path) => ({ status: 'A', path })),
]
const paths = new Set([...committed, ...workingTree].map((item) => item.path))

console.log(JSON.stringify({
  base,
  mergeBase,
  head,
  committed,
  workingTree,
  checks: checksFor([...paths]),
}, null, 2))
