import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

import { readInstalledInterface } from './dsh-interface-catalog.mjs'

const root = fileURLToPath(new URL('../', import.meta.url))
const path = join(root, 'docs/dsh-web-interface-fields.json')
const facts = readInstalledInterface()
const rendered = `${JSON.stringify(facts, null, 2)}\n`

if (process.argv.includes('--check')) {
  let current = ''
  try {
    current = readFileSync(path, 'utf8')
  } catch {
    console.error('docs/dsh-web-interface-fields.json is missing')
  }
  if (current !== rendered) {
    console.error('docs/dsh-web-interface-fields.json is stale')
    console.error('Run pnpm run generate:dsh-interface and commit the generated fields.')
    process.exitCode = 1
  } else {
    console.log('DSH interface field check passed.')
  }
} else {
  writeFileSync(path, rendered)
  console.log('DSH interface fields generated: docs/dsh-web-interface-fields.json')
}
