import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { existsSync, readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { extname, join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('../', import.meta.url))

const targets = {
  verification: {
    dir: 'docs/verification',
    manifest: 'scripts/verification-freeze.json',
    exclude: new Set(['README.md']),
  },
  archived: {
    dir: '.agents/notes/archived',
    manifest: 'scripts/archived-notes-freeze.json',
    exclude: new Set(['.gitkeep']),
  },
}

/** @param {string} dir @param {Set<string>} exclude */
export function listFiles(dir, exclude) {
  const found = []
  const walk = (current) => {
    for (const entry of readdirSync(current, { withFileTypes: true })) {
      if (exclude.has(entry.name)) continue
      const full = join(current, entry.name)
      if (entry.isDirectory()) walk(full)
      else found.push(full)
    }
  }
  walk(dir)
  return found
}

/** @param {string} path */
export function hashFile(path) {
  const buffer = readFileSync(path)
  const text = ['.md', '.json', '.txt', '.csv', '.html', '.xml', '.ts', '.js'].includes(
    extname(path).toLowerCase(),
  )
  return createHash('sha256')
    .update(text ? buffer.toString('utf8').replace(/\r\n?/g, '\n') : buffer)
    .digest('hex')
}

/** @param {string} dir @param {Set<string>} exclude @param {string} baseRoot */
export function buildManifest(dir, exclude, baseRoot = root) {
  const manifest = {}
  for (const file of listFiles(dir, exclude).sort()) {
    manifest[relative(baseRoot, file).split('\\').join('/')] = hashFile(file)
  }
  return manifest
}

/** @param {string} dir @param {string} manifestPath @param {Set<string>} exclude @param {string} baseRoot */
export function checkManifest(dir, manifestPath, exclude, baseRoot = root) {
  const errors = []
  if (!existsSync(manifestPath)) return [`${relative(root, manifestPath)} is missing`]
  const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'))
  const files = listFiles(dir, exclude)
  const seen = new Set()
  for (const file of files) {
    const name = relative(baseRoot, file).split('\\').join('/')
    seen.add(name)
    if (manifest[name] === undefined) {
      errors.push(`${name}: new frozen file; run the matching freeze command`)
    } else if (manifest[name] !== hashFile(file)) {
      errors.push(`${name}: frozen file changed`)
    }
  }
  for (const name of Object.keys(manifest)) {
    if (!seen.has(name)) errors.push(`${name}: frozen file is missing`)
  }
  return errors
}

/** @param {string} dir @param {string} manifestPath @param {Set<string>} exclude @param {string} baseRoot */
export function writeManifest(dir, manifestPath, exclude, baseRoot = root) {
  writeFileSync(manifestPath, `${JSON.stringify(buildManifest(dir, exclude, baseRoot), null, 2)}\n`)
}

/** @param {Record<string, string>} previous @param {Record<string, string>} next */
export function manifestRemovals(previous, next) {
  return Object.keys(previous)
    .filter(name => next[name] === undefined)
    .map(name => `${name}: frozen entry cannot be removed`)
}

function readManifest(manifestPath) {
  return existsSync(manifestPath) ? JSON.parse(readFileSync(manifestPath, 'utf8')) : {}
}

function readBaseline(manifestPath) {
  const repoPath = relative(root, manifestPath).split('\\').join('/')
  try {
    return JSON.parse(execFileSync('git', ['show', `HEAD:${repoPath}`], {
      cwd: root,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
    }))
  } catch {
    return {}
  }
}

function main() {
  const [name, flag] = process.argv.slice(2)
  const target = targets[name]
  if (target === undefined || (flag !== '--check' && flag !== '--write')) {
    console.error('Usage: node scripts/freeze-manifest.mjs <verification|archived> <--check|--write>')
    process.exit(1)
  }
  const dir = join(root, target.dir)
  const manifestPath = join(root, target.manifest)
  if (flag === '--write') {
    const previous = { ...readBaseline(manifestPath), ...readManifest(manifestPath) }
    const next = buildManifest(dir, target.exclude)
    const removals = manifestRemovals(previous, next)
    if (removals.length > 0) {
      for (const error of removals) console.error(error)
      process.exitCode = 1
      return
    }
    writeManifest(dir, manifestPath, target.exclude)
    console.log(`${name} freeze manifest updated: ${target.manifest}`)
    return
  }
  const errors = [
    ...checkManifest(dir, manifestPath, target.exclude),
    ...manifestRemovals(readBaseline(manifestPath), readManifest(manifestPath)),
  ]
  if (errors.length > 0) {
    for (const error of errors) console.error(error)
    process.exitCode = 1
  } else {
    console.log(`${name} freeze check passed.`)
  }
}

if (process.argv[1] === fileURLToPath(import.meta.url)) main()
