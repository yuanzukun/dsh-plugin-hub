import { spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, readdirSync, rmSync } from 'node:fs'
import { basename, dirname, join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('../', import.meta.url))

export function validateTarEntries(entries) {
  const errors = []
  if (!entries.includes('package/package.json')) errors.push('package/package.json is missing')
  if (!entries.includes('package/lib/index.js')) errors.push('package/lib/index.js is missing')
  if (entries.some(entry => entry.startsWith('package/client/'))) {
    errors.push('package/client/ must not be distributed')
  }
  return errors
}

export function validateDumpConfig(output) {
  const errors = []
  if (!/web-search-fetch/.test(output)) errors.push('web-search-fetch plugin is missing')
  if (!/["']?searchProvider["']?\s*:\s*["']?aggregated/.test(output)) {
    errors.push('web.searchProvider is not aggregated')
  }
  if (!/["']?fetchProvider["']?\s*:\s*["']?aggregated/.test(output)) {
    errors.push('web.fetchProvider is not aggregated')
  }
  return errors
}

function argument(name) {
  const index = process.argv.indexOf(name)
  return index >= 0 ? process.argv.at(index + 1) : undefined
}

function quoteWindowsArgument(value) {
  if (!/[\s"]/u.test(value)) return value
  return `"${value
    .replace(/(\\*)"/gu, '$1$1\\"')
    .replace(/(\\+)$/u, '$1$1')}"`
}

function run(command, args, options = {}) {
  const windowsScript = process.platform === 'win32' && /\.(?:cmd|bat)$/iu.test(command)
  const executable = windowsScript ? 'C:\\Windows\\System32\\cmd.exe' : command
  const executableArgs = windowsScript
    ? ['/d', '/s', '/c', [command, ...args].map(quoteWindowsArgument).join(' ')]
    : args
  const result = spawnSync(executable, executableArgs, {
    cwd: root,
    encoding: 'utf8',
    shell: false,
    maxBuffer: 16 * 1024 * 1024,
    ...options,
  })
  if (!options.quiet && result.stdout) process.stdout.write(result.stdout)
  if (!options.quiet && result.stderr) process.stderr.write(result.stderr)
  if (result.error) throw result.error
  if (result.status !== 0) throw new Error(`${command} ${args.join(' ')} failed with exit ${result.status}`)
  return result
}

function packageTarball(destination) {
  mkdirSync(destination, { recursive: true })
  for (const entry of readdirSync(destination)) {
    if (entry.endsWith('.tgz')) rmSync(join(destination, entry), { force: true })
  }
  const npmCli = join(dirname(process.execPath), 'node_modules', 'npm', 'bin', 'npm-cli.js')
  const npmArgs = ['pack', '--ignore-scripts', '--json', '--pack-destination', relative(root, destination)]
  const result = existsSync(npmCli)
    ? run(process.execPath, [npmCli, ...npmArgs], { shell: false, quiet: true })
    : run('npm', npmArgs, { shell: false, quiet: true })
  const manifest = JSON.parse(result.stdout)
  const filename = (Array.isArray(manifest) ? manifest[0] : manifest).filename
  return join(destination, filename)
}

function tarEntries(tarball) {
  return run('tar', ['-tf', tarball], { shell: false, quiet: true }).stdout.split(/\r?\n/).filter(Boolean)
}

function dshExecutable(explicitPath) {
  if (explicitPath !== undefined) {
    if (!existsSync(explicitPath)) throw new Error(`DSH executable does not exist: ${explicitPath}`)
    return explicitPath
  }
  const local = join(root, 'node_modules', '.bin', process.platform === 'win32' ? 'dsh.cmd' : 'dsh')
  return existsSync(local) ? local : 'dsh'
}

function main() {
  const profile = argument('--profile')
  if (profile === undefined || profile.startsWith('-')) {
    throw new Error('Usage: pnpm run acceptance:host -- --profile <profile> [--dsh <executable>]')
  }
  const destination = join(root, '.scratch', 'host-acceptance')
  const tarball = packageTarball(destination)
  try {
    const packageErrors = validateTarEntries(tarEntries(tarball))
    if (packageErrors.length > 0) throw new Error(packageErrors.join('; '))

    const dsh = dshExecutable(argument('--dsh'))
    const packageRef = `file:${tarball.replaceAll('\\', '/')}`
    run(dsh, ['plugin', '--profile', profile, 'add', packageRef])
    const config = run(dsh, ['--profile', profile, '--dump-config']).stdout
    const configErrors = validateDumpConfig(config)
    if (configErrors.length > 0) throw new Error(configErrors.join('; '))
    console.log(`Host acceptance passed for profile ${profile}: package=${basename(tarball)}, client=absent, providers=aggregated.`)
  } finally {
    rmSync(destination, { recursive: true, force: true })
  }
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  try {
    main()
  } catch (error) {
    console.error(error.message)
    process.exitCode = 1
  }
}
