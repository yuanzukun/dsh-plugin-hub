// v0.4 真实抽样验收（任务图 N2 代码节点）：39 垂直 tag + 7 意图各一条真实查询，
// 端到端经 DSH 原生 web_search 工具面，产出 JSONL 逐行证据与汇总。
// 纪律：绝不打印密钥/请求头；总调用计数并断言 ≤60；--live 授权门同 live-probe。
// 路由判定先行记录（离线 import lib 的 routeSearchQuery），与真实派发对照——
// 触发词与路由判定不一致时如实记录，这正是验收要测的真实数据。
import { readFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { join } from 'node:path'
import yaml from 'yaml'
import { Context, Service } from '@deepseek-ai/cordis'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import * as ToolWeb from '@deepseek-ai/dsh-tool-web'
import WebRuntime from '@deepseek-ai/dsh-web'
import { ToolCallId } from '@deepseek-ai/dsh-llm'
import * as plugin from '../lib/index.js'
import { routeSearchQuery } from '../lib/search/router.js'

if (!process.argv.includes('--live')) throw new Error('pass --live to authorize real API requests')
const SAMPLE_LIMIT = Number(process.env.SAMPLE_LIMIT ?? 0)
const outPath = process.env.OUT ?? '.scratch/dev-loop/graphs/v04-closeout/sampling.jsonl'

// 39 垂直 tag 的自然触发词（对照 router 测试表与能力底账；general.general 不下发垂直，归入意图行）
const VERTICAL_SAMPLES = [
  ['finance.quote', '贵州茅台 股价'], ['finance.fundamental', '腾讯 财报'], ['finance.macro', '中国 GDP 增速'],
  ['finance.news', '今日 财经新闻'], ['finance.screen', '新能源 选股'], ['finance.calendar', '本周 财报日历'],
  ['academic.paper', '大语言模型 论文'], ['academic.citation', '这篇论文的 引文'], ['academic.dataset', '气候 数据集'],
  ['academic.person', '深度学习 学者'], ['code.snippet', 'python 快排 代码片段'], ['code.doc', 'react hooks 库文档'],
  ['security.vuln', 'CVE-2026-1234'], ['security.intel', '这个IP的 威胁情报'], ['security.scan', '文件哈希 扫描'],
  ['security.noise', '这个IP 背景噪声'], ['legal.judicial', '劳动纠纷 判例'], ['legal.legislation', '数据安全 法规'],
  ['legal.enforcement', '市场监管 行政处罚'], ['ip.global', '固态电池 专利'], ['travel.flight', '北京到上海 机票'],
  ['travel.flight_status', 'CA1831 航班'], ['business.company', '字节跳动 公司信息'], ['business.jobs', '前端工程师 招聘'],
  ['business.people', '销售总监 联系人'], ['business.trade', '芯片 进出口'], ['social_media.social_media', '微博热搜'],
  ['agriculture.fao', '全球粮食产量 农业'], ['energy.electricity', '德国 电价'], ['energy.production', '原油 能源产量'],
  ['environment.aqi', '北京 空气质量'], ['film.torrent', '4k 电影 种子'], ['gaming.store', '赛博朋克2077 Steam'],
  ['gaming.esports', '英雄联盟 电竞'], ['health.drug', '布洛芬 药品'], ['health.trial', '肺癌 临床试验'],
  ['health.stats', '全球 公共卫生统计'], ['resource.image', '星空 摄影 图片'],
]
const INTENT_SAMPLES = [
  ['ai-news', 'OpenAI 最新新闻'], ['hot-list', '今天有什么新闻'], ['community-opinion', '知乎 怎么看 人工智能'],
  ['english-web', 'kubernetes storage class best practices'], ['research', '多模态模型 综述'],
  ['chinese-web', '周末去哪玩 北京'], ['english-web:developer', 'react useeffect cleanup error'],
]

const CALL_BUDGET = 60
let calls = 0

async function loadKeys() {
  const sources = [{}]
  try {
    const file = JSON.parse(await readFile(process.env.PROBE_KEYS_JSON ?? '.scratch/dev-loop/keys.local.json', 'utf8'))
    sources.unshift({
      ...(file.anysearch ? { ANYSEARCH_API_KEY: file.anysearch } : {}),
      ...(file.tavily ? { TAVILY_API_KEY: file.tavily } : {}),
      ...(file.zhihu ? { ZHIHU_API_KEY: file.zhihu } : {}),
      ...(file.siliconflow ? { SILICONFLOW_API_KEY: file.siliconflow } : {}),
    })
    // Firecrawl key 按值前缀匹配（字段名不可靠）。
    const fc = Object.values(file).find(v => typeof v === 'string' && v.startsWith('fc-'))
    if (fc) sources[0].FIRECRAWL_API_KEY = fc
  } catch { /* 无本地密钥文件则仅环境变量 */ }
  try {
    const vault = yaml.parseDocument(await readFile(join(process.env.DSH_HOME ?? join(homedir(), '.dsh'), '.credentials.yaml'), 'utf8'), { logLevel: 'silent' }).toJS()
    sources.unshift(vault?.refs ?? {})
  } catch { /* 无宿主库 */ }
  return sources
}
class ReadOnlyCredentials extends Service {
  constructor(ctx, sources) { super(ctx, 'credentials'); this.sources = sources }
  async resolve(ref) {
    const env = process.env[String(ref)]?.trim()
    if (env) return { value: env, source: 'env' }
    for (const s of this.sources) {
      const v = s[String(ref)]
      if (typeof v === 'string' && v.trim()) return { value: v.trim(), source: 'keys' }
    }
    return undefined
  }
}

const ctx = new Context()
const fibers = []
const pipeline = []
const stopExport = ctx.logger.exporter({ levels: { default: 3 }, export(message) {
  const line = typeof message.args[0] === 'string' ? message.args[0] : ''
  if (/^\[(搜索|提取|熔断)\]/.test(line)) pipeline.push(line)
} })

/** v0.4 搜索日志把引擎写在归因（来源：anysearch×3）或逐路状态（各通道状态：...）里。 */
function enginesFromLog(line) {
  if (!line.startsWith('[搜索] ')) return []
  const ids = new Set()
  for (const match of line.matchAll(/(?:服务|引擎|单通道) ([a-z0-9-]+)/g)) ids.add(match[1])
  const attribution = /来源：([^。]+)。/.exec(line)
  if (attribution) for (const match of attribution[1].matchAll(/([a-z0-9-]+)×\d+/g)) ids.add(match[1])
  const lanes = /各通道状态：(.+?)。/.exec(line)
  if (lanes) for (const match of lanes[1].matchAll(/(?:^|；)([a-z0-9-]+) /g)) ids.add(match[1])
  return [...ids]
}

let sequence = 0
function classify(content) {
  if (content.includes('未找到与查询相关')) return 'empty'
  if (content.includes('被限流')) return 'rate-limited'
  if (content.includes('额度')) return 'quota'
  if (content.includes('垂直频道')) return 'vertical-degraded'
  return 'ok'
}

try {
  fibers.push(await ctx.plugin(SystemPrompt))
  fibers.push(await ctx.plugin(ToolRuntime))
  fibers.push(await ctx.plugin(WebRuntime, { searchProvider: 'aggregated', fetchProvider: 'aggregated' }))
  fibers.push(await ctx.plugin(ReadOnlyCredentials, await loadKeys()))
  const bundle = yaml.parse(await readFile(new URL('../cordis.patch.yml', import.meta.url), 'utf8'))
  const config = bundle.find(entry => entry.insert)?.insert.find(entry => entry.id === 'web-search-fetch')?.config
  fibers.push(await ctx.plugin(plugin, config))
  fibers.push(await ctx.plugin(ToolWeb, { search: true, fetch: true, searchMaxResults: 8, searchTimeoutMs: 60000, fetchTimeoutMs: 90000 }))

  const rows = []
  const runSample = async (kind, key, query) => {
    if (calls >= CALL_BUDGET) { rows.push({ kind, key, query, skipped: 'budget' }); return }
    calls += 1
    const route = routeSearchQuery(query)
    const pipelineAt = pipeline.length
    const started = Date.now()
    let result
    try {
      result = await ctx.tools.execute({ name: 'web_search', arguments: { queries: [query] }, callId: ToolCallId(`sample-${++sequence}`), signal: AbortSignal.timeout(90_000) })
    } catch (error) {
      rows.push({ kind, key, query, route: { intent: route.intent, tag: route.vertical?.tag }, outcome: 'tool-error', detail: String(error).slice(0, 120), ms: Date.now() - started })
      return
    }
    const content = typeof result.meta?.content === 'string' ? result.meta.content : ''
    const sources = result.meta?.sources?.length ?? 0
    if (result.isError) console.error('[isError]', JSON.stringify(result).slice(0, 600))
    rows.push({
      kind, key, query,
      route: { intent: route.intent, tag: route.vertical?.tag ?? null },
      ok: !result.isError, sources, contentChars: content.length,
      outcome: result.isError ? 'tool-error' : (sources > 0 ? 'sources' : (content.length > 0 ? classify(content) : 'empty')),
      note: content.slice(0, 200), ms: Date.now() - started,
      engines: [...new Set(pipeline.slice(pipelineAt).flatMap(enginesFromLog))],
    })
  }

  const limit = SAMPLE_LIMIT > 0 ? 1 : 0
  const vs = limit ? VERTICAL_SAMPLES.slice(0, 1) : VERTICAL_SAMPLES
  const is = limit ? INTENT_SAMPLES.slice(0, 1) : INTENT_SAMPLES
  for (const [tag, query] of vs) await runSample('vertical', tag, query)
  for (const [intent, query] of is) await runSample('intent', intent, query)

  const { writeFile } = await import('node:fs/promises')
  await writeFile(outPath, rows.map(row => JSON.stringify(row)).join('\n') + '\n', 'utf8')
  const summary = {
    total: rows.length, callsBudgetUsed: calls,
    verticalOk: rows.filter(r => r.kind === 'vertical' && ['sources', 'ok'].includes(r.outcome)).length,
    verticalClassified: rows.filter(r => r.kind === 'vertical' && ['rate-limited', 'quota', 'vertical-degraded', 'empty'].includes(r.outcome)).length,
    verticalUnexpected: rows.filter(r => r.kind === 'vertical' && ['tool-error', 'skipped'].includes(r.outcome)).length,
    intentOk: rows.filter(r => r.kind === 'intent' && !r.ok === false).length,
  }
  console.log(JSON.stringify({ summary, outPath }, null, 2))
} finally {
  stopExport()
  for (const fiber of fibers.reverse()) await fiber.dispose()
}
