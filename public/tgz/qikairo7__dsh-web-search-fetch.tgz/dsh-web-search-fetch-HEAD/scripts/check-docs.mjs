import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('../', import.meta.url))
const noteKinds = new Set(['architecture', 'process', 'feature', 'bug-fix', 'simplification', 'testing'])
const noteHeadings = {
  proposed: ['## Problem', '## Proposal', '## Alternatives considered', '## Acceptance criteria', '## Risks'],
  rejected: ['## Problem', '## Proposal', '## Alternatives considered', '## Acceptance criteria', '## Risks'],
  implemented: ['## Problem', '## Decision', '## Alternatives considered', '## Consequences'],
  archived: ['## Problem', '## Decision', '## Alternatives considered', '## Consequences'],
}

export function validateNote(text, path) {
  const errors = []
  const parts = path.split('/')
  if (parts.length !== 5 || !parts.at(-1).endsWith('.md')) {
    return [`${path}: expected .agents/notes/{lifecycle}/{kind}/yyyy-mm-dd-topic.md`]
  }

  const lifecycle = parts[2]
  const kind = parts[3]
  const filename = parts[4]
  if (!noteHeadings[lifecycle]) errors.push(`${path}: unknown lifecycle ${lifecycle}`)
  if (!noteKinds.has(kind)) errors.push(`${path}: unknown kind ${kind}`)
  const dateText = /^(\d{4}-\d{2}-\d{2})-[a-z\d-]+\.md$/.exec(filename)?.[1]
  if (!dateText || Number.isNaN(Date.parse(`${dateText}T00:00:00Z`))) {
    errors.push(`${path}: filename must be yyyy-mm-dd-topic.md`)
  }

  const lines = text.split(/\r?\n/)
  if (!/^# Agent Note: .+/.test(lines.at(0) ?? '')) {
    errors.push(`${path}: first line must be '# Agent Note: <title>'`)
  }
  const statusLine = lines[2]
  if (!statusLine) {
    errors.push(`${path}: missing Status line`)
  } else if (lifecycle === 'rejected') {
    if (!/^Status: rejected — .+/.test(statusLine)) errors.push(`${path}: rejected note needs a one-line reason`)
  } else if (statusLine !== `Status: ${lifecycle === 'archived' ? 'implemented' : lifecycle}`) {
    errors.push(`${path}: Status does not match lifecycle`)
  }
  const archivedDate = /^Archived: (\d{4}-\d{2}-\d{2})$/.exec(lines[4] ?? '')?.[1]
  if (lifecycle === 'archived' && (!archivedDate || Number.isNaN(Date.parse(`${archivedDate}T00:00:00Z`)))) {
    errors.push(`${path}: archived note needs 'Archived: yyyy-mm-dd'`)
  }

  const headingPositions = noteHeadings[lifecycle]?.map((heading) => lines.indexOf(heading)) ?? []
  const headingsOrdered = headingPositions.every((position, index) =>
    position >= 0 && (index === 0 || position > headingPositions[index - 1]))
  if (!headingsOrdered) {
    errors.push(`${path}: lifecycle headings are missing or out of order`)
  }
  for (const heading of noteHeadings[lifecycle] ?? []) {
    if (!lines.includes(heading)) errors.push(`${path}: missing ${heading}`)
  }
  if (lifecycle === 'implemented' || lifecycle === 'archived') {
    for (const forbidden of ['## Proposal', '## Plan', '## Migration plan', '## Acceptance criteria']) {
      if (lines.includes(forbidden)) errors.push(`${path}: implemented note contains ${forbidden}`)
    }
  }
  return errors
}

export function validateSkill(text, path) {
  const errors = []
  const folder = path.split('/').at(-2)
  const name = /^name:\s*(.+)$/m.exec(text)?.[1]?.trim()
  const description = /^description:\s*(.+)$/m.exec(text)?.[1]?.trim()
  if (name !== folder) errors.push(`${path}: name must equal folder name`)
  if (!description || description.length < 20 || description.length > 500) {
    errors.push(`${path}: description must be 20-500 characters`)
  }
  if (!/^# /m.test(text)) errors.push(`${path}: missing H1 title`)
  return errors
}

export function validatePublicSourceProvenance(text, path) {
  if (!/^(src|test|client|docs)\//.test(path) || path.startsWith('docs/verification/') || path.startsWith('docs/adr/')) return []
  const forbidden = /AD\d+|spec §|TODO-CUTOVER|api-contract-research|验收 R\d+|v\d+\.\d+|\.scratch\//u
  return forbidden.test(text) ? [`${path}: current source must cite a tracked owner, not untracked process provenance`] : []
}

export function validateDocumentCommands(text, path, packageScripts) {
  const errors = []
  for (const match of text.matchAll(/pnpm run ([A-Za-z0-9:_-]+)/g)) {
    if (!packageScripts.has(match[1])) errors.push(`${path}: unknown package script ${match[1]}`)
  }
  for (const match of text.matchAll(/node (scripts\/[A-Za-z0-9_./-]+\.mjs)/g)) {
    if (!existsSync(join(root, match[1]))) errors.push(`${path}: missing command file ${match[1]}`)
  }
  return errors
}

export function validateScriptProvenance(text, path) {
  const forbidden = /AD\d+|spec §|TODO-CUTOVER|api-contract-research|验收 R\d+|v\d+\.\d+/u
  return forbidden.test(text) ? [`${path}: script comments must state current behavior, not process history`] : []
}

function files(dir) {
  if (!statSync(dir, { throwIfNoEntry: false })?.isDirectory()) return []
  return readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const path = join(dir, entry.name)
    return entry.isDirectory() ? files(path) : [path]
  })
}

function run() {
  const errors = []
  for (const path of files(join(root, '.agents/notes'))) {
    const name = relative(root, path).split('\\').join('/')
    if (!name.endsWith('.md') || name.endsWith('README.md')) continue
    errors.push(...validateNote(readFileSync(path, 'utf8'), name))
  }
  for (const path of files(join(root, '.agents/skills'))) {
    const name = relative(root, path).split('\\').join('/')
    if (!name.endsWith('SKILL.md')) continue
    const text = readFileSync(path, 'utf8')
    errors.push(...validateSkill(text, name))
    if (text.split(/\r?\n/).length > 180) errors.push(`${name}: exceeds 180 lines`)
  }
  for (const path of [...files(join(root, 'src')), ...files(join(root, 'test')), ...files(join(root, 'client')), ...files(join(root, 'docs'))]) {
    const name = relative(root, path).split('\\').join('/')
    if (/\.(?:ts|js|mjs|md)$/.test(name)) {
      errors.push(...validatePublicSourceProvenance(readFileSync(path, 'utf8'), name))
    }
  }
  for (const path of files(join(root, 'scripts'))) {
    const name = relative(root, path).split('\\').join('/')
    if (name.endsWith('.mjs') && name !== 'scripts/check-docs.mjs' && name !== 'scripts/check-repository.mjs') {
      errors.push(...validateScriptProvenance(readFileSync(path, 'utf8'), name))
    }
  }
  const workflow = readFileSync(join(root, 'docs/workflow.md'), 'utf8')
  if (workflow.split(/\r?\n/).length > 220) errors.push('docs/workflow.md: exceeds 220 lines')
  const packageScripts = new Set(Object.keys(JSON.parse(readFileSync(join(root, 'package.json'), 'utf8')).scripts))
  for (const path of [...files(join(root, 'docs')), join(root, 'AGENTS.md'), join(root, 'README.md'), join(root, 'CONTRIBUTING.md'), join(root, 'SECURITY.md')]) {
    const name = relative(root, path).split('\\').join('/')
    if (path.endsWith('.md') && !name.startsWith('docs/verification/')) {
      errors.push(...validateDocumentCommands(readFileSync(path, 'utf8'), name, packageScripts))
    }
  }
  if (errors.length > 0) {
    for (const error of errors) console.error(error)
    process.exitCode = 1
    return
  }
  console.log('Documentation governance check passed.')
}

if (process.argv[1] === fileURLToPath(import.meta.url)) run()
