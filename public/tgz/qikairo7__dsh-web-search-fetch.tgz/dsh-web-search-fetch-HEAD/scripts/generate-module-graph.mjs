import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

import { buildModuleGraph, renderModuleGraph } from './module-graph.mjs'

const root = fileURLToPath(new URL('../', import.meta.url))
const path = join(root, 'docs/module-graph.md')
const rendered = renderModuleGraph(buildModuleGraph(root))
const check = process.argv.includes('--check')

if (check) {
  let current = ''
  try {
    current = readFileSync(path, 'utf8')
  } catch {
    console.error('docs/module-graph.md is missing')
  }
  if (current !== rendered) {
    console.error('docs/module-graph.md is stale')
    console.error('Run pnpm run generate:module-graph and commit the generated graph.')
    process.exitCode = 1
  } else {
    console.log('Module graph check passed.')
  }
} else {
  writeFileSync(path, rendered)
  console.log('Module graph generated: docs/module-graph.md')
}
