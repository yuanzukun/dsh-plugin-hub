// 真实调用探针。
// 本地 Cordis 运行时装载构建产物，注册 aggregated 双 provider，经 DSH 原生
// web_search / web_fetch 工具面发起真实请求；另对各引擎直接调 quota() 取额度证据。
// 密钥来源（优先级）：环境变量 > keys JSON（PROBE_KEYS_JSON 路径，缺省仓库相对
// ./.scratch/dev-loop/keys.local.json，gitignored）> ~/.dsh/.credentials.yaml。
// 纪律：绝不打印请求头、密钥原文或上游原始失败体；真实请求消耗服务额度。
// 用法：node scripts/live-probe.mjs --live [--search-only | --fetch-only | --quota-only]
import { readFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { join } from 'node:path'
import yaml from 'yaml'
import { Context, Service } from '@deepseek-ai/cordis'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import * as ToolWeb from '@deepseek-ai/dsh-tool-web'
import WebRuntime from '@deepseek-ai/dsh-web'
import { ToolCallId } from '@deepseek-ai/dsh-llm'
import * as plugin from '../lib/index.js'
import { createQuotaPanelRuntime } from '../lib/index.js'
import { buildEngines, ENGINE_MANIFESTS } from '../lib/engines/registry.js'
import { CircuitBreaker } from '../lib/support/breaker.js'
import { QuotaLedger } from '../lib/support/quota-ledger.js'
import { createAnysearchEngine } from '../lib/engines/anysearch.js'
import { createTavilyEngine } from '../lib/engines/tavily.js'
import { createFirecrawlEngine } from '../lib/engines/firecrawl.js'
import { createExaEngine } from '../lib/engines/exa.js'
import { createZhihuEngine } from '../lib/engines/zhihu.js'
import { createAihotEngine } from '../lib/engines/aihot.js'

if (!process.argv.includes('--live')) throw new Error('pass --live to authorize real API requests')
const searchOnly = process.argv.includes('--search-only')
const fetchOnly = process.argv.includes('--fetch-only')
const quotaOnly = process.argv.includes('--quota-only')

/** 引擎 id → 凭证引用名（与 Config 默认一致）。 */
const ENGINE_ENV = {
  anysearch: 'ANYSEARCH_API_KEY',
  tavily: 'TAVILY_API_KEY',
  firecrawl: 'FIRECRAWL_API_KEY',
  zhihu: 'ZHIHU_API_KEY',
  siliconflow: 'SILICONFLOW_API_KEY',
}

async function loadKeySources() {
  const sources = [{}]
  try {
    const path = process.env.PROBE_KEYS_JSON ?? '.scratch/dev-loop/keys.local.json'
    const file = JSON.parse(await readFile(path, 'utf8'))
    if (file === null || typeof file !== 'object' || Array.isArray(file)) {
      throw Object.assign(new Error('keys file must be a JSON object'), { code: 'EKEYS' })
    }
    // 本地 keys 文件用引擎字段名。
    sources.unshift({
      ...(file.anysearch === undefined ? {} : { ANYSEARCH_API_KEY: file.anysearch }),
      ...(file.tavily === undefined ? {} : { TAVILY_API_KEY: file.tavily }),
      ...(file.firecrawl === undefined ? {} : { FIRECRAWL_API_KEY: file.firecrawl }),
      ...(file.zhihu === undefined ? {} : { ZHIHU_API_KEY: file.zhihu }),
      ...(file.siliconflow === undefined ? {} : { SILICONFLOW_API_KEY: file.siliconflow }),
    })
  } catch (error) {
    if (error?.code === 'ENOENT') {
      // 无本地 keys 文件：回退环境变量/宿主凭证库。
    } else if (error?.code === 'EKEYS') {
      console.warn(`${error.message}; falling back to env/credentials`)
    } else if (error instanceof SyntaxError) {
      console.warn('local keys file is not valid JSON; falling back to env/credentials')
    } else {
      console.warn(`local keys file not loaded (${error?.code ?? 'error'}); falling back to env/credentials`)
    }
  }
  try {
    const vault = yaml.parseDocument(
      await readFile(join(process.env.DSH_HOME ?? join(homedir(), '.dsh'), '.credentials.yaml'), 'utf8'),
      { logLevel: 'silent' },
    ).toJS()
    sources.unshift(vault?.refs ?? {})
  } catch { /* 无宿主凭证库则跳过 */ }
  return sources
}
const keySources = await loadKeySources()
async function resolveCredential(ref) {
  const fromEnv = process.env[ref]?.trim()
  if (fromEnv) return { value: fromEnv, source: 'env' }
  for (const source of keySources) {
    const value = source[ref]
    if (typeof value === 'string' && value.trim()) return { value: value.trim(), source: 'keys-file' }
  }
  return undefined
}
class ReadOnlyCredentials extends Service {
  constructor(ctx) { super(ctx, 'credentials') }
  async resolve(ref) { return await resolveCredential(String(ref)) }
}

const ctx = new Context()
const fibers = []
const report = { checks: [], quotas: [], pipeline: {} }

const stopExport = ctx.logger.exporter({ levels: { default: 3 }, export(message) {
  const line = typeof message.args[0] === 'string' ? message.args[0] : ''
  if (/^(\[搜索\]|\[提取\]|\[熔断\])/.test(line)) {
    report.pipeline[line.slice(0, 120)] = (report.pipeline[line.slice(0, 120)] ?? 0) + 1
  }
} })

let sequence = 0
async function call(name, args) {
  const started = Date.now()
  const result = await ctx.tools.execute({ name, arguments: args, callId: ToolCallId(`probe-${++sequence}`), signal: AbortSignal.timeout(90_000) })
  const check = { name, args: name === 'web_search' ? args.queries : args.url, ok: !result.isError, ms: Date.now() - started }
  if (name === 'web_search') {
    check.sources = result.meta?.sources?.length ?? 0
    check.note = typeof result.meta?.content === 'string' ? result.meta.content.slice(0, 160) : undefined
  } else {
    check.chars = typeof result.meta?.body?.content === 'string' ? result.meta.body.content.length : undefined
  }
  report.checks.push(check)
  return result
}

try {
  fibers.push(await ctx.plugin(SystemPrompt))
  fibers.push(await ctx.plugin(ToolRuntime))
  fibers.push(await ctx.plugin(WebRuntime, { searchProvider: 'aggregated', fetchProvider: 'aggregated' }))
  fibers.push(await ctx.plugin(ReadOnlyCredentials))
  const bundle = yaml.parse(await readFile(new URL('../cordis.patch.yml', import.meta.url), 'utf8'))
  const config = bundle.find(entry => entry.insert)?.insert.find(entry => entry.id === 'web-search-fetch')?.config
  if (config === undefined) throw new Error('cordis.patch.yml 缺少 web-search-fetch 配置')
  fibers.push(await ctx.plugin(plugin, config))
  fibers.push(await ctx.plugin(ToolWeb, { search: true, fetch: true, searchMaxResults: 8, searchTimeoutMs: 60_000, fetchTimeoutMs: 90_000 }))

  // R9 语法翻译：site: 限定 + 时效词分别真实调用。
  if (!fetchOnly && !quotaOnly) {
    const plain = await call('web_search', { queries: ['DeepSeek Harness 插件开发'] })
    if (plain.isError || !(plain.meta?.sources?.length > 0)) throw new Error('plain search returned no sources')
    await call('web_search', { queries: ['cordis 插件 site:github.com'] })
    await call('web_search', { queries: ['最新 AI 搜索引擎 开源 动态'] })
  }
  if (!searchOnly && !quotaOnly) {
    await call('web_fetch', { url: 'https://example.com' })
    await call('web_fetch', { url: 'https://raw.githubusercontent.com/deepseek-ai/deepseek-harness/master/README.md' })
  }

  // R3 额度取证：对带 quota 能力的引擎直接调用（走装配后的上下文与真实凭证）。
  const engines = buildEngines({
    anysearch: createAnysearchEngine(),
    tavily: createTavilyEngine(),
    firecrawl: createFirecrawlEngine(),
    exa: createExaEngine(),
    zhihu: createZhihuEngine(),
    aihot: createAihotEngine(),
  })
  if (!searchOnly && !fetchOnly) {
    // 面板链路（主证据）：真实调用 get()/refresh()，断言快照仓与熔断副作用。
    const panelLedger = new QuotaLedger()
    const panelEvents = []
    const panelBreaker = new CircuitBreaker({ onEvent: event => panelEvents.push(event) })
    const probeBuildContext = async (manifest, op, lane) => {
      const ref = ENGINE_ENV[manifest.id]
      const credential = ref === undefined ? undefined : await resolveCredential(ref)
      return {
        signal: lane.signal,
        deadline: lane.deadline,
        ...(credential === undefined ? {} : { apiKey: credential.value }),
        endpoint: manifest.endpoints.quota ?? manifest.endpoints.search ?? 'https://invalid.local',
        countRequest: () => op.countRequest(),
      }
    }
    const panelRuntime = createQuotaPanelRuntime({
      engines,
      ledger: panelLedger,
      breaker: panelBreaker,
      buildContext: probeBuildContext,
      resolveControls: () => ({
        serviceEnabled: Object.fromEntries(ENGINE_MANIFESTS.map(manifest => [manifest.id, true])),
        maxRequests: 32,
      }),
    })
    const beforeRefresh = panelRuntime.service.get()
    const refreshed = await panelRuntime.service.refresh()
    const panelFailures = []
    if (beforeRefresh.engines.length !== 6) panelFailures.push(`get() 行数 ${beforeRefresh.engines.length} ≠ 6`)
    if (!/^\d{4}-\d{2}-\d{2}$/u.test(refreshed.day)) panelFailures.push(`day 不是 YYYY-MM-DD：${refreshed.day}`)
    for (const row of refreshed.engines) {
      const engine = engines.find(candidate => candidate.manifest.id === row.id)
      if (engine?.quota === undefined) {
        if (row.official !== undefined) panelFailures.push(`${row.id}: 无 quota() 却有 official`)
        continue
      }
      const snapshot = panelRuntime.store.get(row.id)
      if (snapshot === undefined) panelFailures.push(`${row.id}: 快照仓未写入`)
      else if (row.official?.kind !== snapshot.kind) panelFailures.push(`${row.id}: payload 与快照仓不一致`)
      if (row.official?.kind === 'ok' && row.official.remaining !== undefined) {
        const expectedBroken = row.official.remaining <= 0
        const status = panelBreaker.status(row.id)
        if (status.broken !== expectedBroken) panelFailures.push(`${row.id}: 熔断态 ${status.broken} 与 remaining ${row.official.remaining} 不一致`)
      }
    }
    if (panelFailures.length > 0) throw new Error(`面板链路断言失败：${panelFailures.join('；')}`)
    report.panel = {
      day: refreshed.day,
      beforeRefreshOfficials: beforeRefresh.engines.filter(row => row.official !== undefined).length,
      rows: refreshed.engines.map(row => ({
        id: row.id,
        enabled: row.enabled,
        period: row.period,
        official: row.official?.kind ?? 'unset',
        ...(row.official?.kind === 'ok'
          ? { used: row.official.used, limit: row.official.limit, remaining: row.official.remaining, resetsAt: row.official.resetsAt }
          : row.official?.kind === 'unavailable' ? { reason: row.official.reason } : {}),
        ledger: row.ledger,
        breaker: row.breaker,
      })),
      breakerEvents: panelEvents.map(event => `${event.type}:${event.engineId}:${event.reason}`),
    }

    // engine.quota() 直探降为附加证据（不再单独充当 Host 侧交付证据）。
    await Promise.all(engines.filter(engine => engine.quota !== undefined).map(async engine => {
      const manifest = ENGINE_MANIFESTS.find(entry => entry.id === engine.manifest.id)
      const ref = ENGINE_ENV[engine.manifest.id]
      const credential = ref === undefined ? undefined : await resolveCredential(ref)
      const quotaContext = {
        signal: AbortSignal.timeout(20_000),
        deadline: Date.now() + 20_000,
        ...(credential === undefined ? {} : { apiKey: credential.value }),
        endpoint: manifest.endpoints.quota ?? manifest.endpoints.search ?? 'https://invalid.local',
        countRequest: () => true,
      }
      const started = Date.now()
      try {
        const quota = await engine.quota(quotaContext)
        report.quotas.push({ id: engine.manifest.id, ms: Date.now() - started,
          available: quota.available, used: quota.used, limit: quota.limit,
          remaining: quota.remaining, resetsAt: quota.resetsAt,
          ...(quota.raw === undefined ? {} : { raw: quota.raw.slice(0, 200) }),
          ...(manifest.id === 'tavily' && quota.available === false && credential === undefined ? { note: 'keyless 模式 /usage 需密钥（N/A 符合契约）' } : {}) })
      } catch (error) {
        report.quotas.push({ id: engine.manifest.id, ms: Date.now() - started, error: error instanceof Error ? error.message.slice(0, 120) : 'ERROR' })
      }
    }))
    if (report.quotas.length === 0) report.quotas.push({ note: '没有引擎暴露 quota()' })
  }

  const summary = {
    checks: report.checks.length,
    ok: report.checks.filter(check => check.ok).length,
    panelRows: report.panel?.rows.length ?? 0,
    directQuotas: report.quotas.length,
  }
  console.log(JSON.stringify({
    summary,
    checks: report.checks,
    panel: report.panel,
    directQuotas: report.quotas,
    pipelineLines: Object.keys(report.pipeline).length,
  }, null, 2))
} finally {
  for (const fiber of fibers.reverse()) await fiber.dispose()
  stopExport()
}
