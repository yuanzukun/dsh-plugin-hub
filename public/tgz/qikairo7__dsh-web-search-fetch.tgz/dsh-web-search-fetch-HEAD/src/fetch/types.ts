// v0.3 提取层共享类型 —— 形状移植自 v0.2 src/fetch-aggregate.ts 的 FetchCandidate。
// 一个引擎对同一 URL 的一次提取结果：引擎 id + seam 结果（可选的接收时间）。
// 提取编排与正文整理只依赖本类型，不 import 具体引擎模块（AD2 分层）。

import type { WebFetchResult } from '@deepseek-ai/dsh-web'

/** 单路提取候选。 */
export interface FetchCandidate {
  readonly engineId: string
  readonly result: WebFetchResult
  readonly receivedAt?: string
}
