// URL 感知分流（纯函数规则表，可单测）。
// 判定顺序：分流关闭 → 不可解析/非 http(s) → 静态域名画像 → 静态扩展名 → 动态。
// 分流只决定「交给内置 HTTP 单发」还是「交给多路提取引擎」，不涉及任何具体引擎 id。

/** 提取管线的两条派发路线。 */
export type FetchRoute = 'static' | 'dynamic'

/**
 * 默认静态扩展名表（`.txt/.xml/.json/.md/.csv 等`）。
 * 不在表内的扩展名（`.pdf`、`.html`、无扩展名、未知）一律走动态路：
 * PDF 与未知页面交给提取引擎集合。
 */
export const DEFAULT_STATIC_EXTENSIONS: readonly string[] = [
  'txt',
  'text',
  'xml',
  'json',
  'md',
  'markdown',
  'csv',
  'tsv',
  'rss',
  'atom',
  'yaml',
  'yml',
  'log',
  'ini',
  'toml',
  'ics',
  'vtt',
  'srt',
]

/** 路由参数；每个字段都有生产默认值。 */
export interface FetchRouteOptions {
  /** `false` 完全关闭 URL 感知：所有提取都走 HTTP 单发。 */
  readonly enabled?: boolean
  /** 静态扩展名表；条目可以带前导点、大小写不限。 */
  readonly staticExtensions?: readonly string[]
  /** 静态域名画像：主机相等或为其点界子域。 */
  readonly staticDomains?: readonly string[]
}

/**
 * 判定单个 URL 的路线。规则按顺序：
 *
 * 1. 分流关闭 → `static`（直通配置）。
 * 2. 不可解析或非 HTTP(S) URL → `static`，让拥有 URL 校验的 HTTP 提取器给出 `WEB_INVALID_URL`。
 * 3. 主机等于配置的静态域名，或为其点界子域 → `static`（域名画像优先于路径）。
 * 4. 路径末段带表内扩展名 → `static`。
 * 5. 其余 → `dynamic`。
 */
export function classifyFetchRoute(rawUrl: string, options: FetchRouteOptions = {}): FetchRoute {
  if (options.enabled === false) return 'static'
  let url: URL
  try {
    url = new URL(rawUrl)
  } catch {
    return 'static'
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return 'static'

  const host = url.hostname.toLowerCase()
  for (const domain of options.staticDomains ?? []) {
    const normalized = domain.trim().toLowerCase().replace(/^\.+/, '')
    if (normalized.length === 0) continue
    if (host === normalized || host.endsWith(`.${normalized}`)) return 'static'
  }

  const lastSegment = url.pathname.split('/').pop() ?? ''
  const dot = lastSegment.lastIndexOf('.')
  if (dot > 0) {
    const extension = lastSegment.slice(dot + 1).toLowerCase()
    const table = options.staticExtensions ?? DEFAULT_STATIC_EXTENSIONS
    if (table.some(entry => entry.replace(/^\./, '').toLowerCase() === extension)) return 'static'
  }
  return 'dynamic'
}
