import { WebError, type WebFetchRequest, type WebFetchResult } from '@deepseek-ai/dsh-web'
import { blockedTargetError, guardTargetAddress, type AddressLookup } from '../support/address-guard.js'
import type { OpContext } from '../support/budget.js'
import type { FetchPipelineLogger } from './aggregate.js'
import type { StaticHttpFetcher } from './provider.js'
import type { FetchRouteOptions } from './route.js'

interface TargetGuardOptions {
  readonly blockPrivateAddresses?: boolean
  readonly route?: FetchRouteOptions
  readonly lookup?: AddressLookup
  readonly logger?: FetchPipelineLogger
}

/** 私有目标不得抵达专用 API、适配器或任何第三方引擎。 */
export async function guardFetchTarget(
  url: string,
  op: OpContext,
  options: TargetGuardOptions,
): Promise<void> {
  if (options.blockPrivateAddresses === false) return
  const verdict = await guardTargetAddress(url, {
    exemptHosts: options.route?.staticDomains ?? [],
    ...(options.lookup === undefined ? {} : { lookup: options.lookup }),
    signal: op.signal,
  })
  if (verdict.allowed) return
  options.logger?.warn(
    `[提取] 拒绝把本机或内网目标外发给提取服务：${url}${verdict.address === undefined ? '' : `（${verdict.address}）`}`,
  )
  throw blockedTargetError(url, verdict.address)
}

/** 静态路：单次 HTTP 抓取，零引擎调用。 */
export async function fetchStatic(
  request: WebFetchRequest,
  op: OpContext,
  http: StaticHttpFetcher | undefined,
): Promise<WebFetchResult> {
  if ((op.controls.serviceEnabled?.http ?? true) !== true) {
    throw new WebError('直接 HTTP 抓取已关闭，无法提取此静态 URL；请启用该服务后重试。', 'WEB_PROVIDER_ERROR')
  }
  if (http === undefined) {
    throw new WebError('未配置内置 HTTP 提取器，无法提取此静态 URL。', 'WEB_PROVIDER_ERROR')
  }
  const result = await http.fetch(request, op.signal)
  if ((result.statusCode < 200 || result.statusCode >= 300) && result.body.content.trim().length === 0) {
    throw new WebError(`静态抓取失败：目标站返回 HTTP ${result.statusCode} 且无正文`, 'WEB_BLOCKED_URL')
  }
  return result
}

/** 操作自身取消 → seam 的取消码。 */
export function abortedError(signal: AbortSignal): WebError {
  return new WebError('Aggregated web fetch aborted', 'WEB_ABORTED', { cause: signal.reason })
}
