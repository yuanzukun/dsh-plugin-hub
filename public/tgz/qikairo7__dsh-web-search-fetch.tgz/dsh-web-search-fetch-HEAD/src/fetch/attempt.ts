// 单次提取尝试：一次引擎调用从 deadline、异常收敛、空正文判定到结局结算，
// 由两段式 provider 与多路聚合共用。调用方只消费 ExtractionAttempt，不重复解释 LaneOutcome。

import { WebError } from '@deepseek-ai/dsh-web'

import type { Engine, EngineContext, EngineFetchOutcome, EngineManifest } from '../engines/contract.js'
import { engineFailure, type EngineFailure, type EngineFailureKind } from '../engines/failure.js'
import type { OpContext } from '../support/budget.js'
import { failureFromUnknown, runLane, type LaneLogSink } from '../support/lane-runner.js'
import type { LaneSettlement } from '../support/lane-settlement.js'
import type { FetchCandidate } from './types.js'

/** 提取管线日志汇（装配层映射到 ctx.logger）。 */
export interface FetchPipelineLogger {
  info(message: string): void
  warn(message: string): void
}

/** 装配层提供的引擎上下文构造器：凭证解析、端点覆盖、keyless 回退都归装配。 */
export type BuildEngineContext = (
  manifest: EngineManifest,
  op: OpContext,
  lane: { signal: AbortSignal; deadline: number; face: 'fetch' | 'quota' },
) => Promise<EngineContext>

/** fetch 层兜底投影可能携带引擎违约上抛的原始 seam 码。 */
export interface FetchLaneFailure extends EngineFailure {
  readonly webCode?: string
}

/** 一次成功、失败、超时或被取消的提取尝试。 */
export type ExtractionAttempt =
  | { readonly kind: 'ok'; readonly engineId: string; readonly candidate: FetchCandidate; readonly elapsedMs: number }
  | { readonly kind: 'failed'; readonly engineId: string; readonly failure: EngineFailure; readonly code: string; readonly description: string; readonly elapsedMs: number }
  | { readonly kind: 'timeout'; readonly engineId: string; readonly failure: EngineFailure; readonly code: 'WEB_FETCH_TIMEOUT'; readonly description: string; readonly elapsedMs: number }
  | { readonly kind: 'aborted'; readonly engineId: string }

export interface ExtractionAttemptOptions {
  readonly engine: Engine
  readonly url: string
  readonly op: OpContext
  readonly buildContext: BuildEngineContext
  readonly deadlineMs: number
  /** 该路的上游取消信号；缺省只跟随操作信号。 */
  readonly signal?: AbortSignal
  readonly settlement?: LaneSettlement
  readonly logger?: FetchPipelineLogger
  readonly now?: () => number
}

/** 跑一次提取并结算；永不抛出，调用方按结局继续编排。 */
export async function runExtractionAttempt(options: ExtractionAttemptOptions): Promise<ExtractionAttempt> {
  const { engine, url, op, buildContext, deadlineMs } = options
  const now = options.now ?? Date.now
  const engineId = engine.manifest.id
  const outcome = await runLane<EngineFetchOutcome>({
    engineId,
    signal: options.signal ?? op.signal,
    deadlineMs,
    now,
    work: async signal => {
      try {
        const context = await buildContext(engine.manifest, op, { signal, deadline: now() + deadlineMs, face: 'fetch' })
        return await engine.fetch!(url, context)
      } catch (error) {
        return { ok: false, failure: failureFromThrown(error) }
      }
    },
    ...(options.logger === undefined ? {} : { log: laneLogSink(options.logger) }),
  })
  if (outcome.kind !== 'ok' || isUsableCandidate(outcome.result)) {
    options.settlement?.settle(outcome)
  }

  switch (outcome.kind) {
    case 'aborted':
      return { kind: 'aborted', engineId }
    case 'timeout':
      return {
        kind: 'timeout',
        engineId,
        failure: engineFailure('timeout', { detail: `timed out after ${deadlineMs} ms` }),
        code: 'WEB_FETCH_TIMEOUT',
        description: `timed out after ${deadlineMs} ms`,
        elapsedMs: outcome.elapsedMs,
      }
    case 'failed':
      return {
        kind: 'failed',
        engineId,
        failure: outcome.failure,
        code: failureWebCode(outcome.failure),
        description: outcome.failure.detail ?? outcome.failure.kind,
        elapsedMs: outcome.elapsedMs,
      }
    case 'ok':
      if (!isUsableCandidate(outcome.result)) {
        return {
          kind: 'failed',
          engineId,
          failure: engineFailure('provider-error', { detail: 'empty body' }),
          code: 'WEB_PROVIDER_ERROR',
          description: 'empty body',
          elapsedMs: outcome.elapsedMs,
        }
      }
      return {
        kind: 'ok',
        engineId,
        candidate: {
          engineId,
          result: outcome.result,
          receivedAt: new Date(now()).toISOString(),
        },
        elapsedMs: outcome.elapsedMs,
      }
  }
}

function isUsableCandidate(result: EngineFetchOutcome): boolean {
  return result.body.content.trim().length > 0
}

/** 单路日志汇：带引擎前缀转发到管线 logger。 */
export function laneLogSink(logger: FetchPipelineLogger): LaneLogSink {
  return {
    laneInfo: (engineId, message) => logger.info(`[提取] ${engineId} ${message}`),
    laneWarn: (engineId, message) => logger.warn(`[提取] ${engineId} ${message}`),
  }
}

function preservedWebCode(failure: EngineFailure): string | undefined {
  const code = (failure as EngineFailure & { readonly webCode?: unknown }).webCode
  return typeof code === 'string' && code.length > 0 ? code : undefined
}

/**
 * 统一失败模型 → seam 的 WEB_* 码。
 * target-status 默认按目标站被拦；AnySearch HTTP 422 的普通提取失败仍归引擎侧，
 * 业务码 extract_target_blocked 优先。
 */
export function failureWebCode(failure: EngineFailure): string {
  const preserved = preservedWebCode(failure)
  if (preserved !== undefined) return preserved
  switch (failure.kind) {
    case 'target-status':
      return failure.statusCode === 422 && !isExtractTargetBlocked(failure) ? 'WEB_PROVIDER_ERROR' : 'WEB_BLOCKED_URL'
    case 'invalid': return 'WEB_INVALID_URL'
    case 'timeout': return 'WEB_FETCH_TIMEOUT'
    case 'aborted': return 'WEB_ABORTED'
    default: return 'WEB_PROVIDER_ERROR'
  }
}

function isExtractTargetBlocked(failure: EngineFailure): boolean {
  return failure.detail?.toLowerCase().includes('error_code=extract_target_blocked') ?? false
}

/** 引擎违反「不上抛」契约时的兜底投影：原始 WebError 码保真。 */
export function failureFromThrown(error: unknown): FetchLaneFailure {
  if (!(error instanceof WebError)) return failureFromUnknown(error)
  const kind: EngineFailureKind = (() => {
    switch (error.code) {
      case 'WEB_BLOCKED_URL': return 'target-status'
      case 'WEB_INVALID_URL': return 'invalid'
      case 'WEB_FETCH_TIMEOUT': return 'timeout'
      case 'WEB_ABORTED': return 'aborted'
      default: return 'provider-error'
    }
  })()
  return { ...engineFailure(kind, { detail: error.message }), webCode: error.code }
}
