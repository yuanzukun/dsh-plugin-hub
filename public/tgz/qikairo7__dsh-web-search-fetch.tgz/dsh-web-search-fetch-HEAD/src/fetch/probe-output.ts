import type { WebFetchRequest, WebFetchResult } from '@deepseek-ai/dsh-web'
import { organizeDocuments } from './document/organize.js'
import type { FetchCandidate } from './types.js'

/** 首路原文超出单页预算时，按完整内容块省略并标记 truncated。 */
export function serveProbeUnderBudget(
  request: WebFetchRequest,
  result: WebFetchResult,
  budget: number,
  requestCount: number,
): WebFetchResult {
  if (result.body.content.length <= budget) return result
  const candidate: FetchCandidate = { engineId: 'probe', result }
  return organizeDocuments(request.url, [candidate], budget, [
    `首路原文 ${result.body.content.length} 字符超过单页输出预算 ${budget}，已按预算省略完整内容块。`,
    `本插件 HTTP 请求：${requestCount} 次。`,
  ])
}
