// v0.3 聚合提取 provider——v0.2 src/fetch-pipeline.ts 的 AggregatedFetchProvider 重设计。
// 入口 = runOperation + 地址守卫 → classifyFetchRoute 分流：
// - 静态路：交给构造注入的 HTTP fetcher（v0.2 注入式 HTTP fetcher 模式保留，不 new 具体实现）；
// - 动态路：两段式（auto 先探测一路，正文够直接返回原文；不足则升级多路整理）；
//   single 保留 v0.2 的 singleChannelEscalate 语义；超预算走整理路径 + truncated；
// - AIHOT 专用 API 面：按 manifest capabilities 'aihot-api' 判定，读取器由装配层注入
//   （provider 不 import 具体引擎模块，AD2）。
// 探测硬超时（spec §5）：探测与单通道路都由 runLane 的 deadline 竞速执行，忽略 signal 的引擎
// 也会在 probeTimeoutMs 到期时被丢弃，不会拖到操作总限时。

import { WebError } from '@deepseek-ai/dsh-web'
import type { WebFetchProvider, WebFetchRequest, WebFetchResult } from '@deepseek-ai/dsh-web'

import type { Engine, EngineContext, EngineFetchOutcome, EngineManifest, EngineResult } from '../engines/contract.js'
import { engineFailure, type EngineFailure } from '../engines/failure.js'
import type { LaneOutcomeKind } from '../search/aggregate.js'
import { blockedTargetError, guardTargetAddress, type AddressLookup } from '../support/address-guard.js'
import type { CircuitBreaker } from '../support/breaker.js'
import { resolveRuntimeRequest, runOperation, type OpContext, type RuntimeControls } from '../support/budget.js'
import { runLane, type LaneLogSink, type LaneOutcome } from '../support/lane-runner.js'
import { selectServices } from '../search/preset.js'
import {
  aggregateDynamicFetch,
  DEFAULT_FETCH_ENGINE_TIMEOUT_MS,
  failureFromThrown,
  failureWebError,
  type BuildEngineContext,
  type FetchPipelineLogger,
} from './aggregate.js'
import { DEFAULT_MAX_OUTPUT_CHARS, organizeDocuments } from './document/organize.js'
import { classifyFetchRoute, type FetchRouteOptions } from './route.js'
import { isUsableCandidate } from './select-best.js'
import { probeVerdict } from './two-stage.js'
import type { FetchCandidate } from './types.js'

/** 两个 seam 注册表相互独立；id 与搜索面保持同值，便于宿主与日志辨认。 */
export const AGGREGATED_FETCH_PROVIDER_ID = 'aggregated'

/** 自动预设首路探测的 deadline；默认文档化的 15s。 */
export const DEFAULT_PROBE_TIMEOUT_MS = 15_000

/** 静态路 HTTP 提取器的最小结构面（v0.2 包一层 dsh-web-fetch-http；测试注入替身）。 */
export interface StaticHttpFetcher {
  available(): boolean
  fetch(request: WebFetchRequest, signal?: AbortSignal): Promise<WebFetchResult>
}

/**
 * 专用读取 API（AIHOT 的 /api/v1/*）：结构化报告与同步操作优先于通用提取。
 * 返回 undefined 表示该 URL 不属于此 API 面，继续走通用提取。
 */
export interface DedicatedApiReader {
  readonly engineId: string
  readApi(url: string, ctx: EngineContext): Promise<WebFetchResult | undefined>
}

export interface AggregatedFetchProviderOptions {
  /** 每次操作读取控制快照（设置页 volatile）。 */
  resolveControls(): RuntimeControls
  /** registry 顺序的引擎表（buildEngines 产物）。 */
  engines: readonly Engine[]
  /** 装配层提供的引擎上下文构造器（凭证、端点覆盖）。 */
  buildContext: BuildEngineContext
  /** 静态路的 HTTP 提取器；省略时静态 URL 报 WEB_PROVIDER_ERROR。 */
  httpFetcher?: StaticHttpFetcher
  /** 专用 API 读取器（按 engineId 绑定到 capabilities 含 aihot-api 的引擎）。 */
  apiReaders?: readonly DedicatedApiReader[]
  /** 凭证/可用性探测（可选）。 */
  ready?: (id: string, face: 'search' | 'fetch') => Promise<boolean>
  /** 额度熔断器；broken 引擎在派发前跳过。 */
  breaker?: CircuitBreaker
  /** 管线日志汇。 */
  logger?: FetchPipelineLogger
  /** URL 感知路由参数；默认把静态扩展名交给 HTTP。 */
  route?: FetchRouteOptions
  /** 动态路单路 deadline；默认 45s。 */
  perEngineTimeoutMs?: number
  /**
   * 是否在任一引擎或适配器看到 URL 前拒绝已证实的本机/内网目标。默认 true；
   * fetch.staticDomains 主机豁免（内置 HTTP 提取器有自己的策略）。
   */
  blockPrivateAddresses?: boolean
  /** 地址守卫的 DNS 解析器覆盖；默认系统解析器。 */
  lookup?: AddressLookup
  /** 自动预设首路探测的 deadline；默认 15s。 */
  probeTimeoutMs?: number
  /**
   * `single` 预设是否允许在唯一通道失败或正文过薄时回退到多路整理。默认 false：
   * 显式单通道请求由恰好一个通道回答。
   */
  singleChannelEscalate?: boolean
  /**
   * 单路结局回调（装配层注入本地额度账本；只在 success/rate-limited/quota 时调用）。
   * 探测与单通道路由 provider 上报，多路整理路的引擎结果经包装后上报。
   */
  onLaneOutcome?: (engineId: string, kind: LaneOutcomeKind) => void
  /** 时钟覆盖（测试）。 */
  now?: () => number
}

/**
 * 注册在 ctx.web 上的聚合提取 provider（id `aggregated`）。
 * 一次 fetch()：地址守卫 → 专用 API 面 → 静态/动态分流 → 两段式或单通道 → 多路整理。
 */
export class AggregatedFetchProvider implements WebFetchProvider {
  readonly id = AGGREGATED_FETCH_PROVIDER_ID
  /** 宿主 provider 目录元数据（master HEAD 的 WebProviderInfo 消费；结构兼容 0.2.1-rc.2）。 */
  readonly title = { en: 'Aggregated Web Fetch (5 engines)', zh: '聚合网页提取（五引擎）' } as const
  readonly description = {
    en: 'Two-stage fetch: a cheap probe first, escalating to multi-engine content organization that preserves sources and differences. Static files go through the built-in HTTP fetcher.',
    zh: '两段式提取：先探测一路，正文不足再升级多引擎整理并保留来源与差异；静态文件走内置 HTTP 抓取。',
  } as const
  private readonly options: AggregatedFetchProviderOptions

  constructor(options: AggregatedFetchProviderOptions) {
    this.options = options
  }

  /** 廉价本地可用性检查；没有静态提取器时动态引擎仍可用。 */
  available(): boolean {
    return this.options.httpFetcher?.available() ?? true
  }

  /**
   * 提取一个 URL。静态路直通注入的 HTTP 提取器；动态路扇出到提取引擎。
   * 两条路都把目标站非 2xx 当作结果（seam 契约），不抛错。
   */
  async fetch(request: WebFetchRequest, signal?: AbortSignal): Promise<WebFetchResult> {
    const controls = resolveRuntimeRequest(this.options.resolveControls(), 'fetch', request.url)
    return runOperation(controls, 'fetch', signal, op => this.fetchOperation(request, op))
  }

  private async fetchOperation(request: WebFetchRequest, op: OpContext): Promise<WebFetchResult> {
    // 总限时到期不是调用方取消：runOperation 会在限时后让已完成路径返回（truncated），
    // 直接进入这里时也不能误报 WEB_ABORTED（见 aggregateDynamicFetch 的同名判定）。
    if (op.signal.aborted && !op.deadlineReached) throw abortedError(op.signal)
    await this.guardTarget(request.url, op)

    const apiResult = await this.readDedicatedApi(request.url, op)
    if (apiResult !== undefined) return apiResult

    const route = classifyFetchRoute(request.url, this.options.route)
    if (route === 'static') return await this.fetchStatic(request, op)
    return await this.fetchDynamic(request, op)
  }

  /** 地址守卫先行：私有目标不得抵达专用 API、适配器或任何第三方引擎。 */
  private async guardTarget(url: string, op: OpContext): Promise<void> {
    if (this.options.blockPrivateAddresses === false) return
    const verdict = await guardTargetAddress(url, {
      exemptHosts: this.options.route?.staticDomains ?? [],
      ...(this.options.lookup === undefined ? {} : { lookup: this.options.lookup }),
      signal: op.signal,
    })
    if (verdict.allowed) return
    this.options.logger?.warn(
      `[提取] 拒绝把本机或内网目标外发给提取服务：${url}${verdict.address === undefined ? '' : `（${verdict.address}）`}`,
    )
    throw blockedTargetError(url, verdict.address)
  }

  /**
   * AIHOT 专用 API 面：manifest 声明 aihot-api 的引擎优先处理结构化 URL。
   * 读取器由装配层注入；服务总开关、参与范围、熔断与凭证门控与通用提取一致。
   */
  private async readDedicatedApi(url: string, op: OpContext): Promise<WebFetchResult | undefined> {
    for (const engine of this.options.engines) {
      if (!engine.manifest.capabilities.includes('aihot-api')) continue
      const reader = this.options.apiReaders?.find(candidate => candidate.engineId === engine.manifest.id)
      if (reader === undefined) continue
      if (!this.serviceEnabled(engine.manifest.id, op)) continue
      if (op.controls.fetchServices !== undefined && !op.controls.fetchServices.includes(engine.manifest.id)) continue
      if (this.options.breaker?.isBroken(engine.manifest.id) === true) continue
      if (this.options.ready !== undefined && !await this.options.ready(engine.manifest.id, 'fetch')) continue
      const deadline = this.now() + (this.options.perEngineTimeoutMs ?? DEFAULT_FETCH_ENGINE_TIMEOUT_MS)
      const context = await this.options.buildContext(engine.manifest, op, { signal: op.signal, deadline, face: 'fetch' })
      const result = await reader.readApi(url, context)
      if (result !== undefined) return result
    }
    return undefined
  }

  /** 静态路：单次 HTTP 抓取，零引擎调用。 */
  private async fetchStatic(request: WebFetchRequest, op: OpContext): Promise<WebFetchResult> {
    if (!this.serviceEnabled('http', op)) {
      throw new WebError('直接 HTTP 抓取已关闭，无法提取此静态 URL；请启用该服务后重试。', 'WEB_PROVIDER_ERROR')
    }
    const http = this.options.httpFetcher
    if (http === undefined) {
      throw new WebError('未配置内置 HTTP 提取器，无法提取此静态 URL。', 'WEB_PROVIDER_ERROR')
    }
    const result = await http.fetch(request, op.signal)
    // 有正文的非 2xx 是结果（seam 契约）；无正文的非 2xx 是目标站拒绝，
    // 不能伪装成成功返回空白页（v0.2 P2-2 同义）。
    if ((result.statusCode < 200 || result.statusCode >= 300) && result.body.content.trim().length === 0) {
      throw new WebError(`静态抓取失败：目标站返回 HTTP ${result.statusCode} 且无正文`, 'WEB_BLOCKED_URL')
    }
    return result
  }

  /**
   * 动态路：能力适用性路由 → single / auto / 其余预设的分流（only organize 模式）。
   *
   * 能力适用性路由（v0.4.2 复核裁决 1）：声明了 fetchApplicable 且对本次 URL 命中的引擎是
   * 专属路（如知乎问题回答 API），优先派发并直接返回其正文；谓词不命中的引擎本轮完全不
   * 派发——不发请求，也不产生 invalid 失败污染聚合错误组。未声明谓词的引擎是通用路，顺序与
   * 选择逻辑不变。专属路全败时才降级通用路；single 未开启升级时仍维持「恰好一个通道」语义。
   */
  private async fetchDynamic(request: WebFetchRequest, op: OpContext): Promise<WebFetchResult> {
    const dedicated = await this.selectDedicated(op, request.url)
    if (dedicated.length > 0) {
      const attempt = await this.fetchDedicated(request, op, dedicated)
      if ('result' in attempt) return attempt.result
      this.options.logger?.info(`[提取] 专属路 ${attempt.engineId} 全败，降级通用提取引擎`)
      op.note(`专属路 ${attempt.engineId} 失败（${attempt.failure.kind}），降级通用提取服务。`)
      if (op.controls.preset === 'single' && this.options.singleChannelEscalate !== true) {
        // single 是用户显式选择的宽度：专属路已花掉唯一一次派发，失败就报错，不再派第二路。
        throw failureWebError(attempt.failure, `专属路 ${attempt.engineId} 提取失败`)
      }
    }
    if (op.controls.preset === 'single') return await this.singleChannelFetch(request, op)
    if (op.controls.preset === 'auto') {
      const probe = await this.probeFirst(request, op)
      if (probe === undefined) return await this.escalate(request, op)
      if (probe.result !== undefined) return probe.result
      // 探测已在该通道花掉一次请求：把结果并入整理，而不是再问同一引擎一次。
      return await this.escalate(request, op, probe.seeds, probe.skip)
    }
    return await this.escalate(request, op)
  }

  /**
   * 专属路：按候选顺序尝试声明 fetchApplicable 的引擎，首个可用正文直接返回（不再进入通用路
   * 整理）。全部失败时返回最后一次失败，由调用方决定降级或按预设语义报错。
   */
  private async fetchDedicated(
    request: WebFetchRequest,
    op: OpContext,
    engines: readonly Engine[],
  ): Promise<{ readonly result: WebFetchResult } | { readonly failure: EngineFailure; readonly engineId: string }> {
    let last: { readonly failure: EngineFailure; readonly engineId: string } | undefined
    for (const engine of engines) {
      const engineId = engine.manifest.id
      const outcome = await this.runLane(engine, request.url, op, this.probeTimeoutMs)
      if (outcome.kind === 'aborted') {
        if (!op.deadlineReached) throw abortedError(op.signal)
        last = { failure: engineFailure('timeout', { detail: '专属路提取超时' }), engineId }
        continue
      }
      if (outcome.kind === 'failed') {
        last = { failure: outcome.failure, engineId }
        continue
      }
      if (outcome.kind === 'timeout') {
        last = { failure: engineFailure('timeout', { detail: `专属路 ${engineId} 超时` }), engineId }
        continue
      }
      if (!isUsableCandidate(outcome.result)) {
        last = { failure: engineFailure('provider-error', { detail: '专属路返回空正文' }), engineId }
        continue
      }
      this.options.logger?.info(
        `[提取] 能力适用性路由命中 ${engineId}（状态 ${outcome.result.statusCode}，${outcome.result.body.content.length} 字符），不派发通用提取`,
      )
      op.note(`专属路 ${engineId} 已返回正文，未派发通用提取服务。`)
      return { result: this.serveProbeUnderBudget(request, outcome.result, op) }
    }
    return last ?? { failure: engineFailure('provider-error', { detail: '没有可用的专属提取路' }), engineId: '' }
  }

  /**
   * 首路探测：一次请求，不扇出。探测路走 runLane 的 deadline 竞速——这是 v0.3 对
   * v0.2「只传 signal、忽略信号的引擎拖到总限时」缺陷的修复点（spec §5）。
   * 返回 undefined 表示没有可探测的通道；否则给出可直接提供的原文，
   * 或升级时可复用的种子与不得重复请求的引擎。
   */
  private async probeFirst(
    request: WebFetchRequest,
    op: OpContext,
  ): Promise<{ result?: WebFetchResult; seeds: FetchCandidate[]; skip: string[] } | undefined> {
    const engine = await this.firstEligibleEngine(op, request.url)
    if (engine === undefined) return undefined
    const engineId = engine.manifest.id
    const outcome = await this.runLane(engine, request.url, op, this.probeTimeoutMs)
    if (outcome.kind === 'aborted') {
      if (!op.deadlineReached) throw abortedError(op.signal)
      return { seeds: [], skip: [engineId] }
    }
    if (outcome.kind !== 'ok') {
      this.options.logger?.info(`[提取] 首路探测 ${engineId} 未返回可用于单通道的正文，转入多路整理`)
      op.note(`首路探测 ${engineId} 失败，已转入多路整理。`)
      return { seeds: [], skip: [engineId] }
    }
    if (op.deadlineReached) return { seeds: [], skip: [engineId] }
    const result = outcome.result
    const verdict = probeVerdict(request.url, result)
    if (!verdict.sufficient) {
      this.options.logger?.info(`[提取] 首路探测 ${engineId} 不足（${verdict.reason ?? 'unknown'}），转入多路整理`)
      op.note(`首路探测不足（${verdict.reason ?? 'unknown'}），已转入多路整理。`)
      return { seeds: isUsableCandidate(result) ? [{ engineId, result }] : [], skip: [engineId] }
    }
    this.options.logger?.info(
      `[提取] 首路探测 ${engineId} 已取得完整正文（状态 ${result.statusCode}，${result.body.content.length} 字符），直接返回原文`,
    )
    op.note(`首路 ${engineId} 已取得完整正文，未派发其他提取服务。`)
    return { result: this.serveProbeUnderBudget(request, result, op), seeds: [], skip: [] }
  }

  /**
   * `single` 预设：一个通道，原样提供该通道的正文。
   *
   * 与自动探测不同，这是用户显式选择的宽度：正文再薄或偏离目标也原样返回——
   * 调用方要的正好一个来源，就恰好花一次请求。两个例外：通道失败在
   * `singleChannelEscalate` 打开时转入多路整理，否则抛出；操作取消总是抛出。
   */
  private async singleChannelFetch(request: WebFetchRequest, op: OpContext): Promise<WebFetchResult> {
    const engine = await this.firstEligibleEngine(op, request.url)
    if (engine === undefined) {
      throw new WebError('没有可用的提取通道：单通道预设未派发任何请求', 'WEB_PROVIDER_ERROR')
    }
    const engineId = engine.manifest.id
    const outcome = await this.runLane(engine, request.url, op, this.probeTimeoutMs)
    if (outcome.kind === 'aborted') {
      if (!op.deadlineReached) throw abortedError(op.signal)
      throw new WebError('fetch deadline exceeded', 'WEB_FETCH_TIMEOUT')
    }
    if (outcome.kind !== 'ok') {
      const failure = outcome.kind === 'failed'
        ? outcome.failure
        : engineFailure('timeout', { detail: `单通道 ${engineId} 超时` })
      if (this.options.singleChannelEscalate !== true) {
        throw failureWebError(failure, `单通道 ${engineId} 提取失败`)
      }
      this.options.logger?.info(`[提取] 单通道 ${engineId} 失败，按配置转入多路整理`)
      op.note(`单通道 ${engineId} 失败，已按 singleChannelEscalate 转入多路整理。`)
      return await this.escalate(request, op, [], [engineId])
    }
    const result = outcome.result
    const verdict = probeVerdict(request.url, result)
    if (!verdict.sufficient && this.options.singleChannelEscalate === true) {
      this.options.logger?.info(`[提取] 单通道 ${engineId} 正文不足（${verdict.reason ?? 'unknown'}），按配置转入多路整理`)
      op.note(`单通道正文不足（${verdict.reason ?? 'unknown'}），已按 singleChannelEscalate 转入多路整理。`)
      const seeds = isUsableCandidate(result) ? [{ engineId, result }] : []
      return await this.escalate(request, op, seeds, [engineId])
    }
    this.options.logger?.info(
      `[提取] 单通道 ${engineId} 返回原文（状态 ${result.statusCode}，${result.body.content.length} 字符），未加溯源标记`,
    )
    op.note(`单通道 ${engineId} 直接返回原文，未派发其他提取服务。`)
    return result
  }

  /** 多路整理：所有升级预设共用的出口。 */
  private async escalate(
    request: WebFetchRequest,
    op: OpContext,
    seeds: readonly FetchCandidate[] = [],
    skipEngineIds: readonly string[] = [],
  ): Promise<WebFetchResult> {
    const escalating = seeds.length > 0 || skipEngineIds.length > 0
    return await aggregateDynamicFetch({
      settleEarly: op.controls.preset === 'auto',
      url: request.url,
      engines: this.withLaneReporting(await this.selectGeneric(op, request.url, escalating)),
      op,
      buildContext: this.options.buildContext,
      maxOutputChars: op.controls.maxOutputChars ?? DEFAULT_MAX_OUTPUT_CHARS,
      ...(seeds.length === 0 ? {} : { seeds }),
      ...(skipEngineIds.length === 0 ? {} : { skipEngineIds }),
      ...(this.options.breaker === undefined ? {} : { breaker: this.options.breaker }),
      ...(this.options.logger === undefined ? {} : { logger: this.options.logger }),
      ...(this.options.perEngineTimeoutMs === undefined ? {} : { perEngineTimeoutMs: this.options.perEngineTimeoutMs }),
      ...(this.options.now === undefined ? {} : { now: this.options.now }),
    })
  }

  /** 首个可派发的通用提取引擎：与扇出共用同一套预设、启用位、凭证与熔断选择。 */
  private async firstEligibleEngine(op: OpContext, url: string): Promise<Engine | undefined> {
    return (await this.selectGeneric(op, url))[0]
  }

  /** 专属路候选：声明 fetchApplicable 且对本次 URL 命中的提取引擎。 */
  private async selectDedicated(op: OpContext, url: string): Promise<Engine[]> {
    return await this.selectByApplicability(op, url, 'dedicated')
  }

  /**
   * 通用路候选（预设优先级、启用位、凭证存在性、熔断）：未声明 fetchApplicable 的提取引擎。
   * `escalating` 解除 single 预设的一路上限——升级是明确转向多路整理。
   */
  private async selectGeneric(op: OpContext, url: string, escalating = false): Promise<Engine[]> {
    return await this.selectByApplicability(op, url, 'generic', escalating)
  }

  /**
   * 按能力适用性分流候选：谓词不命中的引擎本轮不进入任何候选池（不发请求、不产生 invalid
   * 失败）。谓词判定只消费引擎暴露的方法，fetch 层不认识具体引擎（R7 架构红线）。
   */
  private async selectByApplicability(
    op: OpContext,
    url: string,
    tier: 'dedicated' | 'generic',
    escalating = false,
  ): Promise<Engine[]> {
    const eligible = this.options.engines.filter(engine => {
      if (!engine.manifest.capabilities.includes('fetch') || engine.fetch === undefined) return false
      if (this.options.breaker?.isBroken(engine.manifest.id) === true) return false
      if (engine.fetchApplicable === undefined) return tier === 'generic'
      return tier === 'dedicated' && engine.fetchApplicable(url)
    })
    const limit = op.controls.maxFetchServices ?? 11
    const cap = escalating && op.controls.preset === 'single' ? limit : undefined
    const rows = await selectServices(
      eligible.map(engine => ({
        engine,
        id: engine.manifest.id,
        free: engine.manifest.free ?? false,
        keyless: engine.manifest.keyless ?? false,
        ...(engine.manifest.keylessCapabilities === undefined
          ? {}
          : { keylessCapabilities: engine.manifest.keylessCapabilities }),
      })),
      op,
      'fetch',
      this.options.ready,
      cap,
      // 专属路不记宽度说明（通用选择会记一次）：避免专属路+通用路各刷一遍「多通道预设…」。
      tier === 'generic',
    )
    return rows.map(row => row.engine)
  }

  /** 跑一路引擎：runLane 的 deadline 竞速提供硬超时（探测与单通道共用）。 */
  private async runLane(
    engine: Engine,
    url: string,
    op: OpContext,
    deadlineMs: number,
  ): Promise<LaneOutcome<EngineFetchOutcome>> {
    const log = this.options.logger === undefined ? undefined : laneLogSink(this.options.logger)
    const outcome = await runLane<EngineFetchOutcome>({
      engineId: engine.manifest.id,
      signal: op.signal,
      deadlineMs,
      ...(this.options.now === undefined ? {} : { now: this.options.now }),
      work: async signal => {
        try {
          return await engine.fetch!(
            url,
            await this.options.buildContext(engine.manifest, op, { signal, deadline: this.now() + deadlineMs, face: 'fetch' }),
          )
        } catch (error) {
          return { ok: false, failure: failureFromThrown(error) }
        }
      },
      ...(log === undefined ? {} : { log }),
    })
    this.reportLaneOutcome(outcome)
    return outcome
  }

  /** 单路结局上报：成功/限流/额度三类入账；超时与取消不入账。 */
  private reportLaneOutcome(outcome: LaneOutcome<EngineFetchOutcome>): void {
    const report = this.options.onLaneOutcome
    if (report === undefined) return
    if (outcome.kind === 'ok') { report(outcome.engineId, 'success'); return }
    if (outcome.kind !== 'failed') return
    if (outcome.failure.kind === 'rate-limited') report(outcome.engineId, 'rate-limited')
    else if (outcome.failure.kind === 'quota') report(outcome.engineId, 'quota')
  }

  /** 多路整理路：包装引擎 fetch，让 aggregateDynamicFetch 内部的 lane 结局同样入账。 */
  private withLaneReporting(engines: readonly Engine[]): readonly Engine[] {
    const report = this.options.onLaneOutcome
    if (report === undefined) return engines
    return engines.map(engine => {
      const fetchFn = engine.fetch
      if (fetchFn === undefined) return engine
      return {
        ...engine,
        fetch: async (url, context) => {
          const outcome = await fetchFn(url, context)
          const kind = reportableLaneOutcome(outcome)
          // lane 超时/取消后引擎迟到返回的结果不属于成功路，不入账。
          if (kind !== undefined && !context.signal.aborted) report(engine.manifest.id, kind)
          return outcome
        },
      }
    })
  }

  /**
   * 首路原文按单页输出预算提供：已放得下则逐字返回（无尾注、无标记）；
   * 超预算走 organizeDocuments，按完整块省略并标记 truncated。
   */
  private serveProbeUnderBudget(request: WebFetchRequest, result: WebFetchResult, op: OpContext): WebFetchResult {
    const budget = op.controls.maxOutputChars ?? DEFAULT_MAX_OUTPUT_CHARS
    if (result.body.content.length <= budget) return result
    const candidate: FetchCandidate = { engineId: 'probe', result }
    return organizeDocuments(request.url, [candidate], budget, [
      `首路原文 ${result.body.content.length} 字符超过单页输出预算 ${budget}，已按预算省略完整内容块。`,
      `本插件 HTTP 请求：${op.requestCount} 次。`,
    ])
  }

  private get probeTimeoutMs(): number {
    return this.options.probeTimeoutMs ?? DEFAULT_PROBE_TIMEOUT_MS
  }

  private serviceEnabled(id: string, op: OpContext): boolean {
    return op.controls.serviceEnabled?.[id] ?? true
  }

  private now(): number {
    return this.options.now?.() ?? Date.now()
  }
}

/** 单路日志汇：带引擎前缀转发到管线 logger。 */
function laneLogSink(logger: FetchPipelineLogger): LaneLogSink {
  return {
    laneInfo: (engineId, message) => logger.info(`[提取] ${engineId} ${message}`),
    laneWarn: (engineId, message) => logger.warn(`[提取] ${engineId} ${message}`),
  }
}

/** 引擎结果 → 额度账本口径；其他失败返回 undefined（不入账）。 */
function reportableLaneOutcome(result: EngineResult<EngineFetchOutcome>): LaneOutcomeKind | undefined {
  if (result.ok) return 'success'
  if (result.failure.kind === 'rate-limited') return 'rate-limited'
  if (result.failure.kind === 'quota') return 'quota'
  return undefined
}

/** 操作自身取消 → seam 的取消码。 */
function abortedError(signal: AbortSignal): WebError {
  return new WebError('Aggregated web fetch aborted', 'WEB_ABORTED', { cause: signal.reason })
}
