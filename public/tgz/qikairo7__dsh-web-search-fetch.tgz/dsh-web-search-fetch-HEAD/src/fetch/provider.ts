// 聚合提取 provider。
// 入口 = runOperation + 地址守卫 → classifyFetchRoute 分流：
// - 静态路：交给构造注入的 HTTP fetcher，不 new 具体实现；
// - 动态路：两段式（先探测一路，正文够直接返回原文；不足则升级多路整理）；
//   超预算走整理路径 + truncated；
// - AIHOT 专用 API 面：按 manifest capabilities 'aihot-api' 判定，读取器由装配层注入
//   （provider 不 import 具体引擎模块）。
// 探测硬超时：探测路由 runExtractionAttempt 的 deadline 竞速执行，忽略 signal 的引擎
// 也会在 probeTimeoutMs 到期时被丢弃，不会拖到操作总限时。

import { WebError } from '@deepseek-ai/dsh-web'
import type { WebFetchProvider, WebFetchRequest, WebFetchResult } from '@deepseek-ai/dsh-web'

import type { Engine, EngineContext, EngineManifest } from '../engines/contract.js'
import { engineFailure, type EngineFailure } from '../engines/failure.js'
import type { AddressLookup } from '../support/address-guard.js'
import type { CircuitBreaker } from '../support/breaker.js'
import { resolveRuntimeRequest, runOperation, type OpContext, type RuntimeControls } from '../support/budget.js'
import { LaneSettlement, type LaneOutcomeKind } from '../support/lane-settlement.js'
import { selectServices } from '../search/preset.js'
import {
  aggregateDynamicFetch,
  DEFAULT_FETCH_ENGINE_TIMEOUT_MS,
  type BuildEngineContext,
  type FetchPipelineLogger,
} from './aggregate.js'
import { runExtractionAttempt, type ExtractionAttempt } from './attempt.js'
import { DEFAULT_MAX_OUTPUT_CHARS, organizeDocuments } from './document/organize.js'
import { classifyFetchRoute, type FetchRouteOptions } from './route.js'
import { probeVerdict } from './two-stage.js'
import type { FetchCandidate } from './types.js'
import { serveProbeUnderBudget as serveProbe } from './probe-output.js'
import { abortedError, fetchStatic, guardFetchTarget } from './guards.js'

/** 两个 seam 注册表相互独立；id 与搜索面保持同值，便于宿主与日志辨认。 */
export const AGGREGATED_FETCH_PROVIDER_ID = 'aggregated'

/** 首路探测的 deadline；默认文档化的 15s。 */
export const DEFAULT_PROBE_TIMEOUT_MS = 15_000

/** 静态路 HTTP 提取器的最小结构面；测试注入替身。 */
export interface StaticHttpFetcher {
  available(): boolean
  fetch(request: WebFetchRequest, signal?: AbortSignal): Promise<WebFetchResult>
}

/**
 * 专用读取 API（AIHOT 的 /api/v1/*）：结构化报告与同步操作优先于通用提取。
 * 返回 undefined 表示该 URL 不属于此 API 面，继续走通用提取。
 */
export interface DedicatedApiReader {
  readonly engineId: string
  readApi(url: string, ctx: EngineContext): Promise<WebFetchResult | undefined>
  /** 结果是否来自读取器缓存；缓存结果不重复计入额度或被熔断观察。 */
  isCached?(result: WebFetchResult): boolean
}

export interface AggregatedFetchProviderOptions {
  /** 每次操作读取控制快照。 */
  resolveControls(): RuntimeControls
  /** registry 顺序的引擎表（buildEngines 产物）。 */
  engines: readonly Engine[]
  /** 装配层提供的引擎上下文构造器（凭证、端点覆盖）。 */
  buildContext: BuildEngineContext
  /** 静态路的 HTTP 提取器；省略时静态 URL 报 WEB_PROVIDER_ERROR。 */
  httpFetcher?: StaticHttpFetcher
  /** 专用 API 读取器（按 engineId 绑定到 capabilities 含 aihot-api 的引擎）。 */
  apiReaders?: readonly DedicatedApiReader[]
  /** 凭证/可用性探测（可选）。 */
  ready?: (id: string, face: 'search' | 'fetch') => Promise<boolean>
  /** 额度熔断器；broken 引擎在派发前跳过。 */
  breaker?: CircuitBreaker
  /** 管线日志汇。 */
  logger?: FetchPipelineLogger
  /** URL 感知路由参数；默认把静态扩展名交给 HTTP。 */
  route?: FetchRouteOptions
  /** 动态路单路 deadline；默认 45s。 */
  perEngineTimeoutMs?: number
  /**
   * 是否在任一引擎或适配器看到 URL 前拒绝已证实的本机/内网目标。默认 true；
   * fetch.staticDomains 主机豁免（内置 HTTP 提取器有自己的策略）。
   */
  blockPrivateAddresses?: boolean
  /** 地址守卫的 DNS 解析器覆盖；默认系统解析器。 */
  lookup?: AddressLookup
  /** 首路探测的 deadline；默认 15s。 */
  probeTimeoutMs?: number
  /**
   * 单路结局回调（装配层注入本地额度账本；只在 success/rate-limited/quota 时调用）。
   * 探测路由 provider 上报，多路整理路由 ExtractionAttempt 上报。
   */
  onLaneOutcome?: (engineId: string, kind: LaneOutcomeKind) => void
  /** 时钟覆盖（测试）。 */
  now?: () => number
}

/**
 * 注册在 ctx.web 上的聚合提取 provider（id `aggregated`）。
 * 一次 fetch()：地址守卫 → 专用 API 面 → 静态/动态分流 → 两段式或单通道 → 多路整理。
 */
export class AggregatedFetchProvider implements WebFetchProvider {
  readonly id = AGGREGATED_FETCH_PROVIDER_ID
  /** 宿主 provider 目录元数据；title 是字符串，description 支持多语言。 */
  readonly title = 'Aggregated Web Fetch (5 engines)'
  readonly description = {
    en: 'Two-stage fetch: a cheap probe first, escalating to multi-engine content organization that preserves sources and differences. Static files go through the built-in HTTP fetcher.',
    zh: '两段式提取：先探测一路，正文不足再升级多引擎整理并保留来源与差异；静态文件走内置 HTTP 抓取。',
  } as const
  private readonly options: AggregatedFetchProviderOptions
  private readonly settlement: LaneSettlement

  constructor(options: AggregatedFetchProviderOptions) {
    this.options = options
    this.settlement = new LaneSettlement(options.onLaneOutcome, options.breaker)
  }

  /** 廉价本地可用性检查；没有静态提取器时动态引擎仍可用。 */
  available(): boolean {
    return this.options.httpFetcher?.available() ?? true
  }

  /**
   * 提取一个 URL。静态路直通注入的 HTTP 提取器；动态路扇出到提取引擎。
   * 两条路都把目标站非 2xx 当作结果（seam 契约），不抛错。
   */
  async fetch(request: WebFetchRequest, signal?: AbortSignal): Promise<WebFetchResult> {
    const controls = resolveRuntimeRequest(this.options.resolveControls(), 'fetch', request.url)
    return runOperation(controls, 'fetch', signal, op => this.fetchOperation(request, op))
  }

  private async fetchOperation(request: WebFetchRequest, op: OpContext): Promise<WebFetchResult> {
    // 总限时到期不是调用方取消：runOperation 会在限时后让已完成路径返回（truncated），
    // 直接进入这里时也不能误报 WEB_ABORTED（见 aggregateDynamicFetch 的同名判定）。
    if (op.signal.aborted && !op.deadlineReached) throw abortedError(op.signal)
    await this.guardTarget(request.url, op)

    const apiResult = await this.readDedicatedApi(request.url, op)
    if (apiResult !== undefined) return apiResult

    const route = classifyFetchRoute(request.url, this.options.route)
    if (route === 'static') return await this.fetchStatic(request, op)
    return await this.fetchDynamic(request, op)
  }

  private async guardTarget(url: string, op: OpContext): Promise<void> {
    await guardFetchTarget(url, op, this.options)
  }

  /**
   * AIHOT 专用 API 面：manifest 声明 aihot-api 的引擎优先处理结构化 URL。
   * 读取器由装配层注入；服务总开关、参与范围、熔断与凭证门控与通用提取一致。
   */
  private async readDedicatedApi(url: string, op: OpContext): Promise<WebFetchResult | undefined> {
    for (const engine of this.options.engines) {
      if (!engine.manifest.capabilities.includes('aihot-api')) continue
      const reader = this.options.apiReaders?.find(candidate => candidate.engineId === engine.manifest.id)
      if (reader === undefined) continue
      if (!this.serviceEnabled(engine.manifest.id, op)) continue
      if (
        op.controls.fetchServices !== undefined
        && engine.manifest.capabilities.includes('fetch')
        && !op.controls.fetchServices.includes(engine.manifest.id)
      ) continue
      if (this.options.breaker?.isBroken(engine.manifest.id) === true) continue
      if (this.options.ready !== undefined && !await this.options.ready(engine.manifest.id, 'fetch')) continue
      const deadline = this.now() + (this.options.perEngineTimeoutMs ?? DEFAULT_FETCH_ENGINE_TIMEOUT_MS)
      const context = await this.options.buildContext(engine.manifest, op, { signal: op.signal, deadline, face: 'fetch' })
      const result = await reader.readApi(url, context)
      if (result !== undefined) {
        if (reader.isCached?.(result) !== true) this.settleDedicatedApi(engine.manifest.id, result)
        return result
      }
    }
    return undefined
  }

  private settleDedicatedApi(engineId: string, result: WebFetchResult): void {
    const failure = result.statusCode === 429 || result.statusCode === 503
      ? engineFailure('rate-limited', { statusCode: result.statusCode })
      : result.statusCode === 402
        ? engineFailure('quota', { statusCode: 402 })
        : undefined
    if (failure !== undefined) {
      this.settlement.settle({
        kind: 'failed',
        engineId,
        failure,
        elapsedMs: 0,
      })
      return
    }
    if (result.statusCode >= 200 && result.statusCode < 300 && result.body.content.trim().length > 0) {
      this.settlement.settle({ kind: 'ok', engineId, result, elapsedMs: 0 })
    }
  }

  private async fetchStatic(request: WebFetchRequest, op: OpContext): Promise<WebFetchResult> {
    return await fetchStatic(request, op, this.options.httpFetcher)
  }

  /**
   * 动态路：能力适用性路由 → 两段式提取。
   *
   * 能力适用性路由：声明了 fetchApplicable 且对本次 URL 命中的引擎是
   * 专属路（如知乎问题回答 API），优先派发并直接返回其正文；谓词不命中的引擎本轮完全不
   * 派发——不发请求，也不产生 invalid 失败污染聚合错误组。未声明谓词的引擎是通用路，顺序与
   * 选择逻辑不变。专属路全败时才降级通用路。
   */
  private async fetchDynamic(request: WebFetchRequest, op: OpContext): Promise<WebFetchResult> {
    const dedicated = await this.selectDedicated(op, request.url)
    if (dedicated.length > 0) {
      const attempt = await this.fetchDedicated(request, op, dedicated)
      if ('result' in attempt) return attempt.result
      this.options.logger?.info(`[提取] 专属路 ${attempt.engineId} 全败，降级通用提取引擎`)
      op.note(`专属路 ${attempt.engineId} 失败（${attempt.failure.kind}），降级通用提取服务。`)
    }
    const probe = await this.probeFirst(request, op)
    if (probe === undefined) return await this.escalate(request, op)
    if (probe.result !== undefined) return probe.result
    // 探测已在该通道花掉一次请求：把结果并入整理，而不是再问同一引擎一次。
    return await this.escalate(request, op, probe.seeds, probe.skip)
  }

  /**
   * 专属路：按候选顺序尝试声明 fetchApplicable 的引擎，首个可用正文直接返回（不再进入通用路
   * 整理）。全部失败时返回最后一次失败，由调用方决定是否降级。
   */
  private async fetchDedicated(
    request: WebFetchRequest,
    op: OpContext,
    engines: readonly Engine[],
  ): Promise<{ readonly result: WebFetchResult } | { readonly failure: EngineFailure; readonly engineId: string }> {
    let last: { readonly failure: EngineFailure; readonly engineId: string } | undefined
    for (const engine of engines) {
      const engineId = engine.manifest.id
      const attempt = await this.runAttempt(engine, request.url, op, this.probeTimeoutMs)
      if (attempt.kind === 'aborted') {
        if (!op.deadlineReached) throw abortedError(op.signal)
        last = { failure: engineFailure('timeout', { detail: '专属路提取超时' }), engineId }
        continue
      }
      if (attempt.kind !== 'ok') {
        last = { failure: attempt.failure, engineId }
        continue
      }
      const result = attempt.candidate.result
      this.options.logger?.info(
        `[提取] 能力适用性路由命中 ${engineId}（状态 ${result.statusCode}，${result.body.content.length} 字符），不派发通用提取`,
      )
      op.note(`专属路 ${engineId} 已返回正文，未派发通用提取服务。`)
      return {
        result: serveProbe(
          request,
          result,
          op.controls.maxOutputChars ?? DEFAULT_MAX_OUTPUT_CHARS,
          op.requestCount,
        ),
      }
    }
    return last ?? { failure: engineFailure('provider-error', { detail: '没有可用的专属提取路' }), engineId: '' }
  }

  /**
   * 首路探测：一次请求，不扇出。探测路走 ExtractionAttempt 的 deadline 竞速，这是
   * 忽略 signal 的引擎由调用方 deadline 竞速兜底的修复点。
   * 返回 undefined 表示没有可探测的通道；否则给出可直接提供的原文，
   * 或升级时可复用的种子与不得重复请求的引擎。
   */
  private async probeFirst(
    request: WebFetchRequest,
    op: OpContext,
  ): Promise<{ result?: WebFetchResult; seeds: FetchCandidate[]; skip: string[] } | undefined> {
    const engine = await this.firstEligibleEngine(op, request.url)
    if (engine === undefined) return undefined
    const engineId = engine.manifest.id
    const attempt = await this.runAttempt(engine, request.url, op, this.probeTimeoutMs)
    if (attempt.kind === 'aborted') {
      if (!op.deadlineReached) throw abortedError(op.signal)
      return { seeds: [], skip: [engineId] }
    }
    if (attempt.kind !== 'ok') {
      this.options.logger?.info(`[提取] 首路探测 ${engineId} 未返回可用正文，转入多路整理`)
      op.note(`首路探测 ${engineId} 失败，已转入多路整理。`)
      return { seeds: [], skip: [engineId] }
    }
    if (op.deadlineReached) return { seeds: [], skip: [engineId] }
    const result = attempt.candidate.result
    const verdict = probeVerdict(request.url, result)
    if (!verdict.sufficient) {
      this.options.logger?.info(`[提取] 首路探测 ${engineId} 不足（${verdict.reason ?? 'unknown'}），转入多路整理`)
      op.note(`首路探测不足（${verdict.reason ?? 'unknown'}），已转入多路整理。`)
      return { seeds: [attempt.candidate], skip: [engineId] }
    }
    this.options.logger?.info(
      `[提取] 首路探测 ${engineId} 已取得完整正文（状态 ${result.statusCode}，${result.body.content.length} 字符），直接返回原文`,
    )
    op.note(`首路 ${engineId} 已取得完整正文，未派发其他提取服务。`)
    return {
      result: serveProbe(
        request,
        result,
        op.controls.maxOutputChars ?? DEFAULT_MAX_OUTPUT_CHARS,
        op.requestCount,
      ),
      seeds: [],
      skip: [],
    }
  }

  /** 多路整理：探测不足或无可探测通道时的出口。 */
  private async escalate(
    request: WebFetchRequest,
    op: OpContext,
    seeds: readonly FetchCandidate[] = [],
    skipEngineIds: readonly string[] = [],
  ): Promise<WebFetchResult> {
    return await aggregateDynamicFetch({
      settleEarly: true,
      url: request.url,
      engines: await this.selectGeneric(op, request.url),
      op,
      buildContext: this.options.buildContext,
      maxOutputChars: op.controls.maxOutputChars ?? DEFAULT_MAX_OUTPUT_CHARS,
      ...(seeds.length === 0 ? {} : { seeds }),
      ...(skipEngineIds.length === 0 ? {} : { skipEngineIds }),
      ...(this.options.breaker === undefined ? {} : { breaker: this.options.breaker }),
      ...(this.options.logger === undefined ? {} : { logger: this.options.logger }),
      ...(this.options.perEngineTimeoutMs === undefined ? {} : { perEngineTimeoutMs: this.options.perEngineTimeoutMs }),
      ...(this.options.now === undefined ? {} : { now: this.options.now }),
      settlement: this.settlement,
    })
  }

  /** 首个可派发的通用提取引擎：与升级整理共用启用位、凭证与熔断选择。 */
  private async firstEligibleEngine(op: OpContext, url: string): Promise<Engine | undefined> {
    return (await this.selectGeneric(op, url))[0]
  }

  /** 专属路候选：声明 fetchApplicable 且对本次 URL 命中的提取引擎。 */
  private async selectDedicated(op: OpContext, url: string): Promise<Engine[]> {
    return await this.selectByApplicability(op, url, 'dedicated')
  }

  /**
   * 通用路候选（启用位、凭证存在性、熔断）：未声明 fetchApplicable 的提取引擎。
   */
  private async selectGeneric(op: OpContext, url: string): Promise<Engine[]> {
    return await this.selectByApplicability(op, url, 'generic')
  }

  /**
   * 按能力适用性分流候选：谓词不命中的引擎本轮不进入任何候选池（不发请求、不产生 invalid
   * 失败）。谓词判定只消费引擎暴露的方法，fetch 层不认识具体引擎（R7 架构红线）。
   */
  private async selectByApplicability(
    op: OpContext,
    url: string,
    tier: 'dedicated' | 'generic',
  ): Promise<Engine[]> {
    const eligible = this.options.engines.filter(engine => {
      if (!engine.manifest.capabilities.includes('fetch') || engine.fetch === undefined) return false
      if (this.options.breaker?.isBroken(engine.manifest.id) === true) return false
      if (engine.fetchApplicable === undefined) return tier === 'generic'
      return tier === 'dedicated' && engine.fetchApplicable(url)
    })
    const rows = await selectServices(
      eligible.map(engine => ({
        engine,
        id: engine.manifest.id,
      })),
      op,
      'fetch',
      this.options.ready,
      undefined,
      // 专属路不记宽度说明（通用选择会记一次）：避免专属路和通用路重复记录。
      tier === 'generic',
    )
    return rows.map(row => row.engine)
  }

  /** 跑一次提取：共享 deadline、失败投影与额度结算。 */
  private async runAttempt(
    engine: Engine,
    url: string,
    op: OpContext,
    deadlineMs: number,
  ): Promise<ExtractionAttempt> {
    return await runExtractionAttempt({
      engine,
      url,
      op,
      buildContext: this.options.buildContext,
      deadlineMs,
      settlement: this.settlement,
      ...(this.options.now === undefined ? {} : { now: this.options.now }),
      ...(this.options.logger === undefined ? {} : { logger: this.options.logger }),
    })
  }

  private get probeTimeoutMs(): number {
    return this.options.probeTimeoutMs ?? DEFAULT_PROBE_TIMEOUT_MS
  }

  private serviceEnabled(id: string, op: OpContext): boolean {
    return op.controls.serviceEnabled?.[id] ?? true
  }

  private now(): number {
    return this.options.now?.() ?? Date.now()
  }
}
