import type { EngineFetchOutcome, EngineResult } from '../engines/contract.js'
import type { LaneOutcomeKind } from '../search/aggregate.js'
import type { LaneLogSink } from '../support/lane-runner.js'
import type { FetchPipelineLogger } from './aggregate.js'

/** 单路日志汇：带引擎前缀转发到管线 logger。 */
export function laneLogSink(logger: FetchPipelineLogger): LaneLogSink {
  return {
    laneInfo: (engineId, message) => logger.info(`[提取] ${engineId} ${message}`),
    laneWarn: (engineId, message) => logger.warn(`[提取] ${engineId} ${message}`),
  }
}

/** 引擎结果 → 额度账本口径；其他失败返回 undefined（不入账）。 */
export function reportableLaneOutcome(
  result: EngineResult<EngineFetchOutcome>,
): LaneOutcomeKind | undefined {
  if (result.ok) return 'success'
  if (result.failure.kind === 'rate-limited') return 'rate-limited'
  if (result.failure.kind === 'quota') return 'quota'
  return undefined
}
