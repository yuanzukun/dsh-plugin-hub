// 动态提取编排。关键规则：
// - 单路执行走 support/lane-runner；每路 deadline 由 runLane
//   竞速，忽略 signal 的引擎也会在到期时被丢弃（探测硬超时的同一机制，provider 复用）。
// - 显式 OpContext 替代 AsyncLocalStorage；说明经 op.note 收集。
// - 熔断喂入统一走 LaneSettlement，删除 FirecrawlError/failureSignalOf 依赖——
//   编排层不 import 任何具体引擎错误。
// - 入参是 registry 顺序的 Engine[]，失败只读统一失败模型。
// - mode 只保留 organize：select 模式与 engineWeights 已删。
// 语义保真：空正文无效、SettlementWindow 提前结算、全败取最特异 WEB_* 码、中文说明行、
// truncated 逐层传播。

import { WebError } from '@deepseek-ai/dsh-web'
import type { WebFetchResult } from '@deepseek-ai/dsh-web'

import type { Engine, EngineFetchOutcome } from '../engines/contract.js'
import type { CircuitBreaker } from '../support/breaker.js'
import type { OpContext } from '../support/budget.js'
import { LaneSettlement } from '../support/lane-settlement.js'
import { SettlementWindow } from '../support/settle.js'
import {
  runExtractionAttempt,
  type BuildEngineContext,
  type FetchPipelineLogger,
} from './attempt.js'
import { challengeBlocks, cleanBlocks, markdown, splitBlocks } from './document/blocks.js'
import { DEFAULT_MAX_OUTPUT_CHARS, organizeDocuments } from './document/organize.js'
import type { FetchCandidate } from './types.js'

export { failureFromThrown, failureWebCode } from './attempt.js'
export type { BuildEngineContext, FetchLaneFailure, FetchPipelineLogger } from './attempt.js'

/** 单路提取默认 deadline（45 秒）。 */
export const DEFAULT_FETCH_ENGINE_TIMEOUT_MS = 45_000

/** {@link aggregateDynamicFetch} 的入参。 */
export interface AggregateDynamicFetchOptions {
  /** 是否在「至少三路互补且有共同正文」后提前收掉慢渠道；provider 默认打开。 */
  readonly settleEarly?: boolean
  /** 单页输出预算；缺省 {@link DEFAULT_MAX_OUTPUT_CHARS}。 */
  readonly maxOutputChars?: number
  readonly url: string
  /** registry 顺序的提取引擎表（只认 capabilities 含 fetch 且函数存在者由调用方过滤）。 */
  readonly engines: readonly Engine[]
  /** 显式操作上下文（预算、说明、deadline 判定）。 */
  readonly op: OpContext
  readonly breaker?: CircuitBreaker
  readonly buildContext: BuildEngineContext
  readonly logger?: FetchPipelineLogger
  /** 单路 deadline；缺省 {@link DEFAULT_FETCH_ENGINE_TIMEOUT_MS}。 */
  readonly perEngineTimeoutMs?: number
  /**
   * 首路探测已取得的提取结果：作为普通候选并入整理，不再重复请求同一通道。
   */
  readonly seeds?: readonly FetchCandidate[]
  /** 结果已在 {@link seeds} 中的引擎；绝不重复派发。 */
  readonly skipEngineIds?: readonly string[]
  /** 时钟覆盖（测试）。 */
  readonly now?: () => number
  /** 单路额度结算；缺省只喂熔断。 */
  readonly settlement?: LaneSettlement
}

interface LegFailureNote {
  readonly engineId: string
  readonly code: string
  readonly description: string
}

/** 失败码特异度排序（数字越大越特异，全败时优先返回）。 */
const SPECIFIC_CODE_RANK: Readonly<Record<string, number>> = {
  WEB_BLOCKED_URL: 6,
  WEB_INVALID_URL: 5,
  WEB_FETCH_TOO_LARGE: 4,
  WEB_UNSUPPORTED_CONTENT_TYPE: 3,
  WEB_FETCH_TIMEOUT: 2,
}

/**
 * 描述「目标」而不是「引擎」的码：页面被拦截、URL 非法、过大或类型不支持。
 * 其余都算引擎自身故障。这个分组让全败消息可行动——目标被拒会在每个引擎上失败，
 * 引擎不可用则不会。
 */
const TARGET_REJECTED_CODES: ReadonlySet<string> = new Set([
  'WEB_BLOCKED_URL',
  'WEB_INVALID_URL',
  'WEB_UNSUPPORTED_CONTENT_TYPE',
  'WEB_FETCH_TOO_LARGE',
])

/** 失败码排序：已知特异码 > 未知码 > WEB_PROVIDER_ERROR。 */
function failureRank(code: string): number {
  return SPECIFIC_CODE_RANK[code] ?? (code === 'WEB_PROVIDER_ERROR' ? 0 : 1)
}

/**
 * 跑一个 URL 的动态路：并发派发每个未熔断引擎（每路独立 deadline）、转发熔断信号、
 * 只整理可用正文，且仅在全部引擎都失败后才抛错——错误码取观察到的最特异一个。
 */
export async function aggregateDynamicFetch(options: AggregateDynamicFetchOptions): Promise<WebFetchResult> {
  const { url, engines, op, breaker, logger, buildContext } = options
  const now = options.now ?? Date.now
  const timeoutMs = options.perEngineTimeoutMs ?? DEFAULT_FETCH_ENGINE_TIMEOUT_MS
  const seeds = options.seeds ?? []
  const skipEngineIds = new Set(options.skipEngineIds ?? [])
  const settlement = options.settlement ?? new LaneSettlement(undefined, breaker)

  if (engines.length === 0 && seeds.length === 0) {
    throw new WebError('no extraction engines are configured', 'WEB_PROVIDER_ERROR')
  }
  // 总限时到期（deadlineReached）不是「取消」：
  // 已完成结果并标 truncated，未完成渠道被取消；直接调用聚合器时同样保留这条语义，
  // 因此这里只对调用方主动取消抛 WEB_ABORTED，预到期的 deadline 交给下面的
  // 「幸存者 + truncated」或「无候选 → WEB_FETCH_TIMEOUT」路径。
  if (op.signal.aborted && !op.deadlineReached) throw abortedError(op.signal)

  const active: Engine[] = []
  for (const engine of engines) {
    const engineId = engine.manifest.id
    if (breaker?.isBroken(engineId) === true) {
      logger?.warn(`[提取] 引擎 ${engineId} 处于熔断，已跳过`)
      continue
    }
    if (skipEngineIds.has(engineId)) {
      logger?.info(`[提取] 服务 ${engineId} 的首路结果已在候选集中，不重复派发`)
      continue
    }
    active.push(engine)
  }
  if (active.length === 0 && seeds.length === 0) {
    throw new WebError('all extraction engines are broken', 'WEB_PROVIDER_ERROR')
  }

  const candidatesByLane: (FetchCandidate | undefined)[] = new Array(active.length)
  const notes: LegFailureNote[] = []
  const window = new SettlementWindow(op.signal)
  const substantial = new Map<string, { title: string; anchors: Set<string> }>()

  const runLaneForEngine = async (engine: Engine, index: number): Promise<void> => {
    const engineId = engine.manifest.id
    const attempt = await runExtractionAttempt({
      engine,
      url,
      op,
      buildContext,
      deadlineMs: timeoutMs,
      signal: window.signal,
      now,
      settlement,
      ...(logger === undefined ? {} : { logger }),
    })

    switch (attempt.kind) {
      case 'ok': {
        const result = attempt.candidate.result
        candidatesByLane[index] = attempt.candidate
        observeSubstantialBody(result, engineId, options.settleEarly, url, substantial, window)
        logger?.info(`[提取] 服务 ${engineId} 成功：状态 ${result.statusCode}，正文 ${result.body.content.length} 字符`)
        return
      }
      case 'timeout':
        notes.push({ engineId, code: attempt.code, description: attempt.description })
        return
      case 'aborted':
        // 操作取消在全部路结算后统一判定；这里不参与者级失败归因。
        return
      case 'failed': {
        logger?.warn(`[提取] 引擎 ${engineId} 失败：${attempt.failure.kind}${attempt.failure.statusCode ?? ''}`)
        notes.push({
          engineId,
          code: attempt.code,
          description: attempt.description,
        })
        return
      }
    }
  }

  try {
    await Promise.allSettled(active.map(runLaneForEngine))
  } finally {
    window.finish()
  }
  if (window.endedEarly) {
    op.note('已有至少三路可互补且有共同正文的提取，宽限等待结束后提前取消慢渠道；未完成内容未纳入整理。')
  }

  // 同上：总限时到期时允许已完成候选继续整理（truncated=true），只有调用方取消才抛。
  if (op.signal.aborted && !op.deadlineReached) throw abortedError(op.signal)
  const candidates = [
    ...seeds,
    ...candidatesByLane.filter((candidate): candidate is FetchCandidate => candidate !== undefined),
  ]
  if (candidates.length === 0) {
    if (op.deadlineReached) throw new WebError('fetch deadline exceeded', 'WEB_FETCH_TIMEOUT')
    throw allFailedError(notes)
  }

  const output = organizeDocuments(url, candidates, options.maxOutputChars ?? DEFAULT_MAX_OUTPUT_CHARS, [
    ...notes.map(note => `${note.engineId}: ${note.code}`),
    ...op.notes,
    ...(window.endedEarly ? ['多路正文充分后提前结束等待，保留已完成结果。'] : []),
    `本插件 HTTP 请求：${op.requestCount} 次。`,
  ])
  logger?.info(
    `[提取] 已整理 ${candidates.length} 路结果，输出 ${output.body.content.length} 字符；请求 ${op.requestCount} 次。`,
  )
  return {
    ...output,
    truncated: window.endedEarly
      || output.truncated
      || op.deadlineReached
      || notes.some(note => note.code === 'WEB_FETCH_TIMEOUT'),
  }
}

/**
 * 提前结算信号：同一目标、2xx、无挑战、正文 ≥1200 段落字符的提取，
 * 以「标题 + 长段落 key」为锚点；三路出现相同锚点时打开宽限窗口。
 */
function observeSubstantialBody(
  result: EngineFetchOutcome,
  engineId: string,
  settleEarly: boolean | undefined,
  url: string,
  substantial: Map<string, { title: string; anchors: Set<string> }>,
  window: SettlementWindow,
): void {
  if (settleEarly === false) return
  if (result.statusCode < 200 || result.statusCode >= 300 || result.url !== url) return
  const blocks = cleanBlocks(splitBlocks(markdown(result.body.content, result.body.kind)))
  const paragraphs = blocks
    .filter(block => block.kind === 'paragraph')
    .map(block => block.text.replace(/\s+/g, ' ').trim())
  if (!challengeBlocks(blocks) && paragraphs.join(' ').length >= 1200) {
    substantial.set(engineId, {
      title: (blocks.find(block => block.kind === 'heading')?.key ?? '').split(/\s+(?:—|\||-)\s+/)[0]!.toLowerCase(),
      anchors: new Set(
        blocks
          .filter(block => block.kind === 'paragraph' && block.text.length >= 100)
          .map(block => block.key),
      ),
    })
  }
  const agreement = new Map<string, number>()
  for (const body of substantial.values()) {
    for (const anchor of body.anchors) {
      const key = `${body.title}\n${anchor}`
      agreement.set(key, (agreement.get(key) ?? 0) + 1)
    }
  }
  window.observe([...agreement.values()].some(count => count >= 3))
}

/**
 * 组装全败错误：逐路原因按「目标拒绝了我们」与「引擎不可用」分组，取最特异的码。
 * 分组比码更重要：所有引擎都报同一目标级拒绝时重试无益，消息直说；
 * 引擎自身故障时消息点名它们。
 */
function allFailedError(notes: readonly LegFailureNote[]): WebError {
  let best = notes[0]
  for (const note of notes) {
    if (best === undefined || failureRank(note.code) > failureRank(best.code)) best = note
  }
  const rejected = notes.filter(note => TARGET_REJECTED_CODES.has(note.code))
  const unavailable = notes.filter(note => !TARGET_REJECTED_CODES.has(note.code))
  const describe = (group: readonly LegFailureNote[]): string =>
    group.map(note => `${note.engineId} (${note.code}: ${note.description})`).join('; ')
  const parts: string[] = []
  if (rejected.length > 0) parts.push(`目标被拒绝 target-rejected：${describe(rejected)}`)
  if (unavailable.length > 0) parts.push(`引擎不可用 engine-unavailable：${describe(unavailable)}`)
  return new WebError(`all extraction engines failed. ${parts.join(' | ')}`, best?.code ?? 'WEB_PROVIDER_ERROR')
}

/** 操作自身取消 → seam 的取消码。 */
function abortedError(signal: AbortSignal): WebError {
  return new WebError('Aggregated web fetch aborted', 'WEB_ABORTED', { cause: signal.reason })
}
