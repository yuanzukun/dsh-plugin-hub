// v0.3 动态提取编排——v0.2 src/fetch-aggregate.ts:396-614（aggregateDynamicFetch/runLeg）重设计。
// 关键改动（对 v0.2）：
// - AD3：单路执行走 support/lane-runner（v0.2 内联 runLeg 骨架删除）；每路 deadline 由 runLane
//   竞速，忽略 signal 的引擎也会在到期时被丢弃（探测硬超时的同一机制，provider 复用）。
// - AD5：显式 OpContext 替代 AsyncLocalStorage；说明经 op.note 收集。
// - AD6：熔断喂入 = breakerSignalOf(outcome.failure)，删除 FirecrawlError/failureSignalOf 依赖——
//   编排层不再 import 任何具体引擎错误（v0.2 被批判者点名的穿透）。
// - AD2：入参是 registry 顺序的 Engine[]，失败只读统一失败模型。
// - mode 只保留 organize：v0.2 的 select 模式与 engineWeights 已删（spec §3.4）。
// 语义保真：空正文无效、SettlementWindow 提前结算、全败取最特异 WEB_* 码、中文说明行、
// truncated 逐层传播，均按 v0.2 原行为保留。

import { WebError } from '@deepseek-ai/dsh-web'
import type { WebFetchResult } from '@deepseek-ai/dsh-web'

import type { Engine, EngineContext, EngineFetchOutcome, EngineManifest, EngineResult } from '../engines/contract.js'
import { engineFailure, type EngineFailure, type EngineFailureKind } from '../engines/failure.js'
import { breakerSignalOf, type CircuitBreaker } from '../support/breaker.js'
import type { OpContext } from '../support/budget.js'
import { failureFromUnknown, runLane, type LaneLogSink, type LaneOutcome } from '../support/lane-runner.js'
import { SettlementWindow } from '../support/settle.js'
import { challengeBlocks, cleanBlocks, markdown, splitBlocks } from './document/blocks.js'
import { DEFAULT_MAX_OUTPUT_CHARS, organizeDocuments } from './document/organize.js'
import { isUsableCandidate } from './select-best.js'
import type { FetchCandidate } from './types.js'

/** 单路提取默认 deadline（v0.2 DEFAULT_FETCH_ENGINE_TIMEOUT_MS = 45s）。 */
export const DEFAULT_FETCH_ENGINE_TIMEOUT_MS = 45_000

/** 提取管线日志汇（装配层映射到 ctx.logger）。 */
export interface FetchPipelineLogger {
  info(message: string): void
  warn(message: string): void
}

/** 装配层提供的引擎上下文构造器：凭证解析（异步、每操作）、端点覆盖、keyless 回退都归装配（AD2）。face 标明用途端点。 */
export type BuildEngineContext = (
  manifest: EngineManifest,
  op: OpContext,
  lane: { signal: AbortSignal; deadline: number; face: 'fetch' | 'quota' },
) => Promise<EngineContext>

/** {@link aggregateDynamicFetch} 的入参。 */
export interface AggregateDynamicFetchOptions {
  /** 是否在「至少三路互补且有共同正文」后提前收掉慢渠道；auto 预设打开。 */
  readonly settleEarly?: boolean
  /** 单页输出预算；缺省 {@link DEFAULT_MAX_OUTPUT_CHARS}。 */
  readonly maxOutputChars?: number
  readonly url: string
  /** registry 顺序的提取引擎表（只认 capabilities 含 fetch 且函数存在者由调用方过滤）。 */
  readonly engines: readonly Engine[]
  /** 显式操作上下文（预算、说明、deadline 判定）。 */
  readonly op: OpContext
  readonly breaker?: CircuitBreaker
  readonly buildContext: BuildEngineContext
  readonly logger?: FetchPipelineLogger
  /** 单路 deadline；缺省 {@link DEFAULT_FETCH_ENGINE_TIMEOUT_MS}。 */
  readonly perEngineTimeoutMs?: number
  /**
   * 首路探测已取得的提取结果：作为普通候选并入整理，不再重复请求同一通道。
   */
  readonly seeds?: readonly FetchCandidate[]
  /** 结果已在 {@link seeds} 中的引擎；绝不重复派发。 */
  readonly skipEngineIds?: readonly string[]
  /** 时钟覆盖（测试）。 */
  readonly now?: () => number
}

type Outcome = LaneOutcome<EngineFetchOutcome>

interface LegFailureNote {
  readonly engineId: string
  readonly code: string
  readonly description: string
}

/** 失败码特异度排序（数字越大越特异，全败时优先返回）。 */
const SPECIFIC_CODE_RANK: Readonly<Record<string, number>> = {
  WEB_BLOCKED_URL: 6,
  WEB_INVALID_URL: 5,
  WEB_FETCH_TOO_LARGE: 4,
  WEB_UNSUPPORTED_CONTENT_TYPE: 3,
  WEB_FETCH_TIMEOUT: 2,
}

/**
 * 描述「目标」而不是「引擎」的码：页面被拦截、URL 非法、过大或类型不支持。
 * 其余都算引擎自身故障。这个分组让全败消息可行动——目标被拒会在每个引擎上失败，
 * 引擎不可用则不会。
 */
const TARGET_REJECTED_CODES: ReadonlySet<string> = new Set([
  'WEB_BLOCKED_URL',
  'WEB_INVALID_URL',
  'WEB_UNSUPPORTED_CONTENT_TYPE',
  'WEB_FETCH_TOO_LARGE',
])

/** fetch 层兜底投影可能携带引擎违约上抛的原始 seam 码（EngineFailure 本身没有该字段）。 */
export interface FetchLaneFailure extends EngineFailure {
  readonly webCode?: string
}

function preservedWebCode(failure: EngineFailure): string | undefined {
  const code = (failure as EngineFailure & { readonly webCode?: unknown }).webCode
  return typeof code === 'string' && code.length > 0 ? code : undefined
}

/**
 * AD6 投影：统一失败模型 → seam 的 WEB_* 码。
 * v0.3 引擎不携带 seam 码，按失败语义映射到最接近、最特异的一个：
 * - target-status：目标站级失败（403/404、extract_target_blocked）→ WEB_BLOCKED_URL；
 *   AnySearch HTTP 422 extract_failed 是引擎侧提取失败，归 WEB_PROVIDER_ERROR，不得进入
 *   target-rejected 组；但 422 载体上带 error_code=extract_target_blocked 时仍属目标站被拦，
 *   保持 WEB_BLOCKED_URL（业务码优先于状态码）。422 编码的 rank 也不得压过真实的
 *   WEB_FETCH_TIMEOUT / WEB_INVALID_URL（v0.2 test/fetch-aggregate.test.ts:509-528 的分组语义）。
 * - invalid → WEB_INVALID_URL；timeout → WEB_FETCH_TIMEOUT；aborted → WEB_ABORTED；
 *   其余引擎侧故障 → WEB_PROVIDER_ERROR。
 * 引擎违约上抛的 WebError 原始码优先（见 failureFromThrown）。
 */
export function failureWebCode(failure: EngineFailure): string {
  const preserved = preservedWebCode(failure)
  if (preserved !== undefined) return preserved
  switch (failure.kind) {
    case 'target-status':
      return failure.statusCode === 422 && !isExtractTargetBlocked(failure) ? 'WEB_PROVIDER_ERROR' : 'WEB_BLOCKED_URL'
    case 'invalid': return 'WEB_INVALID_URL'
    case 'timeout': return 'WEB_FETCH_TIMEOUT'
    case 'aborted': return 'WEB_ABORTED'
    default: return 'WEB_PROVIDER_ERROR'
  }
}

/**
 * AnySearch 业务码 extract_target_blocked 表示目标站被拦：即使载体是 422，
 * 也不能归为引擎提取失败（engine-unavailable）。
 */
function isExtractTargetBlocked(failure: EngineFailure): boolean {
  // 大小写不敏感：anysearch 适配层查表用小写、detail 保留原始大小写（如 EXTRACT_TARGET_BLOCKED），
  // 这里必须同口径比对，否则大写业务码按 422 状态归 WEB_PROVIDER_ERROR，违背「业务码优先于状态码」。
  return failure.detail?.toLowerCase().includes('error_code=extract_target_blocked') ?? false
}

/**
 * 引擎违反「不上抛」契约时的兜底投影：WebError 携带的具体 WEB_* 码必须保真
 * （v0.2 runLeg 的 `error instanceof WebError ? error.code` 同义），不能降级成
 * network/provider-error 后重映射。
 */
export function failureFromThrown(error: unknown): FetchLaneFailure {
  if (!(error instanceof WebError)) return failureFromUnknown(error)
  const kind: EngineFailureKind = (() => {
    switch (error.code) {
      case 'WEB_BLOCKED_URL': return 'target-status'
      case 'WEB_INVALID_URL': return 'invalid'
      case 'WEB_FETCH_TIMEOUT': return 'timeout'
      case 'WEB_ABORTED': return 'aborted'
      default: return 'provider-error'
    }
  })()
  return { ...engineFailure(kind, { detail: error.message }), webCode: error.code }
}

/** 把一次引擎失败投影为 seam 错误（单通道路径与全败路径共用）。 */
export function failureWebError(failure: EngineFailure, label: string): WebError {
  const status = failure.statusCode === undefined ? '' : `（HTTP ${failure.statusCode}）`
  const detail = failure.detail === undefined ? failure.kind : failure.detail
  return new WebError(`${label}：${detail}${status}`, failureWebCode(failure))
}

/** 失败码排序：已知特异码 > 未知码 > WEB_PROVIDER_ERROR。 */
function failureRank(code: string): number {
  return SPECIFIC_CODE_RANK[code] ?? (code === 'WEB_PROVIDER_ERROR' ? 0 : 1)
}

/**
 * 跑一个 URL 的动态路：并发派发每个未熔断引擎（每路独立 deadline）、转发熔断信号、
 * 只整理可用正文，且仅在全部引擎都失败后才抛错——错误码取观察到的最特异一个。
 */
export async function aggregateDynamicFetch(options: AggregateDynamicFetchOptions): Promise<WebFetchResult> {
  const { url, engines, op, breaker, logger, buildContext } = options
  const now = options.now ?? Date.now
  const timeoutMs = options.perEngineTimeoutMs ?? DEFAULT_FETCH_ENGINE_TIMEOUT_MS
  const seeds = options.seeds ?? []
  const skipEngineIds = new Set(options.skipEngineIds ?? [])

  if (engines.length === 0 && seeds.length === 0) {
    throw new WebError('no extraction engines are configured', 'WEB_PROVIDER_ERROR')
  }
  // 总限时到期（deadlineReached）不是「取消」：v0.2 的 runOperation 在总限时后返回
  // 已完成结果并标 truncated，未完成渠道被取消；直接调用聚合器时同样保留这条语义，
  // 因此这里只对调用方主动取消抛 WEB_ABORTED，预到期的 deadline 交给下面的
  // 「幸存者 + truncated」或「无候选 → WEB_FETCH_TIMEOUT」路径。
  if (op.signal.aborted && !op.deadlineReached) throw abortedError(op.signal)

  const active: Engine[] = []
  for (const engine of engines) {
    const engineId = engine.manifest.id
    if (breaker?.isBroken(engineId) === true) {
      logger?.warn(`[提取] 引擎 ${engineId} 处于熔断，已跳过`)
      continue
    }
    if (skipEngineIds.has(engineId)) {
      logger?.info(`[提取] 服务 ${engineId} 的首路结果已在候选集中，不重复派发`)
      continue
    }
    active.push(engine)
  }
  if (active.length === 0 && seeds.length === 0) {
    throw new WebError('all extraction engines are broken', 'WEB_PROVIDER_ERROR')
  }

  const candidatesByLane: (FetchCandidate | undefined)[] = new Array(active.length)
  const notes: LegFailureNote[] = []
  const window = new SettlementWindow(op.signal)
  const substantial = new Map<string, { title: string; anchors: Set<string> }>()

  const runLaneForEngine = async (engine: Engine, index: number): Promise<void> => {
    const engineId = engine.manifest.id
    const outcome = await runLane<EngineFetchOutcome>({
      engineId,
      signal: window.signal,
      deadlineMs: timeoutMs,
      now,
      work: laneSignal => callEngine(engine, url, op, buildContext, laneSignal, now() + timeoutMs),
      ...(logger === undefined ? {} : { log: laneLogSink(logger) }),
    })

    switch (outcome.kind) {
      case 'ok': {
        const result = outcome.result
        if (!isUsableCandidate(result)) {
          logger?.warn(`[提取] 引擎 ${engineId} 返回空正文，候选无效`)
          notes.push({ engineId, code: 'WEB_PROVIDER_ERROR', description: 'empty body' })
          return
        }
        candidatesByLane[index] = { engineId, result, receivedAt: new Date(now()).toISOString() }
        observeSubstantialBody(result, engineId, options.settleEarly, url, substantial, window)
        logger?.info(`[提取] 服务 ${engineId} 成功：状态 ${result.statusCode}，正文 ${result.body.content.length} 字符`)
        return
      }
      case 'timeout':
        notes.push({ engineId, code: 'WEB_FETCH_TIMEOUT', description: `timed out after ${timeoutMs} ms` })
        return
      case 'aborted':
        // 操作取消在全部路结算后统一判定；这里不参与者级失败归因。
        return
      case 'failed': {
        logger?.warn(`[提取] 引擎 ${engineId} 失败：${outcome.failure.kind}${outcome.failure.statusCode ?? ''}`)
        notes.push({
          engineId,
          code: failureWebCode(outcome.failure),
          description: outcome.failure.detail ?? outcome.failure.kind,
        })
        const signal = breakerSignalOf(outcome.failure)
        if (signal !== undefined) breaker?.recordSignal(engineId, signal)
        return
      }
    }
  }

  try {
    await Promise.allSettled(active.map(runLaneForEngine))
  } finally {
    window.finish()
  }
  if (window.endedEarly) {
    op.note('已有至少三路可互补且有共同正文的提取，宽限等待结束后提前取消慢渠道；未完成内容未纳入整理。')
  }

  // 同上：总限时到期时允许已完成候选继续整理（truncated=true），只有调用方取消才抛。
  if (op.signal.aborted && !op.deadlineReached) throw abortedError(op.signal)
  const candidates = [
    ...seeds,
    ...candidatesByLane.filter((candidate): candidate is FetchCandidate => candidate !== undefined),
  ]
  if (candidates.length === 0) {
    if (op.deadlineReached) throw new WebError('fetch deadline exceeded', 'WEB_FETCH_TIMEOUT')
    throw allFailedError(notes)
  }

  const output = organizeDocuments(url, candidates, options.maxOutputChars ?? DEFAULT_MAX_OUTPUT_CHARS, [
    ...notes.map(note => `${note.engineId}: ${note.code}`),
    ...op.notes,
    ...(window.endedEarly ? ['多路正文充分后提前结束等待，保留已完成结果。'] : []),
    `本插件 HTTP 请求：${op.requestCount} 次。`,
  ])
  logger?.info(
    `[提取] 已整理 ${candidates.length} 路结果，输出 ${output.body.content.length} 字符；请求 ${op.requestCount} 次。`,
  )
  return {
    ...output,
    truncated: window.endedEarly
      || output.truncated
      || op.deadlineReached
      || notes.some(note => note.code === 'WEB_FETCH_TIMEOUT'),
  }
}

/** 引擎调用兜底：契约要求引擎不上抛，异常仍收敛为统一失败模型，绝不让单路炸掉整个操作。 */
async function callEngine(
  engine: Engine,
  url: string,
  op: OpContext,
  buildContext: BuildEngineContext,
  signal: AbortSignal,
  deadline: number,
): Promise<EngineResult<EngineFetchOutcome>> {
  try {
    const context = await buildContext(engine.manifest, op, { signal, deadline, face: 'fetch' })
    return await engine.fetch!(url, context)
  } catch (error) {
    return { ok: false, failure: failureFromThrown(error) }
  }
}

/**
 * v0.2 提前结算信号原样移植：同一目标、2xx、无挑战、正文 ≥1200 段落字符的提取，
 * 以「标题 + 长段落 key」为锚点；三路出现相同锚点时打开宽限窗口。
 */
function observeSubstantialBody(
  result: EngineFetchOutcome,
  engineId: string,
  settleEarly: boolean | undefined,
  url: string,
  substantial: Map<string, { title: string; anchors: Set<string> }>,
  window: SettlementWindow,
): void {
  if (settleEarly === false) return
  if (result.statusCode < 200 || result.statusCode >= 300 || result.url !== url) return
  const blocks = cleanBlocks(splitBlocks(markdown(result.body.content, result.body.kind)))
  const paragraphs = blocks
    .filter(block => block.kind === 'paragraph')
    .map(block => block.text.replace(/\s+/g, ' ').trim())
  if (!challengeBlocks(blocks) && paragraphs.join(' ').length >= 1200) {
    substantial.set(engineId, {
      title: (blocks.find(block => block.kind === 'heading')?.key ?? '').split(/\s+(?:—|\||-)\s+/)[0]!.toLowerCase(),
      anchors: new Set(
        blocks
          .filter(block => block.kind === 'paragraph' && block.text.length >= 100)
          .map(block => block.key),
      ),
    })
  }
  const agreement = new Map<string, number>()
  for (const body of substantial.values()) {
    for (const anchor of body.anchors) {
      const key = `${body.title}\n${anchor}`
      agreement.set(key, (agreement.get(key) ?? 0) + 1)
    }
  }
  window.observe([...agreement.values()].some(count => count >= 3))
}

/** 编排层的单路日志汇：带引擎前缀转发到管线 logger。 */
function laneLogSink(logger: FetchPipelineLogger): LaneLogSink {
  return {
    laneInfo: (engineId, message) => logger.info(`[提取] ${engineId} ${message}`),
    laneWarn: (engineId, message) => logger.warn(`[提取] ${engineId} ${message}`),
  }
}

/**
 * 组装全败错误：逐路原因按「目标拒绝了我们」与「引擎不可用」分组，取最特异的码。
 * 分组比码更重要：所有引擎都报同一目标级拒绝时重试无益，消息直说；
 * 引擎自身故障时消息点名它们。
 */
function allFailedError(notes: readonly LegFailureNote[]): WebError {
  let best = notes[0]
  for (const note of notes) {
    if (best === undefined || failureRank(note.code) > failureRank(best.code)) best = note
  }
  const rejected = notes.filter(note => TARGET_REJECTED_CODES.has(note.code))
  const unavailable = notes.filter(note => !TARGET_REJECTED_CODES.has(note.code))
  const describe = (group: readonly LegFailureNote[]): string =>
    group.map(note => `${note.engineId} (${note.code}: ${note.description})`).join('; ')
  const parts: string[] = []
  if (rejected.length > 0) parts.push(`目标被拒绝 target-rejected：${describe(rejected)}`)
  if (unavailable.length > 0) parts.push(`引擎不可用 engine-unavailable：${describe(unavailable)}`)
  return new WebError(`all extraction engines failed. ${parts.join(' | ')}`, best?.code ?? 'WEB_PROVIDER_ERROR')
}

/** 操作自身取消 → seam 的取消码。 */
function abortedError(signal: AbortSignal): WebError {
  return new WebError('Aggregated web fetch aborted', 'WEB_ABORTED', { cause: signal.reason })
}
