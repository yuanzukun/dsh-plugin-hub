// 打分函数——v0.2 src/fetch-aggregate.ts:177-361 的库函数移植（引擎权重 + 正文长度 +
// 正文密度 + 标题匹配）。v0.2 的 DEFAULT_ENGINE_WEIGHTS = { firecrawl: 3, anysearch: 2 }
// 不在编排层硬编码（AD2）：权重由调用方显式传入，缺省所有引擎同权 2。
// v0.3 提取主线只做 organize 整理、不再择优，装配层也没有权重注入点（spec §3.4）；
// 这些函数保留给测试与将来的显式打分路径。

import { createHash } from 'node:crypto'
import type { WebFetchResult } from '@deepseek-ai/dsh-web'
import type { FetchCandidate } from './types.js'

export type { FetchCandidate } from './types.js'

/** 长度分在多少字符时饱和。 */
export const LENGTH_SCORE_FULL_CHARS = 2_000
/** 长度分上限，在 {@link LENGTH_SCORE_FULL_CHARS} 字符时达到。 */
export const LENGTH_SCORE_MAX = 2
/** 文本密度信号（文字字符 / 总字符）上限。 */
export const DENSITY_SCORE_MAX = 1
/** slug 与标题匹配信号上限。 */
export const TITLE_MATCH_SCORE_MAX = 1.5
/** 在正文头部多少字符内查找标题。 */
export const TITLE_WINDOW_CHARS = 500
/** 没有显式权重的引擎使用的默认权重（v0.3：全部引擎同权）。 */
export const DEFAULT_ENGINE_WEIGHT = 2

/** 进入选择的一个候选。 */
export interface ScoredCandidate extends FetchCandidate {
  readonly score: number
  readonly breakdown: CandidateScoreBreakdown
}

/** 候选得分背后的逐信号分解，供测试与日志。 */
export interface CandidateScoreBreakdown {
  readonly weight: number
  readonly length: number
  readonly density: number
  readonly titleMatch: number
}

/** 提取结果的正文文本（封闭联合的两支都带 `content`）。 */
function bodyText(result: WebFetchResult): string {
  return result.body.content
}

/**
 * 候选是否算可用正文：200 但正文为空（或纯空白）无效、不计分。
 */
export function isUsableCandidate(result: WebFetchResult): boolean {
  return bodyText(result).trim().length > 0
}

/**
 * 「词」字符（Unicode 字母/数字）在正文中的比例——文本/总字符密度信号。
 * 标记或模板噪声重的抓取得分低；扎实的散文得分高。
 */
function densityRatio(text: string): number {
  if (text.length === 0) return 0
  const matches = text.match(/[\p{L}\p{N}]/gu)
  return (matches?.length ?? 0) / text.length
}

/** URL 最后一个路径段：分隔符归一为空格并小写。 */
export function extractUrlSlug(rawUrl: string): string {
  let url: URL
  try {
    url = new URL(rawUrl)
  } catch {
    return ''
  }
  const lastSegment = decodeSafely(url.pathname.split('/').pop() ?? '')
  const dot = lastSegment.lastIndexOf('.')
  const withoutExtension = dot > 0 ? lastSegment.slice(0, dot) : lastSegment
  return withoutExtension
    .replace(/[-_.+]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase()
}

/**
 * 正文的标题：在前 {@link TITLE_WINDOW_CHARS} 字符内取第一个 markdown 标题；
 * 否则取首个非空行。都没有时为空。
 */
export function extractBodyTitle(text: string): string {
  const window = text.slice(0, TITLE_WINDOW_CHARS)
  const heading = /^#{1,6}[ \t]+(.+)$/m.exec(window)
  if (heading !== null) {
    return heading[1]!.trim().replace(/#+$/, '').trim()
  }
  for (const line of window.split('\n')) {
    const trimmed = line.trim()
    if (trimmed.length > 0) return trimmed
  }
  return ''
}

/** 相似度用的词元集合：Unicode 字母/数字连续段，小写。 */
function tokenize(text: string): Set<string> {
  return new Set(text.toLowerCase().match(/[\p{L}\p{N}]+/gu) ?? [])
}

/** 两个标题词元集合的 Jaccard 相似度；空输入得 0。 */
export function titleSimilarity(a: string, b: string): number {
  const tokensA = tokenize(a)
  const tokensB = tokenize(b)
  if (tokensA.size === 0 || tokensB.size === 0) return 0
  let intersection = 0
  for (const token of tokensA) {
    if (tokensB.has(token)) intersection += 1
  }
  const union = tokensA.size + tokensB.size - intersection
  return intersection / union
}

/** 一致性指纹：正文 sha1 的前 8 位十六进制。 */
export function bodyFingerprint(text: string): string {
  return createHash('sha1').update(text, 'utf8').digest('hex').slice(0, 8)
}

/** 解析一个引擎的权重：显式覆盖，否则默认权重（v0.3 缺省全 2）。 */
function engineWeight(engineId: string, overrides?: Readonly<Record<string, number>>): number {
  const override = overrides?.[engineId]
  if (typeof override === 'number' && Number.isFinite(override)) return override
  return DEFAULT_ENGINE_WEIGHT
}

/**
 * 给一个候选打分：引擎权重 + 正文长度（封顶）+ 正文密度 + slug 与标题匹配。
 * 确定性纯函数，选择因此可复现。
 */
export function scoreCandidate(
  engineId: string,
  result: WebFetchResult,
  requestUrl: string,
  weights: Readonly<Record<string, number>> = {},
): ScoredCandidate {
  const text = bodyText(result)
  const breakdown: CandidateScoreBreakdown = {
    weight: engineWeight(engineId, weights),
    length: Math.min(text.length / LENGTH_SCORE_FULL_CHARS, 1) * LENGTH_SCORE_MAX,
    density: densityRatio(text) * DENSITY_SCORE_MAX,
    titleMatch:
      titleSimilarity(extractUrlSlug(requestUrl), extractBodyTitle(text)) * TITLE_MATCH_SCORE_MAX,
  }
  const score = breakdown.weight + breakdown.length + breakdown.density + breakdown.titleMatch
  return { engineId, result, score, breakdown }
}

/**
 * 择优：取最高分的可用候选；平手时先到先得（引擎派发顺序）。
 * 空正文候选排除；只有没有任何可用候选时 `best` 才是 `undefined`。
 */
export function selectBestCandidate(
  requestUrl: string,
  candidates: readonly FetchCandidate[],
  weights: Readonly<Record<string, number>> = {},
): { best: ScoredCandidate | undefined; scored: readonly ScoredCandidate[] } {
  const scored: ScoredCandidate[] = []
  let best: ScoredCandidate | undefined
  for (const candidate of candidates) {
    if (!isUsableCandidate(candidate.result)) continue
    const entry = scoreCandidate(candidate.engineId, candidate.result, requestUrl, weights)
    scored.push(entry)
    if (best === undefined || entry.score > best.score) best = entry
  }
  return { best, scored }
}

/** 尽力解码 URL 路径段；非法百分号转义原样通过。 */
function decodeSafely(value: string): string {
  try {
    return decodeURIComponent(value)
  } catch {
    return value
  }
}
