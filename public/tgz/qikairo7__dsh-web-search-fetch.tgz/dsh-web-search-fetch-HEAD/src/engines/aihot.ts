// AIHOT 搜索、热点榜与专用只读 API 适配；契约来源 docs/aihot.md 与官方 OpenAPI。

import { WebError, type WebFetchResult } from '@deepseek-ai/dsh-web'

import type {
  Engine,
  EngineContext,
  EngineResult,
  EngineSearchOutcome,
  EngineSearchSource,
  SearchFn,
  HotTopicsFn,
} from './contract.js'
import { clipDetail, engineFailure, isAbortError, type EngineFailure } from './failure.js'
import { EngineHttpError, engineFetch, projectHttpError } from './http.js'
import { AIHOT_MANIFEST } from './registry.js'
import {
  buildRequestUrl,
  isRecord,
  outgoingQuery,
  type ParsedItems,
  readBoundedText,
  readItems,
  toOutcome,
} from './aihot-items.js'
import { problemDetail, problemRetryAfterMs } from './aihot-problem.js'
import { apiTarget, DEFAULT_CACHE_TTL_MS, type ApiTarget } from './aihot-target.js'

/** v0.2 查询长度约定：2–200 个字符（按码点计）。 */
const MIN_QUERY_CODE_POINTS = 2
const MAX_QUERY_CODE_POINTS = 200
const MAX_CACHE_ENTRIES = 32
/** v0.2 冷却默认值：上游没有 Retry-After 时按 60 秒冷却。 */
const DEFAULT_COOLDOWN_MS = 60_000
/** v0.2 readText 的响应体上限：先限量读取再解析，异常大包不整包进内存。 */
const MAX_RESPONSE_BYTES = 1_000_000
const AIHOT_SITE = 'https://aihot.news'

export interface AihotEngineOptions {
  /** 注入 fetcher（离线单测替身）；缺省全局 fetch。 */
  readonly fetcher?: typeof fetch
  /** 覆盖请求 URL（不改 manifest，用于用户端点配置与测试替身）。 */
  readonly endpointOverride?: string
}

interface CachedItems {
  readonly data: ParsedItems
  readonly etag?: string
  /** 200 响应缓存指令得到的 TTL；304 未给 Cache-Control 时续期用它作回退。 */
  readonly ttlMs: number
  readonly expiresAt: number
}

/**
 * 创建 AIHOT 引擎：匿名只读，无 key 分支；搜索走 `/api/v1/items` 的关键词检索。
 * 缓存与冷却挂在引擎实例上（v0.2 的 EngineHttp 实例级状态），不是跨进程限流器。
 */
export function createAihotEngine(options: AihotEngineOptions = {}): Engine {
  const cache = new Map<string, CachedItems>()
  let cooldown: { until: number; failure: EngineFailure } | undefined

  const search: SearchFn = async (request, ctx): Promise<EngineResult<EngineSearchOutcome>> => {
    const query = outgoingQuery(request)
    const length = [...query].length
    if (length < MIN_QUERY_CODE_POINTS || length > MAX_QUERY_CODE_POINTS) {
      return fail(engineFailure('invalid', {
        detail: `AIHOT 查询需 ${MIN_QUERY_CODE_POINTS}–${MAX_QUERY_CODE_POINTS} 个字符，实际 ${length}`,
      }))
    }
    if (ctx.signal.aborted) return fail(engineFailure('aborted', { detail: '操作已取消' }))

    const url = buildRequestUrl(options.endpointOverride ?? ctx.endpoint, query, request.maxResults)
    if (url === undefined) return fail(engineFailure('invalid', { detail: 'AIHOT 搜索端点无效' }))

    // 缓存命中优先于冷却（v0.2 cachedText 在进入 request() 前返回缓存），不发请求、不消耗预算。
    const cached = cache.get(url)
    if (cached !== undefined && cached.expiresAt > Date.now()) {
      return ok(toOutcome(cached.data, request.maxResults))
    }
    if (cooldown !== undefined && cooldown.until > Date.now()) return fail(cooldown.failure)

    try {
      const headers: Record<string, string> = {
        accept: 'application/json',
        'accept-encoding': 'gzip, br',
        'user-agent': 'dsh-web-search-fetch',
      }
      if (cached?.etag !== undefined) headers['if-none-match'] = cached.etag
      const response = await engineFetch(ctx, url, { method: 'GET', headers, fetcher: options.fetcher })
      const parsed = await readItems(response)
      if (typeof parsed === 'string') {
        return fail(engineFailure('provider-error', { statusCode: response.status, detail: clipDetail(parsed) }))
      }
      storeCache(url, parsed, response.headers, cached?.etag)
      return ok(toOutcome(parsed, request.maxResults))
    } catch (error) {
      // engineFetch 把 304 当作非 2xx 抛出；条件验证成功时复用已验证过的缓存数据。
      // 续期优先读 304 自身的 Cache-Control/ETag（v0.2 语义）；304 未给缓存指令时回退上次 200 的 TTL。
      if (error instanceof EngineHttpError && error.kind === 'http' && error.status === 304) {
        if (cached === undefined) {
          return fail(engineFailure('provider-error', { statusCode: 304, detail: 'AIHOT 返回 304 但无可复用缓存' }))
        }
        const control = error.headers?.get('cache-control') ?? ''
        const etag = error.headers?.get('etag') ?? cached.etag
        if (/\bno-store\b/i.test(control)) {
          cache.delete(url)
        } else {
          const ttlMs = cacheTtlMs(control, cached.ttlMs > 0 ? cached.ttlMs : DEFAULT_CACHE_TTL_MS)
          cache.set(url, {
            ...cached,
            expiresAt: Date.now() + ttlMs,
            ttlMs,
            ...(etag === undefined ? {} : { etag }),
          })
        }
        return ok(toOutcome(cached.data, request.maxResults))
      }
      return fail(projectFailure(error, ctx))
    }
  }

  /** 429/503 冷却 + 统一失败投影；503 是 AIHOT 上游的限流信号（v0.2 语义），不按 provider-error 处理。 */
  function projectFailure(error: unknown, ctx: EngineContext): EngineFailure {
    if (error instanceof EngineHttpError && error.kind === 'http') {
      const detail = problemDetail(error)
      if (error.status === 429 || error.status === 503) {
        const base = engineFailure('rate-limited', { statusCode: error.status, detail })
        // Retry-After 头缺失时用 Problem JSON 的 retryAfter（官方 OpenAPI：整数秒）作回退。
        const retryAfterMs = error.retryAfterMs ?? problemRetryAfterMs(error)
        const failure = retryAfterMs === undefined ? base : { ...base, retryAfterMs }
        cooldown = { until: Date.now() + (failure.retryAfterMs ?? DEFAULT_COOLDOWN_MS), failure }
        return failure
      }
      if (error.status === 402) {
        return engineFailure('quota', { statusCode: 402, detail, quotaExhausted: true })
      }
      // 401/403 也走 provider-error：AIHOT 是匿名引擎、没有凭证位，403 实际是策略/授权拒绝
      // （响应头 X-AIHOT-Commercial-Use），投影为 auth 会误导用户去配置不存在的 key（v0.2 语义）。
      return engineFailure('provider-error', { statusCode: error.status, detail })
    }
    const failure = projectHttpError(error)
    // engineFetch 已把单请求超时归为 timeout；这里保留 deadline 判据，把 deadline 到期时
    // 发生的真实网络失败也按 timeout 呈现（deadline 已过，重试无意义）。
    if (failure.kind === 'network' && Date.now() >= ctx.deadline) {
      return engineFailure('timeout', { statusCode: failure.statusCode, detail: failure.detail })
    }
    return failure
  }

  /** 200 响应：先解析校验再入缓存，畸形 JSON / 非法结构不会被缓存掩盖到过期。 */
  function storeCache(url: string, data: ParsedItems, headers: Headers, previousEtag?: string): void {
    const control = headers.get('cache-control') ?? ''
    if (/\bno-store\b/i.test(control)) {
      cache.delete(url)
      return
    }
    // v0.2 语义：200 不带 ETag 时保留旧 ETag，条件验证才不会退化成全量 GET。
    const etag = headers.get('etag') ?? previousEtag
    const ttlMs = cacheTtlMs(control)
    cache.delete(url)
    while (cache.size >= MAX_CACHE_ENTRIES) {
      const oldest = cache.keys().next()
      if (oldest.done) break
      cache.delete(oldest.value)
    }
    cache.set(url, {
      data,
      expiresAt: Date.now() + ttlMs,
      ttlMs,
      ...(etag === undefined ? {} : { etag }),
    })
  }

  /**
   * 热点榜（v0.4 hot-list 意图）：GET /api/v1/hot-topics，匿名，最多 10 条、官方按 rank 排序。
   * 契约（capability-aihot.json，实探 2026-11-07）：items[]{rank, id, title, source.name,
   * links{aihot, original?}, sourceCount, signalCount, latestAt}。官方建议轮询不高于每分钟一次
   * ——本能力仅由 hot-list 意图触达（低频），首版不设本地缓存；失败投影复用 projectFailure
   * （429/503 会进入引擎级冷却，与搜索路一致）。
   */
  const hotTopics: HotTopicsFn = async (ctx): Promise<EngineResult<EngineSearchOutcome>> => {
    if (ctx.signal.aborted) return fail(engineFailure('aborted', { detail: '操作已取消' }))
    const base = options.endpointOverride ?? ctx.endpoint ?? AIHOT_SITE
    let url: URL
    try {
      url = new URL('/api/v1/hot-topics', base)
    } catch {
      return fail(engineFailure('invalid', { detail: 'AIHOT 端点无效' }))
    }
    try {
      const response = await engineFetch(ctx, url.href, { method: 'GET', headers: { accept: 'application/json' }, fetcher: options.fetcher })
      const payload: unknown = await response.json()
      if (!isRecord(payload) || !Array.isArray(payload.items)) {
        return fail(engineFailure('provider-error', { statusCode: response.status, detail: 'AIHOT 热点榜响应缺少 items 数组' }))
      }
      const sources: EngineSearchSource[] = []
      for (const item of payload.items) {
        if (!isRecord(item)) continue
        const title = typeof item.title === 'string' ? item.title : ''
        const links = isRecord(item.links) ? item.links : undefined
        const original = links !== undefined && typeof links.original === 'string' ? links.original : undefined
        const aihot = links !== undefined && typeof links.aihot === 'string' ? links.aihot : undefined
        const href = original ?? aihot
        if (title.length === 0 || href === undefined) continue
        const latestAt = typeof item.latestAt === 'string' ? item.latestAt : undefined
        const sourceCount = typeof item.sourceCount === 'number' ? item.sourceCount : undefined
        sources.push({
          url: href,
          ...(title.length > 0 ? { title } : {}),
          ...(sourceCount !== undefined ? { snippet: `${sourceCount} 家来源共同报道` } : {}),
          ...(latestAt !== undefined ? { publishedAt: latestAt } : {}),
        })
      }
      if (sources.length === 0) {
        return fail(engineFailure('provider-error', { statusCode: response.status, detail: 'AIHOT 热点榜无可映射条目' }))
      }
      return ok({ sources, truncated: false })
    } catch (error) {
      return fail(projectFailure(error, ctx))
    }
  }

  return { manifest: AIHOT_MANIFEST, search, hotTopics }
}

/** 专用 API 文本上限（v0.2）：不截断 JSON，否则会丢 nextCursor/removes；超限由调用方缩小 limit。 */
const MAX_API_TEXT_CHARS = 100_000

export interface AihotApiReaderOptions {
  /** 注入 fetcher（离线单测替身）；缺省全局 fetch。 */
  readonly fetcher?: typeof fetch
}

/**
 * 与 src/fetch/provider.ts:51-54 的 DedicatedApiReader 结构兼容。
 * AD2 禁止引擎层 import 提取层模块，故在此重复声明形状（字段与注释指向保持同步）。
 */
export interface AihotApiReader {
  readonly engineId: 'aihot'
  readApi(url: string, ctx: EngineContext): Promise<WebFetchResult | undefined>
}

interface CachedApiText {
  readonly content: string
  readonly etag?: string
  readonly ttlMs: number
  readonly expiresAt: number
}

/**
 * 创建 AIHOT 专用读取器：只接管文档化的 /api/v1/* 只读端点与 agent Markdown 面；
 * 其余 URL 返回 undefined，调用方继续通用提取。
 *
 * 失败约定（对照 src/fetch/provider.ts 的 DedicatedApiReader 与 WebFetchProvider 契约）：
 * - 上游非 2xx 是可表示的资源状态，Problem JSON 原样保留 code/requestId/retryAfter，
 *   收敛为对应 statusCode 的 WebFetchResult（不上抛）；429/503 另按 EngineFailure 分类冷却；
 * - 传输/校验类失败无法用 WebFetchResult 表示，上抛路由化的 WebError（provider 不 catch，
 *   由 seam 统一处理），裸异常不外泄。
 */
export function createAihotApiReader(options: AihotApiReaderOptions = {}): AihotApiReader {
  const cache = new Map<string, CachedApiText>()
  let cooldown: { until: number; statusCode: number; content: string } | undefined

  return {
    engineId: 'aihot',
    async readApi(rawUrl, ctx) {
      const target = apiTarget(rawUrl)
      if (target === undefined) return undefined

      // 缓存命中优先于冷却（v0.2 cachedText 在进入请求前返回缓存），不发请求、不消耗预算。
      const cached = cache.get(target.key)
      if (cached !== undefined && cached.expiresAt > Date.now()) {
        return apiTextResult(target.url, cached.content)
      }
      if (cooldown !== undefined && cooldown.until > Date.now()) {
        return apiTextResult(target.url, cooldown.content, cooldown.statusCode)
      }

      const headers: Record<string, string> = {
        accept: target.markdown ? 'text/markdown' : 'application/json, application/problem+json;q=0.9',
        'accept-encoding': 'gzip, br',
        'user-agent': 'dsh-web-search-fetch',
      }
      if (cached?.etag !== undefined) headers['if-none-match'] = cached.etag

      try {
        const response = await engineFetch(ctx, target.url, {
          method: 'GET',
          headers,
          ...(options.fetcher === undefined ? {} : { fetcher: options.fetcher }),
        })
        const content = await readApiContent(response, target.markdown)
        const control = response.headers.get('cache-control') ?? ''
        if (/\bno-store\b/i.test(control)) {
          cache.delete(target.key)
        } else {
          // v0.2 语义：200 不带 ETag 时保留旧 ETag，条件验证才不会退化成全量 GET。
          const etag = response.headers.get('etag') ?? cached?.etag
          const ttlMs = cacheTtlMs(control, target.defaultTtlMs)
          cache.delete(target.key)
          while (cache.size >= MAX_CACHE_ENTRIES) {
            const oldest = cache.keys().next()
            if (oldest.done) break
            cache.delete(oldest.value)
          }
          cache.set(target.key, {
            content,
            expiresAt: Date.now() + ttlMs,
            ttlMs,
            ...(etag === undefined ? {} : { etag }),
          })
        }
        return apiTextResult(target.url, content)
      } catch (error) {
        // 本读取器自产的 WebError（超限/格式/版本）原样上抛，不能被下面的网络投影降级。
        if (error instanceof WebError) throw error
        if (error instanceof EngineHttpError && error.kind === 'http') {
          // engineFetch 把 304 当作非 2xx 抛出；条件验证成功时复用已验证过的缓存。
          // 续期优先读 304 自身的 Cache-Control/ETag；未给缓存指令时回退上次 200 的 TTL。
          if (error.status === 304) {
            if (cached === undefined) {
              throw failureToWebError(engineFailure('provider-error', {
                statusCode: 304,
                detail: 'AIHOT 返回 304 但无可复用缓存',
              }))
            }
            const control = error.headers?.get('cache-control') ?? ''
            const etag = error.headers?.get('etag') ?? cached.etag
            if (/\bno-store\b/i.test(control)) {
              cache.delete(target.key)
            } else {
              const ttlMs = cacheTtlMs(control, cached.ttlMs > 0 ? cached.ttlMs : target.defaultTtlMs)
              cache.set(target.key, {
                ...cached,
                expiresAt: Date.now() + ttlMs,
                ttlMs,
                ...(etag === undefined ? {} : { etag }),
              })
            }
            return apiTextResult(target.url, cached.content)
          }
          const failure = problemFailure(error)
          const content = problemContent(error, failure)
          if (failure.kind === 'rate-limited') {
            cooldown = {
              until: Date.now() + (failure.retryAfterMs ?? DEFAULT_COOLDOWN_MS),
              statusCode: error.status ?? 0,
              content,
            }
          }
          return apiTextResult(target.url, content, error.status ?? 0)
        }
        throw failureToWebError(projectApiFailure(error, ctx))
      }
    },
  }
}

/** 读取 200 响应：agent Markdown 原样返回；JSON 端点校验版本后重新序列化（保留 null 与不透明 cursor）。 */
async function readApiContent(response: Response, markdown: boolean): Promise<string> {
  let text: string | undefined
  try {
    text = await readBoundedText(response, MAX_RESPONSE_BYTES)
  } catch (error) {
    // 中止/超时交给外层统一投影，不当作格式错误。
    if (isAbortError(error)) throw error
    throw apiFailure(`AIHOT 响应读取失败：${errorMessage(error)}`)
  }
  if (text === undefined) throw apiFailure(`AIHOT 响应超过 ${MAX_RESPONSE_BYTES} 字节上限`)
  if (text.trim().length === 0) throw apiFailure('AIHOT 响应为空')
  if (markdown) {
    assertApiTextSize(text)
    return text
  }
  let payload: unknown
  try {
    payload = JSON.parse(text)
  } catch (error) {
    throw apiFailure(`AIHOT 响应不是 JSON：${errorMessage(error)}`)
  }
  if (!isRecord(payload) || payload.schemaVersion !== 1) {
    throw apiFailure('AIHOT 响应版本无效（schemaVersion !== 1）')
  }
  const content = JSON.stringify(payload, null, 2)
  assertApiTextSize(content)
  return content
}

/** Problem JSON（application/problem+json）按官方 OpenAPI 契约投影为统一失败模型。 */
function problemFailure(error: EngineHttpError): EngineFailure {
  const status = error.status ?? 0
  const retryAfterMs = error.retryAfterMs ?? problemRetryAfterMs(error)
  const kind = status === 429 || status === 503 ? 'rate-limited' : status === 402 ? 'quota' : 'provider-error'
  return engineFailure(kind, {
    statusCode: status,
    detail: problemDetail(error),
    ...(retryAfterMs === undefined ? {} : { retryAfterMs }),
  })
}

/** 非 2xx 的响应文本：Problem JSON 原样保留（code/requestId/retryAfter 不丢），否则退回错误摘要。 */
function problemContent(error: EngineHttpError, failure: EngineFailure): string {
  if (isRecord(error.body)) return JSON.stringify(error.body, null, 2)
  return failure.detail ?? error.detail ?? `AIHOT 返回 HTTP ${error.status ?? 0}`
}

/** 传输类异常投影；deadline 到期时把真实 network 失败也改判 timeout（单请求超时已由 engineFetch 归为 timeout）。 */
function projectApiFailure(error: unknown, ctx: EngineContext): EngineFailure {
  const failure = projectHttpError(error)
  if (failure.kind === 'network' && Date.now() >= ctx.deadline) {
    return engineFailure('timeout', { statusCode: failure.statusCode, detail: failure.detail })
  }
  return failure
}

/** 统一失败模型 → seam 的 WEB_* 码（src/fetch/aggregate.ts failureFromThrown/failureWebCode 的等价物，AD2 不 import）。 */
function failureToWebError(failure: EngineFailure): WebError {
  const status = failure.statusCode === undefined ? '' : `（HTTP ${failure.statusCode}）`
  const detail = failure.detail === undefined ? failure.kind : failure.detail
  return new WebError(`AIHOT 专用 API：${detail}${status}`, failureWebCodeOf(failure))
}

function failureWebCodeOf(failure: EngineFailure): string {
  switch (failure.kind) {
    case 'invalid': return 'WEB_INVALID_URL'
    case 'timeout': return 'WEB_FETCH_TIMEOUT'
    case 'aborted': return 'WEB_ABORTED'
    default: return 'WEB_PROVIDER_ERROR'
  }
}

/** 校验类失败（读失败/空响应/非 JSON/版本不符）→ 路由化 WebError。 */
function apiFailure(detail: string): WebError {
  return failureToWebError(engineFailure('provider-error', { detail: clipDetail(detail) }))
}

/** 不截断 JSON：超过上限时明确失败，绝不把残包当成功结果。 */
function assertApiTextSize(content: string): void {
  if (content.length > MAX_API_TEXT_CHARS) {
    throw new WebError(
      `AIHOT 响应超过 ${MAX_API_TEXT_CHARS} 字符上限；请缩小 limit 后重试`,
      'WEB_FETCH_TOO_LARGE',
    )
  }
}

function apiTextResult(url: string, content: string, statusCode = 200): WebFetchResult {
  return { url, statusCode, body: { kind: 'text', content }, truncated: false }
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

function ok(outcome: EngineSearchOutcome): EngineResult<EngineSearchOutcome> {
  return { ok: true, outcome }
}

function fail(failure: EngineFailure): EngineResult<EngineSearchOutcome> {
  return { ok: false, failure }
}

/** 缓存指令：no-cache 立即可重新验证；否则取 max-age 与 s-maxage 的较大值（s-maxage 是最小轮询间隔）。 */
function cacheTtlMs(control: string, fallbackMs = DEFAULT_CACHE_TTL_MS): number {
  if (/\bno-cache\b/i.test(control)) return 0
  const maxAge = readDirectiveSeconds(control, 'max-age')
  const sMaxAge = readDirectiveSeconds(control, 's-maxage')
  if (maxAge === undefined && sMaxAge === undefined) return fallbackMs
  return Math.max(maxAge ?? 0, sMaxAge ?? 0) * 1000
}

function readDirectiveSeconds(control: string, directive: string): number | undefined {
  const match = new RegExp(`(?:^|[,;\\s])${directive}=(\\d+)`, 'i').exec(control)
  return match === null ? undefined : Number(match[1])
}
