// AIHOT 引擎适配——v0.2 搜索面移植到 v0.3 契约。
// 来源：
// - v0.2 src/engines/additional/adapters.ts:50-76（case 'aihot'：GET /api/v1/items?mode=all&window=7d&q&limit、
//   schemaVersion/page.hasMore 校验、items→sources 映射、page.hasMore→truncated）；
// - v0.2 src/engines/additional/http.ts（ETag/304 条件缓存、429/503 Retry-After 冷却、失败不回传过期数据）；
// - docs/aihot.md（结构化 API 与缓存节奏）；官方 OpenAPI：https://aihot.news/openapi-v1.json。
// v0.3 只移植 search 能力：专用读取 API（日报/周报/热点详情）属于 aihot-api 能力面，不在本轮 search/fetch 范围；
// 官方无额度端点，quota 保持未实现（设置页显式 N/A，spec §3.3）。

import { WebError, type WebFetchResult } from '@deepseek-ai/dsh-web'

import type {
  Engine,
  EngineContext,
  EngineSearchRequest,
  EngineResult,
  EngineSearchOutcome,
  EngineSearchSource,
  SearchFn,
  HotTopicsFn,
} from './contract.js'
import { clipDetail, engineFailure, isAbortError, type EngineFailure } from './failure.js'
import { EngineHttpError, engineFetch, projectHttpError } from './http.js'
import { AIHOT_MANIFEST } from './registry.js'

/** v0.2 查询长度约定：2–200 个字符（按码点计）。 */
const MIN_QUERY_CODE_POINTS = 2
const MAX_QUERY_CODE_POINTS = 200
/** v0.2 count(request, 100)：上游 items 接口 limit 上限。 */
const MAX_RESULTS_CAP = 100
/** v0.2 cachedText 默认 TTL 与缓存条数上限（items 类接口 60 秒）。 */
const DEFAULT_CACHE_TTL_MS = 60_000
const MAX_CACHE_ENTRIES = 32
/** v0.2 冷却默认值：上游没有 Retry-After 时按 60 秒冷却。 */
const DEFAULT_COOLDOWN_MS = 60_000
/** v0.2 readText 的响应体上限：先限量读取再解析，异常大包不整包进内存。 */
const MAX_RESPONSE_BYTES = 1_000_000
const AIHOT_SITE = 'https://aihot.news'

export interface AihotEngineOptions {
  /** 注入 fetcher（离线单测替身）；缺省全局 fetch。 */
  readonly fetcher?: typeof fetch
  /** 覆盖请求 URL（不改 manifest，用于用户端点配置与测试替身）。 */
  readonly endpointOverride?: string
}

interface ParsedItems {
  readonly sources: readonly EngineSearchSource[]
  readonly hasMore: boolean
}

interface CachedItems {
  readonly data: ParsedItems
  readonly etag?: string
  /** 200 响应缓存指令得到的 TTL；304 未给 Cache-Control 时续期用它作回退。 */
  readonly ttlMs: number
  readonly expiresAt: number
}

type JsonRecord = Record<string, unknown>

/**
 * 创建 AIHOT 引擎：匿名只读，无 key 分支；搜索走 `/api/v1/items` 的关键词检索。
 * 缓存与冷却挂在引擎实例上（v0.2 的 EngineHttp 实例级状态），不是跨进程限流器。
 */
export function createAihotEngine(options: AihotEngineOptions = {}): Engine {
  const cache = new Map<string, CachedItems>()
  let cooldown: { until: number; failure: EngineFailure } | undefined

  const search: SearchFn = async (request, ctx): Promise<EngineResult<EngineSearchOutcome>> => {
    const query = outgoingQuery(request)
    const length = [...query].length
    if (length < MIN_QUERY_CODE_POINTS || length > MAX_QUERY_CODE_POINTS) {
      return fail(engineFailure('invalid', {
        detail: `AIHOT 查询需 ${MIN_QUERY_CODE_POINTS}–${MAX_QUERY_CODE_POINTS} 个字符，实际 ${length}`,
      }))
    }
    if (ctx.signal.aborted) return fail(engineFailure('aborted', { detail: '操作已取消' }))

    const url = buildRequestUrl(options.endpointOverride ?? ctx.endpoint, query, request.maxResults)
    if (url === undefined) return fail(engineFailure('invalid', { detail: 'AIHOT 搜索端点无效' }))

    // 缓存命中优先于冷却（v0.2 cachedText 在进入 request() 前返回缓存），不发请求、不消耗预算。
    const cached = cache.get(url)
    if (cached !== undefined && cached.expiresAt > Date.now()) {
      return ok(toOutcome(cached.data, request.maxResults))
    }
    if (cooldown !== undefined && cooldown.until > Date.now()) return fail(cooldown.failure)

    try {
      const headers: Record<string, string> = {
        accept: 'application/json',
        'accept-encoding': 'gzip, br',
        'user-agent': 'dsh-web-search-fetch',
      }
      if (cached?.etag !== undefined) headers['if-none-match'] = cached.etag
      const response = await engineFetch(ctx, url, { method: 'GET', headers, fetcher: options.fetcher })
      const parsed = await readItems(response)
      if (typeof parsed === 'string') {
        return fail(engineFailure('provider-error', { statusCode: response.status, detail: clipDetail(parsed) }))
      }
      storeCache(url, parsed, response.headers, cached?.etag)
      return ok(toOutcome(parsed, request.maxResults))
    } catch (error) {
      // engineFetch 把 304 当作非 2xx 抛出；条件验证成功时复用已验证过的缓存数据。
      // 续期优先读 304 自身的 Cache-Control/ETag（v0.2 语义）；304 未给缓存指令时回退上次 200 的 TTL。
      if (error instanceof EngineHttpError && error.kind === 'http' && error.status === 304) {
        if (cached === undefined) {
          return fail(engineFailure('provider-error', { statusCode: 304, detail: 'AIHOT 返回 304 但无可复用缓存' }))
        }
        const control = error.headers?.get('cache-control') ?? ''
        const etag = error.headers?.get('etag') ?? cached.etag
        if (/\bno-store\b/i.test(control)) {
          cache.delete(url)
        } else {
          const ttlMs = cacheTtlMs(control, cached.ttlMs > 0 ? cached.ttlMs : DEFAULT_CACHE_TTL_MS)
          cache.set(url, {
            ...cached,
            expiresAt: Date.now() + ttlMs,
            ttlMs,
            ...(etag === undefined ? {} : { etag }),
          })
        }
        return ok(toOutcome(cached.data, request.maxResults))
      }
      return fail(projectFailure(error, ctx))
    }
  }

  /** 429/503 冷却 + 统一失败投影；503 是 AIHOT 上游的限流信号（v0.2 语义），不按 provider-error 处理。 */
  function projectFailure(error: unknown, ctx: EngineContext): EngineFailure {
    if (error instanceof EngineHttpError && error.kind === 'http') {
      const detail = problemDetail(error)
      if (error.status === 429 || error.status === 503) {
        const base = engineFailure('rate-limited', { statusCode: error.status, detail })
        // Retry-After 头缺失时用 Problem JSON 的 retryAfter（官方 OpenAPI：整数秒）作回退。
        const retryAfterMs = error.retryAfterMs ?? problemRetryAfterMs(error)
        const failure = retryAfterMs === undefined ? base : { ...base, retryAfterMs }
        cooldown = { until: Date.now() + (failure.retryAfterMs ?? DEFAULT_COOLDOWN_MS), failure }
        return failure
      }
      if (error.status === 402) {
        return engineFailure('quota', { statusCode: 402, detail, quotaExhausted: true })
      }
      // 401/403 也走 provider-error：AIHOT 是匿名引擎、没有凭证位，403 实际是策略/授权拒绝
      // （响应头 X-AIHOT-Commercial-Use），投影为 auth 会误导用户去配置不存在的 key（v0.2 语义）。
      return engineFailure('provider-error', { statusCode: error.status, detail })
    }
    const failure = projectHttpError(error)
    // engineFetch 已把单请求超时归为 timeout；这里保留 deadline 判据，把 deadline 到期时
    // 发生的真实网络失败也按 timeout 呈现（deadline 已过，重试无意义）。
    if (failure.kind === 'network' && Date.now() >= ctx.deadline) {
      return engineFailure('timeout', { statusCode: failure.statusCode, detail: failure.detail })
    }
    return failure
  }

  /** 200 响应：先解析校验再入缓存，畸形 JSON / 非法结构不会被缓存掩盖到过期。 */
  function storeCache(url: string, data: ParsedItems, headers: Headers, previousEtag?: string): void {
    const control = headers.get('cache-control') ?? ''
    if (/\bno-store\b/i.test(control)) {
      cache.delete(url)
      return
    }
    // v0.2 语义：200 不带 ETag 时保留旧 ETag，条件验证才不会退化成全量 GET。
    const etag = headers.get('etag') ?? previousEtag
    const ttlMs = cacheTtlMs(control)
    cache.delete(url)
    while (cache.size >= MAX_CACHE_ENTRIES) {
      const oldest = cache.keys().next()
      if (oldest.done) break
      cache.delete(oldest.value)
    }
    cache.set(url, {
      data,
      expiresAt: Date.now() + ttlMs,
      ttlMs,
      ...(etag === undefined ? {} : { etag }),
    })
  }

  /**
   * 热点榜（v0.4 hot-list 意图）：GET /api/v1/hot-topics，匿名，最多 10 条、官方按 rank 排序。
   * 契约（capability-aihot.json，实探 2026-11-07）：items[]{rank, id, title, source.name,
   * links{aihot, original?}, sourceCount, signalCount, latestAt}。官方建议轮询不高于每分钟一次
   * ——本能力仅由 hot-list 意图触达（低频），首版不设本地缓存；失败投影复用 projectFailure
   * （429/503 会进入引擎级冷却，与搜索路一致）。
   */
  const hotTopics: HotTopicsFn = async (ctx): Promise<EngineResult<EngineSearchOutcome>> => {
    if (ctx.signal.aborted) return fail(engineFailure('aborted', { detail: '操作已取消' }))
    const base = options.endpointOverride ?? ctx.endpoint ?? AIHOT_SITE
    let url: URL
    try {
      url = new URL('/api/v1/hot-topics', base)
    } catch {
      return fail(engineFailure('invalid', { detail: 'AIHOT 端点无效' }))
    }
    try {
      const response = await engineFetch(ctx, url.href, { method: 'GET', headers: { accept: 'application/json' }, fetcher: options.fetcher })
      const payload: unknown = await response.json()
      if (!isRecord(payload) || !Array.isArray(payload.items)) {
        return fail(engineFailure('provider-error', { statusCode: response.status, detail: 'AIHOT 热点榜响应缺少 items 数组' }))
      }
      const sources: EngineSearchSource[] = []
      for (const item of payload.items) {
        if (!isRecord(item)) continue
        const title = typeof item.title === 'string' ? item.title : ''
        const links = isRecord(item.links) ? item.links : undefined
        const original = links !== undefined && typeof links.original === 'string' ? links.original : undefined
        const aihot = links !== undefined && typeof links.aihot === 'string' ? links.aihot : undefined
        const href = original ?? aihot
        if (title.length === 0 || href === undefined) continue
        const latestAt = typeof item.latestAt === 'string' ? item.latestAt : undefined
        const sourceCount = typeof item.sourceCount === 'number' ? item.sourceCount : undefined
        sources.push({
          url: href,
          ...(title.length > 0 ? { title } : {}),
          ...(sourceCount !== undefined ? { snippet: `${sourceCount} 家来源共同报道` } : {}),
          ...(latestAt !== undefined ? { publishedAt: latestAt } : {}),
        })
      }
      if (sources.length === 0) {
        return fail(engineFailure('provider-error', { statusCode: response.status, detail: 'AIHOT 热点榜无可映射条目' }))
      }
      return ok({ sources, truncated: false })
    } catch (error) {
      return fail(projectFailure(error, ctx))
    }
  }

  return { manifest: AIHOT_MANIFEST, search, hotTopics }
}

/**
 * AIHOT 专用只读 API 路径白名单（v0.2 src/engines/additional/aihot.ts:8 原样）：
 * 只处理文档化的只读端点；人类页面与未知路径交由通用提取管线。
 */
const AIHOT_API_PATH = /^\/api\/v1\/(?:items|hot-topics|stories\/[\w-]{1,128}|codex-resets(?:\/recent)?|dailies(?:\/(?:latest|\d{4}-\d{2}-\d{2}))?|weeklies(?:\/(?:latest|\d{4}-W\d{2}))?|monthlies(?:\/(?:latest|\d{4}-\d{2}))?|selected\/(?:snapshot|changes)|agent(?:\/(?:latest|search|hot|stories\/[\w-]{1,128}|daily(?:\/\d{4}-\d{2}-\d{2})?|weekly(?:\/\d{4}-W\d{2})?|monthly(?:\/\d{4}-\d{2})?|codex-resets))?)$/

/** 专用 API 文本上限（v0.2）：不截断 JSON，否则会丢 nextCursor/removes；超限由调用方缩小 limit。 */
const MAX_API_TEXT_CHARS = 100_000
/** codex-resets 的默认轮询节奏（v0.2 十分钟），其余端点 60 秒。 */
const RESETS_CACHE_TTL_MS = 600_000

export interface AihotApiReaderOptions {
  /** 注入 fetcher（离线单测替身）；缺省全局 fetch。 */
  readonly fetcher?: typeof fetch
}

/**
 * 与 src/fetch/provider.ts:51-54 的 DedicatedApiReader 结构兼容。
 * AD2 禁止引擎层 import 提取层模块，故在此重复声明形状（字段与注释指向保持同步）。
 */
export interface AihotApiReader {
  readonly engineId: 'aihot'
  readApi(url: string, ctx: EngineContext): Promise<WebFetchResult | undefined>
}

interface ApiTarget {
  /** 规范化后的请求 URL（query 排序、去掉 hash）。 */
  readonly url: string
  /** 条件缓存键 = 规范化 URL。 */
  readonly key: string
  /** agent 面返回 Markdown，跳过 JSON 校验。 */
  readonly markdown: boolean
  /** 上游未给 Cache-Control 时的默认 TTL。 */
  readonly defaultTtlMs: number
}

interface CachedApiText {
  readonly content: string
  readonly etag?: string
  readonly ttlMs: number
  readonly expiresAt: number
}

/**
 * 创建 AIHOT 专用读取器：只接管文档化的 /api/v1/* 只读端点与 agent Markdown 面；
 * 其余 URL 返回 undefined，调用方继续通用提取。
 *
 * 失败约定（对照 src/fetch/provider.ts 的 DedicatedApiReader 与 WebFetchProvider 契约）：
 * - 上游非 2xx 是可表示的资源状态，Problem JSON 原样保留 code/requestId/retryAfter，
 *   收敛为对应 statusCode 的 WebFetchResult（不上抛）；429/503 另按 EngineFailure 分类冷却；
 * - 传输/校验类失败无法用 WebFetchResult 表示，上抛路由化的 WebError（provider 不 catch，
 *   由 seam 统一处理），裸异常不外泄。
 */
export function createAihotApiReader(options: AihotApiReaderOptions = {}): AihotApiReader {
  const cache = new Map<string, CachedApiText>()
  let cooldown: { until: number; statusCode: number; content: string } | undefined

  return {
    engineId: 'aihot',
    async readApi(rawUrl, ctx) {
      const target = apiTarget(rawUrl)
      if (target === undefined) return undefined

      // 缓存命中优先于冷却（v0.2 cachedText 在进入请求前返回缓存），不发请求、不消耗预算。
      const cached = cache.get(target.key)
      if (cached !== undefined && cached.expiresAt > Date.now()) {
        return apiTextResult(target.url, cached.content)
      }
      if (cooldown !== undefined && cooldown.until > Date.now()) {
        return apiTextResult(target.url, cooldown.content, cooldown.statusCode)
      }

      const headers: Record<string, string> = {
        accept: target.markdown ? 'text/markdown' : 'application/json, application/problem+json;q=0.9',
        'accept-encoding': 'gzip, br',
        'user-agent': 'dsh-web-search-fetch',
      }
      if (cached?.etag !== undefined) headers['if-none-match'] = cached.etag

      try {
        const response = await engineFetch(ctx, target.url, {
          method: 'GET',
          headers,
          ...(options.fetcher === undefined ? {} : { fetcher: options.fetcher }),
        })
        const content = await readApiContent(response, target.markdown)
        const control = response.headers.get('cache-control') ?? ''
        if (/\bno-store\b/i.test(control)) {
          cache.delete(target.key)
        } else {
          // v0.2 语义：200 不带 ETag 时保留旧 ETag，条件验证才不会退化成全量 GET。
          const etag = response.headers.get('etag') ?? cached?.etag
          const ttlMs = cacheTtlMs(control, target.defaultTtlMs)
          cache.delete(target.key)
          while (cache.size >= MAX_CACHE_ENTRIES) {
            const oldest = cache.keys().next()
            if (oldest.done) break
            cache.delete(oldest.value)
          }
          cache.set(target.key, {
            content,
            expiresAt: Date.now() + ttlMs,
            ttlMs,
            ...(etag === undefined ? {} : { etag }),
          })
        }
        return apiTextResult(target.url, content)
      } catch (error) {
        // 本读取器自产的 WebError（超限/格式/版本）原样上抛，不能被下面的网络投影降级。
        if (error instanceof WebError) throw error
        if (error instanceof EngineHttpError && error.kind === 'http') {
          // engineFetch 把 304 当作非 2xx 抛出；条件验证成功时复用已验证过的缓存。
          // 续期优先读 304 自身的 Cache-Control/ETag；未给缓存指令时回退上次 200 的 TTL。
          if (error.status === 304) {
            if (cached === undefined) {
              throw failureToWebError(engineFailure('provider-error', {
                statusCode: 304,
                detail: 'AIHOT 返回 304 但无可复用缓存',
              }))
            }
            const control = error.headers?.get('cache-control') ?? ''
            const etag = error.headers?.get('etag') ?? cached.etag
            if (/\bno-store\b/i.test(control)) {
              cache.delete(target.key)
            } else {
              const ttlMs = cacheTtlMs(control, cached.ttlMs > 0 ? cached.ttlMs : target.defaultTtlMs)
              cache.set(target.key, {
                ...cached,
                expiresAt: Date.now() + ttlMs,
                ttlMs,
                ...(etag === undefined ? {} : { etag }),
              })
            }
            return apiTextResult(target.url, cached.content)
          }
          const failure = problemFailure(error)
          const content = problemContent(error, failure)
          if (failure.kind === 'rate-limited') {
            cooldown = {
              until: Date.now() + (failure.retryAfterMs ?? DEFAULT_COOLDOWN_MS),
              statusCode: error.status ?? 0,
              content,
            }
          }
          return apiTextResult(target.url, content, error.status ?? 0)
        }
        throw failureToWebError(projectApiFailure(error, ctx))
      }
    },
  }
}

/** URL 分流：只接管 https://aihot.news/api/v1/<文档化路径>；其余返回 undefined 继续通用提取。 */
function apiTarget(rawUrl: string): ApiTarget | undefined {
  if (rawUrl.length > 8192) return undefined
  let url: URL
  try {
    url = new URL(rawUrl)
  } catch {
    return undefined
  }
  // 只认 aihot.news 的 /api/v1 面；人类页面（如 /items/xxx）交给通用提取。
  if (url.hostname !== 'aihot.news' || !url.pathname.startsWith('/api/v1/')) return undefined
  if (url.protocol !== 'https:' || url.username || url.password || url.port) return undefined
  if (!AIHOT_API_PATH.test(url.pathname)) return undefined
  url.hash = ''
  // 查询参数一律原样传递（含不透明 cursor），只做稳定排序作为缓存键。
  url.searchParams.sort()
  return {
    url: url.href,
    key: url.href,
    markdown: url.pathname.startsWith('/api/v1/agent'),
    defaultTtlMs: url.pathname.includes('/codex-resets') ? RESETS_CACHE_TTL_MS : DEFAULT_CACHE_TTL_MS,
  }
}

/** 读取 200 响应：agent Markdown 原样返回；JSON 端点校验版本后重新序列化（保留 null 与不透明 cursor）。 */
async function readApiContent(response: Response, markdown: boolean): Promise<string> {
  let text: string | undefined
  try {
    text = await readBoundedText(response, MAX_RESPONSE_BYTES)
  } catch (error) {
    // 中止/超时交给外层统一投影，不当作格式错误。
    if (isAbortError(error)) throw error
    throw apiFailure(`AIHOT 响应读取失败：${errorMessage(error)}`)
  }
  if (text === undefined) throw apiFailure(`AIHOT 响应超过 ${MAX_RESPONSE_BYTES} 字节上限`)
  if (text.trim().length === 0) throw apiFailure('AIHOT 响应为空')
  if (markdown) {
    assertApiTextSize(text)
    return text
  }
  let payload: unknown
  try {
    payload = JSON.parse(text)
  } catch (error) {
    throw apiFailure(`AIHOT 响应不是 JSON：${errorMessage(error)}`)
  }
  if (!isRecord(payload) || payload.schemaVersion !== 1) {
    throw apiFailure('AIHOT 响应版本无效（schemaVersion !== 1）')
  }
  const content = JSON.stringify(payload, null, 2)
  assertApiTextSize(content)
  return content
}

/** Problem JSON（application/problem+json）按官方 OpenAPI 契约投影为统一失败模型。 */
function problemFailure(error: EngineHttpError): EngineFailure {
  const status = error.status ?? 0
  const retryAfterMs = error.retryAfterMs ?? problemRetryAfterMs(error)
  const kind = status === 429 || status === 503 ? 'rate-limited' : status === 402 ? 'quota' : 'provider-error'
  return engineFailure(kind, {
    statusCode: status,
    detail: problemDetail(error),
    ...(retryAfterMs === undefined ? {} : { retryAfterMs }),
  })
}

/** 非 2xx 的响应文本：Problem JSON 原样保留（code/requestId/retryAfter 不丢），否则退回错误摘要。 */
function problemContent(error: EngineHttpError, failure: EngineFailure): string {
  if (isRecord(error.body)) return JSON.stringify(error.body, null, 2)
  return failure.detail ?? error.detail ?? `AIHOT 返回 HTTP ${error.status ?? 0}`
}

/** 传输类异常投影；deadline 到期时把真实 network 失败也改判 timeout（单请求超时已由 engineFetch 归为 timeout）。 */
function projectApiFailure(error: unknown, ctx: EngineContext): EngineFailure {
  const failure = projectHttpError(error)
  if (failure.kind === 'network' && Date.now() >= ctx.deadline) {
    return engineFailure('timeout', { statusCode: failure.statusCode, detail: failure.detail })
  }
  return failure
}

/** 统一失败模型 → seam 的 WEB_* 码（src/fetch/aggregate.ts failureFromThrown/failureWebCode 的等价物，AD2 不 import）。 */
function failureToWebError(failure: EngineFailure): WebError {
  const status = failure.statusCode === undefined ? '' : `（HTTP ${failure.statusCode}）`
  const detail = failure.detail === undefined ? failure.kind : failure.detail
  return new WebError(`AIHOT 专用 API：${detail}${status}`, failureWebCodeOf(failure))
}

function failureWebCodeOf(failure: EngineFailure): string {
  switch (failure.kind) {
    case 'invalid': return 'WEB_INVALID_URL'
    case 'timeout': return 'WEB_FETCH_TIMEOUT'
    case 'aborted': return 'WEB_ABORTED'
    default: return 'WEB_PROVIDER_ERROR'
  }
}

/** 校验类失败（读失败/空响应/非 JSON/版本不符）→ 路由化 WebError。 */
function apiFailure(detail: string): WebError {
  return failureToWebError(engineFailure('provider-error', { detail: clipDetail(detail) }))
}

/** 不截断 JSON：超过上限时明确失败，绝不把残包当成功结果。 */
function assertApiTextSize(content: string): void {
  if (content.length > MAX_API_TEXT_CHARS) {
    throw new WebError(
      `AIHOT 响应超过 ${MAX_API_TEXT_CHARS} 字符上限；请缩小 limit 后重试`,
      'WEB_FETCH_TOO_LARGE',
    )
  }
}

function apiTextResult(url: string, content: string, statusCode = 200): WebFetchResult {
  return { url, statusCode, body: { kind: 'text', content }, truncated: false }
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

/**
 * AD13 接线：items API 只有 q 一个检索参数，没有域名/日期/语言原生参数——
 * 解析出的操作符全部属于 unsupported，按 spec §10 规则用 operators[].raw 原样回拼进 q：
 * 大小写、路径后缀、出现顺序逐字保留，绝不静默丢弃，也不改写。
 * 发出查询 = bareQuery + ' ' + 全部操作符 raw（空段丢弃）；组合后为空则用 request.query 原文。
 * syntax 缺省（直接调用引擎的旧入口）时沿用 query.trim()，行为与接线前一致。
 * 回拼后若超过 q 的 2–200 码点约定，沿用既有长度校验（invalid、不发请求），不做静默截断。
 */
function outgoingQuery(request: EngineSearchRequest): string {
  const syntax = request.syntax
  if (syntax === undefined) return request.query.trim()
  // items API 无任何原生操作符参数：所有 operator 都 unsupported，按 raw 原样、原顺序回拼。
  const combined = [syntax.bareQuery, ...syntax.operators.map(operator => operator.raw)]
    .filter(segment => segment !== '')
    .join(' ')
  return combined === '' ? request.query : combined
}

function ok(outcome: EngineSearchOutcome): EngineResult<EngineSearchOutcome> {
  return { ok: true, outcome }
}

function fail(failure: EngineFailure): EngineResult<EngineSearchOutcome> {
  return { ok: false, failure }
}

/** 组装 `/api/v1/items` 请求 URL；端点非法返回 undefined（由调用方投影为 invalid）。 */
function buildRequestUrl(base: string, query: string, maxResults: number): string | undefined {
  let url: URL
  try {
    url = new URL(base)
  } catch {
    return undefined
  }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) return undefined
  url.hash = ''
  url.searchParams.set('mode', 'all')
  url.searchParams.set('window', '7d')
  url.searchParams.set('q', query)
  url.searchParams.set('limit', String(requestLimit(maxResults)))
  return url.toString()
}

/** v0.2 count(request, 100)：至少 1，最多 100。 */
function requestLimit(maxResults: number): number {
  const wanted = Number.isFinite(maxResults) ? Math.floor(maxResults) : 10
  return Math.max(1, Math.min(MAX_RESULTS_CAP, wanted))
}

/** 读取并校验 items 响应；返回字符串表示失败原因（不缓存）。 */
async function readItems(response: Response): Promise<ParsedItems | string> {
  let text: string | undefined
  try {
    text = await readBoundedText(response, MAX_RESPONSE_BYTES)
  } catch (error) {
    // 中止/超时交给外层统一投影，不当作格式错误。
    if (isAbortError(error)) throw error
    return `AIHOT 响应读取失败：${error instanceof Error ? error.message : String(error)}`
  }
  if (text === undefined) return `AIHOT 响应超过 ${MAX_RESPONSE_BYTES} 字节上限`
  let payload: unknown
  try {
    payload = JSON.parse(text)
  } catch (error) {
    return `AIHOT 响应不是 JSON：${error instanceof Error ? error.message : String(error)}`
  }
  return parseItems(payload) ?? 'AIHOT 响应格式无效（schemaVersion/items/page.hasMore）'
}

/** 按字节上限读取响应体；超限返回 undefined（v0.2 readText 的 1MB 上限）。 */
async function readBoundedText(response: Response, maxBytes: number): Promise<string | undefined> {
  if (response.body === null) return ''
  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let bytes = 0
  let text = ''
  try {
    for (;;) {
      const { done, value } = await reader.read()
      if (done) return text + decoder.decode()
      bytes += value.byteLength
      if (bytes > maxBytes) return undefined
      text += decoder.decode(value, { stream: true })
    }
  } finally {
    void reader.cancel().catch(() => undefined)
    reader.releaseLock()
  }
}

/** 严格按 v0.2 adapters.ts 的 aihot 分支校验与映射；无 url 的条目在 seam 映射层过滤。 */
function parseItems(payload: unknown): ParsedItems | undefined {
  if (!isRecord(payload) || payload.schemaVersion !== 1) return undefined
  const page = payload.page
  if (!isRecord(page) || typeof page.hasMore !== 'boolean') return undefined
  const items = payload.items
  if (!Array.isArray(items)) return undefined

  const sources: EngineSearchSource[] = []
  for (const item of items) {
    if (!isRecord(item)) return undefined
    const links = item.links
    const publisher = item.source
    const attribution = item.attribution
    if (!isRecord(links) || !isRecord(publisher)) return undefined
    if (attribution !== undefined && !isRecord(attribution)) return undefined
    const source = toSource(
      links.original,
      item.title,
      buildSnippet(item, links, publisher, attribution),
      item.publishedAt,
    )
    if (source !== undefined) sources.push(source)
  }
  return { sources, hasMore: page.hasMore }
}

/** v0.2 摘要拼装：摘要 + 来源名 + AIHOT 链接 + 数据归属（保留 attribution，合规要求）。 */
function buildSnippet(
  item: JsonRecord,
  links: JsonRecord,
  publisher: JsonRecord,
  attribution: JsonRecord | undefined,
): string {
  const lines: string[] = []
  if (isText(item.summary)) lines.push(item.summary)
  if (isText(publisher.name)) lines.push(`来源：${publisher.name}`)
  lines.push(`AIHOT：${toSource(links.aihot, undefined)?.url ?? AIHOT_SITE}`)
  if (attribution !== undefined) {
    const name = isText(attribution.name) ? attribution.name : 'AIHOT'
    const url = toSource(attribution.url, undefined)?.url ?? AIHOT_SITE
    lines.push(`数据归属：${name} ${url}`)
  }
  return lines.join('\n')
}

/** seam source 必须有 http(s) URL；其余字段为空时省略（与 v0.2 source() 一致）。 */
function toSource(
  url: unknown,
  title: unknown,
  snippet?: unknown,
  publishedAt?: unknown,
): EngineSearchSource | undefined {
  if (typeof url !== 'string') return undefined
  try {
    if (!['http:', 'https:'].includes(new URL(url).protocol)) return undefined
  } catch {
    return undefined
  }
  const titleText = isText(title) ? title : undefined
  const snippetText = isText(snippet) ? snippet : undefined
  const publishedText = isText(publishedAt) ? publishedAt : undefined
  return {
    url,
    ...(titleText === undefined ? {} : { title: titleText }),
    ...(snippetText === undefined ? {} : { snippet: snippetText }),
    ...(publishedText === undefined ? {} : { publishedAt: publishedText }),
  }
}

/** 结果截断按请求 maxResults 与上游 page.hasMore 两个来源取并（AD8：任一截断则 true）。 */
function toOutcome(parsed: ParsedItems, maxResults: number): EngineSearchOutcome {
  const limit = Number.isFinite(maxResults) ? Math.max(0, Math.floor(maxResults)) : parsed.sources.length
  return {
    sources: parsed.sources.slice(0, limit),
    truncated: parsed.hasMore || parsed.sources.length > limit,
  }
}

/** 缓存指令：no-cache 立即可重新验证；否则取 max-age 与 s-maxage 的较大值（s-maxage 是最小轮询间隔）。 */
function cacheTtlMs(control: string, fallbackMs = DEFAULT_CACHE_TTL_MS): number {
  if (/\bno-cache\b/i.test(control)) return 0
  const maxAge = readDirectiveSeconds(control, 'max-age')
  const sMaxAge = readDirectiveSeconds(control, 's-maxage')
  if (maxAge === undefined && sMaxAge === undefined) return fallbackMs
  return Math.max(maxAge ?? 0, sMaxAge ?? 0) * 1000
}

function readDirectiveSeconds(control: string, directive: string): number | undefined {
  const match = new RegExp(`(?:^|[,;\\s])${directive}=(\\d+)`, 'i').exec(control)
  return match === null ? undefined : Number(match[1])
}

/**
 * Problem JSON（application/problem+json）的稳定摘要：code/requestId 前置，避免被长度截断吃掉。
 * 官方 OpenAPI components.schemas.Problem：type/title/status/detail/code/requestId 必填。
 */
function problemDetail(error: EngineHttpError): string | undefined {
  const body = error.body
  if (!isRecord(body)) return error.detail
  const parts: string[] = []
  if (isText(body.code)) parts.push(`code=${body.code}`)
  if (isText(body.requestId)) parts.push(`requestId=${body.requestId}`)
  if (isText(body.detail)) parts.push(body.detail)
  else if (isText(body.title)) parts.push(body.title)
  const text = parts.join(' ')
  return text.length > 0 ? clipDetail(text) : error.detail
}

/** Problem JSON 的 retryAfter（官方 OpenAPI：整数秒，仅 429/503），作为 Retry-After 头的回退。 */
function problemRetryAfterMs(error: EngineHttpError): number | undefined {
  const body = error.body
  if (!isRecord(body)) return undefined
  const seconds = body.retryAfter
  return typeof seconds === 'number' && Number.isFinite(seconds) && seconds >= 0 ? seconds * 1000 : undefined
}

function isRecord(value: unknown): value is JsonRecord {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}

function isText(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0
}
