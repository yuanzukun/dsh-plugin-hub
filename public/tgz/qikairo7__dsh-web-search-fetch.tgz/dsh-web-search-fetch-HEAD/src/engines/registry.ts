// 引擎注册表——AD1 单一事实源：服务清单、端点、鉴权模式、额度端点只在这里出现一次。
// 设置面、客户端表、配置默认值、free 名单、凭证位全部从 ENGINES 派生；
// 契约依据：.scratch/dev-loop/recon/api-contracts/*.json（官方文档提取，2026-11-07）。
// v0.3 新增/变更：zhihu 新接入；id 沿用 v0.2（AD11：anysearch/tavily/firecrawl/aihot 不改名，
// firecrawl 显示名标 Firecrawl）；其余 v0.2 引擎按 spec §3.4 暂不注册。

import type { Engine, EngineManifest } from './contract.js'

export const ANYSEARCH_MANIFEST: EngineManifest = {
  id: 'anysearch',
  label: 'AnySearch AI',
  capabilities: ['search', 'fetch'],
  auth: 'keyless-fallback',
  credentialPath: 'anysearch',
  free: true,
  keyless: true,
  enabledByDefault: true,
  endpoints: {
    search: 'https://api.anysearch.com/v1/search',
    fetch: 'https://api.anysearch.com/v1/extract',
    // 契约研究：官方未提供额度端点（api-contracts/anysearch.json quota: 无）。
  },
}

export const TAVILY_MANIFEST: EngineManifest = {
  id: 'tavily',
  label: 'Tavily',
  capabilities: ['search', 'fetch'],
  auth: 'keyless-fallback',
  credentialPath: 'tavily',
  free: true,
  keyless: true,
  enabledByDefault: true,
  endpoints: {
    search: 'https://api.tavily.com/search',
    fetch: 'https://api.tavily.com/extract',
    quota: 'https://api.tavily.com/usage',
  },
}

export const FIRECRAWL_MANIFEST: EngineManifest = {
  id: 'firecrawl',
  label: 'Firecrawl',
  capabilities: ['search', 'fetch'],
  // v0.4.2：官方存在 keyless free tier——fetch（scrape）面可匿名调用；search 面受 IP 风控，
  // 无 key 必 403，所以免钥范围显式收窄到 fetch（keylessCapabilities），search 仍需 key。
  auth: 'keyless-fallback',
  credentialPath: 'firecrawl',
  free: true,
  keyless: true,
  keylessCapabilities: ['fetch'],
  enabledByDefault: true,
  endpoints: {
    search: 'https://api.firecrawl.dev/v2/search',
    fetch: 'https://api.firecrawl.dev/v2/scrape',
    quota: 'https://api.firecrawl.dev/v2/team/credit-usage',
  },
}

export const ZHIHU_MANIFEST: EngineManifest = {
  id: 'zhihu',
  label: '知乎',
  capabilities: ['search', 'fetch'],
  auth: 'key',
  credentialPath: 'zhihu',
  free: false,
  keyless: false,
  enabledByDefault: false,
  endpoints: {
    search: 'https://developer.zhihu.com/api/v1/content/global_search',
    // 提取面：问题回答读取（question_answers），仅处理 zhihu.com/question/* URL。
    fetch: 'https://developer.zhihu.com/api/v1/content/question_answers',
    // 站内搜索用同基地的 /api/v1/content/zhihu_search（适配层按查询意图选择）。
    quota: 'https://developer.zhihu.com/api/v1/quota',
  },
}

export const AIHOT_MANIFEST: EngineManifest = {
  id: 'aihot',
  label: 'AIHOT',
  capabilities: ['search', 'aihot-api'],
  auth: 'anonymous',
  free: true,
  keyless: true,
  enabledByDefault: true,
  endpoints: {
    // 真实搜索端点：GET /api/v1/items?mode=all&window=7d&q=&limit=（v0.2 adapters.ts aihot 分支；
    // docs/aihot.md 与 https://aihot.news/openapi-v1.json）。专用读取 API 属 aihot-api 能力面，本轮不注册。
    search: 'https://aihot.news/api/v1/items',
  },
}

/** 全部引擎清单，注册顺序即默认派发顺序。 */
export const ENGINE_MANIFESTS: readonly EngineManifest[] = [
  ANYSEARCH_MANIFEST,
  TAVILY_MANIFEST,
  FIRECRAWL_MANIFEST,
  ZHIHU_MANIFEST,
  AIHOT_MANIFEST,
]

/**
 * SiliconFlow 重排服务（不是搜索引擎，不进 ENGINE_MANIFESTS）：
 * 契约依据 api-contracts/siliconflow.json——POST /v1/rerank（BAAI/bge-reranker-v2-m3，
 * RPM 2000 / TPM 500k）；余额端点 /v1/user/info 已停用且无替代，
 * 额度呈现用 GET /v1/models 做密钥有效性校验（不伪造余额数字）。
 */
export const RERANK_SERVICE = {
  endpoint: 'https://api.siliconflow.cn/v1/rerank',
  modelsEndpoint: 'https://api.siliconflow.cn/v1/models',
  model: 'BAAI/bge-reranker-v2-m3',
  /** 融合后送重排的候选上限（TPM 安全预算：30 × ~500 token ≈ 15k « 500k）。 */
  topN: 30,
} as const

/** 注册表完整性（M0 测试将钉死）：manifest 声明的能力必须有对应适配函数。 */
export interface EngineRegistryDeps {
  readonly anysearch: Engine
  readonly tavily: Engine
  readonly firecrawl: Engine
  readonly zhihu: Engine
  readonly aihot: Engine
}

/** 组装完整引擎表；装配层（index）调用，适配函数在各自模块实现。 */
export function buildEngines(deps: EngineRegistryDeps): readonly Engine[] {
  const engines = [deps.anysearch, deps.tavily, deps.firecrawl, deps.zhihu, deps.aihot]
  const ids = new Set(engines.map(engine => engine.manifest.id))
  for (const manifest of ENGINE_MANIFESTS) {
    if (!ids.has(manifest.id)) throw new Error(`registry incomplete: missing engine ${manifest.id}`)
  }
  return engines
}
