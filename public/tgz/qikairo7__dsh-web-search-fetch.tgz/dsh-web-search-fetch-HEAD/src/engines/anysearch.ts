// AnySearch AI 引擎适配。
// 契约事实：
//   POST /v1/search  {query, max_results: 1..10} → envelope {code,message,request_id,data:{results:[{title,url,snippet?,content?}],metadata}}
//   POST /v1/extract {url}（请求体只允许该字段，上限 16 KiB）→ envelope {code,message,request_id,data:{url,title,content}}
// 鉴权：无 key → 匿名（不带 Authorization）；有 key → Bearer；账号模式 401/403 报 auth，绝不静默降级匿名。
// 额度：官方无公开额度查询端点，因此不实现 quota()。
// 目标站失败：提取错误体的业务 error_code 优先于 HTTP 状态（AnySearch 官方插件映射，recon/anysearch-official-plugin.md）：
//   extract_target_blocked → target-status（官方常随 403 返回，不能误判 auth）、invalid_extract_url → invalid、
//   extract_content_too_large / extract_unsupported_content → provider-error、extract_timeout → timeout、
//   extract_canceled → aborted。
// 无业务码时：HTTP 400（URL/请求体非法）→ invalid；HTTP 422（extract_failed）→ target-status（statusCode 必填）。

import type {
  Engine,
  EngineContext,
  EngineFetchOutcome,
  EngineResult,
  EngineSearchOutcome,
  EngineSearchRequest,
  EngineSearchSource,
  VerticalRequest,
} from './contract.js'
import { MAX_MODEL_SUMMARY_CHARS } from './contract.js'
import { clipDetail, engineFailure, type EngineFailure, type EngineFailureKind } from './failure.js'
import { EngineHttpError, engineJson, projectHttpError } from './http.js'
import { ANYSEARCH_MANIFEST } from './registry.js'

/** 上游 search 的 max_results 硬上限（契约范围 1–10）。 */
const MAX_SEARCH_RESULTS = 10
/** /v1/extract 请求体上限（契约：未知/重复字段会被拒绝，16 KiB）。 */
const MAX_EXTRACT_BODY_BYTES = 16 * 1024
/** /v1/extract 返回正文上限（契约：50,000 Unicode 字符）。 */
const EXTRACT_CONTENT_LIMIT = 50_000
/** HTML/纯文本被截断时上游插入的标记（契约）。 */
const EXTRACT_TRUNCATION_MARKER = '...(content truncated)'
/**
 * extract 业务 error_code → 统一失败 kind（AnySearch 官方插件映射表照抄，MIT）。
 * 仅覆盖官方列出的六个 extract 码，其余业务码回落 HTTP 状态投影；查表大小写不敏感。
 * error_code 优先于 HTTP 状态：extract_target_blocked 官方随 403 返回，按状态会被误判成 auth。
 */
const EXTRACT_ERROR_CODE_KINDS: Readonly<Record<string, EngineFailureKind>> = {
  invalid_extract_url: 'invalid',
  extract_target_blocked: 'target-status',
  extract_content_too_large: 'provider-error',
  extract_unsupported_content: 'provider-error',
  extract_timeout: 'timeout',
  extract_canceled: 'aborted',
}

/** 按操作覆盖请求 URL；search 与 extract 端点不同，必须分开，避免一个操作静默发到另一个端点。 */
export interface AnysearchEndpointOverride {
  readonly search?: string
  readonly fetch?: string
}

export interface AnysearchEngineOptions {
  /** fetch 注入口：离线单测替身用；缺省全局 fetch。 */
  readonly fetcher?: typeof fetch
  /** 按操作覆盖请求 URL；只影响本引擎发出的请求，不修改 manifest。 */
  readonly endpointOverride?: AnysearchEndpointOverride
  /** 垂直与通用搜索共用的区域选择：设置后写进每个 search 请求体；缺省不发。 */
  readonly zone?: 'cn' | 'intl'
  /** 实时区域读取；每次 search 求值，优先于 zone。 */
  readonly resolveZone?: () => 'cn' | 'intl' | undefined
  /** 语言偏好默认值：syntax.language（lang: 操作符）优先于该默认（syntax 覆盖工厂）。 */
  readonly language?: string
}

/** 契约信封外层；code/message/request_id/data 为契约字段，error_code 可选。 */
interface Envelope {
  readonly code: number
  readonly message: string
  readonly request_id?: string
  readonly error_code?: string
  readonly data: unknown
}

/** 适配层自有的响应形状错误：映射为 provider-error，而不是 network。 */
class WireError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'WireError'
  }
}

export function createAnysearchEngine(options: AnysearchEngineOptions = {}): Engine {
  return {
    manifest: ANYSEARCH_MANIFEST,
    search: (request, ctx) => runSearch(request, ctx, options),
    fetch: (url, ctx) => runExtract(url, ctx, options),
  }
}

async function runSearch(
  request: EngineSearchRequest,
  ctx: EngineContext,
  options: AnysearchEngineOptions,
): Promise<EngineResult<EngineSearchOutcome>> {
  const maxResults = clampMaxResults(request.maxResults)
  const input = searchInput(request, options)
  const vertical = verticalInput(request.vertical)
  const zone = options.resolveZone?.() ?? options.zone
  try {
    const payload = await engineJson<unknown>(ctx, requestUrl(ctx, 'search', options.endpointOverride?.search), {
      method: 'POST',
      headers: requestHeaders(ctx.apiKey),
      body: JSON.stringify({
        query: input.query,
        max_results: maxResults,
        ...(vertical === undefined
          ? {}
          : {
              tag: vertical.tag,
              ...(vertical.params === undefined ? {} : { params: vertical.params }),
            }),
        ...(zone === undefined ? {} : { zone }),
        ...(input.language === undefined ? {} : { language: input.language }),
      }),
      ...(options.fetcher === undefined ? {} : { fetcher: options.fetcher }),
    })
    const envelope = readEnvelope(payload)
    if (envelope.code !== 0) return { ok: false, failure: envelopeFailure(envelope, 'search') }
    const data = readRecord(envelope.data, 'data')
    const rawResults = readArray(data.results, 'data.results')
    const parsed = parseResults(rawResults, vertical !== undefined)
    return {
      ok: true,
      outcome: {
        sources: parsed.sources,
        // 上游 metadata.total_results 是匹配总数：大于实际返回条数即上游截断；缺失/非法时
        // 回退到保守规则——调用方要得比 10 多、上游又拿满 10 条。
        truncated: searchTruncated(request.maxResults, rawResults.length, readTotalResults(data.metadata)),
        ...(parsed.content === undefined ? {} : { content: parsed.content }),
      },
    }
  } catch (error) {
    return { ok: false, failure: projectFailure(error, 'search') }
  }
}

async function runExtract(
  url: string,
  ctx: EngineContext,
  options: AnysearchEngineOptions,
): Promise<EngineResult<EngineFetchOutcome>> {
  if (!isHttpUrl(url)) {
    return { ok: false, failure: engineFailure('invalid', { detail: '提取 URL 必须是绝对 http(s) 地址' }) }
  }
  const body = JSON.stringify({ url })
  if (new TextEncoder().encode(body).byteLength > MAX_EXTRACT_BODY_BYTES) {
    return { ok: false, failure: engineFailure('invalid', { detail: '提取请求体超过 16 KiB 上限' }) }
  }
  try {
    const payload = await engineJson<unknown>(ctx, requestUrl(ctx, 'fetch', options.endpointOverride?.fetch), {
      method: 'POST',
      headers: requestHeaders(ctx.apiKey),
      body,
      ...(options.fetcher === undefined ? {} : { fetcher: options.fetcher }),
    })
    const envelope = readEnvelope(payload)
    if (envelope.code !== 0) return { ok: false, failure: envelopeFailure(envelope, 'extract') }
    const data = readRecord(envelope.data, 'data')
    const content = readString(data.content, 'data.content')
    // 契约说 data.url 是提交的原始 URL（含重定向后）；上游若给出相对/非 http(s) 脏值，
    // 回退到输入 URL，绝不把不可引用地址透传给 seam。
    const returnedUrl = typeof data.url === 'string' && isHttpUrl(data.url) ? data.url : url
    return {
      ok: true,
      outcome: {
        url: returnedUrl,
        statusCode: 200,
        // 上游返回已清洗正文（可能是 HTML/纯文本/JSON/Markdown）；标 text 避免宿主再转换一次。
        body: { kind: 'text', content },
        // 契约没有独立截断标志：HTML/纯文本有标记；JSON/Markdown 直接保留前 50,000 字符。
        // 恰好 50,000 字符时无法区分「完整」与「截断」，按完整处理避免误报；仅超出上限才必然截断。
        truncated: content.includes(EXTRACT_TRUNCATION_MARKER) || content.length > EXTRACT_CONTENT_LIMIT,
      },
    }
  } catch (error) {
    return { ok: false, failure: projectFailure(error, 'extract') }
  }
}

/** 契约范围 1–10；调用方给得更大时截到 10，给得非正数时抬到 1。 */
function clampMaxResults(requested: number): number {
  if (!Number.isFinite(requested)) return MAX_SEARCH_RESULTS
  return Math.max(1, Math.min(MAX_SEARCH_RESULTS, Math.floor(requested)))
}

/**
 * 查询语法映射：AnySearch 只认请求体的 language 原生字段；site/-site/after/before
 * 没有原生参数，按 operators[].raw 逐字、按出现顺序回拼在 bareQuery 之后（大小写、
 * 路径后缀、顺序都不改写），绝不静默丢弃。回拼结果为空（例如查询只有 lang:）时退回
 * request.query 原文，避免发出空查询。syntax 缺省时完全沿用调用方原文，行为与接线前一致。
 * language 优先级：syntax.language（lang: 操作符）> 工厂默认 options.language。
 */
function searchInput(
  request: EngineSearchRequest,
  options: AnysearchEngineOptions,
): { query: string; language?: string } {
  const syntax = request.syntax
  if (syntax === undefined) {
    return {
      query: request.query,
      ...(options.language === undefined ? {} : { language: options.language }),
    }
  }
  const unsupported = syntax.operators.filter(operator => operator.kind !== 'lang').map(operator => operator.raw)
  const combined = [syntax.bareQuery, ...unsupported].filter(part => part.length > 0).join(' ')
  const language = syntax.language ?? options.language
  return {
    query: combined.length > 0 ? combined : request.query,
    ...(language === undefined ? {} : { language }),
  }
}

/**
 * 垂直取数请求 → 请求体字段。tag 原样透传；params 只保留标量值
 * （string / 有限 number / boolean，官方契约的值域）。嵌套对象、数组、非有限数值
 * 等非法值键按字段剔除、合法键保留——引擎层没有「说明」通道，不能为个别脏值
 * 丢掉整个 vertical；tag 为空视为没有垂直请求，按通用搜索处理。
 */
function verticalInput(
  vertical: VerticalRequest | undefined,
): { tag: string; params?: Record<string, string | number | boolean> } | undefined {
  // 契约要求完整 {domain}.{sub_domain}；裸域名/空白 tag 按无垂直请求处理（发上游会 400）。
  if (vertical === undefined || !vertical.tag.includes('.') || vertical.tag.trim().length === 0) return undefined
  const params = sanitizeVerticalParams(vertical.params)
  return { tag: vertical.tag, ...(params === undefined ? {} : { params }) }
}

function sanitizeVerticalParams(params: unknown): Record<string, string | number | boolean> | undefined {
  if (typeof params !== 'object' || params === null || Array.isArray(params)) return undefined
  const kept: Record<string, string | number | boolean> = {}
  for (const [name, value] of Object.entries(params)) {
    if (
      typeof value === 'string' ||
      typeof value === 'boolean' ||
      (typeof value === 'number' && Number.isFinite(value))
    ) {
      kept[name] = value
    }
  }
  return Object.keys(kept).length > 0 ? kept : undefined
}

/**
 * search 的 truncated：metadata.total_results 是上游匹配总数，大于实际返回条数说明上游截断了。
 * 元数据缺失/非法时回退到保守规则（调用方要得比上游上限多、且上游拿满上限），避免无法判断时漏报。
 */
function searchTruncated(requested: number, returned: number, totalResults: number | undefined): boolean {
  if (totalResults !== undefined) return totalResults > returned
  return requested > MAX_SEARCH_RESULTS && returned >= MAX_SEARCH_RESULTS
}

/** metadata 是辅助字段：形状非法按缺失处理，不因元数据问题毁掉可用结果。 */
function readTotalResults(value: unknown): number | undefined {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return undefined
  const total = (value as Record<string, unknown>).total_results
  return typeof total === 'number' && Number.isInteger(total) && total >= 0 ? total : undefined
}

/**
 * 请求 URL：显式 endpointOverride 优先；否则用装配层按本次操作构造的 ctx.endpoint
 * （contract.ts：已应用用户覆盖）；两者都为空时回落 manifest（唯一事实源，禁止重抄端点）。
 */
function requestUrl(
  ctx: EngineContext,
  operation: 'search' | 'fetch',
  override: string | undefined,
): string {
  if (override !== undefined && override.length > 0) return override
  if (ctx.endpoint.length > 0) return ctx.endpoint
  const fallback = operation === 'search' ? ANYSEARCH_MANIFEST.endpoints.search : ANYSEARCH_MANIFEST.endpoints.fetch
  return fallback ?? ''
}

/** keyless-fallback：无 key 匿名（不带 Authorization）；有 key 才发 Bearer。 */
function requestHeaders(apiKey: string | undefined): Record<string, string> {
  const headers: Record<string, string> = { 'content-type': 'application/json' }
  const key = apiKey?.trim()
  if (key !== undefined && key.length > 0) headers.authorization = `Bearer ${key}`
  return headers
}

/** HTTP 200 但业务 code !== 0：引擎服务端错误，不是目标站状态。 */
function envelopeFailure(envelope: Envelope, operation: 'search' | 'extract'): EngineFailure {
  const facts = [`code=${envelope.code}`]
  if (envelope.error_code !== undefined) facts.push(`error_code=${envelope.error_code}`)
  if (envelope.request_id !== undefined) facts.push(`request_id=${envelope.request_id}`)
  return engineFailure('provider-error', {
    detail: clipDetail(`AnySearch ${operation} 错误信封（${facts.join(', ')}）：${envelope.message}`),
  })
}

/** 把 wire 层异常投影为统一失败模型；extract 的业务 error_code 优先于 HTTP 状态，402 正文按契约丢弃。 */
function projectFailure(error: unknown, operation: 'search' | 'extract'): EngineFailure {
  if (error instanceof WireError) {
    return engineFailure('provider-error', {
      detail: clipDetail(`AnySearch ${operation} 响应形状非法：${error.message}`),
    })
  }
  const extractFailure = extractErrorFailure(error, operation)
  if (extractFailure !== undefined) return extractFailure
  const failure = projectHttpError(error)
  if (failure.kind === 'quota') {
    // 契约安全要求：匿名 402 的 message 可能携带自动建号凭据，绝不写入失败详情/日志。
    return { ...failure, detail: 'AnySearch 额度耗尽（HTTP 402）；上游正文可能含凭据，已丢弃。' }
  }
  return failure
}

/**
 * extract 错误分类（官方映射表照抄，error_code 优先于 HTTP 状态）：
 * - 业务 error_code 命中官方映射 → 对应 kind；extract_target_blocked 常随 403 返回，不能误判 auth；
 * - HTTP 400 = URL/请求体非法（契约示例 error_code=invalid_extract_url）→ invalid；
 * - HTTP 422 = 提取失败（extract_failed）→ target-status，属于目标站失败而非引擎服务端错误。
 * 返回 undefined 时交给 projectHttpError 按状态投影（429/402/401/5xx 等）。
 */
function extractErrorFailure(error: unknown, operation: 'search' | 'extract'): EngineFailure | undefined {
  if (operation !== 'extract' || !(error instanceof EngineHttpError) || error.kind !== 'http') return undefined
  const errorCode = readEnvelopeString(error.body, 'error_code')
  // 查表大小写不敏感（上游可能返回大写业务码）；detail 仍保留原始码。
  const mappedKind = errorCode === undefined ? undefined : EXTRACT_ERROR_CODE_KINDS[errorCode.toLowerCase()]
  if (errorCode !== undefined && mappedKind !== undefined) {
    // 只带稳定字段（错误码/请求号），不回显上游 message：402 等错误正文可能含自动建号凭据。
    const facts = [`error_code=${errorCode}`]
    if (error.status !== undefined) facts.push(`HTTP ${error.status}`)
    const requestId = readEnvelopeString(error.body, 'request_id')
    if (requestId !== undefined) facts.push(`request_id=${requestId}`)
    return engineFailure(mappedKind, {
      statusCode: error.status,
      detail: clipDetail(`AnySearch extract 业务错误（${facts.join(', ')}）`),
    })
  }
  if (error.status === 400) {
    return engineFailure('invalid', { statusCode: 400, detail: error.detail })
  }
  if (error.status === 422) {
    return engineFailure('target-status', { statusCode: 422, detail: error.detail })
  }
  return undefined
}

/** 从解析后的错误响应体读字符串字段；错误信封是顶层对象（code/message/request_id/error_code）。 */
function readEnvelopeString(body: unknown, field: 'error_code' | 'request_id'): string | undefined {
  if (typeof body !== 'object' || body === null || Array.isArray(body)) return undefined
  const value = (body as Record<string, unknown>)[field]
  return typeof value === 'string' && value.length > 0 ? value : undefined
}

function readEnvelope(value: unknown): Envelope {
  const record = readRecord(value, 'response')
  if (typeof record.code !== 'number' || !Number.isFinite(record.code)) {
    throw new WireError('response.code 必须是有限数字')
  }
  return {
    code: record.code,
    message: typeof record.message === 'string' ? record.message : '',
    data: record.data,
    ...(typeof record.request_id === 'string' ? { request_id: record.request_id } : {}),
    ...(typeof record.error_code === 'string' ? { error_code: record.error_code } : {}),
  }
}

/** 搜索结果解析结果：sources 只含有引用链接的条目；content 承载无链接的结构化数据。 */
interface ParsedResults {
  readonly sources: EngineSearchSource[]
  readonly content?: string
}

/**
 * 结果解析（ADR-0001 §7）：URL 为绝对 http(s) 的条目进 sources；
 * 垂直请求下 url 缺省/为空串的合法条目是「无引用链接的结构化数据」，
 * 序列化进 outcome.content，不再静默丢弃，也不让上层误判为空结果。
 * 通用搜索保持旧语义：无 URL 条目照旧过滤。
 */
function parseResults(rawResults: readonly unknown[], vertical: boolean): ParsedResults {
  const sources: EngineSearchSource[] = []
  const structured: Record<string, unknown>[] = []
  for (const [index, value] of rawResults.entries()) {
    const item = readRecord(value, `data.results[${index}]`)
    if (vertical && hasNoUrl(item)) {
      structured.push(withoutEmptyUrl(item))
      continue
    }
    const source = parseSource(item, index)
    if (source !== undefined) sources.push(source)
  }
  return {
    sources,
    ...(structured.length === 0 ? {} : { content: formatStructuredData(structured) }),
  }
}

/** 契约：url 可缺省或为空串（实探垂直结构化结果 url 为 ""）；两者都算「无引用链接」。 */
function hasNoUrl(item: Record<string, unknown>): boolean {
  const url = item.url
  return url === undefined || url === null || (typeof url === 'string' && url.trim().length === 0)
}

/** 去掉空的 url 字段：这类条目本就没有引用链接，保留空字段只会制造噪音。 */
function withoutEmptyUrl(item: Record<string, unknown>): Record<string, unknown> {
  const { url: _url, ...rest } = item
  return rest
}

/** 结构化数据序列化：条目数前缀 + 紧凑 JSON（不展开上游 content 里的 JSON 字符串）。 */
function formatStructuredData(items: readonly Record<string, unknown>[]): string {
  return `结构化数据 ${items.length} 条（无引用链接）：${JSON.stringify(items)}`
}

/** 一条搜索结果：url 必须是绝对 http(s)，否则丢弃（结构性结果没有可引用 URL）。 */
function parseSource(item: Record<string, unknown>, index: number): EngineSearchSource | undefined {
  const url = readString(item.url, `data.results[${index}].url`)
  if (!isHttpUrl(url)) return undefined
  const title = typeof item.title === 'string' ? item.title.trim() : ''
  const snippet = typeof item.snippet === 'string' ? item.snippet.trim() : ''
  const content = typeof item.content === 'string' ? item.content.trim().slice(0, MAX_MODEL_SUMMARY_CHARS) : ''
  return {
    url,
    ...(title.length === 0 ? {} : { title }),
    ...(snippet.length === 0 ? {} : { snippet }),
    ...(content.length === 0 ? {} : { summary: content }),
  }
}

function readRecord(value: unknown, path: string): Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new WireError(`${path} 必须是对象`)
  }
  return value as Record<string, unknown>
}

function readArray(value: unknown, path: string): unknown[] {
  if (!Array.isArray(value)) throw new WireError(`${path} 必须是数组`)
  return value
}

function readString(value: unknown, path: string): string {
  if (typeof value !== 'string') throw new WireError(`${path} 必须是字符串`)
  return value
}

function isHttpUrl(value: string): boolean {
  try {
    const url = new URL(value)
    return url.protocol === 'http:' || url.protocol === 'https:'
  } catch {
    return false
  }
}
