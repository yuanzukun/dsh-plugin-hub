// AIHOT items 请求组装、响应解析与通用文本读取。

import type { EngineSearchRequest, EngineSearchSource } from './contract.js'
import { MAX_MODEL_SUMMARY_CHARS } from './contract.js'
import { isAbortError } from './failure.js'

const MAX_RESULTS_CAP = 100
const MAX_RESPONSE_BYTES = 1_000_000
const AIHOT_SITE = 'https://aihot.news'

export interface ParsedItems {
  readonly sources: readonly EngineSearchSource[]
  readonly hasMore: boolean
}

type JsonRecord = Record<string, unknown>

/**
 * AD13 接线：items API 只有 q 一个检索参数；全部操作符按 raw 原样回拼进 q。
 * syntax 缺省（直接调用引擎的旧入口）时沿用 query.trim()。
 */
export function outgoingQuery(request: EngineSearchRequest): string {
  const syntax = request.syntax
  if (syntax === undefined) return request.query.trim()
  const combined = [syntax.bareQuery, ...syntax.operators.map(operator => operator.raw)]
    .filter(segment => segment !== '')
    .join(' ')
  return combined === '' ? request.query : combined
}

/** 组装 `/api/v1/items` 请求 URL；端点非法返回 undefined。 */
export function buildRequestUrl(base: string, query: string, maxResults: number): string | undefined {
  let url: URL
  try {
    url = new URL(base)
  } catch {
    return undefined
  }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) return undefined
  url.hash = ''
  url.searchParams.set('mode', 'all')
  url.searchParams.set('window', '7d')
  url.searchParams.set('q', query)
  url.searchParams.set('limit', String(requestLimit(maxResults)))
  return url.toString()
}

/** v0.2 count(request, 100)：至少 1，最多 100。 */
function requestLimit(maxResults: number): number {
  const wanted = Number.isFinite(maxResults) ? Math.floor(maxResults) : 10
  return Math.max(1, Math.min(MAX_RESULTS_CAP, wanted))
}

/** 读取并校验 items 响应；返回字符串表示失败原因（不缓存）。 */
export async function readItems(response: Response): Promise<ParsedItems | string> {
  let text: string | undefined
  try {
    text = await readBoundedText(response, MAX_RESPONSE_BYTES)
  } catch (error) {
    if (isAbortError(error)) throw error
    return `AIHOT 响应读取失败：${error instanceof Error ? error.message : String(error)}`
  }
  if (text === undefined) return `AIHOT 响应超过 ${MAX_RESPONSE_BYTES} 字节上限`
  let payload: unknown
  try {
    payload = JSON.parse(text)
  } catch (error) {
    return `AIHOT 响应不是 JSON：${error instanceof Error ? error.message : String(error)}`
  }
  return parseItems(payload) ?? 'AIHOT 响应格式无效（schemaVersion/items/page.hasMore）'
}

/** 按字节上限读取响应体；超限返回 undefined。 */
export async function readBoundedText(response: Response, maxBytes: number): Promise<string | undefined> {
  if (response.body === null) return ''
  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let bytes = 0
  let text = ''
  try {
    for (;;) {
      const { done, value } = await reader.read()
      if (done) return text + decoder.decode()
      bytes += value.byteLength
      if (bytes > maxBytes) return undefined
      text += decoder.decode(value, { stream: true })
    }
  } finally {
    void reader.cancel().catch(() => undefined)
    reader.releaseLock()
  }
}

/** 严格按 v0.2 adapters.ts 的 aihot 分支校验与映射；无 url 的条目在 seam 映射层过滤。 */
function parseItems(payload: unknown): ParsedItems | undefined {
  if (!isRecord(payload) || payload.schemaVersion !== 1) return undefined
  const page = payload.page
  if (!isRecord(page) || typeof page.hasMore !== 'boolean') return undefined
  const items = payload.items
  if (!Array.isArray(items)) return undefined

  const sources: EngineSearchSource[] = []
  for (const item of items) {
    if (!isRecord(item)) return undefined
    const links = item.links
    const publisher = item.source
    const attribution = item.attribution
    if (!isRecord(links) || !isRecord(publisher)) return undefined
    if (attribution !== undefined && !isRecord(attribution)) return undefined
    const source = toSource(
      links.original,
      item.title,
      buildSnippet(item, links, publisher, attribution),
      item.publishedAt,
      item.summary,
    )
    if (source !== undefined) sources.push(source)
  }
  return { sources, hasMore: page.hasMore }
}

/** v0.2 摘要拼装：摘要 + 来源名 + AIHOT 链接 + 数据归属。 */
function buildSnippet(
  item: JsonRecord,
  links: JsonRecord,
  publisher: JsonRecord,
  attribution: JsonRecord | undefined,
): string {
  const lines: string[] = []
  if (isText(item.summary)) lines.push(item.summary)
  if (isText(publisher.name)) lines.push(`来源：${publisher.name}`)
  lines.push(`AIHOT：${toSource(links.aihot, undefined)?.url ?? AIHOT_SITE}`)
  if (attribution !== undefined) {
    const name = isText(attribution.name) ? attribution.name : 'AIHOT'
    const url = toSource(attribution.url, undefined)?.url ?? AIHOT_SITE
    lines.push(`数据归属：${name} ${url}`)
  }
  return lines.join('\n')
}

/** seam source 必须有 http(s) URL；其余字段为空时省略。 */
function toSource(
  url: unknown,
  title: unknown,
  snippet?: unknown,
  publishedAt?: unknown,
  summary?: unknown,
): EngineSearchSource | undefined {
  if (typeof url !== 'string') return undefined
  try {
    if (!['http:', 'https:'].includes(new URL(url).protocol)) return undefined
  } catch {
    return undefined
  }
  const titleText = isText(title) ? title : undefined
  const snippetText = isText(snippet) ? snippet : undefined
  const publishedText = isText(publishedAt) ? publishedAt : undefined
  const summaryText = isText(summary) ? summary.slice(0, MAX_MODEL_SUMMARY_CHARS) : undefined
  return {
    url,
    ...(titleText === undefined ? {} : { title: titleText }),
    ...(snippetText === undefined ? {} : { snippet: snippetText }),
    ...(summaryText === undefined ? {} : { summary: summaryText }),
    ...(publishedText === undefined ? {} : { publishedAt: publishedText }),
  }
}

/** 结果截断按请求 maxResults 与上游 page.hasMore 取并。 */
export function toOutcome(parsed: ParsedItems, maxResults: number) {
  const limit = Number.isFinite(maxResults) ? Math.max(0, Math.floor(maxResults)) : parsed.sources.length
  return {
    sources: parsed.sources.slice(0, limit),
    truncated: parsed.hasMore || parsed.sources.length > limit,
  }
}

export function isRecord(value: unknown): value is JsonRecord {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}

export function isText(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0
}
