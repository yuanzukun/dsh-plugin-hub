// 引擎共享 HTTP 核心——v0.2 engines/additional/http.ts 的预算/超时/错误投影职责收敛于此（AD6）。
// 职责：请求前取预算许可（EngineContext.countRequest）、合成操作信号与单请求超时、
// 非 2xx 与网络错误投影为 EngineHttpError，供各引擎 wire 层用 projectHttpError 转成统一失败模型。
// 引擎特有协议知识（Tavily keyless 头、知乎时间戳头、AIHOT 503 冷却）留在各引擎适配文件，不进这里。

import type { EngineContext } from './contract.js'
import { clipDetail, engineFailure, isAbortError, type EngineFailure } from './failure.js'

/** 引擎 HTTP 层错误：wire 层唯一需要识别的异常类型。 */
export class EngineHttpError extends Error {
  constructor(
    readonly kind: 'budget' | 'aborted' | 'http' | 'network' | 'timeout' | 'parse',
    readonly status?: number,
    readonly detail?: string,
    readonly retryAfterMs?: number,
    /** 非 2xx 响应体（有界读取后）可解析为 JSON 时的解析值：业务错误码（anysearch error_code、知乎 Code、tavily failed_results）从这里取；超限或非 JSON 时为 undefined。 */
    readonly body?: unknown,
    /** 非 2xx 响应头：304 条件缓存需要读 304 自身的 Cache-Control/ETag。 */
    readonly headers?: Headers,
  ) {
    super(detail ?? kind)
    this.name = 'EngineHttpError'
  }
}

/** detail 只保留这么多字符：足够诊断，不吞内存。 */
const MAX_ERROR_BODY = 2048
/** 错误响应体最多读这么多字节再解析：超大错误页不整包进内存，超限部分只用于 detail 的前 2048 字符。 */
const MAX_ERROR_BODY_READ = 64 * 1024

export interface EngineFetchInit extends Omit<RequestInit, 'signal'> {
  /** 单请求超时；缺省取「30s 与操作剩余 deadline 的较小者」。 */
  readonly timeoutMs?: number
  /** fetch 注入口：离线单测替身用；缺省全局 fetch。 */
  readonly fetcher?: typeof fetch
}

/**
 * 引擎拥有的 HTTP 请求：预算许可 → 信号合成（操作信号 + 单请求超时）→ fetch。
 * redirect 固定 'error'（v0.2 budgetedFetch 语义）：引擎 API 不应重定向。
 */
export async function engineFetch(ctx: EngineContext, url: string, init: EngineFetchInit = {}): Promise<Response> {
  if (!ctx.countRequest()) throw new EngineHttpError('budget', undefined, '请求预算已用尽，该请求未发出')
  const fetcher = init.fetcher ?? fetch
  const timeoutMs = init.timeoutMs ?? Math.max(1, Math.min(30_000, ctx.deadline - Date.now()))
  const signal = AbortSignal.any([AbortSignal.timeout(timeoutMs), ctx.signal])
  let response: Response
  try {
    response = await fetcher(url, { ...init, redirect: 'error', signal })
  } catch (error) {
    if (isAbortError(error)) {
      throw ctx.signal.aborted
        ? new EngineHttpError('aborted', undefined, '操作已取消')
        : new EngineHttpError('timeout', undefined, `请求超时（${timeoutMs}ms）`)
    }
    throw new EngineHttpError('network', undefined, clipDetail(error instanceof Error ? error.message : String(error)))
  }
  if (!response.ok) {
    // detail 用于诊断（限长）；body 只在有界读取的响应体可解析为 JSON 时保留，供 wire 层取业务错误码。
    const text = await readErrorBody(response)
    let parsedBody: unknown
    if (text.length > 0) {
      try { parsedBody = JSON.parse(text) } catch { parsedBody = undefined }
    }
    const retryAfter = readRetryAfterMs(response.headers.get('retry-after'))
    throw new EngineHttpError(
      'http',
      response.status,
      clipDetail(text.slice(0, MAX_ERROR_BODY)),
      retryAfter,
      parsedBody,
      response.headers,
    )
  }
  return response
}

/**
 * 有界读取错误响应体：最多 MAX_ERROR_BODY_READ 字节。
 * 读取被截断时 JSON.parse 会失败、body 为 undefined——按「错误体超限只保留 detail」处理，
 * 不让超大错误页整包驻留内存。
 */
async function readErrorBody(response: Response): Promise<string> {
  if (response.body === null) return ''
  const reader = response.body.getReader()
  const chunks: Uint8Array[] = []
  let total = 0
  try {
    while (total < MAX_ERROR_BODY_READ) {
      const { done, value } = await reader.read()
      if (done) break
      if (value === undefined || value.byteLength === 0) continue
      const remaining = MAX_ERROR_BODY_READ - total
      if (value.byteLength > remaining) {
        chunks.push(value.subarray(0, remaining))
        total += remaining
        break
      }
      chunks.push(value)
      total += value.byteLength
    }
  } catch {
    // 读错误体失败不掩盖原始 HTTP 失败：按已读到的字节尽力诊断。
  } finally {
    await reader.cancel().catch(() => undefined)
  }
  const bytes = new Uint8Array(total)
  let offset = 0
  for (const chunk of chunks) {
    bytes.set(chunk, offset)
    offset += chunk.byteLength
  }
  return new TextDecoder().decode(bytes)
}

/** JSON 版：非 JSON 的 2xx 响应按 parse 错误处理。 */
export async function engineJson<T>(ctx: EngineContext, url: string, init: EngineFetchInit = {}): Promise<T> {
  const response = await engineFetch(ctx, url, init)
  try {
    return await response.json() as T
  } catch (error) {
    throw new EngineHttpError('parse', response.status, clipDetail(`非 JSON 响应：${error instanceof Error ? error.message : String(error)}`))
  }
}

/**
 * 把 wire 层异常投影为统一失败模型（AD6）。
 * 429 → rate-limited（带 Retry-After）；402 → quota（402 语义由 breakerSignalOf 转日级 insufficient-credits）；
 * 401/403 → auth；单请求超时 → timeout；其余非 2xx → provider-error（引擎 API 的 404/422 是请求形状问题，不是目标站状态）。
 * 目标站状态（提取失败、目标 4xx）由各引擎从响应体内解析，不经此路径。
 */
export function projectHttpError(error: unknown): EngineFailure {
  if (!(error instanceof EngineHttpError)) {
    if (isAbortError(error)) return engineFailure('aborted')
    return engineFailure('network', { detail: clipDetail(error instanceof Error ? error.message : String(error)) })
  }
  switch (error.kind) {
    case 'budget':
    case 'aborted':
      return engineFailure('aborted', { detail: error.detail })
    case 'network':
      return engineFailure('network', { detail: error.detail })
    case 'timeout':
      return engineFailure('timeout', { detail: error.detail })
    case 'parse':
      return engineFailure('provider-error', { detail: error.detail, statusCode: error.status })
    case 'http':
      switch (error.status) {
        case 429:
          return engineFailure('rate-limited', { statusCode: 429, detail: error.detail, retryAfterMs: error.retryAfterMs })
        case 402:
          return engineFailure('quota', { statusCode: 402, detail: error.detail, quotaExhausted: true })
        case 401:
        case 403:
          return engineFailure('auth', { statusCode: error.status, detail: error.detail })
        default:
          return engineFailure('provider-error', { statusCode: error.status, detail: error.detail })
      }
  }
}

/** Retry-After 秒或 HTTP 日期 → 毫秒；不可解析返回 undefined。 */
function readRetryAfterMs(header: string | null): number | undefined {
  if (header === null) return undefined
  const seconds = Number(header)
  if (Number.isFinite(seconds) && seconds >= 0) return seconds * 1000
  const date = Date.parse(header)
  return Number.isFinite(date) ? Math.max(0, date - Date.now()) : undefined
}
