// 统一失败模型——全仓唯一的引擎失败词表。
// 统一失败词表避免各引擎私有错误枚举泄漏到编排层；同一个 HTTP 状态在不同引擎必须按
// 实际语义得到同一类失败，而不是由适配器各自命名。
// 每引擎 wire 层把 HTTP/SDK 错误投影到本模型；aggregate、breaker、呈现层只认本模型；
//           编排层禁止 import 任何引擎专用错误类型。

export type EngineFailureKind =
  /** 429 / 限流：短冷却后可重试。 */
  | 'rate-limited'
  /** 额度耗尽（402、quota remaining=0）：日级熔断，设置页额度区高亮。 */
  | 'quota'
  /** 引擎调用超时（引擎级 timeout 或操作 deadline 到期）。 */
  | 'timeout'
  /** 目标站返回非 2xx。fetch 语义里这是「结果」不是「错误」（seam 契约），仅在搜索侧/探测失败时作为失败上报。 */
  | 'target-status'
  /** 引擎服务端错误：5xx、引擎 envelope 内嵌 error。 */
  | 'provider-error'
  /** 凭证缺失或失效。keyless-fallback 引擎仅在「配置了 key 但 key 无效」时报 auth，不静默降级匿名。 */
  | 'auth'
  /** 网络层失败：DNS、连接被拒、TLS、连接中断。 */
  | 'network'
  /** 主动取消：宽限期结束、操作总限时、用户取消。 */
  | 'aborted'
  /** 引擎判定的输入非法（URL 不在适用范围、查询为空等）。 */
  | 'invalid'

export interface EngineFailure {
  readonly kind: EngineFailureKind
  /** HTTP 状态码（有则填；target-status 必填）。 */
  readonly statusCode?: number
  /** 引擎侧原始错误摘要，限长后进日志与操作说明。 */
  readonly detail?: string
  /** 该失败是否应计入熔断/冷却（rate-limited、quota、provider-error、network 通常 true；aborted、invalid 恒 false）。 */
  readonly cooldownable: boolean
  /** quota 专用：remaining<=0 的明确信号，熔断器据此做日级熔断。 */
  readonly quotaExhausted?: boolean
  /** rate-limited 专用：Retry-After 毫秒提示，熔断器冷却时长的依据。 */
  readonly retryAfterMs?: number
}

export function engineFailure(kind: EngineFailureKind, opts: Partial<Omit<EngineFailure, 'kind'>> = {}): EngineFailure {
  return {
    kind,
    statusCode: opts.statusCode,
    detail: opts.detail,
    cooldownable: opts.cooldownable ?? defaultCooldownable(kind),
    quotaExhausted: opts.quotaExhausted,
    retryAfterMs: opts.retryAfterMs,
  }
}

function defaultCooldownable(kind: EngineFailureKind): boolean {
  switch (kind) {
    case 'rate-limited':
    case 'quota':
    case 'provider-error':
    case 'network':
      return true
    case 'timeout':
      return true
    case 'target-status':
      // 目标站状态不是引擎的错：不冷却引擎本身。
      return false
    case 'auth':
    case 'aborted':
    case 'invalid':
      return false
  }
}

/** 识别「请求被中止」的底层信号（AbortError / DOMException），供 wire 层统一投影为 aborted/timeout。 */
export function isAbortError(error: unknown): boolean {
  if (!(error instanceof Error)) return false
  return error.name === 'AbortError' || error.name === 'TimeoutError'
}

/** detail 限长：进操作说明与日志的引擎原始错误统一截断。 */
export function clipDetail(text: string, max = 300): string {
  return text.length <= max ? text : `${text.slice(0, max)}…`
}
