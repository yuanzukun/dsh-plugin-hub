export interface ApiTarget {
  readonly url: string
  readonly key: string
  readonly markdown: boolean
  readonly defaultTtlMs: number
}

const AIHOT_API_PATH = /^\/api\/v1\/(?:items|hot-topics|stories\/[\w-]{1,128}|codex-resets(?:\/recent)?|dailies(?:\/(?:latest|\d{4}-\d{2}-\d{2}))?|weeklies(?:\/(?:latest|\d{4}-W\d{2}))?|monthlies(?:\/(?:latest|\d{4}-\d{2}))?|selected\/(?:snapshot|changes)|agent(?:\/(?:latest|search|hot|stories\/[\w-]{1,128}|daily(?:\/\d{4}-\d{2}-\d{2})?|weekly(?:\/\d{4}-W\d{2})?|monthly(?:\/\d{4}-\d{2})?|codex-resets))?)$/
const RESETS_CACHE_TTL_MS = 600_000

export const DEFAULT_CACHE_TTL_MS = 60_000

/** 只接管文档化的 https://aihot.news/api/v1/* 只读端点。 */
export function apiTarget(rawUrl: string): ApiTarget | undefined {
  if (rawUrl.length > 8192) return undefined
  let url: URL
  try {
    url = new URL(rawUrl)
  } catch {
    return undefined
  }
  if (url.hostname !== 'aihot.news' || !url.pathname.startsWith('/api/v1/')) return undefined
  if (url.protocol !== 'https:' || url.username || url.password || url.port) return undefined
  if (!AIHOT_API_PATH.test(url.pathname)) return undefined
  url.hash = ''
  url.searchParams.sort()
  return {
    url: url.href,
    key: url.href,
    markdown: url.pathname.startsWith('/api/v1/agent'),
    defaultTtlMs: url.pathname.includes('/codex-resets') ? RESETS_CACHE_TTL_MS : DEFAULT_CACHE_TTL_MS,
  }
}
