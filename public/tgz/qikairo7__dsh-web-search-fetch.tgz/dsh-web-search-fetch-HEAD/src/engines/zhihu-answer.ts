// 知乎直答（OpenAI 兼容 chat/completions）：请求构造、响应解析与 fail-open。
// 官方文档（只保证 model/messages/stream 三个字段语义）：https://developer.zhihu.com/docs?key=zhida

import type { EngineContext, EngineSearchRequest } from './contract.js'
import { engineJson } from './http.js'
import { ZHIHU_MANIFEST } from './registry.js'
import { authHeaders, withPath, type ZhihuEngineOptions } from './zhihu-shared.js'

/** 直答与 /api/v1/content 不同路径前缀，同源不同基地。 */
const ZHIDA_PATH = '/v1/chat/completions'

/** 直答模型档位：快速回答；v0.4 只用这一档（另有 thinking/agent，不接）。 */
const ZHIDA_MODEL = 'zhida-fast-1p5'

/** 直答非流式响应（OpenAI chat 兼容）：只读 choices[0].message.content。 */
interface ZhidaResponse {
  readonly choices?: readonly { readonly message?: { readonly content?: string } }[]
  /** OpenAI 风格错误（官方文档：失败时返回 error 对象）：存在即视为失败。 */
  readonly error?: unknown
}

/** 直答 URL：与搜索同源，路径固定为 OpenAI 兼容的 /v1/chat/completions。 */
function answerUrl(ctx: EngineContext, options: ZhihuEngineOptions): URL {
  const base = options.endpointOverride ?? (ctx.endpoint !== '' ? ctx.endpoint : (ZHIHU_MANIFEST.endpoints.search ?? ''))
  return withPath(base, ZHIDA_PATH)
}

/**
 * 调直答并返回文本。fail-open：网络错、HTTP 4xx/5xx、超时、预算耗尽、OpenAI 风格 error、
 * 空 choices/空 content 一律返回 undefined，不向调用方抛错，也不产生额外 note。
 * 预算由 engineJson → engineFetch 统一记账（每个 HTTP 请求一次 countRequest）。
 */
export async function requestAnswer(
  apiKey: string,
  request: EngineSearchRequest,
  ctx: EngineContext,
  options: ZhihuEngineOptions,
): Promise<string | undefined> {
  try {
    const url = answerUrl(ctx, options)
    const payload = await engineJson<ZhidaResponse>(ctx, url.href, {
      method: 'POST',
      fetcher: options.fetcher,
      headers: authHeaders(apiKey),
      body: JSON.stringify({
        model: ZHIDA_MODEL,
        messages: [{ role: 'user', content: request.query.trim() }],
        stream: false,
      }),
    })
    if (payload.error !== undefined) return undefined
    const content = payload.choices?.[0]?.message?.content
    return typeof content === 'string' && content.trim() !== '' ? content : undefined
  } catch {
    // 直答只是搜索的附加答案：失败静默跳过，不影响搜索结果。
    return undefined
  }
}
