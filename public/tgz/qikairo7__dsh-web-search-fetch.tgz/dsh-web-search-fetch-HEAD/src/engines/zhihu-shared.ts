// 知乎适配公共小件：鉴权头、URL 路径换算、字段取值与 envelope 错误映射。
// 直答与热榜拆分后共用；协议依据同 zhihu.ts 头部注释
// （.scratch/dev-loop/recon/api-contracts/zhihu.json 与官方文档 developer.zhihu.com）。

import { clipDetail, engineFailure, type EngineFailure } from './failure.js'

/** 只声明映射用到的字段，其余字段按契约保留不读（不编造契约外字段名）。 */
export interface ZhihuEnvelope<T> {
  readonly Code?: number
  readonly Message?: string
  readonly Data?: T
}

export interface ZhihuEngineOptions {
  /** fetch 注入口：离线单测替身用；缺省全局 fetch（经 engineJson 透传）。 */
  readonly fetcher?: typeof fetch
  /** 覆盖请求 URL（本地替身服务器等）；只改请求地址，不改动 ZHIHU_MANIFEST。 */
  readonly endpointOverride?: string
  /** 直答开关：默认开；false 时即使 request.wantAnswer 为真也不调用（显式关闭）。 */
  readonly answer?: boolean
}

/** 契约要求的鉴权头；时间戳每次请求现取（服务端校验 ±10 分钟窗口）。 */
export function authHeaders(apiKey: string): Record<string, string> {
  return {
    'Authorization': `Bearer ${apiKey}`,
    'X-Request-Timestamp': String(Math.floor(Date.now() / 1000)),
    'Content-Type': 'application/json',
  }
}

/** 把端点换成 manifest 里登记的路径，保留 origin/端口。 */
export function withPath(endpoint: string, path: string): URL {
  const url = new URL(endpoint)
  url.pathname = path
  url.search = ''
  url.hash = ''
  return url
}

export function asText(value: unknown): string | undefined {
  return typeof value === 'string' && value !== '' ? value : undefined
}

export function asHttpUrl(value: unknown): string | undefined {
  const text = asText(value)
  if (text === undefined) return undefined
  try {
    const url = new URL(text)
    return url.protocol === 'http:' || url.protocol === 'https:' ? text : undefined
  } catch {
    return undefined
  }
}

/**
 * envelope 非成功码 → 失败，按契约错误码表映射（api-contracts/zhihu.json errors）：
 * 20001 鉴权失败 → auth、10001 参数错误 → invalid、30001 频率限制 → rate-limited、
 * 90001 内部错误及其余未知码 → provider-error。detail 保留原始 Code/Message。
 */
export function envelopeFailure(envelope: ZhihuEnvelope<unknown>): EngineFailure | undefined {
  if (envelope.Code === 0) return undefined
  const code = typeof envelope.Code === 'number' ? envelope.Code : undefined
  const message = typeof envelope.Message === 'string' ? envelope.Message : ''
  const detail = clipDetail(code === undefined ? '知乎 API 响应缺少 Code' : `知乎 API Code ${code}: ${message}`)
  switch (code) {
    case 20001:
      return engineFailure('auth', { detail })
    case 10001:
      return engineFailure('invalid', { detail })
    case 30001:
      return engineFailure('rate-limited', { detail })
    default:
      return engineFailure('provider-error', { detail })
  }
}
