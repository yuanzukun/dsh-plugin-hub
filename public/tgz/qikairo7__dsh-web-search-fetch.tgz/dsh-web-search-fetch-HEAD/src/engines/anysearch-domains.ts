// AnySearch 垂直能力目录，作为意图路由的领域发现缓存。
// 能力目录事实：
//   GET /v1/domains（未公开文档，官方插件 listDomains 在用）→ data.domains[{domain, description, sub_domain_count, ...}]
//   GET /v1/sub-domains?domain=a&domain=b（匿名可用，不消耗搜索额度）→
//     data.domains[{domain, description, sub_domains:[{sub_domain, description, params?}]}]
//   实探：缺 domain 返回 400，重复 domain 参数可用且不产生重复条目；先取领域清单再一次性展开 39 个子域。
// 契约：sub_domains[].params 是「参数名 → {description, required, sort_order}」的对象，可为空或缺省。
// 失败不缓存：listTags 拒绝，下一次调用重新拉取；并发调用共享同一次刷新。

/** AnySearch API 基址（与 registry 的 search/extract 端点同源）。 */
const ANYSEARCH_BASE_URL = 'https://api.anysearch.com'
/** 领域拓扑变化很慢（实探 topology_version=13）；默认缓存 24 小时。 */
const DEFAULT_TTL_MS = 24 * 60 * 60 * 1000

/** 一个垂直子域的标签与参数定义（tag 即 /v1/search 的 tag 字段）。 */
export interface SubDomainInfo {
  readonly tag: string
  readonly description: string
  readonly params: ReadonlyArray<{
    readonly name: string
    readonly description: string
    readonly required: boolean
  }>
}

/** 一次能力发现调用的预算与取消上下文（编排层按操作注入；缺省不限制）。 */
export interface DomainDiscoveryBudget {
  /** 调用方操作信号；与内部超时合并。 */
  readonly signal?: AbortSignal
  /** 每次网络请求写出前调用；返回 false 时立即放弃（不发起请求）。 */
  readonly countRequest?: () => boolean
}

/** 垂直 tag 校验结果：是否存在 + 缺失的必填参数名。 */
export interface VerticalTagVerdict {
  readonly exists: boolean
  readonly missingRequired: readonly string[]
}

export interface AnysearchDomainCatalogOptions {
  /** fetch 注入口：离线单测替身用；缺省全局 fetch。 */
  readonly fetcher?: typeof fetch
  /** API 基址；默认公网端点。可传实时 getter，配置更新后下一次请求生效。 */
  readonly baseUrl?: string | (() => string | undefined)
  /** 单个发现请求的超时（毫秒），默认 30s；防上游黑洞挂死搜索 deadline。 */
  readonly timeoutMs?: number
  /** 缓存有效期（毫秒），默认 24h；<=0 表示每次调用都重新拉取。 */
  readonly ttlMs?: number
  /** 时钟注入口：单测控制 TTL 用；缺省 Date.now。 */
  readonly now?: () => number
  /** 可选 API key：提供时发现请求带 Authorization: Bearer，缺省匿名（契约记录匿名可用）。 */
  readonly apiKey?: string
}

/**
 * 领域发现缓存：listTags 首次调用依次请求 /v1/domains 与 /v1/sub-domains，
 * 把 data.domains[].sub_domains[] 扁平化为 tag 列表并缓存 ttlMs。
 */
export class AnysearchDomainCatalog {
  private readonly fetcher: typeof fetch
  private readonly resolveBaseUrl: () => string
  private readonly timeoutMs: number
  private readonly ttlMs: number
  private readonly now: () => number
  private readonly apiKey: string | undefined
  private cached: { readonly baseUrl: string; readonly tags: readonly SubDomainInfo[]; readonly expiresAt: number } | undefined
  private inFlight: { readonly baseUrl: string; readonly promise: Promise<readonly SubDomainInfo[]> } | undefined

  constructor(options: AnysearchDomainCatalogOptions = {}) {
    this.fetcher = options.fetcher ?? fetch
    const configured = options.baseUrl
    const resolve = typeof configured === 'function' ? configured : () => configured
    // 空串与未设置等价，回退官方端点；getter 每次发现请求前求值。
    this.resolveBaseUrl = () => {
      const value = resolve()
      return value !== undefined && value.trim().length > 0 ? value : ANYSEARCH_BASE_URL
    }
    this.timeoutMs = options.timeoutMs ?? 30_000
    this.ttlMs = options.ttlMs ?? DEFAULT_TTL_MS
    this.now = options.now ?? (() => Date.now())
    this.apiKey = options.apiKey
  }

  /** 全部 {domain}.{sub_domain} 标签与参数定义；同一 baseUrl 的 TTL 内直接复用缓存。 */
  listTags(budget: DomainDiscoveryBudget = {}): Promise<readonly SubDomainInfo[]> {
    const baseUrl = this.resolveBaseUrl()
    const cached = this.cached
    if (cached !== undefined && cached.baseUrl === baseUrl && this.now() < cached.expiresAt) {
      return Promise.resolve(cached.tags)
    }
    // 同一 baseUrl 的并发调用共享同一次刷新；baseUrl 变化时不复用旧端点的 in-flight。
    if (this.inFlight !== undefined && this.inFlight.baseUrl === baseUrl) return this.inFlight.promise
    const pending = this.refresh(budget, baseUrl)
      .then(tags => {
        // 旧端点的晚到结果不得覆盖当前端点的缓存；查询时仍会按 baseUrl 校验。
        if (this.resolveBaseUrl() === baseUrl) {
          this.cached = { baseUrl, tags, expiresAt: this.now() + this.ttlMs }
        }
        return tags
      })
      .finally(() => {
        if (this.inFlight?.promise === pending) this.inFlight = undefined
      })
    this.inFlight = { baseUrl, promise: pending }
    return pending
  }

  /**
   * 校验垂直 tag：是否存在，以及 params 定义中 required 的参数哪些没有提供。
   * 只按官方 required 位判断，不猜测条件必填（required=false 的语义由上游解释）。
   */
  async validate(
    tag: string,
    params?: Readonly<Record<string, string | number | boolean>>,
    budget: DomainDiscoveryBudget = {},
  ): Promise<VerticalTagVerdict> {
    const tags = await this.listTags(budget)
    const entry = tags.find(item => item.tag === tag)
    if (entry === undefined) return { exists: false, missingRequired: [] }
    const missingRequired = entry.params
      .filter(param => isRequiredParam(param) && !isSupplied(params?.[param.name]))
      .map(param => param.name)
    return { exists: true, missingRequired }
  }

  private async refresh(budget: DomainDiscoveryBudget, baseUrl: string): Promise<readonly SubDomainInfo[]> {
    const data = await this.requestData(new URL('/v1/domains', baseUrl).href, budget)
    const domains = parseDomains(data)
    if (domains.length === 0) return []
    return parseSubDomains(await this.requestData(subDomainsPath(domains, baseUrl), budget))
  }

  /** 发现请求（GET + 统一信封）；超时与拒绝重定向与 engineFetch 策略一致；非 2xx 只报状态码，不读取正文。 */
  private async requestData(url: string, budget: DomainDiscoveryBudget): Promise<Record<string, unknown>> {
    if (budget.countRequest?.() === false) throw new Error('AnySearch 能力发现请求预算已用尽')
    const headers: Record<string, string> = { accept: 'application/json' }
    const key = this.apiKey?.trim()
    if (key !== undefined && key.length > 0) headers.authorization = `Bearer ${key}`
    const timeout = AbortSignal.timeout(this.timeoutMs)
    const signal = budget.signal === undefined ? timeout : AbortSignal.any([budget.signal, timeout])
    const response = await this.fetcher(url, {
      method: 'GET',
      headers,
      redirect: 'error',
      signal,
    })
    if (!response.ok) {
      // 契约安全要求：402 正文可能携带自动建号凭据，绝不读取或回显。
      throw new Error(`AnySearch 能力发现失败（HTTP ${response.status}）`)
    }
    let payload: unknown
    try {
      payload = await response.json()
    } catch {
      throw new Error('AnySearch 能力发现响应不是合法 JSON')
    }
    if (!isRecord(payload)) throw new Error('AnySearch 能力发现响应必须是对象')
    if (typeof payload.code !== 'number' || !Number.isFinite(payload.code)) {
      throw new Error('AnySearch 能力发现响应缺少 code')
    }
    if (payload.code !== 0) throw new Error(`AnySearch 能力发现返回错误码 ${payload.code}`)
    if (!isRecord(payload.data)) throw new Error('AnySearch 能力发现响应缺少 data')
    return payload.data
  }
}

/** /v1/sub-domains 的 query：重复 domain 参数一次拉全部领域。 */
function subDomainsPath(domains: readonly string[], baseUrl: string): string {
  const url = new URL('/v1/sub-domains', baseUrl)
  for (const domain of domains) url.searchParams.append('domain', domain)
  return url.href
}

/** /v1/domains → 去重后的领域名列表；形状非法直接拒绝；原始非空但全非法时抛错不缓存（防半截响应把垂直路由静默停用一整个 TTL）。 */
function parseDomains(data: Record<string, unknown>): readonly string[] {
  const raw = data.domains
  if (!Array.isArray(raw)) throw new Error('AnySearch /v1/domains 响应缺少 data.domains 数组')
  const domains: string[] = []
  const seen = new Set<string>()
  for (const item of raw) {
    if (!isRecord(item)) continue
    const domain = item.domain
    if (typeof domain !== 'string' || domain.length === 0 || seen.has(domain)) continue
    seen.add(domain)
    domains.push(domain)
  }
  if (raw.length > 0 && domains.length === 0) throw new Error('AnySearch /v1/domains 响应全部条目非法')
  return domains
}

/** /v1/sub-domains → 扁平 tag 列表；params 缺失/非法按空数组处理。 */
function parseSubDomains(data: Record<string, unknown>): readonly SubDomainInfo[] {
  const raw = data.domains
  if (!Array.isArray(raw)) throw new Error('AnySearch /v1/sub-domains 响应缺少 data.domains 数组')
  const tags: SubDomainInfo[] = []
  for (const group of raw) {
    if (!isRecord(group)) continue
    const domain = typeof group.domain === 'string' ? group.domain : ''
    if (!Array.isArray(group.sub_domains)) continue
    for (const item of group.sub_domains) {
      if (!isRecord(item)) continue
      const subDomain = item.sub_domain
      if (typeof subDomain !== 'string' || subDomain.length === 0) continue
      // 契约把 sub_domain 描述为 search 使用的完整 tag，但按域分组返回时也可能是短名；
      // 两种形状都兼容：已含「域.子域」的原样使用，短名补上 domain 前缀。
      const tag = subDomain.includes('.') || domain.length === 0 ? subDomain : `${domain}.${subDomain}`
      tags.push({
        tag,
        description: typeof item.description === 'string' ? item.description : '',
        params: parseParams(item.params),
      })
    }
  }
  return tags
}

/** params 对象 → 有序参数定义数组（JSON 键顺序即官方定义顺序）。 */
function parseParams(value: unknown): readonly SubDomainInfo['params'][number][] {
  if (!isRecord(value)) return []
  const params: Array<{ name: string; description: string; required: boolean }> = []
  for (const [name, definition] of Object.entries(value)) {
    if (!isRecord(definition)) continue
    params.push({
      name,
      description: typeof definition.description === 'string' ? definition.description : '',
      required: definition.required === true,
    })
  }
  return params
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

/**
 * 参数是否必填。上游 schema 存在笔误：required=true 但 description 明写 Optional 的按可选处理。
 * 上游 schema 对 travel.flight_status 的 departure 存在笔误：required 标记为 true
 * 但描述写 Optional，该垂直只需 flight_number。
 */
function isRequiredParam(param: SubDomainInfo['params'][number]): boolean {
  if (!param.required) return false
  return !/\boptional\b/i.test(param.description)
}

/** 参数是否已提供：缺省与空白字符串都算未提供。 */
function isSupplied(value: string | number | boolean | undefined): boolean {
  if (value === undefined) return false
  return typeof value !== 'string' || value.trim().length > 0
}
