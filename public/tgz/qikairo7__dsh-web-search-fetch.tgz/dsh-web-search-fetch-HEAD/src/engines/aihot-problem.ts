import { clipDetail } from './failure.js'
import type { EngineHttpError } from './http.js'
import { isRecord, isText } from './aihot-items.js'

/** Problem JSON 的稳定摘要：code/requestId 前置，避免被长度截断吃掉。 */
export function problemDetail(error: EngineHttpError): string | undefined {
  const body = error.body
  if (!isRecord(body)) return error.detail
  const parts: string[] = []
  if (isText(body.code)) parts.push(`code=${body.code}`)
  if (isText(body.requestId)) parts.push(`requestId=${body.requestId}`)
  if (isText(body.detail)) parts.push(body.detail)
  else if (isText(body.title)) parts.push(body.title)
  const text = parts.join(' ')
  return text.length > 0 ? clipDetail(text) : error.detail
}

/** Problem JSON 的 retryAfter（官方 OpenAPI：整数秒，仅 429/503）。 */
export function problemRetryAfterMs(error: EngineHttpError): number | undefined {
  const body = error.body
  if (!isRecord(body)) return undefined
  const seconds = body.retryAfter
  return typeof seconds === 'number' && Number.isFinite(seconds) && seconds >= 0 ? seconds * 1000 : undefined
}
