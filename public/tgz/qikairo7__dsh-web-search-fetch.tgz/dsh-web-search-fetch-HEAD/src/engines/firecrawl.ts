// Firecrawl（firecrawl）引擎适配——v0.3 M1。
// 契约依据：.scratch/dev-loop/recon/api-contracts/firecrawl.json
//   POST /v2/search            → {success, data:{web:[{title, description, url, markdown?}]}}
//   POST /v2/scrape            → {success, data:{markdown, metadata?}}
//   GET  /v2/team/credit-usage → {success, data:{remainingCredits, planCredits, billingPeriodStart, billingPeriodEnd}}
// 鉴权（v0.4.2 起 keyless-fallback）：fetch（scrape）面在官方端点无 key 时匿名请求
//       （官方 keyless free tier，2026-11-08 实测 200）；search 面受 IP 风控、quota 面不支持
//       keyless，两者缺 key 时不发请求并返回 auth 失败。有 key 时全部端点走 Bearer 账户模式，
//       不静默降级匿名（验收 R6）。
// 端点：manifest 是唯一事实源；endpointOverride 只影响请求 URL（代理域名/测试），不修改 manifest。

import type {
  Engine,
  EngineContext,
  EngineFetchOutcome,
  EngineResult,
  EngineSearchOutcome,
  EngineSearchRequest,
  EngineSearchSource,
  QuotaReport,
} from './contract.js'
import { clipDetail, engineFailure, type EngineFailure } from './failure.js'
import { EngineHttpError, engineJson, projectHttpError } from './http.js'
import { FIRECRAWL_MANIFEST } from './registry.js'

/** 搜索 limit 上限（契约 /v2/search：limit 按每类来源计，1..100）。 */
const MAX_SEARCH_LIMIT = 100

export interface FirecrawlEngineOptions {
  /** fetch 注入口：离线单测替身用；缺省全局 fetch。 */
  readonly fetcher?: typeof fetch
  /** 代理域名/测试基点：覆盖请求 URL，不修改 manifest（支持 firecrawl 代理域名用户）。 */
  readonly endpointOverride?: string
}

type FirecrawlOperation = 'search' | 'fetch' | 'quota'

/** manifest 中的操作端点；注册表缺项时返回 undefined，由调用侧转成显式失败。 */
function manifestEndpoint(operation: FirecrawlOperation): string | undefined {
  return FIRECRAWL_MANIFEST.endpoints[operation]
}

/** manifest 已声明的三条端点路径，用于识别「传进来的其实是另一个操作的端点」。 */
const KNOWN_ENDPOINT_PATHS: readonly string[] = (['search', 'fetch', 'quota'] as const)
  .map(operation => manifestEndpoint(operation))
  .filter((value): value is string => value !== undefined)
  .map(value => {
    try {
      return new URL(value).pathname.replace(/\/+$/u, '')
    } catch {
      return ''
    }
  })
  .filter(path => path.length > 0)

/**
 * 解析本次请求的 URL。
 * - 无 base：直接用 manifest 端点。
 * - base 是完整端点（路径与目标端点一致）：原样使用，支持用户传完整代理 URL。
 * - base 是另一个操作的端点：保留其 origin/前缀，只把已知端点路径换成本操作的路径
 *   （装配层可能复用同一个 ctx.endpoint；代理也不能被静默绕过回官方域）。
 * - base 是代理域名/前缀：保留前缀并拼上 manifest 路径（如 https://proxy/firecrawl + /v2/search）。
 */
function resolveRequestUrl(
  operation: FirecrawlOperation,
  ctx: EngineContext,
  options: FirecrawlEngineOptions,
): string | undefined {
  const target = manifestEndpoint(operation)
  const base = options.endpointOverride ?? ctx.endpoint
  if (base === undefined || base.length === 0) return target
  if (target === undefined) return base
  return mergeRequestUrl(base, target)
}

function mergeRequestUrl(base: string, target: string): string {
  let baseUrl: URL
  let targetUrl: URL
  try {
    baseUrl = new URL(base)
    targetUrl = new URL(target)
  } catch {
    // 覆盖值不是绝对 URL：退回 manifest，避免把非法值带进请求。
    return target
  }
  const basePath = baseUrl.pathname.replace(/\/+$/u, '')
  const targetPath = targetUrl.pathname.replace(/\/+$/u, '')
  if (basePath.endsWith(targetPath)) return baseUrl.href
  const foreignPath = KNOWN_ENDPOINT_PATHS.find(path => path !== targetPath && basePath.endsWith(path))
  if (foreignPath !== undefined) {
    // 覆盖值命中了另一个操作的端点：保留 origin 与前缀，只替换已知端点路径。
    // 直接返回官方 targetUrl 会静默绕过用户配置的代理域。
    baseUrl.pathname = `${basePath.slice(0, basePath.length - foreignPath.length)}${targetUrl.pathname}`
    baseUrl.search = targetUrl.search
    baseUrl.hash = ''
    return baseUrl.href
  }
  baseUrl.pathname = `${basePath}${targetUrl.pathname}`
  baseUrl.search = targetUrl.search
  baseUrl.hash = ''
  return baseUrl.href
}

/** 端点是否与 manifest 登记的官方端点一致（keyless free tier 只覆盖官方端点）。 */
function isOfficialEndpoint(endpoint: string, official: string | undefined): boolean {
  if (official === undefined) return false
  try {
    return new URL(endpoint).href === new URL(official).href
  } catch {
    return false
  }
}

function apiKeyOf(ctx: EngineContext): string | undefined {
  const key = ctx.apiKey?.trim()
  return key === undefined || key.length === 0 ? undefined : key
}

function fail<T>(failure: EngineFailure): EngineResult<T> {
  return { ok: false, failure }
}

/**
 * search 面无 key：keyless free tier 只覆盖 fetch（scrape），搜索仍需密钥；
 * 不发请求，也不静默降级（验收 R6）。
 */
function missingSearchKey<T>(): EngineResult<T> {
  return fail(engineFailure('auth', {
    detail: '未配置 Firecrawl（firecrawl）API key；免钥免费层仅支持网页提取（scrape），搜索需要密钥。',
  }))
}

/**
 * 把 wire 层异常投影为统一失败模型，并补回 retryAfterMs：
 * http.ts 的 EngineHttpError 携带该值，但 failure.ts 的 engineFailure 构造器目前没有透传它。
 */
function projectFailure(error: unknown): EngineFailure {
  const failure = projectHttpError(error)
  if (error instanceof EngineHttpError && error.retryAfterMs !== undefined && failure.kind === 'rate-limited') {
    return { ...failure, retryAfterMs: error.retryAfterMs }
  }
  return failure
}

function providerError(detail: string, statusCode = 200): EngineFailure {
  return engineFailure('provider-error', { statusCode, detail: clipDetail(detail) })
}

interface SearchQueryPlan {
  readonly query: string
  readonly includeDomains?: readonly string[]
  readonly excludeDomains?: readonly string[]
}

/**
 * AD13 查询语法映射（依据 api-contracts/firecrawl.json 的 /v2/search 请求字段）。
 * - site:  → includeDomains；-site: → excludeDomains。
 * - 两者并存：契约规定 includeDomains 与 excludeDomains 互斥，原生无法表达；取舍是两类域名
 *   都按 unsupported 回拼 raw、不发任何域名参数，而不是丢弃其中一侧或静默选一个。
 * - lang/after/before：契约没有对应参数，回拼 raw。tbs 虽有字段但契约未细化其编码，
 *   v0.3 不发明编码，因此同样不映射。
 * 回拼一律取 operators[].raw 逐字、按出现顺序（大小写/路径后缀/顺序都不改），空段丢弃。
 * 组合后 query 为空（操作符全被映射）→ 用 request.query 原文，避免发出空查询。
 */
function planSearchQuery(req: EngineSearchRequest): SearchQueryPlan {
  const syntax = req.syntax
  if (syntax === undefined) return { query: req.query }

  const domainConflict =
    syntax.operators.some(operator => operator.kind === 'site') &&
    syntax.operators.some(operator => operator.kind === '-site')
  const restored = syntax.operators
    .filter(operator =>
      operator.kind === 'site' || operator.kind === '-site' ? domainConflict : true,
    )
    .map(operator => operator.raw)
  const combined = [syntax.bareQuery, ...restored].filter(part => part.length > 0).join(' ')

  const query = combined.length === 0 ? req.query : combined
  if (domainConflict) return { query }
  return {
    query,
    ...(syntax.domains.length === 0 ? {} : { includeDomains: [...syntax.domains] }),
    ...(syntax.excludeDomains.length === 0 ? {} : { excludeDomains: [...syntax.excludeDomains] }),
  }
}

async function search(
  req: EngineSearchRequest,
  ctx: EngineContext,
  options: FirecrawlEngineOptions,
): Promise<EngineResult<EngineSearchOutcome>> {
  const apiKey = apiKeyOf(ctx)
  if (apiKey === undefined) return missingSearchKey()
  const plan = planSearchQuery(req)
  if (plan.query.trim().length === 0) return fail(engineFailure('invalid', { detail: '搜索查询为空' }))

  const url = resolveRequestUrl('search', ctx, options)
  if (url === undefined) return fail(providerError('注册表缺少 firecrawl search 端点'))

  const requested = Number.isFinite(req.maxResults) ? Math.max(0, Math.trunc(req.maxResults)) : 0
  // 调用方要 0 条：直接返回空结果且不发请求（Math.max(1, 0) 会多要 1 条，违背调用方意图）。
  if (requested === 0) return { ok: true, outcome: { sources: [], truncated: false } }
  const limit = Math.min(requested, MAX_SEARCH_LIMIT)

  try {
    const payload = await engineJson<unknown>(ctx, url, {
      method: 'POST',
      fetcher: options.fetcher,
      headers: {
        'authorization': `Bearer ${apiKey}`,
        'content-type': 'application/json',
        'accept': 'application/json',
      },
      body: JSON.stringify({
        query: plan.query,
        limit,
        ...(plan.includeDomains === undefined ? {} : { includeDomains: plan.includeDomains }),
        ...(plan.excludeDomains === undefined ? {} : { excludeDomains: plan.excludeDomains }),
      }),
    })
    const parsed = parseSearchResponse(payload, limit)
    if ('failure' in parsed) return fail(parsed.failure)
    return {
      ok: true,
      outcome: {
        sources: parsed.sources,
        // 请求超过引擎上限（100）或响应条目多于 limit，都算引擎侧截断（AD8）。
        truncated: requested > MAX_SEARCH_LIMIT || parsed.truncated,
      },
    }
  } catch (error) {
    return fail(projectFailure(error))
  }
}

type ParsedSearch = { readonly sources: readonly EngineSearchSource[]; readonly truncated: boolean }

function parseSearchResponse(payload: unknown, limit: number): ParsedSearch | { readonly failure: EngineFailure } {
  const record = asRecord(payload)
  if (record === undefined) return { failure: providerError('响应不是 JSON 对象') }
  if (record.success !== true) return { failure: envelopeFailure(record, '搜索') }

  const data = asRecord(record.data)
  if (data === undefined) return { failure: providerError('响应缺少 data 对象') }

  const web = data.web
  if (!Array.isArray(web)) {
    // 契约冲突（api-contracts/firecrawl.json openQuestions）：features/search 的示例给扁平 data[]，
    // API reference 与 curl source-of-truth 都给 data.web[]。本实现选择分组形状，不做扁平兼容。
    return { failure: providerError('响应缺少 data.web 数组（按契约的分组形状解析）') }
  }

  const truncated = web.length > limit
  const sources: EngineSearchSource[] = []
  for (const entry of web.slice(0, limit)) {
    const source = mapWebEntry(entry)
    if (source !== undefined) sources.push(source)
  }
  return { sources, truncated }
}

/**
 * data.web[] → EngineSearchSource。
 * title→title、description→snippet；URL 缺失或不是绝对 http(s) 的条目丢弃（不可引用）。
 * markdown 是整页正文，不是摘要，且 EngineSearchSource 无对应字段——忽略，不塞进 summary。
 * 契约的 web 项没有 publishedAt/summary 字段，不编造。
 */
function mapWebEntry(value: unknown): EngineSearchSource | undefined {
  const entry = asRecord(value)
  if (entry === undefined) return undefined
  const url = readNonEmptyString(entry.url)
  if (url === undefined || !isHttpUrl(url)) return undefined
  const title = readNonEmptyString(entry.title)
  const snippet = readNonEmptyString(entry.description)
  return {
    url,
    ...(title === undefined ? {} : { title }),
    ...(snippet === undefined ? {} : { snippet }),
  }
}

async function fetchDocument(
  url: string,
  ctx: EngineContext,
  options: FirecrawlEngineOptions,
): Promise<EngineResult<EngineFetchOutcome>> {
  const apiKey = apiKeyOf(ctx)
  if (!isHttpUrl(url)) return fail(engineFailure('invalid', { detail: `提取 URL 非法：${clipDetail(url)}` }))

  const endpoint = resolveRequestUrl('fetch', ctx, options)
  if (endpoint === undefined) return fail(providerError('注册表缺少 firecrawl scrape 端点'))
  // keyless free tier 只覆盖官方端点：自定义端点（firecrawlBaseURL/代理）无 key 时不向
  // 任意地址打匿名流量，与文档「自定义端点仍需密钥」一致（复核裁决 2）；有 key 不受影响。
  if (apiKey === undefined && !isOfficialEndpoint(endpoint, FIRECRAWL_MANIFEST.endpoints.fetch)) {
    return fail(engineFailure('auth', {
      detail: '未配置 Firecrawl（firecrawl）API key；免钥免费层仅适用于官方端点，自定义端点必须配置密钥。',
    }))
  }

  try {
    const payload = await engineJson<unknown>(ctx, endpoint, {
      method: 'POST',
      fetcher: options.fetcher,
      headers: {
        // keyless free tier：官方端点匿名 scrape 可用，无 key 时不带 Authorization。
        ...(apiKey === undefined ? {} : { authorization: `Bearer ${apiKey}` }),
        'content-type': 'application/json',
        'accept': 'application/json',
      },
      // maxAge:0 显式关缓存（契约默认 172800000ms；命中缓存仍按抓取计费且正文可能过期，
      // 与 v0.2 buildFirecrawlScrapeRequest 的取舍一致）。
      body: JSON.stringify({ url, formats: [{ type: 'markdown' }], maxAge: 0 }),
    })
    const parsed = parseFetchResponse(payload, url)
    if ('failure' in parsed) return fail(parsed.failure)
    return { ok: true, outcome: parsed.outcome }
  } catch (error) {
    return fail(projectFailure(error))
  }
}

type ParsedFetch = { readonly outcome: EngineFetchOutcome }

function parseFetchResponse(payload: unknown, requestedUrl: string): ParsedFetch | { readonly failure: EngineFailure } {
  const record = asRecord(payload)
  if (record === undefined) return { failure: providerError('响应不是 JSON 对象') }
  if (record.success !== true) return { failure: envelopeFailure(record, '提取') }

  const data = asRecord(record.data)
  if (data === undefined) return { failure: providerError('响应缺少 data 对象') }
  if (typeof data.markdown !== 'string') return { failure: providerError('响应缺少 data.markdown 字符串') }

  // 目标站非 2xx 是「结果」不是「错误」（seam 契约；v0.2 firecrawl/wire.ts 同义）：
  // metadata.statusCode 透传，缺失时按契约的 200 处理。
  const metadata = asRecord(data.metadata)
  const statusCode = readStatusCode(metadata) ?? 200
  // EngineFetchOutcome.url 是重定向后的最终 URL（contract.ts）；契约 metadata 同时给
  // sourceURL（原始）与 url（最终），优先取 url，缺失才回落请求 URL。
  const finalUrl = readNonEmptyString(metadata?.url) ?? requestedUrl
  return {
    outcome: {
      url: finalUrl,
      statusCode,
      body: { kind: 'text', content: data.markdown },
      truncated: false,
    },
  }
}

async function queryQuota(ctx: EngineContext, options: FirecrawlEngineOptions): Promise<QuotaReport> {
  const engineId = FIRECRAWL_MANIFEST.id
  const apiKey = apiKeyOf(ctx)
  if (apiKey === undefined) {
    return {
      engineId,
      available: false,
      raw: '未配置 Firecrawl（firecrawl）API key；keyless 免费层不支持额度端点',
    }
  }

  const endpoint = resolveRequestUrl('quota', ctx, options)
  if (endpoint === undefined) {
    return { engineId, available: false, raw: '注册表缺少 firecrawl 额度端点' }
  }

  try {
    const payload = await engineJson<unknown>(ctx, endpoint, {
      method: 'GET',
      fetcher: options.fetcher,
      headers: {
        'authorization': `Bearer ${apiKey}`,
        'accept': 'application/json',
      },
    })
    const record = asRecord(payload)
    const data = record === undefined ? undefined : asRecord(record.data)
    if (record === undefined || record.success !== true || data === undefined) {
      return {
        engineId,
        available: false,
        raw: clipDetail(`额度响应不可用：${record === undefined ? '响应不是 JSON 对象' : envelopeErrorDetail(record)}`),
      }
    }
    const remaining = readFiniteNumber(data.remainingCredits)
    const limit = readFiniteNumber(data.planCredits)
    // resetsAt 是「额度重置时刻」：取本周期结束 billingPeriodEnd；开始时间已经过去，不能冒充重置时间。
    const resetsAt = readNonEmptyString(data.billingPeriodEnd)
    return {
      engineId,
      available: true,
      ...(remaining === undefined ? {} : { remaining }),
      ...(limit === undefined ? {} : { limit }),
      ...(resetsAt === undefined ? {} : { resetsAt }),
      raw: clipDetail(JSON.stringify(data)),
    }
  } catch (error) {
    const failure = projectFailure(error)
    const status = failure.statusCode === undefined ? '' : `（HTTP ${failure.statusCode}）`
    return {
      engineId,
      available: false,
      raw: clipDetail(`额度查询失败：${failure.kind}${status}${failure.detail === undefined ? '' : `：${failure.detail}`}`),
    }
  }
}

export function createFirecrawlEngine(options: FirecrawlEngineOptions = {}): Engine {
  return {
    manifest: FIRECRAWL_MANIFEST,
    search: (req, ctx) => search(req, ctx, options),
    fetch: (url, ctx) => fetchDocument(url, ctx, options),
    quota: ctx => queryQuota(ctx, options),
  }
}

/**
 * 成功判定失败（success 不为 true）时的失败分类。
 * 402/429 由 HTTP 层投影；但 v0.2 wire.ts 的 classifyFirecrawlHttpFailure 注释与实现对
 * 「HTTP 200 + {success:false, code}」信封同样按 code 归类（契约 errors 段记录 scrape 的
 * 402 示例 code 为 insufficient_credits），这里补上，避免 200 信封让额度熔断/限流失效。
 */
function envelopeFailure(record: Record<string, unknown>, action: string): EngineFailure {
  const code = readNonEmptyString(record.code) ?? readNonEmptyString(asRecord(record.error)?.code)
  const normalized = code === undefined ? '' : code.toLowerCase().replace(/[^a-z0-9]/gu, '')
  const detail = clipDetail(`${action}失败：${envelopeErrorDetail(record)}`)
  if (normalized.includes('insufficientcredit')) {
    return engineFailure('quota', { statusCode: 200, detail, quotaExhausted: true })
  }
  if (normalized.includes('ratelimit')) {
    return engineFailure('rate-limited', { statusCode: 200, detail })
  }
  return engineFailure('provider-error', { statusCode: 200, detail })
}

/** 取上游 envelope 的 error/code 摘要（成功判定失败时进 detail）。 */
function envelopeErrorDetail(record: Record<string, unknown>): string {
  const nested = asRecord(record.error)
  const message = readNonEmptyString(record.error) ?? (nested === undefined ? undefined : readNonEmptyString(nested.message))
  const code = readNonEmptyString(record.code)
  const parts = [message, code === undefined ? undefined : `(code ${code})`].filter(
    (part): part is string => part !== undefined,
  )
  return parts.length === 0 ? '响应 success 不为 true' : parts.join(' ')
}

function readStatusCode(metadata: unknown): number | undefined {
  const value = asRecord(metadata)?.statusCode
  return typeof value === 'number' && Number.isInteger(value) ? value : undefined
}

function readFiniteNumber(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isFinite(value) ? value : undefined
}

function asRecord(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : undefined
}

function readNonEmptyString(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined
  const trimmed = value.trim()
  return trimmed.length === 0 ? undefined : trimmed
}

function isHttpUrl(value: string): boolean {
  try {
    const url = new URL(value)
    return url.protocol === 'http:' || url.protocol === 'https:'
  } catch {
    return false
  }
}
