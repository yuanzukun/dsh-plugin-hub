// Tavily 引擎适配。
// 端点、鉴权模式、额度端点全部取自 registry 的 TAVILY_MANIFEST，本文件不重抄端点。
// 失败投影遵循统一失败模型：所有异常在引擎边界收敛为 EngineResult.failure，绝不向上抛。

import type {
  Engine,
  EngineContext,
  EngineFetchOutcome,
  EngineResult,
  EngineSearchOutcome,
  EngineSearchRequest,
  EngineSearchSource,
  QueryOperator,
  QuotaReport,
} from './contract.js'
import { MAX_MODEL_SUMMARY_CHARS } from './contract.js'
import { clipDetail, engineFailure, type EngineFailure } from './failure.js'
import { EngineHttpError, engineJson, projectHttpError } from './http.js'
import { TAVILY_MANIFEST } from './registry.js'
import { asHttpUrl, asNumber, asRecord, asText, clipSnippet } from './tavily-json.js'
import { parseDatePeriod, publishedDateToIso } from '../support/time.js'

/** Tavily 搜索单次最多返回 20 条（契约 search.max_results 取值 0-20，默认 10）。 */
const TAVILY_MAX_RESULTS = 20

/** include_domains 契约上限 300；超限报 invalid，不截断放宽用户的过滤意图。 */
const TAVILY_MAX_INCLUDE_DOMAINS = 300

/** exclude_domains 契约上限 150；超限报 invalid（理由同上）。 */
const TAVILY_MAX_EXCLUDE_DOMAINS = 150

/** failed_results 没有目标站真实状态码时的统一目标级状态（4xx 语义：目标被拒绝）。 */
const TARGET_REJECTED_STATUS = 400

export interface TavilyEngineOptions {
  /** fetch 注入口：离线单测替身用；缺省全局 fetch。 */
  readonly fetcher?: typeof fetch
  /** 只覆盖请求 URL（测试/自建代理用），不修改 manifest 中的端点。 */
  readonly endpointOverride?: string
}

/** 创建 Tavily 引擎（search / fetch / quota 三面）。 */
export function createTavilyEngine(options: TavilyEngineOptions = {}): Engine {
  return {
    manifest: TAVILY_MANIFEST,
    search: (req, ctx) => search(req, ctx, options),
    fetch: (url, ctx) => fetchOne(url, ctx, options),
    quota: ctx => quota(ctx, options),
  }
}

async function search(
  req: EngineSearchRequest,
  ctx: EngineContext,
  options: TavilyEngineOptions,
): Promise<EngineResult<EngineSearchOutcome>> {
  const endpoint = options.endpointOverride ?? ctx.endpoint
  // maxResults 至少 1；超过 20 的部分 Tavily 不接受，按引擎上限请求并置 truncated。
  const demand = Number.isFinite(req.maxResults) ? Math.max(1, Math.floor(req.maxResults)) : 1
  const requested = Math.min(demand, TAVILY_MAX_RESULTS)
  const plan = searchBody(req, requested)
  if (!plan.ok) return { ok: false, failure: plan.failure }
  try {
    const payload = await engineJson<unknown>(ctx, endpoint, {
      method: 'POST',
      headers: requestHeaders(ctx),
      body: JSON.stringify(plan.body),
      fetcher: options.fetcher,
    })
    const record = asRecord(payload)
    const rows = record !== undefined && Array.isArray(record.results) ? record.results : undefined
    if (rows === undefined) {
      return { ok: false, failure: engineFailure('provider-error', { detail: 'search 响应缺少 results 数组' }) }
    }
    const sources: EngineSearchSource[] = []
    for (const row of rows) {
      const item = asRecord(row)
      if (item === undefined) continue
      const url = asHttpUrl(item.url)
      if (url === undefined) continue
      const title = asText(item.title)
      const content = asText(item.content)
      const summary = content?.slice(0, MAX_MODEL_SUMMARY_CHARS)
      const publishedAt = publishedDateToIso(item.published_date)
      // score 是 Tavily 的排序信号，seam 没有对应字段，不臆造映射。
      sources.push({
        url,
        ...(title === undefined ? {} : { title }),
        ...(content === undefined ? {} : { snippet: clipSnippet(content) }),
        ...(summary === undefined ? {} : { summary }),
        ...(publishedAt === undefined ? {} : { publishedAt }),
      })
    }
    // 引擎侧截断：请求量超过 Tavily 上限，或服务器返回的条数多于本次请求。
    const truncated = demand > TAVILY_MAX_RESULTS || sources.length > requested
    return { ok: true, outcome: { sources: sources.slice(0, requested), truncated } }
  } catch (error) {
    return { ok: false, failure: projectTavilyError(error) }
  }
}

type SearchBodyPlan =
  | { readonly ok: true; readonly body: Record<string, unknown> }
  | { readonly ok: false; readonly failure: EngineFailure }

/**
 * 搜索请求体原生映射。Tavily 覆盖全部已解析操作符，正常路径下发出的 query
 * 恒为 syntax.bareQuery、无回拼；只有值不符合契约（目前是非法日历日期）的项才按 unsupported
 * 把 operators[].raw 逐字拼回，绝不静默丢弃。syntax 缺省时请求体与接线前逐字段一致。
 */
function searchBody(req: EngineSearchRequest, requested: number): SearchBodyPlan {
  const syntax = req.syntax
  if (syntax === undefined) {
    return {
      ok: true,
      body: { query: req.query, max_results: requested, search_depth: 'basic', include_published_date: true },
    }
  }
  // 契约硬上限：include_domains 最多 300、exclude_domains 最多 150。截断会静默放宽用户的
  // 过滤意图，把 site: 回拼进全文检索又会污染结果，因此超限明确报 invalid 交由调用方决定。
  const violations: string[] = []
  if (syntax.domains.length > TAVILY_MAX_INCLUDE_DOMAINS) {
    violations.push(`include_domains 超过上限 ${TAVILY_MAX_INCLUDE_DOMAINS}（收到 ${syntax.domains.length}）`)
  }
  if (syntax.excludeDomains.length > TAVILY_MAX_EXCLUDE_DOMAINS) {
    violations.push(`exclude_domains 超过上限 ${TAVILY_MAX_EXCLUDE_DOMAINS}（收到 ${syntax.excludeDomains.length}）`)
  }
  if (violations.length > 0) {
    return { ok: false, failure: engineFailure('invalid', { detail: violations.join('；') }) }
  }
  const body: Record<string, unknown> = {
    query: syntax.bareQuery,
    max_results: requested,
    search_depth: 'basic',
    include_published_date: true,
  }
  if (syntax.after !== undefined || syntax.before !== undefined) body.filter_by_published_date = true
  if (syntax.domains.length > 0) body.include_domains = syntax.domains
  if (syntax.excludeDomains.length > 0) body.exclude_domains = syntax.excludeDomains
  if (syntax.after !== undefined) {
    const start = normalizeStartDate(syntax.after)
    if (start !== undefined) body.start_date = start
  }
  if (syntax.before !== undefined) {
    const end = normalizeEndDate(syntax.before)
    if (end !== undefined) body.end_date = end
  }
  // 契约：filter_by_language 需与 language 配合（默认 false，必须显式开启才按语言过滤）。
  if (syntax.language !== undefined) {
    body.language = syntax.language
    body.filter_by_language = true
  }
  // 统一回拼规则：逐个判定操作符是否被本引擎接受，不接受的项按 operators[].raw 原样
  // （大小写、路径后缀、出现顺序都不改）接在 bareQuery 之后，绝不静默丢弃。
  const unsupported = syntax.operators.filter(operator => !supportsOperator(operator)).map(operator => operator.raw)
  const query = [syntax.bareQuery, ...unsupported].filter(part => part.length > 0).join(' ')
  // 组合后为空（如纯 lang:zh）：Tavily 的 query 必填，退回 request.query 原文；
  // 语言/域名/日期参数已独立生效，不受影响。
  body.query = query.length > 0 ? query : req.query
  return { ok: true, body }
}

/** 本引擎能否原生接收该操作符；日期值走完整日历校验，非法项按 unsupported 回拼 raw。 */
function supportsOperator(operator: QueryOperator): boolean {
  switch (operator.kind) {
    case 'site':
    case '-site':
    case 'lang':
      return true
    case 'after':
      return normalizeStartDate(operator.value) !== undefined
    case 'before':
      return normalizeEndDate(operator.value) !== undefined
  }
}

/** after（含当日）：YYYY → 当年 01-01；YYYY-MM → 当月 01；YYYY-MM-DD 校验后原样。 */
function normalizeStartDate(value: string): string | undefined {
  const period = parseDatePeriod(value)
  if (period === undefined) return undefined
  return `${pad4(period.year)}-${pad2(period.month)}-${pad2(period.day)}`
}

/**
 * before（严格早于该期间）：YYYY → (YYYY-1)-12-31；YYYY-MM → 上月最后一日；
 * YYYY-MM-DD 校验后原样。与 after 的「含当日」语义对称：after:2026-10 取 2026-10-01
 * （覆盖整个 10 月），before:2026-10 取 2026-09-30（不覆盖 10 月）。
 */
function normalizeEndDate(value: string): string | undefined {
  const period = parseDatePeriod(value)
  if (period === undefined) return undefined
  if (period.daySpecified) return `${pad4(period.year)}-${pad2(period.month)}-${pad2(period.day)}`
  if (period.month === 1) {
    return period.year === 1 ? undefined : `${pad4(period.year - 1)}-12-31`
  }
  const previousMonth = period.month - 1
  return `${pad4(period.year)}-${pad2(previousMonth)}-${pad2(lastDayOfMonth(period.year, previousMonth))}`
}

/** setUTCFullYear 而非 Date.UTC：后者把 0-99 年映射到 1900+，闰年判断会错。 */
function lastDayOfMonth(year: number, month: number): number {
  const probe = new Date(0)
  probe.setUTCFullYear(year, month, 0)
  return probe.getUTCDate()
}

function pad2(value: number): string {
  return String(value).padStart(2, '0')
}

function pad4(value: number): string {
  return String(value).padStart(4, '0')
}

async function fetchOne(
  url: string,
  ctx: EngineContext,
  options: TavilyEngineOptions,
): Promise<EngineResult<EngineFetchOutcome>> {
  const endpoint = options.endpointOverride ?? ctx.endpoint
  try {
    const payload = await engineJson<unknown>(ctx, endpoint, {
      method: 'POST',
      headers: requestHeaders(ctx),
      body: JSON.stringify({ urls: [url], format: 'markdown', extract_depth: 'basic' }),
      fetcher: options.fetcher,
    })
    const record = asRecord(payload)
    if (record === undefined) {
      return { ok: false, failure: engineFailure('provider-error', { detail: 'extract 响应不是 JSON 对象' }) }
    }
    // 契约提醒：200 也要同时检查 results 与 failed_results；单 URL 请求下 failed_results
    // 非空即目标站失败（引擎不回报目标站真实状态码，用 4xx 语义的 400 作为目标级标记）。
    const failed = Array.isArray(record.failed_results) ? record.failed_results : []
    if (failed.length > 0) {
      return { ok: false, failure: targetStatusFailure(failedResultMessages(failed)) }
    }
    const results = Array.isArray(record.results) ? record.results : undefined
    if (results === undefined) {
      return { ok: false, failure: engineFailure('provider-error', { detail: 'extract 响应缺少 results 数组' }) }
    }
    const item = results.length > 0 ? asRecord(results[0]) : undefined
    const content = item === undefined ? undefined : item.raw_content
    if (typeof content !== 'string' || content.trim().length === 0) {
      return { ok: false, failure: engineFailure('provider-error', { detail: '提取结果没有正文' }) }
    }
    // format=markdown，因此 body 是 text；Tavily 不报告目标站状态码，成功提取统一记 200。
    return {
      ok: true,
      outcome: {
        url: (item === undefined ? undefined : asHttpUrl(item.url)) ?? url,
        statusCode: 200,
        body: { kind: 'text', content },
        truncated: false,
      },
    }
  } catch (error) {
    return { ok: false, failure: projectTavilyError(error) }
  }
}

async function quota(ctx: EngineContext, options: TavilyEngineOptions): Promise<QuotaReport> {
  const key = ctx.apiKey?.trim()
  // keyless 模式不请求 /usage：契约明确 keyless 只覆盖 /search 与 /extract，/usage 必须带 key；
  // 匿名额度也没有文档化数值。显式 N/A（available:false）比发一次必 401 的请求更准确，也更省预算。
  if (key === undefined || key.length === 0) {
    return {
      engineId: TAVILY_MANIFEST.id,
      available: false,
      raw: 'keyless 模式无额度端点：/usage 需要 API key（契约 keyless 仅覆盖 /search 与 /extract）',
    }
  }
  const endpoint = resolveQuotaUrl(ctx, options)
  try {
    const payload = await engineJson<unknown>(ctx, endpoint, {
      method: 'GET',
      headers: { accept: 'application/json', authorization: `Bearer ${key}` },
      fetcher: options.fetcher,
    })
    const record = asRecord(payload)
    const keyRecord = record === undefined ? undefined : asRecord(record.key)
    const used = keyRecord === undefined ? undefined : asNumber(keyRecord.usage)
    if (used === undefined) {
      return { engineId: TAVILY_MANIFEST.id, available: false, raw: 'usage 响应缺少 key.usage' }
    }
    // 契约：key.limit 是 integer 或 null；null 表示 key 级不限。字段缺失/类型异常是响应形状问题，
    // 不能与 null 混为一谈——否则设置页会把「额度未知」显示成「不限」。
    const limitValue = keyRecord === undefined ? undefined : keyRecord.limit
    if (limitValue === undefined) {
      return { engineId: TAVILY_MANIFEST.id, available: false, raw: 'usage 响应缺少 key.limit' }
    }
    if (limitValue !== null && asNumber(limitValue) === undefined) {
      return { engineId: TAVILY_MANIFEST.id, available: false, raw: 'usage 响应 key.limit 不是 integer/null' }
    }
    const account = record === undefined ? undefined : asRecord(record.account)
    const plan = account === undefined ? undefined : asText(account.current_plan)
    const keyLimit = limitValue === null ? undefined : asNumber(limitValue)
    let limit: number | undefined = keyLimit
    let reportedUsed: number | undefined = used
    let remaining: number | undefined = keyLimit === undefined ? undefined : keyLimit - used
    const summary = [`key.usage=${used}`]
    if (keyLimit !== undefined) {
      summary.push(`key.limit=${keyLimit}, remaining=${remaining}`)
    } else {
      // key.limit=null 时口径落到账号套餐：只有 key.limit 与 account.plan_limit 都显式为 null 才「不限」；
      // plan_limit 缺失/类型异常是形状问题，回到 available:false（缺失 ≠ null）。
      const planLimitValue = account === undefined ? undefined : account.plan_limit
      if (planLimitValue === undefined) {
        return { engineId: TAVILY_MANIFEST.id, available: false, raw: 'usage 响应缺少 account.plan_limit' }
      }
      if (planLimitValue !== null && asNumber(planLimitValue) === undefined) {
        return { engineId: TAVILY_MANIFEST.id, available: false, raw: 'usage 响应 account.plan_limit 不是 integer/null' }
      }
      const planLimit = planLimitValue === null ? undefined : asNumber(planLimitValue)
      if (planLimit === undefined) {
        summary.push('key.limit=null', 'account.plan_limit=null（不限）')
      } else {
        // plan 级配对：limit/used 都取 account 侧，不混用 key.usage；plan_usage 缺失则不补 remaining。
        limit = planLimit
        const planUsageValue = account === undefined ? undefined : account.plan_usage
        if (planUsageValue !== undefined && asNumber(planUsageValue) === undefined) {
          return { engineId: TAVILY_MANIFEST.id, available: false, raw: 'usage 响应 account.plan_usage 不是 integer' }
        }
        const planUsage = asNumber(planUsageValue)
        if (planUsage === undefined) {
          reportedUsed = undefined
          summary.push('key.limit=null', `account.plan_limit=${planLimit}`, 'account.plan_usage 缺失，未计算 remaining')
        } else {
          reportedUsed = planUsage
          remaining = planLimit - planUsage
          summary.push('key.limit=null', `account.plan_limit=${planLimit}`, `account.plan_usage=${planUsage}, remaining=${remaining}`)
        }
      }
    }
    if (plan !== undefined) summary.push(`plan=${plan}`)
    return {
      engineId: TAVILY_MANIFEST.id,
      available: true,
      ...(reportedUsed === undefined ? {} : { used: reportedUsed }),
      ...(limit === undefined ? {} : { limit }),
      ...(remaining === undefined ? {} : { remaining }),
      raw: clipDetail(summary.join(', ')),
    }
  } catch (error) {
    const failure = projectTavilyError(error)
    const status = failure.statusCode === undefined ? '' : `（HTTP ${failure.statusCode}）`
    const detail = failure.detail === undefined ? '' : `：${failure.detail}`
    return {
      engineId: TAVILY_MANIFEST.id,
      available: false,
      raw: clipDetail(`额度查询失败：${failure.kind}${status}${detail}`),
    }
  }
}

/**
 * 目标级提取失败的统一投影（契约：/extract 不回报目标站真实状态码）。
 * statusCode 用 4xx 语义占位，detail 明示「未知」，避免下游把占位值当成目标站真实 400 传播。
 */
function targetStatusFailure(messages: readonly string[]): EngineFailure {
  const text = messages.length > 0 ? messages.join('; ') : '提取失败（响应未给出错误文本）'
  return engineFailure('target-status', {
    statusCode: TARGET_REJECTED_STATUS,
    // 占位说明前置：错误文本超长时会被 clipDetail 截掉，语义不能随尾部一起丢失。
    detail: clipDetail(`（目标状态未知，占位 400）${text}`),
  })
}

/** failed_results[] 的 {url,error} 形状 → 错误文本列表。 */
function failedResultMessages(rows: readonly unknown[]): string[] {
  return rows
    .map(entry => asText(asRecord(entry)?.error))
    .filter((message): message is string => message !== undefined)
}

/** 从 400 错误体提取 detail.failed_results（也兼容顶层 failed_results）。 */
function failedResultsOfBody(body: unknown): string[] {
  const record = asRecord(body)
  if (record === undefined) return []
  const detail = asRecord(record.detail)
  const nested = detail !== undefined && Array.isArray(detail.failed_results) ? detail.failed_results : undefined
  const rows = nested ?? (Array.isArray(record.failed_results) ? record.failed_results : undefined)
  return rows === undefined ? [] : failedResultMessages(rows)
}

/** manifest 端点路径，用于识别 base 是否其实是另一个操作的端点。 */
function endpointPath(value: string | undefined): string {
  if (value === undefined) return ''
  try {
    return new URL(value).pathname.replace(/\/+$/u, '')
  } catch {
    return ''
  }
}

/**
 * 额度请求 URL。生产装配层给 EngineContext.endpoint 的是搜索端点（op 固定 search），
 * 因此 quota 必须从 manifest 取 /usage：base 是 quota 端点则原样用；是 search/fetch 则回落
 * 到 manifest /usage；是代理前缀（如 https://proxy）则保留前缀拼上 /usage。
 */
function resolveQuotaUrl(ctx: EngineContext, options: TavilyEngineOptions): string {
  const target = TAVILY_MANIFEST.endpoints.quota
  const base = options.endpointOverride ?? ctx.endpoint
  if (target === undefined) return base
  if (base.length === 0) return target
  let baseUrl: URL
  let targetUrl: URL
  try {
    baseUrl = new URL(base)
    targetUrl = new URL(target)
  } catch {
    return target
  }
  const basePath = baseUrl.pathname.replace(/\/+$/u, '')
  const targetPath = targetUrl.pathname.replace(/\/+$/u, '')
  if (basePath.endsWith(targetPath)) return baseUrl.href
  const otherPaths = [TAVILY_MANIFEST.endpoints.search, TAVILY_MANIFEST.endpoints.fetch]
    .map(endpointPath)
    .filter(path => path.length > 0 && path !== targetPath)
  const foreignPath = otherPaths.find(path => basePath.endsWith(path))
  if (foreignPath !== undefined) {
    // base 是另一个操作的端点（可能是代理前缀 + 操作路径）：只替换操作路径，保留 origin/前缀，
    // 不能返回官方 targetUrl——那会静默绕过用户配置的代理。
    baseUrl.pathname = `${basePath.slice(0, basePath.length - foreignPath.length)}${targetUrl.pathname}`
    baseUrl.search = targetUrl.search
    baseUrl.hash = ''
    return baseUrl.href
  }
  baseUrl.pathname = `${basePath}${targetUrl.pathname}`
  baseUrl.search = targetUrl.search
  baseUrl.hash = ''
  return baseUrl.href
}

/** 鉴权分支：有 key → Bearer；无 key → keyless 头。绝不发送两者。 */
function requestHeaders(ctx: EngineContext): Record<string, string> {
  const key = ctx.apiKey?.trim()
  return {
    accept: 'application/json',
    'content-type': 'application/json',
    ...(key === undefined || key.length === 0
      ? { 'x-tavily-access-mode': 'keyless' }
      : { authorization: `Bearer ${key}` }),
  }
}

/**
 * wire 层错误 → 统一失败模型。
 * 432（套餐上限）/433（PAYGO 上限）都是额度耗尽，statusCode 用真实值；
 * 434（Flex tier 容量）是容量问题不是额度，落 provider-error。
 */
function projectTavilyError(error: unknown): EngineFailure {
  if (error instanceof EngineHttpError && (error.status === 432 || error.status === 433)) {
    return engineFailure('quota', {
      statusCode: error.status,
      detail: error.detail,
      quotaExhausted: true,
    })
  }
  // 契约 errors：/extract 的 400 可能带 detail.failed_results[]（URL 超限/校验失败）。
  // 这是目标级失败，不是引擎故障；映射成 provider-error 会错误触发引擎冷却。
  if (error instanceof EngineHttpError && error.status === 400) {
    const messages = failedResultsOfBody(error.body)
    if (messages.length > 0) return targetStatusFailure(messages)
  }
  // 429 的 retryAfterMs 由共享 projectHttpError 透传，这里不再手工补偿。
  return projectHttpError(error)
}
