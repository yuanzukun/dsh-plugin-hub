// 知乎热榜（hot_list）：请求 URL、envelope 映射与 Engine.hotTopics 处理器。
// 官方文档：https://developer.zhihu.com/docs?key=hot_list
// 契约要点：Data: {Total, Items: [{Title, Url, ThumbnailUrl, Summary}]}，Limit 默认/最大 30；
// Item 没有发布时间字段。

import type {
  EngineContext,
  EngineResult,
  EngineSearchOutcome,
  EngineSearchSource,
  HotTopicsFn,
} from './contract.js'
import { engineFailure } from './failure.js'
import { engineJson, projectHttpError } from './http.js'
import { ZHIHU_MANIFEST } from './registry.js'
import {
  asHttpUrl,
  asText,
  authHeaders,
  envelopeFailure,
  withPath,
  type ZhihuEngineOptions,
  type ZhihuEnvelope,
} from './zhihu-shared.js'

/** 热榜路径：manifest 的 endpoints 只有 search/fetch/quota 槽位，热榜路径没有派生来源（同站内搜索）。 */
const HOT_LIST_PATH = '/api/v1/content/hot_list'

/** 热榜 Item：官方 hot_list 文档的四个字段；ThumbnailUrl 无来源条目不参与映射。 */
interface ZhihuHotListItem {
  readonly Title?: string
  readonly Url?: string
  readonly Summary?: string
}

interface ZhihuHotListData {
  readonly Total?: number
  readonly Items?: readonly ZhihuHotListItem[]
}

/**
 * 热榜 URL：与搜索/额度同源；endpointOverride 优先，其次从装配层端点换算路径。
 * 端点已指向知乎已知路径（搜索/额度）时换成热榜路径；自定义完整端点按原样使用。
 */
function hotListUrl(ctx: EngineContext, options: ZhihuEngineOptions): URL {
  if (options.endpointOverride !== undefined) return withPath(options.endpointOverride, HOT_LIST_PATH)
  const base = ctx.endpoint !== '' ? ctx.endpoint : (ZHIHU_MANIFEST.endpoints.search ?? '')
  const url = new URL(base)
  if (
    url.pathname.endsWith('/global_search') ||
    url.pathname.endsWith('/zhihu_search') ||
    url.pathname.endsWith('/quota')
  ) {
    return withPath(base, HOT_LIST_PATH)
  }
  return url
}

/**
 * 热榜 Item → 归一化来源：Summary 作 snippet；契约没有发布时间字段，publishedAt 省略。
 * 没有可引用 HTTP(S) URL 的条目直接丢弃（契约 Url 为必返字符串）。
 */
function mapHotListItem(item: ZhihuHotListItem): EngineSearchSource | undefined {
  const url = asHttpUrl(item.Url)
  if (url === undefined) return undefined
  const title = asText(item.Title)
  const snippet = asText(item.Summary)
  return {
    url,
    ...(title === undefined ? {} : { title }),
    ...(snippet === undefined ? {} : { snippet }),
  }
}

/**
 * 热榜 envelope → outcome。条数按端点默认（30），适配层不再截断，因此 truncated 恒 false；
 * 失败码与搜索共用 envelopeFailure 映射（30001 → rate-limited）。
 */
function mapHotListResponse(envelope: ZhihuEnvelope<ZhihuHotListData>): EngineResult<EngineSearchOutcome> {
  const failure = envelopeFailure(envelope)
  if (failure !== undefined) return { ok: false, failure }
  const data = envelope.Data
  if (data === undefined || data === null) {
    return { ok: false, failure: engineFailure('provider-error', { detail: '知乎热榜成功响应缺少 Data' }) }
  }
  if (data.Items !== undefined && !Array.isArray(data.Items)) {
    return { ok: false, failure: engineFailure('provider-error', { detail: '知乎热榜响应 Data.Items 不是数组' }) }
  }
  const sources = (data.Items ?? [])
    .filter((item): item is ZhihuHotListItem => typeof item === 'object' && item !== null)
    .map(mapHotListItem)
    .filter((source): source is EngineSearchSource => source !== undefined)
  return { ok: true, outcome: { sources, truncated: false } }
}

/**
 * Engine.hotTopics 处理器：缺凭证是配置错误（不发请求、不降级）；请求/映射错误统一投影。
 */
export function hotTopicsHandler(options: ZhihuEngineOptions): HotTopicsFn {
  return async (ctx) => {
    const apiKey = ctx.apiKey?.trim()
    if (apiKey === undefined || apiKey === '') {
      return { ok: false, failure: engineFailure('auth', { detail: '知乎引擎未配置 Access Secret' }) }
    }
    try {
      const url = hotListUrl(ctx, options)
      // 不传 Limit：按端点默认 30 条（任务约定「条数按端点默认」）。
      const envelope = await engineJson<ZhihuEnvelope<ZhihuHotListData>>(ctx, url.href, {
        method: 'GET',
        fetcher: options.fetcher,
        headers: authHeaders(apiKey),
      })
      return mapHotListResponse(envelope)
    } catch (error) {
      return { ok: false, failure: projectHttpError(error) }
    }
  }
}
