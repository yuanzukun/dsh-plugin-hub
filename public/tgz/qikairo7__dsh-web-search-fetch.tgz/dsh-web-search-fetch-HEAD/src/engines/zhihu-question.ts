// 知乎问题回答读取（fetch 面）——question_answers API。
// 官方文档：https://developer.zhihu.com/docs?key=question_answers
// 契约依据：.scratch/dev-loop/recon/api-contracts/zhihu-docs-tree.json「问题发现」组
//   GET /api/v1/content/question_answers?QuestionUrl=<完整问题URL>&Offset=&Limit=1-50(默认20)
//   → Data.Items[{ContentType:'answer',ContentToken,Url,Summary}] + Data.Paging{IsEnd,NextOffset,Totals}
// 边界（同文档）：问题回答与问题推荐共用「问题发现」额度（默认 100/日，未实名等低信任 10/日，
//   北京时间 00:00 重置）；日额度耗尽返回 30001；Summary 是服务端摘要/截取，不是 AI 生成全文。
// 本实现只取首页（Limit=20），不自动翻页——摘要够用，额度珍贵（spec 裁决）。

import type { EngineContext, EngineFetchOutcome, EngineResult } from './contract.js'
import { clipDetail, engineFailure, type EngineFailure } from './failure.js'
import { engineJson, projectHttpError } from './http.js'
import { ZHIHU_MANIFEST } from './registry.js'
import {
  asHttpUrl,
  asText,
  authHeaders,
  envelopeFailure,
  withPath,
  type ZhihuEngineOptions,
  type ZhihuEnvelope,
} from './zhihu-shared.js'

/** manifest 的 fetch 端点路径；适配层不重抄端点值，只登记路径常量。 */
const QUESTION_ANSWERS_PATH = '/api/v1/content/question_answers'
/** 契约范围 1-50、默认 20；只取首页，固定 20。 */
const QUESTION_ANSWERS_LIMIT = 20

/** 契约逐字列出的 Item 字段；ContentType 固定为 answer，不参与映射。 */
interface ZhihuAnswerItem {
  readonly ContentType?: string
  readonly ContentToken?: string
  readonly Url?: string
  readonly Summary?: string
}

interface ZhihuAnswerPaging {
  readonly IsEnd?: boolean
  readonly NextOffset?: number
  readonly Totals?: number
}

interface ZhihuQuestionAnswersData {
  readonly Items?: readonly ZhihuAnswerItem[]
  readonly Paging?: ZhihuAnswerPaging
}

/**
 * 可处理性判定：仅 zhihu.com/question/<数字 id>（允许 /question/<id>/... 后缀与查询参数）。
 * 非问题 URL 返回 undefined——适配器不发请求、不消费预算，让其他提取引擎接管。
 */
export function zhihuQuestionId(rawUrl: string): string | undefined {
  let url: URL
  try {
    url = new URL(rawUrl)
  } catch {
    return undefined
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return undefined
  const host = url.hostname.toLowerCase()
  if (host !== 'www.zhihu.com' && host !== 'zhihu.com') return undefined
  const match = /^\/question\/(\d+)(?:\/|$)/u.exec(url.pathname)
  return match?.[1]
}

/**
 * 解析本次请求 URL：endpointOverride 优先；ctx.endpoint 若仍是知乎其他已知路径则换算到
 * question_answers，保持与搜索/热榜/额度同源的端点覆盖语义。
 */
function questionAnswersUrl(ctx: EngineContext, options: ZhihuEngineOptions): URL {
  if (options.endpointOverride !== undefined) return withPath(options.endpointOverride, QUESTION_ANSWERS_PATH)
  const base = ctx.endpoint !== '' ? ctx.endpoint : (ZHIHU_MANIFEST.endpoints.fetch ?? '')
  const url = new URL(base)
  const path = url.pathname
  if (
    path.endsWith('/global_search') ||
    path.endsWith('/zhihu_search') ||
    path.endsWith('/hot_list') ||
    path.endsWith('/quota')
  ) {
    return withPath(base, QUESTION_ANSWERS_PATH)
  }
  return url
}

/**
 * 单个回答 → Markdown 段：锚文本用 ContentToken（缺失时退回序号），链接取 Items[].Url，
 * 正文取服务端 Summary。没有可引用 HTTP(S) URL 的条目丢弃（契约 Url 为必返字符串）。
 */
function answerSection(item: ZhihuAnswerItem, index: number): string | undefined {
  const url = asHttpUrl(item.Url)
  if (url === undefined) return undefined
  const token = asText(item.ContentToken)
  const label = token === undefined ? `回答 ${index + 1}` : `回答 ${token}`
  const summary = asText(item.Summary) ?? '（服务端未返回摘要）'
  return `## ${label}\n\n[${label}](${url})\n\n${summary}`
}

/** 正文组织：标题 + 问题 URL + 每个回答一段；空列表也给出成功说明（不误报失败）。 */
function renderQuestionAnswers(sections: readonly string[], questionUrl: string): string {
  const header = `# 知乎问题回答\n\n问题：${questionUrl}\n`
  if (sections.length === 0) {
    return `${header}\n该问题下没有可读取的回答摘要（API 成功返回空列表）。\n`
  }
  return `${header}\n${sections.join('\n\n')}\n`
}

/**
 * envelope 非成功码 → 失败。问题回答与问题推荐共用「问题发现」日额度，
 * 30001 同时覆盖频率/并发与日额度耗尽（官方文档明确二义）；提取面归 quota，
 * 让熔断与本地额度账本按额度失败处理（spec 验收 3）。其余码沿用知乎搜索的现有映射口径，
 * detail 格式保持一致。
 */
function questionAnswersFailure(envelope: ZhihuEnvelope<unknown>): EngineFailure | undefined {
  if (envelope.Code === 0) return undefined
  if (envelope.Code === 30001) {
    const message = typeof envelope.Message === 'string' ? envelope.Message : ''
    return engineFailure('quota', { detail: clipDetail(`知乎问题回答 Code 30001: ${message}`) })
  }
  return envelopeFailure(envelope)
}

function mapQuestionAnswersResponse(
  envelope: ZhihuEnvelope<ZhihuQuestionAnswersData>,
  questionUrl: string,
): EngineResult<EngineFetchOutcome> {
  const failure = questionAnswersFailure(envelope)
  if (failure !== undefined) return { ok: false, failure }
  const data = envelope.Data
  if (data === undefined || data === null) {
    return { ok: false, failure: engineFailure('provider-error', { detail: '知乎问题回答成功响应缺少 Data' }) }
  }
  if (data.Items !== undefined && !Array.isArray(data.Items)) {
    return { ok: false, failure: engineFailure('provider-error', { detail: '知乎问题回答响应 Data.Items 不是数组' }) }
  }
  const items = (data.Items ?? []).filter((item): item is ZhihuAnswerItem => typeof item === 'object' && item !== null)
  const sections = items
    .map(answerSection)
    .filter((section): section is string => section !== undefined)
  // AD8：只取首页；上游明确仍有下一页时置 truncated，不静默丢弃。
  const truncated = data.Paging?.IsEnd === false
  return {
    ok: true,
    outcome: {
      url: questionUrl,
      statusCode: 200,
      body: { kind: 'text', content: renderQuestionAnswers(sections, questionUrl) },
      truncated,
    },
  }
}

/**
 * fetch 面处理器：不适用 URL 或凭据缺失时都不发请求；请求/映射错误统一投影。
 * 预算记账由 engineJson → engineFetch 完成（每个 HTTP 请求一次 countRequest）。
 */
export async function fetchQuestionAnswers(
  url: string,
  ctx: EngineContext,
  options: ZhihuEngineOptions,
): Promise<EngineResult<EngineFetchOutcome>> {
  if (zhihuQuestionId(url) === undefined) {
    return {
      ok: false,
      failure: engineFailure('invalid', { detail: clipDetail(`知乎提取仅支持 zhihu.com/question/<id>：${url}`) }),
    }
  }
  const apiKey = ctx.apiKey?.trim()
  if (apiKey === undefined || apiKey === '') {
    return { ok: false, failure: engineFailure('auth', { detail: '知乎引擎未配置 Access Secret' }) }
  }
  try {
    const endpoint = questionAnswersUrl(ctx, options)
    endpoint.searchParams.set('QuestionUrl', url)
    endpoint.searchParams.set('Limit', String(QUESTION_ANSWERS_LIMIT))
    const envelope = await engineJson<ZhihuEnvelope<ZhihuQuestionAnswersData>>(ctx, endpoint.href, {
      method: 'GET',
      fetcher: options.fetcher,
      headers: authHeaders(apiKey),
    })
    return mapQuestionAnswersResponse(envelope, url)
  } catch (error) {
    return { ok: false, failure: projectHttpError(error) }
  }
}
