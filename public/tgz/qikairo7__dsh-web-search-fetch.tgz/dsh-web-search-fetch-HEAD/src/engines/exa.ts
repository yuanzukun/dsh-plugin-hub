// Exa Search Lite 引擎适配。
// 契约事实：POST /search，type:"lite"，只请求 contents.highlights 与 contents.text；
// 响应 results[]{title,url,publishedDate?,highlights?,text?}。
// 端点、鉴权和默认开关取自 EXA_MANIFEST；本文件不提供端点覆盖，也不接入 Search Lite 之外的能力。

import type {
  Engine,
  EngineContext,
  EngineResult,
  EngineSearchOutcome,
  EngineSearchRequest,
  EngineSearchSource,
  QueryOperator,
} from './contract.js'
import { MAX_MODEL_SUMMARY_CHARS } from './contract.js'
import { clipDetail, engineFailure, type EngineFailure } from './failure.js'
import { engineJson, projectHttpError } from './http.js'
import { EXA_MANIFEST } from './registry.js'
import { parseDatePeriod, publishedDateToIso } from '../support/time.js'

const MAX_SEARCH_RESULTS = 100
const MAX_SNIPPET_CHARS = 500
const MAX_TEXT_CHARS = 10_000
const QUERY_TERM = /[a-z][a-z0-9_+-]{2,}|[\u3400-\u9fff]{2,}/g

export interface ExaEngineOptions {
  /** fetch 注入口：离线单测替身用；缺省全局 fetch。 */
  readonly fetcher?: typeof fetch
}

export function createExaEngine(options: ExaEngineOptions = {}): Engine {
  return {
    manifest: EXA_MANIFEST,
    search: (request, ctx) => search(request, ctx, options),
  }
}

async function search(
  request: EngineSearchRequest,
  ctx: EngineContext,
  options: ExaEngineOptions,
): Promise<EngineResult<EngineSearchOutcome>> {
  const apiKey = ctx.apiKey?.trim()
  if (apiKey === undefined || apiKey.length === 0) {
    return fail(engineFailure('auth', { detail: '未配置 Exa API key；Search Lite 需要普通搜索密钥。' }))
  }

  const requested = Number.isFinite(request.maxResults) ? Math.max(0, Math.trunc(request.maxResults)) : 0
  if (requested === 0) return { ok: true, outcome: { sources: [], truncated: false } }
  const limit = Math.min(requested, MAX_SEARCH_RESULTS)
  const plan = planQuery(request)
  if (plan.query.trim().length === 0) return fail(engineFailure('invalid', { detail: '搜索查询为空' }))

  const endpoint = ctx.endpoint.length > 0 ? ctx.endpoint : EXA_MANIFEST.endpoints.search!
  try {
    const payload = await engineJson<unknown>(ctx, endpoint, {
      method: 'POST',
      headers: {
        'x-api-key': apiKey,
        'content-type': 'application/json',
        'accept': 'application/json',
      },
      body: JSON.stringify({
        type: 'lite',
        query: plan.query,
        numResults: limit,
        contents: {
          highlights: { query: plan.query },
          text: { maxCharacters: MAX_TEXT_CHARS },
        },
        ...(plan.includeDomains === undefined ? {} : { includeDomains: plan.includeDomains }),
        ...(plan.excludeDomains === undefined ? {} : { excludeDomains: plan.excludeDomains }),
        ...(plan.startPublishedDate === undefined ? {} : { startPublishedDate: plan.startPublishedDate }),
        ...(plan.endPublishedDate === undefined ? {} : { endPublishedDate: plan.endPublishedDate }),
      }),
      ...(options.fetcher === undefined ? {} : { fetcher: options.fetcher }),
    })
    const parsed = parseResponse(payload, limit, plan.query)
    if ('failure' in parsed) return fail(parsed.failure)
    return {
      ok: true,
      outcome: {
        sources: parsed.sources,
        truncated: requested > MAX_SEARCH_RESULTS || parsed.truncated,
      },
    }
  } catch (error) {
    return fail(projectHttpError(error))
  }
}

function fail<T>(failure: EngineFailure): EngineResult<T> {
  return { ok: false, failure }
}

interface QueryPlan {
  readonly query: string
  readonly includeDomains?: readonly string[]
  readonly excludeDomains?: readonly string[]
  readonly startPublishedDate?: string
  readonly endPublishedDate?: string
}

/**
 * Search Lite 原生接收 site/-site 与日期过滤；lang 没有对应参数，按原 token 回拼。
 * 非法日期同样回拼，绝不静默丢弃用户操作符。
 */
function planQuery(request: EngineSearchRequest): QueryPlan {
  const syntax = request.syntax
  if (syntax === undefined) return { query: request.query }

  const unsupported = syntax.operators.filter(operator => !supportsOperator(operator)).map(operator => operator.raw)
  const combined = [syntax.bareQuery, ...unsupported].filter(part => part.length > 0).join(' ')
  const query = combined.length > 0 ? combined : request.query
  return {
    query,
    ...(syntax.domains.length === 0 ? {} : { includeDomains: syntax.domains }),
    ...(syntax.excludeDomains.length === 0 ? {} : { excludeDomains: syntax.excludeDomains }),
    ...(syntax.after === undefined ? {} : dateBoundary(syntax.after, 'start')),
    ...(syntax.before === undefined ? {} : dateBoundary(syntax.before, 'end')),
  }
}

function supportsOperator(operator: QueryOperator): boolean {
  switch (operator.kind) {
    case 'site':
    case '-site':
      return true
    case 'lang':
      return false
    case 'after':
    case 'before':
      return parseDatePeriod(operator.value) !== undefined
  }
}

/** after 含期间首日；before 严格早于期间，因此取该期间起点作为排他上界。 */
function dateBoundary(
  value: string,
  kind: 'start' | 'end',
): { readonly startPublishedDate?: string; readonly endPublishedDate?: string } {
  const period = parseDatePeriod(value)
  if (period === undefined) return {}
  const date = new Date(0)
  date.setUTCFullYear(period.year, period.month - 1, period.day)
  return kind === 'start'
    ? { startPublishedDate: date.toISOString() }
    : { endPublishedDate: date.toISOString() }
}

type ParsedResponse =
  | { readonly sources: readonly EngineSearchSource[]; readonly truncated: boolean }
  | { readonly failure: EngineFailure }

function parseResponse(payload: unknown, limit: number, query: string): ParsedResponse {
  const record = asRecord(payload)
  if (record === undefined) return { failure: providerError('响应不是 JSON 对象') }
  if (!Array.isArray(record.results)) return { failure: providerError('响应缺少 results 数组') }

  const sources: EngineSearchSource[] = []
  for (const row of record.results.slice(0, limit)) {
    const item = asRecord(row)
    if (item === undefined) continue
    const url = asHttpUrl(item.url)
    if (url === undefined) continue
    const title = asText(item.title)
    const summary = selectSummary(item.highlights, item.text, query)
    const publishedAt = publishedDateToIso(item.publishedDate)
    sources.push({
      url,
      ...(title === undefined ? {} : { title }),
      ...(summary === undefined ? {} : {
        snippet: summary.slice(0, MAX_SNIPPET_CHARS),
        summary,
      }),
      ...(publishedAt === undefined ? {} : { publishedAt }),
    })
  }
  return { sources, truncated: record.results.length > limit }
}

/**
 * 摘要优先取与查询词最相关的高亮；高亮缺失或均不相关时从正文中取包含查询词的片段。
 * 两者都没有时省略 summary，不拿标题冒充正文。
 */
function selectSummary(highlights: unknown, text: unknown, query: string): string | undefined {
  const terms = queryTerms(query)
  let best: string | undefined
  let bestScore = 0
  if (Array.isArray(highlights)) {
    const values = highlights.map(asText).filter((value): value is string => value !== undefined)
    for (const value of values) {
      const score = relevance(value, terms)
      if (best === undefined || score > bestScore) {
        best = value
        bestScore = score
      }
    }
  }
  if (best !== undefined && (terms.length === 0 || bestScore > 0)) {
    return best.slice(0, MAX_MODEL_SUMMARY_CHARS)
  }
  const body = asText(text)
  if (body !== undefined) {
    const fragment = textFragment(body, terms)
    if (fragment !== undefined) return fragment.slice(0, MAX_MODEL_SUMMARY_CHARS)
  }
  return undefined
}

function textFragment(text: string, terms: readonly string[]): string | undefined {
  if (terms.length === 0) return text.trim()
  const lower = text.toLowerCase()
  let index = -1
  let length = 0
  for (const term of terms) {
    const found = lower.indexOf(term)
    if (found >= 0 && (index < 0 || found < index)) {
      index = found
      length = term.length
    }
  }
  if (index < 0) return undefined
  const lead = Math.floor((MAX_MODEL_SUMMARY_CHARS - Math.min(length, MAX_MODEL_SUMMARY_CHARS)) / 3)
  return text.slice(Math.max(0, index - lead), Math.max(0, index - lead) + MAX_MODEL_SUMMARY_CHARS).trim()
}

function queryTerms(query: string): string[] {
  return [...new Set(query.toLowerCase().match(QUERY_TERM) ?? [])]
}

function relevance(text: string, terms: readonly string[]): number {
  const lower = text.toLowerCase()
  return terms.reduce((score, term) => score + (lower.includes(term) ? 1 : 0), 0)
}

function providerError(detail: string): EngineFailure {
  return engineFailure('provider-error', { statusCode: 200, detail: clipDetail(detail) })
}

function asRecord(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

function asText(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined
  const trimmed = value.trim()
  return trimmed.length === 0 ? undefined : trimmed
}

function asHttpUrl(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined
  try {
    const url = new URL(value)
    return url.protocol === 'http:' || url.protocol === 'https:' ? value : undefined
  } catch {
    return undefined
  }
}
