// 知乎引擎适配，覆盖搜索、热榜、直答与问题回答读取。
// 契约事实：
//   官方文档（Umi SPA）：https://developer.zhihu.com/docs?key=global_search / ?key=zhihu_search
//   / ?key=quota / ?key=hot_list / ?key=zhida
//
// 协议要点（契约原文）：
// - GET + 两个必填头：Authorization: Bearer <Access Secret>、
//   X-Request-Timestamp（秒级 Unix 时间戳，服务端校验时间窗，quota 页写明 ±10 分钟）；
//   另带 Content-Type: application/json（JSON 接口固定值）。
// - 两个搜索面：/api/v1/content/global_search（全网，Count 上限 20）与
//   /api/v1/content/zhihu_search（站内，Count 上限 10）。
// - 统一 envelope {Code, Message, Data}：Code===0 成功；30001 频率限制；其余非 0 按 provider-error 上报。
// - GET /api/v1/quota 返回 Data: Array<{APIID, APIName, TotalQuota, TotalUsed, RemainingQuota}>；
//   契约原话：该查询不消耗业务额度。
// - GET /api/v1/content/hot_list：Data: {Total, Items: [{Title, Url, ThumbnailUrl, Summary}]}，
//   Limit 默认/最大 30；契约 Item 没有发布时间字段。
// - POST /v1/chat/completions：OpenAI 兼容直答；官方只保证 model/messages/stream 三个字段语义。
//
// 拆分（docs/development.md §3.5）：本文件只负责搜索面、额度与引擎组装；
// 直答请求见 zhihu-answer.ts，热榜请求与映射见 zhihu-hot.ts，问题回答 fetch 面见
// zhihu-question.ts，公共小件见 zhihu-shared.ts。

import type {
  Engine,
  EngineContext,
  EngineResult,
  EngineSearchOutcome,
  EngineSearchRequest,
  EngineSearchSource,
  QuotaReport,
} from './contract.js'
import { clipDetail, engineFailure } from './failure.js'
import { engineJson, projectHttpError } from './http.js'
import { ZHIHU_MANIFEST } from './registry.js'
import { requestAnswer } from './zhihu-answer.js'
import { hotTopicsHandler } from './zhihu-hot.js'
import { fetchQuestionAnswers, zhihuQuestionId } from './zhihu-question.js'
import {
  asHttpUrl,
  asText,
  authHeaders,
  envelopeFailure,
  withPath,
  type ZhihuEngineOptions,
  type ZhihuEnvelope,
} from './zhihu-shared.js'

export type { ZhihuEngineOptions } from './zhihu-shared.js'

/** 两个搜索面：global=全网，zhihu=知乎站内。 */
export type ZhihuSearchFace = 'global' | 'zhihu'

/** 契约：global_search 的 Count 最大 20，zhihu_search 的 Count 最大 10。 */
const FACE_LIMIT: Record<ZhihuSearchFace, number> = { global: 20, zhihu: 10 }

/** manifest 端点 → 路径：端点值只在 registry 出现一次，适配层不重抄。 */
function endpointPath(endpoint: string | undefined): string {
  return endpoint === undefined ? '' : new URL(endpoint).pathname
}

/**
 * 契约里的两条搜索路径。global 与 quota 从 manifest 派生；站内面路径在 registry 的
 * endpoints 结构里没有槽位（search/fetch/quota），暂无派生来源，登记缺口另跟。
 */
const GLOBAL_SEARCH_PATH = endpointPath(ZHIHU_MANIFEST.endpoints.search)
const ZHIHU_SEARCH_PATH = '/api/v1/content/zhihu_search'
const QUOTA_PATH = endpointPath(ZHIHU_MANIFEST.endpoints.quota)

/** 额度响应中代表搜索能力的 APIID（契约 quota 页列出的可查询额度项）。 */
const SEARCH_API_IDS = ['global_search', 'zhihu_search'] as const

/**
 * 按查询意图选择搜索面：含「知乎」或 zhihu.com（含 site:zhihu.com，大小写不敏感）→ 站内，
 * 否则全网。纯函数，便于单测。
 */
export function zhihuSearchFace(query: string): ZhihuSearchFace {
  const normalized = query.toLowerCase()
  return normalized.includes('知乎') || normalized.includes('zhihu.com') ? 'zhihu' : 'global'
}

/**
 * 查询语法接线：知乎 API 只有 Query/Count 两个参数，没有域名/日期/语言参数。
 * 解析出的操作符在这里全部属于 unsupported，按统一规则原样回拼进发出的查询文本，
 * 绝不静默丢弃：syntax.bareQuery + 全部 operators[].raw 按原出现顺序逐字拼接
 * （大小写、路径后缀、重复 token 都不改写）。syntax 缺省（直接调用引擎的旧入口）时
 * 沿用 query 原文，行为与接线前一致。
 *
 * 裁决：组合结果为空（bareQuery 与 operators 都为空）时退回 request.query 原文——
 * 调用方确实给了查询，不发空串（空串会被上游判为参数错误）。
 */
function outgoingQuery(request: EngineSearchRequest): string {
  const syntax = request.syntax
  if (syntax === undefined) return request.query.trim()
  const combined = [syntax.bareQuery, ...syntax.operators.map((operator) => operator.raw)]
    .filter((token) => token !== '')
    .join(' ')
  return combined === '' ? request.query : combined
}

interface ZhihuItem {
  readonly Title?: string
  readonly ContentText?: string
  readonly Url?: string
  /** 契约：发布时间或更新时间戳（global 为 Int64、站内为 Int32）。 */
  readonly EditTime?: number
  /** 契约：创建时间（仅 zhihu_search 字段表列出）。 */
  readonly CreateTime?: number
}

interface ZhihuSearchData {
  readonly Items?: readonly ZhihuItem[]
  /** 契约：global_search 表示是否有下一页；zhihu_search 当前实现固定 false。 */
  readonly HasMore?: boolean
}

interface ZhihuQuotaItem {
  readonly APIID?: string
  readonly APIName?: string
  readonly TotalQuota?: number
  readonly TotalUsed?: number
  readonly RemainingQuota?: number
}

/** 解析本次搜索的请求 URL；endpointOverride 优先于装配层给的 ctx.endpoint。 */
function searchUrl(face: ZhihuSearchFace, ctx: EngineContext, options: ZhihuEngineOptions): URL {
  if (options.endpointOverride !== undefined) {
    return withPath(options.endpointOverride, face === 'global' ? GLOBAL_SEARCH_PATH : ZHIHU_SEARCH_PATH)
  }
  // ctx.endpoint 是装配层按能力解析后的端点；空串时退回 manifest。
  const base = ctx.endpoint !== '' ? ctx.endpoint : (ZHIHU_MANIFEST.endpoints.search ?? '')
  if (face === 'global') return new URL(base)
  const url = new URL(base)
  url.pathname = url.pathname.endsWith('/global_search')
    ? url.pathname.replace(/\/global_search$/u, '/zhihu_search')
    : ZHIHU_SEARCH_PATH
  url.search = ''
  url.hash = ''
  return url
}

/** 解析额度查询 URL；若 ctx.endpoint 仍是搜索面端点，则换算到同源额度端点。 */
function quotaUrl(ctx: EngineContext, options: ZhihuEngineOptions): URL {
  if (options.endpointOverride !== undefined) return withPath(options.endpointOverride, QUOTA_PATH)
  const base = ctx.endpoint !== '' ? ctx.endpoint : (ZHIHU_MANIFEST.endpoints.quota ?? '')
  const url = new URL(base)
  if (url.pathname.endsWith('/global_search') || url.pathname.endsWith('/zhihu_search')) {
    return withPath(base, QUOTA_PATH)
  }
  return url
}

/**
 * ASSUMED: 契约只写 EditTime/CreateTime 为 Int32/Int64「时间戳」，未写单位。
 * 按秒级 Unix 时间戳换算（与契约 Filter.publish_time 的「秒级时间戳」说明一致）。
 */
function timestampToIso(value: unknown): string | undefined {
  if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0) return undefined
  const date = new Date(value * 1000)
  return Number.isFinite(date.getTime()) ? date.toISOString() : undefined
}

/** Item → 归一化来源；没有可引用 HTTP(S) URL 的条目直接丢弃（契约 Url 为必返字符串）。 */
function mapItem(item: ZhihuItem): EngineSearchSource | undefined {
  const url = asHttpUrl(item.Url)
  if (url === undefined) return undefined
  const title = asText(item.Title)
  const snippet = asText(item.ContentText)
  const publishedAt = timestampToIso(item.EditTime) ?? timestampToIso(item.CreateTime)
  return {
    url,
    ...(title === undefined ? {} : { title }),
    ...(snippet === undefined ? {} : { snippet }),
    ...(publishedAt === undefined ? {} : { publishedAt }),
  }
}

function mapSearchResponse(
  envelope: ZhihuEnvelope<ZhihuSearchData>,
  maxResults: number,
  count: number,
): EngineResult<EngineSearchOutcome> {
  const failure = envelopeFailure(envelope)
  if (failure !== undefined) return { ok: false, failure }
  const data = envelope.Data
  if (data === undefined || data === null) {
    return { ok: false, failure: engineFailure('provider-error', { detail: '知乎 API 成功响应缺少 Data' }) }
  }
  if (data.Items !== undefined && !Array.isArray(data.Items)) {
    return { ok: false, failure: engineFailure('provider-error', { detail: '知乎 API 响应 Data.Items 不是数组' }) }
  }
  const mapped = (data.Items ?? [])
    .filter((item): item is ZhihuItem => typeof item === 'object' && item !== null)
    .map(mapItem)
    .filter((source): source is EngineSearchSource => source !== undefined)

  // 请求量超过该搜索面上限、上游声明还有下一页、或防御性截断，都置 truncated。
  let truncated = maxResults > count || data.HasMore === true
  let sources = mapped
  if (sources.length > count) {
    sources = sources.slice(0, count)
    truncated = true
  }
  return { ok: true, outcome: { sources, truncated } }
}

function sumField(
  entries: readonly ZhihuQuotaItem[],
  field: 'TotalQuota' | 'TotalUsed' | 'RemainingQuota',
): number | undefined {
  let total: number | undefined
  for (const entry of entries) {
    const value = entry[field]
    if (typeof value === 'number' && Number.isFinite(value)) total = (total ?? 0) + value
  }
  return total
}

/**
 * 额度响应 → QuotaReport。Data 是数组，只聚合搜索能力的两项（global_search / zhihu_search）；
 * 字段名按契约 JSON 原文：TotalQuota / TotalUsed / RemainingQuota。
 * 契约说明未配置的 API 会被省略、全部未配置时成功返回空数组——此时标 available:false（显式 N/A）。
 */
function mapQuotaResponse(envelope: ZhihuEnvelope<readonly ZhihuQuotaItem[]>): QuotaReport {
  const failed = envelopeFailure(envelope)
  if (failed !== undefined) {
    return {
      engineId: ZHIHU_MANIFEST.id,
      available: false,
      raw: clipDetail(`知乎额度查询失败：${failed.kind}（${failed.detail ?? ''}）`),
    }
  }
  const data = envelope.Data
  if (!Array.isArray(data)) {
    return { engineId: ZHIHU_MANIFEST.id, available: false, raw: '知乎额度响应缺少 Data 数组' }
  }
  const entries = data.filter((entry): entry is ZhihuQuotaItem =>
    typeof entry === 'object' && entry !== null && (SEARCH_API_IDS as readonly string[]).includes(entry.APIID ?? ''),
  )
  if (entries.length === 0) {
    return { engineId: ZHIHU_MANIFEST.id, available: false, raw: '知乎额度响应未包含搜索能力额度项' }
  }
  const used = sumField(entries, 'TotalUsed')
  const limit = sumField(entries, 'TotalQuota')
  const remaining = sumField(entries, 'RemainingQuota')
  return {
    engineId: ZHIHU_MANIFEST.id,
    available: true,
    ...(used === undefined ? {} : { used }),
    ...(limit === undefined ? {} : { limit }),
    ...(remaining === undefined ? {} : { remaining }),
    raw: clipDetail(JSON.stringify(entries)),
  }
}

/**
 * 创建知乎引擎适配。manifest 直接引用 registry；
 * 本适配有 search、fetch（问题回答读取）、hotTopics 与 quota。
 */
export function createZhihuEngine(options: ZhihuEngineOptions = {}): Engine {
  return {
    manifest: ZHIHU_MANIFEST,

    async search(request: EngineSearchRequest, ctx: EngineContext): Promise<EngineResult<EngineSearchOutcome>> {
      const query = request.query.trim()
      if (query === '') {
        return { ok: false, failure: engineFailure('invalid', { detail: '知乎搜索查询为空' }) }
      }
      const apiKey = ctx.apiKey?.trim()
      if (apiKey === undefined || apiKey === '') {
        // auth: 'key' 引擎：缺凭证是配置错误，不发请求、不降级。
        return { ok: false, failure: engineFailure('auth', { detail: '知乎引擎未配置 Access Secret' }) }
      }

      // 搜索面判定用原 query（site:zhihu.com 仍命中站内面）；发送文本才用
      // bareQuery + 回拼 token 的结果——判定输入与请求文本分开，回拼不改变面选择。
      const face = zhihuSearchFace(query)
      const outgoing = outgoingQuery(request)
      const limit = FACE_LIMIT[face]
      const requested = Number.isFinite(request.maxResults) ? Math.floor(request.maxResults) : limit
      const count = Math.max(1, Math.min(requested, limit))
      try {
        const url = searchUrl(face, ctx, options)
        url.searchParams.set('Query', outgoing)
        url.searchParams.set('Count', String(count))
        // 主搜索与直答并发：搜索 Promise 创建后立即启动直答（不 await）；直答创建时
        // 即挂 catch，搜索失败时未消费的结果不会变成未处理拒绝，直接丢弃。
        const searchPromise = engineJson<ZhihuEnvelope<ZhihuSearchData>>(ctx, url.href, {
          method: 'GET',
          fetcher: options.fetcher,
          headers: authHeaders(apiKey),
        })
        const answerPromise =
          request.wantAnswer === true && options.answer !== false
            ? requestAnswer(apiKey, request, ctx, options).catch(() => undefined)
            : undefined
        const result = mapSearchResponse(await searchPromise, request.maxResults, count)
        // 直答只是搜索的附加答案：主搜索失败时不并入，结果直接丢弃。
        if (!result.ok || answerPromise === undefined) return result
        const content = await answerPromise
        return content === undefined ? result : { ok: true, outcome: { ...result.outcome, content } }
      } catch (error) {
        // 铁律 4：引擎边界永不抛出；HTTP/网络/解析错误统一投影。
        // 429 的 retryAfterMs 由共享 projectHttpError 透传（failure.ts 复制），适配层不再重复并入。
        return { ok: false, failure: projectHttpError(error) }
      }
    },

    // 能力适用性路由（复核裁决 1）：只有问题 URL 进入知乎 fetch 面；其余 URL 在 provider
    // 派发前就被剔除（不发请求、不产生 invalid 失败）。适配器内守卫保留作纵深防御。
    fetchApplicable: url => zhihuQuestionId(url) !== undefined,

    // fetch 面只处理 zhihu.com/question/*；适配器守卫对直接调用者仍返回 invalid 且不发请求。
    fetch: (url, ctx) => fetchQuestionAnswers(url, ctx, options),

    hotTopics: hotTopicsHandler(options),

    async quota(ctx: EngineContext): Promise<QuotaReport> {
      const apiKey = ctx.apiKey?.trim()
      if (apiKey === undefined || apiKey === '') {
        return { engineId: ZHIHU_MANIFEST.id, available: false, raw: '知乎引擎未配置 Access Secret' }
      }
      try {
        const url = quotaUrl(ctx, options)
        // 只查搜索能力的两项额度；契约说明该查询不消耗业务额度。
        url.searchParams.set('APIIDs', SEARCH_API_IDS.join(','))
        const envelope = await engineJson<ZhihuEnvelope<readonly ZhihuQuotaItem[]>>(ctx, url.href, {
          method: 'GET',
          fetcher: options.fetcher,
          headers: authHeaders(apiKey),
        })
        return mapQuotaResponse(envelope)
      } catch (error) {
        const failure = projectHttpError(error)
        return {
          engineId: ZHIHU_MANIFEST.id,
          available: false,
          raw: clipDetail(`知乎额度查询失败：${failure.kind}（${failure.detail ?? ''}）`),
        }
      }
    },
  }
}
