// Firecrawl 操作端点解析；endpointOverride 只影响请求 URL，不修改 registry manifest。

import type { EngineContext } from './contract.js'
import { FIRECRAWL_MANIFEST } from './registry.js'

export type FirecrawlOperation = 'search' | 'fetch' | 'quota'

export interface FirecrawlEndpointOptions {
  readonly endpointOverride?: string
}

function manifestEndpoint(operation: FirecrawlOperation): string | undefined {
  return FIRECRAWL_MANIFEST.endpoints[operation]
}

const KNOWN_ENDPOINT_PATHS: readonly string[] = (['search', 'fetch', 'quota'] as const)
  .map(operation => manifestEndpoint(operation))
  .filter((value): value is string => value !== undefined)
  .map(value => {
    try {
      return new URL(value).pathname.replace(/\/+$/u, '')
    } catch {
      return ''
    }
  })
  .filter(path => path.length > 0)

export function resolveRequestUrl(
  operation: FirecrawlOperation,
  ctx: EngineContext,
  options: FirecrawlEndpointOptions,
): string | undefined {
  const target = manifestEndpoint(operation)
  const base = options.endpointOverride ?? ctx.endpoint
  if (base === undefined || base.length === 0) return target
  if (target === undefined) return base
  return mergeRequestUrl(base, target)
}

function mergeRequestUrl(base: string, target: string): string {
  let baseUrl: URL
  let targetUrl: URL
  try {
    baseUrl = new URL(base)
    targetUrl = new URL(target)
  } catch {
    return target
  }
  const basePath = baseUrl.pathname.replace(/\/+$/u, '')
  const targetPath = targetUrl.pathname.replace(/\/+$/u, '')
  if (basePath.endsWith(targetPath)) return baseUrl.href
  const foreignPath = KNOWN_ENDPOINT_PATHS.find(path => path !== targetPath && basePath.endsWith(path))
  if (foreignPath !== undefined) {
    baseUrl.pathname = `${basePath.slice(0, basePath.length - foreignPath.length)}${targetUrl.pathname}`
    baseUrl.search = targetUrl.search
    baseUrl.hash = ''
    return baseUrl.href
  }
  baseUrl.pathname = `${basePath}${targetPath}`
  baseUrl.search = targetUrl.search
  baseUrl.hash = ''
  return baseUrl.href
}
