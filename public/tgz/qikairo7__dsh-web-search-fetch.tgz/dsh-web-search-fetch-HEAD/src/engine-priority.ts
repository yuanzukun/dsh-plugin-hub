import type { QueryAnalysis, SearchIntent } from './search/router.js'

/** 搜索路由规则：条件从特异到泛化，首个匹配规则给出候选引擎链。 */
interface SearchRouteRule {
  readonly intent: SearchIntent
  readonly prefer?: QueryAnalysis['prefer']
  readonly engines: readonly string[]
}

const SEARCH_ROUTE_RULES: readonly SearchRouteRule[] = [
  { intent: 'community-opinion', prefer: 'developer', engines: ['firecrawl', 'tavily'] },
  { intent: 'community-opinion', engines: ['zhihu'] },
  { intent: 'chinese-web', prefer: 'developer', engines: ['firecrawl', 'tavily'] },
  { intent: 'chinese-web', engines: ['zhihu'] },
  { intent: 'vertical-data', engines: ['anysearch'] },
  { intent: 'ai-news', engines: ['aihot'] },
  { intent: 'hot-list', engines: ['aihot', 'zhihu'] },
  { intent: 'english-web', prefer: 'developer', engines: ['firecrawl', 'tavily'] },
  { intent: 'english-web', engines: ['tavily', 'firecrawl'] },
  { intent: 'research', engines: [] },
]

/** 意图 → 候选引擎 id 顺序；引擎知识只允许留在装配层。 */
export function intentEnginePriority(
  intent: SearchIntent,
  prefer?: QueryAnalysis['prefer'],
): readonly string[] {
  return SEARCH_ROUTE_RULES
    .find(rule => rule.intent === intent && (rule.prefer === undefined || rule.prefer === prefer))
    ?.engines ?? []
}
