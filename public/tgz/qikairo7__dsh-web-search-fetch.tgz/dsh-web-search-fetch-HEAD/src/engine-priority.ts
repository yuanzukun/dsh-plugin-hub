import type { QueryAnalysis, SearchIntent } from './search/router.js'
import type { SearchCandidateSpec } from './search/planner.js'

/** 搜索路由规则：条件从特异到泛化，首个匹配规则给出候选引擎链。 */
interface SearchRouteRule {
  readonly intent: SearchIntent
  readonly prefer?: QueryAnalysis['prefer']
  readonly candidates: readonly SearchCandidateSpec[]
}

const SEARCH_ROUTE_RULES: readonly SearchRouteRule[] = [
  { intent: 'community-opinion', prefer: 'developer', candidates: [
    { id: 'firecrawl', role: 'developer' },
    { id: 'tavily', role: 'developer' },
  ] },
  { intent: 'community-opinion', candidates: [{ id: 'zhihu', role: 'community' }] },
  { intent: 'chinese-web', prefer: 'developer', candidates: [
    { id: 'firecrawl', role: 'developer' },
    { id: 'tavily', role: 'developer' },
  ] },
  { intent: 'chinese-web', candidates: [{ id: 'zhihu', role: 'chinese-generic' }] },
  { intent: 'vertical-data', candidates: [{ id: 'anysearch', role: 'vertical' }] },
  { intent: 'ai-news', candidates: [{ id: 'aihot', role: 'news' }] },
  { intent: 'hot-list', candidates: [
    { id: 'aihot', role: 'hot-list' },
    { id: 'zhihu', role: 'hot-list' },
  ] },
  { intent: 'english-web', prefer: 'developer', candidates: [
    { id: 'firecrawl', role: 'developer' },
    { id: 'tavily', role: 'developer' },
  ] },
  { intent: 'english-web', candidates: [
    { id: 'tavily', role: 'english' },
    { id: 'firecrawl', role: 'english' },
  ] },
  { intent: 'research', candidates: [] },
]

/** 意图与偏好 → 抽象候选链；引擎 id 只允许留在装配层。 */
export function intentSearchCandidates(
  intent: SearchIntent,
  prefer?: QueryAnalysis['prefer'],
): readonly SearchCandidateSpec[] {
  return SEARCH_ROUTE_RULES
    .find(rule => rule.intent === intent && (rule.prefer === undefined || rule.prefer === prefer))
    ?.candidates ?? []
}

/**
 * 兼容导出：旧调用方按引擎 id 读取候选顺序。
 * 新装配路径使用 intentSearchCandidates；引擎知识仍只留在装配层。
 */
export function intentEnginePriority(
  intent: SearchIntent,
  prefer?: QueryAnalysis['prefer'],
): readonly string[] {
  return intentSearchCandidates(intent, prefer)
    .map(candidate => candidate.engineId ?? candidate.id)
}
