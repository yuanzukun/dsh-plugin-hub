import type { QueryAnalysis, SearchIntent } from './search/router.js'

/** 意图 → 候选引擎 id 顺序；引擎知识只允许留在装配层。 */
export function intentEnginePriority(
  intent: SearchIntent,
  prefer?: QueryAnalysis['prefer'],
): readonly string[] {
  switch (intent) {
    case 'community-opinion':
    case 'chinese-web':
      return prefer === 'developer' ? ['firecrawl', 'tavily'] : ['zhihu']
    case 'vertical-data':
      return ['anysearch']
    case 'ai-news':
      return ['aihot']
    case 'hot-list':
      return ['aihot', 'zhihu']
    case 'english-web':
      return prefer === 'developer' ? ['firecrawl', 'tavily'] : ['tavily', 'firecrawl']
    case 'research':
      return []
  }
}
