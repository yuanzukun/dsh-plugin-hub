import type { WebFetchResult } from '@deepseek-ai/dsh-web';
import { WebError } from '@deepseek-ai/dsh-web';
import type { FetchCandidate } from '../fetch-aggregate.js';
import { markdown, splitBlocks, cleanBlocks, challengeBlocks, paragraphChars, structured, compactTable, LISTING_TABLE_MAX_ROWS } from './blocks.js';
import type { ContentBlock } from './blocks.js';

/** Total characters the supplemental sections may add to one organized document. */
export const SUPPLEMENT_TOTAL_BUDGET_CHARS = 4_000;

/**
 * Default page budget of one organized document, in characters.
 *
 * The budget belongs to the page, not to the transport: an organized result is
 * what the caller reads in place of the page, so the default bounds it to one
 * long article. Raising `controls.maxOutputChars` raises it per deployment.
 */
export const DEFAULT_MAX_OUTPUT_CHARS = 15_000;

/** Characters one supplemental entry may add; longer entries are cut here. */
export const SUPPLEMENT_ENTRY_BUDGET_CHARS = 1_200;

/** Reference body below this many paragraph characters is reported as thin. */
export const THIN_BODY_PARAGRAPH_CHARS = 200;

/** Reference body at or above this many paragraph characters is already substantial. */
export const SUBSTANTIAL_BODY_PARAGRAPH_CHARS = 1_200;

interface Node { block: ContentBlock; refs: string[]; removed?: boolean }
interface Section { key: string; nodes: Node[] }
interface Document { candidate: FetchCandidate; id: string; sections: Section[]; blocks: ContentBlock[]; content: string }
interface Difference { section: string; variants: Node[] }
interface Addition { doc: Document; reason: string; nodes: Node[]; summaryOnly?: boolean }

function titleBlock(blocks: ContentBlock[]): ContentBlock | undefined {
  return blocks.find(block => block.kind === 'heading');
}

function normalizeHeading(text: string): string {
  return text.toLowerCase().replace(/^heading:/, '').replace(/[#*]/g, '').replace(/[\s\u00b7/-]+/g, ' ').split(/\s+/).filter(Boolean).sort().join(' ');
}

function sameHeading(a: string | undefined, b: string | undefined): boolean {
  if (!a || !b) return true;
  const left = new Set(normalizeHeading(a).split(' '));
  const right = new Set(normalizeHeading(b).split(' '));
  const shared = [...left].filter(word => right.has(word)).length;
  return shared >= Math.ceil(Math.min(left.size, right.size) * 0.8);
}

function sections(blocks: ContentBlock[], id: string): Section[] {
  const result: Section[] = [{ key: '', nodes: [] }];
  const stack: string[] = [];
  const occurrences = new Map<string, number>();
  for (const block of blocks) {
    if (block.kind === 'heading') {
      stack.length = block.level! - 1;
      stack.push(normalizeHeading(block.key));
      const path = stack.join('/');
      const occurrence = (occurrences.get(path) ?? 0) + 1;
      occurrences.set(path, occurrence);
      result.push({ key: `${path}@${occurrence}`, nodes: [] });
    }
    result.at(-1)!.nodes.push({ block, refs: [`${id}:B${block.index}`] });
  }
  return result;
}

function target(raw: string): string {
  try { const value = new URL(raw); value.hash = ''; return value.href; } catch { return raw; }
}

/** A same-resource HTTPS upgrade is allowed; other final-target changes stay isolated. */
function matchesTarget(request: string, returned: string): boolean {
  try {
    const expected = new URL(request), actual = new URL(returned);
    expected.hash = ''; actual.hash = '';
    if (expected.protocol === 'http:' && actual.protocol === 'https:'
      && !expected.port && !actual.port && !expected.username && !expected.password && !actual.username && !actual.password) {
      expected.protocol = 'https:';
    }
    return expected.href === actual.href;
  } catch { return request === returned; }
}
function language(blocks: ContentBlock[]): string {
  const text = blocks.filter(block => block.kind === 'paragraph').map(block => block.text).join('');
  const cjk = text.match(/[\u3400-\u9fff]/g)?.length ?? 0;
  const latin = text.match(/[a-z]/ig)?.length ?? 0;
  return cjk > 20 && cjk > latin ? 'cjk' : latin > 40 && latin > cjk * 2 ? 'latin' : '';
}

function version(doc: Document): string | undefined {
  return doc.blocks.filter(block => block.kind === 'paragraph')
    .flatMap(block => block.text.match(/^(?:version|版本|文档版本)\s*[:：]\s*[^\n]+/gim) ?? [])
    .join('\n').toLowerCase() || undefined;
}

/** Keep reference links and footnotes within one document's Markdown scope. */
function originalMarkdown(doc: Document): Node {
  let fenceLength = 3;
  for (const match of doc.content.matchAll(/`+/g)) fenceLength = Math.max(fenceLength, match[0].length + 1);
  const fence = '`'.repeat(fenceLength);
  const text = `${fence}markdown\n${doc.content}\n${fence}`;
  return { block: { kind: 'code', text, key: `code:${text}`, index: 1 }, refs: doc.blocks.map(block => `${doc.id}:B${block.index}`) };
}

/** Aligned number/negation variants are retained, never adjudicated or averaged. */
function variantKey(block: ContentBlock): string | undefined {
  if (!['paragraph', 'table', 'list', 'quote'].includes(block.kind)) return undefined;
  return block.key.replace(/\d+(?:[.,]\d+)*/g, '{number}').replace(/\bnot\s+|不|未|禁止/g, '');
}

/** Cross-service dedup preserves repeated occurrences within each original document. */
function mergeSection(destination: Section, incoming: Section, differences: Difference[]): void {
  const queues = new Map<string, Node[]>();
  for (const node of destination.nodes) {
    const queue = queues.get(node.block.key) ?? [];
    queue.push(node); queues.set(node.block.key, queue);
  }
  const matches = new Map<Node, Node>();
  for (const node of incoming.nodes) {
    const match = queues.get(node.block.key)?.shift();
    if (match) matches.set(node, match);
  }
  const anchorPositions = incoming.nodes.flatMap(node => matches.has(node) ? [destination.nodes.indexOf(matches.get(node)!)] : []);
  const reversed = anchorPositions.some((position, i) => i > 0 && position < anchorPositions[i - 1]!);
  if (reversed) {
    differences.push({ section: `${destination.key}（段落顺序不同）`, variants: incoming.nodes });
    return;
  }
  for (const [node, match] of matches) match.refs.push(...node.refs);
  let previous: Node | undefined;
  for (let i = 0; i < incoming.nodes.length; i++) {
    const node = incoming.nodes[i]!;
    const matched = matches.get(node);
    if (matched) { previous = matched; continue; }
    const next = incoming.nodes.slice(i + 1).map(item => matches.get(item)).find(Boolean);
    const start = previous ? destination.nodes.indexOf(previous) + 1 : 0;
    const end = next ? destination.nodes.indexOf(next) : destination.nodes.length;
    const key = variantKey(node.block);
    const variants = key ? destination.nodes.slice(start, end).filter(item => item.block.key !== node.block.key && variantKey(item.block) === key) : [];
    const existing = differences.find(item => variants.length > 0 && variants.every(variant => item.variants.includes(variant)));
    if (variants.length === 1 || existing) {
      const old = variants[0]!;
      old.removed = true;
      let difference = existing ?? differences.find(item => item.variants.includes(old));
      if (!difference) { difference = { section: destination.key, variants: [old] }; differences.push(difference); }
      difference.variants.push(node);
      destination.nodes.splice(end, 0, node); node.removed = true;
    } else {
      destination.nodes.splice(end, 0, node); previous = node;
    }
  }
}

/** Deterministic union of a single page's extracts; this never calls a language model. */
export function organizeDocuments(url: string, candidates: readonly FetchCandidate[], maxChars = DEFAULT_MAX_OUTPUT_CHARS, notes: readonly string[] = []): WebFetchResult {
  if (!candidates.length) throw new WebError('no extraction candidates', 'WEB_PROVIDER_ERROR');
  // Bound synchronous conversion and alignment work independently of output size.
  if (candidates.some(candidate => candidate.result.body.content.length > 1_000_000)) throw new WebError('extraction input too large', 'WEB_FETCH_TOO_LARGE');
  const raw = candidates.find(candidate => candidate.result.statusCode >= 200 && candidate.result.statusCode < 300 && matchesTarget(url, candidate.result.url) && structured(candidate.result.body.content));
  if (raw) {
    if (raw.result.body.content.length > maxChars) throw new WebError('structured response too large', 'WEB_FETCH_TOO_LARGE');
    return raw.result;
  }
  let removedNoise = 0;
  const documents: Document[] = candidates.map((candidate, index) => {
    const original = splitBlocks(markdown(candidate.result.body.content, candidate.result.body.kind));
    if (original.length > 2000) throw new WebError('too many extraction blocks', 'WEB_FETCH_TOO_LARGE');
    const blocks = cleanBlocks(original);
    removedNoise += original.length - blocks.length;
    const content = blocks.map(block => block.text).join('\n\n');
    return { candidate, id: `F${index + 1}`, blocks, sections: sections(blocks, `F${index + 1}`), content };
  });
  const challenge = (doc: Document) => challengeBlocks(doc.blocks);
  const matched = documents.filter(doc => matchesTarget(url, doc.candidate.result.url) && doc.candidate.result.statusCode >= 200 && doc.candidate.result.statusCode < 300 && !challenge(doc));
  // Prefer the secure final target, without mixing a different HTTP representation into it.
  const finalTarget = matched.find(doc => target(doc.candidate.result.url) !== target(url))?.candidate.result.url ?? url;
  const successful = matched.filter(doc => target(doc.candidate.result.url) === target(finalTarget));
  const firstHeading = successful[0] && titleBlock(successful[0].blocks)?.key;
  const firstVersion = successful[0] && version(successful[0]);
  const compatible = successful.filter(doc => (!firstHeading || !doc.blocks.some(block => block.kind === 'heading') || sameHeading(firstHeading, titleBlock(doc.blocks)?.key))
    && (!firstVersion || !version(doc) || version(doc) === firstVersion));
  const errors = documents.filter(doc => matchesTarget(url, doc.candidate.result.url) && !challenge(doc) && (doc.candidate.result.statusCode < 200 || doc.candidate.result.statusCode >= 300));
  const usable = compatible.length ? compatible : errors;
  if (!usable.length) {
    const reasons = documents.map(doc => `${doc.candidate.engineId}: ${!matchesTarget(url, doc.candidate.result.url) ? 'target-mismatch' : challenge(doc) ? 'login-or-challenge' : 'incompatible-document'}`);
    throw new WebError(`没有可整理的目标网页正文：返回目标不同或属于登录、挑战页面 (${reasons.join('; ')})`, 'WEB_PROVIDER_ERROR');
  }
  const reference = [...usable].sort((a, b) => paragraphChars(b.blocks) - paragraphChars(a.blocks) || b.blocks.length - a.blocks.length)[0]!;
  const referenceParagraphs = paragraphChars(reference.blocks);
  const referenceDefinitions = documents.some(doc => !challenge(doc) && doc.blocks.some(block => block.kind !== 'code' && /^ {0,3}\[[^\]\n]+\]:/m.test(block.text)));
  const main = referenceDefinitions ? [{ key: '', nodes: [originalMarkdown(reference)] }] : reference.sections;
  const additions: Addition[] = [];
  const supplementalSections = new Map<string, Section>();
  const differences: Difference[] = [];
  const heading = titleBlock(reference.blocks)?.key;
  const referenceLanguage = language(reference.blocks);
  const referenceVersion = version(reference);
  const referenceKeys = new Set(reference.blocks.map(block => block.key));
  for (const doc of documents) {
    if (doc === reference) continue;
    const otherHeading = titleBlock(doc.blocks)?.key;
    const otherLanguage = language(doc.blocks);
    const shared = doc.blocks.some(block => referenceKeys.has(block.key));
    const reason = challenge(doc) ? '登录或挑战页面，未加入主正文'
      : doc.candidate.result.statusCode < 200 || doc.candidate.result.statusCode >= 300 ? '非成功状态，未加入主正文'
      : target(doc.candidate.result.url) !== target(reference.candidate.result.url) ? '返回页面目标不同，未加入主正文'
      : heading && otherHeading && !sameHeading(heading, otherHeading) ? '标题或版本不同，未加入主正文'
      : referenceVersion && version(doc) && version(doc) !== referenceVersion ? '版本标记不同，未加入主正文'
      : referenceLanguage && otherLanguage && referenceLanguage !== otherLanguage ? '语言不同，未加入主正文'
      : !shared ? '缺少共同段落锚点，保留独立片段' : '';
    if (referenceDefinitions) {
      const node = originalMarkdown(doc);
      if (!reason && node.block.key === main[0]!.nodes[0]!.block.key) main[0]!.nodes[0]!.refs.push(...node.refs);
      else additions.push({ doc, reason: reason || '引用定义按来源隔离，保留完整原始 Markdown', nodes: challenge(doc) ? [] : [node] });
      continue;
    }
    if (reason) { additions.push({ doc, reason, nodes: challenge(doc) ? [] : doc.sections.flatMap(section => section.nodes) }); continue; }
    for (const section of doc.sections) {
      const found = main.find(item => item.key === section.key);
      if (found) mergeSection(found, section, differences);
      else {
        const supplementary = supplementalSections.get(section.key);
        if (supplementary) mergeSection(supplementary, section, differences);
        else { supplementalSections.set(section.key, section); additions.push({ doc, reason: '独有章节，保留原有顺序', nodes: section.nodes }); }
      }
    }
  }
  const chunks: string[] = [];
  // Different extractors can disagree about section levels. Merge substantial
  // identical blocks across those sections, while retaining every occurrence
  // that appears more than once within any one original extraction.
  const seenBlocks = new Map<string, Node[]>();
  for (const node of [...main.flatMap(section => section.nodes), ...additions.flatMap(addition => addition.nodes)]) {
    if (node.removed || node.block.kind === 'heading' || node.block.text.length < 32) continue;
    const previous = seenBlocks.get(node.block.key) ?? [];
    const origins = new Set(node.refs.map(ref => ref.split(':')[0]));
    const match = previous.find(item => item.refs.every(ref => !origins.has(ref.split(':')[0])));
    if (match) { match.refs.push(...node.refs); node.removed = true; }
    else { previous.push(node); seenBlocks.set(node.block.key, previous); }
  }
  let length = 0;
  let omitted = 0;
  // The footer answers one question: which extract served this page, and in
  // what state. One compact line per extract — a per-block provenance list
  // repeated for every service is what made the old output mostly overhead.
  const footer = '\n\n## 提取来源与处理说明\n\n'
    + documents.map(doc => `${doc.id}: ${doc.candidate.engineId} ${doc.candidate.result.statusCode}`).join('\n')
    + (referenceParagraphs < THIN_BODY_PARAGRAPH_CHARS
      ? `\n\nbody-thin：参照正文仅 ${referenceParagraphs} 字符（阈值 ${THIN_BODY_PARAGRAPH_CHARS}），可能不是该页的完整正文。`
      : '')
    + (removedNoise ? `\n\n已移除 ${removedNoise} 个明确的导航或页面控件内容块。` : '')
    + (referenceDefinitions ? '\n\n检测到引用定义：按来源分别展示原始 Markdown，避免链接或脚注串用。' : '')
    + (notes.length ? `\n\n${notes.join('\n')}` : '');
  const room = Math.max(0, maxChars - footer.length - 100);
  const append = (text: string, count = 1): boolean => {
    if (length + text.length + 2 > room) { omitted += count; return false; }
    chunks.push(text); length += text.length + 2;
    return true;
  };
  // Block provenance is only worth its characters when several extracts share
  // the body: with one source the marker repeats the footer. Above one source
  // the marker stays, because it is what makes a merged body auditable.
  const markerSources = new Set(candidates.map(candidate => candidate.engineId)).size;
  const render = (node: Node) => markerSources >= 2
    ? `${node.block.text}\n\n提取来源：${node.refs.join(', ')}`
    : node.block.text;
  let trimmedTables = 0;
  // A listing table is page furniture: in the rendered document it consumes the
  // same budget as prose, so it is trimmed before a paragraph ever is.
  const renderBlock = (node: Node): string => {
    if (node.block.kind !== 'table') return render(node);
    const compact = compactTable(node.block.text);
    if (compact.omittedRows > 0) trimmedTables += 1;
    return render({ ...node, block: { ...node.block, text: compact.text } });
  };
  for (const section of main) for (const node of section.nodes) if (!node.removed) append(renderBlock(node));
  if (additions.length) {
        const incompatible = additions.filter(addition => addition.nodes.length > 0
          && /^(标题或版本不同|语言不同)/.test(addition.reason));
        const incompatibleBlocks = incompatible.reduce((count, addition) => count + addition.nodes.length, 0);
        // A substantial reference body does not need every block of every
        // incompatible extract beside it; the count is the useful signal there.
        const summarize = referenceParagraphs >= SUBSTANTIAL_BODY_PARAGRAPH_CHARS
          ? incompatible.length > 0
          : incompatible.length > 1 || incompatibleBlocks > 20;
        const grouped = summarize ? additions.filter(addition => !incompatible.includes(addition)) : additions;
        if (summarize) {
          grouped.push({
            doc: incompatible[0]!.doc,
            reason: `${incompatible.length} 路提取因标题、版本或语言不同，未加入主正文；仅保留摘要以避免重复正文噪声`,
            summaryOnly: true,
            nodes: incompatible.map(addition => ({
              block: { ...addition.nodes[0]!.block, text: `${addition.doc.id}: ${addition.doc.candidate.engineId}，${addition.nodes.length} 个内容块` },
              refs: addition.nodes[0]!.refs,
            })),
          });
        }
        // Supplements are capped twice: per entry and in total. The body is the
        // answer; supplements are evidence that something else existed. The
        // budget counts the whole section — heading, separators and labels
        // included — because that is what the reader's page size sees.
        let supplementChars = 0;
        const supplementRoom = (text: string, count = 1): string | undefined => {
          const capped = text.length > SUPPLEMENT_ENTRY_BUDGET_CHARS
            ? `${text.slice(0, SUPPLEMENT_ENTRY_BUDGET_CHARS)}…`
            : text;
          if (supplementChars + capped.length + 2 > SUPPLEMENT_TOTAL_BUDGET_CHARS) { omitted += count; return undefined; }
          return capped;
        };
        const appendSupplement = (text: string, count = 1): boolean => {
          const capped = supplementRoom(text, count);
          if (capped === undefined) return false;
          if (!append(capped, count)) return false;
          supplementChars += capped.length + 2;
          return true;
        };
        const supplementHeading = '## 补充片段';
        if (supplementChars + supplementHeading.length + 2 <= SUPPLEMENT_TOTAL_BUDGET_CHARS && append(supplementHeading)) {
          supplementChars += supplementHeading.length + 2;
          // One label per source and reason: repeating the same sentence before
          // every block of one extract spends the budget on the label instead of
          // the evidence. Later blocks of that group are separated by a blank
          // line and belong to the label above them.
          let currentLabel: string | undefined;
          for (const addition of grouped) {
            const label = `${addition.doc.id}：${addition.reason}`;
            if (!addition.nodes.length) {
              const capped = supplementRoom(label);
              if (capped === undefined) continue;
              append(capped);
              supplementChars += capped.length + 2;
              continue;
            }
            for (const node of addition.summaryOnly ? addition.nodes : addition.nodes.filter(item => !item.removed)) {
              const body = addition.summaryOnly ? node.block.text : renderBlock(node);
              if (label === currentLabel) {
                if (!appendSupplement(body)) break;
                continue;
              }
              const entry = supplementRoom(`${label}\n\n${body}`);
              if (entry === undefined) break;
              if (!append(entry)) break;
              supplementChars += entry.length + 2;
              currentLabel = label;
            }
          }
        } else omitted += additions.reduce((count, addition) => count + Math.max(1, addition.nodes.length), 0);
  }
  if (differences.length) {
    if (append('## 文本差异')) {
      for (const difference of differences) append(`位置：${difference.section.replace(/heading:/g, '')}；保留原文变体，未判断哪份正确。\n\n${difference.variants.map(render).join('\n\n')}`, difference.variants.length);
    } else omitted += differences.reduce((count, difference) => count + difference.variants.length, 0);
  }
  const content = chunks.join('\n\n') + footer
    + (trimmedTables ? `\n\n已裁剪 ${trimmedTables} 个清单类表格：仅保留前 ${LISTING_TABLE_MAX_ROWS} 行，其余行未显示。` : '')
    + (omitted ? `\n\n输出预算不足，已省略 ${omitted} 个完整内容块或说明。` : '');
  if (content.length > maxChars) throw new WebError('正文输出预算不足以容纳来源说明', 'WEB_FETCH_TOO_LARGE');
  return { url: reference.candidate.result.url, statusCode: reference.candidate.result.statusCode, body: { kind: 'text', content }, truncated: omitted > 0 || documents.some(doc => !challenge(doc) && doc.candidate.result.truncated) };
}
