// 日级熔断器——v0.2 src/breaker/（types/breaker/index 三文件）合并移植，状态机原样
// （spec §5：限流冷却、日级熔断语义保留；v0.2 test/breaker.test.ts 的 344 行契约几乎原样可移植）。
// v0.3 改动（AD6）：入口新增 breakerSignalOf()，从统一失败模型投影；熔断器本身仍是不认识
// cordis/网络/定时器的纯状态机，惰性结算（无定时器，恢复由下一次查询发现）。

import type { QuotaReport } from '../engines/contract.js'
import type { EngineFailure } from '../engines/failure.js'

/** 为什么一个引擎被移出轮换。 */
export type BreakerReason = 'rate-limit' | 'quota-exhausted' | 'insufficient-credits'

/**
 * 一条熔断输入。`rate-limit` 是冷却（Retry-After 语义），其余两个是日级耗尽信号
 * （断到本地次日零点）。
 */
export interface BreakerSignal {
  readonly kind: BreakerReason
  /** Retry-After 提示（毫秒），仅 rate-limit 有意义。 */
  readonly retryAfterMs?: number
}

/** 「这个引擎现在是否在轮换外」的回答。 */
export interface BreakerStatus {
  readonly broken: boolean
  /** 恰在 broken=true 时出现。 */
  readonly reason?: BreakerReason
  /** rate-limit：冷却结束时刻。 */
  readonly cooldownUntil?: number
  /** 日级耗尽：下次本地零点。 */
  readonly resetAt?: number
}

/** 每次熔断/恢复跃迁发出的结构化事件。 */
export type BreakerEvent =
  | {
      readonly type: 'open'
      readonly engineId: string
      readonly reason: BreakerReason
      readonly at: number
      readonly until: number
    }
  | {
      readonly type: 'recovery'
      readonly engineId: string
      readonly reason: BreakerReason
      readonly at: number
    }

export interface CircuitBreakerOptions {
  /** open/recovery 事件汇；上层映射到 ctx.logger，本模块不 import cordis。 */
  onEvent?: (event: BreakerEvent) => void
  /** 唯一时钟；测试注入固定值，每个方法另接受逐调用 now。 */
  now?: () => number
  /** 无 Retry-After 的裸 rate-limit 冷却时长，默认 60s。 */
  defaultRateLimitCooldownMs?: number
  /** 指数退避上限，默认 1h。 */
  maxRateLimitCooldownMs?: number
}

/**
 * AD6 投影：统一失败模型 → 熔断输入。
 * - rate-limited → 冷却（带 retryAfterMs 则按提示）
 * - quota：statusCode 402（额度/信用耗尽，如 Firecrawl）→ insufficient-credits 日级；其余 quota → quota-exhausted 日级
 * - 其余 kind 不产生熔断输入（aborted/invalid/target-status/auth 不是引擎健康信号）
 */
export function breakerSignalOf(failure: EngineFailure): BreakerSignal | undefined {
  if (failure.kind === 'rate-limited') {
    return { kind: 'rate-limit', retryAfterMs: failure.retryAfterMs }
  }
  if (failure.kind === 'quota') {
    return failure.statusCode === 402
      ? { kind: 'insufficient-credits' }
      : { kind: 'quota-exhausted' }
  }
  return undefined
}

/**
 * 官方额度快照 → 熔断输入（AD9 投影；日检与面板刷新共用）。
 * `available && remaining !== undefined && remaining <= 0` → 日级 quota-exhausted；
 * available:false（引擎自述 N/A）与 remaining 缺失（如 Tavily「不限」）都不是耗尽信号。
 */
export function quotaReportSignal(report: QuotaReport): BreakerSignal | undefined {
  return report.available && report.remaining !== undefined && report.remaining <= 0
    ? { kind: 'quota-exhausted' }
    : undefined
}

/** 默认裸 rate-limit 冷却。 */
export const DEFAULT_RATE_LIMIT_COOLDOWN_MS = 60_000
/** 指数退避上限。 */
export const MAX_RATE_LIMIT_COOLDOWN_MS = 3_600_000

interface CooldownEntry {
  readonly reason: 'rate-limit'
  /** 连续冷却次数；一次到期即清零。 */
  streak: number
  readonly cooldownUntil: number
}

interface DailyEntry {
  readonly reason: 'quota-exhausted' | 'insufficient-credits'
  readonly resetAt: number
}

type EngineEntry = CooldownEntry | DailyEntry

/** 严格晚于 nowMs 的下一个本地零点（含月/年翻转）。 */
export function nextLocalMidnight(nowMs: number): number {
  const date = new Date(nowMs);
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1).getTime();
}

/** 渲染单条熔断日志行（上层经 ctx.logger 写出）。 */
export function formatBreakerEvent(event: BreakerEvent): string {
  if (event.type === 'open') {
    const until = new Date(event.until).toISOString();
    const expectation =
      event.reason === 'rate-limit' ? `预计恢复 ${until}` : `预计恢复 ${until}（本地次日零点）`;
    return `[熔断] 引擎 ${event.engineId} 已停用：触发原因 ${event.reason}，${expectation}`;
  }
  return `[熔断] 引擎 ${event.engineId} 熔断恢复：原触发原因 ${event.reason}`;
}

export class CircuitBreaker {
  private readonly onEvent: ((event: BreakerEvent) => void) | undefined;
  private readonly clock: () => number;
  private readonly defaultCooldownMs: number;
  private readonly maxCooldownMs: number;
  private readonly engines = new Map<string, EngineEntry>();

  constructor(options: CircuitBreakerOptions = {}) {
    this.onEvent = options.onEvent;
    this.clock = options.now ?? Date.now;
    this.defaultCooldownMs = options.defaultRateLimitCooldownMs ?? DEFAULT_RATE_LIMIT_COOLDOWN_MS;
    this.maxCooldownMs = options.maxRateLimitCooldownMs ?? MAX_RATE_LIMIT_COOLDOWN_MS;
  }

  /**
   * 记一条熔断信号并返回状态。
   * - rate-limit：按 retryAfterMs 冷却，缺省用短默认；冷却中重复触发按 hint × 2^(streak-1)
   *   指数退避（封顶 max）；hint<=0 撤销进行中的冷却。不降级日级熔断。
   * - quota-exhausted / insufficient-credits：断到本地零点；从冷却升级，当日幂等（首个原因胜出）。
   */
  recordSignal(engineId: string, signal: BreakerSignal, now: number = this.clock()): BreakerStatus {
    // 先结算已过期条目：未被查询观察到的恢复先于新信号上报。
    this.status(engineId, now);
    const entry = this.engines.get(engineId);

    if (signal.kind === 'rate-limit') {
      if (entry !== undefined && entry.reason !== 'rate-limit') return this.status(engineId, now);
      const hint = readCooldownHint(signal.retryAfterMs, this.defaultCooldownMs);
      if (hint <= 0) {
        if (entry === undefined) return { broken: false };
        this.engines.delete(engineId);
        this.emit({ type: 'recovery', engineId, reason: 'rate-limit', at: now });
        return { broken: false };
      }
      const streak = entry === undefined ? 1 : entry.streak + 1;
      const duration = Math.min(hint * 2 ** (streak - 1), this.maxCooldownMs);
      const cooldownUntil = now + duration;
      this.engines.set(engineId, { reason: 'rate-limit', streak, cooldownUntil });
      this.emit({ type: 'open', engineId, reason: 'rate-limit', at: now, until: cooldownUntil });
      return { broken: true, reason: 'rate-limit', cooldownUntil };
    }

    if (entry !== undefined && entry.reason !== 'rate-limit') return this.status(engineId, now);
    const resetAt = nextLocalMidnight(now);
    this.engines.set(engineId, { reason: signal.kind, resetAt });
    this.emit({ type: 'open', engineId, reason: signal.kind, at: now, until: resetAt });
    return { broken: true, reason: signal.kind, resetAt };
  }

  /**
   * 解除一个引擎的日级额度熔断（面板刷新拿到健康官方快照时调用）。
   * 只删 quota-exhausted / insufficient-credits 条目并发 recovery；rate-limit 冷却原样保留。
   */
  clearDaily(engineId: string, now: number = this.clock()): BreakerStatus {
    const entry = this.engines.get(engineId)
    if (entry === undefined) return { broken: false }
    if (entry.reason === 'rate-limit') return this.status(engineId, now)
    this.engines.delete(engineId)
    this.emit({ type: 'recovery', engineId, reason: entry.reason, at: now })
    return { broken: false }
  }

  /** 引擎当前是否在轮换外；未知引擎不在。 */
  isBroken(engineId: string, now: number = this.clock()): boolean {
    return this.status(engineId, now).broken;
  }

  /**
   * 当前熔断状态；未知引擎安全返回 { broken: false }。
   * 落在期限之后的查询就地结算条目——恢复事件恰好发一次，因此熔断器不需要定时器。
   */
  status(engineId: string, now: number = this.clock()): BreakerStatus {
    const entry = this.engines.get(engineId);
    if (entry === undefined) return { broken: false };
    const until = entry.reason === 'rate-limit' ? entry.cooldownUntil : entry.resetAt;
    if (now < until) {
      return entry.reason === 'rate-limit'
        ? { broken: true, reason: 'rate-limit', cooldownUntil: until }
        : { broken: true, reason: entry.reason, resetAt: until };
    }
    this.engines.delete(engineId);
    this.emit({ type: 'recovery', engineId, reason: entry.reason, at: now });
    return { broken: false };
  }

  private emit(event: BreakerEvent): void {
    this.onEvent?.(event);
  }
}

/** 归一 Retry-After 提示：有限数字原样用，其余回退默认。 */
function readCooldownHint(retryAfterMs: number | undefined, fallbackMs: number): number {
  return typeof retryAfterMs === 'number' && Number.isFinite(retryAfterMs) ? retryAfterMs : fallbackMs;
}
