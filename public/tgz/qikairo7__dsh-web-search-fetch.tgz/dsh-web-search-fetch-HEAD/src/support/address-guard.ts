// 内网地址守卫，与 SECURITY.md 的安全承诺同步。
// 动态提取把 URL 交给第三方引擎，由对方基础设施解析并抓取——回环/RFC1918 目标会离开本进程、
// 从外部触达操作者内网。本模块在任何引擎派发前拦截：
// - 字面地址直接分类（http://127.0.0.1/ 无需 DNS 即拒绝）；
// - 主机名在此解析，任一答案非公网即拒绝；解析失败不拦（守卫无法证明私有，引擎自会报错）。
// 装配层可注入静态域逃生口；当前 Config 不暴露该配置。
import { lookup } from 'node:dns/promises';
import { isIP } from 'node:net';
import ipaddr from 'ipaddr.js';
import { WebError } from '@deepseek-ai/dsh-web';

/**
 * 一个文本地址是否为非公网目的地。只接受 unicast；ipaddr.js 报告的其余范围
 * （含终点无法钉死的翻译/隧道前缀）一律拒绝。非地址文本返回 false（不归本函数管）。
 */
export function isPrivateAddress(input: string): boolean {
  const address = input.trim().replace(/^\[|\]$/g, '');
  if (isIP(address) === 0) return false;
  let parsed: ipaddr.IPv4 | ipaddr.IPv6;
  try {
    parsed = ipaddr.parse(address);
  } catch {
    return false;
  }
  const range = parsed.range();
  return range !== 'unicast';
}

/** 主机名 → 地址列表；解析失败为 undefined。 */
export type AddressLookup = (hostname: string) => Promise<readonly string[] | undefined>;

/** 默认解析器：操作系统解析器，一次性返回全部答案。 */
export const systemLookup: AddressLookup = async (hostname) => {
  try {
    return (await lookup(hostname, { all: true, order: 'verbatim' })).map(entry => entry.address);
  } catch {
    return undefined;
  }
};

/** 一次守卫检查的结果。 */
export interface AddressGuardVerdict {
  /** 仅当目的地被证明非公网时为 false。 */
  readonly allowed: boolean
  /** 作出判定的地址，供错误消息与日志。 */
  readonly address?: string
  /** 无法作出判定时的原因。 */
  readonly reason?: 'unresolvable' | 'not-a-url' | 'exempt' | 'public'
}

/**
 * 判定一个 URL 是否可交给第三方提取引擎。
 * 不抛异常；操作取消时不再等待解析器。
 */
export async function guardTargetAddress(
  rawUrl: string,
  options: { exemptHosts?: readonly string[]; lookup?: AddressLookup; signal?: AbortSignal } = {},
): Promise<AddressGuardVerdict> {
  let url: URL;
  try {
    url = new URL(rawUrl);
  } catch {
    return { allowed: true, reason: 'not-a-url' };
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return { allowed: true, reason: 'not-a-url' };

  const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (isExempt(host, options.exemptHosts)) return { allowed: true, reason: 'exempt' };

  if (isIP(host) !== 0) {
    return isPrivateAddress(host) ? { allowed: false, address: host } : { allowed: true, address: host, reason: 'public' };
  }

  const addresses = await resolveWithin((options.lookup ?? systemLookup)(host), options.signal);
  if (addresses === undefined || addresses.length === 0) return { allowed: true, reason: 'unresolvable' };
  const blocked = addresses.find(address => isPrivateAddress(address));
  if (blocked !== undefined) return { allowed: false, address: blocked };
  return { allowed: true, reason: 'public' };
}

/** 等待解析器，但操作取消时停止等待：活得比操作久的守卫保护不了任何东西。 */
async function resolveWithin(work: Promise<readonly string[] | undefined>, signal?: AbortSignal): Promise<readonly string[] | undefined> {
  if (signal === undefined) return await work;
  if (signal.aborted) return undefined;
  let stop: (() => void) | undefined;
  const cancelled = new Promise<undefined>((resolve) => {
    stop = () => resolve(undefined);
    signal.addEventListener('abort', stop, { once: true });
  });
  try {
    return await Promise.race([work, cancelled]);
  } finally {
    if (stop !== undefined) signal.removeEventListener('abort', stop);
  }
}

/** 用接缝自己的阻断码拒绝私有目的地。 */
export function blockedTargetError(rawUrl: string, address?: string): WebError {
  const detail = address === undefined ? '' : `（${address}）`;
  return new WebError(
    `目标地址${detail}不属于公网单播范围，已拒绝外发给第三方提取服务；当前版本没有豁免配置：${rawUrl}`,
    'WEB_BLOCKED_URL',
  );
}

/** host 是否命中配置的静态域（点界匹配）。 */
function isExempt(host: string, exemptHosts: readonly string[] | undefined): boolean {
  for (const domain of exemptHosts ?? []) {
    const normalized = domain.trim().toLowerCase().replace(/^\.+/, '');
    if (normalized.length === 0) continue;
    if (host === normalized || host.endsWith(`.${normalized}`)) return true;
  }
  return false;
}
