// URL 归一化唯一实现。
// 契约被 test/search-aggregate.test.ts:91-124 与 quality-regressions 钉死：
// 剥全部 utm_* 参数、剥 #fragment、协议/主机小写、根路径尾斜杠归一、不可解析 URL 原样返回。
// MDN 与 TypeScript 手册的已验证别名（http→https、retiredLocale/source=post_page、.html 剥除）保留。

/**
 * 把结果 URL 归一成去重键：每个 utm_* 参数丢弃，#fragment 丢弃，scheme/hostname 小写
 * （URL 本身已做），根路径归一使 '/' 与 '' 共键。其余参数与非根尾斜杠保持显著，
 * 仅下列已验证的 MDN / TypeScript 别名例外。
 * 不可解析的 URL 原样返回：去重可能因此漏并一次，但来源绝不被丢弃或改写成引擎没返回过的东西。
 */
export function normalizeSearchUrl(url: string): string {
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return url;
  }
  parsed.hash = '';
  if (parsed.hostname === 'developer.mozilla.org' && parsed.protocol === 'http:') parsed.protocol = 'https:';
  if (parsed.hostname === 'www.typescriptlang.org' && parsed.pathname.startsWith('/docs/handbook/') && parsed.pathname.endsWith('.html')) {
    parsed.pathname = parsed.pathname.slice(0, -5);
  }
  const kept: Array<[string, string]> = [];
  for (const [key, value] of parsed.searchParams) {
    if (key.toLowerCase().startsWith('utm_')) continue;
    if (parsed.hostname === 'developer.mozilla.org' && key === 'retiredLocale') continue;
    if (parsed.hostname === 'developer.mozilla.org' && key === 'source' && value.startsWith('post_page')) continue;
    kept.push([key, value]);
  }
  parsed.search = '';
  for (const [key, value] of kept) parsed.searchParams.append(key, value);
  return parsed.toString();
}
