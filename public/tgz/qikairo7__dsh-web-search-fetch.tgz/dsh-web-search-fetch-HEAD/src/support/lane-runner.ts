// 共享单路运行器。
// （search-aggregate.ts:436-519 dispatch 与 fetch-aggregate.ts:518-568 runLeg，
//   批判者：约 180-250 行平行结构——熔断跳过→deadline→race 中止→归类→转发熔断信号→日志）。
// 单路运行语义：
// - 每路独立 AbortController + 定时器：deadline 到点中止该路信号，挂死的请求被真正拆掉；
// - 引擎 promise 与该路中止信号 race：尊重信号的引擎以拒绝结算，忽略信号的引擎也在 deadline 被丢弃；
// - 自己的 deadline 高于引擎被拆时报告的任何东西：没在预算内完成就是 timeout；
//   同时发生的调用方取消仍然优先——那是取消不是故障，由操作层一次性上报；
// - 失败永远收敛为数据（EngineFailure），不上抛；熔断喂入由编排层用 breakerSignalOf 做。

import type { EngineResult } from '../engines/contract.js'
import type { EngineFailure } from '../engines/failure.js'
import { engineFailure, isAbortError } from '../engines/failure.js'

/** 单路结果：ok / failed / timeout / aborted（调用方取消）。 */
export type LaneOutcome<T> =
  | { readonly kind: 'ok'; readonly engineId: string; readonly result: T; readonly elapsedMs: number }
  | { readonly kind: 'failed'; readonly engineId: string; readonly failure: EngineFailure; readonly elapsedMs: number }
  | { readonly kind: 'timeout'; readonly engineId: string; readonly elapsedMs: number }
  | { readonly kind: 'aborted'; readonly engineId: string }

/** 单路日志汇（编排层注入；不传即静默）。 */
export interface LaneLogSink {
  laneInfo(engineId: string, message: string): void
  laneWarn(engineId: string, message: string): void
}

/** 哨兵：该路中止监听 resolve 到它，不与结果混淆。 */
const LANE_ABORTED = Symbol('lane-aborted')

export interface RunLaneOptions<T> {
  readonly engineId: string
  /** 操作信号（取消/总限时）；每路信号是它与该路自身 deadline 的合成。 */
  readonly signal?: AbortSignal
  /** 单路 deadline（毫秒）。 */
  readonly deadlineMs: number
  /** 引擎工作：收到该路合成信号，返回收敛后的结果。 */
  readonly work: (signal: AbortSignal) => Promise<EngineResult<T>>
  readonly log?: LaneLogSink
  /** 时钟覆盖（测试）。 */
  readonly now?: () => number
}

/**
 * 跑一路引擎调用，永不抛出。
 * 熔断跳过不在此处，由编排层在派发前过滤；
 * 本函数只负责单路执行语义。
 */
export async function runLane<T>(options: RunLaneOptions<T>): Promise<LaneOutcome<T>> {
  const { engineId, signal, deadlineMs, work, log } = options
  const now = options.now ?? Date.now
  const startedAt = now()

  const lane = new AbortController()
  const composed = signal === undefined ? lane.signal : AbortSignal.any([signal, lane.signal])
  const timer = setTimeout(() => {
    lane.abort(new Error(`per-engine deadline of ${deadlineMs} ms exceeded`))
  }, deadlineMs)

  const laneAborted = new Promise<typeof LANE_ABORTED>((resolve) => {
    if (composed.aborted) {
      resolve(LANE_ABORTED)
      return
    }
    composed.addEventListener('abort', () => resolve(LANE_ABORTED), { once: true })
  })
  const settled: Promise<EngineResult<T>> = work(composed)
  // race 可能放弃 settled；保持它的最终拒绝被观察到。
  settled.catch(() => undefined)

  let outcome: EngineResult<T> | typeof LANE_ABORTED
  try {
    outcome = await Promise.race([settled, laneAborted])
  } finally {
    clearTimeout(timer)
  }

  if (outcome === LANE_ABORTED) {
    const elapsedMs = now() - startedAt
    if (signal?.aborted) return { kind: 'aborted', engineId }
    log?.laneWarn(engineId, `超时：延迟 ${elapsedMs}ms（上限 ${deadlineMs}ms），已丢弃该路`)
    return { kind: 'timeout', engineId, elapsedMs }
  }
  const elapsedMs = now() - startedAt
  if (outcome.ok) {
    log?.laneInfo(engineId, `成功：延迟 ${elapsedMs}ms`)
    return { kind: 'ok', engineId, result: outcome.outcome, elapsedMs }
  }
  if (outcome.failure.kind === 'aborted' && signal?.aborted) return { kind: 'aborted', engineId }
  log?.laneWarn(engineId, `失败：延迟 ${elapsedMs}ms，原因 ${outcome.failure.kind}${outcome.failure.statusCode ?? ''}`)
  return { kind: 'failed', engineId, failure: outcome.failure, elapsedMs }
}

/** 把未知异常投影成 EngineFailure（引擎适配层兜底用；正常路径引擎自己投影）。 */
export function failureFromUnknown(error: unknown): EngineFailure {
  if (isAbortError(error)) return engineFailure('aborted')
  if (error instanceof Error) return engineFailure('network', { detail: error.message })
  return engineFailure('provider-error', { detail: String(error) })
}
