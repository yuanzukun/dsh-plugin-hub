// 查询结果短 TTL 缓存——ADR-0001 §8 的机制部分：归一键、调用方给定 TTL、容量上限 LRU、时钟可注入。
// support 层不认业务意图：具体 TTL 分档与绕过判定（显式时效语法）都由编排层决定，
// 本文件只提供机制。
import type { WebSearchResult } from '@deepseek-ai/dsh-web'

/** 默认容量上限（条）。 */
export const DEFAULT_QUERY_CACHE_CAPACITY = 50

export interface QueryCacheOptions {
  /** 容量上限，默认 50；非法值回退默认。 */
  capacity?: number
  /** 唯一时钟，默认 Date.now；测试注入固定/可推进时钟。 */
  now?: () => number
}

/** 一次命中：缓存结果 + 距写入时刻的整数秒数（向下取整，命中说明用）。 */
export interface QueryCacheHit {
  readonly result: WebSearchResult
  readonly ageSeconds: number
}

interface CacheEntry {
  readonly result: WebSearchResult
  readonly storedAt: number
}

/** 归一查询：首尾去空白，内部连续空白折叠为一个空格。 */
export function normalizeQuery(query: string): string {
  return query.trim().replace(/\s+/g, ' ')
}

/**
 * 缓存键：归一 query + 意图 + site: 域名（排序后拼接）+ maxResults + 配置指纹。
 * 用 NUL 分隔，避免查询文本里恰好含意图名造成拼接歧义；域名排序让 site: 书写顺序不影响命中。
 * maxResults 参与键：同查询不同条数上限不得互相复用（结果切片不同）。
 * 配置指纹由编排层提供（设置页实时配置的稳定序列化）；设置变更后键变化，旧结果不再命中。
 * intent 是调用方传入的不透明标签，本层不解析其含义。
 */
export function queryCacheKey(
  query: string,
  intent: string,
  domains: readonly string[],
  maxResults?: number,
  fingerprint?: string,
): string {
  return `${normalizeQuery(query)}\u0000${intent}\u0000${[...domains].sort().join(',')}\u0000${maxResults ?? ''}\u0000${fingerprint ?? ''}`
}

/**
 * 精确匹配的查询结果缓存；不做语义缓存。
 * - TTL 由调用方按意图传入；`ttlSeconds <= 0` 表示该意图不缓存（不读也不写）。
 * - 命中刷新 LRU 次序；写入超过容量时淘汰最久未使用的一条。
 * - 过期条目在读取时惰性删除。
 */
export class QueryCache {
  private readonly entries = new Map<string, CacheEntry>()
  private readonly capacity: number
  private readonly now: () => number

  constructor(options: QueryCacheOptions = {}) {
    const capacity = options.capacity ?? DEFAULT_QUERY_CACHE_CAPACITY
    this.capacity = Number.isFinite(capacity) && capacity >= 1 ? Math.floor(capacity) : DEFAULT_QUERY_CACHE_CAPACITY
    this.now = options.now ?? Date.now
  }

  /** 命中返回结果与年龄；过期即删除并按未命中处理。 */
  get(key: string, ttlSeconds: number): QueryCacheHit | undefined {
    if (!(ttlSeconds > 0)) return undefined
    const entry = this.entries.get(key)
    if (entry === undefined) return undefined
    const ageMs = this.now() - entry.storedAt
    // 恰满 TTL 即过期（age = ttl 不算命中）。
    if (ageMs >= ttlSeconds * 1000) {
      this.entries.delete(key)
      return undefined
    }
    // LRU：命中刷新为最新。
    this.entries.delete(key)
    this.entries.set(key, entry)
    return { result: entry.result, ageSeconds: Math.max(0, Math.floor(ageMs / 1000)) }
  }

  /** 写入；同键覆盖并刷新时间戳。ttlSeconds <= 0 直接忽略。 */
  set(key: string, result: WebSearchResult, ttlSeconds: number): void {
    if (!(ttlSeconds > 0)) return
    this.entries.delete(key)
    this.entries.set(key, { result, storedAt: this.now() })
    while (this.entries.size > this.capacity) {
      const oldest = this.entries.keys().next()
      if (oldest.done === true) break
      this.entries.delete(oldest.value)
    }
  }

  /** 当前条目数（测试与诊断用）。 */
  get size(): number { return this.entries.size }
}
