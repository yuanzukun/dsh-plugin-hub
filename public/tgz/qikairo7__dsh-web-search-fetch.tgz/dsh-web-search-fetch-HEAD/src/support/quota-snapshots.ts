// 官方额度快照仓，服务额度面板。
// 每引擎只留最近一次「官方口径」结果：ok（带数值的官方快照）或 unavailable（引擎自述 N/A、
// keyless 原因、探测失败原因）。探测抛错不经过本仓（调用方不入仓），避免把瞬时故障写成官方事实。
import type { QuotaReport } from '../engines/contract.js'

/** 单引擎官方快照：ok 带官方数值字段；unavailable 只带原因。 */
export type QuotaSnapshot =
  | {
      readonly kind: 'ok'
      readonly used?: number
      readonly limit?: number
      readonly remaining?: number
      readonly resetsAt?: string
      readonly raw?: string
      readonly fetchedAt: number
    }
  | { readonly kind: 'unavailable'; readonly reason: string; readonly fetchedAt: number }

export interface QuotaSnapshotStoreOptions {
  /** 时钟注入口：单测控制 fetchedAt；缺省 Date.now。 */
  readonly now?: () => number
}

/** available:true 但没有任何数值不构成可展示快照（「不限」也至少有 used）。 */
function hasOfficialNumber(report: QuotaReport): boolean {
  return report.used !== undefined || report.limit !== undefined || report.remaining !== undefined
}

/** unavailable 的原因优先用引擎自述原文；空原文给通用说明。 */
function reasonOf(report: QuotaReport): string {
  const raw = report.raw?.trim()
  if (raw !== undefined && raw.length > 0) return raw
  return report.available ? '官方额度响应未给出数值' : '官方额度不可用'
}

/**
 * 纯内存官方快照仓：注入时钟，不持久化（重启清零由面板脚注说明）。
 * 面板是唯一消费者；日检钩子与手动刷新都经 record() 归一，两态语义一致。
 */
export class QuotaSnapshotStore {
  private readonly now: () => number
  private readonly entries = new Map<string, QuotaSnapshot>()

  constructor(options: QuotaSnapshotStoreOptions = {}) {
    this.now = options.now ?? Date.now
  }

  /**
   * 写入一次正常 resolve 的探测结果：
   * available 且有数值 → ok；available:false 或无任何数值 → unavailable（reason 取 raw）。
   */
  record(engineId: string, report: QuotaReport): QuotaSnapshot {
    const fetchedAt = this.now()
    const snapshot: QuotaSnapshot = report.available && hasOfficialNumber(report)
      ? Object.freeze({
          kind: 'ok',
          ...(report.used === undefined ? {} : { used: report.used }),
          ...(report.limit === undefined ? {} : { limit: report.limit }),
          ...(report.remaining === undefined ? {} : { remaining: report.remaining }),
          ...(report.resetsAt === undefined ? {} : { resetsAt: report.resetsAt }),
          ...(report.raw === undefined ? {} : { raw: report.raw }),
          fetchedAt,
        })
      : Object.freeze({ kind: 'unavailable', reason: reasonOf(report), fetchedAt })
    this.entries.set(engineId, snapshot)
    return snapshot
  }

  /** 写入探测失败/超时/凭证服务异常：不冒充官方数值，只留原因。 */
  recordUnavailable(engineId: string, reason: string): QuotaSnapshot {
    const snapshot: QuotaSnapshot = Object.freeze({ kind: 'unavailable', reason, fetchedAt: this.now() })
    this.entries.set(engineId, snapshot)
    return snapshot
  }

  /** 最近一次快照；未知引擎返回 undefined（面板显示「未刷新」）。 */
  get(engineId: string): QuotaSnapshot | undefined {
    return this.entries.get(engineId)
  }
}
