// 本地额度账本，作为额度治理的本地增量部分。
// 结构：每引擎 {success, rateLimited, quotaFailures, day}，按本地日滚动清零。
// 口径：这是「估算」而不是上游余额——账本只记录我方观察到的调用结果，
// 与官方快照（引擎 quota() 日检）互补；两者都拿不到时不伪造剩余量。

/** 当日额度型失败达到该次数，视为该源本地耗尽（估算口径，不保证上游余额）。 */
export const LOCAL_QUOTA_FAILURE_THRESHOLD = 2

/** 单引擎的本地计数快照（只读视图）。 */
export interface QuotaLedgerCounts {
  readonly success: number
  readonly rateLimited: number
  readonly quotaFailures: number
  /** 本地日键（YYYY-M-D）；跨日自动清零。 */
  readonly day: string
}

/** 内部可变计数：对外只读，内部按引用累加。 */
interface MutableQuotaCounts {
  success: number
  rateLimited: number
  quotaFailures: number
  day: string
}

export interface QuotaLedgerOptions {
  /** 时钟注入口：单测控制日滚动用；缺省 Date.now。 */
  readonly now?: () => number
}

/**
 * 本地额度账本：记录每引擎成功/限流/额度失败次数，按本地日滚动。
 * 不区分 search/fetch 面——同一引擎的额度由上游账号共享，任一面的额度失败都算数。
 */
export class QuotaLedger {
  private readonly now: () => number
  private readonly entries = new Map<string, MutableQuotaCounts>()

  constructor(options: QuotaLedgerOptions = {}) {
    this.now = options.now ?? Date.now
  }

  recordSuccess(engineId: string): void { this.entry(engineId).success += 1 }

  recordRateLimited(engineId: string): void { this.entry(engineId).rateLimited += 1 }

  recordQuotaFailure(engineId: string): void { this.entry(engineId).quotaFailures += 1 }

  /**
   * 当日额度型失败是否已达「本地耗尽」阈值（默认 2 次）。
   * 估算 ≠ 上游余额：只说明本地连续观察到额度失败、值得当日跳过该源；
   * 上游可能已恢复，跨日后计数清零重新观察。
   */
  locallyExhausted(engineId: string, threshold: number = LOCAL_QUOTA_FAILURE_THRESHOLD): boolean {
    return this.entry(engineId).quotaFailures >= threshold
  }

  /** 当前本地日的计数快照；未知引擎返回全零（不创建条目语义对调用方不可见）。 */
  snapshot(engineId: string): QuotaLedgerCounts {
    return { ...this.entry(engineId) }
  }

  /** 取当日计数；跨日时以新的一天清零重建。 */
  private entry(engineId: string): MutableQuotaCounts {
    const day = localDayKey(this.now())
    const existing = this.entries.get(engineId)
    if (existing !== undefined && existing.day === day) return existing
    const fresh: MutableQuotaCounts = { success: 0, rateLimited: 0, quotaFailures: 0, day }
    this.entries.set(engineId, fresh)
    return fresh
  }
}

/** 本地日键（本地时区，与额度日检同一口径）。 */
export function localDayKey(nowMs: number): string {
  const date = new Date(nowMs)
  return `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`
}
