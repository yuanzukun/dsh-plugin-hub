/** 上游发布时间的共享归一化；只做确定性转换，不猜测不可精确换算的单位。 */

const RELATIVE_DATE = /^(?:just now|(\d+) (minute|min|hour|hr|day|week)s? ago)$/
const DATE_SHAPE = /^(\d{4})(?:-(\d{2}))?(?:-(\d{2}))?$/

export interface DatePeriod {
  readonly year: number
  readonly month: number
  readonly day: number
  readonly daySpecified: boolean
}

export function publishedDateToIso(value: unknown): string | undefined {
  if (typeof value !== 'string' || value.trim().length === 0) return undefined
  const date = new Date(value)
  return Number.isFinite(date.getTime()) ? date.toISOString() : undefined
}

export function relativePublishedDate(value: unknown, now: number): string | undefined {
  if (typeof value !== 'string') return undefined
  const match = RELATIVE_DATE.exec(value.trim().toLowerCase())
  if (match === null) return undefined
  if (match[1] === undefined) return new Date(now).toISOString()
  const amount = Number(match[1])
  const milliseconds: Record<string, number> = {
    minute: 60_000,
    min: 60_000,
    hour: 3_600_000,
    hr: 3_600_000,
    day: 86_400_000,
    week: 604_800_000,
  }
  const unit = match[2] as keyof typeof milliseconds
  const duration = milliseconds[unit]
  return duration === undefined ? undefined : new Date(now - amount * duration).toISOString()
}

export function parseDatePeriod(value: string): DatePeriod | undefined {
  const match = DATE_SHAPE.exec(value)
  if (match === null) return undefined
  const year = Number(match[1])
  const month = match[2] === undefined ? 1 : Number(match[2])
  const day = match[3] === undefined ? 1 : Number(match[3])
  if (year < 1 || month < 1 || month > 12 || day < 1) return undefined
  const parsed = new Date(0)
  parsed.setUTCFullYear(year, month - 1, day)
  return parsed.getUTCFullYear() === year
    && parsed.getUTCMonth() === month - 1
    && parsed.getUTCDate() === day
    ? { year, month, day, daySpecified: match[3] !== undefined }
    : undefined
}
