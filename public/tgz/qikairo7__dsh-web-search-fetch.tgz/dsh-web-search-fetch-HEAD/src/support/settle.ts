// 宽限窗口。
// 语义：多通道下「足够结果」出现后，继续等一个有界宽限期（500ms 起、随启动时间递减、上限 1200ms），
// 到点中止其余未完成渠道；搜索与提取聚合器共用本并发机制。
export class SettlementWindow {
  private readonly controller = new AbortController();
  readonly signal: AbortSignal;
  private timer?: ReturnType<typeof setTimeout>;
  private readonly started = Date.now();
  constructor(parent?: AbortSignal) {
    this.signal = parent ? AbortSignal.any([parent, this.controller.signal]) : this.controller.signal;
  }
  get endedEarly(): boolean { return this.controller.signal.aborted; }
  observe(sufficient: boolean): void {
    if (!sufficient || this.timer || this.signal.aborted) return;
    this.timer = setTimeout(() => this.controller.abort(new Error('sufficient results; grace period ended')),
      Math.max(500, 1200 - (Date.now() - this.started)));
  }
  finish(): void { if (this.timer) clearTimeout(this.timer); }
}
