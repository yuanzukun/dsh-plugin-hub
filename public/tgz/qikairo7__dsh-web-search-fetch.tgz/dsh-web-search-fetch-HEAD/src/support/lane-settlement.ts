// 单路结局结算：额度账本口径与熔断喂入的唯一映射。
// 搜索与提取只提交 LaneOutcome，不各自解释失败类型。

import { breakerSignalOf, type CircuitBreaker } from './breaker.js'
import type { LaneOutcome } from './lane-runner.js'

/** 单路结局的额度账本口径：只记录影响额度判断的三类。 */
export type LaneOutcomeKind = 'success' | 'rate-limited' | 'quota'

export type LaneOutcomeReporter = (engineId: string, kind: LaneOutcomeKind) => void

/** 单路结局 → 额度账本口径；超时、取消与其他失败不入账。 */
export function ledgerKindOfOutcome<T>(outcome: LaneOutcome<T>): LaneOutcomeKind | undefined {
  if (outcome.kind === 'ok') return 'success'
  if (outcome.kind !== 'failed') return undefined
  if (outcome.failure.kind === 'rate-limited') return 'rate-limited'
  if (outcome.failure.kind === 'quota') return 'quota'
  return undefined
}

/** 单路收尾：先记额度，再把结构化失败喂给熔断。 */
export class LaneSettlement {
  constructor(
    private readonly report: LaneOutcomeReporter | undefined,
    private readonly breaker?: CircuitBreaker,
  ) {}

  settle<T>(outcome: LaneOutcome<T>): void {
    const kind = ledgerKindOfOutcome(outcome)
    if (kind !== undefined) this.report?.(outcome.engineId, kind)
    if (outcome.kind !== 'failed' || this.breaker === undefined) return
    const signal = breakerSignalOf(outcome.failure)
    if (signal !== undefined) this.breaker.recordSignal(outcome.engineId, signal)
  }
}
