// 操作上下文与预算——v0.2 src/request-budget.ts 重设计移植（AD5：显式传递，替代 AsyncLocalStorage 隐式上下文）。
// v0.2 教训（critic）：searchOperation/aggregateDynamicFetch 只有包在 runOperation 内才行为正确，
// 管道与聚合器都不显式接收预算/说明/总限时；单独调用 silently 丢上下文。
// v0.3：OpContext 是显式参数，说明收集、请求预算、deadline 判定都是它的方法/字段；
//       引擎侧通过 EngineContext.countRequest 消费预算（见 engines/contract.ts）。
// v0.2 的 deadline/中止语义原样保留：总限时到 → 已完成结果照常返回 + 说明记录 + 未完成渠道取消；
// 调用方取消 → WEB_ABORTED 立即抛出。

import { WebError } from '@deepseek-ai/dsh-web'

/** 调用档（spec §3.4：balanced/deep 已删，select 模式已删）。 */
export type RuntimePreset = 'auto' | 'single' | 'multi' | 'custom' | 'free'

/** 一次操作的运行时控制快照（设置页控件 → 装配层构造）。 */
export interface RuntimeControls {
  /** 提取侧整理模式；v0.2 的 select 模式已删，字段保留给旧配置平滑读取。 */
  mode?: 'organize' | 'select'
  preset?: RuntimePreset
  /** 自动档正在处理的请求类型与文本（自动预设 breadth 判定用）。 */
  request?: 'search' | 'fetch'
  requestText?: string
  searchServices?: readonly string[]
  fetchServices?: readonly string[]
  serviceEnabled?: Readonly<Record<string, boolean>>
  maxSearchServices?: number
  maxFetchServices?: number
  maxRequests?: number
  searchDeadlineMs?: number
  fetchDeadlineMs?: number
  maxOutputChars?: number
}

/** DSH 多查询批共享的请求预算；同一个 batch signal 下所有 provider 调用共同记账。 */
export class SharedRequestBudget {
  readonly maxRequests: number
  private requests = 0

  constructor(maxRequests: number) {
    this.maxRequests = maxRequests
  }

  get requestCount(): number { return this.requests }

  get remainingRequests(): number { return Math.max(0, this.maxRequests - this.requests) }

  acquire(): boolean {
    if (this.requests >= this.maxRequests) return false
    this.requests += 1
    return true
  }
}

/**
 * 一次 provider 操作的显式上下文：并发查询与重试彼此隔离。
 * notes 是结构化操作说明（AD4：呈现层负责拼中文文案，这里只收事实行）。
 */
export class OpContext {
  readonly controls: RuntimeControls
  /** 操作合成信号（调用方取消 + 总限时）。 */
  readonly signal: AbortSignal
  private readonly caller?: AbortSignal
  readonly notes: string[] = []
  private requests = 0
  private readonly sharedRequests?: SharedRequestBudget
  readonly maxRequests: number
  private closed = false

  constructor(
    controls: RuntimeControls,
    signal: AbortSignal,
    caller: AbortSignal | undefined,
    maxRequests: number,
    sharedRequests?: SharedRequestBudget,
  ) {
    this.controls = controls
    this.signal = signal
    this.caller = caller
    this.sharedRequests = sharedRequests
    this.maxRequests = sharedRequests?.maxRequests ?? maxRequests
  }

  get requestCount(): number { return this.sharedRequests?.requestCount ?? this.requests }

  /** 操作还可派发的请求数；无预算上限时为 Infinity。 */
  get remainingRequests(): number { return this.sharedRequests?.remainingRequests ?? Math.max(0, this.maxRequests - this.requests) }

  /** 追加一条操作说明事实行。 */
  note(text: string): void { this.notes.push(text) }

  /** 总限时是否已到（区别于调用方主动取消）。 */
  get deadlineReached(): boolean { return this.signal.aborted === true && this.caller?.aborted !== true }

  /**
   * 请求预算记账：每个插件拥有的 HTTP 尝试在网络写出前先取许可。
   * @returns false 表示预算耗尽或操作已关闭，调用方必须放弃该请求。
   */
  countRequest(): boolean {
    if (this.closed || this.signal.aborted) return false
    if (this.sharedRequests !== undefined) {
      if (!this.sharedRequests.acquire()) {
        this.note('请求预算已用尽；未派发额外请求。')
        return false
      }
      return true
    }
    if (this.requests >= this.maxRequests) {
      this.note('请求预算已用尽；未派发额外请求。')
      return false
    }
    this.requests++
    return true
  }

  /** 标记操作收尾：此后不再发放请求许可。 */
  close(): void { this.closed = true }
}

/**
 * 建立一次操作：构造 deadline 信号与显式上下文，跑 work，把总限时/取消语义
 * （v0.2 runOperation 原样）套在外面。总限时到时 abort 感知的单路先完成微任务、
 * 返回幸存者；无响应的工作在下一个事件循环轮次被停住。
 */
export async function runOperation<T>(
  controls: RuntimeControls,
  face: 'search' | 'fetch',
  caller: AbortSignal | undefined,
  work: (op: OpContext) => Promise<T>,
  sharedRequests?: SharedRequestBudget,
): Promise<T> {
  const deadline = AbortSignal.timeout(face === 'search' ? controls.searchDeadlineMs ?? 15_000 : controls.fetchDeadlineMs ?? 50_000)
  const signal = caller ? AbortSignal.any([caller, deadline]) : deadline
  const op = new OpContext(controls, signal, caller, controls.maxRequests ?? 32, sharedRequests)
  let abort: (() => void) | undefined
  let timeout: ReturnType<typeof setImmediate> | undefined
  const stopped = new Promise<never>((_, reject) => {
    abort = () => {
      const error = new WebError(caller?.aborted ? 'operation aborted' : 'operation deadline exceeded',
        caller?.aborted ? 'WEB_ABORTED' : face === 'fetch' ? 'WEB_FETCH_TIMEOUT' : 'WEB_SEARCH_TIMEOUT')
      if (caller?.aborted) { reject(error); return }
      op.note('操作总限时已到；返回已完成结果，未完成服务已取消。')
      // 允许 abort 感知的单路完成微任务并返回幸存者；无响应的工作仍在下一轮事件循环被停。
      timeout = setImmediate(() => reject(caller?.aborted
        ? new WebError('operation aborted', 'WEB_ABORTED', { cause: caller.reason })
        : error))
    }
    if (signal.aborted) abort(); else signal.addEventListener('abort', abort, { once: true })
  })
  try {
    if (signal.aborted) return await stopped
    const result = await Promise.race([work(op), stopped])
    if (caller?.aborted) throw new WebError('operation aborted', 'WEB_ABORTED')
    return result
  } finally {
    op.close()
    if (abort) signal.removeEventListener('abort', abort)
    if (timeout) clearImmediate(timeout)
  }
}

/** 把操作请求文本挂到控制快照（自动预设 breadth 判定用）。 */
export function resolveRuntimeRequest(controls: RuntimeControls, request: 'search' | 'fetch', text: string): RuntimeControls {
  return controls.preset === 'auto' ? { ...controls, request, requestText: text } : controls
}

/** 已取消的单路必须能结算，即使它注入的传输层忽略信号。 */
export async function abortable<T>(work: Promise<T>, signal?: AbortSignal): Promise<T> {
  if (!signal) return work
  let abort: (() => void) | undefined
  const stopped = new Promise<never>((_, reject) => {
    abort = () => reject(new WebError('operation aborted', 'WEB_ABORTED', { cause: signal.reason }))
    if (signal.aborted) abort(); else signal.addEventListener('abort', abort, { once: true })
  })
  try { return await Promise.race([work, stopped]) }
  finally { if (abort) signal.removeEventListener('abort', abort) }
}
