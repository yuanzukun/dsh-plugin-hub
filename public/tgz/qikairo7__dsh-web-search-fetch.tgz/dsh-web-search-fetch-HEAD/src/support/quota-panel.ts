// 额度面板纯核心。
// 只组装结构化状态，不做 UI、不认识具体引擎：周期标记与 id 顺序由装配层经 manifests 注入。
// 通道（Typert 薄包装/斜杠命令）在装配层；本模块可离线单测。
import type { Engine, EngineManifest, EngineQuotaPeriod, QuotaReport } from '../engines/contract.js'
import { quotaReportSignal, type BreakerReason, type CircuitBreaker } from './breaker.js'
import type { QuotaLedger, QuotaLedgerCounts } from './quota-ledger.js'
import type { QuotaSnapshotStore } from './quota-snapshots.js'

/** 官方额度周期标记（引擎知识，由装配层映射后注入）。 */
export type QuotaPanelPeriod = EngineQuotaPeriod

/** 面板的引擎事实：manifest + 装配层映射出的周期标记。 */
export type PanelEngineManifest = EngineManifest & { readonly period: QuotaPanelPeriod }

/** 官方额度视图：未刷新 = undefined；ok 带数值；unavailable 只带原因。 */
export type OfficialQuota =
  | {
      readonly kind: 'ok'
      readonly used?: number
      readonly limit?: number
      readonly remaining?: number
      readonly resetsAt?: string
      readonly raw?: string
      readonly fetchedAt: number
    }
  | { readonly kind: 'unavailable'; readonly reason: string; readonly fetchedAt: number }
  | undefined

export interface PanelEngineRow {
  readonly id: string
  /** resolveEnabled() 派生（停用行由客户端标「已停用（未探测）」）。 */
  readonly enabled: boolean
  readonly period: QuotaPanelPeriod
  readonly official: OfficialQuota
  /** 现取本地账本快照（按本地日滚动）。 */
  readonly ledger: QuotaLedgerCounts
  /** 现取熔断状态；until = cooldownUntil ?? resetAt。 */
  readonly breaker: { readonly broken: boolean; readonly reason?: BreakerReason; readonly until?: number }
}

export interface PanelPayload {
  /** 规范本地日 YYYY-MM-DD。 */
  readonly day: string
  readonly engines: readonly PanelEngineRow[]
}

/** 单引擎探测硬超时默认值。 */
export const DEFAULT_QUOTA_PROBE_TIMEOUT_MS = 10_000
/** 一次 refresh 的总截止默认值。 */
export const DEFAULT_QUOTA_REFRESH_DEADLINE_MS = 15_000

export type QuotaProbe = (manifest: PanelEngineManifest, signal: AbortSignal) => Promise<QuotaReport>

export interface QuotaPanelOptions {
  readonly engines: readonly Engine[]
  /** registry 顺序 + 装配层周期映射。 */
  readonly manifests: readonly PanelEngineManifest[]
  readonly ledger: QuotaLedger
  readonly store: QuotaSnapshotStore
  readonly breaker: CircuitBreaker
  /** 服务开关快照（装配层由 resolveControls().serviceEnabled 派生）。 */
  readonly resolveEnabled: () => Readonly<Record<string, boolean>>
  /** 装配侧闭包 = buildContext + engine.quota；凭证解析异常必须抛 {@link QuotaCredentialError}。 */
  readonly probe: QuotaProbe
  readonly now?: () => number
  /** 单引擎探测硬超时（测试注入短值）。 */
  readonly perEngineTimeoutMs?: number
  /** 整次 refresh 总截止（测试注入短值）。 */
  readonly totalTimeoutMs?: number
}

/**
 * 凭证服务不可用：装配侧 probe 在 buildContext/凭证解析抛错时改抛本错误，
 * 面板据此给出固定原因（零请求、不喂熔断、不连坐其他引擎）。
 */
export class QuotaCredentialError extends Error {
  constructor() {
    super('凭证服务不可用')
    this.name = 'QuotaCredentialError'
  }
}

class QuotaProbeTimeoutError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'QuotaProbeTimeoutError'
  }
}

/** 规范本地日（YYYY-MM-DD，与账本/熔断的本地日口径一致）。 */
function canonicalDay(nowMs: number): string {
  const date = new Date(nowMs)
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${date.getFullYear()}-${month}-${day}`
}

/** 探测失败原因：凭证固定文案；超时保留具体期限；其余用错误原文（限长）。 */
function probeFailureReason(error: unknown): string {
  if (error instanceof QuotaCredentialError) return '凭证服务不可用'
  if (error instanceof QuotaProbeTimeoutError) return error.message
  const message = error instanceof Error ? error.message.trim() : String(error).trim()
  if (message.length === 0) return '探测失败'
  return message.length <= 200 ? message : `${message.slice(0, 200)}…`
}

/**
 * 额度面板服务：get() 现取；refresh() 探测启用且带 quota() 的引擎后现组装返回。
 * 单飞：同引擎并发 refresh 共享同一个在途探测；硬超时：每引擎 10s、整次 15s。
 */
export class QuotaPanelService {
  private readonly manifests: readonly PanelEngineManifest[]
  private readonly ledger: QuotaLedger
  private readonly store: QuotaSnapshotStore
  private readonly breaker: CircuitBreaker
  private readonly resolveEnabled: () => Readonly<Record<string, boolean>>
  private readonly probe: QuotaProbe
  private readonly now: () => number
  private readonly perEngineTimeoutMs: number
  private readonly totalTimeoutMs: number
  /** 有 quota() 的引擎 id 集（探测对象判定；停用与无端点均由装配层在此之外过滤）。 */
  private readonly quotaEngineIds: ReadonlySet<string>
  private readonly inFlight = new Map<string, Promise<QuotaReport>>()

  constructor(options: QuotaPanelOptions) {
    this.manifests = options.manifests
    this.ledger = options.ledger
    this.store = options.store
    this.breaker = options.breaker
    this.resolveEnabled = options.resolveEnabled
    this.probe = options.probe
    this.now = options.now ?? Date.now
    this.perEngineTimeoutMs = options.perEngineTimeoutMs ?? DEFAULT_QUOTA_PROBE_TIMEOUT_MS
    this.totalTimeoutMs = options.totalTimeoutMs ?? DEFAULT_QUOTA_REFRESH_DEADLINE_MS
    this.quotaEngineIds = new Set(
      options.engines.filter(engine => engine.quota !== undefined).map(engine => engine.manifest.id),
    )
  }

  /** 现组装：day/ledger/breaker 全按调用时刻取（不缓存）。 */
  get(): PanelPayload {
    return this.assemble(this.now())
  }

  /** 探测启用且带 quota() 的引擎，写快照仓与熔断投影，然后现组装返回完整 payload。 */
  async refresh(): Promise<PanelPayload> {
    const totalDeadline = this.now() + this.totalTimeoutMs
    const enabled = this.resolveEnabled()
    const targets = this.manifests.filter(
      manifest => this.isEnabled(manifest, enabled) && this.quotaEngineIds.has(manifest.id),
    )
    const settled = await Promise.allSettled(targets.map(manifest => this.runProbe(manifest, totalDeadline)))
    targets.forEach((manifest, index) => {
      const result = settled[index]!
      if (result.status === 'fulfilled') {
        this.store.record(manifest.id, result.value)
        this.applySnapshot(manifest.id, result.value, this.now())
      } else {
        // 探测失败不冒充官方数值，但作为 unavailable 态留档。
        this.store.recordUnavailable(manifest.id, probeFailureReason(result.reason))
      }
    })
    return this.assemble(this.now())
  }

  /** 官方快照 → 熔断投影：耗尽开日级；健康且 remaining>0 解除日级（rate-limit 不动）。 */
  private applySnapshot(engineId: string, report: QuotaReport, nowMs: number): void {
    const signal = quotaReportSignal(report)
    if (signal !== undefined) {
      this.breaker.recordSignal(engineId, signal, nowMs)
      return
    }
    if (report.available && report.remaining !== undefined && report.remaining > 0) {
      this.breaker.clearDaily(engineId, nowMs)
    }
  }

  /** 单飞：per-engine 在途 Promise，并发 refresh 共享同一次探测结果。 */
  private runProbe(manifest: PanelEngineManifest, totalDeadline: number): Promise<QuotaReport> {
    const existing = this.inFlight.get(manifest.id)
    if (existing !== undefined) return existing
    const promise = this.probeWithinDeadlines(manifest, totalDeadline).finally(() => {
      if (this.inFlight.get(manifest.id) === promise) this.inFlight.delete(manifest.id)
    })
    this.inFlight.set(manifest.id, promise)
    return promise
  }

  /** 每引擎硬超时与整次总截止竞速；到点 abort 探测信号并弃用结果。 */
  private async probeWithinDeadlines(manifest: PanelEngineManifest, totalDeadline: number): Promise<QuotaReport> {
    const controller = new AbortController()
    const perEngineTimer = setTimeout(
      () => controller.abort(new QuotaProbeTimeoutError(`探测超时（单引擎 ${this.perEngineTimeoutMs}ms）`)),
      this.perEngineTimeoutMs,
    )
    const remainingTotalMs = Math.max(0, totalDeadline - this.now())
    const totalTimer = setTimeout(
      () => controller.abort(new QuotaProbeTimeoutError(`探测超时（总截止 ${this.totalTimeoutMs}ms）`)),
      remainingTotalMs,
    )
    if (remainingTotalMs === 0) {
      controller.abort(new QuotaProbeTimeoutError(`探测超时（总截止 ${this.totalTimeoutMs}ms）`))
    }
    const timedOut = new Promise<never>((_, reject) => {
      const fail = () => reject(
        controller.signal.reason instanceof QuotaProbeTimeoutError
          ? controller.signal.reason
          : new QuotaProbeTimeoutError('探测超时'),
      )
      if (controller.signal.aborted) fail()
      else controller.signal.addEventListener('abort', fail, { once: true })
    })
    const work = this.probe(manifest, controller.signal)
    // race 可能放弃 work；保持它的最终拒绝被观察到。
    work.catch(() => undefined)
    try {
      return await Promise.race([work, timedOut])
    } finally {
      clearTimeout(perEngineTimer)
      clearTimeout(totalTimer)
    }
  }

  private isEnabled(manifest: PanelEngineManifest, enabled: Readonly<Record<string, boolean>>): boolean {
    return enabled[manifest.id] ?? manifest.enabledByDefault ?? false
  }

  private assemble(nowMs: number): PanelPayload {
    const enabled = this.resolveEnabled()
    return {
      day: canonicalDay(nowMs),
      engines: this.manifests.map(manifest => {
        const status = this.breaker.status(manifest.id, nowMs)
        const until = status.cooldownUntil ?? status.resetAt
        return {
          id: manifest.id,
          enabled: this.isEnabled(manifest, enabled),
          period: manifest.period,
          official: this.store.get(manifest.id),
          ledger: this.ledger.snapshot(manifest.id),
          breaker: {
            broken: status.broken,
            ...(status.reason === undefined ? {} : { reason: status.reason }),
            ...(until === undefined ? {} : { until }),
          },
        }
      }),
    }
  }
}
