// 搜索证据：把候选池与查询要求压成一组可判定事实。
// 提前停止与补派判断都消费同一份证据，不在两处重复解释官方域、域名覆盖与时效。

import type { FusedCandidate } from './fuse.js'
import { isOfficial, officialHosts, topicMatches } from './quality.js'
import type { QueryAnalysis } from './router.js'

export const QUALITY_SAMPLE_SIZE = 5
const LONG_SUMMARY_CHARS = 200

export interface SearchEvidence {
  readonly candidates: readonly FusedCandidate[]
  readonly hasAnswer: boolean
  /** 至少返回一条来源的成功路数量。 */
  readonly sourceLanes: number
  /** 通过主题匹配的候选数；提前停止只认这些候选。 */
  readonly topicMatchedCandidates: number
  /** Top5 内通过主题匹配的候选数。 */
  readonly topTopicMatchedCandidates: number
  readonly distinctHosts: number
  /** Top5 内的不同主机数。 */
  readonly topDistinctHosts: number
  /** Top5 内有可解析发布日期的候选数。 */
  readonly topDatedCandidates: number
  /** Top5 内超过质量门长度阈值的摘要数。 */
  readonly topLongSummaries: number
  readonly officialRequired: boolean
  readonly officialMatch: boolean
  readonly freshMatch: boolean
}

export interface SearchEvidenceInput {
  readonly analysis: QueryAnalysis
  readonly candidates: readonly FusedCandidate[]
  readonly hasAnswer: boolean
  readonly sourceLanes: number
  readonly now: number
}

/** 从已融合、已治理的候选池生成本轮证据。 */
export function buildSearchEvidence(input: SearchEvidenceInput): SearchEvidence {
  const explicit = input.analysis.syntax.domains
  const hosts = explicit.length > 0 ? explicit : officialHosts(input.analysis)
  const freshStart = input.now - 7 * 86_400_000
  const top = input.candidates.slice(0, QUALITY_SAMPLE_SIZE)
  return {
    candidates: input.candidates,
    hasAnswer: input.hasAnswer,
    sourceLanes: input.sourceLanes,
    topicMatchedCandidates: input.candidates.filter(candidate => topicMatches(input.analysis, candidate)).length,
    topTopicMatchedCandidates: top.filter(candidate => topicMatches(input.analysis, candidate)).length,
    distinctHosts: uniqueHosts(input.candidates),
    topDistinctHosts: uniqueHosts(top),
    topDatedCandidates: top.filter(hasDate).length,
    topLongSummaries: top.filter(candidate => (candidate.summary?.length ?? 0) > LONG_SUMMARY_CHARS).length,
    officialRequired: hosts.length > 0,
    officialMatch: input.candidates.some(candidate =>
      isOfficial(candidate.url, hosts) && topicMatches(input.analysis, candidate)),
    freshMatch: input.candidates.some(candidate => {
      const timestamp = candidate.publishedAt === undefined ? undefined : Date.parse(candidate.publishedAt)
      return timestamp !== undefined && Number.isFinite(timestamp) && timestamp >= freshStart
    }),
  }
}

function hasDate(candidate: FusedCandidate): boolean {
  if (candidate.publishedAt === undefined) return false
  return Number.isFinite(Date.parse(candidate.publishedAt))
}

/**
 * 宽限窗口的提前停止条件：三路有来源，候选达到请求宽度，且显式/项目官方域已命中。
 * 这是延迟策略，不代表查询整体充分；整体补派由 assessSearchSufficiency 判定。
 */
export function shouldSettleEarly(
  evidence: SearchEvidence,
  maxResults: number | undefined,
): boolean {
  return evidence.sourceLanes >= 3
    && evidence.topicMatchedCandidates >= (maxResults ?? 8)
    && (!evidence.officialRequired || evidence.officialMatch)
}

function uniqueHosts(candidates: readonly FusedCandidate[]): number {
  const hosts = new Set<string>()
  for (const candidate of candidates) {
    try { hosts.add(new URL(candidate.url).hostname.replace(/^www\./, '')) } catch { hosts.add(candidate.url) }
  }
  return hosts.size
}
