// 单路派发与结算（AD3/AD6）：一轮 lane 的启动、宽限窗口喂入、熔断与额度账本投影集中在此。
// 行为与 v0.3 内联骨架一致：每路独立 deadline、失败收敛为数据、熔断一处喂入。

import type { WebSearchRequest } from '@deepseek-ai/dsh-web'

import type { Engine, EngineResult, EngineSearchOutcome, EngineSearchRequest, VerticalRequest } from '../engines/contract.js'
import { breakerSignalOf, type CircuitBreaker } from '../support/breaker.js'
import type { OpContext } from '../support/budget.js'
import { type LaneOutcome, runLane } from '../support/lane-runner.js'
import type { SettlementWindow } from '../support/settle.js'
import type { BuildEngineContext, LaneOutcomeKind, SearchLogSink } from './aggregate.js'
import { rrfFuse } from './fuse.js'
import { renderNote } from './output.js'
import { multiChannelPreset } from './preset.js'
import { isOfficial, officialHosts, topicMatches } from './quality.js'
import { parseQuerySyntax } from './query-syntax.js'

type Outcome = LaneOutcome<EngineSearchOutcome>

/** 派发器依赖：引擎表、熔断、上下文构造、日志与时限。 */
export interface LaneDispatcherOptions {
  readonly engines: readonly Engine[]
  readonly breaker: CircuitBreaker
  readonly buildContext: BuildEngineContext
  readonly logger: SearchLogSink
  readonly maxFanoutMs: number
  readonly rrfK: number
  readonly now: () => number
  readonly onLaneOutcome: ((engineId: string, kind: LaneOutcomeKind) => void) | undefined
}

/** 一轮引擎派发的执行器：启动 lane、喂宽限窗口、结算熔断与额度账本。 */
export class LaneDispatcher {
  private readonly engines: readonly Engine[]
  private readonly breaker: CircuitBreaker
  private readonly buildContext: BuildEngineContext
  private readonly logger: SearchLogSink
  private readonly maxFanoutMs: number
  private readonly rrfK: number
  private readonly now: () => number
  private readonly onLaneOutcome: ((engineId: string, kind: LaneOutcomeKind) => void) | undefined

  constructor(options: LaneDispatcherOptions) {
    this.engines = options.engines
    this.breaker = options.breaker
    this.buildContext = options.buildContext
    this.logger = options.logger
    this.maxFanoutMs = options.maxFanoutMs
    this.rrfK = options.rrfK
    this.now = options.now
    this.onLaneOutcome = options.onLaneOutcome
  }

  /** 一轮派发：每路 runLane + acceptor 喂宽限窗口；窗口在此关闭。 */
  async dispatchRound(
    lanes: readonly {
      engine: Engine
      query: string
      vertical?: VerticalRequest
      wantAnswer?: boolean
      freshness?: 'news'
    }[],
    window: SettlementWindow,
    request: WebSearchRequest,
    op: OpContext,
    laneDeadlineMs = this.maxFanoutMs,
  ): Promise<Outcome[]> {
    const accept = this.laneAcceptor(request, window, op)
    try {
      return await Promise.all(lanes.map(({ engine, query, vertical, wantAnswer, freshness }) =>
        runLane({
          engineId: engine.manifest.id,
          signal: window.signal,
          deadlineMs: laneDeadlineMs,
          now: this.now,
          work: async laneSignal => this.searchWithKeylessFallback(engine, laneDeadlineMs, {
            query,
            maxResults: request.maxResults ?? 8,
            syntax: parseQuerySyntax(query),
            ...(vertical === undefined ? {} : { vertical }),
            ...(wantAnswer === true ? { wantAnswer: true } : {}),
            ...(freshness === undefined ? {} : { freshness }),
          }, laneSignal, op),
        }).then(outcome => { this.feedBreaker(outcome); return accept(outcome) }),
      ))
    } finally { window.finish() }
  }

  /** 热点榜单路派发：与普通路共用 runLane 的超时/失败投影与熔断喂入。 */
  async dispatchHotTopics(engine: Engine, window: SettlementWindow, op: OpContext): Promise<Outcome[]> {
    try {
      const outcome = await runLane({
        engineId: engine.manifest.id,
        signal: window.signal,
        deadlineMs: this.maxFanoutMs,
        now: this.now,
        work: async laneSignal => engine.hotTopics!(
          await this.buildContext(engine.manifest, op, { signal: laneSignal, deadline: this.now() + this.maxFanoutMs, face: 'search' }),
        ),
      })
      this.feedBreaker(outcome)
      return [outcome]
    } finally { window.finish() }
  }

  /**
   * 单路搜索 + 额度耗尽同槽降级（ADR-0001 §12 产品裁决）：keyless-fallback 引擎在带 key 调用
   * 遭遇 quota 失败时，用去掉 apiKey 的同一引擎上下文重试一次——仍在同一 lane、同一 deadline
   * 与请求预算内。auth 失败绝不降级（R6 原义：凭证无效不静默改匿名）。
   */
  private async searchWithKeylessFallback(
    engine: Engine,
    laneDeadlineMs: number,
    request: EngineSearchRequest,
    laneSignal: AbortSignal,
    op: OpContext,
  ): Promise<EngineResult<EngineSearchOutcome>> {
    const context = await this.buildContext(engine.manifest, op, { signal: laneSignal, deadline: this.now() + laneDeadlineMs, face: 'search' })
    const result = await engine.search!(request, context)
    // 只有该引擎的 search 面确实支持免钥时才降级：Firecrawl 的 keyless free tier 仅覆盖
    // fetch，search 匿名请求受 IP 风控必 403，重试只会把 quota 失败误报成 auth。
    const keylessSearch = engine.manifest.keylessCapabilities === undefined
      || engine.manifest.keylessCapabilities.includes('search')
    if (result.ok
      || result.failure.kind !== 'quota'
      || engine.manifest.auth !== 'keyless-fallback'
      || !keylessSearch
      || context.apiKey === undefined
      || context.apiKey.trim().length === 0) return result
    op.note(renderNote({ id: 'keyless-fallback' }))
    const { apiKey: _dropped, ...anonymous } = context
    return await engine.search!(request, anonymous)
  }

  /** 单路收尾统一入口：额度账本上报 + 失败路的熔断喂入（AD6：统一失败模型 → 熔断信号，一处投影）。 */
  private feedBreaker(outcome: Outcome): void {
    this.reportLaneOutcome(outcome)
    if (outcome.kind !== 'failed') return
    const signal = breakerSignalOf(outcome.failure)
    if (signal !== undefined) this.breaker.recordSignal(outcome.engineId, signal)
  }

  /** 额度账本上报：成功/限流/额度三类结局入账；空结果仍算成功（HTTP 层成功），其余结局不入账。 */
  private reportLaneOutcome(outcome: Outcome): void {
    if (this.onLaneOutcome === undefined) return
    if (outcome.kind === 'ok') {
      this.onLaneOutcome(outcome.engineId, 'success')
      return
    }
    if (outcome.kind !== 'failed') return
    if (outcome.failure.kind === 'rate-limited') this.onLaneOutcome(outcome.engineId, 'rate-limited')
    else if (outcome.failure.kind === 'quota') this.onLaneOutcome(outcome.engineId, 'quota')
  }

  /** 逐路记录器：喂 SettlementWindow 的「足够」判定（v0.2 laneAcceptor 语义原样）。 */
  private laneAcceptor(request: WebSearchRequest, window: SettlementWindow, op: OpContext): (outcome: Outcome) => Outcome {
    const hosts = officialHosts(request.query)
    const completed: Outcome[] = []
    return (outcome: Outcome): Outcome => {
      completed.push(outcome)
      const successes = completed.filter((item): item is Extract<Outcome, { kind: 'ok' }> => item.kind === 'ok')
      const candidates = rrfFuse(successes.map(item => {
        const group = this.upstreamGroup(item.engineId)
        return { engineId: item.engineId, sources: item.result.sources, ...(group === undefined ? {} : { group }) }
      }), this.rrfK)
      const enough = new Set(successes.filter(item => item.result.sources.length > 0).map(item => item.engineId)).size >= 3
        && candidates.filter(item => topicMatches(request.query, item)).length >= (request.maxResults ?? 8)
        && (!hosts.length || candidates.some(item => isOfficial(item.url, hosts) && topicMatches(request.query, item)))
      window.observe(multiChannelPreset(op.controls) && enough)
      return outcome
    }
  }

  /** 引擎的上游分组（manifest 单一事实源）；未知引擎返回 undefined。 */
  private upstreamGroup(engineId: string): string | undefined {
    return this.engines.find(engine => engine.manifest.id === engineId)?.manifest.upstreamGroup
  }
}
