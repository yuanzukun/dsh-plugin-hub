// 搜索/提取的预设与服务选择策略——v0.2 request-budget.ts 的策略部分移植（spec §5：single/multi/auto 保留，
// balanced/deep 删除；free 名单从 registry 派生，AD1 单一事实源）。
// v0.3 改动（AD5）：全部函数显式接收 OpContext/RuntimeControls，不再读 AsyncLocalStorage；
// 说明经 op.note() 收集（AD4：这里只收事实行，呈现层拼中文）。
// v0.4 宽度归一（ADR-0001 §3）：auto 宽度消费路由意图，不再维护第二份关键词表。

import type { OpContext, RuntimeControls } from '../support/budget.js'
import type { SearchIntent } from './router.js'

/** 参与服务选择的引擎最小形状（manifest 投影）。 */
export interface SelectableService {
  readonly id: string
  /** 免费额度型（额度分档与免费名单展示用）；free 预设不使用此位，见 keyless。 */
  readonly free: boolean
  /** 免密钥型：无需用户凭证即可调用；free 预设按此过滤。 */
  readonly keyless: boolean
  /**
   * 可免钥调用的能力面；省略表示全部能力。
   * free 预设按当前 face 过滤：Firecrawl 只有 fetch 面免钥，search 不进入 free 预设。
   */
  readonly keylessCapabilities?: readonly string[]
}

/**
 * 选择一次操作派发的服务。
 * @param items - 候选服务（含 free/keyless 标记），派发顺序。
 * @param op - 操作上下文（控制快照 + 说明收集）。
 * @param face - 能力面。
 * @param ready - 凭证/可用性探测（可选）。
 * @param capOverride - 显式宽度覆盖（单通道空结果补派等场景自报选择时用）。
 * @param noteSelection - false 时补派方自行记说明，不重复通用选择行。
 * @param intent - 路由意图（仅搜索面 auto 宽度使用；缺省按单路处理）。
 * @param intentOrder - 意图映射的引擎 id 顺序；提供时由它决定派发顺序，`searchServices`
 *   退为成员资格过滤；缺省时按用户 `searchServices` 顺序（未配置则保持进入顺序）。
 */
export async function selectServices<T extends SelectableService>(
  items: readonly T[],
  op: OpContext,
  face: 'search' | 'fetch',
  ready?: (id: string, face: 'search' | 'fetch') => Promise<boolean>,
  capOverride?: number,
  noteSelection = true,
  intent?: SearchIntent,
  intentOrder?: readonly string[],
): Promise<T[]> {
  const controls = op.controls
  const chosen = face === 'search' ? controls.searchServices : controls.fetchServices
  const cap = capOverride ?? resolveAutoCap(controls, face, op, intent, noteSelection)
  const ordered = intentOrder !== undefined
    ? orderByIntent(items, intentOrder)
    : chosen ? [...items].sort((a, b) => chosen.indexOf(a.id) - chosen.indexOf(b.id)) : [...items]
  const allowed = ordered.filter(item =>
    (op.controls.serviceEnabled?.[item.id] ?? true)
    && (!chosen || chosen.includes(item.id))
    && (controls.preset !== 'free'
      || (item.keyless
        && (item.keylessCapabilities === undefined || item.keylessCapabilities.includes(face)))),
  )
  const available = await Promise.all(allowed.map(async item => !ready || await ready(item.id, face)))
  const usable = allowed.filter((_, index) => available[index])
  const selected = usable.slice(0, cap)
  if (noteSelection) {
    op.note(`实际选择 ${selected.length} 路${face === 'search' ? '搜索' : '提取'}服务。`)
    if (usable.length > selected.length) op.note(`服务数量上限：仅派发 ${selected.length} 路，未派发 ${usable.length - selected.length} 路。`)
  }
  return selected
}

/** 按意图序稳定排序：未知 id 排后并保持原有相对顺序（ADR-0001 §2）。 */
function orderByIntent<T extends SelectableService>(items: readonly T[], intentOrder: readonly string[]): T[] {
  const rank = new Map(intentOrder.map((id, index) => [id, index]))
  return [...items].sort((a, b) => (rank.get(a.id) ?? intentOrder.length) - (rank.get(b.id) ?? intentOrder.length))
}

/**
 * 一次操作可派发的服务数。预设直接点名宽度（single=1 路、multi=全量）；
 * auto 消费路由意图：research/ai-news 倾向多路，其余意图单路（ADR-0001 §3）。
 * fetch 面保留 URL 形状信号：自动两段式探测已先花 1 次请求，普通页仍可在探测不足时展开。
 */
export function resolveAutoCap(
  controls: RuntimeControls,
  face: 'search' | 'fetch',
  op?: OpContext,
  intent?: SearchIntent,
  noteSelection = true,
): number {
  const limit = face === 'search' ? controls.maxSearchServices ?? 5 : controls.maxFetchServices ?? 5
  // 宽度说明只在通用选择记一次：专属路/补派等二次调用传 false，避免同一操作重复刷行。
  const note = (text: string) => { if (noteSelection) op?.note(text) }
  switch (controls.preset) {
    case 'single':
      note('单通道预设：只派发 1 路服务。')
      return Math.min(limit, 1)
    case 'multi':
      note(`多通道预设：最多派发 ${limit} 路服务。`)
      return limit
    case 'auto':
      break
    default:
      return limit
  }
  if (face === 'search') {
    const multi = intent === 'research' || intent === 'ai-news'
    const cap = multi ? limit : Math.min(limit, 1)
    note(`自动档按意图判定为${multi ? '多通道' : '单通道'}（${cap} 路）。`)
    return cap
  }
  const url = controls.requestText ?? ''
  const staticLike = /\.(?:txt|text|xml|json|md|markdown|csv|tsv|rss|atom|yaml|yml|log|ini|toml|ics|vtt|srt)(?:[?#]|$)/i.test(url)
  const documentationLike = /(?:docs?|documentation|developer|github\.com|stackoverflow\.com|wikipedia\.org)/i.test(url)
  const cap = staticLike ? Math.min(limit, 3) : documentationLike ? Math.min(limit, 5) : limit
  note(`自动档判定为${staticLike ? '轻量提取' : documentationLike ? '文档提取' : '深度提取'}（${cap} 路）。`)
  return cap
}

/** 单路语义的意图（ADR-0001 §3）：research/ai-news 之外按单路处理。 */
const SINGLE_CHANNEL_INTENTS: ReadonlySet<SearchIntent> = new Set([
  'community-opinion', 'chinese-web', 'english-web', 'vertical-data', 'hot-list',
])

/** 本次操作的搜索宽度是否解析为单通道（自动档补派判定用）。 */
export function singleChannelSearch(intent: SearchIntent, controls: RuntimeControls): boolean {
  if (controls.preset === 'single') return true
  if (controls.preset !== 'auto') return false
  return SINGLE_CHANNEL_INTENTS.has(intent)
}

/** 当前预设是否派发多路（宽限窗口是否可能提前收掉慢渠道）。 */
export function multiChannelPreset(controls: RuntimeControls): boolean {
  return controls.preset !== 'single'
}
