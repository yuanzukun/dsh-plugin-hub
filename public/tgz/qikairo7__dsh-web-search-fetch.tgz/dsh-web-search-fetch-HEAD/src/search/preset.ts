// 服务选择策略：搜索首轮一路；提取按 URL 形状决定升级宽度。
// 全部函数显式接收 OpContext/RuntimeControls，不再读 AsyncLocalStorage；
// 说明经 op.note() 收集事实行，呈现层拼中文。

import type { OpContext, RuntimeControls } from '../support/budget.js'

/** 参与服务选择的引擎最小形状（manifest 投影）。 */
export interface SelectableService {
  readonly id: string
}

/**
 * 选择一次操作派发的服务。
 * @param items - 候选服务，派发顺序。
 * @param op - 操作上下文（控制快照 + 说明收集）。
 * @param face - 能力面。
 * @param ready - 凭证/可用性探测（可选）。
 * @param capOverride - 显式宽度覆盖（单通道结果不足补派等场景自报选择时用）。
 * @param noteSelection - false 时补派方自行记说明，不重复通用选择行。
 * @param intentOrder - 意图映射的引擎 id 顺序；提供时由它决定派发顺序，`searchServices`
 *   退为成员资格过滤；缺省时按用户 `searchServices` 顺序（未配置则保持进入顺序）。
 */
export async function selectServices<T extends SelectableService>(
  items: readonly T[],
  op: OpContext,
  face: 'search' | 'fetch',
  ready?: (id: string, face: 'search' | 'fetch') => Promise<boolean>,
  capOverride?: number,
  noteSelection = true,
  intentOrder?: readonly string[],
): Promise<T[]> {
  const controls = op.controls
  const chosen = face === 'search' ? controls.searchServices : controls.fetchServices
  const cap = capOverride ?? resolveServiceCap(controls, face, op, noteSelection)
  const ordered = intentOrder !== undefined
    ? orderByIntent(items, intentOrder)
    : chosen ? [...items].sort((a, b) => chosen.indexOf(a.id) - chosen.indexOf(b.id)) : [...items]
  const allowed = ordered.filter(item =>
    (op.controls.serviceEnabled?.[item.id] ?? true)
    && (!chosen || chosen.includes(item.id))
  )
  const available = await Promise.all(allowed.map(async item => !ready || await ready(item.id, face)))
  const usable = allowed.filter((_, index) => available[index])
  const selected = usable.slice(0, cap)
  if (noteSelection) {
    op.note(`实际选择 ${selected.length} 路${face === 'search' ? '搜索' : '提取'}服务。`)
    if (usable.length > selected.length) op.note(`服务数量上限：仅派发 ${selected.length} 路，未派发 ${usable.length - selected.length} 路。`)
  }
  return selected
}

/** 按意图序稳定排序：未知 id 排后并保持原有相对顺序（ADR-0001 §2）。 */
function orderByIntent<T extends SelectableService>(items: readonly T[], intentOrder: readonly string[]): T[] {
  const rank = new Map(intentOrder.map((id, index) => [id, index]))
  return [...items].sort((a, b) => (rank.get(a.id) ?? intentOrder.length) - (rank.get(b.id) ?? intentOrder.length))
}

/**
 * 一次操作可派发的服务数。搜索首轮恒为一路，补派由质量评估触发（ADR-0002）。
 * 提取保留 URL 形状信号：两段式探测已先花 1 次请求，不足时再按宽度整理。
 */
export function resolveServiceCap(
  controls: RuntimeControls,
  face: 'search' | 'fetch',
  op?: OpContext,
  noteSelection = true,
): number {
  const limit = controls.maxFetchServices ?? 5
  // 宽度说明只在通用选择记一次：专属路/补派等二次调用传 false，避免同一操作重复刷行。
  const note = (text: string) => { if (noteSelection) op?.note(text) }
  if (face === 'search') {
    note('首轮派发单通道（1 路）。')
    return 1
  }
  const url = controls.requestText ?? ''
  const staticLike = /\.(?:txt|text|xml|json|md|markdown|csv|tsv|rss|atom|yaml|yml|log|ini|toml|ics|vtt|srt)(?:[?#]|$)/i.test(url)
  const documentationLike = /(?:docs?|documentation|developer|github\.com|stackoverflow\.com|wikipedia\.org)/i.test(url)
  const cap = staticLike ? Math.min(limit, 3) : documentationLike ? Math.min(limit, 5) : limit
  note(`判定为${staticLike ? '轻量提取' : documentationLike ? '文档提取' : '深度提取'}（${cap} 路）。`)
  return cap
}
