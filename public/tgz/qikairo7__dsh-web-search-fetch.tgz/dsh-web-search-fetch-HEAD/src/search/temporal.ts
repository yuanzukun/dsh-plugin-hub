// 搜索结果的日期治理：显式日期窗口过滤，热点查询优先保留新鲜结果。

import type { QuerySyntax } from '../engines/contract.js'
import { parseDatePeriod } from '../support/time.js'
import type { QueryAnalysis } from './router.js'

export interface DateGovernanceResult<T> {
  readonly candidates: readonly T[]
  readonly omitted: number
}


export function governDates<T extends { readonly publishedAt?: string }>(
  analysis: QueryAnalysis,
  candidates: readonly T[],
  now: number,
): DateGovernanceResult<T> {
  const explicit = explicitWindow(analysis.syntax)
  const freshness = explicit === undefined && (analysis.intent === 'ai-news' || analysis.intent === 'hot-list')
  if (explicit === undefined && !freshness) return { candidates, omitted: 0 }

  const kept: T[] = []
  let omitted = 0
  for (const candidate of candidates) {
    const timestamp = candidate.publishedAt === undefined ? undefined : Date.parse(candidate.publishedAt)
    if (timestamp !== undefined && Number.isFinite(timestamp) && explicit !== undefined && !inExplicitWindow(timestamp, explicit)) {
      omitted += 1
      continue
    }
    kept.push(candidate)
  }

  const freshStart = now - 7 * 86_400_000
  return {
    candidates: [...kept].sort((left, right) => dateRank(left, explicit, freshStart) - dateRank(right, explicit, freshStart)),
    omitted,
  }
}

interface ExplicitWindow {
  readonly start?: number
  readonly endExclusive?: number
}

function explicitWindow(syntax: QuerySyntax): ExplicitWindow | undefined {
  if (syntax.after === undefined && syntax.before === undefined) return undefined
  const start = syntax.after === undefined ? undefined : periodStart(syntax.after)
  const endExclusive = syntax.before === undefined ? undefined : periodStart(syntax.before)
  if (syntax.after !== undefined && start === undefined) return undefined
  if (syntax.before !== undefined && endExclusive === undefined) return undefined
  return {
    ...(start === undefined ? {} : { start }),
    ...(endExclusive === undefined ? {} : { endExclusive }),
  }
}

function inExplicitWindow(timestamp: number, window: ExplicitWindow): boolean {
  return (window.start === undefined || timestamp >= window.start)
    && (window.endExclusive === undefined || timestamp < window.endExclusive)
}

function dateRank(candidate: { readonly publishedAt?: string }, explicit: ExplicitWindow | undefined, freshStart: number): number {
  const timestamp = candidate.publishedAt === undefined ? undefined : Date.parse(candidate.publishedAt)
  if (timestamp === undefined || !Number.isFinite(timestamp)) return 1
  if (explicit !== undefined) return inExplicitWindow(timestamp, explicit) ? 0 : 2
  return timestamp >= freshStart ? 0 : 2
}

function periodStart(value: string): number | undefined {
  const period = parseDatePeriod(value)
  return period === undefined ? undefined : Date.UTC(period.year, period.month - 1, period.day)
}
