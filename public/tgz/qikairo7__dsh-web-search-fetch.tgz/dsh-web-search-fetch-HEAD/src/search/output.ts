// 搜索输出阶段（ADR-0001 §7/§9/§10/§11）：纯函数，无网络、无 OpContext、无编排状态。
// 状态与呈现分离（development.md §3.4）：编排侧产出结构化 Note（稳定 id + 可选 params），
// 中文用户文案只在本文件的 NOTE_TEXT 一处；测试锚定 id/params，不锚定整句。
// aggregate 在返回前调用一次 buildSearchOutput / buildEmptyOutput，其他模块不做文案拼接。

import { WebError, type WebSearchResult, type WebSearchSource } from '@deepseek-ai/dsh-web'

import type { EngineSearchOutcome } from '../engines/contract.js'
import type { LaneOutcome } from '../support/lane-runner.js'
import { isAuthorityHost, preferAuthority, topicMatches } from './quality.js'
import type { SearchIntent } from './router.js'
import type { FusedCandidate } from './fuse.js'
import type { SearchInsufficiencyReason } from './sufficiency.js'

/** 搜索操作的统一单路结局（与编排层的 Outcome 同形）。 */
export type SearchOutcome = LaneOutcome<EngineSearchOutcome>

/** 归因条目：引擎、贡献候选数、该路耗时（毫秒，可选）。 */
export interface AttributionEntry {
  readonly engine: string
  readonly count: number
  readonly elapsedMs?: number
}

/** 单路说明状态词表（零结果说明用）。 */
export type LaneState = 'empty' | 'rate-limit' | 'quota-exhausted' | 'insufficient-credits' | 'timeout' | 'cancelled' | 'failed' | 'skipped'

/** 单路说明事实：引擎 + 状态 + 返回条数。 */
export interface LaneReport {
  readonly engineId: string
  readonly state: LaneState
  readonly returned: number
}

/**
 * 结构化操作说明：id 是稳定标识符（测试与日志可依赖），params 是渲染所需的少量事实。
 * 中文句子不进入状态，只在 NOTE_TEXT 里。
 */
export type Note =
  | { readonly id: 'hot-list' }
  | { readonly id: 'ai-news-hot' }
  | { readonly id: 'ai-news' }
  | { readonly id: 'community-opinion' }
  | { readonly id: 'vertical-data'; readonly params: { readonly label: string } }
  | { readonly id: 'research' }
  | { readonly id: 'english-web' }
  | { readonly id: 'english-web-developer' }
  | { readonly id: 'chinese-web' }
  | { readonly id: 'cache-hit'; readonly params: { readonly ageSeconds: number } }
  | { readonly id: 'vertical-unavailable' }
  | { readonly id: 'vertical-missing-params'; readonly params: { readonly missing: readonly string[] } }
  | { readonly id: 'official-supplement'; readonly params: { readonly count: number } }
  | { readonly id: 'early-cancel' }
  | { readonly id: 'rerank-applied' }
  | { readonly id: 'keyless-fallback' }
  | { readonly id: 'vertical-degrade'; readonly params: { readonly language: 'chinese' | 'english' } }
  | { readonly id: 'hot-degrade'; readonly params: { readonly language: 'chinese' | 'english' } }
  | { readonly id: 'degrade-no-channel' }
  | { readonly id: 'degrade-early-cancel' }
  | { readonly id: 'escalate-no-channel' }
  | { readonly id: 'escalate-budget-exhausted' }
  | { readonly id: 'escalate-selected'; readonly params: { readonly engine: string; readonly reason: SearchInsufficiencyReason; readonly selected: number } }
  | { readonly id: 'escalate-early-cancel' }
  | { readonly id: 'quota-estimated'; readonly params: { readonly engines: readonly string[] } }
  | { readonly id: 'date-filtered'; readonly params: { readonly omitted: number } }
  | { readonly id: 'domain-limit'; readonly params: { readonly omitted: number } }
  | { readonly id: 'output-budget'; readonly params: { readonly omitted: number } }
  | { readonly id: 'attribution'; readonly params: { readonly entries: readonly AttributionEntry[] } }

/** 全部用户可见操作说明的唯一文案表：新增 note 只改这里与 Note 联合类型。 */
export const NOTE_TEXT: { readonly [K in Note['id']]: (note: Extract<Note, { id: K }>) => string } = {
  'hot-list': () => '为你获取当下的热点榜单。',
  'ai-news-hot': () => '为你获取 AI 领域的热点榜单。',
  'ai-news': () => '为你检索 AI 领域的最新动态。',
  'community-opinion': () => '这个问题适合查知乎社区的观点与经验。',
  'vertical-data': note => `识别为${note.params.label}查询，为你直接获取对应数据。`,
  'research': () => '需要综合多方资料，为你做多来源检索。',
  'english-web': () => '按英文网页检索。',
  'english-web-developer': () => '按英文网页检索，优先开发者文档与代码资料。',
  'chinese-web': () => '按中文网页检索。',
  'cache-hit': note => `（缓存命中，age ${note.params.ageSeconds} 秒）`,
  'vertical-unavailable': () => '垂直频道不可用，改用通用搜索。',
  'vertical-missing-params': note => `垂直频道需参数 ${note.params.missing.join('、')}，改用通用搜索。`,
  'official-supplement': note => `增加 ${note.params.count} 次限定官方域名的补充检索，仍受请求预算约束。`,
  'early-cancel': () => '已有多路相关结果，宽限等待结束后提前取消未完成渠道；可能仍有未返回内容。',
  'rerank-applied': () => '结果经 SiliconFlow 重排服务排序。',
  'keyless-fallback': () => '额度耗尽，改用匿名额度。',
  'vertical-degrade': note => `垂直数据路由无可用结果，降级为通用${note.params.language === 'chinese' ? '中文' : '英文'}搜索重试一次。`,
  'hot-degrade': note => `热点榜单路由无可用结果，降级为通用${note.params.language === 'chinese' ? '中文' : '英文'}搜索重试一次。`,
  'degrade-no-channel': () => '没有可降级的通用搜索通道。',
  'degrade-early-cancel': () => '降级的多路已取得相关结果，宽限等待结束后提前取消未完成渠道；可能仍有未返回内容。',
  'escalate-no-channel': () => '单通道结果不足；没有可补派的其他通道。',
  'escalate-budget-exhausted': () => '单通道结果不足；请求预算已用尽，未补派其他通道。',
  'escalate-selected': note => `单路 ${note.params.engine} 结果不足（${INSUFFICIENCY_TEXT[note.params.reason]}），补派选择 ${note.params.selected} 路搜索。`,
  'escalate-early-cancel': () => '补派的多路已取得相关结果，宽限等待结束后提前取消未完成渠道；可能仍有未返回内容。',
  'quota-estimated': note => `${note.params.engines.join('、')} 无额度端点，本地计数为估算。`,
  'date-filtered': note => `因显式日期窗口省略 ${note.params.omitted} 条已知窗口外结果。`,
  'domain-limit': note => `因单域上限省略 ${note.params.omitted} 条。`,
  'output-budget': note => `因输出预算省略 ${note.params.omitted} 条来源。`,
  'attribution': note => `来源：${note.params.entries.map(entry => {
    const elapsed = entry.elapsedMs === undefined ? '' : `(${entry.elapsedMs}ms)`
    return `${entry.engine}×${entry.count}${elapsed}`
  }).join('、')}。`,
}

const INSUFFICIENCY_TEXT: { readonly [key in SearchInsufficiencyReason]: string } = {
  empty: '无相关结果',
  'official-source': '官方来源缺失',
  'research-coverage': '调研覆盖不足',
  'fresh-date': '缺少近 7 天结果',
}

/** 把一个结构化说明渲染成用户可见句子（唯一入口）。 */
export function renderNote(note: Note): string {
  const render = NOTE_TEXT[note.id] as (note: Note) => string
  return render(note)
}

/** 缓存命中的返回形态：age 说明置于原 content 之前（原 content 可能含答案）。 */
export function cachedResult(result: WebSearchResult, ageSeconds: number): WebSearchResult {
  const marker = renderNote({ id: 'cache-hit', params: { ageSeconds } })
  const content = result.content === undefined ? marker : `${marker}\n\n${result.content}`
  return { ...result, content }
}

/** 答案在前、处理说明在后（ADR-0001 §7）。 */
export function composeContent(answer: string | undefined, explanation: string): string {
  return answer === undefined ? explanation : `${answer}\n\n${explanation}`
}

/** 成功轮里的生成式答案（知乎直答等）：按派发序拼接。 */
export function successfulAnswers(outcomes: readonly SearchOutcome[]): string | undefined {
  const parts = outcomes.flatMap(outcome =>
    outcome.kind === 'ok' && outcome.result.content !== undefined && outcome.result.content.trim() !== ''
      ? [outcome.result.content.trim()]
      : [],
  )
  return parts.length === 0 ? undefined : parts.join('\n\n')
}

/** 任一成功路有非空 content 即视为有产出（垂直结构化数据走 content 通道）。 */
export function hasAnswer(outcomes: readonly SearchOutcome[]): boolean {
  return successfulAnswers(outcomes) !== undefined
}

/** 成功路的耗时（同一引擎多路取最大），归因说明用。 */
function laneElapsed(outcomes: readonly SearchOutcome[]): ReadonlyMap<string, number> {
  const elapsed = new Map<string, number>()
  for (const outcome of outcomes) {
    if (outcome.kind !== 'ok') continue
    const previous = elapsed.get(outcome.engineId)
    elapsed.set(outcome.engineId, previous === undefined ? outcome.elapsedMs : Math.max(previous, outcome.elapsedMs))
  }
  return elapsed
}

/** 融合归因：按 contributors 统计每个引擎贡献的候选数（取前三个，ADR-0001 §9），附单路耗时。 */
function attributionNote(
  candidates: readonly FusedCandidate[],
  elapsedByEngine: ReadonlyMap<string, number>,
): Note | undefined {
  if (candidates.length === 0) return undefined
  const counts = new Map<string, number>()
  const order = new Map<string, number>()
  for (const candidate of candidates) {
    for (const engineId of candidate.contributors) {
      if (!order.has(engineId)) order.set(engineId, order.size)
      counts.set(engineId, (counts.get(engineId) ?? 0) + 1)
    }
  }
  const ranked = [...counts.entries()]
    .sort((left, right) => right[1] - left[1] || order.get(left[0])! - order.get(right[0])!)
    .slice(0, 3)
  if (ranked.length === 0) return undefined
  return {
    id: 'attribution',
    params: {
      entries: ranked.map(([engine, count]) => {
        const elapsedMs = elapsedByEngine.get(engine)
        return { engine, count, ...(elapsedMs === undefined ? {} : { elapsedMs }) }
      }),
    },
  }
}

/** 每域最多保留的来源数（ADR-0001 §10）。 */
const MAX_SOURCES_PER_DOMAIN = 2

/** 域名键：hostname 去 www、小写；URL 非法返回 undefined（不参与配额，原样保留）。 */
function hostKey(url: string): string | undefined {
  try { return new URL(url).hostname.replace(/^www\./i, '').toLowerCase() }
  catch { return undefined }
}

/** 域名多样性：排序豁免域不占每域 2 条上限；返回保留项与被裁数量（ADR-0001 §10）。 */
function limitDomainDiversity(
  query: string,
  intent: SearchIntent | undefined,
  candidates: readonly FusedCandidate[],
): { readonly candidates: FusedCandidate[]; readonly omitted: number } {
  const counts = new Map<string, number>()
  const kept: FusedCandidate[] = []
  let omitted = 0
  for (const candidate of candidates) {
    if (!isAuthorityHost(candidate.url, query, intent) || !topicMatches(query, candidate)) {
      const host = hostKey(candidate.url)
      if (host !== undefined) {
        const count = counts.get(host) ?? 0
        if (count >= MAX_SOURCES_PER_DOMAIN) { omitted += 1; continue }
        counts.set(host, count + 1)
      }
    }
    kept.push(candidate)
  }
  return { candidates: kept, omitted }
}

/**
 * 搜索侧输出预算（ADR-0001 §11）：按 DSH 实际渲染字段估算，从尾部裁 sources。
 */
function applyOutputBudget(
  candidates: readonly FusedCandidate[],
  maxOutputChars: number | undefined,
): { readonly sources: FusedCandidate[]; readonly trimmed: boolean; readonly omitted: number } {
  if (maxOutputChars === undefined || !Number.isFinite(maxOutputChars) || maxOutputChars <= 0) {
    return { sources: [...candidates], trimmed: false, omitted: 0 }
  }
  let used = 0
  let kept = 0
  for (const candidate of candidates) {
    const size = candidate.url.length
      + (candidate.title?.length ?? 0)
      + Math.max(candidate.summary?.length ?? 0, candidate.snippet?.length ?? 0)
      + (candidate.publishedAt?.length ?? 0)
    if (used + size > maxOutputChars) break
    used += size
    kept += 1
  }
  if (kept >= candidates.length) return { sources: [...candidates], trimmed: false, omitted: 0 }
  return { sources: candidates.slice(0, kept), trimmed: true, omitted: candidates.length - kept }
}

/** truncated 汇总（AD8）：宽限提前结束、总限时、任一成功路截断、maxResults 或输出预算裁切。 */
function computeTruncated(input: {
  readonly endedEarly: boolean
  readonly deadlineReached: boolean
  readonly outcomes: readonly SearchOutcome[]
  readonly orderedCount: number | undefined
  readonly maxResults: number | undefined
  readonly outputTrimmed: boolean
}): boolean {
  return input.endedEarly
    || input.deadlineReached
    || input.outcomes.some(outcome => outcome.kind === 'ok' && outcome.result.truncated)
    || (input.orderedCount !== undefined && input.maxResults !== undefined && input.orderedCount > input.maxResults)
    || input.outputTrimmed
}

/** 候选投影到 seam 来源形状，不发明字段。 */
function toSeamSource(candidate: FusedCandidate): WebSearchSource {
  return {
    url: candidate.url,
    ...(candidate.title === undefined ? {} : { title: candidate.title }),
    ...(candidate.snippet === undefined ? {} : { snippet: candidate.snippet }),
    ...(candidate.summary === undefined ? {} : { summary: candidate.summary }),
    ...(candidate.publishedAt === undefined ? {} : { publishedAt: candidate.publishedAt }),
  }
}

/** 正常结果的输出阶段输入（一次性，纯数据）。 */
export interface SearchOutputInput {
  readonly query: string
  readonly intent: SearchIntent
  readonly candidates: readonly FusedCandidate[]
  readonly maxResults: number | undefined
  readonly maxOutputChars: number | undefined
  readonly outcomes: readonly SearchOutcome[]
  readonly endedEarly: boolean
  readonly deadlineReached: boolean
  /** 输出阶段之前已收集的事实行（路由/选择/降级等，已渲染）。 */
  readonly notes: readonly string[]
  readonly requestCount: number
}

/** 正常结果：来源裁剪、归因与说明、答案合并、truncated 汇总一次完成。 */
export interface SearchOutput {
  readonly sources: readonly WebSearchSource[]
  readonly content: string | undefined
  readonly truncated: boolean
  readonly notes: readonly string[]
}

/** 正常结果的输出阶段：aggregate 只在返回前调用一次。 */
export function buildSearchOutput(input: SearchOutputInput): SearchOutput {
  const preferred = preferAuthority(input.query, input.intent, input.candidates)
  const diverse = limitDomainDiversity(input.query, input.intent, preferred)
  const limited = input.maxResults === undefined
    ? diverse.candidates
    : diverse.candidates.slice(0, Math.max(0, input.maxResults))
  const budgeted = applyOutputBudget(limited, input.maxOutputChars)
  const outputNotes: Note[] = []
  if (diverse.omitted > 0) outputNotes.push({ id: 'domain-limit', params: { omitted: diverse.omitted } })
  if (budgeted.omitted > 0) outputNotes.push({ id: 'output-budget', params: { omitted: budgeted.omitted } })
  const attribution = attributionNote(budgeted.sources, laneElapsed(input.outcomes))
  if (attribution !== undefined) outputNotes.push(attribution)
  const notes = [...input.notes, ...outputNotes.map(renderNote)]
  const explanation = notes.length === 0 ? undefined : renderExplanation(notes, input.requestCount)
  const answer = successfulAnswers(input.outcomes)
  return {
    sources: budgeted.sources.map(toSeamSource),
    content: explanation === undefined ? answer : composeContent(answer, explanation),
    truncated: computeTruncated({
      endedEarly: input.endedEarly,
      deadlineReached: input.deadlineReached,
      outcomes: input.outcomes,
      orderedCount: preferred.length,
      maxResults: input.maxResults,
      outputTrimmed: budgeted.trimmed,
    }),
    notes,
  }
}

/** 零结果输出阶段输入。 */
export interface EmptyOutputInput {
  readonly outcomes: readonly SearchOutcome[]
  readonly notes: readonly string[]
  readonly requestCount: number
  readonly endedEarly: boolean
  readonly deadlineReached: boolean
}

/** 零结果输出阶段：逐路状态说明 + 答案 + truncated 汇总。 */
export function buildEmptyOutput(input: EmptyOutputInput): { readonly content: string; readonly truncated: boolean } {
  const empty = emptyResultNote(laneReports(input.outcomes))
  const explanation = input.notes.length === 0
    ? `${empty}本插件 HTTP 请求 ${input.requestCount} 次。`
    : `${empty}${renderExplanation(input.notes, input.requestCount)}`
  return {
    content: composeContent(successfulAnswers(input.outcomes), explanation),
    truncated: computeTruncated({
      endedEarly: input.endedEarly,
      deadlineReached: input.deadlineReached,
      outcomes: input.outcomes,
      orderedCount: undefined,
      maxResults: undefined,
      outputTrimmed: false,
    }),
  }
}

/** 用户可见的处理说明整句（唯一的说明框架）。 */
export function renderExplanation(notes: readonly string[], requestCount: number): string {
  return `搜索处理说明：${notes.join(' ')} 本插件 HTTP 请求 ${requestCount} 次。`
}

/** 日志用的事实行汇总（不带到用户 content）。 */
export function renderLogSummary(notes: readonly string[], requestCount: number): string {
  return `${notes.join(' ')} 本插件 HTTP 请求 ${requestCount} 次。`
}

/** 派发过的通道 → 说明词表（v0.2 laneReports 语义；aborted = 操作信号拆掉的通道 → cancelled）。 */
function laneReports(outcomes: readonly SearchOutcome[]): LaneReport[] {
  const reports = new Map<string, LaneReport>()
  for (const outcome of outcomes) {
    const report: LaneReport = {
      engineId: outcome.engineId,
      state: laneState(outcome),
      returned: outcome.kind === 'ok' ? outcome.result.sources.length : 0,
    }
    const key = `${report.engineId}\u0000${report.state}`
    const existing = reports.get(key)
    // 同一引擎可能派发两次（site: 补充路）；每状态点名一次，保留较大计数。
    reports.set(key, existing === undefined ? report : { ...existing, returned: Math.max(existing.returned, report.returned) })
  }
  return [...reports.values()]
}

/** 单路状态：统一失败模型的 kind 直接映射（AD6 后不再解析引擎私有错误）。 */
function laneState(outcome: SearchOutcome): LaneState {
  switch (outcome.kind) {
    case 'ok': return 'empty'
    case 'timeout': return 'timeout'
    case 'aborted': return 'cancelled'
    case 'failed':
      switch (outcome.failure.kind) {
        case 'rate-limited': return 'rate-limit'
        case 'quota':
          return outcome.failure.statusCode === 402 ? 'insufficient-credits' : 'quota-exhausted'
        case 'timeout': return 'timeout'
        case 'aborted': return 'cancelled'
        default: return 'failed'
      }
  }
}

/** 零结果说明。逐路点名状态，让「查询无解」与「覆盖不足」可区分；只读已记录状态。 */
function emptyResultNote(lanes: readonly LaneReport[]): string {
  const lead = '未找到与查询相关的结果'
  if (lanes.length === 0) return `${lead}：本次没有派发任何通道。`
  if (lanes.length === 1) return `${lead}：单通道引擎 ${lanes[0]!.engineId} ${describeLane(lanes[0]!)}。`
  return `${lead}：各通道状态：${lanes.map(lane => `${lane.engineId} ${describeLane(lane)}`).join('；')}。`
}

/** 单路状态的短句（无凭据）。 */
function describeLane(lane: LaneReport): string {
  switch (lane.state) {
    case 'empty':
      return lane.returned > 0 ? `成功返回 ${lane.returned} 条，但均与查询无关` : '成功返回但无结果'
    case 'rate-limit': return '被限流（rate-limit），本次未取得结果'
    case 'quota-exhausted': return '当日额度已耗尽（quota-exhausted）'
    case 'insufficient-credits': return '余额不足（insufficient-credits）'
    case 'timeout': return '请求超时，未在限时内返回结果'
    case 'cancelled': return '被操作总限时取消，未取得结果'
    case 'skipped': return '已熔断，本次未派发'
    default: return '请求失败'
  }
}

/** 全部引擎失败时的错误。 */
export function allEnginesFailedError(
  outcomes: ReadonlyArray<SearchOutcome | { readonly kind: 'skipped'; readonly engineId: string }>,
): WebError {
  const summary = outcomes.map(describeOutcome).join('; ')
  return new WebError(
    outcomes.length === 0
      ? 'Aggregated web search failed: no engine is configured'
      : `Aggregated web search failed on every engine: ${summary}`,
    'WEB_PROVIDER_ERROR',
  )
}

/** 单路结局的有界、无凭据摘要。 */
function describeOutcome(outcome: SearchOutcome | { readonly kind: 'skipped'; readonly engineId: string }): string {
  switch (outcome.kind) {
    case 'skipped': return `${outcome.engineId} (已熔断，跳过)`
    case 'timeout': return `${outcome.engineId} (超时 ${outcome.elapsedMs}ms)`
    case 'aborted': return `${outcome.engineId} (已取消)`
    case 'failed': return `${outcome.engineId} (${outcome.failure.kind}${outcome.failure.statusCode ? ` ${outcome.failure.statusCode}` : ''})`
    default: return `${outcome.engineId} (ok)`
  }
}
