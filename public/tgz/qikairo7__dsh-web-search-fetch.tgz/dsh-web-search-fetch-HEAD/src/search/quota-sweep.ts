// 搜索入口的额度日检：每个 quota 面每个本地日最多探测一次，失败不阻塞搜索。

import type { Engine, EngineContext, EngineManifest, QuotaReport } from '../engines/contract.js'
import { quotaReportSignal, type CircuitBreaker } from '../support/breaker.js'
import { localDayKey } from '../support/quota-ledger.js'
import { abortable, type OpContext } from '../support/budget.js'
import { renderNote } from './output.js'

interface QuotaSweepOptions {
  readonly enabled: boolean
  readonly breaker: CircuitBreaker
  readonly buildContext: (
    manifest: EngineManifest,
    op: OpContext,
    lane: { signal: AbortSignal; deadline: number; face: 'search' | 'quota' },
  ) => Promise<EngineContext>
  readonly logger: { warn(message: string): void }
  readonly now: () => number
  /** 整轮探测的总截止；缺省 5 秒。 */
  readonly timeoutMs?: number
  readonly onQuotaReport?: (engineId: string, report: QuotaReport) => void
}

export class DailyQuotaSweeper {
  private checkedDay: string | undefined

  constructor(private readonly options: QuotaSweepOptions) {}

  async sweep(engines: readonly Engine[], op: OpContext): Promise<void> {
    if (!this.options.enabled) return
    const day = localDayKey(this.options.now())
    if (this.checkedDay === day) return
    this.checkedDay = day
    const estimated = engines.filter(engine => engine.manifest.endpoints.quota === undefined)
    if (estimated.length > 0) {
      op.note(renderNote({ id: 'quota-estimated', params: { engines: estimated.map(engine => engine.manifest.label) } }))
    }
    const sweepDeadlineAt = this.options.now() + (this.options.timeoutMs ?? QUOTA_SWEEP_TIMEOUT_MS)
    const sweepSignal = AbortSignal.any([op.signal, AbortSignal.timeout(this.options.timeoutMs ?? QUOTA_SWEEP_TIMEOUT_MS)])
    for (const engine of engines) {
      if (engine.quota === undefined) continue
      const remainingMs = sweepDeadlineAt - this.options.now()
      if (remainingMs <= 0) break
      try {
        const context = await abortable(this.options.buildContext(engine.manifest, op, {
          signal: sweepSignal,
          deadline: this.options.now() + Math.min(10_000, remainingMs),
          face: 'quota',
        }), sweepSignal)
        const quota = await abortable(engine.quota(context), sweepSignal)
        this.options.onQuotaReport?.(engine.manifest.id, quota)
        const signal = quotaReportSignal(quota)
        if (signal !== undefined) {
          this.options.breaker.recordSignal(engine.manifest.id, signal)
          this.options.logger.warn(`[搜索] 引擎 ${engine.manifest.id} 当日额度已耗尽（remaining ${quota.remaining}），本次起停用`)
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error)
        this.options.logger.warn(`[搜索] 引擎 ${engine.manifest.id} 额度查询失败，忽略并继续：${message.slice(0, 200)}`)
      }
    }
  }
}

const QUOTA_SWEEP_TIMEOUT_MS = 5_000
