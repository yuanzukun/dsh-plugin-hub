// 抽象候选解析：装配层给出有序候选链，编排层只补运行时事实。
// 本文件把引擎能力与配置状态投影成 SearchRouteCandidate，不参与最终选择。

import type { Engine } from '../engines/contract.js'
import type { CircuitBreaker } from '../support/breaker.js'
import type { RuntimeControls } from '../support/budget.js'
import type { QueryAnalysis, SearchIntent } from './router.js'
import type {
  SearchCandidateCapability,
  SearchCandidateSkipCause,
  SearchCandidateSpec,
  SearchRouteCandidate,
} from './planner.js'

/** 装配层注入的抽象候选链；缺省 = 空链，由 registry 顺序补足。 */
export type SearchCandidateSource = (
  intent: SearchIntent,
  prefer?: QueryAnalysis['prefer'],
) => readonly SearchCandidateSpec[]

/** 规划输入 + 派发所需的引擎句柄；规划器只消费前面的抽象字段。 */
export interface SearchEngineCandidate extends SearchRouteCandidate {
  /** 该候选来自装配层候选链；末尾补足的 fallback 引擎为 false。 */
  readonly fromSpec: boolean
  readonly engine: Engine
}

export interface ResolveSearchCandidatesInput {
  readonly engines: readonly Engine[]
  readonly specs: readonly SearchCandidateSpec[]
  readonly controls: RuntimeControls
  readonly breaker: CircuitBreaker
  readonly ready?: (id: string, face: 'search' | 'fetch') => Promise<boolean>
  /** 已派发候选 id；解析时直接排除，不进入规划器。 */
  readonly exclude?: ReadonlySet<string>
  /** 已派发引擎 id；候选 id 与引擎 id 分离时也必须排除。 */
  readonly excludeEngines?: ReadonlySet<string>
}

/** 把引擎表与装配层候选链投影成规划器输入，顺序保持不变。 */
export async function resolveSearchCandidates(
  input: ResolveSearchCandidatesInput,
): Promise<readonly SearchEngineCandidate[]> {
  const engines = new Map(input.engines
    .filter(engine => engine.manifest.capabilities.includes('search') && engine.search !== undefined)
    .map(engine => [engine.manifest.id, engine]))
  const inputSpecs = new Set(input.specs)
  const excludedEngineIds = new Set(input.excludeEngines ?? [])
  const ordered = orderSpecs(engines, input.specs, input.controls, input.exclude, excludedEngineIds)
  return await Promise.all(ordered.map(async spec => {
    const engineId = spec.engineId ?? spec.id
    const engine = engines.get(engineId)!
    let skip = skipCause(engine, input)
    if (skip === undefined && input.ready !== undefined && !await input.ready(engineId, 'search')) {
      skip = 'unavailable'
    }
    // 凭证探测期间熔断状态可能变化；与旧选择路径一样，派发前再过滤一次。
    if (skip === undefined && input.breaker.isBroken(engineId)) skip = 'breaker-open'
    const capabilities: SearchCandidateCapability[] = []
    if (engine.hotTopics !== undefined) capabilities.push('hot-topics')
    return {
      id: spec.id,
      role: spec.role,
      fromSpec: inputSpecs.has(spec),
      engine,
      capabilities,
      ...(skip === undefined ? {} : { skip }),
    }
  }))
}

/** 有装配层候选链时按其顺序，未列出的引擎按 registry 序补后；空链沿用用户搜索顺序。 */
function orderSpecs(
  engines: ReadonlyMap<string, Engine>,
  specs: readonly SearchCandidateSpec[],
  controls: RuntimeControls,
  excludedCandidates: ReadonlySet<string> | undefined,
  excludedEngines: ReadonlySet<string>,
): readonly SearchCandidateSpec[] {
  if (specs.length === 0) {
    const ordered = [...engines.values()]
      .filter(engine => !excludedEngines.has(engine.manifest.id))
    const chosen = controls.searchServices
    if (chosen !== undefined) {
      ordered.sort((left, right) =>
        chosen.indexOf(left.manifest.id) - chosen.indexOf(right.manifest.id))
    }
    return ordered.map(engine => ({
      id: engine.manifest.id,
      role: 'fallback',
      engineId: engine.manifest.id,
    }))
  }
  const seen = new Set<string>()
  const ordered: SearchCandidateSpec[] = []
  for (const spec of specs) {
    const engineId = spec.engineId ?? spec.id
    if (!engines.has(engineId) || seen.has(engineId)) continue
    seen.add(engineId)
    // 已派发候选直接排除；它们不是本轮候选，不产生 route-skip。
    if (excludedCandidates?.has(spec.id) === true || excludedEngines.has(engineId)) continue
    ordered.push(spec)
  }
  for (const engine of engines.values()) {
    const id = engine.manifest.id
    if (seen.has(id) || excludedEngines.has(id)) continue
    ordered.push({ id, role: 'fallback', engineId: id })
  }
  return ordered
}

function skipCause(
  engine: Engine,
  input: ResolveSearchCandidatesInput,
): SearchCandidateSkipCause | undefined {
  const id = engine.manifest.id
  if ((input.controls.serviceEnabled?.[id] ?? true) !== true) return 'service-disabled'
  if (input.controls.searchServices !== undefined && !input.controls.searchServices.includes(id)) {
    return 'not-configured'
  }
  if (input.breaker.isBroken(id)) return 'breaker-open'
  return undefined
}
