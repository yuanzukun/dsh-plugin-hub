// 意图 → 源池顺序与热点引擎选择（ADR-0001 §2）：纯函数，不派发、不读配置。
// 映射由装配层注入（R7：编排层不点名引擎），这里只应用映射与 registry 顺序。

import type { Engine } from '../engines/contract.js'
import type { OpContext } from '../support/budget.js'
import { selectServices } from './preset.js'
import type { QueryAnalysis, SearchIntent } from './router.js'

/** 装配层注入的意图→引擎 id 映射；缺省 = 空映射，沿用 registry 顺序。 */
export type IntentEngines = (intent: SearchIntent, prefer?: QueryAnalysis['prefer']) => readonly string[]

/** 按意图映射排候选：映射内按给定顺序在前，未映射的按 registry 序排后。priority 为空表示无映射。 */
export function orderCandidates(
  engines: readonly Engine[],
  priority: readonly string[],
  registryOrder: readonly Engine[],
): Engine[] {
  if (priority.length === 0) return [...engines]
  const remaining = new Map(engines.map(engine => [engine.manifest.id, engine]))
  const ordered: Engine[] = []
  for (const id of priority) {
    const engine = remaining.get(id)
    if (engine === undefined) continue
    ordered.push(engine)
    remaining.delete(id)
  }
  // 未映射的引擎按 registry 序排后。
  for (const engine of registryOrder) {
    const match = remaining.get(engine.manifest.id)
    if (match === undefined) continue
    ordered.push(match)
    remaining.delete(engine.manifest.id)
  }
  return ordered
}

/** 把引擎投影成选择服务所需的 manifest 形状，并返回原始引擎。 */
export async function selectSearchEngines(
  engines: readonly Engine[],
  op: OpContext,
  ready: ((id: string, face: 'search' | 'fetch') => Promise<boolean>) | undefined,
  capOverride?: number,
  noteSelection = true,
  intent?: SearchIntent,
  intentOrder?: readonly string[],
): Promise<readonly Engine[]> {
  const rows = await selectServices(engines.map(engine => ({
    engine,
    id: engine.manifest.id,
    free: engine.manifest.free ?? false,
    keyless: engine.manifest.keyless ?? false,
    ...(engine.manifest.keylessCapabilities === undefined
      ? {}
      : { keylessCapabilities: engine.manifest.keylessCapabilities }),
  })), op, 'search', ready, capOverride, noteSelection, intent, intentOrder)
  return rows.map(row => row.engine)
}

/** 热点榜：按意图映射序取第一个在选中池内且具备 hotTopics 的引擎（不只认首位）。 */
export function hotTopicsEngine(
  selected: readonly Engine[],
  route: QueryAnalysis,
  intentEngines: IntentEngines,
): Engine | undefined {
  if (route.useHotTopics !== true) return undefined
  // 知乎热榜优先的 hot-list 在知乎不可用时由 AIHOT 兜底，反之亦然；取映射序内第一个可用的。
  for (const id of intentEngines(route.intent, route.prefer)) {
    const engine = selected.find(candidate => candidate.manifest.id === id)
    if (engine?.hotTopics !== undefined) return engine
  }
  return undefined
}
