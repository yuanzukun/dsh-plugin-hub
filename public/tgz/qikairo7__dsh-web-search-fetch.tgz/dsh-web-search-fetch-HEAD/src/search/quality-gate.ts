// DeepSeek-like 质量门：Top5 候选的主题相关性、域名多样性、日期与长摘要。
// 意图例外在此收口，缓存读取与搜索后质量评估共用；后续补派可复用缺口。

import type { WebSearchResult } from '@deepseek-ai/dsh-web'

import { buildSearchEvidence, QUALITY_SAMPLE_SIZE, type SearchEvidence } from './evidence.js'
import type { FusedCandidate } from './fuse.js'
import { GOVERNMENT_HOSTS, isOfficial, isOfficialWithin, officialHosts, topicMatches } from './quality.js'
import type { QueryAnalysis } from './router.js'

const QUALITY_MIN_RELEVANT = 3
const QUALITY_MIN_DOMAINS = 3
const QUALITY_MIN_DATED = 2
const QUALITY_MIN_LONG_SUMMARIES = 3

type SearchQualityGap = 'relevance' | 'diversity' | 'date' | 'summary' | 'official'

export interface SearchQualityVerdict {
  /** 普通网页质量门是否适用；垂直数据与热榜不适用。 */
  readonly applicable: boolean
  readonly sufficient: boolean
  readonly gaps: readonly SearchQualityGap[]
}

interface RequiredOfficial {
  readonly hosts: readonly string[]
  readonly includeSubdomains: boolean
}

const POLICY_QUERY = /政府|政策|官方指南|监管|法规|法律|税务|税收|判例|立法/

/** 官方域只要求显式站点、开发者文档与政策类查询；AI 新闻、热点与垂直数据不强制。 */
function requiredOfficial(analysis: QueryAnalysis): RequiredOfficial | undefined {
  if (analysis.syntax.domains.length > 0) {
    return { hosts: analysis.syntax.domains, includeSubdomains: false }
  }
  if (analysis.intent === 'ai-news' || analysis.intent === 'hot-list' || analysis.intent === 'vertical-data') {
    return undefined
  }
  const docs = officialHosts(analysis)
  if (docs.length > 0) return { hosts: docs, includeSubdomains: false }
  if (analysis.intent !== 'community-opinion' && POLICY_QUERY.test(analysis.query)) {
    return { hosts: GOVERNMENT_HOSTS, includeSubdomains: true }
  }
  return undefined
}

/** 普通网页质量门；垂直数据按结构化响应与必填字段校验，不参与普通网页多样性判定。 */
export function assessSearchQuality(
  analysis: QueryAnalysis,
  evidence: SearchEvidence,
): SearchQualityVerdict {
  if (analysis.intent === 'vertical-data') {
    // 垂直数据的必填字段由 VerticalCatalog 在派发前校验；这里不重复普通网页指标。
    return {
      applicable: false,
      sufficient: evidence.topTopicMatchedCandidates > 0,
      gaps: [],
    }
  }
  if (analysis.intent === 'hot-list') {
    return { applicable: false, sufficient: true, gaps: [] }
  }

  const gaps: SearchQualityGap[] = []
  const top = evidence.candidates.slice(0, QUALITY_SAMPLE_SIZE)
  if (evidence.topTopicMatchedCandidates < QUALITY_MIN_RELEVANT) gaps.push('relevance')
  // 知乎社区结果集中在本站是预期形态，不按普通域名多样性判失败。
  const zhihuCount = top.filter(candidate => isZhihuHost(candidate.url)).length
  const zhihuCommunity = analysis.intent === 'community-opinion'
    && top.length > 0
    && zhihuCount >= Math.ceil(top.length / 2)
  const explicitSite = analysis.syntax.domains.length > 0
  if (!explicitSite && !zhihuCommunity && evidence.topDistinctHosts < QUALITY_MIN_DOMAINS) gaps.push('diversity')
  if (evidence.topDatedCandidates < QUALITY_MIN_DATED) gaps.push('date')
  if (evidence.topLongSummaries < QUALITY_MIN_LONG_SUMMARIES) gaps.push('summary')

  const required = requiredOfficial(analysis)
  const officialMatch = required === undefined
    || top.some(candidate => (required.includeSubdomains
      ? isOfficialWithin(candidate.url, required.hosts)
      : isOfficial(candidate.url, required.hosts)) && topicMatches(analysis, candidate))
  if (!officialMatch) gaps.push('official')

  return { applicable: true, sufficient: gaps.length === 0, gaps }
}

/** 以最终结果来源构造同一质量门输入；缓存读写与搜索后评估共用。 */
export function assessResultQuality(
  analysis: QueryAnalysis,
  result: Pick<WebSearchResult, 'sources' | 'content'>,
  now: number,
): SearchQualityVerdict {
  const candidates: FusedCandidate[] = result.sources.map(source => ({
    url: source.url,
    score: 0,
    contributors: [],
    ...(source.title === undefined ? {} : { title: source.title }),
    ...(source.snippet === undefined ? {} : { snippet: source.snippet }),
    ...(source.summary === undefined ? {} : { summary: source.summary }),
    ...(source.publishedAt === undefined ? {} : { publishedAt: source.publishedAt }),
  }))
  return assessSearchQuality(analysis, buildSearchEvidence({
    analysis,
    candidates,
    hasAnswer: result.content !== undefined && result.content.trim() !== '',
    sourceLanes: 0,
    now,
  }))
}

function isZhihuHost(url: string): boolean {
  try {
    const host = new URL(url).hostname.replace(/^www\./, '').toLowerCase()
    return host === 'zhihu.com' || host.endsWith('.zhihu.com')
  } catch {
    return false
  }
}
