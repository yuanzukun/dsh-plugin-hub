// 意图路由器——把查询判定为检索意图（本地确定性关键词规则，不调模型、零成本）。
// R7 架构红线：本目录只判意图，不映射引擎；意图到具体服务的翻译只发生在装配层。
// 判定顺序即优先级：
//   裸热点 → AI 资讯 → 社区观点 → 结构化取数 → 调研对比 → 英文网页 → 中文网页（默认）。
// 显式意图词优先于语言启发式（如「对比」优先于英文判据）。
//
// 两条刻意不对称的规则（复核裁决）：
//   1) 综述/对比/调研/盘点 与 academic.paper/citation 同现时调研胜出——综述要的是多源文章，
//      不是论文库取数；其余垂直（finance/travel 等）与调研词同现时垂直胜出——股价对比要的是数据。
//   2) 方法/决策形态词（怎么/是什么/格式/教程…）会拦下垂直取数，回落到通用网页检索；
//      但 CVE 编号、航班号、股票代码这类强数据模式可以越过守卫（CVE-2026-1234 无疑是取数请求）。
//
// site:/lang: 语法由上层解析，路由器不处理：垂直取数匹配前先剥掉操作符与操作数，
// 避免 site:arxiv.org 的域名被当成学术取数线索；语言判据只剥前缀、保留操作数，
// 所以 site:github.com 仍按英文网页处理。裸热点与 AI 资讯判定保留原文——
// 显式站点约束（site:openai.com 新闻）不该被剥成裸热点，也不该丢掉 AI 线索。

import type { VerticalRequest } from '../engines/contract.js'
import { parseQuerySyntax } from './query-syntax.js'
import type { Note } from './output.js'
import { queryTerms, topicTerms } from './quality.js'

/** 检索意图（与方案表一一对应）。 */
export type SearchIntent =
  | 'ai-news'
  | 'community-opinion'
  | 'hot-list'
  | 'vertical-data'
  | 'english-web'
  | 'research'
  | 'chinese-web'

/** 查询分析：意图、本地结构化信号与检索倾向；不点名任何引擎。 */
export interface QueryAnalysis {
  /** 原始查询；缓存与用户可见规则需要原文。 */
  readonly query: string
  readonly intent: SearchIntent
  /** 显式搜索语法与剥离后的查询主体。 */
  readonly syntax: ReturnType<typeof parseQuerySyntax>
  /** 查询语言；无 CJK 且有拉丁字母时为英文，否则沿用中文默认路径。 */
  readonly language: 'chinese' | 'english'
  /** 本地规则提取的主题词；不是 NLP 实体识别。 */
  readonly topics: readonly string[]
  /** 本地规则提取的可用词（含时效/观点形态词），供相关性门槛使用。 */
  readonly terms: readonly string[]
  /** explicit 表示带 after:/before:；high 表示热点或 AI 资讯。 */
  readonly freshnessRequirement: 'normal' | 'high' | 'exact'
  /** 调研对比需要交叉验证，其余查询为普通验证。 */
  readonly verificationRequirement: 'normal' | 'high'
  /** 结构化取数请求（仅 vertical-data 意图携带）。 */
  readonly vertical?: VerticalRequest
  /** 是否希望引擎附带生成式答案（社区观点意图置真）。 */
  readonly wantAnswer?: boolean
  /** 是否直接取当下热点榜单而非普通搜索。 */
  readonly useHotTopics?: boolean
  /** 网页检索的细分偏好：通用网页 / 开发者资料（装配层翻译成具体来源）。 */
  readonly prefer?: 'general-web' | 'developer'
  /** 用户可见说明素材：稳定 noteId + 可选 params（中文文案在 output.ts 的 NOTE_TEXT）。 */
  readonly note: Note
}

type RouteSeed = Omit<QueryAnalysis, 'query' | 'syntax' | 'language' | 'topics' | 'terms' | 'freshnessRequirement' | 'verificationRequirement'>

/** ASCII 关键词的形态：纯 ASCII 词（可含 . + # / -），用于词边界匹配。 */
const ASCII_KEYWORD = /^[a-z0-9][a-z0-9.+#/-]*$/

/**
 * 关键词命中：纯 ASCII 词按词边界匹配，避免 "cpi" 命中 "scaling"、"ai" 命中 "said"；
 * 含中文或空格的关键词按子串匹配。
 */
function hasKeyword(text: string, keyword: string): boolean {
  if (!ASCII_KEYWORD.test(keyword)) return text.includes(keyword)
  const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  return new RegExp(`(^|[^a-z0-9])${escaped}([^a-z0-9]|$)`, 'i').test(text)
}

/** 任何 CJK 字符（汉字/日文假名/韩文）都说明查询主体是中文。 */
const CJK_CHAR = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/u

/** 查询是否含 CJK 字符（编排层的通用路由语言判据复用此入口，避免第二份正则）。 */
export function hasCjk(text: string): boolean {
  return CJK_CHAR.test(text)
}

/** 拉丁字母：无 CJK 时，哪怕只有一个英文词也按英文网页检索。 */
const LATIN_CHAR = /\p{Script=Latin}/u

/** 完整剥掉 site:/lang: 操作符与操作数：域名不参与意图关键词匹配。 */
function stripSyntaxOperators(text: string): string {
  return text.replace(/(^|\s)-?(?:site|lang):\S+/g, ' ').trim()
}

/** 只剥操作符前缀、保留操作数：domain 里的拉丁字母仍算查询中的英文证据。 */
function withoutSyntaxPrefixes(text: string): string {
  return text.replace(/(^|\s)-?(?:site|lang):/g, ' ')
}

/** AI 主体词：AI/大模型/智能体与常见模型/厂商名（含 gpt4/gpt5 这类无连字符变体）。 */
const AI_TERMS = [
  'ai', '人工智能', '大模型', 'llm', '智能体',
  'gpt', 'gpt4', 'gpt5', 'chatgpt', 'claude', 'gemini', 'llama', 'deepseek', 'qwen',
  'openai', 'anthropic', 'grok', 'mistral', 'xai',
  '通义', '文心', '豆包', 'kimi', '混元', '智谱', 'sora', 'midjourney',
] as const
// 'agent' 不列入：单独出现时是「旅行代理」等普通名词；'AI agent' 里的 'ai' 已足够判定。
/** 品牌名可贴连版本号：llama3、qwen2.5、gpt5.1 与不带版本的基础词等价。 */
const AI_VERSIONED_TERM = /(^|[^a-z0-9])(?:llama|qwen|gpt|claude|gemini|deepseek|grok|mistral)\d+(?:\.\d+)*([^a-z0-9]|$)/i

/** 资讯触发词：只收资讯名词与事件词，不收「最新/本周」这类时间词。 */
const AI_NEWS_TERMS = ['新闻', '资讯', '快讯', '发布', '进展', '发生了什么'] as const
/** 动态/事件按词边界匹配：后面紧跟汉字时是构词（动态规划/事件驱动），不算资讯线索。 */
const AI_EVENT_TERM = /(?:动态|事件)(?=$|[^\p{Script=Han}])/u

/** 热点榜触发词：AI 资讯中带这些词时直接取热点榜。 */
const HOT_TERMS = ['热点', '热榜', '热搜', '热门', '头条', '榜单', '排行榜'] as const

/** 裸热点查询的触发词：热点词与资讯词的裸查询都直接取榜单。 */
const HOT_QUERY_TERMS = [
  '今天有什么新闻', '今天发生了什么', '今天有什么大事',
  '最近有什么新闻', '最近发生了什么', '最近有什么大事',
  '有什么新闻', '有什么大事', '最新新闻', '新闻',
  ...HOT_TERMS,
] as const

/** 裸热点判定时剥除的填充词与平台词：剥完没有主题词才算裸热点。 */
const HOT_FILLERS = [
  '今天', '今日', '现在', '目前', '当前', '最近', '这几天', '实时', '最新',
  '有什么', '什么', '啥', '发生', '有', '大事', '新闻', '热点', '热榜', '热搜',
  '热门', '头条', '排行榜', '榜单', '榜', '话题', '事件',
  '一下', '帮我', '看看', '看一下', '请问',
  '知乎', '微博', '百度', '抖音', '贴吧', 'b站', '哔哩哔哩',
  '的', '了', '吗', '呢', '啊', '呀', '和', '与', '及', '在',
] as const

/**
 * 裸热点查询：出现热点词，且剥掉热点词/填充词/平台名后没有剩余主题词。
 * 平台名（知乎/微博等）视为来源而非主题，所以「知乎热榜」也按裸热点处理。
 */
function isBareHotQuery(text: string): boolean {
  let rest = text
  let matched = false
  for (const term of HOT_QUERY_TERMS) {
    if (!rest.includes(term)) continue
    matched = true
    rest = rest.split(term).join(' ')
  }
  if (!matched) return false
  for (const filler of HOT_FILLERS) rest = rest.split(filler).join(' ')
  rest = rest.replace(/[\s\p{P}\p{S}]+/gu, '')
  return rest.length === 0
}

/** AI 资讯：AI 主体词 + 资讯触发词（或热点词——「OpenAI 热点」也是 AI 资讯）。 */
function wantsAiNews(text: string): boolean {
  const mentionsAi = AI_TERMS.some(term => hasKeyword(text, term)) || AI_VERSIONED_TERM.test(text)
  if (!mentionsAi) return false
  return AI_NEWS_TERMS.some(term => text.includes(term))
    || AI_EVENT_TERM.test(text)
    || HOT_TERMS.some(term => text.includes(term))
}

/** 社区观点意图的触发词（社区讨论式提问）。 */
const COMMUNITY_TERMS = [
  '知乎', '怎么看', '如何评价', '怎样评价', '如何看', '有什么经验', '有啥经验', '靠谱吗',
] as const

/** 调研对比意图的触发词。 */
const RESEARCH_TERMS = ['对比', '综述', '调研', '盘点', '比较'] as const

/** 开发者资料触发词：仅在英文网页意图内用于细分偏好。 */
const DEVELOPER_TERMS = [
  '代码', '编程', '开发', '调试', '编译', '报错', '函数', '接口', '库', '文档', '错误', '异常',
  'code', 'coding', 'programming', 'developer', 'api', 'sdk', 'library', 'framework',
  'docs', 'documentation', 'error', 'exception', 'stack trace', 'debug', 'compiler',
  'npm', 'pip', 'cargo', 'github', 'git', 'docker', 'kubernetes', 'python', 'typescript',
  'javascript', 'rust', 'golang', 'java', 'react', 'vue', 'node', 'sql', 'regex', 'snippet',
  'repository', 'repo',
] as const

/** 一条结构化取数规则：关键词命中即用该 tag；params 只在有把握时填写。 */
interface VerticalRule {
  readonly tag: string
  /** 用户可见的查询对象名，用于拼 note（不暴露 tag 与内部术语）。 */
  readonly label: string
  readonly params?: Readonly<Record<string, string | number | boolean>>
  readonly keywords: readonly string[]
}

/**
 * 影视 BT 资源。「种子」有农业歧义，不直接进 keywords：由 matchVertical 的语境守卫
 * 仅在下载/磁力/BT/电影语境同现时命中。
 */
const TORRENT_RULE: VerticalRule = {
  tag: 'film.torrent',
  label: 'BT 资源',
  keywords: ['磁力链接', 'bt种子', '电影种子', 'magnet', 'torrent'],
}

/** 「种子」的语境守卫：只有这些词同现才按 BT 资源处理，农业/种植语义不触发。 */
const TORRENT_SEED_CONTEXT = ['下载', '磁力', 'bt', '电影', 'torrent', 'magnet'] as const

/**
 * 结构化取数词表（按方案给出的 39 子域常用词映射）。
 * 顺序有意义：更具体的规则排在容易混淆的泛化规则之前——
 * 财报日历先于财报、引文先于论文、航班状态先于机票。
 */
const VERTICAL_RULES: readonly VerticalRule[] = [
  // 金融
  { tag: 'finance.calendar', label: '财报日历', keywords: ['财报日历', '除权', '分红日历', 'earnings calendar'] },
  { tag: 'finance.fundamental', label: '公司财报', keywords: ['财报', '营收'] },
  { tag: 'finance.macro', label: '宏观经济指标', keywords: ['gdp', 'cpi', '利率', '失业率', '通胀', '美联储', '非农', 'lpr', 'shibor'] },
  { tag: 'finance.news', label: '财经新闻', keywords: ['财经新闻', '财经资讯', '财经快讯', 'financial news'] },
  { tag: 'finance.screen', label: '股票筛选', keywords: ['选股', 'etf', '股票筛选', 'stock screener'] },
  { tag: 'finance.quote', label: '金融行情', keywords: ['股价', '行情', '涨跌', '股票', '汇率', '比特币', 'btc', 'stock price', 'stock quote'] },
  // 农业
  { tag: 'agriculture.fao', label: '农业统计', keywords: ['农业统计', '粮食产量', '农业产量', '粮农组织', 'fao'] },
  // 学术（引文先于论文：参考文献包含「文献」）
  { tag: 'academic.citation', label: '文献引用', keywords: ['引用', '引文', '参考文献', 'citation', 'citations'] },
  { tag: 'academic.paper', label: '学术论文', keywords: ['论文', '文献', 'paper', 'papers', 'arxiv', 'preprint'] },
  { tag: 'academic.dataset', label: '科研数据集', keywords: ['数据集', 'dataset', 'datasets'] },
  { tag: 'academic.person', label: '学者信息', keywords: ['学者', '教授', 'researcher', 'scientist'] },
  // 安全（扫描类先于情报类：「安全扫描/文件哈希」是更明确的动作）
  { tag: 'security.vuln', label: '漏洞信息', keywords: ['cve', '漏洞', 'vulnerability', 'vulnerabilities', 'cvss'] },
  { tag: 'security.scan', label: '威胁扫描', keywords: ['安全扫描', '威胁扫描', 'ioc 扫描', 'ioc扫描', '域名扫描', '文件哈希', '恶意链接'] },
  { tag: 'security.noise', label: 'IP 扫描噪声', keywords: ['扫描噪声', '背景噪声', '背景扫描', 'ip 噪声', 'ip噪声', 'ip noise', 'internet noise'] },
  { tag: 'security.intel', label: '威胁情报', keywords: ['恶意', '威胁情报', 'ip 信誉', 'ip信誉', 'threat intel', 'malware', 'ioc'] },
  // 法律
  { tag: 'legal.judicial', label: '判例', keywords: ['判例', '判决', 'case law', 'court ruling'] },
  { tag: 'legal.legislation', label: '法规', keywords: ['法规', '立法', '法律条文', 'legislation', 'statute'] },
  { tag: 'legal.enforcement', label: '行政处罚记录', keywords: ['行政处罚', '执法', 'enforcement', 'penalty'] },
  // 专利
  { tag: 'ip.global', label: '专利', keywords: ['专利', 'patent', 'patents'] },
  // 出行（航班状态先于机票；航班号由 matchVertical 的正则分支优先处理）
  { tag: 'travel.flight_status', label: '航班状态', keywords: ['航班号', '航班状态', 'flight status', 'flight number'] },
  { tag: 'travel.flight', label: '机票', keywords: ['机票', '航班'] },
  // 商业
  { tag: 'business.company', label: '公司信息', keywords: ['公司信息', '股东', '企业信息', '工商信息', '工商注册', 'company profile', 'shareholder'] },
  { tag: 'business.jobs', label: '招聘职位', keywords: ['招聘', '职位', 'job', 'jobs', 'hiring', 'career'] },
  // 「联系人」是找人的商务线索；「联系方式」只是普通名词，不收录。
  { tag: 'business.people', label: '商务联系人', keywords: ['商务联系人', '企业联系人', '联系人信息', '联系人', '高管邮箱', 'people search', 'email lookup'] },
  { tag: 'business.trade', label: '进出口贸易数据', keywords: ['进出口', '关税', '贸易数据', 'import', 'export', 'tariff'] },
  // 社媒：params.type 是「有把握参数」的既定例外（二轮复核裁决）——关键词本身点名了平台，
  // type 不是猜测；其余垂直没有把握时只下发 tag。
  { tag: 'social_media.social_media', label: '微博内容', params: { type: 'weibo' }, keywords: ['微博'] },
  { tag: 'social_media.social_media', label: 'X 内容', params: { type: 'x_top' }, keywords: ['twitter', '推特', 'x.com'] },
  { tag: 'social_media.social_media', label: 'Reddit 内容', params: { type: 'reddit_post' }, keywords: ['reddit'] },
  { tag: 'social_media.social_media', label: '公众号内容', params: { type: 'wechatmp' }, keywords: ['微信公众号', '公众号'] },
  // 健康
  { tag: 'health.drug', label: '药品信息', keywords: ['药品', '药物', 'drug', 'medication'] },
  { tag: 'health.trial', label: '临床试验', keywords: ['临床试验', 'clinical trial', 'clinical trials'] },
  { tag: 'health.stats', label: '公共卫生统计', keywords: ['公共卫生统计', '卫生统计', '预期寿命', '人均寿命', '死亡率', 'health statistics'] },
  // 环境
  { tag: 'environment.aqi', label: '空气质量', keywords: ['空气质量', 'aqi', 'pm2.5', 'pm10'] },
  // 能源
  { tag: 'energy.electricity', label: '电力与电价', keywords: ['电价', '发电', '电力', 'electricity', 'power price'] },
  { tag: 'energy.production', label: '能源产量与消费', keywords: ['能源产量', '能源消费', '石油产量', '原油产量', '天然气产量', '煤炭产量', 'energy production'] },
  // 游戏（电竞先于商店：电竞查询常带英雄联盟等具体词）
  { tag: 'gaming.esports', label: '电竞赛事与战绩', keywords: ['电竞', '英雄联盟', 'league of legends', 'lpl', 's赛', '排位', '段位', '战绩'] },
  { tag: 'gaming.store', label: '游戏信息', keywords: ['steam'] },
  // 影视（BT 种子；裸「种子」的农业歧义由 matchVertical 的语境守卫处理）
  TORRENT_RULE,
  // 图片
  { tag: 'resource.image', label: '图片素材', keywords: ['图片', '图库', '素材图', 'stock photo'] },
  // 代码
  { tag: 'code.snippet', label: '代码片段', keywords: ['代码片段', '找代码', 'code snippet', 'snippet'] },
  { tag: 'code.doc', label: '库文档', keywords: ['库文档', 'library docs', 'library documentation'] },
  // 通用搜索：general.general 等同默认网页搜索；命中后刻意不下发 vertical（见 matchVertical）。
  { tag: 'general.general', label: '通用网页搜索', keywords: ['通用搜索', '网页搜索', '普通搜索', 'general web search'] },
]

/** 「微博热搜/热榜」是平台专属频道：裸查询也走这里，不落通用热点榜（通用榜取不到微博数据）。 */
const WEIBO_HOT_RULE: VerticalRule = {
  tag: 'social_media.social_media',
  label: '微博热搜',
  params: { type: 'weibo_hot' },
  keywords: [],
}

/**
 * 航班号：两位字母（或「数字+字母」，覆盖 3U/9C 等航司）+ 3-4 位数字。
 * 至少含字母可避开 6 位股票代码（600519）。
 */
const FLIGHT_NUMBER = /\b(?:[a-z]{2}|[0-9][a-z])\d{3,4}\b/i

/** 有航班语境时不校验航司码；无语境时只认常见航司码，避免把 TS2345 这类错误码当航班。 */
const FLIGHT_CONTEXT_TERMS = ['航班', '机票', 'flight', '起飞', '降落', '到达', '延误', 'status'] as const

/** 常见航司二字码（国内主要航司 + 常见国际航司）。 */
const AIRLINE_CODES = new Set([
  'ca', 'mu', 'cz', 'hu', 'mf', '3u', 'zh', 'sc', 'gs', '9c', 'ho', 'kn', 'eu', 'fm', 'ns', 'gt',
  'jd', 'pn', 'qw', 'uq', 'dr', 'bk', 'gj', 'tv', 'ky', 'a6', 'dz', 'jr', 'lt', 'ry', '8l', 'g5',
  'cn', 'vd', 'xa', 'uw', 'aq', 'y8', 'gx', '9h', 'fh',
  'ua', 'aa', 'dl', 'ba', 'lh', 'af', 'kl', 'nh', 'jl', 'sq', 'cx', 'ek', 'qr', 'tk', 'ac', 'qf',
  'nz', 'oz', 'ke', 'tg', 'mh', 'ga', 'vn', 'pr', 'su', 'lo', 'os', 'lx', 'sk', 'ay', 'ib', 'az',
  'ei', 'wn', 'b6', 'f9', 'nk', 'ha', 'ws', 'am', 'et', 'ci', 'br', 'jq', 'fj', 'pg', 'mi', 'vj',
  'fd', 'ak', 'd7', 'z2', '5j', 'tw', 'bx', 'lj', 'ze', '7c', 'mm', 'gk', 'jw',
])

/** 提取航班号；英文句子里夹带的编号需有航班语境或已知航司码才认。 */
function extractFlightNumber(text: string): string | undefined {
  const match = FLIGHT_NUMBER.exec(text)
  if (match === null) return undefined
  const value = match[0]
  const hasContext = FLIGHT_CONTEXT_TERMS.some(term => text.includes(term))
  if (!hasContext) {
    // 中文查询没有航班语境时，「订单号 CA1234」这类单号不当航班号；
    // 英文查询仍按航司码白名单 + 无残留拉丁字母兜底（如 typescript error TS2345）。
    if (hasCjk(text)) return undefined
    const code = value.replace(/\d+$/, '').toLowerCase()
    if (!AIRLINE_CODES.has(code)) return undefined
    // 去掉编号后仍有拉丁字母，说明它混在英文句子里（如 typescript error CA1234），不认。
    if (LATIN_CHAR.test(text.replace(value, ' '))) return undefined
  }
  return value.toUpperCase()
}

/** 方法/决策形态词：解释型查询不该进垂直取数（强数据模式除外）。 */
const METHOD_GUARD_TERMS = [
  '怎么', '如何', '是什么', '什么是', '为什么', '格式', '写', '买', '申请', '下载', '安装', '教程', '推荐', '值得',
] as const

const CVE_ID = /\bcve-\d{4}-\d{4,}\b/i
const STOCK_CODE = /\b(?:sh|sz)?\d{6}\b/i
const TICKER = /\$[a-z]{1,5}\b/i

/** 强数据模式：方法形态词不能拦下明确的取数请求。 */
function hasStrongData(text: string): boolean {
  if (CVE_ID.test(text)) return true
  if (extractFlightNumber(text) !== undefined) return true
  if (STOCK_CODE.test(text)) return true
  return TICKER.test(text)
}

/**
 * 机票与 BT 资源的例外：明确要「买」机票、「下载」种子就是取数请求
 * （「买机票」「种子 下载」）；「怎么买/如何下载」这类方法问句仍被拦。
 * 买/下载 仍留在其他垂直的守卫里。
 */
function isMethodQuestion(text: string, tag: string): boolean {
  const exempt = tag === 'travel.flight' ? '买' : tag === 'film.torrent' ? '下载' : undefined
  const guards = exempt === undefined
    ? METHOD_GUARD_TERMS
    : METHOD_GUARD_TERMS.filter(term => term !== exempt)
  if (!guards.some(term => text.includes(term))) return false
  return !hasStrongData(text)
}

/** 行情查询里的泛化词：剥掉后仍有剩余，才认为股票标的明确（symbol 本身不猜）。 */
const QUOTE_GENERIC_TERMS = [
  '股价', '行情', '股票', '股市', '走势', '涨跌', '价格', '报价', '今日', '今天', '现在', '最新',
  '查询', '查一下', '一下', '帮我', '多少', '怎么样', '如何', '分析', '预测', '对比', '热点', '热门',
] as const

/** 非股票品类：只下发 tag，不硬填 type=stock。 */
const NON_STOCK_TERMS = [
  '比特币', 'btc', '以太坊', 'eth', 'ethereum', '加密货币', 'crypto', '虚拟货币', '汇率', 'forex',
] as const

/** 行情最小参数：股价/行情 + 明确标的 → type=stock；标的或品类不明确则不下发。 */
function quoteParams(text: string): Readonly<Record<string, string>> | undefined {
  if (NON_STOCK_TERMS.some(term => hasKeyword(text, term))) return undefined
  let rest = text
  for (const term of QUOTE_GENERIC_TERMS) rest = rest.split(term).join(' ')
  rest = rest.replace(/[\s\p{P}\p{S}]+/gu, '')
  return rest.length > 0 ? { type: 'stock' } : undefined
}

/** 命中第一条结构化取数规则；没有命中返回 undefined。 */
function matchVertical(text: string): VerticalRule | undefined {
  if (text.includes('微博') && HOT_TERMS.some(term => text.includes(term))) return WEIBO_HOT_RULE
  const flightNumber = extractFlightNumber(text)
  if (flightNumber !== undefined) {
    return { tag: 'travel.flight_status', label: '航班状态', params: { flight_number: flightNumber }, keywords: [] }
  }
  // 「种子」的歧义守卫：农业/种植语义不触发，只有 BT 语境词同现才取资源数据。
  if (text.includes('种子') && TORRENT_SEED_CONTEXT.some(term => hasKeyword(text, term))) {
    return TORRENT_RULE
  }
  const rule = VERTICAL_RULES.find(item => item.keywords.some(keyword => hasKeyword(text, keyword)))
  // general.general 与默认网页搜索等价：不下发 vertical，落回语言判据的默认路由。
  if (rule?.tag === 'general.general') return undefined
  return rule
}

/** 组装取数请求：只填能从查询确定的参数。 */
function buildVerticalRequest(rule: VerticalRule, text: string): VerticalRequest {
  if (rule.tag === 'finance.quote') {
    const params = rule.params ?? quoteParams(text)
    return params === undefined ? { tag: rule.tag } : { tag: rule.tag, params }
  }
  return rule.params === undefined ? { tag: rule.tag } : { tag: rule.tag, params: rule.params }
}

/**
 * 判定查询意图。规则全部本地确定性：同一查询永远得到同一决策。
 * 每个分支都产出一句用户语言的 note，供上层拼用户可见说明。
 */
export function routeSearchQuery(query: string): QueryAnalysis {
  const text = query.trim().toLowerCase()
  const bare = stripSyntaxOperators(text)
  const syntax = parseQuerySyntax(query)
  const languageText = withoutSyntaxPrefixes(text)
  const language: QueryAnalysis['language'] = !hasCjk(languageText) && LATIN_CHAR.test(languageText) ? 'english' : 'chinese'
  const terms = queryTerms(syntax.bareQuery)
  const topics = [...new Set(topicTerms(terms))]
  const analyze = (decision: RouteSeed): QueryAnalysis => ({
    ...decision,
    query,
    syntax,
    language,
    topics,
    terms,
    freshnessRequirement: syntax.after !== undefined || syntax.before !== undefined
      ? 'exact'
      : decision.intent === 'ai-news' || decision.intent === 'hot-list'
        ? 'high'
        : 'normal',
    verificationRequirement: decision.intent === 'research' ? 'high' : 'normal',
  })

  // 「微博热搜/热榜/热门/榜单」等平台专属榜单：跳过通用裸热点，交给 matchVertical 的 weibo_hot 分支
  // （判据与 matchVertical 的微博分支同源：微博 + 任一热点词，通用榜取不到微博数据）。
  const weiboHot = bare.includes('微博') && HOT_TERMS.some(term => bare.includes(term))

  // 裸热点用原文判：site:/lang: 的操作数剥离只服务垂直取数，不能把显式站点约束剥成裸热点。
  if (!weiboHot && isBareHotQuery(text)) {
    return analyze({ intent: 'hot-list', useHotTopics: true, note: { id: 'hot-list' } })
  }

  // AI 资讯同样用原文：site:openai.com 新闻 的域名本就是 AI 线索，剥离会丢意图。
  if (wantsAiNews(text)) {
    const wantsHotTopics = HOT_TERMS.some(term => bare.includes(term))
    return analyze({
      intent: 'ai-news',
      useHotTopics: wantsHotTopics,
      note: wantsHotTopics ? { id: 'ai-news-hot' } : { id: 'ai-news' },
    })
  }

  if (COMMUNITY_TERMS.some(term => bare.includes(term))) {
    return analyze({
      intent: 'community-opinion',
      wantAnswer: true,
      note: { id: 'community-opinion' },
    })
  }

  const vertical = matchVertical(bare)
  const wantsResearch = RESEARCH_TERMS.some(term => bare.includes(term))

  if (vertical !== undefined) {
    // 不对称规则：调研词 + 学术论文/引文 = 用户要的是多源综述，不是论文库取数；
    // 其余垂直与调研词同现时仍取数据（「股价对比」要的是行情）。
    const academicConflict = wantsResearch
      && (vertical.tag === 'academic.paper' || vertical.tag === 'academic.citation')
    if (!academicConflict && !isMethodQuestion(bare, vertical.tag)) {
      return analyze({
        intent: 'vertical-data',
        vertical: buildVerticalRequest(vertical, bare),
        note: { id: 'vertical-data', params: { label: vertical.label } },
      })
    }
  }

  if (wantsResearch) {
    return analyze({ intent: 'research', note: { id: 'research' } })
  }

  // 语言判据：含任何 CJK 字符即中文路径（site:/lang: 由上层处理，不参与判断）；
  // 否则只要出现拉丁字母就走英文网页，单个英文词也算。
  if (!hasCjk(languageText) && LATIN_CHAR.test(languageText)) {
    const developer = DEVELOPER_TERMS.some(term => hasKeyword(text, term))
    return analyze({
      intent: 'english-web',
      prefer: developer ? 'developer' : 'general-web',
      note: developer ? { id: 'english-web-developer' } : { id: 'english-web' },
    })
  }

  const developer = DEVELOPER_TERMS.some(term => hasKeyword(text, term))
  return analyze({
    intent: 'chinese-web',
    ...(developer ? { prefer: 'developer' as const } : {}),
    note: { id: 'chinese-web' },
  })
}
