// 查询语法解析器——AD13（spec §10，依据 .scratch/dev-loop/recon/deepseek-paid-baseline.md）。
// 解析 DeepSeek Search API 风格操作符：domains/-domains/lang/after/before。
// 复核 R2 修正：operators[] 携带每个操作符的**原样 token**（大小写、路径后缀、顺序逐字保留），
// 引擎回拼 unsupported 项的 raw；视图字段（domains/language/…）仅作参数映射，同名取最后值。
// 宽松解析：认不出的 token 原样留在 bareQuery；site: 后无合法域名不视为操作符。

import type { QueryOperator, QuerySyntax } from '../engines/contract.js'

export type { QueryOperator, QuerySyntax }

const DOMAIN_TOKEN = /^(-?)site:([A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)+)(?:\/\S*)?$/
const LANGUAGE_TOKEN = /^lang:([A-Za-z]{2}(?:,[A-Za-z]{2})*)$/
const DATE_VALUE = /^\d{4}(?:-\d{2}){0,2}$/
const AFTER_TOKEN = new RegExp(`^after:(${DATE_VALUE.source.slice(1, -1)})$`)
const BEFORE_TOKEN = new RegExp(`^before:(${DATE_VALUE.source.slice(1, -1)})$`)

/**
 * 解析一条查询的 DeepSeek 风格操作符。
 * operators 按出现顺序保留全部操作符（含重复）与原样 token；
 * 视图字段同名操作符取最后一个值。不含操作符时 operators 为空、bareQuery 为折叠原文。
 */
export function parseQuerySyntax(query: string): QuerySyntax {
  const operators: QueryOperator[] = []
  const bare: string[] = []

  for (const token of query.split(/\s+/)) {
    if (token.length === 0) continue
    const domain = DOMAIN_TOKEN.exec(token)
    if (domain !== null) {
      operators.push({
        kind: domain[1] === '-' ? '-site' : 'site',
        raw: token,
        value: domain[2]!.toLowerCase(),
      })
      continue
    }
    const lang = LANGUAGE_TOKEN.exec(token)
    if (lang !== null) {
      operators.push({ kind: 'lang', raw: token, value: lang[1]!.toLowerCase() })
      continue
    }
    const afterMatch = AFTER_TOKEN.exec(token)
    if (afterMatch !== null) {
      operators.push({ kind: 'after', raw: token, value: afterMatch[1]! })
      continue
    }
    const beforeMatch = BEFORE_TOKEN.exec(token)
    if (beforeMatch !== null) {
      operators.push({ kind: 'before', raw: token, value: beforeMatch[1]! })
      continue
    }
    bare.push(token)
  }

  const lastValue = (kind: QueryOperator['kind']): string | undefined => {
    for (let index = operators.length - 1; index >= 0; index -= 1) {
      if (operators[index]!.kind === kind) return operators[index]!.value
    }
    return undefined
  }

  return {
    operators,
    domains: operators.filter(operator => operator.kind === 'site').map(operator => operator.value),
    excludeDomains: operators.filter(operator => operator.kind === '-site').map(operator => operator.value),
    ...(lastValue('lang') === undefined ? {} : { language: lastValue('lang') }),
    ...(lastValue('after') === undefined ? {} : { after: lastValue('after') }),
    ...(lastValue('before') === undefined ? {} : { before: lastValue('before') }),
    bareQuery: bare.join(' '),
  }
}
