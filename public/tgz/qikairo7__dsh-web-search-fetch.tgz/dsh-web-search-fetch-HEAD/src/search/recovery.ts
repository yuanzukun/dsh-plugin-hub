// 搜索恢复策略：专属路由失败后的通用降级，以及单通道结果不足后的有界补派。

import type { WebSearchRequest } from '@deepseek-ai/dsh-web'

import type { Engine, EngineSearchOutcome } from '../engines/contract.js'
import type { CircuitBreaker } from '../support/breaker.js'
import type { OpContext } from '../support/budget.js'
import type { LaneOutcome } from '../support/lane-runner.js'
import { SettlementWindow } from '../support/settle.js'
import { LaneDispatcher } from './dispatch.js'
import { noteRouteReasons, renderNote } from './output.js'
import { officialHosts } from './quality.js'
import type { QueryAnalysis, SearchIntent } from './router.js'
import { resolveSearchCandidates, type SearchCandidateSource } from './selection.js'
import { SearchRoutePlanner } from './planner.js'
import type { SearchInsufficiencyReason } from './sufficiency.js'

type Outcome = LaneOutcome<EngineSearchOutcome>

interface SearchRecoveryOptions {
  readonly engines: readonly Engine[]
  readonly breaker: CircuitBreaker
  readonly ready: ((id: string, face: 'search' | 'fetch') => Promise<boolean>) | undefined
  readonly routeCandidates: SearchCandidateSource
  readonly planner: SearchRoutePlanner
  readonly dispatcher: LaneDispatcher
  readonly logger: { info(message: string): void; warn(message: string): void }
}

export class SearchRecovery {
  constructor(private readonly options: SearchRecoveryOptions) {}

  allowed(outcomes: readonly Outcome[], op: OpContext): boolean {
    if (op.deadlineReached || op.signal.aborted || op.remainingRequests <= 0) return false
    return !outcomes.some(outcome => {
      if (outcome.kind === 'timeout' || outcome.kind === 'aborted') return true
      return outcome.kind === 'failed'
        && ['rate-limited', 'quota', 'timeout', 'aborted'].includes(outcome.failure.kind)
    })
  }

  async degrade(
    request: WebSearchRequest,
    op: OpContext,
    analysis: QueryAnalysis,
    specialized: 'hot' | 'vertical',
    usedCandidates: readonly string[],
    usedEngines: readonly string[],
  ): Promise<{ outcomes: Outcome[]; endedEarly: boolean } | undefined> {
    const generalIntent: SearchIntent = analysis.language === 'chinese' ? 'chinese-web' : 'english-web'
    op.note(renderNote({
      id: specialized === 'vertical' ? 'vertical-degrade' : 'hot-degrade',
      params: { language: generalIntent === 'chinese-web' ? 'chinese' : 'english' },
    }))
    const candidates = await this.resolve(generalIntent, undefined, op, usedCandidates, usedEngines)
    const decision = this.options.planner.repair({
      candidates,
      gap: 'empty',
      mode: 'fallback',
    })
    noteRouteReasons(text => op.note(text), decision.reasons)
    if (decision.candidate === undefined) return undefined
    return this.dispatch([decision.candidate.engine], request, analysis, op, false, 'degrade-early-cancel')
  }

  async escalate(
    request: WebSearchRequest,
    outcomes: readonly Outcome[],
    op: OpContext,
    route: QueryAnalysis,
    reason: SearchInsufficiencyReason,
    usedCandidates: readonly string[],
    usedEngines: readonly string[],
  ): Promise<{ outcomes: Outcome[]; endedEarly: boolean } | undefined> {
    if (!recoverableFirstLane(outcomes)) return undefined
    if (op.deadlineReached || op.signal.aborted) return undefined
    if (op.remainingRequests <= 0) return undefined
    const candidates = await this.resolve(route.intent, route.prefer, op, usedCandidates, usedEngines)
    const decision = this.options.planner.repair({
      candidates,
      gap: reason,
      mode: 'supplement',
    })
    noteRouteReasons(text => op.note(text), decision.reasons)
    if (decision.candidate === undefined) return undefined
    this.options.logger.info(`[搜索] 单通道 ${outcomes[0]!.engineId} 结果不足（${reason}），补派 1 路搜索`)
    const officialHost = reason === 'official-source' && route.syntax.domains.length === 0
      ? officialHosts(route)[0]
      : undefined
    const narrowedRequest: WebSearchRequest = officialHost === undefined
      ? request
      : { query: `${request.query} site:${officialHost}`, maxResults: request.maxResults }
    return this.dispatch(
      [decision.candidate.engine],
      narrowedRequest,
      route,
      op,
      route.intent === 'ai-news' || route.intent === 'hot-list',
      'escalate-early-cancel',
    )
  }

  private async resolve(
    intent: SearchIntent,
    prefer: QueryAnalysis['prefer'],
    op: OpContext,
    excludeCandidates: readonly string[],
    excludeEngines: readonly string[],
  ) {
    return await resolveSearchCandidates({
      engines: this.options.engines,
      specs: this.options.routeCandidates(intent, prefer),
      controls: op.controls,
      breaker: this.options.breaker,
      ...(this.options.ready === undefined ? {} : { ready: this.options.ready }),
      exclude: new Set(excludeCandidates),
      excludeEngines: new Set(excludeEngines),
    })
  }

  private dispatch(
    engines: readonly Engine[],
    request: WebSearchRequest,
    analysis: QueryAnalysis,
    op: OpContext,
    news: boolean,
    earlyNote: 'degrade-early-cancel' | 'escalate-early-cancel',
  ) {
    const window = new SettlementWindow(op.signal)
    return this.options.dispatcher.dispatchRound(
      engines.map(engine => ({
        engine,
        query: request.query,
        ...(news ? { freshness: 'news' as const } : {}),
      })),
      window, analysis, request.maxResults, op,
    ).then(outcomes => {
      if (window.endedEarly) op.note(renderNote({ id: earlyNote }))
      return { outcomes, endedEarly: window.endedEarly }
    })
  }
}

export function recoverableFirstLane(outcomes: readonly Outcome[]): boolean {
  if (outcomes.length !== 1) return false
  const outcome = outcomes[0]!
  if (outcome.kind === 'ok') return true
  if (outcome.kind === 'timeout') return true
  return outcome.kind === 'failed'
    && ['provider-error', 'network', 'target-status', 'invalid'].includes(outcome.failure.kind)
}
