// 搜索恢复策略：专属路由失败后的通用降级，以及单通道结果不足后的有界补派。

import type { WebSearchRequest } from '@deepseek-ai/dsh-web'

import type { Engine, EngineSearchOutcome } from '../engines/contract.js'
import type { CircuitBreaker } from '../support/breaker.js'
import type { OpContext } from '../support/budget.js'
import type { LaneOutcome } from '../support/lane-runner.js'
import { SettlementWindow } from '../support/settle.js'
import { LaneDispatcher } from './dispatch.js'
import { renderNote } from './output.js'
import { officialHosts } from './quality.js'
import type { QueryAnalysis, SearchIntent } from './router.js'
import { orderCandidates, selectSearchEngines, type IntentEngines } from './selection.js'
import type { SearchInsufficiencyReason } from './sufficiency.js'

type Outcome = LaneOutcome<EngineSearchOutcome>

interface SearchRecoveryOptions {
  readonly engines: readonly Engine[]
  readonly breaker: CircuitBreaker
  readonly ready: ((id: string, face: 'search' | 'fetch') => Promise<boolean>) | undefined
  readonly intentEngines: IntentEngines
  readonly dispatcher: LaneDispatcher
  readonly logger: { info(message: string): void; warn(message: string): void }
}

export class SearchRecovery {
  constructor(private readonly options: SearchRecoveryOptions) {}

  allowed(outcomes: readonly Outcome[], op: OpContext): boolean {
    if (op.deadlineReached || op.signal.aborted || op.remainingRequests <= 0) return false
    return !outcomes.some(outcome => {
      if (outcome.kind === 'timeout' || outcome.kind === 'aborted') return true
      return outcome.kind === 'failed'
        && ['rate-limited', 'quota', 'timeout', 'aborted'].includes(outcome.failure.kind)
    })
  }

  async degrade(
    request: WebSearchRequest,
    outcomes: readonly Outcome[],
    op: OpContext,
    analysis: QueryAnalysis,
    specialized: 'hot' | 'vertical',
  ): Promise<{ outcomes: Outcome[]; endedEarly: boolean } | undefined> {
    const generalIntent: SearchIntent = analysis.language === 'chinese' ? 'chinese-web' : 'english-web'
    op.note(renderNote({
      id: specialized === 'vertical' ? 'vertical-degrade' : 'hot-degrade',
      params: { language: generalIntent === 'chinese-web' ? 'chinese' : 'english' },
    }))
    const used = new Set(outcomes.map(outcome => outcome.engineId))
    const priority = this.options.intentEngines(generalIntent, undefined)
    const candidates = orderCandidates(this.availableEngines(engine => !used.has(engine.manifest.id)), priority, this.options.engines)
    if (candidates.length === 0) return this.noChannel(op, 'degrade-no-channel')
    const rows = await selectSearchEngines(
      candidates, op, this.options.ready, undefined, false,
      priority.length > 0 ? candidates.map(engine => engine.manifest.id) : undefined,
    )
    const selected = rows.filter(engine => !this.options.breaker.isBroken(engine.manifest.id))
    if (selected.length === 0) return this.noChannel(op, 'degrade-no-channel')
    return this.dispatch(selected, request, analysis, op, false, 'degrade-early-cancel')
  }

  async escalate(
    request: WebSearchRequest,
    outcomes: readonly Outcome[],
    op: OpContext,
    route: QueryAnalysis,
    reason: SearchInsufficiencyReason,
  ): Promise<{ outcomes: Outcome[]; endedEarly: boolean } | undefined> {
    if (!recoverableFirstLane(outcomes)) return undefined
    if (op.deadlineReached || op.signal.aborted) return undefined
    const usedEngine = outcomes[0]!.engineId
    const priority = this.options.intentEngines(route.intent, route.prefer)
    const candidates = orderCandidates(this.availableEngines(engine => engine.manifest.id !== usedEngine), priority, this.options.engines)
    if (candidates.length === 0) return this.noChannel(op, 'escalate-no-channel')
    const remaining = op.remainingRequests
    if (remaining <= 0) return this.noChannel(op, 'escalate-budget-exhausted')
    const selected = await selectSearchEngines(
      candidates, op, this.options.ready,
      Math.min(remaining, 1), false,
      priority.length > 0 ? candidates.map(engine => engine.manifest.id) : undefined,
    )
    if (selected.length === 0) return this.noChannel(op, 'escalate-no-channel')
    this.options.logger.info(`[搜索] 单通道 ${usedEngine} 结果不足（${reason}），补派 ${selected.length} 路搜索`)
    op.note(renderNote({ id: 'escalate-selected', params: { engine: usedEngine, reason, selected: selected.length } }))
    const officialHost = reason === 'official-source' && route.syntax.domains.length === 0
      ? officialHosts(route)[0]
      : undefined
    const narrowedRequest: WebSearchRequest = officialHost === undefined
      ? request
      : { query: `${request.query} site:${officialHost}`, maxResults: request.maxResults }
    return this.dispatch(
      selected,
      narrowedRequest,
      route,
      op,
      route.intent === 'ai-news' || route.intent === 'hot-list',
      'escalate-early-cancel',
    )
  }

  private availableEngines(unused: (engine: Engine) => boolean): readonly Engine[] {
    return this.options.engines.filter(engine =>
      engine.manifest.capabilities.includes('search')
      && engine.search !== undefined
      && unused(engine)
      && !this.options.breaker.isBroken(engine.manifest.id))
  }

  private noChannel(op: OpContext, id: 'degrade-no-channel' | 'escalate-no-channel' | 'escalate-budget-exhausted') {
    op.note(renderNote({ id }))
    return undefined
  }

  private dispatch(
    engines: readonly Engine[],
    request: WebSearchRequest,
    analysis: QueryAnalysis,
    op: OpContext,
    news: boolean,
    earlyNote: 'degrade-early-cancel' | 'escalate-early-cancel',
  ) {
    const window = new SettlementWindow(op.signal)
    return this.options.dispatcher.dispatchRound(
      engines.map(engine => ({
        engine,
        query: request.query,
        ...(news ? { freshness: 'news' as const } : {}),
      })),
      window, analysis, request.maxResults, op,
    ).then(outcomes => {
      if (window.endedEarly) op.note(renderNote({ id: earlyNote }))
      return { outcomes, endedEarly: window.endedEarly }
    })
  }
}

export function recoverableFirstLane(outcomes: readonly Outcome[]): boolean {
  if (outcomes.length !== 1) return false
  const outcome = outcomes[0]!
  if (outcome.kind === 'ok') return true
  if (outcome.kind === 'timeout') return true
  return outcome.kind === 'failed'
    && ['provider-error', 'network', 'target-status', 'invalid'].includes(outcome.failure.kind)
}
