// 融合候选装配（ADR-0001 §5）：成功通道按派发序带 manifest 上游分组交给 RRF，
// 同组去重后做相关性过滤。纯函数，不派发、不写说明。

import type { WebSearchSource } from '@deepseek-ai/dsh-web'

import type { Engine } from '../engines/contract.js'
import { relevantOnly, rrfFuse, type FusedCandidate } from './fuse.js'
import { preferOfficial } from './quality.js'
import type { SearchOutcome } from './output.js'

/** 一路成功通道的排名输出。 */
export interface EngineRankingInput {
  readonly engineId: string
  readonly sources: readonly WebSearchSource[]
  readonly group?: string
}

/** 成功通道的排名输出（派发序），带上 manifest 的上游分组供融合前同组去重。 */
export function successfulRankings(outcomes: readonly SearchOutcome[], engines: readonly Engine[]): EngineRankingInput[] {
  return outcomes.flatMap(outcome => {
    if (outcome.kind !== 'ok') return []
    const group = engines.find(engine => engine.manifest.id === outcome.engineId)?.manifest.upstreamGroup
    return [{
      engineId: outcome.engineId,
      sources: outcome.result.sources,
      ...(group === undefined ? {} : { group }),
    }]
  })
}

/** 融合 + 相关性过滤成功的通道。 */
export function relevantCandidates(
  query: string,
  rankings: readonly EngineRankingInput[],
  rrfK: number,
): FusedCandidate[] {
  const perService = new Map<string, WebSearchSource[]>()
  const groups = new Map<string, string>()
  for (const ranking of rankings) {
    perService.set(ranking.engineId, [...(perService.get(ranking.engineId) ?? []), ...ranking.sources])
    if (ranking.group !== undefined) groups.set(ranking.engineId, ranking.group)
  }
  const fused = preferOfficial(query, rrfFuse([...perService].map(([engineId, sources]) => {
    const group = groups.get(engineId)
    return { engineId, sources, ...(group === undefined ? {} : { group }) }
  }), rrfK))
  return relevantOnly(query, fused)
}
