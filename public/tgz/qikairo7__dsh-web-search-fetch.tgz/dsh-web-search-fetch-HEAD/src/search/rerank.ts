// SiliconFlow 重排：融合后 top-30 经 BAAI/bge-reranker-v2-m3 重排序。
// 契约事实：POST /v1/rerank，响应 results[]{index, relevance_score}。
// 可达时重排序并在说明中可感知；失败 fail-open，按 RRF 序返回并记 note，绝不阻塞。

import type { EngineContext } from '../engines/contract.js'
import { engineFailure, type EngineFailure } from '../engines/failure.js'
import { engineJson, projectHttpError } from '../engines/http.js'
import { RERANK_SERVICE } from '../engines/registry.js'
import type { FusedCandidate } from './fuse.js'

/** 每个文档送重排的文本长度上限（TPM 安全：30 × 2KB 字符仍远低于 500k token）。 */
const MAX_DOCUMENT_CHARS = 2000

export interface RerankOutcome {
  /** 重排后的候选（失败时原序返回）。 */
  readonly ordered: readonly FusedCandidate[]
  /** 是否真的经过了重排（false = 未启用或 fail-open）。 */
  readonly reranked: boolean
  /** 操作说明事实行（呈现层拼中文）。 */
  readonly note?: string
  /** fail-open 时的失败分类（供日志/熔断外层使用；重排不进引擎熔断）。 */
  readonly failure?: EngineFailure
}

interface SiliconflowRerankResponse {
  readonly results?: ReadonlyArray<{ index?: number; relevance_score?: number }>
}

/**
 * 用 SiliconFlow bge-reranker-v2-m3 重排融合候选。
 * - 未配 key：直接返回原序（reranked:false，无 note——未启用不是事件）。
 * - 成功：按 relevance_score 降序，未被返回的候选按 RRF 序跟在后面，不丢结果。
 * - 失败（网络/限流/额度/解析）：fail-open 原序返回 + note，failure 供上层记录。
 */
export async function rerankCandidates(
  ctx: EngineContext,
  query: string,
  candidates: readonly FusedCandidate[],
): Promise<RerankOutcome> {
  if (ctx.apiKey === undefined) return { ordered: candidates, reranked: false }
  if (candidates.length === 0) return { ordered: candidates, reranked: false }

  const top = candidates.slice(0, RERANK_SERVICE.topN)
  const documents = top.map(candidate =>
    [
      candidate.title ?? '',
      candidate.url,
      candidate.publishedAt ?? '',
      candidate.summary ?? candidate.snippet ?? '',
    ].filter(part => part.length > 0).join('\n').slice(0, MAX_DOCUMENT_CHARS),
  )
  const tail = candidates.slice(RERANK_SERVICE.topN)

  try {
    const response = await engineJson<SiliconflowRerankResponse>(ctx, RERANK_SERVICE.endpoint, {
      method: 'POST',
      fetcher: (ctx as EngineContext & { fetcher?: typeof fetch }).fetcher,
      headers: {
        'authorization': `Bearer ${ctx.apiKey}`,
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        model: RERANK_SERVICE.model,
        query,
        documents,
        top_n: top.length,
        return_documents: false,
      }),
    })
    const scored = (response.results ?? [])
      .filter(entry => typeof entry.index === 'number' && entry.index >= 0 && entry.index < top.length)
      .map(entry => ({ index: entry.index!, score: entry.relevance_score ?? 0 }))
      .sort((left, right) => right.score - left.score)
    if (scored.length === 0) {
      return {
        ordered: candidates,
        reranked: false,
        note: '重排服务返回空结果，按融合序返回。',
        failure: engineFailure('provider-error', { detail: 'rerank empty results' }),
      }
    }
    const ranked = scored.map(entry => top[entry.index]!)
    const seen = new Set(ranked)
    const rest = [...top.filter(candidate => !seen.has(candidate)), ...tail]
    return { ordered: [...ranked, ...rest], reranked: true }
  } catch (error) {
    const failure = projectHttpError(error)
    return {
      ordered: candidates,
      reranked: false,
      note: `重排服务不可用（${failure.kind}），按融合排序返回。`,
      failure,
    }
  }
}
