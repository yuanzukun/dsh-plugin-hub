// 查询缓存的读取/写入策略（ADR-0001 §8）：机制在 support/query-cache，这里只决定何时读、写、绕过。
// TTL 按意图分档；显式时效语法与用户强制最新不读缓存；研究型不缓存。

import { queryCacheKey } from '../support/query-cache.js'
import type { QueryAnalysis, SearchIntent } from './router.js'

/** 一次搜索的缓存计划：是否可读写、TTL 与缓存键。 */
export interface SearchCachePolicy {
  /** 是否允许写入（也是命中的前提）。 */
  readonly cacheable: boolean
  /** 本次是否允许读取（用户强制最新时仍写不读）。 */
  readonly readable: boolean
  readonly ttlSeconds: number
  readonly key: string
}

/** 用户强制最新的查询词：读取绕过缓存（写入不绕过）。 */
const FORCE_FRESH_PATTERN = /最新|今天|刚刚|实时/

/** 按意图与查询形态给出本次搜索的缓存计划。 */
export function searchCachePolicy(input: {
  readonly analysis: QueryAnalysis
  readonly maxResults: number | undefined
  /** 影响结果的实时配置指纹；设置变更后不复用旧缓存。 */
  readonly fingerprint?: string
}): SearchCachePolicy {
  const ttlSeconds = cacheTtlSeconds(input.analysis.intent)
  // 显式时效语法（after:/before:）与不缓存意图（TTL 0）不读不写。
  const cacheable = ttlSeconds > 0
    && input.analysis.syntax.after === undefined
    && input.analysis.syntax.before === undefined
  return {
    cacheable,
    // 用户强制最新（查询自带「最新/今天/刚刚/实时」）时不读缓存；写入照常，
    // 让紧随其后的重复新鲜查询仍能复用本次结果。
    readable: cacheable && !FORCE_FRESH_PATTERN.test(input.analysis.query),
    ttlSeconds,
    key: queryCacheKey(input.analysis.query, input.analysis.intent, input.analysis.syntax.domains, input.maxResults, input.fingerprint),
  }
}

/** 查询缓存的意图 TTL（秒，ADR-0001 §8）：0 表示不缓存。 */
function cacheTtlSeconds(intent: SearchIntent): number {
  switch (intent) {
    case 'ai-news':
    case 'hot-list': return 300
    case 'vertical-data': return 900
    case 'research': return 0
    default: return 1800
  }
}
