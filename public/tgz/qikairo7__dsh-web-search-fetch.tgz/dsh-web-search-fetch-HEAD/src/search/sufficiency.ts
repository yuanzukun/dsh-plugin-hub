// 首轮结果的本地充分性判定：只消费已归一化候选，不发起模型或网络请求。

import type { QuerySyntax } from '../engines/contract.js'
import type { FusedCandidate } from './fuse.js'
import { isOfficial, officialHosts, topicMatches } from './quality.js'
import type { SearchIntent } from './router.js'

export type SearchInsufficiencyReason =
  | 'empty'
  | 'official-source'
  | 'research-coverage'
  | 'fresh-date'

export interface SearchSufficiencyInput {
  readonly query: string
  readonly intent: SearchIntent
  readonly freshnessRequirement: 'normal' | 'high' | 'exact'
  readonly verificationRequirement: 'normal' | 'high'
  readonly syntax: QuerySyntax
  readonly candidates: readonly FusedCandidate[]
  readonly hasAnswer: boolean
  readonly maxResults?: number
  readonly now: number
}

export interface SearchSufficiencyDecision {
  readonly sufficient: boolean
  readonly reason?: SearchInsufficiencyReason
}

export function assessSearchSufficiency(input: SearchSufficiencyInput): SearchSufficiencyDecision {
  if (input.candidates.length === 0 && !input.hasAnswer) return { sufficient: false, reason: 'empty' }

  const explicitHosts = input.syntax.domains
  const hosts = explicitHosts.length > 0 ? explicitHosts : officialHosts(input.syntax.bareQuery)
  const officialMatch = input.candidates.some(candidate => isOfficial(candidate.url, hosts) && topicMatches(input.query, candidate))

  let reason: SearchInsufficiencyReason | undefined
  if (hosts.length > 0 && !officialMatch) reason = 'official-source'
  if (reason === undefined
    && input.verificationRequirement === 'high'
    && explicitHosts.length === 0
    && input.candidates.length > 0
    && uniqueHosts(input.candidates) < Math.min(2, input.maxResults ?? 2)) {
    reason = 'research-coverage'
  }
  if (reason === undefined && input.freshnessRequirement === 'high' && input.candidates.length > 0) {
    const freshStart = input.now - 7 * 86_400_000
    const fresh = input.candidates.some(candidate => {
      const timestamp = candidate.publishedAt === undefined ? undefined : Date.parse(candidate.publishedAt)
      return timestamp !== undefined && Number.isFinite(timestamp) && timestamp >= freshStart
    })
    if (!fresh) reason = 'fresh-date'
  }
  if (reason !== undefined) {
    return { sufficient: false, reason }
  }

  return { sufficient: true }
}

function uniqueHosts(candidates: readonly FusedCandidate[]): number {
  const hosts = new Set<string>()
  for (const candidate of candidates) {
    try { hosts.add(new URL(candidate.url).hostname.replace(/^www\./, '')) } catch { hosts.add(candidate.url) }
  }
  return hosts.size
}
