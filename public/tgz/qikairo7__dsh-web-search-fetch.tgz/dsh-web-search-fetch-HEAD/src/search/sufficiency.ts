// 首轮结果的本地充分性判定：只消费查询分析与 SearchEvidence，不发起模型或网络请求。

import type { SearchEvidence } from './evidence.js'
import type { QueryAnalysis } from './router.js'

export type SearchInsufficiencyReason =
  | 'empty'
  | 'official-source'
  | 'research-coverage'
  | 'fresh-date'

export interface SearchSufficiencyInput {
  readonly analysis: QueryAnalysis
  readonly evidence: SearchEvidence
  readonly maxResults?: number
}

export interface SearchSufficiencyDecision {
  readonly sufficient: boolean
  readonly reason?: SearchInsufficiencyReason
}

export function assessSearchSufficiency(input: SearchSufficiencyInput): SearchSufficiencyDecision {
  const { analysis, evidence } = input
  if (evidence.candidates.length === 0 && !evidence.hasAnswer) return { sufficient: false, reason: 'empty' }

  let reason: SearchInsufficiencyReason | undefined
  if (evidence.officialRequired && !evidence.officialMatch) reason = 'official-source'
  if (reason === undefined
    && analysis.verificationRequirement === 'high'
    && analysis.syntax.domains.length === 0
    && evidence.candidates.length > 0
    && evidence.distinctHosts < Math.min(2, input.maxResults ?? 2)) {
    reason = 'research-coverage'
  }
  if (reason === undefined && analysis.freshnessRequirement === 'high' && evidence.candidates.length > 0 && !evidence.freshMatch) {
    reason = 'fresh-date'
  }
  if (reason !== undefined) {
    return { sufficient: false, reason }
  }

  return { sufficient: true }
}
