// RRF 融合与相关性过滤——v0.2 src/search-aggregate.ts:585-737 移植（spec §5 保留清单）。
// v0.3 改动（AD2/AD7）：normalizeSearchUrl 移入 support/url；质量规则移入 search/quality；
// 类型不再回流聚合器（修 v0.2 search-quality ↔ search-aggregate 类型循环）；
// 来源形状改用引擎契约的 EngineSearchSource（与 seam WebSearchSource 同形）。

import type { EngineSearchSource } from '../engines/contract.js'
import { normalizeSearchUrl } from '../support/url.js'
import { contentVariantKey, queryTerms, topicTerms, topicMatches } from './quality.js'

/** 一路引擎的排名输出。 */
export interface EngineRanking {
  readonly engineId: string
  readonly sources: readonly EngineSearchSource[]
  /** 上游分组（manifest.upstreamGroup 透传）：同组只计一路；缺省表示独立来源。 */
  readonly group?: string
}

/** 融合候选：URL 键、RRF 分、贡献引擎、按字段择优合并的来源字段。 */
export interface FusedCandidate {
  readonly url: string
  readonly score: number
  readonly contributors: readonly string[]
  readonly title?: string
  readonly snippet?: string
  readonly publishedAt?: string
}

/**
 * 各引擎排名输出的 Reciprocal Rank Fusion。
 * score(d) = Σ_engines 1/(k + rank(d))，rank 在每路内 1 起、每路每键至多计一次
 * （一路内重复键按其最好名次计一次）。平手按首次出现序，输出对给定输入确定。
 * 相同键合并为一个候选：逐字段择优——更长 snippet 胜、已有 title/publishedAt 胜、缺失字段从有它的副本补。
 */
export function rrfFuse(rankings: readonly EngineRanking[], k: number): FusedCandidate[] {
  const merged = new Map<string, { candidate: FusedCandidate; sequence: number }>();
  const variants = new Map<string, string>();
  let sequence = 0;

  for (const ranking of dedupeUpstreamGroups(rankings)) {
    const seenInEngine = new Set<string>();
    let rank = 0;
    for (const source of ranking.sources) {
      const normalized = normalizeSearchUrl(source.url);
      const identity = contentVariantKey(normalized, source.title);
      const key = variants.get(identity) ?? normalized;
      variants.set(identity, key);
      if (seenInEngine.has(key)) continue;
      seenInEngine.add(key);
      rank += 1;
      const contribution = 1 / (k + rank);

      const existing = merged.get(key);
      if (existing === undefined) {
        const candidate: FusedCandidate = {
          url: key,
          score: contribution,
          contributors: [ranking.engineId],
          ...optionalFields(source),
        };
        merged.set(key, { candidate, sequence: sequence++ });
        continue;
      }
      const current = existing.candidate;
      merged.set(key, {
        sequence: existing.sequence,
        candidate: {
          url: current.url,
          score: current.score + contribution,
          contributors: current.contributors.includes(ranking.engineId)
            ? current.contributors
            : [...current.contributors, ranking.engineId],
          ...mergeFields(current, source),
        },
      });
    }
  }

  return [...merged.values()]
    .sort((left, right) => right.candidate.score - left.candidate.score || left.sequence - right.sequence)
    .map((entry) => entry.candidate);
}

/**
 * 同组只保留排名最好的一路（v0.4 同源去重）：共享上游的引擎命中同一索引，
 * 多路同时计票会制造「多源命中」假共识。输入序即派发优先级，故取组内首个出现的一路；
 * 无组的路各自独立参与融合。
 */
function dedupeUpstreamGroups(rankings: readonly EngineRanking[]): readonly EngineRanking[] {
  const seenGroups = new Set<string>();
  return rankings.filter((ranking) => {
    if (ranking.group === undefined) return true;
    if (seenGroups.has(ranking.group)) return false;
    seenGroups.add(ranking.group);
    return true;
  });
}

/** 引擎没返回的可选字段不出现。 */
function optionalFields(source: EngineSearchSource): Partial<EngineSearchSource> {
  return {
    ...(source.title === undefined ? {} : { title: source.title }),
    ...(source.snippet === undefined ? {} : { snippet: source.snippet }),
    ...(source.publishedAt === undefined ? {} : { publishedAt: source.publishedAt }),
  };
}

/** 同键后到的副本并入已持候选：更长 snippet 胜，候选仍缺的字段补齐。 */
function mergeFields(current: FusedCandidate, incoming: EngineSearchSource): Partial<EngineSearchSource> {
  const title = pickText(current.title, incoming.title, (left) => left);
  const snippet = pickText(current.snippet, incoming.snippet, longer);
  const publishedAt = pickText(current.publishedAt, incoming.publishedAt, (left) => left);
  return {
    ...(title === undefined ? {} : { title }),
    ...(snippet === undefined ? {} : { snippet }),
    ...(publishedAt === undefined ? {} : { publishedAt }),
  };
}

/** 用 choose 在两个可选字符串间取优，或取存在的那一个。 */
function pickText(
  current: string | undefined,
  incoming: string | undefined,
  choose: (left: string, right: string) => string,
): string | undefined {
  if (current === undefined) return incoming;
  if (incoming === undefined) return current;
  return choose(current, incoming);
}

/** 更长者胜（平手保持现值）。 */
function longer(left: string, right: string): string {
  return right.length > left.length ? right : left;
}

/**
 * 单个连字符/下划线/点连接查询词的词段。
 * 线上一个词的查询仍可能是多个单词：引擎把 `deepseek-harness-guide` 按三个词索引。
 * 拆分让单词查询至少能按词段交集评判。短于两字符的片段（`-v-`、`-4-`）不承载主题，丢弃。
 */
function tokenSegments(term: string): string[] {
  const parts = term.split(/[-_+.]+/).filter(part => part.length >= 2);
  return parts.length >= 2 ? parts : [term];
}

/** 候选是否共享复合词段的严格多数。多数（而非「任一」）区分真连字符查询与随机词串。 */
function compoundTokenMatches(segments: readonly string[], candidate: FusedCandidate): boolean {
  const text = `${candidate.title ?? ''} ${candidate.snippet ?? ''} ${candidate.url}`.toLowerCase();
  const matched = segments.filter(segment => text.includes(segment)).length;
  return matched >= Math.floor(segments.length / 2) + 1;
}

/**
 * 丢弃与查询毫无关系的融合候选。
 * 两种形态：≥2 个主题词的查询按 topicMatches 判；单词查询一般放过（单词太薄，硬过滤会过度），
 * 但复合词不是单词——它拆成词段，只共享泛词段的候选不是答案，按词段多数判
 * （这就是 `mhovm-1984-…` 类乱码查询不再返回八张无关页、而 `deepseek-harness-guide` 仍匹配自己文档的原因）。
 * 时效限定词（最近/最新）先剔除再计数：以它开头的中文查询按主题判；
 * 剩余单一主题仍须命中——这让「最近的 AI 芯片新闻」保持相关，又不放天气页进来。
 */
export function relevantOnly(query: string, candidates: readonly FusedCandidate[]): FusedCandidate[] {
  const terms = topicTerms(queryTerms(query));
  if (terms.length >= 2) return candidates.filter(candidate => topicMatches(query, candidate));
  if (terms.length === 1) {
    const segments = tokenSegments(terms[0]!);
    if (segments.length >= 2) return candidates.filter(candidate => compoundTokenMatches(segments, candidate));
    if (queryTerms(query).length >= 2) return candidates.filter(candidate => topicMatches(query, candidate));
  }
  return [...candidates];
}
