// v0.3 搜索编排器——v0.2 src/search-aggregate.ts 的 searchOperation/dispatch/escalate/
// laneAcceptor/sweepDailyQuota 移植重设计（spec §5 保留 + §4 架构决策）。
// 关键改动（对 v0.2）：
// - AD2：引擎优先级 = registry 顺序（v0.2 硬编码 ['tavily','anysearch','exa','firecrawl','bing'] 删除）；
//   失败分类只读统一失败模型 EngineFailure，不再 import 引擎专用错误符号。
// - AD3：单路执行走 support/lane-runner（v0.2 dispatch 84 行内联骨架删除）。
// - AD5：显式 OpContext 替代 AsyncLocalStorage；说明经 op.note 收集。
// - AD6：熔断喂入 = breakerSignalOf(outcome.failure)，一处投影。
// - 新增：融合→相关性过滤后、官方优先前，插入 SiliconFlow 重排（spec §3.2，验收 R2）；
//   重排 fail-open，绝不阻塞。
// - AD9：额度日检从「死路径」变真——engines 带 quota()（registry 契约），remaining<=0 喂日级熔断。

import { WebError, type WebSearchProvider, type WebSearchRequest, type WebSearchResult } from '@deepseek-ai/dsh-web'

import type { Engine, EngineContext, EngineManifest, EngineSearchOutcome, QuotaReport, VerticalRequest } from '../engines/contract.js'
import { quotaReportSignal, type CircuitBreaker } from '../support/breaker.js'
import { type OpContext, type RuntimeControls, resolveRuntimeRequest, runOperation } from '../support/budget.js'
import type { LaneOutcome } from '../support/lane-runner.js'
import { SettlementWindow } from '../support/settle.js'
import { QueryCache } from '../support/query-cache.js'
import { localDayKey } from '../support/quota-ledger.js'
import { RERANK_SERVICE } from '../engines/registry.js'
import { officialHosts } from './quality.js'
import type { FusedCandidate } from './fuse.js'
import { selectServices, singleChannelSearch } from './preset.js'
import { parseQuerySyntax } from './query-syntax.js'
import { hasCjk, routeSearchQuery, type SearchIntent } from './router.js'
import { rerankCandidates } from './rerank.js'
import { allEnginesFailedError, buildEmptyOutput, buildSearchOutput, cachedResult, hasAnswer, renderLogSummary, renderNote } from './output.js'
import { searchCachePolicy } from './cache-policy.js'
import { LaneDispatcher } from './dispatch.js'
import { hotTopicsEngine, orderCandidates, type IntentEngines } from './selection.js'
import { relevantCandidates, successfulRankings } from './ranking.js'

export type { IntentEngines } from './selection.js'

export const AGGREGATED_PROVIDER_ID = 'aggregated'

/** 单路引擎默认 deadline（v0.2 DEFAULT_SEARCH_MAX_FANOUT_MS = 10s）。 */
export const DEFAULT_SEARCH_MAX_FANOUT_MS = 10_000
/** RRF 常数 k（标准 60）。 */
export const DEFAULT_RRF_K = 60

export interface SearchLogSink {
  info(message: string): void
  warn(message: string): void
  error(message: string): void
}

/** 装配层提供的引擎上下文构造器：凭证解析（异步、每操作）、端点覆盖、keyless 回退都归装配（AD2）。face 标明用途端点。 */
export type BuildEngineContext = (
  manifest: EngineManifest,
  op: OpContext,
  lane: { signal: AbortSignal; deadline: number; face: 'search' | 'quota' },
) => Promise<EngineContext>

export interface RerankOptions {
  /** 本次重排的密钥：禁用时返回 undefined；开关与密钥引用读同一次操作快照。 */
  resolve(op: OpContext): Promise<string | undefined>
  /** fetch 注入（离线测试）。 */
  fetcher?: typeof fetch
}

/** 单路结局的额度账本口径（v0.4）：只上报影响额度判断的三类，其余结局不入账。 */
export type LaneOutcomeKind = 'success' | 'rate-limited' | 'quota'

/** 垂直频道能力目录（装配层注入 AnysearchDomainCatalog 的薄接口）：校验 tag 是否存在与必填参数。 */
export interface VerticalCatalog {
  validate(
    tag: string,
    params?: Readonly<Record<string, string | number | boolean>>,
    budget?: { readonly signal?: AbortSignal; readonly countRequest?: () => boolean },
  ): Promise<{ readonly exists: boolean; readonly missingRequired: readonly string[] }>
}

export interface AggregatedSearchOptions {
  resolveControls(): RuntimeControls
  /** registry 顺序的引擎表（buildEngines 产物）。 */
  engines: readonly Engine[]
  breaker: CircuitBreaker
  buildContext: BuildEngineContext
  /** 凭证/可用性探测（装配层注入；key-auth 引擎无有效凭证时不进派发）。 */
  ready?: (id: string, face: 'search' | 'fetch') => Promise<boolean>
  logger?: SearchLogSink
  maxFanoutMs?: number
  rrfK?: number
  rerank?: RerankOptions
  /** 意图→有序引擎 id 列表（装配层注入；缺省=空映射，沿用 registry 顺序）。 */
  intentEngines?: IntentEngines
  /** 垂直 tag 目录校验（装配层注入；缺省不校验，按路由器的垂直请求派发）。 */
  verticalCatalog?: VerticalCatalog
  /** 单路结局回调（装配层注入本地额度账本；只在 success/rate-limited/quota 时调用）。 */
  onLaneOutcome?: (engineId: string, kind: LaneOutcomeKind) => void
  /**
   * 日检探测正常 resolve 时上报官方快照（含 available:false）。探测抛错不调用。
   * 装配层用它写官方快照仓；编排层不解释额度展示语义。
   */
  onQuotaReport?: (engineId: string, report: QuotaReport) => void
  /** 额度日检（默认开）。 */
  quotaCheck?: boolean
  now?: () => number
  /** 查询缓存（缺省用注入时钟新建；测试可注入独立时钟的实例验证 TTL）。 */
  queryCache?: QueryCache
  /** 影响搜索结果的实时配置指纹（装配层注入；设置变更后查询缓存键随之变化）。 */
  cacheFingerprint?: () => string
}

const SILENT_LOG: SearchLogSink = { info: () => undefined, warn: () => undefined, error: () => undefined }

type Outcome = LaneOutcome<EngineSearchOutcome>

/**
 * 注册在 ctx.web 上的聚合搜索 provider（id `aggregated`）。
 * 一次 search()：额度日检 → 熔断过滤 → 服务选择 → 官方域补充 → 并发派发（宽限窗口）
 * → 去重 RRF 融合 → 相关性过滤 →（空结果且单通道 → 补派一次）→ 重排 → 官方优先 → 截断与说明。
 */
export class AggregatedSearchProvider implements WebSearchProvider {
  readonly id = AGGREGATED_PROVIDER_ID
  /** 宿主 provider 目录元数据（master HEAD 的 WebProviderInfo 消费；0.2.1-rc.2 类型面无此字段，多余成员结构兼容）。 */
  readonly title = { en: 'Aggregated Web Search (5 engines)', zh: '聚合网络搜索（五引擎）' } as const
  readonly description = {
    en: 'Routes each query to the engine that fits it best (Zhihu for Chinese, AnySearch verticals, Tavily/Firecrawl for English, AIHOT for AI news), then fuses results with RRF and optional SiliconFlow rerank. Free tiers first; may use anonymous quotas.',
    zh: '按问题类型路由到最擅长的引擎（知乎中文、AnySearch 专业频道、Tavily/Firecrawl 英文、AIHOT 资讯），RRF 融合与可选 SiliconFlow 重排。免费额度优先，未配密钥时使用匿名额度。',
  } as const
  private readonly resolveControls: () => RuntimeControls
  private readonly engines: readonly Engine[]
  private readonly breaker: CircuitBreaker
  private readonly buildContext: BuildEngineContext
  private readonly ready: ((id: string, face: 'search' | 'fetch') => Promise<boolean>) | undefined
  private readonly logger: SearchLogSink
  private readonly rrfK: number
  private readonly rerank: RerankOptions | undefined
  private readonly intentEngines: IntentEngines
  private readonly verticalCatalog: VerticalCatalog | undefined
  private readonly quotaCheckEnabled: boolean
  private readonly now: () => number
  private readonly queryCache: QueryCache
  private readonly cacheFingerprint: (() => string) | undefined
  private readonly dispatcher: LaneDispatcher
  private readonly onQuotaReport: ((engineId: string, report: QuotaReport) => void) | undefined
  private quotaCheckedDay: string | undefined

  constructor(options: AggregatedSearchOptions) {
    this.resolveControls = options.resolveControls
    this.engines = options.engines
    this.breaker = options.breaker
    this.buildContext = options.buildContext
    this.ready = options.ready
    this.logger = options.logger ?? SILENT_LOG
    this.rrfK = positive(options.rrfK, DEFAULT_RRF_K)
    this.rerank = options.rerank
    this.intentEngines = options.intentEngines ?? (() => [])
    this.verticalCatalog = options.verticalCatalog
    this.quotaCheckEnabled = options.quotaCheck ?? true
    this.now = options.now ?? Date.now
    this.queryCache = options.queryCache ?? new QueryCache({ now: this.now })
    this.cacheFingerprint = options.cacheFingerprint
    this.onQuotaReport = options.onQuotaReport
    this.dispatcher = new LaneDispatcher({
      engines: this.engines,
      breaker: this.breaker,
      buildContext: this.buildContext,
      logger: this.logger,
      maxFanoutMs: positive(options.maxFanoutMs, DEFAULT_SEARCH_MAX_FANOUT_MS),
      rrfK: this.rrfK,
      now: this.now,
      onLaneOutcome: options.onLaneOutcome,
    })
  }

  /** 廉价本地可用性检查；凭证按调用解析，这里不答。 */
  available(): boolean { return true }

  async search(request: WebSearchRequest, signal?: AbortSignal): Promise<WebSearchResult> {
    const controls = resolveRuntimeRequest(this.resolveControls(), 'search', request.query)
    return runOperation(controls, 'search', signal, op => this.searchOperation(request, op))
  }

  private async searchOperation(request: WebSearchRequest, op: OpContext): Promise<WebSearchResult> {
    if (op.signal.aborted) throw abortedError(op.signal)
    // ADR-0001 §1：意图在操作入口判定一次，说明先行（先解释路由，再谈选择与派发）。
    const route = routeSearchQuery(request.query)
    op.note(renderNote(route.note))

    // ADR-0001 §8：路由判定后、任何派发与预算消耗前查缓存。
    // 读取/写入判定与 TTL 分档在 cache-policy；命中说明由 output 阶段统一呈现。
    const cache = searchCachePolicy({
      query: request.query,
      intent: route.intent,
      preset: op.controls.preset,
      syntax: parseQuerySyntax(request.query),
      maxResults: request.maxResults,
      fingerprint: this.cacheFingerprint?.(),
    })
    if (cache.readable) {
      const cached = this.queryCache.get(cache.key, cache.ttlSeconds)
      if (cached !== undefined) return cachedResult(cached.result, cached.ageSeconds)
    }

    const searchEngines = this.engines.filter(engine => engine.manifest.capabilities.includes('search') && engine.search !== undefined)
    // ADR-0001 §6：日检移到选择之前——本轮就跳过耗尽者（修 v0.3「先选后检、当轮照发」的顺序缺陷）。
    const enabled = searchEngines.filter(engine => op.controls.serviceEnabled?.[engine.manifest.id] ?? true)
    await this.sweepDailyQuota(enabled, op)
    if (op.signal.aborted) throw abortedError(op.signal)

    const active = searchEngines.filter(engine => !this.breaker.isBroken(engine.manifest.id))
    const skipped = searchEngines.filter(engine => this.breaker.isBroken(engine.manifest.id))
    for (const engine of skipped) this.logger.warn(`[搜索] 服务 ${engine.manifest.id} 已熔断，跳过本次派发`)

    // ADR-0001 §2：垂直 tag 先经能力目录校验（存在性 + 必填参数）；不合法 fail-open 回通用路由并记说明。
    let vertical = route.vertical
    let intent = route.intent
    if (vertical !== undefined && this.verticalCatalog !== undefined) {
      const verdict = await this.verticalVerdict(this.verticalCatalog, vertical, op)
      if (!verdict.exists || verdict.missingRequired.length > 0) {
        op.note(renderNote(verdict.missingRequired.length > 0
          ? { id: 'vertical-missing-params', params: { missing: verdict.missingRequired } }
          : { id: 'vertical-unavailable' }))
        vertical = undefined
        // fail-open 的通用路由按查询语言选：英文查询不落中文源（与降级判据同一入口）。
        intent = hasCjk(request.query) ? 'chinese-web' : 'english-web'
      }
    }

    // ADR-0001 §2：意图映射存在时其顺序优先，searchServices 退为成员资格过滤；
    // 无映射时保持进入顺序，让用户 searchServices 顺序生效。宽度上限作用于最终顺序。
    const intentPriority = this.intentEngines(intent, route.prefer)
    const orderedCandidates = orderCandidates(active, intentPriority, this.engines)
    const selectedRows = await selectServices(
      orderedCandidates.map(engine => ({
        engine,
        id: engine.manifest.id,
        free: engine.manifest.free ?? false,
        keyless: engine.manifest.keyless ?? false,
        ...(engine.manifest.keylessCapabilities === undefined
          ? {}
          : { keylessCapabilities: engine.manifest.keylessCapabilities }),
      })),
      op, 'search', this.ready, undefined, true, intent,
      intentPriority.length > 0 ? orderedCandidates.map(engine => engine.manifest.id) : undefined,
    )
    // 日检/凭证探测之后仍可能处于熔断：选择后再过滤一次（ADR-0001 §6）。
    const selected: Engine[] = []
    for (const row of selectedRows) {
      if (this.breaker.isBroken(row.id)) this.logger.warn(`[搜索] 服务 ${row.id} 已熔断，跳过本次派发`)
      else selected.push(row.engine)
    }
    if (op.signal.aborted) throw abortedError(op.signal)

    // ADR-0001 §2 + §7：热点/热榜意图且映射序内有引擎具备 hotTopics 时直接取榜单；
    // 无该能力或映射内引擎均不可用时回落普通 search。
    const hotEngine = hotTopicsEngine(selected, route, this.intentEngines)
    const specialized: 'hot' | 'vertical' | undefined = hotEngine !== undefined ? 'hot' : vertical !== undefined ? 'vertical' : undefined
    const window = new SettlementWindow(op.signal)
    let outcomes: Outcome[]
    if (hotEngine !== undefined) {
      outcomes = await this.dispatcher.dispatchHotTopics(hotEngine, window, op)
    } else {
      // 官方域补充检索：显式 single 预设与显式 site: 查询不加（拒绝覆盖宽度是刻意的）。
      const hosts = officialHosts(request.query)
      const singleChannel = op.controls.preset === 'single'
      const supplementary = singleChannel || /\bsite:/i.test(request.query) ? [] : hosts.flatMap(host =>
        // v0.3：优先级 = registry 顺序（AD2），不再硬编码引擎表。
        selected.slice(0, hosts.length > 1 ? 1 : 2).map(engine => ({ engine, query: `${request.query} site:${host}` })),
      )
      if (supplementary.length) op.note(renderNote({ id: 'official-supplement', params: { count: supplementary.length } }))
      outcomes = await this.dispatcher.dispatchRound(
        [
          ...selected.map(engine => ({
            engine,
            query: request.query,
            ...(vertical === undefined ? {} : { vertical }),
            ...(route.wantAnswer === true ? { wantAnswer: true } : {}),
          })),
          ...supplementary,
        ],
        window, request, op,
      )
    }
    let endedEarly = window.endedEarly
    if (endedEarly) op.note(renderNote({ id: 'early-cancel' }))
    if (op.signal.aborted && !op.deadlineReached) throw abortedError(op.signal)

    let rankings = successfulRankings(outcomes, this.engines)
    let relevant = rankings.length === 0 ? [] : relevantCandidates(request.query, rankings, this.rrfK)
    // ADR-0001 §7：无 URL 的结构化数据序列化在 content 里，同样是「有产出」。
    // 只有 sources 与 content 双空才触发降级/空结果补派。
    let produced = relevant.length > 0 || hasAnswer(outcomes)
    // ADR-0001 §4：垂直/热榜路由无可用结果时按查询语言降级为通用路由重试一次；
    // 429/额度/超时的通道不重试（预算已花，沿用 Issue #20 语义），每操作至多一次。
    if (specialized !== undefined && !produced && this.degradationAllowed(outcomes, op)) {
      const degraded = await this.degradeRoute(request, outcomes, op, specialized)
      if (degraded !== undefined) {
        outcomes = [...outcomes, ...degraded.outcomes]
        endedEarly = endedEarly || degraded.endedEarly
        rankings = successfulRankings(outcomes, this.engines)
        relevant = rankings.length === 0 ? [] : relevantCandidates(request.query, rankings, this.rrfK)
        produced = relevant.length > 0 || hasAnswer(outcomes)
      }
    }

    if (rankings.length === 0) {
      if (op.deadlineReached) throw new WebError('search deadline exceeded', 'WEB_SEARCH_TIMEOUT')
      throw allEnginesFailedError([...outcomes, ...skipped.map(engine => ({ kind: 'skipped' as const, engineId: engine.manifest.id }))])
    }

    if (!produced) {
      // Issue #20 二阶段语义：单通道恰可补派一次（失败/超时/取消/限流的通道不补派——预算已花，
      // 其余通道大概率同因受限）；补派结果并入同一融合与过滤；不会有第二次补派。
      const escalation = await this.escalateEmptySearch(request, outcomes, op, route.intent)
      if (escalation !== undefined) {
        outcomes = [...outcomes, ...escalation.outcomes]
        endedEarly = endedEarly || escalation.endedEarly
        relevant = relevantCandidates(request.query, successfulRankings(outcomes, this.engines), this.rrfK)
        produced = relevant.length > 0 || hasAnswer(outcomes)
      }
    }

    if (!produced) {
      // 两种零结果形态到此为止：所有通道空返回，或候选存在但全被相关性过滤。
      // 输出阶段统一组装逐路状态说明、答案与 truncated。
      const output = buildEmptyOutput({
        outcomes,
        notes: op.notes,
        requestCount: op.requestCount,
        endedEarly,
        deadlineReached: op.deadlineReached,
      })
      this.logger.info(`[搜索] ${output.content}`)
      return { sources: [], content: output.content, truncated: output.truncated }
    }

    // 重排（spec §3.2）：融合→过滤后的候选经 SiliconFlow 重排序；fail-open 不阻塞。
    let ordered: readonly FusedCandidate[] = relevant
    const rerankKey = this.rerank !== undefined ? await this.rerank.resolve(op) : undefined
    if (rerankKey !== undefined) {
      const rerankContext: EngineContext = {
        signal: op.signal,
        deadline: this.now() + 5_000,
        apiKey: rerankKey,
        endpoint: RERANK_SERVICE.endpoint,
        countRequest: () => op.countRequest(),
        ...(this.rerank?.fetcher !== undefined ? { fetcher: this.rerank.fetcher } : {}),
      } as EngineContext
      const reranked = await rerankCandidates(rerankContext, request.query, relevant)
      ordered = reranked.ordered
      if (reranked.reranked) op.note(renderNote({ id: 'rerank-applied' }))
      else if (reranked.note !== undefined) op.note(reranked.note)
    }

    // ADR-0001 §7/§9/§10/§11：输出阶段一次完成多样性、预算、归因、答案合并与 truncated 汇总。
    const output = buildSearchOutput({
      query: request.query,
      candidates: ordered,
      maxResults: request.maxResults,
      maxOutputChars: op.controls.maxOutputChars,
      outcomes,
      endedEarly,
      deadlineReached: op.deadlineReached,
      notes: op.notes,
      requestCount: op.requestCount,
    })
    this.logger.info(`[搜索] ${renderLogSummary(output.notes, op.requestCount)}`)
    const finalResult: WebSearchResult = {
      ...(output.content === undefined ? {} : { content: output.content }),
      sources: [...output.sources],
      truncated: output.truncated,
    }
    // ADR-0001 §8：只缓存最终成功结果（含降级重试后的形态）；空结果不写，
    // 避免把一次偶发空返回固定一个 TTL。命中说明由读取分支加在 content 前。
    if (cache.cacheable && finalResult.sources.length > 0) this.queryCache.set(cache.key, finalResult, cache.ttlSeconds)
    return finalResult
  }

  /** 垂直 tag 校验：目录拒绝或抛错都按不可用处理（fail-open 回通用路由）；请求预算由目录在发网络请求前消费。 */
  private async verticalVerdict(catalog: VerticalCatalog, request: VerticalRequest, op: OpContext): Promise<{ exists: boolean; missingRequired: readonly string[] }> {
    try {
      return await catalog.validate(request.tag, request.params, {
        signal: op.signal,
        countRequest: () => op.countRequest(),
      })
    } catch (error) {
      this.logger.warn(`[搜索] 垂直频道校验失败，按不可用处理：${describeError(error)}`)
      return { exists: false, missingRequired: [] }
    }
  }

  /** 有界降级的前置条件：预算内、未取消、且失败不属于「不重试」类型。 */
  private degradationAllowed(outcomes: readonly Outcome[], op: OpContext): boolean {
    if (op.deadlineReached || op.signal.aborted || op.remainingRequests <= 0) return false
    for (const outcome of outcomes) {
      if (outcome.kind === 'timeout' || outcome.kind === 'aborted') return false
      if (outcome.kind !== 'failed') continue
      const kind = outcome.failure.kind
      if (kind === 'rate-limited' || kind === 'quota' || kind === 'timeout' || kind === 'aborted') return false
    }
    return true
  }

  /**
   * 有界降级（ADR-0001 §4）：垂直/热榜路由无可用结果时，按查询语言走通用路由重试一次。
   * 已派发过的引擎不重复（重试意义在换通道）；没有可用通道时只记说明。
   */
  private async degradeRoute(
    request: WebSearchRequest,
    outcomes: readonly Outcome[],
    op: OpContext,
    specialized: 'hot' | 'vertical',
  ): Promise<{ outcomes: Outcome[]; endedEarly: boolean } | undefined> {
    const generalIntent: SearchIntent = hasCjk(request.query) ? 'chinese-web' : 'english-web'
    op.note(renderNote({
      id: specialized === 'vertical' ? 'vertical-degrade' : 'hot-degrade',
      params: { language: generalIntent === 'chinese-web' ? 'chinese' : 'english' },
    }))
    const used = new Set(outcomes.map(outcome => outcome.engineId))
    const priority = this.intentEngines(generalIntent, undefined)
    const candidates = orderCandidates(
      this.engines.filter(engine =>
        engine.manifest.capabilities.includes('search')
        && engine.search !== undefined
        && !used.has(engine.manifest.id)
        && !this.breaker.isBroken(engine.manifest.id)),
      priority,
      this.engines,
    )
    if (candidates.length === 0) { op.note(renderNote({ id: 'degrade-no-channel' })); return undefined }
    const rows = await selectServices(
      candidates.map(engine => ({
        engine,
        id: engine.manifest.id,
        free: engine.manifest.free ?? false,
        keyless: engine.manifest.keyless ?? false,
        ...(engine.manifest.keylessCapabilities === undefined
          ? {}
          : { keylessCapabilities: engine.manifest.keylessCapabilities }),
      })),
      op, 'search', this.ready, undefined, false, generalIntent,
      priority.length > 0 ? candidates.map(engine => engine.manifest.id) : undefined,
    )
    const selected = rows.map(row => row.engine).filter(engine => !this.breaker.isBroken(engine.manifest.id))
    if (selected.length === 0) { op.note(renderNote({ id: 'degrade-no-channel' })); return undefined }
    const window = new SettlementWindow(op.signal)
    const degraded = await this.dispatcher.dispatchRound(
      selected.map(engine => ({ engine, query: request.query })),
      window, request, op,
    )
    if (window.endedEarly) op.note(renderNote({ id: 'degrade-early-cancel' }))
    return { outcomes: degraded, endedEarly: window.endedEarly }
  }

  /**
   * 单通道空结果补派（恰一次）。补派尊重预设服务表、启用位、凭证、服务上限与剩余请求预算，
   * 并自报选择说明（不重复首轮通用选择行）。
   */
  private async escalateEmptySearch(
    request: WebSearchRequest,
    outcomes: readonly Outcome[],
    op: OpContext,
    intent: SearchIntent,
  ): Promise<{ outcomes: Outcome[]; endedEarly: boolean } | undefined> {
    if (!singleChannelSearch(intent, op.controls)) return undefined
    if (outcomes.some(outcome => outcome.kind !== 'ok')) return undefined
    const services = new Set(outcomes.map(outcome => outcome.engineId))
    if (services.size !== 1) return undefined
    if (op.deadlineReached || op.signal.aborted) return undefined
    const candidates = this.engines
      .filter(engine => engine.manifest.capabilities.includes('search') && engine.search !== undefined)
      .filter(engine => !services.has(engine.manifest.id) && !this.breaker.isBroken(engine.manifest.id))
    if (candidates.length === 0) { op.note(renderNote({ id: 'escalate-no-channel' })); return undefined }
    const remaining = op.remainingRequests
    if (remaining <= 0) { op.note(renderNote({ id: 'escalate-budget-exhausted' })); return undefined }
    const limit = Math.min(op.controls.maxSearchServices ?? 5, remaining)
    const rows = await selectServices(
      candidates.map(engine => ({
        engine,
        id: engine.manifest.id,
        free: engine.manifest.free ?? false,
        keyless: engine.manifest.keyless ?? false,
        ...(engine.manifest.keylessCapabilities === undefined
          ? {}
          : { keylessCapabilities: engine.manifest.keylessCapabilities }),
      })),
      op, 'search', this.ready, limit, false,
    )
    const selected = rows.map(row => row.engine)
    if (selected.length === 0) { op.note(renderNote({ id: 'escalate-no-channel' })); return undefined }
    const engineId = [...services][0]!
    const laneCount = outcomes.length
    this.logger.info(`[搜索] 单通道 ${engineId} 无相关结果，补派 ${selected.length} 路搜索`)
    op.note(renderNote({
      id: 'escalate-selected',
      params: { engine: engineId, attempts: laneCount, selected: selected.length },
    }))
    const window = new SettlementWindow(op.signal)
    const escalated = await this.dispatcher.dispatchRound(
      selected.map(engine => ({ engine, query: request.query })),
      window, request, op,
    )
    if (window.endedEarly) op.note(renderNote({ id: 'escalate-early-cancel' }))
    return { outcomes: escalated, endedEarly: window.endedEarly }
  }

  /**
   * 额度日检：每个带 quota() 的引擎每本地日至多探测一次；先标记后探测，
   * 单个探测失败不会让管道整天重试；探测失败只记日志，不阻塞搜索（v0.2 语义原样，AD9 成真）。
   */
  private async sweepDailyQuota(engines: readonly Engine[], op: OpContext): Promise<void> {
    if (!this.quotaCheckEnabled) return
    const day = localDayKey(this.now())
    if (this.quotaCheckedDay === day) return
    this.quotaCheckedDay = day
    // ADR-0001 §6：无额度端点的源只有本地观察计数——明示「估算」，不伪造余额/剩余量。
    const estimated = engines.filter(engine => engine.manifest.endpoints.quota === undefined)
    if (estimated.length > 0) {
      op.note(renderNote({ id: 'quota-estimated', params: { engines: estimated.map(engine => engine.manifest.label) } }))
    }
    for (const engine of engines) {
      if (engine.quota === undefined) continue
      try {
        const quota = await engine.quota(await this.buildContext(engine.manifest, op, { signal: op.signal, deadline: this.now() + 10_000, face: 'quota' }))
        // 正常 resolve 的探测都上报（available:false 也是引擎自述事实）；抛错路径维持现状，不入仓。
        this.onQuotaReport?.(engine.manifest.id, quota)
        const signal = quotaReportSignal(quota)
        if (signal !== undefined) {
          this.breaker.recordSignal(engine.manifest.id, signal)
          this.logger.warn(`[搜索] 引擎 ${engine.manifest.id} 当日额度已耗尽（remaining ${quota.remaining}），本次起停用`)
        }
      } catch (error) {
        this.logger.warn(`[搜索] 引擎 ${engine.manifest.id} 额度查询失败，忽略并继续：${describeError(error)}`)
      }
    }
  }
}

/** 有界、无凭据的异常描述。 */
function describeError(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error)
  return message.length <= 200 ? message : `${message.slice(0, 200)}…`
}

/** 操作自身取消 → seam 的取消码。 */
function abortedError(signal: AbortSignal): WebError {
  return new WebError('Aggregated web search aborted', 'WEB_ABORTED', { cause: signal.reason })
}

/** 有限正数覆盖或默认。 */
function positive(value: number | undefined, fallback: number): number {
  return value !== undefined && Number.isFinite(value) && value > 0 ? value : fallback
}
