// 搜索编排器：额度日检、来源选择、首轮单路、质量评估、有界补派、融合与输出。

import { WebError, type WebSearchProvider, type WebSearchRequest, type WebSearchResult } from '@deepseek-ai/dsh-web'

import type { Engine, EngineContext, EngineManifest, EngineSearchOutcome, QuotaReport, VerticalRequest } from '../engines/contract.js'
import type { CircuitBreaker } from '../support/breaker.js'
import {
  runOperation,
  SharedRequestBudget,
  type OpContext,
  type RuntimeControls,
  resolveRuntimeRequest,
} from '../support/budget.js'
import type { LaneOutcome } from '../support/lane-runner.js'
import type { LaneOutcomeKind } from '../support/lane-settlement.js'
import { SettlementWindow } from '../support/settle.js'
import { QueryCache } from '../support/query-cache.js'
import { RERANK_SERVICE } from '../engines/registry.js'
import type { FusedCandidate } from './fuse.js'
import { routeSearchQuery, type SearchIntent } from './router.js'
import { rerankCandidates } from './rerank.js'
import { allEnginesFailedError, buildEmptyOutput, buildSearchOutput, cachedResult, hasAnswer, renderLogSummary, renderNote } from './output.js'
import { searchCachePolicy } from './cache-policy.js'
import { LaneDispatcher } from './dispatch.js'
import { buildSearchEvidence } from './evidence.js'
import { hotTopicsEngine, orderCandidates, selectSearchEngines, type IntentEngines } from './selection.js'
import { relevantCandidates, successfulRankings } from './ranking.js'
import { DailyQuotaSweeper } from './quota-sweep.js'
import { assessSearchSufficiency } from './sufficiency.js'
import { governDates } from './temporal.js'
import { recoverableFirstLane, SearchRecovery } from './recovery.js'

export type { IntentEngines } from './selection.js'

export const AGGREGATED_PROVIDER_ID = 'aggregated'

/** 单路引擎默认 deadline（10 秒）。 */
export const DEFAULT_SEARCH_MAX_FANOUT_MS = 10_000
/** auto 首轮 8 秒，为一次质量不足后的补派预留总限时。 */
export const AUTO_FIRST_LANE_MS = 8_000
/** RRF 常数 k（标准 60）。 */
export const DEFAULT_RRF_K = 60

export interface SearchLogSink {
  info(message: string): void
  warn(message: string): void
  error(message: string): void
}

/** 装配层提供的引擎上下文构造器：凭证解析、端点覆盖、keyless 回退都归装配。face 标明用途端点。 */
export type BuildEngineContext = (
  manifest: EngineManifest,
  op: OpContext,
  lane: { signal: AbortSignal; deadline: number; face: 'search' | 'quota' },
) => Promise<EngineContext>

export interface RerankOptions {
  /** 本次重排的密钥：禁用时返回 undefined；开关与密钥引用读同一次操作快照。 */
  resolve(op: OpContext): Promise<string | undefined>
  /** fetch 注入（离线测试）。 */
  fetcher?: typeof fetch
}

/** 垂直频道能力目录（装配层注入 AnysearchDomainCatalog 的薄接口）：校验 tag 是否存在与必填参数。 */
export interface VerticalCatalog {
  validate(
    tag: string,
    params?: Readonly<Record<string, string | number | boolean>>,
    budget?: { readonly signal?: AbortSignal; readonly countRequest?: () => boolean },
  ): Promise<{ readonly exists: boolean; readonly missingRequired: readonly string[] }>
}

export interface AggregatedSearchOptions {
  resolveControls(): RuntimeControls
  /** registry 顺序的引擎表（buildEngines 产物）。 */
  engines: readonly Engine[]
  breaker: CircuitBreaker
  buildContext: BuildEngineContext
  /** 凭证/可用性探测（装配层注入；key-auth 引擎无有效凭证时不进派发）。 */
  ready?: (id: string, face: 'search' | 'fetch') => Promise<boolean>
  logger?: SearchLogSink
  maxFanoutMs?: number
  rrfK?: number
  rerank?: RerankOptions
  /** 意图→有序引擎 id 列表（装配层注入；缺省=空映射，沿用 registry 顺序）。 */
  intentEngines?: IntentEngines
  /** 垂直 tag 目录校验（装配层注入；缺省不校验，按路由器的垂直请求派发）。 */
  verticalCatalog?: VerticalCatalog
  /** 单路结局回调（装配层注入本地额度账本；只在 success/rate-limited/quota 时调用）。 */
  onLaneOutcome?: (engineId: string, kind: LaneOutcomeKind) => void
  /**
   * 日检探测正常 resolve 时上报官方快照（含 available:false）。探测抛错不调用。
   * 装配层用它写官方快照仓；编排层不解释额度展示语义。
   */
  onQuotaReport?: (engineId: string, report: QuotaReport) => void
  /** 额度日检（默认开）。 */
  quotaCheck?: boolean
  now?: () => number
  /** 查询缓存（缺省用注入时钟新建；测试可注入独立时钟的实例验证 TTL）。 */
  queryCache?: QueryCache
  /** 影响搜索结果的实时配置指纹（装配层注入；设置变更后查询缓存键随之变化）。 */
  cacheFingerprint?: () => string
}

const SILENT_LOG: SearchLogSink = { info: () => undefined, warn: () => undefined, error: () => undefined }

type Outcome = LaneOutcome<EngineSearchOutcome>

/**
 * 注册在 ctx.web 上的搜索 provider（id `aggregated`）。
 * 一次 search()：额度日检 → 熔断过滤 → 首轮单路 → 相关性与充分性评估
 * → 结果不足时补派一路 → RRF 融合 → 重排 → 输出治理。
 */
export class AggregatedSearchProvider implements WebSearchProvider {
  readonly id = AGGREGATED_PROVIDER_ID
  /** 宿主 provider 目录元数据；title 是字符串，description 支持多语言。 */
  readonly title = 'Minimal-Sufficient Web Search'
  readonly description = {
    en: 'Analyzes each query locally, starts with the best-fitting engine, and adds one more source only when relevance, authority, coverage, or freshness is insufficient. Free tiers first; may use anonymous quotas.',
    zh: '本地分析查询后先调用最合适的一路；仅在相关性、权威性、覆盖或时效不足时补派一路。免费额度优先，未配密钥时使用匿名额度。',
  } as const
  private readonly resolveControls: () => RuntimeControls
  private readonly engines: readonly Engine[]
  private readonly breaker: CircuitBreaker
  private readonly buildContext: BuildEngineContext
  private readonly engineReady: ((id: string, face: 'search' | 'fetch') => Promise<boolean>) | undefined
  private readonly logger: SearchLogSink
  private readonly maxFanoutMs: number
  private readonly rrfK: number
  private readonly rerank: RerankOptions | undefined
  private readonly intentEngines: IntentEngines
  private readonly verticalCatalog: VerticalCatalog | undefined
  private readonly now: () => number
  private readonly queryCache: QueryCache
  private readonly cacheFingerprint: (() => string) | undefined
  private readonly dispatcher: LaneDispatcher
  private readonly recovery: SearchRecovery
  private readonly quotaSweeper: DailyQuotaSweeper
  private readonly batchBudgets = new WeakMap<AbortSignal, SharedRequestBudget>()

  constructor(options: AggregatedSearchOptions) {
    this.resolveControls = options.resolveControls
    this.engines = options.engines
    this.breaker = options.breaker
    this.buildContext = options.buildContext
    this.engineReady = options.ready
    this.logger = options.logger ?? SILENT_LOG
    this.maxFanoutMs = positive(options.maxFanoutMs, DEFAULT_SEARCH_MAX_FANOUT_MS)
    this.rrfK = positive(options.rrfK, DEFAULT_RRF_K)
    this.rerank = options.rerank
    this.intentEngines = options.intentEngines ?? (() => [])
    this.verticalCatalog = options.verticalCatalog
    this.now = options.now ?? Date.now
    this.queryCache = options.queryCache ?? new QueryCache({ now: this.now })
    this.cacheFingerprint = options.cacheFingerprint
    this.quotaSweeper = new DailyQuotaSweeper({
      enabled: options.quotaCheck ?? true,
      breaker: this.breaker,
      buildContext: this.buildContext,
      logger: this.logger,
      now: this.now,
      onQuotaReport: options.onQuotaReport,
    })
    this.dispatcher = new LaneDispatcher({
      engines: this.engines,
      breaker: this.breaker,
      buildContext: this.buildContext,
      logger: this.logger,
      maxFanoutMs: this.maxFanoutMs,
      rrfK: this.rrfK,
      now: this.now,
      onLaneOutcome: options.onLaneOutcome,
    })
    this.recovery = new SearchRecovery({
      engines: this.engines,
      breaker: this.breaker,
      ready: this.engineReady,
      intentEngines: this.intentEngines,
      dispatcher: this.dispatcher,
      logger: this.logger,
    })
  }

  /** 廉价本地可用性检查；凭证按调用解析，这里不答。 */
  available(): boolean { return true }

  /** DSH 0.2.2 工具准入：至少一个已启用、未熔断且可用的搜索服务存在。 */
  async ready(): Promise<boolean> {
    const controls = this.resolveControls()
    for (const engine of this.engines) {
      if (!engine.manifest.capabilities.includes('search') || engine.search === undefined) continue
      if ((controls.serviceEnabled?.[engine.manifest.id] ?? true) !== true) continue
      if (controls.searchServices !== undefined && !controls.searchServices.includes(engine.manifest.id)) continue
      if (this.breaker.isBroken(engine.manifest.id)) continue
      if (await this.engineReady?.(engine.manifest.id, 'search') !== false) return true
    }
    return false
  }

  async search(request: WebSearchRequest, signal?: AbortSignal): Promise<WebSearchResult> {
    // 让出微任务，让 DSH 先启动兄弟查询，避免首批 lane 独占共享请求预算。
    await Promise.resolve()
    const controls = resolveRuntimeRequest(this.resolveControls(), 'search', request.query)
    const shared = signal === undefined ? undefined : this.sharedBudget(signal, controls.maxRequests ?? 32)
    return runOperation(controls, 'search', signal, op => this.searchOperation(request, op), shared)
  }

  private sharedBudget(signal: AbortSignal, maxRequests: number): SharedRequestBudget {
    const existing = this.batchBudgets.get(signal)
    if (existing !== undefined) return existing
    const budget = new SharedRequestBudget(maxRequests)
    this.batchBudgets.set(signal, budget)
    return budget
  }

  private async searchOperation(request: WebSearchRequest, op: OpContext): Promise<WebSearchResult> {
    if (op.signal.aborted) throw abortedError(op.signal)
    // ADR-0001 §1：意图在操作入口判定一次，说明先行（先解释路由，再谈选择与派发）。
    const route = routeSearchQuery(request.query)
    op.note(renderNote(route.note))

    // ADR-0001 §8：路由判定后、任何派发与预算消耗前查缓存。
    // 读取/写入判定与 TTL 分档在 cache-policy；命中说明由 output 阶段统一呈现。
    const cache = searchCachePolicy({
      analysis: route,
      maxResults: request.maxResults,
      fingerprint: this.cacheFingerprint?.(),
    })
    if (cache.readable) {
      const cached = this.queryCache.get(cache.key, cache.ttlSeconds)
      if (cached !== undefined) return cachedResult(cached.result, cached.ageSeconds)
    }

    const searchEngines = this.engines.filter(engine => engine.manifest.capabilities.includes('search') && engine.search !== undefined)
    // 日检移到选择之前，本轮就跳过耗尽者。
    const enabled = searchEngines.filter(engine =>
      (op.controls.serviceEnabled?.[engine.manifest.id] ?? true)
      && (op.controls.searchServices === undefined || op.controls.searchServices.includes(engine.manifest.id)))
    await this.quotaSweeper.sweep(enabled, op)
    if (op.signal.aborted) throw abortedError(op.signal)

    const active = searchEngines.filter(engine => !this.breaker.isBroken(engine.manifest.id))
    const skipped = searchEngines.filter(engine => this.breaker.isBroken(engine.manifest.id))
    for (const engine of skipped) this.logger.warn(`[搜索] 服务 ${engine.manifest.id} 已熔断，跳过本次派发`)

    // ADR-0001 §2：垂直 tag 先经能力目录校验（存在性 + 必填参数）；不合法 fail-open 回通用路由并记说明。
    let vertical = route.vertical
    let intent = route.intent
    if (vertical !== undefined && this.verticalCatalog !== undefined) {
      const verdict = await this.verticalVerdict(this.verticalCatalog, vertical, op)
      if (!verdict.exists || verdict.missingRequired.length > 0) {
        op.note(renderNote(verdict.missingRequired.length > 0
          ? { id: 'vertical-missing-params', params: { missing: verdict.missingRequired } }
          : { id: 'vertical-unavailable' }))
        vertical = undefined
        // fail-open 的通用路由按查询语言选：英文查询不落中文源（与降级判据同一入口）。
        intent = route.language === 'chinese' ? 'chinese-web' : 'english-web'
      }
    }

    // ADR-0001 §2：意图映射存在时其顺序优先，searchServices 退为成员资格过滤；
    // 无映射时保持进入顺序，让用户 searchServices 顺序生效。宽度上限作用于最终顺序。
    const intentPriority = this.intentEngines(intent, route.prefer)
    const orderedCandidates = orderCandidates(active, intentPriority, this.engines)
    const selectedRows = await selectSearchEngines(
      orderedCandidates, op, this.engineReady, undefined, true,
      intentPriority.length > 0 ? orderedCandidates.map(engine => engine.manifest.id) : undefined,
    )
    // 日检/凭证探测之后仍可能处于熔断：选择后再过滤一次（ADR-0001 §6）。
    const selected: Engine[] = []
    for (const engine of selectedRows) {
      if (this.breaker.isBroken(engine.manifest.id)) this.logger.warn(`[搜索] 服务 ${engine.manifest.id} 已熔断，跳过本次派发`)
      else selected.push(engine)
    }
    if (op.signal.aborted) throw abortedError(op.signal)

    // ADR-0001 §2 + §7：热点/热榜意图且映射序内有引擎具备 hotTopics 时直接取榜单；
    // 无该能力或映射内引擎均不可用时回落普通 search。
    const hotEngine = hotTopicsEngine(selected, route, this.intentEngines)
    const specialized: 'hot' | 'vertical' | undefined = hotEngine !== undefined ? 'hot' : vertical !== undefined ? 'vertical' : undefined
    const newsFallback = hotEngine === undefined && (route.intent === 'ai-news' || route.intent === 'hot-list')
    const window = new SettlementWindow(op.signal)
    let outcomes: Outcome[]
    if (hotEngine !== undefined) {
      outcomes = await this.dispatcher.dispatchHotTopics(hotEngine, window, op)
    } else {
      // 官方域缺口交给首轮后的质量评估：不足时由 recovery 补派一路，不在首轮并发加 site 查询。
      outcomes = await this.dispatcher.dispatchRound(
        selected.map(engine => ({
          engine,
          query: request.query,
          ...(vertical === undefined ? {} : { vertical }),
          ...(route.wantAnswer === true ? { wantAnswer: true } : {}),
          ...(newsFallback ? { freshness: 'news' as const } : {}),
        })),
        window, route, request.maxResults, op,
        Math.min(this.maxFanoutMs, AUTO_FIRST_LANE_MS),
      )
    }
    let endedEarly = window.endedEarly
    if (endedEarly) op.note(renderNote({ id: 'early-cancel' }))
    if (op.signal.aborted && !op.deadlineReached) throw abortedError(op.signal)

    let rankings = successfulRankings(outcomes, this.engines)
    let relevant = rankings.length === 0 ? [] : relevantCandidates(route, rankings, this.rrfK)
    // ADR-0001 §7：无 URL 的结构化数据序列化在 content 里，同样是「有产出」。
    // 只有 sources 与 content 双空才触发降级/空结果补派。
    let produced = relevant.length > 0 || hasAnswer(outcomes)
    // ADR-0001 §4：垂直/热榜路由无可用结果时按查询语言降级为通用路由重试一次；
    // 429/额度/超时的通道不重试（预算已花，沿用 Issue #20 语义），每操作至多一次。
    if (specialized !== undefined && !produced && this.recovery.allowed(outcomes, op)) {
      const degraded = await this.recovery.degrade(request, outcomes, op, route, specialized)
      if (degraded !== undefined) {
        outcomes = [...outcomes, ...degraded.outcomes]
        endedEarly = endedEarly || degraded.endedEarly
        rankings = successfulRankings(outcomes, this.engines)
        relevant = rankings.length === 0 ? [] : relevantCandidates(route, rankings, this.rrfK)
        produced = relevant.length > 0 || hasAnswer(outcomes)
      }
    }

    if (rankings.length === 0 && !recoverableFirstLane(outcomes)) {
      if (op.deadlineReached) throw new WebError('search deadline exceeded', 'WEB_SEARCH_TIMEOUT')
      throw allEnginesFailedError([...outcomes, ...skipped.map(engine => ({ kind: 'skipped' as const, engineId: engine.manifest.id }))])
    }

    const initialGoverned = governDates(route, relevant, this.now())
    let governedCandidates = initialGoverned.candidates
    let omittedOutOfDate = initialGoverned.omitted
    const evidence = buildSearchEvidence({
      analysis: route,
      candidates: governedCandidates,
      hasAnswer: hasAnswer(outcomes),
      sourceLanes: sourceLaneCount(outcomes),
      now: this.now(),
    })
    const sufficiency = hotEngine !== undefined && produced
      ? { sufficient: true }
      : assessSearchSufficiency({
      analysis: route,
      evidence,
      maxResults: request.maxResults,
    })
    if (!sufficiency.sufficient) {
      const escalation = await this.recovery.escalate(
        request,
        outcomes,
        op,
        route,
        sufficiency.reason ?? 'empty',
      )
      if (escalation !== undefined) {
        outcomes = [...outcomes, ...escalation.outcomes]
        endedEarly = endedEarly || escalation.endedEarly
        rankings = successfulRankings(outcomes, this.engines)
        relevant = relevantCandidates(route, rankings, this.rrfK)
        const escalatedGoverned = governDates(route, relevant, this.now())
        governedCandidates = escalatedGoverned.candidates
        omittedOutOfDate = escalatedGoverned.omitted
        produced = relevant.length > 0 || hasAnswer(outcomes)
      }
    }

    if (rankings.length === 0) {
      if (op.deadlineReached) throw new WebError('search deadline exceeded', 'WEB_SEARCH_TIMEOUT')
      throw allEnginesFailedError([...outcomes, ...skipped.map(engine => ({ kind: 'skipped' as const, engineId: engine.manifest.id }))])
    }

    if (!produced) {
      // 两种零结果形态到此为止：所有通道空返回，或候选存在但全被相关性过滤。
      // 输出阶段统一组装逐路状态说明、答案与 truncated。
      const output = buildEmptyOutput({
        outcomes,
        notes: op.notes,
        requestCount: op.requestCount,
        endedEarly,
        deadlineReached: op.deadlineReached,
      })
      this.logger.info(`[搜索] ${output.content}`)
      return { sources: [], content: output.content, truncated: output.truncated }
    }

    // 重排：融合→过滤后的候选经 SiliconFlow 重排序；fail-open 不阻塞。
    let ordered: readonly FusedCandidate[] = governedCandidates
    const rerankKey = this.rerank !== undefined ? await this.rerank.resolve(op) : undefined
    if (rerankKey !== undefined) {
      const rerankContext: EngineContext = {
        signal: op.signal,
        deadline: this.now() + 5_000,
        apiKey: rerankKey,
        endpoint: RERANK_SERVICE.endpoint,
        countRequest: () => op.countRequest(),
        ...(this.rerank?.fetcher !== undefined ? { fetcher: this.rerank.fetcher } : {}),
      } as EngineContext
      const reranked = await rerankCandidates(rerankContext, request.query, governedCandidates)
      ordered = reranked.ordered
      if (reranked.reranked) op.note(renderNote({ id: 'rerank-applied' }))
      else if (reranked.note !== undefined) op.note(reranked.note)
    }
    ordered = governDates(route, ordered, this.now()).candidates
    if (omittedOutOfDate > 0) op.note(renderNote({ id: 'date-filtered', params: { omitted: omittedOutOfDate } }))

    // ADR-0001 §7/§9/§10/§11：输出阶段一次完成多样性、预算、归因、答案合并与 truncated 汇总。
    const output = buildSearchOutput({
      analysis: route,
      candidates: ordered,
      maxResults: request.maxResults,
      maxOutputChars: op.controls.maxOutputChars,
      outcomes,
      endedEarly,
      deadlineReached: op.deadlineReached,
      notes: op.notes,
      requestCount: op.requestCount,
    })
    this.logger.info(`[搜索] ${renderLogSummary(output.notes, op.requestCount)}`)
    const finalResult: WebSearchResult = {
      ...(output.content === undefined ? {} : { content: output.content }),
      sources: [...output.sources],
      truncated: output.truncated,
    }
    // ADR-0001 §8：只缓存最终成功结果（含降级重试后的形态）；空结果不写，
    // 避免把一次偶发空返回固定一个 TTL。命中说明由读取分支加在 content 前。
    if (cache.cacheable && finalResult.sources.length > 0) this.queryCache.set(cache.key, finalResult, cache.ttlSeconds)
    return finalResult
  }

  /** 垂直 tag 校验：目录拒绝或抛错都按不可用处理（fail-open 回通用路由）；请求预算由目录在发网络请求前消费。 */
  private async verticalVerdict(catalog: VerticalCatalog, request: VerticalRequest, op: OpContext): Promise<{ exists: boolean; missingRequired: readonly string[] }> {
    try {
      return await catalog.validate(request.tag, request.params, {
        signal: op.signal,
        countRequest: () => op.countRequest(),
      })
    } catch (error) {
      this.logger.warn(`[搜索] 垂直频道校验失败，按不可用处理：${describeError(error)}`)
      return { exists: false, missingRequired: [] }
    }
  }

}

/** 有界、无凭据的异常描述。 */
function describeError(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error)
  return message.length <= 200 ? message : `${message.slice(0, 200)}…`
}

/** 操作自身取消 → seam 的取消码。 */
function abortedError(signal: AbortSignal): WebError {
  return new WebError('Aggregated web search aborted', 'WEB_ABORTED', { cause: signal.reason })
}

/** 有限正数覆盖或默认。 */
function positive(value: number | undefined, fallback: number): number {
  return value !== undefined && Number.isFinite(value) && value > 0 ? value : fallback
}

/** 返回过至少一条来源的成功路数量；content-only 答案不计入来源路。 */
function sourceLaneCount(outcomes: readonly Outcome[]): number {
  return new Set(outcomes
    .filter(outcome => outcome.kind === 'ok' && outcome.result.sources.length > 0)
    .map(outcome => outcome.engineId)).size
}
