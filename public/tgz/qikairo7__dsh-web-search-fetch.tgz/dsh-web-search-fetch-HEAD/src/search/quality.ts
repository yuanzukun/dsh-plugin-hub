// 搜索质量规则——v0.2 src/search-quality.ts 移植（spec §5 保留：官方文档意图、主题词匹配、内容变体键）。
// v0.3 改动（AD2，修 v0.2 批判者指出的类型循环）：不再从聚合器 import FusedCandidate，
// 改用结构化最小形状 CandidateText；fuse.ts 的 FusedCandidate 结构满足它，依赖单向化。

/** 质量规则需要的候选最小形状；fuse.FusedCandidate 结构兼容。 */
export interface CandidateText {
  readonly url: string
  readonly title?: string
  readonly snippet?: string
}

/** 显式技术文档意图映射到项目官方文档站；不触发额外搜索的权威域另见 authorityHosts。 */
export function officialHosts(query: string): string[] {
  const explicit = [...query.matchAll(/\bsite:([a-z0-9.-]+)(?:\/[^\s]*)?/gi)].map(match => match[1]!.toLowerCase());
  if (explicit.length) return explicit;
  if (!/官方|文档|规范|official|documentation|\bdocs?\b|specification/i.test(query)) return [];
  const projects: [RegExp, string][] = [
    [/\bpython\b|\basyncio\b/i, 'docs.python.org'],
    [/\btypescript\b/i, 'www.typescriptlang.org'],
    [/\bnode(?:\.js|js)\b/i, 'nodejs.org'],
    [/\bjavascript\b|\bpromise\.(?:all|race|any|allSettled)\b/i, 'developer.mozilla.org'],
    [/\breact\b/i, 'react.dev'], [/\brust\b/i, 'doc.rust-lang.org'],
    [/\bgolang\b|\bgo language\b/i, 'go.dev'],
  ];
  return projects.filter(([pattern]) => pattern.test(query)).map(([, host]) => host).slice(0, 2);
}

/** 中文政府与政策类查询的排序权威域；只影响排序与多样性，不追加补充检索。 */
export function authorityHosts(query: string): string[] {
  return /政府|政策|官方指南/.test(query) ? ['gov.cn'] : []
}

function hostMatches(url: string, hosts: readonly string[], includeSubdomains: boolean): boolean {
  try {
    const host = new URL(url).hostname.replace(/^www\./, '');
    return hosts.some(expected => {
      const root = expected.replace(/^www\./, '');
      return host === root || (includeSubdomains && host.endsWith(`.${root}`));
    });
  } catch { return false; }
}

export function isOfficial(url: string, hosts: readonly string[]): boolean {
  return hostMatches(url, hosts, false);
}

function matchesRankingHost(
  url: string,
  officialHostList: readonly string[],
  authorityHostList: readonly string[],
): boolean {
  return hostMatches(url, officialHostList, false) || hostMatches(url, authorityHostList, true);
}

export function isRankingHost(url: string, query: string): boolean {
  return matchesRankingHost(url, officialHosts(query), authorityHosts(query));
}

/** 自身不承载主题的词；排除出一切词检验。 */
const GENERIC_TERMS: ReadonlySet<string> = new Set([
  'official', 'documentation', 'document', 'docs', 'site', 'https', 'http', 'www', 'org', 'com', 'the', 'and', 'for', 'with', 'versus',
])

/**
 * 时效限定词：只说「何时」、不承载主题的整词。
 * 中文查询常以它开头（「最近的 AI 芯片新闻」），真实候选池把这个想法写成日期或「最新」，
 * 而不是重复查询措辞；把这种词留在硬过滤里检验的是标点，不是相关性。
 */
const RECENCY_TERMS: readonly RegExp[] = [
  /^(?:最近|最新|近期|近日|目前|当前|今天|今日|今年|明年|去年|本周|上周|本月|上月|实时|即时|现在)(?:的)?$/,
]

/** 查询的可用词，按查询顺序（英文词与 CJK 连续段）。 */
export function queryTerms(query: string): string[] {
  const terms = query.toLowerCase().match(/[a-z][a-z0-9_+-]{2,}|[\u3400-\u9fff]{2,}/g) ?? [];
  return terms.filter(term => !GENERIC_TERMS.has(term));
}

/**
 * 一个查询词是否命中候选文本。
 * 英文词按字面出现。中文连续段不是词：「芯片新闻」是「芯片」+「新闻」，页面写成
 * 「芯片…新闻」「AI芯片最新资讯」；要求整段字面曾让这类池全被判不相关（P1-4）。
 * 三字及以上连续段在至少三分之二字符出现时也算命中；两字段保持字面（通常是一个词）。
 */
export function termMatches(term: string, text: string): boolean {
  if (text.includes(term)) return true;
  const characters = [...new Set([...term].filter(character => /[\u3400-\u9fff]/.test(character)))];
  if (characters.length < 3) return false;
  return characters.filter(character => text.includes(character)).length * 3 >= characters.length * 2;
}

/** 承载主题的词：去掉时效限定词。 */
export function topicTerms(terms: readonly string[]): string[] {
  return terms.filter(term => !RECENCY_TERMS.some(pattern => pattern.test(term)));
}

/** 主题匹配防止无关的官方 API 页面仅凭主机名获胜。 */
export function topicMatches(query: string, candidate: CandidateText): boolean {
  const identifiers = query.match(/\b[a-z_]\w*(?:\.\w+)+\b/gi)?.filter(term => !/^(?:node\.js|docs?\.|www\.)/i.test(term)) ?? [];
  const text = `${candidate.title ?? ''} ${candidate.snippet ?? ''} ${candidate.url}`.toLowerCase();
  if (identifiers.length) {
    const subject = `${candidate.title ?? ''} ${candidate.url}`.toLowerCase().replace(/[/.()]+/g, ' ');
    return identifiers.some(term => new RegExp(`\\b${term.toLowerCase().replace(/\./g, ' ')}\\b`).test(subject));
  }
  const topics = topicTerms(queryTerms(query));
  return !topics.length || topics.filter(term => termMatches(term, text)).length >= Math.min(2, topics.length);
}

/** 官方域优先重排：融合前后都可用，优先级内再按语言匹配细分。 */
export function preferOfficial<T extends CandidateText>(query: string, candidates: readonly T[]): T[] {
  const officialHostList = officialHosts(query);
  const authorityHostList = authorityHosts(query);
  if (!officialHostList.length && !authorityHostList.length) return [...candidates];
  const priority = (candidate: T): number => {
    if (!matchesRankingHost(candidate.url, officialHostList, authorityHostList) || !topicMatches(query, candidate)) return 0;
    const path = new URL(candidate.url).pathname;
    if (path === '/' && !/官网|网站|website|homepage/i.test(query)) return 0;
    const chinese = /[\u3400-\u9fff]/.test(query);
    const foreign = /^\/(?:es|fr|de|id|ja|ko|pt-br|ru)(?:\/|$)/i.test(path);
    if (chinese && /^\/(?:zh-CN|zh-cn|zh|zh-TW)(?:\/|$)/i.test(path)) return 3;
    return foreign ? 1 : 2;
  };
  return [...candidates].sort((a, b) => priority(b) - priority(a));
}

/** 标题作为去重证据：小写、空白折叠、去掉尾部站名后缀（「… | 逐水寻源」）。 */
function variantTitle(title: string): string {
  const normalized = title.trim().toLowerCase().replace(/\s+/g, ' ');
  const [head] = normalized.split(/\s*[|｜]\s*/);
  return (head ?? normalized).replace(/[\s\-–—_]+$/, '').trim();
}

/**
 * 一条来源的去重键。
 * 同一路径的斜杠变体按**标题**证据合并：页面名说明两条是同一篇文章，各路合法地返回它的
 * 不同摘录——要求摘录一致曾把真重复挡在合并外（P2-4）。不同非根路径保持相异（URL 是键的
 * 一部分）；标题不同的两页即使只差尾斜杠也保持相异。
 */
export function contentVariantKey(url: string, title?: string): string {
  const key = title === undefined ? '' : variantTitle(title);
  if (key.length === 0) return url;
  try {
    const parsed = new URL(url);
    parsed.pathname = parsed.pathname.replace(/\/$/, '') || '/';
    return `${parsed.href}\n${key}`;
  } catch { return url; }
}
