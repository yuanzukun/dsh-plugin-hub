// 装配层与包入口。
// 职责：cordis 插件定义、registry 派生的 Config、buildContext（凭证每操作异步解析
// + 占位符密钥保护 + 端点覆盖）、buildEngines 装配、两个 aggregated provider 注册、
// AIHOT 专用 API 读取器注入、静态 HTTP 提取器包装、熔断事件接线。
// 配置面保持单一事实源，从引擎清单派生。

import type { Context } from '@deepseek-ai/cordis'
import { Remote, TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol'
import type { Dict, Volatile } from '@deepseek-ai/cosmokit'
import { credentialRef } from '@deepseek-ai/dsh-credentials'
import { DEFAULT_USER_AGENT, HttpFetchProvider } from '@deepseek-ai/dsh-web-fetch-http'
import type { HttpFetchLimits } from '@deepseek-ai/dsh-web-fetch-http'
import z from '@deepseek-ai/schemastery'

import { createAihotApiReader, createAihotEngine } from './engines/aihot.js'
import type { Engine, EngineContext, EngineManifest } from './engines/contract.js'
import { AnysearchDomainCatalog } from './engines/anysearch-domains.js'
import { createAnysearchEngine } from './engines/anysearch.js'
import { createFirecrawlEngine } from './engines/firecrawl.js'
import { createTavilyEngine } from './engines/tavily.js'
import { createZhihuEngine } from './engines/zhihu.js'
import { buildEngines, ENGINE_MANIFESTS } from './engines/registry.js'
import { AggregatedSearchProvider, type BuildEngineContext } from './search/aggregate.js'
import type { LaneOutcomeKind } from './support/lane-settlement.js'
import type { SearchIntent } from './search/router.js'
import { intentEnginePriority } from './engine-priority.js'
import { OpContext, type RuntimeControls } from './support/budget.js'
import { CircuitBreaker, formatBreakerEvent } from './support/breaker.js'
import { LOCAL_QUOTA_FAILURE_THRESHOLD, QuotaLedger } from './support/quota-ledger.js'
import {
  DEFAULT_QUOTA_PROBE_TIMEOUT_MS,
  QuotaCredentialError,
  QuotaPanelService,
  type PanelEngineManifest,
  type PanelPayload,
  type QuotaProbe,
} from './support/quota-panel.js'
import { QuotaSnapshotStore } from './support/quota-snapshots.js'
import { AggregatedFetchProvider, type StaticHttpFetcher } from './fetch/provider.js'
import { DEFAULT_MAX_OUTPUT_CHARS } from './fetch/document/organize.js'

/** 服务开关表（与 schemastery z.dict 同源的 Dict 形状；导出以使命令发射可命名该类型）。 */
export type ServiceSwitches = Dict<boolean>

/** Cordis 插件名；保持稳定以避免已保存的宿主配置失效。 */
export const name = 'web-search-fetch'

/** 能力接缝与凭证服务（凭证每操作解析，轮换即生效）。 */
export const inject = ['web', 'credentials']

// ---------------------------------------------------------------------------
// Config：默认值全部从 registry 派生（单一事实源，禁止第二份清单）
// ---------------------------------------------------------------------------

/** 参与搜索的默认服务 = registry 顺序里的 search 能力引擎。 */
export const DEFAULT_SEARCH_SERVICES: readonly string[] = ENGINE_MANIFESTS
  .filter(manifest => manifest.capabilities.includes('search'))
  .map(manifest => manifest.id)

/** 参与提取的默认服务 = registry 顺序里的 fetch 能力引擎。 */
export const DEFAULT_FETCH_SERVICES: readonly string[] = ENGINE_MANIFESTS
  .filter(manifest => manifest.capabilities.includes('fetch'))
  .map(manifest => manifest.id)

export interface Config {
  /** 运行时控制（设置页 volatile 快照）。 */
  controls?: Partial<RuntimeControls>
  /** SiliconFlow 重排配置。 */
  rerank?: {
    enabled?: boolean
    apiKeyEnv?: string
  }
  /** 各引擎凭证引用（credential-ref）；未配置的 keyless-fallback 引擎走匿名额度。 */
  anysearchApiKeyEnv?: string
  anysearchBaseURL?: string
  /** AnySearch 搜索区域：'cn' 国内 / 'intl' 国际；空串与未设置等价，均不发送 zone 字段。 */
  anysearchZone?: 'cn' | 'intl' | ''
  tavilyApiKeyEnv?: string
  firecrawlApiKeyEnv?: string
  firecrawlBaseURL?: string
  zhihuApiKeyEnv?: string
}

/** 解析后的实时配置引用；每次操作读取一次 `config.get()` 快照。 */
export type ConfigRef = Volatile<Config>

/** 同一操作内共享的配置快照：跨 lane 的保存不会让一次操作混用新旧凭证/端点。 */
const CONFIG_SNAPSHOTS = new WeakMap<OpContext, Config>()

function configSnapshot(config: ConfigRef, op: OpContext): Config {
  let snapshot = CONFIG_SNAPSHOTS.get(op)
  if (snapshot === undefined) {
    snapshot = config.get()
    CONFIG_SNAPSHOTS.set(op, snapshot)
  }
  return snapshot
}

export const Config = z.object({
  controls: z.object({
    serviceEnabled: z.dict(z.boolean()).default({}).description('服务总开关；关闭后不派发该服务。'),
    searchServices: z.array(z.string()).default([...DEFAULT_SEARCH_SERVICES]).description('搜索服务 ID 与调用优先级；有意图映射时该顺序仅作成员资格过滤，不决定派发优先级。'),
    fetchServices: z.array(z.string()).default([...DEFAULT_FETCH_SERVICES]).description('提取服务 ID 与调用优先级；HTTP 静态路径不受此列表控制。'),
    maxFetchServices: z.natural().min(1).max(DEFAULT_FETCH_SERVICES.length).default(DEFAULT_FETCH_SERVICES.length)
      .description('每个 URL 最多调用的提取服务数。'),
    maxRequests: z.natural().min(1).max(256).default(32).description('每次操作的插件 HTTP 请求上限，含额度查询与重试。'),
    searchDeadlineMs: z.natural().min(1).max(3_600_000).default(15_000).description('搜索操作总限时（毫秒）。'),
    fetchDeadlineMs: z.natural().min(1).max(3_600_000).default(50_000).description('提取操作总限时（毫秒）。'),
    maxOutputChars: z.natural().min(1000).max(1_000_000).default(DEFAULT_MAX_OUTPUT_CHARS)
      .description('单页整理与搜索来源的输出上限：整理按完整内容块保留正文，搜索按 title+snippet 从尾部裁剪来源列表；均含来源与说明。'),
  }).description('调用控制。'),
  rerank: z.object({
    enabled: z.boolean().default(true).description('SiliconFlow 重排开关；未配置密钥时自动不启用。'),
    apiKeyEnv: z.string().role('credential-ref').default('SILICONFLOW_API_KEY').description('SiliconFlow 密钥引用。'),
  }).description('重排服务。'),
  // 设置页可实时编辑：整个 Config 根对象标 volatile。上游 dsh-settings 只投影/写入 volatile
  // 路径，loader 对 volatile-only 修改保留实例并提交新快照。消费端必须每次操作 config.get()，
  // 不得把引用当普通 JSON——引用经 JSON.stringify 会得到 {}，这是设计行为，不是值丢失。
  // 回归见 test/config-resolution.test.ts 与 test/live-config.test.ts。
  anysearchApiKeyEnv: z.string().role('credential-ref').default('ANYSEARCH_API_KEY'),
  anysearchBaseURL: z.string(),
  // 区域选择不设默认值；缺省时适配层不发送 zone 字段。
  // 空串与未设置等价（设置页「默认」项写回空串），空串合法、不产生 issue。
  anysearchZone: z.union(['cn', 'intl', '']),
  tavilyApiKeyEnv: z.string().role('credential-ref').default('TAVILY_API_KEY'),
  firecrawlApiKeyEnv: z.string().role('credential-ref').default('FIRECRAWL_API_KEY'),
  firecrawlBaseURL: z.string(),
  zhihuApiKeyEnv: z.string().role('credential-ref').default('ZHIHU_API_KEY'),
}).volatile()

// ---------------------------------------------------------------------------
// 引擎上下文构造（凭证、端点、占位符保护）
// ---------------------------------------------------------------------------

/** 占位符密钥保护集（anysearch-dsh 官方插件同款思路）：命中的字面量不当真钥发送。 */
const API_KEY_PLACEHOLDERS = new Set([
  'ANYSEARCH_API_KEY', 'TAVILY_API_KEY', 'FIRECRAWL_API_KEY', 'ZHIHU_API_KEY', 'SILICONFLOW_API_KEY',
  'as_sk_your_key', 'tvly-YOUR_API_KEY', 'fc-your-key',
])

interface EngineCredentials {
  readonly envName: string
  readonly baseURL?: string
}

/** 端点覆盖空串与未设置等价（文档承诺留空使用官方端点）。 */
function normalizeBaseURL(value: string | undefined): string | undefined {
  if (value === undefined) return undefined
  const trimmed = value.trim()
  return trimmed.length === 0 ? undefined : trimmed
}

/** 各引擎的凭证引用与端点覆盖；引擎 id 保持稳定。 */
function engineCredentials(value: Config): Readonly<Record<string, EngineCredentials>> {
  return {
    anysearch: { envName: value.anysearchApiKeyEnv ?? 'ANYSEARCH_API_KEY', baseURL: normalizeBaseURL(value.anysearchBaseURL) },
    tavily: { envName: value.tavilyApiKeyEnv ?? 'TAVILY_API_KEY' },
    firecrawl: { envName: value.firecrawlApiKeyEnv ?? 'FIRECRAWL_API_KEY', baseURL: normalizeBaseURL(value.firecrawlBaseURL) },
    zhihu: { envName: value.zhihuApiKeyEnv ?? 'ZHIHU_API_KEY' },
    aihot: { envName: '' },
  }
}

function usableKey(value: string | undefined): string | undefined {
  if (value === undefined) return undefined
  const trimmed = value.trim()
  if (trimmed.length === 0 || API_KEY_PLACEHOLDERS.has(trimmed)) return undefined
  return trimmed
}

/** 构造引擎执行上下文：凭证每操作解析，端点按 lane.face 从 manifest 选择。 */
export function makeBuildContext(ctx: Context, config: ConfigRef) {
  // face 取三种用途的超集：本函数同时赋给搜索 provider（search|quota）与提取 provider
  // （fetch|quota）——宽参数签名可赋给两者的窄签名（strictFunctionTypes 下的逆变兼容）。
  return async (
    manifest: EngineManifest,
    op: OpContext,
    lane: { signal: AbortSignal; deadline: number; face: 'search' | 'fetch' | 'quota' },
  ): Promise<EngineContext> => {
    // 每次操作读一次配置快照：凭证引用与端点覆盖轮换后下一次操作生效；
    // 同一操作内的并发 lane 共享该快照。
    const entry = engineCredentials(configSnapshot(config, op))[manifest.id]
    // 凭证每操作异步解析（轮换即生效）+ 占位符保护（anysearch-dsh 官方同款思路）。
    let apiKey: string | undefined
    if (entry !== undefined && entry.envName.length > 0) {
      apiKey = usableKey((await ctx.credentials.resolve(credentialRef(entry.envName)))?.value)
    }
    const endpoint = entry?.baseURL
      ?? (lane.face === 'quota' ? manifest.endpoints.quota : lane.face === 'fetch' ? manifest.endpoints.fetch : manifest.endpoints.search)
      ?? manifest.endpoints.search
      ?? 'https://invalid.local'
    return {
      signal: lane.signal,
      deadline: lane.deadline,
      apiKey,
      endpoint,
      countRequest: () => op.countRequest(),
    }
  }
}

// ---------------------------------------------------------------------------
// 额度面板装配：周期映射与探测闭包属于装配层（引擎知识合法区）
// ---------------------------------------------------------------------------

export interface QuotaPanelRuntimeOptions {
  readonly engines: readonly Engine[]
  readonly ledger: QuotaLedger
  readonly breaker: CircuitBreaker
  readonly buildContext: BuildEngineContext
  readonly resolveControls: () => RuntimeControls
  readonly now?: () => number
}

export interface QuotaPanelRuntime {
  readonly service: QuotaPanelService
  readonly store: QuotaSnapshotStore
  readonly manifests: readonly PanelEngineManifest[]
}

/**
 * 组装面板核心：探测闭包 = buildContext（凭证/端点/预算）+ engine.quota。
 * 凭证解析异常改抛 QuotaCredentialError（面板给固定原因、零请求、不连坐）；
 * 其余探测异常由面板归一为 unavailable 原因。
 */
export function createQuotaPanelRuntime(options: QuotaPanelRuntimeOptions): QuotaPanelRuntime {
  const now = options.now ?? Date.now
  const store = new QuotaSnapshotStore({ now })
  const manifests: readonly PanelEngineManifest[] = ENGINE_MANIFESTS.map(manifest => ({
    ...manifest,
    period: manifest.quotaPeriod ?? 'none',
  }))
  const probe: QuotaProbe = async (manifest, signal) => {
    const engine = options.engines.find(candidate => candidate.manifest.id === manifest.id)
    if (engine?.quota === undefined) throw new Error(`引擎 ${manifest.id} 没有额度端点`)
    const controls = options.resolveControls()
    const op = new OpContext(controls, signal, undefined, controls.maxRequests ?? 32)
    try {
      let context: EngineContext
      try {
        context = await options.buildContext(manifest, op, {
          signal,
          deadline: now() + DEFAULT_QUOTA_PROBE_TIMEOUT_MS,
          face: 'quota',
        })
      } catch {
        throw new QuotaCredentialError()
      }
      return await engine.quota(context)
    } finally {
      op.close()
    }
  }
  const service = new QuotaPanelService({
    engines: options.engines,
    manifests,
    ledger: options.ledger,
    store,
    breaker: options.breaker,
    resolveEnabled: () => options.resolveControls().serviceEnabled ?? {},
    probe,
    now,
  })
  return { service, store, manifests }
}

/**
 * Typert 宿主薄包装（T0 判定 typert-ok）：面板状态经 Gateway 暴露给客户端面（T7）。
 * 方法参数为空，Gateway 的 SRC 回退按 JSON 空参数调用。
 *
 * 注：标准装饰器语法在 Vitest 的 rolldown 转译链下不可用（tsc 可编译，vitest 报
 * SyntaxError）。这里直接调用协议导出的 Remote 装饰器并在构造时执行初始器，运行时
 * 行为与 @Remote 完全一致（标记写入版本化原型描述符）。
 */
const quotaPanelRemoteInitializers: Array<(this: QuotaPanelRemote) => void> = []

export class QuotaPanelRemote extends TypertRemoteService {
  private readonly panel: QuotaPanelService

  constructor(ctx: Context, panel: QuotaPanelService) {
    super(ctx, 'quotaPanel')
    this.panel = panel
    for (const initializer of quotaPanelRemoteInitializers) initializer.call(this)
  }

  get(): PanelPayload {
    return this.panel.get()
  }

  refresh(): Promise<PanelPayload> {
    return this.panel.refresh()
  }
}

for (const method of ['get', 'refresh'] as const) {
  Remote(QuotaPanelRemote.prototype[method] as never, {
    kind: 'method',
    name: method,
    static: false,
    private: false,
    addInitializer(initializer: (this: QuotaPanelRemote) => void) {
      quotaPanelRemoteInitializers.push(initializer)
    },
  } as never)
}

// ---------------------------------------------------------------------------
// 静态 HTTP 提取器（组合包装 dsh-web-fetch-http）
// ---------------------------------------------------------------------------

const DEFAULT_HTTP_FETCH_LIMITS: HttpFetchLimits = {
  maxResponseBytes: 5_000_000,
  maxBodyChars: 100_000,
  timeoutMs: 30_000,
  maxRedirects: 5,
  userAgent: DEFAULT_USER_AGENT,
}

function makeStaticFetcher(): StaticHttpFetcher {
  const http = new HttpFetchProvider(DEFAULT_HTTP_FETCH_LIMITS)
  return {
    available: () => http.available(),
    fetch: (request, signal) => http.fetch(request, signal),
  }
}

export { intentEnginePriority }

/** 影响搜索结果的配置指纹（不含凭证值）；设置变更后查询缓存键随之变化。 */
export function searchCacheFingerprint(value: Config): string {
  return JSON.stringify({
    controls: resolveControlsFrom(value, {}),
    rerank: value.rerank,
    anysearchApiKeyEnv: value.anysearchApiKeyEnv,
    anysearchBaseURL: value.anysearchBaseURL,
    anysearchZone: value.anysearchZone,
    tavilyApiKeyEnv: value.tavilyApiKeyEnv,
    firecrawlApiKeyEnv: value.firecrawlApiKeyEnv,
    firecrawlBaseURL: value.firecrawlBaseURL,
    zhihuApiKeyEnv: value.zhihuApiKeyEnv,
  })
}

/** 运行时控制快照：用户配置与 registry 默认开关合并（纯函数，供装配与离线测试）。 */
export function resolveControlsFrom(
  value: Config,
  defaultEnabled: Readonly<Record<string, boolean>>,
): RuntimeControls {
  const controls = value.controls ?? {}
  return {
    serviceEnabled: controls.serviceEnabled === undefined
      ? defaultEnabled
      : { ...defaultEnabled, ...controls.serviceEnabled },
    searchServices: controls.searchServices,
    fetchServices: controls.fetchServices,
    maxFetchServices: controls.maxFetchServices,
    maxRequests: controls.maxRequests,
    searchDeadlineMs: controls.searchDeadlineMs,
    fetchDeadlineMs: controls.fetchDeadlineMs,
    maxOutputChars: controls.maxOutputChars,
  } as RuntimeControls
}

/** 本次搜索的重排密钥：开关与密钥引用来自同一次配置快照。 */
export async function resolveRerankKey(
  ctx: Context,
  config: ConfigRef,
  op?: OpContext,
): Promise<string | undefined> {
  const rerank = (op === undefined ? config.get() : configSnapshot(config, op)).rerank
  if (rerank?.enabled === false) return undefined
  return usableKey((await ctx.credentials.resolve(credentialRef(rerank?.apiKeyEnv ?? 'SILICONFLOW_API_KEY')))?.value)
}

// ---------------------------------------------------------------------------
// apply（切换时由本文件的 apply 生效；当前草稿不被装载）
// ---------------------------------------------------------------------------

export function apply(ctx: Context, config: ConfigRef): void {
  const breaker = new CircuitBreaker({
    onEvent: event => (event.type === 'open' ? ctx.logger.warn : ctx.logger.info)(formatBreakerEvent(event)),
  })
  const buildContext = makeBuildContext(ctx, config)
  // 本地额度账本（估算口径）与 AnySearch 垂直能力目录（发现结果内部缓存 TTL）。
  const ledger = new QuotaLedger()
  // 目录校验走搜索操作预算并要求短超时：首次垂直查询的发现请求不得拖垮操作 deadline。
  // baseUrl 与 zone 都用实时 getter：设置页保存后下一次请求生效，不重挂插件。
  const anysearchCatalog = new AnysearchDomainCatalog({ baseUrl: () => config.get().anysearchBaseURL, timeoutMs: 5_000 })
  const engines = buildEngines({
    anysearch: createAnysearchEngine({
      resolveZone: () => {
        const zone = config.get().anysearchZone
        return zone === 'cn' || zone === 'intl' ? zone : undefined
      },
    }),
    tavily: createTavilyEngine(),
    firecrawl: createFirecrawlEngine(),
    zhihu: createZhihuEngine(),
    aihot: createAihotEngine(),
  })
  // 服务开关默认值从 registry 派生：manifest 的 enabledByDefault
  // 是缺省态，用户显式设置永远覆盖（含显式关闭默认开的服务）。http 无 manifest，恒默认开。
  const defaultEnabled: Record<string, boolean> = { http: true }
  for (const manifest of ENGINE_MANIFESTS) defaultEnabled[manifest.id] = manifest.enabledByDefault ?? false
  const resolveControls = (): RuntimeControls => resolveControlsFrom(config.get(), defaultEnabled)
  // 额度面板核心：日检上报写同一快照仓；手动刷新与日检共享两态语义。
  const quotaPanel = createQuotaPanelRuntime({ engines, ledger, breaker, buildContext, resolveControls })
  // 凭证就绪探测（selectServices 的 ready 入参）：需要 key 的能力面无有效凭证时
  // 不进入派发（避免必然鉴权失败的路白花预算）。
  const ready = async (id: string, face: 'search' | 'fetch'): Promise<boolean> => {
    // ADR-0001 §6：本地额度账本达到估算阈值后，当日不再派发该源（估算 ≠ 上游余额）。
    if (ledger.locallyExhausted(id, LOCAL_QUOTA_FAILURE_THRESHOLD)) return false
    const manifest = ENGINE_MANIFESTS.find(entry => entry.id === id)
    if (manifest === undefined || manifest.auth === 'anonymous') return true
    // 免密钥能力面按面放行：keylessCapabilities 缺省表示全部能力；Firecrawl 只有 fetch 面免钥，
    // 其 search 面仍需 key（无 key 时不派发，避免每查询白占一路并刷鉴权失败噪声）。
    const keylessFace = manifest.auth === 'keyless-fallback'
      && (manifest.keylessCapabilities === undefined || manifest.keylessCapabilities.includes(face))
    if (keylessFace) return true
    const entry = engineCredentials(config.get())[id]
    if (entry === undefined || entry.envName.length === 0) return true
    return usableKey((await ctx.credentials.resolve(credentialRef(entry.envName)))?.value) !== undefined
  }

  // 额度账本写入钩子：搜索与提取两面的单路结局都入账（同一引擎额度共享），本地日滚动在账本内处理。
  const recordLaneOutcome = (engineId: string, kind: LaneOutcomeKind): void => {
    switch (kind) {
      case 'success': ledger.recordSuccess(engineId); break
      case 'rate-limited': ledger.recordRateLimited(engineId); break
      case 'quota': ledger.recordQuotaFailure(engineId); break
    }
  }
  ctx.web.registerSearchProvider(new AggregatedSearchProvider({
    resolveControls,
    cacheFingerprint: () => searchCacheFingerprint(config.get()),
    engines,
    breaker,
    buildContext,
    ready,
    intentEngines: intentEnginePriority,
    verticalCatalog: {
      validate: (tag, params, budget) => anysearchCatalog.validate(tag, params, budget),
    },
    // 额度账本写入钩子：编排器按单路结局上报。
    onLaneOutcome: recordLaneOutcome,
    // 日检正常 resolve 的官方快照写仓（含 available:false）；抛错路径不上报。
    onQuotaReport: (engineId, report) => quotaPanel.store.record(engineId, report),
    logger: pluginLogger(ctx),
    rerank: {
      resolve: op => resolveRerankKey(ctx, config, op),
    },
  }))

  ctx.web.registerFetchProvider(new AggregatedFetchProvider({
    resolveControls,
    engines,
    buildContext,
    httpFetcher: makeStaticFetcher(),
    apiReaders: [createAihotApiReader()],
    ready,
    breaker,
    onLaneOutcome: recordLaneOutcome,
    logger: fetchLogger(ctx),
  }))

  // 宿主侧额度面板远端。
  new QuotaPanelRemote(ctx, quotaPanel.service)
}

function pluginLogger(ctx: Context) {
  return {
    info: (message: string) => ctx.logger.info(message),
    warn: (message: string) => ctx.logger.warn(message),
    error: (message: string) => ctx.logger.error(message),
  }
}

function fetchLogger(ctx: Context) {
  return {
    info: (message: string) => ctx.logger.info(message),
    warn: (message: string) => ctx.logger.warn(message),
    error: (message: string) => ctx.logger.error(message),
  }
}
