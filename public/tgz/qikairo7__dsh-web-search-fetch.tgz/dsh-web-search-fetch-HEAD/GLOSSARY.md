# 术语表

本表描述当前交付（v0.4.5）的五引擎聚合实现：AnySearch AI、Tavily、Firecrawl、知乎、AIHOT，以及 SiliconFlow 重排。定义以当前代码为准；代码落点中的行号是编写时的参考，以当前工作树为准。

## 宿主接缝与 provider

**聚合 provider（aggregated）**：以 ID `aggregated` 注册到 DSH `ctx.web` 的搜索与提取实现。搜索面一次调用完成意图路由、查询缓存、额度日检与熔断过滤、垂直目录校验、服务选择、官方域补充、并发派发、同源去重与 RRF 融合、相关性过滤、有界降级与空结果补派、重排、官方优先与截断；提取面依次执行地址守卫、AIHOT 专用 API 判定、静态/动态分流、两段式或单通道提取、多路正文整理。搜索与提取是两个独立注册，共用同一个 ID。代码落点：`src/search/aggregate.ts:27`、`src/search/aggregate.ts:82`、`src/fetch/provider.ts:36`、`src/fetch/provider.ts:99`、`src/index.ts:201-243`、`src/search/router.ts`、`src/search/preset.ts`、`src/support/query-cache.ts`、`src/search/selection.ts`。

**引擎与引擎清单（manifest）**：一个外部服务对应一个 manifest，声明稳定 id、显示名、能力面（`search` / `fetch` / `aihot-api`）、鉴权模式（`anonymous` / `key` / `keyless-fallback`）、凭证路径、`free` 标记、免密钥标记与可免钥能力面（`keyless` / `keylessCapabilities`）、上游分组（`upstreamGroup`）、默认启用与端点。五引擎清单只存在于 registry；默认搜索/提取服务列表、设置面与 free 名单都从它派生。代码落点：`src/engines/contract.ts:24-46`、`src/engines/registry.ts:84-90`、`src/index.ts:41-48`。

**原生工具**：DSH 提供给模型的 `web_search` 与 `web_fetch` 工具。插件不新增模型工具、MCP 服务或浏览器自动化，只把两个 provider 接到这两个原生工具后面。代码落点：`src/search/aggregate.ts:13`、`src/fetch/provider.ts:11-12`。

**seam**：DSH 工具与 provider 之间的接口，统一 `WebSearchRequest` / `WebSearchResult`、`WebFetchRequest` / `WebFetchResult` 以及 `WEB_*` 错误码。融合、补派、预算和限时都发生在插件内部，质量信号通过 `sources[]` 顺序与可选字段表达。代码落点：`src/search/aggregate.ts:13`、`src/fetch/provider.ts:11-12`。

**凭证引用**：配置中记录的凭证名称而非密钥值；实际值由 DSH credentials 每次操作异步解析，密钥轮换即时生效。占位符字面量不会被当作密钥发送；`keyless-fallback` 引擎（AnySearch、Tavily、Firecrawl）未配置密钥时按可免钥面走官方匿名或公共额度（Firecrawl 只有提取面免钥，搜索仍需密钥）。已配置密钥后凭证失效不静默降级匿名；只有 `quota` 型失败按产品裁决在同槽改用匿名额度重试一次，仅限 AnySearch 与 Tavily 的免钥搜索面。代码落点：`src/index.ts:50-65`、`src/index.ts:100-127`、`src/index.ts:134-161`、`src/search/dispatch.ts`。

**实时配置引用（volatile）**：schemastery 的 `.volatile()` 让配置解析返回 `Volatile<T>` 实时引用；引用只有 `get()`（返回不可变快照）与宿主内部写入口，`JSON.stringify` 显示 `{}` 是设计形状，不是值丢失。本插件把 Config 根对象标 volatile，装配层只保留引用；`controls` 在操作入口读取一次，凭证与端点在操作的首次 lane 取快照并在同一 `OpContext` 的并发 lane 间共享；`ready`、区域与垂直目录按调用时读取最新引用。设置页保存后下一次操作生效，不重挂插件或重启 profile。代码落点：`src/index.ts`（`Config`、`makeBuildContext`、`resolveControlsFrom`、`resolveRerankKey`、`CONFIG_SNAPSHOTS`）、`client/index.js`（入口去重）、`test/live-config.test.ts`。

## 搜索

**意图路由（intent routing）**：`auto` 预设的查询分类。本地确定性关键词规则把查询判为七类意图之一：`hot-list`（热点榜单）、`ai-news`（AI 资讯）、`community-opinion`（知乎观点）、`vertical-data`（结构化取数）、`research`（调研对比）、`english-web`（英文网页）、`chinese-web`（中文网页，默认）。判定顺序即优先级：裸热点 → AI 资讯 → 社区观点 → 结构化取数 → 调研对比 → 英文网页 → 中文网页。路由器只产出意图、垂直参数、路由倾向与说明素材，不点名任何引擎；意图到来源顺序的映射在装配层。规则全部本地、确定性，同一查询永远得到同一决策，不需要模型。代码落点：`src/search/router.ts`、`src/search/selection.ts`、`src/index.ts`（`intentEnginePriority`）。

**同源去重（upstream group dedupe）**：RRF 计分前的上游分组归并。manifest 的 `upstreamGroup` 标记共享同一上游索引或搜索后端的引擎；`rrfFuse` 先按分组过滤，同组只保留排名最好（派发序在前）的一路，其余路不计票，防止「多源命中」假共识。未填分组的引擎各自独立参与融合；上游重叠度实测确认前不填分组，当前 registry 尚无分组。代码落点：`src/engines/contract.ts`、`src/search/fuse.ts`。

**RRF 融合**：Reciprocal Rank Fusion。每个候选的得分是各引擎内名次倒数之和：`score = Σ 1/(k + rank)`，`k` 默认 60。同一引擎内同一 URL 只计一次；融合前先做 URL 归一（剥 `utm_*`、锚点、统一大小写与已知别名）和内容变体键合并，重复条目的 title、snippet、publishedAt 按「已有优先、更长 snippet 胜」补齐。代码落点：`src/search/fuse.ts:32`、`src/search/aggregate.ts:31-32`、`src/support/url.ts:12`。

**查询语法翻译**：编排层把查询解析成结构化 `QuerySyntax`：`site:` 与 `-site:` 域名、`lang:` 语言、`after:` / `before:` 日期、移除操作符后的 `bareQuery`，并保留每个操作符的原样 token。引擎适配再把支持的部分映射为原生参数：Tavily 用 `include_domains` / `exclude_domains` / `start_date` / `end_date` / `language` + `filter_by_language: true`；Firecrawl 用 `includeDomains` / `excludeDomains`（二者并存时契约互斥，双方都回拼）；AnySearch 只映射 `language`；知乎与 AIHOT 没有原生参数。`before:YYYY-MM` 取上月最后一日，属严格语义；Tavily 的域名超过契约上限（include 300 / exclude 150）时返回 `invalid`，不截断放宽。代码落点：`src/search/query-syntax.ts:22`、`src/engines/contract.ts:48-78`、`src/search/aggregate.ts:234`、`src/engines/tavily.ts:117`、`src/engines/firecrawl.ts:149`。

**逐字回拼**：引擎不支持的操作符不丢弃、不改写，按 `operators[].raw` 的原 token（大小写、路径后缀、出现顺序都不变）接在 `bareQuery` 之后；全部操作符都被映射时发送 `bareQuery`，组合结果为空时退回原查询文本。Tavily 正常路径覆盖全部操作符，只有非法日期等不合契约的值才回拼；Firecrawl 在 `site:` 与 `-site:` 并存时回拼两类域名；AnySearch、知乎、AIHOT 把各自不支持的操作符全部回拼。代码落点：`src/engines/anysearch.ts:181`、`src/engines/tavily.ts:155`、`src/engines/firecrawl.ts:155`、`src/engines/zhihu.ts:70`、`src/engines/aihot.ts:442`。

**重排（SiliconFlow）**：RRF 融合与相关性过滤后，取前 30 条候选，把 `title + snippet`（单条截到 1,000 字符）送 SiliconFlow `POST /v1/rerank`，模型 `BAAI/bge-reranker-v2-m3`，按 `relevance_score` 降序；未被返回的候选按原 RRF 序接在后面，不丢结果。设置默认开启，但只有解析到 SiliconFlow 密钥时才真正调用；网络、限流、额度或解析失败一律 fail-open：保留 RRF 序并写说明，不阻塞搜索，也不计入引擎熔断。代码落点：`src/engines/registry.ts:98-104`、`src/search/rerank.ts:36`、`src/search/aggregate.ts:183-201`、`src/index.ts:84-87`。

**预设（auto / single / multi / custom / free）**：`controls.preset` 决定调用宽度。`auto` 消费意图路由结果：`research`（调研对比）与 `ai-news`（AI 资讯）多路，其余意图单路；`single` 只派发 1 路，搜索不做官方域补充，提取原样返回该路正文；`multi` 在所选服务范围内并发到 `maxSearchServices` / `maxFetchServices` 上限；`custom` 按开关、参与列表与上限执行，不套用自动宽度规则；`free` 按 `keyless` 过滤并按能力面收窄（AnySearch、Tavily 全能力；AIHOT 搜索；Firecrawl 仅提取），仍受凭证、开关、熔断与预算约束。代码落点：`src/index.ts:70-71`、`src/search/preset.ts:24`、`src/search/preset.ts:56`、`src/search/preset.ts:96`。

**自动调用范围**：`auto` 预设的搜索宽度。消费意图路由结果：仅 `research`（调研对比）与 `ai-news`（AI 资讯）多路，其余意图单路；不再维护第二份关键词宽度表。官方文档意图的限定域名补充检索另行追加（最多两个官方域名，显式 `single` 或查询含 `site:` / `-site:` 时不追加），不改变该宽度判定；中文政府权威域只在主题匹配后影响排序与域名多样性，不追加请求。意图判定在 `src/search/router.ts`，宽度在 `src/search/preset.ts`；判定不需要任何模型凭证。代码落点：`src/search/router.ts`、`src/search/preset.ts`。

**中文政府权威域**：中文查询含「政府」「政策」或「官方指南」时映射的 `gov.cn` 排序域。它与 `officialHosts` 的技术文档域分开：官方文档域按精确主机匹配并可触发补充检索；中文政府权威域按 `gov.cn` 及其子域匹配，官方优先排序与域名多样性豁免都只作用于主题匹配候选，不追加请求、不改变自动档宽度。代码落点：`src/search/quality.ts`、`src/search/output.ts`。

**垂直取数（vertical-data）**：`vertical-data` 意图下发的结构化取数请求。路由器按 39 个垂直子域关键词表产出 `VerticalRequest`（完整 `{domain}.{sub_domain}` tag 与可选标量 params）；装配层把它映射到 AnySearch，作为请求体的 `tag` / `params` 下发，其他引擎不认该字段时按通用搜索处理。派发前先经 `AnysearchDomainCatalog` 校验 tag 是否存在、官方 `required` 参数是否齐全；目录不可用、tag 不存在或缺必填参数时不重试垂直路，按查询语言（含 CJK 为中文，否则英文）回落通用路由并记说明。垂直结果里没有引用 URL 的结构化条目序列化进结果 `content`，不伪造来源，也不按空结果处理。代码落点：`src/search/router.ts`、`src/engines/anysearch-domains.ts`、`src/search/aggregate.ts`、`src/engines/anysearch.ts`。

**知乎热榜与直答（hot_list / zhida）**：`hot-list` 与 `community-opinion` 意图的两条专用读取路径。知乎 `hot_list`（平台口径 100 次/日）直接返回榜单条目；AIHOT `hot-topics`（匿名、最多 10 条）作为兜底；命中时直接取榜单，不再发查询词。知乎直答 `zhida` 仅在 `community-opinion` 意图、知乎引擎参与且凭证就绪时调用，与主搜索并发；答案写入结果 `content`，超时、失败与预算耗尽均静默跳过，不影响搜索结果。热榜走独立 lane，其结局按成功/限流/额度失败进入本地额度账本；直答不单独入账，随知乎搜索 lane 记录。知乎额度端点只汇总 `global_search` 与 `zhihu_search`，不覆盖热榜与直答。代码落点：`src/engines/zhihu-hot.ts`、`src/engines/zhihu-answer.ts`、`src/engines/zhihu.ts`、`src/search/output.ts`。

**查询缓存（query cache）**：`auto` 预设的进程内精确缓存。缓存键为归一查询（去首尾空白、连续空白折叠）+ 意图 + 排序后的 `site:` 域名 + `maxResults`；容量 50 条，LRU 淘汰。TTL 按意图分档：`ai-news` / `hot-list` 300 秒，`vertical-data` 900 秒，`research` 不缓存，其余意图 1,800 秒。显式预设（非 `auto`）与带 `after:` / `before:` 的查询不读不写；查询含「最新/今天/刚刚/实时」时只绕过读取，写入照常。命中在 `content` 前置「（缓存命中，age N 秒）」，不产生上游请求，也不计入 `maxRequests`；无来源的结果不写缓存（含仅结构化 `content` 的垂直结果）。代码落点：`src/search/cache-policy.ts`、`src/support/query-cache.ts`、`src/search/aggregate.ts`。

**空结果补派**：单通道（固定 `single`，或 `auto` 按意图判为单通道）的唯一一路成功返回但零可用结果（空返回或全部被相关性过滤）时，排除已派发服务，按预设服务表、启用位、凭证、`maxSearchServices` 与剩余 `maxRequests` 再选一批并发一次。补派结果并入同一轮融合与相关性过滤，且只补一次；派发路失败、超时、取消、限流或预算不足时明确不补派并写说明。代码落点：`src/search/aggregate.ts:261`。

**有界降级（bounded degradation）**：垂直取数或热点榜单路由没有来源、也没有结构化 `content` 时，按查询语言（含 CJK 为中文，否则英文）换通用路由重试一次。重试排除已派发引擎，按通用意图的来源顺序与预设重新选源，受剩余 `maxRequests`、操作总限时、开关、凭证与熔断约束；限流、额度、超时、取消不重试，每操作至多一次。没有可降级通道时只记说明。代码落点：`src/search/aggregate.ts`（`degradationAllowed` / `degradeRoute`）、`src/search/output.ts`。

**无 URL 结构化结果**：seam 的来源条目必须带可引用的绝对 http(s) URL。通用搜索中，上游结构化搜索项若 URL 为空、是相对地址或不是 http(s)，适配层在映射时丢弃，不伪造地址，也不把它计为来源；垂直取数是例外：AnySearch 在 vertical 请求下把无 URL 的合法结构化条目序列化进结果 `content`，不伪造来源，也不让上层误判为空结果。AIHOT 只认 `links.original`，没有原文链接的条目同样不产生来源（`links.aihot` 只进摘要）。代码落点：`src/engines/anysearch.ts:311`、`src/engines/firecrawl.ts:252`、`src/engines/aihot.ts:525`、`src/engines/aihot.ts:571`、`src/search/output.ts`。

**宽限等待**：多路结果达到「足够」后，再等一个有界宽限期（500ms 起、随启动时间递减、上限 1200ms），到期取消未完成渠道；搜索在非 `single` 预设下启用，提取只在 `auto` 预设下启用。搜索的足够条件是至少 3 路成功且有结果、相关去重候选达到 `maxResults`（默认 8），官方文档意图还要求命中官方来源；提取的足够条件是至少 3 路各有不少于 1,200 段落字符的正文，且共享至少一个标题加段落锚点。提前结束会标记 `truncated` 并在说明中提示可能遗漏。代码落点：`src/support/settle.ts:4`、`src/search/aggregate.ts:300`、`src/fetch/aggregate.ts:307`。

## 提取

**两段式提取**：`auto` 预设的提取默认路径。先按参与顺序选第一路，在首路探测限时（默认 15 秒，`DEFAULT_PROBE_TIMEOUT_MS`；Config 未暴露该字段）内探测一次；结果为 2xx、返回目标与请求 URL 同资源（允许 HTTPS 升级）、不是登录或挑战页、段落字符不少于 400 时，直接返回该路原文，不整理、不加标记；否则升级多路整理，已取得的正文作为种子并入，并跳过该引擎避免重复请求。探测和单通道都由 `runLane` 的 deadline 竞速硬超时，忽略 signal 的引擎不会拖到操作总限时。代码落点：`src/fetch/provider.ts:190`、`src/fetch/provider.ts:208`、`src/fetch/two-stage.ts:34`。

**首路探测**：两段式提取的第一段，一次请求、不扇出。探测不足时给出转入多路整理的原因（`non-2xx`、`target-mismatch`、`challenge`、`body-thin`）；探测结果超过 `maxOutputChars` 时按完整内容块省略并标 `truncated`，不裁断代码围栏或段落。代码落点：`src/fetch/provider.ts:208`、`src/fetch/provider.ts:366`、`src/fetch/two-stage.ts:17`。

**正文整理**：把同一 URL 的多路提取合成为一份正文。先去噪，再按标题章节与内容块键去重、互补，保留独有章节和文本差异；标题、版本、语言或返回目标不同的内容不混入主正文，而进入补充片段；引用式链接与脚注按来源隔离。整理不调用语言模型。默认单页上限为 15,000 字符（`controls.maxOutputChars`），超限按完整内容块省略并标 `truncated`；结构化 JSON/XML 超限直接报 `WEB_FETCH_TOO_LARGE`。代码落点：`src/fetch/document/organize.ts:160`、`src/fetch/aggregate.ts:268`。

**内容块**：标题、段落、代码围栏、表格、列表或引用。去重、差异比较和输出预算都以完整内容块为单位，不裁断代码围栏或段落。代码落点：`src/fetch/document/blocks.ts:7-14`、`src/fetch/document/organize.ts:259`。

**提取来源**：整理结果中的 `F#:B#` 溯源标记。`F#` 是第几路提取，尾注给出对应的引擎与状态；`B#` 是该路原始内容块序号。只有参与整理的不同引擎不少于两路时，正文块内才内联标记；同一页面的多份提取不是独立事实佐证。代码落点：`src/fetch/document/organize.ts:176`、`src/fetch/document/organize.ts:251`。

**专用 API 读取**：已启用且声明 `aihot-api` 能力的 AIHOT，在通用 URL 分流前直接读取官方 `/api/v1/*`：Markdown 端点原样返回，JSON 端点校验 `schemaVersion` 后返回完整 JSON；保留原文链接、来源署名与分页字段，不参与正文评分或提取竞争。读取只处理显式请求的一页，不自动翻页或同步；过大响应明确报错，不截断结构化数据；429/503 的 Retry-After 在实例内冷却其他 API 路径。知乎问题回答不经过专用读取器，走引擎 fetch 面（`src/engines/zhihu-question.ts`）。代码落点：`src/fetch/provider.ts:154-169`、`src/fetch/provider.ts:150`、`src/engines/aihot.ts:227`。

**地址守卫**：在目标进入 AIHOT 专用 API、引擎适配器或任何第三方提取服务之前，拒绝本机与内网目标。字面地址直接分类；主机名先解析，任一答案属于回环、私网、链路本地、保留、CGNAT、唯一本地或转换/隧道前缀时，以 `WEB_BLOCKED_URL` 拒绝；解析失败不拦截。当前 Config 不暴露关闭开关或静态主机豁免，生产路径对所有第三方提取目标启用守卫；provider 内部的 `blockPrivateAddresses` 与 `route.staticDomains` 选项只供装配或测试注入。代码落点：`src/support/address-guard.ts:73`、`src/fetch/provider.ts:121-148`。

**URL 分流**：按顺序判定提取路线：不可解析或非 http(s) URL、路径命中内置静态扩展名表时，走内置 HTTP 单发；其余走多路提取引擎。`route` 选项可由装配层覆盖（关闭分流、静态域名、扩展名表），当前 Config 未暴露这些字段，生产路径使用内置扩展名表。分流只决定路线，不认识具体引擎。代码落点：`src/fetch/route.ts:53`、`src/fetch/provider.ts:130-132`。

**body-thin**：整理结果的参照正文段落字符少于 200 时，尾注给出的正文过薄说明。它不是失败，只提示该页可能没有返回完整正文。代码落点：`src/fetch/document/organize.ts:26-30`、`src/fetch/document/organize.ts:253`。

## 额度、熔断与预算

**额度查询**：每个引擎的 `quota()` 返回 `QuotaReport`（`used` / `limit` / `remaining` / `resetsAt` / `raw`）或显式 N/A。Tavily 读 `/usage`（keyless 模式显式 N/A）；Firecrawl 读 `/v2/team/credit-usage`（需密钥；`remainingCredits` / `planCredits`，`resetsAt` 取 `billingPeriodEnd`）；知乎读 `/api/v1/quota`（需 Access Secret），只聚合 `global_search` 与 `zhihu_search`；AnySearch 与 AIHOT 没有官方额度端点，显式 N/A。搜索侧每本地日首次操作至多探测一次，正常 resolve 的结果（含显式 N/A）写入官方快照仓，失败只记日志、不阻塞当天搜索。代码落点：`src/engines/contract.ts:113-123`、`src/engines/registry.ts:9-67`、`src/engines/tavily.ts:281`、`src/engines/firecrawl.ts:327`、`src/engines/zhihu.ts:354`、`src/search/aggregate.ts:319`。

**官方快照仓（quota snapshot store）**：`src/support/quota-snapshots.ts` 的进程内 per-engine 留档：`ok` 保存 `QuotaReport` 的 `used` / `limit` / `remaining` / `resetsAt` / `raw` 与 `fetchedAt`，`unavailable` 只保存原因与 `fetchedAt`；`available:false` 与探测失败不冒充官方数值。搜索日检正常 resolve 的每次探测（含显式 N/A）与手动刷新都写入同一仓，额度面板是唯一读取方；重启清零。代码落点：`src/support/quota-snapshots.ts:40`、`src/support/quota-panel.ts:111`、`src/index.ts:218`。

**额度面板（quota panel）**：设置卡「额度」小节，五行对应五个引擎（直接 HTTP 不进面板）。每行由官方快照仓、本地额度账本、服务开关与凭证状态组成；官方侧四态为「估算」（无端点）/「未刷新」/数值与周期文案/原因原文，另标「已停用（未探测）」与「今日未使用」。手动刷新只探测已启用且有 `quota()` 的引擎，单飞、每引擎 10 秒、整次 15 秒，返回的完整 payload 直接发布；客户端经 `connection.rpc` 调 `quotaPanel/get` / `quotaPanel/refresh` 读取，通道失败只降级本小节。代码落点：`src/support/quota-panel.ts:111`、`src/index.ts:190`、`src/index.ts:269`、`client/index.js`。

**本地额度账本（local quota ledger）**：`QuotaLedger` 按引擎与本地日累计 `success` / `rateLimited` / `quotaFailures`；同一本地日额度型失败达到 2 次即 `locallyExhausted`，该源当日不再派发；搜索与提取共享同一账本。口径是本地观察估算，不是上游余额；重启清零，无端点引擎只以本地计数参与判断。代码落点：`src/support/quota-ledger.ts:35`、`src/index.ts:380`。

**额度熔断与限流冷却**：统一失败模型中的 `rate-limited` 触发冷却（按 Retry-After；无提示默认 60 秒，重复触发指数退避，封顶 1 小时）；`quota` 触发日级熔断，HTTP 402 记为 `insufficient-credits`，其余记为 `quota-exhausted`，到本地次日零点恢复；额度查询返回 `remaining <= 0` 时也记 `quota-exhausted`。熔断引擎在派发前跳过；状态惰性结算，不依赖定时器。搜索与提取共用装配层创建的同一个进程内熔断器。官方快照 `remaining > 0` 的手动刷新调用 `clearDaily` 解除当日日级条目并发恢复事件，`rate-limit` 冷却不受影响。代码落点：`src/support/breaker.ts:65-75`、`src/support/breaker.ts:97-100`、`src/support/breaker.ts:133`、`src/index.ts:187-244`。

**操作请求预算**：一次 provider 操作允许的插件 HTTP 请求上限，默认 32（`controls.maxRequests`）。引擎每个 HTTP 尝试（含额度查询与重试）在网络写出前调用 `countRequest()` 取许可；耗尽后拒绝新请求并写进说明。它不等于上游计费额度，也不限制上游内部工具调用次数。代码落点：`src/support/budget.ts:37-81`、`src/index.ts:78`。

模块边界见[架构说明](./DESIGN.md)，参数定义见[配置参考](./docs/configuration.md)，整理规则见[正文整理](./docs/content-organization.md)。
