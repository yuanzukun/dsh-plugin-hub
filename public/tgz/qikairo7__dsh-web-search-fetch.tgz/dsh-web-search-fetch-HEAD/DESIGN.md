# 架构说明

## 当前交付状态

本文件描述 v0.4.5 的架构；对外行为按当前代码描述，不保留 v0.2 的兼容 shim。

v0.3.0 把搜索与提取收敛为五个引擎：AnySearch AI、Tavily、Firecrawl、知乎、AIHOT；直接 HTTP 抓取继续作为内置静态路径。v0.4 在搜索侧加入按查询意图路由（七意图 + 39 个 AnySearch 垂直 tag）、知乎热榜与直答、查询缓存、本地额度账本、同源去重与有界降级；提取侧保留两段式探测、多路正文整理与内网地址守卫。

最新验收为 [v0.4.5 搜索与重排验收](./docs/verification/v0.4.5-search-rerank-20261109.md)：隔离 DSH Web 中一次 `web_search` 真实调用返回主题匹配的 `gov.cn` 前两条，并经过 SiliconFlow 重排；[v0.4.4 实时配置与设置页保存验收](./docs/verification/v0.4.4-live-config-20261109.md)仍保留真机保存 BLOCKED 边界；验收明细与数字以对应记录为唯一事实源，仓库门禁数字以 README 的「项目定位与证据」表为现行口径。

当前明确的边界：

- 额度日检在每次搜索的选源之前执行，每实例每本地日至多一次；设置卡「额度」小节显示官方快照与本地计数，并提供手动刷新（每引擎 10 秒、整次 15 秒，单飞）。本地额度账本只做估算，不伪造上游余额。
- `select` 正文模式与 `engineWeights` 已删除；提取只走多源整理。
- AD14 的 `summary` 字段已在引擎契约中预留，但五个适配器均未产出，融合与 seam 投影也不处理该字段。
- `EngineManifest.enabledByDefault` 是默认开关的事实源：装配层据此构造 `serviceEnabled` 默认字典（`http` 恒开），用户显式设置覆盖默认值；`cordis.patch.yml` 只是发行配置的显式覆盖。
- 本文件随 v0.4 增量同步；`docs/verification/` 中按版本归档的验证记录保持历史原样，后续版本不自动继承结论。

## 项目定位

`dsh-web-search-fetch` 是运行在 DSH 进程中的 Cordis 插件。插件向 `ctx.web` 注册搜索与网页提取 provider，两者的 ID 都是 `aggregated`，分别供原生 `web_search` 与 `web_fetch` 工具使用。宿主按 `searchProvider` / `fetchProvider` 选中该 ID，工具面不感知内部引擎。

插件只直接调用 HTTP API：不启动外部服务，不读取 `ctx.web` 的私有注册表，不注册额外的模型可见工具。质量信号只能通过 `sources[]` 的顺序与 `url`、`title`、`snippet`、`summary`、`publishedAt` 字段表达；`truncated` 表示结果被截断。提取返回 `WebFetchResult`，其中非 2xx 是结果而不是错误，正文类型只能是 `html` 或 `text`。

## 分层架构

分层顺序为：装配层 `src/index.ts` → 搜索/提取编排层 `src/search/`、`src/fetch/` → 引擎适配层 `src/engines/` → 横切支撑层 `src/support/`。依赖只能向下，编排层不得 import 具体引擎模块或硬编码引擎 id；引擎清单、端点和鉴权模式只允许出现在 `src/engines/registry.ts`。

| 层 | 文件 | 职责 |
| --- | --- | --- |
| 装配 | `src/index.ts` | Cordis 插件定义、registry 派生的 Config、每操作凭证解析、端点覆盖、意图→引擎映射、`buildEngines` 装配、两个 `aggregated` provider 注册、熔断事件接线 |
| 搜索编排 | `src/search/aggregate.ts` | 一次搜索的完整流程：意图路由、缓存、额度日检（选源之前）、熔断过滤、服务选择、垂直校验与热点榜、官方域补充、并发派发、融合、有界降级、补派、重排；输出治理（多样性、预算、归因与说明渲染）在 `search/output.ts` |
| 意图路由 | `src/search/router.ts` | 七意图与 39 个垂直 tag 的本地确定性判定；只产意图、参数与说明素材，不点名引擎 |
| 搜索策略 | `src/search/preset.ts`、`selection.ts`、`cache-policy.ts`、`ranking.ts`、`dispatch.ts`、`output.ts`、`quality.ts`、`query-syntax.ts`、`fuse.ts`、`rerank.ts` | 预设宽度与选择、意图→候选排序与热点引擎、缓存 TTL/绕过、融合候选装配、单路派发、输出治理、官方文档与相关性规则、操作符解析、RRF 融合、SiliconFlow 重排 |
| 提取编排 | `src/fetch/provider.ts`、`aggregate.ts` | 地址守卫、专用 API 面、静态/动态分流、单通道与两段式、多路派发与正文整理 |
| 提取策略 | `src/fetch/route.ts`、`two-stage.ts`、`select-best.ts`、`types.ts` | URL 分流、首路探测判定、候选打分（当前仅测试与未来路径使用）、共享候选类型 |
| 正文整理 | `src/fetch/document/blocks.ts`、`organize.ts` | HTML→Markdown、内容块切分与清洗、章节对齐、去重互补、来源与差异、输出预算 |
| 引擎适配 | `src/engines/registry.ts`、`contract.ts`、`failure.ts`、`http.ts`、`anysearch.ts`、`anysearch-domains.ts`、`tavily.ts`、`firecrawl.ts`、`zhihu.ts`、`zhihu-hot.ts`、`zhihu-answer.ts`、`zhihu-question.ts`、`zhihu-shared.ts`、`aihot.ts` | 五个 manifest、引擎接口、统一失败模型、共享 HTTP 核心、各引擎协议映射与额度查询、AnySearch 垂直目录发现、知乎热榜与直答、知乎问题回答读取、知乎适配公共小件（鉴权头、路径换算、字段取值与 envelope 错误映射） |
| 横切支撑 | `src/support/budget.ts`、`lane-runner.ts`、`breaker.ts`、`settle.ts`、`url.ts`、`address-guard.ts`、`query-cache.ts`、`quota-ledger.ts`、`quota-snapshots.ts`、`quota-panel.ts` | 显式操作上下文与请求预算、单路运行器、日级熔断（含当日解除）、宽限窗口、URL 归一化、内网地址守卫、查询缓存机制、本地额度账本、官方快照仓与额度面板服务 |
| 设置界面 | `client/index.js` | Web 设置卡片、服务开关、凭证位、预设与调用限制、端点覆盖与重排开关、额度面板与手动刷新 |

分层不变量由 `test/architecture.test.ts` 钉死：`src/search/`、`src/fetch/`、`src/support/` 不得 import `src/engines/` 下除 `contract`、`failure`、`http`、`registry` 之外的模块，也不得出现五个引擎 id 的字面量；registry 必须恰好注册五个引擎。

### 意图路由三段式（ADR-0001）

[ADR-0001](./docs/adr/0001-intent-routing.md) 把源选择定为三段：意图 → 源池与策略 → 可用实例。

1. **意图**：`search/router.ts` 的 `routeSearchQuery` 用本地确定性规则判定七类意图（`hot-list`、`ai-news`、`community-opinion`、`vertical-data`、`research`、`english-web`、`chinese-web`）与 39 个垂直 tag；路由器只判意图与倾向，不点名引擎（R7 红线）。
2. **源池与策略**：装配层 `intentEnginePriority` 把意图翻成有序引擎 id（引擎知识只出现在装配层），`search/selection.ts` 按该顺序排候选；`search/preset.ts` 决定宽度——`auto` 下 `research` / `ai-news` 多路，其余意图单路。垂直 tag 先经 `AnysearchDomainCatalog` 校验存在性与必填参数，不合法 fail-open 回通用路由（按查询语言选中文或英文）。
3. **可用实例**：`selectServices` 叠加服务总开关、参与列表、`free` 的 `keyless` 过滤、凭证就绪与本地额度账本，再由熔断器过滤；额度日检前置于选源之前。

热点/热榜意图在映射序内取第一个具备 `hotTopics` 的已选引擎（知乎 `hot_list` 优先、AIHOT `hot-topics` 兜底），命中时直接取榜单；知乎观点意图同时请求知乎直答，答案走 `content` 通道，失败 fail-open。

### 架构决策落位

spec 的 AD1–AD14 在当前代码中的实际状态如下。状态为「部分」的条目只描述已经存在的行为，未实现部分同时写在条目里。

| 决策 | 内容 | 落位状态 |
| --- | --- | --- |
| AD1 | 单一引擎注册表 | 已落地：`ENGINE_MANIFESTS`、`buildEngines`、`EngineRegistryDeps` 是引擎事实源。`client/index.js` 不能 import 宿主模块，重述了一份服务表，由 `test/client-surface.test.ts` 把 id、能力、free/keyless 标记与 registry 对齐；`enabledByDefault` 同时驱动装配层与客户端缺省开关。 |
| AD2 | 严格分层，编排层无引擎知识 | 已落地：R7 架构测试检查 import 与 id 字面量；引擎优先级取 registry 顺序，不再硬编码。 |
| AD3 | 共享单路运行器 | 已落地：搜索与提取都走 `support/lane-runner.ts`；每路独立 AbortController、deadline 竞速、失败收敛为数据。 |
| AD4 | 状态与呈现分离 | 部分：搜索侧已有显式 `LaneState` / `LaneReport` 词表，零结果说明与全败消息集中在 `search/output.ts`，中文文案集中在同文件的 `NOTE_TEXT` 单一文案表，编排侧只产出结构化 `Note`；seam 仍只有 `content` 字符串，没有独立的结构化 `OperationStatus` 字段。 |
| AD5 | 显式操作上下文 | 已落地：`OpContext` 作为参数贯穿搜索与提取，替代 AsyncLocalStorage；预算、说明、deadline 判定都在上下文上。 |
| AD6 | 统一失败模型 | 已落地：`EngineFailure` 是唯一引擎失败词表；`breakerSignalOf` 一处投影；编排层不 import 引擎专用错误类型。提取层再把失败投影成 `WEB_*` 码。 |
| AD7 | URL 工具单一源 | 部分：归一化在 `support/url.ts`；去重键 `contentVariantKey` 在 `search/quality.ts`，同资源判定在 `fetch/two-stage.ts`，slug 提取在 `fetch/select-best.ts`。三处规则尚未合并到一个模块。 |
| AD8 | truncated 逐层传播 | 已落地：每个引擎自报截断；引擎、融合、补派、宽限、总限时与输出预算逐层合并为最终 `truncated`。 |
| AD9 | 额度查询成真 | 部分：Tavily、Firecrawl、知乎实现 `quota()`；AnySearch、AIHOT 没有额度端点（显式 N/A），日检跳过。`remaining <= 0` 会喂入日级熔断；官方快照经快照仓留存并在设置页「额度」小节展示，支持手动刷新。热榜、直答与问题发现额度仍未覆盖。 |
| AD10 | `lib/` 门禁纪律 | 已落地：`lib/` 是 git 跟踪的构建产物，`scripts/check-distribution.mjs` 校验 `package.json` 入口与每个 `src/*.ts` 对应的 `.js` / `.d.ts`；必需文件清单以脚本实际输出为准。 |
| AD11 | 服务 id 稳定 | 已落地：`anysearch`、`tavily`、`firecrawl`、`aihot` 沿用 v0.2；新增 `zhihu`；显示名与凭证位不改旧 id。 |
| AD12 | 文档全量重写 | v0.3 基线已完成；v0.4 增量（意图路由、垂直取数、热榜与直答、缓存、额度账本、有界降级）同步进 README、configuration 与本文件；`docs/verification` 保持历史原样，v0.3.0 记录已归档。 |
| AD13 | 查询语法翻译层 | 已落地：`search/query-syntax.ts` 解析 `site:`、`-site:`、`lang:`、`after:`、`before:`；各引擎按原生能力映射，不支持的 token 逐字回拼。 |
| AD14 | `summary` 字段利用 | 未落地：`EngineSearchSource.summary` 已在契约中预留；五个适配器都没有产出该字段，`fuse.ts` 的合并与 `toSeamSource` 投影也不读写 `summary`。 |

## 五引擎与额度

五个引擎的端点、鉴权、能力与默认状态如下。端点值是 registry 中的默认官方端点；`anysearchBaseURL` 与 `firecrawlBaseURL` 可在配置中覆盖，Firecrawl 适配器会把覆盖值当作基点，按目标操作拼接已知路径。

| id | 显示名 | 能力 | 鉴权 | 搜索 / 提取端点 | 额度端点 | 免费标记 | bundle 默认 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `anysearch` | AnySearch AI | search、fetch | keyless-fallback | `https://api.anysearch.com/v1/search`、`/v1/extract` | 无公开端点 | 是 | 开 |
| `tavily` | Tavily | search、fetch | keyless-fallback | `https://api.tavily.com/search`、`/extract` | `https://api.tavily.com/usage` | 是 | 开 |
| `firecrawl` | Firecrawl | search、fetch | keyless-fallback（仅 fetch 免钥） | `https://api.firecrawl.dev/v2/search`、`/v2/scrape` | `https://api.firecrawl.dev/v2/team/credit-usage` | 是 | 开 |
| `zhihu` | 知乎 | search、fetch | key | `https://developer.zhihu.com/api/v1/content/global_search`、`/zhihu_search`、`/api/v1/content/question_answers`（仅 zhihu.com/question/*） | `https://developer.zhihu.com/api/v1/quota` | 否 | 关 |
| `aihot` | AIHOT | search、aihot-api | anonymous | `https://aihot.news/api/v1/items`、专用读取 API | 无 | 是 | 关 |

`http` 不是 registry 引擎，而是装配层包装的内置 HTTP 提取器，负责静态 URL；它没有凭证位，服务开关键为 `http`。

运行时能力：知乎的 `fetch` 面读取问题回答（`question_answers`，仅 `zhihu.com/question/*`）；`hotTopics`（`hot_list`）与直答（搜索请求的 `wantAnswer`，答案走 `content`）由路由意图触达；AIHOT 实现 `hotTopics`（`/api/v1/hot-topics`）。

鉴权行为：

- `keyless-fallback`：未配置凭证时不发 `Authorization`。AnySearch 走匿名请求；Tavily 另发 `x-tavily-access-mode: keyless`；Firecrawl 只有 fetch 面免钥（`keylessCapabilities: ['fetch']`），search 面缺凭证时不发请求并报 `auth`。已配置凭证时使用账号模式，凭证失效报 `auth`，不静默降级匿名。账号额度耗尽（`quota` 失败）时同一次操作内去掉凭证按匿名额度重试一次并记说明；该降级只对 search 面确实免钥的引擎生效。
- `key`：知乎没有匿名分支。未配置凭证时适配器直接返回 `auth` 失败且不发请求；Firecrawl 的搜索面同样需要凭证（按能力面就绪判定），提取面走 keyless-fallback。
- `anonymous`：AIHOT 只读，不需要凭证；它的专用读取 API 由装配层注入读取器，provider 按 manifest 的 `aihot-api` 能力识别。
- 占位符值（例如 `ANYSEARCH_API_KEY`、`tvly-YOUR_API_KEY`、`fc-your-key`）不会被当作真实密钥发送。

额度行为：

- Tavily `/usage`：只在有 key 时请求；返回 `key.usage`、`key.limit`、`account.plan_limit`/`account.plan_usage` 与 `account.current_plan`。`key.limit` 为 null 时回退计划档配对（limit/used/remaining 取 plan_limit/plan_usage）；`key.limit` 与 `account.plan_limit` 均为显式 null 才表示不限，字段缺失或类型异常如实返回不可用。keyless 模式显式返回 `available: false`，不请求 `/usage`。
- Firecrawl `/v2/team/credit-usage`：读取 `remainingCredits`、`planCredits`、`billingPeriodEnd`；`resetsAt` 取账期结束时间。未配置 key 时返回 `available: false`（keyless 免费层不支持额度端点，不发请求）。
- 知乎 `/api/v1/quota`：以 `APIIDs=global_search,zhihu_search` 查询，聚合两项的 `TotalQuota`、`TotalUsed`、`RemainingQuota`；契约说明该查询不消耗业务额度。
- AnySearch 与 AIHOT 没有 `quota()`（显式 N/A）；日检跳过它们，只在当日首次日检说明中标注本地计数为估算。
- 搜索 provider 在每个本地日第一次搜索时、选源之前，对已启用且带 `quota()` 的引擎各探测一次，单次探测 deadline 为 10 秒；失败只记日志，不阻塞搜索。正常 resolve 的探测结果经 `onQuotaReport` 写入官方快照仓（含 `available:false` 的显式 N/A），抛错路径不上报。`available && remaining <= 0` 时写入 `quota-exhausted` 熔断信号；日检先于选源，因此当轮即跳过该引擎。
- 官方快照仓（`support/quota-snapshots.ts`）：每引擎留档 `ok`（`QuotaReport` 的 used / limit / remaining / resetsAt / raw 与 `fetchedAt`）或 `unavailable`（原因与 `fetchedAt`）；`available:false` 与探测失败不冒充官方数值。日检正常 resolve 的每次探测与手动刷新写同一仓，面板是唯一读取方；重启清零。
- 额度面板服务（`support/quota-panel.ts`）：`get()` 按调用时刻现组装 day / ledger / breaker / official；`refresh()` 只探测已启用且有 `quota()` 的引擎，每引擎 in-flight Promise 单飞，每引擎硬超时 10 秒、整次总截止 15 秒，返回完整 payload 供客户端直接发布。凭证解析异常归一为 `unavailable('凭证服务不可用')`，零请求且不连坐其他引擎。
- 当日解除（`support/breaker.ts` 的 `clearDaily`）：官方快照 `available && remaining > 0` 时删除该引擎已有的日级条目（`quota-exhausted` / `insufficient-credits`）并发恢复事件；`rate-limit` 冷却不受影响。用户在配置密钥或套餐恢复后点「刷新额度」，当天即可恢复派发。
- 本地额度账本（`support/quota-ledger.ts`）：每引擎按本地日累计 success / rate-limited / quota 失败；同一日 quota 失败达到 2 次即 `locallyExhausted`，`ready` 在该本地日余下时间跳过该源；搜索与提取共用同一账本与回调。该口径是估算，不伪造上游余额。
- keyless-fallback 额度降级（`search/dispatch.ts`）：带密钥的搜索路遇 `quota` 失败时，用去掉 `apiKey` 的同一引擎上下文在同一 lane、同一 deadline 与请求预算内匿名重试一次，并记「额度耗尽，改用匿名额度」说明；`auth` 失败不降级。

各引擎的协议要点：

- AnySearch：`POST /v1/search` 请求体为 `{query, max_results}`，`max_results` 范围 1–10；`POST /v1/extract` 请求体只允许 `{url}`，上限 16 KiB，契约正文上限 50,000 字符；超过该值或带上游 `...(content truncated)` 标记时置 `truncated`。402 的错误正文可能含自动建号凭据，适配器丢弃其 detail。
- Tavily：`POST /search` 的 `max_results` 上限 20，`content` 截为 500 字符的 snippet；`POST /extract` 发 `{urls:[url], format:'markdown', extract_depth:'basic'}`，HTTP 200 也检查 `failed_results`，非空即目标级失败（状态码用 400 占位）。HTTP 432/433 也是额度耗尽，434 是容量问题而非额度。
- Firecrawl：`POST /v2/search` 的 `limit` 上限 100，解析 `data.web[]`；`POST /v2/scrape` 发 `formats:[{type:'markdown'}], maxAge:0`，透传 `metadata.statusCode` 与最终 URL。`scrape` 无 key 时不带 `Authorization`，走官方 keyless free tier；`search` 无 key 不发请求并报 `auth`。HTTP 200 信封中的 `insufficient_credits` / `rate_limit` 分别按额度 / 限流处理。
- 知乎：GET 请求必须带 `Authorization: Bearer <Access Secret>` 与秒级 `X-Request-Timestamp`。查询含「知乎」或 `zhihu.com`（含 `site:zhihu.com`）时走站内 `zhihu_search`，否则走 `global_search`；两面上限分别为 10 / 20。问题回答走 `GET /api/v1/content/question_answers?QuestionUrl=<原问题URL>&Limit=20`，只取首页，`Paging.IsEnd=false` 时置 `truncated`；非 `zhihu.com/question/*` URL 不发请求，返回 `invalid` 让位其他引擎。envelope `Code` 20001 为鉴权失败、10001 为参数错误、30001 为限流，其余非 0 按服务端错误处理；问题回答的 30001 投影为 `quota`（问题发现日额度与频率/并发二义）。
- AIHOT：`GET /api/v1/items?mode=all&window=7d&q=<query>&limit=<1..100>`，`q` 按码点 2–200；要求 `schemaVersion: 1` 与布尔 `page.hasMore`；结果默认缓存 60 秒、最多 32 项，429/503 触发实例内冷却。专用读取只接管 `https://aihot.news/api/v1/` 下的白名单路径（items、hot-topics、stories、dailies、weeklies、monthlies、selected、codex-resets、agent 等），JSON 超过 100,000 字符时明确报错而不截断；普通专用端点默认缓存 60 秒，codex-resets 默认 10 分钟。

## 搜索管线

一次 `web_search` 的路径如下。步骤顺序与 `src/search/aggregate.ts` 一致（v0.4：意图路由与缓存前置，额度日检先于选源）。

1. 读取控制快照，建立 `OpContext`（操作信号 = 调用方取消 + `searchDeadlineMs`，默认 15 秒），进入 `runOperation`；`routeSearchQuery` 判定意图并先记说明，`searchCachePolicy` 决定本次是否读缓存，命中直接返回缓存结果与 age 说明。
2. 从引擎表取出具备 `search` 能力且实现了 `search` 的引擎；对已启用引擎执行额度日检（选源之前），本地额度账本参与 `ready` 判断；熔断中的引擎跳过并记日志。
3. 垂直 tag 经 `AnysearchDomainCatalog` 校验（存在性与必填参数）；不合法时记说明并 fail-open 到按查询语言选择的通用意图（`chinese-web` / `english-web`）。
4. 按意图映射排序候选（`orderCandidates`）；有意图映射时该顺序决定派发序，`searchServices` 只做成员资格过滤；无映射时按用户 `searchServices` 顺序。再按预设、`serviceEnabled`、`maxSearchServices` 选择服务。`single` 最多 1 路；`multi` 取上限；`auto` 的宽度由意图决定（`research` / `ai-news` 多路，其余单路）；`custom` 取上限；`free` 只保留 `keyless` 引擎。选择阶段按 `ready` 跳过缺少有效凭证或本地额度耗尽的源，选择后再过滤一次熔断。
5. 热点/热榜意图且映射序内有具备 `hotTopics` 的已选引擎时，直接取榜单（知乎 `hot_list` 优先、AIHOT `hot-topics` 兜底）；否则普通派发。官方域补充检索：查询命中受支持项目的官方文档意图时，为每个官方域名追加限定 `site:` 的检索；受支持项目为 Python、TypeScript、Node.js、JavaScript/Promise、React、Rust、Go，显式 `site:` 直接作为域名来源。显式 `single` 预设或查询含 `site:` / `-site:` 时不追加。单个域名时取前 2 个已选引擎，多个域名时每个域名取前 1 个，因此最多追加 2 路。补充检索与基础检索并发，共用请求预算；同一引擎的补充结果在融合时与基础结果合并，不额外增加票数。中文「政府 / 政策 / 官方指南」查询的 `gov.cn` 权威域只在主题匹配后参与排序与多样性，不追加补充检索。
6. 并发派发。每路通过 `runLane` 执行，单路 deadline 为 10 秒；搜索结果上限为请求的 `maxResults`，未给时按 8 传给引擎。`SettlementWindow` 在多通道场景下观察是否已有足够结果：至少 3 个引擎有来源、相关且去重的候选达到 `maxResults`，若查询有官方域名意图还要求出现相关官方结果。满足后等待 500–1200 毫秒宽限，然后取消未完成渠道，并记录截断说明。
7. 对成功路的来源做 URL 归一化、上游分组去重（同组只保留排名最好的一路）与 RRF 融合。RRF 得分为每个引擎内 `1 / (k + rank)` 的累加，`k = 60`；同一引擎内的重复键只计一次。同分按首次出现顺序。合并时标题与日期取已有值，摘要取较长者。
8. 相关性过滤。查询词按英文词与连续中文段切分，时效词（最近、最新、近期等）先剔除。两个及以上主题词时要求候选命中至少两个主题；单个复合 token（由连字符、下划线、点连接）按词段多数判定；单个普通词信息不足，保持不过滤。三个字以上的中文段允许按字符 2/3 覆盖匹配。结构化数据只有 `content` 没有来源也算有产出。
9. 有界降级。垂直或热榜路由没有来源、也没有结构化 `content` 时，按查询语言换通用路由重试一次，排除已派发引擎；限流、额度、超时、取消不重试，每操作至多一次，受剩余预算与总限时约束。
10. 空结果补派。仅当预设解析为单通道、首轮所有路都成功、实际只派发了一个引擎、且没有任何相关候选时触发。补派排除已派发引擎与熔断引擎，遵守 `maxSearchServices`、`remainingRequests` 与 `free` 预设；失败、超时、取消、限流的路不触发补派。补派只发生一次，结果并入同一套融合、相关性与说明。
11. SiliconFlow 重排（默认开启且配置了 `SILICONFLOW_API_KEY` 时）。取相关性过滤后的前 30 个候选，文档文本为 `title + snippet` 截断到 1000 字符，请求 `POST https://api.siliconflow.cn/v1/rerank`，模型 `BAAI/bge-reranker-v2-m3`。成功按 `relevance_score` 降序，未返回的候选按原 RRF 序追加；失败或返回空结果时按原序返回并记说明，不阻塞搜索。重排请求计入操作请求预算，超时为 5 秒。
12. 输出治理。官方优先重排：命中排序域且主题匹配的候选按中文路径、其他路径、外语路径分级提前；根路径在没有明确官网意图时不优先；官方文档域按精确主机匹配，`gov.cn` 权威域按任意子域匹配。随后每域默认至多保留 2 条（主题匹配的官方文档域与 `gov.cn` 权威域豁免，记省略数），按 `maxResults` 截断，再用 `maxOutputChars` 按 title+snippet 从尾部裁剪并记省略数；说明附引擎×命中数与耗时（前 3），答案与处理说明合并进 `content`。`truncated` 为真当且仅当：宽限提前结束、操作总限时到、任一成功引擎自报截断、截断前候选数超过 `maxResults`、或搜索输出预算裁剪。无相关结果时返回空 `sources` 与逐路状态说明；全部引擎失败返回 `WEB_PROVIDER_ERROR`，总限时返回 `WEB_SEARCH_TIMEOUT`，调用方取消返回 `WEB_ABORTED`。

### 预设与调用宽度

| 预设 | 搜索行为 | 提取行为 |
| --- | --- | --- |
| `auto` | 消费意图路由：`research` / `ai-news` 多路，其余意图单路；垂直/热榜无产出时按语言降级一次；官方文档意图仍追加限定域名补充检索 | 先探一路；正文足够直接返回，不足转多路整理 |
| `single` | 只派发 1 路；唯一一路空结果时可补派一次 | 只派发 1 路并原样返回；`singleChannelEscalate` 打开时才在失败或过薄时转多路 |
| `multi` | 在参与范围内按上限并发 | 直接多路整理 |
| `custom` | 按开关、参与范围与上限执行 | 直接多路整理 |
| `free` | 按 `keyless` 过滤并按能力面收窄：AnySearch、Tavily、AIHOT（需启用）、直接 HTTP 静态抓取与 Firecrawl 免钥提取；Firecrawl 搜索仍需密钥，不进入 free 搜索面 | 直接多路整理（仅 keyless 引擎） |

`auto` 的宽度只由意图决定：`research` / `ai-news` 多路，其余单路；官方文档意图由 `quality.ts` 追加限定域名补充检索（显式 `single` 或查询含 `site:` / `-site:` 时不追加）。`free` 按 `keyless` 过滤并按能力面收窄：AnySearch、Tavily、AIHOT（bundle 默认关闭，需先启用）+ 直接 HTTP 静态抓取，以及 Firecrawl 的免钥提取面；Firecrawl 搜索仍需密钥，不进入 free 搜索面。

### 查询语法翻译

`parseQuerySyntax` 按空白切分，识别以下操作符；每个操作符保留原 token（`raw`）与解析值：

| 操作符 | 解析规则 | Tavily | Firecrawl | AnySearch | 知乎 / AIHOT |
| --- | --- | --- | --- | --- | --- |
| `site:example.com` | 域名小写，允许路径后缀但只取域名 | `include_domains` | `includeDomains` | 回拼原文 | 回拼原文 |
| `-site:example.com` | 排除域名 | `exclude_domains` | `excludeDomains` | 回拼原文 | 回拼原文 |
| `lang:zh` | 两位语言码，可逗号分隔 | `language` + `filter_by_language: true` | 回拼原文 | `language` | 回拼原文 |
| `after:YYYY[-MM[-DD]]` | 起始日期，含当日语义 | `start_date` | 回拼原文 | 回拼原文 | 回拼原文 |
| `before:YYYY[-MM[-DD]]` | 严格早于该期间 | `end_date` | 回拼原文 | 回拼原文 | 回拼原文 |

细节：

- `before` 的严格语义：`before:2026` 取 `2025-12-31`，`before:2026-10` 取 `2026-09-30`，完整日期原样使用。`after:2026-10` 取 `2026-10-01`。
- Tavily 的 `include_domains` / `exclude_domains` 超过 300 / 150 时返回 `invalid`，不截断放宽过滤意图；非法日历日期按不支持处理，原 token 回拼。
- Firecrawl 的 `includeDomains` 与 `excludeDomains` 互斥。两者同时出现时，所有 `site:` / `-site:` token 都逐字回拼，且不发送任何域名参数；`lang`、`after`、`before` 没有契约字段，也回拼；`tbs` 不映射。
- AnySearch 只映射 `language`，其余操作符回拼；知乎与 AIHOT 的 API 没有操作符参数，全部回拼。
- 回拼一律使用 `operators[].raw`，保持大小写、路径后缀与出现顺序。操作符组合后查询为空时退回原始 `request.query`，不发送空查询。

## 提取管线

一次 `web_fetch` 的顺序如下。

1. 读取控制快照，建立 `OpContext`（`fetchDeadlineMs` 默认 50 秒），进入 `runOperation`。
2. 地址守卫。默认开启：字面量 IP 直接分类；主机名先解析，任一答案落在回环、私网、链路本地、保留、组播、NAT64、6to4、Teredo 等非公网范围时，返回 `WEB_BLOCKED_URL`，不派发任何第三方引擎。解析失败不拦截。操作取消时停止等待解析。守卫豁免来自 provider 的 `route.staticDomains`（不是 Config 字段）；`blockPrivateAddresses: false` 可整条关闭。
3. 专用 API 面。遍历具备 `aihot-api` 能力的引擎，找到装配层注入的读取器；再检查服务开关、`fetchServices`、熔断与凭证就绪（`ready`）。命中 `https://aihot.news/api/v1/` 下的文档化路径时直接返回 Markdown 或 JSON，优先于 URL 分流；返回 `undefined` 表示不接管，继续通用提取。注意：默认 `fetchServices` 由具备 `fetch` 能力的引擎派生，不包含 `aihot`，bundle 也默认关闭 AIHOT；要让专用 API 生效，需同时启用 AIHOT 并把 `aihot` 加入 `fetchServices`。当前设置页只给具备提取能力的服务提供「参与提取」开关，因此这是一项配置文件级操作。
4. URL 分流。规则按顺序：分流关闭 → 不可解析或非 HTTP(S) → 静态域名或点界子域 → 静态扩展名表 → 其他。装配层没有覆盖分流参数，默认启用、静态域名列表为空。静态扩展名包括 `txt`、`text`、`xml`、`json`、`md`、`markdown`、`csv`、`tsv`、`rss`、`atom`、`yaml`、`yml`、`log`、`ini`、`toml`、`ics`、`vtt`、`srt`。分流只检查 URL，不发起 Content-Type 预探测；两条路径之间不自动回退。
5. 静态路。调用装配层包装的 `HttpFetchProvider`，限制为响应最多 5,000,000 字节、正文最多 100,000 字符、单请求 30 秒、最多 5 次重定向。`serviceEnabled.http` 为 false 时报错。有正文的非 2xx 原样返回；无正文的非 2xx 抛 `WEB_BLOCKED_URL` 并在消息中带目标状态码。
6. 动态路。
   - `single`：按选择顺序取第一个可用引擎，单路 deadline 为 15 秒。失败时默认直接抛错；`singleChannelEscalate: true` 时转多路整理。正文过薄也只在开关打开时升级。成功时原样返回该路结果，不加来源标记，也不受 `maxOutputChars` 约束。
   - `auto`：先探第一路（15 秒硬超时，忽略信号的引擎也会被 `runLane` 丢弃）。探测结果同时满足 2xx、返回目标与请求目标同资源（允许 HTTP→HTTPS 升级且端口/用户信息一致）、不是登录或挑战页、普通段落字符数不少于 400 时，直接返回原文；超过 `maxOutputChars` 时改由整理器按完整内容块省略并标 `truncated`。任一条件不满足则进入多路整理，探测结果作为候选并入，并跳过该引擎避免重复请求。
   - `multi`、`custom`、`free`：直接进入多路整理。
7. 多路整理。选择的引擎需具备 `fetch` 能力、实现 `fetch`、且未熔断；再按预设、`serviceEnabled`、`fetchServices`、`maxFetchServices` 过滤。每路 deadline 默认 45 秒。空正文或纯空白正文判为无效。`auto` 打开提前结算：至少三路返回同标题、共享长段落且各有不少于 1,200 字符的段落正文时，宽限 500–1200 毫秒后取消慢渠道并标记截断。
8. 正文整理。HTML 先转 Markdown，移除明确的导航与页面控件；按标题路径、章节出现次数与共同内容块对齐。同标题且结构完整的提取作为参照，按段落字符数选择，其余补充；跨服务相同内容块去重，不同章节中至少 32 字符的相同块也可合并来源，同一原文内的重复保留。数字或否定词变体保留在「文本差异」；标题、语言、版本、返回目标或段落顺序不一致时保留独立片段。登录与挑战页不进入主正文；只有此类页面时返回 `WEB_PROVIDER_ERROR`。
9. 输出治理。页级默认上限为 15,000 字符（`maxOutputChars`），按完整内容块省略并标注 `truncated`；清单类表格先按 20 行、4,000 字符裁剪并在尾注说明，数据表格、代码围栏与正文段落不裁断。补充片段单条最多 1,200 字符、整节最多 4,000 字符；参照正文达到 1,200 字符时，标题或语言不兼容的提取只记数量。参照正文段落少于 200 字符时尾注给出 `body-thin`。每份输入最多 1,000,000 字符、2,000 个内容块，超限报 `WEB_FETCH_TOO_LARGE`。JSON 对象/数组与识别出的 XML 内容保持原样，超出输出预算时报错。
10. 错误。全败时按「目标被拒绝 `target-rejected`」与「引擎不可用 `engine-unavailable`」分组，取最特异的 `WEB_BLOCKED_URL`、`WEB_INVALID_URL`、`WEB_FETCH_TOO_LARGE`、`WEB_UNSUPPORTED_CONTENT_TYPE`、`WEB_FETCH_TIMEOUT`，否则 `WEB_PROVIDER_ERROR`。目标站非 2xx 可随有效正文返回：Firecrawl 透传 `metadata.statusCode`；Tavily 不回报真实状态码，`failed_results` 用 400 作为目标级占位；AnySearch 的 `extract_target_blocked` 是目标级失败，而 HTTP 422 虽在适配层标为 `target-status`，fetch 层会把它映射为 `WEB_PROVIDER_ERROR` 并归入 `engine-unavailable`，不进入 `target-rejected` 组。调用方取消使用 `WEB_ABORTED`。

`select-best.ts` 的打分函数保留，但 v0.3 的提取主线只做 `organize` 整理，装配层没有 `engineWeights` 注入点，也没有 `select` 模式。

## 熔断与预算

搜索与提取共用一个 `CircuitBreaker` 实例，键为引擎 id；状态不跨进程、不持久化。熔断器是纯状态机，没有定时器，恢复在下一次状态读取时惰性结算。

| 信号 | 行为 |
| --- | --- |
| `rate-limited` | 使用 `Retry-After` 或默认 60 秒冷却；同一引擎连续冷却按 `hint × 2^(streak-1)` 退避，上限 1 小时；`retryAfterMs <= 0` 清除冷却。 |
| `quota` 且 `statusCode === 402` | `insufficient-credits`，暂停到宿主时区次日零点。 |
| 其他 `quota` | `quota-exhausted`，暂停到宿主时区次日零点。 |

`breakerSignalOf` 只把 `rate-limited` 与 `quota` 映射为熔断输入。`timeout`、`network`、`provider-error` 虽然失败模型上可能标为 `cooldownable`，当前不会触发熔断；`auth`、`target-status`、`invalid`、`aborted` 也不是引擎健康信号。

预算与时间：

| 项 | 默认值 | 说明 |
| --- | --- | --- |
| 每次操作请求上限 | 32 | `maxRequests`；每个插件拥有的 HTTP 请求在写出前调用 `countRequest()`，额度查询与重排也计入。预算耗尽时记说明并让请求失败。 |
| 搜索操作总限时 | 15 秒 | `searchDeadlineMs`；到点取消未完成路，返回已完成结果并标 `truncated`；无结果才 `WEB_SEARCH_TIMEOUT`。 |
| 搜索单路 deadline | 10 秒 | `DEFAULT_SEARCH_MAX_FANOUT_MS`。 |
| 提取操作总限时 | 50 秒 | `fetchDeadlineMs`。 |
| 提取单路 deadline | 45 秒 | `DEFAULT_FETCH_ENGINE_TIMEOUT_MS`。 |
| 首路探测 / 单通道路 deadline | 15 秒 | `DEFAULT_PROBE_TIMEOUT_MS`。 |
| 额度日检单路 deadline | 10 秒 | 额度查询失败只记日志。 |
| 重排 deadline | 5 秒 | 失败 fail-open。 |
| 宽限窗口 | 500–1200 毫秒 | 结果充分后等待补充，随后取消慢渠道。 |

调用方取消优先于总限时：调用方取消始终返回 `WEB_ABORTED`；总限时到只返回已完成结果并标截断。插件发起的引擎 API 请求固定 `redirect: 'error'`；静态 HTTP 路径沿用宿主策略。单请求超时取「30 秒」与「操作剩余 deadline」的较小者。

## 凭证与设置

配置只持有凭证引用名，实际值由 `ctx.credentials.resolve()` 按操作解析，轮换在下一次调用生效。`Config` 的 schema 是根级 volatile：`~standard.validate()` 返回 `Volatile<Config>` 实时引用，装配层只保留引用，每次操作读取一次 `config.get()` 快照；设置页保存后下一次操作生效，不重挂插件。凭证引用、端点覆盖与重排开关按操作读取并在同一 `OpContext` 的并发 lane 间共享快照（`CONFIG_SNAPSHOTS`）；`controls` 在操作入口读取一次；区域与垂直目录在请求/发现时求值。Config 的全部字段如下，均来自 `src/index.ts` 的 schemastery schema。

| 字段 | 类型与范围 | 默认值 | 说明 |
| --- | --- | --- | --- |
| `controls.serviceEnabled` | `dict(boolean)` | 由 registry 派生 | 服务总开关；未写的服务取 registry 的 `enabledByDefault`（`zhihu`、`aihot` 默认关，其余引擎默认开，`http` 恒开），显式写入覆盖默认值。关闭后搜索与动态提取在派发前过滤，静态 HTTP 路径与专用 API 读取也检查。 |
| `controls.preset` | `auto` / `single` / `multi` / `custom` / `free` | `auto` | 调用范围。 |
| `controls.searchServices` | `string[]` | `anysearch`、`tavily`、`firecrawl`、`zhihu`、`aihot` | 搜索服务 ID 与调用优先级；数组顺序参与选择排序。 |
| `controls.fetchServices` | `string[]` | `anysearch`、`tavily`、`firecrawl`、`zhihu` | 提取服务 ID 与调用优先级；HTTP 静态路径不受此列表控制。 |
| `controls.maxSearchServices` | natural，1–5 | `5` | 每个查询最多调用的搜索服务数。 |
| `controls.maxFetchServices` | natural，1–4 | `4` | 每个 URL 最多调用的提取服务数。 |
| `controls.maxRequests` | natural，1–256 | `32` | 每次操作的插件 HTTP 请求上限，含额度查询与重试。 |
| `controls.searchDeadlineMs` | natural，1–3,600,000 | `15000` | 搜索操作总限时。 |
| `controls.fetchDeadlineMs` | natural，1–3,600,000 | `50000` | 提取操作总限时。 |
| `controls.maxOutputChars` | natural，1,000–1,000,000 | `15000` | 搜索与单页整理输出上限；搜索按 title+snippet 估算并从尾部裁剪来源，整理按完整内容块保留并含来源与差异说明。 |
| `rerank.enabled` | boolean | `true` | SiliconFlow 重排开关；未配置密钥时自动不启用。 |
| `rerank.apiKeyEnv` | credential-ref | `SILICONFLOW_API_KEY` | SiliconFlow 密钥引用。 |
| `anysearchApiKeyEnv` | credential-ref | `ANYSEARCH_API_KEY` | AnySearch 密钥引用；为空或未配置时走匿名。 |
| `anysearchBaseURL` | string，可选 | 无 | AnySearch 端点覆盖。 |
| `anysearchZone` | `'cn'` / `'intl'` / `''`，可选 | 无 | AnySearch 搜索区域；空串与未设置等价，均不发送 `zone`。 |
| `tavilyApiKeyEnv` | credential-ref | `TAVILY_API_KEY` | Tavily 密钥引用；为空或未配置时走 keyless。 |
| `firecrawlApiKeyEnv` | credential-ref | `FIRECRAWL_API_KEY` | Firecrawl 密钥引用；未配置时官方端点的提取面（`/v2/scrape`）走 keyless free tier，搜索面与自定义端点仍需密钥。 |
| `firecrawlBaseURL` | string，可选 | 无 | Firecrawl 端点覆盖；适配器按操作拼接已知路径。 |
| `zhihuApiKeyEnv` | credential-ref | `ZHIHU_API_KEY` | 知乎 Access Secret 引用。 |

Config 没有 `fetch.*` 命名空间：首路探测超时、静态域名、地址守卫开关与 `singleChannelEscalate` 目前是 provider 构造选项，装配层使用默认值，不通过 Config 暴露。

设置卡片使用配置命名空间 `web-search-fetch`，覆盖 5 个引擎加直接 HTTP 共 6 个服务行、5 个凭证位（四个引擎凭证加 SiliconFlow）、5 个预设、调用限制字段、`anysearchBaseURL` / `firecrawlBaseURL` 与重排开关。保存只提交发生变化的路径；空白密钥草稿不写入，已有密钥不会被清空；凭证状态只读取「已配置/未配置」，不回显值。保存后下一次操作读取新快照，无需重启或重挂插件；`whileServed` 门控的 tab/bundle 在 volatile 投影可用时渲染，`settings.section` 只作不可投影宿主的兜底，投影触发后释放，避免重复入口。设置卡「额度」小节逐引擎展示官方额度与本地计数，并提供「刷新额度」手动探测；面板不自动轮询。

## 扩展指南

新增一个搜索/提取引擎时，按以下位置改动。编排层不需要改，这是 AD2 的直接结果。

1. `src/engines/registry.ts`：新增 `X_MANIFEST`，声明 `id`、`label`、`capabilities`、`auth`、`credentialPath`、`free`、`enabledByDefault` 与 `endpoints`；把 manifest 加入 `ENGINE_MANIFESTS`，并在 `EngineRegistryDeps` 与 `buildEngines` 中加上适配器依赖。
2. `src/engines/X.ts`：实现 `createXEngine(options)`，返回 `Engine`。`search` 返回 `EngineResult<EngineSearchOutcome>`，`fetch` 返回 `EngineResult<EngineFetchOutcome>`，有额度端点时实现 `quota`。所有异常在引擎边界收敛为 `EngineFailure`，不向上抛；HTTP 走 `engineFetch` / `engineJson`，失败用 `projectHttpError` 投影。
3. `src/index.ts`：在 `engineCredentials` 中加入凭证引用与可选 base URL；在 Config schema 中加 credential-ref 字段；在 `buildEngines({...})` 中传入适配器。端点覆盖通过 `EngineContext.endpoint` 的 `face` 选择 search/fetch/quota 端点。
4. `client/index.js`：客户端不能 import 宿主模块，需要在 `SERVICES`、`CREDENTIAL_SLOTS`、`OPTION_FIELDS`（如有端点覆盖）和 zh/en 字典中同步；`NUMBER_CONTROLS` 的上限若依赖能力数量也要更新。`test/client-surface.test.ts` 会把服务表、凭证位、free 名单与 registry 对齐。
5. 测试：新增引擎适配的离线替身测试，覆盖成功映射、非 2xx 分类、截断与额度；若新增引擎 id，`test/architecture.test.ts` 的 `ENGINE_IDS` 也要同步。
6. `cordis.patch.yml`：发行配置中显式写出的开关覆盖 registry 默认值；新引擎的默认开关由 manifest 的 `enabledByDefault` 决定，无需在此重复。

新增一种能力（例如新的专用 API 读取器）时，provider 侧通过能力位与注入的读取器识别，不在编排层写具体引擎 id。新增设置字段需要同步 Config schema、客户端表单与客户端表面测试。

## 验证与已知边界

离线验证：

- `pnpm test`：v0.4 开发线新增路由、垂直、热榜、直答、缓存与额度账本测试；测试文件数与通过项数以 README「项目定位与证据」表的现行门禁口径为准，各版本历史基线见 `docs/verification/` 下对应验收记录。测试使用注入的 fetch 替身、固定夹具与本地替身服务，不触网。
- `test/architecture.test.ts`：R7 架构不变量。
- `pnpm run check:repository`：Markdown 链接、标题层级、公开源码路径与包入口。
- `pnpm run check:distribution`：`lib/` 构建产物与 `package.json` 入口齐备；必需文件清单以脚本实际输出为准。
- `pnpm run build`、`pnpm run typecheck` 属于提交前门禁。

真实调用证据：

- 搜索与提取探针结果见 [0.3.0 验收记录](./docs/verification/v0.3.0-acceptance-20261107.md)（2026-11-07，`scripts/live-probe.mjs --live`）。
- 额度实测见 [0.4.3 验收记录](./docs/verification/v0.4.3-acceptance-20261108.md)（2026-11-08 真机）。

未完成或未验证的部分：

- 额度面板的离线渲染、通道隔离与真机全流程见 [v0.4.3 验收记录](./docs/verification/v0.4.3-acceptance-20261108.md)；设置入口以 `whileServed` 的 tab/bundle 为主，`settings.section` 在投影触发后释放，避免重复入口。v0.4.4 的实时配置与真机保存验收见 [v0.4.4 验收记录](./docs/verification/v0.4.4-live-config-20261109.md)。
- v0.4 的缓存绕过只识别查询词（最新/今天/刚刚/实时）与 `after:`/`before:`；seam 没有显式 force-fresh 字段。
- `upstreamGroup` 同源去重已接线，但当前 registry 全部留空，尚无实际分组；垂直 `params` 首版只校验必填、不做精确抽取。
- 知乎热榜/直答额度未被 `quota()` 覆盖：热榜走独立 lane，结局进入本地账本估算；直答不单独入账，随知乎搜索 lane 记录；额度与限流以服务方账户为准。
- AD4 的结构化操作状态、AD7 的 URL 工具完全合并、AD14 的 `summary` 合并尚未落地。
- 本地测试不证明外部账户权限、当前响应质量或真实界面效果。
- 开发命令与提交约定见[贡献指南](./CONTRIBUTING.md)；配置字段与设置页细节见[配置参考](./docs/configuration.md)；正文整理规则见[网页正文整理](./docs/content-organization.md)；请求与日志边界见[安全说明](./SECURITY.md)。

## 相关文档

- [配置参考](./docs/configuration.md)
- [ADR-0001：按查询意图路由搜索源的三段式架构](./docs/adr/0001-intent-routing.md)
- [网页正文整理](./docs/content-organization.md)
- [AIHOT 使用说明](./docs/aihot.md)
- [故障排查](./docs/troubleshooting.md)
- [安全说明](./SECURITY.md)
- [贡献指南](./CONTRIBUTING.md)
- [0.4.4 验收记录](./docs/verification/v0.4.4-live-config-20261109.md)
- [0.4.3 验收记录](./docs/verification/v0.4.3-acceptance-20261108.md)
- [0.4.2 验收记录](./docs/verification/v0.4.2-acceptance-20261108.md)
- [0.4.0 验收记录](./docs/verification/v0.4.0-acceptance-20261108.md)
- [0.3.0 验收记录](./docs/verification/v0.3.0-acceptance-20261107.md)
- [0.2.20 验收记录](./docs/verification/v0.2.20-acceptance-20261017.md)
