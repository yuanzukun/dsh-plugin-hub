import { describe, expect, it } from 'vitest'
import { validateDocumentCommands, validateNote, validatePublicSourceProvenance, validateScriptProvenance, validateSkill } from '../scripts/check-docs.mjs'

const implementedNote = `# Agent Note: Example

Status: implemented

## Problem

Problem.

## Decision

Decision.

## Alternatives considered

Alternative.

## Consequences

Consequence.
`

describe('validateNote', () => {
  it('accepts an implemented process note', () => {
    expect(validateNote(implementedNote, '.agents/notes/implemented/process/2026-01-01-example.md')).toEqual([])
  })

  it('requires lifecycle headings and status agreement', () => {
    const errors = validateNote(implementedNote, '.agents/notes/proposed/process/2026-01-01-example.md')
    expect(errors).toContain('.agents/notes/proposed/process/2026-01-01-example.md: Status does not match lifecycle')
    expect(errors).toContain('.agents/notes/proposed/process/2026-01-01-example.md: missing ## Proposal')
    expect(errors).toContain('.agents/notes/proposed/process/2026-01-01-example.md: missing ## Acceptance criteria')
  })

  it('rejects proposal residue in implemented notes', () => {
    const text = implementedNote.replace('## Decision', '## Decision\n\n## Proposal')
    const errors = validateNote(text, '.agents/notes/implemented/process/2026-01-01-example.md')
    expect(errors).toContain('.agents/notes/implemented/process/2026-01-01-example.md: implemented note contains ## Proposal')
  })

  it('rejects invalid note dates and heading order', () => {
    const invalidDate = implementedNote.replace('Decision.', 'Decision.')
    const errors = validateNote(invalidDate, '.agents/notes/implemented/process/2026-99-01-example.md')
    expect(errors).toContain('.agents/notes/implemented/process/2026-99-01-example.md: filename must be yyyy-mm-dd-topic.md')

    const reordered = implementedNote.replace('## Decision\n\nDecision.\n\n', 'Decision.\n\n')
      .replace('## Consequences', '## Decision\n\n## Consequences')
    const orderErrors = validateNote(reordered, '.agents/notes/implemented/process/2026-01-01-example.md')
    expect(orderErrors).toContain('.agents/notes/implemented/process/2026-01-01-example.md: lifecycle headings are missing or out of order')
  })
})

describe('validateSkill', () => {
  it('requires folder-matching metadata and a useful description', () => {
    const text = `---\nname: wrong\ndescription: short\n---\n\n# Wrong\n`
    const errors = validateSkill(text, '.agents/skills/example/SKILL.md')
    expect(errors).toContain('.agents/skills/example/SKILL.md: name must equal folder name')
    expect(errors).toContain('.agents/skills/example/SKILL.md: description must be 20-500 characters')
  })
})

describe('validatePublicSourceProvenance', () => {
  it('rejects ignored scratch citations in current source', () => {
    const pollutedSource = ` // source: ${['.scratch', 'evidence.json'].join('/')}\n`
    const errors = validatePublicSourceProvenance(pollutedSource, 'src/example.ts')
    expect(errors).toContain('src/example.ts: current source must cite a tracked owner, not untracked process provenance')
  })

  it('rejects release-history narration in current source', () => {
    const historicalNarrative = `// v${'0.2'} behavior\n`
    const errors = validatePublicSourceProvenance(historicalNarrative, 'src/example.ts')
    expect(errors).toContain('src/example.ts: current source must cite a tracked owner, not untracked process provenance')
  })

  it('allows frozen verification evidence and operational scripts', () => {
    const source = `source: ${['.scratch', 'evidence.json'].join('/')}`
    expect(validatePublicSourceProvenance(source, 'docs/verification/example.md')).toEqual([])
    expect(validatePublicSourceProvenance(source, 'scripts/example.mjs')).toEqual([])
  })
})

describe('validateDocumentCommands', () => {
  it('requires documented pnpm scripts to exist', () => {
    const errors = validateDocumentCommands('pnpm run missing', 'docs/example.md', new Set(['check']))
    expect(errors).toContain('docs/example.md: unknown package script missing')
  })
})

describe('validateScriptProvenance', () => {
  it('rejects version-history narration in script comments', () => {
    const historicalScriptComment = `// v${'0.4'} behavior\n`
    const errors = validateScriptProvenance(historicalScriptComment, 'scripts/example.mjs')
    expect(errors).toContain('scripts/example.mjs: script comments must state current behavior, not process history')
  })
})
