import { describe, expect, it } from 'vitest'
import {
  validateAdr,
  validateDocBudget,
  validateDocCharBudget,
  validateDocumentCommands,
  validateFoundationOwner,
  validateNote,
  validateParagraphWrap,
  validatePublicSourceProvenance,
  validateScriptProvenance,
  validateSkill,
} from '../scripts/check-docs.mjs'

const implementedNote = `# Agent Note: Example

Status: implemented

## Problem

Problem.

## Decision

Decision.

## Alternatives considered

Alternative.

## Consequences

Consequence.
`

describe('validateNote', () => {
  it('accepts an implemented process note', () => {
    expect(validateNote(implementedNote, '.agents/notes/implemented/process/2026-01-01-example.md')).toEqual([])
  })

  it('requires lifecycle headings and status agreement', () => {
    const errors = validateNote(implementedNote, '.agents/notes/proposed/process/2026-01-01-example.md')
    expect(errors).toContain('.agents/notes/proposed/process/2026-01-01-example.md: Status does not match lifecycle')
    expect(errors).toContain('.agents/notes/proposed/process/2026-01-01-example.md: missing ## Proposal')
    expect(errors).toContain('.agents/notes/proposed/process/2026-01-01-example.md: missing ## Acceptance criteria')
  })

  it('rejects proposal residue in implemented notes', () => {
    const text = implementedNote.replace('## Decision', '## Decision\n\n## Proposal')
    const errors = validateNote(text, '.agents/notes/implemented/process/2026-01-01-example.md')
    expect(errors).toContain('.agents/notes/implemented/process/2026-01-01-example.md: implemented note contains ## Proposal')
  })

  it('rejects invalid note dates and heading order', () => {
    const errors = validateNote(implementedNote, '.agents/notes/implemented/process/2026-99-01-example.md')
    expect(errors).toContain('.agents/notes/implemented/process/2026-99-01-example.md: filename must be yyyy-mm-dd-topic.md')

    const reordered = implementedNote.replace('## Decision\n\nDecision.\n\n', 'Decision.\n\n')
      .replace('## Consequences', '## Decision\n\n## Consequences')
    const orderErrors = validateNote(reordered, '.agents/notes/implemented/process/2026-01-01-example.md')
    expect(orderErrors).toContain('.agents/notes/implemented/process/2026-01-01-example.md: lifecycle headings are missing or out of order')
  })

  it('requires fixed blank lines, a unique Status and Problem first', () => {
    const spacing = implementedNote.replace('# Agent Note: Example\n\n', '# Agent Note: Example\n')
    const spacingErrors = validateNote(spacing, '.agents/notes/implemented/process/2026-01-01-example.md')
    expect(spacingErrors).toContain('.agents/notes/implemented/process/2026-01-01-example.md: line 2 must be blank')

    const duplicate = implementedNote.replace('Status: implemented\n', 'Status: implemented\nStatus: implemented\n')
    const duplicateErrors = validateNote(duplicate, '.agents/notes/implemented/process/2026-01-01-example.md')
    expect(duplicateErrors).toContain('.agents/notes/implemented/process/2026-01-01-example.md: the Status line must be unique')

    const wrongFirst = implementedNote.replace('## Problem', '## Context')
    const firstErrors = validateNote(wrongFirst, '.agents/notes/implemented/process/2026-01-01-example.md')
    expect(firstErrors).toContain('.agents/notes/implemented/process/2026-01-01-example.md: the first section must be \'## Problem\'')
  })
})

describe('validateSkill', () => {
  it('requires folder-matching metadata and a useful description', () => {
    const text = `---\nname: wrong\ndescription: short\n---\n\n# Wrong\n`
    const errors = validateSkill(text, '.agents/skills/example/SKILL.md')
    expect(errors).toContain('.agents/skills/example/SKILL.md: name must equal folder name')
    expect(errors).toContain('.agents/skills/example/SKILL.md: description must be 20-500 characters')
  })
})

describe('validatePublicSourceProvenance', () => {
  it('rejects ignored scratch citations in current source', () => {
    const pollutedSource = ` // source: ${['.scratch', 'evidence.json'].join('/')}\n`
    const errors = validatePublicSourceProvenance(pollutedSource, 'src/example.ts')
    expect(errors).toContain('src/example.ts: current source must cite a tracked owner, not untracked process provenance')
  })

  it('rejects release-history narration in current source', () => {
    const historicalNarrative = `// v${'0.2'} behavior\n`
    const errors = validatePublicSourceProvenance(historicalNarrative, 'src/example.ts')
    expect(errors).toContain('src/example.ts: current source must cite a tracked owner, not untracked process provenance')
  })

  it('allows frozen verification evidence and operational scripts', () => {
    const source = `source: ${['.scratch', 'evidence.json'].join('/')}`
    expect(validatePublicSourceProvenance(source, 'docs/verification/example.md')).toEqual([])
    expect(validatePublicSourceProvenance(source, 'scripts/example.mjs')).toEqual([])
  })
})

describe('validateDocumentCommands', () => {
  it('requires documented pnpm scripts to exist', () => {
    const errors = validateDocumentCommands('pnpm run missing', 'docs/example.md', new Set(['check']))
    expect(errors).toContain('docs/example.md: unknown package script missing')
  })
})

describe('validateScriptProvenance', () => {
  it('rejects version-history narration in script comments', () => {
    const historicalScriptComment = `// v${'0.4'} behavior\n`
    const errors = validateScriptProvenance(historicalScriptComment, 'scripts/example.mjs')
    expect(errors).toContain('scripts/example.mjs: script comments must state current behavior, not process history')
  })
})

describe('validateFoundationOwner', () => {
  it('requires owner documents to link the foundation contract', () => {
    expect(validateFoundationOwner('[foundation](foundation.md)', 'docs/README.md')).toEqual([])
    expect(validateFoundationOwner('[foundation](docs/foundation.md)', 'AGENTS.md')).toEqual([])
    expect(validateFoundationOwner('No link', 'AGENTS.md')).toContain('AGENTS.md: must link docs/foundation.md')
  })
})

describe('validateAdr', () => {
  it('requires a numbered heading, status line and target owner', () => {
    expect(validateAdr('# ADR-0004：Example\n\n状态：已接受（已实施），2026-01-01。\n', 'docs/adr/0004-example.md')).toEqual([])
    expect(validateAdr('# ADR-0004：Example\n\n状态：已接受（目标），2026-01-01。\n', 'docs/adr/0004-example.md'))
      .toContain('docs/adr/0004-example.md: target ADR must link the current-behavior owner')
    expect(validateAdr('# ADR-0004：Example\n\n状态：已接受（目标），2026-01-01。\n\n[owner](../foundation.md)\n', 'docs/adr/0004-example.md')).toEqual([])
    expect(validateAdr('# ADR-0005：Example\n\n状态：已接受\n', 'docs/adr/0004-example.md'))
      .toContain('docs/adr/0004-example.md: first line must be \'# ADR-0004：<title>\'')
    expect(validateAdr('# ADR-0004：Example\n\n', 'docs/adr/0004-example.md'))
      .toContain('docs/adr/0004-example.md: line 3 must start with \'已接受（已实施）\' or \'已接受（目标）\'')
  })
})

describe('validateDocBudget', () => {
  it('rejects a document over its line ceiling', () => {
    expect(validateDocBudget('a\nb\n', 'docs/example.md', 2)).toEqual([])
    expect(validateDocBudget('a\nb\nc\n', 'docs/example.md', 2))
      .toContain('docs/example.md: exceeds 2 lines (3)')
  })

  it('rejects a document over its non-whitespace character ceiling', () => {
    expect(validateDocCharBudget('a b\n', 'docs/example.md', 2)).toEqual([])
    expect(validateDocCharBudget('abcd', 'docs/example.md', 2))
      .toContain('docs/example.md: exceeds 2 non-whitespace characters (4)')
  })
})

describe('validateParagraphWrap', () => {
  it('accepts one-line paragraphs and structural lines', () => {
    const text = '# Heading\n\nParagraph.\n\n- one\n- two\n\n| a | b |\n| --- | --- |\n\n```ts\nconst a = 1\n```\n'
    expect(validateParagraphWrap(text, 'docs/example.md')).toEqual([])
  })

  it('rejects a paragraph split across physical lines', () => {
    expect(validateParagraphWrap('Paragraph.\ncontinued.\n', 'docs/example.md'))
      .toContain('docs/example.md:1: paragraph continues on a second physical line')
  })

  it('rejects a wrapped paragraph inside a list item', () => {
    expect(validateParagraphWrap('- first line\n  continuation\n', 'docs/example.md'))
      .toContain('docs/example.md:1: paragraph continues on a second physical line')
  })
})
