import { describe, expect, it } from 'vitest'
import {
  buildEngineCatalog,
  GENERATED_END,
  GENERATED_START,
  renderCatalog,
  renderClientSurface,
  replaceGeneratedRegion,
} from '../scripts/engine-catalog.mjs'

const manifests = [
  {
    id: 'alpha',
    label: 'Alpha',
    summary: 'Alpha summary.',
    capabilities: ['search', 'fetch'],
    auth: 'keyless-fallback',
    credentialPath: 'alpha',
    free: true,
    keyless: true,
    enabledByDefault: true,
    quotaPeriod: 'monthly',
    endpoints: {
      search: 'https://alpha.test/search',
      fetch: 'https://alpha.test/fetch',
      quota: 'https://alpha.test/quota',
    },
  },
  {
    id: 'beta',
    label: 'Beta',
    summary: 'Beta summary.',
    capabilities: ['search', 'aihot-api'],
    auth: 'anonymous',
    free: true,
    keyless: true,
    enabledByDefault: false,
    quotaPeriod: 'none',
    endpoints: { search: 'https://beta.test/items' },
  },
]

const catalog = buildEngineCatalog(manifests, { model: 'test-model' })

describe('buildEngineCatalog', () => {
  it('projects registry order, capabilities and synthetic HTTP service', () => {
    expect(catalog.services.map(service => service.id)).toEqual(['alpha', 'beta', 'http'])
    expect(catalog.services[0]).toMatchObject({
      capability: 'searchFetch',
      keys: ['alpha'],
      free: true,
      keyless: true,
      auth: 'keyless-fallback',
      enabledByDefault: true,
    })
    expect(catalog.services[1].capability).toBe('aiNews')
    expect(catalog.services[2]).toMatchObject({ capability: 'staticFetch', capabilities: ['fetch'] })
  })

  it('derives anonymous, quota and official-endpoint sets', () => {
    expect(catalog.anonymousServiceIds).toEqual(['alpha'])
    expect(catalog.quotaPeriods).toEqual({ alpha: 'monthly', beta: 'none' })
    expect(catalog.quotaOfficialIds).toEqual(['alpha'])
  })

  it('rejects a manifest without a supported capability', () => {
    expect(() => buildEngineCatalog([{ ...manifests[0], capabilities: [] }], { model: 'x' }))
      .toThrow('engine alpha has no supported capability')
  })
})

describe('renderClientSurface', () => {
  it('wraps the generated constants in replaceable markers', () => {
    const block = renderClientSurface(catalog)
    expect(block.startsWith(GENERATED_START)).toBe(true)
    expect(block.endsWith(GENERATED_END)).toBe(true)
    expect(block).toContain('const RERANK_MODEL = "test-model";')
    expect(block).toContain('"id": "http"')
    expect(block).toContain('"id": "beta"')
  })
})

describe('renderCatalog', () => {
  it('renders the registry rows and keeps the rerank model out of the catalog', () => {
    const doc = renderCatalog(catalog)
    expect(doc).toContain('| `alpha` | Alpha | Alpha summary. | 搜索、提取 | 免密钥回退 |')
    expect(doc).toContain('| `beta` | Beta | Beta summary. | 搜索、AIHOT API | 匿名 |')
    expect(doc).toContain('| `alpha` | `https://alpha.test/search` | `https://alpha.test/fetch` | `https://alpha.test/quota` |')
    expect(doc).not.toContain('test-model')
  })
})

describe('replaceGeneratedRegion', () => {
  it('replaces only the marked region', () => {
    const source = `before\n${GENERATED_START}\nold\n${GENERATED_END}\nafter\n`
    const updated = replaceGeneratedRegion(source, renderClientSurface(catalog))
    expect(updated).toContain('before')
    expect(updated).toContain('after')
    expect(updated).not.toContain('old')
    expect(updated).toContain('"id": "http"')
  })

  it('rejects a client without markers', () => {
    expect(() => replaceGeneratedRegion('no markers', 'block'))
      .toThrow('missing generated-engine-surface markers')
  })
})
