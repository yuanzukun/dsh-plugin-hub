import { describe, expect, it } from 'vitest'
import { buildEngineCatalog, renderCatalog } from '../scripts/engine-catalog.mjs'

const manifests = [
  {
    id: 'alpha',
    label: 'Alpha',
    summary: 'Alpha summary.',
    capabilities: ['search', 'fetch'],
    auth: 'keyless-fallback',
    credentialPath: 'alpha',
    free: true,
    keyless: true,
    enabledByDefault: true,
    quotaPeriod: 'monthly',
    endpoints: {
      search: 'https://alpha.test/search',
      fetch: 'https://alpha.test/fetch',
      quota: 'https://alpha.test/quota',
    },
  },
  {
    id: 'beta',
    label: 'Beta',
    summary: 'Beta summary.',
    capabilities: ['search', 'aihot-api'],
    auth: 'anonymous',
    free: true,
    keyless: true,
    enabledByDefault: false,
    quotaPeriod: 'none',
    endpoints: { search: 'https://beta.test/items' },
  },
]

const catalog = buildEngineCatalog(manifests, { model: 'test-model' })

describe('buildEngineCatalog', () => {
  it('keeps registry order and the rerank model', () => {
    expect(catalog.manifests.map(manifest => manifest.id)).toEqual(['alpha', 'beta'])
    expect(catalog.rerankModel).toBe('test-model')
  })
})

describe('renderCatalog', () => {
  it('renders the registry rows and keeps the rerank model out of the catalog', () => {
    const doc = renderCatalog(catalog)
    expect(doc).toContain('| `alpha` | Alpha | Alpha summary. | 搜索、提取 | 免密钥回退 |')
    expect(doc).toContain('| `beta` | Beta | Beta summary. | 搜索、AIHOT API | 匿名 |')
    expect(doc).toContain('| `alpha` | `https://alpha.test/search` | `https://alpha.test/fetch` | `https://alpha.test/quota` |')
    expect(doc).not.toContain('test-model')
  })
})
