import { describe, expect, it } from 'vitest'
import { findPartialStaged } from '../scripts/check-staged-clean.mjs'

describe('staged worktree', () => {
  it('rejects a staged file whose worktree differs from the index', () => {
    expect(findPartialStaged(['docs/a.md', 'src/b.ts'], new Set(['docs/a.md'])))
      .toEqual(['docs/a.md: staged copy differs from the worktree; stage or restore the current content'])
  })

  it('accepts a clean staged snapshot', () => {
    expect(findPartialStaged(['docs/a.md'], new Set())).toEqual([])
  })
})
