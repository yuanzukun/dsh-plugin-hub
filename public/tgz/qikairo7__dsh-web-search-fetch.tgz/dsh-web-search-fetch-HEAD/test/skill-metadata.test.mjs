import { describe, expect, it } from 'vitest'
import { validateSkillInvocationMetadata } from '../scripts/check-skill-metadata.mjs'

describe('skill invocation metadata', () => {
  it('accepts aligned manual/automatic policies', () => {
    expect(validateSkillInvocationMetadata(
      'name: example\ndisable-model-invocation: false\n',
      'policy:\n  allow_implicit_invocation: true\n',
      '.agents/skills/example/SKILL.md',
    )).toEqual([])
  })

  it('rejects a product mismatch', () => {
    expect(validateSkillInvocationMetadata(
      'name: example\ndisable-model-invocation: true\n',
      'policy:\n  allow_implicit_invocation: true\n',
      '.agents/skills/example/SKILL.md',
    )).toContain('.agents/skills/example/SKILL.md: Claude manual-only=true but Codex manual-only=false')
  })
})
