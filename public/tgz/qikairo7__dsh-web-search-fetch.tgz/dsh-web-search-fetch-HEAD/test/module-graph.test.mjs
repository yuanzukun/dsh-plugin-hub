import { describe, expect, it } from 'vitest'
import { resolve } from 'node:path'
import { relativeImports, renderModuleGraph } from '../scripts/module-graph.mjs'

describe('module graph', () => {
  it('collects relative imports', () => {
    expect(relativeImports("import { x } from './a.js'\nimport type { y } from './b.js'\nimport 'z'\n", resolve('/repo/src/b.ts')))
      .toEqual([resolve('/repo/src/a.ts'), resolve('/repo/src/b.ts')])
  })

  it('renders a deterministic mermaid graph', () => {
    expect(renderModuleGraph([{ from: 'src/a', to: 'src/b', count: 2 }]))
      .toContain('N0 -->|2| N1')
  })
})
