import { describe, expect, it } from 'vitest'
import { validatePackageArtifacts } from '../scripts/check-package-artifacts.mjs'

const allowedAssets = ['docs/assets/app.png']

describe('validatePackageArtifacts', () => {
  it('accepts base files, compiled output, docs and allowlisted assets', () => {
    expect(validatePackageArtifacts([
      'package.json',
      'README.md',
      'lib/index.js',
      'lib/index.d.ts',
      'docs/architecture.md',
      'docs/upgrade/example.md',
      'docs/assets/app.png',
    ], allowedAssets)).toEqual([])
  })

  it('rejects unlisted assets, missing allowlisted assets and unexpected files', () => {
    expect(validatePackageArtifacts([
      'docs/assets/old-settings.jpg',
      'client/index.js',
    ], allowedAssets)).toEqual([
      'docs/assets/app.png: allowlisted package asset is missing',
      'docs/assets/old-settings.jpg: package asset is not allowlisted',
      'client/index.js: unexpected package artifact',
    ])
  })
})
