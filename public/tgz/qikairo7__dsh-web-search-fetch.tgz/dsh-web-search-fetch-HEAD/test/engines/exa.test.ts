// Exa Search Lite 引擎离线单测——注入 fetcher 替身，不触网。
// 契约来源：https://exa.ai/docs/reference/search

import { describe, expect, it } from 'vitest'
import type { EngineContext, EngineResult } from '../../src/engines/contract.js'
import type { EngineFailure } from '../../src/engines/failure.js'
import { createExaEngine } from '../../src/engines/exa.js'
import { EXA_MANIFEST } from '../../src/engines/registry.js'
import { parseQuerySyntax } from '../../src/search/query-syntax.js'

const SEARCH_ENDPOINT = EXA_MANIFEST.endpoints.search!
const API_KEY = 'unit-test-key'

interface RecordedRequest {
  readonly url: string
  readonly init: RequestInit
}

function recorder(handler: (call: RecordedRequest) => Response | Promise<Response>) {
  const calls: RecordedRequest[] = []
  const fetcher = (async (input: string | URL | Request, init?: RequestInit) => {
    const call = {
      url: input instanceof Request ? input.url : String(input),
      init: init ?? {},
    }
    calls.push(call)
    return await handler(call)
  }) as typeof fetch
  return { calls, fetcher }
}

function json(body: unknown, status = 200, headers: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json', ...headers },
  })
}

function context(overrides: Partial<EngineContext> = {}): EngineContext {
  return {
    signal: new AbortController().signal,
    deadline: Date.now() + 30_000,
    endpoint: SEARCH_ENDPOINT,
    countRequest: () => true,
    ...overrides,
  }
}

function bodyOf(call: RecordedRequest | undefined): Record<string, unknown> {
  return JSON.parse(String(call?.init.body)) as Record<string, unknown>
}

function headersOf(call: RecordedRequest | undefined): Headers {
  return new Headers(call?.init.headers)
}

function failureOf(result: EngineResult<unknown>): EngineFailure {
  if (result.ok) throw new Error('预期失败，实际成功')
  return result.failure
}

const SEARCH_RESPONSE = {
  requestId: 'req_exa_1',
  results: [
    {
      title: 'React useEffect cleanup guide',
      url: 'https://example.com/react-cleanup',
      publishedDate: '2026-11-10T08:00:00.000Z',
      highlights: [
        'Cooking pasta needs salted water.',
        'React useEffect cleanup returns a function that removes subscriptions.',
      ],
      text: 'React useEffect cleanup documentation.',
    },
  ],
  searchTime: 12,
}

describe('Exa Search Lite 清单与能力', () => {
  it('登记官方端点、必须凭证且默认不参与搜索', () => {
    const engine = createExaEngine()
    expect(engine.manifest).toBe(EXA_MANIFEST)
    expect(engine.manifest).toMatchObject({
      id: 'exa',
      label: 'Exa Search Lite',
      auth: 'key',
      credentialPath: 'exa',
      enabledByDefault: false,
      capabilities: ['search'],
    })
    expect(engine.manifest.endpoints).toEqual({ search: 'https://api.exa.ai/search' })
    expect(engine.search).toBeTypeOf('function')
    expect(engine.fetch).toBeUndefined()
    expect(engine.quota).toBeUndefined()
  })
})

describe('Exa Search Lite 成功映射', () => {
  it('请求 Search Lite 的 highlights 与 text，并映射 URL、标题、摘要、日期', async () => {
    const { fetcher, calls } = recorder(() => json(SEARCH_RESPONSE))
    const result = await createExaEngine({ fetcher }).search!(
      { query: 'React useEffect cleanup', maxResults: 5 },
      context({ apiKey: API_KEY }),
    )

    expect(result).toEqual({
      ok: true,
      outcome: {
        sources: [{
          url: 'https://example.com/react-cleanup',
          title: 'React useEffect cleanup guide',
          snippet: 'React useEffect cleanup returns a function that removes subscriptions.',
          summary: 'React useEffect cleanup returns a function that removes subscriptions.',
          publishedAt: '2026-11-10T08:00:00.000Z',
        }],
        truncated: false,
      },
    })
    expect(calls).toHaveLength(1)
    expect(calls[0]!.url).toBe(SEARCH_ENDPOINT)
    expect(calls[0]!.init.method).toBe('POST')
    expect(headersOf(calls[0]).get('x-api-key')).toBe(API_KEY)
    expect(bodyOf(calls[0])).toEqual({
      type: 'lite',
      query: 'React useEffect cleanup',
      numResults: 5,
      contents: {
        highlights: { query: 'React useEffect cleanup' },
        text: { maxCharacters: 10_000 },
      },
    })
  })

  it('摘要优先选与查询最相关的高亮，并分别裁剪到 800 和 500 字符', async () => {
    const relevant = `React cleanup ${'x'.repeat(900)}`
    const { fetcher } = recorder(() => json({
      requestId: 'req_exa_clip',
      results: [{
        title: 'Long result',
        url: 'https://example.com/long',
        highlights: ['Unrelated cooking note', relevant],
      }],
    }))
    const result = await createExaEngine({ fetcher }).search!(
      { query: 'React cleanup', maxResults: 1 },
      context({ apiKey: API_KEY }),
    )

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.outcome.sources[0]!.summary).toBe(relevant.slice(0, 800))
    expect(result.outcome.sources[0]!.snippet).toBe(relevant.slice(0, 500))
  })

  it('没有高亮时从正文中选择包含查询词的片段', async () => {
    const prefix = 'This introduction does not answer the question. '.repeat(20)
    const relevant = 'Use the useEffect cleanup function to remove subscriptions.'
    const suffix = ' Additional background follows.'.repeat(20)
    const { fetcher } = recorder(() => json({
      requestId: 'req_exa_text',
      results: [{
        title: 'Cleanup',
        url: 'https://example.com/text',
        text: `${prefix}${relevant}${suffix}`,
      }],
    }))
    const result = await createExaEngine({ fetcher }).search!(
      { query: 'cleanup function', maxResults: 1 },
      context({ apiKey: API_KEY }),
    )

    expect(result.ok).toBe(true)
    if (!result.ok) return
    const source = result.outcome.sources[0]!
    expect(source.summary).toContain(relevant)
    expect(source.summary).not.toBe(`${prefix}${relevant}${suffix}`.slice(0, 800))
    expect(source.summary!.length).toBeLessThanOrEqual(800)
    expect(source.snippet!.length).toBeLessThanOrEqual(500)
  })

  it('高亮均不含查询词时回退到正文中的相关片段', async () => {
    const relevant = 'The cleanup function removes subscriptions before the next render.'
    const { fetcher } = recorder(() => json({
      requestId: 'req_exa_fallback',
      results: [{
        title: 'Cleanup',
        url: 'https://example.com/fallback',
        highlights: ['Cooking pasta needs salted water.'],
        text: `Background. ${relevant}`,
      }],
    }))
    const result = await createExaEngine({ fetcher }).search!(
      { query: 'cleanup function', maxResults: 1 },
      context({ apiKey: API_KEY }),
    )

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.outcome.sources[0]!.summary).toContain(relevant)
    expect(result.outcome.sources[0]!.summary).not.toContain('Cooking pasta')
  })

  it('高亮和正文都不含查询词时省略摘要', async () => {
    const { fetcher } = recorder(() => json({
      requestId: 'req_exa_no_summary',
      results: [{
        title: 'Unrelated',
        url: 'https://example.com/unrelated',
        highlights: ['Cooking pasta needs salted water.'],
        text: 'Background only.',
      }],
    }))
    const result = await createExaEngine({ fetcher }).search!(
      { query: 'cleanup function', maxResults: 1 },
      context({ apiKey: API_KEY }),
    )

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.outcome.sources[0]!.summary).toBeUndefined()
    expect(result.outcome.sources[0]!.snippet).toBeUndefined()
  })

  it('site/-site/after/before 使用原生参数，lang 原样回拼', async () => {
    const raw = 'hooks site:react.dev -site:example.com after:2026-01 before:2026-03 lang:en'
    const { fetcher, calls } = recorder(() => json(SEARCH_RESPONSE))
    const result = await createExaEngine({ fetcher }).search!(
      { query: raw, maxResults: 3, syntax: parseQuerySyntax(raw) },
      context({ apiKey: API_KEY }),
    )

    expect(result.ok).toBe(true)
    expect(bodyOf(calls[0])).toEqual({
      type: 'lite',
      query: 'hooks lang:en',
      numResults: 3,
      contents: {
        highlights: { query: 'hooks lang:en' },
        text: { maxCharacters: 10_000 },
      },
      includeDomains: ['react.dev'],
      excludeDomains: ['example.com'],
      startPublishedDate: '2026-01-01T00:00:00.000Z',
      endPublishedDate: '2026-03-01T00:00:00.000Z',
    })
  })

  it('maxResults 超过 100 时请求 100 条并标记截断', async () => {
    const { fetcher, calls } = recorder(() => json({ requestId: 'req_exa_limit', results: [] }))
    const result = await createExaEngine({ fetcher }).search!(
      { query: 'q', maxResults: 150 },
      context({ apiKey: API_KEY }),
    )
    expect(bodyOf(calls[0]).numResults).toBe(100)
    expect(result).toMatchObject({ ok: true, outcome: { sources: [], truncated: true } })
  })
})

describe('Exa Search Lite 失败分类', () => {
  it('缺少凭证 → auth，且不发请求', async () => {
    const { fetcher, calls } = recorder(() => json(SEARCH_RESPONSE))
    const result = await createExaEngine({ fetcher }).search!(
      { query: 'q', maxResults: 5 },
      context(),
    )
    expect(failureOf(result).kind).toBe('auth')
    expect(calls).toHaveLength(0)
  })

  it.each([401, 403] as const)('HTTP %i → auth', async status => {
    const { fetcher } = recorder(() => json({ error: 'Unauthorized', tag: 'UNAUTHORIZED' }, status))
    const result = await createExaEngine({ fetcher }).search!(
      { query: 'q', maxResults: 5 },
      context({ apiKey: API_KEY }),
    )
    expect(failureOf(result)).toMatchObject({ kind: 'auth', statusCode: status })
  })

  it('HTTP 429 → rate-limited 并保留 Retry-After', async () => {
    const { fetcher } = recorder(() => json(
      { error: 'Too many requests', tag: 'RATE_LIMIT_EXCEEDED' },
      429,
      { 'retry-after': '5' },
    ))
    const result = await createExaEngine({ fetcher }).search!(
      { query: 'q', maxResults: 5 },
      context({ apiKey: API_KEY }),
    )
    expect(failureOf(result)).toMatchObject({
      kind: 'rate-limited',
      statusCode: 429,
      retryAfterMs: 5_000,
      cooldownable: true,
    })
  })

  it('HTTP 402 → quota 且标记额度耗尽', async () => {
    const { fetcher } = recorder(() => json(
      { error: 'Insufficient credits', tag: 'INSUFFICIENT_CREDITS' },
      402,
    ))
    const result = await createExaEngine({ fetcher }).search!(
      { query: 'q', maxResults: 5 },
      context({ apiKey: API_KEY }),
    )
    expect(failureOf(result)).toMatchObject({
      kind: 'quota',
      statusCode: 402,
      quotaExhausted: true,
      cooldownable: true,
    })
  })

  it('HTTP 500 → provider-error', async () => {
    const { fetcher } = recorder(() => json({ error: 'Internal error', tag: 'INTERNAL' }, 500))
    const result = await createExaEngine({ fetcher }).search!(
      { query: 'q', maxResults: 5 },
      context({ apiKey: API_KEY }),
    )
    expect(failureOf(result)).toMatchObject({ kind: 'provider-error', statusCode: 500 })
  })

  it('2xx 非 JSON → provider-error（协议错误）', async () => {
    const { fetcher } = recorder(() => new Response('not json', { status: 200 }))
    const result = await createExaEngine({ fetcher }).search!(
      { query: 'q', maxResults: 5 },
      context({ apiKey: API_KEY }),
    )
    expect(failureOf(result)).toMatchObject({ kind: 'provider-error', statusCode: 200 })
  })

  it.each([
    {},
    { results: 'not-an-array' },
  ])('响应结构缺少 results 数组 → provider-error：%j', async body => {
    const { fetcher } = recorder(() => json(body))
    const result = await createExaEngine({ fetcher }).search!(
      { query: 'q', maxResults: 5 },
      context({ apiKey: API_KEY }),
    )
    expect(failureOf(result).kind).toBe('provider-error')
  })

  it('调用方已取消 → aborted', async () => {
    const controller = new AbortController()
    controller.abort()
    const { fetcher } = recorder(() => {
      throw new DOMException('The operation was aborted.', 'AbortError')
    })
    const result = await createExaEngine({ fetcher }).search!(
      { query: 'q', maxResults: 5 },
      context({ apiKey: API_KEY, signal: controller.signal }),
    )
    expect(failureOf(result).kind).toBe('aborted')
  })

  it('操作 deadline 已到 → timeout', async () => {
    const result = await createExaEngine({
      fetcher: (_input, init) => {
        const signal = init?.signal
        if (signal === undefined || signal === null) throw new Error('缺少中止信号')
        if (signal.aborted) return Promise.reject(new DOMException('timed out', 'TimeoutError'))
        return new Promise<Response>((_resolve, reject) => {
          signal.addEventListener('abort', () => reject(new DOMException('timed out', 'TimeoutError')), { once: true })
        })
      },
    }).search!(
      { query: 'q', maxResults: 5 },
      context({ apiKey: API_KEY, deadline: Date.now() - 1 }),
    )
    expect(failureOf(result).kind).toBe('timeout')
  })

  it('请求预算耗尽 → aborted，且不发请求', async () => {
    const { fetcher, calls } = recorder(() => json(SEARCH_RESPONSE))
    const result = await createExaEngine({ fetcher }).search!(
      { query: 'q', maxResults: 5 },
      context({ apiKey: API_KEY, countRequest: () => false }),
    )
    expect(failureOf(result).kind).toBe('aborted')
    expect(calls).toHaveLength(0)
  })
})
