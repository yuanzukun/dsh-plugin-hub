// registry 能力位：免费额度型（free）与免密钥型（keyless）拆成两位；上游分组未实测不填。
import { describe, expect, it } from 'vitest'
import { ENGINE_MANIFESTS } from '../../src/engines/registry.js'

describe('registry 能力位', () => {
  it('免密钥型 = AnySearch/Tavily/Firecrawl/AIHOT；Firecrawl 仅提取面免钥', () => {
    expect(ENGINE_MANIFESTS.filter(manifest => manifest.keyless === true).map(manifest => manifest.id))
      .toEqual(['anysearch', 'tavily', 'firecrawl', 'aihot'])
    const firecrawl = ENGINE_MANIFESTS.find(manifest => manifest.id === 'firecrawl')
    expect(firecrawl?.free).toBe(true)
    expect(firecrawl?.keyless).toBe(true)
    expect(firecrawl?.keylessCapabilities).toEqual(['fetch'])
    expect(firecrawl?.auth).toBe('keyless-fallback')
  })

  it('知乎声明 fetch 能力并登记 question_answers 端点', () => {
    const zhihu = ENGINE_MANIFESTS.find(manifest => manifest.id === 'zhihu')
    expect(zhihu?.capabilities).toEqual(['search', 'fetch'])
    expect(zhihu?.endpoints.fetch).toBe('https://developer.zhihu.com/api/v1/content/question_answers')
  })

  it('上游分组在上游重叠度实测前全部留空', () => {
    expect(ENGINE_MANIFESTS.map(manifest => manifest.upstreamGroup))
      .toEqual([undefined, undefined, undefined, undefined, undefined, undefined])
  })

  it('有官方额度端点的引擎都声明额度周期', () => {
    for (const manifest of ENGINE_MANIFESTS) {
      if (manifest.endpoints.quota === undefined) continue
      expect(manifest.quotaPeriod, `${manifest.id} 缺少 quotaPeriod`).toBeDefined()
      expect(manifest.quotaPeriod).not.toBe('none')
    }
  })

  it('每个引擎都有目录说明', () => {
    for (const manifest of ENGINE_MANIFESTS) {
      expect(manifest.summary?.trim(), `${manifest.id} 缺少 summary`).toBeTruthy()
    }
  })
})
