/**
 * Tavily 引擎离线单测——注入 fetcher 替身，不触网（仓库规则：测试一律替身与夹具）。
 * 夹具形状来源：.scratch/dev-loop/recon/api-contracts/tavily.json
 *   - /search 响应：endpoints[0].response（文档 https://docs.tavily.com/documentation/api-reference/endpoint/search.md）
 *   - /extract 响应：endpoints[1].response（https://docs.tavily.com/documentation/api-reference/endpoint/extract.md）
 *   - /usage 响应：endpoints[2].response（https://docs.tavily.com/documentation/api-reference/endpoint/usage.md）
 * 夹具只使用契约列出的字段，不编造第三方响应形状。
 */
import { describe, expect, it } from 'vitest'
import type { EngineContext } from '../../src/engines/contract.js'
import type { EngineFailureKind } from '../../src/engines/failure.js'
import { TAVILY_MANIFEST } from '../../src/engines/registry.js'
import { createTavilyEngine } from '../../src/engines/tavily.js'
import { parseQuerySyntax } from '../../src/search/query-syntax.js'

// AD1 单一事实源：测试端点和实现一样从 manifest 取，manifest 漂移时测试跟着变。
const ENDPOINTS = {
  search: TAVILY_MANIFEST.endpoints.search!,
  fetch: TAVILY_MANIFEST.endpoints.fetch!,
  quota: TAVILY_MANIFEST.endpoints.quota!,
} as const

/** 账号模式测试 key（与断言里的字面量一致，避免两处漂移）。 */
const API_KEY = 'tvly-test-key'

interface RecordedCall {
  readonly url: string
  readonly init: RequestInit
}

/** 记录每次请求并按 responder 返回；fetcher 替身由此注入，测试不发起真实网络。 */
function recorder(responder: (call: RecordedCall) => Response | Promise<Response>) {
  const calls: RecordedCall[] = []
  const fetcher = (async (input: string | URL | Request, init?: RequestInit) => {
    const call: RecordedCall = {
      url: input instanceof Request ? input.url : String(input),
      init: init ?? {},
    }
    calls.push(call)
    return await responder(call)
  }) as typeof fetch
  return { calls, fetcher }
}

function json(body: unknown, status = 200, headers: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json', ...headers },
  })
}

function context(overrides: Partial<EngineContext> = {}): EngineContext {
  return {
    signal: new AbortController().signal,
    deadline: Date.now() + 30_000,
    countRequest: () => true,
    endpoint: ENDPOINTS.search,
    ...overrides,
  }
}

function headersOf(call: RecordedCall | undefined): Record<string, string> {
  return (call?.init.headers ?? {}) as Record<string, string>
}

/** 契约 /search 响应：results[]{title,url,content,score,id}，score/id 不映射到 seam。 */
const SEARCH_RESPONSE = {
  query: 'tavily api',
  results: [
    { title: 'Tavily 文档', url: 'https://docs.tavily.com/', content: 'Official docs', score: 0.98, id: 'abc123' },
    { title: 'Tavily 搜索', url: 'https://example.com/search', content: 'Search endpoint', score: 0.72 },
  ],
  response_time: 0.42,
  request_id: 'req_search_1',
}

/** 契约 /extract 响应：results[]{url,raw_content,favicon}。 */
const EXTRACT_RESPONSE = {
  results: [{ url: 'https://example.com/a', raw_content: '# Title\n\nBody', favicon: 'https://example.com/favicon.ico' }],
  failed_results: [] as Array<{ url: string; error: string }>,
  response_time: 1.2,
  usage: { credits: 0 },
  request_id: 'req_extract_1',
}

/** 契约 /usage 响应：key{usage,limit,...} + account{current_plan,...}。 */
const USAGE_RESPONSE = {
  key: {
    usage: 12,
    limit: 1000,
    search_usage: 9,
    extract_usage: 3,
    crawl_usage: 0,
    map_usage: 0,
    research_usage: 0,
  },
  account: {
    current_plan: 'Bootstrap',
    plan_usage: 12,
    plan_limit: 15000,
    paygo_usage: 0,
    paygo_limit: 0,
    search_usage: 9,
    extract_usage: 3,
    crawl_usage: 0,
    map_usage: 0,
    research_usage: 0,
  },
}

/** 契约 /usage 双 null：key.limit 与 account.plan_limit 都显式为 null（两处一致才「不限」）。
 *  来源：https://docs.tavily.com/documentation/api-reference/endpoint/usage.md */
const USAGE_DOUBLE_NULL = {
  key: { usage: 3, limit: null },
  account: { current_plan: 'Bootstrap', plan_usage: 3, plan_limit: null },
}

/** 契约 /usage 半缺：key.limit=null、plan_limit 有值，但 plan_usage 缺失（不能用 key.usage 冒充套餐用量）。 */
const USAGE_PLAN_USAGE_MISSING = {
  key: { usage: 3, limit: null },
  account: { current_plan: 'Bootstrap', plan_limit: 15000 },
}

/** 契约 /usage 全缺：key.limit 与 account.plan_limit 都缺失（缺失 ≠ null）。 */
const USAGE_LIMITS_MISSING = {
  key: { usage: 3 },
}

describe('tavily manifest（AD1 单一事实源）', () => {
  it('端点值与官方契约一致', () => {
    expect(TAVILY_MANIFEST.endpoints).toEqual({
      search: 'https://api.tavily.com/search',
      fetch: 'https://api.tavily.com/extract',
      quota: 'https://api.tavily.com/usage',
    })
  })
})

describe('tavily.search 成功映射', () => {
  it('响应逐字段映射为 sources；score/id 不进入 seam', async () => {
    const { fetcher, calls } = recorder(() => json(SEARCH_RESPONSE))
    const engine = createTavilyEngine({ fetcher })
    const result = await engine.search!({ query: 'tavily api', maxResults: 8 }, context())
    expect(result).toEqual({
      ok: true,
      outcome: {
        sources: [
          { url: 'https://docs.tavily.com/', title: 'Tavily 文档', snippet: 'Official docs' },
          { url: 'https://example.com/search', title: 'Tavily 搜索', snippet: 'Search endpoint' },
        ],
        truncated: false,
      },
    })
    expect(calls).toHaveLength(1)
    expect(calls[0]!.url).toBe(ENDPOINTS.search)
    expect(calls[0]!.init.method).toBe('POST')
    expect(JSON.parse(String(calls[0]!.init.body))).toEqual({
      query: 'tavily api',
      max_results: 8,
      search_depth: 'basic',
    })
  })

  it('无 key → keyless 模式请求头，不发送 Authorization', async () => {
    const { fetcher, calls } = recorder(() => json(SEARCH_RESPONSE))
    await createTavilyEngine({ fetcher }).search!({ query: 'q', maxResults: 5 }, context())
    const headers = headersOf(calls[0])
    expect(headers['x-tavily-access-mode']).toBe('keyless')
    expect(headers.authorization).toBeUndefined()
  })

  it('有 key → Authorization: Bearer，账号模式不发送 keyless 头（验收 R6）', async () => {
    const { fetcher, calls } = recorder(() => json(SEARCH_RESPONSE))
    await createTavilyEngine({ fetcher }).search!(
      { query: 'q', maxResults: 5 },
      context({ apiKey: 'tvly-test-key' }),
    )
    const headers = headersOf(calls[0])
    expect(headers.authorization).toBe('Bearer tvly-test-key')
    expect(headers['x-tavily-access-mode']).toBeUndefined()
  })

  it('maxResults 超过 20 → 请求 20 条并置 truncated=true（AD8 引擎侧截断）', async () => {
    const { fetcher, calls } = recorder(() => json(SEARCH_RESPONSE))
    const result = await createTavilyEngine({ fetcher }).search!({ query: 'q', maxResults: 50 }, context())
    expect(JSON.parse(String(calls[0]!.init.body)).max_results).toBe(20)
    expect(result.ok).toBe(true)
    if (result.ok) expect(result.outcome.truncated).toBe(true)
  })

  it('服务器返回条数超过本次请求 → 截到 maxResults 并置 truncated=true', async () => {
    const rows = Array.from({ length: 5 }, (_, index) => ({
      title: `R${index}`,
      url: `https://example.com/${index}`,
      content: `C${index}`,
      score: 1 - index / 10,
    }))
    const { fetcher } = recorder(() => json({ query: 'q', results: rows, response_time: 0.1 }))
    const result = await createTavilyEngine({ fetcher }).search!({ query: 'q', maxResults: 3 }, context())
    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.outcome.sources).toHaveLength(3)
    expect(result.outcome.truncated).toBe(true)
  })

  it('content 超 500 字符截为 snippet；单字段截断不置 truncated', async () => {
    const long = 'x'.repeat(600)
    const { fetcher } = recorder(() => json({
      query: 'q',
      results: [{ title: 'Long', url: 'https://example.com/long', content: long, score: 0.5 }],
      response_time: 0.1,
    }))
    const result = await createTavilyEngine({ fetcher }).search!({ query: 'q', maxResults: 5 }, context())
    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.outcome.sources[0]!.snippet).toBe('x'.repeat(500))
    expect(result.outcome.truncated).toBe(false)
  })

  it('丢弃无绝对 http(s) URL 的结果，空白 title/content 省略可选字段', async () => {
    const { fetcher } = recorder(() => json({
      query: 'q',
      results: [
        { title: 'Ok', url: 'https://ok.test/page', content: '   ' },
        { title: 'Relative', url: '/relative', content: 'x' },
        { title: 'Ftp', url: 'ftp://files.test/a', content: 'x' },
        { title: 'No URL', content: 'x' },
      ],
      response_time: 0.1,
    }))
    const result = await createTavilyEngine({ fetcher }).search!({ query: 'q', maxResults: 10 }, context())
    expect(result).toEqual({
      ok: true,
      outcome: { sources: [{ url: 'https://ok.test/page', title: 'Ok' }], truncated: false },
    })
  })

  it('空 results → 空 sources、truncated=false', async () => {
    const { fetcher } = recorder(() => json({ query: 'q', results: [], response_time: 0.05 }))
    const result = await createTavilyEngine({ fetcher }).search!({ query: 'q', maxResults: 10 }, context())
    expect(result).toEqual({ ok: true, outcome: { sources: [], truncated: false } })
  })

  it('响应缺 results 数组 → provider-error，不是 network', async () => {
    const { fetcher } = recorder(() => json({ query: 'q', response_time: 0.05 }))
    const result = await createTavilyEngine({ fetcher }).search!({ query: 'q', maxResults: 5 }, context())
    expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.failure.kind).toBe('provider-error')
      expect(result.failure.detail).toContain('results')
    }
  })

  it('endpointOverride 只覆盖请求 URL，不改 manifest', async () => {
    const { fetcher, calls } = recorder(() => json(SEARCH_RESPONSE))
    const engine = createTavilyEngine({ fetcher, endpointOverride: 'https://proxy.local/search' })
    await engine.search!({ query: 'q', maxResults: 5 }, context())
    expect(calls[0]!.url).toBe('https://proxy.local/search')
    expect(engine.manifest.endpoints.search).toBe(ENDPOINTS.search)
  })
})

describe('tavily.search 查询语法映射（AD13）', () => {
  /** 与编排器同路径：先解析操作符，再随请求下发 syntax；请求体由 fetcher 替身抓取。 */
  async function bodyOf(rawQuery: string, maxResults = 5): Promise<Record<string, unknown>> {
    const { fetcher, calls } = recorder(() => json(SEARCH_RESPONSE))
    const result = await createTavilyEngine({ fetcher }).search!(
      { query: rawQuery, maxResults, syntax: parseQuerySyntax(rawQuery) },
      context(),
    )
    expect(result.ok).toBe(true)
    expect(calls).toHaveLength(1)
    return JSON.parse(String(calls[0]!.init.body)) as Record<string, unknown>
  }

  it('site: 单域 → include_domains，且 site: 从发出的查询文本移除', async () => {
    expect(await bodyOf('vitest site:github.com')).toEqual({
      query: 'vitest',
      max_results: 5,
      search_depth: 'basic',
      include_domains: ['github.com'],
    })
  })

  it('site: 多域 → include_domains 按出现顺序收集，查询只留其余词', async () => {
    const body = await bodyOf('site:github.com vitest site:docs.github.com')
    expect(body.query).toBe('vitest')
    expect(body.include_domains).toEqual(['github.com', 'docs.github.com'])
  })

  it('include_domains 超过契约上限 300 → invalid，不截断也不发请求', async () => {
    const domains = Array.from({ length: 301 }, (_, index) => `d${index}.test`)
    const { fetcher, calls } = recorder(() => json(SEARCH_RESPONSE))
    const result = await createTavilyEngine({ fetcher }).search!(
      { query: 'q', maxResults: 5, syntax: { operators: [], domains, excludeDomains: [], bareQuery: 'q' } },
      context(),
    )
    expect(calls).toHaveLength(0)
    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.failure.kind).toBe('invalid')
    expect(result.failure.detail).toContain('300')
    expect(result.failure.cooldownable).toBe(false)
  })

  it('include_domains 恰好 300 → 放行并原样发送', async () => {
    const domains = Array.from({ length: 300 }, (_, index) => `d${index}.test`)
    const { fetcher, calls } = recorder(() => json(SEARCH_RESPONSE))
    const result = await createTavilyEngine({ fetcher }).search!(
      { query: 'q', maxResults: 5, syntax: { operators: [], domains, excludeDomains: [], bareQuery: 'q' } },
      context(),
    )
    expect(result.ok).toBe(true)
    const body = JSON.parse(String(calls[0]!.init.body)) as { include_domains: string[] }
    expect(body.include_domains).toEqual(domains)
  })

  it('-site: → exclude_domains，不发送 include_domains', async () => {
    expect(await bodyOf('vitest -site:youtube.com')).toEqual({
      query: 'vitest',
      max_results: 5,
      search_depth: 'basic',
      exclude_domains: ['youtube.com'],
    })
  })

  it('exclude_domains 超过契约上限 150 → invalid，不截断也不发请求', async () => {
    const excludeDomains = Array.from({ length: 151 }, (_, index) => `x${index}.test`)
    const { fetcher, calls } = recorder(() => json(SEARCH_RESPONSE))
    const result = await createTavilyEngine({ fetcher }).search!(
      { query: 'q', maxResults: 5, syntax: { operators: [], domains: [], excludeDomains, bareQuery: 'q' } },
      context(),
    )
    expect(calls).toHaveLength(0)
    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.failure.kind).toBe('invalid')
    expect(result.failure.detail).toContain('150')
    expect(result.failure.cooldownable).toBe(false)
  })

  it('exclude_domains 恰好 150 → 放行并原样发送', async () => {
    const excludeDomains = Array.from({ length: 150 }, (_, index) => `x${index}.test`)
    const { fetcher, calls } = recorder(() => json(SEARCH_RESPONSE))
    const result = await createTavilyEngine({ fetcher }).search!(
      { query: 'q', maxResults: 5, syntax: { operators: [], domains: [], excludeDomains, bareQuery: 'q' } },
      context(),
    )
    expect(result.ok).toBe(true)
    const body = JSON.parse(String(calls[0]!.init.body)) as { exclude_domains: string[] }
    expect(body.exclude_domains).toEqual(excludeDomains)
  })

  it('after:2026 → start_date=2026-01-01', async () => {
    const body = await bodyOf('tavily after:2026')
    expect(body.query).toBe('tavily')
    expect(body.start_date).toBe('2026-01-01')
  })

  it('after:2026-03 → 该月首日；after:2026-03-15 原样', async () => {
    expect((await bodyOf('q after:2026-03')).start_date).toBe('2026-03-01')
    expect((await bodyOf('q after:2026-03-15')).start_date).toBe('2026-03-15')
  })

  it('before:2026-10 → 上月最后一日 2026-09-30（严格早于该月，与 after 含当日对称）', async () => {
    const body = await bodyOf('tavily before:2026-10')
    expect(body.query).toBe('tavily')
    expect(body.end_date).toBe('2026-09-30')
  })

  it('before:2026-01 → 上一年 12-31；before:2025 → 2024-12-31；before:2024-02 → 2024-01-31', async () => {
    expect((await bodyOf('q before:2026-01')).end_date).toBe('2025-12-31')
    expect((await bodyOf('q before:2025')).end_date).toBe('2024-12-31')
    expect((await bodyOf('q before:2024-02')).end_date).toBe('2024-01-31')
  })

  it('lang:zh → language=zh 且 filter_by_language=true（契约要求配合）', async () => {
    const body = await bodyOf('tavily lang:zh')
    expect(body.query).toBe('tavily')
    expect(body.language).toBe('zh')
    expect(body.filter_by_language).toBe(true)
  })

  it('全部操作符组合 → query 仅为 bareQuery，无回拼', async () => {
    const body = await bodyOf('vitest site:github.com -site:youtube.com after:2026-01 before:2026-10-01 lang:en')
    expect(body).toEqual({
      query: 'vitest',
      max_results: 5,
      search_depth: 'basic',
      include_domains: ['github.com'],
      exclude_domains: ['youtube.com'],
      start_date: '2026-01-01',
      end_date: '2026-10-01',
      language: 'en',
      filter_by_language: true,
    })
  })

  it('无 syntax → 请求体与现状逐字段一致（query 原文不动）', async () => {
    const { fetcher, calls } = recorder(() => json(SEARCH_RESPONSE))
    await createTavilyEngine({ fetcher }).search!(
      { query: 'site:github.com vitest after:2026', maxResults: 7 },
      context(),
    )
    expect(JSON.parse(String(calls[0]!.init.body))).toEqual({
      query: 'site:github.com vitest after:2026',
      max_results: 7,
      search_depth: 'basic',
    })
  })

  it('syntax 存在但无操作符 → 请求体仍是基础三字段', async () => {
    expect(await bodyOf('plain query')).toEqual({
      query: 'plain query',
      max_results: 5,
      search_depth: 'basic',
    })
  })

  it('非法日期值 → 按 operators[].raw 逐字回拼，合法操作符仍走原生参数', async () => {
    const body = await bodyOf('q after:2026-13 site:GitHub.com/docs -site:YouTube.com before:2026-02-30 lang:ZH')
    expect(body).toEqual({
      query: 'q after:2026-13 before:2026-02-30',
      max_results: 5,
      search_depth: 'basic',
      include_domains: ['github.com'],
      exclude_domains: ['youtube.com'],
      language: 'zh',
      filter_by_language: true,
    })
  })

  it('多个非法日期操作符按出现顺序回拼，不丢 token', async () => {
    const body = await bodyOf('q after:2026-13 before:2026-02-30 after:2026-00')
    expect(body.query).toBe('q after:2026-13 before:2026-02-30 after:2026-00')
    expect(body.start_date).toBeUndefined()
    expect(body.end_date).toBeUndefined()
  })

  it('完整日期做日历校验：13 月、2 月 30 日、非闰年 2 月 29 日 → unsupported 回拼', async () => {
    const body = await bodyOf('q after:2026-13-01 before:2026-02-30 after:2023-02-29')
    expect(body.query).toBe('q after:2026-13-01 before:2026-02-30 after:2023-02-29')
    expect(body.start_date).toBeUndefined()
    expect(body.end_date).toBeUndefined()
  })

  it('闰年 2 月 29 日合法 → 原样映射', async () => {
    const body = await bodyOf('q after:2024-02-29 before:2024-02-29')
    expect(body.start_date).toBe('2024-02-29')
    expect(body.end_date).toBe('2024-02-29')
  })

  it('组合后 query 为空（纯 lang:zh）→ 用 request.query 原文，语言参数照常生效', async () => {
    expect(await bodyOf('lang:zh')).toEqual({
      query: 'lang:zh',
      max_results: 5,
      search_depth: 'basic',
      language: 'zh',
      filter_by_language: true,
    })
  })

  it('组合后 query 为空（纯 site:）→ 用 request.query 原文，include_domains 照常生效', async () => {
    const body = await bodyOf('site:github.com')
    expect(body.query).toBe('site:github.com')
    expect(body.include_domains).toEqual(['github.com'])
  })
})

describe('tavily.search 失败投影（AD6）', () => {
  /** 契约 errors：429 带 Retry-After；402/432/433 额度；401/403 鉴权；5xx 服务端。 */
  const HTTP_FAILURES: Array<[number, EngineFailureKind]> = [
    [402, 'quota'],
    [401, 'auth'],
    [403, 'auth'],
    [500, 'provider-error'],
    [432, 'quota'],
    [433, 'quota'],
    [434, 'provider-error'],
  ]

  it.each(HTTP_FAILURES)('HTTP %i → %s（statusCode 保留真实值）', async (status, kind) => {
    const { fetcher } = recorder(() => json({ detail: { error: `HTTP ${status}` } }, status))
    const result = await createTavilyEngine({ fetcher }).search!({ query: 'q', maxResults: 5 }, context())
    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.failure.kind).toBe(kind)
    expect(result.failure.statusCode).toBe(status)
    if (kind === 'quota') expect(result.failure.quotaExhausted).toBe(true)
  })

  it('429 + Retry-After → rate-limited，retryAfterMs 保留（契约要求冷却依据）', async () => {
    const { fetcher } = recorder(() => json(
      { detail: { error: 'Your request has been blocked due to excessive requests.' } },
      429,
      { 'retry-after': '60' },
    ))
    const result = await createTavilyEngine({ fetcher }).search!({ query: 'q', maxResults: 5 }, context())
    expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.failure.kind).toBe('rate-limited')
      expect(result.failure.statusCode).toBe(429)
      expect(result.failure.retryAfterMs).toBe(60_000)
      expect(result.failure.cooldownable).toBe(true)
      expect(result.failure.detail).toContain('excessive requests')
    }
  })

  it.each([401, 403] as const)(
    '已配 key 的 HTTP %i → auth，只发一次请求且不回退 keyless（R6）',
    async status => {
      const { fetcher, calls } = recorder(() => json({ detail: { error: `HTTP ${status}` } }, status))
      const result = await createTavilyEngine({ fetcher }).search!(
        { query: 'q', maxResults: 5 },
        context({ apiKey: API_KEY }),
      )
      expect(calls).toHaveLength(1)
      expect(headersOf(calls[0]).authorization).toBe(`Bearer ${API_KEY}`)
      expect(headersOf(calls[0])['x-tavily-access-mode']).toBeUndefined()
      expect(result.ok).toBe(false)
      if (!result.ok) {
        expect(result.failure.kind).toBe('auth')
        expect(result.failure.statusCode).toBe(status)
      }
    },
  )

  it('网络层异常 → network', async () => {
    const { fetcher } = recorder(() => { throw new TypeError('fetch failed') })
    const result = await createTavilyEngine({ fetcher }).search!({ query: 'q', maxResults: 5 }, context())
    expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.failure.kind).toBe('network')
      expect(result.failure.detail).toContain('fetch failed')
    }
  })

  it('调用方中止 → aborted', async () => {
    const { fetcher, calls } = recorder(call => new Promise<Response>((_resolve, reject) => {
      const signal = call.init.signal
      const fail = () => reject(new DOMException('Aborted', 'AbortError'))
      if (signal?.aborted) {
        fail()
        return
      }
      signal?.addEventListener('abort', fail, { once: true })
    }))
    const controller = new AbortController()
    const pending = createTavilyEngine({ fetcher }).search!(
      { query: 'q', maxResults: 5 },
      context({ signal: controller.signal }),
    )
    controller.abort()
    const result = await pending
    expect(calls).toHaveLength(1)
    expect(result.ok).toBe(false)
    if (!result.ok) expect(result.failure.kind).toBe('aborted')
  })

  it('请求预算用尽 → aborted，且一个请求都不发', async () => {
    const { fetcher, calls } = recorder(() => json(SEARCH_RESPONSE))
    const result = await createTavilyEngine({ fetcher }).search!(
      { query: 'q', maxResults: 5 },
      context({ countRequest: () => false }),
    )
    expect(calls).toHaveLength(0)
    expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.failure.kind).toBe('aborted')
      expect(result.failure.detail).toContain('预算')
    }
  })

  it('2xx 但非 JSON → provider-error（statusCode 200）', async () => {
    const { fetcher } = recorder(() => new Response('not json', { status: 200 }))
    const result = await createTavilyEngine({ fetcher }).search!({ query: 'q', maxResults: 5 }, context())
    expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.failure.kind).toBe('provider-error')
      expect(result.failure.statusCode).toBe(200)
      expect(result.failure.detail).toContain('非 JSON')
    }
  })
})

describe('tavily.fetch 提取映射', () => {
  it('成功：请求体契约 + markdown 映射为 text（statusCode 200、truncated=false）', async () => {
    const { fetcher, calls } = recorder(() => json(EXTRACT_RESPONSE))
    const result = await createTavilyEngine({ fetcher }).fetch!(
      'https://example.com/a',
      context({ endpoint: ENDPOINTS.fetch, apiKey: 'tvly-test-key' }),
    )
    expect(result).toEqual({
      ok: true,
      outcome: {
        url: 'https://example.com/a',
        statusCode: 200,
        body: { kind: 'text', content: '# Title\n\nBody' },
        truncated: false,
      },
    })
    expect(calls[0]!.url).toBe(ENDPOINTS.fetch)
    expect(JSON.parse(String(calls[0]!.init.body))).toEqual({
      urls: ['https://example.com/a'],
      format: 'markdown',
      extract_depth: 'basic',
    })
    expect(headersOf(calls[0]).authorization).toBe('Bearer tvly-test-key')
  })

  it('无 key → keyless 头（keyless 覆盖 /extract）', async () => {
    const { fetcher, calls } = recorder(() => json(EXTRACT_RESPONSE))
    await createTavilyEngine({ fetcher }).fetch!(
      'https://example.com/a',
      context({ endpoint: ENDPOINTS.fetch }),
    )
    expect(headersOf(calls[0])['x-tavily-access-mode']).toBe('keyless')
    expect(headersOf(calls[0]).authorization).toBeUndefined()
  })

  it('failed_results 非空 → target-status（statusCode 必填、error 文本进 detail）', async () => {
    const { fetcher } = recorder(() => json({
      results: [],
      failed_results: [{ url: 'https://example.com/a', error: 'Failed to fetch url' }],
      response_time: 0.4,
      request_id: 'req_extract_2',
    }))
    const result = await createTavilyEngine({ fetcher }).fetch!(
      'https://example.com/a',
      context({ endpoint: ENDPOINTS.fetch }),
    )
    expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.failure.kind).toBe('target-status')
      expect(result.failure.statusCode).toBe(400)
      expect(result.failure.detail).toContain('Failed to fetch url')
      expect(result.failure.detail).toContain('目标状态未知，占位 400')
      expect(result.failure.cooldownable).toBe(false)
    }
  })

  it('failed_results 错误文本超长时，「占位 400」说明不被截断吃掉', async () => {
    const { fetcher } = recorder(() => json({
      results: [],
      failed_results: [{ url: 'https://example.com/a', error: 'E'.repeat(400) }],
      response_time: 0.4,
      request_id: 'req_extract_long',
    }))
    const result = await createTavilyEngine({ fetcher }).fetch!(
      'https://example.com/a',
      context({ endpoint: ENDPOINTS.fetch }),
    )
    expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.failure.kind).toBe('target-status')
      expect(result.failure.statusCode).toBe(400)
      expect(result.failure.detail).toContain('目标状态未知，占位 400')
      expect(result.failure.detail!.length).toBeLessThanOrEqual(301)
    }
  })

  it('400 + detail.failed_results → target-status（不是 provider-error，不触发引擎冷却）', async () => {
    const { fetcher } = recorder(() => json({
      detail: {
        error: 'Bad Request',
        failed_results: [{ url: 'https://example.com/a', error: 'All URLs failed validation.' }],
      },
    }, 400))
    const result = await createTavilyEngine({ fetcher }).fetch!(
      'https://example.com/a',
      context({ endpoint: ENDPOINTS.fetch }),
    )
    expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.failure.kind).toBe('target-status')
      expect(result.failure.statusCode).toBe(400)
      expect(result.failure.cooldownable).toBe(false)
      expect(result.failure.detail).toContain('All URLs failed validation.')
      expect(result.failure.detail).toContain('目标状态未知')
    }
  })

  it('400 且无 failed_results（如请求参数非法）→ provider-error', async () => {
    const { fetcher } = recorder(() => json({ detail: { error: 'Bad Request' } }, 400))
    const result = await createTavilyEngine({ fetcher }).fetch!(
      'https://example.com/a',
      context({ endpoint: ENDPOINTS.fetch }),
    )
    expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.failure.kind).toBe('provider-error')
      expect(result.failure.statusCode).toBe(400)
    }
  })

  it('results 与 failed_results 都为空 → provider-error', async () => {
    const { fetcher } = recorder(() => json({
      results: [],
      failed_results: [],
      response_time: 0.4,
      request_id: 'req_extract_3',
    }))
    const result = await createTavilyEngine({ fetcher }).fetch!(
      'https://example.com/a',
      context({ endpoint: ENDPOINTS.fetch }),
    )
    expect(result.ok).toBe(false)
    if (!result.ok) expect(result.failure.kind).toBe('provider-error')
  })

  it('raw_content 为空白 → provider-error', async () => {
    const { fetcher } = recorder(() => json({
      results: [{ url: 'https://example.com/a', raw_content: '   ' }],
      failed_results: [],
      response_time: 0.4,
      request_id: 'req_extract_4',
    }))
    const result = await createTavilyEngine({ fetcher }).fetch!(
      'https://example.com/a',
      context({ endpoint: ENDPOINTS.fetch }),
    )
    expect(result.ok).toBe(false)
    if (!result.ok) expect(result.failure.kind).toBe('provider-error')
  })

  it('响应缺 results 数组 → provider-error', async () => {
    const { fetcher } = recorder(() => json({ failed_results: [], response_time: 0.4 }))
    const result = await createTavilyEngine({ fetcher }).fetch!(
      'https://example.com/a',
      context({ endpoint: ENDPOINTS.fetch }),
    )
    expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.failure.kind).toBe('provider-error')
      expect(result.failure.detail).toContain('results')
    }
  })

  it('返回 URL 不是绝对 http(s) 时回退到请求 URL（不发明字段）', async () => {
    const { fetcher } = recorder(() => json({
      results: [{ url: '/relative', raw_content: 'Body' }],
      failed_results: [],
      response_time: 0.4,
    }))
    const result = await createTavilyEngine({ fetcher }).fetch!(
      'https://example.com/a',
      context({ endpoint: ENDPOINTS.fetch }),
    )
    expect(result.ok).toBe(true)
    if (result.ok) expect(result.outcome.url).toBe('https://example.com/a')
  })

  it.each([401, 403] as const)(
    '已配 key 的提取侧 HTTP %i → auth，单次请求不回退 keyless（R6）',
    async status => {
      const { fetcher, calls } = recorder(() => json({ detail: { error: `HTTP ${status}` } }, status))
      const result = await createTavilyEngine({ fetcher }).fetch!(
        'https://example.com/a',
        context({ endpoint: ENDPOINTS.fetch, apiKey: API_KEY }),
      )
      expect(calls).toHaveLength(1)
      expect(headersOf(calls[0]).authorization).toBe(`Bearer ${API_KEY}`)
      expect(headersOf(calls[0])['x-tavily-access-mode']).toBeUndefined()
      expect(result.ok).toBe(false)
      if (!result.ok) {
        expect(result.failure.kind).toBe('auth')
        expect(result.failure.statusCode).toBe(status)
      }
    },
  )

  it('提取侧 429 → rate-limited（与搜索共用投影）', async () => {
    const { fetcher } = recorder(() => json(
      { detail: { error: 'slow down' } },
      429,
      { 'retry-after': '5' },
    ))
    const result = await createTavilyEngine({ fetcher }).fetch!(
      'https://example.com/a',
      context({ endpoint: ENDPOINTS.fetch }),
    )
    expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.failure.kind).toBe('rate-limited')
      expect(result.failure.retryAfterMs).toBe(5_000)
    }
  })
})

describe('tavily.quota 额度查询', () => {
  it('默认搜索端点上下文（生产装配路径）仍请求 manifest /usage，GET + Bearer', async () => {
    const { fetcher, calls } = recorder(() => json(USAGE_RESPONSE))
    const report = await createTavilyEngine({ fetcher }).quota!(context({ apiKey: API_KEY }))
    expect(report.available).toBe(true)
    expect(calls).toHaveLength(1)
    expect(calls[0]!.url).toBe(ENDPOINTS.quota)
    expect(calls[0]!.init.method).toBe('GET')
    expect(headersOf(calls[0]).authorization).toBe(`Bearer ${API_KEY}`)
  })

  it('endpointOverride 为「代理前缀 + search 路径」→ quota 保留前缀只换路径，不回落官方域', async () => {
    const { fetcher, calls } = recorder(() => json(USAGE_RESPONSE))
    const report = await createTavilyEngine({ fetcher, endpointOverride: 'https://proxy.local/tavily/search' })
      .quota!(context({ apiKey: API_KEY }))
    expect(report.available).toBe(true)
    expect(calls[0]!.url).toBe('https://proxy.local/tavily/usage')
  })

  it('base 是 fetch 端点（代理 origin）→ quota 保留 origin 与路径前缀', async () => {
    const { fetcher, calls } = recorder(() => json(USAGE_RESPONSE))
    const report = await createTavilyEngine({ fetcher, endpointOverride: 'https://proxy.local/tavily/extract' })
      .quota!(context({ apiKey: API_KEY }))
    expect(report.available).toBe(true)
    expect(calls[0]!.url).toBe('https://proxy.local/tavily/usage')
  })

  it('有 key → GET /usage 映射 used/limit/remaining 与 raw 摘要', async () => {
    const { fetcher, calls } = recorder(() => json(USAGE_RESPONSE))
    const report = await createTavilyEngine({ fetcher }).quota!(
      context({ endpoint: ENDPOINTS.quota, apiKey: 'tvly-test-key' }),
    )
    expect(report).toMatchObject({
      engineId: 'tavily',
      available: true,
      used: 12,
      limit: 1000,
      remaining: 988,
    })
    expect(report.raw).toContain('key.usage=12')
    expect(report.raw).toContain('plan=Bootstrap')
    expect(calls[0]!.url).toBe(ENDPOINTS.quota)
    expect(headersOf(calls[0]).authorization).toBe('Bearer tvly-test-key')
  })

  it('双 null（key.limit=null 且 plan_limit=null）→ 维持不限省略，仍 available=true', async () => {
    const { fetcher } = recorder(() => json(USAGE_DOUBLE_NULL))
    const report = await createTavilyEngine({ fetcher }).quota!(
      context({ endpoint: ENDPOINTS.quota, apiKey: API_KEY }),
    )
    expect(report).toMatchObject({ engineId: 'tavily', available: true, used: 3 })
    expect(report.limit).toBeUndefined()
    expect(report.remaining).toBeUndefined()
  })

  it('key.limit=null + plan_limit/plan_usage 配对齐全 → 补出 limit/used/remaining', async () => {
    const { fetcher } = recorder(() => json({
      key: { usage: 3, limit: null },
      account: { current_plan: 'Bootstrap', plan_limit: 15000, plan_usage: 120 },
    }))
    const report = await createTavilyEngine({ fetcher }).quota!(
      context({ endpoint: ENDPOINTS.quota, apiKey: API_KEY }),
    )
    expect(report).toMatchObject({ available: true, used: 120, limit: 15000, remaining: 14880 })
  })

  it('半缺：plan_limit 有值但 plan_usage 缺失 → available=true，limit 保留、used/remaining 省略', async () => {
    const { fetcher } = recorder(() => json(USAGE_PLAN_USAGE_MISSING))
    const report = await createTavilyEngine({ fetcher }).quota!(
      context({ endpoint: ENDPOINTS.quota, apiKey: API_KEY }),
    )
    expect(report).toMatchObject({ available: true, limit: 15000 })
    expect(report.used).toBeUndefined()
    expect(report.remaining).toBeUndefined()
  })

  it('全缺：key.limit 与 account.plan_limit 都缺失 → available=false 且原因指向 key.limit', async () => {
    const { fetcher } = recorder(() => json(USAGE_LIMITS_MISSING))
    const report = await createTavilyEngine({ fetcher }).quota!(
      context({ endpoint: ENDPOINTS.quota, apiKey: API_KEY }),
    )
    expect(report).toMatchObject({ available: false, raw: expect.stringContaining('key.limit') })
  })

  it('key.limit=null + plan_limit 缺失 → available=false（缺失 ≠ null）', async () => {
    const { fetcher } = recorder(() => json({
      key: { usage: 3, limit: null },
      account: { current_plan: 'Bootstrap' },
    }))
    const report = await createTavilyEngine({ fetcher }).quota!(
      context({ endpoint: ENDPOINTS.quota, apiKey: API_KEY }),
    )
    expect(report).toMatchObject({ available: false, raw: expect.stringContaining('account.plan_limit') })
  })

  it('key.limit=null + plan_limit 类型异常 → available=false', async () => {
    const { fetcher } = recorder(() => json({
      key: { usage: 3, limit: null },
      account: { current_plan: 'Bootstrap', plan_limit: 'many' },
    }))
    const report = await createTavilyEngine({ fetcher }).quota!(
      context({ endpoint: ENDPOINTS.quota, apiKey: API_KEY }),
    )
    expect(report).toMatchObject({ available: false, raw: expect.stringContaining('account.plan_limit') })
  })

  it('plan_usage 类型异常 → available=false', async () => {
    const { fetcher } = recorder(() => json({
      key: { usage: 3, limit: null },
      account: { current_plan: 'Bootstrap', plan_limit: 15000, plan_usage: 'lots' },
    }))
    const report = await createTavilyEngine({ fetcher }).quota!(
      context({ endpoint: ENDPOINTS.quota, apiKey: API_KEY }),
    )
    expect(report).toMatchObject({ available: false, raw: expect.stringContaining('account.plan_usage') })
  })

  it('key.limit 字段缺失 → available=false（形状异常不能显示成「不限」）', async () => {
    const { fetcher } = recorder(() => json({ key: { usage: 3 }, account: { current_plan: 'Bootstrap' } }))
    const report = await createTavilyEngine({ fetcher }).quota!(
      context({ endpoint: ENDPOINTS.quota, apiKey: API_KEY }),
    )
    expect(report.available).toBe(false)
    expect(report.raw).toContain('key.limit')
    expect(report.limit).toBeUndefined()
    expect(report.remaining).toBeUndefined()
  })

  it('keyless 模式不请求 /usage → available=false（显式 N/A，省一次必 401 的请求）', async () => {
    const { fetcher, calls } = recorder(() => json(USAGE_RESPONSE))
    const report = await createTavilyEngine({ fetcher }).quota!(context({ endpoint: ENDPOINTS.quota }))
    expect(report.available).toBe(false)
    expect(report.raw).toContain('keyless')
    expect(calls).toHaveLength(0)
  })

  it('401 → available=false，raw 保留 auth 与真实状态码', async () => {
    const { fetcher } = recorder(() => json({ detail: { error: 'Unauthorized' } }, 401))
    const report = await createTavilyEngine({ fetcher }).quota!(
      context({ endpoint: ENDPOINTS.quota, apiKey: 'tvly-bad-key' }),
    )
    expect(report.available).toBe(false)
    expect(report.raw).toContain('auth')
    expect(report.raw).toContain('HTTP 401')
  })

  it('响应缺 key.usage → available=false', async () => {
    const { fetcher } = recorder(() => json({ key: { limit: 1000 }, account: { current_plan: 'Bootstrap' } }))
    const report = await createTavilyEngine({ fetcher }).quota!(
      context({ endpoint: ENDPOINTS.quota, apiKey: 'tvly-test-key' }),
    )
    expect(report.available).toBe(false)
    expect(report.raw).toContain('key.usage')
  })

  it('网络异常 → available=false（额度面不抛错）', async () => {
    const { fetcher } = recorder(() => { throw new TypeError('socket hang up') })
    const report = await createTavilyEngine({ fetcher }).quota!(
      context({ endpoint: ENDPOINTS.quota, apiKey: 'tvly-test-key' }),
    )
    expect(report.available).toBe(false)
    expect(report.raw).toContain('network')
  })

  it('请求预算用尽 → available=false 且不发请求', async () => {
    const { fetcher, calls } = recorder(() => json(USAGE_RESPONSE))
    const report = await createTavilyEngine({ fetcher }).quota!(
      context({ endpoint: ENDPOINTS.quota, apiKey: 'tvly-test-key', countRequest: () => false }),
    )
    expect(report.available).toBe(false)
    expect(report.raw).toContain('aborted')
    expect(calls).toHaveLength(0)
  })
})
