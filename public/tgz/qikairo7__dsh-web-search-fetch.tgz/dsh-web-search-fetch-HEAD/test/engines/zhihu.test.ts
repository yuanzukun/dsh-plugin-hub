// 离线替身测试，不触网：全部 HTTP 响应由注入的 fetcher 替身返回，不发真实网络请求。
// 夹具依据 global_search / zhihu_search 与 quota 的响应字段表。
// 热榜/直答夹具另按官方文档编码：
//   https://developer.zhihu.com/docs?key=hot_list / https://developer.zhihu.com/docs?key=zhida
// 夹具只包含契约里逐字列出的字段；时间戳单位假设见 src/engines/zhihu.ts 的 ASSUMED 注释。
// 官方文档 URL 见契约 docUrls：https://developer.zhihu.com/docs?key=global_search 等。

import { describe, expect, it } from 'vitest'
import type { EngineContext, EngineSearchOutcome, EngineSearchRequest, QuerySyntax, QuotaReport } from '../../src/engines/contract.js'
import type { EngineFailure } from '../../src/engines/failure.js'
import { ZHIHU_MANIFEST } from '../../src/engines/registry.js'
import { createZhihuEngine, zhihuSearchFace } from '../../src/engines/zhihu.js'
import { parseQuerySyntax } from '../../src/search/query-syntax.js'

// ---- 离线 HTTP 替身 ----

interface RecordedCall {
  readonly url: URL
  readonly init: RequestInit
}

/** 按调用顺序返回预置响应（响应可为工厂，用于抛异常或减少重复构造）。 */
function stubFetch(responses: readonly (Response | (() => Response))[]): {
  fetcher: typeof fetch
  calls: RecordedCall[]
} {
  const calls: RecordedCall[] = []
  let index = 0
  const fetcher = (async (input: Parameters<typeof fetch>[0], init?: RequestInit): Promise<Response> => {
    calls.push({ url: new URL(String(input)), init: init ?? {} })
    const response = responses[Math.min(index, responses.length - 1)]
    index += 1
    if (response === undefined) throw new Error('测试未配置响应')
    return typeof response === 'function' ? response() : response
  }) as typeof fetch
  return { fetcher, calls }
}

function jsonResponse(body: unknown, status = 200, headers: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json', ...headers },
  })
}

function headerOf(call: RecordedCall, name: string): string | null {
  return new Headers(call.init.headers).get(name)
}

function makeContext(overrides: Partial<EngineContext> = {}): EngineContext {
  const controller = new AbortController()
  return {
    signal: controller.signal,
    deadline: Date.now() + 30_000,
    apiKey: 'test-secret',
    endpoint: ZHIHU_MANIFEST.endpoints.search ?? '',
    countRequest: () => true,
    ...overrides,
  }
}

function makeQuotaContext(overrides: Partial<EngineContext> = {}): EngineContext {
  return makeContext({ endpoint: ZHIHU_MANIFEST.endpoints.quota ?? '', ...overrides })
}

async function searchOk(
  engine: ReturnType<typeof createZhihuEngine>,
  query: string,
  maxResults = 8,
  ctx: EngineContext = makeContext(),
): Promise<EngineSearchOutcome> {
  const result = await engine.search!({ query, maxResults }, ctx)
  if (!result.ok) throw new Error(`期望搜索成功，实际失败：${result.failure.kind}`)
  return result.outcome
}

async function searchFailure(
  response: Response | (() => Response),
  ctx: EngineContext = makeContext(),
  query = 'TypeScript',
): Promise<EngineFailure> {
  const { fetcher } = stubFetch([response])
  const engine = createZhihuEngine({ fetcher })
  const result = await engine.search!({ query, maxResults: 8 }, ctx)
  if (result.ok) throw new Error('期望搜索失败，实际成功')
  return result.failure
}

async function quotaReport(
  response: Response | (() => Response),
  ctx: EngineContext = makeQuotaContext(),
): Promise<QuotaReport> {
  const { fetcher } = stubFetch([response])
  return createZhihuEngine({ fetcher }).quota!(ctx)
}

// ---- 夹具（字段逐字取自契约 response 字段表） ----

/** global_search 成功响应；Item 字段见契约 endpoints[1].response。 */
const globalSearchSuccess = {
  Code: 0,
  Message: 'success',
  Data: {
    HasMore: false,
    Items: [
      {
        Title: '如何评价 TypeScript 6.0？',
        ContentType: 'Answer',
        ContentID: 'answer-token-1',
        ContentText: '类型系统<em>改进</em>的摘要',
        Url: 'https://www.zhihu.com/question/1/answer/2?utm_source=zhihu',
        CommentCount: 12,
        VoteUpCount: 345,
        AuthorName: '示例作者',
        AuthorAvatar: 'https://pic1.zhihu.com/avatar.jpg',
        AuthorBadge: 'https://pic1.zhihu.com/badge.png',
        AuthorBadgeText: '优秀回答者',
        EditTime: 1_700_000_000,
        CommentInfoList: [{ Content: '精选评论' }],
        AuthorityLevel: '3',
      },
    ],
  },
}

/** zhihu_search 成功响应；站内面多 SearchHashId/RankingScore，且含 CreateTime、无 EditTime。 */
const zhihuSearchSuccess = {
  Code: 0,
  Message: 'success',
  Data: {
    HasMore: false,
    SearchHashId: 'hash-1',
    Items: [
      {
        Title: '站内回答',
        ContentType: 'Answer',
        ContentID: 'content-token-1',
        ContentText: '站内摘要',
        Url: 'https://www.zhihu.com/question/3/answer/4?utm_source=zhihu',
        CommentCount: 0,
        VoteUpCount: 1,
        AuthorName: '知乎用户',
        AuthorAvatar: 'https://pic1.zhihu.com/avatar-2.jpg',
        AuthorBadge: 'https://pic1.zhihu.com/badge-2.png',
        AuthorBadgeText: '',
        CreateTime: 1_680_000_000,
        CommentInfoList: [],
        AuthorityLevel: '2',
        RankingScore: 0.9,
      },
    ],
  },
}

/** quota 成功响应；字段见契约 endpoints[2].response（含一个无关 APIID 验证过滤）。 */
const quotaSuccess = {
  Code: 0,
  Message: 'success',
  Data: [
    { APIID: 'global_search', APIName: '全网搜索', TotalQuota: 100, TotalUsed: 30, RemainingQuota: 70 },
    { APIID: 'zhihu_search', APIName: '知乎搜索', TotalQuota: 50, TotalUsed: 10, RemainingQuota: 40 },
    { APIID: 'hot_list', APIName: '热榜', TotalQuota: 999, TotalUsed: 1, RemainingQuota: 998 },
  ],
}

/** hot_list 成功响应；字段逐字取自官方文档 https://developer.zhihu.com/docs?key=hot_list 的响应示例。 */
const hotListSuccess = {
  Code: 0,
  Message: 'success',
  Data: {
    Total: 2,
    Items: [
      {
        Title: '如何评价某个热点问题？',
        Url: 'https://www.zhihu.com/question/123456789',
        ThumbnailUrl: 'https://pic1.zhimg.com/v2-d4b0f8158e064dbcc71eb6ce970230a9.jpg',
        Summary: '这是该问题的内容摘要',
      },
      {
        Title: '一篇正在热榜上的文章标题',
        Url: 'https://zhuanlan.zhihu.com/p/987654321',
        ThumbnailUrl: '',
        Summary: '',
      },
    ],
  },
}

/** zhida 非流式成功响应；字段逐字取自官方文档 https://developer.zhihu.com/docs?key=zhida 的响应示例。 */
const zhidaSuccess = {
  id: 'chatcmpl-test',
  object: 'chat.completion',
  created: 1_740_470_400,
  model: 'zhida-fast-1p5',
  choices: [
    {
      index: 0,
      message: { role: 'assistant', content: '这是知乎直答正文。' },
      finish_reason: 'stop',
    },
  ],
}

async function hotTopicsFailure(
  response: Response | (() => Response),
  ctx: EngineContext = makeContext(),
): Promise<EngineFailure> {
  const { fetcher } = stubFetch([response])
  const result = await createZhihuEngine({ fetcher }).hotTopics!(ctx)
  if (result.ok) throw new Error('期望热榜失败，实际成功')
  return result.failure
}

async function runSearchWithCalls(
  responses: readonly (Response | (() => Response))[],
  request: EngineSearchRequest,
  options: NonNullable<Parameters<typeof createZhihuEngine>[0]> = {},
  ctx: EngineContext = makeContext(),
) {
  const { fetcher, calls } = stubFetch(responses)
  const result = await createZhihuEngine({ ...options, fetcher }).search!(request, ctx)
  return { result, calls }
}

// ---- 测试 ----

describe('manifest 与搜索面选择', () => {
  it('manifest 直接引用 registry，声明 search 与 fetch 能力', () => {
    const engine = createZhihuEngine()
    expect(engine.manifest).toBe(ZHIHU_MANIFEST)
    expect(engine.manifest.id).toBe('zhihu')
    expect(engine.manifest.capabilities).toEqual(['search', 'fetch'])
    expect(engine.fetch).toBeTypeOf('function')
  })

  it('fetchApplicable 只命中 zhihu.com/question/<id>（含后缀与查询参数）', () => {
    const engine = createZhihuEngine()
    expect(engine.fetchApplicable!('https://www.zhihu.com/question/123')).toBe(true)
    expect(engine.fetchApplicable!('https://zhihu.com/question/123/answer/456?utm_source=zhihu')).toBe(true)
    expect(engine.fetchApplicable!('https://www.zhihu.com/column/c_1')).toBe(false)
    expect(engine.fetchApplicable!('https://example.com/question/123')).toBe(false)
  })

  it.each([
    ['知乎 如何评价 TypeScript 6.0', 'zhihu'],
    ['site:zhihu.com 大模型', 'zhihu'],
    ['关于 ZHIHU.COM 的讨论', 'zhihu'],
    ['TypeScript 泛型教程', 'global'],
  ] as const)('查询 %s → %s', (query, face) => {
    expect(zhihuSearchFace(query)).toBe(face)
  })
})

describe('查询语法接线（知乎无原生操作符参数，全部回拼）', () => {
  it('site:zhihu.com 命中站内面，请求 Query 含原 token（面判定用原 query，发送用拼后文本）', async () => {
    const { fetcher, calls } = stubFetch([jsonResponse(zhihuSearchSuccess)])
    const engine = createZhihuEngine({ fetcher })
    const query = 'site:zhihu.com 大模型'
    const syntax = parseQuerySyntax(query)
    // bareQuery 已剥除 site: token，本身不再含 zhihu.com——面选择必须仍看原 query。
    expect(syntax.bareQuery).toBe('大模型')
    expect(syntax.domains).toEqual(['zhihu.com'])

    const result = await engine.search!({ query, maxResults: 8, syntax }, makeContext())
    expect(result.ok).toBe(true)

    const call = calls[0]!
    expect(call.url.pathname).toBe('/api/v1/content/zhihu_search')
    const sent = call.url.searchParams.get('Query')
    expect(sent).toContain('site:zhihu.com')
    expect(sent).toContain('大模型')
  })

  it('域名/排除域名/语言/日期操作符逐 token 回拼，不静默丢弃', async () => {
    const query = 'rust 异步 site:zhihu.com -site:medium.com lang:zh after:2026-01 before:2026-06'
    const syntax = parseQuerySyntax(query)
    const { fetcher, calls } = stubFetch([jsonResponse(zhihuSearchSuccess)])
    const engine = createZhihuEngine({ fetcher })

    const result = await engine.search!({ query, maxResults: 8, syntax }, makeContext())
    expect(result.ok).toBe(true)

    const call = calls[0]!
    expect(call.url.pathname).toBe('/api/v1/content/zhihu_search')
    expect(call.url.searchParams.get('Query')).toBe(
      'rust 异步 site:zhihu.com -site:medium.com lang:zh after:2026-01 before:2026-06',
    )
  })

  it('syntax 缺省时行为与现状一致：Query 用 trim 后的原文（不折叠内部空白）', async () => {
    const { fetcher, calls } = stubFetch([jsonResponse(globalSearchSuccess)])
    const engine = createZhihuEngine({ fetcher })
    const outcome = await searchOk(engine, '  TypeScript   6.0  ', 8)

    expect(outcome.sources).toHaveLength(1)
    const call = calls[0]!
    expect(call.url.pathname).toBe('/api/v1/content/global_search')
    expect(call.url.searchParams.get('Query')).toBe('TypeScript   6.0')
  })

  it('syntax 存在但无操作符时发送 bareQuery（空白折叠后的文本）', async () => {
    const { fetcher, calls } = stubFetch([jsonResponse(globalSearchSuccess)])
    const engine = createZhihuEngine({ fetcher })
    const query = '  TypeScript   6.0  '
    const result = await engine.search!({ query, maxResults: 8, syntax: parseQuerySyntax(query) }, makeContext())
    expect(result.ok).toBe(true)
    expect(calls[0]!.url.searchParams.get('Query')).toBe('TypeScript 6.0')
  })

  it('回拼用 operators[].raw 逐字原顺序：大小写、路径后缀、乱序都不改写', async () => {
    const query = 'Rust 异步 before:2026-06 lang:ZH site:Zhihu.COM/ask -site:Medium.com after:2026-01 生态'
    const syntax = parseQuerySyntax(query)
    const { fetcher, calls } = stubFetch([jsonResponse(zhihuSearchSuccess)])
    const engine = createZhihuEngine({ fetcher })

    const result = await engine.search!({ query, maxResults: 8, syntax }, makeContext())
    expect(result.ok).toBe(true)

    expect(calls[0]!.url.searchParams.get('Query')).toBe(
      'Rust 异步 生态 before:2026-06 lang:ZH site:Zhihu.COM/ask -site:Medium.com after:2026-01',
    )
  })

  it('面选择仍用原 request.query：site: 带大小写与路径后缀时仍走站内面', async () => {
    const query = 'site:Zhihu.COM/ask 大模型'
    const syntax = parseQuerySyntax(query)
    const { fetcher, calls } = stubFetch([jsonResponse(zhihuSearchSuccess)])

    const result = await createZhihuEngine({ fetcher }).search!(
      { query, maxResults: 8, syntax },
      makeContext(),
    )
    expect(result.ok).toBe(true)
    expect(calls[0]!.url.pathname).toBe('/api/v1/content/zhihu_search')
  })

  it('组合后查询为空时退回 request.query 原文，不发空串', async () => {
    const syntax: QuerySyntax = { operators: [], domains: [], excludeDomains: [], bareQuery: '' }
    const { fetcher, calls } = stubFetch([jsonResponse(globalSearchSuccess)])

    const result = await createZhihuEngine({ fetcher }).search!(
      { query: 'TypeScript 6.0', maxResults: 8, syntax },
      makeContext(),
    )
    expect(result.ok).toBe(true)
    expect(calls[0]!.url.searchParams.get('Query')).toBe('TypeScript 6.0')
  })
})

describe('搜索成功映射', () => {
  it('global_search：字段逐项映射，并带上契约要求的请求形状与鉴权头', async () => {
    const { fetcher, calls } = stubFetch([jsonResponse(globalSearchSuccess)])
    const engine = createZhihuEngine({ fetcher })
    const outcome = await searchOk(engine, 'TypeScript 6.0', 8)

    expect(outcome.sources).toEqual([
      {
        url: 'https://www.zhihu.com/question/1/answer/2?utm_source=zhihu',
        title: '如何评价 TypeScript 6.0？',
        snippet: '类型系统<em>改进</em>的摘要',
        // ASSUMED: EditTime 按秒级 Unix 时间戳换算（见适配文件）。
        publishedAt: new Date(1_700_000_000_000).toISOString(),
      },
    ])
    expect(outcome.truncated).toBe(false)

    expect(calls).toHaveLength(1)
    const call = calls[0]!
    expect(call.init.method).toBe('GET')
    expect(call.url.pathname).toBe('/api/v1/content/global_search')
    expect(call.url.searchParams.get('Query')).toBe('TypeScript 6.0')
    expect(call.url.searchParams.get('Count')).toBe('8')
    expect(headerOf(call, 'Authorization')).toBe('Bearer test-secret')
    expect(headerOf(call, 'Content-Type')).toBe('application/json')
    const timestamp = Number(headerOf(call, 'X-Request-Timestamp'))
    expect(Number.isInteger(timestamp)).toBe(true)
    expect(Math.abs(timestamp - Math.floor(Date.now() / 1000))).toBeLessThanOrEqual(5)
  })

  it('站内查询走 zhihu_search，CreateTime 兜底为 publishedAt，Count 上限 10', async () => {
    const { fetcher, calls } = stubFetch([jsonResponse(zhihuSearchSuccess)])
    const engine = createZhihuEngine({ fetcher })
    const outcome = await searchOk(engine, '知乎 如何评价 TypeScript', 25)

    expect(calls[0]!.url.pathname).toBe('/api/v1/content/zhihu_search')
    expect(calls[0]!.url.searchParams.get('Count')).toBe('10')
    // 请求 25 条超过站内面上限 10，引擎侧截断。
    expect(outcome.truncated).toBe(true)
    expect(outcome.sources[0]!.publishedAt).toBe(new Date(1_680_000_000_000).toISOString())
  })

  it('全网查询 Count 上限 20，请求更多时置 truncated', async () => {
    const { fetcher, calls } = stubFetch([jsonResponse(globalSearchSuccess)])
    const engine = createZhihuEngine({ fetcher })
    const outcome = await searchOk(engine, 'TypeScript 6.0', 30)

    expect(calls[0]!.url.searchParams.get('Count')).toBe('20')
    expect(outcome.truncated).toBe(true)
  })

  it('上游 HasMore=true 时置 truncated', async () => {
    const payload = { ...globalSearchSuccess, Data: { ...globalSearchSuccess.Data, HasMore: true } }
    const { fetcher } = stubFetch([jsonResponse(payload)])
    const outcome = await searchOk(createZhihuEngine({ fetcher }), 'TypeScript 6.0', 8)
    expect(outcome.truncated).toBe(true)
  })

  it('没有可引用 HTTP(S) URL 的条目被丢弃', async () => {
    const payload = {
      Code: 0,
      Message: 'success',
      Data: {
        HasMore: false,
        Items: [
          { Title: '无链接', ContentText: 'snippet' },
          { Title: '非 HTTP', Url: 'javascript:alert(1)' },
          { Title: '有效', Url: 'https://www.zhihu.com/question/9', ContentText: 'ok' },
        ],
      },
    }
    const { fetcher } = stubFetch([jsonResponse(payload)])
    const outcome = await searchOk(createZhihuEngine({ fetcher }), 'TypeScript 6.0', 8)
    expect(outcome.sources).toHaveLength(1)
    expect(outcome.sources[0]!.url).toBe('https://www.zhihu.com/question/9')
  })
})

describe('失败投影', () => {
  it('envelope Code 30001 → rate-limited，detail 带 Message', async () => {
    const failure = await searchFailure(
      jsonResponse({ Code: 30001, Message: '请求频率超过限制，请稍后重试', Data: null }),
    )
    expect(failure.kind).toBe('rate-limited')
    expect(failure.cooldownable).toBe(true)
    expect(failure.detail).toContain('30001')
    expect(failure.detail).toContain('请求频率超过限制')
  })

  it('envelope Code 20001（鉴权失败）→ auth，detail 保留 Code/Message', async () => {
    const failure = await searchFailure(jsonResponse({ Code: 20001, Message: 'Access Secret 鉴权失败', Data: null }))
    expect(failure.kind).toBe('auth')
    expect(failure.cooldownable).toBe(false)
    expect(failure.detail).toContain('20001')
    expect(failure.detail).toContain('Access Secret 鉴权失败')
  })

  it('envelope Code 10001（参数错误）→ invalid', async () => {
    const failure = await searchFailure(jsonResponse({ Code: 10001, Message: '参数错误', Data: null }))
    expect(failure.kind).toBe('invalid')
    expect(failure.cooldownable).toBe(false)
    expect(failure.detail).toContain('10001')
    expect(failure.detail).toContain('参数错误')
  })

  it('envelope Code 90001（内部错误）→ provider-error', async () => {
    const failure = await searchFailure(jsonResponse({ Code: 90001, Message: '内部错误', Data: null }))
    expect(failure.kind).toBe('provider-error')
    expect(failure.detail).toContain('90001')
    expect(failure.detail).toContain('内部错误')
  })

  it('envelope 未知非 0 Code（12345）→ provider-error', async () => {
    const failure = await searchFailure(jsonResponse({ Code: 12345, Message: '未知错误', Data: null }))
    expect(failure.kind).toBe('provider-error')
    expect(failure.detail).toContain('12345')
    expect(failure.detail).toContain('未知错误')
  })

  it('HTTP 429 → rate-limited，并保留 Retry-After 毫秒提示', async () => {
    const failure = await searchFailure(jsonResponse({}, 429, { 'retry-after': '2' }))
    expect(failure.kind).toBe('rate-limited')
    expect(failure.statusCode).toBe(429)
    // 429 必须带服务端冷却提示，供熔断器决定冷却时长。
    expect(failure.retryAfterMs).toBe(2000)
  })

  it('HTTP 402 → quota（quotaExhausted）', async () => {
    const failure = await searchFailure(jsonResponse({}, 402))
    expect(failure.kind).toBe('quota')
    expect(failure.quotaExhausted).toBe(true)
  })

  it('HTTP 401 → auth', async () => {
    const failure = await searchFailure(jsonResponse({}, 401))
    expect(failure.kind).toBe('auth')
    expect(failure.statusCode).toBe(401)
  })

  it('HTTP 500 → provider-error', async () => {
    const failure = await searchFailure(jsonResponse({}, 500))
    expect(failure.kind).toBe('provider-error')
    expect(failure.statusCode).toBe(500)
  })

  it('网络异常 → network', async () => {
    const failure = await searchFailure(() => {
      throw new TypeError('fetch failed')
    })
    expect(failure.kind).toBe('network')
  })

  it('操作已取消 → aborted', async () => {
    const controller = new AbortController()
    controller.abort()
    const failure = await searchFailure(
      () => {
        throw new DOMException('The operation was aborted.', 'AbortError')
      },
      makeContext({ signal: controller.signal }),
    )
    expect(failure.kind).toBe('aborted')
  })

  it('未配置 Access Secret → auth，且不发请求', async () => {
    const { fetcher, calls } = stubFetch([])
    const result = await createZhihuEngine({ fetcher }).search!(
      { query: 'TypeScript', maxResults: 8 },
      makeContext({ apiKey: undefined }),
    )
    expect(result.ok).toBe(false)
    if (result.ok) throw new Error('期望失败，实际成功')
    expect(result.failure.kind).toBe('auth')
    expect(calls).toHaveLength(0)
  })

  it('空查询 → invalid，且不发请求', async () => {
    const { fetcher, calls } = stubFetch([])
    const result = await createZhihuEngine({ fetcher }).search!(
      { query: '   ', maxResults: 8 },
      makeContext(),
    )
    expect(result.ok).toBe(false)
    if (result.ok) throw new Error('期望失败，实际成功')
    expect(result.failure.kind).toBe('invalid')
    expect(calls).toHaveLength(0)
  })
})

describe('额度查询', () => {
  it('聚合搜索能力两项的 TotalUsed/TotalQuota/RemainingQuota，忽略无关 APIID', async () => {
    const { fetcher, calls } = stubFetch([jsonResponse(quotaSuccess)])
    const report = await createZhihuEngine({ fetcher }).quota!(makeQuotaContext())

    expect(report).toMatchObject({
      engineId: 'zhihu',
      available: true,
      used: 40,
      limit: 150,
      remaining: 110,
    })
    expect(report.raw).toContain('global_search')
    expect(report.raw).not.toContain('hot_list')

    const call = calls[0]!
    expect(call.init.method).toBe('GET')
    expect(call.url.pathname).toBe('/api/v1/quota')
    expect(call.url.searchParams.get('APIIDs')).toBe('global_search,zhihu_search')
    expect(headerOf(call, 'Authorization')).toBe('Bearer test-secret')
    expect(headerOf(call, 'X-Request-Timestamp')).toMatch(/^\d+$/)
  })

  it('Data 为空数组（额度项未配置）→ available:false', async () => {
    const report = await quotaReport(jsonResponse({ Code: 0, Message: 'success', Data: [] }))
    expect(report.available).toBe(false)
    expect(report.raw).toContain('未包含搜索能力')
  })

  it('额度接口 Code 30001 → available:false，raw 带原因', async () => {
    const report = await quotaReport(
      jsonResponse({ Code: 30001, Message: '请求频率超过限制，请稍后重试', Data: [] }),
    )
    expect(report.available).toBe(false)
    expect(report.raw).toContain('rate-limited')
    expect(report.raw).toContain('30001')
  })

  it('未配置 Access Secret → available:false，且不发请求', async () => {
    const { fetcher, calls } = stubFetch([])
    const report = await createZhihuEngine({ fetcher }).quota!(
      makeQuotaContext({ apiKey: undefined }),
    )
    expect(report.available).toBe(false)
    expect(report.raw).toContain('Access Secret')
    expect(calls).toHaveLength(0)
  })

  it('额度接口 HTTP 401 → available:false，raw 标 auth', async () => {
    const report = await quotaReport(jsonResponse({}, 401))
    expect(report.available).toBe(false)
    expect(report.raw).toContain('auth')
  })
})

describe('热榜 hotTopics', () => {
  it('调用 /api/v1/content/hot_list，不传 Limit，映射标题/链接/摘要且 truncated 恒 false', async () => {
    const { fetcher, calls } = stubFetch([jsonResponse(hotListSuccess)])
    const result = await createZhihuEngine({ fetcher }).hotTopics!(makeContext())

    expect(result.ok).toBe(true)
    if (!result.ok) throw new Error('期望热榜成功，实际失败')
    expect(result.outcome).toEqual({
      sources: [
        {
          url: 'https://www.zhihu.com/question/123456789',
          title: '如何评价某个热点问题？',
          snippet: '这是该问题的内容摘要',
        },
        {
          url: 'https://zhuanlan.zhihu.com/p/987654321',
          title: '一篇正在热榜上的文章标题',
        },
      ],
      truncated: false,
    })

    expect(calls).toHaveLength(1)
    const call = calls[0]!
    expect(call.init.method).toBe('GET')
    expect(call.url.pathname).toBe('/api/v1/content/hot_list')
    // 条数按端点默认（30），适配层不发送 Limit。
    expect(call.url.search).toBe('')
    expect(headerOf(call, 'Authorization')).toBe('Bearer test-secret')
    expect(headerOf(call, 'Content-Type')).toBe('application/json')
    expect(Number(headerOf(call, 'X-Request-Timestamp'))).toBeGreaterThan(0)
  })

  it('没有可引用 HTTP(S) URL 的热榜条目被丢弃', async () => {
    const payload = {
      Code: 0,
      Message: 'success',
      Data: {
        Total: 3,
        Items: [
          { Title: '无链接', Summary: 'snippet' },
          { Title: '非 HTTP', Url: 'javascript:alert(1)' },
          { Title: '有效', Url: 'https://www.zhihu.com/question/9', Summary: 'ok' },
        ],
      },
    }
    const { fetcher } = stubFetch([jsonResponse(payload)])
    const result = await createZhihuEngine({ fetcher }).hotTopics!(makeContext())
    expect(result.ok).toBe(true)
    if (!result.ok) throw new Error('期望热榜成功，实际失败')
    expect(result.outcome.sources).toHaveLength(1)
    expect(result.outcome.sources[0]!.url).toBe('https://www.zhihu.com/question/9')
    expect(result.outcome.truncated).toBe(false)
  })

  it('envelope 30001 → rate-limited，detail 带 Message', async () => {
    const failure = await hotTopicsFailure(
      jsonResponse({ Code: 30001, Message: '请求频率超过限制，请稍后重试', Data: null }),
    )
    expect(failure.kind).toBe('rate-limited')
    expect(failure.cooldownable).toBe(true)
    expect(failure.detail).toContain('30001')
    expect(failure.detail).toContain('请求频率超过限制')
  })

  it.each([
    [20001, 'auth'],
    [90001, 'provider-error'],
  ] as const)('envelope %s → %s', async (code, kind) => {
    const failure = await hotTopicsFailure(jsonResponse({ Code: code, Message: '错误', Data: null }))
    expect(failure.kind).toBe(kind)
    expect(failure.detail).toContain(String(code))
  })

  it('成功响应缺少 Data 或 Items 不是数组 → provider-error', async () => {
    const missing = await hotTopicsFailure(jsonResponse({ Code: 0, Message: 'success' }))
    expect(missing.kind).toBe('provider-error')
    expect(missing.detail).toContain('缺少 Data')

    const notArray = await hotTopicsFailure(
      jsonResponse({ Code: 0, Message: 'success', Data: { Total: 1, Items: 'nope' } }),
    )
    expect(notArray.kind).toBe('provider-error')
    expect(notArray.detail).toContain('不是数组')
  })

  it('未配置 Access Secret → auth，且不发请求', async () => {
    const { fetcher, calls } = stubFetch([])
    const result = await createZhihuEngine({ fetcher }).hotTopics!(makeContext({ apiKey: undefined }))
    expect(result.ok).toBe(false)
    if (result.ok) throw new Error('期望失败，实际成功')
    expect(result.failure.kind).toBe('auth')
    expect(calls).toHaveLength(0)
  })

  it('预算耗尽 → aborted，且不发请求', async () => {
    const { fetcher, calls } = stubFetch([])
    const result = await createZhihuEngine({ fetcher }).hotTopics!(
      makeContext({ countRequest: () => false }),
    )
    expect(result.ok).toBe(false)
    if (result.ok) throw new Error('期望失败，实际成功')
    expect(result.failure.kind).toBe('aborted')
    expect(calls).toHaveLength(0)
  })
})

describe('直答 wantAnswer', () => {
  const answerRequest: EngineSearchRequest = { query: '如何学习 Rust', maxResults: 8, wantAnswer: true }

  it('wantAnswer=true 时直答与主搜索并发发起，content 原样回填，sources/truncated 不变', async () => {
    const { result, calls } = await runSearchWithCalls(
      [jsonResponse(globalSearchSuccess), jsonResponse(zhidaSuccess)],
      answerRequest,
    )

    expect(result.ok).toBe(true)
    if (!result.ok) throw new Error('期望搜索成功，实际失败')
    expect(result.outcome.content).toBe('这是知乎直答正文。')
    expect(result.outcome.sources).toHaveLength(1)
    expect(result.outcome.truncated).toBe(false)

    expect(calls).toHaveLength(2)
    const answerCall = calls[1]!
    expect(answerCall.init.method).toBe('POST')
    expect(answerCall.url.origin).toBe('https://developer.zhihu.com')
    expect(answerCall.url.pathname).toBe('/v1/chat/completions')
    expect(headerOf(answerCall, 'Authorization')).toBe('Bearer test-secret')
    expect(headerOf(answerCall, 'Content-Type')).toBe('application/json')
    // 官方直答文档只支持 model/messages/stream：请求体不带未承诺字段。
    expect(JSON.parse(String(answerCall.init.body))).toEqual({
      model: 'zhida-fast-1p5',
      messages: [{ role: 'user', content: '如何学习 Rust' }],
      stream: false,
    })
  })

  it('直答与主搜索并发：两个请求都在任一响应返回前发出，总耗时不接近两者之和', async () => {
    const DELAY_MS = 100
    const starts: number[] = []
    const ends: number[] = []
    const fetcher = (async (input: Parameters<typeof fetch>[0]): Promise<Response> => {
      const path = new URL(String(input)).pathname
      starts.push(Date.now())
      await new Promise((resolve) => setTimeout(resolve, DELAY_MS))
      ends.push(Date.now())
      return path === '/v1/chat/completions' ? jsonResponse(zhidaSuccess) : jsonResponse(globalSearchSuccess)
    }) as typeof fetch

    const startedAt = Date.now()
    const result = await createZhihuEngine({ fetcher }).search!(answerRequest, makeContext())
    const elapsed = Date.now() - startedAt

    expect(result.ok).toBe(true)
    if (!result.ok) throw new Error('期望搜索成功，实际失败')
    expect(result.outcome.content).toBe('这是知乎直答正文。')
    expect(starts).toHaveLength(2)
    expect(ends).toHaveLength(2)
    // 并发判据：第二个请求在第一个响应返回前已发出；串行实现下 max(starts) 必然晚于 min(ends)。
    expect(Math.max(...starts)).toBeLessThan(Math.min(...ends))
    // 时间判据：并发总耗时约为单次延迟；串行实现接近两次之和（200ms）。
    expect(elapsed).toBeLessThan(DELAY_MS * 1.7)
  })

  it.each([undefined, false])('wantAnswer=%s 时不调用直答', async (wantAnswer) => {
    const { result, calls } = await runSearchWithCalls(
      [jsonResponse(globalSearchSuccess)],
      { query: 'TypeScript', maxResults: 8, wantAnswer },
    )
    expect(result.ok).toBe(true)
    if (!result.ok) throw new Error('期望搜索成功，实际失败')
    expect(result.outcome.content).toBeUndefined()
    expect(calls).toHaveLength(1)
  })

  it('引擎级 answer:false 显式关闭直答，即使 wantAnswer=true', async () => {
    const { result, calls } = await runSearchWithCalls(
      [jsonResponse(globalSearchSuccess)],
      answerRequest,
      { answer: false },
    )
    expect(result.ok).toBe(true)
    if (!result.ok) throw new Error('期望搜索成功，实际失败')
    expect(result.outcome.content).toBeUndefined()
    expect(calls).toHaveLength(1)
  })

  it.each([
    ['HTTP 429', jsonResponse({}, 429, { 'retry-after': '2' })],
    [
      '网络异常',
      () => {
        throw new TypeError('fetch failed')
      },
    ],
    ['OpenAI 风格 error', jsonResponse({ error: { message: 'model_not_found', type: 'invalid_request_error' } })],
    ['空 choices', jsonResponse({ choices: [] })],
    ['空 content', jsonResponse({ choices: [{ message: { role: 'assistant', content: '   ' } }] })],
  ] as const)('直答失败（%s）→ fail-open：搜索成功且无 content', async (_label, answerResponse) => {
    const { result, calls } = await runSearchWithCalls(
      [jsonResponse(globalSearchSuccess), answerResponse],
      answerRequest,
    )
    expect(result.ok).toBe(true)
    if (!result.ok) throw new Error('期望搜索成功，实际失败')
    expect(result.outcome.content).toBeUndefined()
    expect(result.outcome.sources).toHaveLength(1)
    expect(calls).toHaveLength(2)
  })

  it('直答请求永不返回（短 deadline 触发超时）→ 搜索仍成功且 content undefined', async () => {
    const base = stubFetch([jsonResponse(globalSearchSuccess)])
    const paths: string[] = []
    const fetcher = (async (input: Parameters<typeof fetch>[0], init?: RequestInit): Promise<Response> => {
      const path = new URL(String(input)).pathname
      paths.push(path)
      if (path !== '/v1/chat/completions') return base.fetcher(input, init)
      // 永不返回响应；只随 abort 信号拒绝，模拟真实 fetch 的超时行为。
      return new Promise<Response>((_resolve, reject) => {
        const fail = (): void => reject(new DOMException('The operation was aborted.', 'AbortError'))
        const signal = init?.signal
        if (signal?.aborted === true) {
          fail()
          return
        }
        signal?.addEventListener('abort', fail, { once: true })
      })
    }) as typeof fetch

    const result = await createZhihuEngine({ fetcher }).search!(
      answerRequest,
      makeContext({ deadline: Date.now() + 50 }),
    )
    expect(result.ok).toBe(true)
    if (!result.ok) throw new Error('期望搜索成功，实际失败')
    expect(result.outcome.content).toBeUndefined()
    expect(result.outcome.sources).toHaveLength(1)
    expect(paths).toEqual(['/api/v1/content/global_search', '/v1/chat/completions'])
  })

  it('直答返回 2xx 非 JSON → 解析失败被吞掉，静默跳过', async () => {
    const { result, calls } = await runSearchWithCalls(
      [
        jsonResponse(globalSearchSuccess),
        new Response('not-json', { status: 200, headers: { 'content-type': 'text/plain' } }),
      ],
      answerRequest,
    )
    expect(result.ok).toBe(true)
    if (!result.ok) throw new Error('期望搜索成功，实际失败')
    expect(result.outcome.content).toBeUndefined()
    expect(result.outcome.sources).toHaveLength(1)
    expect(calls).toHaveLength(2)
  })

  it('预算只剩主搜索一次时，直答跳过且不发请求', async () => {
    let remaining = 1
    let countCalls = 0
    const countRequest = (): boolean => {
      countCalls += 1
      if (remaining <= 0) return false
      remaining -= 1
      return true
    }
    const { result, calls } = await runSearchWithCalls(
      [
        jsonResponse(globalSearchSuccess),
        () => {
          throw new Error('直答不应发请求')
        },
      ],
      answerRequest,
      {},
      makeContext({ countRequest }),
    )
    expect(result.ok).toBe(true)
    if (!result.ok) throw new Error('期望搜索成功，实际失败')
    expect(result.outcome.content).toBeUndefined()
    expect(countCalls).toBe(2)
    expect(calls).toHaveLength(1)
  })

  it('主搜索失败时直答结果直接丢弃，失败原样返回', async () => {
    const { result, calls } = await runSearchWithCalls(
      [jsonResponse({ Code: 30001, Message: '请求频率超过限制，请稍后重试', Data: null })],
      answerRequest,
    )
    expect(result.ok).toBe(false)
    if (result.ok) throw new Error('期望搜索失败，实际成功')
    expect(result.failure.kind).toBe('rate-limited')
    // 并发发起后搜索失败：直答请求已发出，但其结果不并入、也不影响失败投影。
    expect(calls).toHaveLength(2)
    expect(calls[1]!.url.pathname).toBe('/v1/chat/completions')
  })
})

describe('endpointOverride', () => {
  it('只覆盖请求地址，不改 manifest；搜索与额度都落到覆盖源的同路径', async () => {
    const { fetcher, calls } = stubFetch([jsonResponse(globalSearchSuccess), jsonResponse(quotaSuccess)])
    const engine = createZhihuEngine({
      fetcher,
      endpointOverride: 'https://mock.example/api/v1/content/global_search',
    })
    await engine.search!({ query: 'TypeScript', maxResults: 8 }, makeContext())
    await engine.quota!(makeQuotaContext({ endpoint: 'https://ignored.example/api/v1/quota' }))

    expect(calls[0]!.url.origin).toBe('https://mock.example')
    expect(calls[0]!.url.pathname).toBe('/api/v1/content/global_search')
    expect(calls[1]!.url.origin).toBe('https://mock.example')
    expect(calls[1]!.url.pathname).toBe('/api/v1/quota')
    expect(engine.manifest).toBe(ZHIHU_MANIFEST)
    expect(ZHIHU_MANIFEST.endpoints.search).toBe('https://developer.zhihu.com/api/v1/content/global_search')
  })
})

describe('问题回答 fetch 面（question_answers）', () => {
  const questionUrl = 'https://www.zhihu.com/question/123?utm_source=zhihu'
  const fetchContext = (overrides: Partial<EngineContext> = {}): EngineContext =>
    makeContext({ endpoint: ZHIHU_MANIFEST.endpoints.fetch ?? '', ...overrides })

  /** 字段逐字取自官方文档 https://developer.zhihu.com/docs?key=question_answers 的响应示例。 */
  const success = {
    Code: 0,
    Message: 'success',
    Data: {
      Items: [
        {
          ContentType: 'answer',
          ContentToken: '456',
          Url: 'https://www.zhihu.com/question/123/answer/456',
          Summary: '这是一段回答摘要……',
        },
        {
          ContentType: 'answer',
          ContentToken: '789',
          Url: 'https://www.zhihu.com/question/123/answer/789',
          Summary: '另一段回答摘要。',
        },
      ],
      Paging: { IsEnd: true, Totals: 2 },
    },
  }

  it('问题 URL → GET question_answers，QuestionUrl/Limit/鉴权头正确，正文含摘要与回答链接', async () => {
    const { fetcher, calls } = stubFetch([jsonResponse(success)])
    const result = await createZhihuEngine({ fetcher }).fetch!(questionUrl, fetchContext())

    expect(result.ok).toBe(true)
    if (!result.ok) throw new Error('期望提取成功，实际失败')
    expect(calls).toHaveLength(1)
    const call = calls[0]!
    expect(call.init.method).toBe('GET')
    expect(call.url.pathname).toBe('/api/v1/content/question_answers')
    expect(call.url.searchParams.get('QuestionUrl')).toBe(questionUrl)
    expect(call.url.searchParams.get('Limit')).toBe('20')
    expect(headerOf(call, 'Authorization')).toBe('Bearer test-secret')
    expect(headerOf(call, 'Content-Type')).toBe('application/json')
    expect(result.outcome.url).toBe(questionUrl)
    expect(result.outcome.statusCode).toBe(200)
    expect(result.outcome.body.kind).toBe('text')
    expect(result.outcome.body.content).toContain('这是一段回答摘要……')
    expect(result.outcome.body.content).toContain('https://www.zhihu.com/question/123/answer/456')
    expect(result.outcome.body.content).toContain('回答 456')
    expect(result.outcome.truncated).toBe(false)
  })

  it('非问题 URL → invalid，不发请求、不消费预算', async () => {
    let budgetCalls = 0
    const { fetcher, calls } = stubFetch([])
    const result = await createZhihuEngine({ fetcher }).fetch!(
      'https://www.zhihu.com/column/c_1',
      fetchContext({ countRequest: () => { budgetCalls += 1; return true } }),
    )

    expect(result.ok).toBe(false)
    if (result.ok) throw new Error('期望提取失败，实际成功')
    expect(result.failure.kind).toBe('invalid')
    expect(calls).toHaveLength(0)
    expect(budgetCalls).toBe(0)
  })

  it('问题 URL 但未配置 Access Secret → auth，且不发请求', async () => {
    const { fetcher, calls } = stubFetch([])
    const result = await createZhihuEngine({ fetcher }).fetch!(
      questionUrl,
      fetchContext({ apiKey: undefined }),
    )

    expect(result.ok).toBe(false)
    if (result.ok) throw new Error('期望提取失败，实际成功')
    expect(result.failure.kind).toBe('auth')
    expect(calls).toHaveLength(0)
  })

  it('Code 30001 → quota（问题发现日额度/频率二义），detail 保留 Message', async () => {
    const { fetcher } = stubFetch([
      jsonResponse({ Code: 30001, Message: '调用频率、并发限制或当日额度超过限制', Data: null }),
    ])
    const result = await createZhihuEngine({ fetcher }).fetch!(questionUrl, fetchContext())

    expect(result.ok).toBe(false)
    if (result.ok) throw new Error('期望提取失败，实际成功')
    expect(result.failure.kind).toBe('quota')
    expect(result.failure.cooldownable).toBe(true)
    expect(result.failure.detail).toContain('30001')
    expect(result.failure.detail).toContain('当日额度')
  })

  it('Items 为空 → 成功，正文给出空说明而非失败', async () => {
    const { fetcher } = stubFetch([
      jsonResponse({ Code: 0, Message: 'success', Data: { Items: [], Paging: { IsEnd: true, Totals: 0 } } }),
    ])
    const result = await createZhihuEngine({ fetcher }).fetch!(questionUrl, fetchContext())

    expect(result.ok).toBe(true)
    if (!result.ok) throw new Error('期望提取成功，实际失败')
    expect(result.outcome.body.content.trim().length).toBeGreaterThan(0)
    expect(result.outcome.body.content).toContain('没有可读取的回答摘要')
  })

  it('Paging.IsEnd=false → 只取首页并置 truncated', async () => {
    const { fetcher } = stubFetch([
      jsonResponse({
        ...success,
        Data: { ...success.Data, Paging: { IsEnd: false, NextOffset: 20, Totals: 100 } },
      }),
    ])
    const result = await createZhihuEngine({ fetcher }).fetch!(questionUrl, fetchContext())

    expect(result.ok).toBe(true)
    if (!result.ok) throw new Error('期望提取成功，实际失败')
    expect(result.outcome.truncated).toBe(true)
  })
})
