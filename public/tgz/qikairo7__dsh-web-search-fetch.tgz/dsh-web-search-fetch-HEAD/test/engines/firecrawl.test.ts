// 离线替身测试，不触网：所有 HTTP 请求由注入的 fetcher 替身应答，不启动真实进程/服务。
// 夹具形状来源：.scratch/dev-loop/recon/api-contracts/firecrawl.json
//   - search：endpoints[0].response（API reference 的 data.web[] 分组形状）
//   - scrape：endpoints[1].response（data.markdown + data.metadata.statusCode）
//   - quota ：endpoints[2].response（data.remainingCredits / planCredits / billingPeriodEnd）
// 分组/扁平冲突依据同文件 openQuestions：features/search 的示例给扁平 data[]，
// API reference 与 curl source-of-truth 给 data.web[]；本实现选择 data.web[]，夹具按分组形状构造。
// scrape 目标站状态透传依据 v0.2 src/engines/firecrawl/wire.ts（readFirecrawlScrapeSuccess）。

import { describe, expect, it } from 'vitest'
import type { EngineContext, EngineResult } from '../../src/engines/contract.js'
import type { EngineFailure } from '../../src/engines/failure.js'
import { createFirecrawlEngine } from '../../src/engines/firecrawl.js'
import { parseQuerySyntax } from '../../src/search/query-syntax.js'
import { FIRECRAWL_MANIFEST } from '../../src/engines/registry.js'

const SEARCH_ENDPOINT = FIRECRAWL_MANIFEST.endpoints.search!
const FETCH_ENDPOINT = FIRECRAWL_MANIFEST.endpoints.fetch!
const QUOTA_ENDPOINT = FIRECRAWL_MANIFEST.endpoints.quota!

interface RecordedRequest {
  readonly url: string
  readonly init: RequestInit
}

function createFetcher(handler: (url: string, init: RequestInit) => Response | Promise<Response>) {
  const requests: RecordedRequest[] = []
  const fetcher = (async (input: Parameters<typeof fetch>[0], init?: RequestInit) => {
    const url = typeof input === 'string'
      ? input
      : input instanceof URL
        ? input.href
        : input.url
    const requestInit = init ?? {}
    requests.push({ url, init: requestInit })
    return await handler(url, requestInit)
  }) as typeof fetch
  return { fetcher, requests }
}

function jsonResponse(body: unknown, status = 200, headers: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json', ...headers },
  })
}

function context(overrides: Partial<EngineContext> = {}): EngineContext {
  return {
    signal: new AbortController().signal,
    deadline: Date.now() + 30_000,
    apiKey: 'fc-test-key',
    endpoint: SEARCH_ENDPOINT,
    countRequest: () => true,
    ...overrides,
  }
}

function outcomeOf<T>(result: EngineResult<T>): T {
  if (!result.ok) throw new Error(`expected success, got ${result.failure.kind}: ${result.failure.detail ?? ''}`)
  return result.outcome
}

function failureOf<T>(result: EngineResult<T>): EngineFailure {
  if (result.ok) throw new Error('expected failure, got success')
  return result.failure
}

function headersOf(init: RequestInit): Record<string, string> {
  return (init.headers ?? {}) as Record<string, string>
}

function bodyOf(init: RequestInit): unknown {
  if (typeof init.body !== 'string') throw new Error('expected a string request body')
  return JSON.parse(init.body)
}

/** 契约 endpoints[0].response 的示例形状：分组 data.web[] + 顶层 success/id/creditsUsed。 */
const SEARCH_RESPONSE = {
  success: true,
  data: {
    web: [
      {
        title: 'Result A',
        description: '摘要 A',
        url: 'https://a.example/article',
        markdown: '# A 正文',
        html: null,
        rawHtml: null,
        links: [],
        screenshot: null,
        audio: null,
        video: null,
        metadata: { title: 'Result A', sourceURL: 'https://a.example/article', statusCode: 200 },
      },
      { title: 'Result B', description: '', url: 'https://b.example/article' },
      { title: '没有 URL 的条目', description: '应被丢弃' },
      { title: '相对 URL', description: '应被丢弃', url: '/relative' },
      'not-an-object',
    ],
  },
  warning: null,
  id: 'search-job-fixture',
  creditsUsed: 2,
}

/** 契约 endpoints[1].response 的示例形状。 */
const SCRAPE_RESPONSE = {
  success: true,
  data: {
    markdown: '# 标题\n\n正文内容。',
    metadata: {
      title: '标题',
      sourceURL: 'https://example.com/page',
      url: 'https://example.com/page',
      statusCode: 200,
      contentType: 'text/html; charset=UTF-8',
    },
  },
}

/** 契约 endpoints[2].response 的示例形状。 */
const QUOTA_RESPONSE = {
  success: true,
  data: {
    remainingCredits: 123,
    planCredits: 500,
    billingPeriodStart: '2026-11-01T00:00:00.000Z',
    billingPeriodEnd: '2026-12-01T00:00:00.000Z',
  },
}

describe('createFirecrawlEngine 搜索映射', () => {
  it('POST /v2/search：Bearer + query/limit 请求体，按 data.web[] 映射 sources', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SEARCH_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })

    const outcome = outcomeOf(await engine.search!({ query: 'deepseek 搜索', maxResults: 5 }, context()))

    expect(requests).toHaveLength(1)
    const request = requests[0]!
    expect(request.url).toBe(SEARCH_ENDPOINT)
    expect(request.init.method).toBe('POST')
    expect(headersOf(request.init).authorization).toBe('Bearer fc-test-key')
    expect(headersOf(request.init)['content-type']).toBe('application/json')
    expect(bodyOf(request.init)).toEqual({ query: 'deepseek 搜索', limit: 5 })

    // description→snippet；空 description 与无 URL/相对 URL/非对象条目都被丢弃；markdown 不外泄。
    expect(outcome.sources).toEqual([
      { url: 'https://a.example/article', title: 'Result A', snippet: '摘要 A' },
      { url: 'https://b.example/article', title: 'Result B' },
    ])
    expect(outcome.truncated).toBe(false)
    expect(outcome.content).toBeUndefined()
  })

  it('maxResults > 100：limit 截到 100 且 truncated=true', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse({ success: true, data: { web: [] } }))
    const engine = createFirecrawlEngine({ fetcher })

    const outcome = outcomeOf(await engine.search!({ query: 'q', maxResults: 150 }, context()))

    expect(bodyOf(requests[0]!.init)).toEqual({ query: 'q', limit: 100 })
    expect(outcome.truncated).toBe(true)
  })

  it('maxResults=0：返回空结果且不发请求（不多要 1 条）', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SEARCH_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })

    const outcome = outcomeOf(await engine.search!({ query: 'q', maxResults: 0 }, context()))

    expect(outcome).toEqual({ sources: [], truncated: false })
    expect(requests).toHaveLength(0)
  })

  it('响应条目多于 limit：只取前 limit 条且 truncated=true', async () => {
    const { fetcher } = createFetcher(() => jsonResponse(SEARCH_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })

    const outcome = outcomeOf(await engine.search!({ query: 'q', maxResults: 2 }, context()))

    expect(outcome.sources.map(source => source.url)).toEqual([
      'https://a.example/article',
      'https://b.example/article',
    ])
    expect(outcome.truncated).toBe(true)
  })

  it('endpointOverride 作为代理基点覆盖三类请求 URL，manifest 保持不变', async () => {
    const { fetcher, requests } = createFetcher(url => {
      if (url.endsWith('/v2/team/credit-usage')) return jsonResponse(QUOTA_RESPONSE)
      if (url.endsWith('/v2/scrape')) return jsonResponse(SCRAPE_RESPONSE)
      return jsonResponse(SEARCH_RESPONSE)
    })
    const engine = createFirecrawlEngine({ fetcher, endpointOverride: 'https://proxy.example.com/firecrawl' })

    await engine.search!({ query: 'q', maxResults: 1 }, context())
    await engine.fetch!('https://example.com/page', context())
    await engine.quota!(context())

    expect(requests.map(request => request.url)).toEqual([
      'https://proxy.example.com/firecrawl/v2/search',
      'https://proxy.example.com/firecrawl/v2/scrape',
      'https://proxy.example.com/firecrawl/v2/team/credit-usage',
    ])
    expect(FIRECRAWL_MANIFEST.endpoints.search).toBe('https://api.firecrawl.dev/v2/search')
  })

  it('endpointOverride 指向另一个操作的端点：保留代理 origin、换成目标操作路径，不回落官方域', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SCRAPE_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher, endpointOverride: 'https://proxy.example.com/v2/search' })

    await engine.fetch!('https://example.com/page', context())

    expect(requests[0]!.url).toBe('https://proxy.example.com/v2/scrape')
  })

  it('endpointOverride 带路径前缀且指向另一操作端点：前缀保留，只换端点路径', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SCRAPE_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher, endpointOverride: 'https://proxy.example.com/firecrawl/v2/search' })

    await engine.fetch!('https://example.com/page', context())

    expect(requests[0]!.url).toBe('https://proxy.example.com/firecrawl/v2/scrape')
  })
})

describe('createFirecrawlEngine AD13 查询语法映射', () => {
  it('仅 site: → includeDomains，请求 query 不含该 token', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SEARCH_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })
    const query = 'deepseek 教程 site:github.com'

    await engine.search!({ query, maxResults: 5, syntax: parseQuerySyntax(query) }, context())

    expect(bodyOf(requests[0]!.init)).toEqual({
      query: 'deepseek 教程',
      limit: 5,
      includeDomains: ['github.com'],
    })
  })

  it('仅 -site: → excludeDomains，请求 query 不含该 token', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SEARCH_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })
    const query = 'deepseek 教程 -site:medium.com'

    await engine.search!({ query, maxResults: 5, syntax: parseQuerySyntax(query) }, context())

    expect(bodyOf(requests[0]!.init)).toEqual({
      query: 'deepseek 教程',
      limit: 5,
      excludeDomains: ['medium.com'],
    })
  })

  it('site: 与 -site: 并存：契约互斥无法原生表达，不发域名参数且两个 raw 逐字保留', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SEARCH_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })
    const query = 'deepseek site:GitHub.com/Docs -site:Medium.com/RSS'

    await engine.search!({ query, maxResults: 5, syntax: parseQuerySyntax(query) }, context())

    expect(bodyOf(requests[0]!.init)).toEqual({
      query: 'deepseek site:GitHub.com/Docs -site:Medium.com/RSS',
      limit: 5,
    })
  })

  it('lang/after/before 无原生参数：按原出现顺序回拼 raw，大小写逐字保留', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SEARCH_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })
    const query = 'deepseek site:github.com lang:ZH after:2026-01 before:2026-12-31'

    await engine.search!({ query, maxResults: 5, syntax: parseQuerySyntax(query) }, context())

    expect(bodyOf(requests[0]!.init)).toEqual({
      query: 'deepseek lang:ZH after:2026-01 before:2026-12-31',
      limit: 5,
      includeDomains: ['github.com'],
    })
  })

  it('组合后 query 为空（操作符全部被映射）→ 用 request.query 原文', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SEARCH_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })
    const query = 'site:github.com'

    await engine.search!({ query, maxResults: 5, syntax: parseQuerySyntax(query) }, context())

    expect(bodyOf(requests[0]!.init)).toEqual({
      query: 'site:github.com',
      limit: 5,
      includeDomains: ['github.com'],
    })
  })

  it('syntax 缺省：行为不变，query 逐字透传（不解析、不回拼）', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SEARCH_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })
    const query = '  deepseek   site:github.com  '

    await engine.search!({ query, maxResults: 5 }, context())

    expect((bodyOf(requests[0]!.init) as { query: string }).query).toBe(query)
  })
})

describe('createFirecrawlEngine 提取映射', () => {
  it('POST /v2/scrape：formats:[{type:"markdown"}]，data.markdown → kind:text，statusCode 200', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SCRAPE_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })

    const outcome = outcomeOf(
      await engine.fetch!('https://example.com/page', context({ endpoint: FETCH_ENDPOINT })),
    )

    expect(requests).toHaveLength(1)
    const request = requests[0]!
    expect(request.url).toBe(FETCH_ENDPOINT)
    expect(request.init.method).toBe('POST')
    expect(headersOf(request.init).authorization).toBe('Bearer fc-test-key')
    expect(bodyOf(request.init)).toEqual({
      url: 'https://example.com/page',
      formats: [{ type: 'markdown' }],
      maxAge: 0,
    })
    expect(outcome).toEqual({
      url: 'https://example.com/page',
      statusCode: 200,
      body: { kind: 'text', content: '# 标题\n\n正文内容。' },
      truncated: false,
    })
  })

  it('metadata.url 与请求 URL 不同：outcome.url 取重定向后的最终 URL', async () => {
    const { fetcher } = createFetcher(() =>
      jsonResponse({
        success: true,
        data: {
          markdown: '最终页面',
          metadata: { sourceURL: 'https://example.com/old', url: 'https://example.com/final', statusCode: 200 },
        },
      }),
    )
    const engine = createFirecrawlEngine({ fetcher })

    const outcome = outcomeOf(
      await engine.fetch!('https://example.com/old', context({ endpoint: FETCH_ENDPOINT })),
    )

    expect(outcome.url).toBe('https://example.com/final')
  })

  it('metadata.url 缺失：outcome.url 回落请求 URL', async () => {
    const { fetcher } = createFetcher(() =>
      jsonResponse({ success: true, data: { markdown: '正文', metadata: { statusCode: 200 } } }),
    )
    const engine = createFirecrawlEngine({ fetcher })

    const outcome = outcomeOf(
      await engine.fetch!('https://example.com/page', context({ endpoint: FETCH_ENDPOINT })),
    )

    expect(outcome.url).toBe('https://example.com/page')
  })

  it('目标站 4xx 是结果不是错误：metadata.statusCode 透传（seam 契约）', async () => {
    const { fetcher } = createFetcher(() =>
      jsonResponse({
        success: true,
        data: { markdown: '页面不存在', metadata: { statusCode: 404 } },
      }),
    )
    const engine = createFirecrawlEngine({ fetcher })

    const outcome = outcomeOf(
      await engine.fetch!('https://example.com/missing', context({ endpoint: FETCH_ENDPOINT })),
    )

    expect(outcome.statusCode).toBe(404)
    expect(outcome.body).toEqual({ kind: 'text', content: '页面不存在' })
  })

  it('缺少 data.markdown → provider-error', async () => {
    const { fetcher } = createFetcher(() => jsonResponse({ success: true, data: { metadata: {} } }))
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(
      await engine.fetch!('https://example.com/page', context({ endpoint: FETCH_ENDPOINT })),
    )

    expect(failure).toMatchObject({ kind: 'provider-error', statusCode: 200 })
    expect(failure.detail).toContain('data.markdown')
  })

  it('envelope success:false → provider-error，error 字段进 detail', async () => {
    const { fetcher } = createFetcher(() =>
      jsonResponse({ success: false, error: 'Scrape failed: target blocked', code: 'SCRAPE_FAILED' }),
    )
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(
      await engine.fetch!('https://example.com/page', context({ endpoint: FETCH_ENDPOINT })),
    )

    expect(failure.kind).toBe('provider-error')
    expect(failure.detail).toContain('Scrape failed: target blocked')
    expect(failure.detail).toContain('SCRAPE_FAILED')
  })

  it('HTTP 200 信封 code=insufficient_credits → quota（熔断信号不丢失）', async () => {
    const { fetcher } = createFetcher(() =>
      jsonResponse({ success: false, code: 'insufficient_credits', error: 'Insufficient credits' }),
    )
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(
      await engine.fetch!('https://example.com/page', context({ endpoint: FETCH_ENDPOINT })),
    )

    expect(failure).toMatchObject({ kind: 'quota', statusCode: 200, quotaExhausted: true })
  })
})

describe('createFirecrawlEngine 失败投影', () => {
  it('429 → rate-limited，保留 Retry-After 毫秒提示', async () => {
    const { fetcher } = createFetcher(() =>
      jsonResponse({ success: false, error: 'Rate limit exceeded' }, 429, { 'retry-after': '7' }),
    )
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(await engine.search!({ query: 'q', maxResults: 5 }, context()))

    expect(failure).toMatchObject({
      kind: 'rate-limited',
      statusCode: 429,
      retryAfterMs: 7000,
      cooldownable: true,
    })
  })

  it('402 → quota（quotaExhausted=true）', async () => {
    const { fetcher } = createFetcher(() =>
      jsonResponse({ success: false, error: 'Insufficient credits' }, 402),
    )
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(await engine.search!({ query: 'q', maxResults: 5 }, context()))

    expect(failure).toMatchObject({ kind: 'quota', statusCode: 402, quotaExhausted: true })
  })

  it.each([401, 403])('%i → auth，且不冷却', async status => {
    const { fetcher } = createFetcher(() => jsonResponse({ success: false, error: 'Invalid token' }, status))
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(await engine.search!({ query: 'q', maxResults: 5 }, context()))

    expect(failure).toMatchObject({ kind: 'auth', statusCode: status, cooldownable: false })
  })

  it('500 → provider-error', async () => {
    const { fetcher } = createFetcher(() => jsonResponse({ success: false, error: 'boom' }, 500))
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(await engine.search!({ query: 'q', maxResults: 5 }, context()))

    expect(failure).toMatchObject({ kind: 'provider-error', statusCode: 500 })
  })

  it('2xx 非 JSON → provider-error（解析失败）', async () => {
    const { fetcher } = createFetcher(() => new Response('not json', { status: 200 }))
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(await engine.search!({ query: 'q', maxResults: 5 }, context()))

    expect(failure).toMatchObject({ kind: 'provider-error', statusCode: 200 })
    expect(failure.detail).toContain('非 JSON')
  })

  it('envelope success:false → provider-error，error 字段进 detail', async () => {
    const { fetcher } = createFetcher(() =>
      jsonResponse({ success: false, error: 'Invalid request', code: 'BAD_REQUEST' }),
    )
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(await engine.search!({ query: 'q', maxResults: 5 }, context()))

    expect(failure.kind).toBe('provider-error')
    expect(failure.detail).toContain('Invalid request')
    expect(failure.detail).toContain('BAD_REQUEST')
  })

  it('HTTP 200 信封 code=rate_limit → rate-limited（v0.2 classifyFirecrawlHttpFailure 同义）', async () => {
    const { fetcher } = createFetcher(() =>
      jsonResponse({ success: false, code: 'rate_limit', error: 'Rate limit exceeded' }),
    )
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(await engine.search!({ query: 'q', maxResults: 5 }, context()))

    expect(failure).toMatchObject({ kind: 'rate-limited', statusCode: 200, cooldownable: true })
  })

  it('成功 envelope 缺少 data.web[] → provider-error（不做扁平形状兼容）', async () => {
    const { fetcher } = createFetcher(() => jsonResponse({ success: true, data: { images: [] } }))
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(await engine.search!({ query: 'q', maxResults: 5 }, context()))

    expect(failure.kind).toBe('provider-error')
    expect(failure.detail).toContain('data.web')
  })

  it('网络层失败 → network', async () => {
    const { fetcher } = createFetcher(() => {
      throw new Error('ECONNRESET')
    })
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(await engine.search!({ query: 'q', maxResults: 5 }, context()))

    expect(failure.kind).toBe('network')
    expect(failure.detail).toContain('ECONNRESET')
  })

  it('请求预算耗尽 → aborted，且请求未发出', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SEARCH_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(
      await engine.search!({ query: 'q', maxResults: 5 }, context({ countRequest: () => false })),
    )

    expect(failure.kind).toBe('aborted')
    expect(failure.detail).toContain('预算')
    expect(requests).toHaveLength(0)
  })

  it('调用方已取消 → aborted', async () => {
    const controller = new AbortController()
    controller.abort()
    const { fetcher } = createFetcher(() => {
      throw new DOMException('Aborted', 'AbortError')
    })
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(
      await engine.search!({ query: 'q', maxResults: 5 }, context({ signal: controller.signal })),
    )

    expect(failure.kind).toBe('aborted')
  })

  it('空查询 → invalid，且请求未发出', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SEARCH_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(await engine.search!({ query: '   ', maxResults: 5 }, context()))

    expect(failure).toMatchObject({ kind: 'invalid', cooldownable: false })
    expect(requests).toHaveLength(0)
  })

  it('非法提取 URL → invalid，且请求未发出', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SCRAPE_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(await engine.fetch!('ftp://example.com/file', context()))

    expect(failure).toMatchObject({ kind: 'invalid', cooldownable: false })
    expect(requests).toHaveLength(0)
  })
})

describe('createFirecrawlEngine 鉴权分支（提取免钥；搜索与额度需 key）', () => {
  it('ctx.apiKey 缺省 → auth 失败且不发请求，绝不降级匿名', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SEARCH_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(
      await engine.search!({ query: 'q', maxResults: 5 }, context({ apiKey: undefined })),
    )

    expect(failure.kind).toBe('auth')
    expect(requests).toHaveLength(0)
  })

  it('空白 key 同样按缺省处理', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SEARCH_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(
      await engine.search!({ query: 'q', maxResults: 5 }, context({ apiKey: '   ' })),
    )

    expect(failure.kind).toBe('auth')
    expect(requests).toHaveLength(0)
  })

  it('提取面免钥：无 key 匿名请求成功，请求头不带 authorization', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SCRAPE_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })

    const outcome = outcomeOf(
      await engine.fetch!('https://example.com/page', context({ apiKey: undefined, endpoint: FETCH_ENDPOINT })),
    )

    expect(requests).toHaveLength(1)
    const request = requests[0]!
    expect(request.init.method).toBe('POST')
    expect(headersOf(request.init)).not.toHaveProperty('authorization')
    expect(bodyOf(request.init)).toEqual({
      url: 'https://example.com/page',
      formats: [{ type: 'markdown' }],
      maxAge: 0,
    })
    expect(outcome.body).toEqual({ kind: 'text', content: '# 标题\n\n正文内容。' })
  })

  it('自定义端点 + 无 key → auth 失败且不发请求（免钥仅限官方端点）', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SCRAPE_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })

    const failure = failureOf(
      await engine.fetch!(
        'https://example.com/page',
        context({ apiKey: undefined, endpoint: 'https://proxy.example.com/v2/scrape' }),
      ),
    )

    expect(failure.kind).toBe('auth')
    expect(failure.detail).toContain('官方端点')
    expect(requests).toHaveLength(0)
  })

  it('自定义端点 + 有 key → 照常请求并携带 authorization', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(SCRAPE_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })

    const outcome = outcomeOf(
      await engine.fetch!(
        'https://example.com/page',
        context({ endpoint: 'https://proxy.example.com/v2/scrape' }),
      ),
    )

    expect(requests).toHaveLength(1)
    expect(requests[0]!.url).toBe('https://proxy.example.com/v2/scrape')
    expect(headersOf(requests[0]!.init).authorization).toBe('Bearer fc-test-key')
    expect(outcome.body).toEqual({ kind: 'text', content: '# 标题\n\n正文内容。' })
  })

  it('额度面免钥不可用：auth 失败、detail 含 keyless，请求计数 0', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(QUOTA_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })

    const quota = await engine.quota!(context({ apiKey: undefined, endpoint: QUOTA_ENDPOINT }))

    expect(quota).toMatchObject({ engineId: 'firecrawl', available: false })
    expect(quota.raw).toContain('keyless')
    expect(requests).toHaveLength(0)
  })
})

describe('createFirecrawlEngine 额度映射', () => {
  it('GET /v2/team/credit-usage → remaining/limit/resetsAt/raw', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(QUOTA_RESPONSE))
    const engine = createFirecrawlEngine({ fetcher })

    const report = await engine.quota!(context({ endpoint: QUOTA_ENDPOINT }))

    expect(requests).toHaveLength(1)
    const request = requests[0]!
    expect(request.url).toBe(QUOTA_ENDPOINT)
    expect(request.init.method).toBe('GET')
    expect(headersOf(request.init).authorization).toBe('Bearer fc-test-key')
    expect(report).toMatchObject({
      engineId: 'firecrawl',
      available: true,
      remaining: 123,
      limit: 500,
      resetsAt: '2026-12-01T00:00:00.000Z',
    })
    expect(report.raw).toContain('remainingCredits')
  })

  it('billingPeriodEnd 缺失：省略 resetsAt，不拿已过去的 billingPeriodStart 冒充', async () => {
    const { fetcher } = createFetcher(() =>
      jsonResponse({
        success: true,
        data: { remainingCredits: 7, planCredits: 500, billingPeriodStart: '2026-11-01T00:00:00.000Z' },
      }),
    )
    const engine = createFirecrawlEngine({ fetcher })

    const report = await engine.quota!(context({ endpoint: QUOTA_ENDPOINT }))

    expect(report.available).toBe(true)
    expect(report.remaining).toBe(7)
    expect(report).not.toHaveProperty('resetsAt')
  })

  it('额度端点失败不抛出：available=false，raw 带失败分类', async () => {
    const { fetcher } = createFetcher(() => jsonResponse({ success: false, error: 'Invalid token' }, 401))
    const engine = createFirecrawlEngine({ fetcher })

    const report = await engine.quota!(context({ endpoint: QUOTA_ENDPOINT }))

    expect(report.available).toBe(false)
    expect(report.raw).toContain('auth')
    expect(report.raw).toContain('401')
  })

  it('额度 envelope success:false → available=false，raw 带上游 error', async () => {
    const { fetcher } = createFetcher(() =>
      jsonResponse({ success: false, error: 'Could not find credit usage information' }),
    )
    const engine = createFirecrawlEngine({ fetcher })

    const report = await engine.quota!(context({ endpoint: QUOTA_ENDPOINT }))

    expect(report.available).toBe(false)
    expect(report.raw).toContain('Could not find credit usage information')
  })

  it('网络失败同样收敛为 available=false，不抛出', async () => {
    const { fetcher } = createFetcher(() => {
      throw new Error('socket hang up')
    })
    const engine = createFirecrawlEngine({ fetcher })

    const report = await engine.quota!(context({ endpoint: QUOTA_ENDPOINT }))

    expect(report).toMatchObject({ engineId: 'firecrawl', available: false })
    expect(report.raw).toContain('network')
  })
})
