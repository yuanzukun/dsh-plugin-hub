/**
 * 离线替身测试，不触网：所有 HTTP 由注入的 fetcher 替身应答。
 *
 * 夹具形状来源（未编造字段）：
 * - 官方 OpenAPI `https://aihot.news/openapi-v1.json` 的 components.schemas.ItemsResponse / Item / Page
 *   （schemaVersion=1、items[]、page.hasMore；Item 的 source.name、links.original/aihot、attribution）；
 * - v0.2 `src/engines/additional/adapters.ts:50-76`（case 'aihot'）：/api/v1/items?mode=all&window=7d&q&limit、
 *   items→sources 映射、page.hasMore→truncated；
 * - v0.2 `src/engines/additional/http.ts`：ETag/304 条件缓存与 429/503 冷却语义。
 */

import { afterEach, describe, expect, it, vi } from 'vitest'
import { createAihotApiReader, createAihotEngine } from '../../src/engines/aihot.js'
import type { Engine, EngineContext, EngineResult, EngineSearchOutcome } from '../../src/engines/contract.js'
import { AIHOT_MANIFEST } from '../../src/engines/registry.js'
import { parseQuerySyntax } from '../../src/search/query-syntax.js'

const ENDPOINT = 'https://aihot.news/api/v1/items'

/** 一条完整 Item + 一条无可选摘要的 Item + 一条原文 URL 非法的 Item（v0.2 在 seam 映射层过滤）。 */
const ITEMS: readonly Record<string, unknown>[] = [
  {
    id: 'item-1',
    title: 'DeepSeek 发布 V4',
    originalTitle: 'DeepSeek releases V4',
    summary: '新模型摘要',
    source: { name: '机器之心' },
    links: { aihot: 'https://aihot.news/items/item-1', original: 'https://example.com/deepseek-v4' },
    publishedAt: '2026-11-06T08:00:00Z',
    discoveredAt: '2026-11-06T09:00:00Z',
    category: 'ai-models',
    score: 88,
    selected: true,
    attribution: { name: 'AIHOT', url: 'https://aihot.news' },
  },
  {
    id: 'item-2',
    title: '第二条资讯',
    originalTitle: null,
    summary: null,
    source: { name: '量子位' },
    links: { aihot: 'https://aihot.news/items/item-2', original: 'https://example.com/second' },
    publishedAt: '2026-11-05T08:00:00Z',
    discoveredAt: '2026-11-05T09:00:00Z',
    category: 'industry',
    score: null,
    selected: false,
  },
  {
    id: 'item-3',
    title: '无原文链接的条目',
    originalTitle: null,
    summary: '没有 original 的条目',
    source: { name: 'AIHOT' },
    links: { aihot: 'https://aihot.news/items/item-3', original: '' },
    publishedAt: null,
    discoveredAt: '2026-11-04T09:00:00Z',
    category: null,
    score: 10,
    selected: false,
  },
]

const BASE = {
  schemaVersion: 1,
  query: { mode: 'all', category: null, window: '7d', q: 'DeepSeek', by: 'timeline', ordering: 'timelineDesc' },
  items: ITEMS,
  page: { count: ITEMS.length, hasMore: true, nextCursor: 'opaque-cursor' },
}

interface FetchCall {
  readonly url: string
  readonly init: RequestInit
}

/** 注入式 fetcher 替身：记录每次请求的 URL 与 init。 */
function fakeFetch(handler: (url: string, init: RequestInit) => Response | Promise<Response>): {
  fetcher: typeof fetch
  calls: FetchCall[]
} {
  const calls: FetchCall[] = []
  const fetcher: typeof fetch = async (input, init) => {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url
    const options = init ?? {}
    calls.push({ url, init: options })
    return await handler(url, options)
  }
  return { fetcher, calls }
}

function json(body: unknown, init: ResponseInit = {}): Response {
  const headers = new Headers(init.headers)
  headers.set('content-type', 'application/json')
  return new Response(JSON.stringify(body), { ...init, headers })
}

function upstream(status: number, headers: Record<string, string> = {}, body = 'upstream error'): Response {
  return new Response(body, { status, headers })
}

function context(overrides: Partial<EngineContext> = {}): EngineContext {
  return {
    signal: new AbortController().signal,
    deadline: Date.now() + 5_000,
    endpoint: ENDPOINT,
    countRequest: () => true,
    ...overrides,
  }
}

async function runSearch(
  engine: Engine,
  query = 'DeepSeek',
  maxResults = 8,
  ctx: EngineContext = context(),
): Promise<EngineResult<EngineSearchOutcome>> {
  if (engine.search === undefined) throw new Error('测试引擎缺少 search 能力')
  return await engine.search({ query, maxResults }, ctx)
}

function failureOf(result: EngineResult<unknown>) {
  if (result.ok) throw new Error('期望失败结果，实际成功')
  return result.failure
}

afterEach(() => {
  vi.restoreAllMocks()
})

describe('AihotEngine.search 成功映射', () => {
  it('items → seam sources 逐字段映射，page.hasMore → truncated，匿名模式不带鉴权头', async () => {
    const { fetcher, calls } = fakeFetch(() => json(BASE))
    const engine = createAihotEngine({ fetcher })

    const result = await runSearch(engine, 'DeepSeek V4', 8, context({ apiKey: 'anonymous-must-ignore-key' }))
    expect(result).toEqual({
      ok: true,
      outcome: {
        sources: [
          {
            url: 'https://example.com/deepseek-v4',
            title: 'DeepSeek 发布 V4',
            snippet: '新模型摘要\n来源：机器之心\nAIHOT：https://aihot.news/items/item-1\n数据归属：AIHOT https://aihot.news',
            summary: '新模型摘要',
            publishedAt: '2026-11-06T08:00:00Z',
          },
          {
            url: 'https://example.com/second',
            title: '第二条资讯',
            snippet: '来源：量子位\nAIHOT：https://aihot.news/items/item-2',
            publishedAt: '2026-11-05T08:00:00Z',
          },
        ],
        truncated: true,
      },
    })
    if (!result.ok) return
    expect(result.outcome.content).toBeUndefined()

    expect(calls).toHaveLength(1)
    const url = new URL(calls[0]!.url)
    expect(url.origin).toBe('https://aihot.news')
    expect(url.pathname).toBe('/api/v1/items')
    expect(url.searchParams.get('mode')).toBe('all')
    expect(url.searchParams.get('window')).toBe('7d')
    expect(url.searchParams.get('q')).toBe('DeepSeek V4')
    expect(url.searchParams.get('limit')).toBe('8')
    expect(calls[0]!.init.method).toBe('GET')
    const headers = new Headers(calls[0]!.init.headers)
    expect(headers.get('accept')).toBe('application/json')
    expect(headers.get('authorization')).toBeNull()
    expect(headers.get('x-api-key')).toBeNull()
  })

  it('hasMore=false 且结果未超 maxResults 时 truncated=false', async () => {
    const response = { ...BASE, page: { count: 2, hasMore: false, nextCursor: null } }
    const { fetcher } = fakeFetch(() => json(response))
    const result = await runSearch(createAihotEngine({ fetcher }), 'DeepSeek', 8)
    if (!result.ok) throw new Error('期望成功结果')
    expect(result.outcome.sources).toHaveLength(2)
    expect(result.outcome.truncated).toBe(false)
  })

  it('服务端返回超过 maxResults 时按 maxResults 截断并置 truncated（AD8）', async () => {
    const response = { ...BASE, page: { count: 2, hasMore: false, nextCursor: null } }
    const { fetcher } = fakeFetch(() => json(response))
    const result = await runSearch(createAihotEngine({ fetcher }), 'DeepSeek', 1)
    if (!result.ok) throw new Error('期望成功结果')
    expect(result.outcome.sources).toEqual([
      {
        url: 'https://example.com/deepseek-v4',
        title: 'DeepSeek 发布 V4',
        snippet: '新模型摘要\n来源：机器之心\nAIHOT：https://aihot.news/items/item-1\n数据归属：AIHOT https://aihot.news',
        summary: '新模型摘要',
        publishedAt: '2026-11-06T08:00:00Z',
      },
    ])
    expect(result.outcome.truncated).toBe(true)
  })

  it('请求 limit 钳制到上游允许的 1–100', async () => {
    const { fetcher, calls } = fakeFetch(() => json(BASE))
    const engine = createAihotEngine({ fetcher })
    await runSearch(engine, 'Alpha query', 250)
    await runSearch(engine, 'Beta query', 0)
    expect(new URL(calls[0]!.url).searchParams.get('limit')).toBe('100')
    expect(new URL(calls[1]!.url).searchParams.get('limit')).toBe('1')
  })

  it('endpointOverride 只改请求 URL，不改 manifest', async () => {
    const { fetcher, calls } = fakeFetch(() => json(BASE))
    const engine = createAihotEngine({ fetcher, endpointOverride: 'https://mock.test/custom/items?tenant=demo' })
    await runSearch(engine, 'DeepSeek', 8)
    const url = new URL(calls[0]!.url)
    expect(url.origin).toBe('https://mock.test')
    expect(url.pathname).toBe('/custom/items')
    expect(url.searchParams.get('tenant')).toBe('demo')
    expect(url.searchParams.get('q')).toBe('DeepSeek')
    expect(AIHOT_MANIFEST.endpoints.search).toBe(ENDPOINT)
  })

  it('manifest 已回填真实端点，匿名模式且不实现 fetch/quota', () => {
    expect(AIHOT_MANIFEST.endpoints.search).toBe(ENDPOINT)
    expect(AIHOT_MANIFEST.auth).toBe('anonymous')
    const engine = createAihotEngine({ fetcher: fakeFetch(() => json(BASE)).fetcher })
    expect(engine.manifest).toBe(AIHOT_MANIFEST)
    expect(engine.fetch).toBeUndefined()
    expect(engine.quota).toBeUndefined()
  })
})

describe('查询与端点校验', () => {
  it('查询不足 2 或超过 200 个字符 → invalid，且不发请求', async () => {
    const { fetcher, calls } = fakeFetch(() => json(BASE))
    const engine = createAihotEngine({ fetcher })
    for (const query of ['', ' a ', 'x', '字'.repeat(201)]) {
      const failure = failureOf(await runSearch(engine, query, 8))
      expect(failure.kind).toBe('invalid')
      expect(failure.detail).toContain('2–200')
    }
    expect(calls).toHaveLength(0)
  })

  it('非法端点 URL → invalid，且不发请求', async () => {
    const { fetcher, calls } = fakeFetch(() => json(BASE))
    for (const endpointOverride of ['ftp://aihot.news/items', 'not a url', 'https://user@aihot.news/items']) {
      const engine = createAihotEngine({ fetcher, endpointOverride })
      expect(failureOf(await runSearch(engine, 'DeepSeek', 8)).kind).toBe('invalid')
    }
    expect(calls).toHaveLength(0)
  })
})

describe('AD13 查询语法接线（items API 无原生操作符参数，全部回拼）', () => {
  it('site: token 回拼进 q，bareQuery 其余词保留', async () => {
    const { fetcher, calls } = fakeFetch(() => json(BASE))
    const engine = createAihotEngine({ fetcher })
    const query = 'site:example.com DeepSeek'
    const syntax = parseQuerySyntax(query)
    expect(syntax.bareQuery).toBe('DeepSeek')
    expect(syntax.domains).toEqual(['example.com'])

    const result = await engine.search!({ query, maxResults: 8, syntax }, context())
    expect(result.ok).toBe(true)
    expect(new URL(calls[0]!.url).searchParams.get('q')).toBe('DeepSeek site:example.com')
  })

  it('域名/排除域名/语言/日期操作符逐 token 回拼，不静默丢弃', async () => {
    const { fetcher, calls } = fakeFetch(() => json(BASE))
    const engine = createAihotEngine({ fetcher })
    const query = '-site:medium.com lang:zh site:zhihu.com before:2026-06 rust 异步 after:2026-01'
    const result = await engine.search!(
      { query, maxResults: 8, syntax: parseQuerySyntax(query) },
      context(),
    )
    expect(result.ok).toBe(true)
    expect(new URL(calls[0]!.url).searchParams.get('q')).toBe(
      'rust 异步 -site:medium.com lang:zh site:zhihu.com before:2026-06 after:2026-01',
    )
  })

  it('syntax 缺省时 q 用 trim 后的原文（不折叠内部空白）', async () => {
    const { fetcher, calls } = fakeFetch(() => json(BASE))
    const engine = createAihotEngine({ fetcher })
    const result = await runSearch(engine, '  DeepSeek   V4  ', 8)
    expect(result.ok).toBe(true)
    expect(new URL(calls[0]!.url).searchParams.get('q')).toBe('DeepSeek   V4')
  })

  it('回拼后超过 200 码点 → 沿用现有长度校验（invalid，不发请求），不静默截断', async () => {
    const { fetcher, calls } = fakeFetch(() => json(BASE))
    const engine = createAihotEngine({ fetcher })
    const operators = Array.from({ length: 20 }, (_, index) => ({
      kind: 'site' as const,
      raw: `site:d${index}.example.com`,
      value: `d${index}.example.com`,
    }))
    const failure = failureOf(await engine.search!(
      {
        query: 'DeepSeek',
        maxResults: 8,
        syntax: {
          operators,
          domains: operators.map(operator => operator.value),
          excludeDomains: [],
          bareQuery: 'DeepSeek',
        },
      },
      context(),
    ))
    expect(failure.kind).toBe('invalid')
    expect(failure.detail).toContain('2–200')
    expect(calls).toHaveLength(0)
  })

  it('操作符按 operators[].raw 逐字、原顺序回拼（大小写/路径后缀/重复都不改）', async () => {
    const { fetcher, calls } = fakeFetch(() => json(BASE))
    const engine = createAihotEngine({ fetcher })
    const query = 'Rust site:Example.COM/Path -site:Medium.com lang:ZH after:2026-01 site:example.com'
    const result = await engine.search!({ query, maxResults: 8, syntax: parseQuerySyntax(query) }, context())
    expect(result.ok).toBe(true)
    expect(new URL(calls[0]!.url).searchParams.get('q')).toBe(
      'Rust site:Example.COM/Path -site:Medium.com lang:ZH after:2026-01 site:example.com',
    )
  })

  it('组合后为空 → request.query 原文（不 trim、不用 bareQuery 的空串）', async () => {
    const { fetcher, calls } = fakeFetch(() => json(BASE))
    const engine = createAihotEngine({ fetcher })
    const query = '  DeepSeek  '
    const result = await engine.search!(
      { query, maxResults: 8, syntax: { operators: [], domains: [], excludeDomains: [], bareQuery: '' } },
      context(),
    )
    expect(result.ok).toBe(true)
    expect(new URL(calls[0]!.url).searchParams.get('q')).toBe(query)
  })
})

describe('缓存与条件验证', () => {
  it('相同请求命中缓存，不同查询才发新请求', async () => {
    const { fetcher, calls } = fakeFetch(() => json(BASE))
    const engine = createAihotEngine({ fetcher })
    const first = await runSearch(engine, 'DeepSeek', 8)
    const second = await runSearch(engine, 'DeepSeek', 8)
    expect(second).toEqual(first)
    expect(calls).toHaveLength(1)
    await runSearch(engine, 'Kimi K2', 8)
    expect(calls).toHaveLength(2)
  })

  it('缓存过期后带 if-none-match 条件验证，304 复用缓存数据并续期', async () => {
    let now = 1_000_000
    vi.spyOn(Date, 'now').mockImplementation(() => now)
    let stage = 0
    const { fetcher, calls } = fakeFetch(() => {
      stage += 1
      if (stage === 1) return json(BASE, { headers: { etag: '"v1"', 'cache-control': 'max-age=0' } })
      return new Response(null, { status: 304, headers: { etag: '"v1"', 'cache-control': 'max-age=60' } })
    })
    const engine = createAihotEngine({ fetcher })

    const first = await runSearch(engine, 'DeepSeek', 8)
    now += 1
    const second = await runSearch(engine, 'DeepSeek', 8)
    expect(second).toEqual(first)
    expect(calls).toHaveLength(2)
    expect(new Headers(calls[1]!.init.headers).get('if-none-match')).toBe('"v1"')

    // 304 续期后立即命中缓存，不再请求。
    const third = await runSearch(engine, 'DeepSeek', 8)
    expect(third).toEqual(first)
    expect(calls).toHaveLength(2)
  })

  it('304 自身的 Cache-Control/ETag 优先续期', async () => {
    let now = 1_000_000
    vi.spyOn(Date, 'now').mockImplementation(() => now)
    let stage = 0
    const { fetcher, calls } = fakeFetch(() => {
      stage += 1
      if (stage === 1) return json(BASE, { headers: { etag: '"v1"', 'cache-control': 'max-age=2' } })
      if (stage === 2) return new Response(null, { status: 304, headers: { etag: '"v2"', 'cache-control': 'max-age=60' } })
      return json(BASE, { headers: { etag: '"v2"', 'cache-control': 'max-age=60' } })
    })
    const engine = createAihotEngine({ fetcher })

    await runSearch(engine, 'DeepSeek', 8)
    now += 2_001
    await runSearch(engine, 'DeepSeek', 8)
    expect(calls).toHaveLength(2)
    // 304 给 max-age=60：按 304 续期后 2 秒内仍命中缓存。
    now += 2_001
    await runSearch(engine, 'DeepSeek', 8)
    expect(calls).toHaveLength(2)
    // 过期后再验证时使用 304 下发的新 ETag。
    now += 60_001
    await runSearch(engine, 'DeepSeek', 8)
    expect(calls).toHaveLength(3)
    expect(new Headers(calls[2]!.init.headers).get('if-none-match')).toBe('"v2"')
  })

  it('304 未给 Cache-Control 时回退上次 200 的 TTL', async () => {
    let now = 1_000_000
    vi.spyOn(Date, 'now').mockImplementation(() => now)
    let stage = 0
    const { fetcher, calls } = fakeFetch(() => {
      stage += 1
      if (stage === 1) return json(BASE, { headers: { etag: '"v1"', 'cache-control': 'max-age=2' } })
      if (stage === 2) return new Response(null, { status: 304 })
      return json(BASE, { headers: { etag: '"v1"', 'cache-control': 'max-age=60' } })
    })
    const engine = createAihotEngine({ fetcher })

    await runSearch(engine, 'DeepSeek', 8)
    now += 2_001
    await runSearch(engine, 'DeepSeek', 8)
    expect(calls).toHaveLength(2)
    // 304 无缓存指令：按上次 200 的 2 秒续期，2 秒后已过期。
    now += 2_001
    await runSearch(engine, 'DeepSeek', 8)
    expect(calls).toHaveLength(3)
  })

  it('缓存指令同时读 max-age 与 s-maxage，取较大值（s-maxage 是最小轮询间隔）', async () => {
    const { fetcher, calls } = fakeFetch(() =>
      json(BASE, { headers: { 'cache-control': 'max-age=0, s-maxage=60' } }),
    )
    const engine = createAihotEngine({ fetcher })
    await runSearch(engine, 'DeepSeek', 8)
    await runSearch(engine, 'DeepSeek', 8)
    expect(calls).toHaveLength(1)
  })

  it('200 不带 ETag 时保留旧 ETag，后续仍做条件验证（v0.2 语义）', async () => {
    let now = 1_000_000
    vi.spyOn(Date, 'now').mockImplementation(() => now)
    let stage = 0
    const { fetcher, calls } = fakeFetch(() => {
      stage += 1
      if (stage === 1) return json(BASE, { headers: { etag: '"v1"', 'cache-control': 'max-age=0' } })
      if (stage === 2) return json(BASE, { headers: { 'cache-control': 'max-age=0' } })
      return json(BASE, { headers: { 'cache-control': 'max-age=60' } })
    })
    const engine = createAihotEngine({ fetcher })

    await runSearch(engine, 'DeepSeek', 8)
    now += 1
    await runSearch(engine, 'DeepSeek', 8)
    expect(new Headers(calls[1]!.init.headers).get('if-none-match')).toBe('"v1"')
    now += 1
    await runSearch(engine, 'DeepSeek', 8)
    expect(new Headers(calls[2]!.init.headers).get('if-none-match')).toBe('"v1"')
    expect(calls).toHaveLength(3)
  })

  it('Cache-Control: no-store 不入缓存', async () => {
    const { fetcher, calls } = fakeFetch(() =>
      json(BASE, { headers: { 'cache-control': 'no-store', etag: '"v1"' } }),
    )
    const engine = createAihotEngine({ fetcher })
    await runSearch(engine, 'DeepSeek', 8)
    await runSearch(engine, 'DeepSeek', 8)
    expect(calls).toHaveLength(2)
    expect(new Headers(calls[1]!.init.headers).get('if-none-match')).toBeNull()
  })

  it('缓存过期后上游失败 → 返回失败，不回传过期数据', async () => {
    let now = 1_000_000
    vi.spyOn(Date, 'now').mockImplementation(() => now)
    let stage = 0
    const { fetcher } = fakeFetch(() => {
      stage += 1
      return stage === 1 ? json(BASE, { headers: { 'cache-control': 'max-age=0' } }) : upstream(500)
    })
    const engine = createAihotEngine({ fetcher })

    expect((await runSearch(engine, 'DeepSeek', 8)).ok).toBe(true)
    now += 1
    const failure = failureOf(await runSearch(engine, 'DeepSeek', 8))
    expect(failure).toMatchObject({ kind: 'provider-error', statusCode: 500 })
  })
})

describe('失败投影', () => {
  it('429 → rate-limited，Retry-After 期间跨查询冷却且只发一次请求', async () => {
    let now = 1_000_000
    vi.spyOn(Date, 'now').mockImplementation(() => now)
    const { fetcher, calls } = fakeFetch(() => upstream(429, { 'retry-after': '120' }, 'slow down'))
    const engine = createAihotEngine({ fetcher })

    const first = failureOf(await runSearch(engine, 'Alpha 429', 5))
    expect(first).toMatchObject({ kind: 'rate-limited', statusCode: 429, retryAfterMs: 120_000 })

    const second = failureOf(await runSearch(engine, 'Beta 429', 5))
    expect(second).toMatchObject({ kind: 'rate-limited', statusCode: 429 })
    expect(calls).toHaveLength(1)

    now += 120_000
    await runSearch(engine, 'Gamma 429', 5)
    expect(calls).toHaveLength(2)
  })

  it('429 Problem JSON 无 Retry-After 头 → 用 retryAfter（整数秒）冷却，detail 保留 code/requestId', async () => {
    let now = 1_000_000
    vi.spyOn(Date, 'now').mockImplementation(() => now)
    const body = JSON.stringify({
      type: 'about:blank',
      title: 'Too Many Requests',
      status: 429,
      detail: 'rate limit exceeded',
      code: 'rate_limited',
      requestId: 'req-429',
      retryAfter: 7,
    })
    const { fetcher, calls } = fakeFetch(() =>
      new Response(body, { status: 429, headers: { 'content-type': 'application/problem+json' } }),
    )
    const engine = createAihotEngine({ fetcher })

    const first = failureOf(await runSearch(engine, 'Alpha problem 429', 5))
    expect(first).toMatchObject({ kind: 'rate-limited', statusCode: 429, retryAfterMs: 7_000 })
    expect(first.detail).toContain('code=rate_limited')
    expect(first.detail).toContain('requestId=req-429')

    const second = failureOf(await runSearch(engine, 'Beta problem 429', 5))
    expect(second.kind).toBe('rate-limited')
    expect(calls).toHaveLength(1)

    now += 7_000
    await runSearch(engine, 'Gamma problem 429', 5)
    expect(calls).toHaveLength(2)
  })

  it('503 是 AIHOT 的限流信号 → rate-limited，默认冷却 60 秒', async () => {
    let now = 1_000_000
    vi.spyOn(Date, 'now').mockImplementation(() => now)
    const { fetcher, calls } = fakeFetch(() => upstream(503, {}, 'unavailable'))
    const engine = createAihotEngine({ fetcher })

    expect(failureOf(await runSearch(engine, 'Alpha 503', 5))).toMatchObject({
      kind: 'rate-limited',
      statusCode: 503,
    })
    expect(failureOf(await runSearch(engine, 'Beta 503', 5)).kind).toBe('rate-limited')
    expect(calls).toHaveLength(1)

    now += 60_000
    await runSearch(engine, 'Gamma 503', 5)
    expect(calls).toHaveLength(2)
  })

  it('503 带 Retry-After → rate-limited 并按该值冷却（不是默认 60 秒）', async () => {
    let now = 1_000_000
    vi.spyOn(Date, 'now').mockImplementation(() => now)
    const { fetcher, calls } = fakeFetch(() => upstream(503, { 'retry-after': '30' }, 'unavailable'))
    const engine = createAihotEngine({ fetcher })

    expect(failureOf(await runSearch(engine, 'Alpha 503 retry', 5))).toMatchObject({
      kind: 'rate-limited',
      statusCode: 503,
      retryAfterMs: 30_000,
    })
    expect(failureOf(await runSearch(engine, 'Beta 503 retry', 5)).kind).toBe('rate-limited')
    expect(calls).toHaveLength(1)

    now += 30_000
    await runSearch(engine, 'Gamma 503 retry', 5)
    expect(calls).toHaveLength(2)
  })

  it('402 → quota（quotaExhausted 明确信号）', async () => {
    const { fetcher } = fakeFetch(() => upstream(402, {}, 'payment required'))
    const failure = failureOf(await runSearch(createAihotEngine({ fetcher }), 'DeepSeek', 5))
    expect(failure).toMatchObject({ kind: 'quota', statusCode: 402, quotaExhausted: true })
  })

  it.each([401, 403])('HTTP %i → provider-error（匿名引擎无凭证位，403 是策略/授权拒绝）', async status => {
    const body = JSON.stringify({
      type: 'https://aihot.news/problems/commercial-use',
      title: 'Commercial use requires authorization',
      status,
      detail: 'written authorization required',
      code: 'commercial_use_required',
      requestId: 'req-123',
    })
    const { fetcher } = fakeFetch(() =>
      new Response(body, {
        status,
        headers: { 'content-type': 'application/problem+json', 'x-aihot-commercial-use': 'written-authorization-required' },
      }),
    )
    const failure = failureOf(await runSearch(createAihotEngine({ fetcher }), 'DeepSeek', 5))
    expect(failure).toMatchObject({ kind: 'provider-error', statusCode: status })
    expect(failure.detail).toContain('code=commercial_use_required')
    expect(failure.detail).toContain('requestId=req-123')
  })

  it.each([404, 500])('HTTP %i → provider-error（引擎 API 错误不经 target-status）', async status => {
    const { fetcher } = fakeFetch(() => upstream(status))
    const failure = failureOf(await runSearch(createAihotEngine({ fetcher }), 'DeepSeek', 5))
    expect(failure).toMatchObject({ kind: 'provider-error', statusCode: status })
  })

  it('网络层异常 → network', async () => {
    const { fetcher } = fakeFetch(() => {
      throw new TypeError('fetch failed')
    })
    const failure = failureOf(await runSearch(createAihotEngine({ fetcher }), 'DeepSeek', 5))
    expect(failure.kind).toBe('network')
  })

  it('非 JSON 响应 → provider-error，且不被缓存', async () => {
    const { fetcher, calls } = fakeFetch(() =>
      new Response('not-json', { status: 200, headers: { 'content-type': 'application/json' } }),
    )
    const engine = createAihotEngine({ fetcher })
    const first = failureOf(await runSearch(engine, 'Alpha malformed', 5))
    expect(first).toMatchObject({ kind: 'provider-error', statusCode: 200 })
    expect(first.detail).toContain('JSON')
    await runSearch(engine, 'Alpha malformed', 5)
    expect(calls).toHaveLength(2)
  })

  it('响应体超过 1MB → provider-error，且不入缓存', async () => {
    const { fetcher, calls } = fakeFetch(() =>
      new Response('x'.repeat(1_000_001), { status: 200, headers: { 'content-type': 'application/json' } }),
    )
    const engine = createAihotEngine({ fetcher })
    const first = failureOf(await runSearch(engine, 'Alpha huge', 5))
    expect(first).toMatchObject({ kind: 'provider-error', statusCode: 200 })
    expect(first.detail).toContain('上限')
    await runSearch(engine, 'Alpha huge', 5)
    expect(calls).toHaveLength(2)
  })

  it('结构非法（schemaVersion/page.hasMore/items 元素）→ provider-error', async () => {
    const invalidPayloads: unknown[] = [
      { ...BASE, schemaVersion: 2 },
      { ...BASE, page: { count: 3, nextCursor: null } },
      { ...BASE, items: [null] },
      { ...BASE, items: [{ ...ITEMS[0], links: undefined }] },
      { ...BASE, items: [{ ...ITEMS[0], source: undefined }] },
    ]
    for (const payload of invalidPayloads) {
      const { fetcher } = fakeFetch(() => json(payload))
      const failure = failureOf(await runSearch(createAihotEngine({ fetcher }), 'DeepSeek', 5))
      expect(failure).toMatchObject({ kind: 'provider-error' })
      expect(failure.detail).toContain('格式无效')
    }
  })

  it('结构非法响应不入缓存：同一查询第二次仍发请求', async () => {
    const { fetcher, calls } = fakeFetch(() => json({ ...BASE, schemaVersion: 2 }))
    const engine = createAihotEngine({ fetcher })
    expect(failureOf(await runSearch(engine, 'DeepSeek', 5)).kind).toBe('provider-error')
    expect(failureOf(await runSearch(engine, 'DeepSeek', 5)).kind).toBe('provider-error')
    expect(calls).toHaveLength(2)
  })

  it('调用方已取消 → aborted，不发请求', async () => {
    const controller = new AbortController()
    controller.abort()
    const { fetcher, calls } = fakeFetch(() => json(BASE))
    const result = await runSearch(
      createAihotEngine({ fetcher }),
      'DeepSeek',
      5,
      context({ signal: controller.signal }),
    )
    expect(failureOf(result).kind).toBe('aborted')
    expect(calls).toHaveLength(0)
  })

  it('请求预算耗尽 → aborted，不发请求', async () => {
    const countRequest = vi.fn(() => false)
    const { fetcher, calls } = fakeFetch(() => json(BASE))
    const result = await runSearch(
      createAihotEngine({ fetcher }),
      'DeepSeek',
      5,
      context({ countRequest }),
    )
    expect(failureOf(result).kind).toBe('aborted')
    expect(countRequest).toHaveBeenCalledTimes(1)
    expect(calls).toHaveLength(0)
  })

  it('操作 deadline 已到时的网络类失败 → timeout', async () => {
    const { fetcher } = fakeFetch((_url, init) => new Promise<Response>((_resolve, reject) => {
      const signal = init.signal
      if (signal === undefined || signal === null) {
        reject(new Error('缺少中止信号'))
        return
      }
      signal.addEventListener('abort', () => reject(new DOMException('timed out', 'TimeoutError')), { once: true })
    }))
    const result = await runSearch(
      createAihotEngine({ fetcher }),
      'DeepSeek',
      5,
      context({ deadline: Date.now() - 1 }),
    )
    expect(failureOf(result).kind).toBe('timeout')
  })
})

describe('AIHOT 专用读取器（createAihotApiReader）', () => {
  /** 官方 OpenAPI components.schemas.Problem + responses.RateLimited 的形状（application/problem+json）。 */
  function problemResponse(): Response {
    const headers = new Headers({ 'content-type': 'application/problem+json' })
    return new Response(JSON.stringify({
      type: 'https://aihot.news/problems/rate-limited',
      title: 'Too Many Requests',
      status: 429,
      detail: 'request rate exceeded',
      code: 'rate_limited',
      requestId: 'req-abc123',
      retryAfter: 120,
    }), { status: 429, headers })
  }

  it('文档化只读端点命中（items/hot-topics/dailies JSON 与 agent Markdown）', async () => {
    const payload = { schemaVersion: 1, items: [], page: { hasMore: false } }
    for (const path of ['items?limit=2', 'hot-topics', 'dailies/latest']) {
      const { fetcher, calls } = fakeFetch(() => json(payload))
      const result = await createAihotApiReader({ fetcher }).readApi(`https://aihot.news/api/v1/${path}`, context())
      expect(result).toMatchObject({ statusCode: 200, truncated: false, body: { kind: 'text' } })
      expect(calls).toHaveLength(1)
    }
    const { fetcher, calls } = fakeFetch(() => new Response('# AIHOT', { headers: { 'content-type': 'text/markdown' } }))
    const result = await createAihotApiReader({ fetcher })
      .readApi('https://aihot.news/api/v1/agent/search?q=DeepSeek', context())
    expect(result).toMatchObject({ statusCode: 200, truncated: false, body: { kind: 'text' } })
    expect(calls).toHaveLength(1)
  })

  it('非专用 API 面 → undefined，不派发请求（继续通用提取）', async () => {
    const urls = [
      'https://example.com/api/v1/items',
      'https://aihot.news/items/item-1',
      'https://aihot.news/api/v1/items/123',
      'http://aihot.news/api/v1/items',
      'https://user@aihot.news/api/v1/items',
    ]
    for (const url of urls) {
      const { fetcher, calls } = fakeFetch(() => new Response('{}'))
      const result = await createAihotApiReader({ fetcher }).readApi(url, context())
      expect(result).toBeUndefined()
      expect(calls).toHaveLength(0)
    }
  })

  it('agent markdown 面原样返回（不重新序列化、不改写）', async () => {
    const markdown = '# AIHOT\n\n> 不可信外部内容\n\n[原文](https://example.com/original)\n'
    const { fetcher } = fakeFetch(() => new Response(markdown, { headers: { 'content-type': 'text/markdown' } }))
    const result = await createAihotApiReader({ fetcher })
      .readApi('https://aihot.news/api/v1/agent/hot?limit=10', context())
    expect(result?.body).toEqual({ kind: 'text', content: markdown })
  })

  it('JSON 端点重新序列化，保留 null 与不透明 cursor', async () => {
    const payload = { schemaVersion: 1, items: [{ publishedAt: null }], page: { hasMore: true, nextCursor: 'opaque+/=' } }
    const { fetcher } = fakeFetch(() => json(payload))
    const result = await createAihotApiReader({ fetcher })
      .readApi('https://aihot.news/api/v1/items?cursor=opaque%2B%2F%3D', context())
    if (result === undefined) throw new Error('期望读取结果')
    expect(JSON.parse(result.body.content)).toEqual(payload)
  })

  it('Problem 429 保留 code/requestId/retryAfter 并冷却，跨 URL 不再请求', async () => {
    const { fetcher, calls } = fakeFetch(() => problemResponse())
    const reader = createAihotApiReader({ fetcher })
    const first = await reader.readApi('https://aihot.news/api/v1/hot-topics', context())
    if (first === undefined) throw new Error('期望读取结果')
    const problem = JSON.parse(first.body.content) as Record<string, unknown>
    expect({
      statusCode: first.statusCode,
      code: problem.code,
      requestId: problem.requestId,
      retryAfter: problem.retryAfter,
    }).toEqual({ statusCode: 429, code: 'rate_limited', requestId: 'req-abc123', retryAfter: 120 })
    const second = await reader.readApi('https://aihot.news/api/v1/dailies/latest', context())
    expect(second?.statusCode).toBe(429)
    expect(calls).toHaveLength(1)
  })

  it('缓存过期后用 ETag 条件验证，304 复用已验证内容', async () => {
    let now = 1_000_000
    vi.spyOn(Date, 'now').mockImplementation(() => now)
    let stage = 0
    const { fetcher, calls } = fakeFetch(() => {
      stage += 1
      if (stage === 1) {
        return json({ schemaVersion: 1, report: { references: ['withdrawn'] } }, {
          headers: { etag: '"v1"', 'cache-control': 'max-age=0' },
        })
      }
      return new Response(null, { status: 304 })
    })
    const reader = createAihotApiReader({ fetcher })
    const request = 'https://aihot.news/api/v1/dailies/2026-09-30'
    const first = await reader.readApi(request, context())
    now += 1
    const second = await reader.readApi(request, context())
    expect(second).toEqual(first)
    expect(calls).toHaveLength(2)
    expect(new Headers(calls[1]!.init.headers).get('if-none-match')).toBe('"v1"')
  })

  it('JSON 超过 100000 字符 → WEB_FETCH_TOO_LARGE，不把残包当成功', async () => {
    const { fetcher } = fakeFetch(() => json({ schemaVersion: 1, items: ['x'.repeat(100_001)] }))
    const reader = createAihotApiReader({ fetcher })
    await expect(reader.readApi('https://aihot.news/api/v1/selected/snapshot', context()))
      .rejects.toMatchObject({ code: 'WEB_FETCH_TOO_LARGE' })
  })
})

describe('AIHOT hotTopics（v0.4 hot-list 意图）', () => {
  // 夹具依据：.scratch/dev-loop/recon/capability-aihot.json 的 /api/v1/hot-topics 实探形状
  //（items[]{rank,title,source.name,links{aihot,original?},sourceCount,latestAt}，2026-11-07 匿名实测）。
  const hotBody = {
    schemaVersion: 1,
    count: 2,
    items: [
      { rank: 1, id: 'a', title: 'Google Omni 1.2 Flash', source: { name: 'X' }, links: { aihot: 'https://aihot.news/i/a', original: 'https://x.com/p/1' }, sourceCount: 11, latestAt: '2026-11-07T12:00:00Z' },
      { rank: 2, id: 'b', title: '开源模型周报', source: { name: '微博' }, links: { aihot: 'https://aihot.news/i/b' }, sourceCount: 3 },
    ],
  }

  it('热点榜映射：original 优先、来源数进 snippet、时间进 publishedAt', async () => {
    const calls: string[] = []
    const fetcher = (async (input: string | URL) => {
      calls.push(String(input))
      return new Response(JSON.stringify(hotBody), { status: 200, headers: { 'content-type': 'application/json' } })
    }) as typeof fetch
    const engine = createAihotEngine({ fetcher })
    const result = await engine.hotTopics!(context())
    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.outcome.sources).toHaveLength(2)
    expect(result.outcome.sources[0]).toEqual({
      url: 'https://x.com/p/1',
      title: 'Google Omni 1.2 Flash',
      snippet: '11 家来源共同报道',
      publishedAt: '2026-11-07T12:00:00Z',
    })
    expect(result.outcome.sources[1]!.url).toBe('https://aihot.news/i/b')
    expect(result.outcome.truncated).toBe(false)
    expect(calls[0]).toContain('/api/v1/hot-topics')
  })

  it('响应缺 items 数组 → provider-error，不抛出', async () => {
    const fetcher = (async () => new Response(JSON.stringify({ schemaVersion: 1 }), {
      status: 200, headers: { 'content-type': 'application/json' },
    })) as typeof fetch
    const result = await createAihotEngine({ fetcher }).hotTopics!(context())
    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.failure.kind).toBe('provider-error')
  })

  it('429 → rate-limited 投影（与搜索路共用冷却语义）', async () => {
    const fetcher = (async () => new Response('{"title":"Too Many Requests","status":429}', {
      status: 429, headers: { 'content-type': 'application/problem+json', 'retry-after': '30' },
    })) as typeof fetch
    const result = await createAihotEngine({ fetcher }).hotTopics!(context())
    expect(result.ok).toBe(false)
    if (result.ok) return
    expect(result.failure.kind).toBe('rate-limited')
  })
})
