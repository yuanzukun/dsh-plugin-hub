/**
 * AnySearch 垂直能力目录离线单测——注入 fetcher 替身，不触网。
 * 夹具形状来源：.scratch/dev-loop/recon/api-contracts/anysearch.json
 *   GET /v1/domains        → {code,message,request_id,data:{domains:[{domain,description,sub_domain_count,...}]}}
 *   GET /v1/sub-domains?domain=a&domain=b
 *                          → {code,message,request_id,data:{domains:[{domain,description,sub_domains:[{sub_domain,description,params?}]}]}}
 * 实探证据：.scratch/dev-loop/recon/capability-anysearch.json（17 领域 39 子域；匿名 200；缺 domain 400）。
 */
import { describe, expect, it } from 'vitest'
import { AnysearchDomainCatalog } from '../../src/engines/anysearch-domains.js'

const DOMAINS_URL = 'https://api.anysearch.com/v1/domains'
const SUB_DOMAINS_URL = 'https://api.anysearch.com/v1/sub-domains?domain=code&domain=finance'

interface CapturedRequest {
  readonly url: string
  readonly init: RequestInit
}

/** 记录每次请求的 fetcher 替身；handler 决定响应。 */
function createFetcher(handler: (url: string, init: RequestInit) => Response | Promise<Response>) {
  const requests: CapturedRequest[] = []
  const fetcher: typeof fetch = async (input, init) => {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url
    const requestInit = init ?? {}
    requests.push({ url, init: requestInit })
    return handler(url, requestInit)
  }
  return { fetcher, requests }
}

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json' },
  })
}

/** GET /v1/domains 形状：领域名 + 描述 + 子域数量（实探字段）。 */
const domainsPayload = {
  code: 0,
  message: 'success',
  request_id: 'req_domains',
  data: {
    domains: [
      { domain: 'code', description: '代码', sub_domain_count: 2 },
      { domain: 'finance', description: '金融', sub_domain_count: 1 },
    ],
  },
}

/** GET /v1/sub-domains 形状：按域分组，params 是「参数名 → 定义」的对象。 */
const subDomainsPayload = {
  code: 0,
  message: 'success',
  request_id: 'req_sub_domains',
  data: {
    domains: [
      {
        domain: 'code',
        description: '代码',
        sub_domains: [
          {
            sub_domain: 'doc',
            description: '库文档',
            params: {
              library: { description: '库名', required: true, sort_order: 1 },
              version: { description: '版本', required: false, sort_order: 2 },
            },
          },
          { sub_domain: 'snippet', description: '代码片段' },
        ],
      },
      {
        domain: 'finance',
        description: '金融',
        sub_domains: [
          {
            sub_domain: 'finance.quote',
            description: '行情',
            params: { type: { description: '资产类型', required: true, sort_order: 1 } },
          },
        ],
      },
    ],
  },
}

function standardFetcher() {
  return createFetcher(url => jsonResponse(url === DOMAINS_URL ? domainsPayload : subDomainsPayload))
}

describe('AnySearch 领域目录', () => {
  it('首次发现依次请求 /v1/domains 与 /v1/sub-domains，并解析参数定义', async () => {
    const { fetcher, requests } = standardFetcher()
    const catalog = new AnysearchDomainCatalog({ fetcher })

    const tags = await catalog.listTags()

    expect(tags).toEqual([
      {
        tag: 'code.doc',
        description: '库文档',
        params: [
          { name: 'library', description: '库名', required: true },
          { name: 'version', description: '版本', required: false },
        ],
      },
      { tag: 'code.snippet', description: '代码片段', params: [] },
      {
        tag: 'finance.quote',
        description: '行情',
        params: [{ name: 'type', description: '资产类型', required: true }],
      },
    ])
    expect(requests.map(request => request.url)).toEqual([DOMAINS_URL, SUB_DOMAINS_URL])
    expect(requests.every(request => request.init.method === 'GET')).toBe(true)
    // 匿名模式不带 Authorization（契约：匿名可用）。
    expect(new Headers(requests[0]!.init.headers).get('authorization')).toBeNull()
  })

  it('构造时给 apiKey 则为发现请求带 Bearer', async () => {
    const { fetcher, requests } = standardFetcher()
    const catalog = new AnysearchDomainCatalog({ fetcher, apiKey: 'as_test_key' })

    await catalog.listTags()

    expect(requests.map(request => new Headers(request.init.headers).get('authorization'))).toEqual([
      'Bearer as_test_key',
      'Bearer as_test_key',
    ])
  })

  it('TTL 内两次调用复用缓存：第二次零网络请求', async () => {
    let clock = 1_000
    const { fetcher, requests } = standardFetcher()
    const catalog = new AnysearchDomainCatalog({ fetcher, ttlMs: 60_000, now: () => clock })

    const first = await catalog.listTags()
    clock += 59_999
    const second = await catalog.listTags()

    expect(second).toBe(first)
    expect(requests).toHaveLength(2)
  })

  it('TTL 过期后重新拉取 domains + sub-domains', async () => {
    let clock = 0
    const { fetcher, requests } = standardFetcher()
    const catalog = new AnysearchDomainCatalog({ fetcher, ttlMs: 1_000, now: () => clock })

    await catalog.listTags()
    expect(requests).toHaveLength(2)
    clock = 1_000
    await catalog.listTags()
    expect(requests).toHaveLength(4)
  })

  it('发现失败不缓存：本次拒绝，下一次调用重新拉取并成功', async () => {
    let attempts = 0
    const { fetcher, requests } = createFetcher(url => {
      if (url !== DOMAINS_URL) return jsonResponse(subDomainsPayload)
      attempts += 1
      return attempts === 1
        ? jsonResponse({ code: -1, message: 'Capabilities temporarily unavailable.' }, 502)
        : jsonResponse(domainsPayload)
    })
    const catalog = new AnysearchDomainCatalog({ fetcher })

    await expect(catalog.listTags()).rejects.toThrow('HTTP 502')
    const tags = await catalog.listTags()

    expect(tags).toHaveLength(3)
    expect(requests.map(request => request.url)).toEqual([DOMAINS_URL, DOMAINS_URL, SUB_DOMAINS_URL])
  })

  it('HTTP 200 但信封 code!=0 → 拒绝且不缓存，下一次重拉', async () => {
    let attempts = 0
    const { fetcher, requests } = createFetcher(url => {
      if (url !== DOMAINS_URL) return jsonResponse(subDomainsPayload)
      attempts += 1
      return attempts === 1
        ? jsonResponse({ code: -1, message: 'Capabilities temporarily unavailable.', data: null })
        : jsonResponse(domainsPayload)
    })
    const catalog = new AnysearchDomainCatalog({ fetcher })

    await expect(catalog.listTags()).rejects.toThrow('错误码 -1')
    await expect(catalog.listTags()).resolves.toHaveLength(3)
    expect(requests).toHaveLength(3)
  })

  it('并发调用共享同一次刷新（同一 in-flight promise，不重复请求）', async () => {
    let release!: () => void
    const gate = new Promise<void>(resolve => {
      release = resolve
    })
    const { fetcher, requests } = createFetcher(async url => {
      if (url === DOMAINS_URL) await gate
      return jsonResponse(url === DOMAINS_URL ? domainsPayload : subDomainsPayload)
    })
    const catalog = new AnysearchDomainCatalog({ fetcher })

    const first = catalog.listTags()
    const second = catalog.listTags()
    expect(second).toBe(first)
    expect(requests).toHaveLength(1)

    release()
    const [firstTags, secondTags] = await Promise.all([first, second])
    expect(secondTags).toBe(firstTags)
    expect(requests).toHaveLength(2)
  })

  it('data.domains 缺失 → 拒绝，不用空列表掩盖响应形状错误', async () => {
    const { fetcher } = createFetcher(() => jsonResponse({ code: 0, message: 'success', data: {} }))
    const catalog = new AnysearchDomainCatalog({ fetcher })

    await expect(catalog.listTags()).rejects.toThrow('data.domains')
  })

  it('领域清单为空时直接返回空列表，不再请求 sub-domains', async () => {
    const { fetcher, requests } = createFetcher(() =>
      jsonResponse({ code: 0, message: 'success', data: { domains: [] } }),
    )
    const catalog = new AnysearchDomainCatalog({ fetcher })

    await expect(catalog.listTags()).resolves.toEqual([])
    expect(requests).toHaveLength(1)
  })
})

describe('垂直 tag 校验', () => {
  it('存在的 tag 返回缺失的必填参数名', async () => {
    const { fetcher } = standardFetcher()
    const catalog = new AnysearchDomainCatalog({ fetcher })

    await expect(catalog.validate('code.doc')).resolves.toEqual({ exists: true, missingRequired: ['library'] })
    await expect(catalog.validate('code.doc', { library: 'react' })).resolves.toEqual({ exists: true, missingRequired: [] })
    await expect(catalog.validate('code.doc', { library: '  ' })).resolves.toEqual({ exists: true, missingRequired: ['library'] })
    await expect(catalog.validate('code.snippet')).resolves.toEqual({ exists: true, missingRequired: [] })
  })

  it('required=true 但 description 写 Optional 的上游笔误按可选处理（travel.flight_status）', async () => {
    const travelDomains = {
      code: 0,
      message: 'success',
      request_id: 'req_travel',
      data: { domains: [{ domain: 'travel', description: '出行', sub_domain_count: 1 }] },
    }
    const travelSubDomains = {
      code: 0,
      message: 'success',
      request_id: 'req_travel_sub',
      data: {
        domains: [{
          domain: 'travel',
          description: '出行',
          sub_domains: [{
            sub_domain: 'flight_status',
            description: '航班状态',
            params: {
              flight_number: { description: '航班号', required: true, sort_order: 1 },
              // 上游笔误：required 为 true，描述却写 Optional（recon capability-anysearch.json）。
              departure: { description: 'Optional. Departure airport or city', required: true, sort_order: 2 },
            },
          }],
        }],
      },
    }
    const { fetcher } = createFetcher(url => jsonResponse(url === DOMAINS_URL ? travelDomains : travelSubDomains))
    const catalog = new AnysearchDomainCatalog({ fetcher })

    await expect(catalog.validate('travel.flight_status', { flight_number: 'CA1234' }))
      .resolves.toEqual({ exists: true, missingRequired: [] })
    await expect(catalog.validate('travel.flight_status', {}))
      .resolves.toEqual({ exists: true, missingRequired: ['flight_number'] })
  })

  it('未知 tag → exists=false', async () => {
    const { fetcher } = standardFetcher()
    const catalog = new AnysearchDomainCatalog({ fetcher })

    await expect(catalog.validate('unknown.tag')).resolves.toEqual({ exists: false, missingRequired: [] })
  })

  it('发现请求前消费注入的操作预算', async () => {
    const { fetcher, requests } = standardFetcher()
    const catalog = new AnysearchDomainCatalog({ fetcher })
    const calls: boolean[] = []

    const verdict = await catalog.validate('code.doc', undefined, {
      countRequest: () => { calls.push(true); return true },
    })

    expect(verdict.exists).toBe(true)
    expect(calls).toHaveLength(2) // /v1/domains + /v1/sub-domains
    expect(requests).toHaveLength(2)
  })

  it('预算拒绝时不发请求并拒绝校验', async () => {
    const { fetcher, requests } = standardFetcher()
    const catalog = new AnysearchDomainCatalog({ fetcher })

    await expect(catalog.validate('code.doc', undefined, { countRequest: () => false }))
      .rejects.toThrow('请求预算已用尽')
    expect(requests).toHaveLength(0)
  })

  it('短超时生效：悬挂的发现请求会按时中止', async () => {
    const hanging: typeof fetch = (_input, init) => new Promise((_resolve, reject) => {
      init?.signal?.addEventListener('abort', () => reject(new DOMException('aborted', 'AbortError')))
    })
    const catalog = new AnysearchDomainCatalog({ fetcher: hanging, timeoutMs: 5 })

    await expect(catalog.validate('code.doc')).rejects.toThrow()
  })
})
