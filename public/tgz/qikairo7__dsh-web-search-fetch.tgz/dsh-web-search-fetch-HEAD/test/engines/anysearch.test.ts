/**
 * AnySearch 引擎离线单测——注入 fetcher 替身，不触网。
 * 夹具形状来源：.scratch/dev-loop/recon/api-contracts/anysearch.json
 *   POST /v1/search  → {code,message,request_id,data:{results:[{title,url,snippet?,content?}],metadata}}
 *   POST /v1/extract → {code,message,request_id,data:{url,title,content}}
 * 官方文档：https://www.anysearch.com/docs/api-endpoints/v1-search
 *           https://www.anysearch.com/docs/api-endpoints/v1-extract
 */
import { describe, expect, it } from 'vitest'
import type { EngineContext, EngineResult, QuerySyntax } from '../../src/engines/contract.js'
import type { EngineFailure } from '../../src/engines/failure.js'
import { createAnysearchEngine } from '../../src/engines/anysearch.js'
import { ANYSEARCH_MANIFEST } from '../../src/engines/registry.js'
import { parseQuerySyntax } from '../../src/search/query-syntax.js'

interface CapturedRequest {
  readonly url: string
  readonly init: RequestInit
}

/** 记录每次请求的 fetcher 替身；handler 决定响应。 */
function createFetcher(handler: (url: string, init: RequestInit) => Response | Promise<Response>) {
  const requests: CapturedRequest[] = []
  const fetcher: typeof fetch = async (input, init) => {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url
    const requestInit = init ?? {}
    requests.push({ url, init: requestInit })
    return handler(url, requestInit)
  }
  return { fetcher, requests }
}

function jsonResponse(body: unknown, status = 200, headers: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json', ...headers },
  })
}

function successEnvelope(data: unknown, requestId = 'req_test_1') {
  return { code: 0, message: 'success', request_id: requestId, data }
}

function createContext(overrides: Partial<EngineContext> = {}): EngineContext {
  return {
    signal: new AbortController().signal,
    deadline: Date.now() + 60_000,
    endpoint: '',
    countRequest: () => true,
    ...overrides,
  }
}

function failureOf(result: EngineResult<unknown>): EngineFailure {
  if (result.ok) throw new Error('预期失败，实际成功')
  return result.failure
}

function bodyOf(request: CapturedRequest): unknown {
  return JSON.parse(String(request.init.body))
}

function authorizationOf(request: CapturedRequest): string | null {
  return new Headers(request.init.headers).get('authorization')
}

/** AD13 查询语法夹具：默认空集，按用例覆盖。 */
function syntaxOf(overrides: Partial<QuerySyntax> = {}): QuerySyntax {
  return { domains: [], excludeDomains: [], bareQuery: '', ...overrides, operators: overrides.operators ?? [] }
}

const SEARCH_URL = ANYSEARCH_MANIFEST.endpoints.search!
const FETCH_URL = ANYSEARCH_MANIFEST.endpoints.fetch!

/** 契约字段逐字复刻：search 成功响应（results[].title/url/snippet）。 */
const searchBody = {
  code: 0,
  message: 'success',
  request_id: 'req_search_1',
  data: {
    results: [
      { title: 'Result A', url: 'https://a.example.com/one', snippet: 'First summary' },
      { title: 'Result B', url: 'https://b.example.com/two', snippet: 'Second summary' },
    ],
    metadata: { total_results: 2, search_time_ms: 37 },
  },
}

/** 契约字段逐字复刻：extract 成功响应（data.url/title/content）。 */
const extractBody = {
  code: 0,
  message: 'success',
  request_id: 'req_extract_1',
  data: {
    url: 'https://example.com/article-final',
    title: 'Example article',
    content: 'Cleaned body.',
  },
}

describe('AnySearch 清单与能力', () => {
  it('manifest 直接复用注册表，search/fetch 存在且不实现 quota', () => {
    const engine = createAnysearchEngine()
    expect(engine.manifest).toBe(ANYSEARCH_MANIFEST)
    expect(engine.search).toBeTypeOf('function')
    expect(engine.fetch).toBeTypeOf('function')
    // 契约：官方没有公开额度端点，quota() 必须缺省（不是伪造 N/A 报告）。
    expect(engine.quota).toBeUndefined()
  })
})

describe('AnySearch 搜索', () => {
  it('成功：映射 url/title/snippet，默认走 manifest 端点且匿名请求', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })

    const result = await engine.search!({ query: 'hello world', maxResults: 5 }, createContext())

    expect(result).toEqual({
      ok: true,
      outcome: {
        sources: [
          { url: 'https://a.example.com/one', title: 'Result A', snippet: 'First summary' },
          { url: 'https://b.example.com/two', title: 'Result B', snippet: 'Second summary' },
        ],
        truncated: false,
      },
    })
    expect(requests).toHaveLength(1)
    expect(requests[0]!.url).toBe(SEARCH_URL)
    expect(requests[0]!.init.method).toBe('POST')
    expect(new Headers(requests[0]!.init.headers).get('content-type')).toBe('application/json')
    expect(authorizationOf(requests[0]!)).toBeNull()
    expect(bodyOf(requests[0]!)).toEqual({ query: 'hello world', max_results: 5 })
  })

  it('maxResults 超过 10 时发送 max_results=10，拿满上限则 truncated=true', async () => {
    const results = Array.from({ length: 10 }, (_, index) => ({
      title: `R${index}`,
      url: `https://r.example.com/${index}`,
    }))
    const { fetcher, requests } = createFetcher(() =>
      jsonResponse(successEnvelope({ results, metadata: { total_results: 42, search_time_ms: 1 } })),
    )
    const engine = createAnysearchEngine({ fetcher })

    const result = await engine.search!({ query: 'q', maxResults: 25 }, createContext())

    expect(bodyOf(requests[0]!)).toEqual({ query: 'q', max_results: 10 })
    if (!result.ok) throw new Error(`预期成功，实际 ${result.failure.kind}`)
    expect(result.outcome.sources).toHaveLength(10)
    expect(result.outcome.truncated).toBe(true)
  })

  it('content 映射为最长 800 字符的模型阅读 summary', async () => {
    const content = 'x'.repeat(900)
    const { fetcher } = createFetcher(() => jsonResponse(successEnvelope({
      results: [{ title: 'Long', url: 'https://long.example/a', snippet: 'short', content }],
      metadata: { total_results: 1, search_time_ms: 1 },
    })))
    const result = await createAnysearchEngine({ fetcher }).search!({ query: 'q', maxResults: 5 }, createContext())
    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.outcome.sources[0]).toMatchObject({ snippet: 'short', summary: 'x'.repeat(800) })
  })

  it('请求超过 10 但 metadata.total_results 表明总数恰好 10 条 → truncated=false（不误报）', async () => {
    const results = Array.from({ length: 10 }, (_, index) => ({
      title: `R${index}`,
      url: `https://r.example.com/${index}`,
    }))
    const { fetcher } = createFetcher(() =>
      jsonResponse(successEnvelope({ results, metadata: { total_results: 10, search_time_ms: 1 } })),
    )
    const engine = createAnysearchEngine({ fetcher })

    const result = await engine.search!({ query: 'q', maxResults: 25 }, createContext())

    if (!result.ok) throw new Error(`预期成功，实际 ${result.failure.kind}`)
    expect(result.outcome.sources).toHaveLength(10)
    expect(result.outcome.truncated).toBe(false)
  })

  it('请求上限内即使拿满 10 条也不置 truncated', async () => {
    const results = Array.from({ length: 10 }, (_, index) => ({
      title: `R${index}`,
      url: `https://r.example.com/${index}`,
    }))
    const { fetcher } = createFetcher(() => jsonResponse(successEnvelope({ results })))
    const engine = createAnysearchEngine({ fetcher })

    const result = await engine.search!({ query: 'q', maxResults: 10 }, createContext())

    if (!result.ok) throw new Error(`预期成功，实际 ${result.failure.kind}`)
    expect(result.outcome.truncated).toBe(false)
  })

  it('metadata 缺失 + 请求超过 10 且拿满 10 条 → 保守回退 truncated=true', async () => {
    const results = Array.from({ length: 10 }, (_, index) => ({
      title: `R${index}`,
      url: `https://r.example.com/${index}`,
    }))
    const { fetcher } = createFetcher(() => jsonResponse(successEnvelope({ results })))
    const engine = createAnysearchEngine({ fetcher })

    const result = await engine.search!({ query: 'q', maxResults: 25 }, createContext())

    if (!result.ok) throw new Error(`预期成功，实际 ${result.failure.kind}`)
    expect(result.outcome.truncated).toBe(true)
  })

  it('metadata.total_results 非法（字符串/负数/非整数）→ 按缺失处理，仍走保守回退', async () => {
    const results = Array.from({ length: 10 }, (_, index) => ({
      title: `R${index}`,
      url: `https://r.example.com/${index}`,
    }))
    for (const total of ['42', -1, 1.5]) {
      const { fetcher } = createFetcher(() =>
        jsonResponse(successEnvelope({ results, metadata: { total_results: total, search_time_ms: 1 } })),
      )
      const engine = createAnysearchEngine({ fetcher })

      const result = await engine.search!({ query: 'q', maxResults: 25 }, createContext())

      if (!result.ok) throw new Error(`预期成功，实际 ${result.failure.kind}`)
      expect(result.outcome.truncated).toBe(true)
    }
  })

  it('丢弃无绝对 URL 的结果，空 title/snippet 不产生字段', async () => {
    const { fetcher } = createFetcher(() =>
      jsonResponse(
        successEnvelope({
          results: [
            { title: '  Web  ', url: 'https://ok.example/1', snippet: '  S  ' },
            { title: 'No url', url: '', content: '{"x":1}' },
            { title: 'Relative', url: '/relative' },
            { title: '', url: 'https://ok.example/2', snippet: '' },
          ],
        }),
      ),
    )
    const engine = createAnysearchEngine({ fetcher })

    const result = await engine.search!({ query: 'q', maxResults: 5 }, createContext())

    expect(result).toEqual({
      ok: true,
      outcome: {
        sources: [
          { url: 'https://ok.example/1', title: 'Web', snippet: 'S' },
          { url: 'https://ok.example/2' },
        ],
        truncated: false,
      },
    })
  })

  it('HTTP 200 但信封 code!=0 → provider-error（不抛出）', async () => {
    // 契约未给出 search 的 error_code 稳定取值表（api-contracts/anysearch.json openQuestions），
    // 夹具只使用契约能证实的形状：code=-1 + message + request_id。
    const { fetcher } = createFetcher(() =>
      jsonResponse({
        code: -1,
        message: 'invalid query',
        request_id: 'req_bad',
        data: null,
      }),
    )
    const engine = createAnysearchEngine({ fetcher })

    const failure = failureOf(await engine.search!({ query: 'q', maxResults: 5 }, createContext()))

    expect(failure.kind).toBe('provider-error')
    expect(failure.detail).toContain('invalid query')
    expect(failure.detail).toContain('req_bad')
  })

  it('响应形状非法（缺 code / results 非数组）→ provider-error', async () => {
    for (const payload of [
      { message: 'no code', data: { results: [] } },
      { code: 0, message: 'success', data: { results: {} } },
      { code: 0, message: 'success', data: { results: [{ title: 'x', url: 42 }] } },
    ]) {
      const { fetcher } = createFetcher(() => jsonResponse(payload))
      const engine = createAnysearchEngine({ fetcher })
      const failure = failureOf(await engine.search!({ query: 'q', maxResults: 5 }, createContext()))
      expect(failure.kind).toBe('provider-error')
    }
  })

  it('HTTP 429 → rate-limited，保留 Retry-After 毫秒提示', async () => {
    const { fetcher } = createFetcher(() => jsonResponse({ code: -1, message: 'slow down' }, 429, { 'retry-after': '3' }))
    const engine = createAnysearchEngine({ fetcher })

    const failure = failureOf(await engine.search!({ query: 'q', maxResults: 5 }, createContext()))

    expect(failure.kind).toBe('rate-limited')
    expect(failure.statusCode).toBe(429)
    expect(failure.retryAfterMs).toBe(3000)
  })

  it('HTTP 402 → quota，且 402 正文（可能含自动建号凭据）不进入 detail', async () => {
    const secret = 'as_secret_key_must_not_leak'
    const { fetcher } = createFetcher(() =>
      jsonResponse({ code: -1, message: `username=u\npassword=p\napi_key=${secret}` }, 402),
    )
    const engine = createAnysearchEngine({ fetcher })

    const failure = failureOf(await engine.search!({ query: 'q', maxResults: 5 }, createContext()))

    expect(failure.kind).toBe('quota')
    expect(failure.statusCode).toBe(402)
    expect(failure.quotaExhausted).toBe(true)
    expect(failure.detail ?? '').not.toContain(secret)
    expect(failure.detail ?? '').not.toContain('api_key')
  })

  it.each([401, 403])('HTTP %i → auth；账号模式只请求一次，绝不降级匿名重试', async (status) => {
    const { fetcher, requests } = createFetcher(() => jsonResponse({ code: -1, message: 'bad key' }, status))
    const engine = createAnysearchEngine({ fetcher })

    const failure = failureOf(
      await engine.search!({ query: 'q', maxResults: 5 }, createContext({ apiKey: 'as_test_key' })),
    )

    expect(failure.kind).toBe('auth')
    expect(failure.statusCode).toBe(status)
    expect(requests).toHaveLength(1)
    expect(authorizationOf(requests[0]!)).toBe('Bearer as_test_key')
  })

  it.each([500, 502])('HTTP %i → provider-error', async (status) => {
    const { fetcher } = createFetcher(() => jsonResponse({ code: -1, message: 'upstream down' }, status))
    const engine = createAnysearchEngine({ fetcher })

    const failure = failureOf(await engine.search!({ query: 'q', maxResults: 5 }, createContext()))

    expect(failure.kind).toBe('provider-error')
    expect(failure.statusCode).toBe(status)
  })

  it('网络层错误 → network', async () => {
    const { fetcher } = createFetcher(() => {
      throw new TypeError('fetch failed')
    })
    const engine = createAnysearchEngine({ fetcher })

    const failure = failureOf(await engine.search!({ query: 'q', maxResults: 5 }, createContext()))

    expect(failure.kind).toBe('network')
    expect(failure.detail).toContain('fetch failed')
  })

  it('请求预算耗尽 → aborted，且不发出请求', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })

    const failure = failureOf(
      await engine.search!({ query: 'q', maxResults: 5 }, createContext({ countRequest: () => false })),
    )

    expect(failure.kind).toBe('aborted')
    expect(requests).toHaveLength(0)
  })

  it('调用方取消（AbortError）→ aborted', async () => {
    const controller = new AbortController()
    controller.abort()
    const { fetcher } = createFetcher(() => {
      const error = new Error('aborted')
      error.name = 'AbortError'
      throw error
    })
    const engine = createAnysearchEngine({ fetcher })

    const failure = failureOf(
      await engine.search!({ query: 'q', maxResults: 5 }, createContext({ signal: controller.signal })),
    )

    expect(failure.kind).toBe('aborted')
  })

  it('endpointOverride 按操作覆盖请求 URL，ctx.endpoint 次之，manifest 不变', async () => {
    const override = 'https://proxy.example/anysearch-search'
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher, endpointOverride: { search: override } })

    await engine.search!({ query: 'q', maxResults: 1 }, createContext({ endpoint: 'https://ctx.example/search' }))

    expect(requests[0]!.url).toBe(override)
    expect(ANYSEARCH_MANIFEST.endpoints.search).toBe(SEARCH_URL)
  })

  it('无 endpointOverride 时使用装配层传入的 ctx.endpoint', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })

    await engine.search!({ query: 'q', maxResults: 1 }, createContext({ endpoint: 'https://ctx.example/search' }))

    expect(requests[0]!.url).toBe('https://ctx.example/search')
  })

  it('endpointOverride 按操作拆分：search 与 fetch 各自覆盖，互不串端点', async () => {
    const { fetcher, requests } = createFetcher((url) =>
      url === 'https://proxy.example/extract' ? jsonResponse(extractBody) : jsonResponse(searchBody),
    )
    const engine = createAnysearchEngine({
      fetcher,
      endpointOverride: { search: 'https://proxy.example/search', fetch: 'https://proxy.example/extract' },
    })

    await engine.search!({ query: 'q', maxResults: 1 }, createContext())
    await engine.fetch!('https://example.com/article', createContext())

    expect(requests.map(request => request.url)).toEqual([
      'https://proxy.example/search',
      'https://proxy.example/extract',
    ])
  })
})

describe('AnySearch 查询语法映射（AD13）', () => {
  it('unsupported site: 原样回拼进 query；未给 lang 时不带 language 字段', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })

    await engine.search!(
      {
        query: 'deepseek   harness site:github.com',
        maxResults: 5,
        syntax: syntaxOf({
          domains: ['github.com'],
          bareQuery: 'deepseek harness',
          operators: [{ kind: 'site', raw: 'site:github.com', value: 'github.com' }],
        }),
      },
      createContext(),
    )

    const body = bodyOf(requests[0]!) as Record<string, unknown>
    expect(body.query).toBe('deepseek harness site:github.com')
    expect(body).not.toHaveProperty('language')
    expect(body.max_results).toBe(5)
  })

  it('-site:/after:/before: 逐 token 回拼，bareQuery 保留其余词', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })

    await engine.search!(
      {
        query: 'rust   async site:doc.rust-lang.org -site:medium.com after:2026-01 before:2026-02',
        maxResults: 3,
        syntax: syntaxOf({
          domains: ['doc.rust-lang.org'],
          excludeDomains: ['medium.com'],
          after: '2026-01',
          before: '2026-02',
          bareQuery: 'rust async',
          operators: [
            { kind: 'site', raw: 'site:doc.rust-lang.org', value: 'doc.rust-lang.org' },
            { kind: '-site', raw: '-site:medium.com', value: 'medium.com' },
            { kind: 'after', raw: 'after:2026-01', value: '2026-01' },
            { kind: 'before', raw: 'before:2026-02', value: '2026-02' },
          ],
        }),
      },
      createContext(),
    )

    expect((bodyOf(requests[0]!) as Record<string, unknown>).query).toBe(
      'rust async site:doc.rust-lang.org -site:medium.com after:2026-01 before:2026-02',
    )
  })

  it('lang: 映射到请求体 language，且不留在发出的 query 文本', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })

    await engine.search!(
      {
        query: 'hello lang:en',
        maxResults: 5,
        syntax: syntaxOf({
          language: 'en',
          bareQuery: 'hello',
          operators: [{ kind: 'lang', raw: 'lang:en', value: 'en' }],
        }),
      },
      createContext(),
    )

    expect(bodyOf(requests[0]!)).toEqual({ query: 'hello', max_results: 5, language: 'en' })
  })

  it('lang 与 unsupported 同时出现：language 走原生字段，site: 回拼进 query', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })

    await engine.search!(
      {
        query: 'hello site:github.com lang:en',
        maxResults: 5,
        syntax: syntaxOf({
          domains: ['github.com'],
          language: 'en',
          bareQuery: 'hello',
          operators: [
            { kind: 'site', raw: 'site:github.com', value: 'github.com' },
            { kind: 'lang', raw: 'lang:en', value: 'en' },
          ],
        }),
      },
      createContext(),
    )

    expect(bodyOf(requests[0]!)).toEqual({
      query: 'hello site:github.com',
      max_results: 5,
      language: 'en',
    })
  })

  it('纯操作符查询：query 只剩回拼的 token', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })

    await engine.search!(
      {
        query: '  site:github.com  ',
        maxResults: 5,
        syntax: syntaxOf({
          domains: ['github.com'],
          bareQuery: '',
          operators: [{ kind: 'site', raw: 'site:github.com', value: 'github.com' }],
        }),
      },
      createContext(),
    )

    expect((bodyOf(requests[0]!) as Record<string, unknown>).query).toBe('site:github.com')
  })

  it('无 syntax 时 query 逐字沿用原文（不折叠空白），且不带 language', async () => {
    const raw = '  raw   site:github.com  '
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })

    await engine.search!({ query: raw, maxResults: 5 }, createContext())

    const body = bodyOf(requests[0]!) as Record<string, unknown>
    expect(body.query).toBe(raw)
    expect(body).not.toHaveProperty('language')
  })

  it('unsupported 回拼逐字保留 raw：原始大小写与路径后缀不改写', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })
    const query = 'docs site:GitHub.COM/deepseek-ai/deepseek-harness'

    await engine.search!({ query, maxResults: 5, syntax: parseQuerySyntax(query) }, createContext())

    expect((bodyOf(requests[0]!) as Record<string, unknown>).query).toBe(
      'docs site:GitHub.COM/deepseek-ai/deepseek-harness',
    )
  })

  it('多操作符乱序回拼：保持 operators 出现顺序，不按类型重排', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })
    const query = 'rust before:2026-02 site:doc.rust-lang.org after:2026-01 -site:medium.com'

    await engine.search!({ query, maxResults: 5, syntax: parseQuerySyntax(query) }, createContext())

    expect((bodyOf(requests[0]!) as Record<string, unknown>).query).toBe(
      'rust before:2026-02 site:doc.rust-lang.org after:2026-01 -site:medium.com',
    )
  })

  it('lang: 被原生字段消费后，其 raw 不再回拼进 query（含原始大小写 token）', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })
    const query = 'hello lang:ZH'

    await engine.search!({ query, maxResults: 5, syntax: parseQuerySyntax(query) }, createContext())

    expect(bodyOf(requests[0]!)).toEqual({ query: 'hello', max_results: 5, language: 'zh' })
  })

  it('回拼结果为空时退回 request.query 原文', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })
    const query = 'lang:ZH'

    await engine.search!({ query, maxResults: 5, syntax: parseQuerySyntax(query) }, createContext())

    expect(bodyOf(requests[0]!)).toEqual({ query: 'lang:ZH', max_results: 5, language: 'zh' })
  })
})

describe('AnySearch 提取', () => {
  it('成功：请求体只含 url，返回 text 正文与 data.url', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(extractBody))
    const engine = createAnysearchEngine({ fetcher })

    const result = await engine.fetch!('https://example.com/article', createContext())

    expect(result).toEqual({
      ok: true,
      outcome: {
        url: 'https://example.com/article-final',
        statusCode: 200,
        body: { kind: 'text', content: 'Cleaned body.' },
        truncated: false,
      },
    })
    expect(requests).toHaveLength(1)
    expect(requests[0]!.url).toBe(FETCH_URL)
    expect(requests[0]!.init.method).toBe('POST')
    expect(authorizationOf(requests[0]!)).toBeNull()
    // 契约：请求体只允许 url 一个字段。
    expect(Object.keys(bodyOf(requests[0]!) as Record<string, unknown>)).toEqual(['url'])
    expect(bodyOf(requests[0]!)).toEqual({ url: 'https://example.com/article' })
  })

  it('data.url 非绝对 http(s) 时回退输入 URL，不透传脏值', async () => {
    const { fetcher } = createFetcher(() =>
      jsonResponse(successEnvelope({ url: '/relative-final', title: 't', content: 'body' })),
    )
    const engine = createAnysearchEngine({ fetcher })

    const result = await engine.fetch!('https://example.com/article', createContext())

    if (!result.ok) throw new Error(`预期成功，实际 ${result.failure.kind}`)
    expect(result.outcome.url).toBe('https://example.com/article')
  })

  it('有 key 时发送 Bearer', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(extractBody))
    const engine = createAnysearchEngine({ fetcher })

    await engine.fetch!('https://example.com/article', createContext({ apiKey: 'as_test_key' }))

    expect(authorizationOf(requests[0]!)).toBe('Bearer as_test_key')
  })

  it('HTTP 422（extract_failed）→ target-status，statusCode 必填', async () => {
    const { fetcher } = createFetcher(() =>
      jsonResponse({ code: -1, message: 'extract failed', request_id: 'req_e', error_code: 'extract_failed' }, 422),
    )
    const engine = createAnysearchEngine({ fetcher })

    const failure = failureOf(await engine.fetch!('https://example.com/article', createContext()))

    expect(failure.kind).toBe('target-status')
    expect(failure.statusCode).toBe(422)
  })

  it.each([
    [403, 'extract_target_blocked', 'target-status', 403, false],
    [502, 'extract_target_blocked', 'target-status', 502, false],
    [502, 'extract_content_too_large', 'provider-error', 502, true],
    [500, 'extract_unsupported_content', 'provider-error', 500, true],
    [504, 'extract_timeout', 'timeout', 504, true],
    [500, 'extract_canceled', 'aborted', 500, false],
    [401, 'invalid_extract_url', 'invalid', 401, false],
  ] as const)(
    'HTTP %i + error_code=%s → %s（error_code 优先于 HTTP 状态）',
    async (status, errorCode, kind, statusCode, cooldownable) => {
      const { fetcher } = createFetcher(() =>
        jsonResponse(
          { code: -1, message: 'extract failed', request_id: 'req_code', error_code: errorCode },
          status,
        ),
      )
      const engine = createAnysearchEngine({ fetcher })

      const failure = failureOf(await engine.fetch!('https://example.com/article', createContext()))

      expect(failure.kind).toBe(kind)
      expect(failure.statusCode).toBe(statusCode)
      expect(failure.cooldownable).toBe(cooldownable)
      expect(failure.detail).toContain(`error_code=${errorCode}`)
      expect(failure.detail).toContain('request_id=req_code')
    },
  )

  it('extract HTTP 400 无业务码 → invalid（URL/请求体非法，不冷却引擎）', async () => {
    const { fetcher } = createFetcher(() => jsonResponse({ code: -1, message: 'bad url' }, 400))
    const engine = createAnysearchEngine({ fetcher })

    const failure = failureOf(await engine.fetch!('https://example.com/article', createContext()))

    expect(failure.kind).toBe('invalid')
    expect(failure.statusCode).toBe(400)
    expect(failure.cooldownable).toBe(false)
  })

  it('extract HTTP 400 + error_code=invalid_extract_url → invalid', async () => {
    const { fetcher } = createFetcher(() =>
      jsonResponse({ code: -1, message: 'bad url', request_id: 'req_400', error_code: 'invalid_extract_url' }, 400),
    )
    const engine = createAnysearchEngine({ fetcher })

    const failure = failureOf(await engine.fetch!('https://example.com/article', createContext()))

    expect(failure.kind).toBe('invalid')
    expect(failure.statusCode).toBe(400)
    expect(failure.cooldownable).toBe(false)
    expect(failure.detail).toContain('error_code=invalid_extract_url')
  })

  it('业务 error_code 查表大小写不敏感：大写码同样命中映射', async () => {
    const { fetcher } = createFetcher(() =>
      jsonResponse({ code: -1, message: 'blocked', request_id: 'req_upper', error_code: 'EXTRACT_TARGET_BLOCKED' }, 403),
    )
    const engine = createAnysearchEngine({ fetcher })

    const failure = failureOf(await engine.fetch!('https://example.com/article', createContext()))

    expect(failure.kind).toBe('target-status')
    expect(failure.detail).toContain('error_code=EXTRACT_TARGET_BLOCKED')
  })

  it('search 侧不套用 extract 错误码映射：带 error_code 的 403 仍是 auth', async () => {
    const { fetcher } = createFetcher(() =>
      jsonResponse({ code: -1, message: 'forbidden', error_code: 'extract_target_blocked' }, 403),
    )
    const engine = createAnysearchEngine({ fetcher })

    const failure = failureOf(
      await engine.search!({ query: 'q', maxResults: 5 }, createContext({ apiKey: 'as_test_key' })),
    )

    expect(failure.kind).toBe('auth')
    expect(failure.statusCode).toBe(403)
  })

  it('正文含截断标记 → truncated=true', async () => {
    const content = `${'x'.repeat(100)}...(content truncated)`
    const { fetcher } = createFetcher(() => jsonResponse(successEnvelope({ url: 'https://e.example/a', title: 't', content })))
    const engine = createAnysearchEngine({ fetcher })

    const result = await engine.fetch!('https://e.example/a', createContext())

    if (!result.ok) throw new Error(`预期成功，实际 ${result.failure.kind}`)
    expect(result.outcome.truncated).toBe(true)
    expect(result.outcome.body.content).toBe(content)
  })

  it('JSON/Markdown 无标记且恰好 50,000 字符 → truncated=false（等于上限无法区分，按完整处理）', async () => {
    const content = 'x'.repeat(50_000)
    const { fetcher } = createFetcher(() => jsonResponse(successEnvelope({ url: 'https://e.example/a', title: 't', content })))
    const engine = createAnysearchEngine({ fetcher })

    const result = await engine.fetch!('https://e.example/a', createContext())

    if (!result.ok) throw new Error(`预期成功，实际 ${result.failure.kind}`)
    expect(result.outcome.truncated).toBe(false)
  })

  it('JSON/Markdown 无标记但超过 50,000 字符 → truncated=true', async () => {
    const content = 'x'.repeat(50_001)
    const { fetcher } = createFetcher(() => jsonResponse(successEnvelope({ url: 'https://e.example/a', title: 't', content })))
    const engine = createAnysearchEngine({ fetcher })

    const result = await engine.fetch!('https://e.example/a', createContext())

    if (!result.ok) throw new Error(`预期成功，实际 ${result.failure.kind}`)
    expect(result.outcome.truncated).toBe(true)
  })

  it('非绝对 http(s) URL → invalid，且不发请求', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(extractBody))
    const engine = createAnysearchEngine({ fetcher })

    const failure = failureOf(await engine.fetch!('not a url', createContext()))

    expect(failure.kind).toBe('invalid')
    expect(requests).toHaveLength(0)
  })

  it('请求体超过 16 KiB → invalid，且不发请求', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(extractBody))
    const engine = createAnysearchEngine({ fetcher })
    const huge = `https://example.com/${'a'.repeat(17 * 1024)}`

    const failure = failureOf(await engine.fetch!(huge, createContext()))

    expect(failure.kind).toBe('invalid')
    expect(requests).toHaveLength(0)
  })

  it('网络层错误 → network', async () => {
    const { fetcher } = createFetcher(() => {
      throw new TypeError('socket hang up')
    })
    const engine = createAnysearchEngine({ fetcher })

    const failure = failureOf(await engine.fetch!('https://example.com/a', createContext()))

    expect(failure.kind).toBe('network')
  })

  it('提取侧 HTTP 402 同样投影为 quota，且不泄漏正文', async () => {
    const secret = 'as_secret_on_extract'
    const { fetcher } = createFetcher(() => jsonResponse({ code: -1, message: `api_key=${secret}` }, 402))
    const engine = createAnysearchEngine({ fetcher })

    const failure = failureOf(await engine.fetch!('https://example.com/a', createContext()))

    expect(failure.kind).toBe('quota')
    expect(failure.statusCode).toBe(402)
    expect(failure.detail ?? '').not.toContain(secret)
  })
})

describe('AnySearch 垂直取数与区域默认值（v0.4）', () => {
  it('vertical：tag 与标量 params 原样透传，max_results 仍钳 1–10', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })

    await engine.search!(
      {
        query: 'BTCUSD',
        maxResults: 25,
        vertical: {
          tag: 'finance.quote',
          params: { type: 'crypto', symbol: 'BTCUSD', limit: 3, realtime: true },
        },
      },
      createContext(),
    )

    expect(bodyOf(requests[0]!)).toEqual({
      query: 'BTCUSD',
      max_results: 10,
      tag: 'finance.quote',
      params: { type: 'crypto', symbol: 'BTCUSD', limit: 3, realtime: true },
    })
  })

  it('vertical params：嵌套对象/数组/非有限数值按字段剔除，合法键保留', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })
    const params = {
      type: 'gdp',
      nested: { year: 2026 },
      list: [1, 2],
      infinite: Number.POSITIVE_INFINITY,
      nan: Number.NaN,
      flag: false,
    } as unknown as Readonly<Record<string, string | number | boolean>>

    await engine.search!(
      { query: 'GDP', maxResults: 3, vertical: { tag: 'finance.macro', params } },
      createContext(),
    )

    const body = bodyOf(requests[0]!) as Record<string, unknown>
    expect(body.tag).toBe('finance.macro')
    expect(body.params).toEqual({ type: 'gdp', flag: false })
  })

  it('vertical params 全部非法或为空时省略 params，只发 tag', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })
    const params = {
      nested: { a: 1 },
      list: ['x'],
    } as unknown as Readonly<Record<string, string | number | boolean>>

    await engine.search!(
      { query: 'q', maxResults: 5, vertical: { tag: 'general.general', params } },
      createContext(),
    )

    expect(bodyOf(requests[0]!)).toEqual({ query: 'q', max_results: 5, tag: 'general.general' })
  })

  it('空 tag 视为没有 vertical：请求体保持通用搜索形状', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })

    await engine.search!({ query: 'q', maxResults: 5, vertical: { tag: '' } }, createContext())

    expect(bodyOf(requests[0]!)).toEqual({ query: 'q', max_results: 5 })
  })

  it('zone/language 工厂默认写入请求体，通用与垂直搜索都带', async () => {
    const general = createFetcher(() => jsonResponse(searchBody))
    const generalEngine = createAnysearchEngine({ fetcher: general.fetcher, zone: 'cn', language: 'zh-CN' })

    await generalEngine.search!({ query: 'q', maxResults: 5 }, createContext())

    expect(bodyOf(general.requests[0]!)).toEqual({
      query: 'q',
      max_results: 5,
      zone: 'cn',
      language: 'zh-CN',
    })

    const vertical = createFetcher(() => jsonResponse(searchBody))
    const verticalEngine = createAnysearchEngine({ fetcher: vertical.fetcher, zone: 'intl', language: 'en' })

    await verticalEngine.search!(
      { query: 'react', maxResults: 5, vertical: { tag: 'code.doc', params: { library: 'react' } } },
      createContext(),
    )

    expect(bodyOf(vertical.requests[0]!)).toEqual({
      query: 'react',
      max_results: 5,
      tag: 'code.doc',
      params: { library: 'react' },
      zone: 'intl',
      language: 'en',
    })
  })

  it('syntax.language 优先于工厂默认 language（syntax 覆盖工厂）', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher, language: 'zh-CN' })

    await engine.search!(
      {
        query: 'hello lang:en',
        maxResults: 5,
        syntax: syntaxOf({
          language: 'en',
          bareQuery: 'hello',
          operators: [{ kind: 'lang', raw: 'lang:en', value: 'en' }],
        }),
      },
      createContext(),
    )

    expect(bodyOf(requests[0]!)).toEqual({ query: 'hello', max_results: 5, language: 'en' })
  })

  it('无 vertical 且未配置工厂默认时请求体与旧行为完全一致（只含 query/max_results）', async () => {
    const { fetcher, requests } = createFetcher(() => jsonResponse(searchBody))
    const engine = createAnysearchEngine({ fetcher })

    await engine.search!({ query: 'q', maxResults: 5 }, createContext())

    expect(bodyOf(requests[0]!)).toEqual({ query: 'q', max_results: 5 })
  })

  it('垂直搜索：无 URL 的结构化结果序列化进 content，sources 只保留有 URL 的条目', async () => {
    const { fetcher } = createFetcher(() => jsonResponse(successEnvelope({
      results: [
        { title: 'GDP 数据', url: '', content: '{"gdp":1071071,"gdp_yoy":4.6}' },
        { title: '引用来源', url: 'https://ok.example/1', snippet: 'S' },
        { title: 'CPI 数据', content: '{"cpi":1.1}' },
      ],
      metadata: { total_results: 3, search_time_ms: 12 },
    })))
    const engine = createAnysearchEngine({ fetcher })

    const result = await engine.search!(
      { query: 'GDP', maxResults: 5, vertical: { tag: 'finance.macro', params: { type: 'gdp' } } },
      createContext(),
    )

    if (!result.ok) throw new Error(`预期成功，实际 ${result.failure.kind}`)
    expect(result.outcome.sources).toEqual([
      { url: 'https://ok.example/1', title: '引用来源', snippet: 'S' },
    ])
    expect(result.outcome.content).toBeDefined()
    expect(result.outcome.content!.startsWith('结构化数据 2 条（无引用链接）：')).toBe(true)
    expect(result.outcome.content).toContain('GDP 数据')
    expect(result.outcome.content).toContain('CPI 数据')
    expect(result.outcome.content).toContain('gdp')
    expect(result.outcome.content).not.toContain('https://ok.example/1')
  })

  it('通用搜索：无 URL 条目仍被过滤，不产生 content', async () => {
    const { fetcher } = createFetcher(() => jsonResponse(successEnvelope({
      results: [
        { title: 'No url', url: '', content: '{"x":1}' },
        { title: 'OK', url: 'https://ok.example/1' },
      ],
    })))
    const engine = createAnysearchEngine({ fetcher })

    const result = await engine.search!({ query: 'q', maxResults: 5 }, createContext())

    expect(result).toEqual({
      ok: true,
      outcome: {
        sources: [{ url: 'https://ok.example/1', title: 'OK' }],
        truncated: false,
      },
    })
  })
})
