/**
 * 引擎共享 HTTP 核心与失败模型的离线单测——注入 fetcher 替身，不触网。
 * 守三个横切行为：
 *   a) engineFailure 复制 retryAfterMs（熔断冷却时长的依据）；
 *   b) engineFetch 的 429 + retry-after 经 projectHttpError 端到端保留 retryAfterMs；
 *   c) EngineHttpError.body 保留完整 JSON 错误体（业务错误码来源），非 JSON 体时为 undefined。
 */
import { describe, expect, it } from 'vitest'
import type { EngineContext } from '../../src/engines/contract.js'
import { engineFailure } from '../../src/engines/failure.js'
import { EngineHttpError, engineFetch, engineJson, projectHttpError } from '../../src/engines/http.js'

const REQUEST_URL = 'https://api.example.com/v1/search'

function createContext(overrides: Partial<EngineContext> = {}): EngineContext {
  return {
    signal: new AbortController().signal,
    deadline: Date.now() + 60_000,
    endpoint: '',
    countRequest: () => true,
    ...overrides,
  }
}

/** engineFetch 只抛 EngineHttpError；断言失败类型后返回以便读字段。 */
async function captureHttpError(run: () => Promise<unknown>): Promise<EngineHttpError> {
  try {
    await run()
  } catch (error) {
    if (error instanceof EngineHttpError) return error
    throw error
  }
  throw new Error('预期抛出 EngineHttpError，实际成功返回')
}

function fetcherReturning(response: Response): typeof fetch {
  return async () => response
}

describe('engineFailure', () => {
  it('复制 retryAfterMs 到失败模型', () => {
    const failure = engineFailure('rate-limited', { statusCode: 429, retryAfterMs: 1500 })
    expect(failure.retryAfterMs).toBe(1500)
  })
})

describe('engineFetch → projectHttpError', () => {
  it('429 + retry-after 头端到端保留 retryAfterMs', async () => {
    const response = new Response(JSON.stringify({ error: 'slow down' }), {
      status: 429,
      headers: { 'content-type': 'application/json', 'retry-after': '2' },
    })
    const error = await captureHttpError(() =>
      engineFetch(createContext(), REQUEST_URL, { fetcher: fetcherReturning(response) }))

    const failure = projectHttpError(error)
    expect(failure.kind).toBe('rate-limited')
    expect(failure.statusCode).toBe(429)
    expect(failure.retryAfterMs).toBe(2000)
  })

  it('单请求超时 → kind=timeout，projectHttpError 归 timeout（不再伪装 network）', async () => {
    const hangingFetcher = ((_input: string | URL | Request, init?: RequestInit) =>
      new Promise<Response>((_resolve, reject) => {
        init?.signal?.addEventListener('abort', () => reject(new DOMException('timed out', 'TimeoutError')), { once: true })
      })) as typeof fetch
    const error = await captureHttpError(() =>
      engineFetch(createContext(), REQUEST_URL, { fetcher: hangingFetcher, timeoutMs: 5 }))

    expect(error.kind).toBe('timeout')
    expect(projectHttpError(error).kind).toBe('timeout')
  })
})

describe('EngineHttpError.body', () => {
  it('JSON 错误体完整解析进 body（不受 detail 限长影响）', async () => {
    const payload = {
      code: 0,
      error_code: 'extract_failed',
      message: `目标站返回 422：${'x'.repeat(400)}`,
    }
    const response = new Response(JSON.stringify(payload), {
      status: 422,
      headers: { 'content-type': 'application/json' },
    })
    const error = await captureHttpError(() =>
      engineFetch(createContext(), REQUEST_URL, { fetcher: fetcherReturning(response) }))

    expect(error.status).toBe(422)
    expect(error.body).toEqual(payload)
    expect(error.detail).toContain('extract_failed')
  })

  it('非 JSON 错误体时 body 为 undefined，detail 保留文本', async () => {
    const response = new Response('<html>upstream error</html>', {
      status: 502,
      headers: { 'content-type': 'text/html' },
    })
    const error = await captureHttpError(() =>
      engineFetch(createContext(), REQUEST_URL, { fetcher: fetcherReturning(response) }))

    expect(error.status).toBe(502)
    expect(error.body).toBeUndefined()
    expect(error.detail).toBe('<html>upstream error</html>')
  })

  it('错误体超过读取上限 → 不整包解析，body 为 undefined，detail 仍限长', async () => {
    const response = new Response(JSON.stringify({ error: 'x'.repeat(70_000) }), {
      status: 500,
      headers: { 'content-type': 'application/json' },
    })
    const error = await captureHttpError(() =>
      engineFetch(createContext(), REQUEST_URL, { fetcher: fetcherReturning(response) }))

    expect(error.status).toBe(500)
    expect(error.body).toBeUndefined()
    expect(error.detail!.length).toBeLessThanOrEqual(2049)
  })
})

describe('engineJson', () => {
  it('成功响应体读取中断 → network，不伪装成解析失败', async () => {
    const response = new Response(new ReadableStream({
      start(controller) { controller.error(new Error('socket reset')) },
    }))
    const error = await captureHttpError(() =>
      engineJson(createContext(), REQUEST_URL, { fetcher: fetcherReturning(response) }))

    expect(error.kind).toBe('network')
    expect(projectHttpError(error).kind).toBe('network')
  })

  it('成功响应超过读取上限时失败，不解析残包', async () => {
    const response = new Response('x'.repeat(5 * 1024 * 1024 + 1))
    const error = await captureHttpError(() =>
      engineJson(createContext(), REQUEST_URL, { fetcher: fetcherReturning(response) }))

    expect(error.kind).toBe('parse')
    expect(error.detail).toContain('字节上限')
  })

  it('第一块正好到上限、后续仍有数据时也按超限失败', async () => {
    const limit = 5 * 1024 * 1024
    const prefix = '{"x":"'
    const suffix = '"}'
    const json = prefix + 'a'.repeat(limit - prefix.length - suffix.length) + suffix
    const body = new ReadableStream({
      start(controller) {
        controller.enqueue(new TextEncoder().encode(json))
        controller.enqueue(new TextEncoder().encode(' '))
        controller.close()
      },
    })
    const response = new Response(body)
    const error = await captureHttpError(() =>
      engineJson(createContext(), REQUEST_URL, { fetcher: fetcherReturning(response) }))

    expect(error.kind).toBe('parse')
    expect(error.detail).toContain('字节上限')
  })
})
