import { describe, expect, it } from 'vitest'
import { buildLockClosure, compareInventory } from '../scripts/dependency-inventory.mjs'

const pkg = {
  name: 'example',
  version: '1.0.0',
  dependencies: { alpha: '1.0.0' },
}

const lock = {
  importers: { '.': { dependencies: { alpha: { specifier: '1.0.0', version: '1.0.0' } } } },
  snapshots: { 'alpha@1.0.0': {} },
  packages: { 'alpha@1.0.0': { resolution: { integrity: 'sha512-alpha' } } },
}

const inventory = {
  packageName: 'example',
  packageVersion: '1.0.0',
  packages: [{ name: 'alpha', version: '1.0.0', direct: true, integrity: 'sha512-alpha' }],
}

describe('dependency inventory', () => {
  it('matches the lock closure', () => {
    expect(compareInventory(pkg, inventory, buildLockClosure(pkg, lock))).toEqual([])
  })

  it('detects missing, stale and direct-flag changes', () => {
    const packages = buildLockClosure(pkg, lock)
    expect(compareInventory(pkg, { ...inventory, packages: [] }, packages))
      .toContain('dependency inventory is missing alpha@1.0.0')
    expect(compareInventory(pkg, {
      ...inventory,
      packages: [{ ...inventory.packages[0], integrity: 'sha512-old' }],
    }, packages)).toContain('dependency inventory integrity is stale for alpha@1.0.0')
    expect(compareInventory(pkg, {
      ...inventory,
      packages: [{ ...inventory.packages[0], direct: false }],
    }, packages)).toContain('dependency inventory direct flag is stale for alpha@1.0.0')
    expect(compareInventory(pkg, {
      ...inventory,
      packages: [...inventory.packages, { name: 'beta', version: '1.0.0', direct: false, integrity: 'sha512-beta' }],
    }, packages)).toContain('dependency inventory has stale beta@1.0.0')
  })
})
