import { describe, expect, it } from 'vitest'
import { extractInterfaceFacts } from '../scripts/dsh-interface-catalog.mjs'

describe('DSH interface catalog', () => {
  it('extracts request, result and provider members', () => {
    const facts = extractInterfaceFacts(`
      export interface WebSearchRequest { readonly query: string; readonly maxResults?: number }
      export interface WebSearchProvider { available(): boolean; search(request: WebSearchRequest): Promise<unknown> }
    `, 'types.d.ts')
    expect(facts.WebSearchRequest.members).toEqual([
      { name: 'query', optional: false, type: 'string' },
      { name: 'maxResults', optional: true, type: 'number' },
    ])
    expect(facts.WebSearchProvider.members.map(member => member.name)).toEqual(['available', 'search'])
  })
})
