// v0.4 意图路由器离线单测：表驱动，逐意图正例 + 跨意图边界。
// 规则全部本地确定性，不访问网络、不读配置；每条用例只断言单一预期结果。
import { describe, expect, it } from 'vitest'
import { hasCjk, routeSearchQuery, type SearchIntent } from '../../src/search/router.js'

interface IntentCase {
  readonly query: string
  readonly intent: SearchIntent
}

const INTENT_CASES: readonly IntentCase[] = [
  // hot-list：裸热点（剥掉热点词/资讯词/平台名后没有主题词）
  { query: '热点', intent: 'hot-list' },
  { query: '今天有什么新闻', intent: 'hot-list' },
  { query: '今天有什么大事', intent: 'hot-list' },
  { query: '最近的热榜', intent: 'hot-list' },
  { query: '榜单', intent: 'hot-list' },
  { query: '新闻', intent: 'hot-list' },
  { query: '最新新闻', intent: 'hot-list' },
  // ai-news：AI 主体词 + 资讯/事件/热点触发词
  { query: 'AI 本周新闻', intent: 'ai-news' },
  { query: '大模型 最新发布', intent: 'ai-news' },
  { query: 'DeepSeek 最近动态', intent: 'ai-news' },
  { query: 'Claude 新版本 热点', intent: 'ai-news' },
  { query: 'OpenAI 最新新闻', intent: 'ai-news' },
  { query: 'OpenAI 热点', intent: 'ai-news' },
  { query: 'OpenAI 本周新闻', intent: 'ai-news' },
  { query: 'Grok 最新新闻', intent: 'ai-news' },
  { query: 'Anthropic 发布', intent: 'ai-news' },
  { query: 'Mistral 动态', intent: 'ai-news' },
  { query: 'xAI 快讯', intent: 'ai-news' },
  { query: 'gpt5 新闻', intent: 'ai-news' },
  { query: 'llama 4 发布', intent: 'ai-news' },
  { query: 'qwen 最新动态', intent: 'ai-news' },
  { query: 'gemini 事件', intent: 'ai-news' },
  { query: 'AI 今天发生了什么', intent: 'ai-news' },
  { query: 'AI 事件', intent: 'ai-news' },
  { query: 'AI agent 新闻', intent: 'ai-news' },
  // community-opinion：社区/站内观点式提问
  { query: '知乎 如何学习 Rust', intent: 'community-opinion' },
  { query: '这个方案 怎么看', intent: 'community-opinion' },
  { query: '如何评价 新版 框架', intent: 'community-opinion' },
  { query: '转行做后端 有什么经验', intent: 'community-opinion' },
  { query: '这个配置 靠谱吗', intent: 'community-opinion' },
  { query: '知乎 热榜 科技', intent: 'community-opinion' },
  // vertical-data：结构化取数线索
  { query: '苹果 股价', intent: 'vertical-data' },
  { query: '英伟达 财报', intent: 'vertical-data' },
  { query: '中国 GDP 增速', intent: 'vertical-data' },
  { query: 'CVE-2026-1234 影响版本', intent: 'vertical-data' },
  { query: '上海 招聘 后端工程师', intent: 'vertical-data' },
  { query: '微博 用户 讨论', intent: 'vertical-data' },
  { query: 'Twitter 上的讨论', intent: 'vertical-data' },
  { query: '苹果 公司信息', intent: 'vertical-data' },
  { query: '苹果 财报日历', intent: 'vertical-data' },
  { query: '航班号 CA1234', intent: 'vertical-data' },
  { query: 'CA1234 航班', intent: 'vertical-data' },
  { query: '航班 MU5678', intent: 'vertical-data' },
  { query: '上海 到 北京 机票', intent: 'vertical-data' },
  { query: '买机票', intent: 'vertical-data' },
  { query: '查询航班', intent: 'vertical-data' },
  { query: '微博热搜', intent: 'vertical-data' },
  { query: '微博热搜 某明星', intent: 'vertical-data' },
  { query: '微博热榜', intent: 'vertical-data' },
  { query: '热点 股票', intent: 'vertical-data' },
  { query: '比特币 行情', intent: 'vertical-data' },
  { query: '全球 农业统计', intent: 'vertical-data' },
  { query: '某公司 商务联系人', intent: 'vertical-data' },
  { query: '中国 原油产量', intent: 'vertical-data' },
  { query: '电影 磁力链接', intent: 'vertical-data' },
  { query: '英雄联盟 排位 战绩', intent: 'vertical-data' },
  { query: '全球 公共卫生统计', intent: 'vertical-data' },
  { query: '背景扫描 1.2.3.4', intent: 'vertical-data' },
  { query: '安全扫描 example.com', intent: 'vertical-data' },
  // research：对比/综述/调研/盘点/比较
  { query: '主流向量数据库 对比', intent: 'research' },
  { query: 'AI 大模型 综述', intent: 'research' },
  { query: '国产大模型 调研 盘点', intent: 'research' },
  { query: 'AI 论文 综述', intent: 'research' },
  { query: '大模型 论文 综述', intent: 'research' },
  { query: 'AI 论文 对比', intent: 'research' },
  // english-web：无 CJK 且含拉丁字母（单个英文词也算）
  { query: 'how to configure vite plugins', intent: 'english-web' },
  { query: 'python asyncio sleep example', intent: 'english-web' },
  { query: 'typescript error TS2345', intent: 'english-web' },
  { query: 'kubernetes', intent: 'english-web' },
  { query: 'vitest', intent: 'english-web' },
  { query: 'webpack', intent: 'english-web' },
  { query: 'site:github.com', intent: 'english-web' },
  { query: 'site:arxiv.org', intent: 'english-web' },
  { query: 'transformer', intent: 'english-web' },
  // chinese-web：含 CJK 或没有拉丁字母的默认路径
  { query: '红烧肉 做法', intent: 'chinese-web' },
  { query: '北京 周末 去哪玩', intent: 'chinese-web' },
  { query: '苹果 公司', intent: 'chinese-web' },
  { query: 'react 和 vue 哪个好', intent: 'chinese-web' },
  { query: 'python 和 java 哪个好', intent: 'chinese-web' },
  { query: '特斯拉 Model Y 降价', intent: 'chinese-web' },
  { query: '苹果 iPhone 17 Pro 发布', intent: 'chinese-web' },
  { query: 'iPhone 17 Pro 值得买吗', intent: 'chinese-web' },
  { query: '科技 热点', intent: 'chinese-web' },
  { query: '苹果 新闻', intent: 'chinese-web' },
  { query: 'AI 最新 教程', intent: 'chinese-web' },
  { query: 'AI 最新 版本 下载', intent: 'chinese-web' },
  { query: 'travel agent 最新新闻', intent: 'chinese-web' },
  { query: '参考文献 格式', intent: 'chinese-web' },
  { query: '论文 怎么写', intent: 'chinese-web' },
  { query: 'arXiv 论文 下载', intent: 'chinese-web' },
  { query: '机票 怎么买便宜', intent: 'chinese-web' },
  { query: '股价 是什么意思', intent: 'chinese-web' },
  { query: '专利 怎么申请', intent: 'chinese-web' },
  { query: '法规 是什么', intent: 'chinese-web' },
  { query: 'transformer 注意力机制 原理', intent: 'chinese-web' },
  { query: '机器学习 入门 ML', intent: 'chinese-web' },
  { query: '通用搜索 红烧肉', intent: 'chinese-web' },
]

describe('routeSearchQuery：意图判定（表驱动）', () => {
  for (const { query, intent } of INTENT_CASES) {
    it(`${query} → ${intent}`, () => {
      expect(routeSearchQuery(query).intent).toBe(intent)
    })
  }

  it('每类意图至少 3 个正例（表自身防呆）', () => {
    const intents: readonly SearchIntent[] = [
      'ai-news', 'community-opinion', 'hot-list', 'vertical-data', 'english-web', 'research', 'chinese-web',
    ]
    for (const intent of intents) {
      expect(INTENT_CASES.filter(item => item.intent === intent).length).toBeGreaterThanOrEqual(3)
    }
  })

  it('每个分支都给出非空 note', () => {
    for (const { query } of INTENT_CASES) {
      expect(routeSearchQuery(query).note.id.length).toBeGreaterThan(0)
    }
  })
})

describe('跨意图边界：热点', () => {
  it('裸热点走 hot-list，带主题词则回落中文网页', () => {
    expect(routeSearchQuery('热点').intent).toBe('hot-list')
    expect(routeSearchQuery('科技 热点').intent).toBe('chinese-web')
  })

  it('榜单/新闻/最新新闻 裸查询统一走 hot-list', () => {
    for (const query of ['榜单', '新闻', '最新新闻']) {
      expect(routeSearchQuery(query).intent).toBe('hot-list')
    }
  })

  it('AI + 热点走 ai-news 并启用热点榜', () => {
    const decision = routeSearchQuery('AI 热点')
    expect(decision.intent).toBe('ai-news')
    expect(decision.useHotTopics).toBe(true)
  })

  it('AI + 新闻（非热点）走 ai-news 但不启用热点榜', () => {
    const decision = routeSearchQuery('AI 本周新闻')
    expect(decision.intent).toBe('ai-news')
    expect(decision.useHotTopics).toBe(false)
  })

  it('AI 问题混在热点问句里仍归 ai-news', () => {
    expect(routeSearchQuery('AI 今天有什么新闻').intent).toBe('ai-news')
    expect(routeSearchQuery('今天有什么新闻').intent).toBe('hot-list')
  })

  it('带主题的热点按主题意图走：知乎热榜科技归社区观点', () => {
    expect(routeSearchQuery('知乎 热榜 科技').intent).toBe('community-opinion')
  })

  it('微博热搜 + 主题使用 weibo_hot 频道', () => {
    expect(routeSearchQuery('微博热搜 某明星').vertical).toEqual({
      tag: 'social_media.social_media',
      params: { type: 'weibo_hot' },
    })
  })

  it('热点 + 垂直主题时垂直取数胜出', () => {
    expect(routeSearchQuery('热点 股票').intent).toBe('vertical-data')
  })

  it('site:/lang: 显式语法存在时不判裸热点，AI 域名线索不丢', () => {
    expect(routeSearchQuery('site:openai.com 新闻').intent).toBe('ai-news')
    expect(routeSearchQuery('site:reuters.com 今天有什么新闻').intent).toBe('chinese-web')
    expect(routeSearchQuery('site:github.com 新闻').intent).toBe('chinese-web')
  })
})

describe('跨意图边界：AI 资讯词表', () => {
  it('厂商/模型名（含无连字符变体）能触发 AI 资讯', () => {
    for (const query of [
      'OpenAI 最新新闻', 'Grok 最新新闻', 'Anthropic 发布', 'Mistral 动态',
      'xAI 快讯', 'gpt5 新闻', 'llama 4 发布', 'qwen 最新动态', 'gemini 事件',
    ]) {
      expect(routeSearchQuery(query).intent).toBe('ai-news')
    }
  })

  it('教程/下载形态不被当成 AI 资讯', () => {
    expect(routeSearchQuery('AI 最新 教程').intent).toBe('chinese-web')
    expect(routeSearchQuery('AI 最新 版本 下载').intent).toBe('chinese-web')
  })

  it('agent 单独出现不算 AI 语境，与其他 AI 词同现才触发', () => {
    expect(routeSearchQuery('travel agent 最新新闻').intent).toBe('chinese-web')
    expect(routeSearchQuery('AI agent 新闻').intent).toBe('ai-news')
  })

  it('事件词（发生/事件）能触发 AI 资讯', () => {
    expect(routeSearchQuery('AI 今天发生了什么').intent).toBe('ai-news')
    expect(routeSearchQuery('AI 事件').intent).toBe('ai-news')
  })

  it('「动态规划」「事件驱动」是技术术语，不触发 AI 资讯', () => {
    expect(routeSearchQuery('AI 动态规划 算法').intent).toBe('chinese-web')
    expect(routeSearchQuery('AI 事件驱动架构').intent).toBe('chinese-web')
  })

  it('品牌名贴连版本号仍算 AI 主体词', () => {
    expect(routeSearchQuery('llama3 发布').intent).toBe('ai-news')
    expect(routeSearchQuery('qwen2.5 发布').intent).toBe('ai-news')
  })

  it('AI + 热点启用热点榜，AI + 新闻不启用', () => {
    expect(routeSearchQuery('OpenAI 热点').useHotTopics).toBe(true)
    expect(routeSearchQuery('OpenAI 最新新闻').useHotTopics).toBe(false)
  })
})

describe('跨意图边界：研究优先级', () => {
  it('学术取数与综述/对比同现时调研胜出', () => {
    for (const query of ['AI 论文 综述', '大模型 论文 综述', 'AI 论文 对比', '论文 综述']) {
      expect(routeSearchQuery(query).intent).toBe('research')
    }
  })

  it('非学术垂直与调研词同现时垂直取数胜出', () => {
    expect(routeSearchQuery('苹果 股价 对比').intent).toBe('vertical-data')
    expect(routeSearchQuery('特斯拉 财报 对比').intent).toBe('vertical-data')
  })

  it('研究词优先于英文判据：英文查询带「对比」仍走 research', () => {
    expect(routeSearchQuery('React vs Vue 对比').intent).toBe('research')
  })
})

describe('跨意图边界：英文与中文', () => {
  it('含任何 CJK 字符即走中文路径，夹带英文品牌/产品名不改判', () => {
    for (const query of [
      'react 和 vue 哪个好', 'python 和 java 哪个好', '特斯拉 Model Y 降价',
      '苹果 iPhone 17 Pro 发布', 'iPhone 17 Pro 值得买吗',
    ]) {
      expect(routeSearchQuery(query).intent).toBe('chinese-web')
    }
  })

  it('单个英文词也走 english-web', () => {
    for (const query of ['kubernetes', 'vitest', 'webpack', 'transformer']) {
      expect(routeSearchQuery(query).intent).toBe('english-web')
    }
  })

  it('site: 语法不参与关键词匹配，裸域名按英文网页处理', () => {
    expect(routeSearchQuery('site:github.com').intent).toBe('english-web')
    expect(routeSearchQuery('site:arxiv.org').intent).toBe('english-web')
  })

  it('中文技术问句不再被英文占比误判', () => {
    expect(routeSearchQuery('transformer 注意力机制 原理').intent).toBe('chinese-web')
    expect(routeSearchQuery('机器学习 入门 ML').intent).toBe('chinese-web')
  })
})

describe('跨意图边界：vertical 词表', () => {
  it('泛化的「公司」不触发取数，明确的「公司信息」才触发', () => {
    const generic = routeSearchQuery('苹果 公司')
    expect(generic.intent).toBe('chinese-web')
    expect(generic.vertical).toBeUndefined()

    expect(routeSearchQuery('苹果 公司信息').vertical).toEqual({ tag: 'business.company' })
  })

  it('「苹果 股价」命中行情并填最小参数 type=stock', () => {
    expect(routeSearchQuery('苹果 股价').vertical).toEqual({
      tag: 'finance.quote',
      params: { type: 'stock' },
    })
  })

  it('没有明确标的或非股票品类时只下发 tag', () => {
    expect(routeSearchQuery('股价').vertical).toEqual({ tag: 'finance.quote' })
    expect(routeSearchQuery('比特币 行情').vertical).toEqual({ tag: 'finance.quote' })
  })

  it('具体规则先于泛化规则：财报日历、航班号', () => {
    expect(routeSearchQuery('苹果 财报日历').vertical).toEqual({ tag: 'finance.calendar' })
    expect(routeSearchQuery('航班号 CA1234').vertical).toEqual({
      tag: 'travel.flight_status',
      params: { flight_number: 'CA1234' },
    })
  })

  it('航班号命中航班状态，机票词命中机票', () => {
    expect(routeSearchQuery('CA1234 航班').vertical).toEqual({
      tag: 'travel.flight_status',
      params: { flight_number: 'CA1234' },
    })
    expect(routeSearchQuery('航班 CA1234').vertical).toEqual({
      tag: 'travel.flight_status',
      params: { flight_number: 'CA1234' },
    })
    expect(routeSearchQuery('航班 MU5678').vertical).toEqual({
      tag: 'travel.flight_status',
      params: { flight_number: 'MU5678' },
    })
    expect(routeSearchQuery('上海 到 北京 机票').vertical).toEqual({ tag: 'travel.flight' })
    expect(routeSearchQuery('买机票').vertical).toEqual({ tag: 'travel.flight' })
    expect(routeSearchQuery('查询航班').vertical).toEqual({ tag: 'travel.flight' })
  })

  it('航班号正则不吞开发错误码', () => {
    const decision = routeSearchQuery('typescript error TS2345')
    expect(decision.intent).toBe('english-web')
    expect(decision.vertical).toBeUndefined()
  })

  it('中文无航班语境的单号不当航班号', () => {
    const decision = routeSearchQuery('订单号 CA1234')
    expect(decision.intent).toBe('chinese-web')
    expect(decision.vertical).toBeUndefined()
  })

  it('status 纳入航班语境词', () => {
    expect(routeSearchQuery('CA1234 status').vertical).toEqual({
      tag: 'travel.flight_status',
      params: { flight_number: 'CA1234' },
    })
  })

  it('方法/定义形态词拦下垂直取数', () => {
    for (const query of [
      '参考文献 格式', '论文 怎么写', '机票 怎么买便宜',
      '股价 是什么意思', '专利 怎么申请', '法规 是什么',
      '什么是GDP', '什么是CVE', '什么是 判例', 'arXiv 论文 下载',
    ]) {
      const decision = routeSearchQuery(query)
      expect(decision.intent).toBe('chinese-web')
      expect(decision.vertical).toBeUndefined()
    }
  })

  it('CVE 编号这类强数据模式可越过方法词守卫', () => {
    expect(routeSearchQuery('CVE-2026-1234 怎么查').vertical).toEqual({ tag: 'security.vuln' })
  })

  it('social_media 只在有把握时带 params.type', () => {
    expect(routeSearchQuery('微博 用户 讨论').vertical).toEqual({
      tag: 'social_media.social_media',
      params: { type: 'weibo' },
    })
    expect(routeSearchQuery('Twitter 上的讨论').vertical).toEqual({
      tag: 'social_media.social_media',
      params: { type: 'x_top' },
    })
    expect(routeSearchQuery('Reddit 上的讨论').vertical).toEqual({
      tag: 'social_media.social_media',
      params: { type: 'reddit_post' },
    })
    expect(routeSearchQuery('微信公众号 运营').vertical).toEqual({
      tag: 'social_media.social_media',
      params: { type: 'wechatmp' },
    })
  })

  it('补齐的八个垂直子域各有自然中文触发词', () => {
    const cases: readonly (readonly [string, string])[] = [
      ['全球 农业统计', 'agriculture.fao'],
      ['某公司 商务联系人', 'business.people'],
      ['中国 原油产量', 'energy.production'],
      ['电影 磁力链接', 'film.torrent'],
      ['英雄联盟 排位 战绩', 'gaming.esports'],
      ['全球 公共卫生统计', 'health.stats'],
      ['背景扫描 1.2.3.4', 'security.noise'],
      ['安全扫描 example.com', 'security.scan'],
    ]
    for (const [query, tag] of cases) {
      expect(routeSearchQuery(query).vertical).toEqual({ tag })
    }
  })

  it('「引文」与引用/参考文献同权重，命中文献引用', () => {
    expect(routeSearchQuery('这篇论文的 引文').vertical).toEqual({ tag: 'academic.citation' })
  })

  it('「背景噪声」命中 IP 扫描噪声', () => {
    expect(routeSearchQuery('这个IP 背景噪声').vertical).toEqual({ tag: 'security.noise' })
  })

  it('「联系人」命中商务联系人', () => {
    expect(routeSearchQuery('销售总监 联系人').vertical).toEqual({ tag: 'business.people' })
  })

  it('「联系方式」是普通名词，不触发商务联系人', () => {
    const decision = routeSearchQuery('联系方式')
    expect(decision.intent).toBe('chinese-web')
    expect(decision.vertical).toBeUndefined()
  })

  it('裸「微博热搜/热榜/热门/榜单」都走 weibo_hot 频道，不落通用热点榜', () => {
    for (const query of ['微博热搜', '微博热榜', '微博热门', '微博榜单']) {
      const decision = routeSearchQuery(query)
      expect(decision.intent, query).toBe('vertical-data')
      expect(decision.vertical, query).toEqual({
        tag: 'social_media.social_media',
        params: { type: 'weibo_hot' },
      })
    }
  })

  it('「种子」在下载/磁力/BT/电影语境下命中 BT 资源', () => {
    for (const query of ['4k 电影 种子', '种子 下载', 'bt 种子', '磁力 种子']) {
      expect(routeSearchQuery(query).vertical).toEqual({ tag: 'film.torrent' })
    }
  })

  it('农业/种植语义的「种子」不触发 BT 资源', () => {
    for (const query of ['水稻 种子 价格', '农业 种子', '种植 种子']) {
      const decision = routeSearchQuery(query)
      expect(decision.intent).toBe('chinese-web')
      expect(decision.vertical).toBeUndefined()
    }
  })

  it('general.general 等同通用搜索：不下发 vertical', () => {
    const decision = routeSearchQuery('通用搜索 红烧肉')
    expect(decision.intent).toBe('chinese-web')
    expect(decision.vertical).toBeUndefined()
  })
})

describe('意图命名与用户语言 note', () => {
  it('社区观点意图命名为 community-opinion，wantAnswer 语义不变', () => {
    const decision = routeSearchQuery('知乎 怎么看 这个方案')
    expect(decision.intent).toBe('community-opinion')
    expect(decision.wantAnswer).toBe(true)
  })

  it('全部意图名不含引擎品牌', () => {
    const intents: readonly SearchIntent[] = [
      'ai-news', 'community-opinion', 'hot-list', 'vertical-data', 'english-web', 'research', 'chinese-web',
    ]
    for (const intent of intents) {
      expect(intent).not.toMatch(/zhihu|anysearch|tavily|firecrawl|aihot/i)
    }
  })

  it('关键分支使用稳定 noteId（呈现映射在 output.test.ts 单点验证）', () => {
    expect(routeSearchQuery('热点').note).toEqual({ id: 'hot-list' })
    expect(routeSearchQuery('AI 热点').note).toEqual({ id: 'ai-news-hot' })
    expect(routeSearchQuery('AI 本周新闻').note).toEqual({ id: 'ai-news' })
    expect(routeSearchQuery('如何评价 新版 框架').note).toEqual({ id: 'community-opinion' })
    expect(routeSearchQuery('苹果 股价').note).toEqual({ id: 'vertical-data', params: { label: '金融行情' } })
    expect(routeSearchQuery('主流向量数据库 对比').note).toEqual({ id: 'research' })
    expect(routeSearchQuery('how to configure vite plugins').note).toEqual({ id: 'english-web' })
    expect(routeSearchQuery('typescript error TS2345').note).toEqual({ id: 'english-web-developer' })
    expect(routeSearchQuery('红烧肉 做法').note).toEqual({ id: 'chinese-web' })
  })

  it('noteId/params 不含引擎品牌（用户文案的术语检查在 output.test.ts）', () => {
    for (const query of [
      '热点', 'AI 热点', '如何评价 新版 框架', '苹果 股价',
      '主流向量数据库 对比', 'kubernetes', '红烧肉 做法',
    ]) {
      const note = JSON.stringify(routeSearchQuery(query).note)
      expect(note).not.toMatch(/anysearch|tavily|firecrawl|aihot|zhihu/i)
    }
  })
})

describe('跨意图边界：决策附加字段', () => {
  it('社区观点意图带 wantAnswer，普通意图不带', () => {
    expect(routeSearchQuery('如何评价 新版 框架').wantAnswer).toBe(true)
    expect(routeSearchQuery('红烧肉 做法').wantAnswer).toBeUndefined()
  })

  it('english-web 偏好细分：开发者词 → developer，否则 general-web', () => {
    expect(routeSearchQuery('typescript error TS2345').prefer).toBe('developer')
    expect(routeSearchQuery('how to configure vite plugins').prefer).toBe('general-web')
    expect(routeSearchQuery('site:github.com').prefer).toBe('developer')
    expect(routeSearchQuery('site:arxiv.org').prefer).toBe('general-web')
  })

  it('非英文意图不表态偏好', () => {
    expect(routeSearchQuery('红烧肉 做法').prefer).toBeUndefined()
  })
})

describe('hasCjk（编排层共用的语言判据）', () => {
  it('汉字/假名/韩文为真，纯拉丁与数字为假', () => {
    expect(hasCjk('红烧肉')).toBe(true)
    expect(hasCjk('ひらがな')).toBe(true)
    expect(hasCjk('한국어')).toBe(true)
    expect(hasCjk('CVE-2026-1234 vulnerability')).toBe(false)
    expect(hasCjk('12345')).toBe(false)
  })
})
