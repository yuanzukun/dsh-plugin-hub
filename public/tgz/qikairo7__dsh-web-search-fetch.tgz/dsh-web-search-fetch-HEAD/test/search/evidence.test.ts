import { describe, expect, it } from 'vitest'

import { buildSearchEvidence, shouldSettleEarly } from '../../src/search/evidence.js'
import type { FusedCandidate } from '../../src/search/fuse.js'
import { routeSearchQuery } from '../../src/search/router.js'

const NOW = Date.UTC(2026, 10, 10)

function candidate(url: string, title: string): FusedCandidate {
  return { url, title, score: 1, contributors: ['alpha'] }
}

describe('SearchEvidence', () => {
  it('单主题查询不把无关候选算进提前停止阈值', () => {
    const analysis = routeSearchQuery('气候变化')
    const evidence = buildSearchEvidence({
      analysis,
      candidates: [
        candidate('https://a.example/1', '烹饪食谱'),
        candidate('https://b.example/1', '交通新闻'),
        candidate('https://c.example/1', '足球比赛'),
      ],
      hasAnswer: false,
      sourceLanes: 3,
      now: NOW,
    })

    expect(evidence.topicMatchedCandidates).toBe(0)
    expect(shouldSettleEarly(evidence, 3)).toBe(false)
  })

  it('主题匹配候选达到请求宽度后才提前停止', () => {
    const analysis = routeSearchQuery('气候变化')
    const evidence = buildSearchEvidence({
      analysis,
      candidates: [
        candidate('https://a.example/1', '气候变化研究'),
        candidate('https://b.example/1', '气候变化影响'),
        candidate('https://c.example/1', '气候变化数据'),
      ],
      hasAnswer: false,
      sourceLanes: 3,
      now: NOW,
    })

    expect(evidence.topicMatchedCandidates).toBe(3)
    expect(shouldSettleEarly(evidence, 3)).toBe(true)
  })

  it('Top5 证据只统计前五条的相关、域名、日期与长摘要', () => {
    const analysis = routeSearchQuery('气候变化')
    const long = 'x'.repeat(201)
    const evidence = buildSearchEvidence({
      analysis,
      candidates: [
        { ...candidate('https://a.example/1', '气候变化研究'), publishedAt: '2026-11-01', summary: long },
        { ...candidate('https://b.example/1', '气候变化影响'), publishedAt: '2026-11-02', summary: long },
        candidate('https://c.example/1', '气候变化数据'),
        { ...candidate('https://d.example/1', '烹饪食谱'), publishedAt: '2026-11-03', summary: long },
        candidate('https://a.example/2', '气候变化观察'),
        { ...candidate('https://e.example/1', '气候变化研究'), publishedAt: '2026-11-04', summary: long },
      ],
      hasAnswer: false,
      sourceLanes: 1,
      now: NOW,
    })

    expect(evidence.topTopicMatchedCandidates).toBe(4)
    expect(evidence.topDistinctHosts).toBe(4)
    expect(evidence.topDatedCandidates).toBe(3)
    expect(evidence.topLongSummaries).toBe(3)
    expect(evidence.topicMatchedCandidates).toBe(5)
    expect(evidence.distinctHosts).toBe(5)
  })
})
