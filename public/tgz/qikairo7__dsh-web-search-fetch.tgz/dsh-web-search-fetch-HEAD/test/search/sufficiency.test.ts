import { describe, expect, it } from 'vitest'
import type { FusedCandidate } from '../../src/search/fuse.js'
import { parseQuerySyntax } from '../../src/search/query-syntax.js'
import { assessSearchSufficiency } from '../../src/search/sufficiency.js'

const NOW = Date.UTC(2026, 10, 10, 0, 0, 0)

function candidate(url: string, title: string, publishedAt?: string): FusedCandidate {
  return {
    url,
    score: 1,
    contributors: ['alpha'],
    title,
    ...(publishedAt === undefined ? {} : { publishedAt }),
  }
}

function assess(
  candidates: readonly FusedCandidate[],
  overrides: Partial<Parameters<typeof assessSearchSufficiency>[0]> = {},
): ReturnType<typeof assessSearchSufficiency> {
  return assessSearchSufficiency({
    query: '主流向量数据库 对比',
    intent: 'research',
    freshnessRequirement: 'normal',
    verificationRequirement: 'high',
    syntax: parseQuerySyntax('主流向量数据库 对比'),
    candidates,
    hasAnswer: false,
    now: NOW,
    ...overrides,
  })
}

describe('search sufficiency', () => {
  it('无候选且无答案时判定为空结果', () => {
    expect(assess([])).toEqual({ sufficient: false, reason: 'empty' })
  })

  it('调研意图要求至少两个域名；单域名触发补派', () => {
    const single = assess([
      candidate('https://a.example/1', '主流向量数据库 对比'),
    ])
    expect(single).toEqual({ sufficient: false, reason: 'research-coverage' })

    const covered = assess([
      candidate('https://a.example/1', '主流向量数据库 对比'),
      candidate('https://b.example/1', '主流向量数据库 评测'),
    ])
    expect(covered.sufficient).toBe(true)
  })

  it('AI 资讯要求近 7 天发布时间；无时间或过期结果触发补派', () => {
    const input = {
      query: 'OpenAI 最新新闻',
      intent: 'ai-news' as const,
      freshnessRequirement: 'high' as const,
      verificationRequirement: 'normal' as const,
      syntax: parseQuerySyntax('OpenAI 最新新闻'),
    }
    expect(assess([candidate('https://a.example/news', 'OpenAI 新闻')], input))
      .toEqual({ sufficient: false, reason: 'fresh-date' })
    expect(assess([candidate('https://a.example/news', 'OpenAI 新闻', '2026-11-09T00:00:00Z')], input).sufficient)
      .toBe(true)
  })

  it('显式 site 查询缺少对应官方域名时触发补派，命中时足够', () => {
    const input = {
      query: 'Node.js 文档 site:nodejs.org',
      intent: 'english-web' as const,
      verificationRequirement: 'normal' as const,
      syntax: parseQuerySyntax('Node.js 文档 site:nodejs.org'),
    }
    expect(assess([candidate('https://blog.example/node', 'Node.js 文档')], input))
      .toEqual({ sufficient: false, reason: 'official-source' })
    expect(assess([candidate('https://nodejs.org/docs', 'Node.js 文档')], input).sufficient).toBe(true)
  })

  it('-site 排除域名不当作官方域要求', () => {
    const input = {
      query: 'OpenAI 新闻 -site:medium.com',
      intent: 'chinese-web' as const,
      verificationRequirement: 'normal' as const,
      syntax: parseQuerySyntax('OpenAI 新闻 -site:medium.com'),
    }
    expect(assess([candidate('https://news.example/openai', 'OpenAI 新闻')], input).sufficient).toBe(true)
  })

  it('显式 site 命中官方域仍要满足 AI 资讯时效', () => {
    const input = {
      query: 'OpenAI 最新新闻 site:openai.com',
      intent: 'ai-news' as const,
      freshnessRequirement: 'high' as const,
      verificationRequirement: 'normal' as const,
      syntax: parseQuerySyntax('OpenAI 最新新闻 site:openai.com'),
    }
    expect(assess([candidate('https://openai.com/news', 'OpenAI 新闻', '2025-01-01T00:00:00Z')], input))
      .toEqual({ sufficient: false, reason: 'fresh-date' })
  })

  it('content-only 结构化答案即使没有 URL 候选也足够', () => {
    expect(assess([], {
      query: '苹果 股价',
      intent: 'vertical-data' as const,
      verificationRequirement: 'normal' as const,
      syntax: parseQuerySyntax('苹果 股价'),
      hasAnswer: true,
    }).sufficient).toBe(true)
  })
})
