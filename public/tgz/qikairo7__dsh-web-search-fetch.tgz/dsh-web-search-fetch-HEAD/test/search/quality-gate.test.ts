import { describe, expect, it } from 'vitest'

import { buildSearchEvidence } from '../../src/search/evidence.js'
import type { FusedCandidate } from '../../src/search/fuse.js'
import { assessSearchQuality } from '../../src/search/quality-gate.js'
import { routeSearchQuery } from '../../src/search/router.js'

const NOW = Date.UTC(2026, 10, 12)

function candidate(index: number, title: string): FusedCandidate {
  return {
    url: `https://s${index + 1}.example/article`,
    score: 1,
    contributors: ['alpha'],
    title,
    summary: 'x'.repeat(201),
    publishedAt: `2026-11-${String(index + 1).padStart(2, '0')}T00:00:00Z`,
  }
}

function evidence(query: string, candidates: readonly FusedCandidate[]) {
  const analysis = routeSearchQuery(query)
  return {
    analysis,
    evidence: buildSearchEvidence({
      analysis,
      candidates,
      hasAnswer: false,
      sourceLanes: 1,
      now: NOW,
    }),
  }
}

describe('DeepSeek-like 质量门适用范围', () => {
  for (const query of [
    '红烧肉',
    'typescript async error',
    '向量数据库 对比',
    'Windows 蓝屏 错误',
    '家里漏水 解决办法',
  ]) {
    it(`对「${query}」应用普通网页门槛`, () => {
      const candidates = Array.from({ length: 5 }, (_, index) => candidate(index, `${query} 结果`))
      const input = evidence(query, candidates)

      expect(assessSearchQuality(input.analysis, input.evidence)).toEqual({
        applicable: true,
        sufficient: true,
        gaps: [],
      })
    })
  }

  it('AI 资讯与普通生活查询不要求官方域', () => {
    for (const query of ['OpenAI 发布', '红烧肉']) {
      const candidates = Array.from({ length: 5 }, (_, index) => candidate(index, query))
      const input = evidence(query, candidates)

      expect(assessSearchQuality(input.analysis, input.evidence).sufficient).toBe(true)
    }
  })

  it('显式站点约束不要求三个域名', () => {
    const query = '红烧肉 site:example.com'
    const candidates = Array.from({ length: 5 }, (_, index) => ({
      ...candidate(index, '红烧肉 结果'),
      url: `https://example.com/${index + 1}`,
    }))
    const input = evidence(query, candidates)

    expect(assessSearchQuality(input.analysis, input.evidence)).toEqual({
      applicable: true,
      sufficient: true,
      gaps: [],
    })
  })

  it('政策查询要求官方域，命中政府子域才足够', () => {
    const query = '个人所得税 政策解读'
    const candidates = Array.from({ length: 5 }, (_, index) => candidate(index, `${query} 结果`))
    const missing = evidence(query, candidates)
    expect(assessSearchQuality(missing.analysis, missing.evidence)).toMatchObject({
      applicable: true,
      sufficient: false,
      gaps: ['official'],
    })

    const official = evidence(query, candidates.map((item, index) => index === 0
      ? { ...item, url: 'https://www.beijing.gov.cn/zhengce/gerensuodeshui' }
      : item))
    expect(assessSearchQuality(official.analysis, official.evidence).sufficient).toBe(true)
  })

  it('知乎社区不因域名集中判多样性不足', () => {
    const candidates = Array.from({ length: 5 }, (_, index) => ({
      ...candidate(index, '红烧肉 怎么看'),
      url: `https://www.zhihu.com/question/${index + 1}`,
    }))
    const input = evidence('红烧肉 怎么看', candidates)

    expect(input.evidence.topDistinctHosts).toBe(1)
    expect(assessSearchQuality(input.analysis, input.evidence).sufficient).toBe(true)
  })

  it('知乎社区四条加一条外站仍按集中处理', () => {
    const candidates = Array.from({ length: 5 }, (_, index) => ({
      ...candidate(index, '红烧肉 怎么看'),
      url: index < 4 ? `https://www.zhihu.com/question/${index + 1}` : 'https://example.com/answer',
    }))
    const input = evidence('红烧肉 怎么看', candidates)

    expect(assessSearchQuality(input.analysis, input.evidence).sufficient).toBe(true)
  })

  it('非知乎社区的单域结果仍按多样性失败', () => {
    const candidates = Array.from({ length: 5 }, (_, index) => ({
      ...candidate(index, '红烧肉 怎么看'),
      url: `https://stackoverflow.com/questions/${index + 1}`,
    }))
    const input = evidence('红烧肉 怎么看', candidates)

    expect(assessSearchQuality(input.analysis, input.evidence)).toMatchObject({
      applicable: true,
      sufficient: false,
      gaps: ['diversity'],
    })
  })

  it('垂直结构化数据不参与普通网页质量门', () => {
    const candidates = Array.from({ length: 5 }, (_, index) => ({
      ...candidate(index, '苹果 股价'),
      url: `https://quote.example/${index}`,
      summary: undefined,
      publishedAt: undefined,
    }))
    const input = evidence('苹果 股价', candidates)

    expect(assessSearchQuality(input.analysis, input.evidence)).toEqual({
      applicable: false,
      sufficient: true,
      gaps: [],
    })
  })
})
