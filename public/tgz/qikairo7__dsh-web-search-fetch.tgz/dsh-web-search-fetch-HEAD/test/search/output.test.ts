// 搜索输出阶段的 NOTE_TEXT 呈现映射测试（唯一文案锚点）。
// 行为测试（aggregate/router/cache）只断言 note id/params；中文句子只在本文件逐条钉死，
// 改文案只需要改 output.ts 的 NOTE_TEXT 与本文件。
import { describe, expect, it } from 'vitest'
import { NOTE_TEXT, renderNote, type Note } from '../../src/search/output.js'

const CASES: ReadonlyArray<{ readonly note: Note; readonly text: string }> = [
  { note: { id: 'hot-list' }, text: '为你获取当下的热点榜单。' },
  { note: { id: 'ai-news-hot' }, text: '为你获取 AI 领域的热点榜单。' },
  { note: { id: 'ai-news' }, text: '为你检索 AI 领域的最新动态。' },
  { note: { id: 'community-opinion' }, text: '这个问题适合查知乎社区的观点与经验。' },
  { note: { id: 'vertical-data', params: { label: '金融行情' } }, text: '识别为金融行情查询，为你直接获取对应数据。' },
  { note: { id: 'research' }, text: '需要综合多方资料，为你做多来源检索。' },
  { note: { id: 'english-web' }, text: '按英文网页检索。' },
  { note: { id: 'english-web-developer' }, text: '按英文网页检索，优先开发者文档与代码资料。' },
  { note: { id: 'chinese-web' }, text: '按中文网页检索。' },
  { note: { id: 'cache-hit', params: { ageSeconds: 5 } }, text: '（缓存命中，age 5 秒）' },
  { note: { id: 'vertical-unavailable' }, text: '垂直频道不可用，改用通用搜索。' },
  { note: { id: 'vertical-missing-params', params: { missing: ['type', 'value'] } }, text: '垂直频道需参数 type、value，改用通用搜索。' },
  { note: { id: 'early-cancel' }, text: '已有多路相关结果，宽限等待结束后提前取消未完成渠道；可能仍有未返回内容。' },
  { note: { id: 'rerank-applied' }, text: '结果经 SiliconFlow 重排服务排序。' },
  { note: { id: 'keyless-fallback' }, text: '额度耗尽，改用匿名额度。' },
  { note: { id: 'vertical-degrade', params: { language: 'chinese' } }, text: '垂直数据路由无可用结果，降级为通用中文搜索重试一次。' },
  { note: { id: 'hot-degrade', params: { language: 'english' } }, text: '热点榜单路由无可用结果，降级为通用英文搜索重试一次。' },
  { note: { id: 'degrade-early-cancel' }, text: '降级的多路已取得相关结果，宽限等待结束后提前取消未完成渠道；可能仍有未返回内容。' },
  { note: { id: 'escalate-early-cancel' }, text: '补派的多路已取得相关结果，宽限等待结束后提前取消未完成渠道；可能仍有未返回内容。' },
  { note: { id: 'route-primary', params: { candidate: 'alpha', available: 1 } }, text: '路由 route-primary：alpha。' },
  { note: { id: 'route-primary', params: { candidate: 'alpha', available: 3 } }, text: '路由 route-primary：alpha（可用候选 3 路，首轮派发 1 路）。' },
  { note: { id: 'route-primary', params: { candidate: 'zhihu', available: 1 } }, text: '路由 route-primary：zhihu。' },
  { note: { id: 'route-skip', params: { candidate: 'beta', cause: 'breaker-open' } }, text: '路由 route-skip：beta（熔断中）。' },
  { note: { id: 'repair-evidence', params: { candidate: 'alpha', gap: 'research-coverage', mode: 'supplement' } }, text: '补派 repair-evidence：alpha（调研覆盖不足，补查）。' },
  { note: { id: 'repair-evidence', params: { candidate: 'alpha', gap: 'empty', mode: 'fallback' } }, text: '补派 repair-evidence：alpha（降级候选）。' },
  { note: { id: 'stop-quality' }, text: '停止 stop-quality：当前结果已足够。' },
  { note: { id: 'stop-budget' }, text: '停止 stop-budget：请求预算已用尽。' },
  { note: { id: 'stop-deadline' }, text: '停止 stop-deadline：操作总限时已到。' },
  { note: { id: 'stop-exhausted' }, text: '停止 stop-exhausted：补派上限已到或没有可用通道。' },
  { note: { id: 'quota-estimated', params: { engines: ['alpha', 'beta'] } }, text: 'alpha、beta 无额度端点，本地计数为估算。' },
  { note: { id: 'date-filtered', params: { omitted: 2 } }, text: '因显式日期窗口省略 2 条已知窗口外结果。' },
  { note: { id: 'domain-limit', params: { omitted: 2 } }, text: '因单域上限省略 2 条。' },
  { note: { id: 'output-budget', params: { omitted: 3 } }, text: '因输出预算省略 3 条来源。' },
  {
    note: { id: 'attribution', params: { entries: [{ engine: 'alpha', count: 2, elapsedMs: 5 }, { engine: 'beta', count: 1 }] } },
    text: '来源：alpha×2(5ms)、beta×1。',
  },
]

describe('NOTE_TEXT 呈现映射', () => {
  it('用例覆盖全部 note id（新增 id 必须补文案用例）', () => {
    const covered = new Set(CASES.map(item => item.note.id))
    expect([...covered].sort()).toEqual(Object.keys(NOTE_TEXT).sort())
  })

  for (const { note, text } of CASES) {
    it(`${note.id} 渲染为固定文案`, () => {
      expect(renderNote(note)).toBe(text)
    })
  }

  it('非来源 note 文案不含引擎 id 与内部术语', () => {
    const sourceNotes = new Set(['route-primary', 'route-skip', 'repair-evidence', 'attribution'])
    for (const { note, text } of CASES) {
      if (sourceNotes.has(note.id)) continue
      expect(text).not.toMatch(/anysearch|tavily|firecrawl|aihot|zhihu|intent|vertical|裸|意图|取数/i)
    }
  })
})
