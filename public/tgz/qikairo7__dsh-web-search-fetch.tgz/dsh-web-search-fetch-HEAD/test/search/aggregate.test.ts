// v0.4 编排器集成离线单测：注入假引擎、假意图映射与假目录，不触网。
// 覆盖 ADR-0001 接线十条：意图说明、日检前置、三段式选源、垂直校验、宽度归一、
// 有界降级、content 合并、归因、域名多样性、输出预算。
import { describe, expect, it } from 'vitest'
import type {
  Engine,
  EngineContext,
  EngineManifest,
  EngineResult,
  EngineSearchOutcome,
  EngineSearchRequest,
  EngineSearchSource,
  QuotaReport,
} from '../../src/engines/contract.js'
import { engineFailure, type EngineFailure } from '../../src/engines/failure.js'
import { createAnysearchEngine } from '../../src/engines/anysearch.js'
import {
  AggregatedSearchProvider,
  type LaneOutcomeKind,
  type RerankOptions,
  type VerticalCatalog,
} from '../../src/search/aggregate.js'
import { renderNote } from '../../src/search/output.js'
import type { SearchIntent } from '../../src/search/router.js'
import { CircuitBreaker } from '../../src/support/breaker.js'
import { runOperation, SharedRequestBudget, type RuntimeControls } from '../../src/support/budget.js'

// ---- 假引擎 ----

interface FakeOptions {
  readonly id: string
  readonly sources?: readonly EngineSearchSource[]
  readonly content?: string
  readonly truncated?: boolean
  readonly failure?: EngineFailure
  readonly hotSources?: readonly EngineSearchSource[]
  readonly hotFailure?: EngineFailure
  readonly quota?: QuotaReport | Error | (() => Promise<QuotaReport>)
  readonly auth?: EngineManifest['auth']
  readonly upstreamGroup?: string
  readonly search?: (
    request: EngineSearchRequest,
    ctx: EngineContext,
  ) => EngineResult<EngineSearchOutcome> | Promise<EngineResult<EngineSearchOutcome>>
}

interface FakeEngine extends Engine {
  readonly calls: EngineSearchRequest[]
  readonly hotCalls: number
}

function source(url: string, title?: string, snippet?: string): EngineSearchSource {
  return {
    url,
    ...(title === undefined ? {} : { title }),
    ...(snippet === undefined ? {} : { snippet }),
  }
}

function fakeEngine(options: FakeOptions): FakeEngine {
  const calls: EngineSearchRequest[] = []
  let hotCalls = 0
  const hotSources = options.hotSources
  const hotFailure = options.hotFailure
  const quotaOption = options.quota
  const manifest: EngineManifest = {
    id: options.id,
    label: options.id,
    capabilities: ['search'],
    auth: options.auth ?? 'anonymous',
    free: true,
    keyless: true,
    enabledByDefault: true,
    ...(options.upstreamGroup === undefined ? {} : { upstreamGroup: options.upstreamGroup }),
    endpoints: { search: `https://${options.id}.invalid/search` },
  }
  const outcome = (): EngineSearchOutcome => ({
    sources: options.sources ?? [],
    truncated: options.truncated ?? false,
    ...(options.content === undefined ? {} : { content: options.content }),
  })
  return {
    manifest,
    calls,
    get hotCalls() { return hotCalls },
    async search(request, ctx) {
      calls.push(request)
      if (options.search !== undefined) return await options.search(request, ctx)
      if (options.failure !== undefined) return { ok: false, failure: options.failure }
      return { ok: true, outcome: outcome() }
    },
    ...(hotSources === undefined && hotFailure === undefined ? {} : {
      async hotTopics(): Promise<EngineResult<EngineSearchOutcome>> {
        hotCalls += 1
        if (hotFailure !== undefined) return { ok: false, failure: hotFailure }
        return { ok: true, outcome: { sources: hotSources ?? [], truncated: false } }
      },
    }),
    ...(quotaOption === undefined ? {} : {
      async quota(): Promise<QuotaReport> {
        if (quotaOption instanceof Error) throw quotaOption
        if (typeof quotaOption === 'function') return await quotaOption()
        return quotaOption
      },
    }),
  }
}

function quotaReport(engineId: string, remaining: number, available = true): QuotaReport {
  return { engineId, available, remaining }
}

// ---- 测试装配 ----

interface HarnessOptions {
  readonly controls?: RuntimeControls
  readonly intentEngines?: (intent: SearchIntent, prefer?: 'general-web' | 'developer') => readonly string[]
  readonly verticalCatalog?: VerticalCatalog
  readonly onLaneOutcome?: (engineId: string, kind: LaneOutcomeKind) => void
  readonly quotaCheck?: boolean
  readonly onQuotaReport?: (engineId: string, report: QuotaReport) => void
  readonly apiKey?: string
  readonly rerank?: RerankOptions
  readonly now?: number
  readonly ready?: (id: string, face: 'search' | 'fetch') => Promise<boolean>
}

const FIXED_NOW = Date.UTC(2026, 10, 7, 4, 0, 0)

function harness(engines: readonly Engine[], options: HarnessOptions = {}): AggregatedSearchProvider {
  const breaker = new CircuitBreaker({ now: () => options.now ?? FIXED_NOW })
  const controls: RuntimeControls = {
    preset: 'auto',
    maxSearchServices: 5,
    maxRequests: 32,
    ...options.controls,
  }
  return new AggregatedSearchProvider({
    resolveControls: () => controls,
    engines,
    breaker,
    buildContext: async (manifest, op, lane) => ({
      signal: lane.signal,
      deadline: lane.deadline,
      ...(options.apiKey === undefined ? {} : { apiKey: options.apiKey }),
      endpoint: manifest.endpoints.search ?? 'https://fake.invalid/search',
      countRequest: () => op.countRequest(),
    }),
    ...(options.rerank === undefined ? {} : { rerank: options.rerank }),
    ...(options.intentEngines === undefined ? {} : { intentEngines: options.intentEngines }),
    ...(options.verticalCatalog === undefined ? {} : { verticalCatalog: options.verticalCatalog }),
    ...(options.onLaneOutcome === undefined ? {} : { onLaneOutcome: options.onLaneOutcome }),
    ...(options.onQuotaReport === undefined ? {} : { onQuotaReport: options.onQuotaReport }),
    ...(options.quotaCheck === undefined ? {} : { quotaCheck: options.quotaCheck }),
    ...(options.now === undefined ? {} : { now: () => options.now! }),
    ...(options.ready === undefined ? {} : { ready: options.ready }),
  })
}

// ---- 1. 意图说明先行 ----

describe('搜索入口：意图说明先行', () => {
  it('中文查询先记路由说明', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '红烧肉')] })
    const result = await harness([alpha]).search({ query: '红烧肉' })
    expect(result.content).toBeDefined()
    expect(result.content!.startsWith(`搜索处理说明：${renderNote({ id: 'chinese-web' })}`)).toBe(true)
  })

  it('英文查询同样先记路由说明', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', 'weather tomorrow')] })
    const result = await harness([alpha]).search({ query: 'weather tomorrow' })
    expect(result.content).toBeDefined()
    expect(result.content!.startsWith(`搜索处理说明：${renderNote({ id: 'english-web' })}`)).toBe(true)
  })
})

// ---- 2. 额度日检前置 ----

describe('额度日检前置', () => {
  it('remaining=0 的引擎在选择前熔断，本轮不派发', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [source('https://a.example/1', 'kubernetes')],
      quota: quotaReport('alpha', 0),
    })
    const beta = fakeEngine({
      id: 'beta',
      sources: [source('https://b.example/1', 'kubernetes')],
      quota: quotaReport('beta', 10),
    })
    const result = await harness([alpha, beta], { controls: { preset: 'multi' } }).search({ query: 'kubernetes' })
    expect(alpha.calls).toHaveLength(0)
    expect(beta.calls).toHaveLength(1)
    expect(result.sources.map(item => item.url)).toEqual(['https://b.example/1'])
  })

  it('remaining>0 不阻塞派发', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [source('https://a.example/1', 'kubernetes')],
      quota: quotaReport('alpha', 10),
    })
    const beta = fakeEngine({
      id: 'beta',
      sources: [source('https://b.example/1', 'kubernetes')],
      quota: quotaReport('beta', 10),
    })
    await harness([alpha, beta], { controls: { preset: 'multi' } }).search({ query: 'kubernetes' })
    expect(alpha.calls).toHaveLength(1)
    expect(beta.calls).toHaveLength(1)
  })

  it('额度查询抛错 fail-open：本轮照常派发', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [source('https://a.example/1', 'kubernetes')],
      quota: new Error('quota endpoint down'),
    })
    const result = await harness([alpha]).search({ query: 'kubernetes' })
    expect(alpha.calls).toHaveLength(1)
    expect(result.sources).toHaveLength(1)
  })

  it('available=false 视为额度未知，不写熔断', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [source('https://a.example/1', 'kubernetes')],
      quota: quotaReport('alpha', 0, false),
    })
    await harness([alpha]).search({ query: 'kubernetes' })
    expect(alpha.calls).toHaveLength(1)
  })
})

// ---- 2b. 额度日检上报（官方快照仓入口） ----

describe('额度日检上报钩子', () => {
  it('正常 resolve 的每次探测都上报，available:false 原样保留', async () => {
    const reports: Array<[string, QuotaReport]> = []
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [source('https://a.example/1', 'kubernetes')],
      quota: quotaReport('alpha', 10),
    })
    const beta = fakeEngine({
      id: 'beta',
      sources: [source('https://b.example/1', 'kubernetes')],
      quota: { engineId: 'beta', available: false, raw: 'keyless 模式无额度端点' },
    })
    await harness([alpha, beta], {
      controls: { preset: 'multi' },
      onQuotaReport: (engineId, report) => reports.push([engineId, report]),
    }).search({ query: 'kubernetes' })
    expect(reports).toEqual([
      ['alpha', { engineId: 'alpha', available: true, remaining: 10 }],
      ['beta', { engineId: 'beta', available: false, raw: 'keyless 模式无额度端点' }],
    ])
  })

  it('探测抛错不上报，其他引擎照常上报', async () => {
    const reports: Array<[string, QuotaReport]> = []
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [source('https://a.example/1', 'kubernetes')],
      quota: new Error('quota endpoint down'),
    })
    const beta = fakeEngine({
      id: 'beta',
      sources: [source('https://b.example/1', 'kubernetes')],
      quota: quotaReport('beta', 10),
    })
    await harness([alpha, beta], {
      controls: { preset: 'multi' },
      onQuotaReport: (engineId, report) => reports.push([engineId, report]),
    }).search({ query: 'kubernetes' })
    expect(reports).toEqual([['beta', { engineId: 'beta', available: true, remaining: 10 }]])
  })

  it('日检每引擎每天只探测/上报一次', async () => {
    const reports: Array<[string, QuotaReport]> = []
    const probes: string[] = []
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [source('https://a.example/1', 'kubernetes')],
      quota: async () => { probes.push('alpha'); return quotaReport('alpha', 10) },
    })
    const provider = harness([alpha], {
      controls: { preset: 'single' },
      onQuotaReport: (engineId, report) => reports.push([engineId, report]),
    })
    await provider.search({ query: 'kubernetes' })
    await provider.search({ query: 'redis' })
    expect(probes).toHaveLength(1)
    expect(reports).toHaveLength(1)
  })
})

// ---- 3. 三段式：意图排序、宽度、热点榜 ----

describe('三段式：意图排序与宽度', () => {
  it('意图映射内的引擎排前，映射外的按 registry 序排后', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '红烧肉')] })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', '红烧肉')] })
    const gamma = fakeEngine({ id: 'gamma', sources: [source('https://c.example/1', '红烧肉')] })
    const result = await harness([alpha, beta, gamma], {
      controls: { preset: 'multi' },
      intentEngines: intent => intent === 'chinese-web' ? ['gamma'] : [],
    }).search({ query: '红烧肉' })
    expect(result.sources.map(item => item.url)).toEqual([
      'https://c.example/1',
      'https://a.example/1',
      'https://b.example/1',
    ])
  })

  it('auto 宽度：chinese-web 单路，且取意图映射首位', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '红烧肉')] })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', '红烧肉')] })
    const result = await harness([alpha, beta], {
      intentEngines: intent => intent === 'chinese-web' ? ['beta', 'alpha'] : [],
    }).search({ query: '红烧肉' })
    expect(alpha.calls).toHaveLength(0)
    expect(beta.calls).toHaveLength(1)
    expect(result.sources.map(item => item.url)).toEqual(['https://b.example/1'])
  })

  it('默认配置：意图顺序穿透 searchServices 默认清单（不再被重排）', async () => {
    const order: string[] = []
    const tracked = (id: string): FakeEngine => fakeEngine({
      id,
      search: () => {
        order.push(id)
        return { ok: true, outcome: { sources: [source(`https://${id}.example/1`, '红烧肉')], truncated: false } }
      },
    })
    await harness([tracked('alpha'), tracked('beta'), tracked('gamma')], {
      controls: { preset: 'multi', searchServices: ['alpha', 'beta', 'gamma'] },
      intentEngines: intent => intent === 'chinese-web' ? ['gamma', 'beta'] : [],
    }).search({ query: '红烧肉' })
    expect(order).toEqual(['gamma', 'beta', 'alpha'])
  })

  it('无意图映射：用户自定义 searchServices 顺序仍生效', async () => {
    const order: string[] = []
    const tracked = (id: string): FakeEngine => fakeEngine({
      id,
      search: () => {
        order.push(id)
        return { ok: true, outcome: { sources: [source(`https://${id}.example/1`, '红烧肉')], truncated: false } }
      },
    })
    await harness([tracked('alpha'), tracked('beta'), tracked('gamma')], {
      controls: { preset: 'multi', searchServices: ['gamma', 'beta', 'alpha'] },
    }).search({ query: '红烧肉' })
    expect(order).toEqual(['gamma', 'beta', 'alpha'])
  })

  it('auto research：首轮单路，覆盖不足时补派一路', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '红烧肉 对比 评测')] })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', '红烧肉 对比 评测')] })
    const result = await harness([alpha, beta], {
      intentEngines: intent => intent === 'research' ? ['beta', 'alpha'] : [],
    }).search({ query: '红烧肉 对比' })
    expect(beta.calls).toHaveLength(1)
    expect(alpha.calls).toHaveLength(1)
    expect(result.content).toContain('调研覆盖不足')
    expect(result.sources).toHaveLength(2)
  })

  it('auto ai-news：首轮单路，缺少新鲜日期时补派一路', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', 'OpenAI 发布 新模型')] })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', 'OpenAI 发布 新模型')] })
    await harness([alpha, beta], {
      intentEngines: intent => intent === 'ai-news' ? ['beta', 'alpha'] : [],
    }).search({ query: 'OpenAI 发布' })
    expect(beta.calls).toHaveLength(1)
    expect(alpha.calls).toHaveLength(1)
  })

  it('auto research：首轮已有两个域名时不补派', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [] })
    const beta = fakeEngine({
      id: 'beta',
      sources: [
        source('https://b.example/1', '红烧肉 对比 评测'),
        source('https://c.example/1', '红烧肉 对比'),
      ],
    })
    await harness([alpha, beta], {
      intentEngines: intent => intent === 'research' ? ['beta', 'alpha'] : [],
    }).search({ query: '红烧肉 对比' })
    expect(beta.calls).toHaveLength(1)
    expect(alpha.calls).toHaveLength(0)
  })

  it('auto ai-news：首轮已有近 7 天结果时不补派', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [] })
    const beta = fakeEngine({
      id: 'beta',
      sources: [{
        url: 'https://b.example/1',
        title: 'OpenAI 发布 新模型',
        publishedAt: '2026-11-09T00:00:00.000Z',
      }],
    })
    await harness([alpha, beta], {
      intentEngines: intent => intent === 'ai-news' ? ['beta', 'alpha'] : [],
    }).search({ query: 'OpenAI 发布' })
    expect(beta.calls).toHaveLength(1)
    expect(alpha.calls).toHaveLength(0)
  })

  it('auto 普通查询：首轮全被相关性过滤后只补派一路', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '天气')] })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', '红烧肉 做法')] })
    await harness([alpha, beta], {
      intentEngines: intent => intent === 'chinese-web' ? ['alpha', 'beta'] : [],
    }).search({ query: '红烧肉 做法' })
    expect(alpha.calls).toHaveLength(1)
    expect(beta.calls).toHaveLength(1)
  })

  it('auto 首轮 8 秒限时，为补派保留默认 10 秒单路限时', async () => {
    const deadlines: number[] = []
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [],
      search: (_request, ctx) => {
        deadlines.push(ctx.deadline - FIXED_NOW)
        return { ok: true, outcome: { sources: [], truncated: false } }
      },
    })
    const beta = fakeEngine({
      id: 'beta',
      sources: [source('https://b.example/1', '红烧肉 做法')],
      search: (_request, ctx) => {
        deadlines.push(ctx.deadline - FIXED_NOW)
        return { ok: true, outcome: { sources: [source('https://b.example/1', '红烧肉 做法')], truncated: false } }
      },
    })
    await harness([alpha, beta], {
      now: FIXED_NOW,
      intentEngines: intent => intent === 'chinese-web' ? ['alpha', 'beta'] : [],
    }).search({ query: '红烧肉 做法' })
    expect(deadlines).toEqual([8_000, 10_000])
  })

  it('hot-list 且映射首位有 hotTopics：走榜单，不走普通搜索', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '热点')] })
    const beta = fakeEngine({ id: 'beta', hotSources: [source('https://hot.example/1', '热点榜')] })
    const result = await harness([alpha, beta], {
      intentEngines: intent => intent === 'hot-list' ? ['beta'] : [],
    }).search({ query: '热点' })
    expect(beta.hotCalls).toBe(1)
    expect(beta.calls).toHaveLength(0)
    expect(alpha.calls).toHaveLength(0)
    expect(result.sources.map(item => item.url)).toEqual(['https://hot.example/1'])
  })

  it('hot-list 但映射首位无 hotTopics：回落普通搜索', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '热点')] })
    const result = await harness([alpha], {
      intentEngines: intent => intent === 'hot-list' ? ['alpha'] : [],
    }).search({ query: '热点' })
    expect(alpha.hotCalls).toBe(0)
    expect(alpha.calls).toHaveLength(1)
    expect(result.sources).toHaveLength(1)
  })

  it('AI 热点（ai-news + useHotTopics）同样走榜单', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '热点')] })
    const beta = fakeEngine({ id: 'beta', hotSources: [source('https://hot.example/1', 'AI 热点榜')] })
    const result = await harness([alpha, beta], {
      intentEngines: intent => intent === 'ai-news' ? ['beta'] : [],
    }).search({ query: 'AI 热点' })
    expect(beta.hotCalls).toBe(1)
    expect(beta.calls).toHaveLength(0)
    expect(alpha.calls).toHaveLength(0)
    expect(result.sources.map(item => item.url)).toEqual(['https://hot.example/1'])
  })
})

// ---- 4. 垂直频道校验 ----

describe('垂直频道校验', () => {
  const vertical = { tag: 'finance.quote', params: { type: 'stock' } }

  it('目录拒绝：记说明、按 chinese-web 路由走，且不带 vertical', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '苹果 股价 行情')] })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', '苹果 股价 行情')] })
    const result = await harness([alpha, beta], {
      intentEngines: intent => intent === 'vertical-data' ? ['alpha'] : intent === 'chinese-web' ? ['beta'] : [],
      verticalCatalog: { validate: async () => ({ exists: false, missingRequired: [] }) },
    }).search({ query: '苹果 股价' })
    expect(alpha.calls).toHaveLength(0)
    expect(beta.calls).toHaveLength(1)
    expect(beta.calls[0]!.vertical).toBeUndefined()
    expect(result.content).toContain(renderNote({ id: 'vertical-unavailable' }))
  })

  it('目录通过：请求带 vertical', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '苹果 股价 行情')] })
    await harness([alpha], {
      intentEngines: intent => intent === 'vertical-data' ? ['alpha'] : [],
      verticalCatalog: { validate: async () => ({ exists: true, missingRequired: [] }) },
    }).search({ query: '苹果 股价' })
    expect(alpha.calls[0]!.vertical).toEqual(vertical)
  })

  it('未注入目录：按路由器垂直请求派发', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '苹果 股价 行情')] })
    await harness([alpha], {
      intentEngines: intent => intent === 'vertical-data' ? ['alpha'] : [],
    }).search({ query: '苹果 股价' })
    expect(alpha.calls[0]!.vertical).toEqual(vertical)
  })

  it('目录抛错：fail-open 回通用路由', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '苹果 股价 行情')] })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', '苹果 股价 行情')] })
    const result = await harness([alpha, beta], {
      intentEngines: intent => intent === 'vertical-data' ? ['alpha'] : intent === 'chinese-web' ? ['beta'] : [],
      verticalCatalog: { validate: async () => { throw new Error('catalog down') } },
    }).search({ query: '苹果 股价' })
    expect(alpha.calls).toHaveLength(0)
    expect(beta.calls).toHaveLength(1)
    expect(result.content).toContain(renderNote({ id: 'vertical-unavailable' }))
  })

  it('社区观点意图把 wantAnswer 带到请求', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '红烧肉 怎么看')] })
    await harness([alpha], {
      intentEngines: intent => intent === 'community-opinion' ? ['alpha'] : [],
    }).search({ query: '怎么看 红烧肉' })
    expect(alpha.calls[0]!.wantAnswer).toBe(true)
  })

  it('普通意图不下发 wantAnswer', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '红烧肉')] })
    await harness([alpha]).search({ query: '红烧肉' })
    expect(alpha.calls[0]!.wantAnswer).toBeUndefined()
  })
})

// ---- 5. 有界降级 ----

describe('有界降级', () => {
  it('垂直路由失败（非限流/额度/超时）：按 CJK 降级为通用中文搜索一次', async () => {
    const alpha = fakeEngine({ id: 'alpha', failure: engineFailure('provider-error') })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', '苹果 股价 行情')] })
    const result = await harness([alpha, beta], {
      intentEngines: intent => intent === 'vertical-data' ? ['alpha'] : intent === 'chinese-web' ? ['beta'] : [],
    }).search({ query: '苹果 股价' })
    expect(alpha.calls).toHaveLength(1)
    expect(beta.calls).toHaveLength(1)
    expect(beta.calls[0]!.vertical).toBeUndefined()
    expect(result.content).toContain(renderNote({ id: 'vertical-degrade', params: { language: 'chinese' } }))
    expect(result.sources.map(item => item.url)).toEqual(['https://b.example/1'])
  })

  it('垂直路由成功但结果为空：同样降级一次', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [] })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', '苹果 股价 行情')] })
    const result = await harness([alpha, beta], {
      intentEngines: intent => intent === 'vertical-data' ? ['alpha'] : intent === 'chinese-web' ? ['beta'] : [],
    }).search({ query: '苹果 股价' })
    expect(alpha.calls).toHaveLength(1)
    expect(beta.calls).toHaveLength(1)
    expect(result.sources.map(item => item.url)).toEqual(['https://b.example/1'])
  })

  it('垂直路由有候选但全被相关性过滤：同样降级一次', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '完全无关')] })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', 'AAPL stock price')] })
    const result = await harness([alpha, beta], {
      intentEngines: intent => intent === 'vertical-data' ? ['alpha'] : intent === 'english-web' ? ['beta'] : [],
    }).search({ query: 'AAPL stock price' })
    expect(alpha.calls).toHaveLength(1)
    expect(beta.calls).toHaveLength(1)
    expect(result.sources.map(item => item.url)).toEqual(['https://b.example/1'])
  })

  it('限流/额度/超时失败不重试', async () => {
    for (const kind of ['rate-limited', 'quota', 'timeout'] as const) {
      const alpha = fakeEngine({ id: 'alpha', failure: engineFailure(kind) })
      const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', '苹果 股价 行情')] })
      const provider = harness([alpha, beta], {
        intentEngines: intent => intent === 'vertical-data' ? ['alpha'] : intent === 'chinese-web' ? ['beta'] : [],
      })
      await expect(provider.search({ query: '苹果 股价' })).rejects.toMatchObject({ code: 'WEB_PROVIDER_ERROR' })
      expect(beta.calls).toHaveLength(0)
    }
  })

  it('请求预算耗尽：不降级', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      search: (_request, ctx) => {
        ctx.countRequest()
        return { ok: true, outcome: { sources: [], truncated: false } }
      },
    })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', '苹果 股价 行情')] })
    const result = await harness([alpha, beta], {
      controls: { maxRequests: 1 },
      intentEngines: intent => intent === 'vertical-data' ? ['alpha'] : intent === 'chinese-web' ? ['beta'] : [],
    }).search({ query: '苹果 股价' })
    expect(result.sources).toEqual([])
    expect(beta.calls).toHaveLength(0)
  })

  it('热榜路由失败同样降级一次', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '热点')] })
    const beta = fakeEngine({ id: 'beta', hotFailure: engineFailure('provider-error') })
    const result = await harness([alpha, beta], {
      intentEngines: intent => intent === 'hot-list' ? ['beta'] : intent === 'chinese-web' ? ['alpha'] : [],
    }).search({ query: '热点' })
    expect(beta.hotCalls).toBe(1)
    expect(alpha.calls).toHaveLength(1)
    expect(result.content).toContain(renderNote({ id: 'hot-degrade', params: { language: 'chinese' } }))
    expect(result.sources.map(item => item.url)).toEqual(['https://a.example/1'])
  })

  it('每操作最多一次：降级后的通用路由仍为空也不再重试', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [] })
    const beta = fakeEngine({ id: 'beta', sources: [] })
    const gamma = fakeEngine({ id: 'gamma', sources: [source('https://c.example/1', '苹果 股价')] })
    const result = await harness([alpha, beta, gamma], {
      intentEngines: intent => intent === 'vertical-data' ? ['alpha'] : intent === 'chinese-web' ? ['beta', 'gamma'] : [],
    }).search({ query: '苹果 股价' })
    expect(alpha.calls).toHaveLength(1)
    expect(beta.calls).toHaveLength(1)
    expect(gamma.calls).toHaveLength(0)
    expect(result.sources).toEqual([])
  })

  it('没有其他通道时不重复同一引擎', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [] })
    const result = await harness([alpha], {
      intentEngines: intent => intent === 'vertical-data' ? ['alpha'] : [],
    }).search({ query: '苹果 股价' })
    expect(alpha.calls).toHaveLength(1)
    expect(result.content).toContain(renderNote({ id: 'degrade-no-channel' }))
  })
})

// ---- 6. content 合并 ----

describe('content 合并（生成式答案）', () => {
  it('成功轮答案置于处理说明之前', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [source('https://a.example/1', '红烧肉')],
      content: '这是直答答案',
    })
    const result = await harness([alpha]).search({ query: '红烧肉' })
    expect(result.content).toBeDefined()
    expect(result.content!.startsWith('这是直答答案\n\n搜索处理说明：')).toBe(true)
  })

  it('无答案时内容形态不变', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '红烧肉')] })
    const result = await harness([alpha]).search({ query: '红烧肉' })
    expect(result.content!.startsWith('搜索处理说明：')).toBe(true)
  })

  it('零相关结果但有答案：按正常路径返回，不落「未找到」说明', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [source('https://a.example/1', '完全无关')],
      content: '答案正文',
    })
    const result = await harness([alpha]).search({ query: 'weather tomorrow' })
    expect(result.sources).toEqual([])
    expect(result.content!.startsWith('答案正文')).toBe(true)
    expect(result.content).not.toContain('未找到')
  })

  it('多路答案按派发序拼接', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [source('https://a.example/1', '红烧肉')],
      content: 'A',
    })
    const beta = fakeEngine({
      id: 'beta',
      sources: [source('https://b.example/1', '红烧肉')],
      content: 'B',
    })
    const result = await harness([alpha, beta], { controls: { preset: 'multi' } }).search({ query: '红烧肉' })
    expect(result.content!.startsWith('A\n\nB\n\n搜索处理说明：')).toBe(true)
  })
})

// ---- 7. 归因 ----

describe('融合归因', () => {
  it('按贡献数排序并只列前三个引擎', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [source('https://a.example/1', 'kubernetes'), source('https://a.example/2', 'kubernetes')],
    })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', 'kubernetes')] })
    const gamma = fakeEngine({ id: 'gamma', sources: [source('https://c.example/1', 'kubernetes')] })
    const delta = fakeEngine({ id: 'delta', sources: [source('https://d.example/1', 'kubernetes')] })
    const result = await harness([alpha, beta, gamma, delta], { controls: { preset: 'multi' }, now: FIXED_NOW }).search({ query: 'kubernetes' })
    expect(result.content).toContain(renderNote({
      id: 'attribution',
      params: { entries: [
        { engine: 'alpha', count: 2, elapsedMs: 0 },
        { engine: 'beta', count: 1, elapsedMs: 0 },
        { engine: 'gamma', count: 1, elapsedMs: 0 },
      ] },
    }))
  })

  it('单引擎也标注', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', 'kubernetes')] })
    const result = await harness([alpha], { now: FIXED_NOW }).search({ query: 'kubernetes' })
    expect(result.content).toContain(renderNote({ id: 'attribution', params: { entries: [{ engine: 'alpha', count: 1, elapsedMs: 0 }] } }))
  })
})

// ---- 8. 域名多样性 ----

describe('域名多样性', () => {
  it('同一主机超过 2 条被裁，计数进说明', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [
        source('https://example.com/a1', 'kubernetes'),
        source('https://example.com/a2', 'kubernetes'),
        source('https://example.com/a3', 'kubernetes'),
        source('https://example.com/a4', 'kubernetes'),
      ],
    })
    const result = await harness([alpha]).search({ query: 'kubernetes' })
    expect(result.sources).toHaveLength(2)
    expect(result.content).toContain(renderNote({ id: 'domain-limit', params: { omitted: 2 } }))
  })

  it('官方文档域豁免上限', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [
        source('https://docs.python.org/3/a', 'python'),
        source('https://docs.python.org/3/b', 'python'),
        source('https://docs.python.org/3/c', 'python'),
        source('https://example.com/1', 'python'),
      ],
    })
    const result = await harness([alpha]).search({ query: 'python official documentation' })
    expect(result.sources).toHaveLength(4)
    expect(result.content).not.toContain('因单域上限省略')
  })

  it('中文政府权威域及其子域豁免上限', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [
        source('https://www.beijing.gov.cn/a', '城市暴雨积水安全出行官方指南'),
        source('https://www.beijing.gov.cn/b', '城市暴雨积水安全出行官方指南'),
        source('https://www.beijing.gov.cn/c', '城市暴雨积水安全出行官方指南'),
        source('https://example.com/1', '城市暴雨积水安全出行'),
      ],
    })
    const result = await harness([alpha]).search({ query: '城市暴雨积水 安全出行 官方指南' })
    expect(result.sources).toHaveLength(4)
    expect(result.content).not.toContain('因单域上限省略')

    const ordinary = fakeEngine({
      id: 'ordinary',
      sources: [
        source('https://www.beijing.gov.cn/a', '城市暴雨积水安全出行提示'),
        source('https://www.beijing.gov.cn/b', '城市暴雨积水安全出行提示'),
        source('https://www.beijing.gov.cn/c', '城市暴雨积水安全出行提示'),
      ],
    })
    const ordinaryResult = await harness([ordinary]).search({ query: '城市暴雨积水 安全出行 提示' })
    expect(ordinaryResult.sources).toHaveLength(2)
    expect(ordinaryResult.content).toContain('因单域上限省略 1 条')
  })

  it('中文政府权威域不追加搜索请求', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://example.com/1', '城市暴雨积水安全出行')] })
    const result = await harness([alpha]).search({ query: '城市暴雨积水 安全出行 官方指南' })
    expect(alpha.calls).toHaveLength(1)
    expect(result.content).not.toContain('补充检索')
  })

  it('主题不匹配的政府权威域不豁免单域上限', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [
        source('https://www.beijing.gov.cn/a', '义务教育入学服务'),
        source('https://www.beijing.gov.cn/b', '义务教育入学服务'),
        source('https://www.beijing.gov.cn/c', '义务教育入学服务'),
      ],
    })
    const result = await harness([alpha]).search({ query: '政府' })
    expect(result.sources).toHaveLength(2)
    expect(result.content).toContain('因单域上限省略 1 条')
  })

  it('不同主机不受影响', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [
        source('https://a.example/1', 'kubernetes'),
        source('https://b.example/1', 'kubernetes'),
        source('https://c.example/1', 'kubernetes'),
      ],
    })
    const result = await harness([alpha]).search({ query: 'kubernetes' })
    expect(result.sources).toHaveLength(3)
    expect(result.content).not.toContain('因单域上限省略')
  })
})

// ---- 9. 搜索输出预算 ----

describe('搜索输出预算', () => {
  it('超过 maxOutputChars 从尾部裁并置 truncated', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [
        source('https://a.example/1', 'a'),
        source('https://b.example/1', 'bbbbbbbbbb'),
        source('https://c.example/1', 'cccccccccc'),
      ],
    })
    const result = await harness([alpha], { controls: { maxOutputChars: 40 } }).search({ query: 'kubernetes' })
    expect(result.sources).toHaveLength(1)
    expect(result.truncated).toBe(true)
    expect(result.content).toContain(renderNote({ id: 'output-budget', params: { omitted: 2 } }))
  })

  it('预算内不裁、truncated 保持 false', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [
        source('https://a.example/1', 'a'),
        source('https://b.example/1', 'b'),
        source('https://c.example/1', 'c'),
      ],
    })
    const result = await harness([alpha], { controls: { maxOutputChars: 1000 } }).search({ query: 'kubernetes' })
    expect(result.sources).toHaveLength(3)
    expect(result.truncated).toBe(false)
    expect(result.content).not.toContain('因输出预算省略')
  })

  it('与 maxResults 共用 truncated 语义', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [
        source('https://a.example/1', 'a'),
        source('https://b.example/1', 'b'),
        source('https://c.example/1', 'c'),
      ],
    })
    const result = await harness([alpha], { controls: { maxOutputChars: 1000 } }).search({ query: 'kubernetes', maxResults: 1 })
    expect(result.sources).toHaveLength(1)
    expect(result.truncated).toBe(true)
  })

  it('未设置 maxOutputChars 时不做预算裁切', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [
        source('https://a.example/1', 'a'),
        source('https://b.example/1', 'b'),
        source('https://c.example/1', 'c'),
      ],
    })
    const result = await harness([alpha]).search({ query: 'kubernetes' })
    expect(result.sources).toHaveLength(3)
  })
})

// ---- 10. Phase 1B 搜索质量链路 ----

describe('Phase 1B 搜索质量链路', () => {
  it('summary 贯通到 DSH WebSearchSource', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [{
        url: 'https://a.example/1',
        title: 'kubernetes',
        snippet: 'short',
        summary: 'long model-facing summary',
      }],
    })
    const result = await harness([alpha]).search({ query: 'kubernetes' })
    expect(result.sources[0]).toMatchObject({ summary: 'long model-facing summary' })
  })

  it('显式日期窗口过滤已知窗口外结果并说明省略数', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [
        { url: 'https://a.example/old', title: 'kubernetes 2026', publishedAt: '2025-12-31T00:00:00Z' },
        { url: 'https://a.example/new', title: 'kubernetes 2026', publishedAt: '2026-01-15T00:00:00Z' },
      ],
    })
    const result = await harness([alpha], { now: FIXED_NOW }).search({
      query: 'kubernetes 2026 after:2026-01-01 before:2026-02-01',
    })
    expect(result.sources.map(source => source.url)).toEqual(['https://a.example/new'])
    expect(result.content).toContain(renderNote({ id: 'date-filtered', params: { omitted: 1 } }))
  })

  it('首轮日期窗口外结果判定不足，补派一路获取窗口内结果', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [{ url: 'https://a.example/old', title: 'kubernetes 2026', publishedAt: '2025-12-31T00:00:00Z' }],
    })
    const beta = fakeEngine({
      id: 'beta',
      sources: [{ url: 'https://b.example/new', title: 'kubernetes 2026', publishedAt: '2026-01-15T00:00:00Z' }],
    })
    const result = await harness([alpha, beta], {
      now: FIXED_NOW,
      intentEngines: intent => intent === 'english-web' ? ['alpha', 'beta'] : [],
    }).search({ query: 'kubernetes 2026 after:2026-01-01 before:2026-02-01' })
    expect(alpha.calls).toHaveLength(1)
    expect(beta.calls).toHaveLength(1)
    expect(result.sources.map(source => source.url)).toEqual(['https://b.example/new'])
  })

  it('SiliconFlow 重排结果参与最终输出', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [
        source('https://a.example/1', 'kubernetes deployment a'),
        source('https://b.example/1', 'kubernetes deployment b'),
      ],
    })
    const rerank: RerankOptions = {
      resolve: async () => 'rerank-key',
      fetcher: async () => new Response(JSON.stringify({
        results: [
          { index: 1, relevance_score: 0.9 },
          { index: 0, relevance_score: 0.1 },
        ],
      }), { headers: { 'content-type': 'application/json' } }),
    }
    const result = await harness([alpha], { rerank }).search({ query: 'kubernetes deployment' })
    expect(result.sources.map(source => source.url)).toEqual(['https://b.example/1', 'https://a.example/1'])
    expect(result.content).toContain(renderNote({ id: 'rerank-applied' }))
  })

  it('官方域缺失时，补派请求追加对应 site 限定', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://blog.example/node', 'Node.js 文档')] })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://nodejs.org/docs', 'Node.js 文档')] })
    const result = await harness([alpha, beta], {
      intentEngines: intent => intent === 'english-web' ? ['alpha', 'beta'] : [],
    }).search({ query: 'Node.js 文档' })
    expect(beta.calls).toHaveLength(1)
    expect(beta.calls[0]!.query).toBe('Node.js 文档 site:nodejs.org')
    expect(result.sources.map(source => source.url)[0]).toBe('https://nodejs.org/docs')
  })

  it('首路可恢复失败时补派一路，而不是直接全败', async () => {
    const alpha = fakeEngine({ id: 'alpha', failure: engineFailure('provider-error') })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', '红烧肉 做法')] })
    const result = await harness([alpha, beta], {
      intentEngines: intent => intent === 'chinese-web' ? ['alpha', 'beta'] : [],
    }).search({ query: '红烧肉 做法' })
    expect(alpha.calls).toHaveLength(1)
    expect(beta.calls).toHaveLength(1)
    expect(result.sources.map(source => source.url)).toEqual(['https://b.example/1'])
  })

  it('热点意图无榜单引擎时向搜索面下发 freshness news', async () => {
    const requests: EngineSearchRequest[] = []
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [source('https://a.example/news', 'OpenAI AI 新闻')],
      search: async request => {
        requests.push(request)
        return { ok: true, outcome: { sources: [source('https://a.example/news', 'OpenAI AI 新闻')], truncated: false } }
      },
    })
    await harness([alpha]).search({ query: 'OpenAI AI 新闻' })
    expect(requests[0]?.freshness).toBe('news')
  })

  it('中文政策查询将主题匹配的 gov.cn 结果排前', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [
        source('https://example.com/policy', '人工智能政策解读'),
        source('https://www.gov.cn/policy', '人工智能政策解读'),
      ],
    })
    const result = await harness([alpha]).search({ query: '人工智能 政策' })
    expect(result.sources[0]?.url).toBe('https://www.gov.cn/policy')
  })

  it('ready 只要求存在一个已启用且可用的搜索服务', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [] })
    const provider = harness([alpha], {
      controls: { serviceEnabled: { alpha: false } },
      ready: async () => true,
    })
    await expect(provider.ready()).resolves.toBe(false)

    const enabledProvider = harness([alpha], { ready: async () => true })
    await expect(enabledProvider.ready()).resolves.toBe(true)
  })

  it('社区观点形态词不参与硬相关性过滤', async () => {
    const zhihu = fakeEngine({
      id: 'zhihu',
      sources: [source('https://zhuanlan.zhihu.com/p/example', 'DeepSeek V4.1 测试实录')],
    })
    const result = await harness([zhihu], { intentEngines: () => ['zhihu'] })
      .search({ query: '知乎怎么看 DeepSeek V4.1' })
    expect(result.sources.map(source => source.url)).toEqual(['https://zhuanlan.zhihu.com/p/example'])
  })

  it('DSH 多查询共享请求预算', async () => {
    const requests: EngineSearchRequest[] = []
    let granted = 0
    const alpha = fakeEngine({
      id: 'alpha',
      search: async (request, ctx) => {
        requests.push(request)
        if (!ctx.countRequest()) return { ok: false, failure: engineFailure('quota', { detail: 'request budget exhausted' }) }
        granted += 1
        return { ok: true, outcome: { sources: [source('https://a.example/1', 'kubernetes')], truncated: false } }
      },
    })
    const provider = harness([alpha], { controls: { maxRequests: 2 } })
    const controller = new AbortController()
    await Promise.allSettled(Array.from({ length: 10 }, (_, index) =>
      provider.search({ query: `kubernetes ${index}` }, controller.signal),
    ))
    expect(requests).toHaveLength(10)
    expect(granted).toBe(2)
  })

  it('共享预算的 remainingRequests 跨操作扣减', async () => {
    const shared = new SharedRequestBudget(1)
    await runOperation({ preset: 'multi', maxRequests: 1 }, 'search', undefined, async op => {
      expect(op.remainingRequests).toBe(1)
      expect(op.countRequest()).toBe(true)
      expect(op.remainingRequests).toBe(0)
    }, shared)
    await runOperation({ preset: 'multi', maxRequests: 1 }, 'search', undefined, async op => {
      expect(op.remainingRequests).toBe(0)
      expect(op.countRequest()).toBe(false)
    }, shared)
  })
})

// ---- 11. 额度账本上报 ----

describe('单路结局上报（额度账本钩子）', () => {
  it('成功路报 success（空结果也算 HTTP 成功）', async () => {
    const events: Array<[string, LaneOutcomeKind]> = []
    const alpha = fakeEngine({ id: 'alpha', sources: [] })
    await harness([alpha], {
      onLaneOutcome: (engineId, kind) => events.push([engineId, kind]),
    }).search({ query: '红烧肉' })
    expect(events).toEqual([['alpha', 'success']])
  })

  it('限流失败报 rate-limited', async () => {
    const events: Array<[string, LaneOutcomeKind]> = []
    const alpha = fakeEngine({ id: 'alpha', failure: engineFailure('rate-limited') })
    await expect(harness([alpha], {
      onLaneOutcome: (engineId, kind) => events.push([engineId, kind]),
    }).search({ query: '红烧肉' })).rejects.toMatchObject({ code: 'WEB_PROVIDER_ERROR' })
    expect(events).toEqual([['alpha', 'rate-limited']])
  })

  it('额度失败报 quota', async () => {
    const events: Array<[string, LaneOutcomeKind]> = []
    const alpha = fakeEngine({ id: 'alpha', failure: engineFailure('quota') })
    await expect(harness([alpha], {
      onLaneOutcome: (engineId, kind) => events.push([engineId, kind]),
    }).search({ query: '红烧肉' })).rejects.toMatchObject({ code: 'WEB_PROVIDER_ERROR' })
    expect(events).toEqual([['alpha', 'quota']])
  })

  it('其他失败与超时不入账', async () => {
    const events: Array<[string, LaneOutcomeKind]> = []
    const alpha = fakeEngine({ id: 'alpha', failure: engineFailure('provider-error') })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', 'kubernetes')] })
    await harness([alpha, beta], {
      controls: { preset: 'multi' },
      onLaneOutcome: (engineId, kind) => events.push([engineId, kind]),
    }).search({ query: 'kubernetes' })
    expect(events).toEqual([['beta', 'success']])
  })
})

// ---- 12. 垂直必填参数与语言 fail-open ----

describe('垂直必填参数校验', () => {
  it('缺必填参数：与目录不存在同处置，说明缺哪个参数且不派发垂直', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '苹果 股价 行情')] })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', '苹果 股价 行情')] })
    const result = await harness([alpha, beta], {
      intentEngines: intent => intent === 'vertical-data' ? ['alpha'] : intent === 'chinese-web' ? ['beta'] : [],
      verticalCatalog: { validate: async () => ({ exists: true, missingRequired: ['type', 'value'] }) },
    }).search({ query: '苹果 股价' })
    expect(alpha.calls).toHaveLength(0)
    expect(beta.calls).toHaveLength(1)
    expect(beta.calls[0]!.vertical).toBeUndefined()
    expect(result.content).toContain(renderNote({ id: 'vertical-missing-params', params: { missing: ['type', 'value'] } }))
  })

  it('带必填参数的 tag-only 垂直请求（security.vuln/finance.macro/code.doc）不派发垂直', async () => {
    const missingByTag: Record<string, readonly string[]> = {
      'security.vuln': ['type', 'value'],
      'finance.macro': ['type'],
      'code.doc': ['library'],
    }
    const cases = [
      { query: 'CVE-2026-1234 影响版本', tag: 'security.vuln' },
      { query: '中国 GDP 增速', tag: 'finance.macro' },
      { query: 'React 库文档', tag: 'code.doc' },
    ] as const
    for (const testCase of cases) {
      const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', testCase.query)] })
      const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', testCase.query)] })
      const result = await harness([alpha, beta], {
        intentEngines: intent => intent === 'vertical-data' ? ['alpha'] : intent === 'chinese-web' ? ['beta'] : [],
        verticalCatalog: {
          validate: async tag => ({ exists: true, missingRequired: missingByTag[tag] ?? [] }),
        },
      }).search({ query: testCase.query })
      expect(alpha.calls.every(call => call.vertical === undefined)).toBe(true)
      expect(beta.calls.length).toBeGreaterThan(0)
      expect(beta.calls.every(call => call.vertical === undefined)).toBe(true)
      expect(result.content).toContain(renderNote({ id: 'vertical-missing-params', params: { missing: missingByTag[testCase.tag]! } }))
    }
  })

  it('英文垂直查询目录校验失败：fail-open 走 english-web 而非 chinese-web', async () => {
    const verticalEngine = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', 'CVE-9999-1234 vulnerability')] })
    const chineseEngine = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', 'CVE-9999-1234 vulnerability')] })
    const englishEngine = fakeEngine({ id: 'gamma', sources: [source('https://c.example/1', 'CVE-9999-1234 vulnerability')] })
    const result = await harness([verticalEngine, chineseEngine, englishEngine], {
      intentEngines: intent => intent === 'vertical-data' ? ['alpha']
        : intent === 'chinese-web' ? ['beta']
          : intent === 'english-web' ? ['gamma'] : [],
      verticalCatalog: { validate: async () => ({ exists: false, missingRequired: [] }) },
    }).search({ query: 'CVE-9999-1234 vulnerability' })
    expect(verticalEngine.calls).toHaveLength(0)
    expect(chineseEngine.calls).toHaveLength(0)
    expect(englishEngine.calls).toHaveLength(1)
    expect(englishEngine.calls[0]!.vertical).toBeUndefined()
    expect(result.sources.map(item => item.url)).toEqual(['https://c.example/1'])
  })

  it('目录校验拿到操作预算：countRequest 可消费', async () => {
    let budgetAllowed: boolean | undefined
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '苹果 股价 行情')] })
    await harness([alpha], {
      controls: { maxRequests: 1 },
      intentEngines: intent => intent === 'vertical-data' ? ['alpha'] : [],
      verticalCatalog: {
        validate: async (_tag, _params, budget) => {
          budgetAllowed = budget?.countRequest?.()
          return { exists: true, missingRequired: [] }
        },
      },
    }).search({ query: '苹果 股价' })
    expect(budgetAllowed).toBe(true)
  })

  it('请求预算耗尽：目录校验得到 false 并按失败处置', async () => {
    let budgetAllowed: boolean | undefined
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '苹果 股价 行情')] })
    const result = await harness([alpha], {
      controls: { maxRequests: 0 },
      intentEngines: intent => intent === 'vertical-data' ? ['alpha'] : intent === 'chinese-web' ? ['alpha'] : [],
      verticalCatalog: {
        validate: async (_tag, _params, budget) => {
          budgetAllowed = budget?.countRequest?.()
          throw new Error('budget exhausted')
        },
      },
    }).search({ query: '苹果 股价' })
    expect(budgetAllowed).toBe(false)
    expect(result.content).toContain(renderNote({ id: 'vertical-unavailable' }))
  })
})

// ---- 13. content 即成功 ----

describe('content 即成功（无引用链接的结构化数据）', () => {
  it('垂直 content-only 成功不降级、不进空结果分支，content 保留', async () => {
    const alpha = fakeEngine({
      id: 'alpha',
      sources: [],
      content: '结构化数据 1 条（无引用链接）：[{"value":42}]',
    })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', '苹果 股价 行情')] })
    const result = await harness([alpha, beta], {
      intentEngines: intent => intent === 'vertical-data' ? ['alpha'] : intent === 'chinese-web' ? ['beta'] : [],
    }).search({ query: '苹果 股价' })
    expect(alpha.calls).toHaveLength(1)
    expect(beta.calls).toHaveLength(0)
    expect(result.sources).toEqual([])
    expect(result.content).toContain('结构化数据 1 条')
    expect(result.content).not.toContain('未找到与查询相关的结果')
    expect(result.content).not.toContain(renderNote({ id: 'vertical-degrade', params: { language: 'chinese' } }))
  })
})

// ---- 14. 热点榜映射序 ----

describe('热点榜按映射序取第一个可用引擎', () => {
  it('知乎仅为次选且 AIHOT 不在池内：走知乎 hotTopics', async () => {
    const zhihu = fakeEngine({ id: 'zhihu', hotSources: [source('https://hot.example/1', '知乎热榜')] })
    const result = await harness([zhihu], {
      intentEngines: () => ['aihot', 'zhihu'],
    }).search({ query: '热点' })
    expect(zhihu.hotCalls).toBe(1)
    expect(zhihu.calls).toHaveLength(0)
    expect(result.sources.map(item => item.url)).toEqual(['https://hot.example/1'])
  })

  it('AIHOT 在池内具备 hotTopics：走 AIHOT', async () => {
    const aihot = fakeEngine({ id: 'aihot', hotSources: [source('https://hot.example/2', 'AI 热榜')] })
    const result = await harness([aihot], {
      intentEngines: () => ['aihot', 'zhihu'],
    }).search({ query: '热点' })
    expect(aihot.hotCalls).toBe(1)
    expect(aihot.calls).toHaveLength(0)
    expect(result.sources.map(item => item.url)).toEqual(['https://hot.example/2'])
  })
})

// ---- 15. 同源去重接线 ----

describe('同源去重接线', () => {
  it('两个同 upstreamGroup 引擎命中同一 URL 只计一路', async () => {
    const alpha = fakeEngine({ id: 'alpha', upstreamGroup: 'shared', sources: [source('https://same.example/1', 'kubernetes')] })
    const beta = fakeEngine({ id: 'beta', upstreamGroup: 'shared', sources: [source('https://same.example/1', 'kubernetes')] })
    const result = await harness([alpha, beta], { controls: { preset: 'multi' }, now: FIXED_NOW }).search({ query: 'kubernetes' })
    expect(result.sources).toHaveLength(1)
    expect(result.content).toContain(renderNote({ id: 'attribution', params: { entries: [{ engine: 'alpha', count: 1, elapsedMs: 0 }] } }))
    expect(result.content).not.toContain('beta×1')
  })

  it('不同组同 URL 正常合并计票', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://same.example/1', 'kubernetes')] })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://same.example/1', 'kubernetes')] })
    const result = await harness([alpha, beta], { controls: { preset: 'multi' } }).search({ query: 'kubernetes' })
    expect(result.sources).toHaveLength(1)
    expect(result.content).toContain('alpha×1')
    expect(result.content).toContain('beta×1')
  })
})

// ---- 16. 额度耗尽同槽降级 ----

describe('额度耗尽同槽降级', () => {
  it('keyless-fallback 额度失败后用无 apiKey 上下文重试并成功', async () => {
    const seen: Array<string | undefined> = []
    const alpha = fakeEngine({
      id: 'alpha',
      auth: 'keyless-fallback',
      search: (_request, ctx) => {
        seen.push(ctx.apiKey)
        return seen.length === 1
          ? { ok: false, failure: engineFailure('quota') }
          : { ok: true, outcome: { sources: [source('https://a.example/1', '红烧肉')], truncated: false } }
      },
    })
    const result = await harness([alpha], { apiKey: 'secret' }).search({ query: '红烧肉' })
    expect(seen).toEqual(['secret', undefined])
    expect(result.sources.map(item => item.url)).toEqual(['https://a.example/1'])
    expect(result.content).toContain(renderNote({ id: 'keyless-fallback' }))
  })

  it('auth 失败不降级：只调用一次', async () => {
    const seen: Array<string | undefined> = []
    const alpha = fakeEngine({
      id: 'alpha',
      auth: 'keyless-fallback',
      search: (_request, ctx) => {
        seen.push(ctx.apiKey)
        return { ok: false, failure: engineFailure('auth') }
      },
    })
    await expect(harness([alpha], { apiKey: 'secret' }).search({ query: '红烧肉' }))
      .rejects.toMatchObject({ code: 'WEB_PROVIDER_ERROR' })
    expect(seen).toEqual(['secret'])
  })

  it('非 keyless-fallback 的额度失败不降级', async () => {
    const seen: Array<string | undefined> = []
    const alpha = fakeEngine({
      id: 'alpha',
      auth: 'key',
      search: (_request, ctx) => {
        seen.push(ctx.apiKey)
        return { ok: false, failure: engineFailure('quota') }
      },
    })
    await expect(harness([alpha], { apiKey: 'secret' }).search({ query: '红烧肉' }))
      .rejects.toMatchObject({ code: 'WEB_PROVIDER_ERROR' })
    expect(seen).toEqual(['secret'])
  })
})

// ---- 17. 无额度端点源的估算标注 ----

describe('额度估算标注', () => {
  it('日检说明标注无额度端点源的计数为估算', async () => {
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '红烧肉')] })
    const result = await harness([alpha]).search({ query: '红烧肉' })
    expect(result.content).toContain(renderNote({ id: 'quota-estimated', params: { engines: ['alpha'] } }))
  })
})

// ---- 18. 同槽降级到真实适配层的请求头 ----

describe('额度耗尽同槽降级（真实 AnySearch 适配层）', () => {
  it('quota 失败后用无 Authorization 的请求重试并成功', async () => {
    const requests: Array<{ init: RequestInit }> = []
    const fetcher: typeof fetch = async (_input, init) => {
      requests.push({ init: init ?? {} })
      if (requests.length === 1) {
        return new Response(JSON.stringify({ code: -1, message: 'quota exhausted', data: null }), {
          status: 402,
          headers: { 'content-type': 'application/json' },
        })
      }
      return new Response(JSON.stringify({
        code: 0,
        message: 'success',
        request_id: 'req_anonymous',
        data: {
          results: [{ title: '红烧肉', url: 'https://a.example/1', snippet: '红烧肉 做法' }],
          metadata: { total_results: 1 },
        },
      }), { status: 200, headers: { 'content-type': 'application/json' } })
    }
    const engine = createAnysearchEngine({ fetcher })

    const result = await harness([engine], { apiKey: 'secret' }).search({ query: '红烧肉' })

    expect(requests).toHaveLength(2)
    expect(new Headers(requests[0]!.init.headers).get('authorization')).toBe('Bearer secret')
    expect(new Headers(requests[1]!.init.headers).get('authorization')).toBeNull()
    expect(result.sources.map(item => item.url)).toEqual(['https://a.example/1'])
    expect(result.content).toContain(renderNote({ id: 'keyless-fallback' }))
  })
})
