// 查询语法解析器离线单测（AD13）。夹具依据 DeepSeek Search API 官方语法口径
// （https://api-docs.deepseek.com/zh-cn/guides/search/ 与 api/search，见
//  .scratch/dev-loop/recon/deepseek-paid-baseline.md 第三节）。
import { describe, expect, it } from 'vitest'
import { parseQuerySyntax } from '../../src/search/query-syntax.js'

describe('parseQuerySyntax：site 域名操作符', () => {
  it('解析单个 site: 并从 bareQuery 移除', () => {
    const syntax = parseQuerySyntax('deepseek harness site:github.com')
    expect(syntax.domains).toEqual(['github.com'])
    expect(syntax.excludeDomains).toEqual([])
    expect(syntax.bareQuery).toBe('deepseek harness')
  })

  it('多个 site: 全部收集；-site: 进排除集', () => {
    const syntax = parseQuerySyntax('rust async site:doc.rust-lang.org site:stackoverflow.com -site:medium.com')
    expect(syntax.domains).toEqual(['doc.rust-lang.org', 'stackoverflow.com'])
    expect(syntax.excludeDomains).toEqual(['medium.com'])
    expect(syntax.bareQuery).toBe('rust async')
  })

  it('site: 带路径后缀取域名部分；域名小写归一', () => {
    const syntax = parseQuerySyntax('docs site:GitHub.COM/deepseek-ai/deepseek-harness')
    expect(syntax.domains).toEqual(['github.com'])
    expect(syntax.bareQuery).toBe('docs')
  })

  it('site: 后无合法域名不视为操作符，原样保留', () => {
    const syntax = parseQuerySyntax('site: site:notadomain')
    expect(syntax.domains).toEqual([])
    expect(syntax.bareQuery).toBe('site: site:notadomain')
  })
})

describe('parseQuerySyntax：语言与日期操作符', () => {
  it('lang: 保留原值（含逗号多值）并以最后一次为准', () => {
    const syntax = parseQuerySyntax('vue 3 教程 lang:zh lang:zh,en')
    expect(syntax.language).toBe('zh,en')
    expect(syntax.bareQuery).toBe('vue 3 教程')
  })

  it('after:/before: 接受 YYYY / YYYY-MM / YYYY-MM-DD', () => {
    expect(parseQuerySyntax('ai 芯片 after:2026').after).toBe('2026')
    expect(parseQuerySyntax('新闻 after:2026-10 before:2026-10-31')).toEqual(
      expect.objectContaining({ after: '2026-10', before: '2026-10-31' }),
    )
  })

  it('after: 非法日期值不视为操作符', () => {
    const syntax = parseQuerySyntax('after:last-week 新闻')
    expect(syntax.after).toBeUndefined()
    expect(syntax.bareQuery).toBe('after:last-week 新闻')
  })

  it('lang: 非双字母不视为操作符', () => {
    const syntax = parseQuerySyntax('lang:chinese 新闻')
    expect(syntax.language).toBeUndefined()
    expect(syntax.bareQuery).toBe('lang:chinese 新闻')
  })
})

describe('parseQuerySyntax：保留与边界', () => {
  it('引号短语与 -词原样保留（引擎原生支持）', () => {
    const syntax = parseQuerySyntax('"exact phrase" -排除词 普通 词')
    expect(syntax.bareQuery).toBe('"exact phrase" -排除词 普通 词')
    expect(syntax.domains).toEqual([])
  })

  it('纯操作符查询的 bareQuery 为空串', () => {
    const syntax = parseQuerySyntax('site:github.com')
    expect(syntax.bareQuery).toBe('')
    expect(syntax.domains).toEqual(['github.com'])
  })

  it('无操作符时返回折叠空白后的原文', () => {
    const syntax = parseQuerySyntax('  对比   react  与  vue  ')
    expect(syntax.bareQuery).toBe('对比 react 与 vue')
    expect(syntax.domains).toEqual([])
    expect(syntax.language).toBeUndefined()
  })

  it('空查询返回全空集', () => {
    const syntax = parseQuerySyntax('   ')
    expect(syntax.bareQuery).toBe('')
    expect(syntax.domains).toEqual([])
  })
})

describe('parseQuerySyntax：operators 原样保留（复核 R2 修正）', () => {
  it('原 token 逐字保留：大小写、路径后缀、乱序都在', () => {
    const syntax = parseQuerySyntax('-site:Medium.com lang:ZH site:GitHub.COM/a/path before:2026-06 rust after:2026-01')
    expect(syntax.operators.map(operator => operator.raw)).toEqual([
      '-site:Medium.com', 'lang:ZH', 'site:GitHub.COM/a/path', 'before:2026-06', 'after:2026-01',
    ])
    expect(syntax.operators.map(operator => operator.kind)).toEqual(['-site', 'lang', 'site', 'before', 'after'])
    // 视图字段是解析值：域名小写、剥路径；语言小写。
    expect(syntax.domains).toEqual(['github.com'])
    expect(syntax.excludeDomains).toEqual(['medium.com'])
    expect(syntax.language).toBe('zh')
  })

  it('同名操作符重复：operators 全保留，视图取最后一个', () => {
    const syntax = parseQuerySyntax('site:a.com site:b.com lang:en lang:zh')
    expect(syntax.operators).toHaveLength(4)
    expect(syntax.domains).toEqual(['a.com', 'b.com'])
    expect(syntax.language).toBe('zh')
  })

  it('operators 为只读事实源：unsupported 回拼可逐字重建', () => {
    const syntax = parseQuerySyntax('vue site:Doc.Rust-Lang.org/deep 例子')
    const unsupported = syntax.operators.filter(operator => operator.kind === 'site')
    expect(unsupported.map(operator => operator.raw)).toEqual(['site:Doc.Rust-Lang.org/deep'])
    expect(`${syntax.bareQuery} ${unsupported.map(operator => operator.raw).join(' ')}`)
      .toBe('vue 例子 site:Doc.Rust-Lang.org/deep')
  })
})
