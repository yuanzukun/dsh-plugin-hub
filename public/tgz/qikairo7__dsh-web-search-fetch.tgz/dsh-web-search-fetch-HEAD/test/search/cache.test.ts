// 查询缓存接线离线单测（ADR-0001 §8）：意图 TTL 分档、时效语法绕过、非 auto 预设旁路、
// 命中说明与写缓存时机。聚合器其余行为见 aggregate.test.ts；这里只搭最小假引擎，不触网。
import { describe, expect, it } from 'vitest'
import type { WebSearchResult } from '@deepseek-ai/dsh-web'
import type {
  Engine,
  EngineContext,
  EngineManifest,
  EngineResult,
  EngineSearchOutcome,
  EngineSearchRequest,
  EngineSearchSource,
} from '../../src/engines/contract.js'
import { engineFailure, type EngineFailure } from '../../src/engines/failure.js'
import { AggregatedSearchProvider } from '../../src/search/aggregate.js'
import { renderNote } from '../../src/search/output.js'
import type { SearchIntent } from '../../src/search/router.js'
import { CircuitBreaker } from '../../src/support/breaker.js'
import type { RuntimeControls } from '../../src/support/budget.js'
import { QueryCache, queryCacheKey } from '../../src/support/query-cache.js'

const FIXED_NOW = Date.UTC(2026, 10, 7, 4, 0, 0)

function source(url: string, title?: string, snippet?: string): EngineSearchSource {
  return {
    url,
    ...(title === undefined ? {} : { title }),
    ...(snippet === undefined ? {} : { snippet }),
  }
}

interface FakeEngine extends Engine {
  readonly calls: EngineSearchRequest[]
}

interface FakeOptions {
  readonly id: string
  readonly sources?: readonly EngineSearchSource[]
  readonly content?: string
  readonly failure?: EngineFailure
}

/** 最小假引擎：记录每次 search 请求，按配置返回固定来源或失败。 */
function fakeEngine(options: FakeOptions): FakeEngine {
  const calls: EngineSearchRequest[] = []
  const manifest: EngineManifest = {
    id: options.id,
    label: options.id,
    capabilities: ['search'],
    auth: 'anonymous',
    free: true,
    keyless: true,
    enabledByDefault: true,
    endpoints: { search: `https://${options.id}.invalid/search` },
  }
  return {
    manifest,
    calls,
    async search(request: EngineSearchRequest, _ctx: EngineContext): Promise<EngineResult<EngineSearchOutcome>> {
      calls.push(request)
      if (options.failure !== undefined) return { ok: false, failure: options.failure }
      return {
        ok: true,
        outcome: {
          sources: options.sources ?? [],
          truncated: false,
          ...(options.content === undefined ? {} : { content: options.content }),
        },
      }
    },
  }
}

/** 可推进的假时钟：缓存 TTL 用假时间，不碰真实时钟。 */
function mutableClock(start = FIXED_NOW) {
  let current = start
  return {
    now: () => current,
    advance(ms: number) { current += ms },
  }
}

interface HarnessOptions {
  readonly controls?: RuntimeControls
  readonly intentEngines?: (intent: SearchIntent, prefer?: 'general-web' | 'developer') => readonly string[]
  readonly queryCache: QueryCache
  readonly cacheFingerprint?: () => string
}

function harness(engines: readonly Engine[], options: HarnessOptions): AggregatedSearchProvider {
  const controls: RuntimeControls = {
    maxRequests: 32,
    ...options.controls,
  }
  return new AggregatedSearchProvider({
    resolveControls: () => controls,
    engines,
    breaker: new CircuitBreaker({ now: () => FIXED_NOW }),
    buildContext: async (manifest, op, lane) => ({
      signal: lane.signal,
      deadline: lane.deadline,
      endpoint: manifest.endpoints.search ?? 'https://fake.invalid/search',
      countRequest: () => op.countRequest(),
    }),
    queryCache: options.queryCache,
    ...(options.intentEngines === undefined ? {} : { intentEngines: options.intentEngines }),
    ...(options.cacheFingerprint === undefined ? {} : { cacheFingerprint: options.cacheFingerprint }),
  })
}

describe('查询缓存接线', () => {
  it('配置指纹变化后，auto 预设不命中旧缓存', async () => {
    const time = mutableClock()
    const cache = new QueryCache({ now: time.now })
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '红烧肉')] })
    let fingerprint = 'settings-a'
    const provider = harness([alpha], { queryCache: cache, cacheFingerprint: () => fingerprint })

    await provider.search({ query: '红烧肉' })
    expect(alpha.calls).toHaveLength(1)

    fingerprint = 'settings-b'
    const second = await provider.search({ query: '红烧肉' })
    expect(alpha.calls, '配置变更后不应复用旧缓存').toHaveLength(2)
    expect(second.content?.startsWith(renderNote({ id: 'cache-hit', params: { ageSeconds: 0 } })) ?? false).toBe(false)
  })

  it('TTL 内命中：不派发，content 前带 age 说明且来源与截断位保持不变', async () => {
    const time = mutableClock()
    const cache = new QueryCache({ now: time.now })
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '红烧肉')] })
    const provider = harness([alpha], { queryCache: cache })

    const first = await provider.search({ query: '红烧肉' })
    expect(alpha.calls).toHaveLength(1)

    time.advance(5_000)
    const second = await provider.search({ query: '红烧肉' })
    expect(alpha.calls).toHaveLength(1)
    expect(second.content!.startsWith(renderNote({ id: 'cache-hit', params: { ageSeconds: 5 } }))).toBe(true)
    expect(second.content).toContain(first.content!)
    expect(second.sources).toEqual(first.sources)
    expect(second.truncated).toBe(first.truncated)
  })

  it('空白差异归一到同一缓存键', async () => {
    const time = mutableClock()
    const cache = new QueryCache({ now: time.now })
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '红烧肉')] })
    const provider = harness([alpha], { queryCache: cache })

    await provider.search({ query: '红烧肉' })
    const second = await provider.search({ query: '  红烧肉  ' })
    expect(alpha.calls).toHaveLength(1)
    expect(second.content!.startsWith(renderNote({ id: 'cache-hit', params: { ageSeconds: 0 } }))).toBe(true)
  })

  // TTL 分档：ai-news/hot-list 300s、vertical-data 900s、其余网页意图 1800s。
  const tiers = [
    { name: 'ai-news', query: 'OpenAI 发布', title: 'OpenAI 发布 新模型', ttl: 300 },
    { name: 'hot-list', query: '热点', title: '热点', ttl: 300 },
    { name: 'vertical-data', query: '苹果 股价', title: '苹果 股价 行情', ttl: 900 },
    { name: 'chinese-web', query: '红烧肉', title: '红烧肉', ttl: 1800 },
  ] as const
  for (const tier of tiers) {
    it(`${tier.name} 意图 TTL ${tier.ttl} 秒`, async () => {
      const time = mutableClock()
      const cache = new QueryCache({ now: time.now })
      const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', tier.title)] })
      const provider = harness([alpha], { queryCache: cache })

      await provider.search({ query: tier.query })
      expect(alpha.calls).toHaveLength(1)

      time.advance((tier.ttl - 1) * 1_000)
      await provider.search({ query: tier.query })
      expect(alpha.calls).toHaveLength(1)

      time.advance(1_000)
      await provider.search({ query: tier.query })
      expect(alpha.calls).toHaveLength(2)
    })
  }

  it('research 意图不缓存（TTL 0）：连续两次都派发，且不写缓存', async () => {
    const cache = new QueryCache({ now: mutableClock().now })
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '红烧肉 对比')] })
    const provider = harness([alpha], { queryCache: cache })

    await provider.search({ query: '红烧肉 对比' })
    await provider.search({ query: '红烧肉 对比' })
    expect(alpha.calls).toHaveLength(2)
    expect(cache.size).toBe(0)
  })

  for (const operator of ['after:2026-01-01', 'before:2026-12-31']) {
    it(`显式时效语法 ${operator} 不命中已有缓存`, async () => {
      const cache = new QueryCache({ now: mutableClock().now })
      const query = `红烧肉 ${operator}`
      cache.set(queryCacheKey(query, 'chinese-web', []), {
        sources: [source('https://cache.example/1', '缓存条目')],
        truncated: false,
        content: '缓存内容',
      }, 300)
      const alpha = fakeEngine({
        id: 'alpha',
        sources: [source('https://a.example/1', '红烧肉', 'after 2026 before 2027')],
      })
      const provider = harness([alpha], { queryCache: cache })

      const result = await provider.search({ query })
      expect(alpha.calls).toHaveLength(1)
      expect(result.content!.startsWith(renderNote({ id: 'cache-hit', params: { ageSeconds: 0 } }))).toBe(false)
      expect(result.sources.map(item => item.url)).toEqual(['https://a.example/1'])
    })

    it(`显式时效语法 ${operator} 不写缓存`, async () => {
      const cache = new QueryCache({ now: mutableClock().now })
      const alpha = fakeEngine({
        id: 'alpha',
        sources: [source('https://a.example/1', '红烧肉', 'after 2026 before 2027')],
      })
      const provider = harness([alpha], { queryCache: cache })

      const result = await provider.search({ query: `红烧肉 ${operator}` })
      expect(result.sources).toHaveLength(1)
      expect(cache.size).toBe(0)
    })
  }

  it('降级重试后的最终结果写入缓存', async () => {
    const time = mutableClock()
    const cache = new QueryCache({ now: time.now })
    const alpha = fakeEngine({ id: 'alpha', failure: engineFailure('provider-error') })
    const beta = fakeEngine({ id: 'beta', sources: [source('https://b.example/1', '苹果 股价 行情')] })
    const provider = harness([alpha, beta], {
      queryCache: cache,
      intentEngines: intent => intent === 'vertical-data' ? ['alpha'] : intent === 'chinese-web' ? ['beta'] : [],
    })

    await provider.search({ query: '苹果 股价' })
    expect(alpha.calls).toHaveLength(1)
    expect(beta.calls).toHaveLength(1)

    time.advance(10_000)
    const second = await provider.search({ query: '苹果 股价' })
    expect(alpha.calls).toHaveLength(1)
    expect(beta.calls).toHaveLength(1)
    expect(second.content!.startsWith(renderNote({ id: 'cache-hit', params: { ageSeconds: 10 } }))).toBe(true)
    expect(second.sources.map(item => item.url)).toEqual(['https://b.example/1'])
  })

  it('空结果不写缓存：下一次仍派发', async () => {
    const cache = new QueryCache({ now: mutableClock().now })
    const alpha = fakeEngine({ id: 'alpha', sources: [] })
    const provider = harness([alpha], { queryCache: cache })

    await provider.search({ query: '红烧肉' })
    await provider.search({ query: '红烧肉' })
    expect(alpha.calls).toHaveLength(2)
    expect(cache.size).toBe(0)
  })
})

describe('缓存键与强制最新', () => {
  it('maxResults 参与缓存键：不同条数上限不共享缓存', async () => {
    const time = mutableClock()
    const cache = new QueryCache({ now: time.now })
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '红烧肉')] })
    const provider = harness([alpha], { queryCache: cache })

    await provider.search({ query: '红烧肉', maxResults: 3 })
    await provider.search({ query: '红烧肉', maxResults: 5 })
    expect(alpha.calls).toHaveLength(2)
  })

  it('查询含「最新」：读取绕过缓存，但仍写入', async () => {
    const time = mutableClock()
    const cache = new QueryCache({ now: time.now })
    const alpha = fakeEngine({ id: 'alpha', sources: [source('https://a.example/1', '红烧肉 最新')] })
    const provider = harness([alpha], { queryCache: cache })

    await provider.search({ query: '红烧肉 最新' })
    expect(cache.size).toBe(1)
    await provider.search({ query: '红烧肉 最新' })
    expect(alpha.calls).toHaveLength(2)
  })
})
