// 同源去重：RRF 前同组只保留排名最好的一路，防「多源命中」假共识。
import { describe, expect, it } from 'vitest'
import { rrfFuse, type EngineRanking } from '../../src/search/fuse.js'

const source = (url: string) => ({ url })

describe('rrfFuse 上游分组去重', () => {
  it('同组只计一路：a1/a2 同组、b 独立，a2 的票不计', () => {
    const rankings: EngineRanking[] = [
      { engineId: 'a1', group: 'upstream-a', sources: [source('https://example.test/page')] },
      {
        engineId: 'a2',
        group: 'upstream-a',
        sources: [source('https://example.test/page'), source('https://example.test/only-a2')],
      },
      { engineId: 'b', sources: [source('https://example.test/page')] },
    ]
    const fused = rrfFuse(rankings, 60)
    expect(fused.map(item => item.url)).toEqual(['https://example.test/page'])
    expect(fused[0]!.score).toBeCloseTo(2 / 61)
    expect(fused[0]!.contributors).toEqual(['a1', 'b'])
  })

  it('无组的路各自独立计票，同一 URL 获得两份贡献', () => {
    const fused = rrfFuse([
      { engineId: 'a', sources: [source('https://example.test/x')] },
      { engineId: 'b', sources: [source('https://example.test/x')] },
    ], 60)
    expect(fused).toHaveLength(1)
    expect(fused[0]!.score).toBeCloseTo(2 / 61)
    expect(fused[0]!.contributors).toEqual(['a', 'b'])
  })

  it('组名相同但输入序不连续时仍只保留首个出现的一路', () => {
    const fused = rrfFuse([
      { engineId: 'a1', group: 'upstream-a', sources: [source('https://example.test/one')] },
      { engineId: 'b', sources: [source('https://example.test/two')] },
      { engineId: 'a2', group: 'upstream-a', sources: [source('https://example.test/three')] },
    ], 60)
    expect(fused.map(item => item.url).sort()).toEqual(['https://example.test/one', 'https://example.test/two'])
  })
})
