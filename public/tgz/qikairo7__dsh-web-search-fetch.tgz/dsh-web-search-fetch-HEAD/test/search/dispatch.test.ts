// 离线单测：LaneDispatcher 的 keyless 额度降级只对 search 面确实免钥的引擎生效。
// Firecrawl 的 keyless free tier 仅覆盖 fetch，search 匿名请求受 IP 风控必 403；
// 若把 quota 失败降级成匿名重试，会把额度信号误报成 auth。引擎替身不发网络请求。

import { describe, expect, it } from 'vitest'
import type {
  Engine,
  EngineContext,
  EngineManifest,
  EngineResult,
  EngineSearchOutcome,
  SearchFn,
} from '../../src/engines/contract.js'
import { engineFailure } from '../../src/engines/failure.js'
import { LaneDispatcher } from '../../src/search/dispatch.js'
import { CircuitBreaker } from '../../src/support/breaker.js'
import { OpContext } from '../../src/support/budget.js'
import { SettlementWindow } from '../../src/support/settle.js'

const QUOTA = engineFailure('quota', { detail: 'quota exhausted' })
const SUCCESS: EngineResult<EngineSearchOutcome> = { ok: true, outcome: { sources: [], truncated: false } }

function engineWith(search: SearchFn, manifest: Partial<EngineManifest> = {}): Engine {
  return {
    manifest: {
      id: 'probe',
      label: 'Probe',
      capabilities: ['search'],
      auth: 'keyless-fallback',
      keyless: true,
      endpoints: { search: 'https://probe.test/search' },
      ...manifest,
    },
    search,
  }
}

function dispatcherFor(engine: Engine): LaneDispatcher {
  return new LaneDispatcher({
    engines: [engine],
    breaker: new CircuitBreaker(),
    buildContext: async (_manifest, op, lane): Promise<EngineContext> => ({
      signal: lane.signal,
      deadline: lane.deadline,
      apiKey: 'secret',
      endpoint: 'https://probe.test/search',
      countRequest: () => op.countRequest(),
    }),
    logger: { info: () => undefined, warn: () => undefined, error: () => undefined },
    maxFanoutMs: 1_000,
    rrfK: 60,
    now: () => Date.now(),
    onLaneOutcome: undefined,
  })
}

async function run(engine: Engine) {
  const op = new OpContext({ preset: 'multi' }, new AbortController().signal, undefined, 32)
  const window = new SettlementWindow()
  const outcomes = await dispatcherFor(engine).dispatchRound(
    [{ engine, query: 'q' }],
    window,
    { query: 'q', maxResults: 5 },
    op,
  )
  return { op, outcomes }
}

describe('LaneDispatcher keyless 额度降级的能力面判定', () => {
  it('search 面不免钥：quota 失败不匿名重试', async () => {
    let calls = 0
    const engine = engineWith(
      async (): Promise<EngineResult<EngineSearchOutcome>> => {
        calls += 1
        return { ok: false, failure: QUOTA }
      },
      { keylessCapabilities: ['fetch'] },
    )
    const { outcomes } = await run(engine)

    expect(calls).toBe(1)
    const [outcome] = outcomes
    expect(outcome?.kind).toBe('failed')
    if (outcome?.kind !== 'failed') throw new Error('期望失败结局')
    expect(outcome.failure.kind).toBe('quota')
  })

  it('search 面免钥：quota 失败在同一 lane 去掉 key 重试一次', async () => {
    let calls = 0
    const keys: Array<string | undefined> = []
    const engine = engineWith(
      async (_request, context): Promise<EngineResult<EngineSearchOutcome>> => {
        calls += 1
        keys.push(context.apiKey)
        return calls === 1 ? { ok: false, failure: QUOTA } : SUCCESS
      },
    )
    const { outcomes } = await run(engine)

    expect(calls).toBe(2)
    expect(keys).toEqual(['secret', undefined])
    expect(outcomes[0]?.kind).toBe('ok')
  })
})
