import { describe, expect, it } from 'vitest'

import type { Engine, QuotaReport } from '../../src/engines/contract.js'
import { DailyQuotaSweeper } from '../../src/search/quota-sweep.js'
import { CircuitBreaker } from '../../src/support/breaker.js'
import { OpContext } from '../../src/support/budget.js'

describe('DailyQuotaSweeper', () => {
  it('uses one total deadline for all probes', async () => {
    let now = 1_000
    const calls: string[] = []
    const engine = (id: string): Engine => ({
      manifest: { id, label: id, capabilities: ['search'], auth: 'anonymous', endpoints: {} },
      async quota(): Promise<QuotaReport> {
        calls.push(id)
        if (id === 'alpha') now += 5_000
        return { engineId: id, available: true, remaining: 1 }
      },
    })
    const sweeper = new DailyQuotaSweeper({
      enabled: true,
      breaker: new CircuitBreaker({ now: () => now }),
      buildContext: async (_manifest, _op, lane) => ({
        signal: lane.signal,
        deadline: lane.deadline,
        endpoint: '',
        countRequest: () => true,
      }),
      logger: { warn: () => undefined },
      now: () => now,
    })
    const op = new OpContext({}, new AbortController().signal, undefined, 32)

    await sweeper.sweep([engine('alpha'), engine('beta')], op)

    expect(calls).toEqual(['alpha'])
  })

  it('stops waiting when a quota probe ignores the signal', async () => {
    const engine: Engine = {
      manifest: { id: 'stuck', label: 'stuck', capabilities: ['search'], auth: 'anonymous', endpoints: {} },
      quota: () => new Promise(() => undefined),
    }
    const sweeper = new DailyQuotaSweeper({
      enabled: true,
      breaker: new CircuitBreaker(),
      buildContext: async (_manifest, _op, lane) => ({
        signal: lane.signal,
        deadline: lane.deadline,
        endpoint: '',
        countRequest: () => true,
      }),
      logger: { warn: () => undefined },
      now: () => 1_000,
      timeoutMs: 20,
    })
    const op = new OpContext({}, new AbortController().signal, undefined, 32)
    const started = Date.now()

    await sweeper.sweep([engine], op)

    expect(Date.now() - started).toBeLessThan(1_000)
  })
})
