// 服务选择回归：搜索首轮恒为一路；用户列表仍控制成员与顺序。
import { describe, expect, it } from 'vitest'
import { OpContext, type RuntimeControls } from '../../src/support/budget.js'
import { resolveServiceCap, selectServices, type SelectableService } from '../../src/search/preset.js'

function makeOp(controls: RuntimeControls): OpContext {
  return new OpContext(controls, new AbortController().signal, undefined, 32)
}

const service = (id: string): SelectableService => ({ id })

describe('selectServices', () => {
  it('搜索首轮只选择一路', async () => {
    const rows = await selectServices([
      service('anysearch'),
      service('tavily'),
      service('firecrawl'),
    ], makeOp({ searchServices: ['anysearch', 'tavily', 'firecrawl'] }), 'search')
    expect(rows.map(row => row.id)).toEqual(['anysearch'])
  })

  it('searchServices 过滤成员；intentOrder 决定顺序', async () => {
    const rows = await selectServices([
      service('alpha'),
      service('beta'),
      service('gamma'),
    ], makeOp({ searchServices: ['alpha', 'beta', 'gamma'] }), 'search',
    undefined, undefined, false, ['gamma', 'beta'])
    expect(rows.map(row => row.id)).toEqual(['gamma'])
  })

  it('未提供 intentOrder 时沿用用户 searchServices 顺序', async () => {
    const rows = await selectServices([
      service('alpha'),
      service('beta'),
      service('gamma'),
    ], makeOp({ searchServices: ['gamma', 'alpha'] }), 'search', undefined, undefined, false)
    expect(rows.map(row => row.id)).toEqual(['gamma'])
  })
})

describe('resolveServiceCap', () => {
  it('搜索恒为一路；提取按 URL 与上限决定宽度', () => {
    expect(resolveServiceCap({}, 'search')).toBe(1)
    expect(resolveServiceCap({ maxFetchServices: 2, request: 'fetch', requestText: 'https://example.com/a.txt' }, 'fetch')).toBe(2)
    expect(resolveServiceCap({ maxFetchServices: 4, request: 'fetch', requestText: 'https://docs.example.com/a' }, 'fetch')).toBe(4)
  })
})
