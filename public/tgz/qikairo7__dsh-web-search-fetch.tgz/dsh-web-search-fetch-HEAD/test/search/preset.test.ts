// v0.4 free/keyless 拆分：free 预设按 keyless（免密钥）过滤；free 只表示免费额度型。
import { describe, expect, it } from 'vitest'
import { ENGINE_MANIFESTS } from '../../src/engines/registry.js'
import { OpContext, type RuntimeControls } from '../../src/support/budget.js'
import { resolveAutoCap, selectServices, singleChannelSearch, type SelectableService } from '../../src/search/preset.js'

function makeOp(controls: RuntimeControls): OpContext {
  return new OpContext(controls, new AbortController().signal, undefined, 32)
}

const service = (
  id: string,
  free: boolean,
  keyless: boolean,
  keylessCapabilities?: readonly string[],
): SelectableService => ({
  id,
  free,
  keyless,
  ...(keylessCapabilities === undefined ? {} : { keylessCapabilities }),
})

describe('selectServices 免费预设（free/keyless 拆分）', () => {
  it('free 预设按能力面过滤：Firecrawl 只进提取面，不进搜索面', async () => {
    const items = [
      service('anysearch', true, true),
      service('firecrawl', true, true, ['fetch']),
      service('zhihu', false, false),
      service('aihot', true, true),
    ]
    const searchRows = await selectServices(items, makeOp({ preset: 'free' }), 'search')
    expect(searchRows.map(row => row.id)).toEqual(['anysearch', 'aihot'])
    const fetchRows = await selectServices(items, makeOp({ preset: 'free' }), 'fetch')
    expect(fetchRows.map(row => row.id)).toEqual(['anysearch', 'firecrawl', 'aihot'])
  })

  it('非 free 预设不受 keyless 限制', async () => {
    const rows = await selectServices([
      service('anysearch', true, true),
      service('firecrawl', true, true, ['fetch']),
    ], makeOp({ preset: 'multi' }), 'search')
    expect(rows.map(row => row.id)).toEqual(['anysearch', 'firecrawl'])
  })

  it('生产清单映射：free 搜索面 = AnySearch/Tavily/AIHOT（Firecrawl 仅提取免钥）', async () => {
    const rows = await selectServices(
      ENGINE_MANIFESTS.map(manifest => ({
        id: manifest.id,
        free: manifest.free ?? false,
        keyless: manifest.keyless ?? false,
        ...(manifest.keylessCapabilities === undefined
          ? {}
          : { keylessCapabilities: manifest.keylessCapabilities }),
      })),
      makeOp({ preset: 'free' }),
      'search',
    )
    expect(rows.map(row => row.id)).toEqual(['anysearch', 'tavily', 'aihot'])
  })

  it('生产清单映射：free 提取面 = AnySearch/Tavily/Firecrawl（按 fetch 能力过滤）', async () => {
    const rows = await selectServices(
      ENGINE_MANIFESTS.filter(manifest => manifest.capabilities.includes('fetch')).map(manifest => ({
        id: manifest.id,
        free: manifest.free ?? false,
        keyless: manifest.keyless ?? false,
        ...(manifest.keylessCapabilities === undefined
          ? {}
          : { keylessCapabilities: manifest.keylessCapabilities }),
      })),
      makeOp({ preset: 'free' }),
      'fetch',
    )
    expect(rows.map(row => row.id)).toEqual(['anysearch', 'tavily', 'firecrawl'])
  })

  it('keyless 标记随选择结果透传', async () => {
    const [row] = await selectServices([service('anysearch', true, true)], makeOp({ preset: 'free' }), 'search')
    expect(row!.keyless).toBe(true)
  })
})

describe('auto 搜索宽度（ADR-0002 最小充分检索）', () => {
  const controls = (preset: RuntimeControls['preset']): RuntimeControls => ({ preset, maxSearchServices: 5 })

  it('全部搜索意图首轮走单路', () => {
    for (const intent of ['community-opinion', 'chinese-web', 'english-web', 'vertical-data', 'hot-list', 'research', 'ai-news'] as const) {
      expect(resolveAutoCap(controls('auto'), 'search', makeOp(controls('auto')), intent)).toBe(1)
    }
  })

  it('其余意图走单路', () => {
    for (const intent of ['community-opinion', 'chinese-web', 'english-web', 'vertical-data', 'hot-list'] as const) {
      expect(resolveAutoCap(controls('auto'), 'search', makeOp(controls('auto')), intent)).toBe(1)
    }
  })

  it('single / multi 预设覆盖意图宽度', () => {
    expect(resolveAutoCap(controls('single'), 'search', makeOp(controls('single')), 'research')).toBe(1)
    expect(resolveAutoCap(controls('multi'), 'search', makeOp(controls('multi')), 'chinese-web')).toBe(5)
  })
})

describe('singleChannelSearch 由预设推导', () => {
  it('single 与 auto 均为 true，multi 恒为 false', () => {
    expect(singleChannelSearch({ preset: 'auto' })).toBe(true)
    expect(singleChannelSearch({ preset: 'single' })).toBe(true)
    expect(singleChannelSearch({ preset: 'multi' })).toBe(false)
  })

  it('single 预设恒为单路，multi 预设恒非单路', () => {
    expect(singleChannelSearch({ preset: 'custom' })).toBe(false)
  })
})

describe('intentOrder 决定顺序、searchServices 退为成员过滤（ADR-0001 §2）', () => {
  it('提供 intentOrder：按意图序派发，searchServices 只过滤成员', async () => {
    const rows = await selectServices([
      service('alpha', true, true),
      service('beta', true, true),
      service('gamma', true, true),
    ], makeOp({ preset: 'multi', searchServices: ['alpha', 'beta', 'gamma'] }), 'search',
    undefined, undefined, false, undefined, ['gamma', 'beta'])
    expect(rows.map(row => row.id)).toEqual(['gamma', 'beta', 'alpha'])
  })

  it('未提供 intentOrder：沿用用户 searchServices 顺序', async () => {
    const rows = await selectServices([
      service('alpha', true, true),
      service('beta', true, true),
      service('gamma', true, true),
    ], makeOp({ preset: 'multi', searchServices: ['gamma', 'alpha'] }), 'search')
    expect(rows.map(row => row.id)).toEqual(['gamma', 'alpha'])
  })
})
