import { describe, expect, it } from 'vitest'

import { authorityHosts, isAuthorityHost, isOfficial, officialHosts, preferAuthority, termMatches } from '../../src/search/quality.js'
import { routeSearchQuery } from '../../src/search/router.js'

const analyze = routeSearchQuery

describe('官方域名规则', () => {
  it('官方文档域名按精确主机匹配', () => {
    expect(isOfficial('https://docs.python.org/3/', ['docs.python.org'])).toBe(true)
    expect(isOfficial('https://dev.docs.python.org/3/', ['docs.python.org'])).toBe(false)
  })

  it('-site 不产生官方域名，site 与 -site 并存只保留正向域名', () => {
    expect(officialHosts(analyze('OpenAI 新闻 -site:medium.com'))).toEqual([])
    expect(officialHosts(analyze('OpenAI 新闻 site:openai.com -site:medium.com'))).toEqual(['openai.com'])
    expect(isAuthorityHost('https://medium.com/openai/', analyze('OpenAI 新闻 -site:medium.com'))).toBe(false)
    expect(isAuthorityHost('https://beijing.gov.cn/rain/', analyze('暴雨 官方指南 -site:beijing.gov.cn'))).toBe(false)
  })

  it('-site 排除域名不参与权威域优先排序', () => {
    const ordered = preferAuthority(analyze('暴雨 安全出行 官方指南 -site:beijing.gov.cn'), [
      { url: 'https://example.com/guide/', title: '暴雨安全出行指南', snippet: '安全提示' },
      { url: 'https://beijing.gov.cn/rain/', title: '暴雨安全出行官方指南', snippet: '政府提示' },
    ])
    expect(ordered.map(candidate => candidate.url)).toEqual([
      'https://example.com/guide/',
      'https://beijing.gov.cn/rain/',
    ])
  })

  it('中文政府权威域识别任意子域', () => {
    const query = '城市暴雨积水 安全出行 官方指南'
    expect(isAuthorityHost('https://www.beijing.gov.cn/fuwu/', analyze(query))).toBe(true)
    expect(isAuthorityHost('https://fake-gov.cn.example.com/', analyze(query))).toBe(false)
  })

  it('长中文词按字符覆盖匹配', () => {
    expect(termMatches('暴雨积水', '暴雨水深路段')).toBe(true)
    expect(termMatches('暴雨积水', '交通拥堵路段')).toBe(false)
  })

  it('把中文政府与官方指南查询映射到政府域', () => {
    expect(authorityHosts(analyze('城市暴雨积水 安全出行 官方指南'))).toContain('gov.cn')
    expect(authorityHosts(analyze('个人所得税 专项附加扣除 政策解读'))).toContain('gov.cn')
    expect(authorityHosts(analyze('城市暴雨积水 安全出行 经验分享'))).toEqual([])
    expect(officialHosts(analyze('个人所得税 专项附加扣除 政策解读'))).toEqual([])
  })

  it('官方域候选在主题匹配时优先', () => {
    const ordered = preferAuthority(analyze('城市暴雨积水 安全出行 官方指南'), [
      { url: 'https://example.com/blog/', title: '暴雨积水安全出行经验', snippet: '个人经验' },
      { url: 'https://www.beijing.gov.cn/fuwu/rain/', title: '暴雨积水安全出行官方指南', snippet: '政府提示' },
    ])
    expect(ordered[0]?.url).toBe('https://www.beijing.gov.cn/fuwu/rain/')
  })

  it('主题不匹配的权威域候选不优先', () => {
    const ordered = preferAuthority(analyze('城市暴雨积水 安全出行 官方指南'), [
      { url: 'https://example.com/blog/', title: '暴雨积水安全出行经验', snippet: '个人经验' },
      { url: 'https://www.beijing.gov.cn/education/', title: '义务教育入学政策', snippet: '入学服务' },
    ])
    expect(ordered[0]?.url).toBe('https://example.com/blog/')
  })

  it('中文查询优先中文路径', () => {
    const ordered = preferAuthority(analyze('城市暴雨积水 安全出行 官方指南'), [
      { url: 'https://www.beijing.gov.cn/en/rain/', title: '城市暴雨积水安全出行官方指南' },
      { url: 'https://www.beijing.gov.cn/zh-CN/rain/', title: '城市暴雨积水安全出行官方指南' },
    ])
    expect(ordered[0]?.url).toBe('https://www.beijing.gov.cn/zh-CN/rain/')
  })
})
