// Exa Search Lite 的 provider 接缝测试：显式收窄 searchServices 才允许它进入受控路径。

import { describe, expect, it } from 'vitest'
import type { EngineContext } from '../../src/engines/contract.js'
import { createExaEngine } from '../../src/engines/exa.js'
import { EXA_MANIFEST } from '../../src/engines/registry.js'
import { intentSearchCandidates } from '../../src/engine-priority.js'
import { AggregatedSearchProvider } from '../../src/search/aggregate.js'
import { renderNote } from '../../src/search/output.js'
import { CircuitBreaker } from '../../src/support/breaker.js'

const SEARCH_ENDPOINT = EXA_MANIFEST.endpoints.search!
const API_KEY = 'unit-test-key'

describe('Exa provider 接缝', () => {
  it('搜索服务清单显式只留 exa 时，经真实适配层返回结果', async () => {
    const requests: Array<{ url: string; init: RequestInit }> = []
    const fetcher = (async (input: string | URL | Request, init?: RequestInit) => {
      requests.push({
        url: input instanceof Request ? input.url : String(input),
        init: init ?? {},
      })
      return new Response(JSON.stringify({
        requestId: 'req_exa_provider',
        results: [{
          title: 'TypeScript useEffect cleanup guide',
          url: 'https://example.com/typescript-useeffect',
          publishedDate: '2026-11-10T08:00:00.000Z',
          highlights: [
            'TypeScript useEffect cleanup runs before the next effect.',
          ],
          text: 'TypeScript useEffect cleanup guide.',
        }],
      }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    }) as typeof fetch

    const provider = new AggregatedSearchProvider({
      resolveControls: () => ({
        serviceEnabled: { exa: true },
        searchServices: ['exa'],
        maxRequests: 8,
      }),
      engines: [createExaEngine({ fetcher })],
      breaker: new CircuitBreaker(),
      buildContext: async (manifest, op, lane): Promise<EngineContext> => ({
        signal: lane.signal,
        deadline: lane.deadline,
        apiKey: API_KEY,
        endpoint: manifest.endpoints.search ?? 'https://invalid.local',
        countRequest: () => op.countRequest(),
      }),
      routeCandidates: intentSearchCandidates,
    })

    const result = await provider.search({
      query: 'TypeScript useEffect cleanup',
      maxResults: 5,
    })

    expect(requests).toHaveLength(1)
    expect(requests[0]!.url).toBe(SEARCH_ENDPOINT)
    expect(new Headers(requests[0]!.init.headers).get('x-api-key')).toBe(API_KEY)
    expect(result.sources).toEqual([{
      url: 'https://example.com/typescript-useeffect',
      title: 'TypeScript useEffect cleanup guide',
      snippet: 'TypeScript useEffect cleanup runs before the next effect.',
      summary: 'TypeScript useEffect cleanup runs before the next effect.',
      publishedAt: '2026-11-10T08:00:00.000Z',
    }])
    expect(result.content).toContain(renderNote({
      id: 'route-primary',
      params: { candidate: 'exa', available: 1 },
    }))
  })
})
