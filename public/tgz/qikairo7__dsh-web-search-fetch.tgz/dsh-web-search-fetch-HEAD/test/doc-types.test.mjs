import { describe, expect, it } from 'vitest'
import { compileBlocks, extractTsBlocks } from '../scripts/check-doc-types.mjs'

describe('documentation TypeScript fences', () => {
  it('extracts and compiles a valid block', () => {
    const blocks = extractTsBlocks('```ts\nconst value: number = 1\n```\n', 'docs/example.md')
    expect(blocks).toHaveLength(1)
    expect(compileBlocks(blocks, process.cwd())).toEqual([])
  })

  it('reports type errors and honors ignore-check', () => {
    const invalid = extractTsBlocks("```ts\nconst value: number = 'x'\n```\n", 'docs/example.md')
    expect(compileBlocks(invalid, process.cwd()).join('\n')).toContain('Type')

    const ignored = extractTsBlocks("```ts ignore-check\nconst value: number = 'x'\n```\n", 'docs/example.md')
    expect(ignored).toEqual([])
  })

  it('reports an unclosed TypeScript fence', () => {
    expect(extractTsBlocks('```ts\nconst value = 1\n', 'docs/example.md')[0]?.unclosed).toBe(true)
  })
})
