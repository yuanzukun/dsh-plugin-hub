import { describe, expect, it } from 'vitest'
import { existsSync, readFileSync } from 'node:fs'

describe('包表面', () => {
  it('不声明已移除的客户端入口', () => {
    const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'))

    expect(existsSync(new URL('../client', import.meta.url))).toBe(false)
    expect(pkg.exports['./client']).toBeUndefined()
    expect(pkg.files).not.toContain('client/**/*.js')
    expect(pkg.dsh.client).toBeUndefined()
  })
})
