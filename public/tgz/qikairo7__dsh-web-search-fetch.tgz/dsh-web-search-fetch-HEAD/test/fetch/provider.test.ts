// AggregatedFetchProvider 离线单测——注入 HTTP fetcher、假引擎与假 AIHOT 读取器，不触网。
// 静态、动态与 AIHOT 三个分面各覆盖入口分流和提取管线核心断言。

import { describe, expect, it } from 'vitest'
import { WebError } from '@deepseek-ai/dsh-web'
import type { WebFetchResult } from '@deepseek-ai/dsh-web'
import type { Engine, EngineFetchOutcome, EngineManifest, EngineResult } from '../../src/engines/contract.js'
import { engineFailure, type EngineFailure } from '../../src/engines/failure.js'
import {
  AggregatedFetchProvider,
  AGGREGATED_FETCH_PROVIDER_ID,
  type AggregatedFetchProviderOptions,
  type DedicatedApiReader,
  type StaticHttpFetcher,
} from '../../src/fetch/provider.js'
import type { BuildEngineContext } from '../../src/fetch/aggregate.js'
import { createZhihuEngine } from '../../src/engines/zhihu.js'

const URL = 'https://example.com/guide'

function manifest(id: string, capabilities: EngineManifest['capabilities'] = ['fetch']): EngineManifest {
  return { id, label: id, capabilities, auth: 'anonymous', endpoints: {} }
}

function result(content: string, extra: Partial<WebFetchResult> = {}): WebFetchResult {
  return { url: URL, statusCode: 200, body: { kind: 'text', content }, truncated: false, ...extra }
}

function body(chars: number, title = '# Guide'): string {
  const paragraph = 'A documented sentence with stable content and a concrete explanation. '
  return `${title}\n\n${paragraph.repeat(Math.ceil(chars / paragraph.length))}`
}

interface Counting {
  calls: number
}

function okEngine(id: string, content: string, extra: Partial<WebFetchResult> = {}): { engine: Engine; counting: Counting } {
  const counting: Counting = { calls: 0 }
  return {
    counting,
    engine: {
      manifest: manifest(id),
      async fetch(): Promise<EngineResult<EngineFetchOutcome>> {
        counting.calls += 1
        return { ok: true, outcome: result(content, extra) }
      },
    },
  }
}

function failingEngine(id: string, failure: EngineFailure): { engine: Engine; counting: Counting } {
  const counting: Counting = { calls: 0 }
  return {
    counting,
    engine: {
      manifest: manifest(id),
      async fetch(): Promise<EngineResult<EngineFetchOutcome>> {
        counting.calls += 1
        return { ok: false, failure }
      },
    },
  }
}

function hangingEngine(id: string): { engine: Engine; counting: Counting } {
  const counting: Counting = { calls: 0 }
  return {
    counting,
    engine: {
      manifest: manifest(id),
      fetch(): Promise<EngineResult<EngineFetchOutcome>> {
        counting.calls += 1
        return new Promise(() => undefined)
      },
    },
  }
}

function throwingEngine(id: string, error: unknown): { engine: Engine; counting: Counting } {
  const counting: Counting = { calls: 0 }
  return {
    counting,
    engine: {
      manifest: manifest(id),
      async fetch(): Promise<EngineResult<EngineFetchOutcome>> {
        counting.calls += 1
        throw error
      },
    },
  }
}

const buildContext: BuildEngineContext = async (engineManifest: EngineManifest, op, lane) => ({
  signal: lane.signal,
  deadline: lane.deadline,
  endpoint: `https://${engineManifest.id}.test/extract`,
  countRequest: () => op.countRequest(),
})

interface RecordedCall {
  readonly url: URL
  readonly init: RequestInit
}

/** 知乎适配器级替身：记录请求并按下标返回预置响应，不发真实网络请求。 */
function stubFetch(responses: readonly Response[]): { fetcher: typeof fetch; calls: RecordedCall[] } {
  const calls: RecordedCall[] = []
  let index = 0
  const fetcher = (async (input: Parameters<typeof fetch>[0], init?: RequestInit): Promise<Response> => {
    calls.push({ url: new globalThis.URL(String(input)), init: init ?? {} })
    const response = responses[Math.min(index, responses.length - 1)]
    index += 1
    if (response === undefined) throw new Error('测试未配置响应')
    return response
  }) as typeof fetch
  return { fetcher, calls }
}

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })
}

/** 装配层同款上下文：按面取 registry 端点；知乎适配读取 ctx.endpoint，需注入有效凭证。 */
const engineBuildContext: BuildEngineContext = async (engineManifest, op, lane) => ({
  signal: lane.signal,
  deadline: lane.deadline,
  apiKey: 'test-secret',
  endpoint: engineManifest.endpoints.fetch ?? `https://${engineManifest.id}.test/extract`,
  countRequest: () => op.countRequest(),
})

function createProvider(overrides: Partial<AggregatedFetchProviderOptions> = {}): AggregatedFetchProvider {
  return new AggregatedFetchProvider({
    resolveControls: () => ({}),
    engines: [],
    buildContext,
    // 默认关闭地址守卫，避免离线测试触发系统 DNS；守卫行为由专门用例注入 lookup 验证。
    blockPrivateAddresses: false,
    ...overrides,
  })
}

async function catchError(promise: Promise<unknown>): Promise<WebError> {
  const error = await promise.then(
    () => { throw new Error('expected the fetch to reject, but it resolved') },
    (caught: unknown) => caught,
  )
  expect(error).toBeInstanceOf(WebError)
  return error as WebError
}

describe('AggregatedFetchProvider 身份', () => {
  it('id 为 aggregated，available 为 true', () => {
    const provider = createProvider()
    expect(provider.id).toBe(AGGREGATED_FETCH_PROVIDER_ID)
    expect(provider.available()).toBe(true)
  })
})

describe('静态路（注入 HTTP fetcher）', () => {
  it('.json → 只调 HTTP，动态引擎零调用', async () => {
    const http = { calls: 0 }
    const httpFetcher: StaticHttpFetcher = {
      available: () => true,
      async fetch(): Promise<WebFetchResult> {
        http.calls += 1
        return result('{"ok":true}')
      },
    }
    const paid = okEngine('paid', 'must not be used')
    const provider = createProvider({ httpFetcher, engines: [paid.engine] })
    const output = await provider.fetch({ url: 'https://example.com/data.json' })
    expect(http.calls).toBe(1)
    expect(paid.counting.calls).toBe(0)
    expect(output.body.content).toBe('{"ok":true}')
  })

  it('非 2xx 且有正文仍是结果；非 2xx 且空正文 → WEB_BLOCKED_URL', async () => {
    const withBody = createProvider({
      httpFetcher: { available: () => true, async fetch() { return result('not found', { statusCode: 404 }) } },
    })
    expect((await withBody.fetch({ url: 'https://example.com/data.txt' })).statusCode).toBe(404)

    const empty = createProvider({
      httpFetcher: { available: () => true, async fetch() { return result('', { statusCode: 404 }) } },
    })
    const error = await catchError(empty.fetch({ url: 'https://example.com/data.txt' }))
    expect(error.code).toBe('WEB_BLOCKED_URL')
    expect(error.message).toContain('404')
  })

  it('HTTP 服务被关闭 → WEB_PROVIDER_ERROR，零请求', async () => {
    const http = { calls: 0 }
    const provider = createProvider({
      resolveControls: () => ({ serviceEnabled: { http: false } }),
      httpFetcher: { available: () => true, async fetch() { http.calls += 1; return result('x') } },
    })
    const error = await catchError(provider.fetch({ url: 'https://example.com/page.txt' }))
    expect(error.code).toBe('WEB_PROVIDER_ERROR')
    expect(http.calls).toBe(0)
  })
})

describe('动态路：两段式提取', () => {
  it('首路正文够用 → 只派发一路，返回原文，不加溯源标记', async () => {
    const first = okEngine('first', body(900))
    const second = okEngine('second', body(900))
    const provider = createProvider({
      engines: [first.engine, second.engine],
    })
    const output = await provider.fetch({ url: URL })
    expect(first.counting.calls).toBe(1)
    expect(second.counting.calls).toBe(0)
    expect(output.body.content).toBe(body(900))
    expect(output.body.content).not.toContain('提取来源')
    expect(output.body.content).not.toContain('## 提取来源与处理说明')
  })

  it('首路正文不足 → 升级多路整理，种子并入且不重复请求首路', async () => {
    const first = okEngine('first', '# Stub\n\nshort.')
    const second = okEngine('second', body(900))
    const provider = createProvider({
      engines: [first.engine, second.engine],
    })
    const output = await provider.fetch({ url: URL })
    expect(first.counting.calls).toBe(1)
    expect(second.counting.calls).toBe(1)
    expect(output.body.content).toContain('## 提取来源与处理说明')
    expect(output.body.content).toContain('提取来源：')
  })

  it('探测路硬超时：忽略 signal 的悬挂引擎在 probeTimeoutMs 被丢弃，不拖到总限时', async () => {
    const hung = hangingEngine('hung')
    const second = okEngine('second', body(900))
    const provider = createProvider({
      engines: [hung.engine, second.engine],
      probeTimeoutMs: 20,
      perEngineTimeoutMs: 100,
    })
    const started = Date.now()
    const output = await provider.fetch({ url: URL })
    const elapsed = Date.now() - started
    expect(hung.counting.calls).toBe(1)
    expect(second.counting.calls).toBe(1)
    expect(output.body.content).toContain('A documented sentence')
    expect(elapsed).toBeLessThan(2_000)
  })


  it('多路整理传播 truncated', async () => {
    const first = okEngine('first', body(900), { truncated: true })
    const provider = createProvider({ engines: [first.engine] })
    const output = await provider.fetch({ url: URL })
    expect(output.truncated).toBe(true)
  })

  it('动态路没有可用引擎 → WEB_PROVIDER_ERROR，不静默回退 HTTP', async () => {
    const provider = createProvider()
    const error = await catchError(provider.fetch({ url: 'https://example.com/blog' }))
    expect(error.code).toBe('WEB_PROVIDER_ERROR')
  })
})

describe('auto 首路的输出预算', () => {
  it('首路正文超过预算 → 复用整理器省略完整块，标记 truncated', async () => {
    const first = okEngine('first', body(50_000))
    const provider = createProvider({
      engines: [first.engine],
      resolveControls: () => ({ maxOutputChars: 3_000 }),
    })
    const output = await provider.fetch({ url: URL })
    expect(first.counting.calls).toBe(1)
    expect(output.body.content.length).toBeLessThanOrEqual(3_000)
    expect(output.truncated).toBe(true)
    expect(output.body.content).toContain('输出预算不足')
  })

  it('首路未超过预算 → 原样直返，不加尾注与标记', async () => {
    const short = body(900)
    const first = okEngine('first', short)
    const provider = createProvider({
      engines: [first.engine],
      resolveControls: () => ({ maxOutputChars: 3_000 }),
    })
    const output = await provider.fetch({ url: URL })
    expect(output.body.content).toBe(short)
    expect(output.truncated).toBe(false)
  })

  it('首路结构化正文超预算 → 明确报错，不裁坏结构', async () => {
    const json = JSON.stringify({ items: Array.from({ length: 4_000 }, (_value, index) => ({ index, text: 'value' })) })
    const first = okEngine('first', json)
    const provider = createProvider({
      engines: [first.engine],
      resolveControls: () => ({ maxOutputChars: 3_000 }),
    })
    const error = await catchError(provider.fetch({ url: URL }))
    expect(error.code).toBe('WEB_FETCH_TOO_LARGE')
  })
})

describe('AIHOT 专用 API 面', () => {
  it('capabilities 含 aihot-api 的引擎走注入的读取器，不进入通用提取', async () => {
    const aihot: Engine = { manifest: manifest('aihot', ['search', 'aihot-api']) }
    const calls = { read: 0 }
    const reader: DedicatedApiReader = {
      engineId: 'aihot',
      async readApi(url) {
        calls.read += 1
        return result(JSON.stringify({ schemaVersion: 1, url }))
      },
    }
    const provider = createProvider({ engines: [aihot], apiReaders: [reader] })
    const output = await provider.fetch({ url: 'https://aihot.news/api/v1/items?limit=2' })
    expect(calls.read).toBe(1)
    expect(JSON.parse(output.body.content)).toMatchObject({ schemaVersion: 1 })
  })

  it('专用 API 不受普通提取参与列表限制，并按结局入账', async () => {
    const aihot: Engine = { manifest: manifest('aihot', ['search', 'aihot-api']) }
    const outcomes: string[] = []
    const cases = [
      { status: 200, kind: 'success' },
      { status: 429, kind: 'rate-limited' },
      { status: 402, kind: 'quota' },
    ]
    for (const item of cases) {
      const provider = createProvider({
        engines: [aihot],
        apiReaders: [{ engineId: 'aihot', async readApi() { return result('{}', { statusCode: item.status }) } }],
        resolveControls: () => ({ fetchServices: ['anysearch', 'tavily', 'firecrawl', 'zhihu'] }),
        onLaneOutcome: (engineId, kind) => outcomes.push(`${engineId}:${kind}`),
      })
      await provider.fetch({ url: 'https://aihot.news/api/v1/items' })
    }
    expect(outcomes).toEqual(['aihot:success', 'aihot:rate-limited', 'aihot:quota'])
  })

  it('缓存结果不重复计入额度或被熔断观察', async () => {
    const aihot: Engine = { manifest: manifest('aihot', ['search', 'aihot-api']) }
    const outcomes: string[] = []
    const reader: DedicatedApiReader = {
      engineId: 'aihot',
      async readApi() { return result('{}', { statusCode: 503 }) },
      isCached: () => true,
    }
    const provider = createProvider({
      engines: [aihot],
      apiReaders: [reader],
      onLaneOutcome: (engineId, kind) => outcomes.push(`${engineId}:${kind}`),
    })

    await provider.fetch({ url: 'https://aihot.news/api/v1/items' })

    expect(outcomes).toEqual([])
  })

  it('服务总开关关闭 → 读取器零调用，继续通用提取并全败', async () => {
    const aihot: Engine = { manifest: manifest('aihot', ['search', 'aihot-api']) }
    let calls = 0
    const reader: DedicatedApiReader = {
      engineId: 'aihot',
      async readApi() { calls += 1; return result('{}') },
    }
    const provider = createProvider({
      engines: [aihot],
      apiReaders: [reader],
      resolveControls: () => ({ serviceEnabled: { aihot: false } }),
    })
    const error = await catchError(provider.fetch({ url: 'https://aihot.news/api/v1/items' }))
    expect(calls).toBe(0)
    expect(error.code).toBe('WEB_PROVIDER_ERROR')
  })
})

describe('地址守卫', () => {
  it('已证实的回环目标在派发前拒绝，引擎零调用', async () => {
    const paid = okEngine('paid', body(900))
    const provider = createProvider({
      engines: [paid.engine],
      blockPrivateAddresses: true,
      lookup: async () => ['127.0.0.1'],
    })
    const error = await catchError(provider.fetch({ url: 'https://internal.example.com/page' }))
    expect(error.code).toBe('WEB_BLOCKED_URL')
    expect(paid.counting.calls).toBe(0)
  })

  it('fetch.staticDomains 豁免守卫，交给内置 HTTP 提取器', async () => {
    const http: StaticHttpFetcher = { available: () => true, async fetch() { return result('static body') } }
    const provider = createProvider({
      httpFetcher: http,
      blockPrivateAddresses: true,
      lookup: async () => ['127.0.0.1'],
      route: { staticDomains: ['127.0.0.1'] },
    })
    const output = await provider.fetch({ url: 'http://127.0.0.1:8080/page.txt' })
    expect(output.body.content).toBe('static body')
  })
})

describe('入口取消', () => {
  it('已中止的 signal → WEB_ABORTED', async () => {
    const provider = createProvider()
    const controller = new AbortController()
    controller.abort()
    const error = await catchError(provider.fetch({ url: 'https://example.com/page' }, controller.signal))
    expect(error.code).toBe('WEB_ABORTED')
  })
})

describe('fetch 面额度账本上报', () => {
  it('空正文探测失败不入账', async () => {
    const events: Array<[string, 'success' | 'rate-limited' | 'quota']> = []
    const empty = okEngine('empty', '   ')
    const provider = createProvider({
      engines: [empty.engine],
      onLaneOutcome: (engineId, kind) => events.push([engineId, kind]),
    })

    await catchError(provider.fetch({ url: URL }))

    expect(events).toEqual([])
  })

  it('多路整理路的成功与限流结局都上报', async () => {
    const events: Array<[string, 'success' | 'rate-limited' | 'quota']> = []
    const short = okEngine('short', '# Stub\n\nshort.')
    const good = okEngine('good', body(900))
    const limited = failingEngine('limited', engineFailure('rate-limited'))
    const provider = createProvider({
      engines: [short.engine, good.engine, limited.engine],
      onLaneOutcome: (engineId, kind) => events.push([engineId, kind]),
    })

    await provider.fetch({ url: URL })

    expect(events).toContainEqual(['good', 'success'])
    expect(events).toContainEqual(['limited', 'rate-limited'])
  })

  it('首路探测成功上报 success', async () => {
    const events: Array<[string, 'success' | 'rate-limited' | 'quota']> = []
    const first = okEngine('first', body(900))
    const provider = createProvider({
      engines: [first.engine],
      onLaneOutcome: (engineId, kind) => events.push([engineId, kind]),
    })

    await provider.fetch({ url: URL })

    expect(events).toEqual([['first', 'success']])
  })

  it('quota 失败上报 quota', async () => {
    const events: Array<[string, 'success' | 'rate-limited' | 'quota']> = []
    const failed = failingEngine('paid', engineFailure('quota'))
    const provider = createProvider({
      engines: [failed.engine],
      onLaneOutcome: (engineId, kind) => events.push([engineId, kind]),
    })

    await catchError(provider.fetch({ url: URL }))

    expect(events).toEqual([['paid', 'quota']])
  })
})

describe('能力适用性路由（fetchApplicable）', () => {
  const QUESTION_URL = 'https://www.zhihu.com/question/123'
  /** 夹具逐字取自官方文档 https://developer.zhihu.com/docs?key=question_answers 的响应示例。 */
  const QUESTION_ANSWERS_RESPONSE = {
    Code: 0,
    Message: 'success',
    Data: {
      Items: [
        {
          ContentType: 'answer',
          ContentToken: '456',
          Url: 'https://www.zhihu.com/question/123/answer/456',
          Summary: '这是一段回答摘要……',
        },
      ],
      Paging: { IsEnd: true, Totals: 1 },
    },
  }

  /** 真实知乎适配器 + 通用替身引擎：验证 provider 的专属路/通用路分派。 */
  function createRoutingProvider(
    responses: readonly Response[],
    generic: { engine: Engine; counting: Counting },
  ): { provider: AggregatedFetchProvider; calls: RecordedCall[] } {
    const { fetcher, calls } = stubFetch(responses)
    return {
      calls,
      provider: createProvider({
        engines: [generic.engine, createZhihuEngine({ fetcher })],
        buildContext: engineBuildContext,
        resolveControls: () => ({}),
      }),
    }
  }

  it('问题 URL 走 question_answers 专属路，通用提取零派发', async () => {
    const generic = okEngine('anysearch', body(900), { url: QUESTION_URL })
    const { provider, calls } = createRoutingProvider([jsonResponse(QUESTION_ANSWERS_RESPONSE)], generic)

    const output = await provider.fetch({ url: QUESTION_URL })

    expect(calls).toHaveLength(1)
    expect(calls[0]!.url.pathname).toBe('/api/v1/content/question_answers')
    expect(calls[0]!.url.searchParams.get('QuestionUrl')).toBe(QUESTION_URL)
    expect(calls[0]!.url.searchParams.get('Limit')).toBe('20')
    expect(generic.counting.calls).toBe(0)
    expect(output.body.content).toContain('这是一段回答摘要……')
    expect(output.body.content).toContain('https://www.zhihu.com/question/123/answer/456')
  })

  it('非问题 URL：知乎不被派发、无 invalid 污染，通用路照常接管', async () => {
    const columnUrl = 'https://www.zhihu.com/column/c_1'
    const generic = okEngine('anysearch', body(900), { url: columnUrl })
    const { provider, calls } = createRoutingProvider([], generic)

    const output = await provider.fetch({ url: columnUrl })

    expect(calls).toHaveLength(0)
    expect(generic.counting.calls).toBe(1)
    expect(output.body.content).toContain('A documented sentence')
    expect(output.body.content).not.toContain('WEB_INVALID_URL')
  })

  it('问题 URL 但知乎路失败（HTTP 500）→ 降级通用路成功', async () => {
    const generic = okEngine('anysearch', body(900), { url: QUESTION_URL })
    const { provider, calls } = createRoutingProvider(
      [jsonResponse({ Code: 90001, Message: '内部错误' }, 500)],
      generic,
    )

    const output = await provider.fetch({ url: QUESTION_URL })

    expect(calls).toHaveLength(1)
    expect(generic.counting.calls).toBe(1)
    expect(output.body.content).toContain('A documented sentence')
  })

})
