// 动态提取编排离线单测——注入假引擎，不触网、不启动真实服务。
// 用例移植自 v0.2 test/fetch-aggregate.test.ts 的核心行为断言，
// 并按 v0.3 的统一失败模型（EngineFailure）与显式 OpContext 重写。

import { describe, expect, it } from 'vitest'
import { WebError } from '@deepseek-ai/dsh-web'
import type { WebFetchResult } from '@deepseek-ai/dsh-web'
import type { Engine, EngineContext, EngineFetchOutcome, EngineManifest, EngineResult } from '../../src/engines/contract.js'
import { engineFailure, type EngineFailure } from '../../src/engines/failure.js'
import { CircuitBreaker } from '../../src/support/breaker.js'
import { OpContext, type RuntimeControls } from '../../src/support/budget.js'
import {
  aggregateDynamicFetch,
  DEFAULT_FETCH_ENGINE_TIMEOUT_MS,
  type AggregateDynamicFetchOptions,
  type BuildEngineContext,
} from '../../src/fetch/aggregate.js'
import type { FetchCandidate } from '../../src/fetch/types.js'

const REQUEST_URL = 'https://blog.example.com/posts/example-domain-guide'

function manifest(id: string): EngineManifest {
  return { id, label: id, capabilities: ['fetch'], auth: 'anonymous', endpoints: {} }
}

function result(content: string, extra: Partial<WebFetchResult> = {}): WebFetchResult {
  return { url: REQUEST_URL, statusCode: 200, body: { kind: 'text', content }, truncated: false, ...extra }
}

function body(chars: number, title = '# Example Domain Guide'): string {
  const paragraph = 'This domain is for use in illustrative examples in documents. '
  return `${title}\n\n${paragraph.repeat(Math.ceil(chars / paragraph.length))}`
}

interface Counting {
  calls: number
}

function okEngine(id: string, content: string, extra: Partial<WebFetchResult> = {}): { engine: Engine; counting: Counting } {
  const counting: Counting = { calls: 0 }
  return {
    counting,
    engine: {
      manifest: manifest(id),
      async fetch(): Promise<EngineResult<EngineFetchOutcome>> {
        counting.calls += 1
        return { ok: true, outcome: result(content, extra) }
      },
    },
  }
}

function failingEngine(id: string, failure: EngineFailure): { engine: Engine; counting: Counting } {
  const counting: Counting = { calls: 0 }
  return {
    counting,
    engine: {
      manifest: manifest(id),
      async fetch(): Promise<EngineResult<EngineFetchOutcome>> {
        counting.calls += 1
        return { ok: false, failure }
      },
    },
  }
}

function hangingEngine(id: string): { engine: Engine; counting: Counting } {
  const counting: Counting = { calls: 0 }
  return {
    counting,
    engine: {
      manifest: manifest(id),
      fetch(): Promise<EngineResult<EngineFetchOutcome>> {
        counting.calls += 1
        return new Promise(() => undefined)
      },
    },
  }
}

function throwingEngine(id: string, error: unknown): { engine: Engine; counting: Counting } {
  const counting: Counting = { calls: 0 }
  return {
    counting,
    engine: {
      manifest: manifest(id),
      async fetch(): Promise<EngineResult<EngineFetchOutcome>> {
        counting.calls += 1
        throw error
      },
    },
  }
}

const buildContext: BuildEngineContext = async (engineManifest: EngineManifest, op: OpContext, lane) => ({
  signal: lane.signal,
  deadline: lane.deadline,
  endpoint: `https://${engineManifest.id}.test/extract`,
  countRequest: () => op.countRequest(),
})

function makeOp(controls: RuntimeControls = { preset: 'multi', mode: 'organize' }, caller?: AbortSignal): OpContext {
  return new OpContext(controls, caller ?? new AbortController().signal, caller, 32)
}

function run(
  engines: readonly Engine[],
  overrides: Partial<AggregateDynamicFetchOptions> = {},
): Promise<WebFetchResult> {
  return aggregateDynamicFetch({
    url: REQUEST_URL,
    engines,
    op: makeOp(),
    buildContext,
    settleEarly: false,
    ...overrides,
  })
}

async function catchError(promise: Promise<unknown>): Promise<WebError> {
  const error = await promise.then(
    () => { throw new Error('expected the promise to reject, but it resolved') },
    (caught: unknown) => caught,
  )
  expect(error).toBeInstanceOf(WebError)
  return error as WebError
}

describe('aggregateDynamicFetch 编排', () => {
  it('多路并发派发并整理成一份带来源说明的正文', async () => {
    const first = okEngine('firecrawl', body(900))
    const second = okEngine('tavily', body(900))
    const third = okEngine('anysearch', body(900))
    const output = await run([first.engine, second.engine, third.engine])
    expect([first.counting.calls, second.counting.calls, third.counting.calls]).toEqual([1, 1, 1])
    expect(output.body.content).toContain('提取来源与处理说明')
    expect(output.body.content).toContain('This domain is for use')
    expect(output.truncated).toBe(false)
  })

  it('空正文候选无效；全部为空视为全败', async () => {
    const empty = okEngine('firecrawl', '   \n  ')
    const real = okEngine('tavily', body(600))
    const output = await run([empty.engine, real.engine])
    expect(output.body.content).toContain('This domain is for use')
    expect(empty.counting.calls).toBe(1)

    const error = await catchError(run([okEngine('a', '').engine, okEngine('b', '  ').engine]))
    expect(error.code).toBe('WEB_PROVIDER_ERROR')
    expect(error.message.toLowerCase()).toContain('empty')
  })

  it('全败取最特异 WEB_* 码（invalid 胜过 timeout / provider-error）', async () => {
    const error = await catchError(run([
      failingEngine('target', engineFailure('invalid', { detail: 'bad url' })).engine,
      failingEngine('slow', engineFailure('timeout')).engine,
      failingEngine('server', engineFailure('provider-error', { statusCode: 500 })).engine,
    ]))
    expect(error.code).toBe('WEB_INVALID_URL')
    expect(error.message).toContain('target')
  })

  it('目标站拒绝与引擎不可用分组，最特异码为 WEB_BLOCKED_URL', async () => {
    const error = await catchError(run([
      failingEngine('target', engineFailure('target-status', { statusCode: 404, detail: 'not found' })).engine,
      failingEngine('provider', engineFailure('provider-error', { statusCode: 502 })).engine,
    ]))
    expect(error.code).toBe('WEB_BLOCKED_URL')
    const [rejected, unavailable] = error.message.split('|')
    expect(rejected).toContain('目标被拒绝 target-rejected')
    expect(rejected).toContain('target')
    expect(rejected).not.toContain('provider')
    expect(unavailable).toContain('引擎不可用 engine-unavailable')
    expect(unavailable).toContain('provider')
  })

  it('目标站 404 → target-rejected；AnySearch 422 提取失败 → engine-unavailable', async () => {
    const error = await catchError(run([
      failingEngine('target', engineFailure('target-status', { statusCode: 404, detail: 'not found' })).engine,
      failingEngine('anysearch', engineFailure('target-status', { statusCode: 422, detail: 'extract_failed' })).engine,
    ]))
    expect(error.code).toBe('WEB_BLOCKED_URL')
    const [rejected, unavailable] = error.message.split('|')
    expect(rejected).toContain('目标被拒绝 target-rejected')
    expect(rejected).toContain('target')
    expect(rejected).not.toContain('anysearch')
    expect(unavailable).toContain('引擎不可用 engine-unavailable')
    expect(unavailable).toContain('anysearch')
    expect(unavailable).toContain('WEB_PROVIDER_ERROR')
  })

  it('422 编码的 rank 不压过真实 timeout / invalid', async () => {
    const timeoutError = await catchError(run([
      failingEngine('anysearch', engineFailure('target-status', { statusCode: 422, detail: 'extract_failed' })).engine,
      failingEngine('slow', engineFailure('timeout')).engine,
    ]))
    expect(timeoutError.code).toBe('WEB_FETCH_TIMEOUT')

    const invalidError = await catchError(run([
      failingEngine('anysearch', engineFailure('target-status', { statusCode: 422, detail: 'extract_failed' })).engine,
      failingEngine('bad', engineFailure('invalid', { detail: 'bad url' })).engine,
    ]))
    expect(invalidError.code).toBe('WEB_INVALID_URL')
  })

  it('422 载体 + error_code=extract_target_blocked → 仍归 target-rejected（WEB_BLOCKED_URL）', async () => {
    const error = await catchError(run([
      failingEngine('anysearch', engineFailure('target-status', {
        statusCode: 422,
        detail: 'AnySearch extract 业务错误（error_code=extract_target_blocked, HTTP 422）',
      })).engine,
      failingEngine('provider', engineFailure('provider-error', { statusCode: 502 })).engine,
    ]))
    expect(error.code).toBe('WEB_BLOCKED_URL')
    const [rejected, unavailable] = error.message.split('|')
    expect(rejected).toContain('目标被拒绝 target-rejected')
    expect(rejected).toContain('anysearch')
    expect(unavailable).toContain('引擎不可用 engine-unavailable')
    expect(unavailable).toContain('provider')
  })

  it('422 载体 + 大写 error_code=EXTRACT_TARGET_BLOCKED → 同样归 WEB_BLOCKED_URL（业务码比对大小写不敏感）', async () => {
    const error = await catchError(run([
      failingEngine('anysearch', engineFailure('target-status', {
        statusCode: 422,
        detail: 'AnySearch extract 业务错误（error_code=EXTRACT_TARGET_BLOCKED, HTTP 422）',
      })).engine,
    ]))
    expect(error.code).toBe('WEB_BLOCKED_URL')
  })

  it('引擎违约上抛 WebError(WEB_BLOCKED_URL) → 保留原始码，不降级为 network', async () => {
    const error = await catchError(run([
      throwingEngine('rogue', new WebError('target blocked by engine', 'WEB_BLOCKED_URL')).engine,
    ]))
    expect(error.code).toBe('WEB_BLOCKED_URL')
    expect(error.message).toContain('rogue')
  })

  it('熔断引擎零派发，其余照常整理', async () => {
    const breaker = new CircuitBreaker()
    breaker.recordSignal('firecrawl', { kind: 'insufficient-credits' })
    const broken = okEngine('firecrawl', 'should not be called')
    const real = okEngine('tavily', body(600))
    const output = await run([broken.engine, real.engine], { breaker })
    expect(broken.counting.calls).toBe(0)
    expect(real.counting.calls).toBe(1)
    expect(output.body.content).toContain('This domain is for use')
  })

  it('全部熔断 → WEB_PROVIDER_ERROR，零派发', async () => {
    const breaker = new CircuitBreaker()
    breaker.recordSignal('a', { kind: 'quota-exhausted' })
    breaker.recordSignal('b', { kind: 'insufficient-credits' })
    const first = okEngine('a', 'x')
    const second = okEngine('b', 'y')
    const error = await catchError(run([first.engine, second.engine], { breaker }))
    expect(error.code).toBe('WEB_PROVIDER_ERROR')
    expect([first.counting.calls, second.counting.calls]).toEqual([0, 0])
  })

  it('失败路把统一失败模型投影成熔断信号（rate-limited → 冷却）', async () => {
    const breaker = new CircuitBreaker()
    const limited = failingEngine('limited', engineFailure('rate-limited', { retryAfterMs: 5_000 }))
    const real = okEngine('real', body(600))
    await run([limited.engine, real.engine], { breaker })
    expect(breaker.status('limited')).toMatchObject({ broken: true, reason: 'rate-limit' })
  })

  it('单路超时被丢弃，其余正常整理', async () => {
    const hung = hangingEngine('tavily')
    const real = okEngine('firecrawl', body(600))
    const output = await run([hung.engine, real.engine], { perEngineTimeoutMs: 25 })
    expect(hung.counting.calls).toBe(1)
    expect(real.counting.calls).toBe(1)
    expect(output.body.content).toContain('This domain is for use')
  })

  it('超过 deadline 后才返回的成功结果被丢弃（迟到不等于完成）', async () => {
    let release!: () => void
    const gate = new Promise<void>(resolve => { release = resolve })
    const lateCounting: Counting = { calls: 0 }
    const late: Engine = {
      manifest: manifest('late'),
      async fetch(): Promise<EngineResult<EngineFetchOutcome>> {
        lateCounting.calls += 1
        await gate
        return { ok: true, outcome: result('# Late Result\n\nLATE-MARKER ' + body(600)) }
      },
    }
    const survivor = okEngine('real', body(600))
    const pending = run([late, survivor.engine], { perEngineTimeoutMs: 25 })
    await new Promise(resolve => setTimeout(resolve, 50))
    release()
    const output = await pending
    expect(lateCounting.calls).toBe(1)
    expect(output.body.content).toContain('This domain is for use')
    expect(output.body.content).not.toContain('LATE-MARKER')
    expect(output.truncated).toBe(true)
  })

  it('探测种子的结果并入整理，且对应引擎不重复派发', async () => {
    const skipped = okEngine('probe', 'must not be called')
    const real = okEngine('other', body(600))
    const seeds: FetchCandidate[] = [{ engineId: 'probe', result: result('# Probe\n\nseeded body from probe') }]
    const output = await run([skipped.engine, real.engine], { seeds, skipEngineIds: ['probe'] })
    expect(skipped.counting.calls).toBe(0)
    expect(real.counting.calls).toBe(1)
    expect(output.body.content).toContain('seeded body from probe')
  })

  it('目标站非 2xx 但有正文 → 经聚合器返回结果，statusCode 原样', async () => {
    const output = await run([
      okEngine('firecrawl', '# Example Domain Guide\n\n404 page still has a body', { statusCode: 404 }).engine,
      failingEngine('tavily', engineFailure('provider-error')).engine,
    ])
    expect(output.statusCode).toBe(404)
    expect(output.body.content).toContain('404 page still has a body')
  })

  it('truncated 逐层传播：任一候选被截断则最终为 true', async () => {
    const output = await run([okEngine('firecrawl', body(600), { truncated: true }).engine])
    expect(output.truncated).toBe(true)
  })

  it('外层取消在派发前 → WEB_ABORTED，零派发', async () => {
    const controller = new AbortController()
    const op = makeOp({ preset: 'multi' }, controller.signal)
    controller.abort()
    const engine = okEngine('firecrawl', body(600))
    const error = await catchError(run([engine.engine], { op }))
    expect(error.code).toBe('WEB_ABORTED')
    expect(engine.counting.calls).toBe(0)
  })

  it('飞行中取消 → WEB_ABORTED', async () => {
    const controller = new AbortController()
    const pending = run(
      [hangingEngine('a').engine, hangingEngine('b').engine],
      { op: makeOp({ preset: 'multi' }, controller.signal), perEngineTimeoutMs: 60_000 },
    )
    setTimeout(() => controller.abort(), 10)
    const error = await catchError(pending)
    expect(error.code).toBe('WEB_ABORTED')
  })

  it('总限时到 → 返回幸存者并标记 truncated（限时不是取消）', async () => {
    const controller = new AbortController()
    const op = new OpContext({ preset: 'multi' }, controller.signal, undefined, 32)
    const survivor = okEngine('survivor', body(900))
    const pending = run(
      [survivor.engine, hangingEngine('slow').engine],
      { op, perEngineTimeoutMs: 60_000 },
    )
    setTimeout(() => controller.abort(), 10)
    const output = await pending
    expect(output.body.content).toContain('This domain is for use')
    expect(output.truncated).toBe(true)
  })

  it('派发前总限时已到期 → WEB_FETCH_TIMEOUT，而不是 WEB_ABORTED', async () => {
    const controller = new AbortController()
    controller.abort()
    const op = new OpContext({ preset: 'multi' }, controller.signal, undefined, 32)
    const late = hangingEngine('late')
    const error = await catchError(run([late.engine], { op }))
    expect(error.code).toBe('WEB_FETCH_TIMEOUT')
  })

  it('SettlementWindow 提前结算 → truncated=true 且说明行出现', async () => {
    const shared = body(2_000)
    const output = await run([
      okEngine('a', shared).engine,
      okEngine('b', shared).engine,
      okEngine('c', shared).engine,
      hangingEngine('slow').engine,
    ], { settleEarly: true })
    expect(output.truncated).toBe(true)
    expect(output.body.content).toContain('提前结束等待')
  })

  it('没有引擎也没有种子 → WEB_PROVIDER_ERROR', async () => {
    const error = await catchError(run([]))
    expect(error.code).toBe('WEB_PROVIDER_ERROR')
    expect(error.message).toContain('no extraction engines')
  })

  it('默认单路 deadline 为 45s（v0.2 预算保留）', () => {
    expect(DEFAULT_FETCH_ENGINE_TIMEOUT_MS).toBe(45_000)
  })
})
