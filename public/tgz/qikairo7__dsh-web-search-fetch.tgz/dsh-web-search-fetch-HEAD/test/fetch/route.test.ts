// URL 感知分流纯函数单测——离线，无网络。
// 覆盖 classifyFetchRoute 的地址分流规则。

import { describe, expect, it } from 'vitest'
import { classifyFetchRoute, DEFAULT_STATIC_EXTENSIONS } from '../../src/fetch/route.js'

describe('classifyFetchRoute 静态判定', () => {
  it('明确静态扩展名 → static（大小写不敏感、忽略查询串与锚点）', () => {
    expect(classifyFetchRoute('https://example.com/report.csv?download=1')).toBe('static')
    expect(classifyFetchRoute('https://example.com/NOTES.TXT')).toBe('static')
    expect(classifyFetchRoute('https://example.com/page.md')).toBe('static')
    expect(classifyFetchRoute('https://example.com/feed.xml#top')).toBe('static')
    expect(classifyFetchRoute('https://example.com/data.json')).toBe('static')
    expect(classifyFetchRoute('https://example.com/rows.tsv')).toBe('static')
    expect(DEFAULT_STATIC_EXTENSIONS).toContain('yaml')
  })

  it('PDF、.html、未知扩展、无扩展、目录路径 → dynamic', () => {
    expect(classifyFetchRoute('https://example.com/paper.pdf')).toBe('dynamic')
    expect(classifyFetchRoute('https://example.com/index.html')).toBe('dynamic')
    expect(classifyFetchRoute('https://example.com/api/v1/items')).toBe('dynamic')
    expect(classifyFetchRoute('https://example.com/')).toBe('dynamic')
    expect(classifyFetchRoute('https://example.com/blog/')).toBe('dynamic')
    expect(classifyFetchRoute('https://example.com/archive.tar.gz')).toBe('dynamic')
  })

  it('配置的静态域名画像：主机相等或点界子域命中', () => {
    const options = { staticDomains: ['docs.example.com'] }
    expect(classifyFetchRoute('https://docs.example.com/a/b', options)).toBe('static')
    expect(classifyFetchRoute('https://cdn.docs.example.com/a/b', options)).toBe('static')
    expect(classifyFetchRoute('https://example.com/a/b', options)).toBe('dynamic')
    // 后缀边界：必须以点分隔，`evildocs.example.com` 不命中 `docs.example.com`。
    expect(classifyFetchRoute('https://evildocs.example.com/a/b', options)).toBe('dynamic')
  })

  it('静态域名画像对带扩展名的路径同样生效（域名优先）', () => {
    const options = { staticDomains: ['static.example.net'] }
    expect(classifyFetchRoute('https://static.example.net/anything.pdf', options)).toBe('static')
  })

  it('非 http(s) 或不可解析 URL → static（交由 HTTP 路给出 WEB_INVALID_URL）', () => {
    expect(classifyFetchRoute('ftp://example.com/file')).toBe('static')
    expect(classifyFetchRoute('not a url')).toBe('static')
  })

  it('分流开关关闭 → 一律 static', () => {
    expect(classifyFetchRoute('https://example.com/api/v1/items', { enabled: false })).toBe('static')
  })

  it('staticExtensions 覆盖默认表，条目可带点、大小写混杂', () => {
    expect(classifyFetchRoute('https://example.com/paper.pdf', { staticExtensions: ['pdf'] })).toBe('static')
    expect(classifyFetchRoute('https://example.com/notes.txt', { staticExtensions: ['pdf'] })).toBe('dynamic')
    expect(classifyFetchRoute('https://example.com/a.CSV', { staticExtensions: ['.csv'] })).toBe('static')
  })
})
