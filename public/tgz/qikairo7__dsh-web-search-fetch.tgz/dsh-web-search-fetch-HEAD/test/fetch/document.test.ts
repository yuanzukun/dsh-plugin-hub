// 正文整理层离线单测 —— 不触网、不启动进程或真实服务。
// 覆盖 markdown / splitBlocks / cleanBlocks / challengeBlocks / paragraphChars，
// 以及 organizeDocuments 的章节去重、变体保留与补充片段。

import { describe, expect, it } from 'vitest'
import type { WebFetchResult } from '@deepseek-ai/dsh-web'
import {
  challengeBlocks,
  cleanBlocks,
  compactTable,
  markdown,
  paragraphChars,
  splitBlocks,
  structured,
} from '../../src/fetch/document/blocks.js'
import { organizeDocuments } from '../../src/fetch/document/organize.js'

const url = 'https://example.com/guide'

function result(content: string, extra: Partial<WebFetchResult> = {}): WebFetchResult {
  return { url, statusCode: 200, body: { kind: 'text', content }, truncated: false, ...extra }
}

function organize(...bodies: string[]): WebFetchResult {
  return organizeDocuments(url, bodies.map((body, index) => ({ engineId: `service${index}`, result: result(body) })))
}

describe('markdown', () => {
  it('text 只统一换行符', () => {
    expect(markdown('a\r\nb\rc', 'text')).toBe('a\nb\nc')
  })

  it('HTML 转 Markdown 不执行脚本并保留表格', () => {
    const html = '<h1>Guide</h1><p>Text</p><script>bad()</script><table><tr><th>A</th></tr><tr><td>100</td></tr></table>'
    const output = markdown(html, 'html')
    expect(output).toContain('# Guide')
    expect(output).toContain('100')
    expect(output).not.toContain('bad()')
  })
})

describe('splitBlocks', () => {
  it('识别 heading/paragraph/code/list/quote/table', () => {
    const kinds = splitBlocks('# Title\n\nparagraph\n\n```ts\nconst n = 1;\n```\n\n- item\n\n> quote\n\n| A | B |\n| --- | --- |\n| 1 | 2 |').map(block => block.kind)
    expect(kinds).toEqual(['heading', 'paragraph', 'code', 'list', 'quote', 'table'])
  })

  it('围栏代码里的标题不切分章节', () => {
    expect(splitBlocks('# Title\n\n~~~txt\n## literal\n~~~').map(block => block.kind)).toEqual(['heading', 'code'])
  })

  it('段落 key 归并空白与强调标记；标题 key 去掉锚点链接', () => {
    const [paragraph] = splitBlocks('A **shared**\nparagraph.')
    expect(paragraph?.key).toBe('paragraph:A shared paragraph.')
    const [heading] = splitBlocks('# Guide [¶](https://example.com/guide#guide)')
    expect(heading?.key).toBe('heading:# Guide')
  })
})

describe('cleanBlocks', () => {
  it('移除导航标题、链接列表与主题控件，保留正文代码', () => {
    const blocks = splitBlocks('### Navigation\n\n- [index](https://docs.test/index)\n- [modules](https://docs.test/modules)\n\nTheme AutoLightDark\n\n# Task groups\n\nAdded in version 3.11.\n\n```py\nprint("Navigation Theme")\n```')
    const cleaned = cleanBlocks(blocks)
    expect(cleaned.some(block => block.text.includes('### Navigation'))).toBe(false)
    expect(cleaned.some(block => block.text === 'Theme AutoLightDark')).toBe(false)
    expect(cleaned.some(block => block.text.includes('Navigation Theme'))).toBe(true)
  })

  it('文章本身以 Navigation 为题或含正文链接时不误删', () => {
    const blocks = splitBlocks('[Specification](https://spec.test/navigation)\n\n# Navigation\n\nNavigation is a meaningful article topic.\n\n- [Reference](https://docs.test/reference)')
    const cleaned = cleanBlocks(blocks)
    expect(cleaned.some(block => block.text === '# Navigation')).toBe(true)
    expect(cleaned.some(block => block.text.includes('[Specification]'))).toBe(true)
    expect(cleaned.some(block => block.text.includes('[Reference]'))).toBe(true)
  })
})

describe('challengeBlocks / paragraphChars / structured', () => {
  it('识别登录与挑战页', () => {
    for (const text of ['Just a moment...', '# 403 Forbidden', 'Access Denied', '请先登录']) {
      expect(challengeBlocks(splitBlocks(text))).toBe(true)
    }
    expect(challengeBlocks(splitBlocks('# Guide\n\nOrdinary body.'))).toBe(false)
  })

  it('只统计普通段落的字符数', () => {
    const blocks = splitBlocks('# Title\n\nOne  two.\n\n```\ncode\n```\n\nThree.')
    expect(paragraphChars(blocks)).toBe('One two. Three.'.length)
  })

  it('结构化正文按 JSON 或 XML 声明识别', () => {
    expect(structured('{"items":[]}')).toBe(true)
    expect(structured('[1,2]')).toBe(true)
    expect(structured('null')).toBe(false)
    expect(structured('<?xml version="1.0"?><rss/>')).toBe(true)
    expect(structured('ordinary prose')).toBe(false)
  })
})

describe('compactTable', () => {
  it('清单表裁剪到前 20 行并明示省略数量', () => {
    const rows = Array.from({ length: 30 }, (_, index) => `| [folder-${index}](https://example.com/tree/${index}) |  |`)
    const table = ['| Name |  |', '| --- | --- |', ...rows].join('\n')
    const compact = compactTable(table)
    expect(compact.omittedRows).toBe(10)
    expect(compact.text).toContain('（表格仅保留前 20 行，另有 10 行未显示）')
    expect(compact.text).not.toContain('folder-29')
  })

  it('含说明文字的数据表不裁剪', () => {
    const rows = Array.from({ length: 30 }, (_, index) => `| Release ${index} | Notes for release ${index} are described in prose here. |`)
    const table = ['| Version | Notes |', '| --- | --- |', ...rows].join('\n')
    expect(compactTable(table)).toEqual({ text: table, omittedRows: 0 })
  })
})

describe('organizeDocuments 章节去重与变体保留', () => {
  it('互补提取合并：共同段落只出现一次，独有表格保留', () => {
    const output = organizeDocuments(url, [
      { engineId: 'firecrawl', result: result('# Guide\n\nShared introduction.\n\n## Details\n\nThe explanation is retained.') },
      { engineId: 'anysearch', result: result('# Guide\n\nShared introduction.\n\n## Details\n\n| Item | Value |\n| --- | --- |\n| A | 100 |') },
    ])
    expect(output.body.content).toContain('The explanation is retained.')
    expect(output.body.content).toContain('| A | 100 |')
    expect(output.body.content.match(/Shared introduction\./g)).toHaveLength(1)
    expect(output.body.content).toContain('firecrawl')
    expect(output.body.content).toContain('anysearch')
  })

  it('同一原文内重复的警告保留，跨来源去重并标注双来源', () => {
    const content = organize('# Guide\n\nWarning: stop.\n\nMiddle.\n\nWarning: stop.', '# Guide\n\nWarning: stop.\n\nMiddle.\n\nWarning: stop.').body.content
    expect(content.match(/Warning: stop\./g)).toHaveLength(2)
    expect(content).toContain('F1:B2, F2:B2')
  })

  it('冲突价格作为来源变体保留，不选择也不平均', () => {
    const content = organize('# Guide\n\nPrice: 100 yuan.\n\nSame end.', '# Guide\n\nPrice: 120 yuan.\n\nSame end.').body.content
    expect(content).toContain('## 文本差异')
    expect(content).toContain('Price: 100 yuan.')
    expect(content).toContain('Price: 120 yuan.')
    expect(content).not.toContain('Price: 110')
  })

  it('完全重排的提取作为差异保留，即使没有独有段落', () => {
    const content = organize('# Guide\n\nFirst.\n\nSecond.', '# Guide\n\nSecond.\n\nFirst.').body.content
    expect(content).toContain('段落顺序不同')
    const appendix = content.split('## 文本差异')[1]!
    expect(appendix.indexOf('Second.')).toBeLessThan(appendix.indexOf('First.'))
    expect(appendix).toContain('F2:B2')
  })

  it('段落空白归并去重，但不同语言版本不被合并', () => {
    const whitespace = organize('# Guide\n\nA   shared\nparagraph.', '# Guide\n\nA shared paragraph.').body.content
    expect(whitespace).toContain('F1:B2, F2:B2')
    const bilingual = organize('# Guide\n\n' + '这是同一网页的中文版本，保留原文以便读者核对。'.repeat(4), '# Guide\n\n' + 'This is the English version of the same page for comparison. '.repeat(4)).body.content
    expect(bilingual).toContain('语言不同')
    expect(bilingual).toContain('English version')
    expect(bilingual).toContain('中文版本')
  })

  it('标题不同时进入补充片段而不是主正文', () => {
    const content = organize('# Guide 1\n\nCommon.', '# Guide 2\n\nCommon.\n\nOther version.').body.content
    expect(content).toContain('## 补充片段')
    expect(content).toContain('标题或版本不同')
    expect(content).toContain('Other version.')
  })

  it('同名章节合并，独有章节按原顺序进入补充片段', () => {
    const shared = 'Shared introduction paragraph for both extracts.'
    const main = 'Main body sentence with enough content. '.repeat(30)
    const content = organize(
      `# Guide\n\n${shared}\n\n${main}\n\n## Details\n\nMain detail.`,
      `# Guide\n\n${shared}\n\n## Details\n\nSecond detail.\n\n## Extra\n\nUnique section.`,
    ).body.content
    expect(content).toContain('Main detail.')
    expect(content).toContain('Second detail.')
    expect(content).toContain('## 补充片段')
    expect(content).toContain('独有章节')
    expect(content).toContain('Unique section.')
  })
})

describe('organizeDocuments 边界与 truncated', () => {
  it('结构化 JSON 原样返回，超出预算则明确报错', () => {
    const candidate = { engineId: 'api', result: result('{"cursor":"next","items":[]}') }
    expect(organizeDocuments(url, [candidate])).toEqual(candidate.result)
    expect(() => organizeDocuments(url, [candidate], 5)).toThrow('structured response too large')
  })

  it('只有挑战页的候选集被拒绝', () => {
    expect(() => organize('Just a moment...')).toThrow('没有可整理')
  })

  it('非 2xx 正文不混入成功文档；全部失败时保留可读错误正文', () => {
    const output = organizeDocuments(url, [
      { engineId: 'error', result: result('# Guide\n\nNot found', { statusCode: 404 }) },
      { engineId: 'ok', result: result('# Guide\n\nActual content') },
    ])
    expect(output.statusCode).toBe(200)
    expect(output.body.content).toContain('非成功状态')
    const failed = { engineId: 'error', result: result('Readable error', { statusCode: 404 }) }
    expect(organizeDocuments(url, [failed]).statusCode).toBe(404)
    expect(organizeDocuments(url, [failed]).body.content).toContain('Readable error')
  })

  it('超预算时省略完整代码块并传播 truncated，不返回破损围栏', () => {
    const candidate = { engineId: 'a', result: result('# Guide\n\n```ts\n' + 'x'.repeat(2000) + '\n```\n\nLast.') }
    const output = organizeDocuments(url, [candidate], 1000)
    expect(output.body.content).not.toContain('```')
    expect(output.body.content).toContain('已省略')
    expect(output.body.content.length).toBeLessThanOrEqual(1000)
    expect(output.truncated).toBe(true)
  })
})
