// 择优与质量信号纯函数单测——离线，无网络。
// 用例移植自 v0.2 test/fetch-aggregate.test.ts 的质量信号段，并按 v0.3 的默认权重（全 2）调整。

import { describe, expect, it } from 'vitest'
import type { WebFetchResult } from '@deepseek-ai/dsh-web'
import {
  bodyFingerprint,
  DEFAULT_ENGINE_WEIGHT,
  extractBodyTitle,
  extractUrlSlug,
  isUsableCandidate,
  scoreCandidate,
  selectBestCandidate,
  titleSimilarity,
} from '../../src/fetch/select-best.js'

const REQUEST_URL = 'https://blog.example.com/posts/example-domain-guide'

function textResult(content: string, statusCode = 200, url = REQUEST_URL): WebFetchResult {
  return { url, statusCode, body: { kind: 'text', content }, truncated: false }
}

describe('候选有效性与质量分', () => {
  it('空正文 / 纯空白正文视为无效', () => {
    expect(isUsableCandidate(textResult(''))).toBe(false)
    expect(isUsableCandidate(textResult('   \n\t  '))).toBe(false)
    expect(isUsableCandidate(textResult('non-empty'))).toBe(true)
  })

  it('scoreCandidate：默认权重全 2，加上长度、密度与标题匹配分', () => {
    const url = 'https://example.com/docs/example-domain'
    const content = '# Example Domain\n\nClean prose body.'
    const scored = scoreCandidate('firecrawl', textResult(content), url)
    expect(DEFAULT_ENGINE_WEIGHT).toBe(2)
    expect(scored.engineId).toBe('firecrawl')
    expect(scored.breakdown.weight).toBe(2)
    expect(scored.breakdown.titleMatch).toBeCloseTo(1.5, 10)
    expect(scored.score).toBeCloseTo(
      scored.breakdown.weight
        + scored.breakdown.length
        + scored.breakdown.density
        + scored.breakdown.titleMatch,
      10,
    )
  })

  it('注入权重表覆盖默认值（v0.2 的 firecrawl:3 由装配层提供，不在编排层硬编码）', () => {
    const scored = scoreCandidate('firecrawl', textResult('body'), REQUEST_URL, { firecrawl: 3 })
    expect(scored.breakdown.weight).toBe(3)
  })

  it('长度分封顶：更长的正文得分更高但不超过上限', () => {
    const short = scoreCandidate('anysearch', textResult('x'.repeat(100)), REQUEST_URL)
    const long = scoreCandidate('anysearch', textResult('x'.repeat(10_000)), REQUEST_URL)
    expect(long.breakdown.length).toBeGreaterThan(short.breakdown.length)
    expect(long.breakdown.length).toBeLessThanOrEqual(2)
  })

  it('标题匹配分：slug 词元命中正文标题得分更高', () => {
    const matched = scoreCandidate('anysearch', textResult('# Example Domain Guide\n\nbody'), REQUEST_URL)
    const unmatched = scoreCandidate('anysearch', textResult('# 完全无关\n\nbody'), REQUEST_URL)
    expect(matched.breakdown.titleMatch).toBeGreaterThan(unmatched.breakdown.titleMatch)
  })

  it('未知引擎 id 退化为默认权重 2', () => {
    const scored = scoreCandidate('mystery-engine', textResult('body'), REQUEST_URL)
    expect(scored.breakdown.weight).toBe(2)
  })
})

describe('selectBestCandidate', () => {
  it('取最高分；平手时先到先得；空正文不参与', () => {
    const url = 'https://example.com/docs/example-domain'
    const candidates = [
      { engineId: 'firecrawl', result: textResult('short', 200, url) },
      { engineId: 'tavily', result: textResult('# Example Domain\n\n' + 'long body '.repeat(200), 200, url) },
      { engineId: 'empty', result: textResult('   ', 200, url) },
    ]
    const selection = selectBestCandidate(url, candidates, {})
    expect(selection.best?.engineId).toBe('tavily')
    expect(selection.scored).toHaveLength(2)

    const tie = selectBestCandidate(url, [
      { engineId: 'a', result: textResult('# Same\n\nidentical', 200, url) },
      { engineId: 'b', result: textResult('# Same\n\nidentical', 200, url) },
    ])
    expect(tie.best?.engineId).toBe('a')
  })

  it('全部空正文时没有最佳候选', () => {
    expect(selectBestCandidate(REQUEST_URL, [
      { engineId: 'a', result: textResult('') },
      { engineId: 'b', result: textResult('  ') },
    ]).best).toBeUndefined()
  })
})

describe('标题相似度与正文哈希（一致性信号素材）', () => {
  it('extractUrlSlug：末段去扩展、分隔符归一、小写', () => {
    expect(extractUrlSlug('https://example.com/blog/Hello_World-page.html?x=1')).toBe('hello world page')
    expect(extractUrlSlug('https://example.com/')).toBe('')
    expect(extractUrlSlug('nonsense')).toBe('')
  })

  it('extractBodyTitle：优先取前 500 字内的第一个 markdown 标题，否则首个非空行', () => {
    expect(extractBodyTitle('some paragraph\n\n# The Real Title\n\nmore')).toBe('The Real Title')
    expect(extractBodyTitle('plain first line\nsecond line')).toBe('plain first line')
    expect(extractBodyTitle('   \n\n  ')).toBe('')
  })

  it('titleSimilarity：Jaccard 词元相似度，空输入得 0', () => {
    expect(titleSimilarity('Example Domain', 'example domain')).toBe(1)
    expect(titleSimilarity('example domain', 'Example Domain — Full Guide')).toBeCloseTo(0.5, 10)
    expect(titleSimilarity('alpha', 'beta')).toBe(0)
    expect(titleSimilarity('', 'anything')).toBe(0)
  })

  it('bodyFingerprint：sha1 十六进制前 8 位，内容不同则哈希不同', () => {
    const hash = bodyFingerprint('same body')
    expect(hash).toMatch(/^[0-9a-f]{8}$/)
    expect(bodyFingerprint('same body')).toBe(hash)
    expect(bodyFingerprint('other body')).not.toBe(hash)
  })
})
