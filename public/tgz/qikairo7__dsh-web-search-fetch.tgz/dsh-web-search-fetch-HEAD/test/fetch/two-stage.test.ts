// 两段式探测纯函数单测——离线，无网络。
// 覆盖两段式提取的 probeVerdict 段。

import { describe, expect, it } from 'vitest'
import type { WebFetchResult } from '@deepseek-ai/dsh-web'
import { probeVerdict, PROBE_MIN_PARAGRAPH_CHARS, sameResource } from '../../src/fetch/two-stage.js'

const url = 'https://example.com/guide'

function page(content: string, extra: Partial<WebFetchResult> = {}): WebFetchResult {
  return { url, statusCode: 200, body: { kind: 'text', content }, truncated: false, ...extra }
}

/** 段落字符数达到 `chars` 的正文。 */
function body(chars: number, title = '# Guide'): string {
  const paragraph = 'A documented sentence with stable content and a concrete explanation. '
  return `${title}\n\n${paragraph.repeat(Math.ceil(chars / paragraph.length))}`
}

describe('probeVerdict', () => {
  it('2xx + 同目标 + 足够段落 → 可直接返回原文', () => {
    expect(probeVerdict(url, page(body(PROBE_MIN_PARAGRAPH_CHARS)))).toEqual({ sufficient: true })
  })

  it('段落不足、非 2xx、目标不同、挑战页都要升级', () => {
    expect(probeVerdict(url, page(body(120)))).toMatchObject({ sufficient: false, reason: 'body-thin' })
    expect(probeVerdict(url, page(body(2000), { statusCode: 404 }))).toMatchObject({ sufficient: false, reason: 'non-2xx' })
    expect(probeVerdict(url, page(body(2000), { url: 'https://other.test/guide' }))).toMatchObject({ sufficient: false, reason: 'target-mismatch' })
    expect(probeVerdict(url, page('Just a moment...'))).toMatchObject({ sufficient: false, reason: 'challenge' })
  })

  it('同资源 HTTPS 升级仍算同一目标', () => {
    expect(probeVerdict('http://example.com/guide', page(body(600), { url: 'https://example.com/guide' }))).toEqual({ sufficient: true })
  })

  it('正文恰好达到阈值仍算足够（边界包含）', () => {
    const exact = `# Guide\n\n${'x'.repeat(PROBE_MIN_PARAGRAPH_CHARS)}`
    expect(probeVerdict(url, page(exact))).toEqual({ sufficient: true })
  })
})

describe('sameResource', () => {
  it('忽略锚点；查询串、路径、端口差异都算不同资源', () => {
    expect(sameResource('https://example.com/a?x=1#top', 'https://example.com/a?x=1')).toBe(true)
    expect(sameResource('https://example.com/a?x=1', 'https://example.com/a?x=2')).toBe(false)
    expect(sameResource('https://example.com/a', 'https://example.com/b')).toBe(false)
    expect(sameResource('https://example.com:8443/a', 'https://example.com/a')).toBe(false)
  })

  it('只有 http → https 升级被接受', () => {
    expect(sameResource('http://example.com/a', 'https://example.com/a')).toBe(true)
    expect(sameResource('https://example.com/a', 'http://example.com/a')).toBe(false)
  })

  it('不可解析时退回字符串相等', () => {
    expect(sameResource('not a url', 'not a url')).toBe(true)
    expect(sameResource('not a url', 'other')).toBe(false)
  })
})
