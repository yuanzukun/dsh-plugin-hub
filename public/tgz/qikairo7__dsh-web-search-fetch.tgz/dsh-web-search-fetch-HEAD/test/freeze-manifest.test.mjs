import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { describe, expect, it } from 'vitest'
import { buildManifest, checkManifest, manifestRemovals, writeManifest } from '../scripts/freeze-manifest.mjs'

describe('freeze manifest', () => {
  it('detects changed, new and missing files', () => {
    const dir = mkdtempSync(join(tmpdir(), 'dsh-freeze-'))
    try {
      writeFileSync(join(dir, 'a.md'), 'a')
      const manifestPath = join(dir, 'manifest.json')
      const exclude = new Set(['manifest.json'])
      writeManifest(dir, manifestPath, exclude, dir)
      expect(checkManifest(dir, manifestPath, exclude, dir)).toEqual([])

      writeFileSync(join(dir, 'a.md'), 'changed')
      expect(checkManifest(dir, manifestPath, exclude, dir)).toContain('a.md: frozen file changed')

      writeFileSync(join(dir, 'b.md'), 'b')
      expect(checkManifest(dir, manifestPath, exclude, dir)).toContain(
        'b.md: new frozen file; run the matching freeze command',
      )
      rmSync(join(dir, 'a.md'))
      expect(checkManifest(dir, manifestPath, exclude, dir)).toContain('a.md: frozen file is missing')
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })

  it('builds a deterministic manifest', () => {
    const dir = mkdtempSync(join(tmpdir(), 'dsh-freeze-'))
    try {
      mkdirSync(join(dir, 'assets'))
      writeFileSync(join(dir, 'assets', 'x.txt'), 'x')
      writeFileSync(join(dir, 'a.md'), 'a')
      expect(buildManifest(dir, new Set(), dir)).toEqual({
        'a.md': expect.any(String),
        'assets/x.txt': expect.any(String),
      })
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })

  it('normalizes line endings for text evidence', () => {
    const dir = mkdtempSync(join(tmpdir(), 'dsh-freeze-'))
    try {
      writeFileSync(join(dir, 'a.md'), 'a\r\nb\r\n')
      const manifestPath = join(dir, 'manifest.json')
      const exclude = new Set(['manifest.json'])
      writeManifest(dir, manifestPath, exclude, dir)
      writeFileSync(join(dir, 'a.md'), 'a\nb\n')
      expect(checkManifest(dir, manifestPath, exclude, dir)).toEqual([])
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })

  it('rejects removal of a sealed entry', () => {
    expect(manifestRemovals({ 'a.md': 'hash', 'b.md': 'hash' }, { 'a.md': 'hash' }))
      .toEqual(['b.md: frozen entry cannot be removed'])
  })
})
