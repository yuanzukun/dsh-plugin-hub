import { describe, expect, it } from 'vitest'
import { extractMermaidBlocks } from '../scripts/check-mermaid.mjs'

describe('mermaid extraction', () => {
  it('extracts only fenced mermaid blocks with their source line', () => {
    const blocks = extractMermaidBlocks('# Example\n\n```mermaid\nflowchart LR\n```\n\n```ts\nconst x = 1\n```\n', 'docs/example.md')
    expect(blocks).toEqual([{ path: 'docs/example.md', line: 3, source: 'flowchart LR' }])
  })
})
