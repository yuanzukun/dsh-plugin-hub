import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { describe, expect, it } from 'vitest'
import { collectUpgradeGuideViolations, validateUpgradeGuide } from '../scripts/check-upgrade-guides.mjs'

const version = ['0', '4', '6'].join('.')
const guide = `docs/upgrade/v${version}-search-default.md`
const validGuide = `# v${version}：修改默认搜索服务

## 变更

旧版本使用 A；新版本使用 B。

## 迁移

1. 修改配置。

## 验证

运行一次搜索。
`

describe('upgrade guides', () => {
  it('accepts a versioned guide with required sections', () => {
    expect(validateUpgradeGuide(validGuide, guide)).toEqual([])
  })

  it('rejects invalid names and outlines', () => {
    expect(validateUpgradeGuide(validGuide, 'docs/upgrade/search-default.md'))
      .toContain('docs/upgrade/search-default.md: filename must be v<semver>-<kebab-case-topic>.md')
    expect(validateUpgradeGuide('# Wrong\n\n## 变更\n', guide))
      .toContain(`${guide}: first line must be '# v<semver>：<title>'`)
  })

  it('checks every non-index guide in the upgrade directory', () => {
    const dir = mkdtempSync(join(tmpdir(), 'dsh-upgrades-'))
    try {
      const upgradeDir = join(dir, 'docs/upgrade')
      mkdirSync(upgradeDir, { recursive: true })
      writeFileSync(join(upgradeDir, 'README.md'), '# 升级迁移指南\n')
      writeFileSync(join(upgradeDir, 'bad.md'), '# Bad\n')
      expect(collectUpgradeGuideViolations(dir)).toContain('docs/upgrade/bad.md: filename must be v<semver>-<kebab-case-topic>.md')
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })
})
