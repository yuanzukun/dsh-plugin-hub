import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { tmpdir } from 'node:os'
import { describe, expect, it } from 'vitest'
import { findBrokenLinks, markdownAnchors, markdownDestinations } from '../scripts/markdown-links.mjs'

describe('markdown links', () => {
  it('collects inline, image and reference destinations', () => {
    const destinations = markdownDestinations(
      '[inline](target.md) ![image](image.png)\n\n[reference]: other.md\n',
    )
    expect(destinations.map(item => item.url)).toEqual(expect.arrayContaining(['target.md', 'image.png', 'other.md']))
  })

  it('builds heading and explicit anchors with duplicate suffixes', () => {
    expect([...markdownAnchors('# Repeat\n\n## Repeat\n\n<a id="explicit"></a>')])
      .toEqual(expect.arrayContaining(['repeat', 'repeat-1', 'explicit']))
  })

  it('checks reference links and fragments', () => {
    const dir = mkdtempSync(join(tmpdir(), 'dsh-links-'))
    try {
      writeFileSync(join(dir, 'target.md'), '# Existing\n')
      const source = '[ok](target.md#existing) [bad](target.md#missing) [ref][missing]\n\n[missing]: absent.md\n'
      const violations = findBrokenLinks(resolve(dir, 'source.md'), source)
      expect(violations.map(item => item.reason)).toEqual(expect.arrayContaining(['anchor', 'target']))
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })
})
