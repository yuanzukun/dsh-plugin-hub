import { describe, expect, it } from 'vitest'
import { relative } from 'node:path'
import { checkableSource, sourceFiles, validateDocRefs } from '../scripts/check-doc-refs.mjs'

describe('validateDocRefs', () => {
  it('accepts existing document paths', () => {
    expect(validateDocRefs('see docs/architecture.md', 'src/example.ts', () => true)).toEqual([])
  })

  it('rejects missing paths and section-number references', () => {
    expect(validateDocRefs('see docs/missing.md', 'src/example.ts', () => false))
      .toContain('src/example.ts:1: missing docs/missing.md')
    expect(validateDocRefs('see docs/development.md §3.5', 'src/example.ts', () => true))
      .toContain('src/example.ts:1: section-number reference docs/development.md is not stable; link the document or an anchor')
  })

  it('accepts numbered path templates without treating them as references', () => {
    expect(validateDocRefs('expected docs/adr/NNNN-topic.md', 'scripts/example.mjs', () => false)).toEqual([])
  })
})

describe('sourceFiles', () => {
  it('scans source, tests, and scripts', () => {
    const paths = sourceFiles(process.cwd()).map(path => relative(process.cwd(), path).replaceAll('\\', '/'))
    expect(paths).toContain('src/index.ts')
    expect(paths).toContain('test/doc-refs.test.mjs')
    expect(paths).toContain('scripts/check-doc-refs.mjs')
    expect(paths.some(path => path.startsWith('client/'))).toBe(false)
  })
})

describe('checkableSource', () => {
  it('removes fixture strings in tests but keeps comments', () => {
    const source = "const fixture = 'docs/missing.md'\n// see docs/architecture.md\n"
    const checked = checkableSource(source, 'test/example.test.mjs')
    expect(checked).not.toContain('docs/missing.md')
    expect(checked).toContain('// see docs/architecture.md')
    expect(checkableSource(source, 'scripts/example.mjs')).toBe(source)
  })
})
