import { describe, expect, it } from 'vitest'
import { validateDocRefs } from '../scripts/check-doc-refs.mjs'

describe('validateDocRefs', () => {
  it('accepts existing document paths', () => {
    expect(validateDocRefs('see docs/architecture.md', 'src/example.ts', () => true)).toEqual([])
  })

  it('rejects missing paths and section-number references', () => {
    expect(validateDocRefs('see docs/missing.md', 'src/example.ts', () => false))
      .toContain('src/example.ts:1: missing docs/missing.md')
    expect(validateDocRefs('see docs/development.md §3.5', 'src/example.ts', () => true))
      .toContain('src/example.ts:1: section-number reference docs/development.md is not stable; link the document or an anchor')
  })
})
