// 实时配置引用回归：根级 volatile + 每操作 config.get() 的契约。
// 直接覆盖 getter 链路（buildContext / controls / rerank / zone / 目录 baseUrl），
// 防止将来把 config.<field> 再捕获到装配时。
import { describe, expect, it } from 'vitest'
import type { Context } from '@deepseek-ai/cordis'
import { updateVolatile, type Volatile } from '@deepseek-ai/cosmokit'
import { Config, makeBuildContext, resolveControlsFrom, resolveRerankKey, searchCacheFingerprint } from '../src/index.js'
import type { Config as ConfigShape } from '../src/index.js'
import { createAnysearchEngine } from '../src/engines/anysearch.js'
import { AnysearchDomainCatalog } from '../src/engines/anysearch-domains.js'
import { ENGINE_MANIFESTS } from '../src/engines/registry.js'
import { OpContext } from '../src/support/budget.js'
import type { EngineContext } from '../src/engines/contract.js'

async function configRef(raw: Record<string, unknown>): Promise<Volatile<ConfigShape>> {
  const result = (await Config['~standard'].validate(raw)) as { value?: Volatile<ConfigShape>; issues?: unknown[] }
  expect(result.issues, JSON.stringify(result.issues ?? [])).toBeUndefined()
  return result.value!
}

function credentialsContext(): { ctx: Context; resolved: string[] } {
  const resolved: string[] = []
  const ctx = {
    credentials: {
      resolve: async (ref: string) => {
        resolved.push(ref)
        return { value: `sk-${ref}` }
      },
    },
  } as unknown as Context
  return { ctx, resolved }
}

function lane() {
  return {
    signal: new AbortController().signal,
    deadline: Date.now() + 5_000,
    face: 'search' as const,
  }
}

function opContext(): OpContext {
  return new OpContext({}, new AbortController().signal, undefined, 32)
}

describe('buildContext 每次操作读取实时配置', () => {
  it('凭证引用与端点覆盖更新后，下一次 buildContext 使用新值', async () => {
    const { ctx, resolved } = credentialsContext()
    const ref = await configRef({ anysearchApiKeyEnv: 'ANY_OLD', anysearchBaseURL: 'https://old.example.com' })
    const build = makeBuildContext(ctx, ref)
    const manifest = ENGINE_MANIFESTS.find(item => item.id === 'anysearch')!
    const firstOp = opContext()

    const first = await build(manifest, firstOp, lane())
    expect(first.apiKey).toBe('sk-ANY_OLD')
    expect(first.endpoint).toBe('https://old.example.com')

    updateVolatile(ref, await configRef({ anysearchApiKeyEnv: 'ANY_NEW', anysearchBaseURL: 'https://new.example.com' }))
    const second = await build(manifest, opContext(), lane())
    expect(second.apiKey).toBe('sk-ANY_NEW')
    expect(second.endpoint).toBe('https://new.example.com')

    // 同一操作（同一 OpContext）在保存后仍使用开始时的快照。
    const sameOperation = await build(manifest, firstOp, lane())
    expect(sameOperation.apiKey).toBe('sk-ANY_OLD')
    expect(sameOperation.endpoint).toBe('https://old.example.com')
    expect(resolved).toEqual(['ANY_OLD', 'ANY_NEW', 'ANY_OLD'])
  })

  it('空串端点回退 manifest 端点', async () => {
    const { ctx } = credentialsContext()
    const ref = await configRef({ anysearchBaseURL: '' })
    const build = makeBuildContext(ctx, ref)
    const manifest = ENGINE_MANIFESTS.find(item => item.id === 'anysearch')!
    const context = await build(manifest, opContext(), lane())
    expect(context.endpoint).toBe(manifest.endpoints.search)
  })
})

describe('resolveControlsFrom 合并快照', () => {
  const defaults = { anysearch: true, tavily: true, zhihu: false, aihot: false, http: true }

  it('未设置 serviceEnabled 时使用 registry 默认', () => {
    expect(resolveControlsFrom({}, defaults)).toMatchObject({ serviceEnabled: defaults })
  })

  it('显式开关覆盖默认并保留未写的服务', () => {
    expect(resolveControlsFrom({ controls: { serviceEnabled: { zhihu: true, tavily: false } } }, defaults))
      .toMatchObject({ serviceEnabled: { anysearch: true, tavily: false, zhihu: true, aihot: false, http: true } })
  })

  it('其余 controls 字段原样透传', () => {
    expect(resolveControlsFrom({ controls: { maxRequests: 7 } }, defaults))
      .toMatchObject({ maxRequests: 7 })
  })

  it('废弃预设字段不进入运行时控制和缓存指纹', () => {
    const legacy = {
      controls: { preset: 'single', maxSearchServices: 1, maxRequests: 7 },
    } as unknown as ConfigShape
    const current = { controls: { maxRequests: 7 } } as ConfigShape
    expect(resolveControlsFrom(legacy, defaults)).toEqual(resolveControlsFrom(current, defaults))
    expect(searchCacheFingerprint(legacy)).toBe(searchCacheFingerprint(current))
  })
})

describe('resolveRerankKey 读取同一次配置快照', () => {
  it('关闭时不解析凭证；更新引用后下一次读取新开关与引用', async () => {
    const { ctx, resolved } = credentialsContext()
    const ref = await configRef({ rerank: { enabled: false, apiKeyEnv: 'SF_OLD' } })
    const op = opContext()
    expect(await resolveRerankKey(ctx, ref, op)).toBeUndefined()
    expect(resolved).toEqual([])

    updateVolatile(ref, await configRef({ rerank: { enabled: true, apiKeyEnv: 'SF_NEW' } }))
    // 同一操作沿用旧快照：仍为禁用。
    expect(await resolveRerankKey(ctx, ref, op)).toBeUndefined()
    // 新操作读取新值。
    expect(await resolveRerankKey(ctx, ref, opContext())).toBe('sk-SF_NEW')
    expect(resolved).toEqual(['SF_NEW'])
  })
})

describe('AnySearch zone 每次请求求值', () => {
  it('resolveZone 更新后，下一次搜索请求体使用新 zone；undefined 不发送 zone', async () => {
    const bodies: Array<Record<string, unknown>> = []
    const fetcher = (async (_input: string | URL | Request, init?: RequestInit) => {
      bodies.push(JSON.parse(String(init?.body ?? '{}')))
      return new Response(JSON.stringify({ code: 0, message: 'ok', data: { results: [] } }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })
    }) as typeof fetch
    let zone: 'cn' | 'intl' | undefined = 'cn'
    const engine = createAnysearchEngine({ resolveZone: () => zone, fetcher })
    const context: EngineContext = {
      signal: new AbortController().signal,
      deadline: Date.now() + 5_000,
      endpoint: 'https://api.anysearch.com/v1/search',
      countRequest: () => true,
    }
    await engine.search!({ query: 'x', maxResults: 1 }, context)
    zone = 'intl'
    await engine.search!({ query: 'x', maxResults: 1 }, context)
    zone = undefined
    await engine.search!({ query: 'x', maxResults: 1 }, context)
    expect(bodies.map(body => body.zone)).toEqual(['cn', 'intl', undefined])
    expect('zone' in bodies[2]!).toBe(false)
  })
})

describe('AnysearchDomainCatalog 按实时 baseUrl 刷新', () => {
  it('baseUrl 更新后目录发现走新端点，旧缓存不复用', async () => {
    const calls: string[] = []
    const fetcher = (async (input: string | URL | Request) => {
      const url = String(input)
      calls.push(url)
      const body = url.includes('/v1/sub-domains')
        ? { code: 0, data: { domains: [{ domain: 'finance', sub_domains: [{ sub_domain: 'stock', description: 'Stock' }] }] } }
        : { code: 0, data: { domains: [{ domain: 'finance' }] } }
      return new Response(JSON.stringify(body), { status: 200, headers: { 'content-type': 'application/json' } })
    }) as typeof fetch
    let baseUrl = 'https://old.example.com'
    const catalog = new AnysearchDomainCatalog({ baseUrl: () => baseUrl, fetcher, ttlMs: 60_000, now: () => 0 })
    expect((await catalog.listTags()).map(tag => tag.tag)).toEqual(['finance.stock'])
    expect(calls).toEqual([
      'https://old.example.com/v1/domains',
      'https://old.example.com/v1/sub-domains?domain=finance',
    ])

    baseUrl = 'https://new.example.com'
    expect((await catalog.listTags()).map(tag => tag.tag)).toEqual(['finance.stock'])
    expect(calls.slice(2)).toEqual([
      'https://new.example.com/v1/domains',
      'https://new.example.com/v1/sub-domains?domain=finance',
    ])
  })

  it('空 baseUrl 回退官方端点', async () => {
    const calls: string[] = []
    const fetcher = (async (input: string | URL | Request) => {
      calls.push(String(input))
      return new Response(JSON.stringify({ code: 0, data: { domains: [] } }), { status: 200 })
    }) as typeof fetch
    const catalog = new AnysearchDomainCatalog({ baseUrl: () => '', fetcher, now: () => 0 })
    await catalog.listTags()
    expect(calls).toEqual(['https://api.anysearch.com/v1/domains'])
  })

  it('旧端点晚到的结果不覆盖新端点缓存', async () => {
    const calls: string[] = []
    const pending: Array<{ url: string; resolve: (response: Response) => void }> = []
    const fetcher = ((input: string | URL | Request) => new Promise<Response>(resolve => {
      const url = String(input)
      calls.push(url)
      pending.push({ url, resolve })
    })) as typeof fetch
    const flush = () => new Promise<void>(resolve => { setTimeout(resolve, 0) })
    const respond = async (url: string, body: unknown) => {
      const index = pending.findIndex(item => item.url === url)
      expect(index, `${url} 未发起请求；已请求 ${calls.join(', ')}`).toBeGreaterThanOrEqual(0)
      const item = pending.splice(index, 1)[0]!
      item.resolve(new Response(JSON.stringify(body), { status: 200, headers: { 'content-type': 'application/json' } }))
      await flush()
    }
    const domains = (name: string) => ({ code: 0, data: { domains: [{ domain: name }] } })
    const subs = (name: string) => ({
      code: 0,
      data: { domains: [{ domain: name, sub_domains: [{ sub_domain: 'stock', description: name }] }] },
    })

    let baseUrl = 'https://old.example.com'
    const catalog = new AnysearchDomainCatalog({ baseUrl: () => baseUrl, fetcher, ttlMs: 60_000, now: () => 0 })
    const first = catalog.listTags()
    await flush()
    baseUrl = 'https://new.example.com'
    const second = catalog.listTags()
    await flush()

    // 新端点先完成并写入缓存。
    await respond('https://new.example.com/v1/domains', domains('newdomain'))
    await respond('https://new.example.com/v1/sub-domains?domain=newdomain', subs('newdomain'))
    expect((await second).map(tag => tag.tag)).toEqual(['newdomain.stock'])

    // 旧端点随后完成；不得覆盖新端点缓存。
    await respond('https://old.example.com/v1/domains', domains('olddomain'))
    await respond('https://old.example.com/v1/sub-domains?domain=olddomain', subs('olddomain'))
    expect((await first).map(tag => tag.tag)).toEqual(['olddomain.stock'])
    const callsAfterBoth = calls.length

    const final = catalog.listTags()
    expect(calls.length, '新端点缓存未命中，发起了多余刷新').toBe(callsAfterBoth)
    expect((await final).map(tag => tag.tag)).toEqual(['newdomain.stock'])
  })
})

describe('searchCacheFingerprint 覆盖影响结果的配置', () => {
  const base: ConfigShape = {}

  it('controls、端点、区域、重排与凭证引用变化都会改变指纹', () => {
    const basePrint = searchCacheFingerprint(base)
    expect(searchCacheFingerprint({ ...base, controls: { serviceEnabled: { tavily: false } } })).not.toBe(basePrint)
    expect(searchCacheFingerprint({ ...base, anysearchZone: 'cn' })).not.toBe(basePrint)
    expect(searchCacheFingerprint({ ...base, anysearchBaseURL: 'https://proxy.example' })).not.toBe(basePrint)
    expect(searchCacheFingerprint({ ...base, firecrawlBaseURL: 'https://proxy.example' })).not.toBe(basePrint)
    expect(searchCacheFingerprint({ ...base, anysearchApiKeyEnv: 'MY_KEY' })).not.toBe(basePrint)
    expect(searchCacheFingerprint({ ...base, rerank: { enabled: false } })).not.toBe(basePrint)
  })

  it('同一配置得到同一指纹', () => {
    const config: ConfigShape = { controls: { serviceEnabled: { aihot: true } }, anysearchZone: 'intl' }
    expect(searchCacheFingerprint(config)).toBe(searchCacheFingerprint({
      controls: { ...config.controls, serviceEnabled: { aihot: true } },
      anysearchZone: 'intl',
    }))
  })
})
