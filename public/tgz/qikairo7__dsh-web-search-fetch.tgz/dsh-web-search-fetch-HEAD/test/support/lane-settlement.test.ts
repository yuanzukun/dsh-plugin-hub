import { describe, expect, it } from 'vitest'

import { engineFailure } from '../../src/engines/failure.js'
import { CircuitBreaker } from '../../src/support/breaker.js'
import { LaneSettlement, ledgerKindOfOutcome } from '../../src/support/lane-settlement.js'

describe('LaneSettlement', () => {
  it('成功入账，限流与额度失败分别入账，其他结局忽略', () => {
    expect(ledgerKindOfOutcome({ kind: 'ok', engineId: 'a', result: {}, elapsedMs: 1 })).toBe('success')
    expect(ledgerKindOfOutcome({ kind: 'failed', engineId: 'a', failure: engineFailure('rate-limited'), elapsedMs: 1 }))
      .toBe('rate-limited')
    expect(ledgerKindOfOutcome({ kind: 'failed', engineId: 'a', failure: engineFailure('quota'), elapsedMs: 1 }))
      .toBe('quota')
    expect(ledgerKindOfOutcome({ kind: 'timeout', engineId: 'a', elapsedMs: 1 })).toBeUndefined()
    expect(ledgerKindOfOutcome({ kind: 'failed', engineId: 'a', failure: engineFailure('network'), elapsedMs: 1 }))
      .toBeUndefined()
  })

  it('一次结算同时上报额度并喂熔断', () => {
    const events: string[] = []
    const breaker = new CircuitBreaker({ now: () => 1_000 })
    const settlement = new LaneSettlement((engineId, kind) => events.push(`${engineId}:${kind}`), breaker)
    settlement.settle({
      kind: 'failed',
      engineId: 'alpha',
      failure: engineFailure('rate-limited', { retryAfterMs: 2_000 }),
      elapsedMs: 10,
    })
    expect(events).toEqual(['alpha:rate-limited'])
    expect(breaker.isBroken('alpha')).toBe(true)
  })
})
