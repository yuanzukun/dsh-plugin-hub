// 官方快照仓离线单测（spec R2 的仓侧语义）：注入时钟，不触网。
import { describe, expect, it } from 'vitest'
import { QuotaSnapshotStore } from '../../src/support/quota-snapshots.js'

const NOW = Date.UTC(2026, 10, 8, 4, 0, 0)

function storeAt(now: number = NOW): QuotaSnapshotStore {
  return new QuotaSnapshotStore({ now: () => now })
}

describe('QuotaSnapshotStore 官方快照仓', () => {
  it('available 且有数值 → ok，保留官方字段与注入的 fetchedAt', () => {
    const store = storeAt()
    const snapshot = store.record('alpha', {
      engineId: 'alpha',
      available: true,
      used: 12,
      limit: 1000,
      remaining: 988,
      resetsAt: '2026-12-01T00:00:00.000Z',
      raw: 'key.usage=12, key.limit=1000',
    })
    expect(snapshot).toEqual({
      kind: 'ok',
      used: 12,
      limit: 1000,
      remaining: 988,
      resetsAt: '2026-12-01T00:00:00.000Z',
      raw: 'key.usage=12, key.limit=1000',
      fetchedAt: NOW,
    })
    expect(store.get('alpha')).toEqual(snapshot)
  })

  it('available:false → unavailable，reason 取 raw 原文，不冒充官方数值', () => {
    const store = storeAt()
    const snapshot = store.record('beta', {
      engineId: 'beta',
      available: false,
      remaining: 0,
      raw: 'keyless 模式无额度端点',
    })
    expect(snapshot).toEqual({ kind: 'unavailable', reason: 'keyless 模式无额度端点', fetchedAt: NOW })
    expect(store.get('beta')).toEqual(snapshot)
  })

  it('available:true 但没有任何数值 → unavailable 并给通用原因', () => {
    const store = storeAt()
    const snapshot = store.record('gamma', { engineId: 'gamma', available: true })
    expect(snapshot).toEqual({ kind: 'unavailable', reason: '官方额度响应未给出数值', fetchedAt: NOW })
  })

  it('recordUnavailable 覆盖上一次 ok，保留探测失败原因', () => {
    const store = storeAt()
    store.record('alpha', { engineId: 'alpha', available: true, remaining: 5 })
    const later = NOW + 60_000
    const snapshot = new QuotaSnapshotStore({ now: () => later }).recordUnavailable('alpha', '探测超时')
    expect(snapshot).toEqual({ kind: 'unavailable', reason: '探测超时', fetchedAt: later })
  })

  it('未知引擎返回 undefined（面板显示未刷新）', () => {
    expect(storeAt().get('never-probed')).toBeUndefined()
  })
})
