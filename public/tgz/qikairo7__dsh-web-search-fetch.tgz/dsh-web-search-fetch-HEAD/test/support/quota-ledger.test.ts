// 本地额度账本离线单测：注入时钟，不触网。
import { describe, expect, it } from 'vitest'
import {
  LOCAL_QUOTA_FAILURE_THRESHOLD,
  QuotaLedger,
} from '../../src/support/quota-ledger.js'

const DAY_MS = 24 * 60 * 60 * 1000

describe('QuotaLedger 本地额度账本', () => {
  it('按引擎分别累计成功/限流/额度失败', () => {
    const ledger = new QuotaLedger({ now: () => Date.UTC(2026, 10, 7, 4) })
    ledger.recordSuccess('alpha')
    ledger.recordSuccess('alpha')
    ledger.recordRateLimited('alpha')
    ledger.recordQuotaFailure('beta')

    expect(ledger.snapshot('alpha')).toMatchObject({ success: 2, rateLimited: 1, quotaFailures: 0 })
    expect(ledger.snapshot('beta')).toMatchObject({ success: 0, rateLimited: 0, quotaFailures: 1 })
  })

  it('当日额度失败达到默认阈值（2 次）才视为本地耗尽', () => {
    const ledger = new QuotaLedger({ now: () => Date.UTC(2026, 10, 7, 4) })
    ledger.recordQuotaFailure('alpha')
    expect(ledger.locallyExhausted('alpha', LOCAL_QUOTA_FAILURE_THRESHOLD)).toBe(false)

    ledger.recordQuotaFailure('alpha')
    expect(ledger.locallyExhausted('alpha', LOCAL_QUOTA_FAILURE_THRESHOLD)).toBe(true)
    // 未记录过的引擎不受影响。
    expect(ledger.locallyExhausted('beta', LOCAL_QUOTA_FAILURE_THRESHOLD)).toBe(false)
  })

  it('显式阈值覆盖默认值', () => {
    const ledger = new QuotaLedger({ now: () => Date.UTC(2026, 10, 7, 4) })
    ledger.recordQuotaFailure('alpha')
    expect(ledger.locallyExhausted('alpha', 1)).toBe(true)
    expect(ledger.locallyExhausted('alpha', 2)).toBe(false)
  })

  it('本地日滚动：跨日清零，前一天累计不影响今天', () => {
    let now = Date.UTC(2026, 10, 7, 4)
    const ledger = new QuotaLedger({ now: () => now })
    ledger.recordQuotaFailure('alpha')
    ledger.recordQuotaFailure('alpha')
    expect(ledger.locallyExhausted('alpha', 2)).toBe(true)

    now += DAY_MS
    expect(ledger.locallyExhausted('alpha', 2)).toBe(false)
    expect(ledger.snapshot('alpha')).toMatchObject({ success: 0, rateLimited: 0, quotaFailures: 0 })
  })

  it('限流计数记录但不参与本地耗尽判定', () => {
    const ledger = new QuotaLedger({ now: () => Date.UTC(2026, 10, 7, 4) })
    ledger.recordRateLimited('alpha')
    ledger.recordRateLimited('alpha')
    expect(ledger.snapshot('alpha').rateLimited).toBe(2)
    expect(ledger.locallyExhausted('alpha', 2)).toBe(false)
  })
})
