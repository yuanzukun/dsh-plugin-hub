// 查询缓存机制单测（ADR-0001 §8）：归一键、TTL、LRU、时钟注入。
// 意图 TTL 分档与绕过规则属于编排层，见 test/search/cache.test.ts。
import { describe, expect, it } from 'vitest'
import type { WebSearchResult } from '@deepseek-ai/dsh-web'
import {
  DEFAULT_QUERY_CACHE_CAPACITY,
  QueryCache,
  normalizeQuery,
  queryCacheKey,
} from '../../src/support/query-cache.js'

const RESULT: WebSearchResult = {
  sources: [{ url: 'https://a.example/1', title: 'alpha' }],
  truncated: false,
}

/** 可推进的假时钟：测试不依赖真实时间。 */
function clock(start = 1_000) {
  let current = start
  return {
    now: () => current,
    advance(ms: number) { current += ms },
  }
}

describe('归一查询与缓存键', () => {
  it('trim + 空白折叠', () => {
    expect(normalizeQuery('  alpha   beta\t gamma  ')).toBe('alpha beta gamma')
  })

  it('同一归一查询与域名集合得到同一键，域名顺序不影响', () => {
    expect(queryCacheKey('  alpha   beta ', 'intent', ['b.example', 'a.example']))
      .toBe(queryCacheKey('alpha beta', 'intent', ['a.example', 'b.example']))
  })

  it('意图与域名参与键：任一不同即不同键', () => {
    const base = queryCacheKey('alpha', 'chinese-web', [])
    expect(queryCacheKey('alpha', 'english-web', [])).not.toBe(base)
    expect(queryCacheKey('alpha', 'chinese-web', ['a.example'])).not.toBe(base)
  })

  it('maxResults 参与键：不同条数上限即不同键', () => {
    expect(queryCacheKey('alpha', 'chinese-web', [], 3)).not.toBe(queryCacheKey('alpha', 'chinese-web', [], 5))
    expect(queryCacheKey('alpha', 'chinese-web', [], 3)).toBe(queryCacheKey('alpha', 'chinese-web', [], 3))
  })

  it('配置指纹参与键：设置变更后不复用旧结果', () => {
    expect(queryCacheKey('alpha', 'chinese-web', [], 5, 'a'))
      .not.toBe(queryCacheKey('alpha', 'chinese-web', [], 5, 'b'))
    expect(queryCacheKey('alpha', 'chinese-web', [], 5, 'a'))
      .toBe(queryCacheKey('alpha', 'chinese-web', [], 5, 'a'))
  })

  it('规划器版本参与键：版本变化或旧键缺少版本都不命中', () => {
    expect(queryCacheKey('alpha', 'chinese-web', [], 5, 'a', '1'))
      .not.toBe(queryCacheKey('alpha', 'chinese-web', [], 5, 'a', '2'))
    expect(queryCacheKey('alpha', 'chinese-web', [], 5, 'a', '1'))
      .not.toBe(queryCacheKey('alpha', 'chinese-web', [], 5, 'a'))
  })
})

describe('TTL', () => {
  it('TTL 内命中并给出年龄，恰满 TTL 过期', () => {
    const time = clock()
    const cache = new QueryCache({ now: time.now })
    cache.set('k', RESULT, 300)

    expect(cache.get('k', 300)).toEqual({ result: RESULT, ageSeconds: 0 })
    time.advance(5_000)
    expect(cache.get('k', 300)?.ageSeconds).toBe(5)
    time.advance(294_999) // 总计 299.999 秒
    expect(cache.get('k', 300)).toBeDefined()
    time.advance(1) // 恰满 300 秒
    expect(cache.get('k', 300)).toBeUndefined()
  })

  it('ttl 0 不写也不命中（调用方声明不缓存）', () => {
    const cache = new QueryCache({ now: clock().now })
    cache.set('k', RESULT, 0)
    expect(cache.get('k', 300)).toBeUndefined()
    expect(cache.size).toBe(0)
  })

  it('同键重写刷新时间戳', () => {
    const time = clock()
    const cache = new QueryCache({ now: time.now })
    cache.set('k', RESULT, 300)
    time.advance(200_000)
    cache.set('k', RESULT, 300)
    time.advance(200_000)
    expect(cache.get('k', 300)?.ageSeconds).toBe(200)
  })
})

describe('容量与 LRU', () => {
  it('超过容量淘汰最久未使用的一条，命中会刷新次序', () => {
    const cache = new QueryCache({ capacity: 2, now: clock().now })
    cache.set('a', RESULT, 300)
    cache.set('b', RESULT, 300)
    expect(cache.get('a', 300)).toBeDefined() // a 变为最新
    cache.set('c', RESULT, 300)

    expect(cache.get('a', 300)).toBeDefined()
    expect(cache.get('b', 300)).toBeUndefined()
    expect(cache.get('c', 300)).toBeDefined()
    expect(cache.size).toBe(2)
  })

  it('默认容量上限为 50', () => {
    const cache = new QueryCache({ now: clock().now })
    for (let index = 0; index < DEFAULT_QUERY_CACHE_CAPACITY + 1; index += 1) {
      cache.set(`k${index}`, RESULT, 300)
    }
    expect(cache.size).toBe(DEFAULT_QUERY_CACHE_CAPACITY)
    expect(cache.get('k0', 300)).toBeUndefined()
    expect(cache.get(`k${DEFAULT_QUERY_CACHE_CAPACITY}`, 300)).toBeDefined()
  })
})
