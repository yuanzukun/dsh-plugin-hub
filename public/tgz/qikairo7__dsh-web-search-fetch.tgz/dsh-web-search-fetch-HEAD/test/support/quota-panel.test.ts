// 额度面板纯核心单测（spec R1/R4/R5/R6/R7/R8/R9）：注入替身与时钟，不触网。
import { describe, expect, it } from 'vitest'
import type { Engine, QuotaReport } from '../../src/engines/contract.js'
import { CircuitBreaker } from '../../src/support/breaker.js'
import type { BreakerEvent } from '../../src/support/breaker.js'
import { QuotaLedger } from '../../src/support/quota-ledger.js'
import { QuotaCredentialError, QuotaPanelService } from '../../src/support/quota-panel.js'
import type { PanelEngineManifest, QuotaPanelPeriod } from '../../src/support/quota-panel.js'
import { QuotaSnapshotStore } from '../../src/support/quota-snapshots.js'

const FIXED_NOW = new Date(2026, 10, 8, 12, 0, 0).getTime()
const NEXT_MIDNIGHT = new Date(2026, 10, 9).getTime()
const PERIODS: Readonly<Record<string, QuotaPanelPeriod>> = {
  alpha: 'daily-utc',
  beta: 'monthly',
  gamma: 'daily-bj',
  delta: 'none',
  epsilon: 'none',
}

/** 面板只消费 manifest.id/period 与 engine.quota 的存在性；quota 本体由注入 probe 代替。 */
function fakeEngine(id: string, withQuota = true): Engine {
  return {
    manifest: {
      id,
      label: id,
      capabilities: ['search'],
      auth: 'anonymous',
      enabledByDefault: true,
      endpoints: { search: `https://${id}.invalid/search` },
    },
    ...(withQuota ? { quota: async () => ({ engineId: id, available: false, raw: 'stub' }) } : {}),
  }
}

interface HarnessOptions {
  readonly engines: readonly Engine[]
  readonly probe?: (manifest: PanelEngineManifest, signal: AbortSignal) => Promise<QuotaReport>
  readonly enabled?: Readonly<Record<string, boolean>>
  readonly now?: () => number
  readonly perEngineTimeoutMs?: number
  readonly totalTimeoutMs?: number
}

function harness(options: HarnessOptions) {
  const events: BreakerEvent[] = []
  const now = options.now ?? (() => FIXED_NOW)
  const ledger = new QuotaLedger({ now })
  const store = new QuotaSnapshotStore({ now })
  const breaker = new CircuitBreaker({ now, onEvent: event => events.push(event) })
  const manifests = options.engines.map(engine => ({
    ...engine.manifest,
    period: PERIODS[engine.manifest.id] ?? 'none',
  }))
  const calls: string[] = []
  const service = new QuotaPanelService({
    engines: options.engines,
    manifests,
    ledger,
    store,
    breaker,
    now,
    resolveEnabled: () => options.enabled
      ?? Object.fromEntries(options.engines.map(engine => [engine.manifest.id, true])),
    probe: async (manifest, signal) => {
      calls.push(manifest.id)
      if (options.probe === undefined) return { engineId: manifest.id, available: false, raw: 'stub' }
      return await options.probe(manifest, signal)
    },
    ...(options.perEngineTimeoutMs === undefined ? {} : { perEngineTimeoutMs: options.perEngineTimeoutMs }),
    ...(options.totalTimeoutMs === undefined ? {} : { totalTimeoutMs: options.totalTimeoutMs }),
  })
  return { service, ledger, store, breaker, events, calls }
}

describe('QuotaPanelService 额度面板核心', () => {
  it('R1 get(): 五引擎行、规范 day、未刷新 official=undefined', () => {
    const engines = ['alpha', 'beta', 'gamma', 'delta', 'epsilon'].map(id => fakeEngine(id))
    const h = harness({ engines })
    const payload = h.service.get()
    expect(payload.day).toBe('2026-11-08')
    expect(payload.engines.map(engine => engine.id)).toEqual(['alpha', 'beta', 'gamma', 'delta', 'epsilon'])
    expect(payload.engines[0]).toEqual({
      id: 'alpha',
      enabled: true,
      period: 'daily-utc',
      official: undefined,
      ledger: { success: 0, rateLimited: 0, quotaFailures: 0, day: '2026-10-8' },
      breaker: { broken: false },
    })
    expect(h.calls).toEqual([])
  })

  it('refresh: ok 入仓为 ok，available:false 入仓为 unavailable 且保留原因', async () => {
    const h = harness({
      engines: [fakeEngine('alpha'), fakeEngine('beta')],
      probe: async manifest => manifest.id === 'alpha'
        ? { engineId: 'alpha', available: true, used: 12, limit: 1000, remaining: 988 }
        : { engineId: 'beta', available: false, raw: 'keyless 模式无额度端点' },
    })
    const payload = await h.service.refresh()
    expect(payload.engines[0]!.official).toEqual({
      kind: 'ok', used: 12, limit: 1000, remaining: 988, fetchedAt: FIXED_NOW,
    })
    expect(payload.engines[1]!.official).toEqual({
      kind: 'unavailable', reason: 'keyless 模式无额度端点', fetchedAt: FIXED_NOW,
    })
    expect(h.calls).toEqual(['alpha', 'beta'])
  })

  it('refresh 后 get() 仍读到快照仓里的官方结果', async () => {
    const h = harness({
      engines: [fakeEngine('alpha')],
      probe: async manifest => ({ engineId: manifest.id, available: true, remaining: 7 }),
    })
    await h.service.refresh()
    expect(h.service.get().engines[0]!.official).toMatchObject({ kind: 'ok', remaining: 7 })
  })

  it('R5 停用或无 quota() 的引擎零请求；全部停用时仍返回五行', async () => {
    const h = harness({
      engines: [
        fakeEngine('alpha'), fakeEngine('beta'),
        fakeEngine('gamma', false), fakeEngine('delta', false), fakeEngine('epsilon', false),
      ],
      enabled: { alpha: false, beta: false, gamma: true, delta: true, epsilon: true },
      probe: async manifest => ({ engineId: manifest.id, available: true, remaining: 1 }),
    })
    const payload = await h.service.refresh()
    expect(h.calls).toEqual([])
    expect(payload.engines).toHaveLength(5)
    expect(payload.engines.map(engine => engine.official)).toEqual([undefined, undefined, undefined, undefined, undefined])
  })

  it('R6 凭证解析异常 → 该行固定原因，其余引擎照常探测', async () => {
    const h = harness({
      engines: [fakeEngine('alpha'), fakeEngine('beta')],
      probe: async manifest => {
        if (manifest.id === 'alpha') throw new QuotaCredentialError()
        return { engineId: 'beta', available: true, remaining: 9 }
      },
    })
    const payload = await h.service.refresh()
    expect(payload.engines[0]!.official).toEqual({
      kind: 'unavailable', reason: '凭证服务不可用', fetchedAt: FIXED_NOW,
    })
    expect(payload.engines[1]!.official).toMatchObject({ kind: 'ok', remaining: 9 })
    expect(h.breaker.isBroken('alpha', FIXED_NOW)).toBe(false)
  })

  it('R4 ok remaining>0 → 解除日级熔断并发 recovery；rate-limit 冷却不动', async () => {
    const h = harness({
      engines: [fakeEngine('alpha'), fakeEngine('beta')],
      probe: async manifest => ({ engineId: manifest.id, available: true, remaining: 5 }),
    })
    h.breaker.recordSignal('alpha', { kind: 'quota-exhausted' }, FIXED_NOW)
    h.breaker.recordSignal('beta', { kind: 'rate-limit', retryAfterMs: 5_000 }, FIXED_NOW)
    const payload = await h.service.refresh()
    expect(payload.engines[0]!.breaker).toEqual({ broken: false })
    expect(payload.engines[1]!.breaker).toEqual({ broken: true, reason: 'rate-limit', until: FIXED_NOW + 5_000 })
    expect(h.events).toContainEqual({ type: 'recovery', engineId: 'alpha', reason: 'quota-exhausted', at: FIXED_NOW })
    expect(h.events.filter(event => event.type === 'recovery' && event.engineId === 'beta')).toEqual([])
  })

  it('refresh ok remaining<=0 → 开日级熔断，行显示 quota-exhausted', async () => {
    const h = harness({
      engines: [fakeEngine('alpha')],
      probe: async manifest => ({ engineId: manifest.id, available: true, remaining: 0 }),
    })
    const payload = await h.service.refresh()
    expect(payload.engines[0]!.breaker).toEqual({ broken: true, reason: 'quota-exhausted', until: NEXT_MIDNIGHT })
  })

  it('R7 probe 永挂 → 单引擎硬超时返回 unavailable(超时)', async () => {
    const h = harness({
      engines: [fakeEngine('alpha')],
      perEngineTimeoutMs: 20,
      totalTimeoutMs: 200,
      probe: () => new Promise<QuotaReport>(() => {}),
    })
    const started = Date.now()
    const payload = await h.service.refresh()
    expect(Date.now() - started).toBeLessThan(1_000)
    expect(payload.engines[0]!.official).toMatchObject({
      kind: 'unavailable', reason: expect.stringContaining('超时'),
    })
  })

  it('R7 整次总截止优先：per-engine 未到点也按总截止返回', async () => {
    const h = harness({
      engines: [fakeEngine('alpha')],
      perEngineTimeoutMs: 5_000,
      totalTimeoutMs: 20,
      probe: () => new Promise<QuotaReport>(() => {}),
    })
    const payload = await h.service.refresh()
    expect(payload.engines[0]!.official).toMatchObject({
      kind: 'unavailable', reason: expect.stringContaining('总截止'),
    })
  })

  it('R8 并发 refresh 共享同一次探测：每引擎 quota() 恰好一次', async () => {
    let release!: () => void
    const gate = new Promise<void>(resolve => { release = resolve })
    const h = harness({
      engines: [fakeEngine('alpha')],
      probe: async manifest => {
        await gate
        return { engineId: manifest.id, available: true, remaining: 5 }
      },
    })
    const first = h.service.refresh()
    const second = h.service.refresh()
    expect(h.calls).toEqual(['alpha'])
    release()
    const [left, right] = await Promise.all([first, second])
    expect(h.calls).toEqual(['alpha'])
    expect(left.engines[0]!.official).toMatchObject({ kind: 'ok', remaining: 5 })
    expect(right.engines[0]!.official).toMatchObject({ kind: 'ok', remaining: 5 })
  })

  it('R9 跨日 refresh：day 为新一日，ledger 计数清零', async () => {
    let now = new Date(2026, 10, 8, 23, 59).getTime()
    const h = harness({
      engines: [fakeEngine('alpha')],
      now: () => now,
      probe: async manifest => ({ engineId: manifest.id, available: false, raw: 'N/A' }),
    })
    h.ledger.recordSuccess('alpha')
    expect(h.service.get().day).toBe('2026-11-08')
    expect(h.service.get().engines[0]!.ledger.success).toBe(1)
    now = new Date(2026, 10, 9, 0, 1).getTime()
    const payload = await h.service.refresh()
    expect(payload.day).toBe('2026-11-09')
    expect(payload.engines[0]!.ledger.success).toBe(0)
  })
})
