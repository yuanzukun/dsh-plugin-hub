import { describe, expect, it } from 'vitest'

import { blockedTargetError, guardTargetAddress, isPrivateAddress } from '../../src/support/address-guard.js'

describe('address guard', () => {
  it('rejects every non-unicast IP range', async () => {
    for (const address of ['fec0::1', '100::1', '2001:2::1']) {
      expect(isPrivateAddress(address)).toBe(true)
      await expect(guardTargetAddress(`http://[${address}]/doc.md`)).resolves.toMatchObject({
        allowed: false,
        address,
      })
    }
  })

  it('names the rejection as non-public unicast', () => {
    expect(blockedTargetError('http://[100::1]/doc.md', '100::1').message).toContain('不属于公网单播范围')
  })
})
