// 熔断器额度投影与日级解除单测（spec R3/R4）：纯状态机，注入固定时钟。
import { describe, expect, it } from 'vitest'
import type { QuotaReport } from '../../src/engines/contract.js'
import { CircuitBreaker, quotaReportSignal } from '../../src/support/breaker.js'
import type { BreakerEvent } from '../../src/support/breaker.js'

const NOW = Date.UTC(2026, 10, 8, 4, 0, 0)

function report(overrides: Partial<QuotaReport>): QuotaReport {
  return { engineId: 'alpha', available: true, ...overrides }
}

function harness(): { breaker: CircuitBreaker; events: BreakerEvent[] } {
  const events: BreakerEvent[] = []
  const breaker = new CircuitBreaker({ now: () => NOW, onEvent: event => events.push(event) })
  return { breaker, events }
}

describe('quotaReportSignal 官方快照投影', () => {
  it('available:false → 不产生信号', () => {
    expect(quotaReportSignal(report({ available: false, remaining: 0 }))).toBeUndefined()
  })

  it('remaining 缺失（如「不限」）→ 不产生信号', () => {
    expect(quotaReportSignal(report({ used: 12 }))).toBeUndefined()
  })

  it('remaining=0 → quota-exhausted', () => {
    expect(quotaReportSignal(report({ remaining: 0 }))).toEqual({ kind: 'quota-exhausted' })
  })

  it('remaining<0 → quota-exhausted', () => {
    expect(quotaReportSignal(report({ remaining: -3 }))).toEqual({ kind: 'quota-exhausted' })
  })

  it('remaining>0 → 不产生信号', () => {
    expect(quotaReportSignal(report({ remaining: 1 }))).toBeUndefined()
  })
})

describe('CircuitBreaker.clearDaily 日级解除', () => {
  it('quota-exhausted 日级条目被删除并发一条 recovery', () => {
    const { breaker, events } = harness()
    breaker.recordSignal('alpha', { kind: 'quota-exhausted' }, NOW)
    const status = breaker.clearDaily('alpha', NOW + 1_000)
    expect(status).toEqual({ broken: false })
    expect(breaker.isBroken('alpha', NOW + 1_000)).toBe(false)
    expect(events).toEqual([
      { type: 'open', engineId: 'alpha', reason: 'quota-exhausted', at: NOW, until: new Date(2026, 10, 9).getTime() },
      { type: 'recovery', engineId: 'alpha', reason: 'quota-exhausted', at: NOW + 1_000 },
    ])
  })

  it('insufficient-credits 同样按日级清除', () => {
    const { breaker, events } = harness()
    breaker.recordSignal('alpha', { kind: 'insufficient-credits' }, NOW)
    breaker.clearDaily('alpha', NOW + 1_000)
    expect(events.at(-1)).toEqual({ type: 'recovery', engineId: 'alpha', reason: 'insufficient-credits', at: NOW + 1_000 })
  })

  it('rate-limit 冷却不受影响：仍熔断、截止时刻不变、无 recovery', () => {
    const { breaker, events } = harness()
    breaker.recordSignal('beta', { kind: 'rate-limit', retryAfterMs: 5_000 }, NOW)
    const status = breaker.clearDaily('beta', NOW + 1_000)
    expect(status).toEqual({ broken: true, reason: 'rate-limit', cooldownUntil: NOW + 5_000 })
    expect(events.map(event => event.type)).toEqual(['open'])
  })

  it('未知引擎：返回未熔断且不发事件', () => {
    const { breaker, events } = harness()
    expect(breaker.clearDaily('ghost', NOW)).toEqual({ broken: false })
    expect(events).toEqual([])
  })
})
