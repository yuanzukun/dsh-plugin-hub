import { describe, expect, it } from 'vitest'
import { collectErrorCodes, renderErrorCatalog } from '../scripts/error-catalog.mjs'

describe('collectErrorCodes', () => {
  it('collects codes from string literals and sorts them', () => {
    const entries = collectErrorCodes([
      { path: 'src/b.ts', text: "throw new WebError('b', 'WEB_FETCH_TIMEOUT')" },
      { path: 'src/a.ts', text: 'throw new WebError("a", "WEB_ABORTED")' },
      { path: 'src/c.ts', text: "case 'WEB_ABORTED': return 'x'" },
    ])
    expect(entries).toEqual([
      { code: 'WEB_ABORTED', meaning: '调用方主动取消，未继续等待结果。', locations: ['src/a.ts', 'src/c.ts'] },
      { code: 'WEB_FETCH_TIMEOUT', meaning: '提取在总限时或单路限时内未完成。', locations: ['src/b.ts'] },
    ])
  })

  it('rejects an unknown code', () => {
    expect(() => collectErrorCodes([{ path: 'src/a.ts', text: "'WEB_UNKNOWN'" }]))
      .toThrow('WEB error code WEB_UNKNOWN in src/a.ts has no catalog meaning')
  })
})

describe('renderErrorCatalog', () => {
  it('renders the generated table', () => {
    const doc = renderErrorCatalog(collectErrorCodes([
      { path: 'src/a.ts', text: "'WEB_ABORTED'" },
    ]))
    expect(doc).toContain('| `WEB_ABORTED` | 调用方主动取消，未继续等待结果。 | `src/a.ts` |')
  })
})
