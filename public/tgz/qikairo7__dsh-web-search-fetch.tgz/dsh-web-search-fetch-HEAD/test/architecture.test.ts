// 架构不变量：编排层（search）与提取层（fetch）不得 import 具体引擎模块
// 或硬编码引擎 id——引擎知识只允许存在于 engines/registry.ts。
// 引擎清单与私有错误不得泄漏进编排层；本测试把该约束钉死为可执行断言。
import { readFileSync, readdirSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { describe, expect, it } from 'vitest'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')

const ORCHESTRATION_DIRS = ['src/search', 'src/fetch', 'src/support'] as const
const ENGINE_IDS = ['anysearch', 'tavily', 'firecrawl', 'exa', 'zhihu', 'aihot'] as const
/** 引擎层中对编排层开放的模块（契约、失败模型、HTTP 核心、注册表本体）。 */
const ALLOWED_ENGINE_IMPORTS = new Set(['contract', 'failure', 'http', 'registry'])

function tsFiles(dir: string): string[] {
  return readdirSync(join(root, dir), { recursive: true })
    .filter(name => String(name).endsWith('.ts'))
    .map(name => join(root, dir, String(name)))
}

/** 粗粒度剥离注释（块注释与行注释），让 id 检查只针对代码。 */
function stripComments(source: string): string {
  return source
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/(^|[^:])\/\/.*$/gm, '$1')
}

describe('R7 架构不变量：编排层无引擎知识穿透', () => {
  const files = ORCHESTRATION_DIRS.flatMap(tsFiles)

  it('检查范围非空（自身防呆：目录被移动时本测试必须红，而不是静默通过）', () => {
    expect(files.length).toBeGreaterThanOrEqual(10)
  })

  it('不 import 具体引擎模块（仅 contract/failure/http/registry 开放）', () => {
    const offenders: string[] = []
    for (const file of files) {
      const source = readFileSync(file, 'utf8')
      const imports = [...source.matchAll(/from '\.\.\/engines\/([a-z-]+)\.js'/g), ...source.matchAll(/from '\.\/engines\/([a-z-]+)\.js'/g)]
      for (const match of imports) {
        if (!ALLOWED_ENGINE_IMPORTS.has(match[1]!)) offenders.push(`${file}: engines/${match[1]}`)
      }
    }
    expect(offenders).toEqual([])
  })

  it('不硬编码引擎 id 字符串（注册表之外无第二份清单）', () => {
    const offenders: string[] = []
    for (const file of files) {
      const code = stripComments(readFileSync(file, 'utf8'))
      for (const id of ENGINE_IDS) {
        if (code.includes(`'${id}'`) || code.includes(`"${id}"`)) offenders.push(`${file}: '${id}'`)
      }
    }
    expect(offenders).toEqual([])
  })

  it('SearchRoutePlanner 只依赖抽象候选模型，不 import 引擎层', () => {
    const source = stripComments(readFileSync(join(root, 'src/search/planner.ts'), 'utf8'))
    expect(source).not.toContain('engines/')
    expect(source).not.toContain('EngineManifest')
  })

  it('registry 恰好注册六个引擎 id（防静默增删）', async () => {
    const { ENGINE_MANIFESTS } = await import('../src/engines/registry.js')
    expect(ENGINE_MANIFESTS.map(manifest => manifest.id)).toEqual([...ENGINE_IDS])
  })
})
