// 设置页表面契约（离线）。
// client/index.js 是经典脚本，只把工厂交给 window.__ModuleLoader__，Node 构建不触碰它；
// 本测试用替身装载该脚本，断言设置页暴露的服务表、凭证位、调用限制与 registry/Config 一致，
// 并检查已删除的旧服务名没有残留在客户端文件里。
import { readFileSync } from 'node:fs'
import { describe, expect, it, vi } from 'vitest'
import { ENGINE_MANIFESTS, RERANK_SERVICE } from '../src/engines/registry.js'
import { Config } from '../src/index.js'

/** React 替身：装载阶段只建元素，不渲染。 */
const reactStub = {
  createElement: (type: unknown, props: unknown, ...children: unknown[]) => ({ type, props, children }),
  useId: () => 'test-id',
  useRef: (value: unknown) => ({ current: value }),
  useEffect: (effect: () => unknown) => { effect() },
}
const jsxRuntimeStub = {
  jsx: (type: unknown, props: unknown) => ({ type, props }),
  jsxs: (type: unknown, props: unknown) => ({ type, props }),
  Fragment: Symbol('Fragment'),
}
const storeStub = {
  createSnapshotStore: (initial: unknown) => {
    let snapshot = initial
    return {
      getSnapshot: () => snapshot,
      subscribe: () => () => {},
      set: (next: unknown) => { snapshot = next },
    }
  },
}
const primitivesStub = {
  SettingsForm: 'SettingsForm',
  SettingsSecretField: 'SettingsSecretField',
  SegmentedControl: 'SegmentedControl',
  StateDot: 'StateDot',
  Tag: 'Tag',
  Button: 'Button',
  Switch: 'Switch',
  Input: 'Input',
  Checkbox: 'Checkbox',
  SettingsValueField: 'SettingsValueField',
}

/** 客户端脚本允许 require 的平台种子模块。 */
const seedModules: Record<string, unknown> = {
  react: reactStub,
  'react/jsx-runtime': jsxRuntimeStub,
  '@deepseek-ai/dsh-client-store': storeStub,
  '@deepseek-ai/dsh-client-ui-primitives': primitivesStub,
}

interface Registration {
  id: string
  factory: (require: (spec: string) => unknown) => Record<string, unknown>
}

/** 装载客户端脚本并返回它注册的模块导出。 */
function loadClient(): Record<string, any> {
  const source = readFileSync(new URL('../client/index.js', import.meta.url), 'utf8')
  const registrations: Registration[] = []
  const windowStub = {
    __ModuleLoader__: {
      load: (registration: Registration) => { registrations.push(registration) },
    },
  }
  const requireStub = (spec: string): unknown => {
    if (!(spec in seedModules)) throw new Error(`unexpected require("${spec}")`)
    return seedModules[spec]
  }
  new Function('window', 'require', source)(windowStub, requireStub)
  expect(registrations).toHaveLength(1)
  return registrations[0]!.factory(requireStub)
}

interface ClientService {
  id: string
  capabilities: string[]
  free: boolean
  keyless: boolean
  keylessCapabilities?: string[]
  auth: string
  enabledByDefault: boolean
}

interface CredentialSlot {
  id: string
  overridePaths: string[][]
  defaultRef: string
}

interface ClientSurface {
  serviceIds: string[]
  credentialRefs: string[]
  maxFetchServices: number
  localeKeys: { zh: string[]; en: string[] }
  localeValues: { zh: Record<string, string>; en: Record<string, string> }
  rerankModel: string
  quotaEngines: { id: string; period: string; official: boolean }[]
  anonymousServiceIds: string[]
  services: ClientService[]
  credentialSlots: CredentialSlot[]
}

const client = loadClient()
const surface = client.SURFACE as ClientSurface
const source = readFileSync(new URL('../client/index.js', import.meta.url), 'utf8')

/** schemastery 节点的可探属性：字段字典与 UI/默认值元数据。 */
interface SchemaNode {
  meta?: { role?: string; default?: unknown }
  dict?: Record<string, SchemaNode>
}

const configSchema = Config as unknown as SchemaNode

function configPath(path: string[]): SchemaNode | undefined {
  let node: SchemaNode | undefined = configSchema
  for (const segment of path) node = node?.dict?.[segment]
  return node
}

function configDefault(path: string[]): unknown {
  const node = configPath(path)
  expect(node, `Config 缺少路径 ${path.join('.')}`).toBeDefined()
  return node?.meta?.default
}

interface CredentialRefEntry { path: string; defaultValue: unknown }

/** 深度遍历 Config schema，收集所有 role('credential-ref') 字段。 */
function collectCredentialRefs(node: SchemaNode, path: string[] = []): CredentialRefEntry[] {
  const found: CredentialRefEntry[] = []
  if (node.meta?.role === 'credential-ref') found.push({ path: path.join('.'), defaultValue: node.meta.default })
  for (const [key, child] of Object.entries(node.dict ?? {})) {
    found.push(...collectCredentialRefs(child, [...path, key]))
  }
  return found
}

interface PageContext {
  ctx: Record<string, any>
  registrations: { options: Record<string, any>; component: (props: Record<string, any>) => unknown }[]
  scope: Record<string, any>
  mutate: ReturnType<typeof vi.fn>
}

/** 额度面板替身样例：五行覆盖四态（估算 / ok / unavailable / 未刷新 / 停用）。 */
const sampleQuotaPayload = {
  day: '2026-11-08',
  engines: [
    { id: 'anysearch', enabled: true, period: 'daily-utc', official: undefined,
      ledger: { success: 0, rateLimited: 0, quotaFailures: 0, day: '2026-11-8' }, breaker: { broken: false } },
    { id: 'tavily', enabled: true, period: 'monthly',
      official: { kind: 'ok', used: 12, limit: 1000, remaining: 988, resetsAt: '2026-12-01T00:00:00.000Z', fetchedAt: 1 },
      ledger: { success: 2, rateLimited: 0, quotaFailures: 0, day: '2026-11-8' }, breaker: { broken: false } },
    { id: 'firecrawl', enabled: true, period: 'monthly',
      official: { kind: 'unavailable', reason: 'keyless 提取（搜索需密钥）', fetchedAt: 2 },
      ledger: { success: 0, rateLimited: 0, quotaFailures: 0, day: '2026-11-8' }, breaker: { broken: false } },
    { id: 'zhihu', enabled: true, period: 'daily-bj', official: undefined,
      ledger: { success: 0, rateLimited: 0, quotaFailures: 0, day: '2026-11-8' }, breaker: { broken: false } },
    { id: 'aihot', enabled: false, period: 'none', official: undefined,
      ledger: { success: 0, rateLimited: 0, quotaFailures: 0, day: '2026-11-8' }, breaker: { broken: false } },
  ],
}
/** 刷新后的样例：Tavily 剩余从 988 变为 977。 */
const refreshedQuotaPayload = {
  ...sampleQuotaPayload,
  engines: sampleQuotaPayload.engines.map(row => row.id === 'tavily'
    ? { ...row, official: { kind: 'ok', used: 23, limit: 1000, remaining: 977, resetsAt: '2026-12-01T00:00:00.000Z', fetchedAt: 3 } }
    : row),
}
/** 等待额度通道的异步读取落库（get/refresh 均为 Promise）。 */
const flushPage = () => new Promise<void>(resolve => { setTimeout(resolve, 0) })

/** apply 与一次完整渲染所需的最小页面上下文替身。 */
function createPageContext(options: { connectionMissing?: boolean; payload?: Record<string, any>; refreshedPayload?: Record<string, any>; writable?: boolean; mutateResult?: boolean } = {}): PageContext {
  const registrations: PageContext['registrations'] = []
  let quotaPayload: Record<string, any> = options.payload ?? sampleQuotaPayload
  const refreshPayload = () => { quotaPayload = options.refreshedPayload ?? quotaPayload; return quotaPayload }
  const snapshot = { status: 'ready', value: {}, base: {}, user: {}, writable: options.writable !== false, revision: 1 }
  const mutate = vi.fn(async () => options.mutateResult !== false)
  const scope = {
    getSnapshot: () => snapshot,
    subscribe: () => () => {},
    mutate,
  }
  const ctx: Record<string, any> = {
    logger: { error: () => {}, warn: () => {}, info: () => {}, debug: () => {} },
    locale: {
      bind: () => (key: string) => key,
      register: () => () => {},
    },
    slots: {
      inject: (_name: string, register: () => unknown) => {
        return register()
      },
      register: (slotOptions: Record<string, any>, component: (props: Record<string, any>) => unknown) => {
        const registration = { options: slotOptions, component }
        registrations.push(registration)
        const dispose = () => {
          const index = registrations.indexOf(registration)
          if (index >= 0) registrations.splice(index, 1)
        }
        return dispose
      },
    },
    configForms: {
      get: () => scope,
      whileServed: (namespaces: string[], register: (served: Set<string>) => unknown) => {
        register(new Set(namespaces))
        return () => {}
      },
    },
    remote: {
      credentials: { describe: async () => ({ ok: true, value: {} }), set: async () => ({ ok: true }) },
      $on: () => () => {},
    },
    ...(options.connectionMissing ? {} : {
      connection: {
        rpc: {
          call: async (_channel: string, endpoint: string) => {
            if (endpoint === 'quotaPanel/refresh') return { ok: true, value: refreshPayload() }
            if (endpoint === 'quotaPanel/get') return { ok: true, value: quotaPayload }
            return { ok: false, error: { code: 'test/unknown', message: 'unknown endpoint ' + endpoint } }
          },
        },
      },
    }),
    effect: (factory: () => unknown) => { factory(); return () => {} },
  }
  return { ctx, registrations, scope, mutate }
}

/** 从 React 元素树中取出所有 SettingsSecretField 的 props；函数组件就地求值。 */
function collectSecretFields(node: unknown, out: Record<string, any>[]): void {
  if (node === null || typeof node !== 'object') return
  if (Array.isArray(node)) {
    for (const child of node) collectSecretFields(child, out)
    return
  }
  const element = node as { type?: unknown; props?: Record<string, any> }
  if (element.type === primitivesStub.SettingsSecretField && element.props) {
    out.push(element.props)
    return
  }
  if (typeof element.type === 'function') {
    collectSecretFields((element.type as (props: Record<string, any>) => unknown)(element.props ?? {}), out)
    return
  }
  if (element.props) {
    for (const value of Object.values(element.props)) collectSecretFields(value, out)
  }
}

/** 递归取元素树文本（函数组件就地求值；平台组件名当作字符串节点）。 */
function elementText(node: unknown): string {
  if (typeof node === 'string') return node
  if (typeof node === 'number') return String(node)
  if (Array.isArray(node)) return node.map(elementText).join(' ')
  if (node === null || typeof node !== 'object') return ''
  const element = node as { type?: unknown; props?: Record<string, any> }
  if (typeof element.type === 'function') {
    return elementText((element.type as (props: Record<string, any>) => unknown)(element.props ?? {}))
  }
  return elementText(element.props?.children)
}

/** 收集额度行（带 data-quota-engine 的节点）。 */
function collectQuotaRows(node: unknown, out: Record<string, any>[]): void {
  if (node === null || typeof node !== 'object') return
  if (Array.isArray(node)) { for (const child of node) collectQuotaRows(child, out); return }
  const element = node as { props?: Record<string, any> }
  if (typeof element.props?.['data-quota-engine'] === 'string') out.push(element)
  collectQuotaRows(element.props?.children, out)
}

/** 递归收集元素树中的全部元素；函数组件就地求值。 */
function collectAllElements(node: unknown, out: Record<string, any>[]): void {
  if (node === null || typeof node !== 'object') return
  if (Array.isArray(node)) { for (const child of node) collectAllElements(child, out); return }
  const element = node as { type?: unknown; props?: Record<string, any> }
  if (typeof element.type === 'function') {
    collectAllElements((element.type as (props: Record<string, any>) => unknown)(element.props ?? {}), out)
    return
  }
  if (element.type !== undefined) out.push(element)
  collectAllElements(element.props?.children, out)
}

/** 按标签名收集元素。 */
function collectByType(node: unknown, type: string): Record<string, any>[] {
  const elements: Record<string, any>[] = []
  collectAllElements(node, elements)
  return elements.filter(element => element.type === type)
}

/** 收集 h2 标题文本。 */
function collectHeadings(node: unknown, out: string[]): void {
  for (const element of collectByType(node, 'h2')) out.push(elementText(element.props?.children))
}

/** 收集平台 Button 元素。 */
function collectButtons(node: unknown, out: Record<string, any>[]): void {
  if (node === null || typeof node !== 'object') return
  if (Array.isArray(node)) { for (const child of node) collectButtons(child, out); return }
  const element = node as { type?: unknown; props?: Record<string, any> }
  if (element.type === primitivesStub.Button) out.push(element)
  collectButtons(element.props?.children, out)
}

describe('设置页表面（五引擎）', () => {
  it('服务表 = registry 五引擎 + 直接 HTTP；能力/鉴权/默认开关逐项对照 manifest', () => {
    const registryIds = ENGINE_MANIFESTS.map(manifest => manifest.id)
    expect([...surface.serviceIds].sort()).toEqual([...registryIds, 'http'].sort())
    expect(new Set(surface.serviceIds).size).toBe(surface.serviceIds.length)
    for (const manifest of ENGINE_MANIFESTS) {
      const service = surface.services.find(item => item.id === manifest.id)
      expect(service, `客户端缺少服务 ${manifest.id}`).toBeDefined()
      expect(service!.capabilities, `${manifest.id} 能力漂移`).toEqual([...manifest.capabilities])
      expect(service!.auth, `${manifest.id} 鉴权漂移`).toBe(manifest.auth)
      expect(service!.enabledByDefault, `${manifest.id} 默认开关漂移`).toBe(manifest.enabledByDefault ?? false)
      expect(service!.free, `${manifest.id} 免费标记漂移`).toBe(manifest.free === true)
      expect(service!.keyless, `${manifest.id} 免密钥标记漂移`).toBe(manifest.keyless === true)
      expect(service!.keylessCapabilities ?? [], `${manifest.id} 免密钥能力面漂移`)
        .toEqual([...(manifest.keylessCapabilities ?? [])])
    }
    const http = surface.services.find(item => item.id === 'http')
    expect(http, '客户端缺少直接 HTTP').toBeDefined()
    expect(http!.capabilities).toEqual(['fetch'])
    expect(http!.auth).toBe('anonymous')
    expect(http!.keyless).toBe(true)
    expect(http!.enabledByDefault).toBe(true)
  })

  it('匿名集合 = registry 中 auth==="keyless-fallback" 的引擎（http 单列）', () => {
    const keyless = ENGINE_MANIFESTS
      .filter(manifest => manifest.auth === 'keyless-fallback')
      .map(manifest => manifest.id)
    expect([...surface.anonymousServiceIds].sort()).toEqual([...keyless].sort())
    expect(surface.anonymousServiceIds).not.toContain('http')
  })

  it('RERANK_MODEL = registry 的 RERANK_SERVICE.model', () => {
    expect(surface.rerankModel).toBe(RERANK_SERVICE.model)
  })

  it('额度周期静态表 = registry，官方端点标记与 registry 一致', () => {
    expect(surface.quotaEngines.map(entry => entry.id)).toEqual(ENGINE_MANIFESTS.map(manifest => manifest.id))
    const officialIds = ENGINE_MANIFESTS
      .filter(manifest => manifest.endpoints.quota !== undefined)
      .map(manifest => manifest.id)
    for (const entry of surface.quotaEngines) {
      const manifest = ENGINE_MANIFESTS.find(candidate => candidate.id === entry.id)
      expect(entry.period, `${entry.id} 周期漂移`).toBe(manifest?.quotaPeriod ?? 'none')
      expect(entry.official, `${entry.id} 官方端点标记漂移`).toBe(officialIds.includes(entry.id))
    }
    expect(surface.quotaEngines.some(entry => entry.id === 'http')).toBe(false)
  })

  it('凭证位 = Config 中全部 credential-ref 字段（遍历 schema 默认值）', () => {
    const configRefs = collectCredentialRefs(configSchema)
    expect(configRefs).toHaveLength(5)
    expect(configRefs.map(entry => String(entry.defaultValue)).sort())
      .toEqual([...surface.credentialRefs].sort())
    const slotPaths = surface.credentialSlots
      .flatMap(slot => slot.overridePaths)
      .map(path => path.join('.'))
      .sort()
    expect(configRefs.map(entry => entry.path).sort()).toEqual(slotPaths)
    for (const slot of surface.credentialSlots) {
      expect(slot.overridePaths.length).toBeGreaterThan(0)
      for (const path of slot.overridePaths) {
        expect(configDefault(path), `Config ${path.join('.')} 默认引用`).toBe(slot.defaultRef)
      }
    }
  })

  it('调用上限与 registry 能力数量一致', () => {
    const fetchCount = ENGINE_MANIFESTS.filter(manifest => manifest.capabilities.includes('fetch')).length
    expect(surface.maxFetchServices).toBe(fetchCount)
  })

  it('zh/en 字典键一致（locale 同步）', () => {
    expect(surface.localeKeys.zh.length).toBeGreaterThan(0)
    expect([...surface.localeKeys.en].sort()).toEqual([...surface.localeKeys.zh].sort())
  })

  it('关键界面文案在 zh/en 都存在（含凭证位、状态键与能力键）', () => {
    const credentialSlotIds = surface.credentialSlots.map(slot => slot.id)
    const required = [
      ...surface.serviceIds.map(id => id + '-service'),
      ...surface.serviceIds.map(id => id + 'Hint'),
      'autoTitle', 'autoHint', 'enabledSummary', 'credentialSummary', 'useAnonymous',
      'servicesHint', 'behaviorTitle', 'behaviorHint',
      ...credentialSlotIds,
      'siliconflow', 'anysearchBaseURL', 'anysearchZone', 'firecrawlBaseURL', 'rerankTitle', 'rerankModel',
      'staged', 'checking', 'statusFailed', 'configured', 'partial', 'unconfigured', 'anonymous', 'anonymousPartial', 'noKey',
      'save', 'saving', 'discard', 'saved', 'saveFailed',
      'search', 'fetch', 'searchFetch', 'staticFetch', 'aiNews',
    ]
    for (const key of required) {
      expect(surface.localeKeys.zh, `zh 缺少 ${key}`).toContain(key)
      expect(surface.localeKeys.en, `en 缺少 ${key}`).toContain(key)
    }
    for (const id of credentialSlotIds) {
      expect(surface.localeValues.zh[id], `zh ${id} 标签为空`).toBeTruthy()
      expect(surface.localeValues.en[id], `en ${id} 标签为空`).toBeTruthy()
    }
  })

  it('不残留已删除的旧服务名与废弃预设', () => {
    // 宿主平台包作用域 @deepseek-ai/* 是 require 契约的一部分，不是服务引用；去掉后再查。
    const surfaceSource = source.replace(/@deepseek-ai\/[a-z0-9-]+/gi, '')
    const removedServices = ['deepseek', 'exa', 'keenable', 'crawl4ai', 'github', 'tinyfish', 'serply', 'kimi', 'bing']
    for (const id of removedServices) {
      expect(surfaceSource, `残留旧服务 ${id}`).not.toMatch(new RegExp(`(^|[^a-z0-9_])${id}([^a-z0-9_]|$)`, 'i'))
    }
    expect(surfaceSource).not.toMatch(/(^|[^a-z0-9_])balanced([^a-z0-9_]|$)/i)
    expect(surfaceSource).not.toMatch(/(^|[^a-z0-9_])deep([^a-z0-9_]|$)/i)
    for (const token of ["'single'", "'multi'", "'custom'", "'free'", 'singleChannelEscalate', 'maxSearchServices', 'controls.preset']) {
      expect(surfaceSource, `残留废弃预设 ${token}`).not.toContain(token)
    }
  })

  it('apply 注册设置面，卡片可完成一次渲染，默认开关 = manifest', () => {
    const { ctx, registrations } = createPageContext()
    ;(client.apply as (context: unknown) => void)(ctx)
    expect(registrations.length).toBeGreaterThanOrEqual(1)
    const tab = registrations[0]!
    const face = (tab.options.inject as () => Record<string, any>)()
    const snapshot = face.hooks.webSearchFetch.getSnapshot() as { engines: Record<string, boolean> }
    for (const manifest of ENGINE_MANIFESTS) {
      expect(snapshot.engines[manifest.id], `${manifest.id} 默认开关`).toBe(manifest.enabledByDefault ?? false)
    }
    expect(snapshot.engines.http, '直接 HTTP 默认开关').toBe(true)
    const props: Record<string, any> = {
      t: (key: string) => key,
      ...face,
      useWebSearchFetch: (selector: (value: unknown) => unknown) => selector(snapshot),
    }
    expect(() => tab.component(props)).not.toThrow()
  })

  it('页面区块标题为 h2，不再依赖 h3', () => {
    const { ctx, registrations } = createPageContext()
    ;(client.apply as (context: unknown) => void)(ctx)
    const tab = registrations.find(registration => registration.options.name === 'settings.plugins.tab')!
    const face = (tab.options.inject as () => Record<string, any>)()
    const snapshot = face.hooks.webSearchFetch.getSnapshot() as Record<string, any>
    const tree = tab.component({
      t: (key: string) => surface.localeValues.zh[key] ?? key,
      ...face,
      useWebSearchFetch: (selector: (value: unknown) => unknown) => selector(snapshot),
    })
    const h2 = collectByType(tree, 'h2').map(element => elementText(element.props?.children))
    const h3 = collectByType(tree, 'h3').map(element => elementText(element.props?.children))
    for (const key of ['servicesTitle', 'behaviorTitle', 'quotaTitle']) {
      expect(h2, `${key} 不是 h2 区块标题`).toContain(surface.localeValues.zh[key])
      expect(h3, `${key} 仍使用 h3`).not.toContain(surface.localeValues.zh[key])
    }
  })

  it('服务行不再生成 section 地标', () => {
    const { ctx, registrations } = createPageContext()
    ;(client.apply as (context: unknown) => void)(ctx)
    const tab = registrations.find(registration => registration.options.name === 'settings.plugins.tab')!
    const face = (tab.options.inject as () => Record<string, any>)()
    const snapshot = face.hooks.webSearchFetch.getSnapshot() as Record<string, any>
    const tree = tab.component({
      t: (key: string) => surface.localeValues.zh[key] ?? key,
      ...face,
      useWebSearchFetch: (selector: (value: unknown) => unknown) => selector(snapshot),
    })
    const serviceLabels = new Set(surface.services.map(service => surface.localeValues.zh[service.id + '-service']))
    const serviceSections = collectByType(tree, 'section')
      .filter(element => serviceLabels.has(String(element.props?.['aria-label'])))
    expect(serviceSections.map(element => element.props?.['aria-label']), '服务行仍是 section 地标').toEqual([])
  })

  it('AnySearch 端点与区域控件都关联 aria-describedby 提示', () => {
    const { ctx, registrations } = createPageContext()
    ;(client.apply as (context: unknown) => void)(ctx)
    const tab = registrations.find(registration => registration.options.name === 'settings.plugins.tab')!
    const face = (tab.options.inject as () => Record<string, any>)()
    const base = face.hooks.webSearchFetch.getSnapshot() as Record<string, any>
    const snapshot = { ...base, view: { ...base.view, expandedId: 'anysearch' } }
    const tree = tab.component({
      t: (key: string) => surface.localeValues.zh[key] ?? key,
      ...face,
      useWebSearchFetch: (selector: (value: unknown) => unknown) => selector(snapshot),
    })
    const elements: Record<string, any>[] = []
    collectAllElements(tree, elements)
    const endpointLabel = surface.localeValues.zh.anysearchBaseURL
    const zoneLabel = surface.localeValues.zh.anysearchZone
    const endpoint = elements.find(element =>
      (element.type === primitivesStub.Input || element.type === 'input')
      && element.props?.['aria-label'] === endpointLabel)
    const zone = elements.find(element =>
      element.type === 'select' && element.props?.['aria-label'] === zoneLabel)
    expect(endpoint, '缺少 AnySearch 端点 input').toBeDefined()
    expect(zone, '缺少 AnySearch 区域 select').toBeDefined()
    const ids = new Map<string, Record<string, any>>()
    for (const element of elements) {
      if (typeof element.props?.id === 'string') ids.set(element.props.id, element)
    }
    for (const [control, hintKey, label] of [
      [endpoint!, 'baseURLHint', endpointLabel],
      [zone!, 'zoneHint', zoneLabel],
    ] as const) {
      const describedBy = control.props?.['aria-describedby']
      expect(typeof describedBy, `${label} 缺少 aria-describedby`).toBe('string')
      const referencedIds = String(describedBy).trim().split(/\s+/).filter(Boolean)
      expect(referencedIds.length, `${label} 的 aria-describedby 为空`).toBeGreaterThan(0)
      for (const id of referencedIds) {
        const hint = ids.get(id)
        expect(hint, `${label} 的 aria-describedby 指向不存在的 ${id}`).toBeDefined()
        expect(elementText(hint), `${label} 未关联正确提示`).toContain(surface.localeValues.zh[hintKey])
      }
    }
  })

  it('只注册 settings.plugins.tab 与 plugins.bundle.config，不注册 settings.section', () => {
    const { ctx, registrations } = createPageContext()
    ;(client.apply as (context: unknown) => void)(ctx)
    const names = registrations.map(registration => registration.options.name)
    expect([...names].sort()).toEqual(['plugins.bundle.config', 'settings.plugins.tab'])
    expect(names).not.toContain('settings.section')
    expect(source, '仍残留 settings.section 兜底代码').not.toContain('settings.section')
  })

  it('渲染冒烟：五个凭证位的 KeyField 标签为可读文案而非原始 id', () => {
    const { ctx, registrations } = createPageContext()
    ;(client.apply as (context: unknown) => void)(ctx)
    const tab = registrations[0]!
    const face = (tab.options.inject as () => Record<string, any>)()
    const base = face.hooks.webSearchFetch.getSnapshot() as Record<string, any>
    const t = (key: string) => surface.localeValues.zh[key] ?? key
    const rendered = new Map<string, string>()
    for (const expandedId of [null, 'anysearch', 'tavily', 'firecrawl', 'zhihu']) {
      const snapshot = { ...base, view: { ...base.view, expandedId } }
      const props: Record<string, any> = {
        t,
        ...face,
        useWebSearchFetch: (selector: (value: unknown) => unknown) => selector(snapshot),
      }
      const fields: Record<string, any>[] = []
      collectSecretFields(tab.component(props), fields)
      for (const field of fields) rendered.set(String(field.id), String(field.label))
    }
    for (const slotId of surface.credentialSlots.map(slot => slot.id)) {
      const label = rendered.get(`plugin-config-web-search-fetch-${slotId}`)
      expect(label, `${slotId} 凭证位未渲染`).toBeDefined()
      expect(label, `${slotId} 仍显示原始 id`).not.toBe(slotId)
      expect(label, `${slotId} 与 zh 字典不一致`).toBe(surface.localeValues.zh[slotId])
    }
  })

  it('R11 额度小节：五行、四态标签、周期文案与刷新数值', async () => {
    const { ctx, registrations } = createPageContext({ refreshedPayload: refreshedQuotaPayload })
    ;(client.apply as (context: unknown) => void)(ctx)
    await flushPage()
    expect(registrations.map(registration => registration.options.name))
      .toEqual(['settings.plugins.tab', 'plugins.bundle.config'])
    const tab = registrations[0]!
    const face = (tab.options.inject as () => Record<string, any>)()
    const render = () => {
      const snapshot = face.hooks.webSearchFetch.getSnapshot() as Record<string, any>
      return tab.component({
        t: (key: string) => surface.localeValues.zh[key] ?? key,
        ...face,
        useWebSearchFetch: (selector: (value: unknown) => unknown) => selector(snapshot),
      })
    }
    const rows = () => {
      const out: Record<string, any>[] = []
      collectQuotaRows(render(), out)
      return out
    }
    const row = (id: string) => rows().find(item => item.props['data-quota-engine'] === id)!
    expect(rows().map(item => item.props['data-quota-engine']))
      .toEqual(['anysearch', 'tavily', 'firecrawl', 'zhihu', 'aihot'])
    expect(row('anysearch').props['data-quota-state']).toBe('estimate')
    expect(elementText(row('anysearch'))).toContain('估算')
    expect(elementText(row('anysearch'))).not.toContain('未刷新')
    expect(row('tavily').props['data-quota-state']).toBe('ok')
    expect(elementText(row('tavily'))).toContain('月额度')
    expect(elementText(row('tavily'))).toContain('988')
    expect(elementText(row('tavily'))).toContain('本地计数')
    expect(row('firecrawl').props['data-quota-state']).toBe('unavailable')
    expect(elementText(row('firecrawl'))).toContain('keyless 提取（搜索需密钥）')
    expect(elementText(row('firecrawl'))).toContain('仅提取免钥，搜索需密钥')
    expect(row('zhihu').props['data-quota-state']).toBe('never')
    expect(elementText(row('zhihu'))).toContain('未刷新')
    expect(elementText(row('zhihu'))).toContain('搜索两池合计，不含热榜/直答')
    expect(row('aihot').props['data-quota-state']).toBe('disabled')
    expect(elementText(row('aihot'))).toContain('已停用（未探测）')
    expect(elementText(row('anysearch'))).toContain('今日未使用')
    const headings: string[] = []
    collectHeadings(render(), headings)
    expect(headings).toContain('额度')
    expect(headings.some(text => text.includes('今日'))).toBe(false)
    const buttons: Record<string, any>[] = []
    collectButtons(render(), buttons)
    const refreshButton = buttons.find(button => elementText(button) === '刷新额度')
    expect(refreshButton, '缺少额度刷新按钮').toBeDefined()
    await refreshButton!.props.onClick()
    await flushPage()
    expect(elementText(row('tavily'))).toContain('977')
  })

  it('R12 连接缺失：额度小节显示通道不可用与原因，两张原生设置面仍注册', async () => {
    const { ctx, registrations } = createPageContext({ connectionMissing: true })
    ;(client.apply as (context: unknown) => void)(ctx)
    await flushPage()
    expect(registrations.map(registration => registration.options.name).sort())
      .toEqual(['plugins.bundle.config', 'settings.plugins.tab'])
    const tab = registrations.find(registration => registration.options.name === 'settings.plugins.tab')!
    const face = (tab.options.inject as () => Record<string, any>)()
    const snapshot = face.hooks.webSearchFetch.getSnapshot() as Record<string, any>
    expect(snapshot.quota.channelError).toBe(true)
    const text = elementText(tab.component({
      t: (key: string) => surface.localeValues.zh[key] ?? key,
      ...face,
      useWebSearchFetch: (selector: (value: unknown) => unknown) => selector(snapshot),
    }))
    expect(text).toContain('额度数据通道不可用')
    expect(text).toContain('连接服务不可用')
  })

  it('无草稿时保留 role=status 实时区域且不渲染保存栏，修改后保存栏出现', () => {
    const { ctx, registrations } = createPageContext()
    ;(client.apply as (context: unknown) => void)(ctx)
    const tab = registrations[0]!
    const face = (tab.options.inject as () => Record<string, any>)()
    const render = () => {
      const snapshot = face.hooks.webSearchFetch.getSnapshot() as Record<string, any>
      return tab.component({
        t: (key: string) => surface.localeValues.zh[key] ?? key,
        ...face,
        useWebSearchFetch: (selector: (value: unknown) => unknown) => selector(snapshot),
      })
    }
    const statusRegions = () => {
      const elements: Record<string, any>[] = []
      collectAllElements(render(), elements)
      return elements.filter(element => element.props?.role === 'status')
    }
    const labels = () => {
      const buttons: Record<string, any>[] = []
      collectButtons(render(), buttons)
      return buttons.map(button => elementText(button))
    }
    expect(statusRegions().length, '无草稿时缺少 role=status 实时区域').toBeGreaterThan(0)
    expect(labels()).not.toContain('保存更改')
    face.editControl('searchServices', ['anysearch'])
    expect(statusRegions().length, '修改后 role=status 实时区域被卸载').toBeGreaterThan(0)
    expect(labels()).toContain('保存更改')
  })

  it('代数独立：凭证引用变化触发的重读不作废在途额度刷新', async () => {
    const page = createPageContext({ refreshedPayload: refreshedQuotaPayload })
    let onReferenceUpdated: ((ref: string) => void) | undefined
    page.ctx.remote.$on = (_event: string, handler: (ref: string) => void) => {
      onReferenceUpdated = handler
      return () => {}
    }
    ;(client.apply as (context: unknown) => void)(page.ctx)
    await flushPage()
    // 初始 get 已落地（Tavily 988）；把 refresh 端点的 rpc 调用换成挂起态。
    let releaseRefresh: ((value: unknown) => void) | undefined
    const rpc = (page.ctx.connection as Record<string, any>).rpc as Record<string, any>
    const originalCall = rpc.call
    rpc.call = (channel: string, endpoint: string, payload: unknown, signal?: unknown) => {
      if (endpoint === 'quotaPanel/refresh') return new Promise(resolve => { releaseRefresh = resolve })
      return originalCall(channel, endpoint, payload, signal)
    }
    const tab = page.registrations.find(registration => registration.options.name === 'settings.plugins.tab')!
    const face = (tab.options.inject as () => Record<string, any>)()
    const refreshPromise = Promise.resolve((face.refreshQuota as () => Promise<unknown>)()).catch(() => {})
    await flushPage()
    // 凭证引用变化 → 一次新的 readCredentials（立即完成，bump 凭证代数）。
    expect(onReferenceUpdated, '未捕获 credentials/reference-updated 订阅').toBeDefined()
    onReferenceUpdated!('TAVILY_API_KEY')
    await flushPage()
    // 放行额度刷新响应：若额度与凭证共用同一代数计数器，晚到的响应被作废，977 永不出现。
    expect(releaseRefresh, '面板未发起额度刷新').toBeDefined()
    releaseRefresh!({ ok: true, value: refreshedQuotaPayload })
    await refreshPromise
    await flushPage()
    const snapshot = face.hooks.webSearchFetch.getSnapshot() as Record<string, any>
    expect(snapshot.quota.channelError).toBe(false)
    const rows: Record<string, any>[] = []
    collectQuotaRows(tab.component({
      t: (key: string) => surface.localeValues.zh[key] ?? key,
      ...face,
      useWebSearchFetch: (selector: (value: unknown) => unknown) => selector(snapshot),
    }), rows)
    const tavily = rows.find(row => row.props['data-quota-engine'] === 'tavily')
    expect(tavily, '额度行未渲染').toBeDefined()
    expect(elementText(tavily!)).toContain('977')
  })

})

describe('设置页保存（离线）', () => {
  function applyPage(options: Parameters<typeof createPageContext>[0] = {}) {
    const page = createPageContext(options)
    ;(client.apply as (context: unknown) => void)(page.ctx)
    const registration = page.registrations.find(row => row.options.name === 'settings.plugins.tab')!
    return { page, face: (registration.options.inject as () => Record<string, any>)() }
  }

  it('保存把 controls 与 option 草稿提交给 scope.mutate', async () => {
    const { page, face } = applyPage()
    face.editControl('searchServices', ['anysearch'])
    face.editOption('anysearchZone', 'cn')
    await face.save()
    expect(page.mutate).toHaveBeenCalledTimes(1)
    const [ops, revision] = page.mutate.mock.calls[0]!
    expect(ops).toEqual([
      { op: 'set', path: ['controls', 'searchServices'], value: ['anysearch'] },
      { op: 'set', path: ['anysearchZone'], value: 'cn' },
    ])
    expect(revision).toBe(1)
    expect((face.hooks.webSearchFetch.getSnapshot() as Record<string, any>).saved).toBe(true)
  })

  it('writable=false 时不调用 mutate，也不伪装保存成功', async () => {
    const { page, face } = applyPage({ writable: false })
    face.editControl('searchServices', ['anysearch'])
    await face.save()
    expect(page.mutate).not.toHaveBeenCalled()
    const state = face.hooks.webSearchFetch.getSnapshot() as Record<string, any>
    expect(state.saved).toBe(false)
    expect(state.failed).toBe(false)
  })

  it('mutate 拒绝时 failed=true，草稿保留', async () => {
    const { page, face } = applyPage({ mutateResult: false })
    face.editControl('searchServices', ['anysearch'])
    await face.save()
    expect(page.mutate).toHaveBeenCalledTimes(1)
    const state = face.hooks.webSearchFetch.getSnapshot() as Record<string, any>
    expect(state.failed).toBe(true)
    expect(state.saved).toBe(false)
    expect(state.dirty).toBe(true)
  })
})
