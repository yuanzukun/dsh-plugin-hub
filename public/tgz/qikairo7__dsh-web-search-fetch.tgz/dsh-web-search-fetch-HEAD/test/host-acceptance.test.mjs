import { describe, expect, it } from 'vitest'
import { validateDumpConfig, validateTarEntries } from '../scripts/host-acceptance.mjs'

describe('host acceptance assertions', () => {
  it('accepts a package with server entries and no client', () => {
    expect(validateTarEntries(['package/package.json', 'package/lib/index.js'])).toEqual([])
  })

  it('rejects a distributed client directory and missing server entries', () => {
    expect(validateTarEntries(['package/client/index.js'])).toEqual([
      'package/package.json is missing',
      'package/lib/index.js is missing',
      'package/client/ must not be distributed',
    ])
  })

  it('accepts YAML and JSON provider spellings', () => {
    expect(validateDumpConfig('web-search-fetch:\n  searchProvider: aggregated\n  fetchProvider: aggregated')).toEqual([])
    expect(validateDumpConfig('{"plugins":{"web-search-fetch":{}},"searchProvider":"aggregated","fetchProvider":"aggregated"}')).toEqual([])
  })
})
