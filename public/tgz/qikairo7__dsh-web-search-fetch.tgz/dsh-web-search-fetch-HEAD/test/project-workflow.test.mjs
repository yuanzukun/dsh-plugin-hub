import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'

const skill = readFileSync('.agents/skills/project-workflow/SKILL.md', 'utf8')

describe('project workflow', () => {
  it('defines four independent read-only audit lanes', () => {
    const lanes = [...skill.matchAll(/^   - (Documentation|Architecture|Verification|Simplification):/gmu)].map(match => match[1])
    expect(lanes).toEqual(['Documentation', 'Architecture', 'Verification', 'Simplification'])
    expect(skill).toContain('do not modify files')
  })

  it('binds the Skill to Codex multi-agent tools and deterministic evidence', () => {
    expect(skill).toContain('name: project-workflow')
    expect(skill).toContain('multi_agent_v1__spawn_agent')
    expect(skill).toContain('multi_agent_v1__wait_agent')
    expect(skill).toContain('multi_agent_v1__close_agent')
    expect(skill).toContain('do not simulate parallel agents')
    expect(skill).toContain('Wait once for all children')
    expect(skill).toContain('pnpm run change-scope')
    expect(skill).toContain('native agent tools')
  })
})
