// 装配层意图→引擎映射单测（ADR-0001 §1/§2）：R7 允许引擎 id 只出现在装配层。
import { describe, expect, it } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import { remoteMethods } from '@deepseek-ai/dsh-typert-protocol'
import type { Engine, QuotaReport } from '../src/engines/contract.js'
import { ENGINE_MANIFESTS } from '../src/engines/registry.js'
import type { QueryAnalysis, SearchIntent } from '../src/search/router.js'
import { createQuotaPanelRuntime, DEFAULT_FETCH_SERVICES, intentEnginePriority, QuotaPanelRemote } from '../src/index.js'
import { CircuitBreaker } from '../src/support/breaker.js'
import { QuotaLedger } from '../src/support/quota-ledger.js'

type SearchPreference = NonNullable<QueryAnalysis['prefer']>

const SEARCH_PREFERENCES = ['general-web', 'developer'] as const satisfies readonly SearchPreference[]
const ROUTE_MATRIX = {
  'ai-news': { default: ['aihot'], preferences: { 'general-web': ['aihot'], developer: ['aihot'] } },
  'community-opinion': { default: ['zhihu'], preferences: { 'general-web': ['zhihu'], developer: ['firecrawl', 'tavily'] } },
  'hot-list': { default: ['aihot', 'zhihu'], preferences: { 'general-web': ['aihot', 'zhihu'], developer: ['aihot', 'zhihu'] } },
  'vertical-data': { default: ['anysearch'], preferences: { 'general-web': ['anysearch'], developer: ['anysearch'] } },
  'english-web': { default: ['tavily', 'firecrawl'], preferences: { 'general-web': ['tavily', 'firecrawl'], developer: ['firecrawl', 'tavily'] } },
  research: { default: [], preferences: { 'general-web': [], developer: [] } },
  'chinese-web': { default: ['zhihu'], preferences: { 'general-web': ['zhihu'], developer: ['firecrawl', 'tavily'] } },
} satisfies Record<SearchIntent, {
  default: readonly string[]
  preferences: Record<SearchPreference, readonly string[]>
}>

describe('装配层意图→引擎映射', () => {
  it('穷尽所有意图与偏好，候选链保持显式契约', () => {
    for (const intent of Object.keys(ROUTE_MATRIX) as SearchIntent[]) {
      const preferences: Array<SearchPreference | undefined> = [undefined, ...SEARCH_PREFERENCES]
      for (const prefer of preferences) {
        expect(intentEnginePriority(intent, prefer))
          .toEqual(prefer === undefined ? ROUTE_MATRIX[intent].default : ROUTE_MATRIX[intent].preferences[prefer])
      }
    }
  })

  it('默认提取服务派生自 registry，包含知乎问题回答', () => {
    expect(DEFAULT_FETCH_SERVICES).toEqual(['anysearch', 'tavily', 'firecrawl', 'zhihu'])
  })
})

// ---- 装配层面板接线与周期映射 ----

const PANEL_NOW = new Date(2026, 10, 8, 12, 0, 0).getTime()

/** 只给指定 id 配 quota()；其余引擎保持无额度端点。 */
function panelEngines(probeIds: readonly string[], quota: (id: string) => Promise<QuotaReport>): readonly Engine[] {
  return ENGINE_MANIFESTS.map(manifest => probeIds.includes(manifest.id)
    ? { manifest, quota: () => quota(manifest.id) }
    : { manifest })
}

function panelControls(): { serviceEnabled: Record<string, boolean>; maxRequests: number } {
  return {
    serviceEnabled: Object.fromEntries(ENGINE_MANIFESTS.map(manifest => [manifest.id, true])),
    maxRequests: 32,
  }
}

describe('装配层面板接线', () => {
  it('只探测有 quota() 的引擎；刷新写仓并按剩余量投影熔断', async () => {
    const calls: string[] = []
    let face: string | undefined
    const breaker = new CircuitBreaker({ now: () => PANEL_NOW })
    const runtime = createQuotaPanelRuntime({
      engines: panelEngines(['tavily'], async id => {
        calls.push(id)
        return { engineId: id, available: true, used: 1, limit: 100, remaining: 0 }
      }),
      ledger: new QuotaLedger({ now: () => PANEL_NOW }),
      breaker,
      buildContext: async (manifest, op, lane) => {
        face = lane.face
        return {
          signal: lane.signal,
          deadline: lane.deadline,
          endpoint: manifest.endpoints.quota ?? 'https://invalid.local',
          countRequest: () => op.countRequest(),
        }
      },
      resolveControls: panelControls,
      now: () => PANEL_NOW,
    })
    const payload = await runtime.service.refresh()
    expect(calls).toEqual(['tavily'])
    expect(face).toBe('quota')
    expect(payload.engines).toHaveLength(5)
    expect(runtime.store.get('tavily')).toMatchObject({ kind: 'ok', remaining: 0 })
    expect(payload.engines.find(row => row.id === 'tavily')!.breaker)
      .toMatchObject({ broken: true, reason: 'quota-exhausted' })
    expect(payload.engines.find(row => row.id === 'anysearch')!.official).toBeUndefined()
  })

  it('凭据解析异常 → 该引擎零请求且固定原因，其余引擎照常探测', async () => {
    const calls: string[] = []
    const runtime = createQuotaPanelRuntime({
      engines: panelEngines(['tavily', 'firecrawl'], async id => {
        calls.push(id)
        return { engineId: id, available: true, remaining: 3 }
      }),
      ledger: new QuotaLedger({ now: () => PANEL_NOW }),
      breaker: new CircuitBreaker({ now: () => PANEL_NOW }),
      buildContext: async (manifest, op, lane) => {
        if (manifest.id === 'tavily') throw new Error('credentials service down')
        return {
          signal: lane.signal,
          deadline: lane.deadline,
          endpoint: manifest.endpoints.quota ?? 'https://invalid.local',
          countRequest: () => op.countRequest(),
        }
      },
      resolveControls: panelControls,
      now: () => PANEL_NOW,
    })
    const payload = await runtime.service.refresh()
    expect(calls).toEqual(['firecrawl'])
    expect(payload.engines.find(row => row.id === 'tavily')!.official)
      .toMatchObject({ kind: 'unavailable', reason: '凭证服务不可用' })
    expect(payload.engines.find(row => row.id === 'firecrawl')!.official)
      .toMatchObject({ kind: 'ok', remaining: 3 })
  })
})

describe('Typert 宿主薄包装', () => {
  it('get/refresh 写入 Gateway 可发现的 Remote 标记', () => {
    const runtime = createQuotaPanelRuntime({
      engines: panelEngines([], async () => ({ engineId: 'none', available: false })),
      ledger: new QuotaLedger({ now: () => PANEL_NOW }),
      breaker: new CircuitBreaker({ now: () => PANEL_NOW }),
      buildContext: async () => { throw new Error('not used') },
      resolveControls: panelControls,
      now: () => PANEL_NOW,
    })
    const remote = new QuotaPanelRemote(new Context(), runtime.service)
    expect(remote.typertRemote.namespace).toBe('quotaPanel')
    expect(remoteMethods(remote).map(marker => marker.method)).toEqual(['get', 'refresh'])
  })
})
