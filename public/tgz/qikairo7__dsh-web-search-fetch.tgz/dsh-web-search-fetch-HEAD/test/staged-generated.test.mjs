import { describe, expect, it } from 'vitest'
import { findMissingStaged } from '../scripts/check-staged-generated.mjs'

describe('findMissingStaged', () => {
  it('requires generated catalogs and lib files to be staged with their source', () => {
    const errors = findMissingStaged({
      staged: new Set(['src/engines/registry.ts', 'src/index.ts']),
      changed: new Set([
        'docs/engine-catalog.md',
        'client/index.js',
        'docs/config-catalog.md',
        'docs/error-catalog.md',
        'docs/module-graph.md',
        'lib/index.js',
      ]),
    })
    expect(errors).toEqual([
      'docs/engine-catalog.md: stage the regenerated file with src/engines/registry.ts',
      'client/index.js: stage the regenerated file with src/engines/registry.ts',
      'docs/config-catalog.md: stage the regenerated file with src/index.ts',
      'docs/error-catalog.md: stage the regenerated file with src changes',
      'docs/module-graph.md: stage the regenerated file with src changes',
      'lib/index.js: stage the rebuilt lib file with src changes',
    ])
  })

  it('requires the DSH field snapshot with dependency changes', () => {
    expect(findMissingStaged({
      staged: new Set(['package.json']),
      changed: new Set(['docs/dsh-web-interface-fields.json']),
    })).toEqual(['docs/dsh-web-interface-fields.json: stage the regenerated file with dependency changes'])
  })

  it('accepts generated artifacts already staged', () => {
    expect(
      findMissingStaged({
        staged: new Set(['src/index.ts', 'docs/config-catalog.md', 'docs/error-catalog.md', 'lib/index.js']),
        changed: new Set(['docs/config-catalog.md', 'docs/error-catalog.md', 'lib/index.js']),
      }),
    ).toEqual([])
  })
})
