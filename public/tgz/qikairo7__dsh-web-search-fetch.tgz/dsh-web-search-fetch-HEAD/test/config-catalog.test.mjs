import { describe, expect, it } from 'vitest'
import { collectConfigFields, renderConfigCatalog } from '../scripts/config-catalog.mjs'

const schema = {
  dict: {
    controls: {
      dict: {
        maxRequests: {
          type: 'number',
          meta: { default: 32, min: 1, max: 256, description: '请求上限。' },
        },
        serviceEnabled: {
          type: 'dict',
          meta: { default: {}, description: '服务开关。' },
        },
      },
    },
    anysearchZone: {
      type: 'union',
      meta: { description: '区域。' },
      toString: () => '"cn" | "intl" | ""',
    },
    rerank: {
      dict: {
        apiKeyEnv: {
          type: 'string',
          meta: { role: 'credential-ref', default: 'SILICONFLOW_API_KEY', description: '重排密钥引用。' },
        },
      },
    },
  },
}

describe('collectConfigFields', () => {
  it('projects every leaf field with type, default, constraint and description', () => {
    expect(collectConfigFields(schema)).toEqual([
      { path: 'controls.maxRequests', type: 'number', default: '`32`', constraint: '1–256', description: '请求上限。' },
      { path: 'controls.serviceEnabled', type: '{ [key: string]: boolean }', default: '`{}`', constraint: '—', description: '服务开关。' },
      { path: 'anysearchZone', type: '"cn" / "intl" / ""', default: '未设置', constraint: '—', description: '区域。' },
      { path: 'rerank.apiKeyEnv', type: 'string', default: '`SILICONFLOW_API_KEY`', constraint: '凭证引用', description: '重排密钥引用。' },
    ])
  })

  it('rejects a field without a description', () => {
    expect(() => collectConfigFields({ dict: { missing: { type: 'string', meta: {} } } }))
      .toThrow('Config field missing must have a description')
  })
})

describe('renderConfigCatalog', () => {
  it('renders the generated table and notes', () => {
    const doc = renderConfigCatalog(collectConfigFields(schema))
    expect(doc).toContain('| `controls.maxRequests` | `number` | `32` | 1–256 | 请求上限。 |')
    expect(doc).toContain('| `anysearchZone` | `"cn" / "intl" / ""` | 未设置 | — | 区域。 |')
    expect(doc).toContain('凭证字段只保存引用名')
  })
})
