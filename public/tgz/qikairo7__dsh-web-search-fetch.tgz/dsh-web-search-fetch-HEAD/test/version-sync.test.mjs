import { describe, expect, it } from 'vitest'
import { checkVersionSync } from '../scripts/check-version-sync.mjs'

const pkg = {
  version: '0.4.6',
  engines: { dsh: '>=0.2.2-rc.1' },
  devDependencies: { '@deepseek-ai/dsh-web': '0.2.2-rc.1' },
}

const documents = {
  'README.md': '当前开发线为 `0.4.6`；DSH 0.2.2-rc.1',
  'docs/dsh-web-interface.md': 'DSH `0.2.2-rc.1`',
  'docs/glossary.md': 'DSH `0.2.2-rc.1`',
}

describe('version sync', () => {
  it('accepts the current package/document versions', () => {
    expect(checkVersionSync(pkg, documents)).toEqual([])
  })

  it('rejects a different DSH pin or package version', () => {
    expect(checkVersionSync({ ...pkg, devDependencies: { '@deepseek-ai/dsh-web': '0.2.3' } }, documents))
      .toContain('README.md: must mention DSH 0.2.3')
    expect(checkVersionSync(pkg, { ...documents, 'README.md': '当前开发线为 `0.4.7`；DSH 0.2.2-rc.1' }))
      .toContain('README.md: current development version must be 0.4.6')
  })
})
