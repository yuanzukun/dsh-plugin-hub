import { describe, expect, it } from 'vitest'
import { missingExportJsdoc } from '../scripts/check-export-jsdoc.mjs'

describe('export JSDoc', () => {
  it('requires a JSDoc block before exported declarations', () => {
    expect(missingExportJsdoc('/** Contract. */\nexport const value = 1\n', 'src/example.ts')).toEqual([])
    expect(missingExportJsdoc('export const value = 1\n', 'src/example.ts'))
      .toContain('src/example.ts:1: exported declaration needs a JSDoc comment')
  })
})
