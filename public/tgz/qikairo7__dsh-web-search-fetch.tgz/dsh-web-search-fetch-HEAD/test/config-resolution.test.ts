// Config 解析形状回归：cordis 经 ~standard.validate 解析插件配置，根级 volatile 返回
// 实时引用（Volatile<T>）。引用经 JSON.stringify 得到 {} 是设计行为，不是值丢失；
// 消费端必须调用 .get() 读取当前快照。本测试锚定 .get() 后的形状，防止
// "把引用当普通 JSON" 的回归。
import { describe, expect, it } from 'vitest'
import type { Volatile } from '@deepseek-ai/cosmokit'
import { Config } from '../src/index.js'

type PlainConfig = Record<string, unknown> & {
  controls?: Record<string, unknown>
  rerank?: Record<string, unknown>
}

const RAW = {
  anysearchApiKeyEnv: 'MY_ANY_KEY',
  rerank: { apiKeyEnv: 'MY_SF_KEY' },
  controls: { preset: 'multi', maxRequests: 12 },
}

async function validate(raw: Record<string, unknown>) {
  return (await Config['~standard'].validate(raw)) as {
    value?: Volatile<PlainConfig>
    issues?: unknown[]
  }
}

describe('Config 解析形状（~standard 路径，根级 volatile）', () => {
  it('validate 返回实时引用；.get() 后凭证引用与端点字段为字符串', async () => {
    const result = await validate(RAW)
    expect(result.issues, JSON.stringify(result.issues ?? [])).toBeUndefined()
    const ref = result.value
    expect(ref).toBeDefined()
    // 引用本身不参与 JSON 序列化：{} 是设计形状，不是值丢失。
    expect(JSON.stringify(ref)).toBe('{}')
    const value = ref!.get()
    expect(value.anysearchApiKeyEnv).toBe('MY_ANY_KEY')
    expect((value.rerank as Record<string, unknown>)?.apiKeyEnv).toBe('MY_SF_KEY')
    for (const field of ['anysearchBaseURL', 'tavilyApiKeyEnv', 'firecrawlApiKeyEnv', 'firecrawlBaseURL', 'zhihuApiKeyEnv']) {
      expect(typeof value[field], `${field} 应为 string 或 undefined，不得为对象`).not.toBe('object')
    }
  })

  it('controls 嵌套字段按类型解析（默认值生效）', async () => {
    const result = await validate({})
    const value = result.value!.get()
    expect(value.controls?.preset).toBe('auto')
    expect(value.controls?.maxRequests).toBe(32)
    expect(value.controls?.maxFetchServices).toBe(4)
    expect(value.controls?.fetchServices).toEqual(['anysearch', 'tavily', 'firecrawl', 'zhihu'])
    expect((value.rerank as Record<string, unknown>)?.apiKeyEnv).toBe('SILICONFLOW_API_KEY')
    expect(value.controls?.serviceEnabled).toEqual({})
  })

  it('anysearchZone 解析为 cn，缺省为 undefined（缺省不发送 zone 字段）', async () => {
    const withZone = await validate({ ...RAW, anysearchZone: 'cn' })
    expect(withZone.issues, JSON.stringify(withZone.issues ?? [])).toBeUndefined()
    expect(withZone.value!.get().anysearchZone).toBe('cn')

    const withoutZone = await validate(RAW)
    expect(withoutZone.value!.get().anysearchZone).toBeUndefined()

    const emptyZone = await validate({ ...RAW, anysearchZone: '' })
    expect(emptyZone.issues, JSON.stringify(emptyZone.issues ?? [])).toBeUndefined()
    expect(emptyZone.value!.get().anysearchZone).toBe('')

    // schemastery 会把未声明的键原样透传：只有非法值的 issue 才能证明 schema 真的声明了该字段。
    const invalidZone = await validate({ ...RAW, anysearchZone: 'xx' })
    expect(invalidZone.issues?.length ?? 0).toBeGreaterThan(0)
  })
})
