import { describe, expect, it } from 'vitest'
import { validateDocIndex, validateDocKindExemplars, validateDocKinds } from '../scripts/check-doc-index.mjs'

describe('documentation index and kinds', () => {
  it('requires a known kind and reports stale entries', () => {
    expect(validateDocKinds(['docs/a.md'], { 'docs/a.md': 'reference' })).toEqual([])
    expect(validateDocKinds(['docs/a.md'], { 'docs/a.md': 'unknown', 'docs/old.md': 'reference' }))
      .toEqual(expect.arrayContaining(['docs/a.md: unknown kind unknown', 'docs/old.md: stale kind entry']))
  })

  it('requires every authored document to be linked from an index', () => {
    expect(validateDocIndex(['docs/a.md'], { '/repo/docs/README.md': '[a](a.md)' }, '/repo')).toEqual([])
    expect(validateDocIndex(['docs/orphan.md'], { '/repo/docs/README.md': '[a](a.md)' }, '/repo'))
      .toContain('docs/orphan.md: not linked from docs/README.md or docs/adr/README.md')
  })

  it('requires an existing exemplar for every used kind', () => {
    expect(validateDocKindExemplars({ 'docs/a.md': 'reference' }, { reference: 'docs/a.md' }, ['docs/a.md'])).toEqual([])
    expect(validateDocKindExemplars({ 'docs/a.md': 'missing' }, {}, ['docs/a.md']))
      .toContain('kind missing: missing exemplar in docs/doc-kind-exemplars.json')
  })
})
