# dsh-web-search-fetch

[![MIT 许可](https://img.shields.io/badge/license-MIT-blue.svg)](./LICENSE)
[![Node.js](https://img.shields.io/badge/Node.js-22.19%20%7C%2024%2B-green.svg)](./package.json)

**面向资料研究的 DSH 插件：五个搜索引擎加 HTTP 抓取，融合搜索、整理正文、保留来源与差异。**

面向 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)（DSH）的网络搜索与网页提取插件。它把 AnySearch AI、Tavily、Firecrawl、知乎、AIHOT 五家搜索引擎与内置 HTTP 抓取聚合到原生 `web_search` / `web_fetch` 两个 provider 后面，不新增模型工具、MCP 服务、常驻浏览器或外部 CLI。新安装默认启用 AnySearch、Tavily、Firecrawl 与直接 HTTP 抓取；AnySearch、Tavily 未配密钥时走官方匿名额度，Firecrawl 的提取面可用官方免钥免费层、搜索仍需 `fc-` 密钥，知乎与 AIHOT 为可选增强、默认关闭。知乎问题 URL 的提取走 `question_answers` API，直接读取回答摘要，不再抓网页。搜索结果经 URL 归一与 RRF 融合，可选用 SiliconFlow `BAAI/bge-reranker-v2-m3` 重排；动态网页走两段式探测与多源正文整理。v0.4 新增按查询意图路由：七类意图（AI 资讯、知乎观点、热点榜单、结构化取数、调研对比、英文网页、中文网页）与 AnySearch 39 个垂直频道由本地确定性规则判定，不需要模型凭证；热点榜单走知乎热榜（AIHOT 热点榜兜底），知乎观点可附知乎直答，垂直取数结果可走结构化数据通道；相同查询按意图分档缓存，本地额度账本在额度耗尽前换路。v0.3 的查询语法翻译保留：`site:`、`-site:`、`lang:`、`after:`、`before:` 会映射到引擎原生参数，不支持的写法逐字回拼，不静默丢弃。

[快速开始](#快速开始) · [项目定位与证据](#项目定位与证据) · [配置参考](./docs/configuration.md) · [正文整理](./docs/content-organization.md) · [常见问题](./docs/troubleshooting.md) · [参与贡献](./CONTRIBUTING.md)

```sh
dsh plugin --profile web add https://github.com/qikairo7/dsh-web-search-fetch/releases/download/v0.4.4/dsh-web-search-fetch-0.4.4.tgz
```

以上命令安装 `0.4.4` 发布包；跟踪开发线请使用「从源码安装」。

安装后打开「设置 → 内置插件 → 网络搜索与提取」，在顶部明确选择一种开始方式：

- **使用自动预设**：展开调用设置，默认的自动预设已经可用，按本地规则判定查询意图并选择来源顺序与宽度，不需要任何模型凭证。
- **直接体验匿名服务**：切换为自定义固定预设，把参与范围收窄到官方端点且未配密钥的匿名服务（AnySearch、Tavily、Firecrawl 免钥提取）与直接 HTTP 抓取，关闭其他服务；保存后即可使用。已有密钥与自定义端点不会被清除。

匿名模式受服务方额度与限流约束，不能保证无限使用；匿名候选中参与搜索的只有 AnySearch 与 Tavily（AIHOT 启用后可加入）；直接 HTTP 抓取与 Firecrawl 只参与提取面，Firecrawl 搜索仍需 `fc-` 密钥；知乎需要知乎开发者 Access Secret；未配置凭证的相应能力面不参与派发。未安装 DSH 的环境需先完成[宿主安装](https://github.com/deepseek-ai/deepseek-harness)。

## 项目特点

| 特点 | 当前实现 | 使用价值 |
| --- | --- | --- |
| 多来源搜索融合 | AnySearch、Tavily、Firecrawl、知乎、AIHOT 五家搜索面并发调用，URL 归一后合并重复来源，按 RRF（Reciprocal Rank Fusion，k=60）排序；同键候选逐字段取更完整的摘要；最终排序后每域默认至多 2 条，主题匹配的官方文档域与中文政府权威域豁免 | 把多路可用结果整理成一份统一来源列表，单路漏掉的结果由其他路补上 |
| 意图路由 | 本地确定性规则把查询判为七类意图（AI 资讯、知乎观点、热点榜单、结构化取数、调研对比、英文网页、中文网页）与 39 个 AnySearch 垂直 tag；路由器只判意图，意图到来源顺序的映射在装配层，宽度归预设 | 不同问题走各自擅长的来源；规则可解释、零模型成本，同一查询结果稳定 |
| 垂直数据取数 | 结构化取数意图下发 AnySearch 垂直 tag（金融、农业、学术、安全、法律、专利、出行、商业、社媒、健康、环境、能源、游戏、影视、图片、代码等 39 个频道）；tag 先经 `/v1/domains` 目录校验存在性与必填参数，不合法按查询语言回落通用路由；无 URL 的结构化数据进入结果 `content` 通道 | 股价、财报、CVE、判例、航班等查询直接取对应频道，不再只靠通用网页碰运气 |
| 知乎热榜与直答 | 热点/热榜意图直接取知乎 `hot_list`（平台口径 100 次/日），AIHOT `/api/v1/hot-topics` 兜底；知乎观点意图在搜索同时调用知乎直答（`zhida`），答案进结果 `content`，失败静默跳过 | 热点问题拿榜单而非普通新闻搜索；知乎问题附社区回答，两路互不阻塞 |
| 查询缓存 | 仅 `auto` 预设使用；归一查询 + 意图 + `site:` 域名 + `maxResults` 为键，TTL 按意图分档：AI 资讯/热点 300 秒、垂直取数 900 秒、其余 1,800 秒、调研对比不缓存；显式预设、`after:`/`before:` 与「最新/今天/刚刚/实时」查询绕过读取；命中附 age 说明，不计请求预算 | 重复查询省额度、降延迟，同时保留显式时效与新鲜查询的直取通道 |
| 本地额度账本 | 每引擎按本地日记录成功、限流、额度失败次数；同一日额度型失败达到 2 次即视为本地耗尽、当日不再派发；搜索与提取共享同一账本；无额度端点的源只标「估算」，不伪造余额 | 官方快照之外增加本地观察，额度耗尽前主动换路，减少反复撞限流 |
| 额度面板 | 设置卡「额度」小节逐引擎显示官方额度与本地计数；「刷新额度」手动探测，不自动轮询；状态与超时细节见[额度面板与手动刷新](./docs/configuration.md#额度面板与手动刷新) | 不离开设置页就能核对每个来源的剩余额度与本地用量，省额度的判断有据可查 |
| 查询语法翻译 | 解析 `site:`、`-site:`、`lang:`、`after:`、`before:`；Tavily 映射 `include_domains` / `exclude_domains` / `start_date` / `end_date` / `language`，Firecrawl 映射 `includeDomains` / `excludeDomains`，AnySearch 映射 `language`；不支持的写法按原 token 逐字、原顺序回拼 | 让免费聚合在常用检索语法上接近付费 API，同时不悄悄改写用户查询 |
| 两段式提取 | 自动预设在整理模式下先派发一路探测；结果为 2xx、目标一致、非挑战页且普通段落不少于 400 字符时，直接返回该路原文；否则把已取得的结果并入多路整理 | 短页与常见文章一次请求即可，省额度也省尾部等待 |
| 多来源正文整理 | 同一 URL 的多份提取按章节与共同内容块去重、互补，保留提取来源与文本差异；挑战页不混入正文；输出按完整内容块受单页预算约束 | 把说明、表格、代码与独有段落整理到一份正文，同时保留出处 |
| 免钥提取与知乎问答读取 | Firecrawl `/v2/scrape` 未配密钥时走官方 keyless free tier（受出口 IP 信誉门控，VPN/代理出口 403，换节点可恢复）；知乎 `zhihu.com/question/*` 提取走 `question_answers` API，直接读取回答摘要与回答链接（每问题首页 20 条，不自动翻页） | 出口 IP 干净时没有 Firecrawl 密钥也能提取网页；知乎问题页拿到结构化摘要而不是网页噪声 |
| SiliconFlow 重排 | 融合与相关性过滤后的前 30 个候选送入 `BAAI/bge-reranker-v2-m3` 重排；默认开启，未配置 `SILICONFLOW_API_KEY` 时自动不启用；失败按融合序返回并记说明 | 在不阻塞主流程的前提下改善排序；不配密钥不产生额外依赖 |
| 额度查询与日检 | Tavily `/usage`、Firecrawl `/v2/team/credit-usage`、知乎 `/api/v1/quota` 提供结构化额度；AnySearch 与 AIHOT 无额度端点，显式 N/A；每次搜索在选源之前做一次本地日检（每实例每日至多一次），`remaining` 为 0 时该引擎当轮起熔断到次日零点；无端点源的本地计数标注为估算；搜索面确实免钥的 keyless-fallback 引擎（AnySearch、Tavily）带密钥调用遇 `quota` 失败时，同一路去掉密钥按匿名额度重试一次并记说明（密钥无效不降级） | 额度耗尽前换路，避免整段时间反复撞限流 |
| 预设与调用范围 | `auto` / `single` / `multi` / `custom` / `free` 五种预设决定派发宽度与免密钥过滤，规则见[调用预设](./docs/configuration.md#调用预设) | 问题类型决定宽度与首选来源；不需要模型凭证做路由 |
| 原生双工具与预算 | 仅注册搜索与提取 provider，沿用 `web_search` / `web_fetch`；每次操作有请求数、总限时、单路限时与输出长度上限；`maxOutputChars` 同时约束搜索结果（按 title+snippet 估算、从尾部裁剪）与整理正文 | 不改变宿主工具形态；单路失败时其他路继续，预算与输出可预期 |
| 空结果透明与有界降级 | 空结果时逐路标注引擎与结束状态；垂直/热榜路由无产出时按查询语言降级为通用路由重试一次（限流、额度、超时不重试），单通道唯一一路成功但无相关结果时再补派一次多路；两者都受同一请求预算约束 | 区分「查询无解」与「覆盖不足」，换通道找结果但不无界重试 |
| 地址守卫 | 在派发任何第三方提取服务前拒绝已证实的本机、内网、链路本地与保留地址，返回 `WEB_BLOCKED_URL`；当前配置没有跳过守卫的开关 | 防止把操作者内网目标外发给第三方服务 |

搜索融合与重排不构成事实交叉验证。多路并发、官方域名补充检索与额度检查会消耗对应服务额度；参数与边界见[配置参考](./docs/configuration.md)。

### 意图路由（七类）

本地确定性规则把查询判为七类意图，来源顺序由装配层映射，宽度由预设决定；路由器不需要模型凭证。

| 意图 | 判定线索（示例） | 来源顺序与行为 |
| --- | --- | --- |
| 热点榜单 `hot-list` | 「今天有什么新闻」「热榜」「热搜」等裸热点查询 | 知乎 `hot_list` 优先，AIHOT `hot-topics` 兜底；直接取榜单 |
| AI 资讯 `ai-news` | AI/大模型/LLM/模型厂商 + 新闻/发布/进展/事件词 | AIHOT 优先；带热点词时取热点榜 |
| 知乎观点 `community-opinion` | 知乎、怎么看、如何评价、经验 | 知乎优先；并发调用知乎直答补充答案 |
| 结构化取数 `vertical-data` | 股价/财报/GDP/CPI/论文/专利/CVE/判例/航班/招聘等 | AnySearch 垂直 tag；目录校验失败按语言回落通用路由 |
| 调研对比 `research` | 对比、比较、综述、调研、盘点 | 多路（上限 `maxSearchServices`），按参与范围选择 |
| 英文网页 `english-web` | 无 CJK 且含拉丁字母；开发者词细分 | 通用 Tavily→Firecrawl；开发者 Firecrawl→Tavily |
| 中文网页 `chinese-web` | 其余中文查询 | 知乎优先，其余按 registry 顺序排后 |

## 完整接入清单

| 服务 | 搜索 | 网页提取 | 鉴权 | 额度查询 |
| --- | --- | --- | --- | --- |
| AnySearch AI | `/v1/search`（含垂直 tag） | `/v1/extract` | 未配密钥走匿名（按 IP 限流）；配密钥后 Bearer，密钥失效不静默降级匿名；账号额度耗尽时同一次操作内去掉密钥按匿名额度重试一次 | 官方无额度端点（N/A） |
| Tavily | `/search` | `/extract` | 未配密钥发送 `x-tavily-access-mode: keyless`；配密钥后 Bearer；账号额度耗尽时同一路去掉密钥按匿名额度重试一次 | `GET /usage`，需要密钥；`key.limit` 为 null 时回退 `account.plan_limit`/`account.plan_usage` 计划档配对计算剩余；`key.limit` 与 `plan_limit` 均为显式 null 才表示不限；keyless 模式无额度端点（N/A） |
| Firecrawl | `/v2/search` | `/v2/scrape` | 搜索必须配置 `fc-` 密钥（Bearer）；提取未配密钥时走官方 keyless free tier，匿名请求不带 Authorization；端点可用 `firecrawlBaseURL` 覆盖 | `GET /v2/team/credit-usage`（keyless 免费层不支持）：`remainingCredits`、`planCredits`、`billingPeriodEnd` |
| 知乎 | `/api/v1/content/global_search`（全网）、`/api/v1/content/zhihu_search`（站内）、`/api/v1/content/hot_list`（热榜）、`/v1/chat/completions`（直答） | `/api/v1/content/question_answers`（问题回答摘要，仅 `zhihu.com/question/*`） | 必须配置 Access Secret；Bearer + `X-Request-Timestamp`（服务端校验 ±10 分钟窗口） | `GET /api/v1/quota` 只汇总 `global_search` 与 `zhihu_search`；问题回答与问题推荐共用「问题发现」额度（默认 100/日）；热榜、直答额度以知乎平台为准 |
| AIHOT | `/api/v1/items`（近 7 天窗口）、`/api/v1/hot-topics`（热点榜，最多 10 条） | `/api/v1/*` 专用只读 API（热点、事件、日报、周报、月报、精选等） | 匿名只读，无需凭证 | 无额度端点（N/A） |
| 直接 HTTP 抓取 | — | 静态资源：表内扩展名（如 `.md`、`.json`、`.txt`）；其余 URL 走动态提取 | 无需凭证 | — |

AnySearch 垂直频道由 `GET /v1/domains` 与 `GET /v1/sub-domains` 发现并缓存 24 小时；热榜与直答由路由意图触发，不是独立服务。

新安装默认启用 AnySearch、Tavily、Firecrawl 与直接 HTTP 抓取，知乎与 AIHOT 默认关闭。已保存的显式开关优先于安装默认。首轮搜索最多派发 5 路，普通动态提取最多 4 路；实际参与取决于配置、凭证、URL 适用范围与熔断状态。直接 HTTP 抓取不受提取参与列表控制，但可由服务总开关关闭；关闭后静态 URL 会报错，不会自动改走其他提取服务。

AIHOT 搜索覆盖近 7 天 AI 资讯；启用后，`web_fetch` 可读取受支持的 `/api/v1/*` 结构化报告与 Markdown 面，不参与通用网页提取。使用方法见 [AIHOT 接入](./docs/aihot.md)。启用前请阅读 [AIHOT 使用规则](https://aihot.news/terms)；服务数据授权与本项目 MIT 代码许可分别适用。

### 服务费用

DeepSeek 的官方搜索 API 按次计费：每 1,000 次成功且有结果的请求 5 元，失败、无结果和超时不计费。DeepSeek 开源栈（模型、推理框架与 Harness）里唯一闭门收费的搜索位，正是本插件用各家免费额度聚合替代的位置。本插件的搜索与提取不收取中间费用；可选择配置的 SiliconFlow 重排是唯一需要用户自带密钥的可选付费位，不配置时自动不启用。

| 费用方式 | 服务 | 说明 |
| --- | --- | --- |
| 匿名免费额度 | AnySearch AI、Tavily | 官方端点未配密钥时可用；受 IP、共享限流与服务方额度约束 |
| 带密钥的免费额度 | Firecrawl | 搜索必须配置 `fc-` 密钥；提取另有官方免钥免费层（实验性，限额未知）；免费 credits 的周期与额度以服务方账号为准 |
| 付费凭证／账户额度 | 知乎 | 需要知乎开发者 Access Secret；不参与 free 预设 |
| 免费匿名 | AIHOT、直接 HTTP 抓取 | AIHOT 个人非商业、公益及组织内部使用；直接抓取由宿主执行 |
| 可选付费 | SiliconFlow 重排 | 自带 `SILICONFLOW_API_KEY`；默认开启但未配密钥时不启用，失败 fail-open |

匿名模式不表示无限免费，也不保证结果质量或可用性。AnySearch 的自定义端点未配密钥时会收到匿名请求；Firecrawl 的自定义端点必须配密钥，免钥层仅限官方端点的提取面。已有密钥失效时不自动降级为匿名请求。例外是账号额度耗尽：搜索面确实免钥的 keyless-fallback 引擎（AnySearch、Tavily）会在同一次操作内去掉密钥、按匿名额度重试一次，并在处理说明中标注；密钥无效（auth）不降级。费用与额度以服务方及账号为准；接口依据：[AnySearch](https://anysearch.com/pricing)、[Tavily](https://www.tavily.com/pricing)、[Firecrawl](https://www.firecrawl.dev/pricing)、[知乎开放平台](https://developer.zhihu.com/)、[SiliconFlow](https://siliconflow.cn/pricing)。

## 快速开始

### 环境要求

| 组件 | 要求 |
| --- | --- |
| Node.js | `^22.19.0 \|\| >=24.0.0`，不包含 Node.js 23 |
| DSH | 已安装，并具有 `web` 与 `credentials` 服务；`package.json` 声明兼容 `0.2.1-rc.2` |
| 开发工具 | pnpm 12.10.1 |
| 外部服务 | 网络连通性；AnySearch、Tavily 官方匿名模式无需凭证，Firecrawl、知乎按需配置密钥 |

`package.json` 的 `dsh.compatibility.dshReleases` 声明：`0.2.1-alpha.2`、`0.2.1-alpha.3`、`0.2.1-alpha.4`、`0.2.1-alpha.5`、`0.2.1-rc.2` 为 `compatible`；`0.2.0-rc.2` 与 `0.2.1-alpha.1` 保持 `unknown`。未执行实机验收的版本不被文档升格为兼容。

### 使用发布包安装

在已配置 DSH 的环境中执行：

```sh
dsh plugin --profile web add https://github.com/qikairo7/dsh-web-search-fetch/releases/download/v0.4.4/dsh-web-search-fetch-0.4.4.tgz
```

将 `web` 替换为实际使用的 profile，安装后重启宿主。以上命令使用 `0.4.4` 发布包，不需要 npm 发布账号或 GitHub 登录。

### 从源码安装

```sh
git clone https://github.com/qikairo7/dsh-web-search-fetch.git
cd dsh-web-search-fetch
pnpm install --frozen-lockfile
pnpm run build
dsh plugin --profile <profile> add link:<absolute-repository-path>
```

将 `<profile>` 替换为目标 profile，将 `<absolute-repository-path>` 替换为仓库绝对路径。路径包含空格时，对整个 `link:` 参数加引号。仓库跟踪 `lib/**/*.js` 与 `lib/**/*.d.ts` 编译产物，固定 Git 提交安装无需先编译 TypeScript。

bundle patch 自动选择 provider。检查装载后的配置：

```sh
dsh --profile <profile> --dump-config
```

应出现 `web-search-fetch` 条目，以及 `web` 条目下的 `searchProvider: aggregated` 和 `fetchProvider: aggregated`。配置输出只证明装载状态，还需实际调用工具检查响应。分享输出前应检查其他插件的私密数据。

### 配置凭证

在 DSH Web 的设置页找到「网络搜索与提取」入口（插件/内置插件分区由宿主版本决定），填写所需凭证并保存。空白填写位保持已有凭证；状态区只显示配置状态，不回显密钥。

| 默认引用名 | 服务 | 是否必需 |
| --- | --- | --- |
| `ANYSEARCH_API_KEY` | AnySearch AI 搜索与提取 | 可选；未配置走匿名额度 |
| `TAVILY_API_KEY` | Tavily 搜索与提取 | 可选；未配置走 keyless 模式 |
| `FIRECRAWL_API_KEY` | Firecrawl 搜索（以及配置后的提取） | 搜索需要；提取未配置时走官方免钥免费层 |
| `ZHIHU_API_KEY` | 知乎搜索、问题回答读取与额度查询 | 启用知乎时需要 |
| `SILICONFLOW_API_KEY` | SiliconFlow 重排 | 可选；未配置时重排自动不启用 |

AnySearch 与 Firecrawl 各支持一个端点覆盖字段（`anysearchBaseURL`、`firecrawlBaseURL`），AnySearch 另有搜索区域字段 `anysearchZone`（`cn` 国内 / `intl` 国际，缺省不发送）；Tavily 与知乎没有端点覆盖字段。AIHOT 与直接 HTTP 抓取不需要凭证。配置文件只填写引用名，凭证值由 DSH 管理，每次操作重新解析。详细说明见[配置参考](./docs/configuration.md)。

### 使用

在启用本插件的 DSH 会话中使用原生工具，例如：

```text
搜索 DeepSeek Harness 的插件开发文档，并列出来源链接。
读取 https://example.com/guide.md，概括主要内容。
```

需要按时间或站点收窄时，可直接在查询中写操作符：

```text
cordis 插件开发 site:github.com after:2026-01
最近的 AI 搜索引擎开源动态 -site:example.com
```

动态提取默认单路限时 45 秒、操作总限时 50 秒；搜索默认单路限时 10 秒、操作总限时 15 秒。需为会话实际使用的 `tool-web` 设置足够的提取预算；Web agent preset 中的嵌套工具配置也需检查。见[配置参考](./docs/configuration.md)。

## 设置界面与配置指引

设置页使用 DSH 原生分段选择、输入框、复选框和开关。首屏显示当前调用方式与服务配置；展开「调用设置」可切换预设、调整搜索与提取的参与范围；「高级调用限制」中调整服务数量上限、请求数、总限时与正文输出长度；「结果重排」区域提供 SiliconFlow 开关与模型说明；「额度」小节逐引擎显示官方额度与本地计数，并提供「刷新额度」按钮。

服务列表覆盖五个引擎与直接 HTTP 抓取，共 6 行、5 个凭证位。每行显示配置状态、启用开关与展开箭头；展开后可分别选择「参与搜索」「参与提取」，配置密钥与端点。推荐服务置顶，其余标注「可选增强」。服务列表支持名称搜索、能力筛选与配置状态筛选；隐藏或折叠的草稿仍会保留。

常用配置项如下，完整字段、取值范围与语义见[配置参考](./docs/configuration.md)。

| 配置项 | 默认值 | 说明 |
| --- | --- | --- |
| `controls.preset` | `auto` | `auto`、`single`、`multi`、`custom`、`free` |
| `controls.maxSearchServices` | 5 | 每个查询首轮派发的搜索服务上限 |
| `controls.maxOutputChars` | 15000 | 搜索与单页整理输出上限 |
| `rerank.enabled` | `true` | 未配置 SiliconFlow 密钥时自动不启用 |

保存后下一次调用生效，无需重启或重挂插件；正在执行的操作继续使用其原有控制快照。端点覆盖与凭证引用名同样在保存后下一次调用生效。数值输入允许暂时清空，超出范围时提示并阻止保存；离开设置页会撤销未保存草稿。配置状态仅表示凭证是否存在，不证明服务健康。参数、端点覆盖与工具超时细节见[配置参考](./docs/configuration.md)。

额度面板逐引擎显示五行（五个引擎，不含直接 HTTP）；官方值来自各服务额度端点并按各自周期标注（月额度或当日），无端点源标「估算」、未取到标「未刷新」、探测失败显示原因。面板只在打开设置页时读取快照，点击「刷新额度」才探测官方额度，不在后台轮询；每次刷新每引擎 10 秒超时、整次 15 秒总截止，并发点击共享同一次探测。快照仓与本地计数都在进程内，重启后清零；当日首次搜索的日检或手动刷新会重新填充。官方侧四态、刷新超时与熔断解除语义见[配置参考](./docs/configuration.md#额度面板与手动刷新)。

预设行为：`auto` 先由本地规则判定查询意图（AI 资讯、知乎观点、热点榜单、结构化取数、调研对比、英文网页、中文网页），再按意图映射给出源顺序：调研对比与 AI 资讯多路（上限 `maxSearchServices`），其余意图单路；官方文档意图追加限定域名的补充检索（显式 `single` 或查询含 `site:` / `-site:` 时除外）。`single` 首轮恰好一路；`multi` 在参与范围内按 `maxSearchServices` / `maxFetchServices` 并发派发；`custom` 按总开关、参与列表与各项上限执行；`free` 按免密钥过滤——AnySearch、Tavily、AIHOT（需先启用）、直接 HTTP 静态抓取与 Firecrawl 免钥提取面；Firecrawl 搜索仍需密钥，不进入 free 的搜索面；知乎不参与。完整口径见[调用预设](./docs/configuration.md#调用预设)。

## 工作原理

```mermaid
flowchart LR
    Query[web_search 查询] --> Syntax[解析 site:/-site:/lang:/after:/before:]
    Syntax --> Intent[本地意图路由：七意图 + 39 垂直 tag]
    Intent --> Cache{auto 预设且命中缓存?}
    Cache -->|是| Cached[返回缓存结果与 age 说明]
    Cache -->|否| Fanout[按意图映射、预设与额度选源并发派发]
    Fanout --> Special{垂直取数或热榜?}
    Special -->|是| Hot[取垂直频道 / 热点榜单]
    Hot --> Fuse[URL 归一、同源去重与 RRF 融合]
    Special -->|否| Fuse
    Fuse --> Filter[相关性过滤与官方域名优先]
    Filter --> Empty{有来源或结构化内容?}
    Empty -->|否，垂直或热榜路由| Degrade[按语言降级通用路由一次]
    Empty -->|否，单通道普通路由| Escalate[补派一次多路并融合]
    Empty -->|是| Rerank{SiliconFlow 重排可用?}
    Degrade --> Rerank
    Escalate --> Rerank
    Rerank -->|是| Ordered[重排前 30 个候选]
    Rerank -->|否或失败| Ordered2[按融合序返回]
    Ordered --> Sources[每域至多 2 条、输出预算与说明]
    Ordered2 --> Sources

    Fetch[web_fetch URL] --> Guard{本机或内网目标?}
    Guard -->|是| Blocked[拒绝外发 WEB_BLOCKED_URL]
    Guard -->|否| Api{AIHOT 专用只读 API?}
    Api -->|是| ReadApi[直接读取 Markdown 或 JSON]
    Api -->|否| Route{静态扩展名?}
    Route -->|是| Http[DSH HTTP 提取器]
    Route -->|否| Probe{自动预设首路探测}
    Probe -->|2xx、目标一致、≥400 段落字符| Original[直接返回原文]
    Probe -->|不足或失败| Extract[多路并发展开]
    Extract --> Organize[内容块去重、互补与来源标记]
    Organize --> Body[正文、来源与差异]
```

搜索侧要点：

- 管线顺序：解析查询语法 → 本地意图路由（七类意图；路由器只判意图，映射在装配层，宽度归预设）→ `auto` 预设查缓存 → 按意图映射、预设与额度选源并发派发 → URL 归一与 RRF 融合 → 相关性过滤与有界降级/补派 → SiliconFlow 重排（可选）→ 输出治理。逐步细节见[架构说明](./DESIGN.md#搜索管线)。
- 只有 `auto` 预设读写查询缓存；TTL 按意图分档，显式日期操作符与「最新/今天/刚刚/实时」绕过读取，命中附 age 说明且不计请求预算。
- 垂直取数先经 AnySearch 目录校验 tag 与必填参数，不合法按查询语言回落通用路由；热点/热榜意图直接取榜单，知乎观点意图并发调用知乎直答。垂直/热榜路由无产出时按语言降级通用路由重试一次；单通道首轮无相关结果时补派一次多路。两者都受请求预算与总限时约束。
- 相关性过滤：两个及以上主题词按主题词匹配；三字以上连续汉字允许按字符覆盖匹配；时效限定词（最近、最新、近期等）先剔除再判主题；连字符复合词按词段多数匹配。同源分组在 RRF 前只保留排名最好的一路（当前 registry 未填分组）。官方文档意图追加最多两次限定域名检索（显式 `single` 或查询含 `site:` / `-site:` 时不追加），官方来源排序优先但仍须通过主题匹配。
- 中文查询含「政府」「政策」或「官方指南」时，主题匹配的 `gov.cn` 及其子域作为排序权威域参与官方优先与域名多样性豁免；该规则不追加搜索请求。
- 多通道在至少三路有来源且相关去重候选达到请求条数（官方文档意图还需出现相关官方结果）后进入 500–1200 毫秒宽限窗口，随后取消未完成渠道并标记 `truncated`；输出阶段每域默认至多 2 条（主题匹配的官方文档域与中文政府权威域豁免），按宿主 `maxResults` 与 `maxOutputChars` 截断；空结果逐路点名状态（含余额不足等），并附操作说明与请求次数。
- 搜索单路默认限时 10 秒、操作总限时 15 秒。预算、宽限与超时语义见[配置参考](./docs/configuration.md#限制与预算语义)。

提取侧要点：

- 分流顺序：地址守卫 → AIHOT 专用只读 API → 静态扩展名／动态提取；守卫先于第三方派发，拒绝已证实的本机、内网、链路本地与保留地址并返回 `WEB_BLOCKED_URL`，解析失败不拦截，当前配置没有关闭守卫或豁免主机的字段。细节见[架构说明](./DESIGN.md#提取管线)。
- 静态路交给 DSH HTTP 提取器；有正文的非 2xx 仍是结果，无正文的非 2xx 按失败上报。
- 自动预设先探测一路（默认 15 秒）：2xx、目标一致、非挑战页且普通段落不少于 400 字符时直接返回原文；否则升级多路整理，已取得的探测结果并入候选，不重复请求同一引擎。
- 动态提取至少三路返回同标题、共同长段落且段落正文不少于 1,200 字符时，进入宽限等待并提前取消慢渠道。
- 多路正文按章节与完整内容块去重、互补；代码、表格、链接和原文数字保留；不同标题、版本标记或语言的内容放入补充片段，挑战页不混入正文。
- 全败时按「目标被拒绝」与「引擎不可用」分组，取最特异的 `WEB_*` 错误码；单路失败不会炸掉整个操作。预算与整理上限见[配置参考](./docs/configuration.md#限制与预算语义)，错误分组细节见[架构说明](./DESIGN.md#提取管线)。

熔断规则：限流按 `Retry-After` 冷却，无提示时默认 60 秒，重复触发按指数退避、上限 1 小时；额度耗尽与余额不足断到本地次日零点。熔断状态是进程内状态，恢复由下一次查询惰性发现。

## 项目定位与证据

这个项目的目标是资料研究与可治理的多源调用，不是零配置联网的最小方案。它优先解决五件事：模型仍只用 DSH 原生双工具；查询先按意图路由到擅长的来源；搜索结果来自多路融合；动态网页提取保留来源、差异与预算边界；服务、凭证、预设、请求量和熔断可以在设置页统一管理。与按次计费的官方搜索 API 相比，它用免费额度聚合替代收费搜索位；代价是更多上游服务、更多额度边界与更复杂的故障面。

| 证据 | 结果与边界 |
| --- | --- |
| 当前交付版本 | `0.4.4`；修复实时配置与设置页保存（七意图路由、AnySearch 垂直取数、知乎热榜与直答、查询缓存、本地额度账本、额度面板、SiliconFlow 重排与两段式提取不变） |
| 验收记录 | [0.3.0 验收记录](./docs/verification/v0.3.0-acceptance-20261107.md)、[0.4.0 验收记录](./docs/verification/v0.4.0-acceptance-20261108.md)、[0.4.2 批次验收](./docs/verification/v0.4.2-acceptance-20261108.md)、[0.4.3 真机验收](./docs/verification/v0.4.3-acceptance-20261108.md)、[0.4.4 实时配置验收（真机保存待补）](./docs/verification/v0.4.4-live-config-20261109.md)：真实探针输出与未验证项 |
| 仓库门禁 | 814 项离线测试通过（32 个测试文件，2026-11-09 v0.4.4 分支）；`check:distribution` 另行检查分发产物 |
| 架构不变量 | `test/architecture.test.ts` 钉死分层：搜索、提取与横切层不得 import 具体引擎模块或硬编码引擎 id；服务清单只存在于 `src/engines/registry.ts` |
| 真实搜索调用 | 2026-11-07 live-probe：`web_search` 三查询（普通、`site:github.com`、时效查询）各取得 8 个来源并成功返回 |
| 真实提取调用 | 2026-11-07 live-probe：静态 `example.com` 764ms、GitHub raw README 905ms 提取成功 |
| 真实额度查询 | 2026-11-08 真机：知乎两池各 5000/5000 日额度；Firecrawl 729/1000 credits（账期重置）；Tavily 计划档 960/1000（`key.limit=null` 回退 `account.plan_limit` 配对） |
| 未验证部分 | 正式 profile 的安装、卸载与回滚生命周期未在 0.4.x 重测（0.2.12 时验证过）；SiliconFlow 重排真实生效、AIHOT 真实调用与搜索缓存命中未单独取证。门禁通过不表示这些组合均完成 DSH 实机验收 |
| 外部流程 | DSH Store 的独立供应链审阅与准入由 Store 维护者决定，不由本项目宣布通过 |

建议按需求选择：需要开箱即用、最低请求成本或特定引擎原生能力时，直接使用对应服务或官方 API；需要多源融合、正文整理、查询语法翻译、服务级治理与可控预设时，使用本插件。搜索排序与正文整理不验证事实真伪，重要结论仍需回看原始来源。

## 文档

| 我想… | 文档 | 内容 |
| --- | --- | --- |
| 配置服务与预算 | [配置参考](./docs/configuration.md) | 参数、端点、凭证回落关系、工具预算 |
| 理解正文整理 | [网页正文整理](./docs/content-organization.md) | 整理规则、来源标记、差异处理与限制 |
| 用 AIHOT | [AIHOT 接入](./docs/aihot.md) | 原生工具读取 Markdown、结构化报告及精选 API |
| 理解架构 / 改代码 | [架构说明](./DESIGN.md) → [贡献指南](./CONTRIBUTING.md) | 模块职责、数据流、错误处理与扩展方式 |
| 理解意图路由 | [ADR-0001](./docs/adr/0001-intent-routing.md) | 七意图、三段式路由、同源去重、缓存与额度账本的决策记录 |
| 查术语 | [术语表](./GLOSSARY.md) | 项目术语与接口含义 |
| 排障 | [常见问题](./docs/troubleshooting.md) | 装载、凭证、超时、额度与熔断排查 |
| 卸载 / 回滚 | [卸载与回滚](./docs/lifecycle.md) | 配置备份、移除保存的设置与恢复原 provider |
| 审阅依赖 | [运行依赖审阅材料](./docs/dependency-review.md) | 直接依赖来源、许可证、安装脚本、分发完整性与复核命令 |
| 查 0.3.0 验收范围 | [0.3.0 验收记录](./docs/verification/v0.3.0-acceptance-20261107.md) | R1–R9 状态、真实探针输出与未验证项 |

面向 AI 协作开发的约定（开发循环、质量门禁、skill 路由）在 [AGENTS.md](./AGENTS.md) 及其指向的 `docs/agents/`。

## 贡献与反馈

问题反馈和功能建议请通过 [GitHub Issues](https://github.com/qikairo7/dsh-web-search-fetch/issues) 提交。提交代码前请阅读[贡献指南](./CONTRIBUTING.md)，安全问题按[安全说明](./SECURITY.md)的私密入口报告。

## 许可与致谢

本项目采用 [MIT 许可](./LICENSE)。AnySearch 服务包含来自 [anysearch-team/anysearch-dsh](https://github.com/anysearch-team/anysearch-dsh) 的 MIT 代码。来源、改造范围和第三方许可全文见 [NOTICE](./NOTICE)。
