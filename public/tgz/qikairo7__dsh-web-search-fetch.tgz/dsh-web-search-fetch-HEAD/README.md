# dsh-web-search-fetch

面向资料研究的 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) 插件。它在原生 `web_search` / `web_fetch` 后面编排多个外部搜索与提取服务，不新增模型工具、MCP 服务或外部常驻进程。

当前开发线为 `0.4.6` 候选版，兼容 DSH `0.2.2-rc.1`；最新正式发布版仍是 `0.4.5`。

## 能力

| 能力 | 说明 |
| --- | --- |
| 原生双工具 | 保持 DSH 的 `web_search` 与 `web_fetch` 工具形态，只替换 provider。 |
| 免费来源替代 | 用可配置的免费额度来源替换 DSH 内置付费 Search / Fetch provider；多来源结果经 URL 归一、RRF 融合、域名多样性治理与可选 SiliconFlow 重排。 |
| 模型摘要与时间 | 输出 DSH `summary` 与 `publishedAt`；Exa、Tavily、AnySearch、AIHOT 提供长摘要，热点结果优先保留 7 天内条目。 |
| 查询语法 | 支持 `site:`、`-site:`、`lang:`、`after:`、`before:`；不支持原生参数的引擎逐字回拼原文。 |
| 网页提取 | 地址守卫、静态文件直取、动态页两段式探测、多路正文整理、来源与文本差异保留。 |
| 服务治理 | 凭证引用、服务开关、参与列表、请求预算、限时、输出上限、额度状态与进程内熔断。 |

搜索融合和正文整理不判断事实真伪。重要结论仍应回到原始来源核对。

## 安装

安装正式版：

```sh
dsh plugin --profile web add https://github.com/qikairo7/dsh-web-search-fetch/releases/download/v0.4.5/dsh-web-search-fetch-0.4.5.tgz
```

从源码安装：

```sh
git clone https://github.com/qikairo7/dsh-web-search-fetch.git
cd dsh-web-search-fetch
pnpm install --frozen-lockfile
pnpm run build
dsh plugin --profile web add link:<absolute-repository-path>
```

安装后重启 DSH，再检查配置：

```sh
dsh --profile web --dump-config
```

输出应有 `web-search-fetch`，且 `web.searchProvider` 与 `web.fetchProvider` 均为 `aggregated`。

## 服务

服务清单、能力、端点、鉴权和默认开关由 [docs/engine-catalog.md](docs/engine-catalog.md) 从 `src/engines/registry.ts` 生成。直接 HTTP 是本地静态提取器，不进入 registry。

当前包不内置插件设置页。直接编辑 DSH profile 配置，或沿用旧版本已保存的配置；配置更新后下一次调用生效。完整字段见 [docs/configuration.md](docs/configuration.md)。

## 使用

```text
搜索 DeepSeek Harness 的插件开发文档，并列出来源链接。
读取 https://example.com/guide.md，概括主要内容。
cordis 插件开发 site:github.com after:2026-01
```

查询缓存、意图、额度、端点和安全边界见 [docs/configuration.md](docs/configuration.md)。

## 文档

| 目标 | 文档 |
| --- | --- |
| 理解项目地基与不变量 | [docs/foundation.md](docs/foundation.md) |
| 查服务、端点与默认开关 | [docs/engine-catalog.md](docs/engine-catalog.md) |
| 配置服务、凭证、预算与额度 | [docs/configuration.md](docs/configuration.md) |
| 理解架构与数据流 | [docs/architecture.md](docs/architecture.md) |
| 本地开发与测试 | [docs/development.md](docs/development.md) |
| 理解测试策略 | [docs/testing.md](docs/testing.md) |
| 排查错误 | [docs/troubleshooting.md](docs/troubleshooting.md) |
| 查错误码 | [docs/error-catalog.md](docs/error-catalog.md) |
| 理解正文整理 | [docs/content-organization.md](docs/content-organization.md) |
| 使用 AIHOT API | [docs/aihot.md](docs/aihot.md) |
| 卸载或回滚 | [docs/lifecycle.md](docs/lifecycle.md) |
| 查术语 | [docs/glossary.md](docs/glossary.md) |

## 状态

- 离线检查入口：`pnpm run check`。
- DSH `0.2.2-rc.1` 真机验收：10 条搜索全部成功，`summary` 与 `publishedAt` 已贯通。
- 与 DeepSeek Search 同批对比：官方 API 在延迟、摘要与日期覆盖上仍领先；本插件在热点多样性、知乎社区和部分官方文档查询上更强，不宣称完全追平。
- 历史真机证据保存在 [docs/verification/README.md](docs/verification/README.md)，新记录追加，不改旧记录。

## 参与

- 功能与缺陷：[GitHub Issues](https://github.com/qikairo7/dsh-web-search-fetch/issues)
- 开发约定：[CONTRIBUTING.md](CONTRIBUTING.md)、[AGENTS.md](AGENTS.md)
- 安全问题：[SECURITY.md](SECURITY.md)

MIT License。第三方代码和许可见 [NOTICE](NOTICE)。
