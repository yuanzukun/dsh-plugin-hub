# 贡献指南

欢迎通过 [GitHub Issues](https://github.com/qikairo7/dsh-web-search-fetch/issues) 报告问题或提出功能建议；较大的接口变更请先说明使用场景和预期行为。

## 开发

```sh
git clone https://github.com/qikairo7/dsh-web-search-fetch.git
cd dsh-web-search-fetch
pnpm install --frozen-lockfile
pnpm run hooks:install
pnpm run check
```

完整工程约定见 [docs/development.md](docs/development.md)，测试策略见 [docs/testing.md](docs/testing.md)，文档标准见 [docs/AGENTS.md](docs/AGENTS.md)，架构见 [docs/architecture.md](docs/architecture.md)。面向代理的入口是 [AGENTS.md](AGENTS.md)。

## 提交

- 做最小完整改动，只覆盖请求范围。
- 新增非平凡逻辑配一条能失败的离线测试。
- 行为、配置或公共契约变化同步对应文档。
- 提交前跑 `pnpm run check`。
- 改 `src/` 后提交重建的 `lib/`，并跑 `pnpm run check:distribution`。
- PR 说明问题、最终行为和验证命令；未验证项如实列出。

不要提交：

- 凭证
- 本机绝对路径
- 日志和临时报告
- `node_modules/`
- `.scratch/`

## 发布

发布前确定版本号，提交源码、文档和 `lib/`，运行：

```sh
pnpm run check
pnpm run pack:candidate
```

GitHub 外发、合并 `main`、推送 `main` 和 Release 都需要维护者明确确认。

## 安全

普通缺陷使用公开 Issue。可能泄露敏感数据或可被利用的安全问题使用 [私密漏洞报告](SECURITY.md#漏洞报告)。
