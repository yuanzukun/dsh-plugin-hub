import { spawn } from 'node:child_process';
import { AcpUsage } from './acp-usage.ts';
import { acpLimitError, CodeBuddyLimitError } from './acp-error.ts';
import { isSessionMetadata } from './acp-messages.ts';
import { captureAcpDescendants } from './acp-cleanup.ts';
import { isModelIdentifier } from './metadata.ts';
import { isRequestModelIdentifier } from './model-id.ts';
import { NdjsonDecoder, type BridgeEvent } from './protocol.ts';
import { childEnv, killTree, resolveCodeBuddyBin, type CodeBuddyRequest } from './runner.ts';

type JsonObject = Record<string, unknown>;
type RpcId = string | number;
const object = (value: unknown): value is JsonObject => value !== null && typeof value === 'object' && !Array.isArray(value);
const owns = (value: JsonObject, key: string): boolean => Object.prototype.hasOwnProperty.call(value, key);
const validId = (value: unknown): value is RpcId => typeof value === 'string' || (typeof value === 'number' && Number.isSafeInteger(value));
/** Prefer explicit one-shot grants; never turn a residual prompt into a persistent grant. */
const allowOptionRank = (value: JsonObject): number => {
  if (typeof value.optionId !== 'string' || !value.optionId || ['always_allow', 'allow_always'].includes(value.optionId)) return 0;
  if (value.kind === 'allow_once') return 2;
  // Retain legacy `allow` and known ID-only aliases already supported here.
  // Unknown/deny/persistent kinds must not gain approval through an ID alias.
  if (value.kind !== undefined && value.kind !== 'allow') return 0;
  if (value.optionId === 'allow_once') return 2;
  return value.kind === 'allow' || value.optionId === 'yes' ? 1 : 0;
};
const protocolError = (): Error => new Error('Invalid CodeBuddy ACP protocol message (content omitted)');
const abortError = (): Error => Object.assign(new Error('CodeBuddy ACP request aborted'), { name: 'AbortError' });
const DEFAULT_TIMEOUT = 10 * 60 * 1000;
const CANCEL_GRACE_MS = 200;
const MAX_FRAME_BYTES = 8 * 1024 * 1024;
const MAX_BUFFER_BYTES = 32 * 1024 * 1024;

/**
 * Native tools remain entirely inside CodeBuddy. ACP notifications are display
 * events, never tool requests to execute or replay in the host. Each invocation
 * creates a fresh process/session; request.prompt contains the complete history.
 */
export async function* runCodeBuddyAcp(request: CodeBuddyRequest): AsyncGenerator<BridgeEvent> {
  if (request.signal?.aborted) throw abortError();
  if (typeof request.prompt !== 'string' || typeof request.cwd !== 'string' || !request.cwd) throw new TypeError('prompt and cwd are required');
  // ACP tasks may run indefinitely while making progress. This is an idle
  // budget, not a wall-clock deadline; print-mode delegation keeps its own budget.
  const timeoutMs = request.timeoutMs ?? DEFAULT_TIMEOUT;
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0 || timeoutMs > 2_147_483_647) throw new RangeError('timeoutMs must be a positive finite timer duration');
  if (request.permissionMode && !['dontAsk', 'plan', 'acceptEdits'].includes(request.permissionMode)) throw new TypeError('Unsupported permissionMode');
  if (request.dangerouslySkipPermissions !== undefined && typeof request.dangerouslySkipPermissions !== 'boolean') throw new TypeError('dangerouslySkipPermissions must be boolean');
  if (request.jsonSchema !== undefined) throw new TypeError('JSON schema output is not supported by CodeBuddy ACP');
  if (request.model !== undefined && !isRequestModelIdentifier(request.model)) throw new TypeError('Invalid CodeBuddy request model id');
  if (request.fallbackModels !== undefined && (!Array.isArray(request.fallbackModels) || [...request.fallbackModels].some(id => id === 'default' || !isRequestModelIdentifier(id)))) throw new TypeError('Invalid CodeBuddy fallback models');
  const fallbackModels = [...new Set(request.fallbackModels ?? [])];
  const executable = await resolveCodeBuddyBin(request.bin, request.cwd);
  if (request.signal?.aborted) throw abortError();
  const args = [...executable.args, '--acp', '--acp-transport', 'stdio', '--tools', 'default', '--no-session-persistence'];
  if (request.dangerouslySkipPermissions) args.push('--dangerously-skip-permissions');
  else args.push('--permission-mode', request.permissionMode ?? 'dontAsk');
  for (const [flag, value] of [['--system-prompt', request.systemPrompt], ['--append-system-prompt', request.appendSystemPrompt], ['--model', request.model], ['--effort', request.effort]] as const) {
    if (value !== undefined) args.push(flag, value);
  }
  const env = childEnv(request.authToken);
  // Native job identities can make set_model persist an agent's respawn/profile
  // preferences. This bridge owns a fresh task, never a parent CLI job.
  for (const key of Object.keys(env)) if (key.toUpperCase() === 'CODEBUDDY_JOB_ID') delete env[key];
  const child = spawn(executable.command, args, { cwd: request.cwd, env, shell: false, windowsHide: true, detached: process.platform !== 'win32', stdio: ['pipe', 'pipe', 'pipe'] });
  const decoder = new NdjsonDecoder(MAX_FRAME_BYTES);
  const pending = new Map<RpcId, { method: string; resolve(value: unknown): void; reject(error: Error): void }>();
  const queue: { event: BridgeEvent; bytes: number }[] = [];
  const tools = new Map<string, { name: string; ended: boolean }>();
  let queueBytes = 0;
  let outputBytes = 0;
  let output = '';
  let setupSessionId: string | undefined;
  const usage = new AcpUsage();
  let nextId = 0;
  let sessionId: string | undefined;
  let failure: Error | undefined;
  let finished = false;
  let partialSuccess = false;
  let partialSuccessMessage: string | undefined;
  let promptResponded = false;
  let closed = false;
  let resolveClosed!: () => void;
  const didClose = new Promise<void>(resolve => { resolveClosed = resolve; });
  let stopping = false;
  let wake: (() => void) | undefined;
  let termination: Promise<void> | undefined;
  let cleanupFailure: Error | undefined;
  const notify = (): void => { const resolve = wake; wake = undefined; resolve?.(); };
  const progress = (): void => {
    if (!stopping && !failure && !promptResponded) timer.refresh();
  };
  const rejectPending = (error: Error): void => {
    for (const entry of pending.values()) entry.reject(error);
    pending.clear();
  };
  const send = (message: JsonObject): void => {
    if (closed || child.stdin.destroyed || !child.stdin.writable) throw new Error('CodeBuddy ACP connection closed');
    const frame = JSON.stringify(message) + '\n';
    const bytes = Buffer.byteLength(frame);
    if (bytes > MAX_FRAME_BYTES || child.stdin.writableLength + bytes > MAX_BUFFER_BYTES) throw new Error('CodeBuddy ACP request exceeds buffer limit');
    child.stdin.write(frame);
  };
  const terminate = (cancel: boolean): Promise<void> => termination ??= (async () => {
    stopping = true;
    clearTimeout(timer);
    let cleanup: (() => Promise<void>) | undefined;
    // Snapshot identities BEFORE the agent can exit in response to cancel.
    // If capture fails, still force cleanup below, but do not claim success.
    if (child.pid) {
      try { cleanup = await captureAcpDescendants(child.pid); }
      catch { cleanupFailure = new Error('CodeBuddy ACP descendant capture failed; cleanup could not be verified'); }
    }
    if (cancel && sessionId && !closed) {
      try { send({ jsonrpc: '2.0', method: 'session/cancel', params: { sessionId } }); } catch { /* Broken pipe: kill below. */ }
      // Keep draining during this short grace period, but never execute requests.
      await new Promise<void>(resolve => setTimeout(resolve, CANCEL_GRACE_MS));
    }
    try { await killTree(child); }
    catch { cleanupFailure = new Error('CodeBuddy ACP process cleanup failed'); }
    try { await cleanup?.(); }
    catch { cleanupFailure = new Error('CodeBuddy ACP descendant cleanup failed; native work may still be running'); }
    // killTree on POSIX signals synchronously; wait for stdio/process closure
    // before publishing a result, but do not let a broken child block forever.
    if (!closed) await new Promise<void>(resolve => {
      const timer = setTimeout(resolve, 1000);
      void didClose.then(() => { clearTimeout(timer); resolve(); });
    });
    if (!closed) cleanupFailure = new Error('CodeBuddy ACP process did not close after cleanup');
  })();
  const fail = (error: Error): void => {
    if (failure) return;
    failure = error;
    rejectPending(error);
    notify();
    void terminate(true);
  };
  const push = (event: BridgeEvent): void => {
    const bytes = Buffer.byteLength(JSON.stringify(event));
    if (queueBytes + bytes > MAX_BUFFER_BYTES) throw new Error('CodeBuddy ACP event buffer exceeds limit');
    queue.push({ event, bytes }); queueBytes += bytes; notify();
  };
  const rpc = (method: string, params: JsonObject): Promise<unknown> => new Promise((resolve, reject) => {
    if (failure || stopping) { reject(failure ?? new Error('CodeBuddy ACP connection closed')); return; }
    const id = ++nextId;
    pending.set(id, { method, resolve, reject });
    try { send({ jsonrpc: '2.0', id, method, params }); }
    catch { pending.delete(id); reject(new Error('Unable to send CodeBuddy ACP request')); }
  });
  const update = (params: JsonObject): void => {
    if (typeof params.sessionId !== 'string' || !params.sessionId || params.sessionId.length > 512 || !object(params.update)) throw protocolError();
    const row = params.update;
    if (typeof row.sessionUpdate !== 'string') throw protocolError();
    // Initial non-executing metadata may precede the session/new response.
    // Validate the allowlist and bind its ID later; metadata is not progress.
    if (!sessionId) {
      if (![...pending.values()].some(entry => entry.method === 'session/new') || !isSessionMetadata(row)) throw protocolError();
      if (setupSessionId && setupSessionId !== params.sessionId) throw protocolError();
      setupSessionId = params.sessionId;
      return;
    }
    if (params.sessionId !== sessionId) throw protocolError();
    if (promptResponded && !isSessionMetadata(row)) throw protocolError();
    for (const event of usage.accept(row)) push(event);
    if (row.sessionUpdate === 'agent_message_chunk' || row.sessionUpdate === 'agent_thought_chunk') {
      if (!object(row.content) || typeof row.content.type !== 'string') throw protocolError();
      if (row.content.type !== 'text') return;
      if (typeof row.content.text !== 'string') throw protocolError();
      const delta = row.content.text;
      if (!delta) return;
      const type = row.sessionUpdate === 'agent_message_chunk' ? 'text' : 'reasoning';
      if (type === 'text') {
        const meta = object(row._meta) ? row._meta : {};
        for (const id of [row.messageId, meta['codebuddy.ai/messageId']]) {
          if (id !== undefined && typeof id !== 'string') throw protocolError();
        }
        // Message IDs identify chunks, not finality. Without a verified semantic
        // final-answer marker, every text part (including ID-less prefixes) stays.
        // Preserve the exact stream; never interpret/replay JSON or tool-looking text.
        outputBytes += Buffer.byteLength(delta);
        if (outputBytes > MAX_BUFFER_BYTES) throw new Error('CodeBuddy ACP response exceeds limit');
        output += delta;
      }
      push({ type, delta });
      progress();
    } else if (row.sessionUpdate === 'tool_call' || row.sessionUpdate === 'tool_call_update') {
      if (typeof row.toolCallId !== 'string' || !row.toolCallId) throw protocolError();
      if (row.title !== undefined && typeof row.title !== 'string') throw protocolError();
      if (row.kind !== undefined && typeof row.kind !== 'string') throw protocolError();
      if (row.status !== undefined && (typeof row.status !== 'string' || !['pending', 'in_progress', 'completed', 'failed'].includes(row.status))) throw protocolError();
      let tool = tools.get(row.toolCallId);
      if (!tool) {
        if (tools.size >= 10000) throw new Error('CodeBuddy ACP tool notification limit exceeded');
        tool = { name: (row.title as string | undefined) || (row.kind as string | undefined) || 'CodeBuddy tool', ended: false };
        tools.set(row.toolCallId, tool);
        push({ type: 'tool-start', id: row.toolCallId, name: tool.name, ...(owns(row, 'rawInput') ? { input: row.rawInput } : {}) });
      }
      // In-progress tool updates can carry output without emitting a new bridge
      // event. Count them too, but not repeated updates to an already-ended tool.
      if (!tool.ended) progress();
      if (!tool.ended && (row.status === 'completed' || row.status === 'failed')) {
        tool.ended = true;
        push({ type: 'tool-end', id: row.toolCallId, name: tool.name, ...(owns(row, 'rawOutput') ? { output: row.rawOutput } : owns(row, 'content') ? { output: row.content } : {}), isError: row.status === 'failed' });
      }
    }
    // Context occupancy is ignored; only verified CodeBuddy billing extensions
    // are handled by AcpUsage above.
  };
  const accept = (value: unknown): void => {
    if (!object(value) || value.jsonrpc !== '2.0') throw protocolError();
    if (owns(value, 'method')) {
      if (typeof value.method !== 'string' || !value.method || owns(value, 'result') || owns(value, 'error')) throw protocolError();
      if (promptResponded && (value.method !== 'session/update' || owns(value, 'id'))) throw protocolError();
      if (owns(value, 'params') && !object(value.params) && !Array.isArray(value.params)) throw protocolError();
      if (['session/update', 'session/request_permission'].includes(value.method) && !object(value.params)) throw protocolError();
      const params = (value.params ?? {}) as JsonObject;
      if (owns(value, 'id')) {
        if (!validId(value.id)) throw protocolError();
        if (value.method === 'session/request_permission') {
          if (!sessionId || params.sessionId !== sessionId || !object(params.toolCall) || !Array.isArray(params.options)) throw protocolError();
          // The saved yolo setting is an explicit user decision for this bridge:
          // approve residual prompts when skipping is enabled, deny each one
          // otherwise. Never synthesize an option the CLI did not offer.
          if (request.dangerouslySkipPermissions) {
            const options = params.options.filter(object);
            const option = options.find(item => allowOptionRank(item) === 2) ?? options.find(item => allowOptionRank(item) === 1);
            const optionId = option?.optionId;
            if (!optionId) throw protocolError();
            send({ jsonrpc: '2.0', id: value.id, result: { outcome: { outcome: 'selected', optionId } } });
            return;
          }
          send({ jsonrpc: '2.0', id: value.id, result: { outcome: { outcome: 'cancelled' } } });
          fail(new Error('CodeBuddy ACP permission request denied: enable the skip-permissions setting to allow residual prompts in this non-interactive bridge, or run the action in an interactive CodeBuddy session.'));
        } else {
          send({ jsonrpc: '2.0', id: value.id, error: { code: -32601, message: 'Method not found' } });
        }
      } else if (value.method === 'session/update') {
        update(params);
      } else if (value.method === 'session/request_permission') {
        throw protocolError();
      }
      return;
    }
    if (!validId(value.id) || owns(value, 'params') || owns(value, 'result') === owns(value, 'error')) throw protocolError();
    const entry = pending.get(value.id);
    if (!entry) throw protocolError();
    if (owns(value, 'error')) {
      if (!object(value.error) || !Number.isSafeInteger(value.error.code) || typeof value.error.message !== 'string') throw protocolError();
      pending.delete(value.id);
      if (entry.method === 'session/prompt') { promptResponded = true; clearTimeout(timer); }
      // Keep authentication routing authoritative; classify only the explicit
      // RPC error surface for quota/rate limits without relaying server secrets.
      const cause = value.error.code === -32000
        ? Object.assign(new Error('CodeBuddy account requires authorization'), { name: 'CodeBuddyAuthError' })
        : acpLimitError(value.error) ?? new Error('CodeBuddy ACP request failed (server error details omitted)');
      entry.reject(cause);
    } else {
      // A session response and its first notification can share one stdout
      // chunk; record the ID synchronously, before the driver's await resumes.
      if (entry.method === 'session/new') {
        if (!object(value.result) || typeof value.result.sessionId !== 'string' || !value.result.sessionId || value.result.sessionId.length > 512) throw protocolError();
        if (setupSessionId && setupSessionId !== value.result.sessionId) throw protocolError();
        sessionId = value.result.sessionId;
      }
      // A matched setup response starts the next phase's idle budget. Prompt
      // completion ends the watchdog even if the consumer is draining events.
      if (entry.method === 'session/prompt') { promptResponded = true; clearTimeout(timer); }
      else progress();
      pending.delete(value.id); entry.resolve(value.result);
    }
  };
  const onData = (chunk: Buffer): void => {
    // During successful shutdown still validate frames and accept billing/session
    // metadata. stdout chunk boundaries must not decide whether a frame is valid.
    if (failure || (stopping && !promptResponded)) return;
    try { for (const value of decoder.push(chunk)) accept(value); }
    catch { fail(new Error('Invalid or oversized CodeBuddy ACP stream (content omitted)')); }
  };
  const onEnd = (): void => {
    // During successful shutdown still validate frames and accept billing/session
    // metadata. stdout chunk boundaries must not decide whether a frame is valid.
    if (failure || (stopping && !promptResponded)) return;
    try {
      for (const value of decoder.finish()) accept(value);
      if (!promptResponded) fail(new Error('CodeBuddy ACP stream ended before prompt completion'));
    } catch { fail(new Error('Invalid or oversized CodeBuddy ACP stream (content omitted)')); }
  };
  const onProcessError = (): void => fail(new Error('Unable to start or communicate with CodeBuddy ACP process'));
  const onPipeError = (): void => { if (!stopping) fail(new Error('CodeBuddy ACP connection failed')); };
  const onClose = (code: number | null): void => {
    closed = true;
    resolveClosed();
    if (!stopping && (!finished || code !== 0)) fail(new Error('CodeBuddy ACP process exited before successful completion (diagnostics omitted)'));
    notify();
  };
  const onSpawn = (): void => {
    try { request.onSpawn?.(); }
    catch { fail(new Error('CodeBuddy ACP spawn callback failed')); }
  };
  const onAbort = (): void => fail(abortError());
  // Only validated text/thought/tool progress and matched setup replies renew
  // this watchdog: stderr, partial frames and unrelated metadata cannot keep a
  // stalled task alive. Explicit cancellation and bounded cleanup stay unchanged.
  const onTimeout = (): void => fail(Object.assign(new Error(`CodeBuddy ACP request timed out after ${timeoutMs}ms without progress`), { name: 'TimeoutError' }));
  let timer = setTimeout(onTimeout, timeoutMs);
  request.signal?.addEventListener('abort', onAbort, { once: true });
  child.once('spawn', onSpawn);
  child.on('error', onProcessError);
  child.once('close', onClose);
  child.stdin.on('error', onPipeError);
  child.stdout.on('error', onPipeError);
  child.stderr.on('error', onPipeError);
  child.stdout.on('data', onData);
  child.stdout.once('end', onEnd);
  // stderr is intentionally discarded, not attached to errors: it can contain
  // authentication tokens and private backend URLs. resume also prevents stalls.
  child.stderr.resume();
  if (request.signal?.aborted) onAbort();
  const driver = (async () => {
    try {
      const init = await rpc('initialize', { protocolVersion: 1, clientCapabilities: {} });
      if (!object(init) || init.protocolVersion !== 1 || !object(init.agentCapabilities)) throw protocolError();
      if (failure) throw failure;
      const session = await rpc('session/new', { cwd: request.cwd, mcpServers: [] });
      if (!object(session) || typeof session.sessionId !== 'string' || !session.sessionId) throw protocolError();
      sessionId = session.sessionId;
      const models = object(session.models) ? session.models : {};
      if (typeof models.currentModelId === 'string' && request.model && models.currentModelId !== request.model) throw new Error('CodeBuddy ACP selected a different model than requested');
      if (isModelIdentifier(models.currentModelId)) push({type:'metadata',model:models.currentModelId});
      if (failure) throw failure;
      const attempted = new Set<string>([request.model, models.currentModelId].filter((id): id is string => typeof id === 'string'));
      let prompt = request.prompt;
      let switches = 0;
      while (true) {
        try {
          const result = await rpc('session/prompt', { sessionId, prompt: [{ type: 'text', text: prompt }] });
          if (!object(result) || typeof result.stopReason !== 'string') throw protocolError();
          const resultMeta = object(result._meta) ? result._meta : {};
          const outcome = resultMeta['codebuddy.ai/outcome'];
          // Native cancellation is authoritative even when an old quota error is
          // still attached. Never start another prompt after any cancellation.
          if (result.stopReason === 'cancelled' || outcome === 'CANCELLED') throw abortError();
          // Completed partial answers can contain historical model errors. Do not
          // rerun a completed task solely because it retains an old 429 diagnostic.
          const limitError = acpLimitError(resultMeta['codebuddy.ai/errorMessage']);
          if (outcome !== undefined && outcome !== 'SUCCESS' && outcome !== 'PARTIAL_SUCCESS') throw limitError ?? new Error('CodeBuddy ACP reported an unsuccessful outcome');
          if (result.stopReason !== 'end_turn') {
            if (limitError) throw limitError;
            const reasons: Record<string, string> = { cancelled: 'cancelled', refusal: 'refused', max_tokens: 'stopped at the token limit', max_turn_requests: 'stopped at the turn limit' };
            const reason = owns(reasons, result.stopReason) ? reasons[result.stopReason] : 'stopped without end_turn';
            throw new Error(`CodeBuddy ACP request ${reason}`);
          }
          partialSuccess = outcome === 'PARTIAL_SUCCESS';
          if (partialSuccess && !output.trim()) throw limitError ?? new Error('CodeBuddy ACP reported partial success without a final answer');
          if (partialSuccess) partialSuccessMessage = limitError?.message;
          finished = true;
          notify();
          break;
        } catch (error) {
          // Keep the process, account lease and native tool history. Never restart
          // the original task in a new session or replay tools through DSH.
          if (failure || stopping || request.signal?.aborted) throw failure ?? abortError();
          if (!(error instanceof CodeBuddyLimitError) || error.status !== 429) throw error;
          const nextModel = fallbackModels.find(id => !attempted.has(id));
          if (!nextModel) {
            if (switches) error.message += ' 已尝试所有候选模型，任务已停止。';
            throw error;
          }
          attempted.add(nextModel);
          // Completion suspended the watchdog. Bound set_model too, while still
          // rejecting late execution frames between prompt rounds.
          clearTimeout(timer);
          timer = setTimeout(onTimeout, timeoutMs);
          const switched = await rpc('session/set_model', { sessionId, modelId: nextModel });
          if (!object(switched) || switched.modelId !== nextModel) throw new Error('CodeBuddy 未确认候选模型切换，已停止任务以避免重复执行。');
          if (failure || stopping || request.signal?.aborted) throw failure ?? abortError();
          switches++;
          output = ''; tools.clear(); partialSuccess = false; partialSuccessMessage = undefined;
          push({ type: 'model-switch', model: nextModel });
          push({ type: 'metadata', model: nextModel });
          // Official CLI keeps committed tool history on terminal prompt errors.
          // This is a new user turn in that same session, not an exact token resume.
          prompt = '上一次请求因 HTTP 429 中断，已切换模型。请根据当前会话历史继续尚未完成的原任务，不要重复已经完成的工具操作；如果任务已经完成，直接总结结果。';
          promptResponded = false;
          progress();
        }
      }
    } catch (error) { fail(error instanceof Error ? error : new Error('CodeBuddy ACP request failed')); }
  })();
  let finalResult: Extract<BridgeEvent, { type: 'result' }> | undefined;
  let primaryError: unknown;
  let hasPrimaryError = false;
  try {
    while (true) {
      if (failure) throw failure;
      const next = queue.shift();
      if (next) { queueBytes -= next.bytes; yield next.event; continue; }
      if (finished) break;
      await new Promise<void>(resolve => { wake = resolve; });
    }
    // The prompt RPC is the completion boundary; the ACP server normally stays
    // alive awaiting another prompt. Stop it before publishing the final result.
    await terminate(false);
    if (failure) throw failure;
    if (cleanupFailure) throw cleanupFailure;
    // Metadata arriving in separate stdout reads during cleanup is still billable.
    // Drain it before the final result rather than dropping it in finally.
    while (queue.length) {
      if (failure) throw failure;
      const next = queue.shift()!;
      queueBytes -= next.bytes;
      yield next.event;
    }
    if (failure) throw failure;
    finalResult = { type: 'result', sessionId, text: output, ...(partialSuccess ? { partialSuccess: true } : {}), ...(partialSuccessMessage ? { partialSuccessMessage } : {}) };
  } catch (error) {
    primaryError = error;
    hasPrimaryError = true;
    throw error;
  } finally {
    clearTimeout(timer);
    request.signal?.removeEventListener('abort', onAbort);
    rejectPending(failure ?? new Error('CodeBuddy ACP consumer closed'));
    await terminate(!finished);
    await driver;
    child.stdin.destroy(); child.stdout.destroy(); child.stderr.destroy();
    child.removeListener('spawn', onSpawn);
    child.removeListener('close', onClose);
    child.stdout.removeListener('data', onData);
    child.stdout.removeListener('end', onEnd);
    // Error listeners remain until the stream destroy callbacks run, preventing
    // late EPIPE from becoming an unhandled error. once-close then removes them.
    const removeErrors = (): void => {
      child.removeListener('error', onProcessError);
      child.stdin.removeListener('error', onPipeError);
      child.stdout.removeListener('error', onPipeError);
      child.stderr.removeListener('error', onPipeError);
    };
    if (closed) removeErrors(); else child.once('close', removeErrors);
    queue.length = 0; tools.clear(); wake = undefined;
    if (cleanupFailure) {
      if (!hasPrimaryError) throw cleanupFailure;
      // Preserve the original instance/name (notably auth, abort and timeout).
      // Only our fixed diagnostic is attached; subprocess exceptions stay private.
      if (primaryError instanceof Error && primaryError !== cleanupFailure) {
        try {
          Object.defineProperty(primaryError, 'cleanupError', { value: cleanupFailure, configurable: true });
          primaryError.message += `; secondary cleanup failure: ${cleanupFailure.message}`;
        } catch { /* A frozen consumer error must still remain the primary error. */ }
      }
    }
  }
  // Nothing remains live while the consumer holds the final yielded event.
  if (finalResult) yield finalResult;
}
