# dsh-quick-attach（快捷附图）

[![license](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

在 DSH web GUI 的会话输入框**粘贴图片**时，自动把图片保存到你在设置中配置的目录，
并把保存后的**图片绝对路径**追加到消息草稿——发送消息时，AI 会收到该路径，
可通过文件工具与视觉能力读取识别图片。

Paste an image into the DSH web GUI composer: the plugin saves it into your
configured directory and appends the **absolute path** to your message draft —
when you send, the AI receives the path and can read the image with its file
and vision tooling.

## 安装 Install

从 GitHub Release 安装（from the GitHub release）：

```sh
dsh plugin --profile web add https://github.com/ximisi/dsh-quick-attach/releases/download/v0.1.1/dsh-quick-attach-0.1.1.tgz
```

本地安装示例（local install examples）：

```sh
dsh plugin --profile web add ./dsh-quick-attach-0.1.1.tgz
dsh plugin --profile web add ./dsh-quick-attach
```

安装后重启 web 服务，在 **设置 → 快捷附图** 中配置保存目录并启用。
After installing, restart the web service and configure the save directory
under **Settings → 快捷附图**.

## 使用 Usage

1. 打开任意会话（Open any conversation）；
2. 在输入框粘贴（Ctrl+V）一张或多张图片（截图、复制网页图片等）
   （paste one or more images into the composer）；
3. 图片自动保存到配置目录（文件名 `qa-<时间戳>-<随机>.png` 等），
   绝对路径自动追加到输入框（the image is saved and its path is appended
   to the draft）；
4. 正常输入文字并发送——路径随消息发给 AI（send — the path travels with
   the message）。

## 说明 Notes

- 仅拦截**发生在会话输入框内**的图片粘贴；其他输入框、设置、终端等不受影响。
  Only image pastes **inside the composer** are intercepted; other inputs are
  untouched.
- 原生「粘贴图片作为附件」流程被替换（不再以附件形式发送图片数据，改为发送路径）。
  The native paste-as-attachment flow is replaced with save + send-path.
- 配置保存在 `<DSH_HOME>/quick-attach.json`；默认目录 `<DSH_HOME>/quick-attach`
  （config lives in `<DSH_HOME>/quick-attach.json`; default dir is
  `<DSH_HOME>/quick-attach`）。
- 保存的图片可通过 `/quick-attach-files/<文件名>` 预览（saved images are
  served under `/quick-attach-files/<name>`）。

## 结构 Structure

- `lib/index.js` — host：`/api/quick-attach/save`、`/api/quick-attach/config`、`/quick-attach-files/*`
- `lib/client.js` — client：document 捕获阶段粘贴拦截 + 设置栏「快捷附图」分区

## License

MIT
