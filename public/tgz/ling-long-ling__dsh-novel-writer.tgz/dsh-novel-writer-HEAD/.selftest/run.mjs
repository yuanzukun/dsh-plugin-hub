/**
 * Self-test for the Host half under plain Node.
 *
 * `ProjectStore`/`ProjectCache` replace the storage table with an in-memory
 * Map of the same shape, `runNovelAction` exercises every tool action, and the
 * prompt helpers are checked for the facts the agent depends on.
 */
import { ProjectStore, ProjectCache, runNovelAction, renderNovelBrief, novelTool } from './index.mjs'
import { emptyProject, buildPrompt, missingProjectFields, normalizeProject, outlineMarkdown, projectIntegrity, projectMarkdown, projectSummary, readiness } from './state.mjs'
import { buildDemoProject } from './demo.mjs'

let failures = 0
const check = (label, condition) => {
  if (condition) {
    console.log(`ok   ${label}`)
  } else {
    failures += 1
    console.error(`FAIL ${label}`)
  }
}

/** A storage table stand-in with the same surface as the domain handle. */
function memoryTable() {
  const records = new Map()
  return {
    records,
    get: (key) => records.get(key),
    put: async (key, value) => {
      records.set(key, value)
    },
    delete: async (key) => records.delete(key),
    entries: () => [...records.entries()][Symbol.iterator](),
    get size() {
      return records.size
    },
  }
}

const table = memoryTable()
const cache = new ProjectCache(new ProjectStore(table))

const created = await runNovelAction(cache, { action: 'create', title: '测试书' })
check('create returns a project id', typeof created.projectId === 'string' && created.projectId.length > 0)
const id = created.projectId
check('create seeds six blocks', table.get(id).blocks.length === 6)

const block = await runNovelAction(cache, {
  action: 'block',
  projectId: id,
  blockId: 'world',
  content: '蒸汽与雾。',
  status: 'final',
  questions: ['还有别的规则吗？'],
})
check('block writes content and status', block.status === 'final' && block.openQuestions === 1)

const chapter = await runNovelAction(cache, { action: 'appendChapter', projectId: id, title: '开局' })
check('appendChapter assigns index 1', chapter.chapter.index === 1)

const outlined = await runNovelAction(cache, {
  action: 'outline',
  projectId: id,
  chapterId: chapter.chapter.id,
  outline: '1. 开场',
})
check('outline saved', outlined.chapter.outline === '1. 开场')

const written = await runNovelAction(cache, {
  action: 'chapter',
  projectId: id,
  chapterId: chapter.chapter.id,
  draft: '正文……',
  status: 'final',
})
check('chapter draft saved and finalized', written.status === 'final')

const got = await runNovelAction(cache, { action: 'get', projectId: id })
check('get returns a brief naming the project', got.brief.includes('测试书'))
check('get returns the outline', got.outline.includes('开局'))
check('get returns the draft in markdown', got.markdown.includes('正文……'))
check('get no longer ships the whole project object', got.project === undefined)

let rejected = false
try {
  await runNovelAction(cache, { action: 'block', projectId: id, blockId: 'nope' })
} catch {
  rejected = true
}
check('unknown block is rejected', rejected)

rejected = false
try {
  await runNovelAction(cache, { action: 'get', projectId: 'missing-project' })
} catch {
  rejected = true
}
check('unknown project is rejected', rejected)

rejected = false
try {
  await runNovelAction(cache, { action: 'get' })
} catch {
  rejected = true
}
check('missing projectId is rejected', rejected)

const listed = await runNovelAction(cache, { action: 'list' })
check('list reports the finalized chapter', listed.projects.length === 1 && listed.projects[0].chaptersFinal === 1)

const stage = await runNovelAction(cache, { action: 'stage', projectId: id, stage: 'characters' })
check('stage switches', stage.stage === 'characters')

const demo = buildDemoProject('demo-1')
const normalizedDemo = normalizeProject(demo)
check(
  'demo project survives normalization',
  normalizedDemo.id === 'demo-1' &&
    normalizedDemo.blocks.length === demo.blocks.length &&
    normalizedDemo.blocks[0].content === demo.blocks[0].content &&
    normalizedDemo.chapters.length === demo.chapters.length &&
    normalizedDemo.version === 1,
)
check('demo has final blocks', demo.blocks.filter((entry) => entry.status === 'final').length === 2)
check('demo has two chapters', demo.chapters.length === 2)
await cache.put(demo)
const demoBrief = renderNovelBrief(cache.projects)
check('prompt section lists both projects', demoBrief.includes('demo-1') && demoBrief.includes(id))
check('prompt section flags the missing outline', demoBrief.includes('还缺大纲的章节'))

const base = emptyProject('abc', 'x')
check('normalizeProject is stable', JSON.stringify(normalizeProject(base)) === JSON.stringify(base))
check('buildPrompt brief names the project', buildPrompt(base, 'brief').includes('《x》'))
check(
  'buildPrompt write names the chapter',
  buildPrompt(
    { ...base, chapters: [{ id: 'c1', index: 1, title: '雨夜', status: 'outline', outline: 'o', draft: '' }] },
    'write',
    { chapterId: 'c1' },
  ).includes('第 1 章 雨夜'),
)
const promptChapter = { ...base, id: 'abc', chapters: [{ id: 'c1', index: 1, title: '雨夜', status: 'outline', outline: 'o', draft: '' }] }
check(
  'buildPrompt write carries the ids the model must write back with',
  buildPrompt(promptChapter, 'write', { chapterId: 'c1' }).includes('chapterId=c1') &&
    buildPrompt(promptChapter, 'write', { chapterId: 'c1' }).includes('projectId=abc'),
)
check(
  'buildPrompt outline asks the model to save the outline back',
  buildPrompt(promptChapter, 'outline', { chapterId: 'c1' }).includes('novel action=outline'),
)
check('projectSummary exposes the stage', projectSummary(base).includes('了解你'))
check(
  'outlineMarkdown renders headings',
  outlineMarkdown({ ...base, chapters: [{ id: 'c1', index: 1, title: 'A', status: 'outline', outline: 'o' }] }).includes(
    '## 1. A',
  ),
)
check(
  'outlineMarkdown exposes the chapterId the model must write back with',
  outlineMarkdown({ ...base, chapters: [{ id: 'c1', index: 1, title: 'A', status: 'outline', outline: 'o' }] }).includes(
    'chapterId=c1',
  ),
)
const twoChapters = {
  ...base,
  chapters: [
    { id: 'c1', index: 1, title: 'A', status: 'final', outline: 'o1', draft: '早'.repeat(500) },
    { id: 'c2', index: 2, title: 'B', status: 'final', outline: 'o2', draft: '近'.repeat(500) },
  ],
}
const renderedProject = projectMarkdown(twoChapters)
check('projectMarkdown exposes every chapterId', renderedProject.includes('chapterId=c1') && renderedProject.includes('chapterId=c2'))
check('projectMarkdown previews the chapter before the one being written', /首尾各 \d+ 字节选/.test(renderedProject))
check(
  'projectMarkdown can fold all prose on request',
  (projectMarkdown(twoChapters, { context: 'none' }).match(/未展开/g) ?? []).length === 2,
)
// context=all degrades to prev once the whole prose stack exceeds the budget.
const hugeBook = {
  ...base,
  chapters: Array.from({ length: 3 }, (_, index) => ({
    id: `c${index + 1}`,
    index: index + 1,
    title: `章${index + 1}`,
    status: 'final',
    outline: 'o',
    draft: '雾'.repeat(80_000),
  })),
}
const degradedAll = projectMarkdown(hugeBook, { context: 'all' })
check('context=all over budget degrades to prev and says so', /超过单次读取预算/.test(degradedAll), degradedAll.slice(-200))
const smallAll = projectMarkdown(twoChapters, { context: 'all' })
check('context=all within budget stays all', !/超过单次读取预算/.test(smallAll))
// A long chapter index folds far-away headings into a range line instead of
// printing all of them.
const manyChapters = {
  ...base,
  chapters: Array.from({ length: 40 }, (_, index) => ({
    id: `c${index + 1}`,
    index: index + 1,
    title: `第${index + 1}章`,
    status: 'outline',
    outline: 'o',
    draft: '',
  })),
}
const windowed = projectMarkdown(manyChapters, { context: 'none' })
check('a long chapter index folds distant headings', /目录已折叠/.test(windowed), windowed.slice(0, 120))
check('the folded range still names the chapter numbers', /第 \d+–\d+ 章/.test(windowed))
check('a complete document passes the write guard', missingProjectFields(emptyProject('abc', 'x')) === '')
check('a half document is refused by the write guard', /缺少/.test(missingProjectFields({ id: 'abc', blocks: [] })))
check(
  'projectIntegrity flags a project wiped by a partial save',
  projectIntegrity({ title: '未命名小说', chapters: [], createdAt: 0, blocks: [{ content: '留下来的设定' }] }) !== '',
)
check(
  'readiness reports an unwritten outline',
  readiness({ ...base, stage: 'outline', chapters: [{ id: 'c', outline: '' }] }).ok === false,
)

const tool = novelTool(Promise.resolve(cache))
check(
  'tool requires action',
  tool.parameters.type === 'object' &&
    tool.parameters.properties?.action !== undefined &&
    tool.parameters.required.includes('action'),
)
const failure = await tool.execute({ action: 'get', projectId: 'nope' })
check('tool reports failures as a message', typeof failure.message === 'string' && failure.message.includes('没有找到项目'))
const rendered = tool.output.render({}, failure)
check('tool renders a text block', rendered[0].type === 'text' && rendered[0].text.length > 0)

const removed = await cache.drop(id)
check('remove drops the record', removed === true && table.get(id) === undefined)

console.log(failures === 0 ? '\nALL PASSED' : `\n${failures} FAILED`)
process.exit(failures === 0 ? 0 : 1)
