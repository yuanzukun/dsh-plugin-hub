/**
 * Client bundle build for dsh-settings-plus.
 *
 * The DSH web server serves exactly one file per client plugin (the
 * `lib/client.js` bundle), and the host's module system expects that file to
 * register itself through the
 * `window.__ModuleLoader__.load({ id, factory })` handshake. The browser half
 * is therefore one CJS bundle wrapped in that factory: `@deepseek-ai/dsh-*`
 * and `react` stay external (the profile's healed node_modules and the app's
 * module system provide them).
 *
 * The host half (`lib/index.js`, `lib/invariant.js`) is built by `tsdown`;
 * only this client bundle uses esbuild for the handshake wrapper.
 */
import { build } from 'esbuild'
import { mkdirSync } from 'node:fs'
import { dirname } from 'node:path'

const CLIENT_ID = '@oneinitai/dsh-settings-plus'

mkdirSync('lib', { recursive: true })

await build({
  entryPoints: ['lib/types/client/index.js'],
  outfile: 'lib/client.js',
  bundle: true,
  format: 'cjs',
  platform: 'browser',
  target: ['es2022'],
  sourcemap: false,
  jsx: 'automatic',
  external: [
    '@deepseek-ai/cordis',
    '@deepseek-ai/dsh-*',
    'react',
    'react-dom',
    'react/jsx-runtime',
    'react/jsx-dev-runtime',
    'scheduler',
  ],
  banner: {
    js: `window.__ModuleLoader__.load({ id: '${CLIENT_ID}', factory: (require) => { var module = { exports: {} }; var exports = module.exports;`,
  },
  footer: {
    js: 'return module.exports; } });',
  },
  logLevel: 'info',
})
