import { defineConfig } from 'tsdown'

/**
 * Web bundle for the browser half: the harness serves one file per client
 * plugin (lib/client.js). React is provided by the host runtime and stays
 * external; only the plugin's own client modules are bundled.
 */
export default defineConfig({
  entry: {
    client: 'lib/types/client/index.js',
  },
  outDir: 'lib',
  format: ['esm'],
  platform: 'browser',
  target: 'es2024',
  fixedExtension: false,
  dts: false,
  clean: false,
  deps: {
    // React is provided by the host runtime and stays external; only the
    // plugin's own client modules are bundled.
    neverBundle: [/^react($|\/)/],
  },
})
