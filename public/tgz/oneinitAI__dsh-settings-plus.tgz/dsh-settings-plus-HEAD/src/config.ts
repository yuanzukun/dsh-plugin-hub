/**
 * Serializable configuration, schema, and direct-call defaults.
 * @module @deepseek-ai/dsh-settings-plus/config
 */

import z from 'schemastery'

/** Plugin configuration supplied by the profile composition. */
export interface Config {
  /** Message written when this plugin loads. */
  message?: string
  /**
   * Official settings entries the 「官方设置页」 pane shows: the DSH official
   * UI cannot edit these items — they change only through files / config
   * files. Declared manually in cordis.yml; defaults to `[]` (the pane is
   * empty until the user declares entries).
   */
  officialFileEntries?: string[]
}

/** Configuration after defaults have been resolved. */
export interface ResolvedConfig {
  /** Message written when this plugin loads. */
  message: string
  /** Official settings entries shown on the official pane, resolved to `[]`. */
  officialFileEntries: string[]
}

/** Loader-visible configuration schema and defaults. */
export const Config: z<Config> = z.object({
  message: z.string().default('DSH plugin template loaded'),
  officialFileEntries: z.array(z.string()).default([]),
})

/**
 * Resolve the same defaults for direct callers that bypass Cordis Loader.
 * @param config - Partial serialized configuration.
 * @returns Configuration with all template defaults applied.
 */
export function resolveConfig(config: Config = {}): ResolvedConfig {
  return {
    message: config.message ?? 'DSH plugin template loaded',
    officialFileEntries: config.officialFileEntries ?? [],
  }
}
