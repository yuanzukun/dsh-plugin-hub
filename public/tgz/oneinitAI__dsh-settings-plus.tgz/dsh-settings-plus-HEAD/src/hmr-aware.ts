/**
 * HMR awareness for the file-level config editing surface (T13, C3).
 *
 * The plugin deliberately implements **no file watch of its own** — the host
 * already owns reloading:
 *
 * - `cordis.patch.yml` edits are replayed transactionally by the host boot
 *   `watchUserPatches` flow, which re-applies the patch document to the
 *   gateway; the plugin picks the change up on the next replay.
 * - `settings.yaml` edits are detected by the host settings-file watcher
 *   (chokidar → queueRefresh → publish), which hot-reloads the settings.
 *
 * What this module contributes is the save strategy and its user-facing
 * copy: writes stay atomic (the file-store `writeText` channel replaces the
 * file in one step, guarded by an expected version), and after a successful
 * write the UI tells the user the change will hot-reload — no restart is
 * ever suggested or performed here.
 * @module @deepseek-ai/dsh-settings-plus/hmr-aware
 */

/** Which configuration surface a save targets. */
export type HmrConfigKind = 'cordis-patch' | 'settings'

const DESCRIPTIONS: Record<HmrConfigKind, string> = {
  'cordis-patch':
    'Saved by atomic write; the host watchUserPatches replay applies cordis.patch.yml changes transactionally and hot-reloads the gateway — reload is automatic.',
  settings:
    'Saved by atomic write; the host settings-file watcher detects the change and hot-reloads the settings — reload is automatic.',
}

/**
 * Describe what happens after a successful save for the given surface, for
 * UI hint copy. The description names the host mechanism so users (and
 * tests) can verify that this plugin never restarts the host itself.
 * @param kind - the configuration surface being saved.
 * @returns the post-save behavior description.
 */
export function describeHmrBehavior(kind: HmrConfigKind): string {
  return DESCRIPTIONS[kind]
}
