/**
 * Host-side semantic validation and self-protection for `cordis.patch.yml`
 * editing (T13, C3 file-level config editing).
 *
 * ## Semantic validation
 *
 * {@link validatePatchDocument} parses the YAML through `yaml-editor`'s
 * `parseDocumentText` (the same parser the whole file-editing surface uses)
 * and then walks the parsed AST for patch-row structure: the top level must
 * be a sequence of entries, every non-`insert` entry must carry a string
 * `id` (a pure `insert` container carries none), `insert` children must be
 * `{id, name}` maps, a `cordis-fabric` entry (when present) must carry `config.fabric.patches` with per-patch `id` and `target`, and a
 * present `disabled` key must be a boolean. Failures carry a 1-based line
 * number where the AST exposes one.
 *
 * ## Self-protection
 *
 * This plugin's bundle row contributes three critical rows to the gateway
 * patch document:
 *
 * - the `cordis-fabric` entry with its `dsh-settings-plus/exposed-namespaces`
 *   stub patch;
 * - the `dsh-settings-plus` plugin row under an `insert` entry;
 * - the `dsh-settings-plus-invariant` companion row under the same `insert`.
 *
 * Removing or breaking any of them silently disables this plugin at the next
 * host replay, so {@link assertSelfRowsPreserved} reports exactly which rows
 * are gone and {@link validateBeforeWrite} refuses the save unless the caller
 * explicitly opts out with `requireSelfProtection: false` (the escape hatch
 * for intentionally removing the plugin).
 *
 * ## No file watch here
 *
 * This module validates text only — the host's own watchers
 * (`watchUserPatches` replay for `cordis.patch.yml`, the settings-file
 * watcher for `settings.yaml`) reload edits, see `hmr-aware.ts`.
 * @module @deepseek-ai/dsh-settings-plus/patch-validator
 */

import { LineCounter, parseDocument } from 'yaml'
import { isMap, isScalar, isSeq } from 'yaml'
import type { Document, Pair, Range, YAMLMap, YAMLSeq } from 'yaml'
import { YamlEditorError, parseDocumentText } from './yaml-editor.ts'

/** A parsed map node with the generic type arguments isMap resolves to. */
type MapNode = YAMLMap<unknown, unknown>

/** A parsed sequence node with the generic type argument isSeq resolves to. */
type SeqNode = YAMLSeq<unknown>

/** The fabric stub patch id this plugin's `cordis-fabric` row must carry. */
export const SELF_STUB_ID = 'dsh-settings-plus/exposed-namespaces'

/** The plugin rows this plugin's `insert` entry must carry. */
export const SELF_PLUGIN_IDS = ['dsh-settings-plus', 'dsh-settings-plus-invariant'] as const

/** Result of semantic validation of a patch document. */
export interface PatchValidationResult {
  /** Whether the document is syntactically and structurally valid. */
  ok: boolean
  /** Human-readable failure descriptions, with line numbers when known. */
  errors: string[]
}

/** Options for the combined write gate. */
export interface BeforeWriteOptions {
  /**
   * Whether missing self rows reject the save. Defaults to `true` — self-
   * protection is a hard constraint; set `false` only when the user is
   * explicitly removing this plugin from the patch document.
   */
  requireSelfProtection?: boolean
}

/** Result of the combined write gate. */
export interface BeforeWriteResult {
  /** Whether the write may proceed. */
  ok: boolean
  /** All failure descriptions: semantic errors plus self-protection ones. */
  errors: string[]
  /** Descriptions of self rows that are missing or unverifiable. */
  selfRowsMissing: string[]
}

/** A parsed patch document plus its line counter, or the parse failures. */
type ParseOutcome =
  | { ok: true; doc: Document.Parsed; lineCounter: LineCounter }
  | { ok: false; errors: string[] }

/**
 * Parse patch text with the shared syntax gate (`yaml-editor`'s
 * `parseDocumentText`, whose error already carries the line number) and a
 * second AST parse wired to a fresh line counter for structural line
 * reporting. Both parses share the `yaml` library, so they agree.
 */
function parsePatch(text: string): ParseOutcome {
  try {
    parseDocumentText(text)
  } catch (error) {
    if (error instanceof YamlEditorError) {
      return { ok: false, errors: [error.message] }
    }
    throw error
  }
  const lineCounter = new LineCounter()
  const doc = parseDocument(text, { lineCounter })
  return { ok: true, doc, lineCounter }
}

/** The 1-based line of a node's start, when the node exposes a range. */
function lineOf(counter: LineCounter, node: unknown): number | undefined {
  if (node === null || typeof node !== 'object') return undefined
  const range = (node as { range?: Range | null }).range
  if (range === undefined || range === null) return undefined
  const pos = counter.linePos(range[0])
  return pos?.line
}

/** The `id` string of an entry map, or null when absent or not a string. */
function entryId(entry: MapNode): string | null {
  const idPair = entry.items.find(pair => isScalar(pair.key) && pair.key.value === 'id')
  if (idPair === undefined || !isScalar(idPair.value)) return null
  return typeof idPair.value.value === 'string' ? idPair.value.value : null
}

/** Locate one key's pair inside a map node. */
function pairOf(map: MapNode, key: string): Pair<unknown, unknown> | undefined {
  return map.items.find(candidate => isScalar(candidate.key) && candidate.key.value === key)
}

/** Describe an entry by its id for error messages, with its line. */
function describeEntry(entry: MapNode, counter: LineCounter, index: number): string {
  const id = entryId(entry)
  const line = lineOf(counter, entry)
  const name = id ?? `entry ${index + 1}`
  return line === undefined ? name : `${name} (line ${line})`
}

/** Whether a node is a plain object map (not an alias-backed one). */
function isPlainMap(node: unknown): node is MapNode {
  return isMap(node)
}

/** Validate one insert entry's children: each must be an `{id, name}` map. */
function validateInsertChildren(
  children: SeqNode,
  counter: LineCounter,
  entryName: string,
  errors: string[],
): void {
  children.items.forEach((child: unknown, childIndex) => {
    const childName = `insert child ${childIndex + 1} of ${entryName}`
    if (!isMap(child)) {
      errors.push(`${childName} must be a map with 'id' and 'name'`)
      return
    }
    const idPair = pairOf(child, 'id')
    if (idPair === undefined || !isScalar(idPair.value) || typeof idPair.value.value !== 'string') {
      errors.push(`${childName} (line ${lineOf(counter, child) ?? '?'}) requires a string 'id'`)
    }
    const namePair = pairOf(child, 'name')
    if (namePair === undefined || !isScalar(namePair.value) || typeof namePair.value.value !== 'string') {
      errors.push(`${childName} (line ${lineOf(counter, child) ?? '?'}) requires a string 'name'`)
    }
  })
}

/** Validate a `cordis-fabric` entry: `config.fabric.patches` with id/target. */
function validateFabricEntry(entry: MapNode, counter: LineCounter, entryName: string, errors: string[]): void {
  const configPair = pairOf(entry, 'config')
  if (configPair === undefined || !isPlainMap(configPair.value)) {
    errors.push(`${entryName}: missing 'config' map`)
    return
  }
  const fabricPair = pairOf(configPair.value, 'fabric')
  if (fabricPair === undefined || !isPlainMap(fabricPair.value)) {
    errors.push(`${entryName}: missing 'config.fabric' map`)
    return
  }
  const patchesPair = pairOf(fabricPair.value, 'patches')
  if (patchesPair === undefined || !isSeq(patchesPair.value)) {
    errors.push(`${entryName}: missing 'config.fabric.patches' sequence`)
    return
  }
  patchesPair.value.items.forEach((patch, patchIndex) => {
    const patchName = `patch ${patchIndex + 1} of ${entryName}`
    if (!isMap(patch)) {
      errors.push(`${patchName} must be a map with 'id' and 'target'`)
      return
    }
    const idPair = pairOf(patch, 'id')
    if (idPair === undefined || !isScalar(idPair.value) || typeof idPair.value.value !== 'string') {
      errors.push(`${patchName} (line ${lineOf(counter, patch) ?? '?'}) requires a string 'id'`)
    }
    const targetPair = pairOf(patch, 'target')
    if (targetPair === undefined || !isPlainMap(targetPair.value)) {
      errors.push(`${patchName} (line ${lineOf(counter, patch) ?? '?'}) requires a 'target' map`)
    }
  })
}

/**
 * Validate one top-level entry: an id is required unless the entry is a
 * pure `insert` container (the bundle form carries no id of its own); an
 * `insert` entry must hold `{id, name}` children; a `cordis-fabric` entry
 * must hold `config.fabric.patches`; a present `disabled` key must be a
 * boolean.
 */
function validateEntry(entry: unknown, counter: LineCounter, index: number, errors: string[]): void {
  if (!isMap(entry)) {
    errors.push(`entry ${index + 1} (line ${lineOf(counter, entry) ?? '?'}) must be a map`)
    return
  }
  const entryName = describeEntry(entry, counter, index)
  const insertPair = pairOf(entry, 'insert')
  const idPair = pairOf(entry, 'id')
  if ((idPair === undefined || !isScalar(idPair.value) || typeof idPair.value.value !== 'string')
    && insertPair === undefined) {
    errors.push(`${entryName}: requires a string 'id'`)
  }
  const disabledPair = pairOf(entry, 'disabled')
  if (disabledPair !== undefined && (!isScalar(disabledPair.value) || typeof disabledPair.value.value !== 'boolean')) {
    errors.push(`${entryName}: 'disabled' must be a boolean`)
  }
  if (insertPair !== undefined) {
    if (!isSeq(insertPair.value)) {
      errors.push(`${entryName}: 'insert' must be a sequence of rows`)
    } else {
      validateInsertChildren(insertPair.value, counter, entryName, errors)
    }
  }
  if (entryId(entry) === 'cordis-fabric') {
    validateFabricEntry(entry, counter, entryName, errors)
  }
}

/**
 * Validate a patch document's syntax and structure.
 * @param text - the patch document text.
 * @returns `{ok: true, errors: []}` for a valid document; otherwise the
 * failure descriptions with line numbers where the AST exposes them.
 */
export function validatePatchDocument(text: string): PatchValidationResult {
  const outcome = parsePatch(text)
  if (!outcome.ok) return { ok: false, errors: outcome.errors }
  const { doc, lineCounter } = outcome
  const errors: string[] = []
  const root = doc.contents
  if (root === null) {
    errors.push('document is empty: expected a sequence of patch entries')
    return { ok: false, errors }
  }
  if (!isSeq(root)) {
    errors.push(`top level (line ${lineOf(lineCounter, root) ?? '?'}) must be a sequence of patch entries`)
    return { ok: false, errors }
  }
  root.items.forEach((entry, index) => validateEntry(entry, lineCounter, index, errors))
  return { ok: errors.length === 0, errors }
}

/** The ids of all `cordis-fabric` stub patches in a parsed document. */
function collectStubIds(doc: Document.Parsed): string[] {
  const ids: string[] = []
  const root = doc.contents
  if (!isSeq(root)) return ids
  for (const entry of root.items) {
    if (!isMap(entry) || entryId(entry) !== 'cordis-fabric') continue
    const patches = pairOf(entry, 'config')?.value
    const fabric = isPlainMap(patches) ? pairOf(patches, 'fabric')?.value : undefined
    const patchList = isPlainMap(fabric) ? pairOf(fabric, 'patches')?.value : undefined
    if (!isSeq(patchList)) continue
    for (const patch of patchList.items) {
      if (!isMap(patch)) continue
      const idPair = pairOf(patch, 'id')
      if (isScalar(idPair?.value) && typeof idPair.value.value === 'string') {
        ids.push(idPair.value.value)
      }
    }
  }
  return ids
}

/** The ids of all `insert` rows in a parsed document. */
function collectInsertIds(doc: Document.Parsed): string[] {
  const ids: string[] = []
  const root = doc.contents
  if (!isSeq(root)) return ids
  for (const entry of root.items) {
    if (!isMap(entry)) continue
    const insert = pairOf(entry, 'insert')?.value
    if (!isSeq(insert)) continue
    for (const child of insert.items) {
      if (!isMap(child)) continue
      const idPair = pairOf(child, 'id')
      if (isScalar(idPair?.value) && typeof idPair.value.value === 'string') {
        ids.push(idPair.value.value)
      }
    }
  }
  return ids
}

/**
 * Check that the plugin's three self rows survive in the text: the
 * `cordis-fabric` stub patch, the `dsh-settings-plus` plugin row, and the
 * `dsh-settings-plus-invariant` companion row.
 * @param text - the patch document text.
 * @returns one description per broken row; an empty array means the rows
 * are intact. An unparseable document reports the rows as unverifiable
 * rather than pretending they exist.
 */
export function assertSelfRowsPreserved(text: string): string[] {
  const outcome = parsePatch(text)
  if (!outcome.ok) {
    return ['self rows cannot be verified: document is not parseable']
  }
  const { doc } = outcome
  const missing: string[] = []
  const stubIds = collectStubIds(doc)
  if (!stubIds.includes(SELF_STUB_ID)) {
    missing.push(`cordis-fabric stub row (patch id '${SELF_STUB_ID}') is missing`)
  }
  const insertIds = collectInsertIds(doc)
  if (!insertIds.includes(SELF_PLUGIN_IDS[0])) {
    missing.push(`plugin row '${SELF_PLUGIN_IDS[0]}' is missing`)
  }
  if (!insertIds.includes(SELF_PLUGIN_IDS[1])) {
    missing.push(`invariant row '${SELF_PLUGIN_IDS[1]}' is missing`)
  }
  return missing
}

/**
 * The combined write gate: semantic validity plus self-protection. When
 * {@link BeforeWriteOptions.requireSelfProtection} is `true` (the default)
 * any missing self row rejects the save; with `false` the semantic result
 * stands alone and the missing rows are only reported.
 * @param text - the patch document text about to be written.
 * @param options - gate options; `requireSelfProtection` defaults to `true`.
 * @returns whether the write may proceed, all failure descriptions, and the
 * missing self rows (empty when intact).
 */
export function validateBeforeWrite(text: string, options: BeforeWriteOptions = {}): BeforeWriteResult {
  const semantic = validatePatchDocument(text)
  const missing = assertSelfRowsPreserved(text)
  const requireSelfProtection = options.requireSelfProtection ?? true
  const errors = [...semantic.errors]
  if (requireSelfProtection && missing.length > 0) {
    errors.push(...missing.map(item => `self-protection: ${item}`))
  }
  return {
    ok: semantic.ok && !(requireSelfProtection && missing.length > 0),
    errors,
    selfRowsMissing: missing,
  }
}
