/**
 * Plugin settings registration SDK: the open registration face other plugins
 * use to declare their own settings namespaces on the host. Two entry points:
 *
 * - {@link registerUserSettings} performs the live registration through the
 *   host `ctx.settings` seam and returns an explicit-removal disposer;
 * - {@link defineSettingsSection} is declarative — it returns a description
 *   object with no side effects, for scenarios that reference a section
 *   without owning its registration.
 *
 * The host seam (`@deepseek-ai/dsh-settings`) is consumed through minimal
 * local contracts rather than an import, exactly like the crawler: this module
 * only calls `ctx.settings.register(...)`, and the types mirror the seam's
 * `SettingsScope` / `SettingsRegisterOptions` shapes so this module builds and
 * tests without host source files.
 *
 * Dedup semantics, stated honestly: there is no registry arbitration here.
 * A namespace is unique per host — `ctx.settings.register` rejects a duplicate
 * with a loud error, and that error surfaces from the call site unchanged.
 * The SDK's `settingsNamespace` brand validates the official naming rule
 * (`^[a-z][a-z0-9-]*$`) before the call so bad names fail at the SDK, not
 * inside the host. When a plugin registers through this SDK, its namespace is
 * authoritative over anything auto-discovery would otherwise enumerate: the
 * registration is the discovery source.
 *
 * Lifecycle: the host registration is an effect on the calling fiber, so a
 * registered namespace disappears when that fiber disposes. The returned
 * disposer is the explicit-removal handle: it must be called for removal (the
 * SDK never removes behind the caller's back). The recommended pattern is
 * `ctx.effect(() => registerUserSettings(ctx, ns, schema))` so the disposer
 * rides the calling fiber and the registration is reclaimed automatically.
 * @module @deepseek-ai/dsh-settings-plus/sdk
 */

import type { Context } from 'cordis'
import type { DshSettingsPlusService } from './service.ts'

/** Nominal brand of one registered settings namespace (local mirror). */
export type SettingsNamespace = string & { readonly __settingsNamespace?: unique symbol }

/** When a namespace's changes take effect for its owner. */
export type SettingsApplies = 'live' | 'restart'

/**
 * Minimal structural face of a schemastery schema the SDK forwards to the
 * host seam. Any real schemastery schema satisfies it; the SDK never touches
 * the schema beyond forwarding it.
 */
export interface SettingsSchemaLike {
  /** Serialized schema envelope; present on every schemastery schema. */
  toJSON(): unknown
}

/**
 * Registration options beyond the namespace schema — field-for-field the
 * seam's `SettingsRegisterOptions` (`@deepseek-ai/dsh-settings`), with the
 * same defaults: `applies` falls back to `live` inside the host.
 */
export interface SettingsRegisterOptionsLike<T = unknown> {
  /** Composition-layer values resolved below the user layer (entry-config subset). */
  base?: Partial<T>
  /** Owner's effect timing, surfaced to configuration UIs; defaults to `live`. */
  applies?: SettingsApplies
  /** Reject a resolved section the owner could not act on, for constraints its schema cannot express. */
  validate?: (value: T) => void
}

/**
 * Owner-facing handle for one registered namespace — field-for-field the
 * seam's `SettingsScope` (`@deepseek-ai/dsh-settings`). `dispose` is the
 * SDK's explicit-removal hook: the official host scope carries no removal
 * method (removal rides the calling fiber's effect), so against the official
 * host this hook is absent and the SDK's disposer degrades to a no-op —
 * removal then happens through fiber disposal. Test doubles and providers
 * that support explicit removal implement it.
 */
export interface SettingsScopeLike<T = unknown> {
  /** Current resolved value: schema defaults, then `base`, then the user layer. */
  get(): T
  /** Observe committed changes; the returned disposer removes this observer. */
  watch(callback: (next: T, prev: T) => void | Promise<void>): () => void
  /** Merge a partial patch into this namespace's user layer and persist it. */
  update(patch: object): Promise<void>
  /** Replace this namespace's user section wholesale; absent keys re-inherit `base` and defaults. */
  replace(section: object): Promise<void>
  /** Explicit-removal hook; absent on the official host scope. */
  dispose?(): void
}

/** Minimal register face of the host settings seam the SDK consumes. */
export interface SettingsRegisterLike {
  register<T>(ns: SettingsNamespace, schema: SettingsSchemaLike, options?: SettingsRegisterOptionsLike<T>): SettingsScopeLike<T>
}

/** One declaratively described settings section, for reference without side effects. */
export interface SettingsSection {
  /** The branded namespace id. */
  ns: SettingsNamespace
  /** The schemastery schema resolving the section's value. */
  schema: SettingsSchemaLike
  /** The registration options the section would be declared with. */
  options?: SettingsRegisterOptionsLike
}

/**
 * Brand a raw string as a {@link SettingsNamespace}, enforcing the official
 * naming rule (lowercase kebab-case, as in plugin short names). Invalid names
 * fail loud so a bad namespace never reaches the host seam.
 * @param value - candidate namespace.
 * @returns the branded namespace.
 * @throws {TypeError} when the value does not match `^[a-z][a-z0-9-]*$`.
 */
export function settingsNamespace(value: string): SettingsNamespace {
  if (!NAMESPACE_PATTERN.test(value)) {
    throw new TypeError(`settings namespace "${value}" must match ${String(NAMESPACE_PATTERN)}`)
  }
  return value as SettingsNamespace
}

/**
 * Describe a settings section declaratively. No registration happens — this
 * is the side-effect-free counterpart to {@link registerUserSettings}, for
 * scenarios that reference a section (for example alongside auto-discovery)
 * without owning its live registration.
 * @param ns - candidate namespace; validated by the brand rule.
 * @param schema - the schemastery schema resolving the section's value.
 * @param options - the registration options the section would be declared with.
 * @returns the declarative section descriptor.
 */
export function defineSettingsSection(
  ns: string,
  schema: SettingsSchemaLike,
  options?: SettingsRegisterOptionsLike,
): SettingsSection {
  return {
    ns: settingsNamespace(ns),
    schema,
    ...(options === undefined ? {} : { options }),
  }
}

/** Carrier shape of a context with the settings seam mounted. */
interface SettingsCarrier {
  settings?: unknown
}

/**
 * Resolve the host settings seam's register face from a context, failing
 * loud when absent so a registration is never attempted against a context
 * that cannot own namespaces.
 * @param ctx - host context with the settings seam mounted.
 * @returns the register face.
 * @throws {Error} when the seam is missing or malformed.
 */
function resolveRegister(ctx: Context): SettingsRegisterLike {
  const settings = (ctx as unknown as SettingsCarrier).settings
  if (settings === undefined || typeof (settings as SettingsRegisterLike).register !== 'function') {
    throw new Error('registerUserSettings requires the "settings" service with a register method on the host context')
  }
  return settings as SettingsRegisterLike
}

/**
 * Probe the host context for the plugin's `dshSettingsPlus` service and mark
 * a freshly registered namespace as SDK-registered. The probe is best-effort
 * and never loud: the service may be absent (the SDK is independently
 * usable), not yet mounted (the consumer fiber starts before this plugin's),
 * or malformed — in every case the registration has already succeeded and the
 * mark is simply skipped. The mark is what the client catalog later uses to
 * tell third-party SDK registrants apart from official DSH namespaces.
 *
 * The probe is deferred to a microtask because Cordis `ctx.get` only resolves
 * services provided by a fiber that has reached the activated state. A
 * consumer plugin's `apply` (and its `ctx.effect` callbacks) can run before
 * the owning `dshSettingsPlus` fiber has activated, so a synchronous
 * `ctx.get` would miss the service even though it was already provided.
 * Deferring lets the whole fiber tree settle first; the probe stays
 * best-effort and silent on failure.
 * @param ctx - the host context the registration went through.
 * @param ns - the namespace id that was just registered.
 */
function markSdkRegistered(ctx: Context, ns: string): void {
  try {
    void Promise.resolve().then(() => {
      const service = ctx.get('dshSettingsPlus') as DshSettingsPlusService | undefined
      service?.markSdkRegistered?.(ns)
    })
  } catch {
    // Service absent or drifted: the SDK stays independently usable, unmarked.
  }
}

/**
 * Register a plugin-owned settings namespace on the host and receive its
 * explicit-removal disposer.
 *
 * The registration is forwarded verbatim to `ctx.settings.register(ns,
 * schema, { base, applies, validate })`: namespace validation and duplicate
 * rejection surface synchronously at the call site (the host rejects a
 * duplicate namespace with a loud error, and that error propagates unchanged
 * — the SDK does not arbitrate namespaces). After a successful registration
 * the SDK additionally marks the namespace through the plugin's
 * `dshSettingsPlus` service when it is mounted (`ctx.get` probe, silent skip
 * otherwise), so the client catalog can surface SDK registrants under the
 * third-party tier. The returned disposer removes
 * the registration when called; the SDK never removes it behind the caller's
 * back. Because the host registration is an effect on the calling fiber, the
 * recommended pattern for automatic reclamation is:
 *
 * ```ts
 * ctx.effect(() => registerUserSettings(ctx, 'my-ns', MySchema))
 * ```
 *
 * @param ctx - host context with the settings seam mounted.
 * @param ns - namespace id; must match `^[a-z][a-z0-9-]*$`.
 * @param schema - schemastery schema resolving this namespace's value.
 * @param options - composition `base` layer, effect timing, and cross-field validation.
 * @returns the disposer removing the registration.
 * @throws {TypeError} when `ns` violates the namespace rule.
 * @throws {Error} when the settings seam is missing, or the host rejects the registration (duplicate namespace, invalid stored section).
 */
export function registerUserSettings<T = unknown>(
  ctx: Context,
  ns: string,
  schema: SettingsSchemaLike,
  options?: SettingsRegisterOptionsLike<T>,
): () => void {
  const settings = resolveRegister(ctx)
  const branded = settingsNamespace(ns)
  const scope = settings.register<T>(branded, schema, options)
  markSdkRegistered(ctx, branded)
  return () => {
    scope.dispose?.()
  }
}

/** Official namespace naming rule: lowercase kebab-case, as in plugin short names. */
const NAMESPACE_PATTERN = new RegExp('^[a-z][a-z0-9-]*$')
