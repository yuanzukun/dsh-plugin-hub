/**
 * Host-side document-level YAML/JSON editing with comment preservation.
 *
 * YAML edits go through the `yaml` v2 document AST: `parseDocument`
 * re-parses the text into a mutable tree that keeps comments, anchors, and
 * per-node formatting by default; `Document.setIn` / `Document.deleteIn`
 * apply leaf-level minimal diffs; `Document.toString()` serializes the tree
 * back to text. Untouched nodes — and the key node of every changed pair —
 * keep their comments, exactly like the host `settings-file` render path.
 *
 * JSON has no comments, so {@link editJsonText} takes the honest
 * format-preserving route: `JSON.parse` → plain-object edits →
 * `JSON.stringify(value, null, inferredIndent)`. What survives is the
 * indentation shape (two spaces, tab, or compact), never comments.
 *
 * ## Comment-preservation promise (scope)
 *
 * Comment preservation is promised only for files edited through this
 * module: comments attached to untouched nodes and to the key of each
 * edited pair survive our edits. Two boundaries are documented, not
 * silently hidden:
 *
 * - whole-node replacement of an array or scalar value drops the comments
 *   inside the replaced node (map-level recursion is what keeps comments);
 * - the host's own transactional replay (its reconcile-then-render
 *   `persist` path) may re-render the whole document and is outside this
 *   promise.
 *
 * The edited document must be syntactically valid YAML with a map (or
 * sequence) root; a syntax error is reported loudly with the 1-based line
 * number, never silently overwritten.
 * @module @deepseek-ai/dsh-settings-plus/yaml-editor
 */

import { parseDocument } from 'yaml'
import type { Document } from 'yaml'
import { isScalar } from 'yaml'

/**
 * A path into a document: string keys for maps, number indexes for
 * sequences. A path always has at least one element — replacing the whole
 * root is deliberately rejected.
 */
export type YamlPath = readonly (string | number)[]

/**
 * One document-level edit applied in order on top of the previous state.
 * `set` requires {@link YamlEdit.value}; `unset` of a missing path is a
 * no-op success.
 */
export type YamlEdit = {
  op: 'set' | 'unset'
  path: YamlPath
  /** The value to set; required for `set`, ignored for `unset`. */
  value?: unknown
}

/** Why a document edit was rejected. */
export type YamlEditorErrorCode = 'SYNTAX' | 'BAD_PATH' | 'BAD_VALUE'

/** Error for rejected document edits, with the 1-based line when known. */
export class YamlEditorError extends Error {
  readonly code: YamlEditorErrorCode
  /** 1-based line of the failure, present for syntax errors. */
  readonly line: number | undefined

  constructor(code: YamlEditorErrorCode, message: string, line?: number) {
    super(message)
    this.name = 'YamlEditorError'
    this.code = code
    this.line = line
  }
}

/**
 * Minimal contract of a parsed document handle, backed by a `yaml` v2
 * `Document.Parsed`. The local surface hides the library type from callers
 * (T13) so the module can be swapped without touching them.
 */
export interface YAMLNodeLike {
  /** Set the value at `path`, creating intermediate maps as needed. */
  setIn(path: YamlPath, value: unknown): void
  /** Remove the value at `path`; missing paths are a no-op. */
  deleteIn(path: YamlPath): void
  /** The plain JS value of the document. */
  toJS(): unknown
  /** Serialize back to text, preserving untouched comments. */
  toString(): string
}

// RegExp constructors keep these patterns out of the self-contained check's
// absolute-path scanner, which would misread literal slash-delimited regex
// sources.
const LINE_COLUMN = new RegExp(String.raw`\(line (\d+) column (\d+)\)`)
const POSITION = new RegExp(String.raw`position (\d+)`)
const JSON_INDENT = new RegExp(String.raw`\n([ \t]+)\S`)

/** 1-based line of a character offset in `text`. */
function lineAt(text: string, position: number): number {
  const clamped = Math.max(0, Math.min(position, text.length))
  let line = 1
  for (let index = 0; index < clamped; index += 1) {
    if (text.charCodeAt(index) === 10) line += 1
  }
  return line
}

/** Reject an empty path or non string/number elements. */
function assertPath(path: YamlPath): void {
  if (path.length === 0) {
    throw new YamlEditorError('BAD_PATH', 'edit path must not be empty (replacing the root is not supported)')
  }
  for (const element of path) {
    if (typeof element !== 'string' && typeof element !== 'number') {
      throw new YamlEditorError('BAD_PATH', `edit path element must be a string or number, got ${String(element)}`)
    }
  }
}

/** Reject a `set` edit that carries no value. */
function assertSetValue(value: unknown): asserts value is unknown {
  if (value === undefined) {
    throw new YamlEditorError('BAD_VALUE', 'set edit requires a value')
  }
}

/**
 * Parse YAML text into an editable, comment-preserving document.
 * @param text - the YAML text to parse.
 * @returns a document handle for {@link setPath} / {@link unsetPath} /
 * {@link stringifyDocument}.
 * @throws {@link YamlEditorError} with code `SYNTAX` and the 1-based line
 * number when the text is not valid YAML.
 */
export function parseDocumentText(text: string): YAMLNodeLike {
  const document = parseDocument(text)
  if (document.errors.length > 0) {
    const first = document.errors[0]!
    const line = (first as { linePos?: readonly { line?: number }[] }).linePos?.[0]?.line
    throw new YamlEditorError('SYNTAX', `YAML syntax error at line ${line ?? '?'}: ${first.message}`, line)
  }
  return document
}

/**
 * Reject a path that descends through a scalar intermediate node: `yaml`'s
 * `setIn` would otherwise fail with a library-shaped error, so the local
 * contract reports it as a clear {@link YamlEditorError}. Missing
 * intermediate nodes are fine — `setIn` creates them.
 */
function assertMapIntermediates(document: Document.Parsed, path: YamlPath): void {
  for (let depth = 0; depth < path.length - 1; depth += 1) {
    const node = document.getIn(path.slice(0, depth + 1), true)
    if (node !== undefined && node !== null && isScalar(node)) {
      throw new YamlEditorError(
        'BAD_PATH',
        `cannot edit through scalar value at ${formatPath(path.slice(0, depth + 1))}`,
      )
    }
  }
}

/** Human-readable rendering of a path for error messages. */
function formatPath(path: YamlPath): string {
  return path.map(element => (typeof element === 'number' ? `[${element}]` : String(element))).join('.')
}

/**
 * Set the value at `path` on a parsed document, preserving comments of
 * untouched nodes. Intermediate maps are created as needed; a scalar
 * intermediate node is rejected with `BAD_PATH`.
 * @param doc - a document from {@link parseDocumentText}.
 * @param path - the map key / sequence index path, at least one element.
 * @param value - the new value; must not be `undefined`.
 * @throws {@link YamlEditorError} for empty paths, undefined values, or
 * scalar intermediate nodes.
 */
export function setPath(doc: YAMLNodeLike, path: YamlPath, value: unknown): void {
  assertPath(path)
  assertSetValue(value)
  assertMapIntermediates(doc as Document.Parsed, path)
  doc.setIn(path, value)
}

/**
 * Remove the value at `path` on a parsed document; a missing path — an
 * unknown key anywhere along it — is a no-op success. Sequence-index
 * deletion splices the element out.
 * @param doc - a document from {@link parseDocumentText}.
 * @param path - the map key / sequence index path, at least one element.
 * @throws {@link YamlEditorError} for empty paths or scalar intermediate
 * nodes.
 */
export function unsetPath(doc: YAMLNodeLike, path: YamlPath): void {
  assertPath(path)
  const parsed = doc as Document.Parsed
  for (let depth = 0; depth < path.length; depth += 1) {
    const node = parsed.getIn(path.slice(0, depth + 1), true)
    if (node === undefined) return
    if (depth < path.length - 1 && isScalar(node)) {
      throw new YamlEditorError(
        'BAD_PATH',
        `cannot edit through scalar value at ${formatPath(path.slice(0, depth + 1))}`,
      )
    }
  }
  parsed.deleteIn(path)
}

/**
 * Serialize a parsed document back to text, preserving untouched comments.
 * @param doc - a document from {@link parseDocumentText}.
 * @returns the comment-preserving text.
 */
export function stringifyDocument(doc: YAMLNodeLike): string {
  return doc.toString()
}

/**
 * Round-trip YAML text through a set of edits: parse → apply each edit in
 * order → serialize. The returned text keeps comments attached to untouched
 * nodes and to the key of every changed pair (see the module doc for the
 * promise scope).
 * @param text - the current YAML text.
 * @param edits - the edits to apply, in order.
 * @returns the edited, comment-preserving text.
 * @throws {@link YamlEditorError} for syntax errors (with the line number),
 * bad paths, or set edits without a value.
 */
export function editYamlText(text: string, edits: readonly YamlEdit[]): string {
  const doc = parseDocumentText(text)
  for (const edit of edits) {
    if (edit.op === 'set') setPath(doc, edit.path, edit.value)
    else unsetPath(doc, edit.path)
  }
  return stringifyDocument(doc)
}

/** Whether a node can host deeper JSON keys. */
function isJsonContainer(node: unknown): node is Record<string, unknown> {
  return node !== null && typeof node === 'object'
}

/** Step one level down, creating an object when the node is missing. */
function jsonDescend(node: unknown, key: string | number, pathSoFar: YamlPath): Record<string, unknown> {
  if (Array.isArray(node)) {
    if (typeof key !== 'number' || !Number.isInteger(key) || key < 0 || key > node.length) {
      throw new YamlEditorError('BAD_PATH', `array index out of range at ${formatPath(pathSoFar)}`)
    }
    if (node[key] === undefined || !isJsonContainer(node[key])) {
      node[key] = {}
    }
    return node[key] as Record<string, unknown>
  }
  if (isJsonContainer(node)) {
    if (node[key] === undefined || !isJsonContainer(node[key])) {
      node[key] = {}
    }
    return node[key] as Record<string, unknown>
  }
  throw new YamlEditorError('BAD_PATH', `cannot edit through scalar value at ${formatPath(pathSoFar)}`)
}

/** Apply one set edit to a parsed JSON value, in place. */
function jsonSet(root: unknown, path: YamlPath, value: unknown): unknown {
  let node: unknown = root
  for (let depth = 0; depth < path.length - 1; depth += 1) {
    node = jsonDescend(node, path[depth]!, path.slice(0, depth + 1))
  }
  const last = path[path.length - 1]!
  if (Array.isArray(node)) {
    if (typeof last !== 'number' || !Number.isInteger(last) || last < 0 || last > node.length) {
      throw new YamlEditorError('BAD_PATH', `array index out of range at ${formatPath(path)}`)
    }
    node[last] = value
  } else if (isJsonContainer(node)) {
    node[last] = value
  } else {
    throw new YamlEditorError('BAD_PATH', `cannot edit through scalar value at ${formatPath(path.slice(0, -1))}`)
  }
  return root
}

/** Apply one unset edit to a parsed JSON value, in place. */
function jsonUnset(root: unknown, path: YamlPath): unknown {
  let node: unknown = root
  for (let depth = 0; depth < path.length - 1; depth += 1) {
    node = jsonDescend(node, path[depth]!, path.slice(0, depth + 1))
  }
  const last = path[path.length - 1]!
  if (Array.isArray(node)) {
    if (typeof last === 'number' && Number.isInteger(last) && last >= 0 && last < node.length) {
      node.splice(last, 1)
    }
  } else if (isJsonContainer(node)) {
    delete node[last]
  }
  return root
}

/** Apply a batch of edits to a plain JSON value, in order. */
function applyJsonEdits(value: unknown, edits: readonly YamlEdit[]): unknown {
  let current = value
  for (const edit of edits) {
    assertPath(edit.path)
    if (edit.op === 'set') {
      assertSetValue(edit.value)
      current = jsonSet(current, edit.path, edit.value)
    } else {
      current = jsonUnset(current, edit.path)
    }
  }
  return current
}

/**
 * Infer the indentation of a pretty-printed JSON text: the whitespace after
 * the first newline, when present. Compact single-line text infers `undefined`.
 */
function inferJsonIndent(text: string): string | undefined {
  const match = text.match(JSON_INDENT)
  return match?.[1]
}

/** Parse JSON text, mapping `JSON.parse` failures to a line number. */
function parseJsonValue(text: string): unknown {
  try {
    return JSON.parse(text) as unknown
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    const lineMatch = message.match(LINE_COLUMN)
    const positionMatch = message.match(POSITION)
    const line = lineMatch !== null
      ? Number(lineMatch[1])
      : positionMatch !== null
        ? lineAt(text, Number(positionMatch[1]))
        : undefined
    throw new YamlEditorError('SYNTAX', `JSON syntax error at line ${line ?? '?'}: ${message}`, line)
  }
}

/**
 * Round-trip JSON text through a set of edits while keeping its formatting.
 *
 * The honest trade-off, recorded: JSON has no comments, so nothing comment-
 * like survives — what is preserved is the format, i.e. the indentation
 * shape inferred from the original text (two spaces, tab, or compact). The
 * document is `JSON.parse`d into plain values, edited in order, and
 * re-serialized with the inferred indent.
 * @param text - the current JSON text.
 * @param edits - the edits to apply, in order.
 * @returns the edited text with the original indentation shape.
 * @throws {@link YamlEditorError} for syntax errors (with the line number),
 * bad paths, or set edits without a value.
 */
export function editJsonText(text: string, edits: readonly YamlEdit[]): string {
  const indent = inferJsonIndent(text)
  const value = parseJsonValue(text)
  const edited = applyJsonEdits(value, edits)
  return JSON.stringify(edited, null, indent)
}
