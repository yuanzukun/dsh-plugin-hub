/**
 * Host-side configuration directory browser: enumerates the DSH
 * configuration file manifest — writable home-root YAML files, writable
 * per-profile `cordis` patches, and read-only bundle layers declared by
 * profile manifests — and validates every resolved path against a realpath
 * boundary.
 *
 * The writable manifest is a closed list (Metis M-4): `$DSH_HOME` root
 * `*.yml`/`*.yaml` (including `cordis.patch.yml` and `settings.yaml`) plus
 * `profiles/<name>/cordis*.yml`. Bundle layers are read-only display surfaces:
 * the `cordis.patch.yml` shipped inside every bundle package a profile's
 * `package.json` declares under `dsh.profile.bundles`.
 *
 * This module only enumerates and validates — no file is read or written
 * here. Content editing (T11+) routes every write through
 * {@link isWritableTarget} so nothing outside the manifest can be touched.
 * @module @deepseek-ai/dsh-settings-plus/file-browser
 */

import { readdirSync, readFileSync, realpathSync, statSync } from 'node:fs'
import { homedir } from 'node:os'
import { basename, dirname, isAbsolute, join, relative, resolve } from 'node:path'

/** Where a configuration file lives relative to the DSH home. */
export type ConfigFileScope = 'home' | 'profile'

/** What a configuration file is, from the file's name. */
export type ConfigFileKind = 'cordis-patch' | 'settings' | 'yaml' | 'json'

/** One configuration file on the enumerated manifest. */
export interface ConfigFileEntry {
  /** Absolute path of the file. */
  path: string
  /** Path relative to the DSH home, the stable identifier for surfaces. */
  relative: string
  /** `home` for `$DSH_HOME` root files, `profile` for profile-scoped files. */
  scope: ConfigFileScope
  /**
   * Whether the file is on the writable manifest. Bundle layers are
   * enumerated read-only and are never writable targets.
   */
  writable: boolean
  /** Classified from the file name: `cordis.patch.yml` → `cordis-patch`, `settings.yaml` → `settings`, … */
  kind: ConfigFileKind
}

/** Realpath provider, injectable so boundary checks stay unit-testable. */
export interface FileSystemLike {
  /** Node-style `fs.realpathSync`, throwing on missing paths. */
  realpathSync(path: string): string
}

const defaultFs: FileSystemLike = { realpathSync }

// RegExp constructors keep these patterns out of the self-contained check's
// absolute-path scanner, which would misread literal slash-delimited regex
// sources.
const YAML_FILE = new RegExp(String.raw`\.ya?ml$`, 'i')
const CORDIS_FILE = new RegExp(String.raw`^cordis.*\.ya?ml$`, 'i')
const SETTINGS_FILE = new RegExp(String.raw`^settings\.ya?ml$`, 'i')

/**
 * Resolve the DSH home the configuration manifest lives under, in the same
 * precedence as the harness workspace store: explicit `configHome`, then
 * `$DSH_HOME`, then the `.dsh` directory under the user home.
 * @param configHome - the configured home; an empty string skips this tier.
 * @returns the resolved home path.
 */
export function resolveDshHome(configHome: string): string {
  if (configHome !== '') return resolve(configHome)
  if (process.env.DSH_HOME !== undefined && process.env.DSH_HOME !== '') {
    return resolve(process.env.DSH_HOME)
  }
  return join(homedir(), '.dsh')
}

/** Whether the path is an existing regular file. */
function isFile(path: string): boolean {
  try {
    return statSync(path).isFile()
  } catch {
    return false
  }
}

/** Whether the path is an existing directory. */
function isDirectory(path: string): boolean {
  try {
    return statSync(path).isDirectory()
  } catch {
    return false
  }
}

/** Normalize a relative path to POSIX separators, the stable contract form. */
function toPosix(path: string): string {
  return path.split('\\').join('/')
}

/** Classify a configuration file's kind from its name. */
function classifyKind(fileName: string): ConfigFileEntry['kind'] {
  if (CORDIS_FILE.test(fileName)) return 'cordis-patch'
  if (SETTINGS_FILE.test(fileName)) return 'settings'
  if (YAML_FILE.test(fileName)) return 'yaml'
  return 'json'
}

/** Minimal shape of a profile `package.json` manifest the bundle layer reads. */
interface ProfileManifestLike {
  dsh?: {
    profile?: {
      bundles?: unknown
    }
  }
}

/**
 * Collect a profile's read-only bundle layers: the `cordis.patch.yml`
 * shipped inside every bundle package `package.json` declares under
 * `dsh.profile.bundles`. Declared bundles whose patch is missing, and
 * profiles without a manifest, contribute nothing.
 * @param dshHome - the resolved home, for computing relative paths.
 * @param profileDir - one `$DSH_HOME/profiles/<name>` directory.
 * @returns read-only bundle entries, in declaration order.
 */
function listBundleLayers(dshHome: string, profileDir: string): ConfigFileEntry[] {
  let raw: string
  try {
    raw = readFileSync(join(profileDir, 'package.json'), 'utf8')
  } catch {
    return []
  }
  let parsed: unknown
  try {
    parsed = JSON.parse(raw) as unknown
  } catch {
    return []
  }
  const bundles = (parsed as ProfileManifestLike).dsh?.profile?.bundles
  if (!Array.isArray(bundles)) return []
  const entries: ConfigFileEntry[] = []
  for (const bundle of bundles) {
    if (typeof bundle !== 'string' || bundle === '') continue
    const patch = join(profileDir, 'node_modules', bundle, 'cordis.patch.yml')
    if (!isFile(patch)) continue
    entries.push({
      path: patch,
      relative: toPosix(relative(dshHome, patch)),
      scope: 'profile',
      writable: false,
      kind: 'cordis-patch',
    })
  }
  return entries
}

/**
 * Enumerate the closed configuration manifest under one DSH home: writable
 * home-root `*.yml`/`*.yaml` files, writable `profiles/<name>/cordis*.yml`
 * patches, and read-only bundle layers. A missing or unreadable home
 * enumerates as empty.
 * @param dshHome - the resolved DSH home.
 * @returns manifest entries; home-root entries first, then per-profile
 * writable patches, then read-only bundle layers.
 */
export function listConfigFiles(dshHome: string): ConfigFileEntry[] {
  const entries: ConfigFileEntry[] = []
  let rootFiles: string[] = []
  try {
    rootFiles = readdirSync(dshHome)
  } catch {
    return entries
  }
  for (const fileName of rootFiles) {
    if (!YAML_FILE.test(fileName)) continue
    const path = join(dshHome, fileName)
    if (!isFile(path)) continue
    entries.push({
      path,
      relative: fileName,
      scope: 'home',
      writable: true,
      kind: classifyKind(fileName),
    })
  }
  let profileNames: string[] = []
  try {
    profileNames = readdirSync(join(dshHome, 'profiles'))
  } catch {
    return entries
  }
  for (const profileName of profileNames) {
    const profileDir = join(dshHome, 'profiles', profileName)
    if (!isDirectory(profileDir)) continue
    let files: string[] = []
    try {
      files = readdirSync(profileDir)
    } catch {
      continue
    }
    for (const fileName of files) {
      if (!CORDIS_FILE.test(fileName)) continue
      const path = join(profileDir, fileName)
      if (!isFile(path)) continue
      entries.push({
        path,
        relative: toPosix(relative(dshHome, path)),
        scope: 'profile',
        writable: true,
        kind: classifyKind(fileName),
      })
    }
    entries.push(...listBundleLayers(dshHome, profileDir))
  }
  return entries
}

/**
 * Realpath a candidate path even when it does not exist yet, by resolving
 * the deepest existing ancestor and re-appending the missing remainder.
 * @param path - the candidate path.
 * @param fsImpl - realpath provider.
 * @returns the canonicalized candidate path.
 * @throws when no ancestor exists at all.
 */
function resolveExisting(path: string, fsImpl: FileSystemLike): string {
  const pending: string[] = []
  let current = resolve(path)
  for (;;) {
    try {
      return join(fsImpl.realpathSync(current), ...pending.reverse())
    } catch {
      const parent = dirname(current)
      if (parent === current) throw new Error(`no existing ancestor for ${path}`)
      pending.push(basename(current))
      current = parent
    }
  }
}

/**
 * Boundary check: realpath-normalize `candidate` and confirm it stays inside
 * the realpath-normalized `root`. Symlink escapes and `..` traversal both
 * collapse into a path outside the root and resolve to `null`.
 * @param root - the boundary root (the DSH home).
 * @param candidate - the candidate path to validate.
 * @param fsImpl - injectable realpath provider.
 * @returns the canonicalized in-boundary path, or `null` when the candidate
 * is outside the root or cannot be resolved.
 */
export function resolveInside(root: string, candidate: string, fsImpl: FileSystemLike = defaultFs): string | null {
  try {
    const rootReal = fsImpl.realpathSync(root)
    const candidateReal = resolveExisting(candidate, fsImpl)
    const rel = relative(rootReal, candidateReal)
    if (rel === '') return rootReal
    if (rel.startsWith('..') || isAbsolute(rel)) return null
    return candidateReal
  } catch {
    return null
  }
}

/** Whether two paths denote the same file, case-insensitively on Windows. */
function samePath(a: string, b: string): boolean {
  const na = resolve(a)
  const nb = resolve(b)
  if (process.platform === 'win32') return na.toLowerCase() === nb.toLowerCase()
  return na === nb
}

/**
 * Confirm a path is a writable target: it must resolve inside the DSH home
 * boundary *and* appear on the writable manifest. This is the guard every
 * future file write (T11+) must pass; bundle layers and arbitrary files
 * (`.env`, `notes.txt`, …) fail here.
 * @param dshHome - the resolved DSH home.
 * @param path - the candidate write target.
 * @returns whether writing to the path is permitted.
 */
export function isWritableTarget(dshHome: string, path: string): boolean {
  const resolved = resolveInside(dshHome, path)
  if (resolved === null) return false
  return listConfigFiles(dshHome).some(entry => entry.writable && samePath(entry.path, resolved))
}
