/**
 * Host-side raw configuration file store: reads and writes configuration
 * files through an injected fs channel (the ctx.fs contract shape) with
 * byte-size limits, an in-boundary guard, and optimistic concurrency via an
 * expected-version write guard.
 *
 * The channel decision, recorded honestly: this wave works on plain path
 * strings through the local {@link FsLike} contract, and the local
 * {@link FsLike.resolve} hook is used when the injected channel provides one.
 * The real host `ctx.fs` adapter (target resolution plus sandbox policy
 * wiring) is not connected yet — T16's distribution smoke test wires it.
 * Nothing here pretends a host wire exists: without an injected `resolve`,
 * the path string itself is the channel target.
 *
 * Version tokens are opaque (never constructed by callers); they come from
 * the channel's `stat` or write outcomes, mirroring the host fs contract.
 * @module @deepseek-ai/dsh-settings-plus/file-store
 */

import { Buffer } from 'node:buffer'
import { isWritableTarget, resolveDshHome, resolveInside } from './file-browser.ts'

/** Inclusive byte cap on a single file read. */
export const MAX_READ_BYTES = 512 * 1024

/** Inclusive byte cap on a single file write. */
export const MAX_WRITE_BYTES = 1024 * 1024

/** Brand symbol backing the local opaque freshness token type. */
export const fsVersionBrand: unique symbol = Symbol('FsVersion')

/**
 * Opaque freshness token guarding writes. Only the fs channel can produce
 * one (from `stat` or a write outcome); callers must not fabricate versions.
 * Channel implementations and test fakes tag their tokens with
 * {@link fsVersionBrand}.
 */
export type FsVersion = { readonly [fsVersionBrand]: 'FsVersion' }

/** Guarded write intent, mirroring the host `replaceIfVersion` arm. */
export interface FsWriteIntentLike {
  kind: 'replaceIfVersion'
  version: FsVersion
}

/** Write outcome from the channel, carrying the post-write version. */
export interface FsWriteOutcomeLike {
  operation: 'create' | 'update'
  version: FsVersion
  before: string | null
  after: string
}

/** Metadata a channel may report for a target, mirroring the host FsInfo. */
export interface FsStatLike {
  version: FsVersion
  type: 'file' | 'directory' | 'other'
  size?: number
}

/**
 * Minimal contract of the host ctx.fs channel, local to this module: it
 * never imports a host package. `readText` returns text only; the freshness
 * token comes from `stat` or write outcomes, exactly like the host service.
 * `resolve` is optional — when absent, the path string itself is the target.
 */
export interface FsLike {
  /** Read the whole text file. */
  readText(target: unknown, signal?: AbortSignal): Promise<string>
  /**
   * Atomically create-or-replace text. `expected` guards staleness; omitting
   * it means unconditional overwrite.
   */
  writeText(
    target: unknown,
    content: string,
    expected?: FsWriteIntentLike,
    signal?: AbortSignal,
  ): Promise<FsWriteOutcomeLike>
  /** Metadata for a target; undefined when absent. */
  stat?(target: unknown, signal?: AbortSignal): Promise<FsStatLike | undefined>
  /** Resolve a path to the channel's opaque target, when the channel has one. */
  resolve?(path: string): Promise<unknown>
}

/** What a rejected operation in this module is. */
export type FileStoreErrorCode = 'TARGET_FORBIDDEN' | 'FILE_TOO_LARGE' | 'CONTENT_TOO_LARGE'

/** Error for operations rejected before reaching the channel. */
export class FileStoreError extends Error {
  readonly code: FileStoreErrorCode

  constructor(code: FileStoreErrorCode, message: string) {
    super(message)
    this.name = 'FileStoreError'
    this.code = code
  }
}

/**
 * Recognize the host channel's stale-version conflict: the stable error code
 * `FS_STALE_VERSION`. Callers branch on the code, never on the message.
 * @param error - anything a write path may have thrown.
 * @returns true when the error signals a version conflict.
 */
export function isConflictError(error: unknown): boolean {
  if (error === null || typeof error !== 'object') return false
  const candidate = error as { code?: unknown }
  return candidate.code === 'FS_STALE_VERSION'
}

/**
 * Minimal host context this module consumes. The real host wiring passes the
 * `ctx.fs` service here at T16; tests inject a fake channel.
 */
export interface HostContextLike {
  /** The host fs channel, injectable so unit tests run without a host. */
  fs: FsLike
}

/** Options the store closes over. */
export interface FileStoreOptions {
  /** The DSH home every read/write is validated against. */
  dshHome?: string
}

/** Result of a successful read. */
export interface FileReadResult {
  /** The full decoded text content. */
  content: string
  /** Freshness token for a later guarded write; undefined when the channel has no stat. */
  version: FsVersion | undefined
}

/** Host-side raw file access with boundary and size guards. */
export interface FileStore {
  /**
   * Read a configuration file: boundary-check the path, then read text
   * through the channel. Files larger than {@link MAX_READ_BYTES} are
   * rejected before or after the read.
   * @param path - the absolute path to read.
   * @returns the content plus the stat version for a guarded write.
   */
  readFile(path: string): Promise<FileReadResult>
  /**
   * Write a configuration file: the path must be on the writable manifest,
   * the content must fit {@link MAX_WRITE_BYTES}, and an expected version
   * guards against stale writes via `replaceIfVersion`. Without an expected
   * version the write is unconditional.
   * @param path - the absolute path to write.
   * @param content - the full new file content.
   * @param expectedVersion - freshness token from a prior read or write;
   *   omit for unconditional overwrite.
   * @returns the channel write outcome.
   */
  writeFile(path: string, content: string, expectedVersion?: FsVersion): Promise<FsWriteOutcomeLike>
}

/**
 * Create a file store over one DSH home. `dshHome` defaults through
 * {@link resolveDshHome} like the file browser.
 * @param ctx - host context carrying the fs channel.
 * @param options - store options; `dshHome` defaults to the resolved home.
 * @returns the file store.
 */
export function createFileStore(ctx: HostContextLike, options?: FileStoreOptions): FileStore {
  const dshHome = resolveDshHome(options?.dshHome ?? '')
  const fs = ctx.fs

  /** Resolve the channel target: the channel's own target when it has one, else the path string. */
  async function channelTarget(path: string): Promise<unknown> {
    if (fs.resolve === undefined) return path
    return await fs.resolve(path)
  }

  return {
    async readFile(path) {
      if (resolveInside(dshHome, path) === null) {
        throw new FileStoreError('TARGET_FORBIDDEN', `read target outside dsh home: ${path}`)
      }
      let version: FsVersion | undefined
      if (fs.stat !== undefined) {
        const stat = await fs.stat(path)
        if (stat !== undefined && stat.size !== undefined && stat.size > MAX_READ_BYTES) {
          throw new FileStoreError('FILE_TOO_LARGE', `file exceeds ${MAX_READ_BYTES} bytes: ${path}`)
        }
        version = stat?.version
      }
      const target = await channelTarget(path)
      const content = await fs.readText(target)
      if (Buffer.byteLength(content, 'utf8') > MAX_READ_BYTES) {
        throw new FileStoreError('FILE_TOO_LARGE', `file exceeds ${MAX_READ_BYTES} bytes: ${path}`)
      }
      return { content, version }
    },
    async writeFile(path, content, expectedVersion) {
      if (!isWritableTarget(dshHome, path)) {
        throw new FileStoreError('TARGET_FORBIDDEN', `write target not on the writable manifest: ${path}`)
      }
      if (Buffer.byteLength(content, 'utf8') > MAX_WRITE_BYTES) {
        throw new FileStoreError('CONTENT_TOO_LARGE', `content exceeds ${MAX_WRITE_BYTES} bytes: ${path}`)
      }
      const target = await channelTarget(path)
      const expected = expectedVersion === undefined ? undefined : { kind: 'replaceIfVersion' as const, version: expectedVersion }
      return await fs.writeText(target, content, expected)
    },
  }
}
