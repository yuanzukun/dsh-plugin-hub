/**
 * Runtime boundary and Cordis activation for the plugin.
 * @module @deepseek-ai/dsh-settings-plus/runtime
 */

import type { Context } from 'cordis'
import { resolveConfig, type Config } from './config.ts'
import { createCrawler } from './crawler.ts'
import { registerExposedNamespacesPatch } from './fabric.ts'
import { registerSettingsPlusRpc } from './rpc.ts'
import { createDshSettingsPlusService } from './service.ts'

/** Fakeable host boundary used by the minimal plugin behavior. */
export interface PluginRuntime {
  /** Publish one informational message through the host. */
  info(message: string): void
}

/**
 * Create the production runtime adapter from a scoped Cordis context.
 * @param ctx - Scoped plugin context.
 * @returns Host behavior used by the plugin implementation.
 */
export function createPluginRuntime(ctx: Context): PluginRuntime {
  return {
    info: message => { ctx.logger.info(message) },
  }
}

/**
 * Apply the plugin to its Cordis context.
 *
 * The `settings` seam is guaranteed ready by `inject = ['settings']`. The
 * crawler (read-only enumeration) feeds both the published service and the
 * fabric exposure widening; the service itself is owned by the plugin fiber
 * through an effect, so it disappears exactly when this bundle unloads.
 * @param ctx - Scoped plugin context; registrations must be owned by its effects.
 * @param config - Configuration resolved by Cordis from the exported schema.
 */
export function apply(ctx: Context, config: Config): void {
  const runtime = createPluginRuntime(ctx)
  runtime.info(resolveConfig(config).message)

  const crawler = createCrawler(ctx)

  const service = createDshSettingsPlusService(ctx, crawler)
  // Provide the service synchronously: the RPC channel below resolves it via
  // ctx.get within the same apply pass, so an effect-deferred provide would
  // not be visible yet. The disposer is tied to the plugin fiber through the
  // effect cleanup, so the service disappears exactly when this bundle
  // unloads.
  const disposeService = ctx.provide('dshSettingsPlus', service)
  ctx.effect(() => () => disposeService(), 'dsh-settings-plus: service dispose')

  const registered = registerExposedNamespacesPatch(ctx, crawler)
  if (registered) {
    runtime.info('exposed-namespaces fabric patch registered')
  } else {
    runtime.info('fabricCompat facade not mounted; exposed-namespaces widening stays a safe no-op')
  }

  const rpcRegistered = registerSettingsPlusRpc(ctx, {
    service,
    officialFileEntries: resolveConfig(config).officialFileEntries,
  })
  if (rpcRegistered) {
    runtime.info('browser rpc channel registered (loopback authority)')
  } else {
    runtime.info('connection service not mounted; browser rpc channel skipped')
  }
}
