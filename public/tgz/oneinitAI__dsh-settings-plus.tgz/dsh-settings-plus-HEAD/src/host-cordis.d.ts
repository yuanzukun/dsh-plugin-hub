/**
 * Local typecheck stub for `@deepseek-ai/cordis`: the host package does not
 * exist as a dependency here, and `tsconfig.base.json` maps the name to this
 * file so the service's `declare module` augmentation resolves during local
 * typechecking. Real host checkouts resolve the published package instead;
 * this stub never leaves the repository type graph.
 */
export * from 'cordis'
