/**
 * Package-owned invariant companion for `@deepseek-ai/dsh-settings-plus`.
 * @module @deepseek-ai/dsh-settings-plus/invariant
 */

import type { Context } from 'cordis'

const PACKAGE_NAME = '@oneinitai/dsh-settings-plus'

/** A package-attributed invariant failure reported by the host registry. */
type InvariantFailure = (message: string) => never

/** Installer callback accepted by the host's invariant registry. */
type InvariantInstaller = (ctx: Context, fail: InvariantFailure) => void | Promise<void>

/** Minimal runtime contract used by the companion without a source checkout. */
interface InvariantRegistry {
  register(packageName: string, installer: InvariantInstaller): () => void
}

/** Cordis companion plugin name. */
export const name = 'dsh-settings-plus-invariant'
/** Service required before the companion can reserve package ownership. */
export const inject = ['invariants']

/**
 * No runtime invariant, for a package-specific reason:
 *
 * - The crawler's namespace enumeration (`listNamespaces` in src/crawler.ts)
 *   is a direct pass-through of the host seam's
 *   `ctx.settings.describe({ redactSecrets: true })` — there is no second
 *   enumeration surface inside this package whose agreement a runtime check
 *   could verify. The host settings service is the single arbiter of
 *   registered namespaces: duplicates fail loud at `register` time.
 * - The registration SDK (`src/sdk.ts`) forwards verbatim to that same seam,
 *   so registration consistency is enforced by the host at the call site,
 *   not by this package.
 * - This package owns no authoritative event sequence or mutable data
 *   relation beyond what the host seam already guards. The file-store's
 *   expected-version write guard and the client's signature diffing are
 *   local correctness mechanisms, each already proven by its own tests.
 *
 * A future package-owned cache of host state (for example the wire surface
 * that will serve catalog data to the browser) is the natural place for a
 * real invariant — revisit this file when that surface lands.
 */
const install: InvariantInstaller = () => {}

/**
 * Resolve the host registry through Cordis's named service lookup. Keeping this
 * narrow local contract lets the template build without host source files; a
 * composed DSH profile still supplies the real `invariants` service.
 * @param ctx - Cordis context carrying the host service.
 * @returns the host invariant registry.
 * @throws {Error} when the companion is loaded without its host service.
 */
function getInvariantRegistry(ctx: Context): InvariantRegistry {
  const registry = ctx.get('invariants') as InvariantRegistry | undefined
  if (registry === undefined) {
    throw new Error(`invariant companion requires the "invariants" service for ${PACKAGE_NAME}`)
  }
  return registry
}

/**
 * Register this package's invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export const apply = (ctx: Context): Promise<() => void> =>
  Promise.resolve(getInvariantRegistry(ctx).register(PACKAGE_NAME, install))
