/**
 * Pure logic for the generic schema form renderer (T9): envelope
 * rehydration, whitelist rendering decisions, the write-op builder with the
 * secret placeholder protocol, unset-only resets, conflict detection, and
 * the small path/json helpers the component shares with the tests.
 *
 * Wire-safety decisions stated honestly:
 * - Secrets never travel from the host to the browser as plaintext; the
 *   descriptor carries only `RedactedSecretPosition` markers. A secret
 *   control therefore shows an empty password input whose placeholder says
 *   whether a value is configured, and an untouched/empty/placeholder input
 *   produces NO write op.
 * - A reset is a bare `{ op: 'unset', path }` with no value, so paths the
 *   wire never returned (configured secrets) survive it by construction.
 * @module @deepseek-ai/dsh-settings-plus/client/form-logic
 */

/**
 * The string a secret control yields instead of a real value: the UI shows
 * an empty password box, so a "change" of this marker is never a real
 * change. For non-secret fields it is an ordinary string (the write path
 * treats it as data, never as a protocol marker).
 */
export const REDACTED_PLACEHOLDER = '\u0000dsh-secret-placeholder\u0000'

/**
 * A rehydrated schemastery node. Mirrors the toJSON node shape: `dict` for
 * object members, `list` for union branches, `inner`/`sKey` for
 * array/dict element schemas, `value` for const branches — with every
 * cross-reference resolved to a sibling node instead of a numeric uid.
 */
export interface SchemaNodeLike {
  type: string
  meta: Record<string, unknown>
  dict?: Record<string, SchemaNodeLike>
  list?: readonly SchemaNodeLike[]
  inner?: SchemaNodeLike
  sKey?: SchemaNodeLike
  value?: unknown
}

/** A redacted secret marker: where a secret lives and whether it is set. */
export interface RedactedSecretPosition {
  path: readonly string[]
  set: boolean
}

/**
 * One mutation the form computed from a field edit. `set` carries the next
 * value; `unset` deliberately carries none (so a reset cannot clobber paths
 * the wire never returned, i.e. configured secrets).
 */
export type SettingsPathOp =
  | { op: 'set'; path: readonly string[]; value: unknown }
  | { op: 'unset'; path: readonly string[] }

/** Field metadata shared by group and leaf descriptors. */
interface FieldDescriptorBase {
  key: string
  /** Root-relative path; `[]` is the root value itself. */
  path: readonly string[]
  /** Humanized label derived from the key. */
  label: string
}

/** A nested object rendered as a labeled group of child descriptors. */
export interface GroupFieldDescriptor extends FieldDescriptorBase {
  kind: 'group'
  children: readonly FieldDescriptor[]
}

/**
 * A leaf node mapped to one control. `control` is the whitelisted native
 * control ('select' for const-only unions), 'json' is the fallback raw
 * editor with `fallback: true`. `secret: true` marks role('secret') fields
 * so the write path applies the placeholder protocol.
 */
export interface LeafFieldDescriptor extends FieldDescriptorBase {
  kind: 'field'
  control: 'string' | 'number' | 'boolean' | 'select' | 'json'
  secret: boolean
  fallback: boolean
  description?: string
  /** Select options (const-only union branches). */
  choices?: readonly (string | number | boolean)[]
}

/** The render tree: one descriptor per editable slot of a schema. */
export type FieldDescriptor = GroupFieldDescriptor | LeafFieldDescriptor

/**
 * The per-entry descriptor the form renders from. `schema` is the
 * schemastery toJSON envelope, `value` the effective settings object,
 * `user` the user-override layer (reset visibility), `secrets` the redacted
 * secret positions, and `revision` the optimistic-concurrency token echoed
 * on every write.
 */
export interface SettingsDescriptorLike {
  ns: string
  schema: unknown
  value: Record<string, unknown>
  user: Record<string, unknown>
  revision: number
  applies: 'live' | 'restart'
  secrets: readonly RedactedSecretPosition[]
}

/** The slice of a field the write-op builder needs. */
export interface FieldWriteSpec {
  path: readonly string[]
  secret?: boolean
}

/**
 * Resolve a schemastery toJSON envelope `{ uid, refs }` into a node tree.
 * A node that is already a tree passes through unchanged; anything that is
 * no schema at all returns undefined. Lazy uid references are resolved
 * depth-first, and a reference that revisits a node already on the stack
 * (a cycle) is truncated to that node's header — type/meta survive, the
 * structural children do not.
 * @param envelope - a toJSON envelope, an already-rehydrated tree, or junk.
 * @returns the rehydrated root node, or undefined for non-schema shapes.
 */
export function rehydrateSchemaEnvelope(envelope: unknown): SchemaNodeLike | undefined {
  if (envelope === null || typeof envelope !== 'object') return undefined
  const obj = envelope as Record<string, unknown>
  if (typeof obj.uid === 'number') {
    const refs = obj.refs as Record<number, unknown> | undefined
    if (refs === undefined || typeof refs !== 'object' || !(obj.uid in refs)) return undefined
    return rehydrateNode(obj.uid, refs, [])
  }
  return typeof obj.type === 'string' ? (envelope as SchemaNodeLike) : undefined
}

/** Resolve one raw envelope member (a node or a numeric uid reference). */
function rehydrateNode(raw: unknown, refs: Record<number, unknown>, stack: readonly number[]): SchemaNodeLike | undefined {
  if (raw === null || raw === undefined) return undefined
  if (typeof raw === 'number') {
    if (!(raw in refs)) return undefined
    if (stack.includes(raw)) return truncateNode(refs[raw])
    return rehydrateNode(refs[raw], refs, [...stack, raw])
  }
  if (typeof raw !== 'object') return undefined
  const node = raw as Record<string, unknown>
  if (typeof node.type !== 'string') return undefined
  const result: SchemaNodeLike = { type: node.type, meta: node.meta as Record<string, unknown> }
  if (node.dict !== undefined && node.dict !== null && typeof node.dict === 'object') {
    const dict: Record<string, SchemaNodeLike> = {}
    for (const [key, child] of Object.entries(node.dict)) {
      const resolved = rehydrateNode(child, refs, stack)
      if (resolved !== undefined) dict[key] = resolved
    }
    result.dict = dict
  }
  if (Array.isArray(node.list)) {
    result.list = node.list
      .map(branch => rehydrateNode(branch, refs, stack))
      .filter((branch): branch is SchemaNodeLike => branch !== undefined)
  }
  if (node.inner !== undefined) {
    const inner = rehydrateNode(node.inner, refs, stack)
    if (inner !== undefined) result.inner = inner
  }
  if (node.sKey !== undefined) {
    const sKey = rehydrateNode(node.sKey, refs, stack)
    if (sKey !== undefined) result.sKey = sKey
  }
  if ('value' in node) result.value = node.value
  return result
}

/** Keep a revisited node's header (type/meta) and drop its structural children. */
function truncateNode(raw: unknown): SchemaNodeLike | undefined {
  if (raw === null || typeof raw !== 'object') return undefined
  const node = raw as Record<string, unknown>
  if (typeof node.type !== 'string') return undefined
  const result: SchemaNodeLike = { type: node.type, meta: node.meta as Record<string, unknown> }
  if ('value' in node) result.value = node.value
  return result
}

/**
 * Project an envelope into whitelist rendering decisions: string/number/
 * boolean map to their native controls, a const-only union maps to a
 * select, an object recurses as a group, and everything else falls back to
 * a raw JSON editor. A non-object root becomes one fallback field at the
 * root path; an unparseable envelope yields no fields.
 * @param envelope - schemastery toJSON envelope (or an already-rehydrated tree).
 * @returns the field descriptor list.
 */
export function renderFieldDescriptors(envelope: unknown): readonly FieldDescriptor[] {
  const root = rehydrateSchemaEnvelope(envelope)
  if (root === undefined) return []
  if (root.type !== 'object' || root.dict === undefined) {
    return [{ kind: 'field', key: 'value', path: [], label: fieldLabelOf('value'), control: 'json', secret: false, fallback: true }]
  }
  return Object.entries(root.dict).map(([key, node]) => renderNode(key, [key], node))
}

/** Recursively render one node into a descriptor. */
function renderNode(key: string, path: readonly string[], node: SchemaNodeLike): FieldDescriptor {
  const label = fieldLabelOf(key)
  const description = resolveDescription(node.meta['description'])
  if (node.type === 'object') {
    const children = node.dict === undefined
      ? []
      : Object.entries(node.dict).map(([childKey, child]) => renderNode(childKey, [...path, childKey], child))
    return { kind: 'group', key, path, label, children }
  }
  const secret = node.meta['role'] === 'secret'
  let control: LeafFieldDescriptor['control']
  let fallback = false
  let choices: LeafFieldDescriptor['choices']
  if (node.type === 'string') control = 'string'
  else if (node.type === 'number') control = 'number'
  else if (node.type === 'boolean') control = 'boolean'
  else if (node.type === 'union' && node.list !== undefined && node.list.length > 0 && node.list.every(branch => branch.type === 'const')) {
    control = 'select'
    choices = node.list
      .map(branch => branch.value)
      .filter((value): value is string | number | boolean =>
        typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean')
  } else {
    control = 'json'
    fallback = true
  }
  return {
    kind: 'field',
    key,
    path,
    label,
    control,
    secret,
    fallback,
    ...(description !== undefined ? { description } : {}),
    ...(choices !== undefined ? { choices } : {}),
  }
}

/** Resolve a description: plain string, or a {zh, en} dictionary preferring zh. */
function resolveDescription(raw: unknown): string | undefined {
  if (typeof raw === 'string') return raw
  if (raw !== null && typeof raw === 'object') {
    const dict = raw as Record<string, unknown>
    if (typeof dict['zh'] === 'string') return dict['zh']
    if (typeof dict['en'] === 'string') return dict['en']
  }
  return undefined
}

/**
 * Decide the write ops for one field edit under the secret placeholder
 * protocol. For secrets, the placeholder, an empty string, and "unchanged"
 * all produce NO op (so the wire never receives a marker or a blank), an
 * explicitly typed value produces exactly one set op, and a secret is never
 * unset through this path. Non-secret fields follow plain equal/clear/set
 * semantics, treating the placeholder as ordinary data.
 * @param field - the edited field (path, secret flag).
 * @param currentValue - the effective value before the edit (undefined if absent).
 * @param nextValue - the value the control produced (undefined when cleared).
 * @returns the ops to apply; empty when nothing changed.
 */
export function buildWriteOps(field: FieldWriteSpec, currentValue: unknown, nextValue: unknown): readonly SettingsPathOp[] {
  const path = field.path
  if (field.secret) {
    if (nextValue === undefined || nextValue === '' || nextValue === REDACTED_PLACEHOLDER) return []
    if (equalJson(currentValue, nextValue)) return []
    return [{ op: 'set', path, value: nextValue }]
  }
  if (equalJson(currentValue, nextValue)) return []
  if (nextValue === undefined) return [{ op: 'unset', path }]
  return [{ op: 'set', path, value: nextValue }]
}

/**
 * Build the reset op for one field: exactly one unset op carrying no value,
 * so paths the wire never returned (configured secrets) survive the reset.
 * @param path - root-relative field path.
 * @returns the single unset op.
 */
export function buildResetOp(path: readonly string[]): readonly SettingsPathOp[] {
  return [{ op: 'unset', path }]
}

/**
 * Recognize the host's stale-settings conflict: the wire error code
 * `SETTINGS_CONFLICT` or the `SettingsConflictError` class name.
 * @param error - anything a write path may have thrown or resolved with.
 * @returns true when the error signals a revision conflict.
 */
export function isConflictError(error: unknown): boolean {
  if (error === null || typeof error !== 'object') return false
  const candidate = error as { code?: unknown; name?: unknown }
  return candidate.code === 'SETTINGS_CONFLICT' || candidate.name === 'SettingsConflictError'
}

/**
 * Locate a redacted secret position by exact path.
 * @param secrets - the descriptor's secret markers, or undefined.
 * @param path - root-relative path to look up.
 * @returns the matching position, or undefined.
 */
export function secretAt(secrets: readonly RedactedSecretPosition[] | undefined, path: readonly string[]): RedactedSecretPosition | undefined {
  return secrets?.find(position => equalJson(position.path, path))
}

/**
 * Read a deep value along a root-relative path; `[]` is the value itself.
 * @param value - the object to read.
 * @param path - segments to descend; a missing segment yields undefined.
 * @returns the value at the path, or undefined.
 */
export function getPath(value: unknown, path: readonly string[]): unknown {
  let current = value
  for (const segment of path) {
    if (current === null || current === undefined || typeof current !== 'object') return undefined
    current = (current as Record<string, unknown>)[segment]
  }
  return current
}

/**
 * Whether a path is present in a value (a null leaf still counts as
 * present; a missing object or segment does not).
 * @param value - the object to inspect.
 * @param path - segments to descend.
 * @returns true when every segment exists.
 */
export function hasPath(value: unknown, path: readonly string[]): boolean {
  let current = value
  if (path.length === 0) return current !== undefined
  for (const segment of path) {
    if (current === null || current === undefined || typeof current !== 'object') return false
    if (!Object.prototype.hasOwnProperty.call(current, segment)) return false
    current = (current as Record<string, unknown>)[segment]
  }
  return true
}

/**
 * Structural equality for JSON-shaped data: distinguishes undefined from
 * null, compares arrays element-wise and objects by own keys.
 * @param left - first value.
 * @param right - second value.
 * @returns true when deeply equal.
 */
export function equalJson(left: unknown, right: unknown): boolean {
  if (left === right) return true
  if (left === null || right === null) return false
  if (typeof left !== 'object' || typeof right !== 'object') return false
  if (Array.isArray(left) !== Array.isArray(right)) return false
  if (Array.isArray(left)) {
    const rightArray = right as unknown[]
    if (left.length !== rightArray.length) return false
    return left.every((item, index) => equalJson(item, rightArray[index]))
  }
  const leftRecord = left as Record<string, unknown>
  const rightRecord = right as Record<string, unknown>
  const leftKeys = Object.keys(leftRecord)
  if (leftKeys.length !== Object.keys(rightRecord).length) return false
  return leftKeys.every(key =>
    Object.prototype.hasOwnProperty.call(rightRecord, key) && equalJson(leftRecord[key], rightRecord[key]))
}

/**
 * Humanize a field key: split camelCase and kebab/snake separators, keep
 * every word lowercase, capitalize only the first one.
 * @param key - raw schema key.
 * @returns the display label ('displayName' -> 'Display name').
 */
export function fieldLabelOf(key: string): string {
  const words = key
    .replace(new RegExp('([a-z\\d])([A-Z])', 'g'), '$1 $2')
    .replace(new RegExp('[-_.]+', 'g'), ' ')
    .trim()
    .split(new RegExp('\\s+'))
    .filter(word => word.length > 0)
    .map(word => word.toLowerCase())
  if (words.length === 0) return ''
  const first = words[0]!
  return first.charAt(0).toUpperCase() + first.slice(1) + words.slice(1).map(word => ` ${word}`).join('')
}

/**
 * Widen schemastery's `description()` method signature to accept localized
 * dictionaries: the runtime already stores any value on
 * `meta.description` (whose declared type is `string | Dict<string>`), so
 * `description({ zh, en })` works — only the published method signature
 * restricts callers to plain strings. The interface lives directly on the
 * global scope in schemastery's declarations (beside, not inside, the
 * `Schemastery` namespace), so the augmentation merges there.
 */
declare global {
  interface Schemastery<S, T> {
    description(text: string | Record<string, string>): Schemastery<S, T>
  }
}
