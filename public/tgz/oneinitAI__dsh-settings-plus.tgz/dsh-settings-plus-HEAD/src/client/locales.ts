/**
 * `dsh-settings-plus` locale namespace: the settings entry copy, the
 * temporary status-row copy, and the placeholder copy. Chinese is the
 * product copy; English mirrors it. The dictionary keys are the source of
 * truth and register against the harness locale service exactly once.
 */

/** Simplified Chinese dictionary (the key-set source of truth). */
export const zh = {
  'nav': '高级设置',
  'entry.desc': '以表单方式编辑 DSH 的全部插件与设置项，或以文件方式浏览、编辑配置文件。',
  'official.nav': '官方设置',
  'plugins.nav': '插件设置',
  'official.empty': '未配置官方文件设置项。可在 cordis.yml 的 officialFileEntries 中声明。',
  'plugins.empty': '暂无插件设置项。',
  'status.loading': '正在加载设置……',
  'status.loadFailed': '加载设置失败',
  'status.retry': '重试',
  'form.restartNotice': '部分设置将在重启后生效。',
  'form.invalidSchema': '该设置项的 schema 无法解析，暂不能以表单方式编辑。',
  'form.invalidJson': 'JSON 格式不正确，未提交。',
  'form.conflict': '设置已在别处被修改，请重新加载后重试。',
  'form.reload': '重新加载',
  'form.reset': '重置',
  'form.secretConfigured': '已配置（留空保持不变）',
  'form.secretEmpty': '尚未配置（输入新值以保存）',
} satisfies Record<string, string>

/** The `dsh-settings-plus` namespace key union. */
export type SettingsKey = keyof typeof zh

/** English dictionary, checked complete against the zh key set. */
export const en = {
  'nav': 'Advanced settings',
  'entry.desc': 'Edit every plugin and settings entry through forms, or browse and edit configuration files directly.',
  'official.nav': 'Official settings',
  'plugins.nav': 'Plugin settings',
  'official.empty': 'No official file settings declared. Declare them in cordis.yml under officialFileEntries.',
  'plugins.empty': 'No plugin settings yet.',
  'status.loading': 'Loading settings…',
  'status.loadFailed': 'Could not load settings',
  'status.retry': 'Retry',
  'form.restartNotice': 'Some settings take effect after a restart.',
  'form.invalidSchema': 'The schema for this entry cannot be parsed, so it cannot be edited as a form.',
  'form.invalidJson': 'Invalid JSON; nothing was submitted.',
  'form.conflict': 'Settings were changed elsewhere; reload and retry.',
  'form.reload': 'Reload',
  'form.reset': 'Reset',
  'form.secretConfigured': 'Configured (leave empty to keep)',
  'form.secretEmpty': 'Not configured (type a value to save)',
} satisfies Record<SettingsKey, string>

/** Locale namespace id registered under the harness locale service. */
export const NS = 'dsh-settings-plus'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    [NS]: SettingsKey
  }
}
