/**
 * Browser half of dsh-settings-plus: the settings.section registrations.
 *
 * Three always-present registrations: the entry ('dsh-settings-plus',
 * order 30 — strictly after general 0 / models 10 / agent-preset 20), the
 * official settings pane ('dsh-settings-plus-official', order 30) showing
 * the config-declared file-only official entries, and the plugin settings
 * pane ('dsh-settings-plus-plugins', order 31) showing strictly SDK-registered
 * third-party entries. Every registration uses declaration-aware deferral
 * (`ctx.slots.inject('settings.section', ...)`) and signature diffing; the
 * two panes are constant (fixed signatures), so they are registered once and
 * reused for the fiber's lifetime.
 *
 * The catalog reads through the injectable `settingsPlusCatalog` source seam
 * (see src/client/catalog.ts); the production default is the RPC source,
 * which fills both panes from the host's dshSettingsPlus service over the
 * connection transport's loopback channel (see src/rpc.ts). An injected
 * source still wins, so tests and future adapters never touch the wire.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type { LocaleService } from '@deepseek-ai/dsh-client-locale'
import type { SlotsService } from '@deepseek-ai/dsh-client-ui-slots'
import {
  SettingsPlusEntrySection, SettingsPlusOfficialSection, SettingsPlusPluginsSection,
  type SettingsPlusInjected,
} from './component.tsx'
import {
  createRpcCatalogSource, createRpcWriteBack, SettingsCatalogStore,
  type CatalogSource, type SettingsCatalogState,
} from './catalog.ts'
import { ensureSettingsPlusStyles } from './styles.ts'
import { en, NS, zh } from './locales.ts'

export type { SettingsPlusInjected } from './component.tsx'
export type {
  CatalogSource, CatalogLoadResult, SettingsCatalogState, SettingsSectionEntry, SettingsWriteBack,
} from './catalog.ts'

/**
 * Required services. `settings.section` is declaration-ordered independently,
 * so each dynamic contribution uses declaration-aware deferral. `remote` is
 * declared for the host-event invalidation a future wire surface may bring;
 * the catalog RPC source currently performs its own loads on
 * connection/reset.
 */
export const inject = ['slots', 'locale', 'connection', 'remote']

/**
 * Navigation order shared by the standing sections. 30 keeps them strictly
 * after the standing sections (general 0, models 10, agent-preset 20): a
 * lower value would tie with agent-preset's 20, and the stable sort would
 * then order the two by registration sequence — a race between the catalog
 * settling and that section's apply. The plugin pane sits one step later
 * (31), after the official pane.
 */
const OFFICIAL_SECTION_ORDER = 30
const PLUGINS_SECTION_ORDER = 31

/** Stable id of the always-present 设置管理 entry. */
const ENTRY_ID = 'dsh-settings-plus'

/** Stable id of the official settings pane. */
const OFFICIAL_PANE_ID = 'dsh-settings-plus-official'

/** Stable id of the plugin settings pane. */
const PLUGINS_PANE_ID = 'dsh-settings-plus-plugins'

type DesiredSection =
  | { kind: 'entry'; id: typeof ENTRY_ID; signature: string; labelKey: 'nav' }
  | { kind: 'official'; id: typeof OFFICIAL_PANE_ID; signature: string; labelKey: 'official.nav' }
  | { kind: 'plugins'; id: typeof PLUGINS_PANE_ID; signature: string; labelKey: 'plugins.nav' }

/**
 * Project the catalog snapshot into the fixed settings.section
 * registrations: the entry, the official pane, and the plugin pane. The
 * panes are constant — signatures never change — so the registrations are
 * created once and reused; their bodies read the live catalog per render.
 * @param _state - current catalog snapshot (panes render it internally).
 * @returns the desired section set, keyed by stable id.
 */
function desiredSections(_state: SettingsCatalogState): DesiredSection[] {
  return [
    { kind: 'entry', id: ENTRY_ID, signature: 'entry', labelKey: 'nav' },
    { kind: 'official', id: OFFICIAL_PANE_ID, signature: 'official', labelKey: 'official.nav' },
    { kind: 'plugins', id: PLUGINS_PANE_ID, signature: 'plugins', labelKey: 'plugins.nav' },
  ]
}

/**
 * Resolve the catalog source: the injectable seam wins, else the production
 * RPC source over the client connection transport.
 */
function resolveCatalogSource(ctx: ClientContext): CatalogSource {
  const injected = ctx.get('settingsPlusCatalog') as CatalogSource | undefined
  if (injected !== undefined) return injected
  return createRpcCatalogSource(ctx)
}

/**
 * Compose the settings surface: register the locale dictionaries, reconcile
 * the standing settings.section registrations against the catalog store, and
 * keep the catalog fresh on host invalidation.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  // The panes' stylesheet rides the --dsw-* design tokens; install it once
  // so every pane renders with the harness's design language.
  ensureSettingsPlusStyles()
  const slots = ctx.get('slots') as SlotsService
  const locale = ctx.get('locale') as LocaleService
  const source = resolveCatalogSource(ctx)
  const store = SettingsCatalogStore.create(source)
  const t = locale.bind(NS)
  const reload = (): Promise<void> => store.load()
  const writeBack = createRpcWriteBack(ctx)

  ctx.effect(() => locale.register(NS, { zh, en }), 'dsh-settings-plus: dictionaries')

  ctx.effect(() => {
    const live = new Map<string, { signature: string; dispose: () => void }>()
    const reconcile = (): void => {
      const desired = desiredSections(store.getSnapshot())
      const next = new Map<string, DesiredSection>(desired.map(section => [section.id, section]))
      for (const [id, current] of live) {
        if (next.get(id)?.signature === current.signature) continue
        current.dispose()
        live.delete(id)
      }
      for (const section of desired) {
        if (live.has(section.id)) continue
        const component = section.kind === 'entry'
          ? SettingsPlusEntrySection
          : section.kind === 'official'
            ? SettingsPlusOfficialSection
            : SettingsPlusPluginsSection
        const label = () => t(section.labelKey)
        const injected = (): SettingsPlusInjected => ({
          hooks: { catalog: store },
          reload,
          ...(writeBack !== undefined ? { writeBack } : {}),
        })
        const order = section.kind === 'plugins' ? PLUGINS_SECTION_ORDER : OFFICIAL_SECTION_ORDER
        const dispose = slots.inject('settings.section', () => slots.register({
          name: 'settings.section',
          id: section.id,
          order,
          label,
          locale: NS,
          inject: injected,
        }, component))
        live.set(section.id, { signature: section.signature, dispose })
      }
    }
    const unsubscribe = store.subscribe(reconcile)
    reconcile()
    return () => {
      unsubscribe()
      for (const section of live.values()) section.dispose()
      live.clear()
    }
  }, 'dsh-settings-plus: settings panes')

  // Reconnect may have rebuilt the host: reload the catalog with it.
  ctx.on('connection/reset', () => { void reload() })

  // The initial catalog load runs in the background: the panes render the
  // loading/empty/error states from the store, and a slow source must not
  // delay the browser tree's first paint (the web boot awaits every entry's
  // apply before rendering the shell).
  void reload()
}
