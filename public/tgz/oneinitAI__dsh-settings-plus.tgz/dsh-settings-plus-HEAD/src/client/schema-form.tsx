/**
 * The generic schema form renderer (T9): renders a `SettingsDescriptorLike`
 * as a form of whitelisted controls — string/number/boolean natively,
 * const-only unions as selects, nested objects as labeled groups, and
 * everything else as a raw JSON textarea fallback. Secrets render as empty
 * password inputs carrying only a placeholder hint (the wire never sends
 * plaintext), per-field reset appears for user-overridden or configured
 * paths, revision conflicts surface a reload prompt, and restart-applied
 * entries announce the restart notice.
 * @module @deepseek-ai/dsh-settings-plus/client/schema-form
 */
import { useState, type ReactNode } from 'react'
import {
  buildWriteOps,
  getPath,
  hasPath,
  isConflictError,
  rehydrateSchemaEnvelope,
  renderFieldDescriptors,
  secretAt,
  type FieldDescriptor,
  type LeafFieldDescriptor,
  type SettingsDescriptorLike,
} from './form-logic.ts'

/** One surfaced write failure: the message plus whether it is a conflict. */
interface Failure {
  message: string
  conflict: boolean
}

/** The form's channels: write/reset both carry the descriptor revision. */
export interface SettingsFormProps {
  descriptor: SettingsDescriptorLike
  /** Locale lookup (bound by the harness to the dsh-settings-plus namespace). */
  t: (key: string) => string
  /** Commit a changed value at a root-relative path. */
  writeValue: (path: readonly string[], value: unknown, revision: number) => Promise<void>
  /** Unset a user override at a root-relative path (never a value-bearing write). */
  resetField: (path: readonly string[], revision: number) => Promise<void>
  /** Reload the descriptor after a revision conflict. */
  reload: () => Promise<void>
}

/**
 * Render one entry's settings as a form.
 * @param props - the descriptor and its write/reset/reload channels.
 * @returns the form tree, or an invalid-schema alert when the envelope cannot parse.
 */
export function SettingsForm(props: SettingsFormProps): ReactNode {
  const { descriptor, t } = props
  const [failure, setFailure] = useState<Failure | null>(null)
  const [jsonErrors, setJsonErrors] = useState<Record<string, boolean>>({})

  const root = rehydrateSchemaEnvelope(descriptor.schema)
  if (root === undefined) {
    return (
      <div className="dsh_settingsPlus_form" role="alert">
        <p className="dsh_settingsPlus_error">{t('form.invalidSchema')}</p>
      </div>
    )
  }

  /**
   * Decide and apply the write ops for one field edit under the secret
   * placeholder protocol (form-logic decides; this component only routes).
   * A computed unset routes to the reset channel, a set to the write channel.
   */
  const commit = async (field: LeafFieldDescriptor, next: unknown): Promise<void> => {
    const ops = buildWriteOps(field, getPath(descriptor.value, field.path), next)
    const op = ops[0]
    if (op === undefined) return
    try {
      if (op.op === 'unset') await props.resetField(op.path, descriptor.revision)
      else await props.writeValue(op.path, op.value, descriptor.revision)
      setFailure(null)
    } catch (error) {
      setFailure({
        message: error instanceof Error ? error.message : String(error),
        conflict: isConflictError(error),
      })
    }
  }

  /** Unset a user override (or a configured secret) through the reset channel. */
  const reset = async (path: readonly string[]): Promise<void> => {
    try {
      await props.resetField(path, descriptor.revision)
      setFailure(null)
    } catch (error) {
      setFailure({
        message: error instanceof Error ? error.message : String(error),
        conflict: isConflictError(error),
      })
    }
  }

  /** Mark or clear a field's malformed-JSON flag. */
  const flagJsonError = (path: readonly string[], invalid: boolean): void => {
    const key = path.join('.')
    setJsonErrors(previous => {
      const next = { ...previous }
      if (invalid) next[key] = true
      else delete next[key]
      return next
    })
  }

  /** Reset visibility: user overrides, plus configured secrets (whose value never crossed the wire). */
  const showReset = (field: FieldDescriptor): boolean => {
    if (hasPath(descriptor.user, field.path)) return true
    return field.kind === 'field' && field.secret && secretAt(descriptor.secrets, field.path)?.set === true
  }

  /** Render one leaf control (uncontrolled; values are read at blur/change). */
  const renderControl = (field: LeafFieldDescriptor, current: unknown): ReactNode => {
    if (field.secret) {
      return (
        <input
          type="password"
          defaultValue=""
          placeholder={secretAt(descriptor.secrets, field.path)?.set ? t('form.secretConfigured') : t('form.secretEmpty')}
          onBlur={event => { void commit(field, event.currentTarget.value) }}
        />
      )
    }
    switch (field.control) {
      case 'string':
        return (
          <input
            type="text"
            defaultValue={current === undefined ? '' : String(current)}
            onBlur={event => { void commit(field, event.currentTarget.value) }}
          />
        )
      case 'number':
        return (
          <input
            type="number"
            defaultValue={current === undefined ? '' : String(current)}
            onBlur={event => {
              const text = event.currentTarget.value
              if (text.trim() === '') {
                void commit(field, undefined)
                return
              }
              const parsed = Number(text)
              if (Number.isFinite(parsed)) void commit(field, parsed)
            }}
          />
        )
      case 'boolean':
        return (
          <input
            type="checkbox"
            defaultChecked={current === true}
            onChange={event => { void commit(field, event.currentTarget.checked) }}
          />
        )
      case 'select':
        return (
          <select
            defaultValue={current === undefined ? String(field.choices?.[0] ?? '') : String(current)}
            onChange={event => { void commit(field, event.currentTarget.value) }}
          >
            {field.choices?.map(choice => (
              <option key={String(choice)} value={String(choice)}>{String(choice)}</option>
            ))}
          </select>
        )
      case 'json':
        return (
          <textarea
            defaultValue={current === undefined ? '' : JSON.stringify(current, null, 2)}
            onBlur={event => {
              const text = event.currentTarget.value
              if (text.trim() === '') {
                flagJsonError(field.path, false)
                void commit(field, undefined)
                return
              }
              try {
                const parsed = JSON.parse(text) as unknown
                flagJsonError(field.path, false)
                void commit(field, parsed)
              } catch {
                flagJsonError(field.path, true)
              }
            }}
          />
        )
    }
  }

  /** Recursively render one descriptor into its wrapper (leaf or group). */
  const renderField = (field: FieldDescriptor): ReactNode => {
    const pathKey = field.path.join('.')
    if (field.kind === 'group') {
      return (
        <fieldset className="dsh_settingsPlus_group" data-path={pathKey}>
          <legend>{field.label}</legend>
          {field.children.map(child => (
            <div key={child.key} className="dsh_settingsPlus_field_wrap">{renderField(child)}</div>
          ))}
          {showReset(field) && (
            <button type="button" className="dsh_settingsPlus_reset" onClick={() => { void reset(field.path) }}>
              {t('form.reset')}
            </button>
          )}
        </fieldset>
      )
    }
    const current = getPath(descriptor.value, field.path)
    return (
      <div className="dsh_settingsPlus_field" data-path={pathKey}>
        <label>{field.description ?? field.label}</label>
        {renderControl(field, current)}
        {showReset(field) && (
          <button type="button" className="dsh_settingsPlus_reset" onClick={() => { void reset(field.path) }}>
            {t('form.reset')}
          </button>
        )}
        {jsonErrors[pathKey] === true && (
          <p className="dsh_settingsPlus_error">{t('form.invalidJson')}</p>
        )}
      </div>
    )
  }

  const fields = renderFieldDescriptors(descriptor.schema)
  return (
    <div className="dsh_settingsPlus_form">
      {descriptor.applies === 'restart' && (
        <p className="dsh_settingsPlus_restart">{t('form.restartNotice')}</p>
      )}
      {fields.map(field => (
        <div key={field.path.join('.')} className="dsh_settingsPlus_field_wrap">{renderField(field)}</div>
      ))}
      {failure !== null && (
        <div className="dsh_settingsPlus_error" role="alert">
          <p>{failure.conflict ? t('form.conflict') : failure.message}</p>
          {failure.conflict && (
            <button type="button" className="dsh_settingsPlus_reload" onClick={() => { void props.reload() }}>
              {t('form.reload')}
            </button>
          )}
        </div>
      )}
    </div>
  )
}
