/**
 * settings.section components for the dsh-settings-plus browser half. The
 * entry describes the tool; the two pane sections render the two-pane
 * settings display — the official pane (config-declared file-only entries)
 * and the plugin pane (strictly SDK-registered third-party entries). Each
 * pane carries its own loading / empty / error state so a pane without data
 * never flashes empty. Descriptor-carrying entries render the generic
 * SettingsForm bound to the injected RPC write-back; bare entries stay
 * label-only rows.
 */
import type { ReactNode } from 'react'
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client'
import type { SettingsCatalogState, SettingsWriteBack } from './catalog.ts'
import { SettingsForm } from './schema-form.tsx'
import { NS, type SettingsKey } from './locales.ts'

/** Registration-side business face shared by every dynamic section. */
export interface SettingsPlusInjected {
  /** Catalog snapshot bound by the renderer as `useCatalog`. */
  hooks: { catalog: SnapshotStore<SettingsCatalogState> }
  /** Reload the catalog from its source. */
  reload: () => Promise<void>
  /** RPC write-back for the schema forms; undefined without an rpc face. */
  writeBack?: SettingsWriteBack
}

/** Full section props: runtime share + injected face + the locale seat. */
export type SettingsPlusSectionProps =
  PropsRuntime<'settings.section'> & InjectFace<SettingsPlusInjected> & PropsLocale<typeof NS>

/**
 * The 设置管理 entry: the always-present first-level section describing the
 * tool.
 * @param props - runtime share, injected face, and the locale seat.
 * @returns the entry element tree.
 */
export function SettingsPlusEntrySection({ t }: SettingsPlusSectionProps): ReactNode {
  return (
    <section className="dsh_settingsPlus_section">
      <h2 className="dsh_settingsPlus_title">{t('nav')}</h2>
      <p className="dsh_settingsPlus_desc">{t('entry.desc')}</p>
    </section>
  )
}

/** One of the two catalog panes a pane section projects from. */
export type SettingsPane = 'officialEntries' | 'pluginEntries'

/** Empty-state copy key for one pane. */
export type SettingsPaneEmptyKey = 'official.empty' | 'plugins.empty'

/** Options binding a pane section to one catalog pane. */
export interface SettingsPaneSectionOptions {
  /** The catalog state field this pane renders. */
  entriesKey: SettingsPane
  /** The empty-state copy key shown when the pane has no entries. */
  emptyKey: SettingsPaneEmptyKey
}

/**
 * One settings pane: the official pane or the plugin pane. Renders the
 * pane's entries as a list; while the catalog has no data it renders the
 * loading / empty / error states inline (the pane never flashes empty), with
 * a retry action on failure. Descriptor-carrying entries render the generic
 * SettingsForm bound to the injected write-back; bare entries stay
 * label-only rows.
 * @param options - which pane this section renders and its empty copy.
 * @returns a slot component bound to that pane.
 */
export function createSettingsPlusPaneSection(options: SettingsPaneSectionOptions) {
  return function SettingsPlusPaneSection({ t, useCatalog, reload, writeBack }: SettingsPlusSectionProps): ReactNode {
    const state = useCatalog(snapshot => snapshot)
    // Stale entries stay visible on failure: the pane only falls back to the
    // error copy when it has nothing to show.
    const entries = state[options.entriesKey]
    if (entries.length === 0) {
      if (state.status === 'error') {
        return (
          <div className="dsh_settingsPlus_section" role="alert">
            <p className="dsh_settingsPlus_error">{t('status.loadFailed')}: {state.error ?? ''}</p>
            <button type="button" className="dsh_settingsPlus_retry" onClick={() => { void reload() }}>
              {t('status.retry')}
            </button>
          </div>
        )
      }
      if (state.status === 'loading') {
        return (
          <div className="dsh_settingsPlus_section">
            <p className="dsh_settingsPlus_notice">{t('status.loading')}</p>
          </div>
        )
      }
      return (
        <div className="dsh_settingsPlus_section">
          <p className="dsh_settingsPlus_notice">{t(options.emptyKey)}</p>
        </div>
      )
    }
    // The form's locale seat takes any string key; the pane's seat is typed
    // to the namespace key set, so the two meet through a narrow cast.
    const formT = (key: string): string => t(key as SettingsKey)
    // A successful write/remove bumps the host's revision: refresh the catalog
    // right after so the form's next edit carries the new expectedRevision and
    // never trips SETTINGS_CONFLICT on its own write. The store keeps panes
    // stable across a refused reload, and entries keep their stable `key`, so
    // the refresh never flashes the pane or remounts the forms.
    const refreshAfter = async (op: () => Promise<void>): Promise<void> => {
      await op()
      await reload()
    }
    return (
      <section className="dsh_settingsPlus_section">
        <ul className="dsh_settingsPlus_pane">
          {entries.map(entry => {
            if (entry.descriptor !== undefined && writeBack !== undefined) {
              return (
                <li key={entry.key} className="dsh_settingsPlus_pane_item">
                  <h3 className="dsh_settingsPlus_pane_title">{entry.label}</h3>
                  <SettingsForm
                    descriptor={entry.descriptor}
                    t={formT}
                    writeValue={(path, value, revision) => refreshAfter(() => writeBack.writeValue(entry.key, path, value, revision))}
                    resetField={(path, revision) => refreshAfter(() => writeBack.resetField(entry.key, path, revision))}
                    reload={reload}
                  />
                </li>
              )
            }
            return (
              <li key={entry.key} className="dsh_settingsPlus_pane_item">
                <span className="dsh_settingsPlus_pane_key">{entry.key}</span>
                <span className="dsh_settingsPlus_pane_label">{entry.label}</span>
              </li>
            )
          })}
        </ul>
      </section>
    )
  }
}

/** The official pane section component (config-declared file-only entries). */
export const SettingsPlusOfficialSection: (props: SettingsPlusSectionProps) => ReactNode =
  createSettingsPlusPaneSection({ entriesKey: 'officialEntries', emptyKey: 'official.empty' })

/** The plugin pane section component (strictly SDK-registered entries). */
export const SettingsPlusPluginsSection: (props: SettingsPlusSectionProps) => ReactNode =
  createSettingsPlusPaneSection({ entriesKey: 'pluginEntries', emptyKey: 'plugins.empty' })
