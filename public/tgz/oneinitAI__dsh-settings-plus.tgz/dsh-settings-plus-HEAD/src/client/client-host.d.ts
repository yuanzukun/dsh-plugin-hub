/**
 * Local typecheck stubs for the host client packages this plugin's browser
 * half composes against (`@deepseek-ai/dsh-client-*` and
 * `@deepseek-ai/dsh-api-remotes`). None of these packages is installable
 * from the public registry, so the client declares its own minimal mirror of
 * the harness slot/locale/runtime faces instead of importing the real ones.
 * The declared faces cover exactly the members this package's client code
 * touches and mirror the harness contracts in the deepseek-harness checkout's
 * `packages/client/*`; when the real packages resolve (host integration),
 * this file is the single place to compare for drift.
 *
 * Script-mode ambient declarations: the file has no top-level imports or
 * exports, so every `declare module` block DEFINES a fresh ambient module (a
 * module file would turn them into augmentations of unresolvable modules).
 * Cross-module references ride inline `import('…')` types.
 */

declare module '@deepseek-ai/dsh-client-runtime/client' {
  /** The browser root context: the cordis Context the web boot hands entries. */
  export type ClientContext = import('cordis').Context

  /** Bare observable snapshot source (a `getSnapshot` + `subscribe` pair). */
  export interface SnapshotStore<T> {
    getSnapshot(): T
    subscribe(listener: () => void): () => void
  }
}

declare module '@deepseek-ai/dsh-client-ui-slots' {
  /** Slot contract table; owners merge entries in. Mirrored for 'settings.section' only. */
  export interface SlotMap {
    'settings.section': { kind: 'list'; scope: 'root'; owner: { close: () => void } }
  }

  /** Locale namespace table; dictionary owners merge keys in. */
  export interface LocaleNamespaceMap {}

  /** Framework standard kits; empty here (this plugin reads no global seats). */
  export interface GlobalStandardProps {}
  export interface SessionStandardProps {}
  export interface SessionMaybeStandardProps {}

  /** A list-entry display label: plain text or a per-read locale thunk. */
  export type SlotLabel = string | (() => string)

  /** Registration-position component shape: the bare call signature. */
  export type SlotComponent<P> = (props: P) => import('react').ReactNode

  /** Re-export of the runtime observable face for the hooks compartment. */
  export type SnapshotStore<T> = import('@deepseek-ai/dsh-client-runtime/client').SnapshotStore<T>

  /** Translate a dictionary key with optional template params. */
  export type Translate<K extends string = string> =
    (key: K, params?: Record<string, unknown>) => string

  /** Shared common vocabulary keys (empty without the locale plugin's merge). */
  export type CommonKeyOf = LocaleNamespaceMap extends { common: infer C } ? C & string : never

  /** Key domain of a namespace-bound translate: own keys plus the common vocabulary. */
  export type LocaleKeysOf<N extends keyof LocaleNamespaceMap & string> =
    (LocaleNamespaceMap[N] & string) | CommonKeyOf

  /** Namespace-addressed translate, the type of the framework-injected `t` seat. */
  export type TranslateNS<N extends keyof LocaleNamespaceMap & string> = Translate<LocaleKeysOf<N>>

  /** Locale share of composed props, present exactly on entries declaring `locale:`. */
  export type PropsLocale<N> = N extends keyof LocaleNamespaceMap & string
    ? { t: TranslateNS<N> }
    : object

  /** Selector hook over a bare observable snapshot. */
  export type SnapshotSelectorHook<T> =
    <S>(sel: (snapshot: T) => S, eq?: (left: S, right: S) => boolean) => S

  /** Registrant hooks compartment: bare observable sources under the reserved key. */
  export type HooksSources = Record<string, SnapshotStore<unknown>>

  /** Selector-hook share synthesized from a hooks compartment (`use<Name>`). */
  export type PropsHooks<HS extends HooksSources> = {
    [N in keyof HS & string as `use${Capitalize<N>}`]:
    SnapshotSelectorHook<HS[N] extends SnapshotStore<infer T> ? T : never>
  }

  /** Component-side view of an inject face: hooks bound, other members verbatim. */
  export type InjectFace<I extends object> =
    I extends { hooks: infer HS extends HooksSources } ? Omit<I, 'hooks'> & PropsHooks<HS> : I

  type OwnerOf<K extends keyof SlotMap & string> =
    SlotMap[K] extends { owner: infer O extends object } ? O : object

  type ScopeOf<K extends keyof SlotMap & string> = SlotMap[K]['scope']

  /** Runtime props share for a slot key: owner share plus the scope standard kits. */
  export type PropsRuntime<K extends keyof SlotMap & string> =
    OwnerOf<K>
    & (ScopeOf<K> extends 'session' ? SessionStandardProps
      : ScopeOf<K> extends 'session-maybe' ? SessionMaybeStandardProps
        : object)
    & GlobalStandardProps

  /** Register options this client uses (the list-kind shape). */
  export interface SectionRegisterOptions {
    name: keyof SlotMap & string
    id?: string
    order?: number
    label?: SlotLabel
    locale?: keyof LocaleNamespaceMap & string
    inject?: () => object
  }

  /** The slots service face the client consumes through `ctx.get('slots')`. */
  export interface SlotsService {
    /**
     * Install an effect per declaration lifetime of a slot: the callback runs
     * while the slot is declared and its returned disposer runs on collapse.
     */
    inject(key: keyof SlotMap & string, callback: () => (() => void) | Iterable<() => void>): () => void
    /** Contribute one entry; returns the idempotent disposer. */
    register(options: SectionRegisterOptions, component: SlotComponent<never>): () => void
  }
}

declare module '@deepseek-ai/dsh-client-locale' {
  /** The locale service face the client consumes through `ctx.get('locale')`. */
  export interface LocaleService {
    /** Register one namespace's dictionaries; returns the disposer. */
    register(ns: string, dicts: Record<string, Record<string, string>>): () => void
    /** Bind a translate function to a registered namespace. */
    bind(ns: string): import('@deepseek-ai/dsh-client-ui-slots').Translate
  }
}

declare module '@deepseek-ai/dsh-client-connection/client' {
  /**
   * The RpcResult envelope the transport's `rpc.call` answers with (the
   * harness's closed contract mirrored locally): `{ok:true,value}` or
   * `{ok:false,error:{code,message,details}}`, business failures folded into
   * the `internal` code.
   */
  export type RpcResultEnvelope<T = unknown> =
    | { ok: true; value: T }
    | { ok: false; error: { code: string; message: string; details: unknown } }

  /** The browser caller face for generic logical RPC channels. */
  export interface ConnectionRpcCaller {
    /**
     * Call one endpoint through an already registered logical channel;
     * correlation stays inside Connection.
     * @param channel - the absolute logical channel (e.g. '/dsh-settings-plus').
     * @param endpoint - the channel method (e.g. 'listNamespaces').
     * @param payload - channel-owned request payload.
     * @param signal - optional caller cancellation.
     */
    call(
      channel: string,
      endpoint: string,
      payload: unknown,
      signal?: AbortSignal,
    ): Promise<RpcResultEnvelope>
  }

  /**
   * Minimal connection handle face. The catalog RPC source (src/client/
   * catalog.ts) consumes the `rpc` member; `api` is the shared /api-channel
   * client this plugin does not touch.
   */
  export interface ConnectionHandle {
    api: unknown
    isLoopback?: boolean
    rpc?: ConnectionRpcCaller
  }
}

declare module '@deepseek-ai/dsh-client-ui-settings' {
  /**
   * The harness package that owns the settings SlotMap merges; no faces are
   * mirrored here because the 'settings.section' entry lives in the ui-slots
   * stub above. Declared so the peer set is honest about what the client may
   * later bind (settingsScope) without making it importable today.
   */
}

declare module '@deepseek-ai/dsh-api-remotes/client' {
  /**
   * Empty face: T8 declares the `remote` service (the harness forwards host
   * events through it) but performs no remote traffic. The catalog
   * invalidation over `remote.$on` arrives with the host wire surface.
   */
}
