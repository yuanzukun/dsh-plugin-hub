/**
 * The client half's stylesheet, injected as one `<style>` tag so the panes
 * render with the harness's design language. Every color below resolves
 * through the host's `--dsw-*` theme tokens (declared on `body` by
 * `@deepseek-ai/dsh-client-ui-theme/styles/design-platform.css`), so the
 * forms follow the active light/dark scheme automatically — no media queries,
 * no literal colors. Geometry mirrors the host's own settings controls
 * (`ui-settings-plugins` fields, `ui-settings-models` buttons/selects, and
 * the `ui-primitives` buttons): 8px radius inputs, 12px cards, 18px capsule
 * buttons, 6px field gaps, and 2px brand-primary focus rings.
 * @module @deepseek-ai/dsh-settings-plus/client/styles
 */

/** Marker attribute on the injected tag (mirrors the host's per-plugin data-dyn convention). */
export const STYLE_ATTR = 'data-dsh-settings-plus'

/** The stylesheet text: one class per pane element, all colors via --dsw-alias-* tokens. */
export const SETTINGS_PLUS_CSS = `
.dsh_settingsPlus_section {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.dsh_settingsPlus_title {
  margin: 0;
  font-size: 18px;
  line-height: 26px;
  font-weight: 600;
  color: var(--dsw-alias-label-primary);
}

.dsh_settingsPlus_desc {
  margin: 0;
  font-size: 13px;
  line-height: 20px;
  color: var(--dsw-alias-label-secondary);
}

.dsh_settingsPlus_pane {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.dsh_settingsPlus_pane_item {
  background: var(--dsw-alias-bg-layer-1);
  border: 1px solid var(--dsw-alias-border-l2);
  border-radius: 12px;
  padding: 16px;
}

.dsh_settingsPlus_pane_title {
  margin: 0 0 4px;
  font-size: 15px;
  line-height: 22px;
  font-weight: 600;
  color: var(--dsw-alias-label-primary);
}

.dsh_settingsPlus_pane_key {
  font-size: 12px;
  line-height: 18px;
  color: var(--dsw-alias-label-tertiary);
}

.dsh_settingsPlus_pane_label {
  font-size: 13px;
  line-height: 20px;
  color: var(--dsw-alias-label-secondary);
}

.dsh_settingsPlus_form {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

/* One field or group wrapper: rows are separated like the host's settings
   fields (border-top + 12px vertical rhythm). */
.dsh_settingsPlus_field_wrap + .dsh_settingsPlus_field_wrap {
  border-top: 1px solid var(--dsw-alias-border-l2);
  padding-top: 12px;
  margin-top: 12px;
}

.dsh_settingsPlus_field {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.dsh_settingsPlus_field > label {
  font-size: 13px;
  font-weight: 500;
  line-height: 1.5;
  color: var(--dsw-alias-label-primary);
}

.dsh_settingsPlus_group {
  border: 1px solid var(--dsw-alias-border-l2);
  border-radius: 8px;
  padding: 4px 12px 12px;
  margin: 0;
  min-width: 0;
}

.dsh_settingsPlus_group legend {
  font-size: 13px;
  font-weight: 500;
  line-height: 1.5;
  color: var(--dsw-alias-label-primary);
  padding: 0 4px;
}

.dsh_settingsPlus_form input[type="text"],
.dsh_settingsPlus_form input[type="password"],
.dsh_settingsPlus_form input[type="number"],
.dsh_settingsPlus_form select,
.dsh_settingsPlus_form textarea {
  width: 100%;
  box-sizing: border-box;
  height: 32px;
  padding: 0 10px;
  border: 1px solid var(--dsw-alias-border-l2);
  border-radius: 8px;
  background: var(--dsw-alias-bg-layer-3);
  font: inherit;
  font-size: 13px;
  line-height: 1.5;
  color: var(--dsw-alias-label-primary);
}

.dsh_settingsPlus_form input[type="text"]::placeholder,
.dsh_settingsPlus_form input[type="password"]::placeholder,
.dsh_settingsPlus_form input[type="number"]::placeholder,
.dsh_settingsPlus_form textarea::placeholder {
  color: var(--dsw-alias-label-dimmed);
}

.dsh_settingsPlus_form input[type="text"]:focus-visible,
.dsh_settingsPlus_form input[type="password"]:focus-visible,
.dsh_settingsPlus_form input[type="number"]:focus-visible,
.dsh_settingsPlus_form select:focus-visible,
.dsh_settingsPlus_form textarea:focus-visible {
  outline: none;
  border-color: var(--dsw-alias-brand-primary);
}

.dsh_settingsPlus_form input[type="text"]:disabled,
.dsh_settingsPlus_form input[type="password"]:disabled,
.dsh_settingsPlus_form input[type="number"]:disabled,
.dsh_settingsPlus_form select:disabled,
.dsh_settingsPlus_form textarea:disabled {
  color: var(--dsw-alias-label-tertiary);
  cursor: default;
}

.dsh_settingsPlus_form select {
  appearance: none;
  padding-right: 32px;
  cursor: pointer;
  /* Data-URI SVGs cannot resolve CSS variables; the chevron stroke is the
     caption gray (81858C) shared by both themes (same as the host's select). */
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12' fill='none'%3E%3Cpath d='M3 4.5L6 7.5L9 4.5' stroke='%2381858C' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'%2F%3E%3C%2Fsvg%3E");
  background-repeat: no-repeat;
  background-position: right 12px center;
  background-size: 12px 12px;
}

.dsh_settingsPlus_form textarea {
  height: auto;
  min-height: 96px;
  padding: 8px 10px;
  resize: vertical;
  font-family: var(--ds-font-family-code);
}

.dsh_settingsPlus_form input[type="checkbox"] {
  width: 16px;
  height: 16px;
  margin: 0;
  accent-color: var(--dsw-alias-button-primary-fill);
  cursor: pointer;
}

.dsh_settingsPlus_form input[type="checkbox"]:focus-visible {
  outline: 2px solid var(--dsw-alias-state-business-primary);
  outline-offset: 2px;
}

/* Text reset button (per-field override removal), like the host's .reset. */
.dsh_settingsPlus_reset {
  border: none;
  background: none;
  padding: 0;
  font: inherit;
  font-size: 12px;
  line-height: 1.5;
  color: var(--dsw-alias-label-secondary);
  cursor: pointer;
}

.dsh_settingsPlus_reset:hover:not(:disabled) {
  color: var(--dsw-alias-label-primary);
}

.dsh_settingsPlus_reset:focus-visible {
  outline: 2px solid var(--dsw-alias-brand-primary);
  outline-offset: 1px;
}

/* Secondary action buttons (retry / reload), like the host's .discard. */
.dsh_settingsPlus_reload,
.dsh_settingsPlus_retry {
  appearance: none;
  border: 1px solid var(--dsw-alias-border-l2);
  background: none;
  border-radius: 8px;
  padding: 5px 14px;
  font: inherit;
  font-size: 13px;
  line-height: 1.5;
  color: var(--dsw-alias-label-secondary);
  cursor: pointer;
}

.dsh_settingsPlus_reload:hover:not(:disabled),
.dsh_settingsPlus_retry:hover:not(:disabled) {
  background: var(--dsw-alias-interactive-bg-hover);
}

.dsh_settingsPlus_reload:focus-visible,
.dsh_settingsPlus_retry:focus-visible {
  outline: 2px solid var(--dsw-alias-brand-primary);
  outline-offset: 1px;
}

/* Error copy uses the host's defined state-error token (the label-error name
   referenced by host settings code is never defined; do not use it). */
.dsh_settingsPlus_error {
  margin: 0;
  font-size: 12px;
  line-height: 1.5;
  color: var(--dsw-alias-state-error-primary);
}

.dsh_settingsPlus_restart,
.dsh_settingsPlus_notice {
  margin: 0;
  font-size: 12px;
  line-height: 1.5;
  color: var(--dsw-alias-label-tertiary);
}
`

let injected = false

/**
 * Install the stylesheet once. Idempotent: the first call appends a single
 * `<style>` tag carrying {@link STYLE_ATTR}; later calls (e.g. re-applies in
 * tests or a fiber restart) are no-ops. Missing `document` (SSR) degrades to
 * a no-op so the client tree still mounts.
 */
export function ensureSettingsPlusStyles(): void {
  if (injected) return
  injected = true
  if (typeof document === 'undefined') return
  const tag = document.createElement('style')
  tag.setAttribute(STYLE_ATTR, '')
  tag.textContent = SETTINGS_PLUS_CSS
  document.head.append(tag)
}
