/**
 * Module-file augmentation of the plain cordis Events (an ambient
 * `declare module 'cordis'` in a script file would shadow the installed
 * package program-wide; a module file augments it instead). The client
 * runtime package merges the same keys onto the rescoped
 * `@deepseek-ai/cordis` in the harness; this mirror keeps the stubbed
 * ClientContext's `ctx.on` accepting the same event names during local
 * typechecking.
 */
import type {} from 'cordis'

declare module 'cordis' {
  interface Events {
    /**
     * A connection generation was (re-)established. Wire-derived caches must
     * treat their state as stale and repull.
     */
    'connection/reset'(): void
  }
}
