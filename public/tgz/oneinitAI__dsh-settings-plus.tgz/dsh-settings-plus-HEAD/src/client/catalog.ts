/**
 * Browser settings catalog: the observable snapshot the client's settings
 * panes project from, and the source seam every catalog reader plugs into.
 *
 * Two panes, two projection rules, mutually exclusive:
 * - **Plugin pane** (「插件设置页」): strictly SDK. Only entries whose
 *   `registeredBySdk` mark is true — third-party plugins that called the
 *   plugin SDK's `registerUserSettings`. Official DSH entries never appear
 *   here, no matter how they look.
 * - **Official pane** (「官方设置页」): strictly the user-declared
 *   `officialFileEntries` config list. Only entries that exist in the live
 *   namespaces/compositions AND are not SDK-marked appear here. A manifest id
 *   that happens to belong to an SDK-registered third-party entry stays on
 *   the plugin pane.
 *
 * Data path: the host publishes the dshSettingsPlus service over the
 * connection transport's generic RPC channel (see src/rpc.ts), and the
 * production source ({@link createRpcCatalogSource}) calls that channel
 * through the `rpc` face of the client connection handle. Tests and future
 * wire adapters keep the older seam: an injected `settingsPlusCatalog`
 * service overrides the production source, so no registration code changes
 * when the source is swapped.
 * @module @deepseek-ai/dsh-settings-plus/client/catalog
 */

import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type { CompositionConfigView, NamespaceDescriptor } from '../crawler.ts'
import type {
  RedactedSecretPosition,
  SettingsDescriptorLike,
} from './form-logic.ts'

/** The logical RPC channel; mirrors the host-side constant in src/rpc.ts. */
export const RPC_CHANNEL = '/dsh-settings-plus'

/** The channel's list method names (mirrors the host handler dispatch). */
const LIST_NAMESPACES = 'listNamespaces'
const LIST_COMPOSITION_CONFIGS = 'listCompositionConfigs'
const GET_OFFICIAL_FILE_ENTRIES = 'getOfficialFileEntries'
const UPDATE_NAMESPACE = 'updateNamespace'
const RESET_NAMESPACE_FIELD = 'resetNamespaceField'

/** This plugin's own id: never shown in the catalog, on either pane. */
export const SELF_PLUGIN_ID = 'dsh-settings-plus'

/** One catalog entry backing a settings pane row. */
export interface SettingsSectionEntry {
  /** Stable source key: the settings namespace id or composition row id. */
  key: string
  /** Display label resolved by the source. */
  label: string
  /**
   * The full renderable form descriptor, when this entry is backed by a
   * registered settings namespace. Composition-only rows (no namespace
   * descriptor) and degraded candidates carry no descriptor, so their rows
   * stay label-only.
   */
  descriptor?: SettingsDescriptorLike
}

/**
 * One candidate item before the two-pane projection: a namespace or
 * composition id carrying its SDK-registration provenance and, for namespaces,
 * the full descriptor the panes' forms render from. Entries without a mark
 * read as official DSH natives.
 */
export interface CatalogCandidate {
  /** The namespace id or composition row id. */
  key: string
  /** True when registered through the plugin SDK (`registerUserSettings`). */
  registeredBySdk?: boolean
  /** The full namespace descriptor, present only for namespace candidates. */
  descriptor?: NamespaceDescriptor
}

/** One full catalog load: both panes projected from the same candidates. */
export interface CatalogLoadResult {
  /** Entries for the plugin pane: strictly SDK-marked candidates. */
  pluginEntries: readonly SettingsSectionEntry[]
  /** Entries for the official pane: the declared list, minus SDK-marked ids. */
  officialEntries: readonly SettingsSectionEntry[]
}

/** Catalog lifecycle: loading until the first load settles, then ready/error. */
export type SettingsCatalogStatus = 'loading' | 'ready' | 'error'

/** Observable catalog snapshot, split per pane. */
export interface SettingsCatalogState {
  status: SettingsCatalogStatus
  /** The plugin pane's entries (strictly SDK-marked). */
  pluginEntries: readonly SettingsSectionEntry[]
  /** The official pane's entries (declared config list, minus SDK ids). */
  officialEntries: readonly SettingsSectionEntry[]
  /** Failure message of the latest refused load, while status is 'error'. */
  error?: string
}

/**
 * One catalog reader. `load` resolves with both panes' current entries; a
 * rejection means the catalog could not be read this round (the store keeps
 * the previous entries and marks the state as errored).
 */
export interface CatalogSource {
  load(): Promise<CatalogLoadResult>
}

/**
 * Observable catalog store: a bare `getSnapshot` + `subscribe` pair bound to
 * one source. A refused load keeps the last settled panes (stale data stays
 * visible and the panes never flash empty); a superseded load (a newer load
 * started meanwhile) commits nothing.
 */
export class SettingsCatalogStore {
  private state: SettingsCatalogState = {
    status: 'loading',
    pluginEntries: [],
    officialEntries: [],
  }
  private readonly listeners = new Set<() => void>()
  private generation = 0

  private constructor(private readonly source: CatalogSource) {}

  /** Create a store over a source (the source stays injectable for tests and wire adapters). */
  static create(source: CatalogSource): SettingsCatalogStore {
    return new SettingsCatalogStore(source)
  }

  /** Read the current snapshot (stable reference between changes). */
  getSnapshot(): SettingsCatalogState {
    return this.state
  }

  /** Subscribe to state changes. */
  subscribe(listener: () => void): () => void {
    this.listeners.add(listener)
    return () => { this.listeners.delete(listener) }
  }

  /**
   * Reload the catalog. Never rejects: failures settle the state as
   * `{ status: 'error', error }` with the previous panes preserved.
   */
  async load(): Promise<void> {
    const generation = ++this.generation
    try {
      const result = await this.source.load()
      if (generation !== this.generation) return
      this.setState({ status: 'ready', ...result })
    } catch (error) {
      if (generation !== this.generation) return
      this.setState({
        status: 'error',
        pluginEntries: this.state.pluginEntries,
        officialEntries: this.state.officialEntries,
        error: error instanceof Error ? error.message : String(error),
      })
    }
  }

  private setState(next: SettingsCatalogState): void {
    this.state = next
    for (const listener of [...this.listeners]) listener()
  }
}

/**
 * Resolve the RPC caller from a client context: the connection service probed
 * with `ctx.get`. A mounted connection without a callable `rpc.call` face
 * resolves to `undefined` — the source then degrades to the honest empty
 * catalog (same semantics as the local source), so client trees that run
 * against a host without the RPC transport still mount harmlessly.
 * @param ctx - client root context.
 * @returns the caller face, or `undefined` when the seam is absent or malformed.
 */
function resolveRpcCaller(ctx: ClientContext): NonNullable<ConnectionHandle['rpc']> | undefined {
  const connection = ctx.get('connection') as ConnectionHandle | undefined
  const rpc = connection?.rpc
  if (rpc === undefined || typeof rpc.call !== 'function') return undefined
  return rpc
}

/**
 * Decode a listNamespaces payload into catalog candidates: every item must be
 * a plain object carrying a non-empty string `ns`. Anything else is a drifted
 * host contract and refuses the whole load (the store settles as errored).
 * The full item is kept as the candidate's descriptor so the panes can render
 * editable forms from it.
 * @param value - the envelope's success value.
 * @returns the namespace candidates, keyed by namespace id, with their
 *   SDK-registration provenance and full descriptor when the host marked or
 *   described them.
 */
function parseNamespaceEntries(value: unknown): CatalogCandidate[] {
  if (!Array.isArray(value)) throw new Error('listNamespaces returned a non-array payload')
  const entries: CatalogCandidate[] = []
  for (const item of value) {
    if (!(typeof item === 'object' && item !== null)) {
      throw new Error('listNamespaces returned a non-object entry')
    }
    const descriptor = item as Partial<NamespaceDescriptor>
    const ns = descriptor.ns
    if (typeof ns !== 'string' || ns.length === 0) {
      throw new Error('listNamespaces returned an entry without a namespace id')
    }
    entries.push({
      key: ns,
      ...(descriptor.registeredBySdk === true ? { registeredBySdk: true } : {}),
      descriptor: item as NamespaceDescriptor,
    })
  }
  return entries
}

/**
 * Decode a listCompositionConfigs payload into catalog candidates: every
 * item must be a plain object carrying a non-empty string `id`. Anything
 * else is a drifted host contract and refuses the whole load. The ids feed
 * both panes' projections, so they are parsed into candidates with their
 * SDK-registration provenance.
 * @param value - the envelope's success value.
 * @returns the composition candidates, keyed by row id.
 */
function parseCompositionEntries(value: unknown): CatalogCandidate[] {
  if (!Array.isArray(value)) throw new Error('listCompositionConfigs returned a non-array payload')
  const entries: CatalogCandidate[] = []
  for (const item of value) {
    if (!(typeof item === 'object' && item !== null)) {
      throw new Error('listCompositionConfigs returned a non-object entry')
    }
    const view = item as Partial<CompositionConfigView>
    const id = view.id
    if (typeof id !== 'string' || id.length === 0) {
      throw new Error('listCompositionConfigs returned an entry without a composition id')
    }
    entries.push(view.registeredBySdk === true ? { key: id, registeredBySdk: true } : { key: id })
  }
  return entries
}

/**
 * Decode a getOfficialFileEntries payload into the declared id list: every
 * item must be a non-empty string. Anything else is a drifted host contract
 * and refuses the whole load.
 * @param value - the envelope's success value.
 * @returns the declared official settings entry ids.
 */
function parseOfficialFileEntries(value: unknown): string[] {
  if (!Array.isArray(value)) throw new Error('getOfficialFileEntries returned a non-array payload')
  const ids: string[] = []
  for (const item of value) {
    if (typeof item !== 'string' || item.length === 0) {
      throw new Error('getOfficialFileEntries returned a non-string entry')
    }
    ids.push(item)
  }
  return ids
}

/**
 * Whether a value is a plain data object (not null, not an array).
 * @param value - the value to test.
 * @returns true for plain records.
 */
function isPlainRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

/**
 * Whether a wire item looks like one redacted secret position: a plain object
 * with a string-array `path` and a boolean `set`. Anything else is dropped
 * from the renderable descriptor so the form never trips on drifted hosts.
 * @param value - one item of the descriptor's `secrets` list.
 * @returns true when the item carries the position shape.
 */
function isSecretPosition(value: unknown): value is RedactedSecretPosition {
  if (!isPlainRecord(value)) return false
  const candidate = value as { path?: unknown; set?: unknown }
  if (!Array.isArray(candidate.path)) return false
  if (!candidate.path.every(segment => typeof segment === 'string')) return false
  return typeof candidate.set === 'boolean'
}

/**
 * Project a full namespace descriptor into the renderable form descriptor the
 * schema form consumes. The wire's `user` and `secrets` members are optional;
 * the form requires plain records, so missing layers normalize to empty ones
 * and malformed secret markers are dropped.
 * @param descriptor - the full namespace descriptor from the host.
 * @returns the renderable descriptor for {@link SettingsForm}.
 */
function toRenderableDescriptor(descriptor: NamespaceDescriptor): SettingsDescriptorLike {
  return {
    ns: descriptor.ns,
    schema: descriptor.schema,
    value: isPlainRecord(descriptor.value) ? descriptor.value : {},
    user: isPlainRecord(descriptor.user) ? descriptor.user : {},
    revision: descriptor.revision,
    applies: descriptor.applies,
    secrets: Array.isArray(descriptor.secrets) ? descriptor.secrets.filter(isSecretPosition) : [],
  }
}

/**
 * Project a candidate into its pane entry, carrying the renderable form
 * descriptor when the candidate is namespace-backed.
 * @param candidate - the namespace or composition candidate.
 * @returns the pane entry.
 */
function candidateToEntry(candidate: CatalogCandidate): SettingsSectionEntry {
  const base: SettingsSectionEntry = { key: candidate.key, label: candidate.key }
  return candidate.descriptor === undefined
    ? base
    : { ...base, descriptor: toRenderableDescriptor(candidate.descriptor) }
}

/**
 * The plugin pane projection rule — **strict SDK**: only candidates marked
 * `registeredBySdk` are shown, whether they come from namespaces or
 * compositions. Official DSH entries (unmarked) never appear here, and this
 * plugin's own id is excluded even if it were marked. Keys deduplicate
 * across the two candidate lists; order is namespaces first (registration
 * order), then compositions (registry order).
 * @param namespaces - namespace candidates from listNamespaces.
 * @param compositions - composition candidates from listCompositionConfigs.
 * @returns the plugin pane's projected entries.
 */
export function projectPluginEntries(
  namespaces: readonly CatalogCandidate[],
  compositions: readonly CatalogCandidate[],
): SettingsSectionEntry[] {
  const entries: SettingsSectionEntry[] = []
  const seen = new Set<string>()
  const push = (candidate: CatalogCandidate): void => {
    if (candidate.key === SELF_PLUGIN_ID) return
    if (seen.has(candidate.key)) return
    seen.add(candidate.key)
    entries.push(candidateToEntry(candidate))
  }
  for (const namespace of namespaces) {
    if (namespace.registeredBySdk === true) push(namespace)
  }
  for (const composition of compositions) {
    if (composition.registeredBySdk === true) push(composition)
  }
  return entries
}

/**
 * The official pane projection rule — **declared list only**: every id in
 * `officialFileEntries` that resolves to a live namespace or composition
 * candidate. Entries whose candidate carries the SDK mark are refused (they
 * belong to the plugin pane — the two panes are mutually exclusive), and ids
 * absent from the live candidates are skipped (a declaration names a real
 * settings entry, nothing is invented). This plugin's own id never shows.
 * Order follows the user's declared list; keys deduplicate.
 * @param namespaces - namespace candidates from listNamespaces.
 * @param compositions - composition candidates from listCompositionConfigs.
 * @param officialFileEntries - ids declared by the user in cordis.yml.
 * @returns the official pane's projected entries.
 */
export function projectOfficialEntries(
  namespaces: readonly CatalogCandidate[],
  compositions: readonly CatalogCandidate[],
  officialFileEntries: readonly string[],
): SettingsSectionEntry[] {
  const byKey = new Map<string, CatalogCandidate>()
  for (const namespace of namespaces) {
    if (!byKey.has(namespace.key)) byKey.set(namespace.key, namespace)
  }
  for (const composition of compositions) {
    if (!byKey.has(composition.key)) byKey.set(composition.key, composition)
  }
  const entries: SettingsSectionEntry[] = []
  const seen = new Set<string>()
  for (const id of officialFileEntries) {
    if (id === SELF_PLUGIN_ID) continue
    if (seen.has(id)) continue
    const candidate = byKey.get(id)
    if (candidate === undefined) continue
    if (candidate.registeredBySdk === true) continue
    seen.add(id)
    entries.push(candidateToEntry(candidate))
  }
  return entries
}

/**
 * The production default source: reads the live host catalog over the
 * connection transport's RPC channel. Every load calls the three list
 * methods in parallel; any transport failure, refused envelope, or malformed
 * payload rejects the load (the store keeps the previous entries and marks
 * the state as errored). Entries are projected by the two-pane rules
 * ({@link projectPluginEntries} / {@link projectOfficialEntries}): the
 * plugin pane gets strictly SDK-marked entries, the official pane gets the
 * user-declared `officialFileEntries` minus SDK-marked ids. A context
 * without a callable `rpc.call` face degrades to the honest empty catalog
 * (same semantics as {@link createLocalCatalogSource}), so client trees
 * against a host without the RPC transport still mount harmlessly.
 * @param ctx - client root context with the connection service mounted.
 * @returns the RPC-backed catalog source, degrading to an empty catalog when
 *   the connection seam is absent or malformed.
 */
export function createRpcCatalogSource(ctx: ClientContext): CatalogSource {
  const rpc = resolveRpcCaller(ctx)
  if (rpc === undefined) return createLocalCatalogSource()
  return {
    async load() {
      const [namespaces, compositions, officialFileEntries] = await Promise.all([
        rpc.call(RPC_CHANNEL, LIST_NAMESPACES, null),
        rpc.call(RPC_CHANNEL, LIST_COMPOSITION_CONFIGS, null),
        rpc.call(RPC_CHANNEL, GET_OFFICIAL_FILE_ENTRIES, null),
      ])
      if (!namespaces.ok) throw new Error(namespaces.error.message)
      if (!compositions.ok) throw new Error(compositions.error.message)
      if (!officialFileEntries.ok) throw new Error(officialFileEntries.error.message)
      const ns = parseNamespaceEntries(namespaces.value)
      const comps = parseCompositionEntries(compositions.value)
      const declared = parseOfficialFileEntries(officialFileEntries.value)
      return {
        pluginEntries: projectPluginEntries(ns, comps),
        officialEntries: projectOfficialEntries(ns, comps, declared),
      }
    },
  }
}

/**
 * The honest local fallback source: resolves with both panes empty. Kept for
 * tests, embedders, and profiles whose harness lacks the RPC transport —
 * nothing here pretends to enumerate host namespaces.
 * @returns the local empty-catalog source.
 */
export function createLocalCatalogSource(): CatalogSource {
  return {
    async load() {
      return { pluginEntries: [], officialEntries: [] }
    },
  }
}

/** One leaf's RPC write channel: the client half of updateNamespace. */
export interface SettingsWriteBack {
  /**
   * Commit one field edit for a namespace: a nested patch built from the
   * root-relative path, with the descriptor revision as expectedRevision.
   * Rejects with the envelope's error (code preserved) on failure.
   */
  writeValue(ns: string, path: readonly string[], value: unknown, revision: number): Promise<void>
  /**
   * Unset one user override: a value-less nested patch at the path, carrying
   * the descriptor revision. The wire never sends a value for an unset.
   */
  resetField(ns: string, path: readonly string[], revision: number): Promise<void>
}

/**
 * Build the nested patch object for one root-relative path, e.g.
 * `['a', 'b']` with value `1` becomes `{ a: { b: 1 } }`; an empty path is an
 * empty patch (nothing to set).
 * @param path - root-relative segments.
 * @param value - the leaf value.
 * @returns the nested patch, or `{}` for an empty path.
 */
function nestedPatch(path: readonly string[], value: unknown): Record<string, unknown> {
  if (path.length === 0) return {}
  const [head, ...rest] = path
  const key = head!
  return { [key]: rest.length === 0 ? value : nestedPatch(rest, value) }
}

/**
 * Reject with the envelope's failure: a plain Error carrying the envelope
 * error code (so {@link isConflictError} still recognizes conflicts on the
 * wire). The message is the envelope's, safe to surface.
 * @param error - the envelope's error branch.
 */
function rejectEnvelope(error: { code: string; message: string }): never {
  const thrown = new Error(error.message) as Error & { code?: string }
  thrown.code = error.code
  throw thrown
}

/**
 * The production write-back: routes the schema form's write/reset channels to
 * the host over the connection transport's RPC channel, calling the
 * `updateNamespace` / `resetNamespaceField` endpoints (see src/rpc.ts). A
 * context without a callable `rpc.call` face resolves to `undefined` — the
 * panes then render descriptor-carrying entries as label-only rows, so client
 * trees against a host without the RPC transport still mount harmlessly.
 * @param ctx - client root context with the connection service mounted.
 * @returns the write-back face, or `undefined` when the seam is absent.
 */
export function createRpcWriteBack(ctx: ClientContext): SettingsWriteBack | undefined {
  const rpc = resolveRpcCaller(ctx)
  if (rpc === undefined) return undefined
  return {
    async writeValue(ns, path, value, revision) {
      const reply = await rpc.call(RPC_CHANNEL, UPDATE_NAMESPACE, {
        ns,
        patch: nestedPatch(path, value),
        expectedRevision: revision,
      })
      if (!reply.ok) rejectEnvelope(reply.error)
    },
    async resetField(ns, path, revision) {
      const reply = await rpc.call(RPC_CHANNEL, RESET_NAMESPACE_FIELD, {
        ns,
        path: [...path],
        expectedRevision: revision,
      })
      if (!reply.ok) rejectEnvelope(reply.error)
    },
  }
}
