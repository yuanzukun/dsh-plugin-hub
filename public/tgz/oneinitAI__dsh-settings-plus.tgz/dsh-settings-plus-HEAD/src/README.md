# Source Layout

The baseline source entries are:

- `src/index.ts`: Loader-facing plugin namespace and public exports;
- `src/config.ts`: serializable schema, resolved defaults, and configuration types;
- `src/runtime.ts`: fakeable host boundary and Cordis activation;
- `src/file-browser.ts`: closed configuration manifest enumeration and writable-target guard;
- `src/file-store.ts`: raw host-side file reads/writes with size and boundary guards;
- `src/yaml-editor.ts`: comment-preserving YAML/JSON document-level editing (`parseDocumentText`, `setPath`/`unsetPath`, `editYamlText`/`editJsonText`);
- `src/invariant.ts`: package-owned invariant companion;
- `src/client/`: browser half (served as `lib/client.js`):
  - `index.ts`: settings.section registrations — declaration-aware deferral, signature diffing, status row;
  - `catalog.ts`: observable catalog store and the injectable `settingsPlusCatalog` source seam;
  - `component.tsx`: entry / status-row / placeholder section components;
  - `locales.ts`: the `dsh-settings-plus` locale dictionaries;
  - `client-host.d.ts` / `client-events.d.ts`: local type stubs for the host client packages (the host packages are optional peers, never installed).

Keep the baseline files focused. As the plugin grows, use these project-root conventions:

- extend `src/config.ts` rather than hiding deployment choices in implementation constants;
- extend `src/runtime.ts` with fakeable process, clock, transport, or UI boundaries;
- add `src/<feature>/` for cohesive product capabilities such as commands, providers, renderers, or projections;
- add `src/services/` only when the package actually defines one or more Cordis services.

Create a directory only when production code needs it. Name feature directories after the capability they own rather than copying another plugin's product-specific names. Keep `src/index.ts` as the Loader boundary instead of turning it into an unstructured implementation file.
