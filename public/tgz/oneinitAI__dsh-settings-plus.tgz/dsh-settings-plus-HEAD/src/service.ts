/**
 * Host service surface: the `dshSettingsPlus` service this bundle publishes
 * on the host context. Reads delegate to the crawler's redacted snapshots;
 * writes route through the host `settings` seam.
 *
 * Write boundary, stated honestly: the crawler is read-only and there is no
 * channel to write composition documents back. `updateComposition` therefore
 * only accepts ids that are *registered settings namespaces* — the one
 * composition surface the host settings seam owns and can persist — and
 * rejects everything else loudly. A plain `cordis.yml` composition row (for
 * example `llm-main`) is not writable through this service: edit it with the
 * file editor surface or `cordis.patch.yml`.
 * @module @deepseek-ai/dsh-settings-plus/service
 */

import type { Context } from 'cordis'
import type { CompositionConfigView, NamespaceDescriptor, SettingsCrawler } from './crawler.ts'

/** Minimal write face of the host settings seam the service consumes. */
export interface SettingsWriterLike {
  /**
   * Persist a patch for one settings namespace.
   * @param ns - the registered namespace id.
   * @param patch - the value to write (merged over the current view by this service).
   * @param expectedRevision - the revision the patch was computed against, for
   *   the seam's optimistic concurrency checks.
   */
  update(ns: string, patch: unknown, expectedRevision?: number): void | Promise<void>
}

/** The settings surface the bundle exposes to the host as `ctx.dshSettingsPlus`. */
export interface DshSettingsPlusService {
  /** Every registered settings namespace, redacted. */
  listNamespaces(): NamespaceDescriptor[]
  /** Every mounted plugin's composition configuration, redacted. */
  listCompositionConfigs(): CompositionConfigView[]
  /**
   * Mark a namespace as registered through the plugin SDK
   * (`registerUserSettings`). The mark is a display-level provenance signal:
   * from the next list onward, entries whose id is marked carry
   * `registeredBySdk: true`, so the client can tell third-party SDK
   * registrants apart from official DSH namespaces.
   *
   * The mark outlives the registration itself (it is not unmarked when the
   * registration disposer runs): it only annotates live entries, and a
   * namespace that disappears no longer appears in any list.
   * @param ns - the SDK-registered namespace id.
   */
  markSdkRegistered(ns: string): void
  /**
   * Update one composition by id.
   *
   * Only ids that are registered settings namespaces are writable: the
   * current composition value is merged with `patch` and persisted through
   * the host settings seam's `update` path, carrying the namespace's
   * revision as `expectedRevision`. Any other id fails loudly:
   * - a plain `cordis.yml` composition row → error directing to the file
   *   editor surface or `cordis.patch.yml`;
   * - an unknown id → error.
   * @param id - composition id; for settings namespaces this equals `ns`.
   * @param patch - partial configuration to merge over the current value.
   */
  updateComposition(id: string, patch: object): Promise<void>
  /**
   * Reset one composition by id.
   *
   * For a settings namespace this is expressed through the seam's update
   * path with a `null` user section; the namespace itself stays registered
   * and is owned by its registrant. Plain `cordis.yml` rows and unknown ids
   * fail loudly exactly like {@link updateComposition}.
   * @param id - composition id.
   */
  removeComposition(id: string): Promise<void>
  /**
   * Update one settings namespace by id (the official-pane write channel).
   *
   * Semantically identical to {@link updateComposition} for registered
   * settings namespaces — the current composition value is deep-merged with
   * `patch` and persisted through the host settings seam — but it accepts the
   * client-observed `expectedRevision` and forwards it to the seam, so the
   * form's optimistic-concurrency checks survive the RPC round trip. Plain
   * `cordis.yml` rows and unknown ids fail loudly exactly like
   * {@link updateComposition}.
   * @param ns - the registered settings namespace id.
   * @param patch - partial configuration to deep-merge over the current value.
   * @param expectedRevision - the revision the client rendered the value at.
   */
  updateNamespace(ns: string, patch: object, expectedRevision?: number): Promise<void>
  /**
   * Reset one field of a settings namespace by id (the official-pane reset
   * channel): a value-less nested unset patch at the path, written through
   * the settings seam with the client-observed `expectedRevision`. Plain
   * `cordis.yml` rows and unknown ids fail loudly exactly like
   * {@link updateComposition}.
   * @param ns - the registered settings namespace id.
   * @param path - root-relative segments of the field to unset.
   * @param expectedRevision - the revision the client rendered the value at.
   */
  resetNamespaceField(ns: string, path: readonly string[], expectedRevision?: number): Promise<void>
}

declare module '@deepseek-ai/cordis' {
  interface Context {
    dshSettingsPlus: DshSettingsPlusService
  }
}

/** Factory options for {@link createDshSettingsPlusService}. */
export interface DshSettingsPlusServiceOptions {
  /** Injected settings writer for tests; defaults to the host `settings` seam. */
  writer?: SettingsWriterLike
}

/** Carrier shape of a context with the settings seam mounted. */
interface SettingsCarrier {
  settings?: unknown
}

/** Whether a value is a plain data object the merge may spread. */
function isPlainRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

/**
 * Deep-merge a patch over a base value: plain records merge recursively,
 * everything else (leaves, arrays, null) is replaced by the patch side. The
 * base is never mutated.
 * @param base - the value the patch merges over.
 * @param patch - the value to merge in.
 * @returns the merged value.
 */
function deepMerge(base: unknown, patch: unknown): unknown {
  if (!isPlainRecord(base) || !isPlainRecord(patch)) return patch
  const merged: Record<string, unknown> = { ...base }
  for (const [key, value] of Object.entries(patch)) {
    merged[key] = deepMerge(base[key], value)
  }
  return merged
}

/**
 * Build the value-less nested unset patch for one root-relative path, e.g.
 * `['a', 'b']` becomes `{ a: { b: undefined } }` — the wire never sends a
 * value for an unset. An empty path resolves to an empty patch.
 * @param path - root-relative segments.
 * @returns the nested patch with undefined leaves.
 */
function unsetPatchOf(path: readonly string[]): Record<string, unknown> {
  if (path.length === 0) return {}
  const [head, ...rest] = path
  const key = head!
  return { [key]: rest.length === 0 ? undefined : unsetPatchOf(rest) }
}

/** The loud error for ids that are plain cordis.yml rows, not settings namespaces. */
function compositionRowError(id: string): Error {
  return new Error(
    `composition "${id}" is a plain cordis.yml row and is not writable through this service: edit it with the file editor surface or cordis.patch.yml`,
  )
}

/**
 * Resolve the settings writer: the injected override wins, otherwise the
 * host context's `settings` service. A mounted seam without an `update`
 * method is a drifted host contract and must fail loud.
 * @param ctx - host context with the settings seam mounted.
 * @param injected - test override.
 * @returns the writer face.
 * @throws {Error} when the seam is missing or malformed.
 */
function resolveWriter(ctx: Context, injected?: SettingsWriterLike): SettingsWriterLike {
  const candidate = injected ?? (ctx as unknown as SettingsCarrier).settings
  if (candidate === undefined || typeof (candidate as SettingsWriterLike).update !== 'function') {
    throw new Error('dshSettingsPlus service requires the "settings" service to expose an update method')
  }
  return candidate as SettingsWriterLike
}

/**
 * Annotate descriptors with `registeredBySdk: true` when their id is marked
 * through {@link DshSettingsPlusService.markSdkRegistered}. Unmarked
 * descriptors pass through by reference — the host's objects are never
 * mutated, and no field is added for entries without a mark.
 * @param descriptors - raw crawler descriptors.
 * @param marked - the service's SDK-registered id set.
 * @returns the annotated descriptors.
 */
function annotateNamespaces(descriptors: NamespaceDescriptor[], marked: ReadonlySet<string>): NamespaceDescriptor[] {
  return descriptors.map(descriptor =>
    marked.has(descriptor.ns) ? { ...descriptor, registeredBySdk: true } : descriptor,
  )
}

/** Annotate composition views with `registeredBySdk: true` when their id is marked. */
function annotateCompositions(views: CompositionConfigView[], marked: ReadonlySet<string>): CompositionConfigView[] {
  return views.map(view => (marked.has(view.id) ? { ...view, registeredBySdk: true } : view))
}

/**
 * Create the host settings service for a context.
 * @param ctx - host context with the settings seam mounted.
 * @param crawler - the live read-only crawler feeding both list surfaces.
 * @param options - optional injected writer override.
 * @returns the service face; reads resolve at call time.
 */
export function createDshSettingsPlusService(
  ctx: Context,
  crawler: SettingsCrawler,
  options: DshSettingsPlusServiceOptions = {},
): DshSettingsPlusService {
  const writer = resolveWriter(ctx, options.writer)
  const sdkRegistered = new Set<string>()
  return {
    listNamespaces: () => annotateNamespaces(crawler.listNamespaces(), sdkRegistered),
    listCompositionConfigs: () => annotateCompositions(crawler.listCompositionConfigs(), sdkRegistered),
    markSdkRegistered: ns => { sdkRegistered.add(ns) },

    async updateComposition(id, patch) {
      const descriptor = crawler.listNamespaces().find(candidate => candidate.ns === id)
      if (descriptor !== undefined) {
        const view = crawler.listCompositionConfigs().find(candidate => candidate.id === id)
        const merged = view !== undefined && isPlainRecord(view.value)
          ? { ...view.value, ...patch }
          : { ...patch }
        await writer.update(id, merged, descriptor.revision)
        return
      }
      if (crawler.listCompositionConfigs().some(candidate => candidate.id === id)) {
        throw compositionRowError(id)
      }
      throw new Error(`unknown composition id "${id}"`)
    },

    async removeComposition(id) {
      const descriptor = crawler.listNamespaces().find(candidate => candidate.ns === id)
      if (descriptor !== undefined) {
        await writer.update(id, null, descriptor.revision)
        return
      }
      if (crawler.listCompositionConfigs().some(candidate => candidate.id === id)) {
        throw compositionRowError(id)
      }
      throw new Error(`unknown composition id "${id}"`)
    },

    async updateNamespace(ns, patch, expectedRevision) {
      const descriptor = crawler.listNamespaces().find(candidate => candidate.ns === ns)
      if (descriptor !== undefined) {
        const view = crawler.listCompositionConfigs().find(candidate => candidate.id === ns)
        const merged = view !== undefined && isPlainRecord(view.value)
          ? deepMerge(view.value, patch)
          : patch
        await writer.update(ns, merged, expectedRevision ?? descriptor.revision)
        return
      }
      if (crawler.listCompositionConfigs().some(candidate => candidate.id === ns)) {
        throw compositionRowError(ns)
      }
      throw new Error(`unknown composition id "${ns}"`)
    },

    async resetNamespaceField(ns, path, expectedRevision) {
      const descriptor = crawler.listNamespaces().find(candidate => candidate.ns === ns)
      if (descriptor !== undefined) {
        await writer.update(ns, unsetPatchOf(path), expectedRevision ?? descriptor.revision)
        return
      }
      if (crawler.listCompositionConfigs().some(candidate => candidate.id === ns)) {
        throw compositionRowError(ns)
      }
      throw new Error(`unknown composition id "${ns}"`)
    },
  }
}
