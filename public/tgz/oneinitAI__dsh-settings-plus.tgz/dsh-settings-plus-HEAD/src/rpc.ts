/**
 * L2 same-origin browser RPC channel for the settings catalog.
 *
 * The host publishes the `dshSettingsPlus` service surface (see service.ts)
 * to the browser half over the connection transport's generic RPC channel
 * registry: the browser calls the channel with
 * `ctx.connection.rpc.call(channel, method, payload)` (the `rpc` face of the
 * client connection handle, @deepseek-ai/dsh-client-connection), and the host
 * dispatches against the handler registered here. The four methods mirror the
 * service face one-to-one — listNamespaces / listCompositionConfigs are reads
 * served straight from the crawler, updateComposition / removeComposition
 * carry the same loud write boundary as the service.
 *
 * Envelope contract (the harness RpcResult, mirrored locally): every call
 * answers `{ ok: true, value }` or `{ ok: false, error: { code, message,
 * details } }`, the error-code set is the harness's closed union, and
 * business failures fold into `internal` exactly like the transport's own
 * transportError helper. Unknown methods and malformed payloads answer
 * `bad-request`. The handler never throws: an unhandled exception would
 * surface as a transport-level HTTP 500 instead of an envelope.
 *
 * Dependency posture: the connection transport is consumed through a minimal
 * local contract, never an import of the host package. Registration probes
 * the optional `connection` service with `ctx.get` — a context without it
 * (headless host runs, older harness profiles) safely skips the channel;
 * a mounted but malformed seam is a drifted host contract and fails loud.
 * The channel registration is owned by the caller fiber through
 * `ctx.effect`, so it disappears exactly when this bundle unloads.
 * @module @deepseek-ai/dsh-settings-plus/rpc
 */

import type { Context } from 'cordis'
import type { DshSettingsPlusService } from './service.ts'

/** The logical RPC channel the browser half calls through. */
export const RPC_CHANNEL = '/dsh-settings-plus'

/** The channel's method names: the service face, one method per endpoint. */
export type SettingsPlusRpcMethod =
  | 'listNamespaces'
  | 'listCompositionConfigs'
  | 'getOfficialFileEntries'
  | 'updateComposition'
  | 'removeComposition'
  | 'updateNamespace'
  | 'resetNamespaceField'

/** One error branch of the envelope (harness RpcError mirrored locally). */
export interface RpcErrorEnvelope {
  /** Member of the harness's closed error-code union. */
  code: string
  /** Human-readable failure text, safe to surface. */
  message: string
  /** Code-specific details; `{}` for the internal catch-all. */
  details: unknown
}

/** The RpcResult envelope the transport carries (harness contract mirrored). */
export type RpcResultEnvelope<T> =
  | { ok: true; value: T }
  | { ok: false; error: RpcErrorEnvelope }

/** Handler face the transport invokes after decoding the request envelope. */
export type SettingsPlusRpcHandler = (
  endpoint: string,
  payload: unknown,
  signal: AbortSignal,
) => Promise<RpcResultEnvelope<unknown>>

/** Minimal registry face of the host connection service's `rpc` member. */
export interface ConnectionRpcRegistryLike {
  /**
   * Register one channel prefix under the caller's fiber.
   * @param channel - the logical channel this handler answers.
   * @param handler - decoded endpoint handler returning the envelope shape.
   * @param options - channel trust policy (loopback keeps the browser-only fence).
   * @returns disposer removing the channel and its physical route.
   */
  handle(
    channel: string,
    handler: SettingsPlusRpcHandler,
    options: { authority: 'loopback' | 'trusted-host' },
  ): () => void | Promise<void>
}

/** Carrier shape of a host context with the connection service mounted. */
export interface ConnectionCarrierLike {
  rpc?: ConnectionRpcRegistryLike
}

/** Options for {@link registerSettingsPlusRpc}. */
export interface SettingsPlusRpcOptions {
  /**
   * The service face this channel dispatches against. Required: the caller
   * already holds the instance (a same-apply `ctx.get` cannot see a service
   * this fiber provided), so it is passed in rather than re-resolved.
   */
  service?: DshSettingsPlusService
  /**
   * The official settings entries declared by the user in cordis.yml
   * (`officialFileEntries`). Served verbatim by the `getOfficialFileEntries`
   * endpoint so the browser half can project the official pane; defaults to
   * `[]` when the caller does not pass the resolved config.
   */
  officialFileEntries?: readonly string[]
  /**
   * Injected connection service for tests; defaults to the host context's
   * `connection` service (read with `ctx.get`, so an absent seam skips).
   */
  connection?: ConnectionCarrierLike
}

/** One decoded update request: the service's two arguments in a payload. */
interface UpdateCompositionRequest {
  id: string
  patch: Record<string, unknown>
}

/** Whether a value is a plain data object (not null, not an array). */
function isPlainRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

/** Fold any thrown value into the internal error branch of the envelope. */
function foldInternal(error: unknown): RpcResultEnvelope<never> {
  // The host's stale-settings conflict survives the envelope as its own code:
  // the browser half's conflict detection keys on SETTINGS_CONFLICT (see
  // form-logic's isConflictError), so folding it into internal would silently
  // turn a conflict into a plain failure. Everything else folds to internal.
  const thrown = error as { code?: unknown }
  return {
    ok: false,
    error: {
      code: thrown.code === 'SETTINGS_CONFLICT' ? 'SETTINGS_CONFLICT' : 'internal',
      message: error instanceof Error ? error.message : String(error),
      details: { issues: [] },
    },
  }
}

/** The bad-request branch: malformed method or payload, never a business failure. */
function badRequest(message: string): RpcResultEnvelope<never> {
  return { ok: false, error: { code: 'bad-request', message, details: { issues: [] } } }
}

/**
 * Decode an updateComposition payload: an object carrying a non-empty string
 * `id` and a plain-record `patch` (the service merges the patch, so any
 * other shape is refused here, before the service boundary).
 * @param payload - the decoded request payload.
 * @returns the decoded request, or undefined when malformed.
 */
function parseUpdateRequest(payload: unknown): UpdateCompositionRequest | undefined {
  if (!isPlainRecord(payload)) return undefined
  const id = payload['id']
  const patch = payload['patch']
  if (typeof id !== 'string' || id.length === 0) return undefined
  if (!isPlainRecord(patch)) return undefined
  return { id, patch }
}

/**
 * Decode a removeComposition payload: an object carrying a non-empty string
 * `id`.
 * @param payload - the decoded request payload.
 * @returns the composition id, or undefined when malformed.
 */
function parseRemoveRequest(payload: unknown): string | undefined {
  if (!isPlainRecord(payload)) return undefined
  const id = payload['id']
  if (typeof id !== 'string' || id.length === 0) return undefined
  return id
}

/** One decoded updateNamespace request: ns, patch and the optional revision. */
interface UpdateNamespaceRequest {
  ns: string
  patch: Record<string, unknown>
  expectedRevision?: number
}

/**
 * Decode an updateNamespace payload: an object carrying a non-empty string
 * `ns`, a plain-record `patch`, and an optional numeric `expectedRevision`.
 * @param payload - the decoded request payload.
 * @returns the decoded request, or undefined when malformed.
 */
function parseUpdateNamespaceRequest(payload: unknown): UpdateNamespaceRequest | undefined {
  if (!isPlainRecord(payload)) return undefined
  const ns = payload['ns']
  const patch = payload['patch']
  const expectedRevision = payload['expectedRevision']
  if (typeof ns !== 'string' || ns.length === 0) return undefined
  if (!isPlainRecord(patch)) return undefined
  if (expectedRevision !== undefined && typeof expectedRevision !== 'number') return undefined
  return expectedRevision === undefined
    ? { ns, patch }
    : { ns, patch, expectedRevision }
}

/** One decoded resetNamespaceField request: ns, path and the optional revision. */
interface ResetNamespaceFieldRequest {
  ns: string
  path: string[]
  expectedRevision?: number
}

/**
 * Decode a resetNamespaceField payload: an object carrying a non-empty string
 * `ns`, a string-array `path`, and an optional numeric `expectedRevision`.
 * @param payload - the decoded request payload.
 * @returns the decoded request, or undefined when malformed.
 */
function parseResetNamespaceFieldRequest(payload: unknown): ResetNamespaceFieldRequest | undefined {
  if (!isPlainRecord(payload)) return undefined
  const ns = payload['ns']
  const path = payload['path']
  const expectedRevision = payload['expectedRevision']
  if (typeof ns !== 'string' || ns.length === 0) return undefined
  if (!Array.isArray(path) || !path.every(segment => typeof segment === 'string')) return undefined
  if (expectedRevision !== undefined && typeof expectedRevision !== 'number') return undefined
  return expectedRevision === undefined
    ? { ns, path }
    : { ns, path, expectedRevision }
}

/**
 * Create the channel handler over one service face. Endpoint names equal the
 * service method names; every outcome is an envelope (never a throw), with
 * business failures folded into `internal` and malformed calls answered
 * `bad-request`. `getOfficialFileEntries` serves the host-side
 * `officialFileEntries` config verbatim (a fresh array copy per call), so the
 * browser half can project the official pane without a dedicated method on
 * the service.
 * @param service - the service face this channel dispatches against.
 * @param officialFileEntries - the user-declared official settings entries.
 * @returns the transport handler.
 */
export function createSettingsPlusRpcHandler(
  service: DshSettingsPlusService,
  officialFileEntries: readonly string[] = [],
): SettingsPlusRpcHandler {
  return async (endpoint, payload) => {
    try {
      switch (endpoint) {
        case 'listNamespaces':
          return { ok: true, value: service.listNamespaces() }
        case 'listCompositionConfigs':
          return { ok: true, value: service.listCompositionConfigs() }
        case 'getOfficialFileEntries':
          return { ok: true, value: [...officialFileEntries] }
        case 'updateComposition': {
          const request = parseUpdateRequest(payload)
          if (request === undefined) {
            return badRequest('updateComposition requires an object payload with a string id and an object patch')
          }
          await service.updateComposition(request.id, request.patch)
          return { ok: true, value: undefined }
        }
        case 'removeComposition': {
          const id = parseRemoveRequest(payload)
          if (id === undefined) {
            return badRequest('removeComposition requires an object payload with a string id')
          }
          await service.removeComposition(id)
          return { ok: true, value: undefined }
        }
        case 'updateNamespace': {
          const request = parseUpdateNamespaceRequest(payload)
          if (request === undefined) {
            return badRequest('updateNamespace requires an object payload with a string ns, an object patch, and an optional numeric expectedRevision')
          }
          await service.updateNamespace(request.ns, request.patch, request.expectedRevision)
          return { ok: true, value: undefined }
        }
        case 'resetNamespaceField': {
          const request = parseResetNamespaceFieldRequest(payload)
          if (request === undefined) {
            return badRequest('resetNamespaceField requires an object payload with a string ns, a string-array path, and an optional numeric expectedRevision')
          }
          await service.resetNamespaceField(request.ns, request.path, request.expectedRevision)
          return { ok: true, value: undefined }
        }
        default:
          return badRequest(`unknown dsh-settings-plus rpc method ${JSON.stringify(endpoint)}`)
      }
    } catch (error) {
      return foldInternal(error)
    }
  }
}

/**
 * Resolve the connection registry: the injected override wins, otherwise the
 * host context's `connection` service probed with `ctx.get` (never property
 * access — Cordis rc.7 contexts are Proxies that throw on reads of
 * unprovided services). An absent seam is the safe-skip signal; a mounted
 * seam without a callable `rpc.handle` is a drifted host contract and fails
 * loud.
 * @param ctx - host context.
 * @param injected - test override.
 * @returns the registry, or undefined when no connection service is mounted.
 */
function resolveConnection(ctx: Context, injected?: ConnectionCarrierLike): ConnectionRpcRegistryLike | undefined {
  const candidate = injected ?? (ctx.get('connection') as ConnectionCarrierLike | undefined)
  if (candidate === undefined) return undefined
  const rpc = candidate.rpc
  if (rpc === undefined || typeof rpc.handle !== 'function') {
    throw new Error('dsh-settings-plus rpc channel requires a connection service exposing rpc.handle')
  }
  return rpc
}

/**
 * Resolve the service face the channel dispatches against. The service is the
 * channel's reason to exist and the caller already holds its instance, so it
 * is passed in rather than re-resolved from the context: a same-apply
 * `ctx.provide` is not visible to a later `ctx.get` on the same execution
 * stack in Cordis rc.7, so re-reading the context here would race the
 * provider. An unresolvable face fails loud rather than registering a channel
 * that answers nothing.
 * @param service - the service face this channel dispatches against.
 * @returns the service face.
 * @throws {Error} when the face is missing.
 */
function resolveService(service: DshSettingsPlusService | undefined): DshSettingsPlusService {
  if (service === undefined) {
    throw new Error('dsh-settings-plus rpc channel requires the dshSettingsPlus service')
  }
  return service
}

/**
 * Register the browser RPC channel for the settings catalog.
 *
 * The registration is owned by the caller fiber through `ctx.effect`, so the
 * channel and its physical route disappear exactly when this bundle unloads.
 * A context without the optional `connection` service safely skips the
 * channel (the browser half then shows its error status row until a harness
 * with the transport mounts).
 * @param ctx - host context with the connection service (optional) and the
 *   provided `dshSettingsPlus` service.
 * @param options - service / connection overrides for tests.
 * @returns whether the channel was registered.
 */
export function registerSettingsPlusRpc(ctx: Context, options: SettingsPlusRpcOptions = {}): boolean {
  const connection = resolveConnection(ctx, options.connection)
  if (connection === undefined) return false
  const service = resolveService(options.service)
  const handler = createSettingsPlusRpcHandler(service, options.officialFileEntries ?? [])
  ctx.effect(
    () => connection.handle(RPC_CHANNEL, handler, { authority: 'loopback' }),
    'dsh-settings-plus: browser rpc channel',
  )
  return true
}
