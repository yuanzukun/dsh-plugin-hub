// @vitest-environment jsdom
/** SettingsForm component: whitelisted node rendering, secret placeholder protocol, per-field reset, conflict UI, restart notice. */
import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import Schema from 'schemastery'
import { afterEach, beforeAll, describe, expect, it, vi } from 'vitest'
import { zh } from '../src/client/locales.ts'
import {
  SettingsForm,
  type SettingsFormProps,
} from '../src/client/schema-form.tsx'
import type { SettingsDescriptorLike } from '../src/client/form-logic.ts'

beforeAll(() => {
  ;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
})

const t = (key: string): string => (zh as Record<string, string>)[key] ?? key

type WriteValue = SettingsFormProps['writeValue']
type ResetField = SettingsFormProps['resetField']

interface Bench {
  container: HTMLElement
  root: Root
  writeValue: ReturnType<typeof vi.fn<WriteValue>>
  resetField: ReturnType<typeof vi.fn<ResetField>>
  reload: ReturnType<typeof vi.fn<() => Promise<void>>>
}

const benches: Bench[] = []

afterEach(async () => {
  while (benches.length > 0) {
    const bench = benches.pop()!
    await act(async () => { bench.root.unmount() })
    bench.container.remove()
  }
})

function makeDescriptor(overrides: Partial<SettingsDescriptorLike> = {}): SettingsDescriptorLike {
  return {
    ns: 'test-suite',
    schema: Schema.object({
      name: Schema.string().description('Display name'),
      count: Schema.number(),
      enabled: Schema.boolean(),
      mode: Schema.union(['fast', 'safe']),
      token: Schema.string().role('secret'),
      nested: Schema.object({ depth: Schema.number() }),
      tags: Schema.array(Schema.string()),
    }).toJSON(),
    value: { name: 'alpha', count: 2, enabled: true, mode: 'fast', nested: { depth: 3 }, tags: ['x', 'y'] },
    user: { name: 'alpha', nested: { depth: 3 } },
    revision: 7,
    applies: 'live',
    secrets: [{ path: ['token'], set: true }],
    ...overrides,
  }
}

/** Mount the form with spied write/reset/reload channels. */
async function bench(descriptor: SettingsDescriptorLike): Promise<Bench> {
  const container = document.createElement('div')
  document.body.appendChild(container)
  const root = createRoot(container)
  const writeValue = vi.fn<WriteValue>().mockResolvedValue(undefined)
  const resetField = vi.fn<ResetField>().mockResolvedValue(undefined)
  const reload = vi.fn<() => Promise<void>>().mockResolvedValue(undefined)
  await act(async () => {
    root.render(<SettingsForm descriptor={descriptor} t={t} writeValue={writeValue} resetField={resetField} reload={reload} />)
  })
  const created: Bench = { container, root, writeValue, resetField, reload }
  benches.push(created)
  return created
}

/** One field wrapper by root-relative path. */
function field(container: HTMLElement, path: string): HTMLElement {
  const node = container.querySelector<HTMLElement>(`[data-path="${path}"]`)
  expect(node, `field wrapper for ${path}`).not.toBeNull()
  return node!
}

/** Type into an input/textarea the way React observes it. */
function typeText(input: HTMLInputElement | HTMLTextAreaElement, value: string): void {
  const prototype = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype
  const setter = Object.getOwnPropertyDescriptor(prototype, 'value')!.set!
  setter.call(input, value)
  input.dispatchEvent(new Event('input', { bubbles: true }))
}

/** Commit a text-like control through the blur path. */
async function typeAndBlur(input: HTMLInputElement | HTMLTextAreaElement, value: string): Promise<void> {
  await act(async () => {
    typeText(input, value)
    input.dispatchEvent(new FocusEvent('focusout', { bubbles: true }))
  })
}

describe('SettingsForm rendering', () => {
  it('renders whitelisted scalar nodes as their native controls', async () => {
    const b = await bench(makeDescriptor())
    const name = field(b.container, 'name').querySelector<HTMLInputElement>('input[type="text"]')
    expect(name?.value).toBe('alpha')
    const count = field(b.container, 'count').querySelector<HTMLInputElement>('input[type="number"]')
    expect(count?.value).toBe('2')
    const enabled = field(b.container, 'enabled').querySelector<HTMLInputElement>('input[type="checkbox"]')
    expect(enabled?.checked).toBe(true)
    expect(b.container.textContent).toContain('Display name')
  })

  it('renders a const-only union as a select with every branch as an option', async () => {
    const b = await bench(makeDescriptor())
    const select = field(b.container, 'mode').querySelector<HTMLSelectElement>('select')
    expect(select?.value).toBe('fast')
    expect([...select?.querySelectorAll('option') ?? []].map(option => option.value)).toEqual(['fast', 'safe'])
  })

  it('renders a nested object as a labeled group with recursed fields', async () => {
    const b = await bench(makeDescriptor())
    const group = field(b.container, 'nested')
    expect(group.tagName).toBe('FIELDSET')
    expect(group.querySelector('legend')?.textContent).toBe('Nested')
    const depth = field(b.container, 'nested.depth').querySelector<HTMLInputElement>('input[type="number"]')
    expect(depth?.value).toBe('3')
  })

  it('falls back to a JSON textarea for unsupported nodes', async () => {
    const b = await bench(makeDescriptor())
    const tags = field(b.container, 'tags').querySelector<HTMLTextAreaElement>('textarea')
    expect(tags?.value).toBe(JSON.stringify(['x', 'y'], null, 2))
  })

  it('announces restart-applied settings and stays quiet for live ones', async () => {
    const restarting = await bench(makeDescriptor({ applies: 'restart' }))
    expect(restarting.container.textContent).toContain(zh['form.restartNotice'])
    await act(async () => { restarting.root.unmount() })
    restarting.container.remove()
    benches.splice(benches.indexOf(restarting), 1)

    const live = await bench(makeDescriptor({ applies: 'live' }))
    expect(live.container.textContent).not.toContain(zh['form.restartNotice'])
  })

  it('refuses an unparseable schema with an explicit error', async () => {
    const b = await bench(makeDescriptor({ schema: { uid: 99 } }))
    expect(b.container.querySelector('[role="alert"]')?.textContent).toContain(zh['form.invalidSchema'])
  })
})

describe('SettingsForm writes', () => {
  it('commits a string field with the descriptor revision', async () => {
    const b = await bench(makeDescriptor())
    const name = field(b.container, 'name').querySelector<HTMLInputElement>('input')!
    await typeAndBlur(name, 'beta')
    expect(b.writeValue).toHaveBeenCalledTimes(1)
    expect(b.writeValue).toHaveBeenCalledWith(['name'], 'beta', 7)
    expect(b.resetField).not.toHaveBeenCalled()
  })

  it('commits a parsed number field', async () => {
    const b = await bench(makeDescriptor())
    const count = field(b.container, 'count').querySelector<HTMLInputElement>('input')!
    await typeAndBlur(count, '5')
    expect(b.writeValue).toHaveBeenCalledWith(['count'], 5, 7)
  })

  it('commits a boolean field on toggle', async () => {
    const b = await bench(makeDescriptor())
    const enabled = field(b.container, 'enabled').querySelector<HTMLInputElement>('input[type="checkbox"]')!
    await act(async () => { enabled.click() })
    expect(b.writeValue).toHaveBeenCalledWith(['enabled'], false, 7)
  })

  it('commits the chosen union branch on select', async () => {
    const b = await bench(makeDescriptor())
    const select = field(b.container, 'mode').querySelector<HTMLSelectElement>('select')!
    await act(async () => {
      const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value')!.set!
      setter.call(select, 'safe')
      select.dispatchEvent(new Event('change', { bubbles: true }))
    })
    expect(b.writeValue).toHaveBeenCalledWith(['mode'], 'safe', 7)
  })

  it('commits parsed JSON from the fallback textarea', async () => {
    const b = await bench(makeDescriptor())
    const tags = field(b.container, 'tags').querySelector<HTMLTextAreaElement>('textarea')!
    await typeAndBlur(tags, '["z"]')
    expect(b.writeValue).toHaveBeenCalledWith(['tags'], ['z'], 7)
  })

  it('rejects malformed JSON without writing and flags the field', async () => {
    const b = await bench(makeDescriptor())
    const tags = field(b.container, 'tags').querySelector<HTMLTextAreaElement>('textarea')!
    await typeAndBlur(tags, '{')
    expect(b.writeValue).not.toHaveBeenCalled()
    expect(b.resetField).not.toHaveBeenCalled()
    expect(field(b.container, 'tags').textContent).toContain(zh['form.invalidJson'])
  })

  it('clears a defined number field through the unset channel', async () => {
    const b = await bench(makeDescriptor())
    const count = field(b.container, 'count').querySelector<HTMLInputElement>('input')!
    await typeAndBlur(count, '')
    expect(b.resetField).toHaveBeenCalledWith(['count'], 7)
    expect(b.writeValue).not.toHaveBeenCalled()
  })

  it('does not write when a blurred value is unchanged', async () => {
    const b = await bench(makeDescriptor())
    const name = field(b.container, 'name').querySelector<HTMLInputElement>('input')!
    await typeAndBlur(name, 'alpha')
    expect(b.writeValue).not.toHaveBeenCalled()
    expect(b.resetField).not.toHaveBeenCalled()
  })
})

describe('SettingsForm secret placeholder protocol', () => {
  it('renders the secret as an empty password input with the configured hint', async () => {
    const b = await bench(makeDescriptor())
    const token = field(b.container, 'token').querySelector<HTMLInputElement>('input[type="password"]')
    expect(token).not.toBeNull()
    expect(token?.value).toBe('')
    expect(token?.placeholder).toBe(zh['form.secretConfigured'])
  })

  it('never submits the placeholder or an untouched secret', async () => {
    const b = await bench(makeDescriptor())
    const token = field(b.container, 'token').querySelector<HTMLInputElement>('input')!
    await typeAndBlur(token, '')
    expect(b.writeValue).not.toHaveBeenCalled()
    expect(b.resetField).not.toHaveBeenCalled()
    expect(token.placeholder).toBe(zh['form.secretConfigured'])
  })

  it('submits only an explicitly typed secret value', async () => {
    const b = await bench(makeDescriptor())
    const token = field(b.container, 'token').querySelector<HTMLInputElement>('input')!
    await typeAndBlur(token, 's3cret')
    expect(b.writeValue).toHaveBeenCalledTimes(1)
    expect(b.writeValue).toHaveBeenCalledWith(['token'], 's3cret', 7)
    const submitted = b.writeValue.mock.calls[0]?.[1]
    expect(submitted).not.toBe(zh['form.secretConfigured'])
  })

  it('shows the empty-secret hint while no secret is configured', async () => {
    const b = await bench(makeDescriptor({ secrets: [{ path: ['token'], set: false }] }))
    const token = field(b.container, 'token').querySelector<HTMLInputElement>('input[type="password"]')
    expect(token?.placeholder).toBe(zh['form.secretEmpty'])
  })
})

describe('SettingsForm per-field reset', () => {
  it('resets a user-overridden field through the unset channel', async () => {
    const b = await bench(makeDescriptor())
    const reset = field(b.container, 'name').querySelector<HTMLButtonElement>('button')
    expect(reset?.textContent).toBe(zh['form.reset'])
    await act(async () => { reset!.click() })
    expect(b.resetField).toHaveBeenCalledTimes(1)
    expect(b.resetField).toHaveBeenCalledWith(['name'], 7)
    expect(b.writeValue).not.toHaveBeenCalled()
  })

  it('offers reset for a configured secret even though its value never crossed the wire', async () => {
    const b = await bench(makeDescriptor())
    const reset = field(b.container, 'token').querySelector<HTMLButtonElement>('button')
    expect(reset).not.toBeNull()
    await act(async () => { reset!.click() })
    expect(b.resetField).toHaveBeenCalledWith(['token'], 7)
  })

  it('hides reset for inherited fields', async () => {
    const b = await bench(makeDescriptor())
    expect(field(b.container, 'count').querySelector('button')).toBeNull()
  })
})

describe('SettingsForm failure surfaces', () => {
  it('turns a revision conflict into a reload prompt', async () => {
    const b = await bench(makeDescriptor())
    b.writeValue.mockRejectedValueOnce(
      Object.assign(new Error('settings moved'), { code: 'SETTINGS_CONFLICT', expected: 7, actual: 9 }),
    )
    const name = field(b.container, 'name').querySelector<HTMLInputElement>('input')!
    await typeAndBlur(name, 'beta')
    const alert = b.container.querySelector<HTMLElement>('[role="alert"]')
    expect(alert?.textContent).toContain(zh['form.conflict'])
    const reloadButton = [...b.container.querySelectorAll<HTMLButtonElement>('button')]
      .find(button => button.textContent === zh['form.reload'])
    expect(reloadButton).toBeDefined()
    await act(async () => { reloadButton!.click() })
    expect(b.reload).toHaveBeenCalledTimes(1)
  })

  it('surfaces a plain write failure without a reload prompt', async () => {
    const b = await bench(makeDescriptor())
    b.writeValue.mockRejectedValueOnce(new Error('boom'))
    const name = field(b.container, 'name').querySelector<HTMLInputElement>('input')!
    await typeAndBlur(name, 'beta')
    const alert = b.container.querySelector<HTMLElement>('[role="alert"]')
    expect(alert?.textContent).toContain('boom')
    expect(alert?.textContent).not.toContain(zh['form.conflict'])
  })
})
