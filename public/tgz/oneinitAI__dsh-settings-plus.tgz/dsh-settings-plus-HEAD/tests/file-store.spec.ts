import { afterEach, describe, expect, it } from 'vitest'
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import {
  MAX_READ_BYTES,
  MAX_WRITE_BYTES,
  createFileStore,
  fsVersionBrand,
  isConflictError,
} from '../src/file-store.ts'
import type { FsLike, FsVersion } from '../src/file-store.ts'

/** Temp directories created by fixtures, removed after each test. */
const tempDirs: string[] = []

function createTempHome(): string {
  const home = mkdtempSync(join(tmpdir(), 'dsh-settings-plus-'))
  tempDirs.push(home)
  return home
}

afterEach(() => {
  while (tempDirs.length > 0) {
    const dir = tempDirs.pop()
    if (dir !== undefined) rmSync(dir, { recursive: true, force: true })
  }
})

/** One fake-file cell: the content plus its freshness token. */
interface FakeFile {
  content: string
  version: FsVersion
}

/** Recorded writeText invocation, for asserting guard forwarding. */
interface RecordedWrite {
  target: unknown
  content: string
  expected: unknown
}

/** A config file write that the fake fs rejects as stale. */
const STALE_ERROR = Object.assign(new Error('stale version'), { code: 'FS_STALE_VERSION' })

/** Build an in-memory fs channel whose store mirrors the real temp home. */
function createFakeFs(files: Record<string, string> = {}): FsLike & { written: RecordedWrite[] } {
  const store = new Map<string, FakeFile>()
  for (const [path, content] of Object.entries(files)) {
    store.set(path, { content, version: { [fsVersionBrand]: 'FsVersion' } })
  }
  const written: RecordedWrite[] = []
  let nextVersion = 0
  return {
    written,
    async readText(target) {
      const file = store.get(String(target))
      if (file === undefined) throw new Error(`no such file: ${String(target)}`)
      return file.content
    },
    async writeText(target, content, expected) {
      written.push({ target, content, expected })
      const key = String(target)
      const current = store.get(key)
      if (expected?.kind === 'replaceIfVersion') {
        if (current === undefined || current.version !== expected.version) throw STALE_ERROR
      }
      const version: FsVersion = { [fsVersionBrand]: 'FsVersion' }
      nextVersion += 1
      store.set(key, { content, version })
      return {
        operation: current === undefined ? 'create' : 'update',
        version,
        before: current?.content ?? null,
        after: content,
      }
    },
    async stat(target) {
      const file = store.get(String(target))
      if (file === undefined) return undefined
      return { version: file.version, type: 'file' as const, size: Buffer.byteLength(file.content) }
    },
  }
}

describe('readFile', () => {
  it('returns the text content with the stat version for a later write guard', async () => {
    const home = createTempHome()
    const path = join(home, 'settings.yaml')
    writeFileSync(path, 'a: 1\n')
    const fs = createFakeFs({ [path]: 'a: 1\n' })
    const store = createFileStore({ fs }, { dshHome: home })

    const result = await store.readFile(path)

    expect(result.content).toBe('a: 1\n')
    expect(result.version).toBeDefined()
  })

  it('rejects a file whose stat size exceeds MAX_READ_BYTES', async () => {
    const home = createTempHome()
    const path = join(home, 'settings.yaml')
    writeFileSync(path, 'x')
    const fs: FsLike = {
      async readText() {
        return ''
      },
      async writeText() {
        throw new Error('unexpected write')
      },
      async stat() {
        return { version: { [fsVersionBrand]: 'FsVersion' }, type: 'file', size: MAX_READ_BYTES + 1 }
      },
    }
    const store = createFileStore({ fs }, { dshHome: home })

    await expect(store.readFile(path)).rejects.toMatchObject({ code: 'FILE_TOO_LARGE' })
  })

  it('rejects a file whose read content exceeds MAX_READ_BYTES even without stat size', async () => {
    const home = createTempHome()
    const path = join(home, 'settings.yaml')
    writeFileSync(path, 'x')
    const fs: FsLike = {
      async readText() {
        return 'y'.repeat(MAX_READ_BYTES + 1)
      },
      async writeText() {
        throw new Error('unexpected write')
      },
    }
    const store = createFileStore({ fs }, { dshHome: home })

    await expect(store.readFile(path)).rejects.toMatchObject({ code: 'FILE_TOO_LARGE' })
  })

  it('rejects a path escaping the dsh home boundary', async () => {
    const home = createTempHome()
    const fs = createFakeFs()
    const store = createFileStore({ fs }, { dshHome: home })

    await expect(store.readFile(join(home, '..', 'escape.yml'))).rejects.toMatchObject({ code: 'TARGET_FORBIDDEN' })
  })
})

describe('writeFile', () => {
  it('forwards a replaceIfVersion guard when an expected version is given', async () => {
    const home = createTempHome()
    const path = join(home, 'settings.yaml')
    writeFileSync(path, 'a: 1\n')
    const fs = createFakeFs({ [path]: 'a: 1\n' })
    const store = createFileStore({ fs }, { dshHome: home })
    const read = await store.readFile(path)

    const outcome = await store.writeFile(path, 'a: 2\n', read.version)

    expect(outcome.operation).toBe('update')
    expect(fs.written).toHaveLength(1)
    expect(fs.written[0]!).toMatchObject({ target: path, content: 'a: 2\n', expected: { kind: 'replaceIfVersion' } })
    expect(fs.written[0]!.expected).toMatchObject({ version: read.version })
  })

  it('writes unconditionally when no expected version is given', async () => {
    const home = createTempHome()
    const path = join(home, 'settings.yaml')
    writeFileSync(path, 'a: 1\n')
    const fs = createFakeFs({ [path]: 'a: 1\n' })
    const store = createFileStore({ fs }, { dshHome: home })

    const outcome = await store.writeFile(path, 'a: 2\n')

    expect(outcome.operation).toBe('update')
    expect(fs.written).toHaveLength(1)
    expect(fs.written[0]!.expected).toBeUndefined()
  })

  it('surfaces an FS_STALE_VERSION write as a conflict error', async () => {
    const home = createTempHome()
    const path = join(home, 'settings.yaml')
    writeFileSync(path, 'a: 1\n')
    const fs = createFakeFs({ [path]: 'a: 1\n' })
    const store = createFileStore({ fs }, { dshHome: home })
    const staleVersion = { [fsVersionBrand]: 'FsVersion' } as FsVersion

    const rejection = store.writeFile(path, 'a: 2\n', staleVersion)

    await expect(rejection).rejects.toMatchObject({ code: 'FS_STALE_VERSION' })
    await expect(rejection.catch(error => isConflictError(error))).resolves.toBe(true)
  })

  it('rejects a path outside the writable manifest', async () => {
    const home = createTempHome()
    const path = join(home, '.env')
    writeFileSync(path, 'SECRET=1\n')
    const fs = createFakeFs()
    const store = createFileStore({ fs }, { dshHome: home })

    await expect(store.writeFile(path, 'SECRET=2\n')).rejects.toMatchObject({ code: 'TARGET_FORBIDDEN' })
    expect(fs.written).toHaveLength(0)
  })

  it('rejects content exceeding MAX_WRITE_BYTES', async () => {
    const home = createTempHome()
    const path = join(home, 'settings.yaml')
    writeFileSync(path, 'a: 1\n')
    const fs = createFakeFs({ [path]: 'a: 1\n' })
    const store = createFileStore({ fs }, { dshHome: home })

    await expect(store.writeFile(path, 'y'.repeat(MAX_WRITE_BYTES + 1))).rejects.toMatchObject({
      code: 'CONTENT_TOO_LARGE',
    })
    expect(fs.written).toHaveLength(0)
  })
})

describe('isConflictError', () => {
  it('recognizes an FS_STALE_VERSION error code', () => {
    expect(isConflictError(STALE_ERROR)).toBe(true)
  })

  it('rejects non-conflict errors and non-objects', () => {
    expect(isConflictError(new Error('boom'))).toBe(false)
    expect(isConflictError(null)).toBe(false)
    expect(isConflictError('FS_STALE_VERSION')).toBe(false)
  })
})
