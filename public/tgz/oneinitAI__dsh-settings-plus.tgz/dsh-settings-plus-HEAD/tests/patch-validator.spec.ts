import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'
import { assertSelfRowsPreserved, validateBeforeWrite, validatePatchDocument } from '../src/patch-validator.ts'
import { describeHmrBehavior } from '../src/hmr-aware.ts'

/** A minimal valid patch document carrying all three self rows. */
const VALID_PATCH = [
  '- id: cordis-fabric',
  '  disabled: true',
  '  config:',
  '    fabric:',
  '      patches:',
  '        - id: dsh-settings-plus/exposed-namespaces',
  '          target:',
  "            module: '@deepseek-ai/dsh-host-apiproxy'",
  '- insert:',
  '    - id: dsh-settings-plus',
  "      name: '@deepseek-ai/dsh-settings-plus'",
  '    - id: dsh-settings-plus-invariant',
  "      name: '@deepseek-ai/dsh-settings-plus/invariant'",
].join('\n') + '\n'

/** The repository's own patch document, the strongest valid fixture. */
const REAL_PATCH = readFileSync(new URL('../cordis.patch.yml', import.meta.url), 'utf8')

describe('validatePatchDocument', () => {
  it('accepts a semantically valid patch document', () => {
    const result = validatePatchDocument(VALID_PATCH)

    expect(result.ok).toBe(true)
    expect(result.errors).toEqual([])
  })

  it('accepts the repository cordis.patch.yml itself', () => {
    const result = validatePatchDocument(REAL_PATCH)

    expect(result.ok).toBe(true)
    expect(result.errors).toEqual([])
  })

  it('rejects syntactically invalid YAML with the line number', () => {
    const result = validatePatchDocument('a: [1, 2\n')

    expect(result.ok).toBe(false)
    expect(result.errors).toHaveLength(1)
    expect(result.errors[0]).toContain('line')
  })

  it('rejects a non-sequence document', () => {
    const result = validatePatchDocument('a: 1\n')

    expect(result.ok).toBe(false)
    expect(result.errors[0]).toContain('sequence')
  })

  it('rejects an entry without an id', () => {
    const result = validatePatchDocument('- disabled: true\n')

    expect(result.ok).toBe(false)
    expect(result.errors[0]).toContain('id')
  })

  it('rejects an insert child without a name', () => {
    const text = ['- insert:', '    - id: dsh-settings-plus', ''].join('\n')
    const result = validatePatchDocument(text)

    expect(result.ok).toBe(false)
    expect(result.errors[0]).toContain('name')
  })

  it('rejects a cordis-fabric entry without config.fabric.patches', () => {
    const text = ['- id: cordis-fabric', '  disabled: true', '  config:', '    fabric: {}', ''].join('\n')
    const result = validatePatchDocument(text)

    expect(result.ok).toBe(false)
    expect(result.errors[0]).toContain('patches')
  })

  it('rejects a cordis-fabric patch without a target', () => {
    const text = [
      '- id: cordis-fabric',
      '  config:',
      '    fabric:',
      '      patches:',
      '        - id: dsh-settings-plus/exposed-namespaces',
      '',
    ].join('\n')
    const result = validatePatchDocument(text)

    expect(result.ok).toBe(false)
    expect(result.errors[0]).toContain('target')
  })
})

describe('assertSelfRowsPreserved', () => {
  it('reports no missing rows for a complete document', () => {
    expect(assertSelfRowsPreserved(VALID_PATCH)).toEqual([])
    expect(assertSelfRowsPreserved(REAL_PATCH)).toEqual([])
  })

  it('reports the cordis-fabric stub when its entry is deleted', () => {
    const text = VALID_PATCH.replace('- id: cordis-fabric\n  disabled: true\n  config:\n    fabric:\n      patches:\n        - id: dsh-settings-plus/exposed-namespaces\n          target:\n            module: \'@deepseek-ai/dsh-host-apiproxy\'\n', '')

    const missing = assertSelfRowsPreserved(text)

    expect(missing).toHaveLength(1)
    expect(missing[0]).toContain('cordis-fabric stub')
  })

  it('reports the cordis-fabric stub when its patch id is renamed', () => {
    const text = VALID_PATCH.replace('dsh-settings-plus/exposed-namespaces', 'someone-else/exposed-namespaces')

    const missing = assertSelfRowsPreserved(text)

    expect(missing).toHaveLength(1)
    expect(missing[0]).toContain('cordis-fabric stub')
  })

  it('reports the plugin row when it is deleted', () => {
    const text = VALID_PATCH.replace('    - id: dsh-settings-plus\n      name: \'@deepseek-ai/dsh-settings-plus\'\n', '')

    const missing = assertSelfRowsPreserved(text)

    expect(missing).toHaveLength(1)
    expect(missing[0]).toContain('plugin row')
    expect(missing[0]).toContain('dsh-settings-plus')
  })

  it('reports the invariant row when it is deleted', () => {
    const text = VALID_PATCH.replace('    - id: dsh-settings-plus-invariant\n      name: \'@deepseek-ai/dsh-settings-plus/invariant\'\n', '')

    const missing = assertSelfRowsPreserved(text)

    expect(missing).toHaveLength(1)
    expect(missing[0]).toContain('invariant row')
  })

  it('reports rows as unverifiable when the document does not parse', () => {
    const missing = assertSelfRowsPreserved('not: [valid\n')

    expect(missing.length).toBeGreaterThan(0)
    expect(missing[0]).toContain('not parseable')
  })
})

describe('validateBeforeWrite', () => {
  it('accepts a valid complete document with default self-protection', () => {
    const result = validateBeforeWrite(VALID_PATCH)

    expect(result.ok).toBe(true)
    expect(result.errors).toEqual([])
    expect(result.selfRowsMissing).toEqual([])
  })

  it('rejects a document missing a self row when requireSelfProtection defaults to true', () => {
    const text = VALID_PATCH.replace('    - id: dsh-settings-plus\n      name: \'@deepseek-ai/dsh-settings-plus\'\n', '')

    const result = validateBeforeWrite(text)

    expect(result.ok).toBe(false)
    expect(result.selfRowsMissing).toHaveLength(1)
    expect(result.errors.some(error => error.includes('self-protection'))).toBe(true)
  })

  it('reports but passes when requireSelfProtection is explicitly false', () => {
    const text = VALID_PATCH.replace('    - id: dsh-settings-plus\n      name: \'@deepseek-ai/dsh-settings-plus\'\n', '')

    const result = validateBeforeWrite(text, { requireSelfProtection: false })

    expect(result.ok).toBe(true)
    expect(result.selfRowsMissing).toHaveLength(1)
    expect(result.errors.some(error => error.includes('self-protection'))).toBe(false)
  })

  it('still rejects syntactically invalid text even with self-protection disabled', () => {
    const result = validateBeforeWrite('a: [1, 2\n', { requireSelfProtection: false })

    expect(result.ok).toBe(false)
    expect(result.errors[0]).toContain('line')
  })
})

describe('describeHmrBehavior', () => {
  it('describes the watchUserPatches replay for cordis.patch.yml', () => {
    const text = describeHmrBehavior('cordis-patch')

    expect(text).toContain('watchUserPatches')
    expect(text).toContain('hot-reload')
    expect(text).not.toContain('restart')
  })

  it('describes the settings-file watcher for settings.yaml', () => {
    const text = describeHmrBehavior('settings')

    expect(text).toContain('settings-file')
    expect(text).toContain('hot-reload')
    expect(text).not.toContain('restart')
  })
})
