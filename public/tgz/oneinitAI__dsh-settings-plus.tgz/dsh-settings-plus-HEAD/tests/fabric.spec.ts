import { describe, expect, it, vi } from 'vitest'
import { Context } from 'cordis'
import {
  EXPOSED_NAMESPACES_PATCH,
  exposedNamespacesTarget,
  registerExposedNamespacesPatch,
  widenExposedNamespaces,
} from '../src/fabric.ts'
import type { FabricCall, FabricCompatLike, FabricPatchRegistration } from '../src/fabric.ts'
import type { NamespaceDescriptor, SettingsCrawler } from '../src/crawler.ts'

/** Fake crawler face: only the namespace enumeration the widening handler reads. */
type NamespaceSource = Pick<SettingsCrawler, 'listNamespaces'>

function makeDescriptor(ns: string): NamespaceDescriptor {
  return { ns, schema: {}, value: {}, revision: 1, applies: 'live' }
}

function makeCrawler(namespaces: string[]): NamespaceSource & { listNamespaces: ReturnType<typeof vi.fn<() => NamespaceDescriptor[]>> } {
  return { listNamespaces: vi.fn(() => namespaces.map(makeDescriptor)) }
}

interface FakeCompat extends FabricCompatLike {
  registerPatch: ReturnType<typeof vi.fn<(registration: FabricPatchRegistration) => void>>
}

function makeCompat(): FakeCompat {
  return { registerPatch: vi.fn() }
}

/** Mount a `fabricCompat` service on a context for tests, mirroring the host seam. */
function mountCompat(ctx: Context, value: unknown): () => void | Promise<void> {
  return ctx.provide('fabricCompat', value) as unknown as () => void | Promise<void>
}

describe('fabric exposed-namespaces binding', () => {
  it('widens a Set result in place with every crawled namespace', () => {
    const crawler = makeCrawler(['session', 'gateway'])
    const call: FabricCall = { result: new Set(['product']) }

    widenExposedNamespaces(call, crawler)

    expect(call.result).toEqual(new Set(['product', 'session', 'gateway']))
    expect(crawler.listNamespaces).toHaveBeenCalledTimes(1)
  })

  it('leaves non-Set results untouched without consulting the crawler', () => {
    const crawler = makeCrawler(['session'])
    const call: FabricCall = { result: ['product'] }

    widenExposedNamespaces(call, crawler)

    expect(call.result).toEqual(['product'])
    expect(crawler.listNamespaces).not.toHaveBeenCalled()
  })

  it('registers an after patch under the shared id and the gateway exposure target', () => {
    const ctx = new Context()
    const compat = makeCompat()
    const crawler = makeCrawler(['session'])

    const registered = registerExposedNamespacesPatch(ctx, crawler, { compat })

    expect(registered).toBe(true)
    expect(compat.registerPatch).toHaveBeenCalledTimes(1)
    const [patch] = compat.registerPatch.mock.calls[0]!
    expect(patch.id).toBe(EXPOSED_NAMESPACES_PATCH)
    expect(patch.id).toBe('dsh-settings-plus/exposed-namespaces')
    expect(patch.operation).toBe('after')
    expect(patch.target).toEqual(exposedNamespacesTarget)
    expect(patch.target.module).toBe('@deepseek-ai/dsh-host-apiproxy')
    expect(patch.target.filePaths).toEqual(['src/api-proxy.ts', 'lib/index.js'])
    expect(patch.target.functionQuery).toEqual({ functionName: 'exposedNamespaces', kind: 'Sync' })
  })

  it('binds a handler that widens the traced call result through the registered patch', () => {
    const ctx = new Context()
    const compat = makeCompat()
    const crawler = makeCrawler(['session'])
    registerExposedNamespacesPatch(ctx, crawler, { compat })

    const [patch] = compat.registerPatch.mock.calls[0]!
    const call: FabricCall = { result: new Set(['product']) }
    patch.handler(call)

    expect(call.result).toEqual(new Set(['product', 'session']))
  })

  it('resolves the compat facade from the host context when none is injected', () => {
    const ctx = new Context()
    const compat = makeCompat()
    const removeCompat = mountCompat(ctx, compat)

    const registered = registerExposedNamespacesPatch(ctx, makeCrawler(['session']))

    expect(registered).toBe(true)
    expect(compat.registerPatch).toHaveBeenCalledTimes(1)
    void removeCompat()
  })

  it('degrades to a safe no-op when no compat facade is available', () => {
    const ctx = new Context()

    const registered = registerExposedNamespacesPatch(ctx, makeCrawler(['session']))

    expect(registered).toBe(false)
  })

  it('fails loud when the mounted facade lacks a registerPatch method', () => {
    const ctx = new Context()
    const removeCompat = mountCompat(ctx, { broken: true })

    expect(() => registerExposedNamespacesPatch(ctx, makeCrawler(['session']))).toThrow('registerPatch')
    void removeCompat()
  })
})
