/**
 * Client catalog two-pane display rules. Plugin pane: strictly
 * SDK-registered entries — official DSH entries never appear, no matter how
 * they look. Official pane: strictly the user-declared officialFileEntries
 * list, minus any SDK-marked id — a declared id that belongs to an
 * SDK-registered third-party entry stays on the plugin pane. The two rules
 * are mutually exclusive and locked by tests below.
 */
import { describe, expect, it, vi } from 'vitest'
import { Context } from 'cordis'
import {
  createRpcCatalogSource,
  projectOfficialEntries,
  projectPluginEntries,
  SELF_PLUGIN_ID,
  type CatalogCandidate,
} from '../src/client/catalog.ts'
import type { NamespaceDescriptor } from '../src/crawler.ts'

function namespace(key: string, registeredBySdk?: boolean): CatalogCandidate {
  return registeredBySdk === true ? { key, registeredBySdk: true } : { key }
}

/** A namespace candidate carrying its full crawler descriptor. */
function namespaceWithDescriptor(descriptor: NamespaceDescriptor): CatalogCandidate {
  return { key: descriptor.ns, registeredBySdk: descriptor.registeredBySdk === true, descriptor }
}

/** A minimal but realistic namespace descriptor for projection tests. */
function makeNamespaceDescriptor(ns: string, overrides: Partial<NamespaceDescriptor> = {}): NamespaceDescriptor {
  return {
    ns,
    schema: { uid: 1, refs: {} },
    value: { enabled: true, ttl: 60 },
    user: { enabled: true },
    revision: 7,
    applies: 'live',
    secrets: [{ path: ['token'], set: true }],
    ...overrides,
  }
}

function composition(key: string, registeredBySdk?: boolean): CatalogCandidate {
  return registeredBySdk === true ? { key, registeredBySdk: true } : { key }
}

function keys(entries: readonly { key: string }[]): string[] {
  return entries.map(entry => entry.key)
}

describe('projectPluginEntries strict-SDK pane rule', () => {
  it('shows only SDK-registered namespaces; official namespaces never appear', () => {
    const entries = projectPluginEntries(
      [namespace('llm-deepseek'), namespace('third-party-app', true), namespace('permission')],
      [],
    )
    expect(keys(entries)).toEqual(['third-party-app'])
  })

  it('shows only SDK-registered compositions; official and internal ids never appear', () => {
    const entries = projectPluginEntries([], [
      composition('jobs'),
      composition('sandbox', true),
      composition('llm-deepseek'),
      composition('connection'),
    ])
    expect(keys(entries)).toEqual(['sandbox'])
  })

  it('never shows an official DSH entry even when its id looks internal', () => {
    const entries = projectPluginEntries([namespace('jobs'), namespace('spill-policy')], [])
    expect(entries).toEqual([])
  })

  it('hides this plugin itself even when marked', () => {
    const entries = projectPluginEntries(
      [namespace(SELF_PLUGIN_ID, true), namespace('session', true)],
      [],
    )
    expect(keys(entries)).toEqual(['session'])
  })

  it('deduplicates keys across namespaces and compositions', () => {
    const entries = projectPluginEntries(
      [namespace('session', true), namespace('permission', true)],
      [composition('session', true), composition('permission', true)],
    )
    expect(keys(entries)).toEqual(['session', 'permission'])
  })

  it('projects namespaces before compositions, preserving input order within each list', () => {
    const entries = projectPluginEntries(
      [namespace('ui-theme', true), namespace('shell', true)],
      [composition('approval', true), composition('llm-pi-ai', true)],
    )
    expect(keys(entries)).toEqual(['ui-theme', 'shell', 'approval', 'llm-pi-ai'])
  })
})

describe('projectOfficialEntries declared-list pane rule', () => {
  it('shows only declared ids that exist as live candidates', () => {
    const entries = projectOfficialEntries(
      [namespace('llm-deepseek'), namespace('session')],
      [composition('permission'), composition('approval')],
      ['llm-deepseek', 'approval', 'ghost-entry'],
    )
    expect(keys(entries)).toEqual(['llm-deepseek', 'approval'])
  })

  it('never shows an undeclared entry, no matter how official it looks', () => {
    const entries = projectOfficialEntries(
      [namespace('llm-deepseek'), namespace('permission')],
      [],
      [],
    )
    expect(entries).toEqual([])
  })

  it('refuses an SDK-marked id: it belongs to the plugin pane (mutual exclusion)', () => {
    const entries = projectOfficialEntries(
      [namespace('third-party-app', true)],
      [composition('sandbox', true)],
      ['third-party-app', 'sandbox'],
    )
    expect(entries).toEqual([])
  })

  it('keeps the unmarked candidates of a mixed list and drops the marked ones', () => {
    const entries = projectOfficialEntries(
      [namespace('llm-deepseek'), namespace('third-party-app', true)],
      [composition('permission'), composition('sandbox', true)],
      ['llm-deepseek', 'third-party-app', 'permission', 'sandbox'],
    )
    expect(keys(entries)).toEqual(['llm-deepseek', 'permission'])
  })

  it('follows the declared order and deduplicates repeated ids', () => {
    const entries = projectOfficialEntries(
      [namespace('approval'), namespace('permission')],
      [],
      ['permission', 'approval', 'permission', 'approval'],
    )
    expect(keys(entries)).toEqual(['permission', 'approval'])
  })

  it('hides this plugin itself even when declared', () => {
    const entries = projectOfficialEntries([namespace(SELF_PLUGIN_ID)], [], [SELF_PLUGIN_ID])
    expect(entries).toEqual([])
  })
})

describe('projected entries carry the full renderable descriptor', () => {
  it('official pane namespace entries keep schema/value/user/revision/applies/secrets', () => {
    const descriptor = makeNamespaceDescriptor('llm-deepseek')
    const entries = projectOfficialEntries([namespaceWithDescriptor(descriptor)], [], ['llm-deepseek'])

    expect(entries[0]?.descriptor).toEqual({
      ns: 'llm-deepseek',
      schema: descriptor.schema,
      value: descriptor.value,
      user: descriptor.user,
      revision: 7,
      applies: 'live',
      secrets: [{ path: ['token'], set: true }],
    })
  })

  it('plugin pane namespace entries carry their descriptor too', () => {
    const descriptor = makeNamespaceDescriptor('third-party-app', { registeredBySdk: true })
    const entries = projectPluginEntries([namespaceWithDescriptor(descriptor)], [])

    expect(entries[0]?.descriptor?.ns).toBe('third-party-app')
    expect(entries[0]?.descriptor?.revision).toBe(7)
    expect(entries[0]?.descriptor?.value).toEqual({ enabled: true, ttl: 60 })
  })

  it('normalizes a descriptor without a user layer to an empty record', () => {
    const descriptor = makeNamespaceDescriptor('session', { user: undefined })
    const entries = projectOfficialEntries([namespaceWithDescriptor(descriptor)], [], ['session'])

    expect(entries[0]?.descriptor?.user).toEqual({})
  })

  it('composition-only official entries carry no descriptor', () => {
    const entries = projectOfficialEntries([], [composition('approval')], ['approval'])

    expect(entries[0]?.descriptor).toBeUndefined()
  })

  it('candidates without a descriptor produce entries without one', () => {
    const entries = projectOfficialEntries([namespace('session')], [], ['session'])

    expect(entries[0]?.descriptor).toBeUndefined()
  })
})

describe('createRpcCatalogSource', () => {
  /** Mount a fake connection whose rpc.call answers from a canned map. */
  function bench(listNamespaces: unknown, listCompositionConfigs: unknown, officialFileEntries: unknown) {
    const ctx = new Context()
    const call = vi.fn(async (channel: string, method: string) => {
      expect(channel).toBe('/dsh-settings-plus')
      const value = method === 'listNamespaces'
        ? listNamespaces
        : method === 'listCompositionConfigs'
          ? listCompositionConfigs
          : officialFileEntries
      return { ok: true as const, value }
    })
    const removeConnection = ctx.provide('connection', { rpc: { call } })
    return { ctx, call, removeConnection }
  }

  it('loads both panes over the RPC channel: plugin pane strictly SDK, official pane by declaration', async () => {
    const { ctx, call, removeConnection } = bench(
      [
        { ns: 'llm-deepseek', schema: {}, value: {}, revision: 1, applies: 'live' },
        { ns: 'third-party-app', schema: {}, value: {}, revision: 1, applies: 'live', registeredBySdk: true },
      ],
      [
        { id: 'llm-pi-ai', name: 'pi', schemaJSON: {}, value: {} },
        { id: 'sandbox', name: 'sandbox', schemaJSON: {}, value: {}, registeredBySdk: true },
      ],
      ['llm-deepseek', 'llm-pi-ai', 'third-party-app', 'sandbox', 'ghost-entry'],
    )
    const source = createRpcCatalogSource(ctx)

    const result = await source.load()

    expect(call).toHaveBeenCalledTimes(3)
    expect(keys(result.pluginEntries)).toEqual(['third-party-app', 'sandbox'])
    expect(keys(result.officialEntries)).toEqual(['llm-deepseek', 'llm-pi-ai'])
    removeConnection()
  })

  it('refuses a malformed officialFileEntries payload loudly', async () => {
    const { ctx, removeConnection } = bench(
      [{ ns: 'session', schema: {}, value: {}, revision: 1, applies: 'live' }],
      [],
      ['llm-deepseek', 42],
    )
    const source = createRpcCatalogSource(ctx)

    await expect(source.load()).rejects.toThrow(/non-string entry/)
    removeConnection()
  })

  it('refuses a malformed composition payload loudly', async () => {
    const { ctx, removeConnection } = bench(
      [{ ns: 'session', schema: {}, value: {}, revision: 1, applies: 'live' }],
      [{ id: 42 }],
      [],
    )
    const source = createRpcCatalogSource(ctx)

    await expect(source.load()).rejects.toThrow(/composition id/)
    removeConnection()
  })

  it('carries the full namespace descriptor through listNamespaces into the official entries', async () => {
    const { ctx, removeConnection } = bench(
      [{ ns: 'session', schema: { uid: 3 }, value: { ttl: 90 }, user: { ttl: 90 }, revision: 4, applies: 'restart', secrets: [] }],
      [],
      ['session'],
    )
    const source = createRpcCatalogSource(ctx)

    const result = await source.load()

    expect(result.officialEntries[0]?.descriptor).toEqual({
      ns: 'session',
      schema: { uid: 3 },
      value: { ttl: 90 },
      user: { ttl: 90 },
      revision: 4,
      applies: 'restart',
      secrets: [],
    })
    removeConnection()
  })

  it('degrades to the honest empty catalog without a callable rpc face', async () => {
    const ctx = new Context()
    const removeConnection = ctx.provide('connection', { api: {} })
    const source = createRpcCatalogSource(ctx)

    expect(await source.load()).toEqual({ pluginEntries: [], officialEntries: [] })
    removeConnection()
  })
})
