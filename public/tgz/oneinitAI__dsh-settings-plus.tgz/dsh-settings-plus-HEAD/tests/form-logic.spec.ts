/** Schema-form pure logic: envelope rehydration, whitelist rendering decisions, secret placeholder protocol, unset reset, conflict detection. */
import Schema from 'schemastery'
import { describe, expect, it } from 'vitest'
import {
  buildResetOp,
  buildWriteOps,
  equalJson,
  fieldLabelOf,
  getPath,
  hasPath,
  isConflictError,
  REDACTED_PLACEHOLDER,
  rehydrateSchemaEnvelope,
  renderFieldDescriptors,
  secretAt,
  type FieldDescriptor,
  type LeafFieldDescriptor,
  type RedactedSecretPosition,
  type SchemaNodeLike,
} from '../src/client/form-logic.ts'

/** Narrow a descriptor list to the leaf with the given root-relative path. */
function leafAt(fields: readonly FieldDescriptor[], path: readonly string[]): LeafFieldDescriptor | undefined {
  let level: readonly FieldDescriptor[] = fields
  let found: FieldDescriptor | undefined
  for (const segment of path) {
    found = level.find(field => field.key === segment)
    if (found === undefined) return undefined
    level = found.kind === 'group' ? found.children : []
  }
  return found !== undefined && found.kind === 'field' ? found : undefined
}

describe('rehydrateSchemaEnvelope', () => {
  it('resolves a real schemastery toJSON envelope into a tree', () => {
    const envelope = Schema.object({
      name: Schema.string().description('Display name'),
      nested: Schema.object({ depth: Schema.number() }),
      mode: Schema.union(['fast', 'safe']),
    }).toJSON()
    const root = rehydrateSchemaEnvelope(envelope)
    expect(root?.type).toBe('object')
    expect(root?.dict?.['name']?.type).toBe('string')
    expect(root?.dict?.['name']?.meta?.['description']).toBe('Display name')
    expect(root?.dict?.['nested']?.dict?.['depth']?.type).toBe('number')
    expect(root?.dict?.['mode']?.list?.map(branch => branch.type)).toEqual(['const', 'const'])
    expect(root?.dict?.['mode']?.list?.map(branch => branch.value)).toEqual(['fast', 'safe'])
  })

  it('passes through a node that is already a tree', () => {
    const tree: SchemaNodeLike = { type: 'object', dict: { name: { type: 'string', meta: {} } }, meta: {} }
    expect(rehydrateSchemaEnvelope(tree)).toBe(tree)
  })

  it('returns undefined for shapes that are no schema at all', () => {
    expect(rehydrateSchemaEnvelope(undefined)).toBeUndefined()
    expect(rehydrateSchemaEnvelope(null)).toBeUndefined()
    expect(rehydrateSchemaEnvelope('object')).toBeUndefined()
    expect(rehydrateSchemaEnvelope({})).toBeUndefined()
    expect(rehydrateSchemaEnvelope({ uid: 3 })).toBeUndefined()
    expect(rehydrateSchemaEnvelope({ uid: '3', refs: {} })).toBeUndefined()
    expect(rehydrateSchemaEnvelope({ uid: 9, refs: {} })).toBeUndefined()
  })

  it('breaks lazy cycles by truncating the revisiting node children', () => {
    const cyclic = {
      uid: 1,
      refs: {
        1: { type: 'object', meta: {}, dict: { child: 2 } },
        2: { type: 'object', meta: {}, dict: { again: 1 } },
      },
    }
    const root = rehydrateSchemaEnvelope(cyclic)
    expect(root?.type).toBe('object')
    const child = root?.dict?.['child']
    expect(child?.type).toBe('object')
    // The cycle back to uid 1 is truncated: no dict survives the revisit.
    expect(child?.dict?.['again']?.dict).toBeUndefined()
  })
})

describe('renderFieldDescriptors', () => {
  const envelope = Schema.object({
    name: Schema.string().description('Display name'),
    count: Schema.number().default(1),
    enabled: Schema.boolean(),
    mode: Schema.union(['fast', 'safe']),
    token: Schema.string().role('secret'),
    nested: Schema.object({ depth: Schema.number().description('Recursion depth') }),
    tags: Schema.array(Schema.string()),
    table: Schema.dict(Schema.number()),
    anything: Schema.any(),
    shaped: Schema.union([Schema.object({ a: Schema.string() }), Schema.string()]),
  }).toJSON()
  const fields = renderFieldDescriptors(envelope)

  it('maps whitelisted scalar nodes to their native controls', () => {
    expect(leafAt(fields, ['name'])).toMatchObject({
      kind: 'field', control: 'string', secret: false, fallback: false, description: 'Display name',
    })
    expect(leafAt(fields, ['count'])).toMatchObject({ kind: 'field', control: 'number', fallback: false })
    expect(leafAt(fields, ['enabled'])).toMatchObject({ kind: 'field', control: 'boolean', fallback: false })
  })

  it('maps a const-only union to a select with the branch values as choices', () => {
    const mode = leafAt(fields, ['mode'])
    expect(mode).toMatchObject({ kind: 'field', control: 'select', fallback: false })
    expect(mode?.choices).toEqual(['fast', 'safe'])
  })

  it('marks role(secret) fields without changing their scalar control', () => {
    expect(leafAt(fields, ['token'])).toMatchObject({ kind: 'field', control: 'string', secret: true })
  })

  it('recurses into nested objects as groups carrying child descriptors', () => {
    const nested = fields.find(field => field.key === 'nested')
    expect(nested?.kind).toBe('group')
    expect(leafAt(fields, ['nested', 'depth'])).toMatchObject({
      kind: 'field', control: 'number', path: ['nested', 'depth'], description: 'Recursion depth',
    })
  })

  it.each(['tags', 'table', 'anything', 'shaped'])('falls back to raw JSON editing for %s', (key) => {
    expect(leafAt(fields, [key])).toMatchObject({ kind: 'field', control: 'json', fallback: true })
  })

  it('renders a non-object root as one raw JSON field at the root path', () => {
    const arrayRoot = renderFieldDescriptors(Schema.array(Schema.string()).toJSON())
    expect(arrayRoot).toHaveLength(1)
    expect(arrayRoot[0]).toMatchObject({ kind: 'field', control: 'json', fallback: true, path: [] })
  })

  it('resolves dict-shaped descriptions preferring zh, then en', () => {
    const localized = renderFieldDescriptors(Schema.object({
      a: Schema.string().description({ zh: '甲', en: 'A' }),
      b: Schema.string().description({ en: 'B' }),
      c: Schema.string(),
    }).toJSON())
    expect(leafAt(localized, ['a'])?.description).toBe('甲')
    expect(leafAt(localized, ['b'])?.description).toBe('B')
    expect(leafAt(localized, ['c'])?.description).toBeUndefined()
  })

  it('returns no fields for an unparseable schema', () => {
    expect(renderFieldDescriptors(undefined)).toEqual([])
    expect(renderFieldDescriptors({ uid: 1 })).toEqual([])
  })
})

describe('buildWriteOps', () => {
  it('emits a set op for a changed value', () => {
    expect(buildWriteOps({ path: ['name'] }, 'old', 'new'))
      .toEqual([{ op: 'set', path: ['name'], value: 'new' }])
  })

  it('emits nothing when the value is unchanged', () => {
    expect(buildWriteOps({ path: ['name'] }, 'same', 'same')).toEqual([])
    expect(buildWriteOps({ path: ['nested'] }, { a: 1 }, { a: 1 })).toEqual([])
  })

  it('emits an unset op when a defined value is cleared', () => {
    expect(buildWriteOps({ path: ['name'] }, 'old', undefined))
      .toEqual([{ op: 'unset', path: ['name'] }])
  })

  it('emits nothing when an absent value stays absent', () => {
    expect(buildWriteOps({ path: ['name'] }, undefined, undefined)).toEqual([])
  })

  it('never emits an op for a secret left empty or untouched', () => {
    const field = { path: ['token'], secret: true }
    expect(buildWriteOps(field, undefined, undefined)).toEqual([])
    expect(buildWriteOps(field, undefined, '')).toEqual([])
    expect(buildWriteOps(field, REDACTED_PLACEHOLDER, REDACTED_PLACEHOLDER)).toEqual([])
    expect(buildWriteOps(field, undefined, REDACTED_PLACEHOLDER)).toEqual([])
  })

  it('emits a set op only for an explicitly typed secret value', () => {
    expect(buildWriteOps({ path: ['token'], secret: true }, undefined, 's3cret'))
      .toEqual([{ op: 'set', path: ['token'], value: 's3cret' }])
  })

  it('never unsets a secret through the write path', () => {
    const ops = buildWriteOps({ path: ['token'], secret: true }, 'anything', undefined)
    expect(ops.some(op => op.op === 'unset')).toBe(false)
  })

  it('treats the placeholder as an ordinary string for non-secret fields', () => {
    expect(buildWriteOps({ path: ['name'] }, 'old', REDACTED_PLACEHOLDER))
      .toEqual([{ op: 'set', path: ['name'], value: REDACTED_PLACEHOLDER }])
  })
})

describe('buildResetOp', () => {
  it('emits exactly one unset op addressed at the field path', () => {
    expect(buildResetOp(['nested', 'depth'])).toEqual([{ op: 'unset', path: ['nested', 'depth'] }])
  })

  it('carries no value, so unrelated paths (secrets the wire never returned) survive', () => {
    const ops = buildResetOp(['name'])
    expect(ops).toHaveLength(1)
    expect(ops[0]).not.toHaveProperty('value')
    expect(ops[0]?.op).toBe('unset')
  })
})

describe('isConflictError', () => {
  it('recognizes the wire conflict code', () => {
    expect(isConflictError(Object.assign(new Error('stale'), { code: 'SETTINGS_CONFLICT' }))).toBe(true)
    expect(isConflictError({ code: 'SETTINGS_CONFLICT' })).toBe(true)
  })

  it('recognizes the host error class by name', () => {
    expect(isConflictError(Object.assign(new Error('stale'), { name: 'SettingsConflictError' }))).toBe(true)
  })

  it('rejects everything else', () => {
    expect(isConflictError(new Error('boom'))).toBe(false)
    expect(isConflictError({ code: 'OTHER' })).toBe(false)
    expect(isConflictError(undefined)).toBe(false)
    expect(isConflictError(null)).toBe(false)
    expect(isConflictError('SETTINGS_CONFLICT')).toBe(false)
  })
})

describe('secretAt', () => {
  const secrets: readonly RedactedSecretPosition[] = [
    { path: ['token'], set: true },
    { path: ['nested', 'key'], set: false },
  ]

  it('finds the position by exact path', () => {
    expect(secretAt(secrets, ['token'])).toEqual({ path: ['token'], set: true })
    expect(secretAt(secrets, ['nested', 'key'])).toEqual({ path: ['nested', 'key'], set: false })
  })

  it('misses different or partial paths and undefined sidecars', () => {
    expect(secretAt(secrets, ['nested'])).toBeUndefined()
    expect(secretAt(secrets, ['token', 'extra'])).toBeUndefined()
    expect(secretAt(undefined, ['token'])).toBeUndefined()
  })
})

describe('path and label helpers', () => {
  it('reads and detects deep values', () => {
    const value = { nested: { depth: 3 }, nil: null }
    expect(getPath(value, ['nested', 'depth'])).toBe(3)
    expect(getPath(value, ['nested', 'missing'])).toBeUndefined()
    expect(getPath(value, [])).toBe(value)
    expect(hasPath(value, ['nil'])).toBe(true)
    expect(hasPath(value, ['nested', 'depth'])).toBe(true)
    expect(hasPath(value, ['nested', 'missing'])).toBe(false)
    expect(hasPath(undefined, ['a'])).toBe(false)
  })

  it('compares JSON-shaped data structurally', () => {
    expect(equalJson({ a: 1 }, { a: 1 })).toBe(true)
    expect(equalJson({ a: 1 }, { a: 2 })).toBe(false)
    expect(equalJson(undefined, undefined)).toBe(true)
    expect(equalJson(undefined, null)).toBe(false)
  })

  it('humanizes camelCase and kebab field keys', () => {
    expect(fieldLabelOf('displayName')).toBe('Display name')
    expect(fieldLabelOf('api-key')).toBe('Api key')
    expect(fieldLabelOf('')).toBe('')
  })
})
