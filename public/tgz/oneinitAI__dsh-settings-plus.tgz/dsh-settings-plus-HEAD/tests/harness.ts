import { Context } from 'cordis'
import { vi } from 'vitest'
import * as plugin from '../src/index.ts'
import type { NamespaceDescriptor } from '../src/crawler.ts'
import type { SettingsWriterLike } from '../src/service.ts'

/** Fake settings seam with observable describe/update calls. */
export interface HarnessSettings extends SettingsWriterLike {
  describe: ReturnType<typeof vi.fn<(options?: { redactSecrets?: boolean }) => NamespaceDescriptor[]>>
  update: ReturnType<typeof vi.fn<(ns: string, patch: unknown, expectedRevision?: number) => Promise<void>>>
}

/** Build a fake settings seam serving canned descriptors through an update spy. */
export function makeFakeSettings(descriptors: NamespaceDescriptor[] = []): HarnessSettings {
  return {
    describe: vi.fn(() => descriptors),
    update: vi.fn(async () => {}),
  }
}

/** Mount the production plugin with a fake settings seam and an observable host logger. */
export async function createPluginHarness(config: plugin.Config = {}, settings: HarnessSettings = makeFakeSettings()) {
  const ctx = new Context()
  const info = vi.spyOn(ctx.logger, 'info').mockImplementation(() => undefined)
  const removeSettings = ctx.provide('settings', settings)
  const fiber = await ctx.plugin(plugin, config)

  return {
    ctx,
    fiber,
    info,
    settings,
    async dispose(): Promise<void> {
      try {
        await fiber.dispose()
      } finally {
        await removeSettings()
        info.mockRestore()
      }
    },
  }
}
