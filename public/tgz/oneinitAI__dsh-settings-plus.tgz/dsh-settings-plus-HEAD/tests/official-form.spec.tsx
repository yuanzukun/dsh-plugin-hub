// @vitest-environment jsdom
/**
 * Official settings pane form wiring: a descriptor-carrying official entry
 * renders the generic SettingsForm (not just a label row), and the form's
 * write/reset channels route through the RPC write-back to the host
 * (`updateNamespace` / `resetNamespaceField`), carrying the descriptor
 * revision as expectedRevision. Revision conflicts surfaced by the write-back
 * turn into the form's reload prompt.
 */
import { Context } from 'cordis'
import { act, useSyncExternalStore } from 'react'
import type { ReactNode } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import Schema from 'schemastery'
import { afterEach, beforeAll, describe, expect, it, vi } from 'vitest'
import { apply, inject } from '../src/client/index.ts'
import type { SettingsPlusInjected, SettingsPlusSectionProps } from '../src/client/component.tsx'
import type { SettingsCatalogState, SettingsSectionEntry } from '../src/client/catalog.ts'
import type { SettingsDescriptorLike } from '../src/client/form-logic.ts'
import { SettingsKey, zh } from '../src/client/locales.ts'
import {
  createControllableSource, FakeLocale, FakeSlots, type SectionRegistration,
} from './client-harness.ts'

const SEAT = 'settings.section'
const OFFICIAL_PANE_ID = 'dsh-settings-plus-official'
const RPC_CHANNEL = '/dsh-settings-plus'

/** A boolean-capable renderable descriptor for the official pane. */
function makeDescriptor(overrides: Partial<SettingsDescriptorLike> = {}): SettingsDescriptorLike {
  return {
    ns: 'llm-deepseek',
    schema: Schema.object({
      enabled: Schema.boolean(),
      temperature: Schema.number(),
    }).toJSON(),
    value: { enabled: true, temperature: 1.2 },
    user: { enabled: true },
    revision: 7,
    applies: 'live',
    secrets: [],
    ...overrides,
  }
}

/** One official entry carrying the full renderable descriptor. */
function officialEntry(descriptor: SettingsDescriptorLike): SettingsSectionEntry {
  return { key: descriptor.ns, label: descriptor.ns, descriptor }
}

/** Read the injected business face a registration carries. */
function injectedOf(record: SectionRegistration | undefined): SettingsPlusInjected {
  return record?.options.inject?.() as unknown as SettingsPlusInjected
}

const t = (key: string): string => (zh as Record<string, string>)[key] ?? key

/** Mount the client apply over a fake connection whose rpc.call answers from a canned map. */
async function bench(call: ReturnType<typeof vi.fn>) {
  const ctx = new Context()
  const slots = new FakeSlots()
  const locale = new FakeLocale()
  const removeSlots = ctx.provide('slots', slots)
  const removeLocale = ctx.provide('locale', locale)
  ctx.provide('connection', { rpc: { call } })
  ctx.provide('remote', {})
  const source = createControllableSource()
  ctx.provide('settingsPlusCatalog', source.source)
  slots.declare(SEAT)
  const fiber = ctx.plugin({ inject: [...inject], apply })
  await fiber.await()
  return {
    ctx,
    slots,
    locale,
    fiber,
    source,
    async dispose(): Promise<void> {
      try {
        await fiber.dispose()
      } finally {
        removeSlots()
        removeLocale()
      }
    },
  }
}

const mountedRoots: Array<{ root: Root; container: HTMLElement }> = []

beforeAll(() => {
  ;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
})

afterEach(async () => {
  while (mountedRoots.length > 0) {
    const mounted = mountedRoots.pop()!
    await act(async () => { mounted.root.unmount() })
    mounted.container.remove()
  }
})

/**
 * Render one pane registration reactively: `useSyncExternalStore` subscribes
 * to the catalog store, so a post-write reload re-renders the pane with the
 * refreshed descriptor (exactly what the host's own `useCatalog` does) and
 * later edits resolve against the new revision.
 */
function PaneHost({ record }: { record: SectionRegistration }) {
  const injected = injectedOf(record)
  const snapshot = useSyncExternalStore(
    (listener) => injected.hooks.catalog.subscribe(listener),
    () => injected.hooks.catalog.getSnapshot(),
  )
  const component = record.component as unknown as (props: SettingsPlusSectionProps) => ReactNode
  const props: SettingsPlusSectionProps = {
    close: () => {},
    useCatalog: <S,>(selector: (s: SettingsCatalogState) => S): S => selector(snapshot),
    reload: injected.reload,
    t: t as (key: SettingsKey, params?: Record<string, unknown>) => string,
    ...(injected.writeBack !== undefined ? { writeBack: injected.writeBack } : {}),
  }
  return <>{component(props)}</>
}

/** Render one pane registration and return its container. */
async function renderPane(record: SectionRegistration | undefined): Promise<HTMLElement> {
  const container = document.createElement('div')
  document.body.appendChild(container)
  const root = createRoot(container)
  await act(async () => { root.render(record !== undefined ? <PaneHost record={record} /> : null) })
  mountedRoots.push({ root, container })
  return container
}

describe('official pane editable forms', () => {
  it('renders a SettingsForm block (not a bare label row) for descriptor-carrying entries', async () => {
    const call = vi.fn().mockResolvedValue({ ok: true, value: undefined })
    const b = await bench(call)
    b.source.settle({ officialEntries: [officialEntry(makeDescriptor())] })
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(OFFICIAL_PANE_ID)).hooks.catalog.getSnapshot().status).toBe('ready')
    })

    const container = await renderPane(b.slots.liveById(OFFICIAL_PANE_ID))

    expect(container.querySelector('.dsh_settingsPlus_form')).not.toBeNull()
    const checkbox = container.querySelector<HTMLInputElement>('input[type="checkbox"]')
    expect(checkbox).not.toBeNull()
    expect(checkbox?.checked).toBe(true)
    await b.dispose()
  })

  it('toggles a boolean field through updateNamespace with the descriptor revision', async () => {
    const call = vi.fn().mockResolvedValue({ ok: true, value: undefined })
    const b = await bench(call)
    b.source.settle({ officialEntries: [officialEntry(makeDescriptor())] })
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(OFFICIAL_PANE_ID)).hooks.catalog.getSnapshot().status).toBe('ready')
    })
    const container = await renderPane(b.slots.liveById(OFFICIAL_PANE_ID))

    const checkbox = container.querySelector<HTMLInputElement>('input[type="checkbox"]')!
    await act(async () => { checkbox.click() })

    await vi.waitFor(() => {
      expect(call).toHaveBeenCalledWith(
        RPC_CHANNEL,
        'updateNamespace',
        { ns: 'llm-deepseek', patch: { enabled: false }, expectedRevision: 7 },
      )
    })
    await b.dispose()
  })

  it('resets a user-overridden field through resetNamespaceField with the unset path', async () => {
    const call = vi.fn().mockResolvedValue({ ok: true, value: undefined })
    const b = await bench(call)
    b.source.settle({ officialEntries: [officialEntry(makeDescriptor())] })
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(OFFICIAL_PANE_ID)).hooks.catalog.getSnapshot().status).toBe('ready')
    })
    const container = await renderPane(b.slots.liveById(OFFICIAL_PANE_ID))

    const reset = [...container.querySelectorAll<HTMLButtonElement>('button')]
      .find(button => button.textContent === zh['form.reset'])
    expect(reset).toBeDefined()
    await act(async () => { reset!.click() })

    await vi.waitFor(() => {
      expect(call).toHaveBeenCalledWith(
        RPC_CHANNEL,
        'resetNamespaceField',
        { ns: 'llm-deepseek', path: ['enabled'], expectedRevision: 7 },
      )
    })
    expect(call).not.toHaveBeenCalledWith(RPC_CHANNEL, 'updateNamespace', expect.anything())
    await b.dispose()
  })

  it('surfaces a revision conflict from the write-back as the reload prompt', async () => {
    const call = vi.fn().mockResolvedValue({
      ok: false,
      error: { code: 'SETTINGS_CONFLICT', message: 'settings moved', details: { issues: [] } },
    })
    const b = await bench(call)
    b.source.settle({ officialEntries: [officialEntry(makeDescriptor())] })
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(OFFICIAL_PANE_ID)).hooks.catalog.getSnapshot().status).toBe('ready')
    })
    const container = await renderPane(b.slots.liveById(OFFICIAL_PANE_ID))

    const checkbox = container.querySelector<HTMLInputElement>('input[type="checkbox"]')!
    await act(async () => { checkbox.click() })

    await vi.waitFor(() => {
      expect(container.textContent).toContain(zh['form.conflict'])
    })
    const reload = [...container.querySelectorAll<HTMLButtonElement>('button')]
      .find(button => button.textContent === zh['form.reload'])
    expect(reload).toBeDefined()
    await b.dispose()
  })

  it('renders a plain failure message when the write-back rejects without a conflict', async () => {
    const call = vi.fn().mockResolvedValue({
      ok: false,
      error: { code: 'internal', message: 'boom', details: { issues: [] } },
    })
    const b = await bench(call)
    b.source.settle({ officialEntries: [officialEntry(makeDescriptor())] })
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(OFFICIAL_PANE_ID)).hooks.catalog.getSnapshot().status).toBe('ready')
    })
    const container = await renderPane(b.slots.liveById(OFFICIAL_PANE_ID))

    const checkbox = container.querySelector<HTMLInputElement>('input[type="checkbox"]')!
    await act(async () => { checkbox.click() })

    await vi.waitFor(() => {
      expect(container.textContent).toContain('boom')
    })
    expect(container.textContent).not.toContain(zh['form.conflict'])
    await b.dispose()
  })

  it('refreshes the catalog after a successful write so the next edit carries the new revision', async () => {
    const call = vi.fn().mockResolvedValue({ ok: true, value: undefined })
    const b = await bench(call)
    b.source.settle({ officialEntries: [officialEntry(makeDescriptor({ revision: 7 }))] })
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(OFFICIAL_PANE_ID)).hooks.catalog.getSnapshot().status).toBe('ready')
    })
    const container = await renderPane(b.slots.liveById(OFFICIAL_PANE_ID))

    // First edit: writes with revision 7, then refreshes the catalog.
    const checkbox = container.querySelector<HTMLInputElement>('input[type="checkbox"]')!
    await act(async () => { checkbox.click() })
    await vi.waitFor(() => {
      expect(call).toHaveBeenCalledWith(
        RPC_CHANNEL,
        'updateNamespace',
        { ns: 'llm-deepseek', patch: { enabled: false }, expectedRevision: 7 },
      )
    })
    await vi.waitFor(() => {
      expect(b.source.load).toHaveBeenCalledTimes(2)
    })

    // The refreshed catalog carries the host's bumped revision.
    await act(async () => {
      b.source.settle({ officialEntries: [officialEntry(makeDescriptor({ revision: 8, value: { enabled: false, temperature: 1.2 } }))] })
    })
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(OFFICIAL_PANE_ID)).hooks.catalog.getSnapshot()
        .officialEntries[0]?.descriptor?.revision).toBe(8)
    })

    // Second edit on the same field: the re-rendered form resolves the new
    // descriptor, so the write carries revision 8 — no SETTINGS_CONFLICT.
    await act(async () => { checkbox.click() })
    await vi.waitFor(() => {
      expect(call).toHaveBeenCalledWith(
        RPC_CHANNEL,
        'updateNamespace',
        { ns: 'llm-deepseek', patch: { enabled: true }, expectedRevision: 8 },
      )
    })
    expect(container.textContent).not.toContain(zh['form.conflict'])
    await b.dispose()
  })

  it('refreshes the catalog after a successful reset', async () => {
    const call = vi.fn().mockResolvedValue({ ok: true, value: undefined })
    const b = await bench(call)
    b.source.settle({ officialEntries: [officialEntry(makeDescriptor())] })
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(OFFICIAL_PANE_ID)).hooks.catalog.getSnapshot().status).toBe('ready')
    })
    const container = await renderPane(b.slots.liveById(OFFICIAL_PANE_ID))

    const reset = [...container.querySelectorAll<HTMLButtonElement>('button')]
      .find(button => button.textContent === zh['form.reset'])
    expect(reset).toBeDefined()
    await act(async () => { reset!.click() })

    await vi.waitFor(() => {
      expect(call).toHaveBeenCalledWith(
        RPC_CHANNEL,
        'resetNamespaceField',
        { ns: 'llm-deepseek', path: ['enabled'], expectedRevision: 7 },
      )
    })
    await vi.waitFor(() => {
      expect(b.source.load).toHaveBeenCalledTimes(2)
    })
    await b.dispose()
  })

  it('does not refresh the catalog when a write fails', async () => {
    const call = vi.fn().mockResolvedValue({
      ok: false,
      error: { code: 'SETTINGS_CONFLICT', message: 'settings moved', details: { issues: [] } },
    })
    const b = await bench(call)
    b.source.settle({ officialEntries: [officialEntry(makeDescriptor())] })
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(OFFICIAL_PANE_ID)).hooks.catalog.getSnapshot().status).toBe('ready')
    })
    const container = await renderPane(b.slots.liveById(OFFICIAL_PANE_ID))

    const checkbox = container.querySelector<HTMLInputElement>('input[type="checkbox"]')!
    await act(async () => { checkbox.click() })

    await vi.waitFor(() => {
      expect(container.textContent).toContain(zh['form.conflict'])
    })
    expect(b.source.load).toHaveBeenCalledTimes(1)
    await b.dispose()
  })

  it('keeps label-only rows for entries without a descriptor', async () => {
    const call = vi.fn()
    const b = await bench(call)
    b.source.settle({ officialEntries: [{ key: 'approval', label: 'approval' }] })
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(OFFICIAL_PANE_ID)).hooks.catalog.getSnapshot().status).toBe('ready')
    })

    const container = await renderPane(b.slots.liveById(OFFICIAL_PANE_ID))

    expect(container.querySelector('.dsh_settingsPlus_form')).toBeNull()
    expect(container.querySelectorAll('.dsh_settingsPlus_pane_item')).toHaveLength(1)
    expect(container.textContent).toContain('approval')
    await b.dispose()
  })

  it('injected write-back stays undefined when the connection lacks an rpc face', async () => {
    const ctx = new Context()
    const slots = new FakeSlots()
    const locale = new FakeLocale()
    const removeSlots = ctx.provide('slots', slots)
    const removeLocale = ctx.provide('locale', locale)
    ctx.provide('connection', { api: {} })
    ctx.provide('remote', {})
    const source = createControllableSource()
    ctx.provide('settingsPlusCatalog', source.source)
    slots.declare(SEAT)
    const fiber = ctx.plugin({ inject: [...inject], apply })
    await fiber.await()

    expect(injectedOf(slots.liveById(OFFICIAL_PANE_ID)).writeBack).toBeUndefined()

    await fiber.dispose()
    removeSlots()
    removeLocale()
  })
})
