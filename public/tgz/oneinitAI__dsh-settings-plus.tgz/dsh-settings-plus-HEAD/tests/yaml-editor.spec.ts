import { describe, expect, it } from 'vitest'
import {
  YamlEditorError,
  editJsonText,
  editYamlText,
  parseDocumentText,
  setPath,
  stringifyDocument,
  unsetPath,
} from '../src/yaml-editor.ts'

/** A commented YAML document exercising the comment/anchor surface. */
const COMMENTED_YAML = [
  '# service settings',
  'server:',
  '  # host of the server',
  '  host: localhost # inline note',
  '  ports:',
  '    - 8080 # web port',
  '    - 9090',
  'aliases: &base',
  '  retries: 3',
  'worker:',
  '  <<: *base',
  '  timeout: 30',
].join('\n') + '\n'

describe('parseDocumentText', () => {
  it('rejects syntactically invalid YAML with the line number', () => {
    let error: unknown
    try {
      parseDocumentText('a: [1, 2\n')
    } catch (caught) {
      error = caught
    }
    expect(error).toBeInstanceOf(YamlEditorError)
    expect(error).toMatchObject({ code: 'SYNTAX' })
    expect((error as YamlEditorError).line).toBe(2)
    expect((error as YamlEditorError).message).toContain('line 2')
  })

  it('parses valid text into a document that serializes back', () => {
    const doc = parseDocumentText('a: 1\n')
    expect(stringifyDocument(doc)).toBe('a: 1\n')
  })
})

describe('editYamlText — comment preservation', () => {
  it('keeps top, key, and inline comments when a field is edited', () => {
    const output = editYamlText(COMMENTED_YAML, [{ op: 'set', path: ['server', 'host'], value: '0.0.0.0' }])

    expect(output).toContain('# service settings')
    expect(output).toContain('# host of the server')
    expect(output).toContain('host: 0.0.0.0 # inline note')
    expect(output).not.toContain('localhost')
  })

  it('keeps anchors, aliases, and merge keys across edits', () => {
    const output = editYamlText(COMMENTED_YAML, [{ op: 'set', path: ['worker', 'timeout'], value: 40 }])

    expect(output).toContain('aliases: &base')
    expect(output).toContain('<<: *base')
    expect(output).toContain('retries: 3')
    expect(output).toContain('timeout: 40')
  })

  it('applies nested sets and unsets with sibling comments intact', () => {
    const output = editYamlText(COMMENTED_YAML, [
      { op: 'set', path: ['server', 'host'], value: '0.0.0.0' },
      { op: 'unset', path: ['server', 'ports'] },
      { op: 'set', path: ['server', 'workers'], value: 4 },
    ])

    expect(output).not.toContain('ports')
    expect(output).not.toContain('# web port')
    expect(output).toContain('workers: 4')
    expect(output).toContain('# host of the server')
  })
})

describe('editYamlText — whole-node replacement boundary', () => {
  it('replaces a whole array node and drops its inner comments (documented boundary)', () => {
    const output = editYamlText(COMMENTED_YAML, [
      { op: 'set', path: ['server', 'ports'], value: [111, 222] },
    ])

    expect(output).toContain('ports:')
    expect(output).toContain('- 111')
    expect(output).toContain('- 222')
    expect(output).not.toContain('# web port')
  })

  it('replaces a whole scalar node with a map node', () => {
    const output = editYamlText(COMMENTED_YAML, [
      { op: 'set', path: ['server', 'host'], value: { address: '10.0.0.1', tls: false } },
    ])

    expect(output).toContain('address: 10.0.0.1')
    expect(output).toContain('tls: false')
  })
})

describe('editYamlText — errors', () => {
  it('reports syntax errors with the line number', () => {
    let error: unknown
    try {
      editYamlText('a: [1, 2\n', [])
    } catch (caught) {
      error = caught
    }
    expect(error).toBeInstanceOf(YamlEditorError)
    expect(error).toMatchObject({ code: 'SYNTAX' })
    expect((error as YamlEditorError).line).toBe(2)
  })

  it('rejects a set through a scalar intermediate node', () => {
    expect(() => editYamlText('a: 5\n', [{ op: 'set', path: ['a', 'b'], value: 1 }])).toThrowError(
      expect.objectContaining({ code: 'BAD_PATH' }),
    )
  })

  it('rejects an empty path', () => {
    expect(() => editYamlText('a: 1\n', [{ op: 'set', path: [], value: 1 }])).toThrowError(
      expect.objectContaining({ code: 'BAD_PATH' }),
    )
  })

  it('rejects a set edit without a value', () => {
    expect(() => editYamlText('a: 1\n', [{ op: 'set', path: ['a'], value: undefined }])).toThrowError(
      expect.objectContaining({ code: 'BAD_VALUE' }),
    )
  })

  it('treats unset of a missing key as a no-op success', () => {
    const output = editYamlText('a: 1\n', [{ op: 'unset', path: ['missing', 'key'] }])
    expect(output).toBe('a: 1\n')
  })
})

describe('editYamlText — document-level behavior', () => {
  it('creates the root map when the document is empty', () => {
    expect(editYamlText('', [{ op: 'set', path: ['a'], value: 1 }])).toBe('a: 1\n')
  })

  it('applies several edits in order', () => {
    const output = editYamlText('a: 1\n', [
      { op: 'set', path: ['a'], value: 2 },
      { op: 'set', path: ['b', 'c'], value: 'x' },
      { op: 'unset', path: ['a'] },
    ])

    expect(output).toContain('b:')
    expect(output).toContain('c: x')
    expect(output).not.toContain('a:')
  })
})

describe('setPath / unsetPath / stringifyDocument', () => {
  it('edits a parsed document directly and serializes with comments', () => {
    const doc = parseDocumentText('a: 1 # note\n')
    setPath(doc, ['a'], 2)
    unsetPath(doc, ['b'])
    expect(stringifyDocument(doc)).toBe('a: 2 # note\n')
  })
})

describe('editJsonText — format preservation', () => {
  it('keeps the two-space indentation of the original text', () => {
    const output = editJsonText('{\n  "a": 1,\n  "b": [1, 2]\n}\n', [{ op: 'set', path: ['a'], value: 2 }])

    expect(output).toContain('\n  "a": 2,')
    expect(output).toContain('\n  "b": [')
    expect(output).toContain('\n  ]\n}')
  })

  it('keeps a tab indentation', () => {
    const output = editJsonText('{\n\t"a": 1\n}\n', [{ op: 'set', path: ['a'], value: 2 }])
    expect(output).toContain('\t"a": 2')
  })

  it('keeps compact single-line formatting when the original has no indent', () => {
    expect(editJsonText('{"a":1}', [{ op: 'set', path: ['a'], value: 2 }])).toBe('{"a":2}')
  })

  it('applies nested sets and unsets while staying pretty-printed', () => {
    const output = editJsonText('{\n  "a": {\n    "b": 1,\n    "c": 2\n  }\n}\n', [
      { op: 'set', path: ['a', 'b'], value: 3 },
      { op: 'unset', path: ['a', 'c'] },
    ])

    expect(output).toContain('"b": 3')
    expect(output).not.toContain('"c"')
    expect(output).toContain('\n  "a": {')
  })

  it('supports array roots and in-range index edits', () => {
    expect(editJsonText('[1, 2]', [{ op: 'set', path: [0], value: 9 }])).toBe('[9,2]')
  })

  it('rejects an out-of-range array index for set', () => {
    expect(() => editJsonText('[1, 2]', [{ op: 'set', path: [5], value: 9 }])).toThrowError(
      expect.objectContaining({ code: 'BAD_PATH' }),
    )
  })

  it('reports JSON syntax errors with the line number', () => {
    let error: unknown
    try {
      editJsonText('{\n  "a": 1, }\n', [])
    } catch (caught) {
      error = caught
    }
    expect(error).toBeInstanceOf(YamlEditorError)
    expect(error).toMatchObject({ code: 'SYNTAX' })
    expect((error as YamlEditorError).line).toBe(2)
  })
})
