import { describe, expect, it, vi } from 'vitest'
import { Context } from 'cordis'
import z from 'schemastery'
import { createCrawler } from '../src/crawler.ts'
import type { CompositionRuntimeLike, NamespaceDescriptor } from '../src/crawler.ts'

/** A fake settings seam whose `describe` returns canned descriptors and records its options. */
interface FakeSettings {
  describe: ReturnType<typeof vi.fn<(options?: { redactSecrets?: boolean }) => NamespaceDescriptor[]>>
}

function mountSettings(ctx: Context, settings: FakeSettings): () => void | Promise<void> {
  return ctx.provide('settings', settings) as unknown as () => void | Promise<void>
}

describe('settings crawler', () => {
  it('listNamespaces returns describe results verbatim', () => {
    const ctx = new Context()
    const descriptor: NamespaceDescriptor = {
      ns: 'session',
      schema: { type: 'object', dict: {} },
      value: { ttl: 3600 },
      revision: 5,
      applies: 'live',
    }
    const settings: FakeSettings = { describe: vi.fn(() => [descriptor]) }
    const removeSettings = mountSettings(ctx, settings)
    const crawler = createCrawler(ctx)

    const result = crawler.listNamespaces()

    expect(result).toEqual([descriptor])
    expect(result[0]).toBe(descriptor)
    expect(settings.describe).toHaveBeenCalledTimes(1)
    void removeSettings()
  })

  it('requests redacted descriptors so secret values never reach the caller', () => {
    const ctx = new Context()
    const GatewayConfig = z.object({
      token: z.string().role('secret'),
      host: z.string().default('localhost'),
    })
    const secretToken = 'super-secret-token'
    const settings: FakeSettings = {
      // A provider honors redactSecrets: without the flag it leaks the plaintext.
      describe: vi.fn((options?: { redactSecrets?: boolean }): NamespaceDescriptor[] => [{
        ns: 'gateway',
        schema: GatewayConfig.toJSON(),
        value: options?.redactSecrets
          ? { host: 'example.com' }
          : { host: 'example.com', token: secretToken },
        revision: 2,
        applies: 'restart',
        ...(options?.redactSecrets === true ? { secrets: [{ path: ['token'], set: true }] } : {}),
      }]),
    }
    const removeSettings = mountSettings(ctx, settings)
    const crawler = createCrawler(ctx)

    const [result] = crawler.listNamespaces()

    expect(settings.describe).toHaveBeenCalledWith({ redactSecrets: true })
    expect(result).toBeDefined()
    expect(JSON.stringify(result)).not.toContain(secretToken)
    expect(result?.value).toEqual({ host: 'example.com' })
    expect(result?.secrets).toEqual([{ path: ['token'], set: true }])
    void removeSettings()
  })

  it('enumerates schemastery Config rows and skips rows without a renderable Config', () => {
    const LlmConfig = z.object({
      key: z.string().role('secret'),
      model: z.string().default('deepseek-chat'),
    })
    const rows: CompositionRuntimeLike[] = [
      {
        name: 'plugin-llm',
        Config: LlmConfig,
        fibers: [{
          config: { key: 'sk-abc', model: 'deepseek-reasoner' },
          entry: { options: { id: 'llm-main' } },
        }],
      },
      // No Config at all: never rendered.
      {
        name: 'plugin-bare',
        fibers: [{ config: {}, entry: { options: { id: 'bare' } } }],
      },
      // A standard-schema Config without toJSON(): not schemastery, skipped.
      {
        name: 'plugin-standard',
        Config: { '~standard': { version: 1, vendor: 'test', validate: () => ({}) } },
        fibers: [{ config: {}, entry: { options: { id: 'standard' } } }],
      },
      // Schemastery Config but the fiber carries no composition row id: skipped.
      {
        name: 'plugin-no-id',
        Config: z.object({}),
        fibers: [{ config: {} }],
      },
    ]
    const registryProvider = vi.fn(() => rows.map(runtime => [runtime.name, runtime] as const))
    const ctx = new Context()
    const removeSettings = mountSettings(ctx, { describe: vi.fn(() => []) })
    const crawler = createCrawler(ctx, { registryProvider })

    const result = crawler.listCompositionConfigs()

    expect(registryProvider).toHaveBeenCalledTimes(1)
    expect(result).toHaveLength(1)
    const view = result[0]
    expect(view?.id).toBe('llm-main')
    expect(view?.name).toBe('plugin-llm')
    expect(view?.schemaJSON).toEqual(LlmConfig.toJSON())
    expect(view?.value).toEqual({ model: 'deepseek-reasoner' })
    expect(JSON.stringify(view?.value)).not.toContain('sk-abc')
    void removeSettings()
  })

  it('returns an empty array for an empty registry', () => {
    const ctx = new Context()
    const removeSettings = mountSettings(ctx, { describe: vi.fn(() => []) })
    const crawler = createCrawler(ctx, { registryProvider: () => [] })

    expect(crawler.listCompositionConfigs()).toEqual([])
    void removeSettings()
  })

  it('falls back to the live cordis registry when no provider is injected', async () => {
    const ctx = new Context()
    const removeSettings = mountSettings(ctx, { describe: vi.fn(() => []) })
    const fiber = await ctx.plugin({ name: 'plain', Config: z.object({}), apply: () => {} })
    const crawler = createCrawler(ctx)

    // Without a loader entry the real fiber carries no composition row id.
    expect(crawler.listCompositionConfigs()).toEqual([])

    await fiber.dispose()
    await removeSettings()
  })

  it('fails loud when created without the settings seam', () => {
    const ctx = new Context()

    expect(() => createCrawler(ctx)).toThrow(/settings crawler requires the "settings" service/)
  })
})
