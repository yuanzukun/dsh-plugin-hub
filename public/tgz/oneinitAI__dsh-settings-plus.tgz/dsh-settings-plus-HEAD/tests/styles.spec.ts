// @vitest-environment jsdom
/**
 * The client stylesheet: the settings panes install one `<style>` tag whose
 * rules color every pane class through the host's `--dsw-*` design tokens
 * (never literal colors), mirroring the harness settings controls. The tag is
 * idempotent across re-applies, and the component markup carries the wrapper
 * class the row-separator rules target.
 */
import { Context } from 'cordis'
import { afterEach, describe, expect, it } from 'vitest'
import { apply, inject } from '../src/client/index.ts'
import { FakeLocale, FakeSlots } from './client-harness.ts'

const SEAT = 'settings.section'
const STYLE_ATTR = 'data-dsh-settings-plus'

/** The client classes the panes render, each of which must be styled. */
const RENDERED_CLASSES = [
  'section', 'title', 'desc', 'pane', 'pane_item', 'pane_title',
  'form', 'field', 'field_wrap', 'group', 'reset', 'reload', 'retry',
  'error', 'notice', 'restart',
] as const

/** Mount the client apply over a fake connection lacking an rpc face. */
async function bench() {
  const ctx = new Context()
  const slots = new FakeSlots()
  const locale = new FakeLocale()
  const removeSlots = ctx.provide('slots', slots)
  const removeLocale = ctx.provide('locale', locale)
  ctx.provide('connection', { api: {} })
  ctx.provide('remote', {})
  slots.declare(SEAT)
  const fiber = ctx.plugin({ inject: [...inject], apply })
  await fiber.await()
  return {
    async dispose(): Promise<void> {
      try {
        await fiber.dispose()
      } finally {
        removeSlots()
        removeLocale()
      }
    },
  }
}

const mounted: Array<{ dispose: () => Promise<void> }> = []

afterEach(async () => {
  while (mounted.length > 0) {
    const bench = mounted.pop()!
    await bench.dispose()
  }
})

describe('settings-plus stylesheet', () => {
  it('installs one style tag styling every pane class through the --dsw-* tokens', async () => {
    mounted.push(await bench())

    const tags = [...document.head.querySelectorAll<HTMLStyleElement>(`style[${STYLE_ATTR}]`)]
    expect(tags).toHaveLength(1)
    const css = tags[0]?.textContent ?? ''

    for (const cls of RENDERED_CLASSES) {
      expect(css).toContain(`.dsh_settingsPlus_${cls}`)
    }

    // Colors resolve through the host's design tokens, never literal values:
    // text, borders, surfaces, focus, errors, and checkbox accent.
    expect(css).toContain('var(--dsw-alias-label-primary)')
    expect(css).toContain('var(--dsw-alias-label-secondary)')
    expect(css).toContain('var(--dsw-alias-label-tertiary)')
    expect(css).toContain('var(--dsw-alias-border-l2)')
    expect(css).toContain('var(--dsw-alias-bg-layer-1)')
    expect(css).toContain('var(--dsw-alias-bg-layer-3)')
    expect(css).toContain('var(--dsw-alias-brand-primary)')
    expect(css).toContain('var(--dsw-alias-state-business-primary)')
    expect(css).toContain('var(--dsw-alias-state-error-primary)')
    expect(css).toContain('var(--dsw-alias-button-primary-fill)')
    expect(css).toContain('var(--dsw-alias-interactive-bg-hover)')
    // The only hex in the sheet is the select chevron's URL-encoded SVG stroke.
    expect(css).not.toMatch(new RegExp('#[0-9a-fA-F]{3,6}\\b'))
  })

  it('never relies on the undefined --dsw-alias-label-error token', async () => {
    mounted.push(await bench())

    const css = document.head.querySelector<HTMLStyleElement>(`style[${STYLE_ATTR}]`)?.textContent ?? ''
    expect(css).not.toContain('--dsw-alias-label-error')
  })

  it('is idempotent across repeated applies', async () => {
    mounted.push(await bench())
    mounted.push(await bench())

    expect(document.head.querySelectorAll<HTMLStyleElement>(`style[${STYLE_ATTR}]`)).toHaveLength(1)
  })
})
