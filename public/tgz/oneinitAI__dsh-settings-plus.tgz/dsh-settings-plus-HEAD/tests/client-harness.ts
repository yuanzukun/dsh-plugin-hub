import { vi } from 'vitest'
import type { SlotLabel } from '@deepseek-ai/dsh-client-ui-slots'
import type { CatalogLoadResult, CatalogSource, SettingsSectionEntry } from '../src/client/catalog.ts'

/** Options one registration was recorded with. */
export interface SectionRegistrationOptions {
  name: string
  id?: string
  order?: number
  label?: SlotLabel
  locale?: string
  inject?: () => object
}

/** One registration recorded by the fake slots service. */
export interface SectionRegistration {
  options: SectionRegistrationOptions
  component: unknown
  disposed: boolean
}

/**
 * Fake slots service mirroring the harness SlotRegistry's declaration-aware
 * `inject` semantics: the factory runs while the slot is declared (immediate
 * when already declared), its returned disposer runs on collapse, and
 * `register` records entries with idempotent disposers.
 */
export class FakeSlots {
  readonly injectSpy = vi.fn()
  private readonly declared = new Set<string>()
  private readonly holders = new Map<string, Array<{ factory: () => () => void; active: (() => void) | undefined }>>()
  readonly registrations: SectionRegistration[] = []

  inject(key: string, factory: () => () => void): () => void {
    this.injectSpy(key, factory)
    const holder = { factory, active: undefined as (() => void) | undefined }
    const list = this.holders.get(key) ?? []
    list.push(holder)
    this.holders.set(key, list)
    if (this.declared.has(key)) holder.active = factory()
    return () => {
      holder.active?.()
      holder.active = undefined
    }
  }

  /** Declare a slot (the shell's register call); runs every pending factory. */
  declare(key: string): void {
    this.declared.add(key)
    for (const holder of this.holders.get(key) ?? []) {
      if (holder.active === undefined) holder.active = holder.factory()
    }
  }

  /** Collapse a slot declaration; disposes every active factory effect. */
  collapse(key: string): void {
    this.declared.delete(key)
    for (const holder of this.holders.get(key) ?? []) {
      holder.active?.()
      holder.active = undefined
    }
  }

  register(options: SectionRegistrationOptions, component: unknown): () => void {
    const record: SectionRegistration = { options: { ...options }, component, disposed: false }
    this.registrations.push(record)
    return () => { record.disposed = true }
  }

  /** Live (non-disposed) registrations. */
  live(): SectionRegistration[] {
    return this.registrations.filter(record => !record.disposed)
  }

  /** The live registration with a list-id, if any. */
  liveById(id: string): SectionRegistration | undefined {
    return this.live().find(record => record.options.id === id)
  }
}

/** Resolve a possibly-thunked label the way the shell resolves nav labels. */
export function resolveLabel(record: SectionRegistration | undefined): string | undefined {
  const label = record?.options.label
  return typeof label === 'function' ? label() : label
}

/**
 * Fake locale service: stores dictionaries per namespace, serves zh by
 * default, and resolves `bind` translations against the active language.
 */
export class FakeLocale {
  readonly register = vi.fn()
  private readonly dictionaries = new Map<string, Record<string, Record<string, string>>>()
  private lang = 'zh'

  constructor() {
    this.register.mockImplementation((ns: string, dicts: Record<string, Record<string, string>>) => {
      this.dictionaries.set(ns, dicts)
      return () => { this.dictionaries.delete(ns) }
    })
  }

  bind(ns: string): (key: string) => string {
    return (key) => this.dictionaries.get(ns)?.[this.lang]?.[key] ?? `${ns}.${key}`
  }

  setLang(lang: string): void {
    this.lang = lang
  }
}

/**
 * Controllable catalog source: every `load` stays pending until the test
 * settles or fails it, so the loading phase is observable before the state
 * settles. `settle` accepts partial pane lists (missing panes settle empty),
 * which keeps the test call sites focused on the pane under assertion.
 */
export function createControllableSource() {
  const load = vi.fn<() => Promise<CatalogLoadResult>>()
  let pending: { resolve: (result: CatalogLoadResult) => void; reject: (error: Error) => void } | undefined
  load.mockImplementation(() => new Promise((resolve, reject) => { pending = { resolve, reject } }))
  const source: CatalogSource = { load }
  return {
    source,
    load,
    settle(result: Partial<CatalogLoadResult> = {}): void {
      pending?.resolve({
        pluginEntries: result.pluginEntries ?? [],
        officialEntries: result.officialEntries ?? [],
      })
    },
    fail(error: Error): void { pending?.reject(error) },
  }
}

/** One pane's entry list; a shorthand for assertions. */
export function entries(keysAndLabels: Array<[string, string]>): SettingsSectionEntry[] {
  return keysAndLabels.map(([key, label]) => ({ key, label }))
}
