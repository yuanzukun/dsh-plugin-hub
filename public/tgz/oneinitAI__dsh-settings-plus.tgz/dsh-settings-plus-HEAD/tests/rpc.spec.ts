/**
 * Host service SDK marking + RPC envelope pass-through: markSdkRegistered
 * annotates live lists with registeredBySdk, and the channel handler carries
 * the marker through the envelope untouched.
 */
import { describe, expect, it, vi } from 'vitest'
import { Context } from 'cordis'
import type { CompositionConfigView, NamespaceDescriptor, SettingsCrawler } from '../src/crawler.ts'
import { createDshSettingsPlusService } from '../src/service.ts'
import { createSettingsPlusRpcHandler, registerSettingsPlusRpc, RPC_CHANNEL, type SettingsPlusRpcHandler } from '../src/rpc.ts'

function makeDescriptor(ns: string): NamespaceDescriptor {
  return { ns, schema: {}, value: {}, revision: 1, applies: 'live' }
}

function makeComposition(id: string): CompositionConfigView {
  return { id, name: 'pkg', schemaJSON: {}, value: {} }
}

/** A crawler whose two list surfaces return canned views. */
function makeCrawler(namespaces: NamespaceDescriptor[], compositions: CompositionConfigView[]): SettingsCrawler {
  return {
    listNamespaces: () => namespaces,
    listCompositionConfigs: () => compositions,
  }
}

/** A context with the settings writer seam mounted for the service. */
function makeContext(): Context {
  const ctx = new Context()
  ctx.provide('settings', { update: async () => {} })
  return ctx
}

describe('dshSettingsPlus service SDK marking', () => {
  it('annotates the marked namespace with registeredBySdk: true and leaves others unmarked', () => {
    const ctx = makeContext()
    const service = createDshSettingsPlusService(ctx, makeCrawler(
      [makeDescriptor('session'), makeDescriptor('gateway')],
      [],
    ))

    service.markSdkRegistered('session')
    const result = service.listNamespaces()

    expect(result[0]?.registeredBySdk).toBe(true)
    expect('registeredBySdk' in result[1]!).toBe(false)
  })

  it('annotates the marked composition by row id and leaves unmarked rows clean', () => {
    const ctx = makeContext()
    const service = createDshSettingsPlusService(ctx, makeCrawler(
      [],
      [makeComposition('llm-deepseek'), makeComposition('jobs')],
    ))

    service.markSdkRegistered('jobs')
    const result = service.listCompositionConfigs()

    expect(result[0]?.registeredBySdk).toBeUndefined()
    expect(result[1]?.registeredBySdk).toBe(true)
    expect('registeredBySdk' in result[0]!).toBe(false)
  })

  it('never mutates the crawler objects (annotation is a copy)', () => {
    const ctx = makeContext()
    const namespaces = [makeDescriptor('session')]
    const service = createDshSettingsPlusService(ctx, makeCrawler(namespaces, []))

    service.markSdkRegistered('session')
    service.listNamespaces()

    expect('registeredBySdk' in namespaces[0]!).toBe(false)
  })

  it('unmarked lists pass through without added fields', () => {
    const ctx = makeContext()
    const service = createDshSettingsPlusService(ctx, makeCrawler(
      [makeDescriptor('session')],
      [makeComposition('llm-deepseek')],
    ))

    expect('registeredBySdk' in service.listNamespaces()[0]!).toBe(false)
    expect('registeredBySdk' in service.listCompositionConfigs()[0]!).toBe(false)
  })
})

describe('settings-plus RPC handler', () => {
  it('passes the SDK marker through the listNamespaces envelope', async () => {    const ctx = makeContext()
    const service = createDshSettingsPlusService(ctx, makeCrawler(
      [makeDescriptor('session'), makeDescriptor('gateway')],
      [],
    ))
    service.markSdkRegistered('session')
    const handler = createSettingsPlusRpcHandler(service)
    const signal = new AbortController().signal

    const result = await handler('listNamespaces', null, signal)

    expect(result.ok).toBe(true)
    if (!result.ok) return
    const value = result.value as NamespaceDescriptor[]
    expect(value[0]?.registeredBySdk).toBe(true)
    expect('registeredBySdk' in value[1]!).toBe(false)
  })

  it('passes the SDK marker through the listCompositionConfigs envelope', async () => {
    const ctx = makeContext()
    const service = createDshSettingsPlusService(ctx, makeCrawler(
      [],
      [makeComposition('sandbox'), makeComposition('llm-pi-ai')],
    ))
    service.markSdkRegistered('sandbox')
    const handler = createSettingsPlusRpcHandler(service)

    const result = await handler('listCompositionConfigs', null, new AbortController().signal)

    expect(result.ok).toBe(true)
    if (!result.ok) return
    const value = result.value as CompositionConfigView[]
    expect(value[0]?.registeredBySdk).toBe(true)
    expect('registeredBySdk' in value[1]!).toBe(false)
  })

  it('registers the channel against the connection registry under the caller fiber', () => {
    const ctx = makeContext()
    const handle = vi.fn(() => () => {})
    const removeConnection = ctx.provide('connection', { rpc: { handle } })
    const service = createDshSettingsPlusService(ctx, makeCrawler([], []))

    const registered = registerSettingsPlusRpc(ctx, { service })

    expect(registered).toBe(true)
    expect(handle).toHaveBeenCalledWith(
      RPC_CHANNEL,
      expect.any(Function),
      { authority: 'loopback' },
    )
    removeConnection()
  })

  it('skips registration when no connection service is mounted', () => {
    const ctx = makeContext()
    const service = createDshSettingsPlusService(ctx, makeCrawler([], []))

    expect(registerSettingsPlusRpc(ctx, { service })).toBe(false)
  })

  it('serves the declared officialFileEntries verbatim on getOfficialFileEntries', async () => {
    const ctx = makeContext()
    const service = createDshSettingsPlusService(ctx, makeCrawler([], []))
    const handler = createSettingsPlusRpcHandler(service, ['llm-deepseek', 'approval'])

    const result = await handler('getOfficialFileEntries', null, new AbortController().signal)

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.value).toEqual(['llm-deepseek', 'approval'])
  })

  it('returns an empty list on getOfficialFileEntries when nothing is configured', async () => {
    const ctx = makeContext()
    const service = createDshSettingsPlusService(ctx, makeCrawler([], []))
    const handler = createSettingsPlusRpcHandler(service)

    const result = await handler('getOfficialFileEntries', null, new AbortController().signal)

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(result.value).toEqual([])
  })

  it('hands the options officialFileEntries to the registered handler (pass-through)', async () => {
    const ctx = makeContext()
    const handle = vi.fn<(
      channel: string,
      handler: SettingsPlusRpcHandler,
      options: { authority: 'loopback' | 'trusted-host' },
    ) => () => void>(() => () => {})
    const removeConnection = ctx.provide('connection', { rpc: { handle } })
    const service = createDshSettingsPlusService(ctx, makeCrawler([], []))

    registerSettingsPlusRpc(ctx, { service, officialFileEntries: ['permission'] })

    expect(handle).toHaveBeenCalledTimes(1)
    const registered = handle.mock.calls[0]?.[1]
    const reply = await registered?.('getOfficialFileEntries', null, new AbortController().signal)
    expect(reply).toEqual({ ok: true, value: ['permission'] })
    removeConnection()
  })
})

describe('settings-plus RPC namespace write methods', () => {
  function makeHandler(service: ReturnType<typeof createDshSettingsPlusService>) {
    const handler = createSettingsPlusRpcHandler(service)
    const signal = new AbortController().signal
    return { handler, signal }
  }

  it('passes updateNamespace through to the service with ns, patch and expectedRevision', async () => {
    const ctx = makeContext()
    const service = createDshSettingsPlusService(ctx, makeCrawler([makeDescriptor('session')], []))
    const update = vi.spyOn(service, 'updateNamespace').mockResolvedValue(undefined)
    const { handler, signal } = makeHandler(service)

    const result = await handler('updateNamespace', { ns: 'session', patch: { ttl: 1800 }, expectedRevision: 4 }, signal)

    expect(result).toEqual({ ok: true, value: undefined })
    expect(update).toHaveBeenCalledWith('session', { ttl: 1800 }, 4)
  })

  it('forwards a missing expectedRevision as undefined', async () => {
    const ctx = makeContext()
    const service = createDshSettingsPlusService(ctx, makeCrawler([makeDescriptor('session')], []))
    const update = vi.spyOn(service, 'updateNamespace').mockResolvedValue(undefined)
    const { handler, signal } = makeHandler(service)

    await handler('updateNamespace', { ns: 'session', patch: { ttl: 1800 } }, signal)

    expect(update).toHaveBeenCalledWith('session', { ttl: 1800 }, undefined)
  })

  it('rejects a malformed updateNamespace payload with bad-request', async () => {
    const ctx = makeContext()
    const service = createDshSettingsPlusService(ctx, makeCrawler([makeDescriptor('session')], []))
    const { handler, signal } = makeHandler(service)

    const result = await handler('updateNamespace', { ns: 'session' }, signal)

    expect(result).toMatchObject({ ok: false, error: { code: 'bad-request' } })
  })

  it('passes resetNamespaceField through to the service with ns, path and expectedRevision', async () => {
    const ctx = makeContext()
    const service = createDshSettingsPlusService(ctx, makeCrawler([makeDescriptor('session')], []))
    const reset = vi.spyOn(service, 'resetNamespaceField').mockResolvedValue(undefined)
    const { handler, signal } = makeHandler(service)

    const result = await handler('resetNamespaceField', { ns: 'session', path: ['ttl'], expectedRevision: 4 }, signal)

    expect(result).toEqual({ ok: true, value: undefined })
    expect(reset).toHaveBeenCalledWith('session', ['ttl'], 4)
  })

  it('rejects a malformed resetNamespaceField payload with bad-request', async () => {
    const ctx = makeContext()
    const service = createDshSettingsPlusService(ctx, makeCrawler([makeDescriptor('session')], []))
    const { handler, signal } = makeHandler(service)

    const missingPath = await handler('resetNamespaceField', { ns: 'session' }, signal)
    expect(missingPath).toMatchObject({ ok: false, error: { code: 'bad-request' } })

    const badPath = await handler('resetNamespaceField', { ns: 'session', path: 'ttl' }, signal)
    expect(badPath).toMatchObject({ ok: false, error: { code: 'bad-request' } })
  })

  it('preserves the SETTINGS_CONFLICT code through the envelope so the client can detect it', async () => {
    const ctx = makeContext()
    const service = createDshSettingsPlusService(ctx, makeCrawler([makeDescriptor('session')], []))
    vi.spyOn(service, 'updateNamespace').mockRejectedValue(
      Object.assign(new Error('settings moved'), { code: 'SETTINGS_CONFLICT' }),
    )
    const { handler, signal } = makeHandler(service)

    const result = await handler('updateNamespace', { ns: 'session', patch: {} }, signal)

    expect(result).toMatchObject({ ok: false, error: { code: 'SETTINGS_CONFLICT' } })
  })

  it('folds non-conflict service failures into internal with an issues array', async () => {
    const ctx = makeContext()
    const service = createDshSettingsPlusService(ctx, makeCrawler([makeDescriptor('session')], []))
    vi.spyOn(service, 'updateNamespace').mockRejectedValue(new Error('boom'))
    const { handler, signal } = makeHandler(service)

    const result = await handler('updateNamespace', { ns: 'session', patch: {} }, signal)

    expect(result).toMatchObject({ ok: false, error: { code: 'internal', message: 'boom', details: { issues: [] } } })
  })
})
