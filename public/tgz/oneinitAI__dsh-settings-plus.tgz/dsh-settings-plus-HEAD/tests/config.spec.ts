/**
 * Config schema and defaults: officialFileEntries defaults to `[]` (the
 * official pane stays empty until the user declares entries in cordis.yml)
 * and is configurable through both the schema and resolveConfig.
 */
import { describe, expect, it } from 'vitest'
import { Config, resolveConfig } from '../src/config.ts'

describe('config officialFileEntries', () => {
  it('defaults to an empty array when nothing is declared', () => {
    const parsed = Config({})
    expect(parsed.officialFileEntries).toEqual([])
  })

  it('carries the declared entries through the schema', () => {
    const parsed = Config({ officialFileEntries: ['llm-deepseek', 'permission'] })
    expect(parsed.officialFileEntries).toEqual(['llm-deepseek', 'permission'])
  })

  it('resolves to an empty array through resolveConfig when omitted', () => {
    expect(resolveConfig({}).officialFileEntries).toEqual([])
    expect(resolveConfig().officialFileEntries).toEqual([])
  })

  it('resolves the declared entries through resolveConfig', () => {
    expect(resolveConfig({ officialFileEntries: ['approval'] }).officialFileEntries).toEqual(['approval'])
  })

  it('rejects non-array officialFileEntries values', () => {
    const asDeclared = (value: unknown) => ({ officialFileEntries: value }) as Config
    expect(() => Config(asDeclared('llm-deepseek'))).toThrow()
    expect(() => Config(asDeclared([42]))).toThrow()
  })
})
