import { describe, expect, it, vi } from 'vitest'
import { Context } from 'cordis'
import z from 'schemastery'
import { defineSettingsSection, registerUserSettings, settingsNamespace } from '../src/sdk.ts'
import type { SettingsScopeLike } from '../src/sdk.ts'

/** A fake owner scope whose `dispose` hook records explicit removal. */
function makeScope(): SettingsScopeLike {
  return {
    get: () => ({}),
    watch: () => () => {},
    update: async () => {},
    replace: async () => {},
    dispose: vi.fn(),
  }
}

/** A fake settings seam whose `register` returns the given scope and records its arguments. */
function makeRegisterSettings(scope: SettingsScopeLike) {
  return {
    register: vi.fn(() => scope),
  }
}

describe('settings registration SDK', () => {
  it('registers through ctx.settings.register with the branded namespace, schema, and options', () => {
    const ctx = new Context()
    const scope = makeScope()
    const settings = makeRegisterSettings(scope)
    const removeSettings = ctx.provide('settings', settings)
    const GatewayConfig = z.object({
      token: z.string().role('secret'),
      host: z.string().default('localhost'),
    })
    const options = {
      base: { host: 'example.com' },
      applies: 'restart' as const,
      validate: vi.fn(),
    }

    const disposer = registerUserSettings(ctx, 'gateway', GatewayConfig, options)

    expect(settings.register).toHaveBeenCalledTimes(1)
    expect(settings.register).toHaveBeenCalledWith(settingsNamespace('gateway'), GatewayConfig, options)
    expect(typeof disposer).toBe('function')
    removeSettings()
  })

  it('forwards undefined options as-is when none are declared', () => {
    const ctx = new Context()
    const scope = makeScope()
    const settings = makeRegisterSettings(scope)
    const removeSettings = ctx.provide('settings', settings)
    const schema = z.object({ ttl: z.number().default(3600) })

    registerUserSettings(ctx, 'session', schema)

    expect(settings.register).toHaveBeenCalledWith(settingsNamespace('session'), schema, undefined)
    removeSettings()
  })

  it('returns a disposer that removes the registration when called (fake settings records the dispose)', () => {
    const ctx = new Context()
    const scope = makeScope()
    const settings = makeRegisterSettings(scope)
    const removeSettings = ctx.provide('settings', settings)

    const disposer = registerUserSettings(ctx, 'session', z.object({ ttl: z.number() }))

    expect(scope.dispose).not.toHaveBeenCalled()
    disposer()
    expect(scope.dispose).toHaveBeenCalledTimes(1)
    removeSettings()
  })

  it('wiring the disposer into ctx.effect reclaims the registration when the fiber disposes', async () => {
    const ctx = new Context()
    const scope = makeScope()
    const settings = makeRegisterSettings(scope)
    const removeSettings = ctx.provide('settings', settings)
    const schema = z.object({ ttl: z.number() })

    const fiber = await ctx.plugin({
      name: 'consumer',
      apply(c) {
        c.effect(() => registerUserSettings(c, 'session', schema))
      },
    })

    expect(settings.register).toHaveBeenCalledTimes(1)
    expect(scope.dispose).not.toHaveBeenCalled()

    await fiber.dispose()

    expect(scope.dispose).toHaveBeenCalledTimes(1)
    await removeSettings()
  })

  it('settingsNamespace brands valid lowercase kebab-case names', () => {
    for (const name of ['session', 'gateway-2', 'my-settings-ns']) {
      expect(settingsNamespace(name)).toBe(name)
    }
  })

  it.each(['Session', '-lead', '9lead', 'with space', 'ns_under', 'ns!'])(
    'settingsNamespace rejects invalid name "%s"',
    (name) => {
      expect(() => settingsNamespace(name)).toThrow(TypeError)
      expect(() => settingsNamespace(name)).toThrow(/must match/)
    },
  )

  it('defineSettingsSection returns a declarative descriptor without touching the settings seam', () => {
    const ctx = new Context()
    const settings = makeRegisterSettings(makeScope())
    const removeSettings = ctx.provide('settings', settings)
    const schema = z.object({ host: z.string().default('localhost') })

    const section = defineSettingsSection('gateway', schema, { applies: 'restart' })

    expect(section.ns).toBe(settingsNamespace('gateway'))
    expect(section.schema).toBe(schema)
    expect(section.options).toEqual({ applies: 'restart' })
    expect(settings.register).not.toHaveBeenCalled()
    removeSettings()
  })

  it('defineSettingsSection omits the options key when none are declared', () => {
    const schema = z.object({})
    const section = defineSettingsSection('gateway', schema)

    expect('options' in section).toBe(false)
    expect(section.options).toBeUndefined()
  })

  it('surfaces a duplicate namespace as a loud error from the call site (documented dedup boundary)', () => {
    const ctx = new Context()
    const seen: unknown[] = []
    const settings = {
      register: vi.fn((ns: unknown, schema: unknown, options?: unknown) => {
        if (seen.some(candidate => candidate === ns)) {
          throw new Error(`settings namespace "${String(ns)}" is already registered`)
        }
        seen.push(ns, schema, options)
        return makeScope()
      }),
    }
    const removeSettings = ctx.provide('settings', settings)
    const schema = z.object({ ttl: z.number() })

    registerUserSettings(ctx, 'session', schema)

    expect(() => registerUserSettings(ctx, 'session', schema)).toThrow(
      'settings namespace "session" is already registered',
    )
    removeSettings()
  })

  it('fails loud when the settings seam is not mounted on the context', () => {
    const ctx = new Context()

    expect(() => registerUserSettings(ctx, 'session', z.object({}))).toThrow(
      /requires the "settings" service/,
    )
  })

  it('marks the namespace as SDK-registered through the dshSettingsPlus service when mounted', async () => {
    const ctx = new Context()
    const scope = makeScope()
    const settings = makeRegisterSettings(scope)
    const removeSettings = ctx.provide('settings', settings)
    const service = {
      listNamespaces: () => [],
      listCompositionConfigs: () => [],
      updateComposition: async () => {},
      removeComposition: async () => {},
      markSdkRegistered: vi.fn(),
    }
    const removeService = ctx.provide('dshSettingsPlus', service)

    registerUserSettings(ctx, 'gateway', z.object({ host: z.string() }))

    // The mark is deferred to a microtask so it lands after the fiber tree
    // settles (Cordis `ctx.get` only resolves activated-fiber services).
    await Promise.resolve()
    await Promise.resolve()

    expect(settings.register).toHaveBeenCalledTimes(1)
    expect(service.markSdkRegistered).toHaveBeenCalledTimes(1)
    expect(service.markSdkRegistered).toHaveBeenCalledWith(settingsNamespace('gateway'))
    removeService()
    removeSettings()
  })

  it('marks only after a successful registration (a rejected duplicate never reaches the mark)', () => {
    const ctx = new Context()
    const settings = {
      register: vi.fn(() => {
        throw new Error('settings namespace "session" is already registered')
      }),
    }
    const removeSettings = ctx.provide('settings', settings)
    const service = { markSdkRegistered: vi.fn() }
    const removeService = ctx.provide('dshSettingsPlus', service)
    const schema = z.object({ ttl: z.number() })

    expect(() => registerUserSettings(ctx, 'session', schema)).toThrow('already registered')
    expect(service.markSdkRegistered).not.toHaveBeenCalled()
    removeService()
    removeSettings()
  })

  it('silently skips the SDK mark when the dshSettingsPlus service is absent (SDK stays independent)', () => {
    const ctx = new Context()
    const scope = makeScope()
    const settings = makeRegisterSettings(scope)
    const removeSettings = ctx.provide('settings', settings)
    const schema = z.object({ ttl: z.number() })

    expect(() => registerUserSettings(ctx, 'session', schema)).not.toThrow()
    expect(settings.register).toHaveBeenCalledTimes(1)
    removeSettings()
  })

  it('keeps the disposer contract when the mark path is active', () => {
    const ctx = new Context()
    const scope = makeScope()
    const settings = makeRegisterSettings(scope)
    const removeSettings = ctx.provide('settings', settings)
    const service = { markSdkRegistered: vi.fn() }
    const removeService = ctx.provide('dshSettingsPlus', service)

    const disposer = registerUserSettings(ctx, 'gateway', z.object({ host: z.string() }))
    disposer()

    expect(scope.dispose).toHaveBeenCalledTimes(1)
    removeService()
    removeSettings()
  })
})
