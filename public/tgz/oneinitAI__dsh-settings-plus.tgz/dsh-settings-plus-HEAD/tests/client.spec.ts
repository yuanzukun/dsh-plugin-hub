// @vitest-environment jsdom
/**
 * Client settings.section registration: the two-pane display — official
 * pane (order 30, config-declared file-only entries) and plugin pane
 * (order 31, strictly SDK-registered entries) — plus the entry, deferral,
 * signature diffing, locale, pane rendering, and teardown.
 */
import { Context } from 'cordis'
import { act } from 'react'
import type { ReactNode } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeAll, describe, expect, it, vi } from 'vitest'
import { apply, inject } from '../src/client/index.ts'
import type { SettingsPlusInjected, SettingsPlusSectionProps } from '../src/client/component.tsx'
import type { CatalogSource, SettingsCatalogState, SettingsSectionEntry } from '../src/client/catalog.ts'
import { en, NS, SettingsKey, zh } from '../src/client/locales.ts'
import {
  createControllableSource, FakeLocale, FakeSlots, resolveLabel, entries,
  type SectionRegistration,
} from './client-harness.ts'

const SEAT = 'settings.section'
const ENTRY_ID = 'dsh-settings-plus'
const OFFICIAL_PANE_ID = 'dsh-settings-plus-official'
const PLUGINS_PANE_ID = 'dsh-settings-plus-plugins'

function entry(key: string, label: string): SettingsSectionEntry {
  return { key, label }
}

/** Read the injected business face a registration carries. */
function injectedOf(record: SectionRegistration | undefined): SettingsPlusInjected {
  return record?.options.inject?.() as unknown as SettingsPlusInjected
}

const t = (key: string): string => (zh as Record<string, string>)[key] ?? key

/** Mount the client apply over a real cordis Context with fake host services. */
async function bench(options: { source?: CatalogSource; declareSlot?: boolean } = {}) {
  const ctx = new Context()
  const slots = new FakeSlots()
  const locale = new FakeLocale()
  const removeSlots = ctx.provide('slots', slots)
  const removeLocale = ctx.provide('locale', locale)
  ctx.provide('connection', { api: {} })
  ctx.provide('remote', {})
  if (options.source !== undefined) ctx.provide('settingsPlusCatalog', options.source)
  if (options.declareSlot !== false) slots.declare(SEAT)
  const fiber = ctx.plugin({ inject: [...inject], apply })
  await fiber.await()
  return {
    ctx,
    slots,
    locale,
    fiber,
    async dispose(): Promise<void> {
      try {
        await fiber.dispose()
      } finally {
        removeSlots()
        removeLocale()
      }
    },
  }
}

// --- Pane rendering benches (jsdom + react-dom/client) ---

const mountedRoots: Array<{ root: Root; container: HTMLElement }> = []

beforeAll(() => {
  ;(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
})

afterEach(async () => {
  while (mountedRoots.length > 0) {
    const mounted = mountedRoots.pop()!
    await act(async () => { mounted.root.unmount() })
    mounted.container.remove()
  }
})

/** Render one pane registration and return its container. */
async function renderPane(record: SectionRegistration | undefined): Promise<HTMLElement> {
  const container = document.createElement('div')
  document.body.appendChild(container)
  const root = createRoot(container)
  const injected = injectedOf(record)
  const state = injected.hooks.catalog
  const component = record?.component as unknown as (props: SettingsPlusSectionProps) => ReactNode
  const props: SettingsPlusSectionProps = {
    close: () => {},
    useCatalog: <S,>(selector: (snapshot: SettingsCatalogState) => S): S => selector(state.getSnapshot()),
    reload: injected.reload,
    t: t as (key: SettingsKey, params?: Record<string, unknown>) => string,
  }
  await act(async () => { root.render(component(props)) })
  mountedRoots.push({ root, container })
  return container
}

describe('dsh-settings-plus client apply', () => {
  it('declares the required services', () => {
    expect(inject).toEqual(['slots', 'locale', 'connection', 'remote'])
  })

  it('registers the dictionaries under the dsh-settings-plus namespace', async () => {
    const b = await bench()
    expect(b.locale.register).toHaveBeenCalledWith(NS, { zh, en })
    await b.dispose()
  })

  it('registers the entry (order 30), the official pane (order 30), and the plugin pane (order 31)', async () => {
    const source = createControllableSource()
    const b = await bench({ source: source.source })

    expect(b.slots.injectSpy).toHaveBeenCalledWith(SEAT, expect.any(Function))
    const entryRecord = b.slots.liveById(ENTRY_ID)
    const officialRecord = b.slots.liveById(OFFICIAL_PANE_ID)
    const pluginsRecord = b.slots.liveById(PLUGINS_PANE_ID)
    expect(entryRecord?.options).toMatchObject({
      name: SEAT,
      id: ENTRY_ID,
      order: 30,
      locale: NS,
    })
    expect(resolveLabel(entryRecord)).toBe('高级设置')
    expect(officialRecord?.options).toMatchObject({
      name: SEAT,
      id: OFFICIAL_PANE_ID,
      order: 30,
      locale: NS,
    })
    expect(resolveLabel(officialRecord)).toBe('官方设置')
    expect(pluginsRecord?.options).toMatchObject({
      name: SEAT,
      id: PLUGINS_PANE_ID,
      order: 31,
      locale: NS,
    })
    expect(resolveLabel(pluginsRecord)).toBe('插件设置')
    await b.dispose()
  })

  it('defers every registration until the settings.section slot is declared', async () => {
    const source = createControllableSource()
    const b = await bench({ source: source.source, declareSlot: false })
    expect(b.slots.injectSpy).toHaveBeenCalledWith(SEAT, expect.any(Function))
    expect(b.slots.registrations).toHaveLength(0)

    b.slots.declare(SEAT)
    expect(b.slots.liveById(ENTRY_ID)).toBeDefined()
    expect(b.slots.liveById(OFFICIAL_PANE_ID)).toBeDefined()
    expect(b.slots.liveById(PLUGINS_PANE_ID)).toBeDefined()
    await b.dispose()
  })

  it('renders the loading copy in both panes before the catalog settles', async () => {
    const source = createControllableSource()
    const b = await bench({ source: source.source })

    expect((await renderPane(b.slots.liveById(OFFICIAL_PANE_ID))).textContent).toContain('正在加载设置……')
    expect((await renderPane(b.slots.liveById(PLUGINS_PANE_ID))).textContent).toContain('正在加载设置……')
    await b.dispose()
  })

  it('renders the official pane entries and the plugin pane entries from their own pane lists', async () => {
    const source = createControllableSource()
    const b = await bench({ source: source.source })
    source.settle({
      officialEntries: entries([['llm-deepseek', 'llm-deepseek'], ['approval', 'approval']]),
      pluginEntries: entries([['third-party-app', 'third-party-app'], ['sandbox', 'sandbox']]),
    })
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(OFFICIAL_PANE_ID)).hooks.catalog.getSnapshot().status).toBe('ready')
    })

    const official = await renderPane(b.slots.liveById(OFFICIAL_PANE_ID))
    expect(official.querySelectorAll('.dsh_settingsPlus_pane_item')).toHaveLength(2)
    expect(official.textContent).toContain('llm-deepseek')
    expect(official.textContent).toContain('approval')
    expect(official.textContent).not.toContain('third-party-app')

    const plugins = await renderPane(b.slots.liveById(PLUGINS_PANE_ID))
    expect(plugins.querySelectorAll('.dsh_settingsPlus_pane_item')).toHaveLength(2)
    expect(plugins.textContent).toContain('third-party-app')
    expect(plugins.textContent).toContain('sandbox')
    expect(plugins.textContent).not.toContain('llm-deepseek')

    const snapshot = injectedOf(b.slots.liveById(PLUGINS_PANE_ID)).hooks.catalog.getSnapshot()
    expect(snapshot.pluginEntries.map(candidate => candidate.key)).toEqual(['third-party-app', 'sandbox'])
    expect(snapshot.officialEntries.map(candidate => candidate.key)).toEqual(['llm-deepseek', 'approval'])
    expect(typeof injectedOf(b.slots.liveById(PLUGINS_PANE_ID)).reload).toBe('function')
    await b.dispose()
  })

  it('renders each pane its own empty copy when that pane has no data', async () => {
    const source = createControllableSource()
    const b = await bench({ source: source.source })
    source.settle({
      officialEntries: [],
      pluginEntries: [entry('third-party-app', 'third-party-app')],
    })
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(OFFICIAL_PANE_ID)).hooks.catalog.getSnapshot().status).toBe('ready')
    })

    const official = await renderPane(b.slots.liveById(OFFICIAL_PANE_ID))
    expect(official.textContent).toContain('未配置官方文件设置项')
    const plugins = await renderPane(b.slots.liveById(PLUGINS_PANE_ID))
    expect(plugins.textContent).toContain('third-party-app')
    expect(plugins.textContent).not.toContain('未配置官方文件设置项')
    await b.dispose()
  })

  it('surfaces an initial failure in both panes and recovers on retry', async () => {
    const source = createControllableSource()
    const b = await bench({ source: source.source })
    source.fail(new Error('offline'))
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(OFFICIAL_PANE_ID)).hooks.catalog.getSnapshot().status).toBe('error')
    })

    const official = await renderPane(b.slots.liveById(OFFICIAL_PANE_ID))
    expect(official.textContent).toContain('加载设置失败')
    expect(official.textContent).toContain('offline')
    expect(official.querySelector('.dsh_settingsPlus_retry')).not.toBeNull()

    void injectedOf(b.slots.liveById(OFFICIAL_PANE_ID)).reload()
    expect(source.load).toHaveBeenCalledTimes(2)
    source.settle({ officialEntries: [entry('approval', 'approval')] })
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(OFFICIAL_PANE_ID)).hooks.catalog.getSnapshot().status).toBe('ready')
    })
    const recovered = await renderPane(b.slots.liveById(OFFICIAL_PANE_ID))
    expect(recovered.textContent).toContain('approval')
    await b.dispose()
  })

  it('keeps stale entries visible when a refresh fails', async () => {
    const source = createControllableSource()
    const b = await bench({ source: source.source })
    source.settle({ pluginEntries: [entry('alpha', 'Alpha')] })
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(PLUGINS_PANE_ID)).hooks.catalog.getSnapshot().status).toBe('ready')
    })

    b.ctx.emit('connection/reset')
    source.fail(new Error('refresh failed'))
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(PLUGINS_PANE_ID)).hooks.catalog.getSnapshot().status).toBe('error')
    })
    expect(injectedOf(b.slots.liveById(PLUGINS_PANE_ID)).hooks.catalog.getSnapshot().pluginEntries)
      .toEqual([{ key: 'alpha', label: 'Alpha' }])
    const plugins = await renderPane(b.slots.liveById(PLUGINS_PANE_ID))
    expect(plugins.textContent).toContain('alpha')
    await b.dispose()
  })

  it('reuses the standing registrations across catalog refreshes (fixed signatures)', async () => {
    const source = createControllableSource()
    const b = await bench({ source: source.source })
    source.settle({ pluginEntries: [entry('alpha', 'Alpha')] })
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(PLUGINS_PANE_ID)).hooks.catalog.getSnapshot().status).toBe('ready')
    })
    const entryRecord = b.slots.liveById(ENTRY_ID)
    const officialRecord = b.slots.liveById(OFFICIAL_PANE_ID)
    const pluginsRecord = b.slots.liveById(PLUGINS_PANE_ID)

    b.ctx.emit('connection/reset')
    expect(source.load).toHaveBeenCalledTimes(2)
    source.settle({ pluginEntries: [entry('alpha', 'Alpha'), entry('beta', 'Beta')] })
    await vi.waitFor(() => {
      expect(injectedOf(b.slots.liveById(PLUGINS_PANE_ID)).hooks.catalog.getSnapshot().pluginEntries).toHaveLength(2)
    })
    expect(b.slots.liveById(ENTRY_ID)).toBe(entryRecord)
    expect(b.slots.liveById(OFFICIAL_PANE_ID)).toBe(officialRecord)
    expect(b.slots.liveById(PLUGINS_PANE_ID)).toBe(pluginsRecord)
    expect(pluginsRecord?.disposed).toBe(false)
    await b.dispose()
  })

  it('pane labels follow the active locale without re-registration', async () => {
    const source = createControllableSource()
    const b = await bench({ source: source.source })
    const officialBefore = b.slots.liveById(OFFICIAL_PANE_ID)
    const pluginsBefore = b.slots.liveById(PLUGINS_PANE_ID)

    b.locale.setLang('en')
    expect(resolveLabel(b.slots.liveById(OFFICIAL_PANE_ID))).toBe('Official settings')
    expect(resolveLabel(b.slots.liveById(PLUGINS_PANE_ID))).toBe('Plugin settings')
    expect(b.slots.liveById(OFFICIAL_PANE_ID)).toBe(officialBefore)
    expect(b.slots.liveById(PLUGINS_PANE_ID)).toBe(pluginsBefore)
    await b.dispose()
  })

  it('removes every live registration and the dictionaries with the owning fiber', async () => {
    const source = createControllableSource()
    const b = await bench({ source: source.source })
    expect(b.slots.live().length).toBeGreaterThan(0)

    await b.fiber.dispose()
    expect(b.slots.live()).toHaveLength(0)
    expect(b.locale.bind(NS)('nav')).toBe(`${NS}.nav`)
  })
})
