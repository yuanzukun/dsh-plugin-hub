import { describe, expect, it, vi } from 'vitest'
import { Context } from 'cordis'
import * as plugin from '../src/index.ts'
import { createCrawler } from '../src/crawler.ts'
import type { CompositionRuntimeLike, NamespaceDescriptor } from '../src/crawler.ts'
import { createDshSettingsPlusService } from '../src/service.ts'
import type { DshSettingsPlusService } from '../src/service.ts'
import { makeFakeSettings } from './harness.ts'

function makeDescriptor(ns: string, revision = 1): NamespaceDescriptor {
  return { ns, schema: {}, value: {}, revision, applies: 'live' }
}

/** Mount the plugin on a bare context with a fake settings seam. */
async function mountPlugin(settings = makeFakeSettings()) {
  const ctx = new Context()
  const removeSettings = ctx.provide('settings', settings)
  const fiber = await ctx.plugin(plugin)
  return { ctx, fiber, settings, removeSettings }
}

describe('dshSettingsPlus service', () => {
  it('provides ctx.dshSettingsPlus with reads delegated to the crawler', async () => {
    const descriptor = makeDescriptor('session', 5)
    const settings = makeFakeSettings([descriptor])
    const { ctx, fiber, removeSettings } = await mountPlugin(settings)

    const service = ctx.get('dshSettingsPlus') as DshSettingsPlusService
    expect(service).toBeDefined()
    expect(service.listNamespaces()).toEqual([descriptor])
    expect(settings.describe).toHaveBeenCalledWith({ redactSecrets: true })

    await fiber.dispose()
    await removeSettings()
  })

  it('stays inactive without the settings service and activates once it appears', async () => {
    const ctx = new Context()
    const fiber = await ctx.plugin(plugin)
    expect(ctx.get('dshSettingsPlus')).toBeUndefined()

    const settings = makeFakeSettings()
    const removeSettings = ctx.provide('settings', settings)
    await vi.waitFor(() => {
      expect(ctx.get('dshSettingsPlus')).toBeDefined()
    })

    await fiber.dispose()
    await removeSettings()
  })

  it('routes updateComposition through the settings seam with expectedRevision', async () => {
    const descriptor = makeDescriptor('session', 5)
    const settings = makeFakeSettings([descriptor])
    const { ctx, fiber, removeSettings } = await mountPlugin(settings)

    const service = ctx.get('dshSettingsPlus') as DshSettingsPlusService
    await service.updateComposition('session', { ttl: 1800 })

    expect(settings.update).toHaveBeenCalledTimes(1)
    expect(settings.update.mock.calls[0]).toEqual(['session', { ttl: 1800 }, 5])

    await fiber.dispose()
    await removeSettings()
  })

  it('removes the provided service when the plugin unloads', async () => {
    const settings = makeFakeSettings()
    const { ctx, fiber, removeSettings } = await mountPlugin(settings)
    expect(ctx.get('dshSettingsPlus')).toBeDefined()

    await fiber.dispose()
    expect(ctx.get('dshSettingsPlus')).toBeUndefined()
    await removeSettings()
  })
})

describe('createDshSettingsPlusService', () => {
  it('merges the patch over the composition view value for settings namespaces', async () => {
    const descriptor = makeDescriptor('session', 7)
    const settings = makeFakeSettings([descriptor])
    const ctx = new Context()
    const removeSettings = ctx.provide('settings', settings)
    const row: CompositionRuntimeLike = {
      name: 'dsh-session',
      Config: { toJSON: () => ({ type: 'object' }) },
      fibers: [{ config: { ttl: 3600, mode: 'strict' }, entry: { options: { id: 'session' } } }],
    }
    const crawler = createCrawler(ctx, { registryProvider: () => [[row.name, row] as const] })
    const service = createDshSettingsPlusService(ctx, crawler)

    await service.updateComposition('session', { ttl: 1800 })

    expect(settings.update).toHaveBeenCalledWith('session', { ttl: 1800, mode: 'strict' }, 7)
    await removeSettings()
  })

  it('rejects plain cordis.yml composition rows with an explicit error', async () => {
    const settings = makeFakeSettings()
    const ctx = new Context()
    const removeSettings = ctx.provide('settings', settings)
    const row: CompositionRuntimeLike = {
      name: 'plugin-llm',
      Config: { toJSON: () => ({ type: 'object' }) },
      fibers: [{ config: {}, entry: { options: { id: 'llm-main' } } }],
    }
    const crawler = createCrawler(ctx, { registryProvider: () => [[row.name, row] as const] })
    const service = createDshSettingsPlusService(ctx, crawler)

    await expect(service.updateComposition('llm-main', { model: 'deepseek-chat' }))
      .rejects.toThrow('cordis.yml')
    expect(settings.update).not.toHaveBeenCalled()
    await removeSettings()
  })

  it('rejects unknown composition ids', async () => {
    const settings = makeFakeSettings()
    const ctx = new Context()
    const removeSettings = ctx.provide('settings', settings)
    const crawler = createCrawler(ctx, { registryProvider: () => [] })
    const service = createDshSettingsPlusService(ctx, crawler)

    await expect(service.updateComposition('missing', {})).rejects.toThrow(/unknown composition id "missing"/)
    expect(settings.update).not.toHaveBeenCalled()
    await removeSettings()
  })

  it('expresses removeComposition for settings namespaces through the update path with a null user section', async () => {
    const descriptor = makeDescriptor('gateway', 3)
    const settings = makeFakeSettings([descriptor])
    const ctx = new Context()
    const removeSettings = ctx.provide('settings', settings)
    const crawler = createCrawler(ctx, { registryProvider: () => [] })
    const service = createDshSettingsPlusService(ctx, crawler)

    await service.removeComposition('gateway')

    expect(settings.update).toHaveBeenCalledWith('gateway', null, 3)
    await removeSettings()
  })

  it('rejects removal of plain cordis.yml rows', async () => {
    const settings = makeFakeSettings()
    const ctx = new Context()
    const removeSettings = ctx.provide('settings', settings)
    const row: CompositionRuntimeLike = {
      name: 'plugin-llm',
      Config: { toJSON: () => ({ type: 'object' }) },
      fibers: [{ config: {}, entry: { options: { id: 'llm-main' } } }],
    }
    const crawler = createCrawler(ctx, { registryProvider: () => [[row.name, row] as const] })
    const service = createDshSettingsPlusService(ctx, crawler)

    await expect(service.removeComposition('llm-main')).rejects.toThrow('cordis.yml')
    expect(settings.update).not.toHaveBeenCalled()
    await removeSettings()
  })

  it('fails loud when the mounted settings seam lacks an update method', () => {
    const ctx = new Context()
    const removeSettings = ctx.provide('settings', { describe: () => [] })
    const crawler = createCrawler(ctx, { registryProvider: () => [] })

    expect(() => createDshSettingsPlusService(ctx, crawler)).toThrow('update')
    void removeSettings()
  })
})

describe('createDshSettingsPlusService namespace write methods', () => {
  it('updateNamespace forwards the client expectedRevision through the settings seam', async () => {
    const descriptor = makeDescriptor('session', 5)
    const settings = makeFakeSettings([descriptor])
    const ctx = new Context()
    const removeSettings = ctx.provide('settings', settings)
    const crawler = createCrawler(ctx, { registryProvider: () => [] })
    const service = createDshSettingsPlusService(ctx, crawler)

    await service.updateNamespace('session', { ttl: 1800 }, 3)

    expect(settings.update).toHaveBeenCalledWith('session', { ttl: 1800 }, 3)
    await removeSettings()
  })

  it('updateNamespace falls back to the descriptor revision without an explicit one', async () => {
    const descriptor = makeDescriptor('session', 5)
    const settings = makeFakeSettings([descriptor])
    const ctx = new Context()
    const removeSettings = ctx.provide('settings', settings)
    const crawler = createCrawler(ctx, { registryProvider: () => [] })
    const service = createDshSettingsPlusService(ctx, crawler)

    await service.updateNamespace('session', { ttl: 1800 })

    expect(settings.update).toHaveBeenCalledWith('session', { ttl: 1800 }, 5)
    await removeSettings()
  })

  it('updateNamespace deep-merges nested patches over the composition view value', async () => {
    const descriptor = makeDescriptor('session', 5)
    const settings = makeFakeSettings([descriptor])
    const ctx = new Context()
    const removeSettings = ctx.provide('settings', settings)
    const row: CompositionRuntimeLike = {
      name: 'dsh-session',
      Config: { toJSON: () => ({ type: 'object' }) },
      fibers: [{ config: { a: { b: 1, c: 2 }, ttl: 3600 }, entry: { options: { id: 'session' } } }],
    }
    const crawler = createCrawler(ctx, { registryProvider: () => [[row.name, row] as const] })
    const service = createDshSettingsPlusService(ctx, crawler)

    await service.updateNamespace('session', { a: { b: 9 } }, 3)

    expect(settings.update).toHaveBeenCalledWith('session', { a: { b: 9, c: 2 }, ttl: 3600 }, 3)
    await removeSettings()
  })

  it('resetNamespaceField builds a value-less nested unset patch', async () => {
    const descriptor = makeDescriptor('session', 5)
    const settings = makeFakeSettings([descriptor])
    const ctx = new Context()
    const removeSettings = ctx.provide('settings', settings)
    const crawler = createCrawler(ctx, { registryProvider: () => [] })
    const service = createDshSettingsPlusService(ctx, crawler)

    await service.resetNamespaceField('session', ['ttl'], 3)

    expect(settings.update).toHaveBeenCalledWith('session', { ttl: undefined }, 3)
    await removeSettings()
  })

  it('resetNamespaceField unsets a nested path as a nested undefined patch', async () => {
    const descriptor = makeDescriptor('session', 5)
    const settings = makeFakeSettings([descriptor])
    const ctx = new Context()
    const removeSettings = ctx.provide('settings', settings)
    const crawler = createCrawler(ctx, { registryProvider: () => [] })
    const service = createDshSettingsPlusService(ctx, crawler)

    await service.resetNamespaceField('session', ['a', 'b'], 3)

    expect(settings.update).toHaveBeenCalledWith('session', { a: { b: undefined } }, 3)
    await removeSettings()
  })

  it('updateNamespace rejects plain cordis.yml rows like updateComposition', async () => {
    const settings = makeFakeSettings()
    const ctx = new Context()
    const removeSettings = ctx.provide('settings', settings)
    const row: CompositionRuntimeLike = {
      name: 'plugin-llm',
      Config: { toJSON: () => ({ type: 'object' }) },
      fibers: [{ config: {}, entry: { options: { id: 'llm-main' } } }],
    }
    const crawler = createCrawler(ctx, { registryProvider: () => [[row.name, row] as const] })
    const service = createDshSettingsPlusService(ctx, crawler)

    await expect(service.updateNamespace('llm-main', { model: 'deepseek-chat' }))
      .rejects.toThrow('cordis.yml')
    expect(settings.update).not.toHaveBeenCalled()
    await removeSettings()
  })

  it('resetNamespaceField rejects unknown ids', async () => {
    const settings = makeFakeSettings()
    const ctx = new Context()
    const removeSettings = ctx.provide('settings', settings)
    const crawler = createCrawler(ctx, { registryProvider: () => [] })
    const service = createDshSettingsPlusService(ctx, crawler)

    await expect(service.resetNamespaceField('missing', ['a'], 1))
      .rejects.toThrow(/unknown composition id "missing"/)
    expect(settings.update).not.toHaveBeenCalled()
    await removeSettings()
  })
})
