import { afterEach, describe, expect, it } from 'vitest'
import { mkdirSync, mkdtempSync, realpathSync, rmSync, writeFileSync } from 'node:fs'
import { homedir, tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { isWritableTarget, listConfigFiles, resolveDshHome, resolveInside } from '../src/file-browser.ts'

/** Temp directories created by fixtures, removed after each test. */
const tempDirs: string[] = []

function createTempHome(): string {
  const home = mkdtempSync(join(tmpdir(), 'dsh-settings-plus-'))
  tempDirs.push(home)
  return home
}

afterEach(() => {
  while (tempDirs.length > 0) {
    const dir = tempDirs.pop()
    if (dir !== undefined) rmSync(dir, { recursive: true, force: true })
  }
})

/** Restore the ambient $DSH_HOME after a test mutated it. */
function restoreDshHome(previous: string | undefined): void {
  if (previous === undefined) delete process.env.DSH_HOME
  else process.env.DSH_HOME = previous
}

describe('resolveDshHome', () => {
  it('prefers an explicit configHome over $DSH_HOME', () => {
    const explicit = join(createTempHome(), 'explicit')
    const previous = process.env.DSH_HOME
    process.env.DSH_HOME = join(createTempHome(), 'env')
    try {
      expect(resolveDshHome(explicit)).toBe(resolve(explicit))
    } finally {
      restoreDshHome(previous)
    }
  })

  it('falls back to $DSH_HOME when configHome is empty', () => {
    const fromEnv = join(createTempHome(), 'env')
    const previous = process.env.DSH_HOME
    process.env.DSH_HOME = fromEnv
    try {
      expect(resolveDshHome('')).toBe(resolve(fromEnv))
    } finally {
      restoreDshHome(previous)
    }
  })

  it('falls back to the home .dsh directory when neither is set', () => {
    const previous = process.env.DSH_HOME
    delete process.env.DSH_HOME
    try {
      expect(resolveDshHome('')).toBe(join(homedir(), '.dsh'))
    } finally {
      restoreDshHome(previous)
    }
  })
})

describe('listConfigFiles', () => {
  it('enumerates writable home-root yaml files and per-profile cordis patches', () => {
    const home = createTempHome()
    mkdirSync(join(home, 'profiles', 'web'), { recursive: true })
    writeFileSync(join(home, 'settings.yaml'), 'a: 1\n')
    writeFileSync(join(home, 'cordis.patch.yml'), 'a: 1\n')
    writeFileSync(join(home, 'notes.yml'), 'x: 1\n')
    writeFileSync(join(home, 'profiles', 'web', 'cordis.patch.yml'), 'a: 1\n')
    writeFileSync(join(home, 'profiles', 'web', 'cordis.extra.yaml'), 'a: 1\n')
    // non-manifest noise must stay absent
    writeFileSync(join(home, '.env'), 'SECRET=1\n')
    writeFileSync(join(home, 'readme.txt'), 'ignored\n')
    writeFileSync(join(home, 'profiles', 'web', 'settings.json'), '{}\n')

    const entries = listConfigFiles(home)
    const byRelative = new Map(entries.map(entry => [entry.relative, entry]))

    expect(entries).toHaveLength(5)
    expect(byRelative.get('settings.yaml')).toMatchObject({ scope: 'home', writable: true, kind: 'settings' })
    expect(byRelative.get('cordis.patch.yml')).toMatchObject({ scope: 'home', writable: true, kind: 'cordis-patch' })
    expect(byRelative.get('notes.yml')).toMatchObject({ scope: 'home', writable: true, kind: 'yaml' })
    expect(byRelative.get('profiles/web/cordis.patch.yml')).toMatchObject({
      scope: 'profile',
      writable: true,
      kind: 'cordis-patch',
    })
    expect(byRelative.get('profiles/web/cordis.extra.yaml')).toMatchObject({
      scope: 'profile',
      writable: true,
      kind: 'cordis-patch',
    })
    for (const entry of entries) {
      expect(entry.path).toBe(resolve(home, entry.relative))
    }
  })

  it('lists read-only bundle layers declared by profile dsh.profile.bundles', () => {
    const home = createTempHome()
    const bundleDir = join(home, 'profiles', 'web', 'node_modules', '@deepseek-ai', 'dsh-settings-plus')
    mkdirSync(bundleDir, { recursive: true })
    writeFileSync(join(home, 'profiles', 'web', 'package.json'), JSON.stringify({
      name: 'web-profile',
      dsh: { profile: { bundles: ['@deepseek-ai/dsh-settings-plus', 'declared-but-missing'] } },
    }))
    writeFileSync(join(bundleDir, 'cordis.patch.yml'), 'x: 1\n')

    const entries = listConfigFiles(home)
    const bundle = entries.find(
      entry => entry.relative === 'profiles/web/node_modules/@deepseek-ai/dsh-settings-plus/cordis.patch.yml',
    )

    expect(bundle).toBeDefined()
    expect(bundle).toMatchObject({ scope: 'profile', writable: false, kind: 'cordis-patch' })
    expect(entries.filter(entry => !entry.writable)).toHaveLength(1)
  })

  it('reads empty when the home directory does not exist', () => {
    const missing = join(createTempHome(), 'no-such-home')
    expect(listConfigFiles(missing)).toEqual([])
  })
})

describe('resolveInside', () => {
  it('resolves a candidate inside the root to its realpath', () => {
    const home = realpathSync(createTempHome())
    writeFileSync(join(home, 'a.yml'), 'a: 1\n')
    expect(resolveInside(home, join(home, 'a.yml'))).toBe(join(home, 'a.yml'))
  })

  it('returns null for candidates escaping the root via parent traversal', () => {
    const home = realpathSync(createTempHome())
    writeFileSync(join(home, 'a.yml'), 'a: 1\n')
    expect(resolveInside(home, join(home, '..', 'escape.yml'))).toBeNull()
  })

  it('returns null for absolute candidates outside the root', () => {
    const home = realpathSync(createTempHome())
    writeFileSync(join(home, 'a.yml'), 'a: 1\n')
    expect(resolveInside(home, join(home, '..', '..', 'outside.yml'))).toBeNull()
  })

  it('returns the root itself when the candidate equals the root', () => {
    const home = realpathSync(createTempHome())
    expect(resolveInside(home, home)).toBe(home)
  })

  it('resolves not-yet-existing candidates through their existing parent', () => {
    const home = realpathSync(createTempHome())
    const target = join(home, 'future', 'new.yml')
    expect(resolveInside(home, target)).toBe(join(home, 'future', 'new.yml'))
  })
})

describe('isWritableTarget', () => {
  it('accepts files on the writable manifest', () => {
    const home = createTempHome()
    mkdirSync(join(home, 'profiles', 'web'), { recursive: true })
    writeFileSync(join(home, 'cordis.patch.yml'), 'a: 1\n')
    writeFileSync(join(home, 'profiles', 'web', 'cordis.patch.yml'), 'a: 1\n')

    expect(isWritableTarget(home, join(home, 'cordis.patch.yml'))).toBe(true)
    expect(isWritableTarget(home, join(home, 'profiles', 'web', 'cordis.patch.yml'))).toBe(true)
  })

  it('rejects files outside the writable manifest', () => {
    const home = createTempHome()
    writeFileSync(join(home, '.env'), 'SECRET=1\n')
    writeFileSync(join(home, 'notes.txt'), 'nope\n')

    expect(isWritableTarget(home, join(home, '.env'))).toBe(false)
    expect(isWritableTarget(home, join(home, 'notes.txt'))).toBe(false)
    expect(isWritableTarget(home, join(home, '..', 'other.yml'))).toBe(false)
    expect(isWritableTarget(home, join(home, 'does-not-exist.yml'))).toBe(false)
  })

  it('rejects read-only bundle layers even though they are cordis patches', () => {
    const home = createTempHome()
    const bundleDir = join(home, 'profiles', 'web', 'node_modules', '@deepseek-ai', 'dsh-settings-plus')
    mkdirSync(bundleDir, { recursive: true })
    writeFileSync(join(home, 'profiles', 'web', 'package.json'), JSON.stringify({
      dsh: { profile: { bundles: ['@deepseek-ai/dsh-settings-plus'] } },
    }))
    writeFileSync(join(bundleDir, 'cordis.patch.yml'), 'x: 1\n')

    expect(isWritableTarget(home, join(bundleDir, 'cordis.patch.yml'))).toBe(false)
  })
})
