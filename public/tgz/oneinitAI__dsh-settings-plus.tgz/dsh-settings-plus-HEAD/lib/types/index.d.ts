/**
 * Standalone function plugin for DeepSeek Harness.
 * @module @deepseek-ai/dsh-settings-plus
 */
/** Cordis plugin name; keep this stable after publishing. */
export declare const name = "dsh-settings-plus";
/**
 * Services that must exist before the plugin is applied. `settings` is the
 * host settings seam this bundle reads and writes through; optional host
 * services (like the fabric compat facade) are probed at use sites instead
 * of being declared here.
 */
export declare const inject: string[];
export { Config } from './config.ts';
export type { ResolvedConfig } from './config.ts';
export { apply } from './runtime.ts';
export type { PluginRuntime } from './runtime.ts';
export * from './crawler.ts';
export * from './fabric.ts';
export * from './rpc.ts';
export * from './service.ts';
//# sourceMappingURL=index.d.ts.map