/**
 * Host service surface: the `dshSettingsPlus` service this bundle publishes
 * on the host context. Reads delegate to the crawler's redacted snapshots;
 * writes route through the host `settings` seam.
 *
 * Write boundary, stated honestly: the crawler is read-only and there is no
 * channel to write composition documents back. `updateComposition` therefore
 * only accepts ids that are *registered settings namespaces* — the one
 * composition surface the host settings seam owns and can persist — and
 * rejects everything else loudly. A plain `cordis.yml` composition row (for
 * example `llm-main`) is not writable through this service: edit it with the
 * file editor surface or `cordis.patch.yml`.
 * @module @deepseek-ai/dsh-settings-plus/service
 */
import type { Context } from 'cordis';
import type { CompositionConfigView, NamespaceDescriptor, SettingsCrawler } from './crawler.ts';
/** Minimal write face of the host settings seam the service consumes. */
export interface SettingsWriterLike {
    /**
     * Persist a patch for one settings namespace.
     * @param ns - the registered namespace id.
     * @param patch - the value to write (merged over the current view by this service).
     * @param expectedRevision - the revision the patch was computed against, for
     *   the seam's optimistic concurrency checks.
     */
    update(ns: string, patch: unknown, expectedRevision?: number): void | Promise<void>;
}
/** The settings surface the bundle exposes to the host as `ctx.dshSettingsPlus`. */
export interface DshSettingsPlusService {
    /** Every registered settings namespace, redacted. */
    listNamespaces(): NamespaceDescriptor[];
    /** Every mounted plugin's composition configuration, redacted. */
    listCompositionConfigs(): CompositionConfigView[];
    /**
     * Mark a namespace as registered through the plugin SDK
     * (`registerUserSettings`). The mark is a display-level provenance signal:
     * from the next list onward, entries whose id is marked carry
     * `registeredBySdk: true`, so the client can tell third-party SDK
     * registrants apart from official DSH namespaces.
     *
     * The mark outlives the registration itself (it is not unmarked when the
     * registration disposer runs): it only annotates live entries, and a
     * namespace that disappears no longer appears in any list.
     * @param ns - the SDK-registered namespace id.
     */
    markSdkRegistered(ns: string): void;
    /**
     * Update one composition by id.
     *
     * Only ids that are registered settings namespaces are writable: the
     * current composition value is merged with `patch` and persisted through
     * the host settings seam's `update` path, carrying the namespace's
     * revision as `expectedRevision`. Any other id fails loudly:
     * - a plain `cordis.yml` composition row → error directing to the file
     *   editor surface or `cordis.patch.yml`;
     * - an unknown id → error.
     * @param id - composition id; for settings namespaces this equals `ns`.
     * @param patch - partial configuration to merge over the current value.
     */
    updateComposition(id: string, patch: object): Promise<void>;
    /**
     * Reset one composition by id.
     *
     * For a settings namespace this is expressed through the seam's update
     * path with a `null` user section; the namespace itself stays registered
     * and is owned by its registrant. Plain `cordis.yml` rows and unknown ids
     * fail loudly exactly like {@link updateComposition}.
     * @param id - composition id.
     */
    removeComposition(id: string): Promise<void>;
    /**
     * Update one settings namespace by id (the official-pane write channel).
     *
     * Semantically identical to {@link updateComposition} for registered
     * settings namespaces — the current composition value is deep-merged with
     * `patch` and persisted through the host settings seam — but it accepts the
     * client-observed `expectedRevision` and forwards it to the seam, so the
     * form's optimistic-concurrency checks survive the RPC round trip. Plain
     * `cordis.yml` rows and unknown ids fail loudly exactly like
     * {@link updateComposition}.
     * @param ns - the registered settings namespace id.
     * @param patch - partial configuration to deep-merge over the current value.
     * @param expectedRevision - the revision the client rendered the value at.
     */
    updateNamespace(ns: string, patch: object, expectedRevision?: number): Promise<void>;
    /**
     * Reset one field of a settings namespace by id (the official-pane reset
     * channel): a value-less nested unset patch at the path, written through
     * the settings seam with the client-observed `expectedRevision`. Plain
     * `cordis.yml` rows and unknown ids fail loudly exactly like
     * {@link updateComposition}.
     * @param ns - the registered settings namespace id.
     * @param path - root-relative segments of the field to unset.
     * @param expectedRevision - the revision the client rendered the value at.
     */
    resetNamespaceField(ns: string, path: readonly string[], expectedRevision?: number): Promise<void>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        dshSettingsPlus: DshSettingsPlusService;
    }
}
/** Factory options for {@link createDshSettingsPlusService}. */
export interface DshSettingsPlusServiceOptions {
    /** Injected settings writer for tests; defaults to the host `settings` seam. */
    writer?: SettingsWriterLike;
}
/**
 * Create the host settings service for a context.
 * @param ctx - host context with the settings seam mounted.
 * @param crawler - the live read-only crawler feeding both list surfaces.
 * @param options - optional injected writer override.
 * @returns the service face; reads resolve at call time.
 */
export declare function createDshSettingsPlusService(ctx: Context, crawler: SettingsCrawler, options?: DshSettingsPlusServiceOptions): DshSettingsPlusService;
//# sourceMappingURL=service.d.ts.map