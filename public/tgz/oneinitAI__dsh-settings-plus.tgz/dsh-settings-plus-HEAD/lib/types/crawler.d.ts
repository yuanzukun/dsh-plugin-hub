/**
 * Host settings crawler: read-only enumeration of the host's settings
 * surfaces — every registered settings namespace (through the `ctx.settings`
 * seam) and every mounted plugin's composition configuration (through the
 * cordis runtime registry). The crawler performs no writes; configuration
 * surfaces render from these snapshots.
 *
 * The host seam (`@deepseek-ai/dsh-settings`) is consumed through minimal
 * local contracts rather than an import: the crawler only calls
 * `ctx.settings.describe({ redactSecrets: true })`, and the registry rows it
 * reads are plain structural shapes, so this module builds and tests without
 * host source files.
 * @module @deepseek-ai/dsh-settings-plus/crawler
 */
import type { Context } from 'cordis';
/** When a namespace's changes take effect for its owner. */
export type SettingsApplies = 'live' | 'restart';
/**
 * One registered settings namespace as surfaced by `ctx.settings.describe`.
 * Field-for-field the seam's `SettingsDescriptor` (`@deepseek-ai/dsh-settings`),
 * with the branded `SettingsNamespace` id carried as its string payload.
 */
export interface NamespaceDescriptor {
    /** The registered namespace id (lowercase kebab-case, as in plugin short names). */
    ns: string;
    /** Serialized schemastery schema envelope (`schema.toJSON()`). */
    schema: unknown;
    /** Current resolved value, redacted under `describe({ redactSecrets: true })`. */
    value: unknown;
    /** Registrant's composition `base` layer, when one was declared. */
    base?: unknown;
    /** Raw user section from the stored document, when one exists. */
    user?: unknown;
    /** Monotonic revision of the raw user section this descriptor was read at. */
    revision: number;
    /** Owner's declared effect timing. */
    applies: SettingsApplies;
    /** Schema-declared secret positions; present only under `redactSecrets`. */
    secrets?: unknown[];
    /**
     * True when this namespace was registered through the plugin SDK
     * (`registerUserSettings`), distinguishing third-party registrants from
     * official DSH namespaces. Absent (not `false`) for unmarked namespaces.
     */
    registeredBySdk?: boolean;
}
/**
 * One mounted plugin's composition configuration, redacted for wire surfaces.
 */
export interface CompositionConfigView {
    /** The composition row id this config belongs to (`llm-deepseek`, `session`, …). */
    id: string;
    /** The plugin package name. */
    name: string;
    /** Serialized schemastery schema envelope (`Config.toJSON()`). */
    schemaJSON: unknown;
    /** Resolved row configuration with every `role('secret')` field stripped. */
    value: unknown;
    /**
     * True when this composition id was registered through the plugin SDK,
     * marking the row as a third-party settings namespace even when its id
     * would otherwise read as an internal service. Absent (not `false`) for
     * unmarked rows.
     */
    registeredBySdk?: boolean;
}
/** Read-only crawler face enumerating the host's settings surfaces. */
export interface SettingsCrawler {
    /**
     * Every registered settings namespace, in registration order. Resolved at
     * call time, so namespaces that mount or dispose between requests are
     * reflected immediately.
     * @returns redacted namespace descriptors.
     */
    listNamespaces(): NamespaceDescriptor[];
    /**
     * Every mounted plugin whose composition row carries a schemastery `Config`
     * and a row id, in registry order. Rows without a `Config`, with a
     * non-schemastery `Config`, or without a composition row id are skipped.
     * @returns redacted composition configuration views.
     */
    listCompositionConfigs(): CompositionConfigView[];
}
/** Minimal runtime face of the host settings seam the crawler consumes. */
export interface SettingsProviderLike {
    describe(options?: {
        redactSecrets?: boolean;
    }): NamespaceDescriptor[];
}
/** One runtime fiber's composition metadata, as populated by the loader. */
export interface CompositionFiberLike {
    /** The fiber's resolved configuration value. */
    config: unknown;
    /** Loader metadata; `options.id` is the composition row id. */
    entry?: {
        options?: {
            id?: unknown;
        };
    };
}
/** Minimal runtime registry row shape the crawler reads. */
export interface CompositionRuntimeLike {
    /** The plugin package name. */
    name?: string;
    /** The plugin configuration schema; schemastery Configs expose `toJSON()`. */
    Config?: unknown;
    /** Live fibers mounting this plugin. */
    fibers?: Iterable<CompositionFiberLike>;
}
/** Factory options for {@link createCrawler}. */
export interface CrawlerOptions {
    /**
     * Override the composition registry source for testing; defaults to the
     * live `ctx.registry`.
     */
    registryProvider?: () => Iterable<readonly [unknown, CompositionRuntimeLike]>;
}
/**
 * Create the read-only settings crawler for a host context.
 * @param ctx - host context with the settings seam mounted.
 * @param options - registry source override for testing.
 * @returns the crawler face; both lists resolve at call time.
 */
export declare function createCrawler(ctx: Context, options?: CrawlerOptions): SettingsCrawler;
//# sourceMappingURL=crawler.d.ts.map