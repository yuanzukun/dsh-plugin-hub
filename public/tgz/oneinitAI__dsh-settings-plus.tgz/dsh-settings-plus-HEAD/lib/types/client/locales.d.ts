/**
 * `dsh-settings-plus` locale namespace: the settings entry copy, the
 * temporary status-row copy, and the placeholder copy. Chinese is the
 * product copy; English mirrors it. The dictionary keys are the source of
 * truth and register against the harness locale service exactly once.
 */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    nav: string;
    'entry.desc': string;
    'official.nav': string;
    'plugins.nav': string;
    'official.empty': string;
    'plugins.empty': string;
    'status.loading': string;
    'status.loadFailed': string;
    'status.retry': string;
    'form.restartNotice': string;
    'form.invalidSchema': string;
    'form.invalidJson': string;
    'form.conflict': string;
    'form.reload': string;
    'form.reset': string;
    'form.secretConfigured': string;
    'form.secretEmpty': string;
};
/** The `dsh-settings-plus` namespace key union. */
export type SettingsKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    nav: string;
    'entry.desc': string;
    'official.nav': string;
    'plugins.nav': string;
    'official.empty': string;
    'plugins.empty': string;
    'status.loading': string;
    'status.loadFailed': string;
    'status.retry': string;
    'form.restartNotice': string;
    'form.invalidSchema': string;
    'form.invalidJson': string;
    'form.conflict': string;
    'form.reload': string;
    'form.reset': string;
    'form.secretConfigured': string;
    'form.secretEmpty': string;
};
/** Locale namespace id registered under the harness locale service. */
export declare const NS = "dsh-settings-plus";
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        [NS]: SettingsKey;
    }
}
//# sourceMappingURL=locales.d.ts.map