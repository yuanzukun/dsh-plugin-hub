/**
 * Browser half of dsh-settings-plus: the settings.section registrations.
 *
 * Three always-present registrations: the entry ('dsh-settings-plus',
 * order 30 — strictly after general 0 / models 10 / agent-preset 20), the
 * official settings pane ('dsh-settings-plus-official', order 30) showing
 * the config-declared file-only official entries, and the plugin settings
 * pane ('dsh-settings-plus-plugins', order 31) showing strictly SDK-registered
 * third-party entries. Every registration uses declaration-aware deferral
 * (`ctx.slots.inject('settings.section', ...)`) and signature diffing; the
 * two panes are constant (fixed signatures), so they are registered once and
 * reused for the fiber's lifetime.
 *
 * The catalog reads through the injectable `settingsPlusCatalog` source seam
 * (see src/client/catalog.ts); the production default is the RPC source,
 * which fills both panes from the host's dshSettingsPlus service over the
 * connection transport's loopback channel (see src/rpc.ts). An injected
 * source still wins, so tests and future adapters never touch the wire.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export type { SettingsPlusInjected } from './component.tsx';
export type { CatalogSource, CatalogLoadResult, SettingsCatalogState, SettingsSectionEntry, SettingsWriteBack, } from './catalog.ts';
/**
 * Required services. `settings.section` is declaration-ordered independently,
 * so each dynamic contribution uses declaration-aware deferral. `remote` is
 * declared for the host-event invalidation a future wire surface may bring;
 * the catalog RPC source currently performs its own loads on
 * connection/reset.
 */
export declare const inject: string[];
/**
 * Compose the settings surface: register the locale dictionaries, reconcile
 * the standing settings.section registrations against the catalog store, and
 * keep the catalog fresh on host invalidation.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map