/**
 * settings.section components for the dsh-settings-plus browser half. The
 * entry describes the tool; the two pane sections render the two-pane
 * settings display — the official pane (config-declared file-only entries)
 * and the plugin pane (strictly SDK-registered third-party entries). Each
 * pane carries its own loading / empty / error state so a pane without data
 * never flashes empty. Descriptor-carrying entries render the generic
 * SettingsForm bound to the injected RPC write-back; bare entries stay
 * label-only rows.
 */
import type { ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { SettingsCatalogState, SettingsWriteBack } from './catalog.ts';
import { NS } from './locales.ts';
/** Registration-side business face shared by every dynamic section. */
export interface SettingsPlusInjected {
    /** Catalog snapshot bound by the renderer as `useCatalog`. */
    hooks: {
        catalog: SnapshotStore<SettingsCatalogState>;
    };
    /** Reload the catalog from its source. */
    reload: () => Promise<void>;
    /** RPC write-back for the schema forms; undefined without an rpc face. */
    writeBack?: SettingsWriteBack;
}
/** Full section props: runtime share + injected face + the locale seat. */
export type SettingsPlusSectionProps = PropsRuntime<'settings.section'> & InjectFace<SettingsPlusInjected> & PropsLocale<typeof NS>;
/**
 * The 设置管理 entry: the always-present first-level section describing the
 * tool.
 * @param props - runtime share, injected face, and the locale seat.
 * @returns the entry element tree.
 */
export declare function SettingsPlusEntrySection({ t }: SettingsPlusSectionProps): ReactNode;
/** One of the two catalog panes a pane section projects from. */
export type SettingsPane = 'officialEntries' | 'pluginEntries';
/** Empty-state copy key for one pane. */
export type SettingsPaneEmptyKey = 'official.empty' | 'plugins.empty';
/** Options binding a pane section to one catalog pane. */
export interface SettingsPaneSectionOptions {
    /** The catalog state field this pane renders. */
    entriesKey: SettingsPane;
    /** The empty-state copy key shown when the pane has no entries. */
    emptyKey: SettingsPaneEmptyKey;
}
/**
 * One settings pane: the official pane or the plugin pane. Renders the
 * pane's entries as a list; while the catalog has no data it renders the
 * loading / empty / error states inline (the pane never flashes empty), with
 * a retry action on failure. Descriptor-carrying entries render the generic
 * SettingsForm bound to the injected write-back; bare entries stay
 * label-only rows.
 * @param options - which pane this section renders and its empty copy.
 * @returns a slot component bound to that pane.
 */
export declare function createSettingsPlusPaneSection(options: SettingsPaneSectionOptions): ({ t, useCatalog, reload, writeBack }: SettingsPlusSectionProps) => ReactNode;
/** The official pane section component (config-declared file-only entries). */
export declare const SettingsPlusOfficialSection: (props: SettingsPlusSectionProps) => ReactNode;
/** The plugin pane section component (strictly SDK-registered entries). */
export declare const SettingsPlusPluginsSection: (props: SettingsPlusSectionProps) => ReactNode;
//# sourceMappingURL=component.d.ts.map