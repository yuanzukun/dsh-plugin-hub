/**
 * Browser settings catalog: the observable snapshot the client's settings
 * panes project from, and the source seam every catalog reader plugs into.
 *
 * Two panes, two projection rules, mutually exclusive:
 * - **Plugin pane** (「插件设置页」): strictly SDK. Only entries whose
 *   `registeredBySdk` mark is true — third-party plugins that called the
 *   plugin SDK's `registerUserSettings`. Official DSH entries never appear
 *   here, no matter how they look.
 * - **Official pane** (「官方设置页」): strictly the user-declared
 *   `officialFileEntries` config list. Only entries that exist in the live
 *   namespaces/compositions AND are not SDK-marked appear here. A manifest id
 *   that happens to belong to an SDK-registered third-party entry stays on
 *   the plugin pane.
 *
 * Data path: the host publishes the dshSettingsPlus service over the
 * connection transport's generic RPC channel (see src/rpc.ts), and the
 * production source ({@link createRpcCatalogSource}) calls that channel
 * through the `rpc` face of the client connection handle. Tests and future
 * wire adapters keep the older seam: an injected `settingsPlusCatalog`
 * service overrides the production source, so no registration code changes
 * when the source is swapped.
 * @module @deepseek-ai/dsh-settings-plus/client/catalog
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import type { NamespaceDescriptor } from '../crawler.ts';
import type { SettingsDescriptorLike } from './form-logic.ts';
/** The logical RPC channel; mirrors the host-side constant in src/rpc.ts. */
export declare const RPC_CHANNEL = "/dsh-settings-plus";
/** This plugin's own id: never shown in the catalog, on either pane. */
export declare const SELF_PLUGIN_ID = "dsh-settings-plus";
/** One catalog entry backing a settings pane row. */
export interface SettingsSectionEntry {
    /** Stable source key: the settings namespace id or composition row id. */
    key: string;
    /** Display label resolved by the source. */
    label: string;
    /**
     * The full renderable form descriptor, when this entry is backed by a
     * registered settings namespace. Composition-only rows (no namespace
     * descriptor) and degraded candidates carry no descriptor, so their rows
     * stay label-only.
     */
    descriptor?: SettingsDescriptorLike;
}
/**
 * One candidate item before the two-pane projection: a namespace or
 * composition id carrying its SDK-registration provenance and, for namespaces,
 * the full descriptor the panes' forms render from. Entries without a mark
 * read as official DSH natives.
 */
export interface CatalogCandidate {
    /** The namespace id or composition row id. */
    key: string;
    /** True when registered through the plugin SDK (`registerUserSettings`). */
    registeredBySdk?: boolean;
    /** The full namespace descriptor, present only for namespace candidates. */
    descriptor?: NamespaceDescriptor;
}
/** One full catalog load: both panes projected from the same candidates. */
export interface CatalogLoadResult {
    /** Entries for the plugin pane: strictly SDK-marked candidates. */
    pluginEntries: readonly SettingsSectionEntry[];
    /** Entries for the official pane: the declared list, minus SDK-marked ids. */
    officialEntries: readonly SettingsSectionEntry[];
}
/** Catalog lifecycle: loading until the first load settles, then ready/error. */
export type SettingsCatalogStatus = 'loading' | 'ready' | 'error';
/** Observable catalog snapshot, split per pane. */
export interface SettingsCatalogState {
    status: SettingsCatalogStatus;
    /** The plugin pane's entries (strictly SDK-marked). */
    pluginEntries: readonly SettingsSectionEntry[];
    /** The official pane's entries (declared config list, minus SDK ids). */
    officialEntries: readonly SettingsSectionEntry[];
    /** Failure message of the latest refused load, while status is 'error'. */
    error?: string;
}
/**
 * One catalog reader. `load` resolves with both panes' current entries; a
 * rejection means the catalog could not be read this round (the store keeps
 * the previous entries and marks the state as errored).
 */
export interface CatalogSource {
    load(): Promise<CatalogLoadResult>;
}
/**
 * Observable catalog store: a bare `getSnapshot` + `subscribe` pair bound to
 * one source. A refused load keeps the last settled panes (stale data stays
 * visible and the panes never flash empty); a superseded load (a newer load
 * started meanwhile) commits nothing.
 */
export declare class SettingsCatalogStore {
    private readonly source;
    private state;
    private readonly listeners;
    private generation;
    private constructor();
    /** Create a store over a source (the source stays injectable for tests and wire adapters). */
    static create(source: CatalogSource): SettingsCatalogStore;
    /** Read the current snapshot (stable reference between changes). */
    getSnapshot(): SettingsCatalogState;
    /** Subscribe to state changes. */
    subscribe(listener: () => void): () => void;
    /**
     * Reload the catalog. Never rejects: failures settle the state as
     * `{ status: 'error', error }` with the previous panes preserved.
     */
    load(): Promise<void>;
    private setState;
}
/**
 * The plugin pane projection rule — **strict SDK**: only candidates marked
 * `registeredBySdk` are shown, whether they come from namespaces or
 * compositions. Official DSH entries (unmarked) never appear here, and this
 * plugin's own id is excluded even if it were marked. Keys deduplicate
 * across the two candidate lists; order is namespaces first (registration
 * order), then compositions (registry order).
 * @param namespaces - namespace candidates from listNamespaces.
 * @param compositions - composition candidates from listCompositionConfigs.
 * @returns the plugin pane's projected entries.
 */
export declare function projectPluginEntries(namespaces: readonly CatalogCandidate[], compositions: readonly CatalogCandidate[]): SettingsSectionEntry[];
/**
 * The official pane projection rule — **declared list only**: every id in
 * `officialFileEntries` that resolves to a live namespace or composition
 * candidate. Entries whose candidate carries the SDK mark are refused (they
 * belong to the plugin pane — the two panes are mutually exclusive), and ids
 * absent from the live candidates are skipped (a declaration names a real
 * settings entry, nothing is invented). This plugin's own id never shows.
 * Order follows the user's declared list; keys deduplicate.
 * @param namespaces - namespace candidates from listNamespaces.
 * @param compositions - composition candidates from listCompositionConfigs.
 * @param officialFileEntries - ids declared by the user in cordis.yml.
 * @returns the official pane's projected entries.
 */
export declare function projectOfficialEntries(namespaces: readonly CatalogCandidate[], compositions: readonly CatalogCandidate[], officialFileEntries: readonly string[]): SettingsSectionEntry[];
/**
 * The production default source: reads the live host catalog over the
 * connection transport's RPC channel. Every load calls the three list
 * methods in parallel; any transport failure, refused envelope, or malformed
 * payload rejects the load (the store keeps the previous entries and marks
 * the state as errored). Entries are projected by the two-pane rules
 * ({@link projectPluginEntries} / {@link projectOfficialEntries}): the
 * plugin pane gets strictly SDK-marked entries, the official pane gets the
 * user-declared `officialFileEntries` minus SDK-marked ids. A context
 * without a callable `rpc.call` face degrades to the honest empty catalog
 * (same semantics as {@link createLocalCatalogSource}), so client trees
 * against a host without the RPC transport still mount harmlessly.
 * @param ctx - client root context with the connection service mounted.
 * @returns the RPC-backed catalog source, degrading to an empty catalog when
 *   the connection seam is absent or malformed.
 */
export declare function createRpcCatalogSource(ctx: ClientContext): CatalogSource;
/**
 * The honest local fallback source: resolves with both panes empty. Kept for
 * tests, embedders, and profiles whose harness lacks the RPC transport —
 * nothing here pretends to enumerate host namespaces.
 * @returns the local empty-catalog source.
 */
export declare function createLocalCatalogSource(): CatalogSource;
/** One leaf's RPC write channel: the client half of updateNamespace. */
export interface SettingsWriteBack {
    /**
     * Commit one field edit for a namespace: a nested patch built from the
     * root-relative path, with the descriptor revision as expectedRevision.
     * Rejects with the envelope's error (code preserved) on failure.
     */
    writeValue(ns: string, path: readonly string[], value: unknown, revision: number): Promise<void>;
    /**
     * Unset one user override: a value-less nested patch at the path, carrying
     * the descriptor revision. The wire never sends a value for an unset.
     */
    resetField(ns: string, path: readonly string[], revision: number): Promise<void>;
}
/**
 * The production write-back: routes the schema form's write/reset channels to
 * the host over the connection transport's RPC channel, calling the
 * `updateNamespace` / `resetNamespaceField` endpoints (see src/rpc.ts). A
 * context without a callable `rpc.call` face resolves to `undefined` — the
 * panes then render descriptor-carrying entries as label-only rows, so client
 * trees against a host without the RPC transport still mount harmlessly.
 * @param ctx - client root context with the connection service mounted.
 * @returns the write-back face, or `undefined` when the seam is absent.
 */
export declare function createRpcWriteBack(ctx: ClientContext): SettingsWriteBack | undefined;
//# sourceMappingURL=catalog.d.ts.map