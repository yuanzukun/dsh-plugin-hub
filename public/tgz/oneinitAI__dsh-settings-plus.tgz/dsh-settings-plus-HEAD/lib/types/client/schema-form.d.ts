/**
 * The generic schema form renderer (T9): renders a `SettingsDescriptorLike`
 * as a form of whitelisted controls — string/number/boolean natively,
 * const-only unions as selects, nested objects as labeled groups, and
 * everything else as a raw JSON textarea fallback. Secrets render as empty
 * password inputs carrying only a placeholder hint (the wire never sends
 * plaintext), per-field reset appears for user-overridden or configured
 * paths, revision conflicts surface a reload prompt, and restart-applied
 * entries announce the restart notice.
 * @module @deepseek-ai/dsh-settings-plus/client/schema-form
 */
import { type ReactNode } from 'react';
import { type SettingsDescriptorLike } from './form-logic.ts';
/** The form's channels: write/reset both carry the descriptor revision. */
export interface SettingsFormProps {
    descriptor: SettingsDescriptorLike;
    /** Locale lookup (bound by the harness to the dsh-settings-plus namespace). */
    t: (key: string) => string;
    /** Commit a changed value at a root-relative path. */
    writeValue: (path: readonly string[], value: unknown, revision: number) => Promise<void>;
    /** Unset a user override at a root-relative path (never a value-bearing write). */
    resetField: (path: readonly string[], revision: number) => Promise<void>;
    /** Reload the descriptor after a revision conflict. */
    reload: () => Promise<void>;
}
/**
 * Render one entry's settings as a form.
 * @param props - the descriptor and its write/reset/reload channels.
 * @returns the form tree, or an invalid-schema alert when the envelope cannot parse.
 */
export declare function SettingsForm(props: SettingsFormProps): ReactNode;
//# sourceMappingURL=schema-form.d.ts.map