/**
 * Host-side document-level YAML/JSON editing with comment preservation.
 *
 * YAML edits go through the `yaml` v2 document AST: `parseDocument`
 * re-parses the text into a mutable tree that keeps comments, anchors, and
 * per-node formatting by default; `Document.setIn` / `Document.deleteIn`
 * apply leaf-level minimal diffs; `Document.toString()` serializes the tree
 * back to text. Untouched nodes — and the key node of every changed pair —
 * keep their comments, exactly like the host `settings-file` render path.
 *
 * JSON has no comments, so {@link editJsonText} takes the honest
 * format-preserving route: `JSON.parse` → plain-object edits →
 * `JSON.stringify(value, null, inferredIndent)`. What survives is the
 * indentation shape (two spaces, tab, or compact), never comments.
 *
 * ## Comment-preservation promise (scope)
 *
 * Comment preservation is promised only for files edited through this
 * module: comments attached to untouched nodes and to the key of each
 * edited pair survive our edits. Two boundaries are documented, not
 * silently hidden:
 *
 * - whole-node replacement of an array or scalar value drops the comments
 *   inside the replaced node (map-level recursion is what keeps comments);
 * - the host's own transactional replay (its reconcile-then-render
 *   `persist` path) may re-render the whole document and is outside this
 *   promise.
 *
 * The edited document must be syntactically valid YAML with a map (or
 * sequence) root; a syntax error is reported loudly with the 1-based line
 * number, never silently overwritten.
 * @module @deepseek-ai/dsh-settings-plus/yaml-editor
 */
/**
 * A path into a document: string keys for maps, number indexes for
 * sequences. A path always has at least one element — replacing the whole
 * root is deliberately rejected.
 */
export type YamlPath = readonly (string | number)[];
/**
 * One document-level edit applied in order on top of the previous state.
 * `set` requires {@link YamlEdit.value}; `unset` of a missing path is a
 * no-op success.
 */
export type YamlEdit = {
    op: 'set' | 'unset';
    path: YamlPath;
    /** The value to set; required for `set`, ignored for `unset`. */
    value?: unknown;
};
/** Why a document edit was rejected. */
export type YamlEditorErrorCode = 'SYNTAX' | 'BAD_PATH' | 'BAD_VALUE';
/** Error for rejected document edits, with the 1-based line when known. */
export declare class YamlEditorError extends Error {
    readonly code: YamlEditorErrorCode;
    /** 1-based line of the failure, present for syntax errors. */
    readonly line: number | undefined;
    constructor(code: YamlEditorErrorCode, message: string, line?: number);
}
/**
 * Minimal contract of a parsed document handle, backed by a `yaml` v2
 * `Document.Parsed`. The local surface hides the library type from callers
 * (T13) so the module can be swapped without touching them.
 */
export interface YAMLNodeLike {
    /** Set the value at `path`, creating intermediate maps as needed. */
    setIn(path: YamlPath, value: unknown): void;
    /** Remove the value at `path`; missing paths are a no-op. */
    deleteIn(path: YamlPath): void;
    /** The plain JS value of the document. */
    toJS(): unknown;
    /** Serialize back to text, preserving untouched comments. */
    toString(): string;
}
/**
 * Parse YAML text into an editable, comment-preserving document.
 * @param text - the YAML text to parse.
 * @returns a document handle for {@link setPath} / {@link unsetPath} /
 * {@link stringifyDocument}.
 * @throws {@link YamlEditorError} with code `SYNTAX` and the 1-based line
 * number when the text is not valid YAML.
 */
export declare function parseDocumentText(text: string): YAMLNodeLike;
/**
 * Set the value at `path` on a parsed document, preserving comments of
 * untouched nodes. Intermediate maps are created as needed; a scalar
 * intermediate node is rejected with `BAD_PATH`.
 * @param doc - a document from {@link parseDocumentText}.
 * @param path - the map key / sequence index path, at least one element.
 * @param value - the new value; must not be `undefined`.
 * @throws {@link YamlEditorError} for empty paths, undefined values, or
 * scalar intermediate nodes.
 */
export declare function setPath(doc: YAMLNodeLike, path: YamlPath, value: unknown): void;
/**
 * Remove the value at `path` on a parsed document; a missing path — an
 * unknown key anywhere along it — is a no-op success. Sequence-index
 * deletion splices the element out.
 * @param doc - a document from {@link parseDocumentText}.
 * @param path - the map key / sequence index path, at least one element.
 * @throws {@link YamlEditorError} for empty paths or scalar intermediate
 * nodes.
 */
export declare function unsetPath(doc: YAMLNodeLike, path: YamlPath): void;
/**
 * Serialize a parsed document back to text, preserving untouched comments.
 * @param doc - a document from {@link parseDocumentText}.
 * @returns the comment-preserving text.
 */
export declare function stringifyDocument(doc: YAMLNodeLike): string;
/**
 * Round-trip YAML text through a set of edits: parse → apply each edit in
 * order → serialize. The returned text keeps comments attached to untouched
 * nodes and to the key of every changed pair (see the module doc for the
 * promise scope).
 * @param text - the current YAML text.
 * @param edits - the edits to apply, in order.
 * @returns the edited, comment-preserving text.
 * @throws {@link YamlEditorError} for syntax errors (with the line number),
 * bad paths, or set edits without a value.
 */
export declare function editYamlText(text: string, edits: readonly YamlEdit[]): string;
/**
 * Round-trip JSON text through a set of edits while keeping its formatting.
 *
 * The honest trade-off, recorded: JSON has no comments, so nothing comment-
 * like survives — what is preserved is the format, i.e. the indentation
 * shape inferred from the original text (two spaces, tab, or compact). The
 * document is `JSON.parse`d into plain values, edited in order, and
 * re-serialized with the inferred indent.
 * @param text - the current JSON text.
 * @param edits - the edits to apply, in order.
 * @returns the edited text with the original indentation shape.
 * @throws {@link YamlEditorError} for syntax errors (with the line number),
 * bad paths, or set edits without a value.
 */
export declare function editJsonText(text: string, edits: readonly YamlEdit[]): string;
//# sourceMappingURL=yaml-editor.d.ts.map