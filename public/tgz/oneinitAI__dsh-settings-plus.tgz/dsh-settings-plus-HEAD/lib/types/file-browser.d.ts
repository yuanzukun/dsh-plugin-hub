/**
 * Host-side configuration directory browser: enumerates the DSH
 * configuration file manifest — writable home-root YAML files, writable
 * per-profile `cordis` patches, and read-only bundle layers declared by
 * profile manifests — and validates every resolved path against a realpath
 * boundary.
 *
 * The writable manifest is a closed list (Metis M-4): `$DSH_HOME` root
 * `*.yml`/`*.yaml` (including `cordis.patch.yml` and `settings.yaml`) plus
 * `profiles/<name>/cordis*.yml`. Bundle layers are read-only display surfaces:
 * the `cordis.patch.yml` shipped inside every bundle package a profile's
 * `package.json` declares under `dsh.profile.bundles`.
 *
 * This module only enumerates and validates — no file is read or written
 * here. Content editing (T11+) routes every write through
 * {@link isWritableTarget} so nothing outside the manifest can be touched.
 * @module @deepseek-ai/dsh-settings-plus/file-browser
 */
/** Where a configuration file lives relative to the DSH home. */
export type ConfigFileScope = 'home' | 'profile';
/** What a configuration file is, from the file's name. */
export type ConfigFileKind = 'cordis-patch' | 'settings' | 'yaml' | 'json';
/** One configuration file on the enumerated manifest. */
export interface ConfigFileEntry {
    /** Absolute path of the file. */
    path: string;
    /** Path relative to the DSH home, the stable identifier for surfaces. */
    relative: string;
    /** `home` for `$DSH_HOME` root files, `profile` for profile-scoped files. */
    scope: ConfigFileScope;
    /**
     * Whether the file is on the writable manifest. Bundle layers are
     * enumerated read-only and are never writable targets.
     */
    writable: boolean;
    /** Classified from the file name: `cordis.patch.yml` → `cordis-patch`, `settings.yaml` → `settings`, … */
    kind: ConfigFileKind;
}
/** Realpath provider, injectable so boundary checks stay unit-testable. */
export interface FileSystemLike {
    /** Node-style `fs.realpathSync`, throwing on missing paths. */
    realpathSync(path: string): string;
}
/**
 * Resolve the DSH home the configuration manifest lives under, in the same
 * precedence as the harness workspace store: explicit `configHome`, then
 * `$DSH_HOME`, then the `.dsh` directory under the user home.
 * @param configHome - the configured home; an empty string skips this tier.
 * @returns the resolved home path.
 */
export declare function resolveDshHome(configHome: string): string;
/**
 * Enumerate the closed configuration manifest under one DSH home: writable
 * home-root `*.yml`/`*.yaml` files, writable `profiles/<name>/cordis*.yml`
 * patches, and read-only bundle layers. A missing or unreadable home
 * enumerates as empty.
 * @param dshHome - the resolved DSH home.
 * @returns manifest entries; home-root entries first, then per-profile
 * writable patches, then read-only bundle layers.
 */
export declare function listConfigFiles(dshHome: string): ConfigFileEntry[];
/**
 * Boundary check: realpath-normalize `candidate` and confirm it stays inside
 * the realpath-normalized `root`. Symlink escapes and `..` traversal both
 * collapse into a path outside the root and resolve to `null`.
 * @param root - the boundary root (the DSH home).
 * @param candidate - the candidate path to validate.
 * @param fsImpl - injectable realpath provider.
 * @returns the canonicalized in-boundary path, or `null` when the candidate
 * is outside the root or cannot be resolved.
 */
export declare function resolveInside(root: string, candidate: string, fsImpl?: FileSystemLike): string | null;
/**
 * Confirm a path is a writable target: it must resolve inside the DSH home
 * boundary *and* appear on the writable manifest. This is the guard every
 * future file write (T11+) must pass; bundle layers and arbitrary files
 * (`.env`, `notes.txt`, …) fail here.
 * @param dshHome - the resolved DSH home.
 * @param path - the candidate write target.
 * @returns whether writing to the path is permitted.
 */
export declare function isWritableTarget(dshHome: string, path: string): boolean;
//# sourceMappingURL=file-browser.d.ts.map