/**
 * Fabric binding for the exposed-namespaces widening patch.
 *
 * The host gateway's exposure decision (`exposedNamespaces()` in
 * `@deepseek-ai/dsh-host-apiproxy`) defaults to a product allowlist. This
 * bundle widens it through the Fabric layer instead of editing the core
 * gateway: `cordis.patch.yml` carries a disabled `cordis-fabric` stub that
 * transforms the function at load time (covering both launch forms — the
 * source launch loads `src/api-proxy.ts`, built deployments load
 * `lib/index.js`), and this module binds the matching runtime `after`
 * handler when the bundle mounts. The handler adds every namespace the
 * crawler currently enumerates, resolved at call time, to the traced call's
 * result Set in place — the gateway reads the same Set object, so its
 * allowlist decision stays authoritative and this patch only adds what the
 * deployment opted into by mounting the bundle.
 *
 * Dependency posture: the Fabric compat facade is loaded OPTIONALLY. This
 * repository declares no `cordis-fabric`/`cordis-fabric-api` dependency
 * (their git subdirectory specs would fail the `verify:self-contained`
 * non-registry check), so the binding resolves the facade from the host
 * context at registration time. Three outcomes:
 *   - no facade mounted → safe no-op: the stub row stays disabled, no
 *     handler fires, and the gateway keeps its default allowlist stance;
 *   - facade mounted but malformed → loud error: a host upgrade drifted the
 *     compat contract and must not degrade silently;
 *   - facade mounted and well-formed → the widening handler is registered.
 * @module @deepseek-ai/dsh-settings-plus/fabric
 */
import type { Context } from 'cordis';
import type { SettingsCrawler } from './crawler.ts';
/** Patch id shared with `cordis.patch.yml`'s `cordis-fabric` stub row. */
export declare const EXPOSED_NAMESPACES_PATCH = "dsh-settings-plus/exposed-namespaces";
/** Function kinds the Fabric function query accepts. */
export type FabricFunctionKind = 'Sync';
/** The Fabric patch target: the gateway's private exposure decision. */
export interface FabricTarget {
    module: string;
    versionRange: string;
    filePaths: string[];
    functionQuery: {
        functionName: string;
        kind: FabricFunctionKind;
    };
}
/** The gateway's `exposedNamespaces()` in both launch forms. */
export declare const exposedNamespacesTarget: FabricTarget;
/** One traced call record handed to an `after` handler. */
export interface FabricCall {
    /** The traced function's return value; mutated in place when a Set. */
    result: unknown;
}
/** Patch registration shape the compat facade accepts. */
export interface FabricPatchRegistration {
    id: string;
    target: FabricTarget;
    operation: 'after';
    handler: (call: FabricCall) => void;
}
/** Minimal compat facade face this binding registers through. */
export interface FabricCompatLike {
    registerPatch(registration: FabricPatchRegistration): void;
}
/** Registration options for {@link registerExposedNamespacesPatch}. */
export interface FabricPatchOptions {
    /** Injected compat facade for tests; defaults to the host context's. */
    compat?: FabricCompatLike;
}
/** The crawler face the widening handler consults; resolved at call time. */
export type NamespaceSource = Pick<SettingsCrawler, 'listNamespaces'>;
/**
 * Widen a traced `exposedNamespaces()` result with every namespace the
 * crawler currently enumerates. The result is mutated in place so the
 * gateway's own Set instance (and anything aliasing it) observes the
 * addition; non-Set results are left untouched.
 * @param call - the fabric call record whose `result` holds the exposure Set.
 * @param crawler - the live crawler face whose enumeration feeds the set.
 */
export declare function widenExposedNamespaces(call: FabricCall, crawler: NamespaceSource): void;
/**
 * Bind the exposure-widening handler under the patch id the bundle's
 * `cordis-fabric` stub transforms. Without a mounted compat facade this is
 * a safe no-op: the stub row stays disabled, the patch never fires, and the
 * gateway keeps its default allowlist stance.
 * @param ctx - host context.
 * @param crawler - the live crawler whose enumeration feeds the widening.
 * @param options - optional injected facade override.
 * @returns whether a patch registration was made.
 */
export declare function registerExposedNamespacesPatch(ctx: Context, crawler: NamespaceSource, options?: FabricPatchOptions): boolean;
//# sourceMappingURL=fabric.d.ts.map