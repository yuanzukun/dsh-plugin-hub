/**
 * L2 same-origin browser RPC channel for the settings catalog.
 *
 * The host publishes the `dshSettingsPlus` service surface (see service.ts)
 * to the browser half over the connection transport's generic RPC channel
 * registry: the browser calls the channel with
 * `ctx.connection.rpc.call(channel, method, payload)` (the `rpc` face of the
 * client connection handle, @deepseek-ai/dsh-client-connection), and the host
 * dispatches against the handler registered here. The four methods mirror the
 * service face one-to-one — listNamespaces / listCompositionConfigs are reads
 * served straight from the crawler, updateComposition / removeComposition
 * carry the same loud write boundary as the service.
 *
 * Envelope contract (the harness RpcResult, mirrored locally): every call
 * answers `{ ok: true, value }` or `{ ok: false, error: { code, message,
 * details } }`, the error-code set is the harness's closed union, and
 * business failures fold into `internal` exactly like the transport's own
 * transportError helper. Unknown methods and malformed payloads answer
 * `bad-request`. The handler never throws: an unhandled exception would
 * surface as a transport-level HTTP 500 instead of an envelope.
 *
 * Dependency posture: the connection transport is consumed through a minimal
 * local contract, never an import of the host package. Registration probes
 * the optional `connection` service with `ctx.get` — a context without it
 * (headless host runs, older harness profiles) safely skips the channel;
 * a mounted but malformed seam is a drifted host contract and fails loud.
 * The channel registration is owned by the caller fiber through
 * `ctx.effect`, so it disappears exactly when this bundle unloads.
 * @module @deepseek-ai/dsh-settings-plus/rpc
 */
import type { Context } from 'cordis';
import type { DshSettingsPlusService } from './service.ts';
/** The logical RPC channel the browser half calls through. */
export declare const RPC_CHANNEL = "/dsh-settings-plus";
/** The channel's method names: the service face, one method per endpoint. */
export type SettingsPlusRpcMethod = 'listNamespaces' | 'listCompositionConfigs' | 'getOfficialFileEntries' | 'updateComposition' | 'removeComposition' | 'updateNamespace' | 'resetNamespaceField';
/** One error branch of the envelope (harness RpcError mirrored locally). */
export interface RpcErrorEnvelope {
    /** Member of the harness's closed error-code union. */
    code: string;
    /** Human-readable failure text, safe to surface. */
    message: string;
    /** Code-specific details; `{}` for the internal catch-all. */
    details: unknown;
}
/** The RpcResult envelope the transport carries (harness contract mirrored). */
export type RpcResultEnvelope<T> = {
    ok: true;
    value: T;
} | {
    ok: false;
    error: RpcErrorEnvelope;
};
/** Handler face the transport invokes after decoding the request envelope. */
export type SettingsPlusRpcHandler = (endpoint: string, payload: unknown, signal: AbortSignal) => Promise<RpcResultEnvelope<unknown>>;
/** Minimal registry face of the host connection service's `rpc` member. */
export interface ConnectionRpcRegistryLike {
    /**
     * Register one channel prefix under the caller's fiber.
     * @param channel - the logical channel this handler answers.
     * @param handler - decoded endpoint handler returning the envelope shape.
     * @param options - channel trust policy (loopback keeps the browser-only fence).
     * @returns disposer removing the channel and its physical route.
     */
    handle(channel: string, handler: SettingsPlusRpcHandler, options: {
        authority: 'loopback' | 'trusted-host';
    }): () => void | Promise<void>;
}
/** Carrier shape of a host context with the connection service mounted. */
export interface ConnectionCarrierLike {
    rpc?: ConnectionRpcRegistryLike;
}
/** Options for {@link registerSettingsPlusRpc}. */
export interface SettingsPlusRpcOptions {
    /**
     * The service face this channel dispatches against. Required: the caller
     * already holds the instance (a same-apply `ctx.get` cannot see a service
     * this fiber provided), so it is passed in rather than re-resolved.
     */
    service?: DshSettingsPlusService;
    /**
     * The official settings entries declared by the user in cordis.yml
     * (`officialFileEntries`). Served verbatim by the `getOfficialFileEntries`
     * endpoint so the browser half can project the official pane; defaults to
     * `[]` when the caller does not pass the resolved config.
     */
    officialFileEntries?: readonly string[];
    /**
     * Injected connection service for tests; defaults to the host context's
     * `connection` service (read with `ctx.get`, so an absent seam skips).
     */
    connection?: ConnectionCarrierLike;
}
/**
 * Create the channel handler over one service face. Endpoint names equal the
 * service method names; every outcome is an envelope (never a throw), with
 * business failures folded into `internal` and malformed calls answered
 * `bad-request`. `getOfficialFileEntries` serves the host-side
 * `officialFileEntries` config verbatim (a fresh array copy per call), so the
 * browser half can project the official pane without a dedicated method on
 * the service.
 * @param service - the service face this channel dispatches against.
 * @param officialFileEntries - the user-declared official settings entries.
 * @returns the transport handler.
 */
export declare function createSettingsPlusRpcHandler(service: DshSettingsPlusService, officialFileEntries?: readonly string[]): SettingsPlusRpcHandler;
/**
 * Register the browser RPC channel for the settings catalog.
 *
 * The registration is owned by the caller fiber through `ctx.effect`, so the
 * channel and its physical route disappear exactly when this bundle unloads.
 * A context without the optional `connection` service safely skips the
 * channel (the browser half then shows its error status row until a harness
 * with the transport mounts).
 * @param ctx - host context with the connection service (optional) and the
 *   provided `dshSettingsPlus` service.
 * @param options - service / connection overrides for tests.
 * @returns whether the channel was registered.
 */
export declare function registerSettingsPlusRpc(ctx: Context, options?: SettingsPlusRpcOptions): boolean;
//# sourceMappingURL=rpc.d.ts.map