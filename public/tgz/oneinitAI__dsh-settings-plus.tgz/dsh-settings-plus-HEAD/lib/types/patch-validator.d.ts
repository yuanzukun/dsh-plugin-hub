/**
 * Host-side semantic validation and self-protection for `cordis.patch.yml`
 * editing (T13, C3 file-level config editing).
 *
 * ## Semantic validation
 *
 * {@link validatePatchDocument} parses the YAML through `yaml-editor`'s
 * `parseDocumentText` (the same parser the whole file-editing surface uses)
 * and then walks the parsed AST for patch-row structure: the top level must
 * be a sequence of entries, every non-`insert` entry must carry a string
 * `id` (a pure `insert` container carries none), `insert` children must be
 * `{id, name}` maps, a `cordis-fabric` entry (when present) must carry `config.fabric.patches` with per-patch `id` and `target`, and a
 * present `disabled` key must be a boolean. Failures carry a 1-based line
 * number where the AST exposes one.
 *
 * ## Self-protection
 *
 * This plugin's bundle row contributes three critical rows to the gateway
 * patch document:
 *
 * - the `cordis-fabric` entry with its `dsh-settings-plus/exposed-namespaces`
 *   stub patch;
 * - the `dsh-settings-plus` plugin row under an `insert` entry;
 * - the `dsh-settings-plus-invariant` companion row under the same `insert`.
 *
 * Removing or breaking any of them silently disables this plugin at the next
 * host replay, so {@link assertSelfRowsPreserved} reports exactly which rows
 * are gone and {@link validateBeforeWrite} refuses the save unless the caller
 * explicitly opts out with `requireSelfProtection: false` (the escape hatch
 * for intentionally removing the plugin).
 *
 * ## No file watch here
 *
 * This module validates text only — the host's own watchers
 * (`watchUserPatches` replay for `cordis.patch.yml`, the settings-file
 * watcher for `settings.yaml`) reload edits, see `hmr-aware.ts`.
 * @module @deepseek-ai/dsh-settings-plus/patch-validator
 */
/** The fabric stub patch id this plugin's `cordis-fabric` row must carry. */
export declare const SELF_STUB_ID = "dsh-settings-plus/exposed-namespaces";
/** The plugin rows this plugin's `insert` entry must carry. */
export declare const SELF_PLUGIN_IDS: readonly ["dsh-settings-plus", "dsh-settings-plus-invariant"];
/** Result of semantic validation of a patch document. */
export interface PatchValidationResult {
    /** Whether the document is syntactically and structurally valid. */
    ok: boolean;
    /** Human-readable failure descriptions, with line numbers when known. */
    errors: string[];
}
/** Options for the combined write gate. */
export interface BeforeWriteOptions {
    /**
     * Whether missing self rows reject the save. Defaults to `true` — self-
     * protection is a hard constraint; set `false` only when the user is
     * explicitly removing this plugin from the patch document.
     */
    requireSelfProtection?: boolean;
}
/** Result of the combined write gate. */
export interface BeforeWriteResult {
    /** Whether the write may proceed. */
    ok: boolean;
    /** All failure descriptions: semantic errors plus self-protection ones. */
    errors: string[];
    /** Descriptions of self rows that are missing or unverifiable. */
    selfRowsMissing: string[];
}
/**
 * Validate a patch document's syntax and structure.
 * @param text - the patch document text.
 * @returns `{ok: true, errors: []}` for a valid document; otherwise the
 * failure descriptions with line numbers where the AST exposes them.
 */
export declare function validatePatchDocument(text: string): PatchValidationResult;
/**
 * Check that the plugin's three self rows survive in the text: the
 * `cordis-fabric` stub patch, the `dsh-settings-plus` plugin row, and the
 * `dsh-settings-plus-invariant` companion row.
 * @param text - the patch document text.
 * @returns one description per broken row; an empty array means the rows
 * are intact. An unparseable document reports the rows as unverifiable
 * rather than pretending they exist.
 */
export declare function assertSelfRowsPreserved(text: string): string[];
/**
 * The combined write gate: semantic validity plus self-protection. When
 * {@link BeforeWriteOptions.requireSelfProtection} is `true` (the default)
 * any missing self row rejects the save; with `false` the semantic result
 * stands alone and the missing rows are only reported.
 * @param text - the patch document text about to be written.
 * @param options - gate options; `requireSelfProtection` defaults to `true`.
 * @returns whether the write may proceed, all failure descriptions, and the
 * missing self rows (empty when intact).
 */
export declare function validateBeforeWrite(text: string, options?: BeforeWriteOptions): BeforeWriteResult;
//# sourceMappingURL=patch-validator.d.ts.map