/**
 * Runtime boundary and Cordis activation for the plugin.
 * @module @deepseek-ai/dsh-settings-plus/runtime
 */
import type { Context } from 'cordis';
import { type Config } from './config.ts';
/** Fakeable host boundary used by the minimal plugin behavior. */
export interface PluginRuntime {
    /** Publish one informational message through the host. */
    info(message: string): void;
}
/**
 * Create the production runtime adapter from a scoped Cordis context.
 * @param ctx - Scoped plugin context.
 * @returns Host behavior used by the plugin implementation.
 */
export declare function createPluginRuntime(ctx: Context): PluginRuntime;
/**
 * Apply the plugin to its Cordis context.
 *
 * The `settings` seam is guaranteed ready by `inject = ['settings']`. The
 * crawler (read-only enumeration) feeds both the published service and the
 * fabric exposure widening; the service itself is owned by the plugin fiber
 * through an effect, so it disappears exactly when this bundle unloads.
 * @param ctx - Scoped plugin context; registrations must be owned by its effects.
 * @param config - Configuration resolved by Cordis from the exported schema.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=runtime.d.ts.map