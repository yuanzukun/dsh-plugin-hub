/**
 * Pure prediction math for the turn-eta fold: one home for the robust per-step
 * rate estimate and the turn-total extrapolation that the `turnEta` projection
 * unit publishes. Nothing here touches a session or a context, so the estimator
 * can be driven directly (`etaCore` + `ETA_TUNING`) by an agent that only wants
 * the numbers.
 *
 * Two properties matter for the rendered bar:
 * - **robustness** — a single very long step (an idle gap) must not blow up the
 *   estimate, so the historical rate is a median and the live rate is blended
 *   with it rather than replacing it;
 * - **real-time anchoring** — the expected step count is the conditional median
 *   of previously completed turns *at least as long as this one*, so a growing
 *   turn keeps a live estimate instead of saturating; the total only re-anchors
 *   upward once the turn has actually outrun it, which keeps the percentage from
 *   drifting backwards on mere noise.
 * @module @deepseek-ai/dsh-session-turn-eta/predict
 */

import type { TurnEtaInterval, TurnEtaMethod } from './types.ts'

/** Inputs the prediction math reads from either fold. */
export interface EtaPredictionInput {
  readonly startTime: number
  readonly stepDurations: readonly number[]
  readonly completedTurnSteps: readonly number[]
  readonly stepSamples: readonly number[]
  readonly asOf: number
  /**
   * The total already published for this open turn, if any. It is held while it
   * still outruns the turn, and re-anchored to the live estimate once the turn
   * has run past it.
   */
  readonly previousTotalMs?: number | undefined
}

/** The prediction fields shared by the event payload and the projection wire view. */
export interface EtaCore {
  readonly elapsedMs: number
  readonly completedSteps: number
  readonly expectedSteps?: number
  readonly meanStepMs?: number
  readonly predictedTotalMs?: number
  readonly remainingMs?: number
  readonly interval?: TurnEtaInterval
  readonly method: TurnEtaMethod
}

/** Prior weight, in steps, of the historical rate against the live turn's own rate. */
const HISTORY_PRIOR_STEPS = 1

/**
 * Percentile of the step-duration history used as the central per-step rate.
 * The duration distribution is strongly right-skewed, so the central rate has to
 * sit high in the distribution to track the steps that actually dominate a turn.
 * Measured on a rebuilt 131-session archive (42,853 train / 70,586 held-out
 * live predictions), raising this from 0.6 to 0.9 shrank the remaining-time
 * error on both halves and removed most of the systematic under-prediction.
 */
const RATE_PERCENTILE = 0.9

/**
 * Fraction of the published total the turn must reach before the estimate may be
 * re-anchored upward.
 *
 * Holding the total until the turn has *fully* outrun it (`1`) pins the bar to
 * the first estimate of the turn: on a turn that keeps working, the real total
 * is several times the early anchor, so the bar undershoots badly and the
 * remaining time stays wrong for the whole turn. Releasing at the halfway point
 * measured best on both halves of the rebuilt archive: median remaining-time
 * bias -0.29 -> +0.02 on the train half and -0.46 -> -0.29 on the held-out
 * half, with median APE improving on both (0.775 -> 0.769 and 0.771 -> 0.754)
 * and the overrun share dropping below half on the train half (0.60 -> 0.49).
 */
const REANCHOR_AT = 0.5

/** Cap, as a multiple of the median, applied before reading the high quantile. */
const OUTLIER_CAP = 8

/** Safe bound on the blended per-step estimate relative to the historical median. */
const RATE_FLOOR = 0.25
const RATE_CEILING = 4

/** Runway kept when the turn already outran every finished turn in the session. */
const OUTRUN_GROWTH = 0.25
const OUTRUN_MINIMUM = 2

/**
 * Expected step count assumed before the session has any finished turn, so the
 * very first turn still gets a live estimate instead of an endless indeterminate
 * bar. Every later turn replaces it with the session's own median.
 */
const BOOTSTRAP_EXPECTED_STEPS = 10

/** Median of a non-empty ascending numeric list, or undefined for an empty list. */
export function median(values: readonly number[]): number | undefined {
  if (values.length === 0) return undefined
  return values[Math.floor(values.length / 2)] as number
}

/** Linear-interpolated quantile of an already ascending list. */
export function quantile(sorted: readonly number[], fraction: number): number {
  if (sorted.length === 0) return 0
  if (sorted.length === 1) return sorted[0] as number
  const position = fraction * (sorted.length - 1)
  const lower = Math.floor(position)
  const upper = Math.ceil(position)
  if (lower === upper) return sorted[lower] as number
  const weight = position - lower
  return (sorted[lower] as number) * (1 - weight) + (sorted[upper] as number) * weight
}

/**
 * Robust high quantile for a right-skewed sample: clamp the sample to its own
 * median times a generous multiple first, so one 9-hour idle step cannot single
 * handedly drag the central rate up, then take the quantile of the clamped list.
 * @param sorted - ascending step durations.
 * @param fraction - the quantile to read off the clamped list.
 * @returns the robust quantile (0 for an empty list).
 */
export function robustQuantile(sorted: readonly number[], fraction: number): number {
  if (sorted.length === 0) return 0
  const centre = median(sorted) as number
  if (!(centre > 0)) return quantile(sorted, fraction)
  // The clamped list is ascending too, so its quantile is an index read with
  // `min(value, cap)` applied per endpoint — no clamped copy per call.
  const cap = centre * OUTLIER_CAP
  if (sorted.length === 1) return Math.min(sorted[0] as number, cap)
  const position = fraction * (sorted.length - 1)
  const lower = Math.floor(position)
  const upper = Math.ceil(position)
  const low = Math.min(sorted[lower] as number, cap)
  if (lower === upper) return low
  const high = Math.min(sorted[upper] as number, cap)
  return low * (1 - (position - lower)) + high * (position - lower)
}

/**
 * Memo of the ascending copy of a sample list, keyed by the list reference.
 *
 * A fold appends (`[...samples, next]`) rather than mutating, so one list
 * instance lives per state change; caching by reference turns the sort into one
 * per appended sample instead of one per prediction (the same list is read by
 * both the anchor advance and the view of the same event).
 */
const sortedByReference = new WeakMap<readonly number[], readonly number[]>()

/** Ascending copy of a numeric list, memoised for as long as the list lives. */
function sortedSamples(values: readonly number[]): readonly number[] {
  const cached = sortedByReference.get(values)
  if (cached !== undefined) return cached
  const sorted = ascending(values)
  sortedByReference.set(values, sorted)
  return sorted
}

/** The three rates one step-duration history yields, read off it once. */
interface RateProfile {
  readonly historyRate: number
  readonly lowRate: number
  readonly highRate: number
}

/** Rate profile of one sample list; cached per list reference, like the sort. */
const profiles = new WeakMap<readonly number[], RateProfile>()

/**
 * Read the central, low and high step rates off one history.
 *
 * A sample list only changes when a step ends, while the estimator runs on every
 * event inside the step (messages, tool calls, results). Caching the profile by
 * list reference pays the clamp-quantile scan once per finished step instead of
 * once per event, which is what keeps the fold linear in the event count rather
 * than quadratic in it.
 */
function rateProfile(samples: readonly number[]): RateProfile {
  const cached = profiles.get(samples)
  if (cached !== undefined) return cached
  const sorted = sortedSamples(samples)
  const profile: RateProfile = {
    historyRate: robustQuantile(sorted, RATE_PERCENTILE),
    lowRate: quantile(sorted, 0.25),
    highRate: quantile(sorted, 0.75),
  }
  profiles.set(samples, profile)
  return profile
}

/**
 * Insert one value into an ascending list, keeping it ascending.
 * @param sorted - ascending numeric list.
 * @param value - the value to insert.
 * @returns a new ascending list (the input is untouched).
 */
export function insertSorted(sorted: readonly number[], value: number): number[] {
  const at = lowerBound(sorted, value)
  const out = new Array<number>(sorted.length + 1)
  for (let i = 0; i < at; i++) out[i] = sorted[i] as number
  out[at] = value
  for (let i = at; i < sorted.length; i++) out[i + 1] = sorted[i] as number
  return out
}

/**
 * Append one step duration to a sample list, warming the sorted memo for the
 * result.
 *
 * The fold appends one sample per finished step; sorting the whole list again
 * on every append would make a long session cost quadratic time per event, so
 * the ascending copy is grown by insertion instead.
 * @param samples - the previous sample list.
 * @param value - the duration to append.
 * @returns the new sample list.
 */
export function withSample(samples: readonly number[], value: number): readonly number[] {
  const next = [...samples, value]
  sortedByReference.set(next, insertSorted(sortedSamples(samples), value))
  return next
}

/** Ascending copy of a numeric list. */
export function ascending(values: readonly number[]): number[] {
  return [...values].sort((left, right) => left - right)
}

/** Ascending copy of the completed-turn step counts, cached per list reference. */
const anchors = new WeakMap<readonly number[], readonly number[]>()

/** Ascending step counts of the finished turns, memoised for as long as the list lives. */
function sortedCompletedSteps(completedTurnSteps: readonly number[]): readonly number[] {
  const cached = anchors.get(completedTurnSteps)
  if (cached !== undefined) return cached
  const sorted = ascending(completedTurnSteps)
  anchors.set(completedTurnSteps, sorted)
  return sorted
}

/**
 * Index of the first entry of an ascending list that is at least `value`.
 * @param sorted - ascending numeric list.
 * @param value - the lower bound to find.
 * @returns the index, or the list length when every entry is smaller.
 */
function lowerBound(sorted: readonly number[], value: number): number {
  let low = 0
  let high = sorted.length
  while (low < high) {
    const middle = (low + high) >>> 1
    if ((sorted[middle] as number) < value) low = middle + 1
    else high = middle
  }
  return low
}

/**
 * Expected total step count for a turn that has already completed `completedSteps`.
 *
 * The anchor is the median of the completed turns that were at least this long:
 * a turn that has already outlived the typical turn is expected to outlive it
 * further, but no faster than the observed distribution suggests. When no
 * completed turn was this long, grow the observed count by a fixed runway.
 *
 * Both the median of the whole history and the median of its `>= completedSteps`
 * suffix are read off one ascending copy, so a live turn costs a binary search
 * plus an index read per event instead of a filter and a sort.
 * @param completedTurnSteps - step counts of this session's completed turns.
 * @param completedSteps - steps completed in the open turn.
 * @returns the expected total step count, or undefined without history.
 */
export function expectedTotalSteps(
  completedTurnSteps: readonly number[],
  completedSteps: number,
): number | undefined {
  const sorted = sortedCompletedSteps(completedTurnSteps)
  const base = median(sorted) ?? BOOTSTRAP_EXPECTED_STEPS
  if (completedSteps <= 0) return base
  // Median of an ascending list is an index read, so the suffix needs no copy.
  const from = lowerBound(sorted, completedSteps)
  if (from < sorted.length) {
    const longer = sorted[from + Math.floor((sorted.length - from) / 2)] as number
    return Math.max(base, longer)
  }
  return Math.max(base, completedSteps + Math.max(OUTRUN_MINIMUM, Math.ceil(completedSteps * OUTRUN_GROWTH)))
}

/**
 * Derive one remaining-time core from the open turn's facts.
 *
 * The estimate is a robust per-step rate times the anchored expected step count.
 * The rate blends the live turn's own observed rate (elapsed over completed
 * steps, so it includes per-turn overhead) with the historical median step
 * duration. The published total is held while it still outruns the turn and
 * re-anchored to the live estimate once the turn runs past it, so the estimate
 * stays meaningful for arbitrarily long turns without reacting to every noisy
 * sample. `insufficient-data` omits every numeric field rather than guessing.
 * @param input - open-turn anchors and observed step samples.
 * @returns the shared prediction core.
 */
export function etaCore(input: EtaPredictionInput): EtaCore {
  const completedSteps = input.stepDurations.length
  const elapsedMs = Math.max(0, input.asOf - input.startTime)
  const historyRate = input.stepSamples.length === 0 ? undefined : rateProfile(input.stepSamples).historyRate
  const base: EtaCore = { elapsedMs, completedSteps, method: 'insufficient-data' }
  if (historyRate === undefined || historyRate <= 0) return base
  const expectedSteps = expectedTotalSteps(input.completedTurnSteps, completedSteps)
  if (expectedSteps === undefined || expectedSteps < 1) return base

  const currentRate = completedSteps >= 1 ? elapsedMs / completedSteps : undefined
  const blended = currentRate === undefined
    ? historyRate
    : (completedSteps * currentRate + HISTORY_PRIOR_STEPS * historyRate)
      / (completedSteps + HISTORY_PRIOR_STEPS)
  const meanStepMs = Math.min(
    Math.max(blended, RATE_FLOOR * historyRate),
    RATE_CEILING * historyRate,
  )
  const rawTotalMs = meanStepMs * expectedSteps
  const previousTotalMs = input.previousTotalMs
  let predictedTotalMs = previousTotalMs === undefined
    ? rawTotalMs
    : rawTotalMs > previousTotalMs && elapsedMs >= previousTotalMs * REANCHOR_AT
      ? rawTotalMs
      : Math.min(rawTotalMs, previousTotalMs)
  // Keep at least one step of runway while the turn is open, so the estimate
  // cannot report completion before the turn actually ends.
  if (predictedTotalMs <= elapsedMs) {
    predictedTotalMs = Math.max(rawTotalMs, elapsedMs + Math.max(meanStepMs, 1))
  }
  const remainingMs = Math.max(0, predictedTotalMs - elapsedMs)
  const { lowRate, highRate } = rateProfile(input.stepSamples)
  const interval: TurnEtaInterval = {
    lowMs: Math.max(0, Math.min(lowRate * expectedSteps, predictedTotalMs) - elapsedMs),
    highMs: Math.max(0, highRate * expectedSteps - elapsedMs),
  }
  return {
    ...base,
    expectedSteps,
    meanStepMs,
    predictedTotalMs,
    remainingMs,
    interval,
    method: 'step-mean',
  }
}

/**
 * The estimator's tuning constants, exported so a host — or a future agent
 * runtime that wants the same calibration — can read them instead of copying
 * numbers. The comments above each constant carry the measurement behind it.
 */
export const ETA_TUNING = {
  /** Prior weight, in steps, of the historical rate against the live rate. */
  HISTORY_PRIOR_STEPS,
  /** Percentile of the step-duration history read as the central rate. */
  RATE_PERCENTILE,
  /** Fraction of the published total the turn must reach before re-anchoring. */
  REANCHOR_AT,
  /** Cap, as a multiple of the median, applied before reading a high quantile. */
  OUTLIER_CAP,
  /** Safe bound on the blended per-step estimate, relative to the history. */
  RATE_FLOOR,
  RATE_CEILING,
  /** Runway kept when the turn already outran every finished turn. */
  OUTRUN_GROWTH,
  OUTRUN_MINIMUM,
  /** Expected number of steps before the session has any finished turn. */
  BOOTSTRAP_EXPECTED_STEPS,
} as const
