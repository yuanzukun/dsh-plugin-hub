/**
 * The \`turnEta\` projection unit: a pure whole-log fold of turn and step
 * events into the live remaining-time prediction the Web client renders under
 * the composer. State is plain JSON so the persisted projection cache can seed
 * a fold; the wire view reuses one object per state so an unchanged fold
 * publishes nothing.
 * @module @deepseek-ai/dsh-session-turn-eta/projection
 */

import { z } from 'zod'
import type { ProjectionDefinition } from '@deepseek-ai/dsh-session-projection'
import { etaCore, withSample } from './predict.ts'
import type { EtaCore } from './predict.ts'
import type { OpenTurnState, TurnEtaProjection, TurnEtaState } from './types.ts'

const openTurnSchema = z.object({
  turn: z.number().int().nonnegative(),
  startTime: z.number().nonnegative(),
  asOf: z.number().nonnegative(),
  stepDurations: z.array(z.number().nonnegative()),
  openStepStart: z.number().nonnegative().optional(),
  lastStep: z.number().int().nonnegative(),
  lastTotalMs: z.number().nonnegative().optional(),
}).strict()

const stateSchema: z.ZodType<TurnEtaState> = z.object({
  open: openTurnSchema.optional(),
  completedTurnSteps: z.array(z.number().int().nonnegative()),
  stepSamples: z.array(z.number().nonnegative()),
  last: z.object({
    turn: z.number().int().nonnegative(),
    durationMs: z.number().nonnegative(),
    stepCount: z.number().int().nonnegative(),
    completed: z.boolean(),
    reason: z.string(),
  }).strict().optional(),
}).strict()

const viewSchema: z.ZodType<TurnEtaProjection> = z.object({
  turn: z.number().int().nonnegative(),
  step: z.number().int().nonnegative(),
  open: z.boolean(),
  startTime: z.number().nonnegative(),
  elapsedMs: z.number().nonnegative(),
  completedSteps: z.number().int().nonnegative(),
  expectedSteps: z.number().nonnegative().optional(),
  meanStepMs: z.number().nonnegative().optional(),
  predictedTotalMs: z.number().nonnegative().optional(),
  remainingMs: z.number().nonnegative().optional(),
  interval: z.object({ lowMs: z.number().nonnegative(), highMs: z.number().nonnegative() }).strict().optional(),
  method: z.enum(['step-mean', 'insufficient-data']),
  completed: z.boolean().optional(),
  reason: z.string().optional(),
  durationMs: z.number().nonnegative().optional(),
}).strict()

/** The empty-log state; a fresh instance per fold, since a unit owns its state. */
export function emptyTurnEtaState(): TurnEtaState {
  return { completedTurnSteps: [], stepSamples: [] }
}

/** The wire view for one fold state; cached per state reference. */
const views = new WeakMap<TurnEtaState, TurnEtaProjection>()

/**
 * The prediction core already computed for one open-turn state, keyed by the
 * open object reference.
 *
 * Advancing the open turn has to run the estimator to refresh the monotonic
 * total anchor, and the view of the very same event would run it again with the
 * refreshed anchor. That second run is pure idempotence (see `etaCore`: feeding
 * back its own total can only reproduce it), so the first result is reused.
 */
const cores = new WeakMap<OpenTurnState, EtaCore>()

/**
 * Advance the open turn to \`asOf\` with a patch, refreshing the monotonic total
 * anchor so the next view reads the same total the estimator just published.
 */
function advanceOpen(
  state: TurnEtaState,
  open: OpenTurnState,
  asOf: number,
  patch: Partial<OpenTurnState>,
): OpenTurnState {
  const next: OpenTurnState = { ...open, ...patch, asOf }
  const core = etaCore({
    startTime: next.startTime,
    stepDurations: next.stepDurations,
    completedTurnSteps: state.completedTurnSteps,
    stepSamples: state.stepSamples,
    asOf,
    previousTotalMs: next.lastTotalMs,
  })
  const anchored: OpenTurnState = core.predictedTotalMs === undefined
    ? next
    : { ...next, lastTotalMs: core.predictedTotalMs }
  cores.set(anchored, core)
  return anchored
}

function computeView(state: TurnEtaState): TurnEtaProjection {
  const open = state.open
  if (open !== undefined) {
    const cached = cores.get(open)
    if (cached !== undefined) {
      return { turn: open.turn, step: open.lastStep, open: true, startTime: open.startTime, ...cached }
    }
    const core = etaCore({
      startTime: open.startTime,
      stepDurations: open.stepDurations,
      completedTurnSteps: state.completedTurnSteps,
      stepSamples: state.stepSamples,
      asOf: open.asOf,
      previousTotalMs: open.lastTotalMs,
    })
    return { turn: open.turn, step: open.lastStep, open: true, startTime: open.startTime, ...core }
  }
  const last = state.last
  if (last !== undefined) {
    return {
      turn: last.turn,
      step: 0,
      open: false,
      startTime: 0,
      elapsedMs: 0,
      completedSteps: last.stepCount,
      method: 'insufficient-data',
      completed: last.completed,
      reason: last.reason,
      durationMs: last.durationMs,
    }
  }
  return {
    turn: 0,
    step: 0,
    open: false,
    startTime: 0,
    elapsedMs: 0,
    completedSteps: 0,
    method: 'insufficient-data',
  }
}

/** The \`turnEta\` unit registered on \`ctx.sessionProjections\` (exported for the unit spec). */
export const turnEtaProjectionDefinition = {
  key: 'turnEta',
  stateVersion: 2,
  stateSchema,
  // The contract hands both the Session header and the fork-inherited prefix
  // length; this fold keeps nothing header-derived, so they are accepted and
  // ignored rather than dropped, which keeps the signature honest.
  init: (_header, _inheritedEventCount) => emptyTurnEtaState(),
  apply: (state, event) => {
    switch (event.type) {
      case 'turn/start':
        return {
          ...state,
          open: advanceOpen(state, {
            turn: event.data.turn,
            startTime: event.time,
            asOf: event.time,
            stepDurations: [],
            lastStep: 0,
          }, event.time, {}),
        }
      case 'step/start': {
        const open = state.open
        if (open === undefined || open.turn !== event.data.turn) return state
        return { ...state, open: advanceOpen(state, open, event.time, { openStepStart: event.time, lastStep: event.data.step }) }
      }
      case 'step/end': {
        const open = state.open
        if (open === undefined || open.turn !== event.data.turn) return state
        const stepDurations = open.openStepStart === undefined
          ? open.stepDurations
          : [...open.stepDurations, Math.max(0, event.time - open.openStepStart)]
        const stepSamples = open.openStepStart === undefined
          ? state.stepSamples
          : withSample(state.stepSamples, Math.max(0, event.time - open.openStepStart))
        const next = { ...state, stepSamples }
        return { ...next, open: advanceOpen(next, open, event.time, { stepDurations, openStepStart: undefined, lastStep: event.data.step }) }
      }
      case 'assistant/message':
      case 'tool/call':
      case 'tool/result': {
        const open = state.open
        if (open === undefined || open.turn !== event.data.turn) return state
        return { ...state, open: advanceOpen(state, open, event.time, { lastStep: event.data.step }) }
      }
      case 'turn/end': {
        const open = state.open
        if (open === undefined || open.turn !== event.data.turn) return state
        const completed = event.data.reason.kind === 'completed'
        const stepCount = open.stepDurations.length
        return {
          // Anchor on how long turns run, whatever closed them.
          completedTurnSteps: stepCount >= 1
            ? [...state.completedTurnSteps, stepCount]
            : state.completedTurnSteps,
          stepSamples: state.stepSamples,
          last: {
            turn: open.turn,
            durationMs: Math.max(0, event.time - open.startTime),
            stepCount: open.stepDurations.length,
            completed,
            reason: event.data.reason.kind,
          },
        }
      }
      default:
        return state
    }
  },
  wire: {
    viewSchema,
    view: (state) => {
      const cached = views.get(state)
      if (cached !== undefined) return cached
      const computed = computeView(state)
      views.set(state, computed)
      return computed
    },
  },
} satisfies ProjectionDefinition<'turnEta', TurnEtaState>
