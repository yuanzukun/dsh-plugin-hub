# 常见问题

按"你会看到的症状"排列。找到你那一条，照做即可。

---

## 0. 先做这一件事

不管遇到什么问题，**打开 DSH → 设置 → 插件 → 码道连接器 → 诊断 → 运行诊断**。

它会跑四步：凭证就绪 → 密钥协商 → 模型清单 → 积分额度。

- **四步全绿** → 账号和网络都没问题，问题在别处
- **哪一步红** → 就是卡在那一层，往下看对应那条

日志在 `%USERPROFILE%\.dsh-connect-madao\chat.log`，出问题时把最后几行贴出来最有用。

---

## 1. 装完了，但模型列表里没有码道的模型

**先确认插件真的装上了**：设置 → 插件，应该能看到「码道连接器」。

装上了但没模型，通常是这两个原因：

**① DSH 没重启**
装完插件必须重启 DSH。插件在 DSH 启动时注册模型路由。

**② 凭证没就绪**
插件的模型列表是"拿到凭证之后"才去网关拉的。凭证不通就没有模型。
→ 去账号页点「测试连接」，看哪一步红。

---

## 2. 测试连接红了，第一步「凭证就绪」失败

说明拿不到 AK/SK。插件按这个顺序找：

```
1. 环境变量 MADAO_AK / MADAO_SK
2. %APPDATA%\dsh-connect-madao\credentials.enc（加密文件）
3. 码道客户端的登录态
```

**三种都没有** → 去账号页填 AK/SK。

**怎么拿到 AK/SK**：

```
华为云控制台 → 右上角账号名 → 我的凭证 → 访问密钥 → 新增访问密钥
```

会下载一个 `credentials.csv`，里面的 `Access Key Id` 和 `Secret Access Key` 就是这两项。

> **Secret 只在创建时显示一次**，务必当场保存。丢了只能删掉重建。

**填完点「保存」** —— 会写进 `credentials.enc`（DPAPI 加密，绑定你的 Windows 账户）。

---

## 3. 报 `APIG.0301 Incorrect IAM authentication information`

AK 或 SK 不对。常见原因：

- 复制时多了空格 / 少了字符（SK 有 40 位）
- 把 `Access Key Id` 和 `Secret Access Key` 填反了
- 这个 AK 在控制台已经被停用或删除

去控制台核对一遍。如果是被停用了，新建一个。

---

## 4. 报 `APIG.0602 the security token has expired`

**这不是你的错，是临时凭证过期了。**

码道登录态的临时凭证只有 1 小时寿命。插件没法替你续（续期动作发生在码道的 Electron 进程里）。

**两种解法**：

- **临时**：打开一次码道客户端，让它刷新登录态，回来点「测试连接」
- **永久**：在账号页填自己的 AK/SK（推荐，插件会自动换 STS 并提前续期，永不失效）

账号页的「凭证从哪来」卡片会显示剩余时间，**不足 10 分钟时会变红提醒**。

---

## 5. 报 `TM.00001041 并发会话数已达上限(3个)`

码道网关限制**每个账号最多 3 个并发会话**。

插件已经用固定的 `user-session-id` 让整个 DSH 只占 1 个名额。还会撞的话：

- 你是不是**同时开着码道客户端**在对话？关掉它，或者错开用
- 是不是**几个人共用同一个 AK/SK**？共用一定会撞 —— 每人用自己的账号

---

## 6. 模型回了句空话，或者报 `EMPTY_RESPONSE`

这个错误历史上对应三个不同的原因，现在都已修复。如果你还遇到，先看 `chat.log` 里 `chat done` 那一行：

```
chat done stream model=GLM-5.2 finish=stop content=0(0段) reasoning=1752(308段) tool_calls=0帧
```

**① `tool_calls` 不是 0，但 `content` 是 0**
→ 正常。模型在调工具，不是产文本。0.4.1 之后这个场景正常透传。

**② `content` 和 `reasoning` 都是 0，`finish=stop`**
→ 输入超出上下文窗口了。换窗口更大的模型（DeepSeek-V4.1-Flash / GLM-5.3 / Kimi-K3 都是 1M），或者开新会话。

**③ 只有 `reasoning`，`content` 空，`finish=length`**
→ `max_tokens` 太小，思考把它吃光了。插件已兜底 65536，正常不会再出现。

---

## 7. 图片发不出去

**只有这几个模型支持图片**：

```
glm-5.3-flash
deepseek-v4.1-flash
deepseek-v4.1-flash-1017
kimi-k3
kimi-k3.1-pro
```

选别的模型发图，网关会拒绝。模型列表页里支持图片的行会显示 👁。

**另外注意**：大图的 token 开销很可观。一张 2 MB 的 PNG 转 base64 后约 20 万 tokens 量级，GLM-5.2（202K 窗口）可能一张图就顶满。建议先压到几百 KB 再发。

---

## 8. 模型页签打开是空白 / 报错

已修复（0.4.2）。如果还白屏，说明装的是旧版 —— 升到最新版即可。

---

## 9. 思考强度（Thinking 档位）切了没感觉

**能力已生效**（0.5.1 起），但不同模型的梯度不一样。

**GLM-5.2 / GLM-5.2-ArkTS-SPARK**（`high` / `max` 两档）梯度很小，实测同一道题各跑 3 次：

| 档位 | 思考长度 | 相对默认 |
|---|---|---|
| `high` | 1014 字 | −19% |
| 默认 | 1254 字 | — |
| `max` | 1323 字 | +5.5% |

**GLM-5.3 / GLM-5.3-Flash / DeepSeek-V4.1-Flash / Kimi-K3 等**（`low` / `high` / `max` 三档）
梯度明显得多，同样一道题：

| 档位 | 思考长度 |
|---|---|
| `low` | 295 字 |
| `high` | 330 字 |
| `max` | 684 字 |

所以：**要明显改变思考深度，用三档模型并选 `low` 或 `max`**；GLM-5.2 那两个只适合微调。

档位列表由网关动态下发（`POST /v1/model/thinking-variants`），码道更新后可能增加 ——
插件每次启动重新拉取，`cordis.patch.yml` 会随之刷新。

---


## 10. 每日签到点了没反应 / 按钮不见了

**先看状态**：账号页底部「每日签到」区。

- 显示「今日已签到，+100 积分已到账」→ 今天领过了，明天再来
- 显示「可领取 100 积分」+ 领取按钮 → 可以点
- 显示「签到状态暂时查询不到」→ 网络或凭证问题，去跑一次诊断

**签到的真实情况是**：调用 `POST /v1/ops/claim`，活动 `campaignId=34`。领到的积分有效期 1 天（`expireAt`），当天不用就没了。

> 插件**不会自动签到**。一天只有一次机会，必须你点按钮才执行。

---

## 11. 怎么彻底卸载

**① 卸载插件**

设置 → 插件 → 码道连接器 → 卸载。

或者命令行：

```powershell
pnpm --dir "%USERPROFILE%\.dsh\profiles\desktop" remove dsh-connect-madao
```

**② 删掉插件的数据（可选）**

```powershell
# 加密凭证 + 日志
Remove-Item "$env:APPDATA\dsh-connect-madao" -Recurse -Force
Remove-Item "$env:USERPROFILE\.dsh-connect-madao" -Recurse -Force
```

**③ 如果设过环境变量**

```powershell
[Environment]::SetEnvironmentVariable('MADAO_AK', $null, 'User')
[Environment]::SetEnvironmentVariable('MADAO_SK', $null, 'User')
```

**④ 重启 DSH**

DSH 会自动回到原来的模型（DeepSeek 官方）。插件不改动任何其他配置。

---

## 12. 我这台机器上它工作正常，换一台要重新配置吗

**要，但只需一步**：在新机器上填一次 AK/SK。

原因是凭证用 **Windows DPAPI 加密**，密钥绑定当前用户账户 —— 把 `credentials.enc` 拷到别的机器（或别的 Windows 账户）是解不开的，这是有意的。

**注意**：别把 `credentials.enc` 发给别人。虽然换机器解不开，但同账户下能读。

---

## 13. 我能不能把 AK/SK 给别人一起用

**技术上可以，实际别这么做。**

三个理由：

1. **并发会撞** —— 网关按账号限 3 个会话，共用必然打架
2. **AK/SK 等于你账号的完全访问权** —— 不只是码道，凡是这个 AK 权限内的操作都能做
3. **积分是同一个池子** —— 别人用就是从你的额度里扣

要分享，让对方去控制台自己建一个（30 秒的事）。

---

## 还没解决 / 已知限制

| 限制 | 说明 |
|---|---|
| 并发 3 会话 | 网关硬限制，插件只能缓解不能突破 |
| 码道登录态无法自动续期 | 续期在码道的 Electron 进程里，插件做不到 |
| 只有 Windows 有 DPAPI 加密 | Linux/macOS 上凭证是明文（会记日志提醒） |
| 图片不做压缩 | 大图很吃 token，需要自己先压 |
| 没有自动更新 | 升级要手动重装 |

---

## 还是解决不了？

去 [GitHub Issues](https://github.com/XLNC-L/dsh-connect-madao/issues) 提，**请附上**：

1. `chat.log` 的最后 10 行
2. 诊断页四步的结果（哪步红）
3. DSH 版本 + 插件版本

有这三样基本能定位。光说"不工作了"没法查。
