"""Fixed EastMoney (东方财富) public endpoint catalog."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

EastMoneyParameterType = Literal["integer", "string"]


@dataclass(frozen=True, slots=True)
class EastMoneyParameterSpec:
    """One validated query parameter accepted by an EastMoney endpoint."""

    name: str
    description: str
    value_type: EastMoneyParameterType
    required: bool = False
    default: str | int | None = None
    minimum: int | None = None
    maximum: int | None = None
    pattern: str | None = None
    min_length: int | None = None
    max_length: int | None = None


@dataclass(frozen=True, slots=True)
class EastMoneyEndpointSpec:
    """One user-visible EastMoney data endpoint."""

    endpoint_id: str
    name: str
    group: str
    summary: str
    features: tuple[str, ...]
    parameters: tuple[EastMoneyParameterSpec, ...]
    path: str = ""
    query_names: tuple[str, ...] = ()
    report_name: str | None = None
    sort_column: str | None = None
    sort_type: Literal[1, -1] | None = None


_REPORT_DAYS = EastMoneyParameterSpec(
    "days",
    "时间范围：0=当天，1=当天及前一天（默认），最多 30 天。",
    "integer",
    default=1,
    minimum=0,
    maximum=30,
)
_REPORT_TOP = EastMoneyParameterSpec(
    "top",
    "附带正文摘录的篇数，默认 3，上限 10；单篇最多 4000 字符。",
    "integer",
    default=3,
    minimum=1,
    maximum=10,
)
_REPORT_INDEX = EastMoneyParameterSpec(
    "index",
    "指定返回列表第 N 篇的正文摘录（1 起），传此参数时忽略 top。",
    "integer",
    minimum=1,
    maximum=100,
)
_SH_A_SHARE_CODE_PATTERN = r"(?:600|601|603|605|688)\d{3}"
_SZ_A_SHARE_CODE_PATTERN = r"(?:000|001|002|003|300|301)\d{3}"
_A_SHARE_CODE_PATTERN = rf"(?:{_SH_A_SHARE_CODE_PATTERN}|{_SZ_A_SHARE_CODE_PATTERN})"

_STOCK_CODE = EastMoneyParameterSpec(
    "stock_code",
    "沪深 A 股六位代码，如 600519。",
    "string",
    required=True,
    pattern=_A_SHARE_CODE_PATTERN,
)
_STOCK_REPORT_CONTENT = EastMoneyParameterSpec(
    "content",
    (
        "返回内容：summary（默认，最近研报及摘要）或 full（配合 art_code 返回单篇"
        "正文摘录，最多 4000 字符）。"
    ),
    "string",
    default="summary",
    pattern=r"summary|full",
)
_STOCK_REPORT_ART_CODE = EastMoneyParameterSpec(
    "art_code",
    "研报唯一编号；content=full 时必填，如 AP202607231827290069。",
    "string",
    pattern=r"[A-Za-z0-9_-]{1,64}",
)
_PAGE = EastMoneyParameterSpec(
    "page",
    "页码，从 1 开始，默认 1，最多 100。",
    "integer",
    default=1,
    minimum=1,
    maximum=100,
)
_F10_LIMIT = EastMoneyParameterSpec(
    "limit",
    "每页返回条数，默认 20，最多 100。历史数据请按页查询。",
    "integer",
    default=20,
    minimum=1,
    maximum=100,
)


def _f10_endpoint(
    *,
    endpoint_id: str,
    name: str,
    group: str,
    summary: str,
    features: tuple[str, ...],
    report_name: str,
    sort_column: str | None = None,
    sort_type: Literal[1, -1] = -1,
    parameters: tuple[EastMoneyParameterSpec, ...] = (
        _STOCK_CODE,
        _PAGE,
        _F10_LIMIT,
    ),
) -> EastMoneyEndpointSpec:
    """Build one bounded F10 datacenter endpoint specification."""

    return EastMoneyEndpointSpec(
        endpoint_id=endpoint_id,
        name=name,
        group=group,
        summary=summary,
        features=features,
        parameters=parameters,
        path="/securities/api/data/v1/get",
        query_names=tuple(item.name for item in parameters),
        report_name=report_name,
        sort_column=sort_column,
        sort_type=sort_type if sort_column is not None else None,
    )


EASTMONEY_ENDPOINTS: tuple[EastMoneyEndpointSpec, ...] = (
    _f10_endpoint(
        endpoint_id="em_stock_profile",
        name="公司概况",
        group="f10",
        summary="按股票代码查询公司名称、行业、主营业务、注册地、高管与简介。",
        features=("公司概况", "行业分类", "主营业务"),
        report_name="RPT_F10_ORG_BASICINFO",
        parameters=(_STOCK_CODE,),
    ),
    _f10_endpoint(
        endpoint_id="em_financial_summary",
        name="核心财务指标",
        group="financial",
        summary="查询最新报告期的 EPS、ROE、营收、净利润、毛利率与资产负债率。",
        features=("EPS", "ROE", "营收利润", "财务质量"),
        report_name="RPT_PCF10_FINANCEMAINFINADATA",
        sort_column="REPORT_DATE",
        parameters=(_STOCK_CODE,),
    ),
    _f10_endpoint(
        endpoint_id="em_quarterly_financials",
        name="季度财务数据",
        group="financial",
        summary="按报告期查询季度营收、利润、同比环比与核心财务指标历史序列。",
        features=("季度营收", "季度利润", "同比环比"),
        report_name="RPT_F10_QTR_MAINFINADATA",
        sort_column="REPORT_DATE",
    ),
    _f10_endpoint(
        endpoint_id="em_shareholder_counts",
        name="股东户数",
        group="ownership",
        summary="查询股东户数及其历史变化。",
        features=("股东户数", "户均持股", "变化趋势"),
        report_name="RPT_F10_EH_HOLDERNUM",
        sort_column="END_DATE",
    ),
    _f10_endpoint(
        endpoint_id="em_block_trades",
        name="大宗交易",
        group="trading_events",
        summary="查询个股大宗交易的成交日期、金额、折溢价与买卖方明细。",
        features=("成交金额", "折溢价", "交易双方"),
        report_name="RPT_DATA_BLOCKTRADE",
        sort_column="TRADE_DATE",
    ),
    _f10_endpoint(
        endpoint_id="em_margin_trading",
        name="融资融券",
        group="trading_events",
        summary="查询融资融券余额、买入额、偿还额及历史变化。",
        features=("融资余额", "融券余额", "两融变化"),
        report_name="RPT_MARGIN_STATISTICS_STOCKS",
        sort_column="TRADE_DATE",
    ),
    _f10_endpoint(
        endpoint_id="em_dragon_tiger_daily",
        name="龙虎榜上榜记录",
        group="trading_events",
        summary="查询个股龙虎榜上榜日期、异动原因与当日汇总。",
        features=("上榜日期", "异动原因", "买卖汇总"),
        report_name="RPT_BILLBOARD_DAILYDETAILS",
        sort_column="TRADE_DATE",
    ),
    _f10_endpoint(
        endpoint_id="em_dragon_tiger_departments",
        name="龙虎榜营业部交易",
        group="trading_events",
        summary="查询龙虎榜营业部席位的买入、卖出与净额明细。",
        features=("营业部席位", "买卖金额", "净买入"),
        report_name="RPT_OPERATEDEPT_TRADE",
        sort_column="TRADE_DATE",
    ),
    _f10_endpoint(
        endpoint_id="em_institutional_forecasts",
        name="机构盈利预测",
        group="research",
        summary="查询机构对营收、净利润、EPS 等指标的盈利预测。",
        features=("营收预测", "净利润预测", "EPS预测"),
        report_name="RPT_HSF10_RES_ORGPREDICT",
        sort_column="PUBLISH_DATE",
    ),
    _f10_endpoint(
        endpoint_id="em_rating_statistics",
        name="机构评级统计",
        group="research",
        summary="查询机构评级分布、评级变化与统计信息。",
        features=("买入评级", "增持评级", "评级统计"),
        report_name="RPT_HSF10_RESPREDICT_STATISTICS",
        sort_column="YEAR",
        sort_type=1,
    ),
    _f10_endpoint(
        endpoint_id="em_core_themes",
        name="核心题材",
        group="f10",
        summary="查询所属板块、经营范围、主营业务等 F10 核心题材要点。",
        features=("所属板块", "概念标签", "公司要点"),
        report_name="RPT_F10_CORETHEME_CONTENT",
    ),
    _f10_endpoint(
        endpoint_id="em_industry_comparison",
        name="行业对比",
        group="f10",
        summary="查询所属行业及同行公司的财务和估值对比数据。",
        features=("所属行业", "同行公司", "行业对比"),
        report_name="RPT_F10_INDUSTRY_COMPARED",
        sort_column="REPORT_DATE",
    ),
    _f10_endpoint(
        endpoint_id="em_valuation_percentiles",
        name="估值分位",
        group="valuation",
        summary="查询 PE、PB 等估值指标的历史分位信息。",
        features=("PE分位", "PB分位", "估值区间"),
        report_name="RPT_STOCKVALUATIONTANTILE",
    ),
    _f10_endpoint(
        endpoint_id="em_supplementary_indicators",
        name="补充指标",
        group="f10",
        summary="查询公司特有的补充经营、商品或行业指标；不保证属于财务指标。",
        features=("经营指标", "商品指标", "指标来源"),
        report_name="RPTA_DATA_IF_INDICATOR",
        sort_column="UPDATE_DATE",
    ),
    EastMoneyEndpointSpec(
        endpoint_id="em_stock_announcements",
        name="公司公告",
        group="disclosure",
        summary="按股票代码分页查询公司公告标题、日期和公告分类。",
        features=("公告列表", "公告分类", "发布日期"),
        parameters=(_STOCK_CODE, _PAGE, _F10_LIMIT),
        path="/api/security/ann",
        query_names=("stock_code", "page", "limit"),
    ),
    EastMoneyEndpointSpec(
        endpoint_id="em_strategy_reports",
        name="策略研报",
        group="research",
        summary="获取最近两个自然日的策略研报：机构聚合列表加前 N 篇正文摘录。",
        features=("策略列表", "前3篇摘录", "大盘观点"),
        parameters=(_REPORT_DAYS, _REPORT_TOP, _REPORT_INDEX),
        path="/reportapi.eastmoney.com/report/jg",
        query_names=("days", "top", "index"),
    ),
    EastMoneyEndpointSpec(
        endpoint_id="em_macro_reports",
        name="宏观研究",
        group="research",
        summary="获取最近两个自然日的宏观研究研报：机构聚合列表加前 N 篇正文摘录。",
        features=("宏观列表", "前3篇摘录", "宏观经济"),
        parameters=(_REPORT_DAYS, _REPORT_TOP, _REPORT_INDEX),
        path="/reportapi.eastmoney.com/report/jg",
        query_names=("days", "top", "index"),
    ),
    EastMoneyEndpointSpec(
        endpoint_id="em_broker_reports",
        name="券商晨报",
        group="research",
        summary="获取当天的券商晨报：机构聚合列表加前 N 篇正文摘录。",
        features=("当日晨报", "前3篇摘录", "盘前观点"),
        parameters=(
            EastMoneyParameterSpec(
                "days",
                "时间范围：0=当天，最多 30 天。",
                "integer",
                default=0,
                minimum=0,
                maximum=30,
            ),
            _REPORT_TOP,
            _REPORT_INDEX,
        ),
        path="/reportapi.eastmoney.com/report/jg",
        query_names=("days", "top", "index"),
    ),
    EastMoneyEndpointSpec(
        endpoint_id="em_industry_reports",
        name="行业研报",
        group="research",
        summary="获取最近两个自然日的行业研报：机构聚合列表加前 N 篇正文摘录。",
        features=("行业列表", "前3篇摘录", "行业景气"),
        parameters=(_REPORT_DAYS, _REPORT_TOP, _REPORT_INDEX),
        path="/reportapi.eastmoney.com/report/jg",
        query_names=("days", "top", "index"),
    ),
    EastMoneyEndpointSpec(
        endpoint_id="em_stock_reports",
        name="个股研报",
        group="research",
        summary=(
            "按股票代码返回最近 5 篇研报的摘要（最多 1000 字符）、"
            "评级、目标价与预测指标；可按研报编号读取单篇正文摘录（最多 4000 字符）。"
        ),
        features=("最近5篇", "研报摘要", "预测指标", "按编号正文摘录"),
        parameters=(
            _STOCK_CODE,
            _PAGE,
            EastMoneyParameterSpec(
                "limit",
                "每页研报条数，默认 5，最多 5；按页查询更早研报。",
                "integer",
                default=5,
                minimum=1,
                maximum=5,
            ),
            _STOCK_REPORT_CONTENT,
            _STOCK_REPORT_ART_CODE,
        ),
        path="/api/security/rep",
        query_names=("stock_code", "page", "limit", "content", "art_code"),
    ),
    EastMoneyEndpointSpec(
        endpoint_id="em_profit_forecast",
        name="盈利预测",
        group="research",
        summary="按股票代码查询机构盈利预测、评级汇总与目标价区间。",
        features=("机构评级", "EPS预测", "目标价"),
        parameters=(_STOCK_CODE,),
        path="/datacenter.eastmoney.com/securities/api/data/v1/get",
        query_names=("stock_code",),
    ),
    EastMoneyEndpointSpec(
        endpoint_id="em_top_news",
        name="要闻头条",
        group="news",
        summary="获取精选财经要闻标题与摘要。",
        features=("财经要闻", "当日焦点", "标题摘要"),
        parameters=(
            EastMoneyParameterSpec(
                "limit",
                "返回条数，默认 10，上限 20。",
                "integer",
                default=10,
                minimum=1,
                maximum=20,
            ),
        ),
        path="/newsapi.eastmoney.com/kuaixun/v1/getlist_101_ajaxResult",
        query_names=("limit",),
    ),
    EastMoneyEndpointSpec(
        endpoint_id="em_kuaixun",
        name="7x24快讯",
        group="news",
        summary="获取 7x24 实时快讯标题与摘要。",
        features=("实时快讯", "盘中动态"),
        parameters=(
            EastMoneyParameterSpec(
                "limit",
                "返回条数，默认 30，上限 100。",
                "integer",
                default=30,
                minimum=1,
                maximum=100,
            ),
        ),
        path="/newsapi.eastmoney.com/kuaixun/v1/getlist_102_ajaxResult",
        query_names=("limit",),
    ),
    EastMoneyEndpointSpec(
        endpoint_id="em_news_search",
        name="新闻搜索",
        group="news",
        summary="按关键词或股票代码搜索财经新闻，返回标题、摘要、媒体与链接。",
        features=("个股新闻", "主题检索", "正文摘要"),
        parameters=(
            EastMoneyParameterSpec(
                "keyword",
                "搜索关键词，如股票名称、代码或主题。",
                "string",
                required=True,
                min_length=1,
                max_length=100,
            ),
            EastMoneyParameterSpec(
                "limit",
                "返回条数，默认 10，上限 20。",
                "integer",
                default=10,
                minimum=1,
                maximum=20,
            ),
        ),
        path="/search-api-web.eastmoney.com/search/jsonp",
        query_names=("keyword", "limit"),
    ),
)

EASTMONEY_ENDPOINT_BY_ID = {item.endpoint_id: item for item in EASTMONEY_ENDPOINTS}


def get_eastmoney_endpoint(endpoint_id: str) -> EastMoneyEndpointSpec:
    """Return the endpoint spec or raise KeyError for unknown ids."""

    try:
        return EASTMONEY_ENDPOINT_BY_ID[endpoint_id]
    except KeyError as exc:
        raise KeyError(f"unknown EastMoney endpoint: {endpoint_id}") from exc


__all__ = [
    "EASTMONEY_ENDPOINT_BY_ID",
    "EASTMONEY_ENDPOINTS",
    "EastMoneyEndpointSpec",
    "EastMoneyParameterSpec",
    "EastMoneyParameterType",
    "get_eastmoney_endpoint",
]
