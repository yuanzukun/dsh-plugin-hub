import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { relative, resolve, sep } from 'node:path'

const outputDirectory = resolve(process.cwd(), process.argv[2] ?? 'lib')
const artifactPath = file => resolve(outputDirectory, file)
const required = [
  'index.js',
  'client.js',
  'types/index.d.ts',
  'types/client/index.d.ts',
  '.build-manifest.json',
]

const missing = required.filter(file => !existsSync(artifactPath(file)))
if (missing.length > 0) {
  throw new Error(`build did not produce required artifacts: ${missing.join(', ')}`)
}
if (!statSync(outputDirectory).isDirectory()) throw new Error(`build output is not a directory: ${outputDirectory}`)

const manifest = JSON.parse(readFileSync(artifactPath('.build-manifest.json'), 'utf8'))
if (!Array.isArray(manifest.files) || manifest.files.some(file => typeof file !== 'string')) {
  throw new Error('build manifest is invalid')
}
if (new Set(manifest.files).size !== manifest.files.length) {
  throw new Error('build manifest contains duplicate files')
}
const actualFiles = listFiles(outputDirectory)
  .map(file => relative(outputDirectory, file).split(sep).join('/'))
  .filter(file => file !== '.build-manifest.json')
  .sort()
if (actualFiles.length !== manifest.files.length || actualFiles.some((file, index) => file !== manifest.files[index])) {
  throw new Error('build manifest does not match the staged artifacts')
}
const manifestMissingArtifacts = required.slice(0, -1).filter(file => !manifest.files.includes(file))
if (manifestMissingArtifacts.length > 0) {
  throw new Error(`build manifest is missing required artifacts: ${manifestMissingArtifacts.join(', ')}`)
}

const emittedJavaScript = ['index.js', 'client.js']
const staleImports = emittedJavaScript.filter(file =>
  /(?:from\s+|require\()['"][^'"]+\.ts['"]/.test(readFileSync(artifactPath(file), 'utf8')))
if (staleImports.length > 0) {
  throw new Error(`emitted JavaScript still imports TypeScript sources: ${staleImports.join(', ')}`)
}

const client = readFileSync(artifactPath('client.js'), 'utf8')
if (!client.includes('window.__ModuleLoader__.load') || !client.includes('dsh-stock-market')) {
  throw new Error('client bundle does not register itself with the DSH module loader')
}

const cssLifecycleMarkers = [
  'Symbol.for("dsh-stock-market/css")',
  'tag.textContent = css',
  'dsh-stock-market: inline styles',
  'tag.remove()',
]
const missingCssLifecycleMarkers = cssLifecycleMarkers.filter(marker => !client.includes(marker))
if (missingCssLifecycleMarkers.length > 0) {
  throw new Error(`client bundle is missing CSS lifecycle support: ${missingCssLifecycleMarkers.join(', ')}`)
}

const [{ providerEndpointCount }, { STOCK_INTERFACE_SUMMARIES }] = await Promise.all([
  import(artifactPath('stock-api/catalog.js')),
  import(artifactPath('stock-api/interface-summary.js')),
])
const staleProviderCounts = STOCK_INTERFACE_SUMMARIES.filter(summary => (
  summary.endpointCount !== providerEndpointCount(summary.provider)
))
if (staleProviderCounts.length > 0) {
  throw new Error(`interface summary endpoint counts are stale: ${staleProviderCounts.map(item => item.provider).join(', ')}`)
}

function listFiles(directory) {
  const files = []
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = resolve(directory, entry.name)
    if (entry.isDirectory()) files.push(...listFiles(path))
    else if (entry.isFile()) files.push(path)
  }
  return files
}
