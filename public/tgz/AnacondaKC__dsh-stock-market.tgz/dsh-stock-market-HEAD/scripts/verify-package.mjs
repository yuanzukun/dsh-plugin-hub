import { existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, statSync, symlinkSync } from 'node:fs'
import { dirname, relative, resolve } from 'node:path'
import { tmpdir } from 'node:os'
import { spawnSync } from 'node:child_process'

const root = process.cwd()
const packageJson = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'))
const temporaryDirectory = mkdtempSync(resolve(tmpdir(), `${packageJson.name.replaceAll('/', '-')}-pack-`))
let tarballPath

try {
  const packed = run('npm', ['pack', '--json', '--ignore-scripts'], root, {
    ...process.env,
    // An outer `npm pack --dry-run` exports this flag to lifecycle scripts.
    // The verifier still needs a temporary tarball to inspect.
    npm_config_dry_run: 'false',
  })
  const tarball = JSON.parse(packed.stdout)[0]?.filename
  if (typeof tarball !== 'string' || tarball.length === 0) throw new Error('npm pack did not report a tarball filename')

  tarballPath = resolve(root, tarball)
  if (!existsSync(tarballPath)) throw new Error(`npm pack did not create ${tarball}`)
  run('tar', ['-xzf', tarballPath, '-C', temporaryDirectory], root)

  const unpacked = resolve(temporaryDirectory, 'package')
  const required = [
    'package.json',
    'README.md',
    'LICENSE',
    'cordis.patch.yml',
    'lib/index.js',
    'lib/client.js',
    'lib/types/index.d.ts',
    'lib/types/client/index.d.ts',
    'lib/.build-manifest.json',
  ]
  const missing = required.filter(file => !existsSync(resolve(unpacked, file)))
  if (missing.length > 0) throw new Error(`packed tarball is missing required files: ${missing.join(', ')}`)

  const packedManifest = JSON.parse(readFileSync(resolve(unpacked, 'package.json'), 'utf8'))
  if (packedManifest.private === true) throw new Error('packed package is still private')
  for (const entry of ['.', './client', './cordis.patch.yml']) {
    if (packedManifest.exports?.[entry] === undefined) throw new Error(`packed package is missing export ${entry}`)
  }

  const prohibited = ['src', 'tests', 'scripts', 'node_modules']
  const leaked = prohibited.filter(directory => existsSync(resolve(unpacked, directory)))
  if (leaked.length > 0) throw new Error(`packed tarball includes development-only directories: ${leaked.join(', ')}`)

  const files = listFiles(unpacked)
  if (files.length === 0) throw new Error('packed tarball is empty')
  verifyEntrypoints(unpacked)
  console.log(`verified ${tarball}: ${files.length} packaged files`)
} finally {
  if (tarballPath !== undefined) rmSync(tarballPath, { force: true })
  rmSync(temporaryDirectory, { recursive: true, force: true })
}

function verifyEntrypoints(directory) {
  mountPeerDependencies(directory)
  const program = [
    "import { pathToFileURL } from 'node:url'",
    "import { resolve } from 'node:path'",
    "const load = file => import(pathToFileURL(resolve(file)).href)",
    "const plugin = await load('./lib/index.js')",
    "if (plugin.name !== 'dsh-stock-market' || typeof plugin.apply !== 'function') {",
    "  throw new Error('packed server entry has an invalid DSH plugin export')",
    "}",
    "const registrations = []",
    "globalThis.window = { __ModuleLoader__: { load: value => registrations.push(value) } }",
    "await load('./lib/client.js')",
    "const registration = registrations[0]",
    "if (registrations.length !== 1 || registration?.id !== 'dsh-stock-market' || typeof registration.factory !== 'function') {",
    "  throw new Error('packed client entry does not register a DSH module')",
    "}",
  ].join(';')
  run(process.execPath, ['--input-type=module', '--eval', program], directory)
}

function mountPeerDependencies(directory) {
  for (const packageName of Object.keys(packageJson.peerDependencies ?? {})) {
    const target = resolve(root, 'node_modules', packageName)
    if (!existsSync(target)) {
      throw new Error(`declared peer dependency is unavailable for entrypoint verification: ${packageName}`)
    }
    const destination = resolve(directory, 'node_modules', packageName)
    mkdirSync(dirname(destination), { recursive: true })
    symlinkSync(
      process.platform === 'win32' ? target : relative(dirname(destination), target),
      destination,
      process.platform === 'win32' ? 'junction' : 'dir',
    )
  }
}

function listFiles(directory) {
  const files = []
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = resolve(directory, entry.name)
    if (entry.isDirectory()) files.push(...listFiles(path))
    else if (entry.isFile() && statSync(path).size >= 0) files.push(path)
  }
  return files
}

function run(command, args, cwd, env = process.env) {
  const result = spawnSync(command, args, { cwd, env, encoding: 'utf8', stdio: ['ignore', 'pipe', 'inherit'] })
  if (result.error !== undefined) throw result.error
  if (result.status !== 0) throw new Error(`${command} exited with status ${result.status ?? 'unknown'}`)
  return result
}
