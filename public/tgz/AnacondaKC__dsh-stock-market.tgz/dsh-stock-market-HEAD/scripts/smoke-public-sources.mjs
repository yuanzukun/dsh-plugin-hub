if (process.env.DSH_STOCK_MARKET_LIVE_SMOKE !== '1') {
  console.log('Live smoke test skipped. Set DSH_STOCK_MARKET_LIVE_SMOKE=1 to enable it.')
  process.exit(0)
}

const { StockApiService } = await import('../lib/stock-api/service.js')
const service = new StockApiService()
const signal = AbortSignal.timeout(30_000)
const scenarios = [
  ['eastmoney', () => service.executeEastMoney('em_realtime_quote', { secid: '1.600519' }, signal)],
  ['tencent', () => service.executeTencent('tx_realtime_quotes', { symbols: 'sh600519' }, signal)],
  ['sina', () => service.executeSina('sina_realtime_quotes', { symbols: 'sh600519' }, signal)],
  ['tonghuashun', () => service.executeTonghuashun('ths_intraday_trends', { symbol: 'hs_600519' }, signal)],
]

const failures = []
for (const [provider, request] of scenarios) {
  try {
    const result = await request()
    console.log(`${provider}: ${result.endpointId} ok`)
  } catch (error) {
    failures.push(`${provider}: ${error instanceof Error ? error.message : String(error)}`)
  }
}
if (failures.length > 0) throw new Error(`live public-source smoke test failed:\n${failures.join('\n')}`)
