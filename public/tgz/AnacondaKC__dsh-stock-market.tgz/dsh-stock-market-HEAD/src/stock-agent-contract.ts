import type { StockDataProvider } from './stock-api/types.ts'

export const STOCK_AGENT_TOOL_NAMES = [
  'stock_quote',
  'stock_chart',
  'stock_ranking',
  'stock_money_flow',
  'stock_fundamentals',
  'stock_events',
  'stock_research',
  'stock_news',
  'stock_capabilities',
] as const

export type StockAgentToolName = typeof STOCK_AGENT_TOOL_NAMES[number]

export interface StockActionDefinition {
  readonly name: string
  readonly summary: string
  readonly parameters: readonly string[]
  readonly sources: readonly StockDataProvider[]
  readonly fallback: 'equivalent' | 'methodology' | 'none'
}

export interface StockToolCapabilityDefinition {
  readonly name: StockAgentToolName
  readonly summary: string
  readonly actions: readonly StockActionDefinition[]
}

export const STOCK_TOOL_CAPABILITIES = [
  {
    name: 'stock_quote',
    summary: '查询一个或多个证券的实时行情快照。',
    actions: [
      action('snapshot', '批量实时价格、涨跌和成交快照。', ['symbols', 'detail?', 'source?'], ['tencent', 'eastmoney', 'sina'], 'equivalent'),
    ],
  },
  {
    name: 'stock_chart',
    summary: '查询标准化 K 线和分时走势。',
    actions: [
      action('kline', '查询日/周/月或分钟 K 线。', ['symbol', 'period?', 'adjust?', 'start_date?', 'end_date?', 'limit?', 'source?'], ['eastmoney', 'tencent', 'sina', 'tonghuashun'], 'equivalent'),
      action('intraday', '查询当日或近五日分时走势。', ['symbol', 'days?', 'limit?', 'source?'], ['eastmoney', 'tencent', 'tonghuashun'], 'equivalent'),
    ],
  },
  {
    name: 'stock_ranking',
    summary: '查询个股排行、板块排行、板块目录及成分股。',
    actions: [
      action('stocks', '按市场、指标和方向查询个股排行。', ['market?', 'sort?', 'order?', 'page?', 'limit?', 'source?'], ['eastmoney', 'tencent', 'sina'], 'methodology'),
      action('sectors', '查询行业或概念板块排行。', ['sector_type?', 'sort?', 'order?', 'page?', 'limit?', 'source?'], ['eastmoney', 'tencent', 'sina'], 'methodology'),
      action('sector_members', '按新浪板块 ID 查询成分股。', ['sector_id', 'sort?', 'order?', 'page?', 'limit?', 'source?'], ['sina'], 'none'),
      action('sector_catalog', '查询行业或概念板块 ID 目录；不接受 page/limit。', ['sector_type?', 'source?'], ['sina'], 'none'),
    ],
  },
  {
    name: 'stock_money_flow',
    summary: '查询个股、板块及沪深港通资金流。',
    actions: [
      action('stock_history', '查询个股历史资金流。', ['symbol', 'page?', 'limit?', 'source?'], ['eastmoney', 'sina'], 'methodology'),
      action('stock_intraday', '查询个股分钟级实时资金流。', ['symbol', 'limit?', 'source?'], ['eastmoney'], 'none'),
      action('sector', '按主力净流入查询行业或概念板块资金流。', ['sector_type?', 'page?', 'limit?', 'source?'], ['eastmoney', 'sina'], 'methodology'),
      action('connect', '查询南向分钟净流入；北向缺失时通过 unavailable_directions 明示。', ['direction?', 'limit?', 'source?'], ['eastmoney'], 'none'),
    ],
  },
  {
    name: 'stock_fundamentals',
    summary: '查询公司、财务、股东、估值和经营指标。',
    actions: [
      action('profile', '查询公司概况、核心题材和行业对比。', ['symbol', 'sections?', 'page?', 'limit?'], ['eastmoney'], 'none'),
      action('financials', '查询最新或季度财务指标。', ['symbol', 'mode?', 'page?', 'limit?'], ['eastmoney'], 'none'),
      action('shareholders', '查询股东户数历史。', ['symbol', 'page?', 'limit?'], ['eastmoney'], 'none'),
      action('valuation', '查询估值历史分位。', ['symbol', 'page?', 'limit?'], ['eastmoney'], 'none'),
      action('operating_indicators', '查询补充经营和行业指标。', ['symbol', 'page?', 'limit?'], ['eastmoney'], 'none'),
    ],
  },
  {
    name: 'stock_events',
    summary: '查询公告、交易事件和市场数据中心事件。',
    actions: [
      action('announcements', '查询个股公司公告。', ['symbol', 'page?', 'limit?', 'source?'], ['eastmoney', 'sina'], 'methodology'),
      action('block_trades', '查询个股大宗交易。', ['symbol', 'page?', 'limit?'], ['eastmoney'], 'none'),
      action('margin', '查询个股或全市场融资融券。', ['scope?', 'symbol?', 'page?', 'limit?'], ['eastmoney'], 'none'),
      action('dragon_tiger', '查询个股或全市场龙虎榜。', ['scope?', 'symbol?', 'include_departments?', 'page?', 'limit?', 'source?'], ['eastmoney', 'sina'], 'methodology'),
      action('economic_calendar', '查询财经事件日历。', ['page?', 'limit?'], ['eastmoney'], 'none'),
      action('convertible_bonds', '查询可转债数据。', ['page?', 'limit?'], ['eastmoney'], 'none'),
    ],
  },
  {
    name: 'stock_research',
    summary: '查询市场研报、个股研报、盈利预测和评级。',
    actions: [
      action('market_reports', '查询策略、宏观、券商晨报或行业研报。', ['category?', 'days?', 'top?', 'index?'], ['eastmoney'], 'none'),
      action('stock_reports', '查询个股研报摘要或单篇正文。', ['symbol', 'page?', 'limit?', 'content?', 'report_id?'], ['eastmoney'], 'none'),
      action('forecast', '查询盈利预测汇总或机构明细。', ['symbol', 'mode?', 'page?', 'limit?'], ['eastmoney'], 'none'),
      action('ratings', '查询机构评级统计。', ['symbol', 'page?', 'limit?'], ['eastmoney'], 'none'),
    ],
  },
  {
    name: 'stock_news',
    summary: '查询财经资讯、个股新闻、搜索和股吧内容。',
    actions: [
      action('feed', '查询要闻、快讯、频道或滚动新闻。', ['feed?', 'page?', 'limit?', 'source?'], ['eastmoney', 'sina'], 'methodology'),
      action('stock_news', '查询指定个股新闻。', ['symbol', 'page?', 'limit?', 'source?'], ['tencent', 'sina'], 'methodology'),
      action('search', '搜索新闻、股票、基金或股吧。', ['keyword', 'scope?', 'page?', 'limit?'], ['eastmoney'], 'none'),
      action('guba', 'mode=search 使用 keyword/page/limit；mode=stock_page 仅使用 symbol。', ['mode?', 'keyword?', 'symbol?', 'page?', 'limit?'], ['eastmoney'], 'none'),
    ],
  },
  {
    name: 'stock_capabilities',
    summary: '发现业务工具、动作、参数和可用免费数据源。',
    actions: [
      action('list', '列出全部工具，或列出指定工具的动作。', ['tool?'], [], 'none'),
      action('describe', '查看指定工具或动作的参数契约。', ['tool', 'target_action?'], [], 'none'),
      action('sources', '查看指定工具动作的数据源与切换口径。', ['tool', 'target_action'], [], 'none'),
    ],
  },
] as const satisfies readonly StockToolCapabilityDefinition[]

/** Internal adapter coverage. Endpoint IDs are never accepted by model-facing tools. */
export const STOCK_ACTION_ADAPTERS = {
  'stock_quote.snapshot': ['em_realtime_quote', 'em_batch_quotes', 'tx_realtime_quotes', 'sina_realtime_quotes'],
  'stock_chart.kline': ['em_price_history', 'tx_price_history', 'sina_price_history', 'sina_intraday_kline', 'ths_price_history'],
  'stock_chart.intraday': ['em_intraday_trends', 'tx_intraday_trends', 'ths_intraday_trends'],
  'stock_ranking.stocks': ['em_market_snapshot', 'tx_stock_rank', 'sina_market_snapshot'],
  'stock_ranking.sectors': ['em_market_snapshot', 'tx_sector_rank', 'sina_industry_overview'],
  'stock_ranking.sector_members': ['sina_market_snapshot'],
  'stock_ranking.sector_catalog': ['sina_industry_catalog', 'sina_concept_catalog'],
  'stock_money_flow.stock_history': ['em_money_flow_history', 'sina_stock_money_flow'],
  'stock_money_flow.stock_intraday': ['em_money_flow_intraday'],
  'stock_money_flow.sector': ['em_market_snapshot', 'sina_sector_money_flow'],
  'stock_money_flow.connect': ['em_connect_flow'],
  'stock_fundamentals.profile': ['em_stock_profile', 'em_core_themes', 'em_industry_comparison'],
  'stock_fundamentals.financials': ['em_financial_summary', 'em_quarterly_financials'],
  'stock_fundamentals.shareholders': ['em_shareholder_counts'],
  'stock_fundamentals.valuation': ['em_valuation_percentiles'],
  'stock_fundamentals.operating_indicators': ['em_supplementary_indicators'],
  'stock_events.announcements': ['em_stock_announcements', 'sina_stock_announcements_page'],
  'stock_events.block_trades': ['em_block_trades'],
  'stock_events.margin': ['em_margin_trading', 'em_datacenter_report'],
  'stock_events.dragon_tiger': ['em_dragon_tiger_daily', 'em_dragon_tiger_departments', 'em_datacenter_report', 'sina_dragon_tiger_page'],
  'stock_events.economic_calendar': ['em_datacenter_report'],
  'stock_events.convertible_bonds': ['em_datacenter_report'],
  'stock_research.market_reports': ['em_strategy_reports', 'em_macro_reports', 'em_broker_reports', 'em_industry_reports'],
  'stock_research.stock_reports': ['em_stock_reports'],
  'stock_research.forecast': ['em_profit_forecast', 'em_institutional_forecasts'],
  'stock_research.ratings': ['em_rating_statistics'],
  'stock_news.feed': ['em_top_news', 'em_kuaixun', 'em_channel_news', 'sina_rolling_news'],
  'stock_news.stock_news': ['tx_stock_news', 'sina_stock_news_page'],
  'stock_news.search': ['em_news_search', 'em_global_search'],
  'stock_news.guba': ['em_global_search', 'em_guba_page'],
  'stock_capabilities.list': [],
  'stock_capabilities.describe': [],
  'stock_capabilities.sources': [],
} as const satisfies Readonly<Record<`${StockAgentToolName}.${string}`, readonly string[]>>

export function findStockCapability(tool: string): StockToolCapabilityDefinition | undefined {
  return STOCK_TOOL_CAPABILITIES.find(candidate => candidate.name === tool)
}

function action(
  name: string,
  summary: string,
  parameters: readonly string[],
  sources: readonly StockDataProvider[],
  fallback: StockActionDefinition['fallback'],
): StockActionDefinition {
  return { name, summary, parameters, sources, fallback }
}
