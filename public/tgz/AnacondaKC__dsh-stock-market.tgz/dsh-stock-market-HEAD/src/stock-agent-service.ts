import {
  EASTMONEY_ENDPOINTS,
  SINA_ENDPOINTS,
  TENCENT_ENDPOINTS,
  TONGHUASHUN_ENDPOINTS,
} from './stock-api/catalog.ts'
import { StockApiError } from './stock-api/errors.ts'
import type { StockApiService } from './stock-api/service.ts'
import type {
  StockApiJson,
  StockApiResult,
  StockDataProvider,
} from './stock-api/types.ts'
import {
  STOCK_ACTION_ADAPTERS,
  STOCK_TOOL_CAPABILITIES,
  findStockCapability,
  type StockAgentToolName,
} from './stock-agent-contract.ts'

const PROVIDERS = ['eastmoney', 'tencent', 'sina', 'tonghuashun'] as const
const SOURCES = ['auto', ...PROVIDERS] as const
const KLINE_PERIODS = ['1m', '5m', '15m', '30m', '60m', 'day', 'week', 'month'] as const
const ADJUSTMENTS = ['none', 'qfq', 'hfq'] as const
const RANKING_SORTS = ['price', 'change_percent', 'volume', 'amount', 'turnover_rate', 'net_inflow'] as const
const MARKETS = ['all_a', 'sh_a', 'sz_a', 'chinext', 'star'] as const
const SECTOR_TYPES = ['industry', 'concept'] as const
const MAX_PAGE = 100
const MAX_PAGE_SIZE = 50
const MAX_KLINE_ITEMS = 300
const MAX_INTRADAY_ITEMS = 300
const MAX_QUOTE_SYMBOLS = 60

export interface StockAgentResult {
  readonly action: string
  readonly source: StockDataProvider | 'internal'
  readonly attempted_sources: readonly StockDataProvider[]
  readonly fallback_used: boolean
  readonly degraded: boolean
  readonly fetched_at: string
  readonly data: StockApiJson
  readonly warnings: readonly string[]
}

interface CanonicalSymbol {
  readonly canonical: string
  readonly code: string
  readonly market: 'SH' | 'SZ'
}

interface Candidate {
  readonly provider: StockDataProvider
  readonly endpointId: string
  readonly parameters: Record<string, StockApiJson>
  readonly normalize: (value: StockApiJson) => StockApiJson
  readonly degraded?: boolean
  readonly warning?: string
}

interface AggregateRequest {
  readonly key: string
  readonly endpointId: string
  readonly parameters: Record<string, StockApiJson>
}

type SourceChoice = typeof SOURCES[number]
type JsonRecord = Record<string, StockApiJson>

export class StockAgentService {
  constructor(
    private readonly api: StockApiService,
    private readonly now: () => Date = () => new Date(),
  ) {}

  async execute(tool: StockAgentToolName, input: unknown, signal: AbortSignal): Promise<StockAgentResult> {
    const args = requireRecord(input)
    switch (tool) {
      case 'stock_quote': return this.executeQuote(args, signal)
      case 'stock_chart': return this.executeChart(args, signal)
      case 'stock_ranking': return this.executeRanking(args, signal)
      case 'stock_money_flow': return this.executeMoneyFlow(args, signal)
      case 'stock_fundamentals': return this.executeFundamentals(args, signal)
      case 'stock_events': return this.executeEvents(args, signal)
      case 'stock_research': return this.executeResearch(args, signal)
      case 'stock_news': return this.executeNews(args, signal)
      case 'stock_capabilities': return this.executeCapabilities(args)
    }
  }

  private async executeQuote(args: Record<string, unknown>, signal: AbortSignal): Promise<StockAgentResult> {
    const action = requiredEnum(args, 'action', ['snapshot'] as const)
    assertAllowed(args, action, ['symbols', 'detail', 'source'])
    const symbols = symbolArray(args, 'symbols', MAX_QUOTE_SYMBOLS)
    const detail = optionalEnum(args, 'detail', ['basic', 'full'] as const, 'basic')
    if (detail === 'full' && symbols.length > 20) {
      throw badRequest('stock_quote.snapshot 在 detail=full 时最多接受 20 个证券代码。')
    }
    const source = sourceArg(args)
    const candidates: Candidate[] = []
    const tencentSymbols = symbols.map(toTencentSymbol)
    candidates.push({
      provider: 'tencent',
      endpointId: 'tx_realtime_quotes',
      parameters: { symbols: tencentSymbols.join(',') },
      normalize: value => normalizeQuotes('tencent', value, symbols, detail),
    })
    const endpointId = symbols.length === 1 && detail === 'full' ? 'em_realtime_quote' : 'em_batch_quotes'
    candidates.push({
      provider: 'eastmoney',
      endpointId,
      parameters: endpointId === 'em_realtime_quote'
        ? { secid: toEastMoneySecid(symbols[0]) }
        : { secids: symbols.map(toEastMoneySecid).join(',') },
      normalize: value => normalizeQuotes('eastmoney', value, symbols, detail),
      degraded: detail === 'full' && endpointId === 'em_batch_quotes',
      warning: detail === 'full' && endpointId === 'em_batch_quotes'
        ? '东方财富批量备用路径不提供完整的开高低和换手率字段。'
        : undefined,
    })
    candidates.push({
      provider: 'sina',
      endpointId: 'sina_realtime_quotes',
      parameters: { symbols: symbols.map(toSinaSymbol).join(',') },
      normalize: value => normalizeQuotes('sina', value, symbols, detail),
    })
    return this.runCandidates('snapshot', source, candidates, signal)
  }

  private async executeChart(args: Record<string, unknown>, signal: AbortSignal): Promise<StockAgentResult> {
    const action = requiredEnum(args, 'action', ['kline', 'intraday'] as const)
    if (action === 'kline') return this.executeKline(args, signal)
    return this.executeIntraday(args, signal)
  }

  private async executeKline(args: Record<string, unknown>, signal: AbortSignal): Promise<StockAgentResult> {
    assertAllowed(args, 'kline', ['symbol', 'period', 'adjust', 'start_date', 'end_date', 'limit', 'source'])
    const symbol = symbolArg(args)
    const period = optionalEnum(args, 'period', KLINE_PERIODS, 'day')
    const adjust = optionalEnum(args, 'adjust', ADJUSTMENTS, 'qfq')
    const startDate = optionalDate(args, 'start_date')
    const endDate = optionalDate(args, 'end_date')
    if (startDate !== undefined && endDate !== undefined && startDate > endDate) {
      throw badRequest('start_date 不能晚于 end_date。')
    }
    const limit = optionalInteger(args, 'limit', 120, 1, MAX_KLINE_ITEMS)
    const source = sourceArg(args)
    const candidates: Candidate[] = []

    candidates.push({
      provider: 'eastmoney',
      endpointId: 'em_price_history',
      parameters: {
        secid: toEastMoneySecid(symbol),
        period,
        adjust,
        begin: compactDate(startDate ?? '1990-01-01'),
        end: compactDate(endDate ?? '2050-01-01'),
        limit,
      },
      normalize: value => normalizeKline('eastmoney', value, symbol, period, adjust, limit),
    })

    if (period !== '1m') {
      const tencentPeriod = period.startsWith('m') ? period : period === 'day' || period === 'week' || period === 'month'
        ? period
        : `m${period.slice(0, -1)}`
      candidates.push({
        provider: 'tencent',
        endpointId: 'tx_price_history',
        parameters: {
          symbol: toTencentSymbol(symbol),
          period: tencentPeriod,
          ...(startDate === undefined ? {} : { start: startDate }),
          ...(endDate === undefined ? {} : { end: endDate }),
          limit,
          adjust,
        },
        normalize: value => normalizeKline('tencent', value, symbol, period, adjust, limit),
        degraded: true,
        warning: '腾讯 K 线不提供成交额，amount 返回 null。',
      })
    }

    if (
      period !== '1m'
      && adjust === 'none'
      && startDate === undefined
      && endDate === undefined
    ) {
      const scale = sinaScale(period)
      candidates.push({
        provider: 'sina',
        endpointId: period.endsWith('m') ? 'sina_intraday_kline' : 'sina_price_history',
        parameters: { symbol: toSinaSymbol(symbol), scale, limit },
        normalize: value => normalizeKline('sina', value, symbol, period, adjust, limit),
        degraded: true,
        warning: '新浪 K 线成交量口径与首选源可能不同。',
      })
    }

    if (
      period === 'day'
      && adjust === 'none'
      && startDate === undefined
      && endDate === undefined
    ) {
      candidates.push({
        provider: 'tonghuashun',
        endpointId: 'ths_price_history',
        parameters: { symbol: toTonghuashunSymbol(symbol), archive: 'last' },
        normalize: value => normalizeKline('tonghuashun', value, symbol, period, adjust, limit),
        degraded: true,
        warning: '同花顺日 K 为页面归档口径，成交量字段可能与首选源不同。',
      })
    }
    return this.runCandidates('kline', source, candidates, signal)
  }

  private async executeIntraday(args: Record<string, unknown>, signal: AbortSignal): Promise<StockAgentResult> {
    assertAllowed(args, 'intraday', ['symbol', 'days', 'limit', 'source'])
    const symbol = symbolArg(args)
    const days = optionalEnum(args, 'days', [1, 5] as const, 1)
    const limit = optionalInteger(args, 'limit', 120, 1, MAX_INTRADAY_ITEMS)
    const source = sourceArg(args)
    const candidates: Candidate[] = []
    candidates.push({
      provider: 'eastmoney',
      endpointId: 'em_intraday_trends',
      parameters: { secid: toEastMoneySecid(symbol), days },
      normalize: value => normalizeIntraday('eastmoney', value, symbol, days, limit),
    })
    if (days === 1) {
      candidates.push({
        provider: 'tencent',
        endpointId: 'tx_intraday_trends',
        parameters: { symbol: toTencentSymbol(symbol) },
        normalize: value => normalizeIntraday('tencent', value, symbol, days, limit),
      })
      candidates.push({
        provider: 'tonghuashun',
        endpointId: 'ths_intraday_trends',
        parameters: { symbol: toTonghuashunSymbol(symbol) },
        normalize: value => normalizeIntraday('tonghuashun', value, symbol, days, limit),
        degraded: true,
        warning: '同花顺分时成交字段采用页面累计口径。',
      })
    }
    return this.runCandidates('intraday', source, candidates, signal)
  }

  private async executeRanking(args: Record<string, unknown>, signal: AbortSignal): Promise<StockAgentResult> {
    const action = requiredEnum(args, 'action', ['stocks', 'sectors', 'sector_members', 'sector_catalog'] as const)
    if (action === 'stocks') return this.executeStockRanking(args, signal)
    if (action === 'sectors') return this.executeSectorRanking(args, signal)
    if (action === 'sector_members') return this.executeSectorMembers(args, signal)
    return this.executeSectorCatalog(args, signal)
  }

  private async executeStockRanking(args: Record<string, unknown>, signal: AbortSignal): Promise<StockAgentResult> {
    assertAllowed(args, 'stocks', ['market', 'sort', 'order', 'page', 'limit', 'source'])
    const market = optionalEnum(args, 'market', MARKETS, 'all_a')
    const sort = optionalEnum(args, 'sort', RANKING_SORTS, 'change_percent')
    const order = optionalEnum(args, 'order', ['asc', 'desc'] as const, 'desc')
    const page = optionalInteger(args, 'page', 1, 1, MAX_PAGE)
    const limit = optionalInteger(args, 'limit', 20, 1, MAX_PAGE_SIZE)
    const source = sourceArg(args)
    const candidates: Candidate[] = [{
      provider: 'eastmoney',
      endpointId: 'em_market_snapshot',
      parameters: { market, sort, order, page, limit },
      normalize: value => normalizeRanking(value, page, limit, order, sort, false),
    }]
    const txSort = tencentRankingSort(sort)
    if (market === 'all_a' && txSort !== undefined) {
      candidates.push({
        provider: 'tencent',
        endpointId: 'tx_stock_rank',
        parameters: { sort: txSort, order, offset: (page - 1) * limit, limit },
        normalize: value => normalizeRanking(value, page, limit, order, sort, false),
        degraded: true,
        warning: '腾讯排行的市场范围和指标口径可能与东方财富不同。',
      })
    }
    const sinaSort = sinaRankingSort(sort)
    if (sinaSort !== undefined) {
      candidates.push({
        provider: 'sina',
        endpointId: 'sina_market_snapshot',
        parameters: { node: sinaMarketNode(market), page, limit, sort: sinaSort, order },
        normalize: value => normalizeRanking(value, page, limit, order, sort, false),
        degraded: true,
        warning: '新浪排行的市场筛选和指标口径可能与东方财富不同。',
      })
    }
    return this.runCandidates('stocks', source, candidates, signal)
  }

  private async executeSectorRanking(args: Record<string, unknown>, signal: AbortSignal): Promise<StockAgentResult> {
    assertAllowed(args, 'sectors', ['sector_type', 'sort', 'order', 'page', 'limit', 'source'])
    const sectorType = optionalEnum(args, 'sector_type', SECTOR_TYPES, 'industry')
    const sort = optionalEnum(args, 'sort', RANKING_SORTS, 'change_percent')
    const order = optionalEnum(args, 'order', ['asc', 'desc'] as const, 'desc')
    const page = optionalInteger(args, 'page', 1, 1, MAX_PAGE)
    const limit = optionalInteger(args, 'limit', 20, 1, MAX_PAGE_SIZE)
    const source = sourceArg(args)
    const candidates: Candidate[] = [{
      provider: 'eastmoney',
      endpointId: 'em_market_snapshot',
      parameters: { market: sectorType, sort, order, page, limit },
      normalize: value => normalizeRanking(value, page, limit, order, sort, true),
    }]
    if (sort === 'price' || sort === 'change_percent') {
      candidates.push({
        provider: 'tencent',
        endpointId: 'tx_sector_rank',
        parameters: { sector_type: sectorType, sort: 'price', order, offset: (page - 1) * limit, limit },
        normalize: value => normalizeRanking(value, page, limit, order, sort, true),
        degraded: true,
        warning: '腾讯板块排行仅提供已验证的 price 排序，板块口径可能不同。',
      })
    }
    if (sectorType === 'industry') {
      candidates.push({
        provider: 'sina',
        endpointId: 'sina_industry_overview',
        parameters: {},
        normalize: value => normalizeRanking(value, page, limit, order, sort, true, true),
        degraded: true,
        warning: '新浪行业分类及统计口径可能与东方财富不同。',
      })
    }
    return this.runCandidates('sectors', source, candidates, signal)
  }

  private async executeSectorMembers(args: Record<string, unknown>, signal: AbortSignal): Promise<StockAgentResult> {
    assertAllowed(args, 'sector_members', ['sector_id', 'sort', 'order', 'page', 'limit', 'source'])
    const sectorId = requiredString(args, 'sector_id', /^[A-Za-z0-9_]{1,64}$/u)
    const sort = optionalEnum(args, 'sort', RANKING_SORTS, 'change_percent')
    const sinaSort = sinaRankingSort(sort)
    if (sinaSort === undefined) throw badRequest(`stock_ranking.sector_members 不支持 sort=${sort}。`)
    const order = optionalEnum(args, 'order', ['asc', 'desc'] as const, 'desc')
    const page = optionalInteger(args, 'page', 1, 1, MAX_PAGE)
    const limit = optionalInteger(args, 'limit', 20, 1, MAX_PAGE_SIZE)
    const source = sourceArg(args)
    return this.runCandidates('sector_members', source, [{
      provider: 'sina',
      endpointId: 'sina_market_snapshot',
      parameters: { node: sectorId, page, limit, sort: sinaSort, order },
      normalize: value => normalizeRanking(value, page, limit, order, sort, false),
    }], signal)
  }

  private async executeSectorCatalog(args: Record<string, unknown>, signal: AbortSignal): Promise<StockAgentResult> {
    assertAllowed(args, 'sector_catalog', ['sector_type', 'source'])
    const sectorType = optionalEnum(args, 'sector_type', SECTOR_TYPES, 'industry')
    const source = sourceArg(args)
    return this.runCandidates('sector_catalog', source, [{
      provider: 'sina',
      endpointId: sectorType === 'industry' ? 'sina_industry_catalog' : 'sina_concept_catalog',
      parameters: {},
      normalize: value => normalizeSectorCatalog(value, sectorType),
    }], signal)
  }

  private async executeMoneyFlow(args: Record<string, unknown>, signal: AbortSignal): Promise<StockAgentResult> {
    const action = requiredEnum(args, 'action', ['stock_history', 'stock_intraday', 'sector', 'connect'] as const)
    if (action === 'stock_history') {
      assertAllowed(args, action, ['symbol', 'page', 'limit', 'source'])
      const symbol = symbolArg(args)
      const page = optionalInteger(args, 'page', 1, 1, 20)
      const limit = optionalInteger(args, 'limit', 20, 1, MAX_PAGE_SIZE)
      const source = sourceArg(args)
      return this.runCandidates(action, source, [
        {
          provider: 'eastmoney', endpointId: 'em_money_flow_history',
          parameters: { secid: toEastMoneySecid(symbol), limit: page * limit },
          normalize: value => normalizeMoneyFlow(value, symbol, page, limit),
        },
        {
          provider: 'sina', endpointId: 'sina_stock_money_flow',
          parameters: { symbol: toSinaSymbol(symbol), page, limit },
          normalize: value => normalizeMoneyFlow(value, symbol, page, limit),
          degraded: true,
          warning: '新浪个股资金流的资金分类口径可能与东方财富不同。',
        },
      ], signal)
    }
    if (action === 'stock_intraday') {
      assertAllowed(args, action, ['symbol', 'limit', 'source'])
      const symbol = symbolArg(args)
      const limit = optionalInteger(args, 'limit', 120, 1, MAX_INTRADAY_ITEMS)
      const source = sourceArg(args)
      return this.runCandidates(action, source, [{
        provider: 'eastmoney', endpointId: 'em_money_flow_intraday',
        parameters: { secid: toEastMoneySecid(symbol), limit },
        normalize: value => normalizeMoneyFlow(value, symbol, 1, limit),
      }], signal)
    }
    if (action === 'sector') {
      assertAllowed(args, action, ['sector_type', 'page', 'limit', 'source'])
      const sectorType = optionalEnum(args, 'sector_type', SECTOR_TYPES, 'industry')
      const page = optionalInteger(args, 'page', 1, 1, MAX_PAGE)
      const limit = optionalInteger(args, 'limit', 20, 1, MAX_PAGE_SIZE)
      const source = sourceArg(args)
      return this.runCandidates(action, source, [
        {
          provider: 'eastmoney', endpointId: 'em_market_snapshot',
          parameters: { market: sectorType, sort: 'net_inflow', order: 'desc', page, limit },
          normalize: value => normalizeSectorMoneyFlow(value, sectorType, page, limit),
        },
        {
          provider: 'sina', endpointId: 'sina_sector_money_flow',
          parameters: { sector_type: sectorType, page, limit },
          normalize: value => normalizeSectorMoneyFlow(value, sectorType, page, limit),
          degraded: true,
          warning: '新浪板块分类和资金统计口径可能与东方财富不同。',
        },
      ], signal)
    }

    assertAllowed(args, action, ['direction', 'limit', 'source'])
    const direction = optionalEnum(args, 'direction', ['all', 'northbound', 'southbound'] as const, 'all')
    const limit = optionalInteger(args, 'limit', 120, 1, MAX_INTRADAY_ITEMS)
    const source = sourceArg(args)
    const result = await this.runCandidates(action, source, [{
      provider: 'eastmoney', endpointId: 'em_connect_flow', parameters: {},
      normalize: value => normalizeConnectFlow(value, direction, limit),
    }], signal)
    const unavailableDirections = connectUnavailableDirections(result.data)
    if (unavailableDirections.length === 0) return result
    return {
      ...result,
      degraded: true,
      warnings: [
        ...result.warnings,
        `沪深港通分钟净流入暂缺方向：${unavailableDirections.map(connectDirectionLabel).join('、')}。`,
      ],
    }
  }

  private async executeFundamentals(args: Record<string, unknown>, signal: AbortSignal): Promise<StockAgentResult> {
    const action = requiredEnum(args, 'action', ['profile', 'financials', 'shareholders', 'valuation', 'operating_indicators'] as const)
    if (action === 'profile') {
      assertAllowed(args, action, ['symbol', 'sections', 'page', 'limit'])
      const symbol = symbolArg(args)
      const sections = optionalStringArray(args, 'sections', ['company', 'themes', 'industry'] as const, ['company', 'themes', 'industry'])
      const page = optionalInteger(args, 'page', 1, 1, MAX_PAGE)
      const limit = optionalInteger(args, 'limit', 20, 1, MAX_PAGE_SIZE)
      const endpointBySection = {
        company: 'em_stock_profile',
        themes: 'em_core_themes',
        industry: 'em_industry_comparison',
      } as const
      return this.runEastMoneyAggregate(action, sections.map(section => {
        const parameters: Record<string, StockApiJson> = { stock_code: symbol.code }
        if (section !== 'company') Object.assign(parameters, { page, limit })
        return {
          key: section,
          endpointId: endpointBySection[section],
          parameters,
        }
      }), signal)
    }

    assertAllowed(args, action, ['symbol', 'mode', 'page', 'limit'])
    const symbol = symbolArg(args)
    const page = optionalInteger(args, 'page', 1, 1, MAX_PAGE)
    const limit = optionalInteger(args, 'limit', 20, 1, MAX_PAGE_SIZE)
    if (action === 'financials') {
      const mode = optionalEnum(args, 'mode', ['latest', 'quarterly'] as const, 'latest')
      if (mode === 'latest') {
        rejectPresent(args, 'page', 'stock_fundamentals.financials mode=latest')
        rejectPresent(args, 'limit', 'stock_fundamentals.financials mode=latest')
      }
      return this.runSingleEastMoney(action, mode === 'latest' ? 'em_financial_summary' : 'em_quarterly_financials', {
        stock_code: symbol.code,
        ...(mode === 'latest' ? {} : { page, limit }),
      }, signal)
    }
    if (Object.hasOwn(args, 'mode')) throw badRequest(`stock_fundamentals.${action} 不接受参数：mode。`)
    const endpointId = action === 'shareholders'
      ? 'em_shareholder_counts'
      : action === 'valuation'
        ? 'em_valuation_percentiles'
        : 'em_supplementary_indicators'
    return this.runSingleEastMoney(action, endpointId, { stock_code: symbol.code, page, limit }, signal)
  }

  private async executeEvents(args: Record<string, unknown>, signal: AbortSignal): Promise<StockAgentResult> {
    const action = requiredEnum(args, 'action', ['announcements', 'block_trades', 'margin', 'dragon_tiger', 'economic_calendar', 'convertible_bonds'] as const)
    if (action === 'announcements') {
      assertAllowed(args, action, ['symbol', 'page', 'limit', 'source'])
      const symbol = symbolArg(args)
      const page = optionalInteger(args, 'page', 1, 1, MAX_PAGE)
      const limit = optionalInteger(args, 'limit', 20, 1, MAX_PAGE_SIZE)
      const source = sourceArg(args)
      return this.runCandidates(action, source, [
        {
          provider: 'eastmoney', endpointId: 'em_stock_announcements',
          parameters: { stock_code: symbol.code, page, limit }, normalize: value => value,
        },
        {
          provider: 'sina', endpointId: 'sina_stock_announcements_page',
          parameters: { symbol: toSinaSymbol(symbol) }, normalize: value => normalizeHtmlPage(value, '公告'),
          degraded: true, warning: '新浪备用源仅提供公告页面文本，不包含结构化分页字段。',
        },
      ], signal)
    }
    if (action === 'block_trades') {
      assertAllowed(args, action, ['symbol', 'page', 'limit'])
      const symbol = symbolArg(args)
      return this.runSingleEastMoney(action, 'em_block_trades', pagedStockParameters(args, symbol), signal)
    }
    if (action === 'margin') {
      assertAllowed(args, action, ['scope', 'symbol', 'page', 'limit'])
      const scope = optionalEnum(args, 'scope', ['stock', 'market'] as const, 'stock')
      const page = optionalInteger(args, 'page', 1, 1, MAX_PAGE)
      const limit = optionalInteger(args, 'limit', 20, 1, MAX_PAGE_SIZE)
      if (scope === 'stock') {
        const symbol = symbolArg(args)
        return this.runSingleEastMoney(action, 'em_margin_trading', { stock_code: symbol.code, page, limit }, signal)
      }
      rejectPresent(args, 'symbol', 'stock_events.margin scope=market')
      return this.runSingleEastMoney(action, 'em_datacenter_report', { report: 'margin_detail', page, limit }, signal)
    }
    if (action === 'dragon_tiger') return this.executeDragonTiger(args, signal)

    assertAllowed(args, action, ['page', 'limit'])
    const page = optionalInteger(args, 'page', 1, 1, MAX_PAGE)
    const limit = optionalInteger(args, 'limit', 20, 1, MAX_PAGE_SIZE)
    return this.runSingleEastMoney(action, 'em_datacenter_report', {
      report: action === 'economic_calendar' ? 'economic_calendar' : 'convertible_bonds',
      page,
      limit,
    }, signal)
  }

  private async executeDragonTiger(args: Record<string, unknown>, signal: AbortSignal): Promise<StockAgentResult> {
    assertAllowed(args, 'dragon_tiger', ['scope', 'symbol', 'include_departments', 'page', 'limit', 'source'])
    const scope = optionalEnum(args, 'scope', ['stock', 'market'] as const, 'market')
    const page = optionalInteger(args, 'page', 1, 1, MAX_PAGE)
    const limit = optionalInteger(args, 'limit', 20, 1, MAX_PAGE_SIZE)
    const source = sourceArg(args)
    if (scope === 'stock') {
      const symbol = symbolArg(args)
      const includeDepartments = optionalBoolean(args, 'include_departments', false)
      if (source !== 'auto' && source !== 'eastmoney') {
        throw badRequest(`stock_events.dragon_tiger scope=stock 不支持 source=${source}。`)
      }
      return this.runEastMoneyAggregate('dragon_tiger', [
        { key: 'records', endpointId: 'em_dragon_tiger_daily', parameters: { stock_code: symbol.code, page, limit } },
        ...(includeDepartments ? [{
          key: 'departments', endpointId: 'em_dragon_tiger_departments', parameters: { stock_code: symbol.code, page, limit },
        }] : []),
      ], signal)
    }
    rejectPresent(args, 'symbol', 'stock_events.dragon_tiger scope=market')
    rejectPresent(args, 'include_departments', 'stock_events.dragon_tiger scope=market')
    return this.runCandidates('dragon_tiger', source, [
      {
        provider: 'eastmoney', endpointId: 'em_datacenter_report',
        parameters: { report: 'dragon_tiger', page, limit }, normalize: value => value,
      },
      {
        provider: 'sina', endpointId: 'sina_dragon_tiger_page', parameters: {},
        normalize: value => normalizeHtmlPage(value, '龙虎榜'), degraded: true,
        warning: '新浪备用源仅提供龙虎榜页面文本，不包含结构化分页字段。',
      },
    ], signal)
  }

  private async executeResearch(args: Record<string, unknown>, signal: AbortSignal): Promise<StockAgentResult> {
    const action = requiredEnum(args, 'action', ['market_reports', 'stock_reports', 'forecast', 'ratings'] as const)
    if (action === 'market_reports') {
      assertAllowed(args, action, ['category', 'days', 'top', 'index'])
      const category = optionalEnum(args, 'category', ['strategy', 'macro', 'broker', 'industry'] as const, 'strategy')
      const days = optionalInteger(args, 'days', category === 'broker' ? 0 : 1, 0, 30)
      const top = optionalInteger(args, 'top', 3, 1, 10)
      const index = optionalIntegerValue(args, 'index', 1, 100)
      const endpointByCategory = {
        strategy: 'em_strategy_reports', macro: 'em_macro_reports', broker: 'em_broker_reports', industry: 'em_industry_reports',
      } as const
      return this.runSingleEastMoney(action, endpointByCategory[category], {
        days,
        top,
        ...(index === undefined ? {} : { index }),
      }, signal)
    }
    if (action === 'stock_reports') {
      assertAllowed(args, action, ['symbol', 'page', 'limit', 'content', 'report_id'])
      const symbol = symbolArg(args)
      const page = optionalInteger(args, 'page', 1, 1, MAX_PAGE)
      const limit = optionalInteger(args, 'limit', 5, 1, 5)
      const content = optionalEnum(args, 'content', ['summary', 'full'] as const, 'summary')
      const reportId = optionalString(args, 'report_id', /^[A-Za-z0-9_-]{1,64}$/u)
      if (content === 'full' && reportId === undefined) throw badRequest('content=full 时必须提供 report_id。')
      if (content === 'summary' && reportId !== undefined) throw badRequest('report_id 只能与 content=full 一起使用。')
      return this.runSingleEastMoney(action, 'em_stock_reports', {
        stock_code: symbol.code, page, limit, content,
        ...(reportId === undefined ? {} : { art_code: reportId }),
      }, signal)
    }
    if (action === 'forecast') {
      assertAllowed(args, action, ['symbol', 'mode', 'page', 'limit'])
      const symbol = symbolArg(args)
      const mode = optionalEnum(args, 'mode', ['summary', 'institutions'] as const, 'summary')
      if (mode === 'summary') {
        rejectPresent(args, 'page', 'stock_research.forecast mode=summary')
        rejectPresent(args, 'limit', 'stock_research.forecast mode=summary')
        return this.runSingleEastMoney(action, 'em_profit_forecast', { stock_code: symbol.code }, signal)
      }
      const page = optionalInteger(args, 'page', 1, 1, MAX_PAGE)
      const limit = optionalInteger(args, 'limit', 20, 1, MAX_PAGE_SIZE)
      return this.runSingleEastMoney(action, 'em_institutional_forecasts', { stock_code: symbol.code, page, limit }, signal)
    }

    assertAllowed(args, action, ['symbol', 'page', 'limit'])
    const symbol = symbolArg(args)
    return this.runSingleEastMoney(action, 'em_rating_statistics', pagedStockParameters(args, symbol), signal)
  }

  private async executeNews(args: Record<string, unknown>, signal: AbortSignal): Promise<StockAgentResult> {
    const action = requiredEnum(args, 'action', ['feed', 'stock_news', 'search', 'guba'] as const)
    if (action === 'feed') return this.executeNewsFeed(args, signal)
    if (action === 'stock_news') {
      assertAllowed(args, action, ['symbol', 'page', 'limit', 'source'])
      const symbol = symbolArg(args)
      const page = optionalInteger(args, 'page', 1, 1, MAX_PAGE)
      const limit = optionalInteger(args, 'limit', 10, 1, MAX_PAGE_SIZE)
      const source = sourceArg(args)
      const candidates: Candidate[] = [{
        provider: 'tencent', endpointId: 'tx_stock_news',
        parameters: { symbol: toTencentSymbol(symbol), page, limit },
        normalize: value => normalizeGenericItems(value, page, limit),
      }]
      candidates.push({
        provider: 'sina', endpointId: 'sina_stock_news_page',
        parameters: { symbol: toSinaSymbol(symbol) }, normalize: value => normalizeHtmlPage(value, '个股新闻'),
        degraded: true, warning: '新浪备用源仅提供个股新闻页面文本，不包含结构化分页字段。',
      })
      return this.runCandidates(action, source, candidates, signal)
    }
    if (action === 'search') {
      assertAllowed(args, action, ['keyword', 'scope', 'page', 'limit'])
      const keyword = requiredString(args, 'keyword', /^.{1,100}$/u)
      const scope = optionalEnum(args, 'scope', ['news', 'stock', 'fund', 'guba'] as const, 'news')
      const page = optionalInteger(args, 'page', 1, 1, MAX_PAGE)
      const limit = optionalInteger(args, 'limit', 10, 1, 20)
      const candidates: Candidate[] = [{
        provider: 'eastmoney', endpointId: 'em_global_search',
        parameters: { keyword, scope, page, limit }, normalize: value => normalizeSearch(value, scope, page, limit),
      }]
      if (scope === 'news' && page === 1) {
        candidates.push({
          provider: 'eastmoney', endpointId: 'em_news_search', parameters: { keyword, limit },
          normalize: value => normalizeSearch(value, scope, page, limit),
        })
      }
      return this.runCandidates(action, 'auto', candidates, signal)
    }

    assertAllowed(args, action, ['mode', 'keyword', 'symbol', 'page', 'limit'])
    const mode = optionalEnum(args, 'mode', ['search', 'stock_page'] as const, 'search')
    if (mode === 'search') {
      rejectPresent(args, 'symbol', 'stock_news.guba mode=search')
      const keyword = requiredString(args, 'keyword', /^.{1,100}$/u)
      const page = optionalInteger(args, 'page', 1, 1, MAX_PAGE)
      const limit = optionalInteger(args, 'limit', 10, 1, 20)
      return this.runSingleEastMoney(action, 'em_global_search', { keyword, scope: 'guba', page, limit }, signal, value => (
        normalizeSearch(value, 'guba', page, limit)
      ))
    }
    rejectPresent(args, 'keyword', 'stock_news.guba mode=stock_page')
    rejectPresent(args, 'page', 'stock_news.guba mode=stock_page')
    rejectPresent(args, 'limit', 'stock_news.guba mode=stock_page')
    const symbol = symbolArg(args)
    return this.runSingleEastMoney(action, 'em_guba_page', { stock_code: symbol.code }, signal, value => (
      normalizeHtmlPage(value, '股吧')
    ), true, '股吧接口提供经清洗的页面文本，不保证帖子字段完整。')
  }

  private async executeNewsFeed(args: Record<string, unknown>, signal: AbortSignal): Promise<StockAgentResult> {
    assertAllowed(args, 'feed', ['feed', 'page', 'limit', 'source'])
    const feed = optionalEnum(args, 'feed', ['headlines', 'flash', 'finance', 'global', 'stocks', 'money'] as const, 'headlines')
    const page = optionalInteger(args, 'page', 1, 1, MAX_PAGE)
    const defaultLimit = feed === 'flash' ? 30 : 10
    const limit = optionalInteger(args, 'limit', defaultLimit, 1, feed === 'flash' ? 50 : MAX_PAGE_SIZE)
    const source = sourceArg(args)
    const candidates: Candidate[] = []
    if (feed === 'headlines' || feed === 'flash') {
      if (page !== 1) throw badRequest(`stock_news.feed feed=${feed} 只支持 page=1。`)
      candidates.push({
        provider: 'eastmoney', endpointId: feed === 'headlines' ? 'em_top_news' : 'em_kuaixun',
        parameters: { limit }, normalize: value => normalizeFeed(value, page, limit),
      })
      candidates.push({
        provider: 'sina', endpointId: 'sina_rolling_news',
        parameters: { channel: feed === 'headlines' ? 'finance' : 'stocks', page: 1, limit },
        normalize: value => normalizeFeed(value, page, limit),
        degraded: true,
        warning: feed === 'headlines'
          ? '新浪财经滚动流与精选头条的选稿口径不同。'
          : '新浪股票滚动流不是严格的 7x24 快讯口径。',
      })
    } else if (feed === 'finance' || feed === 'global') {
      candidates.push({
        provider: 'eastmoney', endpointId: 'em_channel_news',
        parameters: { channel: feed, page, limit }, normalize: value => normalizeFeed(value, page, limit),
      })
      if (feed === 'finance') {
        candidates.push({
          provider: 'sina', endpointId: 'sina_rolling_news',
          parameters: { channel: 'finance', page, limit }, normalize: value => normalizeFeed(value, page, limit),
          degraded: true, warning: '新浪财经滚动流与东方财富频道资讯的选稿口径不同。',
        })
      }
    } else {
      candidates.push({
        provider: 'sina', endpointId: 'sina_rolling_news',
        parameters: { channel: feed, page, limit }, normalize: value => normalizeFeed(value, page, limit),
      })
    }
    return this.runCandidates('feed', source, candidates, signal)
  }

  private executeCapabilities(args: Record<string, unknown>): StockAgentResult {
    const action = requiredEnum(args, 'action', ['list', 'describe', 'sources'] as const)
    const interfaceCount = EASTMONEY_ENDPOINTS.length + TENCENT_ENDPOINTS.length + SINA_ENDPOINTS.length + TONGHUASHUN_ENDPOINTS.length
    let data: StockApiJson
    if (action === 'list') {
      assertAllowed(args, action, ['tool'])
      const tool = optionalString(args, 'tool')
      if (tool === undefined) {
        data = {
          tool_count: STOCK_TOOL_CAPABILITIES.length,
          internal_interface_count: interfaceCount,
          tools: STOCK_TOOL_CAPABILITIES.map(item => ({
            name: item.name,
            summary: item.summary,
            actions: item.actions.map(candidate => candidate.name),
          })),
        }
      } else {
        const capability = requireCapability(tool)
        data = {
          name: capability.name,
          summary: capability.summary,
          actions: capability.actions.map(candidate => ({ name: candidate.name, summary: candidate.summary })),
        }
      }
    } else {
      assertAllowed(args, action, ['tool', 'target_action'])
      const capability = requireCapability(requiredString(args, 'tool'))
      const targetAction = optionalString(args, 'target_action')
      if (action === 'sources' && targetAction === undefined) {
        throw badRequest('stock_capabilities.sources 必须提供 target_action。')
      }
      const actions = targetAction === undefined
        ? capability.actions
        : [requireCapabilityAction(capability, targetAction)]
      data = action === 'describe'
        ? {
            name: capability.name,
            summary: capability.summary,
            actions: actions.map(candidate => ({
              name: candidate.name,
              summary: candidate.summary,
              parameters: [...candidate.parameters],
            })),
          }
        : {
            tool: capability.name,
            actions: actions.map(candidate => ({
              name: candidate.name,
              sources: [...candidate.sources],
              fallback: candidate.fallback,
              fallback_note: fallbackNote(candidate.fallback),
            })),
          }
    }
    return {
      action,
      source: 'internal',
      attempted_sources: [],
      fallback_used: false,
      degraded: false,
      fetched_at: this.now().toISOString(),
      data,
      warnings: [],
    }
  }

  private async runSingleEastMoney(
    action: string,
    endpointId: string,
    parameters: Record<string, StockApiJson>,
    signal: AbortSignal,
    normalize: (value: StockApiJson) => StockApiJson = value => value,
    degraded = false,
    warning?: string,
  ): Promise<StockAgentResult> {
    return this.runCandidates(action, 'auto', [{
      provider: 'eastmoney', endpointId, parameters, normalize, degraded, warning,
    }], signal)
  }

  private async runEastMoneyAggregate(
    action: string,
    requests: readonly AggregateRequest[],
    signal: AbortSignal,
  ): Promise<StockAgentResult> {
    const outcomes = await Promise.allSettled(requests.map(request => (
      this.api.executeEastMoney(request.endpointId, request.parameters, signal)
    )))
    if (signal.aborted) throw new StockApiError('请求已取消。', 'cancelled')
    const data: JsonRecord = {}
    const unavailable: string[] = []
    const fetchedAt: string[] = []
    for (const [index, outcome] of outcomes.entries()) {
      const request = requests[index]
      if (outcome.status === 'fulfilled') {
        data[request.key] = outcome.value.data
        fetchedAt.push(outcome.value.fetchedAt)
      } else {
        if (isFatalError(outcome.reason) || !isFallbackError(outcome.reason)) throw outcome.reason
        unavailable.push(request.key)
      }
    }
    if (fetchedAt.length === 0) throw new StockApiError(`${action} 的免费数据源暂时不可用。`, 'unavailable')
    return {
      action,
      source: 'eastmoney',
      attempted_sources: ['eastmoney'],
      fallback_used: false,
      degraded: unavailable.length > 0,
      fetched_at: fetchedAt.sort().at(-1) ?? this.now().toISOString(),
      data: { ...data, unavailable_sections: unavailable },
      warnings: unavailable.length === 0 ? [] : [`部分数据暂不可用：${unavailable.join('、')}。`],
    }
  }

  private async runCandidates(
    action: string,
    source: SourceChoice,
    candidates: readonly Candidate[],
    signal: AbortSignal,
  ): Promise<StockAgentResult> {
    const selected = source === 'auto' ? candidates : candidates.filter(candidate => candidate.provider === source)
    if (selected.length === 0) {
      throw badRequest(`${action} 不支持 source=${source} 或当前参数组合。`)
    }
    const attempted: StockDataProvider[] = []
    let failures = 0
    let previousProvider: StockDataProvider | undefined
    let lastFallbackError: StockApiError | undefined
    for (const candidate of selected) {
      if (!attempted.includes(candidate.provider)) attempted.push(candidate.provider)
      try {
        const response = await this.executeCandidate(candidate, signal)
        const data = candidate.normalize(response.data)
        const fallbackUsed = failures > 0
        const warnings: string[] = []
        if (fallbackUsed) {
          warnings.push(previousProvider === candidate.provider
            ? `首选数据适配路径不可用，已使用 ${providerLabel(candidate.provider)} 的备用路径。`
            : `首选免费数据源不可用，已切换至 ${providerLabel(candidate.provider)}。`)
        }
        if (candidate.warning !== undefined) warnings.push(candidate.warning)
        return {
          action,
          source: response.provider,
          attempted_sources: attempted,
          fallback_used: fallbackUsed,
          degraded: candidate.degraded === true,
          fetched_at: response.fetchedAt,
          data,
          warnings,
        }
      } catch (error) {
        if (isFatalError(error) || !isFallbackError(error)) throw error
        failures++
        previousProvider = candidate.provider
        lastFallbackError = error
      }
    }
    if (source !== 'auto' && lastFallbackError !== undefined) throw lastFallbackError
    throw new StockApiError(`${action} 的免费数据源暂时不可用。`, 'unavailable')
  }

  private executeCandidate(candidate: Candidate, signal: AbortSignal): Promise<StockApiResult> {
    switch (candidate.provider) {
      case 'eastmoney': return this.api.executeEastMoney(candidate.endpointId, candidate.parameters, signal)
      case 'tencent': return this.api.executeTencent(candidate.endpointId, candidate.parameters, signal)
      case 'sina': return this.api.executeSina(candidate.endpointId, candidate.parameters, signal)
      case 'tonghuashun': return this.api.executeTonghuashun(candidate.endpointId, candidate.parameters, signal)
    }
  }
}

function normalizeQuotes(
  provider: StockDataProvider,
  value: StockApiJson,
  requested: readonly CanonicalSymbol[],
  detail: 'basic' | 'full',
): StockApiJson {
  const root = asRecord(value)
  let rows: readonly StockApiJson[] | undefined
  if (provider === 'eastmoney') {
    const data = asRecord(root?.data)
    rows = Array.isArray(data?.diff) ? data.diff : data === undefined ? undefined : [data]
  } else {
    rows = Array.isArray(root?.quotes) ? root.quotes : undefined
  }
  if (rows === undefined) throw invalidUpstream('实时行情')

  const quotes: StockApiJson[] = []
  const returned = new Set<string>()
  for (const item of rows) {
    const row = asRecord(item)
    if (row === undefined) continue
    const symbol = matchRequestedSymbol(provider, row, requested)
    if (symbol === undefined || returned.has(symbol.canonical)) continue
    const price = provider === 'eastmoney'
      ? numberOrNull(row.f43 ?? row.f2)
      : numberOrNull(row.price)
    const previousClose = provider === 'eastmoney'
      ? numberOrNull(row.f60 ?? row.f18)
      : numberOrNull(row.previous_close)
    const change = provider === 'eastmoney'
      ? numberOrNull(row.f169 ?? row.f4)
      : numberOrNull(row.change)
    const changePercent = provider === 'eastmoney'
      ? numberOrNull(row.f170 ?? row.f3)
      : numberOrNull(row.change_percent)
    const name = textOrEmpty(provider === 'eastmoney' ? row.f58 ?? row.f14 : row.name)
    const base: JsonRecord = {
      symbol: symbol.canonical,
      name,
      price,
      previous_close: previousClose,
      change: change ?? calculateChange(price, previousClose),
      change_percent: changePercent ?? calculateChangePercent(price, previousClose),
      market_time: quoteTime(provider, row),
    }
    if (detail === 'full') {
      const rawVolume = provider === 'eastmoney'
        ? numberOrNull(row.f47 ?? row.f5)
        : provider === 'tencent'
          ? numberOrNull(row.volume_lots)
          : numberOrNull(row.volume_shares)
      const rawAmount = provider === 'eastmoney'
        ? numberOrNull(row.f48 ?? row.f6)
        : provider === 'tencent'
          ? multiplyOrNull(numberOrNull(row.amount_ten_thousand_cny), 10_000)
          : numberOrNull(row.amount_cny)
      Object.assign(base, {
        open: provider === 'eastmoney' ? numberOrNull(row.f46 ?? row.f17) : numberOrNull(row.open),
        high: provider === 'eastmoney' ? numberOrNull(row.f44 ?? row.f15) : numberOrNull(row.high),
        low: provider === 'eastmoney' ? numberOrNull(row.f45 ?? row.f16) : numberOrNull(row.low),
        volume_shares: normalizeShareVolume(provider, symbol, rawVolume),
        amount: rawAmount,
        amount_currency: 'CNY',
        turnover_rate: provider === 'eastmoney' ? numberOrNull(row.f168 ?? row.f8) : numberOrNull(row.turnover_rate),
      })
    }
    quotes.push(base)
    returned.add(symbol.canonical)
  }
  return {
    detail,
    quotes,
    unavailable_symbols: requested.filter(symbol => !returned.has(symbol.canonical)).map(symbol => symbol.canonical),
  }
}

function normalizeKline(
  provider: StockDataProvider,
  value: StockApiJson,
  symbol: CanonicalSymbol,
  period: string,
  adjust: string,
  limit: number,
): StockApiJson {
  const rows = klineRows(provider, value, period, adjust)
  const byTime = new Map<string, JsonRecord>()
  for (const row of rows) {
    const parsed = parseKlineRow(provider, row, symbol)
    if (parsed !== undefined) byTime.set(parsed.time as string, parsed)
  }
  const bars = [...byTime.values()].slice(-limit)
  if (bars.length === 0) throw invalidUpstream('K 线')
  return { symbol: symbol.canonical, period, adjust, bars }
}

function klineRows(provider: StockDataProvider, value: StockApiJson, period: string, adjust: string): readonly StockApiJson[] {
  if (provider === 'eastmoney') {
    const rows = asRecord(asRecord(value)?.data)?.klines
    return Array.isArray(rows) ? rows : []
  }
  if (provider === 'sina') return Array.isArray(value) ? value : []
  if (provider === 'tencent') {
    const root = asRecord(value)
    const data = asRecord(root?.data)
    if (data === undefined) return []
    const security = Object.values(data).find(item => asRecord(item) !== undefined)
    const record = asRecord(security)
    if (record === undefined) return []
    const prefix = adjust === 'none' || period.endsWith('m') ? '' : adjust
    const preferredKey = period.endsWith('m') ? `m${period.slice(0, -1)}` : `${prefix}${period}`
    const preferred = record[preferredKey] ?? record[period] ?? record[`${adjust}${period}`]
    if (Array.isArray(preferred)) return preferred
    return Object.values(record).find(item => Array.isArray(item) && item.every(row => Array.isArray(row))) as StockApiJson[] | undefined ?? []
  }
  const dataString = findDataString(value)
  return dataString === undefined ? [] : dataString.split(';').filter(Boolean)
}

function parseKlineRow(provider: StockDataProvider, value: StockApiJson, symbol: CanonicalSymbol): JsonRecord | undefined {
  if (provider === 'sina') {
    const row = asRecord(value)
    if (row === undefined) return undefined
    return validBar(
      textOrEmpty(row.day ?? row.date),
      row.open,
      row.high,
      row.low,
      row.close,
      normalizeShareVolume(provider, symbol, numberOrNull(row.volume)),
      numberOrNull(row.amount),
    )
  }
  const fields = Array.isArray(value)
    ? value
    : typeof value === 'string'
      ? value.split(',')
      : []
  if (fields.length < 6) return undefined
  if (provider === 'tonghuashun') {
    return validBar(
      textOrEmpty(fields[0]), fields[1], fields[2], fields[3], fields[4],
      normalizeShareVolume(provider, symbol, numberOrNull(fields[5])), numberOrNull(fields[6]),
    )
  }
  return validBar(
    textOrEmpty(fields[0]), fields[1], fields[3], fields[4], fields[2],
    normalizeShareVolume(provider, symbol, numberOrNull(fields[5])), numberOrNull(fields[6]),
  )
}

function validBar(
  time: string,
  openValue: StockApiJson | undefined,
  highValue: StockApiJson | undefined,
  lowValue: StockApiJson | undefined,
  closeValue: StockApiJson | undefined,
  volumeShares: number | null,
  amount: number | null,
): JsonRecord | undefined {
  const open = numberOrNull(openValue)
  const high = numberOrNull(highValue)
  const low = numberOrNull(lowValue)
  const close = numberOrNull(closeValue)
  if (time.length === 0 || open === null || high === null || low === null || close === null) return undefined
  return { time, open, high, low, close, volume_shares: volumeShares, amount }
}

function normalizeIntraday(
  provider: StockDataProvider,
  value: StockApiJson,
  symbol: CanonicalSymbol,
  days: number,
  limit: number,
): StockApiJson {
  let rows: readonly StockApiJson[] = []
  let previousClose: number | null = null
  if (provider === 'eastmoney') {
    const data = asRecord(asRecord(value)?.data)
    rows = Array.isArray(data?.trends) ? data.trends : []
    previousClose = numberOrNull(data?.preClose)
  } else if (provider === 'tencent') {
    const data = asRecord(asRecord(value)?.data)
    const security = data === undefined ? undefined : Object.values(data).find(item => asRecord(item) !== undefined)
    const nested = asRecord(asRecord(security)?.data)
    rows = Array.isArray(nested?.data) ? nested.data : []
  } else {
    const dataString = findDataString(value)
    rows = dataString === undefined ? [] : dataString.split(';').filter(Boolean)
  }

  const points: StockApiJson[] = []
  for (const item of rows) {
    const fields = typeof item === 'string'
      ? item.trim().split(provider === 'tencent' ? /\s+/u : ',')
      : Array.isArray(item) ? item : []
    if (fields.length < 2) continue
    const time = textOrEmpty(fields[0])
    const price = numberOrNull(fields[provider === 'eastmoney' ? 2 : 1])
    if (time.length === 0 || price === null) continue
    const averagePrice = provider === 'eastmoney'
      ? numberOrNull(fields[7])
      : provider === 'tonghuashun'
        ? numberOrNull(fields[3])
        : null
    const volume = provider === 'eastmoney'
      ? numberOrNull(fields[5])
      : provider === 'tencent'
        ? numberOrNull(fields[2])
        : numberOrNull(fields[4])
    const amount = provider === 'eastmoney'
      ? numberOrNull(fields[6])
      : provider === 'tencent'
        ? numberOrNull(fields[3])
        : numberOrNull(fields[2])
    points.push({
      time,
      price,
      average_price: averagePrice,
      cumulative_volume_shares: normalizeShareVolume(provider, symbol, volume),
      cumulative_amount: amount,
    })
  }
  if (points.length === 0) throw invalidUpstream('分时走势')
  const sampled = points.length > limit
  return {
    symbol: symbol.canonical,
    days,
    previous_close: previousClose,
    sampled,
    points: sampled ? sampleStockApiItems(points, limit) : points,
  }
}

function normalizeRanking(
  value: StockApiJson,
  page: number,
  limit: number,
  order: 'asc' | 'desc',
  sort: string,
  sectors: boolean,
  paginateLocally = false,
): StockApiJson {
  const sourceRows = findRecordRows(value) ?? keyedRows(value)
  if (sourceRows === undefined) throw invalidUpstream(sectors ? '板块排行' : '个股排行')
  const items = sourceRows.map(row => rankingItem(row, sectors)).filter((item): item is JsonRecord => item !== undefined)
  const ordered = paginateLocally && items.some(item => numberOrNull(item[sort]) !== null)
    ? [...items].sort((left, right) => compareNullableNumbers(numberOrNull(left[sort]), numberOrNull(right[sort]), order))
    : items
  const offset = paginateLocally ? (page - 1) * limit : 0
  return { page, limit, items: ordered.slice(offset, offset + limit) }
}

function rankingItem(row: JsonRecord, sectors: boolean): JsonRecord | undefined {
  const code = firstText(row.f12, row.code, row.symbol, row.sector_code, row.node, row.id)
  const name = firstText(row.f14, row.name, row.sector_name, row.cname, row.label)
  if (code.length === 0 && name.length === 0) return undefined
  let item: JsonRecord
  if (sectors) {
    item = { id: code, name }
  } else {
    const symbol = inferCanonicalSymbol(code)
    if (symbol === null) return undefined
    item = { code, symbol, name }
  }
  Object.assign(item, {
    price: firstNumber(row.f2, row.price, row.trade, row.now),
    change: firstNumber(row.f4, row.change, row.pricechange, row.zd),
    change_percent: firstNumber(row.f3, row.change_percent, row.changepercent, row.zdf, row.percent),
    volume: firstNumber(row.f5, row.volume),
    amount: firstNumber(row.f6, row.amount),
    turnover_rate: firstNumber(row.f8, row.turnover_rate, row.turnoverratio, row.hsl),
    net_inflow: firstNumber(row.f62, row.net_inflow, row.netamount),
  })
  return item
}

function normalizeSectorCatalog(value: StockApiJson, sectorType: string): StockApiJson {
  const rows = keyedRows(value) ?? findRecordRows(value)
  if (rows === undefined) throw invalidUpstream('板块目录')
  const items: StockApiJson[] = []
  for (const row of rows) {
    const id = firstText(row.id, row.code, row.node)
    const name = firstText(row.name, row.label, row.cname)
    if (id.length > 0 || name.length > 0) items.push({ id, name })
  }
  return { sector_type: sectorType, items }
}

function normalizeMoneyFlow(
  value: StockApiJson,
  symbol: CanonicalSymbol,
  page: number,
  limit: number,
): StockApiJson {
  const root = asRecord(value)
  const klines = asRecord(root?.data)?.klines
  if (Array.isArray(klines)) {
    const items = klines.map(item => moneyFlowLine(item)).filter((item): item is JsonRecord => item !== undefined)
    const offset = (page - 1) * limit
    return { symbol: symbol.canonical, page, limit, items: items.slice(offset, offset + limit) }
  }
  const rows = findRecordRows(value)
  if (rows === undefined) throw invalidUpstream('资金流')
  return {
    symbol: symbol.canonical,
    page,
    limit,
    items: rows.slice(0, limit).map(row => ({
      time: firstText(row.date, row.day, row.opendate, row.ticktime),
      main_net_inflow: firstNumber(row.main_net_inflow, row.netamount, row.r0_net),
      large_net_inflow: firstNumber(row.large_net_inflow, row.r1_net),
      medium_net_inflow: firstNumber(row.medium_net_inflow, row.r2_net),
      small_net_inflow: firstNumber(row.small_net_inflow, row.r3_net),
      close: firstNumber(row.close, row.trade),
      change_percent: firstNumber(row.change_percent, row.changeratio),
    })),
  }
}

function moneyFlowLine(value: StockApiJson): JsonRecord | undefined {
  if (typeof value !== 'string') return undefined
  const fields = value.split(',')
  const time = fields[0]?.trim() ?? ''
  if (time.length === 0) return undefined
  return {
    time,
    main_net_inflow: numberOrNull(fields[1]),
    small_net_inflow: numberOrNull(fields[2]),
    medium_net_inflow: numberOrNull(fields[3]),
    large_net_inflow: numberOrNull(fields[4]),
    super_large_net_inflow: numberOrNull(fields[5]),
    main_net_ratio: numberOrNull(fields[6]),
    small_net_ratio: numberOrNull(fields[7]),
    medium_net_ratio: numberOrNull(fields[8]),
    large_net_ratio: numberOrNull(fields[9]),
    super_large_net_ratio: numberOrNull(fields[10]),
    close: numberOrNull(fields[11]),
    change_percent: numberOrNull(fields[12]),
  }
}

function normalizeConnectFlow(value: StockApiJson, direction: string, limit: number): StockApiJson {
  const data = asRecord(asRecord(value)?.data)
  if (data === undefined || !Array.isArray(data.s2n) || !Array.isArray(data.n2s)) throw invalidUpstream('沪深港通资金流')

  const northboundRows = connectFlowRows(data.s2n, data.s2nDate)
  const southboundRows = connectFlowRows(data.n2s, data.n2sDate)
  const northboundAvailable = hasReportedConnectFlow(northboundRows)
  const southboundAvailable = hasReportedConnectFlow(southboundRows)
  const requestedNorthbound = direction === 'all' || direction === 'northbound'
  const requestedSouthbound = direction === 'all' || direction === 'southbound'
  const hasRequestedData = (requestedNorthbound && northboundAvailable)
    || (requestedSouthbound && southboundAvailable)
  if (!hasRequestedData) throw invalidUpstream('沪深港通资金流')

  const unavailableDirections: StockApiJson[] = []
  if (requestedNorthbound && !northboundAvailable) unavailableDirections.push('northbound')
  if (requestedSouthbound && !southboundAvailable) unavailableDirections.push('southbound')
  return {
    direction,
    amount_currency: 'CNY',
    unavailable_directions: unavailableDirections,
    ...(requestedNorthbound
      ? { northbound: northboundAvailable ? northboundRows.slice(-limit) : [] }
      : {}),
    ...(requestedSouthbound
      ? { southbound: southboundAvailable ? southboundRows.slice(-limit) : [] }
      : {}),
  }
}

function connectFlowRows(rows: readonly StockApiJson[], date: StockApiJson | undefined): JsonRecord[] {
  const parsed: JsonRecord[] = []
  for (const row of rows) {
    if (typeof row !== 'string') continue
    const fields = row.split(',')
    const time = fields[0]?.trim() ?? ''
    if (!/^\d{1,2}:\d{2}$/u.test(time)) continue
    const shanghaiLeg = numberOrNull(fields[1])
    const shenzhenLeg = numberOrNull(fields[3])
    const total = numberOrNull(fields[5])
    if (shanghaiLeg === null && shenzhenLeg === null && total === null) continue
    parsed.push({
      date: nonEmptyOrNull(date),
      time,
      shanghai_leg_net_inflow: tenThousandCnyToYuan(shanghaiLeg),
      shenzhen_leg_net_inflow: tenThousandCnyToYuan(shenzhenLeg),
      total_net_inflow: tenThousandCnyToYuan(total),
    })
  }
  return parsed
}

function tenThousandCnyToYuan(value: number | null): number | null {
  return value === null ? null : Math.round(value * 10_000)
}

function hasReportedConnectFlow(rows: readonly JsonRecord[]): boolean {
  return rows.some(row => [
    row.shanghai_leg_net_inflow,
    row.shenzhen_leg_net_inflow,
    row.total_net_inflow,
  ].some(value => {
    const amount = numberOrNull(value)
    return amount !== null && amount !== 0
  }))
}

function connectUnavailableDirections(value: StockApiJson): string[] {
  const directions = asRecord(value)?.unavailable_directions
  return Array.isArray(directions)
    ? directions.filter((direction): direction is string => typeof direction === 'string')
    : []
}

function connectDirectionLabel(direction: string): string {
  return direction === 'northbound' ? '北向' : direction === 'southbound' ? '南向' : direction
}

function normalizeSectorMoneyFlow(
  value: StockApiJson,
  sectorType: string,
  page: number,
  limit: number,
): StockApiJson {
  const rows = findRecordRows(value)
  if (rows === undefined || (page === 1 && rows.length === 0)) throw invalidUpstream('板块资金流')
  const items = rows.map(row => rankingItem(row, true)).filter((item): item is JsonRecord => item !== undefined)
  if (items.length === 0) throw invalidUpstream('板块资金流')
  return { sector_type: sectorType, page, limit, items: items.slice(0, limit) }
}

function normalizeGenericItems(value: StockApiJson, page: number, limit: number): StockApiJson {
  const rows = findRecordRows(value)
  if (rows === undefined) throw invalidUpstream('列表')
  return { page, limit, items: rows.slice(0, limit) }
}

function normalizeFeed(value: StockApiJson, page: number, limit: number): StockApiJson {
  const root = asRecord(value)
  const direct = root?.items
  const dataList = asRecord(root?.data)?.list
  const rows = Array.isArray(direct)
    ? direct
    : Array.isArray(dataList)
      ? dataList
      : findRecordRows(value)
  if (rows === undefined) throw invalidUpstream('资讯列表')
  return { page, limit, items: rows.slice(0, limit) }
}

function normalizeSearch(value: StockApiJson, scope: string, page: number, limit: number): StockApiJson {
  const root = asRecord(value)
  const payload = asRecord(root?.data) ?? root
  const result = asRecord(payload?.result)
  const key = scope === 'news' ? 'cmsArticleWebOld' : scope === 'guba' ? 'gubaArticleWeb' : 'labelList'
  const rows = result?.[key]
  if (Array.isArray(rows)) return { scope, page, limit, items: rows.slice(0, limit) }
  const nestedData = asRecord(root?.data)
  const nestedResult = asRecord(nestedData?.result)
  if (Array.isArray(nestedResult?.[key])) {
    return { scope, page, limit, items: nestedResult[key].slice(0, limit) }
  }
  const generic = findRecordRows(value)
  if (generic === undefined) throw invalidUpstream('搜索')
  return { scope, page, limit, items: generic.slice(0, limit) }
}

function normalizeHtmlPage(value: StockApiJson, label: string): StockApiJson {
  const body = asRecord(value)?.body
  if (typeof body !== 'string') throw invalidUpstream(label)
  const text = decodeHtmlEntities(body
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/giu, ' ')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/giu, ' ')
    .replace(/<[^>]+>/gu, ' '))
    .replace(/\s+/gu, ' ')
    .trim()
  if (text.length === 0) throw invalidUpstream(label)
  const maxCharacters = 12_000
  return {
    content_type: 'text/plain',
    text: text.slice(0, maxCharacters),
    truncated: text.length > maxCharacters,
  }
}

function findRecordRows(value: StockApiJson, depth = 0): JsonRecord[] | undefined {
  if (depth > 6) return undefined
  if (Array.isArray(value)) {
    if (value.length === 0) return []
    const records = value.map(asRecord).filter((item): item is JsonRecord => item !== undefined)
    if (records.length === value.length) return records
    for (const item of value) {
      const nested = findRecordRows(item, depth + 1)
      if (nested !== undefined) return nested
    }
    return undefined
  }
  const record = asRecord(value)
  if (record === undefined) return undefined
  for (const nested of Object.values(record)) {
    const rows = findRecordRows(nested, depth + 1)
    if (rows !== undefined) return rows
  }
  return undefined
}

function keyedRows(value: StockApiJson): JsonRecord[] | undefined {
  const record = asRecord(value)
  if (record === undefined) return undefined
  const entries = Object.entries(record).filter(([, item]) => (
    typeof item === 'string' || typeof item === 'number' || asRecord(item) !== undefined
  ))
  if (entries.length === 0) return undefined
  return entries.map(([id, item]): JsonRecord => {
    const nested = asRecord(item)
    if (nested !== undefined) return Object.assign({ id }, nested)
    const fields = String(item).split(',')
    return {
      id,
      name: fields[0]?.trim() ?? id,
      price: numberOrNull(fields[1]),
      change_percent: fields.map(numberOrNull).find(number => number !== null) ?? null,
    }
  })
}

function findDataString(value: StockApiJson): string | undefined {
  const record = asRecord(value)
  if (typeof record?.data === 'string') return record.data
  if (typeof record?.raw === 'string') {
    const match = /["']data["']\s*:\s*["']([^"']*)["']/u.exec(record.raw)
    return match?.[1]
  }
  return undefined
}

function requireRecord(value: unknown): Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) throw badRequest('工具参数必须是对象。')
  return value as Record<string, unknown>
}

function asRecord(value: StockApiJson | undefined): JsonRecord | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value) ? value : undefined
}

function assertAllowed(args: Record<string, unknown>, action: string, allowed: readonly string[]): void {
  const allowedSet = new Set(['action', ...allowed])
  const extra = Object.keys(args).filter(key => !allowedSet.has(key))
  if (extra.length > 0) throw badRequest(`${action} 不接受参数：${extra.join('、')}。`)
}

function rejectPresent(args: Record<string, unknown>, key: string, label: string): void {
  if (Object.hasOwn(args, key)) throw badRequest(`${label} 不接受参数：${key}。`)
}

function requiredEnum<const T extends readonly (string | number)[]>(
  args: Record<string, unknown>,
  key: string,
  values: T,
): T[number] {
  const value = args[key]
  if (!values.includes(value as never)) throw badRequest(`${key} 必须为：${values.join('、')}。`)
  return value as T[number]
}

function optionalEnum<const T extends readonly (string | number)[]>(
  args: Record<string, unknown>,
  key: string,
  values: T,
  fallback: T[number],
): T[number] {
  if (!Object.hasOwn(args, key)) return fallback
  return requiredEnum(args, key, values)
}

function requiredString(args: Record<string, unknown>, key: string, pattern?: RegExp): string {
  const value = args[key]
  if (typeof value !== 'string' || value.trim().length === 0 || (pattern !== undefined && !pattern.test(value))) {
    throw badRequest(`${key} 格式无效。`)
  }
  return value
}

function optionalString(args: Record<string, unknown>, key: string, pattern?: RegExp): string | undefined {
  if (!Object.hasOwn(args, key)) return undefined
  return requiredString(args, key, pattern)
}

function optionalInteger(
  args: Record<string, unknown>, key: string, fallback: number, minimum: number, maximum: number,
): number {
  return optionalIntegerValue(args, key, minimum, maximum) ?? fallback
}

function optionalIntegerValue(
  args: Record<string, unknown>, key: string, minimum: number, maximum: number,
): number | undefined {
  if (!Object.hasOwn(args, key)) return undefined
  const value = args[key]
  if (!Number.isInteger(value) || (value as number) < minimum || (value as number) > maximum) {
    throw badRequest(`${key} 必须是 ${minimum} 到 ${maximum} 之间的整数。`)
  }
  return value as number
}

function optionalBoolean(args: Record<string, unknown>, key: string, fallback: boolean): boolean {
  if (!Object.hasOwn(args, key)) return fallback
  if (typeof args[key] !== 'boolean') throw badRequest(`${key} 必须是布尔值。`)
  return args[key]
}

function optionalDate(args: Record<string, unknown>, key: string): string | undefined {
  const value = optionalString(args, key, /^\d{4}-\d{2}-\d{2}$/u)
  if (value === undefined) return undefined
  const date = new Date(`${value}T00:00:00Z`)
  if (Number.isNaN(date.getTime()) || date.toISOString().slice(0, 10) !== value) throw badRequest(`${key} 不是有效日期。`)
  return value
}

function symbolArg(args: Record<string, unknown>, key = 'symbol'): CanonicalSymbol {
  return parseCanonicalSymbol(requiredString(args, key))
}

function symbolArray(args: Record<string, unknown>, key: string, maximum: number): CanonicalSymbol[] {
  const value = args[key]
  if (!Array.isArray(value) || value.length === 0 || value.length > maximum) {
    throw badRequest(`${key} 必须是包含 1 到 ${maximum} 个证券代码的数组。`)
  }
  const symbols = value.map((item, index) => {
    if (typeof item !== 'string') throw badRequest(`${key}[${index}] 必须是证券代码。`)
    return parseCanonicalSymbol(item)
  })
  if (new Set(symbols.map(symbol => symbol.canonical)).size !== symbols.length) throw badRequest(`${key} 不允许重复证券代码。`)
  return symbols
}

function optionalStringArray<const T extends readonly string[]>(
  args: Record<string, unknown>, key: string, values: T, fallback: readonly T[number][],
): T[number][] {
  if (!Object.hasOwn(args, key)) return [...fallback]
  const value = args[key]
  if (!Array.isArray(value) || value.length === 0 || value.length > values.length) throw badRequest(`${key} 数组长度无效。`)
  const selected = value.map(item => {
    if (typeof item !== 'string' || !values.includes(item as T[number])) throw badRequest(`${key} 包含无效值。`)
    return item as T[number]
  })
  if (new Set(selected).size !== selected.length) throw badRequest(`${key} 不允许重复值。`)
  return selected
}

function parseCanonicalSymbol(value: string): CanonicalSymbol {
  const normalized = value.trim().toUpperCase()
  const match = /^(\d{6})\.(SH|SZ)$/u.exec(normalized)
  if (match === null) throw badRequest(`证券代码格式无效：${value}。请使用 600519.SH 或 000001.SZ。`)
  const code = match[1]
  const market = match[2] as CanonicalSymbol['market']
  if (!isShanghaiShenzhenAStock(code, market)) throw badRequest(`证券代码格式无效：${value}。`)
  return { canonical: `${code}.${market}`, code, market }
}

function isShanghaiShenzhenAStock(code: string, market: CanonicalSymbol['market']): boolean {
  return market === 'SH'
    ? /^(?:600|601|603|605|688)\d{3}$/u.test(code)
    : market === 'SZ' && /^(?:000|001|002|003|300|301)\d{3}$/u.test(code)
}

function toEastMoneySecid(symbol: CanonicalSymbol): string {
  return `${symbol.market === 'SH' ? '1' : '0'}.${symbol.code}`
}

function toTencentSymbol(symbol: CanonicalSymbol): string {
  return `${symbol.market.toLowerCase()}${symbol.code}`
}

function toSinaSymbol(symbol: CanonicalSymbol): string {
  return `${symbol.market.toLowerCase()}${symbol.code}`
}

function toTonghuashunSymbol(symbol: CanonicalSymbol): string {
  return `hs_${symbol.code}`
}

function sourceArg(args: Record<string, unknown>): SourceChoice {
  return optionalEnum(args, 'source', SOURCES, 'auto')
}

function compactDate(value: string): string {
  return value.replaceAll('-', '')
}

function sinaScale(period: string): number {
  const mapping: Readonly<Record<string, number>> = {
    '5m': 5, '15m': 15, '30m': 30, '60m': 60, day: 240, week: 1200, month: 7200,
  }
  const value = mapping[period]
  if (value === undefined) throw badRequest(`新浪不支持 period=${period}。`)
  return value
}

function tencentRankingSort(sort: string): 'price' | 'pn' | 'turnover' | 'volume' | undefined {
  if (sort === 'price') return 'price'
  if (sort === 'change_percent') return 'pn'
  if (sort === 'volume') return 'volume'
  if (sort === 'turnover_rate') return 'turnover'
  return undefined
}

function sinaRankingSort(sort: string): string | undefined {
  const mapping: Readonly<Record<string, string>> = {
    price: 'trade', change_percent: 'changepercent', volume: 'volume', amount: 'amount', turnover_rate: 'turnoverratio',
  }
  return mapping[sort]
}

function sinaMarketNode(market: string): string {
  const mapping: Readonly<Record<string, string>> = {
    all_a: 'hs_a', sh_a: 'sh_a', sz_a: 'sz_a', chinext: 'cyb', star: 'kcb',
  }
  return mapping[market] ?? 'hs_a'
}

function pagedStockParameters(args: Record<string, unknown>, symbol: CanonicalSymbol): Record<string, StockApiJson> {
  return {
    stock_code: symbol.code,
    page: optionalInteger(args, 'page', 1, 1, MAX_PAGE),
    limit: optionalInteger(args, 'limit', 20, 1, MAX_PAGE_SIZE),
  }
}

function matchRequestedSymbol(
  provider: StockDataProvider,
  row: JsonRecord,
  requested: readonly CanonicalSymbol[],
): CanonicalSymbol | undefined {
  const sourceSymbol = firstText(row.symbol)
  const code = firstText(row.f57, row.f12, row.code)
  const eastMoneyMarket = provider === 'eastmoney' ? eastMoneyRowMarket(row) : undefined
  return requested.find(symbol => (
    provider === 'eastmoney'
      ? symbol.code === code && eastMoneyMarket !== null && (eastMoneyMarket === undefined || symbol.market === eastMoneyMarket)
      : provider === 'tencent'
        ? toTencentSymbol(symbol).toLowerCase() === sourceSymbol.toLowerCase()
        : toSinaSymbol(symbol).toLowerCase() === sourceSymbol.toLowerCase()
  ))
}

function eastMoneyRowMarket(row: JsonRecord): CanonicalSymbol['market'] | null | undefined {
  const value = row.f107 ?? row.f13
  if (value === undefined || value === null || textOrEmpty(value).length === 0) return undefined
  if (value === 1 || value === '1') return 'SH'
  if (value === 0 || value === '0') return 'SZ'
  return null
}

function quoteTime(provider: StockDataProvider, row: JsonRecord): StockApiJson {
  if (provider === 'tencent') return nonEmptyOrNull(row.market_time)
  if (provider === 'sina') {
    const date = textOrEmpty(row.date)
    const time = textOrEmpty(row.time)
    return `${date} ${time}`.trim() || null
  }
  return nonEmptyOrNull(row.f292)
}

function normalizeShareVolume(provider: StockDataProvider, _symbol: CanonicalSymbol, value: number | null): number | null {
  if (value === null) return null
  if (provider === 'eastmoney' || provider === 'tencent') return value * 100
  return value
}

function calculateChange(price: number | null, previousClose: number | null): number | null {
  return price === null || previousClose === null ? null : price - previousClose
}

function calculateChangePercent(price: number | null, previousClose: number | null): number | null {
  return price === null || previousClose === null || previousClose === 0 ? null : ((price - previousClose) / previousClose) * 100
}

function multiplyOrNull(value: number | null, multiplier: number): number | null {
  return value === null ? null : value * multiplier
}

function numberOrNull(value: StockApiJson | undefined): number | null {
  if (typeof value === 'number') return Number.isFinite(value) ? value : null
  if (typeof value !== 'string' || value.trim() === '') return null
  const number = Number(value)
  return Number.isFinite(number) ? number : null
}

function firstNumber(...values: readonly (StockApiJson | undefined)[]): number | null {
  for (const value of values) {
    const number = numberOrNull(value)
    if (number !== null) return number
  }
  return null
}

function textOrEmpty(value: StockApiJson | undefined): string {
  return typeof value === 'string' || typeof value === 'number' ? String(value).trim() : ''
}

function firstText(...values: readonly (StockApiJson | undefined)[]): string {
  for (const value of values) {
    const text = textOrEmpty(value)
    if (text.length > 0) return text
  }
  return ''
}

function nonEmptyOrNull(value: StockApiJson | undefined): StockApiJson {
  const text = textOrEmpty(value)
  return text.length === 0 ? null : text
}

function inferCanonicalSymbol(code: string): string | null {
  const source = code.toLowerCase()
  const normalized = source.replace(/^(?:sh|sz)/u, '')
  if (!/^\d{6}$/u.test(normalized)) return null
  const market = /^(?:600|601|603|605|688)/u.test(normalized)
    ? 'SH'
    : /^(?:000|001|002|003|300|301)/u.test(normalized)
      ? 'SZ'
      : undefined
  if (market === undefined) return null
  if ((source.startsWith('sh') || source.startsWith('sz')) && source.slice(0, 2) !== market.toLowerCase()) return null
  return `${normalized}.${market}`
}

function sampleStockApiItems(items: readonly StockApiJson[], limit: number): StockApiJson[] {
  if (items.length <= limit) return [...items]
  if (limit === 1) return [items[items.length - 1]]
  const lastIndex = items.length - 1
  return Array.from({ length: limit }, (_, index) => items[Math.round((index * lastIndex) / (limit - 1))])
}

function compareNullableNumbers(left: number | null, right: number | null, order: 'asc' | 'desc'): number {
  if (left === null && right === null) return 0
  if (left === null) return 1
  if (right === null) return -1
  return order === 'asc' ? left - right : right - left
}

function decodeHtmlEntities(value: string): string {
  return value
    .replace(/&nbsp;/giu, ' ')
    .replace(/&amp;/giu, '&')
    .replace(/&lt;/giu, '<')
    .replace(/&gt;/giu, '>')
    .replace(/&quot;/giu, '"')
    .replace(/&#39;/giu, "'")
    .replace(/&#(\d+);/gu, (_match, code: string) => String.fromCodePoint(Number(code)))
}

function requireCapability(tool: string) {
  const capability = findStockCapability(tool)
  if (capability === undefined) throw badRequest(`未知股票工具：${tool}。`)
  return capability
}

function requireCapabilityAction(capability: ReturnType<typeof requireCapability>, action: string) {
  const definition = capability.actions.find(candidate => candidate.name === action)
  if (definition === undefined) throw badRequest(`${capability.name} 不存在 action=${action}。`)
  return definition
}

function fallbackNote(fallback: 'equivalent' | 'methodology' | 'none'): string {
  if (fallback === 'equivalent') return '备用源会转换为同一字段结构；成交单位等来源差异会显式标注。'
  if (fallback === 'methodology') return '备用源字段会统一，但市场范围、统计或选稿口径可能不同，并会标记 degraded。'
  return '该动作没有可保证语义一致的备用免费数据源。'
}

function providerLabel(provider: StockDataProvider): string {
  const labels: Readonly<Record<StockDataProvider, string>> = {
    eastmoney: '东方财富', tencent: '腾讯财经', sina: '新浪财经', tonghuashun: '同花顺',
  }
  return labels[provider]
}

function isFatalError(error: unknown): boolean {
  return error instanceof StockApiError && (error.kind === 'bad-request' || error.kind === 'cancelled')
}

function isFallbackError(error: unknown): error is StockApiError {
  return error instanceof StockApiError && (error.kind === 'upstream' || error.kind === 'unavailable')
}

function invalidUpstream(label: string): StockApiError {
  return new StockApiError(`${label}返回了无法解析的数据。`, 'upstream')
}

function badRequest(message: string): StockApiError {
  return new StockApiError(message, 'bad-request')
}
