export class StockApiError extends Error {
  constructor(
    message: string,
    readonly kind: 'bad-request' | 'unavailable' | 'upstream' | 'cancelled' = 'upstream',
  ) {
    super(message)
    this.name = 'StockApiError'
  }
}
