import { StockApiError } from './errors.ts'

export type AbortableSleep = (
  milliseconds: number,
  signal: AbortSignal,
) => Promise<void>

/**
 * Serializes request starts without letting a cancelled queued request release
 * later requests before its predecessor has finished waiting.
 */
export class StartIntervalGate {
  private tail: Promise<void> = Promise.resolve()
  private nextStartAt = 0

  constructor(private readonly minimumIntervalMs: number) {}

  async wait(signal: AbortSignal, sleep: AbortableSleep): Promise<void> {
    throwIfAborted(signal)
    const ticket = this.tail.then(async () => {
      throwIfAborted(signal)
      const delay = Math.max(0, this.nextStartAt - Date.now())
      if (delay > 0) await sleep(delay, signal)
      throwIfAborted(signal)
      this.nextStartAt = Date.now() + this.minimumIntervalMs
    })

    // Keep the queue alive after cancellation or transport failure. The
    // caller can still stop waiting immediately through waitForSignal().
    this.tail = ticket.then(() => undefined, () => undefined)
    await waitForSignal(ticket, signal)
  }
}

function waitForSignal<T>(promise: Promise<T>, signal: AbortSignal): Promise<T> {
  if (signal.aborted) return Promise.reject(cancelledError())
  return new Promise<T>((resolve, reject) => {
    let settled = false
    const finish = (operation: () => void): void => {
      if (settled) return
      settled = true
      signal.removeEventListener('abort', onAbort)
      operation()
    }
    const onAbort = (): void => { finish(() => { reject(cancelledError()) }) }
    void promise.then(
      value => { finish(() => { resolve(value) }) },
      error => { finish(() => { reject(error) }) },
    )
    signal.addEventListener('abort', onAbort, { once: true })
    if (signal.aborted) onAbort()
  })
}

function throwIfAborted(signal: AbortSignal): void {
  if (signal.aborted) throw cancelledError()
}

function cancelledError(): StockApiError {
  return new StockApiError('请求已取消。', 'cancelled')
}
