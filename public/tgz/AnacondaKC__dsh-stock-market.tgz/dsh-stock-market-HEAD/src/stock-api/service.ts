import {
  findDocumentedPublicEndpoint,
  findEastMoneyEndpoint,
  type DocumentedPublicEndpoint,
} from './catalog.ts'
import { StockApiError } from './errors.ts'
import {
  PublicWebsiteApiService,
  type TencentTurnoverCode,
} from './public-service.ts'
import { StartIntervalGate } from './request-control.ts'
import type {
  EastMoneyEndpointDescriptor,
  PublicWebsiteProvider,
  StockApiJson,
  StockApiParameterDescriptor,
  StockApiResult,
} from './types.ts'

export { StockApiError } from './errors.ts'

const EASTMONEY_DATACENTER_ORIGIN = 'https://datacenter.eastmoney.com'
const EASTMONEY_ANNOUNCEMENT_ORIGIN = 'https://np-anotice-pc.eastmoney.com'
const EASTMONEY_REPORT_ORIGIN = 'https://reportapi.eastmoney.com'
const EASTMONEY_STOCK_REPORT_ORIGIN = 'https://np-areport-pc.eastmoney.com'
const EASTMONEY_REPORT_CONTENT_ORIGIN = 'https://np-creport-pc.eastmoney.com'
const EASTMONEY_NEWS_ORIGIN = 'https://newsapi.eastmoney.com'
const EASTMONEY_SEARCH_ORIGIN = 'https://search-api-web.eastmoney.com'

const EASTMONEY_TIMEOUT_MS = 20_000
const MAX_RESPONSE_BYTES = 8 * 1024 * 1024
const MAX_ARRAY_ITEMS = 1_000
const MAX_STRING_CHARACTERS = 50_000
const MAX_REPORT_CONTENT_CHARACTERS = 4_000
const MAX_REPORT_SUMMARY_CHARACTERS = 1_000
const EASTMONEY_RETRYABLE_STATUSES = new Set([429, 502, 503, 504])
const EASTMONEY_HEADERS = {
  Accept: 'application/json, text/plain, */*',
  'User-Agent': 'Mozilla/5.0 (compatible; DSH-Stock-Market/0.1)',
  Referer: 'https://data.eastmoney.com/',
}

export interface StockApiServiceOptions {
  fetcher?: typeof fetch
  now?: () => Date
  sleep?: (milliseconds: number, signal: AbortSignal) => Promise<void>
}

class RetryableTransportError extends StockApiError {
  constructor(message: string) {
    super(message, 'upstream')
  }
}

interface UpstreamTextResponse {
  status: number
  headers: Headers
  text: string
}

/**
 * Server-only adapters for the documented fixed stock-data catalogs. Every
 * public execution method accepts an endpoint ID plus validated parameters;
 * none accepts an upstream URL or credential value.
 */
export class StockApiService {
  private readonly fetcher: typeof fetch | undefined
  private readonly now: () => Date
  private readonly sleep: (milliseconds: number, signal: AbortSignal) => Promise<void>
  private readonly publicWebsite: PublicWebsiteApiService
  private readonly eastMoneyGate = new ConcurrencyGate(4)
  private readonly eastMoneyStartGate = new StartIntervalGate(500)

  constructor(private readonly options: StockApiServiceOptions = {}) {
    this.fetcher = options.fetcher ?? globalThis.fetch
    this.now = options.now ?? (() => new Date())
    this.sleep = options.sleep ?? sleepWithSignal
    this.publicWebsite = new PublicWebsiteApiService({
      fetcher: this.fetcher,
      sleep: this.sleep,
    })
  }

  async executeEastMoney(
    endpointId: string,
    parameters: unknown,
    signal: AbortSignal,
  ): Promise<StockApiResult> {
    throwIfAborted(signal)
    const documented = findDocumentedPublicEndpoint('eastmoney', endpointId)
    if (documented !== undefined) {
      return this.executeDocumentedPublic(documented, parameters, signal)
    }

    const endpoint = findEastMoneyEndpoint(endpointId)
    if (endpoint === undefined) throw new StockApiError(`未知的东方财富接口：${endpointId}。`, 'bad-request')
    const normalized = validateParameters(endpoint, parameters)
    const payload = await this.executeEastMoneyEndpoint(endpoint, normalized, signal)
    return result('eastmoney', endpoint.id, endpoint.name, this.now, payload)
  }

  async executeTencent(
    endpointId: string,
    parameters: unknown,
    signal: AbortSignal,
  ): Promise<StockApiResult> {
    return this.executeDocumentedProvider('tencent', endpointId, parameters, signal, '腾讯财经')
  }

  async executeSina(
    endpointId: string,
    parameters: unknown,
    signal: AbortSignal,
  ): Promise<StockApiResult> {
    return this.executeDocumentedProvider('sina', endpointId, parameters, signal, '新浪财经')
  }

  async executeTonghuashun(
    endpointId: string,
    parameters: unknown,
    signal: AbortSignal,
  ): Promise<StockApiResult> {
    return this.executeDocumentedProvider('tonghuashun', endpointId, parameters, signal, '同花顺')
  }

  async requestTencentMarketQuotes(
    codes: readonly string[],
    signal: AbortSignal,
  ): Promise<string> {
    return this.publicWebsite.requestTencentMarketQuotes(codes, signal)
  }

  async requestTencentTurnoverHistory(
    code: TencentTurnoverCode,
    signal: AbortSignal,
  ): Promise<StockApiJson> {
    return this.publicWebsite.requestTencentTurnoverHistory(code, signal)
  }

  async requestSinaGlobalQuotes(signal: AbortSignal): Promise<StockApiJson> {
    return this.publicWebsite.requestSinaGlobalQuotes(signal)
  }

  private async executeDocumentedProvider(
    provider: PublicWebsiteProvider,
    endpointId: string,
    parameters: unknown,
    signal: AbortSignal,
    label: string,
  ): Promise<StockApiResult> {
    throwIfAborted(signal)
    const endpoint = findDocumentedPublicEndpoint(provider, endpointId)
    if (endpoint === undefined) throw new StockApiError(`未知的${label}接口：${endpointId}。`, 'bad-request')
    return this.executeDocumentedPublic(endpoint, parameters, signal)
  }

  private async executeDocumentedPublic(
    endpoint: DocumentedPublicEndpoint,
    parameters: unknown,
    signal: AbortSignal,
  ): Promise<StockApiResult> {
    const payload = await this.publicWebsite.execute(endpoint, parameters, signal)
    return result(endpoint.provider, endpoint.id, endpoint.name, this.now, payload)
  }

  private async executeEastMoneyEndpoint(
    endpoint: EastMoneyEndpointDescriptor,
    parameters: Record<string, StockApiJson>,
    signal: AbortSignal,
  ): Promise<StockApiJson> {
    if (endpoint.reportName !== undefined) return this.eastMoneyF10(endpoint, parameters, signal)

    switch (endpoint.id) {
      case 'em_stock_announcements': return this.eastMoneyAnnouncements(endpoint, parameters, signal)
      case 'em_strategy_reports': return this.eastMoneyResearchReports(endpoint, parameters, 2, signal)
      case 'em_macro_reports': return this.eastMoneyResearchReports(endpoint, parameters, 3, signal)
      case 'em_broker_reports': return this.eastMoneyResearchReports(endpoint, parameters, 4, signal)
      case 'em_industry_reports': return this.eastMoneyResearchReports(endpoint, parameters, 1, signal)
      case 'em_stock_reports': return this.eastMoneyStockReports(endpoint, parameters, signal)
      case 'em_profit_forecast': return this.eastMoneyProfitForecast(endpoint, parameters, signal)
      case 'em_top_news': return this.eastMoneyNewsFeed(endpoint, parameters, 101, signal)
      case 'em_kuaixun': return this.eastMoneyNewsFeed(endpoint, parameters, 102, signal)
      case 'em_news_search': return this.eastMoneyNewsSearch(endpoint, parameters, signal)
      default: throw new StockApiError(`东方财富接口尚未映射：${endpoint.id}。`, 'bad-request')
    }
  }

  private async eastMoneyF10(
    endpoint: EastMoneyEndpointDescriptor,
    parameters: Record<string, StockApiJson>,
    signal: AbortSignal,
  ): Promise<StockApiJson> {
    const stockCode = stringParameter(parameters, 'stock_code')
    const market = inferEastMoneyMarket(stockCode)
    const secucode = `${stockCode}.${eastMoneyMarketSuffix(market)}`
    const page = optionalIntegerParameter(parameters, 'page', 1) ?? 1
    const limit = optionalIntegerParameter(parameters, 'limit', 1) ?? 1
    const query: Record<string, StockApiJson> = {
      reportName: endpoint.reportName ?? '',
      columns: 'ALL',
      filter: `(SECUCODE="${secucode}")`,
      pageNumber: page,
      pageSize: limit,
      source: 'HSF10',
      client: 'PC',
    }
    if (endpoint.sortColumn !== undefined) {
      query.sortColumns = endpoint.sortColumn
      query.sortTypes = endpoint.sortType ?? -1
    }
    const payload = await this.eastMoneyJson(
      buildUrl(EASTMONEY_DATACENTER_ORIGIN, '/securities/api/data/v1/get', query),
      endpoint.id,
      signal,
    )
    const source = requireEastMoneyDataCenterResult(payload, endpoint.name)
    return boundJson({
      stock_code: stockCode,
      secucode,
      page,
      limit,
      total: asNonNegativeInteger(source?.count) ?? 0,
      pages: asNonNegativeInteger(source?.pages) ?? 0,
      items: Array.isArray(source?.data) ? source.data : [],
    })
  }

  private async eastMoneyAnnouncements(
    endpoint: EastMoneyEndpointDescriptor,
    parameters: Record<string, StockApiJson>,
    signal: AbortSignal,
  ): Promise<StockApiJson> {
    const stockCode = stringParameter(parameters, 'stock_code')
    const page = optionalIntegerParameter(parameters, 'page', 1) ?? 1
    const limit = optionalIntegerParameter(parameters, 'limit', 20) ?? 20
    const payload = await this.eastMoneyJson(
      buildUrl(EASTMONEY_ANNOUNCEMENT_ORIGIN, '/api/security/ann', {
        market_stock_list: `${inferEastMoneyMarket(stockCode)}.${stockCode}`,
        page_index: page,
        page_size: limit,
      }),
      endpoint.id,
      signal,
    )
    const data = requireRecordWithArray(payload, 'data', 'list', '东方财富公告')
    return boundJson({
      stock_code: stockCode,
      page,
      limit,
      total: asNonNegativeInteger(data.total_hits) ?? 0,
      announcements: data.list as StockApiJson[],
    })
  }

  private async eastMoneyResearchReports(
    endpoint: EastMoneyEndpointDescriptor,
    parameters: Record<string, StockApiJson>,
    qType: number,
    signal: AbortSignal,
  ): Promise<StockApiJson> {
    const days = optionalIntegerParameter(parameters, 'days', 1) ?? 1
    const top = optionalIntegerParameter(parameters, 'top', 3) ?? 3
    const index = optionalIntegerParameter(parameters, 'index')
    const { beginDate, endDate } = eastMoneyDateRange(this.now(), days)
    const payload = await this.eastMoneyJson(
      buildUrl(EASTMONEY_REPORT_ORIGIN, '/report/jg', {
        cb: '',
        pageSize: 100,
        pageNo: 1,
        fields: '',
        qType,
        orgCode: '',
        code: '*',
        beginTime: beginDate,
        endTime: endDate,
      }),
      endpoint.id,
      signal,
    )
    const sourceReports = requireArrayField(payload, 'data', '东方财富研报')
    const reports = sourceReports.filter(isStockApiRecord).map(eastMoneyResearchReportItem)
    const result: Record<string, StockApiJson> = {
      begin_date: beginDate,
      end_date: endDate,
      qtype: qType,
      reports,
      contents: [],
    }
    if (reports.length === 0) return boundJson(result)

    let artCodeByTitle: Map<string, string>
    try {
      artCodeByTitle = await this.eastMoneyResearchArtCodes(
        endpoint.id,
        qType === 1 ? 1 : 2,
        beginDate,
        endDate,
        signal,
      )
    } catch (error) {
      result.errors = { art_codes: errorMessage(error) }
      return boundJson(result)
    }

    if (index !== undefined && index > reports.length) {
      result.selected_index = index
      result.error = `index ${index} 超出范围（1..${reports.length}）。`
      return boundJson(result)
    }

    const selected = index === undefined ? reports.slice(0, top) : reports.slice(index - 1, index)
    const outcomes = await Promise.allSettled(selected.map(report => (
      this.eastMoneyResearchReportContent(endpoint.id, report, artCodeByTitle, signal)
    )))
    const contents: StockApiJson[] = []
    const errors: Record<string, StockApiJson> = {}
    for (const [position, outcome] of outcomes.entries()) {
      if (outcome.status === 'fulfilled') contents.push(outcome.value)
      else if (signal.aborted) throw outcome.reason
      else errors[`content_${index ?? position + 1}`] = errorMessage(outcome.reason)
    }
    result.contents = contents
    if (index !== undefined) result.selected_index = index
    if (Object.keys(errors).length > 0) result.errors = errors
    return boundJson(result)
  }

  private async eastMoneyResearchArtCodes(
    operationId: string,
    qType: number,
    beginDate: string,
    endDate: string,
    signal: AbortSignal,
  ): Promise<Map<string, string>> {
    const payload = await this.eastMoneyJson(
      buildUrl(EASTMONEY_REPORT_ORIGIN, '/report/list', {
        cb: '',
        industryCode: '*',
        pageSize: 100,
        pageNo: 1,
        fields: '',
        qType,
        orgCode: '',
        code: '*',
        rcode: '',
        beginTime: beginDate,
        endTime: endDate,
      }),
      operationId,
      signal,
    )
    const mapping = new Map<string, string>()
    const rows = requireArrayField(payload, 'data', '东方财富研报目录')
    for (const item of rows) {
      if (!isRecord(item)) continue
      const title = firstText(item.title)
      const artCode = firstText(item.infoCode)
      if (title.length > 0 && artCode.length > 0 && !mapping.has(title)) mapping.set(title, artCode)
    }
    return mapping
  }

  private async eastMoneyResearchReportContent(
    operationId: string,
    report: Record<string, StockApiJson>,
    artCodeByTitle: ReadonlyMap<string, string>,
    signal: AbortSignal,
  ): Promise<StockApiJson> {
    const title = typeof report.title === 'string' ? report.title : ''
    const artCode = artCodeByTitle.get(title) ?? ''
    let content = ''
    let contentTruncated = false
    if (artCode.length > 0) {
      const detail = await this.eastMoneyReportDetail(operationId, artCode, signal)
      const cleaned = cleanReportText(detail.content, MAX_REPORT_CONTENT_CHARACTERS)
      content = cleaned.text
      contentTruncated = cleaned.truncated
    }
    return {
      title,
      org: typeof report.org_name === 'string' ? report.org_name : '',
      publish_date: typeof report.publish_date === 'string' ? report.publish_date : '',
      art_code: artCode,
      content,
      ...(contentTruncated ? { content_truncated: true } : {}),
    }
  }

  private async eastMoneyStockReports(
    endpoint: EastMoneyEndpointDescriptor,
    parameters: Record<string, StockApiJson>,
    signal: AbortSignal,
  ): Promise<StockApiJson> {
    const stockCode = stringParameter(parameters, 'stock_code')
    const page = optionalIntegerParameter(parameters, 'page', 1) ?? 1
    const limit = optionalIntegerParameter(parameters, 'limit', 5) ?? 5
    const content = optionalStringParameter(parameters, 'content', 'summary') ?? 'summary'
    const artCode = optionalStringParameter(parameters, 'art_code')
    if (content === 'full' && artCode === undefined) {
      throw new StockApiError('em_stock_reports.content=full 时必须提供 art_code。', 'bad-request')
    }
    if (content !== 'full' && artCode !== undefined) {
      throw new StockApiError('em_stock_reports.art_code 只能与 content=full 一起使用。', 'bad-request')
    }

    if (content === 'full' && artCode !== undefined) {
      const detail = await this.eastMoneyReportDetail(endpoint.id, artCode, signal)
      if (!detail.found) {
        return boundJson({ stock_code: stockCode, art_code: artCode, found: false, content: '', attach_url: '' })
      }
      if (!detail.stockCodes.includes(stockCode)) {
        return boundJson({
          stock_code: stockCode,
          art_code: artCode,
          found: false,
          content: '',
          attach_url: '',
          error: 'art_code 与 stock_code 不匹配。',
        })
      }
      const cleaned = cleanReportText(detail.content, MAX_REPORT_CONTENT_CHARACTERS)
      return boundJson({
        stock_code: stockCode,
        art_code: artCode,
        found: true,
        title: detail.title,
        stock_name: detail.stockName,
        content: cleaned.text,
        attach_url: detail.attachUrl,
        ...(cleaned.truncated ? { content_truncated: true } : {}),
      })
    }

    const reportList = await this.eastMoneyStockReportList(endpoint.id, stockCode, page, limit, signal)
    const reports: Array<Record<string, StockApiJson>> = isStockApiRecord(reportList) && Array.isArray(reportList.reports)
      ? reportList.reports.filter(isStockApiRecord)
      : []
    if (reports.length === 0) return reportList

    try {
      const metadata = await this.eastMoneyStockReportMetadata(endpoint.id, stockCode, page, limit, signal)
      for (const report of reports) {
        const artCodeValue = eastMoneyArtCode(report)
        const extra = artCodeValue === undefined ? undefined : metadata.get(artCodeValue)
        if (extra !== undefined) Object.assign(report, extra)
      }
    } catch (error) {
      if (signal.aborted) throw error
    }

    const outcomes = await Promise.allSettled(reports.map(report => (
      this.eastMoneyStockReportSummary(endpoint.id, report, signal)
    )))
    const errors: Record<string, StockApiJson> = {}
    for (const [position, outcome] of outcomes.entries()) {
      if (outcome.status === 'fulfilled') Object.assign(reports[position], outcome.value)
      else if (signal.aborted) throw outcome.reason
      else {
        Object.assign(reports[position], { summary: '', summary_source: '', summary_available: false })
        errors[`summary_${position + 1}`] = errorMessage(outcome.reason)
      }
    }
    return boundJson({
      ...(isStockApiRecord(reportList) ? reportList : {}),
      reports,
      ...(Object.keys(errors).length > 0 ? { errors } : {}),
    })
  }

  private async eastMoneyStockReportList(
    operationId: string,
    stockCode: string,
    page: number,
    limit: number,
    signal: AbortSignal,
  ): Promise<StockApiJson> {
    const payload = await this.eastMoneyJson(
      buildUrl(EASTMONEY_STOCK_REPORT_ORIGIN, '/api/security/rep', {
        page_index: page,
        page_size: limit,
        client_source: 'web',
        stock_list: `${inferEastMoneyMarket(stockCode)}.${stockCode}`,
        type: 'A',
      }),
      operationId,
      signal,
    )
    const data = requireRecordWithArray(payload, 'data', 'list', '东方财富个股研报')
    return boundJson({
      stock_code: stockCode,
      page,
      limit,
      total: asNonNegativeInteger(data.total_hits) ?? 0,
      reports: (data.list as StockApiJson[]).filter(isStockApiRecord).map(eastMoneyStockReportItem),
    })
  }

  private async eastMoneyStockReportMetadata(
    operationId: string,
    stockCode: string,
    page: number,
    limit: number,
    signal: AbortSignal,
  ): Promise<Map<string, Record<string, StockApiJson>>> {
    const payload = await this.eastMoneyJson(
      buildUrl(EASTMONEY_REPORT_ORIGIN, '/report/list2', {}),
      operationId,
      signal,
      {
        method: 'POST',
        body: JSON.stringify({
          pageSize: limit,
          pageNo: page,
          p: page,
          pageNum: page,
          pageNumber: page,
          beginTime: '2000-01-01',
          endTime: shanghaiDate(this.now()),
          code: stockCode,
          industryCode: '*',
          rating: null,
          ratingChange: null,
          orgCode: null,
          rcode: '',
        }),
      },
    )
    const metadata = new Map<string, Record<string, StockApiJson>>()
    if (!isRecord(payload) || !Array.isArray(payload.data)) return metadata
    for (const item of payload.data) {
      if (!isRecord(item)) continue
      const artCode = firstText(item.infoCode)
      if (artCode.length > 0) metadata.set(artCode, eastMoneyStockReportMetadataItem(item))
    }
    return metadata
  }

  private async eastMoneyStockReportSummary(
    operationId: string,
    report: Record<string, StockApiJson>,
    signal: AbortSignal,
  ): Promise<Record<string, StockApiJson>> {
    const artCode = eastMoneyArtCode(report)
    if (artCode === undefined) return { summary: '', summary_source: '', summary_available: false }
    const detail = await this.eastMoneyReportDetail(operationId, artCode, signal)
    if (!detail.found) return { summary: '', summary_source: '', summary_available: false }
    const summary = extractReportSummary(detail.content)
    if (summary.text.length === 0) return { summary: '', summary_source: '', summary_available: false }
    return {
      summary: summary.text,
      summary_source: summary.source,
      summary_available: true,
      ...(detail.attachUrl.length > 0 ? { attach_url: detail.attachUrl } : {}),
      ...(summary.truncated ? { summary_truncated: true } : {}),
    }
  }

  private async eastMoneyReportDetail(
    operationId: string,
    artCode: string,
    signal: AbortSignal,
  ): Promise<{
    found: boolean
    title: string
    stockName: string
    stockCodes: string[]
    content: string
    attachUrl: string
  }> {
    const payload = await this.eastMoneyJson(
      buildUrl(EASTMONEY_REPORT_CONTENT_ORIGIN, '/api/content/rep', {
        art_code: artCode,
        client_source: 'web',
      }),
      operationId,
      signal,
    )
    if (!isRecord(payload) || !Object.hasOwn(payload, 'data')) {
      throw new StockApiError('东方财富研报正文响应缺少 data。')
    }
    if (payload.data === null) {
      return { found: false, title: '', stockName: '', stockCodes: [], content: '', attachUrl: '' }
    }
    if (!isRecord(payload.data)) throw new StockApiError('东方财富研报正文 data 格式无效。')
    const data = payload.data
    return {
      found: true,
      title: firstText(data.title, data.title_ch, data.notice_title),
      stockName: firstText(data.short_name),
      stockCodes: eastMoneyReportStockCodes(data.security),
      content: valueText(data.notice_content),
      attachUrl: firstText(data.attach_url),
    }
  }

  private async eastMoneyProfitForecast(
    endpoint: EastMoneyEndpointDescriptor,
    parameters: Record<string, StockApiJson>,
    signal: AbortSignal,
  ): Promise<StockApiJson> {
    const stockCode = stringParameter(parameters, 'stock_code')
    const secucode = `${stockCode}.${eastMoneyMarketSuffix(inferEastMoneyMarket(stockCode))}`
    const payload = await this.eastMoneyJson(
      buildUrl(EASTMONEY_DATACENTER_ORIGIN, '/securities/api/data/v1/get', {
        reportName: 'RPT_WEB_RESPREDICT',
        columns: 'ALL',
        pageNumber: 1,
        pageSize: 1,
        source: 'WEB',
        client: 'WEB',
        filter: `(SECUCODE="${secucode}")`,
      }),
      endpoint.id,
      signal,
    )
    const upstreamResult = requireEastMoneyDataCenterResult(payload, endpoint.name)
    const rows = upstreamResult.data as unknown[]
    return boundJson({ stock_code: stockCode, found: rows.length > 0, item: rows[0] ?? null })
  }

  private async eastMoneyNewsFeed(
    endpoint: EastMoneyEndpointDescriptor,
    parameters: Record<string, StockApiJson>,
    column: 101 | 102,
    signal: AbortSignal,
  ): Promise<StockApiJson> {
    const limit = optionalIntegerParameter(parameters, 'limit', column === 101 ? 10 : 30)
    const response = await this.eastMoneyText(
      buildUrl(EASTMONEY_NEWS_ORIGIN, `/kuaixun/v1/getlist_${column}_ajaxResult_${limit}_1_.html`, {}),
      endpoint.id,
      signal,
    )
    const payload = parseJsonp('东方财富', response.text)
    const items = requireArrayField(payload, 'LivesList', '东方财富快讯')
    return boundJson({
      column,
      items,
    })
  }

  private async eastMoneyNewsSearch(
    endpoint: EastMoneyEndpointDescriptor,
    parameters: Record<string, StockApiJson>,
    signal: AbortSignal,
  ): Promise<StockApiJson> {
    const keyword = stringParameter(parameters, 'keyword')
    const limit = optionalIntegerParameter(parameters, 'limit', 10)
    const param = JSON.stringify({
      uid: '',
      keyword,
      type: ['cmsArticleWebOld'],
      client: 'web',
      clientType: 'web',
      clientVersion: 'curr',
      param: {
        cmsArticleWebOld: {
          searchScope: 'default',
          sort: 'default',
          pageIndex: 1,
          pageSize: limit,
          preTag: '<em>',
          postTag: '</em>',
        },
      },
    })
    const response = await this.eastMoneyText(
      buildUrl(EASTMONEY_SEARCH_ORIGIN, '/search/jsonp', { cb: 'cb', param }),
      endpoint.id,
      signal,
    )
    const payload = parseJsonp('东方财富', response.text)
    validateEastMoneyNewsSearch(payload)
    return boundJson({ keyword, limit, data: payload })
  }

  private async eastMoneyJson(
    url: string,
    operationId: string,
    signal: AbortSignal,
    request: { method: 'POST'; body: string } | undefined = undefined,
  ): Promise<StockApiJson> {
    const response = await this.eastMoneyText(url, operationId, signal, request)
    return parseSuccessJson('东方财富', response.text)
  }

  private async eastMoneyText(
    url: string,
    operationId: string,
    signal: AbortSignal,
    request: { method: 'POST'; body: string } | undefined = undefined,
  ): Promise<UpstreamTextResponse> {
    void operationId
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const response = await this.eastMoneyGate.run(signal, async () => {
          await this.eastMoneyStartGate.wait(signal, this.sleep)
          return this.requestText(url, {
          method: request?.method ?? 'GET',
          headers: request === undefined
            ? EASTMONEY_HEADERS
            : { ...EASTMONEY_HEADERS, 'Content-Type': 'application/json' },
          ...(request === undefined ? {} : { body: request.body }),
          }, signal, EASTMONEY_TIMEOUT_MS, '东方财富')
        })
        if (isSuccessfulStatus(response.status)) return response
        if (attempt === 0 && EASTMONEY_RETRYABLE_STATUSES.has(response.status)) {
          await this.sleep(250, signal)
          continue
        }
        throw upstreamHttpError('东方财富', response)
      } catch (error) {
        if (error instanceof RetryableTransportError && attempt === 0) {
          await this.sleep(250, signal)
          continue
        }
        throw error
      }
    }
    throw new StockApiError('东方财富请求失败。')
  }

  private async requestText(
    url: string,
    init: RequestInit,
    signal: AbortSignal,
    timeoutMs: number,
    provider: string,
  ): Promise<UpstreamTextResponse> {
    throwIfAborted(signal)
    const fetcher = this.fetcher
    if (typeof fetcher !== 'function') throw new StockApiError('当前运行环境不支持行情请求。', 'unavailable')

    const timeout = new AbortController()
    let timedOut = false
    const onAbort = (): void => timeout.abort()
    signal.addEventListener('abort', onAbort, { once: true })
    if (signal.aborted) timeout.abort()
    const timer = setTimeout(() => {
      timedOut = true
      timeout.abort()
    }, timeoutMs)

    try {
      const response = await fetcher(url, { ...init, redirect: 'error', signal: timeout.signal })
      const text = await readBoundedText(response, MAX_RESPONSE_BYTES)
      return { status: response.status, headers: response.headers, text }
    } catch (error) {
      if (signal.aborted) throw new StockApiError('请求已取消。', 'cancelled')
      if (timedOut) throw new RetryableTransportError(`${provider}请求超时。`)
      if (error instanceof StockApiError) throw error
      throw new RetryableTransportError(`${provider}网络请求失败。`)
    } finally {
      clearTimeout(timer)
      signal.removeEventListener('abort', onAbort)
    }
  }
}

function result<TData>(
  provider: StockApiResult['provider'],
  endpointId: string,
  endpointName: string,
  now: () => Date,
  data: TData,
): StockApiResult<TData> {
  return { provider, endpointId, endpointName, fetchedAt: now().toISOString(), data }
}

function requireEastMoneyDataCenterResult(
  payload: StockApiJson,
  label: string,
): Record<string, unknown> {
  if (!isRecord(payload)) throw new StockApiError(`${label}返回了无效数据。`)
  const codeIsSuccess = payload.code === undefined || payload.code === 0 || payload.code === '0'
  if (payload.success !== true || !codeIsSuccess) {
    const detail = safeDetail(firstText(payload.message, payload.msg)) || '上游业务错误'
    throw new StockApiError(`东方财富请求失败：${detail}。`)
  }
  if (!isRecord(payload.result) || !Array.isArray(payload.result.data)) {
    throw new StockApiError(`${label}响应缺少 result.data 列表。`)
  }
  return payload.result
}

function requireRecordWithArray(
  payload: StockApiJson,
  recordKey: string,
  arrayKey: string,
  label: string,
): Record<string, unknown> {
  if (!isRecord(payload) || !isRecord(payload[recordKey]) || !Array.isArray(payload[recordKey][arrayKey])) {
    throw new StockApiError(`${label}响应缺少 ${recordKey}.${arrayKey} 列表。`)
  }
  return payload[recordKey]
}

function requireArrayField(
  payload: StockApiJson,
  key: string,
  label: string,
): StockApiJson[] {
  if (!isRecord(payload) || !Array.isArray(payload[key])) {
    throw new StockApiError(`${label}响应缺少 ${key} 列表。`)
  }
  return payload[key] as StockApiJson[]
}

function validateEastMoneyNewsSearch(payload: StockApiJson): void {
  if (!isRecord(payload)) throw new StockApiError('东方财富资讯搜索返回了无效数据。')
  if (payload.code !== 0 && payload.code !== '0') {
    const detail = safeDetail(firstText(payload.message, payload.msg))
    throw new StockApiError(`东方财富资讯搜索业务请求失败${detail.length > 0 ? `：${detail}` : ''}。`)
  }
  if (!isRecord(payload.result) || !Array.isArray(payload.result.cmsArticleWebOld)) {
    throw new StockApiError('东方财富资讯搜索响应缺少 result.cmsArticleWebOld 列表。')
  }
}

function validateParameters(
  endpoint: Pick<EastMoneyEndpointDescriptor, 'id' | 'parameters'>,
  value: unknown,
): Record<string, StockApiJson> {
  if (!isRecord(value)) throw new StockApiError('parameters 必须是对象。', 'bad-request')
  const allowed = new Map(endpoint.parameters.map(parameter => [parameter.name, parameter]))
  const unknown = Object.keys(value).filter(key => !allowed.has(key))
  if (unknown.length > 0) {
    throw new StockApiError(`${endpoint.id} 不接受参数：${unknown.join('、')}。`, 'bad-request')
  }

  const normalized: Record<string, StockApiJson> = {}
  for (const parameter of endpoint.parameters) {
    const supplied = Object.hasOwn(value, parameter.name)
    const hasDefault = Object.hasOwn(parameter, 'default')
    if (!supplied && !hasDefault) {
      if (parameter.required) throw new StockApiError(`${endpoint.id} 缺少必填参数：${parameter.name}。`, 'bad-request')
      continue
    }
    const parameterValue = supplied ? value[parameter.name] : parameter.default
    normalized[parameter.name] = validateParameterValue(endpoint.id, parameter, parameterValue)
  }
  return normalized
}

function validateParameterValue(
  endpointId: string,
  parameter: StockApiParameterDescriptor,
  value: unknown,
): StockApiJson {
  const label = `${endpointId}.${parameter.name}`
  switch (parameter.type) {
    case 'string': {
      if (typeof value !== 'string') throw new StockApiError(`${label} 必须是字符串。`, 'bad-request')
      if (parameter.minLength !== undefined && value.length < parameter.minLength) {
        throw new StockApiError(`${label} 不能为空。`, 'bad-request')
      }
      if (parameter.maxLength !== undefined && value.length > parameter.maxLength) {
        throw new StockApiError(`${label} 长度不能超过 ${parameter.maxLength}。`, 'bad-request')
      }
      if (parameter.pattern !== undefined && !new RegExp(`^(?:${parameter.pattern})$`, 'u').test(value)) {
        throw new StockApiError(`${label} 格式无效。`, 'bad-request')
      }
      if (parameter.enum !== undefined && !parameter.enum.includes(value)) {
        throw new StockApiError(`${label} 必须为允许的枚举值。`, 'bad-request')
      }
      return value
    }
    case 'integer': {
      if (typeof value !== 'number' || !Number.isInteger(value)) {
        throw new StockApiError(`${label} 必须是整数。`, 'bad-request')
      }
      validateNumericBounds(label, parameter, value)
      if (parameter.enum !== undefined && !parameter.enum.includes(value)) {
        throw new StockApiError(`${label} 必须为允许的枚举值。`, 'bad-request')
      }
      return value
    }
    case 'number': {
      if (typeof value !== 'number' || !Number.isFinite(value)) {
        throw new StockApiError(`${label} 必须是有限数字。`, 'bad-request')
      }
      validateNumericBounds(label, parameter, value)
      if (parameter.enum !== undefined && !parameter.enum.includes(value)) {
        throw new StockApiError(`${label} 必须为允许的枚举值。`, 'bad-request')
      }
      return value
    }
    case 'boolean':
      if (typeof value !== 'boolean') throw new StockApiError(`${label} 必须是布尔值。`, 'bad-request')
      return value
    case 'array': {
      if (!Array.isArray(value)) throw new StockApiError(`${label} 必须是数组。`, 'bad-request')
      if (value.length > MAX_ARRAY_ITEMS) throw new StockApiError(`${label} 最多接受 ${MAX_ARRAY_ITEMS} 项。`, 'bad-request')
      return value.map((item, index) => validateNestedValue(`${label}[${index}]`, parameter.itemType, item))
    }
    case 'object':
      if (!isRecord(value)) throw new StockApiError(`${label} 必须是对象。`, 'bad-request')
      return toJsonValue(value, label)
  }
}

function validateNestedValue(label: string, itemType: StockApiParameterDescriptor['itemType'], value: unknown): StockApiJson {
  if (itemType === undefined) return toJsonValue(value, label)
  const descriptor: StockApiParameterDescriptor = {
    name: label,
    location: 'body',
    type: itemType,
    required: true,
  }
  return validateParameterValue(label, descriptor, value)
}

function validateNumericBounds(label: string, parameter: StockApiParameterDescriptor, value: number): void {
  if (parameter.minimum !== undefined && value < parameter.minimum) {
    throw new StockApiError(`${label} 不能小于 ${parameter.minimum}。`, 'bad-request')
  }
  if (parameter.maximum !== undefined && value > parameter.maximum) {
    throw new StockApiError(`${label} 不能大于 ${parameter.maximum}。`, 'bad-request')
  }
}

function buildUrl(origin: string, path: string, parameters: Record<string, StockApiJson>): string {
  const url = new URL(path, origin)
  for (const [name, value] of Object.entries(parameters)) {
    if (value === undefined || value === null) continue
    url.searchParams.set(name, typeof value === 'object' ? JSON.stringify(value) : String(value))
  }
  return url.toString()
}

function inferEastMoneyMarket(stockCode: string): 0 | 1 {
  if (!/^\d{6}$/.test(stockCode)) throw new StockApiError('stock_code 必须是六位沪深 A 股代码。', 'bad-request')
  if (/^(?:600|601|603|605|688)\d{3}$/.test(stockCode)) return 1
  if (/^(?:000|001|002|003|300|301)\d{3}$/.test(stockCode)) return 0
  throw new StockApiError('stock_code 仅支持沪深 A 股代码。', 'bad-request')
}

function eastMoneyMarketSuffix(market: 0 | 1): 'SZ' | 'SH' {
  return market === 0 ? 'SZ' : 'SH'
}

function eastMoneyDateRange(now: Date, days: number): { beginDate: string; endDate: string } {
  const today = shanghaiDate(now)
  const begin = new Date(`${today}T00:00:00.000Z`)
  begin.setUTCDate(begin.getUTCDate() - days)
  return { beginDate: begin.toISOString().slice(0, 10), endDate: today }
}

function shanghaiDate(value: Date): string {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(value)
  const named = Object.fromEntries(parts.filter(part => part.type !== 'literal').map(part => [part.type, part.value]))
  return `${named.year}-${named.month}-${named.day}`
}

function eastMoneyResearchReportItem(item: Record<string, unknown>): Record<string, StockApiJson> {
  return {
    title: firstText(item.title),
    org_name: firstText(item.orgSName, item.orgName),
    author: firstText(item.researcher),
    publish_date: valueText(item.publishDate).slice(0, 10),
    count: jsonField(item.count ?? 0),
  }
}

function eastMoneyStockReportItem(item: Record<string, unknown>): Record<string, StockApiJson> {
  const codes = Array.isArray(item.codes) ? item.codes : []
  const firstCode = codes.find(isRecord)
  return {
    title: firstText(item.title),
    org: firstText(item.source),
    publish_date: valueText(item.eiTime).slice(0, 10),
    rating: firstText(item.em_rating_name, item.s_rating_name),
    aim_price: jsonField(item.aim_price ?? ''),
    art_code: firstText(item.art_code),
    stock_name: firstCode === undefined ? '' : firstText(firstCode.short_name),
    industry: '',
    rating_change: null,
    forecast: {},
  }
}

function eastMoneyStockReportMetadataItem(item: Record<string, unknown>): Record<string, StockApiJson> {
  return {
    industry: firstText(item.indvInduName, item.industryName),
    rating_change: jsonField(item.ratingChange),
    forecast: {
      actual_last_year_eps: jsonField(item.actualLastYearEps),
      actual_last_two_year_eps: jsonField(item.actualLastTwoYearEps),
      predict_this_year_eps: jsonField(item.predictThisYearEps),
      predict_this_year_pe: jsonField(item.predictThisYearPe),
      predict_next_year_eps: jsonField(item.predictNextYearEps),
      predict_next_year_pe: jsonField(item.predictNextYearPe),
      predict_next_two_year_eps: jsonField(item.predictNextTwoYearEps),
      predict_next_two_year_pe: jsonField(item.predictNextTwoYearPe),
    },
  }
}

function eastMoneyReportStockCodes(value: unknown): string[] {
  const items = Array.isArray(value) ? value : isRecord(value) ? [value] : []
  const codes: string[] = []
  for (const item of items) {
    if (!isRecord(item)) continue
    const code = firstText(item.stock)
    if (/^\d{6}$/u.test(code) && !codes.includes(code)) codes.push(code)
  }
  return codes
}

function cleanReportText(text: string, maximum: number): { text: string; truncated: boolean } {
  const cleaned = text
    .replace(/[\r\n\t\u3000]+/gu, ' ')
    .replace(/ {2,}/gu, ' ')
    .trim()
  return cleaned.length <= maximum
    ? { text: cleaned, truncated: false }
    : { text: cleaned.slice(0, maximum), truncated: true }
}

function extractReportSummary(text: string): { text: string; source: string; truncated: boolean } {
  const normalized = text.replace(/\r\n?/gu, '\n')
  const start = /(?:^|\n)[ \t\u3000]*(投资要点|核心观点|报告摘要|核心结论)[：:]?/mu.exec(normalized)
  let source = 'excerpt'
  let section = normalized
  if (start !== null) {
    source = {
      投资要点: 'investment_points',
      核心观点: 'core_view',
      报告摘要: 'report_abstract',
      核心结论: 'core_conclusion',
    }[start[1]] ?? 'excerpt'
    section = normalized.slice((start.index ?? 0) + start[0].length)
    const end = /(?:^|\n)[ \t\u3000]*(?:盈利预测(?:与投资建议)?|投资建议|风险提示|财务预测(?:与估值)?|估值(?:与投资建议)?|风险因素)[：:]?/mu.exec(section)
    if (end !== null) section = section.slice(0, end.index)
  }
  const cleaned = cleanReportText(section, MAX_REPORT_SUMMARY_CHARACTERS)
  return { ...cleaned, source }
}

function firstText(...values: unknown[]): string {
  for (const value of values) {
    const text = valueText(value).trim()
    if (text.length > 0) return text
  }
  return ''
}

function jsonField(value: unknown): StockApiJson {
  return value === undefined ? null : toJsonValue(value, '东方财富字段')
}

function eastMoneyArtCode(value: Record<string, unknown>): string | undefined {
  for (const key of ['art_code', 'artCode', 'ART_CODE', 'INFO_CODE', 'infoCode']) {
    const candidate = value[key]
    if (typeof candidate === 'string' && candidate.trim().length > 0) return candidate.trim()
  }
  return undefined
}

function parseSuccessJson(provider: string, text: string): StockApiJson {
  try {
    return toJsonValue(JSON.parse(text), `${provider} 响应`)
  } catch (error) {
    if (error instanceof StockApiError) throw error
    throw new StockApiError(`${provider}返回了非 JSON 数据：${safeDetail(text) || '响应为空'}。`)
  }
}

function parseJsonp(provider: string, text: string): StockApiJson {
  let payload = text.trim().replace(/;\s*$/u, '').trim()
  const assignment = /^(?:var\s+)?ajaxResult\s*=\s*([\s\S]+)$/u.exec(payload)
  if (assignment !== null) payload = assignment[1].trim()
  const callback = /^[A-Za-z_$][A-Za-z0-9_$]*(?:\.[A-Za-z_$][A-Za-z0-9_$]*)*\s*\(\s*([\s\S]*)\s*\)$/u.exec(payload)
  if (callback !== null) payload = callback[1].trim()
  return parseSuccessJson(provider, payload)
}

function upstreamHttpError(provider: string, response: UpstreamTextResponse): StockApiError {
  const detail = safeDetail(response.text)
  return new StockApiError(`${provider}请求失败：HTTP ${response.status}${detail ? `，${detail}` : ''}。`)
}

function safeDetail(value: string): string {
  return value.replace(/\s+/g, ' ').trim().slice(0, 500)
}

function valueText(value: unknown): string {
  return typeof value === 'string' ? value : value === undefined || value === null ? '' : String(value)
}

function isSuccessfulStatus(status: number): boolean {
  return status >= 200 && status < 300
}

async function readBoundedText(response: Response, maximum: number): Promise<string> {
  const contentLength = response.headers.get('content-length')
  if (contentLength !== null && Number(contentLength) > maximum) {
    try {
      await response.body?.cancel()
    } catch {
      // The size error is authoritative even if the upstream body cannot be cancelled.
    }
    throw new StockApiError(`上游响应超过 ${maximum} 字节限制。`)
  }
  if (response.body === null) {
    const text = await response.text()
    if (new TextEncoder().encode(text).byteLength > maximum) {
      throw new StockApiError(`上游响应超过 ${maximum} 字节限制。`)
    }
    return text
  }

  const reader = response.body.getReader()
  const chunks: Uint8Array[] = []
  let size = 0
  try {
    for (;;) {
      const item = await reader.read()
      if (item.done) break
      size += item.value.byteLength
      if (size > maximum) {
        await reader.cancel()
        throw new StockApiError(`上游响应超过 ${maximum} 字节限制。`)
      }
      chunks.push(item.value)
    }
  } finally {
    reader.releaseLock()
  }
  const buffer = new Uint8Array(size)
  let offset = 0
  for (const chunk of chunks) {
    buffer.set(chunk, offset)
    offset += chunk.byteLength
  }
  return new TextDecoder().decode(buffer)
}

function boundJson(value: unknown): StockApiJson {
  return boundJsonValue(toJsonValue(value, '上游响应'))
}

function boundJsonValue(value: StockApiJson): StockApiJson {
  if (typeof value === 'string') {
    return value.length > MAX_STRING_CHARACTERS
      ? `${value.slice(0, MAX_STRING_CHARACTERS)}\n[内容已截断]`
      : value
  }
  if (Array.isArray(value)) {
    if (value.length > MAX_ARRAY_ITEMS) {
      return {
        items: value.slice(0, MAX_ARRAY_ITEMS).map(boundJsonValue),
        returned_count: MAX_ARRAY_ITEMS,
        total_count: value.length,
        truncated: true,
      }
    }
    return value.map(boundJsonValue)
  }
  if (isRecord(value)) {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, boundJsonValue(item)]))
  }
  return value
}

function toJsonValue(value: unknown, label: string, depth = 0): StockApiJson {
  if (depth > 32) throw new StockApiError(`${label} 嵌套层级过深。`, 'bad-request')
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new StockApiError(`${label} 包含非有限数字。`, 'bad-request')
    return value
  }
  if (Array.isArray(value)) return value.map(item => toJsonValue(item, label, depth + 1))
  if (isRecord(value)) return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, toJsonValue(item, label, depth + 1)]))
  throw new StockApiError(`${label} 必须是 JSON 值。`, 'bad-request')
}

function isStockApiRecord(value: StockApiJson): value is Record<string, StockApiJson> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function stringParameter(parameters: Record<string, StockApiJson>, name: string): string {
  const value = parameters[name]
  if (typeof value !== 'string') throw new StockApiError(`缺少字符串参数：${name}。`, 'bad-request')
  return value
}

function optionalStringParameter(parameters: Record<string, StockApiJson>, name: string, fallback?: string): string | undefined {
  const value = parameters[name]
  if (value === undefined) return fallback
  if (typeof value !== 'string') throw new StockApiError(`${name} 必须是字符串。`, 'bad-request')
  return value
}

function optionalIntegerParameter(parameters: Record<string, StockApiJson>, name: string, fallback?: number): number | undefined {
  const value = parameters[name]
  if (value === undefined) return fallback
  if (typeof value !== 'number' || !Number.isInteger(value)) throw new StockApiError(`${name} 必须是整数。`, 'bad-request')
  return value
}

function asNonNegativeInteger(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isInteger(value) && value >= 0 ? value : undefined
}

function errorMessage(error: unknown): string {
  return error instanceof Error && error.message.trim().length > 0
    ? error.message
    : String(error) || '未知错误'
}

function throwIfAborted(signal: AbortSignal): void {
  if (signal.aborted) throw new StockApiError('请求已取消。', 'cancelled')
}

function sleepWithSignal(milliseconds: number, signal: AbortSignal): Promise<void> {
  if (signal.aborted) return Promise.reject(new StockApiError('请求已取消。', 'cancelled'))
  return new Promise((resolve, reject) => {
    const timer = setTimeout(done, milliseconds)
    const onAbort = (): void => {
      clearTimeout(timer)
      done(new StockApiError('请求已取消。', 'cancelled'))
    }
    function done(error?: Error): void {
      signal.removeEventListener('abort', onAbort)
      if (error !== undefined) reject(error)
      else resolve()
    }
    signal.addEventListener('abort', onAbort, { once: true })
  })
}

class ConcurrencyGate {
  private active = 0
  private readonly queue: Array<() => void> = []

  constructor(private readonly maximum: number) {}

  async run<T>(signal: AbortSignal, operation: () => Promise<T>): Promise<T> {
    await this.acquire(signal)
    try {
      return await operation()
    } finally {
      this.release()
    }
  }

  private async acquire(signal: AbortSignal): Promise<void> {
    if (signal.aborted) throw new StockApiError('请求已取消。', 'cancelled')
    if (this.active < this.maximum) {
      this.active++
      return
    }
    await new Promise<void>((resolve, reject) => {
      let settled = false
      const resume = (): void => {
        if (settled) return
        settled = true
        signal.removeEventListener('abort', cancel)
        this.active++
        resolve()
      }
      const cancel = (): void => {
        if (settled) return
        settled = true
        signal.removeEventListener('abort', cancel)
        const index = this.queue.indexOf(resume)
        if (index >= 0) this.queue.splice(index, 1)
        reject(new StockApiError('请求已取消。', 'cancelled'))
      }
      this.queue.push(resume)
      signal.addEventListener('abort', cancel, { once: true })
      if (signal.aborted) cancel()
    })
  }

  private release(): void {
    const next = this.queue.shift()
    if (next === undefined) {
      this.active--
      return
    }
    this.active--
    next()
  }
}
