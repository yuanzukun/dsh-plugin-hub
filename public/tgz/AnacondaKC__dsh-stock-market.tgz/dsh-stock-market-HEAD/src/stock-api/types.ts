export type StockDataProvider =
  | 'eastmoney'
  | 'tencent'
  | 'sina'
  | 'tonghuashun'

export type PublicWebsiteProvider = 'tencent' | 'sina' | 'tonghuashun'

export type StockApiParameterLocation = 'path' | 'query' | 'body'
export type StockApiParameterType = 'string' | 'integer' | 'number' | 'boolean' | 'array' | 'object'

export type StockApiJson =
  | null
  | boolean
  | number
  | string
  | StockApiJson[]
  | { [key: string]: StockApiJson }

export interface StockApiParameterDescriptor {
  name: string
  location: StockApiParameterLocation
  type: StockApiParameterType
  required: boolean
  description?: string
  enum?: readonly (string | number)[]
  default?: string | number | boolean | null
  itemType?: StockApiParameterType
  minimum?: number
  maximum?: number
  pattern?: string
  minLength?: number
  maxLength?: number
}

export interface StockApiEndpointBase {
  id: string
  name: string
  group: string
  summary?: string
  parameters: readonly StockApiParameterDescriptor[]
}

export interface EastMoneyEndpointDescriptor extends StockApiEndpointBase {
  provider: 'eastmoney'
  features: readonly string[]
  path: string
  reportName?: string
  sortColumn?: string
  sortType?: 1 | -1
}

export interface PublicWebsiteEndpointDescriptor extends StockApiEndpointBase {
  provider: PublicWebsiteProvider
  features: readonly string[]
  path: string
}

export interface StockApiResult<TData = StockApiJson> {
  provider: StockDataProvider
  endpointId: string
  endpointName: string
  fetchedAt: string
  data: TData
}
