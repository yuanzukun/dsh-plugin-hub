import { StockApiError } from './errors.ts'
import { StartIntervalGate } from './request-control.ts'
import {
  EASTMONEY_UT,
  type DocumentedPublicEndpoint,
} from './researched-catalog.ts'
import type {
  PublicWebsiteProvider,
  StockApiJson,
  StockApiParameterDescriptor,
} from './types.ts'

type DocumentedProvider = 'eastmoney' | PublicWebsiteProvider
type TextEncoding = 'utf-8' | 'gbk'
type ResponseKind = 'json' | 'jsonp' | 'script' | 'html' | 'tencent-quotes' | 'sina-quotes'

interface PublicRequest {
  url: string
  fallbackUrls?: readonly string[]
  encoding: TextEncoding
  responseKind: ResponseKind
  headers: Readonly<Record<string, string>>
  maxResponseBytes?: number
  timeoutMs?: number
}

export type TencentTurnoverCode = 'sh000001' | 'sz399106'

export interface PublicWebsiteApiServiceOptions {
  fetcher?: typeof fetch
  sleep?: (milliseconds: number, signal: AbortSignal) => Promise<void>
}

const REQUEST_TIMEOUT_MS = 20_000
const MAX_RESPONSE_BYTES = 8 * 1024 * 1024
const MAX_ARRAY_ITEMS = 1_000
const MAX_STRING_CHARACTERS = 50_000
const RETRYABLE_STATUSES = new Set([429, 502, 503, 504])
const USER_AGENT = 'Mozilla/5.0 (compatible; DSH-Stock-Market/0.1)'
const TENCENT_MARKET_TIMEOUT_MS = 8_000
const TENCENT_QUOTE_MAX_RESPONSE_BYTES = 64 * 1024
const SINA_QUOTE_MAX_RESPONSE_BYTES = 64 * 1024
const TENCENT_HISTORY_MAX_RESPONSE_BYTES = 128 * 1024
const TENCENT_TURNOVER_CODES: readonly TencentTurnoverCode[] = ['sh000001', 'sz399106']
const SINA_GLOBAL_QUOTE_SYMBOLS = [
  'sh000001',
  'int_hangseng',
  'int_nasdaq',
  'b_KOSPI',
  'b_NKY',
  'hf_OIL',
  'hf_GC',
] as const

const PROVIDER_LABELS: Readonly<Record<DocumentedProvider, string>> = {
  eastmoney: '东方财富',
  tencent: '腾讯财经',
  sina: '新浪财经',
  tonghuashun: '同花顺',
}

const EASTMONEY_FIELDS = [
  'f43', 'f44', 'f45', 'f46', 'f47', 'f48', 'f57', 'f58', 'f60', 'f107',
  'f116', 'f117', 'f162', 'f167', 'f168', 'f169', 'f170', 'f171', 'f177', 'f292',
].join(',')
const EASTMONEY_LIST_FIELDS = [
  'f2', 'f3', 'f4', 'f5', 'f6', 'f12', 'f13', 'f14', 'f15', 'f16', 'f17', 'f18',
  'f20', 'f21', 'f23', 'f8', 'f10', 'f62',
].join(',')
const EASTMONEY_BATCH_FIELDS = 'f1,f2,f3,f4,f5,f6,f12,f13,f14,f104,f105,f106'
const EASTMONEY_KLINE_FIELDS_1 = 'f1,f2,f3,f4,f5,f6'
const EASTMONEY_KLINE_FIELDS_2 = 'f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61'
const EASTMONEY_TREND_FIELDS_1 = 'f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13'
const EASTMONEY_TREND_FIELDS_2 = 'f51,f52,f53,f54,f55,f56,f57,f58'
const EASTMONEY_FLOW_FIELDS_1 = 'f1,f2,f3,f7'
const EASTMONEY_FLOW_FIELDS_2 = 'f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f62,f63,f64,f65'

const EASTMONEY_MARKETS: Readonly<Record<string, string>> = {
  all_a: 'm:0+t:6,m:1+t:2',
  sh_a: 'm:1+t:2',
  sz_a: 'm:0+t:6',
  chinext: 'm:0+t:13+s:2048',
  star: 'm:0+t:81+s:2048',
  industry: 'm:90+t:2',
  concept: 'm:90+t:3',
  region: 'm:90+t:1',
}
const EASTMONEY_SORT_FIELDS: Readonly<Record<string, string>> = {
  price: 'f2',
  change_percent: 'f3',
  change: 'f4',
  volume: 'f5',
  amount: 'f6',
  turnover_rate: 'f8',
  net_inflow: 'f62',
  code: 'f12',
}
const EASTMONEY_PERIODS: Readonly<Record<string, number>> = {
  '1m': 1,
  '5m': 5,
  '15m': 15,
  '30m': 30,
  '60m': 60,
  day: 101,
  week: 102,
  month: 103,
}
const EASTMONEY_ADJUSTMENTS: Readonly<Record<string, number>> = { none: 0, qfq: 1, hfq: 2 }
const EASTMONEY_REPORTS: Readonly<Record<string, string>> = {
  dragon_tiger: 'RPT_DAILYBILLBOARD_DETAILSNEW',
  economic_calendar: 'RPT_CPH_FECALENDAR',
  convertible_bonds: 'RPT_BOND_CB_LIST',
  margin_detail: 'RPTA_WEB_RZRQ_GGMX',
}
const EASTMONEY_CONTENT_SEARCH_TYPES: Readonly<Record<string, string>> = {
  news: 'cmsArticleWebOld',
  guba: 'gubaArticleWeb',
}
const EASTMONEY_SECURITY_SEARCH_LABELS: Readonly<Record<string, string>> = {
  stock: 'AB_STOCK',
  fund: 'FUND',
}

const TENCENT_SECTOR_TYPES: Readonly<Record<string, string>> = {
  industry: 'hy',
  concept: 'gn',
  region: 'dy',
}
const SINA_NEWS_CHANNELS: Readonly<Record<string, number>> = {
  finance: 2516,
  stocks: 2517,
  money: 2519,
}

export class PublicWebsiteApiService {
  private readonly fetcher: typeof fetch | undefined
  private readonly sleep: (milliseconds: number, signal: AbortSignal) => Promise<void>
  private readonly gates: Readonly<Record<DocumentedProvider, ProviderGate>> = {
    eastmoney: new ProviderGate(2, 500),
    tencent: new ProviderGate(4, 100),
    sina: new ProviderGate(2, 300),
    tonghuashun: new ProviderGate(1, 500),
  }

  constructor(options: PublicWebsiteApiServiceOptions = {}) {
    this.fetcher = options.fetcher ?? globalThis.fetch
    this.sleep = options.sleep ?? sleepWithSignal
  }

  async execute(
    endpoint: DocumentedPublicEndpoint,
    parameters: unknown,
    signal: AbortSignal,
  ): Promise<StockApiJson> {
    throwIfAborted(signal)
    const normalized = validateParameters(endpoint, parameters)
    const request = buildRequest(endpoint, normalized)
    const label = PROVIDER_LABELS[endpoint.provider]
    const text = await this.executeRequest(endpoint.provider, request, signal)
    const parsed = parseResponse(request.responseKind, text, label)
    validateBusinessResponse(endpoint, normalized, parsed)
    return boundJson(restrictResponseToPluginScope(endpoint, normalized, parsed))
  }

  async requestTencentMarketQuotes(
    codes: readonly string[],
    signal: AbortSignal,
  ): Promise<string> {
    if (
      codes.length === 0
      || codes.length > 16
      || codes.some(code => !/^(?:sh|sz)\d{6}$/u.test(code))
    ) {
      throw new StockApiError('腾讯行情代码列表无效。', 'bad-request')
    }
    return this.executeRequest('tencent', {
      ...tencentRequest(`https://qt.gtimg.cn/q=${codes.join(',')}`, 'gbk', 'tencent-quotes'),
      maxResponseBytes: TENCENT_QUOTE_MAX_RESPONSE_BYTES,
      timeoutMs: TENCENT_MARKET_TIMEOUT_MS,
    }, signal)
  }

  async requestTencentTurnoverHistory(
    code: TencentTurnoverCode,
    signal: AbortSignal,
  ): Promise<StockApiJson> {
    if (!TENCENT_TURNOVER_CODES.includes(code)) {
      throw new StockApiError('腾讯成交历史代码无效。', 'bad-request')
    }
    const request = {
      ...tencentRequest(`https://web.ifzq.gtimg.cn/appstock/app/day/query?code=${code}`),
      maxResponseBytes: TENCENT_HISTORY_MAX_RESPONSE_BYTES,
      timeoutMs: TENCENT_MARKET_TIMEOUT_MS,
    }
    const parsed = parseJson('腾讯财经', await this.executeRequest('tencent', request, signal))
    if (!isRecord(parsed) || (parsed.code !== 0 && parsed.code !== '0') || !isRecord(parsed.data)) {
      throw new StockApiError('腾讯财经成交历史响应无效。')
    }
    return parsed
  }

  async requestSinaGlobalQuotes(signal: AbortSignal): Promise<StockApiJson> {
    const text = await this.executeRequest('sina', {
      ...sinaRequest(
        `https://hq.sinajs.cn/list=${SINA_GLOBAL_QUOTE_SYMBOLS.join(',')}`,
        'gbk',
        'sina-quotes',
      ),
      maxResponseBytes: SINA_QUOTE_MAX_RESPONSE_BYTES,
      timeoutMs: TENCENT_MARKET_TIMEOUT_MS,
    }, signal)
    return parseSinaQuotes(text)
  }

  private async executeRequest(
    provider: DocumentedProvider,
    request: PublicRequest,
    signal: AbortSignal,
  ): Promise<string> {
    const label = PROVIDER_LABELS[provider]
    return withDeadline(signal, request.timeoutMs ?? REQUEST_TIMEOUT_MS, label, requestSignal => (
      this.gates[provider].run(requestSignal, startGate => (
        this.requestText(provider, request, startGate, requestSignal)
      ))
    ))
  }

  private async requestText(
    provider: DocumentedProvider,
    request: PublicRequest,
    startGate: StartIntervalGate,
    signal: AbortSignal,
  ): Promise<string> {
    const fetcher = this.fetcher
    if (typeof fetcher !== 'function') {
      throw new StockApiError('当前运行环境不支持行情请求。', 'unavailable')
    }
    const label = PROVIDER_LABELS[provider]

    for (let attempt = 0; attempt < 3; attempt++) {
      throwIfAborted(signal)
      await startGate.wait(signal, this.sleep)
      const fallbackUrls = request.fallbackUrls ?? []
      const requestUrl = attempt === 0 || fallbackUrls.length === 0
        ? request.url
        : fallbackUrls[Math.min(attempt - 1, fallbackUrls.length - 1)]
      try {
        const response = await fetcher(requestUrl, {
          method: 'GET',
          headers: request.headers,
          redirect: 'error',
          signal,
        })
        if (response.ok) {
          return await readBoundedText(response, request.encoding, request.maxResponseBytes ?? MAX_RESPONSE_BYTES)
        }
        try {
          await response.body?.cancel()
        } catch {
          // The HTTP status remains authoritative if cancellation fails.
        }
        if (attempt < 2 && RETRYABLE_STATUSES.has(response.status)) {
          await this.sleep(1_000 * (2 ** attempt), signal)
          continue
        }
        throw new StockApiError(`${label}请求失败：HTTP ${response.status}。`)
      } catch (error) {
        if (signal.aborted) throw new StockApiError('请求已取消。', 'cancelled')
        if (error instanceof StockApiError) throw error
        if (attempt < 2) {
          await this.sleep(1_000 * (2 ** attempt), signal)
          continue
        }
        throw new StockApiError(`${label}网络请求失败。`)
      }
    }
    throw new StockApiError(`${label}请求失败。`)
  }
}

function buildRequest(
  endpoint: DocumentedPublicEndpoint,
  parameters: Record<string, StockApiJson>,
): PublicRequest {
  const endpointId: string = endpoint.id
  switch (endpoint.id) {
    case 'em_realtime_quote':
      return eastmoneyRequest(url('https://push2.eastmoney.com', '/api/qt/stock/get', {
        secid: stringParameter(parameters, 'secid'),
        fltt: 2,
        invt: 2,
        ut: EASTMONEY_UT,
        fields: EASTMONEY_FIELDS,
      }))
    case 'em_market_snapshot':
      return eastmoneyRequest(url('https://push2.eastmoney.com', '/api/qt/clist/get', {
        pn: integerParameter(parameters, 'page'),
        pz: integerParameter(parameters, 'limit'),
        po: stringParameter(parameters, 'order') === 'desc' ? 1 : 0,
        np: 1,
        fltt: 2,
        invt: 2,
        fid: requiredMapping(EASTMONEY_SORT_FIELDS, stringParameter(parameters, 'sort'), endpoint.id),
        fs: requiredMapping(EASTMONEY_MARKETS, stringParameter(parameters, 'market'), endpoint.id),
        fields: EASTMONEY_LIST_FIELDS,
      }))
    case 'em_batch_quotes':
      return eastmoneyRequest(url('https://push2.eastmoney.com', '/api/qt/ulist.np/get', {
        secids: stringParameter(parameters, 'secids'),
        fltt: 2,
        invt: 2,
        fields: EASTMONEY_BATCH_FIELDS,
      }))
    case 'em_price_history':
      return eastmoneyRequest(url('https://push2his.eastmoney.com', '/api/qt/stock/kline/get', {
        secid: stringParameter(parameters, 'secid'),
        fields1: EASTMONEY_KLINE_FIELDS_1,
        fields2: EASTMONEY_KLINE_FIELDS_2,
        klt: requiredMapping(EASTMONEY_PERIODS, stringParameter(parameters, 'period'), endpoint.id),
        fqt: requiredMapping(EASTMONEY_ADJUSTMENTS, stringParameter(parameters, 'adjust'), endpoint.id),
        beg: stringParameter(parameters, 'begin'),
        end: stringParameter(parameters, 'end'),
        lmt: integerParameter(parameters, 'limit'),
      }))
    case 'em_intraday_trends':
      return eastmoneyRequest(url('https://push2his.eastmoney.com', '/api/qt/stock/trends2/get', {
        secid: stringParameter(parameters, 'secid'),
        fields1: EASTMONEY_TREND_FIELDS_1,
        fields2: EASTMONEY_TREND_FIELDS_2,
        ndays: integerParameter(parameters, 'days'),
        iscr: 0,
        iscca: 0,
      }))
    case 'em_money_flow_history':
      return eastmoneyRequest(url('https://push2his.eastmoney.com', '/api/qt/stock/fflow/daykline/get', {
        secid: stringParameter(parameters, 'secid'),
        lmt: integerParameter(parameters, 'limit'),
        klt: 101,
        fields1: EASTMONEY_FLOW_FIELDS_1,
        fields2: EASTMONEY_FLOW_FIELDS_2,
      }))
    case 'em_money_flow_intraday':
      return eastmoneyRequest(url('https://push2.eastmoney.com', '/api/qt/stock/fflow/kline/get', {
        secid: stringParameter(parameters, 'secid'),
        lmt: integerParameter(parameters, 'limit'),
        klt: 1,
        fields1: EASTMONEY_FLOW_FIELDS_1,
        fields2: EASTMONEY_FLOW_FIELDS_2,
      }))
    case 'em_connect_flow':
      return eastmoneyRequest(url('https://push2.eastmoney.com', '/api/qt/kamtbs.rtmin/get', {
        fields1: 'f1,f2,f3,f4',
        fields2: 'f51,f54,f52,f58,f53,f62,f56,f57,f60,f61',
        ut: EASTMONEY_UT,
      }))
    case 'em_datacenter_report': {
      const report = stringParameter(parameters, 'report')
      const reportName = requiredMapping(EASTMONEY_REPORTS, report, endpoint.id)
      return eastmoneyRequest(url('https://datacenter-web.eastmoney.com', '/api/data/v1/get', {
        reportName,
        columns: 'ALL',
        pageNumber: integerParameter(parameters, 'page'),
        pageSize: integerParameter(parameters, 'limit'),
        ...(report === 'dragon_tiger' ? { sortColumns: 'SECURITY_CODE', sortTypes: 1 } : {}),
      }))
    }
    case 'em_channel_news':
      return eastmoneyRequest(url('https://np-listapi.eastmoney.com', '/comm/web/getNewsByColumns', {
        client: 'web',
        biz: 'web_news_col',
        column: stringParameter(parameters, 'channel') === 'finance' ? 345 : 346,
        order: 1,
        needInteractData: 0,
        page_index: integerParameter(parameters, 'page'),
        page_size: integerParameter(parameters, 'limit'),
        req_trace: 1,
      }))
    case 'em_global_search': {
      const scope = stringParameter(parameters, 'scope')
      if (scope === 'stock' || scope === 'fund') {
        return eastmoneyRequest(
          url('https://search-codetable.eastmoney.com', '/codetable/search/web/market', {
            keyword: stringParameter(parameters, 'keyword'),
            label: requiredMapping(EASTMONEY_SECURITY_SEARCH_LABELS, scope, endpoint.id),
            uid: '',
            pageIndex: integerParameter(parameters, 'page'),
            pageSize: integerParameter(parameters, 'limit'),
          }),
          'json',
          'https://so.eastmoney.com/',
        )
      }

      const upstreamType = requiredMapping(EASTMONEY_CONTENT_SEARCH_TYPES, scope, endpoint.id)
      const pageIndex = integerParameter(parameters, 'page')
      const pageSize = integerParameter(parameters, 'limit')
      const searchParameters = scope === 'news'
        ? {
            searchScope: 'default',
            sort: 'default',
            pageIndex,
            pageSize,
            preTag: '',
            postTag: '',
          }
        : {
            pageIndex,
            pageSize,
            preTag: '',
            postTag: '',
            sortOrder: 1,
          }
      const param = JSON.stringify({
        uid: '',
        keyword: stringParameter(parameters, 'keyword'),
        type: [upstreamType],
        client: 'web',
        clientType: 'web',
        clientVersion: 'curr',
        param: { [upstreamType]: searchParameters },
      })
      return eastmoneyRequest(
        url('https://search-api-web.eastmoney.com', '/search/jsonp', { cb: 'dshStockCallback', param }),
        'jsonp',
        'https://so.eastmoney.com/',
      )
    }
    case 'em_guba_page':
      return eastmoneyRequest(
        `https://guba.eastmoney.com/list,${stringParameter(parameters, 'stock_code')}.html`,
        'html',
        'https://guba.eastmoney.com/',
      )
    case 'tx_realtime_quotes':
      return tencentRequest(
        `https://qt.gtimg.cn/q=${stringParameter(parameters, 'symbols')}`,
        'gbk',
        'tencent-quotes',
      )
    case 'tx_price_history': {
      const adjust = stringParameter(parameters, 'adjust')
      const param = [
        stringParameter(parameters, 'symbol'),
        stringParameter(parameters, 'period'),
        optionalStringParameter(parameters, 'start') ?? '',
        optionalStringParameter(parameters, 'end') ?? '',
        String(integerParameter(parameters, 'limit')),
        adjust === 'none' ? '' : adjust,
      ].join(',')
      return tencentRequest(url('https://web.ifzq.gtimg.cn', '/appstock/app/fqkline/get', { param }))
    }
    case 'tx_intraday_trends':
      return tencentRequest(url('https://web.ifzq.gtimg.cn', '/appstock/app/minute/query', {
        code: stringParameter(parameters, 'symbol'),
      }))
    case 'tx_stock_rank':
      return tencentRequest(url('https://proxy.finance.qq.com', '/cgi/cgi-bin/rank/hs/getBoardRankList', {
        board_code: 'aStock',
        sort_type: stringParameter(parameters, 'sort'),
        direct: stringParameter(parameters, 'order') === 'desc' ? 'down' : 'up',
        offset: integerParameter(parameters, 'offset'),
        count: integerParameter(parameters, 'limit'),
      }))
    case 'tx_sector_rank':
      return tencentRequest(url('https://proxy.finance.qq.com', '/cgi/cgi-bin/rank/pt/getRank', {
        board_type: requiredMapping(TENCENT_SECTOR_TYPES, stringParameter(parameters, 'sector_type'), endpoint.id),
        sort_type: stringParameter(parameters, 'sort'),
        direct: stringParameter(parameters, 'order') === 'desc' ? 'down' : 'up',
        offset: integerParameter(parameters, 'offset'),
        count: integerParameter(parameters, 'limit'),
      }))
    case 'tx_stock_news': {
      const limit = integerParameter(parameters, 'limit')
      return tencentRequest(url('https://web.ifzq.gtimg.cn', '/appstock/news/info/search', {
        symbol: stringParameter(parameters, 'symbol'),
        n: limit,
        page: integerParameter(parameters, 'page'),
        limit,
        type: 2,
      }))
    }
    case 'sina_realtime_quotes':
      return sinaRequest(
        `https://hq.sinajs.cn/list=${stringParameter(parameters, 'symbols')}`,
        'gbk',
        'sina-quotes',
      )
    case 'sina_price_history':
      return sinaRequest(url('https://quotes.sina.cn', '/cn/api/json_v2.php/CN_MarketDataService.getKLineData', {
        symbol: stringParameter(parameters, 'symbol'),
        scale: integerParameter(parameters, 'scale'),
        ma: 'no',
        datalen: integerParameter(parameters, 'limit'),
      }))
    case 'sina_intraday_kline':
      return sinaRequest(url('https://money.finance.sina.com.cn', '/quotes_service/api/json_v2.php/CN_MarketData.getKLineData', {
        symbol: stringParameter(parameters, 'symbol'),
        scale: integerParameter(parameters, 'scale'),
        ma: 'no',
        datalen: integerParameter(parameters, 'limit'),
      }))
    case 'sina_market_snapshot':
      return sinaRequest(url('https://vip.stock.finance.sina.com.cn', '/quotes_service/api/json_v2.php/Market_Center.getHQNodeData', {
        page: integerParameter(parameters, 'page'),
        num: integerParameter(parameters, 'limit'),
        sort: stringParameter(parameters, 'sort'),
        asc: stringParameter(parameters, 'order') === 'asc' ? 1 : 0,
        node: stringParameter(parameters, 'node'),
        symbol: '',
        _s_r_a: 'init',
      }))
    case 'sina_industry_catalog':
      return sinaRequest('https://money.finance.sina.com.cn/q/view/newSinaHy.php', 'gbk', 'script')
    case 'sina_concept_catalog':
      return sinaRequest(url('https://money.finance.sina.com.cn', '/q/view/newFLJK.php', { param: 'class' }), 'gbk', 'script')
    case 'sina_industry_overview':
      return sinaRequest(url('https://money.finance.sina.com.cn', '/q/view/newFLJK.php', { param: 'industry' }), 'gbk', 'script')
    case 'sina_stock_money_flow':
      return sinaRequest(url('https://vip.stock.finance.sina.com.cn', '/quotes_service/api/json_v2.php/MoneyFlow.ssl_qsfx_zjlrqs', {
        page: integerParameter(parameters, 'page'),
        num: integerParameter(parameters, 'limit'),
        sort: 'netamount',
        asc: 0,
        daima: stringParameter(parameters, 'symbol'),
      }))
    case 'sina_sector_money_flow':
      return sinaRequest(url('https://vip.stock.finance.sina.com.cn', '/quotes_service/api/json_v2.php/MoneyFlow.ssl_bkzj_zjlrqs', {
        page: integerParameter(parameters, 'page'),
        num: integerParameter(parameters, 'limit'),
        sort: 'netamount',
        asc: 0,
        fenlei: stringParameter(parameters, 'sector_type') === 'industry' ? 1 : 2,
      }))
    case 'sina_rolling_news':
      return sinaRequest(url('https://feed.mix.sina.com.cn', '/api/roll/get', {
        pageid: 153,
        lid: requiredMapping(SINA_NEWS_CHANNELS, stringParameter(parameters, 'channel'), endpoint.id),
        num: integerParameter(parameters, 'limit'),
        page: integerParameter(parameters, 'page'),
      }))
    case 'sina_stock_news_page':
      return sinaRequest(
        `https://vip.stock.finance.sina.com.cn/corp/go.php/vCB_AllNewsStock/symbol/${stringParameter(parameters, 'symbol')}.phtml`,
        'gbk',
        'html',
      )
    case 'sina_stock_announcements_page':
      return sinaRequest(
        `https://vip.stock.finance.sina.com.cn/corp/go.php/vCB_AllBulletin/symbol/${stringParameter(parameters, 'symbol')}.phtml`,
        'gbk',
        'html',
      )
    case 'sina_dragon_tiger_page':
      return sinaRequest(
        'https://vip.stock.finance.sina.com.cn/q/go.php/vLHBData/kind/ggtj/index.phtml',
        'gbk',
        'html',
      )
    case 'ths_price_history':
      return tonghuashunRequest(
        `https://d.10jqka.com.cn/v6/line/${stringParameter(parameters, 'symbol')}/01/${stringParameter(parameters, 'archive')}.js`,
      )
    case 'ths_intraday_trends':
      return tonghuashunRequest(
        `https://d.10jqka.com.cn/v6/time/${stringParameter(parameters, 'symbol')}/last.js`,
      )
  }
  throw new StockApiError(`公开接口尚未映射：${endpointId}。`, 'bad-request')
}

function eastmoneyRequest(
  requestUrl: string,
  responseKind: ResponseKind = 'json',
  referer = 'https://data.eastmoney.com/',
): PublicRequest {
  const fallbackUrls = eastmoneyFallbackUrls(requestUrl)
  return {
    url: requestUrl,
    ...(fallbackUrls.length === 0 ? {} : { fallbackUrls }),
    encoding: 'utf-8',
    responseKind,
    headers: {
      Accept: responseKind === 'html' ? 'text/html,application/xhtml+xml' : 'application/json, text/plain, */*',
      Referer: referer,
      'User-Agent': USER_AGENT,
    },
  }
}

function eastmoneyFallbackUrls(requestUrl: string): readonly string[] {
  const target = new URL(requestUrl)
  if (!['push2.eastmoney.com', 'push2his.eastmoney.com'].includes(target.hostname)) return []
  return [`https://push2delay.eastmoney.com${target.pathname}${target.search}`]
}

function tencentRequest(
  requestUrl: string,
  encoding: TextEncoding = 'utf-8',
  responseKind: ResponseKind = 'json',
): PublicRequest {
  return {
    url: requestUrl,
    encoding,
    responseKind,
    headers: {
      Accept: responseKind === 'tencent-quotes' ? 'text/plain, */*' : 'application/json, text/plain, */*',
      'User-Agent': USER_AGENT,
    },
  }
}

function sinaRequest(
  requestUrl: string,
  encoding: TextEncoding = 'utf-8',
  responseKind: ResponseKind = 'json',
): PublicRequest {
  return {
    url: requestUrl,
    encoding,
    responseKind,
    headers: {
      Accept: responseKind === 'html' ? 'text/html,application/xhtml+xml' : 'application/json, text/plain, */*',
      Referer: 'https://finance.sina.com.cn/',
      'User-Agent': USER_AGENT,
    },
  }
}

function tonghuashunRequest(requestUrl: string): PublicRequest {
  return {
    url: requestUrl,
    encoding: 'gbk',
    responseKind: 'script',
    headers: {
      Accept: 'application/javascript, text/javascript, */*',
      Referer: 'http://stockpage.10jqka.com.cn/',
      'User-Agent': USER_AGENT,
    },
  }
}

function restrictResponseToPluginScope(
  endpoint: DocumentedPublicEndpoint,
  parameters: Record<string, StockApiJson>,
  value: StockApiJson,
): StockApiJson {
  if (endpoint.id !== 'em_global_search' || parameters.scope !== 'stock') return value
  if (!isRecord(value) || !isRecord(value.result) || !Array.isArray(value.result.labelList)) return value

  const labelList = value.result.labelList.map(label => {
    if (!isRecord(label)) return label
    const { count: upstreamCount, ...rest } = label
    const quoteList = Array.isArray(label.quoteList)
      ? label.quoteList.filter(isEastMoneyAShareSearchQuote)
      : []
    return {
      ...rest,
      name: '沪深 A 股',
      type: 'A_STOCK',
      returned_count: quoteList.length,
      ...(typeof upstreamCount === 'number' || typeof upstreamCount === 'string'
        ? { upstream_count: upstreamCount }
        : {}),
      quoteList,
    }
  })
  return toJsonValue({
    ...value,
    result: { ...value.result, labelList },
  }, '东方财富股票搜索响应')
}

function isEastMoneyAShareSearchQuote(value: unknown): boolean {
  if (!isRecord(value) || typeof value.code !== 'string') return false
  if (/^(?:600|601|603|605|688)\d{3}$/u.test(value.code)) {
    return value.market === 1 || value.market === '1'
  }
  if (/^(?:000|001|002|003|300|301)\d{3}$/u.test(value.code)) {
    return value.market === 0 || value.market === '0'
  }
  return false
}

function validateBusinessResponse(
  endpoint: DocumentedPublicEndpoint,
  parameters: Record<string, StockApiJson>,
  value: StockApiJson,
): void {
  if (endpoint.provider === 'eastmoney') {
    validateEastMoneyBusinessResponse(endpoint, parameters, value)
    return
  }

  if (endpoint.provider === 'tencent' && endpoint.id !== 'tx_realtime_quotes') {
    if (!isRecord(value)) throw new StockApiError('腾讯财经返回了无效数据。')
    const message = businessMessage(value)
    if (value.code !== 0 && value.code !== '0') {
      throw new StockApiError(`腾讯财经业务请求失败${message}。`)
    }
  }
}

function validateEastMoneyBusinessResponse(
  endpoint: DocumentedPublicEndpoint,
  parameters: Record<string, StockApiJson>,
  value: StockApiJson,
): void {
  if (endpoint.id === 'em_guba_page') return
  if (!isRecord(value)) throw new StockApiError('东方财富返回了无效数据。')

  if (endpoint.id === 'em_datacenter_report') {
    if (value.success !== true || (value.code !== 0 && value.code !== '0')) {
      throw new StockApiError(`东方财富数据中心业务请求失败${businessMessage(value)}。`)
    }
    requireNestedArray(value, 'result', 'data', '东方财富数据中心')
    return
  }

  if (endpoint.id === 'em_global_search') {
    if (value.code !== 0 && value.code !== '0') {
      throw new StockApiError(`东方财富搜索业务请求失败${businessMessage(value)}。`)
    }
    const result = value.result
    if (!isRecord(result)) throw new StockApiError('东方财富搜索响应缺少 result。')
    const scope = stringParameter(parameters, 'scope')
    const resultKey = scope === 'stock' || scope === 'fund'
      ? 'labelList'
      : requiredMapping(EASTMONEY_CONTENT_SEARCH_TYPES, scope, endpoint.id)
    if (!Array.isArray(result[resultKey])) {
      throw new StockApiError(`东方财富搜索响应缺少 ${resultKey} 列表。`)
    }
    return
  }

  if (endpoint.id === 'em_channel_news') {
    requireNestedArray(value, 'data', 'list', '东方财富频道资讯')
    return
  }

  requireEastMoneySuccess(value)
  switch (endpoint.id) {
    case 'em_realtime_quote':
      if (!isRecord(value.data)) throw new StockApiError('东方财富实时行情响应缺少 data。')
      return
    case 'em_market_snapshot':
    case 'em_batch_quotes':
      requireNestedArray(value, 'data', 'diff', '东方财富行情')
      return
    case 'em_price_history':
    case 'em_money_flow_history':
    case 'em_money_flow_intraday':
      requireNestedArray(value, 'data', 'klines', '东方财富历史行情')
      return
    case 'em_intraday_trends':
      requireNestedArray(value, 'data', 'trends', '东方财富分时行情')
      return
    case 'em_connect_flow': {
      const data = value.data
      if (!isRecord(data) || !Array.isArray(data.s2n) || !Array.isArray(data.n2s)) {
        throw new StockApiError('东方财富沪深港通响应缺少 data.s2n 或 data.n2s 列表。')
      }
      return
    }
  }
}

function requireEastMoneySuccess(value: Record<string, unknown>): void {
  if (value.rc === 0 || value.rc === '0') return
  throw new StockApiError(`东方财富业务请求失败${businessMessage(value)}。`)
}

function requireNestedArray(
  value: Record<string, unknown>,
  recordKey: string,
  arrayKey: string,
  label: string,
): void {
  const nested = value[recordKey]
  if (!isRecord(nested) || !Array.isArray(nested[arrayKey])) {
    throw new StockApiError(`${label}响应缺少 ${recordKey}.${arrayKey} 列表。`)
  }
}

function businessMessage(value: Record<string, unknown>): string {
  const detail = [value.message, value.msg].find(item => typeof item === 'string' && item.trim() !== '')
  return typeof detail === 'string' ? `：${detail}` : ''
}

function parseResponse(kind: ResponseKind, text: string, provider: string): StockApiJson {
  switch (kind) {
    case 'json': return parseJson(provider, text)
    case 'jsonp': return parseScriptPayload(provider, text, true)
    case 'script': return parseScriptPayload(provider, text, false)
    case 'html': return { content_type: 'text/html', body: text }
    case 'tencent-quotes': return parseTencentQuotes(text)
    case 'sina-quotes': return parseSinaQuotes(text)
  }
}

function parseJson(provider: string, text: string): StockApiJson {
  try {
    return toJsonValue(JSON.parse(stripBom(text)), `${provider}响应`)
  } catch (error) {
    if (error instanceof StockApiError) throw error
    throw new StockApiError(`${provider}返回了非 JSON 数据。`)
  }
}

function parseScriptPayload(provider: string, text: string, requireJson: boolean): StockApiJson {
  const source = stripBom(text).trim().replace(/;\s*$/u, '').trim()
  const assignment = /^(?:var\s+)?[A-Za-z_$][A-Za-z0-9_$.]*\s*=\s*([\s\S]+)$/u.exec(source)
  const callback = /^[A-Za-z_$][A-Za-z0-9_$.]*\s*\(\s*([\s\S]*)\s*\)$/u.exec(source)
  const payload = (assignment?.[1] ?? callback?.[1] ?? source).trim()
  try {
    return toJsonValue(JSON.parse(payload), `${provider}响应`)
  } catch (error) {
    if (error instanceof StockApiError) throw error
    if (requireJson) throw new StockApiError(`${provider}返回了无效的 JSONP 数据。`)
    return { raw: text }
  }
}

function parseTencentQuotes(text: string): StockApiJson {
  const quotes: StockApiJson[] = []
  for (const match of text.matchAll(/(?:^|[\r\n])\s*v_([A-Za-z0-9_]+)="((?:\\.|[^"])*)";?/gu)) {
    const fields = decodeJavascriptString(match[2]).split('~')
    quotes.push({
      symbol: match[1],
      name: fields[1] ?? '',
      code: fields[2] ?? '',
      price: numericOrNull(fields[3]),
      previous_close: numericOrNull(fields[4]),
      open: numericOrNull(fields[5]),
      volume_lots: numericOrNull(fields[6]),
      market_time: fields[30] ?? '',
      change: numericOrNull(fields[31]),
      change_percent: numericOrNull(fields[32]),
      high: numericOrNull(fields[33]),
      low: numericOrNull(fields[34]),
      amount_ten_thousand_cny: numericOrNull(fields[37]),
      turnover_rate: numericOrNull(fields[38]),
      pe_ttm: numericOrNull(fields[39]),
      amplitude: numericOrNull(fields[43]),
      float_market_cap_hundred_million: numericOrNull(fields[44]),
      market_cap_hundred_million: numericOrNull(fields[45]),
      pb: numericOrNull(fields[46]),
      upper_limit: numericOrNull(fields[47]),
      lower_limit: numericOrNull(fields[48]),
      fields,
    })
  }
  if (quotes.length === 0) throw new StockApiError('腾讯财经返回了无效的行情文本。')
  return { quotes }
}

function parseSinaQuotes(text: string): StockApiJson {
  const quotes: StockApiJson[] = []
  for (const match of text.matchAll(/(?:^|[\r\n])\s*var\s+hq_str_([A-Za-z0-9_]+)="((?:\\.|[^"])*)";?/gu)) {
    const fields = decodeJavascriptString(match[2]).split(',')
    const symbol = match[1]
    const aShare = /^(?:sh|sz)[0-9]{6}$/u.test(symbol)
    quotes.push({
      symbol,
      name: fields[0] ?? '',
      ...(aShare ? {
        open: numericOrNull(fields[1]),
        previous_close: numericOrNull(fields[2]),
        price: numericOrNull(fields[3]),
        high: numericOrNull(fields[4]),
        low: numericOrNull(fields[5]),
        bid: numericOrNull(fields[6]),
        ask: numericOrNull(fields[7]),
        volume_shares: numericOrNull(fields[8]),
        amount_cny: numericOrNull(fields[9]),
        date: fields[30] ?? '',
        time: fields[31] ?? '',
        status: fields[32] ?? '',
      } : {}),
      fields,
    })
  }
  if (quotes.length === 0) throw new StockApiError('新浪财经返回了无效的行情文本。')
  return { quotes }
}

function decodeJavascriptString(value: string): string {
  try {
    return JSON.parse(`"${value}"`) as string
  } catch {
    return value
  }
}

function numericOrNull(value: string | undefined): number | null {
  if (value === undefined || value.trim() === '') return null
  const numeric = Number(value)
  return Number.isFinite(numeric) ? numeric : null
}

function validateParameters(
  endpoint: DocumentedPublicEndpoint,
  value: unknown,
): Record<string, StockApiJson> {
  if (!isRecord(value)) throw new StockApiError('parameters 必须是对象。', 'bad-request')
  const descriptors: readonly StockApiParameterDescriptor[] = endpoint.parameters
  const allowed = new Map<string, StockApiParameterDescriptor>(
    descriptors.map(parameter => [parameter.name, parameter]),
  )
  const unknown = Object.keys(value).filter(key => !allowed.has(key))
  if (unknown.length > 0) {
    throw new StockApiError(`${endpoint.id} 不接受参数：${unknown.join('、')}。`, 'bad-request')
  }

  const normalized: Record<string, StockApiJson> = {}
  for (const parameter of descriptors) {
    const supplied = Object.hasOwn(value, parameter.name)
    const hasDefault = Object.hasOwn(parameter, 'default')
    if (!supplied && !hasDefault) {
      if (parameter.required) {
        throw new StockApiError(`${endpoint.id} 缺少必填参数：${parameter.name}。`, 'bad-request')
      }
      continue
    }
    const parameterValue = supplied ? value[parameter.name] : parameter.default
    normalized[parameter.name] = validateParameterValue(endpoint.id, parameter, parameterValue)
  }
  return normalized
}

function validateParameterValue(
  endpointId: string,
  parameter: StockApiParameterDescriptor,
  value: unknown,
): StockApiJson {
  const label = `${endpointId}.${parameter.name}`
  switch (parameter.type) {
    case 'string': {
      if (typeof value !== 'string') throw new StockApiError(`${label} 必须是字符串。`, 'bad-request')
      if (parameter.minLength !== undefined && value.length < parameter.minLength) {
        throw new StockApiError(`${label} 不能为空。`, 'bad-request')
      }
      if (parameter.maxLength !== undefined && value.length > parameter.maxLength) {
        throw new StockApiError(`${label} 长度不能超过 ${parameter.maxLength}。`, 'bad-request')
      }
      if (parameter.pattern !== undefined && !new RegExp(`^(?:${parameter.pattern})$`, 'u').test(value)) {
        throw new StockApiError(`${label} 格式无效。`, 'bad-request')
      }
      if (parameter.enum !== undefined && !parameter.enum.includes(value)) {
        throw new StockApiError(`${label} 必须为允许的枚举值。`, 'bad-request')
      }
      return value
    }
    case 'integer':
    case 'number': {
      if (typeof value !== 'number' || !Number.isFinite(value) || (parameter.type === 'integer' && !Number.isInteger(value))) {
        throw new StockApiError(`${label} 必须是${parameter.type === 'integer' ? '整数' : '有限数字'}。`, 'bad-request')
      }
      if (parameter.minimum !== undefined && value < parameter.minimum) {
        throw new StockApiError(`${label} 不能小于 ${parameter.minimum}。`, 'bad-request')
      }
      if (parameter.maximum !== undefined && value > parameter.maximum) {
        throw new StockApiError(`${label} 不能大于 ${parameter.maximum}。`, 'bad-request')
      }
      if (parameter.enum !== undefined && !parameter.enum.includes(value)) {
        throw new StockApiError(`${label} 必须为允许的枚举值。`, 'bad-request')
      }
      return value
    }
    case 'boolean':
      if (typeof value !== 'boolean') throw new StockApiError(`${label} 必须是布尔值。`, 'bad-request')
      return value
    case 'array':
      if (!Array.isArray(value)) throw new StockApiError(`${label} 必须是数组。`, 'bad-request')
      if (value.length > MAX_ARRAY_ITEMS) throw new StockApiError(`${label} 数组过长。`, 'bad-request')
      return value.map(item => toJsonValue(item, label))
    case 'object':
      if (!isRecord(value)) throw new StockApiError(`${label} 必须是对象。`, 'bad-request')
      return toJsonValue(value, label)
  }
}

function requiredMapping<T>(mapping: Readonly<Record<string, T>>, key: string, endpointId: string): T {
  const value = mapping[key]
  if (value === undefined) throw new StockApiError(`${endpointId} 参数映射失败。`, 'bad-request')
  return value
}

function stringParameter(parameters: Record<string, StockApiJson>, name: string): string {
  const value = parameters[name]
  if (typeof value !== 'string') throw new StockApiError(`缺少字符串参数：${name}。`, 'bad-request')
  return value
}

function optionalStringParameter(parameters: Record<string, StockApiJson>, name: string): string | undefined {
  const value = parameters[name]
  if (value === undefined) return undefined
  if (typeof value !== 'string') throw new StockApiError(`${name} 必须是字符串。`, 'bad-request')
  return value
}

function integerParameter(parameters: Record<string, StockApiJson>, name: string): number {
  const value = parameters[name]
  if (typeof value !== 'number' || !Number.isInteger(value)) {
    throw new StockApiError(`缺少整数参数：${name}。`, 'bad-request')
  }
  return value
}

function url(origin: string, path: string, parameters: Record<string, string | number>): string {
  const target = new URL(path, origin)
  for (const [name, value] of Object.entries(parameters)) target.searchParams.set(name, String(value))
  return target.toString()
}

async function readBoundedText(
  response: Response,
  encoding: TextEncoding,
  maximum: number,
): Promise<string> {
  const contentLength = response.headers.get('content-length')
  if (contentLength !== null && Number(contentLength) > maximum) {
    try {
      await response.body?.cancel()
    } catch {
      // The size error remains authoritative.
    }
    throw new StockApiError(`上游响应超过 ${maximum} 字节限制。`)
  }

  if (response.body === null) {
    const bytes = new Uint8Array(await response.arrayBuffer())
    if (bytes.byteLength > maximum) throw new StockApiError(`上游响应超过 ${maximum} 字节限制。`)
    return new TextDecoder(encoding).decode(bytes)
  }

  const reader = response.body.getReader()
  const chunks: Uint8Array[] = []
  let size = 0
  try {
    for (;;) {
      const item = await reader.read()
      if (item.done) break
      size += item.value.byteLength
      if (size > maximum) {
        await reader.cancel()
        throw new StockApiError(`上游响应超过 ${maximum} 字节限制。`)
      }
      chunks.push(item.value)
    }
  } finally {
    reader.releaseLock()
  }
  const bytes = new Uint8Array(size)
  let offset = 0
  for (const chunk of chunks) {
    bytes.set(chunk, offset)
    offset += chunk.byteLength
  }
  return new TextDecoder(encoding).decode(bytes)
}

function boundJson(value: StockApiJson): StockApiJson {
  if (typeof value === 'string') {
    return value.length > MAX_STRING_CHARACTERS
      ? `${value.slice(0, MAX_STRING_CHARACTERS)}\n[内容已截断]`
      : value
  }
  if (Array.isArray(value)) {
    if (value.length > MAX_ARRAY_ITEMS) {
      return {
        items: value.slice(0, MAX_ARRAY_ITEMS).map(boundJson),
        returned_count: MAX_ARRAY_ITEMS,
        total_count: value.length,
        truncated: true,
      }
    }
    return value.map(boundJson)
  }
  if (isRecord(value)) {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, boundJson(item as StockApiJson)]))
  }
  return value
}

function toJsonValue(value: unknown, label: string, depth = 0): StockApiJson {
  if (depth > 32) throw new StockApiError(`${label} 嵌套层级过深。`)
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new StockApiError(`${label} 包含非有限数字。`)
    return value
  }
  if (Array.isArray(value)) return value.map(item => toJsonValue(item, label, depth + 1))
  if (isRecord(value)) {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, toJsonValue(item, label, depth + 1)]))
  }
  throw new StockApiError(`${label} 必须是 JSON 值。`)
}

function stripBom(value: string): string {
  return value.charCodeAt(0) === 0xfeff ? value.slice(1) : value
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function throwIfAborted(signal: AbortSignal): void {
  if (signal.aborted) throw new StockApiError('请求已取消。', 'cancelled')
}

async function withDeadline<T>(
  signal: AbortSignal,
  timeoutMs: number,
  provider: string,
  operation: (signal: AbortSignal) => Promise<T>,
): Promise<T> {
  throwIfAborted(signal)
  const controller = new AbortController()
  let timedOut = false
  const onAbort = (): void => { controller.abort() }
  signal.addEventListener('abort', onAbort, { once: true })
  if (signal.aborted) controller.abort()
  const timer = setTimeout(() => {
    timedOut = true
    controller.abort()
  }, timeoutMs)
  try {
    return await operation(controller.signal)
  } catch (error) {
    if (signal.aborted) throw new StockApiError('请求已取消。', 'cancelled')
    if (timedOut) throw new StockApiError(`${provider}请求超时。`)
    throw error
  } finally {
    clearTimeout(timer)
    signal.removeEventListener('abort', onAbort)
  }
}

function sleepWithSignal(milliseconds: number, signal: AbortSignal): Promise<void> {
  if (signal.aborted) return Promise.reject(new StockApiError('请求已取消。', 'cancelled'))
  return new Promise((resolve, reject) => {
    const timer = setTimeout(done, milliseconds)
    const onAbort = (): void => {
      clearTimeout(timer)
      done(new StockApiError('请求已取消。', 'cancelled'))
    }
    function done(error?: Error): void {
      signal.removeEventListener('abort', onAbort)
      if (error !== undefined) reject(error)
      else resolve()
    }
    signal.addEventListener('abort', onAbort, { once: true })
  })
}

class ProviderGate {
  private active = 0
  private readonly queue: Array<() => void> = []
  private readonly startGate: StartIntervalGate

  constructor(
    private readonly maximum: number,
    minimumIntervalMs: number,
  ) {
    this.startGate = new StartIntervalGate(minimumIntervalMs)
  }

  async run<T>(
    signal: AbortSignal,
    operation: (startGate: StartIntervalGate) => Promise<T>,
  ): Promise<T> {
    await this.acquire(signal)
    try {
      return await operation(this.startGate)
    } finally {
      this.release()
    }
  }

  private async acquire(signal: AbortSignal): Promise<void> {
    throwIfAborted(signal)
    if (this.active < this.maximum) {
      this.active++
      return
    }
    await new Promise<void>((resolve, reject) => {
      let settled = false
      const resume = (): void => {
        if (settled) return
        settled = true
        signal.removeEventListener('abort', cancel)
        this.active++
        resolve()
      }
      const cancel = (): void => {
        if (settled) return
        settled = true
        signal.removeEventListener('abort', cancel)
        const index = this.queue.indexOf(resume)
        if (index >= 0) this.queue.splice(index, 1)
        reject(new StockApiError('请求已取消。', 'cancelled'))
      }
      this.queue.push(resume)
      signal.addEventListener('abort', cancel, { once: true })
      if (signal.aborted) cancel()
    })
  }

  private release(): void {
    this.active--
    this.queue.shift()?.()
  }
}
