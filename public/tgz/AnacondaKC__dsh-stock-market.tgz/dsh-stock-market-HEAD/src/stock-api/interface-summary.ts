import type { StockDataProvider } from './types.ts'

export interface StockInterfaceSummary {
  provider: StockDataProvider
  name: string
  endpointCount: number
  toolNames: readonly string[]
  groups: readonly string[]
  visibleInterfaces: readonly string[]
  note: string
}

export const STOCK_INTERFACE_SUMMARIES = [
  {
    provider: 'eastmoney',
    name: '东方财富',
    endpointCount: 36,
    toolNames: ['stock_quote', 'stock_chart', 'stock_ranking', 'stock_money_flow', 'stock_fundamentals', 'stock_events', 'stock_research', 'stock_news'],
    groups: ['行情', '历史数据', '资金流', '数据中心', '公司与财务', '研报与资讯'],
    visibleInterfaces: ['实时/批量行情与排行', 'K 线与分时', '个股、板块及沪深港通资金', '龙虎榜等数据中心报表', 'F10、公告、研报、快讯与搜索'],
    note: '无需凭据；固定公开目录包含 push2，连接失败会有限重试。',
  },
  {
    provider: 'tencent',
    name: '腾讯财经',
    endpointCount: 6,
    toolNames: ['stock_quote', 'stock_chart', 'stock_ranking', 'stock_news'],
    groups: ['行情', '历史数据', '排行', '资讯'],
    visibleInterfaces: ['批量实时行情', 'K 线与分时', '个股和板块排行', '个股资讯'],
    note: '无需凭据；GBK 行情由服务端解码，调用启动间隔至少 100ms。',
  },
  {
    provider: 'sina',
    name: '新浪财经',
    endpointCount: 13,
    toolNames: ['stock_quote', 'stock_chart', 'stock_ranking', 'stock_money_flow', 'stock_events', 'stock_news'],
    groups: ['行情', '历史数据', '板块', '资金流', '资讯与 HTML'],
    visibleInterfaces: ['批量实时行情', '日/周/月及分钟 K 线', '市场和板块目录', '个股与板块资金流', '滚动新闻、公告及龙虎榜页'],
    note: '无需凭据；服务端固定携带 Referer，并按 GBK/UTF-8 分别解码。',
  },
  {
    provider: 'tonghuashun',
    name: '同花顺',
    endpointCount: 2,
    toolNames: ['stock_chart'],
    groups: ['历史数据', '分时'],
    visibleInterfaces: ['最新或月度日 K', '当日分时走势'],
    note: '无需凭据；固定携带 Referer，GBK JSONP 由服务端解析。',
  },
] as const satisfies readonly StockInterfaceSummary[]
