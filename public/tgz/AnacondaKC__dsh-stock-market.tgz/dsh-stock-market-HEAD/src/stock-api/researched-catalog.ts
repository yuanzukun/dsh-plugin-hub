import type {
  EastMoneyEndpointDescriptor,
  PublicWebsiteEndpointDescriptor,
  PublicWebsiteProvider,
} from './types.ts'

const A_SHARE_SH_CODE_PATTERN = '(?:600|601|603|605|688)[0-9]{3}'
const A_SHARE_SZ_CODE_PATTERN = '(?:000|001|002|003|300|301)[0-9]{3}'
const A_SHARE_CODE_PATTERN = `(?:${A_SHARE_SH_CODE_PATTERN}|${A_SHARE_SZ_CODE_PATTERN})`
const EASTMONEY_SECID_PATTERN = '(?:0|1)[.][0-9]{6}'
const TENCENT_SYMBOL_PATTERN = `(?:sh${A_SHARE_SH_CODE_PATTERN}|sz${A_SHARE_SZ_CODE_PATTERN})`

const EASTMONEY_SECID = {
  name: 'secid',
  location: 'query',
  type: 'string',
  required: true,
  description: '东方财富沪深证券 ID，例如 1.600519 或 0.000001。',
  pattern: EASTMONEY_SECID_PATTERN,
  maxLength: 8,
} as const

const EASTMONEY_UT = 'fa5fd1943c7b386f172d6893dbfba10b'

/** Public website endpoints verified in 股票行情接口调研文档.md. */
export const DOCUMENTED_EASTMONEY_ENDPOINTS = [
  {
    id: 'em_realtime_quote',
    provider: 'eastmoney',
    name: '实时行情',
    group: 'quote',
    summary: '查询沪深 A 股的实时行情快照。',
    features: ['实时价格', '成交量额', '估值', '市值'],
    path: '/api/qt/stock/get',
    parameters: [EASTMONEY_SECID],
  },
  {
    id: 'em_market_snapshot',
    provider: 'eastmoney',
    name: '全市场行情排行',
    group: 'quote',
    summary: '按市场或板块分页查询行情快照和涨跌排行。',
    features: ['A 股列表', '板块排行', '分页'],
    path: '/api/qt/clist/get',
    parameters: [
      {
        name: 'market', location: 'query', type: 'string', required: false, default: 'all_a',
        enum: ['all_a', 'sh_a', 'sz_a', 'chinext', 'star', 'industry', 'concept', 'region'],
        description: '固定市场筛选器。',
      },
      {
        name: 'page', location: 'query', type: 'integer', required: false, default: 1,
        minimum: 1, maximum: 10_000, description: '页码。',
      },
      {
        name: 'limit', location: 'query', type: 'integer', required: false, default: 50,
        minimum: 1, maximum: 100, description: '每页数量。',
      },
      {
        name: 'sort', location: 'query', type: 'string', required: false, default: 'change_percent',
        enum: ['price', 'change_percent', 'change', 'volume', 'amount', 'turnover_rate', 'net_inflow', 'code'],
        description: '排序字段。',
      },
      {
        name: 'order', location: 'query', type: 'string', required: false, default: 'desc',
        enum: ['asc', 'desc'], description: '排序方向。',
      },
    ],
  },
  {
    id: 'em_batch_quotes',
    provider: 'eastmoney',
    name: '批量实时行情',
    group: 'quote',
    summary: '一次查询最多 60 个东方财富证券 ID。',
    features: ['批量行情', '沪深两市'],
    path: '/api/qt/ulist.np/get',
    parameters: [{
      name: 'secids', location: 'query', type: 'string', required: true,
      description: '逗号分隔的证券 ID，最多 60 个。', maxLength: 2_000,
      pattern: `(?:${EASTMONEY_SECID_PATTERN})(?:,(?:${EASTMONEY_SECID_PATTERN})){0,59}`,
    }],
  },
  {
    id: 'em_price_history',
    provider: 'eastmoney',
    name: '历史 K 线',
    group: 'history',
    summary: '查询日、周、月或 1/5/15/30/60 分钟 K 线，支持三种复权方式。',
    features: ['历史 K 线', '分钟 K 线', '前后复权'],
    path: '/api/qt/stock/kline/get',
    parameters: [
      EASTMONEY_SECID,
      {
        name: 'period', location: 'query', type: 'string', required: false, default: 'day',
        enum: ['1m', '5m', '15m', '30m', '60m', 'day', 'week', 'month'],
        description: 'K 线周期。',
      },
      {
        name: 'adjust', location: 'query', type: 'string', required: false, default: 'qfq',
        enum: ['none', 'qfq', 'hfq'], description: '不复权、前复权或后复权。',
      },
      {
        name: 'begin', location: 'query', type: 'string', required: false, default: '19900101',
        pattern: '[0-9]{8}', description: '开始日期，yyyyMMdd。',
      },
      {
        name: 'end', location: 'query', type: 'string', required: false, default: '20500101',
        pattern: '[0-9]{8}', description: '结束日期，yyyyMMdd。',
      },
      {
        name: 'limit', location: 'query', type: 'integer', required: false, default: 120,
        minimum: 1, maximum: 10_000, description: '最多返回条数。',
      },
    ],
  },
  {
    id: 'em_intraday_trends',
    provider: 'eastmoney',
    name: '分时走势',
    group: 'history',
    summary: '查询当日或近五日逐分钟走势。',
    features: ['当日分时', '五日分时'],
    path: '/api/qt/stock/trends2/get',
    parameters: [
      EASTMONEY_SECID,
      {
        name: 'days', location: 'query', type: 'integer', required: false, default: 1,
        enum: [1, 5], description: '1 日或 5 日。',
      },
    ],
  },
  {
    id: 'em_money_flow_history',
    provider: 'eastmoney',
    name: '个股历史资金流',
    group: 'money_flow',
    summary: '查询个股日级主力、大单、中单和小单资金净流入。',
    features: ['主力资金', '历史资金流'],
    path: '/api/qt/stock/fflow/daykline/get',
    parameters: [
      EASTMONEY_SECID,
      {
        name: 'limit', location: 'query', type: 'integer', required: false, default: 120,
        minimum: 0, maximum: 10_000, description: '返回条数；0 表示上游可提供的全部记录。',
      },
    ],
  },
  {
    id: 'em_money_flow_intraday',
    provider: 'eastmoney',
    name: '个股实时资金流',
    group: 'money_flow',
    summary: '查询个股分钟级主力资金流。',
    features: ['主力资金', '分钟资金流'],
    path: '/api/qt/stock/fflow/kline/get',
    parameters: [
      EASTMONEY_SECID,
      {
        name: 'limit', location: 'query', type: 'integer', required: false, default: 0,
        minimum: 0, maximum: 1_000, description: '返回条数；0 表示上游默认范围。',
      },
    ],
  },
  {
    id: 'em_connect_flow',
    provider: 'eastmoney',
    name: '沪深港通资金',
    group: 'money_flow',
    summary: '查询南向分钟净流入；现行公开源不再提供北向分钟净流入。',
    features: ['南向资金', '北向不可用状态'],
    path: '/api/qt/kamtbs.rtmin/get',
    parameters: [],
  },
  {
    id: 'em_datacenter_report',
    provider: 'eastmoney',
    name: '数据中心报表',
    group: 'data_center',
    summary: '查询文档列明的龙虎榜、财经日历、可转债或融资融券报表。',
    features: ['龙虎榜', '财经日历', '可转债', '融资融券'],
    path: '/api/data/v1/get',
    parameters: [
      {
        name: 'report', location: 'query', type: 'string', required: true,
        enum: ['dragon_tiger', 'economic_calendar', 'convertible_bonds', 'margin_detail'],
        description: '固定报表别名。',
      },
      {
        name: 'page', location: 'query', type: 'integer', required: false, default: 1,
        minimum: 1, maximum: 10_000, description: '页码。',
      },
      {
        name: 'limit', location: 'query', type: 'integer', required: false, default: 20,
        minimum: 1, maximum: 100, description: '每页数量。',
      },
    ],
  },
  {
    id: 'em_channel_news',
    provider: 'eastmoney',
    name: '频道资讯',
    group: 'news',
    summary: '查询东方财富财经或全球频道资讯。',
    features: ['财经资讯', '全球资讯'],
    path: '/comm/web/getNewsByColumns',
    parameters: [
      {
        name: 'channel', location: 'query', type: 'string', required: false, default: 'finance',
        enum: ['finance', 'global'], description: '财经或全球频道。',
      },
      {
        name: 'page', location: 'query', type: 'integer', required: false, default: 1,
        minimum: 1, maximum: 10_000, description: '页码。',
      },
      {
        name: 'limit', location: 'query', type: 'integer', required: false, default: 20,
        minimum: 1, maximum: 100, description: '每页数量。',
      },
    ],
  },
  {
    id: 'em_global_search',
    provider: 'eastmoney',
    name: '全文搜索',
    group: 'search',
    summary: '按当前网页实际调用搜索资讯、沪深 A 股、基金或股吧帖子。',
    features: ['资讯搜索', '股票搜索', '基金搜索', '股吧搜索'],
    path: '/search/jsonp | /codetable/search/web/market',
    parameters: [
      {
        name: 'keyword', location: 'query', type: 'string', required: true,
        minLength: 1, maxLength: 200, description: '搜索关键词。',
      },
      {
        name: 'scope', location: 'query', type: 'string', required: false, default: 'news',
        enum: ['news', 'stock', 'fund', 'guba'], description: '搜索类型。',
      },
      {
        name: 'page', location: 'query', type: 'integer', required: false, default: 1,
        minimum: 1, maximum: 1_000, description: '页码。',
      },
      {
        name: 'limit', location: 'query', type: 'integer', required: false, default: 10,
        minimum: 1, maximum: 100, description: '每页数量。',
      },
    ],
  },
  {
    id: 'em_guba_page',
    provider: 'eastmoney',
    name: '股吧帖子列表页',
    group: 'search',
    summary: '读取无需登录的股吧 HTML 列表页；JSON API 仍因 403 不开放。',
    features: ['股吧 HTML'],
    path: '/list,{stock_code}.html',
    parameters: [{
      name: 'stock_code', location: 'path', type: 'string', required: true,
      pattern: A_SHARE_CODE_PATTERN, description: '沪深 A 股六位代码，例如 600519。',
    }],
  },
] as const satisfies readonly EastMoneyEndpointDescriptor[]

const TENCENT_SYMBOL = {
  name: 'symbol', location: 'query', type: 'string', required: true,
  description: '腾讯沪深 A 股代码，例如 sh600519 或 sz000001。',
  pattern: TENCENT_SYMBOL_PATTERN,
  maxLength: 8,
} as const

export const TENCENT_ENDPOINTS = [
  {
    id: 'tx_realtime_quotes', provider: 'tencent', name: '批量实时行情', group: 'quote',
    summary: '批量查询沪深 A 股实时行情。',
    features: ['实时行情', '批量行情', '盘口'], path: '/q=',
    parameters: [{
      name: 'symbols', location: 'query', type: 'string', required: true, maxLength: 2_000,
      description: '逗号分隔的腾讯证券代码，最多 60 个。',
      pattern: `(?:(?:s_)?${TENCENT_SYMBOL_PATTERN})(?:,(?:(?:s_)?${TENCENT_SYMBOL_PATTERN})){0,59}`,
    }],
  },
  {
    id: 'tx_price_history', provider: 'tencent', name: '历史 K 线', group: 'history',
    summary: '查询日、周、月或分钟 K 线，支持三种复权方式。',
    features: ['历史 K 线', '分钟 K 线', '前后复权'], path: '/appstock/app/fqkline/get',
    parameters: [
      TENCENT_SYMBOL,
      {
        name: 'period', location: 'query', type: 'string', required: false, default: 'day',
        enum: ['day', 'week', 'month', 'm5', 'm15', 'm30', 'm60'], description: 'K 线周期。',
      },
      {
        name: 'start', location: 'query', type: 'string', required: false,
        pattern: '[0-9]{4}-[0-9]{2}-[0-9]{2}', description: '可选开始日期，yyyy-MM-dd。',
      },
      {
        name: 'end', location: 'query', type: 'string', required: false,
        pattern: '[0-9]{4}-[0-9]{2}-[0-9]{2}', description: '可选结束日期，yyyy-MM-dd。',
      },
      {
        name: 'limit', location: 'query', type: 'integer', required: false, default: 320,
        minimum: 1, maximum: 2_000, description: '最多返回条数。',
      },
      {
        name: 'adjust', location: 'query', type: 'string', required: false, default: 'qfq',
        enum: ['none', 'qfq', 'hfq'], description: '不复权、前复权或后复权。',
      },
    ],
  },
  {
    id: 'tx_intraday_trends', provider: 'tencent', name: '分时走势', group: 'history',
    summary: '查询个股、指数或 ETF 的当日分时走势。',
    features: ['当日分时'], path: '/appstock/app/minute/query', parameters: [TENCENT_SYMBOL],
  },
  {
    id: 'tx_stock_rank', provider: 'tencent', name: '个股排行', group: 'ranking',
    summary: '分页查询沪深 A 股行情排行。',
    features: ['A 股排行'], path: '/cgi/cgi-bin/rank/hs/getBoardRankList',
    parameters: [
      {
        name: 'sort', location: 'query', type: 'string', required: false, default: 'price',
        enum: ['price', 'pn', 'turnover', 'volume'], description: '已验证可用的排序字段。',
      },
      {
        name: 'order', location: 'query', type: 'string', required: false, default: 'desc',
        enum: ['asc', 'desc'], description: '排序方向。',
      },
      {
        name: 'offset', location: 'query', type: 'integer', required: false, default: 0,
        minimum: 0, maximum: 100_000, description: '分页偏移。',
      },
      {
        name: 'limit', location: 'query', type: 'integer', required: false, default: 20,
        minimum: 1, maximum: 100, description: '返回数量。',
      },
    ],
  },
  {
    id: 'tx_sector_rank', provider: 'tencent', name: '板块排行', group: 'ranking',
    summary: '查询行业、概念或地域板块排行。',
    features: ['行业板块', '概念板块', '地域板块'], path: '/cgi/cgi-bin/rank/pt/getRank',
    parameters: [
      {
        name: 'sector_type', location: 'query', type: 'string', required: false, default: 'industry',
        enum: ['industry', 'concept', 'region'], description: '板块类型。',
      },
      {
        name: 'sort', location: 'query', type: 'string', required: false, default: 'price',
        enum: ['price'], description: '已验证可用的排序字段。',
      },
      {
        name: 'order', location: 'query', type: 'string', required: false, default: 'desc',
        enum: ['asc', 'desc'], description: '排序方向。',
      },
      {
        name: 'offset', location: 'query', type: 'integer', required: false, default: 0,
        minimum: 0, maximum: 100_000, description: '分页偏移。',
      },
      {
        name: 'limit', location: 'query', type: 'integer', required: false, default: 20,
        minimum: 1, maximum: 100, description: '返回数量。',
      },
    ],
  },
  {
    id: 'tx_stock_news', provider: 'tencent', name: '个股资讯', group: 'news',
    summary: '按证券代码分页查询腾讯个股资讯。',
    features: ['个股资讯'], path: '/appstock/news/info/search',
    parameters: [
      TENCENT_SYMBOL,
      {
        name: 'page', location: 'query', type: 'integer', required: false, default: 1,
        minimum: 1, maximum: 10_000, description: '页码。',
      },
      {
        name: 'limit', location: 'query', type: 'integer', required: false, default: 10,
        minimum: 1, maximum: 100, description: '每页数量。',
      },
    ],
  },
] as const satisfies readonly PublicWebsiteEndpointDescriptor[]

const SINA_A_SYMBOL = {
  name: 'symbol', location: 'query', type: 'string', required: true,
  description: '新浪沪深 A 股代码，例如 sh600519 或 sz000001。',
  pattern: TENCENT_SYMBOL_PATTERN, maxLength: 8,
} as const

const SINA_A_SYMBOL_PATH = {
  ...SINA_A_SYMBOL,
  location: 'path',
} as const

export const SINA_ENDPOINTS = [
  {
    id: 'sina_realtime_quotes', provider: 'sina', name: '批量实时行情', group: 'quote',
    summary: '批量查询沪深 A 股实时行情。',
    features: ['实时行情', '批量行情', '盘口'], path: '/list=',
    parameters: [{
      name: 'symbols', location: 'query', type: 'string', required: true, maxLength: 2_400,
      description: '逗号分隔的新浪沪深 A 股代码，最多 80 个。',
      pattern: `(?:${TENCENT_SYMBOL_PATTERN})(?:,(?:${TENCENT_SYMBOL_PATTERN})){0,79}`,
    }],
  },
  {
    id: 'sina_price_history', provider: 'sina', name: '历史 K 线', group: 'history',
    summary: '查询日、周、月或 5/15/30/60 分钟 K 线。',
    features: ['历史 K 线', '分钟 K 线'], path: '/cn/api/json_v2.php/CN_MarketDataService.getKLineData',
    parameters: [
      SINA_A_SYMBOL,
      {
        name: 'scale', location: 'query', type: 'integer', required: false, default: 240,
        enum: [5, 15, 30, 60, 240, 1200, 7200], description: '分钟、日、周或月周期。',
      },
      {
        name: 'limit', location: 'query', type: 'integer', required: false, default: 320,
        minimum: 1, maximum: 2_000, description: '返回条数。',
      },
    ],
  },
  {
    id: 'sina_intraday_kline', provider: 'sina', name: '分时 K 线', group: 'history',
    summary: '通过新浪分时接口查询 5/15/30/60 分钟 K 线。',
    features: ['分钟 K 线'], path: '/quotes_service/api/json_v2.php/CN_MarketData.getKLineData',
    parameters: [
      SINA_A_SYMBOL,
      {
        name: 'scale', location: 'query', type: 'integer', required: false, default: 5,
        enum: [5, 15, 30, 60], description: '分钟周期。',
      },
      {
        name: 'limit', location: 'query', type: 'integer', required: false, default: 48,
        minimum: 1, maximum: 2_000, description: '返回条数。',
      },
    ],
  },
  {
    id: 'sina_market_snapshot', provider: 'sina', name: '行情列表与板块个股', group: 'ranking',
    summary: '按新浪 node 分页查询市场、行业或概念成分行情。',
    features: ['A 股列表', '行业成分', '概念成分'], path: '/quotes_service/api/json_v2.php/Market_Center.getHQNodeData',
    parameters: [
      {
        name: 'node', location: 'query', type: 'string', required: false, default: 'hs_a',
        pattern: '[A-Za-z0-9_]{1,64}', description: '新浪市场或板块 node，例如 hs_a、cyb、kcb、new_blhy。',
      },
      {
        name: 'page', location: 'query', type: 'integer', required: false, default: 1,
        minimum: 1, maximum: 10_000, description: '页码。',
      },
      {
        name: 'limit', location: 'query', type: 'integer', required: false, default: 40,
        minimum: 1, maximum: 100, description: '每页数量。',
      },
      {
        name: 'sort', location: 'query', type: 'string', required: false, default: 'symbol',
        enum: ['symbol', 'trade', 'pricechange', 'changepercent', 'volume', 'amount', 'per', 'pb', 'mktcap', 'turnoverratio'],
        description: '排序字段。',
      },
      {
        name: 'order', location: 'query', type: 'string', required: false, default: 'asc',
        enum: ['asc', 'desc'], description: '排序方向。',
      },
    ],
  },
  {
    id: 'sina_industry_catalog', provider: 'sina', name: '行业分类目录', group: 'sector',
    summary: '读取新浪行业分类 ID 列表。', features: ['行业目录'],
    path: '/q/view/newSinaHy.php', parameters: [],
  },
  {
    id: 'sina_concept_catalog', provider: 'sina', name: '概念分类目录', group: 'sector',
    summary: '读取新浪概念分类 ID 列表。', features: ['概念目录'],
    path: '/q/view/newFLJK.php?param=class', parameters: [],
  },
  {
    id: 'sina_industry_overview', provider: 'sina', name: '行业总览', group: 'sector',
    summary: '读取新浪行业涨跌总览。', features: ['行业总览'],
    path: '/q/view/newFLJK.php?param=industry', parameters: [],
  },
  {
    id: 'sina_stock_money_flow', provider: 'sina', name: '个股历史资金流', group: 'money_flow',
    summary: '分页查询个股历史资金流。', features: ['个股资金流'],
    path: '/quotes_service/api/json_v2.php/MoneyFlow.ssl_qsfx_zjlrqs',
    parameters: [
      SINA_A_SYMBOL,
      {
        name: 'page', location: 'query', type: 'integer', required: false, default: 1,
        minimum: 1, maximum: 10_000, description: '页码。',
      },
      {
        name: 'limit', location: 'query', type: 'integer', required: false, default: 20,
        minimum: 1, maximum: 100, description: '每页数量。',
      },
    ],
  },
  {
    id: 'sina_sector_money_flow', provider: 'sina', name: '板块资金流', group: 'money_flow',
    summary: '查询行业或概念板块资金流。', features: ['行业资金流', '概念资金流'],
    path: '/quotes_service/api/json_v2.php/MoneyFlow.ssl_bkzj_zjlrqs',
    parameters: [
      {
        name: 'sector_type', location: 'query', type: 'string', required: false, default: 'industry',
        enum: ['industry', 'concept'], description: '行业或概念。',
      },
      {
        name: 'page', location: 'query', type: 'integer', required: false, default: 1,
        minimum: 1, maximum: 10_000, description: '页码。',
      },
      {
        name: 'limit', location: 'query', type: 'integer', required: false, default: 20,
        minimum: 1, maximum: 100, description: '每页数量。',
      },
    ],
  },
  {
    id: 'sina_rolling_news', provider: 'sina', name: '财经滚动新闻', group: 'news',
    summary: '分页查询财经、股票或理财滚动新闻。', features: ['财经新闻', '股票新闻', '理财新闻'],
    path: '/api/roll/get',
    parameters: [
      {
        name: 'channel', location: 'query', type: 'string', required: false, default: 'finance',
        enum: ['finance', 'stocks', 'money'], description: '新闻频道。',
      },
      {
        name: 'page', location: 'query', type: 'integer', required: false, default: 1,
        minimum: 1, maximum: 10_000, description: '页码。',
      },
      {
        name: 'limit', location: 'query', type: 'integer', required: false, default: 20,
        minimum: 1, maximum: 100, description: '每页数量。',
      },
    ],
  },
  {
    id: 'sina_stock_news_page', provider: 'sina', name: '个股新闻页', group: 'html',
    summary: '读取新浪个股新闻 HTML 页面。', features: ['个股新闻 HTML'],
    path: '/corp/go.php/vCB_AllNewsStock/symbol/{symbol}.phtml', parameters: [SINA_A_SYMBOL_PATH],
  },
  {
    id: 'sina_stock_announcements_page', provider: 'sina', name: '个股公告页', group: 'html',
    summary: '读取新浪个股公告 HTML 页面。', features: ['公告 HTML'],
    path: '/corp/go.php/vCB_AllBulletin/symbol/{symbol}.phtml', parameters: [SINA_A_SYMBOL_PATH],
  },
  {
    id: 'sina_dragon_tiger_page', provider: 'sina', name: '龙虎榜页', group: 'html',
    summary: '读取新浪龙虎榜统计 HTML 页面。', features: ['龙虎榜 HTML'],
    path: '/q/go.php/vLHBData/kind/ggtj/index.phtml', parameters: [],
  },
] as const satisfies readonly PublicWebsiteEndpointDescriptor[]

const TONGHUASHUN_SYMBOL = {
  name: 'symbol', location: 'path', type: 'string', required: true,
  description: '同花顺证券标识，例如 hs_600519。',
  pattern: `hs_${A_SHARE_CODE_PATTERN}`, maxLength: 9,
} as const

export const TONGHUASHUN_ENDPOINTS = [
  {
    id: 'ths_price_history', provider: 'tonghuashun', name: '日 K 线', group: 'history',
    summary: '查询最新或指定年月的日 K JSONP 数据。', features: ['日 K 线', '历史归档'],
    path: '/v6/line/{symbol}/01/{archive}.js',
    parameters: [
      TONGHUASHUN_SYMBOL,
      {
        name: 'archive', location: 'path', type: 'string', required: false, default: 'last',
        pattern: 'last|[0-9]{6}', description: 'last 或 yyyyMM 历史归档。',
      },
    ],
  },
  {
    id: 'ths_intraday_trends', provider: 'tonghuashun', name: '分时走势', group: 'history',
    summary: '查询当日分时 JSONP 数据。', features: ['当日分时'],
    path: '/v6/time/{symbol}/last.js', parameters: [TONGHUASHUN_SYMBOL],
  },
] as const satisfies readonly PublicWebsiteEndpointDescriptor[]

export type DocumentedPublicEndpoint =
  | typeof DOCUMENTED_EASTMONEY_ENDPOINTS[number]
  | typeof TENCENT_ENDPOINTS[number]
  | typeof SINA_ENDPOINTS[number]
  | typeof TONGHUASHUN_ENDPOINTS[number]

export const DOCUMENTED_PUBLIC_ENDPOINTS = [
  ...DOCUMENTED_EASTMONEY_ENDPOINTS,
  ...TENCENT_ENDPOINTS,
  ...SINA_ENDPOINTS,
  ...TONGHUASHUN_ENDPOINTS,
] as const

const documentedByProvider = new Map<string, DocumentedPublicEndpoint>(
  DOCUMENTED_PUBLIC_ENDPOINTS.map(endpoint => [`${endpoint.provider}:${endpoint.id}`, endpoint]),
)

export function findDocumentedPublicEndpoint(
  provider: 'eastmoney' | PublicWebsiteProvider,
  endpointId: string,
): DocumentedPublicEndpoint | undefined {
  return documentedByProvider.get(`${provider}:${endpointId}`)
}

export { EASTMONEY_UT }
