import { EASTMONEY_ENDPOINTS as GENERATED_EASTMONEY_ENDPOINTS } from './catalog.generated.ts'
import {
  DOCUMENTED_EASTMONEY_ENDPOINTS,
  DOCUMENTED_PUBLIC_ENDPOINTS,
  SINA_ENDPOINTS,
  TENCENT_ENDPOINTS,
  TONGHUASHUN_ENDPOINTS,
  findDocumentedPublicEndpoint,
  type DocumentedPublicEndpoint,
} from './researched-catalog.ts'
import type {
  EastMoneyEndpointDescriptor,
  PublicWebsiteEndpointDescriptor,
  StockDataProvider,
} from './types.ts'

export const EASTMONEY_ENDPOINTS = [
  ...GENERATED_EASTMONEY_ENDPOINTS,
  ...DOCUMENTED_EASTMONEY_ENDPOINTS,
] as const satisfies readonly EastMoneyEndpointDescriptor[]

export {
  DOCUMENTED_EASTMONEY_ENDPOINTS,
  DOCUMENTED_PUBLIC_ENDPOINTS,
  SINA_ENDPOINTS,
  TENCENT_ENDPOINTS,
  TONGHUASHUN_ENDPOINTS,
  findDocumentedPublicEndpoint,
}
export type {
  DocumentedPublicEndpoint,
  EastMoneyEndpointDescriptor,
  PublicWebsiteEndpointDescriptor,
}

const eastMoneyById: ReadonlyMap<string, EastMoneyEndpointDescriptor> = new Map(
  EASTMONEY_ENDPOINTS.map(endpoint => [endpoint.id, endpoint]),
)
const tencentById: ReadonlyMap<string, PublicWebsiteEndpointDescriptor> = new Map(
  TENCENT_ENDPOINTS.map(endpoint => [endpoint.id, endpoint]),
)
const sinaById: ReadonlyMap<string, PublicWebsiteEndpointDescriptor> = new Map(
  SINA_ENDPOINTS.map(endpoint => [endpoint.id, endpoint]),
)
const tonghuashunById: ReadonlyMap<string, PublicWebsiteEndpointDescriptor> = new Map(
  TONGHUASHUN_ENDPOINTS.map(endpoint => [endpoint.id, endpoint]),
)

export function findEastMoneyEndpoint(endpointId: string): EastMoneyEndpointDescriptor | undefined {
  return eastMoneyById.get(endpointId)
}

export function findTencentEndpoint(endpointId: string): PublicWebsiteEndpointDescriptor | undefined {
  return tencentById.get(endpointId)
}

export function findSinaEndpoint(endpointId: string): PublicWebsiteEndpointDescriptor | undefined {
  return sinaById.get(endpointId)
}

export function findTonghuashunEndpoint(endpointId: string): PublicWebsiteEndpointDescriptor | undefined {
  return tonghuashunById.get(endpointId)
}

export function providerEndpointCount(provider: StockDataProvider): number {
  switch (provider) {
    case 'eastmoney': return EASTMONEY_ENDPOINTS.length
    case 'tencent': return TENCENT_ENDPOINTS.length
    case 'sina': return SINA_ENDPOINTS.length
    case 'tonghuashun': return TONGHUASHUN_ENDPOINTS.length
  }
}
