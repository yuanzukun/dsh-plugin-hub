export interface StockMarketSideCardState {
  panelOpen: boolean
  width: number
}

export interface StockMarketSideCardSnapshot {
  sessionId: string | undefined
  state: StockMarketSideCardState | undefined
}

export interface StockMarketSideCardStore {
  getSnapshot(): StockMarketSideCardSnapshot
  subscribe(listener: () => void): () => void
  setSession(sessionId: string | undefined): void
  reduce(
    update: (state: StockMarketSideCardState) => StockMarketSideCardState,
    options?: { persist?: boolean },
  ): void
  persist(): void
}

export const STOCK_MARKET_SIDECARD_WIDTH_MIN = 300
export const STOCK_MARKET_SIDECARD_WIDTH_MAX = 640
export const STOCK_MARKET_SIDECARD_WIDTH_DEFAULT = STOCK_MARKET_SIDECARD_WIDTH_MAX

/** Keep the host composer usable whenever the viewport is wide enough for both panes. */
export const STOCK_MARKET_SIDECARD_SESSION_MIN_WIDTH = 480
export const STOCK_MARKET_SIDECARD_OVERLAY_MAX_VIEWPORT_WIDTH =
  STOCK_MARKET_SIDECARD_WIDTH_MIN + STOCK_MARKET_SIDECARD_SESSION_MIN_WIDTH

const STORAGE_PREFIX = 'dsh-stock-market:side-card:v2:'

export function createStockMarketSideCardStore(
  getDefaultPanelOpen: () => boolean = () => true,
): StockMarketSideCardStore {
  let snapshot: StockMarketSideCardSnapshot = { sessionId: undefined, state: undefined }
  const listeners = new Set<() => void>()

  const defaultState = (): StockMarketSideCardState => ({
    panelOpen: getDefaultPanelOpen(),
    width: STOCK_MARKET_SIDECARD_WIDTH_DEFAULT,
  })

  const publish = (): void => {
    for (const listener of [...listeners]) listener()
  }

  return {
    getSnapshot: () => snapshot,
    subscribe(listener) {
      listeners.add(listener)
      return () => { listeners.delete(listener) }
    },
    setSession(sessionId) {
      if (snapshot.sessionId === sessionId) return
      snapshot = {
        sessionId,
        state: sessionId === undefined ? undefined : readState(sessionId, defaultState()),
      }
      publish()
    },
    reduce(update, options) {
      if (snapshot.sessionId === undefined || snapshot.state === undefined) return
      const sessionId = snapshot.sessionId
      const state = normalizeState(update(snapshot.state), defaultState())
      snapshot = { ...snapshot, state }
      if (options?.persist !== false) writeState(sessionId, state)
      publish()
    },
    persist() {
      if (snapshot.sessionId === undefined || snapshot.state === undefined) return
      writeState(snapshot.sessionId, snapshot.state)
    },
  }
}

function readState(sessionId: string, fallback: StockMarketSideCardState): StockMarketSideCardState {
  try {
    const raw = window.localStorage.getItem(storageKey(sessionId))
    if (raw === null) return { ...fallback }
    return normalizeState(JSON.parse(raw), fallback)
  } catch {
    return { ...fallback }
  }
}

function writeState(sessionId: string, state: StockMarketSideCardState): void {
  try {
    window.localStorage.setItem(storageKey(sessionId), JSON.stringify(state))
  } catch {
    // Persistence is an enhancement. The card remains usable when storage is unavailable.
  }
}

function storageKey(sessionId: string): string {
  return `${STORAGE_PREFIX}${sessionId}`
}

function normalizeState(value: unknown, fallback: StockMarketSideCardState): StockMarketSideCardState {
  if (value === null || typeof value !== 'object') return { ...fallback }
  const candidate = value as Partial<StockMarketSideCardState>
  return {
    panelOpen: typeof candidate.panelOpen === 'boolean' ? candidate.panelOpen : fallback.panelOpen,
    width: clampWidth(candidate.width),
  }
}

function clampWidth(value: unknown): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) return STOCK_MARKET_SIDECARD_WIDTH_DEFAULT
  return Math.min(STOCK_MARKET_SIDECARD_WIDTH_MAX, Math.max(STOCK_MARKET_SIDECARD_WIDTH_MIN, Math.round(value)))
}
