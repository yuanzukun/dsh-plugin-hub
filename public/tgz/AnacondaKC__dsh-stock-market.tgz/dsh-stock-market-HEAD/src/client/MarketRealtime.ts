import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import {
  STOCK_MARKET_BREADTH_ENDPOINT,
  STOCK_MARKET_HOTSPOTS_ENDPOINT,
  STOCK_MARKET_MOVERS_ENDPOINT,
  STOCK_MARKET_RPC_CHANNEL,
  STOCK_MARKET_RPC_PROTOCOL_VERSION,
  STOCK_MARKET_TRENDS_ENDPOINT,
  isStockMarketBreadthResponse,
  isStockMarketHotspotsResponse,
  isStockMarketMoversResponse,
  isStockMarketTrendsResponse,
  type StockMarketBreadthResponse,
  type StockMarketHotspotsResponse,
  type StockMarketMoversResponse,
  type StockMarketTrendsResponse,
} from '../rpc-contract.ts'

export function loadMarketBreadth(
  connection: ConnectionHandle,
  signal?: AbortSignal,
): Promise<StockMarketBreadthResponse> {
  return loadRealtimeResource(
    connection,
    STOCK_MARKET_BREADTH_ENDPOINT,
    isStockMarketBreadthResponse,
    '后端返回了不兼容的涨跌家数数据。',
    signal,
  )
}

export function loadMarketTrends(
  connection: ConnectionHandle,
  signal?: AbortSignal,
): Promise<StockMarketTrendsResponse> {
  return loadRealtimeResource(
    connection,
    STOCK_MARKET_TRENDS_ENDPOINT,
    isStockMarketTrendsResponse,
    '后端返回了不兼容的分时数据。',
    signal,
  )
}

export function loadMarketMovers(
  connection: ConnectionHandle,
  signal?: AbortSignal,
): Promise<StockMarketMoversResponse> {
  return loadRealtimeResource(
    connection,
    STOCK_MARKET_MOVERS_ENDPOINT,
    isStockMarketMoversResponse,
    '后端返回了不兼容的个股排行数据。',
    signal,
  )
}

export function loadMarketHotspots(
  connection: ConnectionHandle,
  signal?: AbortSignal,
): Promise<StockMarketHotspotsResponse> {
  return loadRealtimeResource(
    connection,
    STOCK_MARKET_HOTSPOTS_ENDPOINT,
    isStockMarketHotspotsResponse,
    '后端返回了不兼容的板块热点数据。',
    signal,
  )
}

async function loadRealtimeResource<T>(
  connection: ConnectionHandle,
  endpoint: string,
  validate: (value: unknown) => value is T,
  incompatibleMessage: string,
  signal?: AbortSignal,
): Promise<T> {
  const result = await connection.rpc.call(
    STOCK_MARKET_RPC_CHANNEL,
    endpoint,
    { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
    signal,
  )
  if (!result.ok) throw new Error(result.error.message)
  if (!validate(result.value)) throw new Error(incompatibleMessage)
  return result.value
}
