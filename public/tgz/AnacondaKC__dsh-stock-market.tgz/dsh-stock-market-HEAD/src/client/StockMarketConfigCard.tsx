import { useEffect, useRef, useState } from 'react'
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { StockMarketPluginConfig } from '../rpc-contract.ts'
import { loadStockMarketConfig, saveStockMarketConfig } from './plugin-config.ts'
import css from './StockMarketConfigCard.module.css'

export interface StockMarketConfigCardInjected {
  connection: ConnectionHandle
  onConfigApplied(config: StockMarketPluginConfig): void
}

export type StockMarketConfigCardProps =
  PropsRuntime<'settings.plugin.item'> & InjectFace<StockMarketConfigCardInjected>

/**
 * Plugin config card shown in the DSH "Plugin config" settings section.
 * Three switches: plugin master switch, default sidebar expansion, and the
 * default stock-tool state for new sessions.
 */
export function StockMarketConfigCard({ connection, onConfigApplied }: StockMarketConfigCardInjected) {
  const [config, setConfig] = useState<StockMarketPluginConfig>()
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string>()
  const [savedAt, setSavedAt] = useState<string>()
  const loadControllerRef = useRef<AbortController>()
  const saveControllerRef = useRef<AbortController>()

  useEffect(() => {
    const controller = new AbortController()
    loadControllerRef.current = controller
    void loadStockMarketConfig(connection, controller.signal)
      .then(setConfig)
      .catch(() => setError('配置加载失败。'))
    return () => controller.abort()
  }, [connection])

  if (config === undefined) {
    return <p className={css.status}>{error ?? '加载配置中…'}</p>
  }

  const update = (patch: Partial<StockMarketPluginConfig>): void => {
    setConfig(current => (current === undefined ? current : { ...current, ...patch }))
    setError(undefined)
  }

  const save = async (): Promise<void> => {
    if (config === undefined) return
    setSaving(true)
    setError(undefined)
    const controller = new AbortController()
    saveControllerRef.current = controller
    try {
      await saveStockMarketConfig(connection, config, controller.signal)
      onConfigApplied(config)
      setSavedAt(new Date().toLocaleTimeString())
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : '配置保存失败。')
    } finally {
      setSaving(false)
    }
  }

  return (
    <section className={css.root} aria-label="dsh-stock-market 插件配置">
      <h4 className={css.title}>dsh-stock-market</h4>
      {config.enabled === false && <p className={css.disabled}>插件已关闭:行情侧栏、股票工具与设置入口均已隐藏。重新打开并保存后,重启 dsh 完全恢复。</p>}
      <p className={css.hint}>
        控制行情侧栏与股票工具的默认行为;侧边栏与工具开关对新建会话立即生效,插件总开关在重启后完全生效。
      </p>

      <label className={css.row}>
        <span>
          <span className={css.label}>插件总开关</span>
          <span className={css.caption}>关闭后侧栏、工具与设置入口全部隐藏</span>
        </span>
        <input
          type="checkbox"
          role="switch"
          checked={config.enabled}
          onChange={(event) => update({ enabled: event.currentTarget.checked })}
        />
      </label>

      <label className={css.row}>
        <span>
          <span className={css.label}>侧边栏默认展开</span>
          <span className={css.caption}>新会话打开时行情侧栏是否展开</span>
        </span>
        <input
          type="checkbox"
          role="switch"
          checked={config.sidebarOpenByDefault}
          onChange={(event) => update({ sidebarOpenByDefault: event.currentTarget.checked })}
        />
      </label>

      <label className={css.row}>
        <span>
          <span className={css.label}>股票工具默认开启</span>
          <span className={css.caption}>新会话的股票工具开关初始状态</span>
        </span>
        <input
          type="checkbox"
          role="switch"
          checked={config.toolsEnabledByDefault}
          onChange={(event) => update({ toolsEnabledByDefault: event.currentTarget.checked })}
        />
      </label>

      <div className={css.footer}>
        <button type="button" className={css.save} disabled={saving} onClick={() => void save()}>
          {saving ? '保存中…' : '保存配置'}
        </button>
        {savedAt !== undefined && <span className={css.saved}>已保存 {savedAt}</span>}
        {error !== undefined && <span className={css.error}>{error}</span>}
      </div>
    </section>
  )
}
