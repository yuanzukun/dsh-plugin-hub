import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import {
  STOCK_MARKET_RPC_CHANNEL,
  STOCK_MARKET_RPC_PROTOCOL_VERSION,
  STOCK_MARKET_SET_TOOL_ACCESS_ENDPOINT,
  STOCK_MARKET_TOOL_ACCESS_ENDPOINT,
  isStockMarketToolAccessResponse,
} from '../rpc-contract.ts'

export async function loadStockToolAccess(
  connection: ConnectionHandle,
  sessionId: string,
  signal?: AbortSignal,
): Promise<boolean> {
  return callStockToolAccess(connection, STOCK_MARKET_TOOL_ACCESS_ENDPOINT, {
    protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
    sessionId,
  }, signal)
}

export async function setStockToolAccess(
  connection: ConnectionHandle,
  sessionId: string,
  enabled: boolean,
  signal?: AbortSignal,
): Promise<boolean> {
  return callStockToolAccess(connection, STOCK_MARKET_SET_TOOL_ACCESS_ENDPOINT, {
    protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
    sessionId,
    enabled,
  }, signal)
}

async function callStockToolAccess(
  connection: ConnectionHandle,
  endpoint: string,
  payload: unknown,
  signal?: AbortSignal,
): Promise<boolean> {
  const result = await connection.rpc.call(
    STOCK_MARKET_RPC_CHANNEL,
    endpoint,
    payload,
    signal,
  )
  if (!result.ok) throw new Error(result.error.message)
  if (!isStockMarketToolAccessResponse(result.value)) {
    throw new Error('后端返回了不兼容的股票工具状态。')
  }
  return result.value.enabled
}
