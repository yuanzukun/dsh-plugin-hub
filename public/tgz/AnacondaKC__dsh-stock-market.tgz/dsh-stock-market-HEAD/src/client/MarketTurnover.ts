import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import {
  STOCK_MARKET_RPC_CHANNEL,
  STOCK_MARKET_RPC_PROTOCOL_VERSION,
  STOCK_MARKET_TURNOVER_ENDPOINT,
  isStockMarketTurnoverResponse,
  type StockMarketTurnoverResponse,
} from '../rpc-contract.ts'

/** Fetch the server-bounded two-market turnover summary for the market overview. */
export async function loadMarketTurnover(
  connection: ConnectionHandle,
  signal?: AbortSignal,
): Promise<StockMarketTurnoverResponse> {
  const result = await connection.rpc.call(
    STOCK_MARKET_RPC_CHANNEL,
    STOCK_MARKET_TURNOVER_ENDPOINT,
    { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
    signal,
  )
  if (!result.ok) throw new Error(result.error.message)
  if (!isStockMarketTurnoverResponse(result.value)) {
    throw new Error('后端返回了不兼容的成交数据。')
  }
  return result.value
}
