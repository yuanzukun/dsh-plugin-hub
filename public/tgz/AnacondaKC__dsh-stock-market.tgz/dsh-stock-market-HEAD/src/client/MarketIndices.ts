import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import {
  STOCK_MARKET_INDICES_ENDPOINT,
  STOCK_MARKET_RPC_CHANNEL,
  STOCK_MARKET_RPC_PROTOCOL_VERSION,
  isStockMarketIndicesResponse,
  type StockMarketIndicesResponse,
} from '../rpc-contract.ts'

/** Fetch and validate the one market snapshot shared by the collapsed ticker and the overview. */
export async function loadMarketIndices(
  connection: ConnectionHandle,
  signal?: AbortSignal,
): Promise<StockMarketIndicesResponse> {
  const result = await connection.rpc.call(
    STOCK_MARKET_RPC_CHANNEL,
    STOCK_MARKET_INDICES_ENDPOINT,
    { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
    signal,
  )
  if (!result.ok) throw new Error(result.error.message)
  if (!isStockMarketIndicesResponse(result.value)) {
    throw new Error('后端返回了不兼容的行情数据。')
  }
  return result.value
}
