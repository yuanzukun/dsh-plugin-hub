export interface InvestorQuote {
  author: string
  quote: string
}

/** 31 条精选投资哲言，随机展示于行情面板末尾。 */
export const INVESTOR_QUOTES: ReadonlyArray<InvestorQuote> = [
  { author: '沃伦·巴菲特', quote: '在别人贪婪时恐惧，在别人恐惧时贪婪。' },
  { author: '沃伦·巴菲特', quote: '只有退潮时，才知道谁在裸泳。' },
  { author: '沃伦·巴菲特', quote: '投资企业，而不是股票。' },
  { author: '沃伦·巴菲特', quote: '我喜欢简单的事物。' },
  { author: '乔治·索罗斯', quote: '判断对错不重要，关键在于正确时赚了多少、错误时亏了多少。' },
  { author: '乔治·索罗斯', quote: '承担风险无可指责，但千万不能孤注一掷。' },
  { author: '乔治·索罗斯', quote: '身在市场，你就得准备忍受痛苦。' },
  { author: '安德烈·科斯托兰尼', quote: '投机是一门艺术，而不是科学。' },
  { author: '安德烈·科斯托兰尼', quote: '货币之于股市，就像氧气之于呼吸。' },
  { author: '安德烈·科斯托兰尼', quote: '股票永远不会太高而不能买，也不会太低而不能卖。' },
  { author: '威廉·江恩', quote: '阳光之下，没有新东西。' },
  { author: '威廉·江恩', quote: '趋势不明时，宁可在场外观望。' },
  { author: '威廉·江恩', quote: '遭受损失时，切忌赌徒式加码摊低成本。' },
  { author: '吉姆·罗杰斯', quote: '决不赔钱，做自己熟悉的事。' },
  { author: '吉姆·罗杰斯', quote: '当所有人都疯狂时，你必须保持冷静。' },
  { author: '吉姆·罗杰斯', quote: '风险存在于市场本身。' },
  { author: '菲利普·费雪', quote: '抱牢成长股。' },
  { author: '菲利普·费雪', quote: '不要随群众起舞。' },
  { author: '菲利普·费雪', quote: '现金流是公司的重要健康指标。' },
  { author: '彼得·林奇', quote: '让趋势成为你的朋友。' },
  { author: '彼得·林奇', quote: '不做研究的投资，就像打扑克不看牌。' },
  { author: '彼得·林奇', quote: '行情总在绝望中诞生，在半信半疑中成长，在希望中毁灭。' },
  { author: '罗伊·纽伯格', quote: '别人的鞋子不合自己的脚。' },
  { author: '罗伊·纽伯格', quote: '技术指标千变万化，成交量才是实打实的买卖。' },
  { author: '罗伊·纽伯格', quote: '时机可以决定许多事情。' },
  { author: '伯纳德·巴鲁克', quote: '我能躲过灾难，是因为每次都抛得过早。' },
  { author: '伯纳德·巴鲁克', quote: '谁要是说自己总能抄底逃顶，那准是在撒谎。' },
  { author: '伯纳德·巴鲁克', quote: '新高孕育新高，新低孕育新低。' },
  { author: '是川银藏', quote: '买卖只吃八分饱。' },
  { author: '是川银藏', quote: '在我进入之前，我就知道该何时退出了。' },
  { author: '是川银藏', quote: '投资股票永远有风险。' },
]

export function pickInvestorQuote(random: () => number = Math.random): InvestorQuote {
  const selected = INVESTOR_QUOTES[Math.floor(random() * INVESTOR_QUOTES.length)]
  return selected ?? INVESTOR_QUOTES[0]!
}
