import { useEffect, useRef, useState, type ReactNode } from 'react'
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import { MarketHeading } from './MarketHeading.tsx'
import {
  STOCK_MARKET_FLASH_NEWS_ENDPOINT,
  STOCK_MARKET_GLOBAL_QUOTES_ENDPOINT,
  STOCK_MARKET_HEADLINES_ENDPOINT,
  STOCK_MARKET_HOTSPOT_GROUPS,
  STOCK_MARKET_INDICES,
  STOCK_MARKET_RANKINGS,
  STOCK_MARKET_RPC_CHANNEL,
  STOCK_MARKET_RPC_PROTOCOL_VERSION,
  isStockMarketGlobalQuotesResponse,
  type StockMarketBreadth,
  type StockMarketBreadthResponse,
  type StockMarketGlobalQuotesResponse,
  type StockMarketHotspotQuote,
  type StockMarketHotspotsResponse,
  type StockMarketIndexQuote,
  type StockMarketIndexTrend,
  type StockMarketIndicesResponse,
  type StockMarketMoverQuote,
  type StockMarketMoversResponse,
  type StockMarketNewsItem,
  type StockMarketNewsResponse,
  type StockMarketRankingId,
  type StockMarketTradingStatus,
  type StockMarketTrendsResponse,
  type StockMarketTurnoverResponse,
} from '../rpc-contract.ts'
import { loadMarketIndices } from './MarketIndices.ts'
import { loadMarketNews } from './MarketNews.ts'
import {
  loadMarketBreadth,
  loadMarketHotspots,
  loadMarketMovers,
  loadMarketTrends,
} from './MarketRealtime.ts'
import { loadMarketTurnover } from './MarketTurnover.ts'
import { pickInvestorQuote } from './investor-quotes.ts'
import css from './StockMarketView.module.css'

export interface StockMarketViewProps {
  connection: ConnectionHandle
  visible?: boolean
  onBreadthChange: (breadth: StockMarketBreadth | undefined) => void
}

type RequestState<T> =
  | { kind: 'loading' }
  | { kind: 'ready'; snapshot: T }
  | { kind: 'error'; message: string }

type OverviewState = RequestState<StockMarketIndicesResponse>
type GlobalQuotesState = RequestState<StockMarketGlobalQuotesResponse>
type TurnoverState = RequestState<StockMarketTurnoverResponse>
type BreadthState = RequestState<StockMarketBreadthResponse>
type TrendsState = RequestState<StockMarketTrendsResponse>
type MoversState = RequestState<StockMarketMoversResponse>
type HotspotsState = RequestState<StockMarketHotspotsResponse>
type NewsState = RequestState<StockMarketNewsResponse>
type MarketIndex = typeof STOCK_MARKET_INDICES[number]
export type MarketResource =
  | 'indices'
  | 'turnover'
  | 'breadth'
  | 'trends'
  | 'movers'
  | 'hotspots'
  | 'headlines'
  | 'flashNews'
type ResourceRevisions = Record<MarketResource, number>

type MarketLoader<T> = (connection: ConnectionHandle, signal: AbortSignal) => Promise<T>

const INITIAL_RESOURCE_REVISIONS: ResourceRevisions = {
  indices: 0,
  turnover: 0,
  breadth: 0,
  trends: 0,
  movers: 0,
  hotspots: 0,
  headlines: 0,
  flashNews: 0,
}
const INDICES_POLL_INTERVAL_MS = 5_000
const GLOBAL_QUOTES_POLL_INTERVAL_MS = 10_000
const TURNOVER_POLL_INTERVAL_MS = 10_000
const LIVE_MARKET_POLL_INTERVAL_MS = 30_000
const NEWS_POLL_INTERVAL_MS = 60_000
const HOTSPOTS_POLL_INTERVAL_MS = 60_000
const IDLE_INDICES_POLL_INTERVAL_MS = 60_000
const MAX_POLL_BACKOFF_MS = 5 * 60_000
const MORNING_OPEN_MINUTE = 9 * 60 + 30
const MORNING_CLOSE_MINUTE = 11 * 60 + 30
const AFTERNOON_OPEN_MINUTE = 13 * 60
const AFTERNOON_CLOSE_MINUTE = 15 * 60
const MARKET_SESSION_MINUTES = 4 * 60
const loadHeadlines: MarketLoader<StockMarketNewsResponse> = (connection, signal) => (
  loadMarketNews(connection, STOCK_MARKET_HEADLINES_ENDPOINT, signal)
)
const loadFlashNews: MarketLoader<StockMarketNewsResponse> = (connection, signal) => (
  loadMarketNews(connection, STOCK_MARKET_FLASH_NEWS_ENDPOINT, signal)
)
const loadGlobalQuotes: MarketLoader<StockMarketGlobalQuotesResponse> = async (connection, signal) => {
  const result = await connection.rpc.call(
    STOCK_MARKET_RPC_CHANNEL,
    STOCK_MARKET_GLOBAL_QUOTES_ENDPOINT,
    { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
    signal,
  )
  if (!result.ok) throw new Error(result.error.message)
  if (!isStockMarketGlobalQuotesResponse(result.value)) {
    throw new Error('后端返回了不兼容的全球行情数据。')
  }
  return result.value
}
const indexPollingPolicy = (snapshot: StockMarketIndicesResponse | undefined): number => (
  marketPollingInterval('indices', snapshot?.marketStatus) ?? IDLE_INDICES_POLL_INTERVAL_MS
)

export function marketPollingInterval(
  resource: MarketResource,
  status: StockMarketTradingStatus | undefined,
): number | undefined {
  if (resource === 'headlines' || resource === 'flashNews') return NEWS_POLL_INTERVAL_MS
  if (resource === 'indices') {
    return status === undefined || status === 'auction' || status === 'trading'
      ? INDICES_POLL_INTERVAL_MS
      : IDLE_INDICES_POLL_INTERVAL_MS
  }
  if (status !== undefined && status !== 'trading') return undefined
  switch (resource) {
    case 'turnover': return TURNOVER_POLL_INTERVAL_MS
    case 'hotspots': return HOTSPOTS_POLL_INTERVAL_MS
    case 'breadth':
    case 'trends':
    case 'movers': return LIVE_MARKET_POLL_INTERVAL_MS
  }
}

export function marketTrendTimeRatio(time: string): number | undefined {
  const match = /(?:^|\s)(\d{1,2}):(\d{2})(?::\d{2})?(?:\s|$)/u.exec(time.trim())
  if (match === null) return undefined
  const hours = Number(match[1])
  const minutes = Number(match[2])
  if (!Number.isInteger(hours) || !Number.isInteger(minutes) || hours > 23 || minutes > 59) return undefined

  const minuteOfDay = hours * 60 + minutes
  if (minuteOfDay >= MORNING_OPEN_MINUTE && minuteOfDay <= MORNING_CLOSE_MINUTE) {
    return (minuteOfDay - MORNING_OPEN_MINUTE) / MARKET_SESSION_MINUTES
  }
  if (minuteOfDay >= AFTERNOON_OPEN_MINUTE && minuteOfDay <= AFTERNOON_CLOSE_MINUTE) {
    const elapsed = MORNING_CLOSE_MINUTE - MORNING_OPEN_MINUTE + minuteOfDay - AFTERNOON_OPEN_MINUTE
    return elapsed / MARKET_SESSION_MINUTES
  }
  return undefined
}

export function marketPollingDelay(baseIntervalMs: number, consecutiveFailures: number): number {
  return Math.min(baseIntervalMs * (2 ** consecutiveFailures), MAX_POLL_BACKOFF_MS)
}

const PRICE_FORMATTER = new Intl.NumberFormat('zh-CN', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})
const CHANGE_FORMATTER = new Intl.NumberFormat('zh-CN', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})
const FLOW_FORMATTER = new Intl.NumberFormat('zh-CN', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})
const AMOUNT_FORMATTER = new Intl.NumberFormat('zh-CN', {
  maximumFractionDigits: 0,
})

/**
 * Credential-free live resources stay in the overview.
 */
export function StockMarketView({
  connection,
  visible = true,
  onBreadthChange,
}: StockMarketViewProps) {
  const [revisions, setRevisions] = useState<ResourceRevisions>(INITIAL_RESOURCE_REVISIONS)
  const marketVisible = visible

  const overview = useMarketRequest(
    connection,
    marketVisible,
    revisions.indices,
    indexPollingPolicy,
    loadMarketIndices,
  )
  const globalQuotes = useMarketRequest(
    connection,
    marketVisible,
    0,
    GLOBAL_QUOTES_POLL_INTERVAL_MS,
    loadGlobalQuotes,
  )
  const marketStatus = overview.kind === 'ready' ? overview.snapshot.marketStatus : undefined
  const turnover = useMarketRequest(
    connection,
    marketVisible,
    revisions.turnover,
    marketPollingInterval('turnover', marketStatus),
    loadMarketTurnover,
  )
  const breadth = useMarketRequest(
    connection,
    marketVisible,
    revisions.breadth,
    marketPollingInterval('breadth', marketStatus),
    loadMarketBreadth,
  )
  const trends = useMarketRequest(
    connection,
    marketVisible,
    revisions.trends,
    marketPollingInterval('trends', marketStatus),
    loadMarketTrends,
  )
  const movers = useMarketRequest(
    connection,
    marketVisible,
    revisions.movers,
    marketPollingInterval('movers', marketStatus),
    loadMarketMovers,
  )
  const hotspots = useMarketRequest(
    connection,
    marketVisible,
    revisions.hotspots,
    marketPollingInterval('hotspots', marketStatus),
    loadMarketHotspots,
  )
  const headlines = useMarketRequest(
    connection,
    marketVisible,
    revisions.headlines,
    marketPollingInterval('headlines', marketStatus),
    loadHeadlines,
  )
  const flashNews = useMarketRequest(
    connection,
    marketVisible,
    revisions.flashNews,
    marketPollingInterval('flashNews', marketStatus),
    loadFlashNews,
  )

  useEffect(() => {
    onBreadthChange(breadth.kind === 'ready' ? breadth.snapshot.breadth : undefined)
  }, [breadth, onBreadthChange])

  useEffect(() => () => { onBreadthChange(undefined) }, [onBreadthChange])

  const refresh = (resource: MarketResource): void => {
    setRevisions(current => ({ ...current, [resource]: current[resource] + 1 }))
  }

  return (
    <main className={css.root} aria-label="A 股行情">
      <MarketHeading state={globalQuotes} />
      <div className={css.content}>
        <MarketOverview
          indexState={overview}
          turnoverState={turnover}
          breadthState={breadth}
          trendsState={trends}
          moversState={movers}
          hotspotsState={hotspots}
          headlinesState={headlines}
          flashNewsState={flashNews}
          onRefresh={refresh}
        />
      </div>
    </main>
  )
}

type PollingPolicy<T> = number | undefined | ((snapshot: T | undefined) => number | undefined)

type MarketRequestRuntime = {
  policyChanged(): void
}

function useMarketRequest<T>(
  connection: ConnectionHandle,
  enabled: boolean,
  revision: number,
  pollingPolicy: PollingPolicy<T>,
  loader: MarketLoader<T>,
): RequestState<T> {
  const [state, setState] = useState<RequestState<T>>({ kind: 'loading' })
  const stateRef = useRef<RequestState<T>>(state)
  const policyRef = useRef<PollingPolicy<T>>(pollingPolicy)
  const runtimeRef = useRef<MarketRequestRuntime>()
  policyRef.current = pollingPolicy

  useEffect(() => {
    if (!enabled) {
      runtimeRef.current = undefined
      return
    }

    let active = true
    let controller: AbortController | undefined
    let timer: ReturnType<typeof setTimeout> | undefined
    let lastStartedAt = 0
    let consecutiveFailures = 0

    const commit = (next: RequestState<T>): void => {
      stateRef.current = next
      setState(next)
    }
    const clearTimer = (): void => {
      if (timer === undefined) return
      clearTimeout(timer)
      timer = undefined
    }
    const currentInterval = (): number | undefined => {
      const policy = policyRef.current
      const snapshot = stateRef.current.kind === 'ready' ? stateRef.current.snapshot : undefined
      return typeof policy === 'function' ? policy(snapshot) : policy
    }
    const effectiveDelay = (): number | undefined => {
      const interval = currentInterval()
      if (interval === undefined) return undefined
      return marketPollingDelay(interval, consecutiveFailures)
    }
    function schedule(): void {
      clearTimer()
      if (!active || controller !== undefined || document.visibilityState === 'hidden') return
      const delay = effectiveDelay()
      if (delay === undefined) return
      timer = setTimeout(() => {
        timer = undefined
        run(false)
      }, Math.max(0, delay - (Date.now() - lastStartedAt)))
    }
    function run(showLoading: boolean): void {
      if (!active || controller !== undefined) return
      const requestController = new AbortController()
      controller = requestController
      lastStartedAt = Date.now()
      if (showLoading) commit({ kind: 'loading' })

      void loader(connection, requestController.signal).then((snapshot) => {
        if (!active || requestController.signal.aborted) return
        consecutiveFailures = 0
        commit({ kind: 'ready', snapshot })
      }).catch((error: unknown) => {
        if (!active || requestController.signal.aborted) return
        consecutiveFailures++
        if (showLoading || stateRef.current.kind !== 'ready') {
          commit({ kind: 'error', message: messageOf(error) })
        }
      }).finally(() => {
        if (!active || controller !== requestController) return
        controller = undefined
        schedule()
      })
    }
    const policyChanged = (): void => {
      clearTimer()
      if (!active || controller !== undefined || document.visibilityState === 'hidden') return
      const delay = effectiveDelay()
      if (delay === undefined) return
      if (lastStartedAt === 0 || Date.now() - lastStartedAt >= delay) {
        run(stateRef.current.kind !== 'ready')
      } else {
        schedule()
      }
    }
    const onVisibilityChange = (): void => {
      if (document.visibilityState === 'hidden') {
        clearTimer()
        const activeController = controller
        controller = undefined
        activeController?.abort()
        return
      }
      policyChanged()
    }

    const runtime = { policyChanged }
    runtimeRef.current = runtime
    document.addEventListener('visibilitychange', onVisibilityChange)
    if (document.visibilityState !== 'hidden') run(stateRef.current.kind !== 'ready')

    return () => {
      active = false
      if (runtimeRef.current === runtime) runtimeRef.current = undefined
      clearTimer()
      controller?.abort()
      document.removeEventListener('visibilitychange', onVisibilityChange)
    }
  }, [connection, enabled, loader, revision])

  useEffect(() => {
    runtimeRef.current?.policyChanged()
  }, [enabled, pollingPolicy])

  return state
}

function MarketOverview({
  indexState,
  turnoverState,
  breadthState,
  trendsState,
  moversState,
  hotspotsState,
  headlinesState,
  flashNewsState,
  onRefresh,
}: {
  indexState: OverviewState
  turnoverState: TurnoverState
  breadthState: BreadthState
  trendsState: TrendsState
  moversState: MoversState
  hotspotsState: HotspotsState
  headlinesState: NewsState
  flashNewsState: NewsState
  onRefresh: (resource: MarketResource) => void
}) {
  return (
    <div className={css.dashboard}>
      <section className={css.card} aria-label="市场概览">
        {indexState.kind === 'ready' && <MarketUpdateTime snapshot={indexState.snapshot} />}
        {indexState.kind === 'loading' && <IndexSkeleton />}
        {indexState.kind === 'error' && (
          <div className={css.errorState} role="alert">
            <strong>暂时无法获取指数行情</strong>
            <span>{indexState.message}</span>
            <button type="button" className={css.retryButton} onClick={() => { onRefresh('indices') }}>重新加载</button>
          </div>
        )}
        {indexState.kind === 'ready' && (
          <IndexGrid snapshot={indexState.snapshot} trendsState={trendsState} />
        )}
        <LiveMarketPulse
          turnoverState={turnoverState}
          breadthState={breadthState}
          onRefresh={onRefresh}
        />
      </section>

      <MarketRankingsCard state={moversState} onRefresh={() => { onRefresh('movers') }} />
      <MarketHotspotsCard state={hotspotsState} onRefresh={() => { onRefresh('hotspots') }} />

      <div className={css.newsGrid}>
        <NewsCard
          id="headlines-heading"
          title="头条要闻"
          description="东方财富精选财经要闻"
          tone="headlines"
          state={headlinesState}
          onRefresh={() => { onRefresh('headlines') }}
        />
        <NewsCard
          id="flash-news-heading"
          title="24小时快讯"
          description="东方财富 7x24 实时快讯"
          tone="flash"
          state={flashNewsState}
          onRefresh={() => { onRefresh('flashNews') }}
        />
      </div>

      <InvestorQuoteFooter />
    </div>
  )
}

function InvestorQuoteFooter() {
  const [quote] = useState(() => pickInvestorQuote())
  return (
    <blockquote className={css.investorQuote} aria-label="投资名言">
      <p>{quote.quote}</p>
      <cite>—— {quote.author}</cite>
    </blockquote>
  )
}

function MarketUpdateTime({ snapshot }: { snapshot: StockMarketIndicesResponse }) {
  return (
    <span className={css.marketUpdateTime}>
      {formatUpdateTime(latestMarketTime(snapshot.indices))}
    </span>
  )
}

function formatUpdateTime(marketTime: string): string {
  const match = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/.exec(marketTime)
  if (match === null) return `数据更新时间：${marketTime}`
  const [, , month, day, hour, minute, second] = match
  return `数据更新时间：${Number(month)}月${Number(day)}日 ${Number(hour)}时${Number(minute)}分${Number(second)}秒`
}

function LiveMarketPulse({
  turnoverState,
  breadthState,
  onRefresh,
}: {
  turnoverState: TurnoverState
  breadthState: BreadthState
  onRefresh: (resource: MarketResource) => void
}) {
  return (
    <div className={css.marketPulse}>
      <div className={css.marketPulseMetric} aria-label="沪深股票涨跌分布">
        {breadthState.kind === 'loading' && <span className={`${css.skeleton} ${css.pulseSkeleton}`} />}
        {breadthState.kind === 'error' && (
          <button type="button" className={css.textButton} onClick={() => { onRefresh('breadth') }}>暂不可用，重新加载</button>
        )}
        {breadthState.kind === 'ready' && <MarketBreadthMetrics breadth={breadthState.snapshot.breadth} compact />}
      </div>
      <div className={css.marketTurnoverRow} aria-label="沪深两市成交额">
        {turnoverState.kind === 'loading' && <span className={`${css.skeleton} ${css.turnoverSkeleton}`} />}
        {turnoverState.kind === 'error' && (
          <button type="button" className={css.textButton} onClick={() => { onRefresh('turnover') }}>成交额暂不可用，重新加载</button>
        )}
        {turnoverState.kind === 'ready' && <TurnoverMetric snapshot={turnoverState.snapshot} />}
      </div>
    </div>
  )
}

function TurnoverMetric({ snapshot }: { snapshot: StockMarketTurnoverResponse }) {
  const delta = snapshot.todayAmount - snapshot.previousAmount
  const tone = toneFor(delta)
  const comparison = delta > 0
    ? `较上一日增量 +${formatAmountInHundredMillions(delta)}`
    : delta < 0
      ? `较上一日缩量 -${formatAmountInHundredMillions(delta)}`
      : '较上一日持平 0亿'
  return (
    <div className={css.turnoverMetric}>
      <span className={css.turnoverTotal}>两市成交总额 <strong>{formatAmountInHundredMillions(snapshot.todayAmount)}</strong></span>
      <span className={`${css.turnoverDelta} ${css[tone]}`}>{comparison}</span>
    </div>
  )
}

function MarketRankingsCard({ state, onRefresh }: { state: MoversState; onRefresh: () => void }) {
  return (
    <section className={css.rankingSection} aria-label="实时排行">
      {state.kind === 'error' && (
        <div className={css.insightError} role="alert">
          <span>{state.message}</span>
          <button type="button" className={css.textButton} onClick={onRefresh}>重新加载实时排行</button>
        </div>
      )}
      {state.kind !== 'error' && (
        <div className={css.rankingCardGrid}>
          {STOCK_MARKET_RANKINGS.map(ranking => (
            <article
              className={`${css.rankingMetricCard} ${css[rankingCardTone(ranking.id)]}`}
              aria-label={`${ranking.name}排行卡片`}
              key={ranking.id}
            >
              <h4>{ranking.name}</h4>
              {state.kind === 'loading'
                ? <InsightSkeleton rows={5} />
                : <MoverList rows={state.snapshot.rankings[ranking.id]} ranking={ranking.id} />}
            </article>
          ))}
        </div>
      )}
    </section>
  )
}

function rankingCardTone(ranking: StockMarketRankingId): 'rankingMetricCardRise' | 'rankingMetricCardFall' {
  return ranking === 'gainers' || ranking === 'netInflow'
    ? 'rankingMetricCardRise'
    : 'rankingMetricCardFall'
}

function MoverList({
  rows,
  ranking,
}: {
  rows: ReadonlyArray<StockMarketMoverQuote>
  ranking: StockMarketRankingId
}) {
  return (
    <div className={css.marketRankList} aria-label={`${rankingLabel(ranking)}排行`}>
      {rows.map((stock, index) => (
        <div className={css.marketRankRow} key={stock.code}>
          <span className={css.marketRankIndex}>{index + 1}</span>
          <span className={css.stockFlowIdentity}>
            <span className={css.stockFlowName}>{stock.name}</span>
            <small className={css.stockFlowCode}>{stock.code}</small>
          </span>
          <span className={css.stockFlowMetrics}>
            <strong className={`${css.insightValue} ${css[rankingTone(stock, ranking)]}`}>
              {rankingValue(stock, ranking)}
            </strong>
            <small className={`${css.stockFlowChange} ${css[toneFor(stock.changePercent)]}`}>
              {ranking === 'gainers' || ranking === 'losers'
                ? PRICE_FORMATTER.format(stock.price)
                : `${signed(stock.changePercent)}%`}
            </small>
          </span>
        </div>
      ))}
    </div>
  )
}

function MarketHotspotsCard({ state, onRefresh }: { state: HotspotsState; onRefresh: () => void }) {
  return (
    <section className={`${css.card} ${css.hotspotSection}`} aria-label="板块热点">
      {state.kind === 'error' && (
        <div className={css.insightError} role="alert">
          <span>{state.message}</span>
          <button type="button" className={css.textButton} onClick={onRefresh}>重新加载板块热点</button>
        </div>
      )}
      {state.kind !== 'error' && (
        <div className={css.hotspotCardGrid}>
          {STOCK_MARKET_HOTSPOT_GROUPS.map(group => (
            <article
              className={`${css.hotspotMetricCard} ${group.id === 'industry'
                ? css.hotspotMetricCardIndustry
                : css.hotspotMetricCardConcept}`}
              aria-label={`${group.name}涨幅卡片`}
              key={group.id}
            >
              <h4>{group.name}涨幅</h4>
              {state.kind === 'loading'
                ? <InsightSkeleton rows={5} />
                : <HotspotList rows={state.snapshot.groups[group.id]} groupName={`${group.name}涨幅`} />}
            </article>
          ))}
        </div>
      )}
    </section>
  )
}

function HotspotList({
  rows,
  groupName,
}: {
  rows: ReadonlyArray<StockMarketHotspotQuote>
  groupName: string
}) {
  return (
    <div className={css.marketRankList} aria-label={`${groupName}排行`}>
      {rows.map((hotspot, index) => (
        <div className={css.marketRankRow} key={hotspot.code}>
          <span className={css.marketRankIndex}>{index + 1}</span>
          <span className={css.stockFlowIdentity}>
            <span className={css.stockFlowName}>{hotspot.name}</span>
            <small className={css.stockFlowCode}>{hotspot.code}</small>
          </span>
          <strong className={`${css.insightValue} ${css[toneFor(hotspot.changePercent)]}`}>
            {signed(hotspot.changePercent)}%
          </strong>
        </div>
      ))}
    </div>
  )
}

function MarketBreadthMetrics({
  breadth,
  compact = false,
}: {
  breadth: StockMarketBreadth
  compact?: boolean
}) {
  const total = breadth.rising + breadth.falling + breadth.flat
  const percentage = (value: number): string => `${total === 0 ? 0 : (value / total) * 100}%`
  const ariaLabel = compact
    ? `沪深A股涨跌：上涨 ${breadth.rising}，下跌 ${breadth.falling}`
    : `沪深A股涨跌：上涨 ${breadth.rising}，下跌 ${breadth.falling}，平盘 ${breadth.flat}`

  return (
    <div
      className={compact ? `${css.marketBreadth} ${css.marketBreadthCompact}` : css.marketBreadth}
      aria-label={ariaLabel}
    >
      <div className={css.marketBreadthLabels}>
        <span className={css.marketBreadthFall}>跌 <strong>{breadth.falling}</strong></span>
        {!compact && <span className={css.marketBreadthFlat}>平 <strong>{breadth.flat}</strong></span>}
        <span className={css.marketBreadthRise}>涨 <strong>{breadth.rising}</strong></span>
      </div>
      <div className={css.marketBreadthTrack} aria-hidden="true">
        <span className={css.marketBreadthFallBar} style={{ width: percentage(breadth.falling) }} />
        <span className={css.marketBreadthFlatBar} style={{ width: percentage(breadth.flat) }} />
        <span className={css.marketBreadthRiseBar} style={{ width: percentage(breadth.rising) }} />
      </div>
    </div>
  )
}

function CardHeading({
  id,
  title,
  description,
  action,
}: {
  id: string
  title: string
  description: string
  action?: ReactNode
}) {
  return (
    <header className={css.cardHeader}>
      <div>
        <h3 id={id}>{title}</h3>
        <p>{description}</p>
      </div>
      {action}
    </header>
  )
}

function IndexGrid({
  snapshot,
  trendsState,
}: {
  snapshot: StockMarketIndicesResponse
  trendsState: TrendsState
}) {
  const quoteById = new Map(snapshot.indices.map(quote => [quote.id, quote]))
  const trendById = new Map(
    trendsState.kind === 'ready' ? trendsState.snapshot.series.map(trend => [trend.id, trend]) : [],
  )
  const unavailable = new Set(snapshot.unavailable)
  const unavailableNames = STOCK_MARKET_INDICES
    .filter(index => unavailable.has(index.id))
    .map(index => index.name)

  return (
    <>
      <div className={css.quoteGrid}>
        {STOCK_MARKET_INDICES.map(index => (
          <IndexCard
            key={index.id}
            index={index}
            quote={quoteById.get(index.id)}
            trend={trendById.get(index.id)}
            trendLoading={trendsState.kind === 'loading'}
          />
        ))}
      </div>
      {unavailableNames.length > 0 && (
        <p className={css.partialNotice}>
          暂不可用：{unavailableNames.join('、')}
        </p>
      )}
    </>
  )
}

function IndexCard({
  index,
  quote,
  trend,
  trendLoading,
}: {
  index: MarketIndex
  quote: StockMarketIndexQuote | undefined
  trend: StockMarketIndexTrend | undefined
  trendLoading: boolean
}) {
  if (quote === undefined) {
    return (
      <article className={`${css.quoteCard} ${css.quoteUnavailable}`} aria-label={`${index.name}暂不可用`}>
        <p className={css.quoteName}>{index.name}</p>
        <p className={css.unavailableValue}>--</p>
        <p className={css.quoteTime}>当前指数暂不可用</p>
      </article>
    )
  }

  const tone = quote.change > 0 ? 'quoteRise' : quote.change < 0 ? 'quoteFall' : 'quoteFlat'
  const cardTone = quote.change > 0
    ? 'quoteCardRise'
    : quote.change < 0 ? 'quoteCardFall' : 'quoteCardFlat'

  return (
    <article className={`${css.quoteCard} ${css[cardTone]}`} aria-label={index.name}>
      <p className={css.quoteName}>{index.name}</p>
      <p className={`${css.quotePrice} ${css[tone]}`}>{PRICE_FORMATTER.format(quote.price)}</p>
      <p className={`${css.quoteChange} ${css[tone]}`}>
        <span>{signed(quote.change)}</span>
        <span>{signed(quote.changePercent)}%</span>
      </p>
      <IndexSparkline indexName={index.name} trend={trend} tone={tone} loading={trendLoading} />
      <div className={css.quoteStats}>
        <span>高 <strong>{PRICE_FORMATTER.format(quote.high)}</strong></span>
        <span>低 <strong>{PRICE_FORMATTER.format(quote.low)}</strong></span>
      </div>
    </article>
  )
}

function IndexSparkline({
  indexName,
  trend,
  tone,
  loading,
}: {
  indexName: string
  trend: StockMarketIndexTrend | undefined
  tone: 'quoteRise' | 'quoteFall' | 'quoteFlat'
  loading: boolean
}) {
  if (trend === undefined) {
    return (
      <div className={css.sparklinePlaceholder} aria-label={`${indexName}分时${loading ? '加载中' : '暂不可用'}`}>
        {loading && <span className={css.skeleton} />}
      </div>
    )
  }

  const width = 120
  const height = 38
  const plottedPoints = trend.points.flatMap(point => {
    const timeRatio = marketTrendTimeRatio(point.time)
    return timeRatio === undefined ? [] : [{ point, x: timeRatio * width }]
  })
  if (plottedPoints.length === 0) {
    return <div className={css.sparklinePlaceholder} aria-label={`${indexName}分时暂不可用`} />
  }

  const values = [...plottedPoints.map(({ point }) => point.price), trend.previousClose]
  const minimum = Math.min(...values)
  const maximum = Math.max(...values)
  const range = maximum - minimum || Math.max(Math.abs(maximum) * 0.002, 1)
  const padding = range * 0.12
  const chartMin = minimum - padding
  const chartRange = range + padding * 2
  const yFor = (value: number): number => height - ((value - chartMin) / chartRange) * height
  const points = plottedPoints
    .map(({ point, x }) => `${x.toFixed(2)},${yFor(point.price).toFixed(2)}`)
    .join(' ')

  return (
    <svg
      className={`${css.sparkline} ${css[tone]}`}
      viewBox={`0 0 ${width} ${height}`}
      preserveAspectRatio="none"
      role="img"
      aria-label={`${indexName}当日分时走势`}
    >
      <line className={css.sparklineBaseline} x1="0" x2={width} y1={yFor(trend.previousClose)} y2={yFor(trend.previousClose)} />
      <polyline className={css.sparklineLine} points={points} />
    </svg>
  )
}

function IndexSkeleton() {
  return (
    <div className={css.quoteGrid} aria-label="指数行情加载中" aria-busy="true">
      {STOCK_MARKET_INDICES.map(index => (
        <div key={index.id} className={css.quoteCard}>
          <span className={`${css.skeleton} ${css.skeletonName}`} />
          <span className={`${css.skeleton} ${css.skeletonPrice}`} />
          <span className={`${css.skeleton} ${css.skeletonChange}`} />
          <span className={`${css.skeleton} ${css.skeletonTime}`} />
        </div>
      ))}
    </div>
  )
}

function InsightSkeleton({ rows }: { rows: number }) {
  return (
    <div className={css.insightSkeleton} aria-label="行情数据加载中" aria-busy="true">
      {Array.from({ length: rows }, (_, index) => (
        <span className={css.pendingRow} key={index} aria-hidden="true">
          <i className={css.skeleton} />
          <i className={`${css.skeleton} ${css.pendingValue}`} />
        </span>
      ))}
    </div>
  )
}

function NewsCard({
  id,
  title,
  description,
  tone,
  state,
  onRefresh,
}: {
  id: string
  title: string
  description: string
  tone: 'headlines' | 'flash'
  state: NewsState
  onRefresh: () => void
}) {
  return (
    <section
      className={`${css.newsCard} ${tone === 'headlines' ? css.newsCardHeadlines : css.newsCardFlash}`}
      aria-labelledby={id}
    >
      <CardHeading
        id={id}
        title={title}
        description={description}
      />
      {state.kind === 'loading' && <InsightSkeleton rows={6} />}
      {state.kind === 'error' && (
        <div className={css.insightError}>
          <span>{state.message}</span>
          <button type="button" className={css.textButton} onClick={onRefresh}>重新加载</button>
        </div>
      )}
      {state.kind === 'ready' && <NewsList items={state.snapshot.items} />}
    </section>
  )
}

function NewsList({ items }: { items: ReadonlyArray<StockMarketNewsItem> }) {
  return (
    <div className={css.newsList}>
      {items.map(item => (
        <div className={css.newsRow} key={item.id}>
          <span className={css.newsTime}>{item.time.slice(11, 16) || item.time}</span>
          <span className={css.newsTitle} title={item.summary}>{item.title}</span>
        </div>
      ))}
    </div>
  )
}

function rankingLabel(ranking: StockMarketRankingId): string {
  return STOCK_MARKET_RANKINGS.find(candidate => candidate.id === ranking)?.name ?? '个股'
}

function rankingTone(
  stock: StockMarketMoverQuote,
  ranking: StockMarketRankingId,
): 'insightRise' | 'insightFall' | 'insightFlat' {
  return ranking === 'netInflow' || ranking === 'netOutflow'
    ? toneFor(stock.netInflow)
    : toneFor(stock.changePercent)
}

function rankingValue(stock: StockMarketMoverQuote, ranking: StockMarketRankingId): string {
  switch (ranking) {
    case 'gainers':
    case 'losers': return `${signed(stock.changePercent)}%`
    case 'netInflow':
    case 'netOutflow': return flowInHundredMillions(stock.netInflow)
  }
}

function flowInHundredMillions(value: number): string {
  const formatted = FLOW_FORMATTER.format(Math.abs(value) / 100_000_000)
  if (value > 0) return `+${formatted} 亿`
  if (value < 0) return `-${formatted} 亿`
  return `${formatted} 亿`
}

function toneFor(value: number): 'insightRise' | 'insightFall' | 'insightFlat' {
  if (value > 0) return 'insightRise'
  if (value < 0) return 'insightFall'
  return 'insightFlat'
}

function signed(value: number): string {
  const formatted = CHANGE_FORMATTER.format(Math.abs(value))
  if (value > 0) return `+${formatted}`
  if (value < 0) return `-${formatted}`
  return formatted
}

function formatAmountInHundredMillions(value: number): string {
  return `${AMOUNT_FORMATTER.format(Math.abs(value) / 100_000_000)}亿`
}

function latestMarketTime(indices: ReadonlyArray<StockMarketIndexQuote>): string {
  return indices.map(index => index.marketTime).sort().at(-1) ?? '--'
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : '连接行情后端失败。'
}
