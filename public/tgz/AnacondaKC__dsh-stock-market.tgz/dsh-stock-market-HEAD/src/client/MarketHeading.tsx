import { useEffect, useRef, useState } from 'react'
import {
  STOCK_MARKET_GLOBAL_ASSETS,
  type StockMarketGlobalQuote,
  type StockMarketGlobalQuotesResponse,
} from '../rpc-contract.ts'
import { findPageHeader } from './page-chrome.ts'
import css from './MarketHeading.module.css'

type MarketHeadingState =
  | { kind: 'loading' }
  | { kind: 'ready'; snapshot: StockMarketGlobalQuotesResponse }
  | { kind: 'error'; message: string }

export interface MarketHeadingProps {
  state: MarketHeadingState
}

/** Fallback for the host page header height when it cannot be measured yet. */
const PAGE_HEADER_HEIGHT_FALLBACK = 76
const PRICE_FORMATTER = new Intl.NumberFormat('zh-CN', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})
const CHANGE_FORMATTER = new Intl.NumberFormat('zh-CN', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})

/** Keep the market strip aligned with the host conversation header. */
export function MarketHeading({ state }: MarketHeadingProps) {
  const rootRef = useRef<HTMLElement>(null)
  const [headingHeight, setHeadingHeight] = useState(PAGE_HEADER_HEIGHT_FALLBACK)

  useEffect(() => {
    const measure = (): void => {
      const header = findPageHeader()
      const root = rootRef.current
      if (header === undefined || root === null) return
      const target = Math.round(header.getBoundingClientRect().bottom - root.getBoundingClientRect().top)
      if (target > 0 && Math.abs(target - root.getBoundingClientRect().height) > 1) {
        setHeadingHeight(target)
      }
    }
    measure()
    window.addEventListener('resize', measure)
    return () => { window.removeEventListener('resize', measure) }
  }, [])

  return (
    <header
      ref={rootRef}
      className={css.heading}
      style={{ height: headingHeight }}
      aria-label="全球市场行情"
    >
      <div className={css.marketStrip}>
        {STOCK_MARKET_GLOBAL_ASSETS.map(asset => {
          const quote = state.kind === 'ready'
            ? state.snapshot.quotes.find(candidate => candidate.id === asset.id)
            : undefined
          return (
            <MarketStripItem
              key={asset.id}
              name={asset.name}
              quote={quote}
              state={state.kind}
            />
          )
        })}
      </div>
    </header>
  )
}

function MarketStripItem({
  name,
  quote,
  state,
}: {
  name: string
  quote: StockMarketGlobalQuote | undefined
  state: MarketHeadingState['kind']
}) {
  if (quote === undefined) {
    const status = state === 'loading' ? '加载中' : '暂不可用'
    return (
      <section className={`${css.marketItem} ${css.marketItemFlat}`} aria-label={`${name}全球行情：${status}`}>
        <span className={css.marketName}>{name}</span>
        <span className={css.marketUnavailable}>{state === 'loading' ? '--' : '暂无'}</span>
        <span className={css.marketStatus}>{status}</span>
      </section>
    )
  }

  const tone = quote.change > 0
    ? css.marketRise
    : quote.change < 0
      ? css.marketFall
      : css.marketFlat
  const cardTone = quote.change > 0
    ? css.marketItemRise
    : quote.change < 0
      ? css.marketItemFall
      : css.marketItemFlat
  const change = signed(quote.change)
  const changePercent = `${signed(quote.changePercent)}%`
  return (
    <section
      className={`${css.marketItem} ${cardTone}`}
      aria-label={`${name}全球行情：${PRICE_FORMATTER.format(quote.price)}，${change}，${changePercent}`}
      title={quoteTitle(name, quote)}
    >
      <span className={css.marketName}>{name}</span>
      <strong className={`${css.marketPrice} ${tone}`}>{PRICE_FORMATTER.format(quote.price)}</strong>
      <span className={`${css.marketChange} ${tone}`}>
        <span>{change}</span>
        <span>{changePercent}</span>
      </span>
    </section>
  )
}

function quoteTitle(name: string, quote: StockMarketGlobalQuote): string {
  const details = [
    `${name} ${PRICE_FORMATTER.format(quote.price)}`,
    `涨跌 ${signed(quote.change)} (${signed(quote.changePercent)}%)`,
    optionalPrice('昨收', quote.previousClose),
    optionalPrice('今开', quote.open),
    optionalPrice('最高', quote.high),
    optionalPrice('最低', quote.low),
    quote.marketTime === '' ? undefined : `时间 ${quote.marketTime}`,
  ]
  return details.filter((detail): detail is string => detail !== undefined).join(' · ')
}

function optionalPrice(label: string, value: number | null): string | undefined {
  return value === null ? undefined : `${label} ${PRICE_FORMATTER.format(value)}`
}

function signed(value: number): string {
  const formatted = CHANGE_FORMATTER.format(Math.abs(value))
  if (value > 0) return `+${formatted}`
  if (value < 0) return `-${formatted}`
  return formatted
}
