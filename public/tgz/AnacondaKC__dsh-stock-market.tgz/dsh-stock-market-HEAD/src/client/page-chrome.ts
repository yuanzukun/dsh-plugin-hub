/**
 * Find the host page's conversation header — the first <header> outside the
 * plugin's own sidebar host. The stock panel aligns its heading against this
 * chrome.
 */
export function findPageHeader(): HTMLElement | undefined {
  return [...document.querySelectorAll('header')]
    .find(candidate => candidate.closest('[data-dsh-stock-market-sidebar]') === null)
}
