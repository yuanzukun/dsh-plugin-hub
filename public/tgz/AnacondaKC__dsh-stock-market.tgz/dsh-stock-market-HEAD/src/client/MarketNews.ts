import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import {
  STOCK_MARKET_RPC_CHANNEL,
  STOCK_MARKET_RPC_PROTOCOL_VERSION,
  isStockMarketNewsResponse,
  type StockMarketNewsResponse,
} from '../rpc-contract.ts'

/** Fetch the bounded Eastmoney news list (headlines or 24h flash news). */
export async function loadMarketNews(
  connection: ConnectionHandle,
  endpoint: string,
  signal?: AbortSignal,
): Promise<StockMarketNewsResponse> {
  const result = await connection.rpc.call(
    STOCK_MARKET_RPC_CHANNEL,
    endpoint,
    { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
    signal,
  )
  if (!result.ok) throw new Error(result.error.message)
  if (!isStockMarketNewsResponse(result.value)) {
    throw new Error('后端返回了不兼容的资讯数据。')
  }
  return result.value
}
