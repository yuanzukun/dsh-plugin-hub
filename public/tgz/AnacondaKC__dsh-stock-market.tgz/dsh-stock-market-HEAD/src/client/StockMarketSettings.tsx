import {
  IconApiOutline14,
  IconDataOutline16,
  StateDot,
} from '@deepseek-ai/dsh-client-ui-primitives'
import {
  STOCK_TOOL_CAPABILITIES,
  type StockActionDefinition,
} from '../stock-agent-contract.ts'
import type { StockDataProvider } from '../stock-api/types.ts'
import css from './StockMarketSettings.module.css'

const PUBLIC_SOURCES = [
  {
    id: 'tencent',
    name: '腾讯行情',
    description: '用于市场概览、两市成交额比较，并开放实时行情、K 线、分时、排行和个股资讯工具。',
  },
  {
    id: 'eastmoney',
    name: '东方财富',
    description: '固定目录覆盖行情、历史数据、资金流、数据中心、F10、研报、资讯和搜索。',
  },
  {
    id: 'sina',
    name: '新浪财经',
    description: '固定 Referer 访问行情、K 线、板块、资金流、滚动新闻及页面型数据。',
  },
  {
    id: 'tonghuashun',
    name: '同花顺',
    description: '固定 Referer 访问日 K 与分时 JSONP 数据。',
  },
] as const

export function StockMarketSettings() {
  return (
    <section className={css.root}>
      <section className={css.settingsSection} aria-labelledby="stock-public-source-title">
        <header className={css.sectionHeading}>
          <div className={css.sectionTitle}>
            <IconDataOutline16 size={16} />
            <h3 id="stock-public-source-title">免费数据源</h3>
          </div>
          <p>以下数据源均无需配置，可直接用于行情查询。</p>
        </header>

        <div className={css.credentials}>
          {PUBLIC_SOURCES.map(source => <PublicSourceStatus key={source.id} {...source} />)}
        </div>
      </section>

      <ToolCatalog />
    </section>
  )
}

function PublicSourceStatus({
  id,
  name,
  description,
}: typeof PUBLIC_SOURCES[number]) {
  return (
    <section className={css.credential} aria-labelledby={`${id}-source-title`}>
      <div className={css.sourceHeading}>
        <div className={css.sourceIdentity}>
          <h4 id={`${id}-source-title`}>{name}</h4>
          <span className={css.publicLabel}>免费数据源</span>
        </div>
        <span className={css.statusLabel}>
          <StateDot state="done" />
          可直接使用
        </span>
      </div>
      <p className={css.help}>{description}</p>
    </section>
  )
}

function ToolCatalog() {
  return (
    <section className={css.settingsSection} aria-labelledby="stock-tool-catalog-title">
      <header className={css.sectionHeading}>
        <div className={css.sectionTitle}>
          <IconApiOutline14 size={16} />
          <h3 id="stock-tool-catalog-title">已接入工具</h3>
        </div>
        <p>共 {STOCK_TOOL_CAPABILITIES.length} 个 Agent 工具，按动作列出参数、免费数据源及故障切换口径。</p>
      </header>
      <div className={css.catalogList}>
        {STOCK_TOOL_CAPABILITIES.map(tool => (
          <section key={tool.name} className={css.catalogSource} aria-label={`${tool.name} 工具`}>
            <div className={css.catalogSourceHeading}>
              <h4 className={css.toolName}>{tool.name}</h4>
              <span>{tool.actions.length} 个动作</span>
            </div>
            <p className={css.toolSummary}>{tool.summary}</p>
            <div className={css.actionList}>
              {tool.actions.map(action => <ToolAction key={action.name} tool={tool.name} action={action} />)}
            </div>
          </section>
        ))}
      </div>
    </section>
  )
}

function ToolAction({
  tool,
  action,
}: {
  tool: string
  action: StockActionDefinition
}) {
  return (
    <div className={css.actionItem} role="group" aria-label={`${tool}.${action.name}`}>
      <div className={css.actionHeading}>
        <code>{action.name}</code>
        <span>{action.summary}</span>
      </div>
      <dl className={css.actionDetails}>
        <div>
          <dt>参数</dt>
          <dd className={css.parameterList}>
            {action.parameters.map(parameter => <ToolParameter key={parameter} parameter={parameter} />)}
          </dd>
        </div>
        <div>
          <dt>来源</dt>
          <dd>{formatSources(action.sources)}</dd>
        </div>
        <div>
          <dt>切换</dt>
          <dd>{formatFallback(action)}</dd>
        </div>
      </dl>
    </div>
  )
}

function ToolParameter({ parameter }: { parameter: string }) {
  const optional = parameter.endsWith('?')
  const name = optional ? parameter.slice(0, -1) : parameter
  return (
    <span className={css.parameter}>
      <code>{name}</code>
      <small>{optional ? '可选' : '必填'}</small>
    </span>
  )
}

const SOURCE_LABELS: Readonly<Record<StockDataProvider, string>> = {
  eastmoney: '东方财富',
  tencent: '腾讯行情',
  sina: '新浪财经',
  tonghuashun: '同花顺',
}

function formatSources(sources: readonly StockDataProvider[]): string {
  return sources.length === 0 ? '插件内置' : sources.map(source => SOURCE_LABELS[source]).join(' · ')
}

function formatFallback(action: StockActionDefinition): string {
  if (action.sources.length === 0) return '无需外部数据源切换'
  if (action.fallback === 'equivalent') return '支持同字段结构故障切换'
  if (action.fallback === 'methodology') return '支持切换，备用源口径可能不同'
  return '无等价备用数据源'
}
