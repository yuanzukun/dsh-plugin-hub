import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import {
  STOCK_MARKET_CONFIG_ENDPOINT,
  STOCK_MARKET_DEFAULT_CONFIG,
  STOCK_MARKET_RPC_CHANNEL,
  STOCK_MARKET_RPC_PROTOCOL_VERSION,
  STOCK_MARKET_SET_CONFIG_ENDPOINT,
  isStockMarketConfigResponse,
  isStockMarketSetConfigResponse,
  type StockMarketPluginConfig,
} from '../rpc-contract.ts'

/**
 * Load the plugin-wide configuration from the host half. Any failure (RPC
 * unavailable, incompatible payload) falls back to the built-in defaults so
 * the browser UI stays usable in degraded states.
 */
export async function loadStockMarketConfig(
  connection: ConnectionHandle,
  signal?: AbortSignal,
): Promise<StockMarketPluginConfig> {
  try {
    const result = await connection.rpc.call(
      STOCK_MARKET_RPC_CHANNEL,
      STOCK_MARKET_CONFIG_ENDPOINT,
      {
        protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
      },
      signal,
    )
    if (!result.ok) return { ...STOCK_MARKET_DEFAULT_CONFIG }
    if (!isStockMarketConfigResponse(result.value)) return { ...STOCK_MARKET_DEFAULT_CONFIG }
    return { ...result.value.config }
  } catch {
    return { ...STOCK_MARKET_DEFAULT_CONFIG }
  }
}

/** Persist the plugin-wide configuration through the host half. */
export async function saveStockMarketConfig(
  connection: ConnectionHandle,
  config: StockMarketPluginConfig,
  signal?: AbortSignal,
): Promise<void> {
  const result = await connection.rpc.call(
    STOCK_MARKET_RPC_CHANNEL,
    STOCK_MARKET_SET_CONFIG_ENDPOINT,
    {
      protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
      config,
    },
    signal,
  )
  if (!result.ok) throw new Error(result.error.message)
  if (!isStockMarketSetConfigResponse(result.value)) {
    throw new Error('后端返回了不兼容的插件配置保存结果。')
  }
}
