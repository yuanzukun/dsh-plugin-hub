import { useEffect, useState } from 'react'
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import {
  STOCK_MARKET_INDICES,
  type StockMarketBreadth,
  type StockMarketIndexId,
  type StockMarketIndexQuote,
  type StockMarketTradingStatus,
} from '../rpc-contract.ts'
import { loadMarketIndices } from './MarketIndices.ts'
import css from './StockMarketSideCard.module.css'

export interface MarketIndexTickerProps {
  connection: ConnectionHandle
  panelOpen: boolean
  breadth: StockMarketBreadth | undefined
  onToggle: () => void
}

type TickerState =
  | { kind: 'loading' }
  | {
      kind: 'ready'
      quotes: ReadonlyArray<StockMarketIndexQuote>
      marketStatus: StockMarketTradingStatus
    }
  | { kind: 'unavailable' }

type MarketTone = 'rise' | 'fall' | 'flat'

const TICKER_POLL_INTERVAL_MS = 5_000
const TICKER_IDLE_POLL_INTERVAL_MS = 60_000
const TICKER_MAX_BACKOFF_MS = 5 * 60_000

const TICKER_SHORT_NAMES: Record<StockMarketIndexId, string> = {
  sse: '上证指数',
  szse: '深证成指',
  chinext: '创业板指',
  star50: '科创综指',
}

const TICKER_TEXT_TONE_CLASS: Record<MarketTone, string> = {
  rise: css.tickerRise,
  fall: css.tickerFall,
  flat: css.tickerFlat,
}

const TICKER_ROW_TONE_CLASS: Record<MarketTone, string> = {
  rise: css.tickerRowRise,
  fall: css.tickerRowFall,
  flat: css.tickerRowFlat,
}

const PRICE_FORMATTER = new Intl.NumberFormat('zh-CN', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 3,
})
const CHANGE_FORMATTER = new Intl.NumberFormat('zh-CN', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})

export function MarketIndexTicker({
  connection,
  panelOpen,
  breadth,
  onToggle,
}: MarketIndexTickerProps) {
  const [state, setState] = useState<TickerState>({ kind: 'loading' })
  const sseQuote = state.kind === 'ready'
    ? state.quotes.find(quote => quote.id === 'sse')
    : undefined
  const surfaceTone: MarketTone = sseQuote === undefined || sseQuote.change === 0
    ? 'flat'
    : sseQuote.change > 0 ? 'rise' : 'fall'
  const buttonTone: MarketTone = panelOpen ? surfaceTone : 'flat'
  const surfaceClass = buttonTone === 'rise'
    ? css.marketRailButtonRise
    : buttonTone === 'fall'
      ? css.marketRailButtonFall
      : css.marketRailButtonFlat
  const total = breadth === undefined ? 0 : breadth.rising + breadth.falling + breadth.flat
  const temperature = breadth !== undefined && total > 0
    ? Math.round((breadth.rising / total) * 100)
    : undefined
  const temperatureColor = temperature === undefined
    ? undefined
    : temperature > 50
      ? 'var(--dsw-alias-state-error-primary)'
      : temperature < 50
        ? 'var(--dsw-alias-state-success-primary)'
        : 'var(--dsw-alias-label-secondary)'

  useEffect(() => {
    if (panelOpen) return

    let active = true
    let hasSnapshot = state.kind === 'ready'
    let pollIntervalMs = tickerPollingInterval(state.kind === 'ready' ? state.marketStatus : undefined)
    let consecutiveFailures = 0
    let controller: AbortController | undefined
    let timer: ReturnType<typeof setTimeout> | undefined
    let lastStartedAt = 0

    const clearTimer = (): void => {
      if (timer === undefined) return
      clearTimeout(timer)
      timer = undefined
    }
    function schedule(): void {
      clearTimer()
      if (!active || document.visibilityState === 'hidden') return
      const delay = Math.min(pollIntervalMs * (2 ** consecutiveFailures), TICKER_MAX_BACKOFF_MS)
      timer = setTimeout(() => {
        timer = undefined
        run(false)
      }, Math.max(0, delay - (Date.now() - lastStartedAt)))
    }
    function run(showLoading: boolean): void {
      controller?.abort()
      const requestController = new AbortController()
      controller = requestController
      lastStartedAt = Date.now()
      if (showLoading) setState({ kind: 'loading' })

      void loadMarketIndices(connection, requestController.signal).then((snapshot) => {
        if (!active || requestController.signal.aborted) return
        hasSnapshot = true
        consecutiveFailures = 0
        pollIntervalMs = tickerPollingInterval(snapshot.marketStatus)
        setState({ kind: 'ready', quotes: snapshot.indices, marketStatus: snapshot.marketStatus })
      }).catch(() => {
        if (!active || requestController.signal.aborted) return
        consecutiveFailures++
        if (!hasSnapshot) setState({ kind: 'unavailable' })
      }).finally(() => {
        if (!active || controller !== requestController) return
        controller = undefined
        schedule()
      })
    }
    const onVisibilityChange = (): void => {
      if (document.visibilityState === 'hidden') {
        clearTimer()
        controller?.abort()
        controller = undefined
      } else {
        const delay = Math.min(pollIntervalMs * (2 ** consecutiveFailures), TICKER_MAX_BACKOFF_MS)
        if (!hasSnapshot || Date.now() - lastStartedAt >= delay) {
          run(!hasSnapshot)
        } else {
          schedule()
        }
      }
    }

    document.addEventListener('visibilitychange', onVisibilityChange)
    if (document.visibilityState !== 'hidden') run(!hasSnapshot)

    return () => {
      active = false
      clearTimer()
      controller?.abort()
      document.removeEventListener('visibilitychange', onVisibilityChange)
    }
  }, [connection, panelOpen])

  return (
    <div className={panelOpen ? `${css.marketRail} ${css.marketRailOpen}` : css.marketRail}>
      <button
        type="button"
        className={`${css.marketRailButton} ${surfaceClass}${panelOpen ? ` ${css.marketRailButtonOpen}` : ''}`}
        aria-label={panelOpen ? '收起行情侧栏' : '打开行情侧栏'}
        aria-controls="stock-market-side-card"
        aria-expanded={panelOpen}
        data-market-temperature={temperature}
        data-market-tone={buttonTone}
        onClick={onToggle}
      >
        <span className={css.tickerRows} aria-hidden={panelOpen}>
            {STOCK_MARKET_INDICES.map(index => {
              const quote = state.kind === 'ready'
                ? state.quotes.find(candidate => candidate.id === index.id)
                : undefined
              const display = displayFor(quote, state.kind)
              const fullChange = display.changePercent === undefined
                ? display.change
                : `${display.change} ${display.changePercent}`
              return (
                <span
                  key={index.id}
                  className={`${css.tickerRow} ${TICKER_ROW_TONE_CLASS[display.tone]}`}
                  data-market-tone={display.tone}
                  title={`${index.name} ${display.price} ${fullChange} 成交额 ${display.amount}`}
                >
                  <span className={css.tickerName}>{TICKER_SHORT_NAMES[index.id]}</span>
                  <span className={`${css.tickerPrice} ${TICKER_TEXT_TONE_CLASS[display.tone]}`}>{display.compactPrice}</span>
                  <span className={`${css.tickerChange} ${TICKER_TEXT_TONE_CLASS[display.tone]}`}>
                    {display.compactChange}
                  </span>
                  <span className={css.tickerAmount}>{display.amount}</span>
                  <span className={css.tickerFullValue}>{display.price}</span>
                  <span className={css.tickerFullValue}>{fullChange}</span>
                </span>
              )
            })}
          </span>
          <span className={css.temperature} aria-hidden={!panelOpen}>
            <span
              className={css.temperatureValue}
              style={temperatureColor === undefined ? undefined : { color: temperatureColor }}
            >
              {temperature ?? '--'}<small>°</small>
            </span>
            <span className={css.temperatureTrack} aria-hidden="true">
              <span
                className={css.temperatureFill}
                style={{
                  height: `${temperature ?? 0}%`,
                  backgroundColor: temperatureColor ?? 'var(--dsw-alias-border-l3)',
                }}
              />
            </span>
        </span>
      </button>
    </div>
  )
}

function tickerPollingInterval(status: StockMarketTradingStatus | undefined): number {
  return status === undefined || status === 'auction' || status === 'trading'
    ? TICKER_POLL_INTERVAL_MS
    : TICKER_IDLE_POLL_INTERVAL_MS
}

function displayFor(
  quote: StockMarketIndexQuote | undefined,
  state: TickerState['kind'],
): {
  price: string
  compactPrice: string
  change: string
  changePercent?: string
  compactChange: string
  amount: string
  tone: MarketTone
} {
  if (quote === undefined) {
    return {
      price: '--',
      compactPrice: '--',
      change: state === 'loading' ? '加载中' : '暂不可用',
      compactChange: state === 'loading' ? '加载' : '暂无',
      amount: '--',
      tone: 'flat',
    }
  }

  return {
    price: PRICE_FORMATTER.format(quote.price),
    compactPrice: compactPrice(quote.price),
    change: signed(quote.change),
    changePercent: `${signed(quote.changePercent)}%`,
    compactChange: `${signed(quote.changePercent)}%`,
    amount: compactAmount(quote.amount),
    tone: quote.change > 0 ? 'rise' : quote.change < 0 ? 'fall' : 'flat',
  }
}

function compactPrice(value: number): string {
  if (Math.abs(value) >= 10_000) return `${(value / 10_000).toFixed(2)}万`
  return Math.round(value).toLocaleString('zh-CN')
}

function compactAmount(value: number): string {
  if (Math.abs(value) >= 1_000_000_000_000) return `${(value / 1_000_000_000_000).toFixed(1)}万亿`
  return `${Math.round(value / 100_000_000)}亿`
}

function signed(value: number): string {
  const formatted = CHANGE_FORMATTER.format(Math.abs(value))
  if (value > 0) return `+${formatted}`
  if (value < 0) return `-${formatted}`
  return formatted
}
