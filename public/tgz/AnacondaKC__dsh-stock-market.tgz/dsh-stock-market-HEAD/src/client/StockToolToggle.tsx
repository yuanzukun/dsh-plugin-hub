import { useEffect, useRef, useState } from 'react'
import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import { IconDataOutline16 } from '@deepseek-ai/dsh-client-ui-primitives'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import css from './StockToolToggle.module.css'

export interface StockToolToggleInjected {
  load(signal?: AbortSignal): Promise<boolean>
  setEnabled(enabled: boolean, signal?: AbortSignal): Promise<boolean>
}

export type StockToolToggleProps =
  PropsRuntime<'conversation.input.left'> & InjectFace<StockToolToggleInjected>

export function StockToolToggle({ load, setEnabled, session }: StockToolToggleProps) {
  const [enabled, setEnabledState] = useState(true)
  const [loading, setLoading] = useState(true)
  const [pending, setPending] = useState(false)
  const [error, setError] = useState<string>()
  const loadControllerRef = useRef<AbortController>()
  const mutationControllerRef = useRef<AbortController>()

  useEffect(() => {
    setPending(false)
    setError(undefined)
    if (session.removed) {
      setLoading(false)
      return
    }

    const controller = new AbortController()
    loadControllerRef.current = controller
    setLoading(true)
    void load(controller.signal).then((next) => {
      if (controller.signal.aborted || loadControllerRef.current !== controller) return
      setEnabledState(next)
      setLoading(false)
    }, (reason: unknown) => {
      if (controller.signal.aborted || loadControllerRef.current !== controller) return
      setError(messageOf(reason))
      setLoading(false)
    })
    return () => {
      if (loadControllerRef.current === controller) loadControllerRef.current = undefined
      controller.abort()
      const mutation = mutationControllerRef.current
      mutationControllerRef.current = undefined
      mutation?.abort()
    }
  }, [load, setEnabled, session.removed])

  const toggle = (): void => {
    if (loading || pending || session.removed) return
    const controller = new AbortController()
    mutationControllerRef.current?.abort()
    mutationControllerRef.current = controller
    setPending(true)
    setError(undefined)
    void setEnabled(!enabled, controller.signal).then((next) => {
      if (controller.signal.aborted || mutationControllerRef.current !== controller) return
      setEnabledState(next)
    }, (reason: unknown) => {
      if (controller.signal.aborted || mutationControllerRef.current !== controller) return
      setError(messageOf(reason))
    }).finally(() => {
      if (mutationControllerRef.current !== controller) return
      mutationControllerRef.current = undefined
      setPending(false)
    })
  }

  const unavailable = session.removed || loading || pending
  const action = enabled ? '关闭' : '开启'
  const title = error === undefined
    ? `股票工具已${enabled ? '开启' : '关闭'}，按下${action}`
    : `股票工具状态更新失败：${error}`

  return (
    <span className={css.wrap}>
      <button
        type="button"
        role="switch"
        aria-checked={enabled}
        aria-busy={loading || pending}
        aria-label={title}
        title={title}
        className={enabled ? css.enabled : css.disabled}
        disabled={unavailable}
        data-error={error === undefined ? undefined : ''}
        onClick={toggle}
      >
        <IconDataOutline16 size={16} />
        <span className={css.label}>股票工具</span>
      </button>
      <span className={css.srOnly} role="status" aria-live="polite">
        {error === undefined ? '' : `股票工具状态更新失败：${error}`}
      </span>
    </span>
  )
}

function messageOf(value: unknown): string {
  return value instanceof Error ? value.message : String(value)
}
