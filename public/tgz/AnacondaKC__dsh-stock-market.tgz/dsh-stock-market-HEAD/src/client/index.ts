import { Component, createElement, type ErrorInfo, type ReactNode } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import type { ClientContext, SessionId } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings-plugins/client'
import { STOCK_MARKET_DEFAULT_CONFIG, type StockMarketPluginConfig } from '../rpc-contract.ts'
import { StockMarketConfigCard } from './StockMarketConfigCard.tsx'
import { StockMarketSettings } from './StockMarketSettings.tsx'
import { StockMarketSideCard } from './StockMarketSideCard.tsx'
import { createStockMarketSideCardStore } from './StockMarketSideCardState.ts'
import { loadStockToolAccess, setStockToolAccess } from './StockToolAccess.ts'
import { StockToolToggle, type StockToolToggleInjected } from './StockToolToggle.tsx'
import { loadStockMarketConfig } from './plugin-config.ts'

export const inject = ['slots', 'connection', 'sessions']

const STOCK_MARKET_PLUGIN_ID = 'dsh-stock-market'
const STOCK_MARKET_CSS_REGISTRY_KEY = Symbol.for(`${STOCK_MARKET_PLUGIN_ID}/css`)

type GlobalCssRegistry = { [key: symbol]: unknown }

function installStockMarketStyles(): () => void {
  if (typeof document === 'undefined') return () => undefined
  const registry = (globalThis as unknown as GlobalCssRegistry)[STOCK_MARKET_CSS_REGISTRY_KEY]
  if (registry instanceof Map) {
    for (const [tagId, css] of registry) {
      if (typeof tagId !== 'string' || typeof css !== 'string') continue
      let tag = [...document.querySelectorAll<HTMLStyleElement>('style[data-plugin-css]')]
        .find(candidate => candidate.dataset.pluginCss === tagId)
      if (tag === undefined) {
        tag = document.createElement('style')
        tag.dataset.plugin = STOCK_MARKET_PLUGIN_ID
        tag.dataset.pluginCss = tagId
        document.head.appendChild(tag)
      }
      tag.textContent = css
    }
  }
  return () => {
    for (const tag of document.querySelectorAll(`style[data-plugin="${STOCK_MARKET_PLUGIN_ID}"]`)) tag.remove()
  }
}

class StockMarketSideCardBoundary extends Component<{ children: ReactNode }, { error: string | undefined }> {
  state: { error: string | undefined } = { error: undefined }

  static getDerivedStateFromError(error: unknown): { error: string } {
    return { error: error instanceof Error ? error.message : String(error) }
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    console.error('[dsh-stock-market] side card render failed:', error, info.componentStack)
  }

  render(): ReactNode {
    if (this.state.error !== undefined) {
      return createElement('div', { role: 'alert' }, '行情侧栏无法加载：', this.state.error)
    }
    return this.props.children
  }
}

export function apply(ctx: ClientContext): void {
  const connection = ctx.get('connection') as unknown as ConnectionHandle
  const configRef: { current: StockMarketPluginConfig } = { current: { ...STOCK_MARKET_DEFAULT_CONFIG } }
  const disposers: Array<() => void> = []

  ctx.effect(() => installStockMarketStyles(), 'dsh-stock-market: inline styles')

  // The config card is always registered, even while the plugin is disabled.
  // It is the only UI path back to re-enabling the plugin.
  disposers.push(ctx.slots.inject('settings.plugin.item', () => ctx.slots.register({
    name: 'settings.plugin.item',
    id: 'stock-market',
    order: 30,
    inject: () => ({
      connection,
      onConfigApplied: (applied: StockMarketPluginConfig) => { configRef.current = applied },
    }),
  }, StockMarketConfigCard)))

  void loadStockMarketConfig(connection).then((config) => {
    configRef.current = config

    if (!config.enabled) return

    const store = createStockMarketSideCardStore(() => configRef.current.sidebarOpenByDefault)

    ctx.effect(() => {
      let root: Root | undefined
      const host = document.createElement('div')
      host.setAttribute('data-dsh-stock-market-sidebar', '')
      document.body.appendChild(host)
      root = createRoot(host)
      root.render(createElement(
        StockMarketSideCardBoundary,
        null,
        createElement(StockMarketSideCard, { ctx, connection, store }),
      ))

      return () => {
        root?.unmount()
        host.remove()
      }
    }, 'dsh-stock-market: side card mount')

    disposers.push(ctx.slots.inject('conversation.input.left', () => ctx.slots.register({
      name: 'conversation.input.left',
      id: 'stock-tool-access',
      order: 30,
      inject: (sessionId: SessionId): StockToolToggleInjected => ({
        load: signal => loadStockToolAccess(connection, sessionId, signal),
        setEnabled: (enabled, signal) => setStockToolAccess(connection, sessionId, enabled, signal),
      }),
    }, StockToolToggle)))

    disposers.push(ctx.slots.inject('settings.section', () => ctx.slots.register({
      name: 'settings.section',
      id: 'stock-market',
      order: 40,
      label: () => '行情',
      inject: () => ({}),
    }, StockMarketSettings)))
  })

  ctx.effect(() => () => {
    for (const dispose of disposers) dispose()
  }, 'dsh-stock-market: ui disposal')
}
