import { useCallback, useEffect, useLayoutEffect, useRef, useState, useSyncExternalStore } from 'react'
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type { StockMarketBreadth } from '../rpc-contract.ts'
import {
  IconPanelLeftOutline16,
  Tooltip,
} from '@deepseek-ai/dsh-client-ui-primitives'
import { MarketIndexTicker } from './MarketIndexTicker.tsx'
import { StockMarketView } from './StockMarketView.tsx'
import {
  type StockMarketSideCardStore,
  STOCK_MARKET_SIDECARD_OVERLAY_MAX_VIEWPORT_WIDTH,
  STOCK_MARKET_SIDECARD_SESSION_MIN_WIDTH,
  STOCK_MARKET_SIDECARD_WIDTH_MAX,
  STOCK_MARKET_SIDECARD_WIDTH_MIN,
} from './StockMarketSideCardState.ts'
import css from './StockMarketSideCard.module.css'

export interface StockMarketSideCardProps {
  ctx: ClientContext
  connection: ConnectionHandle
  store: StockMarketSideCardStore
}

interface ResizeDragState {
  active: boolean
  startX: number
  startWidth: number
  pendingWidth: number | undefined
  frame: number | undefined
}

export function StockMarketSideCard({ ctx, connection, store }: StockMarketSideCardProps) {
  const sessionsService = sessionsOf(ctx)
  const sessions = useSyncExternalStore(
    useCallback((listener: () => void) => sessionsService.list.subscribe(listener), [sessionsService]),
    useCallback(() => sessionsService.list.getSnapshot(), [sessionsService]),
  )
  const snapshot = useSyncExternalStore(
    useCallback((listener: () => void) => store.subscribe(listener), [store]),
    useCallback(() => store.getSnapshot(), [store]),
  )
  const viewportWidth = useViewportWidth()
  const hostSidebarWidth = useHostSidebarWidth()
  const drag = useRef<ResizeDragState>({
    active: false,
    startX: 0,
    startWidth: 0,
    pendingWidth: undefined,
    frame: undefined,
  })
  const [dragging, setDragging] = useState(false)
  const [marketBreadth, setMarketBreadth] = useState<StockMarketBreadth>()

  useEffect(() => {
    store.setSession(sessions.current === undefined ? undefined : String(sessions.current))
  }, [sessions.current, store])

  const state = snapshot.state
  const hasSession = snapshot.sessionId !== undefined && state !== undefined
  const availableWidth = Math.max(0, viewportWidth - hostSidebarWidth)
  const canCompressLayout = availableWidth > STOCK_MARKET_SIDECARD_OVERLAY_MAX_VIEWPORT_WIDTH
  // Reserve enough room for the host composer when both panes are visible.
  // Below that boundary the market card becomes an overlay of the available area.
  const maxResizableWidth = canCompressLayout
    ? Math.min(
      STOCK_MARKET_SIDECARD_WIDTH_MAX,
      Math.max(STOCK_MARKET_SIDECARD_WIDTH_MIN, availableWidth - STOCK_MARKET_SIDECARD_SESSION_MIN_WIDTH),
    )
    : STOCK_MARKET_SIDECARD_WIDTH_MIN
  const canResize = state !== undefined && state.panelOpen && canCompressLayout
  const panelWidth = hasSession
    ? canCompressLayout
      ? Math.min(state.width, maxResizableWidth)
      : availableWidth
    : 0
  const pushesLayout = hasSession && state.panelOpen && canCompressLayout
  const layoutWidth = pushesLayout ? panelWidth : 0

  useLayoutEffect(() => {
    document.documentElement.style.setProperty('--dsh-stock-market-sidebar-width', `${layoutWidth}px`)
  }, [layoutWidth])

  useEffect(() => {
    return () => { document.documentElement.style.removeProperty('--dsh-stock-market-sidebar-width') }
  }, [])

  useEffect(() => {
    return () => {
      if (drag.current.frame !== undefined) cancelFrame(drag.current.frame)
    }
  }, [])

  useEffect(() => {
    if (canResize || !drag.current.active) return
    finishResize(store, drag.current)
    setDragging(false)
  }, [canResize, store])

  useEffect(() => {
    if (dragging) document.body.setAttribute('data-dsh-stock-market-sidebar-dragging', '')
    else document.body.removeAttribute('data-dsh-stock-market-sidebar-dragging')
    return () => { document.body.removeAttribute('data-dsh-stock-market-sidebar-dragging') }
  }, [dragging])

  if (!hasSession || state === undefined) {
    return (
      <div className={css.toggleRail}>
        <Tooltip label="请选择会话后打开行情" side="top" delayMs={500}>
          <button type="button" className={css.toggleButton} aria-label="请选择会话后打开行情" disabled>
            <IconPanelLeftOutline16 size={16} />
          </button>
        </Tooltip>
      </div>
    )
  }

  return (
    <>
      <MarketIndexTicker
        connection={connection}
        panelOpen={state.panelOpen}
        breadth={marketBreadth}
        onToggle={() => {
          store.reduce(current => ({ ...current, panelOpen: !current.panelOpen }))
        }}
      />
      <aside
        id="stock-market-side-card"
        className={`${css.panel} ${!state.panelOpen ? css.panelHidden : ''}`}
        style={{ width: panelWidth }}
        aria-label="A 股行情侧栏"
        aria-hidden={!state.panelOpen}
      >
        {canResize && <div
          className={`${css.resizeHandle} ${dragging ? css.resizeHandleActive : ''}`}
          role="separator"
          aria-label="调整行情侧栏宽度"
          aria-orientation="vertical"
          aria-valuemin={STOCK_MARKET_SIDECARD_WIDTH_MIN}
          aria-valuemax={maxResizableWidth}
          aria-valuenow={panelWidth}
          tabIndex={0}
          onKeyDown={(event) => {
            const width = keyboardResizeWidth(event.key, panelWidth, maxResizableWidth)
            if (width === undefined) return
            event.preventDefault()
            store.reduce(current => ({ ...current, width }))
          }}
          onPointerDown={(event) => {
            event.preventDefault()
            event.currentTarget.setPointerCapture(event.pointerId)
            drag.current = {
              active: true,
              startX: event.clientX,
              startWidth: panelWidth,
              pendingWidth: undefined,
              frame: undefined,
            }
            setDragging(true)
          }}
          onPointerMove={(event) => {
            if (!event.currentTarget.hasPointerCapture(event.pointerId)) return
            const width = constrainResizeWidth(
              drag.current.startWidth + drag.current.startX - event.clientX,
              maxResizableWidth,
            )
            queueResize(store, drag.current, width)
          }}
          onPointerUp={(event) => {
            if (!event.currentTarget.hasPointerCapture(event.pointerId)) return
            event.currentTarget.releasePointerCapture(event.pointerId)
            finishResize(store, drag.current)
            setDragging(false)
          }}
          onPointerCancel={(event) => {
            if (event.currentTarget.hasPointerCapture(event.pointerId)) {
              event.currentTarget.releasePointerCapture(event.pointerId)
            }
            finishResize(store, drag.current)
            setDragging(false)
          }}
          onLostPointerCapture={() => {
            finishResize(store, drag.current)
            setDragging(false)
          }}
        />}
        <StockMarketView
          connection={connection}
          visible={state.panelOpen}
          onBreadthChange={setMarketBreadth}
        />
      </aside>
    </>
  )
}

interface SessionsView {
  list: {
    subscribe(listener: () => void): () => void
    getSnapshot(): { current: unknown }
  }
}

function sessionsOf(ctx: ClientContext): SessionsView {
  const context = ctx as unknown as {
    get?: (name: string) => unknown
    sessions?: unknown
  }
  const sessions = context.get?.('sessions') ?? context.sessions
  if (typeof sessions !== 'object' || sessions === null || !Object.hasOwn(sessions, 'list')) {
    throw new Error('DSH 会话服务不可用。')
  }
  return sessions as SessionsView
}

function useViewportWidth(): number {
  const [width, setWidth] = useState(() => window.innerWidth)

  useEffect(() => {
    const onResize = (): void => { setWidth(window.innerWidth) }
    window.addEventListener('resize', onResize)
    return () => { window.removeEventListener('resize', onResize) }
  }, [])

  return Math.max(0, width)
}

function useHostSidebarWidth(): number {
  const [width, setWidth] = useState(readHostSidebarWidth)

  useEffect(() => {
    const update = (): void => { setWidth(readHostSidebarWidth()) }
    const observer = typeof MutationObserver === 'function'
      ? new MutationObserver(update)
      : undefined
    observer?.observe(document.documentElement, { attributes: true, attributeFilter: ['class', 'style'] })
    window.addEventListener('resize', update)
    return () => {
      observer?.disconnect()
      window.removeEventListener('resize', update)
    }
  }, [])

  return width
}

function readHostSidebarWidth(): number {
  const value = Number.parseFloat(
    window.getComputedStyle(document.documentElement).getPropertyValue('--dsh-sidebar-width'),
  )
  return Number.isFinite(value) ? Math.max(0, value) : 0
}

function keyboardResizeWidth(key: string, currentWidth: number, maximum: number): number | undefined {
  if (key === 'Home') return STOCK_MARKET_SIDECARD_WIDTH_MIN
  if (key === 'End') return maximum
  if (key === 'ArrowLeft') return constrainResizeWidth(currentWidth - 20, maximum)
  if (key === 'ArrowRight') return constrainResizeWidth(currentWidth + 20, maximum)
  return undefined
}

function constrainResizeWidth(width: number, maximum: number): number {
  return Math.min(maximum, Math.max(STOCK_MARKET_SIDECARD_WIDTH_MIN, width))
}

function queueResize(store: StockMarketSideCardStore, drag: ResizeDragState, width: number): void {
  drag.pendingWidth = width
  if (drag.frame !== undefined) return
  drag.frame = requestFrame(() => {
    drag.frame = undefined
    const pendingWidth = drag.pendingWidth
    drag.pendingWidth = undefined
    if (pendingWidth !== undefined) {
      store.reduce(current => ({ ...current, width: pendingWidth }), { persist: false })
    }
  })
}

function finishResize(store: StockMarketSideCardStore, drag: ResizeDragState): void {
  if (!drag.active) return
  drag.active = false
  if (drag.frame !== undefined) {
    cancelFrame(drag.frame)
    drag.frame = undefined
  }
  const pendingWidth = drag.pendingWidth
  drag.pendingWidth = undefined
  if (pendingWidth !== undefined) {
    store.reduce(current => ({ ...current, width: pendingWidth }), { persist: false })
  }
  store.persist()
}

function requestFrame(callback: () => void): number {
  return typeof window.requestAnimationFrame === 'function'
    ? window.requestAnimationFrame(callback)
    : window.setTimeout(callback, 16)
}

function cancelFrame(frame: number): void {
  if (typeof window.cancelAnimationFrame === 'function') window.cancelAnimationFrame(frame)
  else window.clearTimeout(frame)
}
