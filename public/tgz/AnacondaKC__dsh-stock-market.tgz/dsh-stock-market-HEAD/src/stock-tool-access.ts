import type { Context } from '@deepseek-ai/cordis'
import type { ToolExecution } from '@deepseek-ai/dsh-tools'
import { STOCK_AGENT_TOOL_NAMES } from './stock-agent-contract.ts'

export const STOCK_TOOL_NAMES = STOCK_AGENT_TOOL_NAMES

export const STOCK_TOOL_ACCESS_EVENT = 'stock-market/tool-access'

const STOCK_TOOL_NAME_SET = new Set<string>(STOCK_TOOL_NAMES)
const DISABLED_REASON = '当前会话已关闭股票工具调用，请先在输入框中开启。'

type StockAgent = NonNullable<ToolExecution['agent']>
type StockSessionEvent = {
  readonly type: string
  readonly data?: unknown
}

interface AgentRegistryView {
  get(id: string): StockAgent | undefined
  list(): readonly StockAgent[]
}

type ContextWithAgents = Omit<Context, 'agents'> & {
  agents: AgentRegistryView
}

/** Last logged stock-tool choice wins; sessions without any event fall back to the configured default. */
export function foldStockToolAccess(events: readonly StockSessionEvent[], defaultEnabled = true): boolean {
  for (let index = events.length - 1; index >= 0; index--) {
    const event = events[index]
    if (event.type !== STOCK_TOOL_ACCESS_EVENT || !isRecord(event.data)) continue
    if (typeof event.data.enabled === 'boolean') return event.data.enabled
  }
  return defaultEnabled
}

/** Owns durable per-session state, model-visible tool filtering, and final execution denial. */
export class StockToolAccessService {
  private readonly restrictions = new Map<StockAgent, () => void>()

  constructor(
    private readonly ctx: ContextWithAgents,
    private readonly defaultEnabled = true,
  ) {
    ctx.effect(() => () => { this.disposeRestrictions() }, 'dsh-stock-market: tool restrictions')
    for (const agent of ctx.agents.list()) this.syncRestriction(agent)

    ctx.on('agent/created', ({ agent }) => { this.syncRestriction(agent) })
    ctx.on('agent/disposed', ({ agent }) => { this.liftRestriction(agent) })
    ctx.on('tools/pre-execute', async (exec, next) => {
      const reason = this.guardReason(exec)
      return reason === undefined ? next() : { kind: 'deny', reason }
    })
    ctx.tools.guard(exec => this.guardReason(exec))
  }

  getBySessionId(sessionId: string): boolean {
    const agent = this.requireAgent(sessionId)
    this.syncRestriction(agent)
    return foldStockToolAccess(agent.session.events, this.defaultEnabled)
  }

  setBySessionId(sessionId: string, enabled: boolean): boolean {
    const agent = this.requireAgent(sessionId)
    const current = foldStockToolAccess(agent.session.events, this.defaultEnabled)
    if (current === enabled) {
      this.syncRestriction(agent)
      return current
    }

    if (!enabled) {
      const installed = this.installRestriction(agent)
      try {
        appendAccessEvent(agent, false)
      } catch (error) {
        if (installed) this.liftRestriction(agent)
        throw error
      }
      return false
    }

    appendAccessEvent(agent, true)
    this.liftRestriction(agent)
    return true
  }

  private requireAgent(sessionId: string): StockAgent {
    const agent = this.ctx.agents.get(sessionId)
    if (agent === undefined || agent.session.id !== sessionId) {
      throw new Error(`会话不存在或当前不可用：${sessionId}。`)
    }
    return agent
  }

  private syncRestriction(agent: StockAgent): void {
    if (foldStockToolAccess(agent.session.events, this.defaultEnabled)) this.liftRestriction(agent)
    else this.installRestriction(agent)
  }

  private installRestriction(agent: StockAgent): boolean {
    if (this.restrictions.has(agent)) return false
    const dispose = agent.ctx.tools.restrict({ deny: STOCK_TOOL_NAMES })
    this.restrictions.set(agent, dispose)
    return true
  }

  private liftRestriction(agent: StockAgent): void {
    const dispose = this.restrictions.get(agent)
    if (dispose === undefined) return
    this.restrictions.delete(agent)
    dispose()
  }

  private disposeRestrictions(): void {
    const errors: unknown[] = []
    for (const [agent, dispose] of [...this.restrictions]) {
      this.restrictions.delete(agent)
      try {
        dispose()
      } catch (error) {
        errors.push(error)
      }
    }
    if (errors.length > 0) throw new AggregateError(errors, '股票工具限制清理失败。')
  }

  private guardReason(exec: Readonly<ToolExecution>): string | undefined {
    if (!STOCK_TOOL_NAME_SET.has(exec.name) || exec.agent === undefined) return undefined
    return foldStockToolAccess(exec.agent.session.events, this.defaultEnabled) ? undefined : DISABLED_REASON
  }
}

function appendAccessEvent(agent: StockAgent, enabled: boolean): void {
  const session = agent.session as unknown as {
    append(type: string, data: { enabled: boolean }): unknown
  }
  session.append(STOCK_TOOL_ACCESS_EVENT, { enabled })
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}
