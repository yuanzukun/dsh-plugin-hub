import {
  defineTool,
  type ToolDefinition,
} from '@deepseek-ai/dsh-tools'
import type { Context } from '@deepseek-ai/cordis'
import { STOCK_AGENT_TOOL_NAMES } from './stock-agent-contract.ts'
import { StockAgentService } from './stock-agent-service.ts'
import type { StockApiService } from './stock-api/service.ts'

const SOURCES = ['auto', 'eastmoney', 'tencent', 'sina', 'tonghuashun'] as const
const MAX_TOOL_OUTPUT_CHARACTERS = 64_000

export function registerStockMarketTools(ctx: Context, service: StockApiService): void {
  for (const tool of createStockMarketTools(service)) ctx.tools.register(tool)
}

export function createStockMarketTools(service: StockApiService): ToolDefinition[] {
  const agent = new StockAgentService(service)
  return [
    defineTool({
      name: 'stock_quote',
      description: '查询沪深 A 股实时行情快照。证券代码统一使用 600519.SH 或 000001.SZ；默认自动选择并切换免费数据源。',
      parameters: {
        action: { type: 'string', required: true, enum: ['snapshot'], description: '固定为 snapshot。' },
        symbols: { type: 'array', required: true, items: { type: 'string' }, description: '证券代码数组，最多 60 个；full 最多 20 个。' },
        detail: { type: 'string', enum: ['basic', 'full'], description: 'basic 返回核心价格；full 增加开高低、成交量额和换手率。默认 basic。' },
        source: sourceSchema(),
      },
      output: jsonOutput(),
      timeoutMs: 25_000,
      isConcurrencySafe: () => true,
      execute: async (args, exec) => stringify(await agent.execute('stock_quote', args, exec.signal)),
    }),
    defineTool({
      name: 'stock_chart',
      description: '查询标准化 K 线或分时走势。action=kline 使用周期和复权参数；action=intraday 使用 days。默认自动故障切换。',
      parameters: {
        action: { type: 'string', required: true, enum: ['kline', 'intraday'], description: 'kline 或 intraday。' },
        symbol: symbolSchema(),
        period: { type: 'string', enum: ['1m', '5m', '15m', '30m', '60m', 'day', 'week', 'month'], description: 'K 线周期，默认 day；仅 kline。' },
        adjust: { type: 'string', enum: ['none', 'qfq', 'hfq'], description: '不复权、前复权或后复权，默认 qfq；仅 kline。' },
        start_date: { type: 'string', description: '开始日期 yyyy-MM-dd；仅 kline。' },
        end_date: { type: 'string', description: '结束日期 yyyy-MM-dd；仅 kline。' },
        days: { type: 'integer', enum: [1, 5], description: '1 日或 5 日；仅 intraday，默认 1。' },
        limit: { type: 'integer', description: '返回完整记录数，1 到 300。' },
        source: sourceSchema(),
      },
      output: jsonOutput(),
      timeoutMs: 25_000,
      isConcurrencySafe: () => true,
      execute: async (args, exec) => stringify(await agent.execute('stock_chart', args, exec.signal)),
    }),
    defineTool({
      name: 'stock_ranking',
      description: '查询个股排行、行业/概念板块排行、板块成分或板块目录。sector_catalog 仅使用 sector_type/source，不接受 page/limit。不同数据源排行口径不同时会标记 degraded。',
      parameters: {
        action: { type: 'string', required: true, enum: ['stocks', 'sectors', 'sector_members', 'sector_catalog'], description: '排行操作。' },
        market: { type: 'string', enum: ['all_a', 'sh_a', 'sz_a', 'chinext', 'star'], description: '沪深 A 股市场；仅 stocks。' },
        sector_type: { type: 'string', enum: ['industry', 'concept'], description: '行业或概念；用于 sectors/sector_catalog。' },
        sector_id: { type: 'string', description: '新浪板块 ID；仅 sector_members。' },
        sort: { type: 'string', enum: ['price', 'change_percent', 'volume', 'amount', 'turnover_rate', 'net_inflow'], description: '排序指标。' },
        order: orderSchema(),
        page: pageSchema(),
        limit: pageSizeSchema(),
        source: sourceSchema(),
      },
      output: jsonOutput(),
      timeoutMs: 25_000,
      isConcurrencySafe: () => true,
      execute: async (args, exec) => stringify(await agent.execute('stock_ranking', args, exec.signal)),
    }),
    defineTool({
      name: 'stock_money_flow',
      description: '查询个股历史/实时资金流、行业/概念资金流或沪深港通资金流。connect 的现行公开源仅稳定提供南向分钟净流入，北向缺失会列入 unavailable_directions；口径不等价的备用源会标记 degraded。',
      parameters: {
        action: { type: 'string', required: true, enum: ['stock_history', 'stock_intraday', 'sector', 'connect'], description: '资金流操作。' },
        symbol: symbolSchema(),
        sector_type: { type: 'string', enum: ['industry', 'concept'], description: '行业或概念；仅 sector。' },
        direction: { type: 'string', enum: ['all', 'northbound', 'southbound'], description: '沪深港通方向；仅 connect。默认 all；北向分钟净流入目前由上游停止提供。' },
        page: pageSchema(),
        limit: { type: 'integer', description: '返回记录数，列表最多 50，时间序列最多 300。' },
        source: sourceSchema(),
      },
      output: jsonOutput(),
      timeoutMs: 25_000,
      isConcurrencySafe: () => true,
      execute: async (args, exec) => stringify(await agent.execute('stock_money_flow', args, exec.signal)),
    }),
    defineTool({
      name: 'stock_fundamentals',
      description: '查询沪深 A 股公司概况、财务、股东、估值和经营指标。该工具使用东方财富免费 F10 数据。',
      parameters: {
        action: { type: 'string', required: true, enum: ['profile', 'financials', 'shareholders', 'valuation', 'operating_indicators'], description: '基本面操作。' },
        symbol: symbolSchema(),
        sections: { type: 'array', items: { type: 'string', enum: ['company', 'themes', 'industry'] }, description: 'profile 返回章节，默认全部。' },
        mode: { type: 'string', enum: ['latest', 'quarterly'], description: 'financials 数据模式，默认 latest。' },
        page: pageSchema(),
        limit: pageSizeSchema(),
      },
      output: jsonOutput(),
      timeoutMs: 25_000,
      isConcurrencySafe: () => true,
      execute: async (args, exec) => stringify(await agent.execute('stock_fundamentals', args, exec.signal)),
    }),
    defineTool({
      name: 'stock_events',
      description: '查询沪深 A 股公告、大宗交易、融资融券、龙虎榜、财经日历和可转债。scope 决定个股或全市场。',
      parameters: {
        action: { type: 'string', required: true, enum: ['announcements', 'block_trades', 'margin', 'dragon_tiger', 'economic_calendar', 'convertible_bonds'], description: '事件操作。' },
        scope: { type: 'string', enum: ['stock', 'market'], description: '个股或全市场；用于 margin/dragon_tiger。' },
        symbol: symbolSchema(),
        include_departments: { type: 'boolean', description: '个股龙虎榜是否同时查询营业部明细。' },
        page: pageSchema(),
        limit: pageSizeSchema(),
        source: sourceSchema(),
      },
      output: jsonOutput(),
      timeoutMs: 25_000,
      isConcurrencySafe: () => true,
      execute: async (args, exec) => stringify(await agent.execute('stock_events', args, exec.signal)),
    }),
    defineTool({
      name: 'stock_research',
      description: '查询沪深 A 股市场研报、个股研报、盈利预测和评级统计。列表使用 page/limit，正文按 report_id 单篇读取。',
      parameters: {
        action: { type: 'string', required: true, enum: ['market_reports', 'stock_reports', 'forecast', 'ratings'], description: '研究数据操作。' },
        symbol: symbolSchema(),
        category: { type: 'string', enum: ['strategy', 'macro', 'broker', 'industry'], description: '市场研报类别。' },
        days: { type: 'integer', description: '市场研报自然日范围，0 到 30。' },
        top: { type: 'integer', description: '附正文摘要篇数，1 到 10。' },
        index: { type: 'integer', description: '读取市场研报列表第 N 篇。' },
        mode: { type: 'string', enum: ['summary', 'institutions'], description: '盈利预测汇总或机构明细。' },
        content: { type: 'string', enum: ['summary', 'full'], description: '个股研报摘要或单篇正文。' },
        report_id: { type: 'string', description: 'content=full 时必填的研报编号。' },
        page: pageSchema(),
        limit: pageSizeSchema(),
      },
      output: jsonOutput(),
      timeoutMs: 25_000,
      isConcurrencySafe: () => true,
      execute: async (args, exec) => stringify(await agent.execute('stock_research', args, exec.signal)),
    }),
    defineTool({
      name: 'stock_news',
      description: '查询财经资讯流、个股新闻、全文搜索或股吧内容。guba 的 mode=search 必须使用 keyword，可用 page/limit，不接受 symbol；mode=stock_page 必须使用 symbol，不接受 keyword/page/limit。HTML 备用源会转为有长度上限的纯文本并标记 degraded。',
      parameters: {
        action: { type: 'string', required: true, enum: ['feed', 'stock_news', 'search', 'guba'], description: '资讯操作。' },
        feed: { type: 'string', enum: ['headlines', 'flash', 'finance', 'global', 'stocks', 'money'], description: '资讯流类型。' },
        symbol: symbolSchema(),
        keyword: { type: 'string', description: '搜索关键词；guba 仅 mode=search 使用。' },
        scope: { type: 'string', enum: ['news', 'stock', 'fund', 'guba'], description: '搜索范围。' },
        mode: { type: 'string', enum: ['search', 'stock_page'], description: '股吧模式；search 使用 keyword/page/limit，stock_page 仅使用 symbol。' },
        page: pageSchema(),
        limit: pageSizeSchema(),
        source: sourceSchema(),
      },
      output: jsonOutput(),
      timeoutMs: 25_000,
      isConcurrencySafe: () => true,
      execute: async (args, exec) => stringify(await agent.execute('stock_news', args, exec.signal)),
    }),
    defineTool({
      name: 'stock_capabilities',
      description: '查询 9 个业务股票工具的动作、参数和免费数据源切换口径；不暴露或执行内部 endpoint_id。',
      parameters: {
        action: { type: 'string', required: true, enum: ['list', 'describe', 'sources'], description: '发现操作。' },
        tool: { type: 'string', enum: STOCK_AGENT_TOOL_NAMES, description: '业务工具名。describe/sources 必填。' },
        target_action: { type: 'string', description: '目标业务动作；sources 必填。' },
      },
      output: jsonOutput(),
      timeoutMs: 5_000,
      isConcurrencySafe: () => true,
      execute: async args => stringify(await agent.execute('stock_capabilities', args, new AbortController().signal)),
    }),
  ]
}

function sourceSchema() {
  return {
    type: 'string' as const,
    enum: SOURCES,
    description: '默认 auto；仅在诊断时固定免费数据源。若该动作或参数不支持指定源会拒绝。',
  }
}

function symbolSchema() {
  return {
    type: 'string' as const,
    description: '标准沪深 A 股代码，如 600519.SH 或 000001.SZ。',
  }
}

function pageSchema() {
  return { type: 'integer' as const, description: '页码，从 1 开始，默认 1，最多 100。' }
}

function pageSizeSchema() {
  return { type: 'integer' as const, description: '每页完整记录数，默认按动作确定，最多 50。' }
}

function orderSchema() {
  return { type: 'string' as const, enum: ['asc', 'desc'] as const, description: '升序或降序，默认 desc。' }
}

function jsonOutput() {
  return {
    schema: { type: 'string' as const },
    render: (_args: unknown, value: string) => [{ type: 'text' as const, text: value }],
  }
}

function stringify(value: unknown): string {
  const serialized = JSON.stringify(value)
  if (serialized.length <= MAX_TOOL_OUTPUT_CHARACTERS) return serialized

  const record = isRecord(value) ? value : {}
  const warnings = Array.isArray(record.warnings)
    ? record.warnings.filter((item): item is string => typeof item === 'string').slice(0, 10)
    : []
  const bounded = JSON.stringify({
    ...record,
    data: {
      omitted: true,
      reason: '响应超过工具 64k 字符上限，请减小 limit、缩小日期范围或按页查询。',
    },
    warnings: [...warnings, '完整数据因工具输出上限被省略。'],
    output_truncated: true,
    original_characters: serialized.length,
  })
  if (bounded.length <= MAX_TOOL_OUTPUT_CHARACTERS) return bounded
  return JSON.stringify({
    output_truncated: true,
    original_characters: serialized.length,
    error: '响应超过工具 64k 字符上限，请缩小查询范围。',
  })
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}
