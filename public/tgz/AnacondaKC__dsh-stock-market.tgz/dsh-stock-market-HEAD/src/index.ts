import type {} from '@deepseek-ai/dsh-client-connection'
import type {} from '@deepseek-ai/dsh-tools'
import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { registerStockMarketConfig } from './plugin-config-service.ts'
import { registerStockMarketRpc } from './rpc.ts'
import type { StockMarketPluginConfig } from './rpc-contract.ts'
import { StockApiService } from './stock-api/service.ts'
import { StockToolAccessService } from './stock-tool-access.ts'
import { registerStockMarketTools } from './stock-tools.ts'

export const name = 'dsh-stock-market'
export const inject = ['agents', 'connection', 'tools']

export const Config: z<StockMarketPluginConfig> = z.object({
  enabled: z.boolean().default(true),
  sidebarOpenByDefault: z.boolean().default(true),
  toolsEnabledByDefault: z.boolean().default(true),
})

export function apply(ctx: Context, config: StockMarketPluginConfig): void {
  ctx.inject(['settings'], (settingsCtx) => {
    const configScope = registerStockMarketConfig(settingsCtx.settings, config)
    const effective = configScope.get()

    // The RPC channel is always mounted so the browser config card stays
    // reachable while the plugin is disabled — otherwise the master switch
    // would lock the plugin off with no UI path back (only YAML edits).
    const stockApi = new StockApiService()
    let toolAccess: StockToolAccessService | undefined
    if (effective.enabled) {
      registerStockMarketTools(ctx, stockApi)
      toolAccess = new StockToolAccessService(ctx as never, effective.toolsEnabledByDefault)
    }
    ctx.effect(() => registerStockMarketRpc(ctx.connection, {
      stockApiService: stockApi,
      toolAccess,
      config,
      configScope,
      enabled: effective.enabled,
    }), 'dsh-stock-market: RPC channel')
  })
}
