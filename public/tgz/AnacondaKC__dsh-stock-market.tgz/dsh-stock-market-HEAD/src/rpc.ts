import type {
  ConnectionRpcHandler,
  HostConnectionHandle,
} from '@deepseek-ai/dsh-client-connection'
import {
  STOCK_MARKET_BREADTH_ENDPOINT,
  STOCK_MARKET_CONFIG_ENDPOINT,
  STOCK_MARKET_FLASH_NEWS_ENDPOINT,
  STOCK_MARKET_GLOBAL_ASSETS,
  STOCK_MARKET_GLOBAL_QUOTES_ENDPOINT,
  STOCK_MARKET_HEADLINES_ENDPOINT,
  STOCK_MARKET_DEFAULT_CONFIG,
  STOCK_MARKET_HEALTH_ENDPOINT,
  STOCK_MARKET_HOTSPOTS_ENDPOINT,
  STOCK_MARKET_HOTSPOT_GROUPS,
  STOCK_MARKET_HOTSPOT_SUMMARY_LIMIT,
  STOCK_MARKET_INDICES,
  STOCK_MARKET_INDICES_ENDPOINT,
  STOCK_MARKET_MOVERS_ENDPOINT,
  STOCK_MARKET_NEWS_SUMMARY_LIMIT,
  STOCK_MARKET_RANKINGS,
  STOCK_MARKET_RANKING_SUMMARY_LIMIT,
  STOCK_MARKET_RPC_CHANNEL,
  STOCK_MARKET_RPC_PROTOCOL_VERSION,
  STOCK_MARKET_SET_CONFIG_ENDPOINT,
  STOCK_MARKET_SET_TOOL_ACCESS_ENDPOINT,
  STOCK_MARKET_TOOL_ACCESS_ENDPOINT,
  STOCK_MARKET_TRENDS_ENDPOINT,
  STOCK_MARKET_TREND_POINT_LIMIT,
  STOCK_MARKET_TURNOVER_ENDPOINT,
  isStockMarketBreadthRequest,
  isStockMarketGlobalQuotesRequest,
  isStockMarketConfigRequest,
  isStockMarketConfigResponse,
  isStockMarketHealthRequest,
  isStockMarketHotspotsRequest,
  isStockMarketIndicesRequest,
  isStockMarketMoversRequest,
  isStockMarketNewsRequest,
  isStockMarketSetConfigRequest,
  isStockMarketSetConfigResponse,
  isStockMarketSetToolAccessRequest,
  isStockMarketToolAccessRequest,
  isStockMarketTrendsRequest,
  isStockMarketTurnoverRequest,
  type StockMarketBreadth,
  type StockMarketBreadthResponse,
  type StockMarketGlobalAssetId,
  type StockMarketGlobalQuote,
  type StockMarketGlobalQuotesResponse,
  type StockMarketHotspotGroupId,
  type StockMarketHotspotGroups,
  type StockMarketHotspotQuote,
  type StockMarketHotspotsResponse,
  type StockMarketIndexId,
  type StockMarketIndexQuote,
  type StockMarketIndexTrend,
  type StockMarketIndicesResponse,
  type StockMarketMoverLists,
  type StockMarketMoverQuote,
  type StockMarketMoversResponse,
  type StockMarketNewsItem,
  type StockMarketNewsResponse,
  type StockMarketPluginConfig,
  type StockMarketRankingId,
  type StockMarketTradingStatus,
  type StockMarketTrendPoint,
  type StockMarketTrendsResponse,
  type StockMarketTurnoverResponse,
} from './rpc-contract.ts'

import type { StockToolAccessService } from './stock-tool-access.ts'

import type { SettingsScope } from '@deepseek-ai/dsh-settings'

import {
  StockApiError,
  StockApiService,
} from './stock-api/service.ts'

const TENCENT_INDICES_CACHE_TTL_MS = 5_000
const SINA_GLOBAL_QUOTES_CACHE_TTL_MS = 10_000
const TENCENT_TURNOVER_CACHE_TTL_MS = 10_000
const EASTMONEY_BREADTH_CACHE_TTL_MS = 30_000
const EASTMONEY_TRENDS_CACHE_TTL_MS = 30_000
const EASTMONEY_MOVERS_CACHE_TTL_MS = 30_000
const EASTMONEY_HOTSPOTS_CACHE_TTL_MS = 60_000
const TENCENT_INDEX_CODES: Record<StockMarketIndexId, string> = {
  sse: 'sh000001',
  szse: 'sz399001',
  chinext: 'sz399006',
  star50: 'sh000680',
}
const SINA_GLOBAL_ASSET_SYMBOLS: Record<StockMarketGlobalAssetId, string> = {
  sse: 'sh000001',
  hangSeng: 'int_hangseng',
  nasdaq: 'int_nasdaq',
  kospi: 'b_KOSPI',
  nikkei: 'b_NKY',
  brent: 'hf_OIL',
  newYorkGold: 'hf_GC',
}
const TENCENT_TURNOVER_CODES = ['sh000001', 'sz399106'] as const
const EASTMONEY_INDEX_SECIDS: Record<StockMarketIndexId, string> = {
  sse: '1.000001',
  szse: '0.399001',
  chinext: '0.399006',
  star50: '1.000680',
}
const EASTMONEY_BREADTH_SECIDS = '1.000001,0.399001'
const EASTMONEY_NEWS_CACHE_TTL_MS = 60_000

type RpcResult = Awaited<ReturnType<ConnectionRpcHandler>>

type SnapshotCache<T> = {
  licence: string
  expiresAt: number
  value: T
}

type TencentIndexQuote = Omit<StockMarketIndexQuote, 'id'>

type MarketRankingSpec = {
  id: StockMarketRankingId
  sort: 'change_percent' | 'net_inflow'
  order: 'asc' | 'desc'
}

const MARKET_RANKING_SPECS: ReadonlyArray<MarketRankingSpec> = [
  { id: 'gainers', sort: 'change_percent', order: 'desc' },
  { id: 'losers', sort: 'change_percent', order: 'asc' },
  { id: 'netInflow', sort: 'net_inflow', order: 'desc' },
  { id: 'netOutflow', sort: 'net_inflow', order: 'asc' },
]

const MARKET_HOTSPOT_GROUP_IDS: ReadonlyArray<StockMarketHotspotGroupId> = STOCK_MARKET_HOTSPOT_GROUPS.map(group => group.id)
const CONCEPT_HOTSPOT_CANDIDATE_LIMIT = STOCK_MARKET_HOTSPOT_SUMMARY_LIMIT * 6

/**
 * 东方财富概念板块目录混有涨停梯队与风格统计类板块（如“昨日连板_含一字”、
 * “ST板块”、“微盘股”），按涨跌幅排序时容易挤进概念热点前列；
 * 这里按名称关键词剔除，概念热点只保留主题题材板块。
 */
const CONCEPT_HOTSPOT_EXCLUDED_KEYWORDS = [
  '昨日',
  '连板',
  '打板',
  '涨停',
  '跌停',
  '一字',
  '炸板',
  'st',
  'ST',
  '退市',
  '微盘',
  '低价股',
  '次新股',
  '破净股',
] as const

type TencentTurnoverHistory = {
  tradeDate: string
  previousTradeDate: string
  amountsByCode: ReadonlyMap<string, ReadonlyMap<string, number>>
}

interface StockMarketRpcCache {
  indices?: SnapshotCache<StockMarketIndicesResponse>
  globalQuotes?: SnapshotCache<StockMarketGlobalQuotesResponse>
  breadth?: SnapshotCache<StockMarketBreadthResponse>
  trends?: SnapshotCache<StockMarketTrendsResponse>
  movers?: SnapshotCache<StockMarketMoversResponse>
  hotspots?: SnapshotCache<StockMarketHotspotsResponse>
  turnover?: SnapshotCache<StockMarketTurnoverResponse>
  turnoverHistory?: TencentTurnoverHistory
  headlines?: SnapshotCache<StockMarketNewsResponse>
  flashNews?: SnapshotCache<StockMarketNewsResponse>
}

type MarketResourceKey = Exclude<keyof StockMarketRpcCache, 'turnoverHistory'>

type MarketFlight = {
  controller: AbortController
  promise: Promise<RpcResult>
  settled: boolean
  waiters: number
}

class MarketRequestFlights {
  private readonly pending = new Map<MarketResourceKey, MarketFlight>()

  run(
    key: MarketResourceKey,
    signal: AbortSignal,
    operation: (signal: AbortSignal) => Promise<RpcResult>,
  ): Promise<RpcResult> {
    let flight = this.pending.get(key)
    if (flight === undefined) {
      const controller = new AbortController()
      const promise = Promise.resolve().then(() => operation(controller.signal))
      flight = { controller, promise, settled: false, waiters: 0 }
      this.pending.set(key, flight)
      const created = flight
      const finish = (): void => {
        created.settled = true
        if (this.pending.get(key) === created) this.pending.delete(key)
      }
      void promise.then(finish, finish)
    }
    return this.waitForFlight(flight, signal)
  }

  private waitForFlight(flight: MarketFlight, signal: AbortSignal): Promise<RpcResult> {
    if (signal.aborted) {
      if (flight.waiters === 0 && !flight.settled) flight.controller.abort()
      return Promise.resolve(cancelled())
    }

    flight.waiters++
    return new Promise<RpcResult>((resolve, reject) => {
      let finished = false
      const release = (): void => {
        if (finished) return
        finished = true
        signal.removeEventListener('abort', onAbort)
        flight.waiters--
        if (flight.waiters === 0 && !flight.settled) flight.controller.abort()
      }
      const onAbort = (): void => {
        release()
        resolve(cancelled())
      }
      signal.addEventListener('abort', onAbort, { once: true })
      if (signal.aborted) {
        onAbort()
        return
      }
      void flight.promise.then(
        value => {
          release()
          resolve(value)
        },
        error => {
          release()
          reject(error)
        },
      )
    })
  }
}

export interface StockMarketRpcOptions {
  fetcher?: typeof fetch
  now?: () => Date
  stockApiService?: StockApiService
  toolAccess?: Pick<StockToolAccessService, 'getBySessionId' | 'setBySessionId'>
  config?: StockMarketPluginConfig
  configScope?: SettingsScope<StockMarketPluginConfig>
  enabled?: boolean
}

export function registerStockMarketRpc(
  connection: HostConnectionHandle,
  options: StockMarketRpcOptions = {},
): () => Promise<void> {
  return connection.rpc.handle(
    STOCK_MARKET_RPC_CHANNEL,
    createStockMarketRpcHandler(options),
    { authority: 'trusted-host' },
  )
}

export function createStockMarketRpcHandler(
  options: StockMarketRpcOptions = {},
): ConnectionRpcHandler {
  const cache: StockMarketRpcCache = {}
  const flights = new MarketRequestFlights()
  const stockApiService = options.stockApiService ?? new StockApiService({
    fetcher: options.fetcher,
    now: options.now,
  })

  return async (endpoint, payload, signal) => {
    if (signal.aborted) return cancelled()

    if (options.enabled === false
      && endpoint !== STOCK_MARKET_CONFIG_ENDPOINT
      && endpoint !== STOCK_MARKET_SET_CONFIG_ENDPOINT) {
      return unavailable('插件已关闭,仅配置可读写。')
    }
    if (endpoint === STOCK_MARKET_CONFIG_ENDPOINT) {
      if (!isStockMarketConfigRequest(payload)) return badRequest('config 请求参数无效。')
      return ok({
        protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
        config: options.configScope?.get() ?? options.config ?? STOCK_MARKET_DEFAULT_CONFIG,
      })
    }

    if (endpoint === STOCK_MARKET_SET_CONFIG_ENDPOINT) {
      if (!isStockMarketSetConfigRequest(payload)) return badRequest('set-config 请求参数无效。')
      const scope = options.configScope
      if (scope === undefined) return unavailable('插件配置存储当前不可用。')
      try {
        await scope.replace(payload.config)
      } catch (error) {
        return unavailable('插件配置保存失败。')
      }
      return ok({
        protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
        ok: true,
      })
    }

    if (endpoint === STOCK_MARKET_HEALTH_ENDPOINT) {
      if (!isStockMarketHealthRequest(payload)) return badRequest('health 请求参数无效。')
      return {
        ok: true,
        value: {
          protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
          status: 'ready',
        },
      }
    }

    if (endpoint === STOCK_MARKET_TOOL_ACCESS_ENDPOINT) {
      if (!isStockMarketToolAccessRequest(payload)) return badRequest('tool-access 请求参数无效。')
      if (options.toolAccess === undefined) return unavailable('股票工具开关当前不可用。')
      try {
        return ok({
          protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
          enabled: options.toolAccess.getBySessionId(payload.sessionId),
        })
      } catch {
        return unavailable('无法读取当前会话的股票工具状态。')
      }
    }

    if (endpoint === STOCK_MARKET_SET_TOOL_ACCESS_ENDPOINT) {
      if (!isStockMarketSetToolAccessRequest(payload)) return badRequest('set-tool-access 请求参数无效。')
      if (options.toolAccess === undefined) return unavailable('股票工具开关当前不可用。')
      try {
        return ok({
          protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
          enabled: options.toolAccess.setBySessionId(payload.sessionId, payload.enabled),
        })
      } catch {
        return unavailable('无法更新当前会话的股票工具状态。')
      }
    }

    if (endpoint === STOCK_MARKET_INDICES_ENDPOINT) {
      if (!isStockMarketIndicesRequest(payload)) return badRequest('market-indices 请求参数无效。')
      return flights.run('indices', signal, sharedSignal => (
        marketIndices(options, stockApiService, cache, sharedSignal)
      ))
    }

    if (endpoint === STOCK_MARKET_GLOBAL_QUOTES_ENDPOINT) {
      if (!isStockMarketGlobalQuotesRequest(payload)) return badRequest('market-global-quotes 请求参数无效。')
      return flights.run('globalQuotes', signal, sharedSignal => (
        marketGlobalQuotes(options, stockApiService, cache, sharedSignal)
      ))
    }

    if (endpoint === STOCK_MARKET_BREADTH_ENDPOINT) {
      if (!isStockMarketBreadthRequest(payload)) return badRequest('market-breadth 请求参数无效。')
      return flights.run('breadth', signal, sharedSignal => (
        marketBreadth(options, stockApiService, cache, sharedSignal)
      ))
    }

    if (endpoint === STOCK_MARKET_TRENDS_ENDPOINT) {
      if (!isStockMarketTrendsRequest(payload)) return badRequest('market-trends 请求参数无效。')
      return flights.run('trends', signal, sharedSignal => (
        marketTrends(options, stockApiService, cache, sharedSignal)
      ))
    }

    if (endpoint === STOCK_MARKET_MOVERS_ENDPOINT) {
      if (!isStockMarketMoversRequest(payload)) return badRequest('market-movers 请求参数无效。')
      return flights.run('movers', signal, sharedSignal => (
        marketMovers(options, stockApiService, cache, sharedSignal)
      ))
    }

    if (endpoint === STOCK_MARKET_HOTSPOTS_ENDPOINT) {
      if (!isStockMarketHotspotsRequest(payload)) return badRequest('market-hotspots 请求参数无效。')
      return flights.run('hotspots', signal, sharedSignal => (
        marketHotspots(options, stockApiService, cache, sharedSignal)
      ))
    }

    if (endpoint === STOCK_MARKET_TURNOVER_ENDPOINT) {
      if (!isStockMarketTurnoverRequest(payload)) return badRequest('market-turnover 请求参数无效。')
      return flights.run('turnover', signal, sharedSignal => (
        marketTurnover(options, stockApiService, cache, sharedSignal)
      ))
    }

    if (endpoint === STOCK_MARKET_HEADLINES_ENDPOINT) {
      if (!isStockMarketNewsRequest(payload)) return badRequest('market-headlines 请求参数无效。')
      return flights.run('headlines', signal, sharedSignal => (
        marketNews(options, stockApiService, cache, 'headlines', sharedSignal)
      ))
    }

    if (endpoint === STOCK_MARKET_FLASH_NEWS_ENDPOINT) {
      if (!isStockMarketNewsRequest(payload)) return badRequest('market-flash-news 请求参数无效。')
      return flights.run('flashNews', signal, sharedSignal => (
        marketNews(options, stockApiService, cache, 'flashNews', sharedSignal)
      ))
    }

    return badRequest(`未知的股票行情 endpoint：${JSON.stringify(endpoint)}。`)
  }
}

async function marketIndices(
  options: StockMarketRpcOptions,
  stockApiService: StockApiService,
  cache: StockMarketRpcCache,
  signal: AbortSignal,
): Promise<RpcResult> {
  const cached = cachedSnapshot(cache.indices, 'tencent', currentTime(options))
  if (cached !== undefined) return ok(cached)

  let quotesByCode: ReadonlyMap<string, TencentIndexQuote>
  try {
    const responseText = await stockApiService.requestTencentMarketQuotes(
      Object.values(TENCENT_INDEX_CODES),
      signal,
    )
    quotesByCode = parseTencentIndexQuotes(responseText)
  } catch {
    if (signal.aborted) return cancelled()
    return unavailable('暂时无法获取指数行情。')
  }
  if (signal.aborted) return cancelled()

  const indices = STOCK_MARKET_INDICES.flatMap((index): StockMarketIndexQuote[] => {
    const quote = quotesByCode.get(TENCENT_INDEX_CODES[index.id])
    return quote === undefined ? [] : [{ id: index.id, ...quote }]
  })
  if (indices.length === 0) return unavailable('暂时无法获取指数行情。')

  const returnedIds = new Set(indices.map(index => index.id))
  const unavailableIds = STOCK_MARKET_INDICES
    .map(index => index.id)
    .filter(id => !returnedIds.has(id))
  const now = currentTime(options)
  const value: StockMarketIndicesResponse = {
    protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
    fetchedAt: now.toISOString(),
    marketStatus: resolveMarketStatus(now, indices),
    indices,
    unavailable: unavailableIds,
  }
  cache.indices = {
    licence: 'tencent',
    expiresAt: now.getTime() + TENCENT_INDICES_CACHE_TTL_MS,
    value,
  }
  return ok(value)
}

async function marketGlobalQuotes(
  options: StockMarketRpcOptions,
  stockApiService: StockApiService,
  cache: StockMarketRpcCache,
  signal: AbortSignal,
): Promise<RpcResult> {
  const cached = cachedSnapshot(cache.globalQuotes, 'sina', currentTime(options))
  if (cached !== undefined) return ok(cached)

  let quotes: ReadonlyArray<StockMarketGlobalQuote>
  try {
    quotes = parseSinaGlobalQuotes(await stockApiService.requestSinaGlobalQuotes(signal))
  } catch (error) {
    return marketUnavailable(signal, '暂时无法获取全球行情。', error)
  }
  if (signal.aborted) return cancelled()
  if (quotes.length === 0) return unavailable('暂时无法获取全球行情。')

  const returned = new Set(quotes.map(quote => quote.id))
  const now = currentTime(options)
  const value: StockMarketGlobalQuotesResponse = {
    protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
    fetchedAt: now.toISOString(),
    quotes,
    unavailable: STOCK_MARKET_GLOBAL_ASSETS.map(asset => asset.id).filter(id => !returned.has(id)),
  }
  cache.globalQuotes = {
    licence: 'sina',
    expiresAt: now.getTime() + SINA_GLOBAL_QUOTES_CACHE_TTL_MS,
    value,
  }
  return ok(value)
}

async function marketBreadth(
  options: StockMarketRpcOptions,
  stockApiService: StockApiService,
  cache: StockMarketRpcCache,
  signal: AbortSignal,
): Promise<RpcResult> {
  const cached = cachedSnapshot(cache.breadth, 'eastmoney', currentTime(options))
  if (cached !== undefined) return ok(cached)

  let breadth: StockMarketBreadth
  try {
    const response = await stockApiService.executeEastMoney(
      'em_batch_quotes',
      { secids: EASTMONEY_BREADTH_SECIDS },
      signal,
    )
    const parsed = parseEastMoneyBreadth(response.data)
    if (parsed === undefined) throw new StockApiError('东方财富涨跌家数响应格式无效。')
    breadth = parsed
  } catch (error) {
    return marketUnavailable(signal, '暂时无法获取沪深涨跌家数。', error)
  }

  const now = currentTime(options)
  const value: StockMarketBreadthResponse = {
    protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
    fetchedAt: now.toISOString(),
    breadth,
  }
  cache.breadth = {
    licence: 'eastmoney',
    expiresAt: now.getTime() + EASTMONEY_BREADTH_CACHE_TTL_MS,
    value,
  }
  return ok(value)
}

async function marketTrends(
  options: StockMarketRpcOptions,
  stockApiService: StockApiService,
  cache: StockMarketRpcCache,
  signal: AbortSignal,
): Promise<RpcResult> {
  const cached = cachedSnapshot(cache.trends, 'eastmoney', currentTime(options))
  if (cached !== undefined) return ok(cached)

  const results = await Promise.all(STOCK_MARKET_INDICES.map(async index => {
    try {
      const response = await stockApiService.executeEastMoney(
        'em_intraday_trends',
        { secid: EASTMONEY_INDEX_SECIDS[index.id], days: 1 },
        signal,
      )
      const trend = parseEastMoneyTrend(response.data, index.id)
      return trend === undefined ? undefined : trend
    } catch {
      return undefined
    }
  }))
  if (signal.aborted) return cancelled()

  const series = results.filter((trend): trend is StockMarketIndexTrend => trend !== undefined)
  if (series.length === 0) return unavailable('暂时无法获取指数分时走势。')
  const returnedIds = new Set(series.map(trend => trend.id))
  const now = currentTime(options)
  const value: StockMarketTrendsResponse = {
    protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
    fetchedAt: now.toISOString(),
    series,
    unavailable: STOCK_MARKET_INDICES.map(index => index.id).filter(id => !returnedIds.has(id)),
  }
  cache.trends = {
    licence: 'eastmoney',
    expiresAt: now.getTime() + EASTMONEY_TRENDS_CACHE_TTL_MS,
    value,
  }
  return ok(value)
}

async function marketMovers(
  options: StockMarketRpcOptions,
  stockApiService: StockApiService,
  cache: StockMarketRpcCache,
  signal: AbortSignal,
): Promise<RpcResult> {
  const cached = cachedSnapshot(cache.movers, 'eastmoney', currentTime(options))
  if (cached !== undefined) return ok(cached)

  let rankings: StockMarketMoverLists
  try {
    const entries = await Promise.all(MARKET_RANKING_SPECS.map(async spec => {
      const response = await stockApiService.executeEastMoney(
        'em_market_snapshot',
        { market: 'all_a', page: 1, limit: 10, sort: spec.sort, order: spec.order },
        signal,
      )
      const rows = parseEastMoneyMovers(response.data)
      if (rows === undefined) throw new StockApiError('东方财富个股排行响应格式无效。')
      return [spec.id, rows.slice(0, STOCK_MARKET_RANKING_SUMMARY_LIMIT)] as const
    }))
    const byRanking = new Map(entries)
    rankings = {
      gainers: byRanking.get('gainers') ?? [],
      losers: byRanking.get('losers') ?? [],
      netInflow: byRanking.get('netInflow') ?? [],
      netOutflow: byRanking.get('netOutflow') ?? [],
    }
  } catch (error) {
    return marketUnavailable(signal, '暂时无法获取实时个股排行。', error)
  }

  const now = currentTime(options)
  const value: StockMarketMoversResponse = {
    protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
    fetchedAt: now.toISOString(),
    rankings,
  }
  cache.movers = {
    licence: 'eastmoney',
    expiresAt: now.getTime() + EASTMONEY_MOVERS_CACHE_TTL_MS,
    value,
  }
  return ok(value)
}

async function marketHotspots(
  options: StockMarketRpcOptions,
  stockApiService: StockApiService,
  cache: StockMarketRpcCache,
  signal: AbortSignal,
): Promise<RpcResult> {
  const cached = cachedSnapshot(cache.hotspots, 'eastmoney', currentTime(options))
  if (cached !== undefined) return ok(cached)

  let groups: StockMarketHotspotGroups
  try {
    const entries = await Promise.all(MARKET_HOTSPOT_GROUP_IDS.map(async group => {
      const requestLimit = group === 'concept'
        ? CONCEPT_HOTSPOT_CANDIDATE_LIMIT
        : STOCK_MARKET_HOTSPOT_SUMMARY_LIMIT
      const response = await stockApiService.executeEastMoney(
        'em_market_snapshot',
        { market: group, page: 1, limit: requestLimit, sort: 'change_percent', order: 'desc' },
        signal,
      )
      const rows = parseEastMoneyHotspots(response.data)
      if (rows === undefined) throw new StockApiError('东方财富板块热点响应格式无效。')
      const visible = group === 'concept'
        ? rows.filter(quote => !isExcludedConceptHotspot(quote.name))
        : rows
      return [group, visible.slice(0, STOCK_MARKET_HOTSPOT_SUMMARY_LIMIT)] as const
    }))
    const byGroup = new Map(entries)
    groups = {
      industry: byGroup.get('industry') ?? [],
      concept: byGroup.get('concept') ?? [],
    }
  } catch (error) {
    return marketUnavailable(signal, '暂时无法获取实时板块热点。', error)
  }

  const now = currentTime(options)
  const value: StockMarketHotspotsResponse = {
    protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
    fetchedAt: now.toISOString(),
    groups,
  }
  cache.hotspots = {
    licence: 'eastmoney',
    expiresAt: now.getTime() + EASTMONEY_HOTSPOTS_CACHE_TTL_MS,
    value,
  }
  return ok(value)
}

async function marketTurnover(
  options: StockMarketRpcOptions,
  stockApiService: StockApiService,
  cache: StockMarketRpcCache,
  signal: AbortSignal,
): Promise<RpcResult> {
  const cached = cachedSnapshot(cache.turnover, 'tencent', currentTime(options))
  if (cached !== undefined) return ok(cached)

  let quotes: ReadonlyMap<string, TencentIndexQuote>
  try {
    quotes = parseTencentIndexQuotes(await stockApiService.requestTencentMarketQuotes(TENCENT_TURNOVER_CODES, signal))
  } catch {
    if (signal.aborted) return cancelled()
    return unavailable('暂时无法获取两市成交额。')
  }
  if (signal.aborted) return cancelled()

  const marketQuotes = TENCENT_TURNOVER_CODES.map(code => quotes.get(code))
  if (marketQuotes.some(quote => quote === undefined)) return unavailable('暂时无法获取两市成交额。')
  const availableQuotes = marketQuotes as TencentIndexQuote[]
  const tradeDates = new Set(availableQuotes.map(quote => quote.marketTime.slice(0, 10)))
  if (tradeDates.size !== 1) return unavailable('沪深市场行情日期不一致，暂时无法比较成交额。')
  const tradeDate = [...tradeDates][0]
  const marketMinute = availableQuotes
    .map(quote => quote.marketTime.slice(11, 16).replace(':', ''))
    .sort()[0]

  let history = cache.turnoverHistory
  if (history?.tradeDate !== tradeDate) {
    try {
      const daysByCode = await Promise.all(TENCENT_TURNOVER_CODES.map(async code => ({
        code,
        days: parseTencentTurnoverDays(await stockApiService.requestTencentTurnoverHistory(code, signal), code),
      })))
      history = buildTencentTurnoverHistory(tradeDate, daysByCode)
    } catch {
      if (signal.aborted) return cancelled()
      return unavailable('暂时无法获取上一交易日同期成交额。')
    }
    if (history === undefined) return unavailable('暂时无法获取上一交易日同期成交额。')
    cache.turnoverHistory = history
  }

  const comparisonMinute = latestCommonMinute(history.amountsByCode, marketMinute)
  if (comparisonMinute === undefined) return unavailable('暂时无法匹配上一交易日同期成交额。')
  const previousAmounts = TENCENT_TURNOVER_CODES.map(code => history.amountsByCode.get(code)?.get(comparisonMinute))
  if (previousAmounts.some(amount => amount === undefined)) return unavailable('暂时无法匹配上一交易日同期成交额。')

  const todayAmount = availableQuotes.reduce((total, quote) => total + quote.amount, 0)
  const previousAmount = (previousAmounts as number[]).reduce((total, amount) => total + amount, 0)
  const value: StockMarketTurnoverResponse = {
    protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
    fetchedAt: currentTime(options).toISOString(),
    tradeDate,
    previousTradeDate: history.previousTradeDate,
    todayAmount,
    previousAmount,
    changePercent: previousAmount > 0 ? ((todayAmount - previousAmount) / previousAmount) * 100 : 0,
  }
  cache.turnover = {
    licence: 'tencent',
    expiresAt: currentTime(options).getTime() + TENCENT_TURNOVER_CACHE_TTL_MS,
    value,
  }
  return ok(value)
}

type NewsSlot = 'headlines' | 'flashNews'

const NEWS_ENDPOINT_BY_SLOT: Record<NewsSlot, string> = {
  headlines: 'em_top_news',
  flashNews: 'em_kuaixun',
}

/** Eastmoney news needs no licence; only the service's gate + timeout apply. */
async function marketNews(
  options: StockMarketRpcOptions,
  stockApiService: StockApiService,
  cache: StockMarketRpcCache,
  slot: NewsSlot,
  signal: AbortSignal,
): Promise<RpcResult> {
  const cached = cachedSnapshot(cache[slot], '', currentTime(options))
  if (cached !== undefined) return ok(cached)

  let value: StockMarketNewsResponse
  try {
    const response = await stockApiService.executeEastMoney(
      NEWS_ENDPOINT_BY_SLOT[slot],
      { limit: STOCK_MARKET_NEWS_SUMMARY_LIMIT },
      signal,
    )
    const items = parseEastMoneyNews(response.data)
    if (items === undefined) throw new StockApiError('东方财富资讯响应格式无效。')
    value = {
      protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
      fetchedAt: currentTime(options).toISOString(),
      items,
    }
  } catch (error) {
    if (signal.aborted) return cancelled()
    return marketUnavailable(signal, slot === 'headlines' ? '暂时无法获取头条要闻。' : '暂时无法获取24小时快讯。', error)
  }

  cache[slot] = {
    licence: '',
    expiresAt: currentTime(options).getTime() + EASTMONEY_NEWS_CACHE_TTL_MS,
    value,
  }
  return ok(value)
}

function parseEastMoneyNews(value: unknown): StockMarketNewsItem[] | undefined {
  if (!isRecord(value) || !Array.isArray(value.items)) return undefined

  const items: StockMarketNewsItem[] = []
  for (const item of value.items) {
    if (!isRecord(item)) continue
    const id = typeof item.id === 'string' ? item.id.trim() : ''
    const title = typeof item.title === 'string' ? item.title.trim() : ''
    const time = typeof item.showtime === 'string'
      ? item.showtime
      : typeof item.showTime === 'string'
        ? item.showTime
        : typeof item.time === 'string'
          ? item.time
          : ''
    const summary = typeof item.digest === 'string'
      ? item.digest.trim()
      : typeof item.summary === 'string'
        ? item.summary.trim()
        : ''
    if (id.length === 0 || title.length === 0) continue
    items.push({ id, title, time, summary })
  }
  return items.length === 0 ? undefined : items.slice(0, STOCK_MARKET_NEWS_SUMMARY_LIMIT)
}

function parseEastMoneyBreadth(value: unknown): StockMarketBreadth | undefined {
  const rows = eastMoneyDiff(value)
  if (rows === undefined) return undefined

  const expectedCodes = new Set(['000001', '399001'])
  const seen = new Set<string>()
  let rising = 0
  let falling = 0
  let flat = 0
  for (const row of rows) {
    const code = typeof row.f12 === 'string' ? row.f12.trim() : ''
    if (!expectedCodes.has(code) || seen.has(code)) continue
    const rowRising = nonNegativeInteger(row.f104)
    const rowFalling = nonNegativeInteger(row.f105)
    const rowFlat = nonNegativeInteger(row.f106)
    if (rowRising === undefined || rowFalling === undefined || rowFlat === undefined) continue
    seen.add(code)
    rising += rowRising
    falling += rowFalling
    flat += rowFlat
  }
  return seen.size === expectedCodes.size ? { rising, falling, flat } : undefined
}

function parseEastMoneyTrend(value: unknown, id: StockMarketIndexId): StockMarketIndexTrend | undefined {
  if (!isRecord(value) || !isRecord(value.data) || !Array.isArray(value.data.trends)) return undefined
  const previousClose = finiteNumber(value.data.preClose)
  if (previousClose === undefined || previousClose <= 0) return undefined

  const byTime = new Map<string, StockMarketTrendPoint>()
  for (const row of value.data.trends) {
    if (typeof row !== 'string') continue
    const fields = row.split(',')
    const time = fields[0]?.trim() ?? ''
    const price = finiteNumber(fields[2])
    const averagePrice = finiteNumber(fields[7]) ?? price
    if (time.length === 0 || price === undefined || price <= 0 || averagePrice === undefined || averagePrice <= 0) continue
    byTime.set(time, { time, price, averagePrice })
  }
  if (byTime.size === 0) return undefined
  return { id, previousClose, points: sampleTrendPoints([...byTime.values()]) }
}

function sampleTrendPoints(points: ReadonlyArray<StockMarketTrendPoint>): StockMarketTrendPoint[] {
  if (points.length <= STOCK_MARKET_TREND_POINT_LIMIT) return [...points]
  const lastIndex = points.length - 1
  return Array.from({ length: STOCK_MARKET_TREND_POINT_LIMIT }, (_, index) => (
    points[Math.round((index * lastIndex) / (STOCK_MARKET_TREND_POINT_LIMIT - 1))]
  ))
}

function parseEastMoneyMovers(value: unknown): StockMarketMoverQuote[] | undefined {
  const rows = eastMoneyDiff(value)
  if (rows === undefined) return undefined

  const movers = new Map<string, StockMarketMoverQuote>()
  for (const row of rows) {
    const code = typeof row.f12 === 'string' ? row.f12.trim() : ''
    const name = typeof row.f14 === 'string' ? row.f14.trim() : ''
    const price = finiteNumber(row.f2)
    const changePercent = finiteNumber(row.f3)
    const netInflow = finiteNumber(row.f62)
    if (
      !isSupportedAStockCode(code)
      || name.length === 0
      || price === undefined
      || changePercent === undefined
      || netInflow === undefined
    ) continue
    movers.set(code, {
      code,
      name,
      price,
      changePercent,
      netInflow,
    })
  }
  return movers.size === 0 ? undefined : [...movers.values()]
}

function parseEastMoneyHotspots(value: unknown): StockMarketHotspotQuote[] | undefined {
  const rows = eastMoneyDiff(value)
  if (rows === undefined) return undefined

  const hotspots = new Map<string, StockMarketHotspotQuote>()
  for (const row of rows) {
    const code = typeof row.f12 === 'string' ? row.f12.trim() : ''
    const name = typeof row.f14 === 'string' ? row.f14.trim() : ''
    const changePercent = finiteNumber(row.f3)
    if (code.length === 0 || code.length > 32 || name.length === 0 || changePercent === undefined) continue
    hotspots.set(code, { code, name, changePercent })
  }
  if (rows.length === 0) return []
  return hotspots.size === 0 ? undefined : [...hotspots.values()]
}

function isExcludedConceptHotspot(name: string): boolean {
  return CONCEPT_HOTSPOT_EXCLUDED_KEYWORDS.some(keyword => name.includes(keyword))
}

function eastMoneyDiff(value: unknown): ReadonlyArray<Record<string, unknown>> | undefined {
  if (!isRecord(value) || !isRecord(value.data) || !Array.isArray(value.data.diff)) return undefined
  return value.data.diff.filter(isRecord)
}

function resolveMarketStatus(
  now: Date,
  indices: ReadonlyArray<StockMarketIndexQuote>,
): StockMarketTradingStatus {
  const clock = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
    weekday: 'short',
  }).formatToParts(now)
  const part = (type: Intl.DateTimeFormatPartTypes): string => clock.find(item => item.type === type)?.value ?? ''
  const today = `${part('year')}-${part('month')}-${part('day')}`
  const latestTradeDate = indices.map(index => index.marketTime.slice(0, 10)).sort().at(-1)
  const weekday = part('weekday')
  if (latestTradeDate !== today || weekday === 'Sat' || weekday === 'Sun') return 'closed'

  const minutes = Number(part('hour')) * 60 + Number(part('minute'))
  if (minutes < 9 * 60 + 15) return 'preopen'
  if (minutes < 9 * 60 + 30) return 'auction'
  if (minutes < 11 * 60 + 30) return 'trading'
  if (minutes < 13 * 60) return 'break'
  if (minutes < 15 * 60) return 'trading'
  return 'closed'
}

function nonNegativeInteger(value: unknown): number | undefined {
  const numeric = finiteNumber(value)
  return numeric !== undefined && Number.isSafeInteger(numeric) && numeric >= 0 ? numeric : undefined
}

type TencentTurnoverDay = {
  tradeDate: string
  amountsByMinute: ReadonlyMap<string, number>
}

function parseTencentTurnoverDays(value: unknown, code: string): TencentTurnoverDay[] {
  if (!isRecord(value) || value.code !== 0 || !isRecord(value.data)) return []
  const market = value.data[code]
  if (!isRecord(market) || !Array.isArray(market.data)) return []

  const days: TencentTurnoverDay[] = []
  for (const item of market.data) {
    if (!isRecord(item) || !Array.isArray(item.data)) continue
    const tradeDate = dateText(item.date)
    if (tradeDate === undefined) continue

    const amountsByMinute = new Map<string, number>()
    for (const row of item.data) {
      if (typeof row !== 'string') continue
      const fields = row.trim().split(/\s+/)
      const minute = fields[0]
      const amount = finiteNumber(fields[3])
      if (!/^\d{4}$/.test(minute) || amount === undefined || amount < 0) continue
      amountsByMinute.set(minute, amount)
    }
    if (amountsByMinute.size > 0) days.push({ tradeDate, amountsByMinute })
  }
  return days
}

function buildTencentTurnoverHistory(
  tradeDate: string,
  series: ReadonlyArray<{ code: string; days: ReadonlyArray<TencentTurnoverDay> }>,
): TencentTurnoverHistory | undefined {
  if (series.length === 0 || series.some(item => item.days.length === 0)) return undefined
  const datesByCode = series.map(item => new Map(item.days.map(day => [day.tradeDate, day] as const)))
  const previousTradeDate = [...datesByCode[0].keys()]
    .filter(date => date < tradeDate && datesByCode.every(days => days.has(date)))
    .sort()
    .at(-1)
  if (previousTradeDate === undefined) return undefined

  const amountsByCode = new Map<string, ReadonlyMap<string, number>>()
  for (const [position, item] of series.entries()) {
    const day = datesByCode[position].get(previousTradeDate)
    if (day === undefined) return undefined
    amountsByCode.set(item.code, day.amountsByMinute)
  }
  return { tradeDate, previousTradeDate, amountsByCode }
}

function latestCommonMinute(
  amountsByCode: ReadonlyMap<string, ReadonlyMap<string, number>>,
  targetMinute: string,
): string | undefined {
  const series = [...amountsByCode.values()]
  if (series.length === 0) return undefined
  return [...series[0].keys()]
    .filter(minute => minute <= targetMinute && series.every(amounts => amounts.has(minute)))
    .sort()
    .at(-1)
}

function dateText(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined
  const match = /^(\d{4})[-/]?(\d{2})[-/]?(\d{2})/.exec(value.trim())
  return match === null ? undefined : `${match[1]}-${match[2]}-${match[3]}`
}

function parseSinaGlobalQuotes(value: unknown): ReadonlyArray<StockMarketGlobalQuote> {
  if (!isRecord(value) || !Array.isArray(value.quotes)) return []
  const rows = new Map<string, Record<string, unknown>>()
  for (const candidate of value.quotes) {
    if (!isRecord(candidate) || typeof candidate.symbol !== 'string') continue
    rows.set(candidate.symbol, candidate)
  }
  return STOCK_MARKET_GLOBAL_ASSETS.flatMap((asset): StockMarketGlobalQuote[] => {
    const row = rows.get(SINA_GLOBAL_ASSET_SYMBOLS[asset.id])
    const quote = row === undefined ? undefined : parseSinaGlobalQuote(asset.id, row)
    return quote === undefined ? [] : [quote]
  })
}

function parseSinaGlobalQuote(
  id: StockMarketGlobalAssetId,
  row: Record<string, unknown>,
): StockMarketGlobalQuote | undefined {
  if (id === 'sse') {
    return globalQuote(
      id,
      row.price,
      row.previous_close,
      row.open,
      row.high,
      row.low,
      undefined,
      undefined,
      marketTime(row.date, row.time),
    )
  }
  if (id === 'hangSeng' || id === 'nasdaq') {
    const price = fieldAt(row, 1)
    const change = fieldAt(row, 2)
    return globalQuote(
      id,
      price,
      previousCloseFromChange(price, change),
      null,
      null,
      null,
      change,
      fieldAt(row, 3),
      '',
    )
  }
  if (id === 'kospi' || id === 'nikkei') {
    return globalQuote(
      id,
      fieldAt(row, 1),
      fieldAt(row, 9),
      fieldAt(row, 8),
      fieldAt(row, 10),
      fieldAt(row, 11),
      fieldAt(row, 2),
      fieldAt(row, 3),
      marketTime(fieldAt(row, 6), fieldAt(row, 7)),
    )
  }
  return globalQuote(
    id,
    fieldAt(row, 0),
    fieldAt(row, 7),
    fieldAt(row, 8),
    fieldAt(row, 4),
    fieldAt(row, 5),
    undefined,
    undefined,
    marketTime(fieldAt(row, 12), fieldAt(row, 6)),
  )
}

function globalQuote(
  id: StockMarketGlobalAssetId,
  priceValue: unknown,
  previousCloseValue: unknown,
  openValue: unknown,
  highValue: unknown,
  lowValue: unknown,
  changeValue: unknown,
  changePercentValue: unknown,
  quoteTime: string,
): StockMarketGlobalQuote | undefined {
  const price = positiveNumber(priceValue)
  if (price === undefined) return undefined
  const previousClose = nullablePositiveNumber(previousCloseValue)
  const change = finiteNumber(changeValue)
    ?? (previousClose === null ? undefined : rounded(price - previousClose))
  const changePercent = finiteNumber(changePercentValue)
    ?? (previousClose === null ? undefined : rounded((change ?? 0) / previousClose * 100))
  if (change === undefined || changePercent === undefined) return undefined
  return {
    id,
    price,
    previousClose,
    open: nullablePositiveNumber(openValue),
    high: nullablePositiveNumber(highValue),
    low: nullablePositiveNumber(lowValue),
    change,
    changePercent,
    marketTime: quoteTime,
  }
}

function fieldAt(row: Record<string, unknown>, index: number): unknown {
  return Array.isArray(row.fields) ? row.fields[index] : undefined
}

function previousCloseFromChange(priceValue: unknown, changeValue: unknown): number | null {
  const price = positiveNumber(priceValue)
  const change = finiteNumber(changeValue)
  if (price === undefined || change === undefined) return null
  return nullablePositiveNumber(rounded(price - change))
}

function marketTime(dateValue: unknown, timeValue: unknown): string {
  return [dateValue, timeValue]
    .filter((value): value is string => typeof value === 'string' && value.trim().length > 0)
    .map(value => value.trim())
    .join(' ')
}

function rounded(value: number): number {
  return Number(value.toFixed(6))
}

function positiveNumber(value: unknown): number | undefined {
  const numeric = finiteNumber(value)
  return numeric !== undefined && numeric > 0 ? numeric : undefined
}

function nullablePositiveNumber(value: unknown): number | null {
  return positiveNumber(value) ?? null
}

function parseTencentIndexQuotes(value: string): ReadonlyMap<string, TencentIndexQuote> {
  const quotes = new Map<string, TencentIndexQuote>()
  const assignments = value.matchAll(/(?:^|[\r\n])\s*v_([a-z0-9]+)="([^"]*)";?/g)
  for (const assignment of assignments) {
    const quote = parseTencentIndexQuote(assignment[2])
    if (quote !== undefined) quotes.set(assignment[1], quote)
  }
  return quotes
}

function parseTencentIndexQuote(value: string): TencentIndexQuote | undefined {
  const fields = value.split('~')
  const price = finiteNumber(fields[3])
  const previousClose = finiteNumber(fields[4])
  const open = finiteNumber(fields[5])
  const change = finiteNumber(fields[31])
  const changePercent = finiteNumber(fields[32])
  const high = finiteNumber(fields[33])
  const low = finiteNumber(fields[34])
  const preciseAmount = finiteNumber(fields[35]?.split('/')[2])
  const amountInTenThousands = finiteNumber(fields[37])
  const amount = preciseAmount ?? (amountInTenThousands === undefined ? undefined : amountInTenThousands * 10_000)
  const marketTime = formatTencentMarketTime(fields[30])
  if (
    price === undefined
    || previousClose === undefined
    || open === undefined
    || high === undefined
    || low === undefined
    || change === undefined
    || changePercent === undefined
    || amount === undefined
    || amount < 0
    || marketTime === undefined
  ) return undefined

  return { price, previousClose, open, high, low, change, changePercent, amount, marketTime }
}

function formatTencentMarketTime(value: string | undefined): string | undefined {
  const match = /^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/.exec(value ?? '')
  if (match === null) return undefined
  return `${match[1]}-${match[2]}-${match[3]} ${match[4]}:${match[5]}:${match[6]}`
}

function isSupportedAStockCode(value: string): boolean {
  return /^(?:000|001|002|003|300|301|600|601|603|605|688)\d{3}$/.test(value)
}

function marketUnavailable(signal: AbortSignal, fallback: string, error?: unknown): RpcResult {
  if (signal.aborted) return cancelled()
  if (error instanceof StockApiError && error.kind === 'unavailable') return unavailable(error.message)
  return unavailable(fallback)
}

function cachedSnapshot<T>(
  cache: SnapshotCache<T> | undefined,
  licence: string,
  now: Date,
): T | undefined {
  if (cache === undefined || cache.licence !== licence || cache.expiresAt <= now.getTime()) return undefined
  return cache.value
}

function currentTime(options: StockMarketRpcOptions): Date {
  return (options.now ?? (() => new Date()))()
}

function ok(value: unknown): RpcResult {
  return { ok: true, value } as RpcResult
}

function finiteNumber(value: unknown): number | undefined {
  const numeric = typeof value === 'number'
    ? value
    : typeof value === 'string' && value.trim() !== ''
      ? Number(value)
      : Number.NaN
  return Number.isFinite(numeric) ? numeric : undefined
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function badRequest(message: string): RpcResult {
  return {
    ok: false,
    error: {
      code: 'bad-request',
      message,
      details: { issues: [] },
    },
  } as RpcResult
}

function unavailable(message: string): RpcResult {
  return {
    ok: false,
    error: {
      code: 'internal',
      message,
      details: {},
    },
  } as RpcResult
}

function cancelled(): RpcResult {
  return {
    ok: false,
    error: {
      code: 'cancelled',
      message: '请求已取消。',
      details: {},
    },
  } as RpcResult
}
