export const STOCK_MARKET_RPC_CHANNEL = '/stock-market'
export const STOCK_MARKET_RPC_PROTOCOL_VERSION = 1 as const
export const STOCK_MARKET_HEALTH_ENDPOINT = 'health'
export const STOCK_MARKET_CONFIG_ENDPOINT = 'config'
export const STOCK_MARKET_SET_CONFIG_ENDPOINT = 'set-config'
export const STOCK_MARKET_CONFIG_NS = 'stock-market'
export const STOCK_MARKET_TOOL_ACCESS_ENDPOINT = 'tool-access'
export const STOCK_MARKET_SET_TOOL_ACCESS_ENDPOINT = 'set-tool-access'
export const STOCK_MARKET_INDICES_ENDPOINT = 'market-indices'
export const STOCK_MARKET_GLOBAL_QUOTES_ENDPOINT = 'market-global-quotes'
export const STOCK_MARKET_TURNOVER_ENDPOINT = 'market-turnover'
export const STOCK_MARKET_BREADTH_ENDPOINT = 'market-breadth'
export const STOCK_MARKET_TRENDS_ENDPOINT = 'market-trends'
export const STOCK_MARKET_MOVERS_ENDPOINT = 'market-movers'
export const STOCK_MARKET_HOTSPOTS_ENDPOINT = 'market-hotspots'
export const STOCK_MARKET_HEADLINES_ENDPOINT = 'market-headlines'
export const STOCK_MARKET_FLASH_NEWS_ENDPOINT = 'market-flash-news'
export const STOCK_MARKET_NEWS_SUMMARY_LIMIT = 10
export const STOCK_MARKET_RANKING_SUMMARY_LIMIT = 5
export const STOCK_MARKET_HOTSPOT_SUMMARY_LIMIT = 5
export const STOCK_MARKET_TREND_POINT_LIMIT = 121

export const STOCK_MARKET_INDICES = [
  { id: 'sse', code: '000001.SH', name: '上证指数' },
  { id: 'szse', code: '399001.SZ', name: '深证成指' },
  { id: 'chinext', code: '399006.SZ', name: '创业板指' },
  { id: 'star50', code: '000680.SH', name: '科创综指' },
] as const

export type StockMarketIndexId = typeof STOCK_MARKET_INDICES[number]['id']

export const STOCK_MARKET_GLOBAL_ASSETS = [
  { id: 'sse', name: '上证指数' },
  { id: 'hangSeng', name: '恒生指数' },
  { id: 'nasdaq', name: '纳斯达克' },
  { id: 'kospi', name: '韩国综合' },
  { id: 'nikkei', name: '日经指数' },
  { id: 'brent', name: '布伦特原油' },
  { id: 'newYorkGold', name: '纽约金主连' },
] as const

export type StockMarketGlobalAssetId = typeof STOCK_MARKET_GLOBAL_ASSETS[number]['id']

export const STOCK_MARKET_RANKINGS = [
  { id: 'gainers', name: '个股涨幅' },
  { id: 'losers', name: '个股跌幅' },
  { id: 'netInflow', name: '资金流入' },
  { id: 'netOutflow', name: '资金流出' },
] as const

export type StockMarketRankingId = typeof STOCK_MARKET_RANKINGS[number]['id']

export const STOCK_MARKET_HOTSPOT_GROUPS = [
  { id: 'industry', name: '行业' },
  { id: 'concept', name: '概念' },
] as const

export type StockMarketHotspotGroupId = typeof STOCK_MARKET_HOTSPOT_GROUPS[number]['id']
export type StockMarketTradingStatus = 'preopen' | 'auction' | 'trading' | 'break' | 'closed'

export interface StockMarketHealthRequest {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
}

/** Plugin-wide configuration surfaced to the browser half through the RPC channel. */
export interface StockMarketPluginConfig {
  enabled: boolean
  sidebarOpenByDefault: boolean
  toolsEnabledByDefault: boolean
}

export const STOCK_MARKET_DEFAULT_CONFIG: StockMarketPluginConfig = {
  enabled: true,
  sidebarOpenByDefault: true,
  toolsEnabledByDefault: true,
}

export interface StockMarketConfigRequest {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
}

export interface StockMarketConfigResponse {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
  config: StockMarketPluginConfig
}

export interface StockMarketSetConfigRequest {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
  config: StockMarketPluginConfig
}

export interface StockMarketSetConfigResponse {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
  ok: true
}

export function isStockMarketConfigRequest(value: unknown): value is StockMarketConfigRequest {
  return hasExactKeys(value, ['protocolVersion'])
    && value.protocolVersion === STOCK_MARKET_RPC_PROTOCOL_VERSION
}

export function isStockMarketConfigResponse(value: unknown): value is StockMarketConfigResponse {
  return hasExactKeys(value, ['protocolVersion', 'config'])
    && value.protocolVersion === STOCK_MARKET_RPC_PROTOCOL_VERSION
    && isStockMarketPluginConfig(value.config)
}

export function isStockMarketSetConfigRequest(value: unknown): value is StockMarketSetConfigRequest {
  return hasExactKeys(value, ['protocolVersion', 'config'])
    && value.protocolVersion === STOCK_MARKET_RPC_PROTOCOL_VERSION
    && isStockMarketPluginConfig(value.config)
}

export function isStockMarketSetConfigResponse(value: unknown): value is StockMarketSetConfigResponse {
  return hasExactKeys(value, ['protocolVersion', 'ok'])
    && value.protocolVersion === STOCK_MARKET_RPC_PROTOCOL_VERSION
    && value.ok === true
}

function isStockMarketPluginConfig(value: unknown): boolean {
  return isRecord(value)
    && typeof value.enabled === 'boolean'
    && typeof value.sidebarOpenByDefault === 'boolean'
    && typeof value.toolsEnabledByDefault === 'boolean'
}

export interface StockMarketHealthResponse {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
  status: 'ready'
}

export interface StockMarketToolAccessRequest {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
  sessionId: string
}

export interface StockMarketSetToolAccessRequest extends StockMarketToolAccessRequest {
  enabled: boolean
}

export interface StockMarketToolAccessResponse {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
  enabled: boolean
}

export interface StockMarketIndicesRequest {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
}

export interface StockMarketGlobalQuotesRequest {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
}

export interface StockMarketBreadthRequest {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
}

export interface StockMarketTrendsRequest {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
}

export interface StockMarketMoversRequest {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
}

export interface StockMarketHotspotsRequest {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
}

export interface StockMarketIndexQuote {
  id: StockMarketIndexId
  price: number
  previousClose: number
  open: number
  high: number
  low: number
  change: number
  changePercent: number
  /** 当日成交额（元）。 */
  amount: number
  marketTime: string
}

export interface StockMarketGlobalQuote {
  id: StockMarketGlobalAssetId
  price: number
  previousClose: number | null
  open: number | null
  high: number | null
  low: number | null
  change: number
  changePercent: number
  marketTime: string
}

export interface StockMarketGlobalQuotesResponse {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
  fetchedAt: string
  quotes: ReadonlyArray<StockMarketGlobalQuote>
  unavailable: ReadonlyArray<StockMarketGlobalAssetId>
}

export interface StockMarketTrendPoint {
  time: string
  price: number
  averagePrice: number
}

export interface StockMarketIndexTrend {
  id: StockMarketIndexId
  previousClose: number
  points: ReadonlyArray<StockMarketTrendPoint>
}

export interface StockMarketTrendsResponse {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
  fetchedAt: string
  series: ReadonlyArray<StockMarketIndexTrend>
  unavailable: ReadonlyArray<StockMarketIndexId>
}

export interface StockMarketMoverQuote {
  code: string
  name: string
  price: number
  changePercent: number
  /** 主力净流入额（元），正为流入、负为流出。 */
  netInflow: number
}

export type StockMarketMoverLists = Record<StockMarketRankingId, ReadonlyArray<StockMarketMoverQuote>>

export interface StockMarketMoversResponse {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
  fetchedAt: string
  rankings: StockMarketMoverLists
}

export interface StockMarketHotspotQuote {
  code: string
  name: string
  changePercent: number
}

export type StockMarketHotspotGroups = Record<StockMarketHotspotGroupId, ReadonlyArray<StockMarketHotspotQuote>>

export interface StockMarketHotspotsResponse {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
  fetchedAt: string
  groups: StockMarketHotspotGroups
}

export interface StockMarketBreadthResponse {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
  fetchedAt: string
  breadth: StockMarketBreadth
}

export interface StockMarketBreadth {
  rising: number
  falling: number
  flat: number
}

/** A bounded, server-normalized Eastmoney news item. */
export interface StockMarketNewsItem {
  id: string
  title: string
  /** Publication time text, e.g. 2026-08-10 22:11:05. */
  time: string
  summary: string
}

export interface StockMarketNewsRequest {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
}

export interface StockMarketNewsResponse {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
  fetchedAt: string
  items: ReadonlyArray<StockMarketNewsItem>
}

export interface StockMarketTurnoverRequest {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
}

export interface StockMarketTurnoverResponse {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
  fetchedAt: string
  tradeDate: string
  previousTradeDate: string
  /** Shanghai + Shenzhen cumulative turnover at the latest market time, in CNY. */
  todayAmount: number
  /** Previous trading day's cumulative turnover at the same market minute, in CNY. */
  previousAmount: number
  changePercent: number
}

export interface StockMarketIndicesResponse {
  protocolVersion: typeof STOCK_MARKET_RPC_PROTOCOL_VERSION
  fetchedAt: string
  marketStatus: StockMarketTradingStatus
  indices: ReadonlyArray<StockMarketIndexQuote>
  unavailable: ReadonlyArray<StockMarketIndexId>
}

export function isStockMarketHealthRequest(value: unknown): value is StockMarketHealthRequest {
  return isVersionedRequest(value)
}

export function isStockMarketHealthResponse(value: unknown): value is StockMarketHealthResponse {
  return hasExactKeys(value, ['protocolVersion', 'status'])
    && value.protocolVersion === STOCK_MARKET_RPC_PROTOCOL_VERSION
    && value.status === 'ready'
}

export function isStockMarketToolAccessRequest(value: unknown): value is StockMarketToolAccessRequest {
  return hasExactKeys(value, ['protocolVersion', 'sessionId'])
    && value.protocolVersion === STOCK_MARKET_RPC_PROTOCOL_VERSION
    && isSessionId(value.sessionId)
}

export function isStockMarketSetToolAccessRequest(value: unknown): value is StockMarketSetToolAccessRequest {
  return hasExactKeys(value, ['protocolVersion', 'sessionId', 'enabled'])
    && value.protocolVersion === STOCK_MARKET_RPC_PROTOCOL_VERSION
    && isSessionId(value.sessionId)
    && typeof value.enabled === 'boolean'
}

export function isStockMarketToolAccessResponse(value: unknown): value is StockMarketToolAccessResponse {
  return hasExactKeys(value, ['protocolVersion', 'enabled'])
    && value.protocolVersion === STOCK_MARKET_RPC_PROTOCOL_VERSION
    && typeof value.enabled === 'boolean'
}

export function isStockMarketIndicesRequest(value: unknown): value is StockMarketIndicesRequest {
  return isVersionedRequest(value)
}

export function isStockMarketGlobalQuotesRequest(value: unknown): value is StockMarketGlobalQuotesRequest {
  return isVersionedRequest(value)
}

export function isStockMarketBreadthRequest(value: unknown): value is StockMarketBreadthRequest {
  return isVersionedRequest(value)
}

export function isStockMarketTrendsRequest(value: unknown): value is StockMarketTrendsRequest {
  return isVersionedRequest(value)
}

export function isStockMarketMoversRequest(value: unknown): value is StockMarketMoversRequest {
  return isVersionedRequest(value)
}

export function isStockMarketHotspotsRequest(value: unknown): value is StockMarketHotspotsRequest {
  return isVersionedRequest(value)
}

export function isStockMarketTurnoverRequest(value: unknown): value is StockMarketTurnoverRequest {
  return isVersionedRequest(value)
}

export function isStockMarketNewsRequest(value: unknown): value is StockMarketNewsRequest {
  return isVersionedRequest(value)
}

export function isStockMarketNewsResponse(value: unknown): value is StockMarketNewsResponse {
  return hasExactKeys(value, ['protocolVersion', 'fetchedAt', 'items'])
    && value.protocolVersion === STOCK_MARKET_RPC_PROTOCOL_VERSION
    && typeof value.fetchedAt === 'string'
    && Array.isArray(value.items)
    && isNewsList(value.items)
}

function isNewsList(value: ReadonlyArray<unknown>): value is ReadonlyArray<StockMarketNewsItem> {
  if (value.length === 0 || value.length > STOCK_MARKET_NEWS_SUMMARY_LIMIT) return false
  const ids = new Set<string>()
  return value.every(item => {
    if (
      !hasExactKeys(item, ['id', 'title', 'time', 'summary'])
      || typeof item.id !== 'string'
      || item.id.trim().length === 0
      || ids.has(item.id)
      || typeof item.title !== 'string'
      || item.title.trim().length === 0
      || typeof item.time !== 'string'
      || typeof item.summary !== 'string'
    ) return false
    ids.add(item.id)
    return true
  })
}
export function isStockMarketTurnoverResponse(value: unknown): value is StockMarketTurnoverResponse {
  return hasExactKeys(value, [
    'protocolVersion',
    'fetchedAt',
    'tradeDate',
    'previousTradeDate',
    'todayAmount',
    'previousAmount',
    'changePercent',
  ])
    && value.protocolVersion === STOCK_MARKET_RPC_PROTOCOL_VERSION
    && typeof value.fetchedAt === 'string'
    && isDateText(value.tradeDate)
    && isDateText(value.previousTradeDate)
    && isFiniteNumber(value.todayAmount)
    && value.todayAmount >= 0
    && isFiniteNumber(value.previousAmount)
    && value.previousAmount >= 0
    && isFiniteNumber(value.changePercent)
}

export function isStockMarketBreadthResponse(value: unknown): value is StockMarketBreadthResponse {
  return hasExactKeys(value, ['protocolVersion', 'fetchedAt', 'breadth'])
    && value.protocolVersion === STOCK_MARKET_RPC_PROTOCOL_VERSION
    && typeof value.fetchedAt === 'string'
    && isBreadth(value.breadth)
}

export function isStockMarketTrendsResponse(value: unknown): value is StockMarketTrendsResponse {
  if (
    !hasExactKeys(value, ['protocolVersion', 'fetchedAt', 'series', 'unavailable'])
    || value.protocolVersion !== STOCK_MARKET_RPC_PROTOCOL_VERSION
    || typeof value.fetchedAt !== 'string'
    || !Array.isArray(value.series)
    || !Array.isArray(value.unavailable)
  ) return false

  const returned = new Set<StockMarketIndexId>()
  for (const trend of value.series) {
    if (
      !hasExactKeys(trend, ['id', 'previousClose', 'points'])
      || !isStockMarketIndexId(trend.id)
      || returned.has(trend.id)
      || !isFiniteNumber(trend.previousClose)
      || trend.previousClose <= 0
      || !Array.isArray(trend.points)
      || trend.points.length === 0
      || trend.points.length > STOCK_MARKET_TREND_POINT_LIMIT
      || !trend.points.every(point => (
        hasExactKeys(point, ['time', 'price', 'averagePrice'])
        && typeof point.time === 'string'
        && point.time.length > 0
        && isFiniteNumber(point.price)
        && point.price > 0
        && isFiniteNumber(point.averagePrice)
        && point.averagePrice > 0
      ))
    ) return false
    returned.add(trend.id)
  }

  const unavailable = new Set<StockMarketIndexId>()
  for (const id of value.unavailable) {
    if (!isStockMarketIndexId(id) || returned.has(id) || unavailable.has(id)) return false
    unavailable.add(id)
  }
  return returned.size + unavailable.size === STOCK_MARKET_INDICES.length
}

export function isStockMarketMoversResponse(value: unknown): value is StockMarketMoversResponse {
  if (
    !hasExactKeys(value, ['protocolVersion', 'fetchedAt', 'rankings'])
    || value.protocolVersion !== STOCK_MARKET_RPC_PROTOCOL_VERSION
    || typeof value.fetchedAt !== 'string'
  ) return false
  const rankings = value.rankings
  if (!hasExactKeys(rankings, STOCK_MARKET_RANKINGS.map(ranking => ranking.id))) return false
  return STOCK_MARKET_RANKINGS.every(ranking => {
    const rows = rankings[ranking.id]
    return Array.isArray(rows) && isMoverList(rows)
  })
}

export function isStockMarketHotspotsResponse(value: unknown): value is StockMarketHotspotsResponse {
  if (
    !hasExactKeys(value, ['protocolVersion', 'fetchedAt', 'groups'])
    || value.protocolVersion !== STOCK_MARKET_RPC_PROTOCOL_VERSION
    || typeof value.fetchedAt !== 'string'
  ) return false
  const groups = value.groups
  if (!hasExactKeys(groups, STOCK_MARKET_HOTSPOT_GROUPS.map(group => group.id))) return false
  return STOCK_MARKET_HOTSPOT_GROUPS.every(group => {
    const rows = groups[group.id]
    return Array.isArray(rows) && isHotspotList(rows)
  })
}

export function isStockMarketIndicesResponse(value: unknown): value is StockMarketIndicesResponse {
  if (
    !hasExactKeys(value, ['protocolVersion', 'fetchedAt', 'marketStatus', 'indices', 'unavailable'])
    || value.protocolVersion !== STOCK_MARKET_RPC_PROTOCOL_VERSION
    || typeof value.fetchedAt !== 'string'
    || !isTradingStatus(value.marketStatus)
    || !Array.isArray(value.indices)
    || !Array.isArray(value.unavailable)
  ) return false

  const returned = new Set<StockMarketIndexId>()
  for (const quote of value.indices) {
    if (
      !hasExactKeys(quote, [
        'id', 'price', 'previousClose', 'open', 'high', 'low', 'change', 'changePercent', 'amount', 'marketTime',
      ])
      || !isStockMarketIndexId(quote.id)
      || !isFiniteNumber(quote.price)
      || !isFiniteNumber(quote.previousClose)
      || !isFiniteNumber(quote.open)
      || !isFiniteNumber(quote.high)
      || !isFiniteNumber(quote.low)
      || !isFiniteNumber(quote.change)
      || !isFiniteNumber(quote.changePercent)
      || !isFiniteNumber(quote.amount)
      || quote.amount < 0
      || typeof quote.marketTime !== 'string'
      || returned.has(quote.id)
    ) return false
    returned.add(quote.id)
  }

  const unavailable = new Set<StockMarketIndexId>()
  for (const id of value.unavailable) {
    if (!isStockMarketIndexId(id) || returned.has(id) || unavailable.has(id)) return false
    unavailable.add(id)
  }

  return returned.size > 0
    && returned.size + unavailable.size === STOCK_MARKET_INDICES.length
}

export function isStockMarketGlobalQuotesResponse(value: unknown): value is StockMarketGlobalQuotesResponse {
  if (
    !hasExactKeys(value, ['protocolVersion', 'fetchedAt', 'quotes', 'unavailable'])
    || value.protocolVersion !== STOCK_MARKET_RPC_PROTOCOL_VERSION
    || typeof value.fetchedAt !== 'string'
    || !Array.isArray(value.quotes)
    || !Array.isArray(value.unavailable)
  ) return false

  const returned = new Set<StockMarketGlobalAssetId>()
  for (const quote of value.quotes) {
    if (
      !hasExactKeys(quote, [
        'id', 'price', 'previousClose', 'open', 'high', 'low', 'change', 'changePercent', 'marketTime',
      ])
      || !isStockMarketGlobalAssetId(quote.id)
      || !isPositiveNumber(quote.price)
      || !isNullablePositiveNumber(quote.previousClose)
      || !isNullablePositiveNumber(quote.open)
      || !isNullablePositiveNumber(quote.high)
      || !isNullablePositiveNumber(quote.low)
      || !isFiniteNumber(quote.change)
      || !isFiniteNumber(quote.changePercent)
      || typeof quote.marketTime !== 'string'
      || returned.has(quote.id)
    ) return false
    returned.add(quote.id)
  }

  const unavailable = new Set<StockMarketGlobalAssetId>()
  for (const id of value.unavailable) {
    if (!isStockMarketGlobalAssetId(id) || returned.has(id) || unavailable.has(id)) return false
    unavailable.add(id)
  }

  return returned.size > 0
    && returned.size + unavailable.size === STOCK_MARKET_GLOBAL_ASSETS.length
}

export function isStockMarketIndexId(value: unknown): value is StockMarketIndexId {
  return typeof value === 'string' && STOCK_MARKET_INDICES.some(index => index.id === value)
}

export function isStockMarketGlobalAssetId(value: unknown): value is StockMarketGlobalAssetId {
  return typeof value === 'string' && STOCK_MARKET_GLOBAL_ASSETS.some(asset => asset.id === value)
}

function isVersionedRequest(value: unknown): value is StockMarketHealthRequest {
  return hasExactKeys(value, ['protocolVersion'])
    && value.protocolVersion === STOCK_MARKET_RPC_PROTOCOL_VERSION
}

function isSessionId(value: unknown): value is string {
  return typeof value === 'string' && value.length > 0 && value.length <= 512
}

function hasExactKeys(value: unknown, keys: ReadonlyArray<string>): value is Record<string, unknown> {
  if (!isRecord(value) || Object.keys(value).length !== keys.length) return false
  return keys.every(key => Object.hasOwn(value, key))
}

function isSupportedAStockCode(value: string): boolean {
  return /^(?:000|001|002|003|300|301|600|601|603|605|688)\d{3}$/.test(value)
}

function isMoverList(value: ReadonlyArray<unknown>): value is ReadonlyArray<StockMarketMoverQuote> {
  if (value.length === 0 || value.length > STOCK_MARKET_RANKING_SUMMARY_LIMIT) return false
  const codes = new Set<string>()
  return value.every(quote => {
    if (
      !hasExactKeys(quote, ['code', 'name', 'price', 'changePercent', 'netInflow'])
      || typeof quote.code !== 'string'
      || !isSupportedAStockCode(quote.code)
      || codes.has(quote.code)
      || typeof quote.name !== 'string'
      || quote.name.trim().length === 0
      || !isFiniteNumber(quote.price)
      || !isFiniteNumber(quote.changePercent)
      || !isFiniteNumber(quote.netInflow)
    ) return false
    codes.add(quote.code)
    return true
  })
}

function isHotspotList(value: ReadonlyArray<unknown>): value is ReadonlyArray<StockMarketHotspotQuote> {
  if (value.length > STOCK_MARKET_HOTSPOT_SUMMARY_LIMIT) return false
  const codes = new Set<string>()
  return value.every(quote => {
    if (
      !hasExactKeys(quote, ['code', 'name', 'changePercent'])
      || typeof quote.code !== 'string'
      || quote.code.trim().length === 0
      || quote.code.length > 32
      || codes.has(quote.code)
      || typeof quote.name !== 'string'
      || quote.name.trim().length === 0
      || !isFiniteNumber(quote.changePercent)
    ) return false
    codes.add(quote.code)
    return true
  })
}

function isTradingStatus(value: unknown): value is StockMarketTradingStatus {
  return value === 'preopen' || value === 'auction' || value === 'trading' || value === 'break' || value === 'closed'
}

function isNonNegativeInteger(value: unknown): value is number {
  return typeof value === 'number' && Number.isSafeInteger(value) && value >= 0
}

function isBreadth(value: unknown): value is StockMarketBreadth {
  return hasExactKeys(value, ['rising', 'falling', 'flat'])
    && isNonNegativeInteger(value.rising)
    && isNonNegativeInteger(value.falling)
    && isNonNegativeInteger(value.flat)
}

function isDateText(value: unknown): value is string {
  return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)
}

function isFiniteNumber(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value)
}

function isPositiveNumber(value: unknown): value is number {
  return isFiniteNumber(value) && value > 0
}

function isNullablePositiveNumber(value: unknown): value is number | null {
  return value === null || isPositiveNumber(value)
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}
