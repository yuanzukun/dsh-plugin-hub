import SettingsProvider, { settingsNamespace, type SettingsScope } from '@deepseek-ai/dsh-settings'
import z from '@deepseek-ai/schemastery'
import {
  STOCK_MARKET_CONFIG_NS,
  type StockMarketPluginConfig,
} from './rpc-contract.ts'

/**
 * Settings schema for the plugin-wide configuration. Registered with the DSH
 * settings seam so the values are durable, survive restarts, and can be
 * edited from the browser (Plugin config card / 行情 settings section).
 */
export const StockMarketConfigSchema: z<StockMarketPluginConfig> = z.object({
  enabled: z.boolean(),
  sidebarOpenByDefault: z.boolean(),
  toolsEnabledByDefault: z.boolean(),
})

/** Register the namespace; the returned scope resolves schema defaults → base → user layer. */
export function registerStockMarketConfig(
  settings: SettingsProvider,
  fallback: StockMarketPluginConfig,
): SettingsScope<StockMarketPluginConfig> {
  return settings.register(
    settingsNamespace(STOCK_MARKET_CONFIG_NS),
    StockMarketConfigSchema,
    { applies: 'live', base: fallback },
  )
}
