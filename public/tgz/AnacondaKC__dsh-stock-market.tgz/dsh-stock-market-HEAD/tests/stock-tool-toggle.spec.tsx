// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { StockToolToggle, type StockToolToggleProps } from '../src/client/StockToolToggle.tsx'

afterEach(cleanup)

describe('StockToolToggle', () => {
  it('loads the durable state and toggles the session capability', async () => {
    const load = vi.fn(async () => false)
    const setEnabled = vi.fn(async () => true)
    render(<StockToolToggle {...props(load, setEnabled)} />)

    const off = await screen.findByRole('switch', { name: '股票工具已关闭，按下开启' })
    expect(off.getAttribute('aria-checked')).toBe('false')
    expect(off.textContent).toBe('股票工具')

    fireEvent.click(off)
    expect(setEnabled).toHaveBeenCalledWith(true, expect.any(AbortSignal))
    await waitFor(() => {
      const enabled = screen.getByRole('switch', { name: '股票工具已开启，按下关闭' })
      expect(enabled.getAttribute('aria-checked')).toBe('true')
      expect(enabled.textContent).toBe('股票工具')
    })
  })

  it('keeps the confirmed state and exposes transport failures accessibly', async () => {
    const setEnabled = vi.fn(async () => { throw new Error('network down') })
    render(<StockToolToggle {...props(vi.fn(async () => true), setEnabled)} />)

    const button = await screen.findByRole('switch', { name: '股票工具已开启，按下关闭' })
    fireEvent.click(button)
    await waitFor(() => {
      expect(screen.getByRole('status').textContent).toBe('股票工具状态更新失败：network down')
    })
    expect(screen.getByRole('switch').getAttribute('aria-checked')).toBe('true')
    expect(screen.getByRole('switch').getAttribute('title')).toContain('network down')
  })

  it('cannot mutate a removed session', async () => {
    const setEnabled = vi.fn(async () => false)
    render(<StockToolToggle {...props(vi.fn(async () => true), setEnabled, true)} />)

    const button = await screen.findByRole('switch') as HTMLButtonElement
    expect(button.disabled).toBe(true)
    fireEvent.click(button)
    expect(setEnabled).not.toHaveBeenCalled()
  })

  it('aborts an in-flight mutation when its session entry unmounts', async () => {
    let mutationSignal: AbortSignal | undefined
    const setEnabled = vi.fn((_enabled: boolean, signal?: AbortSignal) => {
      mutationSignal = signal
      return new Promise<boolean>(() => undefined)
    })
    const view = render(<StockToolToggle {...props(vi.fn(async () => true), setEnabled)} />)

    fireEvent.click(await screen.findByRole('switch', { name: '股票工具已开启，按下关闭' }))
    expect(mutationSignal?.aborted).toBe(false)
    view.unmount()
    expect(mutationSignal?.aborted).toBe(true)
  })

  it('clears a pending mutation when the injected session handlers change', async () => {
    let mutationSignal: AbortSignal | undefined
    let resolveMutation: ((enabled: boolean) => void) | undefined
    const firstSetEnabled = vi.fn((_enabled: boolean, signal?: AbortSignal) => {
      mutationSignal = signal
      return new Promise<boolean>((resolve) => { resolveMutation = resolve })
    })
    const view = render(
      <StockToolToggle {...props(vi.fn(async () => true), firstSetEnabled)} />,
    )

    fireEvent.click(await screen.findByRole('switch', { name: '股票工具已开启，按下关闭' }))
    expect(screen.getByRole('switch')).toHaveProperty('disabled', true)

    view.rerender(
      <StockToolToggle {...props(vi.fn(async () => false), vi.fn(async () => true))} />,
    )

    expect(mutationSignal?.aborted).toBe(true)
    const reloaded = await screen.findByRole('switch', { name: '股票工具已关闭，按下开启' })
    expect(reloaded).toHaveProperty('disabled', false)
    resolveMutation?.(false)
  })
})

function props(
  load: () => Promise<boolean>,
  setEnabled: (enabled: boolean, signal?: AbortSignal) => Promise<boolean>,
  removed = false,
): StockToolToggleProps {
  return {
    load,
    setEnabled,
    session: { removed },
  } as unknown as StockToolToggleProps
}
