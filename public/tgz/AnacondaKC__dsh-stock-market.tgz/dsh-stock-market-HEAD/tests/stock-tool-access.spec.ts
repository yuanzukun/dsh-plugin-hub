import { describe, expect, it, vi } from 'vitest'
import type { PreToolDecision, ToolExecution } from '@deepseek-ai/dsh-tools'
import {
  STOCK_TOOL_ACCESS_EVENT,
  STOCK_TOOL_NAMES,
  StockToolAccessService,
  foldStockToolAccess,
} from '../src/stock-tool-access.ts'

describe('stock tool access', () => {
  it('defaults to enabled and folds the last valid logged choice', () => {
    expect(foldStockToolAccess([])).toBe(true)
    expect(foldStockToolAccess([
      { type: STOCK_TOOL_ACCESS_EVENT, data: { enabled: false } },
      { type: STOCK_TOOL_ACCESS_EVENT, data: { enabled: 'invalid' } },
      { type: 'other', data: { enabled: false } },
      { type: STOCK_TOOL_ACCESS_EVENT, data: { enabled: true } },
    ])).toBe(true)
  })

  it('hides all stock tools, denies stale calls, and restores the scoped catalog', async () => {
    const disposeRestriction = vi.fn()
    const restrict = vi.fn(() => disposeRestriction)
    const events: Array<{ type: string; data: unknown }> = []
    const agent = {
      session: {
        id: 'session-1',
        events,
        append: vi.fn((type: string, data: unknown) => { events.push({ type, data }) }),
      },
      ctx: { tools: { restrict } },
    }
    const listeners = new Map<string, Function>()
    const guard = vi.fn()
    const lifecycle = lifecycleHarness()
    const ctx = {
      effect: lifecycle.effect,
      agents: {
        get: vi.fn((id: string) => id === 'session-1' ? agent : undefined),
        list: vi.fn(() => [agent]),
      },
      on: vi.fn((name: string, listener: Function) => { listeners.set(name, listener) }),
      tools: { guard },
    }
    const service = new StockToolAccessService(ctx as never)

    expect(service.getBySessionId('session-1')).toBe(true)
    expect(restrict).not.toHaveBeenCalled()

    expect(service.setBySessionId('session-1', false)).toBe(false)
    expect(restrict).toHaveBeenCalledWith({ deny: STOCK_TOOL_NAMES })
    expect(events).toEqual([{
      type: STOCK_TOOL_ACCESS_EVENT,
      data: { enabled: false },
    }])

    const execution = { name: 'stock_quote', agent } as unknown as Readonly<ToolExecution>
    const preExecute = listeners.get('tools/pre-execute') as (
      exec: Readonly<ToolExecution>,
      next: () => Promise<PreToolDecision>,
    ) => Promise<PreToolDecision>
    const next = vi.fn(async (): Promise<PreToolDecision> => ({ kind: 'allow' }))
    await expect(preExecute(execution, next)).resolves.toMatchObject({
      kind: 'deny',
      reason: expect.stringContaining('已关闭股票工具调用'),
    })
    expect(next).not.toHaveBeenCalled()

    const finalGuard = guard.mock.calls[0]?.[0] as (exec: Readonly<ToolExecution>) => string | undefined
    expect(finalGuard(execution)).toContain('已关闭股票工具调用')
    expect(finalGuard({ name: 'unrelated', agent } as unknown as Readonly<ToolExecution>)).toBeUndefined()

    expect(service.setBySessionId('session-1', true)).toBe(true)
    expect(disposeRestriction).toHaveBeenCalledOnce()
    expect(finalGuard(execution)).toBeUndefined()
  })

  it('keeps the capability isolated between concurrent sessions', () => {
    const makeAgent = (id: string) => ({
      session: {
        id,
        events: [] as Array<{ type: string; data: unknown }>,
        append(type: string, data: unknown) { this.events.push({ type, data }) },
      },
      ctx: { tools: { restrict: vi.fn(() => vi.fn()) } },
    })
    const first = makeAgent('first')
    const second = makeAgent('second')
    const guard = vi.fn()
    const lifecycle = lifecycleHarness()
    const ctx = {
      effect: lifecycle.effect,
      agents: {
        get: vi.fn((id: string) => id === 'first' ? first : id === 'second' ? second : undefined),
        list: vi.fn(() => [first, second]),
      },
      on: vi.fn(),
      tools: { guard },
    }
    const service = new StockToolAccessService(ctx as never)

    service.setBySessionId('first', false)

    expect(service.getBySessionId('first')).toBe(false)
    expect(service.getBySessionId('second')).toBe(true)
    expect(first.ctx.tools.restrict).toHaveBeenCalledWith({ deny: STOCK_TOOL_NAMES })
    expect(second.ctx.tools.restrict).not.toHaveBeenCalled()

    const finalGuard = guard.mock.calls[0]?.[0] as (exec: Readonly<ToolExecution>) => string | undefined
    expect(finalGuard({ name: 'stock_news', agent: first } as unknown as Readonly<ToolExecution>)).toContain('已关闭')
    expect(finalGuard({ name: 'stock_news', agent: second } as unknown as Readonly<ToolExecution>)).toBeUndefined()
  })

  it('reinstalls a persisted disabled restriction for a resumed or forked agent', () => {
    const restrict = vi.fn(() => vi.fn())
    const agent = {
      session: {
        id: 'resumed',
        events: [{ type: STOCK_TOOL_ACCESS_EVENT, data: { enabled: false } }],
      },
      ctx: { tools: { restrict } },
    }
    let created: ((payload: { agent: typeof agent }) => void) | undefined
    const lifecycle = lifecycleHarness()
    const ctx = {
      effect: lifecycle.effect,
      agents: { get: vi.fn(), list: vi.fn(() => []) },
      on: vi.fn((name: string, listener: Function) => {
        if (name === 'agent/created') created = listener as typeof created
      }),
      tools: { guard: vi.fn() },
    }

    new StockToolAccessService(ctx as never)
    created?.({ agent })
    expect(restrict).toHaveBeenCalledWith({ deny: STOCK_TOOL_NAMES })
  })

  it('releases every live agent restriction when the plugin unloads', () => {
    const firstDispose = vi.fn()
    const secondDispose = vi.fn()
    const makeAgent = (id: string, dispose: () => void) => ({
      session: {
        id,
        events: [{ type: STOCK_TOOL_ACCESS_EVENT, data: { enabled: false } }],
      },
      ctx: { tools: { restrict: vi.fn(() => dispose) } },
    })
    const first = makeAgent('first', firstDispose)
    const second = makeAgent('second', secondDispose)
    const lifecycle = lifecycleHarness()
    const ctx = {
      effect: lifecycle.effect,
      agents: { get: vi.fn(), list: vi.fn(() => [first, second]) },
      on: vi.fn(),
      tools: { guard: vi.fn() },
    }

    new StockToolAccessService(ctx as never)
    lifecycle.dispose()

    expect(firstDispose).toHaveBeenCalledOnce()
    expect(secondDispose).toHaveBeenCalledOnce()
  })
})

function lifecycleHarness(): { effect: ReturnType<typeof vi.fn>; dispose: () => void } {
  const disposers: Array<() => void> = []
  return {
    effect: vi.fn((setup: () => unknown) => {
      const dispose = setup()
      if (typeof dispose === 'function') disposers.push(dispose as () => void)
      return vi.fn()
    }),
    dispose: () => {
      for (const dispose of [...disposers].reverse()) dispose()
    },
  }
}
