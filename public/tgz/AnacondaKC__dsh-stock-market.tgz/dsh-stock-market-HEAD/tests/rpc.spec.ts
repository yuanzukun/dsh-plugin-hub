import { describe, expect, it, vi } from 'vitest'
import type { HostConnectionHandle } from '@deepseek-ai/dsh-client-connection'
import {
  createStockMarketRpcHandler,
  registerStockMarketRpc,
} from '../src/rpc.ts'
import {
  STOCK_MARKET_BREADTH_ENDPOINT,
  STOCK_MARKET_FLASH_NEWS_ENDPOINT,
  STOCK_MARKET_GLOBAL_QUOTES_ENDPOINT,
  STOCK_MARKET_HEADLINES_ENDPOINT,
  STOCK_MARKET_HEALTH_ENDPOINT,
  STOCK_MARKET_HOTSPOTS_ENDPOINT,
  STOCK_MARKET_INDICES_ENDPOINT,
  STOCK_MARKET_MOVERS_ENDPOINT,
  STOCK_MARKET_RPC_CHANNEL,
  STOCK_MARKET_RPC_PROTOCOL_VERSION,
  STOCK_MARKET_SET_TOOL_ACCESS_ENDPOINT,
  STOCK_MARKET_TOOL_ACCESS_ENDPOINT,
  STOCK_MARKET_TRENDS_ENDPOINT,
  STOCK_MARKET_TURNOVER_ENDPOINT,
  isStockMarketGlobalQuotesResponse,
  isStockMarketHotspotsResponse,
  isStockMarketIndicesResponse,
  isStockMarketTurnoverResponse,
} from '../src/rpc-contract.ts'
import { StockApiService } from '../src/stock-api/service.ts'

const TENCENT_INDEX_RESPONSE = [
  tencentQuote('sh000001', 3831.382, -0.88, -0.023, 534_600_000_000),
  tencentQuote('sz399001', 12266.314, 22.13, 0.181, 402_300_000_000),
  tencentQuote('sz399006', 2681.183, 4.72, 0.176, 198_700_000_000),
  tencentQuote('sh000680', 1045.761, -1.46, -0.139, 86_500_000_000),
].join('\n')

const SINA_GLOBAL_RESPONSE = [
  sinaAShareQuote('sh000001', 3942.14, 3934.09, 3933.55, 3943.71, 3927.55),
  'var hq_str_int_hangseng="Hang Seng,25374.680,-278.140,-1.080";',
  'var hq_str_int_nasdaq="Nasdaq,22484.07,99.37,0.44";',
  'var hq_str_b_KOSPI="KOSPI,6606.3700,260.84,4.11,2:27 AM,14:27:00,2026-08-12,10:44:00,6438.5000,6345.5300,6621.2900,6413.5000,0";',
  'var hq_str_b_NKY="Nikkei 225,67039.9600,69.74,0.10,2:12 AM,14:12:00,2026-08-12,10:30:01,66994.0500,66970.2200,67144.3600,66735.7600,0";',
  'var hq_str_hf_OIL="89.647,,89.620,89.640,89.730,89.080,10:43:40,88.910,89.170,0,2,2,2026-08-12,Brent,4937";',
  'var hq_str_hf_GC="4465.286,,4464.900,4465.300,4467.600,4421.400,10:44:09,4441.100,4430.000,0,1,3,2026-08-12,New York Gold,0";',
].join('\n')

const TENCENT_TURNOVER_QUOTE_RESPONSE = [
  tencentQuote('sh000001', 3800, 10, 0.2, 460_000_000_000, '20260804101530'),
  tencentQuote('sz399106', 2400, 8, 0.3, 560_000_000_000, '20260804101528'),
].join('\n')

const TENCENT_TURNOVER_DAYS = {
  sh000001: [
    turnoverDay('20260804', [['1015', 460_000_000_000]]),
    turnoverDay('20260803', [['1014', 440_000_000_000], ['1015', 450_000_000_000], ['1500', 900_000_000_000]]),
    turnoverDay('20260731', [['1015', 400_000_000_000]]),
  ],
  sz399106: [
    turnoverDay('20260804', [['1015', 560_000_000_000]]),
    turnoverDay('20260803', [['1014', 530_000_000_000], ['1015', 550_000_000_000], ['1500', 1_000_000_000_000]]),
    turnoverDay('20260731', [['1015', 500_000_000_000]]),
  ],
} as const

describe('stock market RPC', () => {
  it('registers a trusted-host channel', () => {
    const dispose = async (): Promise<void> => undefined
    const handle = vi.fn(() => dispose)

    expect(registerStockMarketRpc({ rpc: { handle } } as unknown as HostConnectionHandle)).toBe(dispose)
    expect(handle).toHaveBeenCalledWith(
      STOCK_MARKET_RPC_CHANNEL,
      expect.any(Function),
      { authority: 'trusted-host' },
    )
  })

  it('answers a versioned health handshake', async () => {
    const result = await createStockMarketRpcHandler()(
      STOCK_MARKET_HEALTH_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
      new AbortController().signal,
    )

    expect(result).toEqual({
      ok: true,
      value: { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION, status: 'ready' },
    })
  })

  it('reads and updates per-session stock tool access through strict RPC payloads', async () => {
    const toolAccess = {
      getBySessionId: vi.fn(() => true),
      setBySessionId: vi.fn((_sessionId: string, enabled: boolean) => enabled),
    }
    const handler = createStockMarketRpcHandler({ toolAccess })
    const signal = new AbortController().signal

    await expect(handler(
      STOCK_MARKET_TOOL_ACCESS_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION, sessionId: 'session-1' },
      signal,
    )).resolves.toEqual({
      ok: true,
      value: { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION, enabled: true },
    })

    await expect(handler(
      STOCK_MARKET_SET_TOOL_ACCESS_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION, sessionId: 'session-1', enabled: false },
      signal,
    )).resolves.toEqual({
      ok: true,
      value: { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION, enabled: false },
    })
    expect(toolAccess.getBySessionId).toHaveBeenCalledWith('session-1')
    expect(toolAccess.setBySessionId).toHaveBeenCalledWith('session-1', false)
  })

  it('rejects malformed stock tool access mutations', async () => {
    const result = await createStockMarketRpcHandler({
      toolAccess: { getBySessionId: () => true, setBySessionId: () => true },
    })(
      STOCK_MARKET_SET_TOOL_ACCESS_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION, sessionId: '', enabled: 'false' },
      new AbortController().signal,
    )

    expect(result.ok).toBe(false)
    if (!result.ok) expect(result.error.code).toBe('bad-request')
  })

  it('returns the fixed four-index realtime summary through Tencent without history fan-out', async () => {
    const fetcher = vi.fn(async (url: string) => tencentIndexResponse(url))
    const result = await createStockMarketRpcHandler({
      fetcher: fetcher as unknown as typeof fetch,
      now: () => new Date('2026-08-03T01:00:00.000Z'),
    })(
      STOCK_MARKET_INDICES_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
      new AbortController().signal,
    )

    expect(result).toEqual({
      ok: true,
      value: {
        protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
        fetchedAt: '2026-08-03T01:00:00.000Z',
        marketStatus: 'preopen',
        indices: [
          expect.objectContaining({
            id: 'sse',
            price: 3831.382,
            previousClose: 3832.262,
            open: 3831.822,
            high: 3832.262,
            low: 3830.502,
            change: -0.88,
            changePercent: -0.023,
            amount: 534_600_000_000,
            marketTime: '2026-08-03 08:50:00',
          }),
          expect.objectContaining({ id: 'szse', price: 12266.314, amount: 402_300_000_000 }),
          expect.objectContaining({ id: 'chinext', price: 2681.183, amount: 198_700_000_000 }),
          expect.objectContaining({ id: 'star50', price: 1045.761, amount: 86_500_000_000 }),
        ],
        unavailable: [],
      },
    })
    expect(fetcher).toHaveBeenCalledTimes(1)
    expect(fetcher).toHaveBeenCalledWith(
      'https://qt.gtimg.cn/q=sh000001,sz399001,sz399006,sh000680',
      expect.objectContaining({
        method: 'GET',
        headers: expect.objectContaining({ Accept: 'text/plain, */*' }),
        redirect: 'error',
      }),
    )
  })

  it('returns the seven-asset global strip through one Sina request', async () => {
    const fetcher = vi.fn(async () => sinaResponse(SINA_GLOBAL_RESPONSE))
    const result = await createStockMarketRpcHandler({
      fetcher: fetcher as unknown as typeof fetch,
      now: () => new Date('2026-08-12T02:45:00.000Z'),
    })(
      STOCK_MARKET_GLOBAL_QUOTES_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
      new AbortController().signal,
    )

    expect(result).toEqual({
      ok: true,
      value: {
        protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
        fetchedAt: '2026-08-12T02:45:00.000Z',
        quotes: [
          expect.objectContaining({ id: 'sse', price: 3942.14, previousClose: 3934.09, open: 3933.55, high: 3943.71, low: 3927.55 }),
          expect.objectContaining({ id: 'hangSeng', price: 25374.68, previousClose: 25652.82, change: -278.14, changePercent: -1.08 }),
          expect.objectContaining({ id: 'nasdaq', price: 22484.07, change: 99.37, changePercent: 0.44 }),
          expect.objectContaining({ id: 'kospi', price: 6606.37, previousClose: 6345.53, open: 6438.5, high: 6621.29, low: 6413.5 }),
          expect.objectContaining({ id: 'nikkei', price: 67039.96, marketTime: '2026-08-12 10:30:01' }),
          expect.objectContaining({ id: 'brent', price: 89.647, previousClose: 88.91, open: 89.17, high: 89.73, low: 89.08 }),
          expect.objectContaining({ id: 'newYorkGold', price: 4465.286, previousClose: 4441.1, open: 4430, high: 4467.6, low: 4421.4 }),
        ],
        unavailable: [],
      },
    })
    expect(fetcher).toHaveBeenCalledOnce()
    expect(fetcher).toHaveBeenCalledWith(
      'https://hq.sinajs.cn/list=sh000001,int_hangseng,int_nasdaq,b_KOSPI,b_NKY,hf_OIL,hf_GC',
      expect.objectContaining({
        method: 'GET',
        headers: expect.objectContaining({ Referer: 'https://finance.sina.com.cn/' }),
        redirect: 'error',
      }),
    )
  })

  it('uses the dedicated global-quote request instead of the business Sina endpoint', async () => {
    const stockApiService = {
      requestSinaGlobalQuotes: vi.fn(async () => ({ quotes: [] })),
      executeSina: vi.fn(),
    } as unknown as StockApiService
    const result = await createStockMarketRpcHandler({ stockApiService })(
      STOCK_MARKET_GLOBAL_QUOTES_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
      new AbortController().signal,
    )

    expect(result).toEqual(expect.objectContaining({ ok: false }))
    expect(stockApiService.requestSinaGlobalQuotes).toHaveBeenCalledWith(expect.any(AbortSignal))
    expect(stockApiService.executeSina).not.toHaveBeenCalled()
  })

  it('keeps available global assets when one upstream quote is missing', async () => {
    const partial = SINA_GLOBAL_RESPONSE
      .split('\n')
      .filter(line => !line.includes('hq_str_b_KOSPI'))
      .join('\n')
    const result = await createStockMarketRpcHandler({
      fetcher: vi.fn(async () => sinaResponse(partial)) as unknown as typeof fetch,
    })(
      STOCK_MARKET_GLOBAL_QUOTES_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
      new AbortController().signal,
    )

    expect(result).toEqual({
      ok: true,
      value: expect.objectContaining({
        quotes: expect.not.arrayContaining([expect.objectContaining({ id: 'kospi' })]),
        unavailable: ['kospi'],
      }),
    })
    if (!result.ok) throw new Error('全球行情请求失败')
    expect(isStockMarketGlobalQuotesResponse(result.value)).toBe(true)
  })

  it('aggregates credential-free breadth, trends, movers, and hotspots into bounded responses', async () => {
    const fetcher = vi.fn(async (url: string) => {
      const requested = new URL(url)
      if (requested.pathname.endsWith('/ulist.np/get')) {
        return responseWith({
          rc: 0,
          data: {
            diff: [
              { f12: '000001', f104: 718, f105: 1574, f106: 59 },
              { f12: '399001', f104: 858, f105: 1975, f106: 99 },
            ],
          },
        })
      }
      if (requested.pathname.endsWith('/trends2/get')) {
        return responseWith({
          rc: 0,
          data: {
            preClose: 100,
            trends: [
              '2026-08-03 09:30,100,101,102,99,10,1000,100.50',
              '2026-08-03 09:31,101,102,103,100,12,1200,101.25',
            ],
          },
        })
      }
      if (requested.pathname.endsWith('/clist/get')) {
        const market = requested.searchParams.get('fs') ?? ''
        if (market.startsWith('m:90')) {
          const suffix = market.endsWith('t:2') ? 'HY' : market.endsWith('t:3') ? 'GN' : 'DY'
          const names = market.endsWith('t:3')
            ? [
                '昨日连板_含一字',
                'ST板块',
                '微盘股',
                '人形机器人',
                '低空经济',
                '商业航天',
                '第三代半导体',
                '新能源车',
              ]
            : Array.from({ length: 5 }, (_, index) => `${suffix}热点${index + 1}`)
          return responseWith({
            rc: 0,
            data: {
              diff: names.map((name, index) => ({
                f12: `${suffix}${index + 1}`,
                f14: name,
                f3: 5 - index,
              })),
            },
          })
        }
        return responseWith({
          rc: 0,
          data: {
            diff: Array.from({ length: 5 }, (_, index) => ({
              f2: 20 + index,
              f3: 10 - index,
              f5: 100_000 + index,
              f6: 1_000_000_000 + index,
              f8: 12.5 - index,
              f12: `60000${index}`,
              f14: `实时股${index + 1}`,
              f62: 5_000_000_000 - index * 1_000_000_000,
            })),
          },
        })
      }
      throw new Error(`unexpected URL: ${url}`)
    })
    const now = () => new Date('2026-08-03T02:00:00.000Z')
    const stockApiService = new StockApiService({
      fetcher: fetcher as unknown as typeof fetch,
      sleep: async () => undefined,
      now,
    })
    const handler = createStockMarketRpcHandler({ stockApiService, now })
    const request = { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION }
    const signal = new AbortController().signal

    const breadth = await handler(STOCK_MARKET_BREADTH_ENDPOINT, request, signal)
    expect(breadth).toEqual({
      ok: true,
      value: expect.objectContaining({ breadth: { rising: 1576, falling: 3549, flat: 158 } }),
    })

    const trends = await handler(STOCK_MARKET_TRENDS_ENDPOINT, request, signal)
    expect(trends).toEqual({
      ok: true,
      value: expect.objectContaining({
        series: expect.arrayContaining([
          expect.objectContaining({
            id: 'sse',
            previousClose: 100,
            points: [
              { time: '2026-08-03 09:30', price: 101, averagePrice: 100.5 },
              { time: '2026-08-03 09:31', price: 102, averagePrice: 101.25 },
            ],
          }),
        ]),
        unavailable: [],
      }),
    })

    const movers = await handler(STOCK_MARKET_MOVERS_ENDPOINT, request, signal)
    expect(movers).toEqual({
      ok: true,
      value: expect.objectContaining({
        rankings: expect.objectContaining({
          gainers: expect.arrayContaining([expect.objectContaining({ code: '600000', changePercent: 10 })]),
          netInflow: expect.arrayContaining([expect.objectContaining({ code: '600000', netInflow: 5_000_000_000 })]),
          netOutflow: expect.arrayContaining([expect.objectContaining({ code: '600004', netInflow: 1_000_000_000 })]),
        }),
      }),
    })

    const hotspots = await handler(STOCK_MARKET_HOTSPOTS_ENDPOINT, request, signal)
    expect(hotspots).toEqual({
      ok: true,
      value: expect.objectContaining({
        groups: expect.objectContaining({
          industry: expect.arrayContaining([expect.objectContaining({ code: 'HY1', name: 'HY热点1' })]),
          concept: expect.arrayContaining([
            expect.objectContaining({ name: '人形机器人' }),
            expect.objectContaining({ name: '低空经济' }),
            expect.objectContaining({ name: '新能源车' }),
          ]),
        }),
      }),
    })
    if (!hotspots.ok || !isStockMarketHotspotsResponse(hotspots.value)) {
      throw new Error('板块热点响应失败')
    }
    expect(Object.keys(hotspots.value.groups)).toEqual(['industry', 'concept'])
    expect(hotspots.value.groups.industry).toHaveLength(5)
    expect(hotspots.value.groups.concept).toHaveLength(5)
    // 涨停梯队与风格统计类板块不进入概念热点
    expect(JSON.stringify(hotspots)).not.toContain('昨日连板')
    expect(JSON.stringify(hotspots)).not.toContain('ST板块')
    expect(JSON.stringify(hotspots)).not.toContain('微盘股')
    const hotspotRequests = fetcher.mock.calls
      .map(([url]) => new URL(url))
      .filter(url => url.pathname.endsWith('/clist/get') && url.searchParams.get('fs')?.startsWith('m:90'))
    expect(hotspotRequests.map(url => url.searchParams.get('fs'))).toEqual(['m:90+t:2', 'm:90+t:3'])
    expect(hotspotRequests.find(url => url.searchParams.get('fs') === 'm:90+t:3')?.searchParams.get('pz')).toBe('30')
    expect(fetcher.mock.calls.some(([url]) => new URL(url).searchParams.get('fid') === 'f62')).toBe(true)
  })

  it('keeps a fully filtered concept list as a valid empty result', async () => {
    const fetcher = vi.fn(async (input: string | URL | Request) => {
      const requested = new URL(String(input))
      const concept = requested.searchParams.get('fs') === 'm:90+t:3'
      return responseWith({
        rc: 0,
        data: {
          diff: concept
            ? [{ f12: 'BK1', f14: '昨日连板_含一字', f3: 8.2 }]
            : [{ f12: 'HY1', f14: '半导体', f3: 3.1 }],
        },
      })
    })
    const now = () => new Date('2026-08-03T02:00:00.000Z')
    const handler = createStockMarketRpcHandler({
      now,
      stockApiService: new StockApiService({
        fetcher: fetcher as unknown as typeof fetch,
        sleep: async () => undefined,
        now,
      }),
    })

    const result = await handler(
      STOCK_MARKET_HOTSPOTS_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
      new AbortController().signal,
    )

    expect(result.ok).toBe(true)
    if (!result.ok) return
    expect(isStockMarketHotspotsResponse(result.value)).toBe(true)
    expect((result.value as { groups: { concept: unknown[] } }).groups.concept).toEqual([])
  })

  it('does not fabricate zero money flow when Eastmoney omits f62', async () => {
    const fetcher = vi.fn(async () => responseWith({
      rc: 0,
      data: {
        diff: [{ f2: 20, f3: 5, f12: '600000', f14: '浦发银行' }],
      },
    }))
    const now = () => new Date('2026-08-03T02:00:00.000Z')
    const handler = createStockMarketRpcHandler({
      now,
      stockApiService: new StockApiService({
        fetcher: fetcher as unknown as typeof fetch,
        sleep: async () => undefined,
        now,
      }),
    })

    const result = await handler(
      STOCK_MARKET_MOVERS_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
      new AbortController().signal,
    )

    expect(result.ok).toBe(false)
    expect(JSON.stringify(result)).not.toContain('"netInflow":0')
  })

  it('returns bounded headlines and flash news from the real Eastmoney assignment wrapper', async () => {
    const upstream = {
      rc: 1,
      LivesList: [
        { id: 'a1', title: '江波龙(301308.SZ)发布公告', showtime: '2026-08-03 08:50:00', digest: '摘要一' },
        { id: 'a2', title: '两市成交额突破万亿', showtime: '2026-08-03 09:10:00', summary: '摘要二' },
        { id: 'bad', title: '', showtime: '2026-08-03 09:10:00', digest: '无标题应被过滤' },
      ],
    }
    const fetcher = vi.fn(async () => new Response(`var ajaxResult=${JSON.stringify(upstream)};`))
    const handler = createStockMarketRpcHandler({
      fetcher: fetcher as unknown as typeof fetch,
      now: () => new Date('2026-08-03T01:00:00.000Z'),
    })
    const request = { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION }

    const headlines = await handler(
      STOCK_MARKET_HEADLINES_ENDPOINT,
      request,
      new AbortController().signal,
    )
    expect(headlines).toEqual({
      ok: true,
      value: {
        protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
        fetchedAt: '2026-08-03T01:00:00.000Z',
        items: [
          { id: 'a1', title: '江波龙(301308.SZ)发布公告', time: '2026-08-03 08:50:00', summary: '摘要一' },
          { id: 'a2', title: '两市成交额突破万亿', time: '2026-08-03 09:10:00', summary: '摘要二' },
        ],
      },
    })
    expect(JSON.stringify(headlines)).not.toContain('无标题应被过滤')
    expect(fetcher).toHaveBeenCalledWith(
      'https://newsapi.eastmoney.com/kuaixun/v1/getlist_101_ajaxResult_10_1_.html',
      expect.objectContaining({ method: 'GET' }),
    )

    const flash = await handler(
      STOCK_MARKET_FLASH_NEWS_ENDPOINT,
      request,
      new AbortController().signal,
    )
    expect(flash).toEqual({
      ok: true,
      value: {
        protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
        fetchedAt: '2026-08-03T01:00:00.000Z',
        items: [
          { id: 'a1', title: '江波龙(301308.SZ)发布公告', time: '2026-08-03 08:50:00', summary: '摘要一' },
          { id: 'a2', title: '两市成交额突破万亿', time: '2026-08-03 09:10:00', summary: '摘要二' },
        ],
      },
    })
    expect(fetcher).toHaveBeenCalledWith(
      'https://newsapi.eastmoney.com/kuaixun/v1/getlist_102_ajaxResult_10_1_.html',
      expect.objectContaining({ method: 'GET' }),
    )
  })

  it('coalesces concurrent cold index requests while preserving caller cancellation', async () => {
    let release: ((response: Response) => void) | undefined
    const fetcher = vi.fn(() => new Promise<Response>((resolve) => { release = resolve }))
    const handler = createStockMarketRpcHandler({
      fetcher: fetcher as unknown as typeof fetch,
      now: () => new Date('2026-08-03T01:00:00.000Z'),
    })
    const payload = { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION }
    const firstController = new AbortController()
    const secondController = new AbortController()

    const first = handler(STOCK_MARKET_INDICES_ENDPOINT, payload, firstController.signal)
    const second = handler(STOCK_MARKET_INDICES_ENDPOINT, payload, secondController.signal)
    await vi.waitFor(() => { expect(fetcher).toHaveBeenCalledOnce() })

    firstController.abort()
    await expect(first).resolves.toMatchObject({ ok: false, error: { code: 'cancelled' } })
    release?.(tencentResponse(TENCENT_INDEX_RESPONSE))
    await expect(second).resolves.toMatchObject({ ok: true })
    expect(fetcher).toHaveBeenCalledOnce()
  })

  it('rejects an oversized streamed Tencent quote response before buffering it all', async () => {
    let cancelledBody = false
    const response = new Response(new ReadableStream<Uint8Array>({
      start(controller) {
        controller.enqueue(new Uint8Array(40 * 1024))
        controller.enqueue(new Uint8Array(40 * 1024))
      },
      cancel() { cancelledBody = true },
    }))
    const fetcher = vi.fn(async () => response)
    const result = await createStockMarketRpcHandler({
      fetcher: fetcher as unknown as typeof fetch,
    })(
      STOCK_MARKET_INDICES_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
      new AbortController().signal,
    )

    expect(result.ok).toBe(false)
    expect(cancelledBody).toBe(true)
    expect(fetcher).toHaveBeenCalledOnce()
  })

  it('reuses successful index snapshots within their bounded freshness windows', async () => {
    let nowMs = 0
    const fetcher = vi.fn(async () => tencentResponse(TENCENT_INDEX_RESPONSE))
    const handler = createStockMarketRpcHandler({
      fetcher: fetcher as unknown as typeof fetch,
      now: () => new Date(nowMs),
    })
    const request = { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION }

    await handler(STOCK_MARKET_INDICES_ENDPOINT, request, new AbortController().signal)
    await handler(STOCK_MARKET_INDICES_ENDPOINT, request, new AbortController().signal)
    expect(fetcher).toHaveBeenCalledTimes(1)

    nowMs += 5_001
    await handler(STOCK_MARKET_INDICES_ENDPOINT, request, new AbortController().signal)
    expect(fetcher).toHaveBeenCalledTimes(2)
  })

  it('keeps available indices when one Tencent quote is missing', async () => {
    const partialResponse = TENCENT_INDEX_RESPONSE
      .split('\n')
      .filter(line => !line.startsWith('v_sz399001='))
      .join('\n')
    const fetcher = vi.fn(async (url: string) => tencentIndexResponse(url, partialResponse))
    const result = await createStockMarketRpcHandler({
      fetcher: fetcher as unknown as typeof fetch,
      now: () => new Date('2026-08-03T01:00:00.000Z'),
    })(
      STOCK_MARKET_INDICES_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
      new AbortController().signal,
    )

    expect(result).toEqual({
      ok: true,
      value: expect.objectContaining({
        indices: [
          expect.objectContaining({ id: 'sse' }),
          expect.objectContaining({ id: 'chinext' }),
          expect.objectContaining({ id: 'star50' }),
        ],
        unavailable: ['szse'],
      }),
    })
  })

  it('keeps current Tencent indices independent from historical turnover requests', async () => {
    const fetcher = vi.fn(async (url: string) => {
      if (url.startsWith('https://qt.gtimg.cn/')) return tencentResponse(TENCENT_INDEX_RESPONSE)
      return new Response('upstream unavailable', { status: 503 })
    })
    const result = await createStockMarketRpcHandler({
      fetcher: fetcher as unknown as typeof fetch,
      now: () => new Date('2026-08-03T01:00:00.000Z'),
    })(
      STOCK_MARKET_INDICES_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
      new AbortController().signal,
    )

    expect(result).toEqual({
      ok: true,
      value: expect.objectContaining({
        indices: expect.arrayContaining([
          expect.objectContaining({ id: 'sse', amount: 534_600_000_000 }),
          expect.objectContaining({ id: 'szse', amount: 402_300_000_000 }),
        ]),
        unavailable: [],
      }),
    })
  })

  it('reports a Tencent upstream failure without exposing its response', async () => {
    const fetcher = vi.fn(async () => new Response('upstream detail', { status: 503 }))
    const result = await createStockMarketRpcHandler({
      fetcher: fetcher as unknown as typeof fetch,
    })(
      STOCK_MARKET_INDICES_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
      new AbortController().signal,
    )

    expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.error.message).toBe('暂时无法获取指数行情。')
      expect(JSON.stringify(result)).not.toContain('upstream detail')
    }
  })

  it('returns Tencent two-market turnover compared with the previous trading day at the same minute', async () => {
    let nowMs = new Date('2026-08-04T02:15:30.000Z').getTime()
    const fetcher = vi.fn(async (url: string) => {
      if (url === 'https://qt.gtimg.cn/q=sh000001,sz399106') return tencentResponse(TENCENT_TURNOVER_QUOTE_RESPONSE)
      if (url.endsWith('code=sh000001')) return tencentHistoryResponse('sh000001', TENCENT_TURNOVER_DAYS.sh000001)
      if (url.endsWith('code=sz399106')) return tencentHistoryResponse('sz399106', TENCENT_TURNOVER_DAYS.sz399106)
      throw new Error(`unexpected URL: ${url}`)
    })
    const handler = createStockMarketRpcHandler({
      fetcher: fetcher as unknown as typeof fetch,
      now: () => new Date(nowMs),
    })
    const request = { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION }

    const result = await handler(STOCK_MARKET_TURNOVER_ENDPOINT, request, new AbortController().signal)

    expect(result).toEqual({
      ok: true,
      value: expect.objectContaining({
        protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
        fetchedAt: '2026-08-04T02:15:30.000Z',
        tradeDate: '2026-08-04',
        previousTradeDate: '2026-08-03',
        todayAmount: 1_020_000_000_000,
        previousAmount: 1_000_000_000_000,
      }),
    })
    if (!result.ok || !isStockMarketTurnoverResponse(result.value)) {
      throw new Error('expected a valid turnover response')
    }
    expect(result.value.changePercent).toBeCloseTo(2, 4)
    expect(fetcher).toHaveBeenCalledTimes(3)
    expect(fetcher).toHaveBeenCalledWith(
      'https://qt.gtimg.cn/q=sh000001,sz399106',
      expect.objectContaining({
        method: 'GET',
        headers: expect.objectContaining({ Accept: 'text/plain, */*' }),
      }),
    )
    expect(fetcher).toHaveBeenCalledWith(
      'https://web.ifzq.gtimg.cn/appstock/app/day/query?code=sh000001',
      expect.objectContaining({
        method: 'GET',
        headers: expect.objectContaining({ Accept: 'application/json, text/plain, */*' }),
      }),
    )
    expect(fetcher).toHaveBeenCalledWith(
      'https://web.ifzq.gtimg.cn/appstock/app/day/query?code=sz399106',
      expect.objectContaining({
        method: 'GET',
        headers: expect.objectContaining({ Accept: 'application/json, text/plain, */*' }),
      }),
    )

    await handler(STOCK_MARKET_TURNOVER_ENDPOINT, request, new AbortController().signal)
    expect(fetcher).toHaveBeenCalledTimes(3)

    nowMs += 10_001
    await handler(STOCK_MARKET_TURNOVER_ENDPOINT, request, new AbortController().signal)
    expect(fetcher).toHaveBeenCalledTimes(4)
  })

  it('aligns Tencent turnover history by the latest shared trading date', async () => {
    const fetcher = vi.fn(async (url: string) => {
      if (url === 'https://qt.gtimg.cn/q=sh000001,sz399106') return tencentResponse(TENCENT_TURNOVER_QUOTE_RESPONSE)
      if (url.endsWith('code=sh000001')) return tencentHistoryResponse('sh000001', TENCENT_TURNOVER_DAYS.sh000001)
      if (url.endsWith('code=sz399106')) {
        return tencentHistoryResponse('sz399106', [
          turnoverDay('20260804', [['1015', 560_000_000_000]]),
          turnoverDay('20260731', [['1015', 500_000_000_000]]),
        ])
      }
      throw new Error(`unexpected URL: ${url}`)
    })
    const result = await createStockMarketRpcHandler({
      fetcher: fetcher as unknown as typeof fetch,
    })(
      STOCK_MARKET_TURNOVER_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
      new AbortController().signal,
    )

    expect(result).toEqual({
      ok: true,
      value: expect.objectContaining({
        tradeDate: '2026-08-04',
        previousTradeDate: '2026-07-31',
        todayAmount: 1_020_000_000_000,
        previousAmount: 900_000_000_000,
      }),
    })
  })

  it('keeps turnover unavailable when either Tencent market history fails', async () => {
    const fetcher = vi.fn(async (url: string) => {
      if (url === 'https://qt.gtimg.cn/q=sh000001,sz399106') return tencentResponse(TENCENT_TURNOVER_QUOTE_RESPONSE)
      if (url.endsWith('code=sh000001')) return tencentHistoryResponse('sh000001', TENCENT_TURNOVER_DAYS.sh000001)
      if (url.endsWith('code=sz399106')) return new Response('upstream unavailable', { status: 503 })
      throw new Error(`unexpected URL: ${url}`)
    })
    const result = await createStockMarketRpcHandler({
      fetcher: fetcher as unknown as typeof fetch,
    })(
      STOCK_MARKET_TURNOVER_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
      new AbortController().signal,
    )

    expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.error.code).toBe('internal')
      expect(result.error.message).toBe('暂时无法获取上一交易日同期成交额。')
    }
  })

  it('fetches Tencent indices without credentials', async () => {
    const fetcher = vi.fn(async (url: string) => tencentIndexResponse(url))
    const result = await createStockMarketRpcHandler({
      fetcher: fetcher as unknown as typeof fetch,
    })(
      STOCK_MARKET_INDICES_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
      new AbortController().signal,
    )

    expect(result.ok).toBe(true)
    expect(fetcher).toHaveBeenCalledTimes(1)
  })

  it.each([
    undefined,
    null,
    {},
    { protocolVersion: 2 },
    { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION, extra: true },
  ])('rejects a non-strict health payload: %j', async (payload) => {
    const result = await createStockMarketRpcHandler()(
      STOCK_MARKET_HEALTH_ENDPOINT,
      payload,
      new AbortController().signal,
    )

    expect(result.ok).toBe(false)
    if (!result.ok) expect(result.error.code).toBe('bad-request')
  })

  it('rejects a non-strict market-indices payload', async () => {
    const result = await createStockMarketRpcHandler()(
      STOCK_MARKET_INDICES_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION, extra: true },
      new AbortController().signal,
    )

    expect(result.ok).toBe(false)
    if (!result.ok) expect(result.error.code).toBe('bad-request')
  })

  it('rejects incomplete index response coverage', () => {
    expect(isStockMarketIndicesResponse({
      protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
      fetchedAt: '2026-08-03T01:00:00.000Z',
      marketStatus: 'closed',
      indices: [],
      unavailable: [],
    })).toBe(false)
  })

  it('rejects incomplete global quote response coverage', () => {
    expect(isStockMarketGlobalQuotesResponse({
      protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION,
      fetchedAt: '2026-08-03T01:00:00.000Z',
      quotes: [],
      unavailable: [],
    })).toBe(false)
  })

  it('rejects unknown endpoints', async () => {
    const result = await createStockMarketRpcHandler()(
      'quotes',
      {},
      new AbortController().signal,
    )

    expect(result.ok).toBe(false)
    if (!result.ok) expect(result.error.code).toBe('bad-request')
  })

  it('honors an already-aborted request', async () => {
    const controller = new AbortController()
    controller.abort()
    const result = await createStockMarketRpcHandler()(
      STOCK_MARKET_HEALTH_ENDPOINT,
      { protocolVersion: STOCK_MARKET_RPC_PROTOCOL_VERSION },
      controller.signal,
    )

    expect(result.ok).toBe(false)
    if (!result.ok) expect(result.error.code).toBe('cancelled')
  })
})

function tencentIndexResponse(url: string, quoteResponse = TENCENT_INDEX_RESPONSE): Response {
  if (url === 'https://qt.gtimg.cn/q=sh000001,sz399001,sz399006,sh000680') {
    return tencentResponse(quoteResponse)
  }
  throw new Error(`unexpected URL: ${url}`)
}

function tencentResponse(payload: string): Response {
  return new Response(payload, {
    status: 200,
    headers: { 'Content-Type': 'text/plain; charset=GBK' },
  })
}

function sinaResponse(payload: string): Response {
  return new Response(payload, {
    status: 200,
    headers: { 'Content-Type': 'text/plain; charset=GBK' },
  })
}

function sinaAShareQuote(
  symbol: string,
  price: number,
  previousClose: number,
  open: number,
  high: number,
  low: number,
): string {
  const fields = Array.from({ length: 33 }, () => '')
  fields[0] = 'SSE Composite'
  fields[1] = String(open)
  fields[2] = String(previousClose)
  fields[3] = String(price)
  fields[4] = String(high)
  fields[5] = String(low)
  fields[30] = '2026-08-12'
  fields[31] = '10:44:05'
  fields[32] = '00'
  return `var hq_str_${symbol}="${fields.join(',')}";`
}

function tencentHistoryResponse(code: string, days: ReadonlyArray<unknown>): Response {
  return responseWith({ code: 0, msg: '', data: { [code]: { data: days } } })
}

function turnoverDay(
  date: string,
  points: ReadonlyArray<readonly [minute: string, amount: number]>,
): { date: string; data: string[] } {
  return {
    date,
    data: points.map(([minute, amount]) => `${minute} 1.00 1 ${amount}`),
  }
}

function tencentQuote(
  code: string,
  price: number,
  change: number,
  changePercent: number,
  amount: number,
  marketTime = '20260803085000',
): string {
  const fields = Array.from({ length: 38 }, () => '')
  fields[0] = '1'
  fields[1] = 'INDEX'
  fields[2] = code.slice(2)
  fields[3] = String(price)
  fields[4] = String(price - change)
  fields[5] = String(price - change / 2)
  fields[30] = marketTime
  fields[31] = String(change)
  fields[32] = String(changePercent)
  fields[33] = String(price + Math.abs(change))
  fields[34] = String(price - Math.abs(change))
  fields[35] = `${price}/1/${amount}`
  fields[37] = String(amount / 10_000)
  return `v_${code}="${fields.join('~')}";`
}

function responseWith(payload: unknown): Response {
  return new Response(JSON.stringify(payload), {
    status: 200,
    headers: { 'Content-Type': 'application/json' },
  })
}
