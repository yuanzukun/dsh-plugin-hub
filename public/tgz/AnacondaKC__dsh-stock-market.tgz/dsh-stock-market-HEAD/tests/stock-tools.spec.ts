import { describe, expect, it, vi } from 'vitest'
import type { Context } from '@deepseek-ai/cordis'
import type { ToolDefinition } from '@deepseek-ai/dsh-tools'
import {
  EASTMONEY_ENDPOINTS,
  SINA_ENDPOINTS,
  TENCENT_ENDPOINTS,
  TONGHUASHUN_ENDPOINTS,
  providerEndpointCount,
} from '../src/stock-api/catalog.ts'
import { StockApiError } from '../src/stock-api/errors.ts'
import { StockApiService } from '../src/stock-api/service.ts'
import { STOCK_INTERFACE_SUMMARIES } from '../src/stock-api/interface-summary.ts'
import {
  STOCK_ACTION_ADAPTERS,
  STOCK_AGENT_TOOL_NAMES,
} from '../src/stock-agent-contract.ts'
import {
  createStockMarketTools,
  registerStockMarketTools,
} from '../src/stock-tools.ts'

describe('stock market tools', () => {
  it('keeps the client interface summary counts aligned with the executable catalogs', () => {
    for (const summary of STOCK_INTERFACE_SUMMARIES) {
      expect(summary.endpointCount).toBe(providerEndpointCount(summary.provider))
    }
  })

  it('publishes exactly the nine business-semantic tools', () => {
    const tools = createStockMarketTools(new StockApiService())
    expect(tools.map(tool => tool.name)).toEqual(STOCK_AGENT_TOOL_NAMES)
    expect(tools).toHaveLength(9)
    expect(tools.map(tool => tool.name)).not.toContain('stock_api_catalog')
    expect(tools.map(tool => tool.name)).not.toContain('stock_eastmoney')
  })

  it('maps every one of the 57 internal interfaces to at least one business action', () => {
    const catalogIds = [
      ...EASTMONEY_ENDPOINTS,
      ...TENCENT_ENDPOINTS,
      ...SINA_ENDPOINTS,
      ...TONGHUASHUN_ENDPOINTS,
    ].map(endpoint => endpoint.id)
    const mappedIds = new Set(Object.values(STOCK_ACTION_ADAPTERS).flat())

    expect(catalogIds).toHaveLength(57)
    expect([...new Set(catalogIds)]).toHaveLength(57)
    expect(catalogIds.filter(id => !mappedIds.has(id))).toEqual([])
  })

  it('registers all nine tools', () => {
    const register = vi.fn()
    const ctx = { tools: { register } } as unknown as Context

    registerStockMarketTools(ctx, new StockApiService())

    expect(register).toHaveBeenCalledTimes(9)
    expect(register.mock.calls.map(call => (call[0] as ToolDefinition).name)).toEqual(STOCK_AGENT_TOOL_NAMES)
  })

  it('discovers actions without exposing internal endpoint ids', async () => {
    const tool = findTool(createStockMarketTools(new StockApiService()), 'stock_capabilities')
    const output = await runTool(tool, { action: 'describe', tool: 'stock_chart' })
    const parsed = JSON.parse(output as string) as {
      data: { name: string; actions: Array<{ name: string; parameters: string[] }> }
    }

    expect(parsed.data.name).toBe('stock_chart')
    expect(parsed.data.actions.map(action => action.name)).toEqual(['kline', 'intraday'])
    expect(output).not.toContain('em_price_history')
    expect(output).not.toContain('endpoint_id')
  })

  it('rejects parameters belonging to another action before any provider call', async () => {
    const service = {
      executeEastMoney: vi.fn(),
      executeTencent: vi.fn(),
      executeSina: vi.fn(),
      executeTonghuashun: vi.fn(),
    } as unknown as StockApiService
    const tool = findTool(createStockMarketTools(service), 'stock_chart')

    await expect(runTool(tool, {
      action: 'intraday',
      symbol: '600519.SH',
      period: 'day',
    })).rejects.toThrow('intraday 不接受参数：period')
    expect(service.executeEastMoney).not.toHaveBeenCalled()
  })

  it('falls back from Tencent to EastMoney and keeps a normalized quote contract', async () => {
    const service = {
      executeTencent: vi.fn(async () => {
        throw new StockApiError('腾讯暂时不可用。', 'upstream')
      }),
      executeEastMoney: vi.fn(async () => ({
        provider: 'eastmoney',
        endpointId: 'em_batch_quotes',
        endpointName: '批量实时行情',
        fetchedAt: '2026-08-11T01:30:00.000Z',
        data: {
          rc: 0,
          data: {
            diff: [{ f12: '600519', f14: '贵州茅台', f2: 1400, f3: 1.2, f4: 16.6, f5: 123, f6: 456789 }],
          },
        },
      })),
      executeSina: vi.fn(),
    } as unknown as StockApiService
    const tool = findTool(createStockMarketTools(service), 'stock_quote')

    const output = await runTool(tool, {
      action: 'snapshot',
      symbols: ['600519.SH'],
      detail: 'full',
    })
    const parsed = JSON.parse(output as string) as {
      source: string
      attempted_sources: string[]
      fallback_used: boolean
      degraded: boolean
      data: { quotes: Array<Record<string, unknown>> }
      warnings: string[]
    }

    expect(parsed).toMatchObject({
      source: 'eastmoney',
      attempted_sources: ['tencent', 'eastmoney'],
      fallback_used: true,
      degraded: false,
    })
    expect(parsed.data.quotes[0]).toMatchObject({
      symbol: '600519.SH',
      name: '贵州茅台',
      price: 1400,
      change_percent: 1.2,
      volume_shares: 12300,
      amount: 456789,
      amount_currency: 'CNY',
    })
    expect(parsed.warnings.join('')).toContain('已切换')
  })

  it('does not assign unmatched or non-SH/SZ EastMoney rows to requested quotes', async () => {
    const service = {
      executeEastMoney: vi.fn(async () => ({
        provider: 'eastmoney',
        endpointId: 'em_batch_quotes',
        endpointName: '批量实时行情',
        fetchedAt: '2026-08-12T02:30:00.000Z',
        data: {
          rc: 0,
          data: {
            diff: [
              { f12: '000001', f13: 1, f14: '错误市场', f2: 1 },
              { f12: '430047', f13: 2, f14: '北交所证券', f2: 2 },
              { f12: '600519', f13: 1, f14: '贵州茅台', f2: 1400 },
            ],
          },
        },
      })),
    } as unknown as StockApiService
    const tool = findTool(createStockMarketTools(service), 'stock_quote')

    const output = await runTool(tool, {
      action: 'snapshot', symbols: ['000001.SZ', '600519.SH'], source: 'eastmoney',
    })
    const parsed = JSON.parse(output as string) as {
      data: { quotes: Array<{ symbol: string }>; unavailable_symbols: string[] }
    }

    expect(parsed.data.quotes).toEqual([expect.objectContaining({ symbol: '600519.SH' })])
    expect(parsed.data.unavailable_symbols).toEqual(['000001.SZ'])
  })

  it('returns all requested quote symbols as unavailable when no upstream row matches', async () => {
    const service = {
      executeTencent: vi.fn(async () => ({
        provider: 'tencent',
        endpointId: 'tx_realtime_quotes',
        endpointName: '批量实时行情',
        fetchedAt: '2026-08-12T02:30:00.000Z',
        data: { quotes: [{ symbol: 'sh600000', name: '浦发银行', price: 10 }] },
      })),
    } as unknown as StockApiService
    const tool = findTool(createStockMarketTools(service), 'stock_quote')

    const output = await runTool(tool, {
      action: 'snapshot', symbols: ['600519.SH'], source: 'tencent',
    })
    const parsed = JSON.parse(output as string) as {
      data: { quotes: unknown[]; unavailable_symbols: string[] }
    }

    expect(parsed.data.quotes).toEqual([])
    expect(parsed.data.unavailable_symbols).toEqual(['600519.SH'])
  })

  it('rejects non-SH/SZ symbols before calling a provider', async () => {
    const service = {
      executeTencent: vi.fn(),
      executeEastMoney: vi.fn(),
      executeSina: vi.fn(),
    } as unknown as StockApiService
    const tool = findTool(createStockMarketTools(service), 'stock_quote')

    await expect(runTool(tool, {
      action: 'snapshot', symbols: ['430047.BJ'],
    })).rejects.toThrow('证券代码格式无效')
    await expect(runTool(tool, {
      action: 'snapshot', symbols: ['600519.SZ'],
    })).rejects.toThrow('证券代码格式无效')
    expect(service.executeTencent).not.toHaveBeenCalled()
  })

  it('keeps stock ranking requests within the SH/SZ all_a market filter', async () => {
    const service = {
      executeEastMoney: vi.fn(async () => ({
        provider: 'eastmoney',
        endpointId: 'em_market_snapshot',
        endpointName: '全市场行情排行',
        fetchedAt: '2026-08-12T02:30:00.000Z',
        data: { rc: 0, data: { diff: [] } },
      })),
    } as unknown as StockApiService
    const tool = findTool(createStockMarketTools(service), 'stock_ranking')

    const output = await runTool(tool, { action: 'stocks', source: 'eastmoney' })
    expect(JSON.parse(output as string)).toMatchObject({ data: { items: [] } })
    expect(service.executeEastMoney).toHaveBeenCalledWith(
      'em_market_snapshot',
      expect.objectContaining({ market: 'all_a' }),
      expect.any(AbortSignal),
    )
  })
  it('normalizes Tencent minute K-lines and maps 5m to the m5 response key', async () => {
    const service = {
      executeTencent: vi.fn(async () => ({
        provider: 'tencent',
        endpointId: 'tx_price_history',
        endpointName: '历史 K 线',
        fetchedAt: '2026-08-11T01:30:00.000Z',
        data: {
          code: 0,
          data: {
            sh600519: {
              m5: [
                ['2026-08-11 09:35', '1348.00', '1349.00', '1350.00', '1347.00', '274'],
                ['2026-08-11 09:40', '1349.00', '1351.00', '1352.00', '1348.00', '300'],
              ],
            },
          },
        },
      })),
    } as unknown as StockApiService
    const tool = findTool(createStockMarketTools(service), 'stock_chart')

    const output = await runTool(tool, {
      action: 'kline', symbol: '600519.SH', period: '5m', source: 'tencent',
    })
    const parsed = JSON.parse(output as string) as {
      degraded: boolean
      data: { bars: Array<Record<string, unknown>> }
      warnings: string[]
    }

    expect(service.executeTencent).toHaveBeenCalledWith(
      'tx_price_history',
      expect.objectContaining({ symbol: 'sh600519', period: 'm5' }),
      expect.any(AbortSignal),
    )
    expect(parsed.data.bars).toEqual([
      expect.objectContaining({ time: '2026-08-11 09:35', open: 1348, close: 1349, high: 1350, low: 1347, volume_shares: 27400, amount: null }),
      expect.objectContaining({ time: '2026-08-11 09:40', open: 1349, close: 1351, high: 1352, low: 1348, volume_shares: 30000, amount: null }),
    ])
    expect(parsed.degraded).toBe(true)
    expect(parsed.warnings.join('')).toContain('不提供成交额')
  })

  it('normalizes EastMoney sector net inflow as sector money flow', async () => {
    const service = {
      executeEastMoney: vi.fn(async () => ({
        provider: 'eastmoney',
        endpointId: 'em_market_snapshot',
        endpointName: '市场排行',
        fetchedAt: '2026-08-12T02:30:00.000Z',
        data: {
          rc: 0,
          data: {
            diff: [{ f12: 'BK1215', f14: '通信', f3: 2.01, f6: 100_637_472_910, f62: 7_954_440_960 }],
          },
        },
      })),
    } as unknown as StockApiService
    const tool = findTool(createStockMarketTools(service), 'stock_money_flow')

    const output = await runTool(tool, {
      action: 'sector', sector_type: 'industry', limit: 5, source: 'eastmoney',
    })
    const parsed = JSON.parse(output as string) as {
      source: string
      data: { sector_type: string; items: Array<Record<string, unknown>> }
    }

    expect(service.executeEastMoney).toHaveBeenCalledWith(
      'em_market_snapshot',
      expect.objectContaining({ market: 'industry', sort: 'net_inflow', order: 'desc', page: 1, limit: 5 }),
      expect.any(AbortSignal),
    )
    expect(parsed.source).toBe('eastmoney')
    expect(parsed.data).toMatchObject({
      sector_type: 'industry',
      items: [expect.objectContaining({
        id: 'BK1215',
        name: '通信',
        change_percent: 2.01,
        amount: 100_637_472_910,
        net_inflow: 7_954_440_960,
      })],
    })
  })

  it('treats an empty Sina sector money-flow response as unavailable', async () => {
    const service = {
      executeSina: vi.fn(async () => ({
        provider: 'sina',
        endpointId: 'sina_sector_money_flow',
        endpointName: '板块资金流',
        fetchedAt: '2026-08-12T02:30:00.000Z',
        data: [],
      })),
    } as unknown as StockApiService
    const tool = findTool(createStockMarketTools(service), 'stock_money_flow')

    await expect(runTool(tool, {
      action: 'sector', sector_type: 'concept', source: 'sina',
    })).rejects.toThrow('板块资金流返回了无法解析的数据')
  })

  it('filters connect-flow placeholders, normalizes units, and applies limit last', async () => {
    const service = {
      executeEastMoney: vi.fn(async () => ({
        provider: 'eastmoney',
        endpointId: 'em_connect_flow',
        endpointName: '沪深港通资金',
        fetchedAt: '2026-08-12T02:30:00.000Z',
        data: {
          rc: 0,
          data: {
            s2nDate: '2026-08-12',
            n2sDate: '2026-08-12',
            s2n: [
              '9:30,10.00,5200000.00,20.00,5200000.00,30.00,0,0,0,0',
              '9:31,11.00,5300000.00,22.00,5300000.00,33.00,0,0,0,0',
              '9:32,-,-,-,-,-,-,-,-,-',
            ],
            n2s: [
              '9:00,1.00,4200000.00,2.00,4200000.00,3.00,0,0,0,0',
              '9:01,-,-,-,-,-,-,-,-,-',
            ],
          },
        },
      })),
    } as unknown as StockApiService
    const tool = findTool(createStockMarketTools(service), 'stock_money_flow')

    const output = await runTool(tool, { action: 'connect', limit: 1 })
    const parsed = JSON.parse(output as string) as {
      degraded: boolean
      data: Record<string, unknown>
      warnings: string[]
    }

    expect(parsed.data).toEqual({
      direction: 'all',
      amount_currency: 'CNY',
      unavailable_directions: [],
      northbound: [{
        date: '2026-08-12',
        time: '9:31',
        shanghai_leg_net_inflow: 110000,
        shenzhen_leg_net_inflow: 220000,
        total_net_inflow: 330000,
      }],
      southbound: [{
        date: '2026-08-12',
        time: '9:00',
        shanghai_leg_net_inflow: 10000,
        shenzhen_leg_net_inflow: 20000,
        total_net_inflow: 30000,
      }],
    })
    expect(parsed.degraded).toBe(false)
    expect(parsed.warnings).toEqual([])
  })

  it('returns available southbound flow and marks zero-only northbound as unavailable', async () => {
    const service = {
      executeEastMoney: vi.fn(async () => ({
        provider: 'eastmoney',
        endpointId: 'em_connect_flow',
        endpointName: '沪深港通资金',
        fetchedAt: '2026-08-12T02:30:00.000Z',
        data: {
          rc: 0,
          data: {
            s2nDate: '2026-08-12',
            n2sDate: '2026-08-12',
            s2n: ['9:30,0,0,0,0,0,0,0,0,0', '9:31,-,-,-,-,-,-,-,-,-'],
            n2s: ['9:00,-1,0,-2,0,-3,0,0,0,0'],
          },
        },
      })),
    } as unknown as StockApiService
    const tool = findTool(createStockMarketTools(service), 'stock_money_flow')

    const output = await runTool(tool, { action: 'connect', direction: 'all' })
    const parsed = JSON.parse(output as string) as {
      degraded: boolean
      warnings: string[]
      data: { unavailable_directions: string[]; northbound: unknown[]; southbound: unknown[] }
    }

    expect(parsed.data.unavailable_directions).toEqual(['northbound'])
    expect(parsed.data.northbound).toEqual([])
    expect(parsed.data.southbound).toHaveLength(1)
    expect(parsed.degraded).toBe(true)
    expect(parsed.warnings.join('')).toContain('北向')
  })

  it('rejects connect flow when the requested direction has no reported net inflow', async () => {
    const service = {
      executeEastMoney: vi.fn(async () => ({
        provider: 'eastmoney',
        endpointId: 'em_connect_flow',
        endpointName: '沪深港通资金',
        fetchedAt: '2026-08-12T02:30:00.000Z',
        data: {
          rc: 0,
          data: {
            s2n: ['9:30,0,0,0,0,0,0,0,0,0', '9:31,-,-,-,-,-,-,-,-,-'],
            n2s: ['9:00,0,1,0,1,0,0,0,0,0'],
          },
        },
      })),
    } as unknown as StockApiService
    const tool = findTool(createStockMarketTools(service), 'stock_money_flow')

    await expect(runTool(tool, {
      action: 'connect', direction: 'northbound',
    })).rejects.toThrow('connect 的免费数据源暂时不可用')
  })

  it('documents and enforces action-specific catalog and guba parameters', async () => {
    const service = {
      executeEastMoney: vi.fn(),
      executeTencent: vi.fn(),
      executeSina: vi.fn(),
      executeTonghuashun: vi.fn(),
    } as unknown as StockApiService
    const tools = createStockMarketTools(service)
    const ranking = findTool(tools, 'stock_ranking')
    const news = findTool(tools, 'stock_news')

    expect(ranking.description).toContain('sector_catalog 仅使用 sector_type/source，不接受 page/limit')
    expect(news.description).toContain('mode=search 必须使用 keyword')
    expect(news.description).toContain('mode=stock_page 必须使用 symbol')
    await expect(runTool(ranking, {
      action: 'sector_catalog', sector_type: 'industry', limit: 10,
    })).rejects.toThrow('sector_catalog 不接受参数：limit')
    await expect(runTool(news, {
      action: 'guba', mode: 'search', symbol: '600519.SH', keyword: '茅台',
    })).rejects.toThrow('mode=search 不接受参数：symbol')
    await expect(runTool(news, {
      action: 'guba', mode: 'stock_page', symbol: '600519.SH', limit: 10,
    })).rejects.toThrow('mode=stock_page 不接受参数：limit')
    expect(service.executeEastMoney).not.toHaveBeenCalled()
  })

  it('samples an intraday series across the whole session when limit is smaller', async () => {
    const service = {
      executeEastMoney: vi.fn(async () => ({
        provider: 'eastmoney',
        endpointId: 'em_intraday_trends',
        endpointName: '分时走势',
        fetchedAt: '2026-08-11T01:30:00.000Z',
        data: {
          rc: 0,
          data: {
            preClose: 100,
            trends: [
              '2026-08-11 09:30,100,100,100,100,1,100,100',
              '2026-08-11 10:30,100,101,101,100,2,202,100.5',
              '2026-08-11 11:30,101,102,102,101,3,306,101',
              '2026-08-11 14:00,102,103,103,102,4,412,102',
              '2026-08-11 15:00,103,104,104,103,5,520,103',
            ],
          },
        },
      })),
    } as unknown as StockApiService
    const tool = findTool(createStockMarketTools(service), 'stock_chart')

    const output = await runTool(tool, {
      action: 'intraday', symbol: '600519.SH', limit: 3, source: 'eastmoney',
    })
    const parsed = JSON.parse(output as string) as {
      data: { sampled: boolean; points: Array<{ time: string }> }
    }

    expect(parsed.data.sampled).toBe(true)
    expect(parsed.data.points.map(point => point.time)).toEqual([
      '2026-08-11 09:30', '2026-08-11 11:30', '2026-08-11 15:00',
    ])
  })

  it('does not fall back after a bad request or when an explicit source is selected', async () => {
    const service = {
      executeTencent: vi.fn(async () => {
        throw new StockApiError('参数无效。', 'bad-request')
      }),
      executeEastMoney: vi.fn(),
      executeSina: vi.fn(),
    } as unknown as StockApiService
    const tool = findTool(createStockMarketTools(service), 'stock_quote')

    await expect(runTool(tool, {
      action: 'snapshot', symbols: ['600519.SH'], source: 'auto',
    })).rejects.toThrow('参数无效')
    expect(service.executeEastMoney).not.toHaveBeenCalled()

    service.executeTencent = vi.fn(async () => {
      throw new StockApiError('腾讯暂时不可用。', 'upstream')
    }) as never
    await expect(runTool(tool, {
      action: 'snapshot', symbols: ['600519.SH'], source: 'tencent',
    })).rejects.toThrow('腾讯暂时不可用')
    expect(service.executeEastMoney).not.toHaveBeenCalled()
  })

  it('returns deterministic valid JSON when a result exceeds the 64k tool budget', async () => {
    const service = {
      executeEastMoney: vi.fn(async () => ({
        provider: 'eastmoney',
        endpointId: 'em_stock_profile',
        endpointName: '公司概况',
        fetchedAt: '2026-08-11T01:00:00.000Z',
        data: { text: '\\'.repeat(80_000) },
      })),
    } as unknown as StockApiService
    const tool = findTool(createStockMarketTools(service), 'stock_fundamentals')

    const output = await runTool(tool, {
      action: 'profile', symbol: '600519.SH', sections: ['company'],
    })
    expect(typeof output).toBe('string')
    expect((output as string).length).toBeLessThanOrEqual(64_000)
    const parsed = JSON.parse(output as string) as {
      output_truncated: boolean
      original_characters: number
      data: { omitted: boolean }
    }
    expect(parsed.output_truncated).toBe(true)
    expect(parsed.original_characters).toBeGreaterThan(64_000)
    expect(parsed.data.omitted).toBe(true)
    expect(output).not.toContain('preview')
  })
})

function findTool(tools: ToolDefinition[], name: string): ToolDefinition {
  const tool = tools.find(candidate => candidate.name === name)
  if (tool === undefined) throw new Error(`missing tool: ${name}`)
  return tool
}

function runTool(tool: ToolDefinition, args: unknown): Promise<unknown> {
  return tool.execute(args, {
    signal: new AbortController().signal,
  } as never)
}
