import { describe, expect, it, vi } from 'vitest'
import { DOCUMENTED_PUBLIC_ENDPOINTS } from '../src/stock-api/catalog.ts'
import { StockApiService } from '../src/stock-api/service.ts'

type PublicProvider = 'eastmoney' | 'tencent' | 'sina' | 'tonghuashun'

type Scenario = {
  provider: PublicProvider
  id: string
  parameters: Record<string, unknown>
  urlPrefix: string
  query?: Readonly<Record<string, string>>
}

const SCENARIOS: readonly Scenario[] = [
  {
    provider: 'eastmoney', id: 'em_realtime_quote', parameters: { secid: '1.600519' },
    urlPrefix: 'https://push2.eastmoney.com/api/qt/stock/get', query: { secid: '1.600519', fltt: '2' },
  },
  {
    provider: 'eastmoney', id: 'em_market_snapshot', parameters: { market: 'concept', sort: 'amount', order: 'asc' },
    urlPrefix: 'https://push2.eastmoney.com/api/qt/clist/get', query: { fs: 'm:90+t:3', fid: 'f6', po: '0' },
  },
  {
    provider: 'eastmoney', id: 'em_batch_quotes', parameters: { secids: '1.600519,0.000001' },
    urlPrefix: 'https://push2.eastmoney.com/api/qt/ulist.np/get', query: { secids: '1.600519,0.000001' },
  },
  {
    provider: 'eastmoney', id: 'em_price_history', parameters: { secid: '1.600519', period: 'week', adjust: 'hfq' },
    urlPrefix: 'https://push2his.eastmoney.com/api/qt/stock/kline/get', query: { secid: '1.600519', klt: '102', fqt: '2' },
  },
  {
    provider: 'eastmoney', id: 'em_intraday_trends', parameters: { secid: '1.600519', days: 5 },
    urlPrefix: 'https://push2his.eastmoney.com/api/qt/stock/trends2/get', query: { ndays: '5' },
  },
  {
    provider: 'eastmoney', id: 'em_money_flow_history', parameters: { secid: '1.600519', limit: 0 },
    urlPrefix: 'https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get', query: { klt: '101', lmt: '0' },
  },
  {
    provider: 'eastmoney', id: 'em_money_flow_intraday', parameters: { secid: '1.600519' },
    urlPrefix: 'https://push2.eastmoney.com/api/qt/stock/fflow/kline/get', query: { klt: '1', lmt: '0' },
  },
  {
    provider: 'eastmoney', id: 'em_connect_flow', parameters: {},
    urlPrefix: 'https://push2.eastmoney.com/api/qt/kamtbs.rtmin/get',
    query: {
      fields1: 'f1,f2,f3,f4',
      fields2: 'f51,f54,f52,f58,f53,f62,f56,f57,f60,f61',
      ut: 'fa5fd1943c7b386f172d6893dbfba10b',
    },
  },
  {
    provider: 'eastmoney', id: 'em_datacenter_report', parameters: { report: 'dragon_tiger', page: 2 },
    urlPrefix: 'https://datacenter-web.eastmoney.com/api/data/v1/get',
    query: { reportName: 'RPT_DAILYBILLBOARD_DETAILSNEW', pageNumber: '2' },
  },
  {
    provider: 'eastmoney', id: 'em_channel_news', parameters: { channel: 'global', page: 3 },
    urlPrefix: 'https://np-listapi.eastmoney.com/comm/web/getNewsByColumns', query: { column: '346', page_index: '3' },
  },
  {
    provider: 'eastmoney', id: 'em_global_search', parameters: { keyword: '茅台', scope: 'guba', page: 2 },
    urlPrefix: 'https://search-api-web.eastmoney.com/search/jsonp', query: { cb: 'dshStockCallback' },
  },
  {
    provider: 'eastmoney', id: 'em_guba_page', parameters: { stock_code: '600519' },
    urlPrefix: 'https://guba.eastmoney.com/list,600519.html',
  },
  {
    provider: 'tencent', id: 'tx_realtime_quotes', parameters: { symbols: 'sh600519,sz000001' },
    urlPrefix: 'https://qt.gtimg.cn/q=sh600519,sz000001',
  },
  {
    provider: 'tencent', id: 'tx_price_history', parameters: { symbol: 'sh600519', period: 'm15', adjust: 'none' },
    urlPrefix: 'https://web.ifzq.gtimg.cn/appstock/app/fqkline/get',
    query: { param: 'sh600519,m15,,,320,' },
  },
  {
    provider: 'tencent', id: 'tx_intraday_trends', parameters: { symbol: 'sh600519' },
    urlPrefix: 'https://web.ifzq.gtimg.cn/appstock/app/minute/query', query: { code: 'sh600519' },
  },
  {
    provider: 'tencent', id: 'tx_stock_rank', parameters: { sort: 'volume', order: 'asc', offset: 20 },
    urlPrefix: 'https://proxy.finance.qq.com/cgi/cgi-bin/rank/hs/getBoardRankList',
    query: { board_code: 'aStock', sort_type: 'volume', direct: 'up', offset: '20' },
  },
  {
    provider: 'tencent', id: 'tx_sector_rank', parameters: { sector_type: 'concept' },
    urlPrefix: 'https://proxy.finance.qq.com/cgi/cgi-bin/rank/pt/getRank', query: { board_type: 'gn' },
  },
  {
    provider: 'tencent', id: 'tx_stock_news', parameters: { symbol: 'sh600519', page: 2, limit: 3 },
    urlPrefix: 'https://web.ifzq.gtimg.cn/appstock/news/info/search',
    query: { symbol: 'sh600519', n: '3', page: '2', limit: '3', type: '2' },
  },
  {
    provider: 'sina', id: 'sina_realtime_quotes', parameters: { symbols: 'sh600519,sz000001' },
    urlPrefix: 'https://hq.sinajs.cn/list=sh600519,sz000001',
  },
  {
    provider: 'sina', id: 'sina_price_history', parameters: { symbol: 'sh600519', scale: 1200 },
    urlPrefix: 'https://quotes.sina.cn/cn/api/json_v2.php/CN_MarketDataService.getKLineData',
    query: { symbol: 'sh600519', scale: '1200', datalen: '320' },
  },
  {
    provider: 'sina', id: 'sina_intraday_kline', parameters: { symbol: 'sh600519', scale: 15, limit: 96 },
    urlPrefix: 'https://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData',
    query: { symbol: 'sh600519', scale: '15', datalen: '96' },
  },
  {
    provider: 'sina', id: 'sina_market_snapshot', parameters: { node: 'new_blhy', order: 'desc' },
    urlPrefix: 'https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/Market_Center.getHQNodeData',
    query: { node: 'new_blhy', asc: '0' },
  },
  {
    provider: 'sina', id: 'sina_industry_catalog', parameters: {},
    urlPrefix: 'https://money.finance.sina.com.cn/q/view/newSinaHy.php',
  },
  {
    provider: 'sina', id: 'sina_concept_catalog', parameters: {},
    urlPrefix: 'https://money.finance.sina.com.cn/q/view/newFLJK.php', query: { param: 'class' },
  },
  {
    provider: 'sina', id: 'sina_industry_overview', parameters: {},
    urlPrefix: 'https://money.finance.sina.com.cn/q/view/newFLJK.php', query: { param: 'industry' },
  },
  {
    provider: 'sina', id: 'sina_stock_money_flow', parameters: { symbol: 'sh600519', page: 2 },
    urlPrefix: 'https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/MoneyFlow.ssl_qsfx_zjlrqs',
    query: { daima: 'sh600519', page: '2' },
  },
  {
    provider: 'sina', id: 'sina_sector_money_flow', parameters: { sector_type: 'concept' },
    urlPrefix: 'https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/MoneyFlow.ssl_bkzj_zjlrqs',
    query: { fenlei: '2' },
  },
  {
    provider: 'sina', id: 'sina_rolling_news', parameters: { channel: 'stocks', page: 2 },
    urlPrefix: 'https://feed.mix.sina.com.cn/api/roll/get', query: { pageid: '153', lid: '2517', page: '2' },
  },
  {
    provider: 'sina', id: 'sina_stock_news_page', parameters: { symbol: 'sh600519' },
    urlPrefix: 'https://vip.stock.finance.sina.com.cn/corp/go.php/vCB_AllNewsStock/symbol/sh600519.phtml',
  },
  {
    provider: 'sina', id: 'sina_stock_announcements_page', parameters: { symbol: 'sh600519' },
    urlPrefix: 'https://vip.stock.finance.sina.com.cn/corp/go.php/vCB_AllBulletin/symbol/sh600519.phtml',
  },
  {
    provider: 'sina', id: 'sina_dragon_tiger_page', parameters: {},
    urlPrefix: 'https://vip.stock.finance.sina.com.cn/q/go.php/vLHBData/kind/ggtj/index.phtml',
  },
  {
    provider: 'tonghuashun', id: 'ths_price_history', parameters: { symbol: 'hs_600519', archive: '202401' },
    urlPrefix: 'https://d.10jqka.com.cn/v6/line/hs_600519/01/202401.js',
  },
  {
    provider: 'tonghuashun', id: 'ths_intraday_trends', parameters: { symbol: 'hs_600519' },
    urlPrefix: 'https://d.10jqka.com.cn/v6/time/hs_600519/last.js',
  },
]

describe('documented public stock APIs', () => {
  it('has one execution scenario for every researched endpoint', () => {
    expect(SCENARIOS.map(item => `${item.provider}:${item.id}`).sort()).toEqual(
      DOCUMENTED_PUBLIC_ENDPOINTS.map(item => `${item.provider}:${item.id}`).sort(),
    )
  })

  it.each(SCENARIOS)('maps $provider:$id to its fixed upstream request', async (scenario) => {
    const fetcher = vi.fn(async () => responseFor(scenario.id))
    const service = serviceWith(fetcher)

    const result = await execute(service, scenario)

    expect(result).toMatchObject({ provider: scenario.provider, endpointId: scenario.id })
    expect(fetcher).toHaveBeenCalledTimes(1)
    const [input, init] = fetcher.mock.calls[0] as unknown as [string, RequestInit]
    expect(input.startsWith(scenario.urlPrefix)).toBe(true)
    expect(init).toMatchObject({ method: 'GET', redirect: 'error' })
    expect(String((init.headers as Record<string, string>)['User-Agent'])).toContain('DSH-Stock-Market')

    const requested = new URL(input)
    for (const [name, value] of Object.entries(scenario.query ?? {})) {
      expect(requested.searchParams.get(name), `${scenario.id}.${name}`).toBe(value)
    }
    if (scenario.provider === 'sina') {
      expect((init.headers as Record<string, string>).Referer).toBe('https://finance.sina.com.cn/')
    }
    if (scenario.provider === 'tonghuashun') {
      expect((init.headers as Record<string, string>).Referer).toBe('http://stockpage.10jqka.com.cn/')
    }
    if (scenario.id === 'em_global_search') {
      expect((init.headers as Record<string, string>).Referer).toBe('https://so.eastmoney.com/')
      const param = JSON.parse(requested.searchParams.get('param') ?? '{}') as Record<string, unknown>
      expect(param).toMatchObject({ keyword: '茅台', type: ['gubaArticleWeb'] })
    }
  })

  it.each([
    {
      scope: 'news', keyword: '茅台', endpoint: 'https://search-api-web.eastmoney.com/search/jsonp',
      upstreamType: 'cmsArticleWebOld', resultKey: 'cmsArticleWebOld',
    },
    {
      scope: 'guba', keyword: '600519', endpoint: 'https://search-api-web.eastmoney.com/search/jsonp',
      upstreamType: 'gubaArticleWeb', resultKey: 'gubaArticleWeb',
    },
    {
      scope: 'stock', keyword: '茅台', endpoint: 'https://search-codetable.eastmoney.com/codetable/search/web/market',
      label: 'AB_STOCK', resultKey: 'labelList',
    },
    {
      scope: 'fund', keyword: '沪深300', endpoint: 'https://search-codetable.eastmoney.com/codetable/search/web/market',
      label: 'FUND', resultKey: 'labelList',
    },
  ])('uses the current Eastmoney $scope search contract', async (searchCase) => {
    const payload = searchCase.label === undefined
      ? `dshStockCallback({"code":0,"result":{"${searchCase.resultKey}":[]}})`
      : `{"code":"0","result":{"${searchCase.resultKey}":[]}}`
    const fetcher = vi.fn(async () => new Response(payload))
    const service = serviceWith(fetcher)

    await service.executeEastMoney(
      'em_global_search',
      { keyword: searchCase.keyword, scope: searchCase.scope, page: 2, limit: 20 },
      new AbortController().signal,
    )

    const [input, init] = fetcher.mock.calls[0] as unknown as [string, RequestInit]
    const requested = new URL(input)
    expect(`${requested.origin}${requested.pathname}`).toBe(searchCase.endpoint)
    expect((init.headers as Record<string, string>).Referer).toBe('https://so.eastmoney.com/')
    expect(requested.searchParams.get('pageIndex')).toBe(searchCase.label === undefined ? null : '2')
    expect(requested.searchParams.get('pageSize')).toBe(searchCase.label === undefined ? null : '20')

    if (searchCase.label !== undefined) {
      expect(requested.searchParams.get('label')).toBe(searchCase.label)
      expect(requested.searchParams.get('keyword')).toBe(searchCase.keyword)
    } else {
      const param = JSON.parse(requested.searchParams.get('param') ?? '{}') as {
        type?: string[]
        param?: Record<string, { pageIndex?: number, pageSize?: number }>
      }
      expect(param.type).toEqual([searchCase.upstreamType])
      expect(param.param?.[searchCase.upstreamType ?? '']).toMatchObject({ pageIndex: 2, pageSize: 20 })
    }
  })

  it('rejects a semantically invalid Eastmoney search response', async () => {
    const fetcher = vi.fn(async () => new Response(
      'dshStockCallback({"code":0,"msg":"包含未知的type：guba","result":{}})',
    ))
    const service = serviceWith(fetcher)

    await expect(service.executeEastMoney(
      'em_global_search',
      { keyword: '600519', scope: 'guba' },
      new AbortController().signal,
    )).rejects.toThrow('gubaArticleWeb')
  })

  it('filters B-share and Beijing search rows from the A-share stock scope', async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify({
      code: '0',
      result: {
        labelList: [{
          name: 'AB股',
          type: 'AB_STOCK',
          count: 6,
          quoteList: [
            { code: '600519', market: 1, securityTypeName: '沪A' },
            { code: '000001', market: 0, securityTypeName: '深A' },
            { code: '900901', market: 1, securityTypeName: '沪B' },
            { code: '200002', market: 0, securityTypeName: '深B' },
            { code: '920017', market: 0, securityTypeName: '京A' },
            { code: '430047', market: 0, securityTypeName: '京A' },
          ],
        }],
      },
    })))
    const service = serviceWith(fetcher)

    const result = await service.executeEastMoney(
      'em_global_search',
      { keyword: '测试', scope: 'stock' },
      new AbortController().signal,
    )

    expect(result.data).toMatchObject({
      result: {
        labelList: [{
          name: '沪深 A 股',
          type: 'A_STOCK',
          returned_count: 2,
          upstream_count: 6,
          quoteList: [
            { code: '600519', market: 1 },
            { code: '000001', market: 0 },
          ],
        }],
      },
    })
  })

  it('rejects B-share and Beijing codes before requesting the stock-page endpoint', async () => {
    const fetcher = vi.fn()
    const service = serviceWith(fetcher)
    const signal = new AbortController().signal

    await expect(service.executeEastMoney('em_guba_page', { stock_code: '900901' }, signal)).rejects.toMatchObject({ kind: 'bad-request' })
    await expect(service.executeEastMoney('em_guba_page', { stock_code: '430047' }, signal)).rejects.toMatchObject({ kind: 'bad-request' })
    expect(fetcher).not.toHaveBeenCalled()
  })

  it.each([
    ['dragon_tiger', 'RPT_DAILYBILLBOARD_DETAILSNEW'],
    ['economic_calendar', 'RPT_CPH_FECALENDAR'],
    ['convertible_bonds', 'RPT_BOND_CB_LIST'],
    ['margin_detail', 'RPTA_WEB_RZRQ_GGMX'],
  ])('maps Eastmoney data-center alias %s to an active report', async (report, reportName) => {
    const fetcher = vi.fn(async () => dataCenterResponse())
    const service = serviceWith(fetcher)

    await service.executeEastMoney(
      'em_datacenter_report',
      { report, limit: 3 },
      new AbortController().signal,
    )

    const [input] = fetcher.mock.calls[0] as unknown as [string]
    const requested = new URL(input)
    expect(requested.searchParams.get('reportName')).toBe(reportName)
  })

  it('rejects an Eastmoney data-center business error', async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify({
      success: false,
      code: 9501,
      message: '报表配置不存在',
      result: null,
    })))
    const service = serviceWith(fetcher)

    await expect(service.executeEastMoney(
      'em_datacenter_report',
      { report: 'economic_calendar' },
      new AbortController().signal,
    )).rejects.toThrow('报表配置不存在')
  })

  it('rejects an Eastmoney quote business error returned with HTTP 200', async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify({
      rc: -1,
      msg: '证券代码不存在',
      data: null,
    })))
    const service = serviceWith(fetcher)

    await expect(service.executeEastMoney(
      'em_realtime_quote',
      { secid: '1.600519' },
      new AbortController().signal,
    )).rejects.toThrow('证券代码不存在')
  })

  it('maps the SH/SZ all_a filter without the Beijing-market selector', async () => {
    const fetcher = vi.fn(async () => new Response('{"rc":0,"data":{"diff":[]}}'))
    const service = serviceWith(fetcher)

    await service.executeEastMoney(
      'em_market_snapshot',
      { market: 'all_a' },
      new AbortController().signal,
    )

    const [input] = fetcher.mock.calls[0] as unknown as [string]
    const requested = new URL(input)
    expect(requested.searchParams.get('fs')).toBe('m:0+t:6,m:1+t:2')
    expect(requested.searchParams.get('fs')).not.toContain('t:80')
  })

  it('rejects an Eastmoney success envelope with a missing endpoint payload', async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify({ rc: 0, data: {} })))
    const service = serviceWith(fetcher)

    await expect(service.executeEastMoney(
      'em_market_snapshot',
      { market: 'all_a' },
      new AbortController().signal,
    )).rejects.toThrow('data.diff')
  })

  it('rejects a Tencent business error returned with HTTP 200', async () => {
    const fetcher = vi.fn(async () => new Response(JSON.stringify({
      code: 1619377101,
      msg: '参数错误:sort_type error',
    })))
    const service = serviceWith(fetcher)

    await expect(service.executeTencent(
      'tx_stock_rank',
      { sort: 'price' },
      new AbortController().signal,
    )).rejects.toThrow('sort_type error')
  })

  it('falls back to Eastmoney fixed delay host after a primary transport reset', async () => {
    const fetcher = vi.fn()
      .mockRejectedValueOnce(new TypeError('fetch failed'))
      .mockResolvedValueOnce(new Response('{"rc":0,"data":{"f57":"600519"}}'))
    const service = serviceWith(fetcher)

    const result = await service.executeEastMoney(
      'em_realtime_quote',
      { secid: '1.600519' },
      new AbortController().signal,
    )

    expect(result).toMatchObject({ provider: 'eastmoney', endpointId: 'em_realtime_quote' })
    expect(String(fetcher.mock.calls[0]?.[0])).toMatch(/^https:\/\/push2\.eastmoney\.com\//)
    expect(String(fetcher.mock.calls[1]?.[0])).toMatch(/^https:\/\/push2delay\.eastmoney\.com\//)
  })

  it('decodes Tencent GBK quote text before parsing fields', async () => {
    const fields = Array.from({ length: 49 }, () => '')
    fields[0] = '1'
    fields[1] = '__NAME__'
    fields[2] = '600519'
    fields[3] = '1340.87'
    const [prefix, suffix] = `v_sh600519="${fields.join('~')}";`.split('__NAME__')
    const bytes = Buffer.concat([
      Buffer.from(prefix, 'ascii'),
      Buffer.from([0xb9, 0xf3, 0xd6, 0xdd]),
      Buffer.from(suffix, 'ascii'),
    ])
    const fetcher = vi.fn(async () => new Response(bytes))
    const service = serviceWith(fetcher)

    const result = await service.executeTencent(
      'tx_realtime_quotes',
      { symbols: 'sh600519' },
      new AbortController().signal,
    )

    expect(result.data).toMatchObject({
      quotes: [expect.objectContaining({ name: '贵州', price: 1340.87 })],
    })
  })

  it.each([
    { provider: 'eastmoney' as const, id: 'em_realtime_quote', parameters: { secid: '1.600519' } },
    { provider: 'tencent' as const, id: 'tx_intraday_trends', parameters: { symbol: 'sh600519' } },
    { provider: 'sina' as const, id: 'sina_price_history', parameters: { symbol: 'sh600519' } },
    { provider: 'tonghuashun' as const, id: 'ths_intraday_trends', parameters: { symbol: 'hs_600519' } },
  ])('rejects undeclared URL parameters before calling $provider', async (scenario) => {
    const fetcher = vi.fn()
    const service = serviceWith(fetcher)

    await expect(execute(service, {
      ...scenario,
      parameters: { ...scenario.parameters, url: 'https://attacker.invalid' },
    })).rejects.toMatchObject({ kind: 'bad-request' })
    expect(fetcher).not.toHaveBeenCalled()
  })
})

function serviceWith(fetcher: ReturnType<typeof vi.fn>): StockApiService {
  return new StockApiService({
    fetcher: fetcher as unknown as typeof fetch,
    sleep: async () => undefined,
    now: () => new Date('2026-08-11T06:00:00.000Z'),
  })
}

function execute(service: StockApiService, scenario: Pick<Scenario, 'provider' | 'id' | 'parameters'>) {
  const signal = new AbortController().signal
  switch (scenario.provider) {
    case 'eastmoney': return service.executeEastMoney(scenario.id, scenario.parameters, signal)
    case 'tencent': return service.executeTencent(scenario.id, scenario.parameters, signal)
    case 'sina': return service.executeSina(scenario.id, scenario.parameters, signal)
    case 'tonghuashun': return service.executeTonghuashun(scenario.id, scenario.parameters, signal)
  }
}

function responseFor(endpointId: string): Response {
  if (endpointId === 'tx_realtime_quotes') return new Response(tencentQuote())
  if (endpointId === 'sina_realtime_quotes') return new Response(sinaQuote())
  if (endpointId === 'em_datacenter_report') return dataCenterResponse()
  if (endpointId === 'em_global_search') {
    return new Response('dshStockCallback({"code":0,"result":{"gubaArticleWeb":[]}})')
  }
  if (endpointId === 'em_market_snapshot' || endpointId === 'em_batch_quotes') {
    return new Response('{"rc":0,"data":{"diff":[]}}')
  }
  if ([
    'em_price_history',
    'em_money_flow_history',
    'em_money_flow_intraday',
  ].includes(endpointId)) {
    return new Response('{"rc":0,"data":{"klines":[]}}')
  }
  if (endpointId === 'em_intraday_trends') {
    return new Response('{"rc":0,"data":{"trends":[]}}')
  }
  if (endpointId === 'em_connect_flow') {
    return new Response('{"rc":0,"data":{"s2n":[],"n2s":[]}}')
  }
  if (endpointId === 'em_channel_news') {
    return new Response('{"data":{"list":[]}}')
  }
  if ([
    'sina_industry_catalog',
    'sina_concept_catalog',
    'sina_industry_overview',
    'ths_price_history',
    'ths_intraday_trends',
  ].includes(endpointId)) return new Response('stockCallback({"data":[]});')
  if ([
    'em_guba_page',
    'sina_stock_news_page',
    'sina_stock_announcements_page',
    'sina_dragon_tiger_page',
  ].includes(endpointId)) return new Response('<html><body>bounded page</body></html>')
  return new Response('{"code":0,"rc":0,"data":{}}')
}

function dataCenterResponse(): Response {
  return new Response(JSON.stringify({
    success: true,
    code: 0,
    message: 'ok',
    result: { data: [] },
  }))
}

function tencentQuote(): string {
  const fields = Array.from({ length: 49 }, () => '')
  fields[0] = '1'
  fields[1] = '贵州茅台'
  fields[2] = '600519'
  fields[3] = '1340.87'
  fields[30] = '20260811135934'
  return `v_sh600519="${fields.join('~')}";`
}

function sinaQuote(): string {
  const fields = Array.from({ length: 33 }, () => '')
  fields[0] = '贵州茅台'
  fields[1] = '1348.000'
  fields[2] = '1348.860'
  fields[3] = '1340.990'
  fields[30] = '2026-08-11'
  fields[31] = '13:59:34'
  fields[32] = '00'
  return `var hq_str_sh600519="${fields.join(',')}";`
}
