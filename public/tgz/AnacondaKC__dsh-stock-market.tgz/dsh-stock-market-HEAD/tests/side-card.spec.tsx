// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import {
  STOCK_MARKET_BREADTH_ENDPOINT,
  STOCK_MARKET_GLOBAL_QUOTES_ENDPOINT,
  STOCK_MARKET_INDICES_ENDPOINT,
} from '../src/rpc-contract.ts'
import { StockMarketSideCard } from '../src/client/StockMarketSideCard.tsx'
import css from '../src/client/StockMarketSideCard.module.css'
import {
  createStockMarketSideCardStore,
  STOCK_MARKET_SIDECARD_OVERLAY_MAX_VIEWPORT_WIDTH,
  STOCK_MARKET_SIDECARD_SESSION_MIN_WIDTH,
} from '../src/client/StockMarketSideCardState.ts'
import { installTestLocalStorage } from './local-storage.ts'

const DEFAULT_VIEWPORT_WIDTH = window.innerWidth

beforeEach(() => {
  installTestLocalStorage()
  setViewportWidth(DEFAULT_VIEWPORT_WIDTH)
})
afterEach(() => {
  cleanup()
  window.localStorage.clear()
  document.documentElement.style.removeProperty('--dsh-stock-market-sidebar-width')
  document.documentElement.style.removeProperty('--dsh-sidebar-width')
  setViewportWidth(DEFAULT_VIEWPORT_WIDTH)
})

describe('StockMarketSideCard', () => {
  it('mounts for the current conversation and supports repeated collapse cycles', async () => {
    const store = createStockMarketSideCardStore()
    const connection = readyConnection()
    const sessions = listWith('session-a')

    render(<StockMarketSideCard ctx={{ sessions: { list: sessions } } as never} connection={connection} store={store} />)

    const card = await screen.findByLabelText('A 股行情侧栏')
    expect(await screen.findByLabelText('上证指数')).toBeTruthy()
    expect(document.documentElement.style.getPropertyValue('--dsh-stock-market-sidebar-width')).not.toBe('')

    const collapseButton = screen.getByRole('button', { name: '收起行情侧栏' })
    expect(collapseButton.closest('aside')).toBeNull()
    expect(collapseButton.getAttribute('aria-expanded')).toBe('true')
    expect(collapseButton.className).toContain(css.marketRailButtonOpen)
    expect(collapseButton.className).toContain(css.marketRailButtonFlat)
    await waitFor(() => { expect(collapseButton.getAttribute('data-market-temperature')).toBe('100') })

    fireEvent.click(collapseButton)
    const openButton = await screen.findByRole('button', { name: '打开行情侧栏' })
    expect(openButton.getAttribute('aria-expanded')).toBe('false')
    await waitFor(() => {
      expect(openButton.getAttribute('data-market-tone')).toBe('flat')
      expect(openButton.className).toContain(css.marketRailButtonFlat)
    })
    const tickerRows = openButton.querySelectorAll<HTMLElement>(`.${css.tickerRow}`)
    expect(tickerRows).toHaveLength(4)
    expect(tickerRows[0]?.getAttribute('data-market-tone')).toBe('fall')
    expect(tickerRows[0]?.className).toContain(css.tickerRowFall)
    expect(tickerRows[1]?.getAttribute('data-market-tone')).toBe('rise')
    expect(tickerRows[1]?.className).toContain(css.tickerRowRise)
    expect(tickerRows[2]?.getAttribute('data-market-tone')).toBe('rise')
    expect(tickerRows[3]?.getAttribute('data-market-tone')).toBe('fall')
    await waitFor(() => { expect(screen.getAllByText('3,831.38')).toHaveLength(2) })
    expect(screen.getByText('3,831')).toBeTruthy()
    expect(screen.getByText('3,831.382')).toBeTruthy()
    expect(screen.getByText('-0.88 -0.02%')).toBeTruthy()
    expect(store.getSnapshot().state?.panelOpen).toBe(false)

    fireEvent.click(openButton)
    const reopenedCollapseButton = await screen.findByRole('button', { name: '收起行情侧栏' })
    await waitFor(() => { expect(store.getSnapshot().state?.panelOpen).toBe(true) })
    expect(reopenedCollapseButton.getAttribute('data-market-temperature')).toBe('100')
    expect(reopenedCollapseButton.className).toContain(css.marketRailButtonOpen)
    expect(reopenedCollapseButton.className).toContain(css.marketRailButtonFall)

    fireEvent.click(reopenedCollapseButton)
    await waitFor(() => { expect(store.getSnapshot().state?.panelOpen).toBe(false) })
    fireEvent.click(screen.getByRole('button', { name: '打开行情侧栏' }))
    await waitFor(() => { expect(store.getSnapshot().state?.panelOpen).toBe(true) })
  })

  it('reserves the rendered card width instead of covering the conversation on compact desktops', async () => {
    const viewportWidth = STOCK_MARKET_SIDECARD_OVERLAY_MAX_VIEWPORT_WIDTH + 40
    const expectedWidth = viewportWidth - STOCK_MARKET_SIDECARD_SESSION_MIN_WIDTH
    setViewportWidth(viewportWidth)
    const store = createStockMarketSideCardStore()
    const connection = readyConnection()

    render(<StockMarketSideCard ctx={{ sessions: { list: listWith('session-a') } } as never} connection={connection} store={store} />)

    const card = await screen.findByLabelText('A 股行情侧栏')
    expect((card as HTMLElement).style.width).toBe(`${expectedWidth}px`)
    expect(document.documentElement.style.getPropertyValue('--dsh-stock-market-sidebar-width')).toBe(`${expectedWidth}px`)
  })

  it('subtracts the host sidebar when sizing the conversation-adjacent panel', async () => {
    setViewportWidth(1_000)
    document.documentElement.style.setProperty('--dsh-sidebar-width', '80px')
    const store = createStockMarketSideCardStore()
    const connection = readyConnection()

    render(<StockMarketSideCard ctx={{ sessions: { list: listWith('session-a') } } as never} connection={connection} store={store} />)

    const card = await screen.findByLabelText('A 股行情侧栏')
    expect((card as HTMLElement).style.width).toBe('440px')
    expect(document.documentElement.style.getPropertyValue('--dsh-stock-market-sidebar-width')).toBe('440px')
  })

  it('uses a full-width overlay before both panes have usable room', async () => {
    setViewportWidth(STOCK_MARKET_SIDECARD_OVERLAY_MAX_VIEWPORT_WIDTH)
    const store = createStockMarketSideCardStore()
    const connection = readyConnection()

    render(<StockMarketSideCard ctx={{ sessions: { list: listWith('session-a') } } as never} connection={connection} store={store} />)

    const card = await screen.findByLabelText('A 股行情侧栏')
    expect((card as HTMLElement).style.width).toBe(`${STOCK_MARKET_SIDECARD_OVERLAY_MAX_VIEWPORT_WIDTH}px`)
    expect(document.documentElement.style.getPropertyValue('--dsh-stock-market-sidebar-width')).toBe('0px')
  })

  it('does not expose a resize separator when the card overlays a host-constrained layout', async () => {
    setViewportWidth(900)
    document.documentElement.style.setProperty('--dsh-sidebar-width', '160px')
    const store = createStockMarketSideCardStore()

    render(<StockMarketSideCard ctx={{ sessions: { list: listWith('session-a') } } as never} connection={readyConnection()} store={store} />)

    const card = await screen.findByLabelText('A 股行情侧栏')
    expect((card as HTMLElement).style.width).toBe('740px')
    expect(screen.queryByRole('separator', { name: '调整行情侧栏宽度' })).toBeNull()
  })

  it('ends an active resize when the card switches to overlay mode', async () => {
    setViewportWidth(900)
    const store = createStockMarketSideCardStore()
    const persist = vi.spyOn(store, 'persist')
    render(<StockMarketSideCard ctx={{ sessions: { list: listWith('session-a') } } as never} connection={readyConnection()} store={store} />)

    const handle = await screen.findByRole('separator', { name: '调整行情侧栏宽度' })
    let capturedPointer: number | undefined
    handle.setPointerCapture = vi.fn(pointerId => { capturedPointer = pointerId })
    handle.hasPointerCapture = vi.fn(pointerId => capturedPointer === pointerId)

    fireEvent.pointerDown(handle, { pointerId: 7, clientX: 600 })
    document.documentElement.style.setProperty('--dsh-sidebar-width', '160px')
    window.dispatchEvent(new Event('resize'))

    await waitFor(() => {
      expect(screen.queryByRole('separator', { name: '调整行情侧栏宽度' })).toBeNull()
      expect(persist).toHaveBeenCalledOnce()
    })
  })

  it('persists a completed resize only once when pointer release also loses capture', async () => {
    const store = createStockMarketSideCardStore()
    const persist = vi.spyOn(store, 'persist')

    render(<StockMarketSideCard ctx={{ sessions: { list: listWith('session-a') } } as never} connection={readyConnection()} store={store} />)

    const card = await screen.findByLabelText('A 股行情侧栏')
    const handle = card.querySelector<HTMLElement>(`.${css.resizeHandle}`)
    expect(handle).not.toBeNull()
    if (handle === null) return

    let capturedPointer: number | undefined
    handle.setPointerCapture = vi.fn(pointerId => { capturedPointer = pointerId })
    handle.hasPointerCapture = vi.fn(pointerId => capturedPointer === pointerId)
    handle.releasePointerCapture = vi.fn(pointerId => {
      if (capturedPointer === pointerId) capturedPointer = undefined
    })

    fireEvent.pointerDown(handle, { pointerId: 7, clientX: 600 })
    fireEvent.pointerMove(handle, { pointerId: 7, clientX: 560 })
    fireEvent.pointerUp(handle, { pointerId: 7, clientX: 560 })
    fireEvent.lostPointerCapture(handle, { pointerId: 7 })

    expect(persist).toHaveBeenCalledOnce()
  })

  it('limits keyboard resize semantics to the current layout budget', async () => {
    setViewportWidth(900)
    const store = createStockMarketSideCardStore()
    render(<StockMarketSideCard ctx={{ sessions: { list: listWith('session-a') } } as never} connection={readyConnection()} store={store} />)

    const handle = await screen.findByRole('separator', { name: '调整行情侧栏宽度' })
    expect(handle.getAttribute('aria-valuemin')).toBe('300')
    expect(handle.getAttribute('aria-valuemax')).toBe('420')
    expect(handle.getAttribute('aria-valuenow')).toBe('420')

    fireEvent.keyDown(handle, { key: 'ArrowRight' })
    expect(store.getSnapshot().state?.width).toBe(420)
    fireEvent.keyDown(handle, { key: 'Home' })
    expect(store.getSnapshot().state?.width).toBe(300)
    fireEvent.keyDown(handle, { key: 'ArrowLeft' })
    expect(store.getSnapshot().state?.width).toBe(300)
    fireEvent.keyDown(handle, { key: 'End' })
    expect(store.getSnapshot().state?.width).toBe(420)
  })

  it('renders a disabled rail before a session is selected', () => {
    const store = createStockMarketSideCardStore()
    const sessions = listWith(undefined)

    render(<StockMarketSideCard ctx={{ sessions: { list: sessions } } as never} connection={connectionWith(vi.fn())} store={store} />)

    expect(screen.getByRole('button', { name: '请选择会话后打开行情' })).toHaveProperty('disabled', true)
  })
})

function listWith(current: string | undefined) {
  const snapshot = { current }
  return {
    getSnapshot: () => snapshot,
    subscribe: () => () => undefined,
  }
}

function setViewportWidth(width: number): void {
  Object.defineProperty(window, 'innerWidth', { configurable: true, value: width })
}

function readyConnection(): ConnectionHandle {
  return connectionWith(vi.fn(async (_channel: string, endpoint: string) => {
    if (endpoint === STOCK_MARKET_INDICES_ENDPOINT) {
      return {
        ok: true as const,
        value: {
          protocolVersion: 1,
          fetchedAt: '2026-08-03T01:00:00.000Z',
          marketStatus: 'preopen',
          indices: [
            { id: 'sse', price: 3831.382, previousClose: 3832.262, open: 3831.822, high: 3832.262, low: 3830.502, change: -0.88, changePercent: -0.023, amount: 534_600_000_000, marketTime: '2026-08-03 08:50:00' },
            { id: 'szse', price: 12266.314, previousClose: 12244.184, open: 12255.249, high: 12277.379, low: 12233.119, change: 22.13, changePercent: 0.181, amount: 402_300_000_000, marketTime: '2026-08-03 08:50:00' },
            { id: 'chinext', price: 2681.183, previousClose: 2676.463, open: 2678.823, high: 2685.903, low: 2674.103, change: 4.72, changePercent: 0.176, amount: 198_700_000_000, marketTime: '2026-08-03 08:50:00' },
            { id: 'star50', price: 1045.761, previousClose: 1047.221, open: 1046.491, high: 1047.951, low: 1044.301, change: -1.46, changePercent: -0.139, amount: 86_500_000_000, marketTime: '2026-08-03 08:50:00' },
          ],
          unavailable: [],
        },
      }
    }
    if (endpoint === STOCK_MARKET_GLOBAL_QUOTES_ENDPOINT) {
      return {
        ok: true as const,
        value: {
          protocolVersion: 1,
          fetchedAt: '2026-08-03T01:00:00.000Z',
          quotes: [
            { id: 'sse', price: 3831.38, previousClose: 3832.26, open: 3831.82, high: 3832.26, low: 3830.50, change: -0.88, changePercent: -0.02, marketTime: '2026-08-03 08:50:00' },
            { id: 'hangSeng', price: 25356.97, previousClose: 25652.82, open: null, high: null, low: null, change: -295.85, changePercent: -1.15, marketTime: '' },
            { id: 'nasdaq', price: 26445.45, previousClose: 26605.36, open: null, high: null, low: null, change: -159.91, changePercent: -0.60, marketTime: '' },
            { id: 'kospi', price: 6606.37, previousClose: 6345.53, open: 6438.50, high: 6621.29, low: 6413.50, change: 260.84, changePercent: 4.11, marketTime: '2026-08-12 10:44:00' },
            { id: 'nikkei', price: 67039.96, previousClose: 66970.22, open: 66994.05, high: 67144.36, low: 66735.76, change: 69.74, changePercent: 0.10, marketTime: '2026-08-12 10:30:01' },
            { id: 'brent', price: 89.647, previousClose: 88.91, open: 89.17, high: 89.73, low: 89.08, change: 0.737, changePercent: 0.829, marketTime: '2026-08-12 10:43:40' },
            { id: 'newYorkGold', price: 4465.286, previousClose: 4441.10, open: 4430, high: 4467.60, low: 4421.40, change: 24.186, changePercent: 0.545, marketTime: '2026-08-12 10:44:09' },
          ],
          unavailable: [],
        },
      }
    }
    if (endpoint === STOCK_MARKET_BREADTH_ENDPOINT) {
      return {
        ok: true as const,
        value: {
          protocolVersion: 1,
          fetchedAt: '2026-08-03T01:00:00.000Z',
          breadth: { rising: 2, falling: 0, flat: 0 },
        },
      }
    }
    return { ok: false as const, error: { code: 'bad-request', message: '未知 endpoint', details: {} } }
  }))
}

function connectionWith(call: (...args: any[]) => Promise<any>): ConnectionHandle {
  return {
    isLoopback: true,
    rpc: { call },
    api: {},
    start: () => ({ stop: () => undefined }),
  } as unknown as ConnectionHandle
}
