// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import {
  STOCK_MARKET_BREADTH_ENDPOINT,
  STOCK_MARKET_FLASH_NEWS_ENDPOINT,
  STOCK_MARKET_GLOBAL_QUOTES_ENDPOINT,
  STOCK_MARKET_HEADLINES_ENDPOINT,
  STOCK_MARKET_HOTSPOTS_ENDPOINT,
  STOCK_MARKET_INDICES_ENDPOINT,
  STOCK_MARKET_MOVERS_ENDPOINT,
  STOCK_MARKET_RPC_CHANNEL,
  STOCK_MARKET_TRENDS_ENDPOINT,
  STOCK_MARKET_TURNOVER_ENDPOINT,
} from '../src/rpc-contract.ts'
import {
  marketPollingDelay,
  marketPollingInterval,
  marketTrendTimeRatio,
  StockMarketView,
  type StockMarketViewProps,
} from '../src/client/StockMarketView.tsx'

const readyResult = {
  ok: true as const,
  value: {
    protocolVersion: 1,
    fetchedAt: '2026-08-03T01:00:00.000Z',
    marketStatus: 'preopen',
    indices: [
      { id: 'sse', price: 3831.582, previousClose: 3832.46, open: 3820.12, high: 3842.18, low: 3815.64, change: -0.88, changePercent: -0.023, amount: 534_600_000_000, marketTime: '2026-08-03 08:50:00' },
      { id: 'szse', price: 12266.314, previousClose: 12244.18, open: 12240.2, high: 12302.8, low: 12210.4, change: 22.13, changePercent: 0.181, amount: 402_300_000_000, marketTime: '2026-08-03 08:50:00' },
      { id: 'chinext', price: 2681.183, previousClose: 2676.46, open: 2674.2, high: 2690.8, low: 2668.4, change: 4.72, changePercent: 0.176, amount: 198_700_000_000, marketTime: '2026-08-03 08:50:00' },
      { id: 'star50', price: 1045.761, previousClose: 1047.22, open: 1048.1, high: 1050.8, low: 1040.2, change: -1.46, changePercent: -0.139, amount: 1_000_100_000_000, marketTime: '2026-08-03 08:50:00' },
    ],
    unavailable: [],
  },
}

const readyTurnoverResult = {
  ok: true as const,
  value: {
    protocolVersion: 1,
    fetchedAt: '2026-08-03T01:00:00.000Z',
    tradeDate: '2026-08-03',
    previousTradeDate: '2026-07-31',
    todayAmount: 1_020_000_000_000,
    previousAmount: 1_000_000_000_000,
    changePercent: 2,
  },
}

const readyBreadthResult = {
  ok: true as const,
  value: {
    protocolVersion: 1,
    fetchedAt: '2026-08-03T01:00:00.000Z',
    breadth: { rising: 1576, falling: 3549, flat: 158 },
  },
}

const readyTrendsResult = {
  ok: true as const,
  value: {
    protocolVersion: 1,
    fetchedAt: '2026-08-03T01:00:00.000Z',
    series: [
      { id: 'sse', previousClose: 3832.46, points: [{ time: '2026-08-03 09:30', price: 3825.2, averagePrice: 3825.2 }, { time: '2026-08-03 10:00', price: 3831.582, averagePrice: 3828.4 }] },
      { id: 'szse', previousClose: 12244.18, points: [{ time: '2026-08-03 09:30', price: 12240.2, averagePrice: 12240.2 }, { time: '2026-08-03 10:00', price: 12266.314, averagePrice: 12252.6 }] },
      { id: 'chinext', previousClose: 2676.46, points: [{ time: '2026-08-03 09:30', price: 2674.2, averagePrice: 2674.2 }, { time: '2026-08-03 10:00', price: 2681.183, averagePrice: 2678.1 }] },
      { id: 'star50', previousClose: 1047.22, points: [{ time: '2026-08-03 09:30', price: 1048.1, averagePrice: 1048.1 }, { time: '2026-08-03 10:00', price: 1045.761, averagePrice: 1046.8 }] },
    ],
    unavailable: [],
  },
}

const moverRows = [
  { code: '301717', name: 'N超纯', price: 503, changePercent: 662.24, netInflow: 8_600_000_000 },
  { code: '600519', name: '贵州茅台', price: 1520, changePercent: 2.35, netInflow: 6_200_000_000 },
]

const readyMoversResult = {
  ok: true as const,
  value: {
    protocolVersion: 1,
    fetchedAt: '2026-08-03T01:00:00.000Z',
    rankings: {
      gainers: moverRows,
      losers: [...moverRows].reverse(),
      netInflow: moverRows,
      netOutflow: moverRows,
    },
  },
}

const readyHotspotsResult = {
  ok: true as const,
  value: {
    protocolVersion: 1,
    fetchedAt: '2026-08-03T01:00:00.000Z',
    groups: {
      industry: [
        { code: 'BK1044', name: '机器人', changePercent: 5.82 },
        { code: 'BK0475', name: '航天航空', changePercent: 5.21 },
        { code: 'BK0727', name: '半导体', changePercent: 4.88 },
        { code: 'BK0428', name: '电机', changePercent: 4.32 },
        { code: 'BK0910', name: '光伏设备', changePercent: 3.96 },
      ],
      concept: [
        { code: 'BK0816', name: '人形机器人', changePercent: 6.18 },
        { code: 'BK0996', name: '低空经济', changePercent: 5.76 },
        { code: 'BK1134', name: '商业航天', changePercent: 5.31 },
        { code: 'BK0969', name: '第三代半导体', changePercent: 4.82 },
        { code: 'BK0574', name: '新能源车', changePercent: 4.25 },
      ],
    },
  },
}

const readyGlobalQuotesResult = {
  ok: true as const,
  value: {
    protocolVersion: 1,
    fetchedAt: '2026-08-03T01:00:00.000Z',
    quotes: [
      { id: 'sse', price: 3831.58, previousClose: 3832.46, open: 3820.12, high: 3842.18, low: 3815.64, change: -0.88, changePercent: -0.02, marketTime: '2026-08-03 08:50:00' },
      { id: 'hangSeng', price: 25356.97, previousClose: 25652.82, open: null, high: null, low: null, change: -295.85, changePercent: -1.15, marketTime: '' },
      { id: 'nasdaq', price: 26445.45, previousClose: 26605.36, open: null, high: null, low: null, change: -159.91, changePercent: -0.60, marketTime: '' },
      { id: 'kospi', price: 6606.37, previousClose: 6345.53, open: 6438.50, high: 6621.29, low: 6413.50, change: 260.84, changePercent: 4.11, marketTime: '2026-08-12 10:44:00' },
      { id: 'nikkei', price: 67039.96, previousClose: 66970.22, open: 66994.05, high: 67144.36, low: 66735.76, change: 69.74, changePercent: 0.10, marketTime: '2026-08-12 10:30:01' },
      { id: 'brent', price: 89.647, previousClose: 88.91, open: 89.17, high: 89.73, low: 89.08, change: 0.737, changePercent: 0.829, marketTime: '2026-08-12 10:43:40' },
      { id: 'newYorkGold', price: 4465.286, previousClose: 4441.10, open: 4430, high: 4467.60, low: 4421.40, change: 24.186, changePercent: 0.545, marketTime: '2026-08-12 10:44:09' },
    ],
    unavailable: [],
  },
}

const readyNewsResult = {
  ok: true as const,
  value: {
    protocolVersion: 1,
    fetchedAt: '2026-08-03T01:00:00.000Z',
    items: [
      { id: 'n1', title: '北京楼市新政落地', time: '2026-08-03 08:50:00', summary: '摘要一' },
      { id: 'n2', title: '两市成交额突破万亿', time: '2026-08-03 09:10:00', summary: '摘要二' },
    ],
  },
}

afterEach(() => {
  cleanup()
  vi.restoreAllMocks()
})

describe('StockMarketView', () => {
  it('uses market-session polling and bounded failure backoff', () => {
    expect(marketPollingInterval('indices', 'trading')).toBe(5_000)
    expect(marketPollingInterval('indices', 'auction')).toBe(5_000)
    expect(marketPollingInterval('indices', 'break')).toBe(60_000)
    expect(marketPollingInterval('indices', 'closed')).toBe(60_000)
    expect(marketPollingInterval('turnover', 'trading')).toBe(10_000)
    expect(marketPollingInterval('turnover', 'preopen')).toBeUndefined()
    expect(marketPollingInterval('movers', 'break')).toBeUndefined()
    expect(marketPollingInterval('headlines', 'closed')).toBe(60_000)
    expect(marketPollingDelay(5_000, 0)).toBe(5_000)
    expect(marketPollingDelay(5_000, 1)).toBe(10_000)
    expect(marketPollingDelay(5_000, 20)).toBe(300_000)
  })

  it('maps intraday points onto the complete A-share trading session', () => {
    expect(marketTrendTimeRatio('2026-08-03 09:30')).toBe(0)
    expect(marketTrendTimeRatio('10:30')).toBe(0.25)
    expect(marketTrendTimeRatio('11:30')).toBe(0.5)
    expect(marketTrendTimeRatio('13:00')).toBe(0.5)
    expect(marketTrendTimeRatio('14:00:00')).toBe(0.75)
    expect(marketTrendTimeRatio('2026-08-03 15:00:00')).toBe(1)
    expect(marketTrendTimeRatio('09:29')).toBeUndefined()
    expect(marketTrendTimeRatio('12:00')).toBeUndefined()
    expect(marketTrendTimeRatio('15:01')).toBeUndefined()
    expect(marketTrendTimeRatio('invalid')).toBeUndefined()
  })

  it('renders the live overview', async () => {
    vi.spyOn(Math, 'random').mockReturnValue(0)
    const call = readyCall()
    render(<StockMarketView {...viewProps(connectionWith(call))} />)

    expect(await screen.findByLabelText('上证指数')).toBeTruthy()
    expect(screen.getByLabelText('科创综指')).toBeTruthy()
    expect(screen.getByLabelText('全球市场行情')).toBeTruthy()
    expect(screen.getByLabelText(/恒生指数全球行情/u).textContent).toContain('25,356.97')
    expect(screen.getByLabelText(/韩国综合全球行情/u).textContent).toContain('+4.11%')
    expect(screen.getByLabelText(/布伦特原油全球行情/u).textContent).toContain('89.65')
    expect(screen.getByLabelText(/纽约金主连全球行情/u).textContent).toContain('4,465.29')
    expect(screen.queryByText('指数、成交与沪深涨跌分布')).toBeNull()
    expect(screen.queryByText(/市场概览\(/u)).toBeNull()
    expect(screen.getByText('数据更新时间：8月3日 8时50分0秒')).toBeTruthy()
    expect(screen.getByLabelText('上证指数').textContent).toContain('3,831.58')
    expect(screen.getByLabelText('上证指数').textContent).not.toContain('3,831.582')
    expect(screen.getByLabelText('上证指数').textContent).toContain('高 3,842.18')
    expect(screen.getByLabelText('上证指数').textContent).not.toContain('成交')
    expect(screen.getByLabelText('深证成指').textContent).toContain('+22.13')
    const sseTrend = screen.getByLabelText('上证指数当日分时走势')
    expect(sseTrend).toBeTruthy()
    expect(sseTrend.querySelector('polyline')?.getAttribute('points')?.split(' ').map(point => point.split(',')[0])).toEqual(['0.00', '15.00'])
    expect(screen.getByLabelText('沪深两市成交额').textContent).toContain('两市成交总额 10,200亿')
    expect(screen.getByLabelText('沪深两市成交额').textContent).toContain('较上一日增量 +200亿')
    const compactBreadth = screen.getByLabelText('沪深A股涨跌：上涨 1576，下跌 3549')
    expect(compactBreadth.textContent).not.toContain('平')
    const compactBreadthSegments = compactBreadth.querySelector('[aria-hidden="true"]')?.querySelectorAll('span')
    expect(compactBreadthSegments).toHaveLength(3)
    expect(parseFloat((compactBreadthSegments?.[1] as HTMLElement).style.width)).toBeGreaterThan(0)
    expect(screen.queryByText('涨跌家数')).toBeNull()
    expect(screen.queryByText('实时排行')).toBeNull()
    expect(screen.queryByText('沪深 A 股盘口快照')).toBeNull()
    expect(screen.getByLabelText('实时排行')).toBeTruthy()
    expect((await screen.findAllByText('N超纯')).length).toBe(4)
    const gainersCard = screen.getByLabelText('个股涨幅排行卡片')
    const losersCard = screen.getByLabelText('个股跌幅排行卡片')
    const inflowCard = screen.getByLabelText('资金流入排行卡片')
    const outflowCard = screen.getByLabelText('资金流出排行卡片')
    expect(gainersCard.className).toBe(inflowCard.className)
    expect(losersCard.className).toBe(outflowCard.className)
    expect(gainersCard.className).not.toBe(losersCard.className)
    expect(screen.getByLabelText('资金流入排行').textContent).toContain('+86.00 亿')
    expect(screen.getByLabelText('资金流出排行').textContent).toContain('+86.00 亿')
    expect(screen.queryByRole('tab', { name: '成交量' })).toBeNull()
    expect(screen.getByRole('region', { name: '板块热点' })).toBeTruthy()
    expect(screen.queryByRole('heading', { name: '板块热点' })).toBeNull()
    expect(screen.queryByText('当日涨幅居前')).toBeNull()
    const industryCard = await screen.findByLabelText('行业涨幅卡片')
    const conceptCard = screen.getByLabelText('概念涨幅卡片')
    expect(industryCard.textContent).toContain('机器人')
    expect(conceptCard.textContent).toContain('人形机器人')
    expect(industryCard.className).not.toBe(conceptCard.className)
    expect(screen.getByRole('heading', { name: '行业涨幅' })).toBeTruthy()
    expect(screen.getByRole('heading', { name: '概念涨幅' })).toBeTruthy()
    expect(screen.getByLabelText('行业涨幅排行').childElementCount).toBe(5)
    expect(screen.getByLabelText('概念涨幅排行').childElementCount).toBe(5)
    expect(screen.queryByRole('tab', { name: '行业' })).toBeNull()
    expect(screen.queryByRole('tab', { name: '概念' })).toBeNull()
    expect(screen.queryByRole('tab', { name: '地域' })).toBeNull()
    expect(screen.queryByText('浙江板块')).toBeNull()
    const newsItems = await screen.findAllByText('北京楼市新政落地')
    expect(newsItems).toHaveLength(2)
    const headlinesCard = screen.getByRole('region', { name: '头条要闻' })
    const flashNewsCard = screen.getByRole('region', { name: '24小时快讯' })
    expect(headlinesCard.className).not.toBe(flashNewsCard.className)
    expect(headlinesCard.textContent).toContain('东方财富精选财经要闻')
    expect(flashNewsCard.textContent).toContain('东方财富 7x24 实时快讯')
    expect(screen.queryByText('个股资金流')).toBeNull()
    expect(screen.queryByText('龙虎榜')).toBeNull()
    expect(screen.queryByText('行业资金流向')).toBeNull()
    const investorQuote = screen.getByLabelText('投资名言')
    expect(investorQuote.textContent).toContain('在别人贪婪时恐惧，在别人恐惧时贪婪。')
    expect(investorQuote.textContent).toContain('沃伦·巴菲特')
    expect(call).toHaveBeenCalledWith(
      STOCK_MARKET_RPC_CHANNEL,
      STOCK_MARKET_INDICES_ENDPOINT,
      { protocolVersion: 1 },
      expect.any(AbortSignal),
    )
    expect(call).toHaveBeenCalledWith(
      STOCK_MARKET_RPC_CHANNEL,
      STOCK_MARKET_TURNOVER_ENDPOINT,
      { protocolVersion: 1 },
      expect.any(AbortSignal),
    )
    expect(call).toHaveBeenCalledWith(
      STOCK_MARKET_RPC_CHANNEL,
      STOCK_MARKET_BREADTH_ENDPOINT,
      { protocolVersion: 1 },
      expect.any(AbortSignal),
    )
    expect(call.mock.calls.some(([, endpoint]) => endpoint === STOCK_MARKET_HEADLINES_ENDPOINT)).toBe(true)
    expect(call.mock.calls.some(([, endpoint]) => endpoint === STOCK_MARKET_FLASH_NEWS_ENDPOINT)).toBe(true)
    expect(call).toHaveBeenCalledWith(
      STOCK_MARKET_RPC_CHANNEL,
      STOCK_MARKET_GLOBAL_QUOTES_ENDPOINT,
      { protocolVersion: 1 },
      expect.any(AbortSignal),
    )
    expect(call).toHaveBeenCalledTimes(9)
  })

  it('shows a recoverable error state when the index snapshot is unavailable', async () => {
    let indexCalls = 0
    const call = vi.fn(async (_channel: string, endpoint: string) => {
      if (endpoint === STOCK_MARKET_TURNOVER_ENDPOINT) return readyTurnoverResult
      if (endpoint === STOCK_MARKET_BREADTH_ENDPOINT) return readyBreadthResult
      if (endpoint === STOCK_MARKET_TRENDS_ENDPOINT) return readyTrendsResult
      if (endpoint === STOCK_MARKET_MOVERS_ENDPOINT) return readyMoversResult
      if (endpoint === STOCK_MARKET_HOTSPOTS_ENDPOINT) return readyHotspotsResult
      if (endpoint === STOCK_MARKET_GLOBAL_QUOTES_ENDPOINT) return readyGlobalQuotesResult
      if (endpoint === STOCK_MARKET_HEADLINES_ENDPOINT || endpoint === STOCK_MARKET_FLASH_NEWS_ENDPOINT) {
        return readyNewsResult
      }
      indexCalls += 1
      return indexCalls === 1
        ? { ok: false as const, error: { code: 'unavailable', message: '请先配置许可证。', details: {} } }
        : readyResult
    })
    render(<StockMarketView {...viewProps(connectionWith(call))} />)

    expect(await screen.findByText('请先配置许可证。')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: '重新加载' }))
    await waitFor(() => { expect(screen.getByLabelText('上证指数')).toBeTruthy() })
    expect(indexCalls).toBe(2)
  })

  it('aborts in-flight market requests when the view unmounts', async () => {
    const signals: AbortSignal[] = []
    const call = vi.fn((_channel: string, _endpoint: string, _payload: unknown, signal?: AbortSignal) => {
      if (signal !== undefined) signals.push(signal)
      return new Promise<never>(() => undefined)
    })
    const mounted = render(<StockMarketView {...viewProps(connectionWith(call))} />)

    await waitFor(() => { expect(call).toHaveBeenCalledTimes(9) })
    mounted.unmount()

    expect(signals).toHaveLength(9)
    expect(signals.every(signal => signal.aborted)).toBe(true)
  })

  it('loads the overview from a trusted remote page', async () => {
    const call = readyCall()
    render(<StockMarketView {...viewProps(connectionWith(call, false))} />)

    expect(await screen.findByLabelText('上证指数')).toBeTruthy()
    expect(await screen.findByRole('heading', { name: '行业涨幅' })).toBeTruthy()
    expect(call).toHaveBeenCalledTimes(9)
  })
})

function readyCall() {
  return vi.fn(async (_channel: string, endpoint: string) => {
    if (endpoint === STOCK_MARKET_INDICES_ENDPOINT) return readyResult
    if (endpoint === STOCK_MARKET_GLOBAL_QUOTES_ENDPOINT) return readyGlobalQuotesResult
    if (endpoint === STOCK_MARKET_TURNOVER_ENDPOINT) return readyTurnoverResult
    if (endpoint === STOCK_MARKET_BREADTH_ENDPOINT) return readyBreadthResult
    if (endpoint === STOCK_MARKET_TRENDS_ENDPOINT) return readyTrendsResult
    if (endpoint === STOCK_MARKET_MOVERS_ENDPOINT) return readyMoversResult
    if (endpoint === STOCK_MARKET_HOTSPOTS_ENDPOINT) return readyHotspotsResult
    if (endpoint === STOCK_MARKET_HEADLINES_ENDPOINT || endpoint === STOCK_MARKET_FLASH_NEWS_ENDPOINT) {
      return readyNewsResult
    }
    return { ok: false as const, error: { code: 'bad-request', message: '未知 endpoint', details: {} } }
  })
}

function connectionWith(call: (...args: any[]) => Promise<any>, isLoopback = true): ConnectionHandle {
  return {
    isLoopback,
    rpc: { call },
    api: {},
    start: () => ({ stop: () => undefined }),
  } as unknown as ConnectionHandle
}

function viewProps(
  connection: ConnectionHandle,
): StockMarketViewProps {
  return { connection, onBreadthChange: vi.fn() }
}
