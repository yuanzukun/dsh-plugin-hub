// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import {
  createStockMarketSideCardStore,
  STOCK_MARKET_SIDECARD_WIDTH_DEFAULT,
  STOCK_MARKET_SIDECARD_WIDTH_MAX,
  STOCK_MARKET_SIDECARD_WIDTH_MIN,
} from '../src/client/StockMarketSideCardState.ts'
import { installTestLocalStorage } from './local-storage.ts'

beforeEach(() => { installTestLocalStorage() })
afterEach(() => { window.localStorage.clear() })

describe('StockMarketSideCardStore', () => {
  it('uses the maximum supported width as the default', () => {
    expect(STOCK_MARKET_SIDECARD_WIDTH_DEFAULT).toBe(STOCK_MARKET_SIDECARD_WIDTH_MAX)
  })

  it('keeps panel state isolated by session and restores it from local storage', () => {
    const store = createStockMarketSideCardStore()

    store.setSession('session-a')
    store.reduce(state => ({ ...state, panelOpen: false, width: 512 }))

    store.setSession('session-b')
    expect(store.getSnapshot()).toEqual({
      sessionId: 'session-b',
      state: {
        panelOpen: true,
        width: STOCK_MARKET_SIDECARD_WIDTH_DEFAULT,
      },
    })

    store.setSession('session-a')
    expect(store.getSnapshot()).toEqual({
      sessionId: 'session-a',
      state: { panelOpen: false, width: 512 },
    })
  })

  it('normalizes malformed persisted values and clamps widths', () => {
    window.localStorage.setItem('dsh-stock-market:side-card:v2:bad', JSON.stringify({
      panelOpen: 'yes',
      width: Number.MAX_VALUE,
      activePanel: 'unknown',
    }))
    const store = createStockMarketSideCardStore()

    store.setSession('bad')
    expect(store.getSnapshot().state).toEqual({
      panelOpen: true,
      width: STOCK_MARKET_SIDECARD_WIDTH_MAX,
    })

    store.reduce(state => ({ ...state, width: 1 }))
    expect(store.getSnapshot().state?.width).toBe(STOCK_MARKET_SIDECARD_WIDTH_MIN)
  })

  it('can publish drag frames without persisting until resize completion', () => {
    const setItem = vi.spyOn(window.localStorage, 'setItem')
    const store = createStockMarketSideCardStore()
    store.setSession('session-a')

    store.reduce(state => ({ ...state, width: 520 }), { persist: false })
    store.reduce(state => ({ ...state, width: 500 }), { persist: false })

    expect(store.getSnapshot().state?.width).toBe(500)
    expect(setItem).not.toHaveBeenCalled()

    store.persist()
    expect(setItem).toHaveBeenCalledOnce()
  })

  it('clears the active state when no conversation is selected', () => {
    const store = createStockMarketSideCardStore()

    store.setSession('session-a')
    store.setSession(undefined)

    expect(store.getSnapshot()).toEqual({ sessionId: undefined, state: undefined })
  })
})
