import { afterEach, describe, expect, it, vi } from 'vitest'
import { StartIntervalGate } from '../src/stock-api/request-control.ts'

afterEach(() => { vi.restoreAllMocks() })

describe('StartIntervalGate', () => {
  it('does not let a cancelled queued request release later starts early', async () => {
    vi.spyOn(Date, 'now').mockReturnValue(0)
    const gate = new StartIntervalGate(100)
    const signal = new AbortController().signal

    await gate.wait(signal, vi.fn(async () => undefined))

    let releaseSecond: (() => void) | undefined
    const secondSleep = vi.fn(() => new Promise<void>((resolve) => { releaseSecond = resolve }))
    const second = gate.wait(signal, secondSleep)
    await vi.waitFor(() => { expect(secondSleep).toHaveBeenCalledWith(100, signal) })

    const cancelledController = new AbortController()
    const cancelled = gate.wait(cancelledController.signal, vi.fn(async () => undefined))
    const fourthSleep = vi.fn(async () => undefined)
    const fourth = gate.wait(signal, fourthSleep)

    cancelledController.abort()
    await expect(cancelled).rejects.toMatchObject({ kind: 'cancelled' })
    await Promise.resolve()
    expect(fourthSleep).not.toHaveBeenCalled()

    releaseSecond?.()
    await second
    await vi.waitFor(() => { expect(fourthSleep).toHaveBeenCalledWith(100, signal) })
    await fourth
  })
})
