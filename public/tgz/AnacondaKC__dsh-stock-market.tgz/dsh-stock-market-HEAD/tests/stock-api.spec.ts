import { describe, expect, it, vi } from 'vitest'
import { EASTMONEY_ENDPOINTS } from '../src/stock-api/catalog.ts'
import { StockApiService } from '../src/stock-api/service.ts'

describe('StockApiService', () => {
  it('keeps every stock_code catalog entry within the SH/SZ A-share code space', () => {
    const stockCodeParameters = EASTMONEY_ENDPOINTS.flatMap(endpoint => (
      endpoint.parameters
        .filter(parameter => parameter.name === 'stock_code')
        .map(parameter => ({ endpointId: endpoint.id, pattern: parameter.pattern }))
    ))

    expect(stockCodeParameters.length).toBeGreaterThan(0)
    for (const { endpointId, pattern } of stockCodeParameters) {
      expect(pattern, endpointId).toBeDefined()
      if (pattern === undefined) continue
      const expression = new RegExp(`^(?:${pattern})$`, 'u')
      expect(expression.test('600519'), endpointId).toBe(true)
      expect(expression.test('000001'), endpointId).toBe(true)
      expect(expression.test('900901'), endpointId).toBe(false)
      expect(expression.test('430047'), endpointId).toBe(false)
    }
  })

  it('rejects undeclared parameters before making a free-provider request', async () => {
    const fetcher = vi.fn()
    const service = serviceWith({ fetcher })

    await expect(service.executeEastMoney(
      'em_stock_profile',
      { stock_code: '600519', url: 'https://attacker.invalid' },
      new AbortController().signal,
    )).rejects.toMatchObject({ kind: 'bad-request' })
    expect(fetcher).not.toHaveBeenCalled()
  })

  it('uses only the fixed EastMoney host and retries one transient response', async () => {
    const fetcher = vi.fn()
      .mockResolvedValueOnce(textResponse(503, 'temporarily unavailable'))
      .mockResolvedValueOnce(jsonResponse({
        success: true,
        result: { count: 1, pages: 1, data: [{ SECURITY_CODE: '600519' }] },
      }))
    const sleep = vi.fn(async () => undefined)
    const service = serviceWith({ fetcher, sleep })

    const result = await service.executeEastMoney(
      'em_stock_profile',
      { stock_code: '600519' },
      new AbortController().signal,
    )

    expect(fetcher).toHaveBeenCalledTimes(2)
    const requestedUrl = String(fetcher.mock.calls[1]?.[0])
    expect(requestedUrl).toMatch(/^https:\/\/datacenter\.eastmoney\.com\/securities\/api\/data\/v1\/get\?/)
    expect(requestedUrl).toContain('SECUCODE')
    expect(result).toMatchObject({ provider: 'eastmoney', endpointId: 'em_stock_profile' })
  })

  it('parses the real EastMoney assignment wrapper without mistaking title parentheses for JSONP', async () => {
    const payload = {
      LivesList: [{
        id: 'news-1',
        title: '江波龙(301308.SZ)公告发布',
        digest: '正文同样包含(普通括号)',
        showtime: '2026-08-03 09:30:00',
      }],
    }
    const fetcher = vi.fn(async () => new Response(`var ajaxResult=${JSON.stringify(payload)};`))
    const service = serviceWith({ fetcher })

    const result = await service.executeEastMoney(
      'em_top_news',
      { limit: 1 },
      new AbortController().signal,
    )

    expect(result.data).toMatchObject({
      column: 101,
      items: [expect.objectContaining({ title: '江波龙(301308.SZ)公告发布' })],
    })
  })

  it('returns bounded research-report excerpts and normalized metadata', async () => {
    const fetcher = vi.fn(async (input: string | URL | Request) => {
      const url = String(input)
      if (url.includes('/report/jg')) {
        return jsonResponse({
          data: [{ title: '策略报告 A', orgSName: '测试机构', researcher: '研究员', publishDate: '2026-08-03 08:00:00', count: 2 }],
        })
      }
      if (url.includes('/report/list?')) {
        return jsonResponse({ data: [{ title: '策略报告 A', infoCode: 'AP-STRATEGY-1' }] })
      }
      if (url.includes('/api/content/rep')) {
        return jsonResponse({ data: { notice_content: `核心观点：\n${'内容'.repeat(2_100)}`, security: [] } })
      }
      throw new Error(`unexpected URL: ${url}`)
    })
    const service = serviceWith({ fetcher })

    const result = await service.executeEastMoney(
      'em_strategy_reports',
      { days: 1, top: 1 },
      new AbortController().signal,
    )
    const data = result.data as {
      reports: Array<Record<string, unknown>>
      contents: Array<{ art_code: string; content: string; content_truncated?: boolean }>
    }

    expect(data.reports).toEqual([{
      title: '策略报告 A',
      org_name: '测试机构',
      author: '研究员',
      publish_date: '2026-08-03',
      count: 2,
    }])
    expect(data.contents[0]).toMatchObject({ art_code: 'AP-STRATEGY-1', content_truncated: true })
    expect(data.contents[0]?.content).toHaveLength(4_000)
  })

  it('enriches stock reports with metadata and bounded summaries', async () => {
    const fetcher = vi.fn(async (input: string | URL | Request, init?: RequestInit) => {
      const url = String(input)
      if (url.includes('np-areport-pc.eastmoney.com')) {
        return jsonResponse({
          data: {
            total_hits: 1,
            list: [{
              title: '贵州茅台深度报告',
              source: '测试证券',
              eiTime: '2026-08-03 08:00:00',
              em_rating_name: '买入',
              aim_price: 1800,
              art_code: 'AP-STOCK-1',
              codes: [{ short_name: '贵州茅台' }],
            }],
          },
        })
      }
      if (url.includes('/report/list2')) {
        expect(init).toMatchObject({ method: 'POST' })
        return jsonResponse({
          data: [{
            infoCode: 'AP-STOCK-1',
            indvInduName: '白酒',
            ratingChange: 1,
            predictThisYearEps: 65.2,
          }],
        })
      }
      if (url.includes('/api/content/rep')) {
        return jsonResponse({
          data: {
            notice_content: `核心观点：\n${'增长'.repeat(600)}\n风险提示：测试风险`,
            attach_url: 'https://example.test/report.pdf',
            security: [{ stock: '600519' }],
          },
        })
      }
      throw new Error(`unexpected URL: ${url}`)
    })
    const service = serviceWith({ fetcher })

    const result = await service.executeEastMoney(
      'em_stock_reports',
      { stock_code: '600519', page: 1, limit: 1, content: 'summary' },
      new AbortController().signal,
    )
    const data = result.data as { reports: Array<Record<string, unknown>> }

    expect(data.reports[0]).toMatchObject({
      art_code: 'AP-STOCK-1',
      industry: '白酒',
      rating_change: 1,
      forecast: { predict_this_year_eps: 65.2 },
      summary_source: 'core_view',
      summary_available: true,
      summary_truncated: true,
      attach_url: 'https://example.test/report.pdf',
    })
    expect(String(data.reports[0]?.summary)).toHaveLength(1_000)
  })

  it('verifies stock ownership and bounds a full report excerpt', async () => {
    const fetcher = vi.fn(async () => jsonResponse({
      data: {
        title: '贵州茅台深度报告',
        short_name: '贵州茅台',
        notice_content: '正文'.repeat(2_500),
        attach_url: 'https://example.test/report.pdf',
        security: [{ stock: '600519' }],
      },
    }))
    const service = serviceWith({ fetcher })

    const result = await service.executeEastMoney(
      'em_stock_reports',
      { stock_code: '600519', content: 'full', art_code: 'AP-STOCK-1' },
      new AbortController().signal,
    )
    const data = result.data as { found: boolean; content: string; content_truncated?: boolean }

    expect(data.found).toBe(true)
    expect(data.content).toHaveLength(4_000)
    expect(data.content_truncated).toBe(true)
    expect(fetcher).toHaveBeenCalledTimes(1)
  })

  it('rejects EastMoney generated endpoint requests for non-SH/SZ stock codes before fetching', async () => {
    const fetcher = vi.fn(async () => jsonResponse({
      success: true,
      result: { count: 0, pages: 0, data: [] },
    }))
    const service = serviceWith({ fetcher })

    await expect(service.executeEastMoney(
      'em_stock_profile',
      { stock_code: '430047' },
      new AbortController().signal,
    )).rejects.toMatchObject({ kind: 'bad-request' })
    await expect(service.executeEastMoney(
      'em_stock_profile',
      { stock_code: '900901' },
      new AbortController().signal,
    )).rejects.toMatchObject({ kind: 'bad-request' })
    await expect(service.executeEastMoney(
      'em_stock_profile',
      { stock_code: '600519' },
      new AbortController().signal,
    )).resolves.toMatchObject({ endpointId: 'em_stock_profile' })
    expect(fetcher).toHaveBeenCalledTimes(1)
  })

  it('rejects malformed generated endpoint payloads instead of returning empty data', async () => {
    const f10 = serviceWith({
      fetcher: vi.fn(async () => jsonResponse({ success: true, result: {} })),
    })
    await expect(f10.executeEastMoney(
      'em_stock_profile',
      { stock_code: '600519' },
      new AbortController().signal,
    )).rejects.toThrow('result.data')

    const announcements = serviceWith({
      fetcher: vi.fn(async () => jsonResponse({ data: {} })),
    })
    await expect(announcements.executeEastMoney(
      'em_stock_announcements',
      { stock_code: '600519' },
      new AbortController().signal,
    )).rejects.toThrow('data.list')

    const news = serviceWith({
      fetcher: vi.fn(async () => new Response('var ajaxResult={"rc":-1};')),
    })
    await expect(news.executeEastMoney(
      'em_top_news',
      { limit: 1 },
      new AbortController().signal,
    )).rejects.toThrow('LivesList')
  })

})

function serviceWith({
  fetcher,
  sleep = async () => undefined,
}: {
  fetcher: ReturnType<typeof vi.fn>
  sleep?: (milliseconds: number, signal: AbortSignal) => Promise<void>
}): StockApiService {
  return new StockApiService({
    fetcher: fetcher as unknown as typeof fetch,
    sleep,
    now: () => new Date('2026-08-03T01:00:00.000Z'),
  })
}

function jsonResponse(payload: unknown): Response {
  return new Response(JSON.stringify(payload), {
    status: 200,
    headers: { 'Content-Type': 'application/json' },
  })
}

function textResponse(status: number, text: string): Response {
  return new Response(text, { status })
}
