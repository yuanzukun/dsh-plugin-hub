import type {
  ButtonHTMLAttributes,
  InputHTMLAttributes,
  ReactNode,
} from 'react'

export type StateDotState = 'done' | 'warning' | 'ongoing' | 'error'

export function Button({ icon, children, type = 'button', ...props }: {
  icon?: ReactNode
  children?: ReactNode
  variant?: string
  size?: string
} & ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button type={type} {...props}>{icon}{children}</button>
}

export function Input(props: InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} />
}

export function StateDot({ state }: { state: StateDotState }) {
  return <span aria-hidden="true" data-state={state} />
}

function TestIcon() {
  return <span aria-hidden="true" />
}

export const IconApiOutline14 = TestIcon
export const IconCheckOutline16 = TestIcon
export const IconChevronRightOutline14 = TestIcon
export const IconDataOutline16 = TestIcon
export const IconPanelLeftOutline16 = TestIcon
export const IconRefreshOutline16 = TestIcon
export const IconSettingsOutline16 = TestIcon
export const IconTrashOutline16 = TestIcon

export function Tooltip({ children }: { children: ReactNode }) {
  return <>{children}</>
}
