import { describe, expect, it, vi } from 'vitest'
import type { StockApiService } from '../src/stock-api/service.ts'
import { StockApiError } from '../src/stock-api/errors.ts'
import { createStockMarketTools } from '../src/stock-tools.ts'
import type { ToolDefinition } from '@deepseek-ai/dsh-tools'

interface RoutingCase {
  readonly tool: string
  readonly args: Record<string, unknown>
  readonly provider: 'EastMoney' | 'Tencent' | 'Sina' | 'Tonghuashun'
  readonly endpoint: string
}

const ROUTING_CASES: readonly RoutingCase[] = [
  { tool: 'stock_quote', args: { action: 'snapshot', symbols: ['600519.SH'], source: 'tencent' }, provider: 'Tencent', endpoint: 'tx_realtime_quotes' },
  { tool: 'stock_chart', args: { action: 'kline', symbol: '600519.SH', source: 'eastmoney' }, provider: 'EastMoney', endpoint: 'em_price_history' },
  { tool: 'stock_chart', args: { action: 'intraday', symbol: '600519.SH', source: 'tencent' }, provider: 'Tencent', endpoint: 'tx_intraday_trends' },
  { tool: 'stock_ranking', args: { action: 'stocks', source: 'eastmoney' }, provider: 'EastMoney', endpoint: 'em_market_snapshot' },
  { tool: 'stock_ranking', args: { action: 'sectors', source: 'tencent' }, provider: 'Tencent', endpoint: 'tx_sector_rank' },
  { tool: 'stock_ranking', args: { action: 'sector_members', sector_id: 'new_blhy', source: 'sina' }, provider: 'Sina', endpoint: 'sina_market_snapshot' },
  { tool: 'stock_ranking', args: { action: 'sector_catalog', sector_type: 'concept', source: 'sina' }, provider: 'Sina', endpoint: 'sina_concept_catalog' },
  { tool: 'stock_money_flow', args: { action: 'stock_history', symbol: '600519.SH', source: 'eastmoney' }, provider: 'EastMoney', endpoint: 'em_money_flow_history' },
  { tool: 'stock_money_flow', args: { action: 'stock_intraday', symbol: '600519.SH' }, provider: 'EastMoney', endpoint: 'em_money_flow_intraday' },
  { tool: 'stock_money_flow', args: { action: 'sector' }, provider: 'EastMoney', endpoint: 'em_market_snapshot' },
  { tool: 'stock_money_flow', args: { action: 'sector', source: 'sina' }, provider: 'Sina', endpoint: 'sina_sector_money_flow' },
  { tool: 'stock_money_flow', args: { action: 'connect' }, provider: 'EastMoney', endpoint: 'em_connect_flow' },
  { tool: 'stock_fundamentals', args: { action: 'financials', symbol: '600519.SH' }, provider: 'EastMoney', endpoint: 'em_financial_summary' },
  { tool: 'stock_fundamentals', args: { action: 'shareholders', symbol: '600519.SH' }, provider: 'EastMoney', endpoint: 'em_shareholder_counts' },
  { tool: 'stock_fundamentals', args: { action: 'valuation', symbol: '600519.SH' }, provider: 'EastMoney', endpoint: 'em_valuation_percentiles' },
  { tool: 'stock_fundamentals', args: { action: 'operating_indicators', symbol: '600519.SH' }, provider: 'EastMoney', endpoint: 'em_supplementary_indicators' },
  { tool: 'stock_events', args: { action: 'announcements', symbol: '600519.SH', source: 'eastmoney' }, provider: 'EastMoney', endpoint: 'em_stock_announcements' },
  { tool: 'stock_events', args: { action: 'block_trades', symbol: '600519.SH' }, provider: 'EastMoney', endpoint: 'em_block_trades' },
  { tool: 'stock_events', args: { action: 'margin', scope: 'stock', symbol: '600519.SH' }, provider: 'EastMoney', endpoint: 'em_margin_trading' },
  { tool: 'stock_events', args: { action: 'margin', scope: 'market' }, provider: 'EastMoney', endpoint: 'em_datacenter_report' },
  { tool: 'stock_events', args: { action: 'dragon_tiger', scope: 'market', source: 'eastmoney' }, provider: 'EastMoney', endpoint: 'em_datacenter_report' },
  { tool: 'stock_events', args: { action: 'economic_calendar' }, provider: 'EastMoney', endpoint: 'em_datacenter_report' },
  { tool: 'stock_events', args: { action: 'convertible_bonds' }, provider: 'EastMoney', endpoint: 'em_datacenter_report' },
  { tool: 'stock_research', args: { action: 'market_reports' }, provider: 'EastMoney', endpoint: 'em_strategy_reports' },
  { tool: 'stock_research', args: { action: 'stock_reports', symbol: '600519.SH' }, provider: 'EastMoney', endpoint: 'em_stock_reports' },
  { tool: 'stock_research', args: { action: 'forecast', symbol: '600519.SH' }, provider: 'EastMoney', endpoint: 'em_profit_forecast' },
  { tool: 'stock_research', args: { action: 'ratings', symbol: '600519.SH' }, provider: 'EastMoney', endpoint: 'em_rating_statistics' },
  { tool: 'stock_news', args: { action: 'feed', feed: 'headlines', source: 'eastmoney' }, provider: 'EastMoney', endpoint: 'em_top_news' },
  { tool: 'stock_news', args: { action: 'stock_news', symbol: '600519.SH', source: 'tencent' }, provider: 'Tencent', endpoint: 'tx_stock_news' },
  { tool: 'stock_news', args: { action: 'search', keyword: '贵州茅台' }, provider: 'EastMoney', endpoint: 'em_global_search' },
  { tool: 'stock_news', args: { action: 'guba', mode: 'stock_page', symbol: '600519.SH' }, provider: 'EastMoney', endpoint: 'em_guba_page' },
]

describe('stock business action routing', () => {
  it.each(ROUTING_CASES)('$tool routes $args.action to $endpoint', async ({ tool, args, provider, endpoint }) => {
    const service = routingService()
    const definition = findTool(createStockMarketTools(service), tool)

    await expect(runTool(definition, args)).rejects.toThrow()
    const method = service[`execute${provider}` as keyof StockApiService] as unknown as ReturnType<typeof vi.fn>
    expect(method).toHaveBeenCalledWith(endpoint, expect.any(Object), expect.any(AbortSignal))
  })

  it('routes the profile aggregate to all requested sections', async () => {
    const called: string[] = []
    const service = {
      executeEastMoney: vi.fn(async (endpoint: string) => {
        called.push(endpoint)
        throw new StockApiError(`route:${endpoint}`, 'upstream')
      }),
    } as unknown as StockApiService
    const tool = findTool(createStockMarketTools(service), 'stock_fundamentals')

    await expect(runTool(tool, {
      action: 'profile', symbol: '600519.SH', sections: ['company', 'themes', 'industry'],
    })).rejects.toThrow('profile 的免费数据源暂时不可用')
    expect(called.sort()).toEqual(['em_core_themes', 'em_industry_comparison', 'em_stock_profile'])
  })

  it('routes stock dragon-tiger details to both record adapters', async () => {
    const called: string[] = []
    const service = {
      executeEastMoney: vi.fn(async (endpoint: string) => {
        called.push(endpoint)
        throw new StockApiError(`route:${endpoint}`, 'upstream')
      }),
    } as unknown as StockApiService
    const tool = findTool(createStockMarketTools(service), 'stock_events')

    await expect(runTool(tool, {
      action: 'dragon_tiger', scope: 'stock', symbol: '600519.SH', include_departments: true,
    })).rejects.toThrow('dragon_tiger 的免费数据源暂时不可用')
    expect(called.sort()).toEqual(['em_dragon_tiger_daily', 'em_dragon_tiger_departments'])
  })
})

function routingService(): StockApiService {
  const reject = vi.fn(async (endpoint: string) => {
    throw new StockApiError(`route:${endpoint}`, 'upstream')
  })
  return {
    executeEastMoney: reject,
    executeTencent: reject,
    executeSina: reject,
    executeTonghuashun: reject,
  } as unknown as StockApiService
}

function findTool(tools: ToolDefinition[], name: string): ToolDefinition {
  const tool = tools.find(candidate => candidate.name === name)
  if (tool === undefined) throw new Error(`missing tool: ${name}`)
  return tool
}

function runTool(tool: ToolDefinition, args: unknown): Promise<unknown> {
  return tool.execute(args, { signal: new AbortController().signal } as never)
}
