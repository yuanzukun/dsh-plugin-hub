import { describe, expect, it, vi } from 'vitest'
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import { apply } from '../src/client/index.ts'

interface Registration {
  options: Record<string, unknown>
  component: unknown
}

describe('client registration', () => {
  it('mounts one side card and contributes settings plus the composer switch', async () => {
    const registrations: Registration[] = []
    const connection = {
      isLoopback: true,
      rpc: {
        call: vi.fn(async () => ({
          ok: true,
          value: {
            protocolVersion: 1,
            config: {
              enabled: true,
              sidebarOpenByDefault: true,
              toolsEnabledByDefault: true,
            },
          },
        })),
      },
    } as unknown as ConnectionHandle
    const effect = vi.fn()
    const slots = {
      inject: vi.fn((_name: string, register: () => unknown) => register()),
      register: vi.fn((options: Record<string, unknown>, component: unknown) => {
        registrations.push({ options, component })
        return () => undefined
      }),
    }
    const ctx = {
      get: vi.fn(() => connection),
      effect,
      slots,
    }

    apply(ctx as never)
    expect(slots.inject.mock.calls.map(call => call[0])).toEqual([
      'settings.plugin.item',
    ])

    await vi.waitFor(() => {
      expect(effect).toHaveBeenCalledWith(expect.any(Function), 'dsh-stock-market: side card mount')
    })

    expect(effect).toHaveBeenCalledWith(expect.any(Function), 'dsh-stock-market: inline styles')
    expect(slots.inject.mock.calls.map(call => call[0])).toEqual([
      'settings.plugin.item',
      'conversation.input.left',
      'settings.section',
    ])
    expect(registrations.map(row => ({
      name: row.options.name,
      id: row.options.id,
      order: row.options.order,
    }))).toEqual([
      { name: 'settings.plugin.item', id: 'stock-market', order: 30 },
      { name: 'conversation.input.left', id: 'stock-tool-access', order: 30 },
      { name: 'settings.section', id: 'stock-market', order: 40 },
    ])
    expect((registrations[2]?.options.label as () => string)()).toBe('行情')
  })
})
