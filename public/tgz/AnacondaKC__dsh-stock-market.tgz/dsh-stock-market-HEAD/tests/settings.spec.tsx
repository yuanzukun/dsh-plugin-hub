// @vitest-environment jsdom
import { afterEach, describe, expect, it } from 'vitest'
import { cleanup, render, screen } from '@testing-library/react'
import { StockMarketSettings } from '../src/client/StockMarketSettings.tsx'

afterEach(cleanup)

describe('StockMarketSettings', () => {
  it('omits the deprecated market-data interface heading', () => {
    render(<StockMarketSettings />)

    expect(screen.queryByRole('heading', { name: '行情数据接口' })).toBeNull()
    expect(screen.queryByText('仅使用无需许可证、API Key 或登录凭据的免费数据源。')).toBeNull()
  })

  it('shows only the four credential-free data sources', () => {
    render(<StockMarketSettings />)

    expect(screen.getByRole('region', { name: '腾讯行情' })).toBeTruthy()
    expect(screen.getByRole('region', { name: '东方财富' })).toBeTruthy()
    expect(screen.getByRole('region', { name: '新浪财经' })).toBeTruthy()
    expect(screen.getByRole('region', { name: '同花顺' })).toBeTruthy()
    expect(screen.getAllByText('可直接使用')).toHaveLength(4)
    expect(screen.queryAllByRole('textbox')).toHaveLength(0)
  })

  it('shows all agent tools with actions, parameters, sources, and fallback behavior', () => {
    render(<StockMarketSettings />)

    expect(screen.getByRole('heading', { name: '已接入工具' })).toBeTruthy()
    expect(screen.getAllByRole('region', { name: /stock_\w+ 工具/u })).toHaveLength(9)

    const chart = screen.getByRole('region', { name: 'stock_chart 工具' })
    expect(chart.textContent).toContain('2 个动作')
    expect(chart.textContent).toContain('kline')
    expect(chart.textContent).toContain('symbol必填')
    expect(chart.textContent).toContain('period可选')
    expect(chart.textContent).toContain('东方财富 · 腾讯行情 · 新浪财经 · 同花顺')
    expect(chart.textContent).toContain('支持同字段结构故障切换')

    const capabilities = screen.getByRole('region', { name: 'stock_capabilities 工具' })
    expect(capabilities.textContent).toContain('插件内置')
    expect(capabilities.textContent).toContain('无需外部数据源切换')
    expect(screen.queryByText('stock_eastmoney')).toBeNull()
  })
})
