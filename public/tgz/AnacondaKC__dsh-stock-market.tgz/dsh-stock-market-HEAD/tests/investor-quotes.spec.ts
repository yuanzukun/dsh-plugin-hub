import { describe, expect, it } from 'vitest'
import { INVESTOR_QUOTES, pickInvestorQuote } from '../src/client/investor-quotes.ts'

describe('investor quotes', () => {
  it('contains the curated 31-quote collection', () => {
    expect(INVESTOR_QUOTES).toHaveLength(31)
    expect(INVESTOR_QUOTES[0]).toEqual({
      author: '沃伦·巴菲特',
      quote: '在别人贪婪时恐惧，在别人恐惧时贪婪。',
    })
    expect(INVESTOR_QUOTES.at(-1)).toEqual({
      author: '是川银藏',
      quote: '投资股票永远有风险。',
    })
  })

  it('selects a quote from the supplied random position', () => {
    expect(pickInvestorQuote(() => 0)).toBe(INVESTOR_QUOTES[0])
    expect(pickInvestorQuote(() => 0.999999)).toBe(INVESTOR_QUOTES.at(-1))
  })
})
