# Changelog

## 0.2.0 - 2026-08-13

### Added

- Added durable plugin-wide settings for the master switch, default sidebar state, and default per-session stock-tool state.
- Added the rc.5 `settings.plugin.item` configuration card so a disabled plugin can always be re-enabled from the Plugins settings page.
- Added host RPC endpoints and browser helpers for reading and saving plugin configuration.

### Changed

- Migrated host and client imports to scoped Cordis rc.4, scoped Schemastery rc.4, and DSH npm `next` rc.5 packages.
- Added the official settings-plugins slot contract and completed the client module injection graph.
- Updated the DSH workspace setup script for the reorganized package tree and scoped runtime modules.

### Fixed

- Registered the configuration card before asynchronous RPC loading, preventing a failed request from permanently hiding the recovery UI.
- Fell back to built-in configuration when the host RPC is unavailable or returns an incompatible payload.
- Removed the duplicate Cordis type graph from tests and builds.
- Fixed package verification under an outer `npm pack --dry-run` lifecycle.

## 0.1.0 - 2026-08-12

- Initial A-share market sidebar, fixed public-data adapters, and nine business-oriented stock tools.
