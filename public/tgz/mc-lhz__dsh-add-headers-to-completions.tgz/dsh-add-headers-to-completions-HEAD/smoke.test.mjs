// dsh-llm-headers 本地冒烟测试（零依赖：node smoke.test.mjs）
// 假 ctx + 本地 HTTP 回显服务器：注入 / 过滤 / 还原 / 防重复包装 /
// llm/stream+ALS 三层回退 / fill 与 override / settings 通道（注册+合并+重载）。
import http from 'node:http'
import { apply } from './index.js'

const originalFetch = globalThis.fetch
let passCount = 0
let failCount = 0

function check(name, ok, detail = '') {
  if (ok) passCount++
  else failCount++
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}  ${detail}`)
}

let ctx_provided = null
const makeCtx = () => {
  const effects = []
  const listeners = new Map()
  return {
    effects,
    on: (evt, fn) => { listeners.set(evt, fn) },
    emit: (evt, ...args) => { listeners.get(evt)?.(...args) },
    getLlmHandler: () => listeners.get('llm/stream'),
    logger: {
      info: (...a) => console.log('  [log ]', ...a),
      warn: (...a) => console.log('  [warn]', ...a),
    },
    provide: (name, value) => { ctx_provided = value },
    effect: (fn) => effects.push(fn),
  }
}
const dispose = (ctx) => {
  ctx.effects.forEach((fn) => fn())
  ctx.effects.length = 0
}

// settings 桩：register 记录命名空间，scope.replace 直接改 section（模拟持久化）；
// get(ns)/mutate(ns, ops) 模拟 llm-pi-ai 命名空间（真实通道同步的读写面）。
// 注意：用 getter/setter 暴露 state，避免 spread 拷贝导致外部读到旧副本。
const makeSettingsStub = (piaiDoc) => {
  const state = { registered: null, section: {}, piai: piaiDoc ?? null, watchCb: null }
  const applyOp = (node, op) => {
    if (op.path.length === 0) {
      if (op.op === 'unset') return {}
      return { ...op.value }
    }
    const [head, ...rest] = op.path
    if (rest.length === 0) {
      if (op.op === 'unset') { const { [head]: _d, ...kept } = node; return kept }
      return { ...node, [head]: op.value }
    }
    return { ...node, [head]: applyOp(node[head] ?? {}, { ...op, path: rest }) }
  }
  return {
    get registered() { return state.registered },
    get section() { return state.section },
    set section(value) { state.section = value },
    get: (ns) => (ns === 'llm-pi-ai' ? state.piai : undefined),
    mutate: (ns, ops) => {
      if (ns !== 'llm-pi-ai' || state.piai === null) return Promise.resolve()
      for (const op of ops) state.piai = applyOp(state.piai, op)
      return Promise.resolve()
    },
    register: (ns, _schema) => {
      state.registered = ns
      return {
        get: () => state.section,
        // 模拟真实 provider：replace 持久化并提交 → 触发注册表 watcher
        replace: (value) => { state.section = value; state.watchCb?.() },
        watch: (cb) => { state.watchCb = cb; return () => { state.watchCb = null } },
      }
    },
  }
}

let received = null
const server = http.createServer((req, res) => {
  received = req.headers
  req.resume()
  res.writeHead(200, { 'content-type': 'application/json' })
  res.end('{}')
})
await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve))
const baseUrl = `http://127.0.0.1:${server.address().port}`
console.log(`== echo server at ${baseUrl} ==\n`)

let ctx

// T1 命中 host -> 注入（legacy headers=global）+ 原有头保留
ctx = makeCtx()
await apply(ctx, { headers: { 'x-company': 'acme', 'x-trace': 't1' }, hosts: ['127.0.0.1'] })
await fetch(`${baseUrl}/t1`, { method: 'POST', headers: { authorization: 'Bearer sk-test' }, body: 'hello' })
check('T1 host 命中注入', received['x-company'] === 'acme' && received['x-trace'] === 't1')
check('T1 原有头保留', received['authorization'] === 'Bearer sk-test')

// T2 hosts 为空默认 -> 回环放行（本地反向代理是常见注入目标）、.local 跳过
dispose(ctx); ctx = makeCtx()
await apply(ctx, { headers: { 'x-company': 'acme' } })
await fetch(`${baseUrl}/t2`, { method: 'POST', body: 'hello' })
check('T2 空列表回环放行', received['x-company'] === 'acme')
const { matches } = await import('./index.js')
check('T2b 无 hosts 匹配 127.0.0.1', matches('127.0.0.1', []) === true)
check('T2c 无 hosts 跳过 .local', matches('myprinter.local', []) === false)
check('T2d 无 hosts 匹配普通域名', matches('api.deepseek.com', []) === true)
check('T2e hosts 后缀匹配', matches('proxy.example.com', ['example.com']) === true)

// T3 未提供 init 仍注入
dispose(ctx); ctx = makeCtx()
await apply(ctx, { headers: { 'x-n': '1' }, hosts: ['127.0.0.1'] })
await fetch(`${baseUrl}/t3`)
check('T3 无 init 注入', received['x-n'] === '1')

// T4 任意头名可注入 + CRLF 防护
dispose(ctx); ctx = makeCtx()
await apply(ctx, {
  headers: { 'x-custom-length': '999', 'x-evil': 'a\r\nInjected: b', 'x-ok': 'yes' },
  hosts: ['127.0.0.1'],
})
await fetch(`${baseUrl}/t4`, { method: 'POST', body: 'payload' })
check('T4 非禁用头名注入', received['x-custom-length'] === '999')
check('T4 CRLF 头被过滤', received['x-evil'] === undefined)
check('T4 合法头注入', received['x-ok'] === 'yes')

// T5 双重挂载（同插件另一 app 链再次 apply）不破坏请求链：
// 每次 apply 都叠一层自己的包装（防止卸载级联还原误杀），配置相同则结果一致
dispose(ctx); ctx = makeCtx()
await apply(ctx, { headers: { 'x-dup': '1' }, hosts: ['127.0.0.1'] })
const stray = makeCtx()
await apply(stray, { headers: { 'x-dup': '1' }, hosts: ['127.0.0.1'] })
await fetch(`${baseUrl}/t5`)
check('T5 双重挂载头一致', received['x-dup'] === '1')
dispose(stray) // 清理多余实例（还原到 ctx 的包装）

// T6 effect 还原原 fetch
dispose(ctx)
check('T6 卸载还原原 fetch', globalThis.fetch === originalFetch)

// T7 llmHeaders 服务(表形态)热更新（config 模式，无 settings）
ctx = makeCtx()
await apply(ctx, { headers: { 'x-a': '1' }, hosts: ['127.0.0.1'] })
ctx_provided.set({ global: { 'x-b': '2' } })
await fetch(`${baseUrl}/t7`)
const snap = ctx_provided.get()
check('T7 get() 表形态', snap.global['x-b'] === '2' && snap.global['x-a'] === undefined)
check('T7 set() 热更新生效', received['x-b'] === '2' && received['x-a'] === undefined)
dispose(ctx)
check('T7 卸载还原', globalThis.fetch === originalFetch)

// T8 llm/stream+ALS：模型绑定优先，provider 回退，global 兜底
dispose(ctx); ctx = makeCtx()
await apply(ctx, {
  hosts: ['127.0.0.1'],
  global: { 'x-glob': 'g1' },
  providers: { 'acme-gateway': { 'x-prov': 'p1' } },
  models: { 'acme-gateway/gpt-5': { 'x-model': 'm1' } },
})
const handler = ctx.getLlmHandler()
async function* fakeStream() {
  await fetch(`${baseUrl}/t8`, { method: 'POST', headers: { authorization: 'Bearer k' }, body: 'hello' })
  yield { type: 'finish', reason: { kind: 'ok' } }
}
for await (const _ of handler({ provider: 'acme-gateway', model: 'gpt-5' }, () => fakeStream())) {}
check('T8a 模型绑定头生效', received['x-model'] === 'm1')
check('T8a 更细层命中则不叠加 provider/global', received['x-prov'] === undefined && received['x-glob'] === undefined)
check('T8a 原有头保留', received['authorization'] === 'Bearer k')
for await (const _ of handler({ provider: 'acme-gateway', model: 'other-model' }, () => fakeStream())) {}
check('T8b 未命中模型→provider 回退', received['x-prov'] === 'p1' && received['x-model'] === undefined)
for await (const _ of handler({ provider: 'other-prov', model: 'm' }, () => fakeStream())) {}
check('T8c 未知 provider→global 兜底', received['x-glob'] === 'g1' && received['x-prov'] === undefined)
await fetch(`${baseUrl}/t8d`, { method: 'POST', body: 'x' })
check('T8d 无 store→global', received['x-glob'] === 'g1')

// T9 fill / override（默认 false = 我们配置的头覆盖同名头）
dispose(ctx); ctx = makeCtx()
await apply(ctx, { headers: { 'x-company': 'new' }, hosts: ['127.0.0.1'] }) // fill 默认
await fetch(`${baseUrl}/t9a`, { method: 'POST', headers: { 'x-company': 'old' }, body: 'x' })
check('T9 默认覆盖已有同名头', received['x-company'] === 'new')
dispose(ctx); ctx = makeCtx()
await apply(ctx, { headers: { 'x-company': 'new' }, hosts: ['127.0.0.1'], fill: true }) // 保留
await fetch(`${baseUrl}/t9b`, { method: 'POST', headers: { 'x-company': 'old' }, body: 'x' })
check('T9 fill:true 保留适配器已有同名头', received['x-company'] === 'old')
dispose(ctx)

// T10 settings 通道：注册命名空间 + 叠加合并 + document-updated 重载 + llmHeaders.set 落盘
// （plain-node 下真实 schemastery 不可解析 → 注入假 z 测试钩子，schema 仅被桩消费）
globalThis.__DSH_LLM_HEADERS_Z__ = {
  object: () => globalThis.__DSH_LLM_HEADERS_Z__,
  dict: () => globalThis.__DSH_LLM_HEADERS_Z__,
  string: () => globalThis.__DSH_LLM_HEADERS_Z__,
}
ctx = makeCtx()
const stub = makeSettingsStub()
ctx.settings = stub
await apply(ctx, { global: { 'x-a': 'cfg-a' }, hosts: ['127.0.0.1'] })
check('T10 注册命名空间', stub.registered === 'dsh-llm-headers')
await fetch(`${baseUrl}/t10a`, { method: 'POST', body: 'x' })
check('T10 初始=config', received['x-a'] === 'cfg-a')
// 设置侧写入（等价于 client 区块 mutate 落盘）
stub.section = { global: { 'x-b': 'set-b' } }
ctx.emit('settings/document-updated', 'dsh-llm-headers')
await fetch(`${baseUrl}/t10b`, { method: 'POST', body: 'x' })
check('T10 doc-updated 后重载(settings 叠加 config)', received['x-b'] === 'set-b' && received['x-a'] === 'cfg-a')
// llmHeaders.set → scope.replace（持久化到 settings）
ctx_provided.set({ global: { 'x-c': 'c3' } })
check('T10 llmHeaders.set 落 settings section', stub.section.global['x-c'] === 'c3')
ctx_provided.reset()
check('T10 llmHeaders.reset 清空 settings', stub.section.global === undefined)
stub.section = { global: { 'x-d': 'd4' } }
ctx.emit('settings/document-updated', 'dsh-llm-headers')
await fetch(`${baseUrl}/t10c`, { method: 'POST', body: 'x' })
check('T10 重载后生效', received['x-d'] === 'd4')
dispose(ctx)

// T11 真实通道同步：三层表 → llm-pi-ai.providers.<路由>.headers（mutate 路径）
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
ctx = makeCtx()
const piaiStub = makeSettingsStub({
  providers: {
    'pi1': {},
    'pi2': { headers: { 'x-manual': 'm1' } },
    'pi3': { baseURL: 'http://x', apiKeyEnv: 'K' }, // 无 headers，非 headers 字段须原样保留
  },
})
ctx.settings = piaiStub
await apply(ctx, { hosts: ['127.0.0.1'] }) // config 无头；三层表完全来自 settings 层（贴合真实：config=插件默认值为空）
// 界面写入等价物：llmHeaders.set（scope.replace → watch → reload → flush → 同步）
ctx_provided.set({ global: { 'User-Agent': 'opencode/1.18.18' }, providers: { 'pi2': { 'x-route': 'r2' } } })
await sleep(30)
check('T11 同步写 pi1.headers[User-Agent]', piaiStub.get('llm-pi-ai')?.providers.pi1.headers?.['User-Agent'] === 'opencode/1.18.18')
const pri2 = piaiStub.get('llm-pi-ai')?.providers.pi2.headers
check('T11 pi2 保留手写头 + 路由头 + global 合并', pri2?.['x-manual'] === 'm1' && pri2?.['x-route'] === 'r2' && pri2?.['User-Agent'] === 'opencode/1.18.18')
check('T11 pi3 无原 headers 也收到 global 头', piaiStub.get('llm-pi-ai')?.providers.pi3.headers?.['User-Agent'] === 'opencode/1.18.18')
check('T11 pi3 非 headers 字段未破坏', piaiStub.get('llm-pi-ai')?.providers.pi3.baseURL === 'http://x' && piaiStub.get('llm-pi-ai')?.providers.pi3.apiKeyEnv === 'K')
const touched = Object.keys(piaiStub.get('llm-pi-ai')?.providers.pi1 ?? {})
check('T11 pi1 未引入多余字段', touched.length === 1 && touched[0] === 'headers')
// 清空表 → pi1 unset；pi2 仅剩手写头
ctx_provided.reset()
await sleep(30)
check('T11 reset 后 pi1.headers unset', piaiStub.get('llm-pi-ai')?.providers.pi1.headers === undefined)
check('T11 reset 后 pi2 保留手写头', piaiStub.get('llm-pi-ai')?.providers.pi2.headers?.['x-manual'] === 'm1' && piaiStub.get('llm-pi-ai')?.providers.pi2.headers?.['User-Agent'] === undefined)
dispose(ctx)
// syncToProviders:false 关闭同步
const ctxOff = makeCtx()
const stubOff = makeSettingsStub({ providers: { 'px': {} } })
ctxOff.settings = stubOff
await apply(ctxOff, { global: { 'User-Agent': 'u' }, hosts: ['127.0.0.1'], syncToProviders: false })
await sleep(30)
check('T11 syncToProviders:false 关闭同步', stubOff.get('llm-pi-ai')?.providers.px.headers === undefined)
dispose(ctxOff)

server.close()
console.log(`\n== ${passCount} PASS, ${failCount} FAIL ==`)
process.exit(failCount === 0 ? 0 : 1)