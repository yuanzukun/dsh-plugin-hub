// 0.5.5 回归测试：锁定 Phase 0（止血）修复
//   ① engines/安装相关（静态检查由 scripts/pack-smoke.mjs 覆盖，这里只测运行时行为）
//   ② 安全三破口：sync.diff 选项注入 / render.out 路径穿越 / fingerprint source 越界
//   ③ receipt.json 自哈希 → receipt.sha256 sidecar；artifacts 不含自身
//   ④ 数据正确性：index 保留段、空 batch、孤儿 upsert、坏文件不静默、policy 缺失时环检测、delete 型 change 死锁
//   ⑤ 渲染安全：<title> 转义、CSP、/s+/g 正则修复
//   ⑥ 原子写：不残留 .tmp- 文件
import { mkdtempSync, rmSync, mkdirSync, writeFileSync, readFileSync, existsSync, readdirSync, unlinkSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { createHash } from 'node:crypto'
const core = await import(new URL('../lib/core/index.js', import.meta.url).href)

const PLUGIN = new URL('../lib/dsh/index.js', import.meta.url).href
const plug = await import(PLUGIN)
const tools = new Map()
plug.apply({ tools: { register: (d) => tools.set(d.name, d) }, skills: { register: () => () => {} },
  logger: { info: () => {}, warn: () => {} }, effect: () => {}, on: () => {} },
  { rootDir: '.', requireBilingual: true, devCompanionReminder: false, devCompanionReminderAfter: 8, toolset: 'full' })
const raw = (n, a) => tools.get(n).execute(a ?? {})
const call = async (n, a) => { try { return await raw(n, a) } catch (e) { return { ok: false, error: { code: 'thrown', message: String(e?.message ?? e) } } } }
const hex = (s) => createHash('sha256').update(s).digest('hex')
const L = (zh, en) => ({ zh, en })
const NOW = '2026-11-03T12:00:00Z'
const fails = []
const ok = (name, cond, extra = '') => { if (!cond) fails.push(name); console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${extra ? '  [' + String(extra).slice(0, 160) + ']' : ''}`) }
const fm = (id, parent, source = [], apis, extra = {}) => ({
  uid: hex('uid:' + id).slice(0, 8), id, parent,
  name: L(id, id), description: L('回归 ' + id, 'regression ' + id),
  source: source.map(p => ({ path: p, line: 1 })),
  revision: '0'.repeat(40), updated_at: NOW, fingerprint: 'pending', state: 'planned',
  ...(apis !== undefined ? { apis } : {}),
  ...extra,
})
const walkFiles = (dir) => {
  const out = []
  const rec = (d) => { for (const e of readdirSync(d, { withFileTypes: true })) { const p = join(d, e.name); if (e.isDirectory()) rec(p); else out.push(p) } }
  try { rec(dir) } catch { /* ignore */ }
  return out
}

const work = mkdtempSync(join(tmpdir(), 'normify-p0-'))
const REPO = join(work, 'repo')
mkdirSync(join(REPO, 'src'), { recursive: true })
writeFileSync(join(REPO, 'src', 'a.ts'), 'export const a = 1\n', 'utf8')
writeFileSync(join(REPO, 'src', 'b.ts'), 'export const b = 2\n', 'utf8')

console.log('== ① 安全：sync.diff 选项注入被拒绝（不创建仓库外文件） ==')
const SEC = join(work, 'normify-sec').replace(/\\/g, '/')
const init = await call('normify_project_init', { dir: SEC, root: { id: 'sec', name: L('安全', 'Sec'), description: L('安全测试项目', 'Security test project') } })
ok('①a 项目初始化', init.ok === true, JSON.stringify(init.error ?? init.root_module))
const attack = join(work, 'pwned.txt').replace(/\\/g, '/')
const inj = await call('normify_sync', { dir: SEC, repoRoot: REPO, diff: '--output=' + attack })
ok('①b diff 注入被拒绝', inj.ok === false && /args\/invalid-diff/.test(JSON.stringify(inj.error ?? inj.errors ?? '')), JSON.stringify(inj.error ?? inj.errors ?? '').slice(0, 140))
ok('①c 仓库外文件未被创建', existsSync(attack) === false)
const outTrav = await call('normify_render', { dir: SEC, out: '../../escaped.html' })
ok('①d render.out 路径穿越被拒绝', outTrav.ok === false && /render\/invalid-out|render\/no-build/.test(JSON.stringify(outTrav.errors ?? outTrav)), JSON.stringify(outTrav.errors ?? outTrav).slice(0, 140))
ok('①e 项目目录外未被写出', existsSync(join(work, 'escaped.html')) === false)
const fpTrav = await call('normify_fingerprint', { repoRoot: REPO, source: [{ path: '../../outside.txt' }] })
ok('①f fingerprint source 越界被拒绝', fpTrav.ok === false && /structure\/source-path-invalid/.test(JSON.stringify(fpTrav.errors ?? fpTrav)), JSON.stringify(fpTrav.errors ?? fpTrav).slice(0, 140))
const fpAbs = await call('normify_fingerprint', { repoRoot: REPO, source: [{ path: 'C:/Windows/win.ini' }] })
ok('①g fingerprint 绝对路径被拒绝', fpAbs.ok === false && /structure\/source-path-invalid/.test(JSON.stringify(fpAbs.errors ?? fpAbs)))

console.log('\n== ② 数据正确性：index 保留段 / 空 batch / 孤儿 upsert ==')
const idx = await call('normify_module_upsert', { dir: SEC, frontmatter: fm('sec.index', 'sec', []) })
ok('②a id 末段 index 被拒绝', idx.ok === false && /structure\/id-reserved/.test(JSON.stringify(idx.errors ?? idx)), JSON.stringify(idx.errors ?? idx).slice(0, 140))
const emptyBatch = await call('normify_module_batch', { dir: SEC, mode: 'upsert', items: [] })
ok('②b 空 batch 不再假成功', emptyBatch.ok === false && /args\/empty-batch/.test(JSON.stringify(emptyBatch.errors ?? emptyBatch)), JSON.stringify(emptyBatch.errors ?? emptyBatch).slice(0, 140))
const orphan = await call('normify_module_upsert', { dir: SEC, frontmatter: fm('nope.x', 'nope', ['src/a.ts'], []) })
ok('②c 孤儿 parent 单 upsert 被拒绝', orphan.ok === false && /structure\/parent-not-exist/.test(JSON.stringify(orphan.error ?? orphan.errors ?? orphan)), JSON.stringify(orphan.error ?? orphan.errors ?? '').slice(0, 140))

console.log('\n== ③ 编译：receipt 自哈希修复 + 原子写 ==')
const BUILD = join(work, 'normify-build').replace(/\\/g, '/')
await call('normify_project_init', { dir: BUILD, root: { id: 'bld', name: L('构建', 'Build'), description: L('构建测试', 'Build test') } })
const built = await call('normify_module_batch', { dir: BUILD, mode: 'upsert', items: [
  { frontmatter: fm('bld.core', 'bld', ['src/a.ts'], undefined) },
  { frontmatter: fm('bld.core.a', 'bld.core', ['src/a.ts'], [{ protocol: 'rpc', path: 'a/run', description: L('跑 a', 'run a') }]) },
] })
ok('③a 建树', built.ok === true, JSON.stringify(built.errors ?? '').slice(0, 100))
// 容器会触发父模块晋升；补一层渲染数据避免 layout/missing warning（不影响 build）
const b = await call('normify_build', { dir: BUILD })
ok('③b build 成功', b.ok === true, JSON.stringify(b.errors ?? '').slice(0, 140))
const receiptPath = join(BUILD, 'receipt.json')
const receiptText = existsSync(receiptPath) ? readFileSync(receiptPath, 'utf8') : ''
const receipt = receiptText ? JSON.parse(receiptText) : {}
ok('③c receipt.artifacts 不含自身', receipt.artifacts !== undefined && receipt.artifacts['receipt.json'] === undefined, JSON.stringify(Object.keys(receipt.artifacts ?? {})))
const sidecar = existsSync(join(BUILD, 'receipt.sha256')) ? readFileSync(join(BUILD, 'receipt.sha256'), 'utf8').trim() : ''
ok('③d receipt.sha256 sidecar 与文件字节一致', sidecar === hex(receiptText), sidecar.slice(0, 12) + ' vs ' + hex(receiptText).slice(0, 12))
const treeText = readFileSync(join(BUILD, 'tree.json'), 'utf8')
ok('③e tree.json 哈希可复算', receipt.artifacts?.['tree.json']?.sha256 === hex(treeText))
// P2-03 结构 SBOM + 回执自证（verify）
ok('③g structure-manifest.json 存在且回执登记 4 件产物', existsSync(join(BUILD, 'structure-manifest.json')) && Object.keys(receipt.artifacts ?? {}).length === 4 && receipt.artifacts?.['structure-manifest.json'] !== undefined, JSON.stringify(Object.keys(receipt.artifacts ?? {})))
const manifest = existsSync(join(BUILD, 'structure-manifest.json')) ? JSON.parse(readFileSync(join(BUILD, 'structure-manifest.json'), 'utf8')) : {}
ok('③h manifest 哈希与回执一致', manifest.hashes?.['tree.json'] === receipt.artifacts?.['tree.json']?.sha256 && manifest.hashes?.['api-index.json'] === receipt.artifacts?.['api-index.json']?.sha256, JSON.stringify(manifest.hashes ?? {}).slice(0, 120))
ok('③i manifest 含模块清单与 totals', Array.isArray(manifest.modules) && manifest.modules.length >= 1 && manifest.stats?.module_count === manifest.modules.length, JSON.stringify({ modules: manifest.modules?.length, stats: manifest.stats?.module_count }))
const verifyOk = await call('normify_build', { dir: BUILD, verify_only: true })
ok('③j verify_only 通过', verifyOk.ok === true && Array.isArray(verifyOk.artifacts) && verifyOk.artifacts.every(a => a.ok === true), JSON.stringify(verifyOk.errors ?? verifyOk.error ?? '').slice(0, 120))
const outlinePath = join(BUILD, 'outline.md')
const outlineBefore = readFileSync(outlinePath, 'utf8')
writeFileSync(outlinePath, 'tampered outline\n', 'utf8')
const verifyBad = await call('normify_build', { dir: BUILD, verify_only: true })
ok('③k 篡改产物被 verify 检出', verifyBad.ok === false && JSON.stringify(verifyBad.errors ?? verifyBad).includes('verify/hash-mismatch'), JSON.stringify(verifyBad.errors ?? verifyBad).slice(0, 140))
writeFileSync(outlinePath, outlineBefore, 'utf8')
ok('③l 恢复后 verify 通过', (await call('normify_build', { dir: BUILD, verify_only: true })).ok === true)

const tmpLeft = walkFiles(join(BUILD, 'modules')).filter(p => p.includes('.tmp-'))
ok('③f 原子写不残留 .tmp- 文件', tmpLeft.length === 0, tmpLeft.slice(0, 3).join(', '))

console.log('\n== ④ 坏文件不静默 + policy 缺失时环检测 + delete 型 change ==')
const BAD = join(work, 'normify-bad').replace(/\\/g, '/')
await call('normify_project_init', { dir: BAD, root: { id: 'bad', name: L('坏', 'Bad'), description: L('坏文件', 'bad file') } })
writeFileSync(join(BAD, 'modules', 'bad', 'broken.md'), '---\nuid: [unclosed\n---\n', 'utf8')
const getBad = await call('normify_module_get', { dir: BAD, id: 'bad' })
ok('④a 读工具遇到坏文件不再静默', getBad.ok === false && /input\/invalid-modules/.test(JSON.stringify(getBad.error ?? getBad.errors ?? '')), JSON.stringify(getBad.error ?? getBad.errors ?? '').slice(0, 160))

const CYC = join(work, 'normify-cyc').replace(/\\/g, '/')
await call('normify_project_init', { dir: CYC, root: { id: 'cyc', name: L('环', 'Cycle'), description: L('环检测', 'cycle check') } })
await call('normify_module_batch', { dir: CYC, mode: 'upsert', items: [
  { frontmatter: fm('cyc.x', 'cyc', ['src/a.ts'], [{ protocol: 'rpc', path: 'x/run', description: L('跑 x', 'run x') }], { deps: [{ kind: 'call', to: 'cyc.y' }] }) },
  { frontmatter: fm('cyc.y', 'cyc', ['src/b.ts'], [{ protocol: 'rpc', path: 'y/run', description: L('跑 y', 'run y') }], { deps: [{ kind: 'call', to: 'cyc.x' }] }) },
] })
unlinkSync(join(CYC, 'policy.yml'))
const cycVal = await call('normify_validate', { dir: CYC })
ok('④b policy 缺失时环依赖被 L2 拦截', cycVal.ok === false && /structure\/dependency-cycle/.test(JSON.stringify(cycVal.errors ?? cycVal)), JSON.stringify(cycVal.errors ?? cycVal).slice(0, 160))

const CHG = join(work, 'normify-chg').replace(/\\/g, '/')
await call('normify_project_init', { dir: CHG, root: { id: 'chg', name: L('变更', 'Change'), description: L('变更测试', 'change test') } })
await call('normify_module_batch', { dir: CHG, mode: 'upsert', items: [
  { frontmatter: fm('chg.c', 'chg', ['src/a.ts']) },
  { frontmatter: fm('chg.c.a', 'chg.c', ['src/a.ts'], [{ protocol: 'rpc', path: 'a/run', description: L('跑 a', 'run a') }]) },
  { frontmatter: fm('chg.c.b', 'chg.c', ['src/b.ts'], [{ protocol: 'rpc', path: 'b/run', description: L('跑 b', 'run b') }]) },
] })
const chgOpen = await call('normify_change_open', { dir: CHG, title: L('删除 a', 'delete a'), intent: L('测试 delete 死锁', 'delete deadlock'), modules: { delete: ['chg.c.a'] }, acceptance: ['a 被删除', 'validate 0 error'] })
ok('④c change_open 记录删除目标', chgOpen.ok === true, JSON.stringify(chgOpen.error ?? chgOpen.id ?? ''))
const chgFile = join(CHG, 'changes', String(chgOpen.id) + '.json')
const chgData = JSON.parse(readFileSync(chgFile, 'utf8'))
ok('④d change 内含 delete_snapshot', Array.isArray(chgData.delete_snapshot) && chgData.delete_snapshot.includes('chg.c.a'), JSON.stringify(chgData.delete_snapshot ?? null))
const delRes = await call('normify_module_delete', { dir: CHG, id: 'chg.c.a' })
ok('④e 删除模块', delRes.ok === true, JSON.stringify(delRes.error ?? ''))
const chgVal = await call('normify_validate', { dir: CHG })
ok('④f 删除后 L2 不再报 change/module-missing', chgVal.ok === true, JSON.stringify(chgVal.errors ?? chgVal).slice(0, 160))
const chgClose = await call('normify_change_close', { dir: CHG, id: String(chgOpen.id) })
ok('④g delete 型 change 可以关闭', chgClose.ok === true, JSON.stringify(chgClose.errors ?? chgClose.error ?? chgClose.phase ?? '').slice(0, 160))

console.log('\n== ⑤ 渲染安全：title 转义 / CSP / \\s 正则 ==')
const treeFile = join(BUILD, 'tree.json')
const t = JSON.parse(readFileSync(treeFile, 'utf8'))
t.project.name = '<img src=x onerror=alert(1)>'
writeFileSync(treeFile, JSON.stringify(t, null, 2) + '\n', 'utf8')
const rnd = await call('normify_render', { dir: BUILD })
ok('⑤a render 成功', rnd.ok === true, JSON.stringify(rnd.errors ?? '').slice(0, 120))
const html = existsSync(join(BUILD, 'normify.html')) ? readFileSync(join(BUILD, 'normify.html'), 'utf8') : ''
ok('⑤b <title> 已转义', /<title>&lt;img/.test(html))
ok('⑤c 未出现未转义的注入标签', !/<title><img/.test(html) && !/<img src=x onerror=alert\(1\)>/.test(html))
ok('⑤d 含 CSP meta', /Content-Security-Policy/.test(html))
ok('⑤e \\s 正则修复（不再是 /s+/g）', html.includes('/\\s+/g') && !html.includes('/s+/g'))
const outTrav2 = await call('normify_render', { dir: BUILD, out: '../../escaped2.html' })
ok('⑤f 已构建项目的 render.out 穿越被拒绝', outTrav2.ok === false && /render\/invalid-out/.test(JSON.stringify(outTrav2.errors ?? outTrav2)), JSON.stringify(outTrav2.errors ?? outTrav2).slice(0, 140))
ok('⑤g 没有写出项目目录', existsSync(join(work, 'escaped2.html')) === false)

console.log('\n== ⑥ 变更列表遇到坏变更文件不静默 ==')
const chgDir = join(CHG, 'changes')
writeFileSync(join(chgDir, '2026-11-03-broken.json'), '{ not valid json', 'utf8')
const listBad = await call('normify_change_list', { dir: CHG })
ok('⑥a change_list 返回解析错误', listBad.ok === false && /change\/json-parse/.test(JSON.stringify(listBad.errors ?? listBad)), JSON.stringify(listBad.errors ?? listBad).slice(0, 160))

console.log('\n== ⑦ 语义化结构 diff ==')
const DIFF = join(work, 'normify-diff').replace(/\\/g, '/')
await call('normify_project_init', { dir: DIFF, root: { id: 'dft', name: L('差异', 'Diff'), description: L('diff 测试', 'diff test') } })
const apiRun = [{ protocol: 'rpc', path: 'run', description: L('跑', 'run') }]
await call('normify_module_batch', { dir: DIFF, mode: 'upsert', items: [{ frontmatter: fm('dft.core', 'dft', ['src/a.ts'], apiRun) }] })
await call('normify_build', { dir: DIFF })
const beforeTree = JSON.parse(readFileSync(join(DIFF, 'tree.json'), 'utf8'))
await call('normify_module_batch', { dir: DIFF, mode: 'upsert', items: [{ frontmatter: fm('dft.core', 'dft', ['src/a.ts'], [...apiRun, { protocol: 'rpc', path: 'stop', description: L('停', 'stop') }]) }] })
await call('normify_build', { dir: DIFF })
const afterTree = JSON.parse(readFileSync(join(DIFF, 'tree.json'), 'utf8'))
const d1 = core.diffTrees(beforeTree, afterTree, 'before', 'after')
ok('⑦a diff 检出 API 新增与模块变化', d1.changed === true && d1.apis.added.includes('rpc:stop') && d1.modules.changed.some(c => c.id === 'dft.core' && c.fields.includes('apis')), JSON.stringify(d1.summary))
ok('⑦b 纯新增不算 breaking', d1.breaking === false)
await call('normify_module_batch', { dir: DIFF, mode: 'upsert', items: [{ frontmatter: fm('dft.core', 'dft', ['src/a.ts'], []) }] })
await call('normify_build', { dir: DIFF })
const afterTree2 = JSON.parse(readFileSync(join(DIFF, 'tree.json'), 'utf8'))
const d2 = core.diffTrees(afterTree, afterTree2, 'after', 'after-remove')
ok('⑦c diff 将 API 删除标记为 breaking', d2.breaking === true && d2.apis.removed.length >= 1, JSON.stringify(d2.apis.removed))
ok('⑦d diff 无变化时 changed=false', core.diffTrees(afterTree2, afterTree2).changed === false && core.diffTrees(afterTree2, afterTree2).summary === '结构无变化')

console.log('\n== ⑧ 根模块带 apis 后再写子模块（父晋升自删回归）==')
const ROOTAPI = join(work, 'normify-rootapi').replace(/\\/g, '/')
await call('normify_project_init', { dir: ROOTAPI, root: { id: 'rap', name: L('根API', 'RootApi'), description: L('根模块带 API', 'root with apis') } })
const rootWithApi = await call('normify_module_upsert', { dir: ROOTAPI, frontmatter: { ...fm('rap', null, ['src/a.ts'], [{ protocol: 'rpc', path: 'root/run', description: L('根跑', 'root run') }]) } })
ok('⑧a 根模块带 API 写入成功', rootWithApi.ok === true, JSON.stringify(rootWithApi.errors ?? rootWithApi.error ?? '').slice(0, 140))
const childAfterRoot = await call('normify_module_upsert', { dir: ROOTAPI, frontmatter: fm('rap.core', 'rap', ['src/a.ts'], []) })
ok('⑧b 再写子模块成功且父晋升给出 api 下放 warning', childAfterRoot.ok === true && (childAfterRoot.warnings ?? []).some(w => /api-dropped-on-promote/.test(String(w))), JSON.stringify(childAfterRoot.warnings ?? childAfterRoot.errors ?? '').slice(0, 160))
ok('⑧c 根模块文件仍然存在', existsSync(join(ROOTAPI, 'modules', 'rap', 'index.md')))
const rootAfter = await call('normify_module_get', { dir: ROOTAPI, id: 'rap' })
ok('⑧d 根模块仍可读取', rootAfter.ok === true, JSON.stringify(rootAfter.error ?? '').slice(0, 120))
const rootVal = await call('normify_validate', { dir: ROOTAPI })
ok('⑧e L2 = 0 error', rootVal.ok === true, JSON.stringify(rootVal.errors ?? rootVal).slice(0, 160))

console.log('\n== ⑨ 7 原语面（toolset=core）==')
const prim = core.createNormifyPrimitiveTools({ rootDir: work, requireBilingual: true, version: 'test', toolset: 'core' })
const pnames = prim.map(t => t.name).sort()
ok('⑨a 恰好 7 个原语', prim.length === 7 && JSON.stringify(pnames) === JSON.stringify(['normify_build', 'normify_change', 'normify_check', 'normify_project', 'normify_read', 'normify_render', 'normify_write']), JSON.stringify(pnames))
const P = (name) => prim.find(t => t.name === name).execute
const PDIR = join(work, 'normify-prim').replace(/\\/g, '/')
const pInit = await P('normify_project')({ op: 'init', dir: PDIR, root_module: { id: 'prm', name: L('原语', 'Prim'), description: L('原语测试', 'prim test') } })
ok('⑨b project init', pInit.ok === true, JSON.stringify(pInit.error ?? pInit.errors ?? '').slice(0, 120))
const pWrite = await P('normify_write')({ op: 'batch', dir: PDIR, mode: 'upsert', items: [{ frontmatter: fm('prm.core', 'prm', ['src/a.ts'], []) }] })
ok('⑨c write batch', pWrite.ok === true, JSON.stringify(pWrite.errors ?? pWrite.error ?? '').slice(0, 120))
const pStatus = await P('normify_project')({ op: 'status', dir: PDIR })
ok('⑨d project status', pStatus.ok === true && pStatus.count >= 2, JSON.stringify({ count: pStatus.count }))
const pVal = await P('normify_check')({ op: 'validate', dir: PDIR })
ok('⑨e check validate 0 error', pVal.ok === true, JSON.stringify(pVal.errors ?? '').slice(0, 120))
const pBuild = await P('normify_build')({ op: 'build', dir: PDIR })
ok('⑨f build 产出 SBOM + 回执', pBuild.ok === true && typeof pBuild.structure_manifest_sha256 === 'string' && typeof pBuild.receipt_sha256 === 'string', JSON.stringify({ ok: pBuild.ok }).slice(0, 80))
const pVerify = await P('normify_build')({ op: 'verify', dir: PDIR })
ok('⑨g build verify 通过', pVerify.ok === true && (pVerify.artifacts ?? []).length === 4)
const pRender = await P('normify_render')({ op: 'render', dir: PDIR })
ok('⑨h render', pRender.ok === true && typeof pRender.bytes === 'number')
const pChange = await P('normify_change')({ op: 'open', dir: PDIR, title: L('原语变更', 'primitive change'), intent: L('测试', 'test'), modules: {}, acceptance: ['ok'] })
ok('⑨i change open', pChange.ok === true, JSON.stringify(pChange.errors ?? pChange.error ?? '').slice(0, 120))

console.log('\n== ⑩ 文案长度校验一致性（issue #4）==')
const L10N = join(work, 'normify-l10n').replace(/\\/g, '/')
mkdirSync(join(L10N, 'modules', 'demo'), { recursive: true })
const rootFm = { uid: 'aa11bb22', id: 'demo', parent: null, name: L('演示', 'Demo'), description: L('根', 'root'), source: [], revision: '0'.repeat(40), updated_at: NOW, fingerprint: 'pending', state: 'planned' }
writeFileSync(join(L10N, 'modules', 'demo', 'index.md'), core.serializeModule(rootFm, ''), 'utf8')
const apiFm = { ...fm('demo.api', 'demo', ['src/a.ts'], [{ protocol: 'rpc', path: 'x', description: L('a'.repeat(250), 'b'.repeat(250)) }]) }
writeFileSync(join(L10N, 'modules', 'demo', 'api.md'), core.serializeModule(apiFm, ''), 'utf8')
const depFm = { ...fm('demo.dep', 'demo', ['src/b.ts'], []), deps: [{ kind: 'call', to: 'demo.api', label: L('短', 'x'.repeat(40)) }] }
writeFileSync(join(L10N, 'modules', 'demo', 'dep.md'), core.serializeModule(depFm, ''), 'utf8')
const strictVal = await call('normify_validate', { dir: L10N })
const strictCodes = JSON.stringify(strictVal.errors ?? [])
ok('⑩a API 描述超长产生 api/description-too-long', /api\/description-too-long/.test(strictCodes), strictCodes.slice(0, 120))
ok('⑩b dep label 超长产生 dep/label-too-long', /dep\/label-too-long/.test(strictCodes), strictCodes.slice(0, 120))
ok('⑩c 不再出现错误的 structure/label-too-long', !/structure\/label-too-long/.test(strictCodes))
const plugLoose = await import(PLUGIN)
const toolsLoose = new Map()
plugLoose.apply({ tools: { register: (d) => toolsLoose.set(d.name, d) }, skills: { register: () => () => {} },
  logger: { info: () => {}, warn: () => {} }, effect: () => {}, on: () => {} },
  { rootDir: '.', requireBilingual: false, devCompanionReminder: false, devCompanionReminderAfter: 8, toolset: 'full' })
const looseVal = await (toolsLoose.get('normify_validate').execute({ dir: L10N }))
const looseWarn = JSON.stringify(looseVal.warnings ?? [])
ok('⑩d 宽松模式：api/description 与 dep/label 统一降级 warning 且 0 error',
  looseVal.ok === true && (looseVal.errors ?? []).length === 0 && /api\/description-too-long/.test(looseWarn) && /dep\/label-too-long/.test(looseWarn),
  JSON.stringify({ ok: looseVal.ok, errors: (looseVal.errors ?? []).map(e => e.code ?? e), warnings: (looseVal.warnings ?? []).map(w => w.code ?? w) }))

console.log('\n=== 结果：' + (fails.length === 0 ? '全部 PASS' : 'FAIL ' + fails.length + ' 项 → ' + fails.join(' | ')) + ' ===')
rmSync(work, { recursive: true, force: true })
process.exit(fails.length === 0 ? 0 : 1)
