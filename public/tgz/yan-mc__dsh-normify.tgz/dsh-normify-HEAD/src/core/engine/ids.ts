import type { Api } from './types.js';
import { join } from 'node:path';
const SEG = /^[a-z0-9][a-z0-9-]*$/;
/** 保留段名：`index` 与容器文件 `index.md` 冲突（0.5.5 起在 L1 直接拒绝，见 issue #3）。 */
export const RESERVED_SEGMENTS: ReadonlySet<string> = new Set(['index']);
/** 返回 id 中第一个保留段名（无则 null），供诊断给出精确修法。 */
export function findReservedSegment(id: string): string | null {
    if (typeof id !== 'string')
        return null;
    for (const seg of id.split('.')) {
        if (RESERVED_SEGMENTS.has(seg))
            return seg;
    }
    return null;
}
// 深度不设上限：树要能按"单一功能单元"无限下钻。若项目确实需要限制层级，
// 用架构规则 policy.yml 的 max-depth 规则（作用域 + maxDepth）来表达，而不是写死在数据结构里。
export function splitId(id: string): string[] | null {
    if (typeof id !== 'string' || id.length === 0 || id.length > 4096)
        return null;
    const segs = id.split('.');
    if (segs.length === 0)
        return null;
    for (const s of segs) {
        if (!SEG.test(s))
            return null;
        if (RESERVED_SEGMENTS.has(s))
            return null;
    }
    return segs;
}
export function isValidId(id: string): boolean {
    return splitId(id) !== null;
}
/** 父 id = 去掉最后一段；单段（树名/根）的父为 null。 */
export function deriveParent(id: string): string | null {
    const segs = splitId(id);
    if (segs === null)
        return null;
    return segs.length === 1 ? null : segs.slice(0, -1).join('.');
}
export function treeOf(id: string): string {
    const segs = splitId(id);
    return segs === null ? '' : segs[0];
}
export function depthOf(id: string): number {
    const segs = splitId(id);
    return segs === null ? 0 : segs.length;
}
export function slugify(name: string): string {
    return String(name)
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '')
        .slice(0, 64) || 'project';
}
/** API 键：http 类为 "METHOD path"，其余为 "protocol:path"。 */
export function apiKey(api: Api): string {
    const proto = String(api.protocol).toLowerCase();
    if (proto === 'http') {
        return String(api.method ?? '').toUpperCase() + ' ' + api.path;
    }
    return proto + ':' + api.path;
}
/** modules/ 相对路径 → 模块 id（根 <tree>/index.md → <tree>）。 */
export function idFromFilePath(relPath: string): string | null {
    const rel = relPath.replace(/\\/g, '/');
    if (!rel.startsWith('modules/'))
        return null;
    const parts = rel.slice('modules/'.length).split('/');
    const file = parts.pop();
    if (file === undefined || !file.endsWith('.md'))
        return null;
    if (parts.length === 0)
        return null;
    const stem = file.slice(0, -3);
    const segs = stem === 'index' ? parts : [...parts, stem];
    for (const s of segs)
        if (!SEG.test(s))
            return null;
    return segs.join('.');
}
/** 模块文件的绝对路径。容器 = <seg>/index.md，叶子 = <last>.md，根 = modules/<tree>/index.md。 */
export function moduleFilePath(projectDir: string, id: string, isContainer: boolean): string {
    const segs = splitId(id);
    if (segs === null)
        throw new Error('normify: invalid module id: ' + JSON.stringify(id));
    const tree = segs[0];
    if (segs.length === 1)
        return join(projectDir, 'modules', tree, 'index.md');
    const rest = segs.slice(1);
    if (isContainer)
        return join(projectDir, 'modules', tree, ...rest, 'index.md');
    const last = rest[rest.length - 1];
    return join(projectDir, 'modules', tree, ...rest.slice(0, -1), last + '.md');
}
