import { join } from 'node:path';
import { readFile } from 'node:fs/promises';
import { apiKey, depthOf, treeOf } from './ids.js';
import { sha256Text } from './store.js';
import { writeFileAtomic } from './atomic.js';
import type { Api, Dep, Diagnostic, LayoutData, LocalizedText, ModuleState, SourceRef } from './types.js';
import { validateProject, type ValidateOptions, type ValidateOutput } from './validate.js';
import { diag } from './diag.js';
export interface BuildOptions extends ValidateOptions {
    /** 生成器版本（写入 structure-manifest.json 的 generator.version；默认 '0' 便于测试）。 */
    generatorVersion?: string;
}
export interface BuildOutput {
    ok: boolean;
    receipt: Record<string, unknown> | null;
    /** receipt.json 自身的 SHA-256（写入 receipt.sha256 sidecar；receipt 内部不含自身哈希，见 P0-03）。 */
    receiptSha256: string | null;
    /** structure-manifest.json（结构 SBOM）的 SHA-256。 */
    manifestSha256: string | null;
    errors: Diagnostic[];
    warnings: Diagnostic[];
    validate: ValidateOutput | null;
}
/** tree.json 里的单个模块摘要（编译期归一化后的结构数据）。 */
interface ModuleSummary {
    uid: string;
    id: string;
    parent: string | null;
    tree: string;
    depth: number;
    state?: ModuleState;
    replacement?: string;
    tags?: string[];
    name: LocalizedText;
    description: LocalizedText;
    source: SourceRef[];
    revision: string;
    updated_at: string;
    fingerprint: string;
    repository?: string;
    apis?: Array<Api & { key: string }>;
    deps?: Array<Dep & { cross_tree: boolean }>;
    aggregate: {
        descendant_count: number;
        own_api_count: number;
        inherited_api_count: number;
        dep_out: number;
        dep_in: number;
    };
}
/** tree.json 里的单条依赖边（带跨树标记）。 */
interface TreeEdge {
    from: string;
    from_api: string | undefined;
    to: string;
    to_api: string | undefined;
    kind: string;
    cross_tree: boolean;
    label: LocalizedText | undefined;
}
function oneLine(desc: string, max = 100): string {
    const line = desc.split(/\r?\n/)[0]?.trim() ?? '';
    return line.length > max ? line.slice(0, max) + '…' : line;
}
function outlineText(slug: string, v: ValidateOutput): string {
    const files = [...v.files].sort((a, b) => a.module.id.localeCompare(b.module.id));
    const byId = new Map(files.map(f => [f.module.id, f.module]));
    const roots = files.filter(f => f.module.parent === null).sort((a, b) => a.module.id.localeCompare(b.module.id));
    const descendantMemo = new Map<string, number>();
    const countDesc = (id: string): number => {
        const hit = descendantMemo.get(id);
        if (hit !== undefined)
            return hit;
        const kids = v.childrenOf.get(id) ?? [];
        let total = kids.length;
        for (const k of kids)
            total += countDesc(k);
        descendantMemo.set(id, total);
        return total;
    };
    const apiCount = (id: string): number => {
        const kids = v.childrenOf.get(id) ?? [];
        let total = 0;
        for (const k of kids) {
            const m = byId.get(k);
            total += (m !== undefined && m.apis !== undefined ? m.apis.length : 0) + apiCount(k);
        }
        return total;
    };
    const lines: string[] = [];
    lines.push('# ' + slug + ' · Normify Outline');
    lines.push('');
    lines.push('> 派生索引（每次 normify_build 重建）。AI 导航入口：先广度后深度。');
    lines.push('');
    const walk = (id: string, indent: number): void => {
        const m = byId.get(id);
        if (m === undefined)
            return;
        const modules = countDesc(id) + 1;
        const apis = (m.apis?.length ?? 0) + apiCount(id);
        lines.push('  '.repeat(indent) + '- ' + id
            + (m.state === 'planned' ? ' [计划]' : m.state === 'deprecated' ? ' [废弃]' : '')
            + ' — ' + m.name.zh + ' / ' + m.name.en
            + ' — ' + oneLine(m.description.zh, 80)
            + ' — [模块 ' + modules + ' · API ' + apis + ']');
        for (const k of v.childrenOf.get(id) ?? [])
            walk(k, indent + 1);
    };
    for (const r of roots) {
        const m = r.module;
        lines.push('## ' + m.id + (m.repository !== undefined ? '（' + m.repository + '）' : ''));
        lines.push('');
        walk(m.id, 0);
        lines.push('');
    }
    return lines.join('\n') + '\n';
}
/** L3：校验通过后编译 tree.json / outline.md / api-index.json / receipt.json（冻结）。 */
export async function buildProject(projectDir: string, opts: BuildOptions): Promise<BuildOutput> {
    const v = await validateProject(projectDir, opts);
    if (!v.ok) {
        return { ok: false, receipt: null, receiptSha256: null, manifestSha256: null, errors: v.errors, warnings: v.warnings, validate: v };
    }
    const slug = projectDir.split(/[\\\/]/).pop() ?? 'project';
    const files = [...v.files].sort((a, b) => a.module.id.localeCompare(b.module.id));
    const byId = new Map(files.map(f => [f.module.id, f.module]));
    const roots = files.filter(f => f.module.parent === null).sort((a, b) => a.module.id.localeCompare(b.module.id));
    const descendantMemo = new Map<string, number>();
    const countDesc = (id: string): number => {
        const hit = descendantMemo.get(id);
        if (hit !== undefined)
            return hit;
        const kids = v.childrenOf.get(id) ?? [];
        let total = kids.length;
        for (const k of kids)
            total += countDesc(k);
        descendantMemo.set(id, total);
        return total;
    };
    const apiBelow = (id: string): number => {
        let total = 0;
        for (const k of v.childrenOf.get(id) ?? []) {
            const m = byId.get(k);
            total += (m !== undefined && m.apis !== undefined ? m.apis.length : 0) + apiBelow(k);
        }
        return total;
    };
    const depIn = new Map<string, number>();
    let depCount = 0;
    let crossTreeDepCount = 0;
    const edges: TreeEdge[] = [];
    for (const f of files) {
        const m = f.module;
        if (m.deps === undefined)
            continue;
        for (const d of m.deps) {
            depCount++;
            depIn.set(d.to, (depIn.get(d.to) ?? 0) + 1);
            const cross = treeOf(d.to) !== treeOf(m.id);
            if (cross)
                crossTreeDepCount++;
            edges.push({
                from: m.id,
                from_api: d.from_api,
                to: d.to,
                to_api: d.to_api,
                kind: d.kind,
                cross_tree: cross,
                label: d.label,
            });
        }
    }
    edges.sort((a, b) => String(a.from).localeCompare(String(b.from)) || String(a.to).localeCompare(String(b.to)));
    const modules: Record<string, ModuleSummary> = {};
    let apiCount = 0;
    let leafCount = 0;
    let maxDepth = 0;
    let plannedCount = 0;
    let deprecatedCount = 0;
    for (const f of files) {
        const m = f.module;
        const ownApis = m.apis ?? [];
        apiCount += ownApis.length;
        const isLeaf = !v.childrenOf.has(m.id);
        if (isLeaf)
            leafCount++;
        maxDepth = Math.max(maxDepth, depthOf(m.id));
        if (m.state === 'planned')
            plannedCount++;
        if (m.state === 'deprecated')
            deprecatedCount++;
        modules[m.id] = {
            uid: m.uid,
            id: m.id,
            parent: m.parent,
            tree: treeOf(m.id),
            depth: depthOf(m.id),
            ...(m.state !== undefined ? { state: m.state } : {}),
            ...(m.replacement !== undefined ? { replacement: m.replacement } : {}),
            ...(m.tags !== undefined ? { tags: m.tags } : {}),
            name: m.name,
            description: m.description,
            source: m.source,
            revision: m.revision,
            updated_at: m.updated_at,
            fingerprint: m.fingerprint,
            ...(m.repository !== undefined ? { repository: m.repository } : {}),
            ...(ownApis.length > 0 ? { apis: ownApis.map(a => ({ ...a, key: apiKey(a) })) } : {}),
            ...(m.deps !== undefined && m.deps.length > 0 ? { deps: m.deps.map(d => ({ ...d, cross_tree: treeOf(d.to) !== treeOf(m.id) })) } : {}),
            aggregate: {
                descendant_count: countDesc(m.id),
                own_api_count: ownApis.length,
                inherited_api_count: apiBelow(m.id),
                dep_out: m.deps?.length ?? 0,
                dep_in: depIn.get(m.id) ?? 0,
            },
        };
    }
    const apiIndex: Record<string, string> = {};
    for (const f of files) {
        const m = f.module;
        for (const a of m.apis ?? [])
            apiIndex[apiKey(a)] = m.id;
    }
    const compiledAt = new Date().toISOString();
    const layouts: Record<string, LayoutData | undefined> = {};
    for (const id of [...v.layouts.keys()].sort())
        layouts[id] = v.layouts.get(id);
    const treeJson = {
        schema_version: 1,
        project: {
            name: slug,
            trees: roots.map(r => ({
                tree_id: r.module.id,
                root_uid: r.module.uid,
                ...(r.module.repository !== undefined ? { repository: r.module.repository } : {}),
            })),
            compiled_at: compiledAt,
            stats: {
                tree_count: roots.length,
                module_count: files.length,
                leaf_count: leafCount,
                api_count: apiCount,
                dep_count: depCount,
                cross_tree_dep_count: crossTreeDepCount,
                max_depth: maxDepth,
                layout_count: v.layouts.size,
                planned_count: plannedCount,
                deprecated_count: deprecatedCount,
                policy_rule_count: v.policy === null ? 0 : v.policy.rules.length,
                change_count: v.changes.length,
                open_change_count: v.changes.filter(c => c.status === 'proposed' || c.status === 'in_progress').length,
            },
        },
        modules,
        api_index: Object.fromEntries(Object.entries(apiIndex).sort(([a], [b]) => a.localeCompare(b))),
        edges,
        layouts,
        policy: v.policy,
        changes: v.changes.map(c => ({ id: c.id, status: c.status, title: c.title, updated_at: c.updated_at })),
    };
    try {
        const treeText = JSON.stringify(treeJson, null, 2) + '\n';
        const outline = outlineText(slug, v);
        const apiIndexText = JSON.stringify(Object.fromEntries(Object.entries(apiIndex).sort(([a], [b]) => a.localeCompare(b))), null, 2) + '\n';
        await writeFileAtomic(join(projectDir, 'tree.json'), treeText);
        await writeFileAtomic(join(projectDir, 'outline.md'), outline);
        await writeFileAtomic(join(projectDir, 'api-index.json'), apiIndexText);
        // structure-manifest.json（结构 SBOM）：模块/API/依赖的确定性清单 + 其它产物的哈希，供 CI/审计消费。
        const manifestModules = files.map(f => {
            const m = f.module;
            const apis = (m.apis ?? []).map(a => apiKey(a)).sort();
            const deps = (m.deps ?? []).map(d => ({ kind: d.kind, to: d.to, from_api: d.from_api ?? null, to_api: d.to_api ?? null })).sort((a, b) => (a.to + '\0' + a.kind).localeCompare(b.to + '\0' + b.kind));
            return {
                id: m.id,
                uid: m.uid,
                parent: m.parent,
                state: m.state ?? 'active',
                fingerprint: m.fingerprint,
                source: m.source.map(s => ({ path: s.path, ...(s.line !== undefined ? { line: s.line } : {}), ...(s.end_line !== undefined ? { end_line: s.end_line } : {}) })),
                apis,
                deps,
            };
        }).sort((a, b) => a.id.localeCompare(b.id));
        const sourcePaths = new Set<string>();
        for (const f of files)
            for (const s of f.module.source)
                sourcePaths.add(s.path);
        const treeStats = treeJson.project.stats;
        const structureManifest = {
            schema_version: 1,
            kind: 'normify-structure-manifest',
            generator: { name: 'normify', version: opts.generatorVersion ?? '0' },
            project: slug,
            compiled_at: compiledAt,
            trees: roots.map(r => ({
                tree_id: r.module.id,
                root_uid: r.module.uid,
                revision: r.module.revision,
                ...(r.module.repository !== undefined ? { repository: r.module.repository } : {}),
            })),
            stats: {
                ...treeStats,
                source_file_count: sourcePaths.size,
            },
            modules: manifestModules,
            hashes: {
                'tree.json': sha256Text(treeText),
                'outline.md': sha256Text(outline),
                'api-index.json': sha256Text(apiIndexText),
            },
        };
        const manifestText = JSON.stringify(structureManifest, null, 2) + '\n';
        await writeFileAtomic(join(projectDir, 'structure-manifest.json'), manifestText);
        const manifestSha256 = sha256Text(manifestText);
        const warningSummary: Record<string, number> = {};
        for (const w of v.warnings)
            warningSummary[w.code] = (warningSummary[w.code] ?? 0) + 1;
        // receipt 只记录其它产物的哈希；自身哈希写 receipt.sha256 sidecar。
        // 把文件自身哈希写进自身在逻辑上不可能成立（P0-03 / issue #2）。
        const artifacts: Record<string, { sha256: string; bytes: number }> = {
            'tree.json': { sha256: sha256Text(treeText), bytes: Buffer.byteLength(treeText, 'utf8') },
            'outline.md': { sha256: sha256Text(outline), bytes: Buffer.byteLength(outline, 'utf8') },
            'api-index.json': { sha256: sha256Text(apiIndexText), bytes: Buffer.byteLength(apiIndexText, 'utf8') },
            'structure-manifest.json': { sha256: manifestSha256, bytes: Buffer.byteLength(manifestText, 'utf8') },
        };
        const receipt = {
            schema_version: 1,
            ok: true,
            project: slug,
            compiled_at: compiledAt,
            stats: treeJson.project && typeof treeJson.project === 'object'
                ? treeJson.project.stats
                : {},
            warnings: warningSummary,
            artifacts,
        };
        const receiptText = JSON.stringify(receipt, null, 2) + '\n';
        await writeFileAtomic(join(projectDir, 'receipt.json'), receiptText);
        const receiptSha256 = sha256Text(receiptText);
        await writeFileAtomic(join(projectDir, 'receipt.sha256'), receiptSha256 + '\n');
        return { ok: true, receipt, receiptSha256, manifestSha256, errors: [], warnings: v.warnings, validate: v };
    }
    catch (error) {
        return {
            ok: false,
            receipt: null,
            receiptSha256: null,
            manifestSha256: null,
            errors: [diag('error', 'build/write-failed', '编译产物写入失败：' + String(error), {}, {}, [])],
            warnings: v.warnings,
            validate: v,
        };
    }
}

export interface VerifyArtifactRow {
    file: string;
    recorded: string;
    actual: string | null;
    ok: boolean;
    bytes: number | null;
}
/** 校验回执与产物：receipt.sha256 → receipt → 各产物哈希（L3 冻结的可自证闭环）。 */
export async function verifyArtifacts(projectDir: string): Promise<{
    ok: boolean;
    receiptSha256: string | null;
    actualReceiptSha256: string | null;
    artifacts: VerifyArtifactRow[];
    errors: Diagnostic[];
    warnings: Diagnostic[];
}> {
    const errors: Diagnostic[] = [];
    const warnings: Diagnostic[] = [];
    const receiptPath = join(projectDir, 'receipt.json');
    let receiptText: string;
    try {
        receiptText = await readFile(receiptPath, 'utf8');
    }
    catch {
        return { ok: false, receiptSha256: null, actualReceiptSha256: null, artifacts: [], errors: [diag('error', 'verify/no-receipt', '缺少 receipt.json（先运行 normify_build）', {}, {}, ['运行 normify_build'])], warnings };
    }
    const actualReceiptSha256 = sha256Text(receiptText);
    let recordedReceiptSha: string | null = null;
    try {
        recordedReceiptSha = (await readFile(join(projectDir, 'receipt.sha256'), 'utf8')).trim();
    }
    catch {
        errors.push(diag('error', 'verify/sidecar-missing', '缺少 receipt.sha256（无法自证回执）', {}, {}, ['重新运行 normify_build']));
    }
    if (recordedReceiptSha !== null && recordedReceiptSha !== actualReceiptSha256) {
        errors.push(diag('error', 'verify/sidecar-mismatch', 'receipt.sha256 与 receipt.json 实际字节不一致（回执被改动或产物不完整）', {}, { recorded: recordedReceiptSha, actual: actualReceiptSha256 }, ['重新运行 normify_build']));
    }
    let receipt: Record<string, unknown>;
    try {
        receipt = JSON.parse(receiptText) as Record<string, unknown>;
    }
    catch {
        return { ok: false, receiptSha256: recordedReceiptSha, actualReceiptSha256, artifacts: [], errors: [...errors, diag('error', 'verify/receipt-parse', 'receipt.json 不是合法 JSON', {}, {}, ['重新运行 normify_build'])], warnings };
    }
    const artifacts = (receipt.artifacts ?? {}) as Record<string, { sha256?: unknown; bytes?: unknown }>;
    const rows: VerifyArtifactRow[] = [];
    for (const [file, record] of Object.entries(artifacts).sort(([a], [b]) => a.localeCompare(b))) {
        const recorded = typeof record?.sha256 === 'string' ? record.sha256 : '';
        const recordedBytes = typeof record?.bytes === 'number' ? record.bytes : null;
        let actual: string | null = null;
        let bytes: number | null = null;
        try {
            const text = await readFile(join(projectDir, file), 'utf8');
            actual = sha256Text(text);
            bytes = Buffer.byteLength(text, 'utf8');
        }
        catch {
            errors.push(diag('error', 'verify/artifact-missing', '回执中登记的产物不存在：' + file, { file }, { recorded }, ['重新运行 normify_build']));
        }
        const okRow = actual !== null && actual === recorded && (recordedBytes === null || recordedBytes === bytes);
        if (actual !== null && !okRow) {
            errors.push(diag('error', 'verify/hash-mismatch', '产物哈希与回执不一致：' + file, { file }, { recorded, actual, recorded_bytes: recordedBytes, actual_bytes: bytes }, ['产物被改动；确认变更后重新运行 normify_build']));
        }
        rows.push({ file, recorded, actual, ok: okRow, bytes });
    }
    if (rows.length === 0) {
        errors.push(diag('error', 'verify/empty-receipt', 'receipt.json 未登记任何产物', {}, {}, ['重新运行 normify_build']));
    }
    for (const warn of (Array.isArray(receipt.warnings) ? [] : Object.keys((receipt.warnings ?? {}) as Record<string, unknown>)))
        warnings.push(diag('warning', 'verify/prior-warning', '编译时存在 warning：' + warn, {}, {}, []));
    return { ok: errors.length === 0, receiptSha256: recordedReceiptSha, actualReceiptSha256, artifacts: rows, errors, warnings };
}
