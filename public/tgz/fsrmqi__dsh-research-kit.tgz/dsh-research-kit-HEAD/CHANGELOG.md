# 变更日志

本项目的所有重要变更记录在此文件中。

格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，版本号遵循 [Semantic Versioning](https://semver.org/lang/zh-CN/)。

> 当前版本 `0.3.13`，**尚未发布到 npm**。安装方式见 [README](README.md)。

## [0.3.13]

### 改进

- **全项目苹果级状态变化动效精修（统一语言、有来有去、跟手可打断）**：
  - **统一曲线与四档节奏**：收敛全站动效语言至单一真源（`--rk-ease-out`、`--rk-ease-spring` 克制微弹、`--rk-ease-in` 干脆退场，配 `90ms / 140ms / 210ms / 280ms` 四档时长），清除首页任务卡与悬浮沉淀钮中残留的零散 `.16s ease` 与内联 hover 脚本。
  - **出现与消失完整闭环**：`ToastHost` 补齐 155ms 平滑退场动画（`rk-toast-leave`）与勾选微弹（`rk-check-pop`），不破坏 `dismissToast` 同步契约；`Modal` 遮罩新增轻柔景深模糊（`backdrop-filter: blur(4px)`）；输入框科研建议浮条、消息沉淀浮层与悬浮沉淀状态条均补齐方向性进场动效（并修正消息提示条暗色模式硬编码白底）。
  - **证据星图可打断镜头缓动**：点击「放大 / 缩小 / 复位 / 迷你地图跳转」时通过 `requestAnimationFrame` 按 220ms 减速曲线平滑推拉 `viewBox`；拖拽或连续缩放瞬间中断上一段动画并从当前帧无缝接续；节点悬停增柔和抬升与描边过渡，聚焦光晕改用当前语义色 `--rk-teal`。
  - **高频切换、展开与微触感**：科研工具切换左侧资源时右侧详情主体平滑轻切（160ms `rk-content-swap`）；首页任务卡悬停时箭头轻滑 `3px`，刷新图标点击后旋转 360° 确认；输入框选择行（`.rk-picker-row`）与 Tab 按钮补齐按压回弹；原生 `<details>` 与全站表单/对比/证据关系/提示词预览抽屉统一 `rk-reveal` 展开；全页面与提示栏启用 `tabular-nums` 消除计数跳动；同步将主控制台顶栏按钮文案修正为「时空囊」。所有新增动效与镜头插值均完整尊重 `prefers-reduced-motion: reduce`。

## [0.3.12]

### 改进

- **「时空囊」统一全站备份与恢复**：将分散在顶栏、灵感资产、证据库与图谱的 4 套导出/恢复入口合并为顶栏唯一「时空囊」；恢复时自动识别整包、证据库、灵感资产、知识星图四类 JSON 格式，点击恢复自动先留本端快照。
- **「证据星图」空态减负与可撤回清空**：升级「证据图谱」为「证据星图」；0 节点空态自动隐藏全部顶栏操作按钮；撤除重复的知识导出/恢复与对话沉淀入口；「清空临时记录」新增「取消」按钮与 4 秒自动复位，不再误按无法收回。
- **「论断审阅」首屏直见列表与智能默认**：将顶部 3 张重型卡片收敛为一行轻量工具条 + 可折叠「添加论断」抽屉，待核验为 0 时隐藏 Agent 审阅按钮；提取候选与 BibTeX/RIS 引用预览改为默认勾选；记住的「评估人」自动折叠为单行签名；审阅保存支持 Toast 一键撤销；全站用户可见文案统一去英文 `Claim` 为「论断」。
- **「科研梦境」「灵感资产」「证据库」减负与反馈统一**：科研梦境将三模式选择收入「偏好 ▾」；证据库撤除重复的只读论断列表卡并将科研账本折叠为单行摘要；灵感资产移除异常项目搜索下拉，卡片底部操作行收敛为 ≤4 项常用动作 +「更多 ⋯」（隔离删除）；取消切换资料库子 Tab 时的强制跳顶；全站统一走 Toast 即时反馈并消除页内 Notice 重复渲染，空闲首页隐藏材料引用输入框。

## [0.3.11]

### 修复

- **修复 Agent 批量初判误报「继续未完成」**：`src/lib/evidence-agent-runner.js` 的 `remainingIds` 原先按全部条目初始化，未勾选「包含人工处理过的」时被跳过的人工条目会留在未完成集合中，导致执行成功后仍误显示「继续未完成」重试按钮；现改为仅追踪 `plan.eligible`。
- **修复浏览器回归测试槽位覆盖**：`scripts/browser-regression.cjs` 的模拟 `slots.register` 未区分 `sidebar.panellist` 与 `conversation.view`，导致侧栏图标覆盖 `registered['dsh-research-kit-console']`；现分表登记 `main` 与 `sidebar.panellist`。
- **同步兼容矩阵槽位冻结清单**：在 `test/dsh-compat-matrix.test.mjs` 的 `DECLARED_SLOT_NAMES` 与 `docs/COMPATIBILITY.md` 中补齐 `main` 与 `sidebar.panellist` 可选槽位声明，修复 `npm test` 矩阵断言失败。
- **修复证据库与梦境批量初判状态残留**：证据库移除残留死状态 `includeHuman` 与重复的 `store.getMany` 副作用，所选条目全为人工处理时禁用「AI 初判」并提示前往「科研梦境 → 批量初判」；切换课题时清理证据库 `retryIds` 与梦境 `batchRetryIds`/`batchStats`，并在无活跃会话时补充按钮禁用说明。

## [0.3.10]

### 新增

- **左侧边栏全局「科研工作台」入口**：通过宿主可选槽位 `sidebar.panellist`（`order: 25`，配自绘烧瓶轮廓图标）与 `main`（key `dsh-research-kit-console`）注册全局工作台入口，点击即可在主区独立打开完整科研工作台，无需先进入具体会话；自动跟随当前活跃会话以支持梦境与批量初判模型调用，旧版无侧栏面板槽的宿主静默降级。

## [0.3.9]

### 改进

- **证据库进一步减负，Agent 批量初判收入「科研梦境」子功能**：
  - 将「Agent 批量判断」整块从证据库顶部移入「本次研究 → 科研梦境」的「批量初判 ▾」折叠子面板，默认零占位；证据库内勾选单条或若干条时仍保留上下文「AI 初判」及进度条。
  - 将证据库顶部「数据质量提示」大卡片精简为单行轻量体检条，仅展示非零异常项，释放约 240px 首屏空间。
  - 抽离共享执行器 `src/lib/evidence-agent-runner.js` 复用批处理、取消与并发快照保护逻辑，并顺带修复证据库「核对来源」中的未定义变量错误。

## [0.3.8]

### 改进

- **全站统一动效系统（按状态变化重塑）**：
  - **统一曲线与三档节奏**：在 `src/theme.js` 建立单一真源动效令牌（`--rk-ease-out` / `--rk-ease-spring` / `--rk-dur-fast 120ms` / `--rk-dur-base 200ms` / `--rk-dur-slow 260ms`），淘汰各处零散 `ease`。
  - **分段控件滑动胶囊**：为 `Segmented` 新增实测定位的滑动背景指示器（`.rk-seg-indicator`），首次挂载无飞行、支持 `ResizeObserver` 折行自适应，全站 7 处分段切换统一拥有丝滑滑动反馈。
  - **微交互与触感**：修复开关圆点（`.rk-picker-switch-track`）瞬移并加入按压微拉伸；收藏星标激活时增加克制微弹（`rk-star-pop`）；`Input/Textarea/Select` 增加柔和焦点环过渡；`ListRow` 与按钮按下阻尼统一为 `120ms`；数字计数启用 `tabular-nums` 防抖动。
  - **空间与反馈层次**：一级分区切换加入 `4px` 轻柔淡入（`.rk-section-enter`）；折叠面板与原位预览统一从触发处自然展开（`.rk-reveal`）；`Modal` 遮罩补齐淡入；错误提示（`Notice tone="error"`）加入轻震反馈（`.rk-shake`）；全局 Toast 上移至 `bottom: 112px` 避让 DSH 底部输入框。
  - **跟手与零重排**：证据图谱画布拖拽实时切换 `grabbing` 手感并为节点/连线聚焦暗退增加平滑透明度过渡；证据库批处理进度条由 `width` 过渡改为合成层 `transform: scaleX()`；所有新增动效完整纳入 `prefers-reduced-motion: reduce` 降级。

## [0.3.7]

### 改进

- **「本次研究」首页视觉重排**：
  - 压缩重复的大标题与副标题，顶部收敛为单行轻量标题栏 + 课题胶囊 + 图标刷新钮，为首屏释放约 60px 空间。
  - 将孤立的蓝框按钮条升级为 3 列铺满的「引导式任务卡」（图标 + 标题 + 一句话说明 + 悬浮抬升），无历史运行时自动隐藏灰置「继续上次工作流」按钮。
  - 无进行中任务/证据/论断时不再平铺 3 张空状态白卡，收敛为一行轻量状态条；有数据时自动展开 3 栏进度/收件箱/产出视图。
  - 精简科研梦境 0 提案时的重复提示语，并为首页底部增加安全留白（`144px`），避免底部操作被 DSH 悬浮输入框遮挡。

## [0.3.6]

### 修复

- **输入框科研建议预览警告归位**：原位展开「预览改动」时将草稿写入失败提示渲染在预览对话容器内，避免提示脱离操作区及回归测试定位超时。
- **证据图谱空状态跳转修正**：空状态「去查文献」按钮改为携带 `{ type: 'database' }`，直接进入「科研工具 → 查来源」而非默认落到「选流程」。
- **检索栏隐藏输入隔离**：收起「英文补充检索式」后不再将隐藏输入框的旧内容静默拼入 `OR` 检索式，并同步空输入提示语。
- **工作台表单撤销防串稿**：清空表单后的 6.5 秒撤销窗口内若用户已切换到其他工作流，点击「撤销」将不再覆盖新工作流表单。

## [0.3.5]

### 改进

- **交互减负、智能默认值与低噪音排版（P1 + P2）**：
  - **工作台与检索减负**：数据库查询面板收敛为单一「检索词」输入（支持中/英文），按需展开「+ 英文补充检索式」；工作流「提示词预览」默认折叠，可一键展开或编辑；输入框「选流程」顶部新增「常用」快捷芯片（取自收藏与使用历史），「预览改动」改为原位展开，不再弹出全屏模态框打断对话。
  - **科研梦境零配置化**：移除常驻技术勾选框（自动优先使用宿主模型并在不可用时静默回退本地规则，自动做梦开关收进「偏好 ▾」）；合并双按钮为单一「开始一次梦境」；用通俗中文替换内部术语（重点提炼、待归档笔记、较早记录）。
  - **论断审阅与迁移流程一步到位**：评估人自动记忆到 `localStorage`；「从最近回答开始」合并读取与自动提取为一步操作；「备份与恢复」支持一键「自动备份并增量恢复」，不再强制用户手动分两步点击；灵感资产与证据库备份恢复均支持直接选择 `.json` 文件（手动粘贴收进折叠区）。
  - **资料库卡片与表单降噪**：新建灵感资产表单折叠 8 项次要属性，卡片合并重复的「认识状态 / 验证状态」徽章；证据库支持一键「标记已核验」，4 维人工细评默认折叠为单行摘要，研究方向改用点击芯片选择。
  - **空状态引导与导语精简**：为灵感资产、证据库、论断审阅与证据图谱的空状态补充一步直达操作按钮（如「去查文献」「新建第一条灵感」「从最近回答提取」），精简证据图谱导语。

## [0.3.4]

### 改进

- **体验减负与防误触（P0）**：
  - **拉平一级导航**：工作台顶部主导航收敛为平等四分区（`本次研究 / 科研工具 / 资料库 / 证据图谱`），消除切入资料库或图谱后仍高亮「本次研究」的状态错位。
  - **证据库减负与危险操作隔离**：未勾选条目时隐藏 5 个灰置批量按钮，勾选后平滑浮出上下文批量操作条（`.rk-selection-bar`）；低频导入导出与课题维护动作收进「导入导出 ▾ / 课题管理 ▾」折叠区；「清空本课题 / 清空全部」移入红色危险区并要求输入目标名称确认；数据质量提示仅在存在异常项时出现。
  - **全局轻提示（Toast）与一键撤销**：新增 `src/lib/toast.js` 与 `ToastHost`，操作结果不再藏在长列表底部；为工作台「清空表单」和科研梦境「忽略 / 采纳提案」提供即时撤销，梦境历史区支持一键「恢复待审」；资产库与证据库的两段式删除确认在 4 秒无操作后自动复位。
  - **统一全站术语与修复过期引导文案**：统一「课题」「论断审阅」「插入对话 / 发送到对话」口径，修复证据库、工作流表单与伴生钮中 3 处旧分区/旧入口引导文案。

## [0.3.3]

### 新增

- **科研梦境（高信号压缩）**：项目首页新增「科研梦境」面板，支持在**巩固梦**（重复证据、正反立场冲突、未关联论断建议与积压待核验）、**联想梦**（新证据呼应旧缺口、跨文献弱连接与待核验假说方向）与**完整梦**三种模式之间切换；每次将积累的证据、论断与知识节点压缩为最值得立即看的 Top 5 提案。知识节点和关系按当前课题精确隔离，默认课题不会带上其他课题。已采纳或忽略的提案按签名去重，未处理提案留在统一收件箱。完整梦合并本地规则与宿主模型结果，并保留重复证据和正反冲突。绝不静默改写已有证据或论断；联想类提案显式标注「梦境推论 · 待核验」；任一声明的引用无效则整条拒绝。提案可跳到对应 Claim 审阅、证据勾选或图谱节点。课题持续变长时，每次只送入新变化和仍未核实的少量锚点，已核实记录留在主库；没有新材料且未决项没变就跳过，模型只在有新材料时调用。首页给出醒来简报（上次停在哪、待看的前 3 条）。采纳可以把联想存成待核验灵感、登记为待核验 Claim，或建立灵感与证据的互链，都不会写成已证实。自动做梦默认关闭。采纳后写入记忆卡（短摘要 + 原记录编号），多张卡可收成主题摘要；原文不删除，被盖住的编号退出后续热队列。记忆文件与 MCP `research_dream_memory` / `research_dream_memory_record` 共用，外部可读取热记忆或按 id 展开。宿主模型不可用时自动降级到本地规则引擎。测试 627 → **639 项 / 79 个测试文件**。

## [0.3.2]

### 改进

- 科研工作台的「备份与恢复」支持本地换机、重装和配置重建。旧版迁移包可从同一入口校验并增量恢复。
- 资源目录使用轻量索引，按需加载详情，并保留对工作流正文的全文搜索。工作台按领域预设推荐工作流。

### 修复

- 窄窗口中，对话增强器按可用空间定位，避免遮挡输入框或超出窗口。
- 从目录复制工作流时，过期的详情请求不会覆盖用户正在编辑的草稿。

## [0.3.0] - 2026-09-28

### 新增

- DSH `0.2.2-rc.4` 和 `rc.5` 加入兼容矩阵，移除不存在的客户端注入项。新增隔离 DSH Web 装载测试。
- 项目首页可跨会话恢复同一研究运行，继续草稿沿用原运行 ID。首页展示待审核论断、缺失来源、检查点与最近产出。
- 证据库支持导出当前项目综述审核包，包含候选及排除理由、可通过证据 ID 回查的论断审核记录，以及纳入文献的 BibTeX。
- 支持 MCP 按需加载状态，以及具备相应宿主能力时的会话项目摘要和草稿文件引用。


- 🧾 **检查点改为「事实 + 投影」，并补上并发与崩溃语义**：新增 `mcp/state/checkpoint-facts.js`，为每个 run 追加一条只增不改的事实（`seq` 自增、`prev_digest` 成链、`receipt_digest` 记录这次放行的依据摘要）；`<run_id>.json` 仍是要给 `run_status`、UI 与工具读的投影，但由事实重放得出。投影丢失或落后（进程在「事实已落盘、投影未写」之间被强杀）时按事实恢复，已放行的闸门不会丢；投影损坏、事实链断裂仍报错，不被静默当作「无待批项」。`research_run_checkpoint_approve` 新增可选 `expected_seq`（与状态里的 `seq` 不一致即返回 `CHECKPOINT_CONFLICT`，避免用旧快照覆盖别人的放行）与同内容幂等重试（不追加事实，`attempt` 按关计次，审计能看出放过几次）；`research_run_checkpoint_status` 新增可选 `explain`，返回每次初始化的放行时间线，用于回答「这次为什么停在这里」。测试 579 → **586 项 / 77 个测试文件**。
- 🚀 **工作台「在新会话开始」**：工作台第三个出口把同一份组装结果交给宿主 `uiWorkspace.startSession(undefined, { prompt, whenDraftExists: 'append' })`，由宿主预填为新会话草稿——不自动发送。草稿预填通道（`startSession` 的 `prompt` + **`conversation` 服务**的 `input.requestDraftInitialization`）自 DSH `0.2.1-rc.1` 起存在；`whenDraftExists` 语义自 `0.2.1-rc.3` 起（更早宿主按「已有草稿则保留」处理，新开的空白会话照常预填）。`0.1.7` / `0.2.0` 线没有该通道，入口整块不渲染。研究运行以 `sessionId: ''` 记录（发起会话未知，不冒充当前会话），详情见 [docs/COMPATIBILITY.md](docs/COMPATIBILITY.md) §4 与 MANUAL-QA F5。
- 📌 **会话视图的「更多会话视图」菜单改为宿主原生能力（文档登记，无插件改动）**：0.2.1-rc.3 起宿主把未固定的会话视图收进标签栏「更多会话视图」菜单。插件只需正常注册 `conversation.view`，不再需要（也不该）自己实现视图选择入口；COMPATIBILITY §4 已记录这条边界，避免以后重复造轮子。

- 🧾 **科研 Claim 台账、审阅面板、验证回执与 Context Pack**：新增 `research_claim_record|list`，以 `extracted|inferred|ambiguous|verified|rejected` 管理研究结论的认识论状态；`verified` 强制要求人工操作人、评估理由和至少一条已保存证据 ID，检索或关键词匹配不能自动升级。研究资产库新增 Claim 审阅面板，逐条确认、存疑或驳回并关联当前课题证据。`research_run_checkpoint_approve` 可追加不含正文的验证回执（证据 ID、人工摘要、操作人）；`research_context_pack` 只读、有界地投影显式 Claim、关联证据元数据和回执，要求调用者审阅后再选择注入，并保留未确认状态与警告。新增数据不保存论文全文、证据笔记或检索词。
- 🧪 **Claim 候选、Agent 初审与发布检查**：研究段落中的 DOI / PMID / arXiv 引用现在可生成带来源位置的候选，研究者勾选后才批量登记；`research_review_output` 附带候选投影。当前会话 Agent 对最多 6 条 Claim 给出独立建议与理由，写回前检查修订号，不覆盖人工状态，也不能建议 `verified`。新增 `research_claim_export`，草稿模式保留状态，发布模式阻断未人工确认或证据缺失的 Claim；导出仅包含最小证据元数据。

- 🧩 **插件详情页新增规模徽章、诊断复制与「回到会话」**：Plugins 页的 Research Kit 详情标题旁新增规模徽章，显示构建期烘焙的工作流 / 技能 / 数据源数量（徽章紧邻标题，不做运行时探测，避免先闪 0 再跳数）；头部新增「复制诊断」，把插件版本、目录规模、宿主能力探测与 UA 写入本机剪贴板，便于反馈问题——只在用户点击时执行，不上传、不含会话内容或凭据。头部另新增「回到会话」：把主区从 Plugins 页切回当前会话（`uiWorkspace.openSession`），省去「关掉 Plugins 页 → 自己点回标签页」两步。前两者只在本插件详情页渲染，宿主未提供 `plugins.detail.badge` / `plugins.detail.actions` 槽位时静默不显示。该入口走宿主公开的会话导航面（0.1.7 起即有；最初的实现误用了宿主从未提供的 `uiConversation.openView`，已在 2026-10-30 修复，见下）；通道采用软探测（不写进客户端 `inject` 列表），服务缺失时按钮整块不渲染，插件其余功能不受影响。
- 🤖 **证据库一键 Agent 批量初判**：证据库新增批量判断入口，默认跳过已人工处理条目，可勾选后重新取得当前会话模型的最新结果。请求按最多 6 条分批，支持进度与取消；模型输出严格校验条目 ID 和证据维度枚举。Agent 判断写入独立的 `agentAssessment`，保留最近 5 次历史，不覆盖人工核验状态、人工依据或状态字段；写回前做并发快照检查，期间被修改或删除的条目会跳过。该初判只发送标题、链接、标识符、来源数据库、保存原因和笔记，不读取来源全文、不等同于 DOI/全文核验，结果仍需人工确认。

### 变更

- 🧩 **适配 DSH 0.2.2-rc.3（当前 Desktop App / CLI 宿主）**：兼容矩阵新增 `dsh-v0.2.2-rc.3` 基线，共 **12 条基线 × 13 条检查**全部成立；`peerDependencies` 与 `engines.dsh` 无需改动（rc.3 仍落在 `<0.2.3-0` 内）。rc.3 线性包含 rc.2，改动集中在官方可选 bundle 与 ui 槽位新增：`sidebar.session.action`（root hoc，包裹 New-session 行内容）、`workspace.picker` Factory（root，含 `workspace.picker.directoryFlow`）与官方可选 bundle `deepseek-chat-import`；本插件不注册 sidebar/workspace 槽、不使用 chat-import，12 条宿主 seam 与平台模块表仍逐字成立，本插件用到的 toolview 三阶段、`ConvViewOwnerProps`、`InputActions.setDraft/insertText/captureInsertion`、`plugins.detail.*` / `plugins.row.config` props 形状未变。rc.1/rc.2 处理的两处适配继续生效。测试 605 → **609 项 / 78 个测试文件**（矩阵每基线 4 项）。
- 🧩 **适配 DSH 0.2.2-rc.2（2026-11-11 时的 Desktop App / CLI 宿主）**：兼容矩阵新增 `dsh-v0.2.2-rc.2` 基线，共 **11 条基线 × 13 条检查**全部成立；`peerDependencies` 与 `engines.dsh` 无需改动（rc.2 仍落在 `<0.2.3-0` 内）。rc.2 线性包含 rc.1（`merge-base` 即 rc.1 的 tag 提交），但合并了整条 master 发布列车，改动面远大于 rc.1；逐面审计后，12 条宿主 seam 与平台模块表 13/13 仍逐字成立，本插件用到的 `tool.call.toolview` 三阶段、`conversation.view`、`conversation.input.*`、`ConversationBinding.activate`、`InputActions.setDraft/insertText/captureInsertion`、`plugins.detail.*` / `plugins.row.config` props 形状均未变。rc.2 的客户端契约改动全部是新增、本插件均未使用：`hoc` 槽种与 `conversation.hero.frame` / `conversation.chat.markdown.fence` 两个包裹层、composer 文档级文件粘贴路由（`registerFileIntake`）与失败重试（`retry` / `allowEmpty`）、`insertQuote` 可选 `summary`、plugin-manager 的 Git 更新入口（`PluginTabProps.update`、`BundleInfo.update`）；Server 侧新增 agent-team、office 工具、MCP manager，`bundle-platform` 增加 `wsl` 平台准入。rc.1 上处理的两处适配（composer fixed 浮层 portal 到 body、模型路由读 `agent.model.current()`）在 rc.2 上继续生效。测试 594 → **598 项 / 77 个测试文件**（矩阵每基线 4 项）。
- 🧩 **适配 DSH 0.2.2 线（`0.2.2-rc.1`）**：`peerDependencies` 的 0.2 线上界从 `<0.2.2-0` 放宽到 `<0.2.3-0`，并新增 `engines.dsh` 声明同一范围（宿主优先读它：0.2.1 线自 rc.1 起就如此，只有 0.1.7/0.2.0 线忽略它、回落到 peer）；兼容矩阵新增 `dsh-v0.2.2-rc.1` 基线，共 **10 条基线 × 13 条检查**全部成立。版本关系：`0.2.2-rc.1` 从 `0.2.1-rc.5` 直接切出（merge-base 即 rc.5 tag 提交），线性包含，不是早先 alpha 那条分叉线。宿主 delta 审计：12 条 seam 与平台模块表逐字成立；客户端契约改动以新增为主（`InputActions.insertQuote`、`InputState.phase` 加 `'sending'`、`conversation.chat.text-interaction` / `conversation.chat.user.before` 槽、`uiConversation.interactions` 注册表、`agent.model` durable 模型选择、plugin-manager 行详情返回按钮；另有 `ChatViewInjected` / `ChatNodeOwnerProps` 删除 `fileMentions`、`readAttachment` 签名调整，两处本插件未使用），本插件用到的 toolview 三阶段、`ConvViewOwnerProps`、`InputActions.setDraft/insertText/captureInsertion` 与 `plugins.*` props 形状均未变。该线宿主 Node engines 升到 `>=24.9.0`（0.1.7～0.2.1 线是 `^22.19.0 || >=24.0.0`），插件自身 `>=22.19` 不放宽也不收紧。测试 586 → **594 项 / 77 个测试文件**（矩阵每基线 4 项、新增 2 项模型路由断言与 2 项 portal 断言）。
- 🔧 **composer 内的 fixed 浮层改 portal 到 body（0.2.2 视觉回归）**：`0.2.2-rc.1` 给 docked composer seat 加了 `will-change: transform`，seat 因此成为 fixed 后代的 containing block——挂在 `conversation.input.*` 槽里的 `position: fixed` 浮层会相对 seat 偏移并被裁（宿主文档要求 composer 内固定浮层 portal 到 body）。草稿增强的加载兜底悬浮钮（[`dsh/prompt-enhancer-glue.js`](dsh/prompt-enhancer-glue.js)）、沉淀伴生钮/状态条（[`src/composer-deposit-button.js`](src/composer-deposit-button.js)）与通用 `Modal` 弹层（[`src/ui.js`](src/ui.js)；研究者选择器弹窗就挂在 composer 槽里）改走新增的 `bodyPortal()`（[`src/lib/overlay-anchor.js`](src/lib/overlay-anchor.js)）：真实 body 上 `createPortal`，SSR 没有可挂载 body 时原样返回节点（`react-dom/server` 对 portal 会直接抛错）；内联形态与绝对定位的锚定浮层不受影响，MANUAL-QA Desktop 专项新增第 ⑥ 项。
- 🔧 **模型路由改读 0.2.2 的 durable 模型选择**：宿主 0.2.2 起把用户为下一步选定的模型记在 `agent.model`（`agent.options` 只是没记录选择时的兜底路由）。`index.js` 的会话路由缓存改为读取时优先 `agent.model.current()`，缺失或抛错再退回 `options`，因此语义增强、证据初审与 Claim 初审在用户切过模型后仍用当前选择；`0.1.7`～`0.2.1` 没有 `agent.model`，可选链让行为与之前完全一致。接线由 `PLUGIN_CONTRACTS.model-route-selection` 看守。
- 🧩 **适配 DSH 0.2.1 线（`0.2.1-rc.1` ～ `0.2.1-rc.5`）**：`peerDependencies` 的 0.2 线上界从 `<0.2.1-0` 放宽到 `<0.2.2-0`，兼容矩阵新增五条基线（共 9 条基线 × 13 条检查全部成立），其中 `0.2.1-rc.5` 是**当前 Desktop App 随附的宿主版本**（rc.4 之后的发布分支，不含 master 上的 0.2.2 线特性）。0.2.1 宿主收窄了 `tool.call.toolview` 的注入面（删除 `hookContext` / `inject`）、草稿持久化改 `DraftSnapshot` 模型、`bindDraftMirror` 更名 `bindDraftPersistence`——本插件未使用这些注入面，只有工具卡用 `typeof` 兜底读已被删除的 `useToolCallArgumentsPartial`：0.2.1 起它恒为 `undefined`，「准备中」阶段不再显示参数前缀，不崩溃、不影响装载与渲染。rc.3～rc.5 的宿主改动全是新增/外观类（导航入口定制、视图固定、埋点、模型列表、ACP/MCP 诊断输出、视图 tooltip、thinking block 渲染），其中 rc.4 的 MCP 诊断修复对本插件的 tools-only MCP server 是净收益；既有 12 条宿主 seam（槽位名、输入契约、agent 事件、会话导航、Desktop 转发）在五条新基线上逐字成立。0.2.2 线目前只有 alpha（`0.2.2-alpha.2`），且与 rc.5 在 rc.4 之后分叉、互不包含；该线出现的 Web 文件下载、附件完整引用、`session.follow(activate)`、context menu 重命名等插件 API 变化本插件均未使用（导出走浏览器侧 `<a download>`），一次性核对 12 条 seam 在 `0.2.2-alpha.2` 与 master HEAD 上同样成立——按「只收已发布 rc」的口径暂不声明基线，等其 rc 发布后再按 [COMPATIBILITY §6](docs/COMPATIBILITY.md) 增行并放宽 peer 范围。注意：随 Desktop App `0.2.1-rc.1` 分发的宿主此前会被旧 peer 范围拒绝装载，本条即修复该问题。
- 📦 **主包瘦身约 52 KB（约 6.7%），预算余量回到 9.6%**：构建器此前给每个模块正文逐行注入 4 空格缩进（约 46 KB 纯装饰），现直接按原样拼接；导出链收敛后下掉 9 个「只在本文件里用」的 `export`；客户端工具注册表改为**构建期投影**——只保留 `name` / `labelZh` / `summaryZh` / `access` / `requiresConfirmation` 五个渲染字段，`example` / `helpRoute` / `tier` / `artifactKind` / `category` 等只有服务端与文档消费的字段不再进 `ui/client.js`（新增 `mcp/tool-registry-projection.js` + `test/tool-registry-projection.test.js` 守住边界）。
- 🔗 **导出落盘只剩一份实现**：`<a download>` + Blob URL 回收集中到 `src/lib/download.js`，且改为**延迟回收**——原先 6 处各写一遍，其中两处紧接 `click()` 同步 `revokeObjectURL`，在真实浏览器里会取消下载（`test/download.test.js` 用异步回收断言 + 收敛守卫拦回）。
- 🧱 **IndexedDB 事务壳收敛到 `src/lib/idb.js`**：工厂探测、请求转 Promise、`withTransaction` / `withObjectStore` 供证据库与知识库共用；完成回调改为**先挂载再执行**业务逻辑，因此业务逻辑自己抛错时的中止不再被漏掉；`src/knowledge-store.js` 不再反向依赖证据库的 store 模块。
- 🗂 **证据库 1248 行拆成「存取层 + 界面层」**：状态订阅 / 文件同步 / 保存删除 / 互链 / 当前项目移到 `src/lib/evidence-vault-sync.js`（约 364 行），`src/research-evidence-vault.js` 只留 `EvidenceSaveForm` 与 `EvidenceVaultPane`（约 904 行）；原 18 个对外导出一个不减，消费方按符号归属改 import。工具注册表同时拆成「数据真值源 `mcp/tool-registry-data.js` / 浏览器标签 `mcp/tool-labels.js` / 门面 `mcp/tool-registry.js`」。
- 📚 **文档登记同步**：ARCHITECTURE 受控清单补登新模块并把职责表补到三层（`idb` / `evidence-vault-sync` / `download`），DEVELOPMENT 记下构建期生成物的登记方式，贡献地图与论文手册改指数据真值源，方法手册的主包体积改为实测值。

### 修复

- 🔧 **证据图谱不再把「零关系」的节点铺成卡片墙**：已保存证据只有能连到同库资源、本会话查询来源、研究论断或自动沉淀知识时才有边；只保存未关联的一批证据会形成「节点很多、关系为 0」的图，旧实现按稀疏网格把每个节点都铺成 136×54 卡片（192 个节点 = 192 张互不相连的卡片）。现新增 `splitEvidenceGraphByConnectivity()`，在布局前把有关系节点与孤立节点分开：默认只绘制有关系的内容，未关联节点按类型汇总计数，并提供「显示未关联节点」显式开关；0 条关系的范围改为说明卡（节点数、原因为何、未关联构成、临时展开入口），不再渲染空画布。导出快照与当前视图一致，缩放/平移控件只在有画布时出现。另新增「清理测试课题」动作：只列保守命名的测试/演示课题（`default` 仅在整桶条目都像调试/测试时纳入），确认后同时删除文件与本地 IndexedDB，避免只删文件被下一次同步重新导出。另把零关系时的说明卡补成按项目概览（项目 / 条数 / DOI·PMID·无标识符构成），并给出「去研究资产库查看完整证据」出口——图只回答关系，完整清单仍归证据库。测试 598 → **605 项 / 78 个测试文件**（矩阵每基线 4 项 + 测试课题识别 3 项 + 项目概览 1 项）。
- 🔧 **详情页导航按钮从「永远不出现」变成可用（修掉唯一一条功能性已知缺口）**：旧接线探测服务级 `uiConversation.openView(sessionId, view, focus?)`，而宿主从未提供该方法——真正的公开导航面是 `uiWorkspace.openSession(target)`（切回主区，同步 retain，0.1.7 起即有）+ `uiConversation.binding(source).activate(target)`（把目标视图加入会话的活跃目标集，0.1.7 起即有）。新增 [`src/lib/host-navigation.js`](src/lib/host-navigation.js) 组合它们：先从会话列表快照里取 `retainedBy.mainView > 0` 的当前会话（宿主内置客户端同样取法），`openSession` 之后再 `binding(id).activate('dsh-research-kit-console')`；顺序反了会因会话未激活抛错，测试对顺序有断言。**边界如实登记**：`activate` 只激活目标的数据源，标签选中由宿主会话 store 的 `s.view` 决定，跨页没有公开的选中入口——按钮文案因此写成「回到会话」（保证切回主区；该会话上次停在科研工作台时随之恢复），不再承诺「选中工作台标签」，详见 [docs/COMPATIBILITY.md](docs/COMPATIBILITY.md) §4。接线走 `ctx.get?.()` 软探测、不进 `inject`，服务缺失时按钮整块不渲染。矩阵随之调整：删掉永绿的可选 seam `view-navigation` 与 `cross-page-view-navigation` 缺口，新增两条**必需** seam（`workspace-session-navigation`、`conversation-view-activation`），`HOST_SEAMS` 11 → 12 条、每基线检查 12 → 13 条（九条基线全部成立）；`ABSENT_OPTIONAL_SEAMS` 冻结机制与相关用例一并移除，较新宿主能力的降级改由 `PLUGIN_CONTRACTS` 的接线契约看守。测试 580 → **579 项 / 77 个测试文件**（新增 `test/host-navigation.test.js` 7 项与渲染级入口降级断言，兼容矩阵每基线 5 → 4 项），MANUAL-QA 新增 F5、P4 改为真实跳转验收（受看守条目 43 → 44）。
- 🔧 **Agent 批量判断空响应处理**：前端不再直接对空响应调用 `Response.json()`；服务端也避免把正常响应关闭误判为客户端取消。异常时显示可读的 HTTP/模型路由提示，批处理可明确报告已完成与未处理数量。
- 🌐 **Agent 批量判断跨源预检**：批量判断路由现在接受 `OPTIONS` 预检并返回受限的 `POST` / `content-type` CORS 响应，避免插件页面与 DSH Web 服务跨源时在真正 POST 之前被 405 拦截。
- 📈 **Agent 批处理过程可见**：批量判断期间显示当前批次、已完成 / 总数、跳过、失败、进度条和最近一条写回结果，取消或失败时保留准确的处理统计。
- 🗂️ **主题分组改为多主题展开**：主列表按内容命中的全部主题归类；一条同时涉及植物、基因和测序的记录会出现在三个对应分组中，使用稳定的分组实例 key 避免重复渲染告警。平铺模式仍只显示一次。
- 引用核验不再根据关键词重合推断声明被支持或反驳；`claim_supported` 保持 `null`，命中词仅作人工核验线索。声明审计相应归入需全文核验。
- 证据自动分级仅检查来源线索：有标识符或链接返回 `ungraded`，均缺失返回 `missing`。DOI、PMID、PMCID、NCT、URL、核验状态和措辞不再被当作实证或推论等级的依据。
- 分级预览与应用跳过 `ungraded` 建议，保留已有分级；历史记录不自动迁移。补充真实模块回归，覆盖否定、中文、缺摘要、来源缺失及人工分级保护。
- 🧰 **开发回路脚本在 macOS 直接失败**：`fetch-baselines.sh` / `register.sh` / `watch.sh` / `web.sh` 里的 `$DSH_REPO：`、`$old_pid）` 这类「变量名紧跟全角字符」的写法，在 macOS 自带 bash 3.2 下会被解析成变量名的一部分，`set -u` 当场报 unbound variable——`npm run baselines:fetch` 在拉取任何基线 tag 之前就退出 1，`dev:watch` / `dev:web` 则在启动时即死；CI 的 bash 5 一直全绿，所以没人发现。现已一律改写为 `${VAR}`，并由 `test/shell-scripts.test.js` 守住（含对着本地 git 远端真跑一遍 fetch 的回归）。
- 🚦 **门禁的四处「看起来在守、其实没守」**：① 覆盖率表头解析失败（Node 换了表格式）过去只在进程同时非零退出时才失败——表头一旦改名，「实测 vs 记录值」这道防线会静默消失而脚本仍打印「通过」，现改为无条件 fail-closed，并补齐 `all files` 汇总行缺失的同类判断；② `--report` 的「覆盖率最低 8 个文件」把 0% 文件过滤掉了，最该被看到的正是它们；③ 兼容矩阵唯一一条可选 seam（`view-navigation`）在四条基线上恒为缺失，却没有任何断言——一条永远打 ○ 的 seam 会让人以为它还在看守什么，现由 `ABSENT_OPTIONAL_SEAMS` 冻结，宿主真补上 `openView` 时测试当场点名要改的清单与文档，同时把已知缺口 `cross-page-view-navigation` 的措辞从「0.1.7 线」修正为覆盖全部四条基线（**0.3.0 收尾时该可选 seam 与缺口已整体删除**：`openView` 在宿主根本不存在，见上文「详情页导航按钮」修复；矩阵现为九条基线 × 12 条必需 seam，`ABSENT_OPTIONAL_SEAMS` 机制不复存在）；④ `check-dsh-app` 在宿主 `platform.ts` 读不到时报「缺少 PLATFORM_MODULES」，把「源码来源错」误导向「宿主改了表」，现按两种情况分别点明。
- 📊 **文档里的规模数字再次与实测对齐**：测试数 474 → **489 项 / 67 个测试文件**（新增 shell 脚本守卫、预设与 overlay 同步、可选 seam 冻结、注册 key 契约），基线数 3 → **4**（README 与开发手册此前分别停在 3 / 2）；并为「N 个基线 tag」补了 `check-doc-stats` 门禁（真值取 `BASELINES.length`——此前这三处措辞各不相同，跨文档一致性检查看不见它们）。README 里预设按钮的名称同时修正为界面真实渲染的文案。
- 🧪 **预设配置补齐契约测试**：预设常量改为导出，插件行配置的注册 key（`<包名>#<patch row id>`）与 `presets/*.patch.yml` 的字段值都加了断言——两条路径此前可以各自漂移而无人察觉；CI 侧 `npm run coverage:ci` 一次跑完覆盖率与文档数字（复用同一遍套件，判定与 `check:test-count` 是同一个函数），本地新增 `npm run verify` 对齐 CI 序列。浏览器回归的假 slots 服务此前只按 `o.id` 登记，键控注册（`plugins.row.config` / `tool.call.toolview`）一律落到 `registered[undefined]`，预设 UI 在真实 DOM 里完全隐形；现已支持键控注册，并补上真实 Chromium 里的点击用例（写入的 ops 与 revision、宿主拒绝时的「预设未保存」、只读禁用、未就绪不渲染）。
- 🖥️ **客户端与 Desktop App 的共用形态显式化**：Web 与 App 跑的是同一份 `ui/client.js`（App 是 Electron 外壳，页面在 `dsh-app://app/`，请求由宿主转发，默认端口 19387），因此客户端不得对「页面源是 http(s)」做任何假设——`src/database-query-panel.js` 里唯一一处以页面 origin 作 URL 基准的写法改为 `location.href`，`test/build-client.test.js` 新增两条守卫（按构建清单逐文件 + 产物核对绝对请求地址、`location.protocol/host/port` 分支、以页面 origin 作基准；以及产物内不得出现本机宿主字面量），并做变异验证确认会拦下。开发手册补了 `DSH_PROFILE=desktop` 的登记方式与「改完产物要刷新 App」，[COMPATIBILITY.md](docs/COMPATIBILITY.md) 说明三条 `desktop-*` seam 之外的客户端 seam 对两种形态同样有效，MANUAL-QA 增「Desktop 新增面专项」（行配置预设、规模徽章与复制诊断、回到会话降级、App 内数据库查询）。

- 🚧 **语法门其实只盖了 28%**：`npm run check` 里的语法检查是一条手工维护的 `node --check` 清单，59 个文件、每加一个文件都要手动补，而仓库里实际有 **208 个 `.js/.mjs`**——漏掉的 149 个正好是最不容易被测试间接解析的那些（`dsh/` 下的路由模块、`mcp/tools/` 与 `mcp/execution/` 大批文件）。实测给 `dsh/claim-review.js` 追加一处语法错误，老门禁依然全绿。现改为 `scripts/check-syntax.mjs` 遍历源码树、单进程 `vm.SourceTextModule` 编译全部文件（当前 208 个；API 缺失时 fail-closed，文件数低于下限也失败），同时删掉只盖 `mcp/tools/` 11 个文件的重复检查（`precheck`）。因此**新增源码模块不再需要登记语法清单**，只需登记 `build-client.mjs` 的 `files` 白名单，README / CONTRIBUTING / DEVELOPMENT / METHOD-WORKSHOP 的「必须登记两处」同步改为一处。
- 🧹 **删掉死代码与重复实现**：`dsh/evidence-file-store.js` 是 55 行的孤儿模块（无任何 import、不在构建清单、不在文档里），却声明了一套与真实落盘位置（`mcp/execution/evidence-store.js` 的 `$DSH_DATA/evidence`）不同的证据库契约（`$DSH_HOME/dsh-research-kit/evidence-vault.json`），留着只会让人以为有两个证据库——直接删除；`dsh/semantic-enhance.js` 的 `enhanceWithCurrentSessionModel` 已无人调用（非流式路由也直接走 `streamEnhanceWithCurrentSessionModel`），一并删除；`mcp/execution/{claim-auditor,literature-linker,openalex-fetcher}.js` 里三份**逐字相同**的 `mapWithConcurrency` 收进 `mcp/execution/concurrency.js`。`prepublishOnly` 补上 `check:dsh-app`（发布前核对宿主 seam），仍**不含** `coverage:ci`——覆盖率地板按 Node 主版本记录，换主版本即硬失败，不该拦住发布。

- 🧱 **路由层 HTTP 样板收敛（10 份 `reply` + 6 份读体）**：`dsh/` 下 10 个路由模块各抄一份 JSON 应答，其中只有 3 份带「响应已销毁/已结束就不再写」守卫、4 份设 `cache-control: no-store`；6 份读体的上限口径各写一遍（16 384 字符 / 32 KB 字符 / 4 000 字符 / 24 000 字符 / 64 KB **字节** / 1 MiB 字符），报错文案、空体语义（坏体按 `{}` 降级还是报 `invalid_json`）、超限是否断连也各不相同。现抽出 `dsh/lib/http-json.js`：`jsonReply`（统一守卫 + charset + no-store，CORS 来源走参数，默认头可被 `headers` 覆盖）与 `readJsonBody`（上限必填、字节/字符口径显式选择、文案与空体语义由调用方传入）。各路由改成一行绑定，**调用点零改动**。行为变化只有明面两类：7 个此前无守卫的路由补上守卫、4 个此前无 `no-store`/charset 的 JSON 路由补上（两者都是「别对已结束的响应再写、别把动态结果交给缓存」）。`memory-search.js` 的读体刻意保留本地实现并注明原因——它按字节累计、超限抛 `request_too_large` 让 handler 回 413、解析失败按空对象降级，是与共享契约不同的另一份契约。受控树同时补登 5 个此前漏登的 `dsh/` 模块（`config.js`、`static-artifact-route.js`、`claim-review.js`、`claim-agent-review.js`、`evidence-source-check.js`）。

- ♻️ **同概念的多份实现收敛（调用轨迹路径 / 进程内缓存 / 文件锁）**：① `calls.jsonl` 的路径此前在写入方（`mcp/execution/call-logger.js`）与读取方（`dsh/agent-activity.js`）各写一遍字面量，现下沉到 `mcp/paths.js` 的 `CALL_LOG_FILE`；两侧的**读取策略**仍然不同（写入方要覆盖轮转文件并按工具过滤，读取方按文件尾部有界读取 + 快照缓存 + 闭区间 `since`），共享的是「轨迹文件在哪」。② `database-query` / `citation-verifier` / `source-querier` 三份同形状 TTL 缓存收进 `mcp/execution/ttl-cache.js`：只有 `database-query` 命中提升（真 LRU），差异由 `lruOnHit` 显式表达，另两处保持插入顺序淘汰。③ `checkpoint-manager` / `claim-ledger` / `evidence-store` 三份文件锁收进 `mcp/execution/file-lock.js`，统一到 `checkpoint-manager` 那套 **rename 接管**——另两处原本是 `unlink`，`stat→unlink→open` 之间的窗口足够让另一个等待者插进来拿到新锁；并在接管后立刻删除改名产物，此前 `.stale-*` 会一直堆在数据目录里。`claim-ledger` 由「50 次退避尝试（≈3.8s）」改为等价的 4s 时间预算；超时、陈旧阈值、空锁宽限期与报错文案仍按调用方原值传入（`evidence-store` 2s/5s、`checkpoint-manager` 5s/10s、空锁 2s 宽限）。三处限流的 `rateLimitExceeded` **刻意不合并**（按客户端 IP vs 按数据源，属于两套策略）并加了交叉注释。新增 `test/file-lock.test.js` 与 `test/ttl-cache.test.js` 直接钉住锁的崩溃恢复语义与淘汰顺序（套件 491 → 501 项）。

- 🔒 **摘掉 9 个「只在本文件里用」的 `export`**：Node 半侧有 9 个符号带 `export` 关键字却全仓无人导入——`dsh/semantic-enhance.js` 的 `streamEnhanceWithCurrentSessionModel`（非流式路由在同文件内直接调用）、`mcp/paths.js` 的 `DATA_HOME`（同文件内供 `dataPath`/`CALL_LOG_FILE` 使用）、`scripts/lib/doc-test-count.mjs` 的 `TEST_COUNT_PATTERNS` / `MIN_PATTERNS`、`scripts/lib/dsh-compat.mjs` 的 `stagedDirOf` / `checkSeam` / `platformModulesOf` / `collectPluginSlots` / `hostDependencyNames`（都只被同文件的导出函数调用）。多余的 `export` 是假对外契约：它让「这个符号能不能改」看起来需要先查外部用法，而实际没有任何消费者。**有意保留**三个真契约：`index.js` 的 `inject`（DSH 宿主按名调用）、`dsh/standalone-glue.js` 的 `researchKitApply`（构建产物入口）、`mcp/tool-registry.js` 的 `ARTIFACT_KIND_LABELS`（在客户端构建白名单内，会进 `ui/client.js`）。判定方式：脚本解析全仓 `import` / `export … from` / 动态 `import()`，并先确认全仓没有 `import * as` 命名空间用法与桶式 `export *`（否则会漏判）。

- 🧭 **手工验收清单的「N 项」终于有门禁了（加门当轮就抓到一处真实漂移）**：`docs/MANUAL-QA.md` 每个章节都在标题里声明「本章有 N 项」，但这个数字此前完全没有看守——`TEST_COUNT_PATTERNS` 的句式清单有意不收它（它讲人工验收步骤，不是测试计数）。新增 `scripts/check-manual-qa.mjs`（判定在 `scripts/lib/manual-qa-count.mjs`，CLI 与测试共用同一函数），按章节比对「标题声明的条目数 vs 章节内实际条目数」；条目有两种写法——表格行 `| F1 | …` 与小节标题 `### F1 …`——两种都算，否则 §2 快线（F1–F4 是小节标题）会被误判成 0 项。门是 **fail-closed** 的：声明了 N 项却一条条目都识别不出来即失败（句式一漂移，门就会变成空转，正是本仓库最反复出现的那类问题）；另设「受看守章节数 ≥ 11」与「受看守条目总数 ≥ 43」两条下限，防止删章节/改标题让门悄悄失去看守对象；同章节内重复条目 ID 也会被点名。**加门的同一轮就抓到**：「自动与逐条沉淀链路」声明 9 项、实际 A1–A10 共 **10** 项，已改正。门已接进 `npm run check`；负向验证——把标题改回 9 项后 `npm run check` 退出 1 并点名「242 行的「自动与逐条沉淀链路（9 项，尚未现场执行）」声明 9 项，实际 10 项（A1 / … / A10）」。顺带修掉 `docs/ARCHITECTURE.md` 里 `check-syntax.mjs` 的「当前 208 个 .js/.mjs」：那个数字每加一个文件就腐烂一次（本轮已到 213），真正的地板在门禁自己手里（文件数下限 150），受控树改为不带数字的准确表述，并登记两条新脚本。套件 501 → 508 项 / 69 → 70 个文件。

- 🔧 **让 CI 真的能跑：`package-lock.json` 自诞生起就是残桩，CI 已连红 12 次**。GitHub Actions 的 #61–#72（最早 2026-09-24）**全部**在 `npm ci` 一步就失败，后面的 `npm run check` / 套件 / 兼容性矩阵 / 覆盖率棘轮 / 浏览器回归**全部 skipped**——也就是说这些门禁在 CI 上从未真正执行过（README 里的 CI 徽章一直是红的）。根因与本轮改动无关：提交进仓库的 lock 只有 **106 个包**，而 `package.json` 的真实依赖树需要 **680 个**（lock 的历史版本一路是 6 → 9 → 103 → 106，从来不是完整树），`npm ci` 于是直接拒绝安装：`Missing: @mixmark-io/domino@2.2.0 / pako@0.2.9 / is-wsl@3.1.1 / readdirp@5.1.1 / ms@2.0.0 / agent-base@7.1.4 from lock file`（本机用 CI 同款 Node 22.19.0 + npm 10.9.3 精确复现）。现按 `package.json` 用**官方 registry** 从零重新解析出完整 lock（`registry.npmjs.org` 695 条；旧 lock 里的 3 条 `registry.npmmirror.com` 是当时本机镜像配置留下的，已清除），根条目的依赖声明与 `package.json` 逐字一致。直接依赖版本核对：`react` / `react-dom` / `zod` / `playwright` **不变**；`^` 范围内的两个包按当前解析落位——`@modelcontextprotocol/sdk` 1.30.0 → 1.31.0（次版本）、`@deepseek-ai/schemastery` 3.18.1 范围 → 3.18.4（补丁级）。落位后的整棵树在**干净 worktree** 里按 CI 的步骤逐条跑通：`npm ci` → `npm run check` → `check:dsh-app -- --require-source` → `coverage:ci` → `test:browser` 全部通过（Node 22.19.0、508/508、lines 83.03），且 `git diff --exit-code -- ui/` 为空——三个提交产物在新依赖树下仍**字节一致**。

## [0.2.0] - 2026-09-21

### 行为变化

- 🛡 **写入类 MCP 工具默认要求人工确认**：`research_evidence_save`、`research_evidence_save_batch`、`research_run_start`、`research_run_export`、`research_evidence_link`、`research_evidence_grade_apply` 与 `research_run_checkpoint_approve` 现在默认通过 MCP form elicitation 向宿主请求确认；取消时返回 `CONFIRMATION_DECLINED`。宿主不支持 elicitation 时，可配置 `DSH_RESEARCH_KIT_CONFIRMATION_TOKEN` 并传入 `confirmation_token` 作受控回落；仅在测试或明确信任的宿主里设置 `DSH_RESEARCH_KIT_CONFIRM_WRITES=disabled` 才会跳过确认。
- 📦 **证据列表与证据盘点默认摘要输出**：`research_evidence_list` 和 `research_evidence_review` 默认返回更紧凑的摘要字段，并新增 `offset` / `limit` / `mode` / `fields` 分页与字段过滤参数。需要笔记、分级推理等完整字段时，显式传 `mode: "full"` 或选择字段；内部 API 与现有调用方的默认行为保持兼容。
- 🧾 **MCP 输出默认紧凑化，OpenAlex 引用列表按需返回**：工具结果改为紧凑 JSON；`research_metadata_openalex_fetch` 默认只返回 `referenced_works_count`，需要完整引用图时才传 `include_references: true`，避免大结果挤占宿主上下文。
- 🧭 **工具能力与本地数据目录可配置**：31 个 MCP 工具现在暴露 `readOnlyHint`、`openWorldHint` 等 annotations；证据库、日志、护照与检查点支持 `DSH_RESEARCH_KIT_HOME` 指向独立数据根目录，便于项目隔离、多实例和测试。

### 变更

- 🌐 **外部学术数据源请求更稳**：新增共享 HTTP 客户端，支持 `Retry-After`、指数退避、短时熔断、标准 User-Agent 与 Crossref `mailto`；Crossref / OpenAlex / Semantic Scholar / Europe PMC / arXiv / ClinicalTrials 支持每源 timeout、rate limit 与 API key 配置。arXiv 统一走 HTTPS。
- 🧬 **多源文献检索标识符归一化**：DOI / PMID / arXiv / OpenAlex 统一为稳定键后合并，DOI 优先；同一论文在 Crossref、OpenAlex、Semantic Scholar 等来源间不再因主键形状不同而漏合并。
- 🧠 **Memory Center 检索边界加固**：显式 `tool` 必须属于请求的 `server`；即使宿主实现不消费 `AbortSignal`，路由也会在 15 秒内硬超时返回。
- 🧮 **用量统计覆盖轮转日志**：`research_usage_stats` 与运行状态产物投影现在同时读取当前日志和轮转日志，不再因 5 MB 轮转低估近期调用。

- 🔧 **MCP 工具命名统一为 `research_` 前缀（升级注意）**：14 个工具从无前缀名改为 `research_<领域>_<动作>`，与新增工具形成一致命名空间——`verify_citation`→`research_citation_verify`、`query_source`→`research_source_query`、`save_evidence`→`research_evidence_save`、`list_evidence`→`research_evidence_list`、`grade_evidence`→`research_evidence_grade`、`link_evidence`→`research_evidence_link`、`export_passport`→`research_run_export`、`import_passport`→`research_run_import`、`generate_figure`→`research_figure_generate`、`list_figure_styles`→`research_figure_list_styles`、`checkpoint_status`→`research_run_checkpoint_status`、`approve_checkpoint`→`research_run_checkpoint_approve`、`search_workflows`→`research_catalog_search`、`compose_workflow`→`research_workflow_compose`。**本包尚未发布到 npm，因此不存在已发布版本层面的破坏性变更**；但 README 提供「GitHub 钉 commit」安装路径——若你按 9/18 之前的 commit 安装并在宿主配置、脚本或提示词里写死了旧工具名，请按上表更新。迁移说明同时收录于 [MCP Server 配置指南](docs/MCP-SETUP.md)。
- 🔗 **动线整合第一切片落地：资产-证据互链（ROADMAP §11 P5，上一轮走查定案）**：四个分区各自完整但互不相通——灵感资产与证据库的关系此前只有自动沉淀的机器链，用户**主动**把某条资产与某条证据挂在一起没有任何入口。本轮补齐最小闭环：① **数据模型**——证据库侧新增 IndexedDB link 表（`evidence-vault-store` v1 → v2，`onupgradeneeded` 按 `objectStoreNames.contains` 守卫创建，**v1 老库平滑升级不丢数据**有专项测试；不扩展 vendored asset provider 契约）；同一对端点按稳定 id 去重，重复建立返回既有记录；500 条总量保险丝；证据删除联动清链，降级内存路径行为一致。② **入口 A（主）**——灵感资产卡展开「关联证据」：候选按同项目、共同标签与**知识链种子**（knowledge-store 节点上同时带 assetId 与 evidenceIds 的配对，最强信号）推导并标注理由，**勾选确认后点「建立关联（N）」才建立，绝不自动建边**；已关联列表可逐条解除；本视图的资产删除联动解除相关 link。③ **入口 B（只读反查）**——证据条目显示「被引用于」哪些灵感资产（标题由分区③传入，资产已删时如实标注「不在当前列表」）。④ **出口**——图谱画「资产 → 支撑证据」`supports` 边，随「持久沉淀」范围收敛；端点不可见或已删除时由图谱既有的末尾边过滤自然剔除（悬空兜底）。⑤ **Non-goal 落实**——不做自动建边、不碰 `vendor/`、首版不进备份（导出完成文案如实注明）。测试 236 → **242 项**（新增 6：link 身份 / 候选推导 / v1→v2 升级 / 去重与联动清链 / 图谱出口 / 接线断言）。

- 🧭 **遗留工程项集中办结（手动沉淀入口扩展 / 左列 sticky / 宿主能力探测 / Memory 检索 / 目录对账）**：本轮五项（对应 ROADMAP §2 / §5 / §6 / §8 与上一轮小账）。
  - 🧲 **手动沉淀入口扩展到输入框**：新增 `src/composer-deposit-button.js` 伴生钮——读 vendored QuickEnhancer 触发钮的同一存储位置（`quick-action.position.v1`），停在正上方（贴顶翻正下方）、共享中轴，拖拽结束（pointerup）与窗口变化重算；点击即显式沉淀当前会话最近一条助手回答，结果以临时状态条反馈并自动消失，绝不注入输入框。与图谱页「沉淀最近回答」同一入口函数、同一去重口径。位置解算为纯函数并有单测（默认位 / 翻转边界 / 钳制 / 非法输入）。
  - 📌 **工作台左列 sticky（ROADMAP §2）**：左列列表 `position: sticky`，偏移 = 一级导航（`--rk-console-nav-h`）+ 二级吸顶带（新增 `--rk-workbench-toolbar-h`，`ResizeObserver` border-box 实测、随折行变化，不写死像素），列表以视口内 `maxHeight` 约束并内部滚动——滚到右列详情底部出口按钮时列表仍在视口内。`ui.js` Toolbar 透传 `innerRef` 供测量。
  - 🔎 **宿主能力探测落地（ROADMAP §6 部署级）**：Node half 新增 `dsh/host-capabilities.js`（`GET /dsh-research-kit/host-capabilities`）——从工具注册表解析 `mcp__<server>__<tool>` 命名得到「已连接 MCP 服务器」事实清单（排序 / 去重 / 有界截断），并报告 Web / Shell / 文件系统 / 模型路由四项装配事实；任何一步失败退化为「未知」，探测不抛错。浏览器端 `src/host-capabilities-client.js` 汇总为事实摘要（5 分钟进程缓存），在工作台数据源详情「宿主能力」行展示。**不根据资源名称推断数据库可用、不改写目录标注**（消费端由测试断言钉住）；条目级 `requires-mcp → available-in-host` 升级仍按 §6 门槛另行执行。
  - 🧠 **Memory Center 项目记忆检索落地（ROADMAP §5）**：Node half 新增 `dsh/memory-search.js`（`POST /dsh-research-kit/memory-search`）——从工具注册表探测宿主已连接的 Memory Center MCP（默认 `memory-center`，可显式指定 server/tool），按目标工具自己的 JSON Schema 合成参数；枚举 / 标识类 / 复杂结构的必填参数无法可靠合成时明确拒绝并给诊断，**绝不拿猜的参数打 MCP、绝不代打 `mcp__` 之外的原生工具**。增强器 `searchMemory` 合并「会话已选资源摘要 + Memory 结果」并带来源标签；是否注入仍由面板「项目记忆」显式开关控制（检索 → 来源预览 → 用户选择 → 组装，禁止静默注入，源码断言钉住）；未接入时如实回落、增强不报错。**归属判据定死**：有外部稳定标识符 → 证据库；项目内部决策与上下文 → Memory Center，且 Memory 结果永不写入三库。
  - 🗂 **目录工作流上游对账办结（ROADMAP §8，记账修正）**：以 k-dense-byok 本地快照对上游 326 条工作流做 id 级全量比对——非金融 285 条**缺口为 0**（仅 2 条同义改名：`write-paper` → `write-full-manuscript`、`systematic-review` → `systematic-review-protocol`）。此前「约 10 条散落缺口（-2/-3/-4/-1）」经复核为记账错误：那是分片条数与上游类目条数的差值，实际是既定跨类归置（管线类归生物信息学、单细胞方法归基因组学等），服务检索直觉、不回改。ROADMAP §8 与 `docs-internal/pending-source-migration.md` 已同步改写为对账结论。
  - 测试 219 → **236 项**（新增 17：伴生钮位置与接线 4、左列 sticky 守护 1、能力探测 5、Memory 检索 6、路由清单更新 1）。新增 Node half 模块与浏览器模块均按纪律登记 `check` / 构建清单。

- ⚡ **自动沉淀事件接线改为增量扫描 + 图谱页新增「沉淀最近回答」手动入口（上一轮小账两项办结）**：① 事件窗口是追加式的（seq 单调递增），此前每次事件通知都全量重扫整段窗口、靠 localStorage 水位线去重——长会话下每次通知都是 O(窗口全长) 的重复劳动。现改为**从尾部增量扫描**：扫描位（内存内，随会话绑定从该会话水位线起步）只收集上次扫过之后的新增段，重复入库的正确性不依赖这条优化、始终由水位线兜底；窗口被裁剪或整体重放时行为与旧实现一致（测试用「重复通知」「窗口替换」「卸载重挂」三个场景钉住）。② **手动沉淀入口**：不开自动开关也能在图谱页点「沉淀最近回答」，把当前会话最近一条助手回答显式入库（`depositLatestAssistantMessage` / `latestDepositableMessage`：与自动沉淀同一提取链路、同一「待核验」起点、同一去重口径；被中断的半截回答如实标注；重复点击按稳定 id 走合并路径、来源按「会话 + seq」去重不会翻倍）。无会话服务 / 无当前会话 / 无可沉淀回答分别给出明确提示而非静默失败。测试 213 → **219 项**（新增 6 项）。
- 🧩 **弹层与工作台的工作流记录统一（上一轮遗留办结）**：输入框弹层的「使用工作流程」与「复制 Prompt」此前只记 `recordHistory`（使用历史），而工作台同名出口还记 `evidence.recordWorkflow`（本会话工作流轨迹）——从弹层使用工作流时，图谱「本会话」范围会漏掉工作流节点。现弹层经同一个 `recordUse` 出口记两笔，与工作台口径一致（会话轨迹按 `sessionId` 隔离；`resourceIds` = 会话选择 + 建议技能）。**计划记录不在弹层代写**：阶段勾选界面只在工作台存在，弹层不静默标记用户看不到的计划状态。接线由源码断言钉住（`recordUse` 单一出口 + 写入/复制两处调用点 + 记录不得携带 Prompt 片段或参数）。

- 📚 **文档与代码一致性修复（以源码为准复核全仓库读者文档；只改文档 + `check` 两处登记）**：修正三类漂移。① **数字错误**——测试数在同一仓库里同时写着 168 / 152，实测 `npm test` 为 **173 项 / 20 个测试文件**，已按同一口径更新两份 README、`docs/README`、`ARCHITECTURE`、`DEVELOPMENT` 共 8 处；`ARCHITECTURE` 的「Agent 回退 44 个」实为 **111**（109 `requires-mcp` + 2 `reference-only`，44 是「55 个数据源」时代的残值）；`DEVELOPMENT` 基线表仍写「65 工作流 + 8 技能 + 55 数据源」与早已不存在的扁平路径 `catalog/*.json`，改为 525 项与 `catalog/{workflows,skills,resources}/`；bundle 体积陈述低估约三倍（600 KB → 实测 **2.3 MB**，含 archify 模板 756 KiB 整段注入）。② **已交付能力在文档里不存在**——`archify` 交互 viewer、「组装回放」与「研究结果解释图」此前只出现在 CHANGELOG / `MANUAL-QA`（O6）/ NOTICE，现补进两份 README 的能力一览与开发命令、`ARCHITECTURE` 的模块树（补 `catalog-category-filter.js`、`route-replay.js`、`lib/archify-adapter.js`、`vendor/archify/*`、三个脚本共 7 项）、§3.2 的「组装事实回放」链路与两条硬边界、§7 的模板注入通道与图门禁、`PRODUCT` §6 已完成、`METHOD-WORKSHOP` 的工件治理（1 件 → 3 件）、`docs/README` 的约束 ② 与配图说明。③ **描述落后于代码**——`ROADMAP §9` 写「`SCIENCE_MODE_PRESETS` 只有三个预设」，实为 **6 个**（按编号不回填纪律改为「已完成」并保留 §9）；英文 README 的预设段整段停留在合并前的三预设；`PRODUCT` 的「学科覆盖六类」改为 24 类目 / 11 个研究入口组，资源模型补上漏掉的 `available-in-plugin` 档；`CONTRIBUTING` 新增数据源第 5 步补「同步改标 `available-in-plugin`」——照原文操作会让 `npm run check` 双向契约直接失败。另补 `package.json` 的 `check` 两处 `node --check`（`src/catalog-category-filter.js`、`src/lib/archify-adapter.js`），使「新增模块登记 `files` 与 `check` 两处」这条文档纪律在仓库内真实成立。
  - 🏷 **badge 迁到实际登记站（原声明不成立，已定位真站点）**：两份 README 原有的 dsh-plugin.org badge 指向同作者的 `fsrmqi/dsh-promptkit`——本仓库在该站**未登记**（`/plugins/fsrmqi/dsh-research-kit` 实测 404；该站插件索引 16,104 条中 `dsh-research-kit` 零命中），「Listed on dsh-plugin.org」属虚假声称，一度移除。经核查本仓库实际登记在 **dshhub.org**（[`/plugins/fsrmqi/dsh-research-kit`](https://dshhub.org/plugins/fsrmqi/dsh-research-kit) 返回 200，页内标注仓库为 `fsrmqi/dsh-research-kit`、version 0.1.0、MIT），故 badge 改指向该页。该站不提供 badge 图片（`/badges/*` 探测全部 404），图片改用 shields.io 自绘并保持原视觉（左 `DSH plugin` `#3d4451` + 右 `listed` `#2ea44f`），文案不再声称 dsh-plugin.org。**后续若在 dsh-plugin.org 完成登记，可换回其官方 `badges/listed.svg`。**

- 📊 **科研路线可视化落地（新渲染链路，设计文档 `docs-internal/research-route-visualization.md`）**：① **整体引入 archify 交互 viewer**（[tt-a1i/archify](https://github.com/tt-a1i/archify) MIT：`vendor/archify/template.html` + `i18n.mjs`，SHA 锁定于 vendor-manifest.json，归属见 NOTICE）——视觉预设（classic/signal-flow/blueprint/editorial）、章节故事（≤5 幕）、语义透镜、雷达总览、彗星流光路线动画原样获得，zh-CN 原生支持；适配层 `src/lib/archify-adapter.js` 把本仓库 IR/trace 转为其 `data-*` 契约；`scripts/render-diagrams.mjs --html` 按此产出单文件交互解释图（`SRC` 事实出处/分享卡导出随 viewer 提供）， `scripts/validate-diagrams.mjs`（10 条规则码机器可读诊断 + supportedFixes，入 `npm run check` 门禁；diagram IR 契约含 source 证据链——path/sha256/anchor，结果文件变动自动标记图过期）；② 工作台**组装回放改为弹出独立 archify viewer 窗口**：`composeWorkflow` 增量返回 `trace`（既有四个返回字段与 5 个调用点零改动），弹窗逐段回放本次组装事实并与 Prompt 文本互证（测试强制每条 trace 都能在 Prompt 中定位），面板内保留紧凑版（`prefers-reduced-motion` 与「切到静态」降级）；③ 目录新增「研究结果解释图生成」工作流（可视化与图表 12 → 13）：支持会话产出与文件驱动（`--from-files` 脚手架）两条路径，综述场景分「检索逻辑/内容逻辑」两幕。**证据库 → 解释图打通**：证据库面板新增「导出解释图素材」（按当前筛选范围导出稳定标识符与核验状态，隐私边界与图谱一致），`render-diagrams --evidence` 或 IR 的 `evidence` 字段可将其并入「证据库来源」卡片——全部已核验时标题升级「已核验证据 · 证据库」，未核验条目按原状态如实标注。目录工作流 316 → **317** 条（总资源 524 → 525）。vendored 工件与归属声明见 `NOTICE`；五张文档 SVG 维持现状（用户裁定不在范围内）。
- ⚡ **新增 8 条执行型工作流（配套能力条目，可直接组装执行指令）**：把高频且会话内可执行的能力做成参数化 Prompt 模板——`rnaseq-fastq-pipeline`（FASTQ→QC→比对定量→计数矩阵，衔接既有「bulk RNA-seq 差异表达」）、`nfcore-pipeline-execution`（test profile 冒烟后正式运行）、`pathway-enrichment-execution`、`phylogenetics-execution`、`exploratory-data-audit`（EDA 与泄漏审计）、`literature-api-search`（跨公开文献 API 检索并按 PRISMA 留痕）、`citation-bibtex-build`、`research-report-docx`。每条先核验会话执行环境（不虚构已安装）、步骤化执行、防编造边界与「需人工核验」定位，`suggestedSkillIds` 关联对应的需宿主能力条目（工具链与凭据前提）。分入 bioinformatics / data-analysis / literature / paper-manuscript 四个既有分片，目录工作流 308 → **316** 条（总资源 516 → 524）。
- 🛠️ **依赖执行侧的 63 条技能以「需宿主能力」状态收录（新分片 `catalog/skills/host-capabilities.json`，按用户决定）**：bulk-rnaseq、Nextflow、Benchling/DNAnexus/LabArchives/OMERO/Opentrons 等平台集成、文献与公共数据库 API 检索、分子模拟、docx/pdf/pptx/xlsx 产出等，每条如实标注宿主前提（Bash/Python 工具链、MCP、API Key、集群算力、自托管实例）与数据外发边界，附使用前提核验清单；不携带可注入片段、不假装可用，会话具备能力时可让 Agent 参照执行。工作台详情视图为该类条目新增前提说明渲染（琥珀色提示）。目录技能 23 → **86** 条（总资源 453 → 516）；`docx/pdf/pptx/xlsx/pacsomatic` 上游为 Anthropic 专有许可，条目为原创撰写、未演绎其内容。
- 🧩 **技能批量迁入 12 条（上游动态技能仓库首次对账，pending-source-migration 台账全部办结）**：锁定 `K-Dense-AI/scientific-agent-skills`（MIT，HEAD `15e77e6`，2026-09-10）并对本地 90 个技能逐个分类——12 条纯方法论技能中文化迁入 `catalog/skills/core.json`（实验设计、假设生成、科学头脑风暴、科学批判性思维、样本量与统计功效、系统文献综述、科研图表、不确定度与单位、临床报告草案、投稿规范核验、同行评审意见、基金申请书撰写），2 条与现有条目重叠不迁（scientific-writing、statistical-analysis），63 条价值依赖执行侧/集成/MCP/本地文件，经用户确认后以「需宿主能力」状态收录（见上条），13 条不适合本插件（商业市场、屏幕监控、图像生成 API 等）；`docx/pdf/pptx/xlsx/pacsomatic` 自带 Anthropic 专有许可，均在专有许可处理。目录技能 11 → **23** 条（总资源 441 → 453）。每条保留上游方法论纪律（Fisher 三原则、PRISMA、GUM、GRADE、CARE/CONSORT 等），执行型副作用全部改为用户显式触发；临床条目保留「仅研究、不得诊断、需资质复核」边界；`literature-review` 与既有工作流撞名，改名 `systematic-literature-review`。
- 🧬 **工作流批量迁入 102 条（8 个预留流程族填满）**：对账上游 326 条工作流后，把与预留分片对应的 neuro / ecology / physics / social / math / ml / engineering / astro 八类条目中文化迁入 `catalog/workflows/`，目录工作流 206 → **308** 条、类目 16 → 24 个（总资源 339 → 441）。每条保留上游占位符契约、按目录风格重写中文 Prompt（内置防编造边界与「需人工核验」定位）、`requiresFiles` 与建议技能/数据源对齐本目录（含上一批迁入的 NASA ADS、Copernicus CDS、Materials Project、Particle Data Group 等）。8 个分片此前已在 `index.js` 登记为空分片，本次迁入即自然并入聚合，未改任何入口。
- 🗄 **数据源批量迁入 40 条（pending-source-migration 台账清零）**：按迁移台账把 K-Dense 上游非金融科研数据源全部迁入 `catalog/resources/general-science.json`，目录规模 82 → **122** 个数据源（总资源 299 → 339）。覆盖天文与空间（NASA ADS / Earthdata / INSPIRE-HEP / Launch Library 2 等 7 条）、化学与材料（Materials Project / ChemSpider / NIST WebBook 等 6 条）、地球气候环境（NOAA CDO / Copernicus CDS / EPA AQS / Sentinel Hub 等 16 条）、地理空间（US Census / OpenCage / ArcGIS REST 等 5 条）与生物多样性、粒子物理、地质样品等 6 条；每条均按迁入门槛完成中文化改写，如实标注访问前提（API Key / 注册 / 订阅 / 许可），未验证直查能力前一律标 `requires-mcp`（仅 GADM 纯下载类标 `reference-only`）。
  - **研究入口分组同步扩充**：新增「材料与物理科学」入口组（Materials Project / MPDS / AFLOW / Particle Data Group），其余 35 条分别归入天文与空间科学、气候/地球/环境、地理空间与社会数据、生物多样性与生态、化学/药物/毒理五个既有入口组；仅 open-food-facts 走「其他研究数据源」兜底组。
  - 台账本身经上游 229 条 id + URL 双重比对核验：原记录「42 条待迁」实为计数失误——41 条清单中有 1 条（`openstreetmap`）早已改名 `openstreetmap-overpass` 迁入，真实待迁为 40 条；台账已标注完结并保留溯源信息。
- 🗂 **目录数据模块化拆分（docs-internal/catalog-modularization-plan.md 全量落地）**：单文件目录按「流程族 / 稳定用途」拆为三个分片目录并各设唯一聚合入口——`catalog/workflows/`（206 条工作流按 16 个类目分片，另预留 ecology / neuroscience / physics / astronomy / social-science / mathematics / machine-learning / engineering 八个空分片）、`catalog/skills/`（11 条按 core / crop-breeding / bioinformatics 分片）、`catalog/resources/`（82 个数据源按 crop-breeding / literature / genomics / omics / general-science 分片，`database-metadata.json` 分组元数据随 resources 入口导出）。大批量迁入从此是独立、可审阅的分片变更，不再挤同一个 JSON 文件。
  - **对外 API 与构建产物语义不变**：`src/catalog.js` 只 import 三个 `index.js` 入口，`catalog` / `itemById()` / `searchCatalog()` / `composeWorkflow()` 等出口与调用方完全解耦；构建器从入口加载后仍整体内联进 `ui/client.js`，浏览器端零动态请求。根 `index.js`（Node half）同步改从 resources 入口取数据源清单。
  - 🔒 **「分片 ↔ 入口 ↔ 产物」三向断言**：新增 `scripts/lib/catalog-entries.mjs`（fs 直读分片 + ESM 加载入口两条独立路径），`validate-catalog.mjs` 与测试断言目录中每个 `*.json` 都被对应 `index.js` 登记、分片条目总数等于聚合数组长度且逐条一致、构建产物内联数组与聚合入口相等——分片遗漏或未登记在 `npm run check` 直接失败。新增 6 项加载与聚合测试（总 149 项）。
  - **拆分零语义变更**：逐条 JSON 全等校验通过；工作流各分类组序与组内顺序与原文件一致，聚合后仅跨类目的扁平交错顺序收敛为按分类聚集（收藏 / 历史 / ID 寻址 / 检索行为不受影响）。技能与数据源的分组展示顺序有两处预期内微调（研究设计组位次、临床与公共卫生组位次），「其他研究数据源」兜底组内顺序随分片重排。
  - 🧪 **顺带修复两个既有测试失败**（今日早前数据提交未跑测试遗留，非拆分引入）：「工作流 Prompt 含防编造边界」对齐 `validate-catalog-lib` 的 GUARD 契约（prompt 或 limitations 任一携带即可，`predictive-model` 的边界写在 limitations）；「每个数据库均归入一个研究入口」把设计内兜底组「其他研究数据源」纳入受控集合（农业 / 作物与生命科学等 27 个近期新增来源暂经兜底组展示，后续再定义专属研究入口）。
  - 📚 **文档与数字全面同步**：README（中/英）、CONTRIBUTING、ARCHITECTURE、ROADMAP、DEVELOPMENT、PRODUCT、MANUAL-QA、NOTICE 与两份 SVG 示意图改为分片路径与当前规模（206 / 11 / 82，共 299 项），新增工作流 / 技能 / 数据源的贡献指引改为「写入对应分片并在 index.js 登记」。

- 🗺 **研究证据图谱升级为可探索的专用 Viewer（ROADMAP §3.1）**：分区④在既有节点/边/方向锚点之上补齐关系探索能力——确定性分层布局与端口路由（纯逻辑，新增节点不让已有节点跳位，同侧多条边按端口展开）、Ctrl / ⌘ 滚轮缩放与拖拽平移（带边界钳制与视口中心锚点）、一键复位、右下角迷你地图（点击跳转、视口框联动）、聚焦 / 上游 / 下游 / 两点路径四种范围模式（BFS 邻域与无向最短路；非范围内节点降透明度而非移除，保留参照系）、节点键盘可达（`role="button"` + Enter / 空格）、`prefers-reduced-motion` 时链路流动自动停止、窄屏单列收敛（画布不再有固定最小宽度）。
  - 🔒 **隐私边界延伸到导出与分享**：复制视图链接只编码焦点、范围模式、路径两端与缩放（`encodeGraphView`），**绝不编码证据内容**——链接会被转发，标题与标识符都不该进去；导出快照（SVG / 离线 HTML）由用户显式触发，导出弹窗与导出文件正文都写明元数据范围（仅节点标题 / 来源库 / 稳定标识符 / 核验状态 / 关系，不含笔记、全文、检索词、附件或草稿）；导出物把当前主题解析为真实色值，脱离宿主 CSS 变量后不退化为黑块。
  - **图谱纯逻辑下沉**：`src/lib/evidence-graph-core.js` 新增 `layoutEvidenceGraph` / `routeEvidenceEdges` / `evidenceNeighborhood` / `findEvidencePath` / `encodeGraphView` / `decodeGraphView` / `clampGraphScale` 共 7 个纯函数，视图层只消费布局结果、不持有图算法，配 17 项纯逻辑测试（布局确定性 / 稳定性 / 分列规则、路由锚点、邻域与路径语义、缩放限幅、URL 编解码往返含「内容不进链接」）。
- 🧪 **渲染级降级测试落地（ROADMAP §1 的 R2 前置）**：新增 `test/render-smoke.test.js`——用真实 `react-dom/server` 渲染初始状态（**不引入 jsdom**，DOM 缺失面由新增的 `test/helpers/dom-stub.js` 补齐），宿主动作缺失场景从「只有代码审查与决策层测试」升级为渲染级断言：工作台降级提示存在且写入/发送按钮真的带 `disabled`（含提供 `inputActions` 的对照组）、证据库写入按钮禁用、灵感库与数据库面板完整渲染不抛错、输入框浮层关闭态不抛错；异步降级与点击路径由源码接线断言钉住（五处守卫一个不漏）。**边界如实声明**：SSR 不执行事件，「点击后是否真的不写入」仍由 `planCitationWrite` 三态决策 + 接线断言 + 真实 profile（W2/W3）共同守护；交互级覆盖需 jsdom，已登记为演进方向。
  - ⚙️ **CI 与开发环境**：`react` / `react-dom` 以 devDependencies 引入（运行时仍零依赖），`.github/workflows/ci.yml` 在 check 与 test 前增加 `npm ci`；真实 profile 的 R2 现场核对仍保留，双保险。
- 🏷 **分区③「研究灵感库」更名为「研究资产库」**：4a–4b 落地后该分区已是「灵感资产 / 证据库」双子模块结构，旧名只描述其中一个子模块——用户点开前无法预知里面还有证据库。更名同时更新分区契约的 `purpose`（两个子模块显式并列）与页导语。英文 README 沿用 "Research Vault"（本就是中性词），无需改动。
  - **为何提前于原计划**：原定「4b–4d 全部落地后整体更名」。但更名的触发条件本质是「沉淀层不再只是灵感库」，而这一点在证据库具备完整的保存、项目隔离、去重与导出导入能力后已经成立；4c–4d 是对既有条目的增强，不改变结构事实。继续沿用旧名会让界面持续误导用户，代价高于提前更名。
- 🗃 **数据源 `availability` 新增 `available-in-plugin` 一档，11 个来源如实标注**：此前 55 个数据源一律标 `requires-mcp`，而其中 11 个（PubMed、Crossref、OpenAlex、Semantic Scholar、Europe PMC、ClinicalTrials.gov、openFDA、UniProt、PubChem、GBIF、iNaturalist）实际由插件内置适配器直接查询。用户读到「需要 MCP 或 Web 能力」会以为用不了，**少报了 20% 已兑现的能力**。
  - 根因是原字段只表达「宿主能力」，缺「插件能力」这一档。新增值专指实现已兑现的直查能力，与需要宿主探测的 `available-in-host` 分开；工作台详情页的状态色与 `toolHint` 文案同步区分，`accessNote` 逐条改写（GBIF / iNaturalist 保留各自的认证与许可提示）。
  - 🔒 **升级为双向契约**：`scripts/validate-catalog-lib.mjs` 新增 `readDirectQueryIds()`，从 `dsh/database-query.js` 读出适配器清单（10 条 `DIRECT_ADAPTERS` + PubMed 的独立分支），与目录标注双向比对——有适配器却未标、或标了却无适配器，`npm run check` 直接失败。`validate-catalog.mjs` 的通过信息现在会报出直查来源数。
- ✍️ **证据库「勾选写入 Prompt」（ROADMAP §4c）状态校正：文档说未实现，代码早已实现**。勾选、引用块预览与 `写入 Prompt（N）` 按钮是随证据库一起落地的，但 `docs/ARCHITECTURE.md` 写着「视图中没有任何写入入口」、`docs/PRODUCT.md` 与 `ROADMAP.md` 把 4c 列在未完成——文档落后于代码，用户会以为存进去的证据用不出去。现同步三处状态，并补上 §4c 自身验收条件里缺的那一项。
  - 🔒 **「未选择不注入」提为可断言的纯逻辑**：该守卫原先只是视图 `writeSelected` 里的一次提前 `return`，纯逻辑测试无法断言「什么都没被注入」。新增 `planCitationWrite({ entries, canWrite })`，返回 `empty / unsupported / write` 三态，**视图只在 `action === 'write'` 时调用 `inputActions.setDraft()`**；同时补源码断言钉住这层调用关系——否则把守卫从视图里删掉，纯逻辑测试仍会全绿（同「目录与实现双向契约」的教训）。宿主未提供输入框操作时按钮禁用，但引用块照常显示供手工复制，降级不等于丢弃。
  - 顺带修正 `src/lib/evidence-vault-core.js` 中「4c 才会用到，此处先备好」的过时注释：该函数早已被视图调用，注释与代码冲突时以代码为准。
  - ✅ **真实 profile 验收闭环（2026-09-11）**：W1–W3 在真实 DSH Web profile 上全部通过——勾选后「写入 Prompt（N）」可用、引用块预览可读；**不勾选任何条目时按钮为禁用态、点不动**；写入后输入框出现带来源链接与核验边界的引用块全文且**未自动发送**，提示条数与实际注入条数一致。至此 §4c 的自动化层（`planCitationWrite()` 三态决策 + 视图接线契约）与现场层互为印证，`docs/MANUAL-QA.md` 的对应遗留条目随之撤销。

- 🧭 **架构文档补上 4 个工作流新增字段的语义**：`scripts/add-agent-fields.mjs` 曾一次性为全部工作流补入 `input_schema` / `tool_mode` / `agent_guidance` / `checkpoints`，但这四个字段**在 ARCHITECTURE §4.2 的 schema 里从未出现**，也没进任何校验器或测试。现补入 §4.2，并写明三条容易误读的语义：`input_schema` 是 `placeholders` 的机器可读投影而非第二份真相；`tool_mode` **不改变执行方式**（插件从不执行工作流，它只是返回给宿主 Agent 的意图信号）；`agent_guidance` 与 `checkpoints` 只经 MCP 路径交付，界面路径不创建研究运行故没有检查点。同时如实标注这四个字段**目前不在目录校验范围内**，并把补校验登记为 [ROADMAP](ROADMAP.md) §12（含反向验证门槛）。

### 新增

- 📄 **新增《论文工作手册》与配套生命周期图**：[docs/PAPER-WORKFLOW.md](docs/PAPER-WORKFLOW.md) 补上此前缺失的**任务视角**入口——目录里有 36 条论文类工作流，但"我手上有一篇论文要写，从哪开始、按什么顺序走"没有一份文档回答。手册覆盖：九阶段全流程总表（每阶段该用哪条工作流、需不需要先给材料）、三条文献查询路径（插件直查的 5 个文献来源 / MCP 工具 / Agent 回退）及各自**能核验到什么程度**、一键流水线的四个入口阶段与八个人工闸门、MCP 侧从检索到审批检查点的最短调用链、以及需要显式确认的六类写操作。配图 `docs/assets/paper-lifecycle.svg` 画十阶段与八处必经闸门，两处强制完整性检查用琥珀底区分。图与文的事实全部取自 `catalog/workflows/` 与 `mcp/tool-registry.js` 实测，未凭工作流名称推测功能。
- 🧪 **文档统计门禁覆盖论文手册，并新增「工具摘要不得写死数量词」守卫**：`scripts/check-doc-stats.mjs` 新增 4 条规则（论文类工作流数 / 其中声明材料依赖的条数 / 文献研究工作流数与数据源数 / MCP 工具数），规则总数 36 → 40，新增的派生量按**类目**切分而非分片数——类目是读者在界面里筛选时看到的口径。另加一条通用守卫：`mcp/tool-registry.js` 的 `summaryZh` 中不得出现数量词，理由是注册表声明自己是纯数据模块、无法从 `catalog/` 或适配器清单派生规模（见「修复」节同一发现的漂移实例）。五项均为反向验证通过后才并入。

- 📊 **文档配图补三张，并给「图 ↔ 引用」上了门禁**：`docs/assets/` 由 5 张增至 8 张，补齐三处此前只有纯文字的入口——`mcp-tools-map.svg`（MCP 工具地图：四类宿主连同一个 stdio 服务、工具按能力域分组、只有两个能力域会改变仓库状态且调用前需显式确认；挂 [配置指南](docs/MCP-SETUP.md) 开篇）、`contributor-map.svg`（贡献落点地图：改什么 → 落到哪个目录 → 由哪条门禁看守，附两条不得手改的红线与新增代码的三处登记；挂 [贡献指南](CONTRIBUTING.md) 开篇）、`availability-ladder.svg`（数据源可用性四档标注及各自的界面行为与保证机制，含 `available-in-host` 尚未实现这一如实状态；挂 README「数据库查询」与 [PRODUCT](docs/PRODUCT.md) §2）。三张图延续配图纪律：手写 SVG、不进构建、不写会随内容增长的统计数字；除真实 Chromium 渲染核对外，本轮加了 `getBBox()` 自动断言——全部 `text` 必须落在画布内且两两不重叠，机器先过一遍再看渲染图。另新增 `scripts/check-doc-assets.mjs` 进入 `npm run check`：双向校验「每张图至少被一处读者文档引用」与「每条 `assets/*.svg` 引用都指向真实文件」，把「只加图不引用」与「删图忘改引用」这两类此前无门禁可拦的漂移变成构建期失败；门禁本身用三个场景反向验证（死资产 / 断链 / 路径写错均被拦下）。

- 🧰 **MCP Server 与 Agent 活动面板（9/18 一批提交，此前未记入本文件）**：插件同时作为 MCP Server 提供 **31 个 `research_*` 工具**，宿主 Agent 可直接调用而无需经过 UI；[配置指南](docs/MCP-SETUP.md)给出 Codex / Claude Code / Zed / DSH 四种宿主的接入方式。
  - **工具元数据单一事实源**：`mcp/tool-registry.js` 统一声明名称 / 分类 / 层级 / 访问级别 / 帮助路由，工具表与活动面板标签由此派生；配置指南的工具表改由 `scripts/sync-tool-docs.mjs` 生成并进入 `npm run check`，工具名与清单不再可能手写漂移。
  - **导航与综合入口**：新增 `research_help`（按自然语言目标推荐工具与最短调用链，本身不执行任何动作）、`research_literature_search`（多源检索、去重、可选核验）与 `research_evidence_review`（只读盘点、建议分级与可追溯性风险），把原先需要多次细粒度调用的路径收敛为默认入口。
  - **运行状态与检查点**：`research_run_start` / `research_run_status` / `research_run_checkpoint_status|approve` / `research_run_export|import`；新增 `mcp/state/run-overview.js` 聚合同一次运行的阶段、检查点、证据、最近产物与推荐下一步，Agent 活动面板据此显示运行概览、支持产物按类型筛选，并可从 MCP 调用日志自动捕获 `run_id`。
  - **写回安全与可观测**：`research_evidence_save_batch` 一次性显式保存人工挑选的候选；`research_evidence_grade_apply` **默认只预览、确认后才写回**分级；`research_usage_stats` 报出调用次数 / 失败率 / 链路中断位置（仅脱敏元数据）。
  - **参数示例随注册表提供**：每个工具带 `example` 字段，配置指南的「最短路径」按任务组织并由注册表派生——调用示例不再与实现脱节。
- 🧭 **跨分区研究上下文（ROADMAP §11 基础设施第一片）**：新增 `src/research-context-store.js`——「当前项目 + 最小研究运行」在四个分区之间保持一致；工作流写入 / 发送 / 复制时创建**不含 Prompt 与原始内容**的运行记录，并与既有证据库项目选择同步，控制台导航显示当前项目与活跃运行。工作流 Prompt 带入格式受限的 `run_id` 协作指令，MCP 证据工具与运行导出可消费该可选关联键；`run_id` 不参与证据去重，也不把「写入输入框」表述为工具已执行。
- 🕸 **证据图谱交互增强**：节点数超过 50 或边节点比过低时自动切换稀疏图网格布局；迷你地图在节点密集时以聚合色块显示分布；证据节点新增详情卡（元数据 / 笔记 / 来源 / 删除，删除带确认与错误处理）与双击查看。
- ⚡ **浏览器端性能优化**：卡片使用 `content-visibility` / `contain-intrinsic-size`，搜索走 `useDeferredValue`，派生计算包进 `useMemo`，图谱拖拽改 `requestAnimationFrame`，证据刷新防抖，项目名输入延迟提交；移除调试用 `console.log`。
- 🧰 **自动沉淀治理与健壮性补强（同轮优化）**：① **知识库备份**——`knowledge-store` 新增 `serializeKnowledgeBackup` / `parseKnowledgeBackup` / `mergeKnowledgeBackup` 与 `importBackup()`：格式带 kind/version，恢复按 key 身份增量合并（已存在跳过、不覆盖现有核验状态），端点缺失或非法条目拒收并计数；图谱页新增「导出知识 / 恢复知识」入口（与证据库备份同一交互模式）——此前知识沉淀没有脱离站点的搬运通道，清站点数据即全部丢失。② **知识记录补 `project` 字段**：沉淀时记录当前项目，已有项目的记录不被后续空项目覆盖。③ **图谱筛选**——工具栏新增「节点生命周期范围」（全部 / 本会话 / 持久沉淀）与「按项目筛选」（选项取自证据、资产、知识三处并集，默认跟随证据库当前项目）；筛选在进 `buildEvidenceGraph` 前收敛输入，关系只保留两端可见者；筛选生效但图被筛空时工具栏保留，避免用户被困在筛选里。④ **资产去重按（标题 + 项目）**——修复跨项目误跳过：同一结论在项目 B 应各自建卡，与证据库「项目隔离去重」同口径。⑤ **知识库降级可见**——IndexedDB 不可用时图谱页显示警告（只存内存、刷新即丢、建议先导出备份），不再静默伪装成已持久化。⑥ **沉淀活动反馈**——图例区显示最近一次沉淀摘要（+节点 / +关系 / 证据 / 资产 / 来源消息 seq）。⑦ **英文句式提取**——新增英文关系模式（may affect / promotes / inhibits / causes / associated with，含「in <物种>」尾巴拆研究对象关系）、英文发现与假设引导句、英文性状/物种词表与英文疑问句识别，英文句子按「句点+大写」规则切分；英文综述类回答从此也能抽出知识关系（收窄匹配：宁可漏不可错）。
- 🧠 **自动沉淀：随科研对话积累知识图谱（新链路，图谱页开关、默认关闭）**：把「回答完成 → 结构化提取 → 自动入库 → 图谱积累」整条链路补齐。① **事件接入**——`dsh/standalone-glue.js` 新增 `attachKnowledgeDeposition(ctx)`，经 `sessions.binding(sessionId).eventSource` 订阅会话事件流，`assistant/message`（一次回答完成，含 `turn/step/seq`）触发提取；按会话水位线（localStorage）只处理新消息，页面刷新导致的事件重放不会重复入库，`interrupted` 半截回答与过短寒暄跳过但水位线照常推进（开启后不回溯补提取历史）。② **结构化提取器** `src/lib/knowledge-extract.js`（纯逻辑、本地完成、零网络请求）：研究问题 / 实体（基因·蛋白·性状·物种·通路·物质）/ 发现 / 假设 / 方法 / 引用来源（DOI·PMID·PMCID·NCT·arXiv·GEO 等访问号·URL，markdown 链接标题优先，同一 DOI 的 `doi.org` 链接去重）与六种二元关系（可能影响 / 促进 / 抑制 / 导致 / 相关 / 研究对象，极性分正向·负向·不确定）；「物种+性状」复合短语自动拆分并补研究对象关系——旗舰样例「Ghd7 可能影响水稻耐盐性」即得 **基因 —可能影响(不确定)→ 性状 ←研究对象— 物种**；确定性与有界性为硬契约（同文本重复提取 deepEqual；节点 ≤24 / 关系 ≤24 / 引用 ≤8 每消息，超限截断且不产生悬挂关系）。③ **知识库** `src/knowledge-store.js`（IndexedDB `dsh-research-kit-knowledge`，nodes/claims 双 store，内存降级并显式 `isDegraded()`）：稳定 id 去重合并（节点=规范化标签哈希，关系=主语|关系|宾语|极性 四元组哈希），相同内容合并并**追加来源消息**（每条知识 ≤5 条来源、摘录 ≤200 字）；同一对实体的相反/不同方向关系**并列保留**不互相覆盖；用户推进过的核验状态绝不被自动沉淀降回。④ **三路自动入库**（全部带「自动沉淀」标签）：发现/假设/问题/方法 → 灵感资产（`thinkingKind` 映射、`epistemicStatus: to_verify`、`provenance` 记录来源消息，按标题去重不重复建卡）；引用来源 → 证据库（复用证据库同项目同标识符去重，命中即跳过绝不覆盖，状态保持「未核验」）；知识节点与关系 → 知识库并回写证据/资产关联。⑤ **图谱与追溯**——`buildEvidenceGraph` 新增 `knowledge` 输入：六类知识节点（`kn-` 前缀，detail 只含类型与核验状态）与 `message` 来源消息节点，新增 `records` / `supports` / `deposited` 与六种知识关系边；图谱页新增「自动沉淀 · 已开启/已关闭」开关（`aria-pressed`）、动态图例与**结论追溯面板**——点击知识节点展开知识关系（含方向与极性）、关联证据（含核验状态）、沉淀资产与来源消息摘录（会话 · seq · 摘录），面板内可推进核验状态，冲突结论并列时给出计数提示。🔒 **隐私边界**：默认关闭、显式 opt-in；提取无任何新增网络请求；只存有界摘录不存整段回答；**来源摘录不进入图数据**（测试断言序列化结果不含摘录，导出快照天然脱敏）。附带修正：「清空本会话查询记录」更名「清空本会话临时记录」并改为两段式确认，按钮与提示写明其边界（只清本会话查询/工作流/计划，不触及持久化的证据、灵感资产与自动沉淀知识）；`evidence-vault-store` 的 `indexedDbFactory`/`requestToPromise` 导出复用（构建器把模块拼进同一作用域，导出而非复制以避开顶层重名断言）。新增 `src/lib/knowledge-extract.js`、`src/knowledge-store.js`、`src/knowledge-deposition.js` 三个模块（`files`/`check`/架构文档受控树三处同步登记），测试 173 → **213** 项（20 → **23** 个测试文件：提取器 10 项、知识库 7 项、编排 6 项，另补图谱知识接入与摘录脱敏断言）；文档测试计数同步更新两份 README、ARCHITECTURE、DEVELOPMENT、docs/README 共 7 处。
- 🕸 **证据图谱接入已保存证据（ROADMAP §4d）**：已保存证据成为图谱里的独立节点，节点上标注「来源库 · 稳定标识符 · 核验状态」——**不带笔记、全文或检索词**。新增两类边：按来源库名匹配同库资源节点（`saved-from`；来源库在目录中存在时，该资源节点会被补进图谱，避免「有证据节点却找不到来源库」的断链），以及按 URL 或稳定标识符匹配本会话查询来源（`saved-copy`）。图谱对证据库是**只读**接入，不写入、不修改；灵感资产的 `relatedIds` 现可直接指向证据节点（`evidence:` 前缀）。
  - 🧭 **方向性锚点（原 ROADMAP「近期」第 3 项，随本项落地）**：连线原先固定「左缘连到右缘」，逆向边（如 `workflow → resource`）会穿过节点产生穿越感。现按两端节点的实际水平位置选锚点：正向走「右缘 → 左缘」，逆向走「左缘 → 右缘」。因锚点自适应会让「箭头指向谁」不再自明，图谱导语显式标注「箭头表示关系方向」。该项已在 ROADMAP §3 标记为已完成；编号刻意不回填，避免 §4a–§4d 等既有引用失效。
  - ✅ **真实 profile 验收（2026-09-11）**：测试证据与 PubMed 资源共呈 **2 个节点 / 1 条关系**，箭头含义已由图谱说明标注；`saved-copy` 因本次会话没有同 URL / 同标识符的来源而未触发（属预期，不是缺陷）。见 [MANUAL-QA](docs/MANUAL-QA.md) 的 G1–G4。
- 📊 **`docs/assets/` 新增 5 张对外展示用架构图**（SVG 随仓库分发，README 与文档直接引用）：全局架构（宿主 / 插件 / 两条受控路由 / 外部通道）、科研闭环四分区、Prompt 组装五步链路、数据源双路径（11 直查 vs 44 回退）、三方责任边界（插件 / DSH / 研究者）。全部经真实 Chromium 渲染核验排版，无溢出与重叠；README（中英）、`docs/PRODUCT.md`、`docs/ARCHITECTURE.md` 共 8 处引用。
- 测试扩充至 143 项：新增「目录标注的插件可直查与实现里的适配器完全一致」（先锁住清单提取结果，避免一致性断言空转）、「契约校验能抓住漏标与虚标」、§4c 的 5 项守护——未选择不注入（含空数组 / `null` / 非数组 / 无参调用）、宿主不支持写入时不注入但引用块仍可复制、有选择时写入文本含来源链接与核验边界、视图确实经由 `planCitationWrite` 且 `setDraft` 受 `action === 'write'` 守卫（否则把守卫从视图删掉，纯逻辑测试仍会全绿）、选择基准必须是全部条目而非当前筛选结果——§4d 的「已保存证据按来源库与查询来源接入图谱、且不暴露笔记」守护——§3.1 的 17 项图谱纯逻辑守护（见上），以及 §1 的 6 项渲染级降级断言（见上）。


- 🗄 **研究证据库（ROADMAP §4b，持久化与项目隔离）**：条目从「能存」升级到「能管」。
  - **按项目隔离**：证据库有「当前项目」这一工作上下文，跨会话保留（存 `localStorage` 的单个键而非 IndexedDB——它同步可读，视图初始化不必等连接）。列表、导出、清空都按项目过滤；未归类条目只在「全部项目」视图出现。**去重按同项目判定，跨项目不去重**——同一篇文献在两个课题里各有各的保存原因，强行全局唯一会让「按项目隔离」名存实亡。
  - **重复交给用户裁决，不自动合并**：保存命中同项目的同标识符（DOI 大小写、URL 协议 / 尾斜杠 / `#片段` 归一化后比较）即停下，提示已有条目并给出「覆盖已有 / 仍然另存一份」两个选择。覆盖沿用原 `id` 与首次保存时间，**不让更新笔记把条目在列表里跳到最前**。
  - **删除分两级**：单条删除直接执行；按项目彻底删除与清空全部走两段式确认（宿主可能屏蔽原生弹窗，不用 `window.confirm`），文案显式写出作用范围（「确认删除「项目名」全部」/「确认删除全部项目」）。
  - **导出 / 导入可搬运、可归档**：备份带 `kind` 与 `version`，错文件与高版本备份被明确拒绝，而不是静默解析成残缺条目；导入是**增量补齐而非回滚**——已存在条目跳过，一条坏数据单独计数、不中断整份恢复，且绝不覆盖恢复之后写下的新笔记。
  - 条目核验状态可逐条推进（未核验 / 已核验 / 存疑 / 已失效），补上 4a 只有状态字段、没有流转入口的缺口。
- 测试扩充至 113 项：新增 4b 守护 14 项——去重键大小写与 URL 归一化、跨项目不判重、`findDuplicate` 排除自身、重复默认拒绝且不入库、覆盖沿用原 id 与首次保存时间、强制另存允许两份、按项目过滤与项目名去重、按项目删除不波及他项目、当前项目跨实例读回，以及**用最小 IndexedDB 桩把「跨刷新持久化」变成可断言命题**（重建 store 后数据仍在、删除同样落盘），外加备份序列化往返与版本校验、增量合并的跳过与非法计数、恢复不覆盖新笔记。
- 🗂 **研究证据库（ROADMAP §4a，最小闭环）**：公开数据源的查询结果可**逐条**点「保存到证据库」，保存前必须经用户确认的表单，禁止自动入库。条目字段为标题 / 来源数据库 / 稳定标识符 / 原始链接 / 保存时间 / 项目 / 标签 / 保存原因 / 用户笔记，核验状态默认「**未核验**」——保存不等于认可。稳定标识符从标题、链接与元数据里自动识别（DOI / PMID / PMCID / NCT / arXiv）。
  - **持久化直接建 IndexedDB 最小 schema**（`src/evidence-vault-store.js`），不先做 `localStorage` 再迁移，避免后续换引擎返工。宿主沙箱不提供 `indexedDB` 或 `open` 被拒时降级为进程内内存存储，接口保持 Promise 不变，并通过 `isDegraded()` 显式提示「刷新后会丢失」，**绝不静默伪装成已持久化**。
  - **隐私边界做成硬校验**：既无原始链接又无稳定标识符的来源直接拒绝入库（无法追溯的证据没有保存意义）；`javascript:` 等非 http(s) 协议链接被清空而非原样落库；标题 / 原因 / 笔记分别按 300 / 500 / 2000 字符裁剪，不收全文。
  - 列表与检索落在沉淀层分区新增的「证据库」子模块，与「灵感资产」并列切换——**不新增第五个并列分区**（ROADMAP §4 的产品定位是沉淀层升级为「研究资产库」，等 4b–4d 落地后整体更名）。
- 测试扩充至 99 项：新增证据库 10 项守护——标识符提取与 DOI 尾部标点剥离、字段完整性与默认未核验、不可追溯来源拒绝入库、危险协议被清空、长文本裁剪、状态分组与关键词筛选、引用块必须保留「尚未逐条核验」的责任声明、存储降级可观测、非法条目在降级路径下同样被拒（两条路径行为一致）、列表按保存时间倒序。
- 🔝 顶部改为两层吸顶，检索行不再随页面滚走：统一视图内容很长（分区①详情栏、分区③资产列表都能把页面撑到数千像素），原先只有分区导航吸顶，检索与筛选行会随页面滚出视口，128 项资源里每次筛选都要先滚回顶部。现拆成两级——一级仍为 `.rk-console-nav`（分区导航 + 说明块，`position:sticky; top:0`），二级为新增的 `.rk-sticky-toolbar`（检索框 + 类型/状态筛选），两个分区都已接入。分区封面 `PageHead`（kicker / 标题 / 导语 / 分区动作）**不吸顶**：它的定位是"封面"，标题与一级导航的当前标签重复、导语是读一次的介绍，吸住会白占约 87px 并放大重复感。
  - **偏移量实测而非写死**：二级吸顶的 `top` 取 `var(--rk-console-nav-h)`，由 `ResearchConsole` 用 `ResizeObserver` 观察一级导航并写入（挂载先写一次，卸载清理）。导航高度会随窗口变窄换行（说明块变 4–5 行）而变化，实测 1280px 宽下为 149px、780px 宽下为 180px，写死必然错位。
  - **`ResizeObserver` 必须显式观察 `box: 'border-box'`**：默认只观察 content-box，因此"内边距/边框把导航撑高而内容框不变"的变化不会触发回调，二级吸顶会停在旧位置并压进导航底下。此缺陷只在真实宿主里扰动导航高度才暴露得出来。
  - 吸顶带的垂直节奏由内边距而非外边距承接（外边距区域不绘制背景，吸顶后会露缝透出滚动内容），故 `Toolbar` 在 `sticky` 态把外边距置零、由 `.rk-sticky-toolbar` 的 `padding` 接管；二级 `z-index: 15` 低于一级 `20`，不遮挡分区切换。
  - 真实 DSH 实测（`scrollBody` 高 557px）：滚动 0 / 200 / 600 / 700 / 900px 时，二级吸顶顶边始终等于一级导航底边（225px，严丝合缝）；扰动导航高度 149 → 189 → 185 → 149px，CSS 变量与吸顶位置逐次跟随；分区③「研究灵感库」同样对齐，吸顶带背景 `rgb(244,247,249)` 与页面底色一致。

- 🎨 三视图视觉统一重构：新增统一基础组件层 `src/ui.js`（Button / Card / Panel / Field / Input / Textarea / Select / Chip / Badge / Segmented / ListRow / EmptyState / Spinner / Notice / Modal / Page / Toolbar）与图标层 `src/lib/icons.js`（ICON_PATHS 与 dsh-promptkit 逐项同源）。科研工作台、资源/工作流程浮层、研究灵感库、输入框入口与数据库查询面板全部改为复用该组件层，移除各视图内联的样式常量工厂。
- 视觉令牌与「研究方法工厂对话增强器」对齐：`src/theme.js` 的 `--rk-*` 调色板、阴影刻度、字号层级（13px 正文 / 14px 面板标题 / 27px 页面标题）、圆角（卡片 12px、控件 8px、芯片 999px）与交互反馈（`.rk-btn` 位移、`.rk-card` 悬浮抬升、统一焦点环）逐项对齐 `--pk-*`；暗色保持 `--rk-d-*` 单一真源 + 系统暗色与 DSH 暗色双路触发。
- 构建器健壮性：`scripts/build-client.mjs` 新增符号顺序断言（`ORDERED_SYMBOLS`），模块间无 import、符号依赖拼接顺序可见，文件顺序错位会在构建期报错而非运行时崩溃；新增多行 `import {}` 折叠，修复跨行 import 只删首行导致产物语法错误的问题。
- 🧭 三个并列视图合并为统一容器：原「科研工作台」「研究方法工坊」「研究灵感库」三个 `conversation.view` 标签收敛为单一视图 `dsh-research-kit-console`，内部按「发现 → 构造 → 沉淀」的科研闭环做二级分区——**资源与工作流**（原工作台：目录检索、参数化组装、公开数据源直查）、**方法工坊**（原方法工坊：方法卡库、变量填充、关系图谱）、**研究灵感库**（原灵感库：资产增删改、版本对比、验证跟进）。分区导航常驻顶部并记忆上次位置，切换时同步展示该分区的定位、核心用途与职责边界。合并只发生在导航层：三个分区组件原样复用（本仓库组件走 `embedded` 模式，vendored 方法工坊零改动），能力集合与合并前完全一致，无功能丢失。
- 分区契约单一真源 `src/lib/console-sections.js`：每个分区显式声明名称、定位、核心用途、职责边界与独占数据；`test/research-console.test.js` 守护五要素非空、边界含否定项、数据归属互斥、分区 id 与组件映射一一对应（杜绝"有导航无内容"的空分区）。
- 统一基础组件层补齐 `ListRow` 行尾操作槽：工作台资源列表改用它渲染，消除最后一处视图内联行样式。
- 测试扩充至 66 项：新增分区契约与导航映射（4 项）、会话模型路由惰性兜底（2 项）、构建产物卫生（3 项：无残留 import/export、视觉层与统一组件已拼入、三视图不再各自内联样式常量）与分区嵌入契约（1 项：守护「分区不得重复渲染页面外壳」）。
- 📋 真实 profile 手工验收清单 [`docs/MANUAL-QA.md`](docs/MANUAL-QA.md)：把验收清单收敛为「快线 4 项（F1–F4）+ 发布门槛 2 项（R1–R2）+ 观测 3 项（O1–O3）」，给出**按症状分层的失败定位树**（L1 加载 / L2 注册 / L3 契约 / L4 渲染 / L5 路由）与修复位置原则（宿主 props 变更只改 `standalone-glue.js`、vendored 工件禁改）。

- 🚀 方法工坊与草稿增强器并入本插件：按 [`docs/METHOD-WORKSHOP.md`](docs/METHOD-WORKSHOP.md) 的设计将 dsh-promptkit 的核心能力纳入本仓库，用户只需安装 dsh-research-kit 即可获得全部能力。
- 研究草稿增强器（`conversation.input.right`，`dsh-research-kit-draft-enhancer`）：输入框旁一键增强，轻量档（零 Token 结构化整理）与语义档（复用当前会话模型、SSE 流式上屏、五维诊断、可取消）；强度三档（低=润色/中=补边界/高=详述）；增强后可撤销与对比原稿。优先级低于宿主模型选择器与发送按钮，不截获普通 Enter。
- 语义增强 Node half（`dsh/semantic-enhance.js`）：`/dsh-research-kit/semantic-enhance`（非流式）与 `/stream`（SSE）两条路由统一注册进根 `index.js`（inject `['webServer', 'web', 'llm', 'sessions']`）；会话模型路由随 `agent/created`/`agent/disposed` 增删，只存 provider/model 标识，浏览器端与服务器均不持有模型 Key。研究化 system 指令强制：不编造引用/DOI/数据集/页码/临床结论、保持草稿研究范围、受限数据保密、结论标注待人工核验。
- 研究上下文桥：每次语义增强自动携带当前会话已选数据库/技能/工作流的只读摘要（请求体 `researchContext`，服务端 4000 字符上限），供改写对齐术语与范围；不授予数据源访问权，改写不得声称已查询。
- 研究灵感库完整管理视图（合并后为统一视图 `dsh-research-kit-console` 的「研究灵感库」分区；`src/research-vault.js`）：搜索、编辑、派生变体（保留来源关系）、版本对比、JSON 导出/增量恢复、收藏、验证状态跟进（待验证→已证实/已被推翻）；隐私边界：正文超 8000 字符拒绝保存，原始数据与完整查询结果不入库。
- 模型输出协议模块（`src/lib/enhance-output.js`）：`[DIAG]` 五维诊断行 + `===PROMPT===` 分隔的统一解析，Node half 与浏览器共用；支持流式尾部剥离与中英文维度别名。
- vendored 工件治理：`vendor/vendor-manifest.json` 记录工件来源 commit 与 SHA-256；`scripts/check-vendor.mjs` 在 `npm run check` 首步校验一致性；构建器在拼接时把工件内残留的 `/dsh-promptkit/` 路由改写为 `/dsh-research-kit/`，产物不出现跨插件 fetch 路径。
- 公开数据源查询预算：`/dsh-research-kit/query` 增加 5 分钟结果缓存（200 条上限，命中不重复出网）与每 IP 每分钟 12 次速率预算（超出返回 429 并提示走 Agent 查询）；Agent 回退响应继续携带可直接执行的查询任务文本。
- DSH slot 注册表单一事实源（`dsh/slot-registry.js`）：槽位的 id/order 集中定义，供 glue 与测试共用；`dsh/standalone-glue.js` 仍是唯一注册入口。当前为合并后的 **4 个槽位**（统一视图 `dsh-research-kit-console` + 左入口 + 浮层 + 右增强器；合并前为 6 个）。
- 测试扩充至 56 项：语义增强路由（SSE 帧、会话路由增删、400/405/503 路径、研究上下文约束）、输出协议解析（流式/别名/未知维度）、灵感库隐私边界与筛选、查询缓存与速率限制、slot 注册表完整性。

- 🧪 科研模式领域预设：工作台头部一键切换三个领域预设——「基因遗传」（附加 6 项技能，纪律段含 ACMG/AMP 解读规则、组学过滤留痕、关联不等于因果、跨物种外推限制）、「临床队列」（仅去标识化数据、强制“研究草案——非临床用途”标注、偏倚逐项讨论）、「通用科研」（基础纪律段）；再次点击同一预设关闭。写入/发送/复制均按预设组装。语义是「预设指导组合」而非能力开关——不会自动执行任何工具。
- 数据源目录扩充至 30 条（原 4 条）：文献研究 14 条（PubMed、Crossref、OpenAlex、Semantic Scholar、CORE、ORCID、Unpaywall、bioRxiv/medRxiv、Europe PMC、DOAJ、ERIC、Springer Nature、Scopus、arXiv）+ 生医数据分析 16 条（NCBI E-utilities、ClinicalTrials.gov、openFDA、GTEx、gnomAD、KEGG、UniProt、RCSB PDB、ChEMBL、PubChem、STRING、Reactome、PhysioNet、WHO GHO、ChEBI、Ensembl），覆盖免费可访问的科研数据源，全部中文重写并附接口地址与访问前提（机构订阅/API 密钥要求如实标注）。
- 新增「研究数据源选择」工作流：按研究问题匹配可访问数据库、生成检索词组合与优先顺序，关联全部 30 个数据源；要求声明访问限制、标注需确认项，不假设会话已能访问。
- 🧬 扩充基因组学与临床研究学科工作流：新增「基因组学」类目 22 条（bulk/single-cell RNA-seq、变异检测、GWAS、ACMG 变异解读、基因集富集、调控网络、比较基因组、宏基因组、系统发育、表达图谱、甲基化、ATAC-seq、ChIP-seq、基因组注释、RNA velocity、空间转录组、细胞类型注释、轨迹拟时序、多组学整合、免疫画像、标志物发现）与「临床研究」类目 5 条（患者队列、病例对照、纵向数据、电子病历、风险预测模型——均强制标注"研究草案——非临床用途"）。参数提示词内嵌具体研究场景示例。
- 数据源补充专业领域关键库：ClinVar、OMIM、GWAS Catalog、HGNC、GEO（数据源总数 35）。
- 工作流目录合计 65 条（原 38 条）：论文与手稿 13、文献研究 12、基因组学 22、临床研究 5、数据分析 11、研究设计 2。新增内容覆盖下列场景：投稿信、稿件翻译、补充材料、研究版图扫描、引文模式分析、公开数据集检索、研究趋势追踪、预印本快报、方法学对比、统计分析执行、Meta 分析、生存分析、回归建模、方差分析、研究计划撰写；全部中文重写，保留防编造边界与"需人工核验"定位，计算类工作流保留"有工具则实际运行、无工具则输出方案"的双路径语义。
- 资源面板学科二级筛选：输入框资源弹层按目录分类聚合数据源与技能；工作台数据源详情展示接口地址。
- 使用历史面板：成功写入/发送/复制工作流后自动记录历史（本地保存 20 条，含名称、Prompt 首行摘要与时间戳；经 `CatalogStorage.recordHistory` 存储并广播变更）；筛选栏新增「历史」分组，点历史条目直接回到对应工作流；历史记录只存 ID、名称与首行摘要，不存完整 Prompt。
- 「复制 Prompt」出口：工作台与输入框预览弹窗均可一键复制提示词，宿主动作缺失时的兜底路径；复制同样计入使用历史。
- 表单一键清空：恢复到模板初始状态，与「恢复自动生成」配合覆盖手动编辑的所有回退场景。
- 收藏与使用历史（`src/catalog-storage.js`）：列表条目一键星标收藏；筛选栏新增「★ 收藏」虚拟分组；存储经 `CatalogStorage` 接口隔离 `localStorage`，隐私模式或宿主禁用时降级为空操作。
- 输入框资源选择器反馈：资源面板底部实时显示已选资源 chip 清单，可单个移除或一键清空，并说明附加语义。
- 启动弹窗必填校验：缺失必填字段时给出字段级错误（红色边框、`aria-invalid`、逐字段说明），不写入草稿；需要材料的工作流在弹窗内展示材料添加方式与流程边界。
- 输入框快捷入口（`conversation.input.left` + `conversation.input.overlay`）：工具行「资源 / 工作流程」两个紧凑按钮，经自定义事件在输入卡片上方打开弹层选择器；工作流面板按科研场景分类筛选、选择后弹出预览确认弹窗（参数填写、Prompt 预览编辑、「使用工作流程」只写草稿不自动发送）；资源面板在全部/数据库/技能间勾选，选择仅记录于当前会话。
- 数据库附加语义：`composeWorkflow` 新增 `extraDatabaseIds`，勾选的数据库以「研究资源提示」并入 Prompt，并强制携带"未确认当前会话具备访问能力前，不得声称已检索"的边界声明。
- 槽位注册测试（`test/dsh-slots.test.js`）：直接调用注册表，断言工作台视图、输入框入口、输入浮层与草稿增强器四个槽位全部注册且返回统一释放函数；另对构建产物做包含性检查。该测试的 slots 服务是模拟对象，故只能证明「产物能注册槽位」，不能替代真实 profile 验收。
- `npm test` 现在先重建浏览器产物再运行测试，保证产物与源码同步后才断言。
- 首批科研工作流目录：22 条人工审核的工作流（论文与手稿 10、文献研究 5、研究设计 1、数据分析 6），每条含参数化 Prompt、防编造边界与"需人工核验"定位；全部中文撰写并适配 DSH `@文件` 约定。
- 可组合技能指导模块：8 项技能各带 `promptFragment` 纪律片段与 `checklist` 人工检查清单；`composeWorkflow` 支持 `extraSkillIds`，勾选后以「附加指导」并入 Prompt 末尾，未知或非技能 ID 静默忽略。
- 数据源条目 4 项（PubMed、Crossref、arXiv、OpenAlex），均保守标注 `requires-mcp`。
- 目录契约校验器（`scripts/validate-catalog.mjs`）：校验 ID 唯一性与格式、公共字段、占位符双向一致、防编造边界必含、availability 合法、关联存在性、技能模块字段；已接入 `npm run check`，CLI 与测试共用纯逻辑库。
- 科研工作台 UI：搜索（覆盖名称、描述、标签与正文）、类型筛选、参数表单、技能勾选、Prompt 预览与手动编辑（含"恢复自动生成"）、写入/发送与宿主动作降级。
- 主题基础（`src/theme.js`）：明暗双套调色板以 CSS 变量为单一真源，双路跟随系统暗色与 DSH `body[data-ds-dark-theme]`；880px 以下单列；`aria-*` 与焦点环。
- GitHub Actions CI：目录契约 + 语法检查、构建、构建可复现校验、测试。

### 修复

- 🧮 **修复工具注册表里写死的规模数字（其中一处已经漂移）**：`mcp/tool-registry.js` 的四处 `summaryZh` 把**本可派生、却无法在注册表内派生**的数量写成了字面量——「搜索 349 条工作流目录」「等 6 个数据源」「列出 8 个可用图表风格」「（支持 15 个期刊）」。注册表声明自己是「纯数据模块，无 Node 专属依赖」，因此没法像文档那样从 `catalog/` 或适配器清单实测，只能靠人记得同步；其中「8 个可用图表风格」**已经漂移**——`mcp/execution/figure-styles` 实际有 11 个（`bar_paired_delta` … `heatmap`），且该数字经 `scripts/sync-tool-docs.mjs` 流进了 [配置指南](docs/MCP-SETUP.md) 的工具表，而现有门禁只校验工具**数量**，看不见摘要内部。四处改为不含数量的措辞；规模信息没有损失——`research_catalog_search` 在调用时返回命中总数，`research_figure_list_styles` 与 `research_disclosure_list_policies` 本身就是清单入口。`scripts/check-doc-stats.mjs` 同步加一条通用守卫：`summaryZh` 出现「数字 + 个/条/种/篇/类」即失败，防止再被写回。

- 🎯 修复「勾选后再改筛选，已选条目被静默移出计数」：证据库的选择集原先从**当前筛选结果**（`filtered`）过滤，用户勾选后一旦调整检索词或核验状态筛选，被筛掉的条目就会退出 `写入 Prompt（N）` 的计数与引用块预览——选择是用户明确做出的动作，不应被视图条件变化悄悄撤销。现改为以**全部证据条目**（`entries`）为基准，筛选只影响「看见什么」，不影响「已选择什么」；项目切换仍会清空选择，故不会跨项目带入。空选择提示语相应从「请先勾选当前筛选结果中的证据条目」改为「请先勾选证据条目」，按钮、预览与写入提示继续按实际选中条数计数，并补一项接线契约测试钉住基准来源。
- 🔬 修复「分区嵌入契约」测试的假阴性：断言写作 `/researchAssetProvider,\s*embedded\s*\}/`，把正则锚在属性对象的结尾 `}` 上；`ResearchVaultHost` 多透传一个 `inputActions` 后即误报失败（缺陷实际不存在）。改为只断言 `h(ResearchVault, { … })` 的 props 里出现 `embedded`，不再耦合属性顺序与对象结尾。
- 🔁 修复已提交构建产物与源码不同步：`src/research-vault.js` 的 `ResearchVaultHost` 与 `ui/client.js` 中同一处的属性顺序不一致，CI 的「构建后可复现」校验必然失败。已重新构建并提交产物；重复构建零 diff 已实测。
- 🧯 **修复统一视图与输入框浮层整屏白屏**：`src/research-selection-store.js` 与 `src/evidence-store.js` 各定义了一个顶层 `stateFor`（返回的 state 形状不同——前者有 `ids` 字段，后者是 `queries` / `workflows`）。构建器把模块拼进同一函数作用域时，**后者的声明静默覆盖前者**：`function` 重名不报错、产物照样通过 `node --check`，只在渲染时才炸成 `TypeError: state.ids is not iterable`。受影响的不止「资源与工作流」分区——`composer-overlay` 与 `prompt-enhancer-glue` 复用同一个 store，因此工具行的「资源 / 工作流程」入口与分区切换一并白屏。修法分两步：① 两个 store 的内部函数按职责改名（`evidenceKeyFor` / `evidenceStateFor`），`formatTime` 的三份同名副本也分别改为 `formatWorkbenchTime` / `formatAssetTime` / `formatEvidenceTime`；② 在 `scripts/build-client.mjs` 新增构建期断言 `assertUniqueTopLevelSymbols`——项目模块顶层符号重名直接让 `npm run build` 失败并报出 `文件:行`，把这类「静默覆盖」从"靠人记得扫一遍"变成"不可能漏"。该断言只覆盖项目模块，vendored 工件的内部声明都在 `const PromptKit = (React => {…})` 作用域内。
- 🧩 修复两个「改了源码但没重新 build 就不会暴露」的构建期缺陷：① `src/evidence-store.js` 与 `src/research-selection-store.js` 各有一个模块级 `const sessions`，构建器把模块拼进同一作用域（strip 掉 import、符号靠拼接顺序可见），重名常量直接让产物 `SyntaxError: Identifier 'sessions' has already been declared`（前者已改名为 `evidenceSessions`，并补注释说明顶层符号必须全局唯一）；② 构建器 `strip()` 不支持 `export async function`（`^export function` 匹配不到它），残留的 `export` 关键字会让产物 `SyntaxError: Unexpected token 'export'`（已补规则，且该规则必须排在普通 `export function` 之前）。
- 🔝 三个分区的顶部操作行统一吸顶，「科研模式」「新建资产」不再随页面滚走：原先只有「资源与工作流 / 研究灵感库」两个分区的检索行吸顶，方法工坊整段随页面滚走（其 vendored 左列的 `position: sticky` 是死代码），而「科研模式」（原挂分区封面右侧）与「新建资产」（原挂封面动作区）也会滚走——实测 `科研模式` 滚 800px 后 top = −555。现统一为「**吸顶只放随时要用的操作，不放读一次就够的内容**」：一级 = 分区导航；二级 = 各分区的模式 / 检索 / 筛选 / 主操作行；分区封面只留标题、导语与低频动作（导出、恢复备份）。三个分区覆盖面一致，不再有"一个吸、两个不吸"。
  - **方法工坊的两条 vendor 解绑（都只有真实宿主才暴露）**：① 左列是栅格中最高的项（实测 910px），`align-items: start` 下它的包含块与自身等高、没有滑动余量，vendor 写的 `position: sticky; top: 14px` 完全无效（实测滚 700px 后左列 top = −355，检索框彻底消失），改为解除整列吸顶、只让筛选块吸顶；② `S.page` 的 `overflow: auto` 会在嵌入场景变成一个不再滚动的内层滚动盒，把 `<main>` 内所有 sticky 的参照系锁死在它自己身上（实测祖先链 `MAIN of=auto`），必须 `overflow: visible` 解绑。
  - **折行顺序与弹性基准按"同占一行"倒推**：DOM 顺序取「模式 → 检索 → 筛选」，让最宽的筛选项最后折行以占满整行；若把「科研模式」放末尾，被挤到第二行的是它一个窄控件、会留下一整行空白（1180px 窗口即触发）。检索框 flex 基准取 `1 1 200px`（922px 内容宽下 176 + 200 + 495 + 20 = 891 ≤ 922），基准给到 260 就会把筛选挤到第二行（带高 76 → 126px）。
  - 真实 DSH 实测（`scrollBody` 高 557px）：三分区滚 200 / 400 / 600px，吸顶顶边均等于导航底边（225px）；视口 1400 / 1280px 操作行单行（带高 76px），1100 / 980 / 820 / 700px 折两行（带高 126px）且顶边仍对齐；≤880px 时方法工坊双栏栅格塌陷为单列，筛选块在列表可见区间内恒贴住导航底（256px）。
- 🧹 移除分区导航右上角的「原「研究方法工坊」」等迁移提示徽标：合并过渡期已过，徽标只是常驻噪声，且它随窗口变窄折行会反过来改变导航高度（而导航高度正是二级吸顶的偏移量来源）。同步删除 `console-sections.js` 中已无消费方的 `formerLabel` 契约字段（六要素 → 五要素）。
- 🧱 修复方法工坊分区在窄屏不塌陷：vendored 双栏栅格是内联样式，880px 以下仍并排挤压，而另外两个分区已单列。现由媒体查询把 `.rk-studio-host main > div` 一并塌陷为单列，三个分区窄屏行为一致。
- 🖼 方法工坊分区不再收成居中窄栏：vendored `PromptStudio` 的根 `<main>` 内联了 `width: min(1240px, max(100%, calc(100vw - 280px)))` + `margin: 0 auto`（独立插件页为宿主侧栏预留 280px 的写法）。嵌入统一容器后父容器已是扣除侧栏的可视区，该上限使本分区在宽屏被压到 1240px 居中、在窄容器反而横向溢出，与铺满的「资源与工作流 / 研究灵感库」两个分区视觉割裂。现由 `dsh/prompt-studio-glue.js` 包装出 `.rk-studio-host` 锚点，`src/theme.js` 以 author 级 `!important` 覆盖内联宽度，vendor 工件零改动、能力集合不变。真实 Chromium 实测：父容器 1440px 时 main 宽 1240px → 1440px（铺满）；父容器 900px 时 1000px（溢出）→ 900px（贴合）。
- 📐 分区内边距改为流式令牌、消除硬编码像素：原先「资源与工作流 / 研究灵感库 / 方法工坊」三个分区与容器导航条各自硬编码 34px 水平内边距，窄窗口下会挤占内容宽度。现统一引用 `--rk-gutter: clamp(16px, 3vw, 34px)`（`src/theme.js` 唯一定义处，四处落点共同消费），视口 ≥1133px 时取上限 34px 保持既有视觉刻度，其间随窗口线性收缩，880px 以下由媒体查询锁定 16px。宽度方向一律用 `100%` 相对父容器解算，不出现固定 px 宽度。真实 Chromium 实测（四档视口，方法工坊分区）：600px / 880px → 16px、1000px → 30px（3vw）、1440px → 34px，各断点均铺满且无横向溢出。
- 🎯 输入卡片浮层改为锚定卡片，不再钉在视口上：`conversation.input.overlay` 的槽位锚点是输入卡片顶边的零高条（宿主自身光标菜单 `MenuView` 用同一锚点，定位为 `position:absolute; bottom:calc(100% + 4px); left:0`），且槽位包装是 `display:contents` 不参与布局。原实现用 `position:fixed; left:14px; bottom:96px; width:min(560px, calc(100vw - 28px)); max-height:min(620px, calc(100vh - 160px))`，后果有三：① 浮层左缘停在视口左侧、距卡片左缘 179px，与触发按钮脱节；② `bottom:96px` 是个猜的输入区高度，实测压住输入卡片 10px，输入框越高错位越大；③ 卡片居中位置与宽度随窗口变化时，浮层不跟随。现改为 `position:absolute; left:0; bottom:calc(100% + 8px)` 与宽度 `min(560px, 100%)`（全部相对锚点解算），可用高度由新增 `src/lib/overlay-anchor.js` 实测「卡片顶边 → 滚动区顶边」得出，并随卡片尺寸、滚动区尺寸（`ResizeObserver`）与窗口尺寸（`resize`）重算。真实 Chromium 实测（同一构建产物、同一 DOM、1180px 视口）：修复前 浮层 left=14 / 卡片 left=193 / 浮层底边压住卡片顶 10px；修复后 浮层 left=194 / 卡片 left=193 / 浮层底边距卡片顶 7px。
- 🛡 补登构建模块清单：`scripts/build-client.mjs` 的 `files` 是显式白名单，漏登记的新模块不会被拼入产物，只会在运行时 `ReferenceError`（`node --check` 查不出）。本次把 `src/lib/overlay-anchor.js` 补入 `files` 与 `ORDERED_SYMBOLS`，`npm run check` 同步纳入语法校验。
- 测试扩充至 80 项：新增「分区宽度一致」守护（vendor 宽度写法漂移检测 + 宿主锚点 + 覆盖规则齐备 + 三分区内边距同刻度，避免后续重构静默删除这条对 vendored 内联样式的覆盖）、「浮层锚定」守护（可用高度解算必须以裁剪边界为先 + 空间不足时不得产生越界高度 + 非法输入回落上限 + 定位不得回到视口固定写法 + 锚点与重算监听齐备）与「顶部吸顶」守护（两级吸顶齐备 + 偏移必须引用实测变量而非写死像素 + 三个分区都接入含方法工坊 vendor 侧解绑与漂移检测 + 常驻操作必须在吸顶带内且不留在封面 + 二级层级低于一级 + 构建产物含锚点），以及「分区契约」新增的「不残留迁移提示徽标 / `formerLabel` 死字段」守护。


- 语义增强英文指令与中文不一致：英文 contextLine 仍声明包含 `file references`，而 `researchContextSummary()` 实际只读会话勾选的目录资源、不含 `@文件` 引用；已改为 “catalog resources selected in this session, e.g. databases and skills”。
- 会话模型路由惰性兜底：插件晚于会话启动（或热重载）时 `agent/created` 不再触发，增强会误报“尚未建立模型路由”。现在缓存未命中时向 `ctx.sessions` 反查一次并缓存；宿主形状未知或探测抛错时安全退化为原有 503 行为，不崩溃。
- 构建器跨行 `import {}` 只删首行，剩余行残留成非法语句导致 `ui/client.js` 语法错误；新增折叠预处理。
- `dsh/slot-registry.js` 纳入 `npm run check` 语法检查。
- 文档与实现对齐：`ARCHITECTURE.md` 的 §1.2、§2 目录树与 §2.1 分层规则不再把 `index.js` 描述为“空 Node half”，改为说明两条受控路由（`/query` 与 `/semantic-enhance`）的边界。
- 文档数字校准：回归测试 40 → 61；公开直查数据源 9 → 11（补 GBIF、iNaturalist）；研究设计类目 3 → 2；基因组学类目 21 → 22。
- 开发手册补齐 Milestone C 的烟测验收记录表，并明确仓库内测试无法替代真实 profile 验证。
- 筛选后详情必须属于当前结果集（`selectedCatalogItem`），修复"技能筛选下继续显示先前工作流"。
- 手动编辑态改用 `null` 语义，用户清空 Prompt 不再被误判回自动组装。
- 成功提示仅在 `setDraft`/`submit` 真实存在并执行后出现；缺失时按钮禁用并说明原因。
- 🐛 **统一容器的「研究灵感库」分区未以 `embedded` 模式渲染**（真实 profile 烟测 F2 发现）：`src/research-console.js` 的 vault 分支未传 `embedded`，`ResearchVaultHost` 也不接收、不透传该参数，导致容器 `Page` 内嵌套第二层 `Page`——产物出现两个 `main.rk-page`，`min-height:100vh` 叠加使内容高 782px（视口仅 633px），产生多余滚动并把分区工具栏推到标签栏背后（`elementFromPoint(941,51)` 命中 `DIV.pV0-EW_tabs` 而非插件按钮）。修复后 `main.rk-page` 由 2 → 1、高度 782 → 633。新增回归测试「分区嵌入契约」（`test/research-console.test.js`）守护该缺陷类。

### 安全

- 🔒 **材料护照 YAML 序列化加固**：`mcp/state/material-passport.js` 此前把 `project` / `current_stage` / `summary` 等字段不经引号直接拼进 YAML 标量，值里含换行或引号便能逃逸出所在字段、在护照文件里**注入新的顶层字段**。现统一以 JSON 字符串（YAML 双引号标量的安全子集）序列化全部用户可控字段，读取端仍兼容历史护照中未加引号的标量；`run_id` 本就受 `validRunId` 字符白名单约束，输出格式保持不变。已附安全性测试。

### 已知限制

- 真实 DSH profile 烟测已完成两轮走查（F1–F4 快线、R1 发布门槛与 O1–O3 观测项全部通过，逐项步骤见 `docs/MANUAL-QA.md`）；**仅 R2 宿主动作缺失降级（无法从外部构造）仍未覆盖**。升级 DSH 版本后需按该清单复验——该次走查证明的只是当时那个 build 的 props 形状。
- R2 的降级守卫（`research-workbench.js:107/163/170`、`composer-overlay.js:48`）仅有代码审查确认，**无自动化测试覆盖**；建议补一个不传 `inputActions` 的渲染级测试。
- 工作台左列（资源列表）未做 sticky：右列详情约 1044px，左列仅 415px 且随页面滚走，滚到详情底部出口按钮时列表已滑出视口（F2 期间观察，非本次改造引入）。
- profile 侧的环境残留（与插件无关，R1 期间发现）：`remove` 不清理 `link:` 依赖的 `node_modules` 符号链接，卸载后 `require('dsh-research-kit')` 仍可解析（插件树由 `bundles` 驱动，残留链接不会被加载，影响为低）。
- 深色主题与窄屏已实现但未经真机截图核验；收藏、历史与个人工作流属 Phase 2。
