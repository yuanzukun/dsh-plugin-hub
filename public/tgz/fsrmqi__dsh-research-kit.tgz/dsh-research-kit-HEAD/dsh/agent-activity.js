
import { open, readFile, readdir, stat } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import path from 'node:path'
import { CALL_LOG_FILE, dataPath } from '../mcp/paths.js'
import { recordApproval } from '../mcp/state/checkpoint-manager.js'
import { buildRunOverview } from '../mcp/state/run-overview.js'
import { jsonReply as reply, readJsonBody } from './lib/http-json.js'

export const AGENT_ACTIVITY_PATH = '/dsh-research-kit/agent-activity'

const LOG_FILE = CALL_LOG_FILE
const CHECKPOINT_DIR = dataPath('checkpoints')
const MAX_TAIL_BYTES = 512 * 1024
const MAX_CHECKPOINT_FILES = 20
let logSnapshot = { size: -1, mtimeMs: -1, records: [] }
const checkpointSnapshots = new Map()

const readBody = req => readJsonBody(req, { maxChars: 32 * 1024, destroyOnTooLarge: true })

// 刻意不复用写入方（mcp/execution/call-logger.js）的 readCallLogs：那条要覆盖轮转文件
// 并按 tool 过滤，这条只读当前文件尾部（有界内存）、按 size/mtime 缓存快照、since 用
// 闭区间以避免同毫秒漏项。两边共享的是「文件在哪」（mcp/paths.js 的 CALL_LOG_FILE）。
async function readCallLogs({ limit = 50, since, runId } = {}) {
  if (!existsSync(LOG_FILE)) return []
  let handle
  try {
    handle = await open(LOG_FILE, 'r')
    const info = await handle.stat()
    const size = info.size
    let records = logSnapshot.records
    if (size !== logSnapshot.size || info.mtimeMs !== logSnapshot.mtimeMs) {
      const length = Math.min(size, MAX_TAIL_BYTES)
      const position = size - length
      const buffer = Buffer.alloc(length)
      await handle.read(buffer, 0, length, position)
      let text = buffer.toString('utf8')
      // 只读文件尾部时，第一行可能是半行；直接丢弃，避免把截断 JSON 当作有效记录。
      if (position > 0 && text.includes('\n')) text = text.slice(text.indexOf('\n') + 1)
      records = text.split('\n').filter(Boolean).map(line => {
        try { return JSON.parse(line) } catch { return null }
      }).filter(Boolean)
      logSnapshot = { size, mtimeMs: info.mtimeMs, records }
    }
    // 时间戳采用闭区间，避免同一毫秒写入多条记录时漏项；浏览器按稳定 key 去重。
    const sinceFiltered = since ? records.filter(record => record.at >= since) : records
    const filtered = runId ? sinceFiltered.filter(record => record.run_id === runId) : sinceFiltered
    return filtered.slice(-Math.min(limit, 200)).reverse()
  } catch {
    return []
  } finally {
    await handle?.close()
  }
}

async function readCheckpoints(runId) {
  if (!existsSync(CHECKPOINT_DIR)) return []
  try {
    const files = (await readdir(CHECKPOINT_DIR)).filter(file => file.endsWith('.json'))
    const liveFiles = new Set(files)
    for (const file of checkpointSnapshots.keys()) { if (!liveFiles.has(file)) checkpointSnapshots.delete(file) }
    const loaded = await Promise.all(files.map(async file => {
      try {
        const full = path.join(CHECKPOINT_DIR, file)
        const info = await stat(full)
        const cached = checkpointSnapshots.get(file)
        if (cached?.mtimeMs === info.mtimeMs && cached?.size === info.size) return cached.value
        const value = { state: JSON.parse(await readFile(full, 'utf8')), mtime: info.mtimeMs }
        checkpointSnapshots.set(file, { mtimeMs: info.mtimeMs, size: info.size, value })
        return value
      } catch { return null }
    }))
    return loaded
      .filter(Boolean)
      .sort((a, b) => b.mtime - a.mtime)
      .slice(0, MAX_CHECKPOINT_FILES)
      .map(item => item.state)
      .filter(state => !runId || state.run_id === runId)
  } catch {
    return []
  }
}

export function agentActivityRoute({ logger } = {}) {
  return {
    kind: 'exact', path: AGENT_ACTIVITY_PATH,
    async handler(req, res) {
      try {
        if (req.method === 'GET') {
          const url = new URL(req.url, `http://${req.headers?.host || 'localhost'}`)
          const limit = Math.max(1, Math.min(parseInt(url.searchParams.get('limit'), 10) || 50, 200))
          const since = url.searchParams.get('since') || null
          const runId = url.searchParams.get('run_id') || ''
          if (runId && !/^[A-Za-z0-9][A-Za-z0-9._-]{0,119}$/.test(runId)) return reply(res, 400, { ok: false, error: 'invalid_run_id' })
          const [calls, checkpoints, runOverview] = await Promise.all([
            readCallLogs({ limit, since, runId }),
            readCheckpoints(runId),
            // 运行总览（ROADMAP P1-1）：与 research_run_status 共享同一聚合层，
            // UI 无需复刻阶段/检查点推导逻辑；run 不存在时返回 null，前端按无概览渲染。
            runId ? buildRunOverview(runId).catch(() => null) : Promise.resolve(null),
          ])
          // 产物是调用日志的只读投影，避免为摘要再维护一份可能漂移的存储。
          const artifacts = calls.filter(call => call.ok !== false && call.artifact_kind).map(call => ({
            id: call.id, kind: call.artifact_kind, tool: call.tool, summary: call.result_summary, at: call.at,
          }))
          return reply(res, 200, { ok: true, calls, checkpoints, artifacts, run_overview: runOverview })
        }

        if (req.method === 'POST') {
          const body = await readBody(req)
          if (body?.action !== 'research_run_checkpoint_approve') {
            return reply(res, 400, { ok: false, error: 'unsupported_action' })
          }
          const result = await recordApproval(body.run_id, body.stage, { note: body.note })
          return reply(res, 200, { ok: true, result })
        }

        return reply(res, 405, { ok: false, error: 'method_not_allowed' })
      } catch (error) {
        try { logger?.warn?.(`agent-activity error: ${error?.message || error}`) } catch {}
        const status = error?.code === 'CHECKPOINT_NOT_FOUND' ? 404
          : error?.message === 'invalid_json' ? 400
            : error?.message === 'body_too_large' ? 413 : 500
        return reply(res, status, { ok: false, error: error?.message || 'internal_error' })
      }
    },
  }
}
