export const DATABASE_QUERY_PATH = '/dsh-research-kit/query'
import { readConfigValue } from './config.js'
import { jsonReply as reply } from './lib/http-json.js'
import { createTtlCache } from '../mcp/execution/ttl-cache.js'

const MAX_QUERY_LENGTH = 300
const MAX_LIMIT = 10

// 查询预算与限流（进程内、重启即清零）：
//   - 缓存：同一 (database, query, limit) 5 分钟内直接返回上次结果，减少对公开 API 的重复冲击；
//   - 速率：每 IP 每分钟最多 12 次查询，超出返回 429 并提示走 Agent 查询；
//   - 缓存只保存解析后的结构化来源（标题/链接/摘要），不含任何凭据或请求头。
const CACHE_TTL_MS = 5 * 60_000
const CACHE_MAX_ENTRIES = 200
const RATE_LIMIT_WINDOW_MS = 60_000
const RATE_LIMIT_MAX_REQUESTS = 12
const MAX_RATE_BUCKETS = 1000

// 命中提升到末尾（真 LRU）：查询分布长尾明显，FIFO 淘汰会把刚用过的结果挤出去。
const queryCache = createTtlCache({ ttlMs: CACHE_TTL_MS, maxEntries: CACHE_MAX_ENTRIES, lruOnHit: true })
const inFlightQueries = new Map()
const rateBuckets = new Map()

function normalizeQueryKey(query) { return String(query || '').trim() }
function normalizeLimit(limit) { return Math.max(1, Math.min(Number(limit) || 5, MAX_LIMIT)) }
function cacheKey(databaseId, query, limit) { return `${databaseId}::${normalizeQueryKey(query)}::${normalizeLimit(limit)}` }

function pruneRateBuckets(now) {
  for (const [key, times] of rateBuckets) {
    const active = times.filter(at => now - at < RATE_LIMIT_WINDOW_MS)
    if (active.length) rateBuckets.set(key, active)
    else rateBuckets.delete(key)
  }
}

function evictOldestRateBucket() {
  let oldestKey = null
  let oldestAt = Infinity
  for (const [key, times] of rateBuckets) {
    const at = times[0] ?? Infinity
    if (at < oldestAt) { oldestAt = at; oldestKey = key }
  }
  if (oldestKey !== null) rateBuckets.delete(oldestKey)
}

// 每 IP 滑动计数：窗口内达到上限时拒绝本次查询。桶数也有硬上限，
// 防止短时间的大量新客户端标识把进程内 Map 撑大。
//
// 注意：`mcp/execution/source-querier.js` 里也有一个 `rateLimitExceeded`，那是**另一套策略**
// （按数据源而不是按客户端 IP 计数、窗口过滤内联、桶数上限 100、没有 prune/淘汰辅助函数），
// 不是这份的重复实现。限流主体不同，不要为了「去重」把它们合成一个。
function rateLimitExceeded(clientKey, maxRequests = RATE_LIMIT_MAX_REQUESTS) {
  const now = Date.now()
  pruneRateBuckets(now)
  const bucket = rateBuckets.get(clientKey) || []
  if (bucket.length >= maxRequests) { rateBuckets.set(clientKey, bucket); return true }
  while (!rateBuckets.has(clientKey) && rateBuckets.size >= MAX_RATE_BUCKETS) evictOldestRateBucket()
  bucket.push(now)
  rateBuckets.set(clientKey, bucket)
  return false
}

function clientKeyFor(req) {
  const remoteAddress = String(req?.socket?.remoteAddress || '')
  // DSH 常部署为本机 webServer；此时本机反向代理传来的首个 XFF 才可信。
  // 非本机直连一律使用 socket 地址，避免客户端伪造 XFF 绕过限流。
  const isLoopback = remoteAddress === '127.0.0.1' || remoteAddress === '::1' || remoteAddress === '::ffff:127.0.0.1'
  const forwarded = String(req?.headers?.['x-forwarded-for'] || '').split(',')[0].trim()
  return isLoopback && forwarded ? forwarded : remoteAddress || 'local'
}

function textBody(result) {
  if (!result || result.statusCode < 200 || result.statusCode >= 300) throw new Error(`数据源返回 HTTP ${result?.statusCode ?? '未知状态'}`)
  return String(result.body?.content || '')
}
function jsonBody(result) {
  const raw = textBody(result)
  try { return JSON.parse(raw) } catch { throw new Error('数据源返回的内容不是可解析 JSON。') }
}
function clean(value, limit = 280) { return String(value || '').replace(/\s+/g, ' ').trim().slice(0, limit) }
function source(id, title, url, meta = '', summary = '') { return { id: String(id || url), title: clean(title, 220) || '未命名记录', url: String(url || ''), meta: clean(meta, 180), summary: clean(summary, 420) } }

// 上游把字段从数组改成对象、或返回 null 包体时，`.map` 会抛 TypeError —— 那会变成 502，
// 用户看到的是「插件坏了」。统一先收敛成「对象数组」：形状不对就当这条来源没返回记录，
// 由下面的空结果分支交给 Agent 回退，绝不把上游的怪形状升级成插件故障。
// （本文件是宿主半区，不进浏览器产物，因此不占用产物的全局符号名约束。）
function adapterRows(value) {
  return (Array.isArray(value) ? value : []).filter(item => item && typeof item === 'object')
}

const DIRECT_ADAPTERS = {
  crossref: {
    url: (q, n) => `https://api.crossref.org/works?query=${encodeURIComponent(q)}&rows=${n}&select=DOI,title,author,published-print,published-online,container-title,URL`,
    parse: data => adapterRows(data?.message?.items).map(item => source(item.DOI, item.title?.[0], item.URL || `https://doi.org/${item.DOI}`, [item.author?.[0]?.family, item['container-title']?.[0], item['published-print']?.['date-parts']?.[0]?.[0] || item['published-online']?.['date-parts']?.[0]?.[0]].filter(Boolean).join(' · ')))
  },
  openalex: {
    url: (q, n) => `https://api.openalex.org/works?search=${encodeURIComponent(q)}&per-page=${n}`,
    parse: data => adapterRows(data?.results).map(item => source(item.id, item.title, item.doi || item.id, [item.publication_year, item.primary_location?.source?.display_name, item.cited_by_count ? `被引 ${item.cited_by_count}` : ''].filter(Boolean).join(' · '), item.abstract_inverted_index ? 'OpenAlex 已返回摘要索引；请打开原文或来源核验细节。' : ''))
  },
  'semantic-scholar': {
    url: (q, n) => `https://api.semanticscholar.org/graph/v1/paper/search?query=${encodeURIComponent(q)}&limit=${n}&fields=title,year,authors,venue,abstract,url,citationCount,externalIds`,
    parse: data => adapterRows(data?.data).map(item => source(item.paperId || item.externalIds?.DOI, item.title, item.url || (item.externalIds?.DOI ? `https://doi.org/${item.externalIds.DOI}` : ''), [item.year, item.venue, item.citationCount ? `被引 ${item.citationCount}` : ''].filter(Boolean).join(' · '), item.abstract))
  },
  'europe-pmc': {
    url: (q, n) => `https://www.ebi.ac.uk/europepmc/webservices/rest/search?format=json&pageSize=${n}&query=${encodeURIComponent(q)}`,
    parse: data => adapterRows(data?.resultList?.result).map(item => source(item.pmid || item.id, item.title, item.pmid ? `https://europepmc.org/article/MED/${item.pmid}` : `https://europepmc.org/article/${item.source || 'MED'}/${item.id}`, [item.authorString, item.journalTitle, item.pubYear].filter(Boolean).join(' · '), item.abstractText))
  },
  clinicaltrials: {
    url: (q, n) => `https://clinicaltrials.gov/api/v2/studies?query.term=${encodeURIComponent(q)}&pageSize=${n}&format=json`,
    parse: data => adapterRows(data?.studies).map(item => {
      const p = item.protocolSection || {}, id = p.identificationModule?.nctId
      return source(id, p.identificationModule?.briefTitle, id ? `https://clinicaltrials.gov/study/${id}` : '', [p.statusModule?.overallStatus, p.designModule?.studyType].filter(Boolean).join(' · '), p.descriptionModule?.briefSummary)
    })
  },
  openfda: {
    url: (q, n) => `https://api.fda.gov/drug/event.json?search=${encodeURIComponent(q)}&limit=${n}`,
    parse: data => adapterRows(data?.results).map((item, index) => source(`openfda-${index}`, item.patient?.drug?.[0]?.medicinalproduct || '药物不良事件记录', 'https://open.fda.gov/apis/drug/event/', [item.receiptdate, item.serious === '1' ? '严重事件' : ''].filter(Boolean).join(' · '), adapterRows(item.patient?.reaction).map(row => row.reactionmeddrapt).filter(Boolean).join('；')))
  },
  uniprot: {
    url: (q, n) => `https://rest.uniprot.org/uniprotkb/search?format=json&size=${n}&query=${encodeURIComponent(q)}`,
    parse: data => adapterRows(data?.results).map(item => source(item.primaryAccession, item.proteinDescription?.recommendedName?.fullName?.value || item.primaryAccession, `https://www.uniprot.org/uniprotkb/${item.primaryAccession}`, [item.organism?.scientificName, item.entryType].filter(Boolean).join(' · '), adapterRows(item.comments)[0]?.texts?.[0]?.value))
  },
  pubchem: {
    url: (q, n) => `https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/${encodeURIComponent(q)}/property/IUPACName,MolecularFormula,MolecularWeight/JSON`,
    parse: (data, n) => adapterRows(data?.PropertyTable?.Properties).slice(0, n).map(item => source(item.CID, item.IUPACName || `PubChem CID ${item.CID}`, `https://pubchem.ncbi.nlm.nih.gov/compound/${item.CID}`, [item.MolecularFormula, item.MolecularWeight ? `${item.MolecularWeight} Da` : ''].filter(Boolean).join(' · ')))
  },
  gbif: {
    url: (q, n) => `https://api.gbif.org/v1/occurrence/search?q=${encodeURIComponent(q)}&limit=${n}`,
    parse: data => adapterRows(data?.results).map(item => source(item.key, item.scientificName || item.species || 'GBIF occurrence', `https://www.gbif.org/occurrence/${item.key}`, [item.country, item.eventDate, item.basisOfRecord].filter(Boolean).join(' · '), item.datasetName || item.recordedBy))
  },
  inaturalist: {
    url: (q, n) => `https://api.inaturalist.org/v1/observations?q=${encodeURIComponent(q)}&per_page=${n}`,
    parse: data => adapterRows(data?.results).map(item => source(item.id, item.taxon?.preferred_common_name || item.taxon?.name || 'iNaturalist observation', `https://www.inaturalist.org/observations/${item.id}`, [item.observed_on, item.place_guess, item.quality_grade].filter(Boolean).join(' · '), item.description))
  }
}

async function queryPubMed(web, query, limit, signal) {
  const search = jsonBody(await web.fetch({ url: `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retmode=json&retmax=${limit}&term=${encodeURIComponent(query)}` }, signal))
  const ids = search.esearchresult?.idlist || []
  if (!ids.length) return []
  const summary = jsonBody(await web.fetch({ url: `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&retmode=json&id=${encodeURIComponent(ids.join(','))}` }, signal))
  return ids.map(id => {
    const item = summary.result?.[id] || {}
    return source(id, item.title, `https://pubmed.ncbi.nlm.nih.gov/${id}/`, [item.pubdate, item.fulljournalname, item.authors?.[0]?.name].filter(Boolean).join(' · '), item.sortfirstauthor ? `第一作者：${item.sortfirstauthor}` : '')
  })
}

function queryPrompt(database, query) {
  return `请基于「${database.name}」查询：${query}。优先使用当前会话已配置的 Web、MCP 或数据库工具。返回每条实际检索到记录的标题、稳定标识符、来源链接、年份/版本与一句相关性说明；未能访问时明确说明原因。不得编造文献、DOI、数据集编号或检索结果。`
}

function agentFallback(database, query, reason) {
  return {
    mode: 'agent-fallback', query, sources: [], reason,
    prompt: queryPrompt(database, query)
  }
}

function shouldFallbackToAgent(error) {
  const message = String(error?.message || error)
  return /HTTP (401|403|408|429|500|502|503|504)|WEB_PROVIDER_|查询超时|上游返回结构异常/.test(message)
}

// 直查「一条都没解析出来」不等于「这条记录不存在」：上游改了返回结构、检索词过窄，
// 或者包体是个没预料到的形状，都会是 0 条。报 mode:'direct' + 空列表等于替上游断言，
// 因此 0 条也交给 Agent 回退（用户显式关掉回退时除外，那时如实返回空直查结果）。
const EMPTY_DIRECT_REASON = '插件直查没有返回可解析记录（可能是检索词过窄，或上游改了返回结构）；可交给当前 Agent 使用 Web 或 MCP 继续查询。'

export async function runDatabaseQuery({ web, database, query, limit = 5, signal, allowAgentFallback = true }) {
  const normalizedQuery = normalizeQueryKey(query)
  if (!normalizedQuery) throw new Error('请输入检索词。')
  if (normalizedQuery.length > MAX_QUERY_LENGTH) throw new Error(`检索词不能超过 ${MAX_QUERY_LENGTH} 个字符。`)
  const size = normalizeLimit(limit)
  const emptyDirect = reason => (allowAgentFallback
    ? agentFallback(database, normalizedQuery, reason)
    : { mode: 'direct', sources: [], query: normalizedQuery })
  const direct = sources => {
    const rows = adapterRows(sources).slice(0, size)
    return rows.length ? { mode: 'direct', sources: rows, query: normalizedQuery } : emptyDirect(EMPTY_DIRECT_REASON)
  }
  try {
    if (database.id === 'pubmed') {
      return direct(await queryPubMed(web, normalizedQuery, size, signal))
    }
    const adapter = DIRECT_ADAPTERS[database.id]
    if (adapter) {
      const data = jsonBody(await web.fetch({ url: adapter.url(normalizedQuery, size) }, signal))
      let sources
      // 适配器自己也要兜一层：万一某个 parse 仍然对怪形状抛错，那是「这次直查没成功」，
      // 而不是插件故障——交给 shouldFallbackToAgent 平滑降级。
      try { sources = adapter.parse(data, size) } catch (error) {
        throw new Error(`上游返回结构异常：${String(error?.message || error)}`)
      }
      return direct(sources)
    }
  } catch (error) {
    if (shouldFallbackToAgent(error) && allowAgentFallback) return agentFallback(database, normalizedQuery, `插件直查暂不可用（${String(error?.message || error)}）；可交给当前 Agent 使用 Web 或 MCP 继续查询。`)
    throw error
  }
  if (!allowAgentFallback) throw new Error('Agent 回退已关闭。')
  return agentFallback(database, normalizedQuery, database.accessNote || '该来源需要当前会话的 MCP、授权或专用适配器。')
}

export function databaseQueryRoute({ web, databases, logger, config }) {
  const byId = new Map(databases.map(item => [item.id, item]))
  return {
    kind: 'exact', path: DATABASE_QUERY_PATH,
    async handler(req, res) {
      if (req.method !== 'GET') return reply(res, 405, { error: 'method_not_allowed' })
      const url = new URL(req.url || DATABASE_QUERY_PATH, 'http://localhost')
      const database = byId.get(String(url.searchParams.get('database_id') || ''))
      if (!database) return reply(res, 404, { error: 'unknown_database' })
      const query = String(url.searchParams.get('q') || '')
      const limit = String(url.searchParams.get('limit') || '5')
      const maxRequests = Math.max(1, Number(readConfigValue(config?.databaseRequestsPerMinute, RATE_LIMIT_MAX_REQUESTS)) || RATE_LIMIT_MAX_REQUESTS)
      const timeoutMs = Math.max(1, Number(readConfigValue(config?.databaseTimeoutMs, 15_000)) || 15_000)
      const allowAgentFallback = readConfigValue(config?.allowAgentFallback, true) !== false
      const clientKey = clientKeyFor(req)
      // 先查缓存：命中则不计入速率窗口（缓存读取不冲击公开 API）。关闭回退后，
      // 不能继续返回旧配置下缓存的 Agent 回退结果；直查结果则与该策略无关，可复用。
      const key = cacheKey(database.id, query, limit)
      const cached = queryCache.get(key)
      if (cached && (allowAgentFallback || cached.mode !== 'agent-fallback')) {
        return reply(res, 200, { ...cached, cached: true })
      }
      if (rateLimitExceeded(clientKey, maxRequests)) {
        try { logger?.warn?.(`database query rate limited client=${clientKey} id=${database.id}`) } catch {}
        return reply(res, 429, { error: 'rate_limited', message: `查询过于频繁（每分钟 ${maxRequests} 次上限）。请稍后再试，或改用「让 Agent 查询」由会话内 Agent 检索。` })
      }
      try {
        // 即时配置也约束正在合并的请求，避免新请求复用旧 fallback/超时策略。
        const inFlightKey = `${key}::fallback=${allowAgentFallback}::timeout=${timeoutMs}`
        let pending = inFlightQueries.get(inFlightKey)
        if (!pending) {
          pending = (async () => {
            const controller = new AbortController()
            const timeout = setTimeout(() => controller.abort(), timeoutMs)
            try {
              const result = await runDatabaseQuery({ web, database, query, limit, signal: controller.signal, allowAgentFallback })
              const payload = { database: { id: database.id, name: database.name }, ...result }
              queryCache.set(key, payload)
              return payload
            } catch (error) {
              if (controller.signal.aborted) throw new Error('查询超时，请缩短检索词或稍后重试。')
              throw error
            } finally {
              clearTimeout(timeout)
            }
          })()
          inFlightQueries.set(inFlightKey, pending)
          pending.finally(() => inFlightQueries.delete(inFlightKey)).catch(() => {})
        }
        const payload = await pending
        reply(res, 200, payload)
      } catch (error) {
        const message = String(error?.message || error)
        try { logger?.warn?.(`database query failed id=${database.id}: ${message}`) } catch {}
        reply(res, /查询超时/.test(message) ? 504 : 502, { error: 'database_query_failed', message })
      }
    }
  }
}
