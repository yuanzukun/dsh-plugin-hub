import React from 'react'
// 研究草稿增强器：把 vendored PromptKit.QuickEnhancer 适配到 Research Kit 的科研边界。
// 增强服务端（dsh/semantic-enhance.js）复用当前会话模型路由；浏览器端不持有任何 Key。
//
// 研究定制（相对通用 QuickEnhancer 的差异）：
//   1. 只读上下文摘要：把当前会话资源面板勾选的目录条目（数据库、技能等）注入
//      researchContext，供改写对齐术语与范围；@文件 引用由 QuickEnhancer 的草稿解析单独并入；
//   2. 研究边界由服务端 system 指令统一执行（不编造引用/数据、保持研究范围、保密、待核验标记）；
//   3. 增强结果写入前保留差异/恢复能力（QuickEnhancer 内置 undoDraft）。
import { itemById, loadBrowserCatalog, subscribeCatalog } from '../src/catalog.js'
import { RESEARCH_RESOURCE_SELECTION_EVENT } from '../src/composer-launcher.js'
import { createResearchSelectionStore } from '../src/research-selection-store.js'
import { C, GlobalStyle } from '../src/theme.js'
import { IconButton } from '../src/ui.js'
import { ResearchDepositButton, QUICK_ENHANCER_POSITION_KEY } from '../src/composer-deposit-button.js'
import { useEntryMode, ENTRY_MODE_FLOATING } from '../src/entry-mode.js'
import { getPromptKit, loadPromptKit, promptKitReady } from '../src/promptkit-loader.js'

const ENHANCE_PATH = '/dsh-research-kit/semantic-enhance'
const ENHANCE_STREAM_PATH = '/dsh-research-kit/semantic-enhance/stream'

// 研究增强客户端：SSE 流式优先，404/501 时降级为非流式 JSON（与 PromptKit 契约一致）。
// QuickEnhancer 的 options 不含 researchContext；这里在发送前统一注入当前会话的
// 只读研究上下文摘要（已选数据库/技能/工作流名称与说明），供服务端对齐术语与范围。
class ResearchSessionEnhancer {
  constructor(getSessionId) { this.getSessionId = getSessionId; this.controller = null }
  get loading() { return !!this.controller }
  withResearchContext(options) {
    return { ...options, researchContext: options.researchContext ?? researchContextSummary(this.getSessionId()) }
  }
  async enhance(options) {
    this.controller?.abort()
    const controller = new AbortController()
    this.controller = controller
    const { draft, extra, lang, method, strength, hasContext, diagnose = false, researchContext } = this.withResearchContext(options)
    try {
      const response = await fetch(`${ENHANCE_PATH}?session_id=${encodeURIComponent(this.getSessionId())}`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ draft, extra, lang, method, strength, hasContext, diagnose, researchContext }),
        signal: controller.signal,
      })
      const body = await response.json().catch(() => ({}))
      if (!response.ok) {
        if (response.status === 504) throw Object.assign(new Error(body.next_action || '模型响应超时，请稍后重试。'), { timeout: true })
        throw new Error(body.next_action || body.error || '基于草稿改造失败')
      }
      return body
    } finally { if (this.controller === controller) this.controller = null }
  }
  async enhanceStream(options) {
    this.controller?.abort()
    const controller = new AbortController()
    this.controller = controller
    const signal = controller.signal
    const { draft, extra, lang, method, strength, hasContext, diagnose = false, researchContext, onDelta, onStage } = this.withResearchContext(options)
    try {
      const response = await fetch(`${ENHANCE_STREAM_PATH}?session_id=${encodeURIComponent(this.getSessionId())}`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ draft, extra, lang, method, strength, hasContext, diagnose, researchContext }),
        signal,
      })
      if (response.status === 404 || response.status === 501) {
        const error = new Error('stream_unavailable')
        error.fallback = true
        throw error
      }
      if (!response.ok || !response.body) {
        const body = await response.json().catch(() => ({}))
        if (response.status === 504) throw Object.assign(new Error(body.next_action || '模型响应超时，请稍后重试。'), { timeout: true })
        throw new Error(body.next_action || body.error || '流式增强不可用')
      }
      const reader = response.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ''
      let final = null
      const consume = frame => {
        const lines = frame.split(/\r?\n/)
        const event = lines.find(line => line.startsWith('event:'))?.slice(6).trim()
        const dataLine = lines.filter(line => line.startsWith('data:')).map(line => line.slice(5).trim()).join('\n')
        if (!event || !dataLine) return
        const data = JSON.parse(dataLine)
        if (event === 'delta') onDelta?.(data.text)
        if (event === 'stage') onStage?.(data.phase, data.model)
        if (event === 'done') final = data
        if (event === 'error') throw Object.assign(new Error(data.message || data.error || '流式增强失败'), { timeout: Boolean(data.timeout) })
      }
      try {
        for (;;) {
          const { value, done } = await reader.read()
          if (signal.aborted) throw Object.assign(new Error('已取消'), { name: 'AbortError' })
          buffer += done ? decoder.decode() : decoder.decode(value, { stream: true })
          const frames = buffer.split(/\r?\n\r?\n/)
          buffer = frames.pop() || ''
          for (const frame of frames) consume(frame)
          if (done && buffer.trim()) consume(buffer)
          if (final || done) break
        }
        if (!final) throw new Error('流式增强连接中断。')
        return final
      } finally {
        await reader.cancel().catch(() => {})
        reader.releaseLock()
      }
    } finally { if (this.controller === controller) this.controller = null }
  }
  cancel() { this.controller?.abort(); this.controller = null }
}

// 桥接 DSH 输入框：inputActions 由槽位体系注入（setDraft / submit）。
// 草稿真源随 DSH 版本：InputZone 点时快照（0.1.2）或 useInput 订阅（0.1.3+/旧契约）。
export class ResearchDraftComposer {
  constructor(input, inputActions) { this.input = input; this.inputActions = inputActions; this.listeners = new Set() }
  getDraft() { return this.input?.draft ?? '' }
  write(text) { this.inputActions?.setDraft(String(text ?? '')) }
  getSelection() {
    if (typeof this.inputActions?.captureInsertion !== 'function') return null
    const span = this.inputActions.captureInsertion()
    if (!span || span.start === span.end) return null
    // DSH 的选区坐标是 detect projection；含 @ 引用 chip 时与 clipboard 草稿坐标不同。
    if (this.input?.occurrences?.length) throw new Error('草稿包含引用，请先取消选区并使用整稿增强。')
    const draft = String(this.getDraft())
    if (!Number.isInteger(span.start) || !Number.isInteger(span.end) || span.start < 0 || span.end > draft.length) throw new Error('选区已变化，请重新选择。')
    return { start: span.start, end: span.end, text: draft.slice(span.start, span.end), draft, span }
  }
  replaceSelection(text, selection) {
    if (!selection || selection.draft !== this.getDraft() || typeof this.inputActions?.insertText !== 'function') throw new Error('选区已变化，请重新选择。')
    if (!this.inputActions.insertText(String(text ?? ''), selection.span)) throw new Error('草稿或选区已变化，未覆盖新内容；请重新操作。')
  }
  onChange(cb) { this.listeners.add(cb); return () => this.listeners.delete(cb) }
  notify(draft) { for (const cb of this.listeners) cb(draft) }
}

// 只读研究上下文：当前会话经资源面板勾选的目录条目（数据库、技能等）的名称与一句话说明。
// 纯内存读取，不落盘、不携带文件正文或查询结果；服务端只把它作为改写的范围参照。
// 注意：@文件 引用不在此摘要内——它们由 QuickEnhancer 的草稿解析（referencedFiles）
// 单独并入增强请求的 extra，并自带"文件内容由 DSH @file 在发送后处理"的边界声明。
function researchContextSummary(sessionId) {
  try {
    const rows = createResearchSelectionStore(sessionId).get().map(itemById).filter(Boolean)
    return rows.map(item => `${item.type === 'database' ? '数据库' : item.type === 'workflow' ? '工作流' : '技能'}：${item.name} —— ${item.description}`).join('\n')
  } catch { return '' }
}

function LoadedResearchDraftEnhancerHost(props) {
  const PromptKit = getPromptKit()
  ensureResearchProviders(PromptKit)
  // anchorRef / open / onOpenChange 由 ResearchDraftEnhancerHost 传入：触发钮由插件自绘
  // （ResearchDraftEnhancerTrigger），工件只负责「嵌在工具条里的面板」。
  const { sessionId, input, useInput, useChat, inputActions, anchorRef, open, onOpenChange, floating } = props
  const zonedDraft = input?.draft
  const hookedInput = useInput ? useInput(value => value) : undefined
  const draft = zonedDraft !== undefined ? zonedDraft : hookedInput?.draft
  const chatSnapshot = useChat ? useChat(value => value?.legacy ?? value) : undefined
  const messages = React.useMemo(() => PromptKit.utils.conversationMessages(chatSnapshot), [chatSnapshot])
  const composer = React.useMemo(() => new ResearchDraftComposer({ draft }, inputActions), [sessionId, inputActions])
  composer.input = { draft, occurrences: input?.occurrences ?? hookedInput?.occurrences }
  const enhancer = React.useMemo(() => new ResearchSessionEnhancer(() => sessionId), [sessionId])
  // 会话资源选择变化时刷新上下文摘要；摘要每次增强时即时计算，避免过期引用。
  const [, setSelectionVersion] = React.useState(0)
  React.useEffect(() => {
    const dispose = subscribeCatalog(() => setSelectionVersion(value => value + 1))
    loadBrowserCatalog().catch(() => {})
    return dispose
  }, [])
  React.useEffect(() => {
    const onChange = () => setSelectionVersion(value => value + 1)
    window.addEventListener(RESEARCH_RESOURCE_SELECTION_EVENT, onChange)
    return () => window.removeEventListener(RESEARCH_RESOURCE_SELECTION_EVENT, onChange)
  }, [])
  const searchMemory = React.useCallback(async query => {
    // 研究上下文桥接（既有）：当前会话已选科研资源的只读摘要。
    const context = researchContextSummary(sessionId)
    const sources = context ? [{ kind: 'research-selection', label: '当前会话已选科研资源' }] : []
    let text = context
    // Memory Center 项目记忆检索（ROADMAP §5）：经 Node half 路由代查宿主已连接的
    // Memory Center MCP；结果只作为候选上下文返回，由 QuickEnhancer 的「项目记忆」
    // 开关显式勾选后才进入增强（检索 → 来源预览 → 用户选择 → 组装，禁止静默注入）。
    // 检索失败或部署未接入 Memory Center 时如实回落：只用研究上下文，不阻断增强。
    // 可选模板：检索工具若是多动作门面（如必填 action），可在 localStorage 设置
    // dsh-research-kit.memory-search.template 为 JSON 模板（{query}/{limit} 占位符），
    // 例：{"action":"search","query":"{query}","limit":5}——这是对工具契约的显式声明。
    try {
      let args
      try { args = JSON.parse(window.localStorage.getItem('dsh-research-kit.memory-search.template') || 'null') || undefined } catch { args = undefined }
      const response = await fetch(`/dsh-research-kit/memory-search?session_id=${encodeURIComponent(sessionId || '')}`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ query, ...(args ? { args } : {}) }),
      })
      if (response.ok) {
        const body = await response.json().catch(() => null)
        if (body?.ok && body?.available && body?.text) {
          text = [context, body.text].filter(Boolean).join('\n\n')
          sources.push(...(body.sources || []).filter(source => source?.label).slice(0, 4))
        }
      }
    } catch { /* 记忆检索不可用不是增强的失败条件 */ }
    return { text, sources }
  }, [sessionId])
  React.useEffect(() => { composer.notify(draft ?? '') }, [draft, composer])
  // 研究方法工坊共用同一 provider 资产命名空间（dsh-research-kit.promptkit.）。
  // 面板本体两种形态共用，只有「启动钮归谁」不同（入口形态见 src/entry-mode.js）：
  //   inline（默认）：launcher: 'inline' + renderLauncher: null —— 触发钮由
  //     ResearchDraftEnhancerTrigger 自绘（工件挂起时入口仍在），anchorRef / open /
  //     onOpenChange 让面板锚定该按钮并由插件受控开合（⌘K 也走同一状态）；
  //   floating（设置里可选）：保留受控 open / onOpenChange 以承接首次按需加载；使用工件自己的可拖拽悬浮钮与位置记忆，
  //     旁边并排渲染「沉淀最近回答」伴生圆钮。
  const launcherProps = floating
    ? { open, onOpenChange }
    : { launcher: 'inline', renderLauncher: () => null, anchorRef, open, onOpenChange }
  return React.createElement(PromptKit.QuickEnhancer, {
    key: 'promptkit-quick-enhancer',
    methodProvider: researchMethodProvider,
    assetProvider: researchAssetProvider,
    composer,
    enhancer,
    messages,
    searchMemory,
    storagePrefix: 'dsh-research-kit.promptkit.',
    ...launcherProps,
  })
}

// 悬浮形态下的加载兜底。工件没就绪时右下角不能什么都不留，否则又回到
// 「插件装着、入口却消失」这种无从定位的状态。它就落在工件自己会用的位置上
// （读同一个位置键，缺省用工件默认的右下角），加载完成后由工件的悬浮钮原样接替。
export function ResearchDraftEnhancerFallbackFab({ state, errorText, onClick }) {
  const failed = state === 'error'
  const label = failed
    ? `草稿增强加载失败，点击重试${errorText ? `：${errorText}` : ''}`
    : state === 'idle' ? '打开对话增强器（⌘K）' : '草稿增强加载中…'
  let stored = null
  try { stored = JSON.parse(window.localStorage.getItem(QUICK_ENHANCER_POSITION_KEY) || 'null') } catch { stored = null }
  const viewportWidth = Number(window.innerWidth) || 0
  const viewportHeight = Number(window.innerHeight) || 0
  const x = Number.isFinite(Number(stored?.x)) ? Number(stored.x) : Math.max(24, viewportWidth - 86)
  const y = Number.isFinite(Number(stored?.y)) ? Number(stored.y) : Math.max(96, viewportHeight - 158)
  return React.createElement(React.Fragment, null, [
    React.createElement(GlobalStyle, { key: 'style' }),
    React.createElement('div', {
      key: 'fab',
      'data-research-kit': 'draft-enhancer-fallback',
      'data-state': state,
      style: { position: 'fixed', left: x, top: y, zIndex: 20001, display: 'flex' },
    }, React.createElement(IconButton, {
      name: 'sparkles',
      label,
      size: 18,
      active: failed,
      onClick,
      style: {
        width: 44, height: 44, borderRadius: '50%',
        border: `1px solid ${failed ? C.amber : C.line}`,
        background: C.surface, color: failed ? C.amber : C.muted,
        boxShadow: '0 10px 24px rgba(15, 23, 42, 0.18)',
      },
    })),
  ])
}

// PromptKit 工件是懒加载的（见 src/promptkit-loader.js）。它加载失败时，
// conversation.input.right 这整块入口会静默收起——除控制台外现场不留任何痕迹，
// 于是「插件装着、四个槽里唯独少了草稿增强」无从定位。这里把最后一次失败原因
// 写进 localStorage（成功即清除），供 Plugins 页诊断与排障读取。
export const PROMPTKIT_LOAD_ERROR_KEY = 'dsh-research-kit.promptkit.load-error.v1'
// 成功也要留痕：否则「加载成功但槽位没挂载」与「页面还在跑旧产物」在磁盘上无法区分。
export const PROMPTKIT_LOADED_KEY = 'dsh-research-kit.promptkit.loaded.v1'

/** 标记加载成功（error 为空）或记录失败原因（error 非空）。 */
export function recordPromptKitLoadError(error) {
  if (error == null) {
    try {
      window.localStorage.removeItem(PROMPTKIT_LOAD_ERROR_KEY)
      window.localStorage.setItem(PROMPTKIT_LOADED_KEY, new Date().toISOString())
    } catch { /* 存储不可用时无痕放弃 */ }
    return
  }
  try {
    window.localStorage.setItem(PROMPTKIT_LOAD_ERROR_KEY, `${new Date().toISOString()} ${String(error?.message || error)}`)
  } catch { /* 同上：写不了也仍然有控制台输出 */ }
  console.error('[dsh-research-kit] PromptKit 工件加载失败，草稿增强入口保持收起：', error)
}

// 输入框右侧的内联入口：纯图标按钮（宿主原生 IconButton，与模型选择器等图标钮同规格）。
// 不带文字标签，说明性文字只放在 title / aria-label 里。
// 它由插件自己渲染，不依赖懒加载的 PromptKit 工件——工件挂起或加载失败时入口仍然在，
// 用户看到「加载中 / 失败可重试」，而不是整块槽位静默消失。外层 div 持有 ref 作为面板锚点
// （IconButton 不转发 ref，且外层矩形即按钮矩形）。
export function ResearchDraftEnhancerTrigger({ open, state, errorText, onClick, anchorRef }) {
  const active = Boolean(open)
  const label = state === 'error'
    ? `草稿增强加载失败，点击重试${errorText ? `：${errorText}` : ''}`
    : state === 'loading' ? '草稿增强加载中…' : '打开对话增强器（⌘K）'
  return React.createElement('div', {
    ref: anchorRef,
    'data-research-kit': 'draft-enhancer-trigger',
    'data-state': state,
    style: { display: 'flex', alignItems: 'center' },
  }, [
    React.createElement(GlobalStyle, { key: 'style' }),
    React.createElement(IconButton, {
      key: 'trigger',
      name: 'sparkles',
      label,
      active,
      onClick,
      onPointerDown: event => event.stopPropagation(),
      'aria-haspopup': 'dialog',
      'aria-expanded': Boolean(open),
      style: state === 'error' ? { borderColor: C.amber, color: C.amber } : undefined,
    }),
  ])
}

export function ResearchDraftEnhancerHost(props) {
  const [state, setState] = React.useState(() => promptKitReady() ? 'ready' : 'idle')
  const [errorText, setErrorText] = React.useState(null)
  const [open, setOpen] = React.useState(false)
  const [attempt, setAttempt] = React.useState(0)
  const anchorRef = React.useRef(null)
  // 入口形态：内联（默认，输入框图标钮）或悬浮（右下角可拖拽钮 + 沉淀伴生钮）。
  const mode = useEntryMode()
  const floating = mode === ENTRY_MODE_FLOATING
  // 工件尚未就绪时点过按钮：加载完成后替他展开面板，避免「点了没反应」。
  const pendingOpen = React.useRef(false)
  React.useEffect(() => {
    if (promptKitReady()) { setState('ready'); return undefined }
    if (!attempt) return undefined
    let active = true
    setState('loading')
    setErrorText(null)
    loadPromptKit().then(PromptKit => {
      ensureResearchProviders(PromptKit)
      recordPromptKitLoadError(null)
      if (active) setState('ready')
    }).catch(error => {
      recordPromptKitLoadError(error)
      if (!active) return
      // 失败不再静默收起：入口保留并显示可重试文案，原因同时写进 localStorage 与控制台。
      setErrorText(String(error?.message || error))
      setState('error')
    })
    return () => { active = false }
  }, [attempt])
  React.useEffect(() => {
    if (state !== 'ready' || !pendingOpen.current) return
    pendingOpen.current = false
    setOpen(true)
  }, [state])
  const onClick = React.useCallback(() => {
    if (state === 'error' || state === 'idle') { pendingOpen.current = true; setState('loading'); setAttempt(value => value + 1); return }
    if (state !== 'ready') { pendingOpen.current = true; return }
    setOpen(value => !value)
  }, [state])
  React.useEffect(() => {
    if (state === 'ready') return undefined
    const shortcut = event => { if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); onClick() } }
    window.addEventListener('keydown', shortcut)
    return () => window.removeEventListener('keydown', shortcut)
  }, [state, onClick])
  if (floating) {
    // 悬浮形态：伴生钮照旧并排渲染；工件就绪前由兜底悬浮钮交出加载/重试反馈。
    return React.createElement(React.Fragment, null, [
      React.createElement(ResearchDepositButton, { key: 'research-deposit-button' }),
      state === 'ready'
        ? React.createElement(LoadedResearchDraftEnhancerHost, {
          key: 'draft-enhancer-panel', ...props, floating: true, open, onOpenChange: setOpen,
        })
        : React.createElement(ResearchDraftEnhancerFallbackFab, {
          key: 'draft-enhancer-fallback', state, errorText, onClick,
        }),
    ])
  }
  return React.createElement(React.Fragment, null, [
    React.createElement(ResearchDraftEnhancerTrigger, {
      key: 'draft-enhancer-trigger', open, state, errorText, onClick, anchorRef,
    }),
    state === 'ready'
      ? React.createElement(LoadedResearchDraftEnhancerHost, {
        key: 'draft-enhancer-panel', ...props, anchorRef, open, onOpenChange: setOpen,
      })
      : null,
  ])
}

// 由 standalone-glue 统一注册为 conversation.input.right（顺序见 slot-registry.js）。
// 优先级低于模型选择器与发送按钮；不得截获普通 Enter（QuickEnhancer 内部只拦截自身面板按键）。
