export const MEMORY_SEARCH_PATH = '/dsh-research-kit/memory-search'
export const DEFAULT_MEMORY_SERVER = 'memory-center'
import { readConfigValue } from './config.js'
import { jsonReply as reply } from './lib/http-json.js'
// 返回文本上限：只取有界摘要供增强上下文与来源预览，不搬运全库。
const MAX_TEXT_CHARS = 4000
const EXEC_TIMEOUT_MS = 15_000
const MAX_SERVERS = 24
const MAX_QUERY_CHARS = 300
const MAX_REQUEST_BYTES = 32_768

// ── MCP 检索工具选择与参数合成（纯函数，单测覆盖）────────────────────────────
// Memory Center 以 MCP 服务器形式接入（工具名 `mcp__<server>__<tool>`）。
// 插件不预设它的私有契约：先按服务器挑工具，再按该工具自己的 JSON Schema 合成参数。

// 在目标服务器的工具里挑检索类入口：名字命中 search/lookup/query 的优先，
// 其次 recall/find；都没有则回落第一个工具并在 candidates 里给出全部选择，
// 让调用方（或用户配置）可以显式指定，绝不静默猜。
export function pickMemoryTool(schemas, server) {
  const list = Array.isArray(schemas) ? schemas : []
  const prefix = `mcp__${server}__`
  const candidates = []
  for (const schema of list) {
    const name = String(schema?.name || '')
    if (!name.startsWith(prefix)) continue
    candidates.push({ name, description: String(schema?.description || ''), parameters: schema?.parameters })
  }
  if (!candidates.length) return { tool: null, candidates: [] }
  const rank = re => candidates.find(candidate => re.test(candidate.name))
  const tool = rank(/search/i) || rank(/lookup/i) || rank(/query/i) || rank(/recall|find/i) || candidates[0]
  return { tool, candidates: candidates.map(candidate => candidate.name) }
}

// 这些必填 string 参数显然不是「检索词」本身（标识符/路径/模式类），填 query 是瞎猜，
// 宁可明确拒绝并在诊断里列出，也不打出去必失败的调用。
const NON_QUERY_KEY = /(id|path|file|key|name|type|kind|mode|action|format|lang|source|url|version)$/i

// 按工具声明的 JSON Schema 合成参数。原则：宁可拒绝执行，也不用猜的参数打 MCP——
//   - 名字像检索词的 string 属性（query/q/keyword/search）填 query；
//   - 名字像条数的 number 属性（limit/topK/k/n/max）填 limit；
//   - 其余 required：普通 string 填 query、number 填 limit、boolean 填 false；
//   - enum / object / array / 标识类 string 的 required 无法可靠填充 → 明确列出 missing。
export function buildMemoryToolArgs(parameters, { query, limit = 8 } = {}) {
  const schema = parameters && typeof parameters === 'object' ? parameters : {}
  const props = schema.properties && typeof schema.properties === 'object' ? schema.properties : {}
  const required = Array.isArray(schema.required) ? schema.required : []
  const args = {}
  const missing = []
  for (const key of Object.keys(props)) {
    const prop = props[key] && typeof props[key] === 'object' ? props[key] : {}
    const type = Array.isArray(prop.type) ? prop.type[0] : prop.type
    if (/query|^q$|keyword|search/i.test(key) && (type === 'string' || !type)) args[key] = query
    else if (/^(limit|top_?k|k|n|max)(_|$)/i.test(key) && (type === 'number' || type === 'integer')) args[key] = limit
  }
  for (const key of required) {
    if (args[key] !== undefined) continue
    const prop = props[key] && typeof props[key] === 'object' ? props[key] : {}
    const type = Array.isArray(prop.type) ? prop.type[0] : prop.type
    if (type === 'string' && !Array.isArray(prop.enum) && !NON_QUERY_KEY.test(key)) args[key] = query
    else if (type === 'number' || type === 'integer') args[key] = limit
    else if (type === 'boolean') args[key] = false
    else missing.push(key)
  }
  return missing.length ? { ok: false, missing, args } : { ok: true, args, missing }
}

// 从工具执行的返回里取有界文本（MCP 结果统一是 ContentBlock 数组）。
export function memoryTextOf(result) {
  const content = result?.content
  if (!Array.isArray(content)) return ''
  const text = content
    .filter(block => block?.type === 'text' && typeof block.text === 'string')
    .map(block => block.text)
    .join('\n')
  return text.length > MAX_TEXT_CHARS ? `${text.slice(0, MAX_TEXT_CHARS)}…（已截断）` : text
}

// ── 显式参数模板（escape hatch）──────────────────────────────────────────────
// 多动作门面工具（如 assistant_knowledge 的必填 action）无法从检索词合成全部参数。
// 调用方可显式提供 args 模板：字符串值中的 {query} / {limit} 占位符会被替换，
// 其余值原样传递。模板是调用方对工具契约的显式声明，不是路由的猜测。
export function applyArgsTemplate(template, { query, limit = 8 } = {}) {
  const q = String(query ?? '')
  const n = String(Number(limit) || 8)
  const walk = value => {
    if (typeof value === 'string') return value.replaceAll('{query}', q).replaceAll('{limit}', n)
    if (Array.isArray(value)) return value.map(walk)
    if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, walk(item)]))
    return value
  }
  return walk(template)
}

// 本路由的读体刻意不走共享 readJsonBody：它按字节累计（先判断再收块）、超限抛
// request_too_large 让 handler 回 413、解析失败按空对象降级而非报错——是另一份契约。
async function readRequestBody(req) {
  const chunks = []
  let size = 0
  for await (const chunk of req) {
    size += chunk.length
    if (size > MAX_REQUEST_BYTES) {
      // 对真实 Node 请求尽快停止继续接收；测试桩可能没有 destroy，故保持可选。
      try { req.destroy?.() } catch {}
      throw Object.assign(new Error('请求内容过大。'), { code: 'request_too_large' })
    }
    chunks.push(chunk)
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}') } catch { return {} }
}

let callCounter = 0

function parseServerOf(name) {
  const raw = String(name || '')
  if (!raw.startsWith('mcp__')) return null
  const rest = raw.slice(5)
  const sep = rest.lastIndexOf('__')
  if (sep <= 0 || sep >= rest.length - 2) return null
  return rest.slice(0, sep)
}

// 检索路由：POST { query, server?, tool?, limit? }。
// 返回 { ok, available, ... }：available=false 是「部署里没有可用的 Memory Center MCP」
// 或参数无法可靠合成，属于如实降级而非错误；available=true 时 text/sources 供增强器
// 预览与注入。安全边界：本路由只代为执行 `mcp__` 前缀的工具，绝不触碰原生工具。
export function memorySearchRoute({ tools, logger, timeoutMs = EXEC_TIMEOUT_MS, config } = {}) {
  return {
    kind: 'exact', path: MEMORY_SEARCH_PATH,
    async handler(req, res) {
      if (req.method !== 'POST') return reply(res, 405, { ok: false, error: 'method_not_allowed' })
      let body = {}
      try { body = await readRequestBody(req) } catch (error) {
        if (error?.code === 'request_too_large') return reply(res, 413, { ok: false, error: 'request_too_large', message: `请求内容不能超过 ${MAX_REQUEST_BYTES / 1024}KB。` })
        throw error
      }
      const query = String(body.query || '').trim()
      const explicitTool = String(body.tool || '').trim()
      const requestTimeoutMs = Math.max(1, Number(readConfigValue(config?.memoryTimeoutMs, readConfigValue(timeoutMs, EXEC_TIMEOUT_MS))) || EXEC_TIMEOUT_MS)
      const configuredServer = readConfigValue(config?.memoryServer, DEFAULT_MEMORY_SERVER)
      const server = String(body.server || (explicitTool ? parseServerOf(explicitTool) || '' : '') || configuredServer)
      const limit = Math.max(1, Math.min(Number(body.limit) || 8, 20))
      if (!query) return reply(res, 400, { ok: false, error: 'empty_query' })
      if (query.length > MAX_QUERY_CHARS) return reply(res, 400, { ok: false, error: 'query_too_long' })
      if (explicitTool && !explicitTool.startsWith('mcp__')) {
        return reply(res, 400, { ok: false, error: 'non_mcp_tool', message: '本路由只代为执行 MCP 工具（mcp__ 前缀）。' })
      }
      if (typeof tools?.execute !== 'function' || typeof tools?.schemas !== 'function') {
        return reply(res, 200, { ok: true, available: false, reason: 'tools-unavailable' })
      }
      let schemas = []
      try { schemas = tools.schemas() || [] } catch { schemas = [] }
      let tool = null
      let candidates = []
      if (explicitTool) {
        const found = schemas.find(schema => schema?.name === explicitTool)
        if (!found) return reply(res, 200, { ok: true, available: false, reason: 'tool-not-found', tool: explicitTool })
        if (parseServerOf(found.name) !== server) {
          return reply(res, 400, {
            ok: false,
            error: 'tool_server_mismatch',
            message: `工具 ${found.name} 属于 MCP 服务器 ${parseServerOf(found.name)}，与请求的 ${server} 不一致。`,
          })
        }
        tool = { name: found.name, description: found.description || '', parameters: found.parameters }
      } else {
        const picked = pickMemoryTool(schemas, server)
        tool = picked.tool
        candidates = picked.candidates
      }
      if (!tool) {
        return reply(res, 200, {
          ok: true, available: false, reason: 'server-not-found', server, candidates,
          servers: [...new Set(schemas.map(schema => parseServerOf(schema?.name)).filter(Boolean))].slice(0, MAX_SERVERS),
        })
      }
      // 参数来源二选一：请求带显式 args 模板（调用方声明契约，占位符替换）时优先；
      // 否则按工具自身 Schema 合成（合成不了如实拒绝，绝不猜）。
      let planned
      if (body.args !== undefined) {
        if (!body.args || typeof body.args !== 'object' || Array.isArray(body.args)) {
          return reply(res, 400, { ok: false, error: 'invalid_args_template' })
        }
        planned = { ok: true, args: applyArgsTemplate(body.args, { query, limit }) }
      } else {
        planned = buildMemoryToolArgs(tool.parameters, { query, limit })
      }
      if (!planned.ok) {
        return reply(res, 200, {
          ok: true, available: false, reason: 'args-unfillable', tool: tool.name,
          missing: planned.missing,
          message: `检索工具 ${tool.name} 的必填参数无法从检索词合成（${planned.missing.join('、')}）；请在请求里显式指定 server/tool 或提供 args 模板。`,
        })
      }
      const controller = new AbortController()
      let timeout
      try {
        const callId = `rk-memory-${Date.now()}-${++callCounter}`
        const execution = Promise.resolve(tools.execute({ callId, name: tool.name, arguments: planned.args, signal: controller.signal }))
        execution.catch(() => {})
        const timeoutPromise = new Promise((_, reject) => {
          timeout = setTimeout(() => {
            controller.abort()
            const error = new Error('Memory Center 检索超时，请稍后重试。')
            error.code = 'MEMORY_SEARCH_TIMEOUT'
            reject(error)
          }, requestTimeoutMs)
        })
        const result = await Promise.race([execution, timeoutPromise])
        const text = memoryTextOf(result)
        if (result?.isError) {
          return reply(res, 200, { ok: true, available: false, reason: 'tool-error', tool: tool.name, message: text || '检索工具返回错误。' })
        }
        if (!text.trim()) {
          return reply(res, 200, { ok: true, available: true, server, tool: tool.name, text: '', sources: [], message: '检索无结果。' })
        }
        try { logger?.info?.(`memory search via ${tool.name} query=${query.length} chars`) } catch {}
        return reply(res, 200, {
          ok: true, available: true, server, tool: tool.name, text,
          sources: [{ kind: 'memory', label: `Memory Center · ${server}/${tool.name}` }],
        })
      } catch (error) {
        const message = controller.signal.aborted || error?.code === 'MEMORY_SEARCH_TIMEOUT'
          ? 'Memory Center 检索超时，请稍后重试。'
          : `Memory Center 检索失败：${error?.message || error}`
        return reply(res, 200, { ok: true, available: false, reason: 'execute-failed', tool: tool.name, message })
      } finally {
        clearTimeout(timeout)
      }
    },
  }
}
