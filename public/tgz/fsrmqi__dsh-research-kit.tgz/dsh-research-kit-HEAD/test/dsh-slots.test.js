import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { RESEARCH_SLOTS, registerResearchSlots } from '../dsh/slot-registry.js'

// slot 注册表是纯数据模块（无 React 依赖），测试直接调用注册动作验证完整注册序列；
// 生成产物另做包含性检查，确认构建器把新模块拼进了 ui/client.js。
test('DSH 客户端注册唯一视图、输入框入口、浮层与草稿增强器', () => {
  const registrations = []
  const dispose = registerResearchSlots(
    {
      slots: {
        inject(_slot, callback) { return callback() },
        register(options, component) { registrations.push({ options, component }); return () => {} }
      }
    },
    RESEARCH_SLOTS.map(() => function PlaceholderComponent() {})
  )
  assert.equal(typeof dispose, 'function')
  assert.deepEqual(registrations.map(row => row.options.name), [
    'conversation.view',
    'conversation.input.left',
    'conversation.input.overlay',
    'conversation.input.right'
  ])
  // 三个并列视图已合并为单一容器视图；分区改由容器内部的二级导航承载。
  assert.deepEqual(registrations.filter(row => row.options.name === 'conversation.view').map(row => row.options.id), [
    'dsh-research-kit-console'
  ])
  assert.deepEqual(registrations.filter(row => row.options.name === 'conversation.input.right').map(row => row.options.id), [
    'dsh-research-kit-draft-enhancer'
  ])
  assert.ok(registrations.every(row => typeof row.component === 'function'))
  // 草稿增强器优先级必须低于发送按钮等宿主控件（order 越小越靠后/越次要）。
  const enhancer = RESEARCH_SLOTS.find(row => row.id === 'dsh-research-kit-draft-enhancer')
  assert.equal(enhancer.order, 80)
  assert.equal(RESEARCH_SLOTS.length, 4)
})

test('生成产物包含新模块并使用 research-kit 命名空间', () => {
  const source = readFileSync(new URL('../ui/client.js', import.meta.url), 'utf8')
  assert.match(source, /dsh-research-kit-draft-enhancer/)
  assert.match(source, /dsh-research-kit-console/)
  assert.match(source, /dsh-research-kit\/semantic-enhance/)
  // 合并后的分区契约与四个分区的实现都必须拼入产物。
  assert.match(source, /RESEARCH_CONSOLE_SECTIONS/)
  assert.match(source, /function ResearchConsole\(/)
  assert.match(source, /function ResearchWorkbench\(/)
  assert.match(source, /function ResearchVault\(/)
  assert.match(source, /function ResearchEvidenceGraph\(/)
  assert.match(source, /function ResearchPromptStudioHost\(/)
  // 不得出现 PromptKit 独立仓库的路径或默认 storage 前缀泄漏。
  assert.ok(!source.includes('/dsh-promptkit/semantic-enhance'), '浏览器端不得回退到 PromptKit 独立插件路由')
  assert.ok(!source.includes("storagePrefix: 'promptkit.'"), '不得使用 PromptKit 默认 storage 前缀')
})

test('内联草稿增强入口：触发钮不依赖懒加载工件，面板走受控 inline 接线', () => {
  const glue = readFileSync(new URL('../dsh/prompt-enhancer-glue.js', import.meta.url), 'utf8')
  // 触发钮必须由插件自绘、且先于 ready 分支渲染：App 里 /promptkit-client 路由挂起时
  // 脚本 load/error 都不触发，若入口挂在 ready 分支上，整块槽位就会静默消失（本次回归根因）。
  assert.match(glue, /export function ResearchDraftEnhancerTrigger/)
  assert.match(glue, /React\.createElement\(ResearchDraftEnhancerTrigger, \{/)
  const host = glue.slice(glue.indexOf('function ResearchDraftEnhancerHost'))
  // 入口形态二选一：内联分支里触发钮必须先于 ready 分支渲染（否则工件挂起/失败时整块静默消失）。
  assert.match(host, /const mode = useEntryMode\(\)/)
  assert.match(host, /const floating = mode === ENTRY_MODE_FLOATING/)
  const inlineBranch = host.slice(host.lastIndexOf('return React.createElement(React.Fragment, null, ['))
  const triggerAt = inlineBranch.indexOf('ResearchDraftEnhancerTrigger')
  const readyAt = inlineBranch.indexOf("state === 'ready'")
  assert.ok(triggerAt >= 0 && readyAt > triggerAt,
    '内联分支里触发钮必须先于 ready 条件渲染（工件挂起/失败时入口仍在，并可点击重试）')
  // 工件侧：内联入口 + 宿主自绘触发钮 + 受控开合 + 锚定插件按钮。
  assert.match(glue, /launcher: 'inline'/)
  assert.match(glue, /renderLauncher: \(\) => null/)
  assert.match(glue, /anchorRef,/)
  assert.match(glue, /onOpenChange,/)
  // 加载器：路由既不回包也不报错时必须超时成「可重试的失败」，不能永远加载中。
  const loader = readFileSync(new URL('../src/promptkit-loader.js', import.meta.url), 'utf8')
  assert.match(loader, /export const PROMPTKIT_LOAD_TIMEOUT_MS = \d+/)
  assert.match(loader, /window\.setTimeout\(/)
  assert.match(loader, /promptKitPromise = null/, '失败必须清掉单例，允许重试')
  // 构建产物必须带上同一套接线。
  const bundle = readFileSync(new URL('../ui/client.js', import.meta.url), 'utf8')
  assert.match(bundle, /launcher: 'inline'/)
  assert.match(bundle, /PROMPTKIT_LOAD_TIMEOUT_MS/)
  assert.match(bundle, /ENTRY_MODE_INLINE|'inline'/)
})

test('新版 DSH 工具详情卡覆盖全部 research MCP 工具', async () => {
  const { researchToolNames, researchToolDetailModel, researchToolArgumentSummary } = await import('../src/research-toolview.js')
  const glue = readFileSync(new URL('../dsh/standalone-glue.js', import.meta.url), 'utf8')
  assert.ok(researchToolNames.length >= 30)
  assert.ok(researchToolNames.every(name => name.startsWith('mcp__dsh-research-kit__research_')))
  assert.match(glue, /slots\.inject\('tool\.call\.toolview',[\s\S]*?researchToolNames\.map\(key => ctx\.slots\.register\(\{ name: 'tool\.call\.toolview', key \}, ResearchToolView\)\)/)
  const model = researchToolDetailModel('mcp__dsh-research-kit__research_literature_search', { kind: 'tool-result', content: [{ type: 'text', text: JSON.stringify({ data: { sources: [{ title: '可追溯来源', doi: '10.1000/example', source_id: 'crossref', url: 'https://doi.org/10.1000/example', verification: { status: 'verified' }, suggested_grade: 'empirical' }] } }) }] })
  assert.deepEqual(model.evidence[0], { title: '可追溯来源', doi: '10.1000/example', source: 'crossref', url: 'https://doi.org/10.1000/example', grades: [{ label: '建议等级', value: '实证' }], verification: 'verified' })
  assert.ok(model.pending.length === 0)
  const recorded = researchToolDetailModel('mcp__dsh-research-kit__research_evidence_list', { content: [{ type: 'text', text: JSON.stringify({ data: { entries: [{ title: '已入库', stored_grade: 'ungraded', suggested_grade: 'inference' }] } }) }] })
  assert.deepEqual(recorded.evidence[0].grades, [{ label: '已记录等级', value: '未分级' }, { label: '建议等级', value: '推论' }])
  assert.ok(researchToolDetailModel('mcp__dsh-research-kit__research_evidence_grade_apply', { content: [{ type: 'text', text: JSON.stringify({ data: { apply: false } }) }] }).pending.some(item => item.includes('人工确认')))
  assert.match(researchToolArgumentSummary('{"query":"BRCA1","project":"测试"}'), /检索词：BRCA1 · 项目：测试/)
  assert.match(researchToolArgumentSummary('{"query":"BR'), /正在接收参数/)
})

test('科研增强只替换选区，版本过期和引用坐标不安全时拒绝写入', async () => {
  const { ResearchDraftComposer } = await import('../dsh/prompt-enhancer-glue.js')
  let draft = '前文 需要增强 后文'
  let rev = 4
  const actions = {
    captureInsertion: () => ({ start: 3, end: 7, draftRev: rev }),
    insertText: (text, span) => {
      if (span.draftRev !== rev) return false
      draft = `${draft.slice(0, span.start)}${text}${draft.slice(span.end)}`
      rev++
      return true
    },
    setDraft: text => { draft = text },
  }
  const composer = new ResearchDraftComposer({ draft, occurrences: [] }, actions)
  const selection = composer.getSelection()
  assert.equal(selection.text, '需要增强')
  composer.replaceSelection('已增强', selection)
  assert.equal(draft, '前文 已增强 后文')
  assert.throws(() => composer.replaceSelection('误覆盖', selection), /已变化/)
  const withReference = new ResearchDraftComposer({ draft: '引用 @x', occurrences: [{ id: 'x' }] }, actions)
  assert.throws(() => withReference.getSelection(), /包含引用/)
})
