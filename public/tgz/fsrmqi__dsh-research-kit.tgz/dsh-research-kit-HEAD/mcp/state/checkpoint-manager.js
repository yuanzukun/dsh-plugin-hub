
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import path from 'node:path'
import { dataPath } from '../paths.js'
import { acquireFileLock, releaseFileLock } from '../execution/file-lock.js'

const CHECKPOINT_DIR = dataPath('checkpoints')
// 与 Material Passport 的 run_id 契约一致：允许点号，拒绝路径分隔符。
const ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,119}$/
const LOCK_TIMEOUT_MS = 5_000
const LOCK_STALE_MS = 10_000

function assertId(value, label) {
  if (!ID_PATTERN.test(String(value || ''))) throw new Error(`${label} 不合法。`)
}

function stateFile(runId) {
  assertId(runId, 'run_id')
  return path.join(CHECKPOINT_DIR, `${runId}.json`)
}

function lockFile(runId) {
  assertId(runId, 'run_id')
  return path.join(CHECKPOINT_DIR, `${runId}.lock`)
}

async function acquireLock(runId) {
  return acquireFileLock(lockFile(runId), {
    timeoutMs: LOCK_TIMEOUT_MS,
    staleMs: LOCK_STALE_MS,
    emptyGraceMs: 2_000,
    busyMessage: '检查点状态正被其他进程写入，请稍后重试。',
  })
}

async function withRunLock(runId, run) {
  const handle = await acquireLock(runId)
  try { return await run() }
  finally { await releaseFileLock(lockFile(runId), handle) }
}

function emptyState(runId) {
  return { run_id: runId, checkpoints: {}, created_at: new Date().toISOString() }
}

function corruptStateError(runId, detail, cause) {
  const error = new Error(
    `检查点状态已损坏（run ${runId}）：${detail}。为避免人工闸门被绕过，拒绝读写；` +
    `请检查或重建 ${stateFile(runId)}。`,
  )
  error.code = 'CHECKPOINT_STATE_CORRUPT'
  error.cause = cause
  return error
}

async function loadState(runId) {
  const file = stateFile(runId)
  if (!existsSync(file)) return emptyState(runId)
  const raw = await readFile(file, 'utf8')
  let state
  try {
    state = JSON.parse(raw)
  } catch (cause) {
    throw corruptStateError(runId, 'JSON 无法解析', cause)
  }
  if (!state || typeof state !== 'object' || Array.isArray(state)) {
    throw corruptStateError(runId, '顶层不是对象')
  }
  if (state.run_id !== runId) {
    throw corruptStateError(runId, `run_id 不匹配（文件里是 ${JSON.stringify(state.run_id)}）`)
  }
  return { ...emptyState(runId), ...state, checkpoints: state.checkpoints || {} }
}

async function saveState(state) {
  await mkdir(CHECKPOINT_DIR, { recursive: true })
  const target = stateFile(state.run_id)
  const temp = `${target}.${process.pid}.${Date.now().toString(36)}.tmp`
  await writeFile(temp, JSON.stringify(state, null, 2), 'utf8')
  await rename(temp, target)
}

function describeState(state) {
  const entries = Object.entries(state.checkpoints)
  return {
    run_id: state.run_id,
    checkpoints: state.checkpoints,
    pending: entries.filter(([, value]) => !value.approved).map(([stage]) => stage),
    approved: entries.filter(([, value]) => value.approved).map(([stage]) => stage),
  }
}

function evaluateCheckpoints(workflow, completedStages = []) {
  const checkpoints = Array.isArray(workflow?.checkpoints) ? workflow.checkpoints : []
  const completed = new Set(completedStages.map(String))
  const pending = checkpoints.filter(checkpoint =>
    checkpoint?.required !== false && completed.has(String(checkpoint.after_stage))
  )
  return {
    should_pause: pending.length > 0,
    pending_checkpoints: pending.map(checkpoint => ({
      after_stage: String(checkpoint.after_stage),
      action: checkpoint.action || 'human_review',
      required: checkpoint.required !== false,
    })),
  }
}

async function initializeCheckpoints(runId, workflow, completedStages = []) {
  assertId(runId, 'run_id')
  return withRunLock(runId, async () => {
    const state = await loadState(runId)
    const { pending_checkpoints } = evaluateCheckpoints(workflow, completedStages)
    for (const checkpoint of pending_checkpoints) {
      if (!state.checkpoints[checkpoint.after_stage]) {
        state.checkpoints[checkpoint.after_stage] = {
          approved: false,
          action: checkpoint.action,
          required: checkpoint.required,
          created_at: new Date().toISOString(),
        }
      }
    }
    state.updated_at = new Date().toISOString()
    await saveState(state)
    return describeState(state)
  })
}

async function recordApproval(runId, stage, { approved_by = 'user', note, evidence_ids, validation_summary } = {}) {
  assertId(runId, 'run_id')
  assertId(stage, 'stage')
  return withRunLock(runId, async () => {
    const state = await loadState(runId)
    const checkpoint = state.checkpoints[stage]
    if (!checkpoint) {
      const error = new Error(`检查点 "${stage}" 不存在于运行 "${runId}"。`)
      error.code = 'CHECKPOINT_NOT_FOUND'
      throw error
    }
    const evidenceIds = [...new Set((Array.isArray(evidence_ids) ? evidence_ids : [])
      .map(String).map(value => value.trim()).filter(Boolean).slice(0, 30))]
    const summary = String(validation_summary || '').trim().slice(0, 500)
    const receipt = evidenceIds.length || summary
      ? {
          schema_version: 1,
          receipt_id: `research-checkpoint:${runId}:${stage}:${Date.now().toString(36)}`,
          status: 'approved',
          evidence_ids: evidenceIds,
          validation_summary: summary,
          approved_by: String(approved_by || 'user').slice(0, 80),
          recorded_at: new Date().toISOString(),
        }
      : undefined
    state.checkpoints[stage] = {
      ...checkpoint,
      approved: true,
      approved_by: String(approved_by || 'user').slice(0, 80),
      note: String(note || '').slice(0, 500),
      approved_at: new Date().toISOString(),
      ...(receipt ? { validation_receipt: receipt } : {}),
    }
    state.updated_at = new Date().toISOString()
    await saveState(state)
    return { approved: true, stage, run_id: runId, ...(receipt ? { validation_receipt: receipt } : {}) }
  })
}

async function getCheckpointState(runId) {
  assertId(runId, 'run_id')
  return describeState(await loadState(runId))
}

export { evaluateCheckpoints, initializeCheckpoints, recordApproval, getCheckpointState }
