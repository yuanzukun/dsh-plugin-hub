// 目录数据只经三个聚合入口进入（分片见 catalog/*/index.js）；对外 API 与文件拆分解耦。
import workflows from '../catalog/workflows/index.js'
import skills from '../catalog/skills/index.js'
import { resources, databaseMetadataConfig } from '../catalog/resources/index.js'

// 数据库的研究用途、访问方式与引用规范。原始目录仍保留上游类别；这里提供面向
// 研究者的六个入口组，避免把遗传、临床、化学等都笼统归入“数据分析”。
export const CATALOG_DATA_PATH = '/dsh-research-kit/catalog-data'
export const CATALOG_ITEM_PATH = '/dsh-research-kit/catalog-item'
export const CATALOG_SEARCH_PATH = '/dsh-research-kit/catalog-search'

let workflowEntries = workflows
let skillEntries = skills
let resourceEntries = resources
let databaseConfig = databaseMetadataConfig
let catalogMode = 'full'
let DATABASE_GROUPS = databaseConfig.groups
let RESTRICTED_DATABASE_ACCESS = new Map(Object.entries(databaseConfig.accessOverrides))
let catalogIndex = new Map()
let catalogSearchIndex = new Map()
let catalogLoadPromise = null
const detailLoadPromises = new Map()
const catalogListeners = new Set()

const WORKFLOW_RECOMMENDATIONS = {
  '文献与引文': ['literature-search', 'literature-review', 'citation-analysis'],
  '临床与公共卫生': ['patient-cohort-study', 'case-control-analysis', 'risk-prediction-model'],
  '基因组与遗传变异': ['variant-annotation', 'variant-calling', 'gwas-analysis'],
  '组学与表达数据': ['rnaseq-deseq2', 'single-cell-rnaseq', 'gene-expression-atlas'],
  '蛋白质、结构与通路': ['gene-set-enrichment', 'gene-regulatory-network', 'methods-comparison'],
  '化学、药物与毒理': ['data-source-selection', 'research-plan', 'methods-comparison'],
  '天文与空间科学': ['data-source-selection', 'research-landscape', 'explore-data'],
  '生物多样性与生态': ['find-datasets', 'research-plan', 'explore-data'],
  '气候、地球与环境': ['find-datasets', 'explore-data', 'statistical-analysis'],
  '地理空间与社会数据': ['data-source-selection', 'find-datasets', 'explore-data']
}

export function databaseMetadata(databaseOrId) {
  const id = typeof databaseOrId === 'string' ? databaseOrId : databaseOrId?.id
  const record = DATABASE_GROUPS.find(group => group.ids.includes(id))
  const database = typeof databaseOrId === 'object' ? databaseOrId : catalogIndex.get(id)
  return {
    group: record?.group || '其他研究数据源',
    dataKind: record?.dataKind || '研究数据与元数据',
    queryExample: record?.queryExample || '按研究问题和稳定标识符查询，并记录检索范围。',
    citationRule: record?.citationRule || '记录数据库名称、稳定标识符、版本和访问日期。',
    accessMode: RESTRICTED_DATABASE_ACCESS.get(id) || '公开网页或 API；当前会话仍需 Web 或 MCP 能力',
    toolHint: database?.availability === 'available-in-plugin'
      ? '本插件已内置该来源的直查适配器，可直接查询；候选结果仍应回到原文逐条核验。'
      : database?.availability === 'available-in-host'
        ? '当前宿主已声明可用；仍应在结果中说明来源。'
        : '在 DSH 当前会话通过 Web 或已连接 MCP 查询；未接通时只能作为检索建议。'
  }
}

/** 根据本会话勾选的数据库给出可启动的工作流，不代表自动执行或结果推荐。 */
export function recommendedWorkflowsForResources(resourceIds = []) {
  const workflowIds = new Set()
  for (const id of resourceIds) {
    const item = catalogIndex.get(id)
    if (!item) continue
    for (const workflowId of WORKFLOW_RECOMMENDATIONS[databaseMetadata(item).group] || []) workflowIds.add(workflowId)
  }
  return [...workflowIds].map(id => catalogIndex.get(id)).filter(item => item?.type === 'workflow')
}

const PRESET_WORKFLOW_RECOMMENDATIONS = {
  general: {
    categories: ['研究设计', '论文与手稿', '文献研究'],
    workflowIds: ['literature-review', 'analysis-plan', 'review-paper', 'compare-papers'],
  },
  literature: {
    categories: ['文献研究', '论文与手稿'],
    workflowIds: ['literature-search', 'literature-review', 'compare-papers', 'review-paper', 'reference-check'],
  },
  bioinformatics: {
    categories: ['生物信息学', '基因组学'],
    workflowIds: ['rnaseq-deseq2', 'single-cell-rnaseq', 'variant-calling', 'bioinformatics-qc-pipeline', 'pathway-enrichment-execution'],
  },
  cropBreeding: {
    categories: ['作物遗传育种'],
    workflowIds: ['crop-gwas-breeding', 'crop-multi-environment-trial', 'crop-qtl-validation', 'crop-phenotype-qc', 'genomic-selection-plan'],
  },
  clinical: {
    categories: ['临床研究'],
    workflowIds: ['patient-cohort-study', 'case-control-analysis', 'risk-prediction-model', 'diagnostic-accuracy', 'longitudinal-study'],
  },
  dataVisualization: {
    categories: ['数据分析', '可视化与图表'],
    workflowIds: ['explore-data', 'clean-data', 'analysis-plan', 'statistical-analysis', 'figure-audit'],
  },
}

/**
 * 主工作台独立推荐区计算：复用已选资源推荐，并按当前领域预设排优先级；
 * 不改变全目录搜索和分类筛选语义。
 */
export function recommendedWorkflowsForWorkbench({ resourceIds = [], presetKey = null, limit = 6 } = {}) {
  const fromResources = recommendedWorkflowsForResources(resourceIds)
  const preset = presetKey ? PRESET_WORKFLOW_RECOMMENDATIONS[presetKey] || null : null
  if (!fromResources.length && !preset) return []

  const presetIdSet = new Set(preset?.workflowIds || [])
  const presetCategorySet = new Set(preset?.categories || [])
  const matchesPreset = item => presetIdSet.has(item.id) || presetCategorySet.has(item.category)

  const seen = new Set()
  const ranked = []
  const push = (item, reason) => {
    if (!item || item.type !== 'workflow' || seen.has(item.id)) return
    seen.add(item.id)
    ranked.push({ item, reason })
  }

  if (preset) {
    for (const item of fromResources) if (matchesPreset(item)) push(item, '匹配领域预设与已选资源')
  }
  for (const item of fromResources) push(item, '匹配已选资源')
  if (preset) {
    for (const id of preset.workflowIds) push(catalogIndex.get(id), '匹配领域预设')
  }
  return ranked.slice(0, limit)
}

function enrichItem(item) {
  const normalized = Array.isArray(item.tags) && item.tags.length ? item : { ...item, tags: [item.category || '科研'] }
  return normalized.type === 'database' ? { ...normalized, databaseMeta: databaseMetadata(normalized) } : normalized
}

// 目录保留多学科能力，避免用户后续需要时丢失既有工作流；
// 新增与默认推荐则优先服务作物遗传育种、生物信息学、基因组与论文科研链路。
function rebuildCatalog() {
  DATABASE_GROUPS = Array.isArray(databaseConfig.groups) ? databaseConfig.groups : []
  RESTRICTED_DATABASE_ACCESS = new Map(Object.entries(databaseConfig.accessOverrides || {}))
  catalog = Object.freeze([...workflowEntries, ...skillEntries, ...resourceEntries].map(enrichItem))
  catalogIndex = new Map(catalog.map(item => [item.id, item]))
  catalogSearchIndex = new Map(catalog.map(item => [item.id, [
    item.name, (item.tags || []).join(' '), item.description,
    [item.category, item.databaseMeta?.group, item.databaseMeta?.dataKind].filter(Boolean).join(' '),
    [item.prompt, item.guidance, item.promptFragment, item.databaseMeta?.queryExample].filter(Boolean).join(' '),
  ].map(value => String(value || '').toLowerCase())]))
}

export let catalog = []
rebuildCatalog()

export function catalogReady() {
  return catalog.length > 0
}

export function catalogIndexMode() {
  return catalogMode === 'index'
}

export function itemDetailReady(item) {
  if (!item) return false
  if (item.type === 'workflow') return typeof item.prompt === 'string' && item.prompt.length > 0
  if (item.type === 'skill') return typeof item.guidance === 'string' && item.guidance.length > 0
  return true
}

export function subscribeCatalog(listener) {
  catalogListeners.add(listener)
  return () => catalogListeners.delete(listener)
}

function notifyCatalogListeners() {
  for (const listener of catalogListeners) { try { listener(catalog) } catch { /* 单个监听失败不影响目录就绪 */ } }
}

export function applyCatalogData(data = {}) {
  if (!Array.isArray(data.workflows) || !Array.isArray(data.skills) || !Array.isArray(data.resources)) {
    throw new Error('目录数据格式无效。')
  }
  workflowEntries = data.workflows
  skillEntries = data.skills
  resourceEntries = data.resources
  databaseConfig = data.databaseMetadataConfig || { groups: [], accessOverrides: {} }
  catalogMode = data.mode === 'index' ? 'index' : 'full'
  detailLoadPromises.clear()
  rebuildCatalog()
  notifyCatalogListeners()
  return catalog
}

export function mergeCatalogItemDetail(detail) {
  if (!detail?.id || !detail?.type) return null
  const replace = list => {
    const index = list.findIndex(entry => entry.id === detail.id)
    return index >= 0 ? list.map((entry, at) => (at === index ? detail : entry)) : [...list, detail]
  }
  if (detail.type === 'workflow') workflowEntries = replace(workflowEntries)
  else if (detail.type === 'skill') skillEntries = replace(skillEntries)
  else if (detail.type === 'database') resourceEntries = replace(resourceEntries)
  else return null
  rebuildCatalog()
  notifyCatalogListeners()
  return catalogIndex.get(detail.id) || null
}

// 源码/Node 入口直接使用静态目录；浏览器轻量产物以空数组启动，首次挂载时才拉取轻量索引 JSON。
// 同一个 Promise 被所有视图复用，避免控制台、输入框浮层和增强器并发重复请求。
export function loadBrowserCatalog(fetcher = globalThis.fetch) {
  if (catalogReady()) return Promise.resolve(catalog)
  if (catalogLoadPromise) return catalogLoadPromise
  if (typeof fetcher !== 'function') return Promise.reject(new Error('当前环境无法加载科研目录。'))
  catalogLoadPromise = fetcher(CATALOG_DATA_PATH, { headers: { accept: 'application/json' } })
    .then(response => {
      if (!response.ok) throw new Error(`科研目录加载失败（HTTP ${response.status}）`)
      return response.json()
    })
    .then(payload => applyCatalogData(payload?.data || payload))
    .catch(error => { catalogLoadPromise = null; throw error })
  return catalogLoadPromise
}

// 按需拉取单条完整目录详情（工作流 Prompt/placeholders、技能 guidance/checklist）；
// 同 id 并发请求共享一个 Promise，失败后清空占位以支持重试。
export function loadCatalogItemDetail(id, fetcher = globalThis.fetch) {
  const key = String(id || '').trim()
  if (!key) return Promise.resolve(null)
  const existing = catalogIndex.get(key)
  if (existing && itemDetailReady(existing)) return Promise.resolve(existing)
  if (detailLoadPromises.has(key)) return detailLoadPromises.get(key)
  if (typeof fetcher !== 'function') return Promise.reject(new Error('当前环境无法加载资源详情。'))
  const promise = fetcher(`${CATALOG_ITEM_PATH}?id=${encodeURIComponent(key)}`, { headers: { accept: 'application/json' } })
    .then(response => {
      if (!response.ok) throw new Error(`资源详情加载失败（HTTP ${response.status}）`)
      return response.json()
    })
    .then(payload => {
      const item = payload?.item || payload?.data
      if (!item?.id) throw new Error('资源详情格式无效。')
      return mergeCatalogItemDetail(item)
    })
    .finally(() => { detailLoadPromises.delete(key) })
  detailLoadPromises.set(key, promise)
  return promise
}

// Node 侧完整目录全文检索：在浏览器仅持有轻量索引时补齐 Prompt / 技能正文 / 示例检索命中。
export function searchCatalogRemote({ query = '', type = 'all' } = {}, { fetcher = globalThis.fetch, signal } = {}) {
  const normalized = String(query || '').trim()
  if (!normalized || typeof fetcher !== 'function') return Promise.resolve([])
  const url = `${CATALOG_SEARCH_PATH}?q=${encodeURIComponent(normalized)}&type=${encodeURIComponent(type || 'all')}`
  return fetcher(url, { headers: { accept: 'application/json' }, signal })
    .then(response => {
      if (!response.ok) throw new Error(`全文检索失败（HTTP ${response.status}）`)
      return response.json()
    })
    .then(payload => (Array.isArray(payload?.results) ? payload.results : []))
}

const CATALOG_SYNONYMS = [
  ['rnaseq', 'rna-seq', 'rna seq', '转录组'],
  ['gwas', '全基因组关联'],
  ['literature review', '文献综述'],
  ['systematic review', '系统综述', '系统文献综述'],
]

export function catalogMatch(item, query = '') {
  const normalized = String(query).trim().toLowerCase()
  if (!normalized) return { score: 0, reason: '', term: '' }
  const terms = CATALOG_SYNONYMS.find(group => group.includes(normalized)) || [normalized]
  const fields = catalogSearchIndex.get(item.id) || []
  let best = { score: 0, reason: '', term: '' }
  for (const term of terms) for (let index = 0; index < fields.length; index++) {
    if (!fields[index].includes(term)) continue
    const score = [80, 60, 40, 30, 10][index] + (index === 0 && fields[index] === term ? 20 : index === 0 && fields[index].startsWith(term) ? 10 : 0)
    if (score > best.score) best = { score, reason: ['名称', '标签', '描述', '分类', '正文'][index] + '匹配', term }
  }
  return best
}

export function searchCatalog({ query = '', type = 'all', remoteMatches = null } = {}) {
  const normalized = String(query).trim().toLowerCase()
  const rows = catalog.filter(item => type === 'all' || item.type === type)
  if (!normalized) return rows
  return rows.map((item, order) => {
    const local = catalogMatch(item, normalized)
    const remote = remoteMatches?.get?.(item.id)
    const match = remote && remote.score > local.score ? remote : local
    return { item, order, match }
  })
    .filter(row => row.match.score > 0)
    .sort((a, b) => b.match.score - a.match.score || a.order - b.order)
    .map(row => row.item)
}

export function itemById(id) {
  return catalogIndex.get(id) || null
}

/** 从当前筛选结果中恢复选中项，绝不返回已被筛掉的历史选择。 */
export function selectedCatalogItem(items, selectedId) {
  return items.find(item => item.id === selectedId) || items[0] || null
}

export function composeWorkflow(workflow, values = {}, { enforceRequired = true, extraSkillIds = [], extraDatabaseIds = [] } = {}) {
  if (!workflow || workflow.type !== 'workflow') throw new Error('请选择一个工作流程。')
  const missing = (workflow.placeholders || [])
    .filter(field => field.required && !String(values[field.key] || '').trim())
    .map(field => field.label)
  if (enforceRequired && missing.length) throw new Error(`请填写：${missing.join('、')}`)
  const prompt = workflow.prompt.replace(/\{([a-zA-Z0-9_-]+)\}/g, (_, key) => {
    const value = String(values[key] || '').trim()
    const field = workflow.placeholders?.find(item => item.key === key)
    return value || (field?.required ? `[${field.label}]` : '未指定（请按综合方式处理）')
  })
  // 附加技能是可选的指导模块：勾选后把该技能的纪律片段追加到 Prompt 末尾。
  const attached = (extraSkillIds || [])
    .map(itemById)
    .filter(skill => skill?.type === 'skill' && skill.promptFragment)
  const attachedDatabases = (extraDatabaseIds || [])
    .map(itemById)
    .filter(database => database?.type === 'database')
  const additions = [
    attached.length ? `附加技能指导：\n${attached.map(skill => `- 【${skill.name}】${skill.promptFragment}`).join('\n')}` : '',
    attachedDatabases.length ? `研究资源提示：\n${attachedDatabases.map(database => `- 【${database.name}】${database.accessNote}；未确认当前会话具备访问能力前，不得声称已检索。`).join('\n')}` : ''
  ].filter(Boolean)
  const guardedPrompt = `${prompt}\n\n通用科研边界：仅基于已提供材料或已核验来源；不得编造数据、图表、引用、结果、完成状态或文件路径；无法确认时明确标记为待核验。`
  const finalPrompt = additions.length ? `${guardedPrompt}\n\n${additions.join('\n\n')}` : guardedPrompt
  // 组装回放轨迹（增量字段，消费方见 src/route-replay.js）：只记录已发生的组装事实，
  // 每一条都必须能在 finalPrompt 文本中找到对应内容——回放与文本互证由测试强制。
  const firstSentence = text => String(text || '').split(/[。；;]/)[0].slice(0, 40)
  const trace = [
    { step: 'workflow', id: workflow.id, label: workflow.name, detail: workflow.description || '' },
    ...(workflow.placeholders || []).map(field => {
      const value = String(values[field.key] || '').trim()
      return {
        step: 'param', id: field.key, label: field.label,
        detail: value || (field.required ? `[${field.label}]` : '未指定（请按综合方式处理）'),
        empty: !value,
      }
    }),
    ...attached.map(skill => ({ step: 'skill', id: skill.id, label: skill.name, detail: firstSentence(skill.promptFragment) })),
    ...attachedDatabases.map(database => ({ step: 'database', id: database.id, label: database.name, detail: firstSentence(database.accessNote) })),
    { step: 'guard', id: 'generic-guard', label: '科研边界', detail: '不得编造；无法确认时标记为待核验' },
  ]
  return {
    prompt: finalPrompt,
    missing,
    attachedSkillIds: attached.map(skill => skill.id),
    attachedDatabaseIds: attachedDatabases.map(database => database.id),
    trace,
  }
}
