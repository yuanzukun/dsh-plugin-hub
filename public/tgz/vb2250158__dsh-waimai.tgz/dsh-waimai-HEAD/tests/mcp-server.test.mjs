/**
 * Integration test for the takeaway MCP server.
 *
 * Starts the real server over stdio and inspects its advertised tools. This
 * checks process startup, tool registration and account-scoped payment inputs.
 * Payment requests require an owned order, a prepared reference and confirmed cents.
 *
 * The test never launches a browser: `tools/list` is answered before any tool
 * call, so no window opens and no page is loaded.
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { Client } from '@modelcontextprotocol/sdk/client/index.js'
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js'

const SERVER_ENTRY = join(dirname(fileURLToPath(import.meta.url)), '..', 'lib', 'mcp-server.js')

/** Tools the server must advertise, in the order the model sees them. */
const EXPECTED_TOOLS = [
  'login_status',
  'login_send_code',
  'login_complete',
  'login_qr_start',
  'login_qr_poll',
  'login_qr_cancel',
  'account_profile',
  'account_orders',
  'platform_list',
  'account_addresses',
  'account_select_address',
  'account_recent_shops',
  'account_nearby_shops',
  'account_probe_menu',
  'account_cross_search',
  'account_cross_search_page',
  'account_product_detail',
  'account_cart_add',
  'account_retail_search',
  'account_retail_resolve_search',
  'account_retail_cart',
  'account_retail_add',
  'account_retail_checkout',
  'account_item_options',
  'account_cart',
  'account_cart_change',
  'account_checkout',
  'account_select_delivery',
  'account_submit',
  'account_trade_history',
  'account_payment_status',
  'account_payment_preferences',
  'account_payment_login',
  'account_payment_provider_receipt',
  'account_payment_h5_methods',
  'account_payment_h5_authenticate',
  'account_payment_h5_start',
  'account_payment_h5_submit',
  'account_list',
  'account_begin',
  'account_cancel',
  'account_view',
  'account_use_taobao',
  'list_platforms',
  'list_connections',
  'get_status',
  'prepare_ordering',
  'search_shops',
  'search_products',
  'get_menu',
  'get_product_details',
  'preview_checkout',
  'get_cart',
  'add_product_to_cart',
  'get_item_options',
  'change_cart',
  'show_order',
  'submit_order',
  'get_order_status',
  'request_payment',
  'search_retail_products',
  'get_retail_cart',
  'add_retail_product',
  'preview_retail_checkout',
  'confirm_order',
  'get_payment_options',
  'pay_order',
  'account_payment_h5_pay',
  'get_payment_status',
  'prepare_h5_payment',
  'get_h5_payment_status',
  'continue_h5_payment',
]

/**
 * Connect to a freshly spawned server.
 *
 * @param env - environment overrides for the child process.
 * @returns the connected client and a disposer that shuts it down.
 */
async function connect(env = {}) {
  const home = await mkdtemp(join(tmpdir(), 'waimai-mcp-test-'))
  const environment = Object.fromEntries(Object.entries(process.env).filter(([key]) =>
    /^(SystemRoot|WINDIR|PATH|PATHEXT|TEMP|TMP)$/i.test(key)))
  const transport = new StdioClientTransport({
    command: process.execPath,
    args: [SERVER_ENTRY],
    env: { ...environment, ...env, DSH_HOME: home, HOME: home, USERPROFILE: home },
    stderr: 'ignore',
  })
  const client = new Client({ name: 'dsh-waimai-test', version: '0.0.0' })
  try { await client.connect(transport) }
  catch (error) { await transport.close(); await rm(home, { recursive: true, force: true }); throw error }
  return { client, close: async () => { try { await client.close() } finally { await rm(home, { recursive: true, force: true }) } } }
}

test('the server advertises every takeaway tool', async () => {
  const { client, close } = await connect()
  try {
    const { tools } = await client.listTools()
    const names = tools.map(tool => tool.name)
    for (const expected of EXPECTED_TOOLS) {
      assert.ok(names.includes(expected), `missing tool ${expected}`)
    }
    assert.equal(names.length, EXPECTED_TOOLS.length)
    const add = tools.find(tool => tool.name === 'add_product_to_cart')
    assert.deepEqual(add.inputSchema.required, ['platformId', 'accountRef', 'productRef', 'skuId', 'quantity', 'revision', 'operationRef'])
    const cart = tools.find(tool => tool.name === 'get_cart')
    assert.deepEqual(cart.inputSchema.properties.platformId.enum, ['taobao', 'hema'])
    const delivery = tools.find(tool => tool.name === 'account_select_delivery')
    assert.equal(delivery.inputSchema.properties.platformId.const, 'hema')
    assert.deepEqual(delivery.inputSchema.required, ['platformId', 'accountRef', 'quoteRef', 'deliveryRef'])
    const payment = tools.find(tool => tool.name === 'pay_order')
    assert.equal(Object.hasOwn(payment.inputSchema.properties, 'sessionId'), false)
    assert.equal(Object.hasOwn(payment.inputSchema.properties, 'paymentSessionId'), false)
    const receipt = tools.find(tool => tool.name === 'account_payment_provider_receipt')
    assert.deepEqual(receipt.inputSchema.required, ['platformId', 'accountRef', 'orderRef'])
    assert.equal(receipt.inputSchema.properties.platformId.const, 'taobao')
  } finally {
    await close()
  }
})

test('merchant browsing keeps the configured default platform while product queries remain explicitly Taobao scoped', async () => {
  const { client, close } = await connect({ DEFAULT_PLATFORM: 'hema' })
  try {
    const { tools } = await client.listTools()
    assert.equal(tools.find(tool => tool.name === 'search_shops').inputSchema.properties.platformId.default, 'hema')
    assert.equal(tools.find(tool => tool.name === 'search_products').inputSchema.properties.platformId.const, 'taobao')
  } finally { await close() }
})

test('request_payment accepts only account and order references, without caller-selected payment amount', async () => {
  const { client, close } = await connect({ PAYMENT_MODE: 'auto', MAX_ORDER_AMOUNT: '35' })
  try {
    const { tools } = await client.listTools()
    const payment = tools.find(tool => tool.name === 'request_payment')
    assert.ok(payment !== undefined)
    const properties = payment.inputSchema?.properties ?? {}
    assert.deepEqual(Object.keys(properties), ['platformId', 'accountRef', 'orderRef'],
      'request_payment must not accept an amount or merchant from the caller')
  } finally {
    await close()
  }
})

test('HTTP tools require a stable merchant and expose platform selection', async () => {
  const { client, close } = await connect()
  try {
    const { tools } = await client.listTools()
    const menu = tools.find(tool => tool.name === 'get_menu')
    assert.deepEqual(menu.inputSchema.required, ['shopId'])

    const submit = tools.find(tool => tool.name === 'submit_order')
    assert.deepEqual(Object.keys(submit.inputSchema.properties ?? {}), ['platformId', 'accountRef', 'shopId', 'lineIds', 'maxAmount'])
    assert.deepEqual(submit.inputSchema.required, ['accountRef', 'maxAmount'])
  } finally {
    await close()
  }
})

test('preview status exposes interactive ordering without automatic payment', async () => {
  const { client, close } = await connect({ DRY_RUN: 'true', PAYMENT_MODE: 'auto' })
  try {
    const value = JSON.parse((await client.callTool({ name: 'get_status', arguments: {} })).content[0].text)
    assert.equal(value.data.dryRun, true); assert.equal(value.data.orderingAvailable, true)
    assert.equal(value.data.automaticPaymentAvailable, false); assert.equal(value.data.paymentMode, 'official-cashier')
    assert.equal(value.data.paymentInitiationAvailable, true)
    const { tools } = await client.listTools()
    const submit = tools.find(tool => tool.name === 'submit_order')
    assert.match(submit.description, /不创建订单或扣款/)
    assert(!('confirmed' in submit.inputSchema.properties))
  } finally { await close() }
})

test('unavailable platforms cannot use private account actions', async () => {
  const { client, close } = await connect({ DRY_RUN: 'false' })
  try {
    for (const platformId of ['meituan', 'jd', 'unknown']) {
      const value = JSON.parse((await client.callTool({ name: 'account_profile', arguments: { platformId } })).content[0].text)
      assert.equal(value.code, platformId === 'unknown' ? 'unknown-platform' : 'not-integrated')
    }
  } finally { await close() }
})
