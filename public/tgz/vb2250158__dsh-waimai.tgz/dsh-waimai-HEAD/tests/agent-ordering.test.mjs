import { test } from 'node:test'
import assert from 'node:assert/strict'
import { z } from 'zod'
import { readFile } from 'node:fs/promises'
import { registerAgentOrdering } from '../lib/agent-ordering.js'

const ref = '11111111-1111-4111-8111-111111111111', address = 'a'.repeat(64), revision = 'b'.repeat(64)
function tools(dispatch) {
  const registrations = new Map()
  registerAgentOrdering((name, description, schema, run) => registrations.set(name, { description, schema: z.object(schema).strict(), run }), { dispatch })
  return async (name, args, extra) => { const tool = registrations.get(name); return tool.run(tool.schema.parse(args), extra) }
}
const cart = { platformId: 'taobao', accountId: 'private-account', addressRef: address, shopId: 'store-17', revision, items: [], quantity: 1 }
const quote = { ...cart, address: { address: 'private address' }, quoteRef: '22222222-2222-4222-8222-222222222222', merchant: '示例店', totalCents: 2100, maxOrderCents: 3500 }

test('payment status exposes lost query availability without changing an unknown payment into a cancellation result', async () => {
  const calls = [], call = tools(async method => {
    calls.push(method)
    return { accountId: 'private-account', orderRef: ref, paymentStatus: 'unknown', paymentQueryAvailable: false,
      officialOrders: [{ id: '123', status: '已取消' }] }
  })
  const result = await call('get_payment_status', { accountRef: ref, orderRef: ref })
  assert.deepEqual(result.attempts, [{ orderRef: ref, paymentStatus: 'unknown', paymentQueryAvailable: false,
    officialOrders: [{ id: '123', status: '已取消' }] }])
  assert.deepEqual(calls, ['paymentStatus'])
  assert(!JSON.stringify(result).includes('private'))
})

test('agent submit returns a capped confirmation card without calling the private submit or exposing an address', async () => {
  const calls = [], call = tools(async (method, args) => { calls.push({ method, args }); return method === 'cart' ? cart : quote })
  const result = await call('submit_order', { accountRef: ref, shopId: 'store-17', maxAmount: 25 })
  assert.equal(result.state, 'awaiting-user-confirmation'); assert.equal(result.maxAmountCents, 2500)
  assert.equal(result.accountRef, ref); assert.equal(result.revision, revision)
  assert(!JSON.stringify(result).includes('private')); assert.deepEqual(calls.map(c => c.method), ['cart', 'checkout'])
  await assert.rejects(call('submit_order', { accountRef: ref, shopId: 'store-17', maxAmount: 20 }), error => error.code === 'over-cap')
  assert(!calls.some(c => c.method === 'submit'))
})

test('agent cart changes resolve the selected address and use only validated current selection fields', async () => {
  const calls = [], call = tools(async (method, args) => { calls.push({ method, args }); return cart })
  const result = await call('change_cart', { accountRef: ref, shopId: 'store-17', revision, step: 1, itemId: 'food-1' })
  assert.equal(result.revision, revision); assert(!result.accountId); assert.match(calls[0].args.operationRef, /^[a-f0-9-]{36}$/)
  await assert.rejects(call('change_cart', { accountRef: ref, shopId: 'store-17', revision, step: -1, itemId: 'food-1' }))
  await assert.rejects(call('change_cart', { accountRef: ref, shopId: 'store-17', revision, step: 1, itemId: 'food-1', selectionRef: ref }))
  assert.equal(calls.length, 1)
})

test('recommendation cards use existing menu identities and never add items', async () => {
  const calls = [], call = tools(async method => { calls.push(method); return { categories: [{ items: [{ id: 'food-1', name: '示例饭', price: '20' }] }] } })
  const result = await call('show_order', { accountRef: ref, shopId: 'store-17', itemIds: ['food-1'], maxAmount: 40 })
  assert.equal(result.view, 'ordering'); assert.deepEqual(result.itemIds, ['food-1']); assert.equal(result.maxAmountCents, 4000)
  await assert.rejects(call('show_order', { accountRef: ref, shopId: 'store-17', itemIds: ['missing'] }), error => error.code === 'item-unavailable')
  assert(calls.every(method => method === 'probeMenu'))
})

test('payment cards project official order status without credentials or payment URLs and never charge', async () => {
  const calls = [], call = tools(async method => {
    calls.push(method)
    return method === 'tradeHistory' ? { attempts: [{ orderRef: ref, status: 'created', orderIds: ['123'], amountCents: 2100, paymentUrl: 'https://r.ele.me/payment?private=secret', paymentStatus: 'unconfirmed' }] }
      : { orders: [{ id: '123', status: '待支付', amount: '21', merchantName: '示例店' }, { id: '456', status: '其他账号订单' }] }
  })
  const result = await call('request_payment', { accountRef: ref, orderRef: ref })
  assert(!JSON.stringify(result).includes('secret')); assert.equal(result.attempts[0].officialOrders.length, 1)
  assert.equal(result.attempts[0].officialOrders[0].status, '待支付'); assert.equal(result.attempts[0].paymentStatus, 'unconfirmed')
  assert.deepEqual(calls, ['tradeHistory', 'orders'])
})

test('agent payment requires a prepared reference and explicit final amount; returns no provider credentials', async () => {
  const calls = [], call = tools(async (method, args) => { calls.push({ method, args }); return { orderRef: ref, paymentRef: ref,
    amountCents: 300, paymentStatus: method === 'paymentSubmit' ? 'requires-verification' : 'unpaid', paymentUrl: 'https://mclient.alipay.com/?private=secret' } })
  const prepared = await call('get_payment_options', { accountRef: ref, orderRef: ref })
  assert(!JSON.stringify(prepared).includes('secret'))
  await assert.rejects(call('pay_order', { accountRef: ref, orderRef: ref, paymentRef: ref, confirmedCents: 300, maxAmountCents: 500 }))
  const paid = await call('pay_order', { accountRef: ref, orderRef: ref, paymentRef: ref, confirmed: true, confirmedCents: 300, maxAmountCents: 500 })
  assert.equal(paid.attempts[0].paymentStatus, 'requires-verification'); assert(!JSON.stringify(paid).includes('secret'))
  await call('get_payment_status', { accountRef: ref, orderRef: ref })
  assert.deepEqual(calls.map(c => c.method), ['paymentPrepare', 'paymentSubmit', 'paymentStatus'])
})

test('payment session identity comes only from Host metadata and stays out of model results', async () => {
  const calls = [], call = tools(async (method, args) => { calls.push({ method, args }); return { orderRef: ref, paymentStatus: 'unknown' } })
  const args = { accountRef: ref, orderRef: ref, paymentRef: ref, confirmed: true, confirmedCents: 300, maxAmountCents: 500 }
  const sessionId = 'session-22222222-2222-4222-8222-222222222222'
  const extra = { _meta: { 'dsh/sessionId': sessionId } }
  const result = await call('pay_order', args, extra)
  assert.equal(calls[0].args.paymentSessionId, sessionId)
  assert(!JSON.stringify(result).includes(sessionId))
  await assert.rejects(call('pay_order', { ...args, paymentSessionId: sessionId }, extra))
  await assert.rejects(call('pay_order', { ...args, sessionId }, extra))
  await call('pay_order', args)
  assert.equal(calls[1].args.paymentSessionId, undefined)
  await call('pay_order', args, { _meta: { 'dsh/sessionId': { forged: true } } })
  assert.equal(calls[2].args.paymentSessionId, undefined)
  await call('get_payment_status', { accountRef: ref, orderRef: ref }, extra)
  assert.equal(Object.hasOwn(calls[3].args, 'paymentSessionId'), false)
})

test('unknown order creation remains queryable without invoking payment or claiming absence', async () => {
  const calls = [], call = tools(async method => {
    calls.push(method)
    if (method === 'tradeHistory') return { attempts: [{ orderRef: ref, status: 'unknown', orderIds: [], amountCents: 190, paymentStatus: 'unconfirmed' }] }
    if (method === 'orders') return { orders: [{ id: 'other', status: '待支付' }] }
    throw Error('Unknown creation must not enter the cashier')
  })
  const result = await call('get_order_status', { accountRef: ref, orderRef: ref })
  assert.equal(result.attempts[0].status, 'unknown')
  assert.equal(result.attempts[0].paymentStatus, 'unconfirmed')
  assert.deepEqual(result.attempts[0].officialOrders, [])
  assert.deepEqual(JSON.parse(JSON.stringify(result)), JSON.parse(await readFile(new URL('./fixtures/unknown-order-status.json', import.meta.url), 'utf8')))
  assert.deepEqual(calls, ['tradeHistory', 'orders'])
})

test('created order status also reconciles payment through its owned reference', async () => {
  const calls = [], call = tools(async method => {
    calls.push(method)
    if (method === 'tradeHistory') return { attempts: [{ orderRef: ref, status: 'created', orderIds: ['123'], amountCents: 190 }] }
    if (method === 'orders') return { orders: [{ id: '123', status: '配送中' }] }
    return { orderRef: ref, paymentStatus: 'paid', officialOrders: [{ id: '123', status: '配送中' }] }
  })
  const result = await call('get_order_status', { accountRef: ref, orderRef: ref })
  assert.equal(result.attempts[0].status, 'created'); assert.equal(result.attempts[0].paymentStatus, 'paid')
  assert.deepEqual(calls, ['tradeHistory', 'orders', 'paymentStatus'])
})

test('recorded payment results distinguish charge outcomes without private provider data', async () => {
  const recorded = []
  for (const state of ['requires-verification', 'unknown', 'failed', 'paid']) {
    const call = tools(async () => ({ orderRef: ref, orderIds: ['123'], amountCents: 190, merchant: '示例店',
      paymentStatus: state, accountId: 'private-owner', paymentUrl: 'https://mclient.alipay.com/?private=secret' }))
    recorded.push(await call('get_payment_status', { accountRef: ref, orderRef: ref }))
  }
  assert.deepEqual(recorded, JSON.parse(await readFile(new URL('./fixtures/payment-outcomes.json', import.meta.url), 'utf8')))
})

test('Hema agent cart and SKU add use the shared account owner and retain the action identity', async () => {
  const calls = [], call = tools(async (method, args) => { calls.push({ method, args }); return { platformId: 'hema', accountId: 'private-account',
    addressRef: address, revision, items: [], mutation: { operationRef: ref, state: 'unconfirmed' } } })
  const current = await call('get_cart', { platformId: 'hema', accountRef: ref })
  assert.equal(current.view, 'cart'); assert.equal(current.accountRef, ref); assert(!JSON.stringify(current).includes('private-account')); assert(!current.addressRef)
  const result = await call('add_product_to_cart', { platformId: 'hema', accountRef: ref, productRef: ref, skuId: '7002', quantity: 1, revision, operationRef: ref })
  assert.deepEqual(calls.map(row => row.method), ['cart', 'cartAdd']); assert.equal(calls[1].args.operationRef, ref); assert.equal(result.mutation.state, 'unconfirmed')
})

test('Hema agent quote uses explicit cart lines and returns a private-address-free confirmation card', async () => {
  const calls = [], call = tools(async (method, args) => {
    calls.push({ method, args })
    return method === 'cart' ? { ...cart, platformId: 'hema' } : { ...quote, platformId: 'hema', shopId: '456' }
  })
  const result = await call('submit_order', { platformId: 'hema', accountRef: ref, lineIds: ['321'], maxAmount: 25 })
  assert.equal(result.platformId, 'hema'); assert.deepEqual(result.lineIds, ['321'])
  assert(!JSON.stringify(result).includes('private')); assert.deepEqual(calls.map(row => row.method), ['cart', 'checkout'])
  assert.deepEqual(calls[1].args.lineIds, ['321'])
  await assert.rejects(call('submit_order', { platformId: 'hema', accountRef: ref, maxAmount: 25 }), error => error.code === 'bad-request')
  assert.equal(calls.length, 2)
})
