import { test } from 'node:test'
import { randomUUID } from 'node:crypto'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { runInNewContext } from 'node:vm'
import React from 'react'
import { create, act } from 'react-test-renderer'
import { Config } from '../lib/index.js'

test('recorded Hema specifications display units and unavailable variants without inventing a price or writing a cart', async () => {
  const fixture = JSON.parse(await readFile(new URL('./fixtures/agent-hema-product-detail.json', import.meta.url), 'utf8'))
  const calls = []
  const mounted = await mount({ async call(_channel, method) { calls.push(method); throw Error('Recorded specifications do not request private data') } }, { tool: fixture })
  try {
    const value = text(mounted.renderer.toJSON())
    assert(value.includes(fixture.expected.name))
    for (const expected of [...fixture.expected.specifications, ...fixture.expected.stock]) assert(value.includes(expected))
    assert(value.includes('已售罄')); assert(value.includes('下单前需重新核验'))
    assert(!value.includes('¥0')); assert(!value.includes('9001')); assert.equal(calls.length, 0)
    assert(mounted.renderer.root.findAllByType('button').some(node => text(node.props.children) === fixture.expected.action))
  } finally { mounted.close() }
})

test('Hema chat products open a specifications modal using the recorded account and freshly selected address', async () => {
  const fixture = JSON.parse(await readFile(new URL('./fixtures/agent-hema-product-detail.json', import.meta.url), 'utf8'))
  const result = JSON.parse(fixture.props.block.content[0].text).data, addressRef = 'a'.repeat(64), calls = []
  fixture.name = 'mcp__waimai__get_menu'
  fixture.props.block.content[0].text = JSON.stringify({ success: true, data: { platformId: 'hema', shopId: result.shopId,
    categories: [{ id: 'search', items: [{ id: result.product.id, name: result.product.name, price: '49.90', productRef: result.productRef, availability: 'available' }] }] } })
  const mounted = await mount({ async call(_channel, method, payload) {
    calls.push({ method, payload })
    if (method === 'profile') return ok(profile)
    if (method === 'productDetail') return ok({ ...result, accountId: profile.id, addressRef })
    throw Error('Unexpected Hema chat operation')
  } }, { tool: fixture, addresses: async payload => {
    calls.push({ method: 'addresses', payload }); return ok({ accountId: profile.id, selectedRef: addressRef })
  } })
  try {
    const root = mounted.renderer.root
    await act(async () => root.findAllByType('button').find(node => text(node.props.children) === '查看规格').props.onClick())
    assert.equal(root.findAllByProps({ role: 'dialog' }).length, 1)
    assert(text(mounted.renderer.toJSON()).includes(result.product.variants[0].name))
    assert.deepEqual(calls.map(call => call.method).sort(), ['addresses', 'productDetail', 'profile'])
    assert(calls.every(call => call.payload.platformId === 'hema' && call.payload.accountRef === '11111111-1111-4111-8111-111111111111'))
    assert.equal(calls.find(call => call.method === 'productDetail').payload.addressRef, addressRef)
    act(() => root.findByProps({ role: 'dialog' }).props.onClose())
    assert.equal(root.findAllByProps({ role: 'dialog' }).length, 0)
  } finally { mounted.close() }
})

test('Hema chat add chooses a SKU, submits once and reconciles a delayed result through the floating cart', async () => {
  const fixture = JSON.parse(await readFile(new URL('./fixtures/agent-hema-product-detail.json', import.meta.url), 'utf8'))
  const result = JSON.parse(fixture.props.block.content[0].text).data, addressRef = 'a'.repeat(64), calls = []
  let operationRef, reads = 0, resolveAdd
  const cart = () => ({ platformId: 'hema', accountId: profile.id, addressRef, revision: 'b'.repeat(64), items: [], availableCount: 0, selectedCount: 0,
    ...(operationRef ? { mutation: { operationRef, state: ++reads > 1 ? 'verified' : 'unconfirmed' } } : {}) })
  const mounted = await mount({ async call(_channel, method, payload) {
    calls.push({ method, payload })
    if (method === 'profile') return ok(profile)
    if (method === 'productDetail') return ok({ ...result, accountId: profile.id, addressRef })
    if (method === 'cart') return ok(cart())
    if (method === 'cartAdd') { operationRef = payload.operationRef; return new Promise(resolve => { resolveAdd = () => resolve(ok(cart())) }) }
    throw Error('unexpected method')
  } }, { tool: fixture, addresses: async () => ok({ accountId: profile.id, selectedRef: addressRef }) })
  try {
    const root = mounted.renderer.root, button = label => root.findAllByType('button').find(node => text(node.props.children) === label)
    await act(async () => button('刷新商品规格').props.onClick())
    assert(button('加入购物车').props.disabled)
    const variant = root.findAll(node => node.type === 'span' && Array.isArray(node.props.items) && node.props.items.some(row => row.id === result.product.variants[0].id))[0]
    await act(async () => variant.props.onSelect(result.product.variants[0].id))
    assert.equal(button('加入购物车').props.disabled, false)
    await act(async () => { button('加入购物车').props.onClick(); button('加入购物车').props.onClick() })
    assert.equal(calls.filter(row => row.method === 'cartAdd').length, 1); assert(button('正在加入…').props.disabled)
    await act(async () => resolveAdd())
    assert.equal(root.findAllByProps({ role: 'dialog' }).length, 2)
    assert(text(root).includes('已加入购物车'))
    assert(calls.every(row => row.payload.platformId === 'hema' && row.payload.accountRef === '11111111-1111-4111-8111-111111111111'))
    const sent = calls.find(row => row.method === 'cartAdd').payload
    assert.equal(sent.quantity, 1); assert.equal(sent.skuId, result.product.variants[0].id)
    const expected = JSON.parse(await readFile(new URL('./fixtures/agent-hema-cart-add.json', import.meta.url), 'utf8'))
    assert.deepEqual({ variant: result.product.variants[0].name, quantity: sent.quantity, pendingLabel: '正在加入…',
      verifiedLabel: '已加入购物车', cartDialog: root.findAllByProps({ role: 'dialog' }).at(-1).props['aria-label'],
      cartScrollable: root.findAllByProps({ role: 'dialog' }).at(-1).findAllByProps({ className: 'waimai-cart-modal-content' }).length === 1,
      requestCount: calls.filter(row => row.method === 'cartAdd').length, privateReads: calls.map(row => row.method) }, expected)
    assert(!calls.some(row => ['checkout', 'submit'].includes(row.method)))
  } finally { mounted.close() }
})

test('a recorded Hema cart opens a fresh cart modal for its account without reusing recorded prices', async () => {
  const ref = '11111111-1111-4111-8111-111111111111', addressRef = 'a'.repeat(64), calls = []
  const fixture = { name: 'mcp__waimai__get_cart', props: { phase: 'result', sessionId: 'hema-cart', callId: 'cart-read', args: { accountRef: ref, platformId: 'hema' },
    block: { content: [{ type: 'text', text: JSON.stringify({ success: true, data: { view: 'cart', platformId: 'hema', accountRef: ref, items: [] } }) }] } } }
  const mounted = await mount({ async call(_channel, method, payload) { calls.push({ method, payload });
    if (method === 'profile') return ok(profile)
    if (method === 'cart') return ok({ accountId: profile.id, addressRef, items: [], availableCount: 0, selectedCount: 0 })
    throw Error('unexpected read')
  } }, { tool: fixture, addresses: async () => ok({ accountId: profile.id, selectedRef: addressRef }) })
  try {
    const root = mounted.renderer.root
    assert.equal(calls.length, 0)
    await act(async () => root.findAllByType('button').find(node => text(node.props.children) === '查看购物车').props.onClick())
    assert.equal(root.findAllByProps({ role: 'dialog' }).length, 1)
    assert.deepEqual(calls.map(row => row.method), ['profile', 'cart']); assert(calls.every(row => row.payload.accountRef === ref && row.payload.platformId === 'hema'))
  } finally { mounted.close() }
})

test('a mismatched Hema account prevents product reads and failed refreshes discard old specifications', async () => {
  const fixture = JSON.parse(await readFile(new URL('./fixtures/agent-hema-product-detail.json', import.meta.url), 'utf8'))
  const result = JSON.parse(fixture.props.block.content[0].text).data, addressRef = 'a'.repeat(64), calls = []
  let mismatch = true, fail = false
  const mounted = await mount({ async call(_channel, method, payload) {
    calls.push(method)
    if (method === 'profile') return ok(profile)
    if (method === 'productDetail') return fail ? { ok: false, error: { code: 'product-changed', message: '商品选择已失效' } } : ok({ ...result, accountId: profile.id, addressRef })
    throw Error('Unexpected operation')
  } }, { tool: fixture, addresses: async () => ok({ accountId: mismatch ? '999' : profile.id, selectedRef: addressRef }) })
  try {
    const root = mounted.renderer.root
    await act(async () => root.findAllByType('button').find(node => text(node.props.children) === '刷新商品规格').props.onClick())
    assert(!calls.includes('productDetail'))
    const modal = () => root.findByProps({ role: 'dialog' })
    assert(text(modal()).includes('账号已变化'))
    mismatch = false
    await act(async () => modal().findAllByType('button').find(node => text(node.props.children) === '刷新商品规格').props.onClick())
    assert(text(modal()).includes(result.product.name))
    fail = true
    await act(async () => modal().findAllByType('button').find(node => text(node.props.children) === '刷新商品规格').props.onClick())
    assert(!text(modal()).includes(result.product.name)); assert(text(modal()).includes('商品选择已失效'))
  } finally { mounted.close() }
})

test('fresh Hema specifications show a closed sale period and prevent add even when the selected SKU has stock', async () => {
  const fixture = JSON.parse(await readFile(new URL('./fixtures/agent-hema-product-detail.json', import.meta.url), 'utf8'))
  const result = JSON.parse(fixture.props.block.content[0].text).data, addressRef = 'a'.repeat(64), calls = []
  result.product.available = false; result.product.availability = 'outside-sale-time'
  const mounted = await mount({ async call(_channel, method) {
    calls.push(method)
    if (method === 'profile') return ok(profile)
    if (method === 'productDetail') return ok({ ...result, accountId: profile.id, addressRef })
    throw Error('Closed store must not issue cart operations')
  } }, { tool: fixture, addresses: async () => ok({ accountId: profile.id, selectedRef: addressRef }) })
  try {
    const root = mounted.renderer.root
    await act(async () => root.findAllByType('button').find(node => text(node.props.children) === '刷新商品规格').props.onClick())
    const variant = root.findAll(node => node.type === 'span' && Array.isArray(node.props.items) && node.props.items.some(row => row.id === result.product.variants[0].id))[0]
    await act(async () => variant.props.onSelect(result.product.variants[0].id))
    const add = root.findAllByType('button').find(node => text(node.props.children) === '加入购物车')
    assert(add.props.disabled); await act(async () => add.props.onClick())
    assert(text(root.findByProps({ role: 'dialog' })).includes('非售卖时段'))
    assert.deepEqual({ label: '非售卖时段', addEnabled: !add.props.disabled, cartWrites: calls.filter(method => method === 'cartAdd').length },
      JSON.parse(await readFile(new URL('./fixtures/agent-hema-product-closed.json', import.meta.url), 'utf8')))
  } finally { mounted.close() }
})

test('recorded product queries retain identical items in different stores and open the selected merchant within the recorded account', async () => {
  const fixture = JSON.parse(await readFile(new URL('./fixtures/agent-product-search.json', import.meta.url), 'utf8')), calls = [], addressRef = 'a'.repeat(64)
  const mounted = await mount({ async call(_channel, method, payload) {
    calls.push({ method, payload })
    if (method === 'profile') return ok(profile)
    if (method === 'probeMenu') return ok({ accountId: profile.id, addressRef, shopId: payload.shopId, categories: [] })
    if (method === 'nearbyShops') return ok({ accountId: profile.id, addressRef, shops: [] })
    throw Error('unexpected product card operation')
  } }, { tool: { name: 'mcp__waimai__search_products', props: fixture },
    addresses: async () => ok({ accountId: profile.id, selectedRef: addressRef, addresses: [{ ref: addressRef, address: '示例地址', usable: true }] }) })
  try {
    const value = text(mounted.renderer.toJSON())
    assert(value.includes('仅查询已选店铺')); assert(value.includes('暂无可售商品，请改天再来')); assert(value.includes('商品读取失败'))
    assert(!value.includes('market-a')); assert(!value.includes('failed'))
    const buttons = mounted.renderer.root.findAllByType('button').filter(button => text(button.props.children) === '选规格并点餐')
    assert.equal(buttons.length, 2); assert.equal(calls.length, 0)
    await act(async () => buttons[1].props.onClick())
    assert(calls.some(call => call.method === 'probeMenu' && call.payload.shopId === 'market-b'))
    assert(calls.every(call => call.payload.accountRef === '11111111-1111-4111-8111-111111111111'))
  } finally { mounted.close() }
})

test('a recorded menu tool renders actionable dishes and keeps private ordering scoped to its recorded account', async () => {
  const recorded = JSON.parse(await readFile(new URL('./fixtures/agent-order-card.json', import.meta.url), 'utf8'))
  const duplicateMenu = JSON.parse(recorded.props.block.content[0].text)
  duplicateMenu.data.categories.push(duplicateMenu.data.categories[0])
  recorded.props.block.content[0].text = JSON.stringify(duplicateMenu)
  const accountRef = '11111111-1111-4111-8111-111111111111', addressRef = 'a'.repeat(64), calls = []
  const item = { id: 'food-1', name: '示例饭', price: '20', imageUrl: null, description: '', availability: 'available', options: [], tips: [] }
  const menu = { platformId: 'taobao', shopId: 'store-17', categories: [{ id: 'main', name: '主食', items: [item] }] }
  const mounted = await mount({ async call(_channel, method, payload) {
    calls.push({ method, payload })
    if (method === 'profile') return ok(profile)
    if (method === 'probeMenu') return ok({ ...menu, accountId: profile.id, addressRef })
    throw Error('Unexpected chat request: ' + method)
  } }, { tool: recorded,
    addresses: async payload => { calls.push({ method: 'addresses', payload }); return ok({ accountId: profile.id, selectedRef: addressRef, addresses: [{ ref: addressRef, address: '示例地址', contact: '', maskedPhone: '', usable: true }] }) } })
  try {
    assert(text(mounted.renderer.toJSON()).includes(recorded.expected.dish))
    assert.equal(mounted.renderer.root.findAllByType('button').filter(node => text(node.props.children) === recorded.expected.action).length, 1)
    const button = mounted.renderer.root.findAllByType('button').find(node => text(node.props.children) === recorded.expected.action)
    assert.equal(button.props.disabled, false)
    await act(async () => button.props.onClick()); await act(async () => {})
    assert(calls.length > 0); assert(calls.every(call => call.payload.accountRef === accountRef))
    assert(text(mounted.renderer.toJSON()).includes('加入购物车'), text(mounted.renderer.toJSON()) + JSON.stringify(calls))
    assert.equal(mounted.renderer.root.findAllByType('aside').length, 0)
  } finally { mounted.close() }
})

test('payment cards read official order states without requiring a delivery address or creating an order', async () => {
  const accountRef = '11111111-1111-4111-8111-111111111111', calls = []
  const mounted = await mount({ async call(_channel, method, payload) { calls.push({ method, payload }); if (method === 'profile') return ok(profile); if (method === 'orders') return ok({ accountId: profile.id, orders: [{ id: '123', status: '已支付' }] }); if (method === 'paymentStatus') return ok({ accountId: profile.id, orderRef: accountRef, paymentStatus: 'paid', officialOrders: [{ id: '123', status: '已支付' }] }); throw Error('Unexpected request: ' + method) } }, {
    tool: { name: 'mcp__waimai__request_payment', props: { phase: 'result', sessionId: 'payment-session', callId: 'payment-call', block: { content: [{ type: 'text', text: JSON.stringify({ success: true,
      data: { view: 'payment', platformId: 'taobao', accountRef, attempts: [{ orderRef: accountRef }] } }) }] } } },
    addresses: async () => { throw Error('Payment must not request addresses') },
    trade: async (method, payload) => { calls.push({ method, payload }); return ok(method === 'tradeHistory' ? { accountId: profile.id, attempts: [{ orderRef: accountRef, merchant: '示例店', amountCents: 2100, status: 'created', orderIds: ['123'], paymentUrl: null }] }
      : { accountId: profile.id, orders: [{ id: '123', status: '已支付' }] }) },
  })
  try {
    assert(text(mounted.renderer.toJSON()).includes('官方订单状态: 已支付'))
    assert(!text(mounted.renderer.toJSON()).includes('付款待确认'))
    assert(text(mounted.renderer.toJSON()).includes('付款已确认'))
    assert.deepEqual({ statuses: mounted.renderer.root.findAllByProps({ role: 'status' }).map(node => text(node.props.children)),
      paymentLinks: mounted.renderer.root.findAllByType('a').length },
    JSON.parse(await readFile(new URL('./fixtures/payment-paid-view.json', import.meta.url), 'utf8')))
    assert.equal(mounted.renderer.root.findAllByType('a').length, 0)
    assert(calls.every(call => call.payload.accountRef === accountRef))
    assert.deepEqual(calls.map(call => call.method).sort(), ['orders', 'paymentStatus', 'profile', 'tradeHistory'])
  } finally { mounted.close() }
})

test('payment cards hide generic cashier links for unresolved attempts and resume only the retained verification handoff', async () => {
  const accountRef = '11111111-1111-4111-8111-111111111111', views = []
  for (const [state, retained, providerErrorCode] of [['unknown', false], ['paid', false], ['failed', false], ['requires-verification', false], ['requires-verification', true], ['unconfirmed', false], ['unknown', false, 'PAYMENT_LINK_UNSUPPORTED'], ['paid', false, 'PAYMENT_LINK_UNSUPPORTED'], ['requires-verification', true, 'PAYMENT_LINK_UNSUPPORTED'], ['requires-verification', false, 'PAYMENT_LINK_UNSUPPORTED']]) {
    const calls = [], officialOrders = [{ id: '123', status: '等待支付' }]
    const mounted = await mount({ async call(_channel, method) {
      calls.push(method)
      if (method === 'profile') return ok(profile)
      if (method === 'orders') return ok({ accountId: profile.id, orders: officialOrders })
      if (method === 'paymentStatus') return ok({ accountId: profile.id, orderRef: accountRef, paymentStatus: state, officialOrders, ...(providerErrorCode ? { providerErrorCode } : {}) })
      throw Error('Unexpected request: ' + method)
    } }, {
      tool: { name: 'mcp__waimai__request_payment', props: { phase: 'result', sessionId: 'payment-session', callId: 'payment-call', block: { content: [{ type: 'text', text: JSON.stringify({ success: true,
        data: { view: 'payment', platformId: 'taobao', accountRef, attempts: [{ orderRef: accountRef }] } }) }] } } },
      trade: async method => { calls.push(method); return ok({ accountId: profile.id, attempts: [{ orderRef: accountRef, merchant: '示例店', amountCents: 2100,
        status: 'created', orderIds: ['123'], paymentStatus: state === 'unknown' ? 'unconfirmed' : state, paymentHandoffAvailable: retained,
        paymentUrl: retained ? 'https://mclient.alipay.com/cashier?synthetic=1' : 'https://tb.ele.me/app/eleme-newretail-c-h5/order-detail-unicorn/order-detail?opType=pay&isAuto=1' }] }) },
    })
    try {
      views.push({ state, retained, ...(providerErrorCode ? { providerErrorCode } : {}), links: mounted.renderer.root.findAllByType('a').length,
        notices: mounted.renderer.root.findAllByProps({ role: 'status' }).map(node => text(node.props.children)) })
      if (state !== 'unconfirmed') assert(!text(mounted.renderer.toJSON()).includes('请在官方客户端的订单中继续'))
      assert(!calls.some(method => ['paymentSubmit', 'submit', 'paymentPrepare'].includes(method)))
    } finally { mounted.close() }
  }
  assert.deepEqual(views, JSON.parse(await readFile(new URL('./fixtures/payment-handoff-view.json', import.meta.url), 'utf8')))
})

test('the chat checkout card refreshes its quote and requires the user to confirm the bounded amount during automation preview', async () => {
  const accountRef = '11111111-1111-4111-8111-111111111111', addressRef = 'a'.repeat(64), revision = 'b'.repeat(64), calls = []
  const display = { platformId: 'taobao', shopId: 'store-17', revision, items: [{ ref: 'c'.repeat(64), name: '示例饭', quantity: 1, priceCents: 2000, totalCents: 2000 }], quantity: 1, invalidCount: 0, totalCents: 2100 }
  const privateQuote = { ...display, accountId: profile.id, addressRef, quoteRef: '22222222-2222-4222-8222-222222222222', merchant: '示例店',
    address: { address: '示例地址', contact: '', maskedPhone: '' }, fees: [{ name: '配送费', amountCents: 100 }], discountCents: 0,
    expiresAt: Date.now() + 60000, deliveryTime: '30分钟', previewOnly: true, maxOrderCents: 3500 }
  const mounted = await mount({ async call(_channel, method) { if (method === 'profile') return ok(profile); throw Error('unexpected chat call') } }, {
    tool: { name: 'mcp__waimai__submit_order', props: { phase: 'result', sessionId: 'session-fixture', callId: 'quote-call', block: { content: [{ type: 'text', text: JSON.stringify({ success: true,
      data: { ...display, view: 'checkout', accountRef, maxAmountCents: 2500 } }) }] } } },
    addresses: async () => ok({ accountId: profile.id, selectedRef: addressRef, addresses: [{ ref: addressRef, address: '示例地址', contact: '', maskedPhone: '', usable: true }] }),
    trade: async (method, payload) => { calls.push({ method, payload }); return ok(method === 'tradeHistory' ? { accountId: profile.id, attempts: [] }
      : method === 'checkout' ? privateQuote : method === 'submit' ? { accountId: profile.id, orderIds: ['123'], paymentStatus: 'unconfirmed', paymentUrl: 'https://r.ele.me/payment?synthetic=1' }
        : { ...display, accountId: profile.id, addressRef }) },
  })
  try {
    const button = () => mounted.renderer.root.findAllByType('button').find(node => text(node.props.children) === '确认创建订单')
    assert.equal(button().props.disabled, true)
    assert(!calls.some(call => call.method === 'submit'))
    const checkbox = mounted.renderer.root.findAll(node => node.type === 'span' && node.props.checked !== undefined)[0]
    await act(async () => checkbox.props.onChange(true))
    assert.equal(button().props.disabled, false)
    await act(async () => button().props.onClick())
    assert.equal(calls.filter(call => call.method === 'submit').length, 1)
    const submitted = calls.find(call => call.method === 'submit').payload
    assert.equal(submitted.accountRef, accountRef); assert.equal(submitted.maxAmountCents, 2500); assert.equal(submitted.manualConfirmation, true)
    assert(text(mounted.renderer.toJSON()).includes('付款待确认'))
    assert.equal(mounted.renderer.root.findAllByType('a')[0].props.href, 'https://r.ele.me/payment?synthetic=1')
  } finally { mounted.close() }
})

test('Hema checkout cards refresh native quotes, show the recorded cost breakdown and submit once after confirmation', async () => {
  const accountRef = '11111111-1111-4111-8111-111111111111', addressRef = 'a'.repeat(64), revision = 'b'.repeat(64), calls = []
  const expected = JSON.parse(await readFile(new URL('./fixtures/agent-hema-checkout.json', import.meta.url), 'utf8'))
  const quote = { platformId: 'hema', accountId: profile.id, addressRef, shopId: '456', revision, quoteRef: '22222222-2222-4222-8222-222222222222',
    expiresAt: Date.now() + 60000, maxOrderCents: 6000, totalCents: 5290, itemPriceCents: 4990, discountCents: 700,
    deliveryTime: '次日送达', address: { address: '示例地址', contact: '示例联系人', maskedPhone: '138****0000' }, merchant: expected.merchant,
    items: [{ id: '789', skuId: '987', name: expected.item, quantity: 1, specification: '570ml×24', totalCents: 4290 }],
    fees: [{ name: '基础运费', amountCents: 600 }, { name: '超重运费', amountCents: 400 }] }
  const mounted = await mount({ async call(_channel, method, payload) {
    calls.push({ method, payload })
    if (method === 'profile') return ok(profile)
    if (method === 'checkout') return ok(quote)
    if (method === 'submit') return ok({ platformId: 'hema', accountId: profile.id, addressRef, orderIds: ['10001'], paymentStatus: 'unconfirmed', paymentUrl: null })
    throw Error('Unexpected checkout operation')
  } }, { tool: { name: 'mcp__waimai__submit_order', props: { phase: 'result', sessionId: 'hema-quote', callId: 'hema-call', block: { content: [{ type: 'text', text: JSON.stringify({ success: true,
    data: { view: 'checkout', platformId: 'hema', accountRef, shopId: '456', revision, lineIds: ['321'], maxAmountCents: 5290 } }) }] } } },
    addresses: async () => ok({ accountId: profile.id, selectedRef: addressRef, addresses: [{ ref: addressRef, usable: true }] }) })
  try {
    const root = mounted.renderer.root, content = text(mounted.renderer.toJSON())
    for (const value of [expected.item, expected.specification, expected.discount, expected.total, expected.confirm, ...expected.fees]) assert(content.includes(value), value)
    const createButton = () => root.findAllByType('button').find(node => text(node.props.children) === expected.create)
    assert(createButton().props.disabled); assert(!calls.some(call => call.method === 'submit'))
    const checkbox = root.findAll(node => node.type === 'span' && node.props.checked !== undefined)[0]
    await act(async () => checkbox.props.onChange(true))
    assert.equal(createButton().props.disabled, false)
    await act(async () => createButton().props.onClick())
    assert.equal(calls.filter(call => call.method === 'submit').length, 1)
    const submitted = calls.find(call => call.method === 'submit').payload
    assert.equal(submitted.platformId, 'hema'); assert.equal(submitted.accountRef, accountRef); assert.equal(submitted.maxAmountCents, 5290)
    assert(text(mounted.renderer.toJSON()).includes('10001')); assert.equal(root.findAllByType('a').length, 0)
    assert.deepEqual(Array.from(calls.find(call => call.method === 'checkout').payload.lineIds), ['321'])
  } finally { mounted.close() }
})

test('Hema delivery repricing resets confirmation and an unknown order permits only one explicitly verified retry', async () => {
  const fixture = JSON.parse(await readFile(new URL('./fixtures/agent-hema-checkout.json', import.meta.url), 'utf8'))
  const expected = JSON.parse(await readFile(new URL('./fixtures/agent-hema-delivery-retry.json', import.meta.url), 'utf8'))
  const accountRef = randomUUID(), addressRef = 'a'.repeat(64), revision = 'b'.repeat(64), calls = []
  const deliveryRef = randomUUID(), originalRef = randomUUID(), adjustedRef = randomUUID(), retryRef = randomUUID()
  let checkoutReads = 0
  const quote = (quoteRef, selected) => ({ accountId: profile.id, addressRef, quoteRef, expiresAt: Date.now() + 60000, maxOrderCents: 6000,
    totalCents: selected ? 5290 : 4990, itemPriceCents: 4990, discountCents: 700, fees: [], requiresDeliveryChoice: !selected,
    address: { address: '示例地址', contact: '示例联系人', maskedPhone: '138****0000' }, deliveryTime: selected ? '次日送达' : '选择时间',
    items: [{ id: '789', skuId: '987', name: fixture.item, quantity: 1, specification: '570ml×24', totalCents: 4290 }],
    deliveryOptions: [{ ref: deliveryRef, label: '次日配送', feeCents: 1000, selected }, { ref: randomUUID(), label: '后日配送', feeCents: 1000, selected: false }] })
  const mounted = await mount({ async call(_channel, method, payload) {
    calls.push({ method, payload })
    if (method === 'profile') return ok(profile)
    if (method === 'checkout') return ok(++checkoutReads === 1 ? quote(originalRef, false) : quote(retryRef, true))
    if (method === 'selectDelivery') return ok(quote(adjustedRef, true))
    if (method === 'submit') return { ok: false, error: { code: 'order-unknown', message: '下单结果未确认' } }
    throw Error('Unexpected delivery operation')
  } }, { tool: { name: 'mcp__waimai__submit_order', props: { phase: 'result', sessionId: 'delivery', callId: 'delivery-call',
    block: { content: [{ type: 'text', text: JSON.stringify({ success: true, data: { view: 'checkout', platformId: 'hema', accountRef,
      shopId: '456', revision, lineIds: ['321'], maxAmountCents: 5290 } }) }] } } },
    addresses: async () => ok({ accountId: profile.id, selectedRef: addressRef, addresses: [{ ref: addressRef, usable: true }] }) })
  try {
    const root = mounted.renderer.root, button = label => root.findAllByType('button').find(node => text(node.props.children) === label)
    const checks = () => root.findAll(node => node.type === 'span' && node.props.checked !== undefined)
    assert(checks()[0].props.disabled); assert(button(fixture.create).props.disabled)
    const picker = root.findAll(node => node.type === 'span' && node.props.className === 'waimai-choice')[0]
    await act(async () => picker.props.onSelect(deliveryRef))
    assert(text(root).includes(expected.selectedTotal)); assert.equal(checks()[0].props.checked, false)
    await act(async () => checks()[0].props.onChange(true))
    await act(async () => button(fixture.create).props.onClick())
    assert(text(root).includes('保留原请求记录'))
    await act(async () => button('去结算').props.onClick())
    assert(button('确认重试一次').props.disabled)
    await act(async () => checks()[1].props.onChange(true))
    assert(button('确认重试一次').props.disabled)
    await act(async () => checks()[0].props.onChange(true))
    assert.equal(button('确认重试一次').props.disabled, false)
    await act(async () => button('确认重试一次').props.onClick())
    assert(button('去结算').props.disabled)
    assert(text(root).includes('本次重试已使用'))
    const submits = calls.filter(row => row.method === 'submit')
    assert.equal(submits.length, 2); assert.equal(submits[0].payload.retryOf, undefined)
    assert.equal(submits[1].payload.retryOf, adjustedRef); assert.equal(submits[1].payload.previousOrderAbsent, true)
    assert.equal(submits[1].payload.quoteRef, retryRef)
    assert.deepEqual({ ...calls.find(row => row.method === 'selectDelivery').payload },
      { platformId: 'hema', accountRef, quoteRef: originalRef, deliveryRef })
    assert.deepEqual({ selectedTotal: expected.selectedTotal, retryAction: '确认重试一次', verification: '我已在盒马 App 确认原请求未生成订单',
      exhausted: root.findAllByProps({ role: 'status' }).map(node => text(node.props.children)).find(value => value.startsWith('本次重试已使用')),
      submitCount: submits.length, deliveryCount: calls.filter(row => row.method === 'selectDelivery').length,
      originalAttemptRetained: submits[1].payload.retryOf === adjustedRef }, expected)
  } finally { mounted.close() }
})

test('unsupported phone selections do not enter a Hema checkout or prevent choosing a different single case', async () => {
  const accountRef = randomUUID(), addressRef = 'a'.repeat(64), revision = 'b'.repeat(64), calls = []
  const expected = JSON.parse(await readFile(new URL('./fixtures/hema-checkout-selection.json', import.meta.url), 'utf8'))
  const mounted = await mount({ async call(_channel, method, payload) {
    calls.push({ method, payload })
    if (method === 'status') return ok({ authenticated: true, state: 'logged-in', viewAccountRef: accountRef,
      accounts: [{ ref: accountRef, nickname: profile.nickname, externalId: profile.id, loginMethod: 'taobao-qr' }] })
    if (method === 'profile') return ok(profile)
    if (method === 'nearbyShops') return ok({ accountId: profile.id, addressRef, shops: [], nextCursor: null })
    if (method === 'cart') return ok({ accountId: profile.id, addressRef, revision, availableCount: 2, selectedCount: 1,
      items: [{ id: '123', name: '示例米饭', available: true, quantity: '2', selected: true, price: '2.50', priceUnit: '/盒' },
        { id: '321', name: '示例矿泉水', available: true, quantity: '1', selected: false, price: '42.90', priceUnit: '/箱' }] })
    if (method === 'checkout') return { ok: false, error: { code: 'fixture-stop', message: '合成报价停止' } }
    throw Error('Unexpected cart selection request')
  } }, { config: { defaultPlatform: 'hema' }, addresses: async () => ok({ accountId: profile.id, selectedRef: addressRef,
    addresses: [{ ref: addressRef, address: '示例地址', usable: true }] }) })
  try {
    const root = mounted.renderer.root, click = label => root.findAllByType('button').find(node => text(node.props.children) === label).props.onClick()
    await act(async () => click('门店与商品'))
    await act(async () => click('查看购物车'))
    const checks = root.findAll(node => node.type === 'span' && node.props.checked !== undefined)
    const initialSelected = checks.filter(node => node.props.checked).length
    const unsupportedDisabled = checks[0].props.disabled
    assert.equal(initialSelected, 0); assert(checks[0].props.disabled)
    assert(root.findAllByType('button').find(node => text(node.props.children) === '去结算 · 0').props.disabled)
    assert(text(root).includes('手机已勾选')); assert(text(root).includes(expected.label))
    await act(async () => checks[1].props.onChange(true))
    await act(async () => click('去结算 · 1'))
    assert.deepEqual({ initialSelected, unsupportedDisabled, label: '本次结算',
      lineIds: Array.from(calls.find(row => row.method === 'checkout').payload.lineIds),
      cartWrites: calls.filter(row => ['cartAdd', 'cartChange', 'submit'].includes(row.method)).length }, expected)
  } finally { mounted.close() }
})

test('Hema view uses explicit Taobao sign-in, private account scope and remote product search', async () => {
  const calls = [], ref = '11111111-1111-4111-8111-111111111111', source = '22222222-2222-4222-8222-222222222222', addressRef = 'a'.repeat(64)
  let linked = false
  let failNext = false
  let failCart = false, foreignCart = false
  let unknownDetailPrice = false
  const productRef = '33333333-3333-4333-8333-333333333333', cursor = { platformId: 'hema', ref: '44444444-4444-4444-8444-444444444444' }
  const status = () => ({ authenticated: linked, state: linked ? 'logged-in' : 'logged-out', loginMethod: 'taobao-qr',
    viewAccountRef: linked ? ref : null, accounts: linked ? [{ ref, nickname: '示例盒马用户', externalId: profile.id, loginMethod: 'taobao-qr' }] : [],
    taobaoAccounts: [{ ref: source, nickname: '示例淘宝用户' }] })
  const mounted = await mount({ async call(_channel, endpoint, payload) {
    calls.push({ endpoint, payload })
    if (endpoint === 'status') return ok(payload.platformId === 'hema' ? status() : { state: 'logged-out', authenticated: false })
    if (endpoint === 'useTaobao') { assert.equal(payload.platformId, 'hema'); assert.equal(payload.sourceAccountRef, source); linked = true; return ok(status()) }
    if (endpoint === 'profile') return ok({ ...profile, nickname: '示例盒马用户' })
    if (endpoint === 'addresses') return ok({ platformId: 'hema', accountId: profile.id, selectedRef: addressRef,
      addresses: [{ ref: addressRef, address: '示例配送地址', contact: '', maskedPhone: '', usable: true }] })
    if (endpoint === 'nearbyShops') return ok({ platformId: 'hema', accountId: profile.id, addressRef, scope: 'delivery-stores', nextCursor: null,
      shops: [{ id: 'group-1', name: '示例盒马门店' }] })
    if (endpoint === 'probeMenu') {
      if (payload.cursor && failNext) return { ok: false, error: { code: 'search-failed', message: '商品分页读取失败' } }
      if (payload.cursor) assert.deepEqual(payload.cursor, cursor)
      return ok({ platformId: 'hema', accountId: profile.id, addressRef, shopId: 'group-1', query: payload.keyword,
        nextCursor: payload.keyword && !payload.cursor ? cursor : null,
        queryRequired: !payload.keyword, categories: payload.keyword ? [{ id: 'results', name: payload.keyword, items: [
          { id: payload.cursor ? 'item-2' : 'item-1', productRef, name: payload.cursor ? '示例下一页鸡蛋' : '示例鸡蛋',
            description: '', imageUrl: null, price: '6.99', priceUnit: '盒', availability: 'available', options: [], tips: [] } ] }] : [] })
    }
    if (endpoint === 'productDetail') return ok({ platformId: 'hema', accountId: profile.id, addressRef, shopId: 'group-1', productRef,
      product: { id: 'item-1', name: '示例鸡蛋', price: unknownDetailPrice ? null : '7.99', originalPrice: unknownDetailPrice ? null : '8.06', priceUnit: '盒', available: true,
        variants: [{ id: 'sku-1', name: '400g/盒', minimumQuantity: 1, quantityStep: 1, stockQuantity: 3, saleUnit: '盒', chargeUnit: '盒' }] } })
    if (endpoint === 'cart') return failCart ? { ok: false, error: { code: 'verification-required', message: '购物车读取需要验证' } } : ok({ platformId: 'hema',
      accountId: foreignCart ? '99999' : profile.id, addressRef, availableCount: 1, selectedCount: 0,
      items: [{ id: 'synthetic-cart', name: '示例购物车鸡蛋', quantity: '1', quantityUnit: '盒', specification: '', price: '6.99', priceUnit: '/盒', available: true, selected: false }] })
    throw Error('unexpected request')
  } }, { addresses: async () => ok({ platformId: 'hema', accountId: profile.id, selectedRef: addressRef,
    addresses: [{ ref: addressRef, address: '示例配送地址', contact: '', maskedPhone: '', usable: true }] }) })
  try {
    const root = mounted.renderer.root
    const click = label => root.findAllByType('button').find(button => text(button.props.children) === label).props.onClick()
    await act(async () => root.findAll(node => node.type === 'span' && node.props.className === 'waimai-choice')[0].props.onSelect('hema'))
    assert(!root.findAllByType('button').some(button => text(button.props.children) === '手机号短信'))
    const loginMethods = ['手机号短信（淘宝授权）', '盒马 App 扫码', '淘宝授权扫码', '使用淘宝账号'].filter(label => root.findAllByType('button').some(button => text(button.props.children) === label))
    assert.equal(loginMethods.length, 4)
    assert(root.findAllByType('button').find(button => text(button.props.children) === '手机号短信（淘宝授权）').props['aria-pressed'])
    await act(async () => click('盒马 App 扫码'))
    assert(text(mounted.renderer.toJSON()).includes('盒马 App 扫码尚未接通'))
    assert(root.findAllByType('button').find(button => text(button.props.children) === '盒马 App 扫码').props['aria-pressed'])
    assert(!calls.some(value => value.endpoint === 'qrStart' && value.payload.platformId === 'hema'))
    await act(async () => click('使用淘宝账号'))
    await act(async () => click('使用已登录淘宝账号'))
    assert(text(mounted.renderer.toJSON()).includes('示例盒马用户'))
    await act(async () => click('门店与商品'))
    const stores = root.findAllByProps({ className: 'waimai-food-card' }).map(node => text(node.findByType('strong').props.children))
    await act(async () => click('查询商品'))
    assert(!calls.some(call => call.endpoint === 'probeMenu' && call.payload.keyword))
    await act(async () => root.findAllByProps({ 'aria-label': '输入商品名称' })[0].props.onChange({ target: { value: '鸡蛋' } }))
    await act(async () => click('搜索商品'))
    const price = text(root.findByProps({ className: 'waimai-price' }).props.children)
    const view = { platform: '盒马', tabs: root.findByType('nav').findAllByType('button').map(button => text(button.props.children)), loginMethods, stores,
      search: calls.find(call => call.endpoint === 'probeMenu' && call.payload.keyword)?.payload.keyword, price,
      ordering: root.findAllByType('p').map(node => text(node.props.children)).find(value => value.startsWith('选择商品核对实付报价')) }
    assert.deepEqual(view, JSON.parse(await readFile(new URL('./fixtures/hema-view.json', import.meta.url), 'utf8')))
    await act(async () => click('查看规格'))
    const specs = { price: root.findAllByProps({ className: 'waimai-price' }).map(value => text(value.props.children)),
      labels: ['返回商品', '商品规格', '400g/盒', '最低数量: 1 盒', '数量步长: 1 盒', '库存: 3', '计价单位: 盒'].filter(value => text(mounted.renderer.toJSON()).includes(value)) }
    assert.deepEqual(specs, JSON.parse(await readFile(new URL('./fixtures/hema-specifications.json', import.meta.url), 'utf8')))
    await act(async () => click('返回商品'))
    unknownDetailPrice = true; await act(async () => click('查看规格'))
    assert(text(mounted.renderer.toJSON()).includes('价格暂无法确认')); assert(!text(mounted.renderer.toJSON()).includes('¥null'))
    await act(async () => click('返回商品'))
    failNext = true
    await act(async () => click('下一页商品'))
    assert(text(mounted.renderer.toJSON()).includes('示例鸡蛋')); assert(text(mounted.renderer.toJSON()).includes('商品分页读取失败'))
    failNext = false
    await act(async () => click('下一页商品'))
    assert(text(mounted.renderer.toJSON()).includes('示例下一页鸡蛋'))
    assert(!root.findAllByProps({ className: 'waimai-food-card' }).some(value => text(value.props.children).includes('示例鸡蛋')))
    assert.equal(root.findAllByType('button').find(button => text(button.props.children) === '下一页商品').props.disabled, true)
    await act(async () => click('返回首批'))
    assert(text(mounted.renderer.toJSON()).includes('示例鸡蛋'))
    await act(async () => click('查看购物车'))
    const cartView = text(mounted.renderer.toJSON())
    assert.deepEqual({ labels: ['购物车', '刷新购物车', '商品条目: 1', '可售商品: 1', '示例购物车鸡蛋', '数量: 1 盒', '标价 ¥6.99 /盒'].filter(value => cartView.includes(value)) },
      JSON.parse(await readFile(new URL('./fixtures/hema-cart.json', import.meta.url), 'utf8')))
    failCart = true; await act(async () => click('刷新购物车'))
    assert(text(mounted.renderer.toJSON()).includes('示例购物车鸡蛋')); assert(text(mounted.renderer.toJSON()).includes('购物车读取需要验证'))
    failCart = false; foreignCart = true; await act(async () => click('刷新购物车'))
    assert(!text(mounted.renderer.toJSON()).includes('示例购物车鸡蛋'))
    assert(calls.filter(call => ['profile', 'addresses', 'nearbyShops', 'probeMenu', 'productDetail', 'cart'].includes(call.endpoint)).every(call => call.payload.accountRef === ref && call.payload.platformId === 'hema'))
    assert(!calls.some(call => /create|pay|bind/i.test(call.endpoint)))
    assert(!text(mounted.renderer.toJSON()).includes('示例淘宝用户'))
  } finally { mounted.close() }
})

const profile = { id: '12345', nickname: '示例用户', maskedPhone: '138****0000', avatarUrl: 'https://cube.elemecdn.com/a/aa/' + 'a'.repeat(29) + 'png.png' }
const order = { id: 'synthetic-order', merchantName: '示例店', createdAt: 1700000000000, amount: '25.50', status: '已完成', items: [{ name: '示例饭', count: 2 }] }
const ok = value => ({ ok: true, value })
const deferred = () => { let resolve; const promise = new Promise(done => { resolve = done }); return { promise, resolve } }
const text = node => typeof node === 'string' ? node : (Array.isArray(node) ? node : node?.children || []).map(text).join('')
const accountTree = node => typeof node === 'string' ? node : { type: node.type,
  props: Object.fromEntries(Object.entries(node.props).filter(([key]) => ['className', 'aria-label', 'src', 'alt', 'width', 'height', 'referrerPolicy'].includes(key))),
  children: node.children.map(accountTree) }

async function mount(rpc, options = {}) {
  const entries = new Map()
  const localStorage = options.storage || { getItem: key => entries.get(key) ?? null, setItem: (key, value) => entries.set(key, value) }
  const originalCall = rpc.call.bind(rpc)
  const platforms = JSON.parse(await readFile(new URL('../lib/platforms.json', import.meta.url), 'utf8'))
  rpc = { call(channel, endpoint, payload) {
    if (endpoint === 'platforms') return options.platforms ? options.platforms() : Promise.resolve(ok(platforms))
    if (endpoint === 'addresses') return options.addresses ? options.addresses(payload) : Promise.resolve(ok({ accountId: profile.id, addresses: [], selectedRef: null }))
    if (payload.platformId === 'taobao' && ['cart', 'tradeHistory', 'itemOptions', 'cartChange', 'checkout', 'submit'].includes(endpoint)) {
      if (options.trade) return options.trade(endpoint, payload)
      return Promise.resolve(ok(endpoint === 'tradeHistory' ? { platformId: 'taobao', accountId: profile.id, attempts: [] }
        : { platformId: 'taobao', accountId: profile.id, addressRef: payload.addressRef, shopId: payload.shopId,
          revision: 'b'.repeat(64), items: [], quantity: 0, invalidCount: 0, totalCents: 0 }))
    }
    return originalCall(channel, endpoint, payload)
  } }
  let module, Card, cardProps, dictionary
  const toolCards = new Map()
  const disposers = []
  const primitives = Object.fromEntries(['Button', 'Input', 'Switch', 'Menu', 'Checkbox', 'Tag', 'StateDot', 'IconPlusOutlineRegular', 'IconChevronDownOutlineRegular', 'IconTrashOutlineRegular'].map(name =>
    [name, props => React.createElement(name === 'Button' ? 'button' : 'span', props, props.children)]))
  primitives.Checkbox = props => {
    assert.equal(typeof props.label, 'string'); assert.equal(typeof props.checked, 'boolean')
    return React.createElement('span', props, props.label)
  }
  primitives.Modal = props => props.open ? React.createElement('section', { role: 'dialog', 'aria-label': props.title, onClose: props.onClose }, props.children, props.footer) : null
  primitives.Toast = props => React.createElement('div', { role: 'alert' }, props.text)
  runInNewContext(await readFile(new URL('../lib/client/index.js', import.meta.url), 'utf8'), {
    window: { localStorage, __ModuleLoader__: { load(entry) { module = entry.factory(name => name === 'react' ? React : primitives) } } },
    document: { createElement: () => ({ dataset: {}, remove() {} }), head: { appendChild() {} } },
    navigator: { userAgent: 'synthetic-browser' },
    structuredClone, setInterval, clearInterval, setTimeout: options.setTimeout || setTimeout,
    clearTimeout: options.clearTimeout || clearTimeout, crypto: { randomUUID },
  })
  const snapshot = { status: 'ready', writable: true, revision: 1, value: Config(options.config || {}).get() }
  const listeners = new Set()
  let currentSnapshot = snapshot
  const form = { subscribe: listener => { listeners.add(listener); return () => listeners.delete(listener) }, getSnapshot: () => currentSnapshot, mutate: options.mutate || (async () => true) }
  const ctx = {
    effect(fn) { disposers.push(fn()) }, connection: { rpc },
    locale: { register(_namespace, values) { dictionary = values.zh; return () => {} }, bind: () => key => dictionary[key] },
    configForms: { get: () => form, whileServed(_names, fn) { fn(); return () => {} } },
    slots: { inject(_slot, fn) { return fn() }, register(spec, component) { if (spec.name === "tool.call.toolview") toolCards.set(spec.key, { component, props: spec.inject() }); else { Card = component; cardProps = spec.inject(); } return () => {} } },
  }
  module.apply(ctx)
  let renderer
  await act(async () => { const selected = options.tool ? toolCards.get(options.tool.name) : { component: Card, props: cardProps }; renderer = create(React.createElement(selected.component, { ...selected.props, toolName: options.tool?.name, ...options.tool?.props })) })
  return { renderer, updateConfig: config => {
    currentSnapshot = { ...currentSnapshot, revision: currentSnapshot.revision + 1, value: Config(config).get() }
    for (const listener of listeners) listener()
  }, close: () => { act(() => renderer.unmount()); for (const dispose of disposers.reverse()) dispose?.() } }
}

test('stale platform metadata shows a retry and never starts a login with missing methods', async () => {
  let ready = false; const calls = []
  const definitions = JSON.parse(await readFile(new URL('../lib/platforms.json', import.meta.url), 'utf8'))
  const mounted = await mount({ async call(_channel, endpoint) { calls.push(endpoint); return ok({ state: 'logged-out', authenticated: false }) } }, {
    platforms: async () => ok(ready ? definitions : definitions.map(({ loginMethods: _methods, defaultLoginMethod: _default, ...entry }) => entry)) })
  try {
    assert(mounted.renderer.root.findAllByProps({ role: 'alert' }).some(node => node.type === 'p'))
    assert.equal(calls.length, 0)
    ready = true
    await act(async () => mounted.renderer.root.findAllByType('button').find(button => text(button.props.children) === '重新加载平台').props.onClick())
    assert(calls.includes('status')); assert(text(mounted.renderer.toJSON()).includes('淘宝扫码'))
  } finally { mounted.close() }
})

test('Hema SMS stays in private RPC, defaults to phone authorization and displays the masked pending state', async () => {
  const calls = []; let pending
  const mounted = await mount({ async call(_channel, endpoint, payload) {
    calls.push({ endpoint, payload })
    if (endpoint === 'sendCode') { assert.equal(payload.loginMethod, 'taobao-sms'); pending = { state: 'code-sent', codePending: true, maskedPhone: '138****0000', retryAfterSeconds: 60, attemptId: '11111111-1111-4111-8111-111111111111' } }
    if (endpoint === 'complete') { assert.equal(payload.loginMethod, 'taobao-sms'); assert.equal(payload.smsAttemptId, pending.attemptId); pending = { ...pending, state: 'registration-required' } }
    return ok({ authenticated: false, state: 'logged-out', pendingLogin: pending, accounts: [] })
  } })
  try {
    const root = mounted.renderer.root
    await act(async () => root.findAll(node => node.type === 'span' && node.props.className === 'waimai-choice')[0].props.onSelect('hema'))
    const phoneInput = root.findAll(node => node.type === 'span' && node.props.type === 'tel')[0]
    await act(async () => phoneInput.props.onChange({ target: { value: '13800000000' } }))
    await act(async () => root.findAllByType('button').find(button => text(button.props.children) === '获取验证码').props.onClick())
    assert(text(mounted.renderer.toJSON()).includes('138****0000'))
    const codeInput = root.findAll(node => node.type === 'span' && node.props.autoComplete === 'one-time-code')[0]
    await act(async () => codeInput.props.onChange({ target: { value: '5678' } }))
    await act(async () => root.findAllByType('button').find(button => text(button.props.children) === '登录').props.onClick())
    assert(root.findAllByType('button').find(button => text(button.props.children) === '登录').props.disabled)
    assert(!calls.some(call => call.endpoint === 'qrStart' && call.payload.platformId === 'hema'))
    const recorded = { method: '手机号短信（淘宝授权）', pending: '138****0000', sends: calls.filter(call => call.endpoint === 'sendCode').length,
      registrationStopped: root.findAllByType('button').find(button => text(button.props.children) === '登录').props.disabled }
    assert.deepEqual(recorded, JSON.parse(await readFile(new URL('./fixtures/hema-sms-view.json', import.meta.url), 'utf8')))
  } finally { mounted.close() }
})

test('Taobao cart shows an expiring server quote; creation requires explicit confirmation and payment is an official link', async () => {
  const addressRef = 'a'.repeat(64), ref = '11111111-1111-4111-8111-111111111111', calls = []
  const quoteRef = '22222222-2222-4222-8222-222222222222'
  let quantity = 0, failSubmit = false
  const cart = () => ({ platformId: 'taobao', accountId: profile.id, addressRef, shopId: 'store-17', revision: 'b'.repeat(64), quantity,
    invalidCount: 0, items: quantity ? [{ ref: 'c'.repeat(64), name: '示例饭', quantity, totalCents: 2000, available: true }] : [], totalCents: 2000 })
  const mounted = await mount({ async call(_channel, endpoint) {
    if (endpoint === 'status') return ok({ authenticated: true, state: 'logged-in', viewAccountRef: ref, accounts: [{ ref, externalId: profile.id }] })
    if (endpoint === 'profile') return ok(profile)
    if (endpoint === 'nearbyShops') return ok({ accountId: profile.id, addressRef, shops: [{ id: 'store-17', name: '示例店' }], nextCursor: null })
    if (endpoint === 'probeMenu') return ok({ accountId: profile.id, addressRef, shopId: 'store-17', categories: [{ id: 'main', name: '主食', items: [
      { id: 'food-1', name: '示例饭', description: '', imageUrl: null, price: '20', availability: 'available', tips: [], options: [] }] }] })
    throw Error('unexpected request')
  } }, { config: { dryRun: false }, addresses: async () => ok({ accountId: profile.id, selectedRef: addressRef,
    addresses: [{ ref: addressRef, address: '示例地址', usable: true }] }), trade: async (endpoint, payload) => {
      calls.push({ endpoint, payload }); assert.equal(payload.accountRef, ref)
      if (endpoint === 'tradeHistory') return ok({ accountId: profile.id, attempts: [] })
      if (endpoint === 'cart') return ok(cart())
      if (endpoint === 'cartChange') { assert.equal(payload.itemId, 'food-1'); quantity++; return ok(cart()) }
      if (endpoint === 'checkout') return ok({ ...cart(), merchant: '示例店', address: { address: '示例地址', contact: '示例用户', maskedPhone: '130****0000' },
        items: [{ name: '示例饭', quantity: 1, priceCents: 2000 }], fees: [{ name: '配送费', amountCents: 100 }], discountCents: 0,
        totalCents: 2100, deliveryTime: '明天 10:00 开始配送', quoteRef, expiresAt: Date.now() + 120000, previewOnly: false, maxOrderCents: 3500 })
      if (endpoint === 'submit') return failSubmit ? { ok: false, error: { code: 'order-unknown', message: '下单结果未确认，勿重复提交' } }
        : ok({ ...cart(), orderRef: quoteRef, orderIds: ['123456'], amountCents: 2100, paymentUrl: 'https://r.ele.me/payment?synthetic=1', paymentStatus: 'unconfirmed' })
      throw Error('unexpected trade operation')
    } })
  try {
    const root = mounted.renderer.root, button = label => root.findAllByType('button').find(value => text(value.props.children) === label)
    await act(async () => button('点餐').props.onClick())
    await act(async () => button('查看菜单').props.onClick())
    await act(async () => button('加入购物车').props.onClick())
    assert.equal(calls.filter(call => call.endpoint === 'cartChange').length, 1)
    assert(text(mounted.renderer.toJSON()).includes('已加入购物车'))
    await act(async () => root.findByProps({ className: 'waimai-cart-trigger' }).props.onClick())
    await act(async () => button('去结算').props.onClick())
    assert.equal(button('确认创建订单').props.disabled, true)
    assert(text(mounted.renderer.toJSON()).includes('实付: ¥21.00'))
    assert(text(mounted.renderer.toJSON()).includes('明天 10:00 开始配送'))
    const confirm = () => root.findAll(node => node.type === 'span' && node.props.label === '我已核对商品、配送地址、时间和实付金额')[0]
    await act(async () => confirm().props.onChange(true))
    assert.equal(button('确认创建订单').props.disabled, false)
    await act(async () => { button('确认创建订单').props.onClick(); button('确认创建订单').props.onClick() })
    assert.equal(calls.filter(call => call.endpoint === 'submit').length, 1)
    assert.deepEqual(JSON.parse(JSON.stringify(calls.find(call => call.endpoint === 'submit').payload)), { platformId: 'taobao', accountRef: ref, quoteRef, confirmed: true, confirmedCents: 2100, manualConfirmation: true, maxAmountCents: 3500 })
    assert.equal(root.findByType('a').props.href, 'https://r.ele.me/payment?synthetic=1')
    assert(!calls.some(call => /pay/.test(call.endpoint)))
    assert.equal(button('去结算').props.disabled, true)
    await act(async () => button('刷新购物车').props.onClick())
    failSubmit = true
    await act(async () => button('去结算').props.onClick())
    await act(async () => confirm().props.onChange(true))
    await act(async () => button('确认创建订单').props.onClick())
    assert(text(mounted.renderer.toJSON()).includes('勿重复提交'))
    assert(!button('确认创建订单'))
  } finally { mounted.close() }
})

test('specifications require a variant and mandatory choices before adding; cart feedback stays visible and the cart opens in a modal', async () => {
  const ref = '11111111-1111-4111-8111-111111111111', addressRef = 'a'.repeat(64), calls = []
  const variantRefs = ['b'.repeat(64), 'c'.repeat(64)], choiceRefs = ['d'.repeat(64), 'e'.repeat(64)]
  let quantity = 0, failure = false; const changePending = deferred()
  const cart = () => ({ platformId: 'taobao', accountId: profile.id, addressRef, shopId: 'store-17', revision: 'f'.repeat(64),
    quantity, totalCents: quantity * 1500, invalidCount: 0, items: quantity ? [{ ref: 'g'.repeat(64), name: '示例奶茶', specification: '标准杯 · 少冰', quantity, totalCents: 1500 }] : [] })
  const mounted = await mount({ async call(_channel, endpoint) {
    if (endpoint === 'status') return ok({ authenticated: true, state: 'logged-in', viewAccountRef: ref, accounts: [{ ref, nickname: profile.nickname }] })
    if (endpoint === 'profile') return ok(profile)
    if (endpoint === 'nearbyShops') return ok({ accountId: profile.id, addressRef, shops: [{ id: 'store-17', name: '示例店铺' }], nextCursor: null })
    if (endpoint === 'probeMenu') return ok({ accountId: profile.id, addressRef, shopId: 'store-17', categories: [{ id: 'drinks', name: '饮品', items: [{ id: 'food-1',
      name: '示例奶茶', description: '', price: '15', availability: 'available', requiresSelection: true, options: [], tips: [] }] }] })
    throw Error('unexpected read')
  } }, { addresses: async () => ok({ accountId: profile.id, selectedRef: addressRef, addresses: [{ ref: addressRef, address: '示例地址', usable: true }] }),
    trade: async (endpoint, payload) => {
      calls.push({ endpoint, payload })
      if (endpoint === 'tradeHistory') return ok({ accountId: profile.id, attempts: [] })
      if (endpoint === 'cart') return ok(cart())
      if (endpoint === 'itemOptions') return ok({ ...cart(), name: '示例奶茶', itemId: 'food-1', selectionRef: ref, minimumQuantity: 1,
        variants: [{ ref: variantRefs[0], name: '大杯', priceCents: 1700, available: true }, { ref: variantRefs[1], name: '标准杯', priceCents: 1500, available: true }],
        groups: [{ ref: 'temperature', name: '温度', minimum: 1, maximum: 1, choices: [{ ref: choiceRefs[0], name: '少冰', available: true }, { ref: choiceRefs[1], name: '热', available: false }] }] })
      if (endpoint === 'cartChange') {
        if (failure) return changePending.promise
        assert.equal(payload.variantRef, variantRefs[1]); assert.deepEqual(Array.from(payload.choiceRefs), [choiceRefs[0]]); assert.equal(payload.quantity, 1)
        quantity++; return ok(cart())
      }
      throw Error('unexpected trade')
    } })
  try {
    const root = mounted.renderer.root, button = label => root.findAllByType('button').find(value => text(value.props.children) === label)
    await act(async () => button('点餐').props.onClick()); await act(async () => button('查看菜单').props.onClick())
    assert.equal(root.findAllByProps({ role: 'dialog' }).length, 0)
    await act(async () => button('选规格').props.onClick())
    assert.equal(button('加入购物车').props.disabled, true); assert.equal(button('热').props.disabled, true)
    await act(async () => button('标准杯 · ¥15.00').props.onClick()); assert.equal(button('加入购物车').props.disabled, true)
    await act(async () => button('少冰').props.onClick()); assert.equal(button('加入购物车').props.disabled, false)
    const fixture = JSON.parse(await readFile(new URL('./fixtures/cart-specifications.expected.json', import.meta.url), 'utf8'))
    assert.equal(root.findByProps({ role: 'dialog' }).props['aria-label'], fixture.dialog)
    assert.deepEqual(fixture.choices.filter(label => button(label)).length, fixture.choices.length)
    await act(async () => button('加入购物车').props.onClick())
    assert.equal(root.findAllByProps({ role: 'dialog' }).length, 0)
    assert(text(mounted.renderer.toJSON()).includes(fixture.readyFeedback))
    assert.equal(root.findByProps({ className: 'waimai-cart-trigger' }).findAll(node => ['span', 'strong'].includes(node.type)).map(node => text(node.props.children)).join(''), fixture.floatingCart)
    await act(async () => root.findByProps({ className: 'waimai-cart-trigger' }).props.onClick())
    assert.equal(root.findByProps({ role: 'dialog' }).props['aria-label'], '购物车')
    assert(text(mounted.renderer.toJSON()).includes('标准杯 · 少冰'))
    await act(async () => root.findByProps({ role: 'dialog' }).props.onClose())
    failure = true
    await act(async () => button('选规格').props.onClick()); await act(async () => button('标准杯 · ¥15.00').props.onClick()); await act(async () => button('少冰').props.onClick())
    const add = button('加入购物车'); await act(async () => { add.props.onClick(); add.props.onClick() })
    assert.equal(button('正在加入…').props.disabled, true)
    assert.equal(calls.filter(call => call.endpoint === 'cartChange').length, 2)
    await act(async () => changePending.resolve({ ok: false, error: { code: 'cart-result-unconfirmed', message: '数量未确认，请刷新购物车核对' } }))
    assert.equal(root.findByProps({ role: 'dialog' }).props['aria-label'], '购物车')
    assert(text(mounted.renderer.toJSON()).includes('数量未确认'))
    assert(!text(mounted.renderer.toJSON()).includes('已加入购物车'))
    assert.equal(quantity, 1)
    assert(!calls.some(call => ['checkout', 'submit'].includes(call.endpoint)))
  } finally { mounted.close() }
})

test('Taobao QR renders in the private plugin page, preserves the current account until linked and cancels on tab change', async () => {
  const calls = [], attemptId = '11111111-1111-4111-8111-111111111111'
  const mounted = await mount({ async call(_channel, endpoint, payload) {
    calls.push({ endpoint, payload })
    if (endpoint === 'status') return ok({ authenticated: true, state: 'logged-in', loginMethod: 'sms' })
    if (endpoint === 'accountBegin') return ok({ authenticated: true, state: 'logged-in', loginMethod: 'sms', addingAccount: true })
    if (endpoint === 'profile') return ok(profile)
    if (endpoint === 'qrStart') return ok({ authenticated: true, state: 'logged-in', addingAccount: true, qr: { attemptId, state: 'business-unconfirmed', image: 'data:image/png;base64,synthetic', pollAfterMs: 2000 } })
    if (endpoint === 'qrCancel') return ok({ qr: { attemptId, state: 'canceled' } })
    return ok({ accountId: profile.id, orders: [], nextCursor: null })
  } })
  try {
    const root = mounted.renderer.root
    const click = label => root.findAllByType('button').find(button => text(button.props.children) === label).props.onClick()
    assert(!root.findAllByType('button').some(button => text(button.props.children) === '获取淘宝登录二维码'))
    await act(async () => click('添加账号'))
    const image = root.findAllByType('img').find(value => value.props.alt === '淘宝扫码')
    assert.equal(image.props.src, 'data:image/png;base64,synthetic')
    assert(text(mounted.renderer.toJSON()).includes('正在完成闪购登录'))
    assert(text(mounted.renderer.toJSON()).includes(profile.nickname))
    assert(!calls.some(value => value.endpoint === 'qrPoll'))
    await act(async () => click('历史订单'))
    assert(!root.findAllByType('img').some(value => value.props.alt === '淘宝扫码'))
    assert(calls.some(value => value.endpoint === 'qrCancel' && value.payload.attemptId === attemptId))
  } finally { mounted.close() }
})

test('opening QR sign-in creates the code and automatically completes business verification without a check button', async () => {
  const attemptId = '11111111-1111-4111-8111-111111111111', timers = new Map(), calls = []
  let timerId = 0, polls = 0
  const mounted = await mount({ async call(_channel, endpoint) {
    calls.push(endpoint)
    if (endpoint === 'status') return ok({ authenticated: true, state: 'logged-in', loginMethod: 'sms' })
    if (endpoint === 'accountBegin') return ok({ authenticated: true, state: 'logged-in', addingAccount: true })
    if (endpoint === 'profile') return ok(profile)
    if (endpoint === 'qrStart') return ok({ authenticated: true, state: 'logged-in', addingAccount: true,
      qr: { attemptId, state: 'waiting', image: 'data:image/png;base64,synthetic', expiresAt: Date.now() + 180000, pollAfterMs: 2000 } })
    if (endpoint === 'qrPoll') {
      if (++polls === 2) return { ok: false, error: { code: 'temporary-failure', message: '请求暂时失败' } }
      const linked = polls === 3
      return ok({ authenticated: true, state: 'logged-in', addingAccount: !linked,
        qr: { attemptId, state: linked ? 'linked' : 'business-unconfirmed', authorizationExpiresAt: Date.now() + 60000, pollAfterMs: 2000 } })
    }
    if (endpoint === 'qrCancel') return ok({ qr: { attemptId, state: 'canceled' } })
    return ok({ accountId: profile.id, orders: [], nextCursor: null })
  } }, { setTimeout: fn => { const id = ++timerId; timers.set(id, fn); return id }, clearTimeout: id => timers.delete(id) })
  const tick = async () => { const [id, fn] = timers.entries().next().value; timers.delete(id); await act(async () => fn()) }
  try {
    const root = mounted.renderer.root
    await act(async () => root.findAllByType('button').find(button => text(button.props.children) === '添加账号').props.onClick())
    assert.equal(calls.filter(value => value === 'qrStart').length, 1)
    assert(!root.findAllByType('button').some(button => text(button.props.children) === '检查闪购授权'))
    await tick()
    assert(text(mounted.renderer.toJSON()).includes('正在完成闪购登录'))
    assert(!text(mounted.renderer.toJSON()).includes('尚未检查登录状态'))
    assert.deepEqual({ steps: root.findByProps({ className: 'waimai-qr-steps' }).findAllByType('li').map(node => text(node.props.children)),
      status: text(root.findByProps({ className: 'waimai-qr-status' }).props.children),
      actions: root.findByProps({ 'aria-label': '淘宝扫码', 'aria-busy': false }).findAllByType('button').map(node => text(node.props.children)) },
      JSON.parse(await readFile(new URL('./fixtures/qr-flow.json', import.meta.url), 'utf8')))
    await tick()
    assert(text(mounted.renderer.toJSON()).includes('自动重试'))
    await tick()
    assert.equal(polls, 3); assert.equal(timers.size, 0)
    assert(text(mounted.renderer.toJSON()).includes(profile.nickname))
  } finally { mounted.close() }
})

test('account labels keep IDs in details and dropdown changes scope orders to the chosen account', async () => {
  const first = '11111111-1111-4111-8111-111111111111', second = '22222222-2222-4222-8222-222222222222'
  const calls = [], accounts = [{ ref: first, externalId: profile.id, nickname: profile.nickname, loginMethod: 'sms' }, { ref: second, externalId: '67890', nickname: '第二账号', loginMethod: 'sms' }]
  const rpc = { async call(_channel, endpoint, payload) {
    calls.push({ endpoint, payload })
    const ref = payload.accountRef || first
    if (endpoint === 'status' || endpoint === 'accountView') return ok({ authenticated: true, state: 'logged-in', loginMethod: 'sms', viewAccountRef: ref, accounts })
    if (endpoint === 'profile') return ok(ref === first ? profile : { ...profile, id: '67890', nickname: '第二账号' })
    return ok({ accountId: ref === first ? profile.id : '67890', orders: [{ ...order, merchantName: ref === first ? '第一账号的店' : '第二账号的店' }], nextCursor: null })
  } }
  const a = await mount(rpc), b = await mount(rpc)
  try {
    const selector = a.renderer.root.findAll(node => node.props.selectedId === first && Array.isArray(node.props.items)).find(node => node.type === 'span')
    assert.deepEqual(JSON.parse(JSON.stringify(selector.props.items)), JSON.parse(await readFile(new URL('./fixtures/account-selector.json', import.meta.url), 'utf8')))
    assert(selector.props.items.every(item => !/12345|67890/.test(item.label)))
    await act(async () => selector.props.onSelect(second))
    assert(text(a.renderer.toJSON()).includes('第二账号'))
    assert(text(b.renderer.toJSON()).includes('账号 ID: 12345'))
    await act(async () => a.renderer.root.findAllByType('button').find(button => text(button.props.children) === '历史订单').props.onClick())
    assert(text(a.renderer.toJSON()).includes('第二账号的店'))
    assert(!text(a.renderer.toJSON()).includes('第一账号的店'))
    assert.equal(calls.findLast(value => value.endpoint === 'orders').payload.accountRef, second)
    assert(!calls.some(value => value.endpoint === 'accountSelect'))
  } finally { a.close(); b.close() }
})

test('adding a SMS account retains the saved account while entering the new phone and code', async () => {
  let adding = false, pending
  const calls = [], first = '11111111-1111-4111-8111-111111111111'
  const mounted = await mount({ async call(_channel, endpoint, payload) {
    calls.push({ endpoint, payload })
    if (endpoint === 'profile') return ok(profile)
    if (endpoint === 'accountBegin') { adding = true; pending = { state: 'not-checked', codePending: false } }
    if (endpoint === 'sendCode') pending = { state: 'code-sent', codePending: true, maskedPhone: '139****0000', retryAfterSeconds: 60 }
    if (endpoint === 'accountCancel') { adding = false; pending = undefined }
    return ok({ authenticated: true, state: 'logged-in', loginMethod: 'sms', viewAccountRef: first,
      accounts: [{ ref: first, externalId: profile.id, nickname: profile.nickname }], addingAccount: adding, pendingLogin: pending })
  } })
  try {
    const root = mounted.renderer.root, click = label => root.findAllByType('button').find(button => text(button.props.children) === label).props.onClick()
    await act(async () => click('添加账号'))
    await act(async () => click('手机号短信'))
    let phone = root.findAll(node => node.props.type === 'tel').find(node => node.type === 'span')
    act(() => phone.props.onChange({ target: { value: '13900000000' } }))
    await act(async () => click('获取验证码'))
    phone = root.findAll(node => node.props.type === 'tel').find(node => node.type === 'span')
    assert.equal(phone.props.value, '13900000000')
    assert(text(mounted.renderer.toJSON()).includes('账号 ID: 12345'))
    assert(text(mounted.renderer.toJSON()).includes('139****0000'))
    assert.equal(calls.find(value => value.endpoint === 'sendCode').payload.accountRef, first)
    await act(async () => click('取消添加'))
    assert(!root.findAll(node => node.props.type === 'tel').some(node => node.type === 'span'))
  } finally { mounted.close() }
})

test('browser platform and account choices survive remounts without changing other open views', async () => {
  const first = '11111111-1111-4111-8111-111111111111', second = '22222222-2222-4222-8222-222222222222'
  const entries = new Map(), storage = { getItem: key => entries.get(key) ?? null, setItem: (key, value) => entries.set(key, value) }, calls = []
  const rpc = { async call(_channel, endpoint, payload) {
    calls.push({ endpoint, payload })
    const ref = payload.accountRef || first
    if (endpoint === 'status' || endpoint === 'accountView') return ok({ authenticated: true, state: 'logged-in', viewAccountRef: ref,
      accounts: [{ ref: first, nickname: '第一账号' }, { ref: second, nickname: '第二账号' }] })
    if (endpoint === 'profile') return ok({ ...profile, nickname: ref === second ? '第二账号' : '第一账号' })
    throw Error('Unexpected request')
  } }
  let a = await mount(rpc, { storage }), b = await mount(rpc, { storage })
  try {
    const pick = (mounted, id, value) => mounted.renderer.root.findAll(node => node.type === 'span' && node.props.selectedId === id && Array.isArray(node.props.items))[0].props.onSelect(value)
    await act(async () => pick(a, first, second))
    assert(text(b.renderer.toJSON()).includes('第一账号')); assert(!text(b.renderer.toJSON()).includes('第二账号登录'))
    const persisted = JSON.parse(entries.get('dsh-waimai.view.v1'))
    assert.deepEqual(persisted, JSON.parse(await readFile(new URL('./fixtures/view-preference.json', import.meta.url), 'utf8')))
    assert(!entries.get('dsh-waimai.view.v1').includes(profile.id))
    a.close(); calls.length = 0; a = await mount(rpc, { storage })
    assert.equal(calls[0].payload.accountRef, second)
    assert(text(a.renderer.toJSON()).includes('第二账号'))
    await act(async () => pick(a, 'taobao', 'jd'))
    a.close(); calls.length = 0; a = await mount(rpc, { storage })
    assert(text(a.renderer.toJSON()).includes('该平台尚未接入'))
    assert.equal(calls.length, 0)
    await act(async () => pick(a, 'jd', 'taobao'))
    assert.equal(calls[0].payload.accountRef, second)
    assert(text(a.renderer.toJSON()).includes('第二账号'))
  } finally { a.close(); b.close() }
})

test('removed account and platform preferences use verified defaults while failed switches retain the previous choice', async () => {
  const first = '11111111-1111-4111-8111-111111111111', removed = '22222222-2222-4222-8222-222222222222'
  let stored = JSON.stringify({ version: 1, platformId: 'removed', accounts: { taobao: removed } })
  const calls = [], storage = { getItem: () => stored, setItem: (_key, value) => { stored = value } }
  const mounted = await mount({ async call(_channel, endpoint, payload) {
    calls.push({ endpoint, payload })
    if (endpoint === 'accountView' || endpoint === 'status' && payload.accountRef) return { ok: false, error: { code: 'account-missing', message: '账号已移除' } }
    if (endpoint === 'status') return ok({ authenticated: true, state: 'logged-in', viewAccountRef: first, accounts: [{ ref: first }] })
    if (endpoint === 'profile') return ok(profile)
    throw Error('Unexpected request')
  } }, { storage })
  try {
    assert.equal(calls[0].payload.accountRef, removed)
    assert.equal(calls[1].payload.accountRef, undefined)
    assert(text(mounted.renderer.toJSON()).includes('账号 ID: 12345'))
    assert.deepEqual(JSON.parse(stored), { version: 1, platformId: 'taobao', accounts: { taobao: first } })
    const selector = mounted.renderer.root.findAll(node => node.type === 'span' && node.props.selectedId === first && Array.isArray(node.props.items))[0]
    await act(async () => selector.props.onSelect(removed))
    assert(text(mounted.renderer.toJSON()).includes('账号已移除'))
    assert.equal(JSON.parse(stored).accounts.taobao, first)
  } finally { mounted.close() }
})

test('unreadable browser storage does not prevent account selection and reports a persistence failure', async () => {
  const first = '11111111-1111-4111-8111-111111111111', second = '22222222-2222-4222-8222-222222222222'
  const mounted = await mount({ async call(_channel, endpoint, payload) {
    if (endpoint === 'status' || endpoint === 'accountView') return ok({ authenticated: true, state: 'logged-in', viewAccountRef: payload.accountRef || first,
      accounts: [{ ref: first }, { ref: second }] })
    if (endpoint === 'profile') return ok(profile)
    throw Error('Unexpected request')
  } }, { storage: { getItem() { throw Error('Storage denied') }, setItem() { throw Error('Storage denied') } } })
  try {
    const selector = mounted.renderer.root.findAll(node => node.type === 'span' && node.props.selectedId === first && Array.isArray(node.props.items))[0]
    await act(async () => selector.props.onSelect(second))
    assert(text(mounted.renderer.toJSON()).includes('无法记住此次选择'))
    assert(mounted.renderer.root.findAll(node => node.type === 'span' && node.props.selectedId === second).length)
  } finally { mounted.close() }
})

test('corrupt preferences do not reach the Host, and a failed restore does not silently query another account', async () => {
  const ref = '22222222-2222-4222-8222-222222222222'
  for (const [stored, expectedRef] of [['invalid-json', undefined], [JSON.stringify({ version: 1, accounts: { taobao: 'not-a-reference' } }), undefined],
    [JSON.stringify({ version: 2, accounts: { taobao: ref } }), undefined], [JSON.stringify({ version: 1, platformId: 'taobao', accounts: { taobao: ref } }), ref]]) {
    const calls = [], mounted = await mount({ async call(_channel, endpoint, payload) {
      calls.push({ endpoint, payload })
      return { ok: false, error: { code: 'verification-required', message: '平台需要验证' } }
    } }, { storage: { getItem: () => stored, setItem() { throw Error('A failed restore must not write preferences') } } })
    try {
      assert.equal(calls.length, 1); assert.equal(calls[0].payload.accountRef, expectedRef)
      assert(text(mounted.renderer.toJSON()).includes('平台需要验证'))
    } finally { mounted.close() }
  }
})

test('the settings page renders avatar, account details and orders, replaces pages and clears data on logout', async () => {
  let signedIn = true
  const calls = []
  const mounted = await mount({ async call(_channel, endpoint, payload) {
    calls.push({ endpoint, payload })
    if (endpoint === 'status') return ok({ authenticated: signedIn, state: signedIn ? 'logged-in' : 'logged-out' })
    if (endpoint === 'profile') return ok(profile)
    return ok({ accountId: profile.id, orders: [{ ...order, id: payload.cursor ? 'older-order' : order.id, merchantName: payload.cursor ? '更早的店' : order.merchantName }],
      nextCursor: payload.cursor ? null : { pageNum: 1, fromTime: order.createdAt } })
  } })
  try {
    const root = mounted.renderer.root
    const account = root.findByProps({ className: 'waimai-account' })
    assert.deepEqual(accountTree(account), JSON.parse(await readFile(new URL('./fixtures/account-card.json', import.meta.url), 'utf8')))
    const avatar = root.findByType('img')
    assert.equal(avatar.props.src, profile.avatarUrl)
    assert.equal(avatar.props.referrerPolicy, 'no-referrer')
    assert.equal(avatar.props.alt, '用户头像')
    assert(text(mounted.renderer.toJSON()).includes('账号 ID: 12345'))
    await act(async () => root.findAllByType('button').find(button => text(button.props.children) === '历史订单').props.onClick())
    assert(text(mounted.renderer.toJSON()).includes('示例饭 × 2'))
    assert(text(mounted.renderer.toJSON()).includes('¥25.50'))
    await act(async () => root.findAllByType('button').find(button => text(button.props.children) === '下一页').props.onClick())
    assert(text(mounted.renderer.toJSON()).includes('更早的店'))
    assert(!text(mounted.renderer.toJSON()).includes('示例店'))
    assert.equal(root.findAllByProps({ className: 'waimai-order' }).length, 1)
    assert.equal(calls.find(call => call.payload.cursor)?.payload.cursor.pageNum, 1)
    act(() => root.findByType('img').props.onError())
    assert.equal(root.findAllByType('img').length, 0)
    signedIn = false
    await act(async () => root.findAllByType('button').find(button => text(button.props.children) === '检查登录状态').props.onClick())
    assert.equal(root.findAllByProps({ className: 'waimai-account' }).length, 0)
    assert.equal(root.findAllByProps({ className: 'waimai-order' }).length, 0)
    assert(!text(mounted.renderer.toJSON()).includes(profile.maskedPhone))
  } finally { mounted.close() }
})

test('platform switching clears the account view and unavailable platforms never receive account requests', async () => {
  const calls = []
  const mounted = await mount({ async call(_channel, endpoint, payload) {
    calls.push({ endpoint, payload })
    if (endpoint === 'status') return ok({ authenticated: true, state: 'logged-in' })
    if (endpoint === 'profile') return ok(profile)
    return ok({ accountId: profile.id, orders: [], nextCursor: null })
  } })
  try {
    const root = mounted.renderer.root
    const view = { platforms: root.findAll(node => node.type === 'span' && node.props.className === 'waimai-choice')[0].props.items,
      tabs: root.findByType('nav').findAllByType('button').map(button => ({ label: text(button.props.children), selected: button.props['aria-pressed'] })) }
    assert.deepEqual(JSON.parse(JSON.stringify(view)), JSON.parse(await readFile(new URL('./fixtures/platform-card.json', import.meta.url), 'utf8')))
    assert.equal(root.findAllByProps({ className: 'waimai-account' }).length, 1)
    await act(async () => root.findAll(node => node.type === 'span' && node.props.className === 'waimai-choice')[0].props.onSelect('meituan'))
    assert.equal(root.findAllByProps({ className: 'waimai-account' }).length, 0)
    assert(!text(mounted.renderer.toJSON()).includes(profile.nickname))
    assert(text(mounted.renderer.toJSON()).includes('尚未接入'))
    assert(calls.every(call => call.payload.platformId === 'taobao'))
    await act(async () => root.findAll(node => node.type === 'span' && node.props.className === 'waimai-choice')[0].props.onSelect('jd'))
    assert(calls.every(call => call.payload.platformId === 'taobao'))
  } finally { mounted.close() }
})

test('address selection confirms the saved reference and hides addresses from another account', async () => {
  let selectedRef = null
  let accountId = profile.id
  const addressRef = 'a'.repeat(64)
  const calls = []
  const mounted = await mount({ async call(_channel, endpoint, payload) {
    calls.push({ endpoint, payload })
    if (endpoint === 'status') return ok({ authenticated: true, state: 'logged-in' })
    if (endpoint === 'profile') return ok(profile)
    if (endpoint === 'selectAddress') { selectedRef = payload.addressRef; return ok({ accountId, selectedRef }) }
    throw new Error('Unexpected request')
  } }, { addresses: async () => ok({ accountId, selectedRef, addresses: [{ ref: addressRef, address: '示例街道 示例房间', contact: '示例联系人', maskedPhone: '138****0000', label: '家', usable: true }] }) })
  try {
    const root = mounted.renderer.root
    const select = () => root.findAllByType('button').find(button => text(button.props.children) === '使用此地址')
    assert.equal(select().props.disabled, false)
    await act(async () => select().props.onClick())
    assert.equal(select(), undefined)
    assert(text(mounted.renderer.toJSON()).includes('当前配送地址'))
    assert.deepEqual(JSON.parse(JSON.stringify(calls.find(call => call.endpoint === 'selectAddress').payload)), { platformId: 'taobao', accountId: profile.id, addressRef })
    accountId = '999'
    await act(async () => root.findAllByType('button').find(button => text(button.props.children) === '刷新地址').props.onClick())
    assert(!text(mounted.renderer.toJSON()).includes('示例街道'))
    assert(text(mounted.renderer.toJSON()).includes('账号已变化'))
  } finally { mounted.close() }
})

test('ordering shows nearby server merchants after address selection and surfaces verification without purchase actions', async () => {
  const addressRef = 'a'.repeat(64)
  const mounted = await mount({ async call(_channel, endpoint) {
    if (endpoint === 'status') return ok({ authenticated: true, state: 'logged-in' })
    if (endpoint === 'profile') return ok(profile)
    if (endpoint === 'nearbyShops') return ok({ accountId: profile.id, addressRef, shops: [{ id: 'synthetic-shop', name: '示例店' }], nextCursor: null })
    if (endpoint === 'probeMenu') return { ok: false, error: { code: 'verification-required', message: '平台要求人工验证' } }
    throw new Error('Unexpected request')
  } }, { addresses: async () => ok({ accountId: profile.id, selectedRef: addressRef,
    addresses: [{ ref: addressRef, address: '示例地址', contact: '示例联系人', maskedPhone: '', usable: true }] }) })
  try {
    const root = mounted.renderer.root
    await act(async () => root.findAllByType('button').find(button => text(button.props.children) === '点餐').props.onClick())
    assert(text(mounted.renderer.toJSON()).includes('示例店'))
    await act(async () => root.findAllByType('button').find(button => text(button.props.children) === '查看菜单').props.onClick())
    assert(text(mounted.renderer.toJSON()).includes('平台要求人工验证'))
    assert(!root.findAllByType('button').some(button => ['创建订单', '支付'].includes(text(button.props.children))))
    assert(!root.findAllByType('button').some(button => text(button.props.children) === '去结算'))
  } finally { mounted.close() }
})

test('ordering requires an address, edits it in place and discards late menus when it changes', async () => {
  const refs = ['a'.repeat(64), 'b'.repeat(64)], pending = deferred(), calls = []
  let selectedRef = null
  const mounted = await mount({ async call(_channel, endpoint, payload) {
    calls.push({ endpoint, payload })
    if (endpoint === 'status') return ok({ authenticated: true, state: 'logged-in' })
    if (endpoint === 'profile') return ok(profile)
    if (endpoint === 'selectAddress') { selectedRef = payload.addressRef; return ok({ accountId: profile.id, selectedRef }) }
    if (endpoint === 'nearbyShops' || endpoint === 'recentShops') return ok({ accountId: profile.id, addressRef: selectedRef,
      shops: [{ id: 'synthetic-shop', name: selectedRef === refs[0] ? '旧地址店铺' : '新地址店铺' }], nextCursor: null })
    if (endpoint === 'probeMenu') return pending.promise
    throw Error('Unexpected request')
  } }, { addresses: async () => ok({ accountId: profile.id, selectedRef,
    addresses: refs.map((ref, i) => ({ ref, address: `示例地址${i}`, contact: '联系人', maskedPhone: '', usable: true })) }) })
  try {
    const root = mounted.renderer.root, click = label => root.findAllByType('button').find(button => text(button.props.children) === label).props.onClick()
    await act(async () => click('点餐'))
    assert(text(mounted.renderer.toJSON()).includes('先选择配送地址'))
    assert(!calls.some(value => ['nearbyShops', 'recentShops'].includes(value.endpoint)))
    await act(async () => click('使用此地址'))
    assert(text(mounted.renderer.toJSON()).includes('旧地址店铺'))
    let read
    act(() => { read = click('查看菜单') })
    await act(async () => click('使用此地址'))
    assert(!text(mounted.renderer.toJSON()).includes('旧地址店铺'))
    assert(text(mounted.renderer.toJSON()).includes('新地址店铺'))
    await act(async () => { pending.resolve(ok({ accountId: profile.id, addressRef: refs[0], shopId: 'synthetic-shop', categories: [{ id: 'old', name: '旧菜单', items: [] }] })); await read })
    assert(!text(mounted.renderer.toJSON()).includes('旧菜单'))
    assert.equal(calls.findLast(value => value.endpoint === 'nearbyShops').payload.addressRef, refs[1])
  } finally { mounted.close() }
})

test('an all-sponsored page explains filtering and keeps the next page usable', async () => {
  const addressRef = 'a'.repeat(64), cursors = [], cursor = { offset: 10, rankId: 'synthetic', addressRef, accountId: profile.id }
  const mounted = await mount({ async call(_channel, endpoint, payload) {
    if (endpoint === 'status') return ok({ authenticated: true, state: 'logged-in' })
    if (endpoint === 'profile') return ok(profile)
    if (endpoint === 'nearbyShops') {
      cursors.push(payload.cursor)
      return ok({ accountId: profile.id, addressRef, shops: payload.cursor ? [{ id: 'store-17', name: '普通店铺', isAd: false }] : [],
        filteredAds: payload.cursor ? 0 : 10, nextCursor: payload.cursor ? null : cursor })
    }
    throw Error('Unexpected request')
  } }, { addresses: async () => ok({ accountId: profile.id, selectedRef: addressRef,
    addresses: [{ ref: addressRef, address: '示例地址', contact: '联系人', maskedPhone: '', usable: true }] }) })
  try {
    const root = mounted.renderer.root, click = label => root.findAllByType('button').find(button => text(button.props.children) === label).props.onClick()
    await act(async () => click('点餐'))
    const empty = root.find(node => node.props.className === 'waimai-empty')
    const output = { empty: text(empty), nextPage: root.findAllByType('button').filter(button => text(button.props.children) === '下一页店铺').length }
    assert.deepEqual(output, JSON.parse(await readFile(new URL('./fixtures/ads-view.json', import.meta.url), 'utf8')))
    assert(!text(mounted.renderer.toJSON()).includes('该地址暂未返回附近店铺'))
    await act(async () => click('下一页店铺'))
    assert.deepEqual(cursors[1], cursor); assert(text(mounted.renderer.toJSON()).includes('普通店铺'))
    assert(!text(mounted.renderer.toJSON()).includes('本页店铺均为推广'))
    assert.equal(root.findAllByType('tag').filter(node => text(node) === '广告').length, 0)
  } finally { mounted.close() }
})

test('menu view renders real categories, listed prices and options, filters dishes and retains data after refresh failure', async () => {
  const addressRef = 'a'.repeat(64)
  const { menuData } = await import('../lib/browse-data.js')
  const menu = menuData(JSON.parse(await readFile(new URL('./fixtures/menu.json', import.meta.url), 'utf8')), 'store-17')
  let fail = false
  const mounted = await mount({ async call(_channel, endpoint) {
    if (endpoint === 'status') return ok({ authenticated: true, state: 'logged-in' })
    if (endpoint === 'profile') return ok(profile)
    if (endpoint === 'nearbyShops') return ok({ accountId: profile.id, addressRef, shops: [{ id: 'store-17', name: '示例店' }], nextCursor: null })
    if (endpoint === 'probeMenu') return fail ? { ok: false, error: { code: 'menu-unavailable', message: '平台暂不可用' } } : ok({ ...menu, accountId: profile.id, addressRef })
    throw Error('Unexpected request')
  } }, { addresses: async () => ok({ accountId: profile.id, selectedRef: addressRef, addresses: [{ ref: addressRef, address: '示例地址', contact: '联系人', maskedPhone: '', usable: true }] }) })
  try {
    const root = mounted.renderer.root, click = label => root.findAllByType('button').find(button => text(button.props.children) === label).props.onClick()
    await act(async () => click('点餐'))
    await act(async () => click('查看菜单'))
    const cards = () => root.findAllByType('article').filter(node => node.props.className === 'waimai-food-card')
    const summary = cards().map(node => ({ name: text(node.findAllByType('strong')[0]), price: text(node.find(node => node.props.className === 'waimai-price')), options: node.findAllByType('summary').map(text) }))
    assert.deepEqual(summary, JSON.parse(await readFile(new URL('./fixtures/browse-view.json', import.meta.url), 'utf8')))
    assert(text(mounted.renderer.toJSON()).includes('已售罄'))
    const input = root.findAll(node => node.type === 'span' && node.props['aria-label'] === '搜索这家店的菜品')[0]
    act(() => input.props.onChange({ target: { value: '汤' } }))
    assert.equal(cards().length, 1)
    fail = true
    await act(async () => click('刷新菜单'))
    assert.equal(cards().length, 1); assert(text(mounted.renderer.toJSON()).includes('平台暂不可用'))
  } finally { mounted.close() }
})

test('account mismatches hide private data, and late reads after unmount cannot restore it', async () => {
  const pending = deferred()
  const mounted = await mount({ async call(_channel, endpoint) {
    if (endpoint === 'status') return ok({ authenticated: true, state: 'logged-in' })
    if (endpoint === 'profile') return ok(profile)
    return pending.promise
  } })
  try {
    await act(async () => mounted.renderer.root.findAllByType('button').find(button => text(button.props.children) === '历史订单').props.onClick())
    await act(async () => pending.resolve(ok({ accountId: '999', orders: [order], nextCursor: null })))
    assert.equal(mounted.renderer.root.findAllByProps({ className: 'waimai-account' }).length, 0)
    assert.equal(mounted.renderer.root.findAllByProps({ className: 'waimai-order' }).length, 0)
    assert(text(mounted.renderer.toJSON()).includes('账号已变化'))
  } finally { mounted.close() }
  const late = deferred()
  const second = await mount({ async call(_channel, endpoint) { return endpoint === 'status' ? ok({ authenticated: true, state: 'logged-in' }) : late.promise } })
  second.close()
  await act(async () => late.resolve(ok(profile)))
  assert.equal(second.renderer.toJSON(), null)
})

test('navigation retains the account context across settings and only shows login fields while adding an account', async () => {
  const first = '11111111-1111-4111-8111-111111111111', calls = []
  const mounted = await mount({ async call(_channel, endpoint, payload) {
    calls.push({ endpoint, payload })
    if (endpoint === 'status') return ok({ authenticated: true, state: 'logged-in', loginMethod: 'taobao-qr', viewAccountRef: first,
      accounts: [{ ref: first, nickname: profile.nickname, externalId: profile.id, loginMethod: 'taobao-qr' }] })
    if (endpoint === 'profile') return ok(profile)
    return ok({ accountId: profile.id, orders: [order], nextCursor: null })
  } })
  try {
    const root = mounted.renderer.root, click = label => root.findAllByType('button').find(button => text(button.props.children) === label).props.onClick()
    assert(!root.findAll(node => node.props.type === 'tel').length)
    assert(!root.findAllByType('button').some(button => text(button.props.children) === '获取淘宝登录二维码'))
    assert(root.findAll(node => Array.isArray(node.props.items)).some(node => node.props.items.some(item => item.label.includes('淘宝扫码'))))
    await act(async () => click('点单设置'))
    assert(root.findAll(node => node.props.selectedId === first).length)
    await act(async () => click('历史订单'))
    assert.equal(calls.filter(call => call.endpoint === 'status').length, 1)
    assert.equal(calls.findLast(call => call.endpoint === 'orders').payload.accountRef, first)
    const details = root.findAllByType('details').find(node => text(node).includes(order.id))
    assert(details); assert.notEqual(details.props.open, true)
  } finally { mounted.close() }
})

test('a failed same-account history refresh keeps the last verified page and provides a retry action', async () => {
  let rejected = false
  const mounted = await mount({ async call(_channel, endpoint) {
    if (endpoint === 'status') return ok({ authenticated: true, state: 'logged-in' })
    if (endpoint === 'profile') return ok(profile)
    if (rejected) throw Error('synthetic transport failure')
    return ok({ accountId: profile.id, orders: [order], nextCursor: null })
  } })
  try {
    const root = mounted.renderer.root, click = label => root.findAllByType('button').find(button => text(button.props.children) === label).props.onClick()
    await act(async () => click('历史订单'))
    rejected = true
    await act(async () => click('刷新订单'))
    assert(text(mounted.renderer.toJSON()).includes(order.merchantName))
    assert(text(mounted.renderer.toJSON()).includes('读取失败'))
    assert.equal(root.findAllByType('button').find(button => text(button.props.children) === '刷新订单').props.disabled, false)
  } finally { mounted.close() }
})

test('advertising preference defaults to hidden and saves only the changed setting', async () => {
  let operations
  const mounted = await mount({ async call(_channel, endpoint) { return endpoint === 'profile' ? ok(profile) : ok({ authenticated: true, state: 'logged-in' }) } },
    { mutate: async ops => { operations = ops; return true } })
  try {
    const root = mounted.renderer.root
    await act(async () => root.findAllByType('button').find(button => text(button.props.children) === '点单设置').props.onClick())
    const toggle = root.findAll(node => node.type === 'span' && node.props.label === '隐藏推广店铺')[0]
    assert(toggle.props.checked)
    assert.deepEqual({ label: toggle.props.label, checked: toggle.props.checked }, JSON.parse(await readFile(new URL('./fixtures/ads-setting.json', import.meta.url), 'utf8')))
    act(() => toggle.props.onChange(false))
    await act(async () => root.findByType('form').props.onSubmit({ preventDefault() {} }))
    assert.deepEqual(structuredClone(operations), [{ op: 'set', path: ['hideSponsoredShops'], value: false }])
    assert(text(mounted.renderer.toJSON()).includes('已保存'))
  } finally { mounted.close() }
})

test('Alipay settings save only payment fields and connection checks use saved configuration without receiving a path', async () => {
  const calls = []; let operations, connection = { configured: true, available: true, version: '0.4.8', reason: null }
  const mounted = await mount({ async call(channel, endpoint, payload) {
    if (endpoint === 'paymentConnection') { calls.push({ channel, endpoint, payload }); return ok(connection) }
    return endpoint === 'profile' ? ok(profile) : ok({ authenticated: true, state: 'logged-in' })
  } }, { mutate: async ops => { operations = structuredClone(ops); return true } })
  try {
    const root = mounted.renderer.root, button = label => root.findAllByType('button').find(node => text(node.props.children) === label)
    await act(async () => button('点单设置').props.onClick())
    const input = label => root.findAll(node => node.type === 'span' && node.props['aria-label'] === label)[0]
    for (const label of ['单笔上限', '每日上限', '支付宝 CLI 绝对路径', '连接超时（毫秒）', '报价有效期（秒）']) assert.equal(input(label), undefined)
    assert.equal(root.findAllByProps({ 'aria-label': '自动支付白名单' }).length, 0)
    await act(async () => button('支付配置').props.onClick())
    assert.equal(root.findByType('form').props.hidden, false)
    assert.equal(button('支付配置').props['aria-pressed'], true)
    assert.deepEqual(root.findByType('nav').findAllByType('button').map(node => text(node.props.children)),
      ['账号与地址', '点餐', '历史订单', '自动化任务', '支付配置', '点单设置'])
    assert.equal(root.findAllByProps({ 'aria-label': '自动支付白名单' }).length, 0)
    assert(root.findAll(node => node.props.selectedId === 'manual' && node.props.className === 'waimai-choice').length)
    assert.equal(input('报价有效期（秒）').props.min, 30)
    assert.equal(input('连接超时（毫秒）').props.min, 1000)
    assert.equal(input('连接超时（毫秒）').props.max, 120000)
    assert.equal(input('六位支付宝支付密码').props.type, 'password')
    assert.equal(input('六位支付宝支付密码').props.disabled, true)
    await act(async () => input('支付宝 CLI 绝对路径').props.onChange({ target: { value: 'C:/tools/alipay-bot.exe' } }))
    await act(async () => input('连接超时（毫秒）').props.onChange({ target: { value: '45000' } }))
    await act(async () => input('单笔上限').props.onChange({ target: { value: '50' } }))
    await act(async () => input('每日上限').props.onChange({ target: { value: '100' } }))
    assert.equal(button('检查连接').props.disabled, true)
    assert(text(mounted.renderer.toJSON()).includes('请先保存再检查连接'))
    await act(async () => button('检查连接').props.onClick())
    assert.equal(calls.length, 0)
    await act(async () => root.findByType('form').props.onSubmit({ preventDefault() {} }))
    assert(operations.every(op => op.op === 'set' && op.path.length === 1))
    assert.deepEqual(Object.fromEntries(operations.map(op => [op.path[0], op.value])),
      { alipayAgentExecutable: 'C:/tools/alipay-bot.exe', alipayAgentTimeoutMs: 45000, maxOrderAmount: 50, dailyBudget: 100 })
    await act(async () => mounted.updateConfig({ alipayAgentExecutable: 'C:/tools/alipay-bot.exe', alipayAgentTimeoutMs: 45000, maxOrderAmount: 50, dailyBudget: 100 }))
    assert.equal(button('检查连接').props.disabled, false)
    await act(async () => button('检查连接').props.onClick())
    assert.deepEqual(structuredClone(calls), [{ channel: '/waimai-login', endpoint: 'paymentConnection', payload: {} }])
    assert(text(mounted.renderer.toJSON()).includes('支付宝 CLI 连接正常 · 0.4.8'))
    for (const [reason, label] of [['not-configured', '未配置支付宝 CLI'], ['invalid-path', '请填写支付宝 CLI 文件的绝对路径'],
      ['unavailable', '无法连接支付宝 CLI'], ['unexpected-version', 'CLI 版本响应无法识别']]) {
      connection = { configured: reason !== 'not-configured', available: false, version: null, reason }
      await act(async () => button('检查连接').props.onClick())
      assert(text(mounted.renderer.toJSON()).includes(label))
      assert(!text(mounted.renderer.toJSON()).includes('连接正常'))
    }
  } finally { mounted.close() }
})

test('Alipay connection checks discard stale replies and hide raw RPC errors', async () => {
  let pending = deferred(), fail = false
  const mounted = await mount({ async call(_channel, endpoint) {
    if (endpoint === 'paymentConnection') { if (fail) throw new Error('synthetic-private-error'); return pending.promise }
    return endpoint === 'profile' ? ok(profile) : ok({ authenticated: true, state: 'logged-in' })
  } })
  try {
    const root = mounted.renderer.root, button = label => root.findAllByType('button').find(node => text(node.props.children) === label)
    await act(async () => button('支付配置').props.onClick())
    await act(async () => { void button('检查连接').props.onClick() })
    assert.equal(button('正在检查…').props.disabled, true)
    await act(async () => mounted.updateConfig({ alipayAgentTimeoutMs: 40000 }))
    await act(async () => pending.resolve(ok({ configured: true, available: true, version: 'stale-version', reason: null })))
    assert(!text(mounted.renderer.toJSON()).includes('stale-version'))
    fail = true
    await act(async () => button('检查连接').props.onClick())
    assert(text(mounted.renderer.toJSON()).includes('无法连接支付宝 CLI'))
    assert(!text(mounted.renderer.toJSON()).includes('synthetic-private-error'))
  } finally { mounted.close() }
})

test('the task view shows only its platform and edits preserve tasks belonging to other platforms', async () => {
  let operations
  const config = { autoTasks: [{ id: 'other', name: '其他平台任务', platformId: 'jd' }, { id: 'current', name: '当前平台任务', platformId: 'taobao' }] }
  const mounted = await mount({ async call(_channel, endpoint) { return endpoint === 'profile' ? ok(profile) : ok({ authenticated: true, state: 'logged-in' }) } },
    { config, mutate: async ops => { operations = ops; return true } })
  try {
    const root = mounted.renderer.root, click = label => root.findAllByType('button').find(button => text(button.props.children) === label).props.onClick()
    await act(async () => click('自动化任务'))
    assert(text(mounted.renderer.toJSON()).includes('当前平台任务'))
    assert(!text(mounted.renderer.toJSON()).includes('其他平台任务'))
    await act(async () => root.findAllByType('button').find(button => button.props['aria-label'] === '编辑任务: 当前平台任务').props.onClick())
    act(() => root.findAll(node => node.type === 'span' && node.props['aria-label'] === '任务名称')[0].props.onChange({ target: { value: '修改后的任务' } }))
    await act(async () => root.findByType('form').props.onSubmit({ preventDefault() {} }))
    assert.equal(operations[0].value[0].name, '其他平台任务')
    assert.equal(operations[0].value[1].name, '修改后的任务')
    assert(!text(mounted.renderer.toJSON()).includes('白名单'))
  } finally { mounted.close() }
})


test('H5 card connects private verification, clears the payment password and reconciles without claiming success from H5', async () => {
  const accountRef = '11111111-1111-4111-8111-111111111111', h5Ref = '22222222-2222-4222-8222-222222222222'
  const calls = [], states = [], officialOrders = [{ id: '123', status: '待支付' }]
  let paid = false, submits = 0
  const mounted = await mount({ async call(_channel, method, payload) {
    calls.push({ method, payload: structuredClone(payload) })
    if (method === 'profile') return ok(profile)
    if (method === 'orders') return ok({ accountId: profile.id, orders: officialOrders })
    if (method === 'paymentStatus') return ok({ accountId: profile.id, paymentStatus: paid ? 'paid' : 'requires-verification',
      orderRef: accountRef, officialOrders })
    if (method === 'paymentH5Start') return ok({ h5Ref, state: 'requires-verification', submitted: false })
    if (method === 'paymentH5Authenticate') return ok({ h5Ref, state: payload.operation === 'sms' ? 'ready' : 'verifying', submitted: false,
      ...(payload.operation === 'sms' ? {} : { loginInput: payload.operation === 'phone' ? { kind: 'sms', codeLength: 4 } : { kind: 'phone' } }) })
    if (method === 'paymentH5Submit') {
      submits++
      if (!payload.password) return ok({ state: 'requires-password', submitted: false })
      assert.equal(payload.password, 'synthetic-password')
      return ok({ state: 'requires-reconciliation', submitted: true })
    }
    throw Error('Unexpected operation: ' + method)
  } }, { tool: { name: 'mcp__waimai__request_payment', props: { phase: 'result', sessionId: 'h5-session', callId: 'h5-call',
    block: { content: [{ type: 'text', text: JSON.stringify({ success: true, data: { view: 'payment', platformId: 'taobao', accountRef, attempts: [{ orderRef: accountRef }] } }) }] } } },
    trade: async () => ok({ accountId: profile.id, attempts: [{ orderRef: accountRef, merchant: '示例店', amountCents: 2100,
      status: 'created', orderIds: ['123'], paymentUrl: null, paymentStatus: 'requires-verification' }] }) })
  try {
    const root = mounted.renderer.root, button = label => root.findAllByType('button').find(node => text(node.props.children) === label)
    const labels = () => root.findAll(node => node.type === 'section' && node.props['aria-label'] === 'H5 后台付款')[0].findAllByType('button').map(node => text(node.props.children))
    states.push(labels())
    await act(async () => button('连接 H5 收银台').props.onClick())
    states.push(labels())
    await act(async () => root.findAll(node => node.type === 'span' && node.props['aria-label'] === '支付宝手机号')[0].props.onChange({ target: { value: '13800000000' } }))
    await act(async () => button('下一步').props.onClick())
    states.push(labels())
    await act(async () => root.findAll(node => node.type === 'span' && node.props['aria-label'] === '支付宝短信验证码')[0].props.onChange({ target: { value: '1234' } }))
    await act(async () => button('验证并连接').props.onClick())
    states.push(labels())
    await act(async () => button('确认后台付款 · ¥21.00').props.onClick())
    const input = root.findAll(node => node.type === 'span' && node.props.type === 'password')[0]
    act(() => input.props.onChange({ target: { value: 'synthetic-password' } }))
    await act(async () => button('确认后台付款 · ¥21.00').props.onClick())
    assert.equal(submits, 2)
    assert(!text(mounted.renderer.toJSON()).includes('付款已确认'))
    assert(!JSON.stringify(mounted.renderer.toJSON()).includes('synthetic-password'))
    assert.equal(button('确认后台付款 · ¥21.00'), undefined)
    assert(calls.every(call => call.payload.accountRef === accountRef))
    const submitted = calls.filter(call => call.method === 'paymentH5Submit')
    assert(submitted.every(call => call.payload.confirmedCents === 2100 && call.payload.maxAmountCents === 2100))
    states.push(labels())
    assert.deepEqual(states, JSON.parse(await readFile(new URL('./fixtures/h5-payment-view.json', import.meta.url), 'utf8')))
    paid = true
    await act(async () => button('核对官方订单状态').props.onClick())
    assert(text(mounted.renderer.toJSON()).includes('付款已确认'))
  } finally { mounted.close() }
})

test('payment settings store a shared six-digit password without shopping accounts only through private RPC and clear the input before dispatch completes', async () => {
  const calls = [], saved = deferred(), storage = [], mutations = []; let configured = false
  const mounted = await mount({ async call(channel, method, payload) {
    calls.push({ channel, method, payload: structuredClone(payload) })
    if (method === 'accountsList') return ok({ accounts: [] })
    if (method === 'paymentCredential') {
      if (payload.operation === 'save') { configured = true; return saved.promise }
      if (payload.operation === 'remove') configured = false
      return ok({ configured, writable: true })
    }
    return method === 'profile' ? ok(profile) : ok({ authenticated: true, state: 'logged-in' })
  } }, { mutate: async ops => { mutations.push(structuredClone(ops)); return true },
    storage: { getItem: () => null, setItem: (...args) => storage.push(args) } })
  try {
    const root = mounted.renderer.root, button = label => root.findAllByType('button').find(node => text(node.props.children) === label)
    await act(async () => button('支付配置').props.onClick())
    const input = () => root.findAll(node => node.type === 'span' && node.props['aria-label'] === '六位支付宝支付密码')[0]
    assert.equal(root.findAllByProps({ 'aria-label': '绑定的淘宝闪购账号' }).length, 0)
    assert.equal(input().props.autoComplete, 'new-password'); assert.equal(input().props.type, 'password')
    assert(text(mounted.renderer.toJSON()).includes('尚未设置支付密码'))
    await act(async () => input().props.onChange({ target: { value: '12345' } }))
    assert.equal(button('保存支付密码').props.disabled, true)
    await act(async () => input().props.onChange({ target: { value: '654321' } }))
    await act(async () => { button('保存支付密码').props.onClick(); button('保存支付密码').props.onClick() })
    assert.equal(input().props.value, ''); assert.equal(button('保存支付密码').props.disabled, true)
    assert.equal(calls.filter(x => x.method === 'paymentCredential' && x.payload.operation === 'save').length, 1)
    await act(async () => saved.resolve(ok({ configured: true, writable: true })))
    assert(text(mounted.renderer.toJSON()).includes('支付密码已设置'))
    assert.equal(input().props.value, '')
    await act(async () => root.findByType('form').props.onSubmit({ preventDefault() {} }))
    assert(!JSON.stringify(mutations).includes('654321')); assert(!JSON.stringify(storage).includes('654321'))
    assert(!text(mounted.renderer.toJSON()).includes('654321'))
    assert(root.findAll(node => node.type === 'span' && node.props.type === 'password').every(node => node.props.value === ''))
    const credentialCalls = calls.filter(x => x.method === 'paymentCredential')
    assert(credentialCalls.every(x => x.channel === '/waimai-login' && !Object.hasOwn(x.payload, 'platformId') && !Object.hasOwn(x.payload, 'accountRef')))
    assert.equal(credentialCalls.find(x => x.payload.operation === 'save').payload.password, '654321')
    await act(async () => button('删除已保存的密码').props.onClick())
    assert(text(mounted.renderer.toJSON()).includes('尚未设置支付密码'))
    assert.equal(calls.filter(x => x.method === 'paymentCredential' && x.payload.operation === 'remove').at(-1).payload.password, undefined)
  } finally { mounted.close() }
})

test('shared password remains configured when the order account changes and failed status never claims unset', async () => {
  const first = '11111111-1111-4111-8111-111111111111', second = '22222222-2222-4222-8222-222222222222'
  let reads = 0, fail = false
  const mounted = await mount({ async call(_channel, method, payload) {
    if (method === 'accountsList') return ok({ viewAccountRef: first, accounts: [{ ref: first, nickname: '第一账号' }, { ref: second, nickname: '第二账号' }] })
    if (method === 'paymentCredential') {
      reads++
      assert.deepEqual(structuredClone(payload), { operation: 'status' })
      if (fail) throw Error('synthetic-private-value')
      return ok({ configured: true, writable: true })
    }
    return method === 'profile' ? ok(profile) : ok({ authenticated: true, state: 'logged-in' })
  } })
  try {
    const root = mounted.renderer.root, button = label => root.findAllByType('button').find(node => text(node.props.children) === label)
    await act(async () => button('支付配置').props.onClick())
    const input = () => root.findAll(node => node.type === 'span' && node.props['aria-label'] === '六位支付宝支付密码')[0]
    const choice = () => root.findAll(node => node.type === 'span' && node.props.className === 'waimai-choice' && node.props.selectedId === first)[0]
    await act(async () => choice().props.onSelect(second))
    assert(text(mounted.renderer.toJSON()).includes('支付密码已设置'))
    assert.equal(reads, 1)
    await act(async () => input().props.onChange({ target: { value: '654321' } }))
    fail = true
    await act(async () => button('刷新支付密码状态').props.onClick())
    assert.equal(input().props.value, '')
    assert(!text(mounted.renderer.toJSON()).includes('尚未设置支付密码'))
    assert(text(mounted.renderer.toJSON()).includes('无法读取或保存支付密码'))
    assert(!text(mounted.renderer.toJSON()).includes('synthetic-private-value'))
    assert.equal(button('保存支付密码').props.disabled, true)
  } finally { mounted.close() }
})

test('unmerged legacy passwords allow explicit replacement or removal and account lookup failure does not block either', async () => {
  const calls = [], states = []
  const mounted = await mount({ async call(_channel, method, payload) {
    if (method === 'accountsList') throw Error('synthetic-private-value')
    if (method === 'paymentCredential') {
      calls.push(structuredClone(payload))
      return ok(payload.operation === 'remove' ? { configured: false, writable: true } : payload.operation === 'save' ? { configured: true, writable: true }
        : { configured: false, writable: true, migrationRequired: true })
    }
    return method === 'profile' ? ok(profile) : ok({ authenticated: true, state: 'logged-in' })
  } })
  try {
    const root = mounted.renderer.root, button = label => root.findAllByType('button').find(node => text(node.props.children) === label)
    await act(async () => button('支付配置').props.onClick())
    const section = () => root.findAll(node => node.type === 'section' && node.props['aria-label'] === '支付宝支付密码')[0]
    const input = () => section().findAll(node => node.type === 'span' && node.props.type === 'password')[0]
    states.push(section().findAllByProps({ role: 'status' }).map(node => text(node.props.children)))
    assert(!text(mounted.renderer.toJSON()).includes('尚未设置支付密码'))
    assert(!text(mounted.renderer.toJSON()).includes('synthetic-private-value'))
    assert.equal(input().props.disabled, false)
    assert.equal(button('删除已保存的密码').props.disabled, false)
    assert.deepEqual(calls, [{ operation: 'status' }])
    await act(async () => input().props.onChange({ target: { value: '654321' } }))
    await act(async () => button('保存支付密码').props.onClick())
    assert.deepEqual(calls[1], { operation: 'save', password: '654321' })
    assert.equal(input().props.value, '')
    states.push(section().findAllByProps({ role: 'status' }).map(node => text(node.props.children)))
    assert.deepEqual(states, JSON.parse(await readFile(new URL('./fixtures/payment-password-migration.json', import.meta.url), 'utf8')))
    await act(async () => button('刷新支付密码状态').props.onClick())
    assert.equal(input().props.value, '')
    assert.equal(button('删除已保存的密码').props.disabled, false)
    assert(text(mounted.renderer.toJSON()).includes('旧支付密码无法自动合并'))
    await act(async () => button('删除已保存的密码').props.onClick())
    assert.deepEqual(calls.at(-1), { operation: 'remove' })
    assert(text(mounted.renderer.toJSON()).includes('尚未设置支付密码'))
    assert(text(mounted.renderer.toJSON()).includes('已删除保存的支付密码'))
    assert(!text(mounted.renderer.toJSON()).includes('旧支付密码无法自动合并'))
    assert.equal(button('删除已保存的密码').props.disabled, true)
  } finally { mounted.close() }
})

test('leaving payment settings discards password input and a late save response cannot repopulate a remounted form', async () => {
  const ref = '11111111-1111-4111-8111-111111111111', pending = deferred()
  const mounted = await mount({ async call(_channel, method, payload) {
    if (method === 'accountsList') return ok({ activeRef: ref, accounts: [{ ref, nickname: '示例账号' }] })
    if (method === 'paymentCredential') return payload.operation === 'save' ? pending.promise : ok({ configured: false, writable: true })
    return method === 'profile' ? ok(profile) : ok({ authenticated: true, state: 'logged-in' })
  } })
  try {
    const root = mounted.renderer.root, button = label => root.findAllByType('button').find(node => text(node.props.children) === label)
    await act(async () => button('支付配置').props.onClick())
    const input = () => root.findAll(node => node.type === 'span' && node.props['aria-label'] === '六位支付宝支付密码')[0]
    await act(async () => input().props.onChange({ target: { value: '654321' } }))
    await act(async () => button('保存支付密码').props.onClick())
    await act(async () => button('点单设置').props.onClick())
    await act(async () => pending.resolve(ok({ configured: true, writable: true })))
    await act(async () => button('支付配置').props.onClick())
    assert.equal(input().props.value, '')
    assert(!text(mounted.renderer.toJSON()).includes('支付密码已保存'))
  } finally { mounted.close() }
})

test('H5 reconciliation snapshots distinguish unsent, submitted and unknown outcomes without exposing raw reasons or offering a retry', async () => {
  const cases = JSON.parse(await readFile(new URL('./fixtures/h5-reconciliation-view.json', import.meta.url), 'utf8'))
  const accountRef = '11111111-1111-4111-8111-111111111111', h5Ref = '22222222-2222-4222-8222-222222222222'
  const officialOrders = [{ id: '123', status: '待支付' }]
  for (const example of cases) {
    const calls = [], response = { state: 'requires-reconciliation', reason: example.reason,
      ...(Object.hasOwn(example, 'submitted') ? { submitted: example.submitted } : {}), h5Ref,
      verificationRequired: example.submitted === false, message: 'synthetic-private-server-message' }
    const mounted = await mount({ async call(_channel, method) {
      calls.push(method)
      if (method === 'profile') return ok(profile)
      if (method === 'orders') return ok({ accountId: profile.id, orders: officialOrders })
      if (method === 'paymentStatus') return ok({ accountId: profile.id, paymentStatus: 'requires-verification', orderRef: accountRef, officialOrders })
      if (method === 'paymentH5Start') return ok(example.submitted === false ? response : { h5Ref, state: 'ready', submitted: false })
      if (method === 'paymentH5Submit') return ok(response)
      if (method === 'paymentH5Authenticate') return ok({ state: 'requires-reconciliation', submitted: false })
      throw Error('Unexpected operation: ' + method)
    } }, { tool: { name: 'mcp__waimai__request_payment', props: { phase: 'result', sessionId: 'h5-reasons', callId: 'h5-reasons-call',
      block: { content: [{ type: 'text', text: JSON.stringify({ success: true, data: { view: 'payment', platformId: 'taobao', accountRef,
        attempts: [{ orderRef: accountRef }] } }) }] } } }, trade: async () => ok({ accountId: profile.id, attempts: [{ orderRef: accountRef,
      merchant: '示例店', amountCents: 2100, status: 'created', orderIds: ['123'], paymentUrl: null, paymentStatus: 'requires-verification' }] }) })
    try {
      const root = mounted.renderer.root, button = label => root.findAllByType('button').find(node => text(node.props.children) === label)
      await act(async () => button('连接 H5 收银台').props.onClick())
      if (example.submitted !== false) await act(async () => button('确认后台付款 · ¥21.00').props.onClick())
      const section = root.findAll(node => node.type === 'section' && node.props['aria-label'] === 'H5 后台付款')[0]
      assert.deepEqual(section.findAll(node => node.type === 'p' && node.props.role === 'status').map(node => text(node.props.children)), [example.expected])
      assert.equal(section.findAllByType('button').length, 0)
      assert(!text(mounted.renderer.toJSON()).includes('synthetic-private-server-message'))
      assert(!text(mounted.renderer.toJSON()).includes('synthetic-unrecognized-private-reason'))
      assert(!text(mounted.renderer.toJSON()).includes('付款已确认'))
      assert.equal(calls.filter(name => name === 'paymentH5Submit').length, example.submitted === false ? 0 : 1)
    } finally { mounted.close() }
  }
})

test('payment settings sign in to the selected pending order without creating orders or submitting payment', async () => {
  const ref = '11111111-1111-4111-8111-111111111111', orderRef = '22222222-2222-4222-8222-222222222222', calls = [], states = []
  const record = { orderRef, orderIds: ['123'], status: 'created', merchant: '验收商店', amountCents: 4690 }
  const officialOrders = [{ id: '123', status: '等待支付' }]
  const rpc = { async call(_channel, method, payload) {
    calls.push({ method, payload: structuredClone(payload) })
    if (method === 'accountsList') return ok({ viewAccountRef: ref, accounts: [{ ref, nickname: '验收账号' }] })
    if (method === 'paymentCredential') return ok({ configured: true, writable: true })
    if (method === 'tradeHistory') return ok({ accountId: profile.id, attempts: [record] })
    if (method === 'orders') return ok({ accountId: profile.id, orders: officialOrders })
    if (method === 'paymentStatus') return ok({ accountId: profile.id, orderRef, paymentStatus: 'requires-verification', officialOrders })
    if (method === 'paymentH5Start') return ok({ h5Ref: ref, state: 'requires-verification', verificationRequired: true, submitted: false })
    if (method === 'paymentH5Authenticate') return ok({ h5Ref: ref, state: payload.operation === 'sms' ? 'ready' : 'verifying', submitted: false,
      ...(payload.operation === 'sms' ? {} : { loginInput: payload.operation === 'phone' ? { kind: 'sms', codeLength: 6 } : { kind: 'phone' } }) })
    return method === 'profile' ? ok(profile) : ok({ authenticated: true, state: 'logged-in' })
  } }
  const mounted = await mount(rpc, { trade: (method, payload) => rpc.call('/waimai-login', method, payload) })
  try {
    const root = mounted.renderer.root, button = label => root.findAllByType('button').find(node => text(node.props.children) === label)
    await act(async () => button('支付配置').props.onClick())
    assert(text(mounted.renderer.toJSON()).includes('支付密码已设置'))
    assert(text(mounted.renderer.toJSON()).includes('尚未检查支付宝验证入口'))
    await act(async () => button('检查待付款订单').props.onClick())
    states.push({ action: text(button('登录支付宝').props.children), amount: '¥46.90' })
    await act(async () => button('登录支付宝').props.onClick())
    assert.equal(calls.find(x => x.method === 'paymentH5Start').payload.verificationOnly, true)
    assert.equal(calls.filter(x => x.method === 'paymentH5Authenticate' && x.payload.operation === 'open').length, 0)
    assert.equal(calls.filter(x => x.method === 'paymentH5Authenticate' && x.payload.operation === 'inline').length, 1)
    await act(async () => root.findAll(node => node.type === 'span' && node.props['aria-label'] === '支付宝手机号')[0].props.onChange({ target: { value: '13800000000' } }))
    await act(async () => button('下一步').props.onClick())
    await act(async () => root.findAll(node => node.type === 'span' && node.props['aria-label'] === '支付宝短信验证码')[0].props.onChange({ target: { value: '654321' } }))
    await act(async () => button('验证并连接').props.onClick())
    assert(text(mounted.renderer.toJSON()).includes('此订单的支付宝登录验证已完成'))
    assert(!root.findAllByType('button').some(node => /确认后台付款|使用已保存的支付密码/.test(text(node.props.children))))
    assert(!calls.some(x => ['submit', 'paymentPay', 'paymentH5Submit'].includes(x.method)))
    assert(calls.filter(x => ['tradeHistory', 'orders', 'paymentStatus', 'paymentH5Start', 'paymentH5Authenticate'].includes(x.method)).every(x => x.payload.accountRef === ref))
    states.push({ verified: true, paymentButtons: 0, paymentCalls: 0 })
    assert.deepEqual(states, JSON.parse(await readFile(new URL('./fixtures/settings-payment-login.json', import.meta.url), 'utf8')))
  } finally { mounted.close() }
})

test('payment settings never offer cancelled, unknown or foreign orders as login sessions', async () => {
  const ref = '11111111-1111-4111-8111-111111111111', records = [
    { orderRef: 'cancelled', orderIds: ['1'], status: 'created' },
    { orderRef: 'unknown', orderIds: ['2'], status: 'unknown' },
    { orderRef: 'foreign', orderIds: ['3'], status: 'created' },
  ]
  const rpc = { async call(_channel, method) {
    if (method === 'accountsList') return ok({ accounts: [{ ref, nickname: '验收账号' }] })
    if (method === 'paymentCredential') return ok({ configured: true, writable: true })
    if (method === 'tradeHistory') return ok({ accountId: profile.id, attempts: records })
    if (method === 'orders') return ok({ accountId: profile.id, orders: [{ id: '1', status: '订单已取消' }, { id: '2', status: '待支付' }, { id: '3', status: '等待支付' }] })
    if (method === 'paymentStatus') return ok({ accountId: 'foreign-owner', paymentStatus: 'requires-verification' })
    return method === 'profile' ? ok(profile) : ok({ authenticated: true, state: 'logged-in' })
  } }
  const mounted = await mount(rpc, { trade: (method, payload) => rpc.call('/waimai-login', method, payload) })
  try {
    const root = mounted.renderer.root, button = label => root.findAllByType('button').find(node => text(node.props.children) === label)
    await act(async () => button('支付配置').props.onClick())
    await act(async () => button('检查待付款订单').props.onClick())
    assert.equal(button('登录支付宝'), undefined)
    assert(root.findAllByProps({ role: 'alert' }).length > 0)
    assert(!text(mounted.renderer.toJSON()).includes('没有可继续验证的待付款订单'))
  } finally { mounted.close() }
})

test('settings login retains initialization errors instead of opening a window and hiding reconciliation', async () => {
  const ref = '11111111-1111-4111-8111-111111111111', record = { orderRef: ref, status: 'created', orderIds: ['123'], amountCents: 4690 }, calls = []
  const officialOrders = [{ id: '123', status: '待支付' }]
  const rpc = { async call(_channel, method, payload) {
    calls.push(method)
    if (method === 'accountsList') return ok({ accounts: [{ ref, nickname: '验收账号' }] })
    if (method === 'paymentCredential') return ok({ configured: true, writable: true })
    if (method === 'tradeHistory') return ok({ accountId: profile.id, attempts: [record] })
    if (method === 'orders') return ok({ accountId: profile.id, orders: officialOrders })
    if (method === 'paymentStatus') return ok({ accountId: profile.id, paymentStatus: 'requires-verification', officialOrders })
    if (method === 'paymentH5Start') return ok({ h5Ref: ref, verificationRequired: true, state: 'requires-reconciliation', reason: 'business-error', submitted: false })
    return method === 'profile' ? ok(profile) : ok({ authenticated: true, state: 'logged-in' })
  } }
  const mounted = await mount(rpc, { trade: (method, payload) => rpc.call('/waimai-login', method, payload) })
  try {
    const root = mounted.renderer.root, button = label => root.findAllByType('button').find(node => text(node.props.children) === label)
    await act(async () => button('支付配置').props.onClick())
    await act(async () => button('检查待付款订单').props.onClick())
    await act(async () => button('登录支付宝').props.onClick())
    assert(text(mounted.renderer.toJSON()).includes('支付宝返回业务错误'))
    assert.equal(calls.filter(x => x === 'paymentH5Authenticate').length, 0)
  } finally { mounted.close() }
})

async function mountInlineSettings(authenticate, options = {}) {
  const first = '11111111-1111-4111-8111-111111111111', second = '22222222-2222-4222-8222-222222222222'
  const calls = [], record = { orderRef: first, orderIds: ['123'], status: 'created', merchant: '示例验证店', amountCents: 4690 }
  const officialOrders = [{ id: '123', status: '等待支付' }]
  const rpc = { async call(channel, method, payload) {
    calls.push({ channel, method, payload: structuredClone(payload) })
    if (method === 'accountsList') return ok({ viewAccountRef: first, accounts: [{ ref: first, nickname: '第一账号' }, { ref: second, nickname: '第二账号' }] })
    if (method === 'paymentCredential') return ok({ configured: true, writable: true })
    if (method === 'tradeHistory') return ok({ accountId: profile.id, attempts: [record] })
    if (method === 'orders') return ok({ accountId: profile.id, orders: officialOrders })
    if (method === 'paymentStatus') return ok({ accountId: profile.id, orderRef: first, paymentStatus: 'requires-verification', officialOrders })
    if (method === 'paymentH5Start') return ok({ h5Ref: first, state: 'requires-verification', verificationRequired: true, submitted: false })
    if (method === 'paymentH5Authenticate') return authenticate(payload)
    if (method === 'paymentH5Methods') return options.paymentMethods(payload)
    return method === 'profile' ? ok(profile) : ok({ authenticated: true, state: 'logged-in' })
  } }
  const mounted = await mount(rpc, { ...options, trade: (method, payload) => rpc.call('/waimai-login', method, payload) })
  const root = mounted.renderer.root, button = label => root.findAllByType('button').find(node => text(node.props.children) === label)
  const input = label => root.findAll(node => node.type === 'span' && node.props['aria-label'] === label && node.props.onChange)[0]
  await act(async () => button('支付配置').props.onClick())
  await act(async () => button('检查待付款订单').props.onClick())
  await act(async () => button('登录支付宝').props.onClick())
  return { ...mounted, root, button, input, calls, first, second }
}

const inlineProgress = loginInput => ok({ h5Ref: '11111111-1111-4111-8111-111111111111', state: 'verifying', submitted: false, verificationRequired: true, loginInput })

test('inline Alipay verification clears inputs before private requests, serializes clicks and only resends when the server enables it', async () => {
  const phoneResponse = deferred(), storage = [], mutations = []
  const mounted = await mountInlineSettings(payload => {
    if (payload.operation === 'inline') return inlineProgress({ kind: 'phone' })
    if (payload.operation === 'phone') return phoneResponse.promise
    if (payload.operation === 'refresh') return inlineProgress({ kind: 'sms', codeLength: 4, canResend: true })
    if (payload.operation === 'resend') return inlineProgress({ kind: 'sms', codeLength: 4, canResend: false })
    if (payload.operation === 'sms') return ok({ state: 'ready', verificationRequired: false, submitted: false })
    return inlineProgress({ kind: 'pending' })
  }, { storage: { getItem: () => null, setItem: (...value) => storage.push(value) }, mutate: async ops => { mutations.push(ops); return true } })
  try {
    const { input, button, root, calls, first } = mounted
    assert.equal(input('支付宝手机号').props.autoComplete, 'off')
    assert.equal(button('打开官方窗口处理额外验证'), undefined)
    await act(async () => input('支付宝手机号').props.onChange({ target: { value: '13800000000' } }))
    await act(async () => { button('下一步').props.onClick(); button('下一步').props.onClick() })
    assert.equal(input('支付宝手机号').props.value, ''); assert.equal(button('下一步').props.disabled, true)
    assert.equal(calls.filter(x => x.payload.operation === 'phone').length, 1)
    await act(async () => phoneResponse.resolve(inlineProgress({ kind: 'sms', codeLength: 4, canResend: false })))
    assert.equal(input('支付宝短信验证码').props.maxLength, 4)
    assert.equal(button('重新发送验证码'), undefined)
    await act(async () => input('支付宝短信验证码').props.onChange({ target: { value: '123456' } }))
    assert.equal(button('验证并连接').props.disabled, true)
    await act(async () => button('刷新验证状态').props.onClick())
    assert.equal(input('支付宝短信验证码').props.value, '')
    await act(async () => { button('重新发送验证码').props.onClick(); button('重新发送验证码').props.onClick() })
    assert.equal(calls.filter(x => x.payload.operation === 'resend').length, 1)
    assert.equal(button('重新发送验证码'), undefined)
    await act(async () => input('支付宝短信验证码').props.onChange({ target: { value: '1234' } }))
    const entered = []
    await act(async () => input('支付宝短信验证码').props.onKeyDown({ key: 'Enter', preventDefault: () => entered.push('prevent'), stopPropagation: () => entered.push('stop') }))
    assert.deepEqual(entered, ['prevent', 'stop'])
    assert.equal(input('支付宝短信验证码'), undefined)
    assert(text(mounted.renderer.toJSON()).includes('此订单的支付宝登录验证已完成'))
    await act(async () => root.findByType('form').props.onSubmit({ preventDefault() {} }))
    assert(!JSON.stringify(storage).includes('13800000000')); assert(!JSON.stringify(mutations).includes('13800000000'))
    assert(!text(mounted.renderer.toJSON()).includes('13800000000'))
    const authentication = calls.filter(x => x.method === 'paymentH5Authenticate')
    assert.deepEqual(authentication.map(x => x.payload.operation), ['inline', 'phone', 'refresh', 'resend', 'sms'])
    assert(authentication.every(x => x.channel === '/waimai-login' && x.payload.accountRef === first && x.payload.orderRef === first))
    assert.deepEqual(authentication.filter(x => Object.hasOwn(x.payload, 'phone')).map(x => x.payload.operation), ['phone'])
    assert.deepEqual(authentication.filter(x => Object.hasOwn(x.payload, 'code')).map(x => x.payload.operation), ['sms'])
    assert(!calls.some(x => ['paymentH5Submit', 'submit', 'paymentPay'].includes(x.method)))
  } finally { mounted.close() }
})

test('inline pending and external steps need explicit refresh or a user-opened official window and never claim full verification support', async () => {
  let state = 'pending'
  const mounted = await mountInlineSettings(payload => {
    if (payload.operation === 'refresh' && state === 'ready') return ok({ state: 'ready', verificationRequired: false, submitted: false })
    return inlineProgress({ kind: state })
  })
  try {
    const { button, calls } = mounted
    assert(text(mounted.renderer.toJSON()).includes('支付宝验证正在处理中'))
    assert.equal(calls.filter(x => x.payload.operation === 'open').length, 0)
    state = 'external'
    await act(async () => button('刷新验证状态').props.onClick())
    assert(text(mounted.renderer.toJSON()).includes('当前步骤无法在 DSH 内完成'))
    assert.equal(calls.filter(x => x.payload.operation === 'open').length, 0)
    await act(async () => button('打开官方窗口处理额外验证').props.onClick())
    assert.equal(calls.filter(x => x.payload.operation === 'open').length, 1)
    state = 'ready'
    await act(async () => button('刷新验证状态').props.onClick())
    assert(text(mounted.renderer.toJSON()).includes('此订单的支付宝登录验证已完成'))
    assert(!mounted.root.findAllByType('button').some(node => /确认后台付款|使用已保存的支付密码/.test(text(node.props.children))))
  } finally { mounted.close() }
})

test('inline authentication failures never echo inputs or resend them, and unknown SMS lengths cannot be guessed', async () => {
  const mounted = await mountInlineSettings(payload => {
    if (payload.operation === 'phone') return { ok: false, error: { message: 'private phone 13800000000 and code 1234' } }
    if (payload.operation === 'refresh') return inlineProgress({ kind: 'sms' })
    return inlineProgress({ kind: 'phone' })
  })
  try {
    const { input, button, calls } = mounted
    await act(async () => input('支付宝手机号').props.onChange({ target: { value: '13800000000' } }))
    await act(async () => button('下一步').props.onClick())
    assert.equal(input('支付宝手机号').props.value, '')
    assert(text(mounted.renderer.toJSON()).includes('手机号和验证码已清空，不会自动重发'))
    assert(!text(mounted.renderer.toJSON()).includes('13800000000'))
    assert.equal(calls.filter(x => x.payload.operation === 'phone').length, 1)
    await act(async () => button('刷新验证状态').props.onClick())
    assert.equal(input('支付宝短信验证码'), undefined)
    assert.equal(button('验证并连接'), undefined)
    assert.equal(button('重新发送验证码'), undefined)
    assert(text(mounted.renderer.toJSON()).includes('支付宝验证正在处理中'))
  } finally { mounted.close() }
})

test('switching payment accounts discards a delayed inline phone response and cancels only the old account session', async () => {
  const delayed = deferred()
  const mounted = await mountInlineSettings(payload => payload.operation === 'phone' ? delayed.promise : inlineProgress({ kind: 'phone' }))
  try {
    const { input, button, root, first, second, calls } = mounted
    await act(async () => input('支付宝手机号').props.onChange({ target: { value: '13800000000' } }))
    await act(async () => button('下一步').props.onClick())
    const selector = root.findAll(node => node.type === 'span' && node.props.className === 'waimai-choice' && node.props.selectedId === first)[0]
    await act(async () => selector.props.onSelect(second))
    await act(async () => delayed.resolve(inlineProgress({ kind: 'sms', codeLength: 6 })))
    assert.equal(input('支付宝短信验证码'), undefined)
    assert.equal(input('支付宝手机号'), undefined)
    assert(text(mounted.renderer.toJSON()).includes('尚未检查支付宝验证入口'))
    const cancelled = calls.filter(x => x.method === 'paymentH5Authenticate' && x.payload.operation === 'cancel')
    assert.equal(cancelled.length, 1); assert.equal(cancelled[0].payload.accountRef, first)
    assert(!calls.some(x => x.method === 'paymentH5Authenticate' && x.payload.accountRef === second))
  } finally { mounted.close() }
})

test('Alipay login channels require explicit selection, serialize requests and never persist channel references or submit payment', async () => {
  const delayed = deferred(), storage = [], mutations = []
  const channelRef = 'temporary-login-channel', label = '<b>支付宝手机号登录</b>'
  const mounted = await mountInlineSettings(payload => payload.operation === 'channel' ? delayed.promise
    : inlineProgress({ kind: 'channel', channels: [{ channelRef, label, disabled: false }, { channelRef: 'unavailable-channel', label: '不可用入口', disabled: true }] }),
  { storage: { getItem: () => null, setItem: (...value) => storage.push(value) }, mutate: async ops => { mutations.push(ops); return true } })
  try {
    const { button, input, calls, root, first } = mounted
    assert(text(mounted.renderer.toJSON()).includes('选择支付宝登录方式'))
    assert(text(mounted.renderer.toJSON()).includes('登录后再确认实际付款方式'))
    assert.equal(button(label).props.children, label)
    assert.equal(button('不可用入口').props.disabled, true)
    assert.deepEqual(calls.filter(x => x.method === 'paymentH5Authenticate').map(x => x.payload.operation), ['inline'])
    assert.equal(button('打开官方窗口处理额外验证'), undefined)
    await act(async () => button('不可用入口').props.onClick())
    assert.equal(calls.filter(x => x.payload.operation === 'channel').length, 0)
    await act(async () => { button(label).props.onClick(); button(label).props.onClick() })
    assert.equal(button(label).props.disabled, true)
    const selection = calls.filter(x => x.payload.operation === 'channel')
    assert.equal(selection.length, 1)
    assert.deepEqual(selection[0].payload, { platformId: 'taobao', accountRef: first, orderRef: first, h5Ref: first, operation: 'channel', channelRef })
    await act(async () => delayed.resolve(inlineProgress({ kind: 'phone' })))
    assert(input('支付宝手机号'))
    assert.equal(button(label), undefined)
    assert.equal(button('下一步').props.disabled, true)
    await act(async () => root.findByType('form').props.onSubmit({ preventDefault() {} }))
    assert(!JSON.stringify(storage).includes(channelRef))
    assert(!JSON.stringify(mutations).includes(channelRef))
    assert(!calls.some(x => ['paymentH5Submit', 'submit', 'paymentPay'].includes(x.method)))
    assert.deepEqual(calls.filter(x => x.method === 'paymentH5Authenticate').map(x => x.payload.operation), ['inline', 'channel'])
  } finally { mounted.close() }
})

test('a late login channel selection cannot restore the previous shopping account verification session', async () => {
  const delayed = deferred()
  const mounted = await mountInlineSettings(payload => payload.operation === 'channel' ? delayed.promise
    : inlineProgress({ kind: 'channel', channels: [{ channelRef: 'temporary-channel', label: '手机号登录', disabled: false }] }))
  try {
    const { button, input, root, first, second, calls } = mounted
    await act(async () => button('手机号登录').props.onClick())
    const selector = root.findAll(node => node.type === 'span' && node.props.className === 'waimai-choice' && node.props.selectedId === first)[0]
    await act(async () => selector.props.onSelect(second))
    await act(async () => delayed.resolve(inlineProgress({ kind: 'phone' })))
    assert.equal(input('支付宝手机号'), undefined)
    assert(text(mounted.renderer.toJSON()).includes('尚未检查支付宝验证入口'))
    const cancelled = calls.filter(x => x.method === 'paymentH5Authenticate' && x.payload.operation === 'cancel')
    assert.equal(cancelled.length, 1)
    assert.equal(cancelled[0].payload.accountRef, first)
    assert(!calls.some(x => ['paymentH5Submit', 'submit', 'paymentPay'].includes(x.method)))
  } finally { mounted.close() }
})

const cashierMethods = (payload, methods) => ok({ orderRef: payload.orderRef, h5Ref: payload.h5Ref, state: 'ready', submitted: false, amountCents: 4690, methods })
const methodA = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', methodB = 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb'

test('settings payment methods load and select only explicitly, show backend readback and never pay or persist method references', async () => {
  const selecting = deferred(), storage = [], mutations = [], label = '<b>银行卡（1234）</b>'
  const methods = [{ methodRef: methodA, label, selected: true }, { methodRef: methodB, label, selected: false }]
  const mounted = await mountInlineSettings(() => ok({ state: 'ready', verificationRequired: false, submitted: false }), {
    paymentMethods: payload => payload.operation === 'list' ? cashierMethods(payload, methods) : selecting.promise,
    storage: { getItem: () => null, setItem: (...value) => storage.push(value) }, mutate: async ops => { mutations.push(ops); return true },
  })
  try {
    const { button, calls, root, first } = mounted
    assert.equal(calls.filter(x => x.method === 'paymentH5Methods').length, 0)
    assert(text(mounted.renderer.toJSON()).includes('不会保存为跨订单默认银行卡'))
    await act(async () => button('刷新付款方式').props.onClick())
    const rows = () => root.findAll(node => node.type === 'div' && node.props.className === 'waimai-order' && node.findAllByType('button').some(child => text(child.props.children) === '选择此方式'))
    assert.equal(rows().length, 2)
    assert.deepEqual(rows().map(row => row.findAllByType('span')[0].props.children), [label, label])
    assert.deepEqual(rows().map(row => row.findByType('button').props.disabled), [true, false])
    const select = rows()[1].findByType('button').props.onClick
    await act(async () => { select(); select() })
    assert.equal(rows().length, 0)
    assert.equal(button('刷新付款方式').props.disabled, true)
    const selections = calls.filter(x => x.method === 'paymentH5Methods' && x.payload.operation === 'select')
    assert.equal(selections.length, 1)
    assert.deepEqual(selections[0].payload, { platformId: 'taobao', accountRef: first, orderRef: first, h5Ref: first, operation: 'select', methodRef: methodB })
    await act(async () => selecting.resolve(cashierMethods(selections[0].payload, methods.map(method => ({ ...method, selected: method.methodRef === methodB })))))
    assert.deepEqual(rows().map(row => row.findByType('button').props.disabled), [false, true])
    assert.deepEqual(rows().map(row => row.findAllByProps({ role: 'status' }).map(child => text(child.props.children))), [[], ['当前已选']])
    assert(text(mounted.renderer.toJSON()).includes('当前收银台金额 · ¥46.90'))
    await act(async () => root.findByType('form').props.onSubmit({ preventDefault() {} }))
    assert(!JSON.stringify(storage).includes(methodB)); assert(!JSON.stringify(mutations).includes(methodB))
    assert(!calls.some(x => ['paymentH5Submit', 'submit', 'paymentPay'].includes(x.method)))
  } finally { mounted.close() }
})

test('failed payment method selection clears old choices until an explicit refresh and never echoes backend errors', async () => {
  const mounted = await mountInlineSettings(() => ok({ state: 'ready', submitted: false }), {
    paymentMethods: payload => payload.operation === 'select' ? { ok: false, error: { message: 'synthetic-private-method-error' } }
      : cashierMethods(payload, [{ methodRef: methodA, label: '银行卡', selected: false }]),
  })
  try {
    const { button, calls } = mounted
    await act(async () => button('刷新付款方式').props.onClick())
    await act(async () => button('选择此方式').props.onClick())
    assert.equal(button('选择此方式'), undefined)
    assert(text(mounted.renderer.toJSON()).includes('旧列表已清空'))
    assert(!text(mounted.renderer.toJSON()).includes('synthetic-private-method-error'))
    assert.deepEqual(calls.filter(x => x.method === 'paymentH5Methods').map(x => x.payload.operation), ['list', 'select'])
    await act(async () => button('刷新付款方式').props.onClick())
    assert(button('选择此方式'))
    assert(!text(mounted.renderer.toJSON()).includes('旧列表已清空'))
    assert(!calls.some(x => ['paymentH5Submit', 'submit', 'paymentPay'].includes(x.method)))
  } finally { mounted.close() }
})

test('switching accounts discards late method selection and does not read methods for the new account automatically', async () => {
  const delayed = deferred()
  const mounted = await mountInlineSettings(() => ok({ state: 'ready', submitted: false }), {
    paymentMethods: payload => payload.operation === 'select' ? delayed.promise : cashierMethods(payload, [{ methodRef: methodA, label: '旧账户银行卡', selected: false }]),
  })
  try {
    const { button, root, first, second, calls } = mounted
    await act(async () => button('刷新付款方式').props.onClick())
    await act(async () => button('选择此方式').props.onClick())
    const request = calls.find(x => x.method === 'paymentH5Methods' && x.payload.operation === 'select').payload
    const selector = root.findAll(node => node.type === 'span' && node.props.className === 'waimai-choice' && node.props.selectedId === first)[0]
    await act(async () => selector.props.onSelect(second))
    await act(async () => delayed.resolve(cashierMethods(request, [{ methodRef: methodA, label: '旧账户银行卡', selected: true }])))
    assert.equal(button('刷新付款方式'), undefined)
    assert(!text(mounted.renderer.toJSON()).includes('旧账户银行卡'))
    assert(!calls.some(x => x.method === 'paymentH5Methods' && x.payload.accountRef === second))
    assert(!calls.some(x => ['paymentH5Submit', 'submit', 'paymentPay'].includes(x.method)))
  } finally { mounted.close() }
})

test('phone login shows official agreements and requires explicit current consent before sending only the agreement reference', async () => {
  const response = deferred(), storage = [], mutations = []
  const agreementRef = 'aaaaaaaa-1111-4111-8111-aaaaaaaaaaaa'
  const agreements = [{ name: '支付宝隐私协议', url: 'https://render.alipay.com/p/f/agreement-test.html' },
    { name: '<b>登录服务协议</b>', url: 'https://render.alipay.com/p/f/login-agreement-test.html' }]
  const mounted = await mountInlineSettings(payload => payload.operation === 'phone' ? response.promise
    : inlineProgress({ kind: 'phone', agreementRef, agreements }), {
    storage: { getItem: () => null, setItem: (...value) => storage.push(value) }, mutate: async ops => { mutations.push(ops); return true },
  })
  try {
    const { root, input, button, calls, first } = mounted
    const checkbox = () => root.findAll(node => node.type === 'span' && node.props.label === '我已阅读并同意以上协议')[0]
    assert.equal(checkbox().props.checked, false)
    const links = root.findAllByType('a').filter(node => agreements.some(agreement => agreement.url === node.props.href))
    assert.deepEqual(links.map(node => ({ name: node.props.children, url: node.props.href })), agreements)
    assert(links.every(node => node.props.target === '_blank' && node.props.rel === 'noopener noreferrer'))
    assert.deepEqual({ agreements: links.map(node => ({ name: node.props.children, url: node.props.href })),
      consent: checkbox().props.checked, submitDisabled: button('下一步').props.disabled },
    JSON.parse(await readFile(new URL('./fixtures/settings-login-agreements.json', import.meta.url), 'utf8')))
    await act(async () => input('支付宝手机号').props.onChange({ target: { value: '13800000000' } }))
    assert.equal(button('下一步').props.disabled, true)
    await act(async () => { button('下一步').props.onClick(); input('支付宝手机号').props.onKeyDown({ key: 'Enter', preventDefault() {}, stopPropagation() {} }) })
    assert.equal(calls.filter(x => x.payload.operation === 'phone').length, 0)
    await act(async () => checkbox().props.onChange(true))
    assert.equal(button('下一步').props.disabled, false)
    await act(async () => { button('下一步').props.onClick(); button('下一步').props.onClick() })
    assert.equal(input('支付宝手机号').props.value, '')
    assert.equal(checkbox().props.checked, false)
    const sent = calls.filter(x => x.payload.operation === 'phone')
    assert.equal(sent.length, 1)
    assert.deepEqual(sent[0].payload, { platformId: 'taobao', orderRef: first, accountRef: first, h5Ref: first, operation: 'phone', phone: '13800000000', agreementRef })
    await act(async () => response.resolve(inlineProgress({ kind: 'sms', codeLength: 4 })))
    assert(input('支付宝短信验证码'))
    await act(async () => root.findByType('form').props.onSubmit({ preventDefault() {} }))
    assert(!JSON.stringify(storage).includes(agreementRef)); assert(!JSON.stringify(mutations).includes(agreementRef))
    assert(!calls.some(x => ['paymentH5Submit', 'submit', 'paymentPay'].includes(x.method)))
  } finally { mounted.close() }
})

test('new phone agreements clear prior consent, missing agreement references block submission and agreement-free login stays unchanged', async () => {
  let step = 0
  const oldRef = 'aaaaaaaa-1111-4111-8111-aaaaaaaaaaaa', newRef = 'bbbbbbbb-1111-4111-8111-bbbbbbbbbbbb'
  const agreements = [{ name: '官方协议', url: 'https://render.alipay.com/p/f/agreement-test.html' }]
  const mounted = await mountInlineSettings(payload => {
    if (payload.operation === 'refresh') step++
    return inlineProgress({ kind: 'phone', ...(step < 3 ? { agreements } : {}), ...(step < 2 ? { agreementRef: step ? newRef : oldRef } : {}) })
  })
  try {
    const { root, input, button, calls } = mounted
    const checkbox = () => root.findAll(node => node.type === 'span' && node.props.label === '我已阅读并同意以上协议')[0]
    await act(async () => checkbox().props.onChange(true))
    await act(async () => button('刷新验证状态').props.onClick())
    assert.equal(checkbox().props.checked, false)
    await act(async () => input('支付宝手机号').props.onChange({ target: { value: '13800000000' } }))
    assert.equal(button('下一步').props.disabled, true)
    await act(async () => checkbox().props.onChange(true))
    await act(async () => button('下一步').props.onClick())
    assert.equal(calls.filter(x => x.payload.operation === 'phone').at(-1).payload.agreementRef, newRef)
    assert.equal(checkbox().props.checked, false)
    await act(async () => button('刷新验证状态').props.onClick())
    assert.equal(checkbox().props.disabled, true)
    await act(async () => input('支付宝手机号').props.onChange({ target: { value: '13800000000' } }))
    assert.equal(button('下一步').props.disabled, true)
    await act(async () => button('刷新验证状态').props.onClick())
    assert.equal(checkbox(), undefined)
    await act(async () => input('支付宝手机号').props.onChange({ target: { value: '13800000000' } }))
    assert.equal(button('下一步').props.disabled, false)
    await act(async () => button('下一步').props.onClick())
    assert.equal(Object.hasOwn(calls.filter(x => x.payload.operation === 'phone').at(-1).payload, 'agreementRef'), false)
  } finally { mounted.close() }
})
