import {randomUUID} from 'node:crypto';

export interface OperationEvidence {
  operationId:string; turnId:string; action:string; startedAt:string; durationMs:number;
  outcome:'returned'|'partial'|'error'; imageReturned:boolean;
  status?:string; completed?:number; attempted?:number; remaining?:number; code?:string;
}
export class OperationFailure extends Error {
  constructor(message:string,readonly operation:OperationEvidence){super(message);}
}
const codeOf=(value:unknown):string|undefined=>typeof value==='string'?value.match(/^[A-Z][A-Z0-9_]+(?=:|$)/)?.[0]:undefined;
// Only explicit protocol evidence is retained: never arguments, OCR, titles,
// native error prose, or screenshot data. Session histories expire with MCP.
export class OperationHistory {
  private sessions=new Map<string,OperationEvidence[]>();
  constructor(private maxSessions=32,private maxEntries=100){}
  private sessionKey(turnId:string):string {
    if(turnId==='standalone')return turnId;
    const parsed:unknown=JSON.parse(turnId);
    if(!Array.isArray(parsed)||parsed.length!==2||typeof parsed[0]!=='string'||!Number.isSafeInteger(parsed[1]))throw new Error('INVALID_TURN_CONTEXT');
    return parsed[0];
  }
  list(turnId:string,limit=20):OperationEvidence[]{
    return structuredClone((this.sessions.get(this.sessionKey(turnId))??[]).slice(-limit));
  }
  async capture(turnId:string,action:string,run:()=>Promise<Record<string,unknown>>):Promise<Record<string,unknown>> {
    const key=this.sessionKey(turnId),started=Date.now();
    const evidence:OperationEvidence={operationId:randomUUID(),turnId,action,startedAt:new Date(started).toISOString(),durationMs:0,outcome:'returned',imageReturned:false};
    try {
      const result=await run();
      evidence.imageReturned=Boolean((result.screenshot as {base64?:string}|undefined)?.base64);
      if(['completed','checkpoint','stopped'].includes(String(result.status)))evidence.status=String(result.status);
      for(const field of ['completed','attempted','remaining'] as const)if(Number.isSafeInteger(result[field])&&Number(result[field])>=0)evidence[field]=Number(result[field]);
      evidence.code=codeOf(result.reason);
      if(result.status==='stopped'||Number(result.remaining)>0)evidence.outcome='partial';
      evidence.durationMs=Date.now()-started;
      return {...result,operation:structuredClone(evidence)};
    } catch(error) {
      evidence.outcome='error';evidence.code=codeOf(error instanceof Error?error.message:undefined)??'OPERATION_FAILED';
      evidence.durationMs=Date.now()-started;
      throw new OperationFailure(error instanceof Error?error.message:String(error),structuredClone(evidence));
    } finally {
      evidence.durationMs=Date.now()-started;
      const entries=this.sessions.get(key)??[];
      entries.push(evidence);
      if(entries.length>this.maxEntries)entries.splice(0,entries.length-this.maxEntries);
      this.sessions.delete(key);this.sessions.set(key,entries);
      if(this.sessions.size>this.maxSessions)this.sessions.delete(this.sessions.keys().next().value!);
    }
  }
}
