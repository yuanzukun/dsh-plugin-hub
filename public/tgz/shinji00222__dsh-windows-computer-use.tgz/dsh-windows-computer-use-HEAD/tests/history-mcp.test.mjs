import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {Client} from '@modelcontextprotocol/sdk/client/index.js';
import {StdioClientTransport} from '@modelcontextprotocol/sdk/client/stdio.js';
test('MCP history is read-only, host-turn scoped and available without native engine',{timeout:30000},async()=>{
  const root=await mkdtemp(path.join(os.tmpdir(),'dsh-history-test-'));
  const turnFile=path.join(root,'turn.json');
  const publish=(session,turn)=>writeFile(turnFile,JSON.stringify({turnId:session?JSON.stringify([session,turn]):null}));
  await publish('a',1);
  const client=new Client({name:'history-test',version:'1'});
  const transport=new StdioClientTransport({command:process.execPath,args:['dist/server.js'],env:{...process.env,DSH_NATIVE_READ_ONLY:'1',DSH_NATIVE_TURN_FILE:turnFile,DSH_NATIVE_INDICATOR:'0'}});
  const call=(name,args={})=>client.callTool({name:'windows_computer_use_'+name,arguments:args});
  try{
    await client.connect(transport);
    assert.ok((await client.listTools()).tools.some(t=>t.name==='windows_computer_use_operation_history'));
    assert.deepEqual(JSON.parse((await call('operation_history')).content[0].text).operations,[]);
    // Missing engine is also a recorded failure on non-Windows development hosts.
    const health=await call('health');
    const response=JSON.parse(health.content[0].text);
    assert.ok(response.operation.operationId);
    await publish('a',2);
    const history=JSON.parse((await call('operation_history')).content[0].text);
    assert.equal(history.operations.length,1);
    assert.equal(history.operations[0].operationId,response.operation.operationId);
    assert.equal(history.operations[0].turnId,JSON.stringify(['a',1]));
    await publish('b',1);
    assert.deepEqual(JSON.parse((await call('operation_history')).content[0].text).operations,[]);
    assert.equal((await call('operation_history',{limit:101})).isError,true);
    await publish(null);
    assert.match((await call('operation_history')).content[0].text,/NO_ACTIVE_USER_TURN/);
  }finally{await client.close();await rm(root,{recursive:true,force:true});}
});
