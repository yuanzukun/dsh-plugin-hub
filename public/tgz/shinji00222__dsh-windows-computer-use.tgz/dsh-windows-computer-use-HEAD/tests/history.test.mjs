import test from 'node:test';
import assert from 'node:assert/strict';
import {OperationHistory,OperationFailure} from '../dist/history.js';
const turn=(session,n)=>JSON.stringify([session,n]);
test('operation history spans human turns, isolates sessions, and retains only evidence',async()=>{
  const h=new OperationHistory();
  const result=await h.capture(turn('a',1),'run_batch',async()=>({status:'stopped',completed:2,attempted:3,remaining:1,reason:'STOPPED_BY_USER: private title',screenshot:{base64:'secret-image'},text:'secret-input',steps:[{text:'secret-input'}]}));
  assert.equal(result.operation.outcome,'partial');
  assert.equal(result.operation.imageReturned,true);
  assert.equal(result.operation.code,'STOPPED_BY_USER');
  assert.equal(h.list(turn('a',2))[0].operationId,result.operation.operationId);
  assert.deepEqual(h.list(turn('b',2)),[]);
  const serialized=JSON.stringify(h.list(turn('a',2)));
  assert.ok(!/secret|private title/.test(serialized));
  const copy=h.list(turn('a',2));copy[0].completed=999;
  assert.equal(h.list(turn('a',2))[0].completed,2);
});
test('failures retain a stable ID and bounded error code without native prose',async()=>{
  const h=new OperationHistory();
  let caught;
  try{await h.capture('standalone','type_text',async()=>{throw Error('NATIVE_TIMEOUT: private content');});}catch(error){caught=error;}
  assert.ok(caught instanceof OperationFailure);
  assert.equal(caught.operation.outcome,'error');
  assert.equal(caught.operation.operationId,h.list('standalone')[0].operationId);
  assert.equal(h.list('standalone')[0].code,'NATIVE_TIMEOUT');
  assert.ok(!JSON.stringify(h.list('standalone')).includes('private content'));
});
test('retention evicts oldest records and sessions, and resets with connection',async()=>{
  const h=new OperationHistory(2,2);
  const run=(s,n)=>h.capture(turn(s,n),'health',async()=>({engine:'C#'}));
  await run('a',1);await run('a',2);await run('a',3);
  assert.deepEqual(h.list(turn('a',4)).map(x=>x.turnId),[turn('a',2),turn('a',3)]);
  assert.equal(h.list(turn('a',4),1).length,1);
  await run('b',1);await run('c',1);
  assert.deepEqual(h.list(turn('a',4)),[]);
  assert.deepEqual(new OperationHistory().list(turn('c',2)),[]);
});
test('malformed turn context cannot dispatch an action',async()=>{
  let dispatched=false;
  await assert.rejects(new OperationHistory().capture('["a"]','click',async()=>{dispatched=true;return {};}),/INVALID_TURN_CONTEXT/);
  assert.equal(dispatched,false);
});
