<h1 align="center">📝 DeepSeek 便签</h1>

<p align="center">
  <strong>中文</strong> · <a href="README.en.md">English</a>
</p>

<p align="center">
  <strong>让 DeepSeek Harness 拥有真正的便签纸</strong><br />
  <sub>可拖动 · 待办勾选 · 9 款皮肤 · 图片便签 · AI 读写</sub>
</p>

<p align="center">
  <a href="https://github.com/charrywhite/dsh-sticky-notes/stargazers"><img src="https://img.shields.io/github/stars/charrywhite/dsh-sticky-notes?style=flat&color=d97706" alt="Stars" /></a>
  <a href="./LICENSE"><img src="https://img.shields.io/github/license/charrywhite/dsh-sticky-notes?style=flat&color=059669" alt="License" /></a>
  <a href="https://github.com/charrywhite/dsh-sticky-notes/releases"><img src="https://img.shields.io/github/package-json/v/charrywhite/dsh-sticky-notes?style=flat&color=2563eb" alt="Version" /></a>
  <a href="https://github.com/charrywhite/dsh-sticky-notes"><img src="https://img.shields.io/badge/DeepSeek%20Harness-plugin-7c3aed?style=flat" alt="DeepSeek Harness Plugin" /></a>
</p>

<p align="center">
  <img src="headline.png" alt="DeepSeek 便签 — 在 DeepSeek Harness 里贴便签" width="100%">
</p>

<p align="center">
  <img src="interface4.PNG" alt="DeepSeek 便签 — 界面截图" width="100%">
</p>

<br />

## 亮点

<table>
<tr>
<td width="50%">

### 📝 打字记录

每张便签就是一个待办列表,回车或点「添加」即可记下一条。

</td>
<td width="50%">

### 🤖 AI 协同

DeepSeek 模型可以直接**读**你的便签、帮你**写**便签(见 [第 3 节](#3-ai-模型读写便签))。

</td>
</tr>
<tr>
<td width="50%">

### ☑️ 勾选完成

点复选框,文字出现删除线并变淡;再点一下取消。

</td>
<td width="50%">

### 📌 多张便签

右上角「＋ 新建便签」随意添加,每张完全独立。

</td>
</tr>
<tr>
<td width="50%">

### 🖐 随意拖动

便签、收起的小标签、「新建便签」按钮都能拖到任意位置并记住。

</td>
<td width="50%">

### 🎨 9 套皮肤

经典黄、薄荷绿、樱花粉、天空蓝、暮光紫、暖橙日落、石墨暗夜、霓虹荧光、极简白纸,每张便签独立设置。

</td>
</tr>
<tr>
<td width="50%">

### 🖼 图片便签

上传或拖入图片,便签纸里直接展示,点击可更换。

</td>
<td width="50%">

### ✏️ 自定义标题

铅笔图标重命名,清空后标题可留白。

</td>
</tr>
<tr>
<td colspan="2">

### 🛡 数据可靠

每次改动即时保存,刷新、重开页面都不丢。

</td>
</tr>
</table>

## 皮肤一览

<p align="center">
  <img src="skins.png" alt="9 款皮肤预览" width="100%">
</p>
<p align="center"><sub>经典黄 · 薄荷绿 · 樱花粉 · 天空蓝 · 暮光紫 · 暖橙日落 · 石墨暗夜 · 霓虹荧光 · 极简白纸</sub></p>

---

## 更新日志

- 8/28 更新双击编辑现有便签条目功能
- 8/18 新增 👀 眼睛键,一键隐藏/显示全部便签
- 8/17 新增 📝 便签键,点击新建便签,按住拖动换位置
- 8/17 更新:单击便签标题即可收起/展开
- 8/16 发布 v0.1.0:多张便签、9 款皮肤、图片便签、AI 模型读写便签

---

## 1. 安装

> 前提:本机可执行 `dsh`(DeepSeek Harness CLI)。若 `pnpm` 不在 PATH,先执行 `npm i -g pnpm`(或 `corepack enable pnpm`)。

### 方式 A:一行命令安装(推荐)

```powershell
# 从 GitHub 仓库安装
dsh plugin --profile web add github:charrywhite/dsh-sticky-notes

# 或本地目录开发安装(link 指向插件目录,自动解析)
dsh plugin --profile web add link:C:/path/to/dsh-plugin-sticky-notes
```

安装完成后:

1. **重启 dsh web**(在启动它的终端 Ctrl+C,重新运行 `dsh web`)
2. **硬刷新浏览器页面**(Ctrl+F5),右侧就会出现便签

卸载:`dsh plugin --profile web remove dsh-sticky-notes`

### 方式 B:手动安装(备选)

把插件目录放到任意位置(下文以 `C:\path\to\dsh-plugin-sticky-notes` 为例),修改 web profile 配置:

**① 注册依赖与 bundle**

编辑 `%USERPROFILE%\.dsh\profiles\web\package.json`:

```json
{
  "dependencies": {
    "dsh-sticky-notes": "link:C:/path/to/dsh-plugin-sticky-notes"
  },
  "dsh": {
    "profile": {
      "bundles": [
        "@deepseek-ai/dsh-base",
        "@deepseek-ai/dsh-web-app",
        "dsh-sticky-notes"
      ]
    }
  }
}
```

> `link:` 指向插件目录的绝对路径,斜杠 `/` 或反斜杠 `\` 均可(JSON 里建议用 `/`)。

**② 在 profile 目录执行 pnpm install**

```powershell
cd "$env:USERPROFILE\.dsh\profiles\web"
pnpm install
```

**③ 重启 dsh web + 硬刷新浏览器页面**(Ctrl+F5)。

### 方式 C:GitHub 依赖手动方式

在 `package.json` 里把依赖写成 GitHub 引用,然后同样执行 `pnpm install` + 重启 + 刷新:

```json
{
  "dependencies": {
    "dsh-sticky-notes": "github:charrywhite/dsh-sticky-notes#commit哈希或分支"
  },
  "dsh": {
    "profile": {
      "bundles": ["dsh-sticky-notes"]
    }
  }
}
```

---

## 2. 使用指南

### 两个功能键

- **📝 便签键**:点一下弹出菜单,选择「文字便签」或「图片便签」新建;按住它拖动可以换位置
- **👀 眼睛键**:点一下隐藏全部便签(图标变成 🙈),再点一下全部恢复

### 创建便签

点击右上角的 📝 **便签按钮**,弹出菜单选择:

| 选项 | 说明 |
|------|------|
| 📝 文字便签 | 输入框打字,回车或点「添加」变成一条待办 |
| 🖼 图片便签 | 点击上传区选择图片,或直接把图片拖进便签 |

新便签默认从右上角层叠排开,每张都有标题栏、计数徽章和操作按钮。

### 便签操作

| 操作 | 方式 |
|------|------|
| 拖动 | 按住**标题栏**(或收起后的小标签、📝 按钮)拖动,位置自动记住 |
| 隐藏/显示全部 | 单击 📝 按钮下方的 👀 按钮:所有便签整体隐藏(图标变 🙈);再单击全部恢复(状态会记住) |
| 勾选完成 | 点条目左侧复选框 → 删除线 + 变淡;再点取消 |
| 删除单条 | 鼠标悬停条目,点右侧 `×` |
| 编辑条目 | 双击条目文字进入编辑,回车或点击其他位置保存,Esc 取消 |
| 清除已完成 | 便签底部「清除已完成」一键清理勾选项 |
| 换皮肤 | 点标题栏 🎨,弹出 9 色色块,点选即换(每张便签独立) |
| 重命名 | 点标题栏 ✏️,输入新名字,回车或点击其他位置保存;清空可留白 |
| 收起/展开 | 点标题栏 `—` 或直接单击标题收起为小圆标;单击小圆标展开 |
| 删除整张 | 点标题栏 🗑(有确认弹窗) |

### 图片便签

- 上传后图片显示在便签纸内,点击图片可更换
- 图片便签同样支持拖动、换皮肤、重命名、收起、删除

---

## 3. AI 模型读写便签

插件注册了两个模型工具,DeepSeek 模型在对话中可以直接调用:

### 读取:`sticky_notes_read`

列出所有便签:标题、每条文字、完成状态(☐/☑)、皮肤、是否收起。图片便签只显示元数据(标题/是否有图)。

**用法**:对模型说「看一下我的便签」「帮我整理便签」「按便签干活」。

### 写入:`sticky_notes_add`

- **新建便签**:不传 `noteId`,传 `text`(必填)+ 可选 `title`
- **追加条目**:传 `noteId`(先用 `sticky_notes_read` 拿到)+ `text`

**设计约束**:只允许追加/新建,**不能修改或删除已有内容**,不会覆盖你手动编辑的东西;图片便签拒绝追加文字条目。

**用法**:对模型说「帮我在便签上记一条:明天下午三点开会」「把这个需求加到工作便签里」。

---

## 4. 卸载

1. 方式 A 安装的:`dsh plugin --profile web remove dsh-sticky-notes`
2. 方式 B/C 安装的:从 `package.json` 移除依赖项和 bundles 条目,再执行 `pnpm install`
3. (可选)删除数据文件:`Remove-Item "$env:USERPROFILE\.dsh\sticky-notes.json"`
4. 重启 dsh web

---

## 环境要求

- DeepSeek Harness **web 模式**(`dsh web`)
- 浏览器:现代 Chromium/Firefox/Safari
- 无第三方运行时依赖

## 鸣谢

感谢 [@scraed](https://github.com/scraed) 在 [PR #1](https://github.com/charrywhite/dsh-sticky-notes/pull/1) 中提出的交互设计:home 键(单击隐藏/显示全部便签、长按新建)与「点击标题栏收起便签」。

---

## FAQ(常见问题)

**Q: dsh-sticky-notes 是什么?**
A: 一个 DeepSeek Harness(DSH)的便签插件,在 `dsh web` 界面提供可拖动的便签纸:文字待办、图片便签、9 款皮肤,并且 AI 模型可以直接读写你的便签。

**Q: 怎么安装?**
A: 一行命令,然后重启 dsh web 并硬刷新页面(Ctrl+F5):

```powershell
dsh plugin --profile web add github:charrywhite/dsh-sticky-notes
```

**Q: 支持图片便签吗?**
A: 支持。新建时选「图片便签」,点击或拖入图片即可,图片会自动压缩以节省存储空间。

**Q: AI 模型能读写我的便签吗?**
A: 能。插件注册了 `sticky_notes_read`(读取所有便签)和 `sticky_notes_add`(新建便签 / 追加条目)两个模型工具,对模型说「看一下我的便签」或「帮我在便签上记一条」即可。AI 只能追加 / 新建,不能修改或删除你手动写的内容。

**Q: 便签数据存在哪里?刷新会丢吗?**
A: 不会丢。数据权威存储在 harness 主机的 `~/.dsh/sticky-notes.json`,浏览器每次改动即时上传;刷新、重开页面、AI 写入都会自动同步。

**Q: 怎么修改已经写上的条目?**
A: 双击条目文字进入编辑模式,回车或点击其他位置保存,Esc 取消。

**Q: 它和其他便签插件有什么不同?**
A: 这是运行在 dsh web 界面里的浮动便签板,核心差异是 AI 模型可以读取和写入便签(agent 工具),并支持 9 款皮肤、图片便签与双击编辑;数据由 harness host 权威存储,AI 的写入会在几秒内同步回浏览器。

## License

MIT
