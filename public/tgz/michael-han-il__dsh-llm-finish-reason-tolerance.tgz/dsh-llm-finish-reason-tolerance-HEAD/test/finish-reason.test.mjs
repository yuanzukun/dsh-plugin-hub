// Self-contained tests for the finish_reason tolerance wrapper.
// Run with: node --test test/
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { tolerateMissingFinishReason } from '../lib/tolerance.js'

/** Collect every chunk from a wrapped iterable into an array. */
async function collect(stream) {
  const out = []
  for await (const chunk of tolerateMissingFinishReason(stream)) out.push(chunk)
  return out
}

const ERROR_FINISH = {
  type: 'finish',
  reason: { kind: 'error', failure: { message: 'Stream ended without finish_reason', code: 'TRANSPORT' } },
}

test('rewrites missing-finish_reason error to stop when text was delivered', async () => {
  const chunks = await collect((async function* () {
    yield { type: 'block-start', index: 0, blockType: 'text' }
    yield { type: 'text-delta', index: 0, text: 'PONG' }
    yield { type: 'block-end', index: 0, block: { type: 'text', text: 'PONG' } }
    yield { type: 'usage', usage: { inputTokens: 5, outputTokens: 1 } }
    yield ERROR_FINISH
  })())

  const finish = chunks.find((c) => c.type === 'finish')
  assert.deepEqual(finish.reason, { kind: 'stop' })
  assert.equal(finish.reason.kind, 'stop')
  assert.ok(!('failure' in finish.reason))
  assert.equal(chunks.filter((c) => c.type === 'text-delta').length, 1)
  // usage passthrough intact
  assert.ok(chunks.some((c) => c.type === 'usage'))
})

test('rewrites missing-finish_reason error to tool-calls when a tool call was delivered', async () => {
  const chunks = await collect((async function* () {
    yield { type: 'block-start', index: 0, blockType: 'tool-call' }
    yield { type: 'tool-call-delta', index: 0, id: 'toolu_1', name: 'get_weather', argumentsDelta: '{"city":"San Francisco"}' }
    yield {
      type: 'block-end', index: 0,
      block: { type: 'tool-call', id: 'toolu_1', name: 'get_weather', arguments: '{"city":"San Francisco"}' },
    }
    yield ERROR_FINISH
  })())

  const finish = chunks.find((c) => c.type === 'finish')
  assert.deepEqual(finish.reason, { kind: 'tool-calls' })
})

test('keeps the error when the message differs (e.g. real truncation wording)', async () => {
  const chunks = await collect((async function* () {
    yield { type: 'text-delta', index: 0, text: 'partial' }
    yield {
      type: 'finish',
      reason: { kind: 'error', failure: { message: 'other side closed', code: 'TRANSPORT' } },
    }
  })())

  const finish = chunks.find((c) => c.type === 'finish')
  assert.equal(finish.reason.kind, 'error')
  assert.equal(finish.reason.failure.message, 'other side closed')
})

test('keeps the error when no content was delivered', async () => {
  const chunks = await collect((async function* () {
    yield ERROR_FINISH
  })())

  const finish = chunks.find((c) => c.type === 'finish')
  assert.equal(finish.reason.kind, 'error')
  assert.equal(finish.reason.failure.code, 'TRANSPORT')
})

test('passes a successful stream through untouched', async () => {
  const chunks = await collect((async function* () {
    yield { type: 'text-delta', index: 0, text: 'hi' }
    yield { type: 'finish', reason: { kind: 'stop' } }
  })())

  assert.deepEqual(chunks.at(-1).reason, { kind: 'stop' })
  assert.equal(chunks.length, 2)
})

test('passes non-matching error finishes and other chunks through untouched', async () => {
  const chunks = await collect((async function* () {
    yield { type: 'usage', usage: { inputTokens: 1, outputTokens: 1 } }
    yield {
      type: 'finish',
      reason: { kind: 'error', failure: { message: 'rate limit hit', code: 'RATE_LIMIT' } },
    }
  })())

  assert.equal(chunks[0].type, 'usage')
  assert.equal(chunks[1].reason.failure.code, 'RATE_LIMIT')
  assert.equal(chunks.length, 2)
})

test('keeps replayState when rewriting', async () => {
  const chunks = await collect((async function* () {
    yield { type: 'text-delta', index: 0, text: 'x' }
    yield { ...ERROR_FINISH, replayState: { version: 1, provider: 'snowflake-cortex' } }
  })())

  const finish = chunks.find((c) => c.type === 'finish')
  assert.equal(finish.reason.kind, 'stop')
  assert.deepEqual(finish.replayState, { version: 1, provider: 'snowflake-cortex' })
})
