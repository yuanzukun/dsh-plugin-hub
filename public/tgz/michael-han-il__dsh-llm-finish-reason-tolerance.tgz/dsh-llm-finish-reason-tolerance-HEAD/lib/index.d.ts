import type { Context } from '@deepseek-ai/cordis'
import type z from '@deepseek-ai/schemastery'

/** Plugin configuration: which provider routes the tolerance applies to. */
export interface FinishReasonToleranceConfig {
  /**
   * Provider route keys (as configured in the `llm-pi-ai` settings section,
   * e.g. `snowflake-cortex`) this tolerance applies to. Empty or omitted
   * applies to every provider route.
   */
  providers?: string[]
}

export declare const name: 'llm-finish-reason-tolerance'

export declare const inject: ['llm']

export declare const Config: z<FinishReasonToleranceConfig>

export declare function apply(ctx: Context, config: FinishReasonToleranceConfig): void

/**
 * Internal: wrap a harness `llm/stream` chunk iterable and promote the pi-ai
 * "Stream ended without finish_reason" error to a successful terminal reason
 * when content was already delivered. Exported for testing.
 */
export declare function tolerateMissingFinishReason(
  stream: AsyncIterable<import('@deepseek-ai/dsh-llm').StreamChunk>,
): AsyncGenerator<import('@deepseek-ai/dsh-llm').StreamChunk, void, void>
