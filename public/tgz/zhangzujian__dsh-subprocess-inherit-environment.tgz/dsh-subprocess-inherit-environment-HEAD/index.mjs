/**
 * Deliberately forward the Harness process environment through the DSH
 * subprocess seam. This disables the subprocess service's ambient credential
 * scrub for callers that use resolveExecutable(), spawn(), or spawnTerminal().
 */

export const name = 'subprocess-inherit-environment'
export const inject = ['subprocess']

const CORDIS_ORIGINAL = Symbol.for('cordis.original')
const ACTIVE_INSTALLATION = Symbol.for('@zhangzujian/dsh-subprocess-inherit-environment.active')
const ACTIVE_RUNTIMES = new WeakSet()

function inheritedEnvironment(explicit) {
  return {
    ...process.env,
    ...explicit,
  }
}

function callWithInheritedEnvironmentSpec(runtime, original, isActive, arguments_) {
  if (!isActive()) return Reflect.apply(original, runtime, arguments_)
  const [spec, ...rest] = arguments_
  return Reflect.apply(original, runtime, [{
    ...spec,
    env: inheritedEnvironment(spec.env),
  }, ...rest])
}

const METHOD_OPERATIONS = [
  {
    method: 'resolveExecutable',
    createWrapper: (runtime, original, isActive) => function resolveExecutableWithInheritedEnvironment(command, env, signal) {
      const arguments_ = Array.from(arguments)
      if (!isActive()) return Reflect.apply(original, runtime, arguments_)
      arguments_[1] = inheritedEnvironment(env)
      return Reflect.apply(original, runtime, arguments_)
    },
  },
  {
    method: 'spawn',
    createWrapper: (runtime, original, isActive) => function spawnWithInheritedEnvironment() {
      return callWithInheritedEnvironmentSpec(runtime, original, isActive, Array.from(arguments))
    },
  },
  {
    method: 'spawnTerminal',
    createWrapper: (runtime, original, isActive) => function spawnTerminalWithInheritedEnvironment() {
      return callWithInheritedEnvironmentSpec(runtime, original, isActive, Array.from(arguments))
    },
  },
]

function sameDescriptor(left, right) {
  if (left === undefined || right === undefined) return left === right
  return left.configurable === right.configurable
    && left.enumerable === right.enumerable
    && left.writable === right.writable
    && left.value === right.value
    && left.get === right.get
    && left.set === right.set
}

function restoreDescriptor(runtime, property, previousDescriptor) {
  if (previousDescriptor === undefined) delete runtime[property]
  else Object.defineProperty(runtime, property, previousDescriptor)
  if (!sameDescriptor(Object.getOwnPropertyDescriptor(runtime, property), previousDescriptor)) {
    throw new Error(`subprocess installation did not restore the previous descriptor for ${String(property)}`)
  }
}

function createDescriptorInstallation(
  runtime,
  property,
  previousDescriptor,
  createDescriptor,
) {
  const installedDescriptor = createDescriptor(previousDescriptor)
  const forceRestore = () => restoreDescriptor(runtime, property, previousDescriptor)
  return {
    install() {
      Object.defineProperty(runtime, property, installedDescriptor)
      if (!sameDescriptor(
        Object.getOwnPropertyDescriptor(runtime, property),
        installedDescriptor,
      )) {
        throw new Error(`subprocess installation did not install the requested descriptor for ${String(property)}`)
      }
    },
    restore() {
      if (!sameDescriptor(
        Object.getOwnPropertyDescriptor(runtime, property),
        installedDescriptor,
      )) return
      forceRestore()
    },
  }
}

function createMethodInstallation(runtime, snapshot) {
  let active = true
  const deactivate = () => {
    active = false
  }
  const descriptorInstallation = createDescriptorInstallation(
    runtime,
    snapshot.method,
    snapshot.previousDescriptor,
    previousDescriptor => ({
      configurable: true,
      enumerable: previousDescriptor?.enumerable ?? false,
      writable: true,
      value: snapshot.createWrapper(runtime, snapshot.original, () => active),
    }),
  )

  return {
    deactivate,
    install: descriptorInstallation.install,
    restore: descriptorInstallation.restore,
  }
}

export const apply = (ctx) => {
  const subprocessView = ctx.get('subprocess')
  const runtime = subprocessView[CORDIS_ORIGINAL] ?? subprocessView
  if (ACTIVE_RUNTIMES.has(runtime)) {
    throw new Error('subprocess environment inheritance is already active on this runtime')
  }

  ACTIVE_RUNTIMES.add(runtime)
  let descriptorSnapshots = []
  let previousMarkerDescriptor
  const methodInstallations = []
  let markerInstallation

  const deactivateMethods = (errors) => {
    for (const methodInstallation of methodInstallations) {
      try { methodInstallation.deactivate() } catch (error) { errors.push(error) }
    }
  }

  const teardown = () => {
    const errors = []
    try {
      deactivateMethods(errors)
      for (let index = methodInstallations.length - 1; index >= 0; index -= 1) {
        try { methodInstallations[index].restore() } catch (error) { errors.push(error) }
      }
      try { markerInstallation?.restore() } catch (error) { errors.push(error) }
    } finally {
      ACTIVE_RUNTIMES.delete(runtime)
    }
    if (errors.length > 0) {
      throw new AggregateError(errors, 'subprocess environment inheritance teardown failed')
    }
  }

  const rollbackSetup = (setupError) => {
    const errors = []
    try {
      deactivateMethods(errors)
      for (let index = descriptorSnapshots.length - 1; index >= 0; index -= 1) {
        const snapshot = descriptorSnapshots[index]
        try {
          restoreDescriptor(runtime, snapshot.method, snapshot.previousDescriptor)
        } catch (error) {
          errors.push(error)
        }
      }
      if (previousMarkerDescriptor !== undefined
        || Object.hasOwn(runtime, ACTIVE_INSTALLATION)) {
        try {
          restoreDescriptor(runtime, ACTIVE_INSTALLATION, previousMarkerDescriptor)
        } catch (error) {
          errors.push(error)
        }
      }
    } finally {
      ACTIVE_RUNTIMES.delete(runtime)
    }
    if (errors.length > 0) {
      throw new AggregateError(
        [setupError, ...errors],
        'subprocess environment inheritance setup and rollback failed',
      )
    }
    throw setupError
  }

  try {
    previousMarkerDescriptor = Object.getOwnPropertyDescriptor(runtime, ACTIVE_INSTALLATION)
    descriptorSnapshots = METHOD_OPERATIONS.map(operation => ({
      ...operation,
      previousDescriptor: Object.getOwnPropertyDescriptor(runtime, operation.method),
    }))

    if (runtime[ACTIVE_INSTALLATION] !== undefined) {
      throw new Error('subprocess environment inheritance is already active on this runtime')
    }
    for (const snapshot of descriptorSnapshots) {
      const { previousDescriptor } = snapshot
      if (previousDescriptor !== undefined && !previousDescriptor.configurable) {
        throw new TypeError(`subprocess.${snapshot.method} must be configurable`)
      }
      if (previousDescriptor === undefined && !Object.isExtensible(runtime)) {
        throw new TypeError(`subprocess runtime must be extensible to install inherited ${snapshot.method}`)
      }
    }
    if (previousMarkerDescriptor !== undefined && !previousMarkerDescriptor.configurable) {
      throw new TypeError('subprocess active installation marker must be configurable')
    }
    if (previousMarkerDescriptor === undefined && !Object.isExtensible(runtime)) {
      throw new TypeError('subprocess runtime must be extensible to install the active marker')
    }

    const methodSnapshots = descriptorSnapshots.map((snapshot) => {
      const original = runtime[snapshot.method]
      if (typeof original !== 'function') {
        throw new TypeError(`subprocess.${snapshot.method} must be a function`)
      }
      return { ...snapshot, original }
    })

    const installation = {}
    markerInstallation = createDescriptorInstallation(
      runtime,
      ACTIVE_INSTALLATION,
      previousMarkerDescriptor,
      () => ({
        configurable: true,
        enumerable: false,
        writable: false,
        value: installation,
      }),
    )
    markerInstallation.install()

    for (const snapshot of methodSnapshots) {
      const methodInstallation = createMethodInstallation(runtime, snapshot)
      methodInstallations.push(methodInstallation)
      methodInstallation.install()
    }

    ctx.effect(() => teardown, 'subprocess complete environment inheritance teardown')
  } catch (error) {
    rollbackSetup(error)
  }
}
