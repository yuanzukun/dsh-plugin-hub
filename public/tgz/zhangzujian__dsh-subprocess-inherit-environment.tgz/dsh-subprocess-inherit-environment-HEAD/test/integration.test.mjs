import assert from 'node:assert/strict'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { afterEach, before, describe, it } from 'node:test'
import * as plugin from '../index.mjs'

const installDir = process.env.DSH_INSTALL_DIR
const integration = installDir === undefined ? describe.skip : describe
const TEST_TOKEN = 'DSH_PLUGIN_INTEGRATION_SECRET_TOKEN'
let savedToken

async function packageImport(name) {
  return import(pathToFileURL(join(installDir, 'node_modules', '@deepseek-ai', name, 'lib', 'index.js')).href)
}

integration('DSH rc.6 integration', () => {
  let Context
  let LocalSubprocessRuntime

  before(async () => {
    ;({ Context } = await packageImport('cordis'))
    ;({ default: LocalSubprocessRuntime } = await packageImport('dsh-subprocess-local'))
    savedToken = process.env[TEST_TOKEN]
  })

  afterEach(() => {
    if (savedToken === undefined) delete process.env[TEST_TOKEN]
    else process.env[TEST_TOKEN] = savedToken
  })

  async function run(runtime) {
    const handle = runtime.spawn({
      argv: ['bash', '-c', `test -n "$${TEST_TOKEN}"`],
      cwd: process.cwd(),
      stdio: {
        stdin: 'ignore',
        stdout: { maxBytes: 1024 },
        stderr: { maxBytes: 1024 },
      },
      graceMs: 1000,
    })
    return handle.done
  }

  async function runTerminal(runtime) {
    const handle = await runtime.spawnTerminal({
      argv: ['bash', '-c', `test -n "$${TEST_TOKEN}"`],
      cwd: process.cwd(),
      rows: 24,
      cols: 80,
      graceMs: 1000,
    })
    return handle.done
  }

  it('restores the scrub through captured later wrappers after disposal', async () => {
    process.env[TEST_TOKEN] = 'integration-secret'
    const ctx = new Context()
    await ctx.plugin(LocalSubprocessRuntime)

    const baseline = await run(ctx.subprocess)
    assert.equal(baseline.exitCode, 1)
    const baselineTerminal = await runTerminal(ctx.subprocess)
    assert.equal(baselineTerminal.exitCode, 1)

    const pluginFiber = await ctx.plugin(plugin)
    const inherited = await run(ctx.subprocess)
    assert.equal(inherited.exitCode, 0)
    const inheritedTerminal = await runTerminal(ctx.subprocess)
    assert.equal(inheritedTerminal.exitCode, 0)

    const runtime = ctx.subprocess[Symbol.for('cordis.original')] ?? ctx.subprocess
    const capturedResolveExecutable = runtime.resolveExecutable
    const capturedSpawn = runtime.spawn
    const capturedSpawnTerminal = runtime.spawnTerminal
    runtime.resolveExecutable = (...args) => capturedResolveExecutable.apply(runtime, args)
    runtime.spawn = (...args) => capturedSpawn.apply(runtime, args)
    runtime.spawnTerminal = (...args) => capturedSpawnTerminal.apply(runtime, args)

    await pluginFiber.dispose()
    const resolved = await runtime.resolveExecutable(
      'bash',
      { PATH: '/usr/bin:/bin' },
      new AbortController().signal,
    )
    assert.equal(typeof resolved, 'string')
    const restored = await run(ctx.subprocess)
    assert.equal(restored.exitCode, 1)
    const restoredTerminal = await runTerminal(ctx.subprocess)
    assert.equal(restoredTerminal.exitCode, 1)
    await ctx.fiber.dispose()
  })
})
