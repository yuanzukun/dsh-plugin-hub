import assert from 'node:assert/strict'
import { afterEach, describe, it } from 'node:test'
import { apply, inject, name } from '../index.mjs'

const TEST_TOKEN = 'DSH_PLUGIN_TEST_SECRET_TOKEN'
const TEST_ORDINARY = 'DSH_PLUGIN_TEST_ORDINARY'
const ACTIVE_INSTALLATION = Symbol.for('@zhangzujian/dsh-subprocess-inherit-environment.active')
const OPERATION_CASES = [
  {
    method: 'resolveExecutable',
    createRecordingMethod: calls => function resolveExecutable(command, env, signal) {
      calls.push({ method: 'resolveExecutable', command, env, signal })
      return Promise.resolve(`/resolved/${command}`)
    },
  },
  {
    name: 'spawn',
    method: 'spawn',
    secret: 'spawn-secret',
    createRecordingMethod: calls => function spawn(spec) {
      calls.push({ method: 'spawn', spec })
      return { kind: 'spawn-handle' }
    },
    createSpec: () => ({
      argv: ['program'],
      cwd: '/workspace',
      stdio: { stdin: 'ignore', stdout: 'inherit', stderr: 'inherit' },
      graceMs: 100,
      env: { EXPLICIT: 'caller' },
    }),
    expectedResult: { kind: 'spawn-handle' },
  },
  {
    name: 'terminal spawn',
    method: 'spawnTerminal',
    secret: 'terminal-secret',
    createRecordingMethod: calls => function spawnTerminal(spec) {
      calls.push({ method: 'spawnTerminal', spec })
      return Promise.resolve({ kind: 'terminal-handle' })
    },
    createSpec: () => ({
      argv: ['bash'],
      cwd: '/workspace',
      rows: 24,
      cols: 80,
      graceMs: 100,
      env: { TERM: 'dumb' },
    }),
    expectedResult: { kind: 'terminal-handle' },
  },
]
const REQUIRED_METHODS = OPERATION_CASES.map(testCase => testCase.method)
const saved = new Map()

function setEnvironment(values) {
  for (const [key, value] of Object.entries(values)) {
    if (!saved.has(key)) saved.set(key, process.env[key])
    if (value === undefined) delete process.env[key]
    else process.env[key] = value
  }
}

afterEach(() => {
  for (const [key, value] of saved) {
    if (value === undefined) delete process.env[key]
    else process.env[key] = value
  }
  saved.clear()
})

function createCompatibleSubprocess() {
  return Object.fromEntries(OPERATION_CASES.map(testCase => (
    [testCase.method, function compatibleSubprocessMethod() {}]
  )))
}

function snapshotInstallationDescriptors(runtime) {
  return {
    methods: Object.fromEntries(REQUIRED_METHODS.map(method => (
      [method, Object.getOwnPropertyDescriptor(runtime, method)]
    ))),
    marker: Object.getOwnPropertyDescriptor(runtime, ACTIVE_INSTALLATION),
  }
}

function assertInstallationDescriptorsUnchanged(runtime, snapshot) {
  for (const method of REQUIRED_METHODS) {
    assert.deepEqual(
      Object.getOwnPropertyDescriptor(runtime, method),
      snapshot.methods[method],
    )
  }
  assert.deepEqual(
    Object.getOwnPropertyDescriptor(runtime, ACTIVE_INSTALLATION),
    snapshot.marker,
  )
}

function createUnappliedContextFixture({ runtime = createCompatibleSubprocess(), effect } = {}) {
  let disposer
  let effectCalls = 0
  const captureDisposer = factory => {
    disposer = factory()
  }
  let effectBehavior = effect ?? captureDisposer
  const ctx = {
    subprocess: runtime,
    get(service) { return this[service] },
    effect(factory, description) {
      effectCalls += 1
      return effectBehavior(factory, description)
    },
  }

  return {
    ctx,
    get effectCalls() { return effectCalls },
    dispose() { return disposer() },
    setEffectBehavior(nextEffect = captureDisposer) {
      effectBehavior = nextEffect
    },
  }
}

function fixture() {
  const calls = []
  const subprocess = Object.fromEntries(OPERATION_CASES.map(testCase => (
    [testCase.method, testCase.createRecordingMethod(calls)]
  )))
  const contextFixture = createUnappliedContextFixture({ runtime: subprocess })
  apply(contextFixture.ctx)
  return { calls, subprocess, dispose: () => contextFixture.dispose() }
}

async function assertCapturedSpecMethodStopsInjecting({ method, secret, createSpec, expectedResult }) {
  setEnvironment({ [TEST_TOKEN]: secret })
  const testFixture = fixture()
  const captured = testFixture.subprocess[method]
  testFixture.subprocess[method] = (...args) => captured(...args)
  testFixture.dispose()

  const spec = createSpec()
  const result = await testFixture.subprocess[method](spec)

  assert.deepEqual(result, expectedResult)
  assert.equal(testFixture.calls[0].spec === spec, true)
  assert.equal(testFixture.calls[0].spec.env === spec.env, true)
  assert.equal(Object.hasOwn(testFixture.calls[0].spec.env, TEST_TOKEN), false)
}

const capturedSpecMethodCases = OPERATION_CASES.filter(testCase => testCase.createSpec !== undefined)

describe('dsh-subprocess-inherit-environment', () => {
  it('exports a Cordis plugin with the subprocess dependency', () => {
    assert.equal(name, 'subprocess-inherit-environment')
    assert.deepEqual(inject, ['subprocess'])
  })

  it('rejects duplicate installation on the same subprocess runtime', () => {
    const subprocess = createCompatibleSubprocess()
    const disposers = []
    const contextFixture = createUnappliedContextFixture({
      runtime: subprocess,
      effect: factory => { disposers.push(factory()) },
    })

    apply(contextFixture.ctx)
    assert.throws(() => apply(contextFixture.ctx), /already active/)
    Object.defineProperty(subprocess, ACTIVE_INSTALLATION, {
      configurable: true,
      value: undefined,
    })
    assert.throws(() => apply(contextFixture.ctx), /already active/)
    disposers.shift()()
    assert.doesNotThrow(() => apply(contextFixture.ctx))
    disposers.shift()()
  })

  const methodPreflightCases = [
    {
      name: 'incompatible runtimes without leaving partial installation state',
      mutate(subprocess, method) {
        const validMethod = subprocess[method]
        subprocess[method] = undefined
        return () => { subprocess[method] = validMethod }
      },
      error: method => new RegExp(`subprocess\\.${method} must be a function`),
    },
    {
      name: 'non-configurable method descriptors before installation',
      mutate(subprocess, method) {
        Object.defineProperty(subprocess, method, {
          ...Object.getOwnPropertyDescriptor(subprocess, method),
          configurable: false,
        })
      },
      error: method => new RegExp(`subprocess\\.${method} must be configurable`),
    },
  ]

  for (const testCase of methodPreflightCases) {
    it(`rejects ${testCase.name}`, () => {
      for (const incompatibleMethod of REQUIRED_METHODS) {
        const subprocess = createCompatibleSubprocess()
        const repair = testCase.mutate(subprocess, incompatibleMethod)
        const beforeInstallation = snapshotInstallationDescriptors(subprocess)
        const contextFixture = createUnappliedContextFixture({ runtime: subprocess })

        assert.throws(() => apply(contextFixture.ctx), testCase.error(incompatibleMethod))
        assertInstallationDescriptorsUnchanged(subprocess, beforeInstallation)
        assert.equal(contextFixture.effectCalls, 0)

        if (repair !== undefined) {
          repair()
          assert.doesNotThrow(() => apply(contextFixture.ctx))
          contextFixture.dispose()
        }
      }
    })
  }

  it('captures each method once during preflight before any installation mutation', () => {
    const subprocess = createCompatibleSubprocess()
    const calls = []
    const originalSpawn = function originalSpawn(...args) {
      calls.push(args)
      return { kind: 'stateful-spawn-handle' }
    }
    let spawnReads = 0
    Object.defineProperty(subprocess, ACTIVE_INSTALLATION, {
      configurable: true,
      enumerable: false,
      value: undefined,
    })
    const storedMarkerDescriptor = Object.getOwnPropertyDescriptor(subprocess, ACTIVE_INSTALLATION)
    const originalDescriptor = {
      configurable: true,
      enumerable: true,
      get() {
        spawnReads += 1
        Object.defineProperty(subprocess, 'spawn', {
          configurable: true,
          writable: true,
          value: undefined,
        })
        Object.defineProperty(subprocess, ACTIVE_INSTALLATION, {
          configurable: true,
          enumerable: true,
          value: undefined,
        })
        return originalSpawn
      },
    }
    Object.defineProperty(subprocess, 'spawn', originalDescriptor)
    const storedDescriptor = Object.getOwnPropertyDescriptor(subprocess, 'spawn')
    const contextFixture = createUnappliedContextFixture({ runtime: subprocess })

    assert.doesNotThrow(() => apply(contextFixture.ctx))
    assert.equal(spawnReads, 1)

    const extra = { kind: 'extra' }
    const result = subprocess.spawn({ env: {} }, extra)
    assert.deepEqual(result, { kind: 'stateful-spawn-handle' })
    assert.equal(calls[0].length, 2)
    assert.equal(calls[0][1], extra)

    contextFixture.dispose()
    assert.deepEqual(Object.getOwnPropertyDescriptor(subprocess, 'spawn'), storedDescriptor)
    assert.deepEqual(
      Object.getOwnPropertyDescriptor(subprocess, ACTIVE_INSTALLATION),
      storedMarkerDescriptor,
    )
  })

  it('reserves the runtime and rolls back getter side effects during preflight', () => {
    const subprocess = createCompatibleSubprocess()
    const originalResolve = subprocess.resolveExecutable
    Object.defineProperty(subprocess, 'resolveExecutable', {
      configurable: true,
      get() {
        assert.throws(() => apply(contextFixture.ctx), /already active/)
        Object.defineProperty(subprocess, 'spawnTerminal', {
          configurable: true,
          writable: true,
          value: undefined,
        })
        return originalResolve
      },
    })
    Object.defineProperty(subprocess, 'spawn', {
      configurable: true,
      get() { throw new Error('preflight getter failed') },
    })
    const beforeInstallation = snapshotInstallationDescriptors(subprocess)
    const contextFixture = createUnappliedContextFixture({ runtime: subprocess })

    assert.throws(() => apply(contextFixture.ctx), /preflight getter failed/)
    assertInstallationDescriptorsUnchanged(subprocess, beforeInstallation)
    assert.equal(contextFixture.effectCalls, 0)
  })

  it('rejects runtimes that cannot define all installation properties', () => {
    const cases = [
      {
        subprocess: Object.preventExtensions(Object.create(createCompatibleSubprocess())),
        error: /subprocess runtime must be extensible to install inherited resolveExecutable/,
      },
      {
        subprocess: Object.preventExtensions(createCompatibleSubprocess()),
        error: /subprocess runtime must be extensible to install the active marker/,
      },
      {
        subprocess: (() => {
          const runtime = createCompatibleSubprocess()
          Object.defineProperty(runtime, ACTIVE_INSTALLATION, {
            configurable: false,
            value: undefined,
          })
          return runtime
        })(),
        error: /subprocess active installation marker must be configurable/,
      },
    ]

    for (const { subprocess, error } of cases) {
      const beforeInstallation = snapshotInstallationDescriptors(subprocess)
      const contextFixture = createUnappliedContextFixture({ runtime: subprocess })

      assert.throws(() => apply(contextFixture.ctx), error)
      assertInstallationDescriptorsUnchanged(subprocess, beforeInstallation)
      assert.equal(contextFixture.effectCalls, 0)
    }
  })

  it('rejects a proxy that reports success without installing the requested descriptor', () => {
    const target = createCompatibleSubprocess()
    const beforeInstallation = snapshotInstallationDescriptors(target)
    const subprocess = new Proxy(target, {
      defineProperty(object, property, descriptor) {
        if (property === 'spawn' && descriptor.value?.name === 'spawnWithInheritedEnvironment') {
          return true
        }
        return Reflect.defineProperty(object, property, descriptor)
      },
    })
    const contextFixture = createUnappliedContextFixture({ runtime: subprocess })

    assert.throws(() => apply(contextFixture.ctx), /did not install the requested descriptor/)
    assertInstallationDescriptorsUnchanged(target, beforeInstallation)
    assert.equal(contextFixture.effectCalls, 0)
  })

  it('rolls back an incremental installation failure and supports immediate retry', () => {
    const target = createCompatibleSubprocess()
    const beforeInstallation = snapshotInstallationDescriptors(target)
    let failInstallation = true
    const subprocess = new Proxy(target, {
      defineProperty(object, property, descriptor) {
        if (failInstallation
          && property === 'spawnTerminal'
          && descriptor.value?.name === 'spawnTerminalWithInheritedEnvironment') {
          failInstallation = false
          Reflect.defineProperty(object, 'spawn', {
            configurable: true,
            writable: true,
            value: () => 'proxy changed earlier installation',
          })
          Reflect.defineProperty(object, property, {
            ...descriptor,
            enumerable: !descriptor.enumerable,
          })
          throw new Error('simulated installation race')
        }
        return Reflect.defineProperty(object, property, descriptor)
      },
    })
    const contextFixture = createUnappliedContextFixture({ runtime: subprocess })

    assert.throws(() => apply(contextFixture.ctx), /simulated installation race/)
    assertInstallationDescriptorsUnchanged(target, beforeInstallation)
    assert.equal(contextFixture.effectCalls, 0)

    assert.doesNotThrow(() => apply(contextFixture.ctx))
    contextFixture.dispose()
  })

  it('continues teardown after a restore failure and clears runtime reservation', () => {
    const target = createCompatibleSubprocess()
    const originals = { ...target }
    const failedRestores = new Set(['spawn', 'spawnTerminal'])
    const subprocess = new Proxy(target, {
      defineProperty(object, property, descriptor) {
        if (failedRestores.has(property) && descriptor.value === originals[property]) {
          failedRestores.delete(property)
          throw new Error(`simulated ${property} restore failure`)
        }
        return Reflect.defineProperty(object, property, descriptor)
      },
    })
    const contextFixture = createUnappliedContextFixture({ runtime: subprocess })
    apply(contextFixture.ctx)

    let teardownError
    try {
      contextFixture.dispose()
    } catch (error) {
      teardownError = error
    }
    assert.equal(teardownError instanceof AggregateError, true)
    assert.deepEqual(
      teardownError.errors.map(error => error.message).sort(),
      ['simulated spawn restore failure', 'simulated spawnTerminal restore failure'],
    )
    assert.equal(target.resolveExecutable, originals.resolveExecutable)
    assert.equal(Object.hasOwn(target, ACTIVE_INSTALLATION), false)

    assert.doesNotThrow(() => apply(contextFixture.ctx))
    contextFixture.dispose()
  })

  it('rolls back installation when effect registration fails', () => {
    const subprocess = createCompatibleSubprocess()
    const beforeInstallation = snapshotInstallationDescriptors(subprocess)
    const contextFixture = createUnappliedContextFixture({
      runtime: subprocess,
      effect: () => { throw new Error('effect registration failed') },
    })

    assert.throws(() => apply(contextFixture.ctx), /effect registration failed/)
    assertInstallationDescriptorsUnchanged(subprocess, beforeInstallation)

    contextFixture.setEffectBehavior()
    assert.doesNotThrow(() => apply(contextFixture.ctx))
    contextFixture.dispose()
  })

  it('forwards the complete process environment to ordinary spawns', () => {
    setEnvironment({ [TEST_TOKEN]: 'unit-secret', [TEST_ORDINARY]: 'unit-ordinary' })
    const testFixture = fixture()
    const spec = {
      argv: ['program'],
      cwd: '/workspace',
      stdio: { stdin: 'ignore', stdout: 'inherit', stderr: 'inherit' },
      graceMs: 100,
      env: { EXPLICIT: 'caller' },
    }
    const result = testFixture.subprocess.spawn(spec)

    assert.deepEqual(result, { kind: 'spawn-handle' })
    assert.equal(testFixture.calls[0].spec.env[TEST_TOKEN], 'unit-secret')
    assert.equal(testFixture.calls[0].spec.env[TEST_ORDINARY], 'unit-ordinary')
    assert.equal(testFixture.calls[0].spec.env.EXPLICIT, 'caller')
    assert.equal(spec.env[TEST_TOKEN], undefined)
    assert.notEqual(testFixture.calls[0].spec, spec)
    assert.notEqual(testFixture.calls[0].spec.env, spec.env)
  })

  it('preserves explicit overrides and tombstones', () => {
    setEnvironment({ [TEST_TOKEN]: 'ambient-secret', [TEST_ORDINARY]: 'ambient-ordinary' })
    const testFixture = fixture()
    testFixture.subprocess.spawn({
      argv: ['program'],
      cwd: '/workspace',
      stdio: { stdin: 'ignore', stdout: 'inherit', stderr: 'inherit' },
      graceMs: 100,
      env: { [TEST_TOKEN]: 'explicit-secret', [TEST_ORDINARY]: undefined },
    })

    assert.equal(testFixture.calls[0].spec.env[TEST_TOKEN], 'explicit-secret')
    assert.equal(testFixture.calls[0].spec.env[TEST_ORDINARY], undefined)
  })

  it('forwards the complete environment to terminal spawns', async () => {
    setEnvironment({ [TEST_TOKEN]: 'terminal-secret' })
    const testFixture = fixture()
    const spec = {
      argv: ['bash'],
      cwd: '/workspace',
      rows: 24,
      cols: 80,
      graceMs: 100,
      env: { TERM: 'dumb' },
    }
    const result = await testFixture.subprocess.spawnTerminal(spec)

    assert.deepEqual(result, { kind: 'terminal-handle' })
    assert.equal(testFixture.calls[0].spec.env[TEST_TOKEN], 'terminal-secret')
    assert.equal(testFixture.calls[0].spec.env.TERM, 'dumb')
    assert.equal(spec.env[TEST_TOKEN], undefined)
  })

  it('forwards the complete environment during executable lookup', async () => {
    setEnvironment({ [TEST_TOKEN]: 'lookup-secret' })
    const testFixture = fixture()
    const signal = new AbortController().signal
    const resolved = await testFixture.subprocess.resolveExecutable('tool', { PATH: '/custom' }, signal)

    assert.equal(resolved, '/resolved/tool')
    assert.equal(testFixture.calls[0].env[TEST_TOKEN], 'lookup-secret')
    assert.equal(testFixture.calls[0].env.PATH, '/custom')
    assert.equal(testFixture.calls[0].signal, signal)
  })

  it('stops injecting the environment through a captured executable resolver after disposal', async () => {
    setEnvironment({ [TEST_TOKEN]: 'lookup-secret' })
    const testFixture = fixture()
    const capturedResolveExecutable = testFixture.subprocess.resolveExecutable
    testFixture.subprocess.resolveExecutable = (...args) => capturedResolveExecutable(...args)
    testFixture.dispose()

    const explicitEnvironment = { PATH: '/custom' }
    const signal = new AbortController().signal
    const resolved = await testFixture.subprocess.resolveExecutable('tool', explicitEnvironment, signal)

    assert.equal(resolved, '/resolved/tool')
    assert.equal(testFixture.calls[0].command, 'tool')
    assert.equal(testFixture.calls[0].env === explicitEnvironment, true)
    assert.equal(Object.hasOwn(testFixture.calls[0].env, TEST_TOKEN), false)
    assert.equal(testFixture.calls[0].signal, signal)
  })

  for (const testCase of capturedSpecMethodCases) {
    it(`stops injecting the environment through a captured ${testCase.name} after disposal`, async () => {
      await assertCapturedSpecMethodStopsInjecting(testCase)
    })
  }

  it('preserves exact argument lists through captured wrappers after disposal', () => {
    for (const method of REQUIRED_METHODS) {
      const calls = []
      const subprocess = createCompatibleSubprocess()
      subprocess[method] = function recordExactArguments(...args) {
        calls.push(args)
        return method
      }
      const contextFixture = createUnappliedContextFixture({ runtime: subprocess })
      apply(contextFixture.ctx)
      const captured = subprocess[method]
      subprocess[method] = (...args) => captured(...args)
      contextFixture.dispose()

      const first = { method, position: 0 }
      const second = { method, position: 1 }
      const third = { method, position: 2 }
      const cases = [[], [first], [first, second, third]]
      for (const args of cases) {
        assert.equal(subprocess[method](...args), method)
        assert.equal(calls.at(-1).length, args.length)
        for (const [index, argument] of args.entries()) {
          assert.equal(calls.at(-1)[index], argument)
        }
      }
    }
  })

  it('restores inherited methods exactly on disposal', () => {
    class Runtime {
      resolveExecutable() {}
      spawn() {}
      spawnTerminal() {}
    }
    const subprocess = new Runtime()
    const contextFixture = createUnappliedContextFixture({ runtime: subprocess })
    apply(contextFixture.ctx)
    assert.equal(Object.hasOwn(subprocess, 'spawn'), true)
    contextFixture.dispose()
    assert.equal(Object.hasOwn(subprocess, 'resolveExecutable'), false)
    assert.equal(Object.hasOwn(subprocess, 'spawn'), false)
    assert.equal(Object.hasOwn(subprocess, 'spawnTerminal'), false)
  })

  it('does not overwrite a later accessor that exposes a captured wrapper', () => {
    const testFixture = fixture()
    const capturedSpawn = testFixture.subprocess.spawn
    const laterDescriptor = {
      configurable: true,
      enumerable: true,
      get() { return capturedSpawn },
    }
    Object.defineProperty(testFixture.subprocess, 'spawn', laterDescriptor)

    testFixture.dispose()

    const currentDescriptor = Object.getOwnPropertyDescriptor(testFixture.subprocess, 'spawn')
    assert.equal(currentDescriptor.get, laterDescriptor.get)
    assert.equal(currentDescriptor.enumerable, true)
  })

  it('does not overwrite later wrappers during disposal', () => {
    const testFixture = fixture()
    const laterResolve = () => 'later resolve'
    const laterSpawn = () => 'later spawn'
    const laterTerminal = () => 'later terminal'
    testFixture.subprocess.resolveExecutable = laterResolve
    testFixture.subprocess.spawn = laterSpawn
    testFixture.subprocess.spawnTerminal = laterTerminal
    testFixture.dispose()
    assert.equal(testFixture.subprocess.resolveExecutable, laterResolve)
    assert.equal(testFixture.subprocess.spawn, laterSpawn)
    assert.equal(testFixture.subprocess.spawnTerminal, laterTerminal)
  })
})
