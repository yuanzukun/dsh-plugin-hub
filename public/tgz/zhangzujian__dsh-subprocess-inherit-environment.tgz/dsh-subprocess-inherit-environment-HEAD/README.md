# dsh-subprocess-inherit-environment

A removable DeepSeek Harness / DSH plugin that deliberately forwards the
Harness process's complete environment through the `ctx.subprocess` service.

## Security warning

**This plugin disables DSH's subprocess credential isolation.** Every caller
that uses the wrapped subprocess service can pass the Harness process's API
keys, tokens, passwords, secrets, cookies, proxy credentials, and other
environment values to child processes. Model-generated commands, repository
scripts, package installers, CLIs, MCP servers, and terminal programs may read
or exfiltrate those values.

Do not install this plugin on a shared or untrusted Harness deployment. Prefer
a dedicated tool or an exact variable allowlist whenever possible.

The plugin never logs environment names or values by itself. That does not
prevent a child process from printing or transmitting them.

## Behavior

DSH normally starts subprocesses from a scrubbed parent environment. Variable
names matching `KEY`, `PASSWORD`, `SECRET`, or `TOKEN`, plus ambient `DSH_*`
names, are removed before explicit request entries are merged.

This plugin wraps the three `ctx.subprocess` operations and supplies an
explicit environment layer built from `process.env`:

- `resolveExecutable(command, env, signal)`
- `spawn(spec)`
- `spawnTerminal(spec)`

All three operations must be functions. Own method descriptors must be
configurable; inherited methods and an absent installation marker require an
extensible runtime; an existing marker slot must be configurable. Apply checks
that complete replacement contract before mutation. If defining the marker or
any method still fails, or Cordis rejects effect registration, apply rolls back
the marker and every installed method descriptor before rethrowing the error.

Caller-provided entries are merged after a fresh `process.env` spread on every
call, so explicit overrides and `undefined` tombstones retain their original
meaning. The plugin does not mutate caller-owned requests.

Disposal first makes every installed wrapper inactive, then restores previous
method descriptors when the plugin still owns them. A later wrapper that
captured and delegates to a plugin method therefore reaches the original DSH
method with the caller's exact arguments after disposal, without environment
injection. Later method replacements are not overwritten. Installing this
plugin more than once on the same subprocess runtime is rejected while the
first installation is active, avoiding ambiguous out-of-order teardown.

The plugin covers consumers that route process creation through
`ctx.subprocess`. It cannot affect code that bypasses that service and calls
Node.js process APIs, worker APIs, or an SDK-owned spawn directly.

## Install into a DSH profile

Until this package is published to npm, clone it and add the local directory:

```bash
git clone https://github.com/zhangzujian/dsh-subprocess-inherit-environment.git
cd dsh-subprocess-inherit-environment
npx @deepseek-ai/dsh@0.1.0-rc.6 plugin --profile web add "$PWD"
```

The package declares a DSH bundle, so `dsh plugin` adds its patch layer to the
profile automatically. Restart DSH if the active profile does not hot-reload
server plugins.

To remove it and restore DSH's default credential scrub:

```bash
npx @deepseek-ai/dsh@0.1.0-rc.6 plugin --profile web remove @zhangzujian/dsh-subprocess-inherit-environment
```

For a local file URL overlay:

```yaml
- insert:
    - id: subprocess-inherit-environment
      name: file:///absolute/path/to/dsh-subprocess-inherit-environment/index.mjs
```

## Test

Unit tests require Node.js 22 or newer:

```bash
npm test
```

Integration tests run against an installed DSH tree and verify the original
scrub, inherited environment, and disposal restoration without printing any
secret value:

```bash
DSH_INSTALL_DIR=/path/to/dsh/install npm run test:integration
```

`DSH_INSTALL_DIR` is the directory containing `node_modules/@deepseek-ai`.

## License

MIT
