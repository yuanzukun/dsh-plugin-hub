// SPDX-FileCopyrightText: 2026 Elouan Martinet <exa@elou.world>
//
// SPDX-License-Identifier: MIT

package podman

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/opencontainers/runtime-spec/specs-go"
	"go.podman.io/podman/v6/pkg/bindings"
	"go.podman.io/podman/v6/pkg/bindings/containers"
	"go.podman.io/podman/v6/pkg/bindings/pods"
	entities "go.podman.io/podman/v6/pkg/domain/entities/types"
	"go.podman.io/podman/v6/pkg/specgen"
)

// lookupTimeout bounds the quick, read-only Podman calls (exists, inspect,
// list) so a wedged API cannot hang a tool. Mutating and build calls stay
// unbounded: a container recreate or an image pull is legitimately long, and
// cutting it off would be worse than waiting.
const lookupTimeout = 30 * time.Second

// lookupContext returns a bounded context for a quick Podman lookup, falling
// back to a plain background context for a zero-value client (tests).
func (c *Client) lookupContext() (context.Context, context.CancelFunc) {
	if c.ctx == nil {
		return context.Background(), func() {}
	}
	return context.WithTimeout(c.ctx, lookupTimeout)
}

// guestRestartPolicy keeps guest pods and containers alive across podman/host
// restarts. "unless-stopped" restarts after a crash or a podman restart but
// respects an explicit stop, which is what the orchestrator's own stop and
// recreate paths perform.
const guestRestartPolicy = "unless-stopped"

// newGuestPodSpec builds the pod spec for one workspace's pod, carrying the
// restart policy so its containers come back after a podman/host restart.
func newGuestPodSpec(name string) *entities.PodSpec {
	return &entities.PodSpec{
		PodSpecGen: specgen.PodSpecGenerator{Name: name, RestartPolicy: guestRestartPolicy},
	}
}

// applyGuestContainerPolicy stamps the guest container policy onto a spec
// generator.
func applyGuestContainerPolicy(generator *specgen.SpecGenerator) {
	generator.RestartPolicy = guestRestartPolicy
	// The root filesystem is read-only, so the container needs writable
	// scratch space. Podman's CLI defaults --read-only-tmpfs to true, but the
	// specgen API does not: without it no tmpfs is mounted and /tmp, /var/tmp
	// and /run stay on the read-only rootfs. It also leaves /dev and /dev/shm
	// writable instead of applying the read-only dev profile.
	generator.ReadOnlyFilesystem = boolPtr(true)
	generator.ReadWriteTmpfs = boolPtr(true)
}

type Client struct {
	ctx                                             context.Context
	socketRoot, hostSocketRoot, projectRoot         string
	skillDir                                        string
	guestAgentImage, guestAgentBin, guestAgentMount string
	hostGuestBinary                                 string
	logger                                          *slog.Logger
}

func New(ctx context.Context, socket, socketRoot, guestAgentImage, guestAgentBin, guestAgentMount, hostSocketRoot, projectRoot, skillDir, hostGuestBinary string, logger *slog.Logger) (*Client, error) {
	connected, err := bindings.NewConnection(ctx, socket)
	if err != nil {
		return nil, err
	}
	return &Client{ctx: connected, socketRoot: socketRoot, hostSocketRoot: hostSocketRoot, projectRoot: projectRoot, skillDir: skillDir, guestAgentImage: guestAgentImage, guestAgentBin: guestAgentBin, guestAgentMount: guestAgentMount, hostGuestBinary: hostGuestBinary, logger: logger}, nil
}

func (c *Client) log() *slog.Logger {
	if c.logger != nil {
		return c.logger
	}
	return slog.Default()
}

// connReady guards against a client whose podman connection context is
// missing (e.g. a zero-value Client constructed without New), turning what
// would otherwise be a panic into a regular error.
func (c *Client) connReady() error {
	if c.ctx == nil {
		return errors.New("podman connection is not configured")
	}
	return nil
}

// EnsurePod lazily creates the pod when it does not already exist. Containers
// created afterwards are placed inside it, sharing its network namespace.
func (c *Client) EnsurePod(name string) error {
	ctx, cancel := c.lookupContext()
	exists, err := pods.Exists(ctx, name, nil)
	cancel()
	if err != nil {
		return err
	}
	if exists {
		return nil
	}
	c.log().Info("creating pod", "pod_name", name)
	_, err = pods.CreatePodFromSpec(c.ctx, newGuestPodSpec(name))
	if err != nil {
		c.log().Error("pod creation failed", "pod_name", name, "error", err)
		return fmt.Errorf("create pod: %w", err)
	}
	return nil
}

// RemovePod deletes the pod, tolerating an already-absent pod.
func (c *Client) RemovePod(name string) error {
	ctx, cancel := c.lookupContext()
	exists, err := pods.Exists(ctx, name, nil)
	cancel()
	if err != nil {
		return err
	}
	if !exists {
		return nil
	}
	c.log().Info("removing pod", "pod_name", name)
	if _, err := pods.Remove(c.ctx, name, &pods.RemoveOptions{Force: boolPtr(true)}); err != nil {
		c.log().Error("pod removal failed", "pod_name", name, "error", err)
		return fmt.Errorf("remove pod: %w", err)
	}
	return nil
}

func (c *Client) CreateWorkspace(pod, name, image, token string, mounts []specs.Mount, secrets []specgen.Secret, envSecrets map[string]string, env map[string]string, paths []string) error {
	return c.createContainer(pod, name, image, token, mounts, secrets, envSecrets, env, paths, false)
}

// CreatePTC creates and starts the one shared PTC container. It takes no
// workspace pod: the shared container does not join a pod, so it can run with
// no network namespace. It also takes no mounts, secrets, environment, or PATH
// additions: the PTC container runs the PTC runtime alone, as root, with only
// the guest agent's socket, the size-capped scratch tmpfs, and the PTC mode
// marker.
func (c *Client) CreatePTC(name, image, token string) error {
	return c.createContainer("", name, image, token, nil, nil, nil, nil, nil, true)
}

func (c *Client) createContainer(pod, name, image, token string, mounts []specs.Mount, secrets []specgen.Secret, envSecrets map[string]string, env map[string]string, paths []string, ptc bool) error {
	c.log().Info("creating guest container", "pod_name", pod, "container_name", name, "image", image, "mount_count", len(mounts), "ptc", ptc)
	socketDir := filepath.Join(c.socketRoot, name)
	if err := os.MkdirAll(socketDir, 0700); err != nil {
		return err
	}
	if err := guestAgentSourcesConfigured(c.hostGuestBinary, c.guestAgentImage); err != nil {
		return err
	}
	// The shared PTC container must not join a pod: a pod would give it the
	// pod's network namespace, while it runs with network mode none.
	if !ptc {
		if err := c.EnsurePod(pod); err != nil {
			return err
		}
	}
	generator := c.newGuestSpec(pod, name, image, token, mounts, secrets, envSecrets, env, paths, ptc)
	for _, volume := range generator.Volumes {
		if err := c.ensureVolume(volume.Name); err != nil {
			return err
		}
	}
	if imageVolume := guestAgentImageVolume(c.guestAgentImage, c.guestAgentMount); imageVolume != nil {
		if err := c.ensureImage(imageVolume.Source); err != nil {
			return err
		}
		generator.ImageVolumes = append(generator.ImageVolumes, imageVolume)
	}
	if _, err := containers.CreateWithSpec(c.ctx, generator, nil); err != nil {
		c.log().Error("guest container creation failed", "pod_name", pod, "container_name", name, "error", err)
		return fmt.Errorf("create container: %w", err)
	}
	if err := containers.Start(c.ctx, name, nil); err != nil {
		c.log().Error("guest container start failed", "container_name", name, "error", err)
		// The container was created but never came up. Remove it so its name is
		// not left in use by an untracked container.
		if removeErr := c.Remove(name); removeErr != nil {
			c.log().Warn("failed to remove container after start failure", "container_name", name, "error", removeErr)
		}
		return err
	}
	c.log().Info("guest container started", "pod_name", pod, "container_name", name)
	return nil
}

// newGuestSpec builds the spec for a guest container. It is pure (it never
// touches the podman API), so the PTC container's shape — root user, no user
// environment, secrets, volumes, ports or workspace mounts, no pod, no network,
// only the capabilities the guest agent needs to switch identity and repair a
// child's home — is unit-testable without a daemon.
// The caller ensures the named volumes and the guest-agent image exist before
// handing the spec to podman.
func (c *Client) newGuestSpec(pod, name, image, token string, mounts []specs.Mount, secrets []specgen.Secret, envSecrets map[string]string, env map[string]string, paths []string, ptc bool) *specgen.SpecGenerator {
	init := true
	hostSocketDir := filepath.Join(c.hostSocketRoot, name)
	binaryDest := filepath.Join(c.guestAgentMount, c.guestAgentBin)
	generator := specgen.NewSpecGenerator(image, false)
	generator.Name = name
	// A pod would share its network namespace, so the pod-less PTC container
	// keeps an empty Pod and its own network mode.
	if !ptc {
		generator.Pod = pod
	}
	generator.Command = []string{binaryDest}
	spill := spillMount()
	if ptc {
		spill = ptcSpillMount()
	}
	containerMounts := append([]specs.Mount(nil), mounts...)
	if !ptc {
		containerMounts = append(containerMounts, c.skillMounts()...)
	}
	containerMounts = append(containerMounts, spill)
	if ptc {
		containerMounts = append(containerMounts, ptcScratchMounts()...)
	}
	generator.Env = containerEnv(c.socketRoot, name, c.projectRoot, token, env, guestFileMounts(containerMounts), paths, ptc)
	generator.EnvSecrets = envSecrets
	generator.Secrets = append(generator.Secrets, secrets...)
	generator.Init = &init
	applyGuestContainerPolicy(generator)
	if ptc {
		// The agent keeps euid 0 so it can switch each PTC child to a numeric
		// uid; the image user is never inherited.
		generator.User = "0"
		// The PTC runtime calls tools host-side and needs no network at all.
		generator.NetNS = specgen.Namespace{NSMode: specgen.NoNetwork}
		// Drop every capability, then add back only what the guest agent needs
		// to start children as another uid/gid (identity.CanSwitchUser) and to
		// prepare their homes: CHOWN changes a home's owner, DAC_OVERRIDE
		// traverses and writes an existing target-owned 0700 home, and
		// SETUID/SETGID perform the identity switch.
		generator.CapDrop = []string{"ALL"}
		generator.CapAdd = []string{"CHOWN", "DAC_OVERRIDE", "SETUID", "SETGID"}
		// no-new-privileges: a setuid binary inside the image still cannot
		// gain anything the process did not already hold.
		generator.NoNewPrivileges = boolPtr(true)
	}
	ociMounts, volumes := classifyMounts(containerMounts)
	generator.Volumes = append(generator.Volumes, volumes...)
	generator.Mounts = append(ociMounts, guestAgentMounts(hostSocketDir, c.socketRoot, name, c.hostGuestBinary, binaryDest)...)
	return generator
}

// classifyMounts separates raw OCI mounts (bind, tmpfs) from named-volume
// mounts. Named volumes cannot be handed to the runtime as OCI mounts (crun
// rejects the "volume" type); podman must mount them through its own volume
// mechanism instead.
func classifyMounts(mounts []specs.Mount) (oci []specs.Mount, volumes []*specgen.NamedVolume) {
	for _, mount := range mounts {
		if mount.Type == "volume" {
			volumes = append(volumes, &specgen.NamedVolume{Name: mount.Source, Dest: mount.Destination, Options: mount.Options})
			continue
		}
		oci = append(oci, mount)
	}
	return oci, volumes
}

// spillRoot is the container-local tmpfs where the guest agent writes bounded
// command-output spill files. It is mounted read-write into every guest
// container and exposed to the guest file API so a caller can read a spill
// after the in-memory tail truncates. The plugin must use the same path.
const spillRoot = "/tmp/dsh-podman"

// spillMount is the container-local tmpfs backing spillRoot. The mode keeps it
// writable by the agent regardless of the container user.
func spillMount() specs.Mount {
	return specs.Mount{Type: "tmpfs", Destination: spillRoot, Options: []string{"rw", "mode=1777"}}
}

// ptcTmpfsSize caps each in-memory scratch filesystem of the PTC container.
// The PTC runtime needs writable scratch (/tmp, /var/tmp, and the command
// output spill) but must not be able to exhaust the host's memory through it.
const ptcTmpfsSize = "64m"

// ptcTmpfsMount is one size-capped, world-writable scratch tmpfs of the PTC
// container. The explicit mount replaces the uncapped one podman's read-only
// tmpfs policy would otherwise add.
func ptcTmpfsMount(destination string) specs.Mount {
	return specs.Mount{Type: "tmpfs", Destination: destination, Options: []string{"rw", "size=" + ptcTmpfsSize, "mode=1777"}}
}

// ptcScratchMounts are the PTC container's size-capped /tmp and /var/tmp. /run
// stays on podman's read-only tmpfs policy.
func ptcScratchMounts() []specs.Mount {
	return []specs.Mount{ptcTmpfsMount("/tmp"), ptcTmpfsMount("/var/tmp")}
}

// ptcSpillMount is the size-capped spill tmpfs of the PTC container.
func ptcSpillMount() specs.Mount {
	return ptcTmpfsMount(spillRoot)
}

// skillMounts returns the read-only bind mount exposing the configured host skill
// directory to every workspace guest container, or nil when none is configured. The
// PTC container is deliberately excluded: it runs the PTC runtime, not the workspace
// agent, so no workspace path belongs in its mount namespace. Source and
// destination are the same path, so a skill's own references to its files resolve
// inside the container; guestMountsEnv tells the guest file API about it, which is
// also what keeps writes to it refused. The mount belongs to the container only:
// it is appended to a copy of the caller's list, so it never reaches the persisted
// workspace state.
func (c *Client) skillMounts() []specs.Mount {
	if c.skillDir == "" {
		return nil
	}
	return []specs.Mount{{Type: "bind", Source: c.skillDir, Destination: c.skillDir, Options: []string{"ro"}}}
}

// guestFileMounts is the mount list the guest file API is told about: the
// container's mounts plus the writable scratch tmpfs podman mounts through its
// read-only tmpfs (/tmp and /var/tmp), which the API must be told about to read
// and write there. /tmp is a reserved destination, so no caller mount can
// shadow it; a caller mount at /var/tmp is kept ahead of the scratch entry.
func guestFileMounts(mounts []specs.Mount) []specs.Mount {
	scratch := []specs.Mount{
		{Type: "tmpfs", Destination: "/tmp", Options: []string{"rw"}},
		{Type: "tmpfs", Destination: "/var/tmp", Options: []string{"rw"}},
	}
	return append(append([]specs.Mount(nil), mounts...), scratch...)
}

// guestAgentMounts returns the socket bind mount and, when a host guest-agent
// binary is configured, a read-only bind mount of that binary at binaryDest.
func guestAgentMounts(hostSocketDir, socketRoot, name, hostGuestBinary, binaryDest string) []specs.Mount {
	mounts := []specs.Mount{{Type: "bind", Source: hostSocketDir, Destination: filepath.Join(socketRoot, name), Options: []string{"rw"}}}
	if hostGuestBinary != "" {
		mounts = append([]specs.Mount{{Type: "bind", Source: hostGuestBinary, Destination: binaryDest, Options: []string{"ro"}}}, mounts...)
	}
	return mounts
}

// guestAgentImageVolume describes the guest-agent image mount, or nil when no
// guest-agent image is configured. Image volumes are always read-only.
func guestAgentImageVolume(image, mountDir string) *specgen.ImageVolume {
	if image == "" {
		return nil
	}
	return &specgen.ImageVolume{Source: image, Destination: mountDir, ReadWrite: false}
}

// guestAgentSourcesConfigured reports an error when neither a host guest-agent
// binary nor a guest-agent image is configured.
func guestAgentSourcesConfigured(hostGuestBinary, guestAgentImage string) error {
	if hostGuestBinary == "" && guestAgentImage == "" {
		return errors.New("no guest agent source configured: set DSH_PODMAN_GUEST_AGENT_IMAGE or DSH_PODMAN_HOST_GUEST_AGENT_BIN")
	}
	return nil
}

// ensureImage pulls the named image into local storage when it is not already
// present.
func (c *Client) ensureImage(name string) error {
	exists, err := c.ImageExists(name)
	if err != nil {
		return err
	}
	if exists {
		return nil
	}
	return c.ImagePull(name)
}

func (c *Client) Stop(name string) error {
	c.log().Info("stopping guest container", "container_name", name)
	err := containers.Stop(c.ctx, name, nil)
	if err != nil {
		c.log().Error("guest container stop failed", "container_name", name, "error", err)
	} else {
		c.log().Info("guest container stopped", "container_name", name)
	}
	return err
}

func (c *Client) ContainerExists(name string) (bool, error) {
	ctx, cancel := c.lookupContext()
	defer cancel()
	exists, err := containers.Exists(ctx, name, nil)
	if err != nil {
		c.log().Error("guest container lookup failed", "container_name", name, "error", err)
	} else {
		c.log().Info("guest container lookup completed", "container_name", name, "exists", exists)
	}
	return exists, err
}

// ContainerRunning reports whether the named container is running. It is used
// to bring a stopped guest container back before handing its socket to a
// caller.
func (c *Client) ContainerRunning(name string) (bool, error) {
	ctx, cancel := c.lookupContext()
	defer cancel()
	inspect, err := containers.Inspect(ctx, name, nil)
	if err != nil {
		c.log().Error("guest container inspect failed", "container_name", name, "error", err)
		return false, err
	}
	running := inspect.State != nil && inspect.State.Running
	c.log().Info("guest container inspect completed", "container_name", name, "running", running)
	return running, nil
}

// ContainerAgentState reports, in one inspect, whether the named container's
// guest agent is outdated and which credential its agent expects.
//
// Outdated means the image volume mounted at GuestAgentMount is not the
// configured guest-agent image; it is always false when no image is configured,
// or when a host binary is configured (that binary is bind-mounted and takes
// precedence, so the image is not the agent source). A container with no image
// volume at all predates the mechanism and counts as outdated.
//
// The credential is the container's DSH_PODMAN_GUEST_TOKEN ("" when absent).
// Comparing it with the stored token is what catches a credential that rotated
// after the container was created.
func (c *Client) ContainerAgentState(name string) (stale bool, token string, err error) {
	ctx, cancel := c.lookupContext()
	defer cancel()
	inspect, err := containers.Inspect(ctx, name, nil)
	if err != nil {
		c.log().Error("guest container inspect failed", "container_name", name, "error", err)
		return false, "", err
	}
	if inspect.Config != nil {
		for _, entry := range inspect.Config.Env {
			if value, ok := strings.CutPrefix(entry, "DSH_PODMAN_GUEST_TOKEN="); ok {
				token = value
				break
			}
		}
	}
	if c.guestAgentImage == "" || c.hostGuestBinary != "" {
		return false, token, nil
	}
	for _, mount := range inspect.Mounts {
		if mount.Type == "image" && mount.Destination == c.guestAgentMount {
			return mount.Source != c.guestAgentImage, token, nil
		}
	}
	// No image volume at the guest-agent mount: the container predates the
	// image-volume mechanism, so it does not carry the configured agent.
	return true, token, nil
}

// ListContainerBindMounts returns, for every container whose podman name starts
// with namePrefix, running or stopped, its bind mounts keyed by podman name:
// the host source path, with an "rw" or "ro" option.
//
// It is the orchestrator's view of which containers could rewrite a project
// path (their read-write binds) and of which paths podman will resolve again
// when a container starts (all binds), both of which the project-mount
// conflict check compares against. Stopped containers are included because
// podman restarts them on its own; untracked containers are included, so a
// leftover from a failed create is seen too.
func (c *Client) ListContainerBindMounts(namePrefix string) (map[string][]specs.Mount, error) {
	ctx, cancel := c.lookupContext()
	defer cancel()
	all := true
	listed, err := containers.List(ctx, &containers.ListOptions{All: &all})
	if err != nil {
		c.log().Error("guest container list failed", "error", err)
		return nil, err
	}
	result := make(map[string][]specs.Mount)
	for _, container := range listed {
		if container.IsInfra {
			continue
		}
		name := ""
		for _, candidate := range container.Names {
			if strings.HasPrefix(candidate, namePrefix) {
				name = candidate
				break
			}
		}
		if name == "" {
			continue
		}
		inspect, err := containers.Inspect(ctx, name, nil)
		if err != nil {
			// A container removed between the list and the inspect cannot mount
			// anything, so it is skipped; any other lookup failure is real.
			exists, existsErr := containers.Exists(ctx, name, nil)
			if existsErr == nil && !exists {
				continue
			}
			c.log().Error("guest container inspect failed", "container_name", name, "error", err)
			return nil, err
		}
		for _, mount := range inspect.Mounts {
			if mount.Type != "bind" {
				continue
			}
			mode := "ro"
			if mount.RW {
				mode = "rw"
			}
			result[name] = append(result[name], specs.Mount{Type: "bind", Source: mount.Source, Destination: mount.Destination, Options: []string{mode}})
		}
	}
	return result, nil
}

func boolPtr(value bool) *bool {
	return &value
}

// Remove deletes the named guest container, tolerating an already-absent one
// (a container removed outside dsh-podman must not block a replace or a
// recreate). It mirrors RemovePod's tolerance of an absent pod.
func (c *Client) Remove(name string) error {
	c.log().Info("removing guest container", "container_name", name)
	_, err := containers.Remove(c.ctx, name, &containers.RemoveOptions{Force: boolPtr(true), Ignore: boolPtr(true)})
	if err != nil {
		c.log().Error("guest container removal failed", "container_name", name, "error", err)
	} else {
		c.log().Info("guest container removed", "container_name", name)
	}
	return err
}

// RemoveSocketDir deletes a container's socket directory, tolerating an
// already-absent one. It mirrors the directory CreateWorkspace makes for the
// guest agent's socket.
func (c *Client) RemoveSocketDir(name string) error {
	dir := filepath.Join(c.socketRoot, name)
	if err := os.RemoveAll(dir); err != nil {
		c.log().Error("guest socket dir removal failed", "container_name", name, "dir", dir, "error", err)
		return err
	}
	c.log().Info("guest socket dir removed", "container_name", name, "dir", dir)
	return nil
}

func (c *Client) RecreateWorkspace(pod, name, image, token string, mounts []specs.Mount, secrets []specgen.Secret, envSecrets map[string]string, env map[string]string, paths []string) error {
	c.log().Info("recreating guest container", "pod_name", pod, "container_name", name, "image", image, "mount_count", len(mounts))
	exists, err := c.ContainerExists(name)
	if err != nil {
		return err
	}
	if exists {
		if err := c.Stop(name); err != nil {
			return err
		}
		if err := c.Remove(name); err != nil {
			return err
		}
	}
	return c.CreateWorkspace(pod, name, image, token, mounts, secrets, envSecrets, env, paths)
}

// PTCModeEnv marks a container as the reserved PTC container. The plugin reads
// it (through the container kind) to route PTC work there instead of a guest
// container.
const PTCModeEnv = "DSH_PODMAN_GUEST_PTC_MODE"

// containerEnv builds the guest container environment: the reserved
// orchestrator agent variables, then every user variable. A PTC container
// carries the PTC mode marker and no user variables at all. User keys that
// collide with the reserved DSH_PODMAN namespace are skipped defensively (the
// caller has already validated them).
func containerEnv(socketRoot, name, projectRoot, token string, user map[string]string, mounts []specs.Mount, paths []string, ptc bool) map[string]string {
	env := map[string]string{
		"DSH_PODMAN_GUEST_TOKEN":   token,
		"DSH_PODMAN_GUEST_SOCKET":  filepath.Join(socketRoot, name, "guest.sock"),
		"DSH_PODMAN_PROJECTS_ROOT": projectRoot,
	}
	if ptc {
		env[PTCModeEnv] = "true"
	}
	if encoded := guestMountsEnv(mounts, projectRoot); encoded != "" {
		env["DSH_PODMAN_GUEST_MOUNTS"] = encoded
	}
	if encoded := guestPathsEnv(paths); encoded != "" {
		env["DSH_PODMAN_GUEST_PATHS"] = encoded
	}
	for key, value := range user {
		if strings.HasPrefix(key, "DSH_PODMAN") {
			continue
		}
		env[key] = value
	}
	return env
}

// guestPathsEnv serializes the container's PATH additions for the guest agent,
// which prepends them to every process it starts. Empty means no additions.
func guestPathsEnv(paths []string) string {
	if len(paths) == 0 {
		return ""
	}
	encoded, err := json.Marshal(paths)
	if err != nil {
		return ""
	}
	return string(encoded)
}

// guestMountsEnv serializes the container's user mounts for the guest agent.
// Project bind mounts are covered by the projects root and are not listed; any
// other bind mount, which is the configured skill directory, is listed so the file
// API can read the files a skill runs. Secret mounts are deliberately omitted so
// the file API never reads them.
func guestMountsEnv(mounts []specs.Mount, projectRoot string) string {
	entries := make([]map[string]any, 0, len(mounts))
	for _, mount := range mounts {
		switch mount.Type {
		case "tmpfs":
			entries = append(entries, map[string]any{"path": mount.Destination, "read_only": false})
		case "volume":
			entries = append(entries, map[string]any{"path": mount.Destination, "read_only": hasOption(mount.Options, "ro")})
		case "bind":
			if isUnderPath(mount.Destination, projectRoot) {
				continue
			}
			entries = append(entries, map[string]any{"path": mount.Destination, "read_only": hasOption(mount.Options, "ro")})
		}
	}
	if len(entries) == 0 {
		return ""
	}
	encoded, err := json.Marshal(entries)
	if err != nil {
		return ""
	}
	return string(encoded)
}

// isUnderPath reports whether path is root itself or lies inside it. An empty root
// matches nothing, so a missing projects root never swallows a mount.
func isUnderPath(path, root string) bool {
	if root == "" {
		return false
	}
	return path == root || strings.HasPrefix(path, root+"/")
}

func hasOption(options []string, want string) bool {
	for _, option := range options {
		if option == want {
			return true
		}
	}
	return false
}
