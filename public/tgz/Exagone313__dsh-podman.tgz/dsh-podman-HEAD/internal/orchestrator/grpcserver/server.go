// SPDX-FileCopyrightText: 2026 Elouan Martinet <exa@elou.world>
//
// SPDX-License-Identifier: MIT

package grpcserver

import (
	"log/slog"
	"sync"

	ctl "github.com/Exagone313/dsh-podman/internal/genproto/dshctl/v1"
	imagebuild "github.com/Exagone313/dsh-podman/internal/orchestrator/images"
	"github.com/Exagone313/dsh-podman/internal/orchestrator/state"
	"github.com/opencontainers/runtime-spec/specs-go"
	"go.podman.io/podman/v6/pkg/specgen"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

// podmanAPI is the subset of the podman client the control plane drives. It is
// a consumer-side interface so tests can substitute a fake without a podman
// daemon; *podman.Client satisfies it.
type podmanAPI interface {
	ContainerExists(name string) (bool, error)
	ContainerRunning(name string) (bool, error)
	ContainerAgentState(name string) (bool, string, error)
	ContainerCreated(name string) (string, error)
	ListContainerBindMounts(namePrefix string) (map[string][]specs.Mount, error)
	CreateWorkspace(pod, name, image, token string, mounts []specs.Mount, secrets []specgen.Secret, envSecrets map[string]string, env map[string]string, paths []string) error
	CreatePTC(name, image, token string) error
	RecreateWorkspace(pod, name, image, token string, mounts []specs.Mount, secrets []specgen.Secret, envSecrets map[string]string, env map[string]string, paths []string) error
	Remove(name string) error
	RemovePod(name string) error
	RemoveSocketDir(name string) error
	Stop(name string) error
	ImageExists(name string) (bool, error)
	ImageLabels(name string) (map[string]string, error)
	ImageCreated(name string) string
	ImagePull(name string) error
	ImageRemove(name string) error
	VolumeExists(name string) (bool, error)
	VolumeCreate(name string) error
	VolumeList() ([]string, error)
	VolumeRemove(name string) error
	SecretExists(name string) (bool, error)
	SecretCreate(name, value string) error
	SecretList() ([]string, error)
	SecretRemove(name string) error
}

// ptcImages is the image-builder operation the reserved PTC container needs:
// the single PTC tag and a build for a missing or stale image. *imagebuild.Builder
// satisfies it; tests substitute their own.
type ptcImages interface {
	PTCImageTag() string
	BuildPTC(dshVersion string) (string, error)
}

type Server struct {
	ctl.UnimplementedOrchestratorControlServer
	ProjectsRoot     string
	HostProjectsRoot string
	SocketsRoot      string
	// GuestAgentMount is the container path the guest agent image is mounted
	// at. Mounts must not shadow it: the container's entry point is executed
	// from below it.
	GuestAgentMount string
	Store           *state.Store
	Podman          podmanAPI
	ImageBuilder    *imagebuild.Builder
	BaseImagePrefix string
	VolumePrefix    string
	SecretPrefix    string
	Logger          *slog.Logger

	// PTCImages, when set, replaces ImageBuilder for the on-demand PTC image.
	// It is nil in production and set by tests, so the build path can run
	// without a podman daemon.
	PTCImages ptcImages

	// Gateway is the optional port-publishing gateway. It is nil when none is
	// configured, and the port RPCs then report that publishing is unavailable.
	Gateway gatewayAPI

	// GuestPorts publishes pod ports on a container's guest agent. It is nil in
	// production, where the real dialer is used, and set by tests.
	GuestPorts GuestPorts

	// gatewayStatus caches the last gateway state the background loop observed.
	gatewayStatus gatewayStatusCache

	// containerLocks serializes work on one podman container so two concurrent
	// ensures cannot recreate the same name at once. Keyed by podman name,
	// which is unique per workspace and container.
	locksMu        sync.Mutex
	containerLocks map[string]*sync.Mutex

	// mountsMu serializes the project-mount conflict check with the container
	// create it guards, so two creates cannot both pass the check and then
	// mount overlapping paths.
	mountsMu sync.Mutex
}

// lockProjectMounts takes the project-mount lock and returns its unlock
// function. It is held across the conflict check and the podman create that
// follows, and is always taken after any per-container lock.
func (s *Server) lockProjectMounts() func() {
	s.mountsMu.Lock()
	return s.mountsMu.Unlock
}

// lockContainer takes the per-container lock and returns its unlock function.
func (s *Server) lockContainer(podmanName string) func() {
	s.locksMu.Lock()
	if s.containerLocks == nil {
		s.containerLocks = make(map[string]*sync.Mutex)
	}
	lock, ok := s.containerLocks[podmanName]
	if !ok {
		lock = &sync.Mutex{}
		s.containerLocks[podmanName] = lock
	}
	s.locksMu.Unlock()
	lock.Lock()
	return lock.Unlock
}

func (s *Server) log() *slog.Logger {
	if s.Logger != nil {
		return s.Logger
	}
	return slog.Default()
}

// grpcError maps a plain error to an Internal status error, passing through
// status errors produced by the resolution helpers unchanged.
func grpcError(err error) error {
	if code := status.Code(err); code != codes.Unknown {
		return err
	}
	return status.Error(codes.Internal, err.Error())
}

// ptcImageBuilder returns the image builder the PTC container uses, preferring
// the test substitute when one is set.
func (s *Server) ptcImageBuilder() (ptcImages, error) {
	if s.PTCImages != nil {
		return s.PTCImages, nil
	}
	if s.ImageBuilder == nil {
		return nil, status.Error(codes.FailedPrecondition, "image builder is not configured")
	}
	return s.ImageBuilder, nil
}

// cloneMap returns a shallow copy of a string map, or nil when the source is
// empty. A nil source yields nil.
func cloneMap(source map[string]string) map[string]string {
	if len(source) == 0 {
		return nil
	}
	result := make(map[string]string, len(source))
	for key, value := range source {
		result[key] = value
	}
	return result
}
