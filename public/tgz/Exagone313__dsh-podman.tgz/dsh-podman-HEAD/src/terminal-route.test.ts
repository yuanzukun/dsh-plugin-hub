// SPDX-FileCopyrightText: 2026 Elouan Martinet <exa@elou.world>
//
// SPDX-License-Identifier: MIT

import test from "node:test";
import assert from "node:assert/strict";
import {
  FakeExecStream,
  FakeTerminalCall,
  WORKSPACE_ID,
} from "./test-support.js";
import {
  TERMINAL_PATH,
  TERMINAL_RETAINED_PATH,
  TERMINAL_SHELLS_PATH,
  TERMINAL_TARGET_PATH,
  type TerminalFrame,
  type TerminalShellView,
  WORKSPACE_PENDING_CODE,
} from "./client/terminal-protocol.js";
import { workspaceSlug } from "./workspace-binding.js";
import { discoverShells, requireShell } from "./terminal-shells.js";
import { TerminalSessions } from "./terminal-sessions.js";
import { registerTerminalRoutes } from "./terminal-route.js";

const ROOT = "/projects/team";

function fakeGuest(options: { stdout?: string } = {}) {
  const terminal = new FakeTerminalCall();
  const starts: Array<Record<string, any>> = [];
  return {
    terminal,
    starts,
    binding: {
      guest: {
        exec: () =>
          new FakeExecStream(starts, { stdout: options.stdout ?? "" }),
        terminal: () => terminal,
      },
      token: "t",
    },
  };
}

function fakeResolver(binding: any) {
  const calls: string[] = [];
  return {
    calls,
    resolveForPath: async () => {
      calls.push("default");
      return binding;
    },
    containerBinding: async (_cwd: unknown, container: string) => {
      calls.push(container);
      return binding;
    },
    getConfig: () => ({ projectsRoot: "/projects" }),
  } as any;
}

function fakeRegistry() {
  return { list: () => [{ id: WORKSPACE_ID, path: ROOT }] };
}

function routeHarness(
  sessions: TerminalSessions,
  resolver: any,
  sessionStore?: { get: (id: string) => unknown },
) {
  const routes = new Map<string, any>();
  const ctx = {
    inject: (_names: string[], fn: (child: any) => void) => {
      fn({
        connection: {
          fetch: {
            register: (route: any) => {
              routes.set(route.path, route);
              return async () => {};
            },
          },
        },
      });
    },
    get: (name: string) => name === "sessions" ? sessionStore : undefined,
  };
  registerTerminalRoutes(ctx, resolver, sessions, fakeRegistry());
  return routes;
}

test("shell discovery parses the probe, dedups and prefers the most capable shell", async () => {
  const { binding } = fakeGuest({
    stdout:
      "sh\t/usr/bin/sh\nbash\t/usr/bin/bash\nzsh\t/opt/tools/bin/zsh\nnot a path\nbash\t/bin/bash\ndash\t/usr/bin/dash\nfish\t/usr/bin/fish\n",
  });
  const shells = await discoverShells(binding as any, ROOT);
  assert.deepEqual(
    shells.map((shell) => `${shell.name}=${shell.path}`),
    [
      "zsh=/opt/tools/bin/zsh",
      "bash=/usr/bin/bash",
      "fish=/usr/bin/fish",
      "dash=/usr/bin/dash",
      "sh=/usr/bin/sh",
    ],
  );
});

test("shell discovery ignores names outside the candidate list", async () => {
  const { binding } = fakeGuest({
    stdout: "rbash\t/usr/bin/rbash\ngit-shell\t/usr/bin/git-shell\n",
  });
  assert.deepEqual(await discoverShells(binding as any, ROOT), []);
});

test("the host resolves a session's workspace from its own directory", async () => {
  const { binding } = fakeGuest();
  const resolver = fakeResolver(binding);
  const sessions = new TerminalSessions({ resolver, retentionMs: 60_000 });
  try {
    const routes = routeHarness(sessions, resolver, {
      get: (id: string) =>
        id === "s1" ? { header: { cwd: `${ROOT}/src` } } : undefined,
    });
    const target = routes.get(TERMINAL_TARGET_PATH);
    assert.ok(target);

    const found = await target.fetch(
      new Request(`http://dsh.internal${TERMINAL_TARGET_PATH}?sessionId=s1`),
    );
    assert.equal(found.status, 200);
    assert.deepEqual(await found.json(), {
      workspace: "team",
      workspaceSlug: workspaceSlug(WORKSPACE_ID),
    });

    // A missing id, an unknown session, an empty directory and a directory
    // outside every workspace all refuse rather than guessing.
    const missingId = await target.fetch(
      new Request(`http://dsh.internal${TERMINAL_TARGET_PATH}`),
    );
    assert.equal(missingId.status, 400);
    assert.deepEqual(await missingId.json(), {
      error: "sessionId is required",
    });
    for (
      const store of [
        { get: () => undefined },
        { get: () => ({ header: { cwd: "" } }) },
        { get: () => ({ header: { cwd: "/elsewhere" } }) },
      ]
    ) {
      const other = routeHarness(sessions, resolver, store).get(
        TERMINAL_TARGET_PATH,
      );
      const refused = await other.fetch(
        new Request(`http://dsh.internal${TERMINAL_TARGET_PATH}?sessionId=s1`),
      );
      assert.equal(refused.status, 409);
      assert.deepEqual(await refused.json(), {
        error: "Cannot determine this session's workspace",
        code: WORKSPACE_PENDING_CODE,
      });
    }
  } finally {
    sessions.dispose();
  }
});

test("the target route waits for a workspace that registers late", async () => {
  const { binding } = fakeGuest();
  const resolver = fakeResolver(binding);
  const sessions = new TerminalSessions({ resolver, retentionMs: 60_000 });
  try {
    // The first polls run before the session exists, like a page restoring a
    // tab while the harness is still creating it.
    let lateCalls = 0;
    const late = routeHarness(sessions, resolver, {
      get: (id: string) => {
        lateCalls++;
        return id === "s1" && lateCalls > 2
          ? { header: { cwd: `${ROOT}/src` } }
          : undefined;
      },
    }).get(TERMINAL_TARGET_PATH);
    assert.ok(late);
    const found = await late.fetch(
      new Request(
        `http://dsh.internal${TERMINAL_TARGET_PATH}?sessionId=s1&wait=5000`,
      ),
    );
    assert.equal(found.status, 200);
    assert.deepEqual(await found.json(), {
      workspace: "team",
      workspaceSlug: workspaceSlug(WORKSPACE_ID),
    });
    assert.ok(lateCalls > 2);

    // A session that never registers spends the budget and then reports the
    // retryable pending answer, not the old hard refusal.
    let pendingCalls = 0;
    const pending = routeHarness(sessions, resolver, {
      get: () => {
        pendingCalls++;
        return undefined;
      },
    }).get(TERMINAL_TARGET_PATH);
    assert.ok(pending);
    const exhausted = await pending.fetch(
      new Request(
        `http://dsh.internal${TERMINAL_TARGET_PATH}?sessionId=s1&wait=250`,
      ),
    );
    assert.equal(exhausted.status, 409);
    assert.deepEqual(await exhausted.json(), {
      error: "Cannot determine this session's workspace",
      code: WORKSPACE_PENDING_CODE,
    });
    assert.ok(pendingCalls > 1);

    // Without `wait` the same unknown session is polled once and answered at
    // once, so a client that cannot retry does not pay the budget.
    let immediateCalls = 0;
    const immediate = routeHarness(sessions, resolver, {
      get: () => {
        immediateCalls++;
        return undefined;
      },
    }).get(TERMINAL_TARGET_PATH);
    assert.ok(immediate);
    const immediateResponse = await immediate.fetch(
      new Request(
        `http://dsh.internal${TERMINAL_TARGET_PATH}?sessionId=s1`,
      ),
    );
    assert.equal(immediateResponse.status, 409);
    assert.equal(immediateCalls, 1);
  } finally {
    sessions.dispose();
  }
});

test("a shell missing from the probe is refused", async () => {
  const { binding } = fakeGuest({ stdout: "bash\t/usr/bin/bash\n" });
  await assert.rejects(
    () => requireShell(binding as any, ROOT, "/bin/zsh"),
    /not available in this container/,
  );
});

test("terminal sessions stream frames, retain the shell and control it", async () => {
  const { binding, terminal } = fakeGuest({ stdout: "bash\t/usr/bin/bash\n" });
  const resolver = fakeResolver(binding);
  const sessions = new TerminalSessions({ resolver, retentionMs: 60_000 });
  try {
    const prepared = await sessions.prepare({
      sessionId: "s1",
      tabId: "t1",
      workspace: "team",
      cwd: ROOT,
      container: "",
      shell: "/usr/bin/bash",
      cols: 80,
      rows: 24,
    });
    assert.equal(prepared.attached, false);
    assert.deepEqual(resolver.calls, ["default"]);

    const frames: TerminalFrame[] = [];
    const detach = sessions.listen(
      prepared.terminalId,
      (frame) => frames.push(frame),
      new AbortController().signal,
    );
    assert.equal(frames[0]?.type, "ready");
    terminal.emitStdout(Buffer.from("hi"));
    assert.deepEqual(frames.at(-1), {
      type: "data",
      data: Buffer.from("hi").toString("base64"),
    });

    assert.equal(
      sessions.control({
        terminalId: prepared.terminalId,
        kind: "input",
        data: Buffer.from("x").toString("base64"),
      }),
      true,
    );
    assert.deepEqual(terminal.stdinChunks, [Buffer.from("x")]);
    assert.equal(
      sessions.control({
        terminalId: prepared.terminalId,
        kind: "resize",
        cols: 100,
        rows: 30,
      }),
      true,
    );
    assert.deepEqual(terminal.resizes, [{ cols: 100, rows: 30 }]);
    assert.equal(
      sessions.control({
        terminalId: prepared.terminalId,
        kind: "rename",
        title: "dev",
      }),
      true,
    );
    assert.deepEqual(frames.at(-1), { type: "title", title: "dev" });

    terminal.emitExit(0);
    // The exit frame is written from the guest's done promise.
    await new Promise((resolve) => setTimeout(resolve, 0));
    assert.equal(frames.at(-1)?.type, "exit");

    // Reattaching replays the serialized screen and the exit state.
    const again = await sessions.prepare({
      sessionId: "s1",
      tabId: "t1",
      workspace: "team",
      cwd: ROOT,
      container: "",
      shell: "/usr/bin/bash",
      cols: 80,
      rows: 24,
    });
    assert.equal(again.attached, true);
    assert.equal(again.terminalId, prepared.terminalId);
    const reattached: TerminalFrame[] = [];
    sessions.listen(
      again.terminalId,
      (frame) => reattached.push(frame),
      new AbortController().signal,
      again.snapshot,
    );
    assert.equal(reattached[0]?.type, "ready");
    assert.equal(reattached[1]?.type, "snapshot");
    assert.equal(reattached.at(-1)?.type, "exit");

    // A named container resolves through containerBinding.
    const other = await sessions.prepare({
      sessionId: "s1",
      tabId: "t2",
      workspace: "team",
      cwd: ROOT,
      container: "dev",
      shell: "/usr/bin/bash",
      cols: 80,
      rows: 24,
    });
    assert.deepEqual(resolver.calls, ["default", "dev"]);
    assert.equal(sessions.retained("s1").length, 2);
    assert.equal(
      sessions.control({ terminalId: other.terminalId, kind: "close" }),
      true,
    );
    assert.equal(sessions.retained("s1").length, 1);
    detach();
  } finally {
    sessions.dispose();
  }
});

test("terminal routes open, control, list and validate", async () => {
  const { binding, terminal } = fakeGuest({ stdout: "bash\t/usr/bin/bash\n" });
  const resolver = fakeResolver(binding);
  const sessions = new TerminalSessions({ resolver, retentionMs: 60_000 });
  try {
    const routes = routeHarness(sessions, resolver);
    const open = routes.get(TERMINAL_PATH);
    assert.ok(open);

    const missingShell = await open.fetch(
      new Request(
        `http://dsh.internal${TERMINAL_PATH}?sessionId=s1&tabId=t1&workspace=team&cols=80&rows=24`,
      ),
    );
    assert.equal(missingShell.status, 400);
    const unknownWorkspace = await open.fetch(
      new Request(
        `http://dsh.internal${TERMINAL_PATH}?sessionId=s1&tabId=t1&workspace=nope&shell=/usr/bin/bash&cols=80&rows=24`,
      ),
    );
    assert.equal(unknownWorkspace.status, 400);

    const response = await open.fetch(
      new Request(
        `http://dsh.internal${TERMINAL_PATH}?sessionId=s1&tabId=t1&workspace=team&shell=/usr/bin/bash&cols=80&rows=24`,
      ),
    );
    assert.equal(response.status, 200);
    assert.equal(response.headers.get("content-type"), "application/x-ndjson");
    const reader = response.body!.getReader();
    const first = new TextDecoder().decode((await reader.read()).value);
    assert.match(first, /"type":"ready"/);
    const ready = JSON.parse(first.trim().split("\n")[0]) as {
      terminalId: string;
    };

    const control = await open.fetch(
      new Request(`http://dsh.internal${TERMINAL_PATH}`, {
        method: "POST",
        body: JSON.stringify({
          terminalId: ready.terminalId,
          kind: "resize",
          cols: 90,
          rows: 30,
        }),
      }),
    );
    assert.equal(control.status, 200);
    assert.deepEqual(terminal.resizes, [{ cols: 90, rows: 30 }]);
    const unknownTerminal = await open.fetch(
      new Request(`http://dsh.internal${TERMINAL_PATH}`, {
        method: "POST",
        body: JSON.stringify({ terminalId: "nope", kind: "close" }),
      }),
    );
    assert.equal(unknownTerminal.status, 404);

    const shellsResponse = await routes.get(TERMINAL_SHELLS_PATH).fetch(
      new Request(
        `http://dsh.internal${TERMINAL_SHELLS_PATH}?workspace=team&sessionId=s1`,
      ),
    );
    const shellsBody = (await shellsResponse.json()) as {
      shells: TerminalShellView[];
    };
    assert.deepEqual(shellsBody.shells.map((shell) => shell.path), [
      "/usr/bin/bash",
    ]);

    const retainedResponse = await routes.get(TERMINAL_RETAINED_PATH).fetch(
      new Request(`http://dsh.internal${TERMINAL_RETAINED_PATH}?sessionId=s1`),
    );
    const retainedBody = (await retainedResponse.json()) as {
      terminals: Array<{ tabId: string }>;
    };
    assert.equal(retainedBody.terminals.length, 1);
    assert.equal(retainedBody.terminals[0]?.tabId, "t1");
    await reader.cancel();
  } finally {
    sessions.dispose();
  }
});
