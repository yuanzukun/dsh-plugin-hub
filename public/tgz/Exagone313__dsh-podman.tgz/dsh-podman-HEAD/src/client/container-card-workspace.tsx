// SPDX-FileCopyrightText: 2026 Elouan Martinet <exa@elou.world>
//
// SPDX-License-Identifier: MIT

import { ContainerRow, CreateContainerModal } from "./container-card-row.js";
import { ConfirmButton, containerStateDot } from "./container-card-shared.js";
import { greyId, hint, wsBody } from "./container-card-styles.js";
import {
  type ContainerCreateConfig,
  type ContainerView,
  type ImageView,
  type MountInput,
  type WorkspaceView,
} from "./container-card-controller.js";
import { type DirectoryPickerFace } from "./directory-picker.js";
import type { Translate } from "./locales.js";
import {
  Button,
  DisclosureRow,
  StateDot,
} from "@deepseek-ai/dsh-client-ui-primitives";
import { type ReactNode, useState } from "react";

export function WorkspaceSection(props: {
  t: Translate;
  workspace: WorkspaceView;
  containers: readonly ContainerView[];
  images: readonly ImageView[];
  volumes: readonly { name: string }[];
  secrets: readonly { name: string }[];
  busy: boolean;
  defaultImage: string;
  projectsRoot: string;
  directoryPicker?: DirectoryPickerFace;
  onRemove: (workspace: string, container: string) => void;
  onRemoveWorkspace: (workspace: string) => void;
  onRecreate: (
    workspace: string,
    container: string,
    image: string,
    env?: Record<string, string>,
  ) => void;
  onCreate: (workspace: WorkspaceView, config?: ContainerCreateConfig) => void;
  onStartContainer: (
    workspace: WorkspaceView,
    container: string,
    config?: ContainerCreateConfig,
  ) => void;
  onAddContainerMount: (
    workspace: string,
    container: string,
    mount: MountInput,
  ) => void;
  onRemoveContainerMount: (
    workspace: string,
    container: string,
    mount: MountInput,
  ) => void;
  onUpdateContainerMount: (
    workspace: string,
    container: string,
    mount: MountInput,
  ) => void;
  onSetContainerPaths: (
    workspace: string,
    container: string,
    paths: readonly string[],
  ) => void;
  onAddContainerSecret: (
    workspace: string,
    container: string,
    envVar: string,
    secret: string,
  ) => void;
  onRemoveContainerSecret: (
    workspace: string,
    container: string,
    envVar: string,
  ) => void;
  onPublishContainerPort: (
    workspace: string,
    container: string,
    port: number,
    suggestedHostPort?: number,
  ) => void;
  onUnpublishContainerPort: (
    workspace: string,
    container: string,
    port: number,
    protocol: string,
  ) => void;
  // Whether the port-publishing gateway is known to be missing, forwarded to
  // each row.
  gatewayUnavailable: boolean;
  // Adds the default container environment to this workspace's containers.
  onSyncDefaults: (workspace: string) => void;
  // How many default variables exist; the sync action is pointless without any.
  defaultEnvCount: number;
}): ReactNode {
  const {
    t,
    workspace,
    containers,
    images,
    volumes,
    secrets,
    busy,
    defaultImage,
    projectsRoot,
    directoryPicker,
    onRemove,
    onRemoveWorkspace,
    onRecreate,
    onCreate,
    onStartContainer,
    onAddContainerMount,
    onRemoveContainerMount,
    onUpdateContainerMount,
    onSetContainerPaths,
    onAddContainerSecret,
    onRemoveContainerSecret,
    onPublishContainerPort,
    onUnpublishContainerPort,
    gatewayUnavailable,
    onSyncDefaults,
    defaultEnvCount,
  } = props;
  const [open, setOpen] = useState(false);
  const [createOpen, setCreateOpen] = useState<"default" | "named" | null>(
    null,
  );
  const hasContainer = containers.length > 0;
  return (
    <DisclosureRow
      icon={hasContainer
        ? <StateDot state={containerStateDot(containers[0]?.status ?? "")} />
        : <span />}
      title={workspace.projectName}
      open={open}
      expandable
      onToggle={() => setOpen(!open)}
    >
      <div style={wsBody}>
        <code style={greyId}>{workspace.workspaceSlug}</code>
        {!hasContainer
          ? (
            <div
              style={{ display: "flex", flexDirection: "column", gap: "8px" }}
            >
              <p style={{ ...hint, margin: 0 }}>{t("noContainers")}</p>
              <div>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={busy}
                  onClick={() => setCreateOpen("default")}
                >
                  {t("createContainer")}
                </Button>
              </div>
            </div>
          )
          : (
            <>
              {containers.map((container) => (
                <ContainerRow
                  key={container.containerName}
                  t={t}
                  container={container}
                  images={images}
                  volumes={volumes}
                  secrets={secrets}
                  busy={busy}
                  onRemove={onRemove}
                  onRecreate={onRecreate}
                  onAddContainerMount={onAddContainerMount}
                  onRemoveContainerMount={onRemoveContainerMount}
                  onUpdateContainerMount={onUpdateContainerMount}
                  onSetContainerPaths={onSetContainerPaths}
                  projectName={workspace.projectName}
                  projectsRoot={projectsRoot}
                  directoryPicker={directoryPicker}
                  onAddContainerSecret={onAddContainerSecret}
                  onRemoveContainerSecret={onRemoveContainerSecret}
                  onPublishContainerPort={onPublishContainerPort}
                  onUnpublishContainerPort={onUnpublishContainerPort}
                  gatewayUnavailable={gatewayUnavailable}
                />
              ))}
              <div>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={busy}
                  onClick={() => setCreateOpen("named")}
                >
                  {t("addContainer")}
                </Button>
              </div>
            </>
          )}
        <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
          <ConfirmButton
            t={t}
            label={t("applyDefaults")}
            title={t("confirmTitle")}
            description={t("confirmApplyDefaults")}
            disabled={busy || defaultEnvCount === 0}
            onConfirm={() => onSyncDefaults(workspace.workspaceSlug)}
          />
          <ConfirmButton
            t={t}
            label={t("removePod")}
            title={t("confirmTitle")}
            description={t("confirmRemovePod", {
              workspace: workspace.projectName,
            })}
            disabled={busy}
            onConfirm={() => onRemoveWorkspace(workspace.workspaceSlug)}
          />
        </div>
      </div>
      <CreateContainerModal
        t={t}
        workspace={workspace}
        images={images}
        volumes={volumes}
        secrets={secrets}
        busy={busy}
        defaultImage={defaultImage}
        projectsRoot={projectsRoot}
        directoryPicker={directoryPicker}
        named={createOpen === "named"}
        existing={containers.map((container) => container.containerName)}
        open={createOpen !== null}
        onClose={() => setCreateOpen(null)}
        onCreate={(container, config) => {
          if (createOpen === "named") {
            onStartContainer(workspace, container, config);
          } else {
            onCreate(workspace, config);
          }
          setCreateOpen(null);
        }}
      />
    </DisclosureRow>
  );
}
