// SPDX-FileCopyrightText: 2026 Elouan Martinet <exa@elou.world>
//
// SPDX-License-Identifier: MIT

const containerParam = {
  type: "string",
  description:
    'Logical container name; use "default" for the default workspace container.',
};

const imageIdParam = { type: "string", description: "Image short name." };

const packageListParam = {
  type: "array",
  items: { type: "string" },
  description: "Package names to install.",
};

const mountModeParam = {
  type: "string",
  enum: ["read_only", "read_write"],
  description:
    "Read mode of the mount. Defaults to read_only, except for tmpfs mounts, which are always read_write.",
};

const mountKindParam = {
  type: "string",
  enum: ["project", "tmpfs", "volume", "secret"],
  description:
    "Kind of mount: a project bind, a tmpfs, a named volume, or a named secret.",
};

// A project mount names a path under the projects root, so it may include
// subdirectories: `team` mounts the project, `team/src` a directory inside it.
const projectPathDescription =
  'Project path under the projects root to mount, e.g. "team" or "team/src".';

const projectMountItemParam = {
  type: "object",
  additionalProperties: false,
  properties: {
    project: { type: "string", description: projectPathDescription },
    mode: mountModeParam,
    destination: {
      type: "string",
      description:
        "Destination path inside the container (volume, tmpfs, and secret mounts only; project mounts always mount at their project root).",
    },
    kind: mountKindParam,
    volume: { type: "string", description: "Volume name to mount." },
    secret: { type: "string", description: "Secret name to mount as a file." },
  },
  required: [],
};

const mountsParam = {
  type: "array",
  items: projectMountItemParam,
  description:
    "Optional mounts to apply: a project bind, a tmpfs, a named volume, or a secret.",
};

export const envParam = {
  type: "object",
  additionalProperties: { type: "string" },
  description: "Environment variables.",
};

// The complete PATH-addition list, shared by the tools that set it outright.
const pathsParam = {
  type: "array",
  items: {
    type: "string",
    description:
      "Absolute directory to prepend to the container's PATH (no ':', NUL, or newline).",
  },
  description:
    "Complete ordered list of PATH additions, highest priority first. Replaces the current list; an empty list clears it.",
};

// The optional process identity a tool may request, shared by the tools that
// can run a process as another user.
const uidParam = {
  type: "integer",
  minimum: 0,
  description: "Run the process as this uid (defaults to the container user).",
};

const gidParam = {
  type: "integer",
  minimum: 0,
  description:
    "Run the process as this gid. Defaults to the uid when uid is set.",
};

const groupsParam = {
  type: "array",
  items: { type: "integer", minimum: 0 },
  description:
    "Supplementary group ids; replaces the process's whole supplementary set.",
};

const descriptionParam = {
  type: "string",
  description:
    "Clear, concise description of what this command does in active voice, 5-10 words.",
};

const timeoutMsParam = {
  type: "number",
  description:
    "Timeout in milliseconds; the command is killed when it expires.",
};

export const imageListParameters = {
  type: "object",
  properties: {},
  required: [] as string[],
};

export const imageGetParameters = {
  type: "object",
  properties: { imageId: imageIdParam },
  required: ["imageId"],
};

export const imageBuildParameters = {
  type: "object",
  properties: {
    imageId: imageIdParam,
    parent: {
      type: "string",
      description:
        "Short name of the parent image (a base like archlinux/ubuntu/alpine, or an existing custom image).",
    },
    packages: packageListParam,
  },
  required: ["imageId", "parent", "packages"],
};

export const imageRebuildParameters = {
  type: "object",
  properties: { imageId: imageIdParam },
  required: ["imageId"],
};

export const imageRebuildAllParameters = {
  type: "object",
  properties: {},
  required: [] as string[],
};

export const imageRemoveParameters = {
  type: "object",
  properties: { imageId: imageIdParam },
  required: ["imageId"],
};

export const containerListParameters = {
  type: "object",
  properties: {},
  required: [] as string[],
};

export const containerStartParameters = {
  type: "object",
  properties: {
    container: containerParam,
    image: {
      type: "string",
      description: "Image short name (base or custom).",
    },
    mounts: mountsParam,
    env: envParam,
    secretEnv: {
      type: "object",
      additionalProperties: { type: "string" },
      description:
        "Secret environment variables (env var name to secret short name).",
    },
    paths: pathsParam,
  },
  required: ["container"],
};

export const containerRecreateParameters = {
  type: "object",
  properties: {
    container: containerParam,
    image: {
      type: "string",
      description:
        "Image ID to recreate the container with; defaults to the container's current image.",
    },
    mounts: mountsParam,
    env: envParam,
    secretEnv: {
      type: "object",
      additionalProperties: { type: "string" },
      description:
        "Secret environment variables (env var name to secret short name).",
    },
    paths: pathsParam,
  },
  required: ["container"],
};

export const containerMountListParameters = {
  type: "object",
  properties: { container: containerParam },
  required: ["container"],
};

export const containerMountAddParameters = {
  type: "object",
  properties: {
    container: containerParam,
    kind: mountKindParam,
    project: { type: "string", description: projectPathDescription },
    destination: {
      type: "string",
      description:
        "Destination path inside the container (volume, tmpfs, and secret mounts only; project mounts always mount at their project root).",
    },
    mode: mountModeParam,
    volume: { type: "string", description: "Named volume to mount." },
    secret: { type: "string", description: "Named secret to mount." },
  },
  required: ["container"],
};

export const containerMountRemoveParameters = {
  type: "object",
  properties: {
    container: containerParam,
    kind: {
      type: "string",
      enum: ["project", "tmpfs", "volume", "secret"],
      description:
        "Kind of mount to remove; inferred from secret or volume when omitted, otherwise project. Pass tmpfs explicitly: it has no name to infer from.",
    },
    project: {
      type: "string",
      description: "Project path of the project mount to remove.",
    },
    volume: {
      type: "string",
      description:
        "Named volume to remove; identifies the mount, so pass destination as well when the volume is mounted more than once.",
    },
    secret: {
      type: "string",
      description:
        "Named secret the removed mount must use; identifies the mount, so pass destination as well when the secret is mounted more than once.",
    },
    destination: {
      type: "string",
      description:
        "Destination path inside the container. Required for tmpfs; for a volume or secret it identifies the mount (and disambiguates one mounted more than once); not applicable to project mounts.",
    },
  },
  required: ["container"],
};

export const containerMountUpdateParameters = {
  type: "object",
  properties: {
    container: containerParam,
    kind: {
      type: "string",
      enum: ["project", "volume"],
      description:
        "Kind of mount to update; inferred from volume when omitted, otherwise project. Only project and volume mounts carry a mode.",
    },
    project: {
      type: "string",
      description: "Project path of the project mount to update.",
    },
    volume: {
      type: "string",
      description:
        "Named volume to update; identifies the mount, so pass destination as well when the volume is mounted more than once.",
    },
    destination: {
      type: "string",
      description:
        "Destination path inside the container; for a volume it identifies the mount (and disambiguates one mounted more than once); not applicable to project mounts.",
    },
    mode: mountModeParam,
  },
  required: ["container", "mode"],
};

export const containerPublishPortParameters = {
  type: "object",
  properties: {
    container: containerParam,
    port: {
      type: "integer",
      minimum: 1,
      maximum: 65535,
      description:
        "TCP port the service listens on inside the pod's network namespace.",
    },
    protocol: {
      type: "string",
      enum: ["tcp"],
      description:
        "Transport to publish. Only tcp is supported for now; udp and http are reserved for later.",
    },
    suggestedHostPort: {
      type: "integer",
      minimum: 1024,
      maximum: 65535,
      description:
        "Host port to prefer, between 1024 and 65535. Omit to let the gateway choose a free one.",
    },
  },
  required: ["container", "port"],
};

export const containerUnpublishPortParameters = {
  type: "object",
  properties: {
    container: containerParam,
    port: {
      type: "integer",
      minimum: 1,
      maximum: 65535,
      description: "Pod port whose host exposure is removed.",
    },
    protocol: {
      type: "string",
      enum: ["tcp"],
      description: "Transport to unpublish. Only tcp is supported for now.",
    },
  },
  required: ["container", "port"],
};

export const containerPathSetParameters = {
  type: "object",
  properties: {
    container: containerParam,
    paths: pathsParam,
  },
  required: ["container", "paths"],
};

export const containerPathAddParameters = {
  type: "object",
  properties: {
    container: containerParam,
    path: {
      type: "string",
      description:
        "Absolute directory to prepend to the container's PATH (no ':', NUL, or newline). An existing entry is moved to the front.",
    },
  },
  required: ["container", "path"],
};

export const containerPathRemoveParameters = {
  type: "object",
  properties: {
    container: containerParam,
    path: {
      type: "string",
      description:
        "PATH addition to remove. A directory that is only part of the container's default PATH cannot be removed.",
    },
  },
  required: ["container", "path"],
};

export const containerRemoveParameters = {
  type: "object",
  properties: { container: containerParam },
  required: ["container"],
};

export const volumeListParameters = {
  type: "object",
  properties: {},
  required: [] as string[],
};

export const volumeCreateParameters = {
  type: "object",
  properties: {
    name: { type: "string", description: "Volume name to create." },
  },
  required: ["name"],
};

export const volumeRemoveParameters = {
  type: "object",
  properties: {
    name: { type: "string", description: "Volume name to remove." },
  },
  required: ["name"],
};

export const secretListParameters = {
  type: "object",
  properties: {},
  required: [] as string[],
};

export const secretCreateParameters = {
  type: "object",
  properties: {
    name: { type: "string", description: "Secret name to create." },
    length: {
      type: "integer",
      minimum: 1,
      description: "Length of the generated random value (default 32).",
    },
    charset: {
      type: "string",
      enum: ["alphanumeric", "hex", "base64url"],
      description: "Character set for the generated random value.",
    },
  },
  required: ["name"],
};

export const secretRemoveParameters = {
  type: "object",
  properties: {
    name: { type: "string", description: "Secret name to remove." },
  },
  required: ["name"],
};

export const containerSecretAddParameters = {
  type: "object",
  properties: {
    container: containerParam,
    env: { type: "string", description: "Environment variable name." },
    secret: { type: "string", description: "Named secret to inject." },
  },
  required: ["container", "env", "secret"],
};

export const containerSecretRemoveParameters = {
  type: "object",
  properties: {
    container: containerParam,
    env: { type: "string", description: "Environment variable name." },
  },
  required: ["container", "env"],
};

export const containerBashParameters = {
  type: "object",
  properties: {
    container: containerParam,
    command: { type: "string", description: "The shell command to execute." },
    description: descriptionParam,
    workdir: { type: "string", description: "Working directory." },
    timeoutMs: timeoutMsParam,
    env: envParam,
    uid: uidParam,
    gid: gidParam,
    groups: groupsParam,
  },
  required: ["container", "command", "description"],
};

export const containerExecParameters = {
  type: "object",
  properties: {
    container: containerParam,
    argv: {
      type: "array",
      items: { type: "string" },
      description: "The program and arguments to execute.",
    },
    description: descriptionParam,
    workdir: { type: "string", description: "Working directory." },
    timeoutMs: timeoutMsParam,
    env: envParam,
    uid: uidParam,
    gid: gidParam,
    groups: groupsParam,
  },
  required: ["container", "argv", "description"],
};

export const containerReadParameters = {
  type: "object",
  properties: {
    container: containerParam,
    file_path: {
      type: "string",
      description:
        "Path to read, resolved against the session working directory.",
    },
    offset: {
      type: "integer",
      minimum: 1,
      description: "1-based first line to return. Defaults to 1.",
    },
    limit: {
      type: "integer",
      minimum: 1,
      description: "Maximum number of lines to return. Defaults to 2000.",
    },
  },
  required: ["container", "file_path"],
};

export const containerWriteParameters = {
  type: "object",
  properties: {
    container: containerParam,
    file_path: {
      type: "string",
      description:
        "Path to write, resolved against the session working directory.",
    },
    content: { type: "string", description: "Content to write." },
  },
  required: ["container", "file_path", "content"],
};

export const containerEditParameters = {
  type: "object",
  properties: {
    container: containerParam,
    file_path: {
      type: "string",
      description:
        "Path to edit, resolved against the session working directory.",
    },
    old_string: { type: "string", description: "Literal text to replace." },
    new_string: { type: "string", description: "Replacement text." },
    replace_all: {
      type: "boolean",
      description:
        "Replace every occurrence. Defaults to false; when false, old_string must appear exactly once.",
    },
  },
  required: ["container", "file_path", "old_string", "new_string"],
};

export const containerGlobParameters = {
  type: "object",
  properties: {
    container: containerParam,
    pattern: { type: "string", description: "File pattern." },
    path: {
      type: "string",
      description:
        "Directory to search in. Defaults to the session working directory.",
    },
  },
  required: ["container", "pattern"],
};

export const containerGrepParameters = {
  type: "object",
  properties: {
    container: containerParam,
    pattern: { type: "string", description: "Regex to search for." },
    path: {
      type: "string",
      description:
        "File or directory to search. Defaults to the session working directory.",
    },
    include: {
      type: "string",
      description: 'One glob filter for which files to search (e.g. "*.ts").',
    },
  },
  required: ["container", "pattern"],
};

export const daemonStartParameters = {
  type: "object",
  properties: {
    container: containerParam,
    name: { type: "string", description: "Daemon name." },
    argv: {
      type: "array",
      items: { type: "string" },
      description: "Command to run as a daemon.",
    },
    cwd: { type: "string", description: "Working directory." },
    env: envParam,
    uid: uidParam,
    gid: gidParam,
    groups: groupsParam,
    inheritEnv: {
      type: "boolean",
      description:
        "Inherit the container's environment (default true). When false the daemon receives only PATH and HOME plus env, so container and secret environment variables are not visible.",
    },
  },
  required: ["container", "name", "argv"],
};

export const daemonListParameters = {
  type: "object",
  properties: { container: containerParam },
  required: ["container"],
};

export const daemonStopParameters = {
  type: "object",
  properties: {
    container: containerParam,
    name: { type: "string", description: "Daemon name to stop." },
    signal: { type: "string", description: 'Signal to send (e.g. "SIGTERM").' },
  },
  required: ["container", "name"],
};

export const daemonRestartParameters = {
  type: "object",
  properties: {
    container: containerParam,
    name: { type: "string", description: "Daemon name to restart." },
  },
  required: ["container", "name"],
};

export const daemonLogsParameters = {
  type: "object",
  properties: {
    container: containerParam,
    name: { type: "string", description: "Daemon name to read logs for." },
    tailBytes: {
      type: "integer",
      description: "Maximum trailing bytes to retain per stream.",
    },
  },
  required: ["container", "name"],
};

const templateNameParam = {
  type: "string",
  description:
    'Template name: a YAML file in the project\'s .dsh-podman directory, with or without the ".yml" suffix.',
};

export const containerTemplateLoadParameters = {
  type: "object",
  properties: {
    template: templateNameParam,
    container: {
      type: "string",
      description:
        'Logical name of the container to create; defaults to "default".',
    },
  },
  required: ["template"],
};

export const containerTemplateExportParameters = {
  type: "object",
  properties: {
    container: containerParam,
  },
  required: ["container"],
};

export const containerTemplateSaveParameters = {
  type: "object",
  properties: {
    container: containerParam,
    name: templateNameParam,
  },
  required: ["container", "name"],
};
