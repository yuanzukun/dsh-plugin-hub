// SPDX-FileCopyrightText: 2026 Elouan Martinet <exa@elou.world>
//
// SPDX-License-Identifier: MIT

import {
  bytesText,
  currentCwd,
  type ExecIdentity,
  fsError,
  guestCwd,
  outputLines,
  resolveToolBinding,
  runExec,
  sessionWorkspaceSlug,
  streamLines,
  unaryGuest,
  writeGuestTemplate,
} from "./guest-rpc.js";
import {
  inferMountKind,
  mountsFromInput,
  projectMountDestinationReason,
} from "./mount-input.js";
import {
  exportContainerTemplate,
  parseContainerTemplate,
  renderContainerTemplate,
} from "./container-template.js";
import { applyContainerTemplate } from "./template-apply.js";
import {
  readProjectTemplate,
  TemplateFileError,
  templateFileName,
  workspaceForCwd,
} from "./template-files.js";
import { ensureTemplateImage } from "./template-image.js";
import { mergeDefaultEnv } from "./container-env.js";
import { isPtcContainer } from "./container-kind.js";
import {
  publicContainerResult,
  publicContainers,
  publicDaemon,
  publicImage,
  publicMount,
  publicPublishedPort,
} from "./public.js";
import { portProtocolToProto } from "./publish-port.js";
import { grpc } from "./grpc/runtime-client.js";
import {
  defaultMountMode,
  mountKindToProto,
  mountModeToProto,
} from "./mount-enums.js";
import { containerNotFound, WorkspaceResolver } from "./workspace-binding.js";

// Cap on paths `container_glob` returns, matching the built-in glob tool's
// default result limit; `--sort=modified` makes the retained head the newest.
const GLOB_MAX_RESULTS = 100;

// VCS metadata directories ripgrep must never descend into for a discovery
// listing (`--no-ignore --hidden` would otherwise surface them).
const GLOB_VCS_EXCLUDES = [".git", ".svn", ".hg", ".bzr", ".jj", ".sl"];

// templateFromContainer exports one container of a workspace as a template,
// refusing a name that does not belong to the workspace (or the reserved PTC
// container). The export and save tools share this lookup.
async function templateFromContainer(
  resolver: WorkspaceResolver,
  workspace: Awaited<ReturnType<typeof workspaceForCwd>>,
  container: string,
) {
  const [containers, images] = await Promise.all([
    resolver.control<{ containers?: any[] }>("listContainers", {}),
    resolver.control<{ images?: any[] }>("listImages", {}),
  ]);
  const row = (containers.containers ?? []).find(
    (candidate: any) =>
      candidate.workspaceSlug === workspace.workspaceSlug &&
      candidate.containerName === container,
  );
  if (row === undefined || isPtcContainer(row)) {
    throw containerNotFound(container, workspace.workspaceSlug);
  }
  return exportContainerTemplate(
    row,
    images.images ?? [],
    workspace.projectName,
  );
}

// failOnSearchError turns a ripgrep failure into a tool error: exit code 2 means
// ripgrep rejected the pattern or could not read the tree, and returning an
// empty result would present that as a successful search.
function failOnSearchError(
  tool: string,
  result: { exitCode: number; stderr: string },
): void {
  if (result.exitCode !== 2) return;
  const detail = result.stderr.trim();
  throw new Error(
    detail === "" ? `${tool} search failed (ripgrep exit code 2)` : detail,
  );
}

// withSpillNote points the caller at the guest spill file when a command's
// output was truncated in memory, so the full stream stays reachable with
// container_read instead of silently vanishing.
function withSpillNote<
  T extends { stdoutSpillPath?: string; stderrSpillPath?: string },
>(
  result: T,
): T & { note?: string } {
  const paths = [result.stdoutSpillPath, result.stderrSpillPath].filter(
    (path): path is string => typeof path === "string",
  );
  if (paths.length === 0) return result;
  return {
    ...result,
    note: `output was truncated; the full stream is at ${
      paths.join(", ")
    } (read it with container_read)`,
  };
}

// The terminal environment the harness's shell executors impose on every
// command (`ENV_OVERRIDES` in dsh-bash-local), so a container command sees the
// same non-interactive terminal as the built-in `bash`.
const ENV_OVERRIDES = {
  NO_COLOR: "1",
  TERM: "dumb",
  PAGER: "cat",
  GIT_PAGER: "cat",
};

// managedEnv layers a container command's environment exactly like the
// harness's shell executors: the terminal overrides first, then the caller's
// entries, then the managed `DSH_*` snapshot last, so a caller cannot displace
// a harness-owned fact. Without the snapshot, `container_bash` would see a
// different command-visible environment than the built-in `bash`, which
// collects it through `ctx.shellEnv`.
function managedEnv(
  ctx: any,
  exec: any,
  env: unknown,
): Record<string, string> {
  const managed = ctx?.get?.("shellEnv")?.collect?.(exec) ?? {};
  return {
    ...ENV_OVERRIDES,
    ...(env as Record<string, string> | undefined),
    ...managed,
  };
}

// startContainerEnv resolves the environment a `container_start` request
// carries. The caller's map wins over the defaults; a container that does not
// exist yet is a creation and gets the defaults alone; one that already exists
// keeps the environment it has (the orchestrator preserves a stored env when
// the request omits one, so nothing has to be sent).
async function startContainerEnv(
  resolver: WorkspaceResolver,
  slug: string,
  input: any,
): Promise<Record<string, string> | undefined> {
  const defaults = resolver.getConfig().containerEnv;
  if (input.env !== undefined) {
    return mergeDefaultEnv(defaults, input.env as Record<string, string>);
  }
  if (defaults === undefined || Object.keys(defaults).length === 0) {
    return undefined;
  }
  const result = await resolver.control<{ containers?: any[] }>(
    "listContainers",
    {},
  );
  const name = input.container === "" ? "default" : input.container;
  const exists = (result.containers ?? []).some(
    (row: any) => row.workspaceSlug === slug && row.containerName === name,
  );
  if (exists) return undefined;
  const env = mergeDefaultEnv(defaults, undefined);
  return Object.keys(env).length === 0 ? undefined : env;
}

// containerTarget resolves a container-scoped file target through the plugin's
// own filesystem provider, so the container file tools share the harness's file
// contracts (the read-before-write guard, the binary rejection, and the same
// diagnostics) instead of calling the guest directly.
async function containerTarget(
  ctx: any,
  path: string,
  container: string,
  exec: any,
): Promise<any> {
  return await ctx.fs.resolve(path, {
    cwd: currentCwd(exec),
    container: container ?? "",
    signal: exec?.signal,
  });
}

// identityFromInput validates the optional uid/gid/groups identity a tool
// accepts and returns it, or undefined when none was requested. Values are
// numeric only: the container's /etc/passwd is on the read-only rootfs, so
// there are no names to resolve.
function identityFromInput(input: any): ExecIdentity | undefined {
  const identity: ExecIdentity = {};
  if (input.uid !== undefined) {
    if (!Number.isInteger(input.uid) || input.uid < 0) {
      throw new Error("uid must be an integer >= 0");
    }
    identity.uid = input.uid;
  }
  if (input.gid !== undefined) {
    if (!Number.isInteger(input.gid) || input.gid < 0) {
      throw new Error("gid must be an integer >= 0");
    }
    identity.gid = input.gid;
  }
  if (input.groups !== undefined) {
    if (
      !Array.isArray(input.groups) ||
      input.groups.some(
        (group: unknown) => !Number.isInteger(group) || (group as number) < 0,
      )
    ) {
      throw new Error("groups must be an array of integers >= 0");
    }
    identity.groups = input.groups;
  }
  return identity.uid === undefined &&
      identity.gid === undefined &&
      identity.groups === undefined
    ? undefined
    : identity;
}

export const toolHandlers: Record<
  string,
  (
    resolver: WorkspaceResolver,
    input: any,
    exec: any,
    ctx?: any,
  ) => Promise<unknown>
> = {
  image_list: async (resolver) => {
    const result = await resolver.control<{ images?: any[] }>("listImages", {});
    return (result.images ?? []).map(publicImage);
  },
  image_get: async (resolver, input) =>
    publicImage(
      await resolver.control("getImage", { imageId: input.imageId }),
    ),
  image_build: async (resolver, input) =>
    publicImage(
      await resolver.control("buildImage", {
        imageId: input.imageId,
        parent: input.parent,
        packages: input.packages,
      }),
    ),
  image_rebuild: async (resolver, input) =>
    publicImage(
      await resolver.control("rebuildImage", { imageId: input.imageId }),
    ),
  image_rebuild_all: async (resolver) => {
    const result = await resolver.control<
      { rebuilt?: string[]; skipped?: string[] }
    >(
      "rebuildAllImages",
      {},
    );
    return {
      rebuilt: result.rebuilt ?? [],
      skipped: result.skipped ?? [],
    };
  },
  image_remove: async (resolver, input) => {
    await resolver.control("removeImage", { imageId: input.imageId });
    return { removed: input.imageId };
  },
  container_list: async (resolver, _input, exec) => {
    const slug = await sessionWorkspaceSlug(resolver, currentCwd(exec));
    const result = await resolver.control<{ containers?: any[] }>(
      "listContainers",
      {},
    );
    const rows = (result.containers ?? []).filter(
      (row: any) => row.workspaceSlug === slug,
    );
    const defaultRow = rows.find((row: any) => row.containerName === "default");
    const listed = defaultRow === undefined
      ? [{ containerName: "default", status: "not started" }]
      : publicContainers([defaultRow]);
    return [
      ...listed,
      ...publicContainers(
        rows.filter((row: any) => row.containerName !== "default"),
      ),
    ];
  },
  container_template_load: async (resolver, input, exec) => {
    const workspace = await workspaceForCwd(
      (resolver as any).registry,
      resolver.getConfig().projectsRoot,
      currentCwd(exec),
    );
    const file = await readProjectTemplate(
      workspace.projectPath,
      input.template,
    );
    const template = parseContainerTemplate(file.yaml);
    const ensured = await ensureTemplateImage(resolver, {
      name: file.name,
      path: file.path,
      template,
    });
    const container = typeof input.container === "string"
      ? input.container
      : undefined;
    const applied = await applyContainerTemplate(resolver, {
      workspaceSlug: workspace.workspaceSlug,
      projectName: workspace.projectName,
      template,
      imageId: ensured.imageId,
      ...(container === undefined || container === "" ? {} : { container }),
    });
    return {
      ...publicContainerResult(applied.row),
      template: file.name,
      imageId: ensured.imageId,
      ...(ensured.built ? { built: true } : {}),
      ...(applied.warnings.length > 0 ? { warnings: applied.warnings } : {}),
    };
  },
  container_template_export: async (resolver, input, exec) => {
    const workspace = await workspaceForCwd(
      (resolver as any).registry,
      resolver.getConfig().projectsRoot,
      currentCwd(exec),
    );
    return (await templateFromContainer(resolver, workspace, input.container))
      .yaml;
  },
  container_template_save: async (resolver, input, exec) => {
    const name = templateFileName(input.name);
    // `container` is required in the tool schema, but the harness does not
    // validate raw JSON-schema arguments, so name the missing source instead of
    // letting an empty string fall through to a lookup that cannot match it.
    if (typeof input.container !== "string" || input.container === "") {
      throw new TemplateFileError(
        'the "container" parameter is required: pass the source container name',
      );
    }
    const workspace = await workspaceForCwd(
      (resolver as any).registry,
      resolver.getConfig().projectsRoot,
      currentCwd(exec),
    );
    // Saving no longer takes a document: export the named container here, then
    // write that canonical YAML through the default container's guest agent,
    // which is the one that always has the project mounted.
    const exported = await templateFromContainer(
      resolver,
      workspace,
      input.container,
    );
    const binding = await resolver.resolve(currentCwd(exec), exec?.signal);
    const path = await writeGuestTemplate(
      binding,
      workspace.projectPath,
      name,
      renderContainerTemplate(exported.template),
    );
    return { container: input.container, name, path };
  },
  container_start: async (resolver, input, exec) => {
    const mounts = mountsFromInput(
      input.mounts,
      resolver.getConfig().projectsRoot,
    );
    const slug = await sessionWorkspaceSlug(resolver, currentCwd(exec));
    const env = await startContainerEnv(resolver, slug, input);
    const row = await resolver.control("startContainer", {
      workspaceSlug: slug,
      container: input.container,
      imageId: input.image,
      ...(mounts === undefined ? {} : { mounts }),
      ...(env === undefined ? {} : { env }),
      ...(input.secretEnv !== undefined ? { secretEnv: input.secretEnv } : {}),
      ...(input.paths !== undefined ? { paths: input.paths } : {}),
    });
    return publicContainerResult(row);
  },
  container_recreate: async (resolver, input, exec) => {
    const mounts = mountsFromInput(
      input.mounts,
      resolver.getConfig().projectsRoot,
    );
    const row = await resolver.control("recreateContainer", {
      workspaceSlug: await sessionWorkspaceSlug(resolver, currentCwd(exec)),
      container: input.container,
      imageId: input.image ?? "",
      ...(mounts === undefined ? {} : { mounts }),
      ...(input.env !== undefined ? { env: input.env } : {}),
      ...(input.secretEnv !== undefined ? { secretEnv: input.secretEnv } : {}),
      ...(input.paths !== undefined ? { paths: input.paths } : {}),
    });
    return publicContainerResult(row);
  },
  container_remove: async (resolver, input, exec) => {
    await resolver.control("removeContainer", {
      workspaceSlug: await sessionWorkspaceSlug(resolver, currentCwd(exec)),
      container: input.container,
    });
    return { removed: input.container };
  },
  container_bash: async (resolver, input, exec, ctx) => {
    const sessionCwd = currentCwd(exec);
    const binding = await resolveToolBinding(
      resolver,
      sessionCwd,
      input.container,
      exec?.signal,
    );
    return withSpillNote(
      await runExec(
        binding,
        ["bash", "-c", input.command],
        guestCwd(input.workdir, sessionCwd, binding),
        managedEnv(ctx, exec, input.env),
        input.timeoutMs,
        identityFromInput(input),
        { signal: exec?.signal },
      ),
    );
  },
  container_exec: async (resolver, input, exec, ctx) => {
    const sessionCwd = currentCwd(exec);
    const binding = await resolveToolBinding(
      resolver,
      sessionCwd,
      input.container,
      exec?.signal,
    );
    return withSpillNote(
      await runExec(
        binding,
        input.argv,
        guestCwd(input.workdir, sessionCwd, binding),
        managedEnv(ctx, exec, input.env),
        input.timeoutMs,
        identityFromInput(input),
        { signal: exec?.signal },
      ),
    );
  },
  container_read: async (resolver, input, exec, ctx) => {
    const target = await containerTarget(
      ctx,
      input.file_path,
      input.container,
      exec,
    );
    // Mirror the harness's read tool: stat first so a miss is FS_NOT_FOUND and
    // a directory is FS_NOT_REGULAR_FILE, then record the read. The observation
    // is what satisfies the read-before-write guard for a later
    // container_write/container_edit on the same path.
    const info = await ctx.fs.stat(target, exec?.signal);
    if (info === undefined) {
      ctx.emit("fs/observed", target, { kind: "absent" }, exec);
      throw fsError(
        "FS_NOT_FOUND",
        `cannot read "${target.displayPath}": not found`,
      );
    }
    if (info.type !== "file") {
      throw fsError(
        "FS_NOT_REGULAR_FILE",
        `cannot read "${target.displayPath}": not a regular file`,
      );
    }
    // Stream the requested line window instead of buffering the whole file:
    // a read of a few lines from a huge file must not read it all into memory.
    const lines = await streamLines(
      await ctx.fs.streamText(target, exec?.signal),
      input.offset,
      input.limit,
    );
    ctx.emit(
      "fs/observed",
      target,
      { kind: "present", version: info.version },
      exec,
    );
    return lines;
  },
  container_write: async (resolver, input, exec, ctx) => {
    const target = await containerTarget(
      ctx,
      input.file_path,
      input.container,
      exec,
    );
    // The harness's write tool computes the intent through this waterfall and
    // the provider enforces it, so the container tool shares the same
    // read-before-write guard and diagnostics.
    const intent = await ctx.waterfall(
      "fs/write-intent",
      target,
      exec,
      () => undefined,
    );
    const content = String(input.content ?? "");
    const outcome = await ctx.fs.writeText(
      target,
      content,
      intent,
      exec?.signal,
    );
    ctx.emit("fs/observed", target, {
      kind: "present",
      version: outcome.version,
    }, exec);
    return { bytesWritten: Buffer.byteLength(content, "utf8") };
  },
  container_edit: async (resolver, input, exec, ctx) => {
    const target = await containerTarget(
      ctx,
      input.file_path,
      input.container,
      exec,
    );
    const intent = await ctx.waterfall(
      "fs/edit-intent",
      target,
      exec,
      () => undefined,
    );
    const outcome = await ctx.fs.editText(
      target,
      {
        oldString: input.old_string,
        newString: input.new_string,
        replaceAll: input.replace_all === true,
      },
      intent,
      exec?.signal,
    );
    ctx.emit("fs/observed", target, {
      kind: "present",
      version: outcome.version,
    }, exec);
    return { before: outcome.before, after: outcome.after };
  },
  container_glob: async (resolver, input, exec) => {
    const sessionCwd = currentCwd(exec);
    const binding = await resolveToolBinding(
      resolver,
      sessionCwd,
      input.container,
      exec?.signal,
    );
    const argv = [
      "rg",
      "--files",
      `--glob=${input.pattern}`,
      "--sort=modified",
      "--no-ignore",
      "--hidden",
      ...GLOB_VCS_EXCLUDES.flatMap((name) => [
        `--glob=!**/${name}`,
        `--glob=!**/${name}/**`,
      ]),
    ];
    const result = await runExec(
      binding,
      argv,
      guestCwd(input.path, sessionCwd, binding),
      undefined,
      undefined,
      undefined,
      { signal: exec?.signal },
    );
    failOnSearchError("glob", result);
    const files = outputLines(result.stdout);
    const capped = files.length > GLOB_MAX_RESULTS;
    return {
      files: capped ? files.slice(0, GLOB_MAX_RESULTS) : files,
      ...(capped
        ? {
          note:
            `showing ${GLOB_MAX_RESULTS} of ${files.length} files in modification-time order; narrow pattern or path to see more`,
        }
        : {}),
    };
  },
  container_grep: async (resolver, input, exec) => {
    const sessionCwd = currentCwd(exec);
    const binding = await resolveToolBinding(
      resolver,
      sessionCwd,
      input.container,
      exec?.signal,
    );
    const cwd = guestCwd(undefined, sessionCwd, binding);
    // The search root: the requested path, else the container's default (the
    // session workspace when it is mounted). Ripgrep reads stdin instead of the
    // working directory when it is given no path, so it is always explicit.
    const root = guestCwd(input.path, sessionCwd, binding) ?? cwd;
    const argv = ["rg", "-n"];
    if (typeof input.include === "string" && input.include !== "") {
      argv.push("--glob", input.include);
    }
    argv.push(input.pattern);
    if (root !== undefined) argv.push(root);
    const result = await runExec(
      binding,
      argv,
      cwd,
      undefined,
      undefined,
      undefined,
      {
        signal: exec?.signal,
      },
    );
    failOnSearchError("grep", result);
    return {
      matches: outputLines(result.stdout),
    };
  },
  container_mount_list: async (resolver, input, exec) => {
    const slug = await sessionWorkspaceSlug(resolver, currentCwd(exec));
    const result = await resolver.control<{ containers?: any[] }>(
      "listContainers",
      {},
    );
    const row = (result.containers ?? []).find(
      (candidate: any) =>
        candidate.workspaceSlug === slug &&
        candidate.containerName === input.container,
    );
    if (row === undefined || isPtcContainer(row)) {
      throw containerNotFound(input.container, slug);
    }
    const mounts = row.mounts ?? [];
    return mounts.map(publicMount);
  },
  container_mount_add: async (resolver, input, exec) => {
    const kind = inferMountKind(input);
    const projectsRoot = resolver.getConfig().projectsRoot;
    const destinationReason = projectMountDestinationReason(
      projectsRoot,
      input,
    );
    if (destinationReason !== undefined) throw new Error(destinationReason);
    if (kind === "secret" && input.mode === "read_write") {
      throw new Error(
        "secret mounts are read-only; omit mode or use read_only",
      );
    }
    const protoKind = mountKindToProto(kind);
    const mode = mountModeToProto(input.mode ?? defaultMountMode(kind));
    const request: Record<string, unknown> = {
      workspaceSlug: await sessionWorkspaceSlug(resolver, currentCwd(exec)),
      container: input.container,
      kind: protoKind,
    };
    if (kind === "volume") {
      request.volume = input.volume;
      request.destination = input.destination;
      request.mode = mode;
    } else if (kind === "tmpfs") {
      request.destination = input.destination;
      request.mode = mode;
    } else if (kind === "secret") {
      request.secret = input.secret;
      request.destination = input.destination;
    } else {
      request.project = input.project;
      request.mode = mode;
    }
    const row = await resolver.control("addContainerMount", request);
    return publicContainerResult(row);
  },
  container_mount_remove: async (resolver, input, exec) => {
    const kind = inferMountKind(input);
    const protoKind = mountKindToProto(kind);
    const request: Record<string, unknown> = {
      workspaceSlug: await sessionWorkspaceSlug(resolver, currentCwd(exec)),
      container: input.container,
      kind: protoKind,
    };
    if (kind === "project") {
      request.project = input.project;
    } else if (kind === "volume") {
      if (input.volume !== undefined) request.volume = input.volume;
    } else if (kind === "secret") {
      if (input.secret !== undefined) request.secret = input.secret;
    }
    if (kind !== "project" && input.destination !== undefined) {
      request.destination = input.destination;
    }
    const row = await resolver.control("removeContainerMount", request);
    return publicContainerResult(row);
  },
  container_mount_update: async (resolver, input, exec) => {
    const kind = inferMountKind(input);
    if (kind !== "project" && kind !== "volume") {
      throw new Error(
        `only project and volume mounts carry a mode; ${kind} mounts cannot be remounted`,
      );
    }
    const projectsRoot = resolver.getConfig().projectsRoot;
    const destinationReason = projectMountDestinationReason(
      projectsRoot,
      input,
    );
    if (destinationReason !== undefined) throw new Error(destinationReason);
    const request: Record<string, unknown> = {
      workspaceSlug: await sessionWorkspaceSlug(resolver, currentCwd(exec)),
      container: input.container,
      kind: mountKindToProto(kind),
      mode: mountModeToProto(input.mode),
    };
    if (kind === "project") {
      request.project = input.project;
    } else {
      if (input.volume !== undefined) request.volume = input.volume;
      if (input.destination !== undefined) {
        request.destination = input.destination;
      }
    }
    const row = await resolver.control("updateContainerMount", request);
    return publicContainerResult(row);
  },
  container_publish_port: async (resolver, input, exec) => {
    const request: Record<string, unknown> = {
      workspaceSlug: await sessionWorkspaceSlug(resolver, currentCwd(exec)),
      container: input.container,
      port: input.port,
      protocol: portProtocolToProto(input.protocol),
    };
    // An omitted suggestion asks the gateway to choose a free host port.
    if (input.suggestedHostPort !== undefined) {
      request.suggestedHostPort = input.suggestedHostPort;
    }
    const published = await resolver.control("publishPort", request);
    return { container: input.container, ...publicPublishedPort(published) };
  },
  container_unpublish_port: async (resolver, input, exec) => {
    const request: Record<string, unknown> = {
      workspaceSlug: await sessionWorkspaceSlug(resolver, currentCwd(exec)),
      container: input.container,
      port: input.port,
      protocol: portProtocolToProto(input.protocol),
    };
    await resolver.control("unpublishPort", request);
    return {
      container: input.container,
      port: input.port,
      protocol: input.protocol ?? "tcp",
      unpublished: true,
    };
  },
  container_path_set: async (resolver, input, exec) => {
    const sessionCwd = currentCwd(exec);
    const slug = await sessionWorkspaceSlug(resolver, sessionCwd);
    const binding = await resolveToolBinding(
      resolver,
      sessionCwd,
      input.container,
      exec?.signal,
    );
    const paths = Array.isArray(input.paths) ? input.paths.map(String) : [];
    return {
      paths: await applyContainerPaths(
        resolver,
        binding,
        slug,
        input.container,
        paths,
      ),
    };
  },
  container_path_add: async (resolver, input, exec) => {
    const sessionCwd = currentCwd(exec);
    const slug = await sessionWorkspaceSlug(resolver, sessionCwd);
    const binding = await resolveToolBinding(
      resolver,
      sessionCwd,
      input.container,
      exec?.signal,
    );
    const current = await containerPathState(binding);
    // Prepending gives the new path the highest priority; an existing entry is
    // moved to the front rather than duplicated.
    const paths = [
      input.path,
      ...current.paths.filter((path) => path !== input.path),
    ];
    return {
      paths: await applyContainerPaths(
        resolver,
        binding,
        slug,
        input.container,
        paths,
      ),
    };
  },
  container_path_remove: async (resolver, input, exec) => {
    const sessionCwd = currentCwd(exec);
    const slug = await sessionWorkspaceSlug(resolver, sessionCwd);
    const binding = await resolveToolBinding(
      resolver,
      sessionCwd,
      input.container,
      exec?.signal,
    );
    const current = await containerPathState(binding);
    if (!current.paths.includes(input.path)) {
      if (current.defaultPaths.includes(input.path)) {
        throw new Error(
          `path ${
            JSON.stringify(input.path)
          } is part of the container's default PATH and cannot be removed`,
        );
      }
      throw new Error(
        `path ${JSON.stringify(input.path)} is not an added path`,
      );
    }
    const paths = current.paths.filter((path) => path !== input.path);
    return {
      paths: await applyContainerPaths(
        resolver,
        binding,
        slug,
        input.container,
        paths,
      ),
    };
  },
  volume_list: async (resolver) => {
    const result = await resolver.control<{ volumes?: any[] }>(
      "listVolumes",
      {},
    );
    return (result.volumes ?? []).map((volume: any) => ({ name: volume.name }));
  },
  volume_create: async (resolver, input) => {
    await resolver.control("createVolume", { name: input.name });
    return { name: input.name };
  },
  volume_remove: async (resolver, input) => {
    await resolver.control("removeVolume", { name: input.name });
    return { removed: input.name };
  },
  secret_list: async (resolver) => {
    const result = await resolver.control<{ secrets?: any[] }>(
      "listSecrets",
      {},
    );
    return (result.secrets ?? []).map((secret: any) => ({ name: secret.name }));
  },
  secret_create: async (resolver, input) => {
    await resolver.control("createSecret", {
      name: input.name,
      ...(input.length ? { length: input.length } : {}),
      ...(input.charset ? { charset: input.charset } : {}),
    });
    return { name: input.name };
  },
  secret_remove: async (resolver, input) => {
    await resolver.control("removeSecret", { name: input.name });
    return { removed: input.name };
  },
  container_secret_add: async (resolver, input, exec) => {
    const row = await resolver.control("addContainerSecret", {
      workspaceSlug: await sessionWorkspaceSlug(resolver, currentCwd(exec)),
      container: input.container,
      env: input.env,
      secret: input.secret,
    });
    return publicContainerResult(row);
  },
  container_secret_remove: async (resolver, input, exec) => {
    const row = await resolver.control("removeContainerSecret", {
      workspaceSlug: await sessionWorkspaceSlug(resolver, currentCwd(exec)),
      container: input.container,
      env: input.env,
    });
    return publicContainerResult(row);
  },
  daemon_start: async (resolver, input, exec) => {
    const sessionCwd = currentCwd(exec);
    const binding = await resolveToolBinding(
      resolver,
      sessionCwd,
      input.container,
      exec?.signal,
    );
    const request: Record<string, unknown> = {
      argv: input.argv,
      inheritEnv: { value: input.inheritEnv !== false },
    };
    if (input.name !== undefined) request.name = input.name;
    const cwd = guestCwd(input.cwd, sessionCwd, binding);
    if (cwd !== undefined) request.cwd = cwd;
    if (input.env !== undefined) request.env = input.env;
    const identity = identityFromInput(input);
    if (identity?.uid !== undefined) request.uid = { value: identity.uid };
    if (identity?.gid !== undefined) request.gid = { value: identity.gid };
    if (identity?.groups !== undefined) request.groups = identity.groups;
    const info = await unaryGuest({ binding }, "startDaemon", request);
    return publicDaemon(info);
  },
  daemon_list: async (resolver, input, exec) => {
    const binding = await resolveToolBinding(
      resolver,
      currentCwd(exec),
      input.container,
      exec?.signal,
    );
    const result = (await unaryGuest(
      { binding },
      "listDaemons",
      {},
    )) as { daemons?: any[] };
    return (result.daemons ?? []).map(publicDaemon);
  },
  daemon_stop: async (resolver, input, exec) => {
    const binding = await resolveToolBinding(
      resolver,
      currentCwd(exec),
      input.container,
      exec?.signal,
    );
    await daemonCall(input.name, () =>
      unaryGuest({ binding }, "stopDaemon", {
        name: input.name,
        signal: input.signal,
      }));
    return { stopped: input.name };
  },
  daemon_restart: async (resolver, input, exec) => {
    const binding = await resolveToolBinding(
      resolver,
      currentCwd(exec),
      input.container,
      exec?.signal,
    );
    const info = await daemonCall(
      input.name,
      () => unaryGuest({ binding }, "restartDaemon", { name: input.name }),
    );
    return publicDaemon(info);
  },
  daemon_logs: async (resolver, input, exec) => {
    const binding = await resolveToolBinding(
      resolver,
      currentCwd(exec),
      input.container,
      exec?.signal,
    );
    const result = (await daemonCall(
      input.name,
      () =>
        unaryGuest({ binding }, "daemonLogs", {
          name: input.name,
          tailBytes: input.tailBytes,
        }),
    )) as { stdout?: unknown; stderr?: unknown };
    return {
      stdout: bytesText(result.stdout),
      stderr: bytesText(result.stderr),
    };
  },
};

function daemonNotFound(name: string): Error {
  const error = new Error(`daemon ${JSON.stringify(name)} not found`);
  (error as { code?: string }).code = "NOT_FOUND";
  return error;
}

// containerPathState reads the guest's live PATH additions and the default PATH
// they are prepended to.
async function containerPathState(binding: {
  guest: any;
  token: string;
}): Promise<{ paths: string[]; defaultPaths: string[] }> {
  const result = (await unaryGuest({ binding }, "getPaths", {})) as any;
  const paths = Array.isArray(result?.paths)
    ? result.paths.map((path: unknown) => String(path))
    : [];
  const defaultPath = typeof result?.defaultPath === "string"
    ? result.defaultPath
    : "";
  return {
    paths,
    defaultPaths: defaultPath === "" ? [] : defaultPath.split(":"),
  };
}

// applyContainerPaths persists the list on the container and pushes it to the
// running guest agent, returning the applied (validated, deduplicated) list.
// The guest holds the live list; the container record is what a recreate
// restores it from.
async function applyContainerPaths(
  resolver: any,
  binding: { guest: any; token: string },
  slug: string,
  container: string,
  paths: readonly string[],
): Promise<string[]> {
  const row = (await resolver.control("setContainerPaths", {
    workspaceSlug: slug,
    container,
    paths: [...paths],
  })) as any;
  const persisted = Array.isArray(row?.paths)
    ? row.paths.map((path: unknown) => String(path))
    : [...paths];
  const result = (await unaryGuest({ binding }, "setPaths", {
    paths: persisted,
  })) as any;
  return Array.isArray(result?.paths)
    ? result.paths.map((path: unknown) => String(path))
    : persisted;
}

// daemonCall maps the guest agent's generic "unknown daemon" to a message that
// names the daemon the caller asked about.
async function daemonCall<T>(name: string, call: () => Promise<T>): Promise<T> {
  try {
    return await call();
  } catch (error) {
    if (
      (error as { code?: unknown }).code === grpc.status.NOT_FOUND &&
      /unknown daemon/.test((error as Error).message)
    ) {
      throw daemonNotFound(name);
    }
    throw error;
  }
}
