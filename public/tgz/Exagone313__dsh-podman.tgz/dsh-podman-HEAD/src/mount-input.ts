// SPDX-FileCopyrightText: 2026 Elouan Martinet <exa@elou.world>
//
// SPDX-License-Identifier: MIT

import {
  defaultMountMode,
  mountKindToProto,
  mountModeToProto,
} from "./mount-enums.js";
import { type ReasonLocale, renderDenial } from "./approval-reasons.js";

// The mount kind for a call: an explicit non-empty `kind` wins, otherwise it is
// inferred from the source field the caller supplied (`secret`/`volume`), since
// `kind` is optional in the mount schemas. Falls back to a project mount.
export function inferMountKind(args: {
  kind?: unknown;
  project?: unknown;
  volume?: unknown;
  secret?: unknown;
}): string {
  if (typeof args.kind === "string" && args.kind !== "") return args.kind;
  if (typeof args.secret === "string" && args.secret !== "") return "secret";
  if (typeof args.volume === "string" && args.volume !== "") return "volume";
  return "project";
}

// The container-side destination a project mount always lands at: the project
// path under projectsRoot.
export function projectMountMirror(
  projectsRoot: string,
  project: string,
): string {
  return [projectsRoot, project].filter((part) => part !== "").join("/");
}

// The reason to deny a mount item that carries a destination on a project (or
// unnamed) mount, or undefined when the item is allowed. Project mounts never
// take a destination; without one the directory lands at its project root.
export function projectMountDestinationReason(
  projectsRoot: string | undefined,
  args: {
    kind?: unknown;
    project?: unknown;
    destination?: unknown;
  },
  locale: ReasonLocale = "en",
): string | undefined {
  if (inferMountKind(args) !== "project") return undefined;
  if (args.destination === undefined || args.destination === "") {
    return undefined;
  }
  const project = typeof args.project === "string" ? args.project : "";
  const mirror = projectsRoot === undefined
    ? ""
    : projectMountMirror(projectsRoot, project);
  return renderDenial(locale, {
    kind: "project_destination",
    ...(project === "" ? {} : { source: project }),
    ...(mirror === "" ? {} : { mirror }),
  });
}

// validateMountInput applies the rules a mount must satisfy before it reaches
// the control plane: a project mount never takes a destination, and a secret
// mount is read-only. Both the model tools and the settings card call this, so
// the same rule cannot hold on one path and not the other.
export function validateMountInput(
  mount: any,
  projectsRoot: string | undefined,
): void {
  const destinationReason = projectMountDestinationReason(projectsRoot, mount);
  if (destinationReason !== undefined) throw new Error(destinationReason);
  if (inferMountKind(mount) === "secret" && mount?.mode === "read_write") {
    throw new Error("secret mounts are read-only; omit mode or use read_only");
  }
}

// mountInputToProto validates one mount and encodes it for the control plane.
// It is the single encoder both entry points use.
export function mountInputToProto(
  mount: any,
  projectsRoot: string | undefined,
): Record<string, unknown> {
  validateMountInput(mount, projectsRoot);
  const inferredKind = inferMountKind(mount);
  const kind = mountKindToProto(inferredKind);
  // `||`, not `??`: the card sends an empty string for an unset mode.
  const mode = mountModeToProto(mount?.mode || defaultMountMode(inferredKind));
  const result: Record<string, unknown> = {
    projectName: mount?.project ?? "",
    kind,
    mode,
  };
  if (inferredKind !== "project" && mount?.destination) {
    result.destination = mount.destination;
  }
  if (mount?.volume) result.volume = mount.volume;
  if (mount?.secret) result.secret = mount.secret;
  return result;
}

export function mountsFromInput(
  mounts: unknown,
  projectsRoot: string | undefined,
): Record<string, unknown>[] | undefined {
  if (!Array.isArray(mounts) || mounts.length === 0) return undefined;
  return mounts.map((mount) => mountInputToProto(mount, projectsRoot));
}
