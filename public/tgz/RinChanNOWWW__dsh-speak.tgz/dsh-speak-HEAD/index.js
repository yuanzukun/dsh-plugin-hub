/**
 * `dsh-speak` — read text aloud on the host machine.
 *
 * Host half of the plugin. It owns all speech: the model-facing `speak` tool,
 * the `POST /api/dsh-speak` action route, and the `GET /api/dsh-speak/status`
 * probe that the browser entries poll. Playback uses the macOS `say` command,
 * so audio comes out of the machine running the Harness, not the browser, and
 * exactly one utterance plays at a time.
 *
 * @module dsh-speak
 */
import { spawn } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { dirname, join } from 'node:path';
import { defineTool } from '@deepseek-ai/dsh-tools';

/** Plugin row id. */
export const name = 'dsh-speak';
/** The tool registry is required; the Web routes attach only when a web server exists. */
export const inject = ['tools'];

/** Action route: read text aloud or stop playback. */
const ROUTE = '/api/dsh-speak';
/** Status route: what is playing right now. */
const STATUS_ROUTE = '/api/dsh-speak/status';
/** Preferences route: per-language voices, rate, and the Han-character bias. */
const SETTINGS_ROUTE = '/api/dsh-speak/settings';
/** Browser-side report route: what the loaded page actually did, for debugging. */
const CLIENT_ROUTE = '/api/dsh-speak/client';
/** Where the preferences live. */
const SETTINGS_FILE = join(process.env.DSH_HOME ?? join(homedir(), '.dsh'), 'dsh-speak.settings.json');
/** Languages the settings panel can pin a voice for. */
const LANGUAGES = ['zh', 'en', 'ja', 'ko'];
/** How many browser reports to keep for the diagnostic read. */
const CLIENT_LOG_LIMIT = 200;
/** Longest text handed to one `say` invocation. */
const MAX_CHARS = 20000;
/** Largest request body accepted on the action route. */
const MAX_BODY_BYTES = 256 * 1024;
/** Default speech rate, words per minute. */
const DEFAULT_RATE = 190;
/** Lowest and highest rate `say` accepts. */
const RATE_MIN = 80;
const RATE_MAX = 500;

/**
 * Preferred voices per language, most preferred first. A missing voice falls
 * through to any installed voice for that locale, then to the system default.
 */
const PREFERRED_VOICES = {
  zh: ['Tingting', 'Meijia', 'Sinji', 'Ting-Ting'],
  en: ['Samantha', 'Alex', 'Daniel', 'Karen'],
  ja: ['Kyoko', 'Otoya'],
  ko: ['Yuna'],
};

/** Locale prefixes that count as one supported language. */
const LOCALE_PREFIXES = {
  zh: ['zh'],
  en: ['en'],
  ja: ['ja'],
  ko: ['ko'],
};

/** Kana, Hangul, Han, and Latin character tests used for per-character language detection. */
const KANA = /[\u3040-\u30ff]/;
const HANGUL = /[\u1100-\u11ff\u3130-\u318f\ua960-\ua97f\uac00-\ud7ff]/;
const HAN = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]/;
const LATIN = /[A-Za-z\u00c0-\u024f\u0370-\u03ff\u0400-\u04ff]/;
/** Punctuation that ends a reading chunk, so a Chinese sentence and the Japanese one after it split. */
const SENTENCE_END = /[。．！？!?…\n;；:：]/u;
/**
 * Latin runs shorter than this are read with the surrounding language instead of
 * an English voice, so an acronym or product name inside Chinese prose does not
 * flip the voice back and forth. Raise it to keep more English unmerged; set it
 * to 0 to disable the smoothing entirely.
 */
const MIN_LATIN_RUN = 12;

/** Installed voices by language code, and the one in-flight listing that fills it. */
let voiceTable = null;
let voiceLoading = null;

/**
 * List installed voices by language code, reading `say -v '?'` once.
 * @returns a map from a two-letter language code to installed voice names.
 */
function loadVoices() {
  if (voiceTable !== null) return Promise.resolve(voiceTable);
  if (voiceLoading !== null) return voiceLoading;
  voiceLoading = new Promise((resolve) => {
    const table = new Map();
    const finish = () => {
      voiceTable = table;
      resolve(table);
    };
    let child;
    try {
      child = spawn('say', ['-v', '?'], { stdio: ['ignore', 'pipe', 'ignore'] });
    } catch {
      finish();
      return;
    }
    let output = '';
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', (chunk) => {
      output += chunk;
    });
    child.on('close', () => {
      for (const line of output.split('\n')) collectVoice(table, line);
      finish();
    });
    child.on('error', finish);
  });
  return voiceLoading;
}

/**
 * Record one `say -v '?'` line.
 * @param cache - the voice map to fill.
 * @param line - one line of the listing.
 */
function collectVoice(cache, line) {
  const match = /^(.*?)\s{2,}([a-z]{2})[_-]([A-Z]{2})\s/.exec(line);
  if (match === null) return;
  const [, voiceName, language] = match;
  const names = cache.get(language) ?? [];
  names.push(voiceName.trim());
  cache.set(language, names);
}

/**
 * Resolve the voice for one language.
 * @param language - two-letter language code.
 * @param installed - the parsed voice table.
 * @returns the voice name, or undefined to let `say` use the system default.
 */
function voiceFor(language, installed) {
  const available = new Set();
  for (const prefix of LOCALE_PREFIXES[language] ?? [language]) {
    for (const name of installed.get(prefix) ?? []) available.add(name);
  }
  for (const preferred of PREFERRED_VOICES[language] ?? []) {
    if (available.has(preferred)) return preferred;
  }
  const [first] = [...available];
  return first;
}

//#region preferences — per-language voices, rate, and the Han-character bias
/** Preferences, read once at activation and rewritten on every change. */
let settings = readSettings();

/**
 * Read the preferences file, treating anything unreadable as "everything auto".
 * @returns the normalized preferences.
 */
function readSettings() {
  const empty = { voices: {}, rate: undefined, language: undefined };
  try {
    return normalizeSettings(JSON.parse(readFileSync(SETTINGS_FILE, 'utf8')), empty);
  } catch {
    return empty;
  }
}

/**
 * Keep only supported preference fields, leaving absent ones untouched.
 * @param raw - parsed JSON from the request body or the file.
 * @param base - values to keep when a field is absent or invalid.
 * @returns the normalized preferences.
 */
function normalizeSettings(raw, base) {
  const source = raw !== null && typeof raw === 'object' ? raw : {};
  const fallback = base ?? { voices: {}, rate: undefined, language: undefined };
  const voices = { ...(fallback.voices ?? {}) };
  if (source.voices === null) {
    for (const language of LANGUAGES) delete voices[language];
  } else if (typeof source.voices === 'object') {
    for (const language of LANGUAGES) {
      const value = source.voices?.[language];
      if (value === null || value === '') delete voices[language];
      else if (typeof value === 'string' && value.trim() !== '') voices[language] = value.trim();
    }
  }
  const rate = Object.hasOwn(source, 'rate')
    ? source.rate === null ? undefined : clampRate(source.rate)
    : fallback.rate;
  const language = Object.hasOwn(source, 'language')
    ? typeof source.language === 'string' && LANGUAGES.includes(source.language.trim().toLowerCase())
      ? source.language.trim().toLowerCase()
      : undefined
    : fallback.language;
  return { voices, rate, language };
}

/**
 * Persist preferences, creating the Harness home when it is missing.
 * @param next - the normalized preferences.
 */
function writeSettings(next) {
  settings = next;
  try {
    mkdirSync(dirname(SETTINGS_FILE), { recursive: true });
    writeFileSync(SETTINGS_FILE, `${JSON.stringify(next, null, 2)}\n`);
  } catch {
    // A read-only home keeps the in-memory value working for this process.
  }
}

/**
 * Resolve one reading's options: explicit arguments win, then preferences.
 * @param options - request or tool arguments, possibly empty.
 * @returns the options {@link planUtterances} should use.
 */
function effectiveOptions(options = {}) {
  return {
    ...options,
    voice: options.voice ?? undefined,
    language: options.language ?? settings.language,
    rate: options.rate ?? settings.rate,
    voices: settings.voices,
  };
}

/**
 * Wire shape of the preferences and the voices they can be chosen from.
 * @returns the settings payload for the browser panel.
 */
async function settingsPayload() {
  const installed = await loadVoices();
  const voices = {};
  for (const language of LANGUAGES) {
    const collected = [];
    for (const prefix of LOCALE_PREFIXES[language] ?? [language]) {
      for (const name of installed.get(prefix) ?? []) if (!collected.includes(name)) collected.push(name);
    }
    // Offer the recommended voices first; the novelty ones stay available below.
    const preferred = PREFERRED_VOICES[language] ?? [];
    const rank = (name) => {
      const index = preferred.indexOf(name);
      return index === -1 ? preferred.length : index;
    };
    collected.sort((left, right) => rank(left) - rank(right) || left.localeCompare(right));
    voices[language] = collected;
  }
  return {
    settings: { voices: settings.voices, rate: settings.rate ?? null, language: settings.language ?? null },
    voices,
    preferred: PREFERRED_VOICES,
    defaults: { rate: DEFAULT_RATE },
    range: { min: RATE_MIN, max: RATE_MAX },
    platform: process.platform,
  };
}
//#endregion

/**
 * Strip the markdown that reads badly aloud.
 * @param text - raw text, from a model reply or a caller.
 * @returns the plain-text form.
 */
function sanitize(text) {
  return String(text ?? '')
    .replace(/```[\s\S]*?(?:```|$)/g, ' ')
    .replace(/`([^`]*)`/g, '$1')
    .replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
    .replace(/^\s{0,3}#{1,6}\s*/gm, '')
    .replace(/^\s{0,3}[-*+]\s+/gm, '')
    .replace(/^\s{0,3}>\s?/gm, '')
    .replace(/^\s*\|.*\|\s*$/gm, ' ')
    .replace(/[*_~]{1,3}/g, '')
    .replace(/[ \t]+/g, ' ')
    .replace(/\s*\n\s*/g, '\n')
    .trim();
}

/**
 * Script family of one character.
 * @param character - one character.
 * @returns `cjk`, `ko`, `en`, or null for punctuation, digits, and whitespace.
 */
function kindOf(character) {
  if (KANA.test(character) || HAN.test(character)) return 'cjk';
  if (HANGUL.test(character)) return 'ko';
  if (LATIN.test(character)) return 'en';
  return null;
}

/**
 * Split text into consecutive same-language runs.
 *
 * Han characters alone are Chinese; a Han/kana run containing any kana is
 * Japanese. Sentence-ending punctuation and script changes close a run, so a
 * Chinese sentence followed by a Japanese one keeps both voices. Han text that
 * is genuinely interleaved with kana cannot be separated by script alone and
 * reads as Japanese.
 *
 * @param text - sanitized text.
 * @param hanLanguage - what a kana-free Han run counts as (the caller's bias).
 * @returns runs of `{ language, text }`, in reading order.
 */
function segments(text, hanLanguage = 'zh') {
  const chunks = [];
  let current = null;
  for (const character of text) {
    const kind = kindOf(character);
    if (kind === null) {
      if (current !== null) {
        current.text += character;
        if (SENTENCE_END.test(character)) current = null;
      }
      continue;
    }
    if (current !== null && current.kind === kind) current.text += character;
    else {
      current = { kind, text: character };
      chunks.push(current);
    }
  }
  const runs = [];
  for (const chunk of chunks) {
    const text = chunk.text.trim();
    if (text === '') continue;
    const language = chunk.kind === 'cjk' ? (KANA.test(chunk.text) ? 'ja' : hanLanguage) : chunk.kind;
    const previous = runs[runs.length - 1];
    if (previous !== undefined && previous.language === language) previous.text += text;
    else runs.push({ language, text });
  }
  return runs;
}

/** Script family each language is written in, for measuring how much of a run is that language. */
const SCRIPT_KIND = { en: 'en', ko: 'ko', zh: 'cjk', ja: 'cjk' };

/**
 * How many characters of a run belong to the run's own script — trailing
 * punctuation and spaces do not count, so `voice input。` measures as 10.
 * @param text - the run text.
 * @param language - the run's language.
 * @returns the count of that script's characters.
 */
function scriptLength(text, language) {
  const kind = SCRIPT_KIND[language] ?? 'en';
  let count = 0;
  for (const character of text) if (kindOf(character) === kind) count += 1;
  return count;
}

/**
 * Fold short Latin fragments into the language around them and merge what that
 * makes adjacent. Chinese prose with an English term in it otherwise switches
 * voice for a few characters and back, which sounds like stuttering; CJK and
 * Hangul runs are never absorbed, so a Korean or Japanese phrase always keeps
 * its own voice.
 *
 * @param runs - runs from {@link segments}.
 * @returns the runs to speak, in order.
 */
function absorbShortLatin(runs) {
  const folded = [];
  for (let index = 0; index < runs.length; index += 1) {
    const run = runs[index];
    const previous = folded[folded.length - 1];
    if (run.language === 'en' && scriptLength(run.text, 'en') < MIN_LATIN_RUN) {
      const next = runs[index + 1];
      const host = previous !== undefined && previous.language !== 'en'
        ? previous
        : next !== undefined && next.language !== 'en' ? { language: next.language } : undefined;
      if (host !== undefined) {
        if (previous !== undefined && previous.language !== 'en') previous.text += run.text;
        else folded.push({ language: host.language, text: run.text });
        continue;
      }
    }
    if (previous !== undefined && previous.language === run.language) previous.text += run.text;
    else folded.push({ ...run });
  }
  return folded;
}

/**
 * Clamp a requested rate into `say`'s accepted range.
 * @param rate - requested words per minute, possibly absent or invalid.
 * @returns the rate to pass to `say`.
 */
function clampRate(rate) {
  const value = Number(rate);
  if (!Number.isFinite(value)) return DEFAULT_RATE;
  return Math.min(RATE_MAX, Math.max(RATE_MIN, Math.round(value)));
}

/**
 * Turn text plus options into an ordered list of single-voice utterances.
 *
 * macOS `say` has no inline voice-switch command — its embedded `[[...]]`
 * commands cover rate, pitch, volume, and input mode only, and an unknown one
 * is read out as literal text. Each language run therefore becomes its own
 * `say` process with its own `-v`, played back to back.
 *
 * @param text - raw text to read.
 * @param options - optional `voice`, `language`, and `rate` overrides.
 * @returns per-run argv, the voices used, rate, languages, and spoken text.
 */
async function planUtterances(text, options = {}) {
  const spoken = sanitize(text).slice(0, MAX_CHARS);
  if (spoken === '') throw new Error('speak: there is no readable text');
  const installed = await loadVoices();

  const forced = typeof options.voice === 'string' && options.voice.trim() !== '' ? options.voice.trim() : undefined;
  const language = typeof options.language === 'string' ? options.language.trim().toLowerCase() : undefined;
  // `language` biases the script reading (bare Han characters) and backs up voice
  // resolution; only `voice` collapses the whole text into one utterance.
  const runs = absorbShortLatin(segments(spoken, language === 'ja' ? 'ja' : 'zh'));
  const rate = clampRate(options.rate);
  const languages = [...new Set(runs.map((run) => run.language))];
  const resolved = runs.length === 0 ? [{ language: language ?? 'en', text: spoken }] : runs;
  const fallbackVoice = language === undefined ? undefined : voiceFor(language, installed);
  // A stored per-language voice only applies while it is still installed.
  const known = new Set();
  for (const names of installed.values()) for (const name of names) known.add(name);
  const pinned = (forLanguage) => {
    const name = options.voices?.[forLanguage];
    return typeof name === 'string' && known.has(name) ? name : undefined;
  };

  const parts = forced !== undefined || resolved.length <= 1
    ? [{
      text: spoken,
      language: language ?? resolved[0].language,
      voice: forced ?? pinned(language ?? resolved[0].language) ?? voiceFor(language ?? resolved[0].language, installed),
    }]
    : resolved.map((run) => ({
      text: run.text,
      language: run.language,
      voice: pinned(run.language) ?? voiceFor(run.language, installed) ?? fallbackVoice,
    }));

  const utterances = parts.map((part) => {
    const argv = [];
    if (part.voice !== undefined) argv.push('-v', part.voice);
    argv.push('-r', String(rate), part.text);
    return { ...part, argv };
  });
  const voices = [...new Set(utterances.map((utterance) => utterance.voice ?? 'system default'))];
  const sequence = utterances.map((utterance) => ({
    language: utterance.language,
    voice: utterance.voice ?? 'system default',
    characters: utterance.text.length,
  }));
  return { utterances, sequence, voices, voice: voices[0] ?? 'system default', rate, languages, spoken };
}

//#region playback — one queue of utterances, owned here
/** The playback running now, or null. */
let playback = null;

/**
 * Leave the current playback record and release anyone waiting on it.
 * @param record - the record to close.
 */
function finishPlayback(record) {
  if (playback === record) playback = null;
  record?.finish?.();
}

/**
 * Stop the current playback, including any utterances queued behind it.
 * @returns whether anything was stopped.
 */
function stopPlayback() {
  const current = playback;
  playback = null; // first, so the child's exit handler does not advance the queue
  if (current === null) return false;
  try {
    current.child?.kill('SIGTERM');
  } catch {
    // The process already exited; nothing left to stop.
  }
  current.finish?.();
  return true;
}

/**
 * Start the next utterance of a record, and finish the record when none remain.
 * @param record - the playback record.
 */
function advancePlayback(record) {
  record.index += 1;
  const utterance = record.queue[record.index];
  if (utterance === undefined) {
    finishPlayback(record);
    return;
  }
  const child = spawn('say', utterance.argv, { stdio: 'ignore' });
  record.child = child;
  child.on('exit', (code, signal) => {
    if (playback !== record) return; // stopped or replaced while this one spoke
    if (code !== 0 && signal === null && code !== null) {
      record.failure = `say exited with code ${String(code)}`;
      finishPlayback(record);
      return;
    }
    advancePlayback(record);
  });
  child.on('error', (error) => {
    if (playback !== record) return;
    record.failure = String(error?.message ?? error);
    finishPlayback(record);
  });
}

/**
 * Start a planned reading, replacing any earlier one.
 * @param plan - the result of {@link planUtterances}.
 * @param meta - identity of this reading, echoed by status.
 * @returns the playback record.
 */
function startPlayback(plan, meta) {
  if (process.platform !== 'darwin') throw new Error('speak: reading aloud uses the macOS say command');
  stopPlayback();
  const record = {
    ...meta,
    queue: plan.utterances,
    index: -1,
    child: null,
    voices: plan.voices,
    sequence: plan.sequence,
    voice: plan.voice,
    rate: plan.rate,
    languages: plan.languages,
    spoken: plan.spoken,
    startedAt: Date.now(),
  };
  record.done = new Promise((resolve) => {
    record.finish = resolve;
  });
  playback = record;
  advancePlayback(record);
  return record;
}

/**
 * Wait for one planned reading to finish or be interrupted.
 * @param record - the playback record to await.
 */
async function waitForPlayback(record) {
  await record.done;
  if (record.failure !== undefined) throw new Error(`speak: ${record.failure}`);
}

/**
 * Wire shape of the current reading.
 * @returns the status payload, or null when nothing is playing.
 */
function playbackStatus() {
  if (playback === null) return null;
  return {
    sessionId: playback.sessionId ?? null,
    messageId: playback.messageId ?? null,
    source: playback.sessionId === undefined ? 'text' : 'message',
    characters: playback.spoken.length,
    languages: playback.languages,
    voice: playback.voice,
    voices: playback.voices,
    sequence: playback.sequence,
    rate: playback.rate,
    utterances: playback.queue.length,
    current: playback.index + 1,
    startedAt: playback.startedAt,
    elapsedMs: Date.now() - playback.startedAt,
  };
}
//#endregion

/**
 * Read a bounded JSON request body.
 * @param req - the incoming request.
 * @returns the parsed body.
 */
async function readJsonBody(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY_BYTES) throw new Error('request body too large');
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

/**
 * Text of one assistant message event.
 * @param event - a session event.
 * @returns the joined text blocks, or the empty string.
 */
function assistantTextOf(event) {
  const blocks = event?.data?.message?.content;
  if (!Array.isArray(blocks)) return '';
  return blocks
    .filter((block) => block !== null && typeof block === 'object' && block.type === 'text' && typeof block.text === 'string')
    .map((block) => block.text)
    .join('\n')
    .trim();
}

/**
 * Resolve readable text for one session message.
 * @param ctx - the plugin context, used to reach the session store.
 * @param sessionId - the session to read.
 * @param messageId - the exact message, or absent for the newest assistant message.
 * @returns the text and the message id it came from.
 */
function sessionMessageText(ctx, sessionId, messageId) {
  const store = ctx.get('sessions');
  if (store === undefined || store === null || typeof store.get !== 'function') {
    throw new Error('speak: the session store is unavailable');
  }
  const session = store.get(sessionId);
  if (session === undefined || session === null) throw new Error(`speak: unknown session ${sessionId}`);
  const events = typeof session.snapshotEvents === 'function' ? session.snapshotEvents() : [];
  let fallback;
  for (const event of events) {
    if (event?.type !== 'assistant/message') continue;
    const text = assistantTextOf(event);
    if (text === '') continue;
    const id = event.data?.message?.id;
    fallback = { text, messageId: id ?? null };
    if (messageId !== undefined && messageId !== null && id === messageId) return fallback;
  }
  if (fallback !== undefined) return fallback;
  throw new Error('speak: this session has no assistant message to read');
}

//#region browser reports — what the loaded page actually did
/** Newest-last ring of browser reports, so a page you cannot see can still be diagnosed. */
const clientLog = [];

/**
 * Record one browser report, keeping it small and serializable.
 * @param report - the parsed request body.
 * @returns the stored entry.
 */
function recordClientReport(report) {
  const { event, build, ...rest } = report ?? {};
  let note = '';
  try {
    note = JSON.stringify(rest);
  } catch {
    note = '"[unserializable]"';
  }
  const entry = {
    at: new Date().toISOString(),
    event: typeof event === 'string' ? event.slice(0, 60) : 'unknown',
    ...typeof build === 'string' ? { build: build.slice(0, 40) } : {},
    note: note.length > 500 ? `${note.slice(0, 500)}…` : note,
  };
  clientLog.push(entry);
  if (clientLog.length > CLIENT_LOG_LIMIT) clientLog.splice(0, clientLog.length - CLIENT_LOG_LIMIT);
  return entry;
}
//#endregion

/**
 * Send one JSON response.
 * @param res - the response to write.
 * @param status - HTTP status.
 * @param payload - JSON-serializable body.
 */
function sendJson(res, status, payload) {
  res.statusCode = status;
  res.setHeader('content-type', 'application/json; charset=utf-8');
  res.setHeader('cache-control', 'no-store');
  res.end(JSON.stringify(payload));
}

/**
 * Resolve one request body into the text to read plus its identity.
 * @param ctx - the plugin context.
 * @param body - the parsed request body.
 * @returns the text, and the message identity when it came from a session.
 */
function resolveRequest(ctx, body) {
  const explicit = typeof body?.text === 'string' && body.text.trim() !== '' ? body.text : undefined;
  if (explicit !== undefined) return { text: explicit, sessionId: undefined, messageId: null };
  const resolved = sessionMessageText(ctx, body?.sessionId, body?.messageId);
  return { text: resolved.text, sessionId: body?.sessionId, messageId: resolved.messageId };
}

/**
 * Register the `speak` tool and, when a web server exists, both Web routes.
 * @param ctx - the plugin context.
 */
export function apply(ctx) {
  ctx.tools.register(defineTool({
    name: 'speak',
    description: 'Read text aloud through the speakers of the machine running the Harness (macOS speech synthesis), or stop the reading already in progress. Use it whenever the human asks to hear, read out, pronounce, or have something spoken, and whenever they ask you to stop. Chinese, English, Japanese, and Korean are detected per character and each script run is read with its own system voice (per-language voices, rate, and the Han-character bias come from the saved speaker settings in the Web UI — pass voice/language/rate only to override them for one reading); markdown is stripped first. Only one reading plays at a time, so a new request replaces the previous one.',
    parameters: {
      text: {
        type: 'string',
        description: 'The text to read aloud. Required unless stop is true. Markdown is stripped automatically.',
      },
      stop: {
        type: 'boolean',
        description: 'Stop whatever is being read aloud instead of starting new speech.',
      },
      language: {
        type: 'string',
        description: 'Bias how ambiguous text is read: zh or ja decides bare Han characters, and it is the fallback voice. It does NOT force the whole text into one voice — other scripts still get their own voices. Use `voice` for a single-voice reading.',
      },
      voice: {
        type: 'string',
        description: 'Read the entire text with this exact macOS voice, such as Tingting, Kyoko, Yuna, or Samantha. Collapses everything into one utterance.',
      },
      rate: {
        type: 'integer',
        description: `Speech rate in words per minute, ${RATE_MIN}-${RATE_MAX} (default ${DEFAULT_RATE}).`,
      },
      wait: {
        type: 'boolean',
        description: 'Wait for playback to finish before returning (default false, returns as soon as speech starts or stops).',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          action: { type: 'string', required: true, enum: ['speak', 'stop'] },
          characters: { type: 'integer', required: true },
          languages: { type: 'array', required: true, items: { type: 'string' } },
          voice: { type: 'string', required: true },
          voices: { type: 'array', required: true, items: { type: 'string' } },
          sequence: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                language: { type: 'string', required: true },
                voice: { type: 'string', required: true },
                characters: { type: 'integer', required: true },
              },
            },
          },
          utterances: { type: 'integer', required: true },
          rate: { type: 'integer', required: true },
          preview: { type: 'string', required: true },
          playing: { type: 'boolean', required: true },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.action === 'stop'
          ? (value.characters > 0 ? `Stopped reading ${value.characters} characters.` : 'Nothing was being read aloud.')
          : `${value.playing ? 'Started reading' : 'Read aloud'} ${value.characters} characters at ${value.rate} wpm as ${value.utterances} utterance(s): ${value.sequence.map((step) => `${step.voice} for ${step.language}`).join(' -> ')}.`,
      }],
    },
    presentCall: (args) => ({
      card: 'generic',
      title: args.stop === true ? 'Stop reading aloud' : 'Read aloud',
      kind: 'other',
      rawInput: { text: args.text, language: args.language, rate: args.rate },
    }),
    async execute(args) {
      if (args.stop === true) {
        const status = playbackStatus();
        const stopped = stopPlayback();
        return {
          action: 'stop',
          characters: stopped ? status?.characters ?? 0 : 0,
          languages: stopped ? status?.languages ?? [] : [],
          voice: stopped ? status?.voice ?? 'system default' : 'system default',
          voices: stopped ? status?.voices ?? [] : [],
          sequence: stopped ? status?.sequence ?? [] : [],
          utterances: stopped ? status?.utterances ?? 0 : 0,
          rate: stopped ? status?.rate ?? DEFAULT_RATE : DEFAULT_RATE,
          preview: '',
          playing: false,
        };
      }
      if (typeof args.text !== 'string' || args.text.trim() === '') {
        throw new Error('speak: `text` is required unless `stop` is true');
      }
      const plan = await planUtterances(args.text, effectiveOptions(args));
      const record = startPlayback(plan, {});
      if (args.wait === true) await waitForPlayback(record);
      return {
        action: 'speak',
        characters: plan.spoken.length,
        languages: plan.languages,
        voice: plan.voice,
        voices: plan.voices,
        sequence: plan.sequence,
        utterances: plan.utterances.length,
        rate: plan.rate,
        preview: plan.spoken.slice(0, 80),
        playing: playbackStatus() !== null,
      };
    },
  }));

  ctx.effect(() => () => stopPlayback(), 'dsh-speak: playback lifetime');

  ctx.inject(['webServer'], (scope) => {
    scope.effect(() => scope.webServer.register({
      kind: 'exact',
      path: ROUTE,
      handler: async (req, res) => {
        if (req.method !== 'POST') {
          res.statusCode = 405;
          res.setHeader('allow', 'POST');
          res.end();
          return;
        }
        const mediaType = String(req.headers['content-type'] ?? '').split(';')[0].trim().toLowerCase();
        if (mediaType !== 'application/json') {
          sendJson(res, 415, { ok: false, error: 'content-type must be application/json' });
          return;
        }
        let body;
        try {
          body = await readJsonBody(req);
        } catch (error) {
          sendJson(res, 400, { ok: false, error: String(error?.message ?? error) });
          return;
        }
        if (body?.action === 'stop') {
          const stopped = stopPlayback();
          sendJson(res, 200, { ok: true, action: 'stop', stopped, speaking: playbackStatus() });
          return;
        }
        try {
          const request = resolveRequest(scope, body);
          const plan = await planUtterances(request.text, effectiveOptions(body ?? {}));
          startPlayback(plan, {
            sessionId: request.sessionId,
            messageId: request.messageId ?? undefined,
          });
          sendJson(res, 200, {
            ok: true,
            action: 'speak',
            messageId: request.messageId ?? null,
            characters: plan.spoken.length,
            languages: plan.languages,
            voice: plan.voice,
            voices: plan.voices,
            sequence: plan.sequence,
            utterances: plan.utterances.length,
            rate: plan.rate,
            speaking: playbackStatus(),
          });
        } catch (error) {
          sendJson(res, 422, { ok: false, error: String(error?.message ?? error) });
        }
      },
    }), `dsh-speak: POST ${ROUTE}`);

    scope.effect(() => scope.webServer.register({
      kind: 'exact',
      path: STATUS_ROUTE,
      handler: (req, res) => {
        if (req.method !== 'GET' && req.method !== 'HEAD') {
          res.statusCode = 405;
          res.setHeader('allow', 'GET');
          res.end();
          return;
        }
        const payload = JSON.stringify({ ok: true, platform: process.platform, speaking: playbackStatus() });
        res.statusCode = 200;
        res.setHeader('content-type', 'application/json; charset=utf-8');
        res.setHeader('cache-control', 'no-store');
        res.end(req.method === 'HEAD' ? undefined : payload);
      },
    }), `dsh-speak: GET ${STATUS_ROUTE}`);

    // Preferences: the browser panel reads them, writes them, and gets the
    // installed voices it can offer.
    scope.effect(() => scope.webServer.register({
      kind: 'exact',
      path: SETTINGS_ROUTE,
      handler: async (req, res) => {
        if (req.method === 'GET' || req.method === 'HEAD') {
          const payload = JSON.stringify({ ok: true, ...(await settingsPayload()) });
          res.statusCode = 200;
          res.setHeader('content-type', 'application/json; charset=utf-8');
          res.setHeader('cache-control', 'no-store');
          res.end(req.method === 'HEAD' ? undefined : payload);
          return;
        }
        if (req.method !== 'POST') {
          res.statusCode = 405;
          res.setHeader('allow', 'GET, POST');
          res.end();
          return;
        }
        const mediaType = String(req.headers['content-type'] ?? '').split(';')[0].trim().toLowerCase();
        if (mediaType !== 'application/json') {
          sendJson(res, 415, { ok: false, error: 'content-type must be application/json' });
          return;
        }
        let body;
        try {
          body = await readJsonBody(req);
        } catch (error) {
          sendJson(res, 400, { ok: false, error: String(error?.message ?? error) });
          return;
        }
        // Refuse a voice this machine does not have, so a saved preference can
        // never turn every later reading into a failed spawn.
        const requested = body?.voices;
        if (requested !== null && typeof requested === 'object') {
          const installed = await loadVoices();
          const known = new Set();
          for (const names of installed.values()) for (const name of names) known.add(name);
          for (const language of LANGUAGES) {
            const name = requested[language];
            if (typeof name === 'string' && name !== '' && !known.has(name)) {
              sendJson(res, 422, { ok: false, error: `unknown voice for ${language}: ${name}` });
              return;
            }
          }
        }
        writeSettings(normalizeSettings(body, settings));
        sendJson(res, 200, { ok: true, ...(await settingsPayload()) });
      },
    }), `dsh-speak: GET+POST ${SETTINGS_ROUTE}`);

    // Browser reports: the page says which bundle loaded and what it registered,
    // which is the only way to see the browser half from here.
    scope.effect(() => scope.webServer.register({
      kind: 'exact',
      path: CLIENT_ROUTE,
      handler: async (req, res) => {
        if (req.method === 'POST') {
          const mediaType = String(req.headers['content-type'] ?? '').split(';')[0].trim().toLowerCase();
          if (mediaType !== 'application/json') {
            sendJson(res, 415, { ok: false, error: 'content-type must be application/json' });
            return;
          }
          let body;
          try {
            body = await readJsonBody(req);
          } catch (error) {
            sendJson(res, 400, { ok: false, error: String(error?.message ?? error) });
            return;
          }
          const entry = recordClientReport(body);
          sendJson(res, 200, { ok: true, at: entry.at });
          return;
        }
        if (req.method === 'GET' || req.method === 'HEAD') {
          const payload = JSON.stringify({ ok: true, count: clientLog.length, reports: clientLog.slice(-60) });
          res.statusCode = 200;
          res.setHeader('content-type', 'application/json; charset=utf-8');
          res.setHeader('cache-control', 'no-store');
          res.end(req.method === 'HEAD' ? undefined : payload);
          return;
        }
        res.statusCode = 405;
        res.setHeader('allow', 'GET, POST');
        res.end();
      },
    }), `dsh-speak: GET+POST ${CLIENT_ROUTE}`);
  });
}
