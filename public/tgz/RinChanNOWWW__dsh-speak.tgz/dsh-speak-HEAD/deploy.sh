#!/bin/bash
# 把 dsh-speak 部署到运行中的 DSH profile，并让宿主代码立刻生效（开发辅助脚本）。
#
# 实测出来的三条 Loader 规则（决定了这个脚本为什么这么写）：
#   1. 已挂载的行只改 `name` **不会**重新 import（旧模块实例还挂在 fiber 上）；
#   2. `name` 里带 `?v=` 查询串会被 Loader 拒绝，文件根本不会被读；
#   3. 把行**移除再插入**会实时生效，此时再用一个**新文件名**，ESM 缓存也不会命中旧代。
# 所以：先删行 → 等路由消失（确认已卸载）→ 用新的 index.vN.js 重新插入 → 等路由回来。
#
# 客户端代码（client.js）没有模块身份可换，改完刷新页面（或重新合成该行）。
#
# 用法：  ./deploy.sh
set -euo pipefail

SRC="$(cd "$(dirname "$0")" && pwd)"
PROFILE="${DSH_PROFILE_DIR:-$HOME/.dsh/profiles/desktop}"
DIR="$PROFILE/plugins/dsh-speak"
PATCH="$PROFILE/cordis.patch.yml"
BASE="${DSH_WEB_URL:-http://127.0.0.1:19387}"
STATUS_ROUTE="$BASE/api/dsh-speak/status"

[ -f "$PATCH" ] || { echo "找不到 profile 配置：$PATCH" >&2; exit 1; }

mkdir -p "$DIR"

# 下一个版本号，并只保留这一个入口文件
next=1
for f in "$DIR"/index.v*.js; do
  [ -e "$f" ] || continue
  n="${f##*/index.v}"; n="${n%.js}"
  [ "$n" -ge "$next" ] 2>/dev/null && next=$((n + 1))
done
entry="index.v$next.js"

# App 在跑吗？（在跑才需要等热重载）
app_up=0
if curl -sf -m 3 -o /dev/null "$STATUS_ROUTE" 2>/dev/null || curl -s -m 3 -o /dev/null -w '%{http_code}' "$STATUS_ROUTE" 2>/dev/null | grep -qE '401|200'; then
  app_up=1
fi

# 1) 先移除行，让宿主卸载旧代
node - "$PATCH" <<'NODE'
const fs = require('node:fs');
const { parse } = require(process.env.HOME + '/.dsh/profiles/node_modules/yaml');
const quiet = (text) => parse(text, { logLevel: 'silent' });
const patch = process.argv[2];
const text = fs.readFileSync(patch, 'utf8');
const index = text.indexOf('\n# ── 朗读插件');
const kept = index < 0 ? text : text.slice(0, index) + '\n';
quiet(kept);
fs.writeFileSync(patch, kept);
console.log(index < 0 ? '[skip] profile patch 里没有 speak 段' : '[1/4] 已移除 speak 行');
NODE

if [ "$app_up" = 1 ]; then
  for _ in $(seq 1 20); do
    code="$(curl -s -m 2 -o /dev/null -w '%{http_code}' "$STATUS_ROUTE" || true)"
    [ "$code" = "401" ] || [ "$code" = "404" ] || [ "$code" = "000" ] && break
    sleep 0.5
  done
fi

# 2) 落盘新版本入口（换文件名，绕开 ESM 缓存）
cp "$SRC/package.json" "$SRC/client.js" "$DIR/"
cp "$SRC/index.js" "$DIR/$entry"
echo "[2/4] 已写入 $DIR/$entry"

# 3) 重新插入行
node - "$PATCH" "$entry" <<'NODE'
const fs = require('node:fs');
const { parse } = require(process.env.HOME + '/.dsh/profiles/node_modules/yaml');
const quiet = (text) => parse(text, { logLevel: 'silent' });
const [patch, entry] = process.argv.slice(2);
const block = `
# ── 朗读插件 @local/dsh-speak：Agent 工具 speak + 消息旁/选中内容 🔊 朗读 ──────
# 源码见本仓库；用 deploy.sh 部署，别手改这里的 name。
# 宿主代码更新必须「先删行再插入」+ 新文件名，只改 name 不会重新 import。
- insert:
    - id: speak
      name: ./plugins/dsh-speak/${entry}
`;
const text = fs.readFileSync(patch, 'utf8');
const next = text.replace(/\s*$/, '\n') + block;
quiet(next);
fs.writeFileSync(patch, next);
console.log(`[3/4] 已插入行：${entry}`);
NODE

# 4) 等路由回来并打印状态
if [ "$app_up" = 1 ]; then
  for _ in $(seq 1 30); do
    code="$(curl -s -m 2 -o /dev/null -w '%{http_code}' "$STATUS_ROUTE" || true)"
    [ "$code" = "200" ] && break
    sleep 0.5
  done
  echo "[4/4] 状态路由 HTTP $code"
fi

# 只保留最新入口
for f in "$DIR"/index.v*.js; do
  [ "$(basename "$f")" = "$entry" ] || rm -f "$f"
done
rm -f "$DIR/index.js"

echo
echo "已部署：$DIR/$entry"
echo "宿主：$(curl -s -m 5 "$STATUS_ROUTE" || echo '（App 未响应，重启 App 后生效）')"
echo "客户端改动请刷新页面。"
