/**
 * `dsh-speak` — browser half.
 *
 * Four entries, all backed by the host half's `say` playback:
 *
 * - a speaker action on every finalized assistant message in the
 *   `conversation.chat.assistant-actions` strip, toggling between reading that
 *   reply and stopping it;
 * - a floating button over any page text selection (the "select to translate"
 *   interaction), registered into the root `shell.overlay` list;
 * - a speaker-gear button in `conversation.composer.dock` that opens the reading
 *   settings panel (per-language voice, rate, Han-character bias);
 * - the settings panel itself, also in `shell.overlay` so the composer cannot
 *   clip it.
 *
 * Playback state lives in one store that polls the host while something plays.
 * The module also reports what it loaded and did to `POST /api/dsh-speak/client`
 * — the only way to see the browser half from the host, and what makes a page
 * without devtools diagnosable.
 */
window.__ModuleLoader__.load({
  id: 'dsh-speak',
  factory(require) {
    const React = require('react');
    const h = React.createElement;

    /** Bumped by hand whenever this file changes, so the host log shows which build a page runs. */
    const CLIENT_BUILD = '2026-10-11.17';
    /** Host routes. */
    const SPEAK_ROUTE = '/api/dsh-speak';
    const STATUS_ROUTE = '/api/dsh-speak/status';
    const SETTINGS_ROUTE = '/api/dsh-speak/settings';
    const CLIENT_ROUTE = '/api/dsh-speak/client';
    /** Poll cadence while playback is active. */
    const POLL_MS = 1200;
    /** Slow heartbeat while idle, so a reading the agent started still gets a stop control. */
    const IDLE_POLL_MS = 4000;
    /** Longest selection handed to the host. */
    const SELECTION_LIMIT = 20000;
    /** How long an error state stays before falling back to idle. */
    const ERROR_RESET_MS = 4000;
    /** Per-event floor between diagnostic reports. */
    const REPORT_MIN_MS = 1500;
    /** Languages the settings panel pins voices for, with their display labels. */
    const LANGUAGE_ROWS = [['zh', '中文'], ['en', 'English'], ['ja', '日本語'], ['ko', '한국어']];
    /** Sample used by the panel's preview button. */
    const PREVIEW_TEXT = '这是中文。This is English. 日本語です。한국어입니다.';

    //#region diagnostics — report to the host so a headless page stays observable
    const lastReportAt = new Map();

    /**
     * POST one report to the host's ring buffer.
     * @param event - short event name.
     * @param detail - small JSON-serializable detail.
     * @param force - skip the per-event throttle.
     */
    function report(event, detail = {}, force = false) {
      const now = Date.now();
      const previous = lastReportAt.get(event) ?? 0;
      if (!force && now - previous < REPORT_MIN_MS) return;
      lastReportAt.set(event, now);
      try {
        void fetch(CLIENT_ROUTE, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ event, build: CLIENT_BUILD, at: new Date().toISOString(), ...detail }),
        }).catch(() => {});
      } catch {
        // Diagnostics must never break the feature.
      }
    }
    //#endregion

    //#region playback store — the single owner of "what is speaking now"
    const playbackListeners = new Set();
    let playbackState = { phase: 'idle', key: null, error: null };
    let pollTimer = null;
    let hostPlatform = null;
    let playbackDisposed = false;

    const emitPlayback = () => {
      for (const listener of [...playbackListeners]) listener();
    };
    const patchPlayback = (next) => {
      playbackState = { ...playbackState, ...next };
      emitPlayback();
    };
    /** Store identity of whatever the host reports as playing. */
    const playbackKey = (speaking) => {
      if (speaking === null || speaking === undefined) return null;
      if (typeof speaking.messageId === 'string' && speaking.messageId !== '') {
        return `msg:${String(speaking.sessionId)}:${speaking.messageId}`;
      }
      return 'selection';
    };

    /** Read host playback status; `undefined` means the probe itself failed. */
    async function readStatus() {
      try {
        const response = await fetch(STATUS_ROUTE, { headers: { accept: 'application/json' } });
        if (!response.ok) return undefined;
        const body = await response.json();
        if (typeof body?.platform === 'string') hostPlatform = body.platform;
        return body?.speaking ?? null;
      } catch {
        return undefined;
      }
    }

    function stopPolling() {
      if (pollTimer !== null) {
        window.clearInterval(pollTimer);
        pollTimer = null;
      }
    }

    function startPolling() {
      if (pollTimer === null && !playbackDisposed) pollTimer = window.setInterval(() => void refresh(), POLL_MS);
    }

    /** Reconcile the store with the host, and keep polling while it plays. */
    async function refresh() {
      const speaking = await readStatus();
      if (playbackDisposed || speaking === undefined) return;
      const key = playbackKey(speaking);
      const phase = key === null ? 'idle' : 'speaking';
      if (phase !== playbackState.phase || key !== playbackState.key || playbackState.error !== null) {
        patchPlayback({ phase, key, error: null });
      }
      if (key === null) stopPolling();
      else startPolling();
    }

    /** POST one action; reject with the host's message when it refuses. */
    async function post(body) {
      const response = await fetch(SPEAK_ROUTE, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body),
      });
      const payload = await response.json().catch(() => null);
      if (!response.ok || payload?.ok !== true) throw new Error(payload?.error ?? `HTTP ${response.status}`);
      return payload;
    }

    /**
     * Start reading one source.
     * @param body - the host request body.
     * @param key - the store identity this entry uses for that source.
     * @returns whether playback started.
     */
    async function start(body, key) {
      patchPlayback({ phase: 'pending', key, error: null });
      try {
        const payload = await post({ action: 'speak', ...body });
        if (playbackDisposed) return true;
        patchPlayback({ phase: 'speaking', key, error: null });
        startPolling();
        report('playback', { event: 'started', key, voices: payload?.voices, utterances: payload?.utterances });
        return true;
      } catch (error) {
        if (playbackDisposed) return false;
        patchPlayback({ phase: 'error', key, error: String(error?.message ?? error) });
        report('playback', { event: 'failed', key, error: String(error?.message ?? error) }, true);
        window.setTimeout(() => {
          if (!playbackDisposed && playbackState.phase === 'error' && playbackState.key === key) {
            patchPlayback({ phase: 'idle', error: null });
          }
        }, ERROR_RESET_MS);
        return false;
      }
    }

    /** Stop whatever is playing. */
    async function stop() {
      try {
        await post({ action: 'stop' });
      } catch {
        // A stop that cannot reach the host is reconciled by the next poll.
      }
      stopPolling();
      if (!playbackDisposed) patchPlayback({ phase: 'idle', key: null, error: null });
      report('playback', { event: 'stopped' });
    }

    function disposePlayback() {
      playbackDisposed = true;
      stopPolling();
      playbackListeners.clear();
    }

    const playback = {
      subscribe(listener) {
        playbackListeners.add(listener);
        return () => playbackListeners.delete(listener);
      },
      getState: () => playbackState,
      start,
      stop,
      refresh,
      supported: () => hostPlatform === null || hostPlatform === 'darwin',
    };
    //#endregion

    //#region settings store — per-language voices, rate, Han bias
    const settingsListeners = new Set();
    let settingsState = {
      open: false,
      loaded: false,
      saving: false,
      saved: false,
      error: null,
      settings: { voices: {}, rate: null, language: null },
      voices: {},
      defaults: { rate: 190 },
      range: { min: 80, max: 500 },
    };
    let settingsDisposed = false;

    const emitSettings = () => {
      for (const listener of [...settingsListeners]) listener();
    };
    const patchSettings = (next) => {
      settingsState = { ...settingsState, ...next };
      emitSettings();
    };

    /** Load preferences and the installed voice list from the host. */
    async function loadSettings() {
      try {
        const response = await fetch(SETTINGS_ROUTE, { headers: { accept: 'application/json' } });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const body = await response.json();
        if (settingsDisposed) return;
        patchSettings({
          loaded: true,
          error: null,
          settings: body.settings ?? settingsState.settings,
          voices: body.voices ?? settingsState.voices,
          defaults: body.defaults ?? settingsState.defaults,
          range: body.range ?? settingsState.range,
        });
        report('settings', {
          event: 'loaded',
          counts: Object.fromEntries(Object.entries(body.voices ?? {}).map(([key, list]) => [key, list.length])),
          current: body.settings,
        }, true);
      } catch (error) {
        if (!settingsDisposed) patchSettings({ error: String(error?.message ?? error) });
      }
    }

    /**
     * Persist one partial change and adopt the host's answer.
     * @param patch - fields to write: `voices`, `rate`, `language`.
     * @returns whether the host accepted it.
     */
    async function saveSettings(patch) {
      patchSettings({ saving: true, saved: false, error: null });
      try {
        const response = await fetch(SETTINGS_ROUTE, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(patch),
        });
        const body = await response.json().catch(() => null);
        if (!response.ok || body?.ok !== true) throw new Error(body?.error ?? `HTTP ${response.status}`);
        if (settingsDisposed) return false;
        patchSettings({
          saving: false,
          saved: true,
          error: null,
          settings: body.settings ?? settingsState.settings,
          voices: body.voices ?? settingsState.voices,
        });
        report('settings', { event: 'saved', patch, current: body.settings }, true);
        window.setTimeout(() => {
          if (!settingsDisposed && settingsState.saved) patchSettings({ saved: false });
        }, 2000);
        return true;
      } catch (error) {
        if (!settingsDisposed) patchSettings({ saving: false, saved: false, error: String(error?.message ?? error) });
        report('settings', { event: 'failed', patch, error: String(error?.message ?? error) }, true);
        return false;
      }
    }

    const settings = {
      subscribe(listener) {
        settingsListeners.add(listener);
        return () => settingsListeners.delete(listener);
      },
      getState: () => settingsState,
      load: loadSettings,
      save: saveSettings,
      open() {
        patchSettings({ open: true });
        if (!settingsState.loaded) void loadSettings();
      },
      close() {
        patchSettings({ open: false });
      },
      toggle() {
        if (settingsState.open) patchSettings({ open: false });
        else {
          patchSettings({ open: true });
          if (!settingsState.loaded) void loadSettings();
        }
      },
      dispose() {
        settingsDisposed = true;
        settingsListeners.clear();
      },
    };
    //#endregion

    //#region selection store — the floating "read the selection" affordance
    const selectionListeners = new Set();
    let selectionState = { visible: false, text: '', top: 0, left: 0, placement: 'above' };
    let selectionFrame = null;
    let selectionDisposed = false;

    const emitSelection = () => {
      for (const listener of [...selectionListeners]) listener();
    };
    const patchSelection = (next) => {
      selectionState = { ...selectionState, ...next };
      emitSelection();
    };
    const hideSelection = () => {
      if (selectionState.visible) patchSelection({ visible: false, text: '' });
    };

    /** Whether a selection sits inside an editable control, where a popover would fight the caret. */
    function insideEditable(node) {
      const element = node === null || node === undefined
        ? null
        : node.nodeType === 1
          ? node
          : node.parentElement ?? null;
      if (element === null || typeof element.closest !== 'function') return false;
      return element.closest('input, textarea, [contenteditable=""], [contenteditable="true"], [role="textbox"]') !== null;
    }

    /** Recompute the popover from the live document selection. */
    function updateSelection() {
      selectionFrame = null;
      if (selectionDisposed) return;
      const current = window.getSelection();
      if (current === null || current.isCollapsed || current.rangeCount === 0) {
        hideSelection();
        return;
      }
      const text = current.toString().trim();
      if (text === '' || text.length > SELECTION_LIMIT) {
        hideSelection();
        return;
      }
      if (insideEditable(current.anchorNode)) {
        hideSelection();
        return;
      }
      let rect;
      try {
        rect = current.getRangeAt(0).getBoundingClientRect();
      } catch {
        hideSelection();
        return;
      }
      if (rect.width === 0 && rect.height === 0) {
        hideSelection();
        return;
      }
      if (rect.bottom < 0 || rect.top > window.innerHeight) {
        hideSelection();
        return;
      }
      const above = rect.top > 52;
      const halfWidth = 84;
      const left = Math.min(Math.max(rect.left + rect.width / 2, halfWidth + 8), window.innerWidth - halfWidth - 8);
      patchSelection({
        visible: true,
        text,
        placement: above ? 'above' : 'below',
        top: above ? rect.top - 38 : rect.bottom + 10,
        left,
      });
      report('selection', {
        visible: true,
        length: text.length,
        placement: above ? 'above' : 'below',
        rect: [Math.round(rect.top), Math.round(rect.left), Math.round(rect.width), Math.round(rect.height)],
        viewport: [window.innerWidth, window.innerHeight],
      });
    }

    /** Coalesce selection events into one measurement per frame. */
    function scheduleSelection() {
      if (selectionFrame !== null || selectionDisposed) return;
      selectionFrame = window.requestAnimationFrame(updateSelection);
    }

    const selection = {
      subscribe(listener) {
        selectionListeners.add(listener);
        return () => selectionListeners.delete(listener);
      },
      getState: () => selectionState,
      schedule: scheduleSelection,
      dispose() {
        selectionDisposed = true;
        if (selectionFrame !== null) window.cancelAnimationFrame(selectionFrame);
        selectionListeners.clear();
      },
    };
    //#endregion

    /** Styles for every entry; theme tokens only, injected once per plugin load. */
    const CSS = `
.dsh-speak-action, .dsh-speak-icon-button, .dsh-speak-text-button {
  margin: 0; border: 0; background: transparent; color: inherit; font: inherit;
  display: inline-flex; align-items: center; justify-content: center;
  border-radius: var(--dsw-radius-sm, 6px); cursor: pointer;
  transition: background-color .12s ease, opacity .12s ease, color .12s ease;
}
.dsh-speak-action, .dsh-speak-icon-button { width: 22px; height: 22px; padding: 0; line-height: 0; opacity: .72; }
.dsh-speak-action:hover, .dsh-speak-icon-button:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(127,127,127,.14)); opacity: 1; }
.dsh-speak-action[data-state="speaking"], .dsh-speak-icon-button[data-state="speaking"] { opacity: 1; color: var(--dsw-alias-state-business-primary, currentColor); }
.dsh-speak-action[data-state="pending"] { opacity: 1; }
.dsh-speak-action[data-state="busy"] { opacity: .34; }
.dsh-speak-action[data-state="error"] { opacity: 1; color: var(--dsw-alias-state-error-primary, currentColor); }
.dsh-speak-action[disabled] { opacity: .28; cursor: default; }
.dsh-speak-action[disabled]:hover { background: transparent; }
.dsh-speak-action:focus-visible, .dsh-speak-icon-button:focus-visible, .dsh-speak-text-button:focus-visible,
.dsh-speak-popover button:focus-visible, .dsh-speak-panel select:focus-visible, .dsh-speak-panel input:focus-visible {
  outline: var(--dsw-focus-ring-width, 2px) solid var(--dsw-focus-ring-color, var(--dsw-alias-state-business-primary, currentColor));
  outline-offset: 2px;
}
.dsh-speak-popover {
  position: fixed; z-index: 24; transform: translateX(-50%);
  display: inline-flex; align-items: center; gap: 4px;
  padding: 4px 5px 4px 8px;
  border: .5px solid var(--dsw-alias-border-l2, rgba(127,127,127,.28));
  border-radius: var(--dsw-radius-sm, 8px);
  background: var(--dsw-alias-bg-layer-1, Canvas);
  color: var(--dsw-alias-label-primary, CanvasText);
  box-shadow: var(--dsw-elevation-panel, 0 6px 18px rgba(0,0,0,.18));
  font-size: 12px; line-height: 16px; white-space: nowrap;
}
.dsh-speak-popover[data-state="error"] { color: var(--dsw-alias-state-error-primary, CanvasText); }
.dsh-speak-selection-button { gap: 6px; padding: 0; margin: 0; border: 0; background: transparent; color: inherit; font: inherit; font-size: 12px; line-height: 16px; display: inline-flex; align-items: center; cursor: pointer; }
.dsh-speak-selection-button:hover { opacity: .78; }
.dsh-speak-panel {
  position: fixed; z-index: 26; right: 24px; bottom: 104px; width: 272px;
  display: flex; flex-direction: column; gap: 9px;
  padding: 12px 14px 12px;
  border: .5px solid var(--dsw-alias-border-l2, rgba(127,127,127,.28));
  border-radius: var(--dsw-radius-md, 10px);
  background: var(--dsw-alias-bg-layer-1, Canvas);
  color: var(--dsw-alias-label-primary, CanvasText);
  box-shadow: var(--dsw-elevation-prominent, 0 10px 30px rgba(0,0,0,.22));
  font-size: 12px; line-height: 16px;
}
.dsh-speak-panel-title { font-weight: 600; font-size: 13px; }
.dsh-speak-panel-row { display: flex; align-items: center; gap: 8px; }
.dsh-speak-panel-row > span:first-child { flex: 0 0 60px; color: var(--dsw-alias-label-secondary, inherit); }
.dsh-speak-panel select {
  flex: 1 1 auto; min-width: 0; font: inherit; color: inherit;
  background: var(--dsw-alias-bg-base, transparent);
  border: .5px solid var(--dsw-alias-border-l3, rgba(127,127,127,.35));
  border-radius: var(--dsw-radius-sm, 6px); padding: 3px 6px;
}
.dsh-speak-panel input[type="range"] { flex: 1 1 auto; min-width: 0; accent-color: var(--dsw-alias-state-business-primary, auto); }
.dsh-speak-panel-foot { display: flex; align-items: center; gap: 8px; margin-top: 2px; }
.dsh-speak-text-button {
  padding: 4px 10px; border: .5px solid var(--dsw-alias-border-l3, rgba(127,127,127,.35));
  background: var(--dsw-alias-interactive-bg-hover, rgba(127,127,127,.1)); opacity: 1;
}
.dsh-speak-note { color: var(--dsw-alias-label-tertiary, inherit); margin-left: auto; }
.dsh-speak-note[data-tone="error"] { color: var(--dsw-alias-state-error-primary, inherit); }
.dsh-speak-stop-pill {
  position: fixed; z-index: 25; right: 24px;
  display: inline-flex; align-items: center; gap: 6px;
  padding: 5px 12px 5px 9px; font-family: inherit;
  border: .5px solid var(--dsw-alias-border-l2, rgba(127,127,127,.28));
  border-radius: var(--dsw-radius-sm, 8px);
  background: var(--dsw-alias-bg-layer-1, Canvas);
  color: var(--dsw-alias-label-primary, CanvasText);
  box-shadow: var(--dsw-elevation-panel, 0 6px 18px rgba(0,0,0,.18));
  font-size: 12px; line-height: 16px; white-space: nowrap; cursor: pointer;
}
.dsh-speak-stop-pill:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(127,127,127,.14)); }
.dsh-speak-stop-pill:focus-visible { outline: var(--dsw-focus-ring-width, 2px) solid var(--dsw-focus-ring-color, currentColor); outline-offset: 2px; }
.dsh-speak-stop-pill[data-source="message"] { color: var(--dsw-alias-state-business-primary, currentColor); }
.dsh-speak-arc { transform-origin: center; }
.dsh-speak-action[data-state="speaking"] .dsh-speak-arc,
.dsh-speak-icon-button[data-state="speaking"] .dsh-speak-arc,
.dsh-speak-popover[data-state="speaking"] .dsh-speak-arc { animation: dsh-speak-pulse 1.1s ease-in-out infinite; }
.dsh-speak-arc-2 { animation-delay: .18s; }
@keyframes dsh-speak-pulse { 0%, 100% { opacity: .28 } 50% { opacity: 1 } }
@media (prefers-reduced-motion: reduce) { .dsh-speak-arc { animation: none } }
`;

    /** Locale dictionaries; simplified Chinese is the key-set source. */
    const zh = {
      'action.speak': '朗读这条回复',
      'action.stop': '停止朗读',
      'action.pending': '正在开始…',
      'action.speaking': '正在朗读，点击停止',
      'action.busy': '正在朗读另一条内容，点击改为朗读这条',
      'action.error': '朗读失败，点击重试',
      'action.unsupported': '当前系统不支持朗读（仅支持 macOS）',
      'selection.speak': '朗读选中内容',
      'selection.stop': '停止朗读',
      'selection.pending': '正在开始…',
      'selection.error': '朗读失败，点击重试',
      'selection.settings': '朗读设置',
      'stop.pill': '停止朗读',
      'stop.pending': '正在开始…',
      'settings.open': '朗读设置',
      'settings.title': '朗读设置',
      'settings.auto': '自动',
      'settings.rate': '语速',
      'settings.han': '汉字优先',
      'settings.preview': '试听',
      'settings.saving': '保存中…',
      'settings.saved': '已保存',
      'settings.failed': '保存失败',
      'settings.loading': '加载中…',
    };
    const en = {
      'action.speak': 'Read this reply aloud',
      'action.stop': 'Stop reading',
      'action.pending': 'Starting…',
      'action.speaking': 'Reading aloud — click to stop',
      'action.busy': 'Reading something else — click to read this instead',
      'action.error': 'Reading failed — click to retry',
      'action.unsupported': 'Reading aloud is not supported on this system (macOS only)',
      'selection.speak': 'Read selection aloud',
      'selection.stop': 'Stop reading',
      'selection.pending': 'Starting…',
      'selection.error': 'Reading failed — click to retry',
      'selection.settings': 'Reading settings',
      'stop.pill': 'Stop reading',
      'stop.pending': 'Starting…',
      'settings.open': 'Reading settings',
      'settings.title': 'Reading settings',
      'settings.auto': 'Auto',
      'settings.rate': 'Rate',
      'settings.han': 'Bare Han is',
      'settings.preview': 'Preview',
      'settings.saving': 'Saving…',
      'settings.saved': 'Saved',
      'settings.failed': 'Save failed',
      'settings.loading': 'Loading…',
    };

    /** Fall back to the key itself when the slot handed no translate function. */
    const translator = (t) => (typeof t === 'function' ? t : (key) => key);

    /**
     * Self-correct a `position: fixed` overlay against a transformed ancestor.
     *
     * The overlay layer sits inside the application frame; if any ancestor
     * carries a transform, `fixed` is measured against that ancestor instead of
     * the viewport and the element lands somewhere else. Rather than guess which
     * ancestor it is, measure where the element actually rendered and shift it by
     * the residual, which converges in one or two passes.
     *
     * @param active - whether the element is on screen.
     * @param target - `{ x, y }` the element should land on, in viewport pixels.
     * @param align - `center` compares the element's horizontal centre, `right` its right edge.
     * @param vertical - `top` compares the element's top edge, `bottom` its bottom edge.
     * @returns the ref to attach plus the translation to add.
     */
    function useViewportCorrection(active, target, align = 'center', vertical = 'top') {
      const ref = React.useRef(null);
      const [shift, setShift] = React.useState({ x: 0, y: 0 });
      React.useLayoutEffect(() => {
        if (!active || ref.current === null) return;
        const box = ref.current.getBoundingClientRect();
        if (box.width === 0 && box.height === 0) return;
        const actualX = align === 'right' ? box.right : box.left + box.width / 2;
        const actualY = vertical === 'bottom' ? box.bottom : box.top;
        const dx = Math.round(target.x - actualX);
        const dy = Math.round(target.y - actualY);
        if (Math.abs(dx) < 3 && Math.abs(dy) < 3) return;
        if (Math.abs(shift.x + dx) > 4000 || Math.abs(shift.y + dy) > 4000) return;
        setShift((previous) => ({ x: previous.x + dx, y: previous.y + dy }));
      });
      return [ref, shift];
    }

    /** The first ancestor whose transform would break `position: fixed`, for diagnostics. */
    function transformAncestor(element) {
      let node = element === null || element === undefined ? null : element.parentElement;
      let depth = 0;
      while (node !== null && depth < 30) {
        const style = window.getComputedStyle(node);
        if (style.transform !== 'none' || style.perspective !== 'none' || style.filter !== 'none' || style.willChange.includes('transform')) {
          return `${node.tagName.toLowerCase()}.${String(node.className).slice(0, 40)} ${style.transform} ${style.perspective !== 'none' ? 'perspective ' : ''}${style.filter !== 'none' ? 'filter ' : ''}`;
        }
        node = node.parentElement;
        depth += 1;
      }
      return null;
    }

    /**
     * Report a slot entry's render error instead of letting it vanish silently: a
     * slot entry that throws renders nothing and otherwise leaves no trace.
     */
    class SpeakBoundary extends React.Component {
      constructor(props) {
        super(props);
        this.state = { error: null };
      }

      static getDerivedStateFromError(error) {
        return { error: String(error?.message ?? error) };
      }

      componentDidCatch(error, info) {
        report('error', {
          entry: this.props.entry,
          error: String(error?.message ?? error),
          stack: String(info?.componentStack ?? '').slice(0, 300),
        }, true);
      }

      render() {
        if (this.state.error !== null) return null;
        return this.props.children;
      }
    }

    /**
     * Wrap one slot component in the reporting boundary.
     * @param entry - entry name for diagnostics.
     * @param Component - the component to guard.
     * @returns a component that mounts the guarded one.
     */
    function guarded(entry, Component) {
      return function Guarded(props) {
        return h(SpeakBoundary, { entry }, h(Component, props));
      };
    }

    /** The speaker artwork; `animated` pulses the arcs while audio plays. */
    function SpeakerGlyph({ animated }) {
      const arc = (d, extraClass) => h('path', {
        d,
        className: animated ? `dsh-speak-arc ${extraClass}` : undefined,
        fill: 'none',
        stroke: 'currentColor',
        strokeWidth: 1.3,
        strokeLinecap: 'round',
      });
      return h('svg', {
        width: 14,
        height: 14,
        viewBox: '0 0 16 16',
        'aria-hidden': true,
        focusable: false,
      },
        h('path', { d: 'M8 1.6 4.7 4.4H1.9v7.2h2.8L8 14.4V1.6Z', fill: 'currentColor' }),
        arc('M10.6 5.3a3.9 3.9 0 0 1 0 5.4', 'dsh-speak-arc-1'),
        arc('M12.7 3.1a7 7 0 0 1 0 9.8', 'dsh-speak-arc-2'));
    }

    /** Speaker with a gear, for the settings entry in the composer dock. */
    function GearGlyph() {
      return h('svg', {
        width: 15,
        height: 15,
        viewBox: '0 0 16 16',
        'aria-hidden': true,
        focusable: false,
      },
        h('path', { d: 'M7.4 1.6 4.2 4.3H1.6v7.4h2.6l3.2 2.7V1.6Z', fill: 'currentColor' }),
        h('path', {
          d: 'M10.1 5.9a3 3 0 0 1 0 4.2',
          fill: 'none',
          stroke: 'currentColor',
          strokeWidth: 1.2,
          strokeLinecap: 'round',
        }),
        h('circle', { cx: 12.4, cy: 8, r: 1.9, fill: 'none', stroke: 'currentColor', strokeWidth: 1.2 }));
    }

    /** Per-message speaker action in the assistant action strip. */
    function MessageSpeakAction({ messageId, sessionId, t }) {
      const tr = translator(t);
      const current = React.useSyncExternalStore(playback.subscribe, playback.getState);
      const key = `msg:${String(sessionId)}:${String(messageId)}`;
      const mine = current.key === key;
      const playing = mine && current.phase === 'speaking';
      const pending = mine && current.phase === 'pending';
      const failed = mine && current.phase === 'error';
      const supported = playback.supported();
      const state = !supported
        ? 'unsupported'
        : playing
          ? 'speaking'
          : pending
            ? 'pending'
            : failed
              ? 'error'
              : current.phase === 'speaking' || current.phase === 'pending'
                ? 'busy'
                : 'idle';
      const label = {
        unsupported: tr('action.unsupported'),
        speaking: tr('action.stop'),
        pending: tr('action.pending'),
        error: tr('action.error'),
        busy: tr('action.busy'),
        idle: tr('action.speak'),
      }[state];
      const onClick = React.useCallback(() => {
        if (playing) {
          void playback.stop();
          return;
        }
        if (pending || !playback.supported()) return;
        void playback.start({ sessionId, messageId }, key);
      }, [playing, pending, key, sessionId, messageId]);
      return h('button', {
        type: 'button',
        className: 'dsh-speak-action',
        'data-state': state,
        title: label,
        'aria-label': label,
        'aria-pressed': playing,
        'aria-busy': pending,
        disabled: state === 'unsupported',
        onClick,
      }, h(SpeakerGlyph, { animated: playing }));
    }

    /** Floating button over the current selection, in the root overlay layer. */
    function SelectionSpeak({ t }) {
      const tr = translator(t);
      const current = React.useSyncExternalStore(playback.subscribe, playback.getState);
      const selected = React.useSyncExternalStore(selection.subscribe, selection.getState);
      const [ref, shift] = useViewportCorrection(selected.visible, { x: selected.left, y: selected.top });
      const lastReport = React.useRef('');
      const onClick = React.useCallback(async () => {
        const mine = current.key === 'selection';
        const playing = mine && current.phase === 'speaking';
        const pending = mine && current.phase === 'pending';
        if (playing) {
          void playback.stop();
          return;
        }
        if (pending) return;
        // Keep the popover: the same button becomes "stop reading".
        await playback.start({ text: selected.text }, 'selection');
      }, [selected.text, current.phase, current.key]);
      React.useEffect(() => {
        report('mounted', { entry: 'selection-popover' }, true);
      }, []);
      React.useEffect(() => {
        report('visibility', { entry: 'selection-popover', visible: selected.visible, length: selected.text.length }, true);
      }, [selected.visible, selected.text.length]);
      React.useLayoutEffect(() => {
        if (!selected.visible || ref.current === null) return;
        const box = ref.current.getBoundingClientRect();
        const key = `${Math.round(box.top)}:${Math.round(box.left)}:${shift.x}:${shift.y}`;
        if (lastReport.current === key) return;
        lastReport.current = key;
        report('rendered', {
          entry: 'selection-popover',
          box: [Math.round(box.top), Math.round(box.left), Math.round(box.width), Math.round(box.height)],
          intended: [selected.top, selected.left],
          shift,
          viewport: [window.innerWidth, window.innerHeight],
          transformAncestor: transformAncestor(ref.current),
          insideViewport: box.top >= 0 && box.left >= 0 && box.bottom <= window.innerHeight && box.right <= window.innerWidth,
        }, true);
      }, [selected.visible, selected.top, selected.left, shift.x, shift.y]);
      // Every hook runs before this return; the values below are plain derivations.
      if (!selected.visible) return null;
      const mine = current.key === 'selection';
      const playing = mine && current.phase === 'speaking';
      const pending = mine && current.phase === 'pending';
      const failed = mine && current.phase === 'error';
      const state = failed ? 'error' : playing ? 'speaking' : pending ? 'pending' : 'idle';
      const label = {
        error: tr('selection.error'),
        speaking: tr('selection.stop'),
        pending: tr('selection.pending'),
        idle: tr('selection.speak'),
      }[state];
      return h('div', {
        ref,
        className: 'dsh-speak-popover',
        'data-state': state,
        'data-placement': selected.placement,
        style: {
          top: selected.top,
          left: selected.left,
          transform: `translate(calc(-50% + ${shift.x}px), ${shift.y}px)`,
        },
      },
      h('button', {
        type: 'button',
        className: 'dsh-speak-selection-button',
        title: label,
        'aria-label': label,
        'aria-pressed': playing,
        'aria-busy': pending,
        onClick,
      }, h(SpeakerGlyph, { animated: playing }), h('span', null, label)),
      h('button', {
        type: 'button',
        className: 'dsh-speak-icon-button',
        title: tr('selection.settings'),
        'aria-label': tr('selection.settings'),
        onClick: () => settings.open(),
      }, h(GearGlyph)));
    }

    /** Settings panel, in the root overlay so the composer cannot clip it. */
    function SettingsPanel({ t }) {
      const tr = translator(t);
      const config = React.useSyncExternalStore(settings.subscribe, settings.getState);
      const [rateDraft, setRateDraft] = React.useState(null);
      const rateTimer = React.useRef(null);
      const [panelRef, panelShift] = useViewportCorrection(
        config.open,
        { x: window.innerWidth - 24, y: window.innerHeight - 104 },
        'right',
        'bottom',
      );
      const lastPanelReport = React.useRef('');
      React.useEffect(() => () => {
        if (rateTimer.current !== null) window.clearTimeout(rateTimer.current);
      }, []);
      React.useLayoutEffect(() => {
        if (!config.open || panelRef.current === null) return;
        const box = panelRef.current.getBoundingClientRect();
        const key = `${Math.round(box.top)}:${Math.round(box.left)}`;
        if (lastPanelReport.current === key) return;
        lastPanelReport.current = key;
        report('rendered', {
          entry: 'settings-panel',
          box: [Math.round(box.top), Math.round(box.left), Math.round(box.width), Math.round(box.height)],
          shift: panelShift,
          viewport: [window.innerWidth, window.innerHeight],
          transformAncestor: transformAncestor(panelRef.current),
          insideViewport: box.top >= 0 && box.left >= 0 && box.bottom <= window.innerHeight && box.right <= window.innerWidth,
        }, true);
      }, [config.open, panelShift.x, panelShift.y]);
      if (!config.open) return null;
      const shown = rateDraft ?? config.settings.rate ?? config.defaults.rate;
      const note = config.error !== null
        ? { text: config.error, tone: 'error' }
        : config.saving
          ? { text: tr('settings.saving'), tone: 'muted' }
          : config.saved
            ? { text: tr('settings.saved'), tone: 'muted' }
            : config.loaded
              ? null
              : { text: tr('settings.loading'), tone: 'muted' };
      const onRate = (event) => {
        const value = Number(event.target.value);
        setRateDraft(value);
        if (rateTimer.current !== null) window.clearTimeout(rateTimer.current);
        rateTimer.current = window.setTimeout(() => {
          rateTimer.current = null;
          void settings.save({ rate: value }).then(() => setRateDraft(null));
        }, 350);
      };
      return h('div', {
        ref: panelRef,
        className: 'dsh-speak-panel',
        role: 'dialog',
        'aria-label': tr('settings.title'),
        style: { transform: `translate(${panelShift.x}px, ${panelShift.y}px)` },
      },
        h('div', { className: 'dsh-speak-panel-title' }, tr('settings.title')),
        ...LANGUAGE_ROWS.map(([code, name]) => h('label', { key: code, className: 'dsh-speak-panel-row' },
          h('span', null, name),
          h('select', {
            value: config.settings.voices?.[code] ?? '',
            onChange: (event) => {
              const value = event.target.value;
              void settings.save({ voices: { [code]: value === '' ? null : value } });
            },
          },
          h('option', { value: '' }, tr('settings.auto')),
          ...(config.voices?.[code] ?? []).map((voice) => h('option', { key: voice, value: voice }, voice))))),
        h('label', { className: 'dsh-speak-panel-row' },
          h('span', null, tr('settings.rate')),
          h('input', {
            type: 'range',
            min: config.range.min,
            max: config.range.max,
            step: 5,
            value: shown,
            'aria-label': tr('settings.rate'),
            onChange: onRate,
          }),
          h('span', { className: 'dsh-speak-note' }, String(shown))),
        h('label', { className: 'dsh-speak-panel-row' },
          h('span', null, tr('settings.han')),
          h('select', {
            value: config.settings.language ?? '',
            onChange: (event) => {
              const value = event.target.value;
              void settings.save({ language: value === '' ? null : value });
            },
          },
          h('option', { value: '' }, tr('settings.auto')),
          h('option', { value: 'zh' }, '中文'),
          h('option', { value: 'ja' }, '日文'))),
        h('div', { className: 'dsh-speak-panel-foot' },
          h('button', {
            type: 'button',
            className: 'dsh-speak-text-button',
            onClick: () => void playback.start({ text: PREVIEW_TEXT }, 'selection'),
          }, tr('settings.preview')),
          h('button', {
            type: 'button',
            className: 'dsh-speak-text-button',
            onClick: () => settings.close(),
          }, '✕'),
          note === null ? null : h('span', { className: 'dsh-speak-note', 'data-tone': note.tone }, note.text)));
    }

    /** Speaker-gear button in the composer dock; opens the settings panel. */
    function SettingsDock({ t }) {
      const tr = translator(t);
      const config = React.useSyncExternalStore(settings.subscribe, settings.getState);
      const label = tr('settings.open');
      return h('button', {
        type: 'button',
        className: 'dsh-speak-icon-button',
        title: label,
        'aria-label': label,
        'aria-expanded': config.open,
        'data-state': config.open ? 'speaking' : 'idle',
        onClick: () => settings.toggle(),
      }, h(GearGlyph));
    }

    /**
     * Always-on stop control while anything is being read, whoever started it —
     * a selection, a message, the preview, or the agent's `speak` tool.
     */
    function StopPill({ t }) {
      const tr = translator(t);
      const current = React.useSyncExternalStore(playback.subscribe, playback.getState);
      const config = React.useSyncExternalStore(settings.subscribe, settings.getState);
      const active = current.phase === 'speaking' || current.phase === 'pending';
      // Keep clear of the settings panel when it is open.
      const bottom = config.open ? 396 : 152;
      const [ref, shift] = useViewportCorrection(active, { x: window.innerWidth - 24, y: window.innerHeight - bottom }, 'right', 'bottom');
      const lastReport = React.useRef('');
      React.useEffect(() => {
        report('visibility', { entry: 'stop-pill', visible: active }, true);
      }, [active]);
      React.useLayoutEffect(() => {
        if (!active || ref.current === null) return;
        const box = ref.current.getBoundingClientRect();
        const key = `${Math.round(box.top)}:${Math.round(box.left)}:${shift.x}:${shift.y}`;
        if (lastReport.current === key) return;
        lastReport.current = key;
        report('rendered', {
          entry: 'stop-pill',
          box: [Math.round(box.top), Math.round(box.left), Math.round(box.width), Math.round(box.height)],
          shift,
          viewport: [window.innerWidth, window.innerHeight],
          transformAncestor: transformAncestor(ref.current),
          insideViewport: box.top >= 0 && box.left >= 0 && box.bottom <= window.innerHeight && box.right <= window.innerWidth,
        }, true);
      }, [active, bottom, shift.x, shift.y]);
      if (!active) return null;
      const label = current.phase === 'pending' ? tr('stop.pending') : tr('stop.pill');
      return h('button', {
        ref,
        type: 'button',
        className: 'dsh-speak-stop-pill',
        'data-source': current.key === null ? 'other' : current.key.startsWith('msg:') ? 'message' : 'selection',
        title: label,
        'aria-label': label,
        style: { bottom: `${bottom}px`, transform: `translate(${shift.x}px, ${shift.y}px)` },
        onClick: () => void playback.stop(),
      }, h(SpeakerGlyph, { animated: true }), h('span', null, label));
    }

    return {
      inject: ['slots', 'locale'],
      /**
       * Register every entry and own the stores' DOM lifetimes.
       * @param ctx - the client plugin context.
       */
      apply(ctx) {
        ctx.effect(() => ctx.locale.register('dsh-speak', { zh, en }), 'dsh-speak: dictionaries');
        ctx.effect(() => {
          report('hello', {
            entries: ['assistant-actions', 'selection-overlay', 'composer-settings', 'settings-panel'],
            overlaySlot: 'shell.overlay',
            dockSlot: 'conversation.composer.dock',
            href: String(window.location.href),
            hasSelectionApi: typeof window.getSelection === 'function',
          }, true);
          void playback.refresh();
          void settings.load();
        }, 'dsh-speak: client hello');
        ctx.effect(() => () => {
          disposePlayback();
          selection.dispose();
          settings.dispose();
        }, 'dsh-speak: store lifetime');
        ctx.effect(() => {
          const onSelectionEvent = () => selection.schedule();
          document.addEventListener('selectionchange', onSelectionEvent);
          window.addEventListener('mouseup', onSelectionEvent, true);
          window.addEventListener('keyup', onSelectionEvent, true);
          window.addEventListener('scroll', onSelectionEvent, true);
          window.addEventListener('resize', onSelectionEvent);
          const style = document.createElement('style');
          style.setAttribute('data-dsh-speak', '');
          style.textContent = CSS;
          document.head.append(style);
          report('style', { injected: true }, true);
          return () => {
            document.removeEventListener('selectionchange', onSelectionEvent);
            window.removeEventListener('mouseup', onSelectionEvent, true);
            window.removeEventListener('keyup', onSelectionEvent, true);
            window.removeEventListener('scroll', onSelectionEvent, true);
            window.removeEventListener('resize', onSelectionEvent);
            style.remove();
          };
        }, 'dsh-speak: selection tracking');
        ctx.effect(() => {
          // Slow heartbeat: a reading started from the agent or another tab still
          // shows the stop control here.
          const timer = window.setInterval(() => void playback.refresh(), IDLE_POLL_MS);
          return () => window.clearInterval(timer);
        }, 'dsh-speak: idle heartbeat');
        ctx.inject(['shortcuts'], (scope) => {
          scope.effect(() => scope.shortcuts.register({
            id: 'speak.stop',
            label: () => 'Stop reading aloud',
            aliases: ['stop reading', '停止朗读', '朗读中止'],
            defaults: {
              'desktop:macos': { code: 'KeyS', modifiers: ['primary', 'shift'] },
              'desktop:windows': { code: 'KeyS', modifiers: ['primary', 'shift'] },
              'desktop:linux': { code: 'KeyS', modifiers: ['primary', 'shift'] },
              'web:macos': { code: 'KeyS', modifiers: ['primary', 'shift'] },
              'web:windows': { code: 'KeyS', modifiers: ['primary', 'shift'] },
              'web:linux': { code: 'KeyS', modifiers: ['primary', 'shift'] },
            },
            regions: ['page', 'editable'],
            modals: [],
            resolve: () => ({
              status: 'handled',
              run: () => {
                void playback.stop();
              },
            }),
          }), 'dsh-speak: stop shortcut');
        });
        ctx.slots.inject('conversation.chat.assistant-actions', () => ctx.slots.register({
          name: 'conversation.chat.assistant-actions',
          id: 'speak',
          order: 20,
          locale: 'dsh-speak',
        }, guarded('assistant-actions', MessageSpeakAction)));
        // Both overlay entries come from ONE injection: a second inject for the
        // same slot replaces the first registration instead of adding to it.
        ctx.slots.inject('shell.overlay', function* () {
          yield ctx.slots.register({
            name: 'shell.overlay',
            id: 'speak-selection',
            order: 50,
            locale: 'dsh-speak',
          }, guarded('selection-popover', SelectionSpeak));
          yield ctx.slots.register({
            name: 'shell.overlay',
            id: 'speak-settings',
            order: 51,
            locale: 'dsh-speak',
          }, guarded('settings-panel', SettingsPanel));
          yield ctx.slots.register({
            name: 'shell.overlay',
            id: 'speak-stop-pill',
            order: 52,
            locale: 'dsh-speak',
          }, guarded('stop-pill', StopPill));
        });
        ctx.slots.inject('conversation.composer.dock', () => ctx.slots.register({
          name: 'conversation.composer.dock',
          id: 'speak-settings-dock',
          order: 40,
          locale: 'dsh-speak',
        }, guarded('composer-dock', SettingsDock)));
      },
    };
  },
});
