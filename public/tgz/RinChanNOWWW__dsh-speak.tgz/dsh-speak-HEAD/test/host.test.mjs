// Offline exercise of the dsh-speak host half with stub services.
//
// It needs no DeepSeek Harness install: the tool registry, session store, and web
// server are stubs. It does spawn the real `say` command, so running it makes
// noise — keep the texts short, as they are here.
//
// Regression focus: every language run is its own `say` process with its own
// `-v`, never an inline `[[voice:...]]` command (macOS `say` has no such
// command and reads it out as literal text).
//
// Run with: pnpm install && pnpm test
import assert from 'node:assert/strict';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

// Point the plugin's settings file at a throwaway home before importing it.
process.env.DSH_HOME = mkdtempSync(join(tmpdir(), 'dsh-speak-test-'));

const { apply } = await import('../index.js');

let registered;
const routes = new Map();

const sessionStore = {
  get(id) {
    if (id !== 'session-demo') return undefined;
    return {
      snapshotEvents: () => [
        { type: 'user/message', data: { content: [{ type: 'text', text: 'hi' }] } },
        { type: 'assistant/message', data: { message: { id: 'msg-1', content: [{ type: 'text', text: '第一条回复。' }] } } },
        {
          type: 'assistant/message',
          data: {
            message: {
              id: 'msg-2',
              content: [
                { type: 'reasoning', text: 'hidden' },
                { type: 'text', text: '**第二条**回复，带 `代码` 和 [链接](https://example.com)。' },
              ],
            },
          },
        },
      ],
    };
  },
};

const ctx = {
  tools: { register(tool) { registered = tool; } },
  effect(fn) { return fn(); },
  inject(names, callback) {
    if (names.includes('webServer')) {
      callback({
        webServer: { register(route) { routes.set(route.path, route); } },
        effect(fn) { return fn(); },
        get: ctx.get,
      });
    }
  },
  get(name) {
    return name === 'sessions' ? sessionStore : undefined;
  },
};

apply(ctx);

function fakeRequest(method, body) {
  const payload = body === undefined ? undefined : Buffer.from(JSON.stringify(body), 'utf8');
  return {
    method,
    headers: payload === undefined ? {} : { 'content-type': 'application/json' },
    async *[Symbol.asyncIterator]() { if (payload !== undefined) yield payload; },
  };
}
function fakeResponse() {
  return {
    statusCode: 0,
    headers: {},
    body: '',
    setHeader(k, v) { this.headers[k] = v; },
    end(chunk) { this.body = chunk ?? ''; },
  };
}
const post = async (body) => {
  const res = fakeResponse();
  await routes.get('/api/dsh-speak').handler(fakeRequest('POST', body), res);
  return { status: res.statusCode, body: JSON.parse(res.body) };
};
const status = async (method = 'GET') => {
  const res = fakeResponse();
  await routes.get('/api/dsh-speak/status').handler(fakeRequest(method), res);
  return { status: res.statusCode, body: res.body === '' ? null : JSON.parse(res.body) };
};

const settings = async (method = 'GET', body) => {
  const res = fakeResponse();
  await routes.get('/api/dsh-speak/settings').handler(fakeRequest(method, body), res);
  return { status: res.statusCode, body: res.body === '' || res.body === undefined ? null : JSON.parse(res.body) };
};
const client = async (method = 'GET', body) => {
  const res = fakeResponse();
  await routes.get('/api/dsh-speak/client').handler(fakeRequest(method, body), res);
  return { status: res.statusCode, body: res.body === '' || res.body === undefined ? null : JSON.parse(res.body) };
};

// ---- registration shape -------------------------------------------------
assert.equal(registered.name, 'speak');
assert.ok(registered.parameters?.properties?.stop, 'stop parameter exists');
assert.deepEqual(registered.output.schema.properties.action.enum, ['speak', 'stop']);
assert.ok(registered.output.schema.properties.voices, 'output reports every voice used');
assert.equal(routes.size, 4, 'action + status + settings + client routes registered');
console.log('[ok] registration:', [...routes.keys()].join(' , '));

// ---- four-language text becomes four single-voice utterances -----------
const mixed = await registered.execute({
  text: '**你好**，这是 `DSH` 朗读测试。Hello, this is a test. こんにちは。안녕하세요.',
  rate: 500,
});
assert.equal(mixed.action, 'speak');
assert.equal(mixed.playing, true, 'playback runs right after the call');
assert.deepEqual([...mixed.languages].sort(), ['en', 'ja', 'ko', 'zh']);
// Script runs are zh, DSH(en), zh, en sentence, ja, ko; the 3-character Latin run
// is folded into the Chinese around it, so four utterances remain.
assert.equal(mixed.utterances, 4, 'short Latin fragments do not become their own utterance');
assert.deepEqual(mixed.voices, ['Tingting', 'Samantha', 'Kyoko', 'Yuna'], 'distinct voices used');
assert.deepEqual(mixed.sequence.map((step) => `${step.language}:${step.voice}`), ['zh:Tingting', 'en:Samantha', 'ja:Kyoko', 'ko:Yuna'], 'one voice per remaining run, in order');
assert.ok(!mixed.preview.includes('**') && !mixed.preview.includes('`'), 'markdown stripped');
console.log('[ok] tool speak ->', JSON.stringify({ characters: mixed.characters, utterances: mixed.utterances, voices: mixed.voices }));

const live = await status();
assert.ok(live.body.speaking !== null, 'status reports the live reading');
assert.equal(live.body.speaking.source, 'text');
assert.equal(live.body.speaking.utterances, 4);
assert.equal(live.body.speaking.current, 1, 'first utterance is the one playing');
assert.deepEqual(live.body.speaking.sequence.map((step) => step.voice), ['Tingting', 'Samantha', 'Kyoko', 'Yuna']);
assert.equal(live.body.platform, process.platform);
console.log('[ok] GET status while playing ->', JSON.stringify({ current: live.body.speaking.current, utterances: live.body.speaking.utterances, voices: live.body.speaking.voices }));

// ---- single-language text stays one utterance / one voice --------------
const single = await registered.execute({ text: '纯中文的一句话，不再切音色。', rate: 500 });
assert.equal(single.utterances, 1);
assert.deepEqual(single.voices, ['Tingting']);

// A long English sentence inside Chinese keeps the English voice.
const kept = await registered.execute({ text: '中文开头。This English sentence is long enough to keep its own voice.中文结尾。', rate: 500 });
assert.equal(kept.utterances, 3, 'a substantial English run stays English');
assert.deepEqual(kept.sequence.map((step) => step.voice), ['Tingting', 'Samantha', 'Tingting']);
console.log('[ok] long English run kept ->', JSON.stringify(kept.sequence.map((step) => step.voice)));
await registered.execute({ stop: true });
console.log('[ok] single-language ->', JSON.stringify({ utterances: single.utterances, voices: single.voices }));
await registered.execute({ stop: true });

// ---- language biases, voice forces -------------------------------------
// language=zh must NOT swallow the English run into the Chinese voice.
const biased = await registered.execute({ text: '中文部分 and English part here.', language: 'zh', rate: 500 });
assert.equal(biased.utterances, 2, 'language keeps other scripts on their own voices');
assert.deepEqual(biased.voices, ['Tingting', 'Samantha']);
console.log('[ok] language bias ->', JSON.stringify({ utterances: biased.utterances, voices: biased.voices }));
await registered.execute({ stop: true });

// language=ja reads bare Han characters with the Japanese voice.
const hanBias = await registered.execute({ text: '漢字だけの文です', language: 'ja', rate: 500 });
assert.equal(hanBias.utterances, 1);
assert.deepEqual(hanBias.voices, ['Kyoko']);
console.log('[ok] language=ja for bare Han ->', JSON.stringify({ voices: hanBias.voices }));
await registered.execute({ stop: true });

// voice alone collapses everything into one utterance.
const forcedVoice = await registered.execute({ text: 'Mixed 中文 and English here.', voice: 'Tingting', rate: 500 });
assert.equal(forcedVoice.utterances, 1, 'voice reads the whole text in one voice');
assert.deepEqual(forcedVoice.voices, ['Tingting']);
console.log('[ok] forced voice ->', JSON.stringify({ utterances: forcedVoice.utterances, voices: forcedVoice.voices }));
await registered.execute({ stop: true });

// ---- wait drains the whole queue ---------------------------------------
const waited = await registered.execute({ text: '短句。', rate: 500, wait: true });
assert.equal(waited.playing, false, 'wait resolves only after the last utterance');
assert.equal((await status()).body.speaking, null);
console.log('[ok] wait ->', JSON.stringify({ playing: waited.playing }));

// ---- stop reports what it interrupted, then nothing --------------------
const running = await registered.execute({ text: '第一条。第二条。', rate: 500 });
assert.equal(running.playing, true);
const stopped = await registered.execute({ stop: true });
assert.equal(stopped.action, 'stop');
assert.equal(stopped.playing, false);
assert.ok(stopped.characters > 0, 'stop reports the interrupted reading');
assert.ok(stopped.voices.length > 0, 'stop reports the voices in use');
console.log('[ok] tool stop ->', JSON.stringify({ characters: stopped.characters, voices: stopped.voices }));
const stoppedAgain = await registered.execute({ stop: true });
assert.equal(stoppedAgain.characters, 0, 'second stop has nothing to stop');
assert.equal((await status()).body.speaking, null, 'status is empty after stopping');
await assert.rejects(() => registered.execute({}), /text|required/i);
console.log('[ok] tool stop twice + empty-request rejection');

// ---- route: explicit text, then stop -----------------------------------
const viaRoute = await post({ text: '这是 DSH 的混合 English 文本。', rate: 500 });
assert.equal(viaRoute.status, 200);
assert.equal(viaRoute.body.speaking.source, 'text');
// zh / DSH(en) / zh / English(en) / zh — both short Latin runs fold into the Chinese.
assert.equal(viaRoute.body.speaking.utterances, 1, 'short Latin fragments fold into the surrounding language');
assert.deepEqual(viaRoute.body.speaking.voices, ['Tingting']);
console.log('[ok] POST text ->', JSON.stringify({ utterances: viaRoute.body.utterances, voices: viaRoute.body.voices }));

const stoppedRoute = await post({ action: 'stop' });
assert.equal(stoppedRoute.status, 200);
assert.equal(stoppedRoute.body.stopped, true);
assert.equal(stoppedRoute.body.speaking, null);
console.log('[ok] POST stop ->', JSON.stringify(stoppedRoute.body));

// ---- route: session message resolution (the message button path) -------
const exact = await post({ sessionId: 'session-demo', messageId: 'msg-2', rate: 500 });
assert.equal(exact.status, 200);
assert.equal(exact.body.messageId, 'msg-2', 'resolved the requested message');
assert.equal(exact.body.speaking.messageId, 'msg-2', 'status carries the message identity');
assert.equal(exact.body.speaking.source, 'message');
console.log('[ok] POST exact message ->', JSON.stringify({ messageId: exact.body.messageId, source: exact.body.speaking.source }));
await post({ action: 'stop' });

const newest = await post({ sessionId: 'session-demo', rate: 500 });
assert.equal(newest.body.messageId, 'msg-2', 'newest assistant message without an id');
await post({ action: 'stop' });
console.log('[ok] POST newest message ->', JSON.stringify({ messageId: newest.body.messageId }));

// ---- preferences drive playback ----------------------------------------
const initial = await settings();
assert.equal(initial.status, 200);
assert.ok(initial.body.voices.zh.includes('Tingting'), 'installed zh voices are listed for the picker');
assert.ok(initial.body.voices.ko.includes('Yuna'), 'installed ko voices are listed');
console.log('[ok] GET settings ->', JSON.stringify({ zhFirst: initial.body.voices.zh.slice(0, 3), ko: initial.body.voices.ko.slice(0, 2), rate: initial.body.settings.rate }));

const savedSettings = await settings('POST', { voices: { zh: 'Meijia' }, rate: 260 });
assert.equal(savedSettings.status, 200);
assert.equal(savedSettings.body.settings.voices.zh, 'Meijia');
assert.equal(savedSettings.body.settings.rate, 260);
const stored = await registered.execute({ text: '这是中文测试。' });
assert.deepEqual(stored.voices, ['Meijia'], 'the stored zh voice applies without explicit options');
assert.equal(stored.rate, 260, 'the stored rate applies without explicit options');
await registered.execute({ stop: true });
console.log('[ok] stored zh voice + rate ->', JSON.stringify({ voices: stored.voices, rate: stored.rate }));

const hanBiasSaved = await settings('POST', { language: 'ja' });
assert.equal(hanBiasSaved.status, 200);
const hanRead = await registered.execute({ text: '漢字文', rate: 500 });
assert.deepEqual(hanRead.voices, ['Kyoko'], 'the stored Han bias reads bare Han as Japanese');
await registered.execute({ stop: true });
console.log('[ok] stored Han bias ->', JSON.stringify({ voices: hanRead.voices }));

const overridden = await registered.execute({ text: '这是中文测试。', voice: 'Samantha', rate: 500 });
assert.deepEqual(overridden.voices, ['Samantha'], 'an explicit voice still overrides the stored one');
await registered.execute({ stop: true });

const rejected = await settings('POST', { voices: { zh: 'NoSuchVoice' } });
assert.equal(rejected.status, 422, 'an unknown voice is refused');
assert.equal((await settings('POST', { voices: { zh: 'Tingting' } })).status, 200, 'a known voice is accepted');
assert.equal((await settings('POST', { voices: null, rate: null, language: null })).body.settings.rate, null, 'null resets a field');
assert.deepEqual((await settings()).body.settings.voices, {}, 'null voices clear every pin');
console.log('[ok] settings validation + reset');

// ---- browser reports ----------------------------------------------------
const reported = await client('POST', { event: 'hello', build: 'test-build', entries: ['actions', 'selection', 'settings'] });
assert.equal(reported.status, 200);
await client('POST', { event: 'selection', build: 'test-build', visible: true, length: 12 });
const log = await client();
assert.equal(log.body.count, 2);
assert.equal(log.body.reports[0].event, 'hello');
assert.equal(log.body.reports[0].build, 'test-build');
assert.ok(log.body.reports[1].note.includes('visible'), 'extra fields survive into the note');
console.log('[ok] browser reports ->', JSON.stringify(log.body.reports.map((r) => r.event)));
const notJsonReport = fakeResponse();
await routes.get('/api/dsh-speak/client').handler({ method: 'POST', headers: { 'content-type': 'text/plain' }, async *[Symbol.asyncIterator]() { yield Buffer.from('{}'); } }, notJsonReport);
assert.equal(notJsonReport.statusCode, 415, 'client route needs JSON');
assert.equal((await client('DELETE')).status, 405, 'client route is GET/POST only');

// ---- guards -------------------------------------------------------------
assert.equal((await post({ sessionId: 'nope' })).status, 422, 'unknown session rejected');
const wrongMethod = fakeResponse();
await routes.get('/api/dsh-speak').handler({ method: 'GET', headers: {} }, wrongMethod);
assert.equal(wrongMethod.statusCode, 405, 'action route is POST only');
const wrongType = fakeResponse();
await routes.get('/api/dsh-speak').handler({ method: 'POST', headers: { 'content-type': 'text/plain' } }, wrongType);
assert.equal(wrongType.statusCode, 415, 'action route needs JSON');
assert.equal((await status('POST')).status, 405, 'status route is GET only');
const head = fakeResponse();
await routes.get('/api/dsh-speak/status').handler(fakeRequest('HEAD'), head);
assert.equal(head.statusCode, 200);
assert.equal(head.body, '', 'HEAD sends no body');
console.log('[ok] guards: 422 / 405 / 415 / HEAD');

console.log('\nALL CHECKS PASSED');
