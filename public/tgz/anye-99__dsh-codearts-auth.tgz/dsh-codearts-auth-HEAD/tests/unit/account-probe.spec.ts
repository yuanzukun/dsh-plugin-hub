/**
 * 限流标记重测 / 重置的单元测试。
 *
 * 全部使用桩函数：**不发起任何网络请求**（探测函数由 deps.probe 注入），
 * 遵循 tests/unit 的约定。
 */
import { describe, expect, it, vi } from 'vitest'
import { LlmError } from '@deepseek-ai/dsh-llm'
import {
  resetAccount,
  resetAllAccounts,
  retestAccount,
  retestAllAccounts,
} from '../../src/account-probe.js'
import type { ProbePool } from '../../src/account-probe.js'
import { ALL_MODELS_RATE_LIMIT_KEY } from '../../src/account-pool.js'
import type { ProviderAccountEntry } from '../../src/types.js'

/** 构造账号条目；默认带一条 deepseek-v4.1-flash 的未到期限流记录。 */
function makeEntry(overrides: Partial<ProviderAccountEntry> = {}): ProviderAccountEntry {
  return {
    id: 'buddy-1',
    provider: 'buddy',
    nickname: '测试号',
    enabled: true,
    credentialRef: 'BUDDY_ACCOUNT_TEST',
    createdAt: 1,
    refreshable: true,
    modelRateLimits: { 'deepseek-v4.1-flash': Date.now() + 3_600_000 },
    ...overrides,
  }
}

/**
 * 记录调用的账号池替身。
 *
 * `clearModelRateLimits` 真实改写内部状态，使「重测后再查」能反映清除结果，
 * 从而验证"只有实测通过的模型才被清除"。
 */
function makePool(entries: ProviderAccountEntry[]) {
  const accounts = new Map(entries.map(e => [e.id, { ...e }]))
  const cleared: Array<{ accountId: string; modelIds?: readonly string[] }> = []
  const updated: Array<{ accountId: string; modelId: string; resetAtMs: number }> = []
  const pool: ProbePool & {
    cleared: typeof cleared
    updated: typeof updated
    get(id: string): ProviderAccountEntry | undefined
  } = {
    cleared,
    updated,
    get: (id) => accounts.get(id),
    findAccount: (id) => accounts.get(id),
    listAccountsByProvider: (provider) => [...accounts.values()].filter(a => a.provider === provider),
    async resolveCredentialForAccount(id) {
      const entry = accounts.get(id)
      if (entry === undefined) return undefined
      return { access_token: 'AT', refresh_token: 'RT', expires_at: '2099-01-01T00:00:00Z' } as never
    },
    async clearModelRateLimits(accountId, modelIds) {
      const entry = accounts.get(accountId)
      if (entry?.modelRateLimits === undefined) return 0
      const limits = { ...entry.modelRateLimits }
      let removed = 0
      const targets = modelIds ?? Object.keys(limits)
      for (const m of targets) {
        if (Object.prototype.hasOwnProperty.call(limits, m)) { delete limits[m]; removed++ }
      }
      if (removed === 0) return 0
      const next = { ...entry }
      if (Object.keys(limits).length === 0) delete next.modelRateLimits
      else next.modelRateLimits = limits
      accounts.set(accountId, next)
      cleared.push({ accountId, modelIds })
      return removed
    },
    // 真实写回，供「仍受限时用上游新时刻覆盖旧值」的断言使用。
    async updateModelRateLimit(accountId, modelId, resetAtMs) {
      const entry = accounts.get(accountId)
      if (entry === undefined) return
      accounts.set(accountId, {
        ...entry,
        modelRateLimits: { ...entry.modelRateLimits, [modelId]: resetAtMs },
      })
      updated.push({ accountId, modelId, resetAtMs })
    },
  }
  return pool
}

describe('retestAccount', () => {
  it('实测通过的模型被清除标记', async () => {
    const pool = makePool([makeEntry()])
    const probe = vi.fn(async (_entry: ProviderAccountEntry, modelId: string) => ({ modelId, ok: true }))
    const result = await retestAccount(pool, 'buddy-1', { probe })

    expect(result.tested).toBe(1)
    expect(result.cleared).toEqual(['deepseek-v4.1-flash'])
    expect(result.stillLimited).toEqual([])
    // 关键：真的写回了池子，且只清除通过的模型
    expect(pool.cleared).toEqual([{ accountId: 'buddy-1', modelIds: ['deepseek-v4.1-flash'] }])
    expect(pool.get('buddy-1')?.modelRateLimits).toBeUndefined()
  })

  it('仍受限的模型保留标记，并回报原因', async () => {
    const pool = makePool([makeEntry({
      modelRateLimits: { 'model-a': Date.now() + 1000, 'model-b': Date.now() + 1000 },
    })])
    const probe = vi.fn(async (_entry: ProviderAccountEntry, modelId: string) => (
      modelId === 'model-a'
        ? { modelId, ok: false, message: '仍受限：频率限制' }
        : { modelId, ok: true }
    ))
    const result = await retestAccount(pool, 'buddy-1', { probe })

    expect(result.cleared).toEqual(['model-b'])
    expect(result.stillLimited).toEqual([{ modelId: 'model-a', ok: false, message: '仍受限：频率限制' }])
    // 只清除了 model-b，model-a 的标记必须还在
    expect(pool.cleared).toEqual([{ accountId: 'buddy-1', modelIds: ['model-b'] }])
    expect(pool.get('buddy-1')?.modelRateLimits).toEqual({ 'model-a': expect.any(Number) })
  })

  it('没有任何限流标记时不发请求', async () => {
    const pool = makePool([makeEntry({ modelRateLimits: undefined })])
    const probe = vi.fn()
    const result = await retestAccount(pool, 'buddy-1', { probe })

    expect(result.tested).toBe(0)
    expect(probe).not.toHaveBeenCalled()
    expect(pool.cleared).toEqual([])
  })

  /**
   * 「整账号受限」保留键（`'*'`）必须换成一个**真实**模型再探测 ——
   * **防的是一个新的死循环**。
   *
   * Qoder 的日额度（code 110）实测按**账号**结算，故现在写的是保留键
   * （见 `account-pool.ts` 的 `ALL_MODELS_RATE_LIMIT_KEY`）。而重测的语义是
   * 「拿这个模型名真发一条消息」—— 若直接把 `'*'` 发出去，上游必然回
   * 「未知模型」，于是**标记永远清不掉**。本仓库已两次记录过这一形态的死循环
   * （`account-probe.ts` 顶部的分派表注释）。
   *
   * ⚠️ 同时必须验证**清除的是原键**（`'*'`）而不是被替换后的真实模型名 ——
   * 否则标记留在存储里、UI 徽章常驻，等于没清。
   */
  it('整账号保留键换成真实模型探测，但清除的是原键（不造清不掉的标记）', async () => {
    const pool = makePool([makeEntry({
      provider: 'qoder',
      modelRateLimits: { [ALL_MODELS_RATE_LIMIT_KEY]: Date.now() + 3600_000 },
    })])
    const probed: string[] = []
    const probe = vi.fn(async (_entry: ProviderAccountEntry, modelId: string) => {
      probed.push(modelId)
      return { modelId, ok: true }
    })

    const result = await retestAccount(pool, 'buddy-1', { probe })

    // ① 真正发出去的**不是** `'*'`（那会被上游判未知模型）
    expect(probed).toEqual([expect.not.stringMatching(/^\*$/)])
    // ② Qoder 的表里有免费模型，优先拿它（重测不该烧付费额度）
    expect(probed[0]).toBe('qmodel_38max')
    // ③ 清除的是**存储里的原键**
    expect(pool.cleared).toEqual([{ accountId: 'buddy-1', modelIds: [ALL_MODELS_RATE_LIMIT_KEY] }])
    expect(pool.get('buddy-1')?.modelRateLimits).toBeUndefined()
    // ④ 回报给 UI 的键也是原键（否则徽章按错误键找不回来）
    expect(result.cleared).toEqual([ALL_MODELS_RATE_LIMIT_KEY])
  })

  it('非 Qoder 的未知保留键保守保留标记（探测如实失败，不误清）', async () => {
    // 其它 provider 目前不写该键；真遇到时宁可不猜模型，也不要误判为「已恢复」。
    const pool = makePool([makeEntry({
      provider: 'buddy',
      modelRateLimits: { [ALL_MODELS_RATE_LIMIT_KEY]: Date.now() + 3600_000 },
    })])
    const probe = vi.fn(async (_entry: ProviderAccountEntry, modelId: string) => (
      { modelId, ok: false, message: '仍受限：未知模型' }
    ))

    const result = await retestAccount(pool, 'buddy-1', { probe })

    expect(probe).toHaveBeenCalledWith(expect.anything(), ALL_MODELS_RATE_LIMIT_KEY)
    expect(result.cleared).toEqual([])
    expect(pool.get('buddy-1')?.modelRateLimits).toEqual({
      [ALL_MODELS_RATE_LIMIT_KEY]: expect.any(Number),
    })
  })

  /**
   * 回归：限流是**滚动窗口**，上游每次都会把重置时刻往后推。若重测只报「仍受限」
   * 而不把新时刻写回，存储会一直停在第一次的旧值 —— 旧值一旦过期，
   * UI 的 `modelRateLimits[v] > Date.now()` 判为过期而**不再渲染「限额重置」**，
   * 于是出现「弹窗说仍受限、账号卡片却空白」的矛盾，选号也会误判为可用。
   */
  it('仍受限时用上游给出的新重置时刻覆盖旧值（滚动窗口）', async () => {
    const staleReset = Date.now() - 60_000 // 已过期的旧时刻
    const freshReset = Date.now() + 45 * 60_000 // 上游推后到 45 分钟后
    const pool = makePool([makeEntry({
      modelRateLimits: { 'deepseek-v4.1-flash': staleReset },
    })])
    const probe = vi.fn(async (_entry: ProviderAccountEntry, modelId: string) => ({
      modelId, ok: false, message: '仍受限：频率限制', resetTimeMs: freshReset,
    }))

    const result = await retestAccount(pool, 'buddy-1', { probe })

    expect(result.cleared).toEqual([])
    // 关键：新时刻被写回并覆盖过期旧值 ⇒ UI 才会重新显示「限额重置」
    expect(pool.updated).toEqual([
      { accountId: 'buddy-1', modelId: 'deepseek-v4.1-flash', resetAtMs: freshReset },
    ])
    expect(pool.get('buddy-1')?.modelRateLimits).toEqual({ 'deepseek-v4.1-flash': freshReset })
  })

  it('仍受限但没有可解析的重置时刻时不写回（保留原标记）', async () => {
    const staleReset = Date.now() + 3_600_000
    const pool = makePool([makeEntry({
      modelRateLimits: { 'deepseek-v4.1-flash': staleReset },
    })])
    const probe = vi.fn(async (_entry: ProviderAccountEntry, modelId: string) => ({
      modelId, ok: false, message: '仍受限：频率限制', // 无 resetTimeMs
    }))

    await retestAccount(pool, 'buddy-1', { probe })

    expect(pool.updated).toEqual([])
    expect(pool.get('buddy-1')?.modelRateLimits).toEqual({ 'deepseek-v4.1-flash': staleReset })
  })

  it('账号不存在时返回错误而不抛异常', async () => {
    const pool = makePool([])
    const result = await retestAccount(pool, 'missing', { probe: vi.fn() })
    expect(result.error).toContain('不存在')
    expect(result.tested).toBe(0)
  })

  it('凭据不可用时不清除标记', async () => {
    const entry = makeEntry()
    const pool = makePool([entry])
    // 覆盖为"凭据不可用"
    pool.resolveCredentialForAccount = async () => undefined
    // 用真实默认探测（deps.probe 省略）会走 resolveCredentialForAccount
    const result = await retestAccount(pool, 'buddy-1')

    expect(result.cleared).toEqual([])
    expect(result.stillLimited[0]?.message).toContain('凭据不可用')
    expect(pool.cleared).toEqual([])
  })
})

describe('retestAllAccounts', () => {
  it('遍历该 provider 的全部账号，包含已停用账号', async () => {
    const pool = makePool([
      makeEntry({ id: 'buddy-on', enabled: true }),
      makeEntry({ id: 'buddy-off', enabled: false }),
      makeEntry({ id: 'codearts-1', provider: 'codearts', credentialRef: 'CODEARTS_ACCOUNT_X' }),
    ])
    const seen: string[] = []
    const probe = vi.fn(async (entry: ProviderAccountEntry, modelId: string) => {
      seen.push(entry.id)
      return { modelId, ok: true }
    })
    const res = await retestAllAccounts(pool, 'buddy', { probe })

    // 停用的 buddy-off 也必须被重测（用户明确要求）
    expect(seen.sort()).toEqual(['buddy-off', 'buddy-on'])
    expect(res.accounts.map(a => a.accountId).sort()).toEqual(['buddy-off', 'buddy-on'])
    expect(res.clearedCount).toBe(2)
    // codearts 账号不应被 buddy 的批量操作波及
    expect(res.accounts.some(a => a.accountId === 'codearts-1')).toBe(false)
  })

  it('按顺序逐个探测，避免并发触发真实限流', async () => {
    const pool = makePool([makeEntry({ id: 'a' }), makeEntry({ id: 'b' }), makeEntry({ id: 'c' })])
    let inFlight = 0
    let maxInFlight = 0
    const probe = vi.fn(async (_entry: ProviderAccountEntry, modelId: string) => {
      inFlight++
      maxInFlight = Math.max(maxInFlight, inFlight)
      await new Promise(r => setTimeout(r, 1))
      inFlight--
      return { modelId, ok: true }
    })
    await retestAllAccounts(pool, 'buddy', { probe })
    expect(maxInFlight).toBe(1)
  })
})

describe('resetAccount / resetAllAccounts', () => {
  it('重置不发请求，直接清除全部标记', async () => {
    const pool = makePool([makeEntry({
      modelRateLimits: { 'model-a': Date.now() + 1000, 'model-b': Date.now() + 2000 },
    })])
    const res = await resetAccount(pool, 'buddy-1')

    expect(res.clearedCount).toBe(2)
    expect(res.accountCount).toBe(1)
    expect(pool.get('buddy-1')?.modelRateLimits).toBeUndefined()
  })

  it('无标记时重置返回 0', async () => {
    const pool = makePool([makeEntry({ modelRateLimits: undefined })])
    expect(await resetAccount(pool, 'buddy-1')).toEqual({ clearedCount: 0, accountCount: 0 })
  })

  it('重置所有覆盖停用账号并统计正确', async () => {
    const pool = makePool([
      makeEntry({ id: 'on', enabled: true }),
      makeEntry({ id: 'off', enabled: false }),
      makeEntry({ id: 'none', enabled: false, modelRateLimits: undefined }),
      makeEntry({ id: 'ca', provider: 'codearts', credentialRef: 'CODEARTS_ACCOUNT_X' }),
    ])
    const res = await resetAllAccounts(pool, 'buddy')

    // on + off 各 1 条；none 无标记不计入；codearts 不在范围内
    expect(res.clearedCount).toBe(2)
    expect(res.accountCount).toBe(2)
    expect(pool.get('ca')?.modelRateLimits).toBeDefined()
  })
})

describe('限流判定（isRateLimitFailure 经由默认探测暴露的行为）', () => {
  it('LlmError 的 QUOTA_EXCEEDED / RATE_LIMIT / QUOTA 都识别为限流', () => {
    // 该判定是私有的，通过默认探测路径间接验证：这里直接断言错误码集合
    // 与实际适配器抛出的码一致，防止词汇漂移（buddy 用 QUOTA_EXCEEDED，
    // harness 常量是 QUOTA）。
    for (const code of ['RATE_LIMIT', 'QUOTA_EXCEEDED', 'QUOTA']) {
      const error = new LlmError('频率限制', code)
      expect(error.code).toBe(code)
    }
  })
})
