/**
 * `account.refresh` RPC 分派的回归测试。
 *
 * 覆盖两个**既有缺陷**（T7 修复）：
 *
 * 1. **workbuddy 分支缺失**：原实现只判 `codearts` / `buddy`，workbuddy 落入
 *    else 抛 `Unknown provider` —— 即 WorkBuddy 账号卡片的「刷新」按钮一直是坏的。
 * 2. **刷错凭据**：原实现调 `service.refresh()`，而该方法读写的是该 provider 的
 *    **默认单凭据 ref**（如 `BUDDY_ACCESS_TOKEN`），Jet Hub 账号卡片对应的却是
 *    `BUDDY_ACCOUNT_XXX` —— 于是「刷新这个账号」实际刷的是另一个凭据。
 *
 * 这两个缺陷都无法靠 `collect*` 那类纯函数测试发现（它们不在那条代码路径上），
 * 因此这里直接驱动 `registerJetHubRpc` 注册的 HTTP 处理器，断言真实分派行为。
 */

import { describe, expect, it, vi } from 'vitest'
import { registerJetHubRpc } from '../../src/jet-hub-rpc.js'
import type { ProviderAccountEntry } from '../../src/types.js'

/** 采集到的「某服务被要求刷新的 credentialRef」。 */
interface RefreshCall {
  service: string
  credentialRef: string
}

/**
 * 构造一个 fake `ctx`，捕获 `connection.fetch.register` 的处理器。
 */
function makeCtx(accounts: ProviderAccountEntry[]) {
  let handler: ((request: Request) => Promise<Response>) | undefined
  const ctx = {
    connection: {
      fetch: {
        register: (options: { fetch: (request: Request) => Promise<Response> }) => {
          handler = options.fetch
        },
      },
    },
    logger: { warn: () => {}, info: () => {}, error: () => {} },
    credentials: {
      resolve: async () => undefined,
      describe: async () => ({ configured: false }),
    },
    get: () => undefined,
    // `connection` 由生产代码用**惰性注入**（`ctx.inject`）挂载，而非插件级
    // 静态 `inject`：它只存在于 Web bundle，静态声明会让 headless/CLI profile
    // 永久 pending 而启动失败。替身必须复刻这一机制，否则 registerJetHubRpc
    // 会以 `ctx.inject is not a function` 直接抛错。
    //
    // 语义对齐真实 cordis：回调以**同一 ctx** 立即调用（本替身里 connection
    // 始终可用），使端点注册行为与 Web profile 下完全一致。
    inject: (_deps: string[], callback: (ctx: unknown) => void) => { callback(ctx) },
  }
  return { ctx, getHandler: () => handler! }
}

/** 构造一个只记录调用、不做真实网络的服务替身。 */
function makeServiceStub(name: string, calls: RefreshCall[]) {
  return {
    refreshAccountCredential: vi.fn(async (ref: string) => { calls.push({ service: name, credentialRef: ref }) }),
    refresh: vi.fn(async () => { calls.push({ service: `${name}.refresh(default)`, credentialRef: '' }) }),
  }
}

/** 构造账号池替身。 */
function makePool(accounts: ProviderAccountEntry[]) {
  return {
    listAllAccounts: async () => accounts,
    listAccounts: async (provider: string) => accounts.filter((a) => a.provider === provider),
    updateAccount: async () => {},
  }
}

/**
 * 调用 `account.refresh` 并返回 RPC 结果载荷。
 */
async function callRefresh(
  accounts: ProviderAccountEntry[],
  accountId: string,
): Promise<{ calls: RefreshCall[]; value: { success: boolean; error?: string } }> {
  const calls: RefreshCall[] = []
  const { ctx, getHandler } = makeCtx(accounts)
  registerJetHubRpc(
    ctx as never,
    makePool(accounts) as never,
    makeServiceStub('codearts', calls) as never,
    makeServiceStub('buddy', calls) as never,
    makeServiceStub('workbuddy', calls) as never,
    makeServiceStub('lobsterai', calls) as never,
    makeServiceStub('qoder', calls) as never,
    makeServiceStub('qodercn', calls) as never,
    makeServiceStub('trae', calls) as never,
    // 补齐 trae 之后的占位（本用例只触发 trae / lobsterai，但**占位数量
    // 必须与签名一致** —— 少补一个不会报错，只会静默错位）。
    makeServiceStub('cline', calls) as never,
    makeServiceStub('loomy', calls) as never,
    makeServiceStub('raccoon', calls) as never,
    makeServiceStub('minimax', calls) as never,
    makeServiceStub('teleagent', calls) as never,
    makeServiceStub('zcode', calls) as never,
    makeServiceStub('stepcode', calls) as never,
  )
  const response = await getHandler()(new Request('http://127.0.0.1/api/jet-hub', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      type: 'client-request',
      rpcId: 'r1',
      method: 'jet-hub',
      payload: { method: 'account.refresh', payload: { accountId } },
    }),
  }))
  const body = await response.json() as {
    result: { ok: boolean; value?: { success: boolean; error?: string } }
  }
  return { calls, value: body.result.value! }
}

function entry(provider: string, credentialRef: string): ProviderAccountEntry {
  return {
    id: `${provider}-1`,
    provider,
    nickname: '测试号',
    enabled: true,
    credentialRef,
    createdAt: 1,
    refreshable: true,
  }
}

describe('account.refresh 分派（T7 回归）', () => {
  it('buddy 账号刷新**自己的** credentialRef，而不是默认单凭据 ref', async () => {
    // 缺陷 2 的回归：原实现调 buddy.refresh()（读 BUDDY_ACCESS_TOKEN），
    // 刷的是另一个凭据。
    const { calls, value } = await callRefresh(
      [entry('buddy', 'BUDDY_ACCOUNT_AAAA1111')], 'buddy-1',
    )
    expect(value.success).toBe(true)
    expect(calls).toEqual([{ service: 'buddy', credentialRef: 'BUDDY_ACCOUNT_AAAA1111' }])
    // 绝不能退化成「刷默认凭据」。
    expect(calls.some((c) => c.service.includes('refresh(default)'))).toBe(false)
  })

  it('workbuddy 账号可刷新且不再抛 Unknown provider（缺陷 1 的回归）', async () => {
    // 原实现只判 codearts / buddy，workbuddy 落到 else 抛
    // `Unknown provider: workbuddy`，value.success 为 false。
    const { calls, value } = await callRefresh(
      [entry('workbuddy', 'WORKBUDDY_ACCOUNT_BBBB2222')], 'workbuddy-1',
    )
    expect(value.success).toBe(true)
    expect(value.error).toBeUndefined()
    expect(calls).toEqual([{ service: 'workbuddy', credentialRef: 'WORKBUDDY_ACCOUNT_BBBB2222' }])
  })

  it('lobsterai 账号刷新自己的 credentialRef（新增 provider 不得重蹈覆辙）', async () => {
    const { calls, value } = await callRefresh(
      [entry('lobsterai', 'LOBSTERAI_ACCOUNT_CCCC3333')], 'lobsterai-1',
    )
    expect(value.success).toBe(true)
    expect(calls).toEqual([{ service: 'lobsterai', credentialRef: 'LOBSTERAI_ACCOUNT_CCCC3333' }])
  })

  it('trae 账号刷新自己的 credentialRef（新增 provider 不得重蹈覆辙）', async () => {
    const { calls, value } = await callRefresh(
      [entry('trae', 'TRAE_ACCOUNT_EEEE5555')], 'trae-1',
    )
    expect(value.success).toBe(true)
    expect(calls).toEqual([{ service: 'trae', credentialRef: 'TRAE_ACCOUNT_EEEE5555' }])
  })

  it('qoder 账号刷新自己的 credentialRef（新增 provider 不得重蹈覆辙）', async () => {
    const { calls, value } = await callRefresh(
      [entry('qoder', 'QODER_ACCOUNT_FFFF6666')], 'qoder-1',
    )
    expect(value.success).toBe(true)
    expect(calls).toEqual([{ service: 'qoder', credentialRef: 'QODER_ACCOUNT_FFFF6666' }])
  })

  it('qodercn 账号刷新分派到**中国版实例**，不串到国际版（同族注册表的核心风险）', async () => {
    // 国际版与中国版共用一个 switch case（`case QODER.id: case QODER_CN.id:`），
    // 靠 `requireQoderFamily(entry.provider)` 查注册表取实例。
    // 若哪天有人把它写死成 `qoder.refreshAccountCredential(...)`，
    // 症状是「中国版账号点刷新，实际续期了国际版的凭据」—— 两站 token
    // 不通用，于是 CN 续期永远失败而国际版被无谓地刷了一次。
    // 这条用例用**行为**（哪个 stub 被调用）而非字符串锁住这件事。
    const { calls, value } = await callRefresh(
      [entry('qodercn', 'QODERCN_ACCOUNT_GGGG7777')], 'qodercn-1',
    )
    expect(value.success).toBe(true)
    expect(value.error).toBeUndefined()
    expect(calls).toEqual([{ service: 'qodercn', credentialRef: 'QODERCN_ACCOUNT_GGGG7777' }])
    // 关键：国际版实例必须**没有**被碰过。
    expect(calls.some((c) => c.service === 'qoder'), '中国版账号串到了国际版实例').toBe(false)
  })

  it('两站账号同时在池时各刷各的（互不串用）', async () => {
    const accounts = [
      entry('qoder', 'QODER_ACCOUNT_H1'),
      entry('qodercn', 'QODERCN_ACCOUNT_H2'),
    ]
    const intl = await callRefresh(accounts, 'qoder-1')
    expect(intl.calls).toEqual([{ service: 'qoder', credentialRef: 'QODER_ACCOUNT_H1' }])
    const cn = await callRefresh(accounts, 'qodercn-1')
    expect(cn.calls).toEqual([{ service: 'qodercn', credentialRef: 'QODERCN_ACCOUNT_H2' }])
  })

  it('codearts 账号刷新自己的 credentialRef', async () => {
    const { calls, value } = await callRefresh(
      [entry('codearts', 'CODEARTS_ACCOUNT_DDDD4444')], 'codearts-1',
    )
    expect(value.success).toBe(true)
    expect(calls).toEqual([{ service: 'codearts', credentialRef: 'CODEARTS_ACCOUNT_DDDD4444' }])
  })

  it('七个 provider 各自分派到对应服务（互不串用）', async () => {
    const accounts = [
      entry('codearts', 'CODEARTS_ACCOUNT_1'),
      entry('buddy', 'BUDDY_ACCOUNT_1'),
      entry('workbuddy', 'WORKBUDDY_ACCOUNT_1'),
      entry('lobsterai', 'LOBSTERAI_ACCOUNT_1'),
      entry('qoder', 'QODER_ACCOUNT_1'),
      entry('qodercn', 'QODERCN_ACCOUNT_1'),
      entry('trae', 'TRAE_ACCOUNT_1'),
    ]
    for (const target of accounts) {
      const { calls, value } = await callRefresh(accounts, target.id.replace(`${target.provider}-1`, `${target.provider}-1`))
      expect(value.success, target.provider).toBe(true)
      expect(calls, target.provider).toEqual([
        { service: target.provider, credentialRef: target.credentialRef },
      ])
    }
  })

  it('未知 provider 仍然报错（不静默成功）', async () => {
    const { value } = await callRefresh([entry('mystery', 'MYSTERY_ACCOUNT_1')], 'mystery-1')
    expect(value.success).toBe(false)
    expect(value.error).toMatch(/Unknown provider/)
  })

  it('账号不存在时报错', async () => {
    const { value } = await callRefresh([], 'nope-1')
    expect(value.success).toBe(false)
    expect(value.error).toMatch(/not found/)
  })
})
