/**
 * Raccoon Work（商汤小浣熊）产品配置。
 *
 * ## 为什么新建 `RaccoonProduct` 而不复用既有类型
 *
 * `BuddyProduct` / `LobsteraiProduct` / `QoderProduct` / `LoomyProduct` 的字段
 * 全部围绕各自协议设计（归属头、refresh 载荷、WASM 签名参数、讯飞 AccessKey…），
 * 对 raccoon 无一有意义。raccoon 需要的是：一套 API 前缀、桌面端身份标识、
 * 手机号加密密钥、阿里云验证码配置，以及一张兜底模型表。
 * 故定义**平行**的接口 —— 共用的是架构**模式**（产品差异收敛到单一真相源），
 * 不是那个类型。
 *
 * ## 数据来源
 *
 * - API 基址与各前缀：`app.asar` 的 `.env.electron`
 * - 手机号加密密钥：渲染层模块 68284 的 `yv(e, t = "senseraccoon2023")`
 * - 阿里云验证码：渲染层模块 37907 的 `q3`（SceneId）/ `$j`（prefix）
 * - 兜底模型表：2026-09-26 用本机登录态实测
 *   `GET /api/web/llm/v2/model_catalog` 取 `visible:true` 的 6 条
 */

import { RACCOON_API_BASE, RACCOON_PHONE_CIPHER_SECRET } from './raccoon.js'
import { RACCOON_REQUEST_IMAGE_MAX_BYTES } from './image-budget.js'

/**
 * 思考档位：小浣熊**只有两态（开 / 关）**，这是实测确证的。
 *
 * ## ⚠️ 为什么是「开 / 关」而不是「high / 关闭」
 *
 * 服务端**接受** `reasoning_effort`（8 个枚举值，报错原文：
 * ``expected one of `none`, `minimal`, `low`, `medium`, `high`, `xhigh`, `ultra`, `max` ``），
 * 但它**不产生任何可观测效果** —— 8 轮配对实验（`temperature=0`）：
 *
 * | 档位 | `reasoning_tokens` 均值 |
 * |---|---|
 * | `minimal` | 197 |
 * | `max` | 226 |
 *
 * 逐轮配对差值 `max - minimal`：**正差 4 次 / 负差 4 次**（纯随机）。
 * 4 轮小样本时曾观察到「单调趋势」（175→288），8 轮后消失 —— 那是巧合。
 * 且 `none` 均值 301 ≠ `disabled` 的 0，说明**它也不控制思考开关**。
 *
 * ⇒ `reasoning_effort` 只是被 JSON schema 接受，不影响行为。
 *
 * ## 唯一有效通道：`extra_body.thinking.type`
 *
 * 报错原文：``thinking.type: expected one of `adaptive`, `enabled`, `disabled` ``。
 * 实测（每组 6~8 次，判据为服务端上报的 `reasoning_tokens`）：
 *
 * | 请求 | 结果 |
 * |---|---|
 * | 基线（不发参数） | 均值 **222**，6/6 有思考 |
 * | `extra_body.thinking={type:'disabled'}` | **6/6、8/8 全为 0** → ✅ 真关闭 |
 * | `extra_body.thinking={type:'enabled'}` | 均值 **218** → ✅ 与默认等价 |
 *
 * 故我们**只暴露这两态**：开（enabled）与关（disabled）。
 *
 * ## ⚠️ 无效的写法（都实测过，别照着试）
 *
 * | 写法 | 结果 |
 * |---|---|
 * | `extra_body.enable_thinking=false` | ❌ 无效 |
 * | `extra_body.extra_body.enable_thinking=false`（双层） | ❌ 无效 |
 * | `reasoning_effort`（单层/双层/顶层） | ❌ 被接受但**无效果**（见上） |
 * | `thinking` 放**顶层**（不在 `extra_body` 内） | ❌ 被忽略（非法值也不报错） |
 * | `thinking.budget_tokens` | ⚠️ 仅被**格式校验**（`max_tokens < budget_tokens` 回 400），1~4096 全接受但思考量无规律 |
 *
 * ⚠️ 客户端注释说 `extra_body` 双层嵌套是 **LiteLLM SDK 的调用约定**
 *（"LiteLLM expects another provider-owned extra_body object inside that body"）——
 * 但实测**单层才生效**，故以实测为准。
 */

/**
 * 档位 id：**开启**思考（`thinking:{type:'enabled'}`）。
 *
 * ⚠️ id 用 `on` 而不是 `high`：服务端虽接受 `high` 字样，但它走的是
 * `reasoning_effort` 通道、**实测无效果**。用 `on` 避免让用户误以为
 * 「选的是高强度档」—— 我们能表达的只有「开 / 关」。
 */
export const RACCOON_EFFORT_ON = 'on'

/** 档位 id：**关闭**思考（`thinking:{type:'disabled'}`）。 */
export const RACCOON_EFFORT_OFF = 'off'

/**
 * 档位展示名（DSH 直接渲染 `efforts[].name`，不本地化）。
 *
 * ⚠️ 用「开启 / 关闭」而非「深度思考 / 关闭思考」（用户 2026-09-28 要求：
 * 「现在开启档位显示的深度思考，就显示开启就行了」）。
 *
 * 理由是**如实**：我们能表达的只有「思考开 / 关」这一个布尔维度，
 * 没有任何强度档位（`reasoning_effort` 实测无效）。叫「深度思考」会让用户
 * 以为存在「浅度思考」之类的其他档位可选，而实际上没有。
 */
export const RACCOON_EFFORT_NAMES: Readonly<Record<string, string>> = Object.freeze({
  [RACCOON_EFFORT_ON]: '开启',
  [RACCOON_EFFORT_OFF]: '关闭',
})

/**
 * 该模型可选的思考档位（按展示顺序）。
 *
 * ⚠️ **所有 6 个可见模型都返回这两档** —— 实测 `extra_body.thinking` 是
 * **provider 级方言**，与模型无关（`thinking.type` 的枚举在服务端全局一致）。
 * 故不做 per-model 分派（那会是凭空猜测）。
 */
export const RACCOON_REASONING_EFFORTS: readonly string[] = Object.freeze([
  RACCOON_EFFORT_ON,
  RACCOON_EFFORT_OFF,
])

/**
 * 默认档位 = `on`。
 *
 * 依据：实测「不发参数」与「显式 `{type:'enabled'}`」的思考量**等价**
 *（均值 222 vs 218），即**服务端默认就是开启**。故默认标成 `on`
 * 是**如实描述**，不是我们强行改变行为。
 */
export const RACCOON_DEFAULT_EFFORT = RACCOON_EFFORT_ON

/**
 * 兜底模型目录中的一个条目。
 */
export interface RaccoonFallbackModel {
  /** 模型 ID（传给 `chat/completions` 的 `model`）。 */
  id: string
  /** **已规范化**的展示名（含倍率，` · ` 分隔；免费显示「免费」）。 */
  name: string
  /** 上下文窗口。 */
  contextWindow: number
  /** 单次输出上限（远端 `params.max_tokens`）。 */
  maxTokens: number
  /** 是否支持图片输入（远端 `tags` 含 `vision`）。 */
  supportsImage: boolean
}

/** Raccoon Work 产品配置。 */
export interface RaccoonProduct {
  /** provider 标识：注册到 `ctx.llm` 的路由名，也是账号列表的 provider 字段值。 */
  id: 'raccoon'
  /** 设置页 / 模型选择器展示名。 */
  displayName: string
  /** API 基址。 */
  apiBase: string
  /** 认证端点前缀。 */
  authApiPrefix: string
  /** 推理与模型目录前缀。 */
  llmApiPrefix: string
  /** 积分端点前缀。 */
  pointsApiPrefix: string
  /** 桌面端端点前缀。 */
  desktopApiPrefix: string
  /**
   * 单张请求图片的像素预算（issue !IKITT9 的 raccoon 变体）。
   *
   * ⚠️ **raccoon 的约束与腾讯不是一回事**：它按**请求体字节**卡 ——
   * 实测 `HTTP_413: request body exceeds 10MB`，一张 2560×1600 的截图
   *（原图 2.87 MiB → base64 后 ≈3.9 MB）过、四张必爆。
   * 所以真正起作用的是下面的 `imageMaxBytes`；像素预算只是让图不至于
   * 大到编码器压不进那个字节目标。
   */
  imagePixelBudget?: number
  /**
   * 单张请求图片的**编码字节目标**（base64 展开前）。
   *
   * 取 **512 KB**：base64 膨胀 4/3 → 每张约占 683 KB，
   * 10 MB 的配额可放约 **14 张**（原图只能放 2 张）。
   * ⚠️ 这是"每张固定预算"路线的固有上限：图再多仍会 413。
   * 按张数分摊总配额会把每张压到 600×400 以下、UI 小字直接糊掉，
   * 权衡后选择「保住可辨认性 + 覆盖到 14 张」（用户 2026-09-28 定，方案 A）。
   */
  imageMaxBytes?: number
  /** User-Agent（仅记录用；实测该端点不校验 UA）。 */
  userAgent: string
  /**
   * 客户端平台标识。
   *
   * ⚠️ 取值必须是 `desktop-windows` / `desktop-macos` / `desktop-linux`
   * —— 依据主进程 `desktopDeviceIdentity.js` 的 `resolveDesktopClientPlatform`
   * （`win32` → `desktop-windows`）。`desktop/v1/login/points/grant`
   * **要求**该头，猜错会被拒。
   */
  clientPlatform: string
  /** 客户端版本（带 `v` 前缀，如 `v1.0.35`）。 */
  clientVersion: string
  /** 默认凭据 ref（无账号池时的单凭据回退）。 */
  defaultCredentialRef: string
  /** 手机号传输层加密密钥（见 `raccoon.ts` 的说明：公开常量，非安全边界）。 */
  phoneCipherSecret: string
  /** 阿里云滑块验证码配置（短信登录必需）。 */
  aliyunCaptcha: { sceneId: string; prefix: string }
  /** 远端模型列表不可用时的兜底目录（6 个可见模型）。 */
  fallbackModels: readonly RaccoonFallbackModel[]
}

/**
 * 兜底模型目录（6 个 `visible:true` 模型）。
 *
 * 来源：2026-10-09 实测 `GET /api/web/llm/v2/model_catalog`（id 集合与顺序均未变）。
 * 顺序**照抄远端返回顺序**，不重排 —— 重排会让「与远端对比」这类排查失去可比性。
 *
 * ⚠️ 展示名由 `raccoonDisplayName` 的输出形态固化（` · x倍率` / ` · 免费` /
 * ` · x原价→x折后价`），与远端 `billing_effective_multiplier` 逐条对应：
 *
 * | id | 原价 | 生效价 | 展示 |
 * |---|---|---|---|
 * | `sn-sensenova-6-8-flash` | 0.5 | 0 | 免费 |
 * | `sn-sensenova-6-8-flash-lite` | 0.5 | 0 | 免费 |
 * | `sn-glm-5-3` | 0.75 | 0.75 | x0.75 |
 * | `sn-kimi-k3` | 1 | 1 | x1 |
 * | `sn-glm-5-3-flash` | 0.2 | **0.2** | x0.2 |
 * | `sn-deepseek-v4-1-flash` | 0.25 | 0.25 | x0.25 |
 *
 * ⚠️ **`sn-glm-5-3-flash` 的折后价已消失**（2026-10-09 实测）：旧值展示
 * `x0.2→x0.1`，现为 `x0.2`。**判定为「上游不再下发」而非「我们解析写错」**，
 * 四条判据（复核脚本 `scripts/probe-loomy-raccoon-catalog.mjs`）：
 * 1. 两个字段**都下发了**且值均为 `0.2`（不是 `undefined`、不是字符串）；
 * 2. 同一段解析对 `sn-sensenova-*` 仍正确判出「免费」（`base=0.5 / effective=0`
 *    被正确区分）⇒ 解析未损坏；
 * 3. 上游自己的折扣明细 `billing_discounts` 已为 **空数组**、`billing_status`
 *    回到 `normal`（对照限免模型有一条 `active:true` 的 discount）⇒ 折扣被
 *    **整体移除**，不是「存在但不在时段内」，故我们无从推算折后价；
 * 4. 5 次采样计费快照只有 1 种，非抖动。
 *
 * ⇒ `raccoonDisplayName` 的箭头分支要求 `base > effective` 严格成立，
 * `0.2 > 0.2` 为 false，正确落到 `x生效价` 分支。**修的是数据，不是逻辑**
 * —— `tests/unit/raccoon.spec.ts` 里「有折扣时显示箭头」的用例必须保留。
 *
 * ⚠️ **不含** `Raccoon-Auto`：它是客户端 i18n 条目（`modelPicker.auto`）渲染的
 * 「自动选模」入口，不是远端模型 —— 直接发给 `chat/completions` 会 404。
 * ⚠️ 也不含 3 个 `visible:false` 的 `raccoon-*` 内部模型。
 */
const RACCOON_FALLBACK_MODELS: readonly RaccoonFallbackModel[] = [
  {
    id: 'sn-sensenova-6-8-flash',
    name: 'SenseNova-6.8-Flash · 免费',
    contextWindow: 256_000,
    maxTokens: 63_999,
    supportsImage: true,
  },
  {
    id: 'sn-sensenova-6-8-flash-lite',
    name: 'SenseNova-6.8-Flash-Lite · 免费',
    contextWindow: 256_000,
    maxTokens: 63_999,
    supportsImage: true,
  },
  {
    id: 'sn-glm-5-3',
    name: 'GLM-5-3 · x0.75',
    contextWindow: 1_000_000,
    maxTokens: 100_000,
    supportsImage: true,
  },
  {
    id: 'sn-kimi-k3',
    // ⚠️ 1 倍也要显示（用户报障「为什么 Kimi-K3 没有倍率，ide 是 1 倍，
    // 1 倍也要显示倍率」）—— 见 `raccoonDisplayName` 的注释。
    name: 'Kimi-K3 · x1',
    contextWindow: 1_000_000,
    maxTokens: 100_000,
    supportsImage: true,
  },
  {
    id: 'sn-glm-5-3-flash',
    // ⚠️ 2026-10-09：上游已移除该模型的折扣（billing_discounts 为空），
    // 生效价 = 原价 = 0.2，故不再显示箭头（见上方四条判据）。
    name: 'GLM-5-3-Flash · x0.2',
    contextWindow: 1_000_000,
    maxTokens: 100_000,
    supportsImage: false,
  },
  {
    id: 'sn-deepseek-v4-1-flash',
    name: 'DeepSeek-V4.1-Flash · x0.25',
    contextWindow: 1_000_000,
    maxTokens: 100_000,
    supportsImage: false,
  },
]

/** Raccoon Work provider 配置。 */
export const RACCOON: RaccoonProduct = {
  id: 'raccoon',
  // ⚠️ 用『Raccoon (商汤)』而非『Raccoon Work (商汤)』—— 后者在 Jet Hub 的
  // provider Tab 里**触发换行**（用户报障）。客户端内的品牌名是 `Raccoon Work`，
  // 但那个词组太长；缩短成 `Raccoon` 后与其余 provider 的标签长度一致
  //（`CodeBuddy (腾讯)` / `LobsterAI (有道)` / `WorkBuddy (国际版)`）。
  displayName: 'Raccoon (商汤)',
  apiBase: RACCOON_API_BASE,
  authApiPrefix: '/api/web/auth/v1',
  llmApiPrefix: '/api/web/llm/v2',
  pointsApiPrefix: '/api/web/points/v1',
  desktopApiPrefix: '/api/web/desktop/v1',
  userAgent: 'Raccoon Work/1.0.35 (Windows)',
  clientPlatform: 'desktop-windows',
  clientVersion: 'v1.0.35',
  defaultCredentialRef: 'RACCOON_ACCESS_TOKEN',
  // 实测该网关按**请求体字节**卡（`HTTP_413: request body exceeds 10MB`），
  // 所以字节目标是主约束；像素预算保证图不至于大到压不进那个字节目标。
  imagePixelBudget: 640_000,
  imageMaxBytes: RACCOON_REQUEST_IMAGE_MAX_BYTES,
  phoneCipherSecret: RACCOON_PHONE_CIPHER_SECRET,
  aliyunCaptcha: { sceneId: '1pkmy0x3', prefix: 'hk1r5l' },
  fallbackModels: RACCOON_FALLBACK_MODELS,
}

/** 全部 Raccoon 产品配置（当前只有一个，保留数组以便将来扩展）。 */
export const ALL_RACCOON_PRODUCTS: readonly RaccoonProduct[] = [RACCOON]

/**
 * 按 provider id 取产品配置；未知 id 返回 undefined。
 *
 * 与 `productById`（CodeBuddy 系）/ `lobsteraiProductById` / `loomyProductById`
 * 分开：各自返回**不同类型**，合并会让调用方拿到联合类型后再也不得不做类型收窄。
 */
export function raccoonProductById(id: string): RaccoonProduct | undefined {
  return ALL_RACCOON_PRODUCTS.find((product) => product.id === id)
}
