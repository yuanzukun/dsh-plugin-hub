/**
 * LobsterAI（有道龙虾）产品配置。
 *
 * ## 为什么不复用 `BuddyProduct`
 *
 * `src/product.ts` 的 `BuddyProduct` 是**围绕 CodeBuddy 系协议**设计的，
 * 它的这些字段对 LobsterAI 完全无意义：
 *
 * - `productCode` / `attributionName` / `clientVersion` / `cliVersion`
 *   —— LobsterAI 不发 `X-Product*` / `X-IDE-*` 归属头，
 *   只发 `X-LobsterAI-Client-*`；
 * - `apiDomain`（`X-Domain` 头）—— 无此头；
 * - `userAgentByModelFamily` —— 那是腾讯后台按 UA 归因的机制；
 * - `appendSessionParams` / `pluginVersion` —— WorkBuddy 登录 URL 的后缀参数。
 *
 * 且 `BuddyProduct.id` 是字面量联合 `'buddy' | 'workbuddy'`，加第三个值会牵动
 * `productById` / `registerBuddyLlm` / `reconcileWithFallback` 一串调用点。
 *
 * 因此这里定义**平行**的 `LobsteraiProduct`：共用的是架构**模式**
 * （产品差异收敛到单一真相源），不是那个类型。
 *
 * ## 数据来源
 *
 * - API 基址 / 版本号接口：`lobsterai2api/sigin.py:10-11`（实测可用）；
 * - 端点路径与请求头：`lobsterai2api/internal/upstream/client.go`；
 * - 兜底模型表：**2026-10-09 用真实凭据重采** `GET /api/models/available`
 *   （30 条）。旧表是 `lobsterai2api/internal/server/handler.go:94-114` 的
 *   19 条编译期快照（注释标称 2026-08-06），实测已严重过期 —— 详见
 *   {@link LOBSTERAI_FALLBACK_MODELS} 的注释；
 * - portal 基址：本次实测确认（见下）。
 */

/**
 * 兜底模型目录中的一个条目。
 *
 * 与 `BuddyFallbackModel` 分开定义。注意**不要把这里的 `contextWindow` 当成
 * 远端权威值**：远端 `GET /api/models/available` 其实**会**返回
 * `contextWindow`（2026-09-17 实测多数为 `1000000`），只是本适配器当前尚未
 * 解析消费它（见 `LobsteraiRemoteModel` 的说明）。因此这里的值是**纯本地
 * 估计值**，且只在本表被用到时（远端整体失败）才生效。
 */
export interface LobsteraiFallbackModel {
  /** 模型 ID（传给 `POST /api/proxy/v1/chat/completions` 的 `model`）。 */
  id: string
  /** 展示名（2026-10-09 起改用**远端下发的 `modelName`**，不再是裸 id）。 */
  name: string
  /**
   * 上下文窗口。
   *
   * ⚠️ **2026-10-09 起以远端权威值为准**（旧表统一填 131072，是桥接层的估值）。
   * 远端 `GET /api/models/available` 会下发 `contextWindow`（实测 30 条里 21 条有值，
   * 多数为 `1000000`）；未下发的那 9 条才沿用 131072 估值。
   *
   * 采信远端值的必要性见 `lobsterai-adapter.ts` 的 `contextWindowFor`：
   * 用偏小的估值会让 DSH 在远未用满窗口时就触发上下文压缩。
   */
  contextWindow: number
}

/**
 * 上游 API 基址。
 *
 * `sigin.py:10` 硬编码 `https://lobsterai-server.youdao.com`；Go 侧被
 * 脱敏成 env `LB2A_UPSTREAM_BASE`（无编译期默认值）。
 * 本插件按文档 §0.2b 的结论固化在常量里 —— 插件面向终端用户，
 * 不应要求用户自行提供域名。
 */
export const LOBSTERAI_API_BASE = 'https://lobsterai-server.youdao.com'

/**
 * 登录 portal 基址。
 *
 * 实测（见文档 §0.2b）：与 `LOBSTERAI_API_BASE` **同一 IP、同一 CNAME 目标**
 * （`pub-g1-gz.alb.ntes53.netease.com`），说明是同一套服务的不同路径；
 * 访问 `{portalBase}/portal` 返回 HTTP 200，页面标题
 * 「LobsterAI - 全场景个人助理 Agent」，与 `cmd/login/main.go:226` 拼出的
 * `{portal}/portal#/login?...` 路径吻合。
 *
 * 之所以仍与 `apiBase` 分成两个字段：Go 侧本就是两个独立 env，
 * 且不排除未来门户与 API 分离部署。
 */
export const LOBSTERAI_PORTAL_BASE = 'https://lobsterai.youdao.com'

/**
 * 客户端版本号查询端点（第三方域名）。
 *
 * 注意该响应**不是**统一信封：`code`/`msg` 在**外层**，载荷在 `data.value`。
 * 实测（2026）返回 `version: "2026.9.4"`（日期式版本号）。
 */
export const LOBSTERAI_CLIENT_VERSION_API
  = 'https://api-overmind.youdao.com/openapi/get/luna/hardware/lobsterai/prod/update'

/**
 * 无法动态取到版本号时的兜底值。
 *
 * `sigin.py:73-76` 在取不到版本号时**整个脚本放弃签到**；本插件比它宽容：
 * 用这个兜底值继续尝试，并在日志里警告。理由是宁可用一个稍旧的版本号试，
 * 也别让用户完全无法签到 —— 后端对 `version` 并不强校验
 * （反证：Go 侧一直发假值 `0.1.0` 也未导致失败）。
 *
 * 取值来自 2026 年实测的最后一个已知版本；随着客户端更新会逐渐变旧。
 */
export const LOBSTERAI_FALLBACK_CLIENT_VERSION = '2026.9.4'

/**
 * 客户端能力声明（`X-LobsterAI-Client-Capabilities` 头）。
 *
 * 两个能力**都必须声明**，各自解决一个具体问题（2026-09-17 真实凭据实测）：
 *
 * - `kimi-k3-agentic-v1`：**模型列表的准入条件**。不带该能力时
 *   `/api/models/available` 只返回 25 个模型且**没有 `kimi-k3`**；带上才 26 个。
 *   该值来自 `internal/upstream/client.go:99` 的硬编码。
 * - `thinking-level-control-v1`：**思考档位协议的前提**。`reasoning_effort`
 *   的常规档位（low/high/max/xhigh）不需要它，但 `"off"`（关闭思考）
 *   在**不带**该能力时服务端直接 HTTP 500（`{"code":500,"message":"服务器内部错误"}`），
 *   带上则正常返回。也就是说「关掉思考」这条协议要先声明支持它。
 *
 * 顺序无关（两种顺序都实测通过），但保持与 IDE 的
 * `LOBSTERAI_CLIENT_CAPABILITIES`（`modelRuntimeProfiles.js`）一致的排列。
 */
export const LOBSTERAI_CLIENT_CAPABILITIES
  = 'kimi-k3-agentic-v1,thinking-level-control-v1'

/**
 * User-Agent。
 *
 * 原样照抄 `client.go:21` 的 `clientUA = "LobsterAI/0.1.0"`。
 *
 * **刻意不跟着真版本号改**：Go 侧用这个 UA 是实测可用的，而
 * `X-LobsterAI-Client-Version` 头用真值 `2026.9.4`（见下方说明）。
 * 若同时改两处，一旦服务端行为变化将无法归因是哪一个导致的，
 * 故先只改有确定依据的那一个（版本头），UA 待单独实测。
 */
export const LOBSTERAI_USER_AGENT = 'LobsterAI/0.1.0'

/**
 * LobsterAI 产品配置。
 *
 * 与 `BuddyProduct` 平行，字段全部为 LobsterAI 实际需要的。
 */
export interface LobsteraiProduct {
  /** provider 标识：注册到 `ctx.llm` 的路由名，也是账号列表的 provider 字段值。 */
  id: 'lobsterai'
  /** 设置页 / 模型选择器展示名。 */
  displayName: string
  /** 登录门户基址（不含 `/portal` 路径）。 */
  portalBase: string
  /** 上游 API 基址（不含路径）。 */
  apiBase: string
  /** 客户端版本号查询端点。 */
  clientVersionApi: string
  /** 版本号动态拉取失败时的兜底值。 */
  fallbackClientVersion: string
  /** `User-Agent` 头取值。 */
  userAgent: string
  /** `X-LobsterAI-Client-Capabilities` 头取值。 */
  clientCapabilities: string
  /** 默认凭据 ref（无账号池时的单凭据回退）。 */
  defaultCredentialRef: string
  /**
   * 单张请求图片的像素预算（issue !IKITT9）。
   *
   * ⚠️ LobsterAI 撞的是**请求体体积**：实测 12 张 2560×1600 原图能过、
   * 13 张（≈50 MiB）回 `SERVER code=500 服务器内部错误`。
   * 那**不是**准入报文（腾讯会明确回 `prompt is too long: N tokens > M maximum`），
   * 所以别把它当成「图片 token 预算」来定值 —— 它是体积压垮了上游。
   * 未配置时适配器用 `DEFAULT_IMAGE_PIXEL_BUDGET`。
   */
  imagePixelBudget?: number
  /** 单张请求图片的编码字节目标（未配置用 1 MiB，见 `src/image-budget.ts`）。 */
  imageMaxBytes?: number
  /** 远端模型列表不可用时的兜底模型目录。 */
  fallbackModels: readonly LobsteraiFallbackModel[]
}

/**
 * 兜底模型目录（**30 个**，2026-10-09 按远端实测重采）。
 *
 * ## 2026-10-09 全表更新
 *
 * 旧表是 19 条的编译期快照（抄自 `lobsterai2api` 桥接层的 `staticModels`，
 * 注释标称 2026-08-06），实测已**严重过期**：远端 `GET /api/models/available`
 * 现返回 **30 条**，其中 **12 条**是旧表完全没有的（`glm-5.3` 系、`qwen3.8` 系、
 * `kimi-k3` / `kimi-k2.8-preview`、`deepseek-flash`、`deepseek-v4-flash-vision-exp`、
 * `MiniMax-M3.1-Flash-Preview`、`doubao-seed-2-1-pro-260915`），
 * 另有 **1 条**已被上游撤下（`doubao-seed-2-1-pro-260628` → 换成 `-260915`）。
 *
 * ⚠️ **兜底表过期是有实际后果的**：远端整体失败时（未登录、网络异常），
 * 用户会看到一张**少了 12 个可用模型**、且含 1 个已撤下模型的列表。
 *
 * 顺序**照抄远端返回顺序**，不重排 —— 它是实测时的返回顺序，重排会让
 * 「与上游对比」这类排查工作失去可比性。
 *
 * ## `contextWindow` 的取值口径（本次已按远端校正）
 *
 * 旧表**全部填 131072**，那是桥接层统一填的估值，**不是**逐个实测结果。
 * 本次改为**以远端下发的 `contextWindow` 为准**（21 条有值，多数为 `1000000`），
 * 仅远端未下发的那 9 条沿用 131072 估值并逐条标注。
 *
 * 采信远端值的必要性见 `lobsterai-adapter.ts` 的 `contextWindowFor`：
 * 用估值会让 DSH 在远未用满窗口时就触发上下文压缩。
 *
 * ⚠️ 兜底表**不含 `costMultiplier`**（设计如此，见适配器 `staticFallbackModels`）：
 * 它是编译期快照而价格会变，远端失败时宁可不显示倍率也不猜。
 */
const LOBSTERAI_FALLBACK_MODELS: readonly LobsteraiFallbackModel[] = [
  { id: 'deepseek-flash', name: 'DeepSeek-V4.1-Flash', contextWindow: 1_000_000 },
  { id: 'deepseek-v4-pro', name: 'DeepSeek-V4-Pro', contextWindow: 1_000_000 },
  { id: 'glm-5.3-flashx', name: 'GLM-5.3-FlashX', contextWindow: 1_000_000 },
  { id: 'glm-5.3-flash', name: 'GLM-5.3-Flash', contextWindow: 1_000_000 },
  { id: 'glm-5.3', name: 'GLM-5.3', contextWindow: 1_000_000 },
  { id: 'MiniMax-M3.1-Flash-Preview', name: 'MiniMax-M3.1-Flash-Preview', contextWindow: 1_000_000 },
  { id: 'MiniMax-M3', name: 'MiniMax-M3', contextWindow: 1_000_000 },
  { id: 'qwen3.8-max', name: 'Qwen3.8-Max', contextWindow: 1_000_000 },
  { id: 'qwen3.8-flash', name: 'Qwen3.8-Flash', contextWindow: 1_000_000 },
  { id: 'qwen3.8-omni-flash', name: 'Qwen3.8-Omni-Flash', contextWindow: 1_000_000 },
  { id: 'kimi-k3', name: 'Kimi-K3', contextWindow: 1_048_576 },
  { id: 'kimi-k2.8-preview', name: 'Kimi-K2.8-Preview', contextWindow: 262_144 },
  { id: 'kimi-k2.7-code', name: 'Kimi-K2.7-Code', contextWindow: 262_144 },
  { id: 'doubao-seed-2-1-pro-260915', name: 'Doubao-Seed-2.1-Pro', contextWindow: 256_000 },
  { id: 'deepseek-v4-flash-vision-exp', name: 'DeepSeek-V4-Flash-Vision-Exp', contextWindow: 1_000_000 },
  { id: 'deepseek-v4-flash', name: 'DeepSeek-V4-Flash', contextWindow: 1_000_000 },
  // 以下 9 条远端**未下发** `contextWindow`，沿用桥接层的保守估值 131072。
  { id: 'MiniMax-M2.7', name: 'MiniMax-M2.7', contextWindow: 131_072 },
  { id: 'qwen3.7-max', name: 'Qwen3.7-Max', contextWindow: 1_000_000 },
  { id: 'qwen3.7-plus', name: 'Qwen3.7-Plus', contextWindow: 1_000_000 },
  { id: 'qwen3.6-plus', name: 'Qwen3.6-Plus', contextWindow: 131_072 },
  // ⚠️ 远端展示名就是 `Qwen3.5-plus`（**不是** id 里的 `qwen3.5-plus-2026-04-20`）。
  { id: 'qwen3.5-plus-2026-04-20', name: 'Qwen3.5-plus', contextWindow: 131_072 },
  { id: 'kimi-k2.7-code-highspeed', name: 'Kimi-K2.7-Code-Highspeed', contextWindow: 262_144 },
  { id: 'kimi-k2.6', name: 'Kimi-K2.6', contextWindow: 131_072 },
  { id: 'kimi-k2.5', name: 'Kimi-K2.5', contextWindow: 131_072 },
  { id: 'glm-5.2', name: 'GLM-5.2', contextWindow: 1_000_000 },
  { id: 'glm-5.1', name: 'GLM-5.1', contextWindow: 131_072 },
  { id: 'glm-5v-turbo', name: 'GLM-5V-Turbo', contextWindow: 131_072 },
  { id: 'glm-5', name: 'GLM-5', contextWindow: 131_072 },
  { id: 'doubao-seed-2-1-turbo-260628', name: 'Doubao-Seed-2.1-Turbo', contextWindow: 256_000 },
  { id: 'doubao-seed-2-0-code-preview-260215', name: 'Doubao-Seed-2.0-Code', contextWindow: 131_072 },
]

/**
 * LobsterAI provider 配置。
 *
 * 与 CodeBuddy / WorkBuddy 并列的第三个产品线，但**协议完全不同**：
 * 它不走腾讯的 external-link 轮询登录，而是本地回调 + `authCode` 换 token。
 */
export const LOBSTERAI: LobsteraiProduct = {
  id: 'lobsterai',
  displayName: 'LobsterAI (有道)',
  portalBase: LOBSTERAI_PORTAL_BASE,
  apiBase: LOBSTERAI_API_BASE,
  clientVersionApi: LOBSTERAI_CLIENT_VERSION_API,
  fallbackClientVersion: LOBSTERAI_FALLBACK_CLIENT_VERSION,
  userAgent: LOBSTERAI_USER_AGENT,
  clientCapabilities: LOBSTERAI_CLIENT_CAPABILITIES,
  defaultCredentialRef: 'LOBSTERAI_ACCESS_TOKEN',
  fallbackModels: LOBSTERAI_FALLBACK_MODELS,
}

/** 全部 LobsterAI 产品配置（当前只有一个，保留数组以便将来扩展）。 */
export const ALL_LOBSTERAI_PRODUCTS: readonly LobsteraiProduct[] = [LOBSTERAI]

/**
 * 按 provider id 取 LobsterAI 产品配置；未知 id 返回 undefined。
 *
 * 与 `productById`（CodeBuddy 系）分开：两者返回**不同类型**，
 * 合并成一个函数会让调用方拿到联合类型后再也不得不做类型收窄。
 */
export function lobsteraiProductById(id: string): LobsteraiProduct | undefined {
  return ALL_LOBSTERAI_PRODUCTS.find((product) => product.id === id)
}
