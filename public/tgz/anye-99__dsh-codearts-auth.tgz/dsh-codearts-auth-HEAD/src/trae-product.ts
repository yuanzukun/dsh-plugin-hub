/**
 * TRAE（字节跳动 TRAE IDE）产品配置。
 *
 * ## 数据来源
 *
 * 基于对 `E:\Workplace\APP\Golang\trae2api` 的逆向分析（2026-08），
 * 以及上游项目 `Sliverkiss/traework2api` 的实测结果。
 *
 * - API 端点：`trae2api/internal/upstream/constants.go`（实测可用的 SOLO 免费通道）；
 * - 客户端常量：同一文件，版本号 `0.1.52` / `20260811` 为实测可获取 glm-5.3 的最低版本；
 * - 兜底模型表：`trae2api/internal/server/handler.go:247-280` 的 staticModels；
 * - 登录 URL 格式：`trae2api/internal/server/login.go` 的 `BuildLoginURL`。
 *
 * ## 为什么是独立接口而非复用 BuddyProduct/LobsteraiProduct
 *
 * TRAE 与二者都不同源：
 * - 与 BuddyProduct 差异：认证用 ExchangeToken（轮换 refreshToken）而非 external-link 轮询；
 *   请求头用 `Cloud-IDE-JWT` 而非 `Bearer`；chat 端点需要 payload 格式转换；
 *   SSE 格式自定（非 OpenAI 标准），需独立解析。
 * - 与 LobsteraiProduct 差异：chat 端点使用 POST + JSON body + 自定义 SSE；
 *   认证协议不同（OAuth code + ExchangeToken，non-localhost 可回调）；
 *   凭据中需持久化 machine_id/device_id 等设备指纹。
 *
 * 因此这里定义**平行**的 `TraeProduct`：共用的是架构模式（产品差异收敛到单一真相源），
 * 不是那个类型。
 */

/**
 * 兜底模型目录中的一个条目（对齐 Go 端 staticModels 格式）。
 *
 * 数据来源：`handler.go:247-280`（2026-08 实测快照）。
 * 远端 `batch_get_detail_param` 拉取失败时用此表回退。
 *
 * ⚠️ **数值是估值**（采信实测主流值 `contextWindow=200000`），远端可用时
 * **完全采信远端**的 `context_window_tokens` 与 `max_tokens`。旧的 `131072` /
 * `maxOutputTokens: 128000` 是 2026-08 的估值，已被实测推翻（见 `AGENTS.md`）。
 */
export interface TraeFallbackModel {
  id: string
  name: string
  contextWindow: number
  /** 已知的上游内部/隐藏条目（远端不可用时也不该出现在目录里）。 */
  isHidden?: boolean
}

/**
 * TRAE 产品配置。
 *
 * 与 `LobsteraiProduct` / `BuddyProduct` 平行，字段全部为 TRAE 实际需要的。
 */
export interface TraeProduct {
  /** provider 标识：注册到 `ctx.llm` 的路由名，也是账号列表的 provider 字段值。 */
  id: 'trae'
  /** 设置页 / 模型选择器展示名。 */
  displayName: string
  /** 上游 API 基址（Agent 服务：对话 + 模型列表）。 */
  agentHost: string
  /** 签到/积分/Ug 基址。 */
  ugHost: string
  /** OAuth/认证基址（ExchangeToken / GetUserInfo）。 */
  oauthHost: string
  /** 登录门户基址。 */
  consoleHost: string
  /** 客户端 ID（OAuth2 的 client_id）。 */
  clientId: string
  /** App ID（请求头 X-App-Id）。 */
  appId: string
  /**
   * IDE 版本号（控制模型可用性：0.1.52 才能用 glm-5.3）。
   *
   * 版本号是「模型可用的准入条件」—— 上游按 `X-Ide-Version` / `X-App-Version-Code`
   * 决定哪些模型可以返回，版本过低时 glm-5.3 等新模型会报 `4001 param is invalid`。
   */
  ideVersion: string
  /** IDE 版本号代码（日期式，如 `20260811`）。 */
  ideVersionCode: string
  /** 设备品牌（请求头 X-Device-Brand）。 */
  deviceBrand: string
  /** 操作系统版本（请求头 X-OS-Version）。 */
  osVersion: string
  /**
   * **默认**对话通道（`function`），模型未标明所属通道时使用。
   *
   * ⚠️ 它不是「唯一的通道」——各通道模型集不同，真正的通道归属由远端目录
   * 的每条 `function` 决定（见 {@link channels}）。
   */
  function: string
  /**
   * 要拉取的**全部**对话通道，**顺序即优先级**。
   *
   * 真实 CN IDE 用 `batch_get_detail_param` 一次查 22 个 function，每个
   * function 各自一套模型目录；同一条目在不同通道的可用性（`is_custom_model`
   * / `is_invisible_to_user` / `config_switch`）**可以不同**，而且
   * **模型只在列出它的通道里可调用**（发错通道 → 流内 `4001`）。
   *
   * 这里只列**实测可调用**的通道，并让 `solo_work_lite` 排在首位以保持既有
   * 模型的通道不变（最小行为变更）；`solo_agent_remote` 补上 agent 专有模型
   * （`glm-5.1` / `qwen-3.5` / `Doubao-Seed-Code`）与 1M 上下文声明。
   *
   * 可用 `DSH_TRAE_CHANNELS`（逗号分隔）覆盖以试验其它通道。
   */
  channels: readonly string[]
  /**
   * 远端不可用时的兜底输出上限（`max_tokens`）。
   *
   * 实测主流模型在远端声明的即为此值；远端可用时**以远端为准**。
   * 不放进 `fallbackModels` 逐条声明是因为各模型真实值并不一致
   * （4000 ~ 384000），逐条填只会编造出更细的假数据。
   */
  fallbackMaxOutputTokens?: number
  /**
   * 是否启用 **Max 模式**（1M 上下文）。**默认开启**，显式设 `DSH_TRAE_MAX_MODE=0` 关闭。
   *
   * 默认开的原因（用户要求）：上下文应当用**最大的那一档**。开启后只有远端
   * `display_config.max_mode === true` 的模型才会走 1M —— 未标记的模型即便
   * 开关为开也仍走常规 `dev`(200K)，见 `TraeAdapter.maxModeFor`，所以开启
   * 不会让任何模型失败。
   *
   * ⚠️ Max 会话向 1M 窗口里塞入远超常规的上下文，**计费倍率与常规会话不同**
   * （远端按 `strategy=max` 单独计价）。需要省额度时设 `DSH_TRAE_MAX_MODE=0`。
   *
   * 与 `Trae2api-cn` 的 `TRAE_REMOTE_MAX_MODE` 同名（但那边默认 `0`，本插件
   * 按用户要求改为默认开）。
   */
  maxMode?: boolean
  /**
   * Max 模式白名单（逗号分隔，`DSH_TRAE_MAX_MODELS`）。留空 = 所有
   * `max_mode=true` 的模型都生效；含 `*` 亦表示全部。
   *
   * 对齐 `Trae2api-cn` 的 `TRAE_REMOTE_MAX_MODELS`。
   */
  maxModeModels?: readonly string[]
  /**
   * @deprecated **不再生效**。`is_invisible_to_user` 过滤已移至
   * `parseTraeBatchModelList` 作为硬性过滤执行，不再由本开关控制。保留字段
   * 仅为避免破坏现有 profile 配置中显式设置了该值的用户。
   */
  hideInternalModels?: boolean
  /**
   * 登录 URL 的 `plugin_version` 参数（**不是** IDE 版本号）。
   *
   * 实测值 `2.3.62834`（`login.sh:54`）—— 与 `ideVersion` 是两个独立字段：
   * 前者是登录门户认的插件版本，后者是 chat 端点的模型准入版本。
   */
  pluginVersion: string
  /** 默认凭据 ref（无账号池时的单凭据回退）。 */
  defaultCredentialRef: string
  /** User-Agent。 */
  userAgent: string
  /** 远端模型列表不可用时的兜底模型目录。 */
  fallbackModels: readonly TraeFallbackModel[]
}

/** 上游 API 基址（Agent 服务）。 */
export const TRAE_AGENT_HOST = 'https://trae-api-cn.mchost.guru'
/** 签到/积分/Ug 基址。 */
export const TRAE_UG_HOST = 'https://api.trae.cn'
/** OAuth/认证基址。 */
export const TRAE_OAUTH_HOST = 'https://api.trae.com.cn'
/** 登录门户基址。 */
export const TRAE_CONSOLE_HOST = 'https://www.trae.cn'

/**
 * 兜底模型目录（**52 个**，2026-10-09 按远端实测补充）。
 *
 * 来源：`handler.go:247-280` 的 32 条快照 + **2026-10-09 远端实测新增 20 条**。
 * 顺序照抄 Go 端，不重排；远端可用时完全采信远端，本表只在远端整体失败时顶替。
 *
 * ## 2026-10-09 更新内容
 *
 * 1. **新增 20 条远端实测可用、而旧表缺失的模型**（`qwen3.8-max`、`glm-5.3` 系、
 *    `mimo-v2.6-*`、`step-5-preview`、`deepseek-v4.1-flash`、`kimi-k2.8-preview`
 *    等）。旧表缺失它们意味着**远端失败时用户会少看到 20 个可用模型**。
 * 2. **修正 3 条 `Doubao-Seed-*` 的 `contextWindow`**：远端实测为 **256000**
 *    （旧表统一填 200000）。⚠️ `Doubao-Seed-2.0-Code` **保持 200000** ——
 *    实测它在远端**未下发 `context_length`**（`ctx=-`），按「不猜」口径不动它。
 * 3. **保留** `seed-code-pro-0430` / `glm-5-turbo` / `sagitta` / `aquila` 与 10 条
 *    `custom_model_*`：本次采样未出现它们，但按红线**「某次没看到 ≠ 不存在」**
 *    不删（TRAE 的返回取决于请求的 `functions` 集合，我们无法穷举所有通道）。
 *
 * ⚠️ **已知的通道口径问题（未在本表解决，需实测确认）**：`batch_get_detail_param`
 * 的返回**取决于请求的 functions 集合** —— 生产口径（22 个 function）与
 * 仅请求 3 个聊天通道的结果不同：后者才含 `solo_agent_remote` 的条目，
 * 前者会把 `minimax-m3` / `mimo-v2.6-*` / `qwen-3.7-plus` 归到 `solo_work_lite`。
 * 而 `src/trae.ts` 记的实测判据是「`glm-5.1` 在 `solo_work_lite` 报 4001」。
 * 该问题属**协议层**（`trae-auth.ts` 的 functions 列表），不是模型表问题，
 * 且改动后必须配一次真实推理验证，故本次未动。复核脚本：
 * `scripts/probe-trae-channels.mjs`（打印两口径的通道归属差异）。
 */
const TRAE_FALLBACK_MODELS: readonly TraeFallbackModel[] = [
  { id: 'DeepSeek-V4-Flash-Official', name: 'DeepSeek V4 Flash Official', contextWindow: 200_000 },
  { id: 'Doubao-Seed-2.1-Pro', name: 'Doubao Seed 2.1 Pro', contextWindow: 256_000 },
  { id: 'seed-code-pro-0430', name: 'Seed Code Pro 0430', contextWindow: 200_000 },
  { id: 'Doubao-Seed-2.1-Turbo', name: 'Doubao Seed 2.1 Turbo', contextWindow: 256_000 },
  { id: 'Doubao-Seed-2.0-Code', name: 'Doubao Seed 2.0 Code', contextWindow: 200_000 },
  { id: 'browser_use_subagent', name: 'Browser Use Subagent', contextWindow: 200_000, isHidden: true },
  { id: 'glm-5.2', name: 'GLM-5.2', contextWindow: 200_000 },
  { id: 'glm-5-turbo', name: 'GLM-5 Turbo', contextWindow: 200_000 },
  { id: 'glm-5', name: 'GLM-5', contextWindow: 200_000 },
  { id: 'DeepSeek-V4-Pro', name: 'DeepSeek V4 Pro', contextWindow: 200_000 },
  { id: 'DeepSeek-V4-Flash', name: 'DeepSeek V4 Flash', contextWindow: 200_000 },
  { id: 'kimi-k3', name: 'Kimi K3', contextWindow: 200_000 },
  { id: 'kimi-k2.7-code', name: 'Kimi K2.7 Code', contextWindow: 200_000 },
  { id: 'kimi-k2.6', name: 'Kimi K2.6', contextWindow: 200_000 },
  { id: 'minimax-m3', name: 'MiniMax M3', contextWindow: 200_000 },
  { id: 'qwen-3.7-plus', name: 'Qwen 3.7 Plus', contextWindow: 200_000 },
  // ── 2026-10-09 远端实测新增（19 条）──
  // 窗口取自远端下发的 `context_length`（多数为 200000，Doubao 系为 256000）。
  { id: 'qwen3.8-max', name: 'Qwen3.8 Max', contextWindow: 200_000 },
  { id: 'qwen3.8-flash', name: 'Qwen3.8 Flash', contextWindow: 200_000 },
  { id: 'glm-5.3', name: 'GLM-5.3', contextWindow: 200_000 },
  { id: 'glm-5.3-flash', name: 'GLM-5.3-Flash', contextWindow: 200_000 },
  { id: 'glm-5.3-flashx', name: 'GLM-5.3-FlashX', contextWindow: 200_000 },
  { id: 'glm-5.1', name: 'GLM-5.1', contextWindow: 200_000 },
  { id: 'glm-5v-turbo', name: 'GLM-5V-Turbo', contextWindow: 200_000 },
  { id: 'deepseek-v4.1-flash', name: 'DeepSeek-V4.1-Flash', contextWindow: 200_000 },
  { id: 'DeepSeek-V4-Pro-Official', name: 'DeepSeek V4 Pro Official', contextWindow: 200_000 },
  { id: 'kimi-k2.8-preview', name: 'Kimi K2.8 Preview', contextWindow: 200_000 },
  { id: 'kimi-k2.5', name: 'Kimi K2.5', contextWindow: 200_000 },
  { id: 'mimo-v2.6-flash', name: 'MiMo V2.6 Flash', contextWindow: 200_000 },
  { id: 'mimo-v2.6-pro', name: 'MiMo V2.6 Pro', contextWindow: 200_000 },
  { id: 'step-5-preview', name: 'Step 5 Preview', contextWindow: 200_000 },
  { id: 'minimax-m2.7', name: 'MiniMax M2.7', contextWindow: 200_000 },
  { id: 'qwen-3.6-plus', name: 'Qwen 3.6 Plus', contextWindow: 200_000 },
  { id: 'qwen-3.5', name: 'Qwen 3.5', contextWindow: 200_000 },
  { id: 'Doubao-Seed-Code', name: 'Doubao Seed Code', contextWindow: 256_000 },
  { id: 'Doubao-Seed-Evolving', name: 'Doubao Seed Evolving', contextWindow: 256_000 },
  { id: 'doubao_1_8', name: 'Doubao 1.8', contextWindow: 200_000 },
  // ── 旧表保留条目（本次采样未出现，按「某次没看到 ≠ 不存在」不删）──
  { id: 'sagitta', name: 'Sagitta', contextWindow: 200_000 },
  { id: 'aquila', name: 'Aquila', contextWindow: 200_000 },
  { id: 'custom_model_gemini', name: 'Custom Gemini', contextWindow: 200_000 },
  { id: 'custom_model_placeholder', name: 'Custom Placeholder', contextWindow: 200_000 },
  { id: 'custom_model_1M_text', name: 'Custom 1M Text', contextWindow: 200_000 },
  { id: 'custom_model_1M', name: 'Custom 1M', contextWindow: 200_000 },
  { id: 'custom_model_kimi', name: 'Custom Kimi', contextWindow: 200_000 },
  { id: 'custom_model_claude', name: 'Custom Claude', contextWindow: 200_000 },
  { id: 'custom_model_gpt-5', name: 'Custom GPT-5', contextWindow: 200_000 },
  { id: 'custom_model_no-fc', name: 'Custom No-FC', contextWindow: 200_000 },
  { id: 'custom_model_deepseek_chat', name: 'Custom DeepSeek Chat', contextWindow: 200_000 },
  { id: 'custom_model_deepseek_reasoner', name: 'Custom DeepSeek Reasoner', contextWindow: 200_000 },
  { id: 'custom_model_deepseek_v4', name: 'Custom DeepSeek V4', contextWindow: 200_000 },
  { id: 'explore_sub_agent_v13', name: 'Explore Sub Agent V13', contextWindow: 200_000, isHidden: true },
  { id: 'explore_sub_agent_v2', name: 'Explore Sub Agent V2', contextWindow: 200_000, isHidden: true },
  { id: 'summary', name: 'Summary', contextWindow: 200_000, isHidden: true },
]

/**
 * 要拉取的对话通道（顺序即优先级）。
 *
 * 默认含三个实测可调用通道：
 * - `solo_agent`：**首位**，对应截图 Auto Mode 的模型列表（`function_configs`
 *   中 `function: "solo_agent"` 的 `config_info_list`）。包含最多的模型（约 66
 *   条），以及 `display_contact_config` 折扣信息、`reasoning_effort_config` 等
 *   完整配置。
 * - `solo_work_lite`：本项目既有通道，`glm-5-turbo` / `sagitta` 等在此通道可用。
 * - `solo_agent_remote`：补上 agent 专有模型（`glm-5.1` / `qwen-3.5` 等）。
 *
 * 可用 `DSH_TRAE_CHANNELS`（逗号分隔）覆盖。
 */
export const TRAE_CHANNELS: readonly string[] = resolveChannelList(
  process.env.DSH_TRAE_CHANNELS,
)

/** 解析 `DSH_TRAE_CHANNELS`；空/非法时回退默认通道列表。 */
function resolveChannelList(raw: string | undefined): readonly string[] {
  const fallback: readonly string[] = ['solo_agent', 'solo_work_lite', 'solo_agent_remote']
  if (raw === undefined) return fallback
  const parsed = raw.split(',').map((item) => item.trim()).filter((item) => item.length > 0)
  return parsed.length > 0 ? parsed : fallback
}

/** 解析布尔型开关环境变量；只有显式真值才算开启。 */
function isTruthyFlag(raw: string | undefined): boolean {
  if (raw === undefined) return false
  const value = raw.trim().toLowerCase()
  return value === '1' || value === 'true' || value === 'yes'
}

/**
 * 解析 `DSH_TRAE_MAX_MODE`；**默认开启**（用户要求「上下文用最大的那一档」）。
 *
 * 只有显式假值（`0` / `false` / `no` / `off`）才关闭 —— 与
 * `isTruthyFlag` 的「默认关」语义相反，故单列一个函数，不要混用。
 */
function resolveMaxModeFlag(raw: string | undefined): boolean {
  if (raw === undefined) return true
  const value = raw.trim().toLowerCase()
  return !(value === '0' || value === 'false' || value === 'no' || value === 'off')
}

/**
 * 解析 `DSH_TRAE_MAX_MODELS` 白名单。
 *
 * 留空返回 `undefined`（而非空数组）：空数组在下游是「白名单存在但什么都不匹配」
 * 的语义，会把 Max 模式**全部**关掉，与「留空 = 全部生效」相反。
 */
function resolveMaxModeModels(raw: string | undefined): readonly string[] | undefined {
  if (raw === undefined) return undefined
  const parsed = raw.split(',').map((item) => item.trim()).filter((item) => item.length > 0)
  return parsed.length > 0 ? parsed : undefined
}

/**
 * TRAE provider 配置。
 */
export const TRAE: TraeProduct = {
  id: 'trae',
  displayName: 'TRAE (字节)',
  agentHost: TRAE_AGENT_HOST,
  ugHost: TRAE_UG_HOST,
  oauthHost: TRAE_OAUTH_HOST,
  consoleHost: TRAE_CONSOLE_HOST,
  clientId: 'en1oxy7wnw8j9n',
  appId: '6eefa01c-1036-4c7e-9ca5-d891f63bfcd8',
  ideVersion: '0.1.52',
  ideVersionCode: '20260811',
  deviceBrand: 'Apple',
  osVersion: 'macOS 15.7.4',
  function: 'solo_work_lite',
  channels: TRAE_CHANNELS,
  fallbackMaxOutputTokens: 32_000,
  maxMode: resolveMaxModeFlag(process.env.DSH_TRAE_MAX_MODE),
  maxModeModels: resolveMaxModeModels(process.env.DSH_TRAE_MAX_MODELS),
  hideInternalModels: isTruthyFlag(process.env.DSH_TRAE_HIDE_INTERNAL),
  pluginVersion: '2.3.62834',
  defaultCredentialRef: 'TRAE_ACCESS_TOKEN',
  userAgent: 'Trae/0.1.52',
  fallbackModels: TRAE_FALLBACK_MODELS,
}
