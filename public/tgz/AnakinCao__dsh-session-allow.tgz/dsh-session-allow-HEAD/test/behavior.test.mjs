import fs from 'node:fs';
const src = fs.readFileSync(new URL('../lib/client.js', import.meta.url), 'utf8');
let captured = null;
// window timers (component lifecycle)
const intervalCbs = new Map();
const timeoutCbs = new Map();
let nextTimer = 1;
const windowListeners = { pointerdown: [] };
const mockWindow = {
  setInterval: (cb) => { const id = nextTimer++; intervalCbs.set(id, cb); return id; },
  clearInterval: (id) => intervalCbs.delete(id),
  setTimeout: (cb) => { const id = nextTimer++; timeoutCbs.set(id, cb); return id; },
  clearTimeout: (id) => timeoutCbs.delete(id),
  addEventListener: (type, cb) => { (windowListeners[type] ??= []).push(cb); },
  removeEventListener: (type, cb) => { windowListeners[type] = (windowListeners[type] ?? []).filter((c) => c !== cb); },
  innerWidth: 1920,
  __ModuleLoader__: { load: (e) => { captured = e; } }
};
globalThis.window = mockWindow;
// localStorage (grant store)
const mem = new Map();
globalThis.localStorage = {
  getItem: (k) => (mem.has(k) ? mem.get(k) : null),
  setItem: (k, v) => mem.set(k, String(v)),
  removeItem: (k) => mem.delete(k)
};
// DOM mocks (approval panel rendering)
const collapseBtn = { clicks: 0, click() { this.clicks += 1; }, getAttribute: () => '\u5c55\u5f00\u4fa7\u8fb9\u680f' }; // 展开侧边栏 (closed -> never matches)
const rootEl = {};
globalThis.getComputedStyle = () => ({ marginRight: '0px' });
globalThis.document = {
  querySelector: (sel) => (sel === '#root' ? rootEl : null),
  querySelectorAll: () => [collapseBtn],
  createElement: () => ({ dataset: {}, style: {}, appendChild() {} }),
  head: { appendChild() {} },
  body: { appendChild() {} }
};
// react stubs
const react = {
  useMemo: (fn) => fn(),
  useState: (init) => [typeof init === 'function' ? init() : init, () => {}],
  useEffect: (fn) => { const r = fn(); if (typeof r === 'function') r(); },
  useRef: (init) => ({ current: init })
};
const jsx = (type, props) => ({ type, props });
const jsxs = (type, props) => ({ type, props });
const primitives = { Button: (props) => ({ button: props }) };
const runtime_client = { conversationContextKey: (k, id) => `${k}:${id}` };
const mockRequire = (spec) => {
  if (spec === 'react') return react;
  if (spec === 'react/jsx-runtime') return { jsx, jsxs };
  if (spec === '@deepseek-ai/dsh-client-ui-primitives') return primitives;
  if (spec === '@deepseek-ai/dsh-client-runtime/client') return runtime_client;
  throw new Error('unexpected require: ' + spec);
};
new Function('require', 'window', src)(mockRequire, globalThis.window);
const mod = captured.factory(mockRequire);
if (typeof mod.apply !== 'function' || !Array.isArray(mod.inject)) throw new Error('bundle exports broken');
let panelComp = null;
let slotOpts = null;
const ctx = {
  effect: (cb) => { const r = cb(); return typeof r === 'function' ? r : () => {}; },
  locale: { register: (ns, dicts) => { globalThis.__dicts = dicts; return () => {}; } },
  slots: { inject: (k, cb) => cb(), register: (opts, comp) => { slotOpts = opts; panelComp = comp; return () => {}; } }
};
mod.apply(ctx);
const zh = globalThis.__dicts.zh;
const t = (k, params) => { let s = zh[k] ?? k; for (const [p, v] of Object.entries(params ?? {})) s = s.replace(`{${p}}`, v); return s; };
const assert = (cond, msg) => { if (!cond) throw new Error('FAIL: ' + msg); console.log('  ok -', msg); };

assert(slotOpts.name === 'conversation.composer' && slotOpts.priority === 0, 'slot entry at priority 0');
const mkWait = (mode) => ({
  key: `a:${Math.random()}`, sessionId: 's1',
  payload: { toolName: 'pwsh', callId: 'c1', reason: `escalate sandbox to ${mode}: need it`, approvalId: 'x' },
  respond: async (msg) => { globalThis.__outcome = msg.value.outcome; return { accepted: true }; }
});
const render = (w) => panelComp({ matched: w, sessionId: 's1', useSession: (sel) => sel({ chat: { nodes: new Map() } }), t });

console.log('B1) ungranted renders 3 buttons');
let el = render(mkWait('danger-full-access'));
assert(el !== null && el.props.className === 'sa_root', 'panel renders');
const kids = el.props.children.props.children;
const row = kids.find((c) => c && c.type === 'div' && c.props && c.props.className === 'sa_actionRow');
const btns = row.props.children.filter(Boolean);
assert(btns.length === 3, 'three buttons');
assert(btns[2].props.children.includes('danger-full-access'), 'session-allow label carries mode');

console.log('B2) session-allow click grants + answers');
globalThis.__outcome = null;
btns[2].props.onClick();
assert(globalThis.__outcome === 'allowed-once', 'answered allowed-once');
assert(mem.get('dsh.sessionAllow.v1') === '{"s1":["mode:danger-full-access"]}', 'grant persisted');

console.log('B3) granted same-mode request auto-hides + auto-answers');
globalThis.__outcome = null;
el = render(mkWait('danger-full-access'));
assert(el === null, 'no dialog for granted mode');
assert(globalThis.__outcome === 'allowed-once', 'auto-answered');

console.log('B4) other mode still prompts with revocable chip');
el = render(mkWait('workspace-write'));
const kids2 = el.props.children.props.children;
const grants = kids2.find((c) => c && c.type === 'div' && c.props && c.props.className === 'sa_grants');
assert(grants !== undefined, 'grants row present');
const chip = grants.props.children.find((c) => c && c.type === 'span' && c.props && c.props.className === 'sa_grantChip');
const revokeBtn = chip.props.children.find((c) => c && c.type === 'button');
revokeBtn.props.onClick();
assert(mem.get('dsh.sessionAllow.v1') === '{}', 'revoke clears grant');

console.log('B5) after revoke, mode prompts again');
el = render(mkWait('danger-full-access'));
assert(el !== null && el.props.className === 'sa_root', 'prompts again');
console.log('BEHAVIOR REGRESSION PASSED');
