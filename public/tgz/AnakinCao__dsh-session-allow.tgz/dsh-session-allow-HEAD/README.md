# dsh-session-allow

> 简体中文: [README.zh.md](README.zh.md)

A DSH (DeepSeek Harness) Web GUI plugin that adds an **"Allow for this session"** option to the approval dialog.

When you pick it, a session-scoped, per-mode standing grant is recorded (persisted in `localStorage`, isolated by session id). Later escalation requests of the **same mode** in this session are auto-approved without a dialog; other modes keep prompting as usual.

## What it does

| Scenario | Behavior |
|---|---|
| A tool asks to escalate to `danger-full-access` | Dialog shows: **Reject / Allow once / Allow danger-full-access for this session** |
| You click "Allow for this session" | The current request is allowed and the mode is granted for this session |
| Same mode is requested again in this session | **Silently auto-approved, no dialog** |
| A different mode is requested (not yet granted) | Still prompts normally |
| Bottom of the dialog | Shows this session's granted modes as revocable chips (click × to revoke) |
| Page refresh / new session | Grants persist per session id / stay isolated per session |

## How it works (no core package changes)

The core approval panel is registered on the `conversation.composer` chain slot at priority 1. This plugin registers the same slot at **priority 0** with an identical selector — the chain slot elects the lowest-priority entry whose `select` returns non-null, so this panel fully replaces the core one. Grants live in `localStorage["dsh.sessionAllow.v1"]`; a matching request is auto-answered `allowed-once` on the wire (the host audit still records `approval/asked` + `approval/decided` as usual).

Grant keys: `mode:<mode>` (parsed from the reason `escalate sandbox to <mode>: ...`); non-escalation reasons fall back to `tool:<tool>:<reason>`.

## Install

Method 1 — recommended, one command (restart `dsh web` afterwards):

```bash
dsh plugin --profile web add https://github.com/AnakinCao/dsh-session-allow.git
```

Method 2 — manual: append to `~/.dsh/profiles/web/cordis.patch.yml`:

```yaml
- insert:
    - id: dsh-session-allow
      name: 'dsh-session-allow'
```

and place the repository content under `~/.dsh/profiles/web/node_modules/dsh-session-allow/` (or `pnpm add`), then restart dsh.

> Pick ONE method — never mount twice.

## Verify

1. The dialog shows three buttons: Reject / Allow once / Allow … for this session.
2. Click "Allow for this session" → the current request is allowed.
3. Trigger the same mode again → no dialog, executes directly.
4. The chips at the bottom show the granted mode; click × to revoke and the mode prompts again.
5. Open another session → that mode still prompts (grants are per-session).

## Uninstall

```bash
dsh plugin --profile web remove dsh-session-allow
```

or delete the `- insert` entry from the profile's `cordis.patch.yml` and remove `node_modules/dsh-session-allow`. Grant data lives in the browser's `localStorage["dsh.sessionAllow.v1"]` and can be cleared manually.

## File structure

```
dsh-session-allow/
├── package.json          # dsh.client / dsh.bundle declaration
├── cordis.patch.yml      # loader entry registration
├── lib/
│   ├── index.js          # host-side placeholder plugin
│   └── client.js         # client bundle (panel takeover + session grants)
├── test/
│   └── behavior.test.mjs # grant / auto-allow / revoke regression tests
└── README.md
```

## License

MIT
