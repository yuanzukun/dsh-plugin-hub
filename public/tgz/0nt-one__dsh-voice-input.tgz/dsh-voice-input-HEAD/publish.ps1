# dsh-voice-input-web — npm 发布脚本
#
# 前置条件（npm 政策要求，缺一不可）：
#   1. 已登录 npm：npm login（或本机已有有效凭据）
#   2. npm 账号必须开启 2FA（npm 强制要求发布者账号启用 2FA；
#      关闭 2FA 反而会发布失败：403 "two-factor authentication required"）
#   3. 手机验证器 App（Google Authenticator / Authy / 1Password 等）
#      已绑定 npm 账号，能看到每 30 秒变化的 6 位动态码
#
# 用法（在项目目录运行）：
#   powershell -ExecutionPolicy Bypass -File .\publish.ps1
#
# 或直接一条命令：
#   npm publish --otp=<验证器里的6位码>

$ErrorActionPreference = 'Stop'

Write-Host "`n=== dsh-voice-input-web publish ===" -ForegroundColor Cyan

# 1) 确认登录
$who = npm whoami 2>$null
if (-not $who) {
  Write-Host "未登录 npm，请先运行: npm login" -ForegroundColor Yellow
  exit 1
}
Write-Host "登录账号: $who"

# 2) 打包预演（可选，确认内容）
# npm pack --dry-run

# 3) 输入验证器动态码
$otp = Read-Host "请输入验证器 App 中的 6 位动态码"
if ($otp -notmatch '^\d{6}$') {
  Write-Host "验证码格式错误（应为 6 位数字）" -ForegroundColor Red
  exit 1
}

# 4) 发布
Write-Host "发布中..." -ForegroundColor Cyan
npm publish --otp=$otp
if ($LASTEXITCODE -eq 0) {
  Write-Host "`n发布成功: https://www.npmjs.com/package/dsh-voice-input-web" -ForegroundColor Green
} else {
  Write-Host "`n发布失败（验证码可能过期，30 秒后重试一次）" -ForegroundColor Red
  exit $LASTEXITCODE
}
