/* dsh-voice-input-web — client bundle (self-contained, zero deps).
 *
 * Self-contained artifact in the exact shape the official packages emit and
 * the shell kernel loads: window.__ModuleLoader__.load({ id, factory }).
 *
 * The factory registers one component into the composer's tool row through the
 * `conversation.input.right` slot (the seat for a control the user reaches on
 * the way to sending, right before the send button). Clicking the mic toggles
 * the browser's Web Speech API (SpeechRecognition / webkitSpeechRecognition,
 * Chrome & Edge): while listening, final results are appended to the message
 * draft via inputActions.setDraft, interim results stream in a small popover
 * above the button, and the recognition language can be switched inline
 * (zh-CN / en-US / auto). Preferences persist in localStorage.
 */
window.__ModuleLoader__.load({
	id: "dsh-voice-input-web",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });

		let react = require("react");
		let react_jsx_runtime = require("react/jsx-runtime");
		const { useState, useRef, useCallback, useEffect } = react;
		const { jsx, jsxs, Fragment } = react_jsx_runtime;

		// ---- identity & storage keys ----------------------------------------
		const SOURCE = "dsh-voice-input-web";
		const LANG_KEY = "dsh-voice-input-web.lang";
		const AUTO_SEND_KEY = "dsh-voice-input-web.autoSend";
		const DEFAULT_LANG = "zh-CN";
		const CSS_TAG_ID = SOURCE + "/VoiceInput.css";

		function readLang() {
			try {
				const v = localStorage.getItem(LANG_KEY);
				return v && v.length ? v : DEFAULT_LANG;
			} catch { return DEFAULT_LANG; }
		}
		function writeLang(v) {
			try { localStorage.setItem(LANG_KEY, v); } catch {}
		}
		function readAutoSend() {
			try {
				const v = localStorage.getItem(AUTO_SEND_KEY);
				return v === null ? false : v === "1";
			} catch { return false; }
		}

		const LANGUAGES = [
			{ id: "zh-CN", label: "中文" },
			{ id: "en-US", label: "English" },
			{ id: "auto", label: "自动" }
		];

		const SR = typeof window !== "undefined"
			? (window.SpeechRecognition || window.webkitSpeechRecognition || null)
			: null;

		const ERROR_TEXT = {
			"not-allowed": "麦克风权限被拒绝：请在地址栏点击麦克风图标，允许本页使用麦克风",
			"service-not-allowed": "语音识别服务不可用（可能被浏览器策略限制）",
			"no-speech": "没有听到声音，请靠近麦克风再说一次",
			"audio-capture": "没有检测到麦克风设备，请检查系统麦克风",
			"network": "语音识别需要联网，请检查网络后重试",
			"language-not-supported": "当前浏览器不支持该识别语言"
		};
		function errorText(code) {
			return ERROR_TEXT[code] || ("语音识别失败: " + code);
		}

		// ---- styles -----------------------------------------------------------
		const css = [
			".dvi_wrap{position:relative;display:flex;align-items:center}",
			".dvi_btn{display:flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:6px;border:1px solid transparent;background:transparent;color:var(--dsw-alias-label-secondary,#6b7280);cursor:pointer;padding:0;transition:background .15s,color .15s,transform .1s}",
			".dvi_btn:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(127,127,127,.14));color:var(--dsw-alias-label-primary,#1f2328)}",
			".dvi_btn:active{transform:translateY(1px)}",
			".dvi_listening{color:var(--dsw-alias-state-error-primary,#dc2626)!important;animation:dvi_pulse 1.2s ease-in-out infinite}",
			".dvi_listening:hover{background:var(--dsw-alias-interactive-bg-hover-danger,rgba(220,38,38,.12))}",
			"@keyframes dvi_pulse{0%,100%{opacity:1}50%{opacity:.4}}",
			".dvi_pop{position:absolute;right:0;bottom:calc(100% + 8px);min-width:230px;max-width:300px;background:var(--dsw-alias-bg-overlay,#f5f6f8);border:1px solid var(--dsw-alias-border-l2,rgba(0,0,0,.1));border-radius:8px;box-shadow:var(--dsw-shadow-lv3,0 6px 24px rgba(0,0,0,.35));padding:10px 12px;z-index:60;display:flex;flex-direction:column;gap:8px}",
			".dvi_status{font-size:13px;line-height:18px;color:var(--dsw-alias-label-primary,#1f2328);max-height:76px;overflow-y:auto;white-space:pre-wrap;word-break:break-all}",
			".dvi_err{color:var(--dsw-alias-state-error-primary,#dc2626)}",
			".dvi_langs{display:flex;gap:6px;flex-wrap:wrap}",
			".dvi_pill{font-size:12px;line-height:1;padding:4px 10px;border-radius:999px;border:1px solid var(--dsw-alias-border-l2,rgba(0,0,0,.1));background:transparent;color:var(--dsw-alias-label-secondary,#6b7280);cursor:pointer}",
			".dvi_pill:hover{color:var(--dsw-alias-label-primary,#1f2328)}",
			".dvi_pill.dvi_on{background:var(--dsw-alias-button-info-fill,#4176e6);border-color:transparent;color:#fff}",
			".dvi_done{align-self:flex-end;font-size:12px;padding:4px 12px;border-radius:6px;border:1px solid var(--dsw-alias-border-l2,rgba(0,0,0,.1));background:transparent;color:var(--dsw-alias-label-primary,#1f2328);cursor:pointer}",
			".dvi_done:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(127,127,127,.14))}"
		].join("\n");
		if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(CSS_TAG_ID) + "]") === null) {
			const tag = document.createElement("style");
			tag.dataset.plugin = SOURCE;
			tag.dataset.pluginCss = CSS_TAG_ID;
			tag.textContent = css;
			document.head.appendChild(tag);
		}

		// ---- mic icon ----------------------------------------------------------
		function MicIcon() {
			return jsx("svg", {
				viewBox: "0 0 24 24",
				width: 15,
				height: 15,
				fill: "none",
				stroke: "currentColor",
				strokeWidth: 2,
				strokeLinecap: "round",
				strokeLinejoin: "round",
				"aria-hidden": true,
				children: [
					jsx("path", { d: "M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" }),
					jsx("path", { d: "M19 10v2a7 7 0 0 1-14 0v-2" }),
					jsx("line", { x1: "12", y1: "19", x2: "12", y2: "23" }),
					jsx("line", { x1: "8", y1: "23", x2: "16", y2: "23" })
				]
			});
		}

		// ---- the composer voice-input control ----------------------------------
		function VoiceInput({ input, inputActions }) {
			const setDraft = inputActions && inputActions.setDraft;
			const submit = inputActions && inputActions.submit;
			const [listening, setListening] = useState(false);
			const [interim, setInterim] = useState("");
			const [error, setError] = useState(null);
			const [lang, setLang] = useState(readLang);

			const recRef = useRef(null);
			const langRef = useRef(lang);
			const draftRef = useRef((input && input.draft) || "");
			draftRef.current = (input && input.draft) || "";
			const baseRef = useRef("");
			const finalCountRef = useRef(0);
			const hadErrorRef = useRef(false);
			const restartRef = useRef(false);

			const stopRec = useCallback(() => {
				const rec = recRef.current;
				if (rec) {
					try { rec.stop(); } catch {}
				}
			}, []);

			const startRec = useCallback(() => {
				if (recRef.current) return;
				if (!SR) {
					setError("当前浏览器不支持语音识别，请使用 Chrome 或 Edge");
					return;
				}
				setError(null);
				hadErrorRef.current = false;
				restartRef.current = false;
				baseRef.current = draftRef.current;
				finalCountRef.current = 0;

				let rec;
				try {
					rec = new SR();
				} catch (err) {
					setError("无法创建语音识别器: " + (err && err.message ? err.message : err));
					return;
				}
				const wanted = langRef.current;
				rec.lang = wanted === "auto" ? "" : wanted;
				rec.continuous = true;
				rec.interimResults = true;
				rec.maxAlternatives = 1;

				rec.onresult = (e) => {
					let interimText = "";
					for (let i = e.resultIndex; i < e.results.length; i++) {
						const result = e.results[i];
						const text = (result[0] && result[0].transcript) || "";
						if (result.isFinal) {
							if (text) {
								const next = baseRef.current ? baseRef.current + " " + text : text;
								baseRef.current = next;
								finalCountRef.current += 1;
								try { setDraft(next); } catch {}
							}
						} else {
							interimText += text;
						}
					}
					setInterim(interimText);
				};

				rec.onerror = (e) => {
					if (e && e.error === "aborted") return;
					hadErrorRef.current = true;
					const code = (e && e.error) || "unknown";
					setError(errorText(code));
					setInterim("");
				};

				rec.onend = () => {
					recRef.current = null;
					if (restartRef.current) {
						restartRef.current = false;
						startRec();
						return;
					}
					setListening(false);
					setInterim("");
					if (!hadErrorRef.current && readAutoSend() && finalCountRef.current > 0) {
						try { if (submit) submit(); } catch {}
					}
					finalCountRef.current = 0;
				};

				try {
					rec.start();
					recRef.current = rec;
					setListening(true);
				} catch (err) {
					setError("无法启动语音识别: " + (err && err.message ? err.message : err));
				}
			}, [setDraft, submit]);

			// stop recognition when this component unmounts
			useEffect(() => () => {
				const rec = recRef.current;
				if (rec) { try { rec.stop(); } catch {} }
			}, []);

			const toggle = () => {
				if (listening) stopRec();
				else startRec();
			};

			const handleLang = (id) => {
				if (id === langRef.current) return;
				writeLang(id);
				langRef.current = id;
				setLang(id);
				if (recRef.current) {
					restartRef.current = true;
					stopRec();
				}
			};

			if (!setDraft) return null;

			return jsx("div", {
				className: "dvi_wrap",
				children: [
					jsx("button", {
						className: "dvi_btn" + (listening ? " dvi_listening" : ""),
						type: "button",
						title: listening ? "停止聆听" : "语音输入（点击开始说话）",
						"aria-label": listening ? "停止语音输入" : "开始语音输入",
						"aria-pressed": listening,
						onClick: toggle,
						children: MicIcon()
					}),
					listening && jsx("div", {
						className: "dvi_pop",
						role: "status",
						children: [
							jsx("div", { className: "dvi_status" + (error ? " dvi_err" : ""), children: error || interim || "正在聆听…" }),
							jsx("div", { className: "dvi_langs", children: LANGUAGES.map((l) =>
								jsx("button", {
									className: "dvi_pill" + (l.id === langRef.current ? " dvi_on" : ""),
									type: "button",
									onClick: () => handleLang(l.id),
									children: l.label
								}, l.id)
							) }),
							jsx("button", { className: "dvi_done", type: "button", onClick: stopRec, children: "完成" })
						]
					})
				]
			});
		}

		/** Client plugin body: register the mic into the composer tool row. */
		function apply(ctx) {
			ctx.slots.inject("conversation.input.right", () => ctx.slots.register({
				name: "conversation.input.right",
				id: "voice-input",
				order: 95,
				label: "语音输入"
			}, VoiceInput));
		}

		exports.apply = apply;
		exports.inject = ["slots"];
		return module.exports;
	}
});
