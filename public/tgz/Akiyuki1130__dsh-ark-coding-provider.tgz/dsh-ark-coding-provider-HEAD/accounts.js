/**
 * 多账户池与轮换标记。
 *
 * 火山方舟 Coding Plan 的额度是**按账号**算的：一个账号的 5 小时窗口打满，
 * 换另一个账号的 key 就还能继续。所以适配器在发请求前按顺序解析可用账号，
 * 遇到「这个账号被限流/额度用尽/鉴权失败」就在**还没吐出任何内容之前**换下一个。
 *
 * 账户有两种来源，靠 `type` 区分：
 *
 * - `apikey`：用户直接粘一把方舟 API Key。它能打数据面（`/api/coding/v3`），
 *   但控制面（套餐额度、官方模型目录）不认 API Key —— 那两样只有 SSO 身份能查。
 * - `cli`：用户在设置页走 arkcli 的 SSO 登录。登录后在每个账户**独立的 HOME**
 *   下存一份 arkcli 身份，于是同一个进程里可以同时持有多个账号，互不打架
 *   （arkcli 的状态目录写死在 `$HOME/.arkcli`，没有环境变量可以改，所以隔离
 *   只能靠换 HOME）。这种账户既能取到 key 用于聊天，也能查套餐额度和模型目录。
 *
 * 标记（mark）是进程内的短时记忆：命中限流后让这个账号冷却一段时间，
 * 免得每个请求都先撞一次墙。冷却到期自动恢复，不需要用户做任何事。
 *
 * 这个模块刻意不依赖 cordis，也刻意不依赖 arkcli：账号由调用方解析好再传进来，
 * 标记只用一个 Map。`home` 为空表示"用默认位置"，具体路径由调用方决定。
 *
 * 末尾的 `sidebarQuotaState` 也是纯函数：它把"有没有能查额度的账户"翻译成
 * "左下角那张卡片该不该显示"。放在这里是因为判据的输入就是账户类型。
 *
 * @module dsh-ark-coding-provider/accounts
 */

/** 账户类型：用户手填的 API Key。 */
export const TYPE_API_KEY = 'apikey'
/** 账户类型：arkcli SSO 登录（带独立 HOME）。 */
export const TYPE_CLI = 'cli'
/** 允许出现在配置里的账户类型。 */
export const ACCOUNT_TYPES = [TYPE_API_KEY, TYPE_CLI]

/** 配置里单个账户 id 允许出现的字符；其余一律换成 `_`。 */
const ID_SAFE = /[^A-Za-z0-9._-]/g

/**
 * 归一化账户 id。
 *
 * **全仓库唯一实现**（`arkcli.js` 直接 re-export 这一份）。以前 `accounts.js` 与
 * `arkcli.js` 各写了一份，规则还不一样：一个截断到 64 字符、空值回退 `account`，
 * 另一个不截断、回退 `default`。于是一个超过 64 字符的手写 id，会得到两个不同的
 * HOME —— 登录写在 A、聊天去 B 找 key，表现为"登录成功了但一直说没登录"。
 * alias 的两条路径必须落在同一个目录上，所以只留一份。
 *
 * 账户 id 会参与两个危险的地方：一是 CLI 账户的 HOME 目录名，二是设置页的键。
 * 所以这里只放行 `[A-Za-z0-9._-]`，并且干掉前导点 —— `../` 这类输入必须
 * 变成一个普通目录名，而不是逃出账户根目录。
 *
 * @param raw - 任意账户 id（可能含中文、斜杠、超长、空值）。
 * @param fallback - 清洗后为空时用的名字。
 */
export function sanitizeAccountId(raw, fallback = 'default') {
  const text = typeof raw === 'string' ? raw.trim() : ''
  const cleaned = text.replace(ID_SAFE, '_').replace(/^\.+/, '').slice(0, 64)
  return cleaned === '' ? fallback : cleaned
}

/** 账户类型归一化：认不出来的按 apikey 处理（旧配置没有 type 字段）。 */
export function normalizeAccountType(raw) {
  return raw === TYPE_CLI ? TYPE_CLI : TYPE_API_KEY
}

/** 一个账户的显示名：用户填了就用用户的，否则给一个能区分开的名字。 */
export function defaultAccountLabel(account, index) {
  if (account.type === TYPE_CLI) return `CLI 账户 ${index + 1}`
  return `API Key 账户 ${index + 1}`
}

/** 默认冷却时长：命中限流/额度后先躲 5 分钟（参考同类实现的量级）。 */
export const DEFAULT_COOLDOWN_MS = 5 * 60_000
/** 鉴权失败（key 错/被禁）的冷却更长：它不会自己好，但也不该永久封死。 */
export const AUTH_COOLDOWN_MS = 30 * 60_000

/**
 * 把配置里的账户列表归一化成统一形状。
 *
 * **主要来源是配置里的 `accounts` 数组。** 另外有一条**兜底**：当 `accounts` 为空时，
 * 顶层 `apiKeyEnv`/`apiKey` 会被当成一个 id 为 `default` 的 API Key 账户。
 *
 * 为什么必须有这条兜底（2026-10-16 补回）：官方 Models 页给每个可配置 provider 都渲染
 * 一个密钥编辑器，它的目标 ref 是**从 provider 名推出来的**（`ark-coding` →
 * `ARK_CODING_API_KEY`），插件管不着。如果插件不读顶层字段，用户在官方卡片里粘了 key、
 * 界面显示"已配置"，聊天却报"一个可用账户都没有" —— 同一屏两张卡片互相打脸，
 * 而这是新用户第一条会踩的路。只在一个账户都没有时启用，所以多账户用户完全不受影响；
 * 把 `apiKeyEnv` 显式设成空串就等于关掉这条兜底。
 *
 * 返回的每个账户：
 *
 * - `id`：稳定标识，写入配置；CLI 账户的 HOME 目录名由它派生。
 * - `label`：显示名。用户没填就按类型给个序号名。
 * - `type`：`apikey` / `cli`。
 * - `ref`：凭据服务引用（只有 apikey 用得上）。
 * - `literal`：组合配置里直接写的密钥（只有 apikey 用得上）。
 * - `home`：CLI 账户的显式 HOME；为空表示"交给调用方按 id 派生"。
 *
 * @param config - 插件配置（已解 volatile 包装）。
 * @param fallbackRef - 兜底账户用的凭据引用名；空/非法时不出兜底账户。
 */
export function describeAccounts(config, fallbackRef) {
  const list = Array.isArray(config.accounts)
    ? config.accounts.filter((entry) => typeof entry === 'object' && entry !== null)
    : []

  const mapped = list.map((entry, position) => {
    const type = normalizeAccountType(entry.type)
    const id = sanitizeAccountId(entry.id, `account-${position + 1}`)
    const ref = type === TYPE_API_KEY
      ? (typeof entry.apiKeyEnv === 'string' && entry.apiKeyEnv !== ''
        ? entry.apiKeyEnv
        : `ARK_CODING_API_KEY_${position + 1}`)
      : ''
    const literal = type === TYPE_API_KEY && typeof entry.apiKey === 'string' && entry.apiKey.trim() !== ''
      ? entry.apiKey.trim()
      : undefined
    const label = typeof entry.label === 'string' && entry.label.trim() !== '' ? entry.label.trim() : ''
    const home = type === TYPE_CLI && typeof entry.home === 'string' && entry.home.trim() !== '' ? entry.home.trim() : undefined
    return {
      id,
      label: label === '' ? defaultAccountLabel({ type }, position) : label,
      labelIsCustom: label !== '',
      type,
      ref,
      literal,
      home,
    }
  })

  // 同一个 id 出现两次，两个账户就会共用同一个 HOME 与同一组派生缓存（额度/登录态
  // 串台、冷却互相影响）。手改配置很容易撞上，所以保留第一个、丢掉后来者。
  const seen = new Set()
  const accounts = []
  for (const account of mapped) {
    if (seen.has(account.id)) continue
    seen.add(account.id)
    accounts.push(account)
  }

  if (accounts.length === 0 && typeof fallbackRef === 'string' && fallbackRef !== '') {
    accounts.push({
      id: 'default',
      label: '默认账户',
      labelIsCustom: false,
      type: TYPE_API_KEY,
      ref: fallbackRef,
      literal: typeof config.apiKey === 'string' && config.apiKey.trim() !== '' ? config.apiKey.trim() : undefined,
      home: undefined,
    })
  }
  return accounts
}

/** 进程内的账号标记表：谁在冷却、为什么、到什么时候。 */
export class AccountMarks {
  constructor(now = () => Date.now()) {
    this.now = now
    /** @type {Map<string, {reason: string, until: number, at: number}>} */
    this.marks = new Map()
  }

  /** 记一个标记。`until` 是绝对时间戳。 */
  mark(id, reason, until) {
    this.marks.set(id, { reason, until, at: this.now() })
  }

  /** 清除一个标记（这个账号刚刚成功了）。 */
  clear(id) {
    this.marks.delete(id)
  }

  /** 这个账号现在可不可用。 */
  usable(id) {
    const mark = this.marks.get(id)
    if (mark === undefined) return true
    if (mark.until <= this.now()) {
      this.marks.delete(id)
      return true
    }
    return false
  }

  /** 面向设置页的标记快照（只读）。 */
  snapshot() {
    const out = {}
    for (const [id, mark] of this.marks) {
      if (mark.until <= this.now()) continue
      out[id] = { reason: mark.reason, until: mark.until, at: mark.at }
    }
    return out
  }
}

/**
 * 把失败归类成「要不要换账号」。
 *
 * - `AUTH`：这个 key 本身不可用（错、被禁、不属于本套餐）→ 换。
 * - `RATE_LIMIT` / `QUOTA`：这个账号的窗口打满了 → 换。
 * - 其余（上下文超限、内容不合规、参数错）换账号也没用，原样抛出去。
 *
 * @param code - DSH 的稳定失败码。
 * @returns 换账号的原因，或 undefined 表示不该换。
 */
export function rotationReasonFor(code) {
  if (code === 'AUTH' || code === 'INVALID_CREDENTIAL') return 'invalid-credential'
  if (code === 'RATE_LIMIT') return 'rate-limit'
  if (code === 'QUOTA' || code === 'ACCOUNT_QUOTA') return 'quota'
  return undefined
}

/** 一个原因对应的冷却时长。 */
export function cooldownFor(reason) {
  return reason === 'invalid-credential' ? AUTH_COOLDOWN_MS : DEFAULT_COOLDOWN_MS
}

/**
 * 排一次请求的账号顺序。
 *
 * 顺序：明确指定的账号 → 其余账号。冷却中的账号排到最后（而不是直接剔除），
 * 这样「所有账号都在冷却」时仍会尝试，而不是直接报「没有可用账号」。
 *
 * @param accounts - 已解析的账号（含 key）。
 * @param marks - 标记表。
 * @param preferredId - 配置里指定的当前账号 id，可选。
 * @returns 有序的可用账号。
 */
export function orderAccounts(accounts, marks, preferredId) {
  const usable = accounts.filter((account) => account.key !== undefined)
  const rank = (account) => {
    if (account.id === preferredId) return 0
    if (marks.usable(account.id)) return 1
    return 2
  }
  return [...usable].sort((left, right) => rank(left) - rank(right))
}

/** 从错误里取 ProviderRetryAfter（毫秒），用于把冷却调到服务端要求的时长。 */
export function retryAfterMsOf(failure) {
  const value = failure?.providerRetryAfterMs
  return typeof value === 'number' && Number.isFinite(value) && value > 0 ? value : undefined
}

/**
 * 解析 `sidebarQuota` 的三态。
 *
 * - `auto`（默认）：有能查到套餐额度的绑定（已登录的 CLI 账户，或一对填全的
 *   AK/SK）就显示卡片；两者都没有就不显示 —— 一张永远只写着"未配置"的常驻
 *   卡片没有信息量。
 * - `on` / `off`：用户在设置页里显式选的档位，永远压过自动判据。
 *
 * 单独成纯函数是为了能被离线测试钉死：这条规则决定卡片显示不显示，
 * 藏在 report 闭包里就只能靠真机去看。
 *
 * @param mode - 配置里的档位；无法识别时按 `auto`。
 * @param capable - 是否真的存在能查额度的绑定。
 */
export function sidebarQuotaState(mode, capable) {
  const normalized = mode === 'on' || mode === 'off' ? mode : 'auto'
  const bound = capable === true
  return {
    mode: normalized,
    capable: bound,
    show: normalized === 'on' ? true : normalized === 'off' ? false : bound,
  }
}
