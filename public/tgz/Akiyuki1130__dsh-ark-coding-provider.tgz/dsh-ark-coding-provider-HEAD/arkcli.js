/**
 * arkcli：官方 ARK CLI（`@volcengine/ark-cli`）的进程封装。
 *
 * ## 为什么要包一层外部进程
 *
 * 用户「扫码 / SSO 登录火山方舟」这件事没有公开 HTTP 接口，只有官方 CLI 会做。
 * 而 CLI 自带的是**控制面**能力：`auth status|whoami|login`、`usage plan`、
 * `models search`、`profile apikey get` —— 正好覆盖「按账号看真实套餐额度」与
 * 「把登录结果换成一把可用的 API key」这两件事。所以这里不重造协议，只封装进程。
 *
 * ## 为什么每个账号一个 HOME（而不是环境变量）
 *
 * arkcli 把自己的状态放在 `os.UserHomeDir()/.arkcli`，并且**没有任何环境变量可以
 * 覆盖**（没有 ARKCLI_HOME / ARK_HOME / XDG 之类）。实测：`HOME=/tmp/h1 arkcli auth
 * status` 用 `/tmp/h1/.arkcli`，与 `/tmp/h2/.arkcli` 完全独立。因此多账号隔离的
 * 唯一可靠做法就是**给子进程换 HOME**：账号 id 只经过白名单字符清洗后就变成目录名。
 * **Windows 上还要一起换 `USERPROFILE`**：Go 的 `os.UserHomeDir()` 不看 `HOME`，
 * 只设 HOME 的话每个账户都会读写宿主的 `%USERPROFILE%\.arkcli`，隔离直接失效。
 *
 * ## 为什么子进程要一份"最小环境"
 *
 * 如果直接继承父进程环境，宿主自己的 `ARK_API_KEY` / `ARK_PROFILE` / `ARK_BASE_URL`
 * / `VOLC_*` 会被 arkcli 当成"当前账号"读走：那样我们以为在查 A 账号，实际查的是
 * 宿主自己的账号，既串了数据也可能把宿主的凭据写进别的账号目录。所以子进程环境是
 * 白名单重建的，只有 PATH/HOME/LANG/LC_ALL/TMPDIR 与几个明确的 ARKCLI_* 开关。
 *
 * ## 为什么登录要"把回调 URL 转回环地址"
 *
 * `arkcli auth login --no-browser` 的实测行为（1.0.39）：在 **stderr** 打印一行提示
 * 加一行授权 URL（URL 里带 `callbackPort`），然后在 **127.0.0.1:<callbackPort>** 上
 * 起一个 HTTP 监听并**一直等**。它不读 stdin、不写 `.sso-pending.json`、也没有
 * `--code` 兑换（包内文档描述的两段式流程在这个构建里并不存在）。
 *
 * 用户在任意设备上打开授权 URL，SSO 完成后浏览器会被重定向到
 * `http://127.0.0.1:<port>/arkcli/broker/callback?...`。因为 DSH 服务端在远端，
 * 这次跳转在用户机器上必然失败，但**回调 URL 留在浏览器地址栏里**。用户把它粘回
 * 设置页，我们就在宿主机上把这条 GET 转发给回环监听，登录随即完成、子进程退出。
 *
 * 转发时 Host 头必须是 `127.0.0.1:<port>` —— 这是**实测**出来的，不是猜的：回环
 * 监听会校验 Host，`localhost:<port>`、裸 `127.0.0.1`、`[::1]:<port>`、端口差一个
 * 数字，全部被判 `invalid host`。详见 `submit()` 里的说明。
 *
 * 这就是本模块 `ArkCliLogin` 的全部职责：start（拿 URL）→ 用户操作 → submit（转发）。
 * 之所以不提供 `--code` 路径：那条路在这个构建里只会回「没有待完成的登录会话」，
 * 我们把它转成一句明确的提示，让用户改粘 URL。
 *
 * 转发那条 GET 用的是 `node:http` 而不是全局 fetch：Fetch 规范和 undici 会把 `Host`
 * 当 forbidden header 丢掉，而回环监听会校验它（详见 `createHttpFetch` 的说明）。
 *
 * 本模块是纯的：不 import cordis，不读全局配置，所有外部依赖（spawn / fetch / now）
 * 都可注入，因此可以离线单测。
 *
 * @module dsh-ark-coding-provider/arkcli
 */

import { spawn as nodeSpawn, spawnSync as nodeSpawnSync } from 'node:child_process'
import { createHash, randomBytes } from 'node:crypto'
import { chmodSync, existsSync, mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } from 'node:fs'
import { request as httpRequest } from 'node:http'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
// 账号 id 的清洗**只保留 accounts.js 那一份实现**：它在 accounts.js 里决定"聊天用哪个
// HOME"，在这里决定"登录写到哪个 HOME"，两处必须完全一致，否则超长 id 会分裂成两个目录。
import { sanitizeAccountId } from './accounts.js'

/** 官方 CLI 的 npm 包名。 */
export const ARKCLI_PACKAGE = '@volcengine/ark-cli'
/** SSO 回调路由。实测：其它路径 404，缺参数 400。 */
export const CALLBACK_PATH = '/arkcli/broker/callback'
/**
 * 安装时用的版本。
 *
 * **钉版本，不装 `latest`**：额度、官方目录、聊天用的 API key 三条链全都建立在
 * arkcli 的输出形状上（`usage plan --format json`、`models search`、
 * `profile apikey get`），而它的容错解析会让"字段改名"表现成"查不到额度"而不是
 * 明确报错。上游已经咬过一次（1.0.16 起关掉了 AK/SK 登录通道，见本文件另一处注释）。
 * 装 `latest` 等于每次点安装都绑定当天的最新版，且用户毫不知情。
 * 1.0.39 是本插件实测通过、并且当前这台机器正在用的版本。
 */
const DEFAULT_INSTALL_VERSION = '1.0.39'
/** 官方二进制的版本：与 {@link ARKCLI_BINARIES} 里的清单必须同步。 */
export const ARKCLI_BINARY_VERSION = DEFAULT_INSTALL_VERSION
/**
 * 官方 Go 二进制的下载清单（逐字节照抄 `@volcengine/ark-cli@1.0.39/manifest.json`）。
 *
 * **为什么不用 npm 装**：DSH 桌面端（Electron Node 模式）**不保证有 npm**——它只打包
 * 了 pnpm 供插件管理用，PATH 上未必有 node/npm。以前这里只会跑 `npm install --prefix`，
 * 在 Windows 桌面端就表现成"点安装没反应"。官方包的 postinstall 本来就是"按平台从
 * CDN 下一个二进制再校验 sha256"，这里把这一步直接做掉：不依赖 npm、不依赖 node，
 * 只需要宿主本来就有的 fetch。
 *
 * `fallback` 是官方包的 GitHub Release 兜底源；`sha256` 是官方清单里的校验值，
 * 校验不过就换下一个源，绝不落盘。
 */
export const ARKCLI_BINARIES = Object.freeze({
  'darwin-amd64': {
    url: 'https://lf3-static.bytednsdoc.com/obj/eden-cn/psjryh/ljhwZthlaukjlkulzlp/prod/1.0.39/arkcli-1.0.39-darwin-amd64',
    sha256: 'a7de0eec2db721cd19035d99c2d891a8f228d02313fb4020e941c6ad8345e809',
    fallback: 'https://github.com/volcengine/ark-cli/releases/download/v1.0.39/arkcli-1.0.39-darwin-amd64',
  },
  'darwin-arm64': {
    url: 'https://lf3-static.bytednsdoc.com/obj/eden-cn/psjryh/ljhwZthlaukjlkulzlp/prod/1.0.39/arkcli-1.0.39-darwin-arm64',
    sha256: '2bcb5bb92bbaf2864d6badfa665a93f247397141b21fc0c6bfd3a70eed99cacd',
    fallback: 'https://github.com/volcengine/ark-cli/releases/download/v1.0.39/arkcli-1.0.39-darwin-arm64',
  },
  'linux-amd64': {
    url: 'https://lf3-static.bytednsdoc.com/obj/eden-cn/psjryh/ljhwZthlaukjlkulzlp/prod/1.0.39/arkcli-1.0.39-linux-amd64',
    sha256: 'b15c597bf3ce02ffaceb17b9c8e28a2ffabee9daf21b60aa2c900c720ef28cb2',
    fallback: 'https://github.com/volcengine/ark-cli/releases/download/v1.0.39/arkcli-1.0.39-linux-amd64',
  },
  'linux-arm64': {
    url: 'https://lf3-static.bytednsdoc.com/obj/eden-cn/psjryh/ljhwZthlaukjlkulzlp/prod/1.0.39/arkcli-1.0.39-linux-arm64',
    sha256: 'a881be103f9493ed0ea63039af6e6c60cff037975b0e158b11f6278a3face011',
    fallback: 'https://github.com/volcengine/ark-cli/releases/download/v1.0.39/arkcli-1.0.39-linux-arm64',
  },
  'windows-amd64': {
    url: 'https://lf3-static.bytednsdoc.com/obj/eden-cn/psjryh/ljhwZthlaukjlkulzlp/prod/1.0.39/arkcli-1.0.39-windows-amd64.exe',
    sha256: '320377827569c3ac0ee78d8c6eaa054bfba1cae73b86b7af60e9d2ffa9408b7e',
    fallback: 'https://github.com/volcengine/ark-cli/releases/download/v1.0.39/arkcli-1.0.39-windows-amd64.exe',
  },
  'windows-arm64': {
    url: 'https://lf3-static.bytednsdoc.com/obj/eden-cn/psjryh/ljhwZthlaukjlkulzlp/prod/1.0.39/arkcli-1.0.39-windows-arm64.exe',
    sha256: '396dc276d81432956b6861b03bfcce98ca2ccdc2ee3eb012a6fb5a6436170ae4',
    fallback: 'https://github.com/volcengine/ark-cli/releases/download/v1.0.39/arkcli-1.0.39-windows-arm64.exe',
  },
})
/** 普通子命令默认超时。 */
const DEFAULT_RUN_TIMEOUT_MS = 60_000
/** 控制面查询（usage plan / models search）默认超时。 */
const DEFAULT_CONTROL_PLANE_TIMEOUT_MS = 120_000
/** 安装默认超时：直接下载约 40 MB 的官方二进制，慢网也要留够时间。 */
const INSTALL_TIMEOUT_MS = 300_000
/** 登录会话最长存活时间。 */
const LOGIN_TTL_MS = 10 * 60_000
/** 等授权链接出现的超时。 */
const LOGIN_START_TIMEOUT_MS = 30_000
/** 转发回调后等子进程退出的超时。 */
const LOGIN_WAIT_TIMEOUT_MS = 20_000
/** 安装 npm 时用的固定参数（安静、不审计、不写 funding 提示）。 */
const NPM_INSTALL_FLAGS = ['--no-audit', '--no-fund', '--loglevel=error']
/**
 * 单个子进程 stdout/stderr 的累积上限（字符）。
 *
 * 正常输出远小于这个数；但异常冗长的报错、日志疯跑、或者失控的子进程不该把
 * 宿主内存吃光。到达上限后停止累积（仍继续把流读干净，避免管道写满把子进程卡住）。
 */
const MAX_CHILD_OUTPUT_CHARS = 1_000_000
/**
 * 官方二进制的大小上限（正常 38–41 MB）。
 *
 * 整包先收进内存再校验 sha256；没有上限时，一个坏掉的 CDN / 被劫持的代理返回
 * 无限流就能把宿主内存吃光。上限给得比正常体积宽裕得多，不会误伤版本增长。
 */
const MAX_BINARY_BYTES = 256 * 1024 * 1024

// ---------------------------------------------------------------------------
// 路径
// ---------------------------------------------------------------------------

/** 本插件的状态根：`<dshHome>/ark-coding`。 */
export function arkcliStateRoot(dshHome) {
  return join(dshHome, 'ark-coding')
}

/** 托管安装目录：`<dshHome>/ark-coding/cli`。 */
export function managedInstallDir(dshHome) {
  return join(arkcliStateRoot(dshHome), 'cli')
}

/**
 * 直接下载安装后的可执行文件：`<installDir>/bin/arkcli[.exe]`。
 *
 * Windows 上没有扩展名的文件不会被 `CreateProcess` 当成可执行文件，所以必须是 `.exe`。
 */
export function managedBinaryPath(dshHome, platform = process.platform) {
  return join(managedInstallDir(dshHome), 'bin', platform === 'win32' ? 'arkcli.exe' : 'arkcli')
}

/** npm 安装留下的 shim：`<installDir>/node_modules/.bin/arkcli[.cmd]`（历史布局，仍然认）。 */
export function managedBinPath(dshHome, platform = process.platform) {
  return join(managedInstallDir(dshHome), 'node_modules', '.bin', platform === 'win32' ? 'arkcli.cmd' : 'arkcli')
}

/**
 * 托管目录里所有可能存在的 arkcli，按优先级排列。
 *
 * 第一个是直接下载的那份；后面是更早版本用 npm 装出来的 shim——已经装过的用户
 * 升级插件后不该突然"又没装了"。Windows 上的 npm shim 是 `.cmd/.exe/.bat`，
 * 无扩展名的那份是给 sh/bash 用的，`spawn` 直接跑不起来，所以不列。
 */
export function managedBinCandidates(dshHome, platform = process.platform) {
  const npmBinDir = join(managedInstallDir(dshHome), 'node_modules', '.bin')
  return [
    managedBinaryPath(dshHome, platform),
    ...(platform === 'win32'
      // npm 在 Windows 上只生成 .cmd / .ps1 / 无扩展名 sh 脚本（.ps1 不是可执行格式，
      // 无扩展名那份是给 sh 用的），能直接 spawn 的只有 .cmd。
      ? [join(npmBinDir, 'arkcli.cmd')]
      : [join(npmBinDir, 'arkcli')]),
  ]
}

/**
 * 把 Node 的 platform/arch 映射成官方清单里的键（`windows-amd64` 等）。
 *
 * 平台或架构不在官方发布范围内时返回 undefined —— 调用方据此给出人话，而不是
 * 拼一个必然 404 的 URL。
 */
export function platformKeyOf(platform = process.platform, arch = process.arch) {
  const os = platform === 'win32' ? 'windows' : platform === 'darwin' ? 'darwin' : platform === 'linux' ? 'linux' : undefined
  if (os === undefined) return undefined
  const cpu = arch === 'x64' ? 'amd64' : arch === 'arm64' ? 'arm64' : undefined
  return cpu === undefined ? undefined : `${os}-${cpu}`
}

/** 无状态子命令（`--version`、安装）用的中性 HOME，避免往用户的 `~/.arkcli` 里写东西。 */
export function neutralHomeDir(dshHome) {
  return join(arkcliStateRoot(dshHome), 'neutral')
}

/**
 * 清洗账号 id，使它一定能安全地当目录名。
 *
 * **实现只有一份**，在 `accounts.js` 里：`accounts.js` 用它推导"聊天用哪个 HOME"，
 * 本模块用它推导"登录写到哪个 HOME"，两处必须是同一个函数，否则超长 id 会让
 * 登录与聊天落在两个目录（表现成"登录成功了却一直说没登录"）。
 */
export { sanitizeAccountId }

/** 某个账号的 HOME：`<dshHome>/ark-coding/accounts/<sanitized id>`。 */
export function accountHomeDir(dshHome, accountId) {
  return join(arkcliStateRoot(dshHome), 'accounts', sanitizeAccountId(accountId))
}

/**
 * 读 CLI 账户凭据的**到期时间**（epoch ms）；读不到就返回 `undefined`。
 *
 * 为什么要专门读文件：`auth status` 里的 `control_plane_auth.sts_expires_at_ms` 是
 * STS 的 15 分钟到期（arkcli 自己会刷新），对用户毫无意义 —— 它永远"还有 15 分钟"。
 * 真正决定**什么时候必须重新登录**的是 profile 上的 `expires_at`（单位秒），它落在
 * `<HOME>/.arkcli/config.yaml` 里。
 *
 * 实测：一个 2026-10-16 登录的 Coding Plan 账户给出 `expires_at = 1797350399`，
 * 也就是 **2026-12-15 23:59:59（UTC+8）**。这是个会随租户/策略变化的服务端事实，
 * 所以界面**显示算出来的具体日期**，而不是写死一句"每 N 天要重登"。
 *
 * 解析用逐行扫描而不是引一个 YAML 库：只需要 `default_profile` 那一段里的一个数字，
 * 为此拉进一个依赖不划算。优先取 default profile 的；找不到就退回全文件里最早的那个
 * （最早到期的最该被提醒）。
 *
 * @param home - 账户的 HOME。
 * @param readFile - 可注入的读取器（测试用）。
 * @returns epoch 毫秒，或 `undefined`。
 */
export function readCredentialExpiry(home, readFile = readFileSync) {
  if (typeof home !== 'string' || home === '') return undefined
  let text
  try { text = readFile(join(home, '.arkcli', 'config.yaml'), 'utf8') } catch { return undefined }
  if (typeof text !== 'string' || text === '') return undefined

  const wanted = /^\s*default_profile:\s*(\S+)\s*$/m.exec(text)?.[1]
  const sectionOf = (line) => /^(\s*)(\S.*?):\s*$/.exec(line)
  const expiryOf = (line) => /^\s*expires_at:\s*(-?\d+)\s*$/.exec(line)
  const lines = text.split('\n')

  // 优先在**目标 profile 自己的缩进块**里找。
  // 旧实现一看到任意 `  key:` 形态的行就把 depth 重置成 -1，于是 profile 内部的嵌套
  // map（`keystore:`、`cache:` 之类）会把本 profile 的 expires_at 推进"全文件候选"，
  // 最后可能取到**另一个 profile** 的到期时间 —— 界面上显示的日期就是错的。
  // 现在的规则：只有缩进回到同级或更外层才算块结束。
  if (typeof wanted === 'string' && wanted !== '') {
    let base
    for (const line of lines) {
      const header = sectionOf(line)
      if (header !== null) {
        if (base === undefined) {
          if (header[2].trim() === wanted) base = header[1].length
          continue
        }
        if (header[1].length <= base) break
        continue
      }
      if (base === undefined) continue
      const expiry = expiryOf(line)
      if (expiry === null) continue
      const ms = expiryToMs(Number(expiry[1]))
      if (ms !== undefined) return ms
    }
  }

  // 兜底：全文件里最早的那个（最早到期的最该被提醒）。
  const found = []
  for (const line of lines) {
    const expiry = expiryOf(line)
    if (expiry === null) continue
    const ms = expiryToMs(Number(expiry[1]))
    if (ms !== undefined) found.push(ms)
  }
  return found.length === 0 ? undefined : Math.min(...found)
}

/**
 * 在 PATH 里找一个可执行文件。
 *
 * 这里用 `existsSync` 逐个拼路径检查（而不是 spawn 一次 `--version`）：
 * 它不产生额外进程、不依赖超时，结果也确定。Windows 上真正能被 `CreateProcess`
 * 直接执行的是 `.exe`（`.cmd/.bat` 要包一层 cmd.exe），无扩展名的那份是 npm 给
 * sh/bash 生成的包装脚本，**不作候选**——找到它反而会让 spawn 报"不是有效的应用程序"。
 * 注意只检查"存在"，不检查可执行位 —— 真正执行时若不可执行，spawn 会给出明确错误。
 *
 * @param name - 可执行文件名，如 `arkcli`。
 * @param pathValue - PATH 值，默认取父进程的 PATH。
 * @param exists - 存在性判断，便于测试注入。
 * @param platform - 目标平台，默认 `process.platform`（测试可注入 win32）。
 */
export function findExecutableOnPath(name, pathValue = process.env.PATH, exists = existsSync, platform = process.platform) {
  if (typeof pathValue !== 'string' || pathValue === '') return undefined
  const suffixes = platform === 'win32' ? ['.exe', '.cmd', '.bat'] : ['']
  // PATH 分隔符也跟目标平台走：Windows 是 `;`。测试注入 win32 时不能按宿主平台切。
  const separator = platform === 'win32' ? ';' : ':'
  for (const dir of pathValue.split(separator)) {
    if (dir === '') continue
    for (const suffix of suffixes) {
      const candidate = join(dir, `${name}${suffix}`)
      if (exists(candidate)) return candidate
    }
  }
  return undefined
}

// ---------------------------------------------------------------------------
// 输出解析
// ---------------------------------------------------------------------------

/** 把任意抛出物转成一句可读文本。 */
function messageOf(error) {
  return error instanceof Error ? error.message : String(error)
}

/** 最后一行非空文本（arkcli 的人类可读报错经常只在最后一行）。 */
function lastMeaningfulLine(text) {
  if (typeof text !== 'string') return undefined
  const lines = text.split('\n').map((line) => line.trim()).filter((line) => line !== '')
  return lines.length === 0 ? undefined : lines[lines.length - 1]
}

/**
 * 解析 arkcli 的 `--format json` 输出。
 *
 * arkcli 成功时把 JSON 打在 stdout；失败时把 `{"ok":false,"error":{...}}` 也打在
 * **stdout**（不是 stderr）并且退出码非零。另外 stdout 里可能先有一行警告，
 * 所以从第一个 JSON 起始符开始截取。
 *
 * 起点同时考虑 `{` 与 `[`：`models search` 的顶层应答既可能是对象、也可能是数组，
 * 只认 `{` 会把数组截坏（取数组内第一个花括号当起点）。先试最靠前的起始符，
 * 失败再试下一个。
 *
 * @param text - 子进程的 stdout。
 * @returns 成功 `{ok:true, value}`；失败 `{ok:false, error}`（error 一定是可读字符串）。
 */
export function parseArkcliJson(text) {
  if (typeof text !== 'string') return { ok: false, error: '没有可解析的输出' }
  const trimmed = text.trim()
  if (trimmed === '') return { ok: false, error: '输出为空' }
  const starts = [trimmed.indexOf('{'), trimmed.indexOf('[')].filter((index) => index >= 0).sort((left, right) => left - right)
  const candidates = starts.length === 0 ? [0] : starts
  let value
  let failure
  for (const start of candidates) {
    try {
      value = JSON.parse(trimmed.slice(start))
      failure = undefined
      break
    } catch (error) {
      failure = error
    }
  }
  if (failure !== undefined) return { ok: false, error: `不是合法 JSON：${messageOf(failure)}` }
  if (value !== null && typeof value === 'object' && value.ok === false) {
    const raw = value.error
    const message = raw !== null && typeof raw === 'object' && typeof raw.message === 'string'
      ? raw.message
      : typeof raw === 'string' && raw !== '' ? raw : 'arkcli 报错（没有 message）'
    return { ok: false, error: message }
  }
  return { ok: true, value }
}

/**
 * 该 stdout 是否"看起来像 JSON 报错"（决定非零退出时优先用哪条错误文本）。
 *
 * 判据是"**trim 之后以 `{` 或 `[` 开头**"，而不是"包含 `{` 或 `[`"：Go 的 panic 回溯
 * 形如 `panic: ...\n\ngoroutine 1 [running]:\n...`，里面就有 `[running]` 的 `[`，
 * 旧判据会把整段回溯当成 JSON 去解析，于是用户看到的是
 * `不是合法 JSON：Unexpected token 'r', "[running]:" is not valid JSON` ——
 * 真正的原因（panic 的第一行）反而被丢掉。
 */
function looksLikeJsonReport(stdout) {
  if (typeof stdout !== 'string') return false
  const trimmed = stdout.trim()
  return trimmed.startsWith('{') || trimmed.startsWith('[')
}

// ---------------------------------------------------------------------------
// 子进程环境
// ---------------------------------------------------------------------------

/**
 * 构造 arkcli 子进程用的最小环境。
 *
 * 白名单重建，**绝不继承** `ARK_API_KEY` / `ARK_PROFILE` / `ARK_BASE_URL` / `VOLC_*`
 * / `ARKCLI_ALLOW_HEADLESS_*`：这些一旦被继承，arkcli 就会把宿主自己的凭据与上下文
 * 当成"当前账号"，多账号隔离当场失效（而且宿主的 key 会被写进别的账号目录）。
 *
 * `HOME` 是必填的：arkcli 的状态目录是 `$HOME/.arkcli` 且无法用环境变量覆盖，
 * 少传 HOME 就等于在宿主的家目录里乱写。
 *
 * **Windows 上 `HOME` 是无效的**：Go 的 `os.UserHomeDir()` 只认 `%USERPROFILE%`。
 * 只设 HOME 的话，所有账户都会读写宿主的 `%USERPROFILE%\.arkcli`，多账户隔离
 * 表现成"登录一个、全部串台"。所以 Windows 还必须把 USERPROFILE 指到同一个目录，
 * 并保留 SystemRoot / ComSpec / PATHEXT / TEMP 这些系统变量——缺了它们，Go 程序
 * 起子进程、解析路径、写临时文件都会出怪问题。
 *
 * @param home - 该账号的 HOME（绝对路径）。
 * @param extra - 追加/覆盖的键，值为 undefined 的键会被跳过。
 * @param platform - 目标平台，默认 `process.platform`（测试可注入 win32）。
 * @throws 当 home 缺失或为空。
 */
export function buildChildEnv(home, extra, platform = process.platform) {
  if (typeof home !== 'string' || home === '') {
    throw new Error('必须显式给定 HOME：arkcli 把状态放在 $HOME/.arkcli 且没有环境变量可以覆盖，多账号隔离完全依赖它。')
  }
  const put = (target, key, value) => {
    if (value !== undefined) target[key] = value
  }
  const env = {}
  put(env, 'PATH', process.env.PATH)
  env.HOME = home
  // Windows：Go 取家目录只看 USERPROFILE（不看 HOME）。不设它 = 多账户全部串到宿主家目录。
  if (platform === 'win32') put(env, 'USERPROFILE', home)
  env.LANG = process.env.LANG ?? 'C.UTF-8'
  env.LC_ALL = process.env.LC_ALL ?? 'C.UTF-8'
  put(env, 'TMPDIR', process.env.TMPDIR ?? tmpdir())
  // Windows 的系统变量：缺 SystemRoot 时部分 Go 运行时会拿不到系统目录；
  // 缺 ComSpec/PATHEXT 时子进程无法再起 .exe/.cmd。
  if (platform === 'win32') {
    for (const key of ['SystemRoot', 'SystemDrive', 'windir', 'ComSpec', 'PATHEXT', 'NUMBER_OF_PROCESSORS', 'PROCESSOR_ARCHITECTURE', 'TEMP', 'TMP']) {
      put(env, key, process.env[key])
    }
  }
  env.NO_COLOR = '1'
  env.ARKCLI_NO_UPDATE_NOTIFIER = '1'
  env.ARKCLI_CALLER_TYPE = 'ai_agent'
  env.ARKCLI_CALLER_NAME = 'dsh-ark-coding-provider'
  for (const [key, value] of Object.entries(extra ?? {})) put(env, key, value)
  return env
}

// ---------------------------------------------------------------------------
// 子进程启动
// ---------------------------------------------------------------------------

/** cmd.exe 里需要引号或转义的字符（含元字符与百分号展开）。 */
const CMD_SPECIAL = /[\s"&|<>^()%!]/

/**
 * 转义一个参数，供 `cmd.exe /d /s /c` 使用。
 *
 * cmd 的引号规则和 POSIX 完全不同：没有反斜杠转义，双引号里 `&|<>^()` 不再生效，
 * 所以一律把带元字符的参数包进双引号。
 *
 * **两个已知边界**：①`%VAR%` 即使在双引号里也会展开，本函数不处理——Windows 路径
 * 里带 `%` 极罕见，而且直接下载的 `.exe`（主路径）根本不经过 cmd；②双引号本身在
 * cmd 里没有可靠转义，`""` 只是尽力而为（Windows 路径本来也不允许 `"`）。
 * 走到这里的只有 npm 兜底和 PATH 上已有的 `.cmd` 安装，参数都是普通词/路径。
 */
function escapeCmdArgument(argument) {
  if (argument === '') return '""'
  if (!CMD_SPECIAL.test(argument)) return argument
  // `"` 不是合法 Windows 路径字符；`""` 是 cmd 对字面引号的唯一近似写法。
  return `"${argument.replace(/"/g, '""')}"`
}

/**
 * 决定怎么启动一个可执行文件。
 *
 * POSIX 直接 `spawn(path, args)`；Windows 上 `.cmd/.bat` 不是有效的 PE，`CreateProcess`
 * 不能直接执行它（报 ENOENT / "不是有效的 Win32 应用程序"），必须包一层
 * `cmd.exe /d /s /c "<命令行>"`。返回的 `verbatim: true` 表示调用方要给 spawn 传
 * `windowsVerbatimArguments`——命令行已经自己拼好了，Node 再 quote 一次反而会把
 * cmd 看到的引号搞乱。
 *
 * @param target - 可执行文件路径（或 PATH 上的命令）。
 * @param args - 参数数组。
 * @param platform - 目标平台。
 * @param comspec - Windows 命令解释器，默认 `$ComSpec`。
 * @returns `{command, args, verbatim}`。
 */
export function spawnPlanFor(target, args, platform = process.platform, comspec = process.env.ComSpec) {
  if (platform !== 'win32' || !/\.(?:cmd|bat)$/i.test(target)) return { command: target, args, verbatim: false }
  const shell = typeof comspec === 'string' && comspec !== '' ? comspec : 'cmd.exe'
  const line = [escapeCmdArgument(target), ...args.map(escapeCmdArgument)].join(' ')
  // 整条命令包一层引号：`/s` 会剥掉最外层这一对，里面的引号原样留给 cmd。
  return { command: shell, args: ['/d', '/s', '/c', `"${line}"`], verbatim: true }
}

/**
 * 杀一个子进程**及其后代**。
 *
 * `node_modules/.bin/arkcli` 是个 node 包装脚本，它用 `execFileSync` 阻塞地去跑真正的
 * Go 二进制。**杀掉包装进程不会杀掉那个 Go 孙子进程**：实测 SIGKILL 掉包装之后，
 * Go 二进制被 init 收养继续活着（PPID=1），还占着回环端口和 `<HOME>/.arkcli` 下的
 * 锁文件 —— 也就是说"超时"并没有真的停下工作，反复超时还会累积 root 进程。
 *
 * 所以 POSIX 上子进程一律以 `detached: true` 起独立进程组，这里按**进程组**杀（负 pid）；
 * Windows 没有进程组信号，改用 `taskkill /T /F` 整棵树带走（直接下载安装的是单个
 * .exe，杀它本身也够；但 PATH 上 npm 全局装的 .cmd 仍有两层）。
 *
 * @param child - spawn 出来的子进程。
 * @param options.platform - 目标平台。
 * @param options.spawnSync - 同步进程工厂（taskkill 用），可注入。
 * @param options.comspec - Windows 命令解释器。
 */
export function killProcessTree(child, options = {}) {
  const platform = options.platform ?? process.platform
  const comspec = options.comspec ?? process.env.ComSpec
  const runSync = options.spawnSync ?? nodeSpawnSync
  const pid = child?.pid
  if (typeof pid === 'number' && pid > 0) {
    if (platform === 'win32') {
      // `spawnSync` 正常不会抛：cmd.exe 找不到 → `{error}`，taskkill 失败 → `{status:1}`。
      // 只有真的成功（status 0 且无 error）才提前返回，否则必须落到下面 child.kill 的兜底。
      try {
        const shell = typeof comspec === 'string' && comspec !== '' ? comspec : 'cmd.exe'
        const result = runSync(shell, ['/d', '/s', '/c', `taskkill /pid ${pid} /T /F`], {
          windowsHide: true,
          stdio: 'ignore',
          timeout: 5_000,
        })
        if (result !== null && typeof result === 'object' && result.status === 0 && result.error === undefined) return
      } catch { /* taskkill 不可用就退回杀单个进程 */ }
    } else {
      try {
        process.kill(-pid, 'SIGKILL')
        return
      } catch { /* 进程组可能已经没了，退回杀单个进程 */ }
    }
  }
  try { child?.kill?.('SIGKILL') } catch { /* 已经退出就无所谓 */ }
}

// ---------------------------------------------------------------------------
// 归一化
// ---------------------------------------------------------------------------

/** 有限数字，否则 undefined。 */
function finiteNumber(value) {
  return typeof value === 'number' && Number.isFinite(value) ? value : undefined
}

/** 有限正数，否则 undefined（`context_window: null` 之类一律视为"未知"）。 */
function positiveNumber(value) {
  const number = finiteNumber(value)
  return number !== undefined && number > 0 ? number : undefined
}

/** 非空字符串，否则 undefined。 */
function stringOrUndefined(value) {
  return typeof value === 'string' && value !== '' ? value : undefined
}

/** 只保留字符串元素的数组。 */
function stringArray(value) {
  return Array.isArray(value) ? value.filter((item) => typeof item === 'string') : []
}

/** 百分比：clamp 到 0..100，最多两位小数；非数字则 undefined。 */
export function normalizePercent(value) {
  const number = finiteNumber(value)
  if (number === undefined) return undefined
  const clamped = Math.max(0, Math.min(100, number))
  return Math.round(clamped * 100) / 100
}

/**
 * `reset_at` → epoch 毫秒。
 *
 * 上游给 RFC3339（带 +08:00 偏移）字符串；如果哪天它改成数字，秒与毫秒都认
 * （> 1e11 视为毫秒）。解析不出来就 undefined —— **绝不返回 NaN**，否则
 * `new Date(NaN)` 会一路把界面显示成 Invalid Date。
 */
export function parseResetAt(value) {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return usableDateMs(value > 1e11 ? value : value * 1000)
  }
  if (typeof value !== 'string' || value.trim() === '') return undefined
  return usableDateMs(Date.parse(value))
}

/**
 * 时间戳是否落在一个能正常显示的范围里。
 *
 * `new Date(-1000).toLocaleString()` 渲染出 1970-01-01，`new Date(1e300)` 渲染出
 * "Invalid Date" —— 用户看到的是**假日期**，比什么都不显示更糟。而 `formatClock`
 * 里的 try/catch 拦不住这两种（它们根本不抛）。所以范围校验必须在这里做。
 */
function usableDateMs(value) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return undefined
  if (value <= 0 || value > 8.64e15) return undefined
  return value
}

/** 上游 `expires_at` 是秒；> 1e11 说明已经是毫秒了，别乘两次。 */
function expiryToMs(raw) {
  if (!Number.isFinite(raw) || raw <= 0) return undefined
  return usableDateMs(raw > 1e11 ? raw : raw * 1000)
}

/** 时间戳 → epoch 毫秒（数字直用，字符串走 Date.parse）。 */
function epochMs(value) {
  const number = finiteNumber(value)
  if (number !== undefined) return number
  if (typeof value === 'string' && value.trim() !== '') {
    const parsed = Date.parse(value)
    return Number.isNaN(parsed) ? undefined : parsed
  }
  return undefined
}

/** 上游 label → 稳定窗口键。 */
export function periodKeyOf(label) {
  const key = typeof label === 'string' ? label.trim().toLowerCase() : ''
  if (key === 'session' || key === '5h') return 'session'
  if (key === 'weekly' || key === 'week') return 'weekly'
  if (key === 'monthly' || key === 'month') return 'monthly'
  return key
}

/** 窗口的规范顺序：5 小时 → 每周 → 每月 → 其它（保持上游相对顺序）。 */
const PERIOD_ORDER = { session: 0, weekly: 1, monthly: 2 }

/** 归一化一个额度窗口。 */
export function normalizePeriod(row) {
  if (row === null || typeof row !== 'object') return undefined
  const label = stringOrUndefined(row.label) ?? ''
  const used = finiteNumber(row.used)
  const total = finiteNumber(row.total)
  return {
    label,
    key: periodKeyOf(label),
    used,
    total,
    percent: normalizePercent(row.percent),
    resetAt: parseResetAt(row.reset_at ?? row.resetAt),
    // CodingPlan 只给 percent（used/total 被 omitempty 掉了），AgentPlan 才给绝对值。
    hasTotals: used !== undefined && total !== undefined,
  }
}

/** 归一化 `usage plan` 的一个套餐条目。 */
export function normalizeUsageItem(row) {
  const source = row !== null && typeof row === 'object' ? row : {}
  const periods = (Array.isArray(source.periods) ? source.periods : [])
    .map(normalizePeriod)
    .filter((period) => period !== undefined)
  // Array.prototype.sort 在 V8 上是稳定的，因此同序的"其它"窗口保持上游顺序。
  periods.sort((left, right) => (PERIOD_ORDER[left.key] ?? 99) - (PERIOD_ORDER[right.key] ?? 99))
  return {
    product: stringOrUndefined(source.product),
    edition: stringOrUndefined(source.edition),
    tier: stringOrUndefined(source.tier),
    seatId: stringOrUndefined(source.seat_id ?? source.seatId),
    subscribed: source.subscribed === true,
    periods,
    updatedAt: epochMs(source.updated_at ?? source.updatedAt),
    // 单个套餐出错时其它套餐仍然返回，所以错误挂在条目上而不是整个应答上。
    error: stringOrUndefined(source.error),
  }
}

/** 归一化一个模型条目。 */
export function normalizeModel(row) {
  const source = row !== null && typeof row === 'object' ? row : {}
  const id = stringOrUndefined(source.name)
  const displayName = stringOrUndefined(source.display_name)
  return {
    id,
    name: displayName ?? id,
    displayName,
    version: stringOrUndefined(source.primary_version),
    contextWindow: positiveNumber(source.context_window),
    maxInputTokens: positiveNumber(source.max_input_tokens),
    maxOutputTokens: positiveNumber(source.max_completion_tokens),
    inputModalities: stringArray(source.input_modalities),
    outputModalities: stringArray(source.output_modalities),
    capabilities: source.capabilities !== null && typeof source.capabilities === 'object' ? source.capabilities : {},
    cacheTypes: stringArray(source.cache_types),
    lifecycleStatus: stringOrUndefined(source.lifecycle_status),
    updateTime: stringOrUndefined(source.update_time),
  }
}

/** `models search` 的应答外壳有三种：裸数组、`{items}`、`{data:{items}}`。 */
export function modelsItemsOf(value) {
  if (Array.isArray(value)) return value
  if (value !== null && typeof value === 'object') {
    if (Array.isArray(value.items)) return value.items
    if (value.data !== null && typeof value.data === 'object' && Array.isArray(value.data.items)) return value.data.items
  }
  return []
}

/**
 * 从 `profile apikey get` 的输出里抠出 API key。
 *
 * 这个子命令的确切输出形状没有实测（文档只说它"机器可读"），所以三种都认：
 * 裸字符串、JSON 对象（`api_key`/`apiKey`/`default_api_key`/`key`，含 `data` 包一层）、
 * 以及 JSON 字符串。裸文本则在每一行里找"像 key 的单行 token"。
 */
export function extractApiKey(text) {
  if (typeof text !== 'string') return undefined
  const trimmed = text.trim()
  if (trimmed === '') return undefined
  // 可能前面还有一行日志，所以从第一个 `{` / `"` 开始试；失败再退回按行找 token。
  const brace = trimmed.indexOf('{')
  const quote = trimmed.indexOf('"')
  const start = brace >= 0 && (quote === -1 || brace < quote) ? brace : quote
  if (start >= 0) {
    try {
      const parsed = JSON.parse(trimmed.slice(start))
      if (typeof parsed === 'string') {
        if (parsed.trim() !== '') return parsed.trim()
      } else {
        const found = apiKeyOf(parsed)
        if (found !== undefined) return found
      }
    } catch { /* 不是 JSON，按裸文本继续找 */ }
  }
  for (const line of trimmed.split('\n')) {
    const candidate = line.trim()
    if (/^[A-Za-z0-9._-]{8,}$/.test(candidate)) return candidate
  }
  return undefined
}

/** 在对象里按候选键名找字符串 key。 */
function apiKeyOf(value) {
  if (value === null || typeof value !== 'object') return undefined
  for (const key of ['api_key', 'apiKey', 'default_api_key', 'key']) {
    const candidate = value[key]
    if (typeof candidate === 'string' && candidate.trim() !== '') return candidate.trim()
  }
  if (value.data !== null && typeof value.data === 'object') return apiKeyOf(value.data)
  return undefined
}

// ---------------------------------------------------------------------------
// ArkCli
// ---------------------------------------------------------------------------

/**
 * arkcli 进程封装。
 *
 * 所有外部依赖都可注入（spawn / fetch / now / exists），测试里给假实现即可完全离线。
 */
export class ArkCli {
  /**
   * @param options - 依赖与配置。
   * @param options.dshHome - DSH 数据目录；托管安装与账号 HOME 都在它下面。
   * @param options.binPath - 配置里的 arkcli 可执行文件路径（优先级最高）。
   * @param options.logger - 可选日志对象（用 debug 通道）。
   * @param options.spawn - 子进程工厂，默认 `node:child_process.spawn`。
   * @param options.spawnSync - 同步子进程工厂（Windows 的 taskkill 用）。
   * @param options.fetchImpl - fetch，默认全局 fetch（安装时直接下载官方二进制）。
   * @param options.now - 时钟，默认 `Date.now`。
   * @param options.packageVersion - 安装时固定的版本；缺省内置的钉住版本。
   * @param options.pathEnv - 用于查找 PATH 上的 arkcli，默认父进程 PATH。
   * @param options.exists - 存在性判断，默认 `fs.existsSync`。
   * @param options.mkdir - 建目录，默认 `fs.mkdirSync`。
   * @param options.platform - 目标平台，默认 `process.platform`（测试可注入 win32）。
   * @param options.arch - 目标架构，默认 `process.arch`。
   * @param options.binaries - 官方二进制清单，默认 {@link ARKCLI_BINARIES}。
   * @param options.comspec - Windows 命令解释器，默认 `$ComSpec`。
   */
  constructor(options = {}) {
    const {
      dshHome,
      binPath,
      logger,
      spawn = nodeSpawn,
      spawnSync = nodeSpawnSync,
      fetchImpl = globalThis.fetch,
      now = Date.now,
      packageVersion,
      pathEnv = process.env.PATH,
      exists = existsSync,
      mkdir = mkdirSync,
      platform = process.platform,
      arch = process.arch,
      binaries = ARKCLI_BINARIES,
      comspec = process.env.ComSpec,
    } = options
    this.dshHome = dshHome
    this.binPath = typeof binPath === 'string' && binPath !== '' ? binPath : undefined
    this.logger = logger
    this.spawn = spawn
    this.spawnSync = spawnSync
    this.fetchImpl = fetchImpl
    this.now = now
    this.packageVersion = typeof packageVersion === 'string' && packageVersion !== '' ? packageVersion : undefined
    this.pathEnv = pathEnv
    this.exists = exists
    this.mkdir = mkdir
    this.platform = platform
    this.arch = arch
    this.binaries = binaries
    this.comspec = typeof comspec === 'string' && comspec !== '' ? comspec : undefined
  }

  /**
   * 解析到底用哪个 arkcli。
   *
   * 顺序：配置里的 binPath（用户明确指定，最可信）→ 本插件托管安装的 bin →
   * PATH 上的 arkcli。第三个是真实查找（`findExecutableOnPath`），不是"试着跑一下"。
   * 托管目录里先看直接下载的那份，再看旧版本用 npm 装出来的 shim。
   *
   * @returns `{path, source}`；都没有时 `path` 为 undefined。
   */
  async resolveBin() {
    if (this.binPath !== undefined && this.exists(this.binPath)) return { path: this.binPath, source: 'config' }
    if (typeof this.dshHome === 'string' && this.dshHome !== '') {
      for (const candidate of managedBinCandidates(this.dshHome, this.platform)) {
        if (this.exists(candidate)) return { path: candidate, source: 'managed' }
      }
    }
    const onPath = findExecutableOnPath('arkcli', this.pathEnv, this.exists, this.platform)
    if (onPath !== undefined) return { path: onPath, source: 'path' }
    return { path: undefined, source: undefined }
  }

  /**
   * 无状态命令用的 HOME；不主动创建目录（`--version` 不会去写状态）。
   *
   * 正常情况下 `apply()` 已经把 DSH home 传进来了；这里的兜底顺序与 DSH 一致
   * （`$DSH_HOME` → `~/.dsh`），并同时看 `USERPROFILE`——Windows 上 `HOME` 可能不存在，
   * 直接 `join(undefined ?? '.', '.dsh')` 会得到**相对路径** `.dsh`，那会变成
   * "把 cwd 当用户主目录"。都拿不到时明确报错，而不是悄悄用相对路径。
   */
  #neutralHome(home) {
    if (typeof home === 'string' && home !== '') return home
    const configured = typeof process.env.DSH_HOME === 'string' ? process.env.DSH_HOME.trim() : ''
    const osHome = process.env.HOME ?? process.env.USERPROFILE
    const base = typeof this.dshHome === 'string' && this.dshHome !== ''
      ? this.dshHome
      : configured !== ''
        ? configured
        : typeof osHome === 'string' && osHome !== '' ? join(osHome, '.dsh') : undefined
    if (base === undefined) {
      throw new Error('拿不到 DSH 数据目录（DSH_HOME 与用户主目录都不可用）：无法为 arkcli 准备 HOME。')
    }
    return neutralHomeDir(base)
  }

  /**
   * 起一个子进程并把输出收全。
   *
   * 超时会杀掉整棵进程树并返回 error='超时'。返回值里的 `failure` 字段只在本模块内部
   * 用来区分"超时 / 起不来 / 正常退出非零"，不进 `run()` 的对外结果。
   *
   * 走 {@link spawnPlanFor}：Windows 上的 `.cmd/.bat`（npm shim、PATH 上的全局安装）
   * 必须包一层 cmd.exe；`.exe` 则照常直接起。`windowsHide` 让桌面端不会闪黑框。
   */
  async #spawnCollect(bin, args, options) {
    const { env, timeoutMs } = options
    const plan = spawnPlanFor(bin, args, this.platform, this.comspec)
    return await new Promise((resolve) => {
      let child
      try {
        // `detached: true`：起独立进程组，这样超时能整组带走（见 killProcessTree）。
        // Windows 上 detached 会开一个新控制台窗口（桌面端每跑一次闪一下），所以只在 POSIX 用。
        child = this.spawn(plan.command, plan.args, {
          stdio: ['ignore', 'pipe', 'pipe'],
          env,
          detached: this.platform !== 'win32',
          windowsHide: true,
          ...plan.verbatim ? { windowsVerbatimArguments: true } : {},
        })
      } catch (error) {
        resolve({ ok: false, code: null, stdout: '', stderr: '', error: `无法启动 ${bin}：${messageOf(error)}`, failure: 'spawn' })
        return
      }
      let stdout = ''
      let stderr = ''
      let settled = false
      let timer
      const done = (result) => {
        if (settled) return
        settled = true
        if (timer !== undefined) clearTimeout(timer)
        resolve(result)
      }
      child.stdout?.on?.('data', (chunk) => {
        if (stdout.length < MAX_CHILD_OUTPUT_CHARS) stdout += String(chunk)
      })
      child.stderr?.on?.('data', (chunk) => {
        if (stderr.length < MAX_CHILD_OUTPUT_CHARS) stderr += String(chunk)
      })
      child.on?.('error', (error) => {
        done({ ok: false, code: null, stdout, stderr, error: `执行 ${bin} 失败：${messageOf(error)}`, failure: 'spawn' })
      })
      child.on?.('close', (code, signal) => {
        done({
          ok: code === 0,
          code,
          stdout,
          stderr,
          error: code === 0 ? undefined : `退出码 ${code ?? signal}`,
          failure: code === 0 ? undefined : 'exit',
        })
      })
      if (typeof timeoutMs === 'number' && timeoutMs > 0) {
        timer = setTimeout(() => {
          killProcessTree(child, { platform: this.platform, spawnSync: this.spawnSync, comspec: this.comspec })
          done({ ok: false, code: null, stdout, stderr, error: '超时', failure: 'timeout' })
        }, timeoutMs)
      }
    })
  }

  /**
   * 跑一次 arkcli。
   *
   * @param args - 参数数组（不含可执行文件名）。
   * @param options - `home`（必填，作为子进程 HOME）、超时、额外环境变量。
   * @returns `{ok, code, stdout, stderr, json, error}`；`json` 是解析成功后的值。
   * @throws 当 `home` 缺失（多账号隔离依赖它，不允许"随手用父进程 HOME"）。
   */
  async run(args, options = {}) {
    const { home, timeoutMs = DEFAULT_RUN_TIMEOUT_MS, env } = options
    const childEnv = buildChildEnv(home, env, this.platform)
    const resolved = await this.resolveBin()
    if (resolved.path === undefined) {
      return { ok: false, code: null, stdout: '', stderr: '', json: undefined, error: '找不到 arkcli：请先安装，或在设置里指定可执行文件路径。' }
    }
    const collected = await this.#spawnCollect(resolved.path, args, { env: childEnv, timeoutMs })
    const parsed = parseArkcliJson(collected.stdout)
    const json = parsed.ok ? parsed.value : undefined

    if (collected.ok) return { ok: true, code: collected.code, stdout: collected.stdout, stderr: collected.stderr, json, error: undefined }

    // 非零退出：优先用 arkcli 自己给的 JSON message，其次 stderr 最后一行，最后才是退出码。
    //
    // 注意两个流都要看：arkcli 的约定是「stdout 只放结构化结果，错误与解释走 stderr」，
    // 实测未登录时整个 {"ok":false,"error":{...}} 信封是打在 **stderr** 上的。只看 stdout
    // 的话，这里会退化成 stderr 的最后一行 —— 也就是一个孤零零的 `}`，界面里毫无意义。
    const errorFrom = (text) => {
      if (!looksLikeJsonReport(text)) return undefined
      const candidate = parseArkcliJson(text)
      return candidate.ok === false ? candidate.error : undefined
    }
    let error
    if (collected.failure === 'timeout') error = '超时'
    else if (collected.failure === 'spawn') error = collected.error
    else {
      error = errorFrom(collected.stderr)
        ?? errorFrom(collected.stdout)
        ?? lastMeaningfulLine(collected.stderr)
        ?? collected.error
    }
    return { ok: false, code: collected.code, stdout: collected.stdout, stderr: collected.stderr, json, error }
  }

  /**
   * 当前 arkcli 是否可用。
   *
   * @returns `{installed, path, version, source, error?}`。
   */
  async status(options = {}) {
    const resolved = await this.resolveBin()
    if (resolved.path === undefined) {
      return {
        installed: false,
        path: undefined,
        version: undefined,
        source: undefined,
        error: '未安装 arkcli：可以在这里一键安装，或把 arkcli 放到 PATH 上。',
      }
    }
    const result = await this.run(['--version'], { home: this.#neutralHome(options.home), timeoutMs: 30_000 })
    const text = `${result.stdout}\n${result.stderr}`
    const match = /(\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?)/.exec(text)
    return {
      installed: result.ok,
      path: resolved.path,
      version: match?.[1],
      source: resolved.source,
      error: result.ok ? undefined : result.error,
    }
  }

  /**
   * 把 CLI 装到本插件的托管目录下。
   *
   * 两条路，按顺序试：
   *
   * 1. **直接下载官方 Go 二进制**（主路径）。官方 npm 包的 postinstall 本来就是
   *    "按平台从 CDN 下二进制 + 校验 sha256"，这里把它直接做掉：只需要宿主自带的
   *    fetch，**不依赖 npm、也不依赖 node**。DSH 桌面端跑在 Electron Node 模式里，
   *    PATH 上通常没有 npm —— 以前只走 npm 的那条路在 Windows 桌面端点安装就只会
   *    报错。下载源用官方 CDN，失败再退 GitHub Release，校验不过绝不落盘。
   *
   * 2. **npm 兜底**。只在直接下载失败、且 PATH 上确实有 npm 时才走：保留老用户
   *    （以及只信任 npm 镜像的网络环境）原来的安装方式。Windows 上 npm 是 `.cmd`，
   *    由 {@link spawnPlanFor} 包一层 cmd.exe。
   *
   * 两条路都要求"这个文件真的能跑"：下载路径在**落盘前**对临时文件跑 `--version`，
   * npm 路径对刚写下的 shim 跑一次；而不是"下载/npm 退出码为 0 就算成功"。
   *
   * @param options.version - 指定版本；缺省内置的钉住版本。
   * @param options.timeoutMs - 单步超时（下载或 npm）。
   * @returns `{ok, path, version, error}`。
   */
  async install(options = {}) {
    const { version, timeoutMs = INSTALL_TIMEOUT_MS } = options
    if (typeof this.dshHome !== 'string' || this.dshHome === '') {
      return { ok: false, path: undefined, version: undefined, error: '没有 DSH 数据目录（DSH_HOME / ~/.dsh 都不可用），无法确定安装目录。' }
    }
    const dir = managedInstallDir(this.dshHome)
    try {
      this.mkdir(dir, { recursive: true })
    } catch (error) {
      return { ok: false, path: undefined, version: undefined, error: `无法创建安装目录 ${dir}：${messageOf(error)}` }
    }
    const wanted = version ?? this.packageVersion ?? DEFAULT_INSTALL_VERSION
    const failures = []
    /** 两条路都失败时的统一结论：带上两条原因，并给出"自己装"的退路。 */
    const failureOf = () => ({
      ok: false,
      path: undefined,
      version: undefined,
      error: `安装 ${ARKCLI_PACKAGE}@${wanted} 失败：${failures.join('；')}。也可以自己装好 arkcli 后，在设置页「arkcli 路径」里指定可执行文件。`,
    })

    // 1) 直接下载官方二进制。#installBinary 会先对**临时文件**跑 --version，通过后才
    // 落盘，所以成功即代表"这个路径上的文件真的能执行"，不需要再用 resolveBin() 复检
    // （那会把一个坏文件已经占住的托管路径当成结论）。
    if (wanted === ARKCLI_BINARY_VERSION) {
      const download = await this.#installBinary(wanted, timeoutMs)
      if (download.ok) {
        this.logger?.debug?.(`[arkcli] 已下载 ${ARKCLI_PACKAGE}@${wanted} → ${download.path}`)
        return download
      }
      failures.push(download.error)
    } else {
      // 版本不是内置清单里的那个：没有可信的 sha256，只能走 npm。
      failures.push(`没有 ${wanted} 的官方二进制清单（内置 ${ARKCLI_BINARY_VERSION}）`)
    }

    // 2) npm 兜底（桌面端通常没有 npm，这条会直接跳过而不是报 ENOENT）。
    const npm = findExecutableOnPath('npm', this.pathEnv, this.exists, this.platform)
    if (npm === undefined) {
      failures.push('PATH 上找不到 npm，无法用 npm 兜底')
      return failureOf()
    }
    const args = ['install', '--prefix', dir, `${ARKCLI_PACKAGE}@${wanted}`, ...NPM_INSTALL_FLAGS]
    // npm 也用最小环境：否则 npm 会把宿主 HOME 下的 .npm 缓存/配置带进这次安装。
    // 中性 HOME 建不出来也无所谓（npm 自己会建缓存目录），但环境绝不能退回"继承父进程"。
    const npmHome = this.#neutralHome()
    try { this.mkdir(npmHome, { recursive: true }) } catch { /* 让 npm 自己决定 */ }
    const env = buildChildEnv(npmHome, undefined, this.platform)
    const collected = await this.#spawnCollect(npm, args, { env, timeoutMs })
    if (!collected.ok) {
      const tail = collected.stderr.trim().slice(-400) || collected.stdout.trim().slice(-400) || collected.error
      failures.push(`npm 安装失败：${tail}`)
      return failureOf()
    }
    // 验证 npm 刚写下的那份 shim，而不是 resolveBin() 的全局首选：托管目录里可能还留着
    // 之前直接下载的旧版本，拿它复检会让"装 1.0.38"看起来装上了 1.0.39。
    const npmShim = managedBinPath(this.dshHome, this.platform)
    const verified = await this.#verifyInstalled(wanted, this.exists(npmShim) ? npmShim : undefined)
    if (verified.ok) {
      this.logger?.debug?.(`[arkcli] 已安装 ${ARKCLI_PACKAGE}@${wanted} → ${verified.path}`)
      return verified
    }
    failures.push(`npm 装完后 arkcli 无法执行：${verified.error}`)
    return failureOf()
  }

  /**
   * 跑一次 `<target> --version`，确认这个文件真的能执行。
   *
   * 直接对**待落盘/刚装好**的文件验证，而不是 `resolveBin()` 的全局首选：否则一个
   * 下载坏掉的文件会先占住托管路径，之后所有解析都指向它，连 npm 兜底都被它带死。
   *
   * @param target - 要验证的可执行文件绝对路径。
   * @returns `{ok, version, error}`。
   */
  async #probeVersion(target) {
    const neutral = this.#neutralHome()
    // 中性 HOME 先建出来：Windows 上它会被当成 USERPROFILE，目录不存在时某些工具会
    // 在第一次写状态时把错误一路带出来。
    try { this.mkdir(neutral, { recursive: true }) } catch { /* 建不出来就让它自己报 */ }
    const env = buildChildEnv(neutral, undefined, this.platform)
    const collected = await this.#spawnCollect(target, ['--version'], { env, timeoutMs: 30_000 })
    const text = `${collected.stdout}\n${collected.stderr}`
    if (!collected.ok) {
      return {
        ok: false,
        version: undefined,
        error: collected.error ?? lastMeaningfulLine(text) ?? `无法执行 ${target}`,
      }
    }
    const match = /(\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?)/.exec(text)
    return { ok: true, version: match?.[1], error: undefined }
  }

  /**
   * 复检一个**已经装好的**路径（npm 兜底用）：文件存在、能执行。
   *
   * @param wanted - 期望版本（只用于输出兜底，不参与判定）。
   * @param explicitPath - 明确要验证的路径；缺省回退到 resolveBin()。
   * @returns `{ok, path, version, error}`。
   */
  async #verifyInstalled(wanted, explicitPath) {
    let target = explicitPath
    if (target === undefined) {
      const resolved = await this.resolveBin()
      if (resolved.path === undefined) {
        return { ok: false, path: undefined, version: undefined, error: '安装完成后仍然找不到 arkcli 可执行文件。' }
      }
      target = resolved.path
    } else if (!this.exists(target)) {
      return { ok: false, path: target, version: undefined, error: `安装完成后没有找到 ${target}。` }
    }
    const probe = await this.#probeVersion(target)
    if (!probe.ok) {
      return { ok: false, path: target, version: probe.version, error: probe.error ?? '安装后 arkcli 无法执行。' }
    }
    return { ok: true, path: target, version: probe.version ?? wanted, error: undefined }
  }

  /**
   * 直接下载官方 Go 二进制到 `<installDir>/bin/`。
   *
   * 逐个源尝试（CDN → GitHub Release），每个源下载完都校验 sha256，再对临时文件实跑
   * `--version`；任何一步失败都删掉临时文件、换下一个源。只有 sha256 与可执行性都
   * 通过才 rename 成正式文件——坏文件绝不占住托管路径。
   *
   * @param version - 版本（必须等于 {@link ARKCLI_BINARY_VERSION}）。
   * @param timeoutMs - 单个源的下载超时。
   * @returns `{ok, path, version, error}`。
   */
  async #installBinary(version, timeoutMs) {
    const key = platformKeyOf(this.platform, this.arch)
    if (key === undefined) {
      return { ok: false, path: undefined, version: undefined, error: `官方 arkcli 没有发布 ${this.platform}-${this.arch} 的二进制` }
    }
    const entry = this.binaries?.[key]
    if (entry === undefined || typeof entry.url !== 'string') {
      return { ok: false, path: undefined, version: undefined, error: `没有 ${key} 的下载清单` }
    }
    // 没有合法 sha256 就**拒绝下载**（fail closed）：官方 postinstall 也是这么做的。
    // "清单里没写校验值 ⇒ 下什么装什么"比不装危险得多。
    if (typeof entry.sha256 !== 'string' || !/^[0-9a-f]{64}$/i.test(entry.sha256)) {
      return { ok: false, path: undefined, version: undefined, error: `${key} 的下载清单缺少合法的 sha256，拒绝下载。` }
    }
    const expected = entry.sha256.toLowerCase()
    const destination = managedBinaryPath(this.dshHome, this.platform)
    try {
      this.mkdir(join(managedInstallDir(this.dshHome), 'bin'), { recursive: true })
    } catch (error) {
      return { ok: false, path: undefined, version: undefined, error: `无法创建 ${destination} 的目录：${messageOf(error)}` }
    }
    // 同一份二进制已经在了就别重下 40 MB：既省流量，也避免在 Windows 上 rename 覆盖
    // 一个正被登录会话/扫描占用的 .exe。sha 对不上（旧版本/坏文件）才继续下载覆盖。
    if (this.exists(destination)) {
      try {
        const existing = createHash('sha256').update(readFileSync(destination)).digest('hex')
        if (existing === expected) {
          const probe = await this.#probeVersion(destination)
          if (probe.ok) return { ok: true, path: destination, version: probe.version ?? version, error: undefined }
        }
      } catch { /* 读不出来就当没装过，走下载 */ }
    }
    // 临时文件名必须唯一（并发点两次安装不能互相截断），且 Windows 上必须以 `.exe`
    // 结尾——CreateProcess 不会执行无扩展名的文件，而我们要在落盘前就试跑它。
    const unique = randomBytes(6).toString('hex')
    const temporary = this.platform === 'win32'
      ? `${destination}.${unique}.download.exe`
      : `${destination}.${unique}.download`
    const errors = []
    const sources = [entry.url, entry.fallback].filter((url) => typeof url === 'string' && url !== '')
    for (const url of sources) {
      let cannotWrite = false
      try {
        const bytes = await this.#downloadBytes(url, timeoutMs)
        const digest = createHash('sha256').update(bytes).digest('hex')
        if (digest !== expected) throw new Error(`sha256 不匹配（期望 ${expected}，实际 ${digest}）`)
        writeFileSync(temporary, bytes)
        // 先 chmod 再验证/改名：chmod 失败时坏文件还停在临时路径，不会污染托管路径。
        if (this.platform !== 'win32') chmodSync(temporary, 0o755)
        const probe = await this.#probeVersion(temporary)
        if (!probe.ok) throw new Error(`下载的二进制无法执行：${probe.error ?? '未知原因'}`)
        try {
          renameSync(temporary, destination)
        } catch (error) {
          // 写不进去通常是被占用（Windows 上正在运行的 .exe 改不了名）。换下一个源
          // 只会再下 40 MB、然后同样写不进去，所以直接收手。
          cannotWrite = true
          throw new Error(`无法写入 ${destination}：${messageOf(error)}（如果 arkcli 正在运行或登录，请先取消再装）`)
        }
        return { ok: true, path: destination, version: probe.version ?? version, error: undefined }
      } catch (error) {
        try { rmSync(temporary, { force: true }) } catch { /* 临时文件清不掉不影响结论 */ }
        errors.push(`${url}：${messageOf(error)}`)
        if (cannotWrite) break
      }
    }
    return { ok: false, path: undefined, version: undefined, error: `下载 arkcli ${version}（${key}）失败：${errors.join('；')}` }
  }

  /**
   * 下载一个 URL 的全部字节。
   *
   * 用注入的 fetch：桌面端宿主跑在 Electron Node 模式里，全局 fetch 可用；测试里
   * 换成假实现就完全离线。超时用 `AbortSignal.timeout`（运行环境没提供时就不带）。
   *
   * @param url - 下载地址。
   * @param timeoutMs - 超时毫秒。
   * @returns `Buffer`。
   */
  async #downloadBytes(url, timeoutMs) {
    if (typeof this.fetchImpl !== 'function') throw new Error('当前运行环境没有 fetch，无法直接下载')
    const init = {}
    if (typeof AbortSignal !== 'undefined' && typeof AbortSignal.timeout === 'function') {
      init.signal = AbortSignal.timeout(timeoutMs)
    }
    const response = await this.fetchImpl(url, init)
    if (response === null || typeof response !== 'object') throw new Error('下载没有返回有效响应')
    const status = typeof response.status === 'number' ? response.status : (response.ok === false ? 0 : 200)
    if (response.ok === false || status < 200 || status >= 300) throw new Error(`HTTP ${status === 0 ? '失败' : status}`)
    if (typeof response.arrayBuffer !== 'function') throw new Error('下载响应不支持 arrayBuffer')
    // 先看声明的 Content-Length 就拒绝明显超大的响应，避免先把它读进内存再发现。
    const declared = Number(response.headers?.get?.('content-length') ?? Number.NaN)
    if (Number.isFinite(declared) && declared > MAX_BINARY_BYTES) throw new Error(`响应过大（${declared} 字节）`)
    const bytes = Buffer.from(await response.arrayBuffer())
    if (bytes.byteLength === 0) throw new Error('下载内容为空')
    if (bytes.byteLength > MAX_BINARY_BYTES) throw new Error(`响应过大（${bytes.byteLength} 字节）`)
    return bytes
  }

  /**
   * 查套餐额度（控制面，需要 SSO）。
   *
   * CodingPlan 的窗口只有 percent；AgentPlan 有 used/total。某个套餐出错时
   * 错误挂在 `items[].error` 上，其余套餐照常返回 —— 这里原样保留这种隔离。
   *
   * @returns `{ok, viewer, items, error}`。
   */
  async usagePlan(options = {}) {
    const { home, timeoutMs = DEFAULT_CONTROL_PLANE_TIMEOUT_MS } = options
    const result = await this.run(['usage', 'plan', '--format', 'json'], { home, timeoutMs })
    if (!result.ok) return { ok: false, viewer: undefined, items: [], error: result.error }
    const value = result.json
    if (value === null || typeof value !== 'object') {
      return { ok: false, viewer: undefined, items: [], error: 'usage plan 没有返回 JSON 对象。' }
    }
    const items = (Array.isArray(value.items) ? value.items : []).map(normalizeUsageItem)
    const viewer = value.viewer !== null && typeof value.viewer === 'object' ? value.viewer : undefined
    return { ok: true, viewer, items, error: undefined }
  }

  /**
   * 搜模型（控制面）。
   *
   * `keyword` 会作为 `--keyword` 传给 CLI；该参数名来自控制面搜索的通用约定，
   * 未逐一实测（`--format json --size 0` 是实测过的）。
   *
   * @returns `{ok, items, updatedAt, error}`。
   */
  async modelsSearch(options = {}) {
    const { home, keyword, size = 0, timeoutMs = DEFAULT_CONTROL_PLANE_TIMEOUT_MS } = options
    const args = ['models', 'search', '--format', 'json', '--size', String(size)]
    if (typeof keyword === 'string' && keyword.trim() !== '') args.push('--keyword', keyword.trim())
    const result = await this.run(args, { home, timeoutMs })
    if (!result.ok) return { ok: false, items: [], updatedAt: undefined, error: result.error }
    const value = result.json
    if (value === undefined) return { ok: false, items: [], updatedAt: undefined, error: 'models search 没有返回 JSON。' }
    const items = modelsItemsOf(value).filter((row) => row !== null && typeof row === 'object').map(normalizeModel)
    const envelope = Array.isArray(value) ? undefined : value
    const updatedAt = epochMs(envelope?.updated_at ?? envelope?.updatedAt)
    return { ok: true, items, updatedAt, error: undefined }
  }

  /**
   * 当前登录身份。
   *
   * 字段名以文档/binary 里的观察为准，多余或缺失都当正常。
   *
   * @returns `{ok, userId, userName, accountId, isRoot, authMethod, loggedIn, raw, error}`。
   */
  async whoami(options = {}) {
    const { home, timeoutMs = DEFAULT_RUN_TIMEOUT_MS } = options
    const result = await this.run(['auth', 'whoami', '--format', 'json'], { home, timeoutMs })
    const value = result.json !== null && typeof result.json === 'object' ? result.json : {}
    return {
      ok: result.ok,
      userId: stringOrUndefined(value.user_id),
      userName: stringOrUndefined(value.user_name),
      accountId: stringOrUndefined(value.account_id),
      isRoot: typeof value.is_root === 'boolean' ? value.is_root : undefined,
      authMethod: stringOrUndefined(value.auth_method),
      loggedIn: value.logged_in === true,
      raw: value,
      error: result.error,
    }
  }

  /**
   * 登录状态。
   *
   * @returns `{ok, loggedIn, authMethod, raw, error}`。
   */
  async authStatus(options = {}) {
    const { home, timeoutMs = DEFAULT_RUN_TIMEOUT_MS } = options
    const result = await this.run(['auth', 'status', '--format', 'json'], { home, timeoutMs })
    const value = result.json !== null && typeof result.json === 'object' ? result.json : {}
    return {
      ok: result.ok,
      loggedIn: value.logged_in === true,
      authMethod: stringOrUndefined(value.auth_method),
      raw: value,
      error: result.error,
    }
  }

  /**
   * 取当前 profile 的默认 API key（明文）。
   *
   * 不加 `--format json`：这个子命令本身就标称"机器可读"，加参数反而可能改变输出。
   * 形状未实测，所以解析按多种可能来（见 `extractApiKey`）。
   *
   * @returns `{ok, apiKey, error}`。
   */
  async profileApiKey(options = {}) {
    const { home, timeoutMs = DEFAULT_RUN_TIMEOUT_MS } = options
    const result = await this.run(['profile', 'apikey', 'get'], { home, timeoutMs })
    if (!result.ok) return { ok: false, apiKey: undefined, error: result.error }
    const apiKey = extractApiKey(result.stdout)
    if (apiKey === undefined) return { ok: false, apiKey: undefined, error: '没有从 profile apikey get 的输出里解析出 API key。' }
    return { ok: true, apiKey, error: undefined }
  }
}

// ---------------------------------------------------------------------------
// 登录会话（GUI 回调转发）
// ---------------------------------------------------------------------------

/**
 * 造一个 fetch 形状的请求函数，底层走 `node:http`。
 *
 * **为什么不用全局 fetch**：Fetch 规范把 `Host` 列为 forbidden header name，Node 24 的
 * undici 会**静默丢掉**我们设的 `host`（2026-10-16 实测：服务端收到的是自己算出来的
 * `127.0.0.1:<port>`，我们想送的 `localhost:<port>` 根本没出去）。而 arkcli 的回环
 * 监听会校验 Host，头被改掉就可能被判 `invalid host`、登录永远完不成。`node:http`
 * 不做这层过滤，实测能把我们指定的 Host 原样送出去。
 *
 * 只服务于回环 http 回调：不做 TLS、不跟重定向，返回值只要求 fetch 的
 * `{ok, status, text()}` 子集。
 *
 * @param requestImpl - `node:http.request`，可注入以便离线测试。
 */
export function createHttpFetch(requestImpl = httpRequest) {
  return async function httpFetch(url, init = {}) {
    const target = new URL(url)
    return await new Promise((resolve, reject) => {
      const request = requestImpl({
        protocol: target.protocol,
        hostname: target.hostname,
        port: target.port === '' ? undefined : target.port,
        path: `${target.pathname}${target.search}`,
        method: init.method ?? 'GET',
        headers: init.headers ?? {},
      }, (response) => {
        const chunks = []
        response.on('data', (chunk) => { chunks.push(String(chunk)) })
        response.on('end', () => {
          const status = response.statusCode ?? 0
          resolve({
            ok: status >= 200 && status < 300,
            status,
            headers: response.headers ?? {},
            text: async () => chunks.join(''),
          })
        })
      })
      request.on('error', reject)
      request.end()
    })
  }
}

/**
 * SSO 登录会话管理器。
 *
 * 一次登录 = 一个常驻子进程 + 一个回环监听。`start()` 把授权 URL 交出去，
 * 用户在浏览器里完成 SSO（跳转会失败，但地址栏留下回调 URL），`submit()` 把那条
 * URL 转发到本机监听上完成登录。详见文件头。
 */
export class ArkCliLogin {
  /**
   * @param options - 与 `ArkCli` 相同的依赖；会用它建一个内部的 `ArkCli` 来解析 bin。
   * @param options.fetchImpl - 自定义的请求实现；缺省用 `createHttpFetch()`（见其说明：
   *   全局 fetch 无法把 Host 头送出去，而回环监听会校验 Host）。
   * @param options.requestImpl - 透传给 `createHttpFetch` 的 `node:http.request`。
   * @param options.refFactory - 生成会话 ref，缺省随机 hex。
   */
  constructor(options = {}) {
    this.cli = new ArkCli(options)
    this.spawn = options.spawn ?? nodeSpawn
    this.fetchImpl = options.fetchImpl ?? createHttpFetch(options.requestImpl)
    this.now = options.now ?? Date.now
    this.logger = options.logger
    this.refFactory = typeof options.refFactory === 'function' ? options.refFactory : () => randomBytes(6).toString('hex')
    /** @type {Map<string, object>} */
    this.sessions = new Map()
  }

  /** 当前活着的会话数（含已经 done/expired 但还没被回收的）。 */
  size() {
    return this.sessions.size
  }

  /** 杀子进程（含它执行出来的孙子进程；已退出的忽略）。 */
  #kill(session) {
    if (session.exited) return
    // 关键：`node_modules/.bin/arkcli` 是个 node 包装脚本，它用 `execFileSync` 阻塞地
    // 去跑真正的 Go 二进制。**杀包装进程不会杀掉 Go 孙子进程** —— 实测 SIGKILL 掉包装之后，
    // Go 二进制被 init 收养、回环端口继续 LISTEN，用户以为取消了其实没有（端口还占着，
    // 下一次登录又会起一个新的）。所以 POSIX 上登录会话以 `detached: true` 起独立进程组，
    // 按**进程组**杀；Windows 上用 taskkill 整棵树带走（见 killProcessTree）。
    killProcessTree(session.child, { platform: this.cli.platform, spawnSync: this.cli.spawnSync, comspec: this.cli.comspec })
  }

  /** 从表里移除并唤醒所有等待者。 */
  #drop(session) {
    this.sessions.delete(session.ref)
    for (const waiter of session.waiters.splice(0)) waiter()
  }

  /** 彻底收尾：清定时器 + 杀子进程 + 移出表。 */
  #dispose(session) {
    if (session.ttlTimer !== undefined) {
      clearTimeout(session.ttlTimer)
      session.ttlTimer = undefined
    }
    this.#kill(session)
    this.#drop(session)
  }

  /**
   * 发起登录：起 `auth login --no-browser`，从输出里抠出授权 URL 与回环端口。
   *
   * @param options - `home`（必填）、等 URL 的超时、会话 TTL、调用方自定义的 ref。
   * @returns `{ok, ref, url, port, error}`。
   */
  async start(options = {}) {
    const { home, timeoutMs = LOGIN_START_TIMEOUT_MS, ttlMs = LOGIN_TTL_MS, ref = this.refFactory() } = options
    const childEnv = buildChildEnv(home, undefined, this.cli.platform)
    const resolved = await this.cli.resolveBin()
    if (resolved.path === undefined) {
      return { ok: false, ref, url: undefined, port: undefined, error: '找不到 arkcli：请先安装，或在设置里指定可执行文件路径。' }
    }
    const loginArgs = ['auth', 'login', '--no-browser']
    const plan = spawnPlanFor(resolved.path, loginArgs, this.cli.platform, this.cli.comspec)
    let child
    try {
      // POSIX 上 `detached: true` 让子进程成为独立进程组组长：这样 `#kill` 能按组把
      // 包装脚本和它 exec 出来的 Go 二进制一起收掉（原因见 `#kill`）。Windows 上
      // detached 会另开控制台窗口，而且本来就要靠 taskkill，所以不用。
      child = this.spawn(plan.command, plan.args, {
        stdio: ['ignore', 'pipe', 'pipe'],
        env: childEnv,
        detached: this.cli.platform !== 'win32',
        windowsHide: true,
        ...plan.verbatim ? { windowsVerbatimArguments: true } : {},
      })
    } catch (error) {
      return { ok: false, ref, url: undefined, port: undefined, error: `无法启动 arkcli：${messageOf(error)}` }
    }
    // 同一个 ref 再次 start：先把旧会话收掉，避免留下孤儿进程。
    const previous = this.sessions.get(ref)
    if (previous !== undefined) this.#dispose(previous)
    const session = {
      ref,
      home,
      child,
      url: undefined,
      port: undefined,
      state: 'pending',
      code: undefined,
      error: undefined,
      output: '',
      note: undefined,
      // 身份由调用方另外用 whoami 解析；这里明确"还没解析"。
      identityUnknown: true,
      createdAt: this.now(),
      exited: false,
      ttlTimer: undefined,
      waiters: [],
    }
    this.sessions.set(ref, session)
    this.logger?.debug?.(`[arkcli] auth login 已启动 ref=${ref}`)

    return await new Promise((resolve) => {
      let settled = false
      let startTimer
      const settle = (result) => {
        if (settled) return
        settled = true
        clearTimeout(startTimer)
        resolve(result)
      }
      const onChunk = (chunk) => {
        if (session.output.length < MAX_CHILD_OUTPUT_CHARS) session.output += String(chunk)
        const urlMatch = /https:\/\/\S+/.exec(session.output)
        const portMatch = /callbackPort=(\d+)/.exec(session.output)
        if (urlMatch === null || portMatch === null) return
        session.url = urlMatch[0]
        session.port = Number(portMatch[1])
        // TTL 只武装一次。以前每个 data 事件都重新武装（等于"只要有输出就永不过期"），
        // 而且成功后**不清掉**：登录成功 10 分钟后再看设置页，会话状态已经被 TTL 回调
        // 从 done 改写成 expired，界面显示"登录会话已过期"，纯属误报。
        if (session.ttlTimer !== undefined) {
          settle({ ok: true, ref, url: session.url, port: session.port })
          return
        }
        session.ttlTimer = setTimeout(() => {
          session.ttlTimer = undefined
          // 已经有结论（成功/失败）就不要再改写成"过期"。
          if (session.state !== 'pending') return
          session.state = 'expired'
          session.error = '登录会话已过期，请重新发起授权。'
          this.#kill(session)
          for (const waiter of session.waiters.splice(0)) waiter()
        }, ttlMs)
        // 定时器不该单独把进程吊住（子进程句柄本来就会撑着事件循环）。
        session.ttlTimer.unref?.()
        settle({ ok: true, ref, url: session.url, port: session.port })
      }
      child.stdout?.on?.('data', onChunk)
      child.stderr?.on?.('data', onChunk)
      child.on?.('error', (error) => {
        session.state = 'error'
        session.error = messageOf(error)
        this.#dispose(session)
        settle({ ok: false, ref, url: session.url, port: session.port, error: `arkcli auth login 无法启动：${session.error}` })
      })
      child.on?.('close', (code) => {
        session.exited = true
        session.code = code
        if (session.state === 'pending') session.state = code === 0 ? 'done' : 'error'
        if (code !== 0 && session.error === undefined) {
          session.error = lastMeaningfulLine(session.output) ?? `arkcli auth login 退出码 ${code}`
        }
        // 已经有结论，就别再让 TTL 定时器把它改写成 expired —— 否则一次**成功**的登录
        // 在 10 分钟后会显示成"登录会话已过期"。
        if (session.ttlTimer !== undefined) {
          clearTimeout(session.ttlTimer)
          session.ttlTimer = undefined
        }
        // 输出与子进程句柄都可以放掉了：结论已经记在 state/error 上，poll 只需要它。
        // （下面提前退出分支要用到输出，所以先取好 tail 再清。）
        const tail = lastMeaningfulLine(session.output)
        session.output = ''
        for (const waiter of session.waiters.splice(0)) waiter()
        if (!settled) {
          const error = `arkcli auth login 提前退出（退出码 ${code}）：${tail ?? '没有输出'}`
          this.#drop(session)
          settle({ ok: false, ref, url: session.url, port: session.port, error })
        }
      })
      startTimer = setTimeout(() => {
        const error = `等待授权链接超时（${timeoutMs}ms）：${lastMeaningfulLine(session.output) ?? 'arkcli 没有输出授权链接'}`
        this.#dispose(session)
        settle({ ok: false, ref, url: session.url, port: session.port, error })
      }, timeoutMs)
    })
  }

  /**
   * 查一次会话状态。
   *
   * @returns `{ok, state, url, code, error}`；ref 不存在时 state='unknown'。
   */
  poll(options = {}) {
    const session = this.sessions.get(options.ref)
    if (session === undefined) {
      return { ok: false, state: 'unknown', url: undefined, code: undefined, error: '登录会话不存在（可能已取消、已过期或已完成）。' }
    }
    return { ok: true, state: session.state, url: session.url, code: session.code, error: session.error }
  }

  /** 等会话进入终态；已经终态则立刻返回。 */
  #waitForTerminal(session, waitMs) {
    if (session.state !== 'pending') return Promise.resolve({ state: session.state, error: session.error })
    return new Promise((resolve) => {
      let timer
      const done = () => {
        clearTimeout(timer)
        session.waiters = session.waiters.filter((waiter) => waiter !== done)
        resolve({ state: session.state, error: session.error })
      }
      session.waiters.push(done)
      timer = setTimeout(done, waitMs)
    })
  }

  /**
   * 提交用户从浏览器地址栏复制的回调 URL（或裸授权码）。
   *
   * @param options - `ref`、`input`、转发后等终态的 `waitMs`。
   * @returns `{ok, state, error}`（可能带 `note`）。
   */
  async submit(options = {}) {
    const { ref, input, waitMs = LOGIN_WAIT_TIMEOUT_MS } = options
    const session = this.sessions.get(ref)
    if (session === undefined) return { ok: false, state: 'unknown', error: '登录会话不存在（可能已取消、已过期或已完成）。' }
    if (session.state !== 'pending') return { ok: session.state === 'done', state: session.state, error: session.error }
    const value = typeof input === 'string' ? input.trim() : ''
    if (value === '') return { ok: false, state: 'pending', error: '没有拿到回调 URL：请把浏览器地址栏里的完整地址复制过来。' }
    if (/^https?:\/\//i.test(value)) return await this.#forward(session, value, waitMs)
    return await this.#codePath(session, value)
  }

  /** 把回调 URL 转发到本机回环监听。 */
  async #forward(session, input, waitMs) {
    let parsed
    try {
      parsed = new URL(input)
    } catch {
      return { ok: false, state: session.state, error: '粘贴的内容不是合法的 URL。' }
    }
    const pathname = parsed.pathname === '' ? '/' : parsed.pathname
    if (pathname !== CALLBACK_PATH) {
      // 只认这一个路由。以前是"不是预期路由也照转，只是记一笔" —— 那等于把本机回环
      // 监听当成一个可以投递任意路径的转发器；而这条地址本来就是用户从浏览器地址栏
      // 粘回来的回调 URL，正常必然是 CALLBACK_PATH。
      return {
        ok: false,
        state: session.state,
        error: `粘贴的地址路径是 ${pathname}，不是登录回调地址 ${CALLBACK_PATH}。请在浏览器地址栏里复制完整的那条地址。`,
      }
    }
    const search = parsed.search
    // 端口一律取会话里记录的那个：用户粘的 URL 可能来自上一次登录（端口已失效）。
    const target = `http://127.0.0.1:${session.port}${pathname}${search}`
    // Host 头是实测出来的，而且很挑：回环监听**只认** `127.0.0.1:<这个端口>`。
    // 逐条试过（live listener，1.0.39）：
    //   127.0.0.1:<port>  → 400 invalid callback parameters（Host 通过，只是参数假的）
    //   localhost:<port>  → 400 invalid host
    //   127.0.0.1 / localhost / [::1]:<port> / 端口差 1 / 大小写  → 400 invalid host
    // 所以这里以 `127.0.0.1:<port>` 为准；万一以后哪个版本改成只认 localhost，
    // 下面那个 `invalid host` 分支会自动再试一次，不至于把功能锁死在一个版本上。
    const hosts = [`127.0.0.1:${session.port}`, `localhost:${session.port}`]
    let status = 0
    let body = ''
    // 每次尝试只读一次正文（`createHttpFetch` 的返回值没有 `clone()`，别去二次读流）。
    for (let attempt = 0; attempt < hosts.length; attempt += 1) {
      let response
      try {
        response = await this.fetchImpl(target, { method: 'GET', headers: { host: hosts[attempt] }, redirect: 'manual' })
      } catch (error) {
        return { ok: false, state: session.state, error: `回调转发失败：${messageOf(error)}（本机监听可能已结束，请重新发起登录。）` }
      }
      status = Number(response.status)
      try { body = await response.text() } catch { body = '' }
      const retryable = status === 400 && /invalid host/i.test(body) && attempt + 1 < hosts.length
      if (!retryable) break
    }
    if (!(status >= 200 && status < 300)) {
      return { ok: false, state: session.state, error: `回调被拒绝（HTTP ${status}）：${body.slice(0, 200)}` }
    }
    const terminal = await this.#waitForTerminal(session, waitMs)
    if (terminal.state === 'pending') return { ok: true, state: 'pending', error: undefined, note: session.note }
    // 终态：捕获结果后立刻回收，绝不留一个还在跑的子进程。
    const result = { ok: terminal.state === 'done', state: terminal.state, error: terminal.error, note: session.note }
    this.#dispose(session)
    return result
  }

  /** 裸授权码：本构建没有 `--code` 兑换，明确告诉调用方去粘 URL。 */
  async #codePath(session, code) {
    const result = await this.cli.run(['auth', 'login', '--no-browser', '--code', code], { home: session.home, timeoutMs: LOGIN_WAIT_TIMEOUT_MS })
    if (result.ok) {
      session.state = 'done'
      session.code = 0
      this.#dispose(session)
      return { ok: true, state: 'done', error: undefined }
    }
    // 子进程保持存活：用户改成粘回调 URL 后这条会话仍然可用。
    const detail = result.error ?? '未知错误'
    return {
      ok: false,
      state: 'error',
      error: `这个 arkcli 构建不支持 --code 授权码兑换（${detail}）。请在浏览器地址栏里复制完整的回调 URL（形如 http://127.0.0.1:<port>${CALLBACK_PATH}?...）再提交，不要只给授权码。`,
    }
  }

  /** 取消一条会话：杀子进程并移出表。 */
  cancel(options = {}) {
    const session = this.sessions.get(options.ref)
    if (session === undefined) return { ok: false, error: '登录会话不存在。' }
    // 已经自己退出的会话没什么可杀的；如实回报，别让调用方以为"取消"生效了。
    const killed = session.exited !== true
    this.#dispose(session)
    return { ok: true, killed }
  }

  /** 插件卸载/关闭时调用：杀掉所有子进程。 */
  disposeAll() {
    let killed = 0
    for (const session of [...this.sessions.values()]) {
      this.#dispose(session)
      killed += 1
    }
    this.sessions.clear()
    return { ok: true, killed }
  }
}
