/**
 * 自包含测试入口。
 *
 * 为什么需要它：插件的宿主半边 `import` 了 `@deepseek-ai/dsh-llm` 这类 harness 包。
 * 在 profile 里跑，这些包由 DSH 的运行时拦截（`pluginPackages` + `loader.internal.import`）
 * 解析；用裸 `node` 跑就没有那层拦截，直接 `ERR_MODULE_NOT_FOUND`。
 *
 * 所以这里在临时目录里搭一个沙箱：把插件文件拷进去，并在 `node_modules/@deepseek-ai/`
 * 下建指向 harness 安装位置的符号链接。这样两个测试都能在 workspace 里直接跑。
 *
 * ```sh
 * npm test                              # 客户端那半，不需要密钥
 * ARK_CODING_TEST_KEY=ark-... npm test  # 再加上打真实 Coding Plan 端点的适配器测试
 * ```
 */

import { cpSync, existsSync, mkdirSync, mkdtempSync, rmSync, symlinkSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { dirname, join, resolve } from 'node:path'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const packageRoot = resolve(here, '..')

/**
 * 宿主半边需要解析的 harness 包。
 *
 * `@deepseek-ai/cordis` 是给 `tests/host.test.mjs` 用的：它要在一个**真的** cordis
 * Context 上跑 `apply()`，才能从 `ctx.get('arkCodingUsage')` 取回闭包里的 deps
 * （HOME 校验、缓存键、在途去重都藏在那里）。假 ctx 拿不到这些。
 */
const NEEDED = [
  '@deepseek-ai/dsh-llm',
  '@deepseek-ai/dsh-credentials',
  '@deepseek-ai/dsh-home-paths',
  '@deepseek-ai/dsh-launch-environment',
  '@deepseek-ai/dsh-typert-protocol',
  '@deepseek-ai/dsh-util-values',
  '@deepseek-ai/schemastery',
  '@deepseek-ai/cordis',
]

/** 候选的搜索根：先看环境变量，再看 dsh 可执行文件的位置，最后兜一个常见全局安装路径。 */
function searchRoots() {
  const roots = []
  if (process.env.DSH_HARNESS_ROOT) roots.push(process.env.DSH_HARNESS_ROOT)
  if (process.env.DSH_PROFILE_DIR) roots.push(process.env.DSH_PROFILE_DIR)
  const dshBin = process.env.DSH_BIN ?? 'dsh'
  try {
    const resolved = execFileSync('sh', ['-c', `command -v ${dshBin}`], { encoding: 'utf8' }).trim()
    if (resolved !== '') roots.push(resolve(dirname(resolved), '..', 'lib', 'node_modules', '@deepseek-ai', 'dsh'))
  } catch { /* dsh 不在 PATH 上 */ }
  roots.push('/opt/node24/lib/node_modules/@deepseek-ai/dsh')
  return roots
}

/** 在一个搜索根下找某个 harness 包的真实目录（它在 <root>/node_modules/@deepseek-ai/ 下）。 */
function locate(root, name) {
  const short = name.replace('@deepseek-ai/', '')
  const candidates = [
    join(root, 'node_modules', '@deepseek-ai', short),
    join(root, 'node_modules', name),
  ]
  for (const candidate of candidates) {
    if (existsSync(join(candidate, 'package.json'))) return candidate
  }
  return undefined
}

function sandboxPath() {
  const roots = searchRoots()
  const resolved = new Map()
  for (const name of NEEDED) {
    for (const root of roots) {
      const found = locate(root, name)
      if (found !== undefined) { resolved.set(name, found); break }
    }
  }
  return { roots, resolved }
}

function run(label, script, cwd, env) {
  process.stdout.write(`\n===== ${label} =====\n`)
  try {
    execFileSync(process.execPath, [script], { cwd, env, stdio: 'inherit' })
    return true
  } catch {
    return false
  }
}

// --- 离线测试：不依赖 harness 包，任何地方都能跑 ---------------------------
const usageOk = run('usage & accounts (offline)', join(here, 'usage.test.mjs'), packageRoot, process.env)
const arkcliOk = run('arkcli bridge (offline)', join(here, 'arkcli.test.mjs'), packageRoot, process.env)
const clientOk = run("client bundle (offline)", join(here, 'client.test.mjs'), packageRoot, process.env)

// --- 需要 harness 包的测试：搭一次沙箱，两边共用 ---------------------------
//
// 沙箱本来只为"打真实端点"的适配器测试而建，但流式 chunk 契约测试与宿主适配器
// 本体测试同样需要 harness 包、却**不需要密钥也不需要网络**（它们喂假 SSE / 假
// fetch），所以现在沙箱无条件搭，沙箱里的这两个套件无条件跑，只有真端点那一套
// 看密钥脸色。
let hostOk = true
let streamOk = true
let adapterOk = true
const key = process.env.ARK_CODING_TEST_KEY ?? process.env.ARK_CODING_API_KEY
const { roots, resolved } = sandboxPath()
const missing = NEEDED.filter((name) => !resolved.has(name))

if (missing.length > 0) {
  console.log('\n===== harness-backed suites (skipped) =====')
  console.log(`找不到 harness 包：${missing.join(', ')}`)
  console.log(`已尝试的根目录：${roots.join(' | ')}`)
  console.log('设 DSH_HARNESS_ROOT 指向 dsh 安装目录可解决。')
  hostOk = false
  streamOk = false
  adapterOk = false
} else {
  const sandbox = mkdtempSync(join(tmpdir(), 'ark-coding-test-'))
  try {
    // 测试脚本本身也要拷进沙箱：ESM 的解析基准是"脚本自己的路径"，
    // 从 workspace 里跑它，`../index.js` 仍会落在没有 node_modules 的包根上。
    for (const file of ['index.js', 'models.js', 'client.js', 'accounts.js', 'usage.js', 'arkcli.js']) cpSync(join(packageRoot, file), join(sandbox, file))
    mkdirSync(join(sandbox, 'tests'), { recursive: true })
    for (const test of ['host.test.mjs', 'stream.test.mjs', 'adapter.test.mjs']) cpSync(join(here, test), join(sandbox, 'tests', test))
    mkdirSync(join(sandbox, 'node_modules', '@deepseek-ai'), { recursive: true })
    for (const [name, target] of resolved) {
      const short = name.replace('@deepseek-ai/', '')
      symlinkSync(target, join(sandbox, 'node_modules', '@deepseek-ai', short))
    }
    hostOk = run('host adapter (offline, no key)', join(sandbox, 'tests', 'host.test.mjs'), sandbox, process.env)
    streamOk = run('stream chunk contract (offline)', join(sandbox, 'tests', 'stream.test.mjs'), sandbox, process.env)
    if (key === undefined || key.trim() === '') {
      console.log('\n===== adapter (SKIP) =====')
      console.log('未设置 ARK_CODING_TEST_KEY，跳过打真实端点的适配器测试（套件自身也会打印 SKIP）。')
      console.log('要跑它：ARK_CODING_TEST_KEY=ark-... npm test')
    } else {
      adapterOk = run('adapter (live endpoint)', join(sandbox, 'tests', 'adapter.test.mjs'), sandbox, {
        ...process.env,
        ARK_CODING_TEST_KEY: key,
      })
    }
  } finally {
    rmSync(sandbox, { recursive: true, force: true })
  }
}

const everythingOk = usageOk && arkcliOk && clientOk && hostOk && streamOk && adapterOk
console.log(`\n${everythingOk ? 'ALL SUITES PASSED' : 'SOME SUITES FAILED'}`)
process.exit(everythingOk ? 0 : 1)
