/**
 * 用量 / 多账户的离线测试。
 *
 * 全部不需要网络也不需要 harness 包：`usage.js` 与 `accounts.js` 都是纯模块。
 * 打真实控制面的那次探测在 `run.mjs` 里单独做（用假凭据确认请求结构被接受）。
 */
import {
  AccountMarks,
  cooldownFor,
  describeAccounts,
  orderAccounts,
  rotationReasonFor,
  sidebarQuotaState,
} from '../accounts.js'
import {
  amzDate,
  fetchCodingPlanUsage,
  parseCodingPlanUsage,
  sha256Hex,
  volcengineSignedHeaders,
} from '../usage.js'

let failures = 0
const check = (name, ok, detail) => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail === undefined ? '' : ` — ${detail}`}`)
  if (!ok) failures += 1
}

// --- V4 签名 -----------------------------------------------------------------
const emptyHash = sha256Hex('')
check('sha256 of the empty body is the known constant',
  emptyHash === 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', emptyHash)

const at = new Date('2026-10-16T00:00:00Z')
check('amzDate renders the compact ISO8601 form', amzDate(at) === '20261016T000000Z', amzDate(at))

const headers = volcengineSignedHeaders({
  accessKeyId: 'AKLTexample',
  secretAccessKey: 'secret',
  query: 'Action=GetCodingPlanUsage&Version=2024-01-01',
  date: at,
})
check('signing covers exactly the four canonical headers',
  headers.authorization.includes('SignedHeaders=content-type;host;x-content-sha256;x-date'), headers.authorization)
check('credential scope is <date>/<region>/<service>/request',
  headers.authorization.includes('Credential=AKLTexample/20261016/cn-beijing/ark/request'), headers.authorization)
check('the Authorization scheme is HMAC-SHA256', headers.authorization.startsWith('HMAC-SHA256 '))
check('a signature is present and hex', /Signature=[0-9a-f]{64}$/.test(headers.authorization), headers.authorization.slice(-20))
check('signing is deterministic',
  volcengineSignedHeaders({ accessKeyId: 'AKLTexample', secretAccessKey: 'secret', query: 'Action=GetCodingPlanUsage&Version=2024-01-01', date: at }).authorization === headers.authorization)
check('a different query yields a different signature',
  volcengineSignedHeaders({ accessKeyId: 'AKLTexample', secretAccessKey: 'secret', query: 'Action=Other&Version=2024-01-01', date: at }).authorization !== headers.authorization)
check('a different key yields a different signature',
  volcengineSignedHeaders({ accessKeyId: 'AKLTexample', secretAccessKey: 'other', query: 'Action=GetCodingPlanUsage&Version=2024-01-01', date: at }).authorization !== headers.authorization)
check('query parameters are sorted canonically',
  volcengineSignedHeaders({ accessKeyId: 'AKLTexample', secretAccessKey: 'secret', query: 'Version=2024-01-01&Action=GetCodingPlanUsage', date: at }).authorization
  === headers.authorization, 'order of the query string must not matter')

// --- 额度解析 ---------------------------------------------------------------
// 夹具刻意带上越界百分比：`-5` 与 `120.456`。删掉实现里的
// `Math.max(0, Math.min(100, …))` 时，这两行必须变红（旧夹具全在合法区间，抓不到）。
const parsed = parseCodingPlanUsage({
  ResponseMetadata: { RequestId: 'x' },
  Result: {
    Status: 'Normal',
    UpdateTimestamp: 1792083000000,
    QuotaUsage: [
      { Level: 'monthly', Percent: 71.5, ResetTimestamp: 1793462400 },
      { Level: 'weekly', Percent: 120.456, ResetTimestamp: 1792252800 },
      { Level: 'session', Percent: -5, ResetTimestamp: 1792084800 },
    ],
  },
})
check('all three levels parse', parsed.windows.length === 3, JSON.stringify(parsed.windows.map((w) => w.level)))
check('windows are ordered session → weekly → monthly',
  parsed.windows.map((w) => w.level).join(',') === 'session,weekly,monthly', parsed.windows.map((w) => w.level).join(','))
check('reset seconds are converted to milliseconds',
  parsed.windows[0].resetAt === 1792084800000, String(parsed.windows[0].resetAt))
check('percent is labelled and clamped into 0..100',
  parsed.windows[0].label === '5 小时' && parsed.windows[0].percent === 0
  && parsed.windows[1].percent === 100 && parsed.windows[2].percent === 71.5,
  JSON.stringify(parsed.windows.map((w) => w.percent)))
check('a missing Result is rejected',
  (() => { try { parseCodingPlanUsage({}); return false } catch { return true } })())

// resetAt 越界必须当"没有"：负数会渲染成 1970-01-01，天文数字会渲染成 Invalid
// Date —— 都是**假日期**，比什么都不显示更糟，而且 formatClock 的 try/catch 拦不住。
const bounds = parseCodingPlanUsage({
  Result: {
    QuotaUsage: [
      { Level: 'session', Percent: 1, ResetTimestamp: -1 },
      { Level: 'weekly', Percent: 1, ResetTimestamp: 1e300 },
      { Level: 'monthly', Percent: 1, ResetTimestamp: 1792084800000 },
    ],
  },
})
check('an out-of-range reset timestamp becomes null instead of a fake date',
  bounds.windows[0].resetAt === null && bounds.windows[1].resetAt === null, JSON.stringify(bounds.windows.map((w) => w.resetAt)))
check('an already-millisecond reset timestamp is not scaled twice',
  bounds.windows[2].resetAt === 1792084800000, String(bounds.windows[2].resetAt))

// 控制面请求必须带 user-agent（排障时能从服务端日志里认出是本插件）。
{
  const seen = []
  const payload = JSON.stringify({ Result: { QuotaUsage: [] } })
  await fetchCodingPlanUsage({
    accessKeyId: 'AKLTexample',
    secretAccessKey: 'secret',
    fetchImpl: async (url, init) => { seen.push({ url, init }); return { ok: true, status: 200, text: async () => payload } },
  })
  check('the control-plane request carries the plugin user-agent',
    seen.length === 1 && seen[0].init.headers['user-agent'] === 'dsh-ark-coding-provider',
    JSON.stringify(seen[0]?.init?.headers?.['user-agent']))
  check('the control-plane request is a signed POST to the documented host',
    seen[0].init.method === 'POST' && seen[0].url === 'https://open.volcengineapi.com/?Action=GetCodingPlanUsage&Version=2024-01-01'
    && /^HMAC-SHA256 Credential=/.test(seen[0].init.headers.authorization),
    seen[0].url)
}

// --- 侧边栏卡片的三态判据 ---------------------------------------------------
// 这条规则决定"左下角那张卡片显不显示"，必须能被离线钉死。
check('auto shows the card once something can read quota',
  sidebarQuotaState('auto', true).show === true && sidebarQuotaState('auto', true).capable === true)
check('auto hides the card while nothing can read quota',
  sidebarQuotaState('auto', false).show === false && sidebarQuotaState('auto', false).mode === 'auto')
check('on wins over a missing binding', sidebarQuotaState('on', false).show === true)
check('off wins over a working binding', sidebarQuotaState('off', true).show === false)
check('an unknown mode degrades to auto',
  sidebarQuotaState('wat', true).mode === 'auto' && sidebarQuotaState(undefined, false).show === false)

// --- 多账户 -----------------------------------------------------------------
// **没有**默认账户这回事了：accounts 为空就是"一个账户都没有"。
// 以前顶层 apiKeyEnv/apiKey 会自动变成一个 id=default 的账户，现在不这样了 ——
// 那样会造出一个"没法走 CLI 登录、规则还跟别人不一样"的特例，而且用户删掉它之后
// 只要顶层字段还在就会自己冒回来。
const orphanTopLevel = describeAccounts({ apiKeyEnv: 'ARK_CODING_API_KEY', apiKey: ' ark-literal ', accountLabel: '默认' })
check('an empty account list stays empty (no synthesized default account)',
  orphanTopLevel.length === 0, JSON.stringify(orphanTopLevel))
check('a missing account list is also empty',
  describeAccounts({}).length === 0 && describeAccounts({ accounts: [] }).length === 0)

// accounts 是唯一真源：顶层的 key 完全不再参与。
const config = {
  apiKeyEnv: 'ARK_CODING_API_KEY',
  apiKey: 'ark-ignored',
  accounts: [
    { id: 'main', label: '猫猫', apiKeyEnv: 'ARK_CODING_API_KEY_2' },
    { label: '', apiKeyEnv: 'ARK_CODING_API_KEY_3' },
    { id: 'cli-1', label: '公司号', type: 'cli' },
  ],
}
const described = describeAccounts(config)
check('a non-empty account list is the only source of truth',
  described.length === 3 && !described.some((a) => a.literal === 'ark-ignored'),
  JSON.stringify(described.map((a) => [a.id, a.literal])))
check('explicit ids are kept and missing ones get a stable fallback',
  described[0].id === 'main' && described[1].id === 'account-2' && described[2].id === 'cli-1',
  JSON.stringify(described.map((a) => a.id)))
check('a custom label is kept; an empty one becomes a typed default name',
  described[0].label === '猫猫' && described[0].labelIsCustom === true
  && described[1].label === 'API Key 账户 2' && described[1].labelIsCustom === false,
  JSON.stringify(described.map((a) => [a.label, a.labelIsCustom])))
check('cli accounts carry no credential ref and no default home',
  described[2].type === 'cli' && described[2].ref === '' && described[2].home === undefined,
  JSON.stringify(described[2]))
check('an explicit home on a cli account is preserved',
  describeAccounts({ accounts: [{ id: 'x', type: 'cli', home: '/tmp/h' }] })[0].home === '/tmp/h')
const evilId = describeAccounts({ accounts: [{ id: '../../etc/passwd' }] })[0].id
check('account ids are sanitized so they cannot escape the accounts dir',
  !evilId.includes('/') && !evilId.includes('\\') && !evilId.startsWith('.'), evilId)
check('an unknown account type degrades to apikey',
  describeAccounts({ accounts: [{ id: 'z', type: 'wat' }] })[0].type === 'apikey')

check('rotation triggers only on account-scoped failures',
  rotationReasonFor('AUTH') === 'invalid-credential'
  && rotationReasonFor('RATE_LIMIT') === 'rate-limit'
  && rotationReasonFor('QUOTA') === 'quota'
  && rotationReasonFor('CONTEXT_WINDOW_EXCEEDED') === undefined
  && rotationReasonFor('PROVIDER_ERROR') === undefined)
check('auth failures cool down longer than rate limits',
  cooldownFor('invalid-credential') > cooldownFor('rate-limit'))

const marks = new AccountMarks()
const accounts = [
  { id: 'default', label: 'default', key: 'k1' },
  { id: 'account-2', label: 'two', key: 'k2' },
  { id: 'account-3', label: 'three', key: 'k3' },
]
check('unmarked accounts keep their order',
  orderAccounts(accounts, marks).map((a) => a.id).join(',') === 'default,account-2,account-3')
marks.mark('account-2', 'rate-limit', Date.now() + 60_000)
check('a cooling account moves to the back, not out of the pool',
  orderAccounts(accounts, marks).map((a) => a.id).join(',') === 'default,account-3,account-2')
check('an unusable (no key) account is dropped',
  orderAccounts([...accounts, { id: 'account-9', label: 'x', key: undefined }], marks).length === 3)
check('a preferred account wins even while cooling',
  orderAccounts(accounts, marks, 'account-2')[0].id === 'account-2')
check('the mark expires on its own',
  orderAccounts(accounts, new AccountMarks(() => Date.now() + 120_000)).map((a) => a.id).join(',') === 'default,account-2,account-3')
check('marks snapshot only lists live marks',
  Object.keys(marks.snapshot()).join(',') === 'account-2', JSON.stringify(marks.snapshot()))

// --- 控制面可达性（假凭据） -------------------------------------------------
// 用一对假 AK/SK 打真实控制面：期望被"鉴权"拒绝，而不是"请求畸形"。
// 这能证明 canonical request / 签名头结构被服务端接受了。
try {
  await fetchCodingPlanUsage({ accessKeyId: 'AKLTfake0000000000000000000000', secretAccessKey: 'ZmFrZWZha2VmYWtlZmFrZWZha2VmYWtl' })
  check('fake credentials are rejected by the control plane', false, 'unexpected success')
} catch (error) {
  const message = String(error?.message ?? error)
  check('fake credentials are rejected by the control plane (structure accepted)',
    /AccessKey|access key|Signature|signature/i.test(message), message.slice(0, 140))
}

console.log(failures === 0 ? '\nALL PASS' : `\n${failures} FAILURE(S)`)
process.exit(failures === 0 ? 0 : 1)
