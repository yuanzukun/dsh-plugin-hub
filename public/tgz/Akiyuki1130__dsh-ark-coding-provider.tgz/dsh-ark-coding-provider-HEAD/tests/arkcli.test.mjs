/**
 * arkcli 封装层的离线测试。
 *
 * 全部离线：**不起真的 arkcli、不碰网络**。spawn 与 fetch 都是注入的假实现，
 * 按脚本吐出 stdout/stderr 与退出码；PATH 查找与托管目录用临时目录伪造。
 * 因此这个文件可以直接 `node tests/arkcli.test.mjs` 跑，不需要 harness 包。
 */
import { EventEmitter } from 'node:events'
import { spawn as nodeSpawn } from 'node:child_process'
import { createHash } from 'node:crypto'
import { chmodSync, existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { createServer } from 'node:http'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import {
  ARKCLI_BINARIES,
  ARKCLI_BINARY_VERSION,
  ARKCLI_PACKAGE,
  ArkCli,
  ArkCliLogin,
  accountHomeDir,
  arkcliStateRoot,
  buildChildEnv,
  createHttpFetch,
  extractApiKey,
  findExecutableOnPath,
  killProcessTree,
  managedBinCandidates,
  managedBinPath,
  managedBinaryPath,
  managedInstallDir,
  modelsItemsOf,
  normalizeModel,
  normalizeUsageItem,
  parseArkcliJson,
  parseResetAt,
  platformKeyOf,
  readCredentialExpiry,
  sanitizeAccountId,
  spawnPlanFor,
} from '../arkcli.js'

let failures = 0
const check = (name, ok, detail) => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail === undefined ? '' : ` — ${detail}`}`)
  if (!ok) failures += 1
}
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

// --- 假子进程 -----------------------------------------------------------------

class FakeChild extends EventEmitter {
  constructor() {
    super()
    this.stdout = new EventEmitter()
    this.stderr = new EventEmitter()
    this.killed = false
    this.killSignal = undefined
  }

  kill(signal) {
    this.killed = true
    this.killSignal = signal
    return true
  }
}

/** 收集 data 再关流；必须在 spawn 之后的下一个微任务里跑，好让调用方先挂监听。 */
function finish(child, stdout, stderr, code) {
  if (stdout) child.stdout.emit('data', stdout)
  if (stderr) child.stderr.emit('data', stderr)
  child.emit('close', code, null)
}

/**
 * 造一个假 spawn：handler 在下一个微任务里按脚本演出。
 * 返回的 calls 里留着 bin/args/options/child，供断言检查。
 */
function spawnHarness(handler) {
  const calls = []
  const spawn = (bin, args, options) => {
    const child = new FakeChild()
    const call = { bin, args, options, child }
    calls.push(call)
    queueMicrotask(() => {
      try {
        handler(call, calls.length - 1)
      } catch (error) {
        child.emit('error', error)
      }
    })
    return child
  }
  return { spawn, calls }
}

/** 只说一句话就退出的命令。 */
function oneShot(stdout, code = 0, stderr = '') {
  return spawnHarness((call) => finish(call.child, stdout, stderr, code))
}

const thisFile = fileURLToPath(import.meta.url)
const tempDirs = []
const makeTemp = (prefix) => {
  const dir = mkdtempSync(join(tmpdir(), prefix))
  tempDirs.push(dir)
  return dir
}

// --- 1. 路径与账号 id 清洗 ----------------------------------------------------
check('state root is <dshHome>/ark-coding', arkcliStateRoot('/dsh') === join('/dsh', 'ark-coding'))
check('managed install dir lives under the state root',
  managedInstallDir('/dsh') === join('/dsh', 'ark-coding', 'cli'))
check('managed bin is node_modules/.bin/arkcli',
  managedBinPath('/dsh') === join('/dsh', 'ark-coding', 'cli', 'node_modules', '.bin', 'arkcli'))
check('the managed binary from a direct download is bin/arkcli',
  managedBinaryPath('/dsh') === join('/dsh', 'ark-coding', 'cli', 'bin', 'arkcli'))
check('the managed binary is .exe on Windows (CreateProcess cannot run extensionless files)',
  managedBinaryPath('/dsh', 'win32').endsWith('arkcli.exe') && managedBinaryPath('/dsh', 'win32').includes('bin'))
check('the npm shim is .cmd on Windows',
  managedBinPath('/dsh', 'win32').endsWith('arkcli.cmd'))
check('managed candidates prefer the direct download, then legacy npm shims',
  managedBinCandidates('/dsh')[0] === managedBinaryPath('/dsh')
  && managedBinCandidates('/dsh')[1] === managedBinPath('/dsh')
  && managedBinCandidates('/dsh', 'win32').some((candidate) => candidate.endsWith('arkcli.cmd'))
  && managedBinCandidates('/dsh', 'win32').some((candidate) => candidate.endsWith('arkcli.exe')))
check('platformKeyOf maps Node platform/arch onto the official manifest keys',
  platformKeyOf('win32', 'x64') === 'windows-amd64'
  && platformKeyOf('win32', 'arm64') === 'windows-arm64'
  && platformKeyOf('darwin', 'arm64') === 'darwin-arm64'
  && platformKeyOf('linux', 'x64') === 'linux-amd64'
  && platformKeyOf('linux', 'ia32') === undefined
  && platformKeyOf('freebsd', 'x64') === undefined)
check('the embedded binary manifest covers every officially published target', [
  'darwin-amd64', 'darwin-arm64', 'linux-amd64', 'linux-arm64', 'windows-amd64', 'windows-arm64',
].every((key) => {
  const entry = ARKCLI_BINARIES[key]
  if (entry === undefined) return false
  const suffix = `arkcli-${ARKCLI_BINARY_VERSION}-${key}${key.startsWith('windows') ? '.exe' : ''}`
  return entry.url.endsWith(suffix)
    && /^[0-9a-f]{64}$/.test(entry.sha256)
    && typeof entry.fallback === 'string' && entry.fallback.endsWith(suffix)
}), JSON.stringify(Object.keys(ARKCLI_BINARIES)))

check('traversal in the account id cannot escape the accounts dir',
  accountHomeDir('/dsh', '../../etc') === join('/dsh', 'ark-coding', 'accounts', '_.._etc'),
  accountHomeDir('/dsh', '../../etc'))
check('a slash in the account id becomes an underscore',
  sanitizeAccountId('a/b') === 'a_b' && accountHomeDir('/dsh', 'a/b').endsWith('accounts/a_b'))
check('leading dots are stripped so ids cannot make hidden dirs',
  sanitizeAccountId('..hidden') === 'hidden')
check('an empty account id falls back to default',
  sanitizeAccountId('') === 'default' && sanitizeAccountId(undefined) === 'default'
  && accountHomeDir('/dsh', '') === join('/dsh', 'ark-coding', 'accounts', 'default'))
check('non-ascii ids are replaced one-for-one',
  sanitizeAccountId('猫猫') === '__' && sanitizeAccountId('账号 1') === '___1')
for (const id of ['../../etc', 'a/b', '..hidden', '', '猫猫', 'C:\\windows', '..', '.']) {
  const dir = accountHomeDir('/dsh', id)
  check(`accountHomeDir(${JSON.stringify(id)}) stays directly under accounts/`,
    dir.startsWith(`${join('/dsh', 'ark-coding', 'accounts')}/`) && !dir.slice(-1).includes('/')
    && !dirname(dir).includes('..') && !dir.includes('\\'), dir)
}

check('findExecutableOnPath finds a real file', (() => {
  const dir = makeTemp('ark-path-')
  writeFileSync(join(dir, 'arkcli'), '#!/bin/sh\n')
  return findExecutableOnPath('arkcli', dir) === join(dir, 'arkcli')
})())
check('findExecutableOnPath returns undefined for an empty PATH',
  findExecutableOnPath('arkcli', '') === undefined)

{
  // Windows：真正能 CreateProcess 的是 .exe/.cmd/.bat；npm 还会生成一份给 sh 用的
  // 无扩展名脚本，它**不能被 spawn**，所以不能当候选。
  const dir = makeTemp('ark-win-path-')
  writeFileSync(join(dir, 'arkcli'), '#!/bin/sh\n')
  check('a Windows PATH lookup ignores the extensionless sh shim',
    findExecutableOnPath('arkcli', dir, existsSync, 'win32') === undefined)
  writeFileSync(join(dir, 'arkcli.cmd'), '@echo off\n')
  check('a Windows PATH lookup finds .cmd shims',
    findExecutableOnPath('arkcli', dir, existsSync, 'win32') === join(dir, 'arkcli.cmd'))
  writeFileSync(join(dir, 'arkcli.exe'), 'MZ\n')
  check('a Windows PATH lookup prefers .exe over .cmd',
    findExecutableOnPath('arkcli', dir, existsSync, 'win32') === join(dir, 'arkcli.exe'))

  // PATH 必须按目标平台的分隔符切：Windows 是 `;`，不是宿主（Linux）的 `:`。
  const second = makeTemp('ark-win-path2-')
  writeFileSync(join(second, 'arkcli.cmd'), '@echo off\n')
  check('a Windows PATH lookup splits entries on `;`',
    findExecutableOnPath('arkcli', `${makeTemp('ark-win-path1-')};${second}`, existsSync, 'win32') === join(second, 'arkcli.cmd'))
}

// --- 1b. 启动计划与进程树清理 ------------------------------------------------
{
  const npm = spawnPlanFor('C:\\Program Files\\nodejs\\npm.cmd', ['install', '--prefix', 'C:\\a b'], 'win32', 'cmd.exe')
  check('a .cmd target is launched through cmd.exe /d /s /c',
    npm.command === 'cmd.exe' && npm.args.slice(0, 3).join(' ') === '/d /s /c' && npm.verbatim === true,
    JSON.stringify(npm.args))
  check('the whole cmd line is wrapped once for /s, and spacey args keep their quotes',
    npm.args[3].startsWith('"') && npm.args[3].endsWith('"')
    && npm.args[3].includes('"C:\\Program Files\\nodejs\\npm.cmd"')
    && npm.args[3].includes('--prefix "C:\\a b"'), npm.args[3])
  const exe = spawnPlanFor('C:\\x\\arkcli.exe', ['--version'], 'win32', 'cmd.exe')
  check('a Windows .exe is launched directly, without cmd.exe',
    exe.command === 'C:\\x\\arkcli.exe' && exe.args[0] === '--version' && exe.verbatim === false)
  const posix = spawnPlanFor('/usr/bin/arkcli', ['auth', 'status'], 'linux')
  check('POSIX launches the resolved path directly',
    posix.command === '/usr/bin/arkcli' && posix.args.join(' ') === 'auth status' && posix.verbatim === false)

  const syncCalls = []
  killProcessTree({ pid: 4242, kill: () => {} }, {
    platform: 'win32',
    comspec: 'cmd.exe',
    spawnSync: (command, args, options) => { syncCalls.push({ command, args, options }); return { status: 0 } },
  })
  check('a Windows timeout kills the whole tree with taskkill /T /F',
    syncCalls.length === 1 && syncCalls[0].command === 'cmd.exe'
    && syncCalls[0].args.at(-1) === 'taskkill /pid 4242 /T /F', JSON.stringify(syncCalls[0]?.args))

  // spawnSync 不会抛：taskkill 失败/缺失时是 {status:1} 或 {error}。那种情况必须真的
  // 落到 child.kill，否则"超时"只是写了个错，子进程还活着。
  const survivor = {
    pid: 4243,
    killed: [],
    kill(signal) { this.killed.push(signal); return true },
  }
  killProcessTree(survivor, { platform: 'win32', comspec: 'cmd.exe', spawnSync: () => ({ status: 1 }) })
  check('a failed taskkill falls back to killing the child directly', survivor.killed.includes('SIGKILL'), JSON.stringify(survivor.killed))
  const missingShell = {
    pid: 4244,
    killed: [],
    kill(signal) { this.killed.push(signal); return true },
  }
  killProcessTree(missingShell, { platform: 'win32', comspec: 'cmd.exe', spawnSync: () => ({ status: null, error: new Error('ENOENT') }) })
  check('a missing cmd.exe falls back to killing the child directly', missingShell.killed.includes('SIGKILL'))
}

// --- 2. parseArkcliJson ------------------------------------------------------
check('bare JSON parses', parseArkcliJson('{"a":1}').ok && parseArkcliJson('{"a":1}').value.a === 1)
check('a warning line before the JSON is tolerated',
  parseArkcliJson('WARN update available\n{"auth_method":"sso","logged_in":true}').value.logged_in === true)
check('a top-level array is parsed as an array',
  Array.isArray(parseArkcliJson('[{"name":"x"}]').value))
check('ok:false surfaces error.message',
  parseArkcliJson('{"ok":false,"error":{"type":"validation","message":"bad flag","trace_id":"t"}}').error === 'bad flag')
check('ok:false without a message still reads sensibly',
  parseArkcliJson('{"ok":false}').error === 'arkcli 报错（没有 message）')
const notJson = parseArkcliJson('Error: something exploded')
check('non-JSON fails with a readable error', !notJson.ok && /不是合法 JSON/.test(notJson.error), notJson.error)
check('empty output fails', !parseArkcliJson('').ok && !parseArkcliJson('   ').ok)
check('non-string input fails instead of throwing', !parseArkcliJson(undefined).ok)

// --- 3. run() 的最小环境 ------------------------------------------------------
const accountHome = '/dsh/ark-coding/accounts/account-2'
const previousKey = process.env.ARK_API_KEY
const previousProfile = process.env.ARK_PROFILE
process.env.ARK_API_KEY = 'host-secret-key'
process.env.ARK_PROFILE = 'host-profile'
try {
  const harness = oneShot('{"auth_method":"sso","logged_in":true}\n', 0)
  const cli = new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: harness.spawn })
  const result = await cli.run(['auth', 'status', '--format', 'json'], { home: accountHome })
  const env = harness.calls[0].options.env
  check('run() does not inherit ARK_API_KEY from the host',
    !('ARK_API_KEY' in env) && !Object.values(env).includes('host-secret-key'), JSON.stringify(env.ARK_API_KEY))
  check('run() does not inherit ARK_PROFILE from the host', !('ARK_PROFILE' in env))
  check('run() sets HOME to the account home', env.HOME === accountHome, env.HOME)
  check('run() marks itself as an agent caller',
    env.ARKCLI_CALLER_TYPE === 'ai_agent' && env.ARKCLI_CALLER_NAME === 'dsh-ark-coding-provider')
  check('run() disables colour and the update notifier',
    env.NO_COLOR === '1' && env.ARKCLI_NO_UPDATE_NOTIFIER === '1')
  check('run() passes the argument vector through unchanged',
    harness.calls[0].args.join(' ') === 'auth status --format json' && harness.calls[0].bin === thisFile)
  check('run() gives the child pipes and no stdin',
    harness.calls[0].options.stdio.join(',') === 'ignore,pipe,pipe')
  check('run() exposes the parsed JSON next to the raw output',
    result.ok && result.json.logged_in === true && result.stdout.includes('logged_in'))

  const extra = spawnHarness((call) => finish(call.child, 'done\n', '', 0))
  const cliExtra = new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: extra.spawn })
  await cliExtra.run(['x'], { home: '/h', env: { EXTRA: 'yes', EXTRA2: undefined } })
  check('an undefined extra env key is dropped, defined ones are kept',
    extra.calls[0].options.env.EXTRA === 'yes' && !('EXTRA2' in extra.calls[0].options.env))

  let threw = false
  try { await cli.run(['--version'], {}) } catch { threw = true }
  check('run() refuses to run without an explicit HOME', threw)
  check('buildChildEnv rejects a missing HOME', (() => {
    try { buildChildEnv(undefined); return false } catch { return true }
  })())
} finally {
  if (previousKey === undefined) delete process.env.ARK_API_KEY
  else process.env.ARK_API_KEY = previousKey
  if (previousProfile === undefined) delete process.env.ARK_PROFILE
  else process.env.ARK_PROFILE = previousProfile
}

// --- 3b. Windows 下的环境与启动方式 ------------------------------------------
{
  const winHome = 'C:\\Users\\x\\.dsh\\ark-coding\\accounts\\default'
  const previousSystemRoot = process.env.SystemRoot
  const previousComspec = process.env.ComSpec
  const previousPathext = process.env.PATHEXT
  process.env.SystemRoot = 'C:\\Windows'
  process.env.ComSpec = 'C:\\Windows\\system32\\cmd.exe'
  process.env.PATHEXT = '.COM;.EXE;.BAT;.CMD'
  try {
    const env = buildChildEnv(winHome, undefined, 'win32')
    check('Windows child env sets USERPROFILE to the account home (Go ignores HOME)',
      env.USERPROFILE === winHome && env.HOME === winHome, JSON.stringify({ HOME: env.HOME, USERPROFILE: env.USERPROFILE }))
    check('Windows child env keeps SystemRoot/ComSpec/PATHEXT',
      env.SystemRoot === 'C:\\Windows' && env.ComSpec === 'C:\\Windows\\system32\\cmd.exe' && env.PATHEXT === '.COM;.EXE;.BAT;.CMD')
    check('Windows child env still refuses to inherit the host ARK_API_KEY', !('ARK_API_KEY' in env))

    // .cmd 目标必须经 cmd.exe 起；detached 在 Windows 会另开控制台窗口，不能带。
    const cmdFile = join(makeTemp('ark-win-cmd-'), 'arkcli.cmd')
    writeFileSync(cmdFile, '@echo off\n')
    const harness = oneShot('arkcli version 1.0.39\n', 0)
    const cli = new ArkCli({ dshHome: '/dsh', binPath: cmdFile, spawn: harness.spawn, platform: 'win32', comspec: 'cmd.exe' })
    const result = await cli.run(['--version'], { home: winHome })
    const call = harness.calls[0]
    check('on Windows a .cmd arkcli is launched through cmd.exe',
      call.bin === 'cmd.exe' && call.args.slice(0, 3).join(' ') === '/d /s /c'
      && call.args[3].includes('arkcli.cmd'), JSON.stringify(call.args))
    check('a cmd.exe launch uses verbatim arguments and windowsHide, never detached',
      call.options.windowsVerbatimArguments === true && call.options.windowsHide === true && call.options.detached === false,
      JSON.stringify(call.options))
    check('the .cmd run still returns the parsed version output', result.ok && result.stdout.includes('1.0.39'), JSON.stringify(result))
  } finally {
    if (previousSystemRoot === undefined) delete process.env.SystemRoot
    else process.env.SystemRoot = previousSystemRoot
    if (previousComspec === undefined) delete process.env.ComSpec
    else process.env.ComSpec = previousComspec
    if (previousPathext === undefined) delete process.env.PATHEXT
    else process.env.PATHEXT = previousPathext
  }
}

// 非零退出时的错误文本优先级：JSON message > stderr 最后一行 > 退出码。
const jsonFailure = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: oneShot('{"ok":false,"error":{"message":"flag not recognised"}}', 2).spawn })
  .run(['bad'], { home: '/h' })
check('a non-zero exit prefers the JSON message', !jsonFailure.ok && jsonFailure.error === 'flag not recognised', jsonFailure.error)
// 实测：arkcli 的错误信封是打在 **stderr** 上的（它自己的约定是「stdout 只放结构化
// 结果，错误与解释走 stderr」）。只看 stdout 的话，这里会退化成 stderr 的最后一行，
// 也就是一个孤零零的 `}` —— 界面里完全没法看。
const stderrEnvelope = await new ArkCli({
  dshHome: '/dsh',
  binPath: thisFile,
  spawn: oneShot('', 1, '{\n  "ok": false,\n  "error": {\n    "type": "error",\n    "message": "not configured, run `arkcli config init`",\n    "trace_id": "abc"\n  }\n}\n').spawn,
}).run(['usage', 'plan', '--format', 'json'], { home: '/h' })
check('a non-zero exit also reads the JSON envelope from stderr',
  !stderrEnvelope.ok && stderrEnvelope.error === 'not configured, run `arkcli config init`', stderrEnvelope.error)
const stderrFailure = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: oneShot('', 1, 'first line\nlast line wins\n').spawn })
  .run(['bad'], { home: '/h' })
check('a non-zero exit falls back to the last stderr line', !stderrFailure.ok && stderrFailure.error === 'last line wins', stderrFailure.error)
const silentFailure = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: oneShot('', 5).spawn })
  .run(['bad'], { home: '/h' })
check('a silent non-zero exit reports the exit code', !silentFailure.ok && silentFailure.error === '退出码 5', silentFailure.error)
const noBin = await new ArkCli({ dshHome: makeTemp('ark-nobin-'), pathEnv: '', spawn: oneShot('', 0).spawn })
  .run(['--version'], { home: '/h' })
check('run() reports an unresolved binary instead of spawning', !noBin.ok && /找不到 arkcli/.test(noBin.error), noBin.error)

// --- 4. 超时与启动失败 --------------------------------------------------------
const hung = spawnHarness(() => { /* 永不输出、永不退出 */ })
const hangResult = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: hung.spawn })
  .run(['auth', 'login', '--no-browser'], { home: '/h', timeoutMs: 40 })
check('run() reports a timeout', !hangResult.ok && hangResult.error === '超时', hangResult.error)
check('run() SIGKILLs the hung child',
  hung.calls[0].child.killed === true && hung.calls[0].child.killSignal === 'SIGKILL')
check('a timed-out run keeps whatever output arrived', hangResult.stdout === '' && hangResult.code === null)

// 只杀直接子进程是不够的：`node_modules/.bin/arkcli` 是 node 包装脚本，它 execFileSync
// 出的 Go 二进制不在我们的直接子进程位置上。所以子进程必须 detached 起独立进程组，
// 超时时按**组**杀（负 pid）。这条断言钉住 "detached + process.kill(-pid)" 两半。
{
  const spawned = spawnHarness((call) => { call.child.pid = 5150 })
  const kills = []
  const realKill = process.kill
  process.kill = (pid, signal) => { kills.push([pid, signal]); return true }
  let grouped
  try {
    grouped = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: spawned.spawn })
      .run(['auth', 'login', '--no-browser'], { home: '/h', timeoutMs: 30 })
  } finally {
    process.kill = realKill
  }
  check('a timed-out child was started detached (its own process group)',
    spawned.calls[0].options.detached === true)
  check('a timeout kills the whole process group, not just the direct child',
    grouped.error === '超时' && kills.length === 1 && kills[0][0] === -5150 && kills[0][1] === 'SIGKILL',
    JSON.stringify(kills))
  check('the direct child is not double-killed once the group kill succeeds',
    spawned.calls[0].child.killed === false, String(spawned.calls[0].child.killed))
}

// 真的起一个"包装脚本 + 孙进程"，确认超时之后没有后代活着。
// 这是上面那条假 spawn 断言的真实版证据（只能在 /tmp 做，不碰任何真实状态）。
if (process.platform !== 'win32') {
  const scriptDir = makeTemp('ark-group-real-')
  const wrapper = join(scriptDir, 'wrapper.sh')
  writeFileSync(wrapper, '#!/bin/sh\nsleep 120 & wait $!\n')
  chmodSync(wrapper, 0o755)
  let capturedPid
  const spawnReal = (bin, args, options) => {
    const child = nodeSpawn(bin, args, options)
    capturedPid = child.pid
    return child
  }
  let realResult
  try {
    realResult = await new ArkCli({ dshHome: scriptDir, binPath: wrapper, spawn: spawnReal })
      .run(['x'], { home: scriptDir, timeoutMs: 400 })
  } catch (error) {
    realResult = { error: String(error) }
  }
  let groupGone = false
  if (typeof capturedPid === 'number' && capturedPid > 0) {
    for (let attempt = 0; attempt < 40; attempt += 1) {
      try { process.kill(-capturedPid, 0) } catch { groupGone = true; break }
      await sleep(50)
    }
    try { process.kill(-capturedPid, 'SIGKILL') } catch { /* 已经没了 */ }
  }
  check('a real wrapper + grandchild leaves no survivor after the timeout',
    realResult.error === '超时' && groupGone === true,
    JSON.stringify({ error: realResult.error, pid: capturedPid, groupGone }))
}

const thrower = new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: () => { throw new Error('boom') } })
const throwResult = await thrower.run(['--version'], { home: '/h' })
check('a throwing spawn becomes a readable error', !throwResult.ok && /无法启动/.test(throwResult.error), throwResult.error)

// Go panic 的形态：`panic: ...` 之后是 `goroutine 1 [running]:` 回溯。回溯里的 `[`
// 会让"包含 [ 就当 JSON"的旧判据把它当 JSON 去 parse，于是用户看到的是
// `不是合法 JSON：Unexpected token 'r', "[running]:" is not valid JSON` —— 真正的原因被丢掉。
{
  const panicText = 'panic: runtime error: index out of range [3] with length 2\n\ngoroutine 1 [running]:\nmain.main()\n\t/app/main.go:12 +0x1\n'
  const panic = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: oneShot('', 2, panicText).spawn })
    .run(['x'], { home: '/h' })
  check('a Go panic on stderr is never misread as a JSON parse failure',
    !panic.ok && !/不是合法 JSON/.test(panic.error) && !/Unexpected token/.test(panic.error) && /main\.go/.test(panic.error),
    String(panic.error))
  const singleLine = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: oneShot('', 2, 'panic: boom\n').spawn })
    .run(['x'], { home: '/h' })
  check('a single-line panic surfaces the panic line itself',
    singleLine.error === 'panic: boom', String(singleLine.error))
}

// 子进程输出上限：洪泛的 stdout 不能把宿主内存吃光。
{
  const CHUNK = 'x'.repeat(100_000)
  const flood = spawnHarness((call) => {
    for (let index = 0; index < 40; index += 1) call.child.stdout.emit('data', CHUNK)
    finish(call.child, '', '', 0)
  })
  const floodResult = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: flood.spawn })
    .run(['x'], { home: '/h' })
  check('a flooding child is capped near the documented output limit',
    floodResult.ok
    && floodResult.stdout.length >= 1_000_000
    && floodResult.stdout.length <= 1_000_000 + CHUNK.length,
    String(floodResult.stdout.length))
}

// --- 5. usagePlan 归一化 ------------------------------------------------------
const planPayload = {
  viewer: {
    auth_method: 'sso',
    is_root: false,
    user_id: 'u-1',
    user_name: '猫猫',
    account_id: '2100000000',
    profile: 'default',
    tenant: 't-1',
    region: 'cn-beijing',
    project_name: 'default',
  },
  items: [
    {
      product: 'coding-plan',
      edition: 'personal',
      tier: 'pro',
      seat_id: 'seat-1',
      subscribed: true,
      updated_at: 1792083000000,
      periods: [
        { label: 'weekly', percent: -5 },
        { label: 'monthly', percent: 42.006, used: 10, total: 100 },
        { label: 'session', percent: 120.456, reset_at: '2026-10-16T18:00:00+08:00' },
      ],
    },
    {
      product: 'agent-plan',
      edition: 'personal',
      tier: 'lite',
      subscribed: true,
      periods: [{ label: '5h', used: 5, total: 50, percent: 10, reset_at: 'not-a-date' }],
    },
    { product: 'coding-plan-team', edition: 'team', subscribed: false, error: '当前账号没有团队套餐权限' },
  ],
}
const planHarness = oneShot(JSON.stringify(planPayload), 0)
const plan = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: planHarness.spawn })
  .usagePlan({ home: '/h' })
check('usagePlan() calls `usage plan --format json`',
  planHarness.calls[0].args.join(' ') === 'usage plan --format json', planHarness.calls[0].args.join(' '))
check('usagePlan() returns every bucket', plan.ok && plan.items.length === 3, String(plan.items.length))
check('usagePlan() passes the viewer through unchanged',
  plan.viewer.user_name === '猫猫' && plan.viewer.auth_method === 'sso' && plan.viewer.region === 'cn-beijing')
check('periods are sorted session → weekly → monthly',
  plan.items[0].periods.map((period) => period.key).join(',') === 'session,weekly,monthly',
  plan.items[0].periods.map((period) => period.key).join(','))
check('a CodingPlan period without used/total has hasTotals:false',
  plan.items[0].periods[0].hasTotals === false
  && plan.items[0].periods[0].used === undefined && plan.items[0].periods[0].total === undefined)
check('an AgentPlan period with used/total has hasTotals:true',
  plan.items[1].periods[0].hasTotals === true
  && plan.items[1].periods[0].used === 5 && plan.items[1].periods[0].total === 50)
check('percent is clamped at 100', plan.items[0].periods[0].percent === 100, String(plan.items[0].periods[0].percent))
check('percent is clamped at 0', plan.items[0].periods[1].percent === 0, String(plan.items[0].periods[1].percent))
check('percent is rounded to two decimals', plan.items[0].periods[2].percent === 42.01, String(plan.items[0].periods[2].percent))
check('the 5h label maps to the session window', plan.items[1].periods[0].key === 'session')
check('RFC3339 reset_at becomes epoch ms',
  plan.items[0].periods[0].resetAt === Date.parse('2026-10-16T18:00:00+08:00'),
  String(plan.items[0].periods[0].resetAt))
check('an unparseable reset_at is undefined, never NaN',
  plan.items[1].periods[0].resetAt === undefined)
check('updated_at becomes epoch ms', plan.items[0].updatedAt === 1792083000000)
check('a missing updated_at stays undefined', plan.items[1].updatedAt === undefined)
check('subscribed:false is preserved along with the bucket error',
  plan.items[2].subscribed === false && plan.items[2].error === '当前账号没有团队套餐权限'
  && plan.items[2].periods.length === 0)
check('a per-bucket error does not poison its siblings', plan.items[0].error === undefined && plan.ok)

check('normalizeUsageItem tolerates a garbage row',
  normalizeUsageItem(null).periods.length === 0 && normalizeUsageItem({ periods: 'nope' }).periods.length === 0)
const failedPlan = await new ArkCli({
  dshHome: '/dsh',
  binPath: thisFile,
  spawn: oneShot('{"ok":false,"error":{"message":"需要先登录（SSO）"}}', 2, '请先登录').spawn,
}).usagePlan({ home: '/h' })
check('usagePlan() surfaces the control-plane failure',
  !failedPlan.ok && failedPlan.error === '需要先登录（SSO）' && failedPlan.items.length === 0, failedPlan.error)
const nonJsonPlan = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: oneShot('not json at all', 0).spawn })
  .usagePlan({ home: '/h' })
check('usagePlan() rejects a non-JSON success', !nonJsonPlan.ok && /没有返回 JSON/.test(nonJsonPlan.error), nonJsonPlan.error)

// --- 6. modelsSearch 归一化 ---------------------------------------------------
const modelRow = {
  name: 'doubao-seed-2-0-pro',
  display_name: 'Doubao-Seed-2.0-Pro',
  primary_version: '260215',
  update_time: '2026-03-02T10:00:00+08:00',
  context_window: 262144,
  max_input_tokens: 229376,
  max_completion_tokens: 65536,
  input_modalities: ['text', 'image', 'bogus', 7],
  output_modalities: ['text'],
  capabilities: { thinking: true, mcp: true, response_format: false },
  cache_types: ['implicit_cache'],
  lifecycle_status: 'Published',
}
const bare = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: oneShot(JSON.stringify([modelRow]), 0).spawn })
  .modelsSearch({ home: '/h' })
check('modelsSearch() accepts a bare array', bare.ok && bare.items.length === 1)
const wrapped = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: oneShot(JSON.stringify({ items: [modelRow] }), 0).spawn })
  .modelsSearch({ home: '/h' })
check('modelsSearch() accepts {items}', wrapped.ok && wrapped.items[0].id === 'doubao-seed-2-0-pro')
const nested = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: oneShot(JSON.stringify({ data: { items: [modelRow] } }), 0).spawn })
  .modelsSearch({ home: '/h' })
check('modelsSearch() accepts {data:{items}}', nested.ok && nested.items[0].displayName === 'Doubao-Seed-2.0-Pro')
const searchArgs = oneShot(JSON.stringify([modelRow]), 0)
await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: searchArgs.spawn }).modelsSearch({ home: '/h' })
check('modelsSearch() sends `models search --format json --size 0`',
  searchArgs.calls[0].args.join(' ') === 'models search --format json --size 0', searchArgs.calls[0].args.join(' '))
const keywordArgs = oneShot(JSON.stringify([modelRow]), 0)
await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: keywordArgs.spawn }).modelsSearch({ home: '/h', keyword: ' doubao ', size: 10 })
check('modelsSearch() forwards a keyword and size when given',
  keywordArgs.calls[0].args.join(' ') === 'models search --format json --size 10 --keyword doubao', keywordArgs.calls[0].args.join(' '))

const item = bare.items[0]
check('model id/name follow name vs display_name',
  item.id === 'doubao-seed-2-0-pro' && item.name === 'Doubao-Seed-2.0-Pro' && item.displayName === 'Doubao-Seed-2.0-Pro')
check('model numbers are normalised',
  item.contextWindow === 262144 && item.maxInputTokens === 229376 && item.maxOutputTokens === 65536)
check('modalities are filtered to strings',
  item.inputModalities.join(',') === 'text,image,bogus' && item.outputModalities.join(',') === 'text',
  item.inputModalities.join(','))
check('capabilities and cache types survive',
  item.capabilities.thinking === true && item.cacheTypes.join(',') === 'implicit_cache')
check('version/lifecycle/update_time survive',
  item.version === '260215' && item.lifecycleStatus === 'Published' && item.updateTime === '2026-03-02T10:00:00+08:00')
const nulls = await new ArkCli({
  dshHome: '/dsh',
  binPath: thisFile,
  spawn: oneShot(JSON.stringify({ items: [{ name: 'x', display_name: null, context_window: null, max_input_tokens: 0, input_modalities: null, capabilities: null }] }), 0).spawn,
}).modelsSearch({ home: '/h' })
check('null enrichment fields become undefined/empty, not NaN or null arrays',
  nulls.items[0].name === 'x' && nulls.items[0].contextWindow === undefined
  && nulls.items[0].maxInputTokens === undefined && nulls.items[0].inputModalities.length === 0
  && JSON.stringify(nulls.items[0].capabilities) === '{}', JSON.stringify(nulls.items[0]))
check('modelsItemsOf tolerates unknown envelopes',
  modelsItemsOf(null).length === 0 && modelsItemsOf({}).length === 0 && modelsItemsOf({ data: {} }).length === 0)
check('normalizeModel tolerates a garbage row', normalizeModel(null).id === undefined && normalizeModel(null).name === undefined)

// --- 7. profileApiKey 解析 ----------------------------------------------------
const keyVariants = [
  ['a bare string', `ark-${'a'.repeat(24)}\n`],
  ['a JSON object with api_key', JSON.stringify({ api_key: 'ark-json-api-key' })],
  ['a JSON object with apiKey', JSON.stringify({ apiKey: 'ark-json-camel' })],
  ['a JSON object with default_api_key', JSON.stringify({ default_api_key: 'ark-json-default' })],
  ['a JSON object with key', JSON.stringify({ key: 'ark-json-key' })],
  ['a JSON string', JSON.stringify('ark-json-string')],
  ['a JSON object after a log line', `INFO profile default\n${JSON.stringify({ api_key: 'ark-json-after-log' })}`],
  ['a log line before the key', `INFO profile default\n${'ark-' + 'b'.repeat(23)}\n`],
]
for (const [label, output] of keyVariants) {
  const result = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: oneShot(output, 0).spawn })
    .profileApiKey({ home: '/h' })
  check(`profileApiKey() parses ${label}`, result.ok && /^ark-/.test(result.apiKey), String(result.apiKey))
}
const noKey = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: oneShot('没有配置 API key\n', 0).spawn })
  .profileApiKey({ home: '/h' })
check('profileApiKey() reports unparseable output', !noKey.ok && /解析出 API key/.test(noKey.error), noKey.error)
const keyFailure = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: oneShot('', 1, 'not logged in').spawn })
  .profileApiKey({ home: '/h' })
check('profileApiKey() forwards the CLI failure', !keyFailure.ok && keyFailure.error === 'not logged in', keyFailure.error)
check('extractApiKey ignores shapes it cannot trust',
  extractApiKey('') === undefined && extractApiKey('{') === undefined && extractApiKey(undefined) === undefined)

// --- 8. 登录编排 --------------------------------------------------------------
// 授权 URL 里的 callbackPort 默认 41035（实测样例的端口）。
const AUTH_URL_FOR = (port) => `https://ark.volcengine.com/region:cn-beijing/arkcli/login?callbackNonce=XXX&callbackPort=${port}&sessionId=YYY`
const AUTH_URL = AUTH_URL_FOR(41035)

/** 登录假实现：授权那条常驻不退出，`--code` 那条明确失败，其它命令报版本。 */
function loginHarness(port = 41035) {
  const calls = []
  const banner = `如果浏览器未自动打开，请手动访问:\n${AUTH_URL_FOR(port)}\n等待浏览器认证完成...\n`
  const spawn = (bin, args, options) => {
    const child = new FakeChild()
    const call = { bin, args, options, child }
    calls.push(call)
    queueMicrotask(() => {
      if (args.includes('--no-browser') && !args.includes('--code')) {
        child.stderr.emit('data', banner)
        return
      }
      if (args.includes('--code')) {
        finish(child, '{"ok":false,"error":{"type":"validation","message":"没有待完成的登录会话"}}', '', 2)
        return
      }
      finish(child, 'arkcli version 1.0.39\n', '', 0)
    })
    return child
  }
  return { spawn, calls }
}
const loginCall = (calls) => calls.find((call) => call.args.includes('--no-browser') && !call.args.includes('--code'))

{
  const harness = loginHarness()
  const fetchCalls = []
  const login = new ArkCliLogin({
    dshHome: '/dsh',
    binPath: thisFile,
    spawn: harness.spawn,
    fetchImpl: async (url, init) => {
      fetchCalls.push({ url, init })
      // 模拟"回环监听收到回调 → 登录完成 → 常驻子进程退出"。
      queueMicrotask(() => finish(loginCall(harness.calls).child, '', '登录成功\n', 0))
      return { ok: true, status: 200, text: async () => 'login ok' }
    },
  })
  const started = await login.start({ ref: 'r1', home: '/h' })
  check('start() extracts the authorize URL from stderr', started.ok && started.url === AUTH_URL, String(started.url))
  check('start() extracts the loopback callback port', started.ok && started.port === 41035, String(started.port))
  check('start() spawns `auth login --no-browser`',
    loginCall(harness.calls).args.join(' ') === 'auth login --no-browser', loginCall(harness.calls).args.join(' '))
  check('start() gives the login child its own HOME',
    loginCall(harness.calls).options.env.HOME === '/h')
  check('start() keeps exactly one live session', login.size() === 1)
  const pending = login.poll({ ref: 'r1' })
  check('poll() reports pending', pending.ok && pending.state === 'pending' && pending.url === AUTH_URL)
  check('poll() reports unknown for a foreign ref', login.poll({ ref: 'nope' }).state === 'unknown')

  // 粘来的 URL 端口是上一次登录的（9999），必须用会话里的 41035。
  const submitted = await login.submit({ ref: 'r1', input: 'http://localhost:9999/arkcli/broker/callback?code=abc&state=xyz' })
  check('submit() forwards the path+query to 127.0.0.1 on the session port',
    fetchCalls[0].url === `http://127.0.0.1:41035/arkcli/broker/callback?code=abc&state=xyz`, fetchCalls[0].url)
  check('submit() sends the host header the binary demands',
    fetchCalls[0].init.headers.host === '127.0.0.1:41035' && fetchCalls[0].init.method === 'GET')
  check('submit() asks fetch not to follow redirects', fetchCalls[0].init.redirect === 'manual')
  check('submit() reports the terminal state', submitted.ok && submitted.state === 'done', JSON.stringify(submitted))
  check('submit() removes the finished session', login.size() === 0)
  check('submit() on a finished ref reports the terminal state',
    (await login.submit({ ref: 'r1', input: 'http://localhost/arkcli/broker/callback' })).state === 'unknown')
}

{
  // 非 2xx：把状态码与正文（截断）摊开给调用方。
  const harness = loginHarness()
  const login = new ArkCliLogin({
    dshHome: '/dsh',
    binPath: thisFile,
    spawn: harness.spawn,
    fetchImpl: async () => ({ ok: false, status: 400, text: async () => 'invalid callback parameters' }),
  })
  await login.start({ ref: 'r2', home: '/h' })
  const rejected = await login.submit({ ref: 'r2', input: 'http://localhost:41035/arkcli/broker/callback' })
  check('a rejected callback reports the status and body',
    !rejected.ok && /HTTP 400/.test(rejected.error) && /invalid callback parameters/.test(rejected.error), rejected.error)
  check('a rejected callback leaves the session alive and unkilled',
    login.size() === 1 && login.poll({ ref: 'r2' }).state === 'pending' && loginCall(harness.calls).child.killed === false)
  check('cancel() kills the child and drops the session',
    login.cancel({ ref: 'r2' }).ok && loginCall(harness.calls).child.killed === true && login.size() === 0)
  check('cancel() on an unknown ref fails cleanly', !login.cancel({ ref: 'r2' }).ok)
}

{
  // 杀"进程组"，不是只杀直接子进程。
  //
  // 原因（实测过）：`node_modules/.bin/arkcli` 是 node 包装脚本，它用 `execFileSync`
  // 阻塞地跑去真正的 Go 二进制。那个二进制不在我们直接子进程的位置上，所以只 SIGKILL
  // 包装脚本的话，Go 进程会被 init 收养、回环端口继续 LISTEN —— 用户以为取消了，
  // 其实端口还占着。修法是 detached 起进程组 + 按组杀（负 pid）。
  const harness = loginHarness()
  const login = new ArkCliLogin({ dshHome: '/dsh', binPath: thisFile, spawn: harness.spawn })
  await login.start({ ref: 'rKill', home: '/h' })
  check('login children start detached so the whole process group can be killed',
    loginCall(harness.calls).options.detached === true)
  loginCall(harness.calls).child.pid = 4242
  const kills = []
  const realKill = process.kill
  process.kill = (pid, signal) => { kills.push([pid, signal]); return true }
  let cancelled
  try { cancelled = login.cancel({ ref: 'rKill' }) } finally { process.kill = realKill }
  check('cancel() kills the whole process group via a negative pid',
    kills.length === 1 && kills[0][0] === -4242 && kills[0][1] === 'SIGKILL', JSON.stringify(kills))
  check('cancel() reports that it really killed a live session',
    cancelled.ok === true && cancelled.killed === true, JSON.stringify(cancelled))
  check('cancel() refuses an unknown ref instead of pretending',
    login.cancel({ ref: 'rKill' }).ok === false)
  login.disposeAll()
}

{
  // 裸授权码：这个构建不支持，必须给出"去粘回调 URL"的明确指引，且不杀掉常驻子进程。
  const harness = loginHarness()
  const login = new ArkCliLogin({ dshHome: '/dsh', binPath: thisFile, spawn: harness.spawn })
  await login.start({ ref: 'r3', home: '/h' })
  const coded = await login.submit({ ref: 'r3', input: 'ZmFrZS1jb2Rl' })
  const codeCall = harness.calls.find((call) => call.args.includes('--code'))
  check('a bare code goes down the --code path with the same HOME',
    codeCall !== undefined && codeCall.args.join(' ') === 'auth login --no-browser --code ZmFrZS1jb2Rl'
    && codeCall.options.env.HOME === '/h', codeCall?.args.join(' '))
  check('the code path reports the unsupported-code guidance',
    !coded.ok && coded.state === 'error' && /不支持 --code/.test(coded.error) && /回调 URL/.test(coded.error), coded.error)
  check('the code path keeps the browser session alive',
    login.size() === 1 && loginCall(harness.calls).child.killed === false && login.poll({ ref: 'r3' }).state === 'pending')
  login.disposeAll()
}

{
  // fetch 抛错（监听已经死了）与"提交后仍然 pending"。
  const harness = loginHarness()
  const login = new ArkCliLogin({
    dshHome: '/dsh',
    binPath: thisFile,
    spawn: harness.spawn,
    fetchImpl: async () => { throw new Error('connect ECONNREFUSED 127.0.0.1:41035') },
  })
  await login.start({ ref: 'r4', home: '/h' })
  const refused = await login.submit({ ref: 'r4', input: 'http://localhost:41035/arkcli/broker/callback?code=x' })
  check('a dead loopback listener becomes a readable error',
    !refused.ok && /ECONNREFUSED/.test(refused.error) && /重新发起登录/.test(refused.error), refused.error)

  const harness2 = loginHarness()
  let login2FetchCalls = 0
  const login2 = new ArkCliLogin({
    dshHome: '/dsh',
    binPath: thisFile,
    spawn: harness2.spawn,
    fetchImpl: async () => { login2FetchCalls += 1; return { ok: true, status: 200, text: async () => 'accepted' } },
  })
  await login2.start({ ref: 'r5', home: '/h' })
  const stillPending = await login2.submit({ ref: 'r5', input: 'http://localhost:41035/arkcli/broker/callback?code=x', waitMs: 60 })
  check('a 2xx callback that does not finish the child stays pending',
    stillPending.ok && stillPending.state === 'pending' && login2.size() === 1, JSON.stringify(stillPending))

  // 不是回调路由的地址必须被**拒绝**，而不是照转到本机回环监听上
  // （那样等于把监听变成任意路径的转发器）。
  const fetchesBefore = login2FetchCalls
  const mismatched = await login2.submit({ ref: 'r5', input: 'http://localhost:41035/some/other/path?code=x', waitMs: 10 })
  check('a URL that is not the callback route is refused, not forwarded',
    mismatched.ok === false && /不是登录回调地址/.test(mismatched.error) && /some\/other\/path/.test(mismatched.error)
    && login2FetchCalls === fetchesBefore,
    String(mismatched.error))
  login2.disposeAll()
  check('disposeAll() kills everything and empties the table',
    login2.size() === 0 && loginCall(harness2.calls).child.killed === true)
  login.disposeAll()
}

{
  // start 失败路径：超时 / 提前退出 / 找不到 bin。
  const login = new ArkCliLogin({ dshHome: '/dsh', binPath: thisFile, spawn: spawnHarness(() => {}).spawn })
  const timedOut = await login.start({ ref: 'r6', home: '/h', timeoutMs: 40 })
  check('start() times out when no URL appears',
    !timedOut.ok && /等待授权链接超时/.test(timedOut.error), timedOut.error)
  check('a timed-out start leaves no session behind', login.size() === 0)

  const exiting = spawnHarness((call) => finish(call.child, '', 'invalid host\n', 2))
  const login2 = new ArkCliLogin({ dshHome: '/dsh', binPath: thisFile, spawn: exiting.spawn })
  const early = await login2.start({ ref: 'r7', home: '/h', timeoutMs: 200 })
  check('start() reports an early exit with the captured output',
    !early.ok && /提前退出/.test(early.error) && /invalid host/.test(early.error), early.error)
  check('an early exit leaves no session behind', login2.size() === 0)

  const login3 = new ArkCliLogin({ dshHome: makeTemp('ark-login-nobin-'), pathEnv: '', spawn: spawnHarness(() => {}).spawn })
  const noBinLogin = await login3.start({ ref: 'r8', home: '/h' })
  check('start() reports a missing binary', !noBinLogin.ok && /找不到 arkcli/.test(noBinLogin.error), noBinLogin.error)
}

{
  // TTL：到点必须杀子进程并把状态置为 expired（而不是直接消失）。
  const harness = loginHarness()
  const login = new ArkCliLogin({ dshHome: '/dsh', binPath: thisFile, spawn: harness.spawn })
  await login.start({ ref: 'r9', home: '/h', ttlMs: 30 })
  await sleep(80)
  const expired = login.poll({ ref: 'r9' })
  check('an expired session reports state=expired', expired.state === 'expired', String(expired.state))
  check('an expired session has killed its child', loginCall(harness.calls).child.killed === true)
  check('an expired session refuses further submits',
    !(await login.submit({ ref: 'r9', input: 'http://localhost:41035/arkcli/broker/callback' })).ok)
  login.disposeAll()
}

{
  // TTL 的另一个方向：子进程**正常退出（done）**之后，时间再推进过 TTL，
  // `poll()` 仍必须返回 done。旧实现只武装 TTL 却不清掉，登录成功 10 分钟后再看
  // 设置页，会话状态会被 TTL 回调从 done 改写成 expired —— 界面显示"登录会话已过期"，
  // 纯属误报。
  const banner = `如果浏览器未自动打开，请手动访问:\n${AUTH_URL}\n等待浏览器认证完成...\n`
  const calls = []
  const spawn = (bin, args, options) => {
    const child = new FakeChild()
    const call = { bin, args, options, child }
    calls.push(call)
    queueMicrotask(() => {
      if (args.includes('--no-browser') && !args.includes('--code')) {
        child.stderr.emit('data', banner)
        // 子进程在给出授权链接后自己退出：登录成功。
        queueMicrotask(() => finish(child, '', '登录成功\n', 0))
        return
      }
      finish(child, 'arkcli version 1.0.39\n', '', 0)
    })
    return child
  }
  let clock = 0
  const login = new ArkCliLogin({ dshHome: '/dsh', binPath: thisFile, spawn, now: () => clock, refFactory: () => 'rDone' })
  await login.start({ ref: 'rDone', home: '/h', ttlMs: 30 })
  await sleep(80)
  clock += 20 * 60_000 // 把注入的时钟推进过 TTL 也一起验一遍
  const afterDone = login.poll({ ref: 'rDone' })
  check('a finished login session stays done after the TTL window (never rewritten to expired)',
    afterDone.state === 'done' && afterDone.ok === true, JSON.stringify(afterDone))
  login.disposeAll()
}

// --- 8b. 走 node:http 的回调转发 ----------------------------------------------
{
  // 为什么不是 fetch：undici 会把 Host 当 forbidden header 丢掉。这里用假的
  // http.request 断言"我们确实把头交给了 socket 层"，再用一次真回环做端到端确认。
  const seen = []
  const requestImpl = (options, callback) => {
    seen.push(options)
    const response = new EventEmitter()
    response.statusCode = 200
    response.headers = { 'content-type': 'text/plain' }
    const request = new EventEmitter()
    request.end = () => queueMicrotask(() => {
      callback(response)
      response.emit('data', 'accepted')
      response.emit('end')
    })
    return request
  }
  const harness = loginHarness()
  const login = new ArkCliLogin({ dshHome: '/dsh', binPath: thisFile, spawn: harness.spawn, requestImpl })
  await login.start({ ref: 'r10', home: '/h' })
  const result = await login.submit({ ref: 'r10', input: 'http://localhost:41035/arkcli/broker/callback?code=abc', waitMs: 40 })
  check('the http adapter dials the loopback address, not the authorize host',
    seen[0].hostname === '127.0.0.1' && seen[0].port === '41035'
    && seen[0].path === '/arkcli/broker/callback?code=abc', JSON.stringify(seen[0]))
  check('the http adapter hands the Host header to the socket layer (fetch would drop it)',
    seen[0].headers.host === '127.0.0.1:41035' && seen[0].method === 'GET', JSON.stringify(seen[0].headers))
  check('a 2xx from the adapter still leaves the session pending when the child lives on',
    result.ok && result.state === 'pending', JSON.stringify(result))

  const clientError = (options, callback) => {
    const response = new EventEmitter()
    response.statusCode = 400
    response.headers = {}
    const request = new EventEmitter()
    request.end = () => queueMicrotask(() => {
      callback(response)
      response.emit('data', 'invalid callback parameters')
      response.emit('end')
    })
    return request
  }
  const harness2 = loginHarness()
  const login2 = new ArkCliLogin({ dshHome: '/dsh', binPath: thisFile, spawn: harness2.spawn, fetchImpl: createHttpFetch(clientError) })
  await login2.start({ ref: 'r11', home: '/h' })
  const rejected = await login2.submit({ ref: 'r11', input: 'http://localhost:41035/arkcli/broker/callback' })
  check('the http adapter maps a 4xx to ok:false with the body',
    !rejected.ok && /HTTP 400/.test(rejected.error) && /invalid callback parameters/.test(rejected.error), rejected.error)

  // Host 校验按实测只认 127.0.0.1:<port>。万一某个版本改认别的，代码会自动用备选
  // Host 再试一次 —— 这条测试盯住那个兜底，免得功能被锁死在一个版本上。
  const hostTries = []
  const invalidHostThenOk = (options, callback) => {
    hostTries.push(options.headers?.host)
    const response = new EventEmitter()
    response.statusCode = hostTries.length === 1 ? 400 : 200
    response.headers = {}
    const request = new EventEmitter()
    request.end = () => queueMicrotask(() => {
      callback(response)
      response.emit('data', hostTries.length === 1 ? 'invalid host\n' : 'login accepted')
      response.emit('end')
    })
    return request
  }
  const retryHarness = loginHarness()
  const retryLogin = new ArkCliLogin({ dshHome: '/dsh', binPath: thisFile, spawn: retryHarness.spawn, fetchImpl: createHttpFetch(invalidHostThenOk) })
  await retryLogin.start({ ref: 'r14', home: '/h' })
  const retried = await retryLogin.submit({ ref: 'r14', input: 'http://localhost:41035/arkcli/broker/callback', waitMs: 30 })
  check('an `invalid host` rejection retries with the alternate loopback host',
    hostTries.length === 2 && hostTries[0] === '127.0.0.1:41035' && hostTries[1] === 'localhost:41035' && retried.ok === true,
    JSON.stringify({ hostTries, state: retried.state }))
  retryLogin.disposeAll()

  const deadListener = () => {
    const request = new EventEmitter()
    request.end = () => queueMicrotask(() => request.emit('error', new Error('connect ECONNREFUSED 127.0.0.1:41035')))
    return request
  }
  const harness3 = loginHarness()
  const login3 = new ArkCliLogin({ dshHome: '/dsh', binPath: thisFile, spawn: harness3.spawn, fetchImpl: createHttpFetch(deadListener) })
  await login3.start({ ref: 'r12', home: '/h' })
  const refused = await login3.submit({ ref: 'r12', input: 'http://localhost:41035/arkcli/broker/callback' })
  check('the http adapter turns a socket error into a readable failure',
    !refused.ok && /ECONNREFUSED/.test(refused.error), refused.error)
  login.disposeAll()
  login2.disposeAll()
  retryLogin.disposeAll()
}

{
  // 端到端：真开一个回环监听（127.0.0.1 的临时端口，不碰外网），确认另一端真的看到
  // `Host: 127.0.0.1:<会话端口>`，并且粘来的旧端口被忽略。
  const seenHosts = []
  const server = createServer((req, res) => {
    seenHosts.push(req.headers.host)
    res.writeHead(200)
    res.end('login accepted')
  })
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve))
  const port = server.address().port
  try {
    const harness = loginHarness(port)
    const login = new ArkCliLogin({ dshHome: '/dsh', binPath: thisFile, spawn: harness.spawn })
    await login.start({ ref: 'r13', home: '/h' })
    const result = await login.submit({ ref: 'r13', input: `http://localhost:${port + 1}/arkcli/broker/callback?code=abc`, waitMs: 60 })
    check('a real loopback listener sees Host: 127.0.0.1:<session port>',
      seenHosts.length === 1 && seenHosts[0] === `127.0.0.1:${port}`, JSON.stringify(seenHosts))
    check('the stale port in the pasted URL is ignored', result.ok && result.state === 'pending', JSON.stringify(result))
    login.disposeAll()
  } finally {
    await new Promise((resolve) => server.close(resolve))
  }
}

// --- 9. status() / install() -------------------------------------------------
{
  const configStatus = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: oneShot('arkcli version 1.0.39\n', 0).spawn })
    .status({ home: '/h' })
  check('status() reports a config-provided binary',
    configStatus.installed && configStatus.source === 'config' && configStatus.path === thisFile, JSON.stringify(configStatus))
  check('status() parses the version banner', configStatus.version === '1.0.39', configStatus.version)

  const brokenStatus = await new ArkCli({ dshHome: '/dsh', binPath: thisFile, spawn: oneShot('', 1, 'permission denied').spawn })
    .status({ home: '/h' })
  check('status() reports a broken binary',
    !brokenStatus.installed && brokenStatus.source === 'config' && brokenStatus.error === 'permission denied', brokenStatus.error)
}

{
  const home = makeTemp('ark-managed-')
  mkdirSync(dirname(managedBinPath(home)), { recursive: true })
  writeFileSync(managedBinPath(home), '#!/bin/sh\n')
  const managed = await new ArkCli({ dshHome: home, pathEnv: '', spawn: oneShot('arkcli version 1.0.39\n', 0).spawn }).resolveBin()
  check('resolveBin() falls back to the managed install',
    managed.source === 'managed' && managed.path === managedBinPath(home), JSON.stringify(managed))

  // 新装（直接下载）的 bin 要优先于老版本 npm 装出来的 shim：前者是 .exe/.bin 真身，
  // 后者是包装脚本；升级之后不该还跑旧的那份。
  const bothHome = makeTemp('ark-managed-both-')
  mkdirSync(dirname(managedBinPath(bothHome)), { recursive: true })
  writeFileSync(managedBinPath(bothHome), '#!/bin/sh\n')
  mkdirSync(dirname(managedBinaryPath(bothHome)), { recursive: true })
  writeFileSync(managedBinaryPath(bothHome), '#!/bin/sh\n')
  const both = await new ArkCli({ dshHome: bothHome, pathEnv: '' }).resolveBin()
  check('resolveBin() prefers the directly downloaded binary over a legacy npm shim',
    both.source === 'managed' && both.path === managedBinaryPath(bothHome), JSON.stringify(both))

  const pathDir = makeTemp('ark-onpath-')
  writeFileSync(join(pathDir, 'arkcli'), '#!/bin/sh\n')
  const onPath = await new ArkCli({ dshHome: makeTemp('ark-empty-'), pathEnv: pathDir, spawn: spawnHarness(() => {}).spawn }).resolveBin()
  check('resolveBin() falls back to PATH', onPath.source === 'path' && onPath.path === join(pathDir, 'arkcli'), JSON.stringify(onPath))

  const empty = new ArkCli({ dshHome: makeTemp('ark-empty2-'), pathEnv: '', spawn: spawnHarness(() => { throw new Error('must not spawn') }).spawn })
  const none = await empty.resolveBin()
  check('resolveBin() returns undefined when nothing is installed', none.path === undefined && none.source === undefined)
  const missing = await empty.status({ home: '/h' })
  check('status() explains a missing install', !missing.installed && /未安装 arkcli/.test(missing.error), missing.error)
}

{
  // --- 9b. 直接下载（主路径）：完全离线，不需要 npm ---
  const home = makeTemp('ark-direct-')
  const payload = Buffer.from('#!/bin/sh\n# fake arkcli 1.0.39\n')
  const digest = createHash('sha256').update(payload).digest('hex')
  const fetched = []
  const fetchImpl = async (url) => {
    fetched.push(url)
    return {
      ok: true,
      status: 200,
      arrayBuffer: async () => payload.buffer.slice(payload.byteOffset, payload.byteOffset + payload.byteLength),
    }
  }
  const calls = []
  const spawn = (bin, args, options) => {
    const child = new FakeChild()
    calls.push({ bin, args, options, child })
    queueMicrotask(() => finish(child, 'arkcli version 1.0.39\n', '', 0))
    return child
  }
  const binaries = { 'linux-amd64': { url: 'https://cdn.example/arkcli-1.0.39-linux-amd64', sha256: digest } }
  // PATH 上故意放一个"假 npm"：下载成功时**不能**再走它（这条断言以前因为 pathEnv=''
  // 是空转的，压根不可能找到 npm）。
  const npmDir = makeTemp('ark-direct-npm-')
  writeFileSync(join(npmDir, 'npm'), '#!/bin/sh\n')
  const installed = await new ArkCli({
    dshHome: home, pathEnv: npmDir, spawn, fetchImpl, platform: 'linux', arch: 'x64', binaries,
  }).install({})
  check('install() downloads the official binary instead of requiring npm',
    installed.ok && installed.path === managedBinaryPath(home, 'linux') && installed.version === '1.0.39',
    JSON.stringify(installed))
  check('install() never spawns npm on the download path',
    calls.every((call) => call.bin !== 'npm' && call.bin !== 'npm.cmd'), calls.map((call) => call.bin).join(','))
  check('install() wrote the downloaded bytes to bin/arkcli',
    readFileSync(managedBinaryPath(home, 'linux')).equals(payload))
  const versionCall = calls.find((call) => call.args.join(' ') === '--version')
  check('install() verifies the downloaded file BEFORE promoting it (temp path)',
    versionCall !== undefined && versionCall.bin.includes('.download')
    && versionCall.bin.startsWith(dirname(managedBinaryPath(home, 'linux'))), JSON.stringify(versionCall?.bin))
  check('install() fetched the CDN url exactly once',
    fetched.length === 1 && fetched[0] === binaries['linux-amd64'].url, JSON.stringify(fetched))

  // 校验不过：不落盘，并给出人话。
  const badHome = makeTemp('ark-badsha-')
  const badBytes = Buffer.from('#!/bin/sh\n# tampered\n')
  const badFetch = async () => ({
    ok: true,
    status: 200,
    arrayBuffer: async () => badBytes.buffer.slice(badBytes.byteOffset, badBytes.byteOffset + badBytes.byteLength),
  })
  const bad = await new ArkCli({
    dshHome: badHome, pathEnv: '', fetchImpl: badFetch, platform: 'linux', arch: 'x64',
    binaries: { 'linux-amd64': { url: 'https://cdn.example/x', sha256: '0'.repeat(64) } },
    spawn: spawnHarness(() => { throw new Error('must not spawn') }).spawn,
  }).install({})
  check('install() refuses a binary whose sha256 does not match',
    !bad.ok && /sha256 不匹配/.test(bad.error) && !existsSync(managedBinaryPath(badHome, 'linux')), bad.error)

  // CDN 失败 → GitHub Release 兜底（第二个源）。
  const fallbackHome = makeTemp('ark-fallback-')
  const seen = []
  const fallbackFetch = async (url) => {
    seen.push(url)
    if (url.includes('cdn')) return { ok: false, status: 503, arrayBuffer: async () => new ArrayBuffer(0) }
    return {
      ok: true,
      status: 200,
      arrayBuffer: async () => payload.buffer.slice(payload.byteOffset, payload.byteOffset + payload.byteLength),
    }
  }
  const fallback = await new ArkCli({
    dshHome: fallbackHome, pathEnv: '', spawn: oneShot('arkcli version 1.0.39\n', 0).spawn, fetchImpl: fallbackFetch,
    platform: 'linux', arch: 'x64',
    binaries: { 'linux-amd64': { url: 'https://cdn.example/a', sha256: digest, fallback: 'https://github.example/a' } },
  }).install({})
  check('install() falls back to the second source when the CDN fails',
    fallback.ok && seen.length === 2 && seen[1] === 'https://github.example/a', JSON.stringify({ seen, fallback }))

  // Windows 上落盘的是 .exe：无扩展名文件 CreateProcess 起不来。
  const winHome = makeTemp('ark-win-install-')
  const winInstalled = await new ArkCli({
    dshHome: winHome, pathEnv: '', spawn: oneShot('arkcli version 1.0.39\n', 0).spawn, fetchImpl,
    platform: 'win32', arch: 'x64',
    binaries: { 'windows-amd64': { url: 'https://cdn.example/arkcli.exe', sha256: digest } },
  }).install({})
  check('a Windows install lands on bin/arkcli.exe',
    winInstalled.ok && winInstalled.path.endsWith('arkcli.exe'), JSON.stringify(winInstalled))

  // 下载回来"能跑"才算装好：坏文件在落盘前被拦住，托管路径不被污染（review finding #1）。
  const probeHome = makeTemp('ark-probe-')
  const probeSpawn = spawnHarness((call) => finish(call.child, '', 'boom\n', 1))
  const probe = await new ArkCli({
    dshHome: probeHome, pathEnv: '', spawn: probeSpawn.spawn, fetchImpl, platform: 'linux', arch: 'x64',
    binaries: { 'linux-amd64': { url: 'https://cdn.example/broken', sha256: digest } },
  }).install({})
  check('a downloaded file that cannot run is never promoted',
    !probe.ok && /无法执行/.test(probe.error) && !existsSync(managedBinaryPath(probeHome, 'linux')), probe.error)
  check('the failed download leaves no temp file behind',
    !existsSync(dirname(managedBinaryPath(probeHome, 'linux')))
    || readdirSync(dirname(managedBinaryPath(probeHome, 'linux'))).length === 0,
    String(readdirSync(dirname(managedBinaryPath(probeHome, 'linux')))))

  // 已经是同一份二进制：不重复下载 40 MB（也避免 Windows 上 rename 覆盖被占用的 .exe）。
  const cachedHome = makeTemp('ark-cached-')
  mkdirSync(dirname(managedBinaryPath(cachedHome, 'linux')), { recursive: true })
  writeFileSync(managedBinaryPath(cachedHome, 'linux'), payload)
  let cacheFetches = 0
  const cached = await new ArkCli({
    dshHome: cachedHome, pathEnv: '', spawn: oneShot('arkcli version 1.0.39\n', 0).spawn,
    fetchImpl: async () => { cacheFetches += 1; throw new Error('must not download') },
    platform: 'linux', arch: 'x64', binaries,
  }).install({})
  check('install() reuses an already-installed binary whose sha256 matches (no re-download)',
    cached.ok && cacheFetches === 0 && cached.path === managedBinaryPath(cachedHome, 'linux'),
    JSON.stringify({ cached, cacheFetches }))

  // sha 对不上的旧文件要被替换掉，而不是被"已经存在"挡住。
  const replaceHome = makeTemp('ark-replace-')
  mkdirSync(dirname(managedBinaryPath(replaceHome, 'linux')), { recursive: true })
  writeFileSync(managedBinaryPath(replaceHome, 'linux'), '#!/bin/sh\n# stale\n')
  const replaced = await new ArkCli({
    dshHome: replaceHome, pathEnv: '', spawn: oneShot('arkcli version 1.0.39\n', 0).spawn,
    fetchImpl, platform: 'linux', arch: 'x64', binaries,
  }).install({})
  check('a stale binary with a different sha256 is replaced',
    replaced.ok && readFileSync(managedBinaryPath(replaceHome, 'linux')).equals(payload), JSON.stringify(replaced))

  // 托管路径写不进去（Windows 上正在运行的 .exe/防病毒占用；这里用"目标是目录"模拟）：
  // 必须说清原因，而且不能为第二个源再下 40 MB。
  const lockedHome = makeTemp('ark-locked-')
  mkdirSync(managedBinaryPath(lockedHome, 'linux'), { recursive: true })
  const lockedFetches = []
  const locked = await new ArkCli({
    dshHome: lockedHome, pathEnv: '', spawn: oneShot('arkcli version 1.0.39\n', 0).spawn,
    fetchImpl: async (url) => {
      lockedFetches.push(url)
      return {
        ok: true,
        status: 200,
        arrayBuffer: async () => payload.buffer.slice(payload.byteOffset, payload.byteOffset + payload.byteLength),
      }
    },
    platform: 'linux', arch: 'x64',
    binaries: { 'linux-amd64': { url: 'https://cdn.example/a', sha256: digest, fallback: 'https://github.example/a' } },
  }).install({})
  check('an unwritable managed path is reported and does not re-download the fallback source',
    !locked.ok && /无法写入/.test(locked.error) && /请先取消再装/.test(locked.error) && lockedFetches.length === 1,
    JSON.stringify({ error: locked.error, lockedFetches }))
}

{
  // --- 9c. npm 兜底：直接下载失败、但 PATH 上有 npm 时仍然能装 ---
  const home = makeTemp('ark-npm-')
  const npmDir = makeTemp('ark-npm-path-')
  const npm = join(npmDir, 'npm')
  writeFileSync(npm, '#!/bin/sh\n')
  chmodSync(npm, 0o755)
  const calls = []
  const spawn = (bin, args, options) => {
    const child = new FakeChild()
    calls.push({ bin, args, options, child })
    queueMicrotask(() => {
      if (bin === npm) {
        // 模拟 postinstall 把 Go 二进制落到 node_modules/.bin。
        mkdirSync(dirname(managedBinPath(home)), { recursive: true })
        writeFileSync(managedBinPath(home), '#!/bin/sh\n')
        finish(child, 'added 1 package in 12s\n', '', 0)
        return
      }
      finish(child, 'arkcli version 1.0.39\n', '', 0)
    })
    return child
  }
  const downloadFails = async () => { throw new Error('ECONNRESET') }
  const installed = await new ArkCli({
    dshHome: home, pathEnv: npmDir, spawn, fetchImpl: downloadFails, platform: 'linux', arch: 'x64',
  }).install({})
  const npmCall = calls.find((call) => call.bin === npm)
  check('install() falls back to npm when the download fails',
    npmCall !== undefined, JSON.stringify(calls.map((call) => call.bin)))
  check('the npm fallback pins the tested version, never latest',
    npmCall.args.includes(`${ARKCLI_PACKAGE}@1.0.39`) && !npmCall.args.some((arg) => arg.endsWith('@latest')),
    npmCall.args.join(' '))
  check('the npm fallback uses the managed dir as --prefix',
    npmCall.args[npmCall.args.indexOf('--prefix') + 1] === managedInstallDir(home))
  check('the npm fallback installs quietly',
    npmCall.args.includes('--no-audit') && npmCall.args.includes('--no-fund'))
  check('the npm fallback runs with its own isolated HOME',
    npmCall.options.env.HOME.startsWith(home), npmCall.options.env.HOME)
  check('install() re-resolves and verifies the npm-installed binary',
    installed.ok && installed.path === managedBinPath(home) && installed.version === '1.0.39', JSON.stringify(installed))

  // 显式要一个不在内置清单里的版本：不试下载，直接 npm。
  const altHome = makeTemp('ark-alt-version-')
  const altCalls = []
  const altSpawn = (bin, args, options) => {
    const child = new FakeChild()
    altCalls.push({ bin, args, options, child })
    queueMicrotask(() => {
      if (bin === npm) {
        mkdirSync(dirname(managedBinPath(altHome)), { recursive: true })
        writeFileSync(managedBinPath(altHome), '#!/bin/sh\n')
        finish(child, '', '', 0)
        return
      }
      finish(child, 'arkcli version 1.0.38\n', '', 0)
    })
    return child
  }
  const alt = await new ArkCli({
    dshHome: altHome, pathEnv: npmDir, spawn: altSpawn, fetchImpl: downloadFails, platform: 'linux', arch: 'x64',
  }).install({ version: '1.0.38' })
  check('an explicit non-manifest version goes straight to npm without hitting the CDN',
    alt.ok && altCalls[0].bin === npm && altCalls[0].args.includes(`${ARKCLI_PACKAGE}@1.0.38`), JSON.stringify(alt))

  // npm 也失败：错误里要带上 npm 的 stderr 尾巴。
  const failingHome = makeTemp('ark-both-fail-')
  const failingSpawn = spawnHarness((call) => finish(call.child, '', 'npm ERR! network timeout\n', 1))
  const failure = await new ArkCli({
    dshHome: failingHome, pathEnv: npmDir, spawn: failingSpawn.spawn, fetchImpl: downloadFails, platform: 'linux', arch: 'x64',
  }).install({ version: '1.0.38' })
  check('install() surfaces the npm stderr tail when everything fails',
    !failure.ok && /npm ERR! network timeout/.test(failure.error), failure.error)

  // 桌面端（没有 npm）：错误要说清"下载失败 + 找不到 npm"，而不是丢一个 ENOENT。
  const desktop = await new ArkCli({
    dshHome: makeTemp('ark-desktop-'), pathEnv: '', spawn: spawnHarness(() => { throw new Error('must not spawn') }).spawn,
    fetchImpl: downloadFails, platform: 'win32', arch: 'x64',
    binaries: { 'windows-amd64': { url: 'https://cdn.example/win.exe', sha256: '0'.repeat(64) } },
  }).install({})
  check('without npm the failure explains both attempts instead of leaking ENOENT',
    !desktop.ok && /下载 arkcli/.test(desktop.error) && /找不到 npm/.test(desktop.error), desktop.error)

  const noHome = await new ArkCli({ dshHome: undefined, spawn: spawnHarness(() => { throw new Error('must not spawn') }).spawn }).install({})
  check('install() refuses to guess an install dir',
    !noHome.ok && /没有 DSH 数据目录/.test(noHome.error), noHome.error)
}

{
  // --- 9d. Windows npm 兜底：npm.cmd 必须经 cmd.exe 起，且 shim 也要能验证 ---
  const home = makeTemp('ark-win-npm-')
  const npmDir = makeTemp('ark-win-npm-path-')
  const npm = join(npmDir, 'npm.cmd')
  writeFileSync(npm, '@echo off\n')
  const calls = []
  const spawn = (bin, args, options) => {
    const child = new FakeChild()
    calls.push({ bin, args, options, child })
    queueMicrotask(() => {
      const line = args.join(' ')
      if (line.includes('install') && line.includes('--prefix')) {
        // 模拟 npm postinstall 落到 Windows 的 .cmd shim。
        mkdirSync(dirname(managedBinPath(home, 'win32')), { recursive: true })
        writeFileSync(managedBinPath(home, 'win32'), '@echo off\n')
        finish(child, 'added 1 package in 12s\n', '', 0)
        return
      }
      finish(child, 'arkcli version 1.0.39\n', '', 0)
    })
    return child
  }
  const installed = await new ArkCli({
    dshHome: home, pathEnv: npmDir, spawn, fetchImpl: async () => { throw new Error('offline') },
    platform: 'win32', arch: 'x64', comspec: 'cmd.exe',
    binaries: { 'windows-amd64': { url: 'https://cdn.example/x.exe', sha256: '0'.repeat(64) } },
  }).install({})
  const npmCall = calls.find((call) => call.args.join(' ').includes('install') && call.args.join(' ').includes('--prefix'))
  check('on Windows the npm fallback launches npm.cmd through cmd.exe',
    installed.ok && npmCall !== undefined && npmCall.bin === 'cmd.exe'
    && npmCall.options.windowsVerbatimArguments === true && npmCall.args[3].includes('npm.cmd'),
    JSON.stringify(npmCall?.args))
  check('on Windows the npm-installed .cmd shim is verified and reported',
    installed.ok && installed.path === managedBinPath(home, 'win32') && installed.version === '1.0.39',
    JSON.stringify(installed))
}

{
  // --- 9e. Windows 登录会话：.cmd 目标经 cmd.exe 起，不 detached，取消能收掉 ---
  const cmdFile = join(makeTemp('ark-win-login-'), 'arkcli.cmd')
  writeFileSync(cmdFile, '@echo off\n')
  const banner = `如果浏览器未自动打开，请手动访问:\n${AUTH_URL_FOR(41036)}\n等待浏览器认证完成...\n`
  const calls = []
  const spawn = (bin, args, options) => {
    const child = new FakeChild()
    calls.push({ bin, args, options, child })
    queueMicrotask(() => {
      if (args.join(' ').includes('auth login')) child.stderr.emit('data', banner)
      else finish(child, '', '', 0)
    })
    return child
  }
  const login = new ArkCliLogin({ dshHome: '/dsh', binPath: cmdFile, spawn, platform: 'win32', comspec: 'cmd.exe' })
  const started = await login.start({ ref: 'win', home: 'C:\\Users\\x\\.dsh\\ark-coding\\accounts\\a' })
  check('on Windows a .cmd login runs through cmd.exe with verbatim args and no detached console',
    started.ok && calls[0].bin === 'cmd.exe' && calls[0].options.windowsVerbatimArguments === true
    && calls[0].options.detached === false && calls[0].args[3].includes('auth login'), JSON.stringify(calls[0]?.args))
  const cancelled = login.cancel({ ref: 'win' })
  check('cancelling the login kills the cmd.exe carrier', cancelled.ok === true && calls[0].child.killed === true)
}

for (const dir of tempDirs) rmSync(dir, { recursive: true, force: true })

// --- 10. 凭据到期时间 ---------------------------------------------------------
{
  // 为什么不是 `auth status`：那里的 `sts_expires_at_ms` 是 STS 的 15 分钟到期，
  // arkcli 自己会刷新，对用户毫无意义。真正决定"什么时候要重新登录"的是 profile 上的
  // `expires_at`（秒），落在 `<HOME>/.arkcli/config.yaml`。
  const fakeRead = (text) => () => text
  const yaml = [
    'lang: zh_cn',
    'default_profile: coding-plan_cn-beijing_personal',
    'profiles:',
    '  coding-plan_cn-beijing_personal:',
    '    type: coding-plan',
    '    plan_tier: lite',
    '    expires_at: 1797350399',
    '    resources:',
    '      text:',
    '        default: doubao-seed-2.1-turbo',
    '  platform_cn-beijing_accountwide:',
    '    type: platform',
    '    expires_at: 1799999999',
    '',
  ].join('\n')
  check('readCredentialExpiry reads the default profile expiry and converts seconds to ms',
    readCredentialExpiry('/h', fakeRead(yaml)) === 1797350399000,
    String(readCredentialExpiry('/h', fakeRead(yaml))))
  check('readCredentialExpiry prefers the default profile over a later one',
    readCredentialExpiry('/h', fakeRead(yaml)) !== 1799999999000)
  check('readCredentialExpiry falls back to the earliest expiry when there is no default',
    readCredentialExpiry('/h', fakeRead(yaml.replace('default_profile: coding-plan_cn-beijing_personal\n', ''))) === 1797350399000)
  check('readCredentialExpiry accepts an already-millisecond value without scaling it twice',
    readCredentialExpiry('/h', fakeRead('default_profile: p\nprofiles:\n  p:\n    expires_at: 1797350399000\n')) === 1797350399000)
  check('readCredentialExpiry returns undefined for a missing file',
    readCredentialExpiry('/h', () => { throw new Error('ENOENT') }) === undefined)
  check('readCredentialExpiry returns undefined for junk, empty input and a bad home',
    readCredentialExpiry('/h', fakeRead('lang: zh_cn\n')) === undefined
    && readCredentialExpiry('/h', fakeRead('')) === undefined
    && readCredentialExpiry(undefined, fakeRead(yaml)) === undefined
    && readCredentialExpiry('', fakeRead(yaml)) === undefined)
  check('readCredentialExpiry ignores a non-positive or non-numeric expiry',
    readCredentialExpiry('/h', fakeRead('default_profile: p\nprofiles:\n  p:\n    expires_at: 0\n')) === undefined
    && readCredentialExpiry('/h', fakeRead('default_profile: p\nprofiles:\n  p:\n    expires_at: soon\n')) === undefined)
  check('readCredentialExpiry ignores negative and astronomically large expiries',
    readCredentialExpiry('/h', fakeRead('default_profile: p\nprofiles:\n  p:\n    expires_at: -5\n')) === undefined
    && readCredentialExpiry('/h', fakeRead('default_profile: p\nprofiles:\n  p:\n    expires_at: 99999999999999999999\n')) === undefined)

  // 目标 profile 内部有**嵌套 map** 时，取到的仍必须是该 profile 的 expires_at。
  // 旧实现一看到任意 `  key:` 形态的行就把缩进基准重置，于是嵌套 map 会把本 profile
  // 的 expires_at 挤出块外，最后可能取到**另一个 profile** 的到期时间 —— 界面上显示
  // 的日期就是错的。这里让另一个 profile 的到期更早，只有取对了才会得到目标值。
  const nested = [
    'default_profile: target',
    'profiles:',
    '  other:',
    '    expires_at: 1000000001',
    '  target:',
    '    cache:',
    '      text:',
    '        default: some-model',
    '    keystore:',
    '      primary: x',
    '    expires_at: 1797350399',
    '',
  ].join('\n')
  check('readCredentialExpiry survives nested maps inside the target profile block',
    readCredentialExpiry('/h', fakeRead(nested)) === 1797350399000,
    String(readCredentialExpiry('/h', fakeRead(nested))))
  check('...and it is the target profile value, not the sibling profile value',
    readCredentialExpiry('/h', fakeRead(nested)) !== 1000000001000)
  check('without a default_profile the earliest expiry still wins',
    readCredentialExpiry('/h', fakeRead(nested.replace('default_profile: target\n', ''))) === 1000000001000,
    String(readCredentialExpiry('/h', fakeRead(nested.replace('default_profile: target\n', '')))))

  // 目标 profile 的块边界：目标自己**没有** expires_at，后面还有另一个 profile 有。
  // 正确的做法是"缩进回到同级或更外层就算块结束"，于是只能落到全文件最早的那个；
  // 不做边界判断就会顺手取到后面那个 profile 的（更晚）到期时间。
  const boundary = [
    'default_profile: target',
    'profiles:',
    '  early:',
    '    expires_at: 1000000001',
    '  target:',
    '    type: coding-plan',
    '  late:',
    '    expires_at: 1797350399',
    '',
  ].join('\n')
  check('readCredentialExpiry stops at the end of the target profile block',
    readCredentialExpiry('/h', fakeRead(boundary)) === 1000000001000,
    String(readCredentialExpiry('/h', fakeRead(boundary))))
}

// --- 11. parseResetAt：时间戳越界必须 undefined，绝不返回 NaN ------------------
{
  // `new Date(-1000).toLocaleString()` 渲染成 1970-01-01，`new Date(1e300)` 渲染成
  // "Invalid Date" —— 都是**假日期**。formatClock 的 try/catch 拦不住（它们不抛）。
  check('parseResetAt rejects out-of-range numbers instead of fabricating a date',
    parseResetAt(-1) === undefined && parseResetAt(0) === undefined
    && parseResetAt(1e300) === undefined && parseResetAt(8.64e15 + 1) === undefined)
  check('parseResetAt accepts seconds and milliseconds within range',
    parseResetAt(1792084800) === 1792084800000 && parseResetAt(1792084800000) === 1792084800000)
  check('parseResetAt parses an RFC3339 string and rejects junk',
    parseResetAt('2026-10-16T18:00:00+08:00') === Date.parse('2026-10-16T18:00:00+08:00')
    && parseResetAt('not-a-date') === undefined && parseResetAt('') === undefined && parseResetAt(undefined) === undefined)
}

console.log(failures === 0 ? '\nALL PASS' : `\n${failures} FAILURE(S)`)
process.exit(failures === 0 ? 0 : 1)
