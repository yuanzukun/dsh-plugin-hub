/**
 * 宿主适配器本体的离线测试（**不需要密钥、不需要网络**）。
 *
 * 为什么单独一个文件：在它之前，宿主的全部真实行为（目录事实、请求体夹取、
 * 失败码、SSE 解析、账户解析、apply() 的接线、缓存去重）只在
 * `tests/adapter.test.mjs` 里被测 —— 而那一套需要 `ARK_CODING_TEST_KEY`。
 * 于是默认 `npm test`（无密钥）对宿主适配器**零覆盖**：改坏档位、少一个模型、
 * 去掉 `max_tokens` 夹取、改失败码……离线三套（usage/arkcli/client）全都不会变红。
 * 这就是本文件存在的理由。
 *
 * 依赖说明：`../index.js` 顶层 import 了 harness 包，裸 `node` 跑不起来。
 * 请经 `node tests/run.mjs` 运行（它会在临时沙箱里建好 `node_modules` 符号链接）。
 * 直接运行时本文件会打印 SKIP 并以 0 退出，避免 `node --test tests/` 假红。
 * `models.js` / `accounts.js` / `arkcli.js` 是纯模块，静态导入没有这个问题。
 *
 * 覆盖分两段：
 *   A. 纯静态/纯离线断言（目录、请求体、失败码、图片预算、SSE 契约、账户解析）；
 *   B. 经真实 cordis Context 驱动 `apply()`，从 `ctx.get('arkCodingUsage')` 取回
 *      deps 后验证接线、HOME 校验、缓存键与在途去重（这些逻辑以前藏在闭包里测不到）。
 */
import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { homedir, tmpdir } from 'node:os'
import { join } from 'node:path'
import { MODELS, modelById } from '../models.js'
import { describeAccounts } from '../accounts.js'
import { ArkCli, arkcliStateRoot } from '../arkcli.js'

// --- 需要 harness 包的导入：拿不到就明确 SKIP（见文件头） ---------------------
let host
let isJsonValue
let Context
try {
  host = await import('../index.js')
  ;({ isJsonValue } = await import('@deepseek-ai/dsh-util-values'))
  ;({ Context } = await import('@deepseek-ai/cordis'))
} catch (error) {
  console.log('SKIP  host adapter suite needs the harness packages (../index.js).')
  console.log('      运行方式：node tests/run.mjs（会在沙箱里补上 node_modules 符号链接）。')
  console.log(`      ${error?.code ?? error}`)
  console.log('\nALL PASS (skipped)')
  process.exit(0)
}

const {
  ArkCodingAdapter,
  CATALOG_REFRESH_DESCRIPTOR,
  CLI_INSTALL_DESCRIPTOR,
  CLI_STATUS_DESCRIPTOR,
  Config,
  DEFAULT_API_BASE,
  DEFAULT_MAX_OUTPUT_TOKENS,
  DEFAULT_MAX_REQUEST_IMAGE_BYTES,
  LOGIN_BEGIN_DESCRIPTOR,
  LOGIN_CANCEL_DESCRIPTOR,
  LOGIN_POLL_DESCRIPTOR,
  LOGIN_SUBMIT_DESCRIPTOR,
  PROVIDER,
  USAGE_CLIENT_CONTRIBUTION,
  USAGE_REPORT_DESCRIPTOR,
  apply,
  resolveConnection,
  toModelInfo,
  toResolvedModelInfo,
  unwrapVolatileConfig,
} = host

let failures = 0
const check = (name, ok, detail) => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail === undefined ? '' : ` — ${detail}`}`)
  if (!ok) failures += 1
}
/**
 * 记录一条**已确认的源码缺陷**：打印成 `KNOWN-BUG`，不计入失败（源码冻结期间
 * 套件必须全绿），但会出现在输出与报告里，修复后这里会自然变成一句 PASS 说明。
 */
const issues = []
const issue = (text) => {
  issues.push(text)
  console.log(`KNOWN-BUG  ${text}`)
}
const step = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

/**
 * 把 DSH_HOME 指到临时目录。
 *
 * 两个理由：一是 `apply()` 的 HOME 校验/派生都必须有一个可控的状态根；二是本机
 * 环境里 DSH_HOME=/data/dsh（只读测试不该去碰真实状态）。文件尾恢复原值。
 */
const originalDshHome = process.env.DSH_HOME
const tempRoot = mkdtempSync(join(tmpdir(), 'ark-host-test-'))
process.env.DSH_HOME = tempRoot
const STATE_ROOT = arkcliStateRoot(tempRoot)

/** 缺省适配器：配置空对象（全部走默认），不注入 marks / attachments / ctx。 */
function makeAdapter(config = {}) {
  return new ArkCodingAdapter({
    config: () => config,
    ctx: () => ({ get: () => undefined }),
    attachments: () => undefined,
    logger: { warn: () => {} },
  })
}

// ---------------------------------------------------------------------------
// A1. 目录事实：12 个模型、顺序、容量、模态、思考档位
// ---------------------------------------------------------------------------
// 这一节全是**钉死的实测值**：任何一行被改动、删掉或换序，这里都必须变红。
const EXPECTED_MODEL_IDS = [
  'doubao-seed-evolving',
  'doubao-seed-2.1-pro',
  'doubao-seed-2.1-lite',
  'doubao-seed-2.0-mini',
  'minimax-m3',
  'glm-5.3',
  'glm-5.3-flash',
  'deepseek-v4.1-flash',
  'deepseek-v4-flash',
  'deepseek-v4-pro',
  'kimi-k2.8-preview',
  'kimi-k3',
]
const ALL_EFFORTS = 'off,minimal,low,medium,high,max'
/** 逐模型事实表：上下文 / 输出上限 / 模态 / 档位 / 默认档。 */
const EXPECTED_FACTS = {
  'doubao-seed-evolving': { ctx: 1048576, out: 262144, input: 'text,image', efforts: ALL_EFFORTS, default: 'medium', family: 'Doubao' },
  'doubao-seed-2.1-pro': { ctx: 1048576, out: 262144, input: 'text,image', efforts: ALL_EFFORTS, default: 'medium', family: 'Doubao' },
  'doubao-seed-2.1-lite': { ctx: 1048576, out: 262144, input: 'text,image', efforts: ALL_EFFORTS, default: 'medium', family: 'Doubao' },
  'doubao-seed-2.0-mini': { ctx: 262144, out: 131072, input: 'text,image', efforts: ALL_EFFORTS, default: 'medium', family: 'Doubao' },
  'minimax-m3': { ctx: 1048576, out: 131072, input: 'text,image', efforts: ALL_EFFORTS, default: 'medium', family: 'MiniMax' },
  // glm-5.3 实测拒图，并且拒 none/minimal —— 只剩 low/medium/high/max 四档。
  'glm-5.3': { ctx: 1048576, out: 131072, input: 'text', efforts: 'low,medium,high,max', default: 'high', family: 'Zhipu' },
  'glm-5.3-flash': { ctx: 1048576, out: 131072, input: 'text,image', efforts: ALL_EFFORTS, default: 'high', family: 'Zhipu' },
  'deepseek-v4.1-flash': { ctx: 1048576, out: 393216, input: 'text,image', efforts: ALL_EFFORTS, default: 'medium', family: 'DeepSeek' },
  'deepseek-v4-flash': { ctx: 1048576, out: 393216, input: 'text', efforts: ALL_EFFORTS, default: 'medium', family: 'DeepSeek' },
  'deepseek-v4-pro': { ctx: 1048576, out: 393216, input: 'text', efforts: ALL_EFFORTS, default: 'medium', family: 'DeepSeek' },
  'kimi-k2.8-preview': { ctx: 1048576, out: 131072, input: 'text,image', efforts: ALL_EFFORTS, default: 'medium', family: 'Moonshot' },
  'kimi-k3': { ctx: 1048576, out: 131072, input: 'text,image', efforts: ALL_EFFORTS, default: 'medium', family: 'Moonshot' },
}

const plainAdapter = makeAdapter()
const listed = await plainAdapter.listModels(PROVIDER)
check('the catalog exposes exactly the twelve pinned model ids in order',
  listed.map((model) => model.id).join(',') === EXPECTED_MODEL_IDS.join(','),
  listed.map((model) => model.id).join(','))
check('MODELS itself is the same twelve rows in the same order',
  MODELS.map((model) => model.id).join(',') === EXPECTED_MODEL_IDS.join(',') && MODELS.length === 12,
  `${MODELS.length} rows`)

for (const id of EXPECTED_MODEL_IDS) {
  const facts = EXPECTED_FACTS[id]
  const entry = modelById(id)
  const resolved = await plainAdapter.resolveModel(PROVIDER, id)
  check(`${id} carries the measured ctx/output/modality/effort facts`,
    entry !== undefined
    && entry.contextWindow === facts.ctx && entry.maxOutput === facts.out
    && entry.family === facts.family
    && entry.input.join(',') === facts.input
    && entry.efforts.map((effort) => effort.id).join(',') === facts.efforts
    && entry.defaultEffort === facts.default
    && resolved.context.contextWindow === facts.ctx
    && resolved.inputModalities.join(',') === facts.input
    && resolved.reasoning.efforts.map((effort) => effort.id).join(',') === facts.efforts
    && resolved.reasoning.defaultEffort === facts.default,
    `${entry?.contextWindow}/${entry?.maxOutput} ${entry?.input?.join(',')} ${entry?.efforts?.map((e) => e.id).join(',')}`)
}

// 模型描述会出现在 harness **共享的**模型选择器里，那里没有插件侧的语言席位。
// 所以它必须是语言无关的 `Family · 1024K ctx`，不能含中文（否则英文界面里只有这行是中文）。
const descriptionViolations = []
for (const model of MODELS) {
  const connection = plainAdapter.connection()
  for (const info of [toModelInfo(model, connection), toResolvedModelInfo(model, connection)]) {
    if (!/^[A-Za-z]+ · \d+K ctx$/.test(info.description) || /[\u4e00-\u9fff]/.test(info.description)) {
      descriptionViolations.push(`${model.id}=${JSON.stringify(info.description)}`)
    }
  }
}
check('every model description is language-independent (Family · <n>K ctx, no CJK)',
  descriptionViolations.length === 0, descriptionViolations.slice(0, 4).join(' | '))

// Config 的默认值也是契约的一部分：`sidebarQuota` 必须是三态字符串 'auto'
// （以前是 z.boolean().default(true)，于是「自动」这一档永远生效不了）。
const configDefaults = unwrapVolatileConfig(new Config({}))
check('Config defaults sidebarQuota to the three-state auto',
  configDefaults.sidebarQuota === 'auto', String(configDefaults.sidebarQuota))
check('Config keeps the documented endpoint/output defaults',
  configDefaults.apiBase === DEFAULT_API_BASE && configDefaults.defaultMaxTokens === DEFAULT_MAX_OUTPUT_TOKENS,
  `${configDefaults.apiBase} / ${configDefaults.defaultMaxTokens}`)

// ---------------------------------------------------------------------------
// A2. 请求体：max_tokens 双向夹取
// ---------------------------------------------------------------------------
const mini = modelById('doubao-seed-2.0-mini') // maxOutput 131072
const big = modelById('deepseek-v4.1-flash') // maxOutput 393216
const defaultConnection = plainAdapter.connection()
const maxTokensOf = (options, model = mini) => plainAdapter.buildBody(options, model, defaultConnection, []).max_tokens

check('a request above the model ceiling is clamped to the model maxOutput',
  maxTokensOf({ maxTokens: 999999 }) === 131072, String(maxTokensOf({ maxTokens: 999999 })))
check('a higher model ceiling is honoured up to its own maxOutput',
  maxTokensOf({ maxTokens: 999999 }, big) === 393216, String(maxTokensOf({ maxTokens: 999999 }, big)))
check('a zero/negative request falls back to the plugin default before clamping',
  maxTokensOf({ maxTokens: 0 }) === DEFAULT_MAX_OUTPUT_TOKENS
  && maxTokensOf({ maxTokens: -5 }) === DEFAULT_MAX_OUTPUT_TOKENS,
  `${maxTokensOf({ maxTokens: 0 })} / ${maxTokensOf({ maxTokens: -5 })}`)
const raisedDefault = makeAdapter({ defaultMaxTokens: 200000 }).connection()
check('a raised plugin default is still clamped by the model ceiling',
  plainAdapter.buildBody({}, mini, raisedDefault, []).max_tokens === 131072
  && plainAdapter.buildBody({}, big, raisedDefault, []).max_tokens === 200000,
  `${plainAdapter.buildBody({}, mini, raisedDefault, []).max_tokens} / ${plainAdapter.buildBody({}, big, raisedDefault, []).max_tokens}`)

// ---------------------------------------------------------------------------
// A3. resolveModel：defaultMaxTokens 的超上限夹具（旧夹具两侧同为 1024，是同义反复）
// ---------------------------------------------------------------------------
const raisedAdapter = makeAdapter({ defaultMaxTokens: 200000 })
const clampedKimi = await raisedAdapter.resolveModel(PROVIDER, 'kimi-k3') // maxOutput 131072
const clampedBig = await raisedAdapter.resolveModel(PROVIDER, 'deepseek-v4.1-flash') // maxOutput 393216
check('resolveModel clamps a config default above the model ceiling down to maxOutput',
  clampedKimi.defaultMaxTokens === 131072, String(clampedKimi.defaultMaxTokens))
check('resolveModel keeps a config default below the model ceiling',
  clampedBig.defaultMaxTokens === 200000, String(clampedBig.defaultMaxTokens))

// ---------------------------------------------------------------------------
// A4. HTTP 失败码映射（驱动真实 streamOnce，喂假 Response）
// ---------------------------------------------------------------------------
const failureConnection = { apiBase: 'https://example.invalid', requestTimeoutMs: 5000, streamIdleTimeoutMs: 5000 }

/** 用假 fetch 打一次 streamOnce，返回抛出的错误（没有抛就返回 undefined）。 */
async function streamOnceFailure(response) {
  const previous = globalThis.fetch
  globalThis.fetch = async () => response
  try {
    for await (const _chunk of plainAdapter.streamOnce(
      { provider: PROVIDER, model: 'kimi-k3', messages: [] },
      failureConnection,
      modelById('kimi-k3'),
      { body: {} },
      { id: 'probe', key: 'ark-probe-key', label: 'probe' },
    )) { /* 只关心它抛什么 */ }
    return undefined
  } catch (error) {
    return error
  } finally {
    globalThis.fetch = previous
  }
}
function httpResponse(status, bodyText, headers = {}) {
  return {
    ok: status >= 200 && status < 300,
    status,
    headers: { get: (name) => headers[String(name).toLowerCase()] ?? null },
    text: async () => bodyText,
  }
}

for (const status of [401, 403]) {
  const error = await streamOnceFailure(httpResponse(status, '{"error":{"message":"bad key"}}'))
  check(`HTTP ${status} maps to AUTH`, error?.code === 'AUTH', String(error?.code))
}
{
  const error = await streamOnceFailure(httpResponse(429, ''))
  check('HTTP 429 maps to RATE_LIMIT', error?.code === 'RATE_LIMIT', String(error?.code))
  for (const status of [500, 503]) {
    const failure = await streamOnceFailure(httpResponse(status, ''))
    check(`HTTP ${status} maps to SERVER`, failure?.code === 'SERVER', String(failure?.code))
  }
  const quota = await streamOnceFailure(httpResponse(400, '{"error":{"code":"QuotaExceeded","message":"quota exceeded"}}'))
  check('a 400 whose body names an exhausted quota maps to QUOTA', quota?.code === 'QUOTA', String(quota?.code))
  const context = await streamOnceFailure(httpResponse(400, '{"error":{"message":"This model\'s maximum context length is 1048576 tokens"}}'))
  check('a 400 whose body names the context window maps to CONTEXT_WINDOW_EXCEEDED',
    context?.code === 'CONTEXT_WINDOW_EXCEEDED', String(context?.code))
  const other = await streamOnceFailure(httpResponse(400, '{"error":{"message":"unknown field"}}'))
  check('any other status maps to PROVIDER_ERROR', other?.code === 'PROVIDER_ERROR', String(other?.code))
}

// ---------------------------------------------------------------------------
// A5. Retry-After 解析：'0' 不产生 providerRetryAfterMs（否则审核期整段轮换失效）
// ---------------------------------------------------------------------------
{
  const zero = await streamOnceFailure(httpResponse(429, '', { 'retry-after': '0' }))
  check("Retry-After '0' does not produce providerRetryAfterMs (0 would make LlmError throw)",
    zero?.code === 'RATE_LIMIT' && zero?.failure?.providerRetryAfterMs === undefined,
    JSON.stringify({ code: zero?.code, after: zero?.failure?.providerRetryAfterMs }))

  const seconds = await streamOnceFailure(httpResponse(429, '', { 'retry-after': '30' }))
  check("Retry-After '30' becomes 30000 ms",
    seconds?.failure?.providerRetryAfterMs === 30000, String(seconds?.failure?.providerRetryAfterMs))

  const huge = await streamOnceFailure(httpResponse(429, '', { 'retry-after': '99999999999999999999' }))
  check('a malformed huge Retry-After is clamped to one hour',
    huge?.failure?.providerRetryAfterMs === 60 * 60_000, String(huge?.failure?.providerRetryAfterMs))

  const past = await streamOnceFailure(httpResponse(429, '', { 'retry-after': new Date(Date.now() - 60_000).toUTCString() }))
  check('a Retry-After HTTP-date in the past produces no retry hint',
    past?.code === 'RATE_LIMIT' && past?.failure?.providerRetryAfterMs === undefined,
    JSON.stringify({ code: past?.code, after: past?.failure?.providerRetryAfterMs }))
}

// 429 双账户：Retry-After '0' 时仍必须换号、仍写冷却标记、最终 code 仍是 RATE_LIMIT。
{
  const marked = []
  const rotationAdapter = new ArkCodingAdapter({
    config: () => ({
      apiBase: 'https://example.invalid',
      accounts: [
        { id: 'a1', label: '一号', apiKey: 'ark-account-one' },
        { id: 'a2', label: '二号', apiKey: 'ark-account-two' },
      ],
    }),
    ctx: () => ({ get: () => undefined }),
    attachments: () => undefined,
    marks: {
      usable: () => true,
      mark: (id, reason, until) => marked.push({ id, reason, until }),
      clear: () => {},
    },
    logger: { warn: () => {} },
  })
  const previous = globalThis.fetch
  globalThis.fetch = async () => httpResponse(429, '', { 'retry-after': '0' })
  let rotatedError
  try {
    for await (const _chunk of rotationAdapter.stream({ provider: PROVIDER, model: 'kimi-k3', messages: [] })) { /* noop */ }
  } catch (error) {
    rotatedError = error
  } finally {
    globalThis.fetch = previous
  }
  const now = Date.now()
  check("a 429 with Retry-After '0' still rotates through both accounts and surfaces RATE_LIMIT",
    rotatedError?.code === 'RATE_LIMIT' && marked.length === 2,
    JSON.stringify({ code: rotatedError?.code, marks: marked.map((m) => m.id) }))
  check('the cooldown fallback is the five-minute default (not a zero/impossible hint)',
    marked.every((mark) => mark.reason === 'rate-limit' && mark.until - now > 60_000 && mark.until - now <= 5 * 60_000 + 5_000),
    JSON.stringify(marked.map((m) => m.until - now)))
}

// ---------------------------------------------------------------------------
// A6. 图片预算：原始字节口径 + 按出现次数计入 + 常量
// ---------------------------------------------------------------------------
const MIB = 1024 * 1024

/** 假附件服务：每个 attachmentId 返回固定原始字节数，并记录请求版参数。 */
function fakeAttachments(bytesById, targets = []) {
  return {
    async readImageRequest(ref, target) {
      targets.push({ attachmentId: ref.attachmentId, ...target })
      return {
        attachment: ref,
        data: Buffer.alloc(4),
        mediaType: 'image/png',
        bytes: bytesById[ref.attachmentId] ?? 0,
        width: ref.width,
        height: ref.height,
      }
    },
  }
}
function imageMessages(ids) {
  return [{
    role: 'user',
    content: ids.map((attachmentId) => ({ type: 'image', attachment: { attachmentId, mediaType: 'image/png' } })),
  }]
}

{
  const targets = []
  const one = imageMessages(['img-1'])
  one[0].content[0].attachment.width = 3000
  one[0].content[0].attachment.height = 1000
  await plainAdapter.projectImages(one, fakeAttachments({ 'img-1': 1000 }, targets))
  check('request images are projected to a 1568 long edge with a 1 MiB encoded cap',
    targets[0]?.width === 1568 && targets[0]?.height === 523 && targets[0]?.maxBytes === MIB,
    JSON.stringify(targets[0]))
  check('the documented request image budget is 20 MiB',
    DEFAULT_MAX_REQUEST_IMAGE_BYTES === 20 * MIB, String(DEFAULT_MAX_REQUEST_IMAGE_BYTES))
}

{
  // 3 张原始各 6 MiB：原始字节 ×3 = 18 MiB；base64 后 = 24 MiB > 20 MiB → 最旧 1 张才够。
  // 旧实现用 base64 长度算原始字节（多算一遍），报出的 missing 会偏大 → 上层永久多卸载。
  let offloadError
  try {
    await plainAdapter.projectImages(imageMessages(['i1', 'i2', 'i3']), fakeAttachments({ i1: 6 * MIB, i2: 6 * MIB, i3: 6 * MIB }))
  } catch (error) {
    offloadError = error
  }
  check('three 6 MiB originals exceed the 20 MiB budget by exactly one image',
    offloadError?.code === 'IMAGE_OFFLOAD_REQUIRED' && offloadError?.failure?.offloadImages === 1,
    JSON.stringify({ code: offloadError?.code, offload: offloadError?.failure?.offloadImages }))
}

{
  // 同一个附件出现两次：body 里就会出现两份 base64，预算必须按**出现次数**算。
  // 按 attachmentId 去重的旧实现会漏算一半，于是超预算的请求被放行。
  const twice = imageMessages(['dup', 'dup'])
  let dedupError
  try {
    await plainAdapter.projectImages(twice, fakeAttachments({ dup: 8 * MIB }))
  } catch (error) {
    dedupError = error
  }
  check('a repeated attachment is counted once per occurrence (body would carry two copies)',
    dedupError?.code === 'IMAGE_OFFLOAD_REQUIRED' && dedupError?.failure?.offloadImages === 1,
    JSON.stringify({ code: dedupError?.code, offload: dedupError?.failure?.offloadImages }))
}

// ---------------------------------------------------------------------------
// A7. options.system 作为**首条** system 消息进入请求体
// ---------------------------------------------------------------------------
{
  const prepared = await plainAdapter.prepare({
    provider: PROVIDER,
    model: 'kimi-k3',
    system: 'POLICY',
    messages: [{ role: 'user', content: [{ type: 'text', text: 'hi' }] }],
  }, defaultConnection, modelById('kimi-k3'))
  const messages = prepared.body.messages
  check('options.system lands as the first system message ahead of the user turn',
    messages[0]?.role === 'system' && messages[0]?.content === 'POLICY'
    && messages[1]?.role === 'user' && messages[1]?.content === 'hi',
    JSON.stringify(messages))
  const without = await plainAdapter.prepare({
    provider: PROVIDER,
    model: 'kimi-k3',
    system: '   ',
    messages: [{ role: 'user', content: [{ type: 'text', text: 'hi' }] }],
  }, defaultConnection, modelById('kimi-k3'))
  check('a blank options.system adds no system message at all',
    without.body.messages.every((message) => message.role !== 'system'), JSON.stringify(without.body.messages))
}

// ---------------------------------------------------------------------------
// A8. normalizeUsage：脏计数必须变成非负安全整数，且 chunk 仍是无损 JSON
// ---------------------------------------------------------------------------
function sseResponseOf(text) {
  const bytes = new TextEncoder().encode(text)
  let sent = false
  return {
    body: {
      getReader() {
        return {
          async read() {
            if (sent) return { done: true, value: undefined }
            sent = true
            return { done: false, value: bytes }
          },
          async cancel() {},
        }
      },
    },
  }
}
const streamConnection = { streamIdleTimeoutMs: 5000, requestTimeoutMs: 5000 }
async function collectFrom(response) {
  const chunks = []
  for await (const chunk of plainAdapter.parseStream(response, streamConnection, { signal: undefined })) chunks.push(chunk)
  return chunks
}
function sseFrame(payload) {
  return `data: ${typeof payload === 'string' ? payload : JSON.stringify(payload)}\n\n`
}

{
  const chunks = await collectFrom(sseResponseOf(
    sseFrame({ choices: [{ delta: { content: 'ok' } }] })
    + sseFrame({
      choices: [{ delta: {}, finish_reason: 'stop' }],
      usage: {
        prompt_tokens: -7,
        completion_tokens: 1.5,
        total_tokens: 1e308,
        prompt_tokens_details: { cached_tokens: 2 },
        completion_tokens_details: { reasoning_tokens: 3 },
      },
    })
    + sseFrame('[DONE]'),
  )).catch((error) => error)
  const chunksList = Array.isArray(chunks) ? chunks : []
  const usage = chunksList.find((chunk) => chunk.type === 'usage')?.usage
  const numbers = usage === undefined ? [] : Object.values(usage)
  check('dirty upstream token counts become non-negative safe integers',
    usage !== undefined
    && numbers.every((value) => Number.isSafeInteger(value) && value >= 0)
    && usage.outputTokens === 0 && usage.totalTokens === 0 && usage.inputTokens === 0 && usage.reasoningTokens === 3,
    JSON.stringify(usage ?? String(chunks)))
  check('the usage chunk stays losslessly JSON-serializable',
    chunksList.filter((chunk) => !isJsonValue(chunk)).length === 0, JSON.stringify(chunksList.filter((chunk) => !isJsonValue(chunk)).slice(0, 2)))
}

// ---------------------------------------------------------------------------
// A9. SSE 解析的七条边界契约
// ---------------------------------------------------------------------------
{
  // ① 结尾没有换行的完整帧必须被消费（旧实现只在 indexOf('\n') 命中时处理那一帧）。
  const noTrailingNewline = `data: ${JSON.stringify({ choices: [{ delta: { content: 'TAIL' } }] })}\ndata: ${JSON.stringify({ choices: [{ delta: {}, finish_reason: 'stop' }] })}`
  const chunks = await collectFrom(sseResponseOf(noTrailingNewline)).catch((error) => error)
  const text = Array.isArray(chunks)
    ? chunks.filter((chunk) => chunk.type === 'block-end' && chunk.block.type === 'text').map((chunk) => chunk.block.text).join('')
    : ''
  check('a complete final frame without a trailing newline is still consumed',
    Array.isArray(chunks) && text === 'TAIL' && chunks.at(-1)?.type === 'finish',
    JSON.stringify({ text, last: Array.isArray(chunks) ? chunks.at(-1)?.type : String(chunks) }))
}
{
  // ② 干净关闭但没有 finish_reason / [DONE] → 截断，必须报 TRANSPORT（不是成功的 stop）。
  let truncation
  try {
    await collectFrom(sseResponseOf(`data: ${JSON.stringify({ choices: [{ delta: { content: 'half' } }] })}\n\n`))
  } catch (error) {
    truncation = error
  }
  check('a clean close without finish_reason/[DONE] is reported as TRANSPORT truncation',
    truncation?.code === 'TRANSPORT', String(truncation?.code))
}
{
  // ③ [DONE] 之后的数据是上游重复/补发，必须忽略。
  const chunks = await collectFrom(sseResponseOf(
    sseFrame({ choices: [{ delta: { content: 'A' } }] })
    + sseFrame('[DONE]')
    + sseFrame({ choices: [{ delta: { content: 'B' } }, { finish_reason: 'stop' }] }),
  )).catch((error) => error)
  const text = Array.isArray(chunks)
    ? chunks.filter((chunk) => chunk.type === 'block-end' && chunk.block.type === 'text').map((chunk) => chunk.block.text).join('')
    : ''
  check('data after [DONE] is ignored', text === 'A', JSON.stringify(Array.isArray(chunks) ? text : String(chunks)))
}
{
  // ④ 字符串形式的流内错误帧必须抛错（旧实现只认对象，字符串错误被完全吞掉）。
  let frameError
  try {
    await collectFrom(sseResponseOf(sseFrame({ error: 'upstream exploded' })))
  } catch (error) {
    frameError = error
  }
  check('a string-shaped in-stream error frame throws instead of succeeding silently',
    frameError?.code === 'PROVIDER_ERROR' && /upstream exploded/.test(frameError?.message ?? ''),
    `${frameError?.code}: ${frameError?.message}`)
}
{
  // ⑤ 上游中途断连时 undici 抛的是裸 TypeError；适配器必须包成 LlmError/TRANSPORT。
  const reader = {
    read: async () => ({ done: false, value: new TextEncoder().encode(`data: ${JSON.stringify({ choices: [{ delta: { content: 'x' } }] })}\n\n`) }),
    cancel: async () => {},
  }
  let reads = 0
  reader.read = async () => {
    reads += 1
    if (reads === 1) return { done: false, value: new TextEncoder().encode(`data: ${JSON.stringify({ choices: [{ delta: { content: 'x' } }] })}\n\n`) }
    throw new TypeError('terminated')
  }
  let disconnect
  try {
    for await (const _chunk of plainAdapter.parseStream({ body: { getReader: () => reader } }, streamConnection, { signal: undefined })) { /* noop */ }
  } catch (error) {
    disconnect = error
  }
  check('a mid-stream bare TypeError becomes a TRANSPORT LlmError, never a raw TypeError',
    disconnect?.name === 'LlmError' && disconnect?.code === 'TRANSPORT', `${disconnect?.name}: ${disconnect?.code}`)
}
{
  // ⑥ 单条超长行 → PROVIDER_ERROR（内存放大攻击面）。
  let hugeLine
  try {
    await collectFrom(sseResponseOf(`data: ${'x'.repeat(8 * MIB + 64)}\n\n`))
  } catch (error) {
    hugeLine = error
  }
  check('a single SSE line above the 8 MiB cap is rejected with PROVIDER_ERROR',
    hugeLine?.code === 'PROVIDER_ERROR', String(hugeLine?.code))
}
{
  // ⑦ 空闲超时时 reader.cancel() 返回 rejected promise → 绝不能产生未处理 rejection
  // （DSH 把 unhandledRejection 当致命错误，会把宿主进程打挂）。
  const rejections = []
  const onRejection = (reason) => rejections.push(reason)
  process.on('unhandledRejection', onRejection)
  const reader = {
    read: () => new Promise((_resolve, reject) => { reader.pendingReject = reject }),
    cancel: () => {
      reader.pendingReject?.(new Error('cancelled by idle timeout'))
      return Promise.reject(new Error('cancel rejected'))
    },
  }
  let idleError
  try {
    for await (const _chunk of plainAdapter.parseStream({ body: { getReader: () => reader } }, { streamIdleTimeoutMs: 10, requestTimeoutMs: 10 }, { signal: undefined })) { /* noop */ }
  } catch (error) {
    idleError = error
  }
  await step(20)
  process.removeListener('unhandledRejection', onRejection)
  check('an idle timeout surfaces TIMEOUT and its rejected reader.cancel() leaks no unhandled rejection',
    idleError?.code === 'TIMEOUT' && rejections.length === 0,
    JSON.stringify({ code: idleError?.code, rejections: rejections.map((reason) => String(reason?.message ?? reason)) }))
}

// ---------------------------------------------------------------------------
// A10. 凭据引用与账户兜底（resolveConnection / describeAccounts）
// ---------------------------------------------------------------------------
{
  let blank
  let dashed
  try { blank = resolveConnection({ apiKeyEnv: '' }) } catch (error) { blank = error }
  try { dashed = resolveConnection({ apiKeyEnv: 'MY-KEY' }) } catch (error) { dashed = error }
  check("an empty apiKeyEnv is not a credential ref and does not throw",
    blank instanceof Error === false && blank.fallbackRef === undefined && blank.accounts.length === 0,
    String(blank?.fallbackRef))
  check("a dashed apiKeyEnv is not a credential ref and does not throw",
    dashed instanceof Error === false && dashed.fallbackRef === undefined && dashed.accounts.length === 0,
    String(dashed?.fallbackRef))

  // 顶层 apiKeyEnv 的兜底只在一个账户都没有时生效，ref 必须原样落到 default 账户上。
  const fallback = resolveConnection({ apiKeyEnv: 'ARK_CODING_API_KEY' })
  check('an empty account list falls back to exactly one default apikey account',
    fallback.accounts.length === 1 && fallback.accounts[0].id === 'default'
    && fallback.accounts[0].type === 'apikey' && fallback.accounts[0].ref === 'ARK_CODING_API_KEY',
    JSON.stringify(fallback.accounts))
  const withAccounts = resolveConnection({ apiKeyEnv: 'ARK_CODING_API_KEY', accounts: [{ id: 'mine', apiKey: 'ark-literal-key' }] })
  check('a non-empty account list suppresses the fallback entirely',
    withAccounts.accounts.length === 1 && withAccounts.accounts[0].id === 'mine', JSON.stringify(withAccounts.accounts.map((a) => a.id)))
  const disabled = resolveConnection({ apiKeyEnv: '', accounts: [] })
  check("apiKeyEnv: '' disables the fallback account", disabled.accounts.length === 0)
  const duplicated = describeAccounts({ accounts: [{ id: 'dup', apiKey: 'ark-one' }, { id: 'dup', apiKey: 'ark-two' }] })
  check('a duplicated account id keeps only the first row',
    duplicated.length === 1 && duplicated[0].literal === 'ark-one', JSON.stringify(duplicated.map((a) => a.id)))
}

{
  // 账户 ref 名含 `-`（不合凭据 ref 文法）时不能抛；启动环境里有同名变量就该兜底取到。
  //
  // 假实现的形状必须忠实：真实 harness 的 `launchEnvironmentOf(ctx).get(name)` 返回的是
  // `{value, source, path?}` **条目对象**，不是字符串。这里曾经注入"返回字符串"的假实现，
  // 结果把一个真实缺陷（按字符串判空 → 兜底永不生效）钉成了"通过"，是典型的 mock 失真。
  const AMBIENT = 'MY-KEY'
  const ambientCtx = {
    get: (key) => (key === 'launchEnvironment'
      ? { get: (name) => (name === AMBIENT ? { value: 'ark-ambient-fallback-key', source: 'process' } : undefined) }
      : undefined),
  }
  const ambientAdapter = new ArkCodingAdapter({ config: () => ({}), ctx: () => ambientCtx, attachments: () => undefined })
  const resolved = await ambientAdapter.resolveRef(AMBIENT, undefined)
  check('a dashed account ref still resolves through the launching environment',
    resolved === 'ark-ambient-fallback-key', String(resolved))
  const accounts = await ambientAdapter.resolveAccounts({
    accounts: [{ id: 'amb', label: 'amb', type: 'apikey', ref: AMBIENT, literal: undefined }],
    activeAccount: '',
  })
  check('resolveAccounts uses the ambient fallback for a dashed ref',
    accounts.length === 1 && accounts[0].key === 'ark-ambient-fallback-key', JSON.stringify(accounts.map((a) => a.key)))

  const states = await new ArkCodingAdapter({
    config: () => ({ accounts: [{ id: 'amb', label: 'amb', type: 'apikey', apiKeyEnv: AMBIENT }] }),
    ctx: () => ambientCtx,
    attachments: () => undefined,
  }).accountStates()
  check('accountStates reports a dashed ref as configured from the environment',
    states.length === 1 && states[0].configured === true && states[0].source === 'env', JSON.stringify(states))
}

{
  // 真实形状回归：直接用 harness 自己的 `createLaunchEnvironmentSnapshot`。
  // 以前 `index.js` 把条目当字符串判空，于是这条兜底**永不生效** —— headless profile
  // （没有凭据服务）里 export 的 `ARK_CODING_API_KEY`、以及含 `-` 的 ref 全部拿不到 key，
  // 用户只看到"账户都还没有可用的 API key"。一方适配器用的是 `.get(name)?.value`。
  const { createLaunchEnvironmentSnapshot } = await import('@deepseek-ai/dsh-launch-environment')
  const snapshot = createLaunchEnvironmentSnapshot([{ source: 'process', values: { 'MY-KEY': 'ark-real-shape-key' } }])
  const realCtx = {
    get: (key) => (key === 'launchEnvironment' ? snapshot : undefined),
  }
  const realAdapter = new ArkCodingAdapter({ config: () => ({}), ctx: () => realCtx, attachments: () => undefined })
  check('the ambient fallback reads the real {value, source} launch-environment entry',
    (await realAdapter.resolveRef('MY-KEY', undefined)) === 'ark-real-shape-key')

  // 同一个修复的另一半：accountStates 也按条目读，否则设置页会把一个"其实能用"的
  // 环境变量账户显示成未配置。
  const realStates = await new ArkCodingAdapter({
    config: () => ({ accounts: [{ id: 'amb', label: 'amb', type: 'apikey', apiKeyEnv: 'MY-KEY' }] }),
    ctx: () => realCtx,
    attachments: () => undefined,
  }).accountStates()
  check('accountStates marks a real-shape ambient ref as configured from the environment',
    realStates.length === 1 && realStates[0].configured === true && realStates[0].source === 'env',
    JSON.stringify(realStates))
}

// ---------------------------------------------------------------------------
// A11. 宿主 / 客户端端点契约逐一对齐（删掉或改名一个端点必须变红）
// ---------------------------------------------------------------------------
const EXPECTED_ENDPOINTS = ['report', 'cliStatus', 'cliInstall', 'catalogRefresh', 'loginBegin', 'loginPoll', 'loginSubmit', 'loginCancel']
const descriptors = USAGE_CLIENT_CONTRIBUTION.descriptors
check('the host contribution exposes exactly the eight pinned endpoints in order',
  descriptors.map((descriptor) => descriptor.method).join(',') === EXPECTED_ENDPOINTS.join(','),
  descriptors.map((descriptor) => descriptor.method).join(','))
check('every host descriptor carries the pinned id/service/namespace/method',
  descriptors.every((descriptor) => descriptor.id === `dsh-ark-coding-provider#arkcoding/${descriptor.method}`
    && descriptor.service === 'arkCodingUsage' && descriptor.namespace === 'arkcoding'
    && descriptor.invocation.kind === 'direct'),
  JSON.stringify(descriptors.map((descriptor) => descriptor.id)))
check('plain endpoints take no argument and action endpoints take one strict `input`',
  [USAGE_REPORT_DESCRIPTOR, CLI_STATUS_DESCRIPTOR, CLI_INSTALL_DESCRIPTOR, CATALOG_REFRESH_DESCRIPTOR].every((d) => d.parameters.length === 0)
  && [LOGIN_BEGIN_DESCRIPTOR, LOGIN_POLL_DESCRIPTOR, LOGIN_SUBMIT_DESCRIPTOR, LOGIN_CANCEL_DESCRIPTOR].every((d) => d.parameters.length === 1
    && d.parameters[0].name === 'input' && d.parameters[0].wire === 'input' && d.parameters[0].source === 'json'
    && d.parameters[0].codec.mode === 'strict'))

// 客户端那半在自己源码里列了同一组方法名：两边必须一字不差。
const clientSource = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
const clientDescriptorSequence = [...clientSource.matchAll(/descriptorOf\('(\w+)'/g)].map((match) => match[1])
check('the client bundle declares descriptors for the very same eight endpoints in the same order',
  clientDescriptorSequence.join(',') === EXPECTED_ENDPOINTS.join(','), clientDescriptorSequence.join(','))

// ---------------------------------------------------------------------------
// A12. 客户端 CATALOG 与宿主 MODELS 必须一一相等（重复真源也要交叉校验）
// ---------------------------------------------------------------------------
{
  const literal = /const CATALOG = (\[[\s\S]*?\n {4}\])/.exec(clientSource)?.[1]
  const clientCatalog = literal === undefined ? undefined : Function(`return ${literal}`)()
  check('the client-side CATALOG is parseable', Array.isArray(clientCatalog) && clientCatalog.length === 12, String(clientCatalog?.length))
  const mismatches = []
  for (const [index, model] of MODELS.entries()) {
    const row = clientCatalog?.[index]
    if (row === undefined
      || row.id !== model.id || row.name !== model.name || row.family !== model.family
      || row.ctx !== model.contextWindow || row.out !== model.maxOutput
      || JSON.stringify(row.input) !== JSON.stringify(model.input)) {
      mismatches.push(`${model.id}: host=${JSON.stringify([model.name, model.family, model.contextWindow, model.maxOutput, model.input])} client=${JSON.stringify(row)}`)
    }
  }
  check('the client catalog mirrors host models id/name/family/ctx/out/modalities one-for-one',
    mismatches.length === 0, mismatches.slice(0, 3).join(' | '))
}

// ---------------------------------------------------------------------------
// B. 经真实 cordis Context 驱动 apply()：接线、HOME 校验、缓存键、在途去重
// ---------------------------------------------------------------------------

/**
 * 用真实 cordis Context 起一个插件实例。
 *
 * 为什么用真的：`apply()` 的内部逻辑（缓存键、在途去重、HOME 校验）全在闭包里，
 * 假 ctx 拿不到 deps；真 Context 会把 `ArkCodingUsageService` 注册成服务，
 * `ctx.get('arkCodingUsage').deps` 就是那份闭包里的 deps。
 */
async function bootstrap(config, options = {}) {
  const ctx = new Context()
  const registered = { adapters: [], providers: [], discoveries: [] }
  const settingsCalls = []
  const typertRegs = []
  ctx.provide('llm', {
    registerAdapter: (routes, adapter) => registered.adapters.push([routes, adapter]),
    registerConfigurableProviders: (entries) => registered.providers.push(entries),
    registerModelDiscovery: (ns, fn) => registered.discoveries.push([ns, fn]),
  })
  if (options.settings !== false) {
    ctx.provide('settings', { configure: (value) => { settingsCalls.push(value); return () => {} } })
  }
  ctx.provide('typert', { register: (spec) => { typertRegs.push(spec); return () => {} } })
  apply(ctx, config)
  await step(25)
  const service = ctx.get('arkCodingUsage')
  return {
    ctx,
    registered,
    settingsCalls,
    typertRegs,
    service,
    deps: service?.deps,
    adapter: registered.adapters[0]?.[1],
  }
}

{
  const boot = await bootstrap({ accounts: [] })
  check('apply() turns off the auto-generated settings page',
    boot.settingsCalls.some((value) => value?.auto === false), JSON.stringify(boot.settingsCalls))
  check('apply() registers the adapter, the configurable provider and model discovery',
    boot.registered.adapters.length === 1 && boot.registered.adapters[0][0][0] === PROVIDER
    && boot.registered.providers[0]?.[0]?.settingsNs === 'llm-ark-coding'
    && boot.registered.discoveries[0]?.[0] === 'llm-ark-coding')
  check('apply() registers the eight endpoints with typert and exposes its deps',
    boot.typertRegs.length === 1 && boot.typertRegs[0].invocations.length === 8
    && typeof boot.deps?.report === 'function',
    JSON.stringify(boot.typertRegs[0]?.invocations?.map((d) => d.method)))
}

{
  // Windows 桌面端（Electron Node 模式）**不会设置 DSH_HOME**：插件必须像 DSH 自己
  // 那样退回 ~/.dsh。以前只看环境变量，桌面端一进设置页就是
  // 「没有 DSH_HOME，无法确定安装目录」—— 装 arkcli、CLI 账户全废。
  const saved = process.env.DSH_HOME
  delete process.env.DSH_HOME
  try {
    const resolved = host.resolveDshHomePath()
    check('the plugin resolves $DSH_HOME -> ~/.dsh exactly like the harness does',
      resolved === join(homedir(), '.dsh'), String(resolved))
  } finally {
    process.env.DSH_HOME = saved ?? tempRoot
  }
  check('the test restores its own DSH_HOME after the desktop check', process.env.DSH_HOME === tempRoot)
}

{
  // 桌面端的等价场景：`apply()` 在 DSH_HOME 缺失时也要有状态根，且与 DSH 的
  // `~/.dsh` 完全一致（账户 home 的越界校验以它为根）。用一次越界 home 触发校验，
  // 不会真的起子进程、也不会写盘。
  const saved = process.env.DSH_HOME
  delete process.env.DSH_HOME
  let boot
  try {
    boot = await bootstrap({ arkcliPath: '/nonexistent/arkcli', accounts: [{ id: 'x', type: 'cli', home: '/etc' }] })
  } finally {
    process.env.DSH_HOME = saved ?? tempRoot
  }
  let outcome
  try {
    outcome = await boot.deps.loginBegin({ accountId: 'x' })
  } catch (error) {
    outcome = { threw: String(error?.message ?? error) }
  }
  const desktopRoot = join(homedir(), '.dsh', 'ark-coding')
  check('without DSH_HOME, apply() still roots every account under ~/.dsh/ark-coding',
    /home 必须位于/.test(outcome.threw ?? '') && (outcome.threw ?? '').includes(desktopRoot), outcome.threw)
}

{
  // arkcliPath 必须真的传进 ArkCli：配置指向一个存在的可执行文件时 source 必须是 'config'。
  // 用 process.execPath（node）当假 arkcli：它 --version 输出 vX.Y.Z，status 能解析出版本。
  const boot = await bootstrap({ arkcliPath: process.execPath, accounts: [] })
  const status = await boot.deps.cliStatus()
  check('the configured arkcliPath is really handed to ArkCli (status.source === config)',
    status.installed === true && status.source === 'config' && status.path === process.execPath,
    JSON.stringify(status))
}

{
  // 账户 HOME 校验：显式 home 必须落在 <DSH_HOME>/ark-coding 之下。
  const cases = [
    ['/etc', false],
    ['../../etc', false],
    [`${STATE_ROOT}/../..`, false],
    [`${STATE_ROOT}/accounts/ok`, true],
  ]
  for (const [home, accepted] of cases) {
    const boot = await bootstrap({ arkcliPath: '/nonexistent/arkcli', accounts: [{ id: 'x', type: 'cli', home }] })
    let outcome
    try {
      outcome = await boot.deps.loginBegin({ accountId: 'x' })
    } catch (error) {
      outcome = { threw: String(error?.message ?? error) }
    }
    if (accepted) {
      // 校验通过后它会去找 arkcli；找不到就如实报找不到 —— 但绝不是 HOME 越界。
      check(`an explicit home under the state root is accepted (${home})`,
        outcome?.threw === undefined && /找不到 arkcli/.test(outcome?.error ?? ''), JSON.stringify(outcome))
    } else {
      check(`an explicit home outside the state root is refused (${home})`,
        /必须位于/.test(outcome?.threw ?? outcome?.error ?? ''), JSON.stringify(outcome))
    }
  }
}

{
  // 派生缓存键必须包含 home/ref：只按 id 缓存的话，删掉重建/改 home 会继续用旧账户。
  const calls = []
  const original = ArkCli.prototype.profileApiKey
  ArkCli.prototype.profileApiKey = async function profileApiKey() {
    calls.push(1)
    return { ok: true, apiKey: 'ark-cached-key-123456' }
  }
  try {
    const boot = await bootstrap({ arkcliPath: '/nonexistent/arkcli', accounts: [{ id: 'c1', type: 'cli', home: `${STATE_ROOT}/a` }] })
    const connection = (home, ref) => ({
      accounts: [{ id: 'c1', label: 'c1', type: 'cli', home, ref, literal: undefined }],
      activeAccount: '',
    })
    await boot.adapter.resolveAccounts(connection(`${STATE_ROOT}/a`, 'REF_ONE'))
    await boot.adapter.resolveAccounts(connection(`${STATE_ROOT}/b`, 'REF_ONE'))
    await boot.adapter.resolveAccounts(connection(`${STATE_ROOT}/b`, 'REF_TWO'))
    await boot.adapter.resolveAccounts(connection(`${STATE_ROOT}/b`, 'REF_TWO'))
    check('derived account caches are keyed by home and ref, not just the account id',
      calls.length === 3, `${calls.length} profileApiKey calls`)
  } finally {
    ArkCli.prototype.profileApiKey = original
  }
}

{
  // 在途去重：并发两次 catalogRefresh / report 只能各起一次子进程。
  const counts = { models: 0, plan: 0 }
  const originals = {
    modelsSearch: ArkCli.prototype.modelsSearch,
    usagePlan: ArkCli.prototype.usagePlan,
    authStatus: ArkCli.prototype.authStatus,
    whoami: ArkCli.prototype.whoami,
  }
  ArkCli.prototype.modelsSearch = async function modelsSearch() {
    counts.models += 1
    return { ok: true, items: [], updatedAt: undefined }
  }
  ArkCli.prototype.usagePlan = async function usagePlan() {
    counts.plan += 1
    return { ok: true, viewer: { user_name: 'n' }, items: [] }
  }
  ArkCli.prototype.authStatus = async function authStatus() {
    return { ok: true, loggedIn: true, authMethod: 'sso' }
  }
  ArkCli.prototype.whoami = async function whoami() {
    return { ok: true, userId: 'u-1', userName: 'n' }
  }
  try {
    const boot = await bootstrap({ arkcliPath: process.execPath, accounts: [{ id: 'c1', type: 'cli' }] })
    const [first, second] = await Promise.all([boot.deps.catalogRefresh(), boot.deps.catalogRefresh()])
    check('two concurrent catalog refreshes share a single arkcli models search',
      counts.models === 1 && first?.ok === true && second?.ok === true,
      JSON.stringify({ models: counts.models, ok: [first?.ok, second?.ok] }))
    await Promise.all([boot.deps.report(), boot.deps.report()])
    check('two concurrent report() calls share a single usage plan query',
      counts.plan === 1, String(counts.plan))
  } finally {
    for (const [key, value] of Object.entries(originals)) ArkCli.prototype[key] = value
  }
}

// --- 收尾 -------------------------------------------------------------------
if (originalDshHome === undefined) delete process.env.DSH_HOME
else process.env.DSH_HOME = originalDshHome
rmSync(tempRoot, { recursive: true, force: true })

console.log(failures === 0 ? '\nALL PASS' : `\n${failures} FAILURE(S)`)
if (issues.length > 0) console.log(`（另有 ${issues.length} 条 KNOWN-BUG，见上；不计入失败。）`)
process.exit(failures === 0 ? 0 : 1)
