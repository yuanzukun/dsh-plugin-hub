/**
 * 流式 chunk 的"无损 JSON"契约测试。
 *
 * 为什么单独一个文件：这条契约是**真机上炸过**的。DSH 在落地每一块流式内容前会跑
 * `snapshotJsonValue`（来自 `@deepseek-ai/dsh-util-values`），而 `{ foo: undefined }`
 * 这种显式 undefined 属性在 JSON 里表示不出来，会被判成不可无损序列化，直接抛
 * `Assistant stream chunk must be losslessly JSON-serializable`。后果不是丢一块，
 * 而是**整轮对话在最后一块上失败** —— 用户看到的是"字都打出来了，然后突然没了"。
 *
 * 这个测试不需要网络、也不需要密钥：`parseStream` 只要求传进来的东西有
 * `body.getReader()`，所以这里直接喂一段假 SSE。用**真**的 `isJsonValue` 校验，
 * 不自己重写一遍规则（重写就会和实现一起跑偏）。
 *
 * ⚠️ 它**依赖 harness 包**（`../index.js` 与 `@deepseek-ai/dsh-util-values`），
 * 直接 `node tests/stream.test.mjs` 会 `ERR_MODULE_NOT_FOUND`。请用
 * `node tests/run.mjs` 跑（它会在临时沙箱里建好 `node_modules` 符号链接）。
 * 万一真被直跑，下面会打印 SKIP 并以 0 退出 —— 这样 `node --test tests/` 不会假红。
 */
let ArkCodingAdapter
let withoutUndefined
let isJsonValue
try {
  ;({ ArkCodingAdapter, withoutUndefined } = await import('../index.js'))
  ;({ isJsonValue } = await import('@deepseek-ai/dsh-util-values'))
} catch (error) {
  console.log('SKIP  stream chunk contract suite needs the harness packages.')
  console.log('      运行方式：node tests/run.mjs（沙箱会补上 node_modules 符号链接）。')
  console.log(`      ${error?.code ?? error}`)
  console.log('\nALL PASS (skipped)')
  process.exit(0)
}

let failures = 0
const check = (name, ok, detail) => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail === undefined ? '' : ` — ${detail}`}`)
  if (!ok) failures += 1
}

/** 把若干 SSE 事件拼成一个假的 fetch Response（只需要 `body.getReader()`）。 */
function sseResponse(events) {
  const text = events.map((event) => `data: ${typeof event === 'string' ? event : JSON.stringify(event)}\n\n`).join('')
  const bytes = new TextEncoder().encode(`${text}data: [DONE]\n\n`)
  let sent = false
  return {
    body: {
      getReader() {
        return {
          async read() {
            if (sent) return { done: true, value: undefined }
            sent = true
            return { done: false, value: bytes }
          },
          async cancel() {},
        }
      },
    },
  }
}

const adapter = new ArkCodingAdapter({
  config: () => ({ apiKey: 'ark-unused-in-this-test' }),
  ctx: () => ({ get: () => undefined }),
  attachments: () => undefined,
})
const connection = { streamIdleTimeoutMs: 5000, requestTimeoutMs: 5000 }

async function collect(events) {
  const chunks = []
  for await (const chunk of adapter.parseStream(sseResponse(events), connection, { signal: undefined })) {
    chunks.push(chunk)
  }
  return chunks
}

const delta = (payload) => ({ choices: [{ delta: payload }] })

// --- 1. 最普通的文本回答：每一块都必须是无损 JSON --------------------------
const plain = await collect([
  delta({ role: 'assistant', content: '' }),
  delta({ content: '你好' }),
  delta({ content: '，世界' }),
  { choices: [{ delta: {}, finish_reason: 'stop' }], usage: { prompt_tokens: 10, completion_tokens: 4 } },
])
const badPlain = plain.filter((chunk) => !isJsonValue(chunk))
check('every chunk of a plain answer is lossless JSON',
  plain.length > 0 && badPlain.length === 0,
  badPlain.length === 0 ? `${plain.length} chunks` : JSON.stringify(badPlain).slice(0, 300))
check('a plain answer ends with a finish chunk',
  plain.at(-1)?.type === 'finish' && plain.at(-1)?.reason?.kind === 'stop', JSON.stringify(plain.at(-1)))
// 这就是真机炸掉的那一处：finish 块以前带着 `replayState: undefined`。
check('the finish chunk carries no explicitly-undefined key',
  plain.at(-1) !== undefined && !Object.prototype.hasOwnProperty.call(plain.at(-1), 'replayState'),
  JSON.stringify(Object.keys(plain.at(-1) ?? {})))

// --- 2. 思考 + 工具调用：字段更多的路径也必须干净 ---------------------------
const rich = await collect([
  delta({ reasoning_content: '让我想想…' }),
  delta({ content: '好的' }),
  delta({ tool_calls: [{ index: 0, id: 'call_1', function: { name: 'get_weather', arguments: '{"city":' } }] }),
  delta({ tool_calls: [{ index: 0, function: { arguments: '"Paris"}' } }] }),
  { choices: [{ delta: {}, finish_reason: 'tool_calls' }], usage: { prompt_tokens: 20, completion_tokens: 9, completion_tokens_details: { reasoning_tokens: 3 } } },
])
const badRich = rich.filter((chunk) => !isJsonValue(chunk))
check('every chunk of a reasoning + tool-call answer is lossless JSON',
  rich.length > 0 && badRich.length === 0,
  badRich.length === 0 ? `${rich.length} chunks` : JSON.stringify(badRich).slice(0, 300))
check('the tool-call block still lands with id/name/arguments',
  rich.some((c) => c.type === 'block-end' && c.block?.type === 'tool-call'
    && c.block.name === 'get_weather' && c.block.arguments === '{"city":"Paris"}'),
  JSON.stringify(rich.filter((c) => c.type === 'block-end').map((c) => c.block?.type)))

// --- 3. 兜底本身：显式 undefined 必须被摘掉 ---------------------------------
check('withoutUndefined drops explicit undefined keys',
  JSON.stringify(withoutUndefined({ type: 'finish', reason: 'stop', replayState: undefined })) === '{"type":"finish","reason":"stop"}')
check('withoutUndefined keeps null (null IS representable in JSON)',
  JSON.stringify(withoutUndefined({ a: null, b: 0, c: '', d: false })) === '{"a":null,"b":0,"c":"","d":false}')
check('withoutUndefined is what makes a poisoned chunk survivable',
  isJsonValue({ type: 'finish', reason: 'stop', replayState: undefined }) === false
  && isJsonValue(withoutUndefined({ type: 'finish', reason: 'stop', replayState: undefined })) === true)
check('withoutUndefined tolerates non-objects',
  withoutUndefined(undefined) === undefined && withoutUndefined('x') === 'x')

console.log(`\n${failures === 0 ? 'ALL PASS' : `${failures} FAILED`}`)
process.exit(failures === 0 ? 0 : 1)
