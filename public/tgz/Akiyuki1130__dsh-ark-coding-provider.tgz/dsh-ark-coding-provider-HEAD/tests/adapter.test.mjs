/**
 * 适配器独立测试：直接驱动 ArkCodingAdapter，验证
 *   1. 插件能否被导入、Config 能否解析
 *   2. listModels / resolveModel 的目录事实
 *   3. 真实 stream() 的 SSE 解析与 StreamChunk 契约
 *   4. 工具调用往返
 *   5. 图片投影（假附件服务）
 *
 * ⚠️ 这一套打**真实端点**，需要 `ARK_CODING_TEST_KEY`；它同时依赖 harness 包，
 * 所以要经 `node tests/run.mjs`（沙箱）跑。没密钥或没有 harness 包时它明确 SKIP
 * 并以 0 退出 —— 以前是 `throw` → 退出码 1，于是 `node --test tests/` 在没有密钥的
 * 任何环境里都会得到一次**假红**。
 */
const KEY = process.env.ARK_CODING_TEST_KEY
if (!KEY || KEY.trim() === '') {
  console.log('SKIP  adapter live-endpoint suite needs ARK_CODING_TEST_KEY (no key set).')
  console.log('      To run it: ARK_CODING_TEST_KEY=ark-... npm test')
  console.log('\nALL PASS (skipped)')
  process.exit(0)
}
// 用动态 import：没有 harness 包时也必须能走到上面/这里的 SKIP，而不是在模块
// 加载阶段就 ERR_MODULE_NOT_FOUND（静态 import 会在检查之前就抛）。
let index
let values
try {
  index = await import('../index.js')
  values = await import('@deepseek-ai/dsh-util-values')
} catch (error) {
  console.log('SKIP  adapter suite needs the harness packages; run it via node tests/run.mjs.')
  console.log(`      ${error?.code ?? error}`)
  console.log('\nALL PASS (skipped)')
  process.exit(0)
}
const { isJsonValue } = values
const {
  ArkCodingAdapter,
  CATALOG_REFRESH_DESCRIPTOR,
  CLI_INSTALL_DESCRIPTOR,
  CLI_STATUS_DESCRIPTOR,
  Config,
  LOGIN_BEGIN_DESCRIPTOR,
  LOGIN_CANCEL_DESCRIPTOR,
  LOGIN_POLL_DESCRIPTOR,
  LOGIN_SUBMIT_DESCRIPTOR,
  USAGE_CLIENT_CONTRIBUTION,
  USAGE_REPORT_DESCRIPTOR,
  apply,
  unwrapVolatileConfig,
} = index

// 注意：账户只有 `accounts` 一个真源了 —— 顶层 `apiKey` 不再被读取（没有默认账户）。
const config = {
  accounts: [{ id: 'main', label: 'test', type: 'apikey', apiKey: KEY }],
  apiBase: 'https://ark.cn-beijing.volces.com/api/coding/v3',
}
const adapter = new ArkCodingAdapter({
  config: () => config,
  ctx: () => ({ get: () => undefined }),
  attachments: () => undefined,
  imageUrl: undefined,
})

let failures = 0
const check = (name, ok, detail) => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail === undefined ? '' : ` — ${detail}`}`)
  if (!ok) failures += 1
}

// --- 1. Config schema -------------------------------------------------------
const parsed = new Config({
  apiKeyEnv: 'ARK_CODING_API_KEY',
  apiBase: 'https://ark.cn-beijing.volces.com/api/coding/v3',
  requestTimeoutMs: 1000,
  defaultMaxTokens: 1024,
})
// 易变字段在解析后被换成 { get() } 引用，插件每次读取都拆开它们。
const plain = unwrapVolatileConfig(parsed)
check('Config marks volatile fields as live references', typeof parsed.defaultMaxTokens?.get === 'function',
  typeof parsed.defaultMaxTokens)
check('Config parses and applies defaults', plain.defaultMaxTokens === 1024 && plain.streamIdleTimeoutMs === 300000,
  `defaultMaxTokens=${plain.defaultMaxTokens} streamIdle=${plain.streamIdleTimeoutMs}`)

// --- 2. catalog -------------------------------------------------------------
const models = await adapter.listModels('ark-coding')
check('listModels returns 12 models', models.length === 12, `got ${models.length}`)
const glm = await adapter.resolveModel('ark-coding', 'glm-5.3')
check('glm-5.3 is text-only', JSON.stringify(glm.inputModalities) === '["text"]', JSON.stringify(glm.inputModalities))
check('glm-5.3 has no off effort', !glm.reasoning.efforts.some((e) => e.id === 'off'),
  glm.reasoning.efforts.map((e) => e.id).join(','))
const ds = await adapter.resolveModel('ark-coding', 'deepseek-v4.1-flash')
check('deepseek-v4.1-flash context = 1M', ds.context.contextWindow === 1048576, String(ds.context.contextWindow))
check('defaultMaxTokens falls back to the plugin default', ds.defaultMaxTokens === 65536, String(ds.defaultMaxTokens))
// 夹具必须**越过**模型上限才会真的检验夹取：以前这里是 1024，而模型上限也是 131072，
// 两侧同为 1024 的断言是同义反复（把 min() 删掉也照样通过）。
const clampedAdapter = new ArkCodingAdapter({ config: () => ({ ...config, defaultMaxTokens: 200000 }), ctx: () => ({ get: () => undefined }), attachments: () => undefined })
const clamped = await clampedAdapter.resolveModel('ark-coding', 'kimi-k3')
check('defaultMaxTokens above the model ceiling is clamped down to maxOutput',
  clamped.defaultMaxTokens === 131072, String(clamped.defaultMaxTokens))
const clampedAbove = await clampedAdapter.resolveModel('ark-coding', 'deepseek-v4.1-flash')
check('a default below the model ceiling is left untouched',
  clampedAbove.defaultMaxTokens === 200000, String(clampedAbove.defaultMaxTokens))
const kimi = await adapter.resolveModel('ark-coding', 'kimi-k3')
check('kimi-k3 has image modality', kimi.inputModalities.includes('image'), JSON.stringify(kimi.inputModalities))
const unknown = await adapter.resolveModel('ark-coding', 'no-such-model')
check('unknown model still resolves', unknown.id === 'no-such-model' && unknown.context === undefined)

// --- 3. real streaming ------------------------------------------------------
/**
 * 生产路径上，DSH 会对每一块流式内容跑一次"无损 JSON"校验（`snapshotJsonValue`）。
 * 这里就用**真的**校验器 `isJsonValue` 跑一遍 —— 曾经 `finish` 块带着
 * `replayState: undefined`，于是整轮对话在最后一块上炸掉，用户看到的是
 * "字都打出来了，然后突然没了"。用假的 SSE 覆盖同一个契约在 `tests/stream.test.mjs`；
 * 这里覆盖的是**真实端点回来的每一块**。
 */
const jsonViolations = []
async function collect(options) {
  const chunks = []
  for await (const chunk of adapter.stream(options)) {
    if (!isJsonValue(chunk)) jsonViolations.push(chunk)
    chunks.push(chunk)
  }
  return chunks
}
function assembledText(chunks) {
  let text = ''
  for (const chunk of chunks) if (chunk.type === 'block-end' && chunk.block.type === 'text') text += chunk.block.text
  return text
}

const chunks = await collect({
  provider: 'ark-coding',
  model: 'doubao-seed-2.0-mini',
  messages: [{ role: 'user', content: [{ type: 'text', text: 'Reply with exactly: PONG' }] }],
  maxTokens: 512,
})
const finish = chunks.at(-1)
check('stream ends with a finish chunk', finish?.type === 'finish', finish?.type)
check('stream produced text', assembledText(chunks).toUpperCase().includes('PONG'), JSON.stringify(assembledText(chunks).slice(0, 60)))
const usage = chunks.find((c) => c.type === 'usage')
check('usage precedes finish and is disjoint', usage !== undefined && usage.usage.inputTokens >= 0 && usage.usage.outputTokens > 0,
  JSON.stringify(usage?.usage))
check('reasoning delta surfaced', chunks.some((c) => c.type === 'reasoning-delta') || usage?.usage.reasoningTokens === 0,
  `reasoningTokens=${usage?.usage.reasoningTokens}`)
check('every chunk of a real stream is losslessly JSON-serializable',
  jsonViolations.length === 0,
  jsonViolations.length === 0 ? `${chunks.length} chunks` : JSON.stringify(jsonViolations).slice(0, 300))

// --- 4. tool calling round trip --------------------------------------------
const toolChunks = await collect({
  provider: 'ark-coding',
  model: 'doubao-seed-2.0-mini',
  messages: [{ role: 'user', content: [{ type: 'text', text: 'What is the weather in Paris? Use get_weather.' }] }],
  tools: [{ name: 'get_weather', description: 'Get weather', parameters: { type: 'object', properties: { city: { type: 'string' } }, required: ['city'] } }],
  maxTokens: 512,
})
const toolBlock = toolChunks.filter((c) => c.type === 'block-end' && c.block.type === 'tool-call').map((c) => c.block)
check('tool call emitted', toolBlock.length === 1, JSON.stringify(toolBlock[0] ?? null))
check('tool arguments are raw JSON', (() => { try { JSON.parse(toolBlock[0]?.arguments ?? ''); return true } catch { return false } })(), toolBlock[0]?.arguments)

// 第二轮：把 tool-call 作为 assistant 历史回灌，验证 type 被强制成 function
const callId = toolBlock[0]?.id
if (callId !== undefined) {
  const second = await collect({
    provider: 'ark-coding',
    model: 'doubao-seed-2.0-mini',
    messages: [
      { role: 'user', content: [{ type: 'text', text: 'What is the weather in Paris? Use get_weather.' }] },
      { role: 'assistant', content: [], source: { kind: 'model', provider: 'ark-coding', model: 'doubao-seed-2.0-mini' }, id: 'm1', toolCalls: undefined,
        ...{ content: [{ type: 'tool-call', id: callId, name: toolBlock[0].name, arguments: toolBlock[0].arguments }] } },
      { role: 'tool', id: 'm2', source: { kind: 'tool', callId }, content: [{ type: 'text', text: '22C and sunny' }] },
    ],
    tools: [{ name: 'get_weather', description: 'Get weather', parameters: { type: 'object', properties: { city: { type: 'string' } }, required: ['city'] } }],
    maxTokens: 512,
  })
  check('tool round trip answers', /22/.test(assembledText(second)), JSON.stringify(assembledText(second).slice(0, 80)))
}

// --- 5. image projection ----------------------------------------------------
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAJUlEQVR42mP8z8Dwn4GBgYGJgYGBgYGBgYGBgYGBgYGBgYGBAQBmBgYBv8kJLwAAAABJRU5ErkJggg==', 'base64')
const fakeAttachments = {
  async readImageRequest(ref, target) {
    return { attachment: ref, data: PNG, mediaType: 'image/png', bytes: PNG.length, width: 8, height: 8, variantId: 'v1', depth: 'uchar', space: 'srgb', hasAlpha: false }
  },
}
const imageAdapter = new ArkCodingAdapter({ config: () => config, ctx: () => ({ get: () => undefined }), attachments: () => fakeAttachments, imageUrl: undefined })
const imageChunks = []
let imageError
try {
  for await (const chunk of imageAdapter.stream({
    provider: 'ark-coding',
    model: 'doubao-seed-2.0-mini',
    messages: [{ role: 'user', content: [{ type: 'text', text: 'What color?' }, { type: 'image', attachment: { attachmentId: 'a1', mediaType: 'image/png', bytes: PNG.length, width: 8, height: 8 } }] }],
    maxTokens: 256,
  })) imageChunks.push(chunk)
} catch (error) {
  imageError = error
}
// 8x8 太小，方舟会以 InvalidParameter 拒绝 —— 关键是它证明请求里确实带了 image_url。
check('image reaches the wire', imageError !== undefined && /dimension|image/i.test(imageError.message), imageError?.message?.slice(0, 120) ?? JSON.stringify(assembledText(imageChunks).slice(0, 60)))

// --- 6. missing credential --------------------------------------------------
// 没有账户（也不再会凭空变出一个默认账户）。
const noKey = new ArkCodingAdapter({ config: () => ({ apiKeyEnv: 'ARK_CODING_API_KEY' }), ctx: () => ({ get: () => undefined }), attachments: () => undefined })
let missingCode, missingMessage
try { for await (const _ of noKey.stream({ provider: 'ark-coding', model: 'kimi-k3', messages: [] })) { /* noop */ } } catch (error) { missingCode = error.code; missingMessage = error.message }
check('missing credential gives MISSING_CREDENTIAL', missingCode === 'MISSING_CREDENTIAL', String(missingCode))
check('the no-account error points at the actual fix (add an account)',
  typeof missingMessage === 'string' && missingMessage.includes('添加账户'), String(missingMessage).slice(0, 120))

// 有账户但 key 解析不出来：必须是另一句话，而不是复用"没有账户"。
const unconfigured = new ArkCodingAdapter({
  config: () => ({ accounts: [{ id: 'x', label: 'x', type: 'apikey', apiKeyEnv: 'ARK_CODING_KEY_THAT_IS_NOT_SET' }] }),
  ctx: () => ({ get: () => undefined }),
  attachments: () => undefined,
})
let unconfiguredCode, unconfiguredMessage
try { for await (const _ of unconfigured.stream({ provider: 'ark-coding', model: 'kimi-k3', messages: [] })) { /* noop */ } } catch (error) { unconfiguredCode = error.code; unconfiguredMessage = error.message }
check('an unconfigured account reports MISSING_CREDENTIAL with its own wording',
  unconfiguredCode === 'MISSING_CREDENTIAL' && typeof unconfiguredMessage === 'string'
  && !unconfiguredMessage.includes('添加账户') && unconfiguredMessage.includes('登录'),
  String(unconfiguredMessage).slice(0, 140))

// --- 7. apply() wiring ------------------------------------------------------
const registered = { adapters: [], providers: [], discoveries: [], remotes: [], injections: [] }
const fakeCtx = {
  get: () => undefined,
  logger: { info: () => {}, warn: () => {} },
  llm: {
    registerAdapter: (routes, a) => registered.adapters.push([routes, a]),
    registerConfigurableProviders: (entries) => registered.providers.push(entries),
    registerModelDiscovery: (ns, fn) => registered.discoveries.push([ns, fn]),
  },
  // 用量 Remote 走 ctx.inject(['typert'])。这里**故意不**回调：
  // 真正的 TypertRemoteService 必须在真 cordis Context 上构造，假上下文构造不了。
  // 于是这里覆盖的是「没有 typert 的 profile 也不会崩」，Remote 的注册由实机验证。
  inject: (services, callback) => { registered.injections.push(services.join(',')) },
}
apply(fakeCtx, config)
check('apply registers the ark-coding adapter', registered.adapters.length === 1 && registered.adapters[0][0][0] === 'ark-coding')
check('apply registers the configurable provider', registered.providers[0]?.[0]?.settingsNs === 'llm-ark-coding', JSON.stringify(registered.providers[0]?.[0]))
check('apply registers model discovery for the namespace', registered.discoveries[0]?.[0] === 'llm-ark-coding')

check('apply asks for the typert service for its usage remote',
  registered.injections.includes('typert'), registered.injections.join(' | '))
check('apply survives a profile without typert',
  registered.adapters.length === 1 && registered.providers.length === 1 && registered.discoveries.length === 1)
check('the usage descriptor is well formed',
  USAGE_REPORT_DESCRIPTOR.service === 'arkCodingUsage'
  && USAGE_REPORT_DESCRIPTOR.namespace === 'arkcoding'
  && USAGE_REPORT_DESCRIPTOR.method === 'report'
  && USAGE_REPORT_DESCRIPTOR.parameters.length === 0
  && USAGE_REPORT_DESCRIPTOR.result.mode === 'strict'
  && typeof USAGE_REPORT_DESCRIPTOR.result.create().parse === 'function',
  JSON.stringify({ id: USAGE_REPORT_DESCRIPTOR.id, service: USAGE_REPORT_DESCRIPTOR.service }))

// 描述符表就是宿主与浏览器之间的契约：方法名、参数个数、命名空间任何一处不一致，
// 界面都会静默失败（浏览器代理按描述符发请求，网关按描述符做严格参数检查）。
// 客户端那半是自己写的副本，所以这里把宿主这份钉住。
const EXPECTED_METHODS = ['report', 'cliStatus', 'cliInstall', 'catalogRefresh', 'loginBegin', 'loginPoll', 'loginSubmit', 'loginCancel']
check('the contribution exposes exactly the eight endpoints the UI calls',
  USAGE_CLIENT_CONTRIBUTION.descriptors.map((d) => d.method).join(',') === EXPECTED_METHODS.join(','),
  USAGE_CLIENT_CONTRIBUTION.descriptors.map((d) => d.method).join(','))
check('every endpoint lives in the arkcoding namespace on the arkCodingUsage service',
  USAGE_CLIENT_CONTRIBUTION.descriptors.every((d) => d.namespace === 'arkcoding' && d.service === 'arkCodingUsage' && d.invocation.kind === 'direct'))
check('plain endpoints take no arguments',
  [USAGE_REPORT_DESCRIPTOR, CLI_STATUS_DESCRIPTOR, CLI_INSTALL_DESCRIPTOR, CATALOG_REFRESH_DESCRIPTOR]
    .every((d) => d.parameters.length === 0))
check('action endpoints take exactly one untyped `input` argument',
  [LOGIN_BEGIN_DESCRIPTOR, LOGIN_POLL_DESCRIPTOR, LOGIN_SUBMIT_DESCRIPTOR, LOGIN_CANCEL_DESCRIPTOR].every((d) => d.parameters.length === 1
    && d.parameters[0].name === 'input' && d.parameters[0].wire === 'input'
    && d.parameters[0].source === 'json'))
// 客户端的贡献校验**只收 strict codec**。用协议里那个 `{ mode: 'src-json' }`（宿主网关
// 内部自己就用它）会让整个 `$mount` 抛 `field "input" has no strict codec`，代价是八个
// 端点全部失效、侧边栏永远停在 Loading —— 真机上踩过一次，所以这里把"必须是 strict"
// 钉死在测试里。strict 的 create() 依然可以返回一个恒真的宽松解析器。
check('every parameter declares a strict codec (the client rejects src-json)',
  USAGE_CLIENT_CONTRIBUTION.descriptors.every((d) => d.parameters.every((parameter) => parameter.codec.mode === 'strict'
    && typeof parameter.codec.typeSymbol === 'string'
    && typeof parameter.codec.create === 'function')))
check('a strict parameter codec accepts a plain object and rejects non-objects',
  (() => {
    const codec = LOGIN_BEGIN_DESCRIPTOR.parameters[0].codec.create()
    let accepted = false
    let rejected = false
    try { codec.parse({ accountId: 'x' }); accepted = true } catch { /* 不该发生 */ }
    try { codec.parse('nope') } catch { rejected = true }
    return accepted && rejected
  })())
check('descriptor ids are globally unique and namespaced',
  new Set(USAGE_CLIENT_CONTRIBUTION.descriptors.map((d) => d.id)).size === EXPECTED_METHODS.length
  && USAGE_CLIENT_CONTRIBUTION.descriptors.every((d) => d.id === `dsh-ark-coding-provider#arkcoding/${d.method}`))
check('the client contribution mirrors the descriptor',
  USAGE_CLIENT_CONTRIBUTION.package === 'dsh-ark-coding-provider'
  && USAGE_CLIENT_CONTRIBUTION.descriptors[0].id === USAGE_REPORT_DESCRIPTOR.id)
check('the result schema rejects a non-object',
  (() => { try { USAGE_REPORT_DESCRIPTOR.result.create().parse(null); return false } catch { return true } })())

// --- 多账户轮换：第 1 个账号是坏 key，应当自动切到第 2 个并成功 --------------
// 注意：accounts 非空时它就是账户的**唯一真源**，顶层的 apiKey 不再参与，
// 所以坏 key 也必须写在 accounts 里。
const rotator = new ArkCodingAdapter({
  config: () => ({
    accounts: [
      { id: 'bad', label: '坏 key', apiKey: 'ark-bogus-key-that-will-be-rejected' },
      { id: 'good', label: '备用', apiKey: KEY },
    ],
    apiBase: config.apiBase,
  }),
  ctx: () => ({ get: () => undefined }),
  attachments: () => undefined,
  logger: { warn: () => {} },
})
let rotatedText = ''
let rotatedError
try {
  for await (const chunk of rotator.stream({
    provider: 'ark-coding',
    model: 'doubao-seed-2.0-mini',
    messages: [{ role: 'user', content: [{ type: 'text', text: 'Reply with exactly: ROTATED' }] }],
    maxTokens: 512,
  })) {
    if (chunk.type === 'block-end' && chunk.block.type === 'text') rotatedText += chunk.block.text
  }
} catch (error) {
  rotatedError = error
}
check('a rejected first account rotates to the next and still answers',
  rotatedText.toUpperCase().includes('ROTATED'),
  rotatedError === undefined ? JSON.stringify(rotatedText.slice(0, 60)) : `${rotatedError.code}: ${rotatedError.message}`.slice(0, 140))

// 两个账号都是坏 key：应当把 AUTH 原样抛出，而不是静默成功或死循环
const doomed = new ArkCodingAdapter({
  config: () => ({
    accounts: [
      { id: 'bad-1', label: 'also bad', apiKey: 'ark-bogus-1' },
      { id: 'bad-2', label: 'still bad', apiKey: 'ark-bogus-2' },
    ],
    apiBase: config.apiBase,
  }),
  ctx: () => ({ get: () => undefined }),
  attachments: () => undefined,
  logger: { warn: () => {} },
})
let doomCode
try {
  for await (const _ of doomed.stream({ provider: 'ark-coding', model: 'doubao-seed-2.0-mini', messages: [{ role: 'user', content: [{ type: 'text', text: 'hi' }] }], maxTokens: 16 })) { /* noop */ }
} catch (error) { doomCode = error.code }
check('all accounts failing surfaces AUTH (no silent success)', doomCode === 'AUTH', String(doomCode))

// 真的跑一次 discovery，证明「测试连接」这条路是通的
const discovered = await registered.discoveries[0][1]({ baseURL: config.apiBase, apiKey: KEY })
check('discovery validates the key and returns the catalog', discovered.length === 12, `got ${discovered.length}`)

// 收口：本文件里跑过的**每一次**真实流式请求，每一块都必须是无损 JSON。
// 上面那条 check 只盯第一次；这条盯全部（含工具调用、图片、轮换等各条路径）。
check('no chunk from ANY real stream in this suite violates the lossless-JSON rule',
  jsonViolations.length === 0,
  jsonViolations.length === 0 ? 'all streams clean' : JSON.stringify(jsonViolations).slice(0, 300))

console.log(failures === 0 ? '\nALL PASS' : `\n${failures} FAILURE(S)`)
process.exit(failures === 0 ? 0 : 1)
