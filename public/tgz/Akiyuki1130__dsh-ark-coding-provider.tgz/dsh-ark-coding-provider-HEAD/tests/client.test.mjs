/**
 * 客户端半边的逻辑测试。
 *
 * 在假浏览器里求值 `window.__ModuleLoader__.load(...)` 的工厂，用假 cordis 上下文驱动它，
 * 递归渲染注册到的组件，最后走一遍真正的密钥读写、"暂存后保存"以及
 * 添加账户 / CLI 登录向导 / 官方目录对照 / arkcli 安装这些新路径。
 *
 * 假上下文刻意**忠实地模拟 cordis 的注入守卫**：每个注入上下文只暴露自己声明的
 * 远端命名空间，读别的会抛 `cannot get property "X" without inject`。
 * 这正是真机上"凭据服务未挂载"的成因 —— 如果假上下文什么都给，这个 bug 就测不出来。
 *
 * 假 `remote.arkcoding` 也照契约 §1 收**恰好一个对象参数**：多传/少传在宿主会被
 * Gateway 的精确参数检查拒掉，所以这里的桩会记下实参形状。
 */
import { readFileSync } from 'node:fs'

let failures = 0
const check = (name, ok, detail) => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail === undefined ? '' : ` — ${detail}`}`)
  if (!ok) failures += 1
}
const flush = () => new Promise((resolve) => setTimeout(resolve, 0))

// --- 最小 React 钩子运行时 --------------------------------------------------
let hookCursor = 0
const hookSlots = []
function resetHooks() { hookCursor = 0; hookSlots.length = 0 }
/** 只归零游标、**保留槽位**：跨两次渲染读同一个 state 时才用得上。 */
function resetCursor() { hookCursor = 0 }
let statefulHooks = false
function nextSlot(init) {
  const i = hookCursor++
  if (!(i in hookSlots)) hookSlots[i] = init
  return hookSlots[i]
}
/**
 * 假 `useEffect` 的三条纪律（旧实现三条都违反）：
 *  1. **收集到队列、渲染全部结束后统一执行** —— 旧实现边渲染边同步执行，效果会在
 *     子树还没渲染出来时就看到半成品状态；
 *  2. **cleanup 保留到卸载时才执行** —— 旧实现立刻调用 cleanup，于是"注册监听 →
 *     马上撤销"永远测不出真正的注册；
 *  3. **异常记录成失败** —— 旧实现 `catch {}` 把 effect 里的异常整个吞掉，
 *     真机上炸了离线还是全绿。
 */
const pendingEffects = []
const effectCleanups = []
const effectErrors = []
/** 渲染深度：只有最外层渲染结束（回到 0）才统一执行本轮的 effect。 */
let renderDepth = 0
function flushEffects() {
  for (const effect of pendingEffects.splice(0)) {
    try {
      const cleanup = effect()
      if (typeof cleanup === 'function') effectCleanups.push(cleanup)
    } catch (error) {
      effectErrors.push(error)
    }
  }
}
const React = {
  createElement(type, props, ...children) {
    return { type, props: { ...(props ?? {}), children: children.length <= 1 ? children[0] : children } }
  },
  useState: (init) => {
    const index = hookCursor++
    if (!(index in hookSlots)) hookSlots[index] = typeof init === 'function' ? init() : init
    // 默认是空 setter（绝大多数组件只需要读）。`statefulHooks` 打开后真的写回槽位，
    // 这是在离线环境里测试"点开详情面板"的唯一办法（没有真的事件循环）。
    return [hookSlots[index], (next) => {
      if (statefulHooks !== true) return
      hookSlots[index] = typeof next === 'function' ? next(hookSlots[index]) : next
    }]
  },
  useEffect: (fn) => { nextSlot(null); pendingEffects.push(fn) },
  useCallback: (fn) => { nextSlot(null); return fn },
  useMemo: (fn) => { nextSlot(null); return fn() },
  useRef: (init) => nextSlot({ current: init }),
  useSyncExternalStore: (_subscribe, get) => { nextSlot(null); return get() },
}

// --- 假 document / window ---------------------------------------------------
const styleTags = []
const document = {
  addEventListener: () => {}, removeEventListener: () => {},
  querySelector: (selector) => styleTags.find((tag) => tag.matches === selector) ?? null,
  createElement: () => ({ dataset: {}, textContent: '', remove() {} }),
  head: { appendChild(tag) { tag.matches = `style[data-plugin-css="${tag.dataset.pluginCss}"]`; styleTags.push(tag) } },
}
let captured
globalThis.window = { __ModuleLoader__: { load: (entry) => { captured = entry } }, innerHeight: 1000, addEventListener: () => {}, removeEventListener: () => {} }
globalThis.document = document

// --- 求值客户端 bundle ------------------------------------------------------
const source = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
new Function('window', 'document', source)(globalThis.window, document)
check('the client bundle registers itself under the package id', captured?.id === 'dsh-ark-coding-provider', String(captured?.id))

const moduleExports = captured.factory((specifier) => {
  if (specifier === 'react') return React
  throw new Error(`unexpected require: ${specifier}`)
})
check('the client module exports apply + inject', typeof moduleExports.apply === 'function' && Array.isArray(moduleExports.inject),
  JSON.stringify(moduleExports.inject))

// --- 远端命名空间的假实现（严格照真实契约） --------------------------------
let storedCredential
let storedSecret
const configuredRefs = new Set()
const credentialCalls = []
const mutateCalls = []
let settingsRevision = 3

/** 两个账户：一个 API Key（老配置迁移出来的 default），一个 CLI。 */
const INITIAL_ACCOUNTS = [
  { id: 'default', label: '', type: 'apikey', apiKeyEnv: 'ARK_CODING_API_KEY', home: '' },
  { id: 'acct-cli-1', label: '工作账号', type: 'cli', apiKeyEnv: '', home: '' },
]
const FALLBACK_ACCOUNTS = INITIAL_ACCOUNTS.map((account) => ({ ...account }))

let storedSettings = {
  apiBase: 'https://ark.cn-beijing.volces.com/api/coding/v3',
  modelVisibility: {},
  contextWindowOverrides: {},
  accounts: INITIAL_ACCOUNTS.map((account) => ({ ...account })),
}

/** describe 报告的可写性；只读态夹具会把它翻成 false。 */
let settingsWritable = true

/**
 * 假 `settings.mutate` 的按路径写入，**照真实 `dsh-settings` 的 `applyPathOp` 抄**。
 *
 * 真实的 `client.js` 现在依赖按路径最小写入（`{op:'set', path:['accounts', '0', 'label']}`、
 * `{op:'unset', path:['accounts', '1']}`）——**下标是字符串**，与 Typert 的 `path: string[]`
 * 线网 schema 一致：整数组回写会吞掉带 secret 角色的字面量密钥。
 * 旧的假实现只会 `{...storedSettings, [op.path[0]]: op.value}`，于是遇到数组下标就
 * `(storedSettings.accounts ?? []).find is not a function` —— 测试在骗人。
 *
 * 语义（对照 `dsh-settings/lib/index.js` 的 `applyPathOp`）：
 * - 数组下标必须是规范十进制；`index === length` 只在"路径到此为止且是 set"时合法；
 * - 数组下标上的 `unset` 是 **splice**（删元素，不是留空洞）；
 * - 对象路径的 `unset`（或 set 成 undefined）删掉该键；
 * - 根结果必须是普通对象。
 */
function applyPathOp(section, op) {
  // 线网 schema 是 `path: string[]`：数字下标会被 gateway 的边界校验直接拒掉
  // （`gateway/input-invalid`），根本到不了这里。假实现也必须这么严格，否则
  // 真实浏览器里点"保存"失败、离线测试却全绿。
  if (!Array.isArray(op.path) || op.path.some((segment) => typeof segment !== 'string')) {
    throw new TypeError('wire path segments must be strings')
  }
  const edit = (input, path) => {
    const [head, ...rest] = path
    if (head === undefined) return op.op === 'set' ? op.value : undefined
    const value = input
    if (Array.isArray(value)) {
      const numeric = typeof head === 'number' ? String(head) : head
      if (!/^(0|[1-9][0-9]*)$/.test(String(numeric)) || Number(numeric) > value.length
        || (Number(numeric) === value.length && (rest.length > 0 || op.op === 'unset'))) {
        throw new TypeError(`Config array index "${head}" is out of range`)
      }
      const result = [...value]
      const index = Number(numeric)
      if (rest.length === 0 && op.op === 'unset') result.splice(index, 1)
      else result[index] = edit(value[index], rest)
      return result
    }
    const result = typeof value === 'object' && value !== null && !Array.isArray(value) ? { ...value } : {}
    const child = edit(Object.hasOwn(result, head) ? result[head] : undefined, rest)
    if (child === undefined) delete result[head]
    else result[head] = child
    return result
  }
  const result = edit(section, op.path)
  if (typeof result !== 'object' || result === null || Array.isArray(result)) throw new TypeError('Config root must be a plain object')
  return result
}

function makeSettingsNamespace() {
  return {
    async describe() {
      return { ok: true, value: { writable: settingsWritable, namespaces: [{ ns: 'llm-ark-coding', value: storedSettings, revision: settingsRevision }] } }
    },
    async mutate(ns, ops, expected) {
      mutateCalls.push({ ns, ops, expected })
      if (ns !== 'llm-ark-coding') return { ok: false, error: { message: 'wrong ns' } }
      // CAS：revision 对不上就整体拒绝（真实实现抛 SettingsConflictError，什么都不写）。
      if (expected !== undefined && expected !== settingsRevision) {
        return { ok: false, error: { message: 'SETTINGS_CONFLICT', code: 'SETTINGS_CONFLICT' } }
      }
      let next = storedSettings
      try {
        for (const op of ops) next = applyPathOp(next, op)
      } catch (error) {
        return { ok: false, error: { message: error.message } }
      }
      storedSettings = next
      settingsRevision += 1
      return { ok: true, value: { ns, value: storedSettings, revision: settingsRevision } }
    },
  }
}

/**
 * credentials 远端：describe(**引用名数组**) → RemoteResult<Record<ref, CredentialInfo>>；
 * set/unset → RemoteResult<void>。传单个字符串或不解信封都拿不到东西。
 */
function makeCredentialsNamespace() {
  return {
    async describe(refs) {
      credentialCalls.push(['describe', refs])
      if (!Array.isArray(refs)) return { ok: false, error: { message: 'describe expects an array of refs' } }
      const value = {}
      for (const ref of refs) {
        const configured = configuredRefs.has(ref)
        value[ref] = { configured, source: configured ? 'file' : undefined, writable: true }
      }
      return { ok: true, value }
    },
    async set(ref, value) {
      credentialCalls.push(['set', ref])
      if (typeof ref !== 'string' || typeof value !== 'string' || value === '') return { ok: false, error: { message: 'bad set' } }
      if (ref === 'ARK_ACCESS_KEY_SECRET') storedSecret = value
      else storedCredential = value
      configuredRefs.add(ref)
      return { ok: true, value: undefined }
    },
    async unset(ref) {
      credentialCalls.push(['unset', ref])
      if (ref === 'ARK_ACCESS_KEY_SECRET') storedSecret = undefined
      else storedCredential = undefined
      configuredRefs.delete(ref)
      return { ok: true, value: undefined }
    },
  }
}

// --- 假报告（契约 §2 的新形状） --------------------------------------------

/**
 * 宿主的账户名规则（`accounts.js` 的 `defaultAccountLabel`）。
 *
 * `accounts` 为空数组就是"一个账户都没有" —— 宿主已经**不再**合成 `default` 账户了
 * （见 `accounts.js` 的注释）。只有文档里根本没有 `accounts` 这个键时才退回老夹具，
 * 用来走"从报告播种"的迁移路径。
 *
 * `cliCredentialExpiresAt` 模拟宿主的 `credentialExpiresAt`：读不到时**不写这个键**，
 * 界面就不该对到期时间说任何话。
 */
let cliCredentialExpiresAt
function accountStatesFromSettings() {
  const config = storedSettings.accounts
  const list = Array.isArray(config) ? config : FALLBACK_ACCOUNTS
  return list.map((account, index) => {
    const type = account.type === 'cli' ? 'cli' : 'apikey'
    const custom = typeof account.label === 'string' && account.label.trim() !== ''
    const label = custom ? account.label.trim() : (type === 'cli' ? `CLI 账户 ${index + 1}` : `API Key 账户 ${index + 1}`)
    const base = {
      id: account.id,
      label,
      labelIsCustom: custom,
      type,
      ref: type === 'cli' ? '' : (account.apiKeyEnv ?? ''),
      home: account.home === undefined || account.home === '' ? undefined : account.home,
      mark: null,
    }
    return type === 'cli'
      ? {
        ...base,
        configured: true,
        source: 'arkcli',
        loggedIn: true,
        identity: { userName: 'nala' },
        ...(typeof cliCredentialExpiresAt === 'number' ? { credentialExpiresAt: cliCredentialExpiresAt } : {}),
      }
      : { ...base, configured: configuredRefs.has(base.ref), source: configuredRefs.has(base.ref) ? 'store' : undefined }
  })
}

const PLAN_WINDOWS = [
  { key: 'session', label: '5 小时', percent: 12, hasTotals: false, resetAt: Date.now() + 3600_000 },
  { key: 'weekly', label: '每周', percent: 34, hasTotals: false, resetAt: null },
  { key: 'monthly', label: '每月', percent: 8, hasTotals: false, resetAt: null },
]

const CATALOG_MODELS = [
  { id: 'doubao-seed-evolving', name: 'Doubao-Seed-Evolving', family: 'Doubao', contextWindow: 1048576, maxOutput: 262144, input: ['text', 'image'] },
  { id: 'doubao-seed-2.1-pro', name: 'Doubao-Seed-2.1-pro', family: 'Doubao', contextWindow: 1048576, maxOutput: 262144, input: ['text', 'image'] },
  { id: 'doubao-seed-2.1-lite', name: 'Doubao-Seed-2.1-lite', family: 'Doubao', contextWindow: 1048576, maxOutput: 262144, input: ['text', 'image'] },
  { id: 'doubao-seed-2.0-mini', name: 'Doubao-Seed-2.0-mini', family: 'Doubao', contextWindow: 262144, maxOutput: 131072, input: ['text', 'image'] },
  { id: 'minimax-m3', name: 'MiniMax-M3', family: 'MiniMax', contextWindow: 1048576, maxOutput: 131072, input: ['text', 'image'] },
  { id: 'glm-5.3', name: 'GLM-5.3', family: 'Zhipu', contextWindow: 1048576, maxOutput: 131072, input: ['text'] },
  { id: 'glm-5.3-flash', name: 'GLM-5.3-Flash', family: 'Zhipu', contextWindow: 1048576, maxOutput: 131072, input: ['text', 'image'] },
  { id: 'deepseek-v4.1-flash', name: 'DeepSeek-V4.1-Flash', family: 'DeepSeek', contextWindow: 1048576, maxOutput: 393216, input: ['text', 'image'] },
  { id: 'deepseek-v4-flash', name: 'DeepSeek-V4-Flash', family: 'DeepSeek', contextWindow: 1048576, maxOutput: 393216, input: ['text'] },
  { id: 'deepseek-v4-pro', name: 'DeepSeek-V4-Pro', family: 'DeepSeek', contextWindow: 1048576, maxOutput: 393216, input: ['text'] },
  { id: 'kimi-k2.8-preview', name: 'Kimi-K2.8-Preview', family: 'Moonshot', contextWindow: 1048576, maxOutput: 131072, input: ['text', 'image'] },
  { id: 'kimi-k3', name: 'Kimi-K3', family: 'Moonshot', contextWindow: 1048576, maxOutput: 131072, input: ['text', 'image'] },
]

/** 官方目录：普通行与实测一致，`glm-5.3-flash` 故意与实测分歧（契约 §2.4）。 */
const CATALOG_CONFLICT_FIELDS = ['contextWindow', 'maxOutput', 'input']
const catalogFixture = {
  ok: true,
  source: 'arkcli',
  updatedAt: Date.now(),
  total: 20,
  models: CATALOG_MODELS.map((model) => model.id === 'glm-5.3-flash'
    ? {
      ...model,
      official: {
        id: model.id, displayName: 'glm-5.3-flash', version: '1.0',
        contextWindow: 262144, maxOutputTokens: 65536, inputModalities: ['text'],
        thinking: true, lifecycleStatus: 'stable',
      },
      conflicts: CATALOG_CONFLICT_FIELDS,
    }
    : {
      ...model,
      official: {
        id: model.id, displayName: model.id, version: '1.0',
        contextWindow: model.contextWindow, maxOutputTokens: model.maxOutput,
        inputModalities: model.input, lifecycleStatus: 'stable',
      },
    }),
  matched: 12,
  conflicts: [{ id: 'glm-5.3-flash', fields: CATALOG_CONFLICT_FIELDS }],
  unmatchedOfficial: 8,
  officialSample: ['doubao-seed-3.0', 'kimi-k4-preview'],
}

const reportBase = {
  provider: 'ark-coding',
  displayName: '火山方舟 Coding Plan',
  plan: {
    ok: true,
    source: 'arkcli',
    windows: PLAN_WINDOWS,
    updatedAt: Date.now(),
    accounts: [
      { accountId: 'acct-cli-1', label: '工作账号', ok: true, windows: PLAN_WINDOWS, tier: 'pro', updatedAt: Date.now() },
      { accountId: 'default', label: 'default', ok: false, windows: [], error: 'API Key 账户查不到套餐额度。' },
    ],
  },
  sidebarQuota: { mode: 'auto', capable: true, show: true },
  catalog: catalogFixture,
  cli: { installed: true, path: '/home/.dsh/arkcli/bin/arkcli', version: '1.0.39', source: 'npm' },
  activeAccount: '',
  refreshSeconds: 60,
  reportedAt: Date.now(),
}
function currentReport() {
  return { ...reportBase, accounts: accountStatesFromSettings(), reportedAt: Date.now() }
}
let usageReportFn = async () => ({ ok: true, value: currentReport() })

// --- 假 remote.arkcoding（契约 §1 的全部 8 个端点） -------------------------
const loginBeginCalls = []
const loginPollCalls = []
const loginSubmitCalls = []
const loginCancelCalls = []
let cliInstallCalls = 0
let catalogRefreshCalls = 0
let loginPollFn = async (input) => ({ ok: true, value: { ok: true, accountId: input.accountId, state: 'pending' } })
let loginSubmitFn = async (input) => ({ ok: true, value: { ok: true, accountId: input.accountId, state: 'pending' } })

function makeArkcodingNamespace() {
  return {
    report: () => usageReportFn(),
    cliStatus: async () => ({ ok: reportBase.cli.installed === true, value: { ok: reportBase.cli.installed === true, ...reportBase.cli } }),
    cliInstall: async () => {
      cliInstallCalls += 1
      reportBase.cli = { installed: true, path: '/home/.dsh/arkcli/bin/arkcli', version: '1.0.39', source: 'npm' }
      return { ok: true, value: { ok: true, installed: true, path: reportBase.cli.path, version: reportBase.cli.version } }
    },
    catalogRefresh: async () => {
      catalogRefreshCalls += 1
      // 刷新后官方目录与实测一致：per-model 的 conflicts 也一并清掉。
      const refreshed = {
        ...catalogFixture,
        updatedAt: Date.now(),
        models: catalogFixture.models.map((model) => {
          const { conflicts, ...rest } = model
          return rest
        }),
        conflicts: [],
        unmatchedOfficial: 0,
        officialSample: [],
      }
      return { ok: true, value: refreshed }
    },
    loginBegin: async (input) => {
      loginBeginCalls.push(input)
      return {
        ok: true,
        value: {
          ok: true,
          accountId: input.accountId,
          url: 'https://console.volcengine.com/ark/authorize?callbackPort=39171',
          port: 39171,
          hint: '登录成功后页面会跳到 http://127.0.0.1:<端口>/… 并显示打不开——这是正常的。',
        },
      }
    },
    loginPoll: async (input) => { loginPollCalls.push(input); return loginPollFn(input) },
    loginSubmit: async (input) => { loginSubmitCalls.push(input); return loginSubmitFn(input) },
    loginCancel: async (input) => { loginCancelCalls.push(input); return { ok: true, value: { ok: true, cancelled: true, accountId: input.accountId } } },
  }
}

// --- 假 cordis 上下文（带真实的注入守卫） -----------------------------------
const localeRegistrations = []
const slotRegistrations = []
const injectedServices = []
const mounted = []

const ctx = {
  effect: (fn) => { const cleanup = fn(); return () => { if (typeof cleanup === 'function') cleanup() } },
  inject: (services, callback) => {
    injectedServices.push(services.join(','))
    const child = {}
    // 只暴露自己声明的命名空间；读别的抛错，和 cordis 的 `without inject` 一致。
    child.remote = new Proxy({}, {
      get(_target, prop) {
        if (typeof prop !== 'string') return undefined
        if (!services.includes(`remote.${prop}`)) throw new Error(`cannot get property "${prop}" without inject`)
        if (prop === 'settings') return makeSettingsNamespace()
        if (prop === 'credentials') return makeCredentialsNamespace()
        if (prop === 'arkcoding') return makeArkcodingNamespace()
        if (prop === 'layout') return { selectPanel: () => {} }
        throw new Error(`cannot get property "${prop}" without inject`)
      },
    })
    child.effect = ctx.effect
    // 真 cordis 里 slots 也在同一个上下文上（sidebar 卡片走 inject(['layout']) 后注册）。
    child.slots = ctx.slots
    callback(child)
  },
  locale: {
    register: (ns, copy) => { localeRegistrations.push({ ns, copy }); return () => {} },
    bind: (ns) => (key) => localeRegistrations.find((entry) => entry.ns === ns)?.copy?.zh?.[key] ?? key,
  },
  slots: {
    inject: (slot, callback) => {
      try { callback() } catch (error) { console.error('slot inject failed for', slot, error) }
    },
    register: (options, component) => { slotRegistrations.push({ options, component }) },
  },
  /**
   * 假 `$mount`，但要**照真的一样校验贡献**。
   *
   * 真实实现见 `@deepseek-ai/dsh-api-gateway/lib/client.js` 的 `requireStrictInputs`：
   * 它逐条校验 `parameters[].codec`、`descriptor.uplink.codec`，以及
   * `invocation.kind === 'context'` 时的 `invocation.codec`；**不校验 `result`**。
   * 错误消息里带 `${namespace}/${method}` 端点名。
   *
   * 以前这里只查 parameters 与 result：既漏了 uplink/context，又把 result 当成必查项，
   * 于是"src-json 参数"这种真机上会掀翻整个 `$mount`（八个端点一起失效）的写法
   * 离线全绿。现在两份行为对齐，并用下面的自检断言钉住。
   */
  remote: (() => {
    return new Proxy({}, {
      get(_target, prop) {
        if (typeof prop !== 'string') return undefined
        if (prop === '$on') return () => () => {}
        if (prop === '$mount') {
          return (contribution) => {
            try {
              requireStrictContribution(contribution)
            } catch (error) {
              return Promise.reject(error)
            }
            mounted.push(contribution)
            return Promise.resolve(() => {})
          }
        }
        throw new Error(`cannot get property "${prop}" without inject`)
      },
    })
  })(),
  get: () => undefined,
}

/**
 * 真实客户端的贡献校验，照 `@deepseek-ai/dsh-api-gateway/lib/client.js` 的
 * `requireStrictInputs` 抄：逐条查 `parameters[].codec`、`descriptor.uplink.codec`，
 * 以及 `invocation.kind === 'context'` 时的 `invocation.codec`；**不查 `result`**。
 * 错误消息里带 `${namespace}/${method}` 端点名。
 *
 * 以前假 `$mount` 只查 parameters 与 result：既漏了 uplink/context，又把 result
 * 当成必查项 —— 于是真机上会掀翻整个 `$mount`（八个端点一起失效）的 src-json 参数
 * 写法离线全绿，而真机合法的 result 形状反而可能被它误判。
 */
function requireStrictContribution(contribution) {
  const requireStrictCodec = (codec, endpoint, field) => {
    if (codec?.mode !== 'strict') {
      throw new Error(`client api: generated Remote ${endpoint} field ${JSON.stringify(field)} has no strict codec`)
    }
  }
  for (const descriptor of contribution.descriptors ?? []) {
    const endpoint = `${descriptor.namespace}/${descriptor.method}`
    for (const parameter of descriptor.parameters ?? []) requireStrictCodec(parameter.codec, endpoint, parameter.wire)
    if (descriptor.uplink !== undefined) requireStrictCodec(descriptor.uplink.codec, endpoint, 'uplink')
    if (descriptor.invocation?.kind === 'context') requireStrictCodec(descriptor.invocation.codec, endpoint, descriptor.invocation.wire)
  }
}

moduleExports.apply(ctx)
await flush()

// --- 注册结果 ---------------------------------------------------------------
check('a stylesheet is injected once', styleTags.length === 1, `tags=${styleTags.length}`)
const css = styleTags[0].textContent
check('styles use only theme tokens', css.indexOf('--dsw-') !== -1)

// ---------------------------------------------------------------------------
// 最小 CSS 解析器：按 (特异性, 源序) 求"某元素某属性的生效值"
// ---------------------------------------------------------------------------
//
// 为什么需要它：以前的 CSS 断言全是 `/\.akc-x\s*\{[^}]*prop:val/` 形式的正则 ——
// 不做选择器解析、不看特异性、也不看源序。于是在样式表**末尾追加**一条同选择器的
// 规则（`.akc-btn:disabled { opacity:.2 }`，或历史上真正踩过的
// `.akc-bar { background:var(--dsw-alias-bg-layer-2) }` —— 浅色下进度条轨道隐形）
// 时，旧的"存在性"断言依然全绿。真实 CSS 的规则是"同特异性后者胜"，所以必须
// 按 (特异性, 源序) 求生效值。
function splitTopLevel(text, separator) {
  const parts = []
  let depth = 0
  let quote = ''
  let current = ''
  for (const char of text) {
    if (quote !== '') { current += char; if (char === quote) quote = ''; continue }
    if (char === '"' || char === "'") { quote = char; current += char; continue }
    if (char === '(' || char === '[') depth += 1
    if (char === ')' || char === ']') depth -= 1
    if (char === separator && depth === 0) { parts.push(current); current = ''; continue }
    current += char
  }
  parts.push(current)
  return parts
}
function parseDeclarations(text) {
  const declarations = []
  for (const chunk of splitTopLevel(text, ';')) {
    const colon = chunk.indexOf(':')
    if (colon === -1) continue
    const property = chunk.slice(0, colon).trim()
    const value = chunk.slice(colon + 1).trim()
    if (property === '' || value === '') continue
    declarations.push([property, value])
  }
  return declarations
}
/** 选择器特异性 (id, class/attr/pseudo, type)：按**整个选择器**求和（含后代部分）。 */
function specificityOf(selector) {
  let id = 0
  let klass = 0
  let type = 0
  // `:not(...)` 按参数里最具体的那个计，先把它抠出来单独算。
  const withoutNot = selector.replace(/:not\(([^)]*)\)/g, (_all, inner) => {
    const innerSpec = specificityOf(inner)
    id += innerSpec[0]
    klass += innerSpec[1]
    type += innerSpec[2]
    return ''
  })
  for (const compound of splitSelectorCompounds(withoutNot)) {
    id += (compound.match(/#[A-Za-z0-9_-]+/g) ?? []).length
    klass += (compound.match(/\.[A-Za-z0-9_-]+/g) ?? []).length
    klass += (compound.match(/\[[^\]]*\]/g) ?? []).length
    klass += (compound.match(/(?<!:):[A-Za-z-]+/g) ?? []).length
    if (/^[A-Za-z][\w-]*/.test(compound)) type += 1
  }
  return [id, klass, type]
}
/** 按组合子把选择器拆成若干复合选择器（本样式表只用到后代组合子）。 */
function splitSelectorCompounds(selector) {
  return selector.trim().split(/\s*[>+~]\s*|\s+/).filter((part) => part !== '')
}
/** 解析一张样式表 → 规则列表（每条含 selector / 特异性 / 声明 / 源序）。 */
function parseCss(text) {
  const body = text.replace(/\/\*[\s\S]*?\*\//g, '')
  const rules = []
  let index = 0
  while (index < body.length) {
    const open = body.indexOf('{', index)
    if (open === -1) break
    const close = body.indexOf('}', open)
    if (close === -1) break
    const selectorText = body.slice(index, open).trim()
    const declarations = parseDeclarations(body.slice(open + 1, close))
    if (selectorText !== '') {
      for (const selector of splitTopLevel(selectorText, ',')) {
        const trimmed = selector.trim()
        if (trimmed === '') continue
        rules.push({ selector: trimmed, specificity: specificityOf(trimmed), declarations, order: rules.length })
      }
    }
    index = close + 1
  }
  return rules
}
/**
 * 解析主体复合选择器。`:not(...)` 的内容先抠掉：它的内部选择器（如 `:disabled`）
 * 不是这个元素的状态，混进 states 会让 `.btn:hover:not(:disabled)` 被误判成
 * "必须同时 hover 且 disabled"。
 */
function parseCompound(selector) {
  const subject = splitSelectorCompounds(selector).pop() ?? ''
  const nots = [...subject.matchAll(/:not\(([^)]*)\)/g)].map((match) => match[1])
  const withoutNot = subject.replace(/:not\([^)]*\)/g, '')
  return {
    tag: /^[A-Za-z][\w-]*/.exec(withoutNot)?.[0],
    classes: [...withoutNot.matchAll(/\.([A-Za-z0-9_-]+)/g)].map((match) => match[1]),
    states: [...withoutNot.matchAll(/(?<!:):([A-Za-z-]+)/g)].map((match) => match[1]),
    nots,
    attrs: [...withoutNot.matchAll(/\[([^\]]+)\]/g)].map((match) => match[1]),
  }
}
/** 描述一个元素：`el('button', 'akc-btn primary', ['disabled'], { 'aria-current': 'step' }, ancestors)`。 */
function el(tag, classes = '', states = [], attrs = {}, ancestors = []) {
  return {
    tag,
    classes: typeof classes === 'string' ? classes.split(/\s+/).filter(Boolean) : classes,
    states,
    attrs,
    ancestors,
  }
}
function compoundMatches(compound, element) {
  if (compound.tag !== undefined && element.tag !== undefined && compound.tag !== element.tag) return false
  if (!compound.classes.every((name) => element.classes.includes(name))) return false
  if (!compound.states.every((state) => element.states.includes(state))) return false
  for (const not of compound.nots) {
    const inner = parseCompound(not)
    if (inner.classes.every((name) => element.classes.includes(name))
      && inner.states.every((state) => element.states.includes(state))
      && (inner.tag === undefined || inner.tag === element.tag)) return false
  }
  for (const attr of compound.attrs) {
    const [name, rawValue] = attr.split('=').map((part) => part.trim())
    const actual = element.attrs?.[name]
    if (actual === undefined) return false
    if (rawValue !== undefined && String(actual) !== rawValue.replace(/^["']|["']$/g, '')) return false
  }
  return true
}
/**
 * 选择器是否匹配一个元素：主体复合选择器必须命中，前面的后代部分必须能按顺序
 * 落在祖先链上。本样式表只用后代组合子；`>`/`+`/`~` 按同样的顺序近似处理。
 */
function selectorMatches(selector, element) {
  const parts = splitSelectorCompounds(selector)
  if (parts.length === 0) return false
  if (!compoundMatches(parseCompound(parts[parts.length - 1]), element)) return false
  const ancestors = element.ancestors ?? []
  let cursor = ancestors.length - 1
  for (let index = parts.length - 2; index >= 0; index -= 1) {
    const compound = parseCompound(parts[index])
    let matched = false
    while (cursor >= 0) {
      if (compoundMatches(compound, ancestors[cursor])) { matched = true; cursor -= 1; break }
      cursor -= 1
    }
    if (!matched) return false
  }
  return true
}
function matchingRules(rules, element) {
  return rules.filter((rule) => selectorMatches(rule.selector, element))
}
/** 某元素某属性的生效值：命中规则里按 (特异性, 源序) 胜出者。 */
function effective(rules, element, property) {
  let winner
  for (const rule of matchingRules(rules, element)) {
    for (const [name, value] of rule.declarations) {
      if (name !== property) continue
      if (winner === undefined) { winner = { value, specificity: rule.specificity }; continue }
      const left = rule.specificity
      const right = winner.specificity
      const compare = left[0] - right[0] || left[1] - right[1] || left[2] - right[2]
      // 迭代按源序进行：`>= 0` 让"同特异性后者胜"。
      if (compare >= 0) winner = { value, specificity: rule.specificity }
    }
  }
  return winner?.value
}
/** 某元素某属性被所有命中规则声明的值（用于"绝不出现某 token"这类断言）。 */
function declaredValues(rules, element, property) {
  const values = []
  for (const rule of matchingRules(rules, element)) {
    for (const [name, value] of rule.declarations) if (name === property) values.push(value)
  }
  return values
}
const CSS_RULES = parseCss(css)

// 解析器自身的信用：同特异性时后写的规则必须胜出 —— 这正是历史回归的形状。
{
  const base = '.akc-bar { background:var(--dsw-alias-state-idle-primary); }'
  const override = '.akc-bar { background:var(--dsw-alias-bg-layer-2); }'
  check('the CSS resolver lets a later same-specificity rule win',
    effective(parseCss(`${base}\n${override}`), el('div', 'akc-bar'), 'background') === 'var(--dsw-alias-bg-layer-2)')
  check('the CSS resolver lets a more specific rule win over a later weaker one',
    effective(parseCss('.akc-btn { color:red; }\n.akc-btn.primary { color:blue; }\n.akc-btn { color:green; }'),
      el('button', 'akc-btn primary'), 'color') === 'blue')
  check('the CSS resolver honours attribute selectors',
    effective(parseCss('.akc-step { color:a; }\n.akc-step[aria-current="step"] { color:b; }'),
      el('li', 'akc-step', [], { 'aria-current': 'step' }), 'color') === 'b')
}

check('the disabled button keeps a readable opacity and an explicit colour',
  effective(CSS_RULES, el('button', 'akc-btn', ['disabled']), 'opacity') === '1'
  && effective(CSS_RULES, el('button', 'akc-btn', ['disabled']), 'color') === 'var(--dsw-alias-label-secondary)',
  'the grey-on-grey Save button was the complaint')
check('the default button gets a 1px border in the disabled state',
  effective(CSS_RULES, el('button', 'akc-btn', ['disabled']), 'border-color') === 'var(--dsw-alias-border-l1)')
check('the locale namespace is registered', localeRegistrations.some((entry) => entry.ns === 'settings.arkcoding'))
check('three slots are registered', slotRegistrations.length === 3, JSON.stringify(slotRegistrations.map((r) => r.options.name)))
check('the settings page registers under id arkcoding',
  slotRegistrations.some((r) => r.options.name === 'settings.section' && r.options.id === 'arkcoding'))
check('the provider card registers under the settings namespace key',
  slotRegistrations.some((r) => r.options.name === 'settings.models.provider-card' && r.options.key === 'llm-ark-coding'))
check('the sidebar usage card registers in the footer area',
  slotRegistrations.some((r) => r.options.name === 'sidebar.footer.action' && r.options.id === 'arkcoding-quota'))
check('each remote namespace is injected separately',
  ['remote.settings', 'remote.credentials', 'remote.arkcoding', 'layout'].every((key) => injectedServices.includes(key)),
  injectedServices.join(' | '))
// 根级 `ctx.remote` 也要有注入守卫（真 cordis 读未声明的命名空间会抛
// `cannot get property "X" without inject`，而不是给一个 undefined 让 UI 静默降级）。
check('the root remote context rejects an undeclared namespace like real cordis',
  (() => {
    try { void ctx.remote.credentials; return false } catch (error) {
      return /cannot get property "credentials" without inject/.test(String(error?.message ?? error))
    }
  })())
check('the usage contribution is mounted once with the host descriptor',
  mounted.length === 1 && mounted[0].descriptors[0].method === 'report' && mounted[0].descriptors[0].namespace === 'arkcoding',
  JSON.stringify(mounted[0]?.descriptors?.[0]?.id ?? null))
check('the contribution declares all eight remote endpoints on the same namespace',
  mounted.length === 1
  && mounted[0].descriptors.length === 8
  && ['report', 'cliStatus', 'cliInstall', 'catalogRefresh', 'loginBegin', 'loginPoll', 'loginSubmit', 'loginCancel']
    .every((method) => mounted[0].descriptors.some((descriptor) => descriptor.method === method && descriptor.namespace === 'arkcoding')),
  JSON.stringify(mounted[0]?.descriptors?.map((d) => d.method) ?? []))
check('the parameterised endpoints declare exactly one wire parameter named input',
  mounted[0].descriptors.filter((d) => ['loginBegin', 'loginPoll', 'loginSubmit', 'loginCancel'].includes(d.method))
    .every((d) => d.parameters.length === 1 && d.parameters[0].name === 'input' && d.parameters[0].wire === 'input'))

// 端点 id 也必须逐字对齐宿主的 `USAGE_CLIENT_CONTRIBUTION`（只在宿主被删/改名时变红）。
const PINNED_ENDPOINT_IDS = ['report', 'cliStatus', 'cliInstall', 'catalogRefresh', 'loginBegin', 'loginPoll', 'loginSubmit', 'loginCancel']
  .map((method) => `dsh-ark-coding-provider#arkcoding/${method}`)
check('the mounted contribution carries the very ids the host contribution declares',
  JSON.stringify(mounted[0].descriptors.map((descriptor) => descriptor.id)) === JSON.stringify(PINNED_ENDPOINT_IDS),
  JSON.stringify(mounted[0].descriptors.map((descriptor) => descriptor.id)))

// 假 `$mount` 的**保真度自检**：它必须与真实 `requireStrictInputs` 同判决。
// 真实现见 dsh-api-gateway/lib/client.js：查 parameters[].codec、uplink.codec、
// invocation.kind==='context' 时的 invocation.codec；**不查 result**。
{
  const strictResult = { mode: 'strict', typeSymbol: 'x', create: () => ({ parse: (value) => value }) }
  const base = { id: 'dsh-ark-coding-provider#arkcoding/report', service: 'arkUsage', namespace: 'arkcoding', method: 'report', invocation: { kind: 'direct' }, parameters: [], result: strictResult }
  const sources = [
    ['a src-json parameter codec', [{ ...base, parameters: [{ name: 'input', wire: 'input', source: 'json', codec: { mode: 'src-json' } }] }], false],
    ['a missing parameter codec', [{ ...base, parameters: [{ name: 'input', wire: 'input', source: 'json' }] }], false],
    ['a src-json uplink codec', [{ ...base, uplink: { codec: { mode: 'src-json' } } }], false],
    ['a src-json context invocation codec', [{ ...base, invocation: { kind: 'context', wire: 'input', codec: { mode: 'src-json' } } }], false],
    ['a non-strict result (the real check does not look at result)', [{ ...base, result: { mode: 'src-json' } }], true],
    ['a strict parameter codec', [{ ...base, parameters: [{ name: 'input', wire: 'input', source: 'json', codec: { mode: 'strict', typeSymbol: 't', create: () => ({ parse: (value) => value }) } }] }], true],
  ]
  let fidelityOk = true
  const observed = []
  for (const [label, descriptors, shouldAccept] of sources) {
    let accepted = false
    let message = ''
    try { requireStrictContribution({ package: 'probe', descriptors }); accepted = true } catch (error) { message = String(error?.message ?? error) }
    observed.push(`${label}=${accepted ? 'accept' : 'reject'}`)
    if (accepted !== shouldAccept) fidelityOk = false
    if (!shouldAccept && (!/arkcoding\/report/.test(message) || !/no strict codec/.test(message))) fidelityOk = false
  }
  check('the fake $mount judges codecs exactly like the real requireStrictInputs',
    fidelityOk && mounted.length === 1, observed.join(' | '))
}
check('the nav label resolves through the locale namespace',
  slotRegistrations.find((r) => r.options.id === 'arkcoding')?.options.label() === '火山方舟')

// --- 控制器：密钥读写 -------------------------------------------------------
const sectionRegistration = slotRegistrations.find((r) => r.options.name === 'settings.section')
const controller = sectionRegistration.options.inject().controller
// 直接调 writeCredential：`client.js` 全文没有 `saveKey`，旧的
// `controller.saveKey?.(...)` 恒为 undefined、每次都靠 `??` 落到 writeCredential ——
// 一条对不存在方法的可选调用，看起来测了两条路径，其实只测了同一条。
const saved = await controller.writeCredential('ARK_CODING_API_KEY', 'ark-live-test-key')
check('writeCredential writes through remote.credentials', saved === true && storedCredential === 'ark-live-test-key',
  `saved=${saved} stored=${storedCredential}`)
await controller.loadKey()
check('loadKey reads back the configured state', controller.store.get().key.state === 'configured', JSON.stringify(controller.store.get().key))
check('loadKey calls describe with an ARRAY of refs',
  credentialCalls.some(([name, arg]) => name === 'describe' && Array.isArray(arg) && arg.includes('ARK_CODING_API_KEY')),
  JSON.stringify(credentialCalls.slice(0, 2)))
check('clearCredential removes it',
  (await controller.clearCredential('ARK_CODING_API_KEY')) === true && controller.store.get().key.state === 'missing')

// --- 控制器：模型勾选只改本地，保存才写一次 ---------------------------------
await controller.loadSettings()
const before = mutateCalls.length
controller.editField('modelVisibility', { 'kimi-k3': false, 'glm-5.3': true })
check('toggling a model does NOT hit the host', mutateCalls.length === before, `mutate calls grew by ${mutateCalls.length - before}`)
check('the draft is marked dirty', controller.store.get().dirty === true)
check('the draft holds the new selection locally',
  controller.store.get().draft.modelVisibility['kimi-k3'] === false,
  JSON.stringify(controller.store.get().draft.modelVisibility))

// 连续勾十个也只在保存时写一次
for (const id of ['doubao-seed-evolving', 'minimax-m3', 'glm-5.3-flash', 'kimi-k2.8-preview']) {
  controller.editField('modelVisibility', { ...controller.store.get().draft.modelVisibility, [id]: false })
}
check('many toggles still make zero host calls', mutateCalls.length === before, `mutate calls grew by ${mutateCalls.length - before}`)

const savedModels = await controller.save()
check('one save writes exactly one mutation', mutateCalls.length === before + 1, `mutate calls = ${mutateCalls.length - before}`)
check('the single mutation carries the whole selection once',
  savedModels === true && mutateCalls[before].ops.length === 1 && mutateCalls[before].ops[0].path[0] === 'modelVisibility',
  JSON.stringify(mutateCalls[before]?.ops))
check('the draft is clean after saving', controller.store.get().dirty === false)
check('numeric fields are normalised before writing',
  await (async () => {
    controller.editField('usageRefreshSeconds', '120')
    const n = mutateCalls.length
    await controller.save()
    const op = mutateCalls[n]?.ops?.find((entry) => entry.path[0] === 'usageRefreshSeconds')
    return op !== undefined && op.value === 120 && typeof op.value === 'number'
  })())

// --- 用量报告 ---------------------------------------------------------------
await controller.refreshUsage()
check('refreshUsage stores the host report', controller.store.get().usage?.plan?.ok === true
  && controller.store.get().usage.plan.windows.length === 3, JSON.stringify(controller.store.get().usageError ?? null))
check('the report carries the accounts and the sidebar-card decision, and no local ledger',
  Array.isArray(controller.store.get().usage.accounts)
  && controller.store.get().usage.sidebarQuota.show === true
  && controller.store.get().usage.local === undefined
  && controller.store.get().usage.ledgerPath === undefined,
  JSON.stringify(Object.keys(controller.store.get().usage).filter((k) => /local|ledger/i.test(k))))
check('the report carries the official catalog and the arkcli status',
  controller.store.get().usage.catalog.ok === true
  && controller.store.get().usage.catalog.unmatchedOfficial === 8
  && controller.store.get().usage.cli.installed === true)
check('the report groups plan quota per account',
  Array.isArray(controller.store.get().usage.plan.accounts) && controller.store.get().usage.plan.accounts.length === 2
  && controller.store.get().usage.plan.accounts[0].accountId === 'acct-cli-1')
usageReportFn = async () => ({ ok: false, error: { message: 'boom' } })
await controller.refreshUsage()
check('a failed report surfaces an error instead of throwing', controller.store.get().usageError === 'boom')
usageReportFn = async () => ({ ok: true, value: currentReport() })
await controller.refreshUsage()

// 没有能查额度的绑定时，`auto` 档下卡片**根本不渲染** —— 而不是渲染一张
// 只写着"未配置"的常驻卡片。report 里 `sidebarQuota.show` 是唯一判据。
const localOnlyReport = () => ({
  ...currentReport(),
  plan: { ok: false, error: 'API Key 只能聊天，查不到套餐额度。', accounts: [] },
  sidebarQuota: { mode: 'auto', capable: false, show: false },
})
usageReportFn = async () => ({ ok: true, value: localOnlyReport() })
await controller.refreshUsage()
check('a report without any quota binding is reported as such',
  controller.store.get().usage.plan.ok === false && controller.store.get().usage.sidebarQuota.show === false)

/** 数一棵渲染树里某类元素的个数。 */
function countNodes(node, predicate) {
  if (node === null || node === undefined || typeof node !== 'object') return 0
  if (Array.isArray(node)) return node.reduce((sum, child) => sum + countNodes(child, predicate), 0)
  let total = predicate(node) ? 1 : 0
  total += countNodes(node.props?.children, predicate)
  return total
}

/** 收集匹配的节点（用于点按钮 / 取子树）。 */
function findNodes(node, predicate, out = []) {
  if (node === null || node === undefined || typeof node !== 'object') return out
  if (Array.isArray(node)) { for (const child of node) findNodes(child, predicate, out); return out }
  if (predicate(node)) out.push(node)
  findNodes(node.props?.children, predicate, out)
  return out
}

const localSide = slotRegistrations.find((r) => r.options.name === 'sidebar.footer.action')
const localFace = localSide.options.inject()
const localT = (key) => localeRegistrations.find((e) => e.ns === localSide.options.locale)?.copy?.zh?.[key] ?? key
const hasBar = (n) => typeof n.type === 'string' && String(n.props?.className ?? '').includes('akc-barFill')
/** 每次渲染前把钩子游标归零，让顶层的 useState/useRef 落在确定的槽位上。 */
const sideProps = (extra) => ({ ...localFace, t: localT, ...extra })

// --- 卡片：拿不到额度就不渲染 -------------------------------------------------
resetCursor()
const hiddenTree = deepRender(localSide.component(sideProps()))
check('an unbound auto card renders nothing at all',
  hiddenTree === null || hiddenTree === undefined, JSON.stringify(hiddenTree))

// --- 卡片：只显示 5 小时与本周 ------------------------------------------------
usageReportFn = async () => ({ ok: true, value: currentReport() })
await controller.refreshUsage()
resetCursor()
const planTree = deepRender(localSide.component(sideProps()))
const planText = JSON.stringify(planTree)
check('the sidebar card draws a bar for 5-hour and weekly only',
  countNodes(planTree, hasBar) === 2, `bars=${countNodes(planTree, hasBar)}`)
check('the sidebar card shows the real percentages',
  planText.includes('12%') && planText.includes('34%'))
check('the sidebar card leaves the monthly window to the detail panel',
  !planText.includes('每月') && !planText.includes('8%'), planText.slice(0, 200))
// 卡片只剩"5 小时 / 本周"两档：以前底部还有一行「账户额度 · 工作账号」，那行既不
// 是要盯的数字、又白占一行高度，用户明确要求去掉。账户名仍然在详情面板里（见下）。
check('the collapsed card carries nothing but the two windows',
  !planText.includes('工作账号') && !planText.includes('账户额度')
  && findNodes(planTree, (n) => String(n.props?.className ?? '').includes('akc-sideMeta')).length === 0,
  planText.slice(0, 240))
check('the sidebar card is a button', planTree.type === 'button' && planTree.props.className.includes('akc-side'))
check('no local-accounting note survives in the sidebar card', !planText.includes('非套餐额度'))

// --- 卡片：窄轨道态（wide:false） --------------------------------------------
// 侧边栏可以被布局收成一条 56px 轨道，那时组件不显示标题与窗口标签、只留两行百分比。
// 以前这一整条分支零覆盖（测试只调 `sideProps()`，从不传 `wide`），于是"不应用 narrow
// 类""窄态没隐藏标签""窄态 gap 被改坏"三种变异全都全绿。
{
  resetCursor()
  const narrowTree = deepRender(localSide.component(sideProps({ wide: false })))
  check('the narrow sidebar card applies the narrow class',
    narrowTree?.type === 'button' && String(narrowTree.props.className).split(/\s+/).includes('narrow'),
    String(narrowTree?.props?.className))
  check('the narrow card drops the header row entirely',
    findNodes(narrowTree, (n) => String(n.props?.className ?? '').split(/\s+/).includes('akc-sideHead')).length === 0)
  const narrowLabels = findNodes(narrowTree, (n) => String(n.props?.className ?? '').split(/\s+/).includes('akc-windowLabel'))
  check('the narrow card hides the window labels as empty strings (rows stay)',
    narrowLabels.length === 2 && narrowLabels.every((node) => node.props.children === ''),
    JSON.stringify(narrowLabels.map((node) => node.props.children)))
  check('the narrow card still draws both percentage bars',
    countNodes(narrowTree, hasBar) === 2, `bars=${countNodes(narrowTree, hasBar)}`)
  check('the narrow gap comes from `.akc-side.narrow`, and the wide gap is unchanged',
    effective(CSS_RULES, el('div', 'akc-side narrow'), 'gap') === '5px'
    && effective(CSS_RULES, el('div', 'akc-side'), 'gap') === '6px',
    JSON.stringify({ narrow: effective(CSS_RULES, el('div', 'akc-side narrow'), 'gap'), wide: effective(CSS_RULES, el('div', 'akc-side'), 'gap') }))
}

// --- 卡片：点击展开详情（登录情况 + 三档额度） --------------------------------
resetCursor()
const closed = deepRender(localSide.component(sideProps()), true)
const cardNode = findNodes(closed, (n) => n.type === 'button' && String(n.props?.className ?? '').includes('akc-side'))[0]
check('the sidebar card carries an open handler', typeof cardNode?.props?.onClick === 'function')
statefulHooks = true
cardNode.props.onClick()
statefulHooks = false
resetCursor()
const opened = deepRender(localSide.component(sideProps()))
const openedText = JSON.stringify(opened)
check('clicking the card opens the detail panel',
  openedText.includes('登录情况') && openedText.includes('额度'), openedText.slice(0, 200))
check('the detail panel lists every account with its sign-in status',
  openedText.includes('工作账号') && openedText.includes('CLI 登录') && openedText.includes('已登录') && openedText.includes('nala'))
check('the detail panel shows all three windows, monthly included',
  openedText.includes('5 小时') && openedText.includes('本周') && openedText.includes('本月')
  && openedText.includes('12%') && openedText.includes('34%') && openedText.includes('8%'))
const dialog = findNodes(opened, (n) => n.props?.role === 'dialog')[0]
check('the detail panel draws one bar per window',
  countNodes(dialog, hasBar) === 3, `bars=${countNodes(dialog, hasBar)}`)
check('the detail panel names the quota source',
  openedText.includes('arkcli') && openedText.includes('来源'))
// 拆成两条：一条管 DOM 形状，一条管**生效的 CSS**。以前合成一条，只查渲染树里
// 出现了 `akc-detail` 字符串；把 `.akc-detail { position:fixed }` 改成 absolute
// 照样全绿 —— 而那正是"面板被侧边栏裁掉"的回归。
check('the detail panel renders exactly one dialog node',
  findNodes(opened, (n) => n.props?.role === 'dialog').length === 1
  && findNodes(opened, (n) => String(n.props?.className ?? '').split(/\s+/).includes('akc-detail')).length === 1,
  `dialogs=${findNodes(opened, (n) => n.props?.role === 'dialog').length}`)
check('the detail panel must be position:fixed (ancestors clip with overflow:hidden)',
  effective(CSS_RULES, el('div', 'akc-detail'), 'position') === 'fixed',
  '侧边栏是 overflow:hidden，绝对定位会被裁掉；祖先链上没有 transform/filter 能建立包含块，所以 fixed 是唯一安全解')
// --- 小数百分比：0.2% 不能显示成 0% ------------------------------------------
// 这个账号日常就在 0.1% ~ 1% 之间；一律取整会让卡片长期写着 "0%"，看着像没用量。
const tinyReport = () => {
  const base = currentReport()
  return {
    ...base,
    plan: {
      ...base.plan,
      windows: base.plan.windows.map((w) => ({ ...w, percent: w.key === 'session' ? 0.42 : 0.13 })),
    },
  }
}
usageReportFn = async () => ({ ok: true, value: tinyReport() })
await controller.refreshUsage()
resetCursor()
const tinyText = JSON.stringify(deepRender(localSide.component(sideProps())))
check('a sub-1% window keeps one decimal instead of rounding to 0%',
  tinyText.includes('0.4%') && tinyText.includes('0.1%') && !tinyText.includes('0%'),
  tinyText.slice(0, 160))
usageReportFn = async () => ({ ok: true, value: currentReport() })
await controller.refreshUsage()

// --- 渲染 ---------------------------------------------------------------
function deepRender(node, keepHandlers = false) {
  renderDepth += 1
  try {
    return renderTree(node, keepHandlers)
  } finally {
    renderDepth -= 1
    // 渲染全部结束后才执行 effect —— 见 React.useEffect 的注释。
    if (renderDepth === 0) flushEffects()
  }
}
function renderTree(node, keepHandlers = false) {
  if (node === null || node === undefined || typeof node !== 'object') return node
  if (Array.isArray(node)) return node.map((child) => deepRender(child, keepHandlers))
  const { type, props } = node
  if (typeof type === 'function') { resetHooks(); return deepRender(type(props), keepHandlers) }
  const rendered = {}
  for (const [key, value] of Object.entries(props ?? {})) {
    if (key === 'children' || (typeof value === 'function' && keepHandlers !== true)) continue
    rendered[key] = value
  }
  rendered.children = deepRender(props?.children, keepHandlers)
  return { type, props: rendered }
}

/** 用当前 controller 状态渲染一次设置页（`keepHandlers` 保留 onClick，便于点按钮）。 */
function renderSettings(keepHandlers = false) {
  const face = typeof sectionRegistration.options.inject === 'function' ? sectionRegistration.options.inject() : {}
  const t = (key) => localeRegistrations.find((entry) => entry.ns === sectionRegistration.options.locale)?.copy?.zh?.[key] ?? key
  resetHooks()
  return deepRender(sectionRegistration.component({ ...face, t, close: () => {}, keyConfigured: false }), keepHandlers)
}

for (const registration of slotRegistrations) {
  const face = typeof registration.options.inject === 'function' ? registration.options.inject() : {}
  const t = (key) => localeRegistrations.find((entry) => entry.ns === registration.options.locale)?.copy?.zh?.[key] ?? key
  let tree
  try {
    // 每次都从干净的钩子槽开始：组件内部的 useState/useRef 是按索引取的，
    // 留着上一次渲染的槽位会让"详情面板已打开"这种状态泄漏到别的测试里。
    resetHooks()
    tree = deepRender(registration.component({ ...face, t, close: () => {}, keyConfigured: false }))
  } catch (error) {
    check(`renders ${registration.options.name}`, false, String(error))
    continue
  }
  const text = JSON.stringify(tree)
  check(`renders ${registration.options.name}`, tree !== undefined && tree !== null, `nodes=${text.length}`)
  if (registration.options.name === 'settings.section') {
    check('the settings page shows all four cards',
      text.includes('账户') && text.includes('模型') && text.includes('用量与显示') && text.includes('高级设置'))
    check('the settings page lists the twelve models with their facts',
      text.includes('Doubao-Seed-Evolving') && text.includes('Kimi-K3') && text.includes('1M'))
    check('the settings page shows the plan windows with percentages',
      text.includes('5 小时') && text.includes('"12%"') && text.includes('每周') && text.includes('"34%"'),
      'plan windows rendered')
    check('the settings page exposes the AK/SK fields',
      text.includes('AccessKey ID') && text.includes('Secret 凭据引用'))
    const sidebarSelect = findNodes(tree, (n) => n.type === 'select')
    check('the settings page has a three-state control for the sidebar card',
      sidebarSelect.length === 1 && sidebarSelect[0].props['aria-label'] === '侧边栏用量卡片'
      && JSON.stringify(sidebarSelect[0].props.children.map((o) => o.props.value)) === '["auto","on","off"]',
      JSON.stringify(sidebarSelect[0]?.props?.children?.map((o) => o.props?.value)))
    check('the settings page groups plan quota per account',
      text.includes('工作账号') && text.includes('账户额度') && text.includes('API Key 账户查不到套餐额度'))
  } else if (registration.options.name === 'sidebar.footer.action') {
    check('the sidebar card shows the 5-hour and weekly windows only',
      text.includes('5 小时') && text.includes('12%') && text.includes('本周') && text.includes('34%')
      && !text.includes('每月') && !text.includes('8%'),
      text.slice(0, 160))
    check('the sidebar card marks the plan as the source', text.includes('套餐额度'))
    check('plan mode shows no misleading local note', !text.includes('非套餐额度'))
    check('the sidebar card is a collapsed button that opens the details',
      tree.type === 'button' && tree.props.className.includes('akc-side')
      && tree.props['aria-expanded'] === false)
  } else {
    // 提供商卡片改成账户感知之后：只报"正在用哪个账户"，不再有粘贴密钥的输入框
    // （顶层 apiKeyEnv/apiKey 已经退役，写进去也没人读）。
    check('the provider card names the account in use and shows readiness',
      text.includes('工作账号') && text.includes('已就绪'),
      text.slice(0, 160))
    check('the provider card no longer renders a key input',
      findNodes(tree, (n) => n.type === 'input' || (typeof n.props?.className === 'string' && n.props.className.includes('akc-input'))).length === 0,
      `inputs=${findNodes(tree, (n) => n.type === 'input').length}`)
    check('the provider card reports the quota source when plan quota works',
      text.includes('额度来源') && text.includes('套餐额度'))
  }
}

// --- 用量面板：契约 §2.3 -----------------------------------------------------
// (a) 一个账户都查不到额度时：不画任何条，也不拿本机数字顶上，只如实说缺什么。
usageReportFn = async () => ({ ok: true, value: localOnlyReport() })
await controller.refreshUsage()
const localSettingsTree = renderSettings()
check('no plan quota renders NO bars on the settings page',
  countNodes(localSettingsTree, hasBar) === 0, `bars=${countNodes(localSettingsTree, hasBar)}`)
const localSettingsText = JSON.stringify(localSettingsTree)
check('no plan quota explains what is missing instead of drawing a denominator-less bar',
  localSettingsText.includes('查不到套餐额度') || localSettingsText.includes('AK/SK'),
  localSettingsText.includes('本机统计') ? '本机统计应该已经删掉了' : '')
check('the settings page no longer mentions local accounting at all',
  !localSettingsText.includes('本机统计') && !localSettingsText.includes('非套餐额度'))

// (b) hasTotals === true 时才允许显示 used / total，且绝不编"剩余"。
const planAccountsSaved = reportBase.plan.accounts
reportBase.plan = {
  ...reportBase.plan,
  accounts: [
    { ...planAccountsSaved[0], windows: PLAN_WINDOWS.map((w) => (w.key === 'session' ? { ...w, hasTotals: true, used: 12000, total: 100000 } : w)) },
    planAccountsSaved[1],
  ],
}
usageReportFn = async () => ({ ok: true, value: currentReport() })
await controller.refreshUsage()
const totalsTree = renderSettings()
const windowValues = findNodes(totalsTree, (n) => typeof n.props?.className === 'string'
  && n.props.className.split(/\s+/).includes('akc-windowValue')).map((n) => n.props.children)
check('a hasTotals window also shows used / total',
  windowValues.includes('12% · 已用 / 总量 12K / 98K'), JSON.stringify(windowValues))
check('a window without hasTotals shows the percentage only, never an invented remainder',
  windowValues.includes('34%') && !windowValues.some((value) => typeof value === 'string' && value.includes('34% ·')),
  JSON.stringify(windowValues))
reportBase.plan = { ...reportBase.plan, accounts: planAccountsSaved }
await controller.refreshUsage()

// --- 添加账户：类型选择 + 可选名字（契约 §4） --------------------------------
controller.openAddAccount()
const addTree = renderSettings()
check('the add-account flow offers a type picker with both account types',
  countNodes(addTree, (n) => typeof n.props?.className === 'string' && n.props.className.includes('akc-typePicker')) === 2,
  `pickers=${countNodes(addTree, (n) => typeof n.props?.className === 'string' && n.props.className.includes('akc-typePicker'))}`)
const addText = JSON.stringify(addTree)
check('the type picker names API Key and CLI sign-in',
  addText.includes('API Key') && addText.includes('CLI 登录'))
check('the add-account flow asks for an optional name',
  addText.includes('名称（可选）') && addText.includes('留空'))

controller.setAddAccount({ type: 'apikey', name: '', key: 'ark-account-two-key' })
const addedKeyAccount = await controller.confirmAddAccount()
const storedKeyAccount = (storedSettings.accounts ?? []).find((account) => account.id === addedKeyAccount.accountId)
check('adding an API Key account with an empty name still works',
  addedKeyAccount.ok === true && storedKeyAccount !== undefined && storedKeyAccount.type === 'apikey',
  JSON.stringify(addedKeyAccount))
check('an empty name is left empty so the host supplies the default label',
  storedKeyAccount?.label === '', `label=${JSON.stringify(storedKeyAccount?.label)}`)
check('a new API Key account gets a colliding-free credential ref',
  typeof storedKeyAccount?.apiKeyEnv === 'string'
  && storedKeyAccount.apiKeyEnv.startsWith('ARK_CODING_API_KEY_')
  && !INITIAL_ACCOUNTS.some((account) => account.apiKeyEnv === storedKeyAccount.apiKeyEnv),
  String(storedKeyAccount?.apiKeyEnv))
check('the API key goes through the credential store, never the settings document',
  configuredRefs.has(storedKeyAccount?.apiKeyEnv) && JSON.stringify(storedKeyAccount).indexOf('ark-account-two-key') === -1,
  JSON.stringify(storedKeyAccount))
// 账户数组**按路径最小写入**：追加新行是 `set path:['accounts', N]`，不是整数组回写
// （整数组回写会把带 secret 角色的字面量密钥从配置里静默抹掉）。这条同时钉住
// 假 `settings.mutate` 必须真的支持数组下标路径。
{
  const appendOps = mutateCalls.at(-1)?.ops ?? []
  check('adding an account appends through an array-index path op, not a whole-array write',
    appendOps.length === 1 && appendOps[0].op === 'set'
    && Array.isArray(appendOps[0].path) && appendOps[0].path.length === 2
    && appendOps[0].path[0] === 'accounts' && appendOps[0].path[1] === String(storedSettings.accounts.length - 1)
    && Array.isArray(storedSettings.accounts),
    JSON.stringify(appendOps))
}
const afterAddTree = renderSettings()
const defaultLabel = accountStatesFromSettings().find((account) => account.id === addedKeyAccount.accountId)?.label
check('the account row shows the host default label when the name was left blank',
  typeof defaultLabel === 'string' && defaultLabel !== '' && JSON.stringify(afterAddTree).includes(defaultLabel),
  String(defaultLabel))
{
  // 移除账户 = 数组下标上的 unset（真实现的 splice），删掉这一行而不是留空洞。
  const beforeRemove = storedSettings.accounts.length
  const removed = await controller.removeAccount(addedKeyAccount.accountId)
  const removeOps = mutateCalls.at(-1)?.ops ?? []
  check('removing an account unsets its array index (splice) instead of rewriting the array',
    removed === true
    && removeOps.some((op) => op.op === 'unset' && Array.isArray(op.path)
      && op.path.length === 2 && op.path[0] === 'accounts' && /^(0|[1-9][0-9]*)$/.test(op.path[1]))
    && storedSettings.accounts.length === beforeRemove - 1
    && !storedSettings.accounts.some((account) => account.id === addedKeyAccount.accountId),
    JSON.stringify({ removed, removeOps, left: storedSettings.accounts.length }))
}

{
  // 0.5.1 的真 bug：数字下标过不了 0.2.1-rc.2 的 Typert 边界（`path: string[]`），
  // 任何账户操作都只剩一句「保存失败」。这里钉住"所有路径段都是字符串"。
  const allOps = mutateCalls.flatMap((call) => call.ops ?? [])
  check('every settings path op uses string segments (Typert wire schema is string[])',
    allOps.length > 0 && allOps.every((op) => Array.isArray(op.path) && op.path.length > 0
      && op.path.every((segment) => typeof segment === 'string')),
    JSON.stringify(allOps.slice(0, 4)))
  let numericRejected = false
  try { applyPathOp(storedSettings, { op: 'set', path: ['accounts', 0], value: {} }) } catch { numericRejected = true }
  check('a numeric path segment is rejected by the wire contract (the fake mirrors the gateway)',
    numericRejected === true)
}

// --- CLI 登录向导（契约 §4.2） ---------------------------------------------
controller.openAddAccount()
controller.setAddAccount({ type: 'cli', name: '' })
const addedCliAccount = await controller.confirmAddAccount()
check('adding a CLI account starts the login handshake immediately',
  addedCliAccount.ok === true && controller.store.get().login.accountId === addedCliAccount.accountId
  && controller.store.get().login.phase === 'waiting',
  JSON.stringify({ added: addedCliAccount, login: controller.store.get().login }))
check('loginBegin is called with exactly one object argument',
  loginBeginCalls.length >= 1
  && loginBeginCalls.every((arg) => arg !== null && typeof arg === 'object' && !Array.isArray(arg) && typeof arg.accountId === 'string'),
  JSON.stringify(loginBeginCalls))

const wizardTree = renderSettings()
const wizardText = JSON.stringify(wizardTree)
const authorizeUrl = 'https://console.volcengine.com/ark/authorize?callbackPort=39171'
check('the wizard renders the authorize URL as text', wizardText.includes(authorizeUrl))
check('the wizard offers a real open control pointing at the authorize URL',
  findNodes(wizardTree, (n) => n.type === 'a' && n.props?.href === authorizeUrl
    && n.props?.target === '_blank' && typeof n.props?.['aria-label'] === 'string').length === 1)
check('the wizard offers a labelled copy control',
  findNodes(wizardTree, (n) => typeof n.props?.className === 'string' && n.props.className.includes('akc-loginCopy')
    && typeof n.props?.['aria-label'] === 'string').length === 1)
check('the wizard explains that the 127.0.0.1 redirect failing to load is expected',
  // 回跳地址实测是 `http://127.0.0.1:<port>`（不是 localhost），所以向导必须按用户
  // 真正会在地址栏里看到的东西来说，否则用户照着 "localhost" 去找会对不上。
  wizardText.includes('127.0.0.1') && wizardText.includes('这是正常的'),
  'the ferry step is the whole point of the wizard')
check('the wizard surfaces the host hint', wizardText.includes('这是正常的'))
check('the wizard announces its state with a progress indicator',
  findNodes(wizardTree, (n) => n.type === 'li' && typeof n.props?.className === 'string' && n.props.className.split(/\s+/).includes('akc-step')).length === 3
  && findNodes(wizardTree, (n) => n.props?.['aria-live'] === 'polite').length >= 1)
check('the wizard has a focusable paste field for the callback URL',
  findNodes(wizardTree, (n) => n.type === 'input' && typeof n.props?.className === 'string'
    && n.props.className.includes('akc-loginPaste') && typeof n.props?.['aria-label'] === 'string').length === 1)

// 轮询到 done：进成功态，并刷新报告
loginPollFn = async (input) => ({ ok: true, value: { ok: true, accountId: input.accountId, state: 'done', identity: { userName: 'nala-done' } } })
await controller.loginPoll(addedCliAccount.accountId)
check('loginPoll drives the wizard to the success state',
  controller.store.get().login.phase === 'done'
  && controller.store.get().login.identity?.userName === 'nala-done',
  JSON.stringify(controller.store.get().login))
check('loginPoll is called with exactly one object argument',
  loginPollCalls.length >= 1 && loginPollCalls.every((arg) => arg !== null && typeof arg === 'object' && !Array.isArray(arg)),
  JSON.stringify(loginPollCalls))
const doneTree = renderSettings()
check('the success state shows the identity from the host',
  JSON.stringify(doneTree).includes('nala-done') && JSON.stringify(doneTree).includes('登录成功'))
check('a successful CLI login prefills a blank name from the identity',
  (storedSettings.accounts ?? []).find((account) => account.id === addedCliAccount.accountId)?.label === 'nala-done',
  String((storedSettings.accounts ?? []).find((account) => account.id === addedCliAccount.accountId)?.label))
{
  // 改名只写 `label` 一个字段：`set path:['accounts', i, 'label']`。
  const renameOp = mutateCalls.flatMap((call) => call.ops ?? [])
    .find((op) => op.op === 'set' && Array.isArray(op.path) && op.path.length === 3
      && op.path[0] === 'accounts' && op.path[2] === 'label' && op.value === 'nala-done')
  check('renaming an account writes only the label field at its array path',
    renameOp !== undefined, JSON.stringify(renameOp ?? null))
}

// loginSubmit 报错必须显示出来，而不是静默吞掉
await controller.loginBegin(addedCliAccount.accountId)
loginSubmitFn = async (input) => ({
  ok: true,
  value: { ok: false, accountId: input.accountId, state: 'error', error: '回调地址无效：缺少 code' },
})
const submitResult = await controller.loginSubmit(addedCliAccount.accountId, 'http://localhost:39171/arkcli/broker/callback')
check('a loginSubmit error is surfaced on the wizard state',
  submitResult.ok === false && controller.store.get().login.phase === 'error'
  && controller.store.get().login.error === '回调地址无效：缺少 code',
  JSON.stringify({ submitResult, login: controller.store.get().login }))
check('loginSubmit is called with one object carrying accountId + input',
  loginSubmitCalls.length >= 1
  && loginSubmitCalls.every((arg) => arg !== null && typeof arg === 'object' && !Array.isArray(arg)
    && typeof arg.accountId === 'string' && typeof arg.input === 'string'),
  JSON.stringify(loginSubmitCalls.slice(-1)))
check('the submit error is rendered, not swallowed',
  JSON.stringify(renderSettings()).includes('回调地址无效：缺少 code'))

// 取消：关掉向导但**不**移除账户
const cancelOk = await controller.loginCancel(addedCliAccount.accountId)
check('cancel calls loginCancel with one object argument and closes the wizard',
  cancelOk === true && loginCancelCalls.length >= 1
  && loginCancelCalls.every((arg) => arg !== null && typeof arg === 'object' && !Array.isArray(arg))
  && controller.store.get().login.phase === 'idle',
  JSON.stringify(loginCancelCalls))
check('cancelling the wizard keeps the account in the list',
  controller.accountRows().some((account) => account.id === addedCliAccount.accountId))

// 重新登录：CLI 账户行有入口，重新走 loginBegin
controller.loginBegin(addedCliAccount.accountId)
const reloginCalls = loginBeginCalls.length
const reloginTree = renderSettings(true)
const reloginButtons = findNodes(reloginTree, (n) => typeof n.props?.className === 'string' && n.props.className.includes('akc-relogin'))
check('CLI account rows expose a re-login control', reloginButtons.length >= 1, `buttons=${reloginButtons.length}`)
reloginButtons[0].props.onClick()
await flush()
check('the re-login control calls loginBegin again for that account',
  loginBeginCalls.length === reloginCalls + 1, `calls=${loginBeginCalls.length - reloginCalls}`)
await controller.loginCancel(addedCliAccount.accountId)

// --- 官方目录对照（契约 §2.4） --------------------------------------------
const catalogTree = renderSettings()
const catalogText = JSON.stringify(catalogTree)
const conflictRow = findNodes(catalogTree, (n) => n.props?.['data-model-id'] === 'glm-5.3-flash')[0]
const conflictText = JSON.stringify(conflictRow ?? {})
check('a catalog conflict is flagged visibly, not silently overwritten',
  conflictText.includes('两处不一致')
  && findNodes(catalogTree, (n) => typeof n.props?.className === 'string' && n.props.className.includes('akc-conflict')).length >= 1,
  conflictText.slice(0, 160))
check('the measured value stays primary next to the official one',
  conflictText.includes('128K') && conflictText.includes('256K') && conflictText.includes('64K'),
  'measured 128K / official 256K + 64K')
check('the official catalog is labelled as such',
  catalogText.includes('官方目录') && catalogText.includes('实测'))
check('unmatched official models are surfaced with a sample',
  (() => {
    const node = findNodes(catalogTree, (n) => typeof n.props?.className === 'string' && n.props.className.includes('akc-catalogUnmatched'))[0]
    const text = JSON.stringify(node ?? {})
    return text.includes('官方目录里还有') && text.includes('8') && text.includes('doubao-seed-3.0')
  })(), 'the “newer models exist” signal')
check('catalogRefresh is wired to a labelled refresh button',
  findNodes(catalogTree, (n) => typeof n.props?.className === 'string' && n.props.className.includes('akc-catalogRefresh')
    && typeof n.props?.children !== 'undefined').length === 1)
const catalogResult = await controller.catalogRefresh()
check('catalogRefresh calls the host and replaces the catalog in place',
  catalogResult === true && catalogRefreshCalls === 1
  && Array.isArray(controller.store.get().usage.catalog.conflicts)
  && controller.store.get().usage.catalog.conflicts.length === 0,
  `calls=${catalogRefreshCalls}`)
check('the conflict badge disappears after a refresh that resolved it',
  !JSON.stringify(renderSettings()).includes('两处不一致'))

// --- arkcli 状态/安装（契约 §2.5） ----------------------------------------
reportBase.catalog = catalogFixture
reportBase.cli = { installed: false, error: undefined }
await controller.refreshUsage()
const notInstalledTree = renderSettings(true)
const installButtons = findNodes(notInstalledTree, (n) => typeof n.props?.className === 'string' && n.props.className.includes('akc-install'))
check('the install button appears when arkcli is not installed',
  installButtons.length === 1 && JSON.stringify(notInstalledTree).includes('安装 arkcli'),
  `buttons=${installButtons.length}`)
check('the install button is a real button carrying its label',
  installButtons[0]?.type === 'button' && installButtons[0]?.props?.children === '安装 arkcli')
installButtons[0].props.onClick()
await flush()
await flush()
check('the install button calls cliInstall', cliInstallCalls === 1, `calls=${cliInstallCalls}`)
check('cliInstall re-reports so the status line updates',
  controller.store.get().usage.cli.installed === true && reportBase.cli.installed === true)
const installedTree = renderSettings(true)
check('the install button disappears once arkcli is installed',
  findNodes(installedTree, (n) => typeof n.props?.className === 'string' && n.props.className.includes('akc-install')).length === 0
  && JSON.stringify(installedTree).includes('1.0.39'),
  'version line shown instead')

// --- 迁移：设置文档没有 accounts 时从报告播种（契约 §3） --------------------
delete storedSettings.accounts
await controller.loadSettings()
await controller.refreshUsage()
const seeded = controller.accountRows()
check('an empty accounts array is seeded from the host report',
  seeded.length === 2 && seeded[0].id === 'default' && seeded[0].type === 'apikey'
  && seeded[1].id === 'acct-cli-1' && seeded[1].type === 'cli',
  JSON.stringify(seeded))
const migrationBefore = mutateCalls.length
await controller.save()
const migrationOp = mutateCalls[migrationBefore]?.ops?.find((op) => op.path[0] === 'accounts')
check('the first save writes the full accounts array',
  Array.isArray(migrationOp?.value) && migrationOp.value.length === 2
  && migrationOp.value[0].apiKeyEnv === 'ARK_CODING_API_KEY',
  JSON.stringify(migrationOp?.value ?? null))

// --- CLI 凭据有效期（宿主新增 credentialExpiresAt） --------------------------
// 到期是服务端事实（真机实测 2026-12-15），界面显示算出来的具体日期，
// 读不到就什么都不说 —— 绝不写死"每 N 天"、也不编一个日期。
const pad2 = (value) => String(value).padStart(2, '0')
const dayOf = (ms) => {
  const date = new Date(ms)
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`
}
const expiryNodes = (tree) => findNodes(tree, (n) => typeof n.props?.className === 'string'
  && n.props.className.split(/\s+/).includes('akc-expiry'))
const reloginNodes = (tree) => findNodes(tree, (n) => typeof n.props?.className === 'string'
  && n.props.className.split(/\s+/).includes('akc-relogin'))

const farFuture = Date.now() + 60 * 86_400_000
cliCredentialExpiresAt = farFuture
await controller.loadSettings()
await controller.refreshUsage()
const farTree = renderSettings()
const farExpiry = expiryNodes(farTree)[0]
check('a signed-in CLI account shows the concrete credential expiry date',
  farExpiry !== undefined && JSON.stringify(farExpiry).includes('凭据有效期至')
  && JSON.stringify(farExpiry).includes(dayOf(farFuture))
  && farExpiry.props.className.includes('akc-hint'),
  JSON.stringify(farExpiry?.props?.children ?? null))
check('a credential far from expiry is not dressed up as a warning',
  farExpiry !== undefined && !farExpiry.props.className.includes('warn') && !farExpiry.props.className.includes('err'))
check('a healthy credential keeps Sign in again a secondary action',
  reloginNodes(farTree).length >= 1 && reloginNodes(farTree).every((node) => !node.props.className.includes('primary')),
  JSON.stringify(reloginNodes(farTree).map((node) => node.props.className)))

cliCredentialExpiresAt = Date.now() + 3 * 86_400_000
await controller.refreshUsage()
const soonExpiry = expiryNodes(renderSettings())[0]
check('a credential expiring within 7 days gets the softer warn note',
  soonExpiry !== undefined && soonExpiry.props.className.includes('akc-note warn')
  && JSON.stringify(soonExpiry).includes('凭据将在 3 天后到期'),
  JSON.stringify(soonExpiry?.props?.children ?? null))

const past = Date.now() - 86_400_000
cliCredentialExpiresAt = past
await controller.refreshUsage()
const pastTree = renderSettings()
const pastExpiry = expiryNodes(pastTree)[0]
check('an expired credential is a clear re-sign-in warning',
  pastExpiry !== undefined && pastExpiry.props.className.includes('akc-note err')
  && JSON.stringify(pastExpiry).includes('凭据已过期') && JSON.stringify(pastExpiry).includes('需要重新登录')
  && JSON.stringify(pastExpiry).includes(dayOf(past)),
  JSON.stringify(pastExpiry?.props?.children ?? null))
check('an expired credential makes Sign in again the obvious action',
  reloginNodes(pastTree).some((node) => node.props.className.includes('primary')),
  JSON.stringify(reloginNodes(pastTree).map((node) => node.props.className)))
check('the expiry warning is announced to assistive tech',
  pastExpiry !== undefined && pastExpiry.props.role === 'status')

cliCredentialExpiresAt = undefined
await controller.refreshUsage()
const unknownTree = renderSettings()
check('an unreadable credential expiry makes no claim at all',
  expiryNodes(unknownTree).length === 0
  && !JSON.stringify(unknownTree).includes('凭据有效期至')
  && !JSON.stringify(unknownTree).includes('凭据已过期'),
  `nodes=${expiryNodes(unknownTree).length}`)

// --- 添加账户：类型说明随选择变化（契约 §4） --------------------------------
const typeNote = (tree) => findNodes(tree, (n) => typeof n.props?.className === 'string'
  && n.props.className.split(/\s+/).includes('akc-typeNote'))[0]
controller.openAddAccount()
controller.setAddAccount({ type: 'apikey' })
const apiKeyNote = typeNote(renderSettings())
controller.setAddAccount({ type: 'cli' })
const cliNote = typeNote(renderSettings())
check('the type picker has a note that switches with the selection',
  apiKeyNote !== undefined && cliNote !== undefined
  && apiKeyNote.props['data-account-type'] === 'apikey' && cliNote.props['data-account-type'] === 'cli'
  && JSON.stringify(apiKeyNote) !== JSON.stringify(cliNote),
  JSON.stringify([apiKeyNote?.props?.['data-account-type'], cliNote?.props?.['data-account-type']]))
check('the API Key note says quota and the catalog need SSO or an AK/SK pair',
  JSON.stringify(apiKeyNote).includes('AK/SK') && JSON.stringify(apiKeyNote).includes('查不到')
  && JSON.stringify(apiKeyNote).includes('用量与显示'))
check('the CLI note promises the chat key, the real quota and the official catalog',
  JSON.stringify(cliNote).includes('API Key') && JSON.stringify(cliNote).includes('5 小时')
  && JSON.stringify(cliNote).includes('官方模型目录'))
check('the CLI note admits the credential is time-limited',
  JSON.stringify(cliNote).includes('凭据有时效'),
  'a time-limited SSO credential must not be presented as permanent')

// 报告里已经有这个账户的到期时间时，CLI 说明直接给出具体日期。
cliCredentialExpiresAt = farFuture
await controller.refreshUsage()
controller.setAddAccount({ type: 'cli', id: 'acct-cli-1' })
const datedNote = typeNote(renderSettings())
check('the CLI note shows the concrete expiry date once the host reports one',
  datedNote !== undefined && JSON.stringify(datedNote).includes(dayOf(farFuture)),
  JSON.stringify(datedNote?.props?.children ?? null))
controller.setAddAccount({ type: 'cli' })
controller.cancelAddAccount()
cliCredentialExpiresAt = undefined
await controller.refreshUsage()

// --- 没有账户：空状态 + 显眼的「添加账户」 ----------------------------------
// 宿主不再合成 default 账户：`accounts: []` 就是"一个账户都没有"，
// 卡片必须明确说出来，而不是静默渲染成空白。
storedSettings.accounts = []
await controller.loadSettings()
await controller.refreshUsage()
const emptyTree = renderSettings(true)
const emptyText = JSON.stringify(emptyTree)
const emptyBoxes = findNodes(emptyTree, (n) => typeof n.props?.className === 'string'
  && n.props.className.split(/\s+/).includes('akc-empty'))
check('an empty accounts array renders the empty state, not a blank card',
  emptyBoxes.length === 1 && emptyText.includes('还没有账户') && emptyText.includes('聊天至少需要一个账户'),
  `empty=${emptyBoxes.length}`)
check('the empty state explains the difference between the two account types',
  emptyText.includes('API Key') && emptyText.includes('CLI 登录') && emptyText.includes('AK/SK'))
check('the empty state keeps Add account present and prominent',
  findNodes(emptyTree, (n) => typeof n.props?.className === 'string'
    && n.props.className.split(/\s+/).includes('akc-addAccount')
    && n.props.className.split(/\s+/).includes('primary')).length === 1,
  'the only useful action on an empty card should read as the primary one')
check('an empty accounts array renders no account rows and no expiry claims',
  controller.accountRows().length === 0 && emptyText.includes('账户 · 0'))

// --- 提供商卡片：账户感知，不再挂密钥输入框 ---------------------------------
const providerRegistration = slotRegistrations.find((r) => r.options.name === 'settings.models.provider-card')
function renderProviderCard() {
  const face = typeof providerRegistration.options.inject === 'function' ? providerRegistration.options.inject() : {}
  const t = (key) => localeRegistrations.find((entry) => entry.ns === providerRegistration.options.locale)?.copy?.zh?.[key] ?? key
  return deepRender(providerRegistration.component({ ...face, t, keyConfigured: false }), true)
}
const providerEmpty = renderProviderCard()
check('with no accounts the provider card points at Settings → 火山方舟',
  JSON.stringify(providerEmpty).includes('还没有账户')
  && JSON.stringify(providerEmpty).includes('设置 → 火山方舟')
  && findNodes(providerEmpty, (n) => n.type === 'input').length === 0,
  JSON.stringify(providerEmpty).slice(0, 200))

storedSettings.accounts = [{ id: 'acct-api-x', label: '占位 API Key', type: 'apikey', apiKeyEnv: 'ARK_CODING_API_KEY_UNSET', home: '' }]
await controller.loadSettings()
await controller.refreshUsage()
const providerUnconfigured = renderProviderCard()
check('accounts that are not configured yet do not pretend the provider is ready',
  JSON.stringify(providerUnconfigured).includes('账户都还没配置好')
  && JSON.stringify(providerUnconfigured).includes('设置 → 火山方舟'),
  JSON.stringify(providerUnconfigured).slice(0, 200))

storedSettings.accounts = [{ id: 'acct-api-x', label: '占位 API Key', type: 'apikey', apiKeyEnv: 'ARK_CODING_API_KEY_SET', home: '' }]
configuredRefs.add('ARK_CODING_API_KEY_SET')
await controller.loadSettings()
await controller.refreshUsage()
const providerReady = renderProviderCard()
const providerReadyText = JSON.stringify(providerReady)
check('a configured account makes the provider card read as ready and names the account',
  providerReadyText.includes('已就绪') && providerReadyText.includes('占位 API Key')
  && providerReadyText.includes('当前使用'),
  providerReadyText.slice(0, 200))
check('the provider card still renders no key input when an account exists',
  findNodes(providerReady, (n) => n.type === 'input').length === 0)
// 旧断言是 `includes('额度来源') || !includes('套餐额度')` —— 恒真式：两个字符串
// 同时消失它也通过。改成两个夹具分别断言"有额度时有来源行 / 无额度时没有来源行"。
check('the provider card names the quota source when plan quota works',
  providerReadyText.includes('额度来源') && providerReadyText.includes('套餐额度'),
  providerReadyText.slice(0, 200))
usageReportFn = async () => ({ ok: true, value: localOnlyReport() })
await controller.refreshUsage()
const providerNoQuotaText = JSON.stringify(renderProviderCard())
check('the provider card shows no quota-source line when plan quota is unavailable',
  !providerNoQuotaText.includes('额度来源'), providerNoQuotaText.slice(0, 200))
usageReportFn = async () => ({ ok: true, value: currentReport() })
await controller.refreshUsage()

// --- 只读态（writable:false）与并发冲突（revision 不匹配） -------------------
// 以前 mock 恒 `writable:true`、revision 永远对得上，于是 `SETTINGS_CONFLICT` 与只读
// 这两条分支是死分支：把 `disabled = !state.writable || busy` 改成 `= busy` 也全绿。
{
  settingsWritable = false
  await controller.loadSettings()
  const readOnlyTree = renderSettings(true)
  check('a read-only document is announced as read-only',
    JSON.stringify(readOnlyTree).includes('当前设置是只读的。'))
  const roSelect = findNodes(readOnlyTree, (n) => n.type === 'select')[0]
  const roAdd = findNodes(readOnlyTree, (n) => String(n.props?.className ?? '').split(/\s+/).includes('akc-addAccount'))[0]
  const roInputs = findNodes(readOnlyTree, (n) => n.type === 'input')
  check('read-only disables every editable control (select, inputs, add-account)',
    roSelect?.props?.disabled === true && roAdd?.props?.disabled === true
    && roInputs.length > 0 && roInputs.every((node) => node.props.disabled === true),
    JSON.stringify({ select: roSelect?.props?.disabled, add: roAdd?.props?.disabled, inputs: roInputs.length }))
  const roSaveButtons = findNodes(readOnlyTree, (n) => n.type === 'button'
    && String(n.props?.className ?? '').split(/\s+/).includes('akc-btn')
    && String(n.props?.className ?? '').split(/\s+/).includes('primary')
    && n.props.children === '保存')
  check('read-only disables the Save buttons too',
    roSaveButtons.length >= 1 && roSaveButtons.every((node) => node.props.disabled === true),
    `save buttons=${roSaveButtons.length}`)
  settingsWritable = true
  await controller.loadSettings()
}

{
  // 并发冲突：另一个写入者先提交了，我们的 revision 已经过期。宿主必须整体拒绝；
  // 客户端必须让用户看到失败，且**旧值绝不能落盘**。
  const conflictBefore = JSON.stringify(storedSettings)
  controller.editField('apiBase', 'https://conflict.invalid')
  settingsRevision += 1
  const conflictSaved = await controller.save()
  check('a revision conflict is refused and reported instead of silently applied',
    conflictSaved === false && controller.store.get().notice?.kind === 'err'
    && controller.store.get().notice?.code === 'saveFailed',
    JSON.stringify(controller.store.get().notice))
  // 只显示「保存失败」等于让用户和排障的人都无从下手：宿主给的 message 必须带出来。
  const conflictNotice = controller.store.get().notice
  const conflictText = JSON.stringify(renderSettings(true))
  check('a rejected save shows the host error message, not just “Save failed”',
    conflictNotice?.text === 'SETTINGS_CONFLICT' && conflictText.includes('SETTINGS_CONFLICT'),
    JSON.stringify({ notice: conflictNotice, rendered: conflictText.includes('SETTINGS_CONFLICT') }))
  check('the stale write never reached the host document',
    JSON.stringify(storedSettings) === conflictBefore && storedSettings.apiBase !== 'https://conflict.invalid',
    JSON.stringify({ apiBase: storedSettings.apiBase, unchanged: JSON.stringify(storedSettings) === conflictBefore }))
}

{
  // 添加账户失败时，卡片里也要说清原因（不只是顶部那条 notice）。
  controller.openAddAccount()
  controller.setAddAccount({ type: 'cli', name: '' })
  const beforeAdd = JSON.stringify(storedSettings)
  settingsRevision += 1
  const failedAdd = await controller.confirmAddAccount()
  const addTreeText = JSON.stringify(renderSettings(true))
  check('a failed account add shows the host message inside the add card and writes nothing',
    failedAdd.ok === false && failedAdd.error === 'save-failed'
    && addTreeText.includes('SETTINGS_CONFLICT')
    && JSON.stringify(storedSettings) === beforeAdd,
    JSON.stringify({ failedAdd, stored: JSON.stringify(storedSettings) === beforeAdd }))
  controller.cancelAddAccount()
}

// --- 侧边栏卡片档位：三态 select 与配色 --------------------------------------
controller.editField('sidebarQuota', 'off')
const selectOff = findNodes(renderSettings(true), (n) => n.type === 'select')
check('the sidebar control reflects the draft value',
  selectOff.length === 1 && selectOff[0].props.value === 'off',
  JSON.stringify(selectOff[0]?.props?.value))
selectOff[0].props.onChange({ target: { value: 'on' } })
check('changing the control writes the new mode into the draft',
  controller.store.get().draft.sidebarQuota === 'on')
check('the mode is not clipped back to a boolean anywhere in the bundle',
  !source.includes('showSidebarQuota'), 'the retired boolean must be gone')
const selectElement = el('select', 'akc-select')
check('the control uses readable tokens in both themes (not a card-coloured track)',
  effective(CSS_RULES, selectElement, 'color') === 'var(--dsw-alias-label-primary)'
  && String(effective(CSS_RULES, selectElement, 'border')).includes('var(--dsw-alias-border-l2)')
  && effective(CSS_RULES, selectElement, 'background') === 'var(--dsw-alias-bg-layer-1)'
  && declaredValues(CSS_RULES, selectElement, 'background').every((value) => !value.includes('--dsw-alias-bg-layer-2')),
  JSON.stringify({ color: effective(CSS_RULES, selectElement, 'color'), border: effective(CSS_RULES, selectElement, 'border'), background: effective(CSS_RULES, selectElement, 'background') }))
check('no dead switch widget is left behind',
  !css.includes('akc-switch') && !source.includes('function Switch'),
  'the two-state switch was replaced by the three-state select')

// --- 深色主题下的可读性回归 ---------------------------------------------------
// 真机上量过：深色主题里 `--dsw-alias-brand-primary` 是**近白色**（#f9fafb），
// `--dsw-alias-bg-base` 才是深色（#151517）。所以"品牌底 + 写死 #fff"就是白字白底 ——
// 用户报的「左下角卡片上『套餐额度』几个字看不见」正是这一条。
check('on-brand surfaces use the on-brand foreground token, never a hard-coded white',
  effective(CSS_RULES, el('button', 'akc-btn primary'), 'color') === 'var(--dsw-alias-label-primary-foreground)'
  && effective(CSS_RULES, el('span', 'akc-pill brand'), 'color') === 'var(--dsw-alias-label-primary-foreground)'
  && effective(CSS_RULES, el('li', 'akc-step', [], { 'aria-current': 'step' }), 'color') === 'var(--dsw-alias-label-primary-foreground)'
  && !/color:\s*(#fff\b|#ffffff\b|white\b)/i.test(css),
  'brand-primary is near-white in dark mode; a literal white foreground disappears')
// success/warn 的 primary 色（#22c55e / #f59e0b）在白底上只有 ~2.2 的对比度，
// 当正文色用会看不清。正确做法是"浅色底 + 常态文字 + 彩色描边"。
check('state colours tint the background instead of colouring the text',
  effective(CSS_RULES, el('div', 'akc-note ok'), 'background') === 'var(--dsw-alias-state-success-tertiary)'
  && effective(CSS_RULES, el('div', 'akc-note warn'), 'background') === 'var(--dsw-alias-state-warn-tertiary)'
  && effective(CSS_RULES, el('span', 'akc-pill ok'), 'background') === 'var(--dsw-alias-state-success-tertiary)'
  && [el('div', 'akc-note ok'), el('div', 'akc-note warn'), el('span', 'akc-pill ok'), el('span', 'akc-pill warn')]
    .every((element) => declaredValues(CSS_RULES, element, 'color')
      .every((value) => !/--dsw-alias-state-(success|warn)-primary/.test(value))),
  'green/amber text on a white card measured 2.28:1 (AA needs 4.5:1)')
{
  // 历史上真正踩过的回归：浅色下 `.akc-bar` 的轨道用了 bg-layer-2（= 卡片底色），
  // 进度条槽整个隐形。旧断言只查"存在那条好规则"，末尾追加一条覆盖规则照样全绿。
  // 现在按生效值断言 —— 并顺带证明解析器确实会看到"后置同优先级覆盖"。
  const barElement = el('div', 'akc-bar')
  check('the progress track stays visible against the card in both themes',
    effective(CSS_RULES, barElement, 'background') === 'var(--dsw-alias-state-idle-primary)',
    'bg-layer-2 equals the card background, so the groove vanished')
  const withAppendedOverride = parseCss(`${css}\n.akc-bar { background:var(--dsw-alias-bg-layer-2); }`)
  check('...and an appended same-specificity override WOULD be caught (regression drill)',
    effective(withAppendedOverride, barElement, 'background') === 'var(--dsw-alias-bg-layer-2)'
    && effective(CSS_RULES, barElement, 'background') !== 'var(--dsw-alias-bg-layer-2)')
}

// --- 左下角卡片的密度 ---------------------------------------------------------
// 卡片每行只有"标签 + 百分比 + 一条 5px 细条"，行距 9px 在侧边栏里显得稀稀拉拉。
check('the sidebar card rows sit closer together',
  effective(CSS_RULES, el('div', 'akc-side'), 'gap') === '6px'
  && effective(CSS_RULES, el('div', 'akc-window', [], {}, [el('div', 'akc-side')]), 'gap') === '4px',
  'the footer card was 9px-gapped and read as sparse')

// --- effect 卫生：异常必须暴露，cleanup 保留到"卸载" -------------------------
// 旧假 useEffect 用 `catch {}` 吞掉 effect 里的一切异常，真机上炸了离线还是全绿。
check('no effect threw during any render in this suite',
  effectErrors.length === 0, effectErrors.map((error) => String(error?.message ?? error)).slice(0, 3).join(' | '))
// 卸载：所有收集到的 cleanup 都应该是函数，并且真的能执行而不抛。
{
  const cleanups = effectCleanups.splice(0)
  let cleanupError
  for (const cleanup of cleanups) {
    try { cleanup() } catch (error) { cleanupError = error }
  }
  check('every collected effect cleanup is a callable disposer',
    cleanups.length > 0 && cleanups.every((cleanup) => typeof cleanup === 'function') && cleanupError === undefined,
    `cleanups=${cleanups.length}${cleanupError === undefined ? '' : ` err=${String(cleanupError?.message ?? cleanupError)}`}`)
}

console.log(failures === 0 ? '\nALL PASS' : `\n${failures} FAILURE(S)`)
process.exit(failures === 0 ? 0 : 1)
