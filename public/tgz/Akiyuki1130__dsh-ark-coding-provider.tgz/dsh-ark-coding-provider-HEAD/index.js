/**
 * dsh-ark-coding-provider — 火山方舟（Volcengine Ark）Coding Plan 的 DeepSeek
 * Harness LLM 提供商插件（非官方社区集成）。
 *
 * 线路协议是 OpenAI 兼容的 `POST {base}/chat/completions`（SSE 流式）：
 * `https://ark.cn-beijing.volces.com/api/coding/v3`。因此适配器只做三件事：
 * 把 DSH 的规范化消息翻译成 OpenAI 形状、解析 SSE 成 StreamChunk、把失败归类成
 * DSH 的稳定失败码。没有反向工程的私有协议。
 *
 * 注册一个提供商路由 `ark-coding`，并在 configurable-provider 目录里登记，
 * 于是设置页会多出一张「火山方舟 Coding Plan」卡片、模型选择器里会列出这 12 个模型。
 * 连接事实（密钥、端点、超时）每次请求都从实时 Config 与凭据 seam 重新解析，
 * 所以改完密钥或端点下一个请求就生效，不需要重启。
 *
 * ```yaml
 * - id: llm-ark-coding
 *   name: "dsh-ark-coding-provider"
 *   config:
 *     apiKeyEnv: ARK_CODING_API_KEY
 * ```
 *
 * @module dsh-ark-coding-provider
 */

import { resolve as resolvePath, sep as pathSep } from 'node:path'
import z from '@deepseek-ai/schemastery'
import {
  EMPTY_RESPONSE_CODE,
  INVALID_CREDENTIAL_CODE,
  LlmAdapter,
  LlmError,
  assertUsableApiKey,
  attributionHeaders,
  isContextWindowExceededError,
  isQuotaExceededError,
  normalizeApiKey,
  offloadedImageText,
  projectOffloadedImages,
  requiredImageOffload,
  resolveRetryPolicy,
} from '@deepseek-ai/dsh-llm'
import { credentialRef, isCredentialRefName } from '@deepseek-ai/dsh-credentials'
import { launchEnvironmentOf } from '@deepseek-ai/dsh-launch-environment'
import { resolveDshHome } from '@deepseek-ai/dsh-home-paths'
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol'
import { EFFORT_WIRE, MODELS, annotateModels, modelById } from './models.js'
import {
  AccountMarks,
  TYPE_API_KEY,
  TYPE_CLI,
  cooldownFor,
  describeAccounts,
  orderAccounts,
  retryAfterMsOf,
  rotationReasonFor,
  sidebarQuotaState,
} from './accounts.js'
import { VOLC_DEFAULT_REGION, fetchCodingPlanUsage } from './usage.js'
import { ArkCli, ArkCliLogin, accountHomeDir, arkcliStateRoot, readCredentialExpiry } from './arkcli.js'

/** 本插件拥有的提供商路由 id。 */
export const PROVIDER = 'ark-coding'
/** 本插件的设置命名空间（也是 profile 里的条目 id）。 */
export const NS = 'llm-ark-coding'
export const name = 'llm-ark-coding'
export const inject = ['llm']

/** Coding Plan 的 OpenAI 兼容端点。 */
export const DEFAULT_API_BASE = 'https://ark.cn-beijing.volces.com/api/coding/v3'
export const DEFAULT_API_KEY_ENV = 'ARK_CODING_API_KEY'
export const DISPLAY_NAME = '火山方舟 Coding Plan'

/** 未配置时单次请求的 max_tokens 上限；会被逐模型输出上限夹住。 */
export const DEFAULT_MAX_OUTPUT_TOKENS = 65536
/** 首字节超时与流空闲超时。Coding Plan 会出现很长的思考，默认给足 5 分钟。 */
export const DEFAULT_REQUEST_TIMEOUT_MS = 300_000
export const DEFAULT_STREAM_IDLE_TIMEOUT_MS = 300_000
/** 单次请求内联图片（base64 后）的字节上限；超出即要求上层卸载最旧的图片。 */
export const DEFAULT_MAX_REQUEST_IMAGE_BYTES = 20 * 1024 * 1024
/** 请求版图片的长边上限与编码字节上限。 */
const REQUEST_IMAGE_MAX_LONG_EDGE = 1568
const REQUEST_IMAGE_MAX_ENCODED_BYTES = 1024 * 1024
/**
 * `Retry-After` 的采用上界（1 小时）。
 *
 * 服务端说什么就等什么是对的，但"说什么"可能是坏值：实测畸形值会把账户冷却到
 * ~1e23 ms，等于本进程内永久不可用。1 小时足够长（正常值都是秒级）又不会失控。
 */
const RETRY_AFTER_MAX_MS = 60 * 60_000
/**
 * 单条 SSE 行的字节上限。
 *
 * 不设上限时，一条巨型 `data:` 行会在内存里放大十几倍：实测 8/16/32/64 MB 输入
 * 分别让 RSS 涨 132/375/476/1082 MB、耗时 0.8/2.8/10.4/44 秒 —— 上游、被劫持的
 * 网关或坏代理塞一条就能把宿主拖垮，而 `apiBase` 是可配置的。正常帧远小于 1 MB。
 */
const MAX_SSE_LINE_BYTES = 8 * 1024 * 1024
/** setTimeout 的可靠上界。 */
const MAX_TIMER_DELAY_MS = 2_147_483_647

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

/** 标一个 schema 字段为易变（volatile）——设置页只能写被标记的节点。 */
function markVolatile(schema) {
  return schema.volatile()
}

/** 逐个标记顶层字段为易变，`apiKey` 字面量除外（没有页面会写它）。 */
function markVolatileFields(fields, skip = []) {
  return Object.fromEntries(
    Object.entries(fields).map(([key, schema]) => [key, skip.includes(key) ? schema : markVolatile(schema)]),
  )
}

/**
 * 插件配置。被标记为易变的字段由设置页改写，加载器就地提交并热重载，
 * 因此 `current()` 每次读取都要拆开 volatile 引用。
 */
export const Config = z.object(markVolatileFields({
  apiKeyEnv: z.string().role('credential-ref').default(DEFAULT_API_KEY_ENV),
  // 字面量密钥：只有组合配置会写它，因此保持非易变，并且必须带 secret 角色，
  // 否则它会随设置描述一起回到浏览器。
  apiKey: z.string().role('secret'),
  apiBase: z.string().default(DEFAULT_API_BASE),
  requestTimeoutMs: z.number().min(1).max(MAX_TIMER_DELAY_MS).default(DEFAULT_REQUEST_TIMEOUT_MS),
  streamIdleTimeoutMs: z.number().min(1).max(MAX_TIMER_DELAY_MS).default(DEFAULT_STREAM_IDLE_TIMEOUT_MS),
  defaultMaxTokens: z.number().min(1).default(DEFAULT_MAX_OUTPUT_TOKENS),
  /** 允许出现在模型选择器里的模型 id；为空 = 全部可见。 */
  visibleModels: z.array(z.string()),
  /** 逐模型开关，覆盖 `visibleModels` 的批量结果。 */
  modelVisibility: z.dict(z.boolean()),
  /** 逐模型覆盖上下文长度（应对上游容量变化，不必等插件更新）。 */
  contextWindowOverrides: z.dict(z.number().min(1024)),
  /**
   * 账户池。**账户主要写在这里**（设置页保存后全部落在这）。
   *
   * 另外有一条**兜底**：`accounts` 为空时，顶层 `apiKeyEnv` / `apiKey` 会被当作一个
   * id 为 `default` 的 API Key 账户（见 `describeAccounts` 的第二个参数）。这不是
   * "隐式魔法"，而是官方 Models 页的密钥编辑器唯一能落地的地方 —— 它写的 ref 是从
   * provider 名推出来的 `ARK_CODING_API_KEY`，插件管不着；不读它就会出现"官方卡片
   * 显示已配置、聊天却说没有可用账户"。把 `apiKeyEnv` 显式设成空串即关闭这条兜底。
   *
   * 每个账户：
   * - `id`：稳定标识，CLI 账户的 HOME 目录名由它派生，所以不要随便改。
   * - `label`：显示名，可留空（留空则按类型显示「API Key 账户 N」）。
   * - `type`：`apikey`（手填 key）或 `cli`（arkcli SSO 登录）。
   * - `apiKeyEnv` / `apiKey`：只有 apikey 用得上。
   * - `home`：只有 cli 用得上；留空表示用 `<DSH_HOME>/ark-coding/accounts/<id>`。
   *   **显式值必须位于 `<DSH_HOME>/ark-coding` 之下**：它会成为 root 子进程的 HOME，
   *   允许任意路径等于让一次配置写入就能让 root 往任意目录写文件（见 `homeForAccount`）。
   */
  accounts: z.array(z.object({
    id: z.string(),
    label: z.string(),
    type: z.string().default(TYPE_API_KEY),
    apiKeyEnv: z.string().role('credential-ref'),
    /** 只在组合配置里写的字面量密钥；带 secret 角色，不会被设置描述回传。 */
    apiKey: z.string().role('secret'),
    home: z.string(),
  })),
  /** 配置里偏好的账户 id（`default` / `account-2` / …）；空 = 按顺序。 */
  activeAccount: z.string(),
  /**
   * 左下角用量卡片：`auto`（默认）/ `on` / `off`。
   *
   * `auto` 的判据是**有没有能取到套餐额度的绑定** —— 已登录的 CLI（SSO）账户，
   * 或一对填全了的 AK/SK。两者都没有时卡片根本不渲染（一张永远只写着"未配置"
   * 的卡片比没有卡片更烦人）；绑上之后它自动出现，不需要谁再去手动打开一次。
   *
   * 以前这里是 `z.boolean().default(true)`：schema 默认值会把「用户没配」填成
   * `true`，「自动」这一档就永远生效不了，所以改成显式三态字符串。
   */
  sidebarQuota: z.union(['auto', 'on', 'off']).default('auto'),
  /**
   * 套餐额度的**备选**来源：一对 AK/SK。
   *
   * 主路径已经是 arkcli（SSO 登录的账户自带 `usage plan`），这一对只在
   * "有 AK/SK、但不想装 arkcli / 不想 SSO 登录"时用得上：本插件自己按
   * Volcengine V4 签名调 `GetCodingPlanUsage`。注意 1.0.16 起 arkcli 已经
   * 关掉了 AK/SK 登录通道，所以这条路的凭据只能由用户手填。
   *
   * 只有 AccessKey ID 放在这里（它不是秘密），Secret 走凭据引用 `secretAccessKeyEnv`。
   */
  accessKeyId: z.string(),
  secretAccessKeyEnv: z.string().role('credential-ref').default('ARK_ACCESS_KEY_SECRET'),
  region: z.string().default(VOLC_DEFAULT_REGION),
  /** 显式指定 arkcli 可执行文件；留空则按「插件自装目录 → PATH」的顺序找。 */
  arkcliPath: z.string(),
  /** 官方模型目录的刷新间隔（秒）。目录是控制面数据，没必要每次轮询都拉。 */
  catalogRefreshSeconds: z.number().min(60).max(86_400).default(3600),
  /** 用量刷新间隔（秒）；卡片打开时按这个节奏轮询。 */
  usageRefreshSeconds: z.number().min(10).max(3600).default(60),
}, ['apiKey']))

/** 一个已解析的 volatile 引用。 */
function isVolatileRef(value) {
  return typeof value === 'object'
    && value !== null
    && !Array.isArray(value)
    && Object.isFrozen(value)
    && typeof value.get === 'function'
}

/** 把配置里的每个顶层 volatile 引用读成普通值（每次调用都新鲜）。 */
function unwrapVolatileConfig(config) {
  if (typeof config !== 'object' || config === null) return config
  const plain = {}
  for (const [key, value] of Object.entries(config)) {
    plain[key] = isVolatileRef(value) ? value.get() : value
  }
  return plain
}

/** 一个请求要用的完整连接事实。 */
function resolveConnection(config) {
  const rawBase = typeof config.apiBase === 'string' && config.apiBase.trim() !== ''
    ? config.apiBase.trim()
    : DEFAULT_API_BASE
  return {
    apiBase: rawBase.replace(/\/+$/, ''),
    // 顶层 `apiKeyEnv` 只在一个用途上被读到：`accounts` 为空时作为兜底账户的凭据引用
    // （见 `describeAccounts` 的第二参数）。官方 Models 页的密钥编辑器写的就是这个 ref。
    //
    // 以前这里对任意字符串直接调 `credentialRef()`，而它是**会抛的**：空串、或
    // `MY-KEY` 这种带 `-` 的名字（看着完全合法，但不符合凭据 ref 文法）都会让
    // `connection()` 整体抛错 —— 于是每一个请求、每一次 report() 都失败，设置页卡片
    // 也起不来，而那个字段当时根本没人读。现在先校验，非法/空就当"没有兜底"。
    fallbackRef: isValidRefName(config.apiKeyEnv) ? config.apiKeyEnv.trim() : undefined,
    literalApiKey: typeof config.apiKey === 'string' && config.apiKey.trim() !== '' ? config.apiKey.trim() : undefined,
    requestTimeoutMs: positive(config.requestTimeoutMs, DEFAULT_REQUEST_TIMEOUT_MS),
    streamIdleTimeoutMs: positive(config.streamIdleTimeoutMs, DEFAULT_STREAM_IDLE_TIMEOUT_MS),
    defaultMaxTokens: positive(config.defaultMaxTokens, DEFAULT_MAX_OUTPUT_TOKENS),
    visibleModels: Array.isArray(config.visibleModels) ? config.visibleModels.filter((id) => typeof id === 'string') : [],
    modelVisibility: isPlainObject(config.modelVisibility) ? config.modelVisibility : {},
    contextWindowOverrides: isPlainObject(config.contextWindowOverrides) ? config.contextWindowOverrides : {},
    /** 账号定义（尚未解析 key）。 */
    accounts: describeAccounts(config, isValidRefName(config.apiKeyEnv) ? config.apiKeyEnv.trim() : undefined),
    activeAccount: typeof config.activeAccount === 'string' ? config.activeAccount : '',
    sidebarQuota: config.sidebarQuota === 'on' || config.sidebarQuota === 'off' ? config.sidebarQuota : 'auto',
    accessKeyId: typeof config.accessKeyId === 'string' ? config.accessKeyId.trim() : '',
    secretAccessKeyEnv: typeof config.secretAccessKeyEnv === 'string' && config.secretAccessKeyEnv !== ''
      ? config.secretAccessKeyEnv
      : 'ARK_ACCESS_KEY_SECRET',
    region: typeof config.region === 'string' && config.region.trim() !== '' ? config.region.trim() : VOLC_DEFAULT_REGION,
    arkcliPath: typeof config.arkcliPath === 'string' ? config.arkcliPath.trim() : '',
    catalogRefreshSeconds: positive(config.catalogRefreshSeconds, 3600),
    usageRefreshSeconds: positive(config.usageRefreshSeconds, 60),
  }
}

function positive(value, fallback) {
  return typeof value === 'number' && Number.isFinite(value) && value > 0 ? Math.trunc(value) : fallback
}

/**
 * 凭据引用名是否合法（文法 `^[A-Za-z_][A-Za-z0-9_]*$`）。
 *
 * `credentialRef()` 对不合法的名字**会直接抛**，而那个抛错发生在 `resolveRef` 里就会
 * 让整个账户被静默剔除（外层 catch 把它当成"这个账户没配 key"），用户只看到
 * "账户都还没有可用的 API key"，完全猜不到是自己 ref 名里有个 `-`。用户手填的 ref
 * 什么形状都可能有，所以先判断：不合法就跳过凭据服务，让启动环境（export/.env）兜底。
 */
function isValidRefName(value) {
  if (typeof value !== 'string') return false
  const trimmed = value.trim()
  if (trimmed === '') return false
  try { return isCredentialRefName(trimmed) === true } catch { return false }
}

function isPlainObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

/**
 * 摘掉属性值为 `undefined` 的键。
 *
 * **为什么需要它**：DSH 在把每一块流式内容落地之前会做一次"无损 JSON"校验
 * （`snapshotJsonValue`），而 `{ foo: undefined }` 这种**显式 undefined 属性**在 JSON
 * 里根本无法表示，于是被判成"不可无损序列化"，直接抛
 * `Assistant stream chunk must be losslessly JSON-serializable` —— 后果是
 * **整轮对话在最后一块上失败**。用户看到的现象就是"字都打出来了，然后突然没了"。
 *
 * 修 `{ finish, replayState: undefined }` 这一处只是治标：JS 里写 `foo: maybeUndefined`
 * 太顺手，下次随手加一个可选字段又会重演。所以放在流式内容的唯一出口兜一层 ——
 * JSON 语义上 `{ foo: undefined }` 与 `{}` 完全等价，摘掉是忠实的，不是掩盖。
 */
function withoutUndefined(chunk) {
  if (typeof chunk !== 'object' || chunk === null) return chunk
  for (const key of Object.keys(chunk)) {
    if (chunk[key] === undefined) delete chunk[key]
  }
  return chunk
}

// ---------------------------------------------------------------------------
// 目录投影
// ---------------------------------------------------------------------------

/** 一个模型在当前配置下的上下文长度（配置覆盖优先）。 */
function contextWindowOf(model, connection) {
  const override = connection.contextWindowOverrides[model.id]
  return positive(override, model.contextWindow)
}

/** 一个模型是否出现在模型选择器里。 */
function modelIsVisible(id, connection) {
  const explicit = connection.modelVisibility[id]
  if (typeof explicit === 'boolean') return explicit
  if (connection.visibleModels.length === 0) return true
  return connection.visibleModels.includes(id)
}

/** DSH 只认识 text/image 两种模态；目录已经按实测值写好。 */
function modalitiesOf(model) {
  return model.input.filter((m) => m === 'text' || m === 'image')
}

/** 目录项 → `LlmModelInfo`。 */
function toModelInfo(model, connection) {
  return {
    provider: PROVIDER,
    id: model.id,
    name: model.name,
    // 这个 description 会出现在 harness **共享的**模型选择器里，而那里没有插件侧的语言
    // 席位 —— 写中文的话，英文界面下就只有这一行是中文。所以用语言无关的短形式。
    description: `${model.family} · ${Math.round(contextWindowOf(model, connection) / 1024)}K ctx`,
    inputModalities: modalitiesOf(model),
  }
}

/** 目录项 → `LlmResolvedModelInfo`（含上下文、输出上限、思考档位）。 */
function toResolvedModelInfo(model, connection) {
  const maxOutput = model.maxOutput
  return {
    ...toModelInfo(model, connection),
    context: { contextWindow: contextWindowOf(model, connection) },
    defaultMaxTokens: Math.min(connection.defaultMaxTokens, maxOutput),
    reasoning: {
      efforts: model.efforts.map((effort) => ({ id: effort.id, name: effort.name })),
      defaultEffort: model.defaultEffort,
    },
  }
}

// ---------------------------------------------------------------------------
// 消息翻译（DSH → OpenAI 兼容线路）
// ---------------------------------------------------------------------------

/** 拼一个 content 数组里的文本。 */
function blockText(blocks) {
  return blocks
    .filter((block) => block.type === 'text')
    .map((block) => block.text)
    .join('')
}

/** 判断一条消息的内容里有没有图片块。 */
function hasImage(blocks) {
  return blocks.some((block) => block.type === 'image')
}

/** 把一张请求版图片编码成 data URL。 */
function dataUrl(mediaType, bytes) {
  return `data:${mediaType};base64,${Buffer.from(bytes).toString('base64')}`
}

/** 计算请求版图片的长边投影（绝不放大，也绝不产生 0 尺寸）。 */
function projectImageSize(width, height, longEdge) {
  if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0) {
    return { width: Math.max(1, Math.round(width) || 1), height: Math.max(1, Math.round(height) || 1) }
  }
  if (longEdge >= Math.max(width, height)) return { width, height }
  return width >= height
    ? { width: longEdge, height: Math.max(1, Math.round((longEdge * height) / width)) }
    : { width: Math.max(1, Math.round((longEdge * width) / height)), height: longEdge }
}

// ---------------------------------------------------------------------------
// SSE 解析
// ---------------------------------------------------------------------------

/** 把一次 HTTP 失败归类成 DSH 的稳定失败码。 */
function classifyHttpFailure(status, bodyText, requestId) {
  const detail = bodyText ?? ''
  if (status === 401 || status === 403) return { code: 'AUTH', message: `火山方舟鉴权失败（HTTP ${status}）` }
  if (status === 429) return { code: 'RATE_LIMIT', message: '火山方舟限流（HTTP 429）' }
  if (status >= 500) return { code: 'SERVER', message: `火山方舟服务端错误（HTTP ${status}）` }
  if (isContextWindowExceededError(detail)) {
    return { code: 'CONTEXT_WINDOW_EXCEEDED', message: '请求超出该模型的上下文窗口' }
  }
  if (isQuotaExceededError(detail)) return { code: 'QUOTA', message: 'Coding Plan 额度已用尽' }
  return { code: 'PROVIDER_ERROR', message: `火山方舟拒绝了请求（HTTP ${status}）${requestId === undefined ? '' : ` · ${requestId}`}` }
}

/** 从响应体里取错误详情，尽力而为。 */
function errorDetail(bodyText) {
  try {
    const parsed = JSON.parse(bodyText)
    const error = parsed?.error
    if (isPlainObject(error)) {
      return [error.code, error.type, error.message].filter((part) => typeof part === 'string' && part !== '').join(' ')
    }
  } catch {
    // 非 JSON 的错误体：原样使用截断文本。
  }
  return typeof bodyText === 'string' ? bodyText.slice(0, 400) : ''
}

/** 从错误详情里取 Ark 的 request id。 */
function requestIdOf(bodyText) {
  const match = /Request id:\s*([0-9a-zA-Z]+)/.exec(bodyText ?? '')
  return match?.[1]
}

/**
 * 读 `Retry-After`（秒或 HTTP 日期）。
 *
 * 方舟在被限流时会带上这个头，冷却时长应当听服务端的 —— 猜一个值只会
 * 要么撞得太早、要么白等太久。
 */
function parseRetryAfter(headers) {
  const raw = headers?.get?.('retry-after')
  if (typeof raw !== 'string' || raw.trim() === '') return undefined
  const seconds = Number(raw)
  // 必须 **> 0**，不能 `>= 0`。`dsh-llm` 要求 `providerRetryAfterMs` 是正有限数，
  // 给 0 会让它构造 LlmError 时抛一句 `providerRetryAfterMs must be a positive finite
  // number`：真实失败码被替换成无意义消息，`rotationReasonFor` 拿不到 code，于是
  // **不冷却、不换下一个账户、直接失败** —— 恰好是限流时最需要轮换的场景。
  // 而且 nginx/Cloudflare/ALB 之类的前置代理在 429/503 上发 `Retry-After: 0` 很常见。
  // 上界同样必需：畸形或恶意的值会把账户冷却到 ~1e23ms，进程内永久不可用。
  if (Number.isFinite(seconds) && seconds > 0) return Math.min(Math.trunc(seconds * 1000), RETRY_AFTER_MAX_MS)
  const date = Date.parse(raw)
  if (Number.isFinite(date)) {
    const delta = date - Date.now()
    return delta > 0 ? Math.min(delta, RETRY_AFTER_MAX_MS) : undefined
  }
  return undefined
}

// ---------------------------------------------------------------------------
// 适配器
// ---------------------------------------------------------------------------

/**
 * 火山方舟 Coding Plan 的 LLM 适配器。
 *
 * 依赖通过构造函数注入（配置读取 thunk、密钥解析、附件服务、日志），
 * 所以适配器自身不持有 cordis 上下文，测试也能直接驱动。
 */
export class ArkCodingAdapter extends LlmAdapter {
  constructor(deps) {
    super()
    this.deps = deps
  }

  /** 当前连接事实（每次调用都重新解析，配置改动立即生效）。 */
  connection() {
    return resolveConnection(unwrapVolatileConfig(this.deps.config()))
  }

  providerInfo(provider) {
    return { id: provider, name: DISPLAY_NAME }
  }

  /** 默认重试策略：只有瞬时失败会被重试（与 dsh-llm 的默认集合一致）。 */
  providerRetryPolicy(provider) {
    return resolveRetryPolicy({ mode: 'normal', maxRetries: 3 }, `providers.${provider}.retryPolicy`)
  }

  async listModels(_provider) {
    const connection = this.connection()
    return MODELS.filter((model) => modelIsVisible(model.id, connection)).map((model) => toModelInfo(model, connection))
  }

  async resolveModel(_provider, model) {
    const connection = this.connection()
    const entry = modelById(model)
    if (entry === undefined) {
      // 目录之外的 id 仍然可路由（核心路由不依赖目录），只是没有容量事实。
      return { provider: PROVIDER, id: model, name: model, inputModalities: ['text'] }
    }
    return toResolvedModelInfo(entry, connection)
  }

  /**
   * 解析一个凭据引用：字面量优先，其次凭据服务，最后启动环境 / `.env`。
   *
   * 密钥永不进日志、不进错误消息；这里只回答"解析出来了吗"。
   *
   * @param ref - 凭据引用名。
   * @param literal - 组合配置里的字面量（优先）。
   * @returns 可用密钥，或 undefined。
   */
  async resolveRef(ref, literal) {
    if (typeof literal === 'string' && literal.trim() !== '') {
      return assertUsableApiKey(literal, NS, `${NS}（字面量）`)
    }
    const ctx = this.deps.ctx?.()
    const credentials = ctx?.get?.('credentials')
    if (credentials !== undefined && credentials !== null && isValidRefName(ref)) {
      // 解不开就往下走 ambient 兜底，不要把整个账户丢掉：`resolve` 本身也可能因为
      // 后端故障抛错，而"凭据服务暂时不好用"不等于"这个账户没配 key"。
      try {
        const resolved = await credentials.resolve(credentialRef(ref))
        if (resolved !== undefined && typeof resolved.value === 'string' && resolved.value !== '') {
          return assertUsableApiKey(resolved.value, NS, ref)
        }
      } catch { /* 交给下面的启动环境兜底 */ }
    }
    // 没有凭据服务（headless profile）时的兜底：启动环境与 .env。
    // **`.get()` 返回的是 `{value, source}` 条目，不是字符串** —— 以前这里按字符串读，
    // 于是这条兜底永远不生效：headless profile 里 export 的 `ARK_CODING_API_KEY` 取不到；
    // ref 名含 `-`（凭据服务文法拒绝，只能靠环境变量）的账户也取不到，用户只看到
    // "账户都还没有可用的 API key"。一方适配器用的都是 `.get(name)?.value`
    // （dsh-llm-pi-ai 的 2093 / 2567 行）。
    const ambient = ctx === undefined ? undefined : launchEnvironmentOf(ctx).get(ref)?.value
    if (typeof ambient === 'string' && ambient.trim() !== '') {
      return assertUsableApiKey(ambient, NS, ref)
    }
    return undefined
  }

  /** 解析主账户（保留旧签名：单账户路径）。 */
  async resolveApiKey() {
    const connection = this.connection()
    const accounts = await this.resolveAccounts(connection)
    return accounts[0]?.key
  }

  /**
   * 解析出全部账户及各自的 key，并按「配置偏好 → 可用 → 冷却中」排序。
   *
   * 冷却中的账号排在最后而不是被剔除：所有账号都在冷却时，仍然应该去试一次，
   * 而不是直接报"没有可用账号"。
   */
  async resolveAccounts(connection = this.connection()) {
    const marks = this.deps.marks
    const resolved = []
    for (const account of connection.accounts) {
      let key
      try {
        // CLI 账户的 key 不在凭据服务里：它是登录后用 arkcli 打印出来的，
        // 由 deps.cliKey 负责取（带缓存），取不到就当这个账户未配置。
        key = account.type === TYPE_CLI && this.deps.cliKey !== undefined
          ? await this.deps.cliKey(account)
          : await this.resolveRef(account.ref, account.literal)
      } catch {
        key = undefined
      }
      resolved.push({ ...account, key, usable: marks === undefined ? true : marks.usable(account.id) })
    }
    return orderAccounts(resolved, marks ?? { usable: () => true }, connection.activeAccount)
  }

  /** 面向设置页的账户状态（只回答"配没配"，永不回传值）。 */
  async accountStates() {
    const connection = this.connection()
    const ctx = this.deps.ctx?.()
    const credentials = ctx?.get?.('credentials')
    const marks = this.deps.marks?.snapshot?.() ?? {}
    const out = []
    for (const account of connection.accounts) {
      const base = {
        id: account.id,
        label: account.label,
        labelIsCustom: account.labelIsCustom === true,
        type: account.type,
        ref: account.ref,
        home: account.type === TYPE_CLI ? account.home : undefined,
        mark: marks[account.id] ?? null,
      }
      if (account.type === TYPE_CLI) {
        // CLI 账户的"配没配"= arkcli 那边登录没登录，key 是登录的副产物。
        const state = this.deps.cliAccountState === undefined
          ? { loggedIn: false }
          : await this.deps.cliAccountState(account)
        out.push({
          ...base,
          configured: state.loggedIn === true,
          source: state.loggedIn === true ? 'arkcli' : undefined,
          loggedIn: state.loggedIn === true,
          credentialExpiresAt: state.credentialExpiresAt,
          identity: state.identity,
          needsInstall: state.needsInstall === true,
        })
        continue
      }
      let configured = account.literal !== undefined
      let source = account.literal === undefined ? undefined : 'config'
      if (!configured && credentials !== undefined && credentials !== null && isValidRefName(account.ref)) {
        try {
          const info = await credentials.describe(credentialRef(account.ref))
          if (info?.configured === true) { configured = true; source = info.source ?? 'store' }
        } catch { /* 描述失败按未配置处理 */ }
      }
      if (!configured) {
        // 同 `resolveRef`：`.get()` 给的是 `{value, source}` 条目，不是字符串。
        const ambient = ctx === undefined ? undefined : launchEnvironmentOf(ctx).get(account.ref)?.value
        if (typeof ambient === 'string' && ambient.trim() !== '') { configured = true; source = 'env' }
      }
      out.push({ ...base, configured, source })
    }
    return out
  }

  /** 面向设置页的密钥状态（主账户；保留旧签名）。 */
  async credentialState() {
    const [first] = await this.accountStates()
    return { configured: first?.configured === true, source: first?.source }
  }

  /**
   * 把请求消息投影成 OpenAI 形状。
   *
   * 关键点：
   * - assistant 历史只回放可见文本与 tool_calls：Ark 的思考字段（`reasoning_content`）
   *   不接受回灌，回灌会被拒。
   * - `developer` 消息（工具增删记录）并入 system：Ark 没有 developer 角色，且本适配器
   *   每次请求都发送完整工具声明，不需要增量语义。
   * - 每个 tool_call 强制写 `type: 'function'`。这是为了 MiniMax-M3：它回传的
   *   `tool_calls[].type` 是 `functionfunction`（服务端缺陷），原样回灌会 400。
   */
  buildMessages(projected, model, imageUrlFor) {
    const output = []
    const imagesAllowed = modalitiesOf(model).includes('image')
    for (const message of projected) {
      const blocks = Array.isArray(message.content) ? message.content : []
      switch (message.role) {
        case 'system':
        case 'developer': {
          const text = blockText(blocks)
          if (text !== '') output.push({ role: 'system', content: text })
          break
        }
        case 'user': {
          if (!hasImage(blocks) || !imagesAllowed) {
            output.push({ role: 'user', content: blockText(blocks) })
            break
          }
          const parts = []
          for (const block of blocks) {
            if (block.type === 'text') parts.push({ type: 'text', text: block.text })
            else if (block.type === 'image') {
              const url = imageUrlFor?.(block)
              if (typeof url === 'string') parts.push({ type: 'image_url', image_url: { url } })
            }
          }
          output.push({ role: 'user', content: parts })
          break
        }
        case 'assistant': {
          const text = blockText(blocks)
          const toolCalls = blocks
            .filter((block) => block.type === 'tool-call')
            .map((block) => ({
              id: block.id,
              type: 'function',
              function: { name: block.name, arguments: block.arguments === '' ? '{}' : block.arguments },
            }))
          const entry = { role: 'assistant', content: text }
          if (toolCalls.length > 0) entry.tool_calls = toolCalls
          output.push(entry)
          break
        }
        case 'tool': {
          const callId = message.source?.kind === 'tool' ? message.source.callId : undefined
          if (callId === undefined) break
          output.push({ role: 'tool', tool_call_id: callId, content: blockText(blocks) })
          break
        }
        default:
          break
      }
    }
    return output
  }

  /** 组一次 `/chat/completions` 的请求体。 */
  buildBody(options, model, connection, messages) {
    const body = {
      model: model?.id ?? options.model,
      messages,
      stream: true,
      stream_options: { include_usage: true },
    }
    const cap = model === undefined ? connection.defaultMaxTokens : model.maxOutput
    const requested = typeof options.maxTokens === 'number' && options.maxTokens > 0 ? Math.trunc(options.maxTokens) : connection.defaultMaxTokens
    body.max_tokens = Math.max(1, Math.min(requested, cap))
    if (typeof options.temperature === 'number') body.temperature = options.temperature
    if (Array.isArray(options.tools) && options.tools.length > 0) {
      body.tools = options.tools.map((tool) => ({
        type: 'function',
        function: { name: tool.name, description: tool.description, parameters: tool.parameters },
      }))
    }
    if (Array.isArray(options.stop) && options.stop.length > 0) body.stop = options.stop
    const effort = options.reasoningEffort
    if (typeof effort === 'string' && effort !== '') {
      const wire = EFFORT_WIRE[effort] ?? effort
      // GLM-5.3 系列不接受 none；目录里已排除该档位，这里再兜一层。
      const allowed = model?.efforts?.some((entry) => entry.id === effort) ?? true
      if (allowed) body.reasoning_effort = wire
    }
    return body
  }

  /** 把一次请求里所有图片读成 data URL，并执行请求体字节预算。 */
  async projectImages(messages, attachments) {
    const occurrences = []
    for (const message of messages) {
      const blocks = Array.isArray(message.content) ? message.content : []
      for (const block of blocks) {
        if (block.type === 'image' && block.offloaded !== true) occurrences.push(block)
      }
    }
    const byId = new Map()
    const urls = new Map()
    for (const block of occurrences) {
      const ref = block.attachment
      if (ref === undefined || typeof ref.attachmentId !== 'string') continue
      if (urls.has(ref.attachmentId)) continue
      const target = {
        ...projectImageSize(ref.width, ref.height, REQUEST_IMAGE_MAX_LONG_EDGE),
        maxBytes: REQUEST_IMAGE_MAX_ENCODED_BYTES,
      }
      const version = await attachments.readImageRequest(ref, target)
      // 存**原始编码字节**，不是 base64 长度：`requiredImageOffload` 的回调要的是原始字节，
      // base64 展开由它自己做（`dsh-llm` 的 content.js 会按 representation==='base64' 再展开）。
      // 以前这里预先展开过一次，于是同一张图被算了两遍，报出的 missing 比真实多，
      // 上层就**永久**多卸载一张图 —— 不可逆的上下文丢失，模型再也看不到它。
      byId.set(ref.attachmentId, imageBytesOf(version))
      urls.set(ref.attachmentId, dataUrl(version.mediaType, version.data))
    }
    // 自检口径要与真正发出去的 body 一致：同一附件被引用两次，data URL 就会在 body 里
    // 出现两次，所以这里按**出现次数**累加（旧实现按 attachmentId 去重，会漏算一半）。
    const encodedTotal = occurrences.reduce((sum, block) => {
      const bytes = byId.get(block.attachment?.attachmentId)
      return sum + (typeof bytes === 'number' ? base64LengthOf(bytes) : 0)
    }, 0)
    if (encodedTotal > DEFAULT_MAX_REQUEST_IMAGE_BYTES) {
      const budget = {
        representation: 'base64',
        maxBytes: DEFAULT_MAX_REQUEST_IMAGE_BYTES,
        byteQuantum: 1,
        countQuantum: 1,
      }
      const missing = requiredImageOffload(messages, budget, (block) => byId.get(block.attachment?.attachmentId) ?? 0)
      throw new LlmError(
        `请求中的图片超过单次上限，需要先卸载最旧的 ${missing} 张图片后再重试。`,
        'IMAGE_OFFLOAD_REQUIRED',
        { offloadImages: missing },
      )
    }
    return urls
  }

  /**
   * 一次请求里与账号无关的部分：图片投影、消息翻译、请求体。
   * 多账户轮换时只准备一次，换账号只是换 `Authorization`。
   */
  async prepare(options, connection, model) {
    // 被上层标记为 offloaded 的图片先降级成占位文本，剩下的才真正内联。
    const projected = projectOffloadedImages(options.messages, (ref) => offloadedImageText(ref))

    let imageUrls = new Map()
    if (projected.some((message) => Array.isArray(message.content) && hasImage(message.content))) {
      const attachments = this.deps.attachments?.()
      if (attachments === undefined || attachments === null) {
        throw new LlmError('图片输入需要宿主挂载附件服务', 'UNSUPPORTED_CONTENT')
      }
      imageUrls = await this.projectImages(projected, attachments)
    }

    // 图片 URL 只属于这一次请求：并发调用（例如会话标题生成）各带各的映射，
    // 绝不挂在适配器实例上。
    const imageUrlFor = (block) => imageUrls.get(block.attachment?.attachmentId)
    const messages = this.buildMessages(projected, model, imageUrlFor)
    // `options.system` 是**一次性调用**的指令入口：`dsh-session-title-llm`（标题的语言/
    // 格式约束）与 `dsh-experimental-auto-review`（`system` 就是风险分类策略本体）都只把
    // 指令放在这里，messages 里只有用户文本。契约要求适配器把它映射到 provider 的
    // system 槽并排在 messages 之前，两个一方适配器都这么做；忽略它等于让那些路径在
    // **没有任何系统指令**的情况下作答 —— 对 Auto Review 来说是安全相关的降级。
    if (typeof options.system === 'string' && options.system.trim() !== '') {
      messages.unshift({ role: 'system', content: options.system })
    }
    return { body: this.buildBody(options, model, connection, messages) }
  }

  /**
   * 唯一的必需方法：把一次模型调用流成 StreamChunk。
   *
   * 多账户轮换发生在这里：按顺序试每个可用账号，**只要还没吐出任何 chunk**，
   * 就把「限流 / 额度用尽 / key 不可用」当成换账号的信号；一旦开始吐内容，
   * 换账号重来会把半截回答重复一遍，所以那时一律原样抛出。
   */
  async *stream(options) {
    const connection = this.connection()
    const model = modelById(options.model)
    const accounts = await this.resolveAccounts(connection)
    if (accounts.length === 0) {
      // 现在没有"默认账户"了，所以这里要区分两种空：压根没有账户 vs 有账户但都没配好。
      // 顺带把"怎么修"说到具体动作上，而不是丢一句"没有 API key"。
      const exists = connection.accounts.length > 0
      throw new LlmError(
        exists
          ? `${DISPLAY_NAME} 的账户都还没有可用的 API key：去「设置 → 火山方舟」，`
            + '给 API Key 账户填上密钥，或给 CLI 账户完成登录。'
          : `${DISPLAY_NAME} 还没有任何账户：去「设置 → 火山方舟」点「添加账户」，`
            + '选「CLI 登录」能顺带拿到真实套餐额度，选「API Key」则只够聊天。',
        'MISSING_CREDENTIAL',
      )
    }

    const prepared = await this.prepare(options, connection, model)
    const marks = this.deps.marks
    let lastError

    for (const account of accounts) {
      const state = { emitted: false }
      try {
        for await (const chunk of this.streamOnce(options, connection, model, prepared, account)) {
          state.emitted = true
          yield chunk
        }
        marks?.clear(account.id)
        return
      } catch (error) {
        if (options.signal?.aborted === true) throw error
        const code = error instanceof LlmError ? error.code : undefined
        const reason = rotationReasonFor(code)
        // 已经吐过内容、或者这个失败换账号也没用 → 原样抛出去。
        if (reason === undefined || state.emitted) throw error
        const cooldown = retryAfterMsOf(error?.failure) ?? cooldownFor(reason)
        marks?.mark(account.id, reason, Date.now() + cooldown)
        lastError = error
        this.deps.logger?.warn?.(
          `${NS}: 账户「${account.label}」${reason}（${code}），冷却 ${Math.round(cooldown / 1000)}s 后重试，先切到下一个账户`,
        )
      }
    }

    throw lastError ?? new LlmError(`${DISPLAY_NAME} 的所有账户都不可用。`, 'QUOTA')
  }

  /** 用某一个账号发一次请求，把响应流交给调用方。 */
  async *streamOnce(options, connection, model, prepared, account) {
    const controller = new AbortController()
    const onAbort = () => controller.abort(options.signal?.reason)
    if (options.signal !== undefined) {
      if (options.signal.aborted) controller.abort(options.signal.reason)
      else options.signal.addEventListener('abort', onAbort, { once: true })
    }
    const headTimer = setTimeout(() => controller.abort(new Error('request timeout')), connection.requestTimeoutMs)

    let response
    try {
      response = await fetch(`${connection.apiBase}/chat/completions`, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          accept: 'text/event-stream',
          authorization: `Bearer ${account.key}`,
          ...attributionHeaders(),
        },
        body: JSON.stringify(prepared.body),
        signal: controller.signal,
      })
    } catch (error) {
      clearTimeout(headTimer)
      options.signal?.removeEventListener?.('abort', onAbort)
      if (options.signal?.aborted === true) throw abortError(options.signal)
      const timedOut = controller.signal.aborted
      throw new LlmError(
        timedOut
          ? `${DISPLAY_NAME} 在 ${connection.requestTimeoutMs} ms 内没有返回响应头。`
          : `无法连接 ${DISPLAY_NAME}：${error instanceof Error ? error.message : String(error)}`,
        timedOut ? 'TIMEOUT' : 'TRANSPORT',
        { cause: error },
      )
    }

    clearTimeout(headTimer)
    try {
      if (!response.ok) {
        const text = await safeText(response)
        const detail = errorDetail(text)
        const requestId = requestIdOf(text)
        const retryAfter = parseRetryAfter(response.headers)
        if (response.status === 401 || response.status === 403) {
          throw new LlmError(
            `${DISPLAY_NAME} 拒绝了这个 API key（HTTP ${response.status}）。请确认它是 Coding Plan 的密钥。`,
            'AUTH',
            { status: response.status, requestId, ...(retryAfter === undefined ? {} : { providerRetryAfterMs: retryAfter }) },
          )
        }
        // 分类用**完整**响应体，展示才用截断后的 detail：额度/上下文这类判定依赖
        // 错误关键字，而关键字有时代码/请求 id 之后（`errorDetail` 只留前 400 字符，
        // 拿它去分类会让一个本该 QUOTA 的失败退化成 PROVIDER_ERROR）。
        const failure = classifyHttpFailure(response.status, text, requestId)
        throw new LlmError(
          failure.message + (detail === '' ? '' : `：${detail}`),
          failure.code,
          { status: response.status, requestId, ...(retryAfter === undefined ? {} : { providerRetryAfterMs: retryAfter }) },
        )
      }
      for await (const chunk of this.parseStream(response, connection, options)) {
        yield chunk
      }
    } finally {
      options.signal?.removeEventListener?.('abort', onAbort)
    }
  }

  /**
   * 解析 SSE 流并产出 StreamChunk。
   *
   * 这里只做出口兜底：真正的解析在 `parseStreamRaw`，本方法保证交出去的每一块都
   * 是"无损 JSON"（见 `withoutUndefined`）。
   */
  async *parseStream(response, connection, options) {
    for await (const chunk of this.parseStreamRaw(response, connection, options)) {
      yield withoutUndefined(chunk)
    }
  }

  /** 真正的 SSE 解析。别的地方不要直接调它 —— 必须经过 `parseStream` 的出口兜底。 */
  async *parseStreamRaw(response, connection, options) {
    const reader = response.body?.getReader()
    if (reader === undefined) {
      throw new LlmError('火山方舟返回了空的响应体', 'TRANSPORT')
    }
    const decoder = new TextDecoder()
    let buffer = ''
    let idleTimer
    /** 空闲超时不是"正常结束"：它必须被报出来，不能悄悄截断成一次成功的补全。 */
    let idleExpired = false
    const armIdle = () => {
      if (idleTimer !== undefined) clearTimeout(idleTimer)
      idleTimer = setTimeout(() => {
        idleExpired = true
        // 必须吞掉拒绝：`cancel()` 拒绝时就是一个未处理 rejection，而 DSH 把
        // unhandledRejection 当致命错误（`dsh-app-boot` 的 report() → proc.exit(1)）。
        // 同一个调用在下面的 finally 里是包了 try/catch 的，这里当时漏了。
        try {
          const cancelled = reader.cancel(new Error('stream idle timeout'))
          if (typeof cancelled?.catch === 'function') cancelled.catch(() => {})
        } catch { /* 流已经崩了，没什么可取消的 */ }
      }, connection.streamIdleTimeoutMs)
    }

    let nextIndex = 0
    let reasoningIndex = -1
    let textIndex = -1
    let reasoningText = ''
    let text = ''
    const toolBlocks = new Map()
    let usage
    let finishReason = 'stop'
    let produced = false
    /** 见过 `finish_reason` 或 `[DONE]` 吗？没见过就结束 = 截断，不能算一次正常的 stop。 */
    let sawTerminal = false
    /** 见过 `[DONE]`：之后的数据是上游重复/补发，必须丢掉。 */
    let sawDone = false
    /** 读到流末尾了（`read()` 返回 done）。用来在冲完残留缓冲后退出循环。 */
    let sawEnd = false
    /** 读取途中抛出的错（含上游断连）。延后到空闲超时判定之后再决定怎么报。 */
    let streamError

    const openBlock = (blockType) => {
      const index = nextIndex++
      if (blockType === 'reasoning') reasoningIndex = index
      else if (blockType === 'text') textIndex = index
      return index
    }

    try {
      armIdle()
      for (;;) {
        const { done, value } = await reader.read()
        if (done) {
          // 流结束：把解码器和残留缓冲一起冲干净。最后一帧**可能没有换行**（旧代理、
          // 自研网关、被截断的连接都会这样），而旧实现只在 `indexOf('\n')` 命中时才处理，
          // 于是那一帧连同末尾半个多字节字符一起被静默丢掉 —— 少字却报成功。
          // 补一个换行，让下面同一套行处理逻辑把它吃掉；处理完就退出循环。
          buffer += `${decoder.decode()}\n`
          sawEnd = true
        } else {
          armIdle()
          buffer += decoder.decode(value, { stream: true })
          // 单条行的上限，见 MAX_SSE_LINE_BYTES 的注释。
          if (buffer.length > MAX_SSE_LINE_BYTES) {
            throw new LlmError(
              `${DISPLAY_NAME} 返回的单条 SSE 数据超过 ${MAX_SSE_LINE_BYTES} 字节，已中断本次请求。`,
              'PROVIDER_ERROR',
            )
          }
        }
        let newline = buffer.indexOf('\n')
        while (newline !== -1) {
          const line = buffer.slice(0, newline).replace(/\r$/, '')
          buffer = buffer.slice(newline + 1)
          newline = buffer.indexOf('\n')
          if (!line.startsWith('data:')) continue
          const payload = line.slice(5).trim()
          if (payload === '') continue
          if (payload === '[DONE]') {
            // 收到终止标记就停：DONE 之后的数据是上游重复/补发，拼进回答里就是脏内容。
            sawDone = true
            sawTerminal = true
            break
          }
          let frame
          try {
            frame = JSON.parse(payload)
          } catch {
            continue
          }
          const frameError = frame.error
          // 错误帧有两种形状：对象（一次失败）与字符串（上游/网关更常这么写）。
          // 旧实现只认对象，字符串形式的错误被**完全吞掉** —— 一次本该失败的调用
          // 变成一次"成功的半截回答"。
          if (isPlainObject(frameError) || (typeof frameError === 'string' && frameError !== '')) {
            const detail = errorDetail(payload) || (typeof frameError === 'string' ? frameError : '')
            throw new LlmError(`火山方舟在流中报错：${detail}`, isQuotaExceededError(detail) ? 'QUOTA' : 'PROVIDER_ERROR', {
              requestId: requestIdOf(payload),
            })
          }
          if (isPlainObject(frame.usage)) usage = frame.usage
          const choice = Array.isArray(frame.choices) ? frame.choices[0] : undefined
          if (!isPlainObject(choice)) continue
          if (typeof choice.finish_reason === 'string' && choice.finish_reason !== '') {
            finishReason = choice.finish_reason
            sawTerminal = true
          }
          const delta = choice.delta
          if (!isPlainObject(delta)) continue

          const reasoning = delta.reasoning_content
          if (typeof reasoning === 'string' && reasoning !== '') {
            if (reasoningIndex === -1) {
              const index = openBlock('reasoning')
              yield { type: 'block-start', index, blockType: 'reasoning' }
            }
            reasoningText += reasoning
            produced = true
            yield { type: 'reasoning-delta', index: reasoningIndex, text: reasoning }
          }

          const content = delta.content
          if (typeof content === 'string' && content !== '') {
            if (textIndex === -1) {
              const index = openBlock('text')
              yield { type: 'block-start', index, blockType: 'text' }
            }
            text += content
            produced = true
            yield { type: 'text-delta', index: textIndex, text: content }
          }

          if (Array.isArray(delta.tool_calls)) {
            for (const call of delta.tool_calls) {
              if (!isPlainObject(call)) continue
              const key = typeof call.index === 'number' ? call.index : toolBlocks.size
              let entry = toolBlocks.get(key)
              if (entry === undefined) {
                // 块声明只带 index 与 blockType，所以这里先开块；id/name 随增量补齐，
                // 收块时用累积值落地（见下面的 block-end）。
                const index = openBlock('tool-call')
                entry = { index, id: '', name: '', arguments: '' }
                toolBlocks.set(key, entry)
                yield { type: 'block-start', index, blockType: 'tool-call' }
              }
              const fn = isPlainObject(call.function) ? call.function : undefined
              if (entry.id === '' && typeof call.id === 'string' && call.id !== '') entry.id = call.id
              const nameDelta = typeof fn?.name === 'string' ? fn.name : ''
              const argsDelta = typeof fn?.arguments === 'string' ? fn.arguments : ''
              if (entry.name === '' && nameDelta !== '') entry.name = nameDelta
              entry.arguments += argsDelta
              produced = true
              yield {
                type: 'tool-call-delta',
                index: entry.index,
                id: entry.id === '' ? `call_${entry.index}` : entry.id,
                ...(nameDelta === '' ? {} : { name: nameDelta }),
                argumentsDelta: argsDelta,
              }
            }
          }
        }
        // `[DONE]` 之后不再消费数据；读到流末尾冲完残留缓冲也要退出。
        // （这两个条件缺一不可：只判 `[DONE]` 的话，一个没有终止标记就结束的流
        // 会让 `reader.read()` 永远返回 done，循环变成忙等 —— 实测直接把进程挂死。）
        if (sawDone || sawEnd) break
      }
    } catch (error) {
      streamError = error
    } finally {
      if (idleTimer !== undefined) clearTimeout(idleTimer)
      try { await reader.cancel() } catch { /* 流已结束 */ }
    }

    // 空闲超时先于收块判定：这时流是被我们主动掐掉的，内容不完整，
    // 报成 TIMEOUT 交给重试器，而不是当作一次正常的短回答落地。
    if (idleExpired) {
      throw new LlmError(
        `${DISPLAY_NAME} 的响应流空闲超过 ${connection.streamIdleTimeoutMs} ms，已中断本次请求。`,
        'TIMEOUT',
      )
    }

    if (streamError !== undefined) {
      if (options.signal?.aborted === true) throw abortError(options.signal)
      if (streamError instanceof LlmError) throw streamError
      // 上游中途断连时 undici 抛的是裸 `TypeError: terminated`：对用户毫无意义，
      // 重试器也认不出它，所以统一包成 TRANSPORT（可重试）。
      throw new LlmError(
        `${DISPLAY_NAME} 的响应流中断：${streamError instanceof Error ? streamError.message : String(streamError)}`,
        'TRANSPORT',
        { cause: streamError },
      )
    }

    // 收块：BlockAssembler 用 block-end 的完整块落地。
    if (reasoningIndex !== -1) {
      yield { type: 'block-end', index: reasoningIndex, block: { type: 'reasoning', text: reasoningText } }
    }
    if (textIndex !== -1) {
      yield { type: 'block-end', index: textIndex, block: { type: 'text', text } }
    }
    for (const entry of toolBlocks.values()) {
      yield {
        type: 'block-end',
        index: entry.index,
        block: {
          type: 'tool-call',
          id: entry.id === '' ? `call_${entry.index}` : entry.id,
          name: entry.name,
          arguments: entry.arguments === '' ? '{}' : entry.arguments,
        },
      }
    }

    if (usage !== undefined) yield { type: 'usage', usage: normalizeUsage(usage) }

    if (!produced) {
      throw new LlmError(`${DISPLAY_NAME} 返回了没有任何内容的一次补全（finish_reason=${finishReason}）。`, EMPTY_RESPONSE_CODE)
    }

    // 流被**干净地**关闭、但既没有 `finish_reason` 也没有 `[DONE]`：这是截断，不是完成。
    // 上游或中间代理在生成中途优雅关掉响应体（FIN 无错）时很常见；旧实现把它当成一次
    // 正常的 `stop`，于是半截回答被当作完整回答落地，重试策略也不会介入 ——
    // "少字却报成功"比直接报错危险得多。报成 TRANSPORT 交给重试器。
    if (!sawTerminal) {
      throw new LlmError(
        `${DISPLAY_NAME} 的响应流在没有 finish_reason / [DONE] 的情况下结束了，回答可能不完整。`,
        'TRANSPORT',
      )
    }

    yield { type: 'finish', reason: finishReasonOf(finishReason) }
  }
}

/** Ark 的 finish_reason → DSH 的 FinishReason。 */
function finishReasonOf(reason) {
  if (reason === 'tool_calls' || reason === 'function_call') return { kind: 'tool-calls' }
  if (reason === 'length' || reason === 'max_tokens') return { kind: 'max-tokens' }
  return { kind: 'stop' }
}

/**
 * Ark 的 usage → DSH 的 TokenUsage。
 *
 * DSH 的计数是不相交的：`inputTokens` 只算未命中缓存的输入，缓存命中单独报。
 * Ark 的 `prompt_tokens` 是含缓存的总量，所以要减出来。
 */
function normalizeUsage(usage) {
  const prompt = countOr(usage.prompt_tokens)
  const cached = countOr(usage.prompt_tokens_details?.cached_tokens)
  const output = countOr(usage.completion_tokens)
  const reasoning = countOr(usage.completion_tokens_details?.reasoning_tokens)
  const result = {
    inputTokens: Math.max(0, prompt - cached),
    outputTokens: output,
  }
  if (cached > 0) result.cacheReadTokens = cached
  if (reasoning > 0) result.reasoningTokens = reasoning
  // total 也要过同一道闸：harness 的 tokenUsage 投影要求 non-negative int，
  // 见 countOr 的注释。
  if (usage.total_tokens !== undefined) result.totalTokens = countOr(usage.total_tokens)
  return result
}

/**
 * 上游计数 → harness 能接受的 token 数：**非负安全整数**，否则 `undefined`（当作没报）。
 *
 * 为什么不能只查 `Number.isFinite`：`dsh-token-meter` 的投影 schema 要求 non-negative
 * integer，而 `viewSchema.parse` 在会话快照/冷恢复路径上没有 try/catch。实测把
 * `outputTokens: -7` 或 `1e308` 或小数透传过去，投影直接 `state=INVALID` 且 `view` 抛错，
 * 打挂的是**整个会话的用量视图**，而不只是这一条数字。脏数据可能来自上游 bug，
 * 也可能来自被劫持的网关，所以这里必须自己兜住。
 */
function countOr(value) {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < 0) return 0
  return value
}

/** 附件服务给的原始编码字节数；`bytes` 缺失时从 data 自身量。 */
function imageBytesOf(version) {
  if (typeof version?.bytes === 'number' && Number.isFinite(version.bytes) && version.bytes >= 0) return version.bytes
  try { return Buffer.from(version?.data ?? []).length } catch { return 0 }
}

/** base64 编码后的字符数（不含 padding 误差，按标准 4/3 上取整）。 */
function base64LengthOf(bytes) {
  return Math.ceil(Math.max(0, bytes) / 3) * 4
}

async function safeText(response) {
  try {
    return await response.text()
  } catch {
    return ''
  }
}

function abortError(signal) {
  return new LlmError('请求已取消', 'ABORTED', { cause: signal.reason })
}

// ---------------------------------------------------------------------------
// 模型发现（Host 侧联机自检）
// ---------------------------------------------------------------------------

/**
 * 设置页「测试连接」背后的 Host 侧询问：用一次性密钥真的打一次 Coding Plan 端点。
 *
 * 这一步存在的意义是让浏览器不必持有密钥就能验证连通性：密钥只在这一个请求的
 * 生命周期里存在，宿主不存储它。成功则顺带回答这 12 个模型的容量事实。
 */
export function createDiscovery() {
  return async function discover(request, signal) {
    const baseURL = (typeof request.baseURL === 'string' && request.baseURL.trim() !== ''
      ? request.baseURL.trim()
      : DEFAULT_API_BASE).replace(/\/+$/, '')
    const apiKey = typeof request.apiKey === 'string' ? normalizeApiKey(request.apiKey) : { ok: false, reason: 'empty' }
    if (apiKey.ok === false) {
      throw new Error('请先填入 API key 再测试连接。')
    }
    const controller = new AbortController()
    const onAbort = () => controller.abort(signal?.reason)
    if (signal !== undefined) {
      if (signal.aborted) controller.abort(signal.reason)
      else signal.addEventListener('abort', onAbort, { once: true })
    }
    const timer = setTimeout(() => controller.abort(new Error('timeout')), 30_000)
    let response
    try {
      response = await fetch(`${baseURL}/chat/completions`, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          accept: 'application/json',
          authorization: `Bearer ${apiKey.value}`,
          ...attributionHeaders(),
        },
        body: JSON.stringify({
          model: 'doubao-seed-2.0-mini',
          messages: [{ role: 'user', content: 'ping' }],
          max_tokens: 1,
          thinking: { type: 'disabled' },
        }),
        signal: controller.signal,
      })
    } catch (error) {
      throw new Error(`无法连接 ${baseURL}：${error instanceof Error ? error.message : String(error)}`)
    } finally {
      clearTimeout(timer)
      signal?.removeEventListener?.('abort', onAbort)
    }
    if (!response.ok) {
      const text = await safeText(response)
      throw new Error(`HTTP ${response.status}：${errorDetail(text) || text.slice(0, 200)}`)
    }
    await safeText(response)
    return MODELS.map((model) => ({
      id: model.id,
      name: model.name,
      contextWindow: model.contextWindow,
      maxTokens: model.maxOutput,
      inputModalities: modalitiesOf(model),
    }))
  }
}

// ---------------------------------------------------------------------------
// 用量 Remote（宿主 → 浏览器）
// ---------------------------------------------------------------------------

/** npm 包身份，Host 贡献与 Client 挂载必须一致。 */
export const REMOTE_PACKAGE = 'dsh-ark-coding-provider'
/** Gateway 解析的 Cordis 服务键，也是默认线网命名空间。 */
export const REMOTE_SERVICE = 'arkCodingUsage'
/** 与 llm-ark-coding 区分开：这是浏览器要调的自定义命名空间。 */
export const REMOTE_NAMESPACE = 'arkcoding'

/** 边界 schema：只保证"是个对象"，字段由两侧的 TS 形状约定。 */
function objectSchema(label) {
  return {
    parse(value) {
      if (typeof value !== 'object' || value === null || Array.isArray(value)) {
        throw new TypeError(`${label}: 结果不是对象`)
      }
      return value
    },
  }
}

/** 无参数端点的结果 schema。 */
function resultOf(method) {
  return {
    mode: 'strict',
    typeSymbol: `${REMOTE_PACKAGE}#arkcoding/${method}:result`,
    create: () => objectSchema(`arkcoding/${method}`),
  }
}

/**
 * 一个收 JSON 参数的端点。
 *
 * codec 必须是 `mode: 'strict'`。协议里还有个 `{ mode: 'src-json' }` 的"不校验"
 * 档（宿主网关内部自己就用它），但**客户端**的贡献校验只收 strict —— 用它会让
 * 整个 `$mount` 抛 `field "input" has no strict codec`，代价是**八个端点全部失效**、
 * 用量卡片永远停在 Loading。所以这里给一个"恒真的 strict"：结构上合规，语义上
 * 仍然不预设字段（这些参数本来就没有可枚举的静态类型，真正的校验在宿主方法里做，
 * 报错信息也更贴近用户看到的东西）。
 *
 * `name` 与 `wire` 都写成 `input`：客户端代理无论按哪个字段映射，落到线上都是 `input`。
 */
function actionOf(method) {
  return {
    id: `${REMOTE_PACKAGE}#${REMOTE_NAMESPACE}/${method}`,
    service: REMOTE_SERVICE,
    namespace: REMOTE_NAMESPACE,
    method,
    invocation: { kind: 'direct' },
    parameters: [{
      name: 'input',
      wire: 'input',
      source: 'json',
      codec: {
        mode: 'strict',
        typeSymbol: `${REMOTE_PACKAGE}#${REMOTE_NAMESPACE}/${method}:input`,
        create: () => objectSchema(`${method} input`),
      },
    }],
    result: resultOf(method),
  }
}

/** 无参数端点的描述符。 */
function plainOf(method) {
  return {
    id: `${REMOTE_PACKAGE}#${REMOTE_NAMESPACE}/${method}`,
    service: REMOTE_SERVICE,
    namespace: REMOTE_NAMESPACE,
    method,
    invocation: { kind: 'direct' },
    parameters: [],
    result: resultOf(method),
  }
}

/** 账户 + 用量 + 官方目录 + arkcli 状态的汇总（侧边栏与设置页共用）。 */
export const USAGE_REPORT_DESCRIPTOR = plainOf('report')
/** arkcli 是否可用、装在哪、什么版本。 */
export const CLI_STATUS_DESCRIPTOR = plainOf('cliStatus')
/** 一键把 arkcli 装进插件私有目录。 */
export const CLI_INSTALL_DESCRIPTOR = plainOf('cliInstall')
/** 强制刷新官方模型目录。 */
export const CATALOG_REFRESH_DESCRIPTOR = plainOf('catalogRefresh')
/** 开始一次 CLI 无浏览器登录，拿回授权 URL。 */
export const LOGIN_BEGIN_DESCRIPTOR = actionOf('loginBegin')
/** 轮询登录状态（用户可能在浏览器那边花了很久）。 */
export const LOGIN_POLL_DESCRIPTOR = actionOf('loginPoll')
/** 把用户从浏览器地址栏复制的回跳 URL（或授权码）交给 arkcli 完成登录。 */
export const LOGIN_SUBMIT_DESCRIPTOR = actionOf('loginSubmit')
/** 取消一次进行中的登录。 */
export const LOGIN_CANCEL_DESCRIPTOR = actionOf('loginCancel')

/** 浏览器通过 `remote.arkcoding.*` 能调到的全部端点。 */
export const USAGE_CLIENT_CONTRIBUTION = {
  package: REMOTE_PACKAGE,
  descriptors: [
    USAGE_REPORT_DESCRIPTOR,
    CLI_STATUS_DESCRIPTOR,
    CLI_INSTALL_DESCRIPTOR,
    CATALOG_REFRESH_DESCRIPTOR,
    LOGIN_BEGIN_DESCRIPTOR,
    LOGIN_POLL_DESCRIPTOR,
    LOGIN_SUBMIT_DESCRIPTOR,
    LOGIN_CANCEL_DESCRIPTOR,
  ],
}

/**
 * Remote 接收者：一个 Cordis 服务，Gateway 按 key 解析它、按命名空间绑定线网。
 * 基类负责盖 `typertRemote` 绑定，不需要装饰器 —— 描述符是显式注册的。
 *
 * 每个方法都只负责把参数转交给 `deps`：真正的逻辑（以及它需要的 cordis 上下文、
 * 子进程、缓存）留在 `apply()` 里，那里才拿得到活的配置与 logger。
 */
export class ArkCodingUsageService extends TypertRemoteService {
  constructor(ctx, deps) {
    super(ctx, REMOTE_SERVICE, { namespace: REMOTE_NAMESPACE })
    this.deps = deps
  }

  /** 账户 + 套餐额度 + 官方目录。 */
  async report() {
    return this.deps.report()
  }

  /** arkcli 探测结果。 */
  async cliStatus() {
    return this.deps.cliStatus()
  }

  /** 装 arkcli（幂等：已装就直接返回现状）。 */
  async cliInstall() {
    return this.deps.cliInstall()
  }

  /** 刷新官方模型目录。 */
  async catalogRefresh() {
    return this.deps.catalogRefresh()
  }

  /** 开始登录，返回授权 URL。 */
  async loginBegin(input) {
    return this.deps.loginBegin(input ?? {})
  }

  /** 查这次登录到哪一步了。 */
  async loginPoll(input) {
    return this.deps.loginPoll(input ?? {})
  }

  /** 把回跳 URL / 授权码喂回去，完成登录。 */
  async loginSubmit(input) {
    return this.deps.loginSubmit(input ?? {})
  }

  /** 放弃这次登录。 */
  async loginCancel(input) {
    return this.deps.loginCancel(input ?? {})
  }
}

/** 把任意抛出物渲染成一行可读文字（供页面显示）。 */
function errorText(error) {
  if (error instanceof Error) return error.message
  return typeof error === 'string' ? error : String(error)
}

// ---------------------------------------------------------------------------
// 插件入口
// ---------------------------------------------------------------------------

/** 挂载适配器、可配置提供商目录、模型发现与用量 Remote。 */
/** Coding Plan 在 `usage plan` 里的 product id。 */
const CODING_PRODUCT = 'coding-plan'

/** 额度窗口 key → 界面上显示的名字。 */
const WINDOW_LABELS = { session: '5 小时', weekly: '本周', monthly: '本月' }

/**
 * 从 `arkcli usage plan` 的 items 里挑出 Coding Plan 的窗口。
 *
 * 只认 `coding-plan`：Agent Plan 的额度是另一套口径（它给绝对值，Coding Plan
 * 只给百分比），混在一起显示会让人以为看到的是同一个池子。没订阅就如实说明，
 * 顺便告诉用户他订的到底是什么 —— 比一个干巴巴的"没有数据"有用。
 */
function windowsFromItems(items) {
  const list = Array.isArray(items) ? items : []
  const coding = list.filter((item) => item.product === CODING_PRODUCT && item.subscribed === true)
  if (coding.length === 0) {
    const others = [...new Set(list.filter((item) => item.subscribed === true).map((item) => item.product))]
    return {
      windows: [],
      error: others.length > 0
        ? `这个账号订阅的是 ${others.join(' / ')}，不是 Coding Plan。`
        : '这个账号没有查到生效中的 Coding Plan 订阅。',
    }
  }
  const item = coding[0]
  return {
    windows: (Array.isArray(item.periods) ? item.periods : []).map((period) => ({
      key: period.key,
      label: WINDOW_LABELS[period.key] ?? period.label ?? period.key,
      percent: period.percent,
      used: period.used,
      total: period.total,
      hasTotals: period.hasTotals === true,
      resetAt: period.resetAt,
    })),
    tier: item.tier,
    updatedAt: item.updatedAt,
  }
}

/**
 * 解析插件的状态根：DSH 的 home（`arkcli` 托管安装与各账户 HOME 都在它下面）。
 *
 * **不能只看 `$DSH_HOME`**：DSH 自己的解析规则是「显式配置 → `$DSH_HOME` → `~/.dsh`」。
 * systemd 单元里写了 `DSH_HOME` 的服务器当然没问题，但 **Windows 桌面端不会给宿主
 * 进程设这个变量**（Electron 直接继承用户注册表环境，DSH home 走默认的
 * `%USERPROFILE%\.dsh`），于是插件在那里必然报「没有 DSH_HOME，无法确定安装目录」。
 *
 * 这里直接复用 DSH 自己的 `resolveDshHome()`：与宿主的 sessions / profile / 凭据
 * 落在同一个根上，CLI 账户目录、arkcli 托管安装都不会"另起一套"。
 *
 * @returns 归一化后的绝对路径；连用户主目录都读不到时 undefined。
 */
export function resolveDshHomePath() {
  try {
    return resolveDshHome()
  } catch {
    // `os.homedir()` 在极端的裁剪环境里会抛错（拿不到用户主目录）；交给调用方给一句人话。
    return undefined
  }
}

export function apply(ctx, config) {
  // 关掉 settings 的"自动页面"：本插件自带设置分区，不需要再按原始 schema 生成一份
  // 表单页。官方 provider 插件（dsh-llm-deepseek / dsh-llm-pi-ai）都这么做。这份自动页
  // 会直接暴露 `apiKeyEnv` / `secretAccessKeyEnv` 这类凭据引用字段，与插件自己的 UI 重复。
  ctx.inject(['settings'], (child) => {
    child.effect(() => child.settings.configure({ auto: false }, ctx.fiber))
  })

  const marks = new AccountMarks()
  // DSH home 是插件所有持久状态的根（arkcli 的托管安装、各账户的 HOME）。
  // 解析规则与宿主一致（`$DSH_HOME` → `~/.dsh`），桌面端没有 DSH_HOME 也能用。
  const dshHome = resolveDshHomePath()
  const NO_DSH_HOME = '无法确定 DSH 数据目录（DSH_HOME 与用户主目录都不可用）：CLI 账户不可用。'

  /** 当前配置的普通值快照（每次都新鲜）。 */
  const live = () => unwrapVolatileConfig(config)

  /**
   * arkcli 进程封装：探测、安装、取额度、取目录。
   *
   * `binPath` 来自配置的 `arkcliPath`。**以前这个字段从来没有传进来过**：它被读进
   * `resolveConnection` 之后就再无消费者，`ArkCli` 的 `binPath` 分支永不命中，
   * 文档承诺的"显式指定 arkcli 可执行文件"是空头支票 —— 实际只会去找托管目录和
   * PATH，而 PATH 上的同名文件可能是别人放的（本插件以 root 运行它）。
   */
  const arkCli = new ArkCli({ dshHome, logger: ctx.logger, binPath: live().arkcliPath })
  /** 无浏览器登录的会话管理：谁在登录、授权 URL 是什么、回调喂回去没有。 */
  const login = new ArkCliLogin({ dshHome, logger: ctx.logger, binPath: live().arkcliPath })

  // --- 缓存 -----------------------------------------------------------------
  // 这些数据都来自子进程或控制面，轮询时不该每次都重新拉。
  const CLI_KEY_TTL_MS = 10 * 60_000
  const CLI_STATE_TTL_MS = 20_000
  const CLI_STATUS_TTL_MS = 30_000
  const FAILURE_TTL_MS = 60_000
  const cliKeyCache = new Map()
  const cliStateCache = new Map()
  const planCache = new Map()
  /** 在途请求：同一个键并发时复用同一个 Promise（见 catalogReport/plan 的注释）。 */
  const catalogPending = new Map()
  const planPending = new Map()
  /** 同一个键的在途请求只跑一次，后来者等同一份结果。 */
  const inFlight = async (registry, key, run) => {
    const existing = registry.get(key)
    if (existing !== undefined) return await existing
    const promise = Promise.resolve().then(run)
    registry.set(key, promise)
    try { return await promise } finally { registry.delete(key) }
  }
  /** AK/SK 备选来源的缓存。单独放，别和账户 id 挤在同一个 Map 里。 */
  let akskCache
  let cliStatusCache = { at: 0, value: undefined }
  let catalogCache = { at: 0, value: undefined }

  /**
   * 账户的 HOME：配置里写了就用写的，否则派生到 `<DSH_HOME>/ark-coding/accounts/<id>`。
   *
   * 显式 `home` 必须落在本插件状态根之下，理由：`accounts` 是 volatile（浏览器可写）
   * 字段，而它的 `home` 会被当成 **root 子进程的 HOME** —— arkcli 随后会在
   * `<HOME>/.arkcli/` 下写凭据、跑 `auth login`。账户 `id` 有白名单清洗，`home` 却是
   * 原样透传的，于是一次配置写入就能让 root 往任意目录写文件（`/etc`、`/root/.config`…）。
   * 运行时从来不需要自定义 HOME —— 多账户隔离靠的就是"每个账户一个派生目录"——
   * 所以越界的值直接拒绝，而不是悄悄接受。
   */
  const homeForAccount = (account) => {
    if (dshHome === undefined) throw new Error(NO_DSH_HOME)
    if (typeof account.home === 'string' && account.home !== '') {
      const root = arkcliStateRoot(dshHome)
      const resolved = resolvePath(account.home)
      if (resolved === root || resolved.startsWith(`${root}${pathSep}`)) return resolved
      throw new Error(`${NS}: 账户「${account.id}」的 home 必须位于 ${root} 之下，收到 ${account.home}。`)
    }
    return accountHomeDir(dshHome, account.id)
  }

  /** 按 id 找账户的 HOME（登录时账户可能还没写进配置，所以容忍找不到）。 */
  const homeForId = (accountId) => {
    const found = resolveConnection(live()).accounts.find((account) => account.id === accountId)
    return found === undefined ? homeForAccount({ id: accountId }) : homeForAccount(found)
  }

  /**
   * 派生缓存的键。
   *
   * **不能只用 `account.id`**：缓存的内容（API key、登录态、额度）取决于这个账户
   * 指向哪个 HOME / 什么类型 / 哪个凭据引用。用户删掉一个 CLI 账户再用同一个 id 新建
   * （或者改掉它的 `home`），旧键仍然命中，于是最长 10 分钟里继续拿**旧账户**的 key
   * 去发请求、额度和登录态也串台 —— 而删掉重建往往正是因为旧账户不该再用了。
   * 拼上这几个字段后，配置一变键就变，天然失效。id 经过白名单清洗，不含 `|`。
   */
  const cacheKeyOf = (account) => [
    account.id,
    account.type ?? '',
    account.home ?? '',
    account.ref ?? '',
  ].join('|')

  /** 清掉某个账户的所有派生缓存（登录成功/安装完成后必须调用）。 */
  const invalidateAccount = (accountId) => {
    if (accountId === undefined) {
      cliKeyCache.clear()
      cliStateCache.clear()
      planCache.clear()
      akskCache = undefined
    } else {
      // 键是 `${id}|…`，所以按前缀删。
      const prefix = `${accountId}|`
      for (const cache of [cliKeyCache, cliStateCache, planCache]) {
        for (const key of [...cache.keys()]) {
          if (key === accountId || key.startsWith(prefix)) cache.delete(key)
        }
      }
    }
    catalogCache = { at: 0, value: undefined }
  }

  /**
   * CLI 账户的 API key。
   *
   * SSO 登录完之后，arkcli 会把该身份下的 API key 落在自己的 profile 里，
   * `profile apikey get` 能打印明文。于是 CLI 账户既能查额度/目录，也能直接
   * 拿来聊天 —— 不需要用户再去控制台手抄一把 key。
   */
  const cliKeyOf = async (account) => {
    const cacheKey = cacheKeyOf(account)
    const hit = cliKeyCache.get(cacheKey)
    const now = Date.now()
    if (hit !== undefined && now - hit.at < CLI_KEY_TTL_MS) return hit.key
    let key
    try {
      const result = await arkCli.profileApiKey({ home: homeForAccount(account) })
      if (result.ok === true && typeof result.apiKey === 'string') {
        const parsed = normalizeApiKey(result.apiKey)
        if (parsed.ok === true) key = parsed.value
      }
    } catch { /* 取不到就当未配置，交给账号轮换去处理 */ }
    cliKeyCache.set(cacheKey, { key, at: now })
    return key
  }

  /** CLI 账户的登录态 + 身份（带缓存，避免每个轮询都起两个子进程）。 */
  const cliStateOf = async (account) => {
    const cacheKey = cacheKeyOf(account)
    const hit = cliStateCache.get(cacheKey)
    const now = Date.now()
    if (hit !== undefined && now - hit.at < CLI_STATE_TTL_MS) return hit.value
    let value
    try {
      const status = await cliStatus()
      if (status.installed !== true) {
        value = { loggedIn: false, needsInstall: true }
      } else {
        const home = homeForAccount(account)
        const auth = await arkCli.authStatus({ home })
        if (auth.loggedIn !== true) {
          value = { loggedIn: false }
        } else {
          const who = await arkCli.whoami({ home })
          value = {
            loggedIn: true,
            // 凭据的到期时间：决定"什么时候必须重新登录"。读不到就是 undefined，
            // 界面据此只显示"有时效"而不编一个日期出来。
            credentialExpiresAt: readCredentialExpiry(home),
            identity: {
              userName: who.userName,
              userId: who.userId,
              accountId: who.accountId,
              isRoot: who.isRoot,
              authMethod: who.authMethod,
            },
          }
        }
      }
    } catch (error) {
      // 单个账户的状态取不到不该让整份报告挂掉：如实标成未登录并带上原因。
      value = { loggedIn: false, error: errorText(error) }
    }
    cliStateCache.set(cacheKey, { value, at: now })
    return value
  }

  const adapter = new ArkCodingAdapter({
    config: () => config,
    ctx: () => ctx,
    marks,
    logger: ctx.logger,
    cliKey: cliKeyOf,
    cliAccountState: cliStateOf,
    attachments: () => {
      const attachments = ctx.get('attachments')
      return attachments === undefined ? undefined : attachments
    },
  })

  ctx.llm.registerAdapter([PROVIDER], adapter)
  ctx.llm.registerConfigurableProviders([
    { provider: PROVIDER, displayName: DISPLAY_NAME, settingsNs: NS, settingsPath: [] },
  ])
  ctx.llm.registerModelDiscovery(NS, createDiscovery())

  /** arkcli 探测结果（带缓存）。 */
  const cliStatus = async (force = false) => {
    const now = Date.now()
    if (!force && cliStatusCache.value !== undefined && now - cliStatusCache.at < CLI_STATUS_TTL_MS) {
      return cliStatusCache.value
    }
    let value
    try {
      value = await arkCli.status()
    } catch (error) {
      value = { installed: false, error: errorText(error) }
    }
    cliStatusCache = { at: now, value }
    return value
  }

  /** 找第一个已登录的 CLI 账户的 HOME —— 控制面数据（额度/目录）用它拉。 */
  const firstLoggedInHome = async (connection) => {
    for (const account of connection.accounts) {
      if (account.type !== TYPE_CLI) continue
      const state = await cliStateOf(account)
      if (state.loggedIn === true) return homeForAccount(account)
    }
    return undefined
  }

  /**
   * 官方模型目录。
   *
   * 目录是**对照**不是覆盖：内置那 12 行的容量/模态是打 Coding Plan 端点实测的，
   * 而 arkcli 给的是方舟通用目录的元数据，两者本来就可能有出入。所以这里把官方
   * 值并排挂上去、把分歧点列出来，让用户看得见，而不是偷偷改掉实测值。
   */
  const catalogReport = async (force = false) => {
    const connection = resolveConnection(live())
    const now = Date.now()
    const cached = catalogCache.value
    if (!force && cached !== undefined) {
      const ttl = cached.ok === true ? connection.catalogRefreshSeconds * 1000 : FAILURE_TTL_MS
      if (now - catalogCache.at < ttl) return cached
    }
    // 在途去重：缓存只在 await 之后才写，所以并发调用必然全部 miss。设置页按钮连点、
    // 或者一次 report() 正好撞上手动刷新，会同时起多个 node + arkcli 子进程。
    // 实测并发 5 次强制刷新 = 5 个子进程。这里让它们共用同一个在途 Promise。
    return await inFlight(catalogPending, 'catalog', async () => {
      const empty = (error) => ({
        ok: false,
        error,
        source: undefined,
        updatedAt: undefined,
        total: 0,
        models: MODELS,
        matched: 0,
        conflicts: [],
        unmatchedOfficial: 0,
        officialSample: [],
      })
      const status = await cliStatus()
      if (status.installed !== true) {
        const value = empty('还没有可用的 arkcli：先在设置页里点「安装 arkcli」。')
        catalogCache = { at: Date.now(), value }
        return value
      }
      const home = await firstLoggedInHome(connection)
      if (home === undefined) {
        const value = empty('拉取官方模型目录需要一个已登录的 CLI 账户。')
        catalogCache = { at: Date.now(), value }
        return value
      }
      let result
      try {
        result = await arkCli.modelsSearch({ home, size: 0 })
      } catch (error) {
        result = { ok: false, items: [], error: errorText(error) }
      }
      if (result.ok !== true) {
        const value = empty(result.error ?? '官方目录拉取失败。')
        catalogCache = { at: Date.now(), value }
        return value
      }
      const annotated = annotateModels(MODELS, result.items, { updatedAt: result.updatedAt, source: 'arkcli' })
      const value = {
        ok: true,
        error: undefined,
        source: 'arkcli',
        updatedAt: result.updatedAt,
        total: result.items.length,
        ...annotated,
      }
      catalogCache = { at: Date.now(), value }
      return value
    })
  }

  /**
   * 组装一次用量报告。
   *
   * 真实套餐额度（plan）优先走 arkcli：每个已登录的 CLI 账户各查一次，谁有
   * 数据谁上。AK/SK 只作为备选（没有 CLI 账户、或 CLI 账户都没登录时）。
   * 两条路都拿不到就如实说明原因（分三种：没账户 / 有 CLI 账户但没登录 /
   * 只有 API Key）—— **不再回落到本机统计**：本机 token 数不是套餐额度，
   * 摆在一起只会让人误读成"还剩这么多"。
   */
  const report = async () => {
    const connection = resolveConnection(live())
    const accounts = await adapter.accountStates()

    // --- 每个 CLI 账户各自的真实额度 ---
    const planAccounts = []
    /** 至少有一个 CLI 账户真的登录了（不是"配了 CLI 账户"）。 */
    let cliLoggedIn = false
    for (const account of connection.accounts) {
      if (account.type !== TYPE_CLI) continue
      const state = await cliStateOf(account)
      if (state.loggedIn !== true) {
        planAccounts.push({
          accountId: account.id,
          label: account.label,
          ok: false,
          windows: [],
          error: state.needsInstall === true ? '还没有安装 arkcli。' : '这个账户尚未登录。',
        })
        continue
      }
      cliLoggedIn = true
      const ttl = connection.usageRefreshSeconds * 1000
      const cacheKey = cacheKeyOf(account)
      const hit = planCache.get(cacheKey)
      let plan
      if (hit !== undefined && Date.now() - hit.at < ttl) {
        plan = hit.value
      } else {
        // 在途去重（同上）：控制面超时 120s，而客户端轮询是 fire-and-forget，
        // 慢的时候会叠起多个 `arkcli usage plan` 子进程。
        plan = await inFlight(planPending, cacheKey, async () => {
          let fetched
          try {
            fetched = await arkCli.usagePlan({ home: homeForAccount(account) })
          } catch (error) {
            fetched = { ok: false, error: errorText(error) }
          }
          const value = fetched.ok === true
            ? { ok: true, items: fetched.items, viewer: fetched.viewer, error: undefined }
            : { ok: false, items: [], error: fetched.error ?? '额度查询失败。' }
          planCache.set(cacheKey, { at: Date.now(), value })
          return value
        })
      }
      if (plan.ok !== true) {
        planAccounts.push({ accountId: account.id, label: account.label, ok: false, windows: [], error: plan.error })
        continue
      }
      const shaped = windowsFromItems(plan.items)
      planAccounts.push({
        accountId: account.id,
        label: account.label,
        ok: shaped.windows.length > 0,
        windows: shaped.windows,
        error: shaped.error,
        tier: shaped.tier,
        updatedAt: shaped.updatedAt,
        viewer: plan.viewer,
      })
    }

    // --- AK/SK 备选：只在没有任何 CLI 账户给出数据时才去试 ---
    let akskEntry
    const anyCliOk = planAccounts.some((entry) => entry.ok === true)
    if (!anyCliOk && connection.accessKeyId !== '') {
      const cachedFor = `${connection.accessKeyId}|${connection.secretAccessKeyEnv}|${connection.region}`
      const ttl = connection.usageRefreshSeconds * 1000
      if (akskCache !== undefined && akskCache.key === cachedFor && Date.now() - akskCache.at < ttl) {
        akskEntry = akskCache.value
      } else if (akskCache !== undefined && akskCache.key === cachedFor && akskCache.value.ok !== true && Date.now() - akskCache.at < FAILURE_TTL_MS) {
        akskEntry = akskCache.value
      } else {
        akskEntry = await (async () => {
          const base = { accountId: '__aksk__', label: 'AK/SK', source: 'aksk' }
          let secret
          try {
            secret = await adapter.resolveRef(connection.secretAccessKeyEnv, undefined)
          } catch (error) {
            return { ...base, ok: false, windows: [], error: `Secret AccessKey 不可用：${errorText(error)}` }
          }
          if (secret === undefined) {
            return { ...base, ok: false, windows: [], error: `未配置 Secret AccessKey（凭据引用 ${connection.secretAccessKeyEnv}）。` }
          }
          try {
            const usage = await fetchCodingPlanUsage({
              accessKeyId: connection.accessKeyId,
              secretAccessKey: secret,
              region: connection.region,
            })
            if (usage.windows.length === 0) {
              return { ...base, ok: false, windows: [], error: '控制面没有返回任何额度窗口。' }
            }
            return { ...base, ok: true, windows: usage.windows, updatedAt: usage.updatedAt }
          } catch (error) {
            return { ...base, ok: false, windows: [], error: errorText(error) }
          }
        })()
        akskCache = { at: Date.now(), key: cachedFor, value: akskEntry }
      }
    }

    const allPlanEntries = akskEntry === undefined ? planAccounts : [...planAccounts, akskEntry]
    const firstOk = allPlanEntries.find((entry) => entry.ok === true)

    // --- 侧边栏卡片该不该显示（`sidebarQuota: auto` 的判据） --------------------
    // 「有绑定」= 已登录的 CLI 账户，或一对填全了的 AK/SK。判据刻意**不看这一次
    // 拉取成不成功**：登录已经完成、AK/SK 已经填好，那就该显示卡片；控制面抖一下
    // 或者网断一下，不该让卡片自己闪没。
    const akskBound = cliLoggedIn || connection.accessKeyId === ''
      ? false
      : await (async () => {
        try {
          return (await adapter.resolveRef(connection.secretAccessKeyEnv, undefined)) !== undefined
        } catch {
          return false
        }
      })()
    const usageCapable = cliLoggedIn || akskBound
    const sidebarQuota = sidebarQuotaState(connection.sidebarQuota, usageCapable)

    const cliAccountsExist = connection.accounts.some((account) => account.type === TYPE_CLI)
    // 三类"查不到额度"的原因要分开说，否则用户不知道该动哪里：
    //   · 一个账户都没有 → 去建账户；
    //   · 有 CLI 账户但没登录 → 去登录；
    //   · 只有 API Key 账户 → 说清楚 API Key 天生查不到，要么加 CLI 账户，要么填 AK/SK。
    const accountsExist = connection.accounts.length > 0
    const plan = firstOk === undefined
      ? {
        ok: false,
        source: undefined,
        windows: [],
        accounts: allPlanEntries,
        error: allPlanEntries.find((entry) => typeof entry.error === 'string' && entry.error !== '')?.error
          ?? (cliAccountsExist
            ? 'CLI 账户还没有登录。'
            : (accountsExist
              ? 'API Key 只能聊天，查不到套餐额度：额度在控制面，只认 SSO 身份（或一对 AK/SK）。想要百分比就再加一个「CLI 登录」的账户，或填下面的 AK/SK。'
              : '还没有任何账户：点上面的「添加账户」建一个。「CLI 登录」能给真实额度，「API Key」只能聊天。')),
      }
      : {
        ok: true,
        source: firstOk.source ?? 'arkcli',
        windows: firstOk.windows,
        updatedAt: firstOk.updatedAt,
        accounts: allPlanEntries,
        error: undefined,
      }

    const catalog = await catalogReport()
    const cli = await cliStatus()

    return {
      provider: PROVIDER,
      displayName: DISPLAY_NAME,
      accounts,
      plan,
      catalog,
      cli: {
        installed: cli.installed === true,
        path: cli.path,
        version: cli.version,
        source: cli.source,
        error: cli.error,
      },
      activeAccount: connection.activeAccount,
      sidebarQuota,
      refreshSeconds: connection.usageRefreshSeconds,
      reportedAt: Date.now(),
    }
  }

  /** 登录成功后统一收尾：清缓存 + 拿身份。 */
  const finishLogin = async (accountId) => {
    invalidateAccount(accountId)
    let identity
    try {
      const who = await arkCli.whoami({ home: homeForId(accountId) })
      identity = {
        userName: who.userName,
        userId: who.userId,
        accountId: who.accountId,
        isRoot: who.isRoot,
        authMethod: who.authMethod,
      }
    } catch { /* 身份拿不到不算登录失败 */ }
    return identity
  }

  const accountIdOf = (input) => (typeof input.accountId === 'string' ? input.accountId.trim() : '')

  const deps = {
    report,

    async cliStatus() {
      const status = await cliStatus(true)
      return {
        ok: status.installed === true,
        installed: status.installed === true,
        path: status.path,
        version: status.version,
        source: status.source,
        error: status.error,
      }
    },

    async cliInstall() {
      let result
      try {
        result = await arkCli.install()
      } catch (error) {
        return { ok: false, error: errorText(error) }
      }
      invalidateAccount(undefined)
      cliStatusCache = { at: 0, value: undefined }
      const status = await cliStatus(true)
      return {
        ok: result.ok === true && status.installed === true,
        path: status.path ?? result.path,
        version: status.version ?? result.version,
        installed: status.installed === true,
        error: result.ok === true && status.installed !== true
          ? (status.error ?? '安装完成但 arkcli 无法执行。')
          : result.error,
      }
    },

    async catalogRefresh() {
      const value = await catalogReport(true)
      return value
    },

    async loginBegin(input) {
      const accountId = accountIdOf(input)
      if (accountId === '') return { ok: false, error: '缺少账户 id。' }
      const home = homeForId(accountId)
      // 同一个账户重复点「登录」时，先把上一条会话收掉，免得留下孤儿进程。
      try { await login.cancel({ ref: accountId }) } catch { /* 没有旧会话就无所谓 */ }
      const started = await login.start({ home, ref: accountId })
      if (started.ok !== true) {
        return { ok: false, accountId, error: started.error }
      }
      return {
        ok: true,
        accountId,
        url: started.url,
        port: started.port,
        error: undefined,
        // 这里**不再返回一段写死的说明文字**：客户端已经有等价且双语的
        // `loginFerryNote` / `loginOrWait`（它才是负责本地化的那一侧）。宿主返回中文
        // 只会在英文界面里夹一整天中文，所以只回一个机器可读的标记。
        notice: 'copyCallbackUrl',
      }
    },

    async loginPoll(input) {
      const accountId = accountIdOf(input)
      if (accountId === '') return { ok: false, error: '缺少账户 id。' }
      const polled = login.poll({ ref: accountId })
      if (polled.state === 'unknown') {
        return { ok: false, accountId, state: 'unknown', error: '登录会话不存在（可能已取消或插件重启过）。' }
      }
      if (polled.state === 'done') {
        const identity = await finishLogin(accountId)
        return { ok: true, accountId, state: 'done', identity, error: undefined }
      }
      return {
        ok: polled.ok !== false,
        accountId,
        state: polled.state,
        url: polled.url,
        error: polled.error,
      }
    },

    async loginSubmit(input) {
      const accountId = accountIdOf(input)
      if (accountId === '') return { ok: false, error: '缺少账户 id。' }
      const raw = typeof input.input === 'string' ? input.input : ''
      let submitted
      try {
        submitted = await login.submit({ ref: accountId, input: raw })
      } catch (error) {
        return { ok: false, accountId, state: 'error', error: errorText(error) }
      }
      if (submitted.state === 'done') {
        const identity = await finishLogin(accountId)
        return { ok: true, accountId, state: 'done', identity, error: undefined }
      }
      return {
        ok: submitted.ok === true,
        accountId,
        state: submitted.state,
        note: submitted.note,
        error: submitted.error,
      }
    },

    async loginCancel(input) {
      const accountId = accountIdOf(input)
      if (accountId === '') return { ok: false, error: '缺少账户 id。' }
      try {
        const cancelled = await login.cancel({ ref: accountId })
        return { ok: true, cancelled: cancelled?.killed === true, accountId }
      } catch (error) {
        return { ok: false, accountId, error: errorText(error) }
      }
    },
  }

  ctx.inject(['typert'], (remoteCtx) => {
    new ArkCodingUsageService(remoteCtx, deps)
    const registry = remoteCtx.typert
    const unregister = registry.register({
      package: REMOTE_PACKAGE,
      face: 'host',
      schemas: [],
      // 手写 Remote 没有生成的反射模型，用官方的"空模型"形状，
      // 而不是留一个 undefined 给注册表检查。
      model: { services: [], events: [], objects: [] },
      invocations: [
        USAGE_REPORT_DESCRIPTOR,
        CLI_STATUS_DESCRIPTOR,
        CLI_INSTALL_DESCRIPTOR,
        CATALOG_REFRESH_DESCRIPTOR,
        LOGIN_BEGIN_DESCRIPTOR,
        LOGIN_POLL_DESCRIPTOR,
        LOGIN_SUBMIT_DESCRIPTOR,
        LOGIN_CANCEL_DESCRIPTOR,
      ],
    })
    remoteCtx.effect(() => () => void unregister(), `${NS}: usage remote`)
  })

  // 插件卸载时把还挂着的登录子进程收掉，别留孤儿。
  // 用可选调用：精简的测试 ctx 上没有 effect，而"收尾"这件事不该让插件挂不起来。
  if (typeof ctx.effect === 'function') {
    ctx.effect(() => () => {
      try { login.disposeAll() } catch { /* 卸载阶段尽力而为 */ }
    }, `${NS}: arkcli login sessions`)
  }

  ctx.logger?.info?.(`${NS}: 已注册 ${MODELS.length} 个火山方舟 Coding Plan 模型（路由 ${PROVIDER}）`)
}

export {
  MODELS,
  modelById,
  withoutUndefined,
  toModelInfo,
  toResolvedModelInfo,
  contextWindowOf,
  modelIsVisible,
  resolveConnection,
  unwrapVolatileConfig,
}
