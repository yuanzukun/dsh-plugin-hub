/**
 * dsh-ark-coding-provider —— 浏览器半边。
 *
 * 三个席位：
 *  1. `settings.section`（id `arkcoding`）：设置页。账户（API Key / CLI SSO 两种）、
 *     CLI 登录向导、模型目录对照、按账户的套餐额度、高级连接参数。
 *  2. `settings.models.provider-card`（key `llm-ark-coding`）：Models 页那张
 *     提供商卡片里的密钥状态 + 粘贴框。
 *  3. `sidebar.footer.action`：左下角的用量卡片，跟着 `arkcoding/report` 实时刷新。
 *
 * 三条硬规则：
 * - **密钥走凭据域**（`remote.credentials`），永不写进设置文档、永不回传浏览器。
 * - **远端命名空间谁声明谁读取**：在只声明了 A 的注入上下文里读 B，cordis 会抛
 *   `cannot get property "B" without inject`，而且这个异常发生在注入回调内部，
 *   外层 try/catch 抓不到（2026-10-16 真机上就是这么坏的）。所以所有 `remote.arkcoding`
 *   的方法都在**同一次** `inject(['remote.arkcoding'])` 里捕获，不再二次挂载。
 * - **远端方法只收一个对象参数**：宿主每个方法声明的线网参数恰好一个、名为 `input`，
 *   传 0 个或 2 个都会被 Gateway 的精确参数检查拒掉（契约 §1）。
 *
 * 样式只用主题 token（`--dsw-*`），不引入任何 Harness Client 包，也不碰别人的 DOM。
 */

window.__ModuleLoader__.load({
  id: 'dsh-ark-coding-provider',
  factory(require) {
    const React = require('react')
    const h = React.createElement
    const { useCallback, useEffect, useRef, useState, useSyncExternalStore } = React

    const PROVIDER = 'ark-coding'
    const NS = 'llm-ark-coding'
    const DEFAULT_API_BASE = 'https://ark.cn-beijing.volces.com/api/coding/v3'
    const DEFAULT_KEY_REF = 'ARK_CODING_API_KEY'
    const DEFAULT_SECRET_REF = 'ARK_ACCESS_KEY_SECRET'
    const SECTION_ID = 'arkcoding'
    const CARD_KEY = NS
    const SIDEBAR_ID = 'arkcoding-quota'
    const CSS_ID = 'ark-coding-provider-css'
    const LOCALE_NS = 'settings.arkcoding'
    const REMOTE_PACKAGE = 'dsh-ark-coding-provider'
    const REMOTE_SERVICE = 'arkCodingUsage'
    const REMOTE_NAMESPACE = 'arkcoding'

    /** 登录向导的轮询节奏：契约要求 ~2s 首查、~2.5s 复查。 */
    const LOGIN_POLL_FIRST_MS = 2_000
    const LOGIN_POLL_EVERY_MS = 2_500

    /**
     * 浏览器半边的端点贡献：与宿主 `index.js` 的 `USAGE_CLIENT_CONTRIBUTION` 一一对应。
     *
     * 之前这里只声明了 `report`，于是登录/安装/目录这些新方法在浏览器侧根本没有线网绑定。
     * 现在扩到宿主提供的全部 8 个端点 —— 仍然是**一个** package/namespace、**一次** mount，
     * 只是描述符多了几条。带参数的方法照抄宿主的 `actionOf`：线网参数名固定 `input`。
     */
    function resultSchema(method) {
      return {
        mode: 'strict',
        typeSymbol: `${REMOTE_PACKAGE}#${REMOTE_NAMESPACE}/${method}:result`,
        create: () => ({
          parse: (value) => {
            if (typeof value !== 'object' || value === null || Array.isArray(value)) {
              throw new TypeError(`arkcoding/${method}: 结果不是对象`)
            }
            return value
          },
        }),
      }
    }

    /**
     * 参数 schema。
     *
     * **必须是 `mode: 'strict'`**：浏览器端的贡献校验只收 strict codec，写
     * `{ mode: 'src-json' }`（协议里那个"不校验的原始 JSON"档，宿主网关自己内部
     * 也用它）会被当场拒掉 —— 报 `field "input" has no strict codec`，而且抛出
     * 位置在 `$mount` 里，于是**所有**端点一起失效、用量卡片永远停在 Loading。
     * 这个坑离线测试抓不到（假 `$mount` 不校验），只有真开一次页面才看得见。
     */
    function inputSchema(method) {
      return {
        mode: 'strict',
        typeSymbol: `${REMOTE_PACKAGE}#${REMOTE_NAMESPACE}/${method}:input`,
        create: () => ({
          parse: (value) => {
            if (typeof value !== 'object' || value === null || Array.isArray(value)) {
              throw new TypeError(`arkcoding/${method}: 参数不是对象`)
            }
            return value
          },
        }),
      }
    }

    function descriptorOf(method, withInput) {
      return {
        id: `${REMOTE_PACKAGE}#${REMOTE_NAMESPACE}/${method}`,
        service: REMOTE_SERVICE,
        namespace: REMOTE_NAMESPACE,
        method,
        invocation: { kind: 'direct' },
        parameters: withInput
          ? [{ name: 'input', wire: 'input', source: 'json', codec: inputSchema(method) }]
          : [],
        result: resultSchema(method),
      }
    }

    const USAGE_CONTRIBUTION = {
      package: REMOTE_PACKAGE,
      descriptors: [
        descriptorOf('report', false),
        descriptorOf('cliStatus', false),
        descriptorOf('cliInstall', false),
        descriptorOf('catalogRefresh', false),
        descriptorOf('loginBegin', true),
        descriptorOf('loginPoll', true),
        descriptorOf('loginSubmit', true),
        descriptorOf('loginCancel', true),
      ],
    }

    /**
     * 目录的浏览器端副本：宿主报告里没带 catalog 时用它兜底。
     * 容量与模态是实测 + 官方文档核对过的值，改这里必须同步宿主 `models.js`。
     */
    const CATALOG = [
      { id: 'doubao-seed-evolving', name: 'Doubao-Seed-Evolving', family: 'Doubao', ctx: 1048576, out: 262144, input: ['text', 'image'] },
      { id: 'doubao-seed-2.1-pro', name: 'Doubao-Seed-2.1-pro', family: 'Doubao', ctx: 1048576, out: 262144, input: ['text', 'image'] },
      { id: 'doubao-seed-2.1-lite', name: 'Doubao-Seed-2.1-lite', family: 'Doubao', ctx: 1048576, out: 262144, input: ['text', 'image'] },
      { id: 'doubao-seed-2.0-mini', name: 'Doubao-Seed-2.0-mini', family: 'Doubao', ctx: 262144, out: 131072, input: ['text', 'image'] },
      { id: 'minimax-m3', name: 'MiniMax-M3', family: 'MiniMax', ctx: 1048576, out: 131072, input: ['text', 'image'] },
      { id: 'glm-5.3', name: 'GLM-5.3', family: 'Zhipu', ctx: 1048576, out: 131072, input: ['text'] },
      { id: 'glm-5.3-flash', name: 'GLM-5.3-Flash', family: 'Zhipu', ctx: 1048576, out: 131072, input: ['text', 'image'] },
      { id: 'deepseek-v4.1-flash', name: 'DeepSeek-V4.1-Flash', family: 'DeepSeek', ctx: 1048576, out: 393216, input: ['text', 'image'] },
      { id: 'deepseek-v4-flash', name: 'DeepSeek-V4-Flash', family: 'DeepSeek', ctx: 1048576, out: 393216, input: ['text'] },
      { id: 'deepseek-v4-pro', name: 'DeepSeek-V4-Pro', family: 'DeepSeek', ctx: 1048576, out: 393216, input: ['text'] },
      { id: 'kimi-k2.8-preview', name: 'Kimi-K2.8-Preview', family: 'Moonshot', ctx: 1048576, out: 131072, input: ['text', 'image'] },
      { id: 'kimi-k3', name: 'Kimi-K3', family: 'Moonshot', ctx: 1048576, out: 131072, input: ['text', 'image'] },
    ]

    // -----------------------------------------------------------------------
    // 文案
    // -----------------------------------------------------------------------

    const ZH = {
      nav: '火山方舟', title: '火山方舟 Coding Plan',
      subtitle: 'OpenAI 兼容端点 · 十二个 Coding Plan 模型 · API Key / CLI 双登录',
      save: '保存', discard: '放弃', saved: '已保存', unsaved: '有未保存的修改',
      cancel: '取消', copy: '复制地址', copied: '已复制',
      accountsSection: '账户', accountsHint: '账户操作立即生效。一个账户的额度打满或被限流时，请求会自动轮到下一个可用账户。',
      addAccount: '添加账户', removeAccount: '移除',
      accountsEmptyTitle: '还没有账户。',
      accountsEmptyBody: '聊天至少需要一个账户：先添加一个，它就会出现在这张卡片里，可以改名、设优先。',
      accountsEmptyTypes: '两种账户：API Key 能直接聊天，但查不到套餐额度和官方模型目录（那两样在控制面，只认 SSO 身份或一对 AK/SK）；CLI 登录（SSO）一次登录就同时拿到聊天密钥、真实的 5 小时 / 周 / 月额度和官方目录。',
      typeNoteApiKey: 'API Key 账户可以聊天，但查不到套餐额度和官方模型目录 —— 控制面只认 SSO 身份或一对 AK/SK。想看到用量数字，请在下面的「用量与显示」卡片里再填 AK/SK。',
      typeNoteCli: 'CLI 登录（SSO）一次登录同时拿到聊天用的 API Key、真实的 5 小时 / 周 / 月额度和官方模型目录。',
      typeNoteCliExpiry: '凭据有效期至', typeNoteCliExpiryUnknown: '凭据有时效，登录完成后这里会显示具体到期日期。',
      credentialExpires: '凭据有效期至', credentialExpired: '凭据已过期，需要重新登录',
      credentialExpiresIn: '凭据将在', credentialDaysLeft: '天后到期',
      providerReady: '已就绪', providerUsing: '当前使用', providerQuotaSource: '额度来源',
      providerNoAccounts: '还没有账户。', providerNoAccountsHint: '请到「设置 → 火山方舟」添加一个账户（API Key 或 CLI 登录），聊天才能用这个提供商。',
      providerNoneConfigured: '账户都还没配置好。', providerNoneConfiguredHint: '请到「设置 → 火山方舟」填写 API Key，或完成 CLI 登录。',
      accountKeyPlaceholder: '粘贴这个账户的 API key…',
      accountConfigured: '已配置', accountMissing: '未配置', accountPreferred: '优先使用', accountUse: '设为优先',
      cooling: '冷却中', until: '至', reasonRateLimit: '限流', reasonQuota: '额度用尽', reasonAuth: '密钥失效',
      accountType: '账户类型', typeApiKey: 'API Key', typeCli: 'CLI 登录 (SSO)',
      accountName: '名称（可选）', accountNamePlaceholder: '留空即可',
      accountNameOptional: '留空就用默认名（API Key 账户 N / CLI 账户 N）。',
      addConfirm: '确认添加', addKeyRequired: '请先粘贴 API Key。',
      accountRefLabel: '凭据引用', accountHomeLabel: '登录目录',
      cliAddHint: '添加后立刻开始登录，向导会出现在这张卡片里。',
      loggedInAs: '已登录', notLoggedIn: '未登录', reLogin: '重新登录',
      removeConfirm: '确认移除？', removeConfirmYes: '确认移除', removeHomeNote: '只从设置里移除；服务器上的 CLI 登录目录不会被删除。',
      cliSection: 'arkcli', cliReady: 'arkcli 已就绪', cliMissing: '还没有安装 arkcli：CLI 登录与真实套餐额度都要用它。',
      cliInstall: '安装 arkcli', cliInstalling: '安装中…（下载约 40 MB）', cliInstallFailed: '安装失败',
      cliVersion: '版本', cliPath: '路径',
      loginTitle: 'CLI 登录', loginStarting: '正在向 arkcli 申请授权链接…',
      loginUrlLabel: '授权地址', loginOpen: '打开授权页面',
      loginStepAuthorize: '1 打开授权页', loginStepPaste: '2 粘回回调地址', loginStepDone: '3 完成',
      loginWaiting: '等待授权…', loginDone: '登录成功', loginFailed: '登录失败',
      loginSessionExpired: '登录会话已过期，请重新发起授权。',
      loginIdentityName: '用户名', loginIdentityAccount: '账号',
      loginFerryNote: '登录完成后，浏览器会跳到 http://127.0.0.1:<端口>/… 并显示「无法访问」——这是正常的：那个端口开在跑 DSH 的服务器上，不在你的电脑上。请把地址栏里那条完整的 127.0.0.1 地址复制下来，粘到下面的输入框里。',
      loginOrWait: '也可以什么都不做：如果你恰好能访问那个端口，登录会在后台自动完成 —— 下面会自动轮询。',
      loginPasteLabel: '粘贴回调地址', loginPastePlaceholder: '把地址栏里那条 127.0.0.1:… 的完整地址粘到这里',
      loginSubmit: '提交回调地址', loginRestart: '重新开始', loginNote: '提示',
      modelsSection: '模型', modelsHint: '取消勾选的模型不会出现在模型选择器里；全部勾选等于全部可见。',
      selectAll: '全选', selectNone: '全不选', modelsDirty: '模型选择已修改，点「保存」生效（只写一次）。',
      context: '上下文', output: '输出上限', textOnly: '纯文本', vision: '图像',
      catalogOfficial: '官方目录', catalogRefresh: '刷新官方目录', catalogRefreshing: '刷新中…',
      catalogUpdated: '目录更新于', catalogUnavailable: '官方目录读取失败', catalogMeasured: '实测',
      catalogConflict: '两处不一致', catalogConflictNote: '以实测值为准 —— 官方目录来自通用 ARK，可能与套餐端点不同，这里不覆盖实测值。',
      catalogUnmatchedPrefix: '官方目录里还有', catalogUnmatchedSuffix: '个模型不在本套餐列表中', catalogUnmatchedSample: '例如',
      inputModality: '模态',
      usageSection: '用量与显示',
      usageHint: '套餐额度只认「CLI 登录」的账户或一对 AK/SK。两者都没有就只说明缺什么 —— 不再拿本机 token 数冒充额度。',
      usageSourcePlan: '套餐额度', usageUnavailable: '不可用',
      usageWindow5h: '5 小时', usageWindowWeekly: '本周', usageWindowMonthly: '本月',
      usageAccountQuota: '账户额度', usageTotals: '已用 / 总量',
      refreshNow: '立即刷新', refreshedAt: '更新于', resetAt: '重置',
      akId: 'AccessKey ID', akIdHint: '不是 ark- 订阅 key；是火山账号的 AKLT…', skRef: 'Secret 凭据引用',
      skHint: 'Secret 写进凭据服务，不写配置文件。', region: '区域',
      sidebarQuotaLabel: '侧边栏用量卡片',
      sidebarQuotaHint: '卡片拿不到真实套餐额度时不显示，也不会拿别的数字顶上。',
      sidebarQuotaAuto: '自动', sidebarQuotaOn: '始终显示', sidebarQuotaOff: '始终隐藏',
      sidebarQuotaAutoHint: '自动 = 有能查额度的绑定（已登录的 CLI 账户，或一对 AK/SK）就显示。',
      sidebarQuotaEffective: '当前',
      refreshSeconds: '刷新间隔（秒）',
      advancedSection: '高级设置', advancedHint: 'API 地址和网络参数，一般无需修改。',
      apiBase: 'API 地址', requestTimeout: '请求超时（毫秒）', streamIdleTimeout: '流空闲超时（毫秒）',
      defaultMaxTokens: '默认输出上限', contextOverrides: '逐模型上下文覆盖',
      contextOverridesHint: '留空则用目录里的容量；上游改了容量时可在这里覆盖，不必等插件更新。',
      keySection: 'API 密钥',
      keyHint: '密钥只写入本机凭据服务，不会进入配置文件，也不会回传到浏览器。',
      clear: '清除', cleared: '已清除',
      credentialsUnavailable: '凭据服务未挂载：请在启动环境里导出该变量，或刷新页面。',
      credentialWriteFailed: '写入凭据失败', credentialClearFailed: '清除凭据失败',
      readOnly: '当前设置是只读的。', unavailable: '设置服务未挂载，页面只能显示只读信息。',
      loadFailed: '读取设置失败', saveFailed: '保存失败', usageFailed: '用量读取失败',
      // 远端方法缺席时的稳定 code：控制器只存 code，渲染处再翻成当前语言，
      // 否则英文界面里会冒出中文原文。
      hostMissingReport: '宿主未提供 arkcoding/report',
      hostMissingCliInstall: '宿主未提供 arkcoding/cliInstall',
      hostMissingLoginBegin: '宿主未提供 arkcoding/loginBegin',
      hostMissingLoginPoll: '宿主未提供 arkcoding/loginPoll',
      hostMissingLoginSubmit: '宿主未提供 arkcoding/loginSubmit',
      providerCardHint: '账户、模型和额度都在「设置 → 火山方舟」里管理；这张卡片只显示当前用的是哪个账户。',
      sidebarTitle: '火山方舟',
      sidebarLoading: '读取中…', sidebarOpenHint: '点击查看详情',
      sidebarUnavailable: '额度暂时读不到',
      sidebarDetailTitle: '火山方舟 Coding Plan',
      sidebarDetailLogin: '登录情况', sidebarDetailQuota: '额度',
      sidebarDetailClose: '收起详情', sidebarRefresh: '刷新', sidebarDetailSource: '来源',
      sidebarDetailNoBindingHint: '在「设置 → 火山方舟」里添加一个「CLI 登录」账户（顺便拿到真实额度），或填一对 AK/SK。',
      sourceArkcli: 'arkcli（SSO）', sourceAksk: 'AK/SK',
    }

    const EN = {
      nav: 'Volcengine Ark', title: 'Volcengine Ark Coding Plan',
      subtitle: 'OpenAI-compatible endpoint · twelve Coding Plan models · API key or CLI sign-in',
      save: 'Save', discard: 'Discard', saved: 'Saved', unsaved: 'Unsaved changes',
      cancel: 'Cancel', copy: 'Copy URL', copied: 'Copied',
      accountsSection: 'Accounts', accountsHint: 'Account operations apply immediately. When one account hits its limit or is throttled, requests move to the next usable account.',
      addAccount: 'Add account', removeAccount: 'Remove',
      accountsEmptyTitle: 'No accounts yet.',
      accountsEmptyBody: 'Chat needs at least one account: add one and it shows up in this card, ready to rename or mark as preferred.',
      accountsEmptyTypes: 'Two kinds of account: an API Key can chat right away but cannot read plan quota or the official model catalog (both live in the control plane, which accepts only an SSO identity or an AK/SK pair); CLI sign-in (SSO) gets the chat key, the real 5-hour / weekly / monthly quota and the official catalog in one login.',
      typeNoteApiKey: 'An API Key account can chat, but it cannot read plan quota or the official model catalog — the control plane accepts only an SSO identity or an AK/SK pair. To see usage numbers anyway, also fill the AK/SK fields in the Usage & display card below.',
      typeNoteCli: 'One CLI sign-in (SSO) gives you the chat API key, the real 5-hour / weekly / monthly quota and the official model catalog.',
      typeNoteCliExpiry: 'credential valid until', typeNoteCliExpiryUnknown: 'The credential is time-limited; the exact expiry date appears here after signing in.',
      credentialExpires: 'Credential valid until', credentialExpired: 'Credential expired — sign in again',
      credentialExpiresIn: 'Credential expires in', credentialDaysLeft: 'days',
      providerReady: 'Ready', providerUsing: 'Using', providerQuotaSource: 'Quota source',
      providerNoAccounts: 'No accounts yet.', providerNoAccountsHint: 'Add an account (API key or CLI sign-in) under Settings → Volcengine Ark before chat can use this provider.',
      providerNoneConfigured: 'No account is configured yet.', providerNoneConfiguredHint: 'Add an API key or finish a CLI sign-in under Settings → Volcengine Ark.',
      accountKeyPlaceholder: 'Paste this account’s API key…',
      accountConfigured: 'Configured', accountMissing: 'Not configured', accountPreferred: 'Preferred', accountUse: 'Prefer',
      cooling: 'cooling down', until: 'until', reasonRateLimit: 'rate limited', reasonQuota: 'quota exhausted', reasonAuth: 'invalid key',
      accountType: 'Account type', typeApiKey: 'API Key', typeCli: 'CLI sign-in (SSO)',
      accountName: 'Name (optional)', accountNamePlaceholder: 'Leave blank',
      accountNameOptional: 'Leave blank for the default label (API Key account N / CLI account N).',
      addConfirm: 'Add', addKeyRequired: 'Paste an API key first.',
      accountRefLabel: 'Credential ref', accountHomeLabel: 'CLI home',
      cliAddHint: 'Sign-in starts right after adding; the wizard appears in this card.',
      loggedInAs: 'Signed in as', notLoggedIn: 'Not signed in', reLogin: 'Sign in again',
      removeConfirm: 'Remove?', removeConfirmYes: 'Remove', removeHomeNote: 'Removes the entry only; the CLI home directory on the server is kept.',
      cliSection: 'arkcli', cliReady: 'arkcli ready', cliMissing: 'arkcli is not installed; CLI sign-in and real plan quota need it.',
      cliInstall: 'Install arkcli', cliInstalling: 'Installing… (~40 MB download)', cliInstallFailed: 'Install failed',
      cliVersion: 'Version', cliPath: 'Path',
      loginTitle: 'CLI sign-in', loginStarting: 'Asking arkcli for an authorize link…',
      loginUrlLabel: 'Authorize URL', loginOpen: 'Open authorize page',
      loginStepAuthorize: '1 Authorize', loginStepPaste: '2 Paste callback', loginStepDone: '3 Done',
      loginWaiting: 'Waiting for authorization…', loginDone: 'Signed in', loginFailed: 'Sign-in failed',
      loginSessionExpired: 'The sign-in session expired — start the authorization again.',
      loginIdentityName: 'User', loginIdentityAccount: 'Account',
      loginFerryNote: 'After signing in, the browser is redirected to http://127.0.0.1:<port>/… and shows “can’t reach this page” — that is expected: the port lives on the server running DSH, not on your machine. Copy that whole 127.0.0.1 address out of the address bar and paste it below.',
      loginOrWait: 'You can also do nothing: if you happen to reach that port, sign-in completes in the background — the wizard polls for you.',
      loginPasteLabel: 'Paste the callback URL', loginPastePlaceholder: 'Paste the full 127.0.0.1:… address from the address bar',
      loginSubmit: 'Submit callback URL', loginRestart: 'Start over', loginNote: 'Note',
      modelsSection: 'Models', modelsHint: 'Unchecked models disappear from the model picker; everything checked means everything visible.',
      selectAll: 'Select all', selectNone: 'Select none', modelsDirty: 'Model selection changed — press Save to write it once.',
      context: 'Context', output: 'Max output', textOnly: 'text only', vision: 'vision',
      catalogOfficial: 'Official catalog', catalogRefresh: 'Refresh catalog', catalogRefreshing: 'Refreshing…',
      catalogUpdated: 'Catalog updated', catalogUnavailable: 'Could not read the official catalog', catalogMeasured: 'measured',
      catalogConflict: 'Sources disagree', catalogConflictNote: 'The measured value is used — the official catalog comes from general ARK and may differ from the plan endpoint; nothing is overwritten.',
      catalogUnmatchedPrefix: 'The official catalog has', catalogUnmatchedSuffix: 'more models not in this plan', catalogUnmatchedSample: 'e.g.',
      inputModality: 'modality',
      usageSection: 'Usage & display',
      usageHint: 'Plan quota needs a signed-in CLI account or an AK/SK pair. With neither, this card only says what is missing — it no longer substitutes local token counts.',
      usageSourcePlan: 'Plan quota', usageUnavailable: 'unavailable',
      usageWindow5h: '5-hour', usageWindowWeekly: 'Weekly', usageWindowMonthly: 'Monthly',
      usageAccountQuota: 'Account quota', usageTotals: 'used / total',
      refreshNow: 'Refresh', refreshedAt: 'Updated', resetAt: 'resets',
      akId: 'AccessKey ID', akIdHint: 'Not the ark- subscription key; the volcano account’s AKLT…', skRef: 'Secret credential ref',
      skHint: 'The secret goes to the credential store, never to a settings file.', region: 'Region',
      sidebarQuotaLabel: 'Usage card in the sidebar',
      sidebarQuotaHint: 'The card stays hidden while no real plan quota can be read, and nothing is substituted for it.',
      sidebarQuotaAuto: 'Automatic', sidebarQuotaOn: 'Always show', sidebarQuotaOff: 'Always hide',
      sidebarQuotaAutoHint: 'Automatic = shown once something can read quota (a signed-in CLI account, or an AK/SK pair).',
      sidebarQuotaEffective: 'Now',
      refreshSeconds: 'Refresh interval (s)',
      advancedSection: 'Advanced', advancedHint: 'Endpoint and network parameters; rarely changed.',
      apiBase: 'API endpoint', requestTimeout: 'Request timeout (ms)', streamIdleTimeout: 'Stream idle timeout (ms)',
      defaultMaxTokens: 'Default output cap', contextOverrides: 'Per-model context overrides',
      contextOverridesHint: 'Blank uses the catalog capacity. Override here when upstream changes it.',
      keySection: 'API key',
      keyHint: 'The key is written to the local credential store only; it never enters a settings document or returns to the browser.',
      clear: 'Clear', cleared: 'Cleared',
      credentialsUnavailable: 'The credential service is not mounted: export the variable in the launch environment, or reload the page.',
      credentialWriteFailed: 'Could not write the credential', credentialClearFailed: 'Could not clear the credential',
      readOnly: 'Settings are read-only right now.', unavailable: 'The settings service is not mounted, so this page can only show read-only facts.',
      loadFailed: 'Could not read settings', saveFailed: 'Save failed', usageFailed: 'Could not read usage',
      // Stable codes for a missing remote method; the controller stores the code and the
      // render sites translate it, so the English UI never shows Chinese source text.
      hostMissingReport: 'The host does not provide arkcoding/report',
      hostMissingCliInstall: 'The host does not provide arkcoding/cliInstall',
      hostMissingLoginBegin: 'The host does not provide arkcoding/loginBegin',
      hostMissingLoginPoll: 'The host does not provide arkcoding/loginPoll',
      hostMissingLoginSubmit: 'The host does not provide arkcoding/loginSubmit',
      providerCardHint: 'Accounts, models and quota are managed under Settings → Volcengine Ark; this card only shows which account is in use.',
      sidebarTitle: 'Volcengine Ark',
      sidebarLoading: 'Loading…', sidebarOpenHint: 'Click for details',
      sidebarUnavailable: 'Quota is unavailable right now',
      sidebarDetailTitle: 'Volcengine Ark Coding Plan',
      sidebarDetailLogin: 'Sign-in status', sidebarDetailQuota: 'Quota',
      sidebarDetailClose: 'Hide details', sidebarRefresh: 'Refresh', sidebarDetailSource: 'Source',
      sidebarDetailNoBindingHint: 'Add a “CLI sign-in” account under Settings → Volcengine Ark (it also gives you real quota), or fill in an AK/SK pair.',
      sourceArkcli: 'arkcli (SSO)', sourceAksk: 'AK/SK',
    }

    // -----------------------------------------------------------------------
    // 样式（只用主题 token）
    // -----------------------------------------------------------------------

    const CSS = `
.akc-root { display:flex; flex-direction:column; gap:18px; padding:2px 0 96px; color:var(--dsw-alias-label-primary); font-size:13px; line-height:1.6; }
.akc-head h2 { margin:0 0 4px; font-size:16px; font-weight:600; }
.akc-head p { margin:0; color:var(--dsw-alias-label-secondary); font-size:12px; }
.akc-card { border:1px solid var(--dsw-alias-border-l1); border-radius:10px; background:var(--dsw-alias-bg-layer-1); overflow:hidden; }
.akc-cardHead { display:flex; align-items:center; justify-content:space-between; gap:12px; padding:12px 16px; border-bottom:1px solid var(--dsw-alias-border-l1); }
.akc-cardHead h3 { margin:0; font-size:13px; font-weight:600; }
.akc-cardBody { padding:14px 16px; display:flex; flex-direction:column; gap:12px; }
.akc-row { display:flex; align-items:center; justify-content:space-between; gap:16px; }
.akc-rowLabel { display:flex; flex-direction:column; gap:2px; min-width:0; }
.akc-rowLabel span { font-size:12px; color:var(--dsw-alias-label-secondary); }
.akc-badge { display:inline-flex; align-items:center; gap:6px; font-size:12px; color:var(--dsw-alias-label-secondary); }
.akc-dot { width:7px; height:7px; border-radius:50%; background:var(--dsw-alias-state-idle-primary); flex:none; }
.akc-dot.on { background:var(--dsw-alias-state-success-primary); }
.akc-dot.off { background:var(--dsw-alias-state-warn-primary); }
.akc-dot.err { background:var(--dsw-alias-state-error-primary); }
.akc-input { flex:1; min-width:120px; box-sizing:border-box; padding:7px 10px; font:inherit; font-size:12.5px; color:var(--dsw-alias-label-primary); background:var(--dsw-alias-bg-base); border:1px solid var(--dsw-alias-border-l2); border-radius:7px; outline:none; }
.akc-input:focus { border-color:var(--dsw-alias-brand-primary); }
.akc-input::placeholder { color:var(--dsw-alias-label-secondary); }
.akc-input:disabled { opacity:.6; cursor:not-allowed; }
.akc-input.num { flex:none; width:150px; }
.akc-btn { flex:none; padding:7px 13px; font:inherit; font-size:12.5px; color:var(--dsw-alias-label-primary); background:var(--dsw-alias-bg-layer-2); border:1px solid var(--dsw-alias-border-l2); border-radius:7px; cursor:pointer; white-space:nowrap; }
.akc-btn:hover:not(:disabled) { border-color:var(--dsw-alias-brand-primary); }
.akc-btn:disabled { cursor:not-allowed; color:var(--dsw-alias-label-secondary); background:var(--dsw-alias-bg-base); border-color:var(--dsw-alias-border-l1); opacity:1; }
.akc-btn.primary { color:var(--dsw-alias-label-primary-foreground); background:var(--dsw-alias-brand-primary); border-color:var(--dsw-alias-brand-primary); }
.akc-btn.primary:hover:not(:disabled) { filter:brightness(1.08); }
.akc-btn.primary:disabled { color:var(--dsw-alias-label-secondary); background:var(--dsw-alias-bg-layer-2); border-color:var(--dsw-alias-border-l1); filter:none; }
.akc-btn.danger { color:var(--dsw-alias-label-primary); border-color:var(--dsw-alias-state-error-primary); background:color-mix(in srgb, var(--dsw-alias-state-error-primary) 14%, transparent); }
a.akc-btn { text-decoration:none; display:inline-flex; align-items:center; justify-content:center; box-sizing:border-box; }
.akc-hint { margin:0; font-size:12px; color:var(--dsw-alias-label-secondary); }
.akc-note { padding:8px 11px; border-radius:7px; font-size:12px; border:1px solid var(--dsw-alias-border-l1); background:var(--dsw-alias-bg-layer-2); }
.akc-note.ok { color:var(--dsw-alias-label-primary); background:var(--dsw-alias-state-success-tertiary); border-color:var(--dsw-alias-state-success-primary); }
/* 红字压卡片底实测只有 4.24（深色）/ 4.50 压线，AA 要 4.5。红色退到描边和浅底，
   正文改用常态前景色 —— 与 .akc-note.ok / .akc-note.warn 同一手法。 */
.akc-note.err { color:var(--dsw-alias-label-primary); background:color-mix(in srgb, var(--dsw-alias-state-error-primary) 14%, var(--dsw-alias-bg-layer-2)); border-color:var(--dsw-alias-state-error-primary); }
.akc-note.warn { color:var(--dsw-alias-label-primary); background:var(--dsw-alias-state-warn-tertiary); border-color:var(--dsw-alias-state-warn-primary); }
.akc-list { display:flex; flex-direction:column; }
.akc-model { display:flex; align-items:flex-start; gap:10px; padding:9px 0; border-bottom:1px solid var(--dsw-alias-border-l1); cursor:pointer; }
.akc-model:last-child { border-bottom:none; }
.akc-model input { margin-top:3px; flex:none; accent-color:var(--dsw-alias-brand-primary); }
.akc-modelMain { display:flex; flex-direction:column; gap:1px; min-width:0; flex:1; }
.akc-modelName { font-size:12.5px; font-weight:500; }
.akc-modelFacts { font-size:11.5px; color:var(--dsw-alias-label-secondary); font-variant-numeric:tabular-nums; }
.akc-tag { display:inline-block; margin-left:6px; padding:0 5px; border-radius:4px; border:1px solid var(--dsw-alias-border-l2); font-size:10.5px; font-weight:400; color:var(--dsw-alias-label-secondary); }
.akc-tools { display:flex; gap:8px; align-items:center; flex-wrap:wrap; }
.akc-account { border:1px solid var(--dsw-alias-border-l1); border-radius:9px; padding:11px 12px; display:flex; flex-direction:column; gap:9px; background:var(--dsw-alias-bg-base); }
.akc-account.active { border-color:var(--dsw-alias-brand-primary); }
.akc-accountHead { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.akc-accountName { font-size:12.5px; font-weight:600; min-width:0; overflow-wrap:anywhere; }
.akc-accountMeta { font-size:11px; color:var(--dsw-alias-label-secondary); word-break:break-all; }
.akc-pill { padding:0 6px; border-radius:20px; font-size:10.5px; border:1px solid var(--dsw-alias-border-l2); color:var(--dsw-alias-label-secondary); white-space:nowrap; }
.akc-pill.brand { color:var(--dsw-alias-label-primary-foreground); background:var(--dsw-alias-brand-primary); border-color:var(--dsw-alias-brand-primary); }
.akc-pill.err { color:var(--dsw-alias-state-error-primary); border-color:var(--dsw-alias-state-error-primary); }
.akc-pill.ok { color:var(--dsw-alias-label-primary); background:var(--dsw-alias-state-success-tertiary); border-color:var(--dsw-alias-state-success-primary); }
.akc-bar { height:5px; border-radius:3px; background:var(--dsw-alias-state-idle-primary); overflow:hidden; }
.akc-barFill { height:100%; border-radius:3px; background:var(--dsw-alias-brand-primary); transition:width .3s ease; }
.akc-barFill.warn { background:var(--dsw-alias-state-warn-primary); }
.akc-barFill.err { background:var(--dsw-alias-state-error-primary); }
.akc-window { display:flex; flex-direction:column; gap:4px; }
.akc-windowHead { display:flex; align-items:baseline; justify-content:space-between; gap:10px; font-size:12px; }
.akc-windowValue { font-variant-numeric:tabular-nums; color:var(--dsw-alias-label-secondary); }
.akc-windowLabel { font-weight:500; }
.akc-saveBar { position:sticky; bottom:0; display:flex; align-items:center; justify-content:space-between; gap:12px; padding:10px 14px; border:1px solid var(--dsw-alias-border-l2); border-radius:9px; background:var(--dsw-alias-bg-overlay,var(--dsw-alias-bg-layer-2)); box-shadow:0 4px 16px rgba(0,0,0,.12); }
/* 保存条压在 bg-overlay 上：warn 当正文色浅色只有 1.81、深色 2.70。
   改常态前景色（实测 15.97 / 5.55），"未保存"的警示交给底下的按钮。 */
.akc-saveText { font-size:12px; color:var(--dsw-alias-label-primary); }
/* 轨道：OFF 用 idle 灰，ON 用品牌色。
   以前 OFF 写的是 bg-layer-2 —— 浅色主题下它等于卡片底色（都是白），于是
   白药丸压在白卡片上，只剩一圈很淡的边框，看起来根本不像一个开关。
   idle 在浅色是 #d4d4d4、深色是 #545557，两种主题下都跟卡片分得开。
   滑块用 bg-base（而不是写死的 #fff）：浅色主题 = 白滑块（压深色轨道），
   深色主题 = 近黑滑块（压浅色轨道）。深色主题里 brand-primary 接近白色，
   再用白滑块就会白压白、看不出滑块在哪 —— 换成 bg-base 后四种组合都清楚。 */
.akc-override { display:flex; align-items:center; gap:10px; }
.akc-overrideName { flex:1; min-width:0; font-size:12px; color:var(--dsw-alias-label-secondary); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.akc-mono { font-family:ui-monospace,SFMono-Regular,Menlo,monospace; font-size:11.5px; }
/* 卡片行距比设置页的卡片紧：这里每行只有"标签 + 百分比 + 一条 5px 细条"，
   行与行之间留 9px 会在侧边栏里显得稀稀拉拉（整卡高度里近三成是空隙）。
   6px + 窗口内 4px 是一眼能看出来、又不至于把两档粘在一起的距离。 */
.akc-side { display:flex; flex-direction:column; gap:6px; width:100%; box-sizing:border-box; padding:10px 12px; border:1px solid var(--dsw-alias-border-l1); border-radius:9px; background:var(--dsw-alias-bg-layer-1); cursor:pointer; text-align:left; font:inherit; color:var(--dsw-alias-label-primary); }
.akc-side:hover { border-color:var(--dsw-alias-border-l2); }
.akc-sideHead { display:flex; align-items:center; justify-content:space-between; gap:8px; font-size:12px; font-weight:600; }
.akc-sideMeta { font-size:10.5px; color:var(--dsw-alias-label-secondary); min-width:0; overflow-wrap:anywhere; }
/* 过期提示（只在详情面板里用）。**不能**用 state-error-primary 当正文色：
   面板表面 bg-overlay 深色是中灰 #61666b，红字压上去只有 1.76、浅色 3.80，
   比它要替代的 label-secondary（3.85）还差。所以沿用 .akc-note.err 的手法：
   正文常态色 + 红色浅底，靠底色把这一行标出来。 */
.akc-sideMeta.err { color:var(--dsw-alias-label-primary); background:color-mix(in srgb, var(--dsw-alias-state-error-primary) 18%, var(--dsw-alias-bg-overlay)); border-radius:4px; }
/* 56px 轨道里的紧凑态：只留两行百分比，标题和账户名都省掉。 */
.akc-side.narrow { padding:8px 6px; gap:5px; align-items:center; }
.akc-side.narrow .akc-window { gap:2px; }
.akc-side.narrow .akc-windowHead { justify-content:center; }
.akc-side.narrow .akc-windowValue { font-size:11px; }
/* 详情面板：fixed 贴卡片上方。侧边栏是 overflow:hidden，绝对定位会被裁掉。 */
.akc-detail { position:fixed; z-index:70; display:flex; flex-direction:column; gap:8px; box-sizing:border-box; padding:12px 14px; border:1px solid var(--dsw-alias-border-l2); border-radius:10px; background:var(--dsw-alias-bg-overlay); color:var(--dsw-alias-label-primary); box-shadow:0 14px 36px rgb(0 0 0 / 22%); font-size:12px; line-height:1.5; max-height:70vh; overflow-y:auto; }
.akc-detailHead { display:flex; align-items:center; justify-content:space-between; gap:8px; font-size:12.5px; font-weight:600; }
.akc-detailClose { border:0; background:transparent; color:var(--dsw-alias-label-secondary); cursor:pointer; font:inherit; padding:0 2px; line-height:1; }
.akc-detailClose:hover { color:var(--dsw-alias-label-primary); }
.akc-detailSection { margin-top:2px; font-size:10.5px; font-weight:600; letter-spacing:.04em; text-transform:uppercase; color:var(--dsw-alias-label-primary); }
/* 面板里的次级文字也必须是 label-primary：popover 表面（bg-overlay）在深色主题里是
 * 中灰 #61666b，label-secondary 压在上面只有 3.85（AA 要 4.5）。层级靠字号和字重。
 * :not(.err) 是必须的：.akc-sideMeta.err 与本规则特异性相同、本规则又靠后，
 * 不排除的话凭据过期那行红色永远画不出来（实测两态同色）。 */
.akc-detail .akc-sideMeta:not(.err), .akc-detail .akc-windowValue, .akc-detail .akc-hint, .akc-detail .akc-detailClose { color:var(--dsw-alias-label-primary); }
.akc-detailAccount { display:flex; flex-direction:column; gap:1px; padding:7px 9px; border:1px solid var(--dsw-alias-border-l1); border-radius:8px; background:var(--dsw-alias-bg-layer-1); }
.akc-detailAccountTop { display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
.akc-detailFoot { display:flex; align-items:center; justify-content:space-between; gap:8px; margin-top:2px; }
.akc-select { appearance:none; padding:5px 26px 5px 10px; border:1px solid var(--dsw-alias-border-l2); border-radius:7px; background:var(--dsw-alias-bg-layer-1); color:var(--dsw-alias-label-primary); font:inherit; font-size:12px; cursor:pointer; background-image:linear-gradient(45deg,transparent 50%,currentColor 50%),linear-gradient(135deg,currentColor 50%,transparent 50%); background-position:calc(100% - 14px) 52%, calc(100% - 9px) 52%; background-size:5px 5px, 5px 5px; background-repeat:no-repeat; }
.akc-select:disabled { opacity:.55; cursor:not-allowed; }
.akc-addFlow { border:1px dashed var(--dsw-alias-border-l2); border-radius:9px; padding:12px; display:flex; flex-direction:column; gap:10px; background:var(--dsw-alias-bg-layer-2); }
.akc-typePicker { padding:6px 12px; border-radius:20px; }
.akc-wizard { border:1px solid var(--dsw-alias-brand-primary); border-radius:9px; padding:12px; display:flex; flex-direction:column; gap:10px; background:var(--dsw-alias-bg-base); }
.akc-steps { display:flex; gap:8px; flex-wrap:wrap; margin:0; padding:0; list-style:none; }
.akc-step { padding:2px 8px; border-radius:20px; font-size:10.5px; border:1px solid var(--dsw-alias-border-l2); color:var(--dsw-alias-label-secondary); }
.akc-step[aria-current="step"] { color:var(--dsw-alias-label-primary-foreground); background:var(--dsw-alias-brand-primary); border-color:var(--dsw-alias-brand-primary); }
.akc-url { word-break:break-all; padding:7px 10px; border-radius:7px; border:1px solid var(--dsw-alias-border-l1); background:var(--dsw-alias-bg-layer-2); }
.akc-conflict { border-color:var(--dsw-alias-state-warn-primary); color:var(--dsw-alias-state-warn-primary); }
.akc-official { color:var(--dsw-alias-label-secondary); }
.akc-usageAccount { border:1px solid var(--dsw-alias-border-l1); border-radius:9px; padding:10px 12px; display:flex; flex-direction:column; gap:9px; background:var(--dsw-alias-bg-base); }
.akc-quiet { font-size:11.5px; color:var(--dsw-alias-label-secondary); }
/* 「一个账户都没有」的空状态：虚线框 + 显式说明，而不是让卡片空白。 */
.akc-empty { display:flex; flex-direction:column; gap:6px; padding:12px; border:1px dashed var(--dsw-alias-border-l2); border-radius:9px; background:var(--dsw-alias-bg-layer-2); }
.akc-emptyTitle { font-size:12.5px; font-weight:600; }
/* Models 页提供商卡片里「正在用哪个账户」那一行。 */
.akc-providerActive { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.akc-accountNameInput { flex:0 0 170px; }
.akc-modelRow { flex:1; min-width:0; display:flex; flex-direction:column; gap:1px; }
.akc-urlLabel { margin-bottom:-6px; }
`

    function injectCss() {
      if (typeof document === 'undefined') return () => {}
      if (document.querySelector(`style[data-plugin-css="${CSS_ID}"]`) !== null) return () => {}
      const tag = document.createElement('style')
      tag.dataset.plugin = 'dsh-ark-coding-provider'
      tag.dataset.pluginCss = CSS_ID
      tag.textContent = CSS
      document.head.appendChild(tag)
      return () => tag.remove()
    }

    // -----------------------------------------------------------------------
    // 工具
    // -----------------------------------------------------------------------

    function createStore(initial) {
      let state = initial
      const listeners = new Set()
      return {
        get: () => state,
        set: (patch) => {
          const next = typeof patch === 'function' ? patch(state) : patch
          state = { ...state, ...next }
          for (const listener of [...listeners]) listener()
        },
        subscribe: (listener) => {
          listeners.add(listener)
          return () => { listeners.delete(listener) }
        },
      }
    }

    function humanTokens(value) {
      if (typeof value !== 'number' || !Number.isFinite(value)) return '—'
      if (value >= 1048576) return `${Math.round(value / 1048576 * 10) / 10}M`
      if (value >= 1024) return `${Math.round(value / 1024)}K`
      return String(value)
    }

    /**
     * 任意 rejection → 可读文本。
     *
     * Typert 会把 rejection 序列化过线，结构化克隆丢掉原型链，**宿主抛的真 Error
     * 到这边也只是普通对象** —— 旧实现只认 `instanceof Error`，于是跨边界失败一律
     * 显示成 `[object Object]`。所以复用 `remoteMessageOf`（认 string / Error /
     * `.message`），再退到 JSON，最后才退到 String。
     */
    function errorText(error) {
      const message = remoteMessageOf(error)
      if (message !== undefined) return message
      try {
        const text = JSON.stringify(error)
        if (typeof text === 'string' && text !== '' && text !== 'undefined') return text
      } catch { /* 循环引用等无法序列化：落到 String */ }
      return String(error)
    }

    function formatClock(ms, locale) {
      if (typeof ms !== 'number' || !Number.isFinite(ms)) return '—'
      try {
        return new Date(ms).toLocaleString(locale === 'zh' ? 'zh-CN' : 'en-US', {
          hour12: false, month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit',
        })
      } catch { return new Date(ms).toISOString().slice(5, 16).replace('T', ' ') }
    }

    /**
     * 只到「天」的本地日期（`2026-12-15`）。
     *
     * 凭据到期是**服务端事实**（实测一个 2026-10-16 登录的账户给出 2026-12-15），
     * 会随租户/策略变化，所以只显示算出来的日期，绝不写死「每 N 天要重登」。
     * 格式固定成 `YYYY-MM-DD`：短、无歧义，也不随浏览器语言改形状。
     */
    /**
     * 百分比文案。
     *
     * 控制面返回的是**小数**百分比：这个账号日常就落在 0.1% ~ 1% 之间，
     * 一律四舍五入到整数会长期显示成 `0%` —— 明明在用却看着像没用过。
     * 所以 10% 以下保留一位小数（整数原样显示），10% 以上才取整。
     */
    function formatPercent(value) {
      const percent = typeof value === 'number' && Number.isFinite(value)
        ? Math.max(0, Math.min(100, value)) : 0
      if (percent >= 10) return `${Math.round(percent)}%`
      const rounded = Math.round(percent)
      return percent === rounded ? `${rounded}%` : `${percent.toFixed(1)}%`
    }

    function formatDate(ms) {
      if (typeof ms !== 'number' || !Number.isFinite(ms)) return '—'
      try {
        const date = new Date(ms)
        const pad = (value) => String(value).padStart(2, '0')
        return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
      } catch { return new Date(ms).toISOString().slice(0, 10) }
    }

    function sameJson(left, right) {
      return JSON.stringify(left ?? null) === JSON.stringify(right ?? null)
    }

    /** 新账户 id：`acct-` + 8 位 hex，稳定且不会和 `default` 撞。 */
    function randomAccountId() {
      const bytes = new Uint8Array(4)
      try {
        if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') crypto.getRandomValues(bytes)
        else for (let i = 0; i < bytes.length; i += 1) bytes[i] = Math.floor(Math.random() * 256)
      } catch {
        for (let i = 0; i < bytes.length; i += 1) bytes[i] = Math.floor(Math.random() * 256)
      }
      return `acct-${[...bytes].map((byte) => byte.toString(16).padStart(2, '0')).join('')}`
    }

    /** 界面管理的账户字段；其余字段（例如只写组合配置的字面量 `apiKey`）不许碰。 */
    const ACCOUNT_FIELDS = ['id', 'label', 'type', 'apiKeyEnv', 'home']

    /**
     * `accounts` 的差异写回 —— **绝不整数组回写**。
     *
     * `accounts[].apiKey` 带 `role('secret')`：describe 时被 harness 结构性抹掉，
     * 整数组回写就等于把用户在配置里写的字面量密钥静默删掉、再也找不回来。
     * `dsh-settings` 的 `mutate` 支持按路径最小写入（`applyPathOp` 认数组下标，
     * 也认 `unset` 删除元素），所以这里只写真正变了的字段。
     *
     * 顺序有讲究：先按**倒序**删掉消失的行（下标不会漂移），再逐字段补差异，
     * 最后追加新行（追加用下标 = 当前长度，这是 `applyPathOp` 允许的写法）。
     * `accounts` 键本身不存在时只能整体写一次：那时 schema 里没有数组可落，逐下标
     * 写会落成一个 `{0: …}` 对象。
     *
     * **路径段必须是字符串**：`settings/mutate` 的 Typert 线网 schema 是
     * `path: string[]`，`applyPathOp` 也只把 `/^(0|[1-9][0-9]*)$/` 的**字符串**
     * 当数组下标。以前这里传的是数字下标，0.2.1-rc.2 的严格边界校验直接回
     * `gateway/input-invalid`（`field: "ops"`），界面上只剩一句「保存失败」——
     * 添加/删除账户、改名、设为首选全都会失败。
     */
    function accountOps(before, after) {
      const previous = Array.isArray(before) ? before : undefined
      const next = Array.isArray(after) ? after : []
      if (previous === undefined) return next.length === 0 ? [] : [{ op: 'set', path: ['accounts'], value: next }]
      const kept = new Set(next.map((account) => account?.id))
      const ops = []
      const removed = []
      previous.forEach((account, index) => { if (!kept.has(account?.id)) removed.push(index) })
      // 下标一律用字符串拼路径：线网 schema 只收 `string[]`（见上面的说明）。
      for (const index of [...removed].reverse()) ops.push({ op: 'unset', path: ['accounts', String(index)] })
      const survivors = previous.filter((account) => kept.has(account?.id))
      survivors.forEach((account, index) => {
        const target = next[index]
        if (target === undefined) return
        for (const field of ACCOUNT_FIELDS) {
          if (target[field] !== undefined && !sameJson(account?.[field], target[field])) {
            ops.push({ op: 'set', path: ['accounts', String(index), field], value: target[field] })
          }
        }
      })
      for (let index = survivors.length; index < next.length; index += 1) {
        ops.push({ op: 'set', path: ['accounts', String(index)], value: next[index] })
      }
      return ops
    }

    /**
     * 远端返回值的统一拆封。
     *
     * Gateway 把 direct invocation 的结果包成 RemoteResult 信封（`{ok, value}`），
     * 契约 §1 里每个方法"返回的对象"就在 `value` 里。裸对象（没装信封）也容忍：
     * 判据是信封必须同时有布尔 `ok` 和 `value` 两个自有字段。
     */
    function remoteMessageOf(value) {
      if (value === undefined || value === null) return undefined
      if (typeof value === 'string') return value
      if (value instanceof Error) return value.message
      if (typeof value.message === 'string' && value.message !== '') return value.message
      return undefined
    }

    function readRemote(response) {
      if (response === null || response === undefined || typeof response !== 'object') {
        return { payload: undefined, error: '远端没有返回结果 / remote returned nothing' }
      }
      const hasValue = Object.prototype.hasOwnProperty.call(response, 'value')
      if (typeof response.ok === 'boolean' && hasValue) {
        if (response.ok !== true) {
          return { payload: undefined, error: remoteMessageOf(response.error) ?? '远端调用失败 / remote call failed' }
        }
        const value = response.value
        if (value === null || value === undefined || typeof value !== 'object') {
          return { payload: undefined, error: '远端返回了空结果 / remote returned an empty result' }
        }
        return { payload: value, error: undefined }
      }
      const error = response.ok === false ? (remoteMessageOf(response.error) ?? '远端调用失败 / remote call failed') : undefined
      return { payload: response, error }
    }

    /** 复制到剪贴板：宿主在浏览器里，没有剪贴板 API 时静默降级（按钮仍然可达）。 */
    function copyText(value) {
      const text = typeof value === 'string' ? value : ''
      if (text === '') return Promise.resolve(false)
      try {
        if (typeof navigator !== 'undefined' && navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
          return Promise.resolve(navigator.clipboard.writeText(text)).then(() => true, () => false)
        }
      } catch { /* 剪贴板被策略禁掉时不该打断向导 */ }
      return Promise.resolve(false)
    }

    // -----------------------------------------------------------------------
    // 控制器
    // -----------------------------------------------------------------------

    /** 一个待添加账户的初始草稿。 */
    function blankAddFlow() {
      return { open: false, type: 'apikey', name: '', key: '', id: '', busy: false, error: undefined }
    }

    /** 登录向导的初始状态。`phase` 是唯一的真相源。 */
    function blankLogin() {
      return {
        accountId: undefined, phase: 'idle', url: undefined, port: undefined,
        hint: undefined, error: undefined, identity: undefined, note: undefined, startedAt: undefined,
      }
    }

    /**
     * 设置页 / 用量卡片的全部状态与写路径。
     *
     * 配置改动先进 `draft`（本地），点保存才一次性写回宿主 —— 这就是
     * 「勾选模型不再卡」的原因：勾选只改本地状态，不触发宿主往返。
     * 但账户的增删改名是**即时提交**的：用户点「添加」就该看到它生效。
     */
    function createController() {
      const store = createStore({
        status: 'loading',
        writable: false,
        value: {},
        draft: {},
        revision: undefined,
        error: undefined,
        key: { state: 'unknown', source: undefined },
        secret: false,
        accounts: [],
        usage: undefined,
        usageLoading: false,
        usageError: undefined,
        busy: false,
        notice: undefined,
        // 最近一次保存失败时宿主给的原始信息：只显示 code 的话，用户（和排障的人）
        // 永远不知道是冲突、只读、还是线网校验拒绝。
        lastSaveError: undefined,
        dirty: false,
        add: blankAddFlow(),
        login: blankLogin(),
        cliInstalling: false,
        cliInstallError: undefined,
        catalogLoading: false,
      })
      let settingsRemote
      let credentialsRemote
      let usageRemote
      let loginTimer

      const blank = (value) => (typeof value === 'object' && value !== null && !Array.isArray(value) ? value : {})

      /** 宿主报告里的账户 → 设置文档里的账户形状（迁移/兜底共用）。 */
      function shapeFromState(account) {
        const type = account?.type === 'cli' ? 'cli' : 'apikey'
        return {
          id: typeof account?.id === 'string' && account.id !== '' ? account.id : randomAccountId(),
          label: account?.labelIsCustom === true && typeof account.label === 'string' ? account.label : '',
          type,
          apiKeyEnv: type === 'cli' ? '' : (typeof account?.ref === 'string' ? account.ref : ''),
          home: type === 'cli' && typeof account?.home === 'string' ? account.home : '',
        }
      }

      /**
       * 当前生效的账户列表。
       *
       * 设置文档的 `accounts` 是唯一真相源；但它为空（老文档）时先用宿主报告
       * 里的账户把界面撑起来 —— 契约 §3 的迁移路径，第一次保存就会写回完整数组。
       */
      function accountRows() {
        const state = store.get()
        const draft = Array.isArray(state.draft?.accounts) ? state.draft.accounts : []
        if (draft.length > 0) return draft
        const report = state.usage
        if (!Array.isArray(report?.accounts) || report.accounts.length === 0) return []
        return report.accounts.map(shapeFromState)
      }

      /** 报告到手后把账户列表灌进 draft，让「添加」从一个完整列表开始。 */
      function seedAccountsFromReport() {
        const state = store.get()
        const draft = Array.isArray(state.draft?.accounts) ? state.draft.accounts : []
        if (draft.length > 0) return
        const report = state.usage
        if (!Array.isArray(report?.accounts) || report.accounts.length === 0) return
        const seeded = report.accounts.map(shapeFromState)
        store.set((current) => ({ draft: { ...current.draft, accounts: seeded } }))
      }

      async function loadSettings() {
        if (settingsRemote === undefined) {
          store.set({ status: 'unavailable', error: undefined })
          return
        }
        try {
          const response = await settingsRemote.describe()
          if (!response || response.ok !== true) {
            store.set({ status: 'error', error: response?.error?.message ?? 'describe failed' })
            return
          }
          const view = response.value ?? {}
          const row = Array.isArray(view.namespaces) ? view.namespaces.find((entry) => entry?.ns === NS) : undefined
          if (row === undefined) {
            store.set({ status: 'unavailable', writable: view.writable === true, error: undefined })
            return
          }
          const value = blank(row.value)
          store.set({
            status: 'ready',
            writable: view.writable === true,
            value,
            draft: { ...value },
            revision: typeof row.revision === 'number' ? row.revision : undefined,
            dirty: false,
            error: undefined,
          })
          // 这里**不**播种账户：此刻 `usage` 可能还是上一份报告，拿它播种会把已经
          // 删掉的账户又灌回 draft。播种只在 refreshUsage 拿到新报告后做。
        } catch (error) {
          store.set({ status: 'error', error: errorText(error) })
        }
      }

      async function loadKey() {
        if (credentialsRemote === undefined) {
          store.set({ key: { state: 'unknown', source: undefined } })
          return
        }
        try {
          const refs = new Set([DEFAULT_KEY_REF, DEFAULT_SECRET_REF])
          const accounts = accountRows()
          for (const account of accounts) {
            if (account && typeof account.apiKeyEnv === 'string' && account.apiKeyEnv !== '') refs.add(account.apiKeyEnv)
          }
          const response = await credentialsRemote.describe([...refs])
          if (!response || response.ok !== true) {
            store.set({ key: { state: 'unknown', source: response?.error?.message ?? undefined } })
            return
          }
          const map = response.value ?? {}
          const primary = map[DEFAULT_KEY_REF]
          const configured = accounts.map((account, index) => {
            const ref = typeof account?.apiKeyEnv === 'string' ? account.apiKeyEnv : ''
            const info = ref === '' ? undefined : map[ref]
            return {
              id: typeof account?.id === 'string' && account.id !== '' ? account.id : `account-${index + 1}`,
              ref,
              configured: info?.configured === true,
              source: typeof info?.source === 'string' ? info.source : undefined,
            }
          })
          store.set({
            key: {
              state: primary?.configured === true ? 'configured' : 'missing',
              source: typeof primary?.source === 'string' ? primary.source : undefined,
              writable: primary?.writable !== false,
            },
            secret: map[DEFAULT_SECRET_REF]?.configured === true,
            accounts: configured,
          })
        } catch (error) {
          store.set({ key: { state: 'unknown', source: errorText(error) } })
        }
      }

      /** 本地编辑：只改 draft，不碰宿主。 */
      function editField(field, value) {
        store.set((state) => {
          const draft = { ...state.draft, [field]: value }
          return { draft, dirty: !sameJson(draft, state.value) }
        })
      }

      function discard() {
        store.set((state) => ({ draft: { ...state.value }, dirty: false, notice: undefined }))
        seedAccountsFromReport()
      }

      /** 数值字段在 draft 里是字符串，写回前归一化。 */
      const NUMERIC_FIELDS = new Set(['requestTimeoutMs', 'streamIdleTimeoutMs', 'defaultMaxTokens', 'usageRefreshSeconds'])

      /** 把 draft 与已提交值的差异一次性写回宿主（一次 mutate = 一次往返）。 */
      async function save() {
        if (settingsRemote === undefined) return false
        const state = store.get()
        const ops = []
        const keys = new Set([...Object.keys(state.draft), ...Object.keys(state.value)])
        for (const key of keys) {
          const before = state.value[key]
          const raw = state.draft[key]
          if (key === 'accounts') {
            // 账户数组只写差异，理由见 accountOps（整数组回写会吞掉字面量密钥）。
            ops.push(...accountOps(before, raw))
            continue
          }
          if (NUMERIC_FIELDS.has(key)) {
            if (raw === undefined || raw === null || String(raw).trim() === '') continue
            const next = Number(raw)
            if (!Number.isFinite(next) || next <= 0) continue
            if (next !== before) ops.push({ op: 'set', path: [key], value: Math.trunc(next) })
            continue
          }
          if (key === 'apiBase' || key === 'region' || key === 'accessKeyId' || key === 'secretAccessKeyEnv') {
            const next = typeof raw === 'string' ? raw.trim() : raw
            if (next === undefined || next === null || next === '') continue
            if (next !== before) ops.push({ op: 'set', path: [key], value: next })
            continue
          }
          if (!sameJson(raw, before)) ops.push({ op: 'set', path: [key], value: raw })
        }
        if (ops.length === 0) {
          store.set((current) => ({ dirty: !sameJson(current.draft, current.value) }))
          return true
        }
        store.set({ busy: true, notice: undefined })
        try {
          const response = await settingsRemote.mutate(NS, ops, state.revision)
          if (!response || response.ok !== true) {
            const detail = remoteMessageOf(response?.error) ?? '保存请求被宿主拒绝'
            await loadSettings()
            store.set({ busy: false, lastSaveError: detail, notice: { kind: 'err', code: 'saveFailed', text: detail } })
            return false
          }
          const row = response.value ?? {}
          const value = blank(row.value)
          store.set({
            busy: false,
            revision: typeof row.revision === 'number' ? row.revision : store.get().revision,
            value,
            draft: { ...value },
            dirty: false,
            lastSaveError: undefined,
            notice: { kind: 'ok', code: 'saved' },
          })
          // 配置刚变：可能刚填了 AK/SK、也可能改了卡片档位 —— 立刻重算一次报告，
          // 侧边栏那张卡片才能跟着出现/消失，而不是等到下一个轮询周期。
          void refreshUsage()
          return true
        } catch (error) {
          const detail = errorText(error)
          await loadSettings()
          store.set({ busy: false, lastSaveError: detail, notice: { kind: 'err', text: detail } })
          return false
        }
      }

      async function writeCredential(ref, value) {
        if (credentialsRemote === undefined) {
          store.set({ notice: { kind: 'err', code: 'credentialsUnavailable' } })
          return false
        }
        store.set({ busy: true, notice: undefined })
        try {
          const response = await credentialsRemote.set(ref, value)
          if (!response || response.ok !== true) {
            store.set({ busy: false, notice: { kind: 'err', code: 'credentialWriteFailed', text: response?.error?.message } })
            return false
          }
          store.set({ busy: false, notice: { kind: 'ok', code: 'saved' } })
          await loadKey()
          await refreshUsage()
          return true
        } catch (error) {
          store.set({ busy: false, notice: { kind: 'err', text: errorText(error) } })
          return false
        }
      }

      async function clearCredential(ref) {
        if (credentialsRemote === undefined) {
          store.set({ notice: { kind: 'err', code: 'credentialsUnavailable' } })
          return false
        }
        store.set({ busy: true, notice: undefined })
        try {
          const response = await credentialsRemote.unset(ref)
          if (!response || response.ok !== true) {
            store.set({ busy: false, notice: { kind: 'err', code: 'credentialClearFailed', text: response?.error?.message } })
            return false
          }
          store.set({ busy: false, notice: { kind: 'ok', code: 'cleared' } })
          await loadKey()
          return true
        } catch (error) {
          store.set({ busy: false, notice: { kind: 'err', text: errorText(error) } })
          return false
        }
      }

      /** 移除账户时静默清凭据：失败也不弹提示（用户要的是"删掉这一行"）。 */
      async function unsetCredentialQuiet(ref) {
        if (credentialsRemote === undefined || typeof ref !== 'string' || ref === '') return
        try { await credentialsRemote.unset(ref) } catch { /* 尽力而为 */ }
      }

      /** 账户数组改完立即提交（账户操作即时生效）。 */
      async function commitAccounts(next, patch) {
        store.set((state) => {
          const draft = { ...state.draft, accounts: next, ...(patch ?? {}) }
          return { draft, dirty: !sameJson(draft, state.value) }
        })
        const ok = await save()
        if (ok) await loadKey()
        return ok
      }

      /** 选一个没被任何既有账户占用的 cred 引用名。 */
      function nextKeyRef(accounts) {
        const used = new Set(accounts.map((account) => account?.apiKeyEnv).filter((ref) => typeof ref === 'string' && ref !== ''))
        used.add(DEFAULT_KEY_REF)
        let index = accounts.length + 1
        while (used.has(`ARK_CODING_API_KEY_${index}`)) index += 1
        return `ARK_CODING_API_KEY_${index}`
      }

      // --- 添加账户（契约 §4） ---------------------------------------------

      function openAddAccount() {
        store.set({ add: { ...blankAddFlow(), open: true } })
      }

      function setAddAccount(patch) {
        store.set((state) => ({ add: { ...state.add, ...patch } }))
      }

      function cancelAddAccount() {
        store.set({ add: blankAddFlow() })
      }

      /**
       * 提交添加。
       *
       * 顺序很重要：先把账户写进设置（宿主据此给 CLI 账户派生 HOME），
       * 再写密钥 / 发起登录。key 永远走 credentials.set，绝不进设置文档。
       */
      async function confirmAddAccount() {
        const add = store.get().add ?? {}
        const type = add.type === 'cli' ? 'cli' : 'apikey'
        const list = accountRows()
        if (type === 'apikey' && (typeof add.key !== 'string' || add.key.trim() === '')) {
          store.set((state) => ({ add: { ...state.add, error: 'missing-key' } }))
          return { ok: false, error: 'missing-key' }
        }
        const ref = type === 'apikey' ? nextKeyRef(list) : ''
        const id = typeof add.id === 'string' && add.id.trim() !== '' ? add.id.trim() : randomAccountId()
        const account = {
          id,
          label: typeof add.name === 'string' ? add.name.trim() : '',
          type,
          apiKeyEnv: ref,
          home: '',
        }
        store.set((state) => ({ add: { ...state.add, busy: true, error: undefined } }))
        const saved = await commitAccounts([...list, account])
        if (!saved) {
          store.set((state) => ({ add: { ...state.add, busy: false, error: 'save-failed' } }))
          return { ok: false, accountId: id, error: 'save-failed' }
        }
        if (type === 'apikey') {
          const written = await writeCredential(ref, add.key.trim())
          if (!written) {
            store.set((state) => ({ add: { ...state.add, busy: false, error: 'key-failed' } }))
            return { ok: false, accountId: id, error: 'key-failed' }
          }
        } else {
          await loginBegin(id)
        }
        store.set({ add: blankAddFlow() })
        await refreshUsage()
        return { ok: true, accountId: id }
      }

      /** 改名即时提交；空白名字交回宿主生成默认名。 */
      async function renameAccount(accountId, label) {
        const list = accountRows()
        const index = list.findIndex((account) => account?.id === accountId)
        if (index < 0) return false
        const next = [...list]
        next[index] = { ...next[index], label: typeof label === 'string' ? label.trim() : '' }
        return commitAccounts(next)
      }

      async function removeAccount(accountId) {
        const list = accountRows()
        const target = list.find((account) => account?.id === accountId)
        if (target === undefined) return false
        const next = list.filter((account) => account?.id !== accountId)
        const preferred = store.get().draft?.activeAccount
        const ok = await commitAccounts(next, preferred === accountId ? { activeAccount: '' } : undefined)
        if (!ok) return false
        if (target.type !== 'cli' && typeof target.apiKeyEnv === 'string' && target.apiKeyEnv !== '') {
          await unsetCredentialQuiet(target.apiKeyEnv)
          await loadKey()
        }
        await refreshUsage()
        return true
      }

      async function setPreferred(id) {
        const current = store.get().value?.activeAccount
        store.set((state) => {
          const draft = { ...state.draft, activeAccount: current === id ? '' : id }
          return { draft, dirty: !sameJson(draft, state.value) }
        })
        return save()
      }

      // --- 用量报告 ---------------------------------------------------------

      async function refreshUsage() {
        if (usageRemote === undefined || typeof usageRemote.report !== 'function') {
          store.set({ usageError: 'hostMissingReport', usageLoading: false })
          return
        }
        store.set({ usageLoading: true })
        try {
          const { payload, error } = readRemote(await usageRemote.report())
          if (error !== undefined || payload === undefined || payload.plan === undefined) {
            store.set({ usageLoading: false, usageError: error ?? 'usage failed' })
            return
          }
          store.set({ usageLoading: false, usage: payload, usageError: undefined })
          seedAccountsFromReport()
        } catch (error) {
          store.set({ usageLoading: false, usageError: errorText(error) })
        }
      }

      // --- arkcli 安装（契约 §2.5） ----------------------------------------

      async function cliInstall() {
        if (usageRemote === undefined || typeof usageRemote.cliInstall !== 'function') {
          store.set({ cliInstallError: 'hostMissingCliInstall' })
          return false
        }
        store.set({ cliInstalling: true, cliInstallError: undefined })
        try {
          const { payload, error } = readRemote(await usageRemote.cliInstall())
          if (error !== undefined || payload === undefined || payload.installed !== true) {
            store.set({ cliInstalling: false, cliInstallError: payload?.error ?? error ?? 'install failed' })
            await refreshUsage()
            return false
          }
          store.set({ cliInstalling: false, cliInstallError: undefined })
          // 装完必须重新 report：cli/path/version 都在报告里。
          await refreshUsage()
          return true
        } catch (error) {
          store.set({ cliInstalling: false, cliInstallError: errorText(error) })
          return false
        }
      }

      // --- 官方目录刷新（契约 §2.4） ---------------------------------------

      async function catalogRefresh() {
        if (usageRemote === undefined || typeof usageRemote.catalogRefresh !== 'function') return false
        store.set({ catalogLoading: true })
        try {
          const { payload, error } = readRemote(await usageRemote.catalogRefresh())
          if (error !== undefined || payload === undefined) {
            store.set({ catalogLoading: false, notice: { kind: 'err', text: error ?? 'catalog refresh failed' } })
            return false
          }
          store.set((state) => ({
            catalogLoading: false,
            usage: state.usage === undefined ? state.usage : { ...state.usage, catalog: payload },
          }))
          return true
        } catch (error) {
          store.set({ catalogLoading: false, notice: { kind: 'err', text: errorText(error) } })
          return false
        }
      }

      // --- CLI 登录向导（契约 §4.2） ---------------------------------------

      function clearLoginTimer() {
        if (loginTimer !== undefined) {
          clearTimeout(loginTimer)
          loginTimer = undefined
        }
      }

      /** 轮询只在向导处于 waiting 时继续；done/error/cancel 都会停。 */
      function scheduleLoginPoll(accountId, delay) {
        clearLoginTimer()
        loginTimer = setTimeout(() => {
          loginTimer = undefined
          void loginPoll(accountId).then((result) => {
            if (result?.keepPolling === true && store.get().login.phase === 'waiting') {
              scheduleLoginPoll(accountId, LOGIN_POLL_EVERY_MS)
            }
          })
        }, delay)
      }

      /**
       * 登录成功后的收尾：记状态、按需用身份补名字、刷新报告。
       *
       * 补名字只在用户当初留空时做 —— 契约 §4.2 的可选项，用户填过就不覆盖。
       */
      async function finishLogin(accountId, identity) {
        clearLoginTimer()
        store.set((state) => ({ login: { ...state.login, accountId, phase: 'done', identity, error: undefined } }))
        const custom = identity?.userName ?? identity?.accountId
        const target = accountRows().find((account) => account?.id === accountId)
        if (typeof custom === 'string' && custom.trim() !== '' && target !== undefined && (target.label ?? '').trim() === '') {
          await renameAccount(accountId, custom)
        }
        await refreshUsage()
      }

      /**
       * 发起登录：拿授权 URL，然后开始轮询。
       *
       * 客户端只负责"把 URL 给用户、把回跳地址收回来"；真正的回环转发在宿主上。
       */
      async function loginBegin(accountId) {
        const id = typeof accountId === 'string' ? accountId.trim() : ''
        clearLoginTimer()
        store.set({
          login: {
            ...blankLogin(),
            accountId: id,
            phase: 'starting',
            startedAt: Date.now(),
          },
        })
        if (usageRemote === undefined || typeof usageRemote.loginBegin !== 'function') {
          store.set((state) => ({ login: { ...state.login, phase: 'error', error: 'hostMissingLoginBegin' } }))
          return { ok: false, accountId: id, error: 'unavailable' }
        }
        let result
        try {
          result = readRemote(await usageRemote.loginBegin({ accountId: id }))
        } catch (error) {
          result = { payload: undefined, error: errorText(error) }
        }
        const value = result.payload
        if (result.error !== undefined || value === undefined || value.ok !== true) {
          const error = result.error ?? value?.error ?? 'loginBegin failed'
          store.set((state) => ({ login: { ...state.login, accountId: id, phase: 'error', url: value?.url, error } }))
          return { ok: false, accountId: id, error }
        }
        store.set({
          login: {
            accountId: id,
            phase: 'waiting',
            url: value.url,
            port: value.port,
            hint: value.hint,
            error: undefined,
            identity: undefined,
            note: undefined,
            startedAt: Date.now(),
          },
        })
        scheduleLoginPoll(id, LOGIN_POLL_FIRST_MS)
        return { ok: true, accountId: id, url: value.url }
      }

      /** 查一次登录状态（供轮询与测试直接驱动）。 */
      async function loginPoll(accountId) {
        const id = typeof accountId === 'string' ? accountId.trim() : ''
        if (store.get().login.accountId !== id) return { ok: false, state: 'stale', keepPolling: false }
        if (usageRemote === undefined || typeof usageRemote.loginPoll !== 'function') {
          store.set((state) => ({ login: { ...state.login, phase: 'error', error: 'hostMissingLoginPoll' } }))
          return { ok: false, state: 'error', keepPolling: false }
        }
        let result
        try {
          result = readRemote(await usageRemote.loginPoll({ accountId: id }))
        } catch (error) {
          result = { payload: undefined, error: errorText(error) }
        }
        const value = result.payload
        const phase = value?.state
        if (phase === 'done') {
          await finishLogin(id, value?.identity)
          return { ok: true, state: 'done', keepPolling: false }
        }
        if (phase === 'pending') {
          store.set((state) => ({ login: { ...state.login, phase: 'waiting', error: undefined } }))
          return { ok: true, state: 'pending', keepPolling: true }
        }
        if (phase === 'error' || phase === 'expired' || phase === 'unknown') {
          const error = value?.error ?? result.error ?? (phase === 'expired' ? 'loginSessionExpired' : 'loginFailed')
          store.set((state) => ({ login: { ...state.login, phase: 'error', state: phase, error } }))
          return { ok: false, state: phase, error, keepPolling: false }
        }
        if (result.error !== undefined) {
          store.set((state) => ({ login: { ...state.login, phase: 'error', error: result.error } }))
          return { ok: false, state: 'error', error: result.error, keepPolling: false }
        }
        return { ok: false, state: 'unknown', keepPolling: false }
      }

      /** 把用户粘回来的回调地址交给宿主转发。 */
      async function loginSubmit(accountId, input) {
        const id = typeof accountId === 'string' ? accountId.trim() : ''
        store.set((state) => ({ login: { ...state.login, accountId: id, phase: 'submitting', error: undefined } }))
        if (usageRemote === undefined || typeof usageRemote.loginSubmit !== 'function') {
          store.set((state) => ({ login: { ...state.login, phase: 'error', error: 'hostMissingLoginSubmit' } }))
          return { ok: false, state: 'error', error: 'unavailable' }
        }
        let result
        try {
          result = readRemote(await usageRemote.loginSubmit({ accountId: id, input: typeof input === 'string' ? input : '' }))
        } catch (error) {
          result = { payload: undefined, error: errorText(error) }
        }
        const value = result.payload
        if (value?.state === 'done') {
          await finishLogin(id, value.identity)
          return { ok: true, state: 'done' }
        }
        const message = result.error ?? value?.error
        if (value?.state === 'error' || value?.state === 'expired' || value?.state === 'unknown') {
          store.set((state) => ({ login: { ...state.login, phase: 'error', state: value.state, error: message ?? 'loginFailed' } }))
          return { ok: false, state: value.state, error: message }
        }
        if (message !== undefined) {
          // 会话还活着（多半是粘错了）：把错误显示出来，同时继续等/轮询。
          store.set((state) => ({ login: { ...state.login, phase: 'waiting', error: message } }))
          scheduleLoginPoll(id, LOGIN_POLL_EVERY_MS)
          return { ok: false, state: value?.state ?? 'pending', error: message }
        }
        store.set((state) => ({ login: { ...state.login, phase: 'waiting', note: value?.note, error: undefined } }))
        scheduleLoginPoll(id, LOGIN_POLL_EVERY_MS)
        return { ok: true, state: value?.state ?? 'pending' }
      }

      /** 取消向导但**不**移除账户：用户可能只是想重来。 */
      async function loginCancel(accountId) {
        const id = typeof accountId === 'string' ? accountId.trim() : store.get().login.accountId
        clearLoginTimer()
        try {
          if (usageRemote !== undefined && typeof usageRemote.loginCancel === 'function') {
            await usageRemote.loginCancel({ accountId: id })
          }
        } catch { /* 会话可能已经结束了，取消失败不影响关掉向导 */ }
        store.set({ login: blankLogin() })
        void refreshUsage()
        return true
      }

      return {
        store,
        attachSettings(namespace) { settingsRemote = namespace; void loadSettings() },
        attachCredentials(namespace) { credentialsRemote = namespace; void loadKey() },
        attachUsage(namespace) { usageRemote = namespace; void refreshUsage() },
        refresh() { void loadSettings(); void loadKey(); void refreshUsage() },
        loadSettings, loadKey, refreshUsage,
        editField, discard, save,
        writeCredential, clearCredential,
        accountRows, openAddAccount, setAddAccount, cancelAddAccount, confirmAddAccount,
        renameAccount, removeAccount, setPreferred,
        loginBegin, loginPoll, loginSubmit, loginCancel,
        cliInstall, catalogRefresh,
        dispose() { clearLoginTimer() },
      }
    }

    // -----------------------------------------------------------------------
    // 组件
    // -----------------------------------------------------------------------

    function useTranslate(props) {
      return useCallback((key) => {
        if (typeof props?.t === 'function') {
          try {
            const value = props.t(key)
            if (typeof value === 'string' && value !== '') return value
          } catch { /* 席位缺失时退回内置英文 */ }
        }
        return EN[key] ?? key
      }, [props?.t])
    }

    function useControllerState(controller) {
      return useSyncExternalStore(controller.store.subscribe, controller.store.get)
    }

    /**
     * 控制器存的稳定 code → 当前语言；**远端消息原样透传**。
     *
     * 不能无条件 `t(value)`：locale 找不到词条时会把 key 原样返回，而 "key"
     * 也可能撞上 `common` 命名空间里的词条（例如 "Close"），那样远端报错就会被
     * 误翻。只在确实是本文件定义的 code 时才翻。
     */
    function errorTextOf(t, value) {
      if (typeof value !== 'string' || value === '') return value
      const known = Object.prototype.hasOwnProperty.call(ZH, value) || Object.prototype.hasOwnProperty.call(EN, value)
      return known ? t(value) : value
    }

    function Row({ label, hint, children }) {
      return h('div', { className: 'akc-row' },
        h('div', { className: 'akc-rowLabel' }, h('div', null, label), hint === undefined ? null : h('span', null, hint)),
        children)
    }

    function Card({ title, extra, children }) {
      return h('section', { className: 'akc-card' },
        h('div', { className: 'akc-cardHead' }, h('h3', null, title), extra ?? null),
        h('div', { className: 'akc-cardBody' }, children))
    }

    /** 提示条：控制器存的是稳定 code，这里翻成当前语言。 */
    function Note({ notice, t }) {
      if (notice === undefined || notice === null) return null
      const text = notice.code === 'saved' ? t('saved')
        : notice.code === 'cleared' ? t('cleared')
          : notice.code === 'saveFailed' ? `${t('saveFailed')}${notice.text ? `: ${notice.text}` : ''}`
            : notice.code === 'credentialsUnavailable' ? t('credentialsUnavailable')
              : notice.code === 'credentialWriteFailed' ? `${t('credentialWriteFailed')}${notice.text ? `: ${notice.text}` : ''}`
                : notice.code === 'credentialClearFailed' ? `${t('credentialClearFailed')}${notice.text ? `: ${notice.text}` : ''}`
                  : (notice.text ?? notice.code ?? '')
      return h('div', { className: `akc-note ${notice.kind === 'err' ? 'err' : 'ok'}` }, text)
    }

    /**
     * 一条用量窗口：标题 + 数值 + 进度条 +（可选）重置时间。
     *
     * **永远画条**：能走到这里的一定是控制面给的真实百分比。以前本机统计那条路
     * 会以 `showBar: false` 进来（只知道用了多少、不知道上限，画出来恒等于 100%，
     * 配上"≥90% 变红"就是三根满格红条），本机统计删掉后这个开关也一起没了。
     */
    function UsageWindow({ label, percent, valueText, hint }) {
      const tone = percent >= 90 ? 'err' : percent >= 60 ? 'warn' : ''
      return h('div', { className: 'akc-window' },
        h('div', { className: 'akc-windowHead' },
          h('span', { className: 'akc-windowLabel' }, label),
          h('span', { className: 'akc-windowValue' }, valueText)),
        h('div', { className: 'akc-bar' },
          h('div', { className: `akc-barFill ${tone}`, style: { width: `${Math.max(0, Math.min(100, percent))}%` } })),
        hint === undefined ? null : h('div', { className: 'akc-sideMeta' }, hint))
    }

    /** 一个凭据输入（写凭据服务，不写配置文件）。 */
    function CredentialInput({ controller, t, refName, disabled, placeholder, configured }) {
      const [draft, setDraft] = useState('')
      const submit = () => {
        const value = draft.trim()
        if (value === '') return
        void controller.writeCredential(refName, value).then((ok) => { if (ok) setDraft('') })
      }
      return h('div', { className: 'akc-tools' },
        h('input', {
          className: 'akc-input', type: 'password', value: draft, disabled,
          placeholder: placeholder ?? `${t('accountKeyPlaceholder')} (${refName})`,
          autoComplete: 'off', spellCheck: false, 'aria-label': `${t('keySection')} ${refName}`,
          onChange: (event) => setDraft(event.target.value),
          onKeyDown: (event) => { if (event.key === 'Enter') submit() },
        }),
        h('button', { type: 'button', className: 'akc-btn primary', disabled: disabled || draft.trim() === '', onClick: submit }, t('save')),
        h('button', {
          type: 'button', className: 'akc-btn', disabled: disabled || configured !== true,
          onClick: () => void controller.clearCredential(refName),
        }, t('clear')))
    }

    /**
     * 账户名：本地暂存，回车/失焦时提交（空名字等于交回宿主生成默认名）。
     *
     * `placeholder` 由调用方传**宿主解析出来的名字**：用户留空时也能看见这个账户
     * 到底叫什么（默认名只存在于宿主，不是客户端编的）。
     */
    function AccountNameInput({ controller, t, accountId, value, placeholder, disabled }) {
      const [draft, setDraft] = useState(value ?? '')
      // 父组件用 `key: row.id` 稳定复用这个实例，不会重挂载；而登录成功后控制器会
      // 自动把身份名补进账户（finishLogin → renameAccount）。只读一次挂载值的旧写法
      // 会一直显示空 + "留空即可"，用户一次失焦就把自动补的名字写回成空串。
      useEffect(() => { setDraft(value ?? '') }, [value])
      const commit = () => { void controller.renameAccount(accountId, draft) }
      return h('input', {
        className: 'akc-input akc-accountNameInput', value: draft, disabled,
        placeholder: placeholder ?? t('accountNamePlaceholder'), title: placeholder ?? '',
        'aria-label': `${t('accountName')}${placeholder ? ` — ${placeholder}` : ''}`, spellCheck: false,
        onChange: (event) => setDraft(event.target.value),
        onBlur: commit,
        onKeyDown: (event) => { if (event.key === 'Enter') commit() },
      })
    }

    /**
     * CLI 登录向导（契约 §4.2）。
     *
     * 关键 UX：用户在浏览器完成 SSO 后会被重定向到 `http://127.0.0.1:<port>/…`
     * （实测是 127.0.0.1，不是 localhost），而那个端口开在**服务器**上，浏览器必然
     * 打不开。所以这里必须把"打不开是正常的"讲清楚，并给一个输入框让用户把地址栏里
     * 的整条地址粘回来。
     */
    function LoginWizard({ controller, t, login }) {
      const [pasted, setPasted] = useState('')
      const [copied, setCopied] = useState(false)
      const accountId = login.accountId
      const phase = login.phase
      const current = phase === 'done' ? 2 : (phase === 'submitting' || phase === 'error') ? 1 : 0
      const identity = login.identity ?? {}
      const identityName = identity.userName ?? identity.accountId
      const steps = ['loginStepAuthorize', 'loginStepPaste', 'loginStepDone']
      // 授权地址是远端给的：只有 http(s) 才配成可点的链接，其余（`javascript:` /
      // `data:` …）只当文本显示，仍然可以复制。
      const rawUrl = typeof login.url === 'string' ? login.url : ''
      const safeUrl = /^https?:\/\//i.test(rawUrl) ? rawUrl : undefined
      const errorMessage = errorTextOf(t, login.error)
      const submit = () => {
        const value = pasted.trim()
        if (value === '') return
        void controller.loginSubmit(accountId, value)
      }
      return h('div', {
        className: 'akc-wizard', role: 'group', 'aria-label': t('loginTitle'),
      },
      h('div', { className: 'akc-accountHead' },
        h('span', { className: 'akc-accountName' }, t('loginTitle')),
        h('span', { className: `akc-pill ${phase === 'done' ? 'ok' : phase === 'error' ? 'err' : ''}` },
          phase === 'done' ? t('loginDone') : phase === 'error' ? t('loginFailed') : t('loginWaiting'))),
      h('ol', { className: 'akc-steps' }, steps.map((key, index) => h('li', {
        key, className: 'akc-step', 'aria-current': index === current ? 'step' : undefined,
      }, t(key)))),
      h('div', { role: 'status', 'aria-live': 'polite', className: 'akc-hint' },
        phase === 'starting' ? t('loginStarting')
          : phase === 'done' ? `${t('loginDone')}${identityName ? ` · ${t('loginIdentityName')} ${identityName}` : ''}`
            : phase === 'error' ? (errorMessage ?? t('loginFailed'))
              : t('loginWaiting')),
      rawUrl === '' ? null : h('div', { className: 'akc-tools' },
        safeUrl === undefined ? null : h('a', {
          className: 'akc-btn primary akc-loginOpen', href: safeUrl, target: '_blank', rel: 'noreferrer',
          'aria-label': t('loginOpen'),
        }, t('loginOpen')),
        h('button', {
          type: 'button', className: 'akc-btn akc-loginCopy', 'aria-label': t('copy'),
          onClick: () => { void copyText(rawUrl).then((ok) => setCopied(ok === true)) },
        }, copied ? t('copied') : t('copy'))),
      rawUrl === '' ? null : h('div', { className: 'akc-urlLabel akc-quiet' }, t('loginUrlLabel')),
      rawUrl === '' ? null : h('div', { className: 'akc-url akc-mono' }, rawUrl),
      // 宿主不再保证给 hint；缺了就不渲染这一块，向导自己的两步说明照旧完整。
      login.hint ? h('div', { className: 'akc-note' }, login.hint) : null,
      h('p', { className: 'akc-hint' }, t('loginFerryNote')),
      h('p', { className: 'akc-hint' }, t('loginOrWait')),
      phase === 'done'
        ? h('div', { className: 'akc-note ok' },
            `${t('loginDone')}${identityName ? ` · ${t('loginIdentityName')} ${identityName}` : ''}${identity.accountId ? ` · ${t('loginIdentityAccount')} ${identity.accountId}` : ''}`)
        : h('div', { className: 'akc-tools' },
            h('input', {
              className: 'akc-input akc-loginPaste', value: pasted, 'aria-label': t('loginPasteLabel'),
              placeholder: t('loginPastePlaceholder'), spellCheck: false, autoComplete: 'off',
              onChange: (event) => setPasted(event.target.value),
              onKeyDown: (event) => { if (event.key === 'Enter') submit() },
            }),
            h('button', {
              type: 'button', className: 'akc-btn primary akc-loginSubmit',
              disabled: pasted.trim() === '' || phase === 'submitting',
              onClick: submit,
            }, t('loginSubmit'))),
      login.note ? h('div', { className: 'akc-note' }, `${t('loginNote')}: ${login.note}`) : null,
      login.error !== undefined && phase !== 'done' ? h('div', { className: 'akc-note err akc-loginError' }, errorMessage) : null,
      h('div', { className: 'akc-tools' },
        h('button', {
          type: 'button', className: 'akc-btn akc-loginRestart',
          onClick: () => void controller.loginBegin(accountId),
        }, t('loginRestart')),
        h('button', {
          type: 'button', className: 'akc-btn akc-loginCancel',
          onClick: () => void controller.loginCancel(accountId),
        }, t('cancel'))))
    }

    /** 一个账户行：类型徽章、可编辑名字、状态、即时动作。 */
    function AccountRow({ controller, t, row, preferred, disabled }) {
      const [confirming, setConfirming] = useState(false)
      const reasonText = (reason) => reason === 'rate-limit' ? t('reasonRateLimit')
        : reason === 'quota' ? t('reasonQuota')
          : reason === 'invalid-credential' ? t('reasonAuth')
            : reason === 'auth' ? t('reasonAuth') : t('cooling')
      const identity = row.identity ?? {}
      const identityName = identity.userName ?? identity.accountId
      const status = row.mark !== null
        ? { tone: 'err', text: `${reasonText(row.mark.reason)} · ${t('until')} ${formatClock(row.mark.until)}` }
        : row.type === 'cli'
          ? row.live?.loggedIn === true
            ? { tone: '', text: identityName ? `${t('loggedInAs')} ${identityName}` : t('accountConfigured') }
            : { tone: 'err', text: row.needsInstall === true ? t('cliMissing') : t('notLoggedIn') }
          : row.configured ? { tone: '', text: t('accountConfigured') } : { tone: 'err', text: t('accountMissing') }
      // 凭据到期只对「已登录的 CLI 账户」有意义。credentialExpiresAt 是宿主从 arkcli
      // 的 profile 里读出来的**服务端事实**（会随租户/策略变化），所以显示算出来的
      // 具体日期；读不到（undefined）时就只字不提，绝不编一个日期出来。
      const expiresAt = row.type === 'cli' && typeof row.expiresAt === 'number' && Number.isFinite(row.expiresAt)
        ? row.expiresAt
        : undefined
      const expired = expiresAt !== undefined && expiresAt <= Date.now()
      const daysLeft = expiresAt === undefined ? undefined : Math.ceil((expiresAt - Date.now()) / 86_400_000)
      const expiringSoon = expired !== true && daysLeft !== undefined && daysLeft <= 7
      return h('div', { className: `akc-account ${preferred === row.id ? 'active' : ''}`, 'data-account-id': row.id },
        h('div', { className: 'akc-accountHead' },
          h('i', { className: `akc-dot ${row.mark !== null ? 'err' : row.configured ? 'on' : 'off'}` }),
          h('span', { className: 'akc-pill' }, row.type === 'cli' ? t('typeCli') : t('typeApiKey')),
          h(AccountNameInput, {
            controller, t, accountId: row.id, value: row.custom,
            placeholder: row.custom === '' ? row.label : t('accountNamePlaceholder'), disabled,
          }),
          h('span', { className: `akc-pill ${status.tone}` }, status.text),
          row.source === undefined ? null : h('span', { className: 'akc-pill' }, row.source),
          preferred === row.id ? h('span', { className: 'akc-pill brand' }, t('accountPreferred')) : null,
          h('span', { style: { flex: 1 } }),
          h('button', {
            type: 'button', className: 'akc-btn akc-prefer', disabled,
            onClick: () => void controller.setPreferred(row.id),
          }, preferred === row.id ? t('accountPreferred') : t('accountUse')),
          row.type === 'cli' ? h('button', {
            // 凭据过期时「重新登录」是唯一该做的事，所以把它变成主按钮。
            type: 'button', className: `akc-btn ${expired ? 'primary ' : ''}akc-relogin`, disabled,
            onClick: () => void controller.loginBegin(row.id),
          }, t('reLogin')) : null,
          confirming
            ? h('span', { className: 'akc-tools' },
                h('span', { className: 'akc-quiet' }, t('removeConfirm')),
                h('button', {
                  type: 'button', className: 'akc-btn danger akc-removeConfirm', disabled,
                  onClick: () => { setConfirming(false); void controller.removeAccount(row.id) },
                }, t('removeConfirmYes')),
                h('button', { type: 'button', className: 'akc-btn', onClick: () => setConfirming(false) }, t('cancel')))
            : h('button', {
                type: 'button', className: 'akc-btn danger akc-remove', disabled, title: t('removeHomeNote'),
                onClick: () => setConfirming(true),
              }, t('removeAccount'))),
        h('div', { className: 'akc-accountMeta' },
          row.type === 'cli'
            ? `${t('accountHomeLabel')}: ${row.home || '(DSH_HOME/ark-coding/accounts/' + row.id + ')'}`
            : `${t('accountRefLabel')}: ${row.ref || '—'}`),
        // 到期提示放在账户事实下面：warning 用 warn 色，过期用 err 色 + 主按钮重登。
        expiresAt === undefined ? null : h('div', {
          className: `akc-expiry ${expired ? 'akc-note err' : expiringSoon ? 'akc-note warn' : 'akc-hint'}`,
          role: 'status',
        }, expired
          ? `${t('credentialExpired')} · ${t('credentialExpires')} ${formatDate(expiresAt)}`
          : expiringSoon
            ? `${t('credentialExpiresIn')} ${Math.max(0, daysLeft)} ${t('credentialDaysLeft')} · ${formatDate(expiresAt)}`
            : `${t('credentialExpires')} ${formatDate(expiresAt)}`),
        row.type === 'cli'
          ? h('p', { className: 'akc-quiet' }, t('removeHomeNote'))
          : h(CredentialInput, {
              controller, t, refName: row.ref, configured: row.configured,
              disabled: disabled || row.ref === '',
            }))
    }

    /** 账户卡片：arkcli 状态、添加流程（类型 + 可选名字）、登录向导、账户列表。 */
    function AccountsCard({ controller, t }) {
      const state = useControllerState(controller)
      const draft = state.draft ?? {}
      const busy = state.busy === true
      const disabled = !state.writable || busy
      const preferred = typeof draft.activeAccount === 'string' ? draft.activeAccount : ''
      const accounts = controller.accountRows()
      const reportAccounts = Array.isArray(state.usage?.accounts) ? state.usage.accounts : []
      const keyState = Array.isArray(state.accounts) ? state.accounts : []
      const add = state.add ?? blankAddFlow()
      const login = state.login ?? blankLogin()
      const cli = state.usage?.cli
      // 报告还没到之前 `cli` 是 undefined：这时不能当作"没装"，否则首页会先闪一个
      // 安装按钮出来（真机上很难看，也会诱使用户点一个并不需要的操作）。
      const cliKnown = cli !== undefined
      const installed = cli?.installed === true

      const rows = accounts.map((account, index) => {
        const live = reportAccounts.find((entry) => entry?.id === account?.id)
        const type = account?.type === 'cli' || live?.type === 'cli' ? 'cli' : 'apikey'
        const custom = typeof account?.label === 'string' ? account.label.trim() : ''
        const hostLabel = typeof live?.label === 'string' && live.label !== '' ? live.label : ''
        const label = custom !== '' ? custom : (hostLabel !== '' ? hostLabel : `${type === 'cli' ? t('typeCli') : t('typeApiKey')} #${index + 1}`)
        const ref = type === 'cli' ? '' : (typeof account?.apiKeyEnv === 'string' && account.apiKeyEnv !== '' ? account.apiKeyEnv : (live?.ref ?? ''))
        const fromKey = keyState.find((entry) => entry.id === account?.id)
        return {
          id: typeof account?.id === 'string' && account.id !== '' ? account.id : `account-${index + 1}`,
          index, type, ref, custom, label, live,
          home: typeof account?.home === 'string' ? account.home : '',
          configured: live !== undefined ? live.configured === true : fromKey?.configured === true,
          source: live?.source ?? fromKey?.source,
          identity: live?.identity,
          needsInstall: live?.needsInstall === true,
          mark: live?.mark ?? null,
          // CLI 账户登录凭据的到期时间（epoch ms）；宿主读不到就是 undefined。
          expiresAt: typeof live?.credentialExpiresAt === 'number' ? live.credentialExpiresAt : undefined,
        }
      })

      const addErrorText = (code) => code === 'missing-key' ? t('addKeyRequired')
        : code === 'key-failed' ? t('credentialWriteFailed')
          : code === 'save-failed'
            ? `${t('saveFailed')}${state.lastSaveError ? `: ${state.lastSaveError}` : ''}`
            : (code ?? '')

      // 类型说明：两种账户能拿到的东西**不一样**，选之前就得讲清楚。
      // CLI 的凭据有时效：如果这个待添加的账户已经有报告数据（里面有宿主读出的
      // credentialExpiresAt），就顺手把具体日期显示出来；否则说明登录后这里会显示。
      const addLive = reportAccounts.find((entry) => entry?.id === add.id)
      const addExpiry = typeof addLive?.credentialExpiresAt === 'number' ? addLive.credentialExpiresAt : undefined
      const typeNoteText = add.type === 'cli'
        ? (addExpiry === undefined
            ? `${t('typeNoteCli')} ${t('typeNoteCliExpiryUnknown')}`
            : `${t('typeNoteCli')} · ${t('typeNoteCliExpiry')} ${formatDate(addExpiry)}`)
        : t('typeNoteApiKey')

      return h(Card, {
        title: `${t('accountsSection')} · ${rows.length}`,
        extra: h('button', {
          // 一个账户都没有时，「添加账户」是这张卡片唯一该做的事 —— 给它主按钮的样式。
          type: 'button', className: `akc-btn akc-addAccount${rows.length === 0 ? ' primary' : ''}`, disabled,
          onClick: () => controller.openAddAccount(),
        }, t('addAccount')),
      },
      h('p', { className: 'akc-hint' }, t('accountsHint')),

      // --- 空状态：明确说"没有账户、聊天需要账户"，并简述两种类型的差别 ---
      // 宿主那边 `accounts` 可以为空（没有可兼容的顶层 apiKeyEnv 账户了），
      // 静默渲染成空白卡片会让人以为页面坏了。
      rows.length === 0
        ? h('div', { className: 'akc-empty' },
            h('div', { className: 'akc-emptyTitle' }, t('accountsEmptyTitle')),
            h('p', { className: 'akc-hint' }, t('accountsEmptyBody')),
            h('p', { className: 'akc-hint' }, t('accountsEmptyTypes')))
        : null,

      // --- arkcli 状态/安装（契约 §2.5） ---
      h('div', { className: 'akc-row' },
        h('div', { className: 'akc-rowLabel' },
          h('div', null, t('cliSection')),
          h('span', null, cliKnown !== true
            ? t('sidebarLoading')
            : installed
              ? `${t('cliReady')}${cli?.version ? ` · ${t('cliVersion')} ${cli.version}` : ''}${cli?.path ? ` · ${t('cliPath')} ${cli.path}` : ''}`
              : t('cliMissing'))),
        cliKnown === true && installed !== true
          ? h('button', {
              type: 'button', className: 'akc-btn primary akc-install', disabled: disabled || state.cliInstalling === true,
              onClick: () => void controller.cliInstall(),
            }, state.cliInstalling === true ? t('cliInstalling') : t('cliInstall'))
          : null),
      state.cliInstallError === undefined ? null : h('div', { className: 'akc-note err' }, `${t('cliInstallFailed')}: ${errorTextOf(t, state.cliInstallError)}`),

      // --- 添加账户：类型 + 可选名字（契约 §4） ---
      add.open
        ? h('div', { className: 'akc-addFlow' },
            h('div', { className: 'akc-row' },
              h('div', { className: 'akc-rowLabel' }, h('div', null, t('accountType'))),
              h('div', { className: 'akc-tools' },
                h('button', {
                  type: 'button', className: `akc-btn akc-typePicker ${add.type !== 'cli' ? 'primary' : ''}`,
                  'aria-pressed': add.type !== 'cli', disabled: add.busy === true,
                  onClick: () => controller.setAddAccount({ type: 'apikey' }),
                }, t('typeApiKey')),
                h('button', {
                  type: 'button', className: `akc-btn akc-typePicker ${add.type === 'cli' ? 'primary' : ''}`,
                  'aria-pressed': add.type === 'cli', disabled: add.busy === true,
                  onClick: () => controller.setAddAccount({ type: 'cli' }),
                }, t('typeCli')))),
            // 选中哪种类型，下面就解释哪种类型的能力边界（readonly 文本，随选择变化）。
            h('p', {
              className: 'akc-hint akc-typeNote', role: 'note',
              'data-account-type': add.type === 'cli' ? 'cli' : 'apikey',
            }, typeNoteText),
            h(Row, { label: t('accountName'), hint: t('accountNameOptional') },
              h('input', {
                className: 'akc-input akc-addName', value: add.name, disabled: add.busy === true,
                placeholder: t('accountNamePlaceholder'), 'aria-label': t('accountName'), spellCheck: false,
                onChange: (event) => controller.setAddAccount({ name: event.target.value }),
              })),
            add.type === 'cli'
              ? h('p', { className: 'akc-hint' }, t('cliAddHint'))
              : h(Row, { label: t('keySection'), hint: t('keyHint') },
                  h('input', {
                    className: 'akc-input akc-addKey', type: 'password', value: add.key, disabled: add.busy === true,
                    placeholder: t('accountKeyPlaceholder'), autoComplete: 'off', spellCheck: false,
                    'aria-label': t('keySection'),
                    onChange: (event) => controller.setAddAccount({ key: event.target.value }),
                    onKeyDown: (event) => { if (event.key === 'Enter') void controller.confirmAddAccount() },
                  })),
            add.error === undefined ? null : h('div', { className: 'akc-note err' }, addErrorText(add.error)),
            h('div', { className: 'akc-tools' },
              h('button', {
                type: 'button', className: 'akc-btn primary akc-addConfirm', disabled: add.busy === true,
                onClick: () => void controller.confirmAddAccount(),
              }, t('addConfirm')),
              h('button', {
                type: 'button', className: 'akc-btn akc-addCancel',
                onClick: () => controller.cancelAddAccount(),
              }, t('cancel'))))
        : null,

      // --- 登录向导 ---
      login.phase === 'idle' ? null : h(LoginWizard, { controller, t, login }),

      ...rows.map((row) => h(AccountRow, {
        key: row.id, controller, t, row, preferred, disabled,
      })))
    }

    /** 目录里一条模型：实测值为主，官方值并排；分歧显式标出来，绝不悄悄覆盖。 */
    function CatalogModel({ model, t, conflictFields }) {
      const official = model.official
      const officialCtx = official?.contextWindow ?? official?.maxInputTokens
      const input = Array.isArray(model.input) ? model.input : []
      const conflict = conflictFields.length > 0
      const fieldName = (field) => field === 'contextWindow' ? t('context')
        : field === 'maxOutput' ? t('output')
          : field === 'input' ? t('inputModality') : field
      return h('div', { className: `akc-modelRow ${conflict ? 'akc-conflictRow' : ''}`, 'data-model-id': model.id },
        h('div', { className: 'akc-modelMain' },
          h('div', { className: 'akc-modelName' }, model.name,
            h('span', { className: 'akc-tag' }, input.includes('image') ? t('vision') : t('textOnly'))),
          h('div', { className: 'akc-modelFacts' },
            `${t('catalogMeasured')} · ${t('context')} ${humanTokens(model.ctx)} · ${t('output')} ${humanTokens(model.out)} · ${model.id}`),
          official === undefined ? null : h('div', { className: 'akc-modelFacts akc-official' },
            `${t('catalogOfficial')} · ${t('context')} ${humanTokens(officialCtx ?? NaN)} · ${t('output')} ${humanTokens(official.maxOutputTokens ?? NaN)}${Array.isArray(official.inputModalities) && official.inputModalities.length > 0 ? ` · ${official.inputModalities.join('/')}` : ''}`),
          conflict
            ? h('div', { className: 'akc-note warn akc-conflict' },
                `${t('catalogConflict')}: ${conflictFields.map(fieldName).join(' / ')} — ${t('catalogConflictNote')}`)
            : null))
    }

    /** 模型白名单 + 官方目录对照。 */
    function ModelsCard({ controller, t }) {
      const state = useControllerState(controller)
      const draft = state.draft ?? {}
      const value = state.value ?? {}
      const busy = state.busy === true
      const disabled = !state.writable || busy
      const visibility = draft.modelVisibility && typeof draft.modelVisibility === 'object' ? draft.modelVisibility : {}
      const allowlist = Array.isArray(draft.visibleModels) ? draft.visibleModels : []
      const catalog = state.usage?.catalog
      const source = Array.isArray(catalog?.models) && catalog.models.length > 0 ? catalog.models : CATALOG
      const conflictMap = new Map(
        (Array.isArray(catalog?.conflicts) ? catalog.conflicts : [])
          .filter((entry) => entry && typeof entry.id === 'string')
          .map((entry) => [entry.id, Array.isArray(entry.fields) ? entry.fields : []]))
      const models = source.map((model) => ({
        id: model.id,
        name: model.name,
        ctx: typeof model.contextWindow === 'number' ? model.contextWindow : model.ctx,
        out: typeof model.maxOutput === 'number' ? model.maxOutput : model.out,
        input: Array.isArray(model.input) ? model.input : [],
        official: model.official,
        conflicts: Array.isArray(model.conflicts) && model.conflicts.length > 0 ? model.conflicts : (conflictMap.get(model.id) ?? []),
      }))
      const checked = (id) => {
        if (typeof visibility[id] === 'boolean') return visibility[id]
        return allowlist.length === 0 ? true : allowlist.includes(id)
      }
      const toggle = (id) => controller.editField('modelVisibility', { ...visibility, [id]: !checked(id) })
      const setAll = (on) => {
        const next = {}
        for (const model of models) next[model.id] = on
        controller.editField('modelVisibility', next)
      }
      const dirty = !sameJson(draft.modelVisibility, value.modelVisibility)
      const unmatched = typeof catalog?.unmatchedOfficial === 'number' ? catalog.unmatchedOfficial : 0
      const sample = Array.isArray(catalog?.officialSample) ? catalog.officialSample : []
      return h(Card, {
        title: `${t('modelsSection')} · ${models.length}`,
        extra: h('div', { className: 'akc-tools' },
          h('button', {
            type: 'button', className: 'akc-btn akc-catalogRefresh', disabled: state.catalogLoading === true,
            onClick: () => void controller.catalogRefresh(),
          }, state.catalogLoading === true ? t('catalogRefreshing') : t('catalogRefresh')),
          h('button', { type: 'button', className: 'akc-btn', disabled, onClick: () => setAll(true) }, t('selectAll')),
          h('button', { type: 'button', className: 'akc-btn', disabled, onClick: () => setAll(false) }, t('selectNone'))),
      },
      h('p', { className: 'akc-hint' }, t('modelsHint')),
      // dirty 不再是内联的 warn 前景色：warn 压白底只有 2.15，改走 .akc-note.warn
      // 的「浅底 + 常态文字 + 彩色描边」（实测 17.48 浅 / 14.79 深）。
      dirty ? h('p', { className: 'akc-note warn akc-modelDirty' }, t('modelsDirty')) : null,
      catalog === undefined ? null
        : catalog.ok !== true
          ? h('div', { className: 'akc-note' }, `${t('catalogUnavailable')}${catalog.error ? `: ${catalog.error}` : ''}`)
          : h('div', { className: 'akc-quiet' },
              `${t('catalogUpdated')} ${formatClock(catalog.updatedAt)}`),
      unmatched > 0
        ? h('div', { className: 'akc-note akc-catalogUnmatched' },
            `${t('catalogUnmatchedPrefix')} ${unmatched} ${t('catalogUnmatchedSuffix')}${sample.length > 0 ? ` (${t('catalogUnmatchedSample')} ${sample.join(', ')})` : ''}`)
        : null,
      h('div', { className: 'akc-list' }, models.map((model) => h('label', { className: 'akc-model', key: model.id },
        h('input', { type: 'checkbox', checked: checked(model.id), disabled, onChange: () => toggle(model.id) }),
        h(CatalogModel, { model, t, conflictFields: model.conflicts })))))
    }

    /** 一个账户的额度块：契约要求按账户分组，让人看清每个账户自己的池子。 */
    function UsageAccountBlock({ entry, t }) {
      // 报告来自线网：null 条目会让整块渲染失败（`window.percent` / `entry.accountId`
      // 直接炸），过滤掉比整页崩掉好。
      const windows = Array.isArray(entry.windows) ? entry.windows.filter(Boolean) : []
      return h('div', { className: 'akc-usageAccount', 'data-usage-account': entry.accountId },
        h('div', { className: 'akc-accountHead' },
          h('span', { className: 'akc-accountName' }, entry.label ?? entry.accountId),
          entry.source === 'aksk' ? h('span', { className: 'akc-pill' }, 'AK/SK') : null,
          typeof entry.tier === 'string' && entry.tier !== '' ? h('span', { className: 'akc-pill' }, entry.tier) : null,
          h('span', { className: `akc-pill ${entry.ok === true ? 'ok' : 'err'}` },
            entry.ok === true ? t('usageSourcePlan') : t('usageUnavailable'))),
        entry.ok === true
          ? windows.map((window) => {
              const percent = typeof window.percent === 'number' ? window.percent : 0
              const hasTotals = window.hasTotals === true && typeof window.used === 'number' && typeof window.total === 'number'
              return h(UsageWindow, {
                key: window.key ?? window.level ?? window.label,
                label: window.label ?? window.key ?? window.level,
                percent,
                valueText: hasTotals
                  ? `${formatPercent(percent)} · ${t('usageTotals')} ${humanTokens(window.used)} / ${humanTokens(window.total)}`
                  : formatPercent(percent),
                hint: window.resetAt === null || window.resetAt === undefined
                  ? undefined
                  : `${t('resetAt')} ${formatClock(window.resetAt)}`,
              })
            })
          : h('div', { className: 'akc-note warn' }, entry.error ?? t('usageUnavailable')))
    }

    /** 用量与显示：按账户的真实套餐额度、AK/SK、侧边栏卡片档位。 */
    function UsageCard({ controller, t }) {
      const state = useControllerState(controller)
      const draft = state.draft ?? {}
      const usage = state.usage
      const plan = usage?.plan
      const planOk = plan?.ok === true
      const busy = state.busy === true
      const disabled = !state.writable || busy
      const entries = Array.isArray(plan?.accounts) && plan.accounts.length > 0
        ? plan.accounts.filter(Boolean)
        : planOk && Array.isArray(plan?.windows)
          ? [{ accountId: '__best__', label: t('usageSourcePlan'), ok: true, windows: plan.windows.filter(Boolean) }]
          : []
      // Secret 引用：`??` 拦不住空串 —— 真机上清空「Secret 凭据引用」后拿到的是
      // `''`，点保存会走到 `credentials.set('', secret)`，凭据服务抛
      // `credential ref "" must match /^[A-Za-z_][A-Za-z0-9_]*$/`，而且 ref 显示
      // 与配置值静默分叉。空串并回默认引用，并照账户行的做法把这个输入禁掉。
      const secretRefRaw = typeof draft.secretAccessKeyEnv === 'string' ? draft.secretAccessKeyEnv.trim() : ''
      const secretRefMissing = secretRefRaw === '' && typeof draft.secretAccessKeyEnv === 'string'
      const secretRef = secretRefRaw === '' ? DEFAULT_SECRET_REF : secretRefRaw

      return h(Card, {
        title: t('usageSection'),
        extra: h('span', { className: 'akc-badge' },
          h('i', { className: `akc-dot ${planOk ? 'on' : 'off'}` }),
          planOk ? t('usageSourcePlan') : t('usageUnavailable')),
      },
      h('p', { className: 'akc-hint' }, t('usageHint')),

      planOk
        ? h('div', { style: { display: 'flex', flexDirection: 'column', gap: '10px' } },
            h('p', { className: 'akc-hint' }, t('usageAccountQuota')),
            ...entries.map((entry) => h(UsageAccountBlock, { key: entry.accountId, entry, t })))
        : h('div', { className: 'akc-note warn' }, plan?.error ?? t('usageUnavailable')),

      h('div', { className: 'akc-tools' },
        h('button', {
          type: 'button', className: 'akc-btn', disabled: state.usageLoading === true,
          onClick: () => void controller.refreshUsage(),
        }, state.usageLoading === true ? '…' : t('refreshNow')),
        usage === undefined ? null : h('span', { className: 'akc-hint' }, `${t('refreshedAt')} ${formatClock(usage.reportedAt)}`)),

      h(Row, { label: t('akId'), hint: t('akIdHint') },
        h('input', {
          className: 'akc-input akc-mono', value: draft.accessKeyId ?? '', disabled, spellCheck: false,
          'aria-label': t('akId'), placeholder: 'AKLT…',
          onChange: (event) => controller.editField('accessKeyId', event.target.value),
        })),
      h(Row, { label: t('skRef'), hint: t('skHint') },
        h('input', {
          className: 'akc-input akc-mono', value: draft.secretAccessKeyEnv ?? DEFAULT_SECRET_REF, disabled, spellCheck: false,
          'aria-label': t('skRef'),
          onChange: (event) => controller.editField('secretAccessKeyEnv', event.target.value),
        })),
      h(CredentialInput, {
        controller, t, refName: secretRef,
        configured: state.secret === true, disabled: disabled || secretRefMissing,
        placeholder: state.secret === true ? '••••••••' : t('accountKeyPlaceholder'),
      }),
      h(Row, { label: t('region') },
        h('input', {
          className: 'akc-input akc-mono', style: { flex: '0 0 200px' }, value: draft.region ?? 'cn-beijing',
          disabled, spellCheck: false, 'aria-label': t('region'),
          onChange: (event) => controller.editField('region', event.target.value),
        })),
      h(Row, { label: t('sidebarQuotaLabel'), hint: t('sidebarQuotaHint') },
        h('div', { className: 'akc-tools' },
          h('select', {
            className: 'akc-select', disabled, 'aria-label': t('sidebarQuotaLabel'),
            value: draft.sidebarQuota ?? 'auto',
            onChange: (event) => controller.editField('sidebarQuota', event.target.value),
          },
          h('option', { value: 'auto' }, t('sidebarQuotaAuto')),
          h('option', { value: 'on' }, t('sidebarQuotaOn')),
          h('option', { value: 'off' }, t('sidebarQuotaOff'))),
          h('span', { className: 'akc-hint' },
            (draft.sidebarQuota ?? 'auto') === 'auto'
              ? t('sidebarQuotaAutoHint')
              : `${t('sidebarQuotaEffective')}: ${usage?.sidebarQuota?.show === true ? t('sidebarQuotaOn') : t('sidebarQuotaOff')}`))),
      h(Row, { label: t('refreshSeconds') },
        h('input', {
          className: 'akc-input num', inputMode: 'numeric', value: draft.usageRefreshSeconds ?? '', disabled,
          'aria-label': t('refreshSeconds'),
          onChange: (event) => controller.editField('usageRefreshSeconds', event.target.value),
        })))
    }

    /** 高级：端点、超时、默认输出上限、逐模型上下文覆盖。 */
    function AdvancedCard({ controller, t }) {
      const state = useControllerState(controller)
      const draft = state.draft ?? {}
      const busy = state.busy === true
      const disabled = !state.writable || busy
      const overrides = draft.contextWindowOverrides && typeof draft.contextWindowOverrides === 'object' ? draft.contextWindowOverrides : {}
      const field = (key, label, hint, numeric) => h(Row, { label, hint },
        h('input', {
          className: `akc-input${numeric ? ' num' : ' akc-mono'}`, inputMode: numeric ? 'numeric' : undefined,
          value: draft[key] ?? '', disabled, spellCheck: false, 'aria-label': label,
          onChange: (event) => controller.editField(key, event.target.value),
        }))
      return h(Card, { title: t('advancedSection') },
        h('p', { className: 'akc-hint' }, t('advancedHint')),
        field('apiBase', t('apiBase'), DEFAULT_API_BASE, false),
        field('requestTimeoutMs', t('requestTimeout'), 'requestTimeoutMs', true),
        field('streamIdleTimeoutMs', t('streamIdleTimeout'), 'streamIdleTimeoutMs', true),
        field('defaultMaxTokens', t('defaultMaxTokens'), 'defaultMaxTokens', true),
        h('p', { className: 'akc-hint' }, t('contextOverrides')),
        h('p', { className: 'akc-hint' }, t('contextOverridesHint')),
        h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } },
          CATALOG.map((model) => h('div', { className: 'akc-override', key: model.id },
            h('span', { className: 'akc-overrideName' }, `${model.name} · ${humanTokens(model.ctx)}`),
            h('input', {
              className: 'akc-input num', inputMode: 'numeric', disabled,
              value: overrides[model.id] ?? '', placeholder: String(model.ctx),
              'aria-label': `${model.name} ${t('context')}`,
              onChange: (event) => {
                const text = event.target.value.trim()
                const next = { ...overrides }
                if (text === '') delete next[model.id]
                else {
                  const numeric = Number(text)
                  if (!Number.isFinite(numeric) || numeric < 1024) return
                  next[model.id] = Math.trunc(numeric)
                }
                controller.editField('contextWindowOverrides', next)
              },
            })))),
      )
    }

    /** 设置页。 */
    function ArkCodingSettingsPage(props) {
      const t = useTranslate(props)
      const controller = props.controller
      const state = useControllerState(controller)
      useEffect(() => { controller.refresh() }, [controller])
      return h('div', { className: 'akc-root' },
        h('div', { className: 'akc-head' }, h('h2', null, t('title')), h('p', null, t('subtitle'))),
        state.status === 'unavailable' ? h('div', { className: 'akc-note err' }, t('unavailable')) : null,
        state.status === 'error' ? h('div', { className: 'akc-note err' }, `${t('loadFailed')}: ${state.error ?? ''}`) : null,
        state.status === 'ready' && state.writable !== true ? h('div', { className: 'akc-note' }, t('readOnly')) : null,
        h(Note, { notice: state.notice, t }),
        h(AccountsCard, { controller, t }),
        h(ModelsCard, { controller, t }),
        h(UsageCard, { controller, t }),
        h(AdvancedCard, { controller, t }),
        state.dirty === true
          ? h('div', { className: 'akc-saveBar' },
              h('span', { className: 'akc-saveText' }, t('unsaved')),
              h('div', { className: 'akc-tools' },
                h('button', { type: 'button', className: 'akc-btn', disabled: state.busy === true, onClick: () => controller.discard() }, t('discard')),
                h('button', { type: 'button', className: 'akc-btn primary', disabled: state.busy === true, onClick: () => void controller.save() }, t('save'))))
          : null)
    }

    /**
     * Models 页那张提供商卡片里的扩展区。
     *
     * 这里**不再**放密钥输入框：顶层 `apiKeyEnv` / `apiKey` 已经退役（宿主不读也不写），
     * 往那个引用里写 key 只会写进一个没人看的凭据槽。账户才是唯一的配置入口，
     * 所以这张卡片改成只读的「账户现状」：用了哪个账户、额度从哪来、没配好该去哪。
     */
    function ArkCodingProviderCard(props) {
      const t = useTranslate(props)
      const controller = props.controller
      const state = useControllerState(controller)
      useEffect(() => { controller.refreshUsage() }, [controller])
      const report = state.usage
      const reportAccounts = Array.isArray(report?.accounts) ? report.accounts : []
      // 报告还没到手时，退回到设置文档里已有的账户数量（至少能区分"有账户"和"没账户"）。
      const total = reportAccounts.length > 0 ? reportAccounts.length : controller.accountRows().length
      const configured = reportAccounts.filter((entry) => entry?.configured === true)
      // 优先用宿主报告的 activeAccount；没设偏好就取第一个配置好的账户。
      const active = configured.find((entry) => entry?.id === report?.activeAccount) ?? configured[0]
      const planOk = report?.plan?.ok === true
      const sourceLabel = report?.plan?.source === 'aksk' ? 'AK/SK' : t('usageSourcePlan')
      return h('div', { style: { display: 'flex', flexDirection: 'column', gap: '10px', color: 'var(--dsw-alias-label-primary)', fontSize: '13px' } },
        h('div', { className: 'akc-badge', role: 'status' },
          h('i', { className: `akc-dot ${active === undefined ? 'off' : 'on'}` }),
          total === 0 ? t('providerNoAccounts')
            : active === undefined ? t('providerNoneConfigured') : t('providerReady')),
        total === 0
          ? h('p', { className: 'akc-hint' }, t('providerNoAccountsHint'))
          : active === undefined
            ? h('p', { className: 'akc-hint' }, t('providerNoneConfiguredHint'))
            : h('div', { className: 'akc-providerActive' },
                h('span', { className: 'akc-hint' }, `${t('providerUsing')}:`),
                h('span', { className: 'akc-accountName' }, active.label),
                h('span', { className: 'akc-pill' }, active.type === 'cli' ? t('typeCli') : t('typeApiKey')),
                planOk ? h('span', { className: 'akc-pill ok' }, `${t('providerQuotaSource')}: ${sourceLabel}`) : null),
        h(Note, { notice: state.notice, t }),
        h('p', { className: 'akc-hint' }, t('providerCardHint')))
    }

    /**
     * 一个额度窗口的稳定键。
     *
     * 两条来源给的形状不一样：arkcli 那条给 `key`（`session`/`weekly`/`monthly`，
     * 也可能带 `5h`/`week` 这种别名），AK/SK 那条给 `level`。归一到这里，
     * 卡片和详情面板才能用同一套判断。
     */
    function windowKeyOf(win) {
      const raw = String(win?.key ?? win?.level ?? win?.label ?? '').trim().toLowerCase()
      if (raw === 'session' || raw === '5h' || raw === 'fivehour') return 'session'
      if (raw === 'weekly' || raw === 'week') return 'weekly'
      if (raw === 'monthly' || raw === 'month') return 'monthly'
      return raw
    }

    /** 卡片上只显示这两档；月额度留给详情面板。 */
    const SIDEBAR_WINDOW_KEYS = ['session', 'weekly']

    /**
     * 左下角的用量卡片。
     *
     * 三条行为：
     * 1. **只显示 5 小时与本周**：日常需要盯的就是这两档，月额度在详情里看。
     * 2. **拿不到真实套餐额度就不渲染**（`undefined` 返回 null）：一张只写着
     *    "未配置"的常驻卡片没有信息量，还会让人以为哪里坏了。
     * 3. **点击展开详情**：各账户的登录情况 + 5 小时/周/月三档额度。面板用
     *    `position: fixed` 贴在卡片正上方 —— 侧边栏是 `overflow: hidden`，
     *    绝对定位会被裁掉；卡片的祖先链上没有 transform/filter，所以 fixed
     *    能安全地逃出裁剪（2026-10-16 在真页面上量过）。
     */
    function ArkCodingSidebarQuota(props) {
      const t = useTranslate(props)
      const controller = props.controller
      const state = useControllerState(controller)
      const [panel, setPanel] = useState(null)
      const anchor = useRef(null)
      const panelEl = useRef(null)
      const usage = state.usage
      const draft = state.draft ?? {}
      const plan = usage?.plan
      const planOk = plan?.ok === true
      const wide = props.wide !== false

      // 显示判据：报告还没到手时先看配置档位（显式 `on` 立刻显示），拿到报告后
      // 一律以宿主算出来的 `sidebarQuota.show` 为准 —— 那是唯一的真相源。
      const mode = usage?.sidebarQuota?.mode ?? draft.sidebarQuota ?? 'auto'
      const show = usage === undefined ? mode === 'on' : usage.sidebarQuota?.show === true

      // 打开时记下卡片位置，面板照着放。窗口尺寸变了就关掉，不追着改。
      const openPanel = () => {
        const el = anchor.current
        if (el !== null && el !== undefined && typeof el.getBoundingClientRect === 'function') {
          const rect = el.getBoundingClientRect()
          setPanel({
            left: Math.max(8, rect.left),
            bottom: Math.max(8, window.innerHeight - rect.top + 8),
            width: Math.round(Math.min(340, Math.max(272, rect.width))),
          })
        } else {
          setPanel({ left: 12, bottom: 96, width: 300 })
        }
      }

      useEffect(() => {
        if (panel === null) return () => {}
        const close = () => setPanel(null)
        const onKey = (event) => { if (event.key === 'Escape') close() }
        // 点面板外（但**不**包括卡片本身，否则"点卡片关闭"会和 onClick 打架）。
        const onDown = (event) => {
          if (panelEl.current?.contains?.(event.target) === true) return
          if (anchor.current?.contains?.(event.target) === true) return
          close()
        }
        window.addEventListener('keydown', onKey)
        window.addEventListener('resize', close)
        window.addEventListener('scroll', close, true)
        document.addEventListener('mousedown', onDown, true)
        // 打开就把焦点收进面板（它是 role="dialog"）：否则键盘用户按 Esc 之后
        // 焦点还停在卡片按钮上，Tab 顺序又从别处开始。
        try { panelEl.current?.focus?.() } catch { /* 焦点被策略拒绝时不影响打开 */ }
        return () => {
          window.removeEventListener('keydown', onKey)
          window.removeEventListener('resize', close)
          window.removeEventListener('scroll', close, true)
          document.removeEventListener('mousedown', onDown, true)
          // 关闭（Esc / 点外部 / 再点卡片）都把焦点还给卡片。必须**延到默认动作之后**：
          // 点外部时 mousedown 的默认动作会把焦点移到 body，同步 focus 会被它覆盖。
          const card = anchor.current
          if (card !== null && card !== undefined) {
            setTimeout(() => { try { card.focus?.() } catch { /* 同上 */ } }, 0)
          }
        }
      }, [panel])

      if (show !== true) return null

      const windows = planOk && Array.isArray(plan?.windows) ? plan.windows : []
      const rows = windows
        .filter((win) => SIDEBAR_WINDOW_KEYS.includes(windowKeyOf(win)))
        .map((win) => {
          const key = windowKeyOf(win)
          const percent = typeof win.percent === 'number' && Number.isFinite(win.percent) ? win.percent : 0
          return {
            key,
            label: key === 'session' ? t('usageWindow5h') : t('usageWindowWeekly'),
            percent,
            text: formatPercent(percent),
          }
        })
      const best = Array.isArray(plan?.accounts) ? plan.accounts.find((entry) => entry?.ok === true) : undefined
      const detailRows = [...windows].sort((left, right) => {
        const order = { session: 0, weekly: 1, monthly: 2 }
        return (order[windowKeyOf(left)] ?? 9) - (order[windowKeyOf(right)] ?? 9)
      })

      const card = h('button', {
        type: 'button', className: `akc-side${wide ? '' : ' narrow'}`, ref: anchor,
        title: `${t('sidebarOpenHint')} · ${t('refreshedAt')} ${usage === undefined ? '—' : formatClock(usage.reportedAt)}`,
        'aria-label': `${t('sidebarTitle')} — ${t('sidebarOpenHint')}`,
        'aria-expanded': panel !== null,
        onClick: () => { if (panel === null) openPanel(); else setPanel(null) },
      },
      // 收成 56px 轨道时只留一个百分比：标题和两个窗口塞不进去。
      wide
        ? h('div', { className: 'akc-sideHead' },
            h('span', null, t('sidebarTitle')),
            h('span', { className: `akc-pill ${planOk ? 'brand' : ''}` }, planOk ? t('usageSourcePlan') : t('sidebarUnavailable')))
        : null,
      rows.length === 0
        ? h('div', { className: 'akc-sideMeta' },
            state.usageError !== undefined ? t('usageFailed')
              : planOk ? t('sidebarLoading') : t('sidebarUnavailable'))
        : rows.map((row) => h(UsageWindow, {
            key: row.key, label: wide ? row.label : '', valueText: row.text,
            percent: row.percent,
          }))
      // 卡片到这里就完了：以前底部还有一行"账户额度 · 名字"，那行既不是额度也不是
      // 需要盯的数字（账户是谁，卡片上方和设置页都写着），只是白占一行高度。
      // 账户名仍然出现在详情面板和设置页里，只是不再挤在卡片上。
      )

      if (panel === null) return card

      const accountStates = Array.isArray(usage?.accounts) ? usage.accounts.filter(Boolean) : []
      const planAccounts = Array.isArray(plan?.accounts) ? plan.accounts : []
      const sourceLabel = plan?.source === 'aksk' ? t('sourceAksk') : t('sourceArkcli')

      // Fragment：卡片和面板一起返回，位置和层级都归我们自己管。
      return h(React.Fragment, null, card,
        h('div', {
          key: 'detail', ref: panelEl, className: 'akc-detail', role: 'dialog', tabIndex: -1,
          'aria-label': t('sidebarDetailTitle'),
          style: { left: `${panel.left}px`, bottom: `${panel.bottom}px`, width: `${panel.width}px` },
        },
        h('div', { className: 'akc-detailHead' },
          h('span', null, t('sidebarDetailTitle')),
          h('button', {
            type: 'button', className: 'akc-detailClose', 'aria-label': t('sidebarDetailClose'),
            onClick: () => setPanel(null),
          }, '✕')),

        h('div', { className: 'akc-detailSection' }, t('sidebarDetailLogin')),
        accountStates.length === 0
          ? h('p', { className: 'akc-hint' }, t('providerNoAccountsHint'))
          : accountStates.map((account) => {
              const planEntry = planAccounts.find((entry) => entry?.accountId === account?.id)
              const expiry = typeof account?.credentialExpiresAt === 'number' ? account.credentialExpiresAt : undefined
              const userId = account?.identity?.userId ?? account?.identity?.userName
              const status = account?.type === 'cli'
                ? (account?.loggedIn === true ? t('loggedInAs') : (account?.needsInstall === true ? t('cliMissing') : t('notLoggedIn')))
                : (account?.configured === true ? t('accountConfigured') : t('accountMissing'))
              return h('div', { className: 'akc-detailAccount', key: String(account?.id ?? account?.label) },
                h('div', { className: 'akc-detailAccountTop' },
                  h('span', { className: 'akc-accountName' }, account?.label ?? '—'),
                  h('span', { className: 'akc-pill' }, account?.type === 'cli' ? t('typeCli') : t('typeApiKey')),
                  planEntry?.ok === true ? h('span', { className: 'akc-pill brand' }, t('usageSourcePlan')) : null),
                h('div', { className: 'akc-sideMeta' },
                  `${status}${account?.type === 'cli' && account?.loggedIn === true && userId !== undefined ? ` · ${userId}` : ''}`),
                account?.type === 'cli' && expiry !== undefined
                  ? h('div', { className: `akc-sideMeta${expiry < Date.now() ? ' err' : ''}` },
                      `${t('credentialExpires')} ${formatDate(expiry)}`)
                  : null,
                typeof planEntry?.error === 'string' && planEntry.error !== '' && planEntry.ok !== true
                  ? h('div', { className: 'akc-sideMeta' }, planEntry.error)
                  : null)
            }),

        h('div', { className: 'akc-detailSection' }, t('sidebarDetailQuota')),
        planOk
          ? detailRows.map((win) => {
              const key = windowKeyOf(win)
              const percent = typeof win.percent === 'number' && Number.isFinite(win.percent) ? win.percent : 0
              const label = key === 'session' ? t('usageWindow5h')
                : key === 'weekly' ? t('usageWindowWeekly')
                  : key === 'monthly' ? t('usageWindowMonthly')
                    : String(win.label ?? key)
              const resetAt = typeof win.resetAt === 'number' ? win.resetAt : undefined
              return h(UsageWindow, {
                key: `${key}-${label}`, label, percent,
                valueText: formatPercent(percent),
                hint: resetAt === undefined ? undefined : `${t('resetAt')} ${formatClock(resetAt)}`,
              })
            })
          : h('p', { className: 'akc-hint' }, plan?.error ?? t('sidebarUnavailable')),
        planOk
          ? h('div', { className: 'akc-sideMeta' },
              `${t('sidebarDetailSource')}: ${sourceLabel}${best !== undefined && typeof best.label === 'string' ? ` · ${best.label}` : ''}`)
          : h('p', { className: 'akc-hint' }, t('sidebarDetailNoBindingHint')),

        h('div', { className: 'akc-detailFoot' },
          h('button', {
            type: 'button', className: 'akc-btn', disabled: state.usageLoading === true,
            onClick: () => void controller.refreshUsage(),
          }, state.usageLoading === true ? '…' : t('sidebarRefresh')),
          h('span', { className: 'akc-sideMeta' },
            `${t('refreshedAt')} ${usage === undefined ? '—' : formatClock(usage.reportedAt)}`))),
      )
    }

    // -----------------------------------------------------------------------
    // 客户端插件体
    // -----------------------------------------------------------------------

    function apply(ctx) {
      ctx.effect(() => injectCss(), 'dsh-ark-coding-provider: styles')
      ctx.effect(() => ctx.locale.register(LOCALE_NS, { zh: ZH, en: EN }), 'dsh-ark-coding-provider: page copy')

      const controller = createController()
      ctx.effect(() => () => controller.dispose(), 'dsh-ark-coding-provider: controller')

      // 失效通知：宿主改文档 / 改凭据时页面跟随。
      ctx.effect(() => {
        const remote = ctx.remote
        if (typeof remote?.$on !== 'function') return () => {}
        const off = remote.$on('settings/document-updated', () => controller.refresh())
        return () => { if (typeof off === 'function') off() }
      }, 'dsh-ark-coding-provider: settings invalidations')
      ctx.effect(() => {
        const remote = ctx.remote
        if (typeof remote?.$on !== 'function') return () => {}
        const off = remote.$on('credentials/reference-updated', () => { void controller.loadKey() })
        return () => { if (typeof off === 'function') off() }
      }, 'dsh-ark-coding-provider: credential invalidations')

      /**
       * 远端命名空间：**谁声明、谁读取**。
       *
       * 在一个只声明了 `remote.settings` 的上下文里读 `.credentials`，cordis 会抛
       * `cannot get property "credentials" without inject`；异常发生在注入回调内部，
       * 外层的 try/catch 抓不到，于是变量永远是 undefined、UI 静默降级。
       * 所以每次注入只碰自己那一个，并在回调内部再包一层。
       */
      const capture = (label, read, use) => {
        try {
          const namespace = read()
          if (namespace === undefined || namespace === null) {
            console.warn(`[dsh-ark-coding-provider] ${label} 命名空间为空`)
            return
          }
          use(namespace)
        } catch (error) {
          console.error(`[dsh-ark-coding-provider] 无法取得 ${label} 命名空间：`, error)
        }
      }
      try {
        ctx.inject(['remote.settings'], (settingsCtx) => {
          capture('remote.settings', () => settingsCtx.remote.settings, (ns) => controller.attachSettings(ns))
        })
      } catch (error) { console.error('[dsh-ark-coding-provider] 注入 remote.settings 失败：', error) }
      try {
        ctx.inject(['remote.credentials'], (credentialsCtx) => {
          capture('remote.credentials', () => credentialsCtx.remote.credentials, (ns) => controller.attachCredentials(ns))
        })
      } catch (error) { console.error('[dsh-ark-coding-provider] 注入 remote.credentials 失败：', error) }

      // 用量 Remote：先把自己的贡献挂上 Gateway，等命名空间出现再注入。
      // 贡献里现在带了全部 8 个端点（report/cliStatus/cliInstall/catalogRefresh/login*），
      // 但仍然是**同一个** namespace、**一次** mount —— 再挂一次会让 Gateway 报重复绑定。
      //
      // 卸载是异步的：`$mount` 对同一个 package 是**硬拒绝**（`already registered`），
      // 旧写法 `void unmount()` 后紧接着再 mount，一旦命中 `ctx.inject(['remote.arkcoding'])`
      // 就永远不执行，用量卡片一直消失到刷新。所以把上一次的 unmount 串成一条链，
      // 等它落地再挂；万一还是撞上（跨模块实例的残留注册）再试一次。
      let unmountChain = Promise.resolve()
      ctx.effect(() => {
        let cancelled = false
        let unmount
        const mount = unmountChain.then(async () => {
          if (cancelled) return
          let dispose
          for (let attempt = 0; attempt < 2 && dispose === undefined && cancelled !== true; attempt += 1) {
            if (attempt > 0) await new Promise((resolve) => setTimeout(resolve, 50))
            try {
              dispose = await ctx.remote.$mount(USAGE_CONTRIBUTION)
            } catch (error) {
              if (attempt === 1) console.error('[dsh-ark-coding-provider] 挂载用量 Remote 失败：', error)
            }
          }
          if (dispose === undefined) return
          if (cancelled) { try { await dispose() } catch { /* 尽力而为 */ } return }
          unmount = dispose
          ctx.inject(['remote.arkcoding'], (usageCtx) => {
            capture('remote.arkcoding', () => usageCtx.remote.arkcoding, (ns) => controller.attachUsage(ns))
          })
        }).catch((error) => {
          console.error('[dsh-ark-coding-provider] 用量 Remote 挂载流程失败：', error)
        })
        unmountChain = mount
        return () => {
          cancelled = true
          // 还没挂上时挂载流程自己会在挂上后立刻卸掉，等同一条链结束即可。
          if (unmount !== undefined) unmountChain = Promise.resolve().then(() => unmount()).catch(() => {})
        }
      }, 'dsh-ark-coding-provider: usage remote')

      // 用量轮询。
      //
      // 卡片**藏着的时候不能停轮询**：那多半是"还没绑定"，而绑定的那一刻正是
      // 卡片该自己冒出来的时刻 —— 停了就永远等不到。只是把节奏放慢到 5 分钟一档，
      // 别为一个看不见的卡片每分钟去打扰一次控制面。显式选了「始终隐藏」才真的停。
      ctx.effect(() => {
        let timer
        const tick = () => {
          const state = controller.store.get()
          const mode = state.usage?.sidebarQuota?.mode ?? state.draft?.sidebarQuota ?? 'auto'
          const seconds = Number(state.usage?.refreshSeconds ?? state.draft?.usageRefreshSeconds ?? 60)
          const every = Math.max(15, Number.isFinite(seconds) ? seconds : 60)
          if (mode === 'off') {
            timer = setTimeout(tick, 300 * 1000)
            return
          }
          // 卡片**看不见**的时候不按可见频率刷：每个 report() 都会为每个 CLI 账户起
          // 1–2 个 arkcli 子进程（登录态 + 额度），一个"有 CLI 账户但还没登录"的用户
          // 等于让一张看不见的卡片永久每 5 分钟拉两个 root 子进程。
          // 而"绑定后卡片自动出现"这条路径本来就自己走完了：设置页里的登录向导与保存
          // 结束时会 await refreshUsage()，卡片当场就冒出来。所以这里的轮询只是
          // "别的地方改了配置"的兜底，降到 30 分钟；一旦变可见就立刻按可见频率重排。
          const visible = state.usage?.sidebarQuota?.show === true
          void controller.refreshUsage().then(() => {
            if (!visible && controller.store.get().usage?.sidebarQuota?.show === true && timer !== undefined) {
              clearTimeout(timer)
              timer = setTimeout(tick, 1000)
            }
          })
          timer = setTimeout(tick, (visible ? every : 1800) * 1000)
        }
        timer = setTimeout(tick, 20_000)
        return () => clearTimeout(timer)
      }, 'dsh-ark-coding-provider: usage polling')

      // 设置页。
      try {
        ctx.slots.inject('settings.section', () => ctx.slots.register({
          name: 'settings.section', id: SECTION_ID, order: 13,
          label: () => localize(ctx, 'nav'), locale: LOCALE_NS,
          inject: () => ({ controller }),
        }, ArkCodingSettingsPage))
      } catch (error) { console.error('[dsh-ark-coding-provider] 注册设置页失败：', error) }

      // Models 页的提供商卡片。
      try {
        ctx.slots.inject('settings.models.provider-card', () => ctx.slots.register({
          name: 'settings.models.provider-card', key: CARD_KEY, locale: LOCALE_NS,
          inject: () => ({ controller }),
        }, ArkCodingProviderCard))
      } catch (error) { console.error('[dsh-ark-coding-provider] 注册提供商卡片失败：', error) }

      // 左下角的用量卡片。gate 在 layout 服务上：没有 layout 的客户端不注册，
      // 免得留一个点了没反应的死卡片。
      ctx.inject(['layout'], (layoutCtx) => {
        try {
          layoutCtx.slots.inject('sidebar.footer.action', () => layoutCtx.slots.register({
            // order 0 与官方 cordis-panel（默认 0）平局，相对顺序看注册时机；
            // 给一个明确的 1，用量卡片稳定排在它后面。
            name: 'sidebar.footer.action', id: SIDEBAR_ID, order: 1, locale: LOCALE_NS,
            inject: () => ({ controller }),
          }, ArkCodingSidebarQuota))
        } catch (error) { console.error('[dsh-ark-coding-provider] 注册侧边栏用量卡片失败：', error) }
      })
    }

    /** 读到当前语言下的一个文案；读不到时退回英文内置文案。 */
    function localize(ctx, key) {
      try {
        const bound = ctx.locale.bind(LOCALE_NS)(key)
        if (typeof bound === 'string' && bound !== '') return bound
      } catch { /* 语言服务还没就绪 */ }
      return EN[key] ?? key
    }

    return { apply, inject: ['slots', 'locale', 'remote'] }
  },
})
