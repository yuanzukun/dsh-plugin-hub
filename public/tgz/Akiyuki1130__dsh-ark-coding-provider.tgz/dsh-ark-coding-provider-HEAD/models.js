/**
 * 火山方舟（Volcengine Ark）Coding Plan 模型目录。
 *
 * 每一行的容量、模态与思考档位都来自实测（2026-10-15，对本机 key 直接调用
 * `https://ark.cn-beijing.volces.com/api/coding/v3/chat/completions`）与官方文档
 * （https://docs.volcengine.com/docs/ark/coding-plan-personal-plan-overview）的交叉验证；
 * 无法确认的字段一律取保守值并在 `note` 里写明，绝不猜测。
 *
 * 字段说明：
 * - `contextWindow`：上下文窗口（tokens）。Ark 别名模型与带日期的目录 id 共用同一容量。
 * - `maxOutput`：单次请求 `max_tokens` 的上限。实测方式是在阶梯值上探测服务端是否拒绝。
 * - `input`：DSH 只认识 `text` / `image` 两种模态。模型若支持视频/音频输入，这里只体现
 *   它同时接受图片；DSH 的模态声明必须保守，宁可不给也不能错给。
 * - `efforts`：实测被服务端接受的 `reasoning_effort` 取值。`off` 映射为 `none`。
 * - `visionNote`：图片能力的实测结论，方便排查。
 *
 * 实测要点（非猜测）：
 * - `glm-5.3` 明确拒绝图片（`Model only support text input`），且不支持关闭思考
 *   （`thinking.type disabled is not supported`），也不接受 `reasoning_effort: none/minimal`。
 * - `deepseek-v4-pro` 收图后回答"看不到图片"，判定为纯文本；`deepseek-v4-flash` 每次带图
 *   都在 3 分钟内无响应，同样按纯文本处理（宁可少给不可错给）。
 * - `minimax-m3` 第 1 轮工具调用正常，但它回传的 `tool_calls[].type` 是 `functionfunction`
 *   （服务端序列化缺陷）。适配器重建请求时强制写 `type: "function"`，多轮工具调用因此可用。
 */

/** 思考档位 id 到 wire 取值的映射。DSH 的 ReasoningEffortId 是不透明字符串。 */
export const EFFORT_WIRE = {
  off: 'none',
  minimal: 'minimal',
  low: 'low',
  medium: 'medium',
  high: 'high',
  max: 'max',
}

/** 档位显示名（中文环境与英文环境共用 id，展示交给语言包）。 */
const ALL_EFFORTS = [
  { id: 'off', name: 'off' },
  { id: 'minimal', name: 'minimal' },
  { id: 'low', name: 'low' },
  { id: 'medium', name: 'medium' },
  { id: 'high', name: 'high' },
  { id: 'max', name: 'max' },
]
const NO_OFF = ALL_EFFORTS.filter((e) => e.id !== 'off')

/**
 * 十二个 Coding Plan 模型。顺序 = 设置页与模型选择器的展示顺序：
 * 先把方舟自家 doubao 排在前面，再按第三方厂商分组。
 */
export const MODELS = [
  {
    id: 'doubao-seed-evolving',
    name: 'Doubao-Seed-Evolving',
    family: 'Doubao',
    contextWindow: 1048576,
    maxOutput: 262144,
    input: ['text', 'image'],
    efforts: ALL_EFFORTS,
    defaultEffort: 'medium',
    visionNote: '实测四象限配色全部答对',
  },
  {
    id: 'doubao-seed-2.1-pro',
    name: 'Doubao-Seed-2.1-pro',
    family: 'Doubao',
    contextWindow: 1048576,
    maxOutput: 262144,
    input: ['text', 'image'],
    efforts: ALL_EFFORTS,
    defaultEffort: 'medium',
    visionNote: '实测四象限配色全部答对',
  },
  {
    id: 'doubao-seed-2.1-lite',
    name: 'Doubao-Seed-2.1-lite',
    family: 'Doubao',
    contextWindow: 1048576,
    maxOutput: 262144,
    input: ['text', 'image'],
    efforts: ALL_EFFORTS,
    defaultEffort: 'medium',
    visionNote: '实测四象限配色全部答对',
  },
  {
    id: 'doubao-seed-2.0-mini',
    name: 'Doubao-Seed-2.0-mini',
    family: 'Doubao',
    contextWindow: 262144,
    maxOutput: 131072,
    input: ['text', 'image'],
    efforts: ALL_EFFORTS,
    defaultEffort: 'medium',
    visionNote: '实测四象限配色全部答对',
  },
  {
    id: 'minimax-m3',
    name: 'MiniMax-M3',
    family: 'MiniMax',
    contextWindow: 1048576,
    maxOutput: 131072,
    input: ['text', 'image'],
    efforts: ALL_EFFORTS,
    defaultEffort: 'medium',
    visionNote: '实测四象限配色全部答对；多轮工具调用需纠正 type 字段',
  },
  {
    id: 'glm-5.3',
    name: 'GLM-5.3',
    family: 'Zhipu',
    contextWindow: 1048576,
    maxOutput: 131072,
    input: ['text'],
    // 实测：thinking 无法关闭，`none`/`minimal` 被拒绝；接受 low/medium/high/max
    // （下面去掉 minimal 之后剩下的正好是这四档）。
    efforts: NO_OFF.filter((e) => e.id !== 'minimal'),
    defaultEffort: 'high',
    visionNote: '纯文本：明确回 "Model only support text input"',
  },
  {
    id: 'glm-5.3-flash',
    name: 'GLM-5.3-Flash',
    family: 'Zhipu',
    contextWindow: 1048576,
    maxOutput: 131072,
    input: ['text', 'image'],
    efforts: ALL_EFFORTS,
    defaultEffort: 'high',
    visionNote: '实测四象限配色全部答对（与 Ark /models 的 text-only 记录相反）',
  },
  {
    id: 'deepseek-v4.1-flash',
    name: 'DeepSeek-V4.1-Flash',
    family: 'DeepSeek',
    contextWindow: 1048576,
    maxOutput: 393216,
    input: ['text', 'image'],
    efforts: ALL_EFFORTS,
    defaultEffort: 'medium',
    visionNote: '实测四象限配色全部答对（官方 deepseek-flash 支持视觉）',
  },
  {
    id: 'deepseek-v4-flash',
    name: 'DeepSeek-V4-Flash',
    family: 'DeepSeek',
    contextWindow: 1048576,
    maxOutput: 393216,
    input: ['text'],
    efforts: ALL_EFFORTS,
    defaultEffort: 'medium',
    visionNote: '纯文本：带图请求三次均在 180s 内无响应，保守按不支持处理',
  },
  {
    id: 'deepseek-v4-pro',
    name: 'DeepSeek-V4-Pro',
    family: 'DeepSeek',
    contextWindow: 1048576,
    maxOutput: 393216,
    input: ['text'],
    efforts: ALL_EFFORTS,
    defaultEffort: 'medium',
    visionNote: '纯文本：收图后回答"看不到图片"',
  },
  {
    id: 'kimi-k2.8-preview',
    name: 'Kimi-K2.8-Preview',
    family: 'Moonshot',
    contextWindow: 1048576,
    maxOutput: 131072,
    input: ['text', 'image'],
    efforts: ALL_EFFORTS,
    defaultEffort: 'medium',
    visionNote: '实测四象限配色全部答对',
  },
  {
    id: 'kimi-k3',
    name: 'Kimi-K3',
    family: 'Moonshot',
    contextWindow: 1048576,
    maxOutput: 131072,
    input: ['text', 'image'],
    efforts: ALL_EFFORTS,
    defaultEffort: 'medium',
    visionNote: '实测四象限配色全部答对',
  },
]

/** 按 id 取一条目录记录。 */
export function modelById(id) {
  return MODELS.find((m) => m.id === id)
}

// ---------------------------------------------------------------------------
// 官方目录（arkcli `models search`）对照
// ---------------------------------------------------------------------------

/**
 * 为什么官方目录**只做对照、不做覆盖**。
 *
 * 上面的 12 行容量与模态是**直接打 Coding Plan 端点实测**出来的；而 arkcli
 * `models search` 返回的是方舟**通用目录**的元数据。两者不是同一份事实源：
 * 已知的真实分歧就有一个 —— 通用目录把 `glm-5.3-flash` 记成纯文本，而实测
 * 它收图并答对了四象限配色。拿通用目录去覆盖实测值，等于用较不可靠的来源
 * 推翻较可靠的来源。
 *
 * 所以这里把官方值挂在 `official` 上并列出 `conflicts`，由设置页并排展示。
 * 好处是：官方目录一旦更新（新增模型、改容量），用户马上能在界面上看到差异，
 * 而不是被插件里写死的快照蒙在鼓里。
 */

/** 把 id / 显示名归一成可比较的键：小写、非字母数字折叠成单个 `-`。 */
export function catalogKeyOf(text) {
  if (typeof text !== 'string') return ''
  return text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')
}

/** 把官方目录索引成 `键 → 条目`，同时按 id 与显示名建索引。 */
export function indexCatalog(items) {
  const map = new Map()
  if (!Array.isArray(items)) return map
  for (const item of items) {
    if (typeof item !== 'object' || item === null) continue
    const id = typeof item.id === 'string' ? item.id : (typeof item.name === 'string' ? item.name : '')
    if (id === '') continue
    for (const key of new Set([catalogKeyOf(id), catalogKeyOf(item.displayName)])) {
      if (key !== '' && !map.has(key)) map.set(key, item)
    }
  }
  return map
}

/** 官方条目里我们关心的那部分事实。 */
function officialOf(item) {
  if (item === undefined) return undefined
  const modalities = Array.isArray(item.inputModalities)
    ? item.inputModalities.filter((m) => m === 'text' || m === 'image')
    : []
  const thinking = item.capabilities !== undefined && item.capabilities !== null
    ? item.capabilities.thinking
    : undefined
  return {
    id: typeof item.id === 'string' ? item.id : '',
    displayName: typeof item.displayName === 'string' ? item.displayName : '',
    version: typeof item.version === 'string' ? item.version : '',
    contextWindow: Number.isFinite(item.contextWindow) ? item.contextWindow : undefined,
    maxInputTokens: Number.isFinite(item.maxInputTokens) ? item.maxInputTokens : undefined,
    maxOutputTokens: Number.isFinite(item.maxOutputTokens) ? item.maxOutputTokens : undefined,
    inputModalities: modalities,
    thinking: typeof thinking === 'boolean' ? thinking : undefined,
    lifecycleStatus: typeof item.lifecycleStatus === 'string' ? item.lifecycleStatus : '',
  }
}

/**
 * 把官方目录对照到内置模型上。
 *
 * 返回新的模型数组（不修改入参），每条可能多出：
 * - `official`：官方目录里对应条目的元数据，没匹配上就是 `undefined`。
 * - `conflicts`：官方值与实测值**不一致的字段名**列表（`contextWindow` /
 *   `maxOutput` / `input`）。空数组表示一致或无从比较。
 *
 * 另外回报 `unmatchedOfficial`：官方目录里存在、但不在这 12 行里的模型数 ——
 * 这是"官方又发新模型了"的信号，设置页据此提示用户。
 */
export function annotateModels(models, catalogItems, options = {}) {
  const index = indexCatalog(catalogItems)
  const used = new Set()
  const annotated = models.map((model) => {
    const item = index.get(catalogKeyOf(model.id)) ?? index.get(catalogKeyOf(model.name))
    const official = officialOf(item)
    const conflicts = []
    if (official !== undefined) {
      if (official.id !== '') used.add(catalogKeyOf(official.id))
      if (official.contextWindow !== undefined && Number.isFinite(model.contextWindow) && official.contextWindow !== model.contextWindow) {
        conflicts.push('contextWindow')
      }
      if (official.maxOutputTokens !== undefined && Number.isFinite(model.maxOutput) && official.maxOutputTokens !== model.maxOutput) {
        conflicts.push('maxOutput')
      }
      if (official.inputModalities.length > 0) {
        const mine = [...model.input].sort().join(',')
        const theirs = [...new Set(official.inputModalities)].sort().join(',')
        if (mine !== theirs) conflicts.push('input')
      }
    }
    return official === undefined ? model : { ...model, official, conflicts }
  })
  const unmatchedOfficial = []
  for (const [key, item] of index) {
    if (used.has(key)) continue
    const id = typeof item.id === 'string' ? item.id : ''
    if (id === '' || unmatchedOfficial.includes(id)) continue
    unmatchedOfficial.push(id)
  }
  return {
    models: annotated,
    matched: annotated.filter((m) => m.official !== undefined).length,
    conflicts: annotated.filter((m) => (m.conflicts ?? []).length > 0).map((m) => ({ id: m.id, fields: m.conflicts })),
    unmatchedOfficial: unmatchedOfficial.length,
    officialSample: unmatchedOfficial.slice(0, 8),
    updatedAt: options.updatedAt,
    source: options.source ?? 'arkcli',
  }
}
