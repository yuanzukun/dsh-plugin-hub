/**
 * 用量：**备选**的套餐额度来源（一对 AK/SK + Volcengine V4 签名）。
 *
 * 主路径是 arkcli（SSO 登录的账户自带 `usage plan`），这个模块是"有 AK/SK、
 * 但不想装 arkcli / 不想 SSO 登录"时的第二条路。
 *
 * ## 为什么不能只靠 `ark-` 订阅 key
 *
 * 火山方舟 Coding Plan 的 5 小时 / 每周 / 每月窗口**只存在于控制面**：
 * `GetCodingPlanUsage`（Service=ark，Version=2024-01-01）要求 Volcengine V4
 * HMAC-SHA256 签名，也就是一对 **AK/SK**。只用 `ark-...` 这个订阅 key 是查不到的
 * —— 2026-10-16 已实测：`/api/coding/v3` 下 usage/quota/subscription/limits/plan/
 * balance/account/me/billing 全部 404，聊天响应里也没有任何 `x-ratelimit-*` 头。
 *
 * 窗口的**重置时间**由控制面自己给（`ResetTimestamp`，秒），插件不推算：
 * 实测这个账号的 monthly 重置在 **15 日 23:59:59（UTC+8）**，不是自然月 1 号 ——
 * 那是套餐的订阅周期，不是日历月。所以页面只如实显示服务端给的那一刻。
 *
 * @module dsh-ark-coding-provider/usage
 */

import { createHash, createHmac } from 'node:crypto'

/** 查询 Coding Plan 额度的控制面动作。 */
export const CODING_PLAN_USAGE_ACTION = 'GetCodingPlanUsage'
export const CODING_PLAN_USAGE_VERSION = '2024-01-01'
/** 控制面主机与签名参数。 */
export const VOLC_HOST = 'open.volcengineapi.com'
export const VOLC_SERVICE = 'ark'
export const VOLC_DEFAULT_REGION = 'cn-beijing'

// ---------------------------------------------------------------------------
// Volcengine V4 签名
// ---------------------------------------------------------------------------

/** sha256 的十六进制摘要。 */
export function sha256Hex(input) {
  return createHash('sha256').update(input).digest('hex')
}

/** HMAC-SHA256。 */
export function hmacSha256(key, data) {
  return createHmac('sha256', key).update(data).digest()
}

/** `YYYYMMDDTHHMMSSZ`，签名要求的紧凑 ISO8601（UTC）。 */
export function amzDate(date) {
  return date.toISOString().replace(/[:-]|\.\d{3}/g, '')
}

/**
 * 构造一次 Volcengine V4 签名的请求头。
 *
 * 与 AWS SigV4 同构（Volcengine 沿用了这套）：
 * 签名头固定为 `content-type;host;x-content-sha256;x-date`，
 * credential scope 为 `<date>/<region>/<service>/request`。
 *
 * @param options - 方法、路径、查询串、正文、AK/SK、区域与时间。
 * @returns 可直接合并进 fetch 的请求头。
 */
export function volcengineSignedHeaders(options) {
  const {
    accessKeyId,
    secretAccessKey,
    region = VOLC_DEFAULT_REGION,
    service = VOLC_SERVICE,
    host = VOLC_HOST,
    method = 'POST',
    path = '/',
    query = '',
    body = '',
    contentType = 'application/json',
    date = new Date(),
  } = options

  const xDate = amzDate(date)
  const shortDate = xDate.slice(0, 8)
  const payloadHash = sha256Hex(body)

  const headers = {
    'content-type': contentType,
    host,
    'x-content-sha256': payloadHash,
    'x-date': xDate,
  }
  const signedHeaderNames = Object.keys(headers).sort()
  const canonicalHeaders = signedHeaderNames.map((name) => `${name}:${headers[name]}`).join('\n')
  const signedHeaders = signedHeaderNames.join(';')

  // 查询串必须按键名字典序排序后再拼接。
  const canonicalQuery = query === ''
    ? ''
    : query
      .split('&')
      .filter((part) => part !== '')
      .map((part) => {
        const index = part.indexOf('=')
        return index === -1 ? [part, ''] : [part.slice(0, index), part.slice(index + 1)]
      })
      .sort(([left], [right]) => (left < right ? -1 : left > right ? 1 : 0))
      .map(([key, value]) => `${key}=${value}`)
      .join('&')

  const canonicalRequest = [method, path, canonicalQuery, `${canonicalHeaders}\n`, signedHeaders, payloadHash].join('\n')
  const credentialScope = `${shortDate}/${region}/${service}/request`
  const stringToSign = ['HMAC-SHA256', xDate, credentialScope, sha256Hex(canonicalRequest)].join('\n')

  const kDate = hmacSha256(secretAccessKey, shortDate)
  const kRegion = hmacSha256(kDate, region)
  const kService = hmacSha256(kRegion, service)
  const kSigning = hmacSha256(kService, 'request')
  const signature = createHmac('sha256', kSigning).update(stringToSign).digest('hex')

  return {
    ...headers,
    authorization: `HMAC-SHA256 Credential=${accessKeyId}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`,
  }
}

// ---------------------------------------------------------------------------
// 套餐额度
// ---------------------------------------------------------------------------

/** 窗口级别 → 中文名。控制面返回的 Level 是 session/weekly/monthly。 */
export const WINDOW_LABELS = {
  session: '5 小时',
  fiveHour: '5 小时',
  weekly: '每周',
  monthly: '每月',
  daily: '每日',
}

/**
 * 解析 `GetCodingPlanUsage` 的应答。
 *
 * 形状（社区实现一致）：`Result.QuotaUsage[] = { Level, Percent, ResetTimestamp }`，
 * `ResetTimestamp` 是**秒**。Coding Plan 只给百分比，没有绝对用量。
 *
 * @param payload - 已解析的 JSON 应答。
 * @returns 归一化的窗口列表，或抛错说明应答不可识别。
 */
/** 时间戳是否落在能正常显示的范围里（秒或毫秒都算）。 */
function inUsableRange(value) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return false
  if (value <= 0) return false
  const ms = value > 1e12 ? value : value * 1000
  return ms <= 8.64e15
}

export function parseCodingPlanUsage(payload) {
  const result = payload?.Result ?? payload?.result
  if (result === undefined || result === null || typeof result !== 'object') {
    throw new Error('应答里没有 Result')
  }
  const rows = Array.isArray(result.QuotaUsage) ? result.QuotaUsage : Array.isArray(result.quotaUsage) ? result.quotaUsage : []
  const windows = []
  for (const row of rows) {
    if (typeof row !== 'object' || row === null) continue
    const level = typeof row.Level === 'string' ? row.Level : typeof row.level === 'string' ? row.level : undefined
    const percentRaw = typeof row.Percent === 'number' ? row.Percent : typeof row.percent === 'number' ? row.percent : undefined
    if (level === undefined || percentRaw === undefined) continue
    const resetRaw = typeof row.ResetTimestamp === 'number' ? row.ResetTimestamp
      : typeof row.resetTimestamp === 'number' ? row.resetTimestamp : undefined
    windows.push({
      level,
      label: WINDOW_LABELS[level] ?? level,
      percent: Math.max(0, Math.min(100, percentRaw)),
      // 秒 → 毫秒；缺省时给 null，页面自行处理。
      // 范围校验是必需的：负数会渲染成 1970-01-01，天文数字会渲染成 "Invalid Date"
      // —— 用户看到的是假日期，比"没有日期"更糟（`formatClock` 的 try/catch 拦不住
      // 这两种，它们根本不抛）。所以超出可用范围一律当"没有"。
      resetAt: inUsableRange(resetRaw) ? (resetRaw > 1e12 ? resetRaw : resetRaw * 1000) : null,
    })
  }
  const order = { session: 0, fiveHour: 0, daily: 1, weekly: 1, monthly: 2 }
  windows.sort((left, right) => (order[left.level] ?? 9) - (order[right.level] ?? 9))
  return {
    windows,
    status: typeof result.Status === 'string' ? result.Status : undefined,
    updatedAt: typeof result.UpdateTimestamp === 'number' ? result.UpdateTimestamp : Date.now(),
  }
}

/**
 * 查一次套餐额度。
 *
 * @param options - AK/SK、区域、超时与可选的 fetch。
 * @returns 归一化的额度；失败时抛错（调用方决定怎么降级）。
 */
export async function fetchCodingPlanUsage(options) {
  const {
    accessKeyId,
    secretAccessKey,
    region = VOLC_DEFAULT_REGION,
    timeoutMs = 15_000,
    fetchImpl = fetch,
    date = new Date(),
  } = options
  if (typeof accessKeyId !== 'string' || accessKeyId.trim() === '') throw new Error('缺少 AccessKey ID')
  if (typeof secretAccessKey !== 'string' || secretAccessKey.trim() === '') throw new Error('缺少 Secret AccessKey')

  const query = `Action=${CODING_PLAN_USAGE_ACTION}&Version=${CODING_PLAN_USAGE_VERSION}`
  const headers = volcengineSignedHeaders({
    accessKeyId: accessKeyId.trim(),
    secretAccessKey: secretAccessKey.trim(),
    region,
    query,
    body: '',
    date,
  })

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(new Error('usage timeout')), timeoutMs)
  let response
  try {
    response = await fetchImpl(`https://${VOLC_HOST}/?${query}`, {
      method: 'POST',
      headers: { ...headers, accept: 'application/json', 'user-agent': 'dsh-ark-coding-provider' },
      body: '',
      signal: controller.signal,
    })
  } finally {
    clearTimeout(timer)
  }
  const text = await response.text()
  let payload
  try {
    payload = JSON.parse(text)
  } catch {
    throw new Error(`控制面返回了非 JSON 应答（HTTP ${response.status}）`)
  }
  // Volcengine 的错误有两种外壳：`ResponseMetadata.Error` 与顶层 `Error`。
  const error = payload?.ResponseMetadata?.Error ?? payload?.Result?.Error ?? payload?.Error
  if (error !== undefined && error !== null) {
    const code = typeof error.Code === 'string' ? error.Code : ''
    const message = typeof error.Message === 'string' ? error.Message : ''
    if (code === 'NotLogin' || code === 'InvalidAccessKeyId' || code === 'SignatureDoesNotMatch' || /signature|access key/i.test(`${code} ${message}`)) {
      throw new Error(`AK/SK 被拒绝（${code || 'auth'}）：请确认这对 AccessKey 属于同一个火山账号，并且有 ark 的读权限。`)
    }
    throw new Error(`${code || '控制面错误'}：${message}`)
  }
  if (!response.ok) throw new Error(`控制面 HTTP ${response.status}`)
  return parseCodingPlanUsage(payload)
}
