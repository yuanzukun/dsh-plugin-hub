import { afterAll, beforeEach, describe, expect, it, vi } from 'vitest'
import { execFile } from 'node:child_process'
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { promisify } from 'node:util'
import { hashPackTarball, verifyAgainstRegistry } from '../lib/guards/registry-verify.js'
import { computePackageHash, refreshBaseline, setBaselineDirForTest } from '../lib/guards/content-baseline.js'
import { setCapabilitiesDirForTest } from '../lib/guard/version-diff.js'
import { setSummariesDirForTest } from '../lib/guard/scan-summaries.js'
import { installInternalPluginGuard } from '../lib/guards/internal-plugin.js'
import { setCatalogAutoRefresh } from '../lib/guards/official-catalog.js'
import { VetStatus } from '../lib/guard/status.js'
import type { VetConfig } from '../lib/config.js'

const execFileAsync = promisify(execFile)

const REPO_ROOT = join(import.meta.dirname, '..')
const OFFICIAL_PKG = join(REPO_ROOT, 'node_modules', '@deepseek-ai', 'vet-fixture')
const NAME = '@deepseek-ai/vet-fixture'
const VERSION = '9.9.9'

const cfg = (over: Partial<VetConfig> = {}): VetConfig => ({
  mode: 'report', autoScan: true,
  scannerTimeoutMs: 15_000,
  rules: {}, denyOn: 'critical', allowlist: [],
  runtimeGuard: 'off', runtimeIntervalMs: 2000, runtimeMemLimitMb: 2048,
  runtimeForkBurstN: 5, runtimeFdLimit: 512, runtimeGrowthMb: 256, runtimeGrowthWindowMs: 600_000,
  contentBaseline: true, acknowledgedPackageHashes: {},
  ...over,
})

class FakeCtx {
  handlers = new Map<string, Function[]>()
  baseUrl = REPO_ROOT
  logger = { info: () => {}, error: () => {}, warn: () => {}, debug: () => {} }
  on(event: string, handler: Function): void {
    const list = this.handlers.get(event) ?? []
    list.push(handler)
    this.handlers.set(event, list)
  }
}

/** 干净的官方命名空间夹具包（每次重建，清掉上个用例的 extra.js）。 */
function makePkg(): void {
  rmSync(OFFICIAL_PKG, { recursive: true, force: true })
  mkdirSync(OFFICIAL_PKG, { recursive: true })
  writeFileSync(join(OFFICIAL_PKG, 'package.json'), JSON.stringify({ name: NAME, version: VERSION, main: 'index.js' }))
  writeFileSync(join(OFFICIAL_PKG, 'index.js'), 'module.exports = { ok: true }\n')
}

/** npm 布局 tarball（package/ 前缀）——快照当前 OFFICIAL_PKG 内容。 */
async function makeTgz(): Promise<Buffer> {
  const stage = mkdtempSync(join(tmpdir(), 'vet-stage-'))
  const pkgDir = join(stage, 'package')
  mkdirSync(pkgDir, { recursive: true })
  for (const f of ['package.json', 'index.js', 'extra.js']) {
    const src = join(OFFICIAL_PKG, f)
    if (existsSync(src)) writeFileSync(join(pkgDir, f), readFileSync(src))
  }
  const out = join(stage, 'p.tgz')
  await execFileAsync('tar', ['-czf', out, '-C', stage, 'package'])
  const buf = readFileSync(out)
  rmSync(stage, { recursive: true, force: true })
  return buf
}

/** 预置陈旧基线（hash 全 0），确保与任何真实内容都不匹配。 */
function preloadStaleBaseline(): void {
  const dir = mkdtempSync(join(tmpdir(), 'vet-base-'))
  writeFileSync(join(dir, 'baseline.json'), JSON.stringify({
    records: { [`${NAME}@${VERSION}`]: { name: NAME, version: VERSION, hash: '0'.repeat(64), recordedAt: Date.now() } },
  }))
  setBaselineDirForTest(dir)
  refreshBaseline()
}

async function waitFor(status: VetStatus, kind: string): Promise<boolean> {
  for (let i = 0; i < 60; i++) {
    if (status.snapshot().alarms.some(a => a.kind === kind)) return true
    await new Promise(r => setTimeout(r, 50))
  }
  return status.snapshot().alarms.some(a => a.kind === kind)
}

describe('hashPackTarball（registry 对账的哈希管线）', () => {
  it('npm 布局 tarball 的哈希 == 对目录直接 computePackageHash；内容变化 → 哈希变化', async () => {
    makePkg()
    const tgz = await makeTgz()
    const h1 = await hashPackTarball(tgz)
    expect(h1).toBe(computePackageHash(OFFICIAL_PKG)?.hash ?? '')
    expect(await hashPackTarball(tgz)).toBe(h1)
    writeFileSync(join(OFFICIAL_PKG, 'index.js'), 'module.exports = { ok: false }\n')
    expect(await hashPackTarball(await makeTgz())).not.toBe(h1)
  })
})

describe('baseline-mismatch 定性（0.1.21：registry 对账 + 已声明补丁）', () => {
  // round-20 review（测试写穿真实环境）：scan 完成时 recordScanSummary/recordVersionScan
  // 无条件写盘——此前只隔离 baseline 目录，扫描夹具包会把记录写进真实 ~/.dsh/vet/
  // （用户环境出现过 @vet-test/*、@esm-test/pkg、@deepseek-ai/vet-fixture 残留）。
  // 与 plugin.test.ts 同纪律：capabilities/summaries 全部重定向 tmp。
  let sandbox: string
  beforeEach(() => {
    sandbox = mkdtempSync(join(tmpdir(), 'vet-reconcile-'))
    setBaselineDirForTest(join(sandbox, 'baseline'))
    setCapabilitiesDirForTest(join(sandbox, 'caps'))
    setSummariesDirForTest(join(sandbox, 'summaries'))
    // 0.3.5（M2）：夹具名 @deepseek-ai/vet-fixture 不在官方目录 → 观察路径会触发 registry
    // 自动核对；测试环境禁止真实出网，统一关闭（生产默认开，need 时才核对）。
    setCatalogAutoRefresh(false)
  })
  afterAll(() => {
    setBaselineDirForTest(undefined)
    setCapabilitiesDirForTest(undefined)
    setSummariesDirForTest(undefined)
    setCatalogAutoRefresh(true)
    rmSync(OFFICIAL_PKG, { recursive: true, force: true })
    if (sandbox !== undefined) rmSync(sandbox, { recursive: true, force: true })
    vi.unstubAllGlobals()
  })

  it('已登记补丁 → 豁免 + info baseline-patch-ack（0.3.13 降为观察档：不计 alarmCount/盾牌），无红警', async () => {
    makePkg()
    const realHash = computePackageHash(OFFICIAL_PKG)!.hash
    preloadStaleBaseline()
    const status = new VetStatus()
    const ctx = new FakeCtx()
    installInternalPluginGuard(ctx as never, cfg({
      acknowledgedPackageHashes: { [`${NAME}@${VERSION}`]: [realHash] },
    }), status)
    ctx.handlers.get('internal/plugin')![0]({ uid: 'f1', entry: { options: { name: NAME } } })
    const snap = status.snapshot()
    const kinds = snap.alarms.map(a => a.kind)
    expect(kinds).toContain('baseline-patch-ack')
    expect(kinds).not.toContain('baseline-mismatch')
    // 0.3.13（用户决策）：声明是用户自己的动作、状态已知且不可行动 → info 观察档
    expect(snap.alarms.find(a => a.kind === 'baseline-patch-ack')?.severity).toBe('info')
    expect(snap.alarms.filter(a => a.severity !== 'info').map(a => a.kind)).not.toContain('baseline-patch-ack')
  })

  it('已登记补丁：自动扫描路径不扫描（零产物噪音，比「产物降档」更彻底）——deny 同步路径下 lastScan 缺席即证明', async () => {
    makePkg()
    const realHash = computePackageHash(OFFICIAL_PKG)!.hash
    preloadStaleBaseline()
    const status = new VetStatus()
    const ctx = new FakeCtx()
    installInternalPluginGuard(ctx as never, cfg({
      mode: 'deny',
      acknowledgedPackageHashes: { [`${NAME}@${VERSION}`]: [realHash] },
    }), status)
    ctx.handlers.get('internal/plugin')![0]({ uid: 'f1b', entry: { options: { name: NAME } } })
    const snap = status.snapshot()
    expect(snap.alarms.map(a => a.kind)).toContain('baseline-patch-ack')
    // deny 走同步 scanSync：若真扫了，noteScan 会在 handler 返回前就位 → 缺席 = 未扫描。
    // 工具面（scan_plugin）是显式审计请求，照常扫描但对已登记 hash 按官方家族降噪。
    expect(snap.lastScan).toBeUndefined()
  })

  it('deny 模式未登记 → 黄牌（零网络；0.3.5 降黄不红——用户决策「哈希对不上也只是黄」），消息含登记指引', async () => {
    makePkg()
    preloadStaleBaseline()
    const status = new VetStatus()
    const ctx = new FakeCtx()
    installInternalPluginGuard(ctx as never, cfg({ mode: 'deny' }), status)
    ctx.handlers.get('internal/plugin')![0]({ uid: 'f2', entry: { options: { name: NAME } } })
    const red = status.snapshot().alarms.find(a => a.kind === 'baseline-mismatch')
    expect(red?.severity).toBe('yellow')
    expect(red?.message).toContain('acknowledged-package-hashes')
  })

  it('report 模式：本机字节 == registry → 基线刷新 + yellow，不记红', async () => {
    makePkg()
    preloadStaleBaseline()
    const tgz = await makeTgz()
    vi.stubGlobal('fetch', vi.fn(async (url: string | URL) => {
      const u = String(url)
      if (u.endsWith(`/${VERSION}`)) {
        const body = JSON.stringify({ dist: { tarball: 'https://registry.npmjs.org/x.tgz' } })
        return new Response(body, { status: 200, headers: { 'content-length': String(body.length) } })
      }
      return new Response(new Uint8Array(tgz), { status: 200, headers: { 'content-length': String(tgz.length) } })
    }))
    const status = new VetStatus()
    const ctx = new FakeCtx()
    installInternalPluginGuard(ctx as never, cfg(), status)
    ctx.handlers.get('internal/plugin')![0]({ uid: 'f3', entry: { options: { name: NAME } } })
    expect(await waitFor(status, 'baseline-refreshed')).toBe(true)
    const kinds = status.snapshot().alarms.map(a => a.kind)
    expect(kinds).not.toContain('baseline-mismatch')
  })

  it('report 模式：本机字节 != registry → 黄牌观察（0.3.5 降黄不红；措辞含 registry 不一致）', async () => {
    makePkg()
    const officialSnapshot = await makeTgz()   // registry 快照：不含随后的本机改动
    writeFileSync(join(OFFICIAL_PKG, 'extra.js'), '// local modification\n')
    preloadStaleBaseline()
    vi.stubGlobal('fetch', vi.fn(async (url: string | URL) => {
      const u = String(url)
      if (u.endsWith(`/${VERSION}`)) {
        const body = JSON.stringify({ dist: { tarball: 'https://registry.npmjs.org/x.tgz' } })
        return new Response(body, { status: 200, headers: { 'content-length': String(body.length) } })
      }
      return new Response(new Uint8Array(officialSnapshot), { status: 200, headers: { 'content-length': String(officialSnapshot.length) } })
    }))
    const status = new VetStatus()
    const ctx = new FakeCtx()
    installInternalPluginGuard(ctx as never, cfg(), status)
    ctx.handlers.get('internal/plugin')![0]({ uid: 'f4', entry: { options: { name: NAME } } })
    expect(await waitFor(status, 'baseline-mismatch')).toBe(true)
    const red = status.snapshot().alarms.find(a => a.kind === 'baseline-mismatch')
    expect(red?.severity).toBe('yellow')
    expect(red?.message).toContain('官方 registry')
  })
})
