import { beforeAll, afterAll, afterEach, describe, expect, it, vi } from 'vitest'
import { VetStatus } from '../lib/guard/status.js'
import { analyzeSample, detectGrowth, hostPpidChanged, type ProcSample, type RssSample, type WatchConfig } from '../lib/guard/runtime-watch.js'
import {
  classifyOp, isSensitivePath, isTransientTempPath, patchModule, pluginFromStack, setRootIndexing, extractNetworkTarget, DEFAULT_HOOK_CONFIG,
} from '../lib/guard/runtime-hooks.js'
import { isSessionLogFile } from '../lib/guard/runtime-hooks.js'
import { readHostMetrics } from '../lib/guard/metrics.js'
import { ensureHoneypot, DEFAULT_HONEYPOT_DIR } from '../lib/guard/honeypot.js'
import { registerStatusRouteOnce, writeRuntimeGuardConfig, writeVetTierConfig, readPatchRuntimeGuard, setGuardToggleHook } from '../lib/guard/status-route.js'
import { setCapabilitiesDirForTest } from '../lib/guard/version-diff.js'
import { recordScanSummary, setSummariesDirForTest } from '../lib/guard/scan-summaries.js'
import { decideRespawn, t2AlarmId, t2Severity, installRuntimeGuard, applyRuntimeGuardImmediate, disposeActiveGuard, isAttributableEntry, isSuppressUnattributedSessionLog, sidecarSupportedOn } from '../lib/guard/runtime-guard.js'
import { envSidecarPid } from '../lib/guard/runtime-sidecar.js'
import { hasAuditRecord, setArchiveDirForTest } from '../lib/audit/archive.js'
import { setDismissedFileForTest } from '../lib/guard/dismissed-alerts.js'
import { mkdirSync, mkdtempSync, rmSync, writeFileSync, readFileSync } from 'node:fs'
import fsDefault from 'node:fs'
import { join } from 'node:path'
import { homedir, tmpdir } from 'node:os'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import * as yaml from 'js-yaml'

const CFG: WatchConfig = { intervalMs: 2000, memLimitMb: 1024, forkBurstN: 5, fdLimit: 512, growthMb: 256, growthWindowMs: 600_000 }

// 0.2.1：dismiss/restore 会写持久化文件——测试必须隔离，避免污染用户真实的忽略记录
const TMP_DISMISS = join(tmpdir(), 'vet-test-dismiss-' + Date.now())
setDismissedFileForTest(TMP_DISMISS)

function sample(partial: Partial<ProcSample>): ProcSample {
  return { rssKb: 512 * 1024, childCount: 0, fdCount: 10, at: Date.now(), ...partial }
}

describe('VetStatus（盾牌聚合器）', () => {
  it('green 初始态', () => {
    const s = new VetStatus()
    const snap = s.snapshot()
    expect(snap.level).toBe('green')
    expect(snap.alarmCount).toBe(0)
  })

  it('yellow 报警 → yellow；同 id 窗口内去重', () => {
    const s = new VetStatus({ dedupeWindowMs: 60_000 })
    const alarm = { id: 't1:fd:512', severity: 'yellow' as const, source: 't1' as const, kind: 'fd', message: 'x', at: Date.now() }
    expect(s.record(alarm)).toBe('new')
    expect(s.record({ ...alarm, at: Date.now() + 1000 })).toBe('deduped')
    expect(s.snapshot().level).toBe('yellow')
    expect(s.snapshot().alarmCount).toBe(1)
  })

  it('red 报警压过 yellow → red', () => {
    const s = new VetStatus()
    s.record({ id: 'a', severity: 'yellow', source: 't2', kind: 'fs-write', message: 'y', at: Date.now() })
    s.record({ id: 'b', severity: 'red', source: 't1', kind: 'mem', message: 'r', at: Date.now() })
    expect(s.snapshot().level).toBe('red')
  })

  it('窗口外的同 id 重新报警（P2-4 replace 语义：旧副本被顶替，不占双槽）', () => {
    const s = new VetStatus({ dedupeWindowMs: 10 })
    const oldAt = Date.now() - 1000
    const alarm = { id: 't1:fd:512', severity: 'yellow' as const, source: 't1' as const, kind: 'fd', message: 'x', at: oldAt }
    expect(s.record(alarm)).toBe('new')
    // 窗口外同 id 重发：旧实现直接 push 新副本（持续报警 ~62s/次会占满 20 槽→alarmCount 虚高、
    // 其他报警被挤出）；修复后先移除旧副本再入列（replace 语义）
    expect(s.record({ ...alarm, at: Date.now() })).toBe('new')
    const snap = s.snapshot()
    expect(snap.alarmCount).toBe(1)
    expect(snap.alarms[0].at).not.toBe(oldAt) // 新记录顶替旧记录
  })

  it('alarmMax 环形截断', () => {
    const s = new VetStatus({ alarmMax: 3, dedupeWindowMs: 0 })
    for (let i = 0; i < 5; i++) {
      s.record({ id: `a${i}`, severity: 'yellow', source: 't2', kind: 'fs-write', message: `m${i}`, at: Date.now() + i })
    }
    expect(s.snapshot().alarmCount).toBe(3)
    expect(s.snapshot().alarms[0].id).toBe('a4')
  })

  it('noteScan suspicious → yellow 抬升', () => {
    const s = new VetStatus()
    expect(s.snapshot().level).toBe('green')
    s.noteScan({ pluginName: 'evil', verdict: 'suspicious', staticScore: 40, at: Date.now() })
    expect(s.snapshot().level).toBe('yellow')
    s.noteScan({ pluginName: 'good', verdict: 'clean', staticScore: 100, at: Date.now() })
    expect(s.snapshot().level).toBe('green')
  })

  it('P2-2：报警 TTL 过期后不再影响盾牌（误报不永久黄/红）', () => {
    // 500ms 前报警，TTL 100ms → 已过期：snapshot 里消失、level 回 green
    const s = new VetStatus({ alarmTtlMs: 100, dedupeWindowMs: 0 })
    s.record({ id: 'old-red', severity: 'red', source: 't1', kind: 'mem', message: 'x', at: Date.now() - 500 })
    expect(s.snapshot().level).toBe('green')
    expect(s.snapshot().alarmCount).toBe(0)
    // 新报警在 TTL 内 → 生效
    s.record({ id: 'fresh-red', severity: 'red', source: 't1', kind: 'mem', message: 'x', at: Date.now() })
    expect(s.snapshot().level).toBe('red')
    expect(s.snapshot().alarmCount).toBe(1)
  })

  it('忽略：dismissed 不计入 level 与 count；可恢复；记录保留', () => {
    const s = new VetStatus({ dedupeWindowMs: 0 })
    s.record({ id: 't1:fd:512', severity: 'yellow', source: 't1', kind: 'fd', message: 'x', at: Date.now() })
    s.record({ id: 't1:mem:2048', severity: 'red', source: 't1', kind: 'mem', message: 'y', at: Date.now() })
    expect(s.snapshot().level).toBe('red')
    // 忽略 red → 只剩 yellow
    s.dismiss('t1:mem:2048')
    let snap = s.snapshot()
    expect(snap.level).toBe('yellow')
    expect(snap.alarmCount).toBe(1)
    expect(snap.alarms.map(a => a.id)).toEqual(['t1:fd:512'])
    expect(snap.dismissed.map(a => a.id)).toEqual(['t1:mem:2048'])
    expect(s.isDismissed('t1:mem:2048')).toBe(true)
    // 全部忽略 → green（shield 不看被忽略的报警）
    s.dismiss('t1:fd:512')
    expect(s.snapshot().level).toBe('green')
    // 恢复 red → 它回来（fd 仍忽略）→ red，count 1
    s.restore('t1:mem:2048')
    snap = s.snapshot()
    expect(snap.level).toBe('red')
    expect(snap.alarmCount).toBe(1)
    expect(snap.alarms.map(a => a.id)).toEqual(['t1:mem:2048'])
    // 全部恢复 → count 2，dismissed 清空
    s.restore('t1:fd:512')
    snap = s.snapshot()
    expect(snap.alarmCount).toBe(2)
    expect(snap.dismissed).toHaveLength(0)
  })

  it('忽略状态持久化：记录过期后忽略仍保持（0.2.1：用户忽略后不再反复报警）', () => {
    const s = new VetStatus({ alarmTtlMs: 100, dedupeWindowMs: 0 })
    s.record({ id: 'a', severity: 'red', source: 't1', kind: 'mem', message: 'x', at: Date.now() - 500 })
    s.dismiss('a')
    expect(s.snapshot().alarms).toHaveLength(0) // 记录已 TTL 过期
    // 0.2.1：持久化忽略不随记录过期清除——用户忽略后跨 session 保持
    expect(s.isDismissed('a')).toBe(true)
    // 同 id 再触发 → 仍被忽略，不再重新可见
    s.record({ id: 'a', severity: 'red', source: 't1', kind: 'mem', message: 'x', at: Date.now() })
    expect(s.snapshot().alarmCount).toBe(0)
    expect(s.snapshot().level).toBe('green')
  })

  it('P3-2：lastScan 按 TTL 过期——一次 suspicious 不永久黄，过期回 green', () => {
    const s = new VetStatus({ alarmTtlMs: 100 })
    s.noteScan({ pluginName: 'evil', verdict: 'suspicious', staticScore: 40, at: Date.now() - 500 }) // 500ms 前（> TTL）
    expect(s.snapshot().level).toBe('green')
    expect(s.snapshot().lastScan).toBeUndefined()
    // 新鲜扫描 → yellow；clean 不抬升
    s.noteScan({ pluginName: 'e2', verdict: 'suspicious', staticScore: 40, at: Date.now() })
    expect(s.snapshot().level).toBe('yellow')
    s.noteScan({ pluginName: 'good', verdict: 'clean', staticScore: 100, at: Date.now() })
    expect(s.snapshot().level).toBe('green')
  })
})

describe('hasAuditRecord（档案门槛：M1 前缀 + P-1 版本精确）', () => {
  const d = mkdtempSync(join(tmpdir(), '.tmp-arch-'))
  const dir = join(d, 'audits')
  beforeAll(() => {
    mkdirSync(dir, { recursive: true })
    setArchiveDirForTest(dir)
  })
  afterAll(() => {
    setArchiveDirForTest(join(homedir(), '.dsh', 'vet', 'audits'))
    rmSync(d, { recursive: true, force: true })
  })
  it('M1：前缀伪造不命中——lodash-foo 档案 ≠ lodash 档案', () => {
    writeFileSync(join(dir, 'lodash-foo-1.0.0-20260815-120000.md'), '# x')
    expect(hasAuditRecord('lodash')).toBe(false)
    writeFileSync(join(dir, 'lodash-4.17.21-20260815-120000.md'), '# y')
    expect(hasAuditRecord('lodash')).toBe(true)
  })
  it('P-1：版本精确匹配——旧版本档案不放行新版本', () => {
    writeFileSync(join(dir, 'pkg-1.0.0-20260815-120000.md'), '# v1 档案')
    expect(hasAuditRecord('pkg', '1.0.0')).toBe(true)  // 同版本 → 通过
    expect(hasAuditRecord('pkg', '1.2.0')).toBe(false) // 升级 → 必须重新审计
  })
  it('P-1：不传版本（无法解析）→ 宽松匹配任意精确版本档案', () => {
    expect(hasAuditRecord('pkg')).toBe(true) // 存在 1.0.0 档案，宽松即过
    expect(hasAuditRecord('nope')).toBe(false)
  })
})

describe('decideRespawn / t2AlarmId（P0-2/P1-6 判定逻辑）', () => {
  it('P0-2：env 指向本哨兵 + 非 stopping + 未达上限 → respawn（旧实现恒 false 的死代码回归）', () => {
    expect(decideRespawn(42, 42, false, 0, 5)).toBe(true)
    expect(decideRespawn(42, 42, false, 4, 5)).toBe(true)
    // stopping → 不复活（off/卸载场景）
    expect(decideRespawn(42, 42, true, 0, 5)).toBe(false)
    // env 已清（undefined）或指向别的 pid → 不复活
    expect(decideRespawn(undefined, 42, false, 0, 5)).toBe(false)
    expect(decideRespawn(43, 42, false, 0, 5)).toBe(false)
    // 达上限 → 不复活
    expect(decideRespawn(42, 42, false, 5, 5)).toBe(false)
    // child pid 未定义（spawn 失败）→ 不复活
    expect(decideRespawn(undefined, undefined, false, 0, 5)).toBe(false)
  })

  it('P1-6：报警 id 拼 pluginHint——两插件同路径不同 id，不互吞', () => {
    const a = t2AlarmId('fs-read', '/home/u/.ssh/id_rsa', 'evil-a')
    const b = t2AlarmId('fs-read', '/home/u/.ssh/id_rsa', 'evil-b')
    expect(a).not.toBe(b)
    expect(t2AlarmId('fs-read', '/home/u/.ssh/id_rsa', 'evil-a'))
      .toBe(t2AlarmId('fs-read', '/home/u/.ssh/id_rsa', 'evil-a'))
    // 无归因时以 kind+target 为 id（与旧行为兼容）
    expect(t2AlarmId('fs-read', '/home/u/.ssh/id_rsa', undefined))
      .toBe('t2:fs-read:/home/u/.ssh/id_rsa:')
  })

  it('A9：归因映射排除 vet 自身（isAttributableEntry）——包装器帧不再把宿主报警栽给 vet', () => {
    expect(isAttributableEntry('@jieai/dsh-plugin-vet')).toBe(false)
    expect(isAttributableEntry('@deepseek-ai/dsh')).toBe(true)
    expect(isAttributableEntry('evil-plugin')).toBe(true)
    // 栈归因配合排除后的映射：首个非 vet 根命中 → 归因到真实调用方
    const roots = new Map([
      ['/app/node_modules/evil-plugin/lib', 'evil-plugin'],
    ])
    // 栈顶是 vet 包装器帧（不在映射里）→ 跳过 → 命中 evil-plugin
    const stack = 'Error\n    at wrapped (/app/node_modules/@jieai/dsh-plugin-vet/lib/guard/runtime-hooks.js:306:20)\n    at caller (/app/node_modules/evil-plugin/lib/index.js:10:5)'
    expect(pluginFromStack(stack, roots)).toBe('evil-plugin')
    // 全部帧都是 vet 自身 → 归因落空（无主），不栽赃
    const vetOnly = 'Error\n    at wrapped (/app/node_modules/@jieai/dsh-plugin-vet/lib/guard/runtime-hooks.js:306:20)'
    expect(pluginFromStack(vetOnly, roots)).toBeUndefined()
  })
})

describe('P0-6/round-19：sidecarSupportedOn 平台门（Linux + macOS 支持，其余跳过 T1）', () => {
  it('linux / darwin → true（Linux 走 /proc，macOS 走 ps/lsof）', () => {
    expect(sidecarSupportedOn('linux')).toBe(true)
    expect(sidecarSupportedOn('darwin')).toBe(true)
    expect(sidecarSupportedOn(process.platform)).toBe(process.platform === 'linux' || process.platform === 'darwin')
  })

  it('win32 / freebsd 等 → false（不拉哨兵，避免"首轮 exit→重拉×5"噪音）', () => {
    expect(sidecarSupportedOn('win32')).toBe(false)
    expect(sidecarSupportedOn('freebsd')).toBe(false)
    expect(sidecarSupportedOn('sunos')).toBe(false)
    expect(sidecarSupportedOn('openbsd')).toBe(false)
    expect(sidecarSupportedOn('aix')).toBe(false)
  })
})

describe('analyzeSample（T1 差分判定）', () => {
  it('内存超限 → red', () => {
    const alarms = analyzeSample(null, sample({ rssKb: 2048 * 1024 }), CFG)
    expect(alarms).toHaveLength(1)
    expect(alarms[0]).toMatchObject({ severity: 'red', kind: 'mem' })
  })

  it('fork 突增 → red（prev 为 null 不误报）', () => {
    expect(analyzeSample(null, sample({ childCount: 20 }), CFG)).toHaveLength(0)
    const alarms = analyzeSample(sample({ childCount: 1 }), sample({ childCount: 20 }), CFG)
    expect(alarms).toHaveLength(1)
    expect(alarms[0]).toMatchObject({ severity: 'red', kind: 'fork' })
  })

  it('fd 超限 → yellow', () => {
    const alarms = analyzeSample(null, sample({ fdCount: 600 }), CFG)
    expect(alarms).toHaveLength(1)
    expect(alarms[0]).toMatchObject({ severity: 'yellow', kind: 'fd' })
  })

  it('稳态无报警', () => {
    expect(analyzeSample(sample({}), sample({}), CFG)).toHaveLength(0)
  })
})

describe('round-16 S6：hostPpidChanged（宿主 PID 复用复检）', () => {
  it('本进程 ppid 未变 → false（不误杀）', () => {
    expect(hostPpidChanged(process.ppid)).toBe(false)
  })
  // round-19（mac CI 兼容）：true 分支依赖 /proc 真读——macOS/其他无 /proc 平台 hostPpidChanged
  // 恒走 catch→false（这正是它的受限环境契约），故该断言仅 Linux 有效；旧门 skipIf(win32) 是漏洞。
  it.skipIf(process.platform !== 'linux')('ppid 与快照不符 → true（宿主退出后哨兵被 init 收养——kill(0) 在 PID 复用下误判存活的对冲）', () => {
    // 传一个不可能等于当前 ppid 的期望值（快照语义：宿主死亡后本进程 ppid 必变）
    expect(hostPpidChanged(process.ppid + 1)).toBe(true)
  })
})

describe('detectGrowth（持续膨胀/疑似泄漏检测）', () => {
  const gcfg = { growthMb: 256, growthWindowMs: 600_000 }
  const s = (rssMb: number, at: number): RssSample => ({ rssKb: rssMb * 1024, at })

  it('窗口内净增长 < 阈值 → 不报警', () => {
    const samples = [s(200, 0), s(300, 300_000), s(400, 600_000)]
    const r = detectGrowth(samples, gcfg, 0)
    expect(r.alarms).toHaveLength(0)
    expect(r.multiples).toBe(0)
  })

  it('净增长越过 1 倍 → yellow growth，倍数更新', () => {
    const samples = [s(200, 0), s(300, 300_000), s(500, 600_000)]
    const r = detectGrowth(samples, gcfg, 0)
    expect(r.alarms).toHaveLength(1)
    expect(r.alarms[0]).toMatchObject({ severity: 'yellow', kind: 'growth' })
    expect(r.alarms[0].message).toContain('持续膨胀')
    expect(r.multiples).toBe(1)
  })

  it('同倍数不重复报警（去重）', () => {
    const r = detectGrowth([s(200, 0), s(500, 600_000)], gcfg, 1)
    expect(r.alarms).toHaveLength(0)
    expect(r.multiples).toBe(1)
  })

  it('回落归零重置倍数', () => {
    const r = detectGrowth([s(500, 0), s(200, 600_000)], gcfg, 2)
    expect(r.alarms).toHaveLength(0)
    expect(r.multiples).toBe(0)
  })

  it('窗口外的旧样本不参与（起点取窗口内）', () => {
    const samples = [s(900, 0), s(300, 200_000), s(600, 800_000)]
    const r = detectGrowth(samples, gcfg, 0)
    expect(r.multiples).toBe(1)
  })

  it('测量跨度未覆盖完整窗口 → 不报警（起窗初期的瞬时尖峰不是"持续膨胀"）', () => {
    // 实测误报形态：窗口 10 分钟，但采样只覆盖 20 秒就涨了 274MB → 不构成窗口级持续膨胀
    const samples = [s(500, 0), s(774, 20_000)]
    const r = detectGrowth(samples, gcfg, 0)
    expect(r.alarms).toHaveLength(0)
    expect(r.multiples).toBe(0)
  })

  it('稳态抖动（最老样本晚于 cutoff 几 ms）仍能检出真实持续膨胀——跨度容差 90%', () => {
    // 真实采样时间戳带抖动：跨度 599999ms（略小于 600000ms 窗口），净增长 300MB → 必须报警
    // （此前严格 span >= window 的写法会让 growth 永远不触发）
    const samples = [s(500, 101_001), s(530, 300_000), s(800, 701_000)]
    const r = detectGrowth(samples, gcfg, 0)
    expect(r.alarms).toHaveLength(1)
    expect(r.multiples).toBe(1)
  })
})

describe('isSensitivePath / classifyOp（T2 分类）', () => {
  it('敏感路径判定', () => {
    expect(isSensitivePath('/etc/passwd', DEFAULT_HOOK_CONFIG)).toBe(true)
    expect(isSensitivePath('/etc', DEFAULT_HOOK_CONFIG)).toBe(true)
    expect(isSensitivePath('/etcetera/foo', DEFAULT_HOOK_CONFIG)).toBe(false)
    expect(isSensitivePath('/home/user/.ssh/id_rsa', DEFAULT_HOOK_CONFIG)).toBe(true)
    expect(isSensitivePath('/home/user/.env.local', DEFAULT_HOOK_CONFIG)).toBe(true)
    expect(isSensitivePath('/home/user/project/src/index.ts', DEFAULT_HOOK_CONFIG)).toBe(false)
  })

  it('敏感路径删除 → red fs-destroy', () => {
    const alarm = classifyOp({ module: 'fs', op: 'rmSync', args: ['/etc/hosts'] }, DEFAULT_HOOK_CONFIG)
    expect(alarm).toMatchObject({ severity: 'red', kind: 'fs-destroy' })
  })

  it('atomic-write 协议锁（<file>.lock）的删/写豁免（盾牌实测误报）', () => {
    // DSH 写凭据用 dsh-atomic-write：wx 创建 <credentials>.lock（内容仅 PID），写完 finally rm 删锁——
    // 宿主每次保存凭据都触发 unlink(.lock) → fs-destroy red 无主误报（.dsh 敏感段命中）
    expect(classifyOp({ module: 'fs', op: 'unlink', args: ['/home/user/.dsh/.credentials.yaml.lock'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    expect(classifyOp({ module: 'fs', op: 'rmSync', args: ['/home/user/.dsh/.credentials.yaml.lock'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    // 锁文件的写入（wx 创建带 PID）也是协议操作 → 不再误报 fs-write
    expect(classifyOp({ module: 'fs', op: 'writeFile', args: ['/home/user/.dsh/.credentials.yaml.lock', '12345'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    // 精度不丢：凭据本体删除仍报 red fs-destroy，非 lock 敏感删除仍报
    expect(classifyOp({ module: 'fs', op: 'rmSync', args: ['/home/user/.dsh/.credentials.yaml'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ severity: 'red', kind: 'fs-destroy' })
    expect(classifyOp({ module: 'fs', op: 'rmSync', args: ['/home/user/.ssh/id_rsa'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ severity: 'red', kind: 'fs-destroy' })
  })

  it('敏感路径写入 → yellow fs-write', () => {
    const alarm = classifyOp({ module: 'fs', op: 'writeFile', args: ['/home/user/.npmrc', 'x'] }, DEFAULT_HOOK_CONFIG)
    expect(alarm).toMatchObject({ severity: 'yellow', kind: 'fs-write' })
  })

  it('敏感路径读取 → yellow fs-read', () => {
    const alarm = classifyOp({ module: 'fs', op: 'readFileSync', args: ['/home/user/.ssh/id_ed25519'] }, DEFAULT_HOOK_CONFIG)
    expect(alarm).toMatchObject({ severity: 'yellow', kind: 'fs-read' })
  })

  it('普通路径写入不报警', () => {
    expect(classifyOp({ module: 'fs', op: 'writeFile', args: ['/home/user/a.txt', 'x'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
  })

  it('库名含 token 子串不误报（js-tokens 回归）', () => {
    // 旧规则：sensitiveSegments 子串匹配把合法库名 js-tokens 当敏感词
    expect(isSensitivePath('/opt/node_modules/@deepseek-ai/dsh/node_modules/js-tokens/index.js', DEFAULT_HOOK_CONFIG)).toBe(false)
    expect(classifyOp({ module: 'fs', op: 'readFileSync', args: ['/opt/node_modules/@deepseek-ai/dsh/node_modules/js-tokens/index.js'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    // 沙箱清理临时文件（文件名带 js-tokens）也不该触发 fs-destroy
    expect(classifyOp({ module: 'fs', op: 'rmdir', args: ['/tmp/._probe-js-tokens.mjs.4152567.abc.tmpdir'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
  })

  it('凭据语义路径仍报警（精度不丢）', () => {
    expect(isSensitivePath('/app/secrets.prod.yaml', DEFAULT_HOOK_CONFIG)).toBe(true)
    expect(isSensitivePath('/home/u/creds/credentials.json', DEFAULT_HOOK_CONFIG)).toBe(true)
    expect(isSensitivePath('/home/u/server.key', DEFAULT_HOOK_CONFIG)).toBe(true)
    expect(isSensitivePath('/home/u/prod.env', DEFAULT_HOOK_CONFIG)).toBe(true)
    expect(isSensitivePath('/home/u/.aws/credentials', DEFAULT_HOOK_CONFIG)).toBe(true)
  })

  it('含 shell/下载关键词的子进程 → yellow spawn', () => {
    expect(classifyOp({ module: 'child_process', op: 'exec', args: ['curl http://x'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ severity: 'yellow', kind: 'spawn' })
    expect(classifyOp({ module: 'child_process', op: 'spawn', args: ['/bin/sh', ['-c', 'rm -rf /tmp/x']] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'spawn' })
    expect(classifyOp({ module: 'child_process', op: 'spawn', args: ['wget', ['https://x/y']] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'spawn' })
  })

  it('M7：readdir/stat 敏感路径侦察 → yellow fs-probe（凭据狩猎第一步可见）', () => {
    expect(classifyOp({ module: 'fs', op: 'readdirSync', args: ['/home/user/.ssh'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ severity: 'yellow', kind: 'fs-probe' })
    expect(classifyOp({ module: 'fs', op: 'statSync', args: ['/home/user/.env'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-probe' })
    expect(classifyOp({ module: 'fs', op: 'accessSync', args: ['/etc/passwd'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-probe' })
    // 普通目录/文件侦察不报
    expect(classifyOp({ module: 'fs', op: 'readdirSync', args: ['/home/user/project'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
  })

  it('A9：node_modules 包目录豁免——敏感词包名（dsh-credentials-local 等）不再误报 fs-probe', () => {
    // 用户实测报警：宿主模块解析 require.resolve 内部 realpathSync 包内 package.json。
    // 注：P2-6 后 ~/.dsh 整段敏感（配置根），这些豁免用例的 fixture 一律放非 .dsh 工作路径，
    // 只测「node_modules 段之后不参与敏感判定」这一 A9 属性（.dsh 段之前的判定见下方 companion）。
    const pkg = '/home/chen/work/profiles/node_modules/@deepseek-ai/dsh-credentials-local/package.json'
    expect(isSensitivePath(pkg, DEFAULT_HOOK_CONFIG, 'read')).toBe(false)
    expect(classifyOp({ module: 'fs', op: 'realpathSync', args: [pkg] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    expect(classifyOp({ module: 'fs', op: 'realpath', args: [pkg] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    expect(classifyOp({ module: 'fs', op: 'statSync', args: [pkg] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    // AWS SDK 凭据提供者全家桶（真实 12 个敏感词包名之一）
    expect(isSensitivePath('/home/chen/work/profiles/node_modules/@aws-sdk/credential-provider-env/package.json', DEFAULT_HOOK_CONFIG, 'read')).toBe(false)
    // 包内 .env 也不敏感（包文件是公开工件，凭据在用户/系统目录）
    expect(classifyOp({ module: 'fs', op: 'readFileSync', args: ['/home/chen/work/node_modules/foo/.env'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    // P2-6 companion：即使包名豁免，配置根 ~/.dsh 段之前的 .dsh 段照常敏感（readdirSync('~/.dsh') 侦察可见）
    expect(classifyOp({ module: 'fs', op: 'readdirSync', args: ['/home/chen/.dsh'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-probe' })
    expect(classifyOp({ module: 'fs', op: 'statSync', args: ['/home/chen/.dsh/profiles/foo/package.json'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-probe' })
    // mutate 下系统根前缀仍生效：删 /usr/lib/node_modules 下的文件照样报
    expect(isSensitivePath('/usr/lib/node_modules/foo/index.js', DEFAULT_HOOK_CONFIG, 'mutate')).toBe(true)
    // N7 族 4：node_modules 写入 → install-write（不再泛化为 fs-write）
    expect(classifyOp({ module: 'fs', op: 'writeFile', args: ['/usr/lib/node_modules/foo/index.js', 'x'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'install-write' })
    // 豁免只作用于 node_modules 段之后：~/.ssh/node_modules/x 仍命中 .ssh
    expect(isSensitivePath('/home/u/.ssh/node_modules/x', DEFAULT_HOOK_CONFIG, 'read')).toBe(true)
    expect(classifyOp({ module: 'fs', op: 'readdirSync', args: ['/home/u/.ssh/node_modules'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-probe' })
    // DSH 安装树豁免：~/.dsh/profiles/<name>/node_modules/** 是平台自己装的公开依赖树
    // 插件加载期 require.resolve 触发 realpathSync（electron/install.js 等）→ 不报警
    expect(isSensitivePath('/home/chenzheng/.dsh/profiles/web/node_modules/electron/install.js', DEFAULT_HOOK_CONFIG, 'read')).toBe(false)
    expect(isSensitivePath('/home/user/.dsh/profiles/web/node_modules/dsh-traffic-light/package.json', DEFAULT_HOOK_CONFIG, 'read')).toBe(false)
    // 顶层 hoisted 树（~/.dsh/profiles/node_modules，pnpm workspace 根布局，无 profile 名段）
    // 用户实测：DSH 重启重解析插件树时对顶层 @deepseek-ai/* 包 realpathSync(package.json)
    // 刷出 20 条 fs-probe 误报——旧豁免正则要求中间必有 profile 名段，顶层树不匹配。
    expect(isSensitivePath('/home/user/.dsh/profiles/node_modules/@deepseek-ai/dsh-agent-loop/package.json', DEFAULT_HOOK_CONFIG, 'read')).toBe(false)
    expect(classifyOp({ module: 'fs', op: 'realpathSync', args: ['/home/user/.dsh/profiles/node_modules/@deepseek-ai/dsh-agent-loop/package.json'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    expect(classifyOp({ module: 'fs', op: 'realpath', args: ['/home/user/.dsh/profiles/node_modules/@deepseek-ai/dsh-base/package.json'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    expect(classifyOp({ module: 'fs', op: 'statSync', args: ['/home/user/.dsh/profiles/node_modules/@deepseek-ai/dsh-client/package.json'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    // 0.1.19：.dsh 直接放 profile（无 profiles 层）也豁免——用户机实测 DSH 升级安装依赖
    // （@joplin/turndown-plugin-gfm、@mixmark-io/domino 等）时 realpathSync/readFileSync
    // 刷出 fs-probe/fs-read 误报。旧正则只豁免 profiles(?:/.+)? 布局
    expect(isSensitivePath('/home/chenzheng/.dsh/web/node_modules/@joplin/turndown-plugin-gfm/lib/turndown-plugin-gfm.cjs.js', DEFAULT_HOOK_CONFIG, 'read')).toBe(false)
    expect(isSensitivePath('/home/chenzheng/.dsh/web/node_modules/@mixmark-io/domino/lib/impl.js', DEFAULT_HOOK_CONFIG, 'read')).toBe(false)
    expect(classifyOp({ module: 'fs', op: 'realpathSync', args: ['/home/chenzheng/.dsh/web/node_modules/@joplin/turndown-plugin-gfm/lib/turndown-plugin-gfm.cjs.js'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    expect(classifyOp({ module: 'fs', op: 'readFileSync', args: ['/home/chenzheng/.dsh/web/node_modules/@mixmark-io/domino/lib/impl.js'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    // 顶层 .dsh/node_modules（hoisted 到 harness 根）同样豁免
    expect(isSensitivePath('/home/user/.dsh/node_modules/@deepseek-ai/dsh-base/package.json', DEFAULT_HOOK_CONFIG, 'read')).toBe(false)
    // 但 ~/.dsh/.credentials.yaml、~/.dsh/sessions/** 等真实凭据面仍正常报警
    expect(isSensitivePath('/home/user/.dsh/.credentials.yaml', DEFAULT_HOOK_CONFIG, 'read')).toBe(true)
    expect(isSensitivePath('/home/user/.dsh/sessions/abc/credentials', DEFAULT_HOOK_CONFIG, 'read')).toBe(true)
    // 顶层豁免不误伤：~/.ssh/node_modules/x 仍命中 .ssh（豁免只在 .dsh/profiles 段生效）
    expect(isSensitivePath('/home/u/.ssh/node_modules/x', DEFAULT_HOOK_CONFIG, 'read')).toBe(true)
  })

  it('round-17：~/.dsh/**/node_modules 豁免语义保持（顺序/尾斜杠边界）', () => {
    // /.dsh/ 段之后有 /node_modules/ 段 → 豁免（hoisted 顶层树）
    expect(isSensitivePath('/home/u/.dsh/.npm-cache/node_modules/x/y.js', DEFAULT_HOOK_CONFIG, 'read')).toBe(false)
    // 顺序反了（node_modules 在 .dsh 之前）→ 不豁免；.ssh 敏感段照报
    expect(isSensitivePath('/home/u/.ssh/node_modules/y/.dsh/x', DEFAULT_HOOK_CONFIG, 'read')).toBe(true)
    // rmdir node_modules 本体（无尾斜杠）不在豁免内——与旧正则一致
    expect(isSensitivePath('/home/u/.dsh/node_modules', DEFAULT_HOOK_CONFIG)).toBe(true)
  })

  it('isSessionLogFile: 识别会话日志文件（用于轮换误报降噪）', () => {
    expect(isSessionLogFile('/home/user/.dsh/sessions/abc/session.jsonl.zst')).toBe(true)
    expect(isSessionLogFile('/home/user/.dsh/sessions/abc/session.jsonl.zstd')).toBe(true)
    expect(isSessionLogFile('/home/user/.dsh/sessions/abc/session.jsonl')).toBe(true)
    expect(isSessionLogFile('/home/user/.dsh/sessions/abc/session.log')).toBe(true)
    expect(isSessionLogFile('/home/user/.dsh/sessions/abc/session.jsonl.tmp')).toBe(true)
    // 分片会话文件（DSH 轮换产生的 .zstd.<shard> 等后缀）也应识别，否则丢失降噪标志
    expect(isSessionLogFile('/home/user/.dsh/sessions/abc/session.jsonl.zstd.9a3')).toBe(true)
    expect(isSessionLogFile('/home/user/.dsh/sessions/abc/session.jsonl.zst.001')).toBe(true)
    // 非会话目录下的日志文件不算
    expect(isSessionLogFile('/home/user/.dsh/profiles/web/session.jsonl.zst')).toBe(false)
    expect(isSessionLogFile('/tmp/session.jsonl.zst')).toBe(false)
    // round-17（去嵌套量词重写后的语义保持）：非字母数字分片不命中（.2026-01 带连字符）
    expect(isSessionLogFile('/home/user/.dsh/sessions/abc/session.log.2026-01')).toBe(false)
    expect(isSessionLogFile('/home/user/.dsh/sessions/abc/a.jsonl.9a3')).toBe(true)
    // 会话目录下的非日志文件不算
    expect(isSessionLogFile('/home/user/.dsh/sessions/abc/credentials')).toBe(false)
    expect(isSessionLogFile('/home/user/.dsh/sessions/abc/config.json')).toBe(false)
  })

  it('fs-destroy: 会话日志文件删除设置 sessionLog 标志（归因分层用）', () => {
    // 会话日志文件删除应该设置 sessionLog: true
    const alarm1 = classifyOp({
      module: 'fs', op: 'unlink', args: ['/home/user/.dsh/sessions/abc/session.jsonl.zst']
    }, DEFAULT_HOOK_CONFIG)
    expect(alarm1).not.toBeNull()
    expect(alarm1!.kind).toBe('fs-destroy')
    expect(alarm1!.severity).toBe('red')
    expect(alarm1!.sessionLog).toBe(true)
    expect(alarm1!.message).toBe('敏感路径删除：unlink(/home/user/.dsh/sessions/abc/session.jsonl.zst)')
    
    // 非会话日志的敏感文件删除 sessionLog 为 undefined
    const alarm2 = classifyOp({
      module: 'fs', op: 'unlink', args: ['/home/user/.ssh/id_rsa']
    }, DEFAULT_HOOK_CONFIG)
    expect(alarm2).not.toBeNull()
    expect(alarm2!.kind).toBe('fs-destroy')
    expect(alarm2!.sessionLog).toBeUndefined()
  })

  it('t2Severity: 未归因会话日志删除 red→yellow；归因插件/非会话日志保持 red', () => {
    const base = { severity: 'red' as const, kind: 'fs-destroy' as const, message: 'x', target: '/home/user/.dsh/sessions/abc/session.jsonl.zstd.9a3' }
    // 未归因（宿主自身运维，不会攻击自己）→ 降为 yellow
    expect(t2Severity({ ...base, sessionLog: true }, undefined)).toBe('yellow')
    // 归因到插件（可能销毁证据）→ 仍 red
    expect(t2Severity({ ...base, sessionLog: true }, 'some-plugin')).toBe('red')
    // 非会话日志的敏感删除（如 .ssh/id_rsa）未归因 → 仍 red
    expect(t2Severity({ ...base, sessionLog: undefined }, undefined)).toBe('red')
    // 其它 kind 原样透传（不受会话日志规则影响）
    expect(t2Severity({ ...base, kind: 'fs-write', severity: 'yellow' as const }, undefined)).toBe('yellow')
  })

  it('isSuppressUnattributedSessionLog: 无主会话日志删除静默（0.1.19 刷屏修复）', () => {
    // DSH 宿主压缩/轮转会话日志（zstd 删分片）→ 无归因 → 静默，不刷屏
    expect(isSuppressUnattributedSessionLog('fs-destroy', true, undefined)).toBe(true)
    // 归因到插件 → 不静默（销毁证据嫌疑，照报）
    expect(isSuppressUnattributedSessionLog('fs-destroy', true, 'some-plugin')).toBe(false)
    // 非会话日志敏感删除 → 不静默（如删 .credentials.yaml 本体）
    expect(isSuppressUnattributedSessionLog('fs-destroy', undefined, undefined)).toBe(false)
    // 其他类型报警不受影响
    expect(isSuppressUnattributedSessionLog('fs-write', true, undefined)).toBe(false)
    expect(isSuppressUnattributedSessionLog('spawn', true, undefined)).toBe(false)
  })

  it('A9 集成：包装器在线上报的 realpathSync 场景不再产生任何报警（端到端复刻）', () => {
    const tmp = mkdtempSync(join(tmpdir(), '.tmp-a9-'))
    const pkgDir = join(tmp, 'node_modules', '@deepseek-ai', 'dsh-credentials-local')
    mkdirSync(pkgDir, { recursive: true })
    mkdirSync(join(tmp, '.ssh'), { recursive: true })
    writeFileSync(join(pkgDir, 'package.json'), '{}')
    const alarms: HookAlarm[] = []
    // 生产 rootIndex：归因映射不含 vet 根（isAttributableEntry 已排除）
    const dispose = patchModule(fsDefault as unknown as Record<string, unknown>, 'fs', DEFAULT_HOOK_CONFIG, a => alarms.push(a), () => new Map([['/app/node_modules/evil/lib', 'evil-plugin']]))
    try {
      // 宿主模块解析链：realpathSync 包内 package.json（属性访问触发包装器，同线上）
      fsDefault.realpathSync(join(pkgDir, 'package.json'))
      fsDefault.statSync(join(pkgDir, 'package.json'))
      expect(alarms).toHaveLength(0)
      // 对照：真敏感路径（不在 node_modules 下）照常报警——豁免没有吞掉探测能力
      fsDefault.writeFileSync(join(tmp, '.ssh', 'probe'), 'x')
      expect(alarms).toHaveLength(1)
      expect(alarms[0].kind).toBe('fs-write')
    } finally {
      dispose()
      rmSync(tmp, { recursive: true, force: true })
    }
  })

  it('常规子进程（git/node/pnpm）不报警', () => {
    expect(classifyOp({ module: 'child_process', op: 'spawn', args: ['git', ['status']] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    expect(classifyOp({ module: 'child_process', op: 'execFile', args: ['node', ['server.js']] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    expect(classifyOp({ module: 'child_process', op: 'exec', args: ['npm run build'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
  })

  it('读取系统根下普通文件不报警；写删仍报（read/mutate 分档）', () => {
    expect(isSensitivePath('/usr/lib/node_modules/foo/index.js', DEFAULT_HOOK_CONFIG, 'read')).toBe(false)
    expect(classifyOp({ module: 'fs', op: 'readFileSync', args: ['/usr/lib/node_modules/foo/index.js'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    expect(isSensitivePath('/usr/lib/node_modules/foo/index.js', DEFAULT_HOOK_CONFIG, 'mutate')).toBe(true)
    // N7 族 4：node_modules 包文件写入是供应链/安装态篡改信号（kind 更具体，仍是黄）
    expect(classifyOp({ module: 'fs', op: 'writeFile', args: ['/usr/lib/node_modules/foo/index.js', 'x'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'install-write' })
    // /etc/passwd 由精确段名覆盖，读取仍报（枚举目标不漏）
    expect(classifyOp({ module: 'fs', op: 'readFileSync', args: ['/etc/passwd'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-read' })
    // 新增敏感名：.netrc / .pgpass / .gitconfig
    expect(isSensitivePath('/home/u/.netrc', DEFAULT_HOOK_CONFIG)).toBe(true)
    expect(isSensitivePath('/home/u/.pgpass', DEFAULT_HOOK_CONFIG)).toBe(true)
    expect(isSensitivePath('/home/u/.gitconfig', DEFAULT_HOOK_CONFIG)).toBe(true)
  })

  it('工具链临时产物豁免：tsc <源名>.<pid>.<uuid>.tmpdir 里的 secrets 是源文件名不是密钥文件', () => {
    const tmp = '/home/u/project/scanner-bin/rules/.secrets.ts.165387.14e663d0-bab4-4539-92de-22a80a17fd7d.tmpdir'
    expect(isTransientTempPath(tmp)).toBe(true)
    expect(isTransientTempPath('/home/u/x/report.tmp')).toBe(true)
    expect(isTransientTempPath('/home/u/x/file.ts')).toBe(false)
    expect(isSensitivePath(tmp, DEFAULT_HOOK_CONFIG)).toBe(false)
    // classifyOp 层面：rmdir 该临时目录 → 不报警（此前误报为 fs-destroy red）
    expect(classifyOp({ module: 'fs', op: 'rmdir', args: [tmp] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    // 父段仍敏感：~/.ssh/config.bak 命中 .ssh（临时后缀只豁免末段）
    expect(isSensitivePath('/home/u/.ssh/config.bak', DEFAULT_HOOK_CONFIG)).toBe(true)
    // .env 系临时文件仍敏感（.env. 前缀判定先于临时豁免）
    expect(isSensitivePath('/home/u/.env.tmp', DEFAULT_HOOK_CONFIG)).toBe(true)
    // 系统根内的临时文件仍算 mutate 敏感（写删 /usr 下的临时文件照样报）
    expect(isSensitivePath('/usr/lib/foo.tmp', DEFAULT_HOOK_CONFIG)).toBe(true)
    // 真实密钥名（不带临时后缀）不受影响
    expect(isSensitivePath('/home/u/.ssh/id_rsa', DEFAULT_HOOK_CONFIG)).toBe(true)
  })

  it('对象参数取 path', () => {
    const alarm = classifyOp({ module: 'fs', op: 'rm', args: [{ path: '/etc/passwd', recursive: true }] }, DEFAULT_HOOK_CONFIG)
    expect(alarm).toMatchObject({ severity: 'red' })
  })

  it('createWriteStream 写敏感路径 → yellow（D29 补漏：流式写入此前漏报；授权密钥属 N7 族 3）', () => {
    expect(classifyOp({ module: 'fs', op: 'createWriteStream', args: ['/home/user/.ssh/authorized_keys'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ severity: 'yellow', kind: 'persistence-write' })
    expect(classifyOp({ module: 'fs', op: 'createWriteStream', args: ['/home/user/log.txt'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
  })

  it('open 带写 flags → fs-write；只读 flags → fs-read（D29 补漏）', () => {
    expect(classifyOp({ module: 'fs', op: 'open', args: ['/etc/hosts', 'w'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-write' })
    expect(classifyOp({ module: 'fs', op: 'openSync', args: ['/home/u/.env', 'a+'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-write' })
    expect(classifyOp({ module: 'fs', op: 'open', args: ['/etc/passwd', 'r'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-read' })
  })

  it('P1-7：open 首参路径以 r/w/a 开头不再误当 flags（open auth.txt 只读）', () => {
    // 旧实现 args.find(/^[rwa]/) 命中 'auth.txt'（a 开头）→ 误报 fs-write；现在 flags 只认短形态
    expect(classifyOp({ module: 'fs', op: 'open', args: ['auth.txt', 'r'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-read' })
    expect(classifyOp({ module: 'fs', op: 'open', args: ['auth.txt', 'r'] }, DEFAULT_HOOK_CONFIG)).not.toMatchObject({ kind: 'fs-write' })
    // 路径含 w 开头且只读 → 也不误报写
    expect(classifyOp({ module: 'fs', op: 'open', args: ['writable.txt', 'r'] }, DEFAULT_HOOK_CONFIG)).not.toMatchObject({ kind: 'fs-write' })
    // 真正的写 flags 仍报
    expect(classifyOp({ module: 'fs', op: 'open', args: ['auth.txt', 'w'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-write' })
    // 长字符串（如模式串）不算 flags
    expect(classifyOp({ module: 'fs', op: 'open', args: ['/home/u/.env', 'w'], }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-write' })
  })

  it('#17 open 复合写 flags（wx+/ax+/as+）→ fs-write；rs 只读仍 fs-read', () => {
    expect(classifyOp({ module: 'fs', op: 'open', args: ['/etc/passwd', 'wx+'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-write' })
    expect(classifyOp({ module: 'fs', op: 'openSync', args: ['/home/u/.env', 'ax+'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-write' })
    expect(classifyOp({ module: 'fs', op: 'open', args: ['/home/u/.env', 'as+'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-write' })
    // rs 只读同步：不含写意图 → 仍按读报
    expect(classifyOp({ module: 'fs', op: 'open', args: ['/etc/passwd', 'rs'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-read' })
  })

  it('#4 fetch(new Request(url, init)) 目标回到观测面（此前 Request 实例全 miss → 网络出口盲点）', () => {
    const req = new Request('https://evil.example:8443/data?q=1')
    expect(extractNetworkTarget([req])).toEqual({ hostname: 'evil.example', port: 8443, path: '/data?q=1' })
    // duck-type（旧 Node 无全局 Request 时等价构造）
    expect(extractNetworkTarget([{ url: 'https://secret.evil/x' } as never])).toEqual({ hostname: 'secret.evil', port: undefined, path: '/x' })
    // 非 Request 的 options 对象不受影响（host/port 形态仍按原名判定）
    expect(extractNetworkTarget([{ hostname: 'api.github.com', port: 443, path: '/v1' }])).toEqual({ hostname: 'api.github.com', port: 443, path: '/v1' })
  })

  it('P1-8：exec 破坏性命令（rm -rf ~/.ssh）→ spawn 报警；常规清理不报', () => {
    expect(classifyOp({ module: 'child_process', op: 'exec', args: ['rm -rf ~/.ssh'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'spawn' })
    expect(classifyOp({ module: 'child_process', op: 'exec', args: ['rm -rf /tmp/x'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    expect(classifyOp({ module: 'child_process', op: 'exec', args: ['echo x > /etc/passwd'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'spawn' })
    expect(classifyOp({ module: 'child_process', op: 'spawn', args: ['rm', ['-rf', '/home/u/.ssh']] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'spawn' })
    expect(classifyOp({ module: 'child_process', op: 'spawn', args: ['cp', ['-r', '/tmp/a', '/tmp/b']] }, DEFAULT_HOOK_CONFIG)).toBeNull()
    // 常规 git/node 仍不报
    expect(classifyOp({ module: 'child_process', op: 'exec', args: ['npm run build'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
  })

  it('cp/rename 双向：src 敏感（拷密钥出局）或 dest 敏感（覆盖系统文件）都报（D29 补漏）', () => {
    // src 敏感：把 .env 拷出去
    expect(classifyOp({ module: 'fs', op: 'cpSync', args: ['/home/u/.env', '/tmp/stolen'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-write' })
    // dest 敏感：把恶意文件覆盖成 /etc/hosts
    // N7 族 3：cp 覆盖 /etc/hosts（DNS 劫持持久化面）→ persistence-write
    expect(classifyOp({ module: 'fs', op: 'cpSync', args: ['/tmp/evil', '/etc/hosts'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'persistence-write' })
    // rename 落位系统路径
    expect(classifyOp({ module: 'fs', op: 'rename', args: ['/tmp/evil', '/etc/passwd'] }, DEFAULT_HOOK_CONFIG)).toMatchObject({ kind: 'fs-write' })
    // 普通 cp 不报
    expect(classifyOp({ module: 'fs', op: 'cpSync', args: ['/tmp/a.txt', '/tmp/b.txt'] }, DEFAULT_HOOK_CONFIG)).toBeNull()
  })
})

describe('R31：归因阶段 fs 直通（递归护栏）', () => {
  it('敏感包名（dsh-credentials-local）下归因不再无限递归：恰好一条报警、标志经 finally 清除', () => {
    const tmp = mkdtempSync(join(tmpdir(), '.tmp-r31-'))
    // 复刻真实崩溃场景：profile node_modules 里有含敏感词（credentials）的包名
    const pkgDir = join(tmp, 'node_modules', '@deepseek-ai', 'dsh-credentials-local')
    mkdirSync(pkgDir, { recursive: true })
    writeFileSync(join(pkgDir, 'package.json'), '{}')
    mkdirSync(join(tmp, '.ssh'), { recursive: true })
    const alarms: HookAlarm[] = []
    // 模拟生产 rootIndex：置标志 → 经被包装的 fs 探测敏感名包路径（会再进包装器）→ finally 清标志
    const rootIndex = (): Map<string, string> => {
      setRootIndexing(true)
      try {
        // realpathSync 在被包装的 fs 上属性访问调用（ESM 具名导入会绕过钩子）
        try { fsDefault.realpathSync(join(pkgDir, 'package.json')) } catch { /* 存在与否都要走包装器 */ }
        return new Map([[pkgDir, '@deepseek-ai/dsh-credentials-local']])
      } finally {
        setRootIndexing(false)
      }
    }
    const dispose = patchModule(fsDefault as unknown as Record<string, unknown>, 'fs', DEFAULT_HOOK_CONFIG, a => alarms.push(a), rootIndex)
    try {
      // 触发真实报警：写敏感路径 → 归因 → rootIndex 内 realpathSync 敏感名包 → 不应递归
      // （无护栏时此处 RangeError: Maximum call stack size exceeded）
      fsDefault.writeFileSync(join(tmp, '.ssh', 'probe'), 'x')
      expect(alarms).toHaveLength(1)
      expect(alarms[0].kind).toBe('fs-write')
      // 标志已清：第二次敏感写入照常报警（护栏不吞报警）
      fsDefault.writeFileSync(join(tmp, '.ssh', 'probe'), 'y')
      expect(alarms).toHaveLength(2)
    } finally {
      dispose()
      setRootIndexing(false)
      rmSync(tmp, { recursive: true, force: true })
    }
  })

  it('置位期间敏感操作直通（不报警）；清除后恢复报警', () => {
    const alarms: HookAlarm[] = []
    const dispose = patchModule(fsDefault as unknown as Record<string, unknown>, 'fs', DEFAULT_HOOK_CONFIG, a => alarms.push(a), () => new Map())
    try {
      const p = join(mkdtempSync(join(tmpdir(), '.tmp-r31b-')), '.env')
      setRootIndexing(true)
      fsDefault.writeFileSync(p, 'x') // 直通：不报警
      expect(alarms).toHaveLength(0)
      setRootIndexing(false)
      fsDefault.writeFileSync(p, 'y') // 恢复：报警
      expect(alarms).toHaveLength(1)
    } finally {
      dispose()
      setRootIndexing(false)
    }
  })

  it('rootIndex 抛错：P1-3 归因失败不反噬原始调用——报警保留无主，写照常执行', () => {
    const alarms: HookAlarm[] = []
    let throwOnce = true
    const dispose = patchModule(fsDefault as unknown as Record<string, unknown>, 'fs', DEFAULT_HOOK_CONFIG, a => alarms.push(a), () => {
      setRootIndexing(true)
      try {
        if (throwOnce) {
          throwOnce = false
          throw new Error('rootIndex boom')
        }
        return new Map()
      } finally {
        setRootIndexing(false)
      }
    })
    try {
      const p = join(mkdtempSync(join(tmpdir(), '.tmp-r31c-')), '.env')
      // 旧实现把归因异常传给调用方（写被吞）；P1-3 改为 catch：报警保留（pluginHint 无主）、
      // fs 调用永不因归因失败而中断——归因只是 best-effort 增强
      fsDefault.writeFileSync(p, 'x')
      expect(alarms).toHaveLength(1)
      expect(alarms[0].kind).toBe('fs-write')
      expect(alarms[0].pluginHint).toBeUndefined() // 归因失败 → 报警无主而非丢失
      expect(readFileSync(p, 'utf8')).toBe('x')    // 原始写照常执行
      // 标志已清 + 归因恢复 → 正常报警且调用成功
      fsDefault.writeFileSync(p, 'y')
      expect(alarms).toHaveLength(2)
      expect(readFileSync(p, 'utf8')).toBe('y')
    } finally {
      dispose()
      setRootIndexing(false)
    }
  })
})

describe('pluginFromStack（栈归因）', () => {
  it('file:// 帧命中插件根 → 包名', () => {
    const roots = new Map([['/app/node_modules/evil-plugin/lib', 'evil-plugin']])
    const stack = 'Error\n    at wrapper (/app/node_modules/evil-plugin/lib/index.js:10:5)\n    at Object.<anonymous> (/app/main.js:1:1)'
    expect(pluginFromStack(stack, roots)).toBe('evil-plugin')
  })

  it('裸路径帧命中 → 包名；未命中 → undefined', () => {
    const roots = new Map([['/x/lib', '@scope/pkg']])
    expect(pluginFromStack('Error\n    at foo (/x/lib/a.js:1:1)', roots)).toBe('@scope/pkg')
    expect(pluginFromStack('Error\n    at foo (/other/b.js:1:1)', roots)).toBeUndefined()
  })

  it('空映射 / 空栈 → undefined', () => {
    expect(pluginFromStack(undefined, new Map())).toBeUndefined()
    expect(pluginFromStack('Error', new Map([['/x', 'x']]))).toBeUndefined()
  })
})

describe('patchModule（包装 + 恢复）', () => {
  it('危险操作报警、普通操作直通、disposer 恢复', () => {
    const calls: string[] = []
    const fake = {
      writeFile: (p: string) => { calls.push(`write:${p}`) },
      readFile: (p: string) => { calls.push(`read:${p}`) },
    }
    const alarms: string[] = []
    const dispose = patchModule(
      fake as unknown as Record<string, unknown>,
      'fs',
      DEFAULT_HOOK_CONFIG,
      a => { alarms.push(a.kind) },
      () => new Map(),
    )
    ;(fake as unknown as { writeFile: (p: string) => void }).writeFile('/home/user/.env')
    ;(fake as unknown as { readFile: (p: string) => void }).readFile('/home/user/a.txt')
    expect(alarms).toEqual(['fs-write'])
    expect(calls).toEqual(['write:/home/user/.env', 'read:/home/user/a.txt'])

    dispose()
    const restored = fake as unknown as Record<string, unknown>
    expect(restored.writeFile).toBeTypeOf('function')
    // 恢复后调用不再报警
    ;(fake as unknown as { writeFile: (p: string) => void }).writeFile('/etc/x')
    expect(alarms).toEqual(['fs-write'])
  })

  it('fs.promises 独立对象也被包装（Promise 调用同样报警）', async () => {
    const fakePromises = {
      readFile: async (p: string) => Buffer.from('x'),
      writeFile: async (p: string) => { },
    }
    const alarms: string[] = []
    const dispose = patchModule(
      fakePromises as unknown as Record<string, unknown>,
      'fs',
      DEFAULT_HOOK_CONFIG,
      a => { alarms.push(a.kind) },
      () => new Map(),
    )
    await (fakePromises as unknown as { readFile(p: string): Promise<Buffer> }).readFile('/home/user/.ssh/id_rsa')
    expect(alarms).toEqual(['fs-read'])
    await (fakePromises as unknown as { writeFile(p: string): Promise<void> }).writeFile('/home/user/.env')
    expect(alarms).toEqual(['fs-read', 'fs-write'])
    dispose()
  })
})

describe('readHostMetrics（宿主实时指标·跨平台容差）', () => {
  it('返回完整形状且字段在界内（Linux 全量；macOS 首轮 -1/0 回退合法）', () => {
    const m = readHostMetrics()
    expect(m.rssMb).toBeGreaterThanOrEqual(0)
    expect(m.cpuPct).toBeGreaterThanOrEqual(0)
    // io 自 round-20 起"不可得 = -1"（macOS/受限容器），不再伪装 0
    expect(m.ioReadMb === -1 || m.ioReadMb >= 0).toBe(true)
    expect(m.ioWriteMb === -1 || m.ioWriteMb >= 0).toBe(true)
    expect(m.mcpRssMb).toBeGreaterThanOrEqual(0)
    expect(m.mcpCount).toBeGreaterThanOrEqual(0)
    expect(m.vetRssMb).toBeGreaterThanOrEqual(0)
    expect(m.vetCount).toBeGreaterThanOrEqual(0)
    expect(m.childCount).toBeGreaterThanOrEqual(-1)
    expect(m.fdCount).toBeGreaterThanOrEqual(-1)
    expect(m.at).toBeGreaterThan(0)
  })
})

describe('writeRuntimeGuardConfig（profile 配置写入）', () => {
  const mkCtx = (baseUrl: string): { baseUrl: string; logger?: undefined } => ({ baseUrl })

  it('enable 写入条目 + 重复 enable 幂等 + disable 移除', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-guard-test-'))
    const patch = join(dir, 'cordis.patch.yml')
    writeFileSync(patch, '- id: settings\n  config:\n    watch: false\n')

    const ctx = mkCtx(dir)
    const r1 = writeRuntimeGuardConfig(ctx, true)
    expect(r1.ok).toBe(true)
    const content1 = readFileSync(patch, 'utf8')
    expect(content1).toContain('- id: plugin-vet')
    expect(content1).toContain('runtimeGuard: watch')

    const r2 = writeRuntimeGuardConfig(ctx, true) // 重复开启：重写而不是叠加，仍只有一条
    expect(r2.ok).toBe(true)
    const content2 = readFileSync(patch, 'utf8')
    expect(content2.match(/- id: plugin-vet/g)?.length).toBe(1)

    const r3 = writeRuntimeGuardConfig(ctx, false)
    expect(r3.ok).toBe(true)
    const content3 = readFileSync(patch, 'utf8')
    expect(content3).not.toContain('plugin-vet')
    expect(content3).toContain('- id: settings')

    rmSync(dir, { recursive: true, force: true })
  })

  it('旧形态包名条目（含引号）会被重写/移除（自愈）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-guard-test-'))
    const patch = join(dir, 'cordis.patch.yml')
    writeFileSync(patch, '- id: settings\n- id: "@jieai/dsh-plugin-vet"\n  config:\n    runtimeGuard: watch\n')

    const r1 = writeRuntimeGuardConfig(mkCtx(dir), true)
    expect(r1.ok).toBe(true)
    const content1 = readFileSync(patch, 'utf8')
    expect(content1).toContain('- id: plugin-vet')
    expect(content1).not.toContain('@jieai/dsh-plugin-vet')

    const r2 = writeRuntimeGuardConfig(mkCtx(dir), false)
    expect(r2.ok).toBe(true)
    const content2 = readFileSync(patch, 'utf8')
    expect(content2).not.toContain('plugin-vet')
    expect(content2).not.toContain('@jieai/dsh-plugin-vet')
    expect(content2).toContain('- id: settings')

    rmSync(dir, { recursive: true, force: true })
  })

  it('vet 条目 config 含嵌套列表也能完整保留（D29：缩进边界；关闭守卫不删其他显式键）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-guard-test-'))
    const patch = join(dir, 'cordis.patch.yml')
    writeFileSync(patch, '- id: settings\n  config:\n    watch: false\n- id: plugin-vet\n  config:\n    runtimeGuard: watch\n    allowlist:\n      - foo\n      - bar\n- id: other\n  config:\n    x: 1\n')

    const r = writeRuntimeGuardConfig(mkCtx(dir), false)
    expect(r.ok).toBe(true)
    const content = readFileSync(patch, 'utf8')
    // 0.3 fix（review）：关闭守卫只移除 runtimeGuard 键——allowlist/档位等显式配置不能丢
    expect(content).toContain('plugin-vet')
    expect(content).toContain('allowlist')
    expect(content).not.toContain('runtimeGuard')
    expect(content).toContain('- id: settings')
    expect(content).toContain('- id: other')
    expect(content).toContain('x: 1')
    rmSync(dir, { recursive: true, force: true })
  })

  it('0.3.1 联动：关闭守卫档位回轻度（profile 行删除）；重开守卫恢复中级，requireAudit 保留', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-guard-test-'))
    const patch = join(dir, 'cordis.patch.yml')
    writeFileSync(patch, '- id: plugin-vet\n  config:\n    runtimeGuard: watch\n    profile: hardened\n    requireAudit: true\n')

    const off = writeRuntimeGuardConfig(mkCtx(dir), false)
    expect(off.ok).toBe(true)
    const afterOff = readFileSync(patch, 'utf8')
    expect(afterOff).not.toContain('profile:')
    expect(afterOff).toContain('requireAudit: true')
    expect(afterOff).not.toContain('runtimeGuard')

    // 重开守卫：档位恢复中级，requireAudit 仍在（旧实现会把整个条目删掉，档位静默丢失回 standard）
    const on = writeRuntimeGuardConfig(mkCtx(dir), true)
    expect(on.ok).toBe(true)
    const afterOn = readFileSync(patch, 'utf8')
    expect(afterOn).toContain('runtimeGuard: watch')
    expect(afterOn).toContain('profile: hardened')
    expect(afterOn).toContain('requireAudit: true')

    rmSync(dir, { recursive: true, force: true })
  })

  it('0.3.1 联动：已设高级防御时开启守卫不降级（保持 paranoid）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-guard-test-'))
    const patch = join(dir, 'cordis.patch.yml')
    writeFileSync(patch, '- id: plugin-vet\n  config:\n    runtimeGuard: watch\n    profile: paranoid\n- id: settings\n  config:\n    watch: false\n')
    const r = writeRuntimeGuardConfig(mkCtx(dir), true)
    expect(r.ok).toBe(true)
    expect(r.profile).toBe('paranoid')
    const content = readFileSync(patch, 'utf8')
    expect(content).toContain('profile: paranoid')
    expect(content).toContain('runtimeGuard: watch')
    expect(content).toContain('- id: settings')
    rmSync(dir, { recursive: true, force: true })
  })

  it('0.3.1 联动：开启→关闭→开启 往返字节一致（无档位初始态的典型路径）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-guard-test-'))
    const patch = join(dir, 'cordis.patch.yml')
    writeFileSync(patch, '- id: settings\n  config:\n    watch: false\n')
    const on = writeRuntimeGuardConfig(mkCtx(dir), true)
    expect(on.ok).toBe(true)
    const withGuard = readFileSync(patch, 'utf8')
    expect(withGuard).toContain('profile: hardened')
    const off = writeRuntimeGuardConfig(mkCtx(dir), false)
    expect(off.ok).toBe(true)
    const afterOff = readFileSync(patch, 'utf8')
    expect(afterOff).not.toContain('profile:')
    expect(afterOff).not.toContain('runtimeGuard')
    expect(afterOff).toContain('- id: settings')
    const on2 = writeRuntimeGuardConfig(mkCtx(dir), true)
    expect(on2.ok).toBe(true)
    expect(readFileSync(patch, 'utf8')).toBe(withGuard)
    rmSync(dir, { recursive: true, force: true })
  })

  it('未配置时 disable 返回 ok', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-guard-test-'))
    writeFileSync(join(dir, 'cordis.patch.yml'), '- id: settings\n')
    const r = writeRuntimeGuardConfig(mkCtx(dir), false)
    expect(r.ok).toBe(true)
    rmSync(dir, { recursive: true, force: true })
  })

  it('baseUrl 为 file: URL 时正常读写（DSH web profile 实际形态）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-guard-test-'))
    writeFileSync(join(dir, 'cordis.patch.yml'), '- id: settings\n')
    const r = writeRuntimeGuardConfig(mkCtx('file:' + dir), true)
    expect(r.ok).toBe(true)
    expect(readFileSync(join(dir, 'cordis.patch.yml'), 'utf8')).toContain('runtimeGuard: watch')
    const r2 = writeRuntimeGuardConfig(mkCtx('file:' + dir), false)
    expect(r2.ok).toBe(true)
    expect(readFileSync(join(dir, 'cordis.patch.yml'), 'utf8')).not.toContain('plugin-vet')
    rmSync(dir, { recursive: true, force: true })
  })

  it('patch 文件不存在时 enable 直接新建', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-guard-test-'))
    const r = writeRuntimeGuardConfig(mkCtx(dir), true)
    expect(r.ok).toBe(true)
    expect(readFileSync(join(dir, 'cordis.patch.yml'), 'utf8')).toContain('- id: plugin-vet')
    rmSync(dir, { recursive: true, force: true })
  })

  it('H1：disable 后文件只剩 vet 条目 → 写 []（DSH boot 契约，空文件会抛错）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-guard-test-'))
    const patch = join(dir, 'cordis.patch.yml')
    writeFileSync(patch, '- id: plugin-vet\n  config:\n    runtimeGuard: watch\n')

    const r = writeRuntimeGuardConfig(mkCtx(dir), false)
    expect(r.ok).toBe(true)
    const content = readFileSync(patch, 'utf8')
    expect(content.trim()).toBe('[]')

    rmSync(dir, { recursive: true, force: true })
  })

  it('H2：开启守卫保留已有 config 的非 runtimeGuard 键（deny/allowlist 不被冲掉）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-guard-test-'))
    const patch = join(dir, 'cordis.patch.yml')
    writeFileSync(patch, '- id: plugin-vet\n  config:\n    mode: deny\n    allowlist:\n      - foo\n')

    const r = writeRuntimeGuardConfig(mkCtx(dir), true)
    expect(r.ok).toBe(true)
    const content = readFileSync(patch, 'utf8')
    expect(content).toContain('mode: deny')
    expect(content).toContain('allowlist')
    expect(content).toContain('runtimeGuard: watch')

    rmSync(dir, { recursive: true, force: true })
  })

  it('M5：readPatchRuntimeGuard 读文件级实际状态（watch/off）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-guard-test-'))
    const patch = join(dir, 'cordis.patch.yml')
    expect(readPatchRuntimeGuard(mkCtx(dir))).toBe('off')
    writeFileSync(patch, '- id: plugin-vet\n  config:\n    runtimeGuard: watch\n')
    expect(readPatchRuntimeGuard(mkCtx(dir))).toBe('watch')
    rmSync(dir, { recursive: true, force: true })
  })

  it('0.3 fix（review）：runtimeGuard 扫描不越出 vet 条目——后续插件条目的同名字段不误读', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-guard-test-'))
    const patch = join(dir, 'cordis.patch.yml')
    // vet 条目自身没有 runtimeGuard（off）；后面的条目（可能是任意插件）带同名字段
    writeFileSync(patch, '- id: plugin-vet\n  config:\n    profile: hardened\n- id: other-plugin\n  config:\n    runtimeGuard: true\n')
    // 旧实现整文件扫描：会误读 other-plugin 的 runtimeGuard: true → 'watch'；必须为 'off'
    expect(readPatchRuntimeGuard(mkCtx(dir))).toBe('off')
    // 反例：vet 条目内 watch 仍正确读回（边界 break 不吞自身字段）
    writeFileSync(patch, '- id: plugin-vet\n  config:\n    runtimeGuard: watch\n    profile: hardened\n- id: other-plugin\n  config:\n    runtimeGuard: false\n')
    expect(readPatchRuntimeGuard(mkCtx(dir))).toBe('watch')
    rmSync(dir, { recursive: true, force: true })
  })

  it('patch 文件不存在时 disable 视为未开启', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-guard-test-'))
    const r = writeRuntimeGuardConfig(mkCtx(dir), false)
    expect(r.ok).toBe(true)
    rmSync(dir, { recursive: true, force: true })
  })

  it('对象操作：含 --- 分隔符的现有文件拒绝写入（round-15：多文档合法，不重排不破坏）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-guard-test-'))
    // 现有文件含 --- 文档分隔符 —— 多文档是合法 YAML stream（用户手写合并形态）。
    // 旧版 js-yaml.load + dump 对象操作会把其余文档抹掉（2026-08-26 !!js 事故同族
    // 破坏面）；round-15 起拒绝写入并提示手动合并，文件原样保留。
    const patch = join(dir, 'cordis.patch.yml')
    const multi = '---\n- id: settings\n---\n- id: other\n'
    writeFileSync(patch, multi)
    const r = writeRuntimeGuardConfig(mkCtx(dir), true)
    expect(r.ok).toBe(false)
    expect(r.note).toContain('多文档')
    expect(readFileSync(patch, 'utf8')).toBe(multi)
    rmSync(dir, { recursive: true, force: true })
  })
})

describe('writeVetTierConfig（档位写入，保留既有配置键）', () => {
  const mkCtx = (baseUrl: string): { baseUrl: string } => ({ baseUrl })

  it('写入 profile 档位并保留 runtimeGuard/requireAudit 等既有键与其他条目', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-vet-tier-'))
    const patch = join(dir, 'cordis.patch.yml')
    writeFileSync(patch, '- id: plugin-vet\n  config:\n    runtimeGuard: watch\n    requireAudit: true\n- id: settings\n  config:\n    watch: false\n')

    const r = writeVetTierConfig(mkCtx(dir), 'hardened')
    expect(r.ok).toBe(true)
    const content = readFileSync(patch, 'utf8')
    expect(content).toContain('profile: hardened')
    expect(content).toContain('runtimeGuard: watch')
    expect(content).toContain('requireAudit: true')
    expect(content).toContain('- id: settings')
    rmSync(dir, { recursive: true, force: true })
  })

  it('无 vet 条目时新建；非法档位拒绝；file: URL 形态可用', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-vet-tier-'))
    const r1 = writeVetTierConfig(mkCtx(dir), 'paranoid')
    expect(r1.ok).toBe(true)
    expect(readFileSync(join(dir, 'cordis.patch.yml'), 'utf8')).toContain('profile: paranoid')

    const r2 = writeVetTierConfig(mkCtx('file:' + dir), 'standard')
    expect(r2.ok).toBe(true)
    // 0.3.1 联动：轻度防御 ⇔ 守卫关——档位与 runtimeGuard 行都删除，空壳条目整块移除
    expect(readFileSync(join(dir, 'cordis.patch.yml'), 'utf8').trim()).toBe('[]')

    const r3 = writeVetTierConfig(mkCtx(dir), 'bogus')
    expect(r3.ok).toBe(false)
    rmSync(dir, { recursive: true, force: true })
  })

  it('切回 standard：档位与守卫行全删（轻度防御 = 无显式配置；空壳条目移除）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-vet-tier-'))
    writeFileSync(join(dir, 'cordis.patch.yml'), '- id: plugin-vet\n  config:\n    profile: paranoid\n')
    const r = writeVetTierConfig(mkCtx(dir), 'standard')
    expect(r.ok).toBe(true)
    const content = readFileSync(join(dir, 'cordis.patch.yml'), 'utf8')
    expect(content.trim()).toBe('[]')
    expect(content).not.toContain('paranoid')
    rmSync(dir, { recursive: true, force: true })
  })

  it('0.3.1 联动：选中级防御自动开启守卫（空文件形态）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-vet-tier-'))
    const r = writeVetTierConfig(mkCtx(dir), 'hardened')
    expect(r.ok).toBe(true)
    expect(r.profile).toBe('hardened')
    const content = readFileSync(join(dir, 'cordis.patch.yml'), 'utf8')
    expect(content).toContain('profile: hardened')
    expect(content).toContain('runtimeGuard: watch')
    expect(() => yaml.load(content)).not.toThrow()
    rmSync(dir, { recursive: true, force: true })
  })
})

describe('/vet/profile 端点', () => {
  const mkHandler = (): ((req: never, res: never) => void) => {
    const routes: { handler: (req: never, res: never) => void }[] = []
    const ctx = {
      get: (name: string) => name === 'webServer' ? { register: (r: never) => { routes.push(r as never) } } : undefined,
      effect: (fn: () => unknown): unknown => fn(),
    }
    const ok = registerStatusRouteOnce(ctx as never, { profile: 'standard' } as never, new VetStatus())
    expect(ok).toBe(true)
    return routes[0]!.handler
  }
  const mkRes = (): { code: number; body: unknown } => {
    const r = { code: 0, body: null as unknown }
    return Object.assign(r, {
      writeHead: (c: number) => { r.code = c },
      end: (b: string) => { r.body = JSON.parse(b) },
    })
  }

  it('无 Origin → 403（跨站防护）', () => {
    const handler = mkHandler()
    const res = mkRes()
    handler({ method: 'POST', url: '/vet/profile', headers: {} }, res as never)
    expect(res.code).toBe(403)
  })

  it('同源 + 非法档位 → 400（写入拒绝）', () => {
    const handler = mkHandler()
    const res = mkRes()
    handler({
      method: 'POST',
      url: '/vet/profile',
      headers: { origin: 'http://x', host: 'x' },
      on: (ev: string, cb: (c?: Buffer) => void) => {
        if (ev === 'data') cb(Buffer.from(JSON.stringify({ tier: 'bogus' })))
        if (ev === 'end') cb()
      },
    }, res as never)
    expect(res.code).toBe(400)
    expect((res.body as { note: string }).note).toContain('非法档位')
  })
})

describe('/vet/plugin 端点（0.3.1：作用域包名合法回归）', () => {
  const mkHandler = (): ((req: never, res: never) => void) => {
    // 数据隔离：capabilities/scan-summaries 指向空目录，避免命中开发机真实留档
    const iso = mkdtempSync(join(tmpdir(), '.tmp-plugin-detail-'))
    setCapabilitiesDirForTest(iso)
    setSummariesDirForTest(iso)
    const routes: { handler: (req: never, res: never) => void }[] = []
    const ctx = {
      get: (name: string) => name === 'webServer' ? { register: (r: never) => { routes.push(r as never) } } : undefined,
      effect: (fn: () => unknown): unknown => fn(),
      logger: { info: vi.fn(), warn: vi.fn(), error: vi.fn() },
    }
    const ok = registerStatusRouteOnce(ctx as never, { profile: 'standard' } as never, new VetStatus())
    expect(ok).toBe(true)
    return routes[0]!.handler
  }
  afterEach(() => {
    setCapabilitiesDirForTest(undefined)
    setSummariesDirForTest(undefined)
  })
  const mkRes = (): { code: number; body: unknown } => {
    const r = { code: 0, body: null as unknown }
    return Object.assign(r, {
      writeHead: (c: number) => { r.code = c },
      end: (b: string) => { r.body = JSON.parse(b) },
    })
  }
  const get = (handler: (req: unknown, res: unknown) => void, url: string): { code: number; body: unknown } => {
    const res = mkRes()
    handler({ method: 'GET', url, headers: {} }, res as never)
    return res
  }

  it('作用域包名（@scope/name 含 /）→ 未见过 404，绝不再 400（用户事故回归）', () => {
    const handler = mkHandler()
    const res = get(handler, '/vet/plugin?name=@deepseek-ai/dsh-client-connection')
    expect(res.code).toBe(404) // 名字合法：不应 400「name 非法」
    expect((res.body as { note: string }).note).toContain('未见过')
  })

  it('round-18：插件详情带 official 标记——官方包不再显示为「未审核陌生包」', () => {
    const handler = mkHandler()
    // mkHandler 已把 summaries 目录隔离；写入官方包 + 第三方包的扫描摘要
    recordScanSummary({ name: '@deepseek-ai/dsh-tools', version: '0.1.1-rc.2', at: Date.now(), verdict: 'clean', staticScore: 95, ruleCodes: [] })
    recordScanSummary({ name: 'third-party', version: '1.0.0', at: Date.now(), verdict: 'clean', staticScore: 90, ruleCodes: [] })
    const official = get(handler, '/vet/plugin?name=' + encodeURIComponent('@deepseek-ai/dsh-tools'))
    expect(official.code).toBe(200)
    expect((official.body as { plugin: { official?: boolean } }).plugin.official).toBe(true)
    expect((official.body as { plugin: { audited?: boolean } }).plugin.audited).toBe(false)
    const third = get(handler, '/vet/plugin?name=third-party')
    expect(third.code).toBe(200)
    expect((third.body as { plugin: { official?: boolean } }).plugin.official).toBe(false)
  })

  it('无 name / 空 name → 400', () => {
    const handler = mkHandler()
    expect(get(handler, '/vet/plugin').code).toBe(400)
    expect(get(handler, '/vet/plugin?name=').code).toBe(400)
  })

  it('路径穿越（..）/ 反斜杠 / 控制字符 → 400 拒绝', () => {
    const handler = mkHandler()
    expect(get(handler, '/vet/plugin?name=a/../b').code).toBe(400)
    expect(get(handler, '/vet/plugin?name=a%5Cb').code).toBe(400)
    expect(get(handler, '/vet/plugin?name=a%00b').code).toBe(400)
  })
})

describe('registerStatusRouteOnce（webServer 就绪重试）', () => {
  it('webServer 未就绪 → false，不注册', () => {
    const routes: unknown[] = []
    const ctx = {
      baseUrl: '/tmp',
      get: () => undefined,
      effect: (fn: () => unknown) => { fn() },
    } as never
    const ok = registerStatusRouteOnce(ctx as never, { runtimeGuard: 'off' } as never, new VetStatus())
    expect(ok).toBe(false)
    expect(routes).toHaveLength(0)
  })

  it('webServer 就绪 → true，注册 /vet 前缀路由', () => {
    let handler: unknown
    const routes: unknown[] = []
    const ws = { register: (r: unknown) => { routes.push(r); return () => {} } }
    const ctx = {
      baseUrl: '/tmp',
      get: (name: string) => (name === 'webServer' ? ws : undefined),
      effect: (fn: () => unknown) => { fn() },
    } as never
    const ok = registerStatusRouteOnce(ctx as never, { runtimeGuard: 'watch' } as never, new VetStatus())
    expect(ok).toBe(true)
    expect(routes).toHaveLength(1)
    expect((routes[0] as { path: string }).path).toBe('/vet')
  })

  it('HTTP handler：GET status.json 返回快照；POST 无 Origin 拒绝；未知路径 404', () => {
    let handler: (req: unknown, res: unknown) => void
    const routes: unknown[] = []
    const ws = { register: (r: unknown) => { routes.push(r); return () => {} } }
    const status = new VetStatus()
    status.record({ id: 't1:fd:512', severity: 'yellow', source: 't1', kind: 'fd', message: 'x', at: Date.now() })
    const ctx = {
      baseUrl: '/tmp',
      get: (name: string) => (name === 'webServer' ? ws : undefined),
      effect: (fn: () => unknown) => { fn() },
      logger: { info: vi.fn(), warn: vi.fn(), error: vi.fn() },
    } as never
    registerStatusRouteOnce(ctx as never, { runtimeGuard: 'watch' } as never, status)
    handler = (routes[0] as { handler: typeof handler }).handler

    // GET /vet/status.json → 200 快照
    const getRes: { code: number; body: unknown } = { code: 0, body: null }
    const gres = {
      writableEnded: false,
      writeHead: (code: number) => { getRes.code = code },
      end: (body: string) => { getRes.body = JSON.parse(body) },
    }
    handler({ method: 'GET', url: '/vet/status.json', headers: {} }, gres)
    expect(getRes.code).toBe(200)
    expect((getRes.body as { level: string }).level).toBe('yellow')
    // 0.3：runtimeGuard = 档位展开后的生效值（= config）；patchRuntimeGuard = 文件级实际状态
    expect((getRes.body as { runtimeGuard: string }).runtimeGuard).toBe('watch')
    expect((getRes.body as { patchRuntimeGuard: string }).patchRuntimeGuard).toBe('off')

    // POST /vet/runtime-guard 无 Origin → 403（跨站防护，M4）
    const postRes: { code: number; body: unknown } = { code: 0, body: null }
    const pres = {
      writableEnded: false,
      writeHead: (code: number) => { postRes.code = code },
      end: (body: string) => { postRes.body = JSON.parse(body) },
      on: () => {},
    }
    handler({ method: 'POST', url: '/vet/runtime-guard', headers: {} }, pres)
    expect(postRes.code).toBe(403)

    // 未知路径 → 404
    const nfRes: { code: number; body: unknown } = { code: 0, body: null }
    const nres = {
      writableEnded: false,
      writeHead: (code: number) => { nfRes.code = code },
      end: (body: string) => { nfRes.body = JSON.parse(body) },
    }
    handler({ method: 'GET', url: '/vet/other', headers: {} }, nres)
    expect(nfRes.code).toBe(404)

    // POST /vet/dismiss {id}（同源）→ 200；GET 再查 → 报警进 dismissed、count/level 降下来
    const mkRes = (): { code: number; body: unknown } & { writableEnded: boolean } => {
      const r = { code: 0, body: null as unknown, writableEnded: false }
      return Object.assign(r, {
        writeHead: (c: number) => { r.code = c },
        end: (b: string) => { r.body = JSON.parse(b) },
      })
    }
    const disRes = mkRes()
    handler(
      {
        method: 'POST',
        url: '/vet/dismiss',
        headers: { origin: 'http://x', host: 'x' },
        on: (ev: string, cb: (c?: Buffer) => void) => {
          if (ev === 'data') cb(Buffer.from(JSON.stringify({ id: 't1:fd:512' })))
          if (ev === 'end') cb()
        },
      },
      disRes,
    )
    expect(disRes.code).toBe(200)
    const get2 = mkRes()
    handler({ method: 'GET', url: '/vet/status.json', headers: {} }, get2)
    expect((get2.body as { alarmCount: number }).alarmCount).toBe(0)
    expect((get2.body as { level: string }).level).toBe('green')
    expect((get2.body as { dismissed: unknown[] }).dismissed).toHaveLength(1)

    // POST /vet/restore {id} → 报警回来
    const resRes = mkRes()
    handler(
      {
        method: 'POST',
        url: '/vet/restore',
        headers: { origin: 'http://x', host: 'x' },
        on: (ev: string, cb: (c?: Buffer) => void) => {
          if (ev === 'data') cb(Buffer.from(JSON.stringify({ id: 't1:fd:512' })))
          if (ev === 'end') cb()
        },
      },
      resRes,
    )
    expect(resRes.code).toBe(200)
    const get3 = mkRes()
    handler({ method: 'GET', url: '/vet/status.json', headers: {} }, get3)
    expect((get3.body as { alarmCount: number }).alarmCount).toBe(1)
    expect((get3.body as { level: string }).level).toBe('yellow')

    // dismiss 无 Origin → 403；缺 id / 非字符串 → 400
    const noOrigin = mkRes()
    handler({ method: 'POST', url: '/vet/dismiss', headers: {}, on: () => {} }, noOrigin)
    expect(noOrigin.code).toBe(403)
    const badId = mkRes()
    handler(
      {
        method: 'POST',
        url: '/vet/dismiss',
        headers: { origin: 'http://x', host: 'x' },
        on: (ev: string, cb: (c?: Buffer) => void) => {
          if (ev === 'data') cb(Buffer.from(JSON.stringify({})))
          if (ev === 'end') cb()
        },
      },
      badId,
    )
    expect(badId.code).toBe(400)
  })
})

describe('ensureHoneypot（蜜罐播种）', () => {
  it('创建诱饵文件集，内容/文件名无蜜罐关键词（反蜜罐）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-hp-data-'))
    const root = ensureHoneypot(dir)
    expect(root).toBe(dir)
    const names = ['id_rsa.pem', 'id_rsa.pub', '.env', 'credentials.json', '.npmrc', '.netrc', 'aws-credentials']
    for (const n of names) {
      expect(readFileSync(join(dir, n), 'utf8').length).toBeGreaterThan(10)
    }
    // 反蜜罐：文件名/内容都不该出现 honeypot/vet/decoy/fake 关键词
    for (const n of names) {
      expect(n).not.toMatch(/honeypot|vet|decoy|fake/i)
      expect(readFileSync(join(dir, n), 'utf8')).not.toMatch(/honeypot|vet[-_]|decoy|fake/i)
    }
    // RSA 诱饵是真实格式
    expect(readFileSync(join(dir, 'id_rsa.pem'), 'utf8')).toContain('BEGIN PRIVATE KEY')
    rmSync(dir, { recursive: true, force: true })
  })

  it('幂等：已存在诱饵不重写；被删诱饵自动重建', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-honeypot-'))
    ensureHoneypot(dir)
    const before = readFileSync(join(dir, '.env'), 'utf8')
    ensureHoneypot(dir)
    expect(readFileSync(join(dir, '.env'), 'utf8')).toBe(before)
    // 用户预置文件不被覆盖
    writeFileSync(join(dir, '.env'), 'REAL=value')
    ensureHoneypot(dir)
    expect(readFileSync(join(dir, '.env'), 'utf8')).toBe('REAL=value')
    // 被删诱饵重建（自愈）
    rmSync(join(dir, '.npmrc'))
    ensureHoneypot(dir)
    expect(readFileSync(join(dir, '.npmrc'), 'utf8').length).toBeGreaterThan(10)
    rmSync(dir, { recursive: true, force: true })
  })

  it('默认目录位于 ~/.dsh 下且无蜜罐关键词', () => {
    expect(DEFAULT_HONEYPOT_DIR).toContain('.dsh')
    expect(DEFAULT_HONEYPOT_DIR).toContain('.local')
    expect(DEFAULT_HONEYPOT_DIR).not.toMatch(/honeypot|vet|decoy|fake/i)
  })
})

describe('installRuntimeGuard（T1 哨兵 + T2 钩子集成，覆盖率补盲）', () => {
  const mkCtx = (): { logger: { info: ReturnType<typeof vi.fn>; warn: ReturnType<typeof vi.fn>; error: ReturnType<typeof vi.fn> }; baseUrl?: string; loader?: unknown } => ({
    logger: { info: vi.fn(), warn: vi.fn(), error: vi.fn() },
  })

  it('watch 模式：装 guard → 真实 fs 写敏感路径 → T2 报警进 status；dispose 恢复', () => {
    const ctx = mkCtx()
    const status = new VetStatus()
    const config = {
      runtimeGuard: 'watch' as const,
      runtimeIntervalMs: 2000, runtimeMemLimitMb: 1024, runtimeForkBurstN: 5,
      runtimeFdLimit: 512, runtimeGrowthMb: 256, runtimeGrowthWindowMs: 600_000,
      honeypot: { enabled: false, dir: '' },
    }
    const dispose = installRuntimeGuard(ctx as never, config as never, status)
    try {
      // 真实 fs 模块已被包装：写敏感路径应产生 fs-write 报警（T2 生效）
      const before = status.snapshot().alarmCount
      // 用真实 fs 触发（写一个临时敏感命名路径）
      const dir = mkdtempSync(join(tmpdir(), '.tmp-guard-integ-'))
      try {
        // 用属性访问（fsDefault.writeFileSync）触发——ESM 具名导入是 patch 前固化的原始引用，
        // patchModule 包装的是模块对象属性（README 已知旁路），属性访问才能命中 T2 钩子
        fsDefault.writeFileSync(join(dir, 'id_rsa.pem'), 'x') // id_rsa 段名敏感
        const snap = status.snapshot()
        expect(snap.alarmCount).toBeGreaterThan(before)
        expect(snap.alarms[0].kind).toBe('fs-write')
        expect(snap.alarms[0].id).toContain('t2:fs-write:')
        // P1-6：id 含 pluginHint 段（无归因时为空段，格式完整）
        expect(snap.alarms[0].id).toMatch(/^t2:fs-write:.+:.*$/)
      } finally {
        fsDefault.rmSync(dir, { recursive: true, force: true })
      }
    } finally {
      dispose()
    }
    // dispose 后：环境变量清空、再写不再报警（钩子已恢复）
    expect(process.env.DSH_VET_SIDECAR_PID).toBeUndefined()
    const after = status.snapshot().alarmCount
    const dir2 = mkdtempSync(join(tmpdir(), '.tmp-guard-integ2-'))
    try {
      fsDefault.writeFileSync(join(dir2, 'id_rsa.pem'), 'y')
      expect(status.snapshot().alarmCount).toBe(after)
    } finally {
      fsDefault.rmSync(dir2, { recursive: true, force: true })
    }
  })

  it('off 模式：不 spawn 哨兵、不装钩子，蜜罐提示（覆盖率补盲）', () => {
    const ctx = mkCtx()
    const status = new VetStatus()
    const config = {
      runtimeGuard: 'off' as const,
      honeypot: { enabled: true, dir: '' },
    }
    const dispose = installRuntimeGuard(ctx as never, config as never, status)
    dispose()
    expect(ctx.logger.warn).toHaveBeenCalledWith(expect.stringContaining('蜜罐未生效'))
    expect(process.env.DSH_VET_SIDECAR_PID).toBeUndefined()
  })
})

describe('蜜罐报警（classifyOp）', () => {
  const mkCfg = (roots: string[]): typeof DEFAULT_HOOK_CONFIG => ({ ...DEFAULT_HOOK_CONFIG, honeypotRoots: roots })

  it('M7：readdir 蜜罐根目录 → honeypot 报警（翻找的第一个动作）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-hp-probe-'))
    ensureHoneypot(dir)
    const cfg = mkCfg([dir])
    expect(classifyOp({ module: 'fs', op: 'readdirSync', args: [dir] }, cfg)).toMatchObject({ kind: 'honeypot', severity: 'yellow' })
    expect(classifyOp({ module: 'fs', op: 'readdir', args: [dir] }, cfg)).toMatchObject({ kind: 'honeypot' })
    rmSync(dir, { recursive: true, force: true })
  })

  it('触碰诱饵路径 → 独立 honeypot 报警（读黄/删红）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-honeypot-'))
    ensureHoneypot(dir)
    const cfg = mkCfg([dir])
    const read = classifyOp({ module: 'fs', op: 'readFileSync', args: [join(dir, '.env')] }, cfg)
    expect(read).toMatchObject({ kind: 'honeypot', severity: 'yellow' })
    const del = classifyOp({ module: 'fs', op: 'rmSync', args: [join(dir, 'credentials.json')] }, cfg)
    expect(del).toMatchObject({ kind: 'honeypot', severity: 'red' })
    const write = classifyOp({ module: 'fs', op: 'writeFile', args: [join(dir, '.npmrc'), 'x'] }, cfg)
    expect(write).toMatchObject({ kind: 'honeypot', severity: 'yellow' })
    rmSync(dir, { recursive: true, force: true })
  })

  it('未启用蜜罐（空蜜罐根）不产生 honeypot 报警；普通敏感路径仍按原规则', () => {
    const cfg = mkCfg([])
    expect(classifyOp({ module: 'fs', op: 'readFileSync', args: ['/home/user/.ssh/id_rsa'] }, cfg)).toMatchObject({ kind: 'fs-read' })
    expect(classifyOp({ module: 'fs', op: 'readFileSync', args: ['/tmp/whatever/index.js'] }, cfg)).toBeNull()
  })
})
describe('sidecar 单例锁（D30 修漏：配置热重载重复 apply 不再叠加哨兵）', () => {
  // spawn 子进程需要真实可执行 JS：用编译产物（npm test = build + vitest；源码是 .ts 不能直接跑）
  const watchPath = fileURLToPath(new URL('../lib/guard/runtime-watch.js', import.meta.url))
  const args = [watchPath, '--vet-sidecar', '2000', '2048', '5', '512', '256', '600000']

  // T1 哨兵完全依赖 /proc（单例认亲 + 宿主存活看护都是 /proc 读取）；Windows 无 /proc，
  // 首个 tick 就会按「宿主不可读」优雅退出（exit 0），单例锁语义无从验证——Linux 专属用例。
  it.skipIf(process.platform === 'win32')('同宿主重复 spawn → 后者立即退出（exit 0），前者存活', async () => {
    const first = spawn(process.execPath, args, { stdio: 'ignore' })
    // 等第一个完成 exec（cmdline 可读）再 spawn 第二个，避免 /proc 竞态
    // 等 first 进入稳态（单例锁已通过、setInterval 已建立）再 spawn second——
    // 模拟生产时序：热重载时旧哨兵早已运行，新 spawn 的哨兵晚到 → 新自杀、旧存活。
    // 不能只等 exec：first 和 second 若几乎同时 exec 完，各自扫描都能看到对方 → 两个都自杀（测试竞态）。
    await new Promise((resolve) => setTimeout(resolve, 1000))
    const second = spawn(process.execPath, args, { stdio: 'ignore' })
    const code = await new Promise<number | null>((resolve) => {
      const timer = setTimeout(() => resolve(null), 5000)
      second.on('exit', (c) => { clearTimeout(timer); resolve(c) })
    })
    expect(code).toBe(0) // 后者自杀退出
    // 前者还活着
    expect(first.exitCode).toBeNull()
    first.kill()
  })
})
describe('2026-08-26 事故回归：!!js patch 行级手术（不重排、不丢条目）', () => {
  const mkCtx = (baseUrl: string): { baseUrl: string } => ({ baseUrl })
  // 事故现场同款文件：注释头 + webserver 的 !!js 表达式 + insert polyfill + 多行哈希
  const JS_HEADER = '# Your patch layer for this dsh profile, applied after every bundle layer:'
  const PATCH_WITH_JS = [
    JS_HEADER,
    '- id: settings',
    '  config:',
    '    watch: false',
    '- id: plugin-vet',
    '  config:',
    '    runtimeGuard: watch',
    '    profile: hardened',
    '    requireAudit: true',
    '    acknowledgedPackageHashes:',
    '      "@deepseek-ai/dsh-client-connection@0.1.0-rc.8":',
    '        - "e396626b275719de626a3338ed5566f7b556846cee52e7e85e947f00ced8442d"',
    '- id: webserver',
    '  config:',
    '    host: 0.0.0.0',
    '    port: !!js ctx.webStartup.port ?? 3456',
    '- insert:',
    "    - name: '/home/chen/.dsh/profiles/web/lan-uuid-polyfill.mjs'",
    '',
  ].join('\n')

  it('开启守卫：只插入 runtimeGuard 行——注释头/!!js webserver/insert/哈希全部原样', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-jstag-'))
    const patch = join(dir, 'cordis.patch.yml')
    // 事故时点：vet 条目无 runtimeGuard（off 状态），用户点「开启」
    writeFileSync(patch, PATCH_WITH_JS.replace('    runtimeGuard: watch\n', ''))
    const r = writeRuntimeGuardConfig(mkCtx(dir), true)
    expect(r.ok).toBe(true)
    expect(r.profile).toBe('hardened') // 0.3.1 联动：开守卫 → 档位=中级防御
    const content = readFileSync(patch, 'utf8')
    // 事故核心：!!js 行与注释头必须原样保留（旧实现把整文件重排成只剩 vet 条目）
    expect(content).toContain('port: !!js ctx.webStartup.port ?? 3456')
    expect(content).toContain(JS_HEADER)
    expect(content).toContain('- id: webserver')
    expect(content).toContain('host: 0.0.0.0')
    expect(content).toContain('- insert:')
    expect(content).toContain('lan-uuid-polyfill.mjs')
    expect(content).toContain('runtimeGuard: watch')
    expect(content).toContain('profile: hardened')
    expect(content).toContain('requireAudit: true')
    expect(content).toContain('acknowledgedPackageHashes')
    expect(content).toContain('- id: settings')
    rmSync(dir, { recursive: true, force: true })
  })

  it('关闭守卫：删 runtimeGuard 与 profile 行——哈希/webserver/insert 保留，条目仍在', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-jstag-'))
    const patch = join(dir, 'cordis.patch.yml')
    writeFileSync(patch, PATCH_WITH_JS)
    const r = writeRuntimeGuardConfig(mkCtx(dir), false)
    expect(r.ok).toBe(true)
    expect(r.profile).toBe('standard') // 0.3.1 联动：关守卫 → 档位=轻度防御
    const content = readFileSync(patch, 'utf8')
    expect(content).not.toContain('runtimeGuard')
    expect(content).not.toContain('profile:') // 档位回默认：profile 行删除（轻度防御 = 无显式档位）
    // 事故核心：其余行零触碰
    expect(content).toContain('port: !!js ctx.webStartup.port ?? 3456')
    expect(content).toContain(JS_HEADER)
    expect(content).toContain('acknowledgedPackageHashes')
    expect(content).toContain('requireAudit: true')
    expect(content).toContain('lan-uuid-polyfill.mjs')
    expect(content).toContain('host: 0.0.0.0')
    expect(content).toContain('- id: plugin-vet') // 条目保留（还有其他显式键）
    rmSync(dir, { recursive: true, force: true })
  })

  it('关→开往返：两次写入后文件与原始 !!js 文件逐字节一致', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-jstag-'))
    const patch = join(dir, 'cordis.patch.yml')
    writeFileSync(patch, PATCH_WITH_JS)
    const off = writeRuntimeGuardConfig(mkCtx(dir), false)
    expect(off.ok).toBe(true)
    const on = writeRuntimeGuardConfig(mkCtx(dir), true)
    expect(on.ok).toBe(true)
    expect(readFileSync(patch, 'utf8')).toBe(PATCH_WITH_JS)
    rmSync(dir, { recursive: true, force: true })
  })

  it('tier 档位写入：!!js 行与其他条目原样，profile 键正确增改（0.3.1 联动守卫同步）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-jstag-'))
    const patch = join(dir, 'cordis.patch.yml')
    // 无档位行形态（旧配置）→ 选中级防御：插入 profile + 守卫保持/置为 watch
    writeFileSync(patch, PATCH_WITH_JS.replace('    profile: hardened\n', '').replace('    runtimeGuard: watch\n', '    runtimeGuard: off\n'))
    const r = writeVetTierConfig(mkCtx(dir), 'hardened')
    expect(r.ok).toBe(true)
    const content = readFileSync(patch, 'utf8')
    expect(content).toContain('profile: hardened')
    expect(content).toContain('runtimeGuard: watch') // 联动：中级防御 ⇒ 守卫开
    expect(content).toContain('port: !!js ctx.webStartup.port ?? 3456')
    expect(content).toContain(JS_HEADER)
    expect(content).toContain('lan-uuid-polyfill.mjs')
    // 旧档位 paranoid 形态 → 选轻度防御：profile 与 runtimeGuard 行都删除（条目因有哈希保留）
    writeFileSync(patch, PATCH_WITH_JS.replace('    profile: hardened\n', '    profile: paranoid\n'))
    const r2 = writeVetTierConfig(mkCtx(dir), 'standard')
    expect(r2.ok).toBe(true)
    const content2 = readFileSync(patch, 'utf8')
    expect(content2).not.toContain('profile:')
    expect(content2).not.toContain('paranoid')
    expect(content2).not.toContain('runtimeGuard') // 轻度防御 ⇒ 守卫关
    expect(content2).toContain('port: !!js ctx.webStartup.port ?? 3456')
    expect(content2).toContain('lan-uuid-polyfill.mjs')
    rmSync(dir, { recursive: true, force: true })
  })

  it('旧形态 id 自愈：@jieai 引号条目在 !!js 文件上规范化为 plugin-vet', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-jstag-'))
    const patch = join(dir, 'cordis.patch.yml')
    const legacy = PATCH_WITH_JS.replace('- id: plugin-vet', '- id: "@jieai/dsh-plugin-vet"')
    writeFileSync(patch, legacy)
    const r = writeRuntimeGuardConfig(mkCtx(dir), true)
    expect(r.ok).toBe(true)
    const content = readFileSync(patch, 'utf8')
    expect(content).toContain('- id: plugin-vet')
    expect(content).not.toContain('@jieai/dsh-plugin-vet')
    expect(content).toContain('port: !!js ctx.webStartup.port ?? 3456')
    expect(content).toContain('lan-uuid-polyfill.mjs')
    rmSync(dir, { recursive: true, force: true })
  })

  it('vet 条目语法坏：行级手术自愈为合法 YAML，不抛错', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-jstag-'))
    const patch = join(dir, 'cordis.patch.yml')
    writeFileSync(patch, '- id: plugin-vet\n  config:\n    runtimeGuard: [bad\n- id: settings\n  config:\n    watch: false\n')
    const r = writeRuntimeGuardConfig(mkCtx(dir), true)
    expect(r.ok).toBe(true)
    const content = readFileSync(patch, 'utf8')
    expect(content).toContain('- id: plugin-vet')
    expect(content).toContain('runtimeGuard: watch')
    expect(content).toContain('- id: settings')
    expect(() => yaml.load(content)).not.toThrow()
    rmSync(dir, { recursive: true, force: true })
  })

  it('其他条目语法坏：fail-closed 拒写，原文件不动（绝不叠写坏文件）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-jstag-'))
    const patch = join(dir, 'cordis.patch.yml')
    const bad = PATCH_WITH_JS.replace('port: !!js ctx.webStartup.port ?? 3456', 'port: !!js [broken')
    writeFileSync(patch, bad)
    const r = writeRuntimeGuardConfig(mkCtx(dir), false)
    expect(r.ok).toBe(false)
    expect(readFileSync(patch, 'utf8')).toBe(bad)
    rmSync(dir, { recursive: true, force: true })
  })

  it('多文档 --- 文件：拒绝写入且文件不动（round-15：重排会抹掉用户手写的其他文档）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-jstag-'))
    const patch = join(dir, 'cordis.patch.yml')
    const multi = '---\n- id: settings\n---\n- id: other\n'
    writeFileSync(patch, multi)
    const r = writeRuntimeGuardConfig(mkCtx(dir), true)
    expect(r.ok).toBe(false)
    expect(r.note).toContain('多文档')
    // 文件原样保留——多文档是合法 YAML stream（用户手写合并形态），vet 不重排不破坏
    expect(readFileSync(patch, 'utf8')).toBe(multi)
    rmSync(dir, { recursive: true, force: true })
  })
})

describe('即时装配（0.4.1）：setGuardToggleHook 接线 + 进程内切换', () => {
  afterEach(() => {
    setGuardToggleHook(undefined)
    disposeActiveGuard()
  })

  const mkConfig = (runtimeGuard: 'off' | 'watch'): {
    runtimeGuard: 'off' | 'watch'
    runtimeIntervalMs: number
    runtimeMemLimitMb: number
    runtimeForkBurstN: number
    runtimeFdLimit: number
    runtimeGrowthMb: number
    runtimeGrowthWindowMs: number
    honeypot: { enabled: boolean; dir: string }
    networkEgress: boolean
  } => ({
    runtimeGuard,
    runtimeIntervalMs: 2000,
    runtimeMemLimitMb: 1024,
    runtimeForkBurstN: 5,
    runtimeFdLimit: 512,
    runtimeGrowthMb: 256,
    runtimeGrowthWindowMs: 600_000,
    honeypot: { enabled: false, dir: '' },
    networkEgress: true,
  })

  const mkHandlerCtx = (dir: string): unknown => {
    const routes: unknown[] = []
    return {
      baseUrl: dir,
      get: (name: string) => (name === 'webServer' ? { register: (r: unknown) => { routes.push(r); return () => {} } } : undefined),
      effect: (fn: () => unknown) => { fn() },
      logger: { info: vi.fn(), warn: vi.fn(), error: vi.fn() },
    }
  }
  const mkRes = (): { code: number; body: unknown } & { writableEnded: boolean } => {
    const r = { code: 0, body: null as unknown, writableEnded: false }
    return Object.assign(r, {
      writeHead: (c: number) => { r.code = c },
      end: (b: string) => { r.body = JSON.parse(b) },
    })
  }
  const post = (handler: (req: unknown, res: unknown) => void, body: unknown, origin = true): { code: number; body: unknown } => {
    const res = mkRes()
    const req = {
      method: 'POST',
      url: '/vet/runtime-guard',
      headers: origin ? { origin: 'http://x', host: 'x' } : {},
      on: (ev: string, cb: (c?: Buffer) => void) => {
        if (ev === 'data') cb(Buffer.from(JSON.stringify(body)))
        if (ev === 'end') cb()
      },
    }
    handler(req as never, res as never)
    return res
  }

  it('未注入 hook：同源 POST 仅持久化（旧行为，note 为写路径文案）', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-instant-'))
    const status = new VetStatus()
    const config = { ...mkConfig('off'), profile: 'standard' }
    const routes: unknown[] = []
    const ctx = {
      baseUrl: dir,
      get: (name: string) => (name === 'webServer' ? { register: (r: unknown) => { routes.push(r); return () => {} } } : undefined),
      effect: (fn: () => unknown) => { fn() },
    }
    const ok = registerStatusRouteOnce(ctx as never, config as never, status)
    expect(ok).toBe(true)
    const handler = (routes[0] as { handler: (req: unknown, res: unknown) => void }).handler
    const res = post(handler, { enable: true })
    expect(res.code).toBe(200)
    expect((res.body as { note: string }).note).toContain('已写入')
    expect(readFileSync(join(dir, 'cordis.patch.yml'), 'utf8')).toContain('runtimeGuard: watch')
    rmSync(dir, { recursive: true, force: true })
  })

  it('注入 hook：同源 POST 持久化 + 调 hook + 返回即时生效文案', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-instant-'))
    const status = new VetStatus()
    const config = { ...mkConfig('off'), profile: 'standard' }
    const calls: boolean[] = []
    setGuardToggleHook((enable) => { calls.push(enable); return { ok: true } })
    const routes: unknown[] = []
    const ctx = {
      baseUrl: dir,
      get: (name: string) => (name === 'webServer' ? { register: (r: unknown) => { routes.push(r); return () => {} } } : undefined),
      effect: (fn: () => unknown) => { fn() },
      logger: { info: vi.fn(), warn: vi.fn(), error: vi.fn() },
    }
    registerStatusRouteOnce(ctx as never, config as never, status)
    const handler = (routes[0] as { handler: (req: unknown, res: unknown) => void }).handler
    const res = post(handler, { enable: true })
    expect(res.code).toBe(200)
    expect(calls).toEqual([true])
    expect((res.body as { note: string }).note).toContain('即时开启')
    // 文件已持久化（重启后保持一致）
    expect(readFileSync(join(dir, 'cordis.patch.yml'), 'utf8')).toContain('runtimeGuard: watch')
    rmSync(dir, { recursive: true, force: true })
  })

  it('hook 返回失败：note 提示配置已持久化但即时失败', () => {
    const dir = mkdtempSync(join(tmpdir(), '.tmp-instant-'))
    const status = new VetStatus()
    setGuardToggleHook(() => ({ ok: false, note: 'spawn boom' }))
    const routes: unknown[] = []
    const ctx = {
      baseUrl: dir,
      get: (name: string) => (name === 'webServer' ? { register: (r: unknown) => { routes.push(r); return () => {} } } : undefined),
      effect: (fn: () => unknown) => { fn() },
      logger: { info: vi.fn(), warn: vi.fn(), error: vi.fn() },
    }
    registerStatusRouteOnce(ctx as never, { ...mkConfig('off'), profile: 'standard' } as never, status)
    const handler = (routes[0] as { handler: (req: unknown, res: unknown) => void }).handler
    const res = post(handler, { enable: true })
    expect(res.code).toBe(200)
    expect((res.body as { note: string }).note).toContain('即时生效失败')
    expect((res.body as { note: string }).note).toContain('spawn boom')
    rmSync(dir, { recursive: true, force: true })
  })

  it.skipIf(process.platform === 'win32')('applyRuntimeGuardImmediate：进程内即时切换 watch↔off，config 实时翻转，哨兵随之启停', () => {
    const ctx = { logger: { info: vi.fn(), warn: vi.fn(), error: vi.fn() } }
    const status = new VetStatus()
    const config = mkConfig('off')
    // off → watch：config 翻转 + 哨兵启动
    const r1 = applyRuntimeGuardImmediate(ctx as never, config as never, status, true)
    expect(r1.ok).toBe(true)
    expect(config.runtimeGuard).toBe('watch')
    expect(envSidecarPid()).toBeDefined()
    // watch → off：config 翻转 + 哨兵终止（env 注册表清空）
    const r2 = applyRuntimeGuardImmediate(ctx as never, config as never, status, false)
    expect(r2.ok).toBe(true)
    expect(config.runtimeGuard).toBe('off')
    expect(envSidecarPid()).toBeUndefined()
    // 再打开：重入安全（prevGuardDisposer 卸载旧实例，不叠加）
    const r3 = applyRuntimeGuardImmediate(ctx as never, config as never, status, true)
    expect(r3.ok).toBe(true)
    expect(config.runtimeGuard).toBe('watch')
    expect(envSidecarPid()).toBeDefined()
  })
})
