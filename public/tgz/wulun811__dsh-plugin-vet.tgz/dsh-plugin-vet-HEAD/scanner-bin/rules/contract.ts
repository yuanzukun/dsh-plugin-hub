import { existsSync } from 'node:fs'
import { dirname, join, resolve, relative } from 'node:path'
import type { Finding } from '../protocol.js'

/**
 * round-15 review（R12 越界探测）：manifest 里的路径（dsh.bundle.patch / main）可能被
 * 恶意构造为 `../../../../etc/hosts` 等穿越串——resolve 后落在包根之外，existsSync 就
 * 变成对任意主机路径的「存在性探测」侧信道（探测结果进报告给人看，不直接外泄，但
 * 扫描面必须约束在包根内：包根之外的存在性不在契约判定范围，一律视为「未命中」）。
 */
function existsWithinPkgRoot(pkgRoot: string, p: string): boolean {
  const resolved = resolve(pkgRoot, p)
  const rel = relative(pkgRoot, resolved)
  // 越界（.. 前缀）或绝对路径逃逸 → 不探测
  if (rel.startsWith('..') || rel.startsWith('/') || resolved === pkgRoot) return false
  return existsSync(resolved)
}

/**
 * R12 Cordis/DSH bundle 契约（P-2 计划项，三审后落地）：
 * 对「插件意图」包（依赖 @deepseek-ai/* 或声明 dsh/cordis 字段）做确定性清单检查——
 * 这些是 DSH 加载器会硬校验/真实失败的项，让 scan_plugin 在安装前就能回答
 * 「这插件装上去能不能跑」，而不是等启动时崩溃。
 *
 * 确定性边界（低误报）：只查 manifest 里声明的路径存在性 + 必备字段，不做源码级推断。
 * - dsh.bundle.patch 声明的文件缺失 → high（插件声明自己是 DSH bundle，挂载必失败）；
 *   0.3.13 起声明形态支持字符串或有序数组，形态非法（非字符串/空数组/非字符串项）同样 high
 *   （DSH 0.1.7-rc.1 的 bundlePatchFiles 对这些形态直接抛错）
 * - 无任何可用入口（无 main、无 exports[.]、根也无 index.js 兜底）→ medium
 * - 声明的入口文件缺失 → high（加载抛 ERR_MODULE_NOT_FOUND）
 * - 插件意图包缺 name → medium（审计门槛/OSV 按名归档失效）
 * - engines.node 明确低于 DSH 要求（major < 22）→ info
 * 非插件意图包不判（避免误伤通用 npm 工具包）。generic 官方包同样适用本规则。
 */
export function runContract(content: string, file: string, targetKind?: 'plugin' | 'generic', scanBasis?: 'git' | 'npm'): Finding[] {
  const found: Finding[] = []
  void targetKind
  // scanBasis==='git'：仅源码仓（通常不提交 lib/ 等构建产物），入口声明对照发布物无效 → 缺失降 info 不误报
  const gitBasis = scanBasis === 'git'
  let pkg: Record<string, unknown>
  try {
    pkg = JSON.parse(content) as Record<string, unknown>
  } catch {
    return found
  }
  const deps: Record<string, unknown> = {
    ...(pkg.dependencies as Record<string, unknown> | undefined),
    ...(pkg.peerDependencies as Record<string, unknown> | undefined),
  }
  const hasDshDep = Object.keys(deps).some(k => k.startsWith('@deepseek-ai/'))
  const dshField = pkg.dsh
  const hasBundleDecl = dshField !== undefined || pkg.cordis !== undefined
  if (!hasDshDep && !hasBundleDecl) return found // 非插件意图：不做契约判定

  const pkgRoot = dirname(file)

  // 1) dsh.bundle.patch 声明 vs 实际文件（字符串或有序数组，0.3.13）
  const patch = pickBundlePatch(dshField)
  if (patch === 'invalid') {
    found.push({
      rule: 'R12',
      severity: 'high',
      confidence: 'certain',
      message: 'dsh.bundle.patch 形态非法（DSH 要求字符串或字符串数组）——profile 挂载必失败',
      evidence: JSON.stringify((dshField as Record<string, unknown>).bundle),
      file,
    })
  } else if (patch !== undefined) {
    for (const p of patch) {
      if (!existsWithinPkgRoot(pkgRoot, p)) {
        found.push({
          rule: 'R12',
          severity: 'high',
          confidence: 'certain',
          message: 'DSH bundle 声明的 patch 文件缺失（dsh.bundle.patch=' + p + '）——插件将无法挂载',
          evidence: p,
          file,
        })
      }
    }
  }

  // 2) 包入口：main / exports["."] / 根 index.js 兜底
  const entry = pickEntry(pkg)
  if (entry === undefined && !existsSync(join(pkgRoot, 'index.js'))) {
    found.push({
      rule: 'R12',
      severity: gitBasis ? 'info' : 'medium',
      confidence: 'likely',
      message: (gitBasis ? '（git 基础）' : '') + '无包入口（无 main、无 exports["."]，根目录也无 index.js）——cordis 无法解析插件模块',
      evidence: '',
      file,
    })
  } else if (entry !== undefined && !existsWithinPkgRoot(pkgRoot, entry)) {
    found.push({
      rule: 'R12',
      severity: gitBasis ? 'info' : 'high',
      confidence: 'certain',
      message: (gitBasis ? '（git 基础）入口文件缺失（构建产物通常不提交，非误报来源）：' : '入口文件缺失：') + entry,
      evidence: entry,
      file,
    })
  }

  // 3) 插件意图包缺 name：审计归档/OSV 核对按名失效
  if (typeof pkg.name !== 'string' || pkg.name === '') {
    found.push({
      rule: 'R12',
      severity: 'medium',
      confidence: 'likely',
      message: '插件包缺 name——审计门槛与 OSV 依赖核对按包名归档会失效',
      evidence: '',
      file,
    })
  }

  // 4) engines.node 明确低于 DSH（>=22.19）→ info 提示
  const engines = pkg.engines
  const nodeRange = engines !== undefined && typeof engines === 'object' && engines !== null
    ? (engines as Record<string, unknown>).node
    : undefined
  if (typeof nodeRange === 'string' && nodeMajorBelow22(nodeRange)) {
    found.push({
      rule: 'R12',
      severity: 'info',
      confidence: 'heuristic',
      message: 'engines.node=' + nodeRange + ' 低于 DSH 运行要求（>=22.19），可能不兼容',
      evidence: nodeRange,
      file,
    })
  }
  return found
}

/**
 * dsh.bundle.patch 声明的 patch 文件（按应用顺序）：
 * 字符串 = 单文件；字符串数组 = 有序多层（0.3.13，DSH 0.1.7-rc.1 同步——rc.2 只支持字符串，
 * 官方 @deepseek-ai/dsh-web-app 已在用 5 文件数组）。
 * @returns 路径列表；未声明 → undefined；形态非法（非字符串/非字符串数组/空串项）→ 'invalid'
 *   （DSH bundlePatchFiles 对这些形态直接抛错，profile 挂载必失败）。
 */
function pickBundlePatch(dshField: unknown): string[] | 'invalid' | undefined {
  if (dshField === undefined || typeof dshField !== 'object' || dshField === null) return undefined
  const bundle = (dshField as Record<string, unknown>).bundle
  if (bundle === undefined || typeof bundle !== 'object' || bundle === null) return undefined
  const patch = (bundle as Record<string, unknown>).patch
  if (patch === undefined) return undefined
  if (typeof patch === 'string') return patch !== '' ? [patch] : 'invalid'
  if (!Array.isArray(patch) || patch.length === 0 || !patch.every(p => typeof p === 'string' && p !== '')) {
    return 'invalid'
  }
  return patch as string[]
}

/** 包入口：exports["."]（字符串/flat/条件对象）优先，其次 main；无则 undefined。 */
function pickEntry(pkg: Record<string, unknown>): string | undefined {
  const exp = pkg.exports
  if (typeof exp === 'string' && exp !== '') return exp // round-4：Node 合法形态 "exports": "./index.js"
  if (exp !== undefined && typeof exp === 'object' && exp !== null) {
    const dot = (exp as Record<string, unknown>)['.']
    if (typeof dot === 'string' && dot !== '') return dot
    if (dot !== undefined && typeof dot === 'object' && dot !== null) {
      // round-4：条件对象含 'node'（DSH 运行在 Node，node 条件最常见）——旧列表漏 node
      for (const key of ['node', 'import', 'require', 'default', 'types']) {
        const v = (dot as Record<string, unknown>)[key]
        if (typeof v === 'string' && v !== '') return v
      }
    }
  }
  const main = pkg.main
  return typeof main === 'string' && main !== '' ? main : undefined
}

/** engines.node 主版本是否低于 22（启发式 info 用；解析数字前缀主版本比较，不做完整语义解析）。 */
function nodeMajorBelow22(range: string): boolean {
  let s = range.trim()
  while (s.length > 0 && '><=~^v '.includes(s[0])) s = s.slice(1)
  // round-4：主版本必须按数字前缀解析——旧实现假定两位数（two=s[0]+s[1]），
  // "4.0.0"/"8.17.0"/"2.0.0" 等单数字主版本全部漏检（返回 false 不提示）
  const m = /^\d+/.exec(s)
  if (m === null) return false // 无数字（'*'、''、纯符号）→ 无法判定，不提示
  return Number(m[0]) < 22
}