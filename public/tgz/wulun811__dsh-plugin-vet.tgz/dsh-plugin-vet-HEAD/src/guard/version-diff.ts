/**
 * N6 版本行为差分（Upgrade Behavioral Diff）。
 * 靶子 G4：供应链投毒几乎都发生在"老包的新版本"——每版独立扫描看不到"这一版比上一版多要了什么"。
 * 本模块把 N1 的静态能力清单（CapabilityManifest，声明侧）按 `name@version` 记入本地存储，
 * 同一包出现新版本时与该包上一个版本（按 recordedAt 选取，不引入 semver 依赖）的能力清单做
 * 纯本地 JSON 差分：**只报"能力变了"**（新增敏感能力 → info(蓝)/red），不报"代码变了"。
 * 0.3.6：升级类报警降档聚合——普通新增能力报蓝色 info 观察并聚合为单行（DSH 模块化升级
 * 一次升级几十个官方包，逐包黄牌会刷满 20 槽缓冲），高敏感组合（执行+网络等）仍报 red。
 * 完全离线、alarm-only（N6 只产生报警，从不拦截）。
 *
 * 存储（复用 content-baseline 基建，原子写临时文件 + rename，0600/0700）：
 *   ~/.dsh/vet/capabilities.json   { records: { "<name>@<version>": { name, version, recordedAt, capabilities } } }
 * 规划书写的 `capabilities/<name>@<version>.json` 单文件布局合并为单 JSON 存储：
 * 原子写与 LRU 清理在同一结构内完成、可整库审计，key 仍是 name@version 粒度（实施方案决策）。
 * 存储治理：LRU 保留最近 MAX_KEPT（1000）个版本，超出的按 recordedAt 淘汰最旧。
 * 冷启动：首次安装无旧清单 → 只记录不报警；但新清单含 exec + network 双高组合时给一条
 * yellow `upgrade-cold` 提示，不完全静默。
 * 失效安全：任何内部错误（存储损坏、路径失败）都静默跳过（返回 no-op 结果），不打扰插件加载。
 * @module dsh-plugin-vet/version-diff
 */
import { readFileSync, renameSync, mkdirSync } from 'node:fs'
import { writeTmpExclusive } from './path-utils.js'
import { createHash } from 'node:crypto'
import { join, dirname } from 'node:path'
import type { CapabilityManifest } from '../scanner/protocol.js'
import { withVetSelfIo } from './runtime-hooks.js'
import { vetStoreRoot } from './store-root.js'
import { currentWriter, readWriter, type StoreTamper, type StoreWriter } from './store-stamp.js'
import { hasAuditRecord } from '../audit/archive.js'

export interface CapabilityRecord {
  name: string
  version: string
  recordedAt: number
  capabilities: CapabilityManifest
}

export interface CapabilityStore {
  records: Record<string, CapabilityRecord>
  /** 0.3.15（M7 归因）：本次落盘的 writer 戳（见 store-stamp.ts）。 */
  writer?: StoreWriter
}

/** 差分只关心"新增"（能力收窄是良性，报警只用 added）；布尔字段 = 该能力是否新增。 */
export interface ManifestDelta {
  hosts: string[]
  fsPaths: string[]
  spawnCmds: string[]
  imports: string[]
  /** P0-2 #9：幽灵依赖变化（代码引用但未声明；subset of imports——展示用，不单独抬级报警）。 */
  ghostDeps: string[]
  /** P0-2 #9：僵尸依赖变化（声明但 node_modules 缺失；展示/审计用，不单独抬级报警）。 */
  zombieDeps: string[]
  hasNetwork: boolean
  hasExec: boolean
  /** C4（0.3.8）：原生二进制（预编译 .node/.so/…）新增/移除。展示口径含「首次观察」——
   * 0.3.8 前的存量记录无此字段（undefined），下一版本记录 true 即入列（宁可多报蓝，不静默）。 */
  hasNativeBinary: boolean
  /** C4：新增/移除的原生二进制文件名（basename 差分；「首次观察」时全部计为新增）。 */
  nativeBinaries: string[]
}

export interface VersionDiffAlarm {
  kind: 'upgrade-diff' | 'upgrade-cold'
  severity: 'info' | 'red'
  message: string
}

/** recordScan 的结果：调用方据此决定是否写一条盾牌报警（alarm 为 null = 只记录不报）。 */
export interface VersionDiffOutcome {
  plugin: string
  /** 上一个被记录的版本；冷启动为 null。 */
  from: string | null
  to: string
  /** 相对上一版的新增能力（无旧版时为 null）。 */
  added: ManifestDelta | null
  /** 相对上一版的移除能力（仅审计展示，不报警）。 */
  removed: ManifestDelta | null
  severity: 'info' | 'red' | null
  alarm: VersionDiffAlarm | null
}

/** vet_diff 工具输出：某包的全部版本历史 + 最近两版差分（供审计）。 */
export interface VersionDiffHistory {
  package: string
  records: { version: string; recordedAt: number }[]
  latest: string | null
  prior: string | null
  diff: { from: string; to: string; added: ManifestDelta; removed: ManifestDelta } | null
  note: string | null
}

/** LRU 上限：保留最近 N 个版本（规划 v2：约 1000）。 */
export const VERSION_DIFF_MAX_KEPT = 1000

/**
 * C3（0.1.16 加固）：模块加载时快照 DSH_PLUGIN_VET_BASELINE_DIR——vet 先于第三方插件加载，
 * 进程内插件此后改 env 无法重定向能力清单存储（archive.ts 同款快照语义）。
 * 测试通过 setCapabilitiesDirForTest 覆盖（生产路径不调用；C1 发布物不包含 guard 内部模块）。
 */
const SNAPSHOT_BASELINE_DIR: string | undefined = (() => {
  const v = process.env.DSH_PLUGIN_VET_BASELINE_DIR
  return v !== undefined && v !== '' ? v : undefined
})()

let baselineDirOverride: string | undefined

/** C3（第二轮补漏）：默认目录在模块加载时定值——homedir() 随 $HOME 变，运行时回退可被
 * 进程内插件改 env 重定向（伪造 capabilities.json 预植 N6 基线）。与 archive.ts 同款纪律。
 * 0.3.15：目录统一由 store-root 解析（测试运行时默认落进程私有临时目录，不写用户真实存储）。 */
const SNAPSHOT_DEFAULT_DIR = vetStoreRoot()

/** 存储文件路径：~/.dsh/vet/capabilities.json（快照 env + homedir；测试可用 setCapabilitiesDirForTest 覆盖）。 */
export function capabilitiesPath(): string {
  const dir = baselineDirOverride ?? SNAPSHOT_BASELINE_DIR ?? SNAPSHOT_DEFAULT_DIR
  return join(dir, 'capabilities.json')
}

/** 测试专用：覆盖快照目录（生产路径不调用）。 */
export function setCapabilitiesDirForTest(dir?: string): void {
  baselineDirOverride = dir
}

/** M7（0.1.16 加固）：vet 自写 store 的内容哈希——进程内插件若直接改写 capabilities.json（
 * 中和升级差分/投毒基线），load 时 hash 与自写记录不符 → 记篡改标志。
 * 0.3.15：标志带证据（文件 + 改写方 writer 戳），由 internal/plugin 分流——别的 vet 进程
 * 写的 = 合法多进程写路径（info 观察）；无戳 / 戳为本进程 pid = 进程内篡改（yellow）。 */
const writtenStoreHashes = new Map<string, string>()
let storeTamper: StoreTamper | null = null

/** 加载存储；文件不存在/损坏 → 空存储。文件被外部（非 vet 自写）改写 → 置篡改标志（可消费）。
 * 说明：单条记录损坏（capabilities 缺/非对象，如旧布局残留/手工编辑）**不在此丢弃**——
 * 保留以便 M7 篡改标志可观测；但对账层（diffManifests）有形状守卫：损坏记录不再让
 * recordScan/history/label 抛 TypeError 整包静默（round-4 review H2，守卫见 diffManifests）。 */
export function loadCapabilities(): CapabilityStore {
  return withVetSelfIo(() => {
    try {
      const path = capabilitiesPath()
      const content = readFileSync(path, 'utf8')
      const recorded = writtenStoreHashes.get(path)
      const parsed = JSON.parse(content) as { records?: Record<string, CapabilityRecord>; writer?: unknown }
      if (recorded !== undefined && sha256Of(content) !== recorded) {
        storeTamper = { file: path, foreign: readWriter(parsed.writer) }
      }
      if (parsed.records !== undefined && typeof parsed.records === 'object') {
        return { records: parsed.records as Record<string, CapabilityRecord> }
      }
      return { records: {} }
    } catch {
      // 自写过但文件读不到（被删除/损坏）→ 同样是篡改信号（无 writer 可归因）
      const path = capabilitiesPath()
      if (writtenStoreHashes.has(path)) storeTamper = { file: path, foreign: null }
      return { records: {} }
    }
  })
}

/** 读取并复位篡改证据（一次消费；internal/plugin 完成时按归因分流上报 info/yellow）。 */
export function consumeCapabilitiesTamper(): StoreTamper | null {
  const t = storeTamper
  storeTamper = null
  return t
}

function sha256Of(content: string): string {
  return createHash('sha256').update(content).digest('hex')
}

/** 保存存储（原子写：临时文件 + rename；目录 0700、文件 0600）。保存失败静默（下次重录）。 */
export function saveCapabilities(store: CapabilityStore): void {
  withVetSelfIo(() => {
    try {
      const path = capabilitiesPath()
      try {
        mkdirSync(dirname(path), { recursive: true, mode: 0o700 })
      } catch {
        // 目录已存在
      }
      const tmpPath = path + '.tmp.' + process.pid
      // 0.3.15（M7 归因）：落盘前盖 writer 戳，读回时据此区分「另一个 vet 进程」与「进程内篡改」
      store.writer = currentWriter()
      const serialized = JSON.stringify(store, null, 2)
      writeTmpExclusive(tmpPath, serialized, 0o600)
      renameSync(tmpPath, path)
      writtenStoreHashes.set(path, sha256Of(serialized))
    } catch {
      // 静默：记录失败不阻塞插件加载
    }
  })
}

/** LRU 清理：按 recordedAt 降序保留最近 maxKept 个记录，超出部分删除。
 * round-15：recordedAt 非有限值的损坏记录排到最末直接淘汰（NaN 比较恒 false）。 */
export function pruneCapabilities(store: CapabilityStore, maxKept = VERSION_DIFF_MAX_KEPT): void {
  if (maxKept <= 0) {
    store.records = {}
    return
  }
  const entries = Object.entries(store.records)
  if (entries.length <= maxKept) return
  entries.sort((a, b) => {
    // 0.3.9（审查修复）：单条 null/非对象记录此前直接读 a[1].recordedAt 抛 TypeError →
    // recordScan 的 catch 吞成整包 noop（该包乃至整个 store 的差分永久静默、审计中心空白）。
    const ar = a[1] !== null && typeof a[1] === 'object' && Number.isFinite(a[1].recordedAt) ? a[1].recordedAt : -Infinity
    const br = b[1] !== null && typeof b[1] === 'object' && Number.isFinite(b[1].recordedAt) ? b[1].recordedAt : -Infinity
    return br - ar
  })
  const keptKeys = new Set(entries.slice(0, maxKept).map(e => e[0]))
  for (const key of entries.map(e => e[0])) {
    if (!keptKeys.has(key)) delete store.records[key]
  }
}

/** 上一个版本：同名、异版、recordedAt 最大者（不引入 semver 解析，规划 v2）。
 * round-15：recordedAt 非有限值的损坏记录不参与（否则 NaN 比较恒 false，排序任意）。
 * 0.3.9（审查修复）：单条 null/非对象记录跳过（此前 record.name 直接 TypeError）。 */
export function findPreviousRecord(store: CapabilityStore, name: string, version: string): CapabilityRecord | null {
  let best: CapabilityRecord | null = null
  for (const record of Object.values(store.records)) {
    if (record === null || typeof record !== 'object') continue
    if (record.name !== name || record.version === version) continue
    if (!Number.isFinite(record.recordedAt)) continue
    // >=：同毫秒记录的 tie-break 取后插入者（object key 保持插入序，确定性）
    if (best === null || record.recordedAt >= best.recordedAt) best = record
  }
  return best
}

/** 0.3.9：清单是否「无任何已观测能力」——退化扫描（文件全不可读/全超限等）的产物。
 * 判定任一能力面有值即非空；用于把空清单基线当作「从未观测过」处理（防假红级联）。 */
export function isEmptyManifest(m: unknown): boolean {
  if (m === null || typeof m !== 'object') return true
  const mm = m as Record<string, unknown>
  if (mm.hasNetwork === true || mm.hasExec === true || mm.hasNativeBinary === true) return false
  for (const k of ['hosts', 'fsPaths', 'spawnCmds', 'imports', 'ghostDeps', 'zombieDeps']) {
    if (Array.isArray(mm[k]) && (mm[k] as unknown[]).length > 0) return false
  }
  return true
}

/**
 * 敏感文件路径判定（N6 抬升组合用，0.1.16 M8 加固）：路径段级匹配，不再用宽泛子串——
 * 旧实现 'credentials' 命中 'my-credentials-app' 等普通路径 → red 误抬升。
 * 匹配规则：整段相等，或段以 marker 为前缀/后缀（连字符或点作边界），如 my-credentials、
 * credentials-app、.ssh/config（段 .ssh 整段）。裸 'key'/'token' 等宽泛词仍不入表。
 */
export function isSensitiveFsPath(path: string): boolean {
  // 0.3.9（审查修复）：按 / 与 \ 双分隔分段（Windows 载荷写反斜杠凭据路径时此前整段漏判，
  // native+敏感Fs 等 red 组合随之降 info——实测 C:\Users\x\.ssh\id_rsa 返回 false）。
  const segs = path.toLowerCase().split(/[\\/]/)
  const markers = [
    '.ssh', '.aws', '.dsh', '.gnupg', '.kube',
    'credentials', 'credential', 'authorized_keys',
    'id_rsa', 'id_ed25519', 'id_ecdsa', 'id_dsa',
    '.netrc', '.pgpass', '.git-credentials', '.npmrc',
    'passwd', 'shadow', 'keystore', 'vault',
  ]
  const hit = (s: string, m: string): boolean =>
    s === m || s.startsWith(m + '-') || s.endsWith('-' + m) || s.startsWith(m + '.') || s.endsWith('.' + m)
  return markers.some(m => segs.some(s => hit(s, m)))
}

function arrayDelta(prev: string[], next: string[]): { added: string[]; removed: string[] } {
  // round-21：字段级损坏（手工编辑/篡改落盘记录把某数组字段写成标量）——对象级守卫
  // （diffManifests 的 typeof prev==='object'）与 `?? []` 都拦不住 'abc'.filter 的
  // TypeError，整包差分被 recordScan 的 catch 吞成永久静默（正是 H2 注释承诺消灭的
  // 隐形失效形态）。入口 Array.isArray 归一：非数组按空集处理，差分照常产出。
  const pa = Array.isArray(prev) ? prev : []
  const na = Array.isArray(next) ? next : []
  const p = new Set(pa)
  const n = new Set(na)
  return { added: na.filter(x => !p.has(x)), removed: pa.filter(x => !n.has(x)) }
}

const emptyDelta = (): ManifestDelta => ({
  hosts: [], fsPaths: [], spawnCmds: [], imports: [], ghostDeps: [], zombieDeps: [],
  hasNetwork: false, hasExec: false, hasNativeBinary: false, nativeBinaries: [],
})

/** 两份清单的差分（added/removed；布尔字段 = 是否新增/移除该能力）。
 * round-4 review（H2）：prev/next 非对象（损坏记录/旧布局残留）时返回空差分而非抛
 * TypeError——记录损坏不再是「该包差分永久静默且无提示」的隐形失效（此前 recordScan
 * catch 吞掉 + history/label 也整体报「存储不可读」）；损坏段按无变化处理，不瘫痪对账。 */
export function diffManifests(prev: CapabilityManifest, next: CapabilityManifest): { added: ManifestDelta; removed: ManifestDelta } {
  if (typeof prev !== 'object' || prev === null || typeof next !== 'object' || next === null) {
    return { added: emptyDelta(), removed: emptyDelta() }
  }
  const hosts = arrayDelta(prev.hosts ?? [], next.hosts ?? [])
  const fsPaths = arrayDelta(prev.fsPaths ?? [], next.fsPaths ?? [])
  const spawnCmds = arrayDelta(prev.spawnCmds ?? [], next.spawnCmds ?? [])
  const imports = arrayDelta(prev.imports ?? [], next.imports ?? [])
  const ghostDeps = arrayDelta(prev.ghostDeps ?? [], next.ghostDeps ?? [])
  const zombieDeps = arrayDelta(prev.zombieDeps ?? [], next.zombieDeps ?? [])
  // C4（0.3.8）：原生二进制——清单名差分管展示（首次观察时 prev 无名单 → 全部计新增）；
  // 布尔新增按「prev !== true && next === true」口径（旧记录缺字段视为未观察过，见 ManifestDelta 注）。
  const nativeNames = arrayDelta(prev.nativeBinaries ?? [], next.nativeBinaries ?? [])
  return {
    added: {
      hosts: hosts.added, fsPaths: fsPaths.added, spawnCmds: spawnCmds.added, imports: imports.added,
      ghostDeps: ghostDeps.added, zombieDeps: zombieDeps.added,
      hasNetwork: (prev.hasNetwork === false || prev.hasNetwork === undefined) && next.hasNetwork === true,
      hasExec: (prev.hasExec === false || prev.hasExec === undefined) && next.hasExec === true,
      hasNativeBinary: prev.hasNativeBinary !== true && next.hasNativeBinary === true,
      nativeBinaries: nativeNames.added,
    },
    removed: {
      hosts: hosts.removed, fsPaths: fsPaths.removed, spawnCmds: spawnCmds.removed, imports: imports.removed,
      ghostDeps: ghostDeps.removed, zombieDeps: zombieDeps.removed,
      hasNetwork: prev.hasNetwork === true && next.hasNetwork !== true,
      hasExec: prev.hasExec === true && next.hasExec !== true,
      hasNativeBinary: prev.hasNativeBinary === true && next.hasNativeBinary !== true,
      nativeBinaries: nativeNames.removed,
    },
  }
}

export function hasAnyAddition(delta: ManifestDelta): boolean {
  return delta.hosts.length > 0 || delta.fsPaths.length > 0 || delta.spawnCmds.length > 0 ||
    delta.imports.length > 0 || delta.hasNetwork || delta.hasExec || delta.hasNativeBinary ||
    // 0.3.9（审查修复）：原生二进制**名字**变化必须可见——换血（system.node → evil.node）
    // 此前布尔不翻（prev 已 true）→ hasAnyAddition 恒 false → 升级零报警、vet_diff 也不显示
    // 名字，与「宁可多报蓝、不静默」的自述口径矛盾。
    (delta.nativeBinaries ?? []).length > 0
}

function describeDelta(delta: ManifestDelta): string[] {
  const parts: string[] = []
  for (const h of delta.hosts) parts.push('网络主机 ' + h)
  for (const f of delta.fsPaths) parts.push('敏感路径 ' + f)
  for (const s of delta.spawnCmds) parts.push('子进程 ' + s)
  for (const i of delta.imports) parts.push('新依赖 ' + i + '（能力未知）')
  for (const d of delta.ghostDeps) parts.push('幽灵依赖 ' + d + '（未声明）')
  for (const d of delta.zombieDeps) parts.push('僵尸依赖 ' + d + '（声明但未安装）')
  if (delta.hasNetwork) parts.push('网络能力')
  if (delta.hasExec) parts.push('执行能力')
  // C4（0.3.8）：原生二进制定性词——「预编译、JS 规则面不可静态审」是它区别于其他能力项的点。
  // 0.3.9（审查修复）：列名展示挂在「布尔或名单任一」上——换血场景布尔不翻但名单变了，
  // 此前名字被布尔门挡住（报警消息与 vet_diff 同时静默）。
  if (delta.hasNativeBinary || (delta.nativeBinaries ?? []).length > 0) {
    const names = delta.nativeBinaries ?? []
    parts.push(names.length > 0
      ? '原生二进制 ' + names.slice(0, 3).join('/') + (names.length > 3 ? '…' : '') + '（预编译，不可静态审）'
      : '原生二进制（预编译，不可静态审）')
  }
  return parts
}

/**
 * 升级差分的严重度（0.3.6 改档；0.3.8 组合扩列）：普通新增能力 → info（蓝色观察，不再黄牌——DSH 模块化
 * 升级会一次性升级几十个官方包，逐包黄牌 = 20 槽警报轰炸、盾牌假性持黄；升级是预期事件，
 * 差异详情仍完整留在 vet_diff/营养标签，报警面只留汇总行）；新增构成高敏感组合（执行+网络 /
 * 敏感路径+网络 / 敏感路径+执行 / **原生二进制+网络·执行·敏感路径**）→ red（此组合是供应链投毒
 * 主签名，保持可行动）。C4 注：预编译二进制对 JS 规则面完全不可审，与任何强能力组合即构成
 * 「不可见载荷 + 外联/执行/敏感触点」的投递形态——单独新增 .node 仍是 info（官方平台二进制包
 * 升级会普遍命中，红轰炸违背 0.3.6 口径）。
 */
export function upgradeSeverity(added: ManifestDelta): 'info' | 'red' | null {
  if (!hasAnyAddition(added)) return null
  const sensitiveFs = added.fsPaths.some(isSensitiveFsPath)
  const combo = (added.hasNetwork && added.hasExec) || (added.hasNetwork && sensitiveFs) || (added.hasExec && sensitiveFs)
    || (added.hasNativeBinary && (added.hasNetwork || added.hasExec || sensitiveFs))
  return combo ? 'red' : 'info'
}

function buildUpgradeAlarm(plugin: string, from: string, to: string, added: ManifestDelta): VersionDiffAlarm | null {
  const severity = upgradeSeverity(added)
  if (severity === null) return null
  const parts = describeDelta(added)
  // 0.1.20 A 方案：red 级别 → 明确告知用户需要重新审计（审查完成后警报自动解除）
  // 0.3.6：非组合新增降为 info（蓝色观察，聚合单行）——不再逐包黄牌轰炸
  const suffix = severity === 'red'
    ? '——已构成 高敏感能力组合（执行+网络 / 敏感路径+网络），请让 agent 执行 vet-audit-protocol skill 重新审查（审查完成后警报自动解除）'
    : '——升级观察（N6，蓝色提示，已聚合）'
  return { kind: 'upgrade-diff', severity, message: '升级行为差分：' + plugin + ' ' + from + ' → ' + to + ' 新增 ' + parts.join('；') + suffix }
}

/**
 * 记录一次扫描的能力清单并产出版本差分结果。
 * - 无版本/无清单 → no-op（不写存储）；
 * - 冷启动（无旧版）→ 只记录；exec+network 双高时附 info upgrade-cold 提示（蓝色，已聚合）；
 * - 升级（有旧版）→ 计算差分，新增敏感能力 → upgrade-diff 报警（yellow/red）；
 * - 同版本重录 → 刷新 recordedAt，不差分。
 * fail-open：任何异常返回 no-op，不打扰插件加载。
 */
export function recordScan(
  plugin: string,
  version: string | undefined,
  manifest: CapabilityManifest | undefined | null,
): VersionDiffOutcome {
  const noop: VersionDiffOutcome = {
    plugin, from: null, to: version ?? 'unknown', added: null, removed: null, severity: null, alarm: null,
  }
  if (typeof version !== 'string' || version === '') return noop
  if (manifest === undefined || manifest === null) return noop
  return withVetSelfIo(() => {
    try {
      const store = loadCapabilities()
      const prev = findPreviousRecord(store, plugin, version)
      // round-4 review（H2）：差分必须在写盘之前完成——旧实现先写 store 再 diff，
      // diff 抛错时 catch 返回 no-op，但新记录已落盘（「no-op = 不写存储」的语义被破坏，
      // 且坏数据已固化）。先算差分（纯内存），成功后才写盘；diff 抛错 → 不写、返回 noop。
      // 退化扫描的拦截在调用方（internal-plugin finish：sourceCount===0 且清单为空时不调
      // recordScan，见 internal-plugin 0.3.9 注）——这里不按清单内容猜，避免误伤真正
      // 「旧版无任何能力」的升级（空 1.0.0 → net+exec 2.0.0 应照常 red）。
      let outcome: VersionDiffOutcome
      if (prev === null) {
        // 冷启动：只记录；exec + network 双高组合给一条提示，不完全静默
        // 0.1.20：upgrade-cold 联审计——已有审计档案则不报（用户审查行为有可见回报）
        // 0.3.6：severity 降为 info（蓝色观察，聚合单行），与 upgrade-diff 同桶
        const alarm: VersionDiffAlarm | null =
          manifest.hasNetwork === true && manifest.hasExec === true && !hasAuditRecord(plugin, version)
            ? {
                kind: 'upgrade-cold',
                severity: 'info',
                message: '新安装插件 ' + plugin + '@' + version + ' 声明 执行+网络 双高能力'
                  + (manifest.hasNativeBinary === true ? '（且含原生二进制，不可静态审）' : '')
                  + '（首次记录，无旧版本可差分）——升级观察（N6 冷启动，蓝色提示，已聚合）',
              }
            : null
        outcome = { plugin, from: null, to: version, added: null, removed: null, severity: alarm?.severity ?? null, alarm }
      } else {
        const { added, removed } = diffManifests(prev.capabilities, manifest)
        const alarm = buildUpgradeAlarm(plugin, prev.version, version, added)
        outcome = { plugin, from: prev.version, to: version, added, removed, severity: alarm?.severity ?? null, alarm }
      }
      const key = plugin + '@' + version
      store.records[key] = { name: plugin, version, recordedAt: Date.now(), capabilities: manifest }
      pruneCapabilities(store)
      saveCapabilities(store)
      return outcome
    } catch {
      return noop
    }
  })
}

/** 某包的全部版本历史 + 最近两版差分（vet_diff 工具数据源；只读，不写存储）。
 * round-15 review（corrupt recordedAt）：旧存储里的损坏记录（recordedAt 非有限值）
 * 会让排序产出任意「上一个版本」与假差分——shape 校验按「设计保留」损坏记录，这里
 * 在排序前过滤非有限值（NaN/Infinity 一律丢弃，不参与历史/差分）。 */
export function history(pkg: string): VersionDiffHistory {
  return withVetSelfIo(() => {
    try {
      const store = loadCapabilities()
      // 0.3.9（审查修复）：null/非对象记录跳过（此前 r.name 直接 TypeError → catch 吞成
      // 整表「存储不可读」——一条坏记录瘫痪整个包的版本史/营养标签）。
      const records = Object.values(store.records)
        .filter(r => r !== null && typeof r === 'object' && r.name === pkg && Number.isFinite(r.recordedAt))
        .sort((a, b) => a.recordedAt - b.recordedAt)
      const versions = records.map(r => ({ version: r.version, recordedAt: r.recordedAt }))
      if (records.length === 0) {
        return { package: pkg, records: versions, latest: null, prior: null, diff: null, note: '无任何版本记录（该包尚未被 vet 自动扫描）' }
      }
      if (records.length === 1) {
        return { package: pkg, records: versions, latest: records[0].version, prior: null, diff: null, note: '仅一条版本记录，无旧版本可差分（冷启动：本次之后的下一次升级将产出差分）' }
      }
      const prev = records[records.length - 2]
      const cur = records[records.length - 1]
      const { added, removed } = diffManifests(prev.capabilities, cur.capabilities)
      return {
        package: pkg,
        records: versions,
        latest: cur.version,
        prior: prev.version,
        diff: { from: prev.version, to: cur.version, added, removed },
        note: null,
      }
    } catch {
      return { package: pkg, records: [], latest: null, prior: null, diff: null, note: '能力清单存储不可读' }
    }
  })
}

/** 营养标签数据（M2）：某包的已记录能力清单 + 升级差分摘要（vet label 数据源；只读，不写存储）。 */
export interface CapabilityLabel {
  package: string
  /** 是否存在任何本地记录。 */
  present: boolean
  records: { version: string; recordedAt: number }[]
  latest: string | null
  /** 最新版的能力清单（基于记录里 recordedAt 最晚的一条）。 */
  manifest: CapabilityManifest | null
  /** 最近一次升级差分的简写（无旧版时 null）。 */
  diffSummary: { from: string; to: string | null; added: string[] } | null
  note: string | null
}

/** 某插件包的最新能力标签（vet label 数据源）。只读，不触发扫描、不联网。 */
export function label(pkg: string): CapabilityLabel {
  return withVetSelfIo(() => {
    try {
      const store = loadCapabilities()
      // round-15：recordedAt 非有限值过滤（与 history 同款——损坏记录不参与排序/判定）
      const records = Object.values(store.records)
        .filter(r => r !== null && typeof r === 'object' && r.name === pkg && Number.isFinite(r.recordedAt))
        .sort((a, b) => a.recordedAt - b.recordedAt)
      const versions = records.map(r => ({ version: r.version, recordedAt: r.recordedAt }))
      if (records.length === 0) {
        return { package: pkg, present: false, records: versions, latest: null, manifest: null, diffSummary: null, note: '无任何本地记录——该包尚未被 vet 自动扫描，或用 vet 扫描后才有能力标签可用' }
      }
      const latestRecord = records[records.length - 1]
      let diffSummary: CapabilityLabel['diffSummary'] = null
      let note: string | null = null
      if (records.length === 1) {
        note = '仅一条版本记录，无升级差分可展示（冷启动：之后的下一次升级将产出差分）'
      } else {
        const prev = records[records.length - 2]
        const { added } = diffManifests(prev.capabilities, latestRecord.capabilities)
        const parts = describeDelta(added)
        diffSummary = { from: prev.version, to: latestRecord.version, added: parts }
      }
      return {
        package: pkg,
        present: true,
        records: versions,
        latest: latestRecord.version,
        manifest: latestRecord.capabilities,
        diffSummary,
        note,
      }
    } catch {
      return { package: pkg, present: false, records: [], latest: null, manifest: null, diffSummary: null, note: '能力清单存储不可读' }
    }
  })
}
