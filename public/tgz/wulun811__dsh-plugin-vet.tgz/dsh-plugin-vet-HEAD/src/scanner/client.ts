import { spawn, spawnSync } from 'node:child_process'
import { randomBytes } from 'node:crypto'
import { resolveVetFile } from '../pkg-root.js'
import type { ScanRequest, ScanResponse } from './protocol.js'

/**
 * C3（0.1.16 加固）：宿主侧快照缓存目录 + 进程内随机 nonce。
 * vet 模块加载早于第三方插件（M2 同款快照语义），插件此后改动 process.env 无法重定向缓存；
 * nonce 仅经请求 JSON（stdin）传给 scanner 子进程，同进程插件读不到闭包值 → 预写伪造缓存失败。
 */
const CACHE_NONCE = randomBytes(16).toString('hex')
const CACHE_DIR_INJECT = process.env.DSH_PLUGIN_VET_CACHE_DIR ?? undefined

/** 独立进程 scanner-bin 入口（lib/scanner-bin/index.js），按候选目录解析，兼容 bundle/逐文件形态。 */
const SCANNER_BIN = resolveVetFile('scanner-bin/index.js')

/**
 * 扫描并发上限（技术债偿还，NEXT-GEN-PLAN 前置）：scanner 是每请求一子进程（spawn），
 * 大批量插件同时加载（首次启动解析整个 profile 树）并发 spawn 会打爆进程/句柄。
 * 上限 2 并发，超出排队（FIFO）。scanSync（spawnSync 同步路径）不排队——同步调用
 * 无法让出事件循环，且 deny 路径本就是一次一个，注释记录即可。
 */
const MAX_CONCURRENT_SCANS = 2
let activeScans = 0
const scanQueue: (() => void)[] = []

async function withScanSlot<T>(fn: () => Promise<T>): Promise<T> {
  if (activeScans < MAX_CONCURRENT_SCANS) {
    activeScans++
    try {
      return await fn()
    } finally {
      activeScans--
      pumpScanQueue()
    }
  }
  return new Promise<T>((resolve, reject) => {
    scanQueue.push(() => {
      // 三轮审查修复（并发记账）：排队路径必须自己增减 activeScans 并在完成后 pump。
      // 此前只跑 fn 不记账：pump 的 while 条件看不到新任务占位，一口气放空整个队列，
      // 真实并发远超 MAX_CONCURRENT_SCANS（8 任务仿真峰值实测 7），首次启动批量加载
      // 恰是该上限要防的 spawn 风暴场景。
      void (async () => {
        activeScans++
        try {
          resolve(await fn())
        } catch (error) {
          reject(error)
        } finally {
          activeScans--
          pumpScanQueue()
        }
      })()
    })
  })
}

function pumpScanQueue(): void {
  while (activeScans < MAX_CONCURRENT_SCANS && scanQueue.length > 0) {
    const next = scanQueue.shift()
    if (next === undefined) return
    next()
  }
}

export interface ScanOptions {
  timeoutMs?: number
}

/**
 * 扫描超时预算（round-5 review，B-A5 单源）：按文件数放大、封顶 60s。
 * 曾散落 gate.ts / scan-plugin.ts / internal-plugin.ts 三份拷贝且口径已分歧（gate 支持
 * 显式值优先、另两处把显式配置当下限放大）——统一为：
 *   budget = clamp(max(explicitMs ?? 15_000, files × 2000), 上限)
 * 调用方如需「显式优先」（gate CLI），自行 `explicit ?? scanBudget(files)`。
 * P2-1 背景：engine 的扫描预算 = min(files×2s, 超时-余量)，守卫超时若小于它，
 * 大包会在 engine 发出 R8-skip 前被 kill → 扫描静默失败；放大让 engine 优雅降级。
 */
export function scanBudget(fileCount: number, explicitMs?: number, capMs = 60_000): number {
  const base = Number.isFinite(explicitMs as number) && (explicitMs as number) > 0 ? (explicitMs as number) : 15_000
  return Math.min(Math.max(base, fileCount * 2000), capMs)
}

/** 导出仅供测试（并发上限回归）：生产代码一律走 scan/scanSync。 */
export const _withScanSlotForTest = withScanSlot

/**
 * scanner 子进程启动即崩的可读化诊断（0.2.4 用户机回归）：子进程在 import 阶段崩溃时
 * stdout 为空，上层只能报 JSON 解析错（Unexpected end of JSON input），真因埋在 stderr
 * 尾部。对已知崩溃形态给出点名结论（缺哪个依赖、怎么处置），原始信息保留在后。
 * 导出仅供测试断言，生产代码经 withCrashDiag 使用。
 */
export function describeScannerCrash(stderr: string): string | undefined {
  const missing = /Cannot find package '([^']+)'/.exec(stderr)
  if (missing !== null) {
    return `scanner crashed on startup: missing runtime dependency '${missing[1]}' (reinstall @jieai/dsh-plugin-vet)`
  }
  if (/Cannot find module/.test(stderr)) {
    return 'scanner crashed on startup: module resolution failed (installation incomplete? reinstall @jieai/dsh-plugin-vet)'
  }
  return undefined
}

function withCrashDiag(diag: string | undefined, message: string): string {
  return diag === undefined ? message : `${diag}; ${message}`
}

/** 异步扫描：spawn scanner-bin，请求-响应式，超时 kill（不伪造 verdict）。 */
export async function scan(request: ScanRequest, options: ScanOptions = {}): Promise<ScanResponse> {
  return withScanSlot(() => scanInner(request, options))
}

async function scanInner(request: ScanRequest, options: ScanOptions = {}): Promise<ScanResponse> {
  // round-5 review（B-A2）：timeoutMs 非有限/≤0（CLI 传 NaN、0、负值）回退默认——
  // NaN 会让 setTimeout(NaN)=0ms 立即杀 scanner、spawnSync timeout:NaN 同理。
  const timeoutMs = Number.isFinite(options.timeoutMs as number) && (options.timeoutMs as number) > 0
    ? (options.timeoutMs as number)
    : 15_000
  // P2-1：把宿主计划超时带给 engine——它按 min(files×2s, timeout-余量) 收敛预算，
  // R8-skip 先于本进程的 kill 触发，大包不再报 scan-fail
  const payload: ScanRequest = {
    ...request,
    timeoutMs,
    cacheNonce: CACHE_NONCE,
    ...(CACHE_DIR_INJECT !== undefined && CACHE_DIR_INJECT !== '' ? { cacheDir: CACHE_DIR_INJECT } : {}),
  }
  return new Promise<ScanResponse>(resolve => {
    const child = spawn(process.execPath, [SCANNER_BIN], { stdio: ['pipe', 'pipe', 'pipe'] })
    let stdout = ''
    let stderr = ''
    let done = false
    const finish = (value: ScanResponse): void => {
      if (done) return
      done = true
      clearTimeout(timer)
      resolve(value)
    }
    const timer = setTimeout(() => {
      child.kill('SIGKILL')
      finish({ ok: false, error: `scanner timeout after ${timeoutMs}ms` })
    }, timeoutMs)
    child.stdout.setEncoding('utf8')
    // round-15 review（async 路径无输出上限修复）：stdout 全量缓冲无 cap——被替换/损坏的
    // scanner-bin 可以流式喷出无限输出把宿主内存打爆（sync 路径有 maxBuffer 64MB，async
    // 路径此前没有对等护栏）。扫描报告 ≤ 数百 KB；64MB 上限与 sync 路径同值，超限即按
    // 协议违约处理（kill + 失败，不信任超过上限的输出）。
    const STDOUT_MAX = 64 * 1024 * 1024
    let stdoutOversize = false
    child.stdout.on('data', chunk => {
      if (!stdoutOversize) {
        stdout += chunk
        if (stdout.length > STDOUT_MAX) stdoutOversize = true
      }
    })
    child.stderr.setEncoding('utf8')
    child.stderr.on('data', chunk => {
      stderr += chunk
      if (stderr.length > 8 * 1024 * 1024) stderr = stderr.slice(stderr.length - 8 * 1024 * 1024) // 尾部保留，防模糊排查信息被冲掉
    })
    child.on('error', err => finish({ ok: false, error: String(err) }))
    child.on('close', (code) => {
      // round-15 review（exit code 未检查修复）：close 时若已超量输出 → 不解析（输出不可信）。
      // 另：非零退出码即使 stdout 有合法行也不该被当作成功报告——退出码 0 且 close 无异常
      // 才可能产出可信报告（sync 路径同时检查 status 的既有纪律）。
      if (stdoutOversize) {
        finish({ ok: false, error: withCrashDiag(describeScannerCrash(stderr), `scanner output exceeded ${STDOUT_MAX} bytes`) })
        return
      }
      const line = stdout.trim().split('\n').pop()
      const diag = describeScannerCrash(stderr)
      if (line === undefined) {
        finish({ ok: false, error: withCrashDiag(diag, `scanner produced no output; stderr: ${stderr.slice(0, 200)}`) })
        return
      }
      // 非零退出码：打印了行也不能当成功——可能是崩溃前残留 stdout（R8-skip 超时也靠
      // 进程内返回，正常路径退出码恒 0；非零 = scanner 自身故障，报告不可信）
      if (code !== 0) {
        finish({ ok: false, error: withCrashDiag(diag, `scanner exited non-zero (${code}); stderr: ${stderr.slice(0, 200)}`) })
        return
      }
      try {
        finish(JSON.parse(line) as ScanResponse)
      } catch (err) {
        finish({ ok: false, error: withCrashDiag(diag, `scanner invalid output: ${String(err)}; stderr: ${stderr.slice(0, 200)}`) })
      }
    })
    // scanner-bin 启动失败时 stdin 流可能已销毁：write 抛错/EPIPE 必须兜住，不能崩宿主
    child.stdin.on('error', () => { /* close 事件会走失败分支 */ })
    try {
      child.stdin.write(JSON.stringify(payload))
    } catch (error) {
      // L3: write 抛错（EPIPE/流销毁）时子进程可能还活着——必须 kill，否则成孤儿
      try { child.kill('SIGKILL') } catch { /* 已退出 */ }
      finish({ ok: false, error: `scanner stdin write failed: ${String(error)}` })
      return
    }
    child.stdin.end()
  })
}

/**
 * 同步扫描（spawnSync）：internal/plugin 守卫 deny 路径需要同步判定才能在 observer 内抛错回滚挂载。
 */
export function scanSync(request: ScanRequest, options: ScanOptions = {}): ScanResponse {
  // round-5 review（B-A2）：同 async 路径，非有限/≤0 timeout 回退默认
  const timeoutMs = Number.isFinite(options.timeoutMs as number) && (options.timeoutMs as number) > 0
    ? (options.timeoutMs as number)
    : 15_000
  // P2-1：同 async 路径，把超时带给 engine（deny 同步路径同样受益于 R8-skip 先于 kill）
  const payload: ScanRequest = {
    ...request,
    timeoutMs,
    cacheNonce: CACHE_NONCE,
    ...(CACHE_DIR_INJECT !== undefined && CACHE_DIR_INJECT !== '' ? { cacheDir: CACHE_DIR_INJECT } : {}),
  }
  let result
  try {
    result = spawnSync(process.execPath, [SCANNER_BIN], {
      input: JSON.stringify(payload),
      encoding: 'utf8',
      timeout: timeoutMs,
      maxBuffer: 64 * 1024 * 1024,
    })
  } catch (error) {
    // maxBuffer 超限/参数异常会抛而非返回 → 归为失败，绝不向上抛（deny 守卫同步路径无外层保护）
    return { ok: false, error: `scanner spawnSync failed: ${String(error)}` }
  }
  if (result.status !== 0) {
    const stderrText = String(result.stderr)
    return {
      ok: false,
      error: withCrashDiag(describeScannerCrash(stderrText), `scanner exit ${result.status}: ${stderrText.slice(0, 200)}`),
    }
  }
  try {
    return JSON.parse(result.stdout.trim()) as ScanResponse
  } catch (err) {
    return { ok: false, error: `scanner invalid output: ${String(err)}` }
  }
}
