/**
 * 客户端侧协议类型。⚠ 与 scanner-bin/protocol.ts 保持同步（实现决策：跨构建根目录无法单源共享，
 * 协议测试以 scanner-bin 为准做往返校验）。
 */
export type Language = 'js' | 'ts'
export type Runtime = 'host' | 'sandbox'
export type Severity = 'critical' | 'high' | 'medium' | 'info'
export type Confidence = 'certain' | 'likely' | 'heuristic'
export type Verdict = 'critical' | 'suspicious' | 'clean'

export interface ScanRequest {
  kind: 'code' | 'files'
  language?: Language
  runtime?: Runtime
  code?: string
  files?: string[]
  rules?: Record<string, boolean>
  /** 扫描目标身份：'plugin'（DSH 插件包，严格逃逸判定，默认）| 'generic'（通用代码审计，R3 降级为能力触达面 info）。 */
  targetKind?: 'plugin' | 'generic'
  /** 官方目录成员包（0.3.13/static-v26，与 scanner-bin 同步）：非授权源码产物（构建输出路径、
   * 压缩/打包文件、.d.ts 声明）里的 critical/high 折为 info；第三方（缺省 false）只加标注。 */
  officialFamily?: boolean
  /** 扫描基础（与 scanner-bin 同步）：'git' = 仅源码仓（R12 入口/patch 缺失降 info 不误报）；'npm' = registry tarball 真实发布物（默认）。 */
  scanBasis?: 'git' | 'npm'
  /** 扫描面扩展（与 scanner-bin 同步）：configFiles → R17 !!js 配置检测；instructionFiles → R18 指令/技能注入检测。undefined = 全开。 */
  surface?: { configFiles?: boolean; instructionFiles?: boolean }
  /** OSV 已知漏洞核对（npm 生态）：仅 files 模式且存在 package.json 时生效；严格 opt-in（=== true）。 */
  osv?: boolean
  /** 宿主侧计划超时（与 scanner-bin/protocol.ts 同步）：engine 据此对齐扫描预算（P2-1）。 */
  timeoutMs?: number
  /** P1：传递依赖 OSV 核对（opt-in，默认 false）：调用 upstream-radar CLI 扫描传递依赖树。 */
  transitiveDeps?: boolean
  /** C3（0.1.16 加固）：缓存目录与 key 混淆 nonce——宿主注入，进程内插件不可重定向/预写缓存（与 scanner-bin 协议同步）。 */
  cacheDir?: string
  cacheNonce?: string
}

export interface Finding {
  rule: string
  severity: Severity
  message: string
  evidence: string
  file?: string
  line?: number
  confidence: Confidence
  /** N2：经解码还原的命中。 */
  decodedFrom?: 'base64' | 'hex' | 'charCode' | 'concat' | 'template'
}

/** N2：静态可求值的解码字面量。 */
export interface DecodedLiteral {
  text: string
  method: 'base64' | 'hex' | 'charCode' | 'concat' | 'template'
  line: number
  file?: string
}

/** N1 静态能力清单（与 scanner-bin/protocol.ts 同步）：声明侧事实，非判定。 */
export interface CapabilityManifest {
  hosts: string[]
  fsPaths: string[]
  spawnCmds: string[]
  imports: string[]
  hasNetwork: boolean
  hasExec: boolean
  /** C2（0.1.16 加固）：ESM 具名/命名空间导入内建危险模块（与 scanner-bin 同步）。 */
  esmNamedBuiltins?: boolean
  /** P0-2（0.1.21，R16）：代码引用但 package.json 未声明的"幽灵依赖"（与 scanner-bin 同步）。 */
  ghostDeps?: string[]
  /** P0-2（0.1.21，R16）：package.json 声明但 node_modules 缺失的"僵尸依赖"（与 scanner-bin 同步）。 */
  zombieDeps?: string[]
  /** C4（0.3.8）：包内含预编译原生/二进制模块（.node/.so/.dll/.dylib/.exe/.wasm 等；
   * 文件面证据，见 scanner-bin/protocol.ts 注记）。宿主侧可选——0.3.8 前的存量记录无此字段。 */
  hasNativeBinary?: boolean
  /** C4（0.3.8）：命中的原生二进制文件名（basename，去重，上限 10）。 */
  nativeBinaries?: string[]
}

export interface ScanReport {
  /** 与 scanner-bin/protocol.ts 同步；0.3.3 起 static-v19，round-22 起 static-v20，0.3.8（C4 原生二进制感知）起 static-v21，0.3.9（审查修复批次）起 static-v22，0.3.10（R13 误报治理）起 static-v23，0.3.11（R3 dev/ops 脚本中间态）起 static-v24，0.3.12（R3 根级判定审查修正：相对包根平铺）起 static-v25，0.3.13（DSH 0.1.7-rc.1 同步：R12 数组 patch + 官方包产物降噪）起 static-v26。 */
  engine: 'static-v26'
  sourceCount: number
  findings: Finding[]
  staticScore: number
  verdict: Verdict
  /** N1：文件模式扫描的静态能力清单（code 模式不产出）。 */
  capabilities?: CapabilityManifest
}

export interface ScanResponse {
  ok: boolean
  error?: string
  report?: ScanReport
}
