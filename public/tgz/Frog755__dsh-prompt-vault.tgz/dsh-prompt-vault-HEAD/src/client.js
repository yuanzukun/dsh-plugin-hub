// dsh-prompt-vault client half: 输入框上方的 Prompt 库（ModuleLoader bundle 格式）。
// 由动态插件 pvault-2 固化而来。
//
//  - conversation.input.left  -> 📚 触发按钮（输入框工具行）
//  - conversation.input.dock  -> 展开面板（输入框上方整行，关闭时渲染 null）
//  - 数据走 Host 半 HTTP 端点：/__prompt-vault/list | save | delete
//  - 填入输入框用官方 inputActions.setDraft（已有草稿时追加不覆盖）

window.__ModuleLoader__.load({
  id: "@frog755/dsh-prompt-vault",
  factory: function (require) {
    var module = { exports: {} };
    var exports = module.exports;

    var React = require("react");
    var h = React.createElement;

    // ---- HTTP 辅助 ----------------------------------------------------------

    function requestJson(url, options) {
      return fetch(url, options).then(function (r) {
        if (!r.ok) {
          return r.text().then(function (body) {
            var snippet = body ? body.slice(0, 200) : "";
            throw new Error("HTTP " + r.status + " for " + url + (snippet ? ": " + snippet : ""));
          });
        }
        return r.json().catch(function () {
          throw new Error("non-JSON response for " + url);
        });
      });
    }

    function apiList() {
      return requestJson("/__prompt-vault/list");
    }

    function apiRpc(method, args) {
      return requestJson("/__prompt-vault/" + method, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(args || {}),
      });
    }

    // ---- 样式 ----------------------------------------------------------------

    var CSS = [
      ".pv-trigger{display:inline-flex;align-items:center;justify-content:center;height:26px;min-width:28px;padding:0 7px;border:1px solid transparent;border-radius:7px;background:transparent;color:var(--dsw-alias-label-secondary);font-size:14px;line-height:1;cursor:pointer;}",
      ".pv-trigger:hover{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);}",
      ".pv-trigger--active{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-brand-primary);border-color:var(--dsw-alias-border-l1);}",
      ".pv-dock{padding:6px 14px 2px;}",
      ".pv-panel{width:100%;max-width:760px;margin:0 auto;display:flex;flex-direction:column;border:1px solid var(--dsw-alias-border-l1);border-radius:12px;background:var(--dsw-alias-bg-overlay);box-shadow:0 10px 32px rgba(0,0,0,.28);overflow:hidden;}",
      ".pv-head{display:flex;align-items:center;gap:8px;padding:8px 12px;border-bottom:1px solid var(--dsw-alias-border-l1);}",
      ".pv-head-title{font-size:13px;font-weight:600;color:var(--dsw-alias-label-primary);white-space:nowrap;}",
      ".pv-count{font-size:11px;color:var(--dsw-alias-label-secondary);background:var(--dsw-alias-bg-layer-2);border-radius:999px;padding:1px 8px;}",
      ".pv-head-spacer{flex:1;}",
      ".pv-list{overflow-y:auto;max-height:300px;}",
      ".pv-empty{padding:20px;text-align:center;color:var(--dsw-alias-label-secondary);font-size:12px;}",
      ".pv-item{border-bottom:1px solid var(--dsw-alias-border-l1);}",
      ".pv-item:last-child{border-bottom:none;}",
      ".pv-item-head{display:flex;align-items:center;gap:6px;padding:6px 10px;}",
      ".pv-caret{flex:none;display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;border:none;border-radius:5px;background:transparent;color:var(--dsw-alias-label-secondary);font-size:11px;cursor:pointer;}",
      ".pv-caret:hover{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);}",
      ".pv-item-main{flex:1;min-width:0;cursor:pointer;padding:2px 0;}",
      ".pv-item-title{font-size:13px;font-weight:500;color:var(--dsw-alias-label-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}",
      ".pv-item-main:hover .pv-item-title{color:var(--dsw-alias-brand-primary);}",
      ".pv-item-sub{font-size:11px;color:var(--dsw-alias-label-secondary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px;}",
      ".pv-item-ops{display:flex;gap:4px;opacity:.35;transition:opacity .12s;}",
      ".pv-item:hover .pv-item-ops{opacity:1;}",
      ".pv-mini{font-size:11px;padding:2px 8px;border-radius:6px;border:1px solid var(--dsw-alias-border-l1);background:transparent;color:var(--dsw-alias-label-secondary);cursor:pointer;white-space:nowrap;}",
      ".pv-mini:hover{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-2);}",
      ".pv-mini--danger:hover{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary);}",
      ".pv-item-body{padding:0 10px 8px 26px;}",
      ".pv-content{margin:0;padding:8px 10px;background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l1);border-radius:8px;font-size:12px;line-height:1.55;color:var(--dsw-alias-label-secondary);white-space:pre-wrap;word-break:break-word;max-height:180px;overflow:auto;font-family:inherit;}",
      ".pv-item-actions{display:flex;gap:6px;margin-top:6px;}",
      ".pv-btn{font-size:12px;padding:4px 12px;border-radius:7px;border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);cursor:pointer;white-space:nowrap;}",
      ".pv-btn:hover{border-color:var(--dsw-alias-border-l2);}",
      ".pv-btn--primary{background:var(--dsw-alias-brand-primary);border-color:var(--dsw-alias-brand-primary);color:#fff;}",
      ".pv-btn--danger{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary);background:transparent;}",
      ".pv-btn--ghost{background:transparent;}",
      ".pv-editor{padding:10px 12px;display:flex;flex-direction:column;gap:8px;border-bottom:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-layer-1);}",
      ".pv-editor-ops{display:flex;gap:8px;}",
      ".pv-input,.pv-textarea{width:100%;box-sizing:border-box;background:var(--dsw-alias-bg-layer-2);border:1px solid var(--dsw-alias-border-l2);border-radius:8px;padding:6px 9px;font-size:12px;color:var(--dsw-alias-label-primary);font-family:inherit;}",
      ".pv-textarea{resize:vertical;min-height:90px;line-height:1.5;}",
      ".pv-input:focus,.pv-textarea:focus{outline:none;border-color:var(--dsw-alias-brand-primary);}",
      ".pv-search{width:170px;flex:none;}",
      ".pv-confirm{display:flex;align-items:center;gap:8px;padding:7px 10px;background:var(--dsw-alias-bg-layer-1);font-size:12px;color:var(--dsw-alias-label-secondary);}",
      ".pv-error{padding:6px 12px;font-size:12px;color:var(--dsw-alias-state-error-primary);}"
    ].join("\n");

    // ---- 共享状态 ------------------------------------------------------------

    var store = {
      open: false,
      items: null,
      error: "",
      loading: false,
      subs: new Set(),
      emit: function () { this.subs.forEach(function (fn) { fn(); }); },
      setOpen: function (v) { this.open = v; this.emit(); },
      setItems: function (items) { this.items = items; this.error = ""; this.emit(); },
      setError: function (msg) { this.error = msg; this.emit(); },
      setLoading: function (v) { this.loading = v; this.emit(); }
    };

    function refresh() {
      if (store.loading) return;
      store.setLoading(true);
      apiList().then(function (res) {
        store.setItems((res && res.items) || []);
      }).catch(function (e) {
        store.setError(String((e && e.message) || e));
      }).then(function () {
        store.setLoading(false);
      });
    }

    function rpc(method, args) {
      return apiRpc(method, args).then(function (res) {
        store.setItems((res && res.items) || []);
        return res;
      }).catch(function (e) {
        var msg = String((e && e.message) || e);
        store.setError(msg);
        throw e;
      });
    }

    function useStore() {
      var force = React.useState(0)[1];
      React.useEffect(function () {
        var fn = function () { force(function (n) { return n + 1; }); };
        store.subs.add(fn);
        return function () { store.subs.delete(fn); };
      }, []);
    }

    // ---- 组件 ----------------------------------------------------------------

    function Trigger() {
      useStore();
      return h("button", {
        type: "button",
        className: "pv-trigger" + (store.open ? " pv-trigger--active" : ""),
        title: "Prompt 库（展开 / 收起）",
        onClick: function () {
          var next = !store.open;
          store.setOpen(next);
          if (next && store.items === null && !store.loading) refresh();
        }
      }, "\uD83D\uDCDA");
    }

    function Panel(props) {
      useStore();
      var editorState = React.useState(null);
      var expandedState = React.useState(null);
      var confirmState = React.useState(null);
      var queryState = React.useState("");
      if (!store.open) return null;
      var actions = props.inputActions;
      var draft = (props.input && typeof props.input.draft === "string") ? props.input.draft : "";
      var editor = editorState[0], setEditor = editorState[1];
      var expanded = expandedState[0], setExpanded = expandedState[1];
      var confirmId = confirmState[0], setConfirmId = confirmState[1];
      var query = queryState[0], setQuery = queryState[1];
      var items = store.items;

      function insert(content) {
        if (!actions || typeof actions.setDraft !== "function") return;
        var base = draft.replace(/\s+$/, "");
        actions.setDraft(base ? base + "\n\n" + content : content);
        store.setOpen(false);
      }

      var children = [];

      children.push(h("div", { className: "pv-head", key: "head" },
        h("span", { className: "pv-head-title" }, "\uD83D\uDCDA Prompt \u5E93"),
        items !== null ? h("span", { className: "pv-count" }, String(items.length)) : null,
        h("span", { className: "pv-head-spacer" }),
        h("input", {
          className: "pv-input pv-search",
          placeholder: "\u641C\u7D22\u2026",
          value: query,
          onChange: function (e) { setQuery(e.target.value); }
        }),
        h("button", {
          type: "button", className: "pv-btn pv-btn--primary",
          onClick: function () { setExpanded(null); setEditor({ id: "", title: "", content: "" }); }
        }, "\uFF0B \u65B0\u5EFA"),
        h("button", {
          type: "button", className: "pv-btn pv-btn--ghost", title: "\u6536\u8D77",
          onClick: function () { store.setOpen(false); }
        }, "\u2715")
      ));

      if (store.error) {
        children.push(h("div", { className: "pv-error", key: "err" }, "\u26A0 " + store.error));
      }

      if (store.loading && items === null) {
        children.push(h("div", { className: "pv-empty", key: "loading" }, "\u52A0\u8F7D\u4E2D\u2026"));
      } else if (editor) {
        children.push(h("div", { className: "pv-editor", key: "editor" },
          h("input", {
            className: "pv-input",
            placeholder: "\u4E3B\u9898\u540D\uFF08\u968F\u4FBF\u8D77\uFF0C\u968F\u65F6\u53EF\u6539\uFF09",
            value: editor.title,
            onChange: function (e) { setEditor({ id: editor.id, title: e.target.value, content: editor.content }); }
          }),
          h("textarea", {
            className: "pv-textarea",
            rows: 6,
            placeholder: "Prompt \u5B8C\u6574\u5185\u5BB9\u2026",
            value: editor.content,
            onChange: function (e) { setEditor({ id: editor.id, title: editor.title, content: e.target.value }); }
          }),
          h("div", { className: "pv-editor-ops" },
            h("button", {
              type: "button", className: "pv-btn pv-btn--primary",
              onClick: function () {
                if (!editor.content.trim()) return;
                var title = editor.title.trim() || "\u672A\u547D\u540D";
                rpc("save", { id: typeof editor.id === "string" ? editor.id : "", title: title, content: editor.content })
                  .then(function () { setEditor(null); })
                  .catch(function () {});
              }
            }, "\u4FDD\u5B58"),
            h("button", { type: "button", className: "pv-btn", onClick: function () { setEditor(null); } }, "\u53D6\u6D88")
          )
        ));
      } else if (items === null) {
        children.push(h("div", { className: "pv-empty", key: "idle" }, "\u52A0\u8F7D\u4E2D\u2026"));
      } else {
        var q = query.trim().toLowerCase();
        var visible = q ? items.filter(function (it) {
          return ((it.title || "") + "\n" + (it.content || "")).toLowerCase().indexOf(q) >= 0;
        }) : items;
        if (visible.length === 0) {
          children.push(h("div", { className: "pv-empty", key: "empty" },
            items.length === 0
              ? "\u8FD8\u6CA1\u6709 prompt\uFF0C\u70B9\u53F3\u4E0A\u89D2\u300C\uFF0B \u65B0\u5EFA\u300D\u6DFB\u52A0\u4E00\u6761\u3002"
              : "\u6CA1\u6709\u5339\u914D\u7684 prompt\u3002"));
        } else {
          var rows = visible.map(function (item) {
            var isOpen = expanded === item.id;
            var preview = ((item.content || "").split("\n")[0] || "").slice(0, 120);
            var parts = [h("div", { className: "pv-item-head", key: "head" },
              h("button", {
                type: "button", className: "pv-caret",
                title: isOpen ? "\u6536\u8D77" : "\u5C55\u5F00\u8BE6\u60C5",
                onClick: function (e) { e.stopPropagation(); setExpanded(isOpen ? null : item.id); }
              }, isOpen ? "\u25BE" : "\u25B8"),
              h("div", {
                className: "pv-item-main",
                title: "\u70B9\u51FB\u628A\u8FD9\u6761 prompt \u586B\u5165\u8F93\u5165\u6846",
                onClick: function () { insert(item.content || ""); }
              },
                h("div", { className: "pv-item-title" }, item.title || "\u672A\u547D\u540D"),
                h("div", { className: "pv-item-sub" }, preview)
              ),
              h("div", { className: "pv-item-ops" },
                h("button", {
                  type: "button", className: "pv-mini",
                  onClick: function (e) { e.stopPropagation(); setEditor({ id: item.id, title: item.title || "", content: item.content || "" }); }
                }, "\u7F16\u8F91"),
                h("button", {
                  type: "button", className: "pv-mini pv-mini--danger",
                  onClick: function (e) { e.stopPropagation(); setConfirmId(item.id); setExpanded(null); }
                }, "\u5220\u9664")
              )
            )];
            if (isOpen) {
              parts.push(h("div", { className: "pv-item-body", key: "body" },
                h("pre", { className: "pv-content" }, item.content || ""),
                h("div", { className: "pv-item-actions" },
                  h("button", {
                    type: "button", className: "pv-btn pv-btn--primary",
                    onClick: function () { insert(item.content || ""); }
                  }, "\u23CE \u63D2\u5165\u5230\u8F93\u5165\u6846")
                )
              ));
            }
            if (confirmId === item.id) {
              parts.push(h("div", { className: "pv-confirm", key: "confirm" },
                h("span", null, "\u5220\u9664\u300C" + (item.title || "\u672A\u547D\u540D") + "\u300D\uFF1F"),
                h("span", { className: "pv-head-spacer" }),
                h("button", {
                  type: "button", className: "pv-btn pv-btn--danger",
                  onClick: function () { rpc("delete", { id: item.id }).then(function () { setConfirmId(null); }).catch(function () {}); }
                }, "\u786E\u8BA4\u5220\u9664"),
                h("button", { type: "button", className: "pv-btn pv-btn--ghost", onClick: function () { setConfirmId(null); } }, "\u53D6\u6D88")
              ));
            }
            return h("div", { className: "pv-item", key: item.id }, parts);
          });
          children.push(h("div", { className: "pv-list", key: "list" }, rows));
        }
      }

      return h("div", { className: "pv-dock" }, h("div", { className: "pv-panel" }, children));
    }

    // ---- apply ----------------------------------------------------------------

    function apply(ctx) {
      var slots = ctx.slots;
      if (slots === undefined) return;

      var styleEl = document.createElement("style");
      styleEl.textContent = CSS;
      document.head.appendChild(styleEl);
      ctx.effect(function () {
        return function () {
          if (styleEl.parentNode) styleEl.parentNode.removeChild(styleEl);
        };
      });

      slots.inject("conversation.input.left", function () {
        return slots.register(
          { name: "conversation.input.left", id: "prompt-vault-trigger", order: 10, label: "Prompt \u5E93" },
          Trigger
        );
      });
      slots.inject("conversation.input.dock", function () {
        return slots.register(
          { name: "conversation.input.dock", id: "prompt-vault-panel", order: 100, label: "Prompt \u5E93\u9762\u677F" },
          Panel
        );
      });

      console.log("[prompt-vault] client ready");
    }

    exports.apply = apply;
    exports.inject = ["slots"];
    return module.exports;
  }
});
