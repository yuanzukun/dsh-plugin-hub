// dsh-prompt-vault Host 半：Prompt 提示词库的存储与 HTTP 端点。
// 由动态插件 pvault-2 固化而来（数据文件沿用 ~/.dsh/prompt-library.json）。
//
// ESM 模块格式（cordis bundle rule）：named exports apply/inject/name。
// 端点（复用 hybrid-memory / session-delete 已验证的 webServer 模式）：
//   GET  /__prompt-vault/list    -> { items }
//   POST /__prompt-vault/save    { id?, title, content } -> { items }
//   POST /__prompt-vault/delete  { id }                  -> { items }
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const name = 'prompt-vault'
const inject = []

function storageFile() {
  return (
    process.env.DSH_PROMPT_VAULT_FILE ||
    path.join(os.homedir(), '.dsh', 'prompt-library.json')
  )
}

// 全新安装时的示例数据（可在面板里编辑或删除）。
const SEED = [
  {
    id: 'p-seed-review',
    title: '示例 · 代码审查',
    content:
      '请审查下面这段代码，重点关注：\n1. 正确性与边界情况\n2. 可读性与命名\n3. 潜在的性能问题\n\n请给出具体、可执行的修改建议：\n\n（在这里粘贴代码）',
  },
  {
    id: 'p-seed-translate',
    title: '示例 · 中英互译',
    content:
      '请把下面的内容翻译成中文（若原文是英文）或英文（若原文是中文），专业术语保留原文，语气自然流畅：\n\n（在这里粘贴内容）',
  },
]

let cache = null

function blankDoc() {
  const now = Date.now()
  return {
    version: 1,
    items: SEED.map(function (s) {
      return { id: s.id, title: s.title, content: s.content, createdAt: now, updatedAt: now }
    }),
  }
}

async function persist(doc) {
  const file = storageFile()
  await fs.promises.mkdir(path.dirname(file), { recursive: true })
  await fs.promises.writeFile(file, JSON.stringify(doc, null, 2), 'utf8')
}

async function loadAll() {
  if (cache) return cache
  let text = null
  try {
    text = await fs.promises.readFile(storageFile(), 'utf8')
  } catch (e) {
    text = null
  }
  if (typeof text === 'string' && text.length > 0) {
    if (text.charCodeAt(0) === 0xfeff) text = text.slice(1)
    try {
      const parsed = JSON.parse(text)
      if (parsed && Array.isArray(parsed.items)) {
        cache = { version: 1, items: parsed.items }
        return cache
      }
    } catch (e) {
      console.error('[prompt-vault] storage file corrupt, reseeding:', String(e))
    }
  }
  cache = blankDoc()
  try {
    await persist(cache)
  } catch (e) {
    console.error('[prompt-vault] seed write failed:', String(e))
  }
  return cache
}

function clamp(v, max) {
  if (typeof v !== 'string') return ''
  return v.length > max ? v.slice(0, max) : v
}

async function listAll() {
  const doc = await loadAll()
  return { items: doc.items }
}

async function saveOne(args) {
  const doc = await loadAll()
  const title = clamp(args && args.title, 120).trim() || '未命名'
  const content = clamp(args && args.content, 80000)
  const now = Date.now()
  const id = args && typeof args.id === 'string' ? args.id : ''
  if (id) {
    const it = doc.items.find(function (x) { return x && x.id === id })
    if (it) {
      it.title = title
      it.content = content
      it.updatedAt = now
      await persist(doc)
      return { items: doc.items }
    }
  }
  const newId = 'p' + now.toString(36) + Math.floor(Math.random() * 1679616).toString(36)
  doc.items.unshift({ id: newId, title: title, content: content, createdAt: now, updatedAt: now })
  await persist(doc)
  return { items: doc.items }
}

async function deleteOne(args) {
  const doc = await loadAll()
  const id = args && typeof args.id === 'string' ? args.id : ''
  const next = doc.items.filter(function (x) { return x && x.id !== id })
  if (next.length !== doc.items.length) {
    doc.items = next
    await persist(doc)
  }
  return { items: doc.items }
}

function apply(ctx) {
  // 每次激活都重新读盘，避免拿到旧进程的内存缓存。
  cache = null

  const registerHttp = (host, targetCtx) => {
    const sendJson = (res, status, obj) => {
      const body = JSON.stringify(obj)
      res.writeHead(status, {
        'content-type': 'application/json; charset=utf-8',
        'content-length': Buffer.byteLength(body),
      })
      res.end(body)
    }
    const readBody = async (req) => {
      let body = ''
      try {
        for await (const chunk of req) body += chunk
      } catch (e) { /* ignore */ }
      let args = {}
      try { if (body) args = JSON.parse(body) } catch (e) { /* bad json */ }
      return args
    }

    targetCtx.effect(() => host.register({
      kind: 'exact',
      path: '/__prompt-vault/list',
      handler: async (req, res) => {
        if (req.method !== 'GET') return sendJson(res, 405, { error: 'method not allowed' })
        try {
          sendJson(res, 200, await listAll())
        } catch (e) {
          sendJson(res, 500, { ok: false, error: e.message })
        }
      },
    }))

    targetCtx.effect(() => host.register({
      kind: 'exact',
      path: '/__prompt-vault/save',
      handler: async (req, res) => {
        if (req.method !== 'POST') return sendJson(res, 405, { error: 'method not allowed' })
        try {
          sendJson(res, 200, await saveOne(await readBody(req)))
        } catch (e) {
          sendJson(res, 500, { ok: false, error: e.message })
        }
      },
    }))

    targetCtx.effect(() => host.register({
      kind: 'exact',
      path: '/__prompt-vault/delete',
      handler: async (req, res) => {
        if (req.method !== 'POST') return sendJson(res, 405, { error: 'method not allowed' })
        try {
          sendJson(res, 200, await deleteOne(await readBody(req)))
        } catch (e) {
          sendJson(res, 500, { ok: false, error: e.message })
        }
      },
    }))
  }

  const ws = ctx.get('webServer')
  if (ws !== undefined) {
    registerHttp(ws, ctx)
  } else {
    ctx.inject(['webServer'], (sub) => registerHttp(sub.webServer, sub))
  }

  console.log('[prompt-vault] host ready, storage at', storageFile())
}

export { apply, inject, name }
