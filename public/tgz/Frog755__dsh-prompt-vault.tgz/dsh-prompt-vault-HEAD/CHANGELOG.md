# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.2] - 2026-08-26

### Added

- Real screenshot of the Prompt Library panel in both READMEs (`assets/screenshot-panel.png`)

### Changed

- Declare marketplace screenshots through `screenshots.json` (own-repo scheme)
- Add `.gitattributes` for LF line-ending normalization
- Bump to `1.0.2` (docs/assets only)

## [1.0.1] - 2026-08-22

### Changed

- Include English README and changelog in the published npm package (`files` field)
- CI: validate the `dsh.bundle.patch` manifest on push and PR

## [1.0.0] - 2026-08-22

### Added

- 📚 composer toolbar button (`conversation.input.left`) toggling the prompt panel
- Expandable panel above the input box (`conversation.input.dock`) listing saved prompts
- Click an entry to fill the whole prompt into the composer draft (appends, never overwrites)
- Create / edit / delete (with confirmation) / search
- Host-side JSON file persistence at `~/.dsh/prompt-library.json`
- `DSH_PROMPT_VAULT_FILE` environment variable to override the storage path
- Two seed prompts (code review / translation) on first run
- HTTP endpoints `/__prompt-vault/list`, `/__prompt-vault/save`, `/__prompt-vault/delete`
