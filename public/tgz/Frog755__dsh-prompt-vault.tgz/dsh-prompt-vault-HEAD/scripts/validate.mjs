#!/usr/bin/env node
/**
 * Manifest validation for @frog755/dsh-prompt-vault.
 * Checks the DSH bundle contract that makes the package installable via
 * `dsh plugin add`, plus the file list declared in package.json.
 */
import { accessSync, readFileSync } from 'node:fs'
import { resolve, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')

let failures = 0
const fail = (msg) => {
  failures += 1
  console.error(`✗ ${msg}`)
}
const ok = (msg) => console.log(`✓ ${msg}`)

// 1. package.json parses and declares a dsh.bundle patch
let pkg
try {
  pkg = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'))
  ok('package.json parses')
} catch (e) {
  fail(`package.json is not valid JSON: ${e.message}`)
  process.exit(1)
}

const patch = pkg?.dsh?.bundle?.patch
if (typeof patch === 'string' && patch.length > 0) {
  ok(`dsh.bundle.patch = ${patch}`)
} else {
  fail('missing dsh.bundle.patch — package is not installable via dsh plugin add')
}

// 2. The bundle patch file exists next to the manifest
if (patch) {
  try {
    accessSync(resolve(root, patch))
    ok(`bundle patch file exists: ${patch}`)
  } catch {
    fail(`bundle patch file missing: ${patch}`)
  }
}

// 3. Files declared in the "files" field exist
if (Array.isArray(pkg.files)) {
  for (const f of pkg.files) {
    try {
      accessSync(resolve(root, f))
      ok(`files: ${f}`)
    } catch {
      fail(`declared file missing: ${f}`)
    }
  }
} else {
  fail('package.json has no "files" field')
}

// 4. Cordis patch YAML references a name matching the package
if (patch) {
  try {
    const yaml = readFileSync(resolve(root, patch), 'utf8')
    const m = yaml.match(/name:\s*['"]?([^'"\n]+)['"]?\s*$/m)
    if (m && pkg.name && m[1].trim() === pkg.name) {
      ok(`bundle patch name matches package: ${pkg.name}`)
    } else {
      fail(`bundle patch name (${m ? m[1].trim() : 'none'}) != package name (${pkg.name})`)
    }
  } catch {
    fail(`cannot read bundle patch: ${patch}`)
  }
}

if (failures > 0) {
  console.error(`\n${failures} validation failure(s)`)
  process.exit(1)
}
console.log('\nAll manifest checks passed.')
