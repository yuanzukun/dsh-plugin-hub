# @frog755/dsh-prompt-vault

Prompt Vault — a prompt library right above the input box of DeepSeek Harness (DSH). Inspired by voyager's Prompt Vault.

<p align="center">
  <img src="assets/screenshot-panel.png" alt="Prompt Vault panel" width="860">
</p>

- A **📚 button** on the left of the composer toolbar toggles a prompt list panel above the input box
- Each entry shows its title plus a one-line preview; **clicking an entry fills the whole prompt into the composer** (appends to an existing draft, never overwrites it)
- **▸** expands the full content; create / edit / delete (with confirmation) / search are all supported
- Data is persisted to `~/.dsh/prompt-library.json` (override with the `DSH_PROMPT_VAULT_FILE` environment variable)
- Ships with two example prompts (code review / translation) on first run — edit or delete them freely

## Install

**Prerequisites:** DSH installed (`dsh web` runs), Node.js ≥ 20.

```sh
npx -y --package @deepseek-ai/dsh dsh plugin --profile web add @frog755/dsh-prompt-vault
```

Then **hard-refresh the browser** (Cmd/Ctrl+Shift+R) and the 📚 button appears in the composer toolbar.

> This command registers the dependency, detects the package's `dsh.bundle.patch` (`cordis.patch.yml`), and mounts it into `dsh.profile.bundles`. The plugin ships as an npm package and **does not modify DSH source code**.

## Update

```sh
npx -y --package @deepseek-ai/dsh dsh plugin --profile web update @frog755/dsh-prompt-vault
```

Then hard-refresh the browser. Client changes hot-reload without a restart; host-half changes need a DSH restart.

## Uninstall

```sh
npx -y --package @deepseek-ai/dsh dsh plugin --profile web remove @frog755/dsh-prompt-vault
```

The data file `~/.dsh/prompt-library.json` is kept.

## Data file

| Item | Value |
| --- | --- |
| Default path | `~/.dsh/prompt-library.json` |
| Override | `DSH_PROMPT_VAULT_FILE` environment variable |
| Format | `{ version, items: [{ id, title, content, createdAt, updatedAt }] }` |

## Structure

| File | Purpose |
| --- | --- |
| `src/index.js` | Host half: `/__prompt-vault/list·save·delete` HTTP endpoints + JSON file storage |
| `src/client.js` | Client half (ModuleLoader bundle): 📚 button + expandable panel; fills the composer via `inputActions.setDraft` |
| `cordis.patch.yml` | Bundle patch: inserts the `prompt-vault` row into the profile roster |

## From source / development (optional)

1. Add to `dependencies` in `~/.dsh/profiles/web/package.json`:
   `"@frog755/dsh-prompt-vault": "link:C:/path/to/dsh-prompt-vault"`
2. Run `pnpm install` in `~/.dsh/profiles/web`
3. Restart DSH (a new bundle enters the boot graph on host restart; afterwards client.js changes hot-reload)

## License

[MIT](LICENSE)
