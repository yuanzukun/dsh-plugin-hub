/**
 * Minesweeper canvas renderer: the mine grid (hidden tiles, glowing numbers,
 * flags), a mine-counter HUD, and win/game-over overlays — all on the shared
 * theme kit. Score-side effects are render-side observations only.
 */
import type { MinesweeperState } from './logic.ts';
export declare const CELL = 30;
export declare const HUD_H = 30;
export declare const BOARD_W: number;
export declare const BOARD_H: number;
export declare const LOGICAL_W: number;
export declare const LOGICAL_H: number;
/**
 * Draw one frame.
 * @param paused - show the pause overlay.
 */
export declare function renderMinesweeper(ctx: CanvasRenderingContext2D, state: MinesweeperState, paused: boolean): void;
