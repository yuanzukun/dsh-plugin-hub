# dsh-one-click-launcher
![Demo usage](assets/demo.gif)

English | [中文](README.md)

A [DeepSeek Harness](https://deepseek-harness.github.io) plugin that puts a **one-click desktop launcher** for your local Harness Web UI on the Windows desktop.


## Why

Starting DeepSeek Harness Web normally means: open a terminal, type `dsh web`, wait for startup, then open the browser by hand. This plugin removes all of that:

- on startup it writes **`~/.dsh/launch-dsh.bat`** — a launcher script that starts the service and opens the browser at exactly the right moment, and
- it creates a **desktop shortcut (`.lnk`)** pointing to that script, with a customizable icon.

Double-click the shortcut. Done.

## Features

- **No blind sleep** — the script polls the port once per second and opens the browser the instant the service is ready; if the service is already running it just opens the browser immediately.
- **Never opens the browser too early** — on failure it shows a per-second wait counter and gives up with a clear message after 120 s.
- **Self-cleaning** — the launcher window exits itself after the browser opens; the minimized `DSH Server` window is the service itself (closing it stops the service).
- **Whale icon by default** — the shortcut uses a black whale icon; a blue `#4176e6` variant ships with the plugin, and you can plug in any `.ico` of your own (see [Customize the icon](#customize-the-icon)).
- **Zero dependencies, no build step** — plain ESM JavaScript, installs straight from GitHub.

## Requirements

- Windows 10/11 (the launcher is a `.bat` + `.lnk` pair)
- `dsh` CLI installed
- `pnpm` (the profile plugin manager `dsh plugin` forwards to pnpm)

## Installation

```sh
# into the web profile (or any profile)
dsh plugin --profile web add dsh-one-click-launcher
```

From GitHub directly (no build script needed):

```sh
dsh plugin --profile web add github:cheng249hx/dsh-one-click-launcher
```

From a tarball:

```sh
pnpm pack
dsh plugin --profile web add ./dsh-one-click-launcher-0.1.0.tgz
```

Restart `dsh web`. On startup the plugin:

1. writes `~/.dsh/launch-dsh.bat`;
2. copies the two built-in whale icons next to it — `~/.dsh/DeepSeek Harness.ico` (black, default) and `~/.dsh/DeepSeek Harness Blue.ico` (blue `#4176e6`);
3. creates a **DSH Web** shortcut on your desktop with the black whale icon.

## Usage

Double-click the **DSH Web** shortcut on the desktop.

- Closing the minimized **DSH Server** window stops the service.
- The launcher window closes by itself after the browser opens.
- To regenerate the shortcut after a config change: delete it from the desktop and restart `dsh web`.

## Customize the icon

Three ways, easiest first:

**1. Pick one of the two built-in whales.** Set `icon` in the plugin config:

```yaml
- update:
    - id: desktop-launcher
      config:
        icon: blue        # 'black' (default) or 'blue' (#4176e6)
```

The icons live at `%USERPROFILE%\.dsh\DeepSeek Harness.ico` and `%USERPROFILE%\.dsh\DeepSeek Harness Blue.ico`.

**2. Use your own `.ico`.** Point `iconPath` at any icon file:

```yaml
- update:
    - id: desktop-launcher
      config:
        iconPath: 'D:\icons\my-whale.ico'
```

**3. Change it on the desktop, no config.** Right-click the shortcut → **Properties** → **Shortcut** tab → **Change Icon…** → pick any `.ico` → OK. This is purely cosmetic and survives restarts.

After changing `icon`/`iconPath` in the config, delete the desktop shortcut and restart `dsh web` so the plugin regenerates it with the new icon.

## Configuration

Edit your profile's `cordis.patch.yml` (e.g. `~/.dsh/profiles/web/cordis.patch.yml`), or pass a `--patch` overlay:

```yaml
- update:
    - id: desktop-launcher
      config:
        icon: 'blue'                         # 'black' (default) or 'blue'
        iconPath: 'D:\icons\my-whale.ico'    # custom .ico (overrides `icon`)
        shortcutName: 'DSH 网页端'            # shortcut file name (no .lnk suffix)
        port: 3080                           # the port the launcher waits for
```

| field          | default            | description                                                |
| -------------- | ------------------ | ---------------------------------------------------------- |
| `icon`         | `black`            | built-in whale icon: `black` or `blue` (#4176e6)           |
| `iconPath`     | *(see `icon`)*     | absolute path to a custom `.ico`; overrides `icon`         |
| `shortcutName` | `DSH Web`          | name of the desktop shortcut (without `.lnk`)              |
| `port`         | `3080`             | the port the launcher waits for before opening the browser |
| `launcherDir`  | `~/.dsh`           | where `launch-dsh.bat` and the icons are written           |
| `desktopDir`   | system Desktop     | where the shortcut is created (mainly for testing)         |
| `dshCommand`   | auto-detected      | the `dsh` command the generated script uses                |
| `enabled`      | `true`             | set `false` to disable file creation                       |

## How it works

The package is a [Cordis bundle](https://deepseek-harness.github.io/deepseek-harness/develop/basic/publish.html): `package.json` declares `dsh.bundle.patch`, `cordis.patch.yml` inserts the plugin row, and `index.js` — plain ESM with zero dependencies — writes the launcher files in `apply()` on startup.

The generated `.bat` is deliberately plain ASCII with CRLF line endings so it parses correctly on any Windows locale.

## License

MIT
