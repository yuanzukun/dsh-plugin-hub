import { writeFileSync, existsSync, mkdirSync, copyFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFile } from 'node:child_process'

export const name = 'dsh-one-click-launcher'

const DEFAULT_PORT = 3080

// Icons shipped with this package (assets/). On apply they are copied next to
// the generated launcher so users can reference them easily.
const ASSETS_DIR = fileURLToPath(new URL('./assets/', import.meta.url))

/**
 * Copy a bundled icon to its destination, tolerating a missing asset.
 */
function copyIconIfPresent(src, dest) {
  try {
    if (existsSync(src)) {
      copyFileSync(src, dest)
      return true
    }
  } catch (err) {
    console.warn(`[${name}] failed to copy icon ${src}: ${err.message}`)
  }
  return false
}

/**
 * Resolve the `dsh` executable that is running this plugin, so the generated
 * launcher script can start the exact same install.
 *
 * When loaded inside dsh, process.argv[1] is dsh's bin.js at
 * <root>/node_modules/@deepseek-ai/dsh/lib/bin.js, so the dsh shim lives at
 * <root>/node_modules/.bin/dsh.cmd. Falls back to the `dsh` PATH command.
 */
function resolveDshCommand() {
  const arg1 = process.argv[1]
  if (arg1 && arg1.endsWith('bin.js')) {
    const binDir = join(dirname(arg1), '..', '..', '..', '.bin')
    for (const file of ['dsh.cmd', 'dsh']) {
      const candidate = join(binDir, file)
      if (existsSync(candidate)) return candidate
    }
  }
  return 'dsh'
}

/**
 * Build the launcher batch script. Plain ASCII + CRLF so it parses correctly
 * on every Windows locale. The script:
 *   1. opens the browser right away if the service is already running;
 *   2. otherwise starts `dsh web` in a minimized window and polls the port
 *      once per second (no blind sleep);
 *   3. opens the browser the moment the port is ready — never before;
 *   4. gives up after 120 s with a clear message (never opens the browser);
 *   5. the launcher window exits itself after the browser opens.
 */
function buildBat({ port, dshCommand }) {
  const lines = [
    '@echo off',
    'title DSH Web Launcher',
    'echo ============================================',
    'echo   DeepSeek Harness Web Launcher',
    'echo ============================================',
    'echo.',
    'rem --- already running? just open the browser ---',
    `netstat -ano | findstr /r ":${port}.*LISTENING" >nul 2>nul`,
    'if not errorlevel 1 goto already',
    '',
    'rem --- start dsh in its own minimized window ---',
    `echo [DSH] starting dsh web (port ${port})...`,
    `set "DSHCMD=${dshCommand}"`,
    'if exist "%DSHCMD%" goto runfull',
    'where dsh >nul 2>nul',
    'if not errorlevel 1 goto runpath',
    'echo [DSH] dsh not found on PATH, trying npx...',
    'start /min "DSH Server" npx dsh web',
    'goto wait',
    ':runpath',
    'echo [DSH] starting dsh web (from PATH)...',
    'start /min "DSH Server" dsh web',
    'goto wait',
    ':runfull',
    'echo [DSH] starting dsh web...',
    'start /min "DSH Server" "%DSHCMD%" web',
    'goto wait',
    '',
    ':wait',
    'echo.',
    'set /a WAIT=0',
    `echo [DSH] waiting for port ${port}... 0s`,
    ':loop',
    'ping -n 2 127.0.0.1 >nul',
    'set /a WAIT+=1',
    `netstat -ano | findstr /r ":${port}.*LISTENING" >nul 2>nul`,
    'if not errorlevel 1 goto up',
    `echo [DSH] waiting for port ${port}... %WAIT%s`,
    'if %WAIT% geq 120 goto fail',
    'goto loop',
    '',
    ':up',
    'echo.',
    `echo [DSH] port ${port} ready, opening browser http://127.0.0.1:${port}`,
    `start "" http://127.0.0.1:${port}`,
    'echo [DSH] launcher will exit now.',
    'exit /b',
    '',
    ':fail',
    'echo.',
    `echo [DSH] timed out after %WAIT%s, port ${port} not ready.`,
    'echo [DSH] check the "DSH Server" window for errors.',
    'pause',
    'exit /b',
    '',
    ':already',
    `echo [DSH] service already running at http://127.0.0.1:${port}`,
    `start "" http://127.0.0.1:${port}`,
    'echo [DSH] launcher will exit now.',
    'exit /b',
    '',
  ]
  return lines.join('\r\n')
}

/**
 * Create the desktop shortcut with PowerShell (WScript.Shell). Returns
 * "CREATED:<path>" when a new shortcut was made, "EXISTS" when one is already
 * present, or null on non-Windows. Existing shortcuts are never overwritten,
 * so user customizations (icon, name) survive restarts.
 */
function createShortcut({ desktopDir, shortcutName, batPath, iconPath }) {
  return new Promise((resolve, reject) => {
    if (process.platform !== 'win32') {
      console.log(`[${name}] not on Windows — desktop shortcut skipped`)
      return resolve(null)
    }
    const q = (s) => String(s).replace(/'/g, "''")
    const ps = [
      '$ErrorActionPreference = "Stop"',
      `$bat = '${q(batPath)}'`,
      desktopDir
        ? `$desktop = '${q(desktopDir)}'`
        : '$desktop = [Environment]::GetFolderPath("Desktop")',
      'if (-not (Test-Path $desktop)) { New-Item -ItemType Directory -Path $desktop | Out-Null }',
      `$lnk = Join-Path $desktop '${q(shortcutName)}.lnk'`,
      'if (Test-Path $lnk) { Write-Output "EXISTS"; exit 0 }',
      '$ws = New-Object -ComObject WScript.Shell',
      '$s = $ws.CreateShortcut($lnk)',
      '$s.TargetPath = $bat',
      '$s.WorkingDirectory = [Environment]::GetFolderPath("UserProfile")',
      `$s.Description = 'Launch DeepSeek Harness Web (${q(shortcutName)})'`,
      `$s.IconLocation = '${q(iconPath)},0'`,
      '$s.Save()',
      'Write-Output ("CREATED:" + $lnk)',
    ].join('; ')
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-Command', ps],
      { windowsHide: true, timeout: 20000 },
      (err, stdout, stderr) => {
        if (err) return reject(new Error((stderr || err.message).trim()))
        resolve(stdout.trim())
      }
    )
  })
}

export async function apply(ctx, config = {}) {
  if (config.enabled === false) return
  const port = config.port ?? DEFAULT_PORT
  const shortcutName = config.shortcutName ?? 'DSH Web'
  const launcherDir = config.launcherDir ?? join(homedir(), '.dsh')
  const desktopDir = config.desktopDir ?? null

  try {
    mkdirSync(launcherDir, { recursive: true })

    // Ship the two built-in whale icons next to the launcher:
    //   black whale -> DeepSeek Harness.ico      (default)
    //   blue whale  -> DeepSeek Harness Blue.ico (#4176e6)
    const blackIcon = join(launcherDir, 'DeepSeek Harness.ico')
    const blueIcon = join(launcherDir, 'DeepSeek Harness Blue.ico')
    copyIconIfPresent(join(ASSETS_DIR, 'whale-black.ico'), blackIcon)
    copyIconIfPresent(join(ASSETS_DIR, 'whale-blue.ico'), blueIcon)
    const iconPath =
      config.iconPath && config.iconPath.length > 0
        ? config.iconPath
        : config.icon === 'blue'
          ? blueIcon
          : blackIcon

    const batPath = join(launcherDir, 'launch-dsh.bat')
    writeFileSync(
      batPath,
      buildBat({ port, dshCommand: config.dshCommand ?? resolveDshCommand() }),
      'utf8'
    )
    console.log(`[${name}] launcher written to ${batPath}`)

    const result = await createShortcut({ desktopDir, shortcutName, batPath, iconPath })
    if (result && result.startsWith('CREATED:')) {
      console.log(`[${name}] desktop shortcut created: ${result.slice('CREATED:'.length)}`)
    } else if (result === 'EXISTS') {
      console.log(`[${name}] desktop shortcut already exists — delete it and restart to regenerate`)
    }
  } catch (err) {
    console.error(`[${name}] failed to create launcher: ${err && err.message ? err.message : err}`)
  }
}
