import test from 'node:test'
import assert from 'node:assert/strict'
import {
  getBalanceProvider,
  matchesModelProvider,
  parseBalanceResponse,
  providerList,
  resolveBalanceEndpoint
} from '../lib/balance.js'

test('lists every balance provider and defaults to DeepSeek', () => {
  assert.deepEqual(providerList().map((p) => p.id), [
    'deepseek', 'siliconflow', 'digitalocean', 'amd-gpu-cloud', 'qwen-token-plan', 'bailian-payg'
  ])
  assert.equal(getBalanceProvider().id, 'deepseek')
  assert.equal(getBalanceProvider('unknown'), null)
  assert.match(providerList().find((p) => p.id === 'digitalocean').credentialHelpUrl, /digitalocean/)
  assert.match(providerList().find((p) => p.id === 'amd-gpu-cloud').credentialHelpUrl, /amd\.com/)
})

test('normalizes DeepSeek balance response', () => {
  const res = parseBalanceResponse('deepseek', JSON.stringify({
    is_available: true,
    balance_infos: [{
      currency: 'CNY', total_balance: '12.34', granted_balance: '2.34', topped_up_balance: '10.00'
    }]
  }))
  assert.equal(res.ok, true)
  assert.equal(res.totalBalance, '12.34')
  assert.equal(res.isAvailable, true)
  assert.equal(res.infos[0].toppedUpBalance, '10.00')
  assert.deepEqual(res.details.map((d) => d.value), ['10.00', '2.34'])
  assert.deepEqual(res.details.map((d) => d.labelKey), ['toppedUp', 'granted'])
})

test('does not report DeepSeek unavailable when the field is omitted', () => {
  const res = parseBalanceResponse('deepseek', JSON.stringify({
    balance_infos: [{ currency: 'CNY', total_balance: '1.00' }]
  }))
  assert.equal(res.ok, true)
  assert.equal(res.isAvailable, null)
})

// 回归用例来自 issue #17：账户同时有人民币赠送余额与美元充值余额时，官方
// /user/balance 会在 balance_infos 里给出两条。旧实现只取 [0]，另一种币种被
// 静默丢弃，且显示哪一种取决于数组顺序（两次刷新之间来回跳）。
test('keeps every currency of a multi-currency DeepSeek account', () => {
  const res = parseBalanceResponse('deepseek', JSON.stringify({
    is_available: true,
    balance_infos: [
      { currency: 'CNY', total_balance: '6.00', granted_balance: '6.00', topped_up_balance: '0.00' },
      { currency: 'USD', total_balance: '10.00', granted_balance: '0.00', topped_up_balance: '10.00' }
    ]
  }))
  assert.equal(res.ok, true)
  assert.equal(res.multiCurrency, true)
  assert.deepEqual(res.infos.map((i) => i.currency), ['CNY', 'USD'])
  assert.deepEqual(res.infos.map((i) => i.totalBalance), ['6.00', '10.00'])
  // 兼容字段仍指向第一条：旧 UI / 导出不会被新字段打断
  assert.equal(res.currency, 'CNY')
  assert.equal(res.totalBalance, '6.00')
  assert.deepEqual(res.details.map((d) => d.labelKey), ['toppedUp', 'granted'])
})

test('a single-currency DeepSeek account is not flagged as multi-currency', () => {
  const res = parseBalanceResponse('deepseek', JSON.stringify({
    balance_infos: [{ currency: 'CNY', total_balance: '1.00' }]
  }))
  assert.equal(res.ok, true)
  assert.equal(res.multiCurrency, false)
  assert.equal(res.infos.length, 1)
})

// 回归用例来自 issue #15：百炼「按量付费」的余额在阿里云费用中心，模型 API Key
// 查不到。插件必须把这件事说清楚，而不是给一个会被误解的查询按钮。
test('bailian pay-as-you-go is exposed as a console-only provider', () => {
  const provider = getBalanceProvider('bailian-payg')
  assert.equal(provider.queryMode, 'unsupported')
  assert.match(provider.unsupportedMessage, /阿里云/)
  assert.match(provider.credentialHelpUrl, /aliyun\.com/)
  assert.match(parseBalanceResponse('bailian-payg', '{}').error, /没有可用的公开余额查询接口/)
})

test('normalizes researched SiliconFlow user info fields', () => {
  const res = parseBalanceResponse('siliconflow', JSON.stringify({
    code: 20000,
    data: { balance: '3.25', chargeBalance: '8.75', totalBalance: '12.00' }
  }))
  assert.equal(res.ok, true)
  assert.equal(res.currency, 'CNY')
  assert.equal(res.totalBalance, '12.00')
  assert.equal(res.zeroBalance, false)
  assert.deepEqual(res.details.map((d) => d.value), ['8.75', '3.25'])
  assert.deepEqual(res.fieldDefinitions.map((d) => d.name), ['totalBalance', 'chargeBalance', 'balance'])
  assert.deepEqual(res.details.map((d) => d.labelKey), ['toppedUp', 'grantedLegacy'])
  assert.equal(res.sourceNoteKey, 'note.siliconflow')
})

test('marks a successful all-zero SiliconFlow response for UI diagnostics', () => {
  const res = parseBalanceResponse('siliconflow', JSON.stringify({
    code: 20000,
    data: { balance: '0', chargeBalance: '0', totalBalance: '0' }
  }))
  assert.equal(res.ok, true)
  assert.equal(res.zeroBalance, true)
})

test('matches custom model provider routes without confusing unrelated providers', () => {
  assert.equal(matchesModelProvider('siliconflow', 'siliconflow', ''), true)
  assert.equal(matchesModelProvider('siliconflow', 'custom-route', 'SiliconFlow'), true)
  assert.equal(matchesModelProvider('digitalocean', 'digital-ocean', ''), true)
  assert.equal(matchesModelProvider('siliconflow', 'digital-ocean', ''), false)
})

test('uses only official SiliconFlow hosts for balance requests', () => {
  assert.equal(
    resolveBalanceEndpoint('siliconflow', 'https://api.siliconflow.com/v1'),
    'https://api.siliconflow.com/v1/user/info'
  )
  assert.equal(
    resolveBalanceEndpoint('siliconflow', 'https://api.siliconflow.cn/v1/chat/completions'),
    'https://api.siliconflow.cn/v1/user/info'
  )
  assert.equal(
    resolveBalanceEndpoint('siliconflow', 'https://example.com/v1'),
    'https://api.siliconflow.cn/v1/user/info'
  )
  assert.equal(
    resolveBalanceEndpoint('siliconflow', 'http://api.siliconflow.com/v1'),
    'https://api.siliconflow.cn/v1/user/info'
  )
})

test('normalizes DigitalOcean account billing balance', () => {
  const res = parseBalanceResponse('digitalocean', JSON.stringify({
    month_to_date_balance: '23.44',
    account_balance: '12.23',
    month_to_date_usage: '11.21',
    generated_at: '2019-07-09T15:01:12Z'
  }))
  assert.equal(res.ok, true)
  assert.equal(res.currency, 'USD')
  assert.equal(res.totalBalance, '12.23')
  assert.equal(res.balanceKind, 'due')
  assert.equal(res.balanceLabelKey, 'bal.due')
  assert.equal(res.monthToDateUsage, '11.21')
  assert.equal(res.monthToDateBalance, '23.44')
  assert.deepEqual(res.details.map((d) => d.value), ['11.21'])
})

test('shows a negative DigitalOcean account balance as available credit', () => {
  const res = parseBalanceResponse('digitalocean', JSON.stringify({
    month_to_date_balance: '-13.00',
    account_balance: '-13.00',
    month_to_date_usage: '0.00',
    generated_at: '2026-08-18T06:35:32Z'
  }))
  assert.equal(res.ok, true)
  assert.equal(res.totalBalance, '13')
  assert.equal(res.balanceKind, 'credit')
  assert.equal(res.balanceLabelKey, 'bal.credit')
  assert.equal(res.rawAccountBalance, '-13.00')
  assert.equal(res.monthToDateUsage, '0.00')
  assert.equal(res.monthToDateBalance, '-13.00')
  assert.deepEqual(res.details.map((d) => d.value), ['0.00'])
})

test('rejects API errors and unrecognized response shapes', () => {
  assert.match(parseBalanceResponse('siliconflow', '{"code":401,"message":"bad key"}').error, /bad key/)
  assert.match(parseBalanceResponse('digitalocean', '{}').error, /account_balance/)
  assert.match(parseBalanceResponse('deepseek', 'not json').error, /无法解析/)
})

test('successful payloads carry semantic keys instead of Chinese presentation text', () => {
  const samples = [
    ['deepseek', JSON.stringify({ is_available: true, balance_infos: [{ currency: 'CNY', total_balance: '12.34', granted_balance: '2.34', topped_up_balance: '10.00' }] })],
    ['siliconflow', JSON.stringify({ code: 20000, data: { balance: '3.25', chargeBalance: '8.75', totalBalance: '12.00' } })],
    ['digitalocean', JSON.stringify({ account_balance: '-5.25', month_to_date_usage: '3.10', generated_at: '2026-08-22T00:00:00Z' })]
  ]
  const cjk = /[\u4e00-\u9fff]/
  for (const [provider, body] of samples) {
    const res = parseBalanceResponse(provider, body)
    assert.equal(res.ok, true)
    const payload = JSON.stringify({
      details: res.details,
      fieldDefinitions: res.fieldDefinitions,
      sourceNoteKey: res.sourceNoteKey,
      balanceLabelKey: res.balanceLabelKey,
      infos: res.infos
    })
    assert.equal(cjk.test(payload), false, provider + ' payload should not contain CJK presentation text')
  }
})

test('digitalocean maps account kinds to semantic labels', () => {
  const credit = parseBalanceResponse('digitalocean', JSON.stringify({ account_balance: '-5.25' }))
  const due = parseBalanceResponse('digitalocean', JSON.stringify({ account_balance: '7.50' }))
  const settled = parseBalanceResponse('digitalocean', JSON.stringify({ account_balance: '0' }))
  assert.equal(credit.ok && due.ok && settled.ok, true)
  assert.equal(credit.balanceLabelKey, 'bal.credit')
  assert.equal(due.balanceLabelKey, 'bal.due')
  assert.equal(settled.balanceLabelKey, 'bal.settled')
})

test('normalizes Qwen Token Plan quota usage (progress data)', () => {
  const res = parseBalanceResponse('qwen-token-plan', JSON.stringify({
    per1WeekPercentage: 0.20169764399999998,
    per1WeekResetTime: 1787897100000
  }))
  assert.equal(res.ok, true)
  assert.equal(res.provider, 'qwen-token-plan')
  assert.equal(res.kind, 'quota-usage')
  assert.equal(res.details.length, 0)
  assert.ok(res.qwenQuota)
  // 进度条比例：0.2017 -> 约 0.2017
  assert.ok(Math.abs(res.qwenQuota.ratio - 0.201697644) < 0.001)
  assert.equal(res.qwenQuota.usedPercent, '20.2%')
  assert.match(res.qwenQuota.weekEnd, /2026-08-28/)
  assert.match(res.qwenQuota.weekStart, /2026-08-21/)
  assert.equal(res.qwenQuota.ratioLabel, '已用 20.2%')
  assert.match(res.sourceNote, /1 周配额已用进度/)
})

test('rejects a Qwen Token Plan response with no quota fields', () => {
  const res = parseBalanceResponse('qwen-token-plan', JSON.stringify({ foo: 1 }))
  assert.equal(res.ok, false)
  assert.match(res.error, /没有可识别的配额字段/)
})
