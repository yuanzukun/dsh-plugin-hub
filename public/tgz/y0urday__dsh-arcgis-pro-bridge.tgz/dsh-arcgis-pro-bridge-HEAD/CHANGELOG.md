# Changelog

本项目遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [0.1.1] - 2026-09-23

依赖健康检查与修复。**这一版修掉了一个会导致 MCP 服务启动即崩的隐患**，建议所有用户升级。

### 修复

- **`mcp[cli]` 缺少上界（关键）**：`server/pyproject.toml` 原为 `mcp[cli]>=1.9.4`（无上界）。
  MCP Python SDK 2.x 删除了 `mcp.server.fastmcp`（`FastMCP` 更名为 `mcp.server.mcpserver.MCPServer`），
  而 vendored 服务使用 `from mcp.server.fastmcp import FastMCP`。原来的 `uv.lock` 恰好锁在 1.x 挡住了它，
  但任何一次 relock、删除 lock，或按旧 README 执行 `pip install "mcp[cli]>=1.9.4"`，都会解析到 2.x 并导致
  `ModuleNotFoundError: No module named 'mcp.server.fastmcp'`。现加上 `<2` 上界。
- **启动配方加 `--locked`**：`uv run --locked --project …`。让「pyproject + uv.lock 固定」这一承诺真正生效 ——
  uv 拒绝在启动时重新解析依赖，不会再悄悄漂移到未经测试的组合。
- **`sync-upstream.sh` 重新打补丁**：同步上游后会重新应用 `mcp<2` 上界（幂等），并用 `uv lock --check`
  校验、必要时 `uv lock --upgrade` 刷新 lock。上游将来迁到 `MCPServer` 后该步骤会自动跳过。
- **打包会带上 `server/__pycache__`**：`package.json` 的 `files` 白名单会让 `.npmignore` 失效，
  按 README 直接在 `server/` 跑一次服务就会生成字节码并被 `npm pack` 打进 tgz。已用否定模式排除。

### 变更

- **`@deepseek-ai/schemastery`：`^3.18.1` → `~3.18.4`**。原范围实际解析到 3.18.2，与宿主 DSH 自带的
  3.18.4 不一致（DSH 内置包统一声明 `~3.18.4`）。本插件是 bundle，schema 由宿主的 cordis loader 校验，
  现与宿主完全对齐。
- **Python 依赖全面刷新**（`uv lock --upgrade`，19 个包）：`mcp` 1.27.0 → **1.30.0**（1.x 最新稳定版），
  `pydantic` 2.12.5 → 2.13.5、`pydantic-core` 2.41.5 → 2.46.5、`starlette` 1.0.0 → 1.6.0、
  `uvicorn` 0.43.0 → 0.53.0、`cryptography` 46.0.6 → 50.0.1、`pyjwt` 2.12.1 → 2.14.0、
  `rich` 14.3.3 → 15.0.0、`ruff` 0.15.9 → 0.16.8、`sse-starlette`、`typer`、`rpds-py` 等。
- 文档：新增「依赖与版本约束」章节说明每条约束的理由；新增 `mcp.server.fastmcp` 报错的排查条目；
  README 的 DSH 验证版本更新为 `0.1.7-alpha.2`；补全发布新版本的流程。

### 未变更

- `server/` 下 6 个上游 `.py` 文件与上游 `b3c1d4ab7a0a30fd4d8faf885aa0bdbc8a6d9572` 逐字节一致。
  唯一的本地改动是 `pyproject.toml` 的 `mcp[cli]` 上界，以及据此重新生成的 `uv.lock`（详见 `NOTICE`）。

### 验证

- `npm run check`、`npm test`（9/9，新增 4 条依赖约束测试）通过。
- `uv lock --check` 一致。
- 用真实启动配方 `uv run --locked --project server server/arcgis_mcp_server.py` 跑 MCP stdio 握手
  （`initialize` + `tools/list`），13 个工具全部注册；在源码目录、`sync-upstream` 后的副本、
  已安装到 profile 的副本三处各验证一次。
- 在 DSH `0.1.7-alpha.2` 下 `mcp__arcgis__ping` 正常。

## [0.1.0] - 2026-08-17

首个版本。把 [ArcGIS-Pro-Bridge-MCP-Server](https://github.com/Sangwxx/ArcGIS-Pro-Bridge-MCP-Server)
的 Python MCP 服务内置进 DSH bundle 插件，通过官方 `@deepseek-ai/dsh-mcp-client` 以 stdio 拉起，
模型侧工具名为 `mcp__arcgis__*`（13 个工具）。
