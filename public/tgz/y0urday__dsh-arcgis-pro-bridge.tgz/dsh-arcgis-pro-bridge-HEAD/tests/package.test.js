import assert from 'node:assert/strict'
import { readFileSync, existsSync, statSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import test from 'node:test'

const root = dirname(dirname(fileURLToPath(import.meta.url)))

const vendoredFiles = [
  'arcgis_aprx_archive.py',
  'arcgis_mcp_resources.py',
  'arcgis_mcp_server.py',
  'arcgis_mcp_services.py',
  'arcgis_runtime_utils.py',
  'arcgis_script_templates.py',
  'pyproject.toml',
  'uv.lock',
  'UPSTREAM_LICENSE',
]

test('bundle manifest is declared and points at the patch', () => {
  const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'))
  assert.equal(pkg.type, 'module')
  assert.equal(pkg.main, 'index.js')
  assert.equal(pkg.dsh.bundle.patch, './cordis.patch.yml')
  assert.ok(!pkg.scripts?.prepare, 'keep the package build-free so github: installs need no allowBuilds')
  assert.ok(!pkg.dependencies?.['@deepseek-ai/dsh-mcp-client'], 'mcp client must come from the in-box DSH bundle, not a duplicate copy')
  // `files` overrides .npmignore, so the bytecode excludes have to live here:
  // running the server straight from server/ (see README) writes __pycache__,
  // and without these patterns `npm pack` ships it.
  assert.ok(pkg.files.includes('!server/**/__pycache__'), 'must exclude server/__pycache__ from the tarball')
  assert.ok(pkg.files.includes('!server/**/*.pyc'), 'must exclude .pyc from the tarball')
})

test('patch inserts the provider and official MCP client rows', () => {
  const patch = readFileSync(join(root, 'cordis.patch.yml'), 'utf8')
  assert.match(patch, /id:\s*arcgis-pro-bridge/)
  assert.match(patch, /name:\s*dsh-arcgis-pro-bridge/)
  assert.match(patch, /id:\s*arcgis-pro-bridge-mcp/)
  assert.match(patch, /name:\s*'@deepseek-ai\/dsh-mcp-client'/)
  assert.match(patch, /inject:\s*\[arcgisProBridge\]/)
  assert.match(patch, /transport:\s*stdio/)
  assert.match(patch, /serverName:\s*!!js ctx\.arcgisProBridge\.serverName/)
})

test('provider plugin publishes the vendored server launch recipe', () => {
  const index = readFileSync(join(root, 'index.js'), 'utf8')
  assert.match(index, /arcgis_mcp_server\.py/)
  assert.match(index, /ctx\.provide\('arcgisProBridge'/)
  assert.match(index, /'run', '--locked', '--project', serverDir, serverEntry/)
  assert.match(index, /UV_PROJECT_ENVIRONMENT/)
})

test('schemastery is pinned to the range the host DSH ships', () => {
  const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'))
  const range = pkg.dependencies?.['@deepseek-ai/schemastery']
  assert.ok(range, 'schemastery must stay a runtime dependency (index.js imports it)')
  // In-box DSH packages all declare ~3.18.4; a caret range here lets a second,
  // older copy get installed next to the host's.
  assert.match(range, /^~3\.18\./)
})

test('vendored MCP SDK stays on the 1.x API the server is written against', () => {
  const pyproject = readFileSync(join(root, 'server', 'pyproject.toml'), 'utf8')
  assert.match(
    pyproject,
    /"mcp\[cli\]>=1\.9\.4,<2"/,
    'mcp 2.x removed mcp.server.fastmcp; the dependency must keep an upper bound',
  )

  const lock = readFileSync(join(root, 'server', 'uv.lock'), 'utf8')
  const pinned = lock.match(/\[\[package\]\]\nname = "mcp"\nversion = "([^"]+)"/)
  assert.ok(pinned, 'uv.lock must pin mcp')
  assert.ok(
    pinned[1].startsWith('1.'),
    `uv.lock pins mcp ${pinned[1]}; the vendored server needs 1.x`,
  )
})

test('sync-upstream re-applies the local mcp<2 bound', () => {
  const sync = readFileSync(join(root, 'scripts', 'sync-upstream.sh'), 'utf8')
  assert.match(sync, /mcp\.server\.fastmcp/, 'must detect the v1 FastMCP import')
  assert.match(sync, /mcp\[cli\][^\n]*<2/, 'must re-apply the upper bound')
  assert.match(sync, /uv lock --check/, 'must verify the refreshed lock')
})

test('all vendored server files exist and are non-empty', () => {
  for (const file of vendoredFiles) {
    const path = join(root, 'server', file)
    assert.ok(existsSync(path), `missing ${path}`)
    assert.ok(statSync(path).size > 0, `empty ${path}`)
  }
})

test('server pyproject keeps the console entry point', () => {
  const pyproject = readFileSync(join(root, 'server', 'pyproject.toml'), 'utf8')
  assert.match(pyproject, /arcgis-mcp-server = "arcgis_mcp_server:main"/)
})

test('NOTICE records the upstream repository and license', () => {
  const notice = readFileSync(join(root, 'NOTICE'), 'utf8')
  assert.match(notice, /github\.com\/Sangwxx\/ArcGIS-Pro-Bridge-MCP-Server/)
  assert.match(notice, /License: MIT/)
  assert.match(notice, /server\/UPSTREAM_LICENSE/)
})
