// @ts-check
/**
 * dsh-arcgis-pro-bridge
 *
 * DeepSeek Harness bundle plugin that bridges ArcGIS Pro and DSH.
 *
 * This plugin is a Cordis *service provider*. It computes the launch recipe
 * for the vendored Python implementation of the ArcGIS Pro Bridge MCP Server
 * (https://github.com/Sangwxx/ArcGIS-Pro-Bridge-MCP-Server) and publishes it
 * under the `arcgisProBridge` service name. The bundle patch mounts DSH's
 * official in-box `@deepseek-ai/dsh-mcp-client` as a second row that injects
 * that service, so the model sees the server tools as:
 *
 *   mcp__<serverName>__ping
 *   mcp__<serverName>__doctor
 *   mcp__<serverName>__inspect_gdb
 *   ...
 *
 * ArcPy code itself always runs inside the ArcGIS Pro Python subprocess, never
 * in the DSH Node.js process.
 */
import { createHash } from 'node:crypto'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

import z from '@deepseek-ai/schemastery'

export const name = 'arcgis-pro-bridge'

/** Service this plugin provides; consumed by the companion mcp-client row. */
export const provide = 'arcgisProBridge'

/** This package directory; the vendored Python server lives in `server/`. */
const packageDir = dirname(fileURLToPath(import.meta.url))
export const serverDir = join(packageDir, 'server')
const serverEntry = join(serverDir, 'arcgis_mcp_server.py')

/** Upper bound for one ArcGIS tool call; matches the upstream 300s default. */
const DEFAULT_TOOL_CALL_TIMEOUT_MS = 300_000

const SERVER_NAME_PATTERN = /^[A-Za-z0-9_-]{1,32}$/

/** @typedef {'uv' | 'python'} Launcher */

/**
 * Plugin configuration, supplied through `cordis.yml` (or a user patch).
 *
 * @typedef {Object} Config
 * @property {string} serverName
 *   Stable namespace for model-facing tool names (`mcp__<serverName>__*`).
 * @property {Launcher} launcher
 *   `uv` runs the vendored server with its pinned pyproject/uv.lock
 *   (recommended); `python` runs it with `pythonExecutable` and requires the
 *   `mcp` package (`>=1.9.4,<2`) already installed in that interpreter.
 * @property {string} pythonExecutable
 *   Interpreter used when `launcher` is `python`. This is the plain Python
 *   that hosts the MCP server, not ArcGIS Pro Python; ArcPy is discovered by
 *   the server itself at runtime.
 * @property {string[]} extraArgs
 *   Extra arguments appended to the MCP server process argv.
 * @property {Record<string, string>} env
 *   Extra environment variables for the MCP server process (for example
 *   `ARCGIS_PRO_PYTHON` or `ARCGIS_PRO_INSTALL_DIR`). With the `uv` launcher,
 *   `UV_PROJECT_ENVIRONMENT` defaults to the OS temp directory and can be
 *   overridden here.
 * @property {number} toolCallTimeoutMs
 *   Timeout per ArcGIS tool invocation.
 * @property {boolean} failOnStartupError
 *   Reject the mcp-client row's activation when initial connection or tool
 *   sync fails.
 * @property {Object} [reconnect]
 *   Reconnect policy for the child MCP server.
 */

export const Config = z.object({
  serverName: z.string().required().pattern(SERVER_NAME_PATTERN).default('arcgis'),
  launcher: z.union(['uv', 'python']).default('uv'),
  pythonExecutable: z.string().default('python'),
  extraArgs: z.array(String).default([]),
  env: z.dict(String).default({}),
  toolCallTimeoutMs: z.number().default(DEFAULT_TOOL_CALL_TIMEOUT_MS),
  failOnStartupError: z.boolean().default(false),
  reconnect: z.object({
    enabled: z.boolean().default(true),
    initialDelayMs: z.number().min(1).default(500),
    maxDelayMs: z.number().min(1).default(30_000),
    maxAttempts: z.number().step(1).min(1).default(10),
  }),
})

/**
 * uv virtual environment location. Keep it outside the installed package so
 * npm/git-installed plugins stay read-clean, and hash the install path so two
 * parallel DSH profiles cannot fight over one venv.
 * `config.env.UV_PROJECT_ENVIRONMENT` wins when set.
 */
const installTag = createHash('sha256').update(packageDir).digest('hex').slice(0, 8)
const defaultUvEnvironmentDir = join(tmpdir(), `dsh-arcgis-pro-bridge-uv-${installTag}`)

/**
 * @param {import('@deepseek-ai/cordis').Context} ctx
 * @param {Config} config
 */
export function apply(ctx, config) {
  const useUv = config.launcher === 'uv'
  const command = useUv ? 'uv' : config.pythonExecutable
  // `--locked` makes the "pinned pyproject + uv.lock" promise real: uv refuses
  // to re-resolve, so a launch can never silently drift onto an untested set
  // (notably MCP Python SDK 2.x, which removed `mcp.server.fastmcp`).
  const args = useUv
    ? ['run', '--locked', '--project', serverDir, serverEntry, ...config.extraArgs]
    : [serverEntry, ...config.extraArgs]
  const env = {
    PYTHONDONTWRITEBYTECODE: '1',
    ...(useUv
      ? {
          UV_PROJECT_ENVIRONMENT: config.env.UV_PROJECT_ENVIRONMENT ?? defaultUvEnvironmentDir,
        }
      : {}),
    ...config.env,
  }

  ctx.logger('arcgis-pro-bridge').info(
    'providing ArcGIS Pro Bridge launch recipe (%s) for %s',
    command,
    serverEntry,
  )

  ctx.provide('arcgisProBridge', {
    serverName: config.serverName,
    command,
    args,
    cwd: serverDir,
    env,
    toolCallTimeoutMs: config.toolCallTimeoutMs,
    failOnStartupError: config.failOnStartupError,
    reconnect: config.reconnect,
  })
}
