#!/usr/bin/env bash
# Refresh the vendored ArcGIS Pro Bridge MCP Server source.
set -euo pipefail

UPSTREAM_REPO="https://github.com/Sangwxx/ArcGIS-Pro-Bridge-MCP-Server.git"
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
SERVER_DIR="$ROOT_DIR/server"
NOTICE_FILE="$ROOT_DIR/NOTICE"

FILES=(
  arcgis_aprx_archive.py
  arcgis_mcp_resources.py
  arcgis_mcp_server.py
  arcgis_mcp_services.py
  arcgis_runtime_utils.py
  arcgis_script_templates.py
  pyproject.toml
  uv.lock
)

TMP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/arcgis-upstream.XXXXXX")"
trap 'rm -rf "$TMP_DIR"' EXIT

echo "Cloning upstream repository..."
git clone --depth 1 "$UPSTREAM_REPO" "$TMP_DIR/upstream"

COMMIT="$(git -C "$TMP_DIR/upstream" rev-parse HEAD)"
echo "Upstream commit: $COMMIT"

for file in "${FILES[@]}"; do
  cp -f "$TMP_DIR/upstream/$file" "$SERVER_DIR/$file"
  echo "  vendored: $file"
done
cp -f "$TMP_DIR/upstream/LICENSE" "$SERVER_DIR/UPSTREAM_LICENSE"

# Re-apply the one local deviation from upstream: an upper bound on the MCP
# Python SDK. The vendored server imports `mcp.server.fastmcp.FastMCP`, which
# SDK 2.x removed (renamed to `mcp.server.mcpserver.MCPServer`), so an
# unbounded `mcp[cli]>=1.9.4` silently resolves 2.x on any relock and the
# server dies with ModuleNotFoundError at startup. This step is idempotent and
# skips itself automatically once upstream migrates off the v1 FastMCP import.
python3 - "$SERVER_DIR" <<'PY'
import pathlib
import re
import sys

server_dir = pathlib.Path(sys.argv[1])
server_src = (server_dir / "arcgis_mcp_server.py").read_text(encoding="utf-8")
pyproject_path = server_dir / "pyproject.toml"
pyproject = pyproject_path.read_text(encoding="utf-8")

if "mcp.server.fastmcp" not in server_src:
    print("  mcp<2 bound: not needed (upstream no longer uses mcp.server.fastmcp)")
    raise SystemExit(0)

if re.search(r'"mcp\[cli\][^"]*<2[^"]*"', pyproject):
    print("  mcp<2 bound: already present upstream, nothing to do")
    raise SystemExit(0)

patched, count = re.subn(
    r'"mcp\[cli\](>=([^",]+))"',
    lambda m: f'"mcp[cli]{m.group(1)},<2"',
    pyproject,
)
if count != 1:
    raise SystemExit(
        "could not find the upstream `mcp[cli]>=...` dependency line in "
        "server/pyproject.toml; refusing to sync without the mcp<2 bound"
    )
pyproject_path.write_text(patched, encoding="utf-8")
print("  mcp<2 bound: re-applied to server/pyproject.toml")
PY

if command -v uv >/dev/null 2>&1; then
  echo "Checking the refreshed uv.lock against the patched pyproject..."
  if ! (cd "$SERVER_DIR" && uv lock --check >/dev/null 2>&1); then
    echo "  uv.lock is stale; refreshing it (upgrade)..."
    (cd "$SERVER_DIR" && uv lock --upgrade)
  fi
  (cd "$SERVER_DIR" && uv lock --check >/dev/null) \
    && echo "  uv.lock is consistent."
else
  echo "  uv not found; run 'cd server && uv lock --upgrade' manually."
fi

python3 - "$NOTICE_FILE" "$COMMIT" <<'PY'
import pathlib
import re
import sys

notice_path = pathlib.Path(sys.argv[1])
commit = sys.argv[2]
text = notice_path.read_text(encoding="utf-8")
text, count = re.subn(
    r"commit [0-9a-f]{40}",
    f"commit {commit}",
    text,
    count=1,
)
if count != 1:
    raise SystemExit("NOTICE does not contain the expected commit line")
notice_path.write_text(text, encoding="utf-8")
print("  updated NOTICE commit")
PY

echo "Done. Run 'npm run check && npm test' before committing."
