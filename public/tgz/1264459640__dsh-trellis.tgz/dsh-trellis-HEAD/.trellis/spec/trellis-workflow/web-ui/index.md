# trellis-workflow / web-ui — 质量检查与约定

> 本文件由 `feat` 任务 `trellis-right-phase-panel`（会话头部阶段徽标）沉淀。
> 证据：任务规划产物（prd/design/design-review/implement/review）与本包 `lib/` 源码。

## Web UI 扩展约定

1. **嵌入 UI 优先选 session 作用域加法座位**，而非 root 作用域浮层：
   - 会话头部右侧状态/徽标 → `conversation.session.header.utilities`（list / session scope /
     additive，fresh id；组件经框架标准 prop `sessionId` 拿当前会话 id，**无需订阅
     `sessions.list`**；会话切换由框架按 key=sessionId 重挂载自动重取）。
   - **blank 会话（新对话，首条消息前）header 整体隐藏**（harness `hideChrome =
     blank && composerPhase === 'blank'` → header children 不渲染），utilities 座位
     不可达 → 同一 chip 必须再注册 `conversation.input.dock`（list / session scope，
     composer 卡片上方独立行，hero 阶段同样渲染，goal bar 先例）；该 hero 座位组件
     （`HeroTaskChip`）以与 header 隐藏**完全相同的谓词**自隐藏（owner props
     `InputZone.session` 快照携带 `blank`/`composerPhase`），两座位互斥、徽标永不重复。
   - frame 级悬浮层（badge/toast/pill）才用 `shell.overlay`（root scope，需自行经
     `sessions` 服务取当前 id）。
   - 注册一律按 settings tab 先例包裹 `ctx.slots.inject('<slot>', () => ctx.slots.register(...))`：
     `package.json` 的 `dsh.client.inject` 不含声明方包时无加载顺序保证，裸 register 可能抛
     「registering into an undeclared slot throws」。
2. **模型工具输出必须是 lossless JSON**：可选字段缺失用 `null`，**禁止 `undefined`**——
   dsh-tools 的 `createSuccessResult → snapshotToolValue → snapshotJsonValue`
   （@deepseek-ai/dsh-session json.js）对任一 own enumerable 值为 undefined 的属性整体返回
   undefined 并抛 `ToolOutputError("value is not lossless JSON")`；工具 `output.schema`
   应声明 `oneOf:[string,null]` 与之一致。
3. **依赖 web 服务的功能用 `ctx.inject(['webServer','sessions'], cb)` 子 fiber 挂载**
   （先例 `lib/settings.js:40`）：headless（无 web 服务）profile 下该功能整体不激活，
   主 fiber 上的面包屑/skills/诊断工具不受影响；路由 disposer 交 `web.effect`，清理监听
   用 `web.on('session/disposed', ...)`。
4. **浏览器只读 API 路由契约**（`POST /trellis-workflow/api/task-state`）：
   - 本地 trust-fence 在前（`lib/trust.js`，dsh-client-connection 的 `isTrustedApiRequest`
     未从包公共入口导出，需本地重实现 ~40 行；**Node `URL.hostname` 对 IPv6 返回带括号的
     `[::1]`**，环回判断须同时含 `'::1'` 与 `'[::1]'`）；
   - 非 POST → 405；body 超限/非 JSON → 400；未知/不存活 session 与缓存缺失同态返回
     稳定 `no-summary`（避免探测差异）；**任何浏览器请求不触发项目解析或 fs 读取**；
   - 响应为 path-free 摘要（`{ kind, title?, status?, stage?, phase, workType? }`），
     绝不回传项目根/任务目录/runtime 路径或底层错误细节。
5. **项目活动任务选择是确定性纯函数**（`activeTaskPointer`）：精确文件名
   `dsh-session.json` 优先，否则 runtime 目录文件名字典序取首个含 `current_task` 的；
   不用 mtime（dsh-fs `FsInfo` 无 mtime）。
6. **阶段轨道单一词表**：`lib/state.js` 的 `TRACKS` 与
   `skills/_templates/work-types.md` 对齐（feat 末端 `finish` 为 completed 展示性节点，
   非可写 work.stage）；客户端 `CHIP_TRACKS` 为同一词表的展示副本。

## 已知坑（防复发）

- 工具 execute 返回对象含 undefined 可选字段 → `ToolOutputError`（见约定 2）。
- `slots.register` 裸调用在声明方未加载时抛错（见约定 1，用 `slots.inject` 包裹）。
- **徽标缓存刷新链路**：Web 徽标只消费 host 缓存；缓存写入点有 `trellis_ui_update`
  工具、`trellis_task_create`（建任务成功后即时刷新本会话摘要）与每轮 `agent/pre-step`
  顺带刷新（现已在 `lib/index.js` 的 pre-step 中实现，命中 allowlist 的会话每轮自动刷新
  缓存）。曾踩坑：仅靠模型自觉调用工具时，创建任务后 UI 长期不刷新——pre-step 刷新是
  兜底，模型在阶段切换/建任务后仍应调用 `trellis_ui_update` 以获得当轮即时刷新。
- Web UI 是否可见依赖 allowlist：`F:\dsh-plugins\dsh-trellis` 不在
  `C:\Users\12644\.dsh\settings.yaml` 的 `trellis-workflow.allowlist` 时，该会话徽标按
  `no-match` 隐藏（属配置，非缺陷）；验证 UI 需把项目根加入 allowlist 并**重启 DSH**
  （静态 Cordis 插件改动无热重载）。
- **新对话看不到徽标 → 无法激活任务**：blank 会话的 session header 被 harness 隐藏
  （`children: !hideChrome && ...`），只注册 utilities 座位时新对话（首条消息前）徽标
  完全不可达——必须补 `conversation.input.dock` hero 座位（见约定 1）。blank 会话在
  host 端真实存在（`connectWorkspace` 经 `session.create` 创建，cwd=workspace 路径），
  task-state/board/bind API 在首条消息前即可正常解析。
- **HeroTaskChip 谓词曾引用不存在的 `composerPhase`**：`conversation.input.dock` 的 owner
  props（`InputZone`）只暴露 `session: SessionSnapshot`，不含 `composerPhase`。曾用
  `session.composerPhase === 'blank'` 导致 `headerHidden` 恒为 `false`、chip 从不渲染；
  正确谓词为 `session.blank === true`（空白会话下与 `hideChrome` 等价）。

## Mini 任务看板约定（feat-08-17-trellis-kanban 沉淀）

7. **会话级活动任务解析**（`activeTaskForSession`）：本会话指针文件
   `<sessionFileBasename(sessionId)>.json` 存在时以其 `current_task` 为准（含显式
   `null` = 已解绑，**不回退** canonical）；文件不存在（legacy 会话）才回退
   `activeTaskPointer` 项目级选择。`resolveProjectState` 带 sessionId 解析——
   面包屑/trellis_state/chip 摘要三处一致，并行会话各绑各的任务互不覆盖。
8. **看板 API**：`POST /trellis-workflow/api/board`（读取，trust-fence + 会话存活 +
   header.cwd → allowlist；浏览器触发时允许直接 fs 读取，因其由用户显式打开、低频）；
   `POST /trellis-workflow/api/bind`（变更）：请求只带 `{sessionId, taskSlug|null}`；
   **项目 root 永远来自会话 header**，taskSlug 过白名单
   `/^[A-Za-z0-9._-]{1,120}$/` + 对 root 存在性校验；只写本会话指针文件，写后刷新
   chip 缓存（refreshSummary → lruSet）。浏览（board）绝不改状态；变更只有显式按钮。
9. **归档按月份折叠**：slug `MM-DD` 段（`monthKeyFromSlug`）分组；completed 任务只读，
   禁止激活；月份数字倒序、默认折叠、无时间戳 slug 归「其他」桶。
10. **Cordis `ctx.inject(services, cb)` 回调收到的是子 Context**：`cb` 内
    `web.fs`/`web.sessions`/`web.get('sandboxPolicy')` 均可直接使用（`web` = 子 ctx，
    非首个服务对象）；依赖该形态写路由，勿假设参数是单个服务。

## 看板双模态与对话联动约定（feat-04-18-kanban-overhaul 沉淀）

11. **阶段泳道单一事实源 = `lib/state.js` TRACKS，随 board 下发**：`buildBoard` 在 payload
    中携带 `tracks`（feat 含 `design-review` 共 6 阶段 + `finish` 显示终端；issue/refactor
    同理）；客户端**禁止维护第三份轨道常量**（曾删除 `CHIP_TRACKS`），泳道/阶段流一律从
    `board.tracks` 读取。`phase === 'completed'`（含 `archived: true`）一律归 Archive 泳道。
12. **看板 steps 聚合字段（lossless-JSON，可选字段 null 非 undefined）**：
    `totalSteps/completedSteps/hasBlocked/blockedReason（取数组顺序第一个 blocked 步骤，
    无则 null）/hasPendingVerification/activeStep`。`activeStep` 必须由宿主端 `findActiveStep`
    计算下发（blocked > in_progress > verifying > pending 优先级），客户端**只负责插入**，
    不得自行拼装推进 Prompt——否则丢失验证门禁（verification: human 人卡点）与 attention 优先级。
    畸形 steps（非对象元素）在 readTask 先过滤再聚合。
13. **克制交互（No Direct State Mutation）**：看板 UI 不提供任何修改任务状态的交互（不拖拽、
    不直接推进 stage）；唯一"推进"方式是「💬 推进任务」把指令**注入 Composer 输入框**，由
    Agent 遵循契约执行。产物预览不内置 Markdown 渲染器——点击产物生成 `@.trellis/tasks/...`
    原生文件 Token（**归档任务必须走 `@.trellis/tasks/archive/<month>/<slug>/<name>` 分支**，
    否则生成死引用），交 DSH 原生文件系统承载。
14. **Composer 注入手法（React 受控输入）**：直接赋 `.value` 不更新 React 受控状态——必须
    `Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, text)` + 派发 `input`/`change`
    事件；contenteditable 用 `execCommand('insertText')`；全部失败降级剪贴板复制 + 提示。
    定位优先级：`textarea[data-testid]` → `textarea[placeholder]` → contenteditable。
15. **新增 UI 入口必须对异步数据做空值守卫**（P1 踩坑）：展开大看板时 board 可能尚未加载
    （fetch 进行中/失败），`board.tasks` 对 null 取值直接抛 TypeError 使渲染中断——组件在
    取值前检查 `!board` 并渲染加载占位；「展开」动作**恒触发 `loadBoard()`**（而非
    `if (!board)`），避免展示陈旧快照（设计契约：展开即重拉）。
16. **看板记录 `phase` 由宿主端 `phaseForTask` 解析并透传 inline**：`buildBoard(..., inline)`
    将 inline 传至 `readTask → phaseForTask(parsed, inline)`，看板与徽标 phase 一致
    （planning-inline / in_progress-inline）。

## 看板 UI 重设计与工匠系统规范（feat-09-07-kanban-ui-redesign 沉淀）

17. **统一设计系统常量对象 `TB`**：
    所有样式通过 `TB`（Tokens Bundle）引用，全面映射 `--dsw-alias-*` 并带稳健 fallback。
    圆角（`TB.R`）、阴影（`TB.S`）、字体栈（`TB.font`）分级严谨；禁止在子组件中硬编码裸色与散乱字号。
18. **紧凑浮层采用单列全宽列表（效果图 A）**：
    浮层空间有限，不再塞入右侧详情抽屉；采用单列高可读性任务流，活动项左侧设 `3.5px` 垂直粗蓝
    Accent Bar 与蓝色弥散光晕，行末显示实心聚焦蓝灯，保障任务标题完全可读、杜绝单字省略号截断。
19. **工作台大看板泳道与列表双模态（效果图 B/C）**：
    顶栏通过 Linear 风格分段控件在「工作台（3 泳道）」与「列表（单列高密度数据网格）」间无缝切换。
    泳道按状态分为「规划中 / 进行中 / 已完成·归档」，列内卡片按生命周期混排；已完成卡片统一呈现
    100% 满格鲜绿进度与绿色对勾图标。
20. **详情抽屉纯黑实心主 CTA（Vercel 风格）**：
    右侧详情面板使用纯黑背景（`TB.color.ink`）配全宽圆角矩形作为主操作按钮，与阶段流水线 5 节点
    Stepper 及双色步骤进度条建立统一的视觉层级。

## 目录选择服务调用约定（feat-09-11-allowlist-folder-picker 沉淀）

21. **设置面板需要「选择目录」时，优先用官方目录服务，不自绘浏览器**：
    - 调用链：客户端注入 `uiWorkspace` 服务（本插件 `lib/client.js` 的 `inject` 数组含
      `'uiWorkspace'`，与 `dsh-client-ui-directory-picker-native` 同款——后者为
      `inject = ["slots", "uiWorkspace"]` 并经 `ctx.uiWorkspace.pickDirectory()` 调用），
      在组件点击时经
      `clientCtx.uiWorkspace.pickDirectory(): Promise<string | null>` 唤起 Host 原生目录选择
      对话框（Windows 上即资源管理器风格窗口）；`null` 表示用户取消（静默返回，无副作用）。
      > **更正记录（issue-09-18-folder-picker-uiworkspace-mismatch）**：本条原写作
      > `workspaces` / `clientCtx.workspaces.pickDirectory()`，属**服务名笔误**。
      > `pickDirectory()` 实际由 `@deepseek-ai/dsh-client-ui-workspace` 注册的服务
      > `uiWorkspace`（`super(ctx, "uiWorkspace")`）提供；而 `workspaces` 是
      > `@deepseek-ai/dsh-api-workspace-controller` 注册的**另一个**服务
      > （`super(ctx, "workspaces")`，成员为 `create/rename/delete/insertBefore/archiveSession`），
      > **不含** `pickDirectory`。照旧文实现会因能力守卫 `typeof pickDirectory !== 'function'`
      > 恒为真而**稳定失败**（原生对话框从不被调用）。
    - **loopback 网关**：`host.pickDirectory` 在 `dsh-client-connection` 的
      `PRIVILEGED_METHODS` 中（与 settings/credentials 同级），仅 loopback 同源放行；
      本产品 Web GUI 即 127.0.0.1 天然满足；非 loopback（trustedHosts）部署会失败 →
      必须做能力守卫（`!uiWorkspace || typeof uiWorkspace.pickDirectory !== 'function'`）与 catch 分支，
      显示可读错误并保留手输通路，绝不静默吞错或崩面板。
    - **路径归一化**：原生对话框返回 OS 分隔符（Windows 反斜杠）；Host 端
      `lib/resolve.js normalizePath` 匹配前统一 `\`→`/` + 盘符大写，所以存储侧做一次
      轻量 `replace(/\\/g, '/')` 保持 UI 展示一致即可，无需引入 Node path API（client
      bundle 为 `window.__ModuleLoader__` 单文件，不能 require Node 模块）。
    - **降级边界**：应用内 Miller 浏览（`listDirectory`/`createDirectory`）由官方
      `dsh-client-ui-directory-picker-browse` 包负责（注册于
      `conversation.hero.workspace.directoryFlow` / `sidebar.workspaces.directoryFlow` slot），
      设置面板等低频页面不重复自绘，原生对话框不可用时用错误提示 + 手输兜底即可。

## 看板主题与对比度（issue-10-08-kanban-dark-contrast / GitHub #2）

22. **先核对宿主实际定义，再使用主题 token**：DSH 的基础表面是
    `--dsw-alias-bg-base`，不存在 `--dsw-alias-bg-layer-0`。不存在的变量即使写了
    白色 fallback，也不能与会随暗色主题变浅的文字 token 安全搭配。
23. **文字与背景成对设计**：主表面、选中行、徽章、阶段圆圈都需随宿主主题调整；
    不可只修主背景而保留固定浅色选中底。强调填充色不等于可读的小字号文字色，
    文字可向宿主 label-primary 混色；固定深色 CTA 与白字、固定深蓝阶段节点与白字
    可以作为明确的配对保留。使用 CSS 变量跟随宿主即时切换，不另建 OS 主题监听器。
24. **回归覆盖必须包含明暗主题和真实渲染数据**：`test/client-theme.test.js` 从当前
    bundle 获取组件树，使用有来源的真实主题子集，检查三种看板视图、三类选中任务、
    阶段数字、类型/状态徽章与步骤标题在 light/dark/无宿主 token 下至少 4.5:1。
    轻量测试中的 CSS 解析不是浏览器；变更主题表达式后，另用浏览器计算样式验证，
    尤其是 `color-mix()` 和同一 DOM 的 light→dark→light 切换。离线页面验证不等于
    已在用户现有 GUI 安装并验收；须明确区分。
