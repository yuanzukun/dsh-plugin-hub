/**
 * ohdsh-api-facade — Host half (0.1.2 起：in-process facade，不再是回环代理).
 *
 * The plugin no longer drives agents. It is a thin, fail-closed gateway that
 * lets an external client (the manager) reach the harness session surface from
 * another machine. 0.1.2 起内部为进程内直调（typertGateway / session follow /
 * session control / waterfall），不再回环转发 HTTP；对外契约冻结：
 *
 *   POST {prefix}/proxy/<method>  ->  in-process Remote call          (unary, migrated set)
 *   POST {prefix}/proxy/respond   ->  pending-table answer            (answers)
 *   POST {prefix}/respond         ->  same handler (manager's base+method form)
 *   GET  {prefix}/events.mux      ->  WS broadcast (downlink only)
 *
 * Every proxied path requires an API key, and every method must be on the
 * whitelist — anything else is refused before touching the host. The proxy
 * never parses the RPC envelope: it forwards bytes, so the wire
 * contract belongs to DSH and the manager, not to this plugin.
 *
 * Install: pnpm add ohdsh-api-facade, then add one row to the host composition
 * (see README / examples/cordis.yml). Uninstall: remove the row and restart.
 *
 * Composition plane: this plugin publishes a cross-session HTTP surface, so it
 * belongs in the HOST composition — never inside an agent preset.
 */
import type { Context } from '@deepseek-ai/cordis'
import type { IncomingMessage, ServerResponse } from 'node:http'
import type { WebRoute, WebUpgradeRoute } from '@deepseek-ai/dsh-host-webserver'
import type { SessionId, SessionStore } from '@deepseek-ai/dsh-session'
import { setSandboxMode } from '@deepseek-ai/dsh-sandbox-policy'
// 0.1.2（A2-10）：settingsNamespace 运行时导出已删，但 dsh-settings 的模块增补
// 声明（ctx.settings: SettingsProvider）仍在本包——保留 type import 以加载它。
import type { SettingsProvider } from '@deepseek-ai/dsh-settings'
import { randomBytes, timingSafeEqual } from 'node:crypto'
import { createRequire } from 'node:module'
import z from '@deepseek-ai/schemastery'
import { WebSocket, WebSocketServer } from 'ws'
import { provisionDecision, resolveCorsOrigin, routeSegments } from './http.js'
import { DEFAULT_PROXY_WHITELIST, isProxyMethodAllowed } from './proxy.js'
import { HOST_DESCRIBE, invokeRemote, isMigrated, readHistory, type GatewayInvoker, type GatewayStreamer } from './adapter.js'
import { FollowRegistry, hostSupportsAssistantStream } from './streams.js'
import { ControlBridge } from './streams.js'
import { Answerer } from './answerer.js'
import { isRemoteSandboxMode, REMOTE_SANDBOX_MODES } from './sandbox-mode.js'
// 加载 ctx.typertGateway 的 Context 模块增补（0.1.2 内置 Remote 分发器）。
import type { TypertGateway } from '@deepseek-ai/dsh-api-gateway/types'

/** Single source of truth for the version advertised by the service index. */
const VERSION: string = (() => {
  try { return String((createRequire(import.meta.url)('../package.json') as { version?: unknown }).version ?? '0.0.0') }
  catch { return '0.0.0' }
})()

/** 诊断用：概括一个服务的类名与原型方法，供 /health 的 answererError 暴露。 */
const describeService = (value: unknown): string => {
  if (value === undefined || value === null) return 'undefined'
  const proto = Object.getPrototypeOf(value)
  const names = Object.getOwnPropertyNames(proto ?? {}).filter((n) => n !== 'constructor')
  const ctor = (proto?.constructor as { name?: string } | undefined)?.name ?? '?'
  return `${ctor} [${names.join(',')}]`
}

export interface Config {
  /** Route prefix. Defaults to /api-gw/v1. */
  prefix: string
  /** Master switch; also toggleable at runtime through the admin endpoint. */
  enabled: boolean
  /** Static API keys accepted by the gateway (in addition to the provisioned key). */
  apiKeys: string[]
  /**
   * The key minted by POST {prefix}/key, persisted through the settings scope.
   *
   * Written by the gateway, not by hand -- apiKeys is the field to edit. It is
   * stored rather than kept in memory so that the bootstrap is one-time *ever*:
   * the key a client was given keeps working across restarts, and the
   * unauthenticated mint closes permanently instead of reopening on each boot.
   */
  provisionedKey?: string
  /** Allow the one-time POST {prefix}/key bootstrap when no key exists at all. */
  allowKeyProvision: boolean
  /** Admin key for {prefix}/admin/*; unset disables the admin surface. */
  adminKey?: string
  /** CORS origin(s); default '*' (open). Set an explicit origin list for public deployments. */
  corsOrigin: string | string[]
  /** Include internal error messages in HTTP responses (helpful locally, noisy publicly). */
  exposeErrors: boolean
  /**
   * @deprecated 0.1.2 起不再回环转发；字段保留仅为兼容既有配置（Phase 5 留一版）。
   * 值不再参与任何请求路径。
   */
  proxyTarget: string
  /**
   * 允许沙箱路由把会话钉在 danger-full-access（默认拒绝）。
   *
   * 风险告知（2026-09-09 拍板）：开启即授予远端客户端全量沙箱能力，
   * 不做 docker-only 等环境限制；网关只在启动时与每次命中时写告警日志。
   */
  allowFullAccess: boolean
  /** Optional override for the proxy whitelist; defaults to DEFAULT_PROXY_WHITELIST. */
  proxyWhitelist: string[]
}

export const Config = z.object({
  prefix: z.string().default('/api-gw/v1'),
  enabled: z.boolean().default(true),
  // role('secret') on the ARRAY, not on its items: the settings redaction
  // only honours the top-level field role, so the old item-level role left
  // static keys readable in settings.describe.
  apiKeys: z.array(z.string()).role('secret').default([]),
  provisionedKey: z.string().role('secret'),
  allowKeyProvision: z.boolean().default(true),
  adminKey: z.string().role('secret'),
  corsOrigin: z.union([z.string(), z.array(z.string())]).default('*'),
  exposeErrors: z.boolean().default(true),
  proxyTarget: z.string().default('http://127.0.0.1:3080/api'),
  allowFullAccess: z.boolean().default(false),
  proxyWhitelist: z.array(z.string()).default([...DEFAULT_PROXY_WHITELIST]),
})

export default {
  inject: ['webServer'],
  Config,
  apply(ctx: Context, config: Config) {
    const webServer = ctx.webServer

    // Mutable runtime config: seeded from the composition row, then re-applied
    // live from the settings namespace (settings integration) below.
    let cfg = config
    let settingsScope: { update: (patch: object) => Promise<void> } | null = null
    /**
     * Fallback home for a minted key when there is no settings provider to
     * persist it in. A deployment without one cannot make the key durable, so it
     * keeps the old in-memory behaviour and says so in the log; everywhere else
     * cfg.provisionedKey is the real storage.
     */
    let volatileKey: string | null = null

    // ---- primitives ----

    const randomToken = (prefix: string, length: number) => {
      const alphabet = '0123456789abcdefghijklmnopqrstuvwxyz'
      let s = prefix
      const pool = randomBytes(length * 2)
      let cursor = 0
      while (s.length < prefix.length + length && cursor < pool.length) {
        const byte = pool[cursor++]
        // 252 = 7 * 36: rejecting >= 252 avoids modulo bias.
        if (byte < 252) s += alphabet[byte % 36]
      }
      while (s.length < prefix.length + length) s += alphabet[randomBytes(1)[0] % 36]
      return s
    }

    /** Constant-time string comparison (timing-attack resistant). */
    const safeEqual = (a: string, b: string) => {
      const ab = Buffer.from(a, 'utf8')
      const bb = Buffer.from(b, 'utf8')
      if (ab.length !== bb.length) return false
      return timingSafeEqual(ab, bb)
    }

    const errorDetail = (error: unknown) => {
      const message = String((error as Error)?.message ?? error)
      return cfg.exposeErrors ? message : 'internal error (set exposeErrors: true for details)'
    }

    /**
     * Access-Control-Allow-Origin carries a single value, so an allow-list is
     * matched against the request Origin and echoed (with Vary: Origin); a
     * disallowed requester gets no header at all.
     */
    const setCors = (res: ServerResponse, req?: IncomingMessage) => {
      const requestOrigin = typeof req?.headers?.origin === 'string' ? req.headers.origin : undefined
      const { origin, vary } = resolveCorsOrigin(cfg.corsOrigin, requestOrigin)
      if (origin !== null) res.setHeader('Access-Control-Allow-Origin', origin)
      if (vary) res.setHeader('Vary', 'Origin')
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
      res.setHeader('Access-Control-Allow-Headers', 'content-type, authorization, x-api-key, x-admin-key')
      res.setHeader('Access-Control-Max-Age', '600')
    }

    const sendJson = (res: ServerResponse, status: number, obj: unknown) => {
      res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' })
      res.end(JSON.stringify(obj))
    }

    /**
     * Buffered body read with a fixed cap and timeout, so a stalled client
     * cannot pin the proxy. The body is NOT parsed: the proxy forwards bytes.
     */
    const BODY_TIMEOUT_MS = 30_000
    const readBodyRaw = (req: IncomingMessage): Promise<Buffer> => new Promise((resolve, reject) => {
      const chunks: Buffer[] = []
      let size = 0
      let settled = false
      const timer = setTimeout(() => {
        if (settled) return
        settled = true
        reject(new Error('body read timeout'))
        try { req.destroy() } catch { /* noop */ }
      }, BODY_TIMEOUT_MS)
      req.on('data', (chunk: Buffer) => {
        size += chunk.length
        if (size > 1_000_000) {
          if (settled) return
          settled = true
          clearTimeout(timer)
          reject(new Error('body too large'))
          return
        }
        chunks.push(chunk)
      })
      req.on('end', () => {
        if (settled) return
        settled = true
        clearTimeout(timer)
        resolve(Buffer.concat(chunks))
      })
      req.on('error', (error) => {
        if (settled) return
        settled = true
        clearTimeout(timer)
        reject(error)
      })
    })

    // ---- auth ----

    const bearerToken = (req: IncomingMessage) => {
      const header = req.headers['authorization']
      if (typeof header !== 'string' || !header.startsWith('Bearer ')) return null
      return header.slice(7).trim()
    }

    /** Every key the deployment currently honours, from all three sources. */
    const acceptedKeys = () => {
      const keys = cfg.apiKeys.filter((key) => key !== '')
      if (cfg.provisionedKey !== undefined && cfg.provisionedKey !== '') keys.push(cfg.provisionedKey)
      if (volatileKey !== null) keys.push(volatileKey)
      return keys
    }

    const keyAccepted = (candidate: string | null) => {
      if (candidate === null || candidate === '') return false
      // Every candidate is compared against every key rather than short-circuiting
      // on the first match, so the work does not depend on which key was supplied.
      let matched = false
      for (const key of acceptedKeys()) if (safeEqual(candidate, key)) matched = true
      return matched
    }

    const authorized = (req: IncomingMessage) => {
      const xKey = req.headers['x-api-key']
      return keyAccepted(bearerToken(req)) || keyAccepted(typeof xKey === 'string' ? xKey : null)
    }

    const isAdmin = (req: IncomingMessage) => {
      if (cfg.adminKey === undefined || cfg.adminKey === '') return false
      const supplied = req.headers['x-admin-key']
      return typeof supplied === 'string' && safeEqual(supplied, cfg.adminKey)
    }

    const requireAuth = (req: IncomingMessage, res: ServerResponse) => {
      if (authorized(req)) return true
      sendJson(res, 401, { error: 'unauthorized', hint: 'Provide X-API-Key (or Authorization: Bearer <key>). POST ' + cfg.prefix + '/key provisions a key (first call only).' })
      return false
    }

    // ---- proxy ----

    /** Generous: unary calls answer quickly, but a slow create must not hang. */
    const PROXY_TIMEOUT_MS = 60_000

    /**
     * 0.1.2 起：已迁移方法经 typertGateway 进程内直调，网关自己造
     * server-response 信封（信封契约不变，manager 零感知）。
     * 未迁移方法诚实报 501——绝不静默走已失效的回环转发。
     */
    const proxyInProcess = async (req: IncomingMessage, res: ServerResponse, method: string) => {
      const raw = await readBodyRaw(req)
      let envelope: { rpcId?: unknown; method?: unknown; payload?: unknown } = {}
      try {
        envelope = JSON.parse(raw.toString('utf8') || '{}') as typeof envelope
      } catch (error) {
        return sendJson(res, 400, { error: 'bad_json', detail: errorDetail(error) })
      }
      if (envelope.method !== method) {
        return sendJson(res, 400, { error: 'method_mismatch', hint: 'envelope method must match the path method' })
      }
      const rpcId = typeof envelope.rpcId === 'string' ? envelope.rpcId : ''
      if (method === 'session.history') {
        // 0.1.2 无同名 Remote：follow 流首帧快照翻译（见 adapter.readHistory）。
        const payload = (envelope.payload ?? {}) as { sessionId?: unknown }
        if (typeof payload.sessionId !== 'string') {
          return sendJson(res, 400, { error: 'bad_request', hint: 'session.history requires payload.sessionId' })
        }
        const gateway = ctx.get('typertGateway', true) as TypertGateway | undefined
        if (gateway === undefined || gateway.stream === undefined) {
          return sendJson(res, 501, { error: 'service_unavailable', hint: 'host typertGateway stream is not available' })
        }
        try {
          const value = await readHistory(gateway as GatewayStreamer, payload.sessionId)
          return sendJson(res, 200, { type: 'server-response', rpcId, result: { ok: true, value } })
        } catch (error) {
          const code = (error as { code?: unknown })?.code
          const message = String((error as Error)?.message ?? error)
          ctx.logger?.warn?.('[ohdsh-api-facade] in-process session.history failed: ' + message)
          return sendJson(res, 200, {
            type: 'server-response',
            rpcId,
            result: { ok: false, error: { code: typeof code === 'string' ? code : 'gateway/internal', message } },
          })
        }
      }
      if (!isMigrated(method)) {
        return sendJson(res, 501, { error: 'method_not_migrated', hint: 'this method is not yet served in-process on the 0.1.2 host' })
      }
      // host.describe 由 facade 合成：version = 宿主真实 DSH 版本，
      // allowFullAccess = 本部署是否开锁 danger-full-access（manager 据此
      // 决定 UI 是否放行第三档权限——2026-09-11 拍板「风险告知+用户决策」）。
      if (method === 'host.describe') {
        return sendJson(res, 200, {
          type: 'server-response',
          rpcId,
          result: { ok: true, value: { version: HOST_DESCRIBE.version, allowFullAccess: cfg.allowFullAccess } },
        })
      }
      const gateway = ctx.get('typertGateway', true) as TypertGateway | undefined
      if (gateway === undefined) {
        return sendJson(res, 501, { error: 'service_unavailable', hint: 'host typertGateway is not available' })
      }
      try {
        const value = await invokeRemote(gateway as GatewayInvoker, method, envelope.payload, AbortSignal.timeout(PROXY_TIMEOUT_MS))
        // 直播桥：会话经网关建立/唤醒时即入流（follow 流事件经 mux 广播）。
        if (method === 'session.create') {
          const created = value as { sessionId?: unknown }
          if (typeof created.sessionId === 'string') registry.ensure(created.sessionId)
        }
        if (method === 'session.prompt') {
          const p = (envelope.payload ?? {}) as { sessionId?: unknown }
          if (typeof p.sessionId === 'string') registry.ensure(p.sessionId)
        }
        return sendJson(res, 200, { type: 'server-response', rpcId, result: { ok: true, value } })
      } catch (error) {
        const code = (error as { code?: unknown })?.code
        const message = String((error as Error)?.message ?? error)
        ctx.logger?.warn?.('[ohdsh-api-facade] in-process ' + method + ' failed: ' + message)
        return sendJson(res, 200, {
          type: 'server-response',
          rpcId,
          result: { ok: false, error: { code: typeof code === 'string' ? code : 'gateway/internal', message } },
        })
      }
    }

    /**
     * respond 桥路由（Phase 3b）。manager 按「统一 base + 方法」假设拼
     * `${base}/respond`（rpc/mux/respond 三个推导同源），老文档面则是
     * `/proxy/respond`——两条路径同一处理函数（mux 双路径同款先例）。
     *
     * 回执契约 = 老 apiproxy 的 { accepted, reason? }：manager respond.ts
     * 只认 accepted === true，HTTP 恒 200。settle 命中即回填挂起项——
     * 含 decline（not-ok + 'cancelled'）：老契约里也算认领成功。
     */
    const dispatchRespond = async (req: IncomingMessage, res: ServerResponse) => {
      if (!requireAuth(req, res)) return
      const raw = await readBodyRaw(req)
      let envelope: {
        type?: unknown
        rpcId?: unknown
        result?: { ok?: unknown; value?: unknown; error?: { code?: unknown; message?: unknown } }
      } = {}
      try {
        envelope = JSON.parse(raw.toString('utf8') || '{}') as typeof envelope
      } catch (error) {
        return sendJson(res, 400, { error: 'bad_json', detail: errorDetail(error) })
      }
      if (envelope.type !== 'client-response') {
        return sendJson(res, 200, { accepted: false, reason: 'bad-response' })
      }
      const { found } = answerer.settle(envelope)
      return sendJson(res, 200, found ? { accepted: true } : { accepted: false, reason: 'not-pending' })
    }

    /**
     * 0.1.2 mux 桥：外层 WS 客户端集合 + 每会话 follow 流注册表。
     * 事件泵把增量 SessionEventEntry 与快照投影翻译成老 mux 帧广播
     * （mirror 0.1.1 全量广播语义；manager 本地按 sessionId 过滤）。
     */
    const outerSockets = new Set<import('ws').WebSocket>()
    let registry: FollowRegistry
    let answerer: Answerer
    let controlBridge: ControlBridge
    /** 应答器挂载状态诊断（/health 与 GET / 可见）：mode remote|fallback|none。 */
    const answererStats = {
      mode: 'none', frames: 0, waterfalls: 0, error: '', broadcasts: 0,
      waterfallEvents: [] as string[], lastBroadcastAt: 0, lastBroadcastSockets: 0,
    }
    /** 兜底 ctx.on 监听器的卸载器；远程路径就绪后替换。 */
    let disposeFallback: (() => void) | null = null
    {
      const streamer = {
        stream: async (request: { namespace: string; method: string; args: Record<string, unknown> }) => {
          const gateway = ctx.get('typertGateway', true) as TypertGateway | undefined
          if (gateway === undefined || gateway.stream === undefined) {
            throw new Error('host typertGateway stream is not available')
          }
          return gateway.stream(request)
        },
      }
      registry = new FollowRegistry(
        streamer,
        (json) => {
          for (const ws of outerSockets) {
            if (ws.readyState === WebSocket.OPEN) {
              try { ws.send(json) } catch { /* socket going away */ }
            }
          }
        },
        (line) => ctx.logger?.warn?.(line),
        // 0.2.x 宿主：follow 请求带 assistantStream:true，直播 chunk 翻译回老
        // assistant/chunk wire 形（打字机复活，manager 零改动）。0.1.x 线保持
        // 已验证的原请求形状（门控与依据见 streams.ts hostSupportsAssistantStream）。
        hostSupportsAssistantStream(HOST_DESCRIBE.version),
      )
      answerer = new Answerer(
        (json) => {
          answererStats.broadcasts += 1
          answererStats.lastBroadcastAt = Date.now()
          answererStats.lastBroadcastSockets = outerSockets.size
          for (const ws of outerSockets) {
            if (ws.readyState === WebSocket.OPEN) {
              try { ws.send(json) } catch { /* socket going away */ }
            }
          }
        },
        (line) => ctx.logger?.warn?.(line),
      )
      // live projections 桥（0.1.2 实测）：host-wide session/control 流的
      // baseline + projection 增量 → 老 session/projection 帧。
      controlBridge = new ControlBridge(
        streamer,
        (json) => {
          for (const ws of outerSockets) {
            if (ws.readyState === WebSocket.OPEN) {
              try { ws.send(json) } catch { /* socket going away */ }
            }
          }
        },
        (line) => ctx.logger?.warn?.(line),
      )
    }

    /** The mux WebSocket route: downlink only, broadcast via the registry. */
    const proxyUpgrade = (wss: WebSocketServer, req: IncomingMessage, socket: import('node:stream').Duplex, head: Buffer) => {
      if (!authorized(req)) {
        // Refuse before protocol negotiation, so an unauthenticated caller
        // never reaches the handshake.
        socket.end('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n')
        return
      }
      wss.handleUpgrade(req, socket, head, (outer) => {
        outer.on('message', () => outer.close(1008, 'downlink only'))
        outerSockets.add(outer)
        outer.on('close', () => { outerSockets.delete(outer) })
        outer.on('error', () => { outerSockets.delete(outer) })
        // 当前挂载会话全部入流（新会话经 create/prompt 路由触发 ensure）。
        const sessions = ctx.get('sessions', true) as { list?: () => Array<{ id: string }> } | undefined
        if (sessions?.list !== undefined) {
          for (const s of sessions.list()) registry.ensure(s.id)
        }
      })
    }

    /** Upstream liveness for /health: the in-process Remote dispatcher. */
    const healthUpstream = (): 'ok' | 'unreachable' => {
      return ctx.get('typertGateway', true) !== undefined ? 'ok' : 'unreachable'
    }

    // ---- HTTP dispatch ----

    const dispatch = async (req: IncomingMessage, res: ServerResponse) => {
      setCors(res, req)
      if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return }
      const seg = routeSegments(cfg.prefix, req.url)
      if (seg === null) return sendJson(res, 404, { error: 'not_found', service: 'ohdsh-api-facade' })

      // health stays reachable while disabled, for monitoring
      if (seg.length === 1 && seg[0] === 'health' && req.method === 'GET') {
        const upstream = healthUpstream()
        return sendJson(res, 200, {
          status: cfg.enabled ? 'ok' : 'disabled',
          enabled: cfg.enabled,
          upstream,
          apiKeySet: acceptedKeys().length > 0,
          dshVersion: HOST_DESCRIBE.version,
          allowFullAccess: cfg.allowFullAccess,
          answerer: answererStats.mode,
          answererFrames: answererStats.frames,
          answererWaterfalls: answererStats.waterfalls,
          answererPending: answerer.pendingCount(),
          answererPendingIds: answerer.pendingIds(),
          answererError: answererStats.error,
          answererBroadcasts: answererStats.broadcasts,
          answererWaterfallEvents: answererStats.waterfallEvents,
          answererLastBroadcastAt: answererStats.lastBroadcastAt,
          answererLastBroadcastSockets: answererStats.lastBroadcastSockets,
        })
      }
      if (!cfg.enabled) return sendJson(res, 503, { error: 'service_disabled' })

      if (seg.length === 0 && req.method === 'GET') {
        return sendJson(res, 200, {
          service: 'ohdsh-api-facade', version: VERSION,
          answerer: answererStats.mode,
          answererFrames: answererStats.frames,
          answererWaterfalls: answererStats.waterfalls,
          answererPending: answerer.pendingCount(),
          endpoints: [
            { method: 'GET', path: cfg.prefix + '/health', auth: false },
            { method: 'POST', path: cfg.prefix + '/key', auth: 'first call only' },
            { method: 'POST', path: cfg.prefix + '/admin/enable', auth: 'admin' },
            { method: 'POST', path: cfg.prefix + '/admin/rotate-key', auth: 'admin' },
            { method: 'POST', path: cfg.prefix + '/proxy/<method>', auth: true, note: 'apiproxy unary passthrough (whitelisted)' },
            { method: 'POST', path: cfg.prefix + '/respond', auth: true, note: 'answer questions / approvals (manager base+method form)' },
            { method: 'POST', path: cfg.prefix + '/proxy/respond', auth: true, note: 'answer questions / approvals (legacy path)' },
            { method: 'GET', path: cfg.prefix + '/answerer/pending', auth: true, note: 'recovery channel: pending question/approval broadcasts (card-loss fix)' },
            { method: 'POST', path: cfg.prefix + '/sessions/{id}/sandbox-mode', auth: true, note: 'per-session sandbox override (read-only | workspace-write)' },
            { method: 'GET', path: cfg.prefix + '/events.mux', auth: true, note: 'WebSocket, downlink only' },
          ],
        })
      }

      /**
       * One-time bootstrap: mint the first key, then close for good.
       *
       * Unauthenticated *only* while the deployment has no key from any source --
       * the single moment when there is no credential that could be demanded. The
       * minted key is persisted before it is returned, so provisionDecision
       * refuses every later call, including after a restart. A caller that
       * already holds a key is refused too: it has nothing to learn here, and
       * echoing a stored secret back over an authenticated request is a way to
       * leak the *other* keys a deployment has.
       */
      if (seg.length === 1 && seg[0] === 'key' && req.method === 'POST') {
        const decision = provisionDecision({
          provisionedKey: cfg.provisionedKey,
          apiKeys: cfg.apiKeys,
          allowKeyProvision: cfg.allowKeyProvision,
          prefix: cfg.prefix,
        })
        if (decision.action === 'refuse') {
          return sendJson(res, decision.status, { error: decision.error, hint: decision.hint })
        }

        const minted = randomToken('apigw-', 32)
        if (settingsScope !== null) {
          try {
            await settingsScope.update({ provisionedKey: minted })
          } catch (error) {
            // Reported rather than returned: handing out a key that silently did
            // not persist is how the caller ends up with a credential that dies
            // at the next restart without anyone knowing why.
            return sendJson(res, 500, { error: 'settings_update_failed', detail: errorDetail(error) })
          }
          // The settings watcher refreshes cfg asynchronously; setting it here
          // means the key works on the very next request either way.
          cfg = { ...cfg, provisionedKey: minted }
        } else {
          volatileKey = minted
          ctx.logger?.warn?.('[ohdsh-api-facade] no settings provider: the provisioned key is in memory only and will not survive a restart. Set config.apiKeys for a durable key.')
        }
        // Never logged: the log is the one place a secret leaks without anyone
        // authenticating for it.
        ctx.logger?.info?.('[ohdsh-api-facade] API key provisioned (one-time bootstrap now closed)')
        return sendJson(res, 200, { apiKey: minted, persisted: settingsScope !== null })
      }

      // Admin surface (X-Admin-Key): runtime master switch + key rotation.
      if (seg.length === 2 && seg[0] === 'admin' && seg[1] === 'enable' && req.method === 'POST') {
        if (!isAdmin(req)) return sendJson(res, 401, { error: 'admin_unauthorized' })
        let body: Record<string, unknown> = {}
        try { body = JSON.parse((await readBodyRaw(req)).toString('utf8') || '{}') } catch (error) { return sendJson(res, 400, { error: errorDetail(error) }) }
        const nextEnabled = body.enabled === true
        if (settingsScope !== null) {
          try { await settingsScope.update({ enabled: nextEnabled }) } catch (error) {
            return sendJson(res, 500, { error: 'settings_update_failed', detail: errorDetail(error) })
          }
        } else {
          cfg = { ...cfg, enabled: nextEnabled }
        }
        return sendJson(res, 200, { enabled: cfg.enabled })
      }
      // Replaces the provisioned key only. apiKeys is the operator's own list
      // and rotating over it would silently revoke keys the gateway was never
      // asked to manage.
      if (seg.length === 2 && seg[0] === 'admin' && seg[1] === 'rotate-key' && req.method === 'POST') {
        if (!isAdmin(req)) return sendJson(res, 401, { error: 'admin_unauthorized' })
        const minted = randomToken('apigw-', 32)
        if (settingsScope !== null) {
          try {
            await settingsScope.update({ provisionedKey: minted })
          } catch (error) {
            return sendJson(res, 500, { error: 'settings_update_failed', detail: errorDetail(error) })
          }
          cfg = { ...cfg, provisionedKey: minted }
        } else {
          volatileKey = minted
        }
        ctx.logger?.info?.('[ohdsh-api-facade] API key rotated')
        return sendJson(res, 200, { apiKey: minted, persisted: settingsScope !== null })
      }

      // respond 桥：manager 拼 `${base}/respond`；/proxy/respond 是网关文档面
      // 老路径——两条同处理。必须在通用 proxy 分支之前，否则 respond 会落到
      // 白名单外的迁移检查上（501）。
      const respondPath = (seg.length === 1 && seg[0] === 'respond')
        || (seg.length === 2 && seg[0] === 'proxy' && seg[1] === 'respond')
      if (respondPath && req.method === 'POST') {
        try {
          await dispatchRespond(req, res)
        } catch (error) {
          ctx.logger?.warn?.('[ohdsh-api-facade] respond failed: ' + String(error))
          if (res.headersSent) { try { res.destroy() } catch { /* noop */ } ; return }
          return sendJson(res, 500, { error: 'internal_error', detail: errorDetail(error) })
        }
        return
      }

      // 卡片链(2026-09-17):manager 的挂起问答恢复通道——question/approval 帧
      // 只广播一次,断线窗口/manager 重启后卡片即永久丢失。本端点把仍挂起的
      // 载荷(rpcId + method + payload)按需交给 manager,由它重放/重建卡片。
      if (seg.length === 2 && seg[0] === 'answerer' && seg[1] === 'pending' && req.method === 'GET') {
        if (!requireAuth(req, res)) return
        return sendJson(res, 200, { pending: answerer.pendingList() })
      }

      // The proxy surface: auth first, then whitelist (fail closed), then bytes.
      // Auth before whitelist so an unauthenticated caller cannot probe which
      // methods exist by telling 403 from 401 apart.
      if (seg.length === 2 && seg[0] === 'proxy' && req.method === 'POST') {
        if (!requireAuth(req, res)) return
        const method = seg[1]
        if (!isProxyMethodAllowed(method, cfg.proxyWhitelist)) {
          return sendJson(res, 403, { error: 'method_not_allowed', hint: 'The requested apiproxy method is not on the proxy whitelist.' })
        }
        try {
          await proxyInProcess(req, res, method)
        } catch (error) {
          ctx.logger?.warn?.('[ohdsh-api-facade] proxy ' + method + ' failed: ' + String(error))
          if (res.headersSent) { try { res.destroy() } catch { /* noop */ } ; return }
          return sendJson(res, 502, { error: 'upstream_unreachable', detail: errorDetail(error) })
        }
        return
      }

      /**
       * Per-session sandbox-mode override.
       *
       * The wire contract has no sandbox field: session.create takes
       * { cwd | workspaceId, sessionId?, agentPreset? }, and no RPC switches a
       * session's mode. The host keeps the override as `sandbox/mode` log
       * events (dsh-sandbox-policy/session-mode), and its write path is
       * process-internal — so this small route is the only way a remote client
       * (the manager) can pin a fresh session's mode before the first prompt.
       *
       * Capped at workspace-write by default: danger-full-access needs the
       * operator's explicit `allowFullAccess` opt-in (风险告知，2026-09-09 拍板：
       * 不限制 docker-only，只做告警).
       * Only live sessions can be pinned; the override is durable (log replay
       * restores it after a cold wake), so one call at creation time suffices.
       */
      if (seg.length === 3 && seg[0] === 'sessions' && seg[2] === 'sandbox-mode' && req.method === 'POST') {
        if (!requireAuth(req, res)) return
        const sessionId = seg[1]
        let body: Record<string, unknown> = {}
        try {
          body = JSON.parse((await readBodyRaw(req)).toString('utf8') || '{}')
        } catch (error) {
          return sendJson(res, 400, { error: 'bad_json', detail: errorDetail(error) })
        }
        if (!isRemoteSandboxMode(body.mode, cfg.allowFullAccess)) {
          return sendJson(res, 400, {
            error: 'invalid_mode',
            hint: 'mode must be one of: ' + REMOTE_SANDBOX_MODES.join(', ')
              + (cfg.allowFullAccess ? ', danger-full-access' : ' (danger-full-access needs allowFullAccess)'),
          })
        }
        if (body.mode === 'danger-full-access') {
          // 风险告知：每次命中都留一条醒目告警（拍板：不做环境限制，只告知）。
          ctx.logger?.warn?.(`[ohdsh-api-facade] session ${sessionId} pinned to danger-full-access by a remote client (allowFullAccess is ON)`)
        }
        // Soft dependency: a host without the session store degrades cleanly
        // instead of breaking plugin startup (RULE 2).
        const sessions = ctx.get('sessions', true) as SessionStore | undefined
        if (sessions === undefined) {
          return sendJson(res, 501, { error: 'service_unavailable', hint: 'host session store is not available' })
        }
        const session = sessions.get(sessionId as SessionId)
        if (session === undefined) {
          return sendJson(res, 409, {
            error: 'session_not_live',
            hint: 'only live (attached) sessions accept a sandbox-mode override',
          })
        }
        setSandboxMode(session, body.mode)
        return sendJson(res, 200, { sessionId, mode: body.mode })
      }

      return sendJson(res, 404, { error: 'not_found' })
    }

    // ---- mount ----

    // One noServer acceptor for all mux upgrades; handleUpgrade is called
    // per connection so the auth check runs before protocol negotiation.
    const wss = new WebSocketServer({ noServer: true })
    wss.on('error', () => { /* an aborted upgrade must not crash the host */ })

    let disposeRoute: (() => void) | null = null
    const disposeUpgrades: Array<() => void> = []
    const mountRoutes = () => {
      if (disposeRoute !== null) { try { disposeRoute() } catch { /* noop */ } ; disposeRoute = null }
      while (disposeUpgrades.length > 0) { try { disposeUpgrades.pop()!() } catch { /* noop */ } }
      const route: WebRoute = {
        kind: 'prefix',
        path: cfg.prefix,
        // The promise is returned so the carrier (and tests) can await the
        // full response lifecycle; SSE-style long responses were removed in S3.
        handler: (req, res) => Promise.resolve(dispatch(req, res)).catch((error) => {
          ctx.logger?.warn?.('[ohdsh-api-facade] request failed: ' + String(error))
          try {
            if (res.headersSent) res.destroy()
            else sendJson(res, 500, { error: 'internal_error', detail: errorDetail(error) })
          } catch { /* noop */ }
        }),
      }
      disposeRoute = webServer.register(route)
      // Two upgrade paths: the canonical one (matching the plan's surface)
      // and one under /proxy so a client whose base is the proxy prefix
      // (the manager's uniform base + method assumption) derives the mux
      // URL without any special case.
      for (const path of [cfg.prefix + '/events.mux', cfg.prefix + '/proxy/events.mux']) {
        const upgrade: WebUpgradeRoute = {
          path,
          handler: (req, socket, head) => proxyUpgrade(wss, req, socket, head),
        }
        disposeUpgrades.push(webServer.registerUpgrade(upgrade))
      }
    }

    ctx.effect(() => {
      mountRoutes()
      // 兜底：ctx.on 瀑布监听器（connection 注入不到或 $events 打不开的部署）。
      // 挂上即生效；远程路径就绪后由下方 inject fiber 替换。
      answererStats.mode = 'fallback'
      disposeFallback = answerer.mount(ctx)
      // live projections 桥：一个宿主级 control 流，随插件生命周期开关。
      controlBridge.start()
      return () => {
        controlBridge.dispose()
        if (disposeFallback !== null) { disposeFallback(); disposeFallback = null }
        if (disposeRoute !== null) { try { disposeRoute() } catch { /* noop */ } ; disposeRoute = null }
        while (disposeUpgrades.length > 0) { try { disposeUpgrades.pop()!() } catch { /* noop */ } }
        // Terminated rather than closed politely: an unload must not wait on
        // clients that keep their sockets open.
        for (const client of wss.clients) client.terminate()
        wss.close()
      }
    })

    // 方案 A：connection 服务可能晚于 facade 注册（ctx.get optional 不等待，
    // 注入会等——gateway 同款拿法）。就绪后开 $events 客户端流替换兜底。
    ctx.inject(['connection'] as never, (connectionCtx) => {
      const cctx = connectionCtx as Context & {
        connection?: { createSharedFetchHandler?: (channel: string) => { fetch: (request: Request) => Promise<Response> } }
      }
      cctx.effect(() => {
        let disposeRemote: (() => void) | null = null
        let disposed = false
        void (async () => {
          const gateway = ctx.get('typertGateway', true) as
            (TypertGateway & { wireStream?: { open?: (endpoint: string, payload: unknown, ...rest: unknown[]) => Promise<AsyncIterable<unknown>> } }) | undefined
          // 宿主侧 connection 没有浏览器客户端的 rpc.call；进程内发 $events/result
          // 走共享通道的 Fetch handler（与浏览器信封同形，gateway 拦截路由到
          // dispatchRpc —— dsh-client-connection/src/rpc-host.ts 实证）。
          const connection = cctx.connection
          if (gateway?.wireStream?.open === undefined || connection?.createSharedFetchHandler === undefined) {
            answererStats.error = gateway?.wireStream?.open === undefined
              ? `typertGateway.wireStream.open missing (${describeService(gateway)})`
              : `connection carrier missing (${describeService(connection)})`
            return
          }
          // wireStream.open 签名在 0.1.7→0.2.0 走廊漂移（两代宿主树 lib 实证，
          // 192.168.33.11）：旧宿主 (endpoint, payload, signal)——arity 3；
          // dsh-api-gateway 0.2.0 起 (endpoint, payload, uplink, peer, signal)——arity 5
          // （J1-06 duplex uplink + 显式 Peer）。$events 是纯下行：uplink/peer 传
          // undefined（宿主 releaseUplink 对非异步可迭代静默容忍、openRemoteEvents
          // 不读 peer）。若按旧 3 参调用新宿主，signal 会落进 uplink 槽而 signal=
          // undefined——惰性生成器 open 不抛错、首次迭代 AbortSignal.any 才炸，
          // 泵静默死亡且 health 无错可报（实测：answererFrames=0、问答永久挂起）。
          const openWire = gateway.wireStream.open
          const duplexSig = openWire.length >= 5
          const sharedFetch = connection.createSharedFetchHandler('/api')
          try {
            const mounted = await answerer.mountRemote({
              openStream: (endpoint, payload, signal) => (duplexSig
                ? openWire(endpoint, payload, undefined, undefined, signal)
                : openWire(endpoint, payload, signal)),
              sendResult: async (args, signal) => {
                const response = await sharedFetch.fetch(new Request('http://ohdsh-internal/api/$events/result', {
                  method: 'POST',
                  headers: { 'content-type': 'application/json' },
                  body: JSON.stringify({ type: 'client-request', rpcId: `apigw-${randomBytes(8).toString('hex')}`, method: '$events/result', payload: { args } }),
                  signal,
                }))
                if (!response.ok) throw new Error(`$events/result: HTTP ${response.status}`)
              },
              onFrame: (kind, event) => {
                answererStats.frames += 1
                if (kind === 'waterfall') {
                  answererStats.waterfalls += 1
                  if (typeof event === 'string' && answererStats.waterfallEvents.length < 8) answererStats.waterfallEvents.push(event)
                }
              },
            })
            if (disposed) {
              mounted()
            } else {
              disposeRemote = mounted
              answererStats.mode = 'remote'
              if (disposeFallback !== null) { disposeFallback(); disposeFallback = null }
              ctx.logger?.info?.('[ohdsh-api-facade] answerer mounted via in-process remote event client ($events)')
            }
          } catch (error) {
            answererStats.error = String((error as Error)?.message ?? error)
            ctx.logger?.warn?.('[ohdsh-api-facade] remote event stream unavailable (' + answererStats.error + ') — keeping in-host waterfall listeners')
          }
        })()
        return () => {
          disposed = true
          if (disposeRemote !== null) { disposeRemote(); disposeRemote = null }
        }
      })
    })

    // Settings integration: expose the gateway Config as a live settings
    // namespace so edits apply without a restart. Secret fields (adminKey /
    // apiKeys) are declared role('secret') in the schema, so the wire surface
    // redacts them. Non-fatal by design: a deployment without a settings
    // provider simply keeps the composition-row config.
    //
    // The namespace is 'ohdsh-api-facade': DSH ships a built-in
    // @deepseek-ai/dsh-api-gateway (the typert Remote dispatcher), so a card
    // keyed 'api-gateway' would be indistinguishable from it in the plugin list.
    ctx.inject(['settings'], (sctx) => {
      try {
        // 0.1.2（A2-10）：settingsNamespace 运行时导出已删——命名空间是编译期
        // 校验的字符串字面量（小写连字符标识符），register 签名不变。
        const provider: SettingsProvider = sctx.settings
        const scope = provider.register('ohdsh-api-facade', Config, { base: config, applies: 'live' })
        settingsScope = scope
        const resolved = scope.get()
        const prefixChanged = resolved.prefix !== cfg.prefix
        cfg = resolved
        if (prefixChanged) mountRoutes()
        scope.watch((next, prev) => {
          const changed = next.prefix !== prev.prefix
          cfg = next
          if (changed) mountRoutes()
        })
      } catch (error) {
        ctx.logger?.warn?.('[ohdsh-api-facade] settings namespace not registered: ' + String(error))
      }
    })

    ctx.logger?.info?.('[ohdsh-api-facade] mounted at ' + cfg.prefix + ' (facade, enabled=' + String(cfg.enabled) + ')')
    if (cfg.allowFullAccess) {
      ctx.logger?.warn?.('[ohdsh-api-facade] allowFullAccess is ON: remote clients may pin sessions to danger-full-access. This is an operator opt-in with no environment restriction — review before leaving it enabled.')
    }
  },
}

