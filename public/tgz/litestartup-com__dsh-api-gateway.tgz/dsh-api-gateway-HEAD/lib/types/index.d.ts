/**
 * ohdsh-api-facade — Host half (0.1.2 起：in-process facade，不再是回环代理).
 *
 * The plugin no longer drives agents. It is a thin, fail-closed gateway that
 * lets an external client (the manager) reach the harness session surface from
 * another machine. 0.1.2 起内部为进程内直调（typertGateway / session follow /
 * session control / waterfall），不再回环转发 HTTP；对外契约冻结：
 *
 *   POST {prefix}/proxy/<method>  ->  in-process Remote call          (unary, migrated set)
 *   POST {prefix}/proxy/respond   ->  pending-table answer            (answers)
 *   POST {prefix}/respond         ->  same handler (manager's base+method form)
 *   GET  {prefix}/events.mux      ->  WS broadcast (downlink only)
 *
 * Every proxied path requires an API key, and every method must be on the
 * whitelist — anything else is refused before touching the host. The proxy
 * never parses the RPC envelope: it forwards bytes, so the wire
 * contract belongs to DSH and the manager, not to this plugin.
 *
 * Install: pnpm add ohdsh-api-facade, then add one row to the host composition
 * (see README / examples/cordis.yml). Uninstall: remove the row and restart.
 *
 * Composition plane: this plugin publishes a cross-session HTTP surface, so it
 * belongs in the HOST composition — never inside an agent preset.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export interface Config {
    /** Route prefix. Defaults to /api-gw/v1. */
    prefix: string;
    /** Master switch; also toggleable at runtime through the admin endpoint. */
    enabled: boolean;
    /** Static API keys accepted by the gateway (in addition to the provisioned key). */
    apiKeys: string[];
    /**
     * The key minted by POST {prefix}/key, persisted through the settings scope.
     *
     * Written by the gateway, not by hand -- apiKeys is the field to edit. It is
     * stored rather than kept in memory so that the bootstrap is one-time *ever*:
     * the key a client was given keeps working across restarts, and the
     * unauthenticated mint closes permanently instead of reopening on each boot.
     */
    provisionedKey?: string;
    /** Allow the one-time POST {prefix}/key bootstrap when no key exists at all. */
    allowKeyProvision: boolean;
    /** Admin key for {prefix}/admin/*; unset disables the admin surface. */
    adminKey?: string;
    /** CORS origin(s); default '*' (open). Set an explicit origin list for public deployments. */
    corsOrigin: string | string[];
    /** Include internal error messages in HTTP responses (helpful locally, noisy publicly). */
    exposeErrors: boolean;
    /**
     * @deprecated 0.1.2 起不再回环转发；字段保留仅为兼容既有配置（Phase 5 留一版）。
     * 值不再参与任何请求路径。
     */
    proxyTarget: string;
    /**
     * 允许沙箱路由把会话钉在 danger-full-access（默认拒绝）。
     *
     * 风险告知（2026-09-09 拍板）：开启即授予远端客户端全量沙箱能力，
     * 不做 docker-only 等环境限制；网关只在启动时与每次命中时写告警日志。
     */
    allowFullAccess: boolean;
    /** Optional override for the proxy whitelist; defaults to DEFAULT_PROXY_WHITELIST. */
    proxyWhitelist: string[];
}
export declare const Config: z<Schemastery.ObjectS<{
    prefix: z<string, string>;
    enabled: z<boolean, boolean>;
    apiKeys: z<string[], string[]>;
    provisionedKey: z<string, string>;
    allowKeyProvision: z<boolean, boolean>;
    adminKey: z<string, string>;
    corsOrigin: z<string | string[], string | string[]>;
    exposeErrors: z<boolean, boolean>;
    proxyTarget: z<string, string>;
    allowFullAccess: z<boolean, boolean>;
    proxyWhitelist: z<string[], string[]>;
}>, Schemastery.ObjectT<{
    prefix: z<string, string>;
    enabled: z<boolean, boolean>;
    apiKeys: z<string[], string[]>;
    provisionedKey: z<string, string>;
    allowKeyProvision: z<boolean, boolean>;
    adminKey: z<string, string>;
    corsOrigin: z<string | string[], string | string[]>;
    exposeErrors: z<boolean, boolean>;
    proxyTarget: z<string, string>;
    allowFullAccess: z<boolean, boolean>;
    proxyWhitelist: z<string[], string[]>;
}>>;
declare const _default: {
    inject: string[];
    Config: z<Schemastery.ObjectS<{
        prefix: z<string, string>;
        enabled: z<boolean, boolean>;
        apiKeys: z<string[], string[]>;
        provisionedKey: z<string, string>;
        allowKeyProvision: z<boolean, boolean>;
        adminKey: z<string, string>;
        corsOrigin: z<string | string[], string | string[]>;
        exposeErrors: z<boolean, boolean>;
        proxyTarget: z<string, string>;
        allowFullAccess: z<boolean, boolean>;
        proxyWhitelist: z<string[], string[]>;
    }>, Schemastery.ObjectT<{
        prefix: z<string, string>;
        enabled: z<boolean, boolean>;
        apiKeys: z<string[], string[]>;
        provisionedKey: z<string, string>;
        allowKeyProvision: z<boolean, boolean>;
        adminKey: z<string, string>;
        corsOrigin: z<string | string[], string | string[]>;
        exposeErrors: z<boolean, boolean>;
        proxyTarget: z<string, string>;
        allowFullAccess: z<boolean, boolean>;
        proxyWhitelist: z<string[], string[]>;
    }>>;
    apply(ctx: Context, config: Config): void;
};
export default _default;
