# dsh-file-panel v0.1.0

首个版本：DeepSeek Harness 的「会话文件」右侧弹出面板。

## 功能 / Features

- 自动追踪 Agent 创建/下载的文件：双源监听 —— Harness `fs/observed` 事件（write/edit 等工具）+ 会话工作目录的递归 `fs.watch`（curl、Invoke-WebRequest、git、解压等 shell 下载也能捕获）
- 新文件到达时右侧面板**自动弹出**，新文件带 `新` 徽标；收起后右下角悬浮按钮显示新文件数量角标
- 预览：图片 base64 内联显示；文本文件内联显示前 256 KB；其他类型显示元信息
- 「所在位置」：在系统文件管理器中定位文件（Windows `explorer.exe /select`、macOS `open -R`、Linux `xdg-open`）
- 「打开」：用系统默认程序打开文件（复用 Harness 内置 `host.openPath`）
- 「复制路径」：一键复制绝对路径
- 底部「打开工作目录」快捷入口
- 中英双语（跟随 GUI 语言）、MIT 开源、单元/冒烟测试与 CI 齐全

## 安装 / Install

```sh
dsh plugin --profile web add github:yu2025-luo/dsh-file-panel#v0.1.0
```

重启 `dsh web` 并刷新 `http://127.0.0.1:3080` 即生效，无需配置。

## 说明 / Notes

- 面板数据为进程内状态：重启后从空开始（只记录实际观察到的文件）
- 默认忽略 `node_modules`、`.git` 与临时文件
- RPC 通道仅接受本机（127.0.0.1）访问；所有读取/定位操作均经过已追踪路径栅栏
- 兼容 `@deepseek-ai/dsh` 0.1.0-rc.x
