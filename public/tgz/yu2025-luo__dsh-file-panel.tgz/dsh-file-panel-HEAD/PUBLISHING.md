# 发布指南（第一次发布 GitHub 专用）

> 所有「复制粘贴」的内容都在这里，已按用户名 `yu2025-luo` 填好。
> 本仓库在本地已经完全就绪（`main` 分支 + `v0.1.0` 标签 + 提交历史），
> 剩下要做的只是：安装 GitHub CLI → 登录 → 一条命令推送 → 加主题 → 发 Release。

---

## ① 准备好复制的文字

### 仓库名称

```
dsh-file-panel
```

### 仓库描述（英文，约 160 字符，选一个用）

```
Right-side file panel for DeepSeek Harness — auto-popup when the agent creates or downloads files, with image/text preview, reveal-in-folder and open actions. Bilingual · MIT
```

### 仓库描述（中文备选）

```
DeepSeek Harness 插件：Agent 创建/下载文件时右侧自动弹出面板，支持图片与文本预览、打开所在位置、复制路径。中英双语 · MIT 开源
```

### Topics（主题标签，照抄这 7 个）

```
dsh-plugin, deepseek-harness, dsh, deepseek, file-preview, cordis, plugin
```

### Release 标题

```
v0.1.0 — 首个版本 · Initial release
```

### Release 说明

用仓库里的 `docs/RELEASE-NOTES-v0.1.0.md`（已写好）。

---

## ② 实际发布步骤（跟着做）

### 第 0 步：安装 GitHub CLI（一次性）

打开 PowerShell 运行：

```powershell
winget install GitHub.cli
```

装完后**关掉当前 PowerShell 窗口，重新开一个**，然后：

```powershell
gh --version   # 出现版本号即成功
```

### 第 1 步：登录 GitHub（一次性，全程在浏览器里点）

```powershell
gh auth login
```

按提示依次选择（用方向键 + 回车）：

1. 选 **GitHub.com**
2. 选 **HTTPS**
3. 问 "Authenticate Git with your GitHub credentials?" → 选 **Yes**
4. 选 **Login with a web browser**
5. 终端会显示一段 8 位代码，回车后浏览器自动打开
6. 在浏览器里登录你的 GitHub 账号，粘贴代码 → **Authorize github**（蓝色按钮）
7. 回到终端看到 `Logged in as yu2025-luo` 即成功

> 验证：`gh auth status` 显示 ✓ 即为已登录。

### 第 2 步：一条命令创建仓库并推送（在插件目录里执行）

```powershell
cd D:\76183\Documents\dsh-file-panel

gh repo create dsh-file-panel --public --source . --remote origin --push --description "Right-side file panel for DeepSeek Harness — auto-popup when the agent creates or downloads files, with image/text preview, reveal-in-folder and open actions. Bilingual · MIT"
```

这一条命令做了四件事：在 GitHub 建仓库 → 设为公开 → 关联本地 origin → 推送全部提交和标签。

### 第 3 步：加 Topics（主题标签）

方法 A（网页，推荐新手）：打开你的仓库页面 → 右下角 **About** 右侧点 ⚙ 齿轮 → **Topics** 输入框逐个粘贴（每输入一个回车）：

```
dsh-plugin
deepseek-harness
dsh
deepseek
file-preview
cordis
plugin
```

方法 B（命令行，等价）：

```powershell
gh api repos/yu2025-luo/dsh-file-panel/topics -X PUT -f 'names[]=dsh-plugin' -f 'names[]=deepseek-harness' -f 'names[]=dsh' -f 'names[]=deepseek' -f 'names[]=file-preview' -f 'names[]=cordis' -f 'names[]=plugin'
```

### 第 4 步：发布 Release v0.1.0

（`docs/RELEASE-NOTES-v0.1.0.md` 已按真实用户名填好，直接执行即可）

```powershell
gh release create v0.1.0 --title "v0.1.0 — 首个版本 · Initial release" --notes-file docs/RELEASE-NOTES-v0.1.0.md
```

### 第 5 步：验收

1. 打开 `https://github.com/yu2025-luo/dsh-file-panel` —— 能看到 README、MIT 徽标、文件树
2. 打开 `https://github.com/topics/dsh-plugin` —— 你的仓库几分钟内会出现（按 star 排序，新仓库在下面，正常）
3. 打开仓库的 **Actions** 标签 —— CI 会自动跑（绿色 ✓ = 通过；显示「First workflow run needs approval」就点一下 Run workflow 批准）
4. 验证安装：另开一个 PowerShell 运行
   `dsh plugin --profile web add github:yu2025-luo/dsh-file-panel#v0.1.0`

---

## ③ 常见问题

| 现象 | 处理 |
| --- | --- |
| `gh auth login` 后没有浏览器弹出 | 手动打开 https://github.com/login/device 输入终端显示的代码 |
| 推送报 "permission denied" | 回到第 1 步重新 `gh auth login` |
| CI 全红 | 打开 Actions 看日志；大概率是网络问题，点 Re-run jobs |
| 想改 README/描述 | 改完 `git add -A && git commit -m "..." && git push` 即可，无需重发 Release |
| 装错了想撤 | `dsh plugin --profile web remove dsh-file-panel` |
