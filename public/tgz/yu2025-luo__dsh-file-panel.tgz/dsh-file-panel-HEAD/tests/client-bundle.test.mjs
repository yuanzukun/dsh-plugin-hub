import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

/**
 * Executes the built client bundle the way the browser shell kernel does:
 * the bundle registers a module on `window.__ModuleLoader__`; the factory is
 * then materialized with a `require` that resolves the module-table peers
 * (react, react/jsx-runtime). Verifies the factory exports a valid plugin
 * and that `apply` performs its registrations against a ctx double.
 */
test('client bundle registers a working plugin module', () => {
  const requirePeer = createRequire(import.meta.url)
  const react = requirePeer('react')
  const jsxRuntime = requirePeer('react/jsx-runtime')

  let captured = undefined
  const previousWindow = globalThis.window
  globalThis.window = {
    __ModuleLoader__: {
      load: (definition) => {
        captured = definition
      },
    },
  }
  try {
    const code = readFileSync(fileURLToPath(new URL('../lib/client.js', import.meta.url)), 'utf8')
    // Evaluate in a scope where the bundle's top-level `window.__ModuleLoader__`
    // call lands on the stub; `document` stays undefined so CSS injection is skipped.
    Function(code)()
  } finally {
    if (previousWindow === undefined) delete globalThis.window
    else globalThis.window = previousWindow
  }

  assert.ok(captured, 'bundle registered a module on window.__ModuleLoader__')
  assert.equal(captured.id, 'dsh-file-panel')
  assert.equal(typeof captured.factory, 'function')

  const requireShim = (spec) => {
    if (spec === 'react') return react
    if (spec === 'react/jsx-runtime') return jsxRuntime
    throw new Error(`unexpected peer spec ${spec}`)
  }
  const plugin = captured.factory(requireShim)
  assert.deepEqual(plugin.inject, ['slots', 'connection', 'locale'])
  assert.equal(typeof plugin.apply, 'function')

  // Resizable-panel width clamp: exported so the browser half stays testable
  // without a DOM.
  assert.equal(typeof plugin.clampPanelWidth, 'function')
  assert.equal(plugin.clampPanelWidth(100), 240)          // below minimum
  assert.equal(plugin.clampPanelWidth(500), 500)          // inside range
  assert.equal(plugin.clampPanelWidth(99999), 1200)       // above hard cap
  assert.equal(plugin.clampPanelWidth(Number.NaN), 372)   // invalid → default
  assert.equal(plugin.clampPanelWidth(400, 300), 268)     // viewport-bound (300 − 32)
  assert.equal(plugin.clampPanelWidth(400, 240), 240)     // tiny viewport → floor at minimum

  // Vertical resize clamp (top-anchored at 64px, default margins 80px).
  assert.equal(typeof plugin.clampPanelHeight, 'function')
  assert.equal(plugin.clampPanelHeight(100), 200)         // below minimum
  assert.equal(plugin.clampPanelHeight(500), 500)         // inside range
  assert.equal(plugin.clampPanelHeight(99999), 720)       // default vh 800 → 800 − 80
  assert.equal(plugin.clampPanelHeight(Number.NaN), 720)  // invalid → default full height
  assert.equal(plugin.clampPanelHeight(400, 300), 220)    // viewport-bound (300 − 80)
  assert.equal(plugin.clampPanelHeight(999, 300), 220)    // capped
  assert.equal(plugin.clampPanelHeight(400, 240), 200)    // tiny viewport → floor at minimum

  // Free-drag position clamp: keep ≥80px of the panel reachable on every
  // side, header above the bottom 96px, default dock right/top.
  assert.equal(typeof plugin.clampPanelPos, 'function')
  assert.deepEqual(plugin.clampPanelPos({ x: 100, y: 100 }, 1280, 800, 372, 500), { x: 100, y: 100 })
  assert.deepEqual(plugin.clampPanelPos({ x: -9999, y: -9999 }, 1280, 800, 372, 500), { x: 80 - 372, y: 8 })
  assert.deepEqual(plugin.clampPanelPos({ x: 99999, y: 99999 }, 1280, 800, 372, 500), { x: 1280 - 80, y: 800 - 96 })
  assert.deepEqual(plugin.clampPanelPos(null, 1280, 800, 372, 500), { x: 1280 - 372 - 16, y: 64 })
  assert.deepEqual(plugin.clampPanelPos({ x: 300, y: 900 }, 1280, 800, 372, 500), { x: 300, y: 704 })

  // Drive apply() through a minimal client-ctx double.
  let registered = undefined
  const ctx = {
    effect: (fn) => {
      const disposer = fn()
      if (typeof disposer === 'function') disposer()
      return () => {}
    },
    locale: {
      register: () => () => {},
      bind: () => () => '',
    },
    connection: { rpc: {}, api: {}, isLoopback: true },
    slots: {
      inject: (name, callback) => {
        assert.equal(name, 'shell.overlay')
        callback()
      },
      register: (options, component) => {
        registered = { options, component }
      },
    },
  }
  plugin.apply(ctx)

  assert.deepEqual(registered.options, { name: 'shell.overlay', id: 'file-panel', order: 100 })
  assert.equal(typeof registered.component, 'function')
})
