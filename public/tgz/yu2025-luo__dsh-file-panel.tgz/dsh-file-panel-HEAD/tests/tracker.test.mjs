import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, writeFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { FileTracker, kindOf, isWatchable, MAX_ENTRIES_PER_SESSION } from '../src/tracker.js'

test('kindOf classifies common downloads', () => {
  assert.equal(kindOf('photo.PNG'), 'image')
  assert.equal(kindOf('report.pdf'), 'pdf')
  assert.equal(kindOf('notes.md'), 'text')
  assert.equal(kindOf('data.json'), 'text')
  assert.equal(kindOf('archive.zip'), 'archive')
  assert.equal(kindOf('song.mp3'), 'audio')
  assert.equal(kindOf('movie.mkv'), 'video')
  assert.equal(kindOf('sheet.xlsx'), 'office')
  assert.equal(kindOf('font.woff2'), 'font')
  assert.equal(kindOf('tool.exe'), 'binary')
  assert.equal(kindOf('/x/Makefile'), 'text')
  assert.equal(kindOf('/x/LICENSE'), 'text')
})

test('isWatchable filters noise paths', () => {
  const root = path.join('C:', 'work')
  assert.equal(isWatchable(root, path.join(root, 'out.png')), true)
  assert.equal(isWatchable(root, path.join(root, 'node_modules', 'x', 'y.js')), false)
  assert.equal(isWatchable(root, path.join(root, '.git', 'HEAD')), false)
  assert.equal(isWatchable(root, path.join(root, 'a', '.DS_Store')), false)
  assert.equal(isWatchable(root, path.join(root, 'b', 'x.crdownload')), false)
  // Hidden dot-directories are application noise (home-workspace flood
  // guard), except the whitelisted project dirs; dot-FILES stay visible.
  assert.equal(isWatchable(root, path.join(root, '.config', 'google-chrome', 'Default', 'x.log')), false)
  assert.equal(isWatchable(root, path.join(root, '.cache', 'tracker3', 'files')), false)
  assert.equal(isWatchable(root, path.join(root, 'src', '.hidden', 'x.js')), false)
  assert.equal(isWatchable(root, path.join(root, '.github', 'workflows', 'ci.yml')), true)
  assert.equal(isWatchable(root, path.join(root, '.vscode', 'settings.json')), true)
  assert.equal(isWatchable(root, path.join(root, '.env')), true)
  assert.equal(isWatchable(root, path.join('C:', 'elsewhere', 'x.png')), false)
  assert.equal(isWatchable(root, root), false)
  if (process.platform === 'win32') {
    // Cross-drive paths must never count as "inside" the root: on Windows
    // path.relative returns an ABSOLUTE path for them (fence regression).
    assert.equal(isWatchable(root, 'D:\\Windows\\win.ini'), false)
    assert.equal(isWatchable(root, 'D:\\work\\x.png'), false)
  }
})

test('FileTracker records, orders, caps, and fences', async () => {
  const tracker = new FileTracker()
  const dir = await mkdtemp(path.join(tmpdir(), 'dsh-file-panel-'))

  const paths = []
  for (let i = 0; i < MAX_ENTRIES_PER_SESSION + 5; i++) {
    const p = path.join(dir, `file-${String(i).padStart(3, '0')}.txt`)
    paths.push(p)
    await writeFile(p, `content ${i}`)
  }
  try {
    for (const p of paths) await tracker.touch(p, { sessionId: 's1' })
    // Storage keeps the newest 500, the list endpoint serves the newest 250.
    assert.equal(tracker.bySession.get('s1').size, MAX_ENTRIES_PER_SESSION)
    const files = tracker.filesFor('s1')
    assert.equal(files.length, 250)
    // The list is the mtime-descending head of the stored set.
    const expected = [...tracker.bySession.get('s1').values()]
      .sort((a, b) => b.mtimeMs - a.mtimeMs)
      .slice(0, 250)
      .map((entry) => entry.name)
    assert.deepEqual(files.map((entry) => entry.name), expected)
    // All retained paths remain fence-allowed; evicted ones do not.
    assert.equal(tracker.isAllowed(paths.at(-1)), true)
    assert.equal(tracker.isAllowed(paths[0]), false)
    assert.equal(tracker.isAllowed(path.join(dir, 'never-written.txt')), false)
    // A second touch refreshes the entry without duplicating.
    await tracker.touch(paths.at(-1), { sessionId: 's1' })
    assert.equal(tracker.bySession.get('s1').size, MAX_ENTRIES_PER_SESSION)
  } finally {
    tracker.dispose()
    await rm(dir, { recursive: true, force: true })
  }
})

test('FileTracker attributes watcher events only to the session currently viewing the workspace', async () => {
  const tracker = new FileTracker()
  const dir = await mkdtemp(path.join(tmpdir(), 'dsh-file-panel-'))
  try {
    tracker.attribute('s1', dir)
    tracker.attribute('s2', dir) // s2 is the conversation on screen now
    assert.equal(tracker.watchers.size, 1)
    assert.equal(tracker.activeSessions.get(dir), 's2')
    // A shell download while s2 is visible belongs to s2 only.
    const p = path.join(dir, 'downloaded.png')
    await writeFile(p, 'x')
    const cell = tracker.watchers.get(dir)
    cell.pending.add(p)
    await tracker.flushWatcher(dir)
    assert.equal(tracker.bySession.get('s2')?.get(p)?.kind, 'image')
    assert.equal(tracker.bySession.get('s1')?.get(p), undefined) // no cross-session sharing
    assert.equal(tracker.isAllowed(p), true)
    // Switching the visible conversation moves the attribution from now on.
    tracker.attribute('s1', dir)
    const p2 = path.join(dir, 'next.txt')
    await writeFile(p2, 'x')
    cell.pending.add(p2)
    await tracker.flushWatcher(dir)
    assert.equal(tracker.bySession.get('s1')?.get(p2)?.kind, 'text')
    assert.equal(tracker.bySession.get('s2')?.get(p2), undefined)
    if (process.platform === 'win32') {
      // Cross-drive paths must stay outside the fence even with a live
      // watcher rooted on another drive (regression for path.relative).
      assert.equal(tracker.isAllowed('D:\\Windows\\win.ini'), false)
    }
  } finally {
    tracker.dispose()
    await rm(dir, { recursive: true, force: true })
  }
})
