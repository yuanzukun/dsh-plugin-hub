import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, writeFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { apply } from '../src/index.js'

/** Minimal cordis-context double covering exactly what the host half uses. */
function fakeCtx() {
  const listeners = new Map()
  const disposers = []
  const registered = {}
  const ctx = {
    get: () => undefined,
    on(name, fn) {
      const list = listeners.get(name) ?? []
      list.push(fn)
      listeners.set(name, list)
    },
    effect(fn) {
      const disposer = fn()
      if (typeof disposer === 'function') disposers.push(disposer)
      return () => {}
    },
    connection: {
      rpc: {
        handle(channel, handler, options) {
          registered.channel = channel
          registered.handler = handler
          registered.options = options
          return () => {}
        },
      },
    },
  }
  return { ctx, listeners, disposers, registered }
}

test('host half registers the loopback channel and serves tracked files', async () => {
  const { ctx, listeners, disposers, registered } = fakeCtx()
  apply(ctx)

  assert.equal(registered.channel, '/file-panel')
  assert.deepEqual(registered.options, { authority: 'loopback' })
  const handler = registered.handler

  // Capability probe.
  const describe = await handler('describe', {}, new AbortController().signal)
  assert.equal(describe.ok, true)
  assert.equal(typeof describe.value.canReveal, 'boolean')

  // Unknown endpoints and missing input fail with a structured RpcResult.
  const unknown = await handler('nope', {}, new AbortController().signal)
  assert.equal(unknown.ok, false)
  assert.equal(unknown.error.code, 'bad-request')

  // The fence rejects untracked paths before any I/O or spawning.
  const fenced = await handler('reveal', { path: 'C:\\Windows\\notepad.exe' }, new AbortController().signal)
  assert.equal(fenced.ok, false)
  assert.equal(fenced.error.code, 'bad-request')

  // A simulated `fs/observed` (write tool) attributes the file to its session.
  const dir = await mkdtemp(path.join(tmpdir(), 'dsh-file-panel-host-'))
  try {
    const textPath = path.join(dir, 'notes.md')
    await writeFile(textPath, '# hello\nworld\n')
    const pngPath = path.join(dir, 'pic.png')
    const pngBytes = Buffer.from('89504e470d0a1a0a0000000d49484452', 'hex') // PNG magic + IHDR
    await writeFile(pngPath, pngBytes)

    for (const fn of listeners.get('fs/observed') ?? []) {
      fn({ displayPath: textPath }, { kind: 'present' }, { agent: { session: { id: 's1', header: { cwd: dir } } } })
      fn({ displayPath: pngPath }, { kind: 'present' }, { agent: { session: { id: 's1', header: { cwd: dir } } } })
      fn({ displayPath: textPath }, { kind: 'absent' }, { agent: { session: { id: 's1' } } })
    }

    // Give the async touch() calls a beat.
    await new Promise((resolve) => setTimeout(resolve, 100))

    if (process.platform === 'win32') {
      // Cross-drive regression with a LIVE watched root: path.relative
      // returns an absolute path across drives, which the fence must reject.
      const crossDrive = await handler('reveal', { path: 'D:\\Windows\\win.ini' }, new AbortController().signal)
      assert.equal(crossDrive.ok, false)
      assert.equal(crossDrive.error.code, 'bad-request')
    }

    const list = await handler('list', { sessionId: 's1', cwd: dir }, new AbortController().signal)
    assert.equal(list.ok, true)
    assert.equal(list.value.files.length, 2)
    const names = list.value.files.map((entry) => entry.name).sort()
    assert.deepEqual(names, ['notes.md', 'pic.png'])
    assert.equal(list.value.files.find((entry) => entry.name === 'pic.png').kind, 'image')

    const text = await handler('readText', { path: textPath }, new AbortController().signal)
    assert.equal(text.ok, true)
    assert.equal(text.value.text, '# hello\nworld\n')

    const image = await handler('readImage', { path: pngPath }, new AbortController().signal)
    assert.equal(image.ok, true)
    assert.equal(image.value.dataUrl.startsWith('data:image/png;base64,'), true)
  } finally {
    for (const dispose of disposers) await dispose()
    await rm(dir, { recursive: true, force: true })
  }
})
