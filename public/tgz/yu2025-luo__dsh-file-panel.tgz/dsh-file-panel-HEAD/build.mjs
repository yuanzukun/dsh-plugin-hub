/**
 * Builds both halves of the package:
 *
 * - `lib/index.js`  — the Node/host half (ESM bundle of src/index.js).
 * - `lib/client.js` — the browser half, wrapped in the DSH client-module
 *   registration form the shell's module loader expects:
 *
 *     window.__ModuleLoader__.load({ id, factory: (require) => { ... } })
 *
 *   Peer imports (`react`, `react/jsx-runtime`) stay external `require` calls,
 *   which the shell's module table resolves at runtime.
 */
import { build } from 'esbuild'
import { readFileSync, mkdirSync } from 'node:fs'
import { fileURLToPath } from 'node:url'

const root = new URL('.', import.meta.url)
const fromRoot = (spec) => fileURLToPath(new URL(spec, root))

const pkg = JSON.parse(readFileSync(fromRoot('package.json'), 'utf8'))
const id = pkg.name

mkdirSync(fromRoot('lib'), { recursive: true })

// ── host half ──────────────────────────────────────────────────────────────
await build({
  entryPoints: [fromRoot('src/index.js')],
  outfile: fromRoot('lib/index.js'),
  bundle: true,
  platform: 'node',
  format: 'esm',
  target: 'node20',
  logLevel: 'info',
})

// ── client half ────────────────────────────────────────────────────────────
const banner = [
  'window.__ModuleLoader__.load({',
  `  id: ${JSON.stringify(id)},`,
  '  factory: (require) => {',
  "    var module = { exports: {} };",
  '    var exports = module.exports;',
  '    Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });',
  '',
].join('\n')
const footer = '\n    return module.exports;\n  },\n});\n'

await build({
  entryPoints: [fromRoot('src/client.jsx')],
  outfile: fromRoot('lib/client.js'),
  bundle: true,
  platform: 'browser',
  format: 'cjs',
  jsx: 'automatic',
  target: ['es2020'],
  external: ['react', 'react/jsx-runtime'],
  sourcemap: 'external',
  banner: { js: banner },
  footer: { js: footer },
  logLevel: 'info',
})

console.log(`built lib/index.js and lib/client.js for ${id}`)
