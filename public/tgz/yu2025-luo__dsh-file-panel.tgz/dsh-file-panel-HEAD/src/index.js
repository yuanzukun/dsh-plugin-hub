/**
 * dsh-file-panel — host half.
 *
 * Tracks files the agent creates or downloads (the `fs/observed` harness
 * event plus a recursive watch of each session's working directory) and
 * serves them over a loopback-only RPC channel `/file-panel` for the
 * browser half:
 *
 *   list      { sessionId, cwd }  -> { files: FileEntry[] }
 *   readText  { path }            -> { text, truncated }
 *   readImage { path }            -> { dataUrl }
 *   reveal    { path }            -> { revealed }  (show in the OS file manager)
 *   describe  {}                  -> { canReveal }
 *
 * The channel is registered through `ctx.connection.rpc.handle` (the
 * sanctioned static-package RPC seam) with `authority: 'loopback'`, so only
 * the local machine's browser pages can call it.
 */
import { readFile, stat } from 'node:fs/promises'
import { spawn } from 'node:child_process'
import path from 'node:path'
import { FileTracker, kindOf, mimeOfImage } from './tracker.js'

export const inject = ['connection']

const CHANNEL = '/file-panel'
/** Text preview cap (bytes read from disk). */
const TEXT_PREVIEW_MAX = 256 * 1024
/** Image preview cap (bytes read from disk). */
const IMAGE_PREVIEW_MAX = 8 * 1024 * 1024

/** Resolve the most useful absolute process path for an fs target. */
function absolutePathOf(ctx, target, displayPath, cwd) {
  if (target !== undefined) {
    try {
      const fs = ctx.get('fs')
      if (fs !== undefined) return fs.processPath(target)
    } catch { /* fall through to displayPath */ }
  }
  if (typeof displayPath !== 'string' || displayPath === '') return undefined
  if (path.isAbsolute(displayPath)) return path.normalize(displayPath)
  if (typeof cwd === 'string' && cwd !== '') return path.resolve(cwd, displayPath)
  return path.resolve(displayPath)
}

function badRequest(message) {
  return {
    ok: false,
    error: { code: 'bad-request', message, details: { issues: [] } },
  }
}

function internalError(error) {
  return {
    ok: false,
    error: {
      code: 'internal',
      message: error instanceof Error ? error.message : String(error),
      details: {},
    },
  }
}

function ok(value) {
  return { ok: true, value }
}

/**
 * Open the containing folder with the file selected (the "reveal in folder"
 * gesture), or open a directory itself.
 */
function revealInFileManager(absPath, isDirectory) {
  return new Promise((resolve, reject) => {
    let child
    try {
      if (process.platform === 'win32') {
        child = isDirectory
          ? spawn('explorer.exe', [absPath], { stdio: 'ignore' })
          : spawn('explorer.exe', ['/select,', absPath], { stdio: 'ignore' })
      } else if (process.platform === 'darwin') {
        child = spawn('open', ['-R', absPath], { stdio: 'ignore' })
      } else {
        const target = isDirectory ? absPath : path.dirname(absPath)
        child = spawn('xdg-open', [target], { stdio: 'ignore' })
      }
    } catch (error) {
      reject(error)
      return
    }
    child.once('error', (error) => {
      reject(new Error(`could not open the file manager: ${error.message}`))
    })
    child.once('spawn', () => {
      child.unref()
      resolve(true)
    })
  })
}

function describeReveal() {
  if (process.platform === 'win32' || process.platform === 'darwin') return true
  if (process.platform === 'linux') {
    if (process.env.WSL_DISTRO_NAME !== undefined) return true
    return process.env.DISPLAY !== undefined || process.env.WAYLAND_DISPLAY !== undefined
  }
  return false
}

/** Build the RPC handler for one channel registration. */
function createHandler(ctx, tracker) {
  return async (endpoint, payload, signal) => {
    const input = payload ?? {}
    try {
      switch (endpoint) {
        case 'list': {
          const sessionId = input.sessionId
          if (typeof sessionId !== 'string' || sessionId === '') return badRequest('sessionId must be a non-empty string')
          if (typeof input.cwd === 'string' && input.cwd !== '') tracker.attribute(sessionId, input.cwd)
          return ok({ files: tracker.filesFor(sessionId) })
        }
        case 'readText': {
          const abs = input.path
          if (typeof abs !== 'string' || abs === '' || !path.isAbsolute(abs) || !tracker.isAllowed(abs)) {
            return badRequest('path must be an absolute, tracked file path')
          }
          const statResult = await statOf(abs)
          if (statResult === undefined) return badRequest('file not found')
          if (statResult.size > TEXT_PREVIEW_MAX) {
            return ok({ text: '', truncated: true, tooLarge: true, size: statResult.size })
          }
          const bytes = await readFile(abs)
          return ok({ text: bytes.toString('utf8'), truncated: false, tooLarge: false, size: statResult.size })
        }
        case 'readImage': {
          const abs = input.path
          if (typeof abs !== 'string' || abs === '' || !path.isAbsolute(abs) || !tracker.isAllowed(abs)) {
            return badRequest('path must be an absolute, tracked file path')
          }
          if (kindOf(abs) !== 'image') return badRequest('not an image file')
          const statResult = await statOf(abs)
          if (statResult === undefined) return badRequest('file not found')
          if (statResult.size > IMAGE_PREVIEW_MAX) {
            return ok({ dataUrl: null, tooLarge: true, size: statResult.size })
          }
          const bytes = await readFile(abs)
          return ok({ dataUrl: `data:${mimeOfImage(abs)};base64,${bytes.toString('base64')}`, tooLarge: false, size: statResult.size })
        }
        case 'reveal': {
          const abs = input.path
          if (typeof abs !== 'string' || abs === '' || !path.isAbsolute(abs) || !tracker.isAllowed(abs)) {
            return badRequest('path must be an absolute, tracked file path')
          }
          const statResult = await statOf(abs)
          if (statResult === undefined) return badRequest('file not found')
          await revealInFileManager(abs, statResult.isDirectory)
          return ok({ revealed: true })
        }
        case 'describe':
          return ok({ canReveal: describeReveal(), platform: process.platform })
        default:
          return badRequest(`unknown endpoint ${JSON.stringify(endpoint)}`)
      }
    } catch (error) {
      if (signal?.aborted) return internalError(new Error('aborted'))
      return internalError(error)
    }
  }
}

async function statOf(abs) {
  try {
    const info = await stat(abs)
    return { isDirectory: info.isDirectory(), size: info.size }
  } catch {
    return undefined
  }
}

export function apply(ctx) {
  const tracker = new FileTracker()

  // Precise source: harness filesystem tools report authoritative
  // observations of present files (writes and edits included).
  ctx.on('fs/observed', (target, observation, actor) => {
    if (observation === undefined || observation.kind !== 'present') return
    const session = actor?.agent?.session
    if (session === undefined || session === null || typeof session.id !== 'string') return
    const cwd = typeof session.header?.cwd === 'string' ? session.header.cwd : undefined
    const abs = absolutePathOf(ctx, target, target?.displayPath, cwd)
    if (abs === undefined) return
    void tracker.touch(abs, { sessionId: session.id, cwd })
  })

  ctx.effect(() => () => tracker.dispose(), 'dsh-file-panel: tracker')

  // Loopback-only RPC channel for the browser half. `rpc.handle` registers
  // the HTTP prefix route through the connection service's webServer.
  ctx.effect(
    () => ctx.connection.rpc.handle(CHANNEL, createHandler(ctx, tracker), { authority: 'loopback' }),
    'dsh-file-panel: rpc channel',
  )
}

export { createHandler, revealInFileManager, describeReveal }
