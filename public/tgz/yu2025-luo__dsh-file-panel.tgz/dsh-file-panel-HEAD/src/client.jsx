/**
 * dsh-file-panel — browser half.
 *
 * Registers a floating panel in the shell's `shell.overlay` slot, docked to
 * the right edge of the frame. It polls the host half's `/file-panel` RPC
 * channel for the current session's files (created/downloaded by the agent)
 * and, when new files appear, pops the panel open automatically. Each row can
 * preview (images inline, text inline), open with the OS default app, reveal
 * in the OS file manager, and copy its path.
 */
import { useState, useEffect, useRef, useCallback } from 'react'

export const inject = ['slots', 'connection', 'locale']

const NS = 'file-panel'
const CHANNEL = '/file-panel'
const POLL_MS = 1500
const MODE_KEY = 'dsh-file-panel:mode'
const AUTOPOP_KEY = 'dsh-file-panel:autoPop'
const WIDTH_KEY = 'dsh-file-panel:width'
const HEIGHT_KEY = 'dsh-file-panel:height'
const POS_KEY = 'dsh-file-panel:pos'
/** Panel width bounds (px): narrowest usable, default, and hard cap. */
const MIN_WIDTH = 240
const DEFAULT_WIDTH = 372
const HARD_MAX_WIDTH = 1200
/** Panel height bounds (px): shortest usable, and the default top/bottom margin. */
const MIN_HEIGHT = 200
const DEFAULT_HEIGHT_OFFSET = 80

const zh = {
  title: '会话文件',
  files: '文件',
  noSession: '打开一个会话后，这里会显示该会话生成或下载的文件。',
  empty: '该会话还没有生成或下载文件。',
  unavailable: '文件面板暂不可用（未连接到本机 Harness）。',
  loopbackOnly: '文件面板仅支持通过本机地址（127.0.0.1）访问时使用。',
  preview: '预览',
  open: '打开',
  reveal: '所在位置',
  copyPath: '复制路径',
  copied: '已复制',
  collapse: '收起',
  expand: '展开',
  close: '关闭',
  resize: '拖动调整宽度',
  resetWidth: '双击恢复默认宽度',
  resizeHeight: '拖动调整高度',
  resetHeight: '双击恢复默认高度',
  drag: '按住拖动面板',
  autoPopOn: '新文件时自动弹出：开',
  autoPopOff: '新文件时自动弹出：关',
  newFiles: '新文件',
  newBadge: '新',
  loading: '加载中…',
  tooLargeText: '文件过大，仅显示元信息（{size}）',
  tooLargeImage: '图片过大，无法内联预览（{size}）',
  previewFailed: '预览失败：{reason}',
  openFailed: '打开失败：{reason}',
  revealFailed: '无法打开所在位置：{reason}',
  revealUnavailable: '当前环境不支持打开文件管理器',
  binaryNote: '该类型不支持内联预览',
  openWorkspace: '打开工作目录',
}

const en = {
  title: 'Session Files',
  files: 'Files',
  noSession: 'Open a session to see the files it creates or downloads here.',
  empty: 'This session has not created or downloaded any files yet.',
  unavailable: 'The file panel is unavailable (not connected to the local Harness).',
  loopbackOnly: 'The file panel only works when the page is served from the local machine (127.0.0.1).',
  preview: 'Preview',
  open: 'Open',
  reveal: 'Show in folder',
  copyPath: 'Copy path',
  copied: 'Copied',
  collapse: 'Collapse',
  expand: 'Expand',
  close: 'Close',
  resize: 'Drag to resize',
  resetWidth: 'Double-click to reset width',
  resizeHeight: 'Drag to resize height',
  resetHeight: 'Double-click to reset height',
  drag: 'Hold and drag to move the panel',
  autoPopOn: 'Auto-pop on new files: on',
  autoPopOff: 'Auto-pop on new files: off',
  newFiles: 'new files',
  newBadge: 'NEW',
  loading: 'Loading…',
  tooLargeText: 'File too large for inline preview ({size})',
  tooLargeImage: 'Image too large for inline preview ({size})',
  previewFailed: 'Preview failed: {reason}',
  openFailed: 'Open failed: {reason}',
  revealFailed: 'Cannot show in folder: {reason}',
  revealUnavailable: 'This environment cannot open the file manager',
  binaryNote: 'No inline preview for this file type',
  openWorkspace: 'Open workspace folder',
}

/* ── small inline icons (stroke = currentColor) ─────────────────────────── */

function EyeIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  )
}

function ExternalIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 4h6v6" />
      <path d="M20 4 10 14" />
      <path d="M20 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h5" />
    </svg>
  )
}

function FolderIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-8l-2-2H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2Z" />
    </svg>
  )
}

function CopyIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="9" y="9" width="12" height="12" rx="2" />
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
    </svg>
  )
}

function CloseIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <path d="M6 6l12 12M18 6 6 18" />
    </svg>
  )
}

function MinusIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <path d="M5 12h14" />
    </svg>
  )
}

function PanelIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z" />
      <path d="M14 2v6h6" />
      <path d="M9 13h6M9 17h6" />
    </svg>
  )
}

function BellIcon({ off }) {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
      <path d="M13.7 21a2 2 0 0 1-3.4 0" />
      {off ? <path d="M2 2l20 20" /> : null}
    </svg>
  )
}

/* ── presentation helpers ───────────────────────────────────────────────── */

const KIND_GLYPH = {
  image: '🖼️',
  text: '📄',
  archive: '🗜️',
  pdf: '📕',
  office: '📊',
  audio: '🎵',
  video: '🎬',
  font: '🔤',
  binary: '📦',
}

function formatSize(bytes) {
  if (!Number.isFinite(bytes) || bytes < 0) return '—'
  if (bytes < 1024) return `${bytes} B`
  const units = ['KB', 'MB', 'GB', 'TB']
  let value = bytes
  let unit = 'B'
  for (const next of units) {
    if (value < 1024) break
    value /= 1024
    unit = next
  }
  return `${value >= 100 ? Math.round(value) : value.toFixed(1)} ${unit}`
}

function formatTime(ms) {
  try {
    const date = new Date(ms)
    const now = new Date()
    const sameDay = date.toDateString() === now.toDateString()
    const time = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    if (sameDay) return time
    return `${date.toLocaleDateString()} ${time}`
  } catch {
    return ''
  }
}

/**
 * Clamp a panel width to the usable range. The panel is right-anchored, so
 * the upper bound also respects the viewport (16px margins on both sides).
 * Exported for tests.
 * @param {number} value
 * @param {number} [viewportWidth]
 * @returns {number}
 */
export function clampPanelWidth(value, viewportWidth) {
  const vw = viewportWidth ?? (typeof window !== 'undefined' ? window.innerWidth : 1280)
  const max = Math.max(MIN_WIDTH, Math.min(vw - 32, HARD_MAX_WIDTH))
  if (!Number.isFinite(value)) return Math.min(DEFAULT_WIDTH, max)
  return Math.min(Math.max(Math.round(value), MIN_WIDTH), max)
}

/**
 * Clamp a panel height to the usable range. The panel is top-anchored at
 * 64px, so the upper bound is the viewport height minus the default
 * top/bottom margins. Exported for tests.
 * @param {number} value
 * @param {number} [viewportHeight]
 * @returns {number}
 */
export function clampPanelHeight(value, viewportHeight) {
  const vh = viewportHeight ?? (typeof window !== 'undefined' ? window.innerHeight : 800)
  const max = Math.max(MIN_HEIGHT, vh - DEFAULT_HEIGHT_OFFSET)
  if (!Number.isFinite(value)) return max
  return Math.min(Math.max(Math.round(value), MIN_HEIGHT), max)
}

/**
 * Clamp the panel's top-left position so it stays on screen: at least
 * MIN_VISIBLE px of the panel must remain reachable on every side, and the
 * header (top edge) never sinks below the last 96px of the viewport so the
 * drag handle stays grabbable. Exported for tests.
 * @param {{x: number, y: number}|null} value
 * @param {number} [viewportWidth]
 * @param {number} [viewportHeight]
 * @param {number} [panelWidth]
 * @param {number} [panelHeight]
 * @returns {{x: number, y: number}}
 */
export function clampPanelPos(value, viewportWidth, viewportHeight, panelWidth, panelHeight) {
  const vw = viewportWidth ?? (typeof window !== 'undefined' ? window.innerWidth : 1280)
  const vh = viewportHeight ?? (typeof window !== 'undefined' ? window.innerHeight : 800)
  const w = panelWidth ?? DEFAULT_WIDTH
  const h = panelHeight ?? 300
  const MIN_VISIBLE = 80
  const x = value !== null && Number.isFinite(value?.x) ? Math.round(value.x) : vw - w - 16
  const y = value !== null && Number.isFinite(value?.y) ? Math.round(value.y) : 64
  return {
    x: Math.min(Math.max(x, MIN_VISIBLE - w), vw - MIN_VISIBLE),
    y: Math.min(Math.max(y, 8), vh - 96),
  }
}

function displayPathOf(entry, cwd) {
  if (cwd === undefined || cwd === '') return entry.dir
  const sep = cwd.includes('\\') ? '\\' : '/'
  if (entry.dir === cwd) return '.'
  const prefix = cwd.endsWith(sep) ? cwd : cwd + sep
  if (entry.dir.startsWith(prefix)) return entry.dir.slice(prefix.length)
  return entry.dir
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch {
    try {
      const area = document.createElement('textarea')
      area.value = text
      area.style.position = 'fixed'
      area.style.opacity = '0'
      document.body.appendChild(area)
      area.select()
      const done = document.execCommand('copy')
      document.body.removeChild(area)
      return done
    } catch {
      return false
    }
  }
}

/* ── the panel component ────────────────────────────────────────────────── */

function FilePanel({ useSessions, rpc, api, isLoopback, t }) {
  const currentId = useSessions((state) => state.current)
  const cwd = useSessions((state) => (state.current !== undefined ? state.byId[state.current]?.cwd : undefined))

  const [mode, setModeState] = useState(() => {
    try {
      const stored = localStorage.getItem(MODE_KEY)
      return stored === 'open' || stored === 'collapsed' ? stored : 'hidden'
    } catch {
      return 'hidden'
    }
  })
  const [autoPop, setAutoPopState] = useState(() => {
    try {
      return localStorage.getItem(AUTOPOP_KEY) !== '0'
    } catch {
      return true
    }
  })
  const [width, setWidthState] = useState(() => {
    try {
      const stored = Number(localStorage.getItem(WIDTH_KEY))
      return stored > 0 && Number.isFinite(stored) ? clampPanelWidth(stored) : DEFAULT_WIDTH
    } catch {
      return DEFAULT_WIDTH
    }
  })
  const [height, setHeightState] = useState(() => {
    try {
      const stored = Number(localStorage.getItem(HEIGHT_KEY))
      return stored > 0 && Number.isFinite(stored) ? clampPanelHeight(stored) : clampPanelHeight(Number.NaN)
    } catch {
      return clampPanelHeight(Number.NaN)
    }
  })
  const [pos, setPosState] = useState(() => {
    let stored = null
    try {
      const raw = localStorage.getItem(POS_KEY)
      if (raw !== null) stored = JSON.parse(raw)
    } catch { /* corrupted or unavailable: fall through to default */ }
    return clampPanelPos(stored, undefined, undefined, width, height)
  })
  const [files, setFiles] = useState([])
  const [newCount, setNewCount] = useState(0)
  const [selected, setSelected] = useState(null)
  const [preview, setPreview] = useState(null)
  const [canReveal, setCanReveal] = useState(true)
  const [unavailable, setUnavailable] = useState(false)
  const [notice, setNotice] = useState(null)

  const seenRef = useRef(new Set())
  const lastSeenRef = useRef(new Map())
  const openedAtRef = useRef(0)
  const filesRef = useRef(files)
  filesRef.current = files
  const modeRef = useRef(mode)
  const autoPopRef = useRef(autoPop)
  const noticeTimerRef = useRef(null)

  const setMode = useCallback((next) => {
    modeRef.current = next
    setModeState(next)
    try { localStorage.setItem(MODE_KEY, next) } catch { /* storage unavailable */ }
    if (next === 'open') setNewCount(0)
  }, [])

  const setAutoPop = useCallback((next) => {
    autoPopRef.current = next
    setAutoPopState(next)
    try { localStorage.setItem(AUTOPOP_KEY, next ? '1' : '0') } catch { /* storage unavailable */ }
  }, [])

  const widthRef = useRef(width)
  widthRef.current = width
  const heightRef = useRef(height)
  heightRef.current = height
  const resizeRef = useRef(null)

  const setWidth = useCallback((next) => {
    const clamped = clampPanelWidth(next)
    widthRef.current = clamped
    setWidthState(clamped)
    try { localStorage.setItem(WIDTH_KEY, String(clamped)) } catch { /* storage unavailable */ }
  }, [])

  const setHeight = useCallback((next) => {
    const clamped = clampPanelHeight(next)
    heightRef.current = clamped
    setHeightState(clamped)
    try { localStorage.setItem(HEIGHT_KEY, String(clamped)) } catch { /* storage unavailable */ }
  }, [])

  const posRef = useRef(pos)
  posRef.current = pos
  const moveRef = useRef(null)

  const setPos = useCallback((next) => {
    const clamped = clampPanelPos(next, undefined, undefined, widthRef.current, heightRef.current)
    posRef.current = clamped
    setPosState(clamped)
    try { localStorage.setItem(POS_KEY, JSON.stringify(clamped)) } catch { /* storage unavailable */ }
  }, [])

  const onMoveStart = useCallback((event) => {
    if (event.pointerType === 'mouse' && event.button !== 0) return
    moveRef.current = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      startPos: { ...posRef.current },
    }
    try { event.currentTarget.setPointerCapture(event.pointerId) } catch { /* capture unavailable */ }
    document.body.style.userSelect = 'none'
    document.body.style.cursor = 'move'
  }, [])

  const onMoveMove = useCallback((event) => {
    const move = moveRef.current
    if (move === null || event.pointerId !== move.pointerId) return
    setPos({
      x: move.startPos.x + (event.clientX - move.startX),
      y: move.startPos.y + (event.clientY - move.startY),
    })
  }, [setPos])

  const onMoveEnd = useCallback((event) => {
    const move = moveRef.current
    if (move === null || event.pointerId !== move.pointerId) return
    moveRef.current = null
    try { event.currentTarget.releasePointerCapture(event.pointerId) } catch { /* already released */ }
    document.body.style.userSelect = ''
    document.body.style.cursor = ''
  }, [])

  const onResizeStart = useCallback((axis) => (event) => {
    if (event.pointerType === 'mouse' && event.button !== 0) return
    resizeRef.current = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      startWidth: widthRef.current,
      startHeight: heightRef.current,
      startPosX: posRef.current.x,
      axis,
    }
    try { event.currentTarget.setPointerCapture(event.pointerId) } catch { /* capture unavailable */ }
    document.body.style.userSelect = 'none'
    document.body.style.cursor = axis === 'width' ? 'col-resize' : 'ns-resize'
  }, [])

  const onResizeMove = useCallback((event) => {
    const drag = resizeRef.current
    if (drag === null || event.pointerId !== drag.pointerId) return
    if (drag.axis === 'width') {
      // Left edge follows the cursor (right edge stays fixed): dragging LEFT
      // widens the panel and moves its left edge along with the pointer.
      const delta = drag.startX - event.clientX
      setWidth(drag.startWidth + delta)
      setPos({ ...posRef.current, x: drag.startPosX - delta })
    } else {
      // Bottom edge follows the cursor: dragging DOWN grows, UP shrinks.
      setHeight(drag.startHeight + (event.clientY - drag.startY))
    }
  }, [setWidth, setHeight, setPos])

  const onResizeEnd = useCallback((event) => {
    const drag = resizeRef.current
    if (drag === null || event.pointerId !== drag.pointerId) return
    resizeRef.current = null
    try { event.currentTarget.releasePointerCapture(event.pointerId) } catch { /* already released */ }
    document.body.style.userSelect = ''
    document.body.style.cursor = ''
  }, [])

  // Re-clamp size and position when the viewport shrinks below them.
  useEffect(() => {
    const onViewport = () => {
      setWidth(widthRef.current)
      setHeight(heightRef.current)
      setPos(posRef.current)
    }
    window.addEventListener('resize', onViewport)
    return () => window.removeEventListener('resize', onViewport)
  }, [setWidth, setHeight, setPos])

  const flash = useCallback((message) => {
    setNotice(message)
    if (noticeTimerRef.current !== null) clearTimeout(noticeTimerRef.current)
    noticeTimerRef.current = setTimeout(() => setNotice(null), 2600)
  }, [])

  // Host capability probe.
  useEffect(() => {
    if (!isLoopback) return
    let cancelled = false
    rpc.call(CHANNEL, 'describe', {}).then((result) => {
      if (!cancelled && result.ok) setCanReveal(result.value.canReveal !== false)
    }).catch(() => {
      if (!cancelled) setUnavailable(true)
    })
    return () => { cancelled = true }
  }, [rpc, isLoopback])

  // Poll the current session's file list; auto-pop when new files arrive.
  useEffect(() => {
    if (!isLoopback) return
    if (currentId === undefined) {
      setFiles([])
      setSelected(null)
      setPreview(null)
      return
    }
    let cancelled = false
    let inFlight = false

    // Detection is key-set based (path + mtime), not newest-mtime based:
    // archives and git checkouts restore old mtimes, which an mtime-delta
    // baseline would silently miss.
    const keyOf = (entry) => `${entry.path}\u0000${entry.mtimeMs}`

    const applyFiles = (nextFiles) => {
      setFiles(nextFiles)
      if (nextFiles.length === 0) return
      let previous = lastSeenRef.current.get(currentId)
      if (previous === undefined) {
        previous = { keys: new Set(), started: false }
        lastSeenRef.current.set(currentId, previous)
      }
      const fresh = nextFiles.filter((entry) => !previous.keys.has(keyOf(entry)))
      if (!previous.started) {
        // First poll for this session: baseline, no pop.
        for (const entry of nextFiles) previous.keys.add(keyOf(entry))
        previous.started = true
        return
      }
      if (fresh.length === 0) return
      for (const entry of nextFiles) previous.keys.add(keyOf(entry))
      if (previous.keys.size > 400) {
        // Rebase the baseline on the current state instead of growing forever.
        previous.keys = new Set(nextFiles.map(keyOf))
      }
      setNewCount((count) => count + fresh.length)
      if (modeRef.current === 'hidden' && autoPopRef.current) setMode('open')
    }

    const poll = async () => {
      if (cancelled || inFlight) return
      inFlight = true
      try {
        const result = await rpc.call(CHANNEL, 'list', { sessionId: currentId, cwd })
        if (cancelled) return
        if (result.ok) {
          setUnavailable(false)
          applyFiles(result.value.files)
        } else {
          setUnavailable(true)
        }
      } catch {
        if (!cancelled) setUnavailable(true)
      } finally {
        inFlight = false
      }
    }

    poll()
    const timer = setInterval(poll, POLL_MS)
    return () => {
      cancelled = true
      clearInterval(timer)
    }
  }, [currentId, cwd, isLoopback, rpc, setMode])

  // Opening the panel baselines everything currently listed: only files that
  // arrive after the open get NEW chips.
  useEffect(() => {
    if (mode !== 'open') return
    openedAtRef.current = Date.now()
    for (const entry of filesRef.current) seenRef.current.add(`${entry.path}\u0000${entry.mtimeMs}`)
  }, [mode])

  // Chip pass: files that arrived while the panel is open stay chipped for a
  // moment, then join the seen set.
  useEffect(() => {
    if (mode !== 'open') return
    const pending = files.filter(
      (entry) => entry.mtimeMs > openedAtRef.current && !seenRef.current.has(`${entry.path}\u0000${entry.mtimeMs}`),
    )
    if (pending.length === 0) return
    const timer = setTimeout(() => {
      for (const entry of filesRef.current) seenRef.current.add(`${entry.path}\u0000${entry.mtimeMs}`)
    }, 1500)
    return () => clearTimeout(timer)
  }, [files, mode])

  const isNew = useCallback((entry) => {
    if (mode !== 'open') return false
    return entry.mtimeMs > openedAtRef.current && !seenRef.current.has(`${entry.path}\u0000${entry.mtimeMs}`)
  }, [mode])

  const previewEntry = useCallback(async (entry) => {
    setSelected(entry)
    setPreview({ state: 'loading' })
    if (entry.kind === 'image') {
      const result = await rpc.call(CHANNEL, 'readImage', { path: entry.path })
      if (!result.ok) {
        setPreview({ state: 'error', reason: result.error?.message ?? '?' })
        return
      }
      if (result.value.tooLarge) {
        setPreview({ state: 'tooLarge', size: result.value.size })
      } else {
        setPreview({ state: 'image', dataUrl: result.value.dataUrl, size: result.value.size })
      }
    } else if (entry.kind === 'text') {
      const result = await rpc.call(CHANNEL, 'readText', { path: entry.path })
      if (!result.ok) {
        setPreview({ state: 'error', reason: result.error?.message ?? '?' })
        return
      }
      if (result.value.tooLarge) {
        setPreview({ state: 'tooLarge', size: result.value.size })
      } else {
        setPreview({ state: 'text', text: result.value.text, size: result.value.size })
      }
    } else {
      setPreview({ state: 'meta' })
    }
  }, [rpc])

  const openEntry = useCallback(async (entry) => {
    try {
      const response = await api.host.openPath({ path: entry.path })
      if (!response.result.ok) flash(t('openFailed', { reason: response.result.error?.message ?? '?' }))
    } catch (error) {
      flash(t('openFailed', { reason: error instanceof Error ? error.message : String(error) }))
    }
  }, [api, flash, t])

  const revealEntry = useCallback(async (entry) => {
    try {
      const result = await rpc.call(CHANNEL, 'reveal', { path: entry.path })
      if (!result.ok) flash(t('revealFailed', { reason: result.error?.message ?? '?' }))
    } catch (error) {
      flash(t('revealFailed', { reason: error instanceof Error ? error.message : String(error) }))
    }
  }, [rpc, flash, t])

  const copyEntryPath = useCallback(async (entry) => {
    const done = await copyText(entry.path)
    flash(done ? t('copied') : t('copyPath'))
  }, [flash, t])

  /* ── collapsed launcher ── */
  if (mode !== 'open') {
    return (
      <div className="fp_launcher" style={{ pointerEvents: 'auto' }}>
        <button
          type="button"
          className="fp_launcherButton"
          title={t('title')}
          aria-label={t('title')}
          onClick={() => setMode('open')}
        >
          <PanelIcon />
          {newCount > 0 ? <span className="fp_badge">{newCount}</span> : null}
        </button>
      </div>
    )
  }

  /* ── open panel ── */
  return (
    <div className="fp_panel" style={{ width: `${width}px`, height: `${height}px`, left: `${pos.x}px`, top: `${pos.y}px`, pointerEvents: 'auto' }} role="dialog" aria-label={t('title')}>
      <div
        className="fp_resizeHandle fp_resizeHandleLeft"
        title={`${t('resize')} · ${t('resetWidth')}`}
        aria-label={t('resize')}
        role="separator"
        aria-orientation="vertical"
        onPointerDown={onResizeStart('width')}
        onPointerMove={onResizeMove}
        onPointerUp={onResizeEnd}
        onPointerCancel={onResizeEnd}
        onDoubleClick={() => setWidth(DEFAULT_WIDTH)}
      />
      <div
        className="fp_resizeHandle fp_resizeHandleBottom"
        title={`${t('resizeHeight')} · ${t('resetHeight')}`}
        aria-label={t('resizeHeight')}
        role="separator"
        aria-orientation="horizontal"
        onPointerDown={onResizeStart('height')}
        onPointerMove={onResizeMove}
        onPointerUp={onResizeEnd}
        onPointerCancel={onResizeEnd}
        onDoubleClick={() => setHeight(Number.NaN)}
      />
      <div
        className="fp_header"
        title={t('drag')}
        onPointerDown={onMoveStart}
        onPointerMove={onMoveMove}
        onPointerUp={onMoveEnd}
        onPointerCancel={onMoveEnd}
      >
        <span className="fp_title">{t('title')}</span>
        <span className="fp_count">{files.length}</span>
        <div className="fp_headerActions" onPointerDown={(event) => event.stopPropagation()}>
          <button
            type="button"
            className="fp_iconButton"
            title={autoPop ? t('autoPopOn') : t('autoPopOff')}
            onClick={() => setAutoPop(!autoPop)}
          >
            <BellIcon off={!autoPop} />
          </button>
          <button type="button" className="fp_iconButton" title={t('collapse')} onClick={() => setMode('collapsed')}>
            <MinusIcon />
          </button>
          <button type="button" className="fp_iconButton" title={t('close')} onClick={() => setMode('hidden')}>
            <CloseIcon />
          </button>
        </div>
      </div>

      {notice !== null ? <div className="fp_notice">{notice}</div> : null}

      <div className="fp_body">
        {!isLoopback ? (
          <div className="fp_empty">{t('loopbackOnly')}</div>
        ) : unavailable ? (
          <div className="fp_empty">{t('unavailable')}</div>
        ) : currentId === undefined ? (
          <div className="fp_empty">{t('noSession')}</div>
        ) : files.length === 0 ? (
          <div className="fp_empty">{t('empty')}</div>
        ) : (
          <ul className="fp_list">
            {files.map((entry) => (
              <li
                key={`${entry.path}\u0000${entry.mtimeMs}`}
                className={`fp_row${selected?.path === entry.path ? ' fp_rowSelected' : ''}`}
              >
                <button type="button" className="fp_rowMain" onClick={() => previewEntry(entry)}>
                  <span className="fp_glyph">{KIND_GLYPH[entry.kind] ?? '📄'}</span>
                  <span className="fp_rowText">
                    <span className="fp_name">
                      {entry.name}
                      {isNew(entry) ? <span className="fp_newChip">{t('newBadge')}</span> : null}
                    </span>
                    <span className="fp_meta">
                      {displayPathOf(entry, cwd)} · {formatSize(entry.size)} · {formatTime(entry.mtimeMs)}
                    </span>
                  </span>
                </button>
                <span className="fp_rowActions">
                  <button type="button" className="fp_iconButton" title={t('preview')} onClick={() => previewEntry(entry)}>
                    <EyeIcon />
                  </button>
                  <button type="button" className="fp_iconButton" title={t('open')} onClick={() => openEntry(entry)}>
                    <ExternalIcon />
                  </button>
                  {canReveal ? (
                    <button type="button" className="fp_iconButton" title={t('reveal')} onClick={() => revealEntry(entry)}>
                      <FolderIcon />
                    </button>
                  ) : null}
                  <button type="button" className="fp_iconButton" title={t('copyPath')} onClick={() => copyEntryPath(entry)}>
                    <CopyIcon />
                  </button>
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>

      {selected !== null ? (
        <div className="fp_preview">
          <div className="fp_previewHead">
            <span className="fp_previewName">{selected.name}</span>
            <button type="button" className="fp_iconButton" title={t('close')} onClick={() => { setSelected(null); setPreview(null) }}>
              <CloseIcon />
            </button>
          </div>
          <div className="fp_previewBody">
            {preview === null || preview.state === 'loading' ? (
              <div className="fp_previewNote">{t('loading')}</div>
            ) : preview.state === 'image' ? (
              <img className="fp_previewImage" src={preview.dataUrl} alt={selected.name} />
            ) : preview.state === 'text' ? (
              <pre className="fp_previewText">{preview.text}</pre>
            ) : preview.state === 'meta' ? (
              <div className="fp_previewNote">{t('binaryNote')}</div>
            ) : preview.state === 'tooLarge' ? (
              <div className="fp_previewNote">
                {selected.kind === 'image' ? t('tooLargeImage', { size: formatSize(preview.size) }) : t('tooLargeText', { size: formatSize(preview.size) })}
              </div>
            ) : (
              <div className="fp_previewNote">{t('previewFailed', { reason: preview.reason ?? '?' })}</div>
            )}
          </div>
          <div className="fp_previewActions">
            <button type="button" className="fp_actionButton" onClick={() => openEntry(selected)}>
              <ExternalIcon /> {t('open')}
            </button>
            {canReveal ? (
              <button type="button" className="fp_actionButton" onClick={() => revealEntry(selected)}>
                <FolderIcon /> {t('reveal')}
              </button>
            ) : (
              <span className="fp_previewNote fp_inlineNote">{t('revealUnavailable')}</span>
            )}
            <button type="button" className="fp_actionButton" onClick={() => copyEntryPath(selected)}>
              <CopyIcon /> {t('copyPath')}
            </button>
          </div>
        </div>
      ) : cwd !== undefined && cwd !== '' ? (
        <div className="fp_footer">
          <button type="button" className="fp_actionButton" onClick={() => openEntry({ path: cwd, name: cwd, kind: 'binary', size: 0, mtimeMs: 0, dir: cwd })}>
            <FolderIcon /> {t('openWorkspace')}
          </button>
        </div>
      ) : null}
    </div>
  )
}

/* ── plugin body ────────────────────────────────────────────────────────── */

export function apply(ctx) {
  ctx.effect(() => ctx.locale.register(NS, 'zh', zh), 'dsh-file-panel: zh dictionary')
  ctx.effect(() => ctx.locale.register(NS, 'en', en), 'dsh-file-panel: en dictionary')

  const connection = ctx.connection
  const rpc = connection.rpc
  const api = connection.api
  const isLoopback = connection.isLoopback
  const t = ctx.locale.bind(NS)

  ctx.slots.inject('shell.overlay', () => ctx.slots.register(
    { name: 'shell.overlay', id: 'file-panel', order: 100 },
    (props) => <FilePanel {...props} rpc={rpc} api={api} isLoopback={isLoopback} t={t} />,
  ))
}

/* ── styles ─────────────────────────────────────────────────────────────── */

const CSS = `
.fp_launcher { position: fixed; right: 16px; bottom: 16px; z-index: 40; }
.fp_launcherButton {
  width: 44px; height: 44px; border-radius: 12px; border: 1px solid var(--dsw-alias-border-l2);
  background: var(--dsw-alias-bg-layer-3); color: var(--dsw-alias-label-secondary);
  display: flex; align-items: center; justify-content: center; cursor: pointer;
  box-shadow: 0 6px 24px rgba(0,0,0,.18); position: relative;
  transition: color .15s, border-color .15s, transform .15s;
}
.fp_launcherButton:hover { color: var(--dsw-alias-brand-primary); border-color: var(--dsw-alias-label-dimmed); transform: translateY(-1px); }
.fp_badge {
  position: absolute; top: -6px; right: -6px; min-width: 18px; height: 18px; padding: 0 5px;
  border-radius: 999px; background: var(--dsw-alias-brand-primary); color: var(--dsw-alias-bg-layer-3);
  font-size: 11px; font-weight: 600; line-height: 18px; text-align: center;
}
.fp_panel {
  position: fixed; max-width: calc(100vw - 32px);
  min-height: 200px; max-height: calc(100vh - 80px);
  z-index: 40; display: flex; flex-direction: column;
  background: var(--dsw-alias-bg-layer-3); border: 1px solid var(--dsw-alias-border-l2);
  border-radius: 14px; box-shadow: 0 16px 48px rgba(0,0,0,.28);
}
/* Resize handles straddle the panel edge (mostly OUTSIDE it) — the panel
   must not clip them, so overflow clipping lives on the inner scrollers
   (.fp_body / .fp_previewBody) instead of the panel itself. */
.fp_resizeHandle {
  position: absolute; z-index: 1; touch-action: none;
}
.fp_resizeHandle::after {
  content: ''; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
  border-radius: 2px; background: var(--dsw-alias-label-dimmed);
  opacity: .25; transition: opacity .12s;
}
.fp_resizeHandle:hover::after, .fp_resizeHandle:active::after { opacity: 1; }
.fp_resizeHandleLeft { top: 0; bottom: 0; left: -12px; width: 16px; cursor: col-resize; }
.fp_resizeHandleLeft::after { width: 3px; height: 36px; }
.fp_resizeHandleBottom { left: 0; right: 0; bottom: -12px; height: 16px; cursor: ns-resize; }
.fp_resizeHandleBottom::after { width: 36px; height: 3px; }
.fp_header { display: flex; align-items: center; gap: 8px; padding: 10px 12px; border-bottom: 1px solid var(--dsw-alias-border-l2); cursor: grab; touch-action: none; }
.fp_header:active { cursor: grabbing; }
.fp_title { font-size: 14px; font-weight: 600; color: var(--dsw-alias-label-primary); }
.fp_count { font-size: 12px; color: var(--dsw-alias-label-tertiary); }
.fp_headerActions { margin-left: auto; display: flex; gap: 2px; }
.fp_iconButton {
  width: 26px; height: 26px; border: 0; border-radius: 6px; background: transparent;
  color: var(--dsw-alias-label-secondary); display: inline-flex; align-items: center; justify-content: center;
  cursor: pointer; padding: 0; flex: none;
}
.fp_iconButton:hover { background: var(--dsw-alias-fill-tsp-secondary); color: var(--dsw-alias-label-primary); }
.fp_notice {
  margin: 8px 12px 0; padding: 6px 10px; border-radius: 8px; font-size: 12px;
  background: var(--dsw-alias-fill-tsp-secondary); color: var(--dsw-alias-label-secondary);
}
.fp_body { flex: 1; overflow: auto; padding: 8px; }
.fp_empty { padding: 24px 16px; font-size: 13px; color: var(--dsw-alias-label-tertiary); text-align: center; line-height: 1.6; }
/* min-width: max-content keeps full row content laid out, so a panel narrower
   than its widest row shows a horizontal scrollbar instead of clipping. */
.fp_list { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 2px; min-width: max-content; }
.fp_row {
  display: flex; align-items: center; gap: 4px; border-radius: 8px; padding: 2px 4px;
  transition: background .12s;
}
.fp_row:hover { background: var(--dsw-alias-fill-tsp-secondary); }
.fp_rowSelected { background: var(--dsw-alias-fill-tsp-secondary); }
.fp_rowMain {
  display: flex; align-items: center; gap: 8px; flex: 1; min-width: 0; text-align: left;
  background: none; border: 0; padding: 4px 2px; cursor: pointer; color: inherit; font: inherit;
}
.fp_glyph { font-size: 16px; line-height: 1; flex: none; }
.fp_rowText { display: flex; flex-direction: column; gap: 1px; min-width: 0; }
.fp_name {
  font-size: 13px; color: var(--dsw-alias-label-primary); white-space: nowrap;
  overflow: hidden; text-overflow: ellipsis; display: flex; align-items: center; gap: 6px;
}
.fp_newChip {
  font-size: 10px; font-weight: 600; line-height: 1; padding: 2px 5px; border-radius: 999px;
  background: var(--dsw-alias-brand-primary); color: var(--dsw-alias-bg-layer-3); flex: none;
}
.fp_meta { font-size: 11px; color: var(--dsw-alias-label-tertiary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.fp_rowActions { display: none; align-items: center; gap: 2px; flex: none; }
.fp_row:hover .fp_rowActions { display: inline-flex; }
.fp_preview { border-top: 1px solid var(--dsw-alias-border-l2); display: flex; flex-direction: column; max-height: 44%; }
.fp_previewHead { display: flex; align-items: center; gap: 8px; padding: 6px 12px; }
.fp_previewName { font-size: 12px; font-weight: 600; color: var(--dsw-alias-label-secondary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1; }
.fp_previewBody { flex: 1; overflow: auto; padding: 0 12px 8px; }
.fp_previewImage { max-width: 100%; border-radius: 8px; display: block; margin: 0 auto; background: repeating-conic-gradient(#8881 0 25%, transparent 0 50%) 0 0 / 16px 16px; }
.fp_previewText { margin: 0; font-family: ui-monospace, SFMono-Regular, Consolas, monospace; font-size: 11.5px; line-height: 1.5; color: var(--dsw-alias-label-primary); white-space: pre-wrap; word-break: break-word; }
.fp_previewNote { font-size: 12px; color: var(--dsw-alias-label-tertiary); padding: 12px 4px; line-height: 1.5; }
.fp_inlineNote { padding: 0; }
.fp_previewActions { display: flex; flex-wrap: wrap; gap: 6px; padding: 0 12px 10px; align-items: center; }
.fp_footer { border-top: 1px solid var(--dsw-alias-border-l2); padding: 8px 12px; }
.fp_actionButton {
  display: inline-flex; align-items: center; gap: 6px; padding: 5px 10px; font-size: 12px;
  border-radius: 8px; border: 1px solid var(--dsw-alias-border-l2); cursor: pointer;
  background: transparent; color: var(--dsw-alias-label-secondary);
}
.fp_actionButton:hover { border-color: var(--dsw-alias-label-dimmed); color: var(--dsw-alias-label-primary); }
`

const STYLE_TAG_ID = 'dsh-file-panel/style'
if (typeof document !== 'undefined' && document.querySelector(`style[data-plugin-css="${STYLE_TAG_ID}"]`) === null) {
  const tag = document.createElement('style')
  tag.dataset.plugin = 'dsh-file-panel'
  tag.dataset.pluginCss = STYLE_TAG_ID
  tag.textContent = CSS
  document.head.appendChild(tag)
}
