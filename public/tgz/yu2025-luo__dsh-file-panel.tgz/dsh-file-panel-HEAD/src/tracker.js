/**
 * Host-side file tracker for dsh-file-panel.
 *
 * Two observation sources feed one per-session file list:
 *
 * 1. `fs/observed` (from the harness `write`/`edit`/`str_replace_editor` tools)
 *    — precise, instantly attributed to the session that performed the write,
 *    and it covers paths OUTSIDE the session working directory too.
 * 2. A recursive `fs.watch` on each session's working directory — catches
 *    files the agent produces through shell commands (curl, Invoke-WebRequest,
 *    git, unzip, ffmpeg, …), which never emit `fs/observed`.
 *
 * The tracker is plain Node.js (no harness imports), so it is unit-testable
 * in isolation.
 */
import { watch } from 'node:fs'
import { stat } from 'node:fs/promises'
import path from 'node:path'

/** Maximum retained entries per session (oldest evicted first). */
export const MAX_ENTRIES_PER_SESSION = 500
/** Maximum simultaneously watched working directories. */
export const MAX_WATCHERS = 12
/** Watcher debounce: batch a burst of events into one stat pass. */
export const WATCH_DEBOUNCE_MS = 400
/** Directory names never watched (noise sources). */
const IGNORED_DIRS = new Set(['node_modules', '.git', '.hg', '.svn', '.dsh', '__pycache__', '.venv', 'venv'])
/**
 * Hidden directories that stay watchable inside a project. Every other
 * dot-directory (`.config`, `.cache`, `.local`, `.mozilla`, …) is treated
 * as application noise — a home-directory workspace must not flood the
 * panel with browser caches and desktop-indexer internals.
 */
const DOT_DIR_WHITELIST = new Set(['.github', '.vscode', '.idea', '.devcontainer'])
/** File basenames / suffixes never reported. */
const IGNORED_FILES = new Set(['.DS_Store', 'Thumbs.db', 'desktop.ini', 'ehthumbs.db'])
const IGNORED_SUFFIXES = ['.tmp', '.swp', '.swx', '.crdownload', '.part', '.download', '.lock']

export const IMAGE_EXTENSIONS = new Set(['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'bmp', 'ico', 'avif', 'tif', 'tiff'])
export const TEXT_EXTENSIONS = new Set([
  'txt', 'md', 'markdown', 'json', 'jsonc', 'json5', 'js', 'jsx', 'ts', 'tsx', 'mjs', 'cjs',
  'py', 'rb', 'go', 'rs', 'java', 'kt', 'c', 'cc', 'cpp', 'h', 'hpp', 'cs', 'php', 'lua', 'r', 'pl', 'swift', 'scala', 'dart', 'ex', 'exs',
  'css', 'scss', 'sass', 'less', 'html', 'htm', 'xml', 'yaml', 'yml', 'toml', 'ini', 'cfg', 'conf', 'env', 'sh', 'bash', 'zsh', 'bat', 'ps1', 'cmd',
  'csv', 'tsv', 'log', 'sql', 'vue', 'svelte', 'gradle', 'properties', 'patch', 'diff', 'tex', 'bib', 'ipynb',
])
const ARCHIVE_EXTENSIONS = new Set(['zip', 'tar', 'gz', 'tgz', 'bz2', 'tbz2', 'xz', '7z', 'rar', 'lz4', 'zst'])
const OFFICE_EXTENSIONS = new Set(['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'odt', 'ods', 'odp', 'rtf'])
const AUDIO_EXTENSIONS = new Set(['mp3', 'wav', 'ogg', 'flac', 'm4a', 'aac', 'opus', 'wma'])
const VIDEO_EXTENSIONS = new Set(['mp4', 'mkv', 'avi', 'mov', 'webm', 'm4v', 'wmv', 'flv', 'ts'])
const FONT_EXTENSIONS = new Set(['ttf', 'otf', 'woff', 'woff2', 'eot'])
const PDF_EXTENSIONS = new Set(['pdf'])

/** Basenames of well-known extensionless text files. */
const TEXT_BASENAMES = new Set([
  'makefile', 'cmakelists.txt', 'dockerfile', 'license', 'readme', 'changelog',
  'authors', 'copying', 'notice', 'gitignore', 'gitattributes', 'gitmodules',
  'editorconfig', 'prettierrc', 'eslintrc', 'babelrc', 'npmrc', 'yarnrc', 'pnpmrc', 'package-lock.json',
])

/**
 * Classify a file path into a coarse kind used for icons and preview choice.
 * @param {string} filePath
 * @returns {'image'|'text'|'archive'|'pdf'|'office'|'audio'|'video'|'font'|'binary'}
 */
export function kindOf(filePath) {
  const base = path.basename(filePath).toLowerCase()
  const ext = path.extname(base).slice(1).toLowerCase()
  if (ext !== '' && ext.length <= 8) {
    if (IMAGE_EXTENSIONS.has(ext)) return 'image'
    if (TEXT_EXTENSIONS.has(ext)) return 'text'
    if (ARCHIVE_EXTENSIONS.has(ext)) return 'archive'
    if (OFFICE_EXTENSIONS.has(ext)) return 'office'
    if (AUDIO_EXTENSIONS.has(ext)) return 'audio'
    if (VIDEO_EXTENSIONS.has(ext)) return 'video'
    if (FONT_EXTENSIONS.has(ext)) return 'font'
    if (PDF_EXTENSIONS.has(ext)) return 'pdf'
    if (base.startsWith('.')) return 'text'
  }
  if (TEXT_BASENAMES.has(base)) return 'text'
  return 'binary'
}

/** MIME types used for image preview data URLs. */
const IMAGE_MIME = {
  png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif',
  webp: 'image/webp', svg: 'image/svg+xml', bmp: 'image/bmp', ico: 'image/x-icon',
  avif: 'image/avif', tif: 'image/tiff', tiff: 'image/tiff',
}

/** @param {string} filePath @returns {string} */
export function mimeOfImage(filePath) {
  const ext = path.extname(filePath).slice(1).toLowerCase()
  return IMAGE_MIME[ext] ?? 'application/octet-stream'
}

/** Case-normalized comparison for Windows paths. */
function samePath(a, b) {
  if (process.platform === 'win32') return a.toLowerCase() === b.toLowerCase()
  return a === b
}

/**
 * Whether a path observed by the recursive watcher should be reported.
 * Also the containment half of the RPC fence: a path passes only when it is
 * strictly inside `root`.
 *
 * On Windows, `path.relative` across drives returns the target's ABSOLUTE
 * path (not a `..`-prefixed relative one), so absolute results must be
 * rejected explicitly — otherwise every path on another drive would appear
 * to be "inside" the root.
 * @param {string} root the watched working directory
 * @param {string} filePath absolute path observed
 */
export function isWatchable(root, filePath) {
  const rel = path.relative(root, filePath)
  if (rel === '') return false
  if (path.isAbsolute(rel) || rel === '..' || rel.startsWith(`..${path.sep}`)) return false
  const segments = rel.split(/[\\/]/)
  if (segments.some((segment) => IGNORED_DIRS.has(segment))) return false
  // Every segment before the basename is a directory: hidden dot-directories
  // are noise unless whitelisted. The basename itself stays subject only to
  // the file-level rules below, so project dot-FILES (.env, .gitignore)
  // remain visible.
  for (let i = 0; i < segments.length - 1; i++) {
    const segment = segments[i]
    if (segment.startsWith('.') && !DOT_DIR_WHITELIST.has(segment)) return false
  }
  const base = segments[segments.length - 1]
  if (IGNORED_FILES.has(base)) return false
  return !IGNORED_SUFFIXES.some((suffix) => base.toLowerCase().endsWith(suffix))
}

export class FileTracker {
  constructor() {
    /** @type {Map<string, Map<string, FileEntry>>} sessionId -> absolute path -> entry */
    this.bySession = new Map()
    /** @type {Map<string, WatcherCell>} watched cwd -> cell */
    this.watchers = new Map()
    /** @type {Set<string>} every path currently tracked (RPC validation fence) */
    this.knownPaths = new Set()
    /** @type {Set<string>} every cwd currently watched (RPC validation fence) */
    this.watchedRoots = new Set()
    /** @type {Map<string, string>} cwd -> session currently viewing that workspace */
    this.activeSessions = new Map()
  }

  /**
   * Record that a file exists now. Called from `fs/observed` and from
   * watcher events.
   * @param {string} absPath
   * @param {{ sessionId: string, cwd?: string }} attribution
   * @param {number} [mtimeMs] known modification time (avoids a stat)
   */
  async touch(absPath, attribution, mtimeMs) {
    try {
      const info = await stat(absPath)
      if (!info.isFile()) return
      this.record(absPath, {
        path: absPath,
        name: path.basename(absPath),
        dir: path.dirname(absPath),
        size: info.size,
        mtimeMs: Math.floor(info.mtimeMs),
        kind: kindOf(absPath),
      }, attribution)
    } catch {
      // Deleted between the event and the stat — nothing to report.
    }
  }

  /** Insert/refresh one entry in the attributed session's map. */
  record(absPath, entry, { sessionId, cwd }) {
    let map = this.bySession.get(sessionId)
    if (map === undefined) {
      map = new Map()
      this.bySession.set(sessionId, map)
    }
    map.delete(absPath)
    map.set(absPath, entry)
    if (map.size > MAX_ENTRIES_PER_SESSION) {
      const oldest = map.keys().next().value
      map.delete(oldest)
      this.refreshKnownPaths()
    } else {
      this.knownPaths.add(absPath)
    }
    if (cwd !== undefined && !this.watchers.has(cwd)) this.ensureWatcher(cwd, sessionId)
    else if (cwd !== undefined) this.watchers.get(cwd).sessions.add(sessionId)
  }

  refreshKnownPaths() {
    this.knownPaths = new Set()
    for (const map of this.bySession.values()) for (const key of map.keys()) this.knownPaths.add(key)
  }

  /** Start a recursive watcher for a session working directory (deduped, capped). */
  ensureWatcher(cwd, sessionId) {
    if (this.watchers.has(cwd)) {
      this.watchers.get(cwd).sessions.add(sessionId)
      return
    }
    if (this.watchers.size >= MAX_WATCHERS) {
      const oldestKey = this.watchers.keys().next().value
      this.stopWatcher(oldestKey)
    }
    const cell = {
      cwd,
      sessions: new Set([sessionId]),
      watcher: null,
      pending: new Set(),
      timer: null,
    }
    this.watchers.set(cwd, cell)
    this.watchedRoots.add(cwd)
    try {
      cell.watcher = watch(cwd, { recursive: true }, (eventType, filename) => {
        if (filename === null || typeof filename !== 'string') return
        const abs = path.join(cwd, filename)
        if (!isWatchable(cwd, abs)) return
        cell.pending.add(abs)
        if (cell.timer !== null) clearTimeout(cell.timer)
        cell.timer = setTimeout(() => this.flushWatcher(cwd), WATCH_DEBOUNCE_MS)
      })
      cell.watcher.on('error', () => {
        // A deleted/renamed root or unsupported platform: stop silently, the
        // `fs/observed` source still covers tool writes.
        this.stopWatcher(cwd)
      })
    } catch {
      this.stopWatcher(cwd)
    }
  }

  async flushWatcher(cwd) {
    const cell = this.watchers.get(cwd)
    if (cell === undefined) return
    const pending = [...cell.pending]
    cell.pending.clear()
    cell.timer = null
    // The panel follows the conversation: watcher events (shell downloads)
    // are attributed to the session currently viewing this workspace, not
    // broadcast to every session that shares the same working directory.
    const sessionId = this.activeSessions.get(cwd) ?? cell.sessions.values().next().value
    if (sessionId === undefined) return
    await Promise.all(pending.map(async (abs) => {
      await this.touch(abs, { sessionId, cwd })
    }))
  }

  stopWatcher(cwd) {
    const cell = this.watchers.get(cwd)
    if (cell === undefined) return
    if (cell.timer !== null) clearTimeout(cell.timer)
    try { cell.watcher?.close() } catch { /* already closed */ }
    this.watchers.delete(cwd)
    this.watchedRoots.delete(cwd)
  }

  /**
   * Ensure a watcher exists for `cwd` and is attributed to `sessionId`
   * (used by the client's `list` call, which already knows the session cwd).
   */
  attribute(sessionId, cwd) {
    if (cwd === undefined || cwd === '') return
    this.ensureWatcher(cwd, sessionId)
    // The panel shows the conversation on screen: watcher events from now on
    // belong to this session until another session starts viewing the cwd.
    this.activeSessions.set(cwd, sessionId)
  }

  /**
   * Files for one session, newest first, capped.
   * @param {string} sessionId
   */
  filesFor(sessionId) {
    const map = this.bySession.get(sessionId)
    if (map === undefined) return []
    const files = [...map.values()]
    files.sort((a, b) => b.mtimeMs - a.mtimeMs)
    return files.slice(0, 250)
  }

  /**
   * Whether a requested path may be read/revealed through the RPC fence:
   * either an explicitly tracked file or a file under a watched root.
   * @param {string} absPath
   */
  isAllowed(absPath) {
    if (this.knownPaths.has(absPath)) return true
    for (const root of this.watchedRoots) {
      if (isWatchable(root, absPath)) return true
    }
    return false
  }

  dispose() {
    for (const cwd of [...this.watchers.keys()]) this.stopWatcher(cwd)
    this.bySession.clear()
    this.knownPaths.clear()
    this.activeSessions.clear()
  }
}

/** @typedef {{ path: string, name: string, dir: string, size: number, mtimeMs: number, kind: string }} FileEntry */
