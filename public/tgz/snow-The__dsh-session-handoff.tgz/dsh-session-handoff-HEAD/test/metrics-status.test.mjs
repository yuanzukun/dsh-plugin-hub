/**
 * The wired path: apply() -> acp_status -> the text a user reads.
 *
 * Why a boot test and not just the pure renderers: this plugin once had a banner whose unit test
 * passed against a string that nobody rendered. The metrics block is only worth anything if the
 * tool actually prints it, next to a journal that actually has rows.
 */
import { after, test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const dir = mkdtempSync(join(tmpdir(), 'acp-status-'));
process.env.DSH_HOME = dir;
process.env.DSH_ACP_METRICS = join(dir, 'acp-metrics.jsonl');
process.env.DSH_NOTEMAP_RETRIEVAL = join(dir, 'notemap-retrieval.jsonl');

const ROWS = [
  { v: 1, ts: 1000, session: 's1', start: 1, end: 9, nodes: 8, before: 10000, after: 4000, lossTokens: 6000, lossCostCNY: 0.5, ms: 300, userMsgs: 3 },
  { v: 1, ts: 4000, session: 's1', start: 10, end: 20, nodes: 10, before: 8000, after: 3000, lossTokens: 5000, lossCostCNY: 0.4, ms: 200, userMsgs: 7 },
];
writeFileSync(process.env.DSH_ACP_METRICS, ROWS.map((r) => JSON.stringify(r)).join('\n') + '\n');
writeFileSync(process.env.DSH_NOTEMAP_RETRIEVAL,
  JSON.stringify({ v: 1, tool: 'notemap_neighbors', truncated: true }) + '\n'
  + JSON.stringify({ v: 1, tool: 'notemap_paths', unknown_id: 'readimm8' }) + '\n');

const { apply, dispose } = await import('../lib/index.js');
const { readMetrics, formatCheckpointLines } = await import('../lib/metrics.js');

// A fold starts the ingest worker; its MessagePort is a live handle, so the suite must end it
// explicitly or the test process hangs forever with no failing test to show for it.
after(() => { dispose(); });

/** The smallest ctx that boots the plugin: register, services, lifecycle hooks. */
function boot() {
  const registered = [];
  const meter = { measure: () => ({ totalTokens: 1234, nodes: [{ seq: 1, tokens: 1234 }] }) };
  const llm = { resolveModelInfo: async () => ({ contextWindow: 10000 }) };
  const ctx = {
    tools: { register: (d) => { registered.push(d); return d; } },
    get: (k) => (k === 'tokenMeter' ? meter : k === 'llm' ? llm : undefined),
    logger: { info() {}, warn() {}, error() {}, debug() {} },
    effect: () => {}, on: () => {}, provide: () => {},
  };
  apply(ctx, { minContextLimit: '50%', maxContextLimit: '90%' });
  const session = {
    id: 's1',
    surface: { nodes: [1, 2, 3] },
    events: [],
    requestHeader: () => ({ config: { provider: 'deepseek', model: 'probe' } }),
    ctx,
  };
  const agent = { session, ctx, options: { provider: "deepseek", model: "probe" } };
  return { registered, agent };
}

test('acp_status prints the budget ledger, the four layers and the pooled view', async () => {
  const { registered, agent } = boot();
  const status = registered.find((t) => t.name === 'acp_status');
  assert.ok(status, "acp_status must be registered");
  const text = await status.execute({}, { agent });

  assert.match(text, /budget: used 1234 tok = 12\.3% of 10000 \(window reported by the host\) \| soft 5000 = 50\.0% \| hard 9000 = 90\.0% \| unit: tokenMeter estimate/,
    'ratio, absolute cap and unit in one line: ' + text.split('\n')[1]);
  assert.match(text, /L1 stored: 1234 tok on the surface \/ 3 nodes \/ 0 collapsed/);
  assert.match(text, /L2 delivered \(billed\): not recorded for this session yet/);
  assert.match(text, /L3 work: 2 compaction\(s\), ~11000 tok re-sent uncached \(ESTIMATED from the post-fold context\), ≈0\.900 CNY, 500 ms of plugin-side fold calls, 7 user turns so far/);
  assert.match(text, /L3 measured: no settled fold bill yet/, 'an unsettled fold must read as not measured, not as a zero bill');
  assert.match(text, /L4 outcome \(proxy\): gap between the last two folds 3\.0s/);
  assert.match(text, /retrieval signals: 2 degenerate answer\(s\) — 1 truncated, 1 unknown_id, 0 unresolved/);
  assert.match(text, /restatement of the same request by the user: NOT measured/);
  assert.match(text, /pooled: 2 compaction\(s\) across 1 session\(s\), avg shrink 61\.1%/);
  assert.match(text, /this session: 2, avg shrink 61\.1%/);
  assert.match(text, /compactions this session: 2 in the journal \(0 in this process - a restart resets that ledger\)/,
    'the journal and the in-process ledger must not contradict each other');
});

test('without a journal the status says so — it does not invent zeros', async () => {
  process.env.DSH_ACP_METRICS = join(dir, 'absent.jsonl');
  const { registered, agent } = boot();
  const text = await registered.find((t) => t.name === 'acp_status').execute({}, { agent });
  assert.match(text, /pooled: no compactions recorded in the journal/);
  assert.match(text, /L4 outcome \(proxy\): no fold recorded for this session/);
  assert.match(text, /compactions this session: none recorded/);
  assert.ok(!/avg shrink/.test(text), 'no data must not render as a shrink figure');
  process.env.DSH_ACP_METRICS = join(dir, 'acp-metrics.jsonl');
});

test('an unknown window is printed as UNKNOWN, never as a full context', async () => {
  const registered = [];
  const meter = { measure: () => ({ totalTokens: 999999, nodes: [] }) };
  const ctx = {
    tools: { register: (d) => { registered.push(d); return d; } },
    get: (k) => (k === 'tokenMeter' ? meter : undefined),
    logger: { info() {}, warn() {}, error() {}, debug() {} },
    effect: () => {}, on: () => {}, provide: () => {},
  };
  apply(ctx, { minContextLimit: "50%", maxContextLimit: "90%" });
  const session = { id: 's2', surface: { nodes: [] }, events: [], requestHeader: () => ({ config: {} }), ctx };
  const text = await registered.find((t) => t.name === "acp_status").execute({}, { agent: { session, ctx } });
  assert.match(text, /window UNKNOWN/);
  assert.match(text, /no-llm-service|no-provider-model/, 'the reason is named: ' + text);
  const budgetLine = text.split('\n').find((l) => l.startsWith('budget:'));
  assert.ok(!/%/.test(budgetLine), 'no percentage may be manufactured without a denominator: ' + budgetLine);
});

/**
 * The automatic fold: this is the half that must never need a human or a model decision. The tool
 * `acp_compress` is the model folding EARLY (its own choice); this is the host folding at the fuse,
 * on `agent/pre-step`, before the request is built. If this test goes red, "跑下去" is a lie.
 */
function bootAutoFold({ shrink = true } = {}) {
  const handlers = new Map();
  const registered = [];
  const logs = [];
  const foldedCalls = [];
  let used = 950000;
  const meter = { measure: () => ({ totalTokens: used, nodes: Array.from({ length: 10 }, (_, i) => ({ seq: i + 1, tokens: 95000 })) }) };
  const compaction = {
    compactRegion: async (start, end) => {
      foldedCalls.push([start, end]);
      if (shrink) used = 300000;
      return { shadowedRange: { start, end }, shadowedSeqs: [1, 2, 3, 4, 5, 6, 7, 8] };
    },
  };
  const llm = { resolveModelInfo: async () => ({ contextWindow: 1000000 }) };
  const ctx = {
    tools: { register: (d) => { registered.push(d); return d; } },
    get: (k) => (k === 'tokenMeter' ? meter : k === 'llm' ? llm : k === 'compaction' ? compaction : undefined),
    logger: { info: (m) => logs.push(String(m)), warn: (m) => logs.push(String(m)), error() {}, debug() {} },
    effect: () => {}, provide: () => {},
    on: (evt, fn) => { handlers.set(evt, fn); },
  };
  apply(ctx, { minContextLimit: '78%', maxContextLimit: '90%' });
  // A real harness session has NO `events` property (ownEvents/snapshotEvents are the accessors) -
  // so this stub deliberately exposes only the accessor. Reading `.events` is exactly the bug that
  // made the user count always 0 and the lossless block store always empty.
  const events = [];
  events.push({ seq: 1, type: 'user/message', data: { message: { content: 'first ask' } } });
  events.push({ seq: 2, type: 'assistant/message', data: { message: { content: 'working' } } });
  events.push({ seq: 3, type: 'user/message', data: { message: { content: 'second ask' } } });
  events.push({ seq: 4, type: 'tool/result', data: { name: 'pwsh', text: 'z'.repeat(300) } });
  events.push({ seq: 5, type: 'user/message', data: { message: { content: 'third ask' } } });
  const session = {
    id: 'auto-fold-' + (shrink ? 'ok' : 'stuck'),
    surface: { nodes: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] },
    ownEvents: () => events,
    requestHeader: () => ({ config: { provider: 'deepseek', model: 'probe' } }),
    ctx,
  };
  return { agent: { session, ctx, options: {} }, handlers, logs, foldedCalls, session, registered };
}

test('the host folds by itself at the fuse — no model call, no user, no asking', async () => {
  const before = readMetrics().rows.length;
  const { agent, handlers, logs, foldedCalls, registered } = bootAutoFold();
  const preStep = handlers.get('agent/pre-step');
  assert.equal(typeof preStep, 'function', 'the automatic fold must hang off agent/pre-step');
  let nextCalled = false;
  await preStep({ agent }, () => { nextCalled = true; });
  // [2, 8]: index 0 is the system-prompt node and is NEVER folded (a host fold that rewrote it was a
  // real bug once); the last two nodes are the preserved tail.
  assert.deepEqual(foldedCalls, [[2, 8]], "everything foldable was folded, unprompted");
  assert.ok(nextCalled, "and the step then proceeds — the fold does not stop the run");
  assert.ok(logs.some((l) => /acp host-trigger: folded 950000 -> 300000/.test(l)), "the fold is logged: " + logs.join(" | "));
  const rows = readMetrics().rows;
  assert.equal(rows.length, before + 1, "the automatic fold leaves a journal row like any other fold");
  const row = rows[rows.length - 1];
  assert.equal(row.before, 950000);
  assert.equal(row.after, 300000);
  assert.equal(row.userMsgs, 3, "L4's context is a REAL count - it read a property the host does not have and was always 0");

  // The lossless block store: a 300-char tool result sat inside the folded range, so it must be
  // recoverable. This path was a no-op for the same reason (`session.events`) and reported
  // "blocks saved: 0" - a number that reads like "nothing was worth keeping".
  const stats = await registered.find((t) => t.name === 'acp_block').execute({ command: 'stats' }, {});
  assert.match(String(stats), /blocks=[1-9]/, "the folded tool output must really be in the block store: " + String(stats));
});

test('a fold that does not shrink is reported and cooled down, not retried in a loop', async () => {
  const { agent, handlers, logs, foldedCalls } = bootAutoFold({ shrink: false });
  const preStep = handlers.get('agent/pre-step');
  await preStep({ agent }, () => {});
  assert.equal(foldedCalls.length, 1);
  assert.ok(logs.some((l) => /FOLD FAILED/.test(l)), "a fold that achieved nothing must say so: " + logs.join(" | "));
  await preStep({ agent }, () => {});
  assert.equal(foldedCalls.length, 1, "the cooldown stops a failing fold from being retried on every step");
});

after(() => {
  dispose();
  console.log('ACTIVE RESOURCES AFTER TESTS: ' + JSON.stringify(process.getActiveResourcesInfo()));
});

process.on('exit', () => { try { rmSync(dir, { recursive: true, force: true }); } catch { /* best effort */ } });
/**
 * A refused fold must not become a dead end.
 *
 * Real session evidence: the agent called acp_compress with an explicit end and the core answered
 * "end seq 14400 is not a balanced boundary (would split a step, or the step is still open)". The
 * agent had already told the user a compaction was coming, and none did. The plugin now retries ONCE
 * at the boundary end:'auto' would have picked — the range only ever shrinks, so this can never fold
 * more than the caller asked for.
 */
test('an end that would split a step is retried at the balanced boundary, never a dead end', async () => {
  const registered = [];
  const calls = [];
  let used = 400000;
  const meter = { measure: () => ({ totalTokens: used, nodes: Array.from({ length: 10 }, (_, i) => ({ seq: i + 1, tokens: 40000 })) }) };
  const compaction = {
    compactRegion: async (start, end) => {
      calls.push([start, end]);
      if (calls.length === 1) throw new Error('compactRegion: end seq ' + end + ' is not a balanced boundary (would split a step, or the step is still open)');
      used = 120000;
      return { shadowedRange: { start, end }, shadowedSeqs: [2, 3, 4] };
    },
  };
  const ctx = {
    tools: { register: (d) => { registered.push(d); return d; } },
    get: (k) => (k === 'tokenMeter' ? meter : k === 'compaction' ? compaction : k === 'llm' ? { resolveModelInfo: async () => ({ contextWindow: 1000000 }) } : undefined),
    logger: { info() {}, warn() {}, error() {}, debug() {} },
    effect: () => {}, provide: () => {}, on: () => {},
  };
  apply(ctx, { minContextLimit: '78%', maxContextLimit: '90%' });
  // Nodes 3/4 are one complete step (call c1, result c1); node 5 opens c2, so a cut right after node 5
  // would split that step — exactly what the core refuses.
  const events = [
    { seq: 2, type: 'user/message', data: { message: { content: [{ type: 'text', text: 'ask' }] } } },
    { seq: 3, type: 'assistant/message', data: { message: { content: [{ type: 'tool-call', id: 'c1', name: 'run_code' }] } } },
    { seq: 4, type: 'tool/result', data: { message: { content: [{ type: 'tool-result', toolCallId: 'c1', content: [{ type: 'text', text: 'out' }] }] } } },
    { seq: 5, type: 'assistant/message', data: { message: { content: [{ type: 'tool-call', id: 'c2', name: 'run_code' }] } } },
    { seq: 6, type: 'tool/result', data: { message: { content: [{ type: 'tool-result', toolCallId: 'c2', content: [{ type: 'text', text: 'out' }] }] } } },
  ];
  const session = {
    id: 'snap-retry', surface: { nodes: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] },
    ownEvents: () => events, requestHeader: () => ({ config: { provider: 'deepseek', model: 'probe' } }), ctx,
  };
  const agent = { session, ctx, options: {} };
  const tool = registered.find((t) => t.name === 'acp_compress');
  const out = await tool.execute({ start: 2, end: 5, deep: false, summary: 'a model-authored summary' }, { agent });
  assert.equal(calls.length, 2, 'refused once, retried once: ' + JSON.stringify(calls));
  assert.deepEqual(calls[0], [2, 5], 'the first attempt used exactly what the caller asked for');
  assert.equal(calls[1][0], 2, 'the start is untouched');
  assert.equal(calls[1][1], 4, 'the retry snapped DOWN to the last balanced cut (node 4 closes c1); node 5 opens c2');
  assert.ok(calls[1][1] < 5, 'a retry is a SUBSET of what the caller asked for, never a bigger fold');
  assert.match(String(out), /split a step: folded DOWN to the balanced boundary 4 instead/, 'and the caller is told what happened: ' + out);
});
/**
 * A fold pays back only if it removes a real share of the context.
 *
 * Live probe that motivated this: a 596-token fold of a 507k context answered "the next call re-sends
 * ~507,508 tokens uncached (≈0.497)" — one full-prefix miss to save ~12 tokens per request, i.e. a
 * 41,700-request payback. The guard refuses such a fold and says why, instead of quietly paying.
 */
function bootShare({ nodes = 100, per = 4000 } = {}) {
  const registered = [];
  const calls = [];
  const meter = { measure: () => ({ totalTokens: nodes * per, nodes: Array.from({ length: nodes }, (_, i) => ({ seq: i + 1, tokens: per })) }) };
  const compaction = {
    compactRegion: async (start, end) => { calls.push([start, end]); return { shadowedRange: { start, end }, shadowedSeqs: [start] }; },
  };
  const ctx = {
    tools: { register: (d) => { registered.push(d); return d; } },
    get: (k) => (k === 'tokenMeter' ? meter : k === 'compaction' ? compaction : undefined),
    logger: { info() {}, warn() {}, error() {}, debug() {} },
    effect: () => {}, provide: () => {}, on: () => {},
  };
  apply(ctx, { minContextLimit: '78%', maxContextLimit: '90%' });
  const session = {
    id: 'share-' + nodes + '-' + per, surface: { nodes: Array.from({ length: nodes }, (_, i) => i + 1) },
    ownEvents: () => [], requestHeader: () => ({ config: {} }), ctx,
  };
  return { agent: { session, ctx, options: {} }, registered, calls };
}

test('a fold too small to pay for its own cache miss is refused, with the arithmetic', async () => {
  const { agent, registered, calls } = bootShare();
  const tool = registered.find((t) => t.name === 'acp_compress');
  await assert.rejects(
    () => tool.execute({ start: 2, end: 2, deep: false, summary: 'cosmetic' }, { agent }),
    (err) => {
      assert.match(String(err.message), /would remove ~4000 of ~400000 tokens \(1\.0%\)/, err.message);
      assert.match(String(err.message), /break-even is ~\d+ later requests/, 'the arithmetic is shown: ' + err.message);
      assert.match(String(err.message), /at least 10% of the context/, 'and the way out is named');
      return true;
    },
  );
  assert.deepEqual(calls, [], 'nothing was folded, so no miss was paid');
});

test('a fold that removes a real share goes through', async () => {
  const { agent, registered, calls } = bootShare();
  const tool = registered.find((t) => t.name === 'acp_compress');
  await tool.execute({ start: 2, end: 50, deep: false, summary: 'half the surface' }, { agent });
  assert.deepEqual(calls, [[2, 50]], '49% of the context is worth the miss');
});

// ---------------------------------------------------------------------------
// The checkpoint table. `acp_decompress` matches a CHECKPOINT, not an arbitrary range, so a model
// that wants to retrieve something must be able to READ the boundary somewhere a tool prints. The
// journal always held {start, end}; these two tests pin that it reaches the text.
// ---------------------------------------------------------------------------

test('acp_status prints the exact shadowed range of every checkpoint', async () => {
  const { registered, agent } = boot();
  const text = await registered.find((t) => t.name === 'acp_status').execute({}, { agent });
  assert.match(text, /recoverable checkpoints \(acp_decompress needs these EXACT boundaries\):/);
  assert.match(text, /s1-s9 {2}8 node\(s\) {2}10000->4000 tok/,
    'the first fold row must be readable with both endpoints: ' + text);
  assert.match(text, /s10-s20 {2}10 node\(s\) {2}8000->3000 tok/);
});

test('a checkpoint table is per-session and de-duplicated — it is a retrieval index, not a log', () => {
  const rows = [
    { ts: 1, session: 's1', start: 5, end: 9, nodes: 4 },
    { ts: 2, session: 's1', start: 5, end: 9, nodes: 4 },          // retried write of the same fold
    { ts: 3, session: 's2', start: 1, end: 2, nodes: 1 },          // another session
    { ts: 4, session: 's1', start: 10, end: 20, nodes: 10, before: 8000, after: 3000 },
    { ts: 5, session: 's1', kind: 'settle', start: 99, end: 99 },  // settle rows are not folds
  ];
  const lines = formatCheckpointLines(rows, 's1');
  assert.equal(lines.length, 3, 'one header + two distinct folds: ' + JSON.stringify(lines));
  assert.ok(lines.some((l) => /s5-s9/.test(l)), lines.join('\n'));
  assert.ok(lines.some((l) => /s10-s20/.test(l)), lines.join('\n'));
  assert.ok(!lines.some((l) => /s1-s2|s99/.test(l)), 'other sessions and settle rows must not appear: ' + lines.join('\n'));
  // `s5-s9`, not `5-9`: the prefix is load-bearing. acp_decompress takes INTS, but every id a
  // caller reads elsewhere (the surface map, the checkpoint message, acp_search) carries the `s`,
  // so a table without it invites a copy-paste that fails the surface check.
  assert.ok(lines[1].includes('s5-s9') && lines[2].includes('s10-s20'), 'ordered by start: ' + lines.join('\n'));
});

test('no folds means no checkpoint header — it does not print an empty table', async () => {
  const text = await (async () => {
    process.env.DSH_ACP_METRICS = join(dir, 'absent2.jsonl');
    const { registered, agent } = boot();
    const t = await registered.find((x) => x.name === 'acp_status').execute({}, { agent });
    process.env.DSH_ACP_METRICS = join(dir, 'acp-metrics.jsonl');
    return t;
  })();
  assert.ok(!/recoverable checkpoints/.test(text), 'an empty table is noise: ' + text);
});
