# AGENTS.md —— 项目宪法

> 本文件是整个仓库中最重要的文件。所有 AI coding agent（以及人类工程师）在本仓库工作前必须阅读并遵守。
> 每一行规则都必须通过检验：**「删掉这行，AI 会犯错吗？」** 删了不会犯错的行不该存在。

---

## 1. 双层架构（TS 编排层 / Python 领域层）

- **TS 层 `src/`** 只拥有：工具 schema、交叉校验、子进程编排、超时、receipt 解析。**不含任何 CAE 领域知识**（不知道 FoamFile 头长什么样、不知道 tet10 节点序）。
- **Python 层 `python/dsh_cae/`** 拥有全部领域知识。每个 stage 经
  `python -m dsh_cae.<stage> [mode] ...` 一次性子进程调用；stdout 中 `<<<DSH_CAE_JSON>>>` marker 之后的单个 JSON 是 receipt。
- **域失败（求解器崩溃、不收敛、网格畸形……）= 正常 receipt**（带 exitCode/logTail，exit 0）；**仅基础设施失败**（非零退出 / 无 marker / marker 后 JSON 不可解析 / 超时）才在 TS 侧抛异常。把 ccx 非零退出当异常抛出会丢掉 logTail，AI 就无法诊断。
- **stage 名表（TS 与 Python 的唯一耦合契约）**——工具名 ↔ 包名 ↔ mode 取值一一对应，改任一侧必须同一 commit 改齐：

  | 工具 | stage（包名） | 子命令/mode |
  | --- | --- | --- |
  | `cae_geometry` | `geometry` | `build` \| `import` |
  | `cae_mesh` | `mesh` | `solid` \| `fluid` |
  | `cae_solve` | `solve` | `static` \| `steady` \| `transient` |
  | `cae_post` | `post` | — |
  | `cae_verify` | `verify` | `structural` \| `cfd` |
  | （依赖自检） | `shared.deps` | `--group structural` \| `--group cfd` |
  | （测试桩） | `fixtures.fake_stage` | `--mode ok`\|`fail`\|`sleep`\|`no-receipt` |

- 依赖方向 DAG：`verify → {mesh, solve, post} → shared`；`geometry → shared`。禁止反向、禁止 verify 之外的兄弟包互调、fixtures 独立。各包细则见 `python/dsh_cae/<pkg>/AGENTS.md`。

## 2. 错误只在系统边界，一层一次

- **TS `execute()` 是分支组合校验的唯一一层**：mode 缺分支必填参数、传入了非本 mode 的参数（报 `'step' belongs to mode='import'` 而非静默忽略）、velocity 长度、endTimeS/writeIntervalS 整除、case stem 路径分隔符。
- **Python 各 `main()` 只校验自己的 argv 完整性**（pytest 直接驱动 CLI，是真实边界）；领域函数（`generate`/`solve`/`extract`/`study`）互信其调用者，不重复校验。
- 两层校验对象不同（合并前的工具参数 vs 子进程 argv），不构成重复，不要「统一」它们。

## 3. 双面镜像契约

- `src/tools/solve.ts` 的 `OVERRIDES_PARAM`/`OVERRIDE_FILES` ↔ `python/dsh_cae/shared/cfd_case.py` 的 `CASE_DICT_FILES`：override 可触碰的 case 字典文件白名单在两侧各有一份，**改必须双侧同一 commit**（两侧代码里已有注释互相指向）。

## 4. YAGNI / Deferred

- 没有事故证据（真实翻车记录、现存的出错调用路径、≥3 个真实调用者）不加重试、缓存、降级、抽象层。
- Deferred 想法记入 `progress.md` 的「遗留」区，不写代码、不留死分支。

## 5. 验收命令红线

- **Python 测试必须用 console script 加环境清洗**（repo 根执行）：

  ```
  LD_LIBRARY_PATH="$HOME/miniconda3/envs/dsh-cae/lib" PATH="$HOME/miniconda3/envs/dsh-cae/bin:$PATH" ~/miniconda3/envs/dsh-cae/bin/pytest pytest/<file> -v
  ```

  - 禁止 repo 根 `python -m pytest`：仓库的 `pytest/` 测试目录会遮蔽已安装的 pytest 包，直接 collection error。
  - PATH 必须前置 env 的 bin：否则找不到 `ccx`，结构链测试**静默 skip**（假绿）而非 fail。
  - LD_LIBRARY_PATH 不清洗则 conda env 的 Python 可能导入失败（pyexpat 符号错误一类）。
- TS 测试：`pnpm build && pnpm vitest run`（无需 API key）。
- **宣布完成前必须真实运行验收命令并贴输出**到 progress.md；不许说「应该能通过」。

## 6. Git

- 原子 commit，conventional 风格（`feat:` / `fix:` / `docs:` / `chore:` / `test:`）。
- **禁止任何 AI 署名尾注**：不加 `Co-Authored-By`、不加「Generated with …」。贡献者只有维护者本人。

## 7. 交接三件套（跨会话）

- 新会话第一件事：读 `feature_list.json`（功能验收状态）→ `progress.md`（交接日志）→ `docs/specs/`（意图源头）。
- 新功能开工前先查 `MODULES.md`，已有模块能解决的事禁止新写；新增可复用模块必须登记进去。
- `feature_list.json` 中 `passes` 只能在对应 `acceptance_command` 真实运行通过并贴出输出后翻 `true`。
