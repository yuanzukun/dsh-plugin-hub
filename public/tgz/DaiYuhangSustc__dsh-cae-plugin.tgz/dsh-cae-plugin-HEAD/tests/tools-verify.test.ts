// tests/tools-verify.test.ts
import { resolve } from 'node:path'
import { describe, expect, it, vi, beforeEach } from 'vitest'
import type { ToolRunContext } from '@deepseek-ai/dsh-tools'
import { defineCaeVerifyTool } from '../src/tools/verify.ts'

vi.mock('../src/runner.js', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../src/runner.js')>()
  return { ...actual, ensureDeps: vi.fn(), runStage: vi.fn() }
})

const config = { python: 'python3', workdir: './cae-stub', stageTimeoutMs: 1000 } as const
const exec = () => ({ signal: new AbortController().signal }) as ToolRunContext
const runnerMod = async () => import('../src/runner.js')

// 制造解计数（精确比 1.5）：v = 100 + 1/N → p = 3，GCI≈0
const COUNTS: Record<string, number> = { '8': 1000, '5': 3375, '3': 11390.625 }
const valueFor = (count: number) => 100 + 1 / count

const structuralArgs = {
  chain: 'structural' as const,
  step: '/tmp/beam.step',
  facesJson: '/tmp/beam.faces.json',
  material: { youngMPa: 210000, poisson: 0.3 },
  constraints: [{ groupName: 'fixed', kind: 'fixed' as const }],
  loads: [{ groupName: 'load', vectorN: [0, 0, -1000] }],
  elementSizesMm: [3, 5, 8],   // 乱序输入 — Python 侧排序粗→细
}

const cfdArgs = {
  chain: 'cfd' as const,
  lengthMm: 1000, widthMm: 20, heightMm: 20,
  inletVelocityMS: [0.02, 0, 0], kinematicViscosityM2S: 1e-6,
  cellSizesMm: [8, 5, 3], densityKgM3: 1000,
}

// ONE runStage('verify', ...) — the per-level mesh→solve→post loop now lives
// in the Python verify package; the mock mirrors its receipt: chain/metric
// echo plus a levels table sorted coarse→fine from the sizes argv.
beforeEach(async () => {
  const runner = await runnerMod()
  vi.mocked(runner.runStage).mockReset()
  vi.mocked(runner.runStage).mockImplementation(async (_cfg, stage, argv) => {
    if (stage !== 'verify') throw new Error(`unexpected stage ${stage}`)
    const flag = (name: string) => {
      const i = argv.indexOf(name)
      return i >= 0 ? argv[i + 1] : undefined
    }
    const sizes = String(flag('--element-sizes') ?? flag('--cell-sizes')).split(',').map(Number)
    const levels = [...sizes].sort((a, b) => b - a).map(size => ({
      sizeMm: size,
      count: COUNTS[String(size)] ?? 1000,
      metricValue: valueFor(COUNTS[String(size)] ?? 8000),
    }))
    return { receipt: { chain: argv[0], metric: flag('--metric'), levels }, logPath: '' }
  })
  vi.mocked(runner.ensureDeps).mockReset()
  vi.mocked(runner.ensureDeps).mockResolvedValue(undefined)
})

const verifyCall = async (): Promise<[{ workdir: string }, string, string[], {
  signal: AbortSignal; logFile: string; timeoutMs?: number
}]> => {
  const runner = await runnerMod()
  const calls = vi.mocked(runner.runStage).mock.calls.filter(([, s]) => s === 'verify')
  expect(calls).toHaveLength(1)
  return calls[0]!
}

describe('cae_verify validation', () => {
  it('rejects fewer than 3 sizes', async () => {
    const tool = defineCaeVerifyTool({ ...config, workdir: './w' })
    await expect(tool.execute({ ...structuralArgs, elementSizesMm: [8, 5] }, exec()))
      .rejects.toThrow('at least 3')
  })

  it('rejects non-monotonic sizes', async () => {
    const tool = defineCaeVerifyTool({ ...config, workdir: './w' })
    await expect(tool.execute({ ...structuralArgs, elementSizesMm: [8, 5, 8] }, exec()))
      .rejects.toThrow('strictly monotonic')
  })

  it('rejects a cfd-only metric on the structural chain', async () => {
    const tool = defineCaeVerifyTool({ ...config, workdir: './w' })
    await expect(tool.execute({ ...structuralArgs, metric: 'pressureDropPa' }, exec()))
      .rejects.toThrow('not available on chain=structural')
  })

  it('rejects a structural-only metric on the cfd chain', async () => {
    const tool = defineCaeVerifyTool({ ...config, workdir: './w' })
    await expect(tool.execute({ ...cfdArgs, metric: 'maxVonMises' }, exec()))
      .rejects.toThrow('not available on chain=cfd')
  })

  it('requires densityKgM3 when metric is pressureDropPa', async () => {
    const tool = defineCaeVerifyTool({ ...config, workdir: './w' })
    await expect(tool.execute({
      chain: 'cfd', lengthMm: 1000, widthMm: 20, heightMm: 20,
      inletVelocityMS: [0.02, 0, 0], kinematicViscosityM2S: 1e-6, cellSizesMm: [8, 5, 3],
      metric: 'pressureDropPa',
    }, exec())).rejects.toThrow('requires densityKgM3')
  })

  it('requires the structural branch inputs', async () => {
    const tool = defineCaeVerifyTool({ ...config, workdir: './w' })
    const { step: _step, ...noStep } = structuralArgs
    await expect(tool.execute(noStep, exec()))
      .rejects.toThrow('chain=structural needs step')
    await expect(tool.execute({ ...structuralArgs, constraints: [] }, exec()))
      .rejects.toThrow('at least one constraint')
    await expect(tool.execute({ ...structuralArgs, loads: [] }, exec()))
      .rejects.toThrow('at least one load')
  })

  it('requires the cfd branch inputs', async () => {
    const tool = defineCaeVerifyTool({ ...config, workdir: './w' })
    await expect(tool.execute({
      chain: 'cfd', widthMm: 20, heightMm: 20,
      inletVelocityMS: [0.02, 0, 0], kinematicViscosityM2S: 1e-6, cellSizesMm: [8, 5, 3],
    }, exec())).rejects.toThrow('chain=cfd needs lengthMm, widthMm, heightMm')
    await expect(tool.execute({
      chain: 'cfd', lengthMm: 1000, widthMm: 20, heightMm: 20, cellSizesMm: [8, 5, 3],
    }, exec())).rejects.toThrow('chain=cfd needs inletVelocityMS and kinematicViscosityM2S')
  })

  it("rejects cfd-branch params on chain='structural'", async () => {
    const tool = defineCaeVerifyTool({ ...config, workdir: './w' })
    await expect(tool.execute({ ...structuralArgs, lengthMm: 1000 }, exec()))
      .rejects.toThrow(`'lengthMm' belongs to chain='cfd'`)
    await expect(tool.execute({ ...structuralArgs, cellSizesMm: [8, 5, 3] }, exec()))
      .rejects.toThrow(`'cellSizesMm' belongs to chain='cfd'`)
  })

  it("rejects structural-branch params on chain='cfd'", async () => {
    const tool = defineCaeVerifyTool({ ...config, workdir: './w' })
    await expect(tool.execute({ ...cfdArgs, material: structuralArgs.material }, exec()))
      .rejects.toThrow(`'material' belongs to chain='structural'`)
    await expect(tool.execute({ ...cfdArgs, elementSizesMm: [8, 6, 4] }, exec()))
      .rejects.toThrow(`'elementSizesMm' belongs to chain='structural'`)
  })

  it('shape-guards material/constraints/loads before spawning any stage', async () => {
    const tool = defineCaeVerifyTool({ ...config, workdir: './w' })
    await expect(tool.execute({ ...structuralArgs, material: { poisson: 0.3 } }, exec()))
      .rejects.toThrow("'material' requires 'youngMPa' and 'poisson'")
    await expect(tool.execute({ ...structuralArgs, constraints: [{ kind: 'fixed' }] }, exec()))
      .rejects.toThrow("each constraint requires a 'groupName'")
    await expect(tool.execute({ ...structuralArgs, loads: [{ groupName: 'load', vectorN: [0, -1] }] }, exec()))
      .rejects.toThrow('load vectorN must be [fx, fy, fz]')
    // kind is enum-guarded at the schema layer already; execute()'s own guard
    // is defense-in-depth for in-process callers of the same checks.
    await expect(tool.execute({
      ...structuralArgs, constraints: [{ groupName: 'fixed', kind: 'pinned' as never }],
    }, exec())).rejects.toThrow('kind')
    const runner = await runnerMod()
    expect(vi.mocked(runner.runStage)).not.toHaveBeenCalled()
  })
})

describe('cae_verify structural study', () => {
  it('runs exactly ONE verify stage with loop argv and the N×3 timeout multiplier', async () => {
    const tool = defineCaeVerifyTool(config)
    await tool.execute({ ...structuralArgs }, exec())
    const [, stage, argv, opts] = await verifyCall()
    expect(stage).toBe('verify')
    expect(argv[0]).toBe('structural')
    expect(argv[argv.indexOf('--step') + 1]).toBe('/tmp/beam.step')
    expect(argv[argv.indexOf('--faces-json') + 1]).toBe('/tmp/beam.faces.json')
    // the list goes over as-given; Python's study sorts coarse→fine
    expect(argv[argv.indexOf('--element-sizes') + 1]).toBe('3,5,8')
    expect(argv[argv.indexOf('--young-mpa') + 1]).toBe('210000')
    expect(argv[argv.indexOf('--poisson') + 1]).toBe('0.3')
    expect(argv[argv.indexOf('--fixed-group') + 1]).toBe('fixed')
    expect(argv[argv.indexOf('--load-group') + 1]).toBe('load')
    // '=' form: a plain '--load-n -1000,0,0' would be eaten as an option flag
    expect(argv).toContain('--load-n=0,0,-1000')
    expect(argv.filter(a => a === '--load-n')).toHaveLength(0)
    expect(argv[argv.indexOf('--metric') + 1]).toBe('maxVonMises')
    expect(argv[argv.indexOf('--workdir') + 1]).toBe(resolve(config.workdir))
    expect(opts.logFile).toBe('verify.structural.log')
    // one process now shares what N stages previously got individually
    expect(opts.timeoutMs).toBe(config.stageTimeoutMs * structuralArgs.elementSizesMm.length * 3)
  })

  it('consumes the coarse→fine levels and reports the GCI study', async () => {
    const tool = defineCaeVerifyTool(config)
    const receipt = await tool.execute({ ...structuralArgs }, exec())
    expect(receipt.chain).toBe('structural')
    expect(receipt.metric).toBe('maxVonMises')
    expect(receipt.levels.map(l => l.sizeMm)).toEqual([8, 5, 3])
    expect(receipt.levels.map(l => l.count)).toEqual([1000, 3375, 11390.625])
    expect(receipt.convergenceState).toBe('monotonic')
    expect(receipt.observedOrder).toBeCloseTo(3, 3)
    expect(receipt.richardsonExtrapolated).toBeCloseTo(100, 6)
    expect(receipt.meshIndependent).toBe(true)
    expect(receipt.thresholdPercent).toBe(3)
    expect(receipt.recommendation).toContain('8')
  })

  it('checks the structural dependency group', async () => {
    const tool = defineCaeVerifyTool(config)
    await tool.execute({ ...structuralArgs }, exec())
    const runner = await runnerMod()
    expect(runner.ensureDeps).toHaveBeenLastCalledWith(expect.anything(), expect.anything(), 'structural')
  })
})

describe('cae_verify cfd study', () => {
  it('runs exactly ONE verify stage with the cfd loop argv', async () => {
    const tool = defineCaeVerifyTool(config)
    await tool.execute({ ...cfdArgs }, exec())
    const [, stage, argv, opts] = await verifyCall()
    expect(stage).toBe('verify')
    expect(argv[0]).toBe('cfd')
    expect(argv[argv.indexOf('--length-mm') + 1]).toBe('1000')
    expect(argv[argv.indexOf('--width-mm') + 1]).toBe('20')
    expect(argv[argv.indexOf('--height-mm') + 1]).toBe('20')
    expect(argv[argv.indexOf('--cell-sizes') + 1]).toBe('8,5,3')
    expect(argv[argv.indexOf('--wall-grading') + 1]).toBe('1')
    expect(argv[argv.indexOf('--velocity') + 1]).toBe('0.02,0,0')
    expect(argv[argv.indexOf('--nu') + 1]).toBe('0.000001')
    expect(argv[argv.indexOf('--rho') + 1]).toBe('1000')
    expect(argv[argv.indexOf('--metric') + 1]).toBe('maxVelocityMS')
    expect(argv[argv.indexOf('--workdir') + 1]).toBe(resolve(config.workdir))
    expect(opts.logFile).toBe('verify.cfd.log')
    expect(opts.timeoutMs).toBe(config.stageTimeoutMs * cfdArgs.cellSizesMm.length * 3)
  })

  it('reports the cfd receipt with its GCI study', async () => {
    const tool = defineCaeVerifyTool(config)
    const receipt = await tool.execute({ ...cfdArgs }, exec())
    expect(receipt.chain).toBe('cfd')
    expect(receipt.metric).toBe('maxVelocityMS')
    expect(receipt.levels.map(l => l.sizeMm)).toEqual([8, 5, 3])
    expect(receipt.observedOrder).toBeCloseTo(3, 3)
    expect(receipt.meshIndependent).toBe(true)
  })

  it('checks the cfd dependency group', async () => {
    const tool = defineCaeVerifyTool(config)
    await tool.execute({ ...cfdArgs }, exec())
    const runner = await runnerMod()
    expect(runner.ensureDeps).toHaveBeenLastCalledWith(expect.anything(), expect.anything(), 'cfd')
  })

  it('forwards --bashrc under the local runtime', async () => {
    const bashrc = '/opt/openfoam13/etc/bashrc'
    const tool = defineCaeVerifyTool({ ...config, openfoamBashrc: bashrc })
    await tool.execute({ ...cfdArgs }, exec())
    const [, , argv] = await verifyCall()
    expect(argv[argv.indexOf('--bashrc') + 1]).toBe(bashrc)
  })

  it('drops --bashrc under the docker runtime', async () => {
    const tool = defineCaeVerifyTool({
      ...config,
      python: 'docker://ghcr.io/daiyuhangsustc/dsh-cae:latest',
      openfoamBashrc: '/opt/openfoam13/etc/bashrc',
    })
    await tool.execute({ ...cfdArgs }, exec())
    const [, , argv] = await verifyCall()
    expect(argv).not.toContain('--bashrc')
  })
})

describe('level-table protocol guards', () => {
  it('rejects a receipt without levels', async () => {
    const runner = await runnerMod()
    vi.mocked(runner.runStage).mockResolvedValue({ receipt: {}, logPath: '' })
    const tool = defineCaeVerifyTool(config)
    await expect(tool.execute({ ...structuralArgs }, exec()))
      .rejects.toThrow('produced no levels')
  })

  it('rejects levels that are not strictly size-descending', async () => {
    const runner = await runnerMod()
    const levels = [8, 5, 3].map((size, i) => ({ sizeMm: size, count: 1000 * (i + 1), metricValue: 100 + i }))
    vi.mocked(runner.runStage).mockResolvedValue({
      receipt: { chain: 'structural', metric: 'maxVonMises', levels: [...levels].reverse() },
      logPath: '',
    })
    const tool = defineCaeVerifyTool(config)
    await expect(tool.execute({ ...structuralArgs }, exec()))
      .rejects.toThrow('strictly size-descending')
  })
})
