// tests/tools-solve.test.ts
import { mkdtemp, mkdir, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { afterAll, beforeEach, describe, expect, it, vi } from 'vitest'
import type { ToolRunContext } from '@deepseek-ai/dsh-tools'
import { defineCaeSolveTool } from '../src/tools/solve.ts'

vi.mock('../src/runner.js', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../src/runner.js')>()
  return { ...actual, ensureDeps: vi.fn(), runStage: vi.fn() }
})

const config = { python: 'python3', workdir: './cae-stub', stageTimeoutMs: 1000 } as const
const exec = () => ({ signal: new AbortController().signal }) as ToolRunContext

const runnerMod = async () => import('../src/runner.js')

const workdirs: string[] = []
// static writes <stem>.patch.inp under the workdir and the cfd branches write
// <stem>.overrides.json inside the case — './cae-stub' would pollute the repo
// root, so every fs-touching test takes a tracked tmp dir.
const workdir = async () => {
  const dir = await mkdtemp(join(tmpdir(), 'dsh-cae-solve-'))
  workdirs.push(dir)
  return dir
}
afterAll(async () => {
  await Promise.all(workdirs.map(d => rm(d, { recursive: true, force: true })))
})

beforeEach(async () => {
  const runner = await runnerMod()
  vi.mocked(runner.runStage).mockReset()
  vi.mocked(runner.runStage).mockResolvedValue({ receipt: { exitCode: 0 }, logPath: '/tmp/stub.log' })
  vi.mocked(runner.ensureDeps).mockReset()
  vi.mocked(runner.ensureDeps).mockResolvedValue(undefined)
})

const solveArgv = async () => {
  const runner = await runnerMod()
  const call = vi.mocked(runner.runStage).mock.calls.find(([, stage]) => stage === 'solve')
  expect(call).toBeDefined()
  return call![2]
}

const staticArgs = {
  mode: 'static' as const,
  msh: './beam.msh',
  material: { youngMPa: 210000, poisson: 0.3 },
  constraints: [{ groupName: 'fixed', kind: 'fixed' as const }],
  loads: [{ groupName: 'load', vectorN: [0, -100, 0] }],
}

const cfdBase = { inletVelocityMS: [0.02, 0, 0], kinematicViscosityM2S: 1e-6 } as const

describe('cae_solve static argv construction', () => {
  it("forwards ['static', ...] argv with constraints/loads flattened to --fixed-group/--load-group/--load-n", async () => {
    const work = await workdir()
    const tool = defineCaeSolveTool({ ...config, workdir: work })
    const value = await tool.execute({ ...staticArgs, case: 'case' }, exec())
    const argv = await solveArgv()
    expect(argv[0]).toBe('static')
    expect(argv[argv.indexOf('--msh') + 1]).toBe('./beam.msh')
    expect(argv[argv.indexOf('--case') + 1]).toBe(join(resolve(work), 'case'))
    expect(argv[argv.indexOf('--young-mpa') + 1]).toBe('210000')
    expect(argv[argv.indexOf('--poisson') + 1]).toBe('0.3')
    expect(argv[argv.indexOf('--fixed-group') + 1]).toBe('fixed')
    expect(argv[argv.indexOf('--load-group') + 1]).toBe('load')
    expect(argv[argv.indexOf('--load-n') + 1]).toBe('0,-100,0')
    expect(value).toEqual({ mode: 'static', exitCode: 0 })
  })

  it('keeps multiple constraints and loads in call order', async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await tool.execute({
      ...staticArgs,
      constraints: [
        { groupName: 'fixed', kind: 'fixed' },
        { groupName: 'guide', kind: 'fixed' },
      ],
      loads: [{ groupName: 'load', vectorN: [0, -100, 0] }, { groupName: 'side', vectorN: [-5, 0, 0] }],
    }, exec())
    const argv = await solveArgv()
    expect(argv.filter(a => a === '--fixed-group').length).toBe(2)
    expect(argv[argv.indexOf('--fixed-group') + 1]).toBe('fixed')
    expect(argv[argv.indexOf('--fixed-group', argv.indexOf('--fixed-group') + 1) + 1]).toBe('guide')
    expect(argv[argv.indexOf('--load-n', argv.indexOf('--load-n') + 1) + 1]).toBe('-5,0,0')
  })

  it('writes script text to <stem>.patch.inp and forwards --script-file', async () => {
    const work = await workdir()
    const tool = defineCaeSolveTool({ ...config, workdir: work })
    const script = '*NSET, NSET=EXTRA\n1, 2\n'
    await tool.execute({ ...staticArgs, script }, exec())
    const argv = await solveArgv()
    const scriptFile = argv[argv.indexOf('--script-file') + 1]
    expect(scriptFile).toBe(join(resolve(work), 'case.patch.inp'))
    expect(await readFile(scriptFile, 'utf8')).toBe(script)
  })
})

describe('cae_solve static validation', () => {
  it('rejects a load vectorN that is not [fx, fy, fz]', async () => {
    // A 2-vector would reach static.py's `fx, fy, fz` unpack as a ValueError —
    // not a StageError, so the runner would misread it as an infrastructure
    // failure. The boundary must reject it first.
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({
      ...staticArgs, loads: [{ groupName: 'load', vectorN: [0, -100] }],
    }, exec())).rejects.toThrow('load vectorN must be [fx, fy, fz]')
  })
})

describe('cae_solve steady argv construction', () => {
  it("forwards ['steady', ...] argv with velocity/nu/rho/iterations and the case stem", async () => {
    const work = await workdir()
    const caseDir = join(work, 'cfd', 'duct')
    await mkdir(caseDir, { recursive: true })
    const tool = defineCaeSolveTool({ ...config, workdir: work })
    const value = await tool.execute({
      mode: 'steady', caseDir, ...cfdBase, densityKgM3: 1000, iterations: 300, case: 'run',
    }, exec())
    const argv = await solveArgv()
    expect(argv[0]).toBe('steady')
    expect(argv[argv.indexOf('--case-dir') + 1]).toBe(caseDir)
    expect(argv[argv.indexOf('--velocity') + 1]).toBe('0.02,0,0')
    expect(argv[argv.indexOf('--nu') + 1]).toBe('0.000001')
    expect(argv[argv.indexOf('--rho') + 1]).toBe('1000')
    expect(argv[argv.indexOf('--iterations') + 1]).toBe('300')
    expect(argv[argv.indexOf('--case') + 1]).toBe('run')
    expect(argv).not.toContain('--overrides-file')
    expect(value).toEqual({ mode: 'steady', exitCode: 0 })
  })

  it('writes overrides JSON into the case and forwards --overrides-file', async () => {
    const work = await workdir()
    const caseDir = join(work, 'cfd', 'duct')
    await mkdir(caseDir, { recursive: true })
    const tool = defineCaeSolveTool({ ...config, workdir: work })
    const overrides = [{ file: 'system/fvSolution', entry: 'SIMPLE', dict: 'SIMPLE { nNonOrthogonalCorrectors 0; }' }]
    await tool.execute({
      mode: 'steady', caseDir, ...cfdBase, overrides, case: 'run',
    }, exec())
    const argv = await solveArgv()
    const ovrFile = argv[argv.indexOf('--overrides-file') + 1]
    expect(ovrFile).toBe(join(caseDir, 'run.overrides.json'))
    expect(JSON.parse(await readFile(ovrFile, 'utf8'))).toEqual(overrides)
    // density defaults to 1 when not given
    expect(argv[argv.indexOf('--rho') + 1]).toBe('1')
  })
})

describe('cae_solve steady validation', () => {
  it('rejects inletVelocityMS that is not [u, v, w]', async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({
      mode: 'steady', caseDir: './cae/cfd/duct', inletVelocityMS: [0.02], kinematicViscosityM2S: 1e-6,
    }, exec())).rejects.toThrow('inletVelocityMS must be [u, v, w]')
  })

  it('rejects non-positive iterations', async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({
      mode: 'steady', caseDir: './cae/cfd/duct', ...cfdBase, iterations: 0,
    }, exec())).rejects.toThrow('iterations must be a positive integer')
  })

  it('rejects a case stem with path separators', async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({
      mode: 'steady', caseDir: './cae/cfd/duct', ...cfdBase, case: 'a/b',
    }, exec())).rejects.toThrow('path separators')
  })

  it('rejects a non-existent caseDir before writing overrides or spawning a stage', async () => {
    const missing = './cae/cfd/no-such-case'
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({
      mode: 'steady', caseDir: missing, ...cfdBase,
      overrides: [{ file: 'system/controlDict', entry: 'endTime', dict: 'endTime 5;' }],
    }, exec())).rejects.toThrow(`caseDir '${resolve(missing)}' does not exist`)
  })
})

describe('cae_solve transient argv construction', () => {
  it("forwards ['transient', ...] argv with endTime/writeInterval/maxCo and no fixed deltaT", async () => {
    const work = await workdir()
    const caseDir = join(work, 'cfd', 'duct')
    await mkdir(caseDir, { recursive: true })
    const tool = defineCaeSolveTool({ ...config, workdir: work })
    const value = await tool.execute({
      mode: 'transient', caseDir, ...cfdBase,
      endTimeS: 2, writeIntervalS: 0.1, densityKgM3: 1000,
    }, exec())
    const argv = await solveArgv()
    expect(argv[0]).toBe('transient')
    expect(argv[argv.indexOf('--end-time-s') + 1]).toBe('2')
    expect(argv[argv.indexOf('--write-interval-s') + 1]).toBe('0.1')
    expect(argv[argv.indexOf('--max-co') + 1]).toBe('0.5')
    expect(argv).not.toContain('--delta-t')
    expect(value).toEqual({ mode: 'transient', exitCode: 0 })
  })

  it('forwards --delta-t when a fixed step is given', async () => {
    const work = await workdir()
    const caseDir = join(work, 'cfd', 'duct')
    await mkdir(caseDir, { recursive: true })
    const tool = defineCaeSolveTool({ ...config, workdir: work })
    await tool.execute({
      mode: 'transient', caseDir, ...cfdBase, endTimeS: 0.02, writeIntervalS: 0.02, deltaTS: 0.001,
    }, exec())
    const argv = await solveArgv()
    expect(argv[argv.indexOf('--delta-t') + 1]).toBe('0.001')
  })
})

describe('cae_solve transient validation', () => {
  it('rejects inletVelocityMS that is not [u, v, w]', async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({
      mode: 'transient', caseDir: './c', inletVelocityMS: [1], kinematicViscosityM2S: 1e-6,
      endTimeS: 1, writeIntervalS: 0.1,
    }, exec())).rejects.toThrow('inletVelocityMS must be [u, v, w]')
  })

  it('rejects non-positive endTimeS', async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({
      mode: 'transient', caseDir: './c', ...cfdBase, endTimeS: 0, writeIntervalS: 0.1,
    }, exec())).rejects.toThrow('endTimeS must be a positive number')
  })

  it('rejects writeIntervalS greater than endTimeS', async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({
      mode: 'transient', caseDir: './c', ...cfdBase, endTimeS: 0.1, writeIntervalS: 0.2,
    }, exec())).rejects.toThrow('writeIntervalS must be in (0, endTimeS]')
  })

  it('rejects a writeIntervalS that does not divide endTimeS evenly', async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({
      mode: 'transient', caseDir: './c', ...cfdBase, endTimeS: 1, writeIntervalS: 0.3,
    }, exec())).rejects.toThrow('does not divide endTimeS')
  })

  it('accepts a writeIntervalS that divides endTimeS evenly', async () => {
    const work = await workdir()
    const caseDir = join(work, 'cfd', 'duct')
    await mkdir(caseDir, { recursive: true })
    const tool = defineCaeSolveTool({ ...config, workdir: work })
    await tool.execute({
      mode: 'transient', caseDir, ...cfdBase, endTimeS: 1, writeIntervalS: 0.25,
    }, exec())
    const argv = await solveArgv()
    expect(argv[argv.indexOf('--write-interval-s') + 1]).toBe('0.25')
  })

  it('rejects maxCourant <= 0 when deltaTS is not fixing the step', async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({
      mode: 'transient', caseDir: './c', ...cfdBase, endTimeS: 1, writeIntervalS: 0.1, maxCourant: 0,
    }, exec())).rejects.toThrow('maxCourant must be positive when deltaTS is not set')
  })

  it('rejects a case stem with path separators', async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({
      mode: 'transient', caseDir: './c', ...cfdBase, endTimeS: 1, writeIntervalS: 0.1, case: 'a/b',
    }, exec())).rejects.toThrow('path separators')
  })

  it('rejects a non-existent caseDir before spawning a stage', async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({
      mode: 'transient', caseDir: './no-such-case', ...cfdBase, endTimeS: 1, writeIntervalS: 0.1,
    }, exec())).rejects.toThrow('does not exist')
  })
})

describe('cae_solve cross-validation', () => {
  it("throws on static mode without msh/material/constraints/loads", async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({ mode: 'static' }, exec()))
      .rejects.toThrow("mode='static' requires 'msh', 'material', 'constraints' and 'loads'")
  })

  it('throws on static mode with empty constraints or loads', async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({ ...staticArgs, constraints: [] }, exec()))
      .rejects.toThrow("mode='static' requires 'msh', 'material', 'constraints' and 'loads'")
    await expect(tool.execute({ ...staticArgs, loads: [] }, exec()))
      .rejects.toThrow("mode='static' requires 'msh', 'material', 'constraints' and 'loads'")
  })

  it("throws on steady mode without caseDir/velocity/nu", async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({ mode: 'steady' }, exec()))
      .rejects.toThrow("mode='steady' requires 'caseDir', 'inletVelocityMS' and 'kinematicViscosityM2S'")
  })

  it("throws on transient mode without endTimeS/writeIntervalS", async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({ mode: 'transient' }, exec()))
      .rejects.toThrow(
        "mode='transient' requires 'caseDir', 'inletVelocityMS', 'kinematicViscosityM2S', 'endTimeS' and 'writeIntervalS'")
    await expect(tool.execute({ mode: 'transient', caseDir: './c', ...cfdBase, endTimeS: 1 }, exec()))
      .rejects.toThrow(
        "mode='transient' requires 'caseDir', 'inletVelocityMS', 'kinematicViscosityM2S', 'endTimeS' and 'writeIntervalS'")
  })

  it("throws on static mode given a cfd-only param", async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({ ...staticArgs, caseDir: './c' }, exec()))
      .rejects.toThrow("'caseDir' belongs to mode='steady'|'transient'")
    await expect(tool.execute({ ...staticArgs, iterations: 5 }, exec()))
      .rejects.toThrow("'iterations' belongs to mode='steady'")
  })

  it("throws on steady mode given a static- or transient-only param", async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({ mode: 'steady', caseDir: './c', ...cfdBase, msh: 'x.msh' }, exec()))
      .rejects.toThrow("'msh' belongs to mode='static'")
    await expect(tool.execute({ mode: 'steady', caseDir: './c', ...cfdBase, endTimeS: 1 }, exec()))
      .rejects.toThrow("'endTimeS' belongs to mode='transient'")
  })

  it("throws on transient mode given a static- or steady-only param", async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({
      mode: 'transient', caseDir: './c', ...cfdBase, endTimeS: 1, writeIntervalS: 0.1, material: staticArgs.material,
    }, exec())).rejects.toThrow("'material' belongs to mode='static'")
    await expect(tool.execute({
      mode: 'transient', caseDir: './c', ...cfdBase, endTimeS: 1, writeIntervalS: 0.1, iterations: 5,
    }, exec())).rejects.toThrow("'iterations' belongs to mode='steady'")
  })
})

describe('dependency groups', () => {
  it('checks structural for static and cfd for steady/transient', async () => {
    const runner = await runnerMod()
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir() })
    await tool.execute({ ...staticArgs }, exec())
    expect(runner.ensureDeps).toHaveBeenLastCalledWith(expect.anything(), expect.anything(), 'structural')

    const work = await workdir()
    const caseDir = join(work, 'cfd', 'duct')
    await mkdir(caseDir, { recursive: true })
    await tool.execute({ mode: 'steady', caseDir, ...cfdBase }, exec())
    expect(runner.ensureDeps).toHaveBeenLastCalledWith(expect.anything(), expect.anything(), 'cfd')
    await tool.execute({ mode: 'transient', caseDir, ...cfdBase, endTimeS: 1, writeIntervalS: 0.1 }, exec())
    expect(runner.ensureDeps).toHaveBeenLastCalledWith(expect.anything(), expect.anything(), 'cfd')
  })
})

// --bashrc forwarding vs runtime: a host OpenFOAM bashrc path cannot exist
// inside the container, so the docker runtime must drop it (the image's own
// OpenFOAM is auto-detected). runStage is mocked at the module boundary —
// what matters here is the argv the tool builds, not the subprocess.
describe('openfoamBashrc forwarding', () => {
  const hostBashrc = '/opt/openfoam11/etc/bashrc'
  const dockerConfig = { python: 'docker://ghcr.io/daiyuhangsustc/dsh-cae:latest', openfoamBashrc: hostBashrc }

  const cfdCaseDir = async () => {
    const work = await workdir()
    const caseDir = join(work, 'cfd', 'duct')
    await mkdir(caseDir, { recursive: true })
    return caseDir
  }

  it('forwards --bashrc to the steady branch under the local runtime', async () => {
    const caseDir = await cfdCaseDir()
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir(), openfoamBashrc: hostBashrc })
    await tool.execute({ mode: 'steady', caseDir, ...cfdBase }, exec())
    const argv = await solveArgv()
    expect(argv[argv.indexOf('--bashrc') + 1]).toBe(hostBashrc)
  })

  it('drops --bashrc from the steady branch under the docker runtime', async () => {
    const caseDir = await cfdCaseDir()
    const tool = defineCaeSolveTool({ ...config, ...dockerConfig, workdir: await workdir() })
    await tool.execute({ mode: 'steady', caseDir, ...cfdBase }, exec())
    const argv = await solveArgv()
    expect(argv).not.toContain('--bashrc')
  })

  it('drops --bashrc from the transient branch under the docker runtime', async () => {
    const caseDir = await cfdCaseDir()
    const tool = defineCaeSolveTool({ ...config, ...dockerConfig, workdir: await workdir() })
    await tool.execute({ mode: 'transient', caseDir, ...cfdBase, endTimeS: 1, writeIntervalS: 0.1 }, exec())
    const argv = await solveArgv()
    expect(argv).not.toContain('--bashrc')
  })

  it('never forwards --bashrc from the static branch', async () => {
    const tool = defineCaeSolveTool({ ...config, workdir: await workdir(), openfoamBashrc: hostBashrc })
    await tool.execute({ ...staticArgs }, exec())
    const argv = await solveArgv()
    expect(argv).not.toContain('--bashrc')
  })
})
