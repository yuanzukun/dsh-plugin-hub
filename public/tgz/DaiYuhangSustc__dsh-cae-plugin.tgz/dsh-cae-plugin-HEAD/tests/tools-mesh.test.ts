// tests/tools-mesh.test.ts
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { afterAll, beforeEach, describe, expect, it, vi } from 'vitest'
import type { ToolRunContext } from '@deepseek-ai/dsh-tools'
import { defineCaeMeshTool } from '../src/tools/mesh.ts'

vi.mock('../src/runner.js', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../src/runner.js')>()
  return { ...actual, ensureDeps: vi.fn(), runStage: vi.fn() }
})

const config = { python: 'python3', workdir: './cae-stub', stageTimeoutMs: 1000 } as const
const exec = () => ({ signal: new AbortController().signal }) as ToolRunContext

const runnerMod = async () => import('../src/runner.js')

const workdirs: string[] = []
// execute() mkdirs <workdir>/cfd even with runStage mocked — './cae-stub'
// would pollute the repo root, so every test takes a tracked tmp dir.
const workdir = async () => {
  const dir = await mkdtemp(join(tmpdir(), 'dsh-cae-mesh-'))
  workdirs.push(dir)
  return dir
}
afterAll(async () => {
  await Promise.all(workdirs.map(d => rm(d, { recursive: true, force: true })))
})

beforeEach(async () => {
  const runner = await runnerMod()
  vi.mocked(runner.runStage).mockReset()
  vi.mocked(runner.runStage).mockResolvedValue({ receipt: { mshPath: '/x.msh' }, logPath: '/tmp/stub.log' })
  vi.mocked(runner.ensureDeps).mockReset()
  vi.mocked(runner.ensureDeps).mockResolvedValue(undefined)
})

const meshArgv = async () => {
  const runner = await runnerMod()
  const call = vi.mocked(runner.runStage).mock.calls.find(([, stage]) => stage === 'mesh')
  expect(call).toBeDefined()
  return call![2]
}

const ductArgs = { mode: 'fluid' as const, lengthMm: 1000, widthMm: 20, heightMm: 20, cellSizeMm: 2.5 }

describe('cae_mesh argv construction', () => {
  it("solid mode forwards ['solid', ...] argv with resolved artifact paths", async () => {
    const tool = defineCaeMeshTool({ ...config, workdir: await workdir() })
    const value = await tool.execute({
      mode: 'solid', step: './bracket.step', elementSizeMm: 4, elementType: 'tet4',
      minSizeMm: 0.5, maxSizeMm: 8,
    }, exec())
    const argv = await meshArgv()
    const stem = resolve('./bracket.step').replace(/\.step$/, '')
    expect(argv[0]).toBe('solid')
    expect(argv[argv.indexOf('--step') + 1]).toBe(`${stem}.step`)
    expect(argv[argv.indexOf('--msh') + 1]).toBe(`${stem}.msh`)
    expect(argv[argv.indexOf('--faces-json') + 1]).toBe(`${stem}.faces.json`)
    expect(argv[argv.indexOf('--element-size') + 1]).toBe('4')
    expect(argv[argv.indexOf('--element-type') + 1]).toBe('tet4')
    expect(argv[argv.indexOf('--min-size') + 1]).toBe('0.5')
    expect(argv[argv.indexOf('--max-size') + 1]).toBe('8')
    expect(value).toEqual({ mode: 'solid', mshPath: '/x.msh' })
  })

  it('solid mode defaults element size/type and omits min/max size flags', async () => {
    const tool = defineCaeMeshTool({ ...config, workdir: await workdir() })
    await tool.execute({ mode: 'solid', step: '/tmp/x.step' }, exec())
    const argv = await meshArgv()
    expect(argv[argv.indexOf('--element-size') + 1]).toBe('2')
    expect(argv[argv.indexOf('--element-type') + 1]).toBe('tet10')
    expect(argv).not.toContain('--min-size')
    expect(argv).not.toContain('--max-size')
  })

  it("fluid mode forwards ['fluid', ...] argv with resolved workdir and mm dims", async () => {
    const work = await workdir()
    const tool = defineCaeMeshTool({ ...config, workdir: work })
    const value = await tool.execute({ ...ductArgs, wallGrading: 4 }, exec())
    const argv = await meshArgv()
    expect(argv[0]).toBe('fluid')
    expect(argv[argv.indexOf('--workdir') + 1]).toBe(resolve(work))
    expect(argv[argv.indexOf('--name') + 1]).toBe('duct')
    expect(argv[argv.indexOf('--length-mm') + 1]).toBe('1000')
    expect(argv[argv.indexOf('--width-mm') + 1]).toBe('20')
    expect(argv[argv.indexOf('--height-mm') + 1]).toBe('20')
    expect(argv[argv.indexOf('--cell-size-mm') + 1]).toBe('2.5')
    expect(argv[argv.indexOf('--wall-grading') + 1]).toBe('4')
    expect(argv).not.toContain('--block-mesh-dict-file')
    expect(argv).not.toContain('--bashrc')
    expect(value).toEqual({ mode: 'fluid', mshPath: '/x.msh' })
  })

  it('fluid mode writes blockMeshDict text to a file and forwards its path', async () => {
    const work = await workdir()
    const tool = defineCaeMeshTool({ ...config, workdir: work })
    await tool.execute({ ...ductArgs, name: 'custom', blockMeshDict: 'convertToMeters 1;\n' }, exec())
    const argv = await meshArgv()
    const dictFile = argv[argv.indexOf('--block-mesh-dict-file') + 1]
    expect(dictFile).toBe(join(work, 'cfd', 'custom.blockMeshDict.txt'))
    expect(await readFile(dictFile, 'utf8')).toBe('convertToMeters 1;\n')
  })

  it('checks the structural dep group for solid and the cfd group for fluid', async () => {
    const runner = await runnerMod()
    const tool = defineCaeMeshTool({ ...config, workdir: await workdir() })
    await tool.execute({ mode: 'solid', step: '/tmp/x.step' }, exec())
    expect(runner.ensureDeps).toHaveBeenLastCalledWith(expect.anything(), expect.anything(), 'structural')
    await tool.execute({ ...ductArgs }, exec())
    expect(runner.ensureDeps).toHaveBeenLastCalledWith(expect.anything(), expect.anything(), 'cfd')
  })
})

describe('cae_mesh cross-validation', () => {
  it("throws on solid mode without 'step'", async () => {
    const tool = defineCaeMeshTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({ mode: 'solid' }, exec()))
      .rejects.toThrow("mode='solid' requires 'step'")
  })

  it('throws on fluid mode without the duct dims', async () => {
    const tool = defineCaeMeshTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({ mode: 'fluid' }, exec()))
      .rejects.toThrow("mode='fluid' requires 'lengthMm', 'widthMm', 'heightMm' and 'cellSizeMm'")
  })

  it("throws on solid mode given a fluid-only param", async () => {
    const tool = defineCaeMeshTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({ mode: 'solid', step: './x.step', cellSizeMm: 2 }, exec()))
      .rejects.toThrow("'cellSizeMm' belongs to mode='fluid'")
  })

  it("throws on fluid mode given a solid-only param", async () => {
    const tool = defineCaeMeshTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({ ...ductArgs, elementSizeMm: 2 }, exec()))
      .rejects.toThrow("'elementSizeMm' belongs to mode='solid'")
  })
})

describe('cae_mesh fluid validation', () => {
  it('rejects a case name with path separators before starting Python', async () => {
    const tool = defineCaeMeshTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({ ...ductArgs, name: '../escape' }, exec()))
      .rejects.toThrow('must be a plain directory name')
  })
})

// --bashrc forwarding vs runtime: a host OpenFOAM bashrc path cannot exist
// inside the container, so the docker runtime must drop it (the image's own
// OpenFOAM is auto-detected). runStage is mocked at the module boundary —
// what matters here is the argv the tool builds, not the subprocess.
describe('openfoamBashrc forwarding', () => {
  const hostBashrc = '/opt/openfoam11/etc/bashrc'
  const dockerConfig = { python: 'docker://ghcr.io/daiyuhangsustc/dsh-cae:latest', openfoamBashrc: hostBashrc }

  it('forwards --bashrc to the mesh stage under the local runtime', async () => {
    const tool = defineCaeMeshTool({ ...config, workdir: await workdir(), openfoamBashrc: hostBashrc })
    await tool.execute({ ...ductArgs }, exec())
    const argv = await meshArgv()
    expect(argv[argv.indexOf('--bashrc') + 1]).toBe(hostBashrc)
  })

  it('drops --bashrc under the docker runtime', async () => {
    const tool = defineCaeMeshTool({ ...config, ...dockerConfig, workdir: await workdir() })
    await tool.execute({ ...ductArgs }, exec())
    const argv = await meshArgv()
    expect(argv).not.toContain('--bashrc')
  })
})
