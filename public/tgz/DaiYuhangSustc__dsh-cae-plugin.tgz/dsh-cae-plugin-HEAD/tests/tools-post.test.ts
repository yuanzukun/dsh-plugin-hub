// tests/tools-post.test.ts
import { resolve } from 'node:path'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import type { ToolRunContext } from '@deepseek-ai/dsh-tools'
import { defineCaePostTool } from '../src/tools/post.ts'

vi.mock('../src/runner.js', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../src/runner.js')>()
  return { ...actual, ensureDeps: vi.fn(), runStage: vi.fn() }
})

const config = { python: 'python3', workdir: './cae-stub', stageTimeoutMs: 1000 } as const
const exec = () => ({ signal: new AbortController().signal }) as ToolRunContext

const runnerMod = async () => import('../src/runner.js')

beforeEach(async () => {
  const runner = await runnerMod()
  vi.mocked(runner.runStage).mockReset()
  vi.mocked(runner.runStage).mockResolvedValue({ receipt: { values: [], plots: [] }, logPath: '/tmp/stub.log' })
  vi.mocked(runner.ensureDeps).mockReset()
  vi.mocked(runner.ensureDeps).mockResolvedValue(undefined)
})

const postArgv = async () => {
  const runner = await runnerMod()
  const call = vi.mocked(runner.runStage).mock.calls.find(([, stage]) => stage === 'post')
  expect(call).toBeDefined()
  return call![2]
}

describe('cae_post argv construction', () => {
  it("forwards --vtu/--max/--probe/--plot with --density-kg-m3 and the vtu-derived --png-stem", async () => {
    const tool = defineCaePostTool(config)
    await tool.execute({
      vtu: './case.vtu',
      maxima: [{ field: 'vonMises' }],
      probes: [{ field: 'displacement', point: [10, 0, 0] }],
      plots: [{ field: 'vonMises' }],
      densityKgM3: 1000,
    }, exec())
    const argv = await postArgv()
    expect(argv[argv.indexOf('--vtu') + 1]).toBe(resolve('./case.vtu'))
    expect(argv[argv.indexOf('--max') + 1]).toBe('vonMises')
    expect(argv[argv.indexOf('--probe') + 1]).toBe('displacement,10,0,0')
    expect(argv[argv.indexOf('--plot') + 1]).toBe('vonMises')
    expect(argv[argv.indexOf('--density-kg-m3') + 1]).toBe('1000')
    expect(argv[argv.indexOf('--png-stem') + 1]).toBe(resolve('./case.vtu').replace(/\.vtu$/, ''))
  })

  it('derives --png-stem from frd and omits --density-kg-m3 when not given', async () => {
    const tool = defineCaePostTool(config)
    await tool.execute({ frd: './case.frd' }, exec())
    const argv = await postArgv()
    expect(argv[argv.indexOf('--frd') + 1]).toBe(resolve('./case.frd'))
    expect(argv).not.toContain('--vtu')
    expect(argv).not.toContain('--density-kg-m3')
    expect(argv[argv.indexOf('--png-stem') + 1]).toBe(resolve('./case.frd').replace(/\.frd$/, ''))
  })
})

describe('cae_post input validation', () => {
  it('rejects when both vtu and frd are given, without starting Python', async () => {
    const post = defineCaePostTool(config)
    await expect(post.execute(
      { vtu: 'case.vtu', frd: 'case.frd' },
      exec(),
    )).rejects.toThrow('provide either vtu or frd, not both')
  })

  it('rejects when neither vtu nor frd is given', async () => {
    const post = defineCaePostTool(config)
    await expect(post.execute({}, exec())).rejects.toThrow('provide either vtu or frd')
  })
})

describe('cae_post CFD fields', () => {
  it('rejects probes using the old pointMm key', async () => {
    const post = defineCaePostTool(config)
    await expect(post.execute(
      { vtu: 'duct.vtk', probes: [{ field: 'velocity', pointMm: [1, 2, 3] } as never] },
      exec(),
    )).rejects.toThrow()
  })
})
