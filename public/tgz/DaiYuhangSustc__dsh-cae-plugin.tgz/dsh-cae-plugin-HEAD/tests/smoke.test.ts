// tests/smoke.test.ts
import { describe, expect, it } from 'vitest'
import type { Context } from '@deepseek-ai/cordis'
import { apply, Config, inject, name } from '../src/index.ts'

describe('dsh-cae plugin entry', () => {
  it('exports loader metadata with function-plugin shape', () => {
    expect(name).toBe('dsh-cae')
    expect(inject).toEqual(['tools'])
  })
  it('Config schema carries the three deployment fields with defaults', () => {
    expect(Config.meta).toBeDefined()
  })
  it('registers exactly the final five-tool set', () => {
    const registered: { name: string }[] = []
    const ctx = { tools: { register: (tool: { name: string }) => { registered.push(tool) } } }
    apply(ctx as unknown as Context, { python: 'python3', workdir: './cae', stageTimeoutMs: 1000 })
    expect(registered.map(tool => tool.name)).toEqual(['cae_geometry', 'cae_mesh', 'cae_solve', 'cae_post', 'cae_verify'])
  })
})
