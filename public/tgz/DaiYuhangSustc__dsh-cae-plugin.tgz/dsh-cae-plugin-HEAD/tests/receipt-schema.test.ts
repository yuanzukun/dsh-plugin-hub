// tests/receipt-schema.test.ts
// Seam test between the Python receipts and the TS output schemas. Each fixture
// is hand-built to be FAITHFUL to the Python emit() call of its branch (source
// noted per fixture) and must validate against the tool's compiled output
// schema — the exact check the dsh-tools registry runs on every tool result
// (validateJsonSchemaValue(tool.output.schema, value); lib/index.js:3298).
// TS tests mock runStage and pytest never crosses the TS schema, so without
// this test a receipt the Python side really emits can be rejected by the
// tool's own schema at runtime (the v0.5.0 solid-branch connectivity/warnings
// regression this file pins).
import { describe, expect, it } from 'vitest'
import { validateJsonSchemaValue } from '@deepseek-ai/dsh-tools'
import { defineCaeGeometryTool } from '../src/tools/geometry.ts'
import { defineCaeMeshTool } from '../src/tools/mesh.ts'
import { defineCaeSolveTool } from '../src/tools/solve.ts'
import { defineCaePostTool } from '../src/tools/post.ts'
import { defineCaeVerifyTool } from '../src/tools/verify.ts'

const config = { python: 'python3', workdir: './cae-stub', stageTimeoutMs: 1000 } as const

const TOOLS = {
  cae_geometry: defineCaeGeometryTool(config),
  cae_mesh: defineCaeMeshTool(config),
  cae_solve: defineCaeSolveTool(config),
  cae_post: defineCaePostTool(config),
  cae_verify: defineCaeVerifyTool(config),
} as const

/** One branch receipt: what Python emits (+ the mode/chain key the TS layer adds). */
const FIXTURES: { tool: keyof typeof TOOLS; branch: string; source: string; receipt: unknown }[] = [
  {
    tool: 'cae_geometry', branch: 'build', source: 'python/dsh_cae/geometry/build.py:68 (+ mode from geometry.ts)',
    receipt: {
      mode: 'build',
      stepPath: '/work/parts/beam.step',
      volumeMm3: 10000.0,
      bboxMm: { min: [-50.0, -10.0, -2.5], max: [50.0, 10.0, 2.5] },
      namedFaces: [
        { name: 'fixed', areaMm2: 100.0, centroidMm: [-50.0, 0.0, 0.0] },
        { name: 'load', areaMm2: 100.0, centroidMm: [50.0, 0.0, 0.0] },
      ],
    },
  },
  {
    tool: 'cae_geometry', branch: 'import', source: 'python/dsh_cae/geometry/step_import.py:218 (+ mode from geometry.ts)',
    receipt: {
      mode: 'import',
      stepPath: '/work/bracket.step',
      stepOut: '/work/bracket_clean.step',
      repaired: true,
      repairedDelta: { facesBefore: 14, facesAfter: 10, mergeableFacesRemaining: 0 },
      checks: {
        solidCount: 1,
        faceCount: 10,
        invalidSolids: 0,
        freeEdges: false,
        sliverFaces: [{ id: 7, areaMm2: 0.0004 }],
        shortEdges: { count: 2, minLengthMm: 0.031, thresholdMm: 0.103 },
        mergeableFaces: 4,
        clean: false,
      },
      faces: [{ id: 1, areaMm2: 1000.0, centroidMm: [50.0, 10.0, 2.5], normal: [0.0, 0.0, 1.0] }],
      namedGroups: [{ name: 'fixed', faceIds: [1, 2] }],
      facesJsonPath: '/work/bracket_clean.faces.json',
    },
  },
  {
    // connectivity is ALWAYS emitted; warnings only when components > 1 — the
    // exact fields the v0.5.0 solid oneOf branch forgot to declare.
    tool: 'cae_mesh', branch: 'solid', source: 'python/dsh_cae/mesh/solid.py:89 (+ mode from mesh.ts)',
    receipt: {
      mode: 'solid',
      mshPath: '/work/parts/beam.msh',
      nodeCount: 4712,
      elementCount: 2834,
      groupNames: ['fixed', 'load', 'solid'],
      quality: { minJacobian: 0.31 },
      connectivity: { components: 2, totalElements: 2834, isolatedElements: 12 },
      warnings: [
        'mesh has 2 disconnected components (12 of 2834 elements outside the largest one); '
        + 'a downstream static solve will be singular unless every component is constrained or tied',
      ],
    },
  },
  {
    tool: 'cae_mesh', branch: 'fluid', source: 'python/dsh_cae/mesh/fluid.py:52 (+ mode from mesh.ts)',
    receipt: {
      mode: 'fluid',
      caseDir: '/work/cfd/duct',
      blockMeshDictPath: '/work/cfd/duct/system/blockMeshDict',
      boundsM: { min: [0.0, 0.0, 0.0], max: [0.6, 0.05, 0.02] },
      cells: 6000,
      maxNonOrthogonalityDeg: 0.0,
      maxAspectRatio: 1.5,
      checksPassed: true,
      checkMeshLogPath: '/work/cfd/duct/checkMesh.log',
      logTail: 'End\n',
    },
  },
  {
    tool: 'cae_solve', branch: 'static', source: 'python/dsh_cae/solve/static.py:141 (+ mode from solve.ts)',
    receipt: {
      mode: 'static',
      inpPath: '/work/case.inp',
      frdPath: '/work/case.frd',
      vtuPath: '/work/case.vtu',
      exitCode: 0,
      wallMs: 1840,
      logTail: 'Job finished\n',
    },
  },
  {
    tool: 'cae_solve', branch: 'steady', source: 'python/dsh_cae/solve/steady.py:65 (+ mode from solve.ts)',
    receipt: {
      mode: 'steady',
      caseDir: '/work/cfd/duct',
      logPath: '/work/cfd/duct/run.foam.log',
      vtkPath: '/work/cfd/duct/VTK/duct_1000.vtk',
      iterationsRun: 350,
      converged: true,
      finalResiduals: { p: 1.2e-6, U: 3.4e-7 },
      wallMs: 45678,
      exitCode: 0,
      logTail: 'SIMPLE solution converged in 350 iterations\n',
      densityKgM3: 1000,
    },
  },
  {
    tool: 'cae_solve', branch: 'transient', source: 'python/dsh_cae/solve/transient.py:88 (+ mode from solve.ts)',
    receipt: {
      mode: 'transient',
      caseDir: '/work/cfd/duct',
      logPath: '/work/cfd/duct/run.foam.log',
      vtkPath: '/work/cfd/duct/VTK/duct_2.0.vtk',
      timeStepsRun: 412,
      simTimeS: 2.0,
      endTimeS: 2.0,
      maxCourantSeen: 0.48,
      finalResiduals: { p: 2.0e-6, U: 5.0e-7 },
      wallMs: 90123,
      exitCode: 0,
      logTail: 'ExecutionTime = 87.2 s\n',
      densityKgM3: 1000,
    },
  },
  {
    tool: 'cae_post', branch: '(single)', source: 'python/dsh_cae/post/extract.py:145',
    receipt: {
      values: [
        { kind: 'max', field: 'displacement', value: 0.756, unit: 'mm', atMm: [50.0, 0.0, -0.75] },
        { kind: 'probe', field: 'pressure', value: 2.8, unit: 'Pa', atM: [0.0, 0.025, 0.01] },
      ],
      plots: [
        { field: 'vonMises', path: '/work/case.vonMises.png' },
        { field: 'displacement', path: null, error: 'ValueError: no displacement field' },
      ],
    },
  },
  {
    // verify/{structural,cfd}.py emit {chain, metric, levels}; solve's TS layer
    // appends the gci() study + recommendation — numbers below are the actual
    // gci() output for these levels, threshold 3.
    tool: 'cae_verify', branch: 'structural', source: 'python/dsh_cae/verify/structural.py:59 + src/gci.ts',
    receipt: {
      chain: 'structural',
      metric: 'maxVonMises',
      levels: [
        { sizeMm: 8, count: 1228, metricValue: 115.2 },
        { sizeMm: 6, count: 2896, metricValue: 117.8 },
        { sizeMm: 4, count: 9720, metricValue: 118.9 },
      ],
      refinementRatios: { r21: 1.4972324660382825, r32: 1.331067450825979 },
      convergenceState: 'monotonic',
      observedOrder: 3.6191456565032607,
      richardsonExtrapolated: 119.23240600082414,
      gciFinePercent: 0.3494596308075461,
      gciCoarsePercent: 1.5199554338117527,
      meshIndependent: true,
      thresholdPercent: 3,
      recommendation: '6 mm is already within 3% of the extrapolated metric; finer levels add cost, not accuracy',
    },
  },
]

describe('receipt↔schema seam (Python emit ↔ tool.output.schema)', () => {
  for (const { tool, branch, source, receipt } of FIXTURES) {
    it(`accepts the ${tool} ${branch} receipt (${source})`, () => {
      const violations = validateJsonSchemaValue(TOOLS[tool].output.schema, receipt)
      expect(violations, JSON.stringify(receipt, null, 2)).toEqual([])
    })
  }
})
