// tests/tools-geometry.test.ts
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { afterAll, beforeEach, describe, expect, it, vi } from 'vitest'
import type { ToolRunContext } from '@deepseek-ai/dsh-tools'
import { defineCaeGeometryTool } from '../src/tools/geometry.ts'

vi.mock('../src/runner.js', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../src/runner.js')>()
  return { ...actual, ensureDeps: vi.fn(), runStage: vi.fn() }
})

const config = { python: 'python3', workdir: './cae-stub', stageTimeoutMs: 1000 } as const
const exec = () => ({ signal: new AbortController().signal }) as ToolRunContext

const runnerMod = async () => import('../src/runner.js')

const workdirs: string[] = []
const workdir = async () => {
  const dir = await mkdtemp(join(tmpdir(), 'dsh-cae-geometry-'))
  workdirs.push(dir)
  return dir
}
afterAll(async () => {
  await Promise.all(workdirs.map(d => rm(d, { recursive: true, force: true })))
})

beforeEach(async () => {
  const runner = await runnerMod()
  vi.mocked(runner.runStage).mockReset()
  vi.mocked(runner.runStage).mockResolvedValue({ receipt: { stepPath: '/x.step' }, logPath: '/tmp/stub.log' })
  vi.mocked(runner.ensureDeps).mockResolvedValue(undefined)
})

const geometryArgv = async () => {
  const runner = await runnerMod()
  const call = vi.mocked(runner.runStage).mock.calls.find(([, stage]) => stage === 'geometry')
  expect(call).toBeDefined()
  return call![2]
}

describe('cae_geometry argv construction', () => {
  it("build mode forwards ['build', ...] argv with resolved artifact paths", async () => {
    const work = await workdir()
    const tool = defineCaeGeometryTool({ ...config, workdir: work })
    const value = await tool.execute({
      mode: 'build', name: 'it-beam',
      script: 'from build123d import Box\npart = Box(100, 20, 5)\n',
    }, exec())
    const argv = await geometryArgv()
    expect(argv[0]).toBe('build')
    expect(argv[argv.indexOf('--script-file') + 1]).toBe(join(work, 'it-beam.cad.py'))
    expect(argv[argv.indexOf('--step') + 1]).toBe(join(work, 'it-beam.step'))
    expect(argv[argv.indexOf('--faces-json') + 1]).toBe(join(work, 'it-beam.faces.json'))
    expect(value).toEqual({ mode: 'build', stepPath: '/x.step' })
  })

  it("import mode forwards ['import', ...] argv, resolving the step path and omitting repair by default", async () => {
    const tool = defineCaeGeometryTool({ ...config, workdir: await workdir() })
    const value = await tool.execute({ mode: 'import', step: './bracket.step' }, exec())
    const argv = await geometryArgv()
    expect(argv[0]).toBe('import')
    expect(argv[argv.indexOf('--step') + 1]).toBe(resolve('./bracket.step'))
    expect(argv).not.toContain('--repair')
    expect(argv).toContain('--faces-json')
    expect(value).toEqual({ mode: 'import', stepPath: '/x.step' })
  })

  it('import mode forwards repair and nameFaces as stage flags', async () => {
    const tool = defineCaeGeometryTool({ ...config, workdir: await workdir() })
    const facesJson = '/tmp/bracket.faces.json'
    await tool.execute({
      mode: 'import', step: '/tmp/bracket.step', repair: true, facesJson,
      nameFaces: [{ faceId: 2, name: 'fixed' }, { faceId: 3, name: 'load' }],
    }, exec())
    const argv = await geometryArgv()
    expect(argv[0]).toBe('import')
    expect(argv).toContain('--repair')
    const nf = argv[argv.indexOf('--name-faces') + 1]
    expect(JSON.parse(nf)).toEqual([{ faceId: 2, name: 'fixed' }, { faceId: 3, name: 'load' }])
    expect(argv[argv.indexOf('--faces-json') + 1]).toBe(facesJson)
  })
})

describe('cae_geometry cross-validation', () => {
  it("throws on build mode without 'script'", async () => {
    const tool = defineCaeGeometryTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({ mode: 'build' }, exec()))
      .rejects.toThrow("mode='build' requires 'script'")
  })

  it("throws on import mode without 'step'", async () => {
    const tool = defineCaeGeometryTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({ mode: 'import' }, exec()))
      .rejects.toThrow("mode='import' requires 'step'")
  })

  it("throws on build mode given an import-only param", async () => {
    const tool = defineCaeGeometryTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({ mode: 'build', script: 'part = 1', step: './x.step' }, exec()))
      .rejects.toThrow("'step' belongs to mode='import'")
  })

  it("throws on import mode given a build-only param", async () => {
    const tool = defineCaeGeometryTool({ ...config, workdir: await workdir() })
    await expect(tool.execute({ mode: 'import', step: './x.step', script: 'part = 1' }, exec()))
      .rejects.toThrow("'script' belongs to mode='build'")
  })
})
