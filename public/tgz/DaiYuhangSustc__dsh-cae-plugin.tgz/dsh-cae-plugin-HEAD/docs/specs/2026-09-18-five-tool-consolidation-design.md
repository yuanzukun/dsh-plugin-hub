# 九工具归并五工具设计（dsh-cae v0.4.0 → v0.5.0，破坏性重构）

日期：2026-09-18
状态：**已实施至 C7**（C0–C7 已提交；C8 验收运行待做）。批准的计划全文入库于 `docs/plans/2026-09-18-five-tool-consolidation.md`。

## 背景与目标

dsh-cae 是 DeepSeek cordis 插件（TS 编排层 + Python 领域层，子进程 argv + stdout marker receipt 通信），v0.4 对外注册 9 个工具。从第一性原理看，CAE 工作流的本质是**几何 → 网格 → 求解 → 后处理**四步，外加 GCI 验证这个横切关注点——工具过多使模型在 9 个名字里做无意义选择。本次破坏性归并为 **5 个工具**，内外边界一一对齐，并参考 `ai-native-template/` 的开发方式落地交接文件（spec 驱动、AGENTS.md 分层宪法、MODULES.md 登记表、feature_list.json + progress.md 跨会话交接、最小代码/YAGNI）。

已确认的决策：

- 5 工具：`cae_geometry` / `cae_mesh` / `cae_solve` / `cae_post` / `cae_verify`；Python 包同名（`dsh_cae.solve` 全面对称）
- 旧 9 个工具名全部移除，不留别名（文档/示例/测试同步改）
- **备份先行、原位新建**：旧插件文件整体移入 `backup/`，新代码在标准位置从零写成，领域逻辑对照 `backup/` 移植（警示注释逐字拷贝）
- verify 的逐层循环从 TS 下沉到 Python，TS 侧 schema 改为复用 mesh/solve 的导出片段
- 验收：vitest + pytest 全绿 + `examples/cantilever.md`（结构链）、`duct-flow.md`（CFD 链）端到端
- 明确不做（Deferred）：统一 case manifest、流体网格吃 STEP（snappyHexMesh）、新物理
- Git 提交不加 AI 署名尾注；提交信息用仓库现有 conventional 风格

## 目标形态

```
对模型暴露 5 工具        TS 编排层                 Python 领域层
cae_geometry ←──────→  src/tools/geometry.ts ←──→ dsh_cae/geometry/  (build | import)
cae_mesh     ←──────→  src/tools/mesh.ts     ←──→ dsh_cae/mesh/      (solid | fluid)
cae_solve    ←──────→  src/tools/solve.ts    ←──→ dsh_cae/solve/     (static | steady | transient)
cae_post     ←──────→  src/tools/post.ts     ←──→ dsh_cae/post/
cae_verify   ←──────→  src/tools/verify.ts   ←──→ dsh_cae/verify/    (chain: structural | cfd)
                                                   共享: dsh_cae/shared/{receipt,deps,cfd_case}.py
```

**分流参数**：geometry/mesh/solve 用 `mode`，verify 保留 `chain`；取值与 Python 子命令逐字相同：

| 工具 | 分流值 | 子进程形态 |
|---|---|---|
| cae_geometry | `mode: 'build' \| 'import'` | `python -m dsh_cae.geometry build ...` |
| cae_mesh | `mode: 'solid' \| 'fluid'` | `python -m dsh_cae.mesh fluid ...` |
| cae_solve | `mode: 'static' \| 'steady' \| 'transient'` | `python -m dsh_cae.solve steady ...` |
| cae_verify | `chain: 'structural' \| 'cfd'` | `python -m dsh_cae.verify cfd ...` |

## 九条关键设计决策

1. **schema 用纯对象组合，不引抽象层**。工具参数是 `@deepseek-ai/dsh-tools` 的 `ParameterSchemaSpec` 纯对象字面量（非 Schemastery；Schemastery 只用于 `src/config.ts`，不动）。各分支参数平铺、除 mode/chain 外全 optional。mesh.ts/solve.ts 导出属性级片段（`STEP_PARAM`、`MATERIAL_PARAM`、`DUCT_GEOMETRY_PARAMS`、`INLET_VELOCITY_PARAM`、`OVERRIDES_PARAM` 等，片段不带 `required`，拥有者用 `{ ...FRAG, required: true }` 补必填），verify.ts 展开组合。
2. **交叉校验只在 TS execute() 一层做一次**：mode 缺分支必填参数、传入了非本 mode 的参数（报 `'step' belongs to mode='import'` 而非静默忽略）、velocity 长度、endTimeS/writeInterval 整除等。Python argparse 只校验自己的 argv 完整性（pytest 直接驱动 CLI，是真实边界）。两层校验对象不同，不构成重复。
3. **receipt 协议零变化**：`<<<DSH_CAE_JSON>>>` marker、域失败=正常 receipt、stderr marker+exit 1 失败路径全部不变。`runStage` 签名不变，仅 opts 增可选 `timeoutMs`（verify 专用）；`ensureDeps` 的 stage 名 `'deps'` → `'shared.deps'`。
4. **receipt.py 的 `fail()` 改为 `raise StageError`**（打印 marker+exit 移到各包 `__main__.py` 分发器统一处理 `report_fail`）——外部可观测行为不变，但 verify 能逐层捕获加 `level i of N (size s mm):` 前缀再抛。fail-path pytest 用例保持通过即证明协议未破。
5. **领域函数只拆 verify 有真实进程内调用者的 5 处**：`mesh/solid.generate`、`mesh/fluid.generate`、`solve/static.solve`、`solve/steady.solve`、`post/extract`。geometry 两模块与 solve/transient 保持 main-only（第二个调用者出现再拆，YAGNI）。
6. **verify 形状统一到 solve**：v0.4 verify 的 `fixedGroups`/`loads[{group, forceN}]` 与 solve 的 `constraints[{groupName, kind}]`/`loads[{groupName, vectorN}]` 已经漂移，本次统一为后者，随 v0.5.0 破坏性发布；verify 不再接收 `caseDir`（各层 case 目录由 Python 自建）。GCI 数学留在 TS（`gci.ts` 原样），Python verify 的 receipt 只含 `{chain, metric, levels}`（levels 粗→细排序，写死并加断言），TS 计算研究量并沿用现 `VerifyMeshReceipt` 形状。
7. **超时预算**：verify 单进程共享一个超时，必须覆盖为 `config.stageTimeoutMs × sizes.length × 3`（每层 ~2 个 stage 工作量 + 余量；代码注释说明预算依据），否则多层 mesh+solve 必翻车。
8. **依赖方向 DAG（写进各包 AGENTS.md）**：`verify → {mesh, solve, post} → shared`；`geometry → shared`；禁止反向、禁止 verify 之外的兄弟包互调；fixtures 独立。
9. **deps 分组映射**：geometry（两种 mode）、mesh solid、solve static、post → structural；mesh fluid、solve steady/transient、verify 按链 → cfd。

## 文件映射（新文件 ← 对照 backup/ 移植来源）

### TS 层（src/）

| 旧 | 新 | 说明 |
|---|---|---|
| `src/index.ts` | 新写 | 注册 5 个工具；docstring "five stage tools" |
| `src/config.ts`、`src/interpreter.ts`、`src/gci.ts` | **不动** | |
| `src/runner.ts` | 两处小改 | `'deps'`→`'shared.deps'`；opts 加可选 `timeoutMs`（kill 定时器与超时报文两处都用） |
| `src/tools/cad.ts` + `step-import.ts` | `src/tools/geometry.ts` | description/schema/execute 合并 + mode 分派 |
| `src/tools/mesh.ts` + `cfd-mesh.ts` | `src/tools/mesh.ts` 重写 | solid/fluid 两分支；导出 schema 片段 |
| `src/tools/solve.ts` + `cfd-steady.ts` + `cfd-transient.ts` | `src/tools/solve.ts` 重写 | 三分支；OVERRIDE_FILES 常量收敛一份；导出片段 |
| `src/tools/post.ts` | 新写（内容照搬 backup） | 工具名 `cae_post`；description 旧名引用清除 |
| `src/tools/verify-mesh.ts` | `src/tools/verify.ts` | 删 runLevel argv 镜像，改单次 runStage + gci |

### Python 层（python/dsh_cae/）

| 旧 | 新 | 说明 |
|---|---|---|
| `receipt.py` | `shared/receipt.py` | 新增 `StageError`；`fail()` 改 raise，`report_fail` 收口在 `__main__` 分发器 |
| `deps.py` | `shared/deps.py` | `-m dsh_cae.shared.deps` |
| `cfd_case.py` | `shared/cfd_case.py` | 内容零改仅搬家（FoamFile 多行头等坑全在其中） |
| `cad.py` | `geometry/build.py` | `main(argv=None)` 化 |
| `step_import.py` | `geometry/step_import.py` | 同上（文件名避开 import 关键字） |
| `mesh.py` | `mesh/solid.py` | 拆 `generate(step, msh, *, faces_json=None, element_size=2.0, element_type='tet10', min_size=None, max_size=None) -> dict` |
| `cfd_mesh.py` | `mesh/fluid.py` | 拆 `generate(workdir, name, *, length_mm, width_mm, height_mm, cell_size_mm, wall_grading=1.0, block_mesh_dict_file=None, bashrc=None, timeout_s=600) -> dict` |
| `solve.py` | `solve/static.py` | 拆 `solve(...)`；负数 `--load-n` 的 `'='` argv 改写留在 main() |
| `cfd_steady.py` | `solve/steady.py` | 拆 `solve(case_dir, velocity, nu, *, rho=1.0, iterations=2000, overrides=None, case='run', bashrc=None, timeout_s=1800) -> dict` |
| `cfd_transient.py` | `solve/transient.py` | 仅 `main(argv=None)` 化，不拆函数 |
| `post.py` | `post/extract.py` | 拆 `extract(...) -> dict` |
| （新增） | `verify/structural.py`、`verify/cfd.py`、`verify/__main__.py` | 逐层循环，进程内调领域函数；CFD pressureDropPa 双 probe 逻辑（eps=size/2000）从 verify-mesh.ts 逐字移植 |
| （新增） | 各包 `__init__.py` + `__main__.py`、`shared/__init__.py` | 统一分发器模式（COMMANDS 字典 + StageError → report_fail） |
| `fixtures/`、`__init__.py` | 不动 | fixtures.fake_stage stage 名不变 |

`__main__.py` 分发器模式（五包统一）：COMMANDS 字典分发子命令，`StageError` 统一转 `report_fail`（stderr marker + exit 1）。叶子模块统一 `def main(argv: list[str] | None = None)`；不共享 parser、不做 subparsers 委托——每个叶子保留完整 argparse（它就是 CLI 边界文档），复用发生在领域函数层。

### 测试

- vitest 按新工具重组（文件名=工具名）：`tools-geometry` / `tools-mesh` / `tools-solve` / `tools-post` / `tools-verify`；`runner/interpreter/gci/smoke.test.ts`、`composition.e2e.ts` 不动（deps.test.ts 仅 stage 名改 `shared.deps`）；smoke 注册断言随每 commit 渐进 9→5。
- pytest 按包改名（stage 元组首参数=包名，conftest 的 `-m dsh_cae.{stage}` 模板天然兼容）：`test_geometry_build` / `test_geometry_import` / `test_mesh_solid` / `test_mesh_fluid` / `test_solve_static` / `test_solve_steady` / `test_solve_transient` / `test_shared_cfd_case`；`test_post`、`test_pipeline`、`test_cfd_pipeline`、`test_deps` 文件名不动仅改 stage 元组；新增 `test_verify.py`（真内核结构链 + CFD 链模块级 skip）。

### 文档与交接文件

- README×2 五工具表 + 六阶段映射改写；examples×2 调用链改名；package.json 0.5.0
- 根 `AGENTS.md`（精简宪法）、6 份包级 `AGENTS.md`（领域警示清单逐条有代码出处）、`MODULES.md`、`feature_list.json`（F-001~F-005）、`progress.md`、本设计文档

## 实施顺序（9 个原子 commit）

顺序原则：C0 一次性归档旧插件，随后从零新建——每个 commit 引入一个新组件及其测试，除 C0（归档后构建暂缺，commit message 注明 rebuild in progress）外每步全绿。新增行为（mode 交叉校验、verify 单阶段化）先写失败测试再实现；移植行为对照 `backup/` 拷贝，警示注释逐字。

| # | commit | 内容 | 绿色判据 |
|---|---|---|---|
| C0 | `chore: archive v0.4 plugin to backup/` | git mv 旧件 → backup/；package.json 0.5.0 | 无测试可跑（注明 rebuild in progress） |
| C1 | `feat: scaffold + cae_geometry` | src/ 脚手架 + geometry 两端 + 测试 | vitest+pytest 全绿 |
| C2 | `feat: cae_mesh` | mesh/{solid,fluid} + TS mesh.ts + 测试 | 全绿 |
| C3 | `feat: cae_solve` | solve/{static,steady,transient} + TS solve.ts + 测试 | 全绿 |
| C4 | `feat: cae_post` | post/extract.py + TS post.ts + 测试 | 全绿 |
| C5 | `feat: cae_verify` | python verify/ 三件 + TS verify.ts + 测试；smoke=5 | 全绿 |
| C6 | `docs: five-tool rewrite` | README×2、examples×2；旧名 grep 清零 | 全绿 |
| C7 | `docs: handoff files` | 根/包级 AGENTS.md、MODULES.md、feature_list.json、progress.md、设计文档 | 全绿 |
| C8 | `test: acceptance` | 内核环境全量 + 双示例链；feature_list 翻绿；progress.md 贴真实输出 | 验收记录 |

## Deferred（明确不做）

| 条目 | 暂缓原因 | 重新激活的触发条件 |
| --- | --- | --- |
| 统一 case manifest（结构/CFD 链共用一份 case 描述） | 当前 5 工具 receipt 传递已闭环，无重复出错记录 | 出现一次跨链参数漂移事故 |
| 流体网格直接消费 STEP（snappyHexMesh） | 现为参数化 blockMesh 管道，无外部几何 CFD 需求记录 | 用户提出真实外部几何 CFD 案例 |
| 新物理模型（湍流/传热/可压缩……） | 无需求证据；物理边界 README 已写明 | 用户明确提出且愿意承担验证成本 |

（另有 v0.4 时代改进清单 P2–P4 仍在开放，见 progress.md 遗留区。）
