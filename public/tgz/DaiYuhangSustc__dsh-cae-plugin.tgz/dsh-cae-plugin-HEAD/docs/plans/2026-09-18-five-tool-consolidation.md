# dsh-cae 九工具归并五工具（v0.4.0 → v0.5.0，破坏性重构）

> 来源：本文件是 2026-09-18 会话中批准的实施计划，内容未改；标点规范化为全角。**已执行**（C0–C7 已提交，C8 验收运行见 progress.md）；对应设计文档：`docs/specs/2026-09-18-five-tool-consolidation-design.md`。

## Context

dsh-cae 是 DeepSeek cordis 插件（TS 编排层 + Python 领域层，子进程 argv + stdout marker receipt 通信），目前对外注册 9 个工具。用户从第一性原理出发认为工具过多：CAE 工作流的本质是 **几何 → 网格 → 求解 → 后处理** 四步，外加 GCI 验证这个横切关注点。决定破坏性归并为 **5 个工具**，内外边界一一对齐，并参考 `ai-native-template/` 的开发方式落地交接文件（spec 驱动、AGENTS.md 分层宪法、MODULES.md 登记表、feature_list.json + progress.md 跨会话交接、最小代码/YAGNI）。

已确认的决策：
- 5 工具：`cae_geometry` / `cae_mesh` / `cae_solve` / `cae_post` / `cae_verify`；Python 包同名（`dsh_cae.solve` 全面对称）
- 旧 9 个工具名全部移除，不留别名（文档/示例/测试同步改）
- **备份先行、原位新建**（用户指定）：旧插件文件先整体移入 `backup/`，新代码在当前目录从零写成——工作区里除 `backup/` 外的源码文件全部是新产物，一眼可辨
- verify 的逐层循环从 TS 下沉到 Python，TS 侧 schema 改为复用 mesh/solve 的导出片段
- 验收：vitest+pytest 全绿 + `examples/cantilever.md`（结构链）、`duct-flow.md`（CFD 链）端到端
- 明确不做（登记 Deferred）：统一 case manifest、流体网格吃 STEP（snappyHexMesh）、新物理
- Git 提交不加 Claude 署名尾注；提交信息用仓库现有 conventional 风格

## 目标形态

```
对模型暴露 5 工具        TS 编排层                 Python 领域层
cae_geometry ←──────→  src/tools/geometry.ts ←──→ dsh_cae/geometry/  (build | import)
cae_mesh     ←──────→  src/tools/mesh.ts     ←──→ dsh_cae/mesh/      (solid | fluid)
cae_solve    ←──────→  src/tools/solve.ts    ←──→ dsh_cae/solve/     (static | steady | transient)
cae_post     ←──────→  src/tools/post.ts     ←──→ dsh_cae/post/
cae_verify   ←──────→  src/tools/verify.ts   ←──→ dsh_cae/verify/    (chain: structural | cfd)
                                                   共享: dsh_cae/shared/{receipt,deps,cfd_case}.py
```

**分流参数**：geometry/mesh/solve 用 `mode`，verify 保留 `chain`；取值与 Python 子命令逐字相同：

| 工具 | 分流值 | 子进程形态 |
|---|---|---|
| cae_geometry | `mode: 'build' \| 'import'` | `python -m dsh_cae.geometry build ...` |
| cae_mesh | `mode: 'solid' \| 'fluid'` | `python -m dsh_cae.mesh fluid ...` |
| cae_solve | `mode: 'static' \| 'steady' \| 'transient'` | `python -m dsh_cae.solve steady ...` |
| cae_verify | `chain: 'structural' \| 'cfd'` | `python -m dsh_cae.verify cfd ...` |

## 关键设计决策

1. **schema 用纯对象组合，不引抽象层**。工具参数是 `@deepseek-ai/dsh-tools` 的 `ParameterSchemaSpec` 纯对象字面量（非 Schemastery；Schemastery 只用于 `src/config.ts`，不动）。各分支参数平铺、除 mode/chain 外全 optional。mesh.ts/solve.ts 导出属性级片段（如 `STEP_PARAM`、`MATERIAL_PARAM`、`DUCT_GEOMETRY_PARAMS`、`INLET_VELOCITY_PARAM`、`OVERRIDES_PARAM`，片段不带 `required`，拥有者用 `{ ...FRAG, required: true }` 补必填），verify.ts 展开组合。
2. **交叉校验只在 TS execute() 一层做一次**：mode 缺分支必填参数、传入了非本 mode 的参数（报 `'step' belongs to mode='import'` 而非静默忽略）、velocity 长度、endTimeS/writeInterval 整除等——沿用各现有工具的校验代码搬到对应分支。Python argparse 只校验自己的 argv 完整性（pytest 直接驱动 CLI，是真实边界）。两层校验对象不同，不构成重复。
3. **receipt 协议零变化**：`<<<DSH_CAE_JSON>>>` marker、域失败=正常 receipt、stderr marker+exit 1 失败路径全部不变。`runStage` 签名不变，仅 opts 增可选 `timeoutMs`（verify 专用）；`ensureDeps` 的 stage 名 `'deps'` → `'shared.deps'`。
4. **receipt.py 的 `fail()` 改为 `raise StageError`**（打印 marker+exit 移到各包 `__main__.py` 分发器统一处理）——外部可观测行为不变，但 verify 能逐层捕获加 `level i of N (size s mm):` 前缀再抛。新建即采用此结构（无过渡态）；从 backup/ 移植的 fail-path pytest 用例保持通过即证明协议未破。
5. **领域函数只拆 verify 有真实进程内调用者的 5 处**：`mesh/solid.generate`、`mesh/fluid.generate`、`solve/static.solve`、`solve/steady.solve`、`post/extract`。geometry 两模块与 solve/transient 保持 main-only（第二个调用者出现再拆，YAGNI）。
6. **verify 形状统一到 solve**：现 verify 的 `fixedGroups`/`loads[{group, forceN}]` 与 solve 的 `constraints[{groupName, kind}]`/`loads[{groupName, vectorN}]` 已经漂移，本次统一为后者，随 v0.5.0 破坏性发布；verify 不再接收 `caseDir`（各层 case 目录由 Python 自建）。GCI 数学留在 TS（`gci.ts` 原样），Python verify 的 receipt 只含 `{chain, metric, levels}`（levels 粗→细排序，写死并加断言），TS 计算研究量并沿用现 `VerifyMeshReceipt` 形状。
7. **超时预算**：verify 单进程共享一个超时，必须覆盖为 `config.stageTimeoutMs × sizes.length × 3`（代码注释说明预算依据），否则 3 层 mesh+solve 必翻车。
8. **依赖方向 DAG（写进各包 AGENTS.md）**：`verify → {mesh, solve, post} → shared`；geometry → shared；禁止反向、禁止 verify 之外的兄弟包互调；fixtures 独立。
9. **deps 分组映射**：geometry（两种 mode）、mesh solid、solve static → structural；mesh fluid、solve steady/transient、verify 按链 → cfd。

## 备份与新建策略

**移入 `backup/`（一次 `git mv`，单独 commit，内容零改动）**：`src/`、`python/`、`tests/`、`pytest/`、`examples/`、`README.md`、`README.zh.md` → `backup/{src,python,tests,pytest,examples,README.md,README.zh.md}`。

**留守原地（插件身份与基础设施，非"旧代码"）**：`package.json`（版本改 0.5.0）、`tsconfig.json`、`.gitignore`、`docker/`、`Dockerfile`、CI workflow、`cae-deps/`、`cae-tmp/`、`dsh_case/`（运行时目录）、`docs/specs`+`docs/plans`（意图历史，ai-native-template 哲学：意图记录要保留，新 spec 加入其中）、`ai-native-template/`（参考模板）。

**新建方式**：所有新文件从零写在当前目录的标准位置（`src/`、`python/dsh_cae/` 等）。领域逻辑从 `backup/` **对照移植**——已验证的算法、领域警示注释（tet10 节点交换、FoamFile 多行头等）逐字拷贝，不凭记忆重写。`backup/` 正常提交入库（git 历史本来就留痕；提交后工作区状态干净，新增文件以 untracked/addition 形式清晰可见）。

**lib/ 是 gitignored 构建产物**：备份后 `pnpm build` 会随脚手架就位重新生成，无需处理。

## 文件映射（新文件 ← 对照 backup/ 移植来源）

### TS 层（src/）

| 旧 | 新 | 说明 |
|---|---|---|
| `src/index.ts` | 新写 | 注册 5 个工具；docstring "five stage tools" |
| `src/config.ts`、`src/interpreter.ts`、`src/gci.ts` | **不动** | |
| `src/runner.ts` | 两处小改 | `'deps'`→`'shared.deps'`；opts 加可选 `timeoutMs`（注意 line 84 与 line 100 两处都用超时值） |
| `src/tools/cad.ts` + `step-import.ts` | `src/tools/geometry.ts` | description/schema/execute 合并 + mode 分派 |
| `src/tools/mesh.ts` + `cfd-mesh.ts` | `src/tools/mesh.ts` 重写 | solid/fluid 两分支；导出 schema 片段 |
| `src/tools/solve.ts` + `cfd-steady.ts` + `cfd-transient.ts` | `src/tools/solve.ts` 重写 | 三分支；OVERRIDE_FILES 常量收敛一份；导出片段 |
| `src/tools/post.ts` | 新写（内容照搬 backup） | 工具名 `cae_post`;description 旧名引用清除 |
| `src/tools/verify-mesh.ts` | `src/tools/verify.ts` | 删 runLevel argv 镜像，改单次 runStage + gci |

import 用 `.js` 后缀（NodeNext）：`./tools/geometry.js`。

### Python 层（python/dsh_cae/）

| 旧 | 新 | 说明 |
|---|---|---|
| `receipt.py` | `shared/receipt.py` | 新增 `StageError`;`fail()` 改 raise |
| `deps.py` | `shared/deps.py` | `-m dsh_cae.shared.deps` |
| `cfd_case.py` | `shared/cfd_case.py` | 内容零改仅搬家（543 行，FoamFile 多行头等坑全在其中） |
| `cad.py` | `geometry/build.py` | `main(argv=None)` 化 |
| `step_import.py` | `geometry/step_import.py` | 同上（文件名避开 import 关键字） |
| `mesh.py` | `mesh/solid.py` | 拆 `generate(step, msh, *, faces_json=None, element_size=2.0, element_type='tet10', min_size=None, max_size=None) -> dict` |
| `cfd_mesh.py` | `mesh/fluid.py` | 拆 `generate(workdir, name, *, length_mm, width_mm, height_mm, cell_size_mm, wall_grading=1.0, block_mesh_dict_file=None, bashrc=None, timeout_s=600) -> dict` |
| `solve.py` | `solve/static.py` | 拆 `solve(...)`;负数 `--load-n` 的 `'='` argv 改写留在 main() |
| `cfd_steady.py` | `solve/steady.py` | 拆 `solve(case_dir, velocity, nu, *, rho=1.0, iterations=2000, overrides=None, case='run', bashrc=None, timeout_s=1800) -> dict` |
| `cfd_transient.py` | `solve/transient.py` | 仅 `main(argv=None)` 化，不拆函数 |
| `post.py` | `post/extract.py` | 拆 `extract(...) -> dict` |
| （新增） | `verify/structural.py`、`verify/cfd.py`、`verify/__main__.py` | 逐层循环，进程内调领域函数;CFD pressureDropPa 双 probe 逻辑（eps=size/2000）从 verify-mesh.ts:249-259 逐字移植 |
| （新增） | 各包 `__init__.py` + `__main__.py`、`shared/__init__.py` | 统一分发器模式（见下） |
| `fixtures/`、`__init__.py` | 不动 | fixtures.fake_stage stage 名不变 |

`__main__.py` 分发器模式（五包统一）：

```python
"""python -m dsh_cae.geometry build|import ..."""
import sys
from dsh_cae.geometry import build, step_import
from dsh_cae.shared.receipt import StageError, fail

COMMANDS = {"build": build.main, "import": step_import.main}

def main() -> None:
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        fail(f"usage: python -m dsh_cae.geometry <{'|'.join(COMMANDS)}> ...")
    try:
        COMMANDS[sys.argv[1]](sys.argv[2:])
    except StageError as exc:
        fail(str(exc))

if __name__ == "__main__":
    main()
```

叶子模块统一 `def main(argv: list[str] | None = None)`；不共享 parser、不做 subparsers 委托——每个叶子保留完整 argparse（它就是 CLI 边界文档），复用发生在领域函数层。

### 测试

vitest 按新工具重组（文件名=工具名）：

| 旧 | 新 |
|---|---|
| `tests/tools-cad-mesh.test.ts` | real-kernel build 部分 → `tests/tools-geometry.test.ts`;mesh 部分 → `tests/tools-mesh.test.ts` |
| `tests/tools-step-import.test.ts` | → `tools-geometry.test.ts` import 分支（argv 断言前插 `'import'` 子命令） |
| `tests/tools-cfd.test.ts` | fluid 校验 → `tools-mesh.test.ts`;steady 校验 + bashrc 转发 → `tools-solve.test.ts` |
| `tests/tools-cfd-transient.test.ts` | → `tools-solve.test.ts` transient 分支 |
| `tests/tools-solve-post.test.ts` | 注册断言（"exactly nine"）→ `smoke.test.ts`（随每 commit 渐进缩减 9→…→5）;post 两例 → `tests/tools-post.test.ts` |
| `tests/verify-mesh.test.ts` | 重写为 `tests/tools-verify.test.ts`:mock 单次 `runStage('verify')` 返回制造解 levels 表（COUNTS/valueFor 复用，gci 断言不变）;≥3 档、严格单调、链-指标匹配、pressureDropPa 需 ρ、缺分支必填项校验**原样保留在 TS** |
| `runner/interpreter/gci/smoke.test.ts`、`composition.e2e.ts` | 不动（deps.test.ts 仅 stage 名改 `shared.deps`） |

pytest 按包改名（stage 元组首参数=包名，conftest 的 `-m dsh_cae.{stage}` 模板天然兼容）：

| 旧 | 新 |
|---|---|
| `test_cad.py` | `test_geometry_build.py`（CANTILEVER 常量留此供导入） |
| `test_step_import.py` | `test_geometry_import.py` |
| `test_mesh.py` | `test_mesh_solid.py` |
| `test_cfd_mesh.py` | `test_mesh_fluid.py` |
| `test_solve.py` | `test_solve_static.py` |
| `test_cfd_steady.py` / `test_cfd_transient.py` | `test_solve_steady.py` / `test_solve_transient.py` |
| `test_post.py`、`test_pipeline.py`、`test_cfd_pipeline.py` | 文件名不动，stage 元组更新 |
| `test_cfd_case.py` | `test_shared_cfd_case.py`（仅 import 行） |
| `test_deps.py` | 文件名不动，`-m dsh_cae.shared.deps` |
| （新增） | `test_verify.py`:真内核结构链（CANTILEVER，elementSizes 8,6,4，粗档控制 120s 预算内），断言 levels 单调、receipt 形状;CFD 链沿用 `try_resolve_bashrc()` 模块级 skip |

跨文件导入同步改：`from test_cad import CANTILEVER`（3 处）→ 新名;`from test_mesh import _build` → `from test_mesh_solid import _build`。漏一处即 collection error。

### 文档与交接文件

- `README.md` / `README.zh.md`：九工具表→五工具表（加 mode 列）;六阶段映射改写;`cae_cfd_steady vs cae_cfd_transient` 段改为 `cae_solve mode='steady' vs 'transient'`;Try-it 示例链改名;契约段补"5 工具 ↔ 5 包对齐 + OVERRIDES/CASE_DICT_FILES 双侧镜像契约"
- `examples/cantilever.md`、`duct-flow.md`：调用 JSON 全改新名+mode/chain+统一后的 constraints/loads 形状
- `package.json` 0.4.0 → 0.5.0
- 根 `AGENTS.md`（精简宪法）：双层架构、唯一耦合契约（argv+marker+stage 名表）、错误只在边界一层一次、YAGNI/Deferred 规则、验收命令文化（**pytest 必须 console script，禁止 repo 根 `python -m pytest`**——目录名遮蔽）、Git 原子 commit、交接三件套指针。每行过"删掉这行 AI 会犯错吗"检验
- 6 份包级 `AGENTS.md`（geometry/mesh/solve/post/verify/shared）：分层与依赖方向、系统边界验证点、**领域警示注释清单**（solve 的 tet10 `conn[8],conn[9]` 交换、`SOLVER=ITERATIVE SCALING`、负数 load-n `'='` 改写;shared 的 FoamFile 多行 banner、override 白名单）、测试命令、禁止事项
- 根 `MODULES.md`：登记 shared 三件、runner/interpreter/gci、mesh.ts/solve.ts 导出片段（调用方 cae_verify）
- `feature_list.json`：F-001~F-005，各带验收命令（如 F-002 `pytest pytest/test_mesh_solid.py pytest/test_mesh_fluid -v`），初始 `passes:false`，内核环境真实跑过后翻 true
- `progress.md`：初始条目记录本次重构会话
- 本次设计文档存 `docs/specs/2026-09-18-five-tool-consolidation-design.md`

## 实施顺序（9 个原子 commit）

顺序原则：C0 一次性归档旧插件，随后从零新建——每个 commit 引入一个新组件及其测试，除 C0（归档后构建暂缺，commit message 注明"rebuild in progress"）外每步全绿。smoke 注册断言随每步增长，终态 5。**新增行为**（mode 交叉校验、verify 单阶段化）先写失败测试再实现；移植行为对照 `backup/` 拷贝，警示注释逐字。

| # | commit | 内容 | 绿色判据 |
|---|---|---|---|
| C0 | `chore: archive v0.4 plugin to backup/` | git mv 旧 src/python/tests/pytest/examples/README×2 → backup/;package.json 0.5.0 | 无测试可跑（注明 rebuild in progress） |
| C1 | `feat: scaffold + cae_geometry` | 新 src/(index/config/runner/interpreter + tools/geometry.ts，从 backup 对照移植)、python/dsh_cae/{shared,geometry}/、tests/(smoke+tools-geometry)、pytest/(conftest+test_geometry_*) | vitest+pytest 全绿 |
| C2 | `feat: cae_mesh` | mesh/{solid,fluid}（含领域函数拆分）、TS mesh.ts+片段导出、tests/tools-mesh、pytest/test_mesh_* | 全绿 |
| C3 | `feat: cae_solve` | solve/{static,steady,transient}（static/steady 拆函数）、TS solve.ts+片段、tests/tools-solve、pytest/test_solve_* | 全绿 |
| C4 | `feat: cae_post` | post/extract.py、TS post.ts、tests/tools-post、pytest/test_post | 全绿 |
| C5 | `feat: cae_verify` | python verify/ 三件、TS verify.ts（片段组合+单 runStage+timeoutMs）、tests/tools-verify 重写、pytest/test_verify、smoke=5 | 全绿 |
| C6 | `docs: five-tool rewrite` | 新 README×2、examples×2;`grep -rn "cae_cad_build\|cae_step_import\|cae_mesh_generate\|cae_solve_static\|cae_cfd_" src/ python/ tests/ pytest/ examples/ README*` 清零 | 全绿 |
| C7 | `docs: handoff files` | 根 AGENTS.md、6 份包 AGENTS.md、MODULES.md、feature_list.json、progress.md、docs/specs/2026-09-18 设计文档 | 全绿 |
| C8 | `test: acceptance` | 内核环境全量跑 + 双示例链;feature_list 翻绿;progress.md 贴真实输出 | 验收记录 |

## 风险清单（实现时盯住）

1. **pytest console script 红线**：`pytest pytest -v`，禁止 `python -m pytest`（pytest/ 目录遮蔽）
2. **interpreter.ts 环境清洗零改**：`stageEnv`（conda lib 前置 LD_LIBRARY_PATH）与 `dockerSpawnEnv` 别被顺手重构
3. **领域警示注释逐字搬运**（丢一处即坏）：tet10 节点交换、SPOOLES 迭代求解器、负数 load-n `'='` 改写、FoamFile 多行 banner、override 顶层键精确匹配、ccx 裸 basename、路径分隔符校验
4. **StageError 改造回归**：fail-path pytest 用例通过=协议未破的证明
5. **verify 超时**：不加 timeoutMs 覆盖必翻车（旧架构每 stage 各享预算）
6. **描述文本旧名残留**：9 个工具 description 互相引用旧名，C6 grep 收口
7. **pytest 跨文件导入断链**：CANTILEVER/_build 改名漏一处即 collection error
8. **smoke 渐进缩减**：别在 C1 就改成 5，跟随每步实际注册数

## Verification

1. TS：`pnpm build && pnpm vitest run`（无需 key;composition.e2e.ts 需 DSH_COMPOSITION=1 + harness checkout，保持选通）
2. Python：conda env `dsh-cae` + `LD_LIBRARY_PATH=$ENV/lib PATH=$ENV/bin:$PATH` 清洗后 `pytest pytest -v`;无内核环节（gmsh/ccx/OpenFOAM）自跳过
3. 端到端：`pytest pytest/test_pipeline.py pytest/test_cfd_pipeline.py -v` + 手动按 `examples/cantilever.md`、`duct-flow.md` 走新工具链
4. 旧名清零（显式列目录，天然排除 backup/）：`grep -rn "cae_cad_build\|cae_step_import\|cae_mesh_generate\|cae_solve_static\|cae_cfd_" src/ python/ tests/ pytest/ examples/ README*` 零命中
5. feature_list.json 五条验收命令逐条真实运行并贴输出到 progress.md
