"""python -m dsh_cae.mesh solid|fluid ..."""
import sys

from dsh_cae.mesh import fluid, solid
from dsh_cae.shared.receipt import StageError, report_fail

COMMANDS = {"solid": solid.main, "fluid": fluid.main}


def main() -> None:
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        report_fail(f"usage: python -m dsh_cae.mesh <{'|'.join(COMMANDS)}> ...")
    try:
        COMMANDS[sys.argv[1]](sys.argv[2:])
    except StageError as exc:
        report_fail(str(exc))


if __name__ == "__main__":
    main()
