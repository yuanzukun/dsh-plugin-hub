"""Mesh stage: Gmsh solid tetra meshing + parametric blockMesh fluid duct, dispatched by mode."""
