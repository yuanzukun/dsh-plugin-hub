"""Fluid mesh stage: lay a parametric blockMesh case and check it. Geometry arrives
in mm and is converted to SI here — the only unit conversion in the CFD chain."""
import argparse
import pathlib
import subprocess

from dsh_cae.shared import cfd_case
from dsh_cae.shared.receipt import emit, fail


def generate(workdir: str, name: str, *, length_mm: float, width_mm: float, height_mm: float,
             cell_size_mm: float, wall_grading: float = 1.0,
             block_mesh_dict_file: str | None = None, bashrc: str | None = None,
             timeout_s: float = 600) -> dict:
    """Parametric blockMesh duct case; returns the receipt dict (raise StageError on domain failure)."""
    if name in (".", "..") or "/" in name or "\\" in name:
        fail(f"case name '{name}' must be a plain directory name")
    for flag in ("length_mm", "width_mm", "height_mm", "cell_size_mm"):
        value = {"length_mm": length_mm, "width_mm": width_mm,
                 "height_mm": height_mm, "cell_size_mm": cell_size_mm}[flag]
        if value <= 0:
            fail(f"--{flag.replace('_', '-')} must be positive, got {value}")
    bashrc = cfd_case.resolve_bashrc(bashrc)
    case_dir = pathlib.Path(workdir) / "cfd" / name
    case_dir.mkdir(parents=True, exist_ok=True)

    if block_mesh_dict_file:
        dict_text = pathlib.Path(block_mesh_dict_file).read_text()
    else:
        dict_text = cfd_case.render_block_mesh_dict(
            length_mm / 1000.0, width_mm / 1000.0,
            height_mm / 1000.0, cell_size_mm / 1000.0, wall_grading)
    cfd_case.write_case_skeleton(case_dir, dict_text)

    try:
        meshed = cfd_case.foam_run(bashrc, "blockMesh", ["-case", str(case_dir)], timeout_s)
    except subprocess.TimeoutExpired:
        fail(f"blockMesh timed out after {timeout_s}s")
    (case_dir / "blockMesh.log").write_text(meshed.stdout + meshed.stderr)
    if meshed.returncode != 0:
        fail(f"blockMesh failed with exit {meshed.returncode}:\n"
             f"{cfd_case.tail40(meshed.stdout + meshed.stderr)}")

    try:
        checked = cfd_case.foam_run(bashrc, "checkMesh", ["-case", str(case_dir)], timeout_s)
    except subprocess.TimeoutExpired:
        fail(f"checkMesh timed out after {timeout_s}s")
    check_log = case_dir / "checkMesh.log"
    check_log.write_text(checked.stdout + checked.stderr)

    metrics = cfd_case.parse_check_mesh(checked.stdout)
    return {
        "caseDir": str(case_dir),
        "blockMeshDictPath": str(case_dir / "system" / "blockMeshDict"),
        "boundsM": metrics["boundsM"],
        "cells": metrics["cells"],
        "maxNonOrthogonalityDeg": metrics["maxNonOrthogonalityDeg"],
        "maxAspectRatio": metrics["maxAspectRatio"],
        "checksPassed": metrics["checksPassed"],
        "checkMeshLogPath": str(check_log),
        "logTail": cfd_case.tail40(checked.stdout),
    }


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workdir", required=True)
    parser.add_argument("--name", default="duct")
    parser.add_argument("--length-mm", type=float, required=True)
    parser.add_argument("--width-mm", type=float, required=True)
    parser.add_argument("--height-mm", type=float, required=True)
    parser.add_argument("--cell-size-mm", type=float, required=True)
    parser.add_argument("--wall-grading", type=float, default=1.0)
    parser.add_argument("--block-mesh-dict-file")
    parser.add_argument("--bashrc")
    parser.add_argument("--timeout-s", type=float, default=600)
    args = parser.parse_args(argv)

    emit(generate(args.workdir, args.name,
                  length_mm=args.length_mm, width_mm=args.width_mm,
                  height_mm=args.height_mm, cell_size_mm=args.cell_size_mm,
                  wall_grading=args.wall_grading,
                  block_mesh_dict_file=args.block_mesh_dict_file,
                  bashrc=args.bashrc, timeout_s=args.timeout_s))


if __name__ == "__main__":
    main()
