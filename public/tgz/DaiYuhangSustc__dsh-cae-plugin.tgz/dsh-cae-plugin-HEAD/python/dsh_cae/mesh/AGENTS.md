# python/dsh_cae/mesh —— 网格包规则

> 本文件只约束 `python/dsh_cae/mesh`。全局规则见仓库根 `AGENTS.md`。

## 本包职责

- `solid.py`：STEP → Gmsh 四面体网格（tet4/tet10），按面指纹 sidecar 重建命名 physical groups，报告质量（minSJ）与连通性。
- `fluid.py`：铺设参数化 blockMesh 管道 case 并 checkMesh，产出后续 CFD 求解用的 caseDir。
- 对应工具 `cae_mesh`（mode `solid` | `fluid`），经 `python -m dsh_cae.mesh solid|fluid ...` 调用。

## 依赖方向（DAG：verify → mesh → shared）

- 只 import `dsh_cae.shared.receipt` 与 `dsh_cae.shared.cfd_case`（仅 fluid）。
- 调用我：TS 侧 `cae_mesh`（子进程）；进程内 `verify/structural.py` 调 `solid.generate`、`verify/cfd.py` 调 `fluid.generate`。

## 系统边界验证点（防御只允许在这里）

1. `__main__.py` 分发器：子命令必须是 `solid` 或 `fluid`。
2. `solid.py` 的 `main()`：argparse 保证 `--step`/`--msh` 必填、`--element-type` 限 tet4/tet10。
3. `fluid.py` 的 `generate()` 入口（`fluid.py:16-22`）：case 名不得是 `.`/`..` 或含路径分隔符；四个几何尺寸必须为正。blockMesh/checkMesh 非零退出是域失败，`fail` 时带 tail40 日志（`fluid.py:40-42`）。

## 领域警示清单（每条都有代码出处，不可丢）

- **面指纹 sidecar 重建 physical groups**：`solid.py:44-63` — 按质心 + 面积匹配 STEP 面，容差 = `1e-6 × 包围盒对角线 + 1e-9`（质心）与 `1e-9`（面积，rel/abs）；匹配不到任何面即 fail 并附全部候选指纹。sidecar 由 geometry 包两个 mode 产出（键 `centroidMm`/`areaMm2`，见 `geometry/AGENTS.md`）。
- **sidecar 缺席 = 无命名面，不是错误**：`solid.py:20-27` — TS 工具层总是传 `--faces-json`，但无命名面的首过 CAD 不写 sidecar 文件，这里必须当"没有组要重建"处理。
- **mm→m 唯一转换点**：`fluid.py:1-2` docstring — `Geometry arrives in mm and is converted to SI here — the only unit conversion in the CFD chain`（实现在 `fluid.py:30-32` 的 `/1000.0`）；`shared/cfd_case.py:1-3` 同义声明。CFD 链其它任何位置不得再做单位换算。
- **grading 语义**：`shared/cfd_case.py:62-77`（`render_block_mesh_dict`）— `wall_grading` 是 y/z 向**中心→壁面的对称膨胀比**（1 = 均匀），实现为每半宽按 `sqrt(ratio)` 展开，使整体中心→壁面网格尺寸比恰等于 `wall_grading`。
- **tet10 连通性只数 4 角点**：`solid.py:164` — `tet10: 4 corners, then 6 mid-edge`；组件数 >1 时 receipt 带 warning（下游静力求解奇异，`solid.py:97-103` 与 `147-149`）。
- **min/max size 缺省语义**：`solid.py:70-71` — `max_size` 缺省取 `element_size`，`min_size` 缺省取 `element_size/5`。

## 测试命令

```
LD_LIBRARY_PATH="$HOME/miniconda3/envs/dsh-cae/lib" PATH="$HOME/miniconda3/envs/dsh-cae/bin:$PATH" ~/miniconda3/envs/dsh-cae/bin/pytest pytest/test_mesh_solid.py pytest/test_mesh_fluid.py -v
```

## 禁止事项

- 禁止在 solid 分支引入任何 OpenFOAM 依赖；禁止在 fluid 分支做第二次单位换算。
- 禁止放宽指纹匹配容差来"修"匹配失败——容差绑定包围盒尺度是有意的（`solid.py:38-39`）。
- 禁止把连通性 warning 升级为 fail（信息给模型，让模型决定约束每个组件还是tie）。
