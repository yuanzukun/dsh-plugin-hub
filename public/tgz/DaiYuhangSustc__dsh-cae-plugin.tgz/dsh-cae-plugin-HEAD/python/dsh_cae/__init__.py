"""Bundled CAE stage modules for the five stage tools; executed via `python -m dsh_cae.<stage>` with this directory on PYTHONPATH."""
