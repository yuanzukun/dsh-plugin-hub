"""python -m dsh_cae.solve static|steady|transient ..."""
import sys

from dsh_cae.solve import static, steady, transient
from dsh_cae.shared.receipt import StageError, report_fail

COMMANDS = {"static": static.main, "steady": steady.main, "transient": transient.main}


def main() -> None:
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        report_fail(f"usage: python -m dsh_cae.solve <{'|'.join(COMMANDS)}> ...")
    try:
        COMMANDS[sys.argv[1]](sys.argv[2:])
    except StageError as exc:
        report_fail(str(exc))


if __name__ == "__main__":
    main()
