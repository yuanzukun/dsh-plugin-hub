# python/dsh_cae/solve —— 求解包规则

> 本文件只约束 `python/dsh_cae/solve`。全局规则见仓库根 `AGENTS.md`。

## 本包职责

- `static.py`：Gmsh MSH → CalculiX INP → ccx 线性静力 → VTU（`solve()` 领域函数 + `main()` CLI）。
- `steady.py`：在 fluid mesh case 上参数化并跑 foamRun 稳态不可压缩求解（`solve()` + `main()`）。
- `transient.py`：真实物理秒的 PIMPLE/Euler 瞬态推进（`main()` 一体，无第二个调用者故不拆函数）。
- 对应工具 `cae_solve`（mode `static` | `steady` | `transient`），经 `python -m dsh_cae.solve static|steady|transient ...` 调用。

## 依赖方向（DAG：verify → solve → shared）

- 只 import `dsh_cae.shared.receipt` 与 `dsh_cae.shared.cfd_case`。
- 调用我：TS 侧 `cae_solve`（子进程）；进程内 `verify/structural.py` 调 `static.solve`、`verify/cfd.py` 调 `steady.solve`。

## 系统边界验证点（防御只允许在这里）

1. `__main__.py` 分发器：子命令必须是 `static`/`steady`/`transient`。
2. 各 `main()` 只校验自己的 argv：velocity 必须 3 分量、iterations/endTime/deltaT 为正、case stem 不含路径分隔符、`system/controlDict` 存在（不是 fluid mesh 产出的 case 即 fail，`steady.py:24-29`、`transient.py:37-48`）。
3. 域失败（ccx 非零、foamRun 超时/非零、不收敛）按协议进 receipt 或 `fail`，内部函数互信。

## 领域警示清单（每条都有代码出处，不可丢）

- **tet10 中间节点 9/10 交换**：`static.py:27-31` — Gmsh 把最后两个中间节点排成 (3-4),(2-4)，Abaqus/CalculiX C3D10 要 (2-4),(3-4)；不交换 `conn[8], conn[9]` 则 ccx 在每个单元报 nonpositive jacobian。
- **`SOLVER=ITERATIVE SCALING`**：`static.py:104-105` — 本机 SPOOLES 对中大模型静默崩溃（exit 255），迭代求解器更稳。不要"简化"回默认 SPOOLES。
- **负数 `--load-n` 的 `'='` argv 改写**：`static.py:161-172`（`verify/structural.py:74-85` 同款）— argparse 会把 `"-15733,6808,-12000"` 误当选项，必须预先改写成 `--load-n=...` 形式；TS 侧组 argv 时同样用 `=` 形式（`src/tools/verify.ts:181-182` 注释）。
- **ccx 裸 basename + cwd**：`static.py:60-61` — CalculiX 讨厌绝对 jobname，必须 `cwd=case_dir` 跑 `ccx <basename>`，receipt 里再报绝对路径。
- **foamRun/foamToVTK 用小写 `-case`**：全部 foam 调用点 `mesh/fluid.py:36,45`、`steady.py:47,57`、`transient.py:69,79` 都是 `["-case", ...]`——OpenFOAM 工具不认大写 `-Case`。
- **transient endTimeS/writeIntervalS 整除**：`src/tools/solve.ts:364-372` 注释 — 非整除时 foamRun 的 adjustableRunTime 永远踩不到 endTime、末态不写盘，foamToVTK 会转出一个更早的时刻而 receipt 仍报 endTimeS；整除校验在 TS execute()，Python `transient.py:41-43` 校验 writeInterval ∈ (0, endTime]。
- **重跑卫生**：`steady.py:31-36`、`transient.py:50-54` — 跑前删除旧时间目录与 VTK，否则 `foamToVTK -latestTime` 捡到上一轮更长模拟的残余结果。

## 测试命令

```
LD_LIBRARY_PATH="$HOME/miniconda3/envs/dsh-cae/lib" PATH="$HOME/miniconda3/envs/dsh-cae/bin:$PATH" ~/miniconda3/envs/dsh-cae/bin/pytest pytest/test_solve_static.py pytest/test_solve_steady.py pytest/test_solve_transient.py -v
```

## 禁止事项

- 禁止把 ccx 非零退出改成异常抛出（域结果协议：exitCode/logTail 进 receipt）。
- 禁止在 Python 里重复 TS 的分支组合校验（对象不同，见根宪法第 2 节）。
- 禁止换 solver 名：`incompressibleFluid` 是 OpenFOAM ≥ 11 的 simpleFoam 后继（`steady.py:1-5` docstring）；改求解器配置走 overrides，不动模板。
