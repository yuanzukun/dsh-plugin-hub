"""Solve stage: CalculiX static + OpenFOAM steady/transient solves, dispatched by mode."""
