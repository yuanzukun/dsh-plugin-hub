# python/dsh_cae/solve/steady.py
"""CFD steady stage: parameterize the laid case (fields, nu, iterations), apply
dict overrides, run foamRun (incompressibleFluid = simpleFoam successor in
OpenFOAM >= 11), and convert the final time to VTK. Non-convergence and solver
crashes are domain outcomes carried in the receipt."""
import argparse
import json
import pathlib
import re
import shutil
import subprocess
import time

from dsh_cae.shared import cfd_case
from dsh_cae.shared.receipt import emit, fail


def solve(case_dir: str, velocity: tuple[float, float, float], nu: float, *,
          rho: float = 1.0, iterations: int = 2000,
          overrides: list[dict] | None = None, case: str = "run",
          bashrc: str | None = None, timeout_s: float = 1800) -> dict:
    """Clone case, parametrize, foamRun simpleFoam successor, VTK; returns receipt dict."""
    case_dir = pathlib.Path(case_dir)
    if not (case_dir / "system" / "controlDict").is_file():
        fail(f"'{case_dir}' is not a cfd_mesh case (system/controlDict missing)")
    if iterations <= 0:
        fail(f"--iterations must be positive, got {iterations}")
    if case in (".", "..") or "/" in case or "\\" in case:
        fail(f"case stem '{case}' must not contain path separators")

    # Rerun hygiene: a longer previous run leaves time dirs (and VTK output)
    # that foamToVTK -latestTime would otherwise pick up as the new result.
    for entry in case_dir.iterdir():
        if entry.name != "0" and re.fullmatch(r"\d+(\.\d+)?", entry.name) and entry.is_dir():
            shutil.rmtree(entry)
    shutil.rmtree(case_dir / "VTK", ignore_errors=True)

    bashrc = cfd_case.resolve_bashrc(bashrc)
    cfd_case.write_fields(case_dir, list(velocity), nu)
    cfd_case.write_control_dict(case_dir, iterations)
    if overrides:
        cfd_case.apply_overrides(case_dir, overrides)

    log_path = case_dir / f"{case}.foam.log"
    start = time.monotonic()
    try:
        run = cfd_case.foam_run(bashrc, "foamRun", ["-case", str(case_dir)], timeout_s)
    except subprocess.TimeoutExpired:
        fail(f"foamRun timed out after {timeout_s}s")
    wall_ms = int((time.monotonic() - start) * 1000)
    log_text = run.stdout + run.stderr
    log_path.write_text(log_text)

    vtk_path = None
    if run.returncode == 0:
        try:
            conv = cfd_case.foam_run(bashrc, "foamToVTK", ["-case", str(case_dir), "-latestTime"],
                                     timeout_s)
        except subprocess.TimeoutExpired:
            fail(f"foamToVTK timed out after {timeout_s}s")
        if conv.returncode == 0:
            vtk_path = cfd_case.find_latest_vtk(case_dir)

    parsed = cfd_case.parse_foam_log(run.stdout)
    return {
        "caseDir": str(case_dir),
        "logPath": str(log_path),
        "vtkPath": vtk_path,
        "iterationsRun": parsed["iterationsRun"],
        "converged": parsed["converged"],
        "finalResiduals": parsed["finalResiduals"],
        "wallMs": wall_ms,
        "exitCode": run.returncode,
        "logTail": cfd_case.tail40(log_text),
        "densityKgM3": rho,
    }


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case-dir", required=True)
    parser.add_argument("--velocity", required=True, help="u,v,w in m/s")
    parser.add_argument("--nu", type=float, required=True, help="kinematic viscosity m^2/s")
    parser.add_argument("--rho", type=float, default=1.0, help="density kg/m^3 (echoed for post)")
    parser.add_argument("--iterations", type=int, default=2000)
    parser.add_argument("--overrides-file")
    parser.add_argument("--case", default="run")
    parser.add_argument("--bashrc")
    parser.add_argument("--timeout-s", type=int, default=1800)
    args = parser.parse_args(argv)

    vel = [float(v) for v in args.velocity.split(",")]
    if len(vel) != 3:
        fail(f"--velocity must be u,v,w (m/s), got '{args.velocity}'")
    overrides = None
    if args.overrides_file:
        overrides = json.loads(pathlib.Path(args.overrides_file).read_text())

    emit(solve(args.case_dir, (vel[0], vel[1], vel[2]), args.nu,
               rho=args.rho, iterations=args.iterations, overrides=overrides,
               case=args.case, bashrc=args.bashrc, timeout_s=args.timeout_s))


if __name__ == "__main__":
    main()
