# python/dsh_cae/geometry —— 几何包规则

> 本文件只约束 `python/dsh_cae/geometry`。全局规则见仓库根 `AGENTS.md`。

## 本包职责

- `build.py`：执行 build123d 建模脚本、导出 STEP、为 `NAMED_FACES` 落面指纹 sidecar。
- `step_import.py`：导入外部 STEP，校验（无效体/自由边/小面/短边/可合并面）、可选愈合（ShapeFix + UnifySameDomain）、按 faceId 命名面并写出同格式 sidecar。
- 对应工具 `cae_geometry`（mode `build` | `import`），经 `python -m dsh_cae.geometry build|import ...` 调用。

## 依赖方向

- 只 import `dsh_cae.shared.receipt`。本包是 DAG 叶子，不依赖其它领域包。
- 调用我：TS 侧 `cae_geometry`（子进程）；无进程内调用者。

## 系统边界验证点（防御只允许在这里）

1. `__main__.py` 分发器：子命令必须是 `build` 或 `import`，否则 usage 失败。
2. `build.py` 的 `main()`：argparse 保证 `--script-file`/`--step` 必填；脚本执行异常、缺 `part`、导出失败都是域失败（`fail` → `StageError`）。
3. `step_import.py` 的 `main()`：`--name-faces` 的 faceId 必须在输出几何面表 1..N 内、名字合法且唯一；不可读文件、无 solid 的 STEP fail loud，其余脏几何信号只进 receipt 的 `checks`（模型自己决定要不要修）。

## 领域警示清单（每条都有代码出处，不可丢）

- **脚本必须定义 `part`**：`build.py:37-39` — `cad script must define 'part' (a build123d solid/BuildPart)`；脚本异常是域诊断（`build.py:33-35`，trust level = bash tool）。
- **sidecar 格式与 STEP 来源同构**：`build.py:55-63` 写出的条目键为 `centroidMm`/`areaMm2`/`normal`；`step_import.py:210-215` 写出逐键相同的 sidecar（`step_import.py:3-7` docstring：`in build.py's format so the mesh stage can rebuild boundary-condition groups`）。改任一侧的键名都会断掉 `mesh/solid.py` 的指纹匹配。
- **sidecar 缺席 = 无命名面，不是错误**：`build.py:64`（sidecar 为空就不写文件）；下游 `mesh/solid.py:20-27` 的注释明确 `an absent file means "no named faces to rebuild", not an error`——TS 工具层总是传 `--faces-json`。
- **nameFaces 的 ASCII 名守卫**：`step_import.py:203-208` — 名字必须非空、`isascii`、字母数字/下划线、组内唯一，faceId 必须落在面表内（下游 physical group 名不允许其它字符）。
- **无 solid 的 STEP fail loud**：`step_import.py:92-94` — `STEP contains no solid bodies`，这是导入校验仅有的致命项之一。

## 测试命令

```
LD_LIBRARY_PATH="$HOME/miniconda3/envs/dsh-cae/lib" PATH="$HOME/miniconda3/envs/dsh-cae/bin:$PATH" ~/miniconda3/envs/dsh-cae/bin/pytest pytest/test_geometry_build.py pytest/test_geometry_import.py -v
```

## 禁止事项

- 禁止改 sidecar 键名而不同步 `mesh/solid.py`（双面契约）。
- 禁止给脚本执行加沙箱/重试（`build.py:33` 的 trust 注释即决策记录；有事故再谈）。
- 禁止把脏几何信号升级为 fail——校验结果进 receipt 让模型决策是本工具的设计。
