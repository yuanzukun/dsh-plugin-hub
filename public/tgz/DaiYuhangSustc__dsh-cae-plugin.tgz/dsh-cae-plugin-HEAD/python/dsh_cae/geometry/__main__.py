"""python -m dsh_cae.geometry build|import ..."""
import sys

from dsh_cae.geometry import build, step_import
from dsh_cae.shared.receipt import StageError, report_fail

COMMANDS = {"build": build.main, "import": step_import.main}


def main() -> None:
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        report_fail(f"usage: python -m dsh_cae.geometry <{'|'.join(COMMANDS)}> ...")
    try:
        COMMANDS[sys.argv[1]](sys.argv[2:])
    except StageError as exc:
        report_fail(str(exc))


if __name__ == "__main__":
    main()
