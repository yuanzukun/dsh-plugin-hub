"""Geometry stage: build123d script build + external STEP import/heal, dispatched by mode."""
