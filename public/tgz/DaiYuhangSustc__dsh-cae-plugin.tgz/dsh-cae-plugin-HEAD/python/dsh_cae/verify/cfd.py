# python/dsh_cae/verify/cfd.py
"""CFD half of the mesh-independence study: for each cell size (coarse→fine) re-lay the
parametric blockMesh duct, re-run the identical foamRun steady solve, and extract the
monitored metric — all in-process via the C2-C4 domain functions."""
import argparse
import os

from dsh_cae.mesh import fluid
from dsh_cae.post.extract import extract
from dsh_cae.shared.receipt import StageError, emit, fail
from dsh_cae.solve import steady


def study(length_mm: float, width_mm: float, height_mm: float, cell_sizes: list[float], *,
          velocity: tuple[float, float, float], nu: float, rho: float = 1.0,
          wall_grading: float = 1.0, metric: str, workdir: str,
          bashrc: str | None = None) -> dict:
    """For each cell size (coarse→fine): mesh.fluid.generate → solve.steady.solve → post.extract.

    Returns {"chain": "cfd", "metric": metric, "levels": [...]} — levels coarse→fine;
    the ordering is contractual, the TS side's GCI study consumes it as-is.
    """
    if metric not in ("maxVelocityMS", "pressureDropPa"):
        fail(f"metric '{metric}' is not available on chain=cfd — use maxVelocityMS or pressureDropPa")
    ordered = sorted(cell_sizes, reverse=True)  # coarse first — order is contractual, GCI consumes it
    L, W, H = length_mm / 1000.0, width_mm / 1000.0, height_mm / 1000.0

    levels = []
    n = len(ordered)
    for i, size in enumerate(ordered):
        try:
            mesh_receipt = fluid.generate(workdir, f"verify-l{i}",
                                          length_mm=length_mm, width_mm=width_mm,
                                          height_mm=height_mm, cell_size_mm=size,
                                          wall_grading=wall_grading, bashrc=bashrc)
            count = mesh_receipt.get("cells")
            if not isinstance(count, (int, float)):
                fail("fluid mesh receipt has no cell count — cannot compute refinement ratios")
            case_dir = mesh_receipt.get("caseDir")
            if not case_dir:
                fail("fluid mesh receipt has no caseDir — cannot run the steady solve")
            steady_receipt = steady.solve(case_dir, tuple(velocity), nu,
                                          rho=rho, iterations=2000, case="run", bashrc=bashrc)
            if steady_receipt.get("converged") is not True:
                fail("did not converge at this level — raise iterations or loosen SIMPLE residualControl before studying mesh independence")
            vtk = steady_receipt.get("vtkPath")
            if not vtk:
                fail("steady solve produced no VTK result")
            png_stem = os.path.join(case_dir, f"verify-l{i}")
            if metric == "pressureDropPa":
                eps = size / 2000  # half a cell, meters
                receipt = extract(vtu=str(vtk),
                                  probes=[f"p,{eps},{W / 2},{H / 2}", f"p,{L - eps},{W / 2},{H / 2}"],
                                  png_stem=png_stem, density_kg_m3=rho)
                values = receipt.get("values")
                if not values or len(values) < 2:
                    fail("post produced no metric value")
                metric_value = values[0]["value"] - values[1]["value"]
            else:
                receipt = extract(vtu=str(vtk), maxima=["velocity"], png_stem=png_stem)
                values = receipt.get("values")
                if not values:
                    fail("post produced no metric value")
                metric_value = values[0]["value"]
        except StageError as exc:
            raise StageError(f"level {i + 1} of {n} ({size} mm): {exc}")
        levels.append({"sizeMm": size, "count": count, "metricValue": metric_value})
    return {"chain": "cfd", "metric": metric, "levels": levels}


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--length-mm", type=float, required=True)
    parser.add_argument("--width-mm", type=float, required=True)
    parser.add_argument("--height-mm", type=float, required=True)
    parser.add_argument("--cell-sizes", required=True, help="comma-separated cell sizes mm, e.g. 8,5,3")
    parser.add_argument("--wall-grading", type=float, default=1.0)
    parser.add_argument("--velocity", required=True, help="u,v,w in m/s")
    parser.add_argument("--nu", type=float, required=True, help="kinematic viscosity m^2/s")
    parser.add_argument("--rho", type=float, default=1.0, help="density kg/m^3 (echoed for post)")
    parser.add_argument("--metric", default="maxVelocityMS", choices=["maxVelocityMS", "pressureDropPa"])
    parser.add_argument("--workdir", required=True)
    parser.add_argument("--bashrc")
    args = parser.parse_args(argv)

    vel = [float(v) for v in args.velocity.split(",")]
    if len(vel) != 3:
        fail(f"--velocity must be u,v,w (m/s), got '{args.velocity}'")
    sizes = [float(s) for s in args.cell_sizes.split(",")]

    emit(study(args.length_mm, args.width_mm, args.height_mm, sizes,
               velocity=(vel[0], vel[1], vel[2]), nu=args.nu, rho=args.rho,
               wall_grading=args.wall_grading, metric=args.metric,
               workdir=args.workdir, bashrc=args.bashrc))


if __name__ == "__main__":
    main()
