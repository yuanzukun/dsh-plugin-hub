# python/dsh_cae/verify/structural.py
"""Structural half of the mesh-independence study: for each element size (coarse→fine)
re-mesh the STEP solid, re-run the identical ccx static solve, and extract the monitored
metric — all in-process via the C2-C4 domain functions."""
import argparse
import os
import sys

from dsh_cae.mesh import solid
from dsh_cae.post.extract import extract
from dsh_cae.shared.receipt import StageError, emit, fail
from dsh_cae.solve import static


def study(step: str, element_sizes: list[float], *, faces_json: str | None = None,
          young_mpa: float, poisson: float,
          constraints: list[dict], loads: list[dict],
          metric: str, workdir: str) -> dict:
    """For each size (coarse→fine): mesh.solid.generate → solve.static.solve → post.extract.

    Returns {"chain": "structural", "metric": metric, "levels": [...]} — levels coarse→fine;
    the ordering is contractual, the TS side's GCI study consumes it as-is.
    """
    if metric not in ("maxVonMises", "maxDisplacement"):
        fail(f"metric '{metric}' is not available on chain=structural — use maxVonMises or maxDisplacement")
    field = "vonMises" if metric == "maxVonMises" else "displacement"
    ordered = sorted(element_sizes, reverse=True)  # coarse first — order is contractual, GCI consumes it
    fixed_groups = [c["groupName"] for c in constraints if c.get("kind") == "fixed"]
    resolved_loads = [(l["groupName"], tuple(l["vectorN"])) for l in loads]

    levels = []
    n = len(ordered)
    for i, size in enumerate(ordered):
        try:
            level_dir = os.path.join(workdir, "verify", f"l{i}")
            os.makedirs(level_dir, exist_ok=True)
            msh = os.path.join(level_dir, "part.msh")
            mesh_receipt = solid.generate(step, msh, faces_json=faces_json, element_size=size)
            count = mesh_receipt.get("nodeCount")
            if count is None:
                fail("solid mesh receipt has no nodeCount — cannot compute refinement ratios")
            solve_receipt = static.solve(msh, os.path.join(level_dir, "case"),
                                         young_mpa=young_mpa, poisson=poisson,
                                         fixed_groups=fixed_groups, loads=resolved_loads)
            vtu = solve_receipt.get("vtuPath")
            frd = solve_receipt.get("frdPath")
            png_stem = os.path.join(level_dir, "post")
            if vtu:
                post_receipt = extract(vtu=vtu, maxima=[field], png_stem=png_stem)
            elif frd:
                post_receipt = extract(frd=frd, maxima=[field], png_stem=png_stem)
            else:
                fail("solve produced neither vtu nor frd result")
            values = post_receipt.get("values")
            if not values:
                fail("post produced no metric value")
            metric_value = values[0]["value"]
        except StageError as exc:
            raise StageError(f"level {i + 1} of {n} ({size} mm): {exc}")
        levels.append({"sizeMm": size, "count": count, "metricValue": metric_value})
    return {"chain": "structural", "metric": metric, "levels": levels}


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--step", required=True)
    parser.add_argument("--element-sizes", required=True, help="comma-separated element sizes mm, e.g. 8,5,3")
    parser.add_argument("--faces-json")
    parser.add_argument("--young-mpa", type=float, required=True)
    parser.add_argument("--poisson", type=float, required=True)
    parser.add_argument("--fixed-group", action="append", default=[])
    parser.add_argument("--load-group", action="append", default=[])
    parser.add_argument("--load-n", action="append", default=[])
    parser.add_argument("--metric", default="maxVonMises", choices=["maxVonMises", "maxDisplacement"])
    parser.add_argument("--workdir", required=True)
    # argparse 会把 "-15733,6808,-12000" 这类负值载荷误当选项；预先改写为 --load-n=... 形式
    rewritten: list[str] = []
    i = 0
    raw = sys.argv[1:] if argv is None else argv
    while i < len(raw):
        if raw[i] == "--load-n" and i + 1 < len(raw):
            rewritten.append(f"--load-n={raw[i + 1]}")
            i += 2
        else:
            rewritten.append(raw[i])
            i += 1
    args = parser.parse_args(rewritten)

    if len(args.load_group) != len(args.load_n):
        fail("--load-group and --load-n must appear in pairs")
    sizes = [float(s) for s in args.element_sizes.split(",")]

    emit(study(args.step, sizes,
               faces_json=args.faces_json,
               young_mpa=args.young_mpa, poisson=args.poisson,
               constraints=[{"groupName": g, "kind": "fixed"} for g in args.fixed_group],
               loads=[{"groupName": name, "vectorN": [float(v) for v in vec.split(",")]}
                      for name, vec in zip(args.load_group, args.load_n)],
               metric=args.metric, workdir=args.workdir))


if __name__ == "__main__":
    main()
