# python/dsh_cae/verify —— 验证包规则

> 本文件只约束 `python/dsh_cae/verify`。全局规则见仓库根 `AGENTS.md`。

## 本包职责

- `structural.py` / `cfd.py`：网格无关性研究的逐层循环——每档尺寸进程内调 mesh/solve/post 领域函数（mesh+solve+post 一轮），receipt 只含 `{chain, metric, levels}`。
- GCI 数学**不在本包**：在 TS `src/gci.ts`（纯函数），由 `cae_verify` 消费 levels 计算。
- 对应工具 `cae_verify`（chain `structural` | `cfd`），TS 侧单次 `runStage('verify', ...)` 调入，超时预算 ×3×层数。

## 依赖方向（DAG 顶层：verify → {mesh, solve, post} → shared）

- import `dsh_cae.mesh.{solid,fluid}`、`dsh_cae.solve.{static,steady}`、`dsh_cae.post.extract`、`dsh_cae.shared.receipt`。
- 调用我：TS 侧 `cae_verify`（子进程，全插件唯一入口）。**本包是唯一允许跨领域包调用的地方**。

## 系统边界验证点（防御只允许在这里）

1. `__main__.py` 分发器：子命令必须是 `structural` 或 `cfd`。
2. `main()`：velocity 3 分量、负数 `--load-n` 的 `'='` 改写（`structural.py:74-85`，同 solve 包）。
3. `study()` 入口：metric 必须在链的白名单内（`structural.py:24-25`、`cfd.py:23-24`）。TS `verify.ts:124-130` 对工具参数做同一组合校验——两层对象不同（工具参数 vs study 参数），是镜像不是重复。

## 领域警示清单（每条都有代码出处，不可丢）

- **levels 粗→细排序是 GCI 的契约**：`structural.py:27`、`cfd.py:25` — `sorted(..., reverse=True)  # coarse first — order is contractual, GCI consumes it`；docstring 同义（`the ordering is contractual, the TS side's GCI study consumes it as-is`）。TS `verify.ts:219-224` 断言严格降序，违序即协议被破坏。
- **每层 StageError 加 `level i of N` 前缀**：`structural.py:56-57`、`cfd.py:63-64` — `raise StageError(f"level {i + 1} of {n} ({size} mm): {exc}")`，否则三层循环里分不清哪档尺寸翻的车。
- **converged≠true 即失败**：`cfd.py:42-43` — 判据是 `is not True`（不是 falsy 检查）；不收敛的层没有可信指标，fail 并提示先放宽 SIMPLE residualControl 或加迭代，**不许跳过该层继续**。
- **eps=size/2000 半格探针**：`cfd.py:48-52` — `eps = size / 2000  # half a cell, meters`；pressureDropPa 的两探针一个在入口内半格、一个在出口前半格，避免贴 patch 插值污染压差。
- **结构链产物 vtu 优先、frd 兜底**：`structural.py:43-51` — vtuPath 转换失败时 frd 仍可用（与 solve static 的 receipt 语义一致）。
- **CFD 链层数据必须拿得到 cells**：`cfd.py:36-38` — 无 cell 数则无法算细化比，直接 fail。

## 测试命令

```
LD_LIBRARY_PATH="$HOME/miniconda3/envs/dsh-cae/lib" PATH="$HOME/miniconda3/envs/dsh-cae/bin:$PATH" ~/miniconda3/envs/dsh-cae/bin/pytest pytest/test_verify.py -v
```

## 禁止事项

- 禁止在 Python 里实现 GCI（`src/gci.ts` 是唯一实现，两侧重复必漂移）。
- 禁止吞掉不收敛的层（失败即停是设计：网格无关性研究不容忍坏数据点）。
- 禁止绕过领域函数直接起子进程调 mesh/solve 的 CLI——进程内调用就是本包存在的意义。
