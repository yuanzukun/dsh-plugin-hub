"""Verify stage: the per-level mesh→solve→post mesh-independence loop, dispatched by chain."""
