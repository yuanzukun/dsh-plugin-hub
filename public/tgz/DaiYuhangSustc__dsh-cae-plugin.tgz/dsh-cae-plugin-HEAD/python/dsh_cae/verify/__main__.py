"""python -m dsh_cae.verify structural|cfd ..."""
import sys

from dsh_cae.shared.receipt import StageError, report_fail
from dsh_cae.verify import cfd, structural

COMMANDS = {"structural": structural.main, "cfd": cfd.main}


def main() -> None:
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        report_fail(f"usage: python -m dsh_cae.verify <{'|'.join(COMMANDS)}> ...")
    try:
        COMMANDS[sys.argv[1]](sys.argv[2:])
    except StageError as exc:
        report_fail(str(exc))


if __name__ == "__main__":
    main()
