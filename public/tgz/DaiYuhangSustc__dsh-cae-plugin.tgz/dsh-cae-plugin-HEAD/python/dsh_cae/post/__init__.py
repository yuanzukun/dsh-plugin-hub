"""Post stage: scalar extraction and offscreen deformed-shape plots from VTU/FRD."""
