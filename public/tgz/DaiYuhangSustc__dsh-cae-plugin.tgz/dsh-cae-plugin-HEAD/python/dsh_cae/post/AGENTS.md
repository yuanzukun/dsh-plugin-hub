# python/dsh_cae/post —— 后处理包规则

> 本文件只约束 `python/dsh_cae/post`。全局规则见仓库根 `AGENTS.md`。

## 本包职责

- `extract.py`：读 VTU/FRD 结果，做场极值、点探针、离屏云图 PNG；一个 `extract()` 领域函数 + `main()` CLI。
- 对应工具 `cae_post`（无 mode），经 `python -m dsh_cae.post ...` 调用。同时服务结构链（VTU/FRD，mm/MPa）与 CFD 链（VTK，SI）。

## 依赖方向（DAG：verify → post → shared）

- 只 import `dsh_cae.shared.receipt`（numpy/pyvista 延迟导入）。
- 调用我：TS 侧 `cae_post`（子进程）；进程内 `verify/structural.py`、`verify/cfd.py` 调 `extract(...)`。

## 系统边界验证点（防御只允许在这里）

1. `__main__.py` 包装 `extract.main`（单命令，无子命令分发）。
2. `main()`：`--vtu`/`--frd` 互斥且必填、`--png-stem` 必填。
3. `_find()`：请求的字段不存在时 `fail` 并列出数据集实际可用的 point data 键（`extract.py:30,35,41,59`）——排障靠这个清单。

## 领域警示清单（每条都有代码出处，不可丢）

- **字段别名表**：`extract.py:12-20` — ccx2paraview 写 `U`/`S`，foamToVTK 写 `U`/`p`，合成 fixture 用全名；**`U` 按请求字段名解释**：请求 displacement 时是位移，请求 velocity 时是速度（`extract.py:14-15` 注释：`the requested field name decides the interpretation`）。
- **运动学压力 ×ρ→Pa**：`extract.py:37-38` — `simpleFoam/foamRun output is kinematic p (m²/s²); ×density → Pa`；ρ 来自 solve receipt 回传的 densityKgM3（`--density-kg-m3`），漏传则压差差一个 ρ 因子（verify 的 pressureDropPa 指标在 TS 侧为此强制要求 densityKgM3，`src/tools/verify.ts:131-133`）。
- **离屏渲染**：`extract.py:136` — `pv.Plotter(off_screen=True)`，无头环境唯一可行形态；绘图失败不得杀掉整个提取（`extract.py:142-143`：receipt 记 `error`，极值/探针照常返回）。
- **FRD 无 vtk reader**：`extract.py:109-112` — `pyvista/vtk ships no FRD reader`，必须先用 ccx2paraview 转成同名 VTU 再读。
- **von Mises 直取优先**：`extract.py:43-45` — 数据集可能带精确分量名（合成 fixtures）或 ccx2paraview 的 `S_Mises`；都没有才从 6 分量张量自算。
- **位置键单位**：`extract.py:74-76` — velocity/pressure 的位置是 SI 米（`atM`），结构场是毫米（`atMm`）。

## 测试命令

```
LD_LIBRARY_PATH="$HOME/miniconda3/envs/dsh-cae/lib" PATH="$HOME/miniconda3/envs/dsh-cae/bin:$PATH" ~/miniconda3/envs/dsh-cae/bin/pytest pytest/test_post.py pytest/test_pipeline.py pytest/test_cfd_pipeline.py -v
```

## 禁止事项

- 禁止把 `U` 硬编码解释为位移或速度——永远按请求字段名走别名表。
- 禁止在 density 未传时猜压力单位（默认 1.0 是有意的：kinematic→Pa 的显式契约）。
- 禁止把 plot 失败升级为整包失败。
