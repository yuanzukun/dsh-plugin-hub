"""python -m dsh_cae.post ..."""
import sys

from dsh_cae.post import extract
from dsh_cae.shared.receipt import StageError, report_fail


def main() -> None:
    try:
        extract.main(sys.argv[1:])
    except StageError as exc:
        report_fail(str(exc))


if __name__ == "__main__":
    main()
