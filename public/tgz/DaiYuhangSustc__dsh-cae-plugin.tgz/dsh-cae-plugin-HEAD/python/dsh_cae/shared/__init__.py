"""Shared layer: the receipt protocol and the dependency self-check stage."""
