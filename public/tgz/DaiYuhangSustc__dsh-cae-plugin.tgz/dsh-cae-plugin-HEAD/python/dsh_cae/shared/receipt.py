"""Shared receipt emission for every dsh_cae stage."""
import json
import sys
from typing import NoReturn

MARK = "<<<DSH_CAE_JSON>>>"


class StageError(Exception):
    """Domain failure that must reach the caller as a marker receipt, not a traceback."""


def emit(obj: dict) -> None:
    """Print the receipt marker and one JSON object as the stage's final stdout."""
    print(MARK)
    print(json.dumps(obj))
    sys.stdout.flush()


def fail(message: str) -> NoReturn:
    """Raise StageError; the package __main__ dispatcher converts it to the stderr marker + exit 1."""
    raise StageError(message)


def report_fail(message: str) -> NoReturn:
    """Marker JSON on stderr + exit 1 — exactly v0.4 fail()'s observable behavior."""
    print(MARK, file=sys.stderr)
    print(json.dumps({"error": message}), file=sys.stderr)
    sys.stderr.flush()
    sys.exit(1)
