# python/dsh_cae/shared —— 共享层规则

> 本文件只约束 `python/dsh_cae/shared`。全局规则见仓库根 `AGENTS.md`。

## 本包职责

- `receipt.py`：stage receipt 协议——`<<<DSH_CAE_JSON>>>` marker、`emit()`、`fail()`（=raise `StageError`）、`report_fail()`（stderr marker + exit 1）。
- `deps.py`：依赖自检 stage（`python -m dsh_cae.shared.deps --group structural|cfd`），structural 探 Python 导入 + ccx，cfd 探 OpenFOAM bashrc 与四个工具。
- `cfd_case.py`：OpenFOAM case 组装全集——bashrc 解析、`foam_run`、模板渲染（blockMeshDict/fvSchemes/fvSolution/物理属性/controlDict 稳态+瞬态）、顶层 override、checkMesh/foamRun 日志解析。
- 依赖分组映射（deps group）：geometry 两 mode、mesh solid、solve static、post → `structural`；mesh fluid、solve steady/transient、verify 按链 → `cfd`。

## 依赖方向（DAG 底层：全部领域包 → shared）

- 只依赖标准库。调用我：五个领域包（receipt 全员；cfd_case 被 mesh/fluid 与 solve 两 CFD 分支用）；TS 侧经 `runStage(config, 'shared.deps', ...)`。

## 系统边界验证点（防御只允许在这里）

1. 各包 `__main__.py` 分发器是 `report_fail` 的唯一常规入口（usage 错误与 `StageError` → stderr marker + exit 1）。
2. `deps.py` 例外：模块直连 `-m` 执行没有分发器，`main()` 自带 StageError 包装（`deps.py:67-69` 注释）。
3. `resolve_bashrc()`：配置的 bashrc 不存在、环境完全找不到 OpenFOAM 都是基础设施失败，fail 时列出尝试过的路径（`cfd_case.py:32-44`）。

## 领域警示清单（每条都有代码出处，不可丢）

- **FoamFile 多行 banner**：`cfd_case.py:55-59` — `Multi-line banner is mandatory: the single-line form makes OpenFOAM 13 fail the read with a bogus "Cannot find file"`。单行头不报语法错而是**误报找不到文件**，极难排查；所有 `_foam_header` 产物都吃这条。
- **override 顶层键精确匹配白名单**：`cfd_case.py:14-19` 的 `CASE_DICT_FILES`（frozenset，精确成员判断），`cfd_case.py:15` 注释 `TS mirror: OVERRIDE_FILES in src/tools/solve.ts — change both in one commit`；`apply_override`（`cfd_case.py:297-301`）只做**整词、键位**的顶层匹配，缺键即 fail、绝不模糊匹配；`_in_key_position`（`cfd_case.py:286-291`）保证值 token（如 `stopAt endTime;` 里的 `endTime`）不被当作键。
- **receipt 的 fail=raise StageError / report_fail 分工**：`receipt.py:20-30` — `fail()` raise `StageError`（域失败在调用栈上传播，verify 等进程内调用者能逐层加工再抛）；`report_fail()` 打 stderr marker + exit 1，与 v0.4 的可观测失败协议逐字一致。两者语义不同，不要合并。
- **所有长度 SI 米**：`cfd_case.py:1-3` docstring — `All lengths are SI meters; callers own the single mm→m conversion at the cae_mesh (fluid) boundary`。shared 不接受 mm 输入。
- **foam_run 的 bash -c 形态**：`cfd_case.py:47-52` — `source "$0" && exec "$@"`，任何参数都不被二次展开；加参数请走 args 列表，不要拼字符串。
- **parse_foam_log 的 U 残差**：`cfd_case.py:386-389` — 取最后一个 Time 块中**实际出现**的分量的最大值；只在早期迭代出现的分量（如 Uy）不算。

## 测试命令

```
LD_LIBRARY_PATH="$HOME/miniconda3/envs/dsh-cae/lib" PATH="$HOME/miniconda3/envs/dsh-cae/bin:$PATH" ~/miniconda3/envs/dsh-cae/bin/pytest pytest/test_shared_cfd_case.py pytest/test_deps.py -v
```

## 禁止事项

- 禁止改 `CASE_DICT_FILES` 而不同步 `src/tools/solve.ts` 的 `OVERRIDE_FILES`（双面镜像契约，根宪法第 3 节）。
- 禁止把 FoamFile banner 折叠成单行。
- 禁止在 shared 里引入任何领域决策（求解器选型、网格参数……）——这里只有机制。
