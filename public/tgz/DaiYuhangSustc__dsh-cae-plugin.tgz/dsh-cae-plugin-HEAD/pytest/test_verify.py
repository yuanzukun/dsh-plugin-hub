# pytest/test_verify.py
"""verify stage (the per-level mesh→solve→post loop) against real kernels."""
import json
import math
import shutil

import pytest

pytest.importorskip("build123d")
pytest.importorskip("gmsh")
pytest.importorskip("pyvista")
if shutil.which("ccx") is None:
    pytest.skip("CalculiX ccx not on PATH", allow_module_level=True)

from dsh_cae.shared import cfd_case
from test_geometry_build import CANTILEVER

# The cfd chain needs an OpenFOAM bashrc; skipping is scoped to the cfd test so
# the structural study still runs on a ccx-only install.
BASHRC = cfd_case.try_resolve_bashrc()
skip_no_openfoam = pytest.mark.skipif(BASHRC is None, reason="no OpenFOAM bashrc resolvable")


def _cantilever(stage, workdir):
    script = workdir / "beam.cad.py"
    script.write_text(CANTILEVER)
    step, faces = workdir / "beam.step", workdir / "beam.faces.json"
    stage(workdir, "geometry", "build",
          "--script-file", str(script), "--step", str(step), "--faces-json", str(faces))
    return step, faces


def test_verify_structural_three_level_study(stage, workdir, parse_receipt):
    step, faces = _cantilever(stage, workdir)
    proc = stage(workdir, "verify", "structural",
                 "--step", str(step), "--faces-json", str(faces),
                 "--element-sizes", "4,6,8",
                 "--young-mpa", "210000", "--poisson", "0.3",
                 "--fixed-group", "fixed", "--load-group", "load", "--load-n", "-100,0,0",
                 "--metric", "maxVonMises", "--workdir", str(workdir))
    receipt = parse_receipt(proc)
    assert proc.returncode == 0
    assert receipt["chain"] == "structural"
    assert receipt["metric"] == "maxVonMises"
    levels = receipt["levels"]
    assert len(levels) == 3
    sizes = [l["sizeMm"] for l in levels]
    counts = [l["count"] for l in levels]
    # 升序传入、降序返回 — 逼出 Python 侧的降序排序；粗→细是契约，TS 侧 GCI 直接消费
    assert sizes == [8.0, 6.0, 4.0]
    assert all(b > a for a, b in zip(counts, counts[1:]))
    assert all(math.isfinite(l["metricValue"]) and l["metricValue"] > 0 for l in levels)


@skip_no_openfoam
def test_verify_cfd_three_level_study(stage, workdir, parse_receipt):
    proc = stage(workdir, "verify", "cfd",
                 "--length-mm", "60", "--width-mm", "10", "--height-mm", "10",
                 "--cell-sizes", "5,4,3", "--wall-grading", "2",
                 "--velocity", "0.02,0,0", "--nu", "1e-6", "--rho", "1000",
                 "--metric", "maxVelocityMS", "--workdir", str(workdir), "--bashrc", BASHRC)
    receipt = parse_receipt(proc)
    assert proc.returncode == 0
    assert receipt["chain"] == "cfd"
    assert receipt["metric"] == "maxVelocityMS"
    levels = receipt["levels"]
    assert len(levels) == 3
    sizes = [l["sizeMm"] for l in levels]
    counts = [l["count"] for l in levels]
    assert sizes == [5.0, 4.0, 3.0]
    assert all(b > a for a, b in zip(counts, counts[1:]))
    assert all(math.isfinite(l["metricValue"]) for l in levels)


def test_verify_fail_path_labels_the_level(stage, workdir):
    # A faces.json naming a group that matches no STEP surface kills the first
    # level's mesh — StageError must surface as the stderr marker, exit 1.
    step, faces = _cantilever(stage, workdir)
    faces.write_text(json.dumps({"nope": [{"centroidMm": [0.0, 0.0, 0.0], "areaMm2": 1.0}]}))
    proc = stage(workdir, "verify", "structural",
                 "--step", str(step), "--faces-json", str(faces),
                 "--element-sizes", "8,6,4",
                 "--young-mpa", "210000", "--poisson", "0.3",
                 "--fixed-group", "fixed", "--load-group", "load", "--load-n", "0,0,-100",
                 "--workdir", str(workdir))
    assert proc.returncode == 1
    assert proc.stderr.startswith("<<<DSH_CAE_JSON>>>")
    assert "level 1 of 3 (8.0 mm)" in proc.stderr
    assert "matched no STEP surface" in proc.stderr
    assert "Traceback" not in proc.stderr
