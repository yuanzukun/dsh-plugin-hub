/**
 * dsh-cae: natural-language-driven CAE pipeline for DeepSeek Harness.
 * Registers five stage tools (geometry → mesh → solve → post → verify) on `ctx.tools`; domain work
 * runs in bundled Python modules via one-shot subprocesses. Spec: docs/specs.
 * @module dsh-cae
 */
import type { Context } from '@deepseek-ai/cordis'
import type { Config } from './config.js'
import { defineCaeGeometryTool } from './tools/geometry.js'
import { defineCaeMeshTool } from './tools/mesh.js'
import { defineCaeSolveTool } from './tools/solve.js'
import { defineCaePostTool } from './tools/post.js'
import { defineCaeVerifyTool } from './tools/verify.js'

export const name = 'dsh-cae'
export const inject = ['tools']

export { Config } from './config.js'

/**
 * Register the five CAE stage tools on the tool registry.
 * @param ctx - registrant context carrying the tool registry.
 * @param config - deployment configuration.
 */
export function apply(ctx: Context, config: Config): void {
  ctx.tools.register(defineCaeGeometryTool(config))
  ctx.tools.register(defineCaeMeshTool(config))
  ctx.tools.register(defineCaeSolveTool(config))
  ctx.tools.register(defineCaePostTool(config))
  ctx.tools.register(defineCaeVerifyTool(config))
}
