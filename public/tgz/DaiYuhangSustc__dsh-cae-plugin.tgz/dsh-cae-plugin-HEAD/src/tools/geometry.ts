// src/tools/geometry.ts
import { writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { ensureDeps, runStage } from '../runner.js'
import type { Config } from '../config.js'

const DESCRIPTION =
  'Geometry entry point of the CAE chain (units mm). mode="build" constructs geometry by running a '
  + 'build123d Python script: the script MUST assign a solid to `part` (e.g. `part = Box(100, 20, 5)`); '
  + 'to prepare boundary conditions, also assign NAMED_FACES = {"<groupName>": <Face or list of Faces>} '
  + 'for faces you will later fix or load (group names survive into meshing and solving); returns the '
  + 'STEP path, volume, bounding box, and the named faces with areas and centroids. mode="import" imports '
  + 'an external STEP file: validate the geometry (invalid solids, free edges, sliver faces, short edges, '
  + 'mergeable split faces) and optionally heal it (OCCT ShapeFix + same-domain merge; healed geometry is '
  + 'written to a new *_clean.step). Recommended import flow: call WITHOUT nameFaces first and read the '
  + 'faces table (id, areaMm2, centroidMm, normal), decide which faces carry boundary conditions, then '
  + 'call again with nameFaces [{faceId, name}] — with the SAME repair setting as the first call — to '
  + 'write the faces.json sidecar that cae_mesh rebuilds into named groups for cae_solve. clean=false '
  + 'issues are reports, not errors; heal them by re-calling with repair=true. Only unreadable files, '
  + 'solids-free geometry, or bad faceIds fail.'

/** Receipt shape of the geometry build branch (build123d script), pinned for the tool's output schema. */
export interface GeometryBuildReceipt {
  mode: 'build'
  stepPath: string
  volumeMm3: number
  bboxMm: { min: number[]; max: number[] }
  namedFaces: { name: string; areaMm2: number; centroidMm: number[] }[]
}

/** Receipt shape of the geometry import branch (external STEP validate/heal), pinned for the output schema. */
export interface GeometryImportReceipt {
  mode: 'import'
  stepPath: string
  stepOut: string
  repaired: boolean
  repairedDelta: { facesBefore: number; facesAfter: number; mergeableFacesRemaining: number } | null
  checks: {
    solidCount: number
    faceCount: number
    invalidSolids: number
    freeEdges: boolean
    sliverFaces: { id: number; areaMm2: number }[]
    shortEdges: { count: number; minLengthMm: number | null; thresholdMm: number }
    mergeableFaces: number
    clean: boolean
  }
  faces: { id: number; areaMm2: number; centroidMm: number[]; normal: number[] }[]
  namedGroups: { name: string; faceIds: number[] }[]
  facesJsonPath: string | null
}

/** Canonical value of cae_geometry: the mode-discriminated union of the two branch receipts. */
export type GeometryReceipt = GeometryBuildReceipt | GeometryImportReceipt

/** Build the `cae_geometry` tool bound to one deployment configuration. */
export function defineCaeGeometryTool(config: Config) {
  return defineTool({
    name: 'cae_geometry',
    description: DESCRIPTION,
    parameters: {
      mode: {
        type: 'string', enum: ['build', 'import'], required: true,
        description: "Which geometry source: 'build' runs a build123d script; 'import' loads an external STEP file.",
      },
      script: { type: 'string', description: "build mode: build123d Python source; must define `part`, may define NAMED_FACES." },
      name: { type: 'string', description: "build mode: artifact stem; files become <name>.step. Defaults to \"part\"." },
      step: { type: 'string', description: "import mode: path to the .step file to import (mm)." },
      repair: { type: 'boolean', description: 'import mode: heal the geometry (ShapeFix + merge split faces) into a new *_clean.step. Default false.' },
      nameFaces: {
        type: 'array',
        items: {
          type: 'object', additionalProperties: false,
          properties: {
            faceId: { type: 'integer', required: true },
            name: { type: 'string', required: true, description: 'Alphanumeric/underscore group name, e.g. "fixed".' },
          },
        },
        description: 'import mode: face names assigned by faceId from the receipt table; writes the faces.json sidecar.',
      },
      facesJson: { type: 'string', description: 'import mode: sidecar path for nameFaces; pass it as facesJson to cae_mesh. Default <step stem>.faces.json.' },
    },
    output: {
      schema: {
        oneOf: [{
          type: 'object', additionalProperties: false,
          properties: {
            mode: { type: 'string', enum: ['build'], required: true },
            stepPath: { type: 'string', required: true },
            volumeMm3: { type: 'number', required: true },
            bboxMm: {
              type: 'object', additionalProperties: false, required: true,
              properties: {
                min: { type: 'array', items: { type: 'number' }, required: true },
                max: { type: 'array', items: { type: 'number' }, required: true },
              },
            },
            namedFaces: {
              type: 'array', required: true,
              items: {
                type: 'object', additionalProperties: false,
                properties: {
                  name: { type: 'string', required: true },
                  areaMm2: { type: 'number', required: true },
                  centroidMm: { type: 'array', items: { type: 'number' }, required: true },
                },
              },
            },
          },
        }, {
          type: 'object', additionalProperties: false,
          properties: {
            mode: { type: 'string', enum: ['import'], required: true },
            stepPath: { type: 'string', required: true },
            stepOut: { type: 'string', required: true },
            repaired: { type: 'boolean', required: true },
            repairedDelta: {
              oneOf: [{
                type: 'object', additionalProperties: false,
                properties: {
                  facesBefore: { type: 'integer', required: true },
                  facesAfter: { type: 'integer', required: true },
                  mergeableFacesRemaining: { type: 'integer', required: true },
                },
              }, { type: 'null' }], required: true,
            },
            checks: {
              type: 'object', additionalProperties: false, required: true,
              properties: {
                solidCount: { type: 'integer', required: true },
                faceCount: { type: 'integer', required: true },
                invalidSolids: { type: 'integer', required: true },
                freeEdges: { type: 'boolean', required: true },
                sliverFaces: {
                  type: 'array', required: true,
                  items: { type: 'object', additionalProperties: false, properties: {
                    id: { type: 'integer', required: true }, areaMm2: { type: 'number', required: true },
                  } },
                },
                shortEdges: {
                  type: 'object', additionalProperties: false, required: true,
                  properties: {
                    count: { type: 'integer', required: true },
                    minLengthMm: { oneOf: [{ type: 'number' }, { type: 'null' }], required: true },
                    thresholdMm: { type: 'number', required: true },
                  },
                },
                mergeableFaces: { type: 'integer', required: true },
                clean: { type: 'boolean', required: true },
              },
            },
            faces: {
              type: 'array', required: true,
              items: { type: 'object', additionalProperties: false, properties: {
                id: { type: 'integer', required: true },
                areaMm2: { type: 'number', required: true },
                centroidMm: { type: 'array', items: { type: 'number' }, required: true },
                normal: { type: 'array', items: { type: 'number' }, required: true },
              } },
            },
            namedGroups: {
              type: 'array', required: true,
              items: { type: 'object', additionalProperties: false, properties: {
                name: { type: 'string', required: true },
                faceIds: { type: 'array', items: { type: 'integer' }, required: true },
              } },
            },
            facesJsonPath: { oneOf: [{ type: 'string' }, { type: 'null' }], required: true },
          },
        }],
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.mode === 'build'
          ? `CAD part built: volume ${value.volumeMm3.toFixed(3)} mm³, bbox `
            + `${JSON.stringify(value.bboxMm)}${value.namedFaces.length ? `, named faces: ${value.namedFaces.map(f => f.name).join(', ')}` : ''}. STEP: ${value.stepPath}`
          : `STEP import ${value.repaired ? '(repaired) ' : ''}${value.checks.clean ? 'clean' : 'dirty'}: `
            + `${value.checks.solidCount} solid(s), ${value.checks.faceCount} faces`
            + (value.checks.mergeableFaces ? `, ${value.checks.mergeableFaces} mergeable split faces` : '')
            + (value.checks.sliverFaces.length ? `, ${value.checks.sliverFaces.length} sliver faces` : '')
            + (value.checks.shortEdges.count ? `, ${value.checks.shortEdges.count} short edges` : '')
            + `. Geometry: ${value.stepOut}`,
      }],
    },
    async execute(args, exec) {
      // Cross-validate at the merge boundary, once: every param belongs to
      // exactly one mode and each mode's own required params must be present.
      if (args.mode === 'build') {
        if (args.step !== undefined) throw new Error("'step' belongs to mode='import'")
        if (args.repair !== undefined) throw new Error("'repair' belongs to mode='import'")
        if (args.nameFaces !== undefined) throw new Error("'nameFaces' belongs to mode='import'")
        if (args.facesJson !== undefined) throw new Error("'facesJson' belongs to mode='import'")
        if (args.script === undefined) throw new Error("mode='build' requires 'script'")
        await ensureDeps(config, exec.signal, 'structural')
        const stem = args.name ?? 'part'
        const dir = resolve(config.workdir)
        const scriptFile = join(dir, `${stem}.cad.py`)
        const step = join(dir, `${stem}.step`)
        const facesJson = join(dir, `${stem}.faces.json`)
        await writeFile(scriptFile, args.script, 'utf8')
        const { receipt } = await runStage(config, 'geometry',
          ['build', '--script-file', scriptFile, '--step', step, '--faces-json', facesJson],
          { signal: exec.signal, logFile: `${stem}.cad.log` })
        return { mode: 'build', ...receipt } as unknown as GeometryBuildReceipt
      }
      if (args.script !== undefined) throw new Error("'script' belongs to mode='build'")
      if (args.name !== undefined) throw new Error("'name' belongs to mode='build'")
      if (args.step === undefined) throw new Error("mode='import' requires 'step'")
      await ensureDeps(config, exec.signal, 'structural')
      const stepAbs = resolve(args.step)
      const facesJson = args.facesJson ?? stepAbs.replace(/\.step$/i, '') + '.faces.json'
      const argv = ['import', '--step', stepAbs]
      if (args.repair) argv.push('--repair')
      if (args.nameFaces?.length) {
        argv.push('--name-faces', JSON.stringify(args.nameFaces.map(f => ({ faceId: f.faceId, name: f.name }))))
      }
      argv.push('--faces-json', facesJson)
      const { receipt } = await runStage(config, 'geometry', argv,
        { signal: exec.signal, logFile: 'step_import.log' })
      return { mode: 'import', ...receipt } as unknown as GeometryImportReceipt
    },
    presentCall: args => args.mode === 'import'
      ? { card: 'terminal', title: `STEP import${args.repair ? ' + repair' : ''}`, description: 'External geometry check' }
      : { card: 'generic', title: 'Build CAD part', kind: 'other', rawInput: { name: args.name ?? 'part' } },
  })
}
