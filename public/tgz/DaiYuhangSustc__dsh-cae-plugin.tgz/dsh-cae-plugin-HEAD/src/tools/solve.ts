// src/tools/solve.ts
import { access, writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { ensureDeps, runStage } from '../runner.js'
import { runtimeFor } from '../interpreter.js'
import type { Config } from '../config.js'

const DESCRIPTION =
  'Solve stage of the CAE chain behind one mode switch. mode="static" runs a CalculiX linear static '
  + 'solve on a solid mesh. Units: mm, N, MPa. Pass the mshPath returned by cae_mesh (solid mode); fix '
  + 'surfaces by group name (named via cae_geometry) and apply forces as total vectors [fx, fy, fz] '
  + 'spread over a group. A NON-ZERO exitCode is a domain outcome (e.g. divergence, singular matrix): '
  + 'read logTail, adjust mesh/loads/boundary conditions, retry. Returns deck/result paths and wall '
  + 'time; vtuPath is null when FRD conversion failed (frdPath stays usable). mode="steady" runs a '
  + 'steady incompressible laminar solve (simpleFoam-successor foamRun) on a cae_mesh fluid case. SI '
  + 'units: velocity m/s, kinematic viscosity m²/s, density kg/m³. converged=false is a normal '
  + 'outcome: raise iterations or override system/fvSolution\'s SIMPLE block (e.g. looser '
  + 'residualControl) and retry; exitCode!=0 carries logTail for diagnosis. mode="transient" marches '
  + 'REAL physical seconds (foamRun incompressibleFluid, Euler + PIMPLE) with a Courant-limited '
  + 'adaptive step; endTimeS/writeIntervalS are simulated seconds and writeIntervalS must divide '
  + 'endTimeS evenly so the final time is written; maxCourant (default 0.5) caps stability, or pass '
  + 'deltaTS to fix the step. Choose steady when only fully-developed/time-averaged quantities matter '
  + '— it is far cheaper; choose transient for startup transients, vortex shedding, or any '
  + 'time-history dependence — and recommend the choice to the user, the decision is theirs. '
  + 'densityKgM3 is echoed by both CFD modes — pass the same value to cae_post so kinematic pressure '
  + 'converts to Pa. overrides replace top-level entries in whitelisted case dicts, exactly and only.'

// -- Schema fragments shared with later tools (cae_verify et al.); they carry
//    NO `required` — owners add `required: true` where their tool demands it.
/** Linear-elastic material pair of the static branch (mm-N-MPa consistency). */
export const MATERIAL_PARAM = {
  type: 'object', additionalProperties: false,
  properties: {
    youngMPa: { type: 'number', description: "Young's modulus in MPa (steel ≈ 210000)." },
    poisson: { type: 'number', description: "Poisson's ratio (steel ≈ 0.3)." },
  },
} as const
/** Boundary conditions of the static branch: surface groups to constrain. */
export const CONSTRAINTS_PARAM = {
  type: 'array',
  items: {
    type: 'object', additionalProperties: false,
    properties: {
      groupName: { type: 'string' },
      kind: { type: 'string', enum: ['fixed'] },
    },
  },
} as const
/** Point loads of the static branch: total force vectors spread over group nodes. */
export const LOADS_PARAM = {
  type: 'array',
  items: {
    type: 'object', additionalProperties: false,
    properties: {
      groupName: { type: 'string' },
      vectorN: { type: 'array', items: { type: 'number' }, description: 'Total force [fx, fy, fz] in N.' },
    },
  },
} as const
/** Inlet velocity [u, v, w] in m/s of the CFD branches. */
export const INLET_VELOCITY_PARAM = {
  type: 'array', items: { type: 'number' },
  description: 'Inlet velocity [u, v, w] in m/s.',
} as const
/** Kinematic viscosity of the CFD branches. */
export const NU_PARAM = {
  type: 'number',
  description: 'Kinematic viscosity ν in m²/s (water ≈ 1e-6, air ≈ 1.5e-5).',
} as const
/** Density of the CFD branches, echoed for cae_post. */
export const RHO_PARAM = {
  type: 'number',
  description: 'Density kg/m³, echoed for cae_post. Default 1.',
} as const
// mirror of CASE_DICT_FILES in python/dsh_cae/shared/cfd_case.py — change both in one commit
/** Case dict files an override may touch (case-rooted, exact membership). */
export const OVERRIDE_FILES = [
  'system/controlDict', 'system/fvSchemes', 'system/fvSolution',
  'system/blockMeshDict', 'constant/physicalProperties', 'constant/momentumTransport',
] as const
/** Exact top-level entry replacements applied to whitelisted case dicts before a solve. */
export const OVERRIDES_PARAM = {
  type: 'array',
  items: {
    type: 'object', additionalProperties: false,
    properties: {
      file: { type: 'string', enum: [...OVERRIDE_FILES] },
      entry: { type: 'string', description: 'Top-level entry to replace, e.g. endTime or SIMPLE.' },
      dict: { type: 'string', description: 'Full replacement text including the entry name and trailing ";".' },
    },
  },
  description: 'Exact top-level entry replacements applied before the solve.',
} as const
/** CFD case directory produced by cae_mesh (fluid mode). */
export const CASE_DIR_PARAM = {
  type: 'string',
  description: 'caseDir from cae_mesh (fluid mode).',
} as const

/** Receipt shape of the static branch (CalculiX solve), pinned for the tool's output schema. */
export interface StaticSolveReceipt {
  mode: 'static'
  inpPath: string
  frdPath: string
  vtuPath: string | null
  exitCode: number
  wallMs: number
  logTail: string
}

/** Receipt shape of the steady branch (foamRun simpleFoam successor), pinned for the output schema. */
export interface CfdSteadyReceipt {
  mode: 'steady'
  caseDir: string
  logPath: string
  vtkPath: string | null
  iterationsRun: number
  converged: boolean
  finalResiduals: { p: number | null; U: number | null }
  wallMs: number
  exitCode: number
  logTail: string
  densityKgM3: number
}

/** Receipt shape of the transient branch (foamRun PIMPLE march), pinned for the output schema. */
export interface CfdTransientReceipt {
  mode: 'transient'
  caseDir: string
  logPath: string
  vtkPath: string | null
  timeStepsRun: number
  simTimeS: number
  endTimeS: number
  maxCourantSeen: number | null
  finalResiduals: { p: number | null; U: number | null }
  wallMs: number
  exitCode: number
  logTail: string
  densityKgM3: number
}

/** Canonical value of cae_solve: the mode-discriminated union of the three branch receipts. */
export type SolveReceipt = StaticSolveReceipt | CfdSteadyReceipt | CfdTransientReceipt

/** Build the `cae_solve` tool bound to one deployment configuration. */
export function defineCaeSolveTool(config: Config) {
  return defineTool({
    name: 'cae_solve',
    description: DESCRIPTION,
    parameters: {
      mode: {
        type: 'string', enum: ['static', 'steady', 'transient'], required: true,
        description: "Which solver: 'static' runs CalculiX ccx on a solid mesh; 'steady' and 'transient' run foamRun on a cae_mesh fluid case.",
      },
      msh: { type: 'string', description: 'static mode: path to the .msh file from cae_mesh (solid mode).' },
      material: MATERIAL_PARAM,
      constraints: CONSTRAINTS_PARAM,
      loads: LOADS_PARAM,
      script: { type: 'string', description: 'static mode: extra CalculiX INP keywords appended before *STEP (advanced).' },
      case: { type: 'string', description: 'Artifact stem: static writes <case>.inp/.frd/.vtu under the workdir, CFD modes name logs/VTK inside the case. Defaults "case"/"run".' },
      caseDir: CASE_DIR_PARAM,
      inletVelocityMS: INLET_VELOCITY_PARAM,
      kinematicViscosityM2S: NU_PARAM,
      densityKgM3: RHO_PARAM,
      iterations: { type: 'integer', description: 'steady mode: iteration (endTime) cap. Default 2000.' },
      endTimeS: { type: 'number', description: 'transient mode: simulated physical seconds to march.' },
      maxCourant: { type: 'number', description: 'transient mode: Courant cap for the adaptive step. Default 0.5.' },
      deltaTS: { type: 'number', description: 'transient mode: fixed time step in s; disables the Courant-limited adaptive step.' },
      writeIntervalS: { type: 'number', description: 'transient mode: result write interval in simulated seconds; must divide endTimeS evenly so the final time is written.' },
      overrides: OVERRIDES_PARAM,
    },
    output: {
      schema: {
        oneOf: [{
          type: 'object', additionalProperties: false,
          properties: {
            mode: { type: 'string', enum: ['static'], required: true },
            inpPath: { type: 'string', required: true },
            frdPath: { type: 'string', required: true },
            vtuPath: { oneOf: [{ type: 'string' }, { type: 'null' }], required: true },
            exitCode: { type: 'integer', required: true },
            wallMs: { type: 'integer', required: true },
            logTail: { type: 'string', required: true },
          },
        }, {
          type: 'object', additionalProperties: false,
          properties: {
            mode: { type: 'string', enum: ['steady'], required: true },
            caseDir: { type: 'string', required: true },
            logPath: { type: 'string', required: true },
            vtkPath: { oneOf: [{ type: 'string' }, { type: 'null' }], required: true },
            iterationsRun: { type: 'integer', required: true },
            converged: { type: 'boolean', required: true },
            finalResiduals: {
              type: 'object', additionalProperties: false, required: true,
              properties: {
                p: { oneOf: [{ type: 'number' }, { type: 'null' }], required: true },
                U: { oneOf: [{ type: 'number' }, { type: 'null' }], required: true },
              },
            },
            wallMs: { type: 'integer', required: true },
            exitCode: { type: 'integer', required: true },
            logTail: { type: 'string', required: true },
            densityKgM3: { type: 'number', required: true },
          },
        }, {
          type: 'object', additionalProperties: false,
          properties: {
            mode: { type: 'string', enum: ['transient'], required: true },
            caseDir: { type: 'string', required: true },
            logPath: { type: 'string', required: true },
            vtkPath: { oneOf: [{ type: 'string' }, { type: 'null' }], required: true },
            timeStepsRun: { type: 'integer', required: true },
            simTimeS: { type: 'number', required: true },
            endTimeS: { type: 'number', required: true },
            maxCourantSeen: { oneOf: [{ type: 'number' }, { type: 'null' }], required: true },
            finalResiduals: {
              type: 'object', additionalProperties: false, required: true,
              properties: {
                p: { oneOf: [{ type: 'number' }, { type: 'null' }], required: true },
                U: { oneOf: [{ type: 'number' }, { type: 'null' }], required: true },
              },
            },
            wallMs: { type: 'integer', required: true },
            exitCode: { type: 'integer', required: true },
            logTail: { type: 'string', required: true },
            densityKgM3: { type: 'number', required: true },
          },
        }],
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.mode === 'static'
          ? `ccx exit ${value.exitCode} in ${value.wallMs} ms${value.exitCode === 0 ? ' (converged)' : ' — inspect logTail and retry'}. `
            + `Results: ${value.vtuPath ?? value.frdPath}`
          : value.mode === 'steady'
            ? `foamRun exit ${value.exitCode} — `
              + (value.converged
                ? `converged in ${value.iterationsRun} iterations`
                : `NOT converged after ${value.iterationsRun} iterations (p ${value.finalResiduals.p ?? 'n/a'}, `
                  + `U ${value.finalResiduals.U ?? 'n/a'}) — raise iterations or override SIMPLE`)
              + `. Results: ${value.vtkPath ?? value.logPath}`
            : `foamRun exit ${value.exitCode} — marched ${value.simTimeS} of ${value.endTimeS} s `
              + `in ${value.timeStepsRun} steps, max Co ${value.maxCourantSeen ?? 'n/a'}. `
              + `Results: ${value.vtkPath ?? value.logPath}`,
      }],
      // Terminal result card (all three branches are solver runs): exit-code
      // pill + log tail, ported from the v0.4 solve/cfd-steady/cfd-transient
      // tools the merge folded in here.
      presentationMeta: (_args, value) => ({ exitCode: value.exitCode, logTail: value.logTail }),
    },
    async execute(args, exec) {
      // Cross-validate at the merge boundary, once: every param belongs to
      // exactly one mode and each mode's own required params must be present.
      if (args.mode === 'static') {
        for (const p of ['caseDir', 'inletVelocityMS', 'kinematicViscosityM2S', 'densityKgM3',
          'iterations', 'overrides', 'endTimeS', 'maxCourant', 'deltaTS', 'writeIntervalS'] as const) {
          if (args[p] !== undefined) throw new Error(`'${p}' belongs to mode='steady'|'transient'`)
        }
        if (args.msh === undefined || args.material === undefined
          || !args.constraints?.length || !args.loads?.length) {
          throw new Error("mode='static' requires 'msh', 'material', 'constraints' and 'loads'")
        }
        // Cheap shape validation first (verify.ts's order); ensureDeps and the
        // subprocess only run once the arguments are fully well-formed.
        const stem = args.case ?? 'case'
        if (stem.includes('/') || stem.includes('\\')) {
          throw new Error(`case stem '${stem}' must not contain path separators`)
        }
        const dir = resolve(config.workdir)
        const casePath = join(dir, stem)
        if (args.material.youngMPa === undefined || args.material.poisson === undefined) {
          throw new Error("'material' requires 'youngMPa' and 'poisson'")
        }
        for (const c of args.constraints) {
          if (c.groupName === undefined) throw new Error("each constraint requires a 'groupName'")
          if (c.kind !== 'fixed') throw new Error(`unsupported constraint kind '${c.kind}'`)
        }
        for (const l of args.loads) {
          if (l.groupName === undefined || l.vectorN === undefined) {
            throw new Error("each load requires a 'groupName' and a 'vectorN'")
          }
          if (l.vectorN.length !== 3) {
            throw new Error(`load vectorN must be [fx, fy, fz], got ${JSON.stringify(l.vectorN)}`)
          }
        }
        await ensureDeps(config, exec.signal, 'structural')
        const argv = ['static', '--msh', args.msh, '--case', casePath,
          '--young-mpa', String(args.material.youngMPa), '--poisson', String(args.material.poisson)]
        // Non-null: the validation loops above guarantee these (same idiom as verify.ts).
        for (const c of args.constraints) argv.push('--fixed-group', c.groupName!)
        for (const l of args.loads) argv.push('--load-group', l.groupName!, '--load-n', l.vectorN!.join(','))
        if (args.script) {
          const scriptFile = join(dir, `${stem}.patch.inp`)
          await writeFile(scriptFile, args.script, 'utf8')
          argv.push('--script-file', scriptFile)
        }
        const { receipt } = await runStage(config, 'solve', argv,
          { signal: exec.signal, logFile: `${stem}.solve.log` })
        return { mode: 'static', ...receipt } as unknown as StaticSolveReceipt
      }
      for (const p of ['msh', 'material', 'constraints', 'loads', 'script'] as const) {
        if (args[p] !== undefined) throw new Error(`'${p}' belongs to mode='static'`)
      }
      if (args.mode === 'steady') {
        for (const p of ['endTimeS', 'maxCourant', 'deltaTS', 'writeIntervalS'] as const) {
          if (args[p] !== undefined) throw new Error(`'${p}' belongs to mode='transient'`)
        }
        if (args.caseDir === undefined || args.inletVelocityMS === undefined
          || args.kinematicViscosityM2S === undefined) {
          throw new Error("mode='steady' requires 'caseDir', 'inletVelocityMS' and 'kinematicViscosityM2S'")
        }
        if (args.inletVelocityMS.length !== 3) {
          throw new Error(`inletVelocityMS must be [u, v, w], got ${JSON.stringify(args.inletVelocityMS)}`)
        }
        const iterations = args.iterations ?? 2000
        if (!Number.isInteger(iterations) || iterations <= 0) {
          throw new Error(`iterations must be a positive integer, got ${iterations}`)
        }
        const stem = args.case ?? 'run'
        if (stem.includes('/') || stem.includes('\\')) {
          throw new Error(`case stem '${stem}' must not contain path separators`)
        }
        const caseDir = resolve(args.caseDir)
        try {
          await access(caseDir)
        } catch {
          throw new Error(`caseDir '${caseDir}' does not exist — pass the caseDir returned by cae_mesh`)
        }
        await ensureDeps(config, exec.signal, 'cfd')
        const argv = [
          'steady',
          '--case-dir', caseDir,
          '--velocity', args.inletVelocityMS.join(','),
          '--nu', String(args.kinematicViscosityM2S),
          '--rho', String(args.densityKgM3 ?? 1),
          '--iterations', String(iterations),
          '--case', stem,
        ]
        if (args.overrides?.length) {
          const ovrFile = join(caseDir, `${stem}.overrides.json`)
          await writeFile(ovrFile, JSON.stringify(args.overrides), 'utf8')
          argv.push('--overrides-file', ovrFile)
        }
        // Host bashrc paths don't exist inside the container; the image's
        // OpenFOAM is auto-detected (see runner.ts's identical guard).
        if (config.openfoamBashrc && runtimeFor(config).kind !== 'docker') {
          argv.push('--bashrc', config.openfoamBashrc)
        }
        const { receipt } = await runStage(config, 'solve', argv,
          { signal: exec.signal, logFile: `cfd.${stem}.steady.log` })
        return { mode: 'steady', ...receipt } as unknown as CfdSteadyReceipt
      }
      if (args.iterations !== undefined) throw new Error("'iterations' belongs to mode='steady'")
      if (args.caseDir === undefined || args.inletVelocityMS === undefined
        || args.kinematicViscosityM2S === undefined || args.endTimeS === undefined
        || args.writeIntervalS === undefined) {
        throw new Error(
          "mode='transient' requires 'caseDir', 'inletVelocityMS', 'kinematicViscosityM2S', 'endTimeS' and 'writeIntervalS'")
      }
      if (args.inletVelocityMS.length !== 3) {
        throw new Error(`inletVelocityMS must be [u, v, w], got ${JSON.stringify(args.inletVelocityMS)}`)
      }
      const endTimeS = args.endTimeS
      if (!(endTimeS > 0)) {
        throw new Error(`endTimeS must be a positive number, got ${endTimeS}`)
      }
      const writeIntervalS = args.writeIntervalS
      if (!(writeIntervalS > 0) || writeIntervalS > endTimeS) {
        throw new Error(`writeIntervalS must be in (0, endTimeS], got ${writeIntervalS}`)
      }
      // foamRun overshoots a non-divisor endTime (adjustableRunTime never lands
      // on it) and the final state is never written — foamToVTK then converts an
      // earlier time while the receipt still reports endTimeS.
      const ratio = endTimeS / writeIntervalS
      if (Math.abs(ratio - Math.round(ratio)) > 1e-9) {
        throw new Error(
          `writeIntervalS ${writeIntervalS} does not divide endTimeS ${endTimeS} — `
          + 'choose a writeIntervalS that divides endTimeS evenly so the final time is written')
      }
      const maxCourant = args.maxCourant ?? 0.5
      if (args.deltaTS === undefined && !(maxCourant > 0)) {
        throw new Error(`maxCourant must be positive when deltaTS is not set, got ${maxCourant}`)
      }
      if (args.deltaTS !== undefined && !(args.deltaTS > 0)) {
        throw new Error(`deltaTS must be a positive number, got ${args.deltaTS}`)
      }
      const stem = args.case ?? 'run'
      if (stem.includes('/') || stem.includes('\\')) {
        throw new Error(`case stem '${stem}' must not contain path separators`)
      }
      const caseDir = resolve(args.caseDir)
      try {
        await access(caseDir)
      } catch {
        throw new Error(`caseDir '${caseDir}' does not exist — pass the caseDir returned by cae_mesh`)
      }
      await ensureDeps(config, exec.signal, 'cfd')
      const argv = [
        'transient',
        '--case-dir', caseDir,
        '--velocity', args.inletVelocityMS.join(','),
        '--nu', String(args.kinematicViscosityM2S),
        '--rho', String(args.densityKgM3 ?? 1),
        '--end-time-s', String(endTimeS),
        '--max-co', String(maxCourant),
        '--write-interval-s', String(writeIntervalS),
        '--case', stem,
      ]
      if (args.deltaTS !== undefined) argv.push('--delta-t', String(args.deltaTS))
      if (args.overrides?.length) {
        const ovrFile = join(caseDir, `${stem}.overrides.json`)
        await writeFile(ovrFile, JSON.stringify(args.overrides), 'utf8')
        argv.push('--overrides-file', ovrFile)
      }
      // Host bashrc paths don't exist inside the container; the image's
      // OpenFOAM is auto-detected (see runner.ts's identical guard).
      if (config.openfoamBashrc && runtimeFor(config).kind !== 'docker') {
        argv.push('--bashrc', config.openfoamBashrc)
      }
      const { receipt } = await runStage(config, 'solve', argv,
        { signal: exec.signal, logFile: `cfd.${stem}.transient.log` })
      return { mode: 'transient', ...receipt } as unknown as CfdTransientReceipt
    },
    presentCall: args => args.mode === 'static'
      ? { card: 'terminal', title: `ccx ${args.case ?? 'case'}`, description: 'CalculiX static solve' }
      : args.mode === 'steady'
        ? { card: 'terminal', title: `foamRun ${args.case ?? 'run'}`, description: 'Steady incompressible solve' }
        : { card: 'terminal', title: `foamRun ${args.case ?? 'run'}`, description: 'Transient incompressible solve' },
    presentResult: (_args, { meta }) => {
      const m = meta as { exitCode?: number; logTail?: string } | undefined
      return {
        card: 'terminal',
        output: m?.logTail ?? '',
        exitCode: m?.exitCode ?? -1,
      }
    },
  })
}
