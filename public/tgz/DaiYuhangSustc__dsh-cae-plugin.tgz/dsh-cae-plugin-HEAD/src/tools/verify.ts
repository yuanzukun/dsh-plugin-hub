// src/tools/verify.ts
import { resolve } from 'node:path'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { InferArgs, ParameterSchemaSpec } from '@deepseek-ai/dsh-tools'
import { ensureDeps, runStage } from '../runner.js'
import { runtimeFor } from '../interpreter.js'
import { gci } from '../gci.js'
import type { GciLevel } from '../gci.js'
import type { Config } from '../config.js'
import { STEP_PARAM, FACES_JSON_PARAM, DUCT_GEOMETRY_PARAMS, WALL_GRADING_PARAM } from './mesh.js'
import { MATERIAL_PARAM, CONSTRAINTS_PARAM, LOADS_PARAM, INLET_VELOCITY_PARAM, NU_PARAM, RHO_PARAM } from './solve.js'

const DESCRIPTION =
  'Mesh-independence study (stage-5 verification): re-mesh at 3+ sizes, run the identical '
  + 'solve at every level, extract one monitored metric, and report the Richardson observed '
  + 'order + GCI (Celik 2008) with a threshold verdict. chain="structural" needs the same '
  + 'inputs as cae_solve (static mode) plus elementSizesMm; chain="cfd" re-meshes the '
  + 'parametric duct of cae_mesh (fluid mode) at cellSizesMm and runs the cae_solve steady '
  + 'branch per level. The whole per-level loop runs inside one Python verify process (this '
  + 'is the MOST EXPENSIVE tool — a full mesh+solve per size, so its stage timeout is scaled '
  + 'by 3×levels). A CFD level that does not converge fails the study (retry the level with '
  + 'cae_solve steady and looser SIMPLE residualControl overrides first); oscillatory '
  + 'convergence reports meshIndependent=false because the numbers cannot be trusted. '
  + 'meshIndependent=true when the fine-grid GCI is within gciThresholdPercent (default 3%).'

/** Receipt of cae_verify: per-level table + the GCI study + a verdict. */
export interface VerifyReceipt {
  chain: 'structural' | 'cfd'
  metric: string
  levels: { sizeMm: number; count: number; metricValue: number }[]
  refinementRatios: { r21: number; r32: number }
  convergenceState: 'monotonic' | 'oscillatory'
  observedOrder: number | null
  richardsonExtrapolated: number | null
  gciFinePercent: number | null
  gciCoarsePercent: number | null
  meshIndependent: boolean
  thresholdPercent: number
  recommendation: string
}

type LevelRow = VerifyReceipt['levels'][number]

// No manual mirroring: every branch input is the shared fragment the owning
// tool exports — cae_verify only adds the chain switch and the size lists.
const PARAMETERS = {
  chain: { type: 'string', enum: ['structural', 'cfd'], required: true, description: 'Which chain to study.' },
  elementSizesMm: { type: 'array', items: { type: 'number' }, description: 'structural: ≥3 strictly monotonic element sizes, e.g. [8, 5, 3].' },
  cellSizesMm: { type: 'array', items: { type: 'number' }, description: 'cfd: ≥3 strictly monotonic cell sizes.' },
  metric: {
    type: 'string', enum: ['maxVonMises', 'maxDisplacement', 'maxVelocityMS', 'pressureDropPa'],
    description: 'Monitored scalar. Default maxVonMises (structural) / maxVelocityMS (cfd).',
  },
  gciThresholdPercent: { type: 'number', description: 'Fine-grid GCI percent below which the mesh counts as independent. Default 3.' },
  step: STEP_PARAM,
  facesJson: FACES_JSON_PARAM,
  material: MATERIAL_PARAM,
  constraints: CONSTRAINTS_PARAM,
  loads: LOADS_PARAM,
  ...DUCT_GEOMETRY_PARAMS,
  wallGrading: WALL_GRADING_PARAM,
  inletVelocityMS: INLET_VELOCITY_PARAM,
  kinematicViscosityM2S: NU_PARAM,
  densityKgM3: RHO_PARAM,
} satisfies ParameterSchemaSpec

/** The tool's inferred argument object type. */
type VerifyArgs = InferArgs<typeof PARAMETERS>

/** Build the `cae_verify` tool bound to one deployment configuration. */
export function defineCaeVerifyTool(config: Config) {
  return defineTool({
    name: 'cae_verify',
    description: DESCRIPTION,
    parameters: PARAMETERS,
    output: {
      schema: {
        type: 'object', additionalProperties: false,
        properties: {
          chain: { type: 'string', required: true },
          metric: { type: 'string', required: true },
          levels: {
            type: 'array', required: true,
            items: { type: 'object', additionalProperties: false, properties: {
              sizeMm: { type: 'number', required: true },
              count: { type: 'number', required: true },
              metricValue: { type: 'number', required: true },
            } },
          },
          refinementRatios: {
            type: 'object', additionalProperties: false, required: true,
            properties: { r21: { type: 'number', required: true }, r32: { type: 'number', required: true } },
          },
          convergenceState: { type: 'string', enum: ['monotonic', 'oscillatory'], required: true },
          observedOrder: { oneOf: [{ type: 'number' }, { type: 'null' }], required: true },
          richardsonExtrapolated: { oneOf: [{ type: 'number' }, { type: 'null' }], required: true },
          gciFinePercent: { oneOf: [{ type: 'number' }, { type: 'null' }], required: true },
          gciCoarsePercent: { oneOf: [{ type: 'number' }, { type: 'null' }], required: true },
          meshIndependent: { type: 'boolean', required: true },
          thresholdPercent: { type: 'number', required: true },
          recommendation: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: `mesh ${value.meshIndependent ? 'INDEPENDENT' : 'NOT independent'} `
          + `(GCI_fine ${value.gciFinePercent ?? 'n/a'}% vs ${value.thresholdPercent}% threshold, `
          + `order ${value.observedOrder ?? 'n/a'}, ${value.convergenceState}). `
          + `${value.recommendation}`,
      }],
    },
    async execute(args, exec) {
      const isStructural = args.chain === 'structural'
      const sizesRaw = (isStructural ? args.elementSizesMm : args.cellSizesMm) ?? []
      const label = isStructural ? 'elementSizesMm' : 'cellSizesMm'
      if (sizesRaw.length < 3) {
        throw new Error(`need at least 3 ${label} for a GCI study, got ${sizesRaw.length}`)
      }
      if (!sizesRaw.every((s, i) => i === 0 || Math.abs(s - sizesRaw[i - 1]) > 1e-12)
          || new Set(sizesRaw.slice(1).map((s, i) => Math.sign(s - sizesRaw[i]))).size > 1) {
        throw new Error(`${label} must be strictly monotonic`)
      }
      const metric = args.metric ?? (isStructural ? 'maxVonMises' : 'maxVelocityMS')
      // 链/指标组合必须匹配，否则静默测错量纲（结构链测压降、CFD 链测应力）
      if (isStructural && metric !== 'maxVonMises' && metric !== 'maxDisplacement') {
        throw new Error(`metric '${metric}' is not available on chain=structural — use maxVonMises or maxDisplacement`)
      }
      if (!isStructural && metric !== 'maxVelocityMS' && metric !== 'pressureDropPa') {
        throw new Error(`metric '${metric}' is not available on chain=cfd — use maxVelocityMS or pressureDropPa`)
      }
      if (metric === 'pressureDropPa' && typeof args.densityKgM3 !== 'number') {
        throw new Error('metric pressureDropPa requires densityKgM3 — without it the kinematic-pressure difference is off by a factor of ρ')
      }
      if (isStructural) {
        if (!args.step) throw new Error('chain=structural needs step')
        if (!args.material) throw new Error('chain=structural needs material')
        if (!args.constraints?.length) throw new Error('chain=structural needs at least one constraint')
        if (!args.loads?.length) throw new Error('chain=structural needs at least one load')
        for (const p of ['cellSizesMm', 'lengthMm', 'widthMm', 'heightMm', 'wallGrading',
          'inletVelocityMS', 'kinematicViscosityM2S', 'densityKgM3'] as const) {
          if (args[p] !== undefined) throw new Error(`'${p}' belongs to chain='cfd'`)
        }
        if (args.material.youngMPa === undefined || args.material.poisson === undefined) {
          throw new Error("'material' requires 'youngMPa' and 'poisson'")
        }
        for (const c of args.constraints) {
          if (c.groupName === undefined) throw new Error("each constraint requires a 'groupName'")
          if (c.kind !== 'fixed') throw new Error(`unsupported constraint kind '${c.kind}'`)
        }
        for (const l of args.loads) {
          if (l.groupName === undefined || l.vectorN === undefined) {
            throw new Error("each load requires a 'groupName' and a 'vectorN'")
          }
          if (l.vectorN.length !== 3) {
            throw new Error(`load vectorN must be [fx, fy, fz], got ${JSON.stringify(l.vectorN)}`)
          }
        }
      } else {
        if (![args.lengthMm, args.widthMm, args.heightMm].every(v => typeof v === 'number')) {
          throw new Error('chain=cfd needs lengthMm, widthMm, heightMm')
        }
        if (!args.inletVelocityMS || !args.kinematicViscosityM2S) {
          throw new Error('chain=cfd needs inletVelocityMS and kinematicViscosityM2S')
        }
        for (const p of ['elementSizesMm', 'step', 'facesJson', 'material', 'constraints', 'loads'] as const) {
          if (args[p] !== undefined) throw new Error(`'${p}' belongs to chain='structural'`)
        }
      }
      const threshold = args.gciThresholdPercent ?? 3
      const workdirAbs = resolve(config.workdir)
      await ensureDeps(config, exec.signal, isStructural ? 'structural' : 'cfd')

      const argv: string[] = isStructural
        ? [
            'structural',
            '--step', resolve(args.step!),
            '--element-sizes', sizesRaw.join(','),
            '--young-mpa', String(args.material!.youngMPa),
            '--poisson', String(args.material!.poisson),
            ...args.constraints!.flatMap(c => ['--fixed-group', c.groupName!]),
            // '=' form: a plain '--load-n -1000,0,0' would be eaten as an option flag
            ...args.loads!.flatMap(l => ['--load-group', l.groupName!, `--load-n=${l.vectorN!.join(',')}`]),
            '--metric', metric,
            '--workdir', workdirAbs,
          ]
        : [
            'cfd',
            '--length-mm', String(args.lengthMm!),
            '--width-mm', String(args.widthMm!),
            '--height-mm', String(args.heightMm!),
            '--cell-sizes', sizesRaw.join(','),
            '--wall-grading', String(args.wallGrading ?? 1),
            '--velocity', args.inletVelocityMS!.join(','),
            '--nu', String(args.kinematicViscosityM2S!),
            '--rho', String(args.densityKgM3 ?? 1),
            '--metric', metric,
            '--workdir', workdirAbs,
          ]
      if (args.facesJson) argv.push('--faces-json', resolve(args.facesJson))
      // Host bashrc paths don't exist inside the container; the image's
      // OpenFOAM is auto-detected (see runner.ts's identical guard).
      if (!isStructural && config.openfoamBashrc && runtimeFor(config).kind !== 'docker') {
        argv.push('--bashrc', config.openfoamBashrc)
      }

      // ONE process now runs the whole per-level loop (mesh+solve+post per
      // size) that previously was N separate stages — it needs the study's
      // total budget: ~2 stages of work per level plus slack ⇒ ×3 per size.
      const { receipt } = await runStage(config, 'verify', argv, {
        signal: exec.signal,
        logFile: `verify.${args.chain}.log`,
        timeoutMs: config.stageTimeoutMs * sizesRaw.length * 3,
      })

      const levels = receipt.levels as LevelRow[] | undefined
      if (!Array.isArray(levels) || levels.length === 0) {
        throw new Error('verify produced no levels')
      }
      // The Python study emits coarse→fine (contractual — the GCI study
      // consumes level order); a violated order means the protocol changed.
      for (const [i, l] of levels.entries()) {
        if (i > 0 && !(l.sizeMm < levels[i - 1].sizeMm)) {
          throw new Error('verify levels must be strictly size-descending (coarse→fine)')
        }
      }
      const study = gci(levels.map((l): GciLevel => ({ size: l.sizeMm, count: l.count, value: l.metricValue })), threshold)
      const recommendation = recommend(levels, study.richardsonExtrapolated, threshold)
      return { chain: args.chain, metric, levels, ...study, recommendation } as VerifyReceipt
    },
    presentCall: args => ({
      card: 'terminal', title: 'verify mesh', description: `mesh-independence study (${args.chain}, ${args.elementSizesMm?.length ?? args.cellSizesMm?.length ?? '?'} levels)`,
    }),
  })
}

/** Coarsest level already within threshold of the extrapolated metric. */
function recommend(levels: LevelRow[], extrapolated: number | null, thresholdPercent: number): string {
  if (extrapolated === null) {
    return 'grid convergence is oscillatory — do not trust any single level; inspect the levels table and refine between levels'
  }
  const pick = levels.find(l => Math.abs(l.metricValue - extrapolated) / Math.abs(extrapolated) * 100 <= thresholdPercent)
  if (!pick) {
    return `no level is within ${thresholdPercent}% of the extrapolated value — refine further and re-run`
  }
  return `${pick.sizeMm} mm is already within ${thresholdPercent}% of the extrapolated metric; finer levels add cost, not accuracy`
}
