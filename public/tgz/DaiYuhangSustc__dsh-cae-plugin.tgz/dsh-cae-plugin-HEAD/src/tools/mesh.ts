// src/tools/mesh.ts
import { mkdir, writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { ensureDeps, runStage } from '../runner.js'
import { runtimeFor } from '../interpreter.js'
import type { Config } from '../config.js'

const DESCRIPTION =
  'Mesh stage of the CAE chain. mode="solid" meshes a STEP solid with Gmsh second-order '
  + 'tetrahedra. Units are mm. Pass the stepPath returned by cae_geometry (build or import); '
  + 'named face groups are rebuilt automatically from the faces.json sidecar cae_geometry '
  + 'wrote next to the STEP. elementSizeMm is the target edge length (smaller = finer, more '
  + 'accurate, slower solve). Returns node/element counts, group names, and the minimum scaled '
  + 'Jacobian (quality; > 0.01 is healthy). mode="fluid" generates a CFD mesh for a rectangular '
  + 'duct with blockMesh and validates it with checkMesh. Geometry in mm; the chain converts to '
  + 'SI meters here and stays SI afterwards. Flow along +x, inlet at x-min; patches are named '
  + 'inlet/outlet/walls. Returns caseDir (pass to cae_solve), cell count, and mesh quality. '
  + 'checksPassed=false is a mesh-quality verdict, not an error: refine (smaller cellSizeMm) or '
  + 'use wallGrading, or supply blockMeshDict — full dict text (convertToMeters 1, patches must '
  + 'still be named inlet/outlet/walls) — for anything non-rectangular. checksPassed=null means '
  + 'the checkMesh output could not be parsed: read checkMeshLogPath yourself.'

// -- Schema fragments shared with later tools (cae_verify et al.); they carry
//    NO `required` — owners add `required: true` where their tool demands it.
/** STEP file input (mm) produced by cae_geometry. */
export const STEP_PARAM = { type: 'string', description: 'Path to the .step file.' } as const
/** faces.json sidecar written by cae_geometry nameFaces; named groups are rebuilt from it. */
export const FACES_JSON_PARAM = {
  type: 'string',
  description: 'Path to the faces.json sidecar next to the STEP; named face groups are rebuilt from it. Default <step stem>.faces.json.',
} as const
/** Parametric duct geometry (mm) of the fluid branch. */
export const DUCT_GEOMETRY_PARAMS = {
  lengthMm: { type: 'number', description: 'Duct length in mm (flow direction x).' },
  widthMm: { type: 'number', description: 'Cross-section width in mm (y).' },
  heightMm: { type: 'number', description: 'Cross-section height in mm (z).' },
} as const
/** Symmetric wall expansion ratio of the fluid branch. */
export const WALL_GRADING_PARAM = { type: 'number', description: 'Symmetric center-to-wall expansion ratio in y/z (1 = uniform). Default 1.' } as const
/** Target CFD cell edge of the fluid branch. */
export const CELL_SIZE_PARAM = { type: 'number', description: 'Target cell edge in mm; per-direction counts are rounded.' } as const

/** Receipt shape of the mesh solid branch (Gmsh tetra mesh), pinned for the tool's output schema. */
export interface MeshSolidReceipt {
  mode: 'solid'
  mshPath: string
  nodeCount: number
  elementCount: number
  groupNames: string[]
  quality: { minJacobian: number | null }
  /** Node-sharing component audit of the volume mesh (always emitted by solid.py). */
  connectivity: { components: number; totalElements: number; isolatedElements: number }
  /** Present only when connectivity.components > 1 (floating solids → singular solve). */
  warnings?: string[]
}

/** Receipt shape of the mesh fluid branch (blockMesh duct), pinned for the tool's output schema. */
export interface MeshFluidReceipt {
  mode: 'fluid'
  caseDir: string
  blockMeshDictPath: string
  boundsM: { min: number[]; max: number[] } | null
  cells: number | null
  maxNonOrthogonalityDeg: number | null
  maxAspectRatio: number | null
  checksPassed: boolean | null
  checkMeshLogPath: string
  logTail: string
}

/** Canonical value of cae_mesh: the mode-discriminated union of the two branch receipts. */
export type MeshReceipt = MeshSolidReceipt | MeshFluidReceipt

/** Build the `cae_mesh` tool bound to one deployment configuration. */
export function defineCaeMeshTool(config: Config) {
  return defineTool({
    name: 'cae_mesh',
    description: DESCRIPTION,
    parameters: {
      mode: {
        type: 'string', enum: ['solid', 'fluid'], required: true,
        description: "Which mesher: 'solid' runs Gmsh on a STEP file; 'fluid' lays a parametric blockMesh duct.",
      },
      step: STEP_PARAM,
      elementSizeMm: { type: 'number', description: 'solid mode: target element edge length in mm. Default 2.0.' },
      elementType: { type: 'string', enum: ['tet4', 'tet10'], description: 'solid mode: tet10 (default, quadratic) or tet4 (linear).' },
      minSizeMm: { type: 'number', description: 'solid mode: minimum edge length; default elementSizeMm/5.' },
      maxSizeMm: { type: 'number', description: 'solid mode: maximum edge length; default elementSizeMm.' },
      ...DUCT_GEOMETRY_PARAMS,
      wallGrading: WALL_GRADING_PARAM,
      cellSizeMm: CELL_SIZE_PARAM,
      blockMeshDict: { type: 'string', description: 'fluid mode: full blockMeshDict text (escape hatch); overrides the parametric geometry.' },
      name: { type: 'string', description: 'fluid mode: case directory name under <workdir>/cfd/. Default "duct".' },
    },
    output: {
      schema: {
        oneOf: [{
          type: 'object', additionalProperties: false,
          properties: {
            mode: { type: 'string', enum: ['solid'], required: true },
            mshPath: { type: 'string', required: true },
            nodeCount: { type: 'integer', required: true },
            elementCount: { type: 'integer', required: true },
            groupNames: { type: 'array', items: { type: 'string' }, required: true },
            quality: {
              type: 'object', additionalProperties: false, required: true,
              properties: {
                minJacobian: {
                  oneOf: [{ type: 'number' }, { type: 'null' }],
                  required: true,
                  description: 'Minimum scaled Jacobian; null when no element admits the measure.',
                },
              },
            },
            connectivity: {
              type: 'object', additionalProperties: false, required: true,
              properties: {
                components: { type: 'integer', required: true, description: 'Node-sharing components among volume elements.' },
                totalElements: { type: 'integer', required: true },
                isolatedElements: { type: 'integer', required: true, description: 'Elements outside the largest component.' },
              },
            },
            warnings: {
              type: 'array', items: { type: 'string' },
              description: 'Emitted only when components > 1: floating solids make a downstream static solve singular.',
            },
          },
        }, {
          type: 'object', additionalProperties: false,
          properties: {
            mode: { type: 'string', enum: ['fluid'], required: true },
            caseDir: { type: 'string', required: true },
            blockMeshDictPath: { type: 'string', required: true },
            boundsM: {
              oneOf: [{
                type: 'object', additionalProperties: false, properties: {
                  min: { type: 'array', items: { type: 'number' }, required: true },
                  max: { type: 'array', items: { type: 'number' }, required: true },
                },
              }, { type: 'null' }], required: true,
            },
            cells: { oneOf: [{ type: 'integer' }, { type: 'null' }], required: true },
            maxNonOrthogonalityDeg: { oneOf: [{ type: 'number' }, { type: 'null' }], required: true },
            maxAspectRatio: { oneOf: [{ type: 'number' }, { type: 'null' }], required: true },
            checksPassed: { oneOf: [{ type: 'boolean' }, { type: 'null' }], required: true },
            checkMeshLogPath: { type: 'string', required: true },
            logTail: { type: 'string', required: true },
          },
        }],
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.mode === 'solid'
          ? `Meshed: ${value.nodeCount} nodes, ${value.elementCount} elements, groups `
            + `${value.groupNames.join(', ')}, min scaled Jacobian ${value.quality.minJacobian ?? 'n/a'}. MSH: ${value.mshPath}`
          : `blockMesh: ${value.cells ?? '?'} cells, max non-orthogonality `
            + `${value.maxNonOrthogonalityDeg ?? 'n/a'}°, max aspect ${value.maxAspectRatio ?? 'n/a'}, checks `
            + `${value.checksPassed === null ? 'unparsed — read checkMeshLogPath' : value.checksPassed ? 'OK' : 'FAILED (refine or escape via blockMeshDict)'}. `
            + `Case: ${value.caseDir}`,
      }],
    },
    async execute(args, exec) {
      // Cross-validate at the merge boundary, once: every param belongs to
      // exactly one mode and each mode's own required params must be present.
      if (args.mode === 'solid') {
        for (const p of ['lengthMm', 'widthMm', 'heightMm', 'cellSizeMm', 'wallGrading', 'blockMeshDict', 'name'] as const) {
          if (args[p] !== undefined) throw new Error(`'${p}' belongs to mode='fluid'`)
        }
        if (args.step === undefined) throw new Error("mode='solid' requires 'step'")
        await ensureDeps(config, exec.signal, 'structural')
        const stem = resolve(args.step).replace(/\.step$/, '')
        const argv = [
          'solid',
          '--step', `${stem}.step`,
          '--faces-json', `${stem}.faces.json`,
          '--msh', `${stem}.msh`,
          '--element-size', String(args.elementSizeMm ?? 2.0),
          '--element-type', args.elementType ?? 'tet10',
        ]
        if (args.minSizeMm) argv.push('--min-size', String(args.minSizeMm))
        if (args.maxSizeMm) argv.push('--max-size', String(args.maxSizeMm))
        const { receipt } = await runStage(config, 'mesh', argv,
          { signal: exec.signal, logFile: `${stem.split('/').pop()}.mesh.log` })
        return { mode: 'solid', ...receipt } as unknown as MeshSolidReceipt
      }
      for (const p of ['step', 'elementSizeMm', 'elementType', 'minSizeMm', 'maxSizeMm'] as const) {
        if (args[p] !== undefined) throw new Error(`'${p}' belongs to mode='solid'`)
      }
      if (args.lengthMm === undefined || args.widthMm === undefined
        || args.heightMm === undefined || args.cellSizeMm === undefined) {
        throw new Error("mode='fluid' requires 'lengthMm', 'widthMm', 'heightMm' and 'cellSizeMm'")
      }
      const name = args.name ?? 'duct'
      if (name.includes('/') || name.includes('\\') || name === '.' || name === '..') {
        throw new Error(`case name '${name}' must be a plain directory name`)
      }
      await ensureDeps(config, exec.signal, 'cfd')
      const workdirAbs = resolve(config.workdir)
      await mkdir(join(workdirAbs, 'cfd'), { recursive: true })
      const argv = [
        'fluid',
        '--workdir', workdirAbs,
        '--name', name,
        '--length-mm', String(args.lengthMm),
        '--width-mm', String(args.widthMm),
        '--height-mm', String(args.heightMm),
        '--cell-size-mm', String(args.cellSizeMm),
        '--wall-grading', String(args.wallGrading ?? 1),
      ]
      if (args.blockMeshDict) {
        const dictFile = join(workdirAbs, 'cfd', `${name}.blockMeshDict.txt`)
        await writeFile(dictFile, args.blockMeshDict, 'utf8')
        argv.push('--block-mesh-dict-file', dictFile)
      }
      // Host bashrc paths don't exist inside the container; the image's
      // OpenFOAM is auto-detected (see runner.ts's identical guard).
      if (config.openfoamBashrc && runtimeFor(config).kind !== 'docker') {
        argv.push('--bashrc', config.openfoamBashrc)
      }
      const { receipt } = await runStage(config, 'mesh', argv,
        { signal: exec.signal, logFile: `cfd.${name}.mesh.log` })
      return { mode: 'fluid', ...receipt } as unknown as MeshFluidReceipt
    },
    presentCall: args => args.mode === 'fluid'
      ? { card: 'terminal', title: `blockMesh ${args.name ?? 'duct'}`, description: 'CFD duct mesh' }
      : { card: 'generic', title: 'Generate mesh', kind: 'other', rawInput: { step: args.step } },
  })
}
