# MODULES.md —— 模块清单

> **新功能开工前先查本表**：已有模块能解决的事，禁止新写。
> **新模块必须登记**：一行 = 模块 | 做什么 | 从哪里调用。只登记真实存在且被真实调用的模块，模块删除时同步删行。

## Python 领域层（python/dsh_cae/）

| 模块 | 做什么 | 从哪里调用 |
| --- | --- | --- |
| `dsh_cae.geometry`（`build.py` + `step_import.py`） | build123d 脚本建模导出 STEP / 外部 STEP 校验、愈合、面命名，产出面指纹 sidecar | TS `cae_geometry`（`python -m dsh_cae.geometry build\|import`） |
| `dsh_cae.mesh`（`solid.py` + `fluid.py`） | 固体：Gmsh 四面体 + sidecar 重建命名组；流体：参数化 blockMesh 管道 case（mm→m 唯一转换点）；导出领域函数 `solid.generate` / `fluid.generate` | TS `cae_mesh`（`python -m dsh_cae.mesh solid\|fluid`）；进程内 `dsh_cae.verify` |
| `dsh_cae.solve`（`static.py` + `steady.py` + `transient.py`） | CalculiX 线性静力 / foamRun 稳态 / foamRun PIMPLE 瞬态；导出领域函数 `static.solve` / `steady.solve` | TS `cae_solve`（`python -m dsh_cae.solve static\|steady\|transient`）；进程内 `dsh_cae.verify` |
| `dsh_cae.post`（`extract.py`） | VTU/FRD 场极值、点探针、离屏云图 PNG；导出领域函数 `extract` | TS `cae_post`（`python -m dsh_cae.post`）；进程内 `dsh_cae.verify` |
| `dsh_cae.verify`（`structural.py` + `cfd.py`） | 网格无关性逐层研究（进程内循环调 mesh/solve/post），receipt 含 `{chain, metric, levels}` | TS `cae_verify`（`python -m dsh_cae.verify structural\|cfd`，单次 runStage + TS 侧 GCI） |
| `dsh_cae.shared.receipt` | stage receipt 协议：marker、`emit`、`fail`（=raise StageError）、`report_fail` | 全部五个领域包 + 各 `__main__` 分发器 |
| `dsh_cae.shared.deps` | 依赖自检（structural：Python 导入 + ccx；cfd：bashrc + 四个 foam 工具），带解释器与逐项导入错误诊断 | TS `runner.ts` 的 `ensureDeps`（`python -m dsh_cae.shared.deps --group ...`） |
| `dsh_cae.shared.cfd_case` | OpenFOAM case 组装全集：bashrc 解析、`foam_run`、dict 模板（稳态+瞬态）、顶层 override（白名单 `CASE_DICT_FILES`）、日志解析 | `dsh_cae.mesh`（fluid）、`dsh_cae.solve`（steady/transient）、`dsh_cae.shared.deps` |
| `dsh_cae.fixtures.fake_stage` | 测试桩：一个 stage 覆盖 runner 全部路径（ok/fail/sleep/no-receipt） | `tests/runner.test.ts`、`tests/interpreter.test.ts`、`tests/docker.e2e.ts` |

## TS 编排层（src/）

| 模块 | 做什么 | 从哪里调用 |
| --- | --- | --- |
| `src/runner.ts#runStage` | 唯一子进程边界：spawn `python -m dsh_cae.<stage>`、超时/abort 杀进程组、解析 marker receipt；域失败=receipt，仅基础设施失败 reject | 五个工具的 `execute()` 与 `ensureDeps` |
| `src/runner.ts#ensureDeps` | 每个配置对象每依赖组一次的依赖自检（调 `shared.deps`），失败带安装提示 | 五个工具的 `execute()`（按分支选 structural/cfd 组） |
| `src/interpreter.ts` | 解释器/docker 运行时解析（`python: auto` 探测 conda env `dsh-cae`）、`stageEnv` 环境清洗（conda lib/bin 前置，防 LD_LIBRARY_PATH 遮蔽）、docker argv/preflight/spawn env | `runner.ts`（唯一消费方） |
| `src/gci.ts#gci` | Celik 2008 网格收敛指数纯数学（细化比、观测阶、Richardson 外推、GCI、判决）——无 IO | `src/tools/verify.ts` |
| `src/config.ts` | `Config` 接口 + Schemastery 配置（python/workdir/stageTimeoutMs/openfoamBashrc） | `index.ts` 注册、全部工具与 runner |
| `src/tools/mesh.ts` 导出的 schema 片段（`STEP_PARAM`、`FACES_JSON_PARAM`、`DUCT_GEOMETRY_PARAMS`、`WALL_GRADING_PARAM`、`CELL_SIZE_PARAM`） | 属性级参数片段（不带 required，拥有者补） | `src/tools/verify.ts` 组合 cae_verify 的链参数；`CELL_SIZE_PARAM` 为 mesh fluid 分支自用 |
| `src/tools/solve.ts` 导出的 schema 片段（`MATERIAL_PARAM`、`CONSTRAINTS_PARAM`、`LOADS_PARAM`、`INLET_VELOCITY_PARAM`、`NU_PARAM`、`RHO_PARAM`、`OVERRIDES_PARAM`、`CASE_DIR_PARAM`；常量 `OVERRIDE_FILES`） | 同上；`OVERRIDE_FILES` 与 Python `CASE_DICT_FILES` 双面镜像 | `src/tools/verify.ts`；`OVERRIDES_PARAM` 为 solve 两 CFD 分支自用 |

<!-- 新模块行追加在对应表格末尾。保持一行一个模块，别写段落。 -->
