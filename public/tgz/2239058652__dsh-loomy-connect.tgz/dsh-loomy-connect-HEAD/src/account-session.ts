/**
 * Persist the account session next to the user's other DSH state.
 *
 * Why a file and not the `credentials` service: that seam is the official home
 * for a plugin-held secret, but it only exists in DSH builds that mount
 * `@deepseek-ai/dsh-credentials`, and this plugin supports older ones. A file
 * keeps the plugin loadable everywhere it claims to run, with no new
 * dependency.
 *
 * The file lives under `$DSH_HOME` (default `~/.dsh`), the directory DSH keeps
 * its own profiles in, holds nothing but the session and the account id, and
 * is written owner-only where the platform honours a mode.
 *
 * @module dsh-loomy-connect/account-session
 */

import { chmod, mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { dirname, join } from 'node:path'

/** Overrides the state directory; a test and a non-standard install use it. */
export const LOOMY_STATE_DIR_ENV = 'LOOMY_STATE_DIR'

/** What gets persisted: the session plus who it belongs to. */
export interface StoredAccountSession {
  session: string
  userId?: string
  maskedPhone?: string
  savedAt?: string
}

/** DSH's own home, where profiles and sessions already live. */
function dshHome(): string {
  const configured = process.env.DSH_HOME
  if (configured !== undefined && configured.trim() !== '') return configured.trim()
  return join(homedir(), '.dsh')
}

/** Absolute path of the session file. */
export function accountSessionPath(): string {
  const override = process.env[LOOMY_STATE_DIR_ENV]
  if (override !== undefined && override.trim() !== '') return join(override.trim(), 'loomy-account.json')
  return join(dshHome(), 'loomy-account.json')
}

/**
 * Read the stored session, or `undefined` when none was ever saved.
 *
 * A corrupt or unreadable file reads as "not signed in" rather than throwing:
 * losing the session must degrade to the desktop fallback, never break startup.
 */
export async function readAccountSession(path = accountSessionPath()): Promise<StoredAccountSession | undefined> {
  try {
    const text = await readFile(path, 'utf8')
    const value: unknown = JSON.parse(text)
    if (typeof value !== 'object' || value === null || Array.isArray(value)) return undefined
    const record = value as Record<string, unknown>
    const session = typeof record.session === 'string' ? record.session.trim() : ''
    if (session === '') return undefined
    const string = (field: unknown): string | undefined =>
      typeof field === 'string' && field.trim() !== '' ? field.trim() : undefined
    const userId = string(record.userId)
    const maskedPhone = string(record.maskedPhone)
    const savedAt = string(record.savedAt)
    return {
      session,
      ...userId === undefined ? {} : { userId },
      ...maskedPhone === undefined ? {} : { maskedPhone },
      ...savedAt === undefined ? {} : { savedAt },
    }
  } catch {
    return undefined
  }
}

/**
 * Store the session, or delete the file when `session.session` is empty.
 *
 * Returns `false` when the write failed — a read-only home, a sandbox denial —
 * so the caller can tell the user the sign-in lasts only this process instead
 * of silently forgetting it on the next restart.
 */
export async function writeAccountSession(
  session: StoredAccountSession | undefined,
  path = accountSessionPath(),
): Promise<boolean> {
  try {
    if (session === undefined || session.session === '') {
      await rm(path, { force: true })
      return true
    }
    await mkdir(dirname(path), { recursive: true })
    const payload: StoredAccountSession = { ...session, savedAt: new Date().toISOString() }
    await writeFile(path, `${JSON.stringify(payload, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 })
    // `mode` is ignored when the file already existed, so tighten it explicitly.
    // Windows has no POSIX mode; there this is a no-op and the user's own ACL
    // on the profile directory is the protection.
    await chmod(path, 0o600).catch(() => undefined)
    return true
  } catch {
    return false
  }
}
