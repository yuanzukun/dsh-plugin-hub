/**
 * Same-origin route for signing the plugin in with an SMS code.
 *
 * The browser half posts here; the host talks to iFlytek's account service and
 * keeps the resulting session server-side. Nothing session-shaped ever crosses
 * back to the page — the card only learns whether the sign-in worked.
 *
 * Three actions, all `POST`:
 *   `{ action: 'code', phone }`      → send an SMS code, return its message id
 *   `{ action: 'verify', phone, code, messageId }` → exchange it for a session
 *   `{ action: 'logout' }`           → forget the stored session
 *
 * @module dsh-loomy-connect/login-route
 */

import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-host-webserver'
import { LoomyAccountError } from './account-auth.ts'
import { loopbackHost, loopbackOrigin } from './loopback.ts'
import { LOOMY_LOGIN_PATH } from './status-paths.ts'

/** Longest body this route accepts; the payloads are a few dozen bytes. */
const MAX_BODY_BYTES = 4_096

/** What the route needs from the plugin. */
export interface LoomyLoginRouteOptions {
  /** Ask iFlytek to text a code to `phone`. */
  requestCode: (phone: string) => Promise<{ messageId: string; expiresIn: number }>
  /** Exchange a code for a session, store it, and report whether it persisted. */
  verifyCode: (phone: string, code: string, messageId: string) => Promise<{ account?: string; persistent: boolean }>
  /** Drop the stored session. */
  logout: () => Promise<void>
}

function json(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body)
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) })
  res.end(payload)
}

/** A browser-supplied message must not echo token material back. */
function safeMessage(error: unknown): string {
  return (error instanceof Error ? error.message : String(error))
    .replace(/[A-Za-z0-9_-]{24,}/gu, '[redacted]')
    .slice(0, 300)
}

/**
 * iFlytek's own error code when there is one, so the card can tell a wrong
 * code apart from a wrong phone number without reading Chinese prose.
 */
function errorCodeOf(error: unknown): string | undefined {
  return error instanceof LoomyAccountError ? error.code : undefined
}

function loopbackRequest(req: IncomingMessage): boolean {
  return loopbackHost(req.headers.host) && loopbackOrigin(req.headers.origin)
}

/**
 * A browser fetch with a JSON body is not a cross-site simple request, so it
 * must be declared as JSON here too. That keeps a form post from another page
 * out even before the Origin check.
 */
function jsonContentType(req: IncomingMessage): boolean {
  const value = req.headers['content-type']
  return typeof value === 'string' && value.toLowerCase().startsWith('application/json')
}

/** Read the request body, refusing anything oversized. */
async function readBody(req: IncomingMessage): Promise<string> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of req) {
    const buffer = chunk as Buffer
    size += buffer.length
    if (size > MAX_BODY_BYTES) throw new Error('request body too large')
    chunks.push(buffer)
  }
  return Buffer.concat(chunks).toString('utf8')
}

/** A trimmed string field, or `''`. */
function field(body: Record<string, unknown>, name: string): string {
  const value = body[name]
  return typeof value === 'string' ? value.trim() : ''
}

/** The sign-in route's request handler, extracted so tests can mount it bare. */
export function loomyLoginHandler(
  deps: LoomyLoginRouteOptions,
): (req: IncomingMessage, res: ServerResponse) => Promise<void> {
  return async (req, res) => {
    if (req.method !== 'POST') {
      json(res, 405, { error: 'method not allowed' })
      return
    }
    if (!loopbackRequest(req)) {
      json(res, 403, { error: 'request-not-trusted' })
      return
    }
    if (!jsonContentType(req)) {
      json(res, 415, { error: 'json-body-required' })
      return
    }
    let body: Record<string, unknown>
    try {
      const parsed: unknown = JSON.parse(await readBody(req))
      if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) throw new Error('not an object')
      body = parsed as Record<string, unknown>
    } catch (error: unknown) {
      json(res, 400, { error: safeMessage(error) })
      return
    }
    const action = field(body, 'action')
    try {
      if (action === 'code') {
        const phone = field(body, 'phone')
        if (phone === '') {
          json(res, 400, { error: 'phone required' })
          return
        }
        json(res, 200, { ok: true, ...await deps.requestCode(phone) })
        return
      }
      if (action === 'verify') {
        const phone = field(body, 'phone')
        const code = field(body, 'code')
        const messageId = field(body, 'messageId')
        if (phone === '' || code === '' || messageId === '') {
          json(res, 400, { error: 'phone, code and messageId are required' })
          return
        }
        json(res, 200, { ok: true, ...await deps.verifyCode(phone, code, messageId) })
        return
      }
      if (action === 'logout') {
        await deps.logout()
        json(res, 200, { ok: true })
        return
      }
      json(res, 400, { error: 'unknown action' })
    } catch (error: unknown) {
      const code = errorCodeOf(error)
      // A refused code is the user's mistake, not an upstream outage: answer
      // 400 so the card can show it as input feedback rather than a failure.
      const status = code === 'INVALID_CODE' || code === 'CODE_EXPIRED' || code === 'PHONE_INVALID' ? 400 : 502
      json(res, status, { error: safeMessage(error), ...code === undefined ? {} : { code } })
    }
  }
}

/** Mount the POST sign-in route on an optional webServer context. */
export function registerLoomyLoginRoute(ctx: Context, deps: LoomyLoginRouteOptions): void {
  ctx.effect(() => {
    const dispose = ctx.webServer.register({
      kind: 'exact',
      path: LOOMY_LOGIN_PATH,
      handler: loomyLoginHandler(deps),
    })
    return () => {
      dispose()
    }
  }, 'dsh-loomy-connect: Sign-in route')
}
