/** Loomy's OpenAI-compatible iModel endpoint. */
import type { LoomyCredential } from './auth.ts'

export const LOOMY_API_BASE = 'https://loomyad.xunfei.cn/api/v1'

/**
 * Sent as `loomy-version`. The gateway only checks that the header is
 * present, but sending the real client's version keeps requests ordinary.
 */
const LOOMY_VERSION = '0.9.38'

/** One live points reading from the upstream ledger. */
export interface LoomyPointsReading {
  /** Long-lived points — Loomy labels these 永久积分. */
  permanent: number
  /** Points refilled each day — 每日赠送积分. */
  daily: number
  /** What a request may actually spend: permanent plus daily. */
  available?: number
}

export class LoomyUpstreamClient {
  /**
   * The account's model list, carrying Loomy's own rate labels.
   *
   * Preferred over Loomy's generated OpenCode config: it is the same list the
   * app renders, it exists on every platform, and it is the only source that
   * says what each model costs.
   */
  async models(credential: LoomyCredential, signal?: AbortSignal): Promise<string> {
    const response = await fetch(`${LOOMY_API_BASE}/models`, {
      headers: {
        Accept: 'application/json',
        Authorization: `Bearer ${credential.session}`,
        token: credential.session,
        'X-User-Id': credential.userId,
      },
      ...(signal === undefined ? {} : { signal }),
    })
    if (!response.ok) throw new Error(`Loomy model list failed (HTTP ${response.status})`)
    return response.text()
  }

  async chatStream(credential: LoomyCredential, body: string, signal?: AbortSignal): Promise<Response> {
    const response = await fetch(`${LOOMY_API_BASE}/chat/completions`, {
      method: 'POST',
      headers: {
        Accept: 'text/event-stream',
        'Content-Type': 'application/json',
        Authorization: `Bearer ${credential.session}`,
        token: credential.session,
        'X-User-Id': credential.userId,
        'loomy-version': LOOMY_VERSION,
      },
      body,
      ...(signal === undefined ? {} : { signal }),
    })
    if (!response.ok) throw new Error(`Loomy request failed (HTTP ${response.status}): ${(await response.text()).slice(0, 400)}`)
    return response
  }

  /**
   * The account's live points ledger.
   *
   * This is the documented endpoint behind Loomy's own points display, and it
   * is the only *live* figure available: the desktop app's local cache can be
   * days old. `availableBalance` is what a request may actually spend —
   * permanent balance plus the daily grant — while the card shows the two
   * parts separately.
   */
  async points(credential: LoomyCredential, signal?: AbortSignal): Promise<LoomyPointsReading> {
    const response = await fetch(`${LOOMY_API_BASE}/points/records?record_type=all&page_no=1&page_size=1`, {
      headers: {
        Accept: 'application/json',
        Authorization: `Bearer ${credential.session}`,
        token: credential.session,
        'X-User-Id': credential.userId,
        'loomy-version': LOOMY_VERSION,
      },
      ...(signal === undefined ? {} : { signal }),
    })
    if (!response.ok) throw new Error(`Loomy points failed (HTTP ${response.status})`)
    const text = await response.text()
    let parsed: unknown
    try {
      parsed = JSON.parse(text)
    } catch {
      throw new Error('Loomy points returned a non-JSON body')
    }
    if (typeof parsed !== 'object' || parsed === null) throw new Error('Loomy points returned an unexpected body')
    const body = parsed as Record<string, unknown>
    const code = typeof body.code === 'string' ? body.code : ''
    // iFlytek's success code; anything else means the session was refused.
    if (code !== '' && code !== '000000') {
      const desc = typeof body.desc === 'string' && body.desc !== '' ? body.desc : code
      throw new Error(`Loomy points: ${desc} (${code})`)
    }
    const data = body.data
    if (typeof data !== 'object' || data === null || Array.isArray(data)) throw new Error('Loomy points carried no data')
    const record = data as Record<string, unknown>
    const number = (value: unknown): number | undefined => {
      const parsed = Number(value)
      return Number.isFinite(parsed) ? parsed : undefined
    }
    const permanent = number(record.balance)
    const daily = number(record.dailyBalance)
    if (permanent === undefined && daily === undefined) throw new Error('Loomy points carried no figures')
    return {
      permanent: permanent ?? 0,
      daily: daily ?? 0,
      ...number(record.availableBalance) === undefined ? {} : { available: number(record.availableBalance) as number },
    }
  }
}

/** Preserve tool calls; add the options Loomy sends for agent conversations. */
export function prepareLoomyBody(source: string): string {
  try {
    const value: unknown = JSON.parse(source)
    if (typeof value !== 'object' || value === null || Array.isArray(value)) return source
    const body = value as Record<string, unknown>
    body.stream = true
    if (typeof body.reasoning_effort === 'string') body.reasoningEffort = body.reasoning_effort
    // Loomy's service accepts OpenAI messages but expects system rather than
    // the newer developer role used by some OpenAI-compatible clients.
    if (Array.isArray(body.messages)) {
      for (const item of body.messages) {
        if (typeof item === 'object' && item !== null && (item as Record<string, unknown>).role === 'developer') {
          (item as Record<string, unknown>).role = 'system'
        }
      }
    }
    return JSON.stringify(body)
  } catch { return source }
}
