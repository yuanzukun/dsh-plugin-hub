/**
 * iFlytek account service: sign the plugin in with an SMS code and get the
 * session that Loomy's model gateway already accepts.
 *
 * This is the one credential source that covers every surface at once. The
 * desktop app keeps its session in local storage, the web build hands out a
 * `loomy_web_session` cookie for `loomy.xunfei.cn` only — but the account
 * service's session is what the model gateway at `loomyad.xunfei.cn` actually
 * authenticates against, which is where chat and points both live.
 *
 * Two login paths exist upstream:
 *   - SMS: `/login/phone/sendMsgCode` → `/login/phone/checkCode`
 *   - password: `/login/account/getPuKey` → `/login/account/byPwd`
 *
 * Only SMS is used here. The password path needs RSA/PKCS#1 v1.5 encryption of
 * the password, and the account has to have a password set in the iFlytek
 * account centre first — an extra setup step this plugin cannot walk a user
 * through from a settings card.
 *
 * Every request to the account service is HMAC-SHA1 signed. The key pair below
 * ships inside every Loomy client; the doc comment says as much, and the
 * protocol reference confirms it is a client constant, not a secret.
 *
 * @module dsh-loomy-connect/account-auth
 */

import { createHash, createHmac, randomBytes, randomUUID } from 'node:crypto'

/** Where the account service lives. */
export const LOOMY_ACCOUNT_BASE = 'https://account.xfinfr.com'

/** App id Loomy's clients send in every account-service envelope. */
export const LOOMY_ACCOUNT_APPID = 'GM3LOOMY'

/**
 * The client-shipped signing pair.
 *
 * Present in every Loomy installation and used only to talk to the account
 * service — the model gateway never sees it. Overridable through the
 * environment for a build that ships different values.
 */
export const LOOMY_ACCOUNT_ACCESS_KEY_ID = process.env.LOOMY_AK_ID ?? '2thryby66wxi53sk'
export const LOOMY_ACCOUNT_ACCESS_KEY_SECRET = process.env.LOOMY_AK_SECRET ?? 'zsak6eadrbawz683wf5r3m2snrwj868r'

/** How long a session is requested for: 14 days, the service's maximum. */
export const LOOMY_SESSION_EXPIRE_SECONDS = 14 * 24 * 3600

/** What a signed-in account looks like. */
export interface LoomyAccountCredential {
  /** The session token; this is the Bearer the model gateway wants. */
  session: string
  /** Loomy's numeric account id, sent as `X-User-Id`. */
  userId: string
  /** Already-masked phone number, for display only. */
  maskedPhone?: string
}

/** Raised for a business-level account-service failure. */
export class LoomyAccountError extends Error {
  /** iFlytek's own code, e.g. `000000` on success. */
  readonly code: string
  /** HTTP status, or 0 for a transport failure. */
  readonly status: number

  constructor(message: string, code: string, status: number) {
    super(message)
    this.name = 'LoomyAccountError'
    this.code = code
    this.status = status
  }
}

/** An SMS code request the caller must echo back with the code. */
export interface LoomySmsChallenge {
  /** Server-side handle for this code. */
  messageId: string
  /** Seconds the code stays valid. */
  expiresIn: number
}

/** RFC 3986 escaping, including the sub-delims `encodeURIComponent` keeps. */
function escapeSegment(value: string): string {
  return encodeURIComponent(value).replace(/[!'()*]/gu, character =>
    `%${character.charCodeAt(0).toString(16).toUpperCase()}`)
}

/** The envelope every account-service call carries. */
function envelope(): Record<string, string> {
  return {
    appid: LOOMY_ACCOUNT_APPID,
    modelid: 'Web',
    version: '1.0.0',
    devid: 'web',
    ua: 'Loomy|Desktop|Electron|macOS',
    traceid: randomBytes(16).toString('hex'),
  }
}

/**
 * Sign one account-service request.
 *
 * The signed string is nine lines — method, escaped path, escaped query,
 * content MD5, content type, date, nonce, signed-header names, and the
 * canonicalised `x-*` headers. The last two are empty when no custom headers
 * are sent, but they must still be present: the server counts lines.
 */
export function accountRequestHeaders(
  path: string,
  body: string,
  options: { accessKeyId?: string; accessKeySecret?: string; now?: number } = {},
): Record<string, string> {
  const accessKeyId = options.accessKeyId ?? LOOMY_ACCOUNT_ACCESS_KEY_ID
  const accessKeySecret = options.accessKeySecret ?? LOOMY_ACCOUNT_ACCESS_KEY_SECRET
  const date = new Date(options.now ?? Date.now()).toUTCString()
  const nonce = randomUUID()
  const md5 = body === '' ? '' : createHash('md5').update(body, 'utf8').digest('base64')
  const escapedPath = `/${path.replace(/^\/+/u, '').split('/').map(escapeSegment).join('/')}`
  const stringToSign = ['POST', escapedPath, '', md5, 'application/json', date, nonce, '', ''].join('\n')
  const signature = createHmac('sha1', accessKeySecret).update(stringToSign, 'utf8').digest('base64')
  const headers: Record<string, string> = {
    Authorization: `account ${accessKeyId}:${signature}`,
    Date: date,
    Nonce: nonce,
    'Content-Type': 'application/json',
  }
  if (md5 !== '') headers['Content-MD5'] = md5
  return headers
}

/** The subset of a fetch response this module needs. */
export interface LoomyAccountResponse {
  ok: boolean
  status: number
  text(): Promise<string>
}

/** Injection seam so a test can drive the client without a network. */
export type LoomyAccountFetch = (url: string, init: {
  method: string
  headers: Record<string, string>
  body?: string
}) => Promise<LoomyAccountResponse>

const defaultFetch: LoomyAccountFetch = async (url, init) => fetch(url, init)

/** Mask an 11-digit mainland-China phone for display: `176****7973`. */
export function maskPhoneNumber(value: string): string {
  if (value.includes('*')) return value
  if (/^\d{11}$/u.test(value)) return `${value.slice(0, 3)}****${value.slice(7)}`
  if (value.length <= 4) return value
  return `${value.slice(0, Math.ceil(value.length / 3))}****${value.slice(-Math.ceil(value.length / 4))}`
}

/**
 * The iFlytek account client: SMS sign-in and the session that comes with it.
 *
 * Stateless — the caller supplies the session — so the settings card and a
 * background refresh can share one instance.
 */
export class LoomyAccountClient {
  private readonly base: string
  private readonly doFetch: LoomyAccountFetch

  constructor(options: { base?: string; fetch?: LoomyAccountFetch } = {}) {
    this.base = (options.base ?? LOOMY_ACCOUNT_BASE).replace(/\/+$/u, '')
    this.doFetch = options.fetch ?? defaultFetch
  }

  /** One signed call, unwrapping iFlytek's `{ code, desc, data }` envelope. */
  private async call(path: string, param?: Record<string, unknown>, what = 'The account service'): Promise<Record<string, unknown>> {
    const body = JSON.stringify(param === undefined ? { base: envelope() } : { base: envelope(), param })
    let response: LoomyAccountResponse
    try {
      response = await this.doFetch(`${this.base}${path}`, {
        method: 'POST',
        headers: accountRequestHeaders(path, body),
        body,
      })
    } catch (error: unknown) {
      throw new LoomyAccountError(
        `${what} is unreachable: ${error instanceof Error ? error.message : String(error)}`,
        'NETWORK',
        0,
      )
    }
    const text = await response.text()
    let parsed: unknown
    try {
      parsed = JSON.parse(text)
    } catch {
      throw new LoomyAccountError(`${what} returned HTTP ${response.status}`, `HTTP_${response.status}`, response.status)
    }
    if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
      throw new LoomyAccountError(`${what} returned an unexpected body`, 'INVALID_RESPONSE', response.status)
    }
    const payload = parsed as Record<string, unknown>
    const code = typeof payload.code === 'string' ? payload.code : ''
    // `000000` is iFlytek's success code; anything else carries a `desc`.
    if (code !== '' && code !== '000000') {
      const desc = typeof payload.desc === 'string' && payload.desc !== '' ? payload.desc : code
      throw new LoomyAccountError(desc, code, response.status)
    }
    if (!response.ok && code === '') {
      throw new LoomyAccountError(`${what} returned HTTP ${response.status}`, `HTTP_${response.status}`, response.status)
    }
    const data = payload.data
    return typeof data === 'object' && data !== null && !Array.isArray(data) ? data as Record<string, unknown> : {}
  }

  /** Ask iFlytek to text a sign-in code to `phone`. */
  async sendSmsCode(phone: string): Promise<LoomySmsChallenge> {
    const data = await this.call('/login/phone/sendMsgCode', { ccode: '86', phone, expire: 300 }, 'Sending the sign-in code')
    const messageId = typeof data.msgid === 'string' ? data.msgid : ''
    if (messageId === '') throw new LoomyAccountError('The account service returned no message id', 'NO_MESSAGE_ID', 200)
    return { messageId, expiresIn: 300 }
  }

  /**
   * Exchange a texted code for a session.
   *
   * `expire` asks the service to keep the session for two weeks; that is also
   * the maximum, and there is no refresh token — an expired session means
   * signing in again.
   */
  async loginWithSmsCode(phone: string, code: string, messageId: string): Promise<LoomyAccountCredential> {
    const data = await this.call('/login/phone/checkCode', {
      ccode: '86',
      phone,
      mcode: code,
      msgid: messageId,
      expire: LOOMY_SESSION_EXPIRE_SECONDS,
    }, 'Signing in')
    const session = typeof data.session === 'string' ? data.session.trim() : ''
    if (session === '') throw new LoomyAccountError('Sign-in succeeded but returned no session', 'NO_SESSION', 200)
    const userId = typeof data.userid === 'string' ? data.userid.trim() : ''
    const phoneMasked = typeof data.phone === 'string' && data.phone !== ''
      ? data.phone
      : maskPhoneNumber(typeof data.cellphone === 'string' ? data.cellphone : '')
    return {
      session,
      userId,
      ...phoneMasked === '' ? {} : { maskedPhone: maskPhoneNumber(phoneMasked) },
    }
  }

  /**
   * Confirm a session is still live, and read the identity behind it.
   *
   * Used right after sign-in to reject a session the service will not honour,
   * and on startup to decide whether a stored session is still usable.
   */
  async me(session: string): Promise<LoomyAccountCredential> {
    const data = await this.call('/userinfo/query/baseInfo', { session }, 'Reading the account')
    const userId = typeof data.userid === 'string' ? data.userid.trim() : ''
    const raw = typeof data.phone === 'string' && data.phone !== ''
      ? data.phone
      : typeof data.cellphone === 'string' ? data.cellphone : ''
    return {
      session,
      userId,
      ...raw === '' ? {} : { maskedPhone: maskPhoneNumber(raw) },
    }
  }

  /** Sign the session out upstream. */
  async logout(session: string): Promise<void> {
    await this.call('/login/account/logout', { session }, 'Signing out')
  }
}
