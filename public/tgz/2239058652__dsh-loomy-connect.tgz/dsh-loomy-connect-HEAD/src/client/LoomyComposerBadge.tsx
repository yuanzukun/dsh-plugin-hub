/**
 * Composer credit badge: a compact icon in the input toolbar that opens the
 * account's live points.
 *
 * It rides `conversation.input.activity`, the one composer seat documented as
 * sitting *after the model selector* and able to expand across the toolbar —
 * the same place other provider bundles put their account chip.
 *
 * The badge does not poll. Nothing is fetched until the popover opens, so a
 * conversation that never asks for points costs no upstream calls; the popover
 * holds a manual refresh for when the user wants a fresh figure.
 */

import { useCallback, useEffect, useId, useRef, useState, useSyncExternalStore } from 'react'
import type { ReactElement } from 'react'
import { IconRefreshOutlineMedium } from '@deepseek-ai/dsh-client-ui-primitives'
import { LOOMY_STATUS_PATH } from '../status-paths.ts'
import type { LoomyWebStatus } from '../status-paths.ts'
import type { Translate } from './use-loomy-status.ts'
import { CSS } from './card-css.ts'

/**
 * The slice of the model directory store this badge reads.
 *
 * Declared structurally rather than imported: the `models` service is declared
 * by `@deepseek-ai/dsh-client-ui-model-selection`, and depending on that
 * package for one field would add a peer for what is a two-line read.
 */
export interface ModelSelectionStore {
  subscribe: (listener: () => void) => () => void
  getSnapshot: () => { current: { provider: string } | null } | undefined
}

/** Points as the popover renders them. */
interface PointsView {
  permanent: number
  daily: number
  updatedAt?: string
  live: boolean
}

/** Read the status route once, and only the points out of it. */
async function fetchPoints(signal?: AbortSignal): Promise<PointsView | undefined> {
  const response = await fetch(`${LOOMY_STATUS_PATH}?refresh=1`, {
    headers: { accept: 'application/json' },
    credentials: 'same-origin',
    ...signal === undefined ? {} : { signal },
  })
  if (!response.ok) throw new Error(`HTTP ${response.status}`)
  const value = await response.json().catch(() => undefined) as LoomyWebStatus | undefined
  if (value === undefined) throw new Error('empty response')
  if (value.status !== 'signed-in') return undefined
  if (value.points === undefined) throw new Error(value.pointsError ?? 'no points')
  return {
    permanent: value.points.permanent,
    daily: value.points.daily,
    ...value.points.updatedAt === undefined ? {} : { updatedAt: value.points.updatedAt },
    live: value.pointsLive === true,
  }
}

function formatNumber(value: number): string {
  return new Intl.NumberFormat(undefined).format(value)
}

function formatTime(ms: number): string {
  return new Intl.DateTimeFormat(undefined, { timeStyle: 'short' }).format(new Date(ms))
}

/** Props injected by the client plugin's registration. */
export interface LoomyComposerBadgeProps {
  t: Translate
  /** Whether the composer refuses interaction right now. */
  locked: boolean
  /** Tell the toolbar this control needs the full width (never, for a popover). */
  onActiveChange: (active: boolean) => void
  /** Resolve one session's model directory; absent when the service is missing. */
  directoryFor?: (sessionId: string) => ModelSelectionStore | undefined
  /** The session this composer belongs to (a standard slot prop). */
  sessionId?: string
}

/** The provider route this plugin registers. */
const LOOMY_PROVIDER_ROUTE = 'loomy'

/** The composer's points icon and its popover. */
export function LoomyComposerBadge({ t, locked, directoryFor, sessionId }: LoomyComposerBadgeProps): ReactElement | null {
  const [open, setOpen] = useState(false)
  const [points, setPoints] = useState<PointsView | undefined>(undefined)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | undefined>(undefined)
  const root = useRef<HTMLDivElement | null>(null)
  const panelId = useId()

  // Resolving per render keeps the reference stable for `useSyncExternalStore`:
  // the service hands back the same store object for the same session.
  const directory = sessionId === undefined ? undefined : directoryFor?.(sessionId)

  // The badge belongs to Loomy alone: while another provider is selected the
  // composer keeps its usual width rather than growing a foreign control.
  const provider = useSyncExternalStore(
    useCallback((listener: () => void) => directory?.subscribe(listener) ?? (() => undefined), [directory]),
    useCallback(() => directory?.getSnapshot()?.current?.provider, [directory]),
  )
  const mine = provider === LOOMY_PROVIDER_ROUTE

  // A selection change while the popover is open closes it, so the panel can
  // never outlive the model it describes.
  useEffect(() => {
    if (!mine) setOpen(false)
  }, [mine])

  const load = useCallback(async (signal?: AbortSignal): Promise<void> => {
    setBusy(true)
    setError(undefined)
    try {
      const value = await fetchPoints(signal)
      if (signal?.aborted === true) return
      setPoints(value)
      if (value === undefined) setError(t('pointsUnavailable'))
    } catch (failure: unknown) {
      if (signal?.aborted === true) return
      setError(failure instanceof Error ? failure.message : String(failure))
    } finally {
      if (signal?.aborted !== true) setBusy(false)
    }
  }, [t])

  // Fetch on open and drop the reading on close, so reopening always asks the
  // host again rather than showing a figure from an earlier conversation.
  useEffect(() => {
    if (!open) return
    const controller = new AbortController()
    void load(controller.signal)
    return () => {
      controller.abort()
    }
  }, [open, load])

  // A click anywhere else, or Escape, closes the popover. The composer sits
  // inside a scroll container, so a pointerdown listener on the document is
  // more reliable than a focusout (which fires while moving between its rows).
  useEffect(() => {
    if (!open) return
    const onPointerDown = (event: PointerEvent): void => {
      if (root.current !== null && !root.current.contains(event.target as Node)) setOpen(false)
    }
    const onKeyDown = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') setOpen(false)
    }
    document.addEventListener('pointerdown', onPointerDown)
    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('pointerdown', onPointerDown)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [open])

  const updatedMs = points?.updatedAt === undefined ? undefined : Date.parse(points.updatedAt)

  if (!mine) return null

  return (
    <div className={CSS.badgeRoot} ref={root}>
      <button
        type="button"
        className={open ? `${CSS.badgeButton} ${CSS.badgeButtonOpen}` : CSS.badgeButton}
        aria-label={t('pointsHeading')}
        aria-expanded={open}
        aria-controls={open ? panelId : undefined}
        title={t('pointsHeading')}
        disabled={locked}
        onClick={() => setOpen(value => !value)}
      >
        {/* A coin glyph drawn inline: the primitives package ships no points icon. */}
        <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" focusable="false">
          <circle cx="8" cy="8" r="6.25" fill="none" stroke="currentColor" strokeWidth="1.25" />
          <path d="M8 4.75v6.5M10.1 6.4H6.9a1.1 1.1 0 0 0 0 2.2h2.2a1.1 1.1 0 0 1 0 2.2H5.9" fill="none" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" />
        </svg>
      </button>
      {open
        ? (
          <div className={CSS.badgePanel} id={panelId} role="dialog" aria-label={t('pointsHeading')}>
            <div className={CSS.badgePanelHead}>
              <span className={CSS.badgePanelTitle}>{t('pointsHeading')}</span>
              <button
                type="button"
                className={CSS.badgeRefresh}
                aria-label={t('refresh')}
                title={t('refresh')}
                disabled={busy}
                onClick={() => void load()}
              >
                <IconRefreshOutlineMedium className={busy ? CSS.refreshSpin : undefined} />
              </button>
            </div>
            {error !== undefined
              ? <p className={CSS.error}>{error}</p>
              : points === undefined
                ? <p className={CSS.hint}>{busy ? t('loading') : t('pointsUnavailable')}</p>
                : (
                  <>
                    <div className={CSS.badgeRows}>
                      <div className={CSS.badgeRow}>
                        <span className={CSS.badgeRowLabel}>{t('permanentPoints')}</span>
                        <span className={CSS.badgeRowValue}>{formatNumber(points.permanent)}</span>
                      </div>
                      <div className={CSS.badgeRow}>
                        <span className={CSS.badgeRowLabel}>{t('dailyPoints')}</span>
                        <span className={CSS.badgeRowValue}>{formatNumber(points.daily)}</span>
                      </div>
                      <div className={`${CSS.badgeRow} ${CSS.badgeRowTotal}`}>
                        <span className={CSS.badgeRowLabel}>{t('pointsAvailable')}</span>
                        <span className={CSS.badgeRowValue}>{formatNumber(points.permanent + points.daily)}</span>
                      </div>
                    </div>
                    <p className={CSS.badgeFoot}>
                      {updatedMs === undefined || Number.isNaN(updatedMs)
                        ? null
                        : `${t('updatedAt', { time: formatTime(updatedMs) })} · `}
                      {points.live ? t('pointsLive') : t('pointsCached')}
                    </p>
                  </>
                )}
          </div>
        )
        : null}
    </div>
  )
}
