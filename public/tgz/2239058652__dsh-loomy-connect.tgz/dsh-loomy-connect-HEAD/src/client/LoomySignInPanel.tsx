/**
 * Two-step SMS sign-in for a Loomy account.
 *
 * The page posts to the plugin's own host route; the session stays on the host
 * side, so this component only ever sees "worked" or "did not".
 */

import { useState } from 'react'
import type { ReactElement } from 'react'
import { Button } from '@deepseek-ai/dsh-client-ui-primitives'
import { LOOMY_LOGIN_PATH } from '../status-paths.ts'
import type { Translate } from './use-loomy-status.ts'
import { CSS } from './card-css.ts'

/** What the host answers for `action: 'code'`. */
interface CodeReply {
  ok?: boolean
  messageId?: string
  expiresIn?: number
  error?: string
  code?: string
}

/** What the host answers for `action: 'verify'` / `'logout'`. */
interface VerifyReply {
  ok?: boolean
  account?: string
  /** False when the host could not save the session to disk. */
  persistent?: boolean
  error?: string
  code?: string
}

/** Send one JSON action to the host sign-in route. */
async function postLogin(body: Record<string, unknown>): Promise<Record<string, unknown>> {
  const response = await fetch(LOOMY_LOGIN_PATH, {
    method: 'POST',
    headers: { accept: 'application/json', 'content-type': 'application/json' },
    credentials: 'same-origin',
    body: JSON.stringify(body),
  })
  const value = await response.json().catch(() => undefined) as Record<string, unknown> | undefined
  if (value === undefined) throw new Error(`HTTP ${response.status}`)
  if (!response.ok) {
    const message = typeof value.error === 'string' ? value.error : `HTTP ${response.status}`
    const error = new Error(message) as Error & { code?: string }
    if (typeof value.code === 'string') error.code = value.code
    throw error
  }
  return value
}

/** Map iFlytek's error codes onto the card's own wording. */
function describeFailure(error: unknown, t: Translate): string {
  const code = (error as { code?: unknown }).code
  if (code === 'PHONE_INVALID' || code === 'INVALID_PHONE') return t('signInInvalidPhone')
  if (code === 'INVALID_CODE' || code === 'CODE_INVALID' || code === 'CODE_EXPIRED') return t('signInCodeRejected')
  const message = error instanceof Error ? error.message : String(error)
  return t('signInFailed', { message })
}

/** Props for {@link LoomySignInPanel}. */
export interface LoomySignInPanelProps {
  t: Translate
  /** Called after a successful sign-in so the caller can re-read the status. */
  onSignedIn: (account?: string) => void
}

/** Phone → code → session, with the code challenge kept in component state. */
export function LoomySignInPanel({ t, onSignedIn }: LoomySignInPanelProps): ReactElement {
  const [phone, setPhone] = useState('')
  const [code, setCode] = useState('')
  const [messageId, setMessageId] = useState<string | undefined>(undefined)
  const [busy, setBusy] = useState<'code' | 'verify' | undefined>(undefined)
  const [error, setError] = useState<string | undefined>(undefined)
  const [notice, setNotice] = useState<string | undefined>(undefined)

  const digital = phone.replace(/\D/gu, '')

  const sendCode = async (): Promise<void> => {
    setBusy('code')
    setError(undefined)
    setNotice(undefined)
    try {
      const reply = await postLogin({ action: 'code', phone: digital }) as CodeReply
      if (typeof reply.messageId !== 'string' || reply.messageId === '') throw new Error('no message id')
      setMessageId(reply.messageId)
      const minutes = Math.max(1, Math.round((reply.expiresIn ?? 300) / 60))
      setNotice(t('signInCodeSent', { minutes }))
    } catch (failure: unknown) {
      setError(describeFailure(failure, t))
    } finally {
      setBusy(undefined)
    }
  }

  const verify = async (): Promise<void> => {
    if (messageId === undefined) return
    setBusy('verify')
    setError(undefined)
    try {
      const reply = await postLogin({
        action: 'verify',
        phone: digital,
        code: code.trim(),
        messageId,
      }) as VerifyReply
      // A session that could not be written to disk still works for this
      // process; saying so is better than letting it vanish on restart.
      if (reply.persistent === false) setError(t('signInNotPersisted'))
      onSignedIn(typeof reply.account === 'string' ? reply.account : undefined)
    } catch (failure: unknown) {
      setError(describeFailure(failure, t))
    } finally {
      setBusy(undefined)
    }
  }

  return (
    <div className={CSS.section}>
      <h3 className={CSS.heading}>{t('signInHeading')}</h3>
      <p className={CSS.hint}>{t('signInHint')}</p>
      <div className={CSS.field}>
        <label className={CSS.fieldLabel} htmlFor="dlc-phone">{t('signInPhone')}</label>
        <input
          id="dlc-phone"
          className={CSS.input}
          inputMode="tel"
          autoComplete="tel"
          value={phone}
          placeholder="13800000000"
          disabled={busy !== undefined}
          onChange={event => {
            setPhone(event.target.value)
            // A new number invalidates the challenge, so the code field resets
            // with it rather than pairing a fresh number with a stale code.
            setMessageId(undefined)
            setCode('')
            setNotice(undefined)
            setError(undefined)
          }}
        />
      </div>
      {messageId === undefined
        ? null
        : (
          <div className={CSS.field}>
            <label className={CSS.fieldLabel} htmlFor="dlc-code">{t('signInCode')}</label>
            <input
              id="dlc-code"
              className={CSS.input}
              inputMode="numeric"
              autoComplete="one-time-code"
              value={code}
              disabled={busy !== undefined}
              onChange={event => {
                setCode(event.target.value)
                setError(undefined)
              }}
            />
          </div>
        )}
      <div className={CSS.actions}>
        {messageId === undefined
          ? (
            <Button
              variant="primary"
              size="sm"
              disabled={busy !== undefined || digital.length < 6}
              onClick={() => void sendCode()}
            >
              {busy === 'code' ? t('signInSending') : t('signInSendCode')}
            </Button>
          )
          : (
            <>
              <Button
                variant="primary"
                size="sm"
                disabled={busy !== undefined || code.trim() === ''}
                onClick={() => void verify()}
              >
                {busy === 'verify' ? t('signInSubmitting') : t('signInSubmit')}
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={busy !== undefined}
                onClick={() => void sendCode()}
              >
                {busy === 'code' ? t('signInSending') : t('signInSendCode')}
              </Button>
            </>
          )}
      </div>
      {notice === undefined ? null : <p className={CSS.hint}>{notice}</p>}
      {error === undefined ? null : <p className={CSS.error}>{error}</p>}
    </div>
  )
}
