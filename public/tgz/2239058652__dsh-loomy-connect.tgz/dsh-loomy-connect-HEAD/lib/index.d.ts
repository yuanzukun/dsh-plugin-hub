import Schema from "@deepseek-ai/schemastery";
import { PiAiAdapter } from "@deepseek-ai/dsh-llm-pi-ai";
import { IncomingMessage, ServerResponse } from "node:http";
import { Context } from "@deepseek-ai/cordis";
import { AttachmentStore } from "@deepseek-ai/dsh-attachment";

//#region src/entry-id.d.ts
/**
 * Identity shared by the host and browser halves.
 *
 * `LOOMY_ENTRY_ID` is the cordis patch entry id in `cordis.patch.yml`, which
 * also becomes the settings namespace in DSH 0.2.1. The browser half keys the
 * provider card and the row configuration page by it, so changing the patch id
 * without changing this constant silently unhooks both.
 */
/** Package name, used as the bundle key on the Plugins page. */
declare const LOOMY_PACKAGE = "dsh-loomy-connect";
/** Profile entry id declared by `cordis.patch.yml`. */
declare const LOOMY_ENTRY_ID = "llm-loomy";
/** LLM provider route registered with `ctx.llm`. */
declare const LOOMY_PROVIDER = "loomy";
//#endregion
//#region src/auth.d.ts
/**
 * The `localStorage` key Loomy's renderer keeps the sign-in session under.
 *
 * Only the Windows build relies on it: there Loomy keeps the session in the
 * renderer's own storage and never writes the `auth-session.json` sidecar the
 * macOS build leaves in its Electron data dir.
 */
declare const LOOMY_AUTH_SESSION_KEY = "loomy-auth-session";
interface LoomyCredential {
  session: string;
  userId: string;
  /** Already-masked phone number Loomy stores alongside the session, for display only. */
  maskedPhone?: string;
}
/** The first existing auth file, or the primary platform default when none yet. */
declare function defaultLoomyAuthPath(): string;
/** The first existing config file, or the primary platform default when none yet. */
declare function defaultLoomyConfigPath(): string;
declare function parseLoomyAuth(text: string): LoomyCredential | undefined;
/**
 * Every session cached in one LevelDB log, oldest first.
 *
 * The log is append-only, so several records can share the key; `loggedInAt`
 * decides which is current rather than file order.
 */
declare function extractLoomyAuthSessions(text: string): LoomyCredential[];
/** The newest session in Loomy's localStorage, or undefined when there is none. */
declare function readLoomySessionFromStorage(dir?: string): Promise<LoomyCredential | undefined>;
declare function readLoomyCredential(authFile?: string): Promise<LoomyCredential>;
//#endregion
//#region src/catalog.d.ts
interface LoomyModel {
  id: string;
  name: string;
  /**
   * Context window in tokens, exactly when the source carries one.
   *
   * Loomy's `/v1/models` fills `context_length` for chat models but leaves it
   * off some image generators, and the offline snapshot should not invent
   * numbers either — `undefined` means unknown, which the card renders as
   * `未提供` instead of a plausible-looking guess.
   */
  contextWindow: number | undefined;
  maxTokens: number | undefined;
  supportsImages: boolean;
  reasoning: boolean;
  /** Points multiplier Loomy prints in the model name — 3 for `x3.0`. */
  rate?: number;
  /** Promotional label Loomy prints in the model name, e.g. 限时免费. */
  promo?: string;
  /** True for image generators: listed for reference, never served to DSH. */
  image?: boolean;
}
/** Parse Loomy's `/v1/models` response; every entry that has an id survives. */
declare function parseLoomyApiModels(text: string): readonly LoomyModel[];
/** Parse Loomy's generated OpenCode config, the source the macOS build writes. */
declare function parseLoomyModels(text: string): readonly LoomyModel[];
/**
 * The account's model list.
 *
 * Loomy's `/v1/models` is authoritative and carries the rates, so it is the
 * preferred source; the generated OpenCode config is the fallback for builds
 * or sessions where the API cannot be reached.
 */
declare class LoomyCatalog {
  private served;
  private discovered;
  private blocked;
  /** Models DSH can actually call: text models the user has not disabled. */
  current(): readonly LoomyModel[];
  /** Everything Loomy lists, image generators included, for the card to show. */
  all(): readonly LoomyModel[];
  /** The ids the user switched off, as the profile stored them. */
  blockedIds(): readonly string[];
  /** Whether the user switched this model off in the plugin's own settings. */
  isBlocked(id: string): boolean;
  /**
   * Apply the user's disabled-model list.
   *
   * The filter runs over whatever the catalog holds, so it survives a refresh:
   * `accept()` recomputes the served list from the same set. Disabling every
   * model legitimately leaves nothing served — the provider then offers no
   * models, which is what the switch means.
   */
  setBlocked(ids: readonly string[]): void;
  private recompute;
  private accept;
  /**
   * Forget every model, offered and discovered alike.
   *
   * Used when no sign-in source is left: a remembered list would offer models
   * whose every request is refused, which reads as a broken provider instead of
   * a signed-out one.
   */
  clear(): void;
  refreshFromApi(credential: LoomyCredential, signal?: AbortSignal): Promise<void>;
  refreshFromFile(configFile?: string): Promise<void>;
}
//#endregion
//#region src/shim.d.ts
interface LoomyShim {
  ready: Promise<void>;
  baseUrl(): string;
  token(): string;
  close(): Promise<void>;
}
/**
 * Where the desktop app's auth file lives. A thunk is accepted so the value the
 * Plugin configuration card writes takes effect on the next request instead of
 * only after a Harness restart — the shim is built before settings attach.
 */
type LoomyAuthFile = string | (() => string | undefined);
/**
 * Resolves the credential per request, so a web sign-in or a desktop sign-out
 * takes effect on the next call instead of only after a restart.
 *
 * Unlike the status route, this one must produce a credential or throw: a chat
 * request that cannot authenticate is a 502, not an empty answer.
 */
type LoomyCredentialResolver = () => Promise<LoomyCredential>;
interface LoomyShimOptions {
  catalog: LoomyCatalog;
  authFile?: LoomyAuthFile;
  /** Overrides the desktop-file read; the web session takes precedence there. */
  credential?: LoomyCredentialResolver;
  logger?: {
    warn(...args: unknown[]): void;
  };
}
/** Resolve a possibly-dynamic auth-file location at call time. */
declare function resolveAuthFile(value: LoomyAuthFile | undefined): string | undefined;
declare function createLoomyShim(options: LoomyShimOptions): LoomyShim;
//#endregion
//#region src/adapter.d.ts
/** What {@link createLoomyAdapter} hands back. */
interface LoomyAdapter {
  adapter: PiAiAdapter;
  /** Rebuild the adapter's provider snapshot; call after a catalog update. */
  invalidate(): void;
}
/**
 * The services the adapter reads at request time.
 *
 * Both are looked up through `ctx.get` on every call rather than captured once,
 * because `attachments` and `fs` are optional services a profile may mount or
 * replace while this plugin keeps running.
 */
interface LoomyAdapterServices {
  /**
   * Durable attachment service. Without it pi-ai refuses image input outright,
   * before the gateway is ever reached.
   */
  attachments: () => AttachmentStore | undefined;
  /** Maps a stored host path into the path the model tool can read. */
  processPathFromHostPath: ((hostPath: string) => string | undefined) | undefined;
}
declare function createLoomyAdapter(catalog: LoomyCatalog, shim: LoomyShim, services: LoomyAdapterServices): LoomyAdapter;
//#endregion
//#region src/upstream.d.ts
declare const LOOMY_API_BASE = "https://loomyad.xunfei.cn/api/v1";
/** One live points reading from the upstream ledger. */
interface LoomyPointsReading {
  /** Long-lived points — Loomy labels these 永久积分. */
  permanent: number;
  /** Points refilled each day — 每日赠送积分. */
  daily: number;
  /** What a request may actually spend: permanent plus daily. */
  available?: number;
}
/**
 * iFlytek refused the session.
 *
 * The model gateway answers an expired or forged session with HTTP 200 and a
 * `{"code":"100002"}` body rather than a 401, so a plain status check would
 * read the refusal as an empty model list.
 */
declare class LoomySessionRejected extends Error {
  /** The upstream's own code, e.g. `100002`. */
  readonly code: string;
  constructor(code: string, description: string);
}
declare class LoomyUpstreamClient {
  /**
   * The account's model list, carrying Loomy's own rate labels.
   *
   * Preferred over Loomy's generated OpenCode config: it is the same list the
   * app renders, it exists on every platform, and it is the only source that
   * says what each model costs.
   *
   * @throws {LoomySessionRejected} when the gateway answered but refused the session
   */
  models(credential: LoomyCredential, signal?: AbortSignal): Promise<string>;
  chatStream(credential: LoomyCredential, body: string, signal?: AbortSignal): Promise<Response>;
  /**
   * The account's live points ledger.
   *
   * This is the documented endpoint behind Loomy's own points display, and it
   * is the only *live* figure available: the desktop app's local cache can be
   * days old. `availableBalance` is what a request may actually spend —
   * permanent balance plus the daily grant — while the card shows the two
   * parts separately.
   */
  points(credential: LoomyCredential, signal?: AbortSignal): Promise<LoomyPointsReading>;
}
/** Preserve tool calls; add the options Loomy sends for agent conversations. */
declare function prepareLoomyBody(source: string): string;
//#endregion
//#region src/loopback.d.ts
/**
 * Shared loopback gates for the plugin's local HTTP surfaces: the credential
 * shim and the same-origin web-status route. Both are only ever meant to be
 * addressed through the machine's loopback interface.
 *
 * @module dsh-loomy-connect/loopback
 */
/**
 * A `Host` header value names loopback. A DNS-rebinding page (an attacker
 * domain re-resolved to 127.0.0.1) still sends its own domain in `Host`, so
 * this check drops those before any routing happens.
 */
declare function loopbackHost(value: string | undefined): boolean;
/**
 * A browser-sent `Origin` must be loopback. Non-browser clients (the OpenAI
 * client pi-ai drives) send no `Origin` at all and pass.
 */
declare function loopbackOrigin(value: string | undefined): boolean;
//#endregion
//#region src/points.d.ts
/**
 * Read Loomy's own points summary straight off disk.
 *
 * Loomy is an Electron app whose renderer keeps the account's points summary in
 * `localStorage` under the key `loomy-points-summary`, shaped
 * `{ balance, dailyBalance, updatedAt, … }`. Loomy's own sidebar reads that
 * cache to render 永久积分 / 每日赠送积分, so the numbers the card shows are
 * the same numbers the user sees in the app.
 *
 * The desktop build has no HTTP endpoint for this: the model gateway at
 * `loomyad.xunfei.cn` answers 404 for `/v1/credits`, and the points calls the
 * renderer makes go through `window.electronAPI.points.*` IPC, which only the
 * running app can serve. Reading the cache is therefore the only way to get
 * these numbers from a desktop-only setup, and it is read-only.
 *
 * This is the fallback. When the plugin holds its own account session, the
 * gateway's `/points/records` ledger answers the same two figures live — see
 * {@link LoomyUpstreamClient.points} — and that reading is preferred because
 * this cache is only as fresh as the last time the desktop app refreshed it.
 *
 * Chromium's `localStorage` lives in a LevelDB log, which is append-only: a
 * key's old values stay in the file behind newer ones. We parse every candidate
 * record and keep the newest by `updatedAt` rather than trusting file order.
 *
 * @module dsh-loomy-connect/points
 */
/** The localStorage key Loomy's renderer writes the points summary to. */
declare const LOOMY_POINTS_KEY = "loomy-points-summary";
/** The first existing localStorage dir, or the primary platform default when none yet. */
declare function defaultLoomyLocalStorageDir(): string;
/** One account's points split the way Loomy's own UI presents it. */
interface LoomyPointsSummary {
  /** Long-lived points — Loomy labels these 永久积分. */
  permanent: number;
  /** Points refilled each sign-in day — Loomy labels these 每日赠送积分. */
  daily: number;
  /** ISO timestamp of the last time Loomy refreshed the summary. */
  updatedAt?: string;
}
/** Parse one cached record, keeping only the fields the card renders. */
declare function parseLoomyPointsRecord(raw: string): LoomyPointsSummary | undefined;
/** Every cached summary in one LevelDB log, oldest first. */
declare function extractLoomyPoints(text: string): LoomyPointsSummary[];
/** Newest record wins; `updatedAt` decides, file order breaks ties. */
declare function newestLoomyPoints(records: readonly LoomyPointsSummary[]): LoomyPointsSummary | undefined;
/**
 * Read the account's points summary from Loomy's localStorage.
 *
 * Returns `undefined` when Loomy has never cached a summary (or is not
 * installed) so the card can degrade instead of showing a bogus zero.
 */
declare function readLoomyPoints(dir?: string): Promise<LoomyPointsSummary | undefined>;
/** Drop the memoized read; tests and the status route use this. */
declare function resetLoomyPointsCache(): void;
//#endregion
//#region src/status-paths.d.ts
/** Node-free constants and types shared by the Host and browser halves. */
/** Plugin-owned status endpoint consumed by its browser half. */
declare const LOOMY_STATUS_PATH = "/plugins/dsh-loomy-connect/status";
/** Web sign-in: request a code, submit it, or drop the session. */
declare const LOOMY_LOGIN_PATH = "/plugins/dsh-loomy-connect/login";
/** Which sign-in source the account came from, so the card can say so. */
type LoomyCredentialSource = 'account' | 'desktop';
/** The account's points split the way Loomy's own UI presents it. */
interface LoomyWebPoints {
  /** Long-lived points — Loomy labels these 永久积分. */
  permanent: number;
  /** Points refilled each sign-in day; 每日赠送积分. Resets to 5000 daily. */
  daily: number;
  /** ISO timestamp of Loomy's last refresh, so the card can show staleness. */
  updatedAt?: string;
}
/** One model as Loomy lists it, including the rate it bills at. */
interface LoomyWebModel {
  id: string;
  /** Loomy's own display name, which carries the rate (e.g. `…（x3.0）`). */
  name: string;
  /** Points multiplier Loomy prints in the name — 3 for `x3.0`. */
  rate?: number;
  /** Promotional label Loomy prints in the name, e.g. 限时免费. */
  promo?: string;
  /** True for image generators: listed for reference, never served to DSH. */
  image?: boolean;
  /**
   * Context window in tokens, when Loomy's list carries one. Absent means
   * unknown — e.g. some image generators ship without `context_length` — and
   * the card renders that as `未提供` rather than guessing.
   */
  contextWindow?: number;
  /**
   * True when the user switched this model off. The card still lists it so it
   * can be switched back on; the provider never serves it.
   */
  disabled?: boolean;
}
/** The JSON document the plugin card renders. */
type LoomyWebStatus = {
  status: 'signed-out';
} | {
  status: 'signed-in'; /** Masked sign-in identity (Loomy stores a masked phone number). */
  account?: string; /** Which credential the plugin is running on. */
  source?: LoomyCredentialSource; /** How many models the plugin is currently serving. */
  modelCount: number; /** Every model the account can reach, including image generators. */
  models?: LoomyWebModel[]; /** Ids the user switched off, in the order the profile stores them. */
  blockedModels?: string[];
  points?: LoomyWebPoints;
  pointsError?: string; /** True when the points figures are a live reading, not a cached one. */
  pointsLive?: boolean;
} | {
  status: 'error';
  message: string;
};
//#endregion
//#region src/account-session.d.ts
/**
 * Persist the account session next to the user's other DSH state.
 *
 * Why a file and not the `credentials` service: that seam is the official home
 * for a plugin-held secret, but it only exists in DSH builds that mount
 * `@deepseek-ai/dsh-credentials`, and this plugin supports older ones. A file
 * keeps the plugin loadable everywhere it claims to run, with no new
 * dependency.
 *
 * The file lives under `$DSH_HOME` (default `~/.dsh`), the directory DSH keeps
 * its own profiles in, holds nothing but the session and the account id, and
 * is written owner-only where the platform honours a mode.
 *
 * @module dsh-loomy-connect/account-session
 */
/** Overrides the state directory; a test and a non-standard install use it. */
declare const LOOMY_STATE_DIR_ENV = "LOOMY_STATE_DIR";
/** What gets persisted: the session plus who it belongs to. */
interface StoredAccountSession {
  session: string;
  userId?: string;
  maskedPhone?: string;
  savedAt?: string;
}
/** Absolute path of the session file. */
declare function accountSessionPath(): string;
/**
 * Read the stored session, or `undefined` when none was ever saved.
 *
 * A corrupt or unreadable file reads as "not signed in" rather than throwing:
 * losing the session must degrade to the desktop fallback, never break startup.
 */
declare function readAccountSession(path?: string): Promise<StoredAccountSession | undefined>;
/**
 * Store the session, or delete the file when `session.session` is empty.
 *
 * Returns `false` when the write failed — a read-only home, a sandbox denial —
 * so the caller can tell the user the sign-in lasts only this process instead
 * of silently forgetting it on the next restart.
 */
declare function writeAccountSession(session: StoredAccountSession | undefined, path?: string): Promise<boolean>;
//#endregion
//#region src/account-auth.d.ts
/**
 * iFlytek account service: sign the plugin in with an SMS code and get the
 * session that Loomy's model gateway already accepts.
 *
 * This is the one credential source that covers every surface at once. The
 * desktop app keeps its session in local storage, the web build hands out a
 * `loomy_web_session` cookie for `loomy.xunfei.cn` only — but the account
 * service's session is what the model gateway at `loomyad.xunfei.cn` actually
 * authenticates against, which is where chat and points both live.
 *
 * Two login paths exist upstream:
 *   - SMS: `/login/phone/sendMsgCode` → `/login/phone/checkCode`
 *   - password: `/login/account/getPuKey` → `/login/account/byPwd`
 *
 * Only SMS is used here. The password path needs RSA/PKCS#1 v1.5 encryption of
 * the password, and the account has to have a password set in the iFlytek
 * account centre first — an extra setup step this plugin cannot walk a user
 * through from a settings card.
 *
 * Every request to the account service is HMAC-SHA1 signed. The key pair below
 * ships inside every Loomy client; the doc comment says as much, and the
 * protocol reference confirms it is a client constant, not a secret.
 *
 * @module dsh-loomy-connect/account-auth
 */
/** Where the account service lives. */
declare const LOOMY_ACCOUNT_BASE = "https://account.xfinfr.com";
/** App id Loomy's clients send in every account-service envelope. */
declare const LOOMY_ACCOUNT_APPID = "GM3LOOMY";
/**
 * The client-shipped signing pair.
 *
 * Present in every Loomy installation and used only to talk to the account
 * service — the model gateway never sees it. Overridable through the
 * environment for a build that ships different values.
 */
declare const LOOMY_ACCOUNT_ACCESS_KEY_ID: string;
declare const LOOMY_ACCOUNT_ACCESS_KEY_SECRET: string;
/** How long a session is requested for: 14 days, the service's maximum. */
declare const LOOMY_SESSION_EXPIRE_SECONDS: number;
/** What a signed-in account looks like. */
interface LoomyAccountCredential {
  /** The session token; this is the Bearer the model gateway wants. */
  session: string;
  /** Loomy's numeric account id, sent as `X-User-Id`. */
  userId: string;
  /** Already-masked phone number, for display only. */
  maskedPhone?: string;
}
/** Raised for a business-level account-service failure. */
declare class LoomyAccountError extends Error {
  /** iFlytek's own code, e.g. `000000` on success. */
  readonly code: string;
  /** HTTP status, or 0 for a transport failure. */
  readonly status: number;
  constructor(message: string, code: string, status: number);
}
/** An SMS code request the caller must echo back with the code. */
interface LoomySmsChallenge {
  /** Server-side handle for this code. */
  messageId: string;
  /** Seconds the code stays valid. */
  expiresIn: number;
}
/**
 * Sign one account-service request.
 *
 * The signed string is nine lines — method, escaped path, escaped query,
 * content MD5, content type, date, nonce, signed-header names, and the
 * canonicalised `x-*` headers. The last two are empty when no custom headers
 * are sent, but they must still be present: the server counts lines.
 */
declare function accountRequestHeaders(path: string, body: string, options?: {
  accessKeyId?: string;
  accessKeySecret?: string;
  now?: number;
}): Record<string, string>;
/** The subset of a fetch response this module needs. */
interface LoomyAccountResponse {
  ok: boolean;
  status: number;
  text(): Promise<string>;
}
/** Injection seam so a test can drive the client without a network. */
type LoomyAccountFetch = (url: string, init: {
  method: string;
  headers: Record<string, string>;
  body?: string;
}) => Promise<LoomyAccountResponse>;
/** Mask an 11-digit mainland-China phone for display: `176****7973`. */
declare function maskPhoneNumber(value: string): string;
/**
 * The iFlytek account client: SMS sign-in and the session that comes with it.
 *
 * Stateless — the caller supplies the session — so the settings card and a
 * background refresh can share one instance.
 */
declare class LoomyAccountClient {
  private readonly base;
  private readonly doFetch;
  constructor(options?: {
    base?: string;
    fetch?: LoomyAccountFetch;
  });
  /** One signed call, unwrapping iFlytek's `{ code, desc, data }` envelope. */
  private call;
  /** Ask iFlytek to text a sign-in code to `phone`. */
  sendSmsCode(phone: string): Promise<LoomySmsChallenge>;
  /**
   * Exchange a texted code for a session.
   *
   * `expire` asks the service to keep the session for two weeks; that is also
   * the maximum, and there is no refresh token — an expired session means
   * signing in again.
   */
  loginWithSmsCode(phone: string, code: string, messageId: string): Promise<LoomyAccountCredential>;
  /**
   * Confirm a session is still live, and read the identity behind it.
   *
   * Used right after sign-in to reject a session the service will not honour,
   * and on startup to decide whether a stored session is still usable.
   */
  me(session: string): Promise<LoomyAccountCredential>;
  /** Sign the session out upstream. */
  logout(session: string): Promise<void>;
}
//#endregion
//#region src/login-route.d.ts
/** What the route needs from the plugin. */
interface LoomyLoginRouteOptions {
  /** Ask iFlytek to text a code to `phone`. */
  requestCode: (phone: string) => Promise<{
    messageId: string;
    expiresIn: number;
  }>;
  /** Exchange a code for a session, store it, and report whether it persisted. */
  verifyCode: (phone: string, code: string, messageId: string) => Promise<{
    account?: string;
    persistent: boolean;
  }>;
  /** Drop the stored session. */
  logout: () => Promise<void>;
}
/** The sign-in route's request handler, extracted so tests can mount it bare. */
declare function loomyLoginHandler(deps: LoomyLoginRouteOptions): (req: IncomingMessage, res: ServerResponse) => Promise<void>;
/** Mount the POST sign-in route on an optional webServer context. */
declare function registerLoomyLoginRoute(ctx: Context, deps: LoomyLoginRouteOptions): void;
//#endregion
//#region src/web-status.d.ts
/** Constructor dependencies. */
interface LoomyStatusRouteOptions {
  /** Current sign-in state; `undefined` means signed out. */
  credential: () => Promise<LoomyCredential | undefined>;
  /** Which credential backs the current sign-in. */
  source?: () => LoomyCredentialSource;
  /**
   * Points summary, or `undefined` when there is nothing to show.
   *
   * `force` is the manual refresh: a live backend should bypass its own
   * memoization rather than answer from the previous reading.
   */
  points: (force: boolean) => Promise<LoomyPointsSummary | undefined>;
  /** True when {@link points} is a live reading rather than a cache. */
  pointsLive?: () => boolean;
  /** How many models the plugin currently serves. */
  modelCount: () => number;
  /** Every model the account can reach, for the card to list with its rate. */
  models?: () => LoomyWebModel[];
  /** Ids the user switched off, so the card can mark them without guessing. */
  blockedModels?: () => readonly string[];
  /**
   * Re-pull the catalog and drop the memoized points read. Called for an
   * explicit refresh only — the card's polling pass must stay cheap.
   */
  refresh?: () => Promise<void>;
}
/**
 * Assemble the card's status document.
 *
 * `force` re-reads everything before answering: the model list is re-pulled and
 * the memoized points read is dropped. Without it the answer is assembled from
 * whatever the host already holds, which is what the card's polling wants.
 *
 * Points come from Loomy's own cache, so a missing or unreadable cache
 * degrades to `pointsError` rather than failing the whole document.
 */
declare function loomyWebStatus(deps: LoomyStatusRouteOptions, force?: boolean): Promise<LoomyWebStatus>;
/** The status route's request handler, extracted so tests can mount it on a bare server. */
declare function loomyStatusHandler(deps: LoomyStatusRouteOptions): (req: IncomingMessage, res: ServerResponse) => Promise<void>;
/** Mount the GET status route on an optional webServer context. */
declare function registerLoomyStatusRoute(ctx: Context, deps: LoomyStatusRouteOptions): void;
//#endregion
//#region src/index.d.ts
declare const name = "llm-loomy";
declare const inject: string[];
/**
 * Runtime config schema. cordis resolves a loader entry's config through this
 * schema before calling `apply`.
 *
 * DSH 0.2.x only exposes fields marked `.volatile()` to the settings forms,
 * and commits a live edit into the running config reference instead of
 * remounting the plugin. The two paths are therefore read through
 * {@link readField} on every request rather than copied into a closure.
 */
declare const Config: Schema<Schemastery.ObjectS<NoInfer<{
  authFile: Schema<string, string, "volatile">;
  configFile: Schema<string, string, "volatile">;
  disabledModels: Schema<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
  authFile: Schema<string, string, "volatile">;
  configFile: Schema<string, string, "volatile">;
  disabledModels: Schema<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
}>>, "plain">;
/** One config field: a plain value, or a reference the loader commits into. */
type Field<T> = T | {
  get(): T;
} | undefined;
/** Config as seen inside {@link apply}. */
interface ConfigShape {
  authFile?: Field<string>;
  configFile?: Field<string>;
  disabledModels?: Field<string[]>;
}
declare function apply(ctx: Context, config?: ConfigShape): void;
//#endregion
export { Config, ConfigShape, LOOMY_ACCOUNT_ACCESS_KEY_ID, LOOMY_ACCOUNT_ACCESS_KEY_SECRET, LOOMY_ACCOUNT_APPID, LOOMY_ACCOUNT_BASE, LOOMY_API_BASE, LOOMY_AUTH_SESSION_KEY, LOOMY_ENTRY_ID, LOOMY_LOGIN_PATH, LOOMY_PACKAGE, LOOMY_POINTS_KEY, LOOMY_PROVIDER, LOOMY_SESSION_EXPIRE_SECONDS, LOOMY_STATE_DIR_ENV, LOOMY_STATUS_PATH, LoomyAccountClient, type LoomyAccountCredential, LoomyAccountError, type LoomyAdapter, type LoomyAuthFile, LoomyCatalog, type LoomyCredential, type LoomyLoginRouteOptions, type LoomyModel, type LoomyPointsReading, type LoomyPointsSummary, LoomySessionRejected, type LoomyShim, type LoomyShimOptions, type LoomySmsChallenge, type LoomyStatusRouteOptions, LoomyUpstreamClient, type LoomyWebPoints, type LoomyWebStatus, type StoredAccountSession, accountRequestHeaders, accountSessionPath, apply, createLoomyAdapter, createLoomyShim, defaultLoomyAuthPath, defaultLoomyConfigPath, defaultLoomyLocalStorageDir, extractLoomyAuthSessions, extractLoomyPoints, inject, loomyLoginHandler, loomyStatusHandler, loomyWebStatus, loopbackHost, loopbackOrigin, maskPhoneNumber, name, newestLoomyPoints, parseLoomyApiModels, parseLoomyAuth, parseLoomyModels, parseLoomyPointsRecord, prepareLoomyBody, readAccountSession, readLoomyCredential, readLoomyPoints, readLoomySessionFromStorage, registerLoomyLoginRoute, registerLoomyStatusRoute, resetLoomyPointsCache, resolveAuthFile, writeAccountSession };