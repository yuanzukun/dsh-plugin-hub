# DSH Loomy Connect — 0.2.1 适配分支

本仓库是 [gdrpzym/dsh-loomy-connect](https://github.com/gdrpzym/dsh-loomy-connect) 的派生版本，目标是把插件适配到 **DeepSeek Harness 0.2.1**（当前 npm `latest` 为 `0.2.1-rc.2`），并在其上补齐上游未实现的账号登录能力。

- 上游基线：`dsh-loomy-connect@0.2.0`（2026-09-12）
- 本分支版本：**0.4.0**
- 兼容范围：DSH `>=0.2.1-rc.2 <0.3.0`，Node `>=22.19`
- 许可：沿用上游 **MIT**，原始版权归 `gdrpzym` 所有；本分支改动同样以 MIT 发布。

## 改了什么

### 0.3.x：适配 DSH 0.2.1

| 层面 | 上游（0.2.0） | 本分支 |
|---|---|---|
| 安装门禁 | 只有 `^0.1.5-rc.x` peers | 声明 `engines.dsh`，peers 全部对齐 0.2.1 |
| 配置命名空间 | `settings.installSection(...)` 注册 | 删除该调用；配置项标记 `.volatile()`，命名空间取 loader entry id |
| 配置读取 | 通过 settings `setSource` thunk | 直接读 volatile 引用，兼容 `.get()` 形态；监听 `loader/volatile-update` |
| 插件配置卡片 | `settings.plugin.item` | `plugins.bundle.config`（完整面板） |
| 路径覆盖 | 自动生成表单 | `plugins.row.config`（可保存的 `authFile`/`configFile`） |
| 模型页 | 无 | `settings.models.provider-card` 精简状态条 |
| 文案/图标 | 仅运行时 locale | 增加 `./locale/*.json` 与 `./icon` 资源子路径 |

### 0.4.0：账号登录与实时积分（新增能力）

上游 issue #1 提到的 OAuth/云端登录，本分支以**短信登录**的形式实现。

| 层面 | 上游（0.2.0） | 本分支（0.4.0） |
|---|---|---|
| 登录方式 | 只能读 Loomy 桌面端落盘的登录态 | 手机号 + 短信验证码，插件自己换 session；桌面端登录态降为可选回退 |
| 是否需桌面端 | 必需 | **不需要** |
| 积分来源 | 读 Loomy 本地 localStorage 缓存（可能滞后数天） | 走 `/points/records` 正式账本接口，**实时** |
| 会话持久化 | 无（每次读桌面端文件） | `~/.dsh/loomy-account.json`，权限 `0600`，14 天有效 |
| 登录界面 | 无 | 插件页内嵌两步登录表单 + 退出登录 |

新增模块：`account-auth.ts`（讯飞账号服务签名与登录）、`account-session.ts`（会话落盘）、`login-route.ts`（宿主侧登录路由）。

功能逻辑（回环网关、模型目录、HTTP 状态路由）保持不变。

## 安装

```bash
dsh plugin --profile web add /绝对路径/dsh-loomy-connect
dsh web
```

安装后在插件页填手机号收验证码即可，无需 Loomy 桌面应用。

## 已知限制

- 依赖 Loomy 与讯飞账号服务的非公开接口，Loomy 更新后可能需要调整。
- 会话 14 天到期且无 refresh token，到期需重新短信登录；插件不保存密码。
- 只实现短信登录，未实现密码登录（需账号在讯飞账号中心单独设置密码，无法从插件引导完成）。
- 沙箱/CI 中没有 Loomy 账号，因此只能验证未登录态、fallback 模型目录与错误分支；真实登录与积分需要在有账号的机器上复核。

## 上游

上游项目与 Loomy、讯飞、DeepSeek 均无关联，未获其授权或认可。本分支同样不代表任何官方立场。

账号服务的协议细节参考 [loomy2api](https://github.com/Patrick130306/loomy2api) 的逆向文档，本项目未引入其代码或依赖。
