# DSH Loomy Connect

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

[简体中文](README.md) | English

> **Derivative notice**: this project is a fork of [gdrpzym/dsh-loomy-connect](https://github.com/gdrpzym/dsh-loomy-connect), upstream baseline `0.2.0` (MIT, original copyright held by `gdrpzym`), adapted here to DSH 0.2.1. See [FORK.md](FORK.md) for the change list and licensing.

Sign in with a Loomy account and use its text models from [DeepSeek Harness](https://github.com/deepseek-ai) (DSH), without an API key.

**The Loomy desktop app is not required**: enter a phone number on the plugin page and confirm one SMS code. The plugin holds the session itself, valid for 14 days.

On a machine that does have the desktop app, its existing sign-in is reused instead, so no second login is needed.

> **Note**: this fork and the upstream [gdrpzym/dsh-loomy-connect](https://github.com/gdrpzym/dsh-loomy-connect) register the same `loomy` provider and **cannot be installed together**. Uninstall one before installing the other.

| Contribution | Surface | Description |
|---|---|---|
| Model provider | Host | Registers a `loomy` provider; the model list is discovered from Loomy at startup |
| Settings card | Browser | Two tabs — **Account** and **Models** — under **Settings → Plugin configuration**: Account shows sign-in state, masked phone, and credit balance; Models renders a table of each model's name, context window, and rate, with image models sorted last |
| Sign-in form | Browser | While signed out — or while running on the desktop app's session — the card shows "Sign in to your Loomy account": phone number → SMS code → done |

## Contents

- [Derivative notice (FORK.md)](FORK.md)
- [Features](#features)
- [Installation](#installation)
- [Sign-in](#sign-in)
- [Configuration](#configuration)
- [Security model](#security-model)
- [Known limitations](#known-limitations)
- [Troubleshooting](#troubleshooting)
- [Further documentation](#further-documentation)
- [License](#license)
- [Disclaimer](#disclaimer)
- [Acknowledgments](#acknowledgments)

## Features

- **Zero configuration**: once installed and enabled, Loomy's models appear directly in DSH's model selector.
- **SMS sign-in**: a phone number and a code, nothing else — no password, no desktop app. The plugin exchanges them for a session through `/login/phone/sendMsgCode` and `/login/phone/checkCode`; the session lasts 14 days.
- **Live credits**: signed in, the balance comes from Loomy's points ledger (`/points/records`). The Refresh button pulls it again immediately, so the figures no longer lag behind a local cache.
- **Model auto-discovery**: the account's model list is fetched at startup; only models with text output are served.
- **Rates and promos**: the plugin page's **Models** tab lists every model with its points multiplier (`x3.0`) and flags limited-time free ones, following Loomy's own numbers.
- **Account and credits**: the page's status row shows the signed-in account (masked phone); the **Points** tab shows long-lived and daily credits.
- **Model details**: the **Models** tab renders a three-column table of each model's name, context window (when Loomy's list provides it), and points rate; image models are listed after the chat models.
- **Models-page status bar**: the Loomy card under Settings → Models shows sign-in state and the permanent balance inline.
- **Per-model switch**: each model can be enabled or disabled on the `llm-loomy` row configuration page; a disabled model stops appearing in DSH's model selector, and the change applies without a restart.
- **Image input**: images can be sent to the models, converted by the host's attachment service into image content on the request.
- **Tool calling**: models return `tool_calls` normally, so DSH's tool chain is unaffected.
- **Bilingual**: UI copy follows the DSH interface language.

## Where it appears (DSH 0.2.1)

| Location | Content |
|---|---|
| Settings → Plugins → **DSH Loomy Connect** | Account, points, model table, sign-in form, sign out, manual refresh |
| That plugin's **llm-loomy** row → configuration page | `authFile` / `configFile` overrides; the page ends with the disabled-models switch, saved and applied live |
| Settings → Models → **Loomy** card | Compact status line (sign-in, permanent points, refresh) |

## Installation

| | |
|---|---|
| **Loomy account** | A phone number that can receive SMS |
| **Loomy desktop app** | **Optional.** When installed and signed in, the plugin reuses that session instead of asking you to sign in again |
| **DeepSeek Harness** | `>= 0.2.1-rc.2 < 0.3.0` |
| **Node.js** | `>= 22.19` |
| **pnpm** | Required. `dsh plugin` manages profile dependencies through pnpm; having only npm is not enough |

### From the plugin market (recommended)

Search for `loomy` under **Plugins → Plugin market** in DSH, or open the entry directly:

```
https://awesome-dsh-plugin.com/p/2239058652/dsh-loomy-connect/
```

This repository is listed in [awesome-dsh-plugin](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin); the market picks it up automatically.

### From GitHub

```sh
dsh plugin --profile web add github:2239058652/dsh-loomy-connect
dsh web
```

This repository commits its build output in `lib/`, so installing does **not** run a build — no tsdown or TypeScript needed.

Without a global `dsh`, replace `dsh` with either of the following (both only fetch dsh itself; the plugin install still goes through pnpm):

```sh
npx @deepseek-ai/dsh plugin --profile web add github:2239058652/dsh-loomy-connect
pnpm dlx @deepseek-ai/dsh plugin --profile web add github:2239058652/dsh-loomy-connect
```

### From a local checkout (when editing code)

```sh
git clone https://github.com/2239058652/dsh-loomy-connect.git
cd dsh-loomy-connect
pnpm install
pnpm run build          # only needed after editing src/; output goes to lib/
dsh plugin --profile web add /absolute/path/to/dsh-loomy-connect
dsh web
```

Verifying:

```sh
dsh --profile web --dump-config     # expect an `llm-loomy` entry
```

`--dump-config` only composes the config tree; it does not instantiate the plugin. To confirm the plugin actually boots, run `dsh web` and check for **Loomy** in the model selector.

## Sign-in

Open **Settings → Plugins → DSH Loomy Connect**:

1. While the status row reads "Not signed in", the card shows **Sign in to your Loomy account**.
2. Enter the phone number and choose **Send code**.
3. Enter the 6-digit code and choose **Sign in**.

After signing in:

| Status-row tag | Meaning |
|---|---|
| `Loomy account` | The plugin holds its own session; credits are live and a **Sign out** button appears |
| `Desktop app` | Running on the Loomy desktop app's session; credits are read from its local cache |

**The sign-in form stays visible on the desktop source** — signing in once switches to the account mode and live credits. Both modes chat normally; only the freshness of the credit figures differs.

### Credential precedence

```
The plugin's own account session  →  Loomy desktop app session  →  signed out (chat returns 502)
```

The account session lives in `~/.dsh/loomy-account.json` (move it with `DSH_HOME`). The file holds only the session and the account id, with mode `0600`.

### Session lifetime

A Loomy session **expires after 14 days and there is no refresh token**. When it lapses the card shows "not signed in" again; run the SMS sign-in once more.

## Configuration

Paths are auto-detected per platform, so configuration is normally unnecessary. **The overrides below only matter in desktop-session mode**; account mode reads no local files.

| Variable | Overrides |
|---|---|
| `LOOMY_AUTH_FILE` | Sign-in session `auth-session.json` path |
| `LOOMY_CONFIG_FILE` | Model manifest `opencode.json` path |
| `LOOMY_LOCAL_STORAGE_DIR` | Credits cache `Local Storage/leveldb` directory |
| `DSH_HOME` | Parent directory of the account session (default `~/.dsh`) |
| `LOOMY_AK_ID` / `LOOMY_AK_SECRET` | Signing pair for the account service (only needed when the official client ships different constants) |

Resolution order per lookup: **plugin config (`authFile` / `configFile`) → environment variable → detected default**.

Default paths are probed across macOS and Windows; the first existing path wins:

| Platform | Sign-in session | Model manifest | Credits cache |
|---|---|---|---|
| Windows | `%APPDATA%/loomy/auth-session.json` | `%APPDATA%/loomy-opencode/opencode.json` | `%APPDATA%/loomy/Local Storage/leveldb` |

## Security model

| Boundary | Mechanism |
|---|---|
| Network exposure | Gateway binds `127.0.0.1` only |
| Client authentication | Per-process random secret, compared with `timingSafeEqual` |
| DNS rebinding | `Host` must be loopback |
| Cross-site simple requests | `Origin`, when sent, must be loopback; request body must be `application/json` |
| Token custody | The Loomy session token stays host-side: in account mode it lives in `~/.dsh/loomy-account.json` (`0600`); in desktop mode it is read from disk inside the gateway per request. Neither mode hands the token to the browser |
| Sign-in form | The code and the session never pass through the page: the browser sends only the phone number and the code, the host exchanges them and writes the session, and the reply carries just success/failure plus the masked phone |

Threat model: protects against other local processes and against web pages running in the user's browser. It does **not** protect against code running as the same user, which can read the same files the plugin reads.

## Known limitations

- Depends on Loomy's and iFlytek's account-service interfaces (not an official public API); upstream updates may require plugin changes.
- Sessions expire after 14 days with no refresh token, so signing in again is required; the plugin never stores a password.
- Only SMS sign-in is implemented. Password sign-in needs a password set in the iFlytek account centre first, which a settings card cannot walk a user through.
- The model list and its rates come from Loomy's API; when there is no sign-in, or the gateway refuses the credential, the plugin treats that as signed out and serves no models at all (rather than a stale list whose every request would fail). The built-in snapshot is only used when the API is temporarily unreachable *and* Loomy's generated config cannot be read either.
- In desktop-session mode credits are read from Loomy's local cache and can lag; account mode reads the live ledger instead.
- The model manifest is read at startup; choose Refresh or restart DSH after Loomy adds or removes models.
- Image input needs the host's attachment service (the default `@deepseek-ai/dsh-attachment` composition provides it); in a headless composition without it, requests carrying images are refused.
- This fork and the upstream [gdrpzym/dsh-loomy-connect](https://github.com/gdrpzym/dsh-loomy-connect) register the same `loomy` provider and **cannot be installed together**; switching between them requires an uninstall first.
- If the desktop sign-in path is not detected on Windows, set `LOOMY_AUTH_FILE` explicitly (desktop mode only).

## Troubleshooting

| Symptom | Cause |
|---|---|
| Card never appears under Plugin configuration | Host half did not register the namespace; see item 4 in [docs/internals.en.md](docs/internals.en.md#browser-half) |
| Plugin listed under Plugins but no card | Same as above — the Plugins tab reflects installed entries, not served namespaces |
| `Cannot read properties of undefined (reading 'authFile')` at boot | Missing runtime `Config` export; see [docs/internals.en.md](docs/internals.en.md#cordis-config-schema) |
| Sending a code reports an invalid phone number | Only 11-digit mainland-China numbers are accepted, without `+86` |
| Signed in, yet the card still says signed out | The session was written but DSH has not re-read it; refresh the page or restart DSH |
| "session could not be saved to disk" after signing in | `~/.dsh` is not writable; the session lasts only this process and is lost on restart |
| Card shows "not signed in" though you signed in earlier | The session passed its 14-day lifetime; run the SMS sign-in again |
| `502` on every chat request | No usable session in either mode: sign in, or check whether the desktop app was ever signed in |
| Model list is stale | Choose Refresh, or restart DSH |
| Credits empty | Desktop mode: Loomy has not cached a summary yet, or `LOOMY_LOCAL_STORAGE_DIR` is wrong. Account mode: usually an expired session |

## Further documentation

Architecture, gateway, and browser-card constraints are documented in [docs/internals.en.md](docs/internals.en.md) (中文版 [docs/internals.md](docs/internals.md)).

## License

[MIT](LICENSE)

## Disclaimer

- This project is for **personal learning and research only**. It drives your own Loomy account on your own machine. Do not use it commercially or beyond reasonable personal use.
- You must comply with the Loomy terms of service. Any consequence of using this project — including account restrictions, depleted credits, or service interruption — is yours to bear.
- The author is not liable for any direct or indirect loss arising from the use or misuse of this project.
- This project is not affiliated with, endorsed by, or sponsored by Loomy, iFlytek, or DeepSeek. Product names are used to describe compatibility only; trademarks belong to their respective owners.

## Acknowledgments

- [gdrpzym/dsh-loomy-connect](https://github.com/gdrpzym/dsh-loomy-connect) (MIT): the upstream baseline `0.2.0` this fork derives from, and the origin of the provider registration, loopback gateway, credential parsing, model catalog, and credits reading.
- [Patrick130306/loomy2api](https://github.com/Patrick130306/loomy2api): the protocol reference for iFlytek's account-service HMAC-SHA1 signing and its login endpoints (`getPuKey` / `sendMsgCode` / `checkCode`). This project ports only the SMS sign-in and the points ledger calls, and includes none of its code or dependencies.
- The DSH provider architecture follows [dsh-workbuddy-connect](https://github.com/corrinehu/dsh-workbuddy-connect) (MIT).
