// Right-sidebar tab showing one thread's live conversation, with its own composer.
// Body shape copied from dsh-client-ui-subagent's SidebarChatTab / ConversationSlotPanel,
// but for ordinary sessions (the `subagentchat` resource would reroute them as subagents).
import { useState, type ReactNode } from 'react'
import { glyphState, ThreadGlyph } from './glyphs.tsx'
import type { Translate } from './locale.ts'
import { setThreadArchived, setThreadResolved, stopThread } from './resolved.ts'
import { parseThreadAddress, type ThreadDetail, useHostValue, useLive, type UseStatus, useThreadsRevision } from './threads.ts'
import { ArchiveIcon, BranchChip, CheckIcon, ExpandIcon, Pill, ReopenIcon, StopIcon } from './ui.tsx'

/** Session-scoped child slot this tab declares; only the declaring entry may render it. */
export const THREAD_CONVERSATION_SLOT = 'dsh-threads.chat.conversation'

type RenderSlot = (name: string, props: Record<string, unknown>, options?: unknown) => ReactNode

export function ThreadChatTab({ useTabInfo, useResource, SessionProvider, renderSlot, useSessionStatus, t, openSession }: {
  useTabInfo: () => { tab: { contentId: string } }
  useResource: (address: string) => { value?: { reference: unknown } }
  SessionProvider: (props: { session: unknown; children: ReactNode }) => ReactNode
  renderSlot: RenderSlot
  useSessionStatus: UseStatus
  t: Translate
  openSession: (sessionId: string) => void
}) {
  const { tab } = useTabInfo()
  const threadId = parseThreadAddress(tab.contentId)
  const resource = useResource(tab.contentId)
  return (
    <div className="dsht-chat" data-dsh-threads-chat="">
      {threadId === undefined ? null : <ThreadPaneHeader threadId={threadId} useSessionStatus={useSessionStatus} t={t} openSession={openSession} />}
      <div className="dsht-chat-body">
        {resource.value === undefined
          ? null
          : <SessionProvider session={resource.value.reference}>{renderSlot(THREAD_CONVERSATION_SLOT, {})}</SessionProvider>}
      </div>
    </div>
  )
}

function ThreadPaneHeader({ threadId, useSessionStatus, t, openSession }: {
  threadId: string
  useSessionStatus: UseStatus
  t: Translate
  openSession: (sessionId: string) => void
}) {
  const live = useLive(useSessionStatus)
  const running = live.running.has(threadId)
  const revision = useThreadsRevision()
  const thread = useHostValue<ThreadDetail>('threads.get', { id: threadId }, [threadId, running, revision])
  const [busy, setBusy] = useState(false)
  if (thread === undefined) return <div className="dsht-pane-head" />
  // A refusal here only means the state changed under the button; the views reload either way.
  const act = (action: () => Promise<void>) => {
    setBusy(true)
    void action().catch(() => {}).finally(() => setBusy(false))
  }
  return (
    <div className="dsht-pane-head">
      <ThreadGlyph state={glyphState(thread, running, live.asking.has(threadId))} />
      <div className="dsht-pane-text">
        <div className="dsht-pane-title" title={thread.title}><span className="dsht-item-n">#{thread.n}</span>{thread.title}</div>
        <div className="dsht-pane-meta">
          {thread.projectTitle === null ? null : <span>{thread.projectTitle}</span>}
          {thread.archived ? <span>{t('pane.archived')}</span> : null}
          {thread.worktree === null ? null : <BranchChip branch={thread.worktree.branch} removed={thread.worktree.removed} />}
        </div>
      </div>
      <div className="dsht-pane-actions">
        {running
          ? <Pill icon={<StopIcon />} disabled={busy} onClick={() => act(() => stopThread(threadId))}>{t('pane.stop')}</Pill>
          : thread.archived
            ? <Pill icon={<ArchiveIcon />} disabled={busy} onClick={() => act(() => setThreadArchived(threadId, false))}>{t('pane.unarchive')}</Pill>
            : <>
                <Pill icon={thread.resolved ? <ReopenIcon /> : <CheckIcon />} disabled={busy} onClick={() => act(() => setThreadResolved(threadId, !thread.resolved))}>
                  {thread.resolved ? t('pane.reopen') : t('pane.resolve')}
                </Pill>
                <Pill icon={<ArchiveIcon />} label={t('pane.archive')} disabled={busy} onClick={() => act(() => setThreadArchived(threadId, true))} />
              </>}
        <Pill icon={<ExpandIcon />} onClick={() => openSession(threadId)}>{t('pane.openMain')}</Pill>
      </div>
    </div>
  )
}

/** The embedded Conversation for the thread the tab's SessionProvider supplies. */
export function ThreadConversation({ sessionId, useSession, useConversation, useSessions, renderFactorySlot }: {
  sessionId: string
  useSession: <T>(selector: (session: SessionLike) => T) => T
  useConversation: <T>(selector: (conversation: { activeTargets: { size: number } }) => T) => T
  useSessions: <T>(selector: (state: { byId: Record<string, { blank?: boolean } | undefined> }) => T) => T
  renderFactorySlot: (name: string, props: Record<string, unknown>, options: { slots: Record<string, unknown> }) => ReactNode
}) {
  const session = useSession((value) => value)
  const active = useConversation((value) => value.activeTargets.size > 0) || (!session.blank && !session.awaitingFirstTurn) || session.running
  const summaryBlank = useSessions((state) => state.byId[sessionId]?.blank)
  // Never show the blank-session hero: its workspace picker would move the main view.
  const settling = !active && session.openState === 'loading' && summaryBlank !== true
  return renderFactorySlot(
    'conversation.content',
    { variant: 'embedded', phase: settling ? 'settling' : 'active', hero: false },
    { slots: { views: FixedChatConversationView } },
  )
}

interface SessionLike {
  blank: boolean
  awaitingFirstTurn: boolean
  running: boolean
  openState: string
}

function FixedChatConversationView(props: { renderSlot: RenderSlot }) {
  return <>{props.renderSlot('conversation.session', { view: 'chat' })}</>
}

/** Replaces the composer of a resolved thread (conversation.composer chain). */
export function ResolvedComposer({ sessionId, t }: { sessionId: string; t: Translate }) {
  const [busy, setBusy] = useState(false)
  return (
    <div className="dsht-resolved">
      <ThreadGlyph state="resolved" />
      <span className="dsht-resolved-text"><b>{t('resolved.notice')}</b>{t('resolved.hint')}</span>
      <Pill disabled={busy} onClick={() => {
        setBusy(true)
        void setThreadResolved(sessionId, false).finally(() => setBusy(false))
      }}>
        {t('resolved.reopen')}
      </Pill>
    </div>
  )
}
