# sync.ps1 - one-click deploy dsh-veneer to the DSH profile directory
# Usage: powershell -ExecutionPolicy Bypass -File .\sync.ps1
# NOTE: copies runtime files + verifies SHA256. Host-side changes require a dsh web restart.

param(
    [switch]$AllowManagedOverwrite
)

$ErrorActionPreference = "Stop"

$src = Split-Path -Parent $MyInvocation.MyCommand.Path
$dst = Join-Path $env:USERPROFILE ".dsh\profiles\web\node_modules\dsh-veneer"
$webPackage = Join-Path $env:USERPROFILE ".dsh\profiles\web\package.json"

Write-Host "==> source: $src"
Write-Host "==> target: $dst"

if (Test-Path -LiteralPath $webPackage) {
    $profile = Get-Content -LiteralPath $webPackage -Raw | ConvertFrom-Json
    $bundles = $profile.dsh.profile.bundles
    $managed = $bundles -is [System.Array] -and ($bundles -contains "dsh-veneer")
    if ($managed -and -not $AllowManagedOverwrite) {
        Write-Host "Refusing to overwrite a dsh plugin-managed package." -ForegroundColor Yellow
        Write-Host "Use 'dsh plugin --profile web update dsh-veneer', or pass -AllowManagedOverwrite for an explicit local development deployment."
        exit 2
    }
}

# 1. Syntax check
Write-Host ""
Write-Host "==> node --check ..."
foreach ($f in @("lib\client.js", "lib\index.js", "lib\theme-storage.js", "lib\llm-errors.js")) {
    node --check (Join-Path $src $f)
    if ($LASTEXITCODE -ne 0) {
        Write-Host "  x $f syntax check FAILED" -ForegroundColor Red
        exit 1
    }
    Write-Host "  OK $f"
}

# 2. Copy runtime files only. The target may be managed by `dsh plugin`, so never
# mirror repository-only files (tests, docs, diagnostics, release artifacts) into it.
Write-Host ""
Write-Host "==> copying files to target ..."
New-Item -ItemType Directory -Path $dst -Force | Out-Null
foreach ($rel in @("package.json", "cordis.patch.yml", "lib")) {
    $srcItem = Join-Path $src $rel
    if (-not (Test-Path -LiteralPath $srcItem)) {
        Write-Host "  x missing runtime item: $rel" -ForegroundColor Red
        exit 1
    }
    Copy-Item -LiteralPath $srcItem -Destination $dst -Recurse -Force
    Write-Host "  OK $rel"
}

# 3. SHA256 compare
Write-Host ""
Write-Host "==> SHA256 verify ..."
$files = @("package.json", "cordis.patch.yml", "lib\client.js", "lib\index.js", "lib\theme-storage.js", "lib\llm-errors.js")
$allMatch = $true
foreach ($f in $files) {
    $srcFile = Join-Path $src $f
    $dstFile = Join-Path $dst $f
    $srcHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $srcFile).Hash
    $dstHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $dstFile).Hash
    $ok = $srcHash -eq $dstHash
    if (-not $ok) { $allMatch = $false }
    if ($ok) {
        Write-Host "  OK  $f -> MATCH"
    } else {
        Write-Host "  x   $f -> MISMATCH"
        Write-Host "       src  : $srcHash"
        Write-Host "       depl : $dstHash"
    }
}

if (-not $allMatch) {
    Write-Host ""
    Write-Host "WARNING: files differ, check the output above." -ForegroundColor Yellow
    exit 1
}

Write-Host ""
Write-Host "Deployed and verified. Restart dsh web for Host-side changes; client-only changes need a browser refresh." -ForegroundColor Green
