// ai-colors.browser.test.mjs — real-browser verification of the colour
// coercion in lib/client.js.
//
// Run:  node --test test/ai-colors.browser.test.mjs
//
// Why a second suite? The unit suite (ai-colors.test.mjs) fakes the canvas
// colour parser, so it can only assert what WE believe the browser accepts.
// This suite loads the REAL client.js factory into a real headless browser
// engine (Playwright's bundled Chromium) and calls the same __test hooks, so
// oklch()/hwb()/lab()/color() (CSS Color 4) and the hex edge cases are
// verified against an actual browser engine. The coercion itself only uses
// standard Canvas 2D APIs, so it works in any modern engine (Chromium /
// Firefox / Safari); Chromium here is just the engine Playwright ships.
//
// Playwright is a dev-only convenience: if it (or its browser binary) is not
// installed, the suite skips instead of failing the whole `node --test` run.

import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const here = dirname(fileURLToPath(import.meta.url));
const source = readFileSync(join(here, "..", "lib", "client.js"), "utf8");

let chromium = null;
try {
  ({ chromium } = await import("playwright"));
} catch {
  // playwright not installed -> leave chromium null, tests will skip.
}

const SKIP = chromium ? false : "playwright not installed (skip real-browser suite)";

test("real browser engine: CSS Color 4 colours coerce to #RRGGBBAA", { skip: SKIP }, async () => {
  const browser = await chromium.launch();
  try {
    const page = await browser.newPage();
    await page.goto("about:blank");
    await page.evaluate((src) => {
      // Same loader contract the unit suite uses: client.js is wrapped in
      // window.__ModuleLoader__.load({ id, factory }). Drive the real factory
      // with a react stub and keep the module for the __test hooks.
      window.__ModuleLoader__ = {
        load({ factory }) {
          window.__dshVeneerMod = factory((name) => {
            if (name === "react") {
              return { useState: () => [null, () => {}], useEffect: () => {}, createElement: () => ({}) };
            }
            throw new Error("unexpected require: " + name);
          });
        }
      };
      (0, eval)(src);
    }, source);
    const r = await page.evaluate(() => {
      const { recognizedColor, coerceColor, parseSurface, parseAiTheme } = window.__dshVeneerMod.__test;
      // End-to-end through the real AI-theme pipeline: an oklch surface and a
      // bare-hex font colour must land in the theme as normalised #RRGGBBAA
      // (surface alpha is overridden by the opacity field, default 100 → ff).
      const aiSurface = parseAiTheme(JSON.stringify({
        name: "browser",
        surfaces: [{ token: "--dsw-specific-sidebar-fill", color: "oklch(0.5 0.1 200)" }]
      })).themeEntries;
      const aiFont = parseAiTheme(JSON.stringify({
        // surfaces is a required field in the AI contract, even when empty.
        surfaces: [],
        fonts: [{ key: "global", family: "Inter", color: "0a0a1f" }]
      })).colorEntries;
      return {
        aiSurface,
        aiFont,
        oklch: coerceColor("oklch(0.5 0.1 200)"),
        hwb: coerceColor("hwb(200 20% 10%)"),
        lab: coerceColor("lab(50% 20 30)"),
        p3: coerceColor("color(display-p3 1 0 0)"),
        rgbaPct: coerceColor("rgba(0, 0, 0, 50%)"),
        f008: coerceColor("#f008"),
        hex5: coerceColor("#12345"),
        inject: coerceColor("red; background:url(x)"),
        jsUrl: coerceColor("url(javascript:alert(1))"),
        bare: coerceColor("0a0a1f"),
        surfF008: parseSurface("#f008").color,
        surfHex5: parseSurface("#12345").color,
        surfAbc: parseSurface("#abc").color,
        surfAbcLower: parseSurface("#aabbcc").color,
        surf8: parseSurface("#aabbccdd").color,
        strictF008: recognizedColor("#f008")
      };
    });
    // CSS Color 4 spaces (the whole point of the canvas fallback path).
    assert.equal(r.oklch, "#00747aff");   // oklch(0.5 0.1 200) -> rgb(0,116,122)
    assert.equal(r.hwb, "#33aae6ff");     // hwb(200 20% 10%) -> rgb(51,170,230)
    assert.equal(r.lab, "#a16945ff");     // lab(50% 20 30) -> rgb(161,105,69)
    assert.equal(r.p3, "#ff0000ff");      // display-p3 red (wide gamut, clamped) -> rgb(255,0,0)
    // Full AI-theme pipeline: modern colour spaces survive end to end.
    assert.deepEqual(r.aiSurface, [["--dsw-specific-sidebar-fill", "#00747aff"]]);
    assert.deepEqual(r.aiFont, [["global", "#0A0A1F"]]);
    // Modern syntax / percentages and 4-digit hex.
    assert.equal(r.rgbaPct, "#00000080"); // rgba(0,0,0,50%) -> alpha 128
    assert.equal(r.f008, "#ff000088");    // #RGBA -> #RRGGBBAA
    // Invalid hex is rejected by a real browser engine, not turned black.
    assert.equal(r.hex5, null);           // #12345 is NOT a legal CSS hex colour
    assert.equal(r.strictF008, null);     // strict path keeps only 3/6/8-digit hex
    // Injection strings are silently ignored by canvas -> null.
    assert.equal(r.inject, null);
    assert.equal(r.jsUrl, null);
    // The original 0a0a1f bug stays fixed.
    assert.equal(r.bare, "#0a0a1fff");
    // parseSurface: legal 3/6/8-digit hex kept, 4/5-digit dropped.
    assert.equal(r.surfAbc, "#abc");
    assert.equal(r.surfAbcLower, "#aabbcc");
    assert.equal(r.surf8, "#aabbccdd");
    assert.equal(r.surfF008, "");
    assert.equal(r.surfHex5, "");
  } finally {
    await browser.close();
  }
});
