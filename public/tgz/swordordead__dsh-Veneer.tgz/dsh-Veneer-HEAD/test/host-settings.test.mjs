// host-settings.test.mjs — unit tests for the Host settings section that
// lib/index.js registers when the optional `settings` service is composed.
//
// Run:  node --test test/host-settings.test.mjs
//
// The tests drive lib/index.js through a fake cordis ctx and use
// mock.module to stub the three external packages so the host half can be
// unit-tested without a running harness:
//   - @deepseek-ai/dsh-settings (settingsNamespace)
//   - @deepseek-ai/schemastery (z.object / z.any)
//   - @deepseek-ai/dsh-llm (BlockAssembler / createUserMessage)

import { test, mock } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

// Isolate the bundled-images bootstrap from the real user profile so the test
// never touches the actual DSH storage directory.
const dshHome = mkdtempSync(join(tmpdir(), "dsh-veneer-host-settings-"));
process.env.DSH_HOME = dshHome;

mock.module("@deepseek-ai/dsh-llm", {
  namedExports: {
    BlockAssembler: class BlockAssembler {
      push() {}
      finish = { kind: "ok" };
      blocks() {
        return [];
      }
    },
    createUserMessage: (opts) => ({ ...opts })
  }
});

mock.module("@deepseek-ai/dsh-settings", {
  namedExports: {
    settingsNamespace: (value) => ({ namespace: value })
  }
});

mock.module("@deepseek-ai/schemastery", {
  defaultExport: {
    object: (shape) => ({ kind: "object", shape }),
    any: () => ({ kind: "any" })
  }
});

const { apply, inject } = await import("../lib/index.js");

test.after(() => {
  rmSync(dshHome, { recursive: true, force: true });
});

function makeCtx({ withSettings, onInject }) {
  const routes = [];
  const settingsCtx = {
    settings: {
      register(ns, schema) {
        if (onInject) onInject({ ns, schema });
      }
    }
  };
  return {
    ctx: {
      effect(fn) {
        fn();
      },
      inject(keys, cb) {
        if (withSettings) cb(settingsCtx);
      },
      webServer: {
        register(route) {
          routes.push(route);
        }
      },
      reflect: {
        get() {
          return undefined;
        }
      }
    },
    routes
  };
}

test("static inject stays webServer-only so the plugin never goes inactive", () => {
  assert.deepEqual(inject, ["webServer"]);
});

test("registers the dsh-veneer settings section when settings is available", () => {
  let registered = null;
  const { ctx } = makeCtx({
    withSettings: true,
    onInject: (entry) => {
      registered = entry;
    }
  });

  apply(ctx);

  assert.ok(registered, "settings.register must be called");
  assert.deepEqual(registered.ns, { namespace: "dsh-veneer" });
  assert.equal(registered.schema.kind, "object");
  assert.ok(registered.schema.shape.theme, "schema must expose a theme field");
  assert.equal(registered.schema.shape.theme.kind, "any");
});

test("stays active and registers all routes when settings is absent", () => {
  const { ctx, routes } = makeCtx({ withSettings: false });

  apply(ctx);

  const paths = routes.map((r) => r.path);
  assert.equal(routes.length, 4);
  assert.ok(paths.includes("/api/dsh-veneer/upload"));
  assert.ok(paths.includes("/api/dsh-veneer/images"));
  assert.ok(paths.includes("/api/dsh-veneer/ai/models"));
  assert.ok(paths.includes("/api/dsh-veneer/ai/generate"));
});
