# -*- coding: utf-8 -*-
"""Veneer v0.5.0：AI 主题（复用 Harness 模型目录）+ 样式维度 + 模板库 端到端回归验证（Playwright, Chrome）。

覆盖：
- AI 主题：模型两级下拉（provider/model）存在且默认选中 Harness 默认模型；未选模型 → 面板内提示；
  mock 成功 → 预览条 + body token 更新 + localStorage 未写入；点「应用」→ 写入；再生成另一版 → 点「放弃」→ 恢复；
  mock 401 → 面板内友好错误；生成请求体携带 provider/model（与对话一致，零 API Key 配置）。
- 样式 tab：改强调色 → body 变量更新 + 420ms 后持久化；「恢复默认」清空该 token。
- 模板库：点选模板卡 → 预览 → 应用 → 全量变量生效并持久化。
- 回归 v0.4.1：AI 预览期间编辑背景色不污染 localStorage；AI 输出 opacity null/"" 视为不透明。
- 页面无 pageerror。

运行：python test/ai-theme-check.py（需 Playwright + Chrome，DSH 跑在 127.0.0.1:3080）
"""
import json
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
from playwright.sync_api import sync_playwright

URL = "http://127.0.0.1:3080"
STORAGE_KEY = "dsh-veneer.theme.v1"
TOKEN_SIDEBAR = "--dsw-specific-sidebar-fill"
TOKEN_ACCENT = "--dsw-alias-state-business-primary"

# Harness 模型目录 mock（GET /api/dsh-veneer/ai/models）
MODELS_PAYLOAD = {
    "providers": [
        {
            "id": "deepseek",
            "label": "DeepSeek",
            "models": [
                {"id": "deepseek-v4-flash", "name": "DeepSeek V4 Flash"},
                {"id": "deepseek-chat", "name": "DeepSeek Chat"},
            ],
        }
    ],
    "default": {"provider": "deepseek", "model": "deepseek-v4-flash"},
}

results = {}

# AI 响应 payload（mode 控制内容）
PAYLOADS = {
    "ok1": {
        "content": json.dumps(
            {
                "name": "测试主题A",
                "surfaces": [
                    {"token": TOKEN_SIDEBAR, "color": "#123456", "opacity": 100},
                    {"token": "--dsw-alias-bg-base", "color": "#ABCDEF", "opacity": 100},
                ],
                "fonts": [{"key": "global", "family": "微软雅黑", "color": "#222222"}],
            },
            ensure_ascii=False,
        )
    },
    "ok2": {
        "content": json.dumps(
            {
                "name": "测试主题B",
                "surfaces": [
                    {"token": TOKEN_SIDEBAR, "color": "#654321", "opacity": 100},
                    {"token": "--dsw-alias-bg-base", "color": "#FEDCBA", "opacity": 90},
                ],
                "fonts": [{"key": "input", "family": "宋体", "color": "#333333"}],
            },
            ensure_ascii=False,
        )
    },
    "opacity_null": {
        "content": json.dumps(
            {
                "name": "opacity测试",
                "surfaces": [
                    {"token": TOKEN_SIDEBAR, "color": "#AA0000", "opacity": None},
                    {"token": "--dsw-alias-bg-base", "color": "#00AA00", "opacity": ""},
                ],
                "fonts": [],
            },
            ensure_ascii=False,
        )
    },
}


def wait_for_save(page):
    page.wait_for_timeout(420)


def read_snapshot(page):
    return page.evaluate(
        """key => { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : null; }""",
        STORAGE_KEY,
    )


def body_token(page, token):
    return page.evaluate(
        """token => document.body.style.getPropertyValue(token).trim()""", token
    )


def open_panel(page):
    page.wait_for_selector(".dsh-veneer-toggle", timeout=20000)
    if page.locator(".dsh-veneer-panel").count() == 0:
        page.locator(".dsh-veneer-toggle").click()
    page.wait_for_selector(".dsh-veneer-panel", timeout=10000)


def run_check():
    global results
    mode = {"cur": "ok1"}
    captured = []  # 记录 POST /ai/generate 的请求体
    with sync_playwright() as p:
        browser = p.chromium.launch(channel="chrome", headless=True)
        context = browser.new_context()
        page = context.new_page()
        page_errors = []
        page.on("pageerror", lambda e: page_errors.append(str(e)))

        def handle_models(route):
            route.fulfill(
                status=200,
                content_type="application/json",
                body=json.dumps(MODELS_PAYLOAD),
            )

        def handle_ai(route):
            try:
                captured.append(json.loads(route.request.post_data or "{}"))
            except Exception:
                pass
            if mode["cur"] == "unauthorized":
                # 与后端 sendError 的字符串 error 格式一致（llmFailureText 输出）
                route.fulfill(
                    status=401,
                    content_type="application/json",
                    body=json.dumps({"error": "模型认证失败（API Key 无效或已过期）"}),
                )
            else:
                route.fulfill(
                    status=200,
                    content_type="application/json",
                    body=json.dumps(PAYLOADS[mode["cur"]]),
                )

        page.route("**/api/dsh-veneer/ai/models", handle_models)
        page.route("**/api/dsh-veneer/ai/generate", handle_ai)

        page.goto(URL, wait_until="domcontentloaded", timeout=30000)
        page.evaluate(
            """key => localStorage.removeItem(key)""", STORAGE_KEY
        )
        page.reload(wait_until="domcontentloaded")
        open_panel(page)

        # ── AI 主题 tab ──
        page.locator(".dsh-veneer-tab", has_text="AI 主题").click()
        page.wait_for_selector(".dsh-veneer-ai-generate", timeout=10000)
        results["ai_tab_form"] = page.locator(".dsh-veneer-ai-form").count() == 1

        # 模型两级下拉存在；默认选中 Harness 默认模型（与对话同一目录）
        results["ai_model_selects"] = page.locator(".dsh-veneer-ai-select").count() == 2
        model_select = page.locator('.dsh-veneer-ai-select[title="模型"]')
        provider_select = page.locator('.dsh-veneer-ai-select[title="模型提供方"]')
        page.wait_for_function(
            """() => {
                const sel = document.querySelector('.dsh-veneer-ai-select[title="模型"]');
                return sel && sel.value !== '';
            }""",
            timeout=10000,
        )
        results["ai_default_provider_selected"] = provider_select.input_value() == "deepseek"
        results["ai_default_model_selected"] = model_select.input_value() == "deepseek-v4-flash"

        # 未选模型 → 面板内提示
        page.evaluate(
            """() => {
                const sel = document.querySelector('.dsh-veneer-ai-select[title="模型"]');
                const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value').set;
                setter.call(sel, '');
                sel.dispatchEvent(new Event('change', {bubbles: true}));
            }"""
        )
        page.locator(".dsh-veneer-ai-generate").click()
        page.wait_for_timeout(300)
        err = page.locator(".dsh-veneer-ai-error")
        results["ai_no_model_error"] = "dsh-veneer-visible" in (err.get_attribute("class") or "")
        # 恢复默认模型选择，继续主路径
        page.evaluate(
            """() => {
                const sel = document.querySelector('.dsh-veneer-ai-select[title="模型"]');
                const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value').set;
                setter.call(sel, 'deepseek-v4-flash');
                sel.dispatchEvent(new Event('change', {bubbles: true}));
            }"""
        )
        page.locator(".dsh-veneer-ai-error").evaluate("el => el.classList.remove('dsh-veneer-visible')")

        # mock 成功 → 预览条 + body token 更新 + localStorage 未写入
        captured.clear()
        mode["cur"] = "ok1"
        page.locator(".dsh-veneer-ai-generate").click()
        page.wait_for_selector(".dsh-veneer-ai-preview", timeout=10000)
        results["ai_preview_bar"] = page.locator(".dsh-veneer-ai-preview").count() == 1
        results["ai_body_token"] = body_token(page, TOKEN_SIDEBAR).upper().startswith("#123456")
        results["ai_preview_no_save"] = read_snapshot(page) is None
        # 请求体携带 provider/model（零 API Key）
        req = captured[-1] if captured else {}
        results["ai_request_payload"] = (
            req.get("provider") == "deepseek" and req.get("model") == "deepseek-v4-flash"
            and "apiKey" not in req and "baseUrl" not in req
        )

        # 点「应用」→ 写入 localStorage（AI 输出带 alpha，如 #123456ff）
        page.locator(".dsh-veneer-ai-preview button", has_text="应用").click()
        page.wait_for_timeout(400)
        snap = read_snapshot(page)
        results["ai_applied_saved"] = snap is not None and any(
            k == TOKEN_SIDEBAR and str(v).upper().startswith("#123456")
            for k, v in snap.get("themeOverrides", [])
        )

        # 再生成另一版 → 点「放弃」→ 恢复预览前快照（已保存的主题恢复）
        captured.clear()
        mode["cur"] = "ok2"
        page.locator(".dsh-veneer-ai-generate").click()
        page.wait_for_selector(".dsh-veneer-ai-preview", timeout=10000)
        results["ai_second_preview_body"] = body_token(page, TOKEN_SIDEBAR).upper().startswith("#654321")
        page.locator(".dsh-veneer-ai-preview button", has_text="放弃").click()
        page.wait_for_timeout(300)
        results["ai_discard_restore_saved"] = body_token(page, TOKEN_SIDEBAR).upper().startswith("#123456")
        # 放弃后 storage 仍保留「应用」过的主题（放弃只回退预览）
        snap = read_snapshot(page)
        results["ai_discard_keeps_saved"] = snap is not None and any(
            k == TOKEN_SIDEBAR and str(v).upper().startswith("#123456")
            for k, v in snap.get("themeOverrides", [])
        )

        # mock 401 → 面板内友好错误
        captured.clear()
        mode["cur"] = "unauthorized"
        page.locator(".dsh-veneer-ai-generate").click()
        page.wait_for_timeout(600)
        err = page.locator(".dsh-veneer-ai-error")
        results["ai_401_error"] = "dsh-veneer-visible" in (err.get_attribute("class") or "") and "认证" in err.inner_text()
        results["ai_401_no_preview"] = page.locator(".dsh-veneer-ai-preview").count() == 0

        # ── 样式 tab ──
        page.locator(".dsh-veneer-tab", has_text="样式").click()
        page.wait_for_selector(".dsh-veneer-style-group", timeout=10000)
        accent_sec = page.locator(".dsh-veneer-style-group", has_text="强调色").first
        accent_input = accent_sec.locator(".dsh-veneer-color-input").first
        results["style_accent_exists"] = accent_input.count() == 1
        accent_input.evaluate(
            """(input) => {
                const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
                setter.call(input, '#FF8800');
                input.dispatchEvent(new Event('input', {bubbles: true}));
                input.dispatchEvent(new Event('change', {bubbles: true}));
            }"""
        )
        page.wait_for_timeout(300)
        results["style_accent_body"] = body_token(page, TOKEN_ACCENT).upper() == "#FF8800"
        wait_for_save(page)
        snap = read_snapshot(page)
        results["style_accent_saved"] = snap is not None and any(
            k == TOKEN_ACCENT and str(v).upper() == "#FF8800"
            for k, v in snap.get("themeOverrides", [])
        )
        # 恢复默认 → 清空
        accent_sec.locator(".dsh-veneer-btn", has_text="恢复默认").click()
        page.wait_for_timeout(300)
        snap = read_snapshot(page)
        results["style_accent_reset"] = (
            body_token(page, TOKEN_ACCENT) == ""
            and snap is not None
            and all(k != TOKEN_ACCENT for k, v in snap.get("themeOverrides", []))
        )

        # ── 模板库 ──
        results["template_cards"] = page.locator(".dsh-veneer-template-card").count() >= 8
        page.locator(".dsh-veneer-template-card").first.click()
        page.wait_for_selector(".dsh-veneer-ai-preview", timeout=10000)
        results["template_preview"] = page.locator(".dsh-veneer-ai-preview").count() == 1
        # 模板会写入 sidebar token；应用后应持久化
        page.locator(".dsh-veneer-ai-preview button", has_text="应用").click()
        page.wait_for_timeout(400)
        snap = read_snapshot(page)
        results["template_applied_saved"] = snap is not None and any(
            k == TOKEN_SIDEBAR for k, v in snap.get("themeOverrides", [])
        )

        # ── 回归 v0.4.1：AI 预览期间编辑背景色不得写入 storage ──
        page.evaluate(
            """key => localStorage.removeItem(key)""", STORAGE_KEY
        )
        page.reload(wait_until="domcontentloaded")
        open_panel(page)
        page.locator(".dsh-veneer-tab", has_text="AI 主题").click()
        page.wait_for_selector(".dsh-veneer-ai-generate", timeout=10000)
        mode["cur"] = "ok1"
        page.locator(".dsh-veneer-ai-generate").click()
        page.wait_for_selector(".dsh-veneer-ai-preview", timeout=10000)
        results["regress_preview_edit_clean_start"] = read_snapshot(page) is None
        # 预览态下切到背景 tab 改色 → storage 必须保持 None
        page.locator(".dsh-veneer-tab", has_text="背景").click()
        page.wait_for_selector(".dsh-veneer-surface", timeout=10000)
        page.evaluate(
            """() => {
                const input = document.querySelector('.dsh-veneer-surface .dsh-veneer-color-input');
                const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
                setter.call(input, '#00FF00');
                input.dispatchEvent(new Event('input', {bubbles: true}));
                input.dispatchEvent(new Event('change', {bubbles: true}));
            }"""
        )
        page.wait_for_timeout(450)
        results["regress_preview_edit_no_pollute"] = read_snapshot(page) is None
        # 放弃 → body 恢复为空 → 刷新后 storage 仍空（无 AI 主题残留）
        page.locator(".dsh-veneer-tab", has_text="AI 主题").click()
        page.locator(".dsh-veneer-ai-preview button", has_text="放弃").click()
        page.wait_for_timeout(300)
        results["regress_preview_discard_body_empty"] = body_token(page, TOKEN_SIDEBAR) == ""
        page.reload(wait_until="domcontentloaded")
        page.wait_for_selector(".dsh-veneer-toggle", timeout=20000)
        raw_after = page.evaluate("""key => localStorage.getItem(key)""", STORAGE_KEY)
        results["regress_preview_no_residue_after_reload"] = raw_after is None or raw_after.strip() == ""

        # ── 回归 v0.4.1：AI 输出 opacity null/"" 应视为不透明（alpha=ff）──
        page.evaluate(
            """key => localStorage.removeItem(key)""", STORAGE_KEY
        )
        page.reload(wait_until="domcontentloaded")
        open_panel(page)
        page.locator(".dsh-veneer-tab", has_text="AI 主题").click()
        page.wait_for_selector(".dsh-veneer-ai-generate", timeout=10000)
        mode["cur"] = "opacity_null"
        page.locator(".dsh-veneer-ai-generate").click()
        page.wait_for_selector(".dsh-veneer-ai-preview", timeout=10000)
        side = body_token(page, TOKEN_SIDEBAR).lower()
        base = body_token(page, "--dsw-alias-bg-base").lower()
        results["regress_opacity_null_sidebar_ff"] = side.endswith("ff")
        results["regress_opacity_empty_base_ff"] = base.endswith("ff")

        results["no_pageerror"] = len(page_errors) == 0
        if page_errors:
            print("PAGEERRORS:", page_errors)
        browser.close()


try:
    run_check()
except Exception as e:
    results["EXCEPTION"] = repr(e)
    print("EXCEPTION:", repr(e))

print("\n===== RESULTS =====")
all_ok = True
for k in sorted(results.keys()):
    v = results[k]
    ok = bool(v)
    if not ok:
        all_ok = False
    print(("PASS  " if ok else "FAIL  ") + k + " = " + repr(v))
print("\nALL OK" if all_ok else "\nSOME FAILED")
sys.exit(0 if all_ok else 1)
