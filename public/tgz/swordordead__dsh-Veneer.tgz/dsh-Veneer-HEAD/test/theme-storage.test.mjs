// theme-storage.test.mjs — unit tests for the pure theme-storage coordinator
// (lib/theme-storage.js). The browser half mirrors this logic inline because
// the client bundle can only resolve fixed module ids; this module is the
// canonical, documented behaviour the mirror must match.
//
// Run:  node --test test/theme-storage.test.mjs

import { test } from "node:test";
import assert from "node:assert/strict";
import {
  createThemeStorage,
  parseThemeSnapshot,
  selectInitialTheme,
  toHostTheme,
  toLocalTheme
} from "../lib/theme-storage.js";

const LOCAL_V2 = JSON.stringify({
  v: 2,
  themeOverrides: [["--dsw-specific-sidebar-fill", "#FFFFFF"]],
  fontOverrides: [["global", "Inter"]],
  fontColors: [["main", "#002570"]]
});

const HOST_V3 = {
  schemaVersion: 3,
  themeOverrides: [["--dsw-alias-bg-base", "#000000"]],
  fontOverrides: [],
  fontColors: []
};

const DEFAULT_THEME = { v: 2, themeOverrides: [], fontOverrides: [], fontColors: [] };

// ── parseThemeSnapshot ─────────────────────────────────────────────────────
test("parseThemeSnapshot accepts v:2 JSON strings and schemaVersion:3 objects", () => {
  const fromString = parseThemeSnapshot(LOCAL_V2);
  assert.notEqual(fromString, null);
  assert.equal(fromString.version, 2);
  assert.deepEqual(fromString.themeOverrides, [["--dsw-specific-sidebar-fill", "#FFFFFF"]]);
  assert.deepEqual(fromString.fontOverrides, [["global", "Inter"]]);
  assert.deepEqual(fromString.fontColors, [["main", "#002570"]]);

  const fromObject = parseThemeSnapshot(HOST_V3);
  assert.notEqual(fromObject, null);
  assert.equal(fromObject.version, 3);
  assert.deepEqual(fromObject.themeOverrides, [["--dsw-alias-bg-base", "#000000"]]);
});

test("parseThemeSnapshot fills absent optional lists with empty arrays", () => {
  const r = parseThemeSnapshot({ schemaVersion: 3, themeOverrides: [["--x", "1"]] });
  assert.notEqual(r, null);
  assert.deepEqual(r.fontOverrides, []);
  assert.deepEqual(r.fontColors, []);
});

test("parseThemeSnapshot drops malformed entries but keeps the theme", () => {
  const r = parseThemeSnapshot({
    schemaVersion: 3,
    themeOverrides: [["ok", "1"], ["half"], 42, null],
    fontOverrides: [["k", "v"]],
    fontColors: []
  });
  assert.notEqual(r, null);
  assert.deepEqual(r.themeOverrides, [["ok", "1"]]);
});

test("parseThemeSnapshot rejects structurally invalid input", () => {
  assert.equal(parseThemeSnapshot(null), null);
  assert.equal(parseThemeSnapshot(undefined), null);
  assert.equal(parseThemeSnapshot(""), null);
  assert.equal(parseThemeSnapshot("not json"), null);
  assert.equal(parseThemeSnapshot("{}"), null); // no version marker
  assert.equal(parseThemeSnapshot(JSON.stringify({ v: 1, themeOverrides: [] })), null);
  assert.equal(parseThemeSnapshot([]), null);
  assert.equal(parseThemeSnapshot({ schemaVersion: 3, themeOverrides: "nope" }), null);
  assert.equal(parseThemeSnapshot({ schemaVersion: 3, fontOverrides: {} }), null);
  assert.equal(parseThemeSnapshot({ schemaVersion: 3 }), null);
});

test("toLocalTheme / toHostTheme wrap the same canonical arrays", () => {
  const canonical = {
    themeOverrides: [["--x", "1"]],
    fontOverrides: [],
    fontColors: [["main", "#000000"]]
  };
  assert.deepEqual(toLocalTheme(canonical), { v: 2, hostManaged: true, ...canonical });
  assert.deepEqual(toHostTheme(canonical), { schemaVersion: 3, ...canonical });
});

// ── selectInitialTheme ─────────────────────────────────────────────────────
test("host theme is legal -> host wins, no migration", () => {
  const r = selectInitialTheme({
    host: { available: true, theme: HOST_V3 },
    local: LOCAL_V2,
    defaultTheme: DEFAULT_THEME
  });
  assert.equal(r.source, "host");
  assert.equal(r.migrate, false);
  assert.equal(r.theme.version, 3);
});

test("host empty + legal v2 localStorage -> migrate local to host", () => {
  const r = selectInitialTheme({
    host: { available: true, theme: null },
    local: LOCAL_V2,
    defaultTheme: DEFAULT_THEME
  });
  assert.equal(r.source, "local");
  assert.equal(r.migrate, true);
});

test("host empty + Host-managed local snapshot -> discard instead of migrate", () => {
  const managed = JSON.stringify({ ...JSON.parse(LOCAL_V2), hostManaged: true });
  const r = selectInitialTheme({
    host: { available: true, theme: null },
    local: managed,
    defaultTheme: DEFAULT_THEME
  });
  assert.equal(r.source, "default");
  assert.equal(r.migrate, false);
  assert.equal(r.discardLocal, true);
});

test("host unavailable + legal localStorage -> local, no migration", () => {
  const r = selectInitialTheme({
    host: { available: false, theme: null },
    local: LOCAL_V2,
    defaultTheme: DEFAULT_THEME
  });
  assert.equal(r.source, "local");
  assert.equal(r.migrate, false);
});

test("host data illegal -> fall back to legal localStorage WITHOUT overwriting host", () => {
  const r = selectInitialTheme({
    host: { available: true, theme: { schemaVersion: 3, themeOverrides: "broken" } },
    local: LOCAL_V2,
    defaultTheme: DEFAULT_THEME
  });
  assert.equal(r.source, "local");
  assert.equal(r.migrate, false); // never destroy the illegal original
});

test("neither side legal -> default theme, no user config fabricated", () => {
  const r = selectInitialTheme({
    host: { available: true, theme: null },
    local: null,
    defaultTheme: DEFAULT_THEME
  });
  assert.equal(r.source, "default");
  assert.equal(r.migrate, false);
});

// ── createThemeStorage.load ────────────────────────────────────────────────
function makeEnv(overrides = {}) {
  const calls = [];
  const local = {
    value: overrides.localRaw ?? null,
    read() { calls.push("local.read"); return this.value; },
    write(json) { calls.push("local.write"); this.value = json; },
    remove() { calls.push("local.remove"); this.value = null; }
  };
  const host = {
    available: overrides.hostAvailable ?? true,
    theme: overrides.hostTheme ?? null,
    writeErr: overrides.hostWriteErr ?? null,
    unsetErr: overrides.hostUnsetErr ?? null,
    readErr: overrides.hostReadErr ?? null,
    written: [],
    unsetCalls: [],
    async read() {
      calls.push("host.read");
      if (this.readErr) throw this.readErr;
      return { available: this.available, theme: this.theme };
    },
    async write(theme) {
      calls.push("host.write");
      this.written.push(theme);
      if (this.writeErr) throw this.writeErr;
      if (!overrides.hostWriteRecovered) this.theme = theme;
    },
    async unset(field) {
      calls.push("host.unset");
      this.unsetCalls.push(field);
      if (this.unsetErr) throw this.unsetErr;
      if (!overrides.hostUnsetRecovered) this.theme = null;
    }
  };
  const errors = [];
  const storage = createThemeStorage({
    defaultTheme: DEFAULT_THEME,
    local,
    host,
    onError: (err) => errors.push(err)
  });
  return { storage, local, host, errors, calls };
}

test("load: legal host theme wins and refreshes the local snapshot", async () => {
  const env = makeEnv({ localRaw: LOCAL_V2, hostTheme: HOST_V3 });
  const r = await env.storage.load();
  assert.equal(r.source, "host");
  assert.equal(env.host.written.length, 0, "no host write on host-first path");
  assert.ok(env.local.value !== null, "local snapshot refreshed");
  const localParsed = JSON.parse(env.local.value);
  assert.equal(localParsed.v, 2);
  assert.deepEqual(localParsed.themeOverrides, HOST_V3.themeOverrides);
});

test("load: empty host migrates legal v2 localStorage WITHOUT deleting it", async () => {
  const env = makeEnv({ localRaw: LOCAL_V2, hostTheme: null });
  const r = await env.storage.load();
  assert.equal(r.source, "local");
  assert.equal(r.migrate, true);
  assert.equal(env.host.written.length, 1);
  assert.equal(env.host.written[0].schemaVersion, 3);
  assert.equal(env.local.value, LOCAL_V2, "old local value untouched");
});

test("load: unavailable host falls back to localStorage, no migration write", async () => {
  const env = makeEnv({ localRaw: LOCAL_V2, hostAvailable: false });
  const r = await env.storage.load();
  assert.equal(r.source, "local");
  assert.equal(r.migrate, false);
  assert.equal(env.host.written.length, 0);
});

test("load: host.read throwing counts as unavailable", async () => {
  const env = makeEnv({ localRaw: LOCAL_V2, hostReadErr: new Error("wire down") });
  const r = await env.storage.load();
  assert.equal(r.source, "local");
  assert.equal(r.migrate, false);
  assert.equal(env.host.written.length, 0);
});

test("load: illegal host data falls back to localStorage and is never overwritten", async () => {
  const env = makeEnv({ localRaw: LOCAL_V2, hostTheme: { schemaVersion: 3, themeOverrides: "broken" } });
  const r = await env.storage.load();
  assert.equal(r.source, "local");
  assert.equal(r.migrate, false);
  assert.equal(env.host.written.length, 0, "illegal host data preserved");
  assert.equal(env.local.value, LOCAL_V2, "local data preserved");
});

test("load: neither side legal -> default, no writes at all", async () => {
  const env = makeEnv({ localRaw: null, hostTheme: null });
  const r = await env.storage.load();
  assert.equal(r.source, "default");
  assert.equal(env.host.written.length, 0);
  assert.equal(env.local.value, null);
});

// ── createThemeStorage.save / reset ────────────────────────────────────────
test("save writes localStorage first, then a rejected Host write restores Host authority", async () => {
  const env = makeEnv({ localRaw: null, hostTheme: null, hostWriteErr: new Error("readonly") });
  const theme = { themeOverrides: [["--x", "#fff"]], fontOverrides: [], fontColors: [] };
  await env.storage.save(theme);
  // order: local.write BEFORE host.write
  const lw = env.calls.indexOf("local.write");
  const hw = env.calls.indexOf("host.write");
  assert.ok(lw !== -1 && hw !== -1, "both writes happened");
  assert.ok(lw < hw, "local first, host second");
  assert.equal(env.local.value, null, "empty authoritative Host removes the rejected draft");
  // failure surfaced through onError, and save() itself does not throw
  assert.equal(env.errors.length, 1);
  assert.equal(env.errors[0].message, "readonly");
});

test("save detects a recovered Host write that resolves without applying the value", async () => {
  const env = makeEnv({ hostTheme: HOST_V3, hostWriteRecovered: true });
  const theme = { themeOverrides: [["--x", "#fff"]], fontOverrides: [], fontColors: [] };
  await env.storage.save(theme);
  assert.deepEqual(JSON.parse(env.local.value).themeOverrides, HOST_V3.themeOverrides);
  assert.equal(env.errors.length, 1);
});

test("save keeps host copy when host write succeeds", async () => {
  const env = makeEnv({ localRaw: null, hostTheme: null });
  const theme = { themeOverrides: [["--x", "#fff"]], fontOverrides: [], fontColors: [] };
  await env.storage.save(theme);
  assert.equal(env.host.written.length, 1);
  assert.deepEqual(env.host.written[0], toHostTheme(theme));
  assert.equal(env.errors.length, 0);
});

test("reset clears localStorage and unsets the Host theme field", async () => {
  const env = makeEnv({ localRaw: LOCAL_V2, hostTheme: HOST_V3 });
  await env.storage.reset();
  assert.equal(env.local.value, null);
  assert.deepEqual(env.host.unsetCalls, ["theme"]);
  assert.equal(env.errors.length, 0);
});

test("reset rejection restores the authoritative Host snapshot", async () => {
  const env = makeEnv({ localRaw: LOCAL_V2, hostTheme: HOST_V3, hostUnsetErr: new Error("offline") });
  await env.storage.reset();
  assert.deepEqual(JSON.parse(env.local.value).themeOverrides, HOST_V3.themeOverrides);
  assert.equal(env.errors.length, 1);
  assert.equal(env.errors[0].message, "offline");
});

test("reset detects recovery that resolves while Host still contains the theme", async () => {
  const env = makeEnv({ localRaw: LOCAL_V2, hostTheme: HOST_V3, hostUnsetRecovered: true });
  await env.storage.reset();
  assert.deepEqual(JSON.parse(env.local.value).themeOverrides, HOST_V3.themeOverrides);
  assert.equal(env.errors.length, 1);
});
