# install-script-check.ps1 — isolated regression checks for install.ps1.

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$installer = Join-Path $root "install.ps1"
$tempRoot = Join-Path $env:TEMP ("dsh-veneer-install-test-" + [guid]::NewGuid().ToString("N"))

function Assert-True([bool]$condition, [string]$message) {
    if (-not $condition) { throw $message }
}

function New-FakeHome([string]$name, [bool]$withDependencies = $true) {
    $fakeDshRoot = Join-Path $tempRoot $name
    $web = Join-Path $fakeDshRoot "profiles\web"
    New-Item -ItemType Directory -Path $web -Force | Out-Null
    [System.IO.File]::WriteAllText(
        (Join-Path $web "cordis.patch.yml"),
        "# fake web profile`n",
        (New-Object System.Text.UTF8Encoding($false))
    )
    if ($withDependencies) {
        foreach ($dep in @("dsh-settings", "schemastery")) {
            New-Item -ItemType Directory -Path (Join-Path $fakeDshRoot "profiles\node_modules\@deepseek-ai\$dep") -Force | Out-Null
        }
    }
    return $fakeDshRoot
}

try {
    New-Item -ItemType Directory -Path $tempRoot | Out-Null

    $bytes = [System.IO.File]::ReadAllBytes($installer)
    Assert-True ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) "install.ps1 must retain its UTF-8 BOM for Windows PowerShell 5.1"

    $missingHome = New-FakeHome "missing-dependency" $false
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer -DshHome $missingHome -NoPause *> $null
    Assert-True ($LASTEXITCODE -eq 1) "missing Host Settings dependencies must fail clearly"
    Assert-True (-not (Test-Path -LiteralPath (Join-Path $missingHome "profiles\web\node_modules\dsh-veneer"))) "dependency failure must happen before copying"

    $managedHome = New-FakeHome "managed"
    $managedWeb = Join-Path $managedHome "profiles\web"
    [System.IO.File]::WriteAllText(
        (Join-Path $managedWeb "package.json"),
        '{"dsh":{"profile":{"bundles":["dsh-veneer"]}}}',
        (New-Object System.Text.UTF8Encoding($false))
    )
    $managedTarget = Join-Path $managedWeb "node_modules\dsh-veneer"
    New-Item -ItemType Directory -Path $managedTarget -Force | Out-Null
    $sentinel = Join-Path $managedTarget "sentinel.txt"
    [System.IO.File]::WriteAllText($sentinel, "owned-by-package-manager")
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer -DshHome $managedHome -NoPause *> $null
    Assert-True ($LASTEXITCODE -eq 0) "managed installs should exit successfully with update guidance"
    Assert-True (([System.IO.File]::ReadAllText($sentinel)) -eq "owned-by-package-manager") "managed target was overwritten before safety exit"
    Assert-True (-not (Test-Path -LiteralPath (Join-Path $managedTarget "lib\theme-storage.js"))) "managed target received copied runtime files"

    $plainHome = New-FakeHome "plain"
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer -DshHome $plainHome -NoPause *> $null
    Assert-True ($LASTEXITCODE -eq 0) "plain offline install must succeed"
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer -DshHome $plainHome -NoPause *> $null
    Assert-True ($LASTEXITCODE -eq 0) "repeated offline install must remain idempotent"
    $plainTarget = Join-Path $plainHome "profiles\web\node_modules\dsh-veneer"
    foreach ($rel in @("package.json", "cordis.patch.yml", "lib\client.js", "lib\index.js", "lib\theme-storage.js", "lib\llm-errors.js")) {
        $sourceHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $root $rel)).Hash
        $targetHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $plainTarget $rel)).Hash
        Assert-True ($sourceHash -eq $targetHash) "offline install hash mismatch: $rel"
    }
    $patch = [System.IO.File]::ReadAllText((Join-Path $plainHome "profiles\web\cordis.patch.yml"), [System.Text.Encoding]::UTF8)
    Assert-True (($patch | Select-String -Pattern "(?m)^\s*-\s*id:\s*dsh-veneer\s*$" -AllMatches).Matches.Count -eq 1) "offline install must register exactly one plugin id"
    Assert-True (-not (Test-Path -LiteralPath (Join-Path $plainTarget "lib\lib"))) "repeated install created a nested lib directory"

    Write-Host "PASS install.ps1 isolated checks"
} finally {
    if (Test-Path -LiteralPath $tempRoot) {
        $resolved = [System.IO.Path]::GetFullPath($tempRoot)
        $expectedParent = [System.IO.Path]::GetFullPath($env:TEMP).TrimEnd('\') + '\'
        if (-not $resolved.StartsWith($expectedParent, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "refusing to remove unexpected test directory: $resolved"
        }
        Remove-Item -LiteralPath $resolved -Recurse -Force
    }
}
