# -*- coding: utf-8 -*-
"""dsh-veneer 系统字体扫描功能的端到端验证（Playwright, Chrome）。

覆盖四个场景：
  1. 支持 queryLocalFonts：扫描、过滤符号字体、选中、CSS 生效、刷新后回填。
  2. 不支持（queryLocalFonts = undefined）：按钮置灰。
  3. 授权被拒（NotAllowedError）：按钮恢复、提示友好信息。
  4. 字体文字颜色：颜色选择器、HEX 输入、刷新持久化、单项重置、字体设置重置；并验证全局重置范围。

运行：python test/system-fonts-check.py（需 Playwright + Chrome）
"""
import sys, json
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
from playwright.sync_api import sync_playwright

URL = "http://127.0.0.1:3080"
STUB_OK = "window.queryLocalFonts = () => Promise.resolve([{family:'Microsoft YaHei'},{family:'Arial'},{family:'Wingdings'},{family:'Symbol'},{family:'Wingdings 2'}]);"
STUB_DENY = "window.queryLocalFonts = () => Promise.reject(new DOMException('denied','NotAllowedError'));"
out = {}


def open_font_tab(page):
    page.goto(URL, wait_until="domcontentloaded", timeout=30000)
    page.wait_for_selector(".dsh-veneer-toggle", timeout=15000)
    page.click(".dsh-veneer-toggle")
    page.wait_for_selector(".dsh-veneer-panel", timeout=10000)
    for t in page.query_selector_all(".dsh-veneer-tab"):
        if "字体" in (t.inner_text() or ""):
            t.click()
            break
    page.wait_for_selector(".dsh-veneer-font-select", timeout=10000)


with sync_playwright() as p:
    b = p.chromium.launch(channel="chrome", headless=True)

    # 场景1：支持 queryLocalFonts
    ctx = b.new_context()
    ctx.add_init_script(STUB_OK)
    pg = ctx.new_page()
    errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    open_font_tab(pg)
    scan = pg.query_selector(".dsh-veneer-scan-fonts")
    out["scan_enabled"] = not scan.is_disabled()
    scan.click()
    pg.wait_for_timeout(600)
    sel = pg.query_selector_all(".dsh-veneer-font-select")[0]
    names = [o.inner_text() for o in sel.query_selector_all("option")]
    out["has_optgroup"] = len(sel.query_selector_all("optgroup")) > 0
    out["system_names"] = [o.inner_text() for o in sel.query_selector_all("optgroup option")]
    # 符号字体（含 Wingdings 2）均应被过滤
    out["symbol_filtered"] = all(x not in names for x in ("Wingdings", "Wingdings 2", "Symbol"))
    sel.select_option("system:Microsoft YaHei")
    pg.wait_for_timeout(350)
    css = pg.evaluate('''() => { const t = document.querySelector('style[data-plugin-css="dsh-veneer/theme"]'); return t ? t.textContent : ''; }''')
    out["css_system_font"] = ('font-family: "Microsoft YaHei"' in css)
    pg.reload(wait_until="domcontentloaded")
    open_font_tab(pg)
    sel2 = pg.query_selector_all(".dsh-veneer-font-select")[0]
    out["persisted_value"] = sel2.input_value()
    out["persisted_backfill"] = any(o.get_attribute("value") == "system:Microsoft YaHei" for o in sel2.query_selector_all("option"))
    out["errs_scene1"] = errs

    # 场景2：不支持 → 按钮置灰
    ctx2 = b.new_context()
    ctx2.add_init_script("window.queryLocalFonts = undefined;")
    pg2 = ctx2.new_page()
    open_font_tab(pg2)
    s2 = pg2.query_selector(".dsh-veneer-scan-fonts")
    out["unsupported_disabled"] = s2.is_disabled()
    out["unsupported_title"] = s2.get_attribute("title")

    # 场景3：授权被拒 → 友好提示 + 按钮恢复
    ctx3 = b.new_context()
    ctx3.add_init_script(STUB_DENY)
    pg3 = ctx3.new_page()
    open_font_tab(pg3)
    s3 = pg3.query_selector(".dsh-veneer-scan-fonts")
    s3.click()
    pg3.wait_for_timeout(600)
    out["denial_title"] = s3.get_attribute("title")
    out["denial_reenabled"] = not s3.is_disabled()
    out["denial_text"] = s3.inner_text()

    # 场景4：字体文字颜色编辑、持久化和重置
    ctx4 = b.new_context()
    pg4 = ctx4.new_page()
    color_errs = []
    pg4.on("pageerror", lambda e: color_errs.append(str(e)))
    open_font_tab(pg4)
    color_texts = pg4.query_selector_all(".dsh-veneer-font-color-text")
    color_inputs = pg4.query_selector_all(".dsh-veneer-font-color-input")
    out["font_color_targets"] = len(color_texts) == 5 and len(color_inputs) == 5
    out["font_color_compact_layout"] = pg4.evaluate("""() => {
        return [...document.querySelectorAll('.dsh-veneer-font-card')].every((card) => {
            const head = card.querySelector('.dsh-veneer-font-head');
            const colorRow = card.querySelector('.dsh-veneer-font-color-row');
            const reset = card.querySelector('.dsh-veneer-font-reset');
            if (!head || !colorRow || !reset || !head.contains(colorRow)) return false;
            const colorBox = colorRow.getBoundingClientRect();
            const resetBox = reset.getBoundingClientRect();
            return !card.innerText.includes('文字颜色')
                && Math.abs(colorBox.top - resetBox.top) <= 2.5
                && colorBox.right <= resetBox.left;
        });
    }""")

    # 颜色选择器改变后应立即生成安全的 !important CSS。
    color_inputs[0].evaluate("""el => {
        el.value = '#123456';
        el.dispatchEvent(new Event('input', { bubbles: true }));
    }""")
    pg4.wait_for_timeout(350)
    css4 = pg4.evaluate("""() => {
        const t = document.querySelector('style[data-plugin-css=\"dsh-veneer/theme\"]');
        return t ? t.textContent : '';
    }""")
    out["font_color_picker_css"] = "color: #123456 !important;" in css4

    # HEX 文本框允许省略 #，补全后仍应生效。
    color_texts[1].fill("A1B2C3")
    pg4.wait_for_timeout(350)
    css4 = pg4.evaluate("""() => {
        const t = document.querySelector('style[data-plugin-css=\"dsh-veneer/theme\"]');
        return t ? t.textContent : '';
    }""")
    out["font_color_hex_css"] = "color: #A1B2C3 !important;" in css4

    pg4.reload(wait_until="domcontentloaded")
    open_font_tab(pg4)
    color_texts_after_reload = pg4.query_selector_all(".dsh-veneer-font-color-text")
    out["font_color_persisted"] = (
        color_texts_after_reload[0].input_value() == "#123456"
        and color_texts_after_reload[1].input_value() == "#A1B2C3"
    )
    css4_persisted = pg4.evaluate("""() => {
        const t = document.querySelector('style[data-plugin-css=\"dsh-veneer/theme\"]');
        return t ? t.textContent : '';
    }""")
    out["font_color_css_after_reload"] = (
        "color: #123456 !important;" in css4_persisted
        and "color: #A1B2C3 !important;" in css4_persisted
    )

    # 单项重置只清理当前目标，其他目标颜色必须保留。
    pg4.locator(".dsh-veneer-font-reset").nth(0).click()
    pg4.wait_for_timeout(350)
    css4_single_reset = pg4.evaluate("""() => {
        const t = document.querySelector('style[data-plugin-css=\"dsh-veneer/theme\"]');
        return t ? t.textContent : '';
    }""")
    out["font_color_single_reset"] = (
        "color: #123456 !important;" not in css4_single_reset
        and "color: #A1B2C3 !important;" in css4_single_reset
    )

    # 全部重置应清理所有字体和文字颜色覆盖。
    pg4.get_by_role("button", name="重置字体设置").click()
    pg4.wait_for_timeout(350)
    css4_all_reset = pg4.evaluate("""() => {
        const t = document.querySelector('style[data-plugin-css=\"dsh-veneer/theme\"]');
        return t ? t.textContent : '';
    }""")
    stored4 = pg4.evaluate("""() => {
        const raw = localStorage.getItem('dsh-veneer.theme.v1');
        return raw ? JSON.parse(raw) : null;
    }""")
    out["font_color_reset_all"] = (
        "color: #123456 !important;" not in css4_all_reset
        and "color: #A1B2C3 !important;" not in css4_all_reset
        and stored4 is not None
        and stored4.get("fontColors") == []
    )

    # 两个重置入口必须同时存在且范围不同：字体入口不应清理背景，全局入口应清空全部主题覆盖。
    out["reset_buttons_are_distinct"] = (
        pg4.get_by_role("button", name="重置字体设置").count() == 1
        and pg4.get_by_role("button", name="重置全部设置").count() == 1
    )
    pg4.evaluate("""() => localStorage.setItem('dsh-veneer.theme.v1', JSON.stringify({
        v: 2,
        themeOverrides: [['--dsw-specific-sidebar-fill', '#123456']],
        fontOverrides: [['global', 'Arial']],
        fontColors: [['global', '#ABCDEF']]
    }))""")
    pg4.reload(wait_until="domcontentloaded")
    open_font_tab(pg4)
    pg4.get_by_role("button", name="重置字体设置").click()
    pg4.wait_for_timeout(350)
    scoped_reset = pg4.evaluate("""() => {
        const raw = localStorage.getItem('dsh-veneer.theme.v1');
        return raw ? JSON.parse(raw) : null;
    }""")
    theme_after_reset = (scoped_reset or {}).get("themeOverrides") or []
    out["font_reset_preserves_background"] = (
        scoped_reset is not None
        and len(theme_after_reset) == 1
        and theme_after_reset[0][0] == "--dsw-specific-sidebar-fill"
        # v2 存储规范化：6 位 #123456 读入后保存为 8 位 #123456ff，值等价
        and str(theme_after_reset[0][1]).lower().startswith("#123456")
        and scoped_reset.get("fontOverrides") == []
        and scoped_reset.get("fontColors") == []
    )
    pg4.get_by_role("button", name="重置全部设置").click()
    pg4.wait_for_timeout(350)
    out["global_reset_clears_background"] = pg4.evaluate("""() => {
        const raw = localStorage.getItem('dsh-veneer.theme.v1');
        return raw === null;
    }""")

    # 不可信的旧快照不能把非法颜色拼进注入 CSS。
    pg4.evaluate("""payload => localStorage.setItem('dsh-veneer.theme.v1', JSON.stringify(payload))""", {
        "v": 2,
        "themeOverrides": [],
        "fontOverrides": [],
        "fontColors": [
            ["global", "#112233"],
            ["sidebar", "445566"],
            ["main", "red; background: url(javascript:bad)"],
            ["input", "#abc"],
            ["unknown", "#778899"],
        ],
    })
    pg4.reload(wait_until="domcontentloaded")
    open_font_tab(pg4)
    css4_storage = pg4.evaluate("""() => {
        const t = document.querySelector('style[data-plugin-css=\"dsh-veneer/theme\"]');
        return t ? t.textContent : '';
    }""")
    out["font_color_storage_validation"] = (
        "color: #112233 !important;" in css4_storage
        and "color: #445566 !important;" in css4_storage
        and "red; background" not in css4_storage
        and "color: #abc !important;" not in css4_storage
        and "#778899" not in css4_storage
    )
    # 回归修复：Veneer 面板自身的文字颜色必须能生效。
    # 修复前 selector 是 ".dsh-veneer-panel"（无 " *"），子元素的显式
    # color: var(--dsw-alias-label-primary) 会压掉继承值 → 颜色改不动。
    pg4.evaluate("""() => {
        const cards = [...document.querySelectorAll('.dsh-veneer-font-card')];
        const veneer = cards[cards.length - 1];
        const input = veneer.querySelector('.dsh-veneer-font-color-input');
        input.value = '#0F2B46';
        input.dispatchEvent(new Event('input', { bubbles: true }));
    }""")
    pg4.wait_for_timeout(350)
    css4_veneer = pg4.evaluate("""() => {
        const t = document.querySelector('style[data-plugin-css="dsh-veneer/theme"]');
        return t ? t.textContent : '';
    }""")
    out["font_color_veneer_css"] = (
        ".dsh-veneer-panel * { color: #0F2B46 !important; }" in css4_veneer
    )
    # 面板内带显式 color 的子元素（如 .dsh-veneer-group-title）应被真正覆盖。
    out["font_color_veneer_effective"] = pg4.evaluate("""() => {
        const el = document.querySelector('.dsh-veneer-group-title');
        return !!el && getComputedStyle(el).color === 'rgb(15, 43, 70)';
    }""")
    out["errs_scene4"] = color_errs

    b.close()

print(json.dumps(out, ensure_ascii=False, indent=1))
