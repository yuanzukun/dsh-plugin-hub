# -*- coding: utf-8 -*-
"""Veneer 皮肤导出/导入 + 选择器加固 端到端回归验证（Playwright, Chrome）。

覆盖：面板结构、导出 dialog（JSON 字段/名称/下载）、导入恢复、非法 JSON 错误提示、
字体 data-slot 选择器、退出面板侧栏按钮同步、无 pageerror。

运行：python test/veneer-skin-check.py（需 Playwright + Chrome，DSH 跑在 127.0.0.1:3080）
"""
import json
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
from playwright.sync_api import sync_playwright

URL = "http://127.0.0.1:3080"
STORAGE_KEY = "dsh-veneer.theme.v1"
TOKEN_SIDEBAR = "--dsw-specific-sidebar-fill"
TOKEN_MAIN = "--dsw-alias-bg-base"
TOKEN_BUBBLE = "--dsw-specific-bubble"
TOKEN_INPUT = "--dsw-specific-input-major"

results = {}


def wait_for_save(page):
    # applySurface / saveTheme 使用 250ms 防抖持久化
    page.wait_for_timeout(420)


def read_snapshot(page):
    return page.evaluate(
        """key => { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : null; }""",
        STORAGE_KEY,
    )


def body_token(page, token):
    return page.evaluate(
        """token => document.body.style.getPropertyValue(token).trim()""", token
    )


def set_surface_color(page, token, hexv):
    page.evaluate(
        """({ token, hexv }) => {
            const row = document.querySelector('.dsh-veneer-surface[data-token="' + token + '"]');
            const txt = row.querySelector('.dsh-veneer-color-text');
            txt.value = hexv;
            txt.dispatchEvent(new Event('input', { bubbles: true }));
            txt.dispatchEvent(new Event('blur', { bubbles: true }));
        }""",
        {"token": token, "hexv": hexv},
    )
    wait_for_save(page)


def open_panel(page):
    page.wait_for_selector(".dsh-veneer-toggle", timeout=20000)
    if page.locator(".dsh-veneer-panel").count() == 0:
        page.locator(".dsh-veneer-toggle").click()
    page.wait_for_selector(".dsh-veneer-panel", timeout=10000)
    page.wait_for_selector(
        '.dsh-veneer-surface[data-token="%s"]' % TOKEN_SIDEBAR, timeout=10000
    )


def run_check():
    global results
    with sync_playwright() as p:
        browser = p.chromium.launch(channel="chrome", headless=True)
        context = browser.new_context()
        page = context.new_page()
        page_errors = []
        page.on("pageerror", lambda e: page_errors.append(str(e)))
        page.goto(URL, wait_until="domcontentloaded", timeout=30000)
        page.evaluate("localStorage.removeItem(%r)" % STORAGE_KEY)
        page.reload(wait_until="domcontentloaded")
        open_panel(page)

        # ── 结构 ──
        results["panel_visible"] = page.locator(".dsh-veneer-panel").is_visible()
        results["header_actions"] = page.locator(".dsh-veneer-header-actions").count() == 1
        # 吸管取色功能已整体移除：头部不应再出现吸管按钮，相关浮层类也不应存在
        results["no_eye_button"] = page.locator(".dsh-veneer-eye").count() == 0
        results["no_picker_overlay"] = page.locator(".dsh-veneer-picker").count() == 0
        results["tabs_4"] = page.locator(".dsh-veneer-tab").count() == 4
        results["groups_3"] = page.locator(".dsh-veneer-group").count() == 3
        results["surfaces_12"] = page.locator(".dsh-veneer-surface").count() == 12
        results["footer_row1_3"] = page.locator(".dsh-veneer-actions .dsh-veneer-btn").count() == 3
        results["footer_row2_2"] = page.locator(".dsh-veneer-file-actions .dsh-veneer-btn").count() == 2

        # ── 导出 ──
        page.locator(".dsh-veneer-export").click()
        dialog = page.locator(".dsh-veneer-dialog")
        results["export_dialog"] = dialog.count() == 1
        results["export_title"] = dialog.locator(".dsh-veneer-dialog-title").inner_text() == "导出主题"
        ta = dialog.locator(".dsh-veneer-dialog-textarea")
        results["export_textarea_readonly"] = ta.get_attribute("readonly") is not None
        envelope = json.loads(ta.input_value())
        results["export_fields"] = (
            envelope.get("app") == "dsh-veneer"
            and envelope.get("format") == "skin"
            and envelope.get("v") == 3
            and isinstance(envelope.get("themeOverrides"), list)
            and isinstance(envelope.get("fontOverrides"), list)
            and isinstance(envelope.get("fontColors"), list)
        )
        # 名称联动
        dialog.locator(".dsh-veneer-dialog-name").fill("我的主题")
        envelope2 = json.loads(dialog.locator(".dsh-veneer-dialog-textarea").input_value())
        results["export_name_link"] = envelope2.get("name") == "我的主题"
        # 下载 .json
        with page.expect_download(timeout=5000) as dl_info:
            dialog.locator(".dsh-veneer-btn", has_text="下载 .json").click()
        dl = dl_info.value
        results["export_download"] = dl.suggested_filename.endswith(".json")
        # 复制 JSON（headless 剪贴板可能受限，确保不抛错即可）
        try:
            dialog.locator(".dsh-veneer-btn", has_text="复制 JSON").click()
            page.wait_for_timeout(200)
            results["export_copy_no_error"] = len(page_errors) == 0
        except Exception:
            results["export_copy_no_error"] = False
        # 关闭 dialog
        dialog.locator(".dsh-veneer-dialog-close").click()
        results["export_dialog_closed"] = page.locator(".dsh-veneer-dialog").count() == 0

        # ── 导入：导出 → 重置 → 导入恢复 ──
        set_surface_color(page, TOKEN_SIDEBAR, "#445566")
        page.locator(".dsh-veneer-export").click()
        exported = page.locator(".dsh-veneer-dialog-textarea").input_value()
        page.locator(".dsh-veneer-dialog-close").click()
        page.locator(".dsh-veneer-reset").click()
        page.wait_for_timeout(300)
        results["import_after_reset"] = body_token(page, TOKEN_SIDEBAR) == ""
        page.locator(".dsh-veneer-import").click()
        import_ta = page.locator(".dsh-veneer-dialog-textarea")
        import_ta.fill(exported)
        page.locator(".dsh-veneer-btn", has_text="应用导入").click()
        page.wait_for_timeout(250)
        snap = read_snapshot(page)
        results["import_restored_color"] = body_token(page, TOKEN_SIDEBAR).startswith("#445566")
        results["import_restored_storage"] = snap is not None and any(
            k == TOKEN_SIDEBAR and str(v).lower().startswith("#445566")
            for k, v in snap.get("themeOverrides", [])
        )
        results["import_dialog_closed"] = page.locator(".dsh-veneer-dialog").count() == 0

        # ── 导入：非法 JSON / 未知格式 ──
        page.locator(".dsh-veneer-import").click()
        import_ta = page.locator(".dsh-veneer-dialog-textarea")
        import_ta.fill("这不是 JSON")
        page.locator(".dsh-veneer-btn", has_text="应用导入").click()
        err = page.locator(".dsh-veneer-dialog-error")
        results["import_bad_json_error"] = "dsh-veneer-visible" in (err.get_attribute("class") or "")
        import_ta.fill('{"v": 9}')
        page.locator(".dsh-veneer-btn", has_text="应用导入").click()
        results["import_unknown_format_error"] = "无法识别主题格式" in err.inner_text()
        page.locator(".dsh-veneer-dialog-close").click()

        # ── 字体：data-slot 选择器加固后仍生效 ──
        page.locator(".dsh-veneer-tab", has_text="字体").click()
        page.wait_for_selector(".dsh-veneer-font-card", timeout=10000)
        # 为 全局/侧边栏/主内容/输入区 四个目标都设置字体，
        # 确保 `body, body *` 与三条 [data-slot] 规则都会生成到 theme CSS。
        cards = page.locator(".dsh-veneer-font-card")
        for w in ("全局页面", "侧边栏", "主内容", "输入区"):
            for i in range(cards.count()):
                if w in cards.nth(i).locator(".dsh-veneer-font-label").inner_text():
                    cards.nth(i).locator(".dsh-veneer-font-select").select_option("yahei")
                    break
        page.wait_for_timeout(300)
        css_text = page.evaluate(
            """() => {
                const t = document.querySelector('style[data-plugin-css="dsh-veneer/theme"]');
                return t ? t.textContent : "";
            }"""
        )
        results["font_global_rule"] = "body, body *" in css_text and "Microsoft YaHei" in css_text
        results["font_sidebar_selector"] = '[data-slot="sidebar"], [data-slot="sidebar"] *' in css_text
        results["font_main_selector"] = '[data-slot="conversation"], [data-slot="conversation"] *' in css_text
        results["font_input_selector"] = '[data-slot="conversation.composer"], [data-slot="conversation.composer"] *' in css_text
        # 页面真实存在 data-slot 元素时，验证 computed font-family 已生效
        has_sidebar_slot = page.evaluate("() => document.querySelector('[data-slot=\"sidebar\"]') !== null")
        if has_sidebar_slot:
            computed_family = page.evaluate(
                """() => {
                    const el = document.querySelector('[data-slot="sidebar"]');
                    return getComputedStyle(el).fontFamily;
                }"""
            )
            results["font_sidebar_computed"] = "Microsoft YaHei" in computed_family
        else:
            results["font_sidebar_computed"] = "no-data-slot-element"

        # ── 退出面板：侧栏按钮状态同步 ──
        page.locator(".dsh-veneer-close").click()
        page.wait_for_timeout(200)
        toggle_cls = page.locator(".dsh-veneer-toggle").get_attribute("class") or ""
        results["close_sync_toggle"] = (
            page.locator(".dsh-veneer-panel").count() == 0
            and "dsh-veneer-active" not in toggle_cls
        )

        results["no_pageerror"] = len(page_errors) == 0
        if page_errors:
            print("PAGEERRORS:", page_errors)
        browser.close()


try:
    run_check()
except Exception as e:
    results["EXCEPTION"] = repr(e)
    print("EXCEPTION: %r" % e)

print("\n===== RESULTS =====")
all_ok = True
for k in sorted(results.keys()):
    v = results[k]
    ok = bool(v) if not isinstance(v, str) else True
    if isinstance(v, str) and v.startswith("no-data-slot"):
        ok = True
    if not ok:
        all_ok = False
    print(("PASS  " if ok else "FAIL  ") + k + " = " + repr(v))
print("\nALL OK" if all_ok else "\nSOME FAILED")
sys.exit(0 if all_ok else 1)
