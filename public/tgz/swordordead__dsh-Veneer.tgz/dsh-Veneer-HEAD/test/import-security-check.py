# -*- coding: utf-8 -*-
"""导入安全回归：恶意皮肤导入必须被 sanitizer 拦截（CSS 注入 / 非法 token / 恶意背景图 URL / 字体注入），
同时合法的标准色（rgb / named）必须被接受。运行：python test/import-security-check.py（需 DSH 跑在 127.0.0.1:3080）"""
import json
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
from playwright.sync_api import sync_playwright

URL = "http://127.0.0.1:3080"
results = {}
page_errors = []


def open_panel(page):
    # 侧栏按钮进入 Veneer 面板
    page.wait_for_selector(".dsh-veneer-toggle", timeout=20000)
    if page.locator(".dsh-veneer-panel").count() == 0:
        page.locator(".dsh-veneer-toggle").click()
    page.wait_for_selector(".dsh-veneer-panel", timeout=10000)


def import_skin(page, payload):
    page.locator(".dsh-veneer-import").click()
    ta = page.locator(".dsh-veneer-dialog-textarea")
    ta.fill(json.dumps(payload, ensure_ascii=False))
    page.locator(".dsh-veneer-btn", has_text="应用导入").click()
    page.wait_for_timeout(300)


with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    ctx = browser.new_context()
    page = ctx.new_page()
    page.on("pageerror", lambda e: page_errors.append(str(e)))
    page.goto(URL)
    page.wait_for_timeout(1500)

    try:
        open_panel(page)

        # 1. CSS 注入：值里带 `}` 和后续 CSS 规则，必须被丢弃/净化
        evil = 'red;} body{display:none}'
        payload = {
            "app": "dsh-veneer", "format": "skin", "v": 3, "name": "evil",
            "themeOverrides": [["--dsw-specific-sidebar-fill", evil]],
            "fontOverrides": [],
            "fontColors": [],
        }
        import_skin(page, payload)
        body_display = page.evaluate("() => document.body.style.display")
        applied = page.evaluate(
            "() => document.body.style.getPropertyValue('--dsw-specific-sidebar-fill').trim()"
        )
        results["css_inject_body_display_none"] = body_display != "none"
        results["css_inject_dropped_or_safe"] = (
            applied == ""
            or ("body" not in applied and "{" not in applied and "}" not in applied and "display" not in applied)
        )
        print("  body.style.display =", repr(body_display))
        print("  applied token value =", repr(applied))

        # 2. 非法 token：未登记的 token 必须被过滤
        payload2 = {
            "app": "dsh-veneer", "format": "skin", "v": 3, "name": "bad-token",
            "themeOverrides": [["--dsw-not-a-real-token", "#ff0000"]],
            "fontOverrides": [], "fontColors": [],
        }
        import_skin(page, payload2)
        snap = page.evaluate(
            """key => { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : null; }""",
            "dsh-veneer.theme.v1",
        )
        toks = [k for k, v in (snap or {}).get("themeOverrides", [])] if snap else []
        results["unknown_token_filtered"] = "--dsw-not-a-real-token" not in toks

        # 3. 恶意背景图 URL：带引号/分号/反斜杠的 URL 必须被丢弃
        payload3 = {
            "app": "dsh-veneer", "format": "skin", "v": 3, "name": "evil-url",
            "themeOverrides": [
                ["--dsw-specific-sidebar-fill", "#112233"],
                ["--dsw-specific-sidebar-image", 'javascript:alert(1)" onerror="x'],
                ["--dsw-specific-sidebar-maskalpha", "0.5"],
            ],
            "fontOverrides": [], "fontColors": [],
        }
        import_skin(page, payload3)
        img_val = page.evaluate(
            "() => document.body.style.getPropertyValue('--dsw-specific-sidebar-image').trim()"
        )
        results["evil_url_dropped"] = img_val == ""
        print("  image token after import =", repr(img_val))

        # 4. 字体注入：字体族里带 CSS 也要被丢弃
        payload4 = {
            "app": "dsh-veneer", "format": "skin", "v": 3, "name": "evil-font",
            "themeOverrides": [],
            "fontOverrides": [["global", 'Arial;} body{display:none}']],
            "fontColors": [],
        }
        import_skin(page, payload4)
        body_display4 = page.evaluate("() => document.body.style.display")
        results["font_inject_body_display_none"] = body_display4 != "none"
        font_val = page.evaluate(
            """() => {
                const t = document.querySelector('style[data-plugin-css="dsh-veneer/theme"]');
                return t ? t.textContent : "";
            }"""
        )
        results["font_inject_no_body_rule"] = "body{display:none}" not in font_val and "display:none" not in font_val

        results["no_pageerror"] = len(page_errors) == 0

        # 5. 合法标准色（rgb / named / hsl 之外）必须被接受，不能静默丢弃
        payload5 = {
            "app": "dsh-veneer", "format": "skin", "v": 3, "name": "legal-rgb",
            "themeOverrides": [
                ["--dsw-specific-sidebar-fill", "rgb(255, 0, 0)"],
                ["--dsw-specific-bubble", "navy"],
            ],
            "fontOverrides": [],
            "fontColors": [["global", "rgb(0, 128, 0)"]],
        }
        import_skin(page, payload5)
        snap5 = page.evaluate(
            """key => { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : null; }""",
            "dsh-veneer.theme.v1",
        )
        toks5 = dict((snap5 or {}).get("themeOverrides", []))
        fontcols5 = dict((snap5 or {}).get("fontColors", []))
        results["legal_rgb_accepted"] = toks5.get("--dsw-specific-sidebar-fill", "").startswith("#ff0000")
        results["legal_named_accepted"] = toks5.get("--dsw-specific-bubble", "").startswith("#000080")
        results["legal_fontcolor_accepted"] = fontcols5.get("global", "") == "#008000"
        print("  sidebar after rgb import =", repr(toks5.get("--dsw-specific-sidebar-fill")))
        print("  bubble after named import =", repr(toks5.get("--dsw-specific-bubble")))
        print("  fontColor global =", repr(fontcols5.get("global")))
    except Exception as e:
        import traceback
        traceback.print_exc()
        results["EXCEPTION"] = repr(e)
    finally:
        browser.close()

print("\n===== SECURITY RESULTS =====")
for k, v in results.items():
    print(f"  {'PASS' if v is True else 'FAIL'}  {k} = {v}")
failed = [k for k, v in results.items() if v is not True]
print("ALL OK" if not failed else f"FAILED: {failed}")
