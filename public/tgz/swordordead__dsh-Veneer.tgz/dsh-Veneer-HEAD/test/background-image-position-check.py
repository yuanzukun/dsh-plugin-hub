# -*- coding: utf-8 -*-
"""背景图位置调整的端到端回归验证（Playwright, Chrome）。

覆盖：旧配置兼容、横纵滑块、拖拽定位、刷新持久化、轻点收缩/展开预览、居中、上传默认居中，
以及变淡蒙层和移除背景图回归。

运行：python test/background-image-position-check.py（需 Playwright + Chrome）
"""
import json
import math
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
from playwright.sync_api import sync_playwright

URL = "http://127.0.0.1:3080"
STORAGE_KEY = "dsh-veneer.theme.v1"
TOKEN = "--dsw-specific-sidebar-fill"
LEGACY_URL = "https://example.test/legacy-background.png"
UPLOADED_URL = "https://example.test/uploaded-background.png"
results = {}


def wait_for_save(page):
    # applySurface uses a 250 ms trailing debounce for localStorage persistence.
    page.wait_for_timeout(380)


def set_range(locator, value):
    locator.evaluate(
        """(el, value) => {
            el.value = String(value);
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
        }""",
        value,
    )


def read_snapshot(page):
    return page.evaluate(
        """key => {
            const raw = localStorage.getItem(key);
            return raw ? JSON.parse(raw) : null;
        }""",
        STORAGE_KEY,
    )


def token_value(snapshot):
    if not snapshot:
        return ""
    for key, value in snapshot.get("themeOverrides", []):
        if key == TOKEN:
            return value
    return ""


def open_background_editor(page):
    page.wait_for_selector(".dsh-veneer-toggle", timeout=15000)
    if not page.locator(".dsh-veneer-panel").is_visible():
        page.locator(".dsh-veneer-toggle").click()
    page.wait_for_selector(f'.dsh-veneer-surface[data-token="{TOKEN}"]', timeout=10000)


def surface_locator(page):
    return page.locator(f'.dsh-veneer-surface[data-token="{TOKEN}"]')


with sync_playwright() as p:
    browser = p.chromium.launch(channel="chrome", headless=True)
    context = browser.new_context()
    context.route(
        "**/api/dsh-veneer/upload**",
        lambda route: route.fulfill(
            status=200,
            content_type="application/json",
            body=json.dumps({"url": UPLOADED_URL}),
        ),
    )
    page = context.new_page()
    page_errors = []
    page.on("pageerror", lambda error: page_errors.append(str(error)))

    # 旧版 `center/cover` 保存值不含位置坐标；加载时应自动回退到 50% / 50%。
    page.goto(URL, wait_until="domcontentloaded", timeout=30000)
    page.evaluate(
        """({ key, token, value }) => localStorage.setItem(key, JSON.stringify({
            v: 2,
            themeOverrides: [[token, value]],
            fontOverrides: [],
            fontColors: []
        }))""",
        {"key": STORAGE_KEY, "token": TOKEN, "value": f"url({LEGACY_URL}) center/cover no-repeat #123456"},
    )
    page.reload(wait_until="domcontentloaded")
    open_background_editor(page)
    surface = surface_locator(page)
    preview = surface.locator(".dsh-veneer-preview")
    x_range = surface.locator(".dsh-veneer-image-position-x")
    y_range = surface.locator(".dsh-veneer-image-position-y")
    results["legacy_defaults_to_center"] = (
        x_range.input_value() == "50"
        and y_range.input_value() == "50"
        and preview.evaluate("el => el.style.backgroundPosition") == "50% 50%"
    )

    # 两个滑块应同时更新实际 CSS 和本地持久化。
    set_range(x_range, 35)
    set_range(y_range, 70)
    value_after_sliders = token_value(read_snapshot(page))
    # applySurface coalesces inline body writes through requestAnimationFrame;
    # headless Chrome throttles rAF, so poll until the flush lands instead of
    # sleeping a fixed amount (flaky before).
    page.wait_for_function(
        """token => {
            const v = document.body.style.getPropertyValue(token);
            return v.includes("35% 70%/cover no-repeat");
        }""",
        arg=TOKEN,
        timeout=3000,
    )
    actual_surface_after_sliders = page.evaluate(
        """token => document.body.style.getPropertyValue(token)""",
        TOKEN,
    )
    results["sliders_update_css_and_storage"] = (
        x_range.input_value() == "35"
        and y_range.input_value() == "70"
        and "35% 70%/cover no-repeat" in value_after_sliders
        and "35% 70%/cover no-repeat" in actual_surface_after_sliders
    )

    # 在预览内从中间拖到约 20% / 80%，滑块和保存值应同步变化。
    box = preview.bounding_box()
    if box is None or box["width"] <= 0 or box["height"] <= 0:
        raise RuntimeError("背景图预览没有可用尺寸，无法测试拖拽定位")
    start_x = box["x"] + box["width"] * 0.5
    start_y = box["y"] + box["height"] * 0.5
    drag_x = box["x"] + box["width"] * 0.20
    drag_y = box["y"] + box["height"] * 0.80
    page.mouse.move(start_x, start_y)
    page.mouse.down()
    page.mouse.move(drag_x, drag_y, steps=5)
    page.mouse.up()
    value_after_drag = token_value(read_snapshot(page))
    page.wait_for_timeout(80)
    x_after_drag = int(x_range.input_value())
    y_after_drag = int(y_range.input_value())
    results["drag_updates_both_axes"] = (
        math.isclose(x_after_drag, 20, abs_tol=2)
        and math.isclose(y_after_drag, 80, abs_tol=2)
        and f"{x_after_drag}% {y_after_drag}%/cover no-repeat" in value_after_drag
    )

    # 刷新后保留拖拽结果，预览和滑块均应回填。
    page.reload(wait_until="domcontentloaded")
    open_background_editor(page)
    surface = surface_locator(page)
    preview = surface.locator(".dsh-veneer-preview")
    x_range = surface.locator(".dsh-veneer-image-position-x")
    y_range = surface.locator(".dsh-veneer-image-position-y")
    results["position_persists_after_refresh"] = (
        int(x_range.input_value()) == x_after_drag
        and int(y_range.input_value()) == y_after_drag
        and preview.evaluate("el => el.style.backgroundPosition") == f"{x_after_drag}% {y_after_drag}%"
    )

    # 轻点预览（不拖动）应收缩/展开预览高度，且不得改变图片位置或保存值。
    # 注意：预览高度有 0.2s 过渡动画，断言前需等待过渡完成。
    preview.click()
    page.wait_for_function(
        """token => {
            const el = document.querySelector(`.dsh-veneer-surface[data-token="${token}"] .dsh-veneer-preview`);
            return el && el.classList.contains('dsh-veneer-preview-small')
                && Math.round(el.getBoundingClientRect().height) === 32;
        }""",
        arg=TOKEN,
        timeout=3000,
    )
    results["click_collapses_preview"] = (
        preview.evaluate("el => el.classList.contains('dsh-veneer-preview-small')")
        and preview.evaluate("el => Math.round(el.getBoundingClientRect().height)") == 32
    )
    value_after_collapse = token_value(read_snapshot(page))
    results["collapse_keeps_position"] = (
        int(x_range.input_value()) == x_after_drag
        and int(y_range.input_value()) == y_after_drag
        and f"{x_after_drag}% {y_after_drag}%/cover no-repeat" in value_after_collapse
    )
    preview.click()
    page.wait_for_function(
        """token => {
            const el = document.querySelector(`.dsh-veneer-surface[data-token="${token}"] .dsh-veneer-preview`);
            return el && !el.classList.contains('dsh-veneer-preview-small')
                && Math.round(el.getBoundingClientRect().height) === 112;
        }""",
        arg=TOKEN,
        timeout=3000,
    )
    results["click_expands_preview"] = (
        not preview.evaluate("el => el.classList.contains('dsh-veneer-preview-small')")
        and preview.evaluate("el => Math.round(el.getBoundingClientRect().height)") == 112
    )

    # 收缩后：位置控件 / 移除 / 变淡行应隐藏，但上传行必须仍可见可点。
    preview.click()
    page.wait_for_function(
        """token => {
            const el = document.querySelector(`.dsh-veneer-surface[data-token="${token}"] .dsh-veneer-preview`);
            return el && el.classList.contains('dsh-veneer-preview-small');
        }""",
        arg=TOKEN,
        timeout=3000,
    )
    collapsed_rows = surface.locator(".dsh-veneer-row").all()
    results["collapse_hides_controls_keeps_upload"] = (
        not surface.locator(".dsh-veneer-image-position-controls").is_visible()
        and not surface.locator(".dsh-veneer-actions").is_visible()
        and len(collapsed_rows) >= 3
        and all(not r.is_visible() for r in collapsed_rows)
        and surface.locator(".dsh-veneer-upload-btn").is_visible()
    )

    # 收缩状态必须在重渲染后保留（切到"字体"标签再切回），否则面板重建后预览会弹回 112px。
    page.locator(".dsh-veneer-tab", has_text="字体").click()
    page.wait_for_selector(f'.dsh-veneer-surface[data-token="{TOKEN}"]', state="detached", timeout=5000)
    page.locator(".dsh-veneer-tab", has_text="背景").click()
    page.wait_for_function(
        """token => {
            const el = document.querySelector(`.dsh-veneer-surface[data-token="${token}"] .dsh-veneer-preview`);
            return el && el.classList.contains('dsh-veneer-preview-small')
                && Math.round(el.getBoundingClientRect().height) === 32;
        }""",
        arg=TOKEN,
        timeout=3000,
    )
    results["collapse_survives_rerender"] = (
        surface.locator(".dsh-veneer-preview").evaluate(
            "el => el.classList.contains('dsh-veneer-preview-small')"
        )
    )
    preview.click()
    page.wait_for_function(
        """token => {
            const el = document.querySelector(`.dsh-veneer-surface[data-token="${token}"] .dsh-veneer-preview`);
            return el && !el.classList.contains('dsh-veneer-preview-small');
        }""",
        arg=TOKEN,
        timeout=3000,
    )

    # 亚阈值移动（<10px）应判定为点击（切换收缩），不得当作拖动去改位置。
    x_before = int(surface.locator(".dsh-veneer-image-position-x").input_value())
    y_before = int(surface.locator(".dsh-veneer-image-position-y").input_value())
    micro = surface.locator(".dsh-veneer-preview").bounding_box()
    page.mouse.move(micro["x"] + micro["width"] * 0.5, micro["y"] + micro["height"] * 0.5)
    page.mouse.down()
    page.mouse.move(micro["x"] + micro["width"] * 0.5 + 4, micro["y"] + micro["height"] * 0.5 + 3, steps=2)
    page.mouse.up()
    page.wait_for_function(
        """token => {
            const el = document.querySelector(`.dsh-veneer-surface[data-token="${token}"] .dsh-veneer-preview`);
            return el && el.classList.contains('dsh-veneer-preview-small');
        }""",
        arg=TOKEN,
        timeout=3000,
    )
    results["subthreshold_move_counts_as_click"] = (
        int(surface.locator(".dsh-veneer-image-position-x").input_value()) == x_before
        and int(surface.locator(".dsh-veneer-image-position-y").input_value()) == y_before
    )
    preview.click()
    page.wait_for_function(
        """token => {
            const el = document.querySelector(`.dsh-veneer-surface[data-token="${token}"] .dsh-veneer-preview`);
            return el && !el.classList.contains('dsh-veneer-preview-small');
        }""",
        arg=TOKEN,
        timeout=3000,
    )

    # 居中图片必须恢复精确的 50% / 50%。
    surface.get_by_role("button", name="居中图片").click()
    centered_value = token_value(read_snapshot(page))
    results["center_button_restores_center"] = (
        x_range.input_value() == "50"
        and y_range.input_value() == "50"
        and "50% 50%/cover no-repeat" in centered_value
    )

    # 回归：变淡蒙层继续正常叠加；移除背景图应清理 URL、蒙层与位置控件。
    fade_range = surface.locator(".dsh-veneer-range").nth(2)
    set_range(fade_range, 25)
    wait_for_save(page)
    faded_value = token_value(read_snapshot(page))
    results["fade_mask_preserved"] = "linear-gradient(rgba(255,255,255,0.25), rgba(255,255,255,0.25))" in faded_value
    surface.get_by_role("button", name="移除背景图").click()
    wait_for_save(page)
    removed_value = token_value(read_snapshot(page))
    results["remove_image_clears_image_state"] = (
        LEGACY_URL not in removed_value
        and "url(" not in removed_value
        and surface.locator(".dsh-veneer-preview").count() == 0
        and surface.locator(".dsh-veneer-image-position-x").count() == 0
        and surface.locator(".dsh-veneer-image-position-y").count() == 0
    )

    # 上传或替换新图不应继承旧图焦点，必须从中间开始。
    file_input = surface.locator('input[type="file"]')
    file_input.set_input_files(
        {
            "name": "background.png",
            "mimeType": "image/png",
            "buffer": b"\x89PNG\r\n\x1a\nplaceholder",
        }
    )
    page.wait_for_selector(f'.dsh-veneer-surface[data-token="{TOKEN}"] .dsh-veneer-preview', timeout=10000)
    wait_for_save(page)
    surface = surface_locator(page)
    uploaded_x = surface.locator(".dsh-veneer-image-position-x")
    uploaded_y = surface.locator(".dsh-veneer-image-position-y")
    uploaded_value = token_value(read_snapshot(page))
    results["upload_defaults_to_center"] = (
        uploaded_x.input_value() == "50"
        and uploaded_y.input_value() == "50"
        and UPLOADED_URL in uploaded_value
        and "50% 50%/cover no-repeat" in uploaded_value
    )
    results["no_page_errors"] = page_errors == []

    browser.close()

print(json.dumps(results, ensure_ascii=False, indent=2))
failed = [name for name, passed in results.items() if not passed]
if failed:
    raise SystemExit("验证失败：" + ", ".join(failed))