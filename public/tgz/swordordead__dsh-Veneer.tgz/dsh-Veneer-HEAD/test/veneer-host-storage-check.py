# -*- coding: utf-8 -*-
"""Veneer Host Settings 主存储 + localStorage 降级 端到端回归（Playwright, Chrome）。

覆盖（针对 v0.8.0 存储架构）：
  1. v:2 localStorage 旧数据 -> 刷新 -> 迁移写入 Host（settings.yaml），本地保留；
  2. 改色保存 -> localStorage 与 Host 同步更新（规范化 8 位小写）；
  3. 重置 -> 本地清空 + Host unset theme（yaml 中删除该键）；
  4. Host 写失败（settings.yaml 只读）-> 本地快照不残留未保存编辑，最终与 Host 一致；
  5. 另一客户端 RPC 改 Host -> 广播应用 + 刷新后持久化生效（Host 是主存储）。
  6. 多页面并发：B 页 reset 后，A 页不得把本地旧主题写回 Host。

安全：全程备份 ~/.dsh/settings.yaml，测试结束（含异常）先通过 RPC 恢复运行中
Host，再恢复原文件字节。
运行：python test/veneer-host-storage-check.py（需 Playwright + Chrome + PyYAML，
      DSH 跑在 127.0.0.1:3080）
"""
import json
import os
import shutil
import sys
import time
import uuid
import urllib.request

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import yaml
from playwright.sync_api import sync_playwright

URL = "http://127.0.0.1:3080"
STORAGE_KEY = "dsh-veneer.theme.v1"
SETTINGS = os.path.join(
    os.path.expanduser("~"), ".dsh", "settings.yaml"
)
TOKEN_BUBBLE = "--dsw-specific-bubble"

results = {}
settings_orig = None
settings_backup = None
original_theme_present = False
original_theme = None
host_mutation_enabled = False


def validate_rpc_response(body, expected_rpc_id=None):
    try:
        envelope = json.loads(body)
    except Exception as exc:
        raise RuntimeError("settings RPC returned invalid JSON: %r" % body[:300]) from exc
    if not isinstance(envelope, dict) or envelope.get("type") != "server-response":
        raise RuntimeError("settings RPC returned invalid envelope: %r" % envelope)
    if expected_rpc_id is not None and envelope.get("rpcId") != expected_rpc_id:
        raise RuntimeError("settings RPC id mismatch: %r" % envelope)
    result = envelope.get("result")
    if not isinstance(result, dict) or result.get("ok") is not True:
        error = result.get("error") if isinstance(result, dict) else envelope
        raise RuntimeError("settings RPC failed: %r" % error)
    return envelope


def read_settings():
    with open(SETTINGS, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def write_settings(data):
    with open(SETTINGS, "w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)


def host_theme_section():
    data = read_settings()
    ns = data.get("dsh-veneer") if isinstance(data, dict) else None
    if not isinstance(ns, dict):
        return None
    return ns.get("theme")


def host_theme_unset():
    """Host 的 dsh-veneer section 中不存在 theme 键（unset 后的落盘形态）。"""
    data = read_settings()
    ns = data.get("dsh-veneer") if isinstance(data, dict) else None
    return isinstance(ns, dict) and "theme" not in ns


def host_bubble_contains(prefix):
    t = host_theme_section()
    return isinstance(t, dict) and any(
        isinstance(e, list) and len(e) >= 2 and e[0] == TOKEN_BUBBLE
        and str(e[1]).lower().startswith(prefix)
        for e in t.get("themeOverrides", [])
    )


def wait_for(predicate, timeout=4.0, interval=0.25):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            v = predicate()
            if v:
                return v
        except Exception:
            pass
        time.sleep(interval)
    return predicate() if True else None


def read_snapshot(page):
    return page.evaluate(
        """key => { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : null; }""",
        STORAGE_KEY,
    )


def theme_css(page):
    return page.evaluate(
        """() => {
            const t = document.querySelector('style[data-plugin-css="dsh-veneer/theme"]');
            return t ? t.textContent : "";
        }"""
    )


def open_panel(page):
    page.wait_for_selector(".dsh-veneer-toggle", timeout=20000)
    if page.locator(".dsh-veneer-panel").count() == 0:
        page.locator(".dsh-veneer-toggle").click()
    page.wait_for_selector(".dsh-veneer-panel", timeout=10000)
    page.wait_for_selector(
        '.dsh-veneer-surface[data-token="%s"]' % TOKEN_BUBBLE, timeout=10000
    )


def set_surface_color(page, hexv):
    page.evaluate(
        """({ token, hexv }) => {
            const row = document.querySelector('.dsh-veneer-surface[data-token="' + token + '"]');
            const txt = row.querySelector('.dsh-veneer-color-text');
            txt.value = hexv;
            txt.dispatchEvent(new Event('input', { bubbles: true }));
            txt.dispatchEvent(new Event('blur', { bubbles: true }));
        }""",
        {"token": TOKEN_BUBBLE, "hexv": hexv},
    )
    # applySurface / saveTheme 使用 250ms 防抖持久化
    page.wait_for_timeout(550)


def make_v2_theme(bubble):
    return {
        "v": 2,
        "themeOverrides": [[TOKEN_BUBBLE, bubble]],
        "fontOverrides": [],
        "fontColors": [],
    }


def mutate_host_theme(page, theme_present, theme=None):
    """通过官方 settings RPC 恢复/修改运行中的权威 Host 文档。"""
    op = (
        {"op": "set", "path": ["theme"], "value": theme}
        if theme_present
        else {"op": "unset", "path": ["theme"]}
    )
    result = page.evaluate(
        """({ ns, op }) => {
            const rpcId = 'hostcheck-restore-' + Date.now();
            const message = {
                type: 'client-request',
                rpcId,
                method: 'settings.mutate',
                payload: { ns: ns, ops: [op] }
            };
            return fetch('/api/settings.mutate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(message)
            }).then(async r => ({ ok: r.ok, status: r.status, rpcId, body: await r.text() }));
        }""",
        {"ns": "dsh-veneer", "op": op},
    )
    if not result.get("ok"):
        raise RuntimeError("settings.mutate restore failed: %r" % result)
    validate_rpc_response(result.get("body", ""), result.get("rpcId"))


def mutate_host_theme_http(theme_present, theme=None):
    """finally 专用：不依赖仍存活的 Playwright page，直接恢复 Host 权威状态。"""
    op = (
        {"op": "set", "path": ["theme"], "value": theme}
        if theme_present
        else {"op": "unset", "path": ["theme"]}
    )
    message = {
        "type": "client-request",
        "rpcId": "hostcheck-finally-" + uuid.uuid4().hex[:12],
        "method": "settings.mutate",
        "payload": {"ns": "dsh-veneer", "ops": [op]},
    }
    request = urllib.request.Request(
        URL + "/api/settings.mutate",
        data=json.dumps(message).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=10) as response:
        body = response.read().decode("utf-8", "replace")
        if response.status < 200 or response.status >= 300:
            raise RuntimeError("settings.mutate restore HTTP %s" % response.status)
    validate_rpc_response(body, message["rpcId"])


def original_theme_restored():
    data = read_settings()
    ns = data.get("dsh-veneer") if isinstance(data, dict) else None
    if original_theme_present:
        return isinstance(ns, dict) and ns.get("theme") == original_theme
    return not isinstance(ns, dict) or "theme" not in ns


def run_check():
    global settings_orig, settings_backup, original_theme_present, original_theme, host_mutation_enabled
    with sync_playwright() as p:
        browser = p.chromium.launch(channel="chrome", headless=True)
        context = browser.new_context()
        page = context.new_page()
        page_errors = []
        page.on("pageerror", lambda e: page_errors.append(str(e)))

        # ── 0. 备份 settings.yaml；通过页面 reset 清空 Host ──
        # 注意：DSH 内存中的 settings 文档是权威，直接改写 yaml 不会改变 Host
        # 快照，所以必须由页面发起 unset（点重置按钮），再等 yaml 落盘确认。
        with open(SETTINGS, "r", encoding="utf-8") as f:
            settings_orig = f.read()
        original_doc = yaml.safe_load(settings_orig)
        original_ns = original_doc.get("dsh-veneer") if isinstance(original_doc, dict) else None
        original_theme_present = isinstance(original_ns, dict) and "theme" in original_ns
        original_theme = original_ns.get("theme") if original_theme_present else None
        settings_backup = SETTINGS + ".bak-hostcheck-" + uuid.uuid4().hex[:8]
        with open(settings_backup, "w", encoding="utf-8") as f:
            f.write(settings_orig)

        page.goto(URL, wait_until="domcontentloaded", timeout=30000)
        # Preflight before any destructive UI action: an HTTP 2xx with a JSON-RPC
        # error is not success, and an unregistered namespace means DSH needs restart.
        mutate_host_theme(page, original_theme_present, original_theme)
        host_mutation_enabled = True
        page.evaluate("localStorage.removeItem(%r)" % STORAGE_KEY)
        # Deterministic fixture setup: do not race the client's initial Host
        # subscription by clicking reset before its first ready snapshot.
        mutate_host_theme(page, False)
        results["cleanup_host_unset"] = wait_for(host_theme_unset, timeout=6.0) is True
        page.reload(wait_until="domcontentloaded")
        page.wait_for_selector(".dsh-veneer-toggle", timeout=20000)

        # ── 1. v:2 本地数据迁移到 Host ──
        legacy = make_v2_theme("#112233")
        page.evaluate(
            """({ key, value }) => localStorage.setItem(key, JSON.stringify(value))""",
            {"key": STORAGE_KEY, "value": legacy},
        )
        page.reload(wait_until="domcontentloaded")
        page.wait_for_selector(".dsh-veneer-toggle", timeout=20000)

        migrated = wait_for(
            lambda: host_theme_section() if host_bubble_contains("#112233") else None,
            timeout=5.0,
        )
        results["migration_host_written"] = (
            isinstance(migrated, dict)
            and migrated.get("schemaVersion") == 3
            and any(
                isinstance(e, list) and len(e) >= 2 and e[0] == TOKEN_BUBBLE
                for e in migrated.get("themeOverrides", [])
            )
        )
        results["migration_host_bubble"] = any(
            isinstance(e, list) and len(e) >= 2 and e[0] == TOKEN_BUBBLE
            and str(e[1]).lower().startswith("#112233")
            for e in (migrated or {}).get("themeOverrides", [])
        )
        snap = read_snapshot(page)
        results["migration_keeps_local"] = snap is not None and snap.get("v") == 2
        results["migration_marks_host_managed"] = (
            snap is not None and snap.get("hostManaged") is True
        )
        results["migration_css_applied"] = "#112233" in theme_css(page).lower()

        # ── 2. 改色保存：本地 + Host 同步 ──
        open_panel(page)
        set_surface_color(page, "#445566")
        snap = read_snapshot(page)
        results["save_local_updated"] = any(
            k == TOKEN_BUBBLE and str(v).lower().startswith("#445566")
            for k, v in snap.get("themeOverrides", [])
        )

        def host_has_445566():
            t = host_theme_section()
            return isinstance(t, dict) and any(
                isinstance(e, list) and len(e) >= 2 and e[0] == TOKEN_BUBBLE
                and str(e[1]).lower().startswith("#445566")
                for e in t.get("themeOverrides", [])
            )

        results["save_host_updated"] = wait_for(host_has_445566, timeout=5.0) is True

        # ── 3. 重置：本地清空 + Host unset theme（yaml 中无该键）──
        page.locator(".dsh-veneer-reset").click()
        page.wait_for_timeout(600)
        results["reset_local_cleared"] = read_snapshot(page) is None
        results["reset_host_unset"] = wait_for(host_theme_unset, timeout=6.0) is True

        # ── 4. Host 写失败（settings.yaml 只读）──
        # 官方 settings-scope 写失败会做 recovery read：Host 快照保持旧值，订阅
        # 广播把本地快照拉回 Host 旧值（local 是 Host 快照，不伪造保存成功）。
        set_surface_color(page, "#556677")  # 先恢复正常写入
        page.wait_for_timeout(500)
        os.chmod(SETTINGS, 0o444)  # Windows 只读属性
        try:
            set_surface_color(page, "#778899")
            results["degrade_local_eventually_host"] = wait_for(
                lambda: any(
                    k == TOKEN_BUBBLE and str(v).lower().startswith("#556677")
                    for k, v in (read_snapshot(page) or {}).get("themeOverrides", [])
                ),
                timeout=6.0,
            )
            results["degrade_host_untouched"] = not host_bubble_contains("#778899")

            # unset is a distinct mutation path: reset must be recovered to the old
            # Host theme, including UI/local snapshot, when persistence is read-only.
            open_panel(page)
            page.locator(".dsh-veneer-reset").click()
            results["degrade_reset_host_restored"] = wait_for(
                lambda: host_bubble_contains("#556677"), timeout=6.0
            ) is True
            results["degrade_reset_local_restored"] = wait_for(
                lambda: any(
                    k == TOKEN_BUBBLE and str(v).lower().startswith("#556677")
                    for k, v in (read_snapshot(page) or {}).get("themeOverrides", [])
                ),
                timeout=6.0,
            ) is True
        finally:
            os.chmod(SETTINGS, 0o644)

        # ── 5. 另一客户端 RPC 改 Host -> 广播应用 + 刷新后持久化生效 ──
        # 注意：直接改写 settings.yaml 不会改变 DSH 内存中的权威文档（yaml 只是
        # 持久化副本），所以外部修改必须走 settings.mutate RPC。
        external = {
            "schemaVersion": 3,
            "themeOverrides": [[TOKEN_BUBBLE, "#990000"]],
            "fontOverrides": [],
            "fontColors": [],
        }
        page.evaluate(
            """({ ns, theme }) => {
                const message = {
                    type: 'client-request',
                    rpcId: 'hostcheck-ext-' + Date.now(),
                    method: 'settings.mutate',
                    payload: { ns: ns, ops: [{ op: 'set', path: ['theme'], value: theme }] }
                };
                return fetch('/api/settings.mutate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(message)
                }).then(r => r.text());
            }""",
            {"ns": "dsh-veneer", "theme": external},
        )
        results["external_rpc_accepted"] = (
            wait_for(lambda: host_bubble_contains("#990000"), timeout=6.0) is True
        )
        page.reload(wait_until="domcontentloaded")
        page.wait_for_selector(".dsh-veneer-toggle", timeout=20000)
        results["external_host_applied"] = (
            wait_for(lambda: "#990000" in theme_css(page).lower(), timeout=6.0) is True
        )
        results["external_host_synced_local"] = any(
            k == TOKEN_BUBBLE and str(v).lower().startswith("#990000")
            for k, v in read_snapshot(page).get("themeOverrides", [])
        )

        # ── 6. 多客户端并发：独立 context 的 B reset 后 A 不得写回 ──
        open_panel(page)
        set_surface_color(page, "#223344")
        context_b = browser.new_context()
        page_b = context_b.new_page()
        page_b.goto(URL, wait_until="domcontentloaded", timeout=30000)
        page_b.wait_for_selector(".dsh-veneer-toggle", timeout=20000)
        open_panel(page_b)
        page_b.locator(".dsh-veneer-reset").click()
        page_b.wait_for_timeout(1500)  # 给 A 页反写留出观察窗口
        results["multi_page_reset_survives"] = (
            wait_for(host_theme_unset, timeout=6.0) is True
        )
        results["multi_page_a_ui_cleared"] = (
            "#223344" not in theme_css(page).lower()
        )
        results["multi_page_a_local_gone"] = read_snapshot(page) is None
        page.reload(wait_until="domcontentloaded")
        page.wait_for_selector(".dsh-veneer-toggle", timeout=20000)
        results["multi_page_reset_survives_reload"] = (
            wait_for(host_theme_unset, timeout=3.0) is True
            and read_snapshot(page) is None
        )
        context_b.close()

        results["no_pageerror"] = len(page_errors) == 0
        if page_errors:
            print("PAGEERRORS:", page_errors)
        # 测试会通过 RPC 改变 DSH 内存中的权威文档；退出前必须同样通过 RPC 恢复。
        os.chmod(SETTINGS, 0o644)
        mutate_host_theme(page, original_theme_present, original_theme)
        results["cleanup_live_host_restored"] = (
            wait_for(original_theme_restored, timeout=6.0) is True
        )
        browser.close()


try:
    run_check()
except Exception as e:
    results["EXCEPTION"] = repr(e)
    print("EXCEPTION: %r" % e)
finally:
    # 即使 run_check 中途失败，也先恢复 live Host，再恢复原始字节以保留 YAML 格式。
    file_restored = False
    if settings_orig is not None:
        try:
            os.chmod(SETTINGS, 0o644)
            if host_mutation_enabled:
                mutate_host_theme_http(original_theme_present, original_theme)
                if wait_for(original_theme_restored, timeout=6.0) is not True:
                    raise RuntimeError("live Host restore did not reach settings.yaml")
        except Exception as e:
            results["cleanup_live_host_restored"] = False
            print("LIVE-RESTORE-FAILED: %r" % e)
        try:
            with open(SETTINGS, "w", encoding="utf-8") as f:
                f.write(settings_orig)
            file_restored = open(SETTINGS, "r", encoding="utf-8").read() == settings_orig
            if not file_restored:
                raise RuntimeError("settings.yaml byte restore verification failed")
        except Exception as e:
            results["cleanup_file_restored"] = False
            print("FILE-RESTORE-FAILED: %r" % e)
    if settings_backup and os.path.exists(settings_backup):
        if file_restored:
            try:
                os.remove(settings_backup)
            except Exception:
                pass
        else:
            print("RECOVERY BACKUP KEPT: %s" % settings_backup)

print("\n===== RESULTS =====")
all_ok = True
for k in sorted(results.keys()):
    v = results[k]
    ok = bool(v) and k != "EXCEPTION"
    if not ok:
        all_ok = False
    print(("PASS  " if ok else "FAIL  ") + k + " = " + repr(v))
print("\nALL OK" if all_ok else "\nSOME FAILED")
sys.exit(0 if all_ok else 1)
