// ai-colors.test.mjs — unit tests for AI-theme colour coercion in lib/client.js.
//
// Run:  node --test test/ai-colors.test.mjs
//
// client.js is a CJS module wrapped in window.__ModuleLoader__.load({ id, factory }),
// so we drive it through a minimal mock of the dsh module loader plus DOM/canvas
// stubs that mirror the browser contract coerceColor() relies on:
//   - assigning an INVALID value to canvas fillStyle is silently ignored
//     (fillStyle keeps its previous value) -> coerceColor returns null;
//   - assigning a VALID value normalises it -> #rrggbbaa is returned;
//   - fillRect does REAL source-over compositing into a 1×1 pixel buffer, so a
//     canvas reused without clearRect would bleed the previous colour through.

import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const here = dirname(fileURLToPath(import.meta.url));
const source = readFileSync(join(here, "..", "lib", "client.js"), "utf8");

// ── mock CSS colour parser used by the fake canvas ─────────────────────────
const NAMED = {
  red: [255, 0, 0, 255], green: [0, 128, 0, 255], blue: [0, 0, 255, 255],
  black: [0, 0, 0, 255], white: [255, 255, 255, 255], transparent: [0, 0, 0, 0]
};
function hexByte(n) { return n.toString(16).padStart(2, "0"); }
function parseCssColor(input) {
  const t = String(input).trim().toLowerCase();
  if (t === "") return null;
  // Mirrors real browsers: only 3/4/6/8-digit hex are legal CSS hex colours
  // (5/7-digit like #12345 are INVALID and must be rejected -> null).
  if (/^#(?:[0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/.test(t)) {
    let h = t.slice(1);
    if (h.length === 4) h = h.split("").map((c) => c + c).join(""); // #RGBA → #RRGGBBAA
    const parts = h.length === 3 ? h.split("").map((c) => c + c) : [h.slice(0, 2), h.slice(2, 4), h.slice(4, 6), h.slice(6, 8)];
    const rgb = parts.slice(0, 3).map((x) => parseInt(x, 16));
    const alpha = parts.length === 4 ? parseInt(parts[3], 16) : 255;
    return [rgb[0], rgb[1], rgb[2], alpha];
  }
  let m = /^rgba?\(\s*([\d.]+%?)\s*[,\s]+\s*([\d.]+%?)\s*[,\s]+\s*([\d.]+%?)\s*(?:[,\/]\s*([\d.]+%?)\s*)?\)$/.exec(t);
  if (m) {
    const part = (v) => (v.endsWith("%") ? Math.round(parseFloat(v) * 255 / 100) : Math.round(parseFloat(v)));
    const alpha = m[4] === undefined ? 255
      : (m[4].trim().endsWith("%") ? Math.round(parseFloat(m[4]) * 255 / 100) : Math.round(parseFloat(m[4]) * 255));
    return [part(m[1]), part(m[2]), part(m[3]), alpha];
  }
  m = /^hsla?\(\s*([\d.]+)(?:deg)?\s+([\d.]+)%\s+([\d.]+)%\s*(?:[,\/]\s*([\d.]+%?)\s*)?\)$/.exec(t);
  if (m) {
    const h = ((parseFloat(m[1]) % 360) + 360) % 360 / 360;
    const s = parseFloat(m[2]) / 100;
    const l = parseFloat(m[3]) / 100;
    const a = m[4] === undefined ? 1 : Math.min(1, Math.max(0, parseFloat(m[4]) / 100));
    const f = (n) => {
      const k = (n + h * 12) % 12;
      const aa = s * Math.min(l, 1 - l);
      return l - aa * Math.max(-1, Math.min(k - 3, Math.min(9 - k, 1)));
    };
    return [Math.round(f(0) * 255), Math.round(f(8) * 255), Math.round(f(4) * 255), Math.round(a * 255)];
  }
  if (Object.prototype.hasOwnProperty.call(NAMED, t)) return NAMED[t];
  return null;
}
function makeCanvasCtx() {
  // `fill` = current fillStyle colour; `buf` = the 1×1 pixel buffer that
  // fillRect paints into with REAL source-over compositing (mirrors browsers,
  // so a canvas reused without clearRect would bleed the previous colour
  // through — exactly the bug the production fix guards against).
  let fill = [0x12, 0x34, 0x56, 255];
  let buf = [0, 0, 0, 0];
  return {
    set fillStyle(v) {
      const p = parseCssColor(v);
      if (p !== null) fill = p; // invalid -> silently ignored, like the browser
    },
    get fillStyle() { return "#" + fill.map(hexByte).join(""); },
    clearRect() { buf = [0, 0, 0, 0]; },
    fillRect() {
      const srcA = fill[3] / 255;
      const dstA = buf[3] / 255;
      const outA = srcA + dstA * (1 - srcA);
      if (outA <= 0) { buf = [0, 0, 0, 0]; return; }
      const inv = dstA * (1 - srcA);
      for (let i = 0; i < 3; i++) buf[i] = (fill[i] * srcA + buf[i] * inv) / outA;
      buf[3] = outA * 255;
    },
    getImageData() { return { data: Uint8ClampedArray.from(buf) }; }
  };
}

// ── module loader + DOM mocks ───────────────────────────────────────────────
let mod = null;
function loadModule(canvasCtxFactory = makeCanvasCtx) {
  const ctx = canvasCtxFactory(); // e.g. () => null to simulate missing canvas support
  const bodyStyle = {};
  const documentMock = {
    querySelector: () => null, // no pre-existing injected <style>
    head: { appendChild() {} },
    body: {
      style: new Proxy(bodyStyle, {
        get: (t, k) => t[k] ?? "",
        set: (t, k, v) => { t[k] = v; return true; }
      })
    },
    createElement: (tag) => {
      if (tag === "canvas") return { getContext: () => ctx };
      return { dataset: {}, style: {}, textContent: "", appendChild() {} };
    }
  };
  const windowMock = {
    getComputedStyle: () => ({}),
    addEventListener() {}, removeEventListener() {},
    dispatchEvent() {},
    __ModuleLoader__: {
      load({ factory }) {
        const fakeRequire = (name) => {
          if (name === "react") return { useState: () => [null, () => {}], useEffect: () => {}, createElement: () => ({}) };
          throw new Error("unexpected require: " + name);
        };
        mod = factory(fakeRequire);
        return mod;
      }
    }
  };
  global.window = windowMock;
  global.document = documentMock;
  global.localStorage = { getItem: () => null, setItem() {}, removeItem() {} };
  // Evaluate the real module source through the mock loader.
  new Function("window", source)(windowMock);
  return mod;
}

loadModule();
const { recognizedColor, coerceColor, parseSurface, parseAiTheme } = mod.__test;
assert.ok(recognizedColor && coerceColor && parseAiTheme, "test hooks exported");

// ── recognised / coerced colours ───────────────────────────────────────────
test("bare hex without # (the 0a0a1f bug) is accepted", () => {
  assert.equal(coerceColor("0a0a1f"), "#0a0a1fff");
  assert.equal(recognizedColor("0a0a1f"), "#0a0a1fff");
});
test("# hex with 3/6/8 digits expands correctly", () => {
  assert.equal(coerceColor("#0a0a1f"), "#0a0a1fff");
  assert.equal(coerceColor("#abc"), "#aabbccff");
  assert.equal(coerceColor("#aabbccdd"), "#aabbccdd");
});
test("hsl is coerced through the canvas parser when supported", () => {
  const v = coerceColor("hsl(210 50% 40%)");
  assert.ok(v !== null, "hsl should coerce");
  assert.match(v, /^#[0-9a-f]{8}$/);
});
test("uppercase hex is accepted and normalised (bare and # prefixed)", () => {
  assert.equal(coerceColor("0A0A1F"), "#0a0a1fff");
  assert.equal(coerceColor("#ABC"), "#aabbccff");
  assert.equal(coerceColor("#AABBCCDD"), "#aabbccdd");
  assert.equal(recognizedColor("#ABC"), "#aabbccff");
});
test("4-digit #RGBA goes through the canvas path only (strict path rejects it)", () => {
  // Strict skin-import path keeps only 3/6/8-digit hex; the AI path accepts
  // the full CSS hex grammar via the canvas parser.
  assert.equal(recognizedColor("#f008"), null);
  assert.equal(coerceColor("#f008"), "#ff000088"); // #RGBA → #RRGGBBAA
});
test("5/7-digit hex is invalid everywhere (like real browsers)", () => {
  // Real browsers reject #12345 / #1234567 (only 3/4/6/8 digits are legal),
  // so the strict path must not turn them into black, and the canvas path
  // must not let them through either.
  assert.equal(recognizedColor("#12345"), null);
  assert.equal(recognizedColor("#1234567"), null);
  assert.equal(coerceColor("#12345"), null);
  assert.equal(coerceColor("#1234567"), null);
});
test("parseSurface keeps only legal 3/6/8-digit hex and drops 4/5/7", () => {
  // Skin-import path: a malformed hex must be DROPPED (empty color), never
  // silently coerced to black.
  assert.equal(parseSurface("#abc").color, "#abc");
  assert.equal(parseSurface("#aabbcc").color, "#aabbcc");
  assert.equal(parseSurface("#aabbccdd").color, "#aabbccdd");
  assert.equal(parseSurface("#f008").color, "");
  assert.equal(parseSurface("#12345").color, "");
  assert.equal(parseSurface("#1234567").color, "");
  // rgb()/named colours still recognised through the strict path.
  assert.equal(parseSurface("rgb(1, 2, 3)").color, "#010203ff");
  assert.equal(parseSurface("red").color, "#ff0000ff");
});
test("percentage alpha in rgba() is parsed correctly (50% → 0.5)", () => {
  assert.equal(recognizedColor("rgba(0, 0, 0, 50%)"), "#00000080");
  assert.equal(recognizedColor("rgba(255, 0, 0, 100%)"), "#ff0000ff");
});
test("reused canvas is cleared between calls — no pixel pollution", () => {
  // Regression guard: coerceColor reuses one canvas; without clearRect the
  // second semi-transparent fill would be source-over blended over the first.
  assert.equal(coerceColor("#f008"), "#ff000088");
  assert.equal(coerceColor("#00f8"), "#0000ff88");
  assert.equal(coerceColor("hsl(210 50% 40%)"), "#336699ff");
});
test("unknown / injectable strings are rejected, not passed through", () => {
  assert.equal(coerceColor("url(javascript:alert(1))"), null);
  assert.equal(coerceColor("red; background:url(x)"), null);
  assert.equal(coerceColor("  "), null);
  assert.equal(coerceColor(""), null);
  assert.equal(coerceColor(null), null);
  assert.equal(coerceColor(42), null);
});
test("recognizedColor stays a strict security boundary", () => {
  assert.equal(recognizedColor("url(javascript:alert(1))"), null);
  assert.equal(recognizedColor("red; background:url(x)"), null);
  assert.equal(recognizedColor("hsl(210 50% 40%)"), null); // strict path: only named/rgb/hex
});

// ── parseAiTheme end-to-end ─────────────────────────────────────────────────
test("parseAiTheme accepts bare-hex surfaces and font colours", () => {
  const r = parseAiTheme(JSON.stringify({
    name: "test",
    surfaces: [
      { token: "--dsw-specific-sidebar-fill", color: "0a0a1f" },
      { token: "--dsw-alias-bg-base", color: "#abc", opacity: "" }
    ],
    fonts: [
      { key: "global", family: "PingFang SC", color: "f8fafc" }
    ]
  }));
  assert.equal(r.name, "test");
  assert.deepEqual(r.themeEntries, [
    ["--dsw-specific-sidebar-fill", "#0a0a1fff"],
    ["--dsw-alias-bg-base", "#aabbccff"]
  ]);
  assert.deepEqual(r.colorEntries, [["global", "#F8FAFC"]]);
});
test("parseAiTheme still rejects injectable colours (safety)", () => {
  assert.throws(
    () => parseAiTheme(JSON.stringify({
      surfaces: [{ token: "--dsw-specific-sidebar-fill", color: "red; background:url(x)" }]
    })),
    /AI 输出了非法颜色/
  );
});
test("parseAiTheme normalises 8-digit hex surfaces; alpha comes from opacity field", () => {
  // Surfaces carry a separate opacity field (default 100), so the alpha of an
  // 8-digit hex colour is overridden by it — only the RGB part is kept.
  const r = parseAiTheme(JSON.stringify({
    surfaces: [{ token: "--dsw-alias-bg-base", color: "#11223344" }]
  }));
  assert.deepEqual(r.themeEntries, [["--dsw-alias-bg-base", "#112233ff"]]);
  const half = parseAiTheme(JSON.stringify({
    surfaces: [{ token: "--dsw-alias-bg-base", color: "#11223344", opacity: 50 }]
  }));
  assert.deepEqual(half.themeEntries, [["--dsw-alias-bg-base", "#11223380"]]);
});

test("canvas context unavailable → coerce falls back to null (no crash)", () => {
  // Load a fresh module instance whose canvas.getContext() returns null.
  // loadModule() swaps the global window/document/localStorage mocks, so
  // restore them afterwards (try/finally) to keep tests order-independent.
  const saved = {
    window: global.window,
    document: global.document,
    localStorage: global.localStorage
  };
  try {
    const mod2 = loadModule(() => null);
    const { coerceColor: coerceNoCtx } = mod2.__test;
    assert.equal(coerceNoCtx("hsl(210 50% 40%)"), null);
    assert.equal(coerceNoCtx("#f008"), null);
    assert.equal(coerceNoCtx("#12345"), null);
    assert.equal(coerceNoCtx("0a0a1f"), "#0a0a1fff"); // strict path still works without canvas
  } finally {
    global.window = saved.window;
    global.document = saved.document;
    global.localStorage = saved.localStorage;
  }
});
