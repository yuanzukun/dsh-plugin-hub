// client-storage-integration.test.mjs — integration tests for the browser-half
// storage bridge in lib/client.js (Host Settings primary + localStorage
// fallback). The decisions under test mirror lib/theme-storage.js; this file
// drives the real client source through a mock module loader, fake DOM,
// fake localStorage and a fake settingsScope.
//
// Run:  node --test test/client-storage-integration.test.mjs

import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const here = dirname(fileURLToPath(import.meta.url));
const source = readFileSync(join(here, "..", "lib", "client.js"), "utf8");

const STORAGE_KEY = "dsh-veneer.theme.v1";
const LOCAL_A = JSON.stringify({
  v: 2,
  themeOverrides: [["--dsw-specific-sidebar-fill", "#AAAAAA"]],
  fontOverrides: [],
  fontColors: []
});
const HOST_B = {
  schemaVersion: 3,
  themeOverrides: [["--dsw-specific-sidebar-fill", "#BBBBBB"]],
  fontOverrides: [["global", "Inter"]],
  fontColors: [["main", "#002570"]]
};

function makeScope({ snapshot, setImpl, unsetImpl }) {
  const calls = { bind: null, set: [], unset: [], subscribed: [], subscribeDisposed: 0, scopeDisposed: 0 };
  const scope = {
    bind(opts) {
      calls.bind = opts;
      return this;
    },
    getSnapshot() {
      return typeof snapshot === "function" ? snapshot() : snapshot;
    },
    set(field, value) {
      calls.set.push([field, value]);
      return setImpl ? setImpl(field, value) : Promise.resolve();
    },
    unset(field) {
      calls.unset.push(field);
      return unsetImpl ? unsetImpl(field) : Promise.resolve();
    },
    subscribe(cb) {
      calls.subscribed.push(cb);
      return () => { calls.subscribeDisposed += 1; };
    },
    dispose() {
      calls.scopeDisposed += 1;
    }
  };
  return { scope, calls };
}

function makeDom() {
  const bodyChildren = [];
  const headChildren = [];
  const removedProps = [];
  let themeStyle = null;
  // Permissive fake element: explicit fields behave normally, every unknown
  // property is a no-op callable so inspector code paths (setAttribute,
  // addEventListener, classList.*, focus, click, ...) never throw.
  const makeElement = (tag) =>
    new Proxy(
      {
        id: "",
        tagName: String(tag).toUpperCase(),
        dataset: {},
        style: {},
        textContent: "",
        parentNode: null,
        children: [],
        appendChild(child) {
          child.parentNode = this;
          this.children.push(child);
        },
        removeChild(child) {
          const i = this.children.indexOf(child);
          if (i >= 0) {
            this.children.splice(i, 1);
            child.parentNode = null;
          }
        },
        get firstChild() {
          return this.children[0] || null;
        },
        get lastChild() {
          return this.children[this.children.length - 1] || null;
        }
      },
      {
        get(target, key) {
          if (key in target) return target[key];
          if (key === "classList") {
            return { add() {}, remove() {}, toggle() {}, contains() { return false; } };
          }
          return () => {};
        },
        set(target, key, value) {
          target[key] = value;
          return true;
        }
      }
    );
  const dom = {
    bodyChildren,
    headChildren,
    removedProps,
    get themeStyle() {
      return themeStyle;
    },
    querySelector() {
      return themeStyle;
    },
    getElementById(id) {
      return bodyChildren.find((c) => c.id === id) || null;
    },
    createElement(tag) {
      const el = makeElement(tag);
      if (tag === "style" && themeStyle === null) themeStyle = el;
      return el;
    },
    head: {
      appendChild(el) {
        headChildren.push(el);
      }
    },
    body: {
      style: new Proxy({}, {
        get(t, k) {
          if (k === "removeProperty") return (prop) => removedProps.push(prop);
          return t[k] ?? "";
        },
        set(t, k, v) {
          t[k] = v;
          return true;
        }
      }),
      appendChild(el) {
        el.parentNode = dom.body;
        bodyChildren.push(el);
      },
      removeChild(el) {
        const i = bodyChildren.indexOf(el);
        if (i >= 0) {
          bodyChildren.splice(i, 1);
          el.parentNode = null;
        }
      }
    }
  };
  return dom;
}

function loadModule({ localValue = null, scope = null, dynamicInject = false } = {}) {
  const localStore = new Map();
  if (localValue !== null) localStore.set(STORAGE_KEY, localValue);
  const localCalls = { set: [], remove: [] };
  const localStorageMock = {
    getItem(k) {
      return localStore.has(k) ? localStore.get(k) : null;
    },
    setItem(k, v) {
      localStore.set(k, String(v));
      localCalls.set.push([k, String(v)]);
    },
    removeItem(k) {
      localStore.delete(k);
      localCalls.remove.push(k);
    }
  };

  const dom = makeDom();
  let mod = null;
  const windowMock = {
    getComputedStyle: () =>
      new Proxy(
        { color: "rgb(0, 0, 0)" },
        {
          get(target, key) {
            if (key === "getPropertyValue") {
              return (prop) => (prop === "color" ? target.color : "");
            }
            return target[key] ?? "";
          }
        }
      ),
    addEventListener() {},
    removeEventListener() {},
    dispatchEvent() {},
    __ModuleLoader__: {
      load({ factory }) {
        const fakeRequire = (name) => {
          if (name === "react") {
            return {
              useState: () => [null, () => {}],
              useEffect: () => {},
              createElement: () => ({})
            };
          }
          throw new Error("unexpected require: " + name);
        };
        mod = factory(fakeRequire);
        return mod;
      }
    }
  };
  const effects = [];
  const injections = [];
  const ctx = {
    reflect: {
      get(name) {
        return name === "settingsScope" ? scope : undefined;
      }
    },
    slots: {
      inject() {}
    },
    effect(factory) { effects.push(factory()); }
  };
  if (dynamicInject) {
    ctx.inject = (names, callback) => {
      injections.push({ names, callback });
      if (scope !== null) callback({ settingsScope: scope, effect: ctx.effect });
    };
  }

  global.window = windowMock;
  global.document = dom;
  global.localStorage = localStorageMock;
  new Function("window", source)(windowMock);

  return { mod, ctx, dom, localCalls, effects, injections };
}

test("settingsScope arriving after apply binds through optional Cordis injection", () => {
  const h = loadModule({ localValue: LOCAL_A, dynamicInject: true });
  h.mod.apply(h.ctx);
  assert.equal(h.injections.length, 1);
  const late = makeScope({ snapshot: { status: "ready", value: { theme: HOST_B } } });
  h.injections[0].callback({ settingsScope: late.scope, effect: h.ctx.effect });
  assert.deepEqual(late.calls.bind, { namespace: "dsh-veneer" });
  assert.ok(h.dom.themeStyle.textContent.includes("#bbbbbbff"));
  h.effects.at(-1)();
  assert.equal(late.calls.subscribeDisposed, 1);
});

test("a stale provider disposer cannot tear down a newer settingsScope binding", () => {
  const h = loadModule({ localValue: LOCAL_A, dynamicInject: true });
  h.mod.apply(h.ctx);
  const first = makeScope({ snapshot: { status: "ready", value: { theme: HOST_B } } });
  h.injections[0].callback({ settingsScope: first.scope, effect: h.ctx.effect });
  const disposeFirst = h.effects.at(-1);
  const secondTheme = { ...HOST_B, themeOverrides: [["--dsw-specific-sidebar-fill", "#CCCCCC"]] };
  const second = makeScope({ snapshot: { status: "ready", value: { theme: secondTheme } } });
  h.injections[0].callback({ settingsScope: second.scope, effect: h.ctx.effect });
  disposeFirst();
  h.mod.__test.storage.saveTheme();
  assert.equal(second.calls.set.length, 1, "new provider must remain bound after stale cleanup");
  assert.equal(first.calls.scopeDisposed, 1, "replaced provider scope must be disposed exactly once");
});

test("a failed late binding does not register a cleanup that can tear down a later provider", () => {
  const h = loadModule({ localValue: LOCAL_A, dynamicInject: true });
  h.mod.apply(h.ctx);
  const broken = { bind() { throw new Error("provider unavailable"); } };
  h.injections[0].callback({ settingsScope: broken, effect: h.ctx.effect });
  assert.equal(h.effects.length, 0);
  const good = makeScope({ snapshot: { status: "ready", value: { theme: HOST_B } } });
  h.injections[0].callback({ settingsScope: good.scope, effect: h.ctx.effect });
  assert.equal(h.effects.length, 1);
  h.mod.__test.storage.saveTheme();
  assert.equal(good.calls.set.length, 1);
});

test("without settingsScope the storage stays localStorage-only", () => {
  const h = loadModule({ localValue: LOCAL_A, scope: null });
  h.mod.apply(h.ctx);

  assert.ok(h.dom.themeStyle.textContent.includes("--dsw-specific-sidebar-fill"));
  // Surface colors are normalized to 8-digit lowercase hex in the CSS.
  assert.ok(h.dom.themeStyle.textContent.includes("#aaaaaaff"));

  h.mod.__test.storage.saveTheme();
  assert.equal(h.localCalls.set.length, 1);
  const saved = JSON.parse(h.localCalls.set[0][1]);
  assert.equal(saved.v, 2);
  // saveTheme persists the canonical (sanitized) state, not the raw input.
  assert.deepEqual(saved.themeOverrides, [["--dsw-specific-sidebar-fill", "#aaaaaaff"]]);
});

test("with settingsScope, binds dsh-veneer and prefers the Host snapshot", () => {
  const host = makeScope({ snapshot: { status: "ready", value: { theme: HOST_B } } });
  const h = loadModule({ localValue: LOCAL_A, scope: host.scope });
  h.mod.apply(h.ctx);

  assert.deepEqual(host.calls.bind, { namespace: "dsh-veneer" });
  assert.ok(host.calls.subscribed.length >= 1, "must subscribe to Host changes");
  assert.ok(h.dom.themeStyle.textContent.includes("#bbbbbbff"));
  assert.ok(h.dom.themeStyle.textContent.includes('"Inter"'));
  assert.ok(h.dom.themeStyle.textContent.includes("#002570"));

  // Local snapshot is refreshed to the Host value.
  const refreshed = JSON.parse(h.localCalls.set[h.localCalls.set.length - 1][1]);
  assert.equal(refreshed.v, 2);
  assert.deepEqual(refreshed.themeOverrides, [["--dsw-specific-sidebar-fill", "#BBBBBB"]]);
  assert.equal(refreshed.hostManaged, true);
});

test("a confirmed Host echo upgrades a local draft to hostManaged", async () => {
  let current = { status: "ready", value: {} };
  const host = makeScope({
    snapshot: () => current,
    setImpl: (_field, value) => {
      current = { status: "ready", value: { theme: value } };
      host.calls.subscribed.forEach((fn) => fn());
      return Promise.resolve();
    }
  });
  const h = loadModule({ localValue: null, scope: host.scope });
  h.mod.apply(h.ctx);
  h.mod.__test.storage.saveTheme();
  await new Promise((resolve) => setTimeout(resolve, 0));
  const last = JSON.parse(h.localCalls.set.at(-1)[1]);
  assert.equal(last.hostManaged, true);
});

test("an older Host write echo does not overwrite a newer local draft", () => {
  let current = { status: "ready", value: {} };
  const host = makeScope({ snapshot: () => current });
  const h = loadModule({ localValue: null, scope: host.scope });
  h.mod.apply(h.ctx);
  h.mod.__test.storage.saveTheme();
  const newer = JSON.stringify({
    v: 2,
    hostManaged: false,
    themeOverrides: [["--dsw-specific-sidebar-fill", "#CCCCCC"]],
    fontOverrides: [],
    fontColors: []
  });
  global.localStorage.setItem(STORAGE_KEY, newer);
  current = { status: "ready", value: { theme: host.calls.set[0][1] } };
  host.calls.subscribed[0]();
  assert.equal(global.localStorage.getItem(STORAGE_KEY), newer);
});

test("empty Host migrates a legal localStorage theme (copy, never delete)", () => {
  const host = makeScope({ snapshot: { status: "ready", value: {} } });
  const h = loadModule({ localValue: LOCAL_A, scope: host.scope });
  h.mod.apply(h.ctx);

  assert.ok(h.dom.themeStyle.textContent.includes("#aaaaaaff"));
  assert.equal(host.calls.set.length, 1);
  assert.equal(host.calls.set[0][0], "theme");
  assert.equal(host.calls.set[0][1].schemaVersion, 3);
  assert.deepEqual(host.calls.set[0][1].themeOverrides, [["--dsw-specific-sidebar-fill", "#AAAAAA"]]);
  assert.ok(h.localCalls.remove.length === 0, "localStorage must not be deleted by migration");
});

test("illegal Host data is neither applied nor overwritten", () => {
  const host = makeScope({ snapshot: { status: "ready", value: { theme: "not-a-theme" } } });
  const h = loadModule({ localValue: LOCAL_A, scope: host.scope });
  h.mod.apply(h.ctx);

  assert.ok(h.dom.themeStyle.textContent.includes("#aaaaaaff"));
  assert.equal(host.calls.set.length, 0, "no migration over non-empty illegal Host data");
  assert.equal(h.localCalls.set.length, 0, "local snapshot stays untouched");
});

test("Host save rejection writes a synchronous draft and shows a non-blocking warning", async () => {
  const host = makeScope({
    snapshot: { status: "ready", value: {} },
    setImpl: () => Promise.reject(new Error("transport down"))
  });
  const h = loadModule({ localValue: null, scope: host.scope });
  h.mod.apply(h.ctx);

  h.mod.__test.storage.saveTheme();
  assert.equal(h.localCalls.set.length, 1, "localStorage write is synchronous");

  await new Promise((resolve) => setTimeout(resolve, 0));
  const banner = h.dom.getElementById("dsh-veneer-storage-warning");
  assert.ok(banner !== null, "a warning banner must appear");
  assert.ok(banner.textContent.includes("未写入"));
});

test("reset clears localStorage and unsets the Host theme field", () => {
  const host = makeScope({ snapshot: { status: "ready", value: { theme: HOST_B } } });
  const h = loadModule({ localValue: LOCAL_A, scope: host.scope });
  h.mod.apply(h.ctx);

  h.mod.__test.storage.resetTheme();
  assert.ok(h.localCalls.remove.includes(STORAGE_KEY));
  assert.deepEqual(host.calls.unset, ["theme"]);
  assert.equal(host.calls.set.length, 0, "reset must not set theme");
  assert.equal(h.dom.themeStyle.textContent, "");
  assert.ok(h.dom.removedProps.includes("--dsw-specific-sidebar-fill"));
});

test("a runtime emptied Host is never re-populated from local storage", () => {
  let current = { status: "ready", value: { theme: HOST_B } };
  const host = makeScope({ snapshot: () => current });
  const h = loadModule({ localValue: LOCAL_A, scope: host.scope });
  h.mod.apply(h.ctx);

  // Boot: Host 有主题 -> 应用 Host，无迁移写。
  assert.equal(host.calls.set.length, 0);
  assert.ok(h.dom.themeStyle.textContent.includes("#bbbbbbff"));

  // 用户 reset：本地清空 + Host unset；随后 Host 广播空快照（另一页或本页均可）。
  h.mod.__test.storage.resetTheme();
  current = { status: "ready", value: {} };
  host.calls.subscribed[0]();

  assert.equal(host.calls.unset.length, 1);
  assert.equal(host.calls.set.length, 0, "emptied Host must not be re-populated at runtime");
  assert.equal(h.dom.themeStyle.textContent, "");
});

test("another page resetting clears this page's UI without re-populating Host", () => {
  let current = { status: "ready", value: { theme: HOST_B } };
  const host = makeScope({ snapshot: () => current });
  const h = loadModule({ localValue: LOCAL_A, scope: host.scope });
  h.mod.apply(h.ctx);
  assert.ok(h.dom.themeStyle.textContent.includes("#bbbbbbff"));

  // 另一页面 reset 后 Host 广播空快照；本页本地残留也不得写回，界面同步清空。
  current = { status: "ready", value: {} };
  host.calls.subscribed[0]();

  assert.equal(host.calls.set.length, 0, "no write back from a stale local snapshot");
  assert.equal(h.dom.themeStyle.textContent, "", "UI clears together with the Host");
});

test("local->Host migration happens once at boot, never again at runtime", () => {
  let current = { status: "ready", value: {} };
  const host = makeScope({ snapshot: () => current });
  const h = loadModule({ localValue: LOCAL_A, scope: host.scope });
  h.mod.apply(h.ctx);

  // Boot: 空 Host + 合法本地主题 -> 迁移一次。
  assert.equal(host.calls.set.length, 1);

  // 运行期再次出现空 Host（另一页面 reset）：不得发生第二次迁移写。
  h.mod.__test.storage.resetTheme();
  current = { status: "ready", value: {} };
  host.calls.subscribed[0]();

  assert.equal(host.calls.set.length, 1, "migration must not repeat after boot");
  assert.equal(host.calls.unset.length, 1);
});

test("Host changes after boot are applied through the subscription", () => {
  let current = { status: "ready", value: {} };
  const host = makeScope({ snapshot: () => current });
  const h = loadModule({ localValue: LOCAL_A, scope: host.scope });
  h.mod.apply(h.ctx);

  // Boot: empty Host + legal local -> migration attempted.
  assert.equal(host.calls.set.length, 1);
  assert.ok(h.dom.themeStyle.textContent.includes("#aaaaaaff"));

  current = { status: "ready", value: { theme: HOST_B } };
  host.calls.subscribed[0]();
  assert.ok(h.dom.themeStyle.textContent.includes("#bbbbbbff"));
});

test("a repeated empty Host snapshot does not clear the built-in default theme", () => {
  let current = { status: "ready", value: {} };
  const host = makeScope({ snapshot: () => current });
  const h = loadModule({ localValue: null, scope: host.scope });
  h.mod.apply(h.ctx);

  const before = h.dom.themeStyle.textContent;
  assert.ok(before.includes("--dsw-specific-sidebar-fill"), "default theme is applied at boot");

  current = { status: "ready", value: {} };
  host.calls.subscribed[0]();

  assert.equal(h.dom.themeStyle.textContent, before, "empty -> empty is not a reset transition");
});

test("a remote Host reset removes this client's stale local snapshot", () => {
  let current = { status: "ready", value: { theme: HOST_B } };
  const host = makeScope({ snapshot: () => current });
  const h = loadModule({ localValue: LOCAL_A, scope: host.scope });
  h.mod.apply(h.ctx);

  current = { status: "ready", value: {} };
  host.calls.subscribed[0]();

  assert.ok(h.localCalls.remove.includes(STORAGE_KEY), "remote reset must clear local compatibility data");
  assert.equal(h.dom.themeStyle.textContent, "");
});

test("a Host-managed stale local snapshot is not migrated back into an empty Host", () => {
  const staleManaged = JSON.stringify({
    ...JSON.parse(LOCAL_A),
    hostManaged: true
  });
  const host = makeScope({ snapshot: { status: "ready", value: {} } });
  const h = loadModule({ localValue: staleManaged, scope: host.scope });
  h.mod.apply(h.ctx);

  assert.equal(host.calls.set.length, 0, "managed snapshots are never legacy migration candidates");
  assert.ok(h.localCalls.remove.includes(STORAGE_KEY), "stale managed snapshot is discarded");
  assert.equal(h.dom.themeStyle.textContent, "", "stale snapshot is removed from the rendered theme");
});

test("a recovered Host write is reported when the promise resolves without applying the value", async () => {
  let current = { status: "ready", value: { theme: HOST_B } };
  const host = makeScope({
    snapshot: () => current,
    setImpl: async () => {
      current = { status: "ready", value: { theme: HOST_B } };
      host.calls.subscribed[0]();
    }
  });
  const h = loadModule({ localValue: LOCAL_A, scope: host.scope });
  h.mod.apply(h.ctx);

  h.mod.__test.storage.saveTheme();
  await new Promise((resolve) => setTimeout(resolve, 0));

  const banner = h.dom.getElementById("dsh-veneer-storage-warning");
  assert.ok(banner !== null, "resolved-after-recovery writes must still show a warning");
  assert.ok(banner.textContent.includes("未写入"));
});

test("a recovered Host reset is reported when unset resolves but the Host value remains", async () => {
  let current = { status: "ready", value: { theme: HOST_B } };
  const host = makeScope({
    snapshot: () => current,
    unsetImpl: async () => {
      await Promise.resolve();
      current = { status: "ready", value: { theme: HOST_B } };
      host.calls.subscribed[0]();
    }
  });
  const h = loadModule({ localValue: LOCAL_A, scope: host.scope });
  h.mod.apply(h.ctx);

  h.mod.__test.storage.resetTheme();
  await new Promise((resolve) => setTimeout(resolve, 0));

  const banner = h.dom.getElementById("dsh-veneer-storage-warning");
  assert.ok(banner !== null, "resolved-after-recovery reset must show a warning");
  assert.ok(banner.textContent.includes("未写入"));
  assert.ok(h.dom.themeStyle.textContent.includes("#bbbbbbff"), "recovery restores the authoritative Host theme");
});
