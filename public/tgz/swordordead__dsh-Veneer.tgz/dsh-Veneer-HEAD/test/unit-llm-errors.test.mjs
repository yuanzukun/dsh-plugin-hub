// unit-llm-errors.test.mjs — pure-function unit tests for lib/llm-errors.js.
//
// Run:  node --test test/unit-llm-errors.test.mjs
// The module is dependency-free on purpose, so this runs without the harness
// packages or a running DSH service.

import { test } from "node:test";
import assert from "node:assert/strict";
import { llmFailureText } from "../lib/llm-errors.js";

test("maps canonical dsh-llm codes to friendly Chinese copy", () => {
  assert.equal(
    llmFailureText({ code: "MISSING_CREDENTIAL" }),
    "未配置模型凭据：请在 Harness 设置中配置模型 API Key 后重试"
  );
  assert.equal(
    llmFailureText({ code: "INVALID_CREDENTIAL" }),
    "模型凭据无效：请在 Harness 设置中检查模型 API Key"
  );
  assert.equal(
    llmFailureText({ code: "AUTH" }),
    "模型认证失败（API Key 无效或已过期）"
  );
  assert.equal(llmFailureText({ code: "RATE_LIMIT" }), "请求频率超限，请稍后再试");
  assert.equal(llmFailureText({ code: "QUOTA" }), "模型账户额度不足或已用完，请检查额度");
  assert.equal(
    llmFailureText({ code: "NO_ADAPTER" }),
    "当前模型提供方不可用，请切换模型或稍后重试"
  );
  assert.equal(
    llmFailureText({ code: "CONTEXT_WINDOW_EXCEEDED" }),
    "请求超出模型上下文窗口，请简化描述后重试"
  );
  assert.equal(llmFailureText({ code: "EMPTY_RESPONSE" }), "模型未返回内容，请重试");
  assert.equal(llmFailureText({ code: "TRANSPORT" }), "无法连接模型服务，请检查网络后重试");
  assert.equal(llmFailureText({ code: "SERVER" }), "模型服务暂时不可用，请稍后重试");
  assert.equal(llmFailureText({ code: "TIMEOUT" }), "模型请求超时，请稍后重试");
  assert.equal(llmFailureText({ code: "STREAM_CLOSED" }), "模型响应中断，请重试");
  assert.equal(llmFailureText({ code: "INVALID_REQUEST" }), "请求参数无效，请调整描述后重试");
  assert.equal(llmFailureText({ code: "NETWORK" }), "网络错误，无法连接模型服务");
});

test("QUOTA regression: canonical code is 'QUOTA', not 'QUOTA_EXCEEDED'", () => {
  // @deepseek-ai/dsh-llm exports QUOTA_EXCEEDED_CODE = "QUOTA". The old table
  // keyed on "QUOTA_EXCEEDED", which was dead code — an exhausted account fell
  // through to the raw provider message instead of the friendly copy.
  assert.equal(
    llmFailureText({ code: "QUOTA", message: "Insufficient Balance" }),
    "模型账户额度不足或已用完，请检查额度"
  );
  // A hypothetical non-canonical code must NOT hit the map: it falls through
  // to the provider message (documenting the old dead-code behaviour is gone).
  assert.equal(llmFailureText({ code: "QUOTA_EXCEEDED", message: "Insufficient Balance" }), "Insufficient Balance");
});

test("falls back to the provider message for unknown codes", () => {
  assert.equal(llmFailureText({ code: "SOME_UNKNOWN_CODE", message: "provider said no" }), "provider said no");
});

test("falls back to generic copy when neither code nor message is present", () => {
  assert.equal(llmFailureText({}), "模型调用失败");
  assert.equal(llmFailureText({ code: "X" }), "模型调用失败（X）");
});

test("prefers the friendly map over a non-empty provider message", () => {
  assert.equal(
    llmFailureText({ code: "AUTH", message: "invalid api key" }),
    "模型认证失败（API Key 无效或已过期）"
  );
});

test("handles null / undefined / non-object input without throwing", () => {
  assert.equal(llmFailureText(null), "模型调用失败");
  assert.equal(llmFailureText(undefined), "模型调用失败");
  assert.equal(llmFailureText("oops"), "模型调用失败");
  assert.equal(llmFailureText(42), "模型调用失败");
});

test("treats non-string code / message fields as absent", () => {
  assert.equal(llmFailureText({ code: 7, message: 123 }), "模型调用失败");
  assert.equal(llmFailureText({ code: "", message: "" }), "模型调用失败");
});
