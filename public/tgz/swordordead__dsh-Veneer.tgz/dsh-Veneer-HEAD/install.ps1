﻿# install.ps1 — dsh-veneer 一键安装脚本
#
# 作用：把本目录下的 dsh-veneer 插件装到当前用户的 DeepSeek Harness：
#   1. 复制 package.json + cordis.patch.yml + lib/ 到 <DSH_HOME>/profiles/web/node_modules/dsh-veneer
#   2. 在 <DSH_HOME>/profiles/web/cordis.patch.yml 的 insert 列表注册一行（幂等，重复执行不重复注册）
#   注意：如果该插件已通过「dsh plugin --profile web add dsh-veneer」管理
#   （web/package.json 的 dsh.profile.bundles 已含 dsh-veneer），则跳过第 2 步，
#   避免与官方命令产生重复注册。
# 首次安装或 Host 端文件变化后需重启 dsh web；仅 client 变化时刷新浏览器即可。
#
# 用法：
#   双击 install.bat（推荐）
#   或：powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
#   自定义 DSH 数据目录：powershell ... -File .\install.ps1 -DshHome "D:\path\to\.dsh"
#
# 只依赖 PowerShell 内置命令，无需 node / pnpm。

param(
    [string]$DshHome = "",
    [switch]$NoPause
)

$ErrorActionPreference = "Stop"

function Write-Step($msg) { Write-Host ""; Write-Host "==> $msg" -ForegroundColor Cyan }
function Write-Ok($msg)   { Write-Host "  OK  $msg" -ForegroundColor Green }
function Write-Fail($msg) { Write-Host "  x   $msg" -ForegroundColor Red }

# ── 1. 定位 DSH 数据目录（优先级：-DshHome 参数 > $env:DSH_HOME > ~/.dsh）──
if ([string]::IsNullOrWhiteSpace($DshHome)) { $DshHome = $env:DSH_HOME }
if ([string]::IsNullOrWhiteSpace($DshHome)) { $DshHome = Join-Path $HOME ".dsh" }
$DshHome = [System.IO.Path]::GetFullPath($DshHome)
$profilesDir = Join-Path $DshHome "profiles"
$webDir      = Join-Path $profilesDir "web"
$patchFile   = Join-Path $webDir "cordis.patch.yml"

Write-Step "检查 DSH 环境"
Write-Host "  DSH 数据目录 : $DshHome"
if (-not (Test-Path -LiteralPath $patchFile)) {
    Write-Fail "未找到 web profile 配置文件：$patchFile"
    Write-Host ""
    Write-Host "  请先启动一次 DSH 网页端（运行 dsh web，它会自动初始化 profile）" -ForegroundColor Yellow
    Write-Host "  初始化完成后再运行本安装程序。" -ForegroundColor Yellow
    if (-not $NoPause) { Read-Host "按回车键退出" }
    exit 1
}
Write-Ok "web profile 已存在"

# Host Settings 是 v0.8.0 的公开运行契约；旧版 Harness 缺少这些包时应明确拒绝，
# 不能等插件启动后才以 MODULE_NOT_FOUND 静默失活。
$sharedModules = Join-Path $profilesDir "node_modules\@deepseek-ai"
foreach ($dep in @("dsh-settings", "schemastery")) {
    if (-not (Test-Path -LiteralPath (Join-Path $sharedModules $dep))) {
        Write-Fail "当前 Harness 缺少 @deepseek-ai/$dep，请先更新 DeepSeek Harness"
        if (-not $NoPause) { Read-Host "按回车键退出" }
        exit 1
    }
}
Write-Ok "Host Settings 依赖可用"

# ── 2. 定位插件源码（本脚本所在目录）──
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not (Test-Path -LiteralPath (Join-Path $src "package.json"))) {
    Write-Fail "当前目录缺少 package.json，请把本安装程序与插件文件放在同一目录后重试。"
    if (-not $NoPause) { Read-Host "按回车键退出" }
    exit 1
}

# ── 3. 检查是否已由官方包管理器安装 ──
$dst = Join-Path $webDir "node_modules\dsh-veneer"
$webPkgFile = Join-Path $webDir "package.json"
$managedByDsh = $false
if (Test-Path -LiteralPath $webPkgFile) {
    try {
        $webPkg = Get-Content -LiteralPath $webPkgFile -Raw | ConvertFrom-Json -ErrorAction Stop
        $bundles = $webPkg.dsh.profile.bundles
        if ($bundles -is [System.Array] -and ($bundles -contains "dsh-veneer")) { $managedByDsh = $true }
    } catch {
        $managedByDsh = $false
    }
}
if ($managedByDsh) {
    Write-Ok "已由 dsh plugin 管理；未覆盖包管理器目录"
    Write-Host "  请运行：dsh plugin --profile web update dsh-veneer" -ForegroundColor Yellow
    if (-not $NoPause) { Read-Host "按回车键退出" }
    exit 0
}

# ── 4. 复制插件到 web profile 的 node_modules ──
Write-Step "复制插件文件到 $dst"
New-Item -ItemType Directory -Path $dst -Force | Out-Null
foreach ($rel in @("package.json", "cordis.patch.yml", "lib")) {
    $s = Join-Path $src $rel
    if (-not (Test-Path -LiteralPath $s)) {
        Write-Fail "缺少必需文件：$rel"
        if (-not $NoPause) { Read-Host "按回车键退出" }
        exit 1
    }
    Copy-Item -LiteralPath $s -Destination $dst -Recurse -Force
}
Write-Ok "插件文件已复制"

# ── 5. 注册到 cordis.patch.yml（幂等）──
Write-Step "注册插件到 web profile"
# 显式按 UTF-8 读取（PS5.1 默认按 ANSI/GBK 解码无 BOM 文件，会把已有中文注释读成乱码）
$content = [System.IO.File]::ReadAllText($patchFile, [System.Text.Encoding]::UTF8)
if ($content -match "(?m)^\s*-\s*id:\s*dsh-veneer\s*$") {
    Write-Ok "cordis.patch.yml 已包含 dsh-veneer 注册项，跳过"
} else {
    $block = @"

# ── dsh-veneer: DSH UI reskin editor ──
- insert:
    - id: dsh-veneer
      name: 'dsh-veneer'
"@
    # 保持 UTF-8 无 BOM（与原文件一致），避免 YAML 解析差异
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    # 顶层若是空数组字面量 "[]"，必须整行剔除后再追加：`[]` 已经结束了顶层
    # 数组，后面再接 "- " 序列项是非法 YAML（seq-item-ind 解析错误），会让
    # dsh 加载 patch 时直接失败、后端启动即退出。空文档同样归入这一支。
    $body = (($content -split "`r?`n") | Where-Object { $_.Trim() -ne "[]" }) -join "`r`n"
    $body = $body.TrimEnd()
    if ($body -eq "") {
        $newContent = $block.TrimStart("`r", "`n") + "`r`n"
    } else {
        $newContent = $body + "`r`n" + $block + "`r`n"
    }
    [System.IO.File]::WriteAllText($patchFile, $newContent, $utf8NoBom)
    Write-Ok "已写入 cordis.patch.yml"
}

# ── 6. SHA256 校验 ──
Write-Step "校验文件一致性"
$allMatch = $true
foreach ($rel in @("package.json", "cordis.patch.yml", "lib\client.js", "lib\index.js", "lib\theme-storage.js", "lib\llm-errors.js")) {
    $srcHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $src $rel)).Hash
    $dstHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $dst $rel)).Hash
    if ($srcHash -eq $dstHash) {
        Write-Ok "$rel -> MATCH"
    } else {
        Write-Fail "$rel -> MISMATCH"
        $allMatch = $false
    }
}
if (-not $allMatch) {
    Write-Fail "文件校验不一致，请重新下载后再试。"
    if (-not $NoPause) { Read-Host "按回车键退出" }
    exit 1
}

# ── 7. 完成 ──
Write-Host ""
Write-Host "安装完成。首次安装或 Host 端升级请重启 dsh web；仅前端更新时强制刷新浏览器。" -ForegroundColor Green
if (-not $NoPause) { Read-Host "按回车键退出" }
