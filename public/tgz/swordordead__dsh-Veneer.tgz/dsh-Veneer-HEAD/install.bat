@echo off
rem dsh-veneer one-click installer (Windows)
rem Runs install.ps1 in the same directory with PowerShell.

setlocal
cd /d "%~dp0"

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
    echo.
    echo Install failed. See the messages above.
    pause
    exit /b 1
)

endlocal
