# dsh-Veneer 名称改动检查清单

> 供人工复核:本次把插件从 `dsh-ui-studio` 全面重命名为 `dsh-Veneer` 的全部改动对照。
> 验证日期:2026-08-19 | 仓库:https://github.com/swordordead/dsh-Veneer

---

## 一、包与插件标识

| 项 | 旧 | 新 |
|---|---|---|
| npm 包名 | `dsh-ui-studio` | `dsh-veneer` |
| 插件 id (client bundle) | `dsh-ui-studio` | `dsh-veneer` |
| CSS style tag | `dsh-ui-studio/editor.css` | `dsh-veneer/editor.css` |
| localStorage 键 | `dsh-ui-studio.theme.v1` | `dsh-veneer.theme.v1` |
| 图片上传 API | `/api/dsh-ui-studio/upload` | `/api/dsh-veneer/upload` |
| 侧栏按钮 title/aria | `UI Studio 界面编辑器` | `Veneer 界面编辑器` |
| 面板标题 | `🎨 UI Studio` | `🎨 Veneer` |
| 背景分组标题 | `UI studio页面` | `Veneer 页面` |

## 二、CSS class / 组件 / 事件

| 项 | 旧 | 新 |
|---|---|---|
| 全部 class 前缀 | `.dsh-studio-*` | `.dsh-veneer-*` |
| Toggle 组件 | `StudioToggle` | `VeneerToggle` |
| 模式事件 | `dsh-studio:mode` | `dsh-veneer:mode` |
| panel dataset | `dshStudio` | `dshVeneer` |

## 三、文件改动

| 文件 | 改动 |
|---|---|
| `package.json` | name → `dsh-veneer`;description 重写 |
| `README.md` | 整篇重写(贴合当前背景编辑功能) |
| `docs/dsh-veneer-architecture.html` | 文件名 + 内容(标题/节点文字) |
| `docs/dsh-veneer-architecture.json` | 文件名 + 内容(标题/组件标签) |
| `docs/superpowers/plans/2026-08-18-bg-group-refactor.md` | 内容(路径/class 引用) |
| `docs/superpowers/plans/task4-review-prompt.md` | 内容(路径引用) |
| `docs/audit-findings-self.md` | 内容(事件名) |

## 四、部署与远端

| 项 | 旧 | 新 |
|---|---|---|
| 部署目录 | `~/.dsh/profiles/node_modules/dsh-ui-studio` | `~/.dsh/profiles/node_modules/dsh-veneer` |
| `profiles/web/cordis.patch.yml` | `id/name: dsh-ui-studio` | `id/name: dsh-veneer` |
| GitHub 仓库 | — | `swordordead/dsh-Veneer` (master) |
| 源码目录 | `Desktop/onetwothree/dsh-ui-studio` | `Desktop/onetwothree/dsh-veneer` |

## 五、验证结果

| 检查项 | 结果 |
|---|---|
| 全仓库 `studio` 相关字符串残留 | 无 ✓ |
| package.json JSON 合法性(源码 + 部署) | 合法 ✓ |
| 语法检查 client.js / index.js | 通过 ✓ |
| dsh web 加载 `dsh-veneer` 按钮 | 正常 ✓ |
| 页面无 console 报错 | 无 ✓ |
| GitHub push | `025464f` + `bf7e900` ✓ |

## 六、git 提交历史

| commit | 说明 |
|---|---|
| `025464f` | Initial commit: dsh-veneer — DSH UI reskin editor |
| `bf7e900` | fix: missing comma in package.json description |
