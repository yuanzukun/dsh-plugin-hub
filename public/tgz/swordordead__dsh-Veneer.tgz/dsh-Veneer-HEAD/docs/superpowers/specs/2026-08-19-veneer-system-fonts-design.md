# 扫描系统字体加入字体选择 设计文档

日期：2026-08-19  |  状态：已批准，待实施  |  范围：仅 client.js，零 host 改动、零重启

## 1. 背景与目标
现有字体选择来自 `FONT_PRESETS`（22 个写死预设）+ 每区域「自定义…」文本框，无法反映用户系统里实际安装了哪些字体。

目标：新增「扫描系统字体」能力，用浏览器 `queryLocalFonts()` 枚举已装字体，作为新的字体来源加入下拉，让用户能选择任意已安装字体。

## 2. 明确不做
- 不做拖入字体文件上传/注册（用户已明确排除）。
- 不改 `lib/index.js`，不新增 host 路由，不重启 dsh web。

## 3. 设计

### 3.1 状态与按钮
- 新增内存变量 `systemFonts = []`（本次会话内记忆，不持久化列表本身）。
- 字体设置组头「重置全部」旁新增「扫描系统字体」按钮。
- 点击 → `window.queryLocalFonts()` → 取 `family` 去重 → 过滤符号字体（Wingdings/Symbol/Webdings/Segoe UI Symbol/Segoe UI Emoji 等）→ `localeCompare` 排序 → 上限 300 → 写入 `systemFonts` → 重绘字体区。
- 降级：无 `window.queryLocalFonts` → 按钮置灰、提示「需 Chrome」；授权被拒 → 提示「已拒绝，可稍后重试」。

### 3.2 下拉结构
- 每个区域的 `<select>` 在「22 预设」之后、「自定义…」之前插入 `<optgroup label="系统字体">`。
- 选项值用 `system:<字体名>` 前缀，规避与预设 key 的冲突。

### 3.3 选择与存储
- 选中系统字体 → `fontOverrides` 存 `system:<字体名>`，复用 `applyFontOverride` + localStorage，存储格式不变（仍是字符串）。
- 刷新后：把「当前已选系统字体」补回下拉选项（即使尚未重扫），避免选中态丢失。

### 3.4 CSS 生成
- `resolveFontCssValue`：值以 `system:` 开头 → 去掉前缀、加引号输出 `font-family: "字体名"`（系统已装，无需回退栈）。
- `resolveFontOverride`：识别 `system:` 前缀 → 返回该 key 用于 select 回显。
- 预设 key / 自定义原文逻辑不变。

## 4. 涉及函数/区域（client.js）
- `FONT_PRESETS` 附近：新增符号字体过滤清单、`systemFonts` 状态。
- `renderFontProperties`：新增「扫描系统字体」按钮、optgroup 注入、已选系统字体回补。
- `resolveFontOverride` / `resolveFontCssValue`：处理 `system:` 前缀。
- `buildThemeCss`：无需改动（走 resolveFontCssValue）。

## 5. 验证计划
- `node --check` 语法校验。
- 同步部署副本并校验哈希一致。
- Playwright：点「扫描系统字体」→ 下拉出现「系统字体」分组且含真实字体（如 Microsoft YaHei / Arial）→ 选中后 CSS 写入 `font-family: "..."` → 刷新后选中态保留 → 无页面报错。
- 降级路径：模拟无 `queryLocalFonts`，确认按钮置灰且不影响 22 预设。

## 6. 风险
- `queryLocalFonts` 仅 Chrome（dsh GUI 即 Chrome），且需一次授权；拒绝/缺失时现有功能不受影响。