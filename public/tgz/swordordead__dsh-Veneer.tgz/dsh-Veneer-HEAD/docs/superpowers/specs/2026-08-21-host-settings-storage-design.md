# dsh-veneer Host Settings 持久化设计

日期：2026-08-21  
状态：已批准  
目标版本：0.8.0

## 1. 目标

将主题配置从“仅浏览器 `localStorage`”演进为“DSH Host Settings 主存储 + `localStorage` 兼容快照”，同时保持现有图片目录、旧主题数据、导入导出和离线降级行为不变。

## 2. 官方契约

仅依赖 Harness 公开架构：

1. Host 端使用 `@deepseek-ai/dsh-settings` 的 `settingsNamespace()` 注册插件专属 Schema。
2. Browser 端使用 `ctx.settingsScope.bind()` 读取、订阅和写入设置。
3. 使用 `dsh.client`、`dsh.bundle` 和 Cordis 服务注入加载插件。
4. 继续优先使用公开 `--dsw-*` 设计 Token；不新增对随机 DOM class 的依赖。

## 3. 数据边界

Host Settings 命名空间固定为 `dsh-veneer`，只保存一个 `theme` 字段：

```json
{
  "theme": {
    "schemaVersion": 3,
    "themeOverrides": [],
    "fontOverrides": [],
    "fontColors": []
  }
}
```

图片二进制继续保存在：

```text
~/.dsh/storages/dsh-veneer/images/
```

Host Settings 只保存图片 URL，不保存 Base64 或二进制。

## 4. 读取优先级

1. Host Settings 中存在合法主题：采用 Host 主题，同时刷新 `localStorage` 快照。
2. Host Settings 可用但为空：读取旧 `localStorage`；若存在合法旧主题，仅在首次 ready 快照（boot）时应用并写入 Host 一次，旧值不删除；运行期 Host 再被清空（本页或其他页面 reset）时**不再回迁**，只同步清空本页 UI。
3. Host Settings 服务不可用：读取并继续写入 `localStorage`；Host 已连接但只读、冲突或写入失败时，官方 scope 会 recovery 到 Host 权威版本，本地快照随之回滚并显示提示。
4. 两侧都没有合法主题：使用内置默认主题，但不立即制造用户配置。
5. Host 数据不合法：拒绝应用，回退到合法 `localStorage`；两侧原始数据都不自动删除。

client 通过 Cordis 可选服务 `ctx.inject(["settingsScope"], callback)` 动态接入：服务晚于
插件出现或发生 provider reload 时会重新绑定，scoped effect 负责释放旧订阅。首次安装或
Host 端注册变化必须重启一次 `dsh web`；此后仅 client 文件变化可只刷新浏览器。

## 5. 写入语义

每次持久化先同步写入带 `hostManaged:false` 的 `localStorage` 草稿，再异步写入 Host Settings；写入成功并从 scope 快照确认后标记 `hostManaged:true`。Host 写入失败、只读或冲突时，遵循官方 recovery 契约回到 Host 权威版本并显示非阻塞提示。

重置操作使用 `settingsScope.unset("theme")` 清空 Host 字段（官方"清空字段"语义：settings.yaml 删除该键，回落到组合层），并删除当前 `localStorage` 主题；成功后所有在线客户端删除各自兼容快照。若 Host 写入失败，官方 recovery 恢复旧 Host 主题并显示非阻塞提示。

## 6. 兼容与迁移

1. 保留当前 `dsh-veneer.theme.v1` 键名，避免升级时读不到旧数据。
2. 支持旧版原始 CSS、`v:2` JSON 和新的 `schemaVersion:3`。
3. 未标记 `hostManaged` 的旧版 v2 快照只迁移一次；已由 Host 管理过的快照遇到空 Host 时视为过期并删除，避免跨浏览器 reset 被复活。
4. Host Settings 服务未挂载时插件仍能完整运行，只退回现有 `localStorage` 行为；
   但 Harness 必须包含静态导入的 settings/schemastery npm 模块，否则插件无法加载。
5. 设置服务存在但命名空间未公开、连接只读或写入失败时，不使插件、图片或 AI 路由失活。

## 7. 模块边界

1. `lib/theme-storage.js`：纯数据解析、规范化、读写协调与迁移决策，可脱离浏览器和 DSH 单测。
2. `lib/index.js`：注册 `dsh-veneer` Host Settings Schema；设置服务为可选依赖。
3. `lib/client.js`：提供 local adapter 与 settingsScope adapter，应用存储结果，不包含 Schema 迁移细节。

## 8. 错误处理

1. 所有存储错误都不得阻止皮肤应用和编辑器打开。
2. Host 保存失败或冲突时回到 Host 权威快照，并显示一次友好提示，禁止静默吞掉故障。
3. 非法主题字段继续通过现有 token、颜色、字体和 URL 白名单清洗。
4. 图片缺失只移除对应背景呈现，不破坏其余主题字段。

## 9. 测试要求

1. 单测覆盖 Host 优先、旧数据迁移、Host 不可用降级、非法 Host 回退、双写顺序和重置。
2. Client 工厂测试覆盖有/无 `settingsScope` 两种注入环境。
3. Host 单测验证设置命名空间和 Schema 注册为可选，不影响现有 Web 路由。
4. 运行全部 Node 测试、模板校验和现有 DSH Playwright 回归。
5. 人工升级验证：0.7.1 保存主题后升级到 0.8.0，刷新、重启 DSH、卸载再安装插件，主题和图片仍可恢复。

## 10. 非目标

1. 不引入数据库。
2. 不把图片写入 Host Settings。
3. 不删除 `localStorage` 兼容层。
4. 不重构整个 2500 行客户端文件；只抽离存储职责。
5. 不承诺兼容 Harness 私有 DOM 结构，只承诺使用公开插件与设置契约。
