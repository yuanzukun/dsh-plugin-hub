# 背景分组重构实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 把背景界面分类从 flat `BG_SURFACES` + 魔法 `group` 字符串重构为 `BG_GROUPS` 单一数据源,重命名分组 key,动态计算计数,优化标签语义。

**Architecture:** 用嵌套结构 `BG_GROUPS` 作为唯一数据源(每个分组自带 `key/title/surfaces`),渲染器 `renderBgSurfaces` 退化为单层循环,计数与标题都从数据派生,消除"三套命名体系"与硬编码计数。

**Tech Stack:** 原生 JS(browser bundle,无框架);验证用 Playwright(Python, headless Chrome via system Chrome) + `node --check`。

**前置事实(已核实):**
- `BG_SURFACES` 仅在两处引用:client.js L67 定义、L289 遍历。结构反转安全,无其他消费者。
- `renderSurfaceRow(surf)` 只读 `surf.token` 和 `surf.label`,不读 `surf.group`,移除 `group` 字段安全。
- `--dsw-alias-bg-module-platform` 语义是"模块坐落的平台"(`module-platform`),故标签 `平台底` → `模块平台`;layer-1/layer-2 是抽象层叠背景,标签 `第1层/第2层` 保持忠实不变。

---

### Task 1: 数据源反转 —— BG_SURFACES → BG_GROUPS

**Files:**
- Modify: `C:\Users\Administrator\Desktop\onetwothree\dsh-veneer\lib\client.js` (BG_SURFACES 定义处,约 L66-79)

- [ ] **Step 1: 用 BG_GROUPS 替换 BG_SURFACES**

把 `const BG_SURFACES = [ ... ];` 整块(含其上方注释)替换为:

```js
		// ── background groups: the only editable targets. Each group owns its
		//     key/title/surfaces; each surface maps to a theme token whose value
		//     drives `background: var(--token)` ──
		const BG_GROUPS = [
			{
				key: "component",
				title: "组件背景",
				surfaces: [
					{ token: "--dsw-specific-sidebar-fill", label: "侧栏" },
					{ token: "--dsw-specific-bubble", label: "消息气泡" },
					{ token: "--dsw-specific-input-major", label: "输入框" },
					{ token: "--dsw-specific-menu", label: "菜单" },
					{ token: "--dsw-specific-selector", label: "选择器" },
					{ token: "--dsw-specific-tip", label: "提示气泡" }
				]
			},
			{
				key: "layer",
				title: "背景层",
				surfaces: [
					{ token: "--dsw-alias-bg-base", label: "主背景" },
					{ token: "--dsw-alias-bg-module-platform", label: "模块平台" },
					{ token: "--dsw-alias-bg-layer-1", label: "第1层" },
					{ token: "--dsw-alias-bg-layer-2", label: "第2层" },
					{ token: "--dsw-alias-bg-overlay", label: "覆盖层" }
				]
			}
		];
```

- [ ] **Step 2: 语法检查**

Run: `node --check "C:\Users\Administrator\Desktop\onetwothree\dsh-veneer\lib\client.js"`
Expected: exit 0,无输出(node --check 只做语法解析不执行,故 renderBgSurfaces 仍引用旧名 BG_SURFACES 也不会报错;ReferenceError 只在 Task 2 完成前实际运行浏览器时才出现)。

---

### Task 2: 渲染器单循环 + 动态计数

**Files:**
- Modify: `C:\Users\Administrator\Desktop\onetwothree\dsh-veneer\lib\client.js` (renderBgSurfaces,约 L277-294)

- [ ] **Step 1: 替换 renderBgSurfaces**

把整个 `function renderBgSurfaces(container) { ... }` 替换为:

```js
		function renderBgSurfaces(container) {
			for (const g of BG_GROUPS) {
				const sec = document.createElement("div");
				sec.className = "dsh-veneer-section";
				const title = document.createElement("div");
				title.textContent = g.title + " (" + g.surfaces.length + ")";
				title.style.cssText = "font-weight:600;margin-bottom:6px";
				sec.appendChild(title);
				for (const surf of g.surfaces) {
					sec.appendChild(renderSurfaceRow(surf));
				}
				container.appendChild(sec);
			}
		}
```

- [ ] **Step 2: 语法检查**

Run: `node --check "C:\Users\Administrator\Desktop\onetwothree\dsh-veneer\lib\client.js"`
Expected: exit 0。

---

### Task 3: 同步 + 端到端验证

**Files:**
- Create: `C:\Users\Administrator\Desktop\onetwothree\diag.py`(临时验证脚本,可复用已有路径)
- Modify: 同步 `C:\Users\Administrator\.dsh\profiles\node_modules\dsh-veneer\lib\client.js`

- [ ] **Step 1: 同步到部署位置**

Run:
```powershell
Copy-Item -Path "C:\Users\Administrator\Desktop\onetwothree\dsh-veneer\lib\client.js" -Destination "C:\Users\Administrator\.dsh\profiles\node_modules\dsh-veneer\lib\client.js" -Force
```
Expected: 无输出。

- [ ] **Step 2: 写 Playwright 验证脚本**

`diag.py` 内容:

```python
from playwright.sync_api import sync_playwright
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, channel="chrome")
    page = browser.new_page()
    errs = []
    page.on("pageerror", lambda e: errs.append(str(e)))
    page.goto("http://127.0.0.1:3080", wait_until="domcontentloaded")
    page.wait_for_timeout(6000)
    page.locator(".dsh-veneer-toggle").first.click()
    page.wait_for_timeout(800)

    titles = page.locator(".dsh-veneer-section > div").all_inner_texts()
    rows = page.locator(".dsh-veneer-surface").count()
    # 每行的 label 文本
    labels = page.evaluate("() => Array.from(document.querySelectorAll('.dsh-veneer-surface')).map(r => r.querySelector('label').textContent)")

    print("section headers:", [t.split(chr(10))[0] for t in titles if t], flush=True)
    print("surface row count:", rows, flush=True)
    print("labels:", labels, flush=True)
    print("page errors:", errs, flush=True)
    browser.close()
```

- [ ] **Step 3: 运行验证**

Run: `python "C:\Users\Administrator\Desktop\onetwothree\diag.py" 2>&1`
Expected 输出满足:
- section headers 含 `组件背景 (6)` 和 `背景层 (5)`
- surface row count == 11
- labels 顺序 == [侧栏, 消息气泡, 输入框, 菜单, 选择器, 提示气泡, 主背景, 模块平台, 第1层, 第2层, 覆盖层]
- page errors == []

---

### Task 4: 二次代码审查(可选,收敛回归)

**Files:** 无(派发审查 subagent)

- [ ] **Step 1: 派发 code review**

用 requesting-code-review 派发审查 subagent,核对:命名三轴是否已对齐(key/title/token 前缀)、计数是否动态、`模块平台` 标签是否准确、无 `BG_SURFACES` 残留引用。

Expected: 无 Critical;如有 Important 命名问题,回到 Task 1/2 修订。

---

## Self-Review 记录

- Spec 覆盖:code review 的 3 个 Important(generic 命名 / 硬编码计数 / 标签模糊)+ Minor(结构反转、magic string、标题复合词)均有对应任务。
- 占位符扫描:无 TBD/TODO;所有代码块完整。
- 类型一致性:`BG_GROUPS` 的分组字段 `key/title/surfaces` 与 `renderBgSurfaces` 读取的 `g.title/g.surfaces` 一致;surface 项字段 `token/label` 与 `renderSurfaceRow` 读取一致。
- 已知取舍:`第1层/第2层` 保持忠实 token 名不改,因为 layer-1/layer-2 是抽象层叠背景,强行绑定"输入框层"会是误导(那只是 client 自身 CSS 恰好复用了 layer-1)。

