# 扫描系统字体 实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: 使用 superpowers:subagent-driven-development（推荐）或 superpowers:executing-plans 按任务逐条实现。步骤用 `- [ ]` 勾选跟踪。

**Goal:** 在字体下拉中新增「系统字体」来源——通过 `queryLocalFonts()` 枚举本机已装字体，让用户可选任意已安装字体。

**Architecture:** 纯前端改动 `lib/client.js`。新增 `systemFonts` 状态 + 组头「扫描系统字体」按钮 + 每个下拉注入「系统字体」`<optgroup>`；选中的系统字体以 `system:<字体名>` 前缀存储，生成 CSS 时去掉前缀并加引号。零 host 改动、零重启。

**Tech Stack:** 原生 JS（浏览器 bundle）、`window.queryLocalFonts`（Chrome）、现有 localStorage 持久化、`node --check` + Playwright 验证。

> 注意：`lib/client.js` 为 CRLF 行尾，所有编辑的 old_string/new_string 必须用 `\r\n` 换行。改完源文件后必须同步到部署副本 `C:\Users\Administrator\.dsh\profiles\node_modules\dsh-veneer\lib\client.js` 并校验哈希一致。

---

## 文件结构
- 修改：`lib/client.js`（唯一改动文件）
  - 状态区（~119 行）：新增 `systemFonts`、`SYSTEM_FONT_PREFIX`、`SYMBOL_FONT_RE`
  - `resolveFontOverride` / `resolveFontCssValue`（~808-818 行）：识别 `system:` 前缀
  - 新增 `collectSystemFonts` / `collectSystemOptionFamilies` 两个辅助函数
  - `renderFontProperties`（~462-582 行）：扫描按钮 + optgroup 注入
  - `EDITOR_CSS`（~83 行后）：扫描按钮禁用态样式

---

### Task 1: 状态与解析层（`system:` 前缀）

**Files:**
- Modify: `lib/client.js`（状态区 ~119；`resolveFontOverride`/`resolveFontCssValue` ~808-818）

- [ ] **Step 1: 新增状态与常量**

在 `let fontOverrides = new Map();` 之后插入：

```js
		/** systemFonts: 本次会话扫描到的本机字体 family 列表（不持久化）。 */
		let systemFonts = [];
		const SYSTEM_FONT_PREFIX = "system:";
		const SYMBOL_FONT_RE = /^(wingdings|webdings|symbol|mt extra|marlett|segoe ui symbol|segoe ui emoji|segoe mdl2 assets|seg mdl2 assets|hololens mdl2 assets)$/i;
```

- [ ] **Step 2: 改 resolveFontOverride 识别 system 前缀**

把现有 `resolveFontOverride` 改为：

```js
		function resolveFontOverride(override) {
			if (override == null || override === "") return { key: "", raw: null };
			if (FONT_PRESET_BY_KEY.has(override)) return { key: override, raw: null };
			if (typeof override === "string" && override.startsWith(SYSTEM_FONT_PREFIX)) return { key: override, raw: null };
			const preset = FONT_PRESET_BY_VALUE.get(override);
			if (preset) return { key: preset.key, raw: null };
			return { key: "custom", raw: String(override) };
		}
```

- [ ] **Step 3: 改 resolveFontCssValue 输出带引号字体名**

```js
		function resolveFontCssValue(override) {
			const preset = FONT_PRESET_BY_KEY.get(override);
			if (preset) return preset.value;
			if (typeof override === "string" && override.startsWith(SYSTEM_FONT_PREFIX)) {
				return JSON.stringify(override.slice(SYSTEM_FONT_PREFIX.length));
			}
			return String(override);
		}
```

- [ ] **Step 4: 新增两个辅助函数**（放在 `resolveFontCssValue` 之后、`applyFontOverride` 之前）

```js
		function collectSystemFonts() {
			if (typeof window.queryLocalFonts !== "function") {
				return Promise.reject(new Error("unsupported"));
			}
			return window.queryLocalFonts().then((fonts) => {
				const seen = new Set();
				const list = [];
				for (const f of fonts) {
					const family = (f && f.family ? String(f.family) : "").trim();
					if (!family || seen.has(family)) continue;
					if (SYMBOL_FONT_RE.test(family)) continue;
					seen.add(family);
					list.push(family);
					if (list.length >= 300) break;
				}
				list.sort((a, b) => a.localeCompare(b, "zh-Hans-CN"));
				return list;
			});
		}
		function collectSystemOptionFamilies() {
			const set = new Set(systemFonts);
			for (const v of fontOverrides.values()) {
				if (typeof v === "string" && v.startsWith(SYSTEM_FONT_PREFIX)) set.add(v.slice(SYSTEM_FONT_PREFIX.length));
			}
			return Array.from(set).sort((a, b) => a.localeCompare(b, "zh-Hans-CN"));
		}
```

- [ ] **Step 5: 语法校验**

运行：`node --check "C:\Users\Administrator\Desktop\onetwothree\dsh-veneer\lib\client.js"`

预期：exit 0，无输出。

- [ ] **Step 6: 提交**

```bash
git add lib/client.js
git commit -m "feat: system: prefix state + resolve helpers for system fonts"
```

---

### Task 2: 扫描按钮 + optgroup 渲染

**Files:**
- Modify: `lib/client.js`（`renderFontProperties` ~462-582；`EDITOR_CSS` ~83 后）

- [ ] **Step 1: 组头新增「扫描系统字体」按钮**

在 `head.appendChild(resetAll);` 之后插入：

```js
			const scanBtn = document.createElement("button");
			scanBtn.type = "button";
			scanBtn.className = "dsh-veneer-btn dsh-veneer-reset-all-fonts dsh-veneer-scan-fonts";
			scanBtn.textContent = "扫描系统字体";
			scanBtn.title = "读取本机已安装字体（需 Chrome 授权）";
			if (typeof window.queryLocalFonts !== "function") {
				scanBtn.disabled = true;
				scanBtn.title = "当前环境不支持（需 Chrome）";
			}
			scanBtn.addEventListener("click", () => {
				scanBtn.disabled = true;
				scanBtn.textContent = "扫描中…";
				collectSystemFonts().then((list) => {
					systemFonts = list;
					renderProperties();
				}).catch((err) => {
					scanBtn.textContent = "扫描系统字体";
					scanBtn.disabled = false;
					scanBtn.title = (err && err.name === "NotAllowedError") ? "已拒绝授权，可稍后重试" : ((err && err.message) ? err.message : "扫描失败");
				});
			});
			head.appendChild(scanBtn);
```

- [ ] **Step 2: 计算系统字体选项集**

在 `body.className = "dsh-veneer-group-body dsh-veneer-fonts";` 之后、`for (const target of FONT_TARGETS) {` 之前插入：

```js
			const sysFamilies = collectSystemOptionFamilies();
```

- [ ] **Step 3: 注入「系统字体」optgroup**

在预设循环结束（`select.appendChild(option);` 的 `}` 之后）、`const customOpt = ...` 之前插入：

```js
				if (sysFamilies.length > 0) {
					const sysGroup = document.createElement("optgroup");
					sysGroup.label = "系统字体";
					for (const fam of sysFamilies) {
						const sysOpt = document.createElement("option");
						sysOpt.value = SYSTEM_FONT_PREFIX + fam;
						sysOpt.textContent = fam;
						sysGroup.appendChild(sysOpt);
					}
					select.appendChild(sysGroup);
				}
```

- [ ] **Step 4: 新增禁用态 CSS**

在 `.dsh-veneer-reset-all-fonts:hover{...}` 那条 CSS 之后插入：

```js
			".dsh-veneer-scan-fonts:disabled{opacity:.5;cursor:not-allowed}",
```

- [ ] **Step 5: 语法校验**

运行：`node --check "C:\Users\Administrator\Desktop\onetwothree\dsh-veneer\lib\client.js"`

预期：exit 0。

- [ ] **Step 6: 提交**

```bash
git add lib/client.js
git commit -m "feat: scan-system-fonts button + optgroup injection"
```

---

### Task 3: 部署同步 + Playwright 验证

**Files:**
- 部署副本：`C:\Users\Administrator\.dsh\profiles\node_modules\dsh-veneer\lib\client.js`（同步）
- 测试脚本：`C:\Users\Administrator\Desktop\onetwothree\diag_sysfonts.py`（临时）

- [ ] **Step 1: 同步部署副本并校验哈希**

```powershell
Copy-Item -Force 'C:\Users\Administrator\Desktop\onetwothree\dsh-veneer\lib\client.js' 'C:\Users\Administrator\.dsh\profiles\node_modules\dsh-veneer\lib\client.js'
(Get-FileHash '...\client.js').Hash   # 两侧应一致
```

- [ ] **Step 2: 写 Playwright 验证脚本**（用 `add_init_script` 注入 `queryLocalFonts` 桩，确定性测试）

```python
# -*- coding: utf-8 -*-
import sys, json
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
from playwright.sync_api import sync_playwright
URL = "http://127.0.0.1:3080"
STUB = "window.queryLocalFonts = () => Promise.resolve([{family:'Microsoft YaHei'},{family:'Arial'},{family:'Wingdings'},{family:'Symbol'}]);"
out = {}
with sync_playwright() as p:
    b = p.chromium.launch(channel="chrome", headless=True)
    # 场景1：支持 queryLocalFonts
    ctx = b.new_context()
    ctx.add_init_script(STUB)
    pg = ctx.new_page()
    errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(URL, wait_until="domcontentloaded")
    pg.wait_for_selector(".dsh-veneer-toggle")
    pg.click(".dsh-veneer-toggle")
    pg.wait_for_selector(".dsh-veneer-panel")
    for t in pg.query_selector_all(".dsh-veneer-tab"):
        if "字体" in (t.inner_text() or ""): t.click(); break
    pg.wait_for_selector(".dsh-veneer-font-select")
    scan = pg.query_selector(".dsh-veneer-scan-fonts")
    out["scan_enabled"] = not scan.is_disabled()
    scan.click()
    pg.wait_for_timeout(500)
    sel = pg.query_selector_all(".dsh-veneer-font-select")[0]
    opts = sel.query_selector_all("option")
    names = [o.inner_text() for o in opts]
    out["has_optgroup"] = len(sel.query_selector_all("optgroup")) > 0
    out["system_names"] = [o.inner_text() for o in sel.query_selector_all("optgroup option")]
    # 过滤符号字体：Wingdings/Symbol 不应出现
    out["symbol_filtered"] = ("Wingdings" not in names) and ("Symbol" not in names)
    # 选中系统字体
    sel.select_option("system:Microsoft YaHei")
    pg.wait_for_timeout(350)
    css = pg.evaluate('''() => { const t = document.querySelector('style[data-plugin-css="dsh-veneer/theme"]'); return t ? t.textContent : ''; }''')
    out["css_system_font"] = ('font-family: "Microsoft YaHei"' in css)
    # 刷新后选中态保留（含未重扫时回补）
    pg.reload(wait_until="domcontentloaded")
    pg.wait_for_selector(".dsh-veneer-toggle")
    pg.click(".dsh-veneer-toggle")
    pg.wait_for_selector(".dsh-veneer-panel")
    for t in pg.query_selector_all(".dsh-veneer-tab"):
        if "字体" in (t.inner_text() or ""): t.click(); break
    pg.wait_for_selector(".dsh-veneer-font-select")
    sel2 = pg.query_selector_all(".dsh-veneer-font-select")[0]
    out["persisted_value"] = sel2.input_value()
    out["persisted_backfill"] = any(o.get_attribute("value") == "system:Microsoft YaHei" for o in sel2.query_selector_all("option"))
    out["errs_scene1"] = errs
    # 场景2：不支持 queryLocalFonts → 按钮置灰
    ctx2 = b.new_context()
    pg2 = ctx2.new_page()
    pg2.goto(URL, wait_until="domcontentloaded")
    pg2.wait_for_selector(".dsh-veneer-toggle")
    pg2.click(".dsh-veneer-toggle")
    pg2.wait_for_selector(".dsh-veneer-panel")
    for t in pg2.query_selector_all(".dsh-veneer-tab"):
        if "字体" in (t.inner_text() or ""): t.click(); break
    pg2.wait_for_selector(".dsh-veneer-font-select")
    s2 = pg2.query_selector(".dsh-veneer-scan-fonts")
    out["unsupported_disabled"] = s2.is_disabled()
    out["unsupported_title"] = s2.get_attribute("title")
    b.close()
print(json.dumps(out, ensure_ascii=False, indent=1))
```

- [ ] **Step 3: 运行验证**

运行：`python diag_sysfonts.py`（工作目录 `C:\Users\Administrator\Desktop\onetwothree`）

预期输出关键字段：`scan_enabled=True`、`has_optgroup=True`、`system_names=['Arial','Microsoft YaHei']`、`symbol_filtered=True`、`css_system_font=True`、`persisted_value='system:Microsoft YaHei'`、`persisted_backfill=True`、`errs_scene1=[]`、`unsupported_disabled=True`、`unsupported_title` 含「需 Chrome」。

- [ ] **Step 4: 提交并推送**

```bash
git add lib/client.js
git commit -m "test: verify system-fonts scan, selection, persistence, fallback"
$env:GIT_TERMINAL_PROMPT='0'; git push origin master
```
