# Host Settings Storage Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在不丢失现有主题和图片的前提下，为 dsh-veneer 增加 DSH Host Settings 主存储与 localStorage 自动降级。

**Architecture:** Host 注册专属 `dsh-veneer` 设置 Schema；client 通过可选 `settingsScope` 读写。纯存储决策抽到 `lib/theme-storage.js`，所有写入先落 localStorage 快照，再尝试 Host，旧数据迁移只复制不删除。

**Tech Stack:** Node.js ESM、DSH rc.8 Settings API、Cordis、Schemastery、Node test、Playwright

---

### Task 1: 纯存储协调器

**Files:**
- Create: `lib/theme-storage.js`
- Create: `test/theme-storage.test.mjs`

- [ ] 写失败测试：Host 合法值优先，并刷新本地快照。
- [ ] 写失败测试：Host 为空时迁移合法 `v:2` localStorage，且不删除旧值。
- [ ] 写失败测试：Host 不可用或数据非法时回退 localStorage。
- [ ] 写失败测试：保存顺序为 localStorage 先、Host 后，Host 失败仍保留本地值。
- [ ] 写失败测试：重置清本地并向 Host 写 `null`。
- [ ] 运行 `node --test test/theme-storage.test.mjs`，确认因模块缺失而失败。
- [ ] 实现 `parseThemeSnapshot()`、`selectInitialTheme()`、`createThemeStorage()` 的最小代码。
- [ ] 重跑测试，预期全部通过。

### Task 2: Host 设置 Schema

**Files:**
- Modify: `lib/index.js`
- Modify: `package.json`
- Create: `test/host-settings.test.mjs`

- [ ] 写失败测试：`apply()` 在 settings 服务出现时注册 `settingsNamespace("dsh-veneer")`。
- [ ] 写失败测试：settings 服务缺失时不抛错，现有 Web 路由仍注册。
- [ ] 运行测试并确认失败原因是尚未注册 Schema。
- [ ] 增加 `@deepseek-ai/dsh-settings`、`@deepseek-ai/schemastery` peer dependency。
- [ ] 使用 `ctx.inject(["settings"], ...)` 注册只含 `theme` JSON 字段的可选 Schema。
- [ ] 重跑 Host 测试与 `node --check lib/index.js`。

### Task 3: Browser settingsScope 适配

**Files:**
- Modify: `package.json`
- Modify: `lib/client.js`
- Create: `test/client-storage-integration.test.mjs`

- [ ] 写失败测试：client 在有 `settingsScope` 时绑定 `dsh-veneer` 命名空间并采用 Host 快照。
- [ ] 写失败测试：没有 `settingsScope` 时仍按原有 localStorage 路径启动。
- [ ] 写失败测试：旧 localStorage 首次载入后调用 `scope.set("theme", snapshot)`。
- [ ] 写失败测试：Host 保存拒绝时主题仍留在 localStorage，且产生用户可见非阻塞错误状态。
- [ ] 更新 `dsh.client.inject`，将 `@deepseek-ai/dsh-client-ui-settings` 声明为客户端依赖；运行实机前验证该依赖在官方 web bundle 中存在。
- [ ] 将 `saveTheme()`、`loadTheme()`、`resetTheme()` 接入 `createThemeStorage()`，保持现有调用点和防抖不变。
- [ ] 重跑集成测试、AI 颜色测试和语法检查。

### Task 4: 升级与降级回归

**Files:**
- Modify: `test/veneer-skin-check.py`
- Modify: `README.md`
- Create: `docs/change-reports/2026-08-21-host-settings-storage.md`

- [ ] 增加回归：预置 0.7.1 `v:2` localStorage，刷新后主题生效并写入 Host。
- [ ] 增加回归：模拟 Host 设置只读/失败，编辑和刷新仍使用本地快照。
- [ ] 增加回归：重置、导出、导入语义保持不变。
- [ ] README 说明 Host 主存储、localStorage 降级、图片目录和跨版本恢复边界。
- [ ] 记录迁移、回滚和已知限制。

### Task 5: 版本与完整验证

**Files:**
- Modify: `package.json`

- [ ] 将功能版本从 `0.7.1` 升到 `0.8.0`。
- [ ] 运行 `node --check lib/client.js lib/index.js lib/theme-storage.js`（逐文件执行）。
- [ ] 运行 `node --test test/*.test.mjs`，预期 0 失败。
- [ ] 运行 `node tools/validate_templates.cjs`，预期全部模板有效。
- [ ] 在运行中的 DSH 执行全部 Python Playwright 回归，预期 0 pageerror、0 失败。
- [ ] 检查 `git diff --check`、README 与实际行为一致。
- [ ] 提交时只暂存本功能文件，commit message 标明 `v0.7.1 -> v0.8.0`；未经用户确认不推送。
