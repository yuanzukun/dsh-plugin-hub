# Veneer 字体选择 v2 改造计划

日期：2026-08-19  |  状态：已完成并验证  |  提交：d967b59

## 1. 问题描述
1. 选择一个字体后，下拉列表的候选项全部消失，无法再选择其他字体。
2. 列表里显示的是原始 CSS 字体栈（如 `-apple-system, BlinkMacSystemFont, "Segoe UI", ...`），用户无法辨识。

## 2. 根因分析
- 控件用的是 `<input list=datalist>`。浏览器对 datalist 只显示**包含当前输入内容**的候选项。
- 选中后输入框的值是整条 CSS 栈，没有任何候选项包含这一整串 → 下拉为空。
- 候选列表的 `value` 本身就是 CSS 栈，缺少「名称」层 → 用户看到乱码。

## 3. 设计目标（逻辑无问题的写法）
- 字体必须结构化：`{ key, name, value }`，name 是给人看的，value 是写进 CSS 的。
- 选择控件必须**永远展示全部选项**，不受输入/过滤影响 → 用原生 `<select>`，弃用 datalist。
- 存储层只存 key（或自定义原文），生成 CSS 时再映射 → 数据与展示解耦。
- 旧数据自动迁移：旧存的 CSS 栈能匹配预设 → 显示预设名；不能匹配 → 进「自定义」。

## 4. 实施步骤
1. `FONT_PRESETS` 22 项改为 `{key, name, value}` 对象 + `FONT_PRESET_BY_KEY`/`FONT_PRESET_BY_VALUE` 两个映射表。
2. `renderFontProperties` 重写：每个区域一个 `<select>`（首项「默认（不修改）」/「跟随全局（不修改）」+ 22 预设 + 「自定义…」），选中「自定义…」才显示文本框。
3. 新增 `resolveFontOverride`（key↔名称↔值解析、旧数据迁移）与 `resolveFontCssValue`（key→CSS 栈）。
4. `buildThemeCss` 改用 `resolveFontCssValue` 输出字体栈。
5. 新增 `.dsh-veneer-font-select` 样式；保留每卡「重置」与「重置全部」。
6. `node --check` 语法校验 → 同步到部署副本（哈希一致）→ Playwright 功能验证。

## 5. 验证结果（Playwright 实测）
- 5 个区域 select，各 24 项，名称全部为中文/可读名，无原始 CSS 栈。
- 选中「微软雅黑」→ 切换「楷体 KaiTi」，选项始终 24 个，CSS 正确写入。
- 「自定义…」输入 `Georgia, serif` 正常应用；清空恢复默认。
- 刷新后选择保留（存储 key，回显中文名），无页面报错。

## 6. 涉及文件
- `lib/client.js`（唯一改动；已同步 `~/.dsh/profiles/node_modules/dsh-veneer/lib/client.js`）