# 2026-08-21 主题持久化演进：DSH Host Settings 主存储（v0.7.1 → v0.8.0）

## 问题

主题只存在浏览器 `localStorage`：Harness 更新、浏览器清理缓存或换机后，皮肤
直接丢失。DSH 官方提供公开设置契约（`@deepseek-ai/dsh-settings` 的
`settingsNamespace()` + `ctx.settingsScope`），可用于把主题存进 Host Settings
（`~/.dsh/profiles/.../settings.yaml`），与 Harness 版本共存，更新不丢。

## 方案

Host Settings 命名空间 `dsh-veneer`（唯一字段 `theme`）作为主存储，
`localStorage` 保留为兼容快照：

1. **读取优先级**：Host 合法 → Host 优先并刷新快照；Host 空 → 仅首次 ready
   快照（boot）迁移旧本地主题一次（只复制不删除）；Host 不可用 / 只读 / 非法
   → 本地兜底且不覆盖 Host。
2. **写入双写**：先同步写 `localStorage` 草稿，再异步写 Host；成功确认后将快照
   标记为 `hostManaged`。Host 写失败 / 只读 / 冲突时按官方 recovery 契约回到 Host
   权威版本并给出非阻塞提示，插件 / 图片 / AI 路由不失活。
3. **重置语义**：使用 `settingsScope.unset("theme")` 清空 Host 字段（官方
   "清空字段"语义：settings.yaml 删除该键、回落到组合层），同时删除本地快照。
   旧实现写 `null` 会留一个空键，语义与 `unset` 不同，已修正。
4. **运行期空 Host 不回迁**：只有未标记的旧版 v2 快照可在 boot 迁移；运行期
   只把真实的“有主题 → 空主题”视为 reset，并清理每个在线客户端的本地快照。
   重复空快照不会误清默认皮肤，离线客户端重启也不会把旧主题写回 Host。

## 关键改动

- `lib/theme-storage.js`（新增）：纯数据解析、规范化、读写协调与迁移决策，
  可脱离浏览器 / DSH 单测。
- `lib/index.js`：`ctx.inject(["settings"])` + `settingsNamespace("dsh-veneer")`
  + `z.object({ theme: z.any() })` 注册；settings 为可选依赖，缺失时插件完整
  运行。
- `lib/client.js`：settingsScope adapter 接入读写订阅；重置改为 `unset`；
  空 Host 迁移仅 boot 一次；运行期 Host 清空同步清本页 UI（清 maps +
  `applyThemeCss("")`），绝不写回；通过 Cordis 动态可选服务注入支持
  `settingsScope` 晚到/provider reload，并在 scoped effect 中释放订阅。
- `package.json`：`version` 0.7.1 → 0.8.0；新增 `@deepseek-ai/dsh-settings` /
  `@deepseek-ai/schemastery` peerDependencies；`test` script 带上
  `--experimental-test-module-mocks`（Node 24 起 `mock.module` 需该 flag）。

## 测试

- 单测覆盖 theme-storage、client-storage-integration、host-settings 三个新增测试
  文件，以及迁移仅一次、运行期空 Host 不写回、他页 reset 清 UI、非法 Host
  不覆盖、动态服务晚到/dispose、写入 recovery 与双写顺序。
- `test/install-script-check.ps1` 隔离验证 BOM、缺依赖前置失败、官方管理目录
  零覆盖、离线复制与 SHA256。
- 实机 E2E：受控重启 `dsh web` 后，`settings.describe` 已注册 `dsh-veneer`；
  23/23 通过，覆盖旧本地迁移与 `hostManaged:true`、双写落盘、reset unset、
  只读状态下 save/reset recovery、独立浏览器 reset 后不复活、外部 RPC、
  无 pageerror，以及 live Host/YAML 原值恢复。

## 版本与兼容

- 版本号：v0.7.1 → v0.8.0（功能演进，`package.json` 同步；本项目无 index.html，
  无 `?v=` 参数）。
- 兼容：保留 `dsh-veneer.theme.v1` 键名与旧版 CSS / `v:2` / `schemaVersion:3`
  解析；迁移只复制不删除；卸载再装 / Host 服务未挂载时退回 `localStorage`。
  Harness 必须提供静态导入的 `@deepseek-ai/dsh-settings` 与
  `@deepseek-ai/schemastery` 模块；zip 安装器会在复制前检查，缺失时要求先更新 Harness。
