# Veneer v0.5.0：AI 主题接入 Harness 统一 LLM 运行时

日期：2026-08-20  |  状态：已完成并验证  |  版本：0.4.1 → 0.5.0  |  提交：v0.5.0（本次提交）

## 1. 目标

- 「AI 主题」标签页的模型下拉与 Harness 对话一致（同一模型目录）。
- 生成请求走 `ctx.llm` 统一运行时，复用对话凭据，用户零 API Key 配置。
- 不带 `sessionId` 的一次性 completion：不进对话历史、不阻塞主对话。

## 2. 变更清单

| 文件 | 变更 | 责任 | 副作用 | 测试 |
|---|---|---|---|---|
| `lib/index.js` | 新增 `GET /api/dsh-veneer/ai/models`；`POST /ai/generate` 在 apiKey 为 null 时走 `ctx.llm.stream` + `BlockAssembler`；新增 `llmFailureText` 错误映射；`inject` 增加 `llm`、`agentDefaultModel` | 模型目录 + 统一运行时调用 | 保留直连 DeepSeek 兜底（显式 apiKey 才走）与 SSRF 防护 | node --check；AI 测试 mock 前端路由 |
| `lib/client.js` | 删除 API Key 输入；新增 provider/model 两级下拉（`.dsh-veneer-ai-select`）；`aiFormState` 增加 provider/model；请求体改为 `{provider, model, prompt, locked}`；Veneer 面板字体选择器补 `" *"` 修复文字颜色不生效；**整体移除吸管取色功能**（`.dsh-veneer-eye`、`runEyedropper`、`showSurfacePicker`、匹配高亮动画及 picker 浮层 CSS 全部删除） | 零配置模型选择 + 功能精简 | 面板字体颜色修复（`system-fonts-check.py` 覆盖） | ai-theme-check.py、system-fonts-check.py |
| `test/ai-theme-check.py` | 重写为 v0.5.0 契约：mock 模型目录、断言两级下拉与默认模型、请求体无 apiKey/baseUrl、401 字符串错误格式 | 端到端回归 | — | 全部 PASS |
| `test/system-fonts-check.py` | 增加 Veneer 面板自身文字颜色生效的回归断言 | 字体颜色 bug 修复验证 | — | 全部 PASS |
| `test/veneer-skin-check.py` | 由 `veneer-skin-eyedropper-check.py` 重命名并重写：删除吸管相关断言，保留面板结构 / 导出导入 / 字体选择器 / 退出同步 / 无 pageerror | 回归测试同步 | 旧吸管测试文件已删除 | 32 项全部 PASS |
| `README.md` | AI 段落改为「模型与凭据说明」，架构段更新 | 文档同步 | — | — |
| `package.json` | 0.4.1 → 0.5.0 | 版本递增（功能增强 +0.1.0） | — | — |

## 3. API 契约核实（对照 `@deepseek-ai/dsh-llm` 类型定义）

- `ctx.llm.stream(options: GenerateOptions)`：`provider`、`model`、`messages`、`system`、`maxTokens`、`signal` 字段全部匹配。
- `BlockAssembler.push/ blocks()/ finish`：`FinishReason.kind` 枚举 `stop | tool-calls | max-tokens | aborted | error`，代码对 error/aborted → 错误映射、max-tokens → 422、其余走 blocks，正确。
- `createUserMessage({content, source:{kind:"plugin", plugin}})`：签名匹配，`plugin` source 合法。
- `ctx.agentDefaultModel.currentSelection(): ModelSelection{provider, model, reasoningEffort?}`：代码取 provider/model，正确。
- `listProviders()` 同步返回 `{id,name}`；`listModels(provider)` 异步返回 `{id,name}`；目录接口对单个 provider 失败有 try/catch 隔离。

## 4. 验证结果（实测）

- `node --check`：source 与部署副本均通过。
- `ai-theme-check.py`：29 项全部 PASS（模型下拉/默认模型/请求体/预览不落库/应用落库/放弃恢复/401/样式强调色/模板库/回归）。
- `veneer-skin-check.py`：32 项全部 PASS（吸管取色功能已移除，测试同步重命名，含无吸管按钮/无 picker 浮层负向断言）。
- `system-fonts-check.py`：含 Veneer 面板字体颜色生效，全部 PASS。
- `background-image-position-check.py`、`import-security-check.py`：全部 PASS。
- `sync.ps1`：部署后 SHA256 全部 MATCH，未重启 DSH（仅刷新浏览器）。

## 5. 同批附加变更

- **自定义字体名（DIY 方式）**：每个字体卡片下拉新增「✎ 自定义字体名…」，选中后出现输入框，输入本机字体名即时生效（`quoteFontFamily` 自动加引号、含逗号字体栈原样、已有引号先剥再引）；非法输入标红不应用，清空失焦复位；刷新后持久化恢复。
- **面板 UI 精简**：删除 header「Design tokens / 编辑中」标记、字体页「字体设置 / 重置字体设置 / 扫描系统字体」及对应死 CSS（`.dsh-veneer-reset-all-fonts`、`.dsh-veneer-scan-fonts:disabled`）；README 功能表同步（自定义字体名 / 重置语义）。

## 6. 已知局限（非阻塞）

1. **后端真实 `ctx.llm` 调用未被端到端覆盖**：Playwright mock 了 `/ai/models` 与 `/ai/generate`，后端真实路径只过 `node --check` 语法检查。真实模型调用需在具备凭据的浏览器里手动点一次「生成」验证。
2. **`inject` 硬依赖**：声明 `llm`/`agentDefaultModel` 要求 harness 部署包含 `@deepseek-ai/dsh-llm` 与 `@deepseek-ai/dsh-agent-default-model`（当前 profiles/node_modules 均存在）。未来精简部署若移除这两包，插件会加载失败而非优雅降级。
3. **模型目录缓存**：前端面板首次打开时拉取一次并缓存，改动 Harness 模型设置后需刷新页面才能反映到 AI 下拉。
4. **代码风格小瑕疵**：`client.js` 中新增的 4 条 AI 下拉 CSS 字符串缩进比相邻行少一个 tab（不影响功能，纯可读性）。
