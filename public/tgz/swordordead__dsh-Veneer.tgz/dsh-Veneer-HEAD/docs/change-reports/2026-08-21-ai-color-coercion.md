# 2026-08-21 修复「AI 输出了非法颜色」（v0.7.0 → v0.7.1）

## 问题

AI 生成主题时，模型经常省略 `#` 前缀输出颜色（如 `0a0a1f`），或输出
`hsl(...)` / `oklch(...)` 等合法但非 hex 的 CSS 颜色。旧实现的
`recognizedColor()` 只接受 19 个命名色 + `#hex` + `rgb/rgba`，其余一律判为
非法，`parseAiTheme()` 整单抛错「AI 输出了非法颜色」。

## 修复（lib/client.js）

1. **`normalizeHex()`**：接受带 / 不带 `#` 的 3/6/8 位 hex（`0a0a1f` →
   `#0a0a1fff`），统一输出小写，与 named / rgba / canvas 各路径的规范形式一致。
2. **`recognizedColor()`**：新增纯 hex 串识别（省略 `#` 前缀）；修复
   「`#` 开头但非合法 hex 被当 hex 处理」的隐患。
3. **`toAlpha()`**：百分比 alpha 修复 —— `rgba(0,0,0,50%)` 现在解析为 0.5
   （此前 `parseFloat` 得 50，50×255 被 clamp 成 255 = 完全不透明）。`toHex` /
   `toAlpha` 从 `normalizeColor` 内联提升为模块级工具函数，供 canvas 路径复用；
   `toHex` 对 NaN/Infinity 兜底返回 `00`，防止 `"NaN"` 字符串混进 CSS。
4. **`coerceColor()`（新增，AI 主题专用）**：严格识别失败时交给浏览器
   Canvas `fillStyle` 解析任意合法 CSS 颜色（hsl/hwb/lab/lch/oklch/color()）
   并归一化为 `#RRGGBBAA`。每次解析前 `clearRect` 清空 1×1 缓冲，避免复用
   canvas 时 source-over 合成把连续半透明色互染、alpha 被错误拉满成 255。
   非法 / 夹带 CSS 的赋值被 Canvas 静默忽略（fillStyle 不变）→ 返回 null，
   安全上等价于严格拒绝，不注入任意字符串。
5. **`parseAiTheme()`**：surfaces / fonts 两处颜色校验改用 `coerceColor()`。
6. **`parseSurface()` hex 正则收紧**：只捕获 3/6/8 位合法 hex（带 `\b`
   边界），4/5/7 位不再被 `{3,8}` 贪婪捕获，落回 `recognizedColor` → null →
   该 surface 颜色置空丢弃，杜绝导入皮肤时静默变黑。

## 行为刻意收紧（皮肤导入路径）

- CSS 4 位 hex `#RGBA`（如 `#f008`）：旧实现的 `{3,8}` 会贪婪捕获第 4 位，
  实测结果是静默变黑（`#000000ff`）；现在皮肤导入路径一律丢弃（surface
  颜色置空）；AI 路径则由 canvas 接受并归一化为 `#ff000088`（浏览器测试已证）。
- 5 位 / 7 位 hex（如 `#12345`、`#1234567`）：浏览器本就视为非法颜色，旧实现
  同样静默变黑，现在**一律丢弃**。只有 3/6/8 位合法 hex 会被 surface 导入
  路径保留。

## 安全边界保持

- `recognizedColor` 仍是皮肤导入的严格安全边界，未被放宽；
- `coerceColor` 依赖浏览器「非法值赋值被忽略」的语义，夹带 CSS 的字符串
  （`red; background:url(x)`、`url(javascript:…)`）一律返回 null，不会进入样式表。

## 测试

- 新增 `test/ai-colors.test.mjs`（node:test，mock dsh 模块加载器 + 模拟
  Canvas 颜色解析语义，`fillRect` 做真实 source-over 合成以复现 canvas 复用
  污染）。22 个用例覆盖：裸 hex、3/6/8 位 hex、大写 hex 归一化、4 位 `#RGBA`
  （严格拒绝 / canvas 接受）、5/7 位 hex 全路径拒绝、`parseSurface` 3/6/8
  保留 4/5/7 丢弃、百分比 alpha、canvas 复用污染回归、hsl 宽容解析、注入串
  拒绝、无 canvas 时优雅降级、`parseAiTheme` 全流程（含 opacity 控制 alpha）。
- 新增 `test/ai-colors.browser.test.mjs`（Playwright + 真实浏览器引擎，默认 Chromium）：把
  真实 `client.js` 工厂载入 about:blank，验证 `oklch()` / `hwb()` / `lab()` /
  `color(display-p3)` 等 CSS Color 4 颜色经 canvas 正确归一化，并确认
  `#12345`、注入串在真实引擎中被拒、`parseSurface` 行为与单测一致。
  Playwright 未安装时自动跳过，不影响 `node --test` 主流程。
- `node --test test/*.test.mjs` 23/23 通过（含既有 llm-errors 7 个单测）。

## 版本

`package.json` 0.7.0 → 0.7.1（bugfix）。
