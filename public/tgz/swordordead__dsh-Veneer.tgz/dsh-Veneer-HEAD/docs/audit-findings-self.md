# 自查发现(待与独立审查合并)

## [HIGH] B1 size 字段多值坍缩(数据破坏)
- 位置:fieldRow size 分支 (client.js:179-182) + STYLE_FIELDS padding/margin/border-radius/border-width
- 问题:getPropertyValue 对四边不同的 padding/margin 返回 '10px 20px 30px 40px';parseFloat 只取第一个数;用户一改该字段,onInput 写回单值 '15px',其余三边丢失。
- 修复:检测多值(空格分隔>1 个 token)时,用 4 个独立输入框,或至少警告/保留原值。

## [MEDIUM] B2 状态不同步:面板退出按钮不派发 dsh-veneer:mode
- 位置:exitBtn click handler (client.js:311) vs sidebar onClick (client.js:412-413)
- 问题:侧栏按钮退出会 dispatchEvent 同步激活态;面板「退出」只调 toggleEdit() 不派发事件,侧栏 🎨 按钮停留高亮(视觉与真实状态不符)。
- 修复:把 dispatchEvent 挪进 toggleEdit() 内部,或 exitBtn 也派发事件。

## [LOW] B3 normalizeColor 边界误判为黑色
- 位置:normalizeColor (client.js:197-207)
- 问题:transparent(rgba(0,0,0,0))、现代语法 rgb(76 141 255 / .85)、8位hex #rrggbbaa 全部返回 #000000;透明元素在面板里显示黑色,改色从黑色起步。
- 修复:透明返回空/标记;支持现代语法与 8 位 hex。

## [LOW] B4 hover 面板内部元素会被高亮
- 位置:onPointerOver 无 panel.contains 守卫 (client.js:126-133),而 onPointerDown 有
- 问题:鼠标悬停 Inspector 面板内的输入框/按钮时,可编辑高亮虚线框也会套上去(纯视觉干扰)。
- 修复:onPointerOver 也加 panel.contains 检查。

## [LOW] B5 主题颜色输入丢失 alpha 通道
- 位置:color picker 只支持 6 位 hex (input type=color)
- 问题:半透明颜色(如 rgba(0,0,0,.5))经 normalizeColor 转成纯色 #000000 显示,改色时丢失透明度。
- 修复:接受 8 位 hex 或提供透明度控件;文档说明。