﻿# pack-release.ps1 — 构建可分发的 dsh-veneer 发布包
#
# 用法：powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\pack-release.ps1
# 产物：release\dsh-veneer-v<version>.zip（插件本体 + install.bat + install.ps1 + 使用说明.txt）
# 发布前请先保证版本号已按规则递增（package.json 的 version 即 zip 文件名）。
#
# 打包内容只包含运行期必需文件，不包含 .git / test / docs / 截图等开发产物。

param(
    [string]$OutDir = "release"
)

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location -LiteralPath $root

# ── 1. 读取版本号 ──
$pkg = Get-Content -LiteralPath "package.json" -Raw | ConvertFrom-Json
$version = $pkg.version
if ([string]::IsNullOrWhiteSpace($version)) {
    Write-Host "package.json 缺少 version 字段" -ForegroundColor Red
    exit 1
}
Write-Host "==> dsh-veneer v$version" -ForegroundColor Cyan

# ── 2. 语法检查 ──
Write-Host ""
Write-Host "==> node --check ..."
foreach ($f in @("lib\client.js", "lib\index.js", "lib\theme-storage.js", "lib\llm-errors.js")) {
    node --check $f
    if ($LASTEXITCODE -ne 0) {
        Write-Host "  x $f syntax check FAILED" -ForegroundColor Red
        exit 1
    }
    Write-Host "  OK $f"
}

# ── 3. 组装临时目录（只含运行期必需文件）──
$stage = Join-Path $env:TEMP ("dsh-veneer-pack-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $stage | Out-Null
Write-Host ""
Write-Host "==> staging ..."
$items = @("package.json", "cordis.patch.yml", "lib", "install.bat", "install.ps1", "使用说明.txt")
foreach ($rel in $items) {
    if (Test-Path -LiteralPath (Join-Path $root $rel)) {
        Copy-Item -LiteralPath (Join-Path $root $rel) -Destination $stage -Recurse -Force
        Write-Host "  + $rel"
    } else {
        Write-Host "  ! missing: $rel" -ForegroundColor Yellow
    }
}

# ── 4. 压缩 ──
$outAbs = Join-Path $root $OutDir
New-Item -ItemType Directory -Path $outAbs -Force | Out-Null
$zip = Join-Path $outAbs ("dsh-veneer-v{0}.zip" -f $version)
if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }
Compress-Archive -Path (Join-Path $stage "*") -DestinationPath $zip -CompressionLevel Optimal
Remove-Item -LiteralPath $stage -Recurse -Force

Write-Host ""
Write-Host "打包完成: $zip" -ForegroundColor Green
Write-Host ("SHA256  : " + (Get-FileHash -Algorithm SHA256 -LiteralPath $zip).Hash)
