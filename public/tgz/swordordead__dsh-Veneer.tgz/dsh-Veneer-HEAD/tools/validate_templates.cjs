// Validate TEMPLATES / BG_GROUPS / STYLE_TOKENS data from client.js by
// extracting the literal blocks and eval'ing them in isolation.
const fs = require('fs');
const src = fs.readFileSync('lib/client.js', 'utf8');

function extract(name) {
  const start = src.indexOf('const ' + name + ' =');
  if (start < 0) throw new Error(name + ' not found');
  const brace = src.indexOf('[', start);
  let depth = 0, i = brace, inStr = null;
  for (; i < src.length; i++) {
    const ch = src[i];
    if (inStr) {
      if (ch === '\\') { i++; continue; }
      if (ch === inStr) inStr = null;
      continue;
    }
    if (ch === '"' || ch === "'" || ch === '`') { inStr = ch; continue; }
    if (ch === '[' || ch === '{') depth++;
    else if (ch === ']' || ch === '}') { depth--; if (depth === 0) break; }
  }
  return src.slice(start, i + 1);
}

const bgGroups = eval(extract('BG_GROUPS') + '; BG_GROUPS');
// STYLE_TOKENS is `new Set([...])`; extract between `= new Set(` and the matching `);`
const stStart = src.indexOf('const STYLE_TOKENS = new Set(');
const stBrace = src.indexOf('[', stStart);
let depth = 0, i = stBrace, inStr = null;
for (; i < src.length; i++) {
  const ch = src[i];
  if (inStr) {
    if (ch === '\\') { i++; continue; }
    if (ch === inStr) inStr = null;
    continue;
  }
  if (ch === '"' || ch === "'" || ch === '`') { inStr = ch; continue; }
  if (ch === '[' || ch === '{') depth++;
  else if (ch === ']' || ch === '}') { depth--; if (depth === 0) break; }
}
const styleTokens = eval('Array.from(new Set(' + src.slice(stBrace, i + 1) + '))');
const templates = eval(extract('TEMPLATES') + '; TEMPLATES');

const surfaceTokens = new Set();
for (const g of bgGroups) for (const s of g.surfaces) surfaceTokens.add(s.token);
const editable = new Set([...surfaceTokens, ...styleTokens]);

let errors = [];
const hexOk = (v) => /^#([0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(v);

for (const t of templates) {
  if (!Array.isArray(t.themeOverrides) || !Array.isArray(t.fontOverrides) || !Array.isArray(t.fontColors)) {
    errors.push(t.name + ': 结构缺数组'); continue;
  }
  for (const [token, value] of t.themeOverrides) {
    if (!editable.has(token)) errors.push(t.name + ': 未知 token ' + token);
    if (typeof value !== 'string' || value === '') errors.push(t.name + ': ' + token + ' 值非法');
  }
  for (const [key, stack] of t.fontOverrides) {
    if (typeof stack !== 'string' || stack === '') errors.push(t.name + ': 字体栈非法 ' + JSON.stringify(stack));
  }
  for (const [key, color] of t.fontColors) {
    if (!hexOk(color)) errors.push(t.name + ': 字体色非法 ' + color);
  }
}

console.log('BG_GROUPS tokens:', surfaceTokens.size, '| STYLE_TOKENS:', styleTokens.length, '| templates:', templates.length);
if (errors.length) { console.log('ERRORS:'); errors.forEach(e => console.log(' -', e)); process.exit(1); }
console.log('ALL TEMPLATES VALID');
