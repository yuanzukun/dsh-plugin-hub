/**
 * Host-half smoke test with a mock cordis context.
 *
 * Exercises the full crystallization path without a live DSH host:
 *   1. a successful 6-call turn with one failed step fires complex+recovered
 *   2. the (mocked) reviewer LLM answers VERDICT: SAVE
 *   3. the skill is parsed, persisted, and registered into the mock catalog
 *   4. a failed turn is never reviewed (unresolved failures never crystallize)
 *   5. RPC list/get/remove round-trip, including file deletion
 *
 * Run: node test/smoke.mjs
 */
import { existsSync, readFileSync, readdirSync, rmSync, unlinkSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { apply } from '../plugin.mjs'

const PLUGIN_DIR = join(dirname(fileURLToPath(import.meta.url)), '..')
const GENERATED_DIR = join(PLUGIN_DIR, 'generated')
const RUNTIME_CONFIG_FILE = join(PLUGIN_DIR, 'runtime-config.json')
const assert = (cond, msg) => {
  if (!cond) {
    console.error(`FAIL: ${msg}`)
    process.exit(1)
  }
  console.log(`ok - ${msg}`)
}

const registered = new Map()
let llmCalls = 0
let lastSystemPrompt = ''
const ctx = {
  logger: { info: () => {}, warn: (m) => console.error(`[plugin warn] ${m}`) },
  skills: {
    register(def) {
      registered.set(def.name, def)
      return () => registered.delete(def.name)
    },
  },
  llm: {
    async *stream(options) {
      llmCalls++
      lastSystemPrompt = options && typeof options.system === 'string' ? options.system : ''
      yield {
        type: 'text-delta',
        text: [
          'VERDICT: SAVE',
          'NAME: smoke-test-workflow',
          'DESCRIPTION: Smoke test skill',
          '---',
          '# Smoke Test Workflow',
          '',
          '## When to Use',
          'Only during smoke tests.',
          '',
          '## Procedure',
          '1. Nothing to do.',
          '',
          '## Pitfalls',
          'None.',
          '',
          '## Verification',
          'This file exists.',
        ].join('\n'),
      }
      yield { type: 'finish', reason: { kind: 'completed' } }
    },
  },
  connection: { rpc: { handle(_channel, handler) { ctx._rpc = handler } } },
  _handlers: {},
  on(event, fn) {
    ctx._handlers[event] = fn
  },
}

apply(ctx, { minToolCalls: 5, minPatternOccurrences: 3, llmProvider: 'mock', llmModel: 'mock' })
assert(typeof ctx._rpc === 'function', 'registers the /skill-evolution RPC handler')

const session = { id: 'smoke-session' }
const emit = (type, data) => ctx._handlers['session/event'](session, { type, data })

// --- turn 1: six tool calls, one fails then recovers -------------------
emit('user/message', { content: [{ type: 'text', text: 'smoke test intent' }] })
const steps = [
  ['c1', 'bash', true],
  ['c2', 'read', true],
  ['c3', 'bash', false],
  ['c4', 'grep', true],
  ['c5', 'edit', true],
  ['c6', 'bash', true],
]
for (const [id, tool] of steps) emit('tool/call', { callId: id, name: tool, arguments: '{}' })
for (const [id, , ok] of steps) {
  emit('tool/result', {
    callId: id,
    error: ok ? undefined : { message: 'step failed' },
    message: { source: { callId: id }, content: [{ content: [{ type: 'text', text: ok ? 'done' : 'exit 1' }] }] },
  })
}
emit('turn/end', { reason: { kind: 'completed' } })
await new Promise((r) => setTimeout(r, 300))

assert(llmCalls === 1, 'successful turn with signals triggers exactly one review')
assert(/in English\./.test(lastSystemPrompt), 'default generated-skill language directive is English')
assert(registered.has('smoke-test-workflow'), 'crystallized skill is registered into the catalog')
assert(readdirSync(GENERATED_DIR).includes('smoke-test-workflow.json'), 'crystallized skill is persisted')

const list = await ctx._rpc('list', { args: {} })
assert(list.ok && list.value.skills.length === 1, 'RPC list returns the skill')
assert(list.value.skills[0].signals.length >= 1, 'skill record carries crystallization signals')

const got = await ctx._rpc('get', { args: { name: 'smoke-test-workflow' } })
assert(got.ok && got.value.content.includes('## Verification'), 'RPC get returns full SKILL.md content')

// --- skill invocation counting through the host `skill` tool -------------
emit('tool/call', { callId: 'sk1', name: 'skill', arguments: JSON.stringify({ name: 'smoke-test-workflow' }) })
await new Promise((r) => setTimeout(r, 50))
const counted = await ctx._rpc('list', { args: {} })
assert(counted.value.skills[0].invocations === 1, 'loading the skill through the skill tool counts an invocation')

// --- user-explicit invocation injection also counts -----------------------
emit('user/message', {
  content: [{ type: 'text', text: '<skill_content name="smoke-test-workflow">body</skill_content>' }],
  source: { kind: 'skill-invocation', name: 'smoke-test-workflow', form: 'instructions' },
})
await new Promise((r) => setTimeout(r, 50))
const injected = await ctx._rpc('list', { args: {} })
assert(injected.value.skills[0].invocations === 2, 'a host-injected skill invocation counts an invocation too')

// --- turn 2: failed turn must never be reviewed -----------------------
llmCalls = 0
emit('user/message', { content: [{ type: 'text', text: 'failing task' }] })
for (let i = 0; i < 6; i++) {
  emit('tool/call', { callId: `f${i}`, name: 'bash', arguments: '{}' })
  emit('tool/result', { callId: `f${i}`, message: { source: { callId: `f${i}` }, content: [{ content: [{ type: 'text', text: 'x' }] }] } })
}
emit('turn/end', { reason: { kind: 'error', failure: { message: 'boom' } } })
await new Promise((r) => setTimeout(r, 200))
assert(llmCalls === 0, 'failed turn is never sent to review')

// --- cleanup via RPC remove --------------------------------------------
const rm = await ctx._rpc('remove', { args: { name: 'smoke-test-workflow' } })
assert(rm.ok && rm.value.removed === 'smoke-test-workflow', 'RPC remove succeeds')
assert(registered.size === 0, 'removed skill is unregistered')
assert(!readdirSync(GENERATED_DIR).includes('smoke-test-workflow.json'), 'removed skill file is deleted')

// --- corroboration gate: lone complex is withheld by default ------------
{
  const infos = []
  let gateLlmCalls = 0
  const gateCtx = {
    logger: { info: (m) => infos.push(m), warn: (m) => console.error(`[plugin warn] ${m}`) },
    skills: { register: () => () => {} },
    llm: { async *stream() { gateLlmCalls++; yield { type: 'text-delta', text: 'NOTHING_TO_SAVE' }; yield { type: 'finish', reason: { kind: 'completed' } } } },
    connection: { rpc: { handle() {} } },
    _handlers: {},
    on(event, fn) { gateCtx._handlers[event] = fn },
  }
  apply(gateCtx, { llmProvider: 'mock', llmModel: 'mock' })
  const gateSession = { id: 'gate-session' }
  const gateEmit = (type, data) => gateCtx._handlers['session/event'](gateSession, { type, data })
  const replayTurn = (failures) => {
    gateEmit('user/message', { content: [{ type: 'text', text: 'gate test' }] })
    for (let i = 0; i < 6; i++) {
      const fail = i < failures
      gateEmit('tool/call', { callId: `g${i}`, name: 'bash', arguments: '{}' })
      gateEmit('tool/result', {
        callId: `g${i}`,
        error: fail ? { message: 'boom' } : undefined,
        message: { source: { callId: `g${i}` }, content: [{ content: [{ type: 'text', text: fail ? 'exit 1' : 'ok' }] }] },
      })
    }
    gateEmit('turn/end', { reason: { kind: 'completed' } })
  }

  replayTurn(0) // lone complex: 6 successful calls, no failures
  await new Promise((r) => setTimeout(r, 200))
  assert(gateLlmCalls === 0 && infos.some((m) => m.includes('withheld pending corroboration')),
    'gate on: lone complex turn is withheld from review')

  replayTurn(1) // same sequence, now with a recovered failure
  await new Promise((r) => setTimeout(r, 200))
  assert(gateLlmCalls === 1, 'gate on: corroborated (complex+recovered) turn reaches review')
}

// --- generated-skill language selection ----------------------------------
{
  // hermetic: drop any developer-local runtime config before and after
  if (existsSync(RUNTIME_CONFIG_FILE)) unlinkSync(RUNTIME_CONFIG_FILE)
  try {
    let langLlmCalls = 0
    let langSystem = ''
    const langCtx = {
      logger: { info: () => {}, warn: (m) => console.error(`[plugin warn] ${m}`) },
      skills: { register: () => () => {} },
      llm: { async *stream(options) { langLlmCalls++; langSystem = options?.system ?? ''; yield { type: 'text-delta', text: 'NOTHING_TO_SAVE' }; yield { type: 'finish', reason: { kind: 'completed' } } } },
      connection: { rpc: { handle(_c, handler) { langCtx._rpc = handler } } },
      _handlers: {},
      on(event, fn) { langCtx._handlers[event] = fn },
    }
    apply(langCtx, { llmProvider: 'mock', llmModel: 'mock', skillLanguage: 'zh' })
    const langSession = { id: 'lang-session' }
    const langEmit = (type, data) => langCtx._handlers['session/event'](langSession, { type, data })
    langEmit('user/message', { content: [{ type: 'text', text: 'language test' }] })
    for (let i = 0; i < 6; i++) {
      const fail = i === 0
      langEmit('tool/call', { callId: `l${i}`, name: 'bash', arguments: '{}' })
      langEmit('tool/result', {
        callId: `l${i}`,
        error: fail ? { message: 'boom' } : undefined,
        message: { source: { callId: `l${i}` }, content: [{ content: [{ type: 'text', text: fail ? 'exit 1' : 'ok' }] }] },
      })
    }
    langEmit('turn/end', { reason: { kind: 'completed' } })
    await new Promise((r) => setTimeout(r, 200))
    assert(langLlmCalls === 1 && langSystem.includes('简体中文'),
      'skillLanguage zh injects the Chinese directive into the review prompt')

    const bad = await langCtx._rpc('setLanguage', { args: { language: 'fr' } })
    assert(!bad.ok && bad.error.code === 'skill-evolution/bad-language', 'RPC setLanguage rejects unknown languages')

    // mount config above sets skillLanguage 'zh', so 'en' is the override here
    const setEn = await langCtx._rpc('setLanguage', { args: { language: 'en' } })
    assert(setEn.ok && setEn.value.skillLanguage === 'en', 'RPC setLanguage accepts en')
    const persisted = existsSync(RUNTIME_CONFIG_FILE) ? JSON.parse(readFileSync(RUNTIME_CONFIG_FILE, 'utf8')) : {}
    assert(persisted.skillLanguage === 'en' && !('llmProvider' in persisted),
      'language-only persistence keeps the model on the config baseline')

    const snapshot = await langCtx._rpc('list', { args: {} })
    assert(snapshot.value.config.skillLanguage === 'en' && snapshot.value.config.defaults.skillLanguage === 'zh',
      'config snapshot exposes skillLanguage and its config default')
  } finally {
    if (existsSync(RUNTIME_CONFIG_FILE)) unlinkSync(RUNTIME_CONFIG_FILE)
  }
}

// --- runtime tuning & prompt overrides ------------------------------------
{
  if (existsSync(RUNTIME_CONFIG_FILE)) unlinkSync(RUNTIME_CONFIG_FILE)
  try {
    let tuneLlmCalls = 0
    let tuneSystem = ''
    const tuneCtx = {
      logger: { info: () => {}, warn: (m) => console.error(`[plugin warn] ${m}`) },
      skills: { register: () => () => {} },
      llm: { async *stream(options) { tuneLlmCalls++; tuneSystem = options?.system ?? ''; yield { type: 'text-delta', text: 'NOTHING_TO_SAVE' }; yield { type: 'finish', reason: { kind: 'completed' } } } },
      connection: { rpc: { handle(_c, handler) { tuneCtx._rpc = handler } } },
      _handlers: {},
      on(event, fn) { tuneCtx._handlers[event] = fn },
    }
    apply(tuneCtx, { llmProvider: 'mock', llmModel: 'mock' })
    const tuneSession = { id: 'tune-session' }
    const tuneEmit = (type, data) => tuneCtx._handlers['session/event'](tuneSession, { type, data })
    const replay = (steps, failures) => {
      tuneEmit('user/message', { content: [{ type: 'text', text: 'tuning test' }] })
      for (let i = 0; i < steps; i++) {
        const fail = i < failures
        tuneEmit('tool/call', { callId: `t${i}`, name: 'bash', arguments: '{}' })
        tuneEmit('tool/result', {
          callId: `t${i}`,
          error: fail ? { message: 'boom' } : undefined,
          message: { source: { callId: `t${i}` }, content: [{ content: [{ type: 'text', text: fail ? 'exit 1' : 'ok' }] }] },
        })
      }
      tuneEmit('turn/end', { reason: { kind: 'completed' } })
    }

    const snap0 = await tuneCtx._rpc('list', { args: {} })
    assert(snap0.value.config.defaults.minToolCalls === 5 && snap0.value.config.defaults.signals.repeated === true,
      'config snapshot exposes tuning defaults')

    const badType = await tuneCtx._rpc('setTuning', { args: { tuning: { minToolCalls: 'many' } } })
    assert(!badType.ok && badType.error.code === 'skill-evolution/bad-tuning', 'setTuning rejects non-numeric thresholds')
    const badRange = await tuneCtx._rpc('setTuning', { args: { tuning: { minSuccessRate: 1.5 } } })
    assert(!badRange.ok && badRange.error.code === 'skill-evolution/bad-tuning', 'setTuning rejects out-of-range values')
    const badKey = await tuneCtx._rpc('setTuning', { args: { tuning: { bogus: 1 } } })
    assert(!badKey.ok && badKey.error.code === 'skill-evolution/bad-tuning', 'setTuning rejects unknown keys')

    // 2-step turn is below the default floors (minTraceSteps 3, minToolCalls 5): no review
    replay(2, 1)
    await new Promise((r) => setTimeout(r, 200))
    assert(tuneLlmCalls === 0, 'turn below default floors is not reviewed')

    const setOk = await tuneCtx._rpc('setTuning', { args: { tuning: { minTraceSteps: 2, minToolCalls: 2, signals: { repeated: false } } } })
    assert(setOk.ok && setOk.value.config.minToolCalls === 2 && setOk.value.config.signals.repeated === false,
      'setTuning applies thresholds and signal toggles immediately')
    const persistedTuning = existsSync(RUNTIME_CONFIG_FILE) ? JSON.parse(readFileSync(RUNTIME_CONFIG_FILE, 'utf8')) : {}
    assert(persistedTuning.tuning && persistedTuning.tuning.minToolCalls === 2 && !('llmProvider' in persistedTuning),
      'tuning persists without dragging the model off the config baseline')

    // same 2-step turn now clears the lowered floors; recovered corroborates the gate
    replay(2, 1)
    await new Promise((r) => setTimeout(r, 200))
    assert(tuneLlmCalls === 1, 'lowered thresholds take effect for subsequent turns')

    const setPrompt = await tuneCtx._rpc('setPrompt', { args: { role: 'review', text: 'CUSTOM REVIEWER PROMPT.' } })
    assert(setPrompt.ok && setPrompt.value.config.prompts.reviewOverridden === true, 'setPrompt overrides the review prompt')
    replay(2, 1)
    await new Promise((r) => setTimeout(r, 200))
    assert(tuneLlmCalls === 2 && tuneSystem.startsWith('CUSTOM REVIEWER PROMPT.') && /in English\./.test(tuneSystem),
      'custom review prompt is used and the language directive is still appended')

    const clearPrompt = await tuneCtx._rpc('setPrompt', { args: { role: 'review', text: '   ' } })
    assert(clearPrompt.ok && clearPrompt.value.config.prompts.reviewOverridden === false, 'blank text restores the default review prompt')

    const badRole = await tuneCtx._rpc('setPrompt', { args: { role: 'other', text: 'x' } })
    assert(!badRole.ok && badRole.error.code === 'skill-evolution/bad-role', 'setPrompt rejects unknown roles')

    const reset = await tuneCtx._rpc('resetTuning', { args: {} })
    assert(reset.ok && reset.value.config.minToolCalls === 5 && reset.value.config.signals.repeated === true,
      'resetTuning restores the mount-config baseline')
    assert(!existsSync(RUNTIME_CONFIG_FILE), 'runtime-config.json is removed when no override remains')
  } finally {
    if (existsSync(RUNTIME_CONFIG_FILE)) unlinkSync(RUNTIME_CONFIG_FILE)
  }
}

// --- master switch ---------------------------------------------------------
{
  if (existsSync(RUNTIME_CONFIG_FILE)) unlinkSync(RUNTIME_CONFIG_FILE)
  try {
    let swLlmCalls = 0
    const swCtx = {
      logger: { info: () => {}, warn: (m) => console.error(`[plugin warn] ${m}`) },
      skills: { register: () => () => {} },
      llm: { async *stream() { swLlmCalls++; yield { type: 'text-delta', text: 'NOTHING_TO_SAVE' }; yield { type: 'finish', reason: { kind: 'completed' } } } },
      connection: { rpc: { handle(_c, handler) { swCtx._rpc = handler } } },
      _handlers: {},
      on(event, fn) { swCtx._handlers[event] = fn },
    }
    apply(swCtx, { llmProvider: 'mock', llmModel: 'mock' })
    const swSession = { id: 'switch-session' }
    const swEmit = (type, data) => swCtx._handlers['session/event'](swSession, { type, data })
    const swReplay = () => {
      swEmit('user/message', { content: [{ type: 'text', text: 'switch test' }] })
      for (let i = 0; i < 6; i++) {
        const fail = i === 0
        swEmit('tool/call', { callId: `s${i}`, name: 'bash', arguments: '{}' })
        swEmit('tool/result', {
          callId: `s${i}`,
          error: fail ? { message: 'boom' } : undefined,
          message: { source: { callId: `s${i}` }, content: [{ content: [{ type: 'text', text: fail ? 'exit 1' : 'ok' }] }] },
        })
      }
      swEmit('turn/end', { reason: { kind: 'completed' } })
    }

    swReplay()
    await new Promise((r) => setTimeout(r, 200))
    assert(swLlmCalls === 1, 'enabled plugin reviews a corroborated turn')

    const off = await swCtx._rpc('setEnabled', { args: { enabled: false } })
    assert(off.ok && off.value.enabled === false, 'setEnabled(false) pauses observation')
    swReplay()
    await new Promise((r) => setTimeout(r, 200))
    assert(swLlmCalls === 1, 'disabled plugin ignores turns entirely')
    const persistedOff = existsSync(RUNTIME_CONFIG_FILE) ? JSON.parse(readFileSync(RUNTIME_CONFIG_FILE, 'utf8')) : {}
    assert(persistedOff.enabled === false, 'the paused state is persisted')

    const badEnabled = await swCtx._rpc('setEnabled', { args: { enabled: 'yes' } })
    assert(!badEnabled.ok && badEnabled.error.code === 'skill-evolution/bad-enabled', 'setEnabled rejects non-boolean values')

    const on = await swCtx._rpc('setEnabled', { args: { enabled: true } })
    assert(on.ok && on.value.enabled === true, 'setEnabled(true) resumes observation')
    swReplay()
    await new Promise((r) => setTimeout(r, 200))
    assert(swLlmCalls === 2, 'resumed plugin reviews again')
    assert(!existsSync(RUNTIME_CONFIG_FILE), 'resuming to the config default drops the override file')
  } finally {
    if (existsSync(RUNTIME_CONFIG_FILE)) unlinkSync(RUNTIME_CONFIG_FILE)
  }
}

// --- semantic dedup: FOLD_INTO routes near-duplicates into an existing skill
{
  if (existsSync(RUNTIME_CONFIG_FILE)) unlinkSync(RUNTIME_CONFIG_FILE)
  try {
    let foldLlmCalls = 0
    const userContents = []
    const foldResponses = [
      // review 1 (sequence A): crystallize the first skill
      ['VERDICT: SAVE', 'NAME: alpha-flow', 'DESCRIPTION: First workflow', '---', '# Alpha Flow', '', '## When to Use', 'Never.', '', '## Procedure', '1. Step.', '', '## Pitfalls', 'None.', '', '## Verification', 'Done.'].join('\n'),
      // review 2 (sequence B, different tools): reviewer folds into alpha-flow
      'VERDICT: FOLD_INTO: alpha-flow',
      // review 3: the improvement pipeline merges the fresh evidence
      ['VERDICT: UPDATE', '---', '# Alpha Flow', '', '## When to Use', 'Never.', '', '## Procedure', '1. Step.', '2. New step folded in.', '', '## Pitfalls', 'None.', '', '## Verification', 'Done.'].join('\n'),
      // review 4 (sequence C): fold into a skill that does not exist
      'VERDICT: FOLD_INTO: ghost-skill',
    ]
    const foldCtx = {
      logger: { info: () => {}, warn: (m) => console.error(`[plugin warn] ${m}`) },
      skills: { register: () => () => {} },
      llm: {
        async *stream(options) {
          foldLlmCalls++
          userContents.push(options?.messages?.[0]?.content?.[0]?.text ?? '')
          yield { type: 'text-delta', text: foldResponses.shift() ?? 'NOTHING_TO_SAVE' }
          yield { type: 'finish', reason: { kind: 'completed' } }
        },
      },
      connection: { rpc: { handle(_c, handler) { foldCtx._rpc = handler } } },
      _handlers: {},
      on(event, fn) { foldCtx._handlers[event] = fn },
    }
    apply(foldCtx, { llmProvider: 'mock', llmModel: 'mock' })
    const foldSession = { id: 'fold-session' }
    const foldEmit = (type, data) => foldCtx._handlers['session/event'](foldSession, { type, data })
    const foldReplay = (tools) => {
      foldEmit('user/message', { content: [{ type: 'text', text: 'fold test' }] })
      tools.forEach((tool, i) => {
        const fail = i === 0
        foldEmit('tool/call', { callId: `d${i}`, name: tool, arguments: '{}' })
        foldEmit('tool/result', {
          callId: `d${i}`,
          error: fail ? { message: 'boom' } : undefined,
          message: { source: { callId: `d${i}` }, content: [{ content: [{ type: 'text', text: fail ? 'exit 1' : 'ok' }] }] },
        })
      })
      foldEmit('turn/end', { reason: { kind: 'completed' } })
    }

    foldReplay(['bash', 'read', 'bash', 'grep', 'edit', 'bash'])
    await new Promise((r) => setTimeout(r, 300))
    assert(foldLlmCalls === 1, 'sequence A crystallizes after one review')

    foldReplay(['grep', 'edit', 'bash', 'read', 'bash', 'grep'])
    await new Promise((r) => setTimeout(r, 400))
    assert(foldLlmCalls === 3, 'FOLD_INTO triggers the improvement review instead of a save')
    assert(/Existing evolved skills:[\s\S]*- alpha-flow/.test(userContents[1] ?? ''), 'the crystallization prompt lists existing skills for dedup')
    const foldedList = await foldCtx._rpc('list', { args: {} })
    assert(foldedList.value.skills.length === 1, 'no near-duplicate skill is created')
    assert(foldedList.value.skills[0].version === 2, 'folded evidence bumps the existing skill to v2')
    assert(foldedList.value.skills[0].improvements === 1, 'the fold counts as one improvement')

    foldReplay(['edit', 'bash', 'grep', 'bash', 'read', 'edit'])
    await new Promise((r) => setTimeout(r, 300))
    assert(foldLlmCalls === 4, 'fold into an unknown skill is declined without saving')
    const ghostList = await foldCtx._rpc('list', { args: {} })
    assert(ghostList.value.skills.length === 1, 'unknown fold target creates nothing')

    // cleanup: remove the crystallized skill so generated/ stays clean
    await foldCtx._rpc('remove', { args: { name: 'alpha-flow' } })
  } finally {
    if (existsSync(RUNTIME_CONFIG_FILE)) unlinkSync(RUNTIME_CONFIG_FILE)
  }
}

console.log('\nsmoke test passed')
