# dsh-find-bar

DSH web 插件：为桌面 App（Electron 壳）补上 **⌘F / Ctrl+F 页内查找**，
体验对齐浏览器原生查找条——支持全文高亮、匹配计数、回车跳转。

搜索范围：当前页面渲染的全部文本——对话内容、侧边栏、设置页。

## 原理

Electron 没有浏览器内置查找栏。本插件在客户端实现：

- 监听 ⌘F/Ctrl+F（capture 阶段）弹出自绘查找条（跟随主题变量）
- 用 TreeWalker 收集文本节点（含 shadow root 内），构建 DOM Range 匹配
- 用 **CSS Custom Highlight API**（`CSS.highlights` + `::highlight()`）高亮——
  只绘制不修改 DOM，与 React 渲染零冲突
- 不支持该 API 的环境自动退回 `window.find()`

## 快捷键

| 键 | 功能 |
|---|---|
| ⌘F / Ctrl+F | 打开查找条（自动填入当前选中文本） |
| Enter / Shift+Enter | 下一个 / 上一个匹配 |
| ⌘G / F3（+Shift） | 下一个 / 上一个 |
| Esc | 关闭并清除高亮 |

输入即搜（防抖跟随内容流式更新），计数显示 `当前/总数`。

## 安装

```sh
npm pack
dsh plugin --profile desktop add ./dsh-find-bar-0.1.0.tgz
```

安装后重启一次应用（插件清单启动时装载）。

## 已知限制

- 只搜索**已渲染**在 DOM 里的内容；未展开的会话/极长列表若被界面折叠，需先展开
- 匹配上限 5000 条（超限显示 `+`）
- 大小写不敏感，暂无"区分大小写"开关

## 卸载

```sh
dsh plugin --profile desktop remove dsh-find-bar
```
