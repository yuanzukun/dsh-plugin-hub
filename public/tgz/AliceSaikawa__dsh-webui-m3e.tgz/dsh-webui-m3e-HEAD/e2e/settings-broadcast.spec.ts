import { test, expect, visit } from './helpers'
import type { MockContext } from '../web/src/dsh/mock/context.ts'
import type { SettingsApi } from '../web/src/features/settings/store.ts'

declare global { interface Window {
  __s5SettingsProbe: { ctx: MockContext; describes: number }
} }

test('S5 偽の複数引数放送から useSettings へ版を渡し、同じ版を無視して画面を閉じた後も更新を読む', async ({ page }) => {
  await page.route('**/src/dsh/mock/context.ts*', async route => {
    const response = await route.fetch()
    const body = await response.text()
    expect(body.match(/\breturn ctx;?/g)).toHaveLength(1)
    await route.fulfill({ response, body: body.replace(/\breturn ctx;?/, `
      const probe = globalThis.__s5SettingsProbe = { ctx, describes: 0 };
      const describe = ctx.remote.settings.describe.bind(ctx.remote.settings);
      ctx.remote.settings.describe = (...args) => { probe.describes++; return describe(...args); };
      return ctx;`) })
  })
  await visit(page, '/settings/other')
  const section = page.locator('.settings-namespace').filter({ has: page.getByRole('heading', { name: 'example-extension', exact: true }) })
  await expect(section.getByLabel('名前', { exact: true })).toHaveValue('追加機能')
  const revision = await page.evaluate(async () => {
    const result = await (window.__s5SettingsProbe.ctx.remote.settings as SettingsApi).describe()
    if (!result.ok) throw new Error(result.error.message)
    return result.value.namespaces.find(row => row.ns === 'example-extension')!.revision
  })
  const emitAndCount = (version: number) => page.evaluate(async version => {
    const probe = window.__s5SettingsProbe
    const before = probe.describes
    await probe.ctx.mock.emit('settings/document-updated', 'example-extension', { additionalArgs: [version] })
    await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))
    return probe.describes - before
  }, version)
  expect(await emitAndCount(revision)).toBe(0)
  expect(await emitAndCount(revision + 1)).toBe(1)
  await page.evaluate(() => { window.location.hash = '/' })
  await expect(page.locator('.home-session').first()).toBeVisible()
  // The store and its subscription live with the remote, not the screen, so a
  // change broadcast while no settings screen is open is read as well.
  expect(await emitAndCount(revision + 1)).toBe(1)
})
