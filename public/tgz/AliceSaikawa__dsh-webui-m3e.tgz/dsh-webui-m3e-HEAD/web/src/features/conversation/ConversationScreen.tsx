import { useEffect, useLayoutEffect, useRef } from 'react'
import { M3eIconButton } from '@m3e/react/icon-button'
import { M3eTabs, M3eTab } from '@m3e/react/tabs'
import { Icon } from '../../app/icons/Icon.tsx'
import { ConnectionBanner } from '../../app/shell/ConnectionBanner.tsx'
import { RetainedScrollPanel } from '../../app/shell/RetainedScrollPanel.tsx'
import { ErrorState } from '../../app/ErrorState.tsx'
import { errorMessages } from '../../app/messages.ts'
import { useMessages } from '../../i18n/index.ts'
import { back, navigate } from '../../app/router.ts'
import { useOverlays } from '../../app/overlay/index.ts'
import { useDsh } from '../../dsh/services.ts'
import { useSnapshot } from '../../dsh/use-snapshot.ts'
import { useSession } from '../../dsh/session.ts'
import { sessionAccess } from '../../dsh/session-access.ts'
import { remoteErrorMessage } from '../../dsh/remote-result.ts'
import { usePendingInteractions } from '../../dsh/interactions.ts'
import { shouldHideComposer } from '../../dsh/interaction-presentation.ts'
import { ChatView } from '../chat/ChatView.tsx'
import { TraceView } from '../trace/TraceView.tsx'
import { Composer } from '../composer/Composer.tsx'
import { presentInteraction } from '../interactions/InteractionSheet.tsx'
import { PendingChip } from '../interactions/PendingChip.tsx'
import { ConversationPickerButton } from './ConversationPicker.tsx'
import { conversationMessages } from './messages.ts'
import { SessionMenuButton } from '../session-tools/SessionMenu.tsx'

export function ConversationScreen({ sessionId, tab = 'chat' }: { sessionId: string; tab?: 'chat' | 'trace' }) {
  const { sessions } = useDsh()
  const list = useSnapshot(sessions.list)
  const { snapshot } = useSession(sessionId)
  const error = useMessages(errorMessages)
  const text = useMessages(conversationMessages)
  const access = sessionAccess(list.byId[sessionId], snapshot)
  const pending = usePendingInteractions(sessionId)
  const current = pending.find(item => !item.deferred)
  const overlays = useOverlays()
  const composerHidden = shouldHideComposer(sessionId, pending, overlays)
  const contentRef = useRef<HTMLElement>(null)
  const chatTabRef = useRef<HTMLElement | null>(null)
  const traceTabRef = useRef<HTMLElement | null>(null)
  const previousTab = useRef(tab)
  useLayoutEffect(() => {
    const changed = previousTab.current !== tab
    previousTab.current = tab
    if (!changed) return
    const focused = document.activeElement
    const hiddenPanel = contentRef.current?.querySelector<HTMLElement>(':scope > .conversation-panel[hidden]')
    // A hash change can hide the focused content without a tab click. Also cover
    // focus lost when the composer disappears, while leaving overlay focus alone.
    if (focused === document.body || (focused && hiddenPanel?.contains(focused))) {
      const selectedTab = tab === 'chat' ? chatTabRef : traceTabRef
      selectedTab.current?.focus({ preventScroll: true })
    }
  }, [tab])
  useEffect(() => {
    if (!current) return
    return presentInteraction(current, { from: 'conversation' })
  }, [current])
  const base = `/s/${encodeURIComponent(sessionId)}`
  return <section className="screen conversation-screen"><header className="top-bar">
    <M3eIconButton aria-label={text.back} onClick={back}><Icon name="arrow_back" /></M3eIconButton>
    <h1>{list.byId[sessionId]?.displayTitle ?? text.title}</h1><ConversationPickerButton sessionId={sessionId} /><SessionMenuButton sessionId={sessionId} />
  </header><ConnectionBanner />
    <M3eTabs className="conversation-tabs" stretch disableSwipe disablePagination variant="primary" previousPageLabel={text.previousTab} nextPageLabel={text.nextTab}>
      <M3eTab ref={element => { chatTabRef.current = element }} selected={tab === 'chat'} onClick={() => navigate(base, { replace: true })}>{text.chatTab}</M3eTab>
      <M3eTab ref={element => { traceTabRef.current = element }} selected={tab === 'trace'} onClick={() => navigate(`${base}/trace`, { replace: true })}>{text.traceTab}</M3eTab>
    </M3eTabs>
    <main ref={contentRef} className="screen-content conversation-content">
      {snapshot.openState === 'error' ? <div className="conversation-panel" data-scroll-area><ErrorState icon="chat_error" title={error.openFailedTitle} message={remoteErrorMessage(snapshot.openError)} actions={[{ label: error.back, onClick: back }, { label: error.retryOpen, primary: true, onClick: () => window.location.reload() }]} /></div>
        : <>
          <RetainedScrollPanel active={tab === 'chat'} label={text.chatTab}>
            <ChatView sessionId={sessionId} active={tab === 'chat'} />
          </RetainedScrollPanel>
          <RetainedScrollPanel active={tab === 'trace'} label={text.traceTab}>
            <TraceView sessionId={sessionId} active={tab === 'trace'} />
          </RetainedScrollPanel>
        </>}
    </main>
    {tab === 'chat' && snapshot.openState !== 'error' && <footer className="conversation-footer"><PendingChip sessionId={sessionId} />{!composerHidden && (access.canCompose
      ? <Composer target={{ kind: 'session', sessionId }} />
      : <p>{access.mode === 'one-shot' ? text.readOnlySubagent : text.readOnlyUnknownChild}</p>)}</footer>}
  </section>
}
