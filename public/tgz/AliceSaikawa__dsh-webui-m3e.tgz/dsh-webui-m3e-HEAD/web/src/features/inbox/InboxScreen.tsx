import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { M3eActionList, M3eListAction } from '@m3e/react/list'
import { Icon } from '../../app/icons/Icon.tsx'
import { navigate } from '../../app/router.ts'
import { showSnackbar } from '../../app/overlay/index.ts'
import { TabScaffold } from '../../app/shell/TabScaffold.tsx'
import { useDsh } from '../../dsh/services.ts'
import { useSnapshot } from '../../dsh/use-snapshot.ts'
import { remoteErrorMessage } from '../../dsh/remote-result.ts'
import { useMessages } from '../../i18n/index.ts'
import { presentInteraction } from '../interactions/InteractionSheet.tsx'
import { inboxMessages } from './messages.ts'
import { buildInboxRows, inboxStatus } from './model.ts'
import { useInbox } from './use-inbox.ts'
import { openInboxSession } from './session-navigation.ts'
import './inbox.css'

export function InboxScreen() {
  const text = useMessages(inboxMessages)
  const { workspaces, sessions } = useDsh()
  const workspaceList = useSnapshot(workspaces.list)
  const { list, pending } = useInbox()
  const [now, setNow] = useState(Date.now)
  const [openingId, setOpeningId] = useState<string | null>(null)
  const interactionCloses = useRef(new Set<() => void>())
  useLayoutEffect(() => () => {
    // Remove queued requests first so cleanup cannot open one on the next route.
    for (const close of [...interactionCloses.current.values()].reverse()) close()
    interactionCloses.current.clear()
  }, [])
  const navigationAttempt = useRef(0)
  const openingLifetime = useRef<AbortController | undefined>(undefined)
  useEffect(() => () => { navigationAttempt.current++; openingLifetime.current?.abort() }, [])
  const rows = buildInboxRows(pending, list, workspaceList, now, text)
  const status = inboxStatus(rows, list, workspaceList, text)
  const hasCompleted = rows.completed.length > 0
  const hasRows = rows.pending.length > 0 || hasCompleted
  useEffect(() => {
    if (!hasCompleted) return
    setNow(Date.now())
    const timer = setInterval(() => setNow(Date.now()), 60_000)
    return () => clearInterval(timer)
  }, [hasCompleted])

  async function openCompleted(sessionId: string) {
    openingLifetime.current?.abort()
    openingLifetime.current = new AbortController()
    const attempt = ++navigationAttempt.current
    const origin = window.location.hash
    const isActive = () => navigationAttempt.current === attempt && window.location.hash === origin
    setOpeningId(sessionId)
    try { await openInboxSession(sessions, sessionId, navigate, isActive, openingLifetime.current.signal, text) }
    catch (error) { if (isActive()) showSnackbar(remoteErrorMessage(error, text.openFailed)) }
    // Clear even after an unrelated hash change so the rows cannot stay disabled.
    finally { if (navigationAttempt.current === attempt) setOpeningId(null) }
  }

  return <TabScaffold title={text.title}>
    <div className={`inbox-content${!hasRows ? ' inbox-is-empty' : ''}`}>
      <div className="inbox-notices">
        {status.workspaceError && <p className="inbox-error" role="alert">{status.workspaceError}</p>}
        {hasRows && status.loadingMessage && <p className="inbox-loading" role="status">{status.loadingMessage}</p>}
        {openingId && <p className="inbox-loading" role="status">{text.opening}</p>}
      </div>
      {rows.pending.length > 0 && <section className="inbox-section" aria-labelledby="inbox-pending-heading">
        <h2 id="inbox-pending-heading">{text.pendingHeading}</h2>
        <M3eActionList aria-label={text.pendingHeading}>
          {rows.pending.map(row => <M3eListAction key={row.key} className="inbox-row"
            aria-label={text.rowLabel(row.title, row.workspaceName, row.description)}
            onClick={() => {
              navigationAttempt.current++
              setOpeningId(null)
              interactionCloses.current.add(presentInteraction(row.pending, { from: 'inbox' }))
            }}>
            <Icon slot="leading" name={row.icon} />
            <span className="inbox-title">{row.title}</span>
            <span slot="supporting-text" className="inbox-description"><small>{row.workspaceName}</small>{text.rowSeparator}{row.description}</span>
          </M3eListAction>)}
        </M3eActionList>
      </section>}
      {hasCompleted && <section className="inbox-section" aria-labelledby="inbox-completed-heading">
        <h2 id="inbox-completed-heading">{text.completedHeading}</h2>
        <M3eActionList aria-label={text.completedHeading}>
          {rows.completed.map(row => <M3eListAction key={row.key} className="inbox-row"
            aria-label={text.rowLabel(row.title, row.workspaceName, row.description)}
            disabled={openingId !== null}
            onClick={() => { void openCompleted(row.sessionId) }}>
            <Icon slot="leading" name={row.icon} />
            <span className="inbox-title">{row.title}</span>
            <span slot="supporting-text" className="inbox-description"><small>{row.workspaceName}</small>{text.rowSeparator}{row.description}</span>
          </M3eListAction>)}
        </M3eActionList>
      </section>}
      {!hasRows && <div className="inbox-empty" role="status">
        <Icon name={status.loadingMessage ? 'hourglass_empty' : 'front_hand'} />
        {status.loadingMessage ? <p>{status.loadingMessage}</p> : status.showEmpty && <p>{text.empty}</p>}
      </div>}
    </div>
  </TabScaffold>
}
