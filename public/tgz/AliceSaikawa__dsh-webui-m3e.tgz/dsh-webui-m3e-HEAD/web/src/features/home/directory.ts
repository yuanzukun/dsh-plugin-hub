import { useEffect, useState } from 'react'
import type { DshRemote, RemoteResult } from '../../dsh/services.ts'
import { remoteFailureOf, unwrapRemoteResult } from '../../dsh/remote-result.ts'
import { messagesOf } from '../../i18n/catalog.ts'
import { currentLocale } from '../../i18n/current.ts'
import { homeMessages } from './messages.ts'

export interface DirectoryEntry { name: string; path: string; hidden: boolean }
export interface DirectoryListing { path: string; home: string; crumbs: DirectoryEntry[]; entries: DirectoryEntry[]; truncated: boolean }
export interface DirectoryPicker {
  list(path: string | undefined, signal?: AbortSignal): Promise<RemoteResult<DirectoryListing>>
  createDirectory(path: string, name: string): Promise<RemoteResult<string>>
}

/** The picker's "no native folder support" text in the page language. */
export function nativeUnavailableMessage(): string {
  return messagesOf(homeMessages, currentLocale()).nativeUnavailable
}

export function directoryPicker(remote: DshRemote): DirectoryPicker | undefined {
  const value = remote.directoryPicker as Partial<DirectoryPicker> | undefined
  return value && typeof value.list === 'function' ? value as DirectoryPicker : undefined
}
export function isNativeUnavailable(error: unknown): boolean {
  const failure = remoteFailureOf(error)
  return failure?.code === 'directory-picker/unavailable' && failure.details.capability === 'native'
}

export interface DirectoryAvailability { ready: boolean; canAdd: boolean; homePath?: string }
function failedAvailability(error: unknown): DirectoryAvailability {
  const unavailable = remoteFailureOf(error)?.code === 'directory-picker/unavailable'
  // A failed probe is not evidence of missing support; keep the screen available for retry.
  return { ready: true, canAdd: !unavailable || isNativeUnavailable(error) }
}
export async function probeDirectory(remote: DshRemote, signal?: AbortSignal): Promise<DirectoryAvailability> {
  const picker = directoryPicker(remote)
  if (!picker) return { ready: true, canAdd: remote.directoryPicker != null }
  try {
    const listing = unwrapRemoteResult(await picker.list(undefined, signal))
    return { ready: true, canAdd: true, homePath: listing.home }
  } catch (error) { return failedAvailability(error) }
}

/** The public RPC has no capability() method; probe its read-only browse operation. */
export function useDirectoryAvailability(remote: DshRemote, connected: boolean) {
  const [state, setState] = useState<DirectoryAvailability>({ ready: false, canAdd: false })
  useEffect(() => {
    if (!connected) return
    const controller = new AbortController()
    void probeDirectory(remote, controller.signal).then(next => { if (!controller.signal.aborted) setState(next) })
    return () => controller.abort()
  }, [remote, connected])
  return state
}
