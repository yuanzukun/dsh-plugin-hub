import { M3eButton } from '@m3e/react/button'
import { M3eActionList, M3eListAction } from '@m3e/react/list'
import { Icon } from '../../app/icons/Icon.tsx'
import { TabScaffold } from '../../app/shell/TabScaffold.tsx'
import { navigate } from '../../app/router.ts'
import { useAppearance, useThemeColor } from '../../app/theme/index.ts'
import { useMessages } from '../../i18n/index.ts'
import { useDsh } from '../../dsh/services.ts'
import { appearanceLabels, confirmClassic, openAppearance, themeColorLabel } from './AppearanceSheet.tsx'
import { useAgentPresetRoster } from './AgentPresetsPage.tsx'
import { presetDisplayText } from './agent-presets.ts'
import { GeneralSection } from './GeneralSection.tsx'
import { agentPresetMessages } from './messages.ts'
import { groupNamespaces, pageSummary, settingsPages } from './schema.ts'
import { useSettings } from './use-settings.ts'
import { useProviderSummary } from './use-provider-summary.ts'
import type { SettingsState } from './store.ts'
import manifest from '../../../../package.json'
import './settings.css'

export function SettingsStatus({ state, reload }: { state: SettingsState; reload(): unknown }) {
  if (state.phase === 'loading') return <p role="status" className="muted">設定を読み込んでいます…</p>
  if (state.error) return <div className="settings-notice"><p role="alert">{state.error}</p><M3eButton onClick={() => { void reload() }}>再読み込み</M3eButton></div>
  if (!state.writable) return <p className="settings-notice" role="status">この DSH では設定を変更できません</p>
  return null
}

export function SettingsScreen() {
  const appearance = useAppearance()
  const color = useThemeColor()
  const { state, store } = useSettings()
  const providers = useProviderSummary()
  const groups = groupNamespaces(state.namespaces)
  const { remote } = useDsh()
  const presetText = useMessages(agentPresetMessages)
  const presets = useAgentPresetRoster(remote)
  const modeSummary = presets.state.phase === 'loading' ? presetText.summaryLoading
    : presets.state.phase === 'unavailable' ? presetText.summaryUnavailable
    : presets.state.phase === 'error' ? presetText.summaryError
    : (() => {
        const selected = presets.state.rows.find(row => row.isDefault)
        if (selected) return presetDisplayText(selected, presetText).name
        return presets.state.rows.length === 0 ? presetText.empty : presetText.missingDefault
      })()
  return <TabScaffold title="設定" tab="settings"><div className="settings-content">
    <section className="settings-section" aria-labelledby="settings-device">
      <h2 id="settings-device">この端末</h2>
      <M3eActionList className="settings-card">
        <M3eListAction onClick={confirmClassic}>
          <span slot="leading"><Icon name="swap_horiz" /></span>今の画面に戻す
          <span slot="supporting-text">DSH の標準の画面を使う</span>
          <span slot="trailing"><Icon name="chevron_right" /></span>
        </M3eListAction>
        <M3eListAction onClick={openAppearance}>
          <span slot="leading"><Icon name="dark_mode" /></span>外観
          <span slot="supporting-text">{appearanceLabels[appearance]}・{themeColorLabel(color)}</span>
          <span slot="trailing"><Icon name="chevron_right" /></span>
        </M3eListAction>
      </M3eActionList>
    </section>
    <SettingsStatus state={state} reload={store.reload} />
    <GeneralSection state={state} store={store} />
    <section className="settings-section" aria-labelledby="settings-dsh">
      <h2 id="settings-dsh">DSH の設定</h2>
      <M3eActionList className="settings-card">
        {settingsPages.filter(page => page.id !== 'other' || groups.other.length > 0).flatMap(page => {
          const row = <M3eListAction key={page.id} onClick={() => navigate(`/settings/${page.id}`)}>
            <span slot="leading"><Icon name={page.icon} /></span>{page.title}
            <span slot="supporting-text">{page.id === 'providers' ? providers : state.phase === 'loading' ? '読み込み中…' : state.error ? '設定を確認できません' : pageSummary(page.id, groups[page.id], state.permissionCatalog)}</span>
            <span slot="trailing"><Icon name="chevron_right" /></span>
          </M3eListAction>
          return page.id === 'agent' ? [row, <M3eListAction key="modes" onClick={() => navigate('/settings/modes')}>
            <span slot="leading"><Icon name="tune" /></span>{presetText.title}
            <span slot="supporting-text">{modeSummary}</span>
            <span slot="trailing"><Icon name="chevron_right" /></span>
          </M3eListAction>] : [row]
        })}
        <M3eListAction onClick={() => navigate('/settings/plugins')}>
          <span slot="leading"><Icon name="extension" /></span>プラグイン
          <span slot="supporting-text">入っているプラグインと状態</span>
          <span slot="trailing"><Icon name="chevron_right" /></span>
        </M3eListAction>
      </M3eActionList>
    </section>
    <p className="settings-version">この画面の版：{manifest.version}</p>
  </div></TabScaffold>
}
