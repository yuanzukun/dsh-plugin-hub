import type { ISessions, SessionListState, SessionTarget, SubagentAddress } from './services.ts'
import { RemoteCallError } from './remote-result.ts'
import { messagesOf, type Translation } from '../i18n/catalog.ts'
import { currentLocale } from '../i18n/current.ts'
import { navigationErrorMessages } from './messages.ts'

type NavigationErrorTexts = Translation<typeof navigationErrorMessages.ja>
/** Resolved when the error is thrown, so a language change is picked up without a reload. */
const errorText = (): NavigationErrorTexts => messagesOf(navigationErrorMessages, currentLocale())

const refreshes = new WeakMap<ISessions['list'], Map<string, Promise<void>>>()
function refresh(sessions: Pick<ISessions, 'list' | 'refreshProjections'>, id: string): Promise<void> {
  let pending = refreshes.get(sessions.list)
  if (!pending) { pending = new Map(); refreshes.set(sessions.list, pending) }
  const existing = pending.get(id)
  if (existing) return existing
  const request = sessions.refreshProjections(id).finally(() => pending.delete(id))
  pending.set(id, request)
  return request
}

export function subagentCatalogAddress(list: SessionListState, parentSessionId: string, childSessionId: string): SubagentAddress | undefined {
  const projection = list.projectionsBySession[parentSessionId]
  if (!projection || projection.state === 'error' || projection.state === 'loading') return undefined
  // 'migration-required' keeps cached values applied, so the catalog is still readable here.
  const entry = projection.values.subagentCatalog?.find(value => value.id === childSessionId)
  // The client library does not address external children from the catalog either (manager.js:92).
  if (entry?.mode !== 'one-shot' && entry?.mode !== 'continuable') return undefined
  return { parentSessionId, childSessionId, mode: entry.mode }
}

/** Resolve without owning anything. A closed picker never reaches retain. */
export async function resolveConversationTarget(sessions: Pick<ISessions, 'list' | 'subagentAddress' | 'refreshProjections'>, sessionId: string, isActive: () => boolean = () => true): Promise<SessionTarget | undefined> {
  if (!isActive()) return undefined
  const list = sessions.list.getSnapshot()
  const row = list.byId[sessionId]
  const retained = sessions.subagentAddress(sessionId)
  if (row?.origin !== 'subagent' && retained === undefined) {
    if (!row) throw new Error(errorText().sessionMissing)
    return sessionId
  }
  const parentSessionId = row?.parentId ?? retained?.parentSessionId
  if (!parentSessionId) throw new Error(errorText().parentMissing)
  let address = subagentCatalogAddress(list, parentSessionId, sessionId)
  if (!address) {
    try { await refresh(sessions, parentSessionId) } catch (error) { if (!isActive()) return undefined; throw error }
    if (!isActive()) return undefined
    const latest = sessions.list.getSnapshot()
    const failure = latest.projectionsBySession[parentSessionId]?.error
    if (failure) throw new RemoteCallError(failure)
    const current = latest.byId[sessionId]
    if (row && (!current || current.origin !== row.origin || current.parentId !== row.parentId)) throw new Error(errorText().childChanged)
    address = subagentCatalogAddress(latest, parentSessionId, sessionId)
  }
  if (!address) throw new Error(errorText().childUnavailable)
  return isActive() ? address : undefined
}
