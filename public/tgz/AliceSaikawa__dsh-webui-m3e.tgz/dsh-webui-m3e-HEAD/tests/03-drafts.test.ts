import assert from 'node:assert/strict'
import test from 'node:test'
import { clearDraft, readDraft, writeDraft } from '../web/src/features/composer/drafts.ts'

test('端末の下書きを会話ごとに復元し、送った会話だけ消す', () => {
  const savedWindow = Object.getOwnPropertyDescriptor(globalThis, 'window')
  const savedStorage = Object.getOwnPropertyDescriptor(globalThis, 'localStorage')
  const entries = new Map([['m3e:composer:session:saved-one', '保存した文章\n次の行'], ['m3e:composer:session:saved-two', '別の会話']])
  Object.defineProperty(globalThis, 'window', { configurable: true, value: {} })
  Object.defineProperty(globalThis, 'localStorage', { configurable: true, value: {
    getItem: (key: string) => entries.get(key) ?? null,
    setItem: (key: string, value: string) => { entries.set(key, value) },
    removeItem: (key: string) => { entries.delete(key) },
  } })
  try {
    assert.equal(readDraft('session:saved-one').text, '保存した文章\n次の行')
    writeDraft('session:saved-one', { text: '編集した文章', images: [], plan: true })
    assert.equal(entries.get('m3e:composer:session:saved-one'), '編集した文章')
    assert.equal(readDraft('session:saved-two').text, '別の会話')
    clearDraft('session:saved-one')
    assert.equal(entries.has('m3e:composer:session:saved-one'), false)
    assert.equal(entries.get('m3e:composer:session:saved-two'), '別の会話')
    const marker = { sessionId: 'already-created', workspaceId: 'workspace-one' }
    entries.set('m3e:composer:new:partial-create', '登録だけ失敗した文章')
    entries.set('m3e:composer:new:partial-create:workspaceAttachment', JSON.stringify(marker))
    assert.deepEqual(readDraft('new:partial-create').workspaceAttachment, marker)
    assert.equal(readDraft('new:partial-create').text, '登録だけ失敗した文章')
    writeDraft('session:already-created', { text: '移管した文章', images: [], workspaceAttachment: marker })
    assert.deepEqual(JSON.parse(entries.get('m3e:composer:session:already-created:workspaceAttachment')!), marker)
    // The failure body survives a reload; the images and choices stay in the tab.
    const recorded = { sessionId: 'recorded-conversation', workspaceId: 'workspace-two', baseline: { text: '失敗した時点の本文' } }
    writeDraft('session:recorded-conversation', { text: '移管した文章', images: [], workspaceAttachment: recorded })
    assert.deepEqual(JSON.parse(entries.get('m3e:composer:session:recorded-conversation:workspaceAttachment')!), recorded)
    assert.deepEqual(readDraft('session:recorded-conversation').workspaceAttachment, recorded)
    writeDraft('session:recorded-choices', { text: '失敗した時点の本文', images: [], workspaceAttachment: { workspaceId: 'workspace-two', sessionId: 'recorded-choices', baseline: { text: '失敗した時点の本文', input: { images: [], model: undefined, permission: 'limited', plan: true } } } })
    assert.deepEqual(JSON.parse(entries.get('m3e:composer:session:recorded-choices:workspaceAttachment')!), { workspaceId: 'workspace-two', sessionId: 'recorded-choices', baseline: { text: '失敗した時点の本文' } })
    clearDraft('session:already-created')
    assert.equal(entries.has('m3e:composer:session:already-created:workspaceAttachment'), false)
    entries.set('m3e:composer:new:bad-marker:workspaceAttachment', '{broken')
    assert.equal(readDraft('new:bad-marker').workspaceAttachment, undefined)
    entries.set('m3e:composer:session:wrong-id:workspaceAttachment', JSON.stringify(marker))
    assert.equal(readDraft('session:wrong-id').workspaceAttachment, undefined)
    entries.set('m3e:composer:session:uncertain-saved', '受理されたか分からない依頼')
    entries.set('m3e:composer:session:uncertain-saved:deliveryOutcome', 'unknown')
    const uncertain = readDraft('session:uncertain-saved')
    assert.equal(uncertain.deliveryOutcome, 'unknown')
    assert.match(uncertain.error ?? '', /送信結果を確認できません/)
    writeDraft('session:uncertain-saved', { ...uncertain, text: '編集した依頼' })
    assert.equal(entries.get('m3e:composer:session:uncertain-saved:deliveryOutcome'), 'unknown')
    clearDraft('session:uncertain-saved')
    assert.equal(entries.has('m3e:composer:session:uncertain-saved:deliveryOutcome'), false)
    entries.set('m3e:composer:session:invalid-outcome:deliveryOutcome', 'accepted')
    assert.equal(readDraft('session:invalid-outcome').deliveryOutcome, undefined)
    // A denied storage area still keeps a usable in-memory draft.
    Object.defineProperty(globalThis, 'localStorage', { configurable: true, get() { throw new Error('保存領域を利用できません') } })
    writeDraft('session:storage-off', { text: '端末内のメモリに保持', images: [] })
    assert.equal(readDraft('session:storage-off').text, '端末内のメモリに保持')
    assert.equal(readDraft('session:storage-off-empty').text, '')
  } finally {
    if (savedWindow) Object.defineProperty(globalThis, 'window', savedWindow)
    else Reflect.deleteProperty(globalThis, 'window')
    if (savedStorage) Object.defineProperty(globalThis, 'localStorage', savedStorage)
    else Reflect.deleteProperty(globalThis, 'localStorage')
  }
})

test('metadata write or removal failures cannot stop an available text overwrite or affect another conversation', () => {
  const savedWindow = Object.getOwnPropertyDescriptor(globalThis, 'window')
  const savedStorage = Object.getOwnPropertyDescriptor(globalThis, 'localStorage')
  Object.defineProperty(globalThis, 'window', { configurable: true, value: {} })
  try {
    for (const removal of [false, true]) {
      const key = `session:partial-storage-${removal}`
      const textKey = `m3e:composer:${key}`
      const entries = new Map([[textKey, '以前の長い合成下書き'], ['m3e:composer:session:unrelated-storage', '別の会話の文章']])
      Object.defineProperty(globalThis, 'localStorage', { configurable: true, value: {
        getItem: (name: string) => entries.get(name) ?? null,
        setItem(name: string, value: string) {
          if (!removal && name.endsWith(':deliveryOutcome')) throw new Error('synthetic metadata quota exceeded')
          entries.set(name, value)
        },
        removeItem(name: string) {
          if (removal && name.endsWith(':deliveryOutcome')) throw new Error('synthetic metadata removal denied')
          entries.delete(name)
        },
      } })
      writeDraft(key, { text: '編集後', images: [], ...(removal ? {} : { deliveryOutcome: 'unknown' as const }) })
      assert.equal(readDraft(key).text, '編集後')
      assert.equal(entries.get(textKey), '編集後')
      assert.equal(entries.get('m3e:composer:session:unrelated-storage'), '別の会話の文章')
      assert.equal(entries.size, 2)
    }
  } finally {
    if (savedWindow) Object.defineProperty(globalThis, 'window', savedWindow)
    else Reflect.deleteProperty(globalThis, 'window')
    if (savedStorage) Object.defineProperty(globalThis, 'localStorage', savedStorage)
    else Reflect.deleteProperty(globalThis, 'localStorage')
  }
})
