import assert from 'node:assert/strict'
import test from 'node:test'
import { folderName, formatUpdatedAt, modelIcon, orderSessions, pinnedFirst, pinnedFirstInOrder, selectWorkspace, shortenHomePath, visibleSessions } from '../web/src/features/home/data.ts'
import { createHomePreferencesStore, parseHomePreferences } from '../web/src/features/home/preferences-store.ts'
import type { SessionSummary, WorkspaceView } from '../web/src/dsh/services.ts'

function workspace(workspaceId: string, sessionIds: readonly string[] = []): WorkspaceView {
  return { workspaceId, title: workspaceId, path: `/home/test/${workspaceId}`, sessionIds, createdAt: '', updatedAt: '' }
}
function session(id: string, values: Partial<SessionSummary> = {}): SessionSummary {
  return { retainedBy: {}, id, displayTitle: id, running: false, blank: false, updatedAt: 0, ...values }
}

test('saved workspace survives replacement, and missing selections fall back to the first item', () => {
  const first = workspace('first')
  const second = workspace('second')
  assert.equal(selectWorkspace([first, second], 'second'), second)
  const replacement = { ...second, title: '新しい名前' }
  assert.equal(selectWorkspace([first, replacement], 'second'), replacement)
  assert.equal(selectWorkspace([first, second], 'deleted'), first)
  assert.equal(selectWorkspace([first, second]), first)
  assert.equal(selectWorkspace([]), undefined)
})

test('visible sessions follow workspace order and omit archives, missing IDs, and subagents by default', () => {
  const byId = {
    first: session('first'), second: session('second'), archived: session('archived'),
    child: session('child', { origin: 'subagent', parentId: 'first' }), other: session('other'),
  }
  const current = workspace('current', ['second', 'missing', 'child', 'archived', 'first', 'toString'])
  assert.deepEqual(visibleSessions(current, byId, ['archived'], false).map(item => item.id), ['second', 'first'])
  assert.deepEqual(visibleSessions(current, byId, ['archived'], true).map(item => item.id), ['second', 'child', 'first'])
  assert.deepEqual(visibleSessions(undefined, byId, [], true), [])
  assert.deepEqual(current.sessionIds, ['second', 'missing', 'child', 'archived', 'first', 'toString'])
})

test('visible sessions take the archived filter into account', () => {
  const byId = { first: session('first'), archived: session('archived'), child: session('child', { origin: 'subagent', parentId: 'first' }) }
  const current = workspace('current', ['first', 'archived', 'missing', 'child'])
  assert.deepEqual(visibleSessions(current, byId, ['archived'], false, 'show').map(item => item.id), ['first', 'archived'])
  assert.deepEqual(visibleSessions(current, byId, ['archived'], false, 'only').map(item => item.id), ['archived'])
  assert.deepEqual(visibleSessions(current, byId, ['archived'], true, 'only').map(item => item.id), ['archived'])
  assert.deepEqual(visibleSessions(current, byId, [], false, 'only'), [])
  assert.deepEqual(visibleSessions(current, byId, ['archived'], false, 'default').map(item => item.id), ['first'])
})

test('pinned rows move to the front in pin order, ignoring unknown IDs and keeping the rest in place', () => {
  const rows = [session('a'), session('b'), session('c'), session('d')]
  const ordered = pinnedFirst(rows, ['c', 'a'])
  assert.deepEqual(ordered.rows.map(row => row.id), ['c', 'a', 'b', 'd'])
  assert.deepEqual([...ordered.pinned].sort(), ['a', 'c'])
  assert.deepEqual(pinnedFirst(rows, ['missing', 'c']).rows.map(row => row.id), ['c', 'a', 'b', 'd'])
  assert.deepEqual(pinnedFirst(rows, []).rows.map(row => row.id), ['a', 'b', 'c', 'd'])
  assert.equal(pinnedFirst(rows, []).pinned.size, 0)
  assert.deepEqual(pinnedFirst(rows, ['d', 'd']).rows.map(row => row.id), ['d', 'a', 'b', 'c'])
})

test('session order keeps the workspace order or sorts by the newest update with an ID tie-break', () => {
  const rows = [session('b', { updatedAt: 100 }), session('a', { updatedAt: 100 }), session('c', { updatedAt: 300 })]
  assert.deepEqual(orderSessions(rows, 'manual').map(row => row.id), ['b', 'a', 'c'])
  assert.deepEqual(orderSessions(rows, 'updated').map(row => row.id), ['c', 'a', 'b'])
  const withUnknown = [...rows, session('unknown', { updatedAt: Number.NaN }), session('infinite', { updatedAt: Number.POSITIVE_INFINITY })]
  assert.deepEqual(orderSessions(withUnknown, 'manual').map(row => row.id), ['b', 'a', 'c', 'unknown', 'infinite'])
  assert.deepEqual(orderSessions(withUnknown, 'updated').map(row => row.id), ['c', 'a', 'b', 'infinite', 'unknown'])
})

test('updated order keeps archives in their recency slot and fronts only unarchived pins', () => {
  const rows = [session('older', { updatedAt: 100 }), session('pinnedOld', { updatedAt: 200 }), session('archived', { updatedAt: 500 }), session('pinnedNew', { updatedAt: 600 }), session('archivedPinned', { updatedAt: 700 })]
  const archived = new Set(['archived', 'archivedPinned'])
  const ordered = orderSessions(rows, 'updated')
  assert.deepEqual(ordered.map(row => row.id), ['archivedPinned', 'pinnedNew', 'archived', 'pinnedOld', 'older'])
  const { rows: placed, pinned } = pinnedFirstInOrder(ordered, ['pinnedOld', 'pinnedNew', 'archivedPinned'].filter(id => !archived.has(id)))
  assert.deepEqual(placed.map(row => row.id), ['pinnedNew', 'pinnedOld', 'archivedPinned', 'archived', 'older'])
  assert.deepEqual([...pinned].sort(), ['pinnedNew', 'pinnedOld'])
  assert.deepEqual(pinnedFirst(orderSessions(rows, 'manual'), ['pinnedOld', 'pinnedNew']).rows.map(row => row.id), ['pinnedOld', 'pinnedNew', 'older', 'archived', 'archivedPinned'])
})

test('updated dates use the local calendar day and two-digit times and dates', () => {
  const now = new Date(2026, 8, 25, 15, 30)
  assert.equal(formatUpdatedAt(new Date(2026, 8, 25, 9, 5).getTime(), now), '09:05')
  assert.equal(formatUpdatedAt(new Date(2026, 8, 24, 23, 59).getTime(), now), '2026/09/24')
  assert.equal(formatUpdatedAt(new Date(2025, 0, 2, 9, 5).getTime(), now), '2025/01/02')
  assert.equal(formatUpdatedAt(Number.NaN, now), '日時不明')
  assert.equal(formatUpdatedAt(Number.POSITIVE_INFINITY, now), '日時不明')
  assert.equal(formatUpdatedAt(1e20, now), '日時不明')
})

test('folder labels support a missing path, root, trailing separators, and Windows paths', () => {
  assert.equal(folderName('/home/test/project/'), 'project')
  assert.equal(folderName('C:\\work\\project\\'), 'project')
  assert.equal(folderName('/'), '/')
  assert.equal(folderName(), '作業フォルダなし')
})

test('home shortening respects path boundaries and requires a known home path', () => {
  assert.equal(shortenHomePath('/home/test', '/home/test'), '~')
  assert.equal(shortenHomePath('/home/test/', '/home/test/'), '~')
  assert.equal(shortenHomePath('/home/test/dev', '/home/test/'), '~/dev')
  assert.equal(shortenHomePath('/home/testing/dev', '/home/test'), '/home/testing/dev')
  assert.equal(shortenHomePath('/elsewhere/home/test', '/home/test'), '/elsewhere/home/test')
  assert.equal(shortenHomePath('/home/test/dev'), '/home/test/dev')
  assert.equal(shortenHomePath('/dev', '/'), '/dev')
  assert.equal(shortenHomePath('C:\\Users\\test\\dev', 'C:\\Users\\test'), '~\\dev')
})

test('model icons use DeepSeek identity, a Unicode initial, or a generic fallback', () => {
  assert.deepEqual(modelIcon({ provider: 'deepseek', model: 'chat' }), { kind: 'deepseek' })
  assert.deepEqual(modelIcon({ provider: 'other', model: 'deepseek-ai/DeepSeek-V3' }), { kind: 'deepseek' })
  assert.deepEqual(modelIcon({ provider: 'other', model: 'DeepSeek-V4' }), { kind: 'deepseek' })
  assert.deepEqual(modelIcon({ provider: 'other', model: ' gpt-test ' }), { kind: 'initial', initial: 'G' })
  assert.deepEqual(modelIcon({ model: '日本語モデル' }), { kind: 'initial', initial: '日' })
  assert.deepEqual(modelIcon({ model: '🚀モデル' }), { kind: 'initial', initial: '🚀' })
  assert.deepEqual(modelIcon({ provider: 'deepseek', model: ' ' }), { kind: 'generic' })
  assert.deepEqual(modelIcon({ model: 123 }), { kind: 'generic' })
  assert.deepEqual(modelIcon(null), { kind: 'generic' })
})

test('stored preferences accept only the supported values and tolerate damaged JSON', () => {
  assert.deepEqual(parseHomePreferences('{"workspaceId":"saved","showSubagents":true}'), { workspaceId: 'saved', showSubagents: true, archivedFilter: 'default', orderBy: 'manual' })
  assert.deepEqual(parseHomePreferences('{"archivedFilter":"show"}').archivedFilter, 'show')
  assert.equal(parseHomePreferences('{"archivedFilter":"only"}').archivedFilter, 'only')
  assert.equal(parseHomePreferences('{"archivedFilter":"other"}').archivedFilter, 'default')
  assert.equal(parseHomePreferences('{"orderBy":"updated"}').orderBy, 'updated')
  assert.equal(parseHomePreferences('{"orderBy":"other"}').orderBy, 'manual')
  for (const value of [null, 'broken', 'null', '[]', 'false', '{"workspaceId":12,"showSubagents":"true"}']) {
    assert.deepEqual(parseHomePreferences(value), { workspaceId: null, showSubagents: false, archivedFilter: 'default', orderBy: 'manual' })
  }
})

test('stored preferences from before both choices default the missing field', () => {
  assert.deepEqual(parseHomePreferences('{"archivedFilter":"only"}'), { workspaceId: null, showSubagents: false, archivedFilter: 'only', orderBy: 'manual' })
  assert.deepEqual(parseHomePreferences('{"orderBy":"updated"}'), { workspaceId: null, showSubagents: false, archivedFilter: 'default', orderBy: 'updated' })
  assert.deepEqual(parseHomePreferences('{"workspaceId":"saved","showSubagents":true}'), { workspaceId: 'saved', showSubagents: true, archivedFilter: 'default', orderBy: 'manual' })
  assert.deepEqual(parseHomePreferences(null), { workspaceId: null, showSubagents: false, archivedFilter: 'default', orderBy: 'manual' })
})

test('preferences persist both choices, reuse unchanged snapshots, and notify on changes only', () => {
  let saved: string | null = '{"workspaceId":"saved","showSubagents":true}'
  const storage = { getItem: () => saved, setItem: (_key: string, next: string) => { saved = next } }
  const store = createHomePreferencesStore(() => storage)
  let notifications = 0
  const unsubscribe = store.subscribe(() => { notifications++ })
  const initial = store.getSnapshot()
  assert.equal(store.getSnapshot(), initial)
  assert.deepEqual(initial, { workspaceId: 'saved', showSubagents: true, archivedFilter: 'default', orderBy: 'manual' })
  store.setCurrentWorkspace('next')
  store.setShowSubagents(false)
  store.setShowSubagents(false)
  store.setArchivedFilter('show')
  store.setArchivedFilter('show')
  store.setOrderBy('updated')
  store.setOrderBy('updated')
  assert.equal(notifications, 4)
  assert.deepEqual(JSON.parse(saved!), { workspaceId: 'next', showSubagents: false, archivedFilter: 'show', orderBy: 'updated' })
  saved = '{"workspaceId":"another-tab","showSubagents":true}'
  store.refresh()
  assert.deepEqual(store.getSnapshot(), { workspaceId: 'another-tab', showSubagents: true, archivedFilter: 'default', orderBy: 'manual' })
  unsubscribe()
  store.setCurrentWorkspace(null)
  assert.equal(notifications, 5)
})

test('blocked device storage does not prevent changing or retaining local preferences', () => {
  const store = createHomePreferencesStore(() => { throw new Error('保存できません') })
  assert.deepEqual(store.getSnapshot(), { workspaceId: null, showSubagents: false, archivedFilter: 'default', orderBy: 'manual' })
  store.setCurrentWorkspace('current')
  store.setShowSubagents(true)
  store.setArchivedFilter('only')
  store.setOrderBy('updated')
  store.refresh()
  assert.deepEqual(store.getSnapshot(), { workspaceId: 'current', showSubagents: true, archivedFilter: 'only', orderBy: 'updated' })
  const saved = '{"workspaceId":"saved","showSubagents":false}'
  const writeBlocked = createHomePreferencesStore(() => ({ getItem: () => saved, setItem: () => { throw new Error('保存できません') } }))
  writeBlocked.setCurrentWorkspace('current')
  writeBlocked.refresh()
  assert.equal(writeBlocked.getSnapshot().workspaceId, 'current')
})
