# 08 設定タブ

## 目的

この端末だけの設定と、DSH 全体の設定を変えられるようにします。DSH の設定は、DSH が返す定義（スキーマ）から画面を自動で作り、項目を 1 つずつ手で描かないようにします。

## 担当する画面

| Canvas の画面 id | 名前 |
|---|---|
| `settings` | 設定 |
| `settingsModel` | 設定の詳細（モデル） |
| `keys` | 提供元と API キー |
| `keyEntry` | API キーの入力 |
| `appearance` | 外観 |

仕様は `docs/ui-spec.md` の「設定タブ」「そのほかの一覧と設定の画面」の節です。

## 担当するファイル

- `web/src/features/settings/` の全部（`routes.tsx` と `SettingsScreen.tsx` は 00 の仮の部品を置き換える）
- `tests/08-*.test.ts`
- `e2e/settings-*.spec.ts`、`e2e-dsh/settings-general.spec.ts`（「一般」の行の試験）
- この設計書の「実装メモ」

## 入口

`routes`：`#/settings`（下のタブ、`tab: 'settings'`）と `#/settings/<ページ>`。

## 画面の中身

### 設定のトップ

- **この端末**
  - 「今の画面に戻す」：00 の `backToClassic()`。押す前に確認のダイアログ（「この端末では DSH の標準の画面を使います。M3E の画面には、標準の画面の設定からいつでも戻れます」）を挟みます。
  - 「外観」：今の値を 2 行目に出し、タップで外観のシート。
- **一般**：標準の画面の「設定 → 一般」にある項目のうち、M3E でも変えられるものです。「この端末」と「DSH の設定」の間に置きます。値は標準の画面と同じ名前空間・同じ項目に保存するので、どちらで変えてももう一方に反映されます。Host がその名前空間や項目を返さないときは、その行を出しません。
  - コーディングビューを表示（スイッチ）：`ui-settings` の `enabled`（既定 `true`）。オフにすると、モードの一覧と新しい会話から PTC と最小が隠れます（Issue #143 の動き。下の実装メモ）。
  - 作業の詳細（選択）：`ui-chat` の `transcriptView`。簡潔（`compact`）・標準（`standard`）・詳細（`detailed`）・完全に展開（`verbose`）。保存した値がないときは、標準の画面（デスクトップアプリ以外）と同じく「詳細」を選んだ形で出す。古い保存値の `normal`・`expanded` は「詳細」として出す。
  - 折りたたむタイミング（選択。標準の画面では「作業の詳細を折りたたむタイミング」）：`ui-chat` の `collapseTiming`。回答の完了時（`completion`、既定）・次のメッセージの送信時（`next-input`）。
  - パフォーマンスと使用状況（選択）：`ui-chat` の `performanceUsage`。簡潔（`compact`）・詳細（`detailed`、既定）。
  - 言語（選択）：`locale` の `preference`。「端末の言語に合わせる」（保存値を消す。未設定）・日本語（`ja`）・English（`en`）・中文（`zh`）。日本語は M3E が足した選択肢で、標準の画面は登録がないとしてブラウザの言語に従う。ほかの言語タグが保存されていれば、そのタグも選択肢に足して出す。選ぶと M3E の画面もその言語に切り替わる（再読み込みなし）。
  - リンクの開き方（`ui-chat` の `linkOpening`）は出さない。理由は下の実装メモ。
- **DSH の設定**：次の 5 行です。2 行目には、そのページの主な値を出します。

| 行 | ページ | 名前空間 |
|---|---|---|
| モデル | `#/settings/models` | `agent-default-model`、`subagent-model-selection` |
| 権限 | `#/settings/permission` | `permission` |
| エージェント | `#/settings/agent` | `agent-presets`、`agent-loop` |
| 提供元と API キー | `#/settings/providers` | `llm-*`（`llm-deepseek`、`llm-pi-ai`、`llm-retry` など、`llm-` で始まるもの全部）と認証情報 |
| Web 検索とシェル | `#/settings/tools` | `web`、`web-search-deepseek`、`web-deepseek-api`、`shell`（`locale` は「一般」の言語の行に移した） |

- `ui-` で始まる名前空間と `ui-onboarding` は、今の画面向けなので出しません。例外は、上の「一般」に専用の行がある名前空間（`general.ts` の `generalRows`、`schema.ts` の `generalNamespaces`）で、これも汎用のページには出しません。上の表にない名前空間が `describe()` にあれば、「そのほか」の行を足し、名前空間の名前をそのまま見出しにしたページで出します。
- 一番下に、この UI の版（`package.json` の `version`）と、接続先の DSH の版（取れれば）を小さく出します。

### 設定の詳細ページ（スキーマから作る）

- ページに含まれる名前空間ごとに、見出しを付けて項目を並べます。
- `describe()` の各名前空間の `schema`（JSON）から、項目の種類を読み取って部品を選びます。

| スキーマの種類 | 部品 |
|---|---|
| 真偽 | スイッチ |
| 文字 | テキスト欄 |
| 数値 | 数値のテキスト欄（最小・最大があれば検査） |
| 決まった値のどれか（定数の組み合わせ） | ドロップダウン |
| 入れ子のまとまり | 小見出しを付けて、中の項目を並べる |
| 配列、辞書、そのほか | 値を読み取り専用で出し、「この項目は今の画面で編集してください」と添える |

- 項目の説明（スキーマの説明文）は補足として小さく出します。
- 補足の最後に、反映のタイミングを出します。`applies` が `live` なら「すぐ反映されます」、`restart` なら「DSH の再起動後に反映されます」。
- ユーザーが上書きした項目（`user` に値がある）には「既定値に戻す」を出します。
- 値を変えたら、すぐに `settings.update(ns, patch, revision)` で保存します。文字と数値は、入力が止まって 600ms 後か、欄から離れたときに保存します。
- `writable` が false なら、すべての項目を無効にし、上に「この DSH では設定を変更できません」と出します。
- 保存が競合したら（`settings/conflict`）、スナックバーで「ほかの場所で設定が変わりました。読み直しました」と出して、その名前空間を読み直します。イベント `settings/document-updated` が来たときも読み直します。
- 保存が拒否されたら（`settings/rejected`）、その項目の下に理由を出します。
- 秘密の値（`secrets`）の項目は、値を出さず「登録済み」「未登録」だけを出します。

### 提供元と API キー

- 提供元ごとに 1 行。2 行目は「API キー：登録済み」「API キー：未登録」「キーは不要」のどれかです。
- キーが要る提供元の行をタップすると、キーの入力のシートを開きます。提供元ごとの詳しい設定（`llm-*` の名前空間）は、同じページの下にスキーマから作ります。
- **キーの入力のシート**：テキスト欄（入力中は伏せ字、目のアイコンで表示の切り替え）、「保存」（`credentials.set`）、登録済みなら「登録を消す」（`credentials.unset`、確認を挟む）。保存したら欄を空にし、二度と表示しません。

### 外観

- シートで「端末の設定に合わせる」「ライト」「ダーク」を選びます。00 の `useAppearance()` と `setAppearance()` を使い、選んだ瞬間に画面の明暗が変わります。
- この設定はこの端末だけのものです。DSH 本体の `ui-theme` とは共有しません（2026-09-25 の決定）。

## 使う DSH の窓口

- `ctx.remote.settings`：`describe()`、`update()`、`replace()`、イベント `settings/document-updated`（API の調査メモ §6）
- `ctx.remote.credentials`：`describe(refs)`、`set(ref, value)`、`unset(ref)`。型は未確認です（下の「未確認のこと」）
- 00 の `backToClassic()`、`useAppearance()`、`setAppearance()`、`openSheet`、`openDialog`、`showSnackbar`

参考の実装：今の画面の `dsh-client-ui-settings`、`dsh-client-ui-settings-general`、`dsh-client-ui-settings-models`、`dsh-client-ui-theme`。スキーマの JSON の読み方はここに合わせてください。

## 偽データ（mock.ts）

- 上の表の名前空間を揃えた `describe()` の結果。各名前空間に、真偽、文字、数値、決まった値のどれか、入れ子、配列の項目を最低 1 つずつ含めます。`applies` は `live` と `restart` を混ぜます。
- `llm-deepseek` はキー登録済み、`llm-pi-ai` は未登録、ローカルはキー不要。
- `?mock&scenario=settings-readonly`：`writable: false`。`scenario=settings-conflict`：最初の保存で `settings/conflict` を返します。

## テスト

`tests/08-settings.test.ts` で、次の純粋な処理を確かめます。

- スキーマの JSON から、項目の一覧と部品の種類を作る処理（上の表の全種類と、知らない種類）
- 名前空間を 5 つのページと「そのほか」に振り分ける処理（`ui-` を除く、`llm-` をまとめる）
- 保存する差分（patch）の組み立てと、「既定値に戻す」ときの差分

## 完了条件

- `?mock` で、トップの 2 区分、5 つのページと「そのほか」、各種の項目の編集と保存、読み取り専用、競合、キーの登録と削除、外観の切り替え、今の画面に戻す（確認のダイアログまで）が動きます。
- `pnpm typecheck`、`pnpm test`、`pnpm build` が通ります。

## 未確認のこと

- スキーマの JSON の正確な形（cordis の `Schema` の `toJSON()`）。参考の実装で確かめてください。
- `ctx.remote.credentials` の正確な型（API の調査では型ファイルを読めず、README からの推測です）。
- 認証情報の参照（`ref`）と `llm-*` の名前空間の `secrets` の対応。
- DSH の版を取る窓口があるか。なければ DSH の版は出しません。

## 実装メモ

（実装した担当が書き足します）

### 2026-10-05：Issue #16 カスタムプロバイダーの契約と実装

対象は **0.2.0-rc.2 のみ**。第1回の画面案を基に、追加・編集の専用フォームを実装した。過去のメモの未確認事項は、この節で確認できた範囲を更新する。Issue #18 を通常のマージで取り込み、その配布用設定や scripts は変更していない。キーの RPC を呼ぶ既存関数を再利用し、保護対象のパッケージは読んでいない。

#### 配布物で確かめた契約

以下の `P/` は、リポジトリ内の `tmp/dsh-integration/dsh-0.2.0-rc.2/node_modules/@deepseek-ai/` を指す。5 パッケージを個別に指定して読んだ。上流 master の内容をそのまま契約としない。

| 事実 | 実物のパスと行 |
|---|---|
| 設定先は `llm-pi-ai` の `providers[ID]` | `P/dsh-llm-pi-ai/lib/index.js:1017–1051, 2513–2535` |
| 標準画面の追加は開いた revision を付けた `settings.mutate`。設定成功後にキーを別保存 | `P/dsh-client-ui-settings-models/lib/client.js:1210–1277` |
| 標準画面の編集は変更箇所の `set/unset` と revision。ID は固定 | 同 `client.js:1455–1489, 1511–1524, 1586–1626` |
| `update` は再帰マージ、配列は置換。`mutate` は保存済みの層への path 操作 | `P/dsh-settings/lib/index.js:190–218, 276–291, 470–499` |
| revision は名前空間・Host プロセス単位。異なる値は `settings/conflict`、検証拒否は `settings/rejected` | `P/dsh-settings/lib/index.js:500–514`、`P/dsh-api-settings-controller/lib/index.js:391–423, 451–504` |
| providers の `sKey` は string、pattern なし。標準画面の小文字英字・ハイフン制限は UI 独自 | `P/dsh-llm-pi-ai/lib/index.js:1051`、`P/dsh-client-ui-settings-models/lib/client.js:1186–1204` |
| プロトコルは schema の `api` の const union。別の候補 RPC は不要 | 同 `client.js:938–958`、`P/dsh-llm-pi-ai/lib/index.js:802–816, 1020` |
| カスタムの判定は directory の `declared: true` と設定先。稼働中かどうかではない | `P/dsh-llm-pi-ai/lib/index.js:2506–2529` |
| スキーマ以外にもモデル ID の重複、カタログ外の必須項目などを解決時に検査 | 同 `index.js:638–711, 1085–1154` |
| volatile 設定の更新で adapter、directory、catalog が変わる | 同 `index.js:2537–2561, 2588–2597, 2616–2637` |
| adapter の登録変更で `llm/adapters-updated`、設定変更で `(ns, revision)` の `settings/document-updated` | `P/dsh-llm/lib/index.js:1879–1893, 1910–1963`、`P/dsh-settings/lib/index.js:413–461` |
| `apiKeyEnv` はキーの参照名。導出式は ID を大文字化し英数字以外の連続を `_` にして `_API_KEY` を付ける | `P/dsh-client-ui-settings-models/lib/client.js:938–940`、`web/src/features/settings/providers.ts:47` |
| キーの RPC は参照名の検査、状態の照会、登録・削除を別々に扱う | 呼出し側の `P/dsh-api-settings-controller/lib/index.js:62–70, 161–216`。保存実装の保護対象パッケージは対象外 |
| 伏せる処理はスキーマの role に従う。pi-ai の `apiKeyEnv`、`headers` は自動的に伏せられる項目ではない | `P/dsh-settings/lib/index.js:22–84`、`P/dsh-llm-pi-ai/lib/index.js:1017–1051` |

Issue の版表記は 0.2.0-rc.2 に読み替えた。master を根拠とする保存契約はこの版でも成立した。一方、ID の pattern、HTTP URL の強制、未知項目の一律拒否は Host の条件ではなかった。

#### フォームが扱うスキーマ

根拠は `P/dsh-llm-pi-ai/lib/index.js:1001–1051` と `lib/types/config.d.ts:51–161`。スキーマの任意と、カタログ外の提供元で必要になる条件を区別する。

| 項目 | 型と条件 |
|---|---|
| ID（辞書キー） | string。空文字は解決時に拒否。sKey の pattern はない |
| `displayName` | 任意 string。指定した空文字は拒否。フォームの空欄は省略／既存上書きの unset |
| `baseURL` | 任意 string だがカスタムでは非空が必須。URL の pattern はなく、HTTP の制限もない |
| `api` | 任意 const union だがカスタムでは必須。`openai-completions` / `openai-responses` / `anthropic-messages`。フォームは応答から列挙する |
| `models` | 配列。カタログ外で解決できるモデルが 0 件なら拒否 |
| モデル `id` | 必須 string、非空、同じ一覧内で一意。空白だけの文字列は Host で受理 |
| モデル `name` | 任意 string |
| `contextWindow`, `maxTokens` | 任意 number、1 以上の整数。`maxTokens <= contextWindow` という制約はない |
| `input` | `text` / `image` の配列。省略・空配列は継承。フォームの「提供元の既定値を使う」で省略する |
| `apiKeyEnv` | 任意の参照名。キー本体を設定へ入れない |

フォームの対象外は `headers`、`modelOverrides`、`compat`、`reasoningEfforts`、`thinkingBudgets`、各種既定値、timeout、transport、retryPolicy 等。モデルの `reasoningEfforts` は false または off/minimal/low/medium/high/xhigh/max をキー、string/null を値とする辞書。未知の項目と合わせて保持する。スキーマの詳細を高度なフォームへ展開することはしない。

#### 隔離した実 DSH への追加実入力

`tmp/issue16-observe/contract.spec.ts` を既存 e2e-dsh の fixture で実行した。HOME と DSH_HOME は tmp、loopback の Host、偽 LLM を使用。設定 RPC のみで **35 入力**を観測し、受理した入力は毎回 unset で復帰、拒否した入力は保存済みの層が変わらないことを確認した。結果は `tmp/issue16-observed.json`。一時 spec はコミットしない。

| 入力 | 結果 |
|---|---|
| キー参照なしの有効なカスタム | 受理 |
| ID：大文字、下線、点、数字始まり、空白を含む、スラッシュ、空白のみ | すべて受理 |
| ID：`constructor`, `prototype` | 受理。既存 M3E の安全な path アクセスが拒否する予約名なので、この画面では編集対象外 |
| ID：空文字、`__proto__` | `settings/rejected` |
| URL：`not a url`、FTP、空白のみ | 受理。保存可能という結果であり、通信に使えることの確認ではない |
| URL：空文字、省略 | `settings/rejected` |
| models：空配列、省略 | `settings/rejected` |
| モデル ID：空文字、欠落、重複 | `settings/rejected` |
| モデル ID：空白のみ | 受理 |
| contextWindow 0、maxTokens 1.5 / 1.000000001 | `settings/rejected` |
| input：空配列、image のみ | 受理 |
| input：audio | `settings/rejected` |
| api：未知値、省略 | `settings/rejected` |
| 未知の提供元項目、未知のモデル項目 | 受理し保持 |
| displayName：空文字 | `settings/rejected` |
| 表示名、モデル名、context 4096、maxTokens 8192、text/image | 受理 |

既存 `tests/support/settings-write-cases.ts` と `e2e-dsh/rpc.spec.ts:183–202` の 37 入力には、pi-ai の表示名の成功と空文字拒否、defaultInput 空配列拒否、未知項目受理、旧フィールド拒否、reasoningEfforts のキー検証がある。これは設定 RPC の確認で、今回の追加・編集フォームとは分けて扱う。

追加直後の `llm.listProviders`、`listConfigurableProviders`、`session.modelCatalog` に新しい ID とモデルが現れた。作成時は adapter 通知 2 回と設定通知、モデル名だけの編集では設定通知だけを観測した。モデル変更でも adapter 通知が必ず来るとは扱わない。編集後のカタログとページ再読み込み後の値も一致し、再起動なしで反映した。Host 再起動を挟む永続性と実際の外部提供元への接続は未検証。

#### 下書き、差分、キーの別保存

追加は次の形で、**フォームを開いて取得した revision** を送る。

```ts
settings.mutate('llm-pi-ai', [
  { op: 'set', path: ['providers', id], value: { api, baseURL, models /* 任意の表示名・キー参照 */ } },
], openedRevision)
```

編集は `['providers', id, 'displayName' | 'baseURL' | 'api']` の変更項目だけを `set/unset`。モデル一覧は元の各行全体を deep clone し、既知の編集項目だけを変更する。変化があった場合だけ `['providers', id, 'models']` を配列で set する。名前空間全体とプロフィール全体の置換、未変更の配列の再送はしない。伏せた値のパス、disabled、password role と対象が交差するならその欄を変更不可とし、安全な他の欄だけの編集を許可する。

キー入力があれば、参照未指定のときだけ `apiKeyEnv` を設定差分へ追加し、設定成功後に既存 `createProviderStore` の `load` と `save(row, input)` を呼ぶ。参照と登録可能状態を再確認し、キー RPC へ参照名と今回の入力だけを送る。キー空欄では登録済みキーを維持し、キー RPC を呼ばない。標準画面と同じ保存順。登録済みの値を取得・表示する経路は作らない。

`custom-provider-store.ts` は loading / blocked / editing / savingSettings / savingKey / keyFailed / stale / unknown / saved を区別する。同期的な busy で二重送信を止め、revision を通知で勝手に進めない。外部変更・競合では再読込と確認を求める。設定成功後は ID と保存応答を確定し、keyFailed の再試行はキー保存だけ。再作成はしない。応答を失った場合、または明確な拒否コード以外のエラー応答の場合は追加を再送せず、「保存結果を確認」で対象を取得し、既存なら編集へ切り替える。

`createKeyDraft` の送信開始時消去・表示状態初期化・dispose を再利用する。再読込時の `clear` は購読を保って入力だけを消す。キャンセル、Escape、ルート離脱で入力と未送信キーを破棄する。処理は閉じた後も送信済み設定の完了まで追跡し、完了後に一覧を更新するが、閉じたフォームからキーを続けて送らない。接続世代と取得 ticket で古い応答を無効化する。

#### ファイル、偽データ、判断

- 新規：`CustomProviderSheet.tsx`（共通フォーム）、`custom-provider.ts`（下書き・検証・差分）、`custom-provider-store.ts`（保存制御）、`mock-custom.ts`（失敗シナリオ）。いずれも `web/src/features/settings/`。
- 変更：同フォルダの `ProvidersPanel.tsx`、`providers.ts`、`settings.css`、`mock.ts`、`mock-models.ts`、`mock-validation.ts`。schema の復号、valueAt、既存キー操作、field-access、openFullSheet を再利用。ルーターと共有 overlay は変更しない。
- 試験：`tests/08-custom-provider.test.ts`、`e2e/settings-custom-provider.spec.ts`、`e2e-dsh/custom-provider.spec.ts`。既存 M5 の入力へ実 Host で必須の api/baseURL を足し、directory の declared を明示した。期待を緩めた修正ではない。`tests/18-pack.test.ts` の偽モジュール一覧に mock-custom を追加。
- 偽データ：既存 settings-readonly と、新規 custom-no-namespace / custom-unavailable / custom-rejected / custom-conflict / custom-response-lost / custom-slow。custom-partial のキー拒否処理への接続は一度保護フックで停止したが、`tmp/handoff-issue16-01.md` を指示役が `ad192ba` で適用済み。custom-slow はレビュー対応で固定 800ms を廃止し、試験側が開始を観測して保留応答を解放する。
- 全画面シートを採用。専用ルートは不要な履歴と復元を増やすため採用しない。共通シートを開くだけでは初期高さが半分になることを実測したため、このフォームを持つシートだけに動的画面高を CSS 指定した。ほかのシートを変更しない。
- 終了経路を統一できる破棄確認の仕組みが共有 overlay にないため、今回も破棄確認なし。送信開始後は取消できないことを表示する。
- モデルの index ごとの操作より、変更時だけ配列を送る案を採用。継承と削除後の index 移動を避け、元の未知項目を保持する。保護された子がある配列は置換しない。
- ID は標準画面独自の正規表現を採用せず、非空・重複・既存 M3E path が拒否する 3 予約名を検査する。ID の空白は保存どおり扱う。URL はレビューの明示指示を優先し、前後の空白を除いた HTTP/HTTPS の URL だけを保存する。Host の受理範囲を再現する偽データは変更しない。キー付きの保存には参照名の形式と、明示された名前も含む実際の保存先の重複検査を別に行う。

#### 受け入れ条件と検証の対応

| 条件 | 単体 | 偽データ e2e | 実 DSH e2e |
|---|---|---|---|
| 1 追加・編集 | I16 ops | UI lifecycle | real lifecycle、キーあり・なし |
| 2 値と未編集設定の保持 | I16 ops | UI lifecycle、モデル選択不変 | real lifecycle、再読込・他提供元・未知項目・既定値 |
| 3 入力検査 | I16 validation | UI lifecycle、欄エラーとフォーカス | 一時 spec の 35 入力 |
| 4 キーの維持・消去 | I16 partial / close / unknown | UI dismiss / refused / late | real lifecycle / failures |
| 5 保存失敗の分類 | I16 refusals / partial / unknown | UI blocked / refused / lost / partial（接続差分は適用済み） | real failures、別ページ競合と設定だけ成功 |
| 6 取消・連打・終了 | I16 partial / close | UI dismiss / late、4 終了経路 | real failures の閉じて再編集 |
| 7 狭い画面と回帰 | 既存キー・モデル試験 | 390px と 375×420px、実寸の全画面高と横幅 | 新モデルの選択候補。iOS のキーボード実機は未確認 |
| 8 品質 | typecheck / test | 全偽データ e2e | build、全実 DSH e2e を 2 回 |

追加・変更した各試験は次の故障注入で確認した。表の試験名は先頭の識別子。各回で対象だけを実行し、追跡ファイルへの変更は `git restore` で戻した。一時 spec の準備値は元の値へ戻して再実行した。ブラウザーの短い viewport をソフトウェアキーボード実機確認の代用とはしない。

| 試験 | 一時的な故障（本体または偽データ） | 結果 |
|---|---|---|
| I16 ops | custom-provider のモデル変換を既知キーだけに制限 | 未知の extra が消えて失敗 |
| I16 validation | 検証が常に空のエラーを返す | 空 ID のエラーがなく失敗 |
| I16 partial | 保存済みフラグと編集モードを消して再作成 | 設定書込み 2 回になり失敗 |
| I16 partial（入力消去） | createKeyDraft の送信時 draft/visible 初期化を削除 | 入力が残って失敗 |
| I16 refusals | 競合時に同じ mutate を自動再送 | 書込み 2 回になり失敗 |
| I16 close | dispose を空にする | 閉じた後も保存が成功扱いになって失敗 |
| I16 unknown | 再取得後も新規扱いにする | 編集へ切り替わらず失敗 |
| I16 unknown（エラー応答） | 不明なエラーコードの分類を削除 | unknown でなく editing になって失敗 |
| I16 partial（参照重複） | 導出参照名の重複検査を削除 | 他の提供元と同じキーを保存できてしまい失敗 |
| 既存 M5 | mock-models の declared を false にする | directory の厳密一致で失敗 |
| pack の全偽モジュール検査 | 偽の chunk 入力の mock-custom を命名規則外の custom-provider に変える | 規則外のファイルが検出されず失敗。scripts 本体は変更しない |
| UI lifecycle | 入力検証を無効化 | ID 重複エラーが表示されず失敗 |
| UI dismiss | 終了処理で submit も呼ぶ | キャンセル時の書込みが 0 → 1 となり失敗 |
| UI blocked | 名前空間なしの準備を削除 | 追加ボタンが有効になって失敗 |
| UI refused | 競合時に自動再送 | 書込み 2 回になり失敗 |
| UI lost | 再取得後も新規扱い | 保存済み ID の欄が空になって失敗 |
| UI late | dispose を空にする | 閉じた後にキーが登録済みとなり失敗 |
| UI lifecycle / dismiss / refused / lost / late（初期フォーカス） | シートが開いた後の見出しへの focus を削除 | 5 件とも見出しのフォーカス検査で失敗 |
| UI partial | 第2回の時点では接続差分が未適用 | `ad192ba` で適用済み。今回の故障注入の結果は下記のレビュー対応に記録 |
| real lifecycle | モデルの未知フィールドと reasoningEfforts を落とす | 保存・再読込後の配列の厳密一致で失敗 |
| real failures | 外部設定通知の処理を無効化 | 別ページ変更後の競合案内がなく失敗 |
| 一時 spec | 有効入力のモデル準備を空配列に変える | valid-no-key が拒否となり失敗 |

#### 第2回の最終検証（2026-10-05、接続差分適用前）

故障注入を戻した最終コードで実行した。結果を緑にするための skip、期待失敗への変更、アサーションの緩和は行っていない。

| 実行 | 結果 |
|---|---|
| `pnpm typecheck` | 成功 |
| `pnpm test` | 1,052 件成功、失敗・skip 0 |
| `pnpm build` | 成功。配布側の本番偽モジュール混入検査も通過 |
| 全偽データ e2e | 165 成功、1 失敗、skip/flaky 0、482.0 秒。既存ポートを避け、一時設定で 5216 を使用 |
| 全実 DSH e2e 1 回目 | 36 件が想定どおり、unexpected/skip/flaky 0、286.7 秒 |
| 全実 DSH e2e 2 回目 | 同じく 36 件が想定どおり、unexpected/skip/flaky 0、207.1 秒 |
| 追加実測の一時 spec | 1 件成功、35 入力（受理 19、拒否 16）と反映・通知・再読込、62.4 秒 |

実 DSH の各 36 件には、変更していない既存の期待失敗（Host が止まったままの場合の切断表示）1 件を含む。通常成功は各 35 件。LLM とキーは架空のもので、外部提供元への実通信ではない。

当時の偽データの失敗は `e2e/settings-custom-provider.spec.ts:140` の `I16 UI partial: 設定だけ成功したらキーだけ再試行する` だけだった。保護フックで止まった `web/src/features/settings/mock.ts` の接続差分は、`tmp/handoff-issue16-01.md` を指示役が `ad192ba` で適用して解消した。同コミットで指示役が型・単体 1,052 件・ビルド・配布検査・偽データ 166 件・実 DSH 2 回を確認済みとの引き継ぎを受けた。今回の再実行と故障注入は下記に分けて記録する。

第2回の判定と結果は `tmp/handoff-issue16-implementation.md`、`tmp/issue16-mock-final.json`、`tmp/issue16-real-run1.json`、`tmp/issue16-real-run2.json` に保存した。その後レビューで指摘された不足と最新の判定は下記のレビュー対応を参照する。iOS 実機のソフトウェアキーボードは引き続き未確認。

範囲外：カタログの提供元追加、提供元削除・ID 変更、OAuth、モデル自動取得、接続試験、高度な設定、他の DSH 版。保護対象パッケージを読むことと、利用者の DSH を操作することは実施していない。

### 2026-10-05：Issue #16 レビューへの対応

`ad192ba` の引き継ぎ差分を含む状態から修正した。対応パッケージの追加や、Issue #18 の配布用ファイルの変更はない。

#### 指摘ごとの変更

| 指摘 | 対応 |
|---|---|
| 1 明示された参照名との衝突 | `custom-provider-store.ts` は directory と全名前空間から `providerRows` で実際の参照先を取得し、新規とキーなし提供元へのあと付けの両方を検査する。`providers.ts` の再照会でも、初めて参照を付ける保存では他の行と同じ保存先を使わない。部分成功後の再試行もこの条件を保持する |
| 2 数字始まり ID が一括照会を壊す | Host の参照名検証を `validKeyReference` へ写し、不正な名前を照会から除外する。当該行だけを変更不可とし、理由を行とフォームへ出す。キー付きの保存は設定送信前の欄エラーで止める。既存提供元の状態・登録・削除は単体と実 DSH の画面で確認 |
| 3 閉じた後に再照会からキーを送る | 既存 `ProviderStore.save` に省略可能な `canSend` を追加。カスタムフォームは active・接続・接続世代を渡し、再照会の完了後とキー送信直前の両方で判定する。オプションを渡さない既存の登録経路は維持。専用試験は `tmp/handoff-issue16-02.md` へ回し、その後 `e9f4e3a` で適用済み。今回、正常実行と `canSend` を常に true にする変異の検出を確認 |
| 4 URL と ID の形式 | URL は HTTP/HTTPS のみ。前後の空白を除いて検証・保存する。ID は非空・重複・予約名を検査し、英字始まりを推奨。数字始まりなどはキーなしで許可する。キーの参照名を別に検査する |
| 5 固定 800ms の待ち | `mock-custom.ts` に試験用の保留・解放を設けた。UI late は開始件数 1、保存中表示、閉じてフォームが消えたことと行が未作成なことを確認してから解放する |
| 6 古い適用待ちの記述 | UI 仕様とこのメモを `ad192ba` で適用済みに更新。第2回の失敗結果は当時の記録と明示し、今回の結果と区別する |
| 7 UI partial の故障注入 | 設定の再送、新規再作成、キー送信の省略、最初の拒否の無効化を個別に確認する。結果は下表 |
| 8 新規・変更試験の故障注入 | 正常状態で通過後、各試験に対応する本体または偽データを壊して実行し、`git restore` で戻す。未適用の専用試験は成功実績に数えない |

根拠：`P/dsh-api-settings-controller/lib/index.js:55–70` は参照名を `^[A-Za-z_][A-Za-z0-9_]*$` と定義し、describe の配列内にも同じ検査を適用する。設定の ID 自体の制約とは異なる。実物の保存処理を含む保護対象パッケージには触れていない。

ID を標準画面の小文字英字・ハイフンだけへ制限する案は不採用。キーなしのローカル提供元や既存の大文字・数字始まりの ID を扱える契約を維持するため。画面から新規にキーを使う場合は有効な導出参照が必要で、既存提供元に有効な参照名が明示されていればそれを優先する。既に明示的に共有している参照は変更しない。

URL は Issue の明示要件を優先する。`http://` / `https://` のプレフィックスと URL の解析を検査し、localhost、IPv4、IPv6、ポートを許可。前後の空白を拒否する案より、入力欄に貼り付けたときの余分な空白だけを除く案を採用した。未変更の既存フィールドを自動的に正規化して書き直すことはしない。Host が FTP や空白だけの文字列も受理するという実測と、その偽データは維持する。フォームの条件とは目的が異なる。

#### レビュー対応で壊して確かめた表

| 試験 | 故障の場所と内容 | 検出 |
|---|---|---|
| I16 ops | custom-provider の URL 保存時の trim を削除 | 差分の URL に前後空白が残り失敗 |
| I16 validation | validBaseURL が常に true | 不正 URL の欄エラーがなく失敗 |
| I16 explicit reference | custom-provider-store の参照比較を ID からの導出だけへ戻す | 衝突する追加が成功して失敗 |
| I16 numeric ID | providers の照会対象から不正参照を除外しない | DeepSeek が登録済みでなく unknown となり失敗 |
| I16 numeric ID（欄検査） | custom-provider-store の参照名の形式検査を無効化 | キー欄のエラーがなく失敗 |
| I16 reference recheck | providers の送信前の共有検査を削除 | 共有を作るキー保存が成功して失敗 |
| I16 UI URL | validBaseURL が常に true | 不正 URL の保存が通り、欄エラーが出ず失敗 |
| I16 real numeric ID | providers の照会対象から不正参照を除外しない | 作成後、既存 DeepSeek の「登録済み」が「確認できません」となり失敗 |
| I16 UI late | custom-provider-store の dispose を空にする | 閉じてから保留応答を解放するとキーが登録済みとなり失敗 |
| I16 UI partial（設定再送） | 保存済みでも同じ URL の mutate を送る | 設定書込みが 1 回でなく 2 回となり失敗 |
| I16 UI partial（新規再作成） | 保存済みフラグを消し editing を false に戻す | 設定書込みが 2 回となり失敗 |
| I16 UI partial（キー未送信） | keyFailed からの再試行でキー保存の分岐を通らない | 登録済みでなく未登録のままで失敗 |
| I16 UI partial（拒否なし） | mock-custom の rejectKeyOnce が常に false | 部分成功の案内が出ず失敗 |
| I16 key recheck close | 前回は試験差分自体が保護フックで停止 | `tmp/handoff-issue16-02.md` は指示役が `e9f4e3a` で適用済み。正常実行も成功。今回の M47（参照先書込み待ち）とは別の待機境界 |

すべての実施した故障を `git restore` で戻し、本体・試験には故障を残していない。今回追加・期待変更した試験は上表に 1 件ずつ載せた。I16 UI partial は既存試験の条件を変更せず、指定の 4 種類の故障を個別に検出した。

#### レビュー対応後の全体検証と残り

| 実行 | 結果 |
|---|---|
| `pnpm typecheck` | 成功 |
| `pnpm test` | 1,055 件成功、失敗・skip 0 |
| `pnpm build` / `pnpm check:pack` | 成功。配布検査は 19 ファイル |
| 全偽データ e2e | 167 件成功、unexpected/skip/flaky 0、516.8 秒 |
| 全実 DSH e2e 1 回目 | 通常成功 36 件＋既存の期待失敗 1 件、unexpected/skip/flaky 0、296.0 秒 |
| 全実 DSH e2e 2 回目 | 通常成功 36 件＋同じ期待失敗 1 件、unexpected/skip/flaky 0、253.5 秒 |

結果は `tmp/issue16-review-mock-final.json`、`tmp/issue16-review-real-run1.json`、`tmp/issue16-review-real-run2.json`。実 DSH は隔離した 0.2.0-rc.2、LLM とキーは架空値。未適用の試験を skip で除いた結果ではなく、追跡中の試験を全件実行した結果である。

| 受け入れ条件 | 前回終了時（handoff 02 適用前）の判定 |
|---|---|
| 1 追加・編集 | 達成。数字始まりのキーなし作成も実 DSH で確認 |
| 2 再表示・他設定・モデル選択の保持 | 達成。明示参照との衝突を新規・あと付けで検査 |
| 3 入力検査 | 達成。URL の形式と正規化、ID、キー参照名の条件を分離 |
| 4 キー維持・伏せ字・入力破棄 | 本体は修正済み。キー保存内部の再照会待ちで送信 0 件を確かめる専用試験は引き継ぎ |
| 5 失敗の偽データ検証 | 達成。設定だけ成功も全体実行で成功 |
| 6 キャンセル・連打・再オープン・終了 | 設定保存待ちの終了は確認。キー内部の再照会待ちは専用試験を引き継ぎ |
| 7 狭い画面・キーボード・既存機能の回帰 | 390px、375×420px、既存キー・モデル操作は確認。実機キーボードは未確認 |
| 8 試験追加・品質 | 型・単体・ビルド・配布・全 e2e は成功。追加できなかった専用試験 1 件とその故障注入は未完了 |

指摘 3 の試験追加は、前回の保護フック拒否後に `tmp/handoff-issue16-02.md` へ回し、指示役が `e9f4e3a` で適用済み。上記の件数と受け入れ表は適用前の履歴であり、最新の残りは次の再レビュー対応を参照する。

今回の詳細報告は `tmp/handoff-issue16-review-fixes.md`。iOS 実機のキーボード、今回追加した設定の Host 再起動を挟む保持、外部提供元との実通信は引き続き未検証。検索コマンドの引用符なし glob が形式で拒否された 1 回は、対象ファイルを明示して読み直した。保護対象のパスと禁止された操作には触れていない。

### 2026-10-05：Issue #16 再レビュー・変異監査への対応

`e9f4e3a` から開始し、`git fetch origin` 後、`origin/main`（`23e8ec6`、v0.0.8）を通常のマージ `739606e` で取り込んだ。文書に衝突はなく、main の配布・リリースの記述を保持した。

#### 参照先の所有と衝突の契約

`P` は `tmp/dsh-integration/dsh-0.2.0-rc.2/node_modules/@deepseek-ai`、`L` は同じ node_modules の `@earendil-works/pi-ai/dist`。

- `P/dsh-llm-pi-ai/lib/index.js:727–730,840–859`：標準のカタログ提供元は標準の認証探索を保持する。独自提供元の認証と区別する。
- `P/dsh-llm-pi-ai/lib/index.js:2088–2096`：標準の認証探索が環境名を要求すると、DSH の保存済みキーを先に探す。設定に明示名がないことは、保存先がないことを意味しない。
- `L/providers/openai.js:6–10`：標準 `openai` の既定名は `OPENAI_API_KEY`。`L/providers/google.js:6–10` は `GEMINI_API_KEY`、`L/providers/azure-openai-responses.js:6–9` は `AZURE_OPENAI_API_KEY`。
- `L/env-api-keys.js:67–121`：標準の環境名の対応表。Anthropic の 3 名、Copilot、Moonshot の共通名、Qwen/Opencode の共通名など、単なる ID 導出では得られない名前がある。ここから既定名を固定の契約データとして `provider-key-refs.ts` に保持する。実行時にライブラリを UI へ追加しない。
- `L/providers/amazon-bedrock.js:50–78`、`L/providers/google-vertex.js:61–82`：API キー以外の補助環境名も参照する。すべての SDK の探索先まで読んだとは断定せず、`AWS_`、`GOOGLE_`、`GCLOUD_`、`CLOUDFLARE_` の名前群を対応する標準提供元以外から予約する。保護対象パッケージ・設定ファイルは読まない。
- `L/providers/cloudflare-auth.js:1–3,20–24`：Cloudflare のキーに加え、account/gateway の補助名を使う。上の予約群の根拠に含める。
- `P/dsh-llm-pi-ai/lib/index.js:818–826`：明示名にキーがなければ認証探索へ戻らず要求が失敗する場合がある。そのため参照先だけの状態を一覧・フォームで案内する。

`ref` は登録状態の照会先、`usedRefs` は衝突防止用の集合と分けた。後者は明示名・導出名・既定名を含む。標準候補が未稼働でも既定名を予約する。既定名の所有者自身、および公開定義で同じ既定名を使う標準提供元どうしは使用できる。カスタムなど別の所有者との共有は止める。DSH の標準 DeepSeek の ID `deepseek-official` も `DEEPSEEK_API_KEY` の所有者とする（実 DSH の既存キー操作試験で確認）。`P/dsh-llm-pi-ai/lib/index.js:2506–2529` が全カタログを directory に含めるため、稼働していない標準 `deepseek` と公式提供元が同時に一覧に現れることを考慮した。

共通のキー保存・削除は毎回最新の行を読み、保存先の衝突を検査する。呼び出し側の `exclusive` オプションは廃止した。フォームの事前検査も同じ判定を使う。明示済み・設定だけ成功・開き直しという履歴に依存しない。衝突中は状態を unknown、変更不可とし、他人のキーを登録済みとして見せない。

補助名の予約は、確認済みの標準 ID 自身の導出名だけは除外する（`google` → `GOOGLE_API_KEY`）。標準の登録経路を妨げず、他の行の実際の参照先との照合は残す。`GOOGLE` のような別 ID や `GOOGLE_CLOUD_PROJECT` のような任意の補助名はこの除外に入らない。対応表は own property だけを読み、Host に `constructor` などの ID が存在しても一覧の取得を壊さない。

選ばなかった案：既存の明示共有だけを許す／未稼働の標準名を予約しない。前者は自動で付いた明示名を識別できず再オープンで迂回でき、後者は認証前の標準提供元を保護できない。安全側の予約は、未使用の標準名や補助名でもカスタムから登録できなくなる制約を持つ。キーなしの設定作成・編集は妨げない。

#### 試験の補強と引き継ぎ

一覧からの後付け登録、明示名が残った状態の再オープン、標準 OpenAI/Google/Moonshot の既定名との衝突は、先に現行本体で落ちる試験 3 件を作成した（全 3 件が誤った保存成功で失敗）。修正後は成功した。M08/M22/M24/M39 は保存要求の revision、欄エラーと送信 0 件、Host 成功値の確定、設定・キーの各待機中の無効ボタンを直接検査する。

実 DSH の競合試験はクライアントへの設定通知を保留し、旧 revision の要求を実 Host へ送る。応答が `settings/conflict`、書込みが 1 回、Host の revision・全提供元の値が別ページの変更のままであることを検査する。部分成功の再試行は Host の値に加え、設定 RPC の要求列が増えないことを検査する。同値の no-op 再送も検出する。RPC 本体や Host は置き換えていない。キーの参照には、この試験で渡す環境名 `M3E_DSH_VERSION` を使う（他の提供元のキーと共有させない）。0.2.1-rc.2 では環境変数由来の参照も読み取り専用ではなく `writable: true` になり、`set` は成功して保存した値が環境変数より優先される（`unset` の後は再び環境変数が有効になる）。このため、この試験はキー保存が成功する経路を確かめ、「キーの保存だけが恒常的に拒否される」部分失敗は単体試験の注入で確認する。

M47 は当時の通常の apply_patch が拒否されたため `tmp/handoff-issue16-03.md` に引き継いだ。その後、指示役が `e187882` で `tests/08-provider-reference-close.test.ts` を適用済み。正常実行、M47 と案内を除去する変異の検出も確認済みとの引き継ぎを受けた。今回も正常実行を確認した。

追加・変更ファイル：`provider-key-refs.ts`（標準名と衝突の純粋な判定）、`providers.ts`、`custom-provider-store.ts`、両フォーム/一覧、単体 2 ファイルと両 e2e、UI 仕様とこのメモ。新しい偽データモジュールはない。配布用のファイルは取り込み以外で変更しない。

#### 壊して確かめた表（今回）

M08/M22/M24/M39 と M09 は監査の置換と同じ。M25 は廃止した `exclusive` 引数だけを除き、監査と同じ条件・同じ no-op の設定書込みを挿入した。試験ごとに正常通過を確かめてから適用し、終了後は対象の本体を `git restore` で戻した。この回の 4 生存変異はすべて検出。M47 は後に `e187882` で適用・検証済み。

| 試験 | 故障 | 検出した結果 |
|---|---|---|
| I16 opened revision M08 | 開いた版を describe の最新 revision へ差し替え | 保存が成功してしまい、競合を期待する検査で失敗 |
| I16 input M22 | 明示する入力種別の検査を除去 | 空配列が保存され、送信しない期待で失敗 |
| I16 UI input M22 | 同上 | 欄エラーが表示されず失敗 |
| I16 committed state M24 | 成功応答を編集状態・初期値へ確定する publish を除去 | editing が false のままで失敗。正常時は部分成功も含め ID・revision・Host 整形値を確認 |
| I16 UI saving M39 | 監査と同じく保存中の phase を保存可能に追加 | 設定待ちの保存ボタンが有効となり失敗 |
| I16 UI saving M39（キー待ち） | savingKey のときだけ保存を有効化 | キー待ちの保存ボタンが有効となり失敗 |
| I16 destinations list | 衝突判定を常に false | 一覧からの後付け登録が成功して失敗 |
| I16 destinations reopen | 同上 | 明示名が残ったフォームでキー保存が成功して失敗 |
| I16 destinations native | 同上 | 標準の保存先を使うカスタムの作成が成功して失敗 |
| I16 destinations owners | 同上 | 標準以外の ID の予約が解除されて失敗。継承名の検査追加前には constructor 参照が例外になることも確認し修正 |
| I16 destinations owners（本人の導出名） | 補助名の予約で標準 ID 自身も除外しない | google 自身の登録まで拒否して失敗。修正前にも同じ検査で失敗を確認 |
| I16 reference recheck | 同上 | 保存直前に他の行の参照が変わっても成功し失敗 |
| I16 UI destinations | 同上 | 衝突中の案内が表示されず失敗 |
| I16 UI destinations（参照先だけ） | keyNotice の付与を除去 | 未登録の参照先に必要な案内が表示されず失敗 |
| I16 real failures / M09 | RPC 競合後に最新 revision で自動再送 | Host の表示名と revision が別ページの状態から変わり失敗 |
| I16 real failures / M25 | 部分成功後の再試行で同じ api を mutate | Host の値が同じでも設定要求が 2 件から 3 件になり失敗 |
| I16 UI partial / M25 | 同上 | 設定要求が 1 件から 2 件になり失敗 |
| I16 key recheck close（適用済み 02） | canSend を常に true | 閉じた後のキー送信が 0 件でなく 1 件になり失敗 |
| I16 reference write close / M47 | 参照先書込み後の 2 回目の canSend を除去 | 当時は未実行。`e187882` で適用され、指示役と独立監査が検出を確認済み |

画面と実 DSH の変異の結果は `tmp/issue16-review2-M22.json`、`M39.json`、`M39-key.json`、`destinations.json`、`reference-notice.json`、`M09-real.json`、`M25-real-final.json`、`M25-ui.json`（いずれも先頭は `issue16-review2-`）。失敗を期待した実行は全体の成功件数に含めない。

#### 今回の全体検証と受け入れ判定

- `pnpm typecheck`：成功。
- `pnpm test`：1,063 件成功、失敗・skip 0。
- `pnpm build`：成功。既存の 500 kB 超の chunk 警告あり。
- `pnpm check:pack`：19 ファイルで成功。
- 偽データ全体 e2e：170 件成功、予期しない失敗・skip・flaky 0。
- 実 DSH 全体 1 回目：通常成功 36 件、既知の差の期待失敗 1 件、予期しない失敗・skip・flaky 0。
- 実 DSH 全体 2 回目：通常成功 36 件、既知の差の期待失敗 1 件、予期しない失敗・skip・flaky 0。

全体 e2e は共通のコマンドに `--global-timeout=900000` を付けて実行した。実 DSH は 0.2.0-rc.2 の隔離プロファイルと偽 LLM。既知の期待失敗は、Host が停止したままでも切断済み表示へ変わらない従来の 1 件である。最初の試行では再試行後のボタンが有効になるという試験の誤りを検出した。入力消去後はボタンが無効になることが正しいため、入力欄の再有効化で完了を待ち、ボタンは無効と検査するよう修正した。修正後の正常動作と M25 の検出をやり直した。

| 受け入れ条件 | この回の終了時点（03 適用前）の判定 |
|---|---|
| 1 追加・編集の入口とフォーム | 達成。UI / real lifecycle |
| 2 保存値・他の提供元・未知項目・選択モデルの保持 | 達成。path operation 単体、real lifecycle、M24、実 Host の競合後の全値 |
| 3 入力検査と欄エラー | 達成。単体、UI lifecycle / URL / input M22、実 Host の設定書込み |
| 4 キーの非表示・空欄で保持・入力消去 | 実装と適用済み試験は成功。M47 の特定の待機境界の送信 0 件は未検証 |
| 5 各失敗と部分成功 | 達成。UI blocked / refused / lost / partial、real failures。M09/M25 の変異も検出 |
| 6 キャンセル・二重送信・戻る・閉じる | 通常の終了経路は成功。UI dismiss / late / saving M39。参照先書込み待ちの M47 は未検証 |
| 7 375–390px と既存操作の回帰 | 自動試験の範囲で達成。既存のモデル・キー操作と real numeric ID。iOS 実機のキーボードは未検証 |
| 8 単体・e2e・型・ビルド | 適用済みコードは上記で検証。M47 の追加試験・故障検出を引き継ぐ |

結果は `tmp/issue16-review2-mock-final.json`、`tmp/issue16-review2-real-final-1.json`、`tmp/issue16-review2-real-final-2.json`。最初の試行の結果は `tmp/issue16-review2-real-trial.json` に分けた。詳細報告は `tmp/handoff-issue16-review2-fixes.md`。この集計は 03 適用前の履歴であり、M47 はその後 `e187882` で正常・変異とも確認済み。現在の状態は次節に記す。

本番の利用者の DSH や実キーには触れず、実提供元への認証・推論はしていない。保護対象のパッケージは読まなかった。試験のパッチ以外には、検索引数に保護対象語を含む操作 2 回が停止し、共通の決まりが認める安全な単一ファイル指定へ直した。担当外の追加変更・依存追加・push はない。

### 2026-10-06：6 回目のレビュー（Grok Bot）と変異監査（現在の方針。下の 5 回目の節より優先）

開始時は `379299f`（`feat/16-custom-provider`）。作業ブランチは `grok/16-custom-provider`。レビューの判定は blocking 3 件（すべて修正）、major 0 件、minor 2 件（記録のみ）。この節は 5 回目の節の方針を引き継ぎ、下に書く点だけを改める。食い違う記述は、この節が優先する。DSH の動きの根拠は、e2e-dsh が取得した実物の DSH 0.2.0-rc.2（`tmp/dsh-integration/dsh-0.2.0-rc.2/node_modules/@deepseek-ai/`）のコードと、実 DSH の統合試験の結果だけにした。

#### (1) レビューの判定と指摘

| 番号 | 重大度 | ファイルと行（`379299f`） | 内容と根拠 | 対応 |
|---|---|---|---|---|
| G1 | blocking | `web/src/features/settings/providers.ts:119`、`ProvidersPanel.tsx:135` | `keyNotice` の条件が `!row.needsReference` だったので、前からある種類の行（参照名を明示した標準の行、同じ名前を明示した複数の行、main の流れで参照名を書き込んだ未稼働の標準の行）でキーが未登録のとき、「キーの参照先だけが設定されています…」が付いた。パネルはカスタムでない行の補足にも `{row.keyNotice}` を足していた。実 DSH では標準の DeepSeek（`dsh-llm-deepseek-api-key/lib/index.js:9` が `apiKeyEnv` の既定値を `DEEPSEEK_API_KEY` にするので、明示の行になる）の表示が「API キー：未登録キーの参照先だけが…」になることを、偽データと実 DSH の両方で確かめた。前からある機能の回帰 | 条件を `row.custom && status && !status.configured` にし、パネルのカスタムでない行を main と同じ表示に戻した |
| G2 | blocking | `custom-provider-store.ts`（`requireMissing` で止めたあと） | 論点 2。フォームが付けた参照名に、保存の間に別の経路でキーが登録されると、キーは送らずに止めるが、名前は設定に残った。DSH は明示された名前のキーをそのまま使うので（下の (3)）、利用者が入力したベース URL へ別の提供元のキーが送られ得た | (3) の方針で、付けた名前を外す |
| G3 | blocking | `custom-provider-store.ts` の `load`（予約名の収集） | 一覧（main と同じ動き）は、参照名の無い未稼働の標準の行に導出名（例：pi-ai の `openai-codex` → `OPENAI_CODEX_API_KEY`）を使って照会・登録する。この名前は既定名の表（5 回目の節）に無いので、フォームは ID `OpenAI-Codex` のカスタムに同じ名前を新しく付けられた。その結果、標準の行が他人のキーを「登録済み」と表示し、一覧からの登録がそのキーを上書きし得た。pi-ai の builtin 41 件（`@earendil-works/pi-ai/dist/providers/all.js`）には、表に無い提供元が複数ある | `load` で `providerRows(...)` のカスタムでない行の `row.ref` を予約名に足す |
| m1 | minor | `custom-provider-store.ts` の予約名の収集 | 提供元でない名前空間の `apiKeyEnv`（例：`web-search-deepseek`）は予約していない。登録済みなら、保存時の 1 件の照会（登録済みならキー欄のエラー）で止まるので、上書きはしない。未登録の名前を先に取った場合は、あとでその機能がキーを共有する | 記録のみ |
| m2 | minor | G2 の外せなかった場合 | 名前を外せなかったとき（競合・拒否・結果不明）、M3E の中に、カスタムの参照名を外す操作は無い。案内は、再読み込みで状態を確かめ、DSH の標準の設定で外すか変えるよう促す | 記録のみ |

確かめて、問題が無いと判定した点（試験の名前は、根拠にした試験）：

- フォームの保存：追加は `providers.<ID>` への 1 件の `set`、編集は変えた項目だけの `set` / `unset`（`I16 ops`、`I16 A6 edit key reference O06`）。開いた時点の revision を使い、競合では `stale` にして自動で再送しない（`I16 opened revision M08`、`I16 preflight revision`、`I16 A6 change during save S15`）。画面が扱わない項目（`headers` など）、ほかの提供元、既定のモデル・選択中のモデルは変えない（`I16 ops`、`I16 UI lifecycle`、実 DSH の `I16 real lifecycle`）。
- 保存の状態：二重送信、閉じたあとの応答、切断、結果不明で、提供元を重ねて作らない（`I16 partial`、`I16 UI late`、`I16 A6 double submit S10/S11`）。設定だけ成功してキーが失敗したあとの再試行は、キーだけを送る（`I16 UI partial`）。
- 重なりの検査：G3 のほかに、すり抜けと止めすぎは見つからなかった。明示された保存先の共有は止めない（`I16 explicit reference`）。
- API キー：保存済みのキーは取得も表示もしない（使うのは `credentials.describe` の `configured` / `writable` と、`set` / `unset` だけ）。設定の本文、URL、ログ、ブラウザーの保存領域に入力を書く処理は無い（`localStorage` / `sessionStorage` / `console` / `history` の使用なし）。送信の開始時、キャンセル・破棄・切断・読み直し・外部変更のときに入力を消す（`I16 A6 reload clears key S07`、`I16 A6 change while editing S16`）。
- 偽データ（`?mock`）：参照名の扱い、競合、検査の厳しさで、実物との差は見つからなかった。実物で確かめた動き（G2 の外す流れ、G3）は、偽データと実 DSH の両方の試験で同じ期待にした。

#### (2) main との比較

`git diff origin/main..HEAD -- providers.ts ProvidersPanel.tsx` の差（修正のあと）：

1. `ProviderAddress.declared` を受け取る。`custom = declared === true && settingsNs === 'llm-pi-ai'`。標準のカタログの提供元は `declared` にならない（`dsh-llm-pi-ai/lib/index.js:2513-2525`）。
2. `native` から、名前の無いカスタムを除く。名前の無いカスタムは `ref` なし、`status: 'unset'`、`needsReference: false`。
3. `keyNotice`：カスタムの行で、キーが未登録のときだけ。
4. `settingsWritable` と `customAvailable` を状態に足す（「カスタムプロバイダーを追加」の可否）。
5. `change` の `canSend`（照会のあとと送信の直前）と `requireMissing`。渡すのはフォームだけで、一覧の `save` / `remove` は渡さない。
6. `createKeyDraft.clear()`。フォームが入力を消すため。
7. パネル：状態の文言に「API キー：未設定」を足す。カスタムの行は別の表示（「編集」と、参照名があるときだけ「API キー」）。カスタムでない行は main と同じ。

| 行の種類 | 表示 | 登録 | 削除 | 照会の失敗 | 修正前 |
|---|---|---|---|---|---|
| 標準・稼働中・名前なし（キーは不要） | 同じ | 同じ（不可） | 同じ（不可） | 同じ | 同じ |
| 標準・未稼働・pi-ai・名前なし（導出名） | 同じ | 同じ（参照名を書き込んでからキー） | 同じ | 同じ（確認できません＋再読み込み） | 名前を書き込んだあと、キー未登録の表示に案内が付いた（✗） |
| 標準・未稼働・pi-ai 以外の名前空間（導出名） | 同じ | 同じ（変更できません） | 同じ | 同じ | 同じ |
| 参照名を明示した行（実 DSH の DeepSeek を含む） | 同じ | 同じ | 同じ | 同じ | キー未登録のとき案内が付いた（✗） |
| 同じ名前を明示した複数の行 | 同じ | 同じ（共有を止めない） | 同じ | 同じ | キー未登録のとき案内が付いた（✗） |
| アカウントの提供元（`deepseek-account`） | 同じ | 同じ（不可） | 同じ | 同じ | 同じ |

根拠の試験：`I16 R4 main parity`（全種類の既存行が、参照先なしのカスタム 70 件の有無で変わらない）、`I16 G1 standard notice`、`I16 UI standard notice G1`、実 DSH の `I16 real numeric ID`（DeepSeek の補足が「API キー：未登録」と完全に一致）。

#### (3) 論点 2：止めたときに、付けた名前を外す

実物の確認（`dsh-llm-pi-ai/lib/index.js`）：

- `2563-2570` の `resolveApiKey`：`apiKeyEnv` があれば、その名前の資格情報を解決して使う。見つからなければ `MISSING_CREDENTIAL` で、ほかの名前へは戻らない。`apiKeyEnv` が無ければ `undefined`。
- `818-866` の `harnessApiKeyAuth` / `routeAuth`：カタログに無い（手で宣言した）経路は harness の解決だけを使う。名前が無ければ認証なしで、周囲の環境変数は探さない。`1852` で要求ごとに解決する。

したがって、名前を残すと、登録済みの別のキーが、利用者の入力したベース URL へ送られ得る。名前を外せば、この提供元にキーは付かない。方針は適切と判断し、そのまま採用した。

実装（`custom-provider-store.ts` の `detach`）：止めたら、設定をその場で読み直し、その提供元の `apiKeyEnv` がまだ自分の付けた名前のときだけ、読み直した revision で `unset` を 1 回送る。自動で再送しない。結果は次のとおり。

| 結果 | 状態 | 案内（部分成功の説明と「設定を保存する間に、この参照名のキーが登録されました。上書きを避けるため、API キーを送信していません。」に続ける） |
|---|---|---|
| 外せた | `saved`（入力と保存は無効。開き直すと名前の重なりで止まる） | この保存で付けた参照名を、この提供元の設定から外しました。… ほかと重ならない ID で追加し直してください。 |
| 値が変わっていた・競合 | `stale`（再読み込み） | この保存で付けた参照名を外せませんでした。… DSH の標準の設定でこの提供元の参照名を外すか変えてください。 |
| 拒否 | `keyFailed` | 参照名を外す変更が拒否されました。… |
| 例外・切断・読み直し失敗 | `unknown`（保存結果を確認） | 参照名を外せたか確認できません。… |

外せたあとは、その名前を予約名に足し、付けた名前の記憶を消す。`providers.ts` には、名前を付ける・外す処理を戻していない（返すのは `keyRegisteredMeanwhileMessage` の定数だけ）。`docs/ui-spec.md` の「保存できない場合」の表と、参照名の予約の段落を合わせた。

#### (4) 試験を壊して確かめる監査

本体を 1 か所ずつ書き換え、対象の試験を実際に流して、毎回 `git checkout` で戻した（壊した変更はコミットしていない。監査の終わりに `git status` が clean であることを確かめた）。対象の試験は `tests/08-custom-provider*.test.ts`、`tests/08-provider-*.test.ts`、`tests/08-providers.test.ts`（単体）、`e2e/settings-custom-provider.spec.ts`（偽データ e2e）、`e2e-dsh/custom-provider.spec.ts`（実 DSH）。変異は 88 個で、実行は単体 76 回、偽データ e2e 26 回、実 DSH 15 回。実 DSH で落ちたのは 11 個（P05、P14、F04、F10、F14、S01、O02、O03、U01、U09、U10）。実 DSH で落ちなかった P09、F01、F07、S05 は、単体で検出するか、等価と判断した。結果の内訳は、検出 68、追加の試験で検出 7、等価 13、未検出の非等価 0。「落ちた試験」の欄は、試験の名前の先頭だけを書いた。

| 番号 | 場所 | 変異 | 落ちた試験 | 結果 |
|---|---|---|---|---|
| P01 | providers: カスタムの判定 | `const custom = entry.declared === true && entry.settingsNs === 'llm…` → `const custom = entry.settingsNs === 'llm-pi-ai'` | 単体：I16 G1 standard notice、I16 G3 list destination、I16 R4 main parity ほか | 検出 |
| P02 | providers: カスタムの判定 | `const custom = entry.declared === true && entry.settingsNs === 'llm…` → `const custom = entry.declared === true` | 単体：生存 | 生存→追加試験で検出 |
| P03 | providers: カスタムの判定 | `const custom = entry.declared === true && entry.settingsNs === 'llm…` → `const custom = false` | 単体：I16 G1 standard notice、I16 G2 detach、I16 R4 main parity ほか | 検出 |
| P04 | providers: 名前なしカスタムの行 | `!custom && !named && live.has(entry.provider)` → `!named && live.has(entry.provider)` | 単体：生存 | 等価 |
| P05 | providers: 名前なしカスタムの行 | `const withoutReference = custom && !named` → `const withoutReference = false` | 単体：I16 G2 detach、I16 R4 main parity、I16 R4 native write ほか／実 DSH：I16 real case N09、I16 real destinations、I16 real failures ほか | 検出 |
| P06 | providers: 名前なしカスタムの行 | `native \|\| withoutReference ? undefined :` → `native ? undefined :` | 単体：I16 G2 detach、I16 R4 main parity、I16 R4 native write ほか | 検出 |
| P07 | providers: 名前なしカスタムの行 | `needsReference: !named && !native && !custom,` → `needsReference: !named && !native,` | 単体：生存 | 等価 |
| P08 | providers: 名前なしカスタムの行 | `status: withoutReference ? 'unset' :` → `status: withoutReference ? 'missing' :` | 単体：I16 G2 detach、I16 R4 lookup failures、I16 R4 main parity ほか | 検出 |
| P09 | providers: keyNotice の条件 | `...(row.custom && status && !status.configured ?` → `...(status && !status.configured ?` | 単体：I16 G1 standard notice、I16 reference write close M47／実 DSH：生存 | 検出 |
| P10 | providers: keyNotice の条件 | `...(row.custom && status && !status.configured ?` → `...(row.custom && status && status.configured ?` | 単体：I16 G1 standard notice、I16 reference recheck | 検出 |
| P11 | providers: keyNotice の条件 | `{ keyNotice: pendingKeyReferenceMessage }` → `{}` | 単体：I16 G1 standard notice | 検出 |
| P12 | providers: canSend（照会後） | `if (options.canSend?.() === false) return { ok: false, message: '入力…` → `（削除）` | 単体：生存 | 等価 |
| P13 | providers: canSend（送信直前） | `if (options.canSend?.() === false) return { ok: false, message: '入力…` → `（削除）` | 単体：I16 reference write close M47 | 検出 |
| P14 | providers: requireMissing の判定 | `if (options.requireMissing && row.status !== 'missing')` → `if (false)` | 単体：I16 G2 detach、I16 G2 detach changed、I16 G2 detach conflict ほか／実 DSH：I16 real late registration | 検出 |
| P15 | providers: requireMissing の判定 | `if (options.requireMissing && row.status !== 'missing')` → `if (row.status !== 'missing')` | 単体：I16 G1 standard notice、I16 R4 main parity、I16 destinations reopen ほか | 検出 |
| P16 | providers: requireMissing の判定 | `if (options.requireMissing && row.status !== 'missing')` → `if (options.requireMissing && row.status === 'm…` | 単体：I16 G2 detach、I16 G2 detach changed、I16 G2 detach conflict ほか | 検出 |
| P17 | providers: 照会の失敗 | `const info = answer.ok ? answer.value : {}` → `const info = answer.ok ? answer.value : Object.…` | 単体：I16 R4 lookup failures、状態照会の拒否・不正応答・例外を未登録に置き換えず書き込みを止める | 検出 |
| P18 | providers: 照会の失敗 | `if (request === sequence && generation === epoch) publish({ phase: …` → `if (request === sequence && generation === epoc…` | 単体：I16 R4 lookup failures、状態照会の拒否・不正応答・例外を未登録に置き換えず書き込みを止める | 検出 |
| P19 | providers: 追加の可否 | `customAvailable: settings.value.namespaces.some(row => row.ns === '…` → `customAvailable: true,` | 偽データ e2e：I16 UI blocked | 検出 |
| P20 | providers: 追加の可否 | `settingsWritable: settings.value.writable,` → `settingsWritable: true,` | 偽データ e2e：I16 UI blocked | 検出 |
| F01 | フォーム: 明示名との重なり | `return objectValue(value) && typeof value.apiKeyEnv === 'string' ? …` → `return []` | 単体：生存／実 DSH：生存 | 等価（重複） |
| F02 | フォーム: 明示名との重なり | `if (objectValue(value) && typeof value.apiKeyEnv === 'string') refe…` → `if (false) references.push('')` | 単体：生存 | 等価（重複） |
| F03 | フォーム: 別の名前空間の名前 | `return objectValue(value) && typeof value.apiKeyEnv === 'string' ? …` → `return entry.settingsNs === CUSTOM_NS && object…` | 単体：生存 | 等価（重複） |
| F04 | フォーム: 一覧の導出名の予約 | `if (!row.custom && row.ref) references.push(row.ref)` → `if (false) references.push('')` | 単体：I16 G3 list destination／実 DSH：I16 real list destination G3 | 検出 |
| F05 | フォーム: 重なりの検査 | `else if (key && !hasReference && state.draft) {` → `else if (false) {` | 単体：I16 G2 detach、I16 G3 list destination、I16 R5 foreign owner ほか／偽データ e2e：I16 UI destinations、I16 UI late registration、I16 UI reserved | 検出 |
| F06 | フォーム: 名前の形 | `if (key && !validKeyReference(ref)) errors.key = invalidKeyReferenc…` → `if (false) errors.key = invalidKeyReferenceMess…` | 単体：I16 numeric ID | 検出 |
| F07 | フォーム: 登録済みの確認 | `: info.configured ? 'この名前のキーはすでに登録されています。'` → `: false ? 'この名前のキーはすでに登録されています。'` | 単体：I16 orphan destination、I16 preflight／実 DSH：生存 | 検出 |
| F08 | フォーム: 登録済みの確認 | `const reason = !info ? '登録状況を確認できません。接続を確認して、もう一度お試しください。'` → `const reason = !info ? undefined` | 単体：I16 preflight | 検出 |
| F09 | フォーム: 登録済みの確認 | `: !info.writable ? 'この保存先は変更できません。' : undefined` → `: undefined` | 単体：I16 preflight | 検出 |
| F10 | フォーム: 付けた名前を覚える | `          assignedReference = ref⏎` → `（削除）` | 単体：I16 G2 detach、I16 G2 detach changed、I16 G2 detach conflict ほか／実 DSH：I16 real late registration | 検出 |
| F11 | フォーム: 付けた名前を忘れる（1 回目のあと） | `        pendingKey = undefined⏎        const outcome` → `        pendingKey = undefined⏎        assigned…` | 単体：I16 G2 detach、I16 G2 detach changed、I16 G2 detach conflict ほか | 検出 |
| F12 | フォーム: 付けた名前を忘れる（読み直し） | `    input.clear()⏎    publish({ phase: 'loading'` → `    input.clear(); assignedReference = undefine…` | 単体：I16 G2 detach conflict、I16 R5 unknown result | 検出 |
| F13 | フォーム: requireMissing の付与 | `requireMissing: ref === assignedReference` → `requireMissing: false` | 単体：I16 G2 detach、I16 G2 detach changed、I16 G2 detach conflict ほか | 検出 |
| F14 | フォーム: 名前を外す（呼ばない） | `if (!outcome.ok && outcome.message === keyRegisteredMeanwhileMessag…` → `if (false) {` | 単体：I16 G2 detach、I16 G2 detach changed、I16 G2 detach conflict ほか／偽データ e2e：I16 UI late registration／実 DSH：I16 real late registration | 検出 |
| F15 | フォーム: 名前を外す（値の確認） | `      if (!objectValue(profile) \|\| profile.apiKeyEnv !== ref) retur…` → `（削除）` | 単体：I16 G2 detach changed | 検出 |
| F16 | フォーム: 名前を外す（revision） | `[{ op: 'unset', path: ['providers', target!, 'apiKeyEnv'] }], names…` → `[{ op: 'unset', path: ['providers', target!, 'a…` | 単体：生存 | 生存→追加試験で検出 |
| F17 | フォーム: 名前を外す（競合の自動再送） | `      if (!result.ok) return result.error.code === 'settings/confli…` → `      if (!result.ok && result.error.code === '…` | 単体：I16 G2 detach conflict | 検出 |
| F18 | フォーム: 名前を外す（失敗の分類） | `['settings/rejected', 'gateway/bad-request'].includes(result.error.…` → `['settings/rejected', 'gateway/bad-request'].in…` | 単体：I16 G2 detach failures | 検出 |
| F19 | フォーム: 名前を外す（忘れる） | `      assignedReference = undefined⏎      references.push(ref)` → `      references.push(ref)` | 単体：生存 | 等価 |
| F20 | フォーム: 名前を外す（予約に足す） | `      assignedReference = undefined⏎      references.push(ref)` → `      assignedReference = undefined` | 単体：生存 | 等価 |
| F21 | フォーム: 名前を外す（状態の更新） | `      publish({ namespace: result.value, initial: structuredClone(s…` → `      return 'saved'` | 単体：生存 | 等価 |
| F22 | フォーム: 名前を外す（成功の phase） | `      return 'saved'⏎    } catch { return 'unknown' }` → `      return 'keyFailed'⏎    } catch { return '…` | 単体：I16 G2 detach、I16 G2 detach conflict、I16 R5 late registration ほか／偽データ e2e：I16 UI late registration | 検出 |
| F23 | フォーム: 大文字と小文字 | `if (named.includes(ref)) return` → `if (named.some(name => name.toUpperCase() === r…` | 単体：I16 destinations owners | 検出 |
| F24 | フォーム: 標準の既定名の表 | `if (Object.values(defaults).some(refs => refs.includes(ref))) return` → `if (false) return` | 単体：I16 destinations native、I16 destinations owners | 検出 |
| F25 | フォーム: 接頭辞の予約 | `const families = ['AWS_', 'GOOGLE_', 'GCLOUD_', 'CLOUDFLARE_']` → `const families: string[] = []` | 単体：I16 destinations owners／偽データ e2e：I16 UI reserved | 検出 |
| F26 | フォーム: 名前の形 | `export const validKeyReference = (ref: string) => /^[A-Za-z_][A-Za-…` → `export const validKeyReference = (ref: string) …` | 単体：I16 numeric ID | 検出 |
| S01 | 保存: revision | `const result = await remote.settings.mutate(CUSTOM_NS, ops, namespa…` → `const latest = await remote.settings.describe()…` | 単体：I16 opened revision M08、I16 preflight revision／実 DSH：I16 real failures | 検出 |
| S02 | 保存: 競合のあとの再送 | `            const conflict = result.error.code === 'settings/confli…` → `            if (result.error.code === 'settings…` | 単体：I16 opened revision M08、I16 preflight revision、I16 refusals | 検出 |
| S03 | 保存: 部分成功のあとの再試行（設定再送） | `    try {⏎      if (!committed) {⏎        const ops` → `    try {⏎      if (true) {⏎        const ops` | 単体：生存／偽データ e2e：生存 | 等価 |
| S04 | 保存: 部分成功のあとの再試行（キー） | `      if (pendingKey) {⏎        publish({ phase: 'savingKey' })` → `      if (false) {⏎        publish({ phase: 'sa…` | 単体：I16 G2 detach、I16 G2 detach changed、I16 G2 detach conflict ほか | 検出 |
| S05 | 保存: 閉じたあとの送信 | `canSend: () => active && connected && generation === epoch` → `canSend: () => true` | 単体：I16 key recheck close／実 DSH：生存 | 検出 |
| S06 | 保存: 閉じたあとの送信 | `dispose() { active = false; ticket++; pendingKey = undefined; input…` → `dispose() {},` | 単体：I16 close、I16 key recheck close、I16 preflight close／偽データ e2e：I16 UI late | 検出 |
| S07 | キーの入力: 読み直しで消す | `    input.clear()⏎    publish({ phase: 'loading'` → `    publish({ phase: 'loading'` | 単体：生存 | 生存→追加試験で検出 |
| S08 | キーの入力: 切断で消す | `      connected = next; epoch++; ticket++; pendingKey = undefined⏎ …` → `      connected = next; epoch++; ticket++; pend…` | 単体：I16 unknown | 検出 |
| S09 | キーの入力: 送信開始で消す | `publish({ draft: '', visible: false, busy: true, error: null })` → `publish({ busy: true, error: null })` | 単体：I16 partial、I16 preflight、サーバーの拒否と例外に入力値が含まれても保存結果と入力シートへ出さない ほか／偽データ e2e：I16 UI late、I16 UI late registration、I16 UI partial ほか | 検出 |
| S10 | 保存: 二重送信 | `if (!active \|\| !connected \|\| saving \|\| !state.writable` → `if (!active \|\| !connected \|\| !state.writable` | 単体：生存 | 等価（重複） |
| S11 | 保存: 二重送信 | `      if (saving \|\| !active \|\| !connected) return false` → `      if (!active \|\| !connected) return false` | 単体：生存 | 等価（重複） |
| S12 | 保存中のボタン | `disabled={!['editing', 'keyFailed'].includes(state.phase) \|\| (!chan…` → `disabled={!['editing', 'keyFailed', 'savingSett…` | 偽データ e2e：I16 UI saving M39 | 検出 |
| S13 | 失敗の理由の表示 | `          const message = `${partialMessage} ${outcome.message}`` → `          const message = partialMessage` | 単体：I16 R5 retry、I16 partial／偽データ e2e：I16 UI partial | 検出 |
| S14 | 失敗の理由の表示 | `if (!conflict && !['settings/rejected', 'gateway/bad-request'].incl…` → `if (false) {` | 単体：I16 unknown | 検出 |
| S15 | 保存: 保存中の外部変更 | `if (saving) { changedDuringSave = true; return }` → `if (saving) return` | 単体：生存 | 生存→追加試験で検出 |
| S16 | 保存: 編集中の外部変更 | `      input.clear()⏎      publish({ phase: 'stale', message: confli…` → `    },` | 単体：生存／偽データ e2e：生存 | 生存→追加試験で検出 |
| O01 | path operation: 項目の欠落 | `...(draft.displayName ? { displayName: draft.displayName } : {}),` → `（削除）` | 単体：生存／偽データ e2e：I16 UI URL、I16 UI destinations、I16 UI dismiss ほか | 検出 |
| O02 | path operation: 項目の欠落 | `...(withKey ? { apiKeyEnv: providerRef(id) } : {}),` → `（削除）` | 単体：I16 G2 detach、I16 G2 detach changed、I16 G2 detach conflict ほか／実 DSH：I16 real late registration、I16 real lifecycle | 検出 |
| O03 | path operation: 変えていない項目の送信 | `if (draft[key] !== initial[key]) put(` → `if (true) put(` | 単体：I16 G2 detach conflict、I16 ops、I16 retry sharing B04／実 DSH：I16 real failures | 検出 |
| O04 | path operation: 変えていない項目の送信 | `if (!equal(models, initial.models.map(modelValue))) put('models', m…` → `put('models', models)` | 単体：I16 ops、I16 retry sharing B04 | 検出 |
| O05 | path operation: モデルの未知の項目 | `  const result = structuredClone(model.original)` → `  const result: SettingObject = {}` | 単体：I16 G2 detach、I16 G2 detach changed、I16 G2 detach conflict ほか | 検出 |
| O06 | path operation: 編集での名前の付与 | `if (withKey && !reference) put('apiKeyEnv', providerRef(id))` → `if (false) put('apiKeyEnv', providerRef(id))` | 単体：生存 | 生存→追加試験で検出 |
| O07 | 入力の検査: ID | `else if (['__proto__', 'constructor', 'prototype'].includes(id))` → `else if (false)` | 単体：I16 validation | 検出 |
| O08 | 入力の検査: ID | `else if (taken.includes(id))` → `else if (false)` | 単体：I16 validation／偽データ e2e：I16 UI lifecycle | 検出 |
| O09 | 入力の検査: URL | `  if (!/^https?:\/\//i.test(url)) return false` → `  if (!/^[a-z]+:\/\//i.test(url)) return false` | 単体：生存／偽データ e2e：生存 | 等価 |
| O10 | 入力の検査: URL | `baseURL: draft.baseURL.trim(), models` → `baseURL: draft.baseURL, models` | 単体：I16 ops | 検出 |
| O11 | 入力の検査: プロトコル | `if (!choices.includes(draft.api)) errors.api` → `if (!draft.api) errors.api` | 単体：I16 validation | 検出 |
| O12 | 入力の検査: モデル | `else if (ids.has(name)) errors` → `else if (false) errors` | 単体：I16 validation | 検出 |
| O13 | 入力の検査: モデル | `if (!name) errors[`${model.row}.id`]` → `if (false) errors[`${model.row}.id`]` | 単体：I16 validation | 検出 |
| O14 | 入力の検査: モデル | `!Number.isFinite(number) \|\| number < 1 \|\|` → `!Number.isFinite(number) \|\|` | 単体：I16 validation | 検出 |
| O15 | 入力の検査: モデル | `if (!draft.models.length) errors.models` → `if (false) errors.models` | 単体：I16 validation／偽データ e2e：生存 | 生存→追加試験で検出 |
| O16 | 入力の検査: モデル | `(!model.input.length \|\| model.input.some(` → `(model.input.some(` | 単体：I16 input M22 | 検出 |
| U01 | 画面: 未設定の表示 | `unset: 'API キー：未設定',` → `unset: 'API キー：未登録',` | 偽データ e2e：I16 UI destinations、I16 UI late registration、I16 UI lifecycle ほか／実 DSH：I16 real case N09、I16 real destinations、I16 real failures ほか | 検出 |
| U02 | 画面: 未設定の案内 | `{!row.ref && <span>API キーは「編集」から登録できます。</span>}` → `（削除）` | 偽データ e2e：I16 UI destinations、I16 UI late registration | 検出 |
| U03 | 画面: 「API キー」の入口 | `{row.ref && <M3eButton variant="text" disabled={!row.writable` → `{<M3eButton variant="text" disabled={!row.writa…` | 偽データ e2e：I16 UI destinations、I16 UI late registration | 検出 |
| U04 | 画面: 「編集」の入口 | `{state.rows.map(row => row.custom ? <div` → `{state.rows.map(row => row.custom && row.ref ? …` | 偽データ e2e：I16 UI URL、I16 UI destinations、I16 UI dismiss ほか | 検出 |
| U05 | 画面: 案内の文言（一覧の keyNotice） | `{row.keyNotice && <span>{row.keyNotice}</span>}` → `（削除）` | 偽データ e2e：I16 UI destinations | 検出 |
| U06 | 画面: 案内の文言（変更できません） | `<span>{statusLabels[row.status]}{row.ref && !row.writable && row.st…` → `<span>{statusLabels[row.status]}</span>{!row.ref` | 偽データ e2e：I16 UI fixed key | 検出 |
| U07 | 画面: 追加の入口 | `state.settingsWritable !== true \|\| !state.customAvailable \|\| editor…` → `state.settingsWritable !== true \|\| editorBusy` | 偽データ e2e：I16 UI blocked | 検出 |
| U08 | 画面: 案内の文言（フォームの keyNotice） | `{provider?.keyNotice && <p className="settings-field-help">{provide…` → `（削除）` | 偽データ e2e：I16 UI destinations | 検出 |
| U09 | 画面: 案内の文言（名前の形） | `{keyRefInvalid && !state.errors.key && <p className="settings-field…` → `（削除）` | 偽データ e2e：生存／実 DSH：I16 real numeric ID | 検出 |
| U10 | 画面: 名前を外したあとの表示 | `          if (active && generation === epoch) publish({ phase, mess…` → `          if (active && generation === epoch) p…` | 単体：I16 G2 detach、I16 G2 detach changed、I16 G2 detach conflict ほか／偽データ e2e：I16 UI late registration／実 DSH：I16 real late registration | 検出 |

生存した変異の扱い：

- 追加の試験で検出（`tests/08-provider-audit6.test.ts`。修正のあとの本体で成功し、同じ変異で落ちることを確かめた）：P02（`llm-pi-ai` 以外の宣言をカスタムとして扱う）、F16（名前を外すときに、読み直す前の revision を使う。ほかの提供元の変更と競合する）、S07（読み直しでキーの入力を消さない）、S15（保存中の外部変更を覚えない）、S16（編集中の外部変更で `stale` にしない・入力を消さない）、O06（編集でキーを入れたときに参照名を付けない）、O15（モデル 0 件を止めない）。
- 等価（利用者に見える動きも、送るデータも変わらない）：
  - P04：名前の無いカスタムは、`native` の値に関わらず `withoutReference` が先に効き、`ref` なし・`unset` になる。
  - P07：名前の無いカスタムの `needsReference` を読む箇所は、`writable` の計算（`ns === 'llm-pi-ai'` なので結果が同じ）と、`change` の参照名の書き込み（`ref` が無い行は先に止まる）だけ。
  - P12：照会のあとの `canSend` は、送信の直前の `canSend`（P13 は検出）と重なる。その間の参照名の書き込みは `needsReference` の行だけで、フォームが渡すカスタムの行は該当しない。
  - F01・F02・F03：明示名を集める処理が 2 か所にあり、互いを覆う。組み合わせの F01+F02、F01+F04、F02+F04 は、どれも単体で落ちることを確かめた。
  - F19・F20・F21：名前を外せたあとは `saved` で、入力と保存が無効になる。次に開くフォームは `load` で計算し直す。
  - S03：部分成功のあとの再試行で設定の分岐に入っても、`apiKeyEnv` は保存済みなので操作が空になり、書き込みは起きない。
  - S10・S11：二重送信の防止は、`saving` の 2 か所と、`phase` の検査（`savingSettings` の間は `save` が先に止まる）の 3 重。S10+S11 の組み合わせも生存したので、`phase` の検査が残る限り等価と判断した。キーなしの二重送信で書き込みが 1 回であることは `I16 A6 double submit S10/S11` で固定した。
  - O09：URL の正規表現をゆるめても、あとの `new URL` のプロトコルの検査で `http:` / `https:` 以外は止まる。

#### (5) 直した内容と、壊して確かめた表

修正は `ae74342`（G1・G2・G3）、監査で足した試験は `ca76cfa`。足した試験と期待を変えた試験は、修正の前の本体（または対応する変異）で落ちることを、1 件ずつ実行して確かめた。

| 試験 | 種類 | 壊した本体 | 結果 |
|---|---|---|---|
| `I16 G1 standard notice`（単体） | 追加 | 修正の前の `providers.ts`（`!row.needsReference`） | 落ちる |
| `I16 G2 detach` / `detach changed` / `detach conflict` / `detach failures`（単体） | 追加 | 修正の前の `custom-provider-store.ts`（外さない） | 4 件とも落ちる |
| `I16 G3 list destination`（単体） | 追加 | 修正の前（一覧の導出名を予約しない） | 落ちる |
| `I16 UI standard notice G1`（偽データ e2e） | 追加 | 修正の前の本体 | 落ちる |
| `I16 UI late registration`（偽データ e2e） | 期待を変更 | 修正の前の本体 | 落ちる |
| `I16 real numeric ID`（実 DSH、DeepSeek の補足の完全一致を追加） | 期待を追加 | 修正の前の本体 | 落ちる |
| `I16 real late registration`（実 DSH） | 期待を変更 | 修正の前の本体 | 落ちる |
| `I16 real list destination G3`（実 DSH） | 追加 | 修正の前の本体 | 落ちる |
| `I16 reference write close M47`（単体） | 期待を変更 | 変異 P09（カスタムに限らない） | 落ちる |
| `I16 R5 late registration` / `I16 R5 unknown result`（単体） | 期待を変更 | 修正の前の本体／変異 U10・F14 | 落ちる |
| `I16 A6 …` の 8 件（単体） | 追加 | 変異 P02、F16、S07、S15、S16、O06、O15、S10+S11（最後の組み合わせは生存。上の等価の判断を参照） | 7 件は落ちる |

既存の試験の期待を変えた理由：

- `I16 reference write close M47`：標準の行の `keyNotice` を `undefined` にした。G1 で、前からある種類の行を main と同じ表示に戻したため。
- `I16 R5 late registration`：理由の文言を `keyRegisteredMeanwhileMessage` に変え、外せたあと（`saved`、`apiKeyEnv` なし）の動きを確かめるようにした。同じフォームの再試行、シートの中の読み直し、一覧、開き直したフォームのどれからも、キーを送らないことは保ったまま。G2 の方針を変えたため。
- `I16 R5 unknown result`：文言を変え、`apiKeyEnv` の確認を足した。G2 のため。
- 偽データ e2e と実 DSH の `late registration`：外す書き込みが増えたので、書き込みは 2 件で最後が `unset`、行は「API キー：未設定」、開き直すと重なりで止まる、を確かめる。相手のキーは登録済みのまま、送ったキーは 0 件。G2 のため。

#### (6) 検証の件数

基準（`379299f`）：型検査とビルドは成功、単体 1,078 件、`check:pack` は成功、偽データの e2e 173 件（文書の値。この作業では基準の本体で流していない）、実 DSH は全 41 件（この作業で 1 回流して確かめた。通常の成功 40 件と、既知の差の期待失敗 1 件）。

最終（`ca76cfa` の本体）：

| 検証 | 結果 |
|---|---|
| `pnpm typecheck` | 成功 |
| `pnpm test`（単体） | 1,092 件すべて成功（基準より 14 件多い：`08-provider-review6` 6 件、`08-provider-audit6` 8 件） |
| `pnpm build` | 成功 |
| `pnpm run check:pack` | 成功（19 ファイル） |
| 偽データの e2e（`e2e/playwright.config.ts`） | 174 件すべて成功（`I16 UI standard notice G1` を足した） |
| 実 DSH の e2e 1 回目（`M3E_DSH_VERSION=0.2.0-rc.2`） | 全 42 件が期待どおり（通常の成功 41 件と、再接続の表示についての既知の差の期待失敗 1 件）。3.2 分 |
| 実 DSH の e2e 2 回目 | 1 回目と同じ。全 42 件が期待どおり（41 件と期待失敗 1 件）。3.2 分 |

偽データの成功と実 DSH の成功は、別々に数えた。実 DSH の 1 件の増加は `I16 real list destination G3`。

#### (7) 未検証のこと

- iOS の実機のキーボードと自動入力でのキー欄の扱い（Chromium の e2e だけで確かめた）。
- 実際の提供元への認証と推論（実 DSH は偽の LLM と 127.0.0.1 だけで動かした）。
- Host を再起動したあとに、外した参照名が残らないこと。
- 読み直しから送信までの時間差（既存の制限。5 回目の節を参照）と、閉じた直後に外す処理が走らない微小な時間差。
- 外せなかった場合に、DSH の標準の設定で参照名を外す手順の操作確認。
- `dsh-credentials` 系の内部（保護対象のため読んでいない）。資格情報の挙動は、統合試験で観測した範囲だけを根拠にした。

#### (8) `providers.ts` の main との差の一覧と理由

| 差 | 理由 |
|---|---|
| `ProviderAddress.declared?` | 実物の `listConfigurableProviders` が返す `declared` で、手で宣言した `llm-pi-ai` の提供元（カスタム）を見分ける |
| `ProviderRow.custom` / `keyNotice` / `status: 'unset'` | 名前の無いカスタムを「API キー：未設定」の行にし、キーの登録を編集のフォームへ回すため。`keyNotice` は、カスタムの行でキーが未登録のときだけ（6 回目で G1 を直し、前からある種類の行は main と同じ表示） |
| `native` から名前の無いカスタムを除き、`ref` を付けない・`needsReference: false` | 一覧から名前を自動で付ける経路を作らないため（5 回目までの判断） |
| `settingsWritable` / `customAvailable` | 「カスタムプロバイダーを追加」の可否と理由の表示 |
| `KeySaveOptions`（`canSend`、`requireMissing`）と `save` の第 3 引数 | フォームを閉じたあとに送らないため、フォームが付けたばかりの名前に別のキーが登録されていたら上書きしないため。一覧の `save` / `remove` は渡さないので、main と同じ動き |
| `keyRegisteredMeanwhileMessage` / `pendingKeyReferenceMessage` の import | 文言を `provider-key-refs.ts` の定数にして、フォームが `requireMissing` の停止を見分けるため（6 回目で `keyRegisteredMeanwhileMessage` を足した） |
| `createKeyDraft.clear()` | フォームが、送信の開始、キャンセル、破棄、外部変更のときに入力を消すため |

照会・登録・削除の流れ（1 回の `credentials.describe`、参照名の書き込み、`set` / `unset`、失敗の文言）は main と同じで、照会の分割と保存のあとの再検査は戻していない。

### 2026-10-05：5 回目のレビューへの対応（6 回目の節が優先）

開始時は `6652683`。5 回目のレビューは blocking 3 件、minor 1 件で、Issue #16 の前からある機能の回帰は解消したと判定された。この節は、次の「4 回目の判断による単純化」の方針を引き継ぎ、下に書く点だけを改める。食い違う記述は、この節が優先する。

#### `6652683` の時点の状態（次節の「06・07 待ち」の記述の、その後）

次節は `8e45f9f` の時点の記録で、「06 へ引き継ぎ」「07 待ち」「現在のソースには分割ファイルが残る」「現在は確認不能を返す」と書いている。その後の経緯は次のとおり。

- 06（一覧の照会を main と同じ 1 回の呼び出しへ戻す）、07（フォームが新しい参照名の 1 件を照会する接続）、08（main の失敗の契約を固定する試験）は、指示役が `6652683` で当てた。64 件ずつに分ける処理のファイル `provider-key-info.ts` は外し、いまのソースには無い。
- `6652683` での指示役の検証：型検査とビルドは成功、単体 1,073 件が成功、`check:pack` は成功、偽データの e2e は 171 件が成功、実 DSH は全 40 件（通常の成功 39 件と、既知の差の期待失敗 1 件）。次節の「最終検証」と受け入れ条件の表にある失敗（06・07 待ち）は、この時点で解消している。

#### 指摘 1：衝突の検査で、所有者を除外しない

以前は、設定で参照名を明示している提供元の一覧を `{ id, ref }` で持ち、別の名前空間の所有者の `id` を `名前空間/提供元 ID` という文字列にして、入力されたカスタムの ID と同じなら「自分自身」として除いていた。カスタムの ID は `/` を許すので、たとえば `llm-deepseek` の `deepseek` が `LLM_DEEPSEEK_DEEPSEEK_API_KEY` を明示しているとき、ID `llm-deepseek/deepseek` のカスタムプロバイダーは、導出名が同じなのに衝突を見逃した。

この検査が走るのは、キーが入力されていて、その提供元が参照名をまだ持たない場合だけである。その提供元が同じ名前を自分で明示していることはないので、「自分自身を除く」処理は要らない。所有者を別々の項目で識別する代わりに、除外そのものを外した。`provider-key-refs.ts` の `keyReferenceReason` / `keyReferenceConflict` は、明示されている名前の一覧と、これから付ける名前だけを受け取る。

#### 指摘 2：新しく付けた参照名へは、未登録のときだけキーを送る

設定の保存に付ける revision は `llm-pi-ai` のもので、別の名前空間の設定と、キーの保存先の変化は検出しない。そのため、次の順で、ほかのキーを上書きできた。

1. 画面 A が `acme` をキーつきで追加し、`ACME_API_KEY` が未登録であることを確かめる。
2. 画面 B が、別の名前空間の提供元の参照先を `ACME_API_KEY` にして、キーを登録する。
3. A の設定の保存は、`llm-pi-ai` の revision が変わっていないので成功する。
4. A のキーの保存が、B のキーを上書きする。

指示役の判断にしたがい、次のようにした。

- `providers.ts` の `change` は、キーを送る直前に登録の状況を読み直している。`KeySaveOptions` に任意の `requireMissing` を足し、指定があるときだけ、読み直した結果が「未登録」でなければ、キーを送らずに理由を返す。指定が無い経路（一覧からの登録・削除、参照名のない標準の提供元）は main と同じまま。
- フォーム（`custom-provider-store.ts`）は、この保存で付けた参照名を `assignedReference` に覚え、その名前へのキーの保存にだけ `requireMissing` を付ける。覚えるのは、保存先の照会を通って、設定を送る直前。フォームを開いている間は消さない。したがって、部分成功のあとの同じシートでの再試行、シートの中での読み直し、設定の応答を失ったあとの「保存結果を確認」のあとでも、同じ確認が続く。
- フォームを開き直すと、新しい状態から始まり、参照名は設定に明示されたものとして読み込まれる。これまでの方針どおり、ふつうのキーの登録として扱う（一覧からの登録と同じ）。
- 止めたときは、部分成功の説明に続けて「設定を保存する間に、この参照名のキーが登録されました。上書きを避けるため、API キーを送信していません。この提供元は登録済みのキーを参照します。提供元の設定とキーを確認してください。」を出す。

これにより、次節の「設定成功後の同名の明示は、その操作側が意図した共有として扱う。設定後と再試行では衝突・configured の検査をしない」は、次のように改まる。衝突（名前の重なり）の検査と保存先の照会は、いまも設定の保存の前に 1 回だけで、再試行ではやり直さない。ただし、同じフォームからのキーの送信は、その名前がまだ未登録である場合にかぎる。別の画面が同じ名前を明示しただけ（キーは未登録）なら、これまでどおり送る。

**残る時間差（既存の制限）。** 確認は「読み直しから送信まで」の間を守れない。DSH の `credentials` には「未登録のときだけ書く」操作が無く、画面の側だけでは無くせない。同じ時間差は main にもある。`git show origin/main:web/src/features/settings/providers.ts` の `change`（138〜178 行）は、150 行で登録の状況を読み、参照名のない標準の提供元なら 159 行で導出した名前を `settings.update` で付け、163 行で `credentials.set` を呼ぶ。150 行の読み取りから 163 行の送信までに、ほかの提供元がその名前を明示してキーを登録すれば、同じように上書きになる。この時間差は、既存の制限として扱う。

**残る状態。** 止めたあとも、設定には参照名が残る。その名前には別のキーが登録されているので、このカスタムプロバイダーは、そのキーを参照する状態になる。画面は、そのことを文言で伝えるだけで、参照名を外す書き込みはしない（設定をもう一度書き換える操作は、指示の範囲に無く、それ自体が失敗や競合を起こし得るため）。利用者が、意図した共有かどうかを確かめる。

監査の B04（`I16 retry sharing B04`）は、キーの保存を偽物に置き換えた試験で、再試行で設定を送り直さないことと、保存先の照会をやり直さないことを確かめている。いまも正しい。再試行でキーを送るかどうかは、本物のキーの保存（`providers.ts`）が読み直した登録の状況で決まり、それは下の R5 の試験が確かめる。

#### 指摘 3：外していた照会の上限の試験を戻す

前の回に外した `I16 R3 lookup limit` は、64 件ずつに分ける処理の試験ではなく、偽の RPC が「64 件を受け付け、65 件を拒否する」という、いまも残っている契約の確認だった。根拠は `web/src/features/settings/mock.ts` の `describe` と、実物の `dsh-api-settings-controller/lib/index.js` の 55〜57 行（`MAX_DESCRIBE_REFS = 64`、超えると `gateway/bad-request`）。`tests/08-mock.test.ts` に `I16 lookup limit` として戻した。受け付けた 64 件の名前がそのまま返ることと、拒否のコードも確かめる。次節の表の「R3 lookup limit：削除」は、この回で取り消した。

#### 指摘 4：一覧の補足

カスタムの行から「（変更できません）」の補足が無くなっていた。参照名を持たない行は、「API キー：未設定」と「API キーは「編集」から登録できます。」で理由が伝わるので、変えない。参照名を持つ行は、キーを変更できないとき（キーの保存先だけが読み取り専用、など）に「API キー」のボタンが無効になるだけで理由が出ていなかったので、main の一覧と同じ条件（参照名があり、変更できず、登録状況が分かっている）で「（変更できません）」を添える。

#### `providers.ts` の main との差（この回の時点）

| 箇所 | 差と理由 |
|---|---|
| 型（`ProviderAddress.declared`、`ProviderRow.custom` / `keyNotice`、`status` の `unset`） | カスタムプロバイダーの識別、参照先なしの表示、参照先だけ設定された行の案内 |
| `ProviderState.settingsWritable` / `customAvailable` と、その publish | 「カスタムプロバイダーを追加」の可否 |
| `providerRows` | `declared` のカスタムで参照名が無い行は、名前を導出せず、`unset`、`needsReference` は false |
| 照会の結果に `keyNotice` を付ける 1 行 | 参照名が明示されていてキーが未登録の行の案内 |
| `KeySaveOptions`（`canSend`、`requireMissing`）と、`change` / `save` の引数 | フォームから任意で渡す。指定が無ければ main と同じ |
| `change` の `canSend` の判定 2 か所 | 閉じたフォームからキーを送らない |
| `change` の `requireMissing` の判定 1 か所（この回に追加） | フォームが新しく付けた参照名へは、未登録のときだけキーを送る |
| `createKeyDraft.clear()` | 読み直しと切断のときに入力を消す |

次節の表にある「残っている未完了差（分割 import と呼出し）」は、`6652683` で無くなった。

#### 試験の対応

| 試験 | 内容 |
|---|---|
| `I16 R5 foreign owner`（`tests/08-provider-destinations.test.ts`、追加） | `llm-deepseek` の `deepseek` が明示した名前と、ID `llm-deepseek/deepseek` の導出名が同じ場合に、追加と、編集でのあと付けが止まり、設定もキーも書かれない |
| `I16 destinations owners`（入力を変更） | 関数の引数から ID が無くなったので、呼び出しの引数を直した。名前ごとの期待（衝突する・しない）は同じ。ID だけが違って結果が同じになる行は、まとめた |
| `I16 R5 late registration`（`tests/08-provider-review5.test.ts`、追加） | 設定の保存の応答を保留し、その間に `llm-deepseek` が同じ名前を明示してキーを登録する。フォームからの送信は 0 件、理由が出る。同じフォームの再試行と、シートの中の読み直しのあとも送らない。一覧からの登録（指定なし）は main と同じく送る。開き直したフォームからも送る |
| `I16 R5 unknown result`（追加） | 設定の応答を失ったあとの確認で、別に登録されていれば送らず、未登録なら送る |
| `I16 R5 retry`（追加） | キーが拒否されただけで、未登録のままなら、同じフォームの再試行で送る（止めすぎないこと） |
| `I16 lookup limit`（`tests/08-mock.test.ts`、戻した） | 偽の照会が 64 件を受け付け、65 件を拒否する |
| `I16 UI late registration`（偽データの画面、追加） | 上の late registration を画面で確かめる。理由の表示、キーの欄が空に戻ること、送信の記録 |
| `I16 UI fixed key`（偽データの画面、追加） | 参照名を持つカスタムの行。変更できる場合は補足なしでボタンが有効、キーだけ読み取り専用なら「（変更できません）」が出てボタンが無効、編集は有効 |
| `I16 real late registration`（実 DSH、追加） | 1 つ目のページの設定の応答だけを保留し、2 つ目のページから `llm-deepseek` の参照先とキーを操作する。1 つ目のページからのキーの送信は 0 件、理由が出る、再試行でも 0 件。一覧からの登録で 1 件になる（数え方が正しいことの確認を兼ねる） |

別の画面の操作が入る位置は 2 通りを確かめている。単体と実 DSH の試験は、設定の書き込みが Host に反映されたあと、応答を受け取る前。偽データの画面の試験は、設定の書き込みが反映される前（レビューが示した順）。どちらも、キーを送る直前の読み直しで止まる。

main と同じ動きを固定している試験（`tests/08-provider-review4.test.ts`、`tests/08-providers.test.ts`）は、入力も期待も変えていない。

#### 壊して確かめた表（この回）

どれも、一時的に当てて、落ちることを見て、元に戻した。

| 試験 | 当てた変更 | 落ちたこと |
|---|---|---|
| R5 foreign owner | 直す前の本体（`6652683`）でそのまま実行 | 止まるはずの追加が成功した（`submit()` が true） |
| R5 foreign owner | `custom-provider-store.ts`：別の名前空間の明示名を集めない（`entry.settingsNs === CUSTOM_NS` の条件を足す） | 同上 |
| R5 foreign owner、destinations owners、既存の explicit reference / partial | `provider-key-refs.ts`：明示名との比較を常に偽にする | 4 件とも、衝突を期待する断言で落ちた |
| destinations owners、destinations native | `provider-key-refs.ts`：標準の既定名の予約の行を消す | 予約を期待する断言で落ちた |
| R5 late registration | 直す前の本体（`6652683` に指摘 1 の直しだけを当てた状態）でそのまま実行 | フォームの保存が成功し、キーが送られた |
| R5 late registration、R5 unknown result | `providers.ts`：`requireMissing` の判定を無効にする | 2 件とも、フォームの保存が成功し、キーが送られた |
| R5 late registration | `custom-provider-store.ts`：1 回目のキーの保存のあとに `assignedReference` を消す | 同じフォームの再試行が成功した |
| R5 late registration、R5 unknown result | `custom-provider-store.ts`：読み直し（`load`）で `assignedReference` を消す | 読み直しのあとの保存が成功した |
| R5 unknown result | `custom-provider-store.ts`：`assignedReference` を、設定の成功の応答を受けたあとにだけ覚える | 応答を失ったあとの保存が成功した |
| R5 late registration | `providers.ts`：`requireMissing` の指定が無くても判定する | 一覧からの登録が拒否され、main と同じ `{ ok: true }` の期待で落ちた |
| R5 late registration、R5 unknown result、R5 retry | `providers.ts`：判定を逆にする（未登録のときに止める） | 3 件とも落ちた。R5 retry は、未登録への再試行が拒否された |
| I16 lookup limit | `mock.ts`：`refs.length > 64` の判定を消す | 65 件が受け付けられた |
| UI fixed key | `ProvidersPanel.tsx`：カスタムの行の補足を消す | 「（変更できません）」が見つからない |
| UI fixed key | `ProvidersPanel.tsx`：変更できる行にも補足を出す | 補足が無いことの断言で落ちた |
| UI late registration | `providers.ts`：`requireMissing` の判定を無効にする | 理由の表示が見つからない（保存が成功してシートが閉じた） |
| UI late registration | `custom-provider-store.ts`：1 回目のあとに `assignedReference` を消す | 再試行が成功してシートが閉じた |
| real late registration | `providers.ts`：`requireMissing` の判定を無効にする | 実 DSH で、理由の表示が見つからない（保存が成功した） |
| real late registration | `custom-provider-store.ts`：1 回目のあとに `assignedReference` を消す | 実 DSH で、再試行が成功してシートが閉じた |

#### 検証（この回の最後）

コードの最後のコミット（`e247b94`）で、共通の決まりの確かめ方を全部流した。このあとのコミットは文書だけである。

| 確認 | 結果 |
|---|---|
| `pnpm typecheck` | 成功 |
| `pnpm test`（単体。偽データ） | 1,078 件が成功、失敗・skip・cancelled は 0。`6652683` の 1,073 件に、R5 foreign owner、R5 late registration、R5 unknown result、R5 retry、I16 lookup limit の 5 件を足した |
| `pnpm build` | 成功（既存の 500 kB 超の chunk の警告あり） |
| `pnpm run check:pack` | 成功（19 ファイル） |
| 偽データの e2e（`tmp/e2e-alt-port.config.ts`） | 173 件が成功、失敗・skip・flaky は 0。171 件に、UI late registration と UI fixed key の 2 件を足した |
| 実 DSH 0.2.0-rc.2 の e2e（偽の LLM）1 回目 | 全 41 件。通常の成功 40 件、既知の差の期待失敗 1 件、予期しない失敗・skip・flaky は 0 |
| 実 DSH 0.2.0-rc.2 の e2e（偽の LLM）2 回目 | 同じ（全 41 件。通常の成功 40 件、期待失敗 1 件） |

実 DSH の 40 件に足した 1 件は real late registration。既知の期待失敗は、Host が止まったままでも切断の表示へ変わらない、従来の 1 件。記録は `tmp/issue16-review5-logs/`（Git の管理外）に置いた。

確かめていないこと：実際の提供元への認証と推論、iOS Safari／PWA の実機のキーボード、Host を再起動したあとの保持。止めたあとに残る「登録済みのキーを参照する状態」を、DSH の標準の画面で解消する手順は、この作業では操作して確かめていない。

### 2026-10-05：4 回目の判断による単純化（方針は継続。上の 5 回目の節が優先）

この節は `8e45f9f` の時点の記録。06〜08 を「引き継ぎ」「待ち」としている記述は、`6652683` で適用済み（上の節の「`6652683` の時点の状態」）。

開始時は `c015aee`。04 の接続・05 の試験はこのコミットで適用済みだが、照会例外を吸収する回帰が残っていた。既存 `tests/08-providers.test.ts:204` の失敗を再現した。今回、一覧の二段保存へ衝突の文脈を持ち込む設計と分割照会を廃止する。以下が旧節より優先する。

#### A・B：一覧の既存動作と参照先なしのカスタム

一覧のキー RPC は `origin/main`（`23e8ec6`）と同じ一括照会へ戻す。拒否・不正な状態は ready/unknown と一部確認不能の案内、例外は error、load の戻り値 false、一覧の取得失敗の案内。標準の未稼働 pi-ai 提供元は、参照書込みが成功すればキーを送り、最後の再取得に失敗してもキー保存は成功とする。新規参照・共有の検査、書込み後の再検査、newReference/attachingReference の文脈を共通保存から除去した。canSend がなければ main の流れとなる。

`declared: true` のカスタムで apiKeyEnv がなければ ref を導出しない。状態は unset（「API キー：未設定」）、書込み不可。「API キー」は出さず、編集から登録する案内を出す。照会対象が増えないため、70 件や数字始まりのキーなし ID を混ぜても、既存行を巻き込まない。設定トップにも未設定の件数を表示する。

**一括照会への実際の接続は保護チェックで拒否されたため 06 へ引き継ぎ。** この時点（`8e45f9f`）のソースには接続と未使用化する分割ファイルが残っていた。06 適用時に import・呼出しを main のブロックへ戻し、`provider-key-info.ts` を削除する、という引き継ぎで、既存の例外試験はこの時点では未解消だった。既存 `08-providers.test.ts` は入力・期待とも変えていない。**その後：06 は `6652683` で適用済み。分割のファイルは外し、既存の例外試験は成功している。**

#### C・D：フォームだけで参照先を付ける

フォームが読み込んだ設定から他の提供元の明示名を集め、同じ設定の revision で mutate する。キーつき追加の provider 全体の set、または編集の apiKeyEnv の set に参照先を含める。キーなしカスタムの ID から導出した候補は予約しない。標準の既定名と AWS_/GOOGLE_/GCLOUD_/CLOUDFLARE_ の予約は残すが、フォームの新規参照にだけ使う。明示参照同士の比較は大小文字を区別する。

新しい参照先に限って、設定を送る前にその 1 件の登録状況を照会する。configured が true、応答が取れない・不正、writable が false なら欄エラーで止める。参照名の形式も先に検査する。キーの値は照会しない。照会中は保存中として二重送信を止め、入力を消し、閉じた後の応答では設定もキーも送らない。**RPC の接続は保護チェックで拒否され 07 へ引き継ぎ。** この時点（`8e45f9f`）では確認不能を返すため、新しい参照へのキーつき保存は停止していた。試験専用の注入可能な reader では状態管理を確認し、既定の reader の未接続を試験で検出していた。**その後：07 は `6652683` で適用済み。既定の reader（`custom-provider-key.ts`）が実際に 1 件を照会し、新しい参照へのキーつき保存は動く。**

同じ llm-pi-ai 名前空間の変更は、開いた版での mutate が競合として拒否する。別の名前空間の設定やキーの登録状況とは原子的な検査にならない。キー照会からキー保存までに別操作が登録する競合も、この API には未登録時だけ書く条件付き保存がないため同時に防げない。今回の指定どおり、設定成功後の同名の明示は、その操作側が意図した共有として扱う。設定後と再試行では衝突・configured の検査をしない（5 回目で一部を改めた：フォームが新しく付けた参照名へのキーの送信は、送る直前の読み直しで未登録の場合にかぎる。上の節の「指摘 2」）。通常のキー登録が行う対象・参照先・書込み可否の再確認と canSend は残す。

部分成功は設定の成功応答（ID、revision、値）を編集の初期値に確定する。同じシートの再試行はキーのみで、開き直した後と一覧からも通常の明示参照の操作。keyNotice は保持する。失敗の理由は partialMessage で捨てず、キー保存の処理が返した日本語の message を続ける。Host の生のメッセージは出さない。

予約・明示名・登録済みのエラーには、導出名、止めた理由、別の ID の例（my- を付ける）を表示する。例が常に空いている保証はなく、「ほかと重ならない」と案内する。編集では ID を変更できないので、キーを空欄にするか別 ID で追加する案内とする。

#### main との差の一覧

| ファイル | 残す差と理由 |
|---|---|
| providers.ts：型と providerRows | declared/custom、unset、参照先なしカスタムの ref/needsReference を外す。追加編集と正しい表示のため |
| providers.ts：状態 | settingsWritable/customAvailable は追加ボタンの可否。keyNotice は参照だけ保存した未登録状態の案内 |
| providers.ts：change/save | 任意の canSend と送信前 2 か所の中止判定だけ。フォームが閉じたあとの送信を防ぐ。指定なしの一覧は main と同じ |
| providers.ts：createKeyDraft | clear() は再読込み・切断時の入力破棄 |
| providers.ts：残っている未完了差 | 分割 import と呼出し。設計では廃止、06 適用待ち。正当化する機能差ではない（`6652683` で無くなった） |
| ProvidersPanel.tsx：追加・編集 | 全画面フォーム、編集中 controller の寿命と更新通知、保存中の二重起動抑止 |
| ProvidersPanel.tsx：カスタム行 | 編集入口、unset の表示、ref のない行のキー入口を非表示、keyNotice。既存 KeyEntry/RemoveKey の保存・確認・削除は変更なし |

#### E：試験の対応づけと B04

| 旧試験 | 今回の扱いと理由 |
|---|---|
| R3 main parity / many references | R4 main parity へ統合・書き直し。70 件は照会しない。毎回新しい fixture で未稼働標準の参照なしを再現し、アカウント、非 pi-ai、稼働中 pi-ai も追加 |
| R3 post-reference race | 削除。カスタムの一覧からの参照書込み自体を廃止。保存後の共有を許す reference recheck と、保存前の競合試験へ置換 |
| R3 batches / partial lookup | 削除。分割と一部失敗を保つ動作を廃止し、main の失敗契約へ戻す。補強試験は 08 に引き継ぎ |
| R3 lookup limit | 削除。Host/偽データの上限自体は変えず、新しく照会件数を増やさない設計に置換（5 回目で取り消し：残っている契約の確認だったので、`tests/08-mock.test.ts` の `I16 lookup limit` として戻した） |
| R3 case N09 | 旧一覧後付けを含む試験を削除。明示名の大小文字の区別は destinations owners と既存の実 DSH N09 で維持 |
| destinations list / native / owners | 書き直し。unset、予約の具体的理由、キーなし ID は予約しないことを確認。標準所有者への制限はなく、フォームの新規参照に予約例外は不要 |
| reference recheck | 書き直し。設定後の同名の明示を許し、両行が登録済みとなることを確認 |
| reference write close M47 | 標準の未稼働行に fixture を変更。カスタムの一覧後付けを廃止したため。canSend による中止、送信 0 件、再開と keyNotice は維持 |
| partial / explicit reference | キーなし ID からの衝突を明示参照からの衝突へ変更し、具体的理由・参照名・例を確認。部分成功の理由を追加断言 |
| numeric ID / UI lifecycle・destinations・saving / real numeric・lifecycle | 参照先なしの表示を unset と入口なしへ変更。UI saving と real lifecycle のキーあり部分は 07 待ち |
| UI partial / real failures | キー保存が返した理由を含む期待へ変更。設定を再送しない既存の確認は維持 |
| real destinations | 一覧の後付けを、編集フォームの後付けへ変更。別ページで既存側の状態と設定が変わらないことを確認 |

close と key recheck close は、新しく入った保存先照会の待機を fixture に加えた。前者は設定の送信開始を待って閉じ、後者は専用 reader を注入して従来の再照会中断点を保つ。試験が確認するキー送信 0 件は維持する。B04 の「部分成功後の衝突検査を飛ばす」は、今回の設計では正しい処理であり変異の対象から外す。逆に保存済み参照へ configured の検査を再導入すると、retry sharing B04 が落ちる。

#### 検証・引き継ぎ

`tmp/handoff-issue16-06.md` は main 照会への復元、07 はフォームの 1 件照会、08 は main の失敗契約の追加試験。いずれも通常 apply_patch を 1 回試して拒否されたため引き継ぐ。保護対象のパッケージは読んでいない。

実物 `tmp/dsh-integration/dsh-0.2.0-rc.2/node_modules/@deepseek-ai/dsh-api-settings-controller/lib/index.js:55–70,148–161` を再確認し、参照名の形式、64 件上限、名前ごとの照会を確認した。標準の予約表は前節の調査を保持し、増やしていない。キー専用照会の configured/writable は `providers.ts` の既存 keyInfo で真偽値を検証する。実際の新 reader の照会は 07 待ち。

新規・書き直し試験は以下の変更を一時的に当てて失敗を確認し、すべて復元した。各試験ごとの詳細は `tmp/handoff-issue16-review4-fixes.md`。

| 試験 | 壊した処理と失敗 |
|---|---|
| R4 main parity / destinations list / numeric ID | 参照なしでも導出名を作る。既存の照会失敗・不正な ref・許してはいけない一覧登録を検出 |
| R4 native write | 参照書込み直後に拒否する。main と異なる保存 false を検出 |
| key recheck close / M47 | canSend を外す。終了後のキー送信を検出 |
| destinations native / owners | 標準既定名の予約を外す。衝突漏れと理由の欠落を検出 |
| explicit reference / partial | 明示名の衝突を外す。拒否すべき保存の成功を検出 |
| preflight | configured の判定を外す。登録済みの受理を検出 |
| preflight revision | 開いた revision に 1 を足す。競合すべき保存の成功を検出 |
| preflight close | 照会後の終了判定を外す。閉じた後の設定送信 1 件を検出 |
| close | dispose を無処理にする。閉じた後の成功を検出 |
| retry sharing B04 | 設定後にも configured を再検査する。正しいキー再試行の拒否を検出 |
| reference recheck / destinations reopen | 共通保存に共有拒否を戻す。正しい登録の拒否を検出 |
| partial / real failures | 失敗理由を捨てる。部分成功の説明から理由が消えて失敗 |
| UI / real destinations | 明示名の衝突検査を外す。衝突の案内がなくなり失敗。07 待ちの確認不能にも阻止されるため、上書きそのものの検出とは区別 |
| UI lifecycle / real numeric | unset を未登録と表示する。表示の期待で失敗 |
| real notification / real case N09 | 同上。変更した共通 helper の期待を検出したもので、通知や大小文字の新たな変異ではない |
| UI reserved | エラーから導出名と例を消す。導出名の期待で失敗 |
| destination RPC / orphan destination | 正常でも 07 未接続で失敗するため、適用後の変異検証が必要 |
| UI partial / UI saving M39 / real lifecycle | 正常な新規キーつき保存が 07 待ちのため、今回書き換えた部分の変異検証も適用後 |

最終検証：型検査・ビルド・配布検査は成功（19 ファイル、既存のチャンク容量警告あり）。単体は 1,072 件中 1,069 件成功・3 件失敗、skip/cancelled 0。失敗は既存の照会例外試験（06 待ち）と destination RPC / orphan destination（07 待ち）。偽データ全体は 171 件中 167 件成功・4 件失敗（UI refused / partial / late / saving M39、すべて 07 待ち）。実 DSH 全体は 2 回とも通常成功 38 件・既知の期待失敗 1 件・失敗 1 件（real lifecycle、07 待ち）。e2e の skip/flaky はいずれも 0。結果は `tmp/issue16-review4-mock-final.json`、`tmp/issue16-review4-real-final-1.json`、`tmp/issue16-review4-real-final-2.json` に保存した。実提供元の認証と iOS 実キーボードは対象外のまま。06〜08 の適用後の全体検証が残り、完了とはしていない。（その後：`6652683` で 06〜08 を適用し、ここに挙げた失敗は解消した。件数は上の節。）

| 受け入れ条件 | `8e45f9f` の時点の判定（06・07 待ちは `6652683` で解消） |
|---|---|
| 1 追加・編集の入口と共通フォーム | 一部未達。キーなし・既存明示参照は動作、新規キーつきは 07 待ち |
| 2 再表示と他設定・未知項目・モデル選択の保持 | 一部未検証。差分保存・衝突・競合は確認、キーつき lifecycle は 07 待ち |
| 3 入力検査と欄エラー | 一部未検証。静的検査・予約理由・注入 reader の configured 検査は確認、実接続は 07 待ち |
| 4 非表示・空欄維持・消去 | 確認済み。既存単体と終了後の送信 0 件を確認 |
| 5 各失敗と部分成功 | 一部未検証。詳細理由とキーのみ再試行を単体・既存明示参照の実 DSH で確認。新規参照の UI partial は 07 待ち |
| 6 キャンセル・連打・再表示・終了操作 | 一部未検証。単体と通る UI は維持、新規参照の UI late / saving は 07 待ち |
| 7 小画面と既存機能の回帰なし | 未達。main の例外契約が 06 待ち。通常行・70件混在・375px は確認。iOS 実機キーボードは未検証 |
| 8 試験と品質コマンド | 未達。06・07・08 の適用と全体検証が必要 |

### 2026-10-05：3 回目のレビューと監査（以下は当時の履歴）

この節は 3 回目当時の方針と検証。4 回目の単純化により更新した。04・05 は後に `c015aee` で適用されたが、分割照会と保存後の衝突検査は今回の設計では廃止。開始時の HEAD は `e187882`。03 の試験と M47 は適用済みで、この時点で正常実行を確認した。

#### main と同じに保つ範囲

`git show origin/main:web/src/features/settings/providers.ts`（`23e8ec6`）の `providerRows`・`read`・`change` を読み、次を単体 `I16 R3 main parity` の期待値に固定した。参照未設定のカスタムを追加する前後の両方で確認する。

| 既存の行 | main の状態・操作の期待 |
|---|---|
| 稼働中の標準、参照名なし | ref なし、`unnecessary`、変更不可、登録・削除とも拒否。偽データの ollama で確認 |
| 未稼働の標準、参照名なし（pi-ai） | 導出名で missing/registered を照会。登録時は参照を追加し、登録・削除できる。openai で確認 |
| 明示参照あり | 実際の参照の missing/registered と writable に従い、登録・削除できる。owner と既存 deepseek で確認 |
| 同じ名前を明示する 2 行 | 両方を操作でき、一方の登録・削除が他方の登録状態にも反映。share-one/share-two で確認 |
| 混在する参照未設定のカスタム | この行だけを新しい参照の候補として検査。既存の owner・標準・明示共有の操作は変えない |

#### 残した検査と保存の途中の扱い

フォームのキーつき追加、参照未設定のカスタムへの後付け登録（フォームと一覧）だけが衝突検査の対象。`providers.ts` は `custom && needsReference` の行だけに衝突理由を付ける。明示済みの行や標準の行を予約表で操作不可にしない。新しい側には他の所有者のキーを登録済みとして表示せず、登録・削除の入口を無効にする。キーなしの設定保存は可能。

`custom-provider-store.ts` は保存開始時に参照を新しく足すかを保持し、共通保存に `newReference` を渡す。設定の成功で apiKeyEnv が付いた直後と、同じシートでの部分成功の再試行も、この操作の間は検査を続ける。閉じて開き直すと保存済みの明示参照として main と同じ扱いになる。参照が付いた由来を永続化して共有を禁止する案は、既存の明示共有を意図したものとする原則 1 と合わないため採用しない。

一覧の参照追加（`settings.update`）の応答後は設定を読み直し、対象の存在、参照名、namespace/path、書込み可否、他の所有者との衝突を再確認する。更新通知で再照会中の版が変わったら再度読む。キーを送る直前の終了判定は維持する。途中で衝突すればキーは保存せず、参照先だけが残り得ることを案内する。直接の送信件数の検査は保護チェックで止まったため 05 へ引き継ぐが、適用済みの試験は失敗結果・両行の未登録・keyNotice を確認する。

保存先の集合（明示名・導出名・標準既定名と補助名群）は前節の実物調査を保持し、新しい参照の検査だけに使う。参照名の大文字・小文字は区別する。実物の `dsh-api-settings-controller/lib/index.js:55–70,148–177` の検証は両方の文字を許す。保護対象の保存内部は読まず、実 DSH で `i16_case_api_key` と `I16_CASE_API_KEY` の登録状態が独立し、一方の削除が他方を消さないことを確認した。

#### 64 件の上限と部分失敗

実物の `dsh-api-settings-controller/lib/index.js:55–57` の 64 は参照名の長さではなく、1 回の照会の個数。偽データの `mock.ts:119–123` にも同じ上限がある。`provider-key-info.ts` で 64 件ずつ照会し、成功した回の値だけを返す。拒否・例外の回はその回の行だけ unknown/変更不可とし、ほかの行の表示・操作を保つ。main の「取得できない状態は unknown」という規則を各回に適用し、多数の新しい行の失敗で既存行を巻き込まない選択。全体を失敗にする案は採用しない。

当時は保護チェックで止まり 04・05 に引き継いだが、**`c015aee` で接続と試験は適用済み**。その後 main の例外契約の回帰が見つかり、4 回目の方針で分割を廃止する。下の未適用・失敗の集計は 3 回目の終了時点の履歴であり、現在の判定ではない。

#### 試験の期待を変えた理由（1 件ずつ）

| 試験 | 変更と理由 |
|---|---|
| I16 destinations reopen | 明示共有を開き直すと拒否 → フォームと一覧から登録・削除でき、他方の状態にも反映。原則 1 に従い旧制限を外す |
| I16 reference recheck | 保存結果は引き続き拒否。設定に参照が付いた両行の状態は unknown → missing、既存所有者は writable。原則 1・3 により状態の照会と新規操作の拒否を分離 |
| I16 UI destinations | 衝突時のカスタム側へ apiKeyEnv を明示する設定を外し、参照未設定での拒否を確認。原則 2 に対象を限定。衝突解除後には明示参照を付け、既存の keyNotice と再登録の確認を維持 |

実 DSH の既存 RPC 競合試験は弱めず残した。通知だけで保存を押さずに警告・保存無効・書込み 0 件を確認する `I16 real notification` を別に追加。`I16 real destinations` はフォーム追加と、一覧の入力画面を開いた後の別ページの参照変更を試す。別ページを読み直して既存側の未登録状態と変更可否、設定全体が変わらないことを確認する。通知を保留するのは後者で保存時の再照会を独立して検査するためで、通常の通知だけの試験とは分けた。

#### 検証と未適用分

指摘 1〜3 は先に現行本体で 3 件すべて失敗を確認（明示共有の操作拒否、参照書込み後の誤った成功、多数照会で既存行が unknown）。今回の追加依存・偽データファイル・配布用ファイルの変更はない。

| 試験 | 壊した処理 | 結果 |
|---|---|---|
| R3 main parity | 行の衝突判定を新規の行だけでなく全行に戻す | 明示共有の writable=false で失敗 |
| destinations reopen | 同上 | 明示共有のフォーム保存が false で失敗 |
| reference recheck | 同上 | 明示行が missing でなく unknown となり失敗 |
| reference recheck（新規操作） | フォームから共通保存へ渡す newReference を false | 衝突後に保存が成功して失敗 |
| R3 post-reference race | 参照書込み後の再照会を除去 | 衝突後にキー保存が成功して失敗 |
| R3 batches | 64 件を 65 件へ変更 | 64/64/2 でなく 65/65 となり失敗 |
| R3 batches（部分失敗） | 一度拒否されたら全体を空で終了 | 最後の回を照会せず失敗 |
| R3 case N09 | 参照名を両方大文字にして照合 | 別名を衝突と扱って失敗。監査と同じ変異 |
| UI destinations | 行表示と共通保存の衝突検査を除去 | 衝突の案内が消えて失敗 |
| real destinations | 同上（N06 相当、フォームの事前検査は維持） | 新しい側が unknown でなく missing となり失敗 |
| real notification | updated の先頭で return | 保存前の競合警告が出ず失敗 |
| real case N09 | 参照名の検査で小文字を拒否 | 小文字側のキー入口が無効で失敗 |
| R3 many references | 分割接続は未適用 | 現在も失敗。正常通過後の変異検査は 04 適用後 |
| 05 の直接 RPC 試験 | 試験自体が未適用 | 未実行 |

変異はすべて `git restore` で戻した。実 DSH の大小文字試験に当てた故障は小文字の過剰拒否であり、単体に当てた N09 とは区別する。詳細な場所・試験名・期待変更の理由は `tmp/handoff-issue16-review3-fixes.md`。画面の失敗結果は `tmp/issue16-review3-N06-ui.json`、`tmp/issue16-review3-N06-real.json`、`tmp/issue16-review3-notification-mutation.json`、`tmp/issue16-review3-case-mutation.json`。

- 型検査・ビルド・配布検査：成功。配布 19 ファイル。既存のチャンク容量警告は残る。
- 単体：全 1,069 件中 1,068 件成功、1 件失敗、skip 0。失敗は `I16 R3 many references` だけ。04 の接続がないためで、試験は消さず残した。
- 偽データ全体 e2e：170 件成功、予期しない失敗・skip・flaky 0。
- 実 DSH 全体：2 回とも通常成功 39 件＋既知の期待失敗 1 件、予期しない失敗・skip・flaky 0。結果は `tmp/issue16-review3-real-final-1.json`、`tmp/issue16-review3-real-final-2.json`。偽データは `tmp/issue16-review3-mock-final.json`。

| 受け入れ条件 | この回の判定 |
|---|---|
| 1 追加・編集の入口とフォーム | 充足。UI / real lifecycle |
| 2 保存値・他の提供元・未知項目・選択モデルの保持 | 修正・実測済み。参照書込み待ちの衝突は失敗結果と未登録維持を確認。直接送信 0 件の追加断言は 05 待ち |
| 3 入力検査と欄エラー | 充足。従来の単体・UI と N09 の区別、衝突の実 DSH |
| 4 キーの非表示・空欄で保持・入力消去 | 充足。M47 は e187882 で適用済み、今回も正常成功 |
| 5 各失敗と部分成功 | 従来の失敗シナリオは維持。多数照会の部分失敗は処理単体のみ確認し、接続と直接 RPC 試験は 04・05 待ち |
| 6 キャンセル・二重送信・戻る・閉じる | 充足。既存の単体・UI・M47 を維持 |
| 7 375–390px と既存操作の回帰 | 一部未達。通常件数の main 互換は確認、多数参照は 04 待ち。iOS 実機キーボードは未検証 |
| 8 単体・e2e・型・ビルド | 未達。単体 1 件が失敗。04・05 の適用とその検証が必要 |

止められた操作は、04 の接続と 05 の試験への通常 apply_patch 各 1 回。理由はキー RPC 名を含む行が保護チェックの対象になったため。回避はしていない。実 DSH のモデルは偽物であり、実提供元の認証・推論、保護された保存内部、iOS 実機は検証していない。

### 2026-09-25：設定タブの実装と、認証操作の保留

- 作業ブランチは `feat/08-settings`。土台 `25e3b2d` を元にした worktree 内だけで作業し、main の変更、merge、rebase はしていない。
- 設定トップの「この端末」「DSH の設定」、詳細 5 ページと「そのほか」、外観シート、標準の画面へ戻す確認ダイアログを実装した。画面の版はルートの package.json から読む。外観は土台の端末設定を使い、DSH のテーマとは共有しない。
- スキーマの参照展開・項目モデル生成・ページ分類・数値検査・保存差分を `schema.ts` の純粋関数に分けた。未知の型、配列、辞書は読み取り専用。真偽と選択肢は変更時、文字と数値は 600ms の入力停止・フォーカス離脱・Enter で保存する。
- `store.ts` が保存を直列化し、名前空間ごとの revision を送る。競合は再取得して編集中の状態を破棄し、取得に成功した場合だけ「読み直しました」と通知する。外部更新イベントでも再取得する。読み取り専用、取得失敗、保存拒否、通信失敗を画面に表示する。
- 偽データは表示対象 12 名前空間、除外対象 2 名前空間、追加機能 1 名前空間。各名前空間に全種類を含め、`settings-readonly`、`settings-conflict`、`settings-rejected` のシナリオを用意した。

#### 未確認事項を読み取りで確かめた結果

参照元はインストール済み DSH 内の次の安全なソースファイル。DSH 本体は変更・起動していない。

- `dsh-client-ui-settings/lib/client.js`：231–244、275–287 でスキーマは `{ uid, refs }` と確認。子ノードは ID 参照で、object の dict、union/intersect の list、array/dict の inner を持つ。description、min、max、step、default は meta 配下。コールバック文字列は実行せず、参照だけを純粋に展開する。
- `dsh-api-settings-controller/lib/typert.remote-client.d.ts`、`dsh-settings/lib/types/types.d.ts`：describe は RemoteResult に包んだ writable と namespaces を返す。update、replace、mutate は更新後の名前空間を返し、revision は名前空間単位の数値。base と user は省略され得る。更新イベントの引数は名前空間名と revision の 2 つ。
- `dsh-settings/lib/index.js`：update はオブジェクトを再帰マージする。null は削除記号ではない。既定値への復帰は `mutate(ns, [{ op: 'unset', path }], revision)` を使う。値が除去された user 全体から replace を作ると、画面外の値まで失うため使わない。
- `dsh-settings/lib/types/types.d.ts`：value、base、user はホスト側で認証値除去済み。認証用の状態情報は別配列にパスと登録状態だけを載せる。
- `dsh-client-ui-settings-models/lib/client.js`：認証参照は提供元の settingsNs/settingsPath が指す profile.apiKeyEnv を使う。未指定時は提供元 ID から大文字と `_API_KEY` の参照を導出する。ただし参照の未指定だけで「キー不要」とは断定できない。安全な生成型では、登録状況照会は参照配列、登録は参照と文字列、削除は参照を受け取ることまで確認した。状態型の定義元は保護対象のパッケージ名に当たるため読んでいない。
- 指定された既存 UI 4 パッケージでは DSH の版を取る窓口を確認できなかった。存在しないと断定せず、接続先の版は表示しない。

#### 制約によって保留したことと、実装上の判断

- **認証キーの登録状態の表示、入力シート、登録・削除は未実装。完了条件全体は未達。** 必須の認証 API と状態配列の識別子が、今回のユーザー補足でコマンド・パッチへの記載を禁じられた文字列に該当する。文字列の分割や動的なプロパティ探索で迂回せず、その部分を実装しなかった。提供元ページに利用できないことと標準の画面への導線を明記した。対応する偽の認証 API も作っていない。
- 通常の設定はホストが値を除去した応答を前提に扱う。値のない葉は、普通の未設定項目も含め保守的に読み取り専用にする。これにより認証用スロットへ通常の update を送らない。読み取り専用項目の既定値復帰も提供しない。登録済みか未登録かを推測しない。
- meta.role が password の場合は追加の防御として項目モデルへ値を一切渡さない。これは既存 UI の認証状態契約を代替するものではない。偽データの当該例には値自体を生成していない。
- 日本語の title/description を優先し、既知の項目名を日本語にする。英語だけの説明は標準画面での確認案内、未知の項目名は番号にする。未知の名前空間は設計どおり名前空間名を見出しにする。値・モデル名などのデータは翻訳しない。
- 共通 MockKit の emit は payload 1 個なので、偽の更新イベントは名前空間名だけを渡す。本物の 2 引数のイベントにも対応し、第 2 引数がない偽イベントは再取得する。
- 調査担当の型ファイル名一覧に、保護対象名が 1 件混入した。該当ファイルの内容は開かず、その後は一覧取得を停止した。保護対象が含まれないという補足を受けた範囲でも起きたため、以後は確認済みの安全な単一ファイルだけを指定した。保護フックや自動承認による操作拒否は発生していない。
- 実装パッチの形式エラーが 1 回あったが、権限による拒否ではない。同じファイルへの重複したパッチ操作を単一の更新に直して適用した。

#### 検証と引き継ぎ

- 途中確認：スキーマの Node テスト 13 件、偽データの Node テスト 6 件は成功。型検査も成功。最終の 3 コマンドの結果は下に追記する。
- 今回の補足で開発サーバー起動・HTTP 確認が禁止されたため、ブラウザーの画面操作はしていない。DSH も起動していない。
- オーケストレーターの画面確認対象：`?mock#/settings` の 2 区分と詳細 6 ページ、各入力と保存・既定値復帰、外観 3 種、標準画面への切り替え確認をキャンセル、提供元ページの未対応案内。読み取り専用と競合・拒否の 3 シナリオも確認する。キーの入力・登録・削除は未実装なので成功扱いにしない。
- 担当外で必要になったソース変更：なし。残る認証機能の実装には、禁止文字を含む正規 API 識別子の使用についてオーケストレーター側で制約を整理する必要がある。共有ファイルや保護フックは変更していない。

#### 最終検証結果

- `pnpm typecheck`：成功。実物に合わせて base/user を省略可能にした際に偽データのテスト側で型エラーが出たため、偽データに値があることの確認を足してから再実行した。
- `pnpm test`：89 件すべて成功（既存 55 件、今回 34 件）。今回分はスキーマ・差分 14 件、偽データ 6 件、保存制御 14 件。競合後の再取得失敗、同時編集、古い応答、書き込み抑止、機密値を項目モデルへ渡さないことも検証した。React の描画テストは追加していない。
- `pnpm build`：成功。Vite の 500 kB 超の chunk 警告は残る。生成 JavaScript は約 1,049 kB、gzip 約 251 kB。同梱フォントは約 4 MB。
- ブラウザーで操作した画面：なし。今回の指示どおり、開発サーバー起動と HTTP 確認を行わず、上記の画面確認はオーケストレーターへ引き継ぐ。

### 2026-09-25：2 本のレビューに対する修正

前節の認証機能の保留・通常の欠落値を編集不可にする判断は、この節の修正で更新した。ユーザーが承認したパッチ本文だけの例外を使い、認証 API と機密パスの正規識別子を書いた。コマンドの例外は設けず、保護語を含む名前のファイルの作成・読み取り・一覧取得は行っていない。

#### 1. 提供元と API キー

- 提供元一覧、登録済み・未登録・キー不要の行、キー入力シート、入力中だけの表示切り替え、登録、確認後の削除を実装した。設定全体の書き込み可否と、参照ごとの書き込み可否を両方確認する。照会失敗を「未登録」と扱わず、再読み込みを案内する。
- `providers.ts` の状態モデルが持つのは提供元の名前・設定の場所・参照名と登録状態だけ。照会応答からは configured/writable の boolean だけを取り出し、余分なフィールドや保存結果の値を画面へ渡さない。
- 入力値は送信開始時に空にして表示切り替えも戻す。成功時だけでなく失敗時も入力値を復元しない。シートを閉じると下書きを消去し、破棄前の遅い応答が開き直した下書きを変更しない。登録時のサーバーエラー本文には入力値が含まれる可能性があるため、認証操作では固定の日本語メッセージを出す。
- 削除ダイアログを出す前に入力シートを閉じる。土台の OverlayHost が下のシートをアンマウントする契約に合わせ、入力の復元に依存しない。
- 既存 UI に合わせ、llm.listProviders と listConfigurableProviders を結合し、settingsNs/settingsPath が指す apiKeyEnv を参照名として使う。実際に有効な提供元で参照指定がないものは、提供元固有の認証経路を使うものとして「キーは不要」と表示する。単なる名前空間名やローカルらしい ID だけでは判定しない。
- 無効な pi-ai の提供元で参照先が未指定の場合は、既存 UI と同じ規則で参照名を導出し、その名前だけを設定へ保存してから認証 API にキーを送る。参照先を設定できなければキーは送らない。保存直前に再取得し、開いたときから参照先が変わっていれば送信を止める。
- 偽データはディープシークが登録済み、別のクラウド提供元が未登録、ローカルがキー不要。登録と削除では登録状態の boolean だけを持ち、入力値は保存しない。認証だけの読み取り専用と照会失敗のシナリオも追加した。

#### 確認した認証契約と残る確認

- API 調査メモ §6 と、許可された既存 `dsh-client-ui-settings-models/lib/client.js` の 890–1048、1060–1072、1447–1451、1521–1554、2586–2600 行で確認した。describe の結果は参照名をキーにした map、利用する状態は configured と writable。set/unset は RemoteResult の成否だけを使うため、成功時の payload は unknown として保持しない。
- 同ファイルの providerUsable は「有効な提供元で apiKeyEnv がない場合、その画面でキーを要求しない」と明記している。単に参照が未指定の非稼働プロファイルをキー不要とする推測はしていない。
- 認証状態型の定義元にある保護対象ファイルは読んでいない。必要な2つの状態フィールドと呼び出し方は上記の利用側ソースで確認できた。実物の通信と提供元固有の認証は段階3に残る。DSH の版の取得窓口については前節どおり未確認で、非表示を維持する。

#### 2. 再接続と revision

- 公開済み connection.state を購読し、切断・再接続で revision の比較基準を更新する。再接続後の最初の取得では、保存済みの番号より小さな 0 も採用する。
- 接続世代と非同期リクエストの順序を別々に管理する。古い接続の取得・保存応答、拒否通知、送信待ち編集は破棄する。古い通信が完了しなくても新しい接続の保存を開始できる。同じ接続内での古い取得応答の上書き防止は維持した。
- Node で revision 3 を取得し、サーバーを 0 に戻して再接続・再取得したあと、保存2回が成功することを確認する回帰テストを追加した。

#### 3. 通常の未設定項目と機密項目

- 名前空間が返す secrets の path/set を使い、値がない理由を判定する。通常の未設定項目は型に従って編集可能。任意の reasoningEffort を初めて保存する回帰テストを追加した。
- 保護対象の項目モデルには登録状態だけを渡し、値を持たせない。読み取り専用の親オブジェクト・辞書・配列からの表示にも保護パスを適用し、親の JSON 表示や一覧の要約からも値が出ないことを検証した。password role も補助的に保護対象として扱う。

#### 4. 入力を止めない保存

- `input.ts` に React と独立した保存制御を分けた。文字・数値・スイッチ・選択肢は保存中も操作可能で、処理中は別の表示を出す。600ms、欄から離れたとき、Enter による保存を維持した。
- 入力の変更番号を持ち、古い保存応答で新しい下書きを上書きしない。保存中に編集された場合は、応答後に最新の値を続けて保存する。途中の値はまとめ、各保存は直列にする。競合・再接続・画面離脱で無効になった入力は再送しない。
- 遅延した保存中の追加入力、元の値への戻し、拒否、既定値への復帰、無効化後の待機入力を Node で検証した。スマートフォンの実際のキーボードとフォーカスはブラウザー未検証。

#### 5. 03 と共有する偽の既定権限

- この worktree の 03 設計書は土台時点のため、`feat/03-composer` の同設計書の実装メモと composer の api/mock を `git show` で読み取り照合した。ブランチの取り込みはしていない。
- 08 が持つ permission の value/base に `defaultPreset: 'workspace-write'` を追加。スキーマの列挙を `workspace-write`（ワークスペース書込）と `danger-full-access`（フル アクセス）に合わせた。root.dict.defaultPreset から const union を読む03の契約に合わせ、値と候補の整合をテストする。
- 03 や土台のファイルは変更していない。今回の担当外で必要になった変更はなし。

#### 今回の検証

- DSH・開発サーバーは起動せず、HTTP 確認とブラウザー操作もしていない。オーケストレーターへ、API キーの入力表示切り替え・保存後の空欄・削除確認・外観との併用、遅い保存中の連続入力、再接続後の保存、03との既定権限の統合確認を引き継ぐ。
- `?mock&scenario=settings-keys-readonly#/settings/providers` は認証の変更不可、`?mock&scenario=settings-keys-unavailable#/settings/providers` は照会失敗の表示を確認するための追加シナリオ。
- 保護フック・自動承認による拒否操作はなし。全体3コマンドの最終結果は以下に追記する。

#### 修正後の最終結果

- `pnpm typecheck`：成功。
- `pnpm test`：117 件すべて成功。08 の内訳はスキーマ 17 件、保存制御 19 件、連続入力 9 件、提供元・キーと03の権限候補 11 件、既存の設定偽データ 6 件。基盤の既存55件も成功。
- `pnpm build`：成功。JavaScript 約1,061 kB、gzip 約256 kB。同梱フォント約4 MB。500 kB 超の chunk 警告は残る。
- 今回の5指摘は担当範囲で修正済み。ブラウザーで操作した画面はなし。認証機能は今回追加した Node テストと偽データまでを確認済みで、実際の画面操作・スマートフォンのフォーカス維持・本物のDSHへの接続は未確認。

### 2026-09-26：Claude（Opus 5.5）の再レビュー指摘 1〜5

- 作業ブランチは、ユーザーが main から作成した `feat/08-settings-2`。開始時の作業ツリーは変更なし。main の変更、merge、rebase はしていない。変更先は08の設定ソース・テストと、この実装メモのみ。

#### 修正内容と判断

1. **同じ接続中の revision の巻き戻り**：取得結果の新旧はリクエストの順序と接続世代で判定する。名前空間の revision が小さいという理由では describe の結果を捨てない。更新通知も、現在と同じ番号だけを無視する。Node で `3 → サーバー側だけ0 → 保存競合 → 再取得で0を採用 → 保存2回成功`、小さい番号の通知、古い高い番号の遅延応答を確認した。
2. **キー保存中の再読み込み競合**：保存・削除のための再取得と通常の更新通知による再取得を分ける。通常の再取得は操作終了まで待ち、保存前の確認中に通知があれば再確認してから送信する。入力したキーは従来どおり送信開始時に欄から消し、成功・失敗にかかわらず再表示しない。
3. **非稼働の提供元の登録状況**：参照名がない非稼働の提供元は、pi-ai 以外でも ID から参照名を導出して照会する。登録済み・未登録を表示できた場合は、再読み込みのエラーを出さない。参照先を書き込む契約を確認できたのは pi-ai のため、ほかの提供元で参照未指定の場合は状態表示のみ・変更不可とする。稼働中で参照指定がない提供元の「キーは不要」の扱いは維持する。
4. **任意の文字項目を空にする操作**：空文字と空白のみの文字入力は `undefined` に正規化し、既存の `mutate` の `unset` で上書きを削除する。必須文字の空欄、数値の空欄は従来どおり検査エラー。空でない文字列の前後の空白は保持する。reasoningEffort を保存してから空にし、対象だけが user/value から消えることを偽データで確認した。
5. **未設定の選択欄**：候補の選択位置と補足表示を純粋関数に分け、値がない場合は「未設定」、値があって候補外なら「現在の値は選択肢にありません」とする。候補に含まれる false・0・空文字・null は選択済みとして扱う。`settings-unset` シナリオでは既定モデルの「動作モード」を未設定から確認できる。

#### 既存プラグインで確認したこと・残る未確認事項

- `npm root -g` の結果は既存メモの場所と一致。DSH 内の安全な名前の既知ファイルだけを読み取った。禁止語を含む名前のファイルは作成・読取・列挙していない。
- `dsh-settings/lib/index.js:281–297`：名前空間を登録するたびに revision を0に設定し、登録解除はプラグインの寿命に連動する。`dsh-client-ui-settings/lib/client.js:1046–1062` と1098付近では、保存失敗後に再取得し、取得した revision を採用する。実環境で同じ接続中の再登録が起きる頻度は未確認だが、番号の単調増加を前提にしない実装へ変更した。
- `dsh-client-ui-settings-models/lib/client.js:1023`、1447–1451：参照名がない場合の導出と照会を確認。1521–1554では、pi-ai の参照先設定をキー登録前に保存する。他の提供元で同じ書き込みが有効かは未確認のため、状態照会に限定した。
- 同ファイル1496–1499は空白だけの文字列も未指定として扱う。通常の任意文字項目にもこの扱いを適用し、設定の既存 unset API を使う。
- スキーマの形、認証状態の configured/writable と呼び出し方は前節の確認結果を利用する。認証型の定義元の保護対象ファイルは今回も開かず、未確認の成功 payload に依存しない。DSH の版の取得窓口、実物への通信、スマートフォンのフォーカス・キーボードは未確認のまま。

#### 検証と引き継ぎ

- DSH・開発サーバーの起動、HTTP 確認、ブラウザー操作はしていない。ブラウザーで操作した画面はなし。
- オーケストレーターの画面確認対象：`?mock#/settings/models` の「考える深さ」を入力後に空欄へ戻す操作、`?mock&scenario=settings-unset#/settings/models` の「動作モード」の未設定表示・選択・既定値への復帰、`?mock#/settings/providers` のキー登録・削除と入力欄の消去。通知と保存の重なり、同じ接続中の revision 巻き戻りは Node の遅延応答・偽 API で検証する。
- 拒否された操作：なし。担当外で必要になった変更：なし。
- `pnpm typecheck`：成功。初回は追加テストの配列要素の存在確認不足で型エラーになったため、明示的な存在確認を足して再実行した。
- `pnpm test`：528件すべて成功（08は73件、今回11件追加）。キー操作は3種類の更新通知と保存・削除の組み合わせ、確認中の参照変更、旧接続の遅い応答と新接続の操作の重なりを検証した。型エラー修正後にも全体を再実行して成功。
- `pnpm build`：成功。生成JavaScriptは約1,579 kB、gzip約397 kB。従来と同じ500 kB超のchunk警告あり。アプリのソースはこのビルド後に変更していない。
- 指摘1〜5は担当範囲内で修正済み。未検証の画面操作・実物接続は上記のとおりオーケストレーターへ引き継ぐ。

### 2026-09-26：統合後の画面仕様・横断レビュー対応

- 作業ブランチは最新 main `dec19bd` から作られた `feat/08-settings-spec`。前回の利用上限による中断後、残った未コミット差分を確認して作業を再開した。main の変更、merge、rebase は行っていない。

#### 画面仕様とユーザー決定を反映したこと

- 設定トップの2行目は、先頭の項目を機械的に選ぶのをやめた。モデル名と考える深さ、権限の既定プリセット、エージェントの既定プリセットと並列実行数、Web検索のモデルと上限回数を、確認済みの項目パスから選ぶ。提供元は登録済み・未登録・キー不要・未確認の件数を表示し、照会失敗を未登録に見せない。要約は機密項目を除いたスキーマ項目だけを入力にする。
- 上記の項目パスは、インストール済みの安全な名前の既知ファイル `dsh-agent-default-model/lib/index.js`、`dsh-agent-presets/lib/index.js`、`dsh-agent-loop/lib/index.js`、`dsh-web-search-deepseek/lib/index.js` で確認した。偽データにも対応する値とスキーマを足し、モデルは03の偽カタログの `deepseek-v4` に合わせた。シェルの項目パスは確認していないため、Web検索の値を主な値として出す。
- APIキーの入力シートは見出し「API キー」、説明「保存すると、あとから表示できません」、左の outlined「登録を消す」と右の filled「保存」を同じ幅の2列にした。未登録のとき削除は無効。削除確認は既存のオーバーレイの重なりを使い、キャンセルしたら空欄の入力シートへ戻る。登録削除に成功したときは両方閉じる。確認に入ると未送信の値も破棄し、保存済みの値を再表示しない。
- 外観は左にラジオボタンがある3行にし、「閉じる」ボタンを外した。アイコンは外観・モデル・エージェント・Web検索とシェル・キー不要の提供元を指定の名前にした。設定固有CSSの余白と角丸は、公開済み `--app-space` と `--app-radius` から計算する。土台の新トークンは使っていない。
- 上書きした配列・辞書・未知型・入れ子のまとまりにも「既定値に戻す」を出し、`mutate` の `unset` だけを許可する。通常の複合値編集は許可しない。保護された子や変更不可の子をまとめて消し得る場合は、理由を添えて復帰ボタンを無効にする。グループ復帰後は古い子の入力世代を無効化し、待機していた保存による再上書きを防ぐ。未翻訳項目の扱いはユーザー決定どおり変更していない。

#### 03 が使う公開入口：新しい会話の既定権限

- 08 の `web/src/features/settings/mock.ts` が唯一の偽 `settings` 名前空間を `MockKit.addRemote('settings', remote)` で登録する。`await ctx.remote.settings.describe()` の成功結果にある `namespaces.find(row => row.ns === 'permission').value.defaultPreset` が**現在の値**。初期値は `workspace-write` で、設定画面からの `update('permission', { defaultPreset: ... }, revision)` と `mutate` により更新・復帰する。同じ `permission` 行のシリアライズされたスキーマは root の `dict.defaultPreset` から定数の union に進み、`workspace-write` と `danger-full-access` の2候補を返す。
- 03 の既存 `composerApi(ctx.remote).defaultPermissions()` はこの describe を毎回読み、値と候補を検査する公開の読取入口。Nodeで、08の値を変更・復帰したあとにこの入口が新しい値を返すことを確認した。以前の取得結果はコピーのため、会話を作る際は最新値を改めて読む必要がある。03 の固定の初期権限をこの現在値へ合わせる変更は03担当側で並行している。08は03のファイルを変更していない。

#### 確認と引き継ぎ

- Nodeで要約の主要値と保存後の更新、登録状況の成功・失敗、複合値の復帰と競合・保護、削除確認前後の入力の破棄、03の読取入口を確認した。React描画・削除確認のキャンセル/Escape/背景操作・ラジオのタッチ操作はブラウザー未確認。
- DSH・開発サーバーは起動せず、HTTP確認もしていない。ブラウザーで操作した `?mock` 画面はなし。オーケストレーターは `?mock#/settings` の5行の要約とアイコン、`?mock#/settings/providers` のキー入力・削除確認キャンセル、`?mock#/settings/models` と `?mock#/settings/agent` の複合値復帰、外観3行を確認する。
- **担当外で必要になった変更**：03が会話作成時に08の現在の `permission.value.defaultPreset` を読む変更。03側で並行作業中。今回の08実装で新しい00の公開入口や共有ファイルの変更は必要なかった。
- 拒否された操作・禁じられた操作の実行：なし。3コマンドの結果は下に追記する。
- `pnpm typecheck`：成功。
- `pnpm test`：545件すべて成功。今回の08では、主要値の要約と03の読取入口、複合値の復帰、キー下書きの破棄を追加して確認した。
- `pnpm build`：成功。JavaScript約1,582 kB（gzip約397 kB）。500 kB超の既存の容量警告は残る。

### 2026-09-27：モデル選択画面の実装経緯

- 最初の検索は、引用符のないワイルドカードを含めたため拒否された。オーケストレーターの指示に従い、フォルダを指定する正規の書式で再開した。
- 続く `mock.ts` の編集パッチは保護フックに拒否された。オーケストレーターがユーザーの了承を得て偽データと `mutate` の偽実装を編集した。Codex はこのファイルを読んで確認したが、再編集はしていない。
- DSH の `update` はマージ方式なので、推論の強さを省いても古い上書きが残る。既定モデルの提供元・モデル・推論の強さは、`mutate` の `set` と `unset` をまとめて一度で保存する。サブエージェントの許可リストは、直列化された保存処理の中で直近の値を読んで追加・削除する。
- `#/settings/models` の二つの名前空間だけを専用部品にし、ほかのページは汎用スキーマ表示を維持した。対応モデルだけに推論の強さを表示し、一覧外の保存値も保持する。保存・復帰・読取専用・一覧取得失敗の表示を追加した。設定トップの要約は従来のモデル ID のまま。
- `pnpm typecheck` 成功、`pnpm test` は710件成功、`pnpm build` 成功、Playwright 全件は77件成功。新規のブラウザー試験3件を `--repeat-each 3` で計9件成功。幅390pxで横幅も確認した。
- DSH 本体は起動していない。実物への保存と、一部の提供元だけモデル一覧の取得に失敗する場合の画面操作は段階3で確認する。ビルド時には既存の500 kB超のチャンク警告が残る。

### 2026-09-27：モデル選択画面のレビュー対応

- DSH 0.1.5-rc.1 はサブエージェントの許可リストが空のまま有効化する変更を拒否する。無効中もモデルを選べるようにし、先に1件以上保存してから有効化する。有効中は最後の1件を外せない。保存待ちの操作も直列キュー内で最新値を再確認する。
- 推論の強さに選べる「既定（モデルに任せる）」を置き、選択時は `reasoningEffort` の `unset` を保存する。候補外の保存値は一覧外と表示して保持する。モデル一覧の再読込失敗中は、残っている一覧と保存値を表示しながら編集操作を無効にする。推論欄がない場合の区切り線と余白は `hidden` の表示規則で消した。
- `mock.ts` に本物と同じ空リストの検査を追加したのは、オーケストレーターである。ユーザーの了承を得て編集され、Codex はこのファイルを編集していない。単体試験と幅375pxのブラウザー試験で、有効化の順序、最後の1件、推論の既定への復帰、欄を隠す表示を確認した。
- `pnpm typecheck` 成功、`pnpm test` 712件成功、`pnpm build` 成功、Playwright 全件77件成功。変更したブラウザー試験3件は `--repeat-each 3` で計9件成功。DSH 本体は起動しておらず、実物への保存とモデル一覧の再読込失敗をブラウザーで起こす操作は未確認。

### 2026-10-07：Issue #45、推論の指定なしと下位設定の継承を区別

- 非対応モデルの選択と「既定（モデルに任せる）」では、`reasoningEffort` に固定の loader 設定式 `{ __jsExpr: 'void 0' }` を `set` する。`unset` は下位設定の推論値を復活させるため、この操作には使用しない。「既定値に戻す」の `modelResetOperations` は従来の `unset` を維持する。
- DSH 0.2.0-rc.2 の公開配布コードで検証した。`dsh-settings/lib/index.js` の `SettingsForms.mutate` は `unset` を下位値の `set` へ変換する。`cordis-plugin-loader/lib/index.js` の `interpolate` は固定式を `undefined` に解決し、`dsh-agent-default-model` の Config と currentSelection を経て推論指定が省略される。`null` は推論値として残るので代替にならない。
- `tests/08-reasoning-inheritance.test.ts` に下位 high を持つ設定からの保存・再読込・カタログ・リセットの回帰を追加。配布コードが配置されている環境では、実際の mutate、設定解決、`LlmRuntime.resolveCallWithInfo` を呼ぶ契約試験も実行する。旧 unset が非対応モデルで拒否されること、修正後が成功すること、対応モデルの既定 low を妨げないことを確認した。配布物がない環境ではこの1件だけ明示的に skip する。
- mock はこの固定式だけを解釈し、任意の JavaScript は評価しない。`settings-inherited-reasoning` シナリオを追加し、ブラウザーで非対応モデル・指定なしを保存して開き直せること、リセットで high を継承することを検証した。
- `pnpm typecheck`、`pnpm test`（1096件、skipなし）、`pnpm build`、`git diff --check` 成功。Chromium 390×844 のモデル設定既存3件と新規回帰1件が成功。既存の chunk サイズ警告あり。DSH 本体の起動や実設定の変更は行っていない。
- 保護フックでの公開コード検索の拒否後、利用者から公開コード限定の再試行許可を得た。シェルのワイルドカード検索も実行審査で拒否されたため、許可された公開ファイルの明示的な読み取りだけで確認した。

### 2026-10-07：PR #51 差し戻し後の実DSH確認

- 差し戻しは、実DSHの設定保存経路で「指定なし」「既定値に戻す」「非対応モデルへの変更」を確認し、メモを追記するという内容。既存の検証は公開配布コードとmockの範囲であり、この3経路を実DSHで確認したとは扱わない。
- 初回の追加パッチは保護フックに拒否されたため停止し、利用者から隔離DSH起動・テスト編集の再試行を許可されたあとに再開した。CIは分離して扱う。既存のユーザー設定は対象にせず、新規の隔離ホームと127.0.0.1の偽LLMだけを使用した。
- `e2e-dsh/reasoning-inheritance.spec.ts` を追加し、未変更の実DSH 0.2.0-rc.2へビルドしたプラグインを導入。Chromium 390×844のM3Eで3経路を操作し、それぞれ同じ検証ホームのHostを再起動して再確認した。公開RPCの取得値・選択カタログ・画面写真をテストに添付し、console/pageエラーはいずれも0件だった。

| 経路 | 実DSHで確認した結果（再起動後） |
| --- | --- |
| 指定なし | 下位bundleの `base.reasoningEffort` は `high` のまま。保存した `user` は固定式 `void 0`、解決後の `value` とモデルカタログの既定選択から推論指定が消えた。画面も「既定（モデルに任せる）」を保持。 |
| 既定値に戻す | `user` が空になり、`value` と既定選択は下位の `high` を継承。画面も `high` に戻った。 |
| 非対応モデルへ変更 | 推論非対応モデル `plain` に切り替えて保存。下位 `high` は保持しつつ、解決後の値と既定選択から推論指定が消え、推論欄は非表示。再起動後の新規会話から実アダプター経由でローカルLLMへ送信し、返答を受信した。 |

- 下位設定は追加の検証用bundleで定義した。ホーム直下のpatchは編集対象より優先されるoverlayであり、継承元ではないため使用しない。この違いを確認する初期テストの失敗も保存済み。モデルは実カタログへ登録する検証専用の2種類を使う。
- 実アダプターが付ける `/v1/messages?beta=true` を偽LLMが誤って404にしていたため、テスト用サーバーの判定をpathnameへ修正した。要求パスも添付する。製品の保存ロジックの追加変更は不要だった。
- 実画面の証跡を目視すると、指定なしで空のselect値と独自の表示文言を併用した際、ラベル「推論の強さ」が選択値と重なっていた。製品の `ModelsPanel.tsx` で推論欄の `floatLabel` を常時浮動にし、フォーカスを外した後も両者の矩形が重ならないことを実DSH試験で検査した。再起動を含む3経路を再実行して成功し、修正後の画像も目視確認した。修正前後は `docs/review/pr51-reasoning-before.png` と `pr51-reasoning-after.png` に保存した。
- 再現コマンドは `pnpm exec playwright test -c e2e-dsh/playwright.config.ts reasoning-inheritance.spec.ts`（配置済み配布物を使う場合は `M3E_DSH_DIR` を指定）。3件すべて成功。`pnpm typecheck`、単体1096件、配布build/check:pack、新規specの個別TypeScript検査も成功。既存chunk警告のみ。
- 対象は隔離した実プロセス・実設定ファイル・実RPC・実ブラウザーであり、本番や利用者の日常設定、本物のLLM、iPhone/Safariの検証ではない。最終証跡は当ブランチの `tmp/dsh-integration/report.json`（3件成功、画面写真・設定スナップショットを含む）。実行時刻で変わる出力先はJSON内の設定を正とする。

### 2026-10-08：Issue #27、一覧の API キー入力の寿命

- `ProvidersPanel.tsx` の一覧用 `KeyEntry` を非制御の入力へ変更した。キーの文字列を React の状態や `value` 属性へ渡さず、入力の有無・表示状態・処理状態だけを保持する。送信開始、切断、シートの閉じ始め、破棄で入力を空にし、伏せ字へ戻す。削除確認に覆われた場合も、戻ると空欄になる。
- 保存ごとにシートの世代、接続、overlay の所属、開閉状態を調べる `canSend` を渡す。既存の `ProviderStore.save` が行う照会後と参照先の設定後の 2 回の確認を使い、閉じたあとから未送信のキーを送らない。store の epoch・revision・参照名の検査と、カスタムプロバイダー編集フォームは変更していない。すでに送信した RPC は取り消さず、閉じたシートの再表示や成功通知を抑える。
- 利用者の不具合修正・試験指示に従い、担当表外の `e2e/settings-key-lifetime.spec.ts` に回帰試験を追加した。合成したダミー文字列だけを使い、照会／参照先設定の待機中の閉鎖、切断と再接続、HTML 属性、正常保存と連打、同じタスクでの閉鎖と応答、送信済み応答、削除確認からの復帰の 9 件を検証した。既存試験の期待値は変えていない。
- 修正前は、照会中の閉鎖後もキー送信が 1 回、切断後も入力が残留、HTML の `value` 属性にダミー文字列が複製されることを確認した（`tmp/issue27-before.log`）。参照先設定待機の fixture は、未稼働・参照名なしの標準提供元に修正し、本体未変更で閉鎖後のキー送信 1 回を確認した（`tmp/issue27-before-attach-valid.log`）。修正後の 9 件はすべて成功（`tmp/issue27-browser-final.log`）。関連する既存の提供元試験 16 件も成功した。追加試験の削除確認は、開いた直後の Escape の競合を避けて登録済み提供元を直接開く fixture に直し、最終 9 件で再確認した。
- Node 22.23.3 で `pnpm typecheck`、`pnpm test`（1,107 件成功、失敗・skip 0）、`pnpm build`、`pnpm run check:pack`（19 ファイル）、`git diff --check` が成功。初回の単体実行は公開 DSH 配布コードを参照する 2 件が skip したため、既存の公開パッケージ fixture の node_modules だけを接続して全件を再実行した。DSH プロセスは起動していない。既存の 500 kB 超 chunk 警告は残る。
- 専用 worktree `fix/issue-27-key-sheet-lifetime` と localhost:5295 の偽データ画面を使用した。worktree 作成の sandbox 内操作は Git メタデータの書込み権限で停止し、正式な昇格の承認後に作成した。ブラウザ試験も承認された昇格で実行した。pnpm 11 の自動 install は TTY 不在で停止したため、既存依存を使用し `pnpm_config_verify_deps_before_run=false` を指定した。依存・ロックファイル、PR #54、認証情報は変更せず、本物のキー・外部 API は使用していない。コミット・公開は指示役に引き継ぐ。iOS Safari の実機動作は未確認。
- 親の独立レビューで新規 Chromium 9 件を再実行し成功。隔離公開 DSH 0.2.0-rc.2 の合成キー登録・削除試験 1 件も成功。実キーや利用者の設定は使用していない。


### 2026-10-08：Issue #46 共通設定の未保存入力とエラー

- 指定された選択は `gpt-6-astra`／Codex。今回の情報にルーティング矛盾は見つからなかったが、実モデル ID の独立照会はしていない。`cd99f273f9582729475272e48722d7ec850d6857` から専用 worktree と `fix/issue-46-settings-drafts` を作成した。PR #54 とカスタム提供元のコードには触れていない。
- 共通の項目の下書きは settings store が名前空間／path ごとに所有し、入力欄は購読する。文字・数値の 600ms debounce も入力 controller が持つ。namespace generation を React key にして全項目を作り直す処理を共通設定から除いた。
- グループの復帰は対象 subtree の書き込み世代だけを進め、子の古い下書き・待機保存を破棄する。兄弟項目の下書きと待機保存は残す。モデル専用画面の namespace-wide reset、revision による直列化、接続 epoch の拒否処理は維持した。
- 独立レビューで、復帰開始後の子項目の追加入力が成功応答で消えるケースが見つかった。この入力を受け付けた後に消すことがないように、復帰を依頼した時点から対象 subtree だけ入力を無効にする。UI に加えて controller の変更・保存入口でも同じ状態を確かめる。状態は store が所有し、切断後に古い RPC が停止しても新しい接続の編集を妨げない。
- 切断時は debounce と古い保存 controller の継続を止め、入力と中断案内を残す。古い Promise が永久に解決しなくても、新しい接続では明示した再試行ができる。再接続の読み直しで値が既に保存済みなら中断状態を解消し、差がある場合は自動再送せず、保存済みの値と「もう一度保存する」を表示する。外部 revision の変更でも未保存の入力は保持して停止し、明示した再試行で最新 revision を使う。
- 保存のエラーは入力変更で消し、遅れて返る拒否は入力の世代・revision が同じ場合だけ表示する。外部 revision の読み直しでは古いエラーを消す。読み取り専用化・削除された項目は編集可能な下書きを残さない。
- 修正前の本体で、兄弟の待機保存が group reset に巻き込まれるケースと外部 revision 更新後の stale error を追加試験で再現した（`tmp/issue46-before.log`、2 件とも失敗）。既存の group reset 試験は namespace generation が進むという期待だけを対象 subtree の無効化へ変更し、子の待機保存の拒否と次の新規編集の成功は維持した。
- すべて通常の合成設定による検証。秘密ファイル、認証情報、実 DSH、外部 LLM API は使っていない。ブラウザは tmp 配下の専用設定とポート 5293 の偽データだけを使用。iOS 実機は未確認。この段階でコミット・公開はしていない。
- 最終確認：`pnpm typecheck` 成功、`pnpm test` は 1,121 件成功（失敗・skip とも 0）、`pnpm build` 成功、`pnpm run check:pack` 成功（19 ファイル）。npm のキャッシュは作業場所内の `tmp/npm-cache` を指定した。既存の bundle サイズ警告は残る。
- Chromium の関連 e2e は 10 件成功（追加の共通設定 5 件、放送 1 件、モデル設定 3 件、推論の継承 1 件）。途中の 1 失敗はテスト用遅延条件で未指定値同士を比較して nested update まで保留したためで、遅延指定の有無を判定するように試験を修正して解消した。独立レビューは修正後に残る指摘なし、関連単体 53 件を独立実行して成功。再現・制約・ログ一覧は `tmp/issue46-evidence.md` に記録した。
- 親の確認で、隔離公開 DSH 0.2.0-rc.2＋localhost 偽 LLM の設定一覧・保存再読込、および 35 項目と辞書キー 2 項目の受理・拒否の 2 試験が成功。利用者の設定や実キーは使用していない。
- 2026-10-11（統合時）：保存の競合（`settings/conflict`）でも入力を残し、「もう一度保存する」を示すことを利用者と確認した。以前の動作（読み直した値で入力を置き換える）を期待していた既存の e2e `08d` を、新しい動作（案内の表示、入力の保持、保存し直し、別画面から戻っても保存済み）を確かめる内容に書き換えた。統合時の e2e 全件 271 件と単体 1,185 件（Asia/Tokyo）が成功した。


### 2026-10-08：Issue #33、不正データと例外の境界

- スキーマの同一参照を復号キャッシュで共有し、復号・保護対象の探索・表示値の探索・項目数に上限を設けた。上限を超える定義は値を含まない読取専用の案内1件にする。通常の共有参照は各パスに表示でき、password の伏字も維持する。
- 質問の初期 projection と inbox を配列・項目単位で検査する。不正項目を除外し、有効な質問を維持する。初期購読で例外が起きた場合は登録済みハンドラーと購読を解除し、画面初期化の例外も既存の起動失敗表示へ渡す。
- trace は null の添付を除外する。tool-output の本文探索と JSON 整形には深さ・処理量の上限を設け、深い値や循環参照でも通常の行と詳細表示を維持する。
- 設定の再読込は接続ごとに同時1件とし、処理中の通知は終了後の再取得へまとめる。待機する呼出元は最後の取得まで同じ Promise を待つ。再接続・保存後の古い応答の無効化は維持する。`settings/rejected` はコードに対応する固定の日本語案内を表示し、サーバーの診断文は表示しない。
- 修正前に単体回帰7件がすべて失敗することを確認した。追加した正常データの維持確認を含め、単体1116件（失敗・skip とも0）、型検査、build、配布検査19ファイルが成功。新規ブラウザー6件と既存の設定通知・時間指定質問6件が成功した。隔離した実 DSH 0.2.0-rc.2 でも既存 S5 のシェル設定保存・再読込1件が成功した。本番設定や外部 LLM は使用していない。既存のチャンク容量警告は残る。
- 回帰は `tests/08-malformed-data.test.ts` と `e2e/malformed-data.spec.ts`、取得の直列化と最新結果の確認は `tests/08-store.test.ts`。作業証跡は `tmp/issue33-before.log`、`tmp/issue33-unit.log`、`tmp/issue33-browser-verified.log`、`tmp/issue33-real-dsh.log` に保存した。
- 独立レビューで、循環打切りを含む復号結果のキャッシュが別パスの password マスクを失わせる退行と、JSON文字列を再帰的に解釈する表示差分を検出した。各回帰を修正前に失敗確認し、循環打切りを含む部分木はキャッシュせず、JSONの解釈は一度だけにした。通常の循環スキーマ内の兄弟項目を維持し、再検証の単体1118件は失敗・skip とも0。証跡は `tmp/issue33-review-before.log` と `tmp/issue33-review-unit.log`。
- 2026-10-11（統合時）：保存拒否の表示は、利用者と確認して両立させた。理由がひらがな・カタカナ・漢字と日本語の句読点だけで 200 文字以内なら、そのまま表示する（管理者の設定などの理由を残す）。英数字（全角を含む）、パス、その他の記号を含むものは、固定の「この値は設定できません。入力内容を確認してください。」にする（入力値や内部パスを表示しない）。判定は `displayableRejection`（`store.ts`）。境界の単体試験を追加し、既存の e2e 08e・`settings-models`・`settings-drafts` の管理者の理由と、この PR の漏洩防止の試験がどちらも成り立つ。

### 2026-10-15：Issue #80 と #77 の 73-4・73-5、保存と再読込の重なり

- **#80**：保存の成功で進行中の `describe()` を無効にするとき、再読込の実行中なら追い読みを予約する（`reloadAgain`）。無効にした応答にはほかの名前空間の更新が含まれ得るが、その通知は消費済みで、同じ値の保存では新しい通知も出ないため。保存した名前空間を古い応答から守る仕組み（`sequence`）はそのまま。名前空間ごとの保存世代の案は、古い応答の一部だけを採用する分岐が増えるため採らなかった。追い読みは保存の応答の後に始まるので、保存結果を含む値を読む。
- **73-4**：1 回の再読込が合流で続ける読込は 4 回まで（`reloadReadLimit`）。最後の読込中に来た呼出しと通知は、その読込を捨てずに完了させ、終了後に新しい再読込を 1 回だけ始めてそこへまとめる（末尾の 1 回）。待つ呼出し元は必ず解決し、最後の通知も読み直す。通知が続く間は背後で読込が 1 件ずつ続くが、同時に走るのは常に 1 件。保存の成功による追い読みは上限に数えない（保存は利用者の操作ごとで有限なため）。
- **73-5**：`reload()` の JSDoc に、合流の動きと戻り値（待った再読込の最後の読込を適用できたか。捨てた途中の読込は数えない。失敗・未接続・接続の切替で `false`）を書いた。
- 回帰は `tests/08-store.test.ts` の末尾 4 件（同値の保存、保存通知が応答の後に届く場合、保存を待つ再読込の戻り値、通知が続く場合の読込回数）。修正前の本体で 4 件とも失敗することを確かめた（`tmp/issue80-before.log`）。末尾の 1 回をなくす変異でも回数の試験が失敗する。
- 既存の「保存前に開始した古い describe 応答で新しい保存結果を上書きしない」は、古い応答の後に追い読みするようになったため、`reload()` の期待を `false` から `true` に変え、古い応答の値（revision 0）が一度も公開されないことを確かめる形にした。偽 API が 2 回目以降も古い応答を返し続けていたので、2 回目からは現在の値を返すようにした。
- 実 DSH でこの重なりを起こす確認はしていない（偽 API の単体試験と `?mock` の e2e のみ）。
- 検証：`pnpm typecheck`、e2e の型検査、`pnpm test`（1,206 件中 1,204 件成功、失敗 0、skip 2 件は公開 DSH 配布物が未配置のための既存の skip）、`pnpm build`、`pnpm check:pack`（19 ファイル。npm のキャッシュは `tmp/npm-cache` を指定）。`?mock` の関係する e2e 20 件（settings-broadcast・settings-drafts・settings-models・malformed-data の全件、mock の 08a/08b、edge-cases の 08c〜08e）が成功。

### 2026-10-15：Issue #16 の残りの洗い出しと、フォームのキー欄の非制御化

- main `a3465a5` で Issue #16 の要件を 1 件ずつ照合した。PR #23（`71dd560`）で入口・共通フォーム・検証・path operation の差分保存・revision の競合・部分成功・キーの別保存・終了経路は実装済みで、その後の main の変更（#65、#66、#72、#73）を取り込んだ状態でも、既存の偽データ e2e 15 件は成功した。DSH の根拠は、上の節と同じく 0.2.0-rc.2 の `dsh-llm-pi-ai`（`providers` のスキーマ、`api` の const union、`apiKeyEnv` の `credential-ref`）を読んで確かめた。
- 未対応で見つかったのは 1 点。フォームの「API キー（任意）」は React の制御された入力だったため、入力中の平文が DOM の `value` 属性（HTML）に複製されていた（偽データで合成値を入れ、`getAttribute('value')` と `html` の innerHTML に出ることを確認）。Issue #27 で一覧の `KeyEntry` だけを非制御にした際、このフォームは対象外だった。Issue #16 の「キーを残さない」「既存 M3E の方針に合わせる」に当たるため直した。
- `CustomProviderSheet.tsx` に `KeyField` を設け、キー欄を非制御の入力にした。値は入力の value プロパティと、これまでどおり `createKeyDraft` の下書きだけに持つ。下書きが変わったとき（送信開始、切断、読み直し、外部変更、キャンセルでの消去）にプロパティを書き戻し、シートが overlay から外れたときと破棄のときにも空にする。下書き・保存・検証の store（`custom-provider-store.ts`、`providers.ts`）は変更していない。
- 回帰試験 `I16 UI key markup`（`e2e/settings-custom-provider.spec.ts`）：追加フォームの入力・表示切替、部分成功のあとの再入力、編集フォームの入力で、`value` 属性が無く HTML に合成値が出ないこと、送信とキャンセルのあとにも残らないことを確かめる。修正前の本体で失敗することを確認した。下書きの書き戻しを外す変異では、この試験と既存の 5 件（refused、partial、late、saving M39、late registration）が入力の残留で失敗した。シートが外れたときの消去と、store が入力を受け付けなかったときの書き戻しは防御で、個別の試験は無い。
- 今回変えなかったこと：Host の拒否は ui-spec の表どおり固定の「この変更は保存できませんでした。入力内容を確認してください。」のまま（#73 の `displayableRejection` を使う共通設定とは揃えていない。揃えるかは利用者の判断）。モデルの詳細項目（表示名、コンテキスト長、最大出力トークン数、入力種別）は 0.2.0-rc.2 のスキーマにある前提で常に出し、スキーマから有無を判定していない。
- 未確認：iOS 実機でキーボードを出したときの操作（Issue #26）、Host 再起動をまたぐ保存内容の確認、本物の提供元への接続。実 DSH（`e2e-dsh`）は今回起動していない。

### 2026-10-15：Issue #77（73-1・73-2）、スキーマの上限で名前空間ごと消さない

- **73-1 段階的な縮退**（`schema.ts`）。`decodeSchema` は上限（ノード数・作業量・深さ）を超えたノードと循環で打ち切ったノードだけを `{ truncated: true }` にし、残りの定義は復号する。`schemaFields` は最上位の項目を表示順に処理し、次の項目で項目数（512）や保護の検査量の上限を超えたら、そこから後ろを「表示していない項目」の案内 1 件（「先頭の N 項目だけを表示しています。残りの項目は標準の画面で確認してください。」）に置き換える。深さの超過・循環・ノード数の超過で定義を読めないノードは、その項目だけを値なしの読み取り専用（「設定の定義を読み切れないため、値を表示しません。」）にする。値が大きすぎる読み取り専用の項目もその項目だけを省略し、スカラー値の項目は検査量を使わないので後ろの通常の項目は残る。省略した項目には値・編集・既定値への復帰を出さない（`SchemaFields.tsx` の `OmittedField`）。
- 安全側の判断：打ち切ったノード（`truncated`）は password を含むかもしれないので、そのパス以下と、それを含む読み取り専用の親の値を出さない。循環の打切りも同じ扱いにした。以前の `{}` は保護の探索を素通りさせ、再帰スキーマの 2 段目の password が読み取り専用の配列の JSON に出ていた（`tests/08-schema-limits.test.ts` の循環の試験。修正前に失敗を確認）。これに合わせ `tests/08-settings.test.ts` の循環の期待を `{}` から `{ truncated: true }`・値なしに変えた。経路依存の打切り（深さ・循環）を含む結果をキャッシュしない規則と、#73 の password の伏字の試験は維持した。
- 保護の検査は最上位のキーごとにまとめる（交差の複数のメンバーが同じキーを宣言しても、全部を調べてからそのキーを表示する）。検査を終えたキーだけを表示し、ルートの交差に含まれるオブジェクト以外のメンバー（値全体を表示する）は全キーの検査が済んだときだけ表示する。password も打切りも含まない部分木は検査を省く（識別子でメモ化）。交差の同じメンバー（同一の復号ノード）は 1 回だけ数え、指数的な共有でも同じ項目を重複させない。`field-access.ts` の既定値に戻す判定は全スキーマを上限なしで辿っていたため、#73 の指数的な共有スキーマで 268 秒止まることを確かめた。4096 回で打ち切って `resetBlocked` にし、`truncated` も保護対象と同じく復帰を止める。`custom-provider.ts` の書込み可否も `truncated` を変更不可に数える。
- **73-2**：`SchemaNode` と `SchemaMeta` を `readonly`（`dict`・`list` も読み取り専用）で公開し、本番ビルド以外（`import.meta.env.PROD !== true`、Node の単体試験を含む）では復号したノード・`dict`・`list`・`meta` を `Object.freeze` する。`meta` は複製してから凍結し、呼び出し側の文書は凍結・変更しない。
- **上限の根拠（計測）**：DSH 0.2.0-rc.2 同梱のプラグインのスキーマから計測した。指定された `tmp/dsh-integration/dsh-0.2.0-rc.2/` は worktree にも本体 checkout にもなかったため、同じ版の `npm root -g` 配下 `@deepseek-ai/dsh/node_modules/@deepseek-ai/`（`dsh/package.json` の version が 0.2.0-rc.2）を読み取りだけで使った。方法：各パッケージの `lib/index.js` を Node で import して `Config` を取り出し、`dsh-settings/lib/index.js` の `volatileForm` と同じ手順で設定画面用のフォームにして `toJSON()` した `{ uid, refs }` を、この実装の復号と同じ辿り方で数えた。DSH は起動していない。名前に credential を含むパッケージは読んでいない。import できなかったのは設定を持たない `dsh-client-store`・`dsh-client-ui-primitives` の 2 件。
  - 設定フォームを持つ 24 パッケージの最大値：参照 144・復号ノード 144・復号の訪問 153・深さ 10・項目 19（すべて `dsh-llm-pi-ai`。深さだけは 2 位以下が 5）。循環 0、新しい実装での省略 0。既定値に戻す判定の探索は `dsh-llm-pi-ai` で 291。
  - 値に比例する分：`dsh-llm-pi-ai` の旧実装の保護の検査は、カスタムの提供元 1 件で約 100、モデル 1 件で約 56 増え、提供元 10 件×モデル 10 件で 6,612 となり、旧上限 4096 を超えて名前空間ごと消えていた（同じ形の合成データの試験で修正前に失敗を確認）。新しい実装では password を含まない部分木を検査しないため、この構成の保護の検査はほぼ 0、値の表示は約 750 ノード（50 件×10 モデルで約 3,750、8.6 ms）。
  - 決めた上限：ノード 1024（実測最大の約 7 倍）、復号の訪問 4096（約 27 倍）、深さ 32（約 3 倍）、項目 512（約 27 倍）は据え置き。保護の検査と値の表示は利用者のデータに比例するため 4096 から 32768 に上げた（値の表示は上の 50 件構成でも約 9 倍の余裕）。
- 未確認・残り：実物の DSH は `role: 'secret'` と `secrets` の別配列で値を伏せており、M3E が追加で見る `role: 'password'` は同梱プラグインに 1 件もない（`secret` 3 件・`credential-ref` 4 件）。サーバー側の伏字は従来どおり前提にしている。`secret` を M3E 側でも伏せるかはこの Issue の範囲外として変えていない。`custom-provider.ts` の `containsBlocked` は上限なしの再帰のまま（先に上限つきの `settingFieldAccess` を通る）。ブラウザーは `?mock` の Chromium だけで、iOS 実機は未確認。
- 試験：`tests/08-schema-limits.test.ts` 12 件（11 件は修正前に失敗、交差の password の 1 件は回帰防止）、`tests/08-malformed-data.test.ts` の上限の期待を「先頭 512 項目＋案内」に変更、`e2e/malformed-data.spec.ts` の指数的な共有の期待を「1 つの項目」に変え、深さ・項目数の縮退の e2e を追加（2 件とも修正前に失敗を確認）。
- 検証：`pnpm typecheck`、`tsc -p tsconfig.e2e.json`、`pnpm test`（1,214 件中 1,212 件成功・失敗 0。skip 2 件は DSH 配布物が `tmp/dsh-integration/` に無いための既存の skip）、`pnpm build`、`pnpm check:pack`（19 ファイル。npm のキャッシュは `tmp/npm-cache`）が成功。本番ビルドでは凍結の処理が除かれていることを生成物で確認した。`?mock` の e2e は `malformed-data` 7 件、設定 6 spec 34 件、設定を含む `mock`・`operations`・`edge-cases`・`stage6c`・`provider-record-broadcast` 66 件が成功（ポート 5227）。`store.ts` は #80 が修正中のため変更していない。

### 2026-10-19：Issue #102（PR #110）、画面の基準の色を端末ごとに選べるようにした

- **担当範囲外を触った経緯**：外観シートに色の選択を足す機能のため、次の担当外のファイルを変更した。設計書の「担当するファイル」は `web/src/features/settings/` と `tests/08-*.test.ts` だが、画面全体の配色は `web/src/app/theme/`（`appearance.ts`、`colors.ts`、`Theme.tsx`、`apply.ts`、`index.ts`）が持ち、起動直後に保存済みの配色を当てるには `web/src/main.tsx` の先頭で呼ぶ必要があった。ほかに、外観の仕様を `docs/ui-spec.md` の設定タブの節へ、e2e を `e2e/mock.spec.ts`（08a）と `tests/00-theme-colors.test.ts` へ足した。いずれも色の入力を `themeOptions` 固定から引数にする変更で、他の機能の挙動は変えない。担当外のため統合の担当は差分を確認してほしい。
- **PR #110 のレビューへの対応**：(1) `<input type="color">` の連続更新は、`AppearanceSheet.tsx` で 1 フレームに 1 回だけ `setThemeColor` を呼ぶ（requestAnimationFrame。シートを閉じるときは保留中の最後の色を反映する）。入力欄は保存の遅れに引きずられないよう、手元の状態で選択中の色を表示する。`colors.ts` のパレットの作り置きは直近 32 色までにした。(2) 「ほかの色」の選択状態は、`aria-pressed` を付けられない（色の入力に許される ARIA 属性ではない）ため、入力の名前を「ほかの色（選択中）」にして伝える。(3) `applyStoredTheme` と `meta[name=theme-color]` の更新を `web/src/app/theme/apply.ts` に移し、DOM のない単体試験（`tests/08-theme-apply.test.ts`）で明暗・端末設定・タグなし・失敗時を確かめる。実ブラウザーでは 08a で `theme-color` の内容と「ほかの色」の名前を確かめる。
- **PR #110 の 2 回目のレビューへの対応**：「ほかの色」の変更で予約したフレーム、またはシートを閉じたときの反映が、あとから選んだプリセットを捨てたはずのカスタム色で上書きしていた（プリセットのタップが保留中の色を取り消していなかった。OverlayHost は閉じるアニメーションのあいだシートを残すため、Escape の直後でも起きる）。間引きを `web/src/features/settings/frame-throttle.ts` の `createFrameThrottledWriter` に分け、プリセットは `immediate` で保留中のフレームを取り消して保留の色を捨ててから書く。閉じるときの `flush` は保留が残っているとき、つまり最新の意図がカスタム色のときだけ書く。プリセットが保存済みの色と同じでも入力欄にカスタム色が残らないよう、プリセットのタップで入力欄の表示もその色に戻す。試験は `tests/08-frame-throttle.test.ts`（同じフレームの custom → preset → 閉じるを含む 5 件）と `e2e/mock.spec.ts` の 08c（同じタスクで「ほかの色」→ プリセット、および「ほかの色」→ プリセット → Escape）。08c は修正前のコードで失敗することを確かめた。

### 2026-10-19：Issue #126、履歴移動で自動保存前に離れても入力を失わない

- 原因は `SchemaFields.tsx` のアンマウント時の `input.setActive(false)` が `input.ts` の保存待ちタイマーを解除し、`use-settings.ts` の store も画面ごとに作り直されていたこと。`setActive` を `leave()` に置き換え、`createSettingInput` は画面を離れるときに `flush()` する。`drain` は画面の有無で打ち切らないため、最初の保存中に追加入力して離れた場合も最新値を続けて保存する。
- `useSettings` は `createSettingsStore` の結果を remote ごとの `WeakMap` に保持し、画面をまたいで下書き・保存結果・欄エラーを復元する。設定画面を開き直したときは `reload()` して、購読していない間に届かなかった変更を読む。`FieldEditor` の離脱は 0ms 後に遅らせ、StrictMode の疑似アンマウントでは保存しない。
- 試験：`tests/08-input.test.ts` の離脱の期待を新しい契約へ変更。`e2e/settings-drafts.spec.ts` に、600ms 以内の `page.goBack()`、最初の保存中の追加入力、離脱時の保存拒否から開き直して再保存の 3 件を追加し、修正前に失敗することを確認した。
- 検証：`pnpm typecheck`、`tsc -p tsconfig.e2e.json --noEmit`、`pnpm test`（1,321 件中 1,319 件成功・失敗 0、skip 2 件は既存）、`pnpm build`、`git diff --check`。`?mock` の e2e は `e2e/settings-*.spec.ts` 38 件と、`operations`・`edge-cases`・`mock` の 08 系 9 件が成功。

### 2026-10-20：Issue #126 レビュー対応、設定画面を閉じている間も接続と通知を受け取る

- 回帰の原因は、store を remote ごとに残した一方、`connection.state` と `settings/document-updated` の購読を `useSettings` の effect に残したこと。設定画面が 1 つも出ていない間の切断・再接続が store に届かず、応答の返らない保存が queue と `saving` を止めたままになった。
- `settings-lifetime.ts` の `settingsStoreFor` で、store の生成時に購読を 1 回だけ張り、remote と同じ寿命にした。画面ごとに残すのは `subscribeNotice(showSnackbar)` だけにし、`opened()` で設定画面を開いたときの `reload()` を行う。
- `SchemaFields.tsx` の離脱時は `input.leave()` の完了後に `dirty` または欄のエラーが残っていれば、`showSnackbar` で「『<項目の名前>』を保存できませんでした。設定を開き直して確かめてください。」と知らせる。
- 試験：`tests/08-settings-lifetime.test.ts` 3 件（開くたびの reload、画面を閉じている間の切断・再接続、`document-updated`）。`e2e/settings-drafts.spec.ts` に、応答を止めた保存のまま `#/` へ移り、切断・再接続後に開き直して 90 を保存する 1 件を追加。修正前の `use-settings.ts` で「保存しています…」が残って失敗することを確認した。離脱時の拒否の試験にはスナックバーの確認を足し、修正前の `SchemaFields.tsx` で失敗することを確認した。`e2e/settings-broadcast.spec.ts` の S5 は、画面を閉じた後の `document-updated` でも読む期待（1 回）に変えた。
- 検証：`pnpm typecheck`、`tsc -p tsconfig.e2e.json --noEmit`、`pnpm test`（1,324 件中 1,322 件成功・失敗 0、skip 2 件は既存）、`pnpm build`、`git diff --check`。`?mock` の `e2e/settings-drafts.spec.ts` 9 件が成功。

### 2026-10-19：Issue #123、モードの一覧と新しい会話の既定

- **DSH で確かめた契約**（インストール済みの `@deepseek-ai/dsh` 0.2.0-rc.2 の型と標準クライアントを読み取りで確認。DSH は起動していない）：`agentPresets.list()` は `{ presets }` を返し、各行は `id`・`isDefault` と任意の `name`・`description`・`broken` を持ちます。`agentPresets.read(id)` は `{ agentPreset, content, name?, description? }` を返し、知らない ID は `agent-preset/not-found` で失敗します。既定は `agent-preset-registry` の `selectedDefault` で、`settings.update('agent-preset-registry', { selectedDefault }, revision)` により保存します。標準の画面は一覧の表示と既定の選択だけで、モードの作成・編集はしません（作成は Creator モードのバンドルが担います）。
- **組み込みの判定**：名前を公開しない既知の ID（`standard`・`ptc`・`minimal`・`cordis`）だけを組み込みとしました。同じ ID でも Host が `name` を返したものは、その名前と説明を持つカスタム宣言として扱います。標準クライアントの組み込みの説明は英語と中国語だけで日本語がないため、M3E の日本語を辞書に置きました。標準の英語の説明との対応は、標準が「Work with code, files, and information…」、PTC が「Includes all Standard mode capabilities…」、最小が「The agent works using only a terminal tool…」、Creator が「Customize DSH through conversation…」です。
- **実装**：`agent-presets.ts` が一覧・文書の形を検査し（不正な行と重複を捨てる）、組み込みの表示文と 2 つのまとまりを作ります。`agentPresets` の名前空間がない Host は `list()` を `undefined` にして「利用不可」にし、`gateway/invocation-unavailable` も同じ扱いにします。`AgentPresetsPage.tsx` が一覧、既定の保存、壊れた行、設定の全画面シートを持ちます。保存は `createSettingsStore().edit(AGENT_PRESET_NS, ['selectedDefault'], id)` を使い、設定ファイルを直接書きません。`agent-preset-registry` は汎用フォームから外し、設定トップの「エージェント」の次の「モード」から `#/settings/modes` を開きます。ルートは 2 つの部分を持つ `/settings/:page` より前に登録しました。
- **偽データと試験**：`mock.ts` に組み込み 4 件、名前と説明のあるカスタム、説明のないカスタム、壊れた行の 7 件を足しました。既定は `selectedDefault` を読み、未設定なら `standard` です。シナリオは `agent-presets-unavailable`（名前空間なし）と `agent-presets-error`（取得失敗）で、保存の拒否と読み取り専用は既存の `settings-rejected`・`settings-readonly` を再利用します。試験は `tests/08-agent-presets.test.ts` 4 件（不正な行・組み込みの判定・偽データの保存と read・利用不可と失敗）と `e2e/agent-presets.spec.ts` 5 件（入口と説明・既定の変更・壊れた行と設定の閲覧・読み取り専用・利用不可と失敗）です。既存の設定の試験は、`agent-preset-registry` が汎用フォームから消えたことに合わせて期待を 4 ファイルで更新しました。
- **検証**：`pnpm typecheck`、関連の単体試験 71 件、`pnpm exec playwright test -c tmp/e2e-alt-port.config.ts agent-presets.spec.ts` の 5 件、`pnpm test`（1,342 件中 1,340 件成功・失敗 0、既存の skip 2 件）、`pnpm build`、`git diff --check` が成功しました。差分は文書を含めて 581 行（追跡済み 117 行、新規 464 行）で、600 行の上限内です。
- **残ること**：Creator モードへの入口は作りませんでした。標準の画面では `cordis` のモードがあることと会話の導線があるときに `uiWorkspace.startSession()` で `cordis` を選び、`configForms.developerTools.enabled` にも依存します。M3E には会話の開始の導線と開発者向けの設定の読み取りがないため、今回の範囲では出しません。モードの作成・編集・削除、並び替え、実 DSH での確認（`e2e-dsh` は未起動）、英語と中国語の訳（`en: null`・`zh: null`）は後続です。

### 2026-10-20：Issue #143、コード作業がオフのときの PTC と最小

- **DSH で確かめた契約**（インストール済みの `@deepseek-ai/dsh` 0.2.1-rc.2 の `dsh-client-ui-agent-preset` と `dsh-client-ui-settings` を読み取りで確認）：`ui-settings` の形は `{ enabled: boolean }`（既定 `true`）。標準の画面は PTC と最小（`requiresCodingTools`）を一覧と新しい会話のメニューから隠し、`reconcileCodingTools` が、隠した既定を `settings.update('agent-preset-registry', { selectedDefault: 'standard' }, revision)` で戻す。`ui-settings` の変更と一覧の読み直しのたびに走る。標準が無いか壊れているときは、保存せずにエラーを出す。
- **実装**：`agent-presets.ts` に `codingToolsDisabled`・`requiresCodingTools`・`visiblePresets`・`codingToolsReset`（隠す・戻す・標準が使えないの判定。純関数）。`useAgentPresetRoster` が判定を実行し、保存は既存の `store.edit(AGENT_PRESET_NS, ['selectedDefault'], 'standard')`。保存を拒否されたら、一覧を読み直すまで再試行しない。設定の読み込み中は、隠すモードが一瞬見えないよう「読み込み中」にする。
- **標準の画面との違い**：標準の `developerTools.enabled` は値が読めるまで `false` として扱う（読み込み中や値がないときも隠す）。M3E は、隠す条件と戻す条件をどちらも `enabled === false` にそろえた。値がない・読めないときはすべてのモードを出す。
- **偽データ**：`ui-settings`（`enabled: true`）を足した。シナリオ `coding-tools-off`、`coding-tools-off-default-ptc`、`coding-tools-off-default-ptc-no-standard`。
- **入れていないこと**：新しい会話の画面のモードを選ぶチップ、会話のヘッダーのモードの表示、Creator モードの入口（M3E には #138 で入れていない。入れるかどうかは別の Issue）。
- **実 DSH での確認**：隔離した Host（0.2.1-rc.2、`e2e-dsh` の起動手順。コミットしない使い捨ての試験）で、`settings.describe()` の `ui-settings` が `autoGenerate: false`・`value: { enabled: true }`・`applies: 'live'`・`enabled` は `boolean`（既定 `true`）であることを確かめ、偽データの形と合わせた。同じ Host で既定を `ptc`、`enabled` を `false` にして `#/settings/modes` を開くと、PTC と最小が隠れ、`selectedDefault` が `standard` に保存された。`enabled` を `true` に戻すと 4 件に戻った。この確認は、M3E の 0.0.8 を 0.2.1-rc.2 に載せた状態で行ったもので、標準の画面からの切り替え（`/` から `/m3e/` への移動）は通らなかったため、`/m3e/` を直接開いている（0.2.1-rc.2 対応の別の作業の範囲）。

### 2026-10-21：設定の「一般」①コーディングビュー（`feat/settings-coding-view`）

標準の画面の「設定 → 一般」にあって M3E にない項目を、3 本の PR に分けて足します。この PR は土台と「コーディングビューを表示」です。次の PR で作業の詳細・パフォーマンスと使用状況、その次で言語とリンクの開き方を足します。

- **DSH で確かめた契約**（インストール済みの `@deepseek-ai/dsh` 0.2.1-rc.2 の `dsh-client-ui-settings/lib/client.js` と `dsh-client-ui-settings-general/lib/client.js` を読み取りで確認）：名前空間 `ui-settings`（`DEVELOPER_TOOLS_NAMESPACE`）、項目 `enabled`、型は真偽、既定 `true`（`DeveloperToolsSettingsFields`）。標準の画面は、保存された値が届くまで `false` として扱う（`getSnapshot: () => scope.getSnapshot().value?.enabled ?? false`）。標準の画面の文言は、英語が「Show coding view」と説明「Shows trajectory, code diffs, and all Agent presets」、中国語が「显示代码工作视图」と説明「开启后，显示轨迹、本轮代码差异，可选择完整的 Agent 预设切换」。
- **隔離した実 DSH（0.2.1-rc.2、`e2e-dsh`）で確かめたこと**：`settings.describe()` の `ui-settings` は `autoGenerate: false`、`value: { enabled: true }`、`applies: 'live'`、スキーマは真偽。`e2e-dsh/settings-general.spec.ts` で、M3E のスイッチで変えると標準の画面の設定ダイアログ（`Show coding view`）が再読み込みなしで変わり、標準の画面で戻すと M3E のスイッチも戻ること、オフにすると M3E のモードの一覧から PTC と最小が消えてオンで戻ることを確かめた。試験の最後に値をオンへ戻す。
- **仕組み**：`general.ts` が行の表（`generalRows`：名前空間・項目・部品の種類・既定値・古い保存値の読み替え）と、Host のスキーマと照らして出す行を決める `generalEntries` を持つ。部品は共通設定の `FieldEditor` をそのまま使い、題名・説明・選択肢の表示だけを `FieldDisplay` で差し替える。そのため、下書き・revision・直列化・競合（「ほかの場所で設定が変わりました。読み直しました」と「もう一度保存する」）・拒否（項目の下に理由）・書き込み不可（無効にして案内）は、共通設定と同じ決まりのまま。スキーマが期待した部品の種類でない行、選択肢が足りない行は、推測せずに出さない。
- **PTC と最小を隠す判定の所在**（依頼の 4）：新しく足したものではなく、Issue #143 で入れた `agent-presets.ts` の `codingToolsDisabled`（`CODING_TOOLS_NS = 'ui-settings'`、`enabled === false` のときだけオフ）が、`useAgentPresetRoster`（`AgentPresetsPage.tsx`）で `useSettings()` の名前空間を読んで判定している。`settings.update('ui-settings', …)` の保存と、標準の画面からの変更（`settings/document-updated`）は同じストアに入るので、このスイッチの値にそのまま従う。`grep` で `ui-settings` を探すと定数の 1 か所に見えるが、読んでいるのはこの関数。試験：`tests/08-general.test.ts`（保存した値を `codingToolsDisabled` が読む）、`e2e/settings-general.spec.ts` の G2。
- **`ui-` の除外**（`schema.ts` の `groupNamespaces`）：`generalNamespaces`（専用の行がある名前空間）を足し、`ui-` で始まるものと合わせて汎用のページから外す。ほかの `ui-*`（`ui-theme` など）はこれまでどおり出さない。
- **読み込み中・エラーの案内**：「設定を読み込んでいます…」「この DSH では設定を変更できません」などの案内（`SettingsStatus`）は、「一般」の上に 1 つだけ置いた（以前は「DSH の設定」の見出しの下）。「一般」の行が先に出て、案内が下にあると、無効の理由が見えないため。案内の文字は変えていない。
- **言語**：文言は `messages.ts` の `generalMessages` に日本語・英語・中国語を同じ変更で足した。`DISPLAY_LOCALES` は `['ja']` のままなので、画面は日本語（11-i18n の決まり）。`FieldEditor` の固定の文言（「保存しました」「もう一度保存する」など）は設定の移行 PR まで日本語のまま。
- **画面の外観**：390px 幅で、「この端末」と「DSH の設定」の間に「一般」の見出しとスイッチ 1 行（説明つき）が出る。
- **未確認**：iOS 実機。

### 2026-10-21：設定の「一般」②作業の詳細・パフォーマンスと使用状況（`feat/settings-chat-display`）

- **DSH で確かめた契約**（インストール済みの `@deepseek-ai/dsh` 0.2.1-rc.2 の `dsh-client-ui-chat/lib/client.js`・`lib/index.js` を読み取りで確認）：名前空間 `ui-chat`（`CHAT_SETTINGS_NAMESPACE`）。`transcriptView`：`compact`・`standard`・`detailed`・`verbose` と、古い保存値の `normal`・`expanded`（標準の画面は `detailed` と読み、選択肢には出さず、書き戻さない）。Host のスキーマには既定がなく（`.loose()`）、標準の画面が `dshDesktop` のあるデスクトップアプリでは `standard`、それ以外では `detailed` を使う。`collapseTiming`：`completion`（既定）・`next-input`。`performanceUsage`：`compact`・`detailed`（既定）。`linkOpening`：`sidebar`（既定）・`new-tab`（次の PR で扱う）。標準の画面の文言は、英語が Work details／Compact・Standard・Detailed・Verbose、When to Collapse Work Details／On completion・On next message、Performance & usage／Compact・Detailed。中国語は 工作步骤展示／简洁・标准・详细・完全展开、工作步骤收起时机／回答结束后・下次有新消息时、性能与用量／简洁・详细。
- **隔離した実 DSH（0.2.1-rc.2、`e2e-dsh`）で確かめたこと**：`settings.describe()` の `ui-chat` は `autoGenerate: false`、`applies: 'live'`、何も保存していないときの `value` は `{ collapseTiming: 'completion', performanceUsage: 'detailed', linkOpening: 'sidebar' }`（`transcriptView` は無い）。偽データの `ui-chat`（`mock-fixtures.ts`）は、この実物の写しで、`e2e-dsh/rpc.spec.ts` の S5 の照合（スキーマの形・`value`・`autoGenerate`）が成功する。`e2e-dsh/settings-general.spec.ts` の G-real-3 で、M3E で 3 項目を変えると標準の画面の設定ダイアログ（Work details／When to Collapse Work Details／Performance & usage）が変わり、標準の画面で変えると M3E の選択が変わること、再読み込みしても残ることを確かめた。
- **標準の画面と同じ値の読み方**：保存した値がない `transcriptView` は「詳細」、`collapseTiming` は「回答の完了時」、`performanceUsage` は「詳細」として出す（`general.ts` の `fallback` と `legacy`）。M3E は `transcriptView` を自分では書き戻さない（選んだときだけ保存する）。
- **M3E のチャットの表示はこの値をまだ読んでいない**：`web/src/` で `transcriptView`・`collapseTiming`・`performanceUsage` を読むのは、この設定の行だけ。チャットの詳細度や統計の見せ方を M3E の画面に反映するのは別の作業で、行の説明には「標準の画面の表示に使われます」と書いた。
- **選択の部品**：`FieldEditor` の選択（`m3e-select`）に、`FieldDisplay.choices` で標準の画面と同じ順・同じ訳の選択肢を渡す。Host のスキーマに選択肢のどれかがなければ、その行を出さない（`generalEntries`）。保存は項目 1 つの差分（`{ transcriptView: 'verbose' }` など）で、ほかの項目は変えない。
- **試験**：`tests/08-general.test.ts`（選択肢の順と 3 言語の訳、既定と古い値の読み替え、スキーマに選択肢がない Host、項目ごとの保存の差分と revision、競合・拒否・書き込み不可）、`e2e/settings-general.spec.ts` の G8〜G12、`e2e-dsh/settings-general.spec.ts` の G-real-3。選択の表示は、`m3e-select` の `selected`（選ばれた選択肢）で確かめる（要素の文字列には全選択肢が含まれるため）。
- **未確認**：デスクトップアプリ（`dshDesktop`）での既定（`standard`）。M3E は常に携帯向けなので「詳細」を既定にした。iOS 実機。
- **レビューへの対応（幅 320px のラベル）**：`m3e-form-field` のラベルは 1 行で、はみ出す分を切る。「作業の詳細を折りたたむタイミング」は 320px で全文 198px に対し使える幅 185px で切れていた（340px 以上は収まる）。日本語を「折りたたむタイミング」、英語を `Collapse timing` に短くし、何を折りたたむかは説明文（「作業の詳細を自動で折りたたむタイミングを選びます。」）に残した。中国語の `工作步骤收起时机` は DSH のままで収まる。`e2e/settings-general.spec.ts` の G17 が、幅 320px で「一般」の全行のラベルが切れないこと（`scrollWidth` が `clientWidth` 以下）を確かめる。ラベルの折り返しは、`m3e-form-field` の浮くラベルの高さが固定で、ほかの設定の画面も変わるため行わなかった。

### 2026-10-21：設定の「一般」③言語とリンクの開き方（`feat/settings-language`）

- **DSH で確かめた契約**（インストール済みの `@deepseek-ai/dsh` 0.2.1-rc.2 の `dsh-client-locale/lib/client.js` を読み取りで確認）：名前空間 `locale`、項目 `preference`、文字列で `^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*$`、任意（未設定は保存しない）。内蔵の言語は `zh`（表示名「中文」）と `en`（「English」）だけ（`LOCALE_IDS`、`BUILT_IN_LOCALE_METADATA`）。標準の画面の選択は `setLocale(id)` で、`preference` に `id` を保存する。保存値がなければブラウザの言語（`resolveInitialLocale`）、どれも合わなければ英語。標準の画面は「端末の言語に合わせる」の選択肢を持たず、保存値を消す操作もない。標準の画面の行の題は英語 `Language`、中国語 `语言`。
- **「端末の言語に合わせる」は M3E の追加**：標準の画面にない選択肢で、`settings.mutate('locale', [{ op: 'unset', path: ['preference'] }], revision)` で保存値を消す。保存値がなければ標準の画面は、ブラウザの言語（`navigator.languages`。`zh-TW` のように主言語が合えば合う）が内蔵の `zh` か `en` に合うときだけその言語になり、合わなければ英語になる（`detectBrowserLocale`・`resolveInitialLocale`）。つまり日本語の端末では、標準の画面は英語になる一方、M3E は日本語のまま（M3E の言語の決め方は 11-i18n）。この違いは、行の説明に「標準の画面は端末の言語が English か中文のときだけそれに合わせ、ほかの言語（日本語を含む）では English になります」と書いた。選択肢の名前は、依頼で決めた「端末の言語に合わせる」のままにした。文言は DSH の辞書にないため、`docs/i18n/glossary.md` に「なし」と書いた。
- **日本語は選択肢に足さない**：標準の画面の内蔵言語に日本語はなく、`ja` を保存しても標準の画面は登録がないとしてブラウザの言語に戻る。M3E の画面を日本語のままにしたい利用者は「端末の言語に合わせる」を使う（標準の画面は英語になる。上の項目）。すでに `ja` など別の言語タグが保存されているときは、そのタグをそのまま選択肢に足して選択済みで出す（`general.ts` の `open`）。
- **隔離した実 DSH（0.2.1-rc.2、`e2e-dsh`）で確かめたこと**：`settings.describe()` の `locale` は `autoGenerate: false`、何も保存していないとき `value: {}`、`applies: 'live'`。`e2e-dsh/settings-general.spec.ts` の G-real-4 で、M3E で「中文」を選ぶと標準の画面の設定ダイアログが中国語になり行が「中文」を指すこと、標準の画面で English を選ぶと M3E が English になること、再読み込みしても残ること、「端末の言語に合わせる」で保存値が消えることを確かめた。
- **汎用ページから言語を外した**：`locale` は「Web 検索とシェル」のページにスキーマ生成で出ていたが、専用の行に移したので `groupNamespaces` から外した（`generalNamespaces` に足し、許可リストと `namespaceTitle` から削除）。`tests/08-rpc-contract.test.ts` と `tests/08-settings.test.ts` の期待を、`locale` が `tools` に入らないものに変えた。表示が変わった理由は、同じ設定を 2 か所に出さないため。
- **M3E の言語表示は変わらない**：`DISPLAY_LOCALES` は `['ja']` のまま。英語・中国語を選んでも、`locale.preference` が変わって標準の画面が切り替わるだけで、M3E の画面と `<html lang>` は日本語（`e2e` の G14 で確かめた）。行の説明にその旨（「M3E の画面は今のところ日本語で表示します」）を書いた。英語・中国語を表示に使えるようにする PR で、この一文を外す。
- **リンクの開き方は出さなかった**：標準の画面は、アプリ内ブラウザ（サイドバーの `browser` タブ）が使えるときだけ `linkOpening` の行を出す（`LinkOpeningRow` の `useBrowserAvailable`）。0.2.1-rc.2 の標準の Web 画面にはその行がなく（実 DSH で設定ダイアログを確認）、M3E にはアプリ内ブラウザの有無を知る手段も、リンクを開く場所を選ぶ画面もない（`Markdown.tsx` は常に新しいタブで開く）。値の保存先（`ui-chat` の `linkOpening`、`sidebar`・`new-tab`、既定 `sidebar`）は確かめたが、効かない行を足さないことにした。必要になれば `generalRows` に 1 行足すだけでよい（偽データのスキーマには `linkOpening` が入っている）。
- **試験**：`tests/08-general.test.ts`（選択肢と 3 言語の題、既定の読み替え、知らない言語タグ、`unset` の保存、競合・拒否・書き込み不可）、`e2e/settings-general.spec.ts` の G13〜G16、`e2e-dsh/settings-general.spec.ts` の G-real-4。
- **未確認**：`zh-Hant` など標準の画面が出さない言語タグを実 DSH に保存したときの標準の画面の動き（コードを読んだだけ）。iOS 実機。
- **担当外で未更新のもの（レビューの指摘）**：`docs/ui-spec.md` の「設定タブ」は、まだ「一般」の区分がなく、105 行の「Web 検索とシェル」の名前空間に `locale` を含めたまま。設計書 08 の表と実装は更新したが、`docs/ui-spec.md` は担当ファイルの外（README の「変更してよいファイル」）なので変えていない。統合の担当、または変更を許可された担当が、次を反映する。「一般」の区分を「この端末」と「DSH の設定」の間に置き、コーディングビュー・作業の詳細・折りたたむタイミング・パフォーマンスと使用状況・言語の 5 行を並べる（保存先は上の各節）。「Web 検索とシェル」から `locale` を外す。
- **レビューへの対応（保存値の大文字・小文字）**：標準の画面は言語の登録を `toLowerCase()` で引く（`localeKey`）ので、`EN`・`Zh` が保存されていれば English・中文 として扱う。M3E も、保存値を小文字にして `en`・`zh` に一致すれば、その行を選択済みで出し、別の行を足さない（`general.ts` の `sameChoice`）。大文字小文字だけを無視し、`en-US` のような地域つきの標準の画面が引けないタグは、これまでどおりそのタグを選択肢に足して出す。コードを読んで確かめたもので、実 DSH に `EN` を保存しての確認はしていない。試験：`tests/08-general.test.ts`、`e2e/settings-general.spec.ts` の G15。

### 2026-10-22：言語の行に日本語を足す（Issue #78、`feat/issue-78-en-zh`）

- 英語・中国語の表示を有効にした（`DISPLAY_LOCALES` は `['ja', 'en', 'zh']`）ため、M3E の画面を日本語にする明示の手段として、選択肢に日本語（`ja`）を足した。上の③の「日本語は選択肢に足さない」を改めた。標準の画面は `ja` を登録していないので、ブラウザの言語（English か中文、ほかは English）で表示する。説明文（`languageDescription`）もそれに合わせて書き換えた。
- 言語名は、どの画面の言語でも自称（日本語・English・中文）で出す。
- 言語を切り替えると、`m3e-select` が選択肢の写しを作り直さず古い文言のまま残ること、言語と保存値が同時に変わると選択が外れることが e2e の G14・G15 で分かった。`FieldEditor`（`SchemaFields.tsx`）を #178 で直した。
