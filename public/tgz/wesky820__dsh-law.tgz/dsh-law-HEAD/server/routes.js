// HTTP 路由：静态前端 + REST API + SSE
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { ROOT } from './config.js';
import * as store from './store.js';
import { sseHandler, broadcast } from './sse.js';
import { getBoard, projectCase, computeStats, KANBAN_COLUMNS } from './board.js';

const PUBLIC = path.join(ROOT, 'public');
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.json': 'application/json', '.ico': 'image/x-icon', '.woff2': 'font/woff2',
};

function json(res, code, obj) { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(obj)); }
function ok(res, obj) { json(res, 200, { ok: true, ...obj }); }
function fail(res, code, error) { json(res, code, { ok: false, error }); }

async function readBody(req) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 4 * 1024 * 1024) throw new Error('请求体过大');
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

function emitCase(caseId) {
  const c = store.getCase(caseId);
  if (!c) return;
  broadcast('case.updated', { case: projectCase(c) });
  broadcast('stats', computeStats(store.listCases().map(projectCase)));
}

function feedAndBroadcast(entry) {
  const e = store.addFeed(entry);
  broadcast('feed', { entry: e });
  return e;
}

// ---------- API 处理器（body 已由外层读取） ----------
async function api(req, res, url, body) {
  const p = url.pathname;
  const m = (method) => req.method === method;
  const parts = p.split('/').filter(Boolean); // [api, ...]

  if (p === '/api/events') { sseHandler(req, res); return true; }

  if (p === '/api/board' && m('GET')) { ok(res, getBoard(store)); return true; }

  if (p === '/api/stats' && m('GET')) { ok(res, computeStats(store.listCases().map(projectCase))); return true; }

  if (p === '/api/cases' && m('GET')) {
    ok(res, { cases: store.listCases().map((c) => ({ id: c.id, title: c.title, caseNumber: c.caseNumber, status: c.status, updatedAt: c.updatedAt, partyNames: c.parties.map((x) => x.name).join('、') })) });
    return true;
  }
  if (p === '/api/cases' && m('POST')) {
    if (!body.title?.trim()) return fail(res, 400, '案件标题不能为空');
    const c = store.createCase(body);
    if (body.createWorkspace !== false) store.ensureCaseWorkspace(c);
    feedAndBroadcast({ type: 'case', caseId: c.id, caseTitle: c.title, label: `新建案件：${c.title}` });
    broadcast('case.created', { case: projectCase(c) });
    broadcast('stats', computeStats(store.listCases().map(projectCase)));
    ok(res, { case: projectCase(c) });
    return true;
  }

  if (parts[1] === 'cases' && parts[2] && !parts[3]) {
    const c = store.getCase(parts[2]);
    if (!c) return fail(res, 404, '案件不存在');
    if (m('GET')) { ok(res, { case: c }); return true; }
    if (m('DELETE')) {
      store.deleteCase(c.id);
      broadcast('case.deleted', { caseId: c.id });
      feedAndBroadcast({ type: 'case', label: `删除案件：${c.title}` });
      broadcast('stats', computeStats(store.listCases().map(projectCase)));
      ok(res, {});
      return true;
    }
    if (m('PATCH')) {
      const updated = store.updateCase(c.id, body);
      emitCase(c.id);
      ok(res, { case: projectCase(updated) });
      return true;
    }
  }

  if (parts[1] === 'cases' && parts[2] && parts[3] === 'transition' && m('POST')) {
    const c = store.getCase(parts[2]);
    if (!c) return fail(res, 404, '案件不存在');
    if (!KANBAN_COLUMNS.some((k) => k.id === body.to)) return fail(res, 400, '无效目标列');
    const from = c.status;
    store.transitionCase(c, body.to, 'human');
    feedAndBroadcast({ type: 'transition', caseId: c.id, caseTitle: c.title, label: `阶段变更：${KANBAN_COLUMNS.find((k) => k.id === from)?.title} → ${KANBAN_COLUMNS.find((k) => k.id === body.to)?.title}` });
    emitCase(c.id);
    ok(res, { case: projectCase(c) });
    return true;
  }

  if (parts[1] === 'cases' && parts[2] && parts[3] === 'chat' && !parts[4] && m('POST')) {
    fail(res, 410, '工作台对话已统一由 DSH 法律模式处理，请从 DSH 侧边栏进入本案对话');
    return true;
  }

  if (parts[1] === 'cases' && parts[2] && parts[3] === 'chat' && parts[4] === 'stop' && m('POST')) {
    fail(res, 410, '请通过 DSH 原生会话停止当前任务');
    return true;
  }

  if (parts[1] === 'cases' && parts[2] && parts[3] === 'conv' && m('DELETE')) {
    fail(res, 410, '工作台不再维护独立对话记录；请在本案 DSH 会话中管理历史');
    return true;
  }

  if (parts[1] === 'cases' && parts[2] && parts[3] === 'workspace' && !parts[4] && m('POST')) {
    const c = store.getCase(parts[2]);
    if (!c) return fail(res, 404, '案件不存在');
    const workspacePath = store.ensureCaseWorkspace(c);
    emitCase(c.id);
    ok(res, { path: workspacePath });
    return true;
  }

  if (parts[1] === 'cases' && parts[2] && parts[3] === 'workspace' && parts[4] === 'open' && m('POST')) {
    const c = store.getCase(parts[2]);
    if (!c) return fail(res, 404, '案件不存在');
    const workspacePath = store.ensureCaseWorkspace(c);
    if (process.platform !== 'darwin') return fail(res, 400, '当前系统暂不支持直接打开文件夹');
    const child = spawn('open', [workspacePath], { detached: true, stdio: 'ignore' });
    child.unref();
    ok(res, { path: workspacePath });
    return true;
  }

  if (parts[1] === 'cases' && parts[2] && parts[3] === 'schedule' && !parts[4] && m('POST')) {
    const c = store.getCase(parts[2]);
    if (!c) return fail(res, 404, '案件不存在');
    const title = String(body.title || '').trim();
    const date = String(body.date || '').trim();
    if (!title) return fail(res, 400, '事项名称不能为空');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(new Date(date + 'T00:00:00').getTime())) return fail(res, 400, '日期格式无效');
    const type = body.type === 'deadline' ? 'deadline' : 'event';
    let item;
    if (type === 'deadline') {
      item = { id: store.uid('dl'), title, kind: String(body.kind || 'other'), startDate: null, days: null, businessDays: false, dueDate: date, basis: String(body.note || '').trim(), done: false, at: store.now() };
      c.deadlines.push(item);
    } else {
      item = { id: store.uid('evt'), title, date, kind: String(body.kind || 'other'), note: String(body.note || '').trim(), at: store.now() };
      c.events.push(item);
    }
    store.touch(c); store.persist();
    feedAndBroadcast({ type, caseId: c.id, caseTitle: c.title, label: `手动登记${type === 'deadline' ? '期限' : '日程'}：${title}（${date}）` });
    emitCase(c.id);
    ok(res, { item, type });
    return true;
  }

  if (parts[1] === 'cases' && parts[2] && parts[3] === 'schedule' && parts[4] && m('DELETE')) {
    const c = store.getCase(parts[2]);
    if (!c) return fail(res, 404, '案件不存在');
    const eventIndex = c.events.findIndex((item) => item.id === parts[4]);
    const deadlineIndex = c.deadlines.findIndex((item) => item.id === parts[4]);
    let removed;
    let type;
    if (eventIndex >= 0) { [removed] = c.events.splice(eventIndex, 1); type = 'event'; }
    else if (deadlineIndex >= 0) { [removed] = c.deadlines.splice(deadlineIndex, 1); type = 'deadline'; }
    else return fail(res, 404, '日程或期限不存在');
    store.touch(c); store.persist();
    feedAndBroadcast({ type, caseId: c.id, caseTitle: c.title, label: `删除${type === 'deadline' ? '期限' : '日程'}：${removed.title}` });
    emitCase(c.id);
    ok(res, { removedId: removed.id });
    return true;
  }

  if (parts[1] === 'cases' && parts[2] && parts[3] === 'evidence' && parts[4] && parts[5] === 'status' && m('POST')) {
    const c = store.getCase(parts[2]);
    const e = c?.evidence.find((x) => x.id === parts[4]);
    if (!e) return fail(res, 404, '证据不存在');
    e.status = body.status; e.at = store.now();
    store.touch(c); store.persist();
    emitCase(c.id);
    ok(res, { evidence: e });
    return true;
  }

  if (parts[1] === 'cases' && parts[2] && parts[3] === 'gates' && parts[4] && parts[5] === 'decide' && m('POST')) {
    const c = store.getCase(parts[2]);
    const g = c?.gates.find((x) => x.id === parts[4]);
    if (!g) return fail(res, 404, '门禁不存在');
    if (!['approve', 'reject'].includes(body.decision)) return fail(res, 400, 'decision 必须是 approve 或 reject');
    if (g.status !== 'pending') return fail(res, 400, '该门禁已处理');
    g.status = body.decision === 'approve' ? 'approved' : 'rejected';
    g.decidedAt = store.now();
    g.decision = body.decision;
    store.touch(c); store.persist();
    feedAndBroadcast({ type: 'gate', caseId: c.id, caseTitle: c.title, label: `律师${body.decision === 'approve' ? '通过' : '驳回'}门禁：${g.title}` });
    emitCase(c.id);
    ok(res, { gate: g });
    return true;
  }

  if (p.startsWith('/api/settings')) { fail(res, 410, '模型、服务商和凭据统一在 DSH 设置中管理'); return true; }

  return false;
}

// ---------- 静态文件 ----------
function staticFile(req, res, url) {
  let p = url.pathname;
  if (p === '/' || p === '/app' || p === '/index.html') p = '/index.html';
  const file = path.join(PUBLIC, path.normalize(p).replace(/^([.][.][/\\])+/, ''));
  if (!file.startsWith(PUBLIC)) { res.writeHead(403); res.end('forbidden'); return; }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); res.end('not found'); return; }
  const ext = path.extname(file).toLowerCase();
  res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
}

export function handleRequest(req, res) {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname.startsWith('/api/')) {
    (req.method === 'POST' || req.method === 'PATCH' ? readBody(req) : Promise.resolve({}))
      .then((body) => api(req, res, url, body))
      .then((handled) => { if (!handled) fail(res, 404, '接口不存在'); })
      .catch((e) => fail(res, 400, String(e?.message || e)));
    return;
  }
  staticFile(req, res, url);
}
