// 看板定义与卡片投影
export const KANBAN_COLUMNS = [
  { id: 'intake',  title: '待接案',   color: '#64748b', hint: '新案件 · 接案评估' },
  { id: 'survey',  title: '调查取证', color: '#3b82f6', hint: '证据收集 · 事实调查' },
  { id: 'strategy',title: '策略制定', color: '#8b5cf6', hint: '请求权基础 · 诉讼策略' },
  { id: 'drafting',title: '文书起草', color: '#f59e0b', hint: '起诉状/答辩状/代理词' },
  { id: 'filing',  title: '待定稿送审', color: '#ef4444', hint: '定稿门禁 · 提交' },
  { id: 'closed',  title: '已结案',   color: '#10b981', hint: '归档 · 执行' },
];

export const TYPE_LABELS = { civil: '民事', criminal: '刑事', administrative: '行政', arbitration: '仲裁', consultation: '咨询', other: '其他' };

export function deadlineState(dl) {
  const today = startOfDay(new Date());
  const due = startOfDay(new Date(dl.dueDate + 'T00:00:00'));
  const days = Math.round((due - today) / 86400000);
  if (dl.done) return { done: true, days };
  return { overdue: days < 0, dueSoon: days >= 0 && days <= 7, days };
}
function startOfDay(d) { d.setHours(0, 0, 0, 0); return d; }

export function projectCase(c) {
  const dlStats = c.deadlines.map(deadlineState);
  return {
    id: c.id,
    title: c.title,
    caseNumber: c.caseNumber,
    court: c.court,
    type: c.type,
    typeLabel: TYPE_LABELS[c.type] || c.type,
    parties: c.parties.map((p) => ({ name: p.name, role: p.role })),
    summary: c.summary,
    status: c.status,
    workMode: c.workMode || 'case',
    assistant: c.assistant || { enabled: true, mode: 'full', autoExtract: true, reminders: 'all' },
    workspacePath: c.workspacePath || '',
    counts: {
      evidence: c.evidence.length,
      evidenceTodo: c.evidence.filter((e) => e.status === 'todo').length,
      deadlines: c.deadlines.length,
      deadlineOverdue: dlStats.filter((s) => s.overdue).length,
      deadlineSoon: dlStats.filter((s) => s.dueSoon).length,
      claims: c.claims.length,
      docs: c.docs.length,
      research: c.research.length,
      pendingGates: c.gates.filter((g) => g.status === 'pending').length,
      events: c.events.length,
    },
    latestMaterials: c.materials.slice(0, 3),
    aiActive: !!c.aiActive,
    updatedAt: c.updatedAt,
    lastActivityAt: c.lastActivityAt,
  };
}

export function computeStats(cards) {
  return {
    totalCases: cards.length,
    activeCases: cards.filter((c) => c.status !== 'closed').length,
    byColumn: Object.fromEntries(KANBAN_COLUMNS.map((k) => [k.id, cards.filter((c) => c.status === k.id).length])),
    overdueDeadlines: cards.reduce((n, c) => n + c.counts.deadlineOverdue, 0),
    dueSoonDeadlines: cards.reduce((n, c) => n + c.counts.deadlineSoon, 0),
    pendingGates: cards.reduce((n, c) => n + c.counts.pendingGates, 0),
  };
}

export function getSchedule(store) {
  const items = [];
  for (const c of store.listCases()) {
    for (const event of c.events || []) items.push({
      id: event.id, type: 'event', kind: event.kind || 'other', date: event.date,
      title: event.title, note: event.note || '', caseId: c.id, caseTitle: c.title,
    });
    for (const dl of c.deadlines || []) items.push({
      id: dl.id, type: 'deadline', kind: dl.kind || 'other', date: dl.dueDate,
      title: dl.title, note: dl.basis || '', done: !!dl.done, caseId: c.id, caseTitle: c.title,
      state: deadlineState(dl),
    });
  }
  return items.filter((x) => x.date).sort((a, b) => a.date.localeCompare(b.date));
}

export function getReminders(store) {
  const reminders = [];
  for (const c of store.listCases()) {
    const reminderMode = c.assistant?.reminders || 'all';
    if (reminderMode !== 'off') {
      for (const dl of c.deadlines || []) {
        const s = deadlineState(dl);
        if (s.done) continue;
        reminders.push({
          id: dl.id, type: 'deadline', title: dl.title, date: dl.dueDate,
          severity: s.overdue ? 'danger' : s.dueSoon ? 'warning' : 'normal', days: s.days,
          caseId: c.id, caseTitle: c.title,
        });
      }
      if (reminderMode === 'all') {
        if ((c.workMode || 'case') === 'consultation') reminders.push({
          id: `workflow-consult-${c.id}`, type: 'workflow', title: '补齐咨询要素并决定是否正式收案',
          date: '', severity: 'normal', caseId: c.id, caseTitle: c.title,
        });
        else if (c.status === 'intake') reminders.push({
          id: `workflow-intake-${c.id}`, type: 'workflow', title: '完成接案审查与利益冲突核验',
          date: '', severity: 'normal', caseId: c.id, caseTitle: c.title,
        });
        const evidenceTodo = (c.evidence || []).filter((e) => e.status === 'todo').length;
        if (evidenceTodo) reminders.push({
          id: `workflow-evidence-${c.id}`, type: 'workflow', title: `核对并补齐 ${evidenceTodo} 项待收集证据`,
          date: '', severity: evidenceTodo >= 3 ? 'warning' : 'normal', caseId: c.id, caseTitle: c.title,
        });
        if (c.status === 'drafting' && (c.docs || []).length) reminders.push({
          id: `workflow-draft-${c.id}`, type: 'workflow', title: '复核文书草稿中的事实、金额、期限与引用依据',
          date: '', severity: 'normal', caseId: c.id, caseTitle: c.title,
        });
      }
    }
    for (const gate of (c.gates || []).filter((g) => g.status === 'pending')) reminders.push({
      id: gate.id, type: 'gate', title: gate.title, date: gate.requestedAt?.slice(0, 10) || '',
      severity: 'review', caseId: c.id, caseTitle: c.title,
    });
  }
  return reminders.sort((a, b) => {
    const rank = { danger: 0, warning: 1, review: 2, normal: 3 };
    return (rank[a.severity] - rank[b.severity]) || String(a.date).localeCompare(String(b.date));
  });
}

export function getBoard(store) {
  const cards = store.listCases().map(projectCase);
  return {
    columns: KANBAN_COLUMNS,
    cases: cards,
    feed: store.getFeed().slice(0, 100),
    stats: computeStats(cards),
    schedule: getSchedule(store),
    reminders: getReminders(store),
  };
}
