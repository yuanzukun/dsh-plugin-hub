// DeepSeek 对话引擎：流式 chat completions + 函数调用 agent 循环
import { loadConfig } from './config.js';
import * as store from './store.js';
import { broadcast } from './sse.js';
import { TOOL_DEFS, TOOL_CN, executeTool } from './tools.js';
import { projectCase } from './board.js';

const ROLE_CN = { plaintiff: '原告', defendant: '被告', applicant: '申请人', respondent: '被申请人', thirdParty: '第三人', other: '其他' };
const KIND_CN = { request_basis: '请求权基础', defense: '答辩理由', issue: '争议焦点', fact: '待证事实' };

export function buildSystemPrompt(c) {
  const assistant = c.assistant || { enabled: true, mode: 'full', autoExtract: true, reminders: 'all' };
  let modeInstruction = !assistant.enabled
    ? '本案已关闭自动辅助：只回答问题，不调用工具，不自动登记或推进案件。'
    : assistant.mode === 'consultation'
      ? '当前是咨询接待模式：优先识别主体、诉求、时间、金额、证据与紧迫期限；信息不足时先提问。未经用户明确要求，不推进案件阶段、不起草正式文书。'
      : assistant.mode === 'manual'
        ? '当前是按需协作模式：仅在用户明确要求登记、生成或推进时调用工具，不主动改变案件数据。'
        : '当前是全流程辅助模式：主动识别应登记的事项并给出下一步提醒，但所有门禁与最终决定仍由律师完成。';
  if (assistant.enabled && assistant.autoExtract === false) {
    modeInstruction += ' 本案已关闭自动提取：只有用户明确要求登记、保存、生成或推进时才调用工具。';
  }
  const snapshot = JSON.stringify({
    title: c.title, caseNumber: c.caseNumber, court: c.court, judge: c.judge, type: c.type,
    parties: c.parties, summary: c.summary, status: c.status,
    deadlines: c.deadlines, evidence: c.evidence, claims: c.claims, docs: c.docs.map(d => ({ id: d.id, docType: d.docType, title: d.title, status: d.status, versionCount: d.versions.length })),
    research: c.research, gates: c.gates,
  }, null, 1).slice(0, 9000);

  return `你是「深法工作台」的 AI 律师助手，运行在本机法律工作台中，与执业律师协作处理案件。

【本案辅助策略】
${modeInstruction}

【工作方式】
1. 用户对话中出现的案件事实、证据、期限、主张、日程、检索结论，必须立即用对应工具登记到案件，不要只写在回复里。
2. 当事人提到的日期/期限（上诉期、举证期、答辩期、开庭）一律用 deadline_add 登记并注明法律依据；拿不准起算日时先向用户确认。
3. 用户提供的转账记录、合同、聊天记录、文件等用 evidence_add 登记（kind 选择合适种类）。
4. 起草文书：doc_draft 创建记录 → 在回复中写出全文 → doc_draft_save 保存为草稿版本。
5. 检索到的法规、案例、裁判规则用 research_note_save 沉淀；重要讨论结论用 minutes_save 存档。
6. 案件阶段用 case_transition 推进看板；结案只能由律师人工操作。门禁（接案/策略/定稿/结案）只能 gate_request 提交，由律师在界面审批。
7. 证据与主张用 claim_link 关联并写明证明目的。

【红线】
- 绝不编造法条、案号、案例、金额、日期；不确定就说不确定并请用户核对。
- 涉及金额、期限、法条、事实细节的表述，必须复述给用户确认。
- 你只登记与起草，定稿、审批、结案等最终动作一律由执业律师完成。

【当前案件快照】（实时）
${snapshot}

请用中文回复，专业、简洁、有结构。`;
}

// 流式调用 DeepSeek，解析 SSE，累积文本与工具调用
async function streamChat(messages, cfg, onDelta, toolsEnabled = true) {
  const url = cfg.baseUrl.replace(/\/+$/, '') + '/chat/completions';
  const resp = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${cfg.apiKey}` },
    body: JSON.stringify({
      model: cfg.model,
      messages,
      ...(toolsEnabled ? { tools: TOOL_DEFS } : {}),
      stream: true,
      temperature: cfg.temperature,
    }),
  });
  if (!resp.ok) {
    let msg = `HTTP ${resp.status}`;
    try { msg = (await resp.json()).error?.message || msg; } catch { /* ignore */ }
    throw new Error(`DeepSeek API 调用失败：${msg}`);
  }
  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buf = '';
  let content = '';
  const toolCalls = [];
  let finished = false;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    let nl;
    while ((nl = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, nl).trim();
      buf = buf.slice(nl + 1);
      if (!line.startsWith('data:')) continue;
      const payload = line.slice(5).trim();
      if (payload === '[DONE]') { finished = true; break; }
      try {
        const chunk = JSON.parse(payload);
        const delta = chunk.choices?.[0]?.delta || {};
        if (delta.content) { content += delta.content; onDelta?.(delta.content); }
        if (delta.tool_calls) {
          for (const tc of delta.tool_calls) {
            const i = tc.index ?? 0;
            toolCalls[i] ||= { id: '', name: '', arguments: '' };
            if (tc.id) toolCalls[i].id = tc.id;
            if (tc.function?.name) toolCalls[i].name += tc.function.name;
            if (tc.function?.arguments) toolCalls[i].arguments += tc.function.arguments;
          }
        }
      } catch { /* 忽略无法解析的分片 */ }
    }
    if (finished) break;
  }
  return { content, toolCalls: toolCalls.filter((t) => t.name || t.id), finished };
}

// 单轮 agent 执行：用户消息 → 工具循环 → 最终回复；所有变更实时广播
export async function runTurn(caseId, text, { turnId, isCancelled = () => false, model } = {}) {
  const cfg = { ...loadConfig() };
  const c = store.getCase(caseId);
  if (!c) throw new Error('案件不存在');
  if (!cfg.apiKey) throw new Error('尚未配置 DeepSeek API Key，请先在设置中配置');
  if (typeof model === 'string' && model.trim()) cfg.model = model.trim();
  else if (c.aiModel) cfg.model = c.aiModel;

  turnId ||= store.uid('turn');
  c.aiActive = true;
  store.touch(c);
  store.persist();
  broadcast('ai.start', { caseId, turnId, model: cfg.model });
  broadcast('case.updated', { case: projectCase(c) });

  const conv = store.loadConv(caseId);
  conv.messages.push({ role: 'user', content: text, at: store.now() });

  const messages = [{ role: 'system', content: buildSystemPrompt(c) }, ...conv.messages.slice(-40).map(stripTools)];
  const toolsUsed = [];
  let finalText = '';

  try {
    for (let round = 0; round < cfg.maxToolRounds; round++) {
      if (isCancelled()) { finalText = '（已停止）'; break; }
      const res = await streamChat(messages, cfg, (d) => broadcast('chat.delta', { caseId, turnId, text: d }), c.assistant?.enabled !== false);

      if (res.toolCalls.length) {
        const assistantMsg = { role: 'assistant', content: res.content || '', tool_calls: res.toolCalls.map((tc) => ({ id: tc.id, type: 'function', function: { name: tc.name, arguments: tc.arguments } })) };
        messages.push(assistantMsg);
        for (const tc of res.toolCalls) {
          let args = {};
          try { args = JSON.parse(tc.arguments || '{}'); } catch { args = { _raw: tc.arguments }; }
          const cn = TOOL_CN[tc.name] || tc.name;
          broadcast('ai.tool', { caseId, turnId, name: tc.name, cn, args });
          const feedEntry = store.addFeed({ caseId, caseTitle: c.title, type: 'tool', label: `AI 调用工具：${cn}` });
          broadcast('feed', { entry: feedEntry });
          let result;
          try { result = await executeTool(caseId, tc.name, args); }
          catch (e) { result = { ok: false, error: String(e?.message || e) }; }
          toolsUsed.push({ name: tc.name, args });
          messages.push({ role: 'tool', tool_call_id: tc.id, content: JSON.stringify(result).slice(0, 6000) });
          if (isCancelled()) break;
        }
        if (isCancelled()) { finalText = '（已停止）'; break; }
        continue;
      }

      // 纯文本回复
      conv.messages.push({ role: 'assistant', content: res.content || '', at: store.now() });
      finalText = res.content || '';
      break;
    }
  } catch (e) {
    const msg = String(e?.message || e);
    broadcast('chat.error', { caseId, turnId, message: msg });
    conv.messages.push({ role: 'assistant', content: `⚠️ 调用出错：${msg}`, at: store.now() });
    throw e;
  } finally {
    c.aiActive = false;
    store.touch(c);
    store.persist();
    broadcast('case.updated', { case: projectCase(c) });
    broadcast('ai.end', { caseId, turnId });
  }

  store.saveConv(caseId, conv);
  broadcast('chat.done', { caseId, turnId, text: finalText, toolCount: toolsUsed.length, model: cfg.model });
  return { turnId, text: finalText, tools: toolsUsed };
}

function stripTools(m) {
  if (m.tool_calls) { const { tool_calls, ...rest } = m; return rest; }
  return m;
}
