// 启动种子数据：首次运行创建示例案件，展示看板形态
import * as store from './store.js';

export function seedIfEmpty() {
  if (store.listCases().length > 0) return;

  const c1 = store.createCase({
    title: '【示例】张某某诉李某某民间借贷纠纷',
    caseNumber: '(2026)沪0113民初12345号',
    court: '上海市宝山区人民法院',
    judge: '',
    type: 'civil',
    summary: '2025年6月1日，李某某向张某某借款人民币200,000元，约定2025年12月31日前归还，月利率1%。到期后李某某未还款，张某某多次催收无果，拟起诉。',
    parties: [
      { id: store.uid('party'), name: '张某某', role: 'plaintiff', contact: '138****0001' },
      { id: store.uid('party'), name: '李某某', role: 'defendant', contact: '139****0002' },
    ],
  });
  c1.evidence = [
    { id: store.uid('ev'), name: '借款合同（2025-06-01）', kind: 'documentary', source: '委托人提供', description: '载明借款金额20万、利率1%/月、还款日2025-12-31', status: 'collected' },
    { id: store.uid('ev'), name: '银行转账记录（200,000元）', kind: 'electronic', source: '委托人提供', description: '2025-06-01 转账凭证', status: 'collected' },
    { id: store.uid('ev'), name: '微信催收聊天记录', kind: 'electronic', source: '委托人提供', description: '2026年1月至3月多次催收', status: 'todo' },
  ];
  c1.claims = [
    { id: store.uid('claim'), title: '请求返还借款本金200,000元', kind: 'request_basis', statement: '双方成立借款合同关系，借款到期未还', basisLaw: ['《民法典》第667条', '《民法典》第675条'], links: [], at: store.now() },
    { id: store.uid('claim'), title: '请求支付利息（按约定月息1%计算）', kind: 'request_basis', statement: '自2025年6月1日起至实际清偿之日止', basisLaw: ['《民法典》第670条'], links: [], at: store.now() },
  ];
  c1.claims[0].links.push({ evidenceId: c1.evidence[0].id, purpose: '证明借款合意成立', strength: 'direct' });
  c1.claims[0].links.push({ evidenceId: c1.evidence[1].id, purpose: '证明借款已实际交付', strength: 'direct' });
  c1.deadlines = [
    { id: store.uid('dl'), title: '一审举证期限届满', kind: 'evidence', startDate: '2026-08-01', days: 30, dueDate: '2026-08-31', basis: '民诉法解释第99条', done: false, at: store.now() },
    { id: store.uid('dl'), title: '开庭（9月10日）前证据交换', kind: 'hearing', startDate: null, days: null, dueDate: '2026-09-05', basis: '', done: false, at: store.now() },
  ];
  c1.events = [
    { id: store.uid('evt'), title: '第一次开庭', date: '2026-09-10', kind: 'hearing', note: '宝山区法院第3法庭', at: store.now() },
  ];
  c1.research = [
    { id: store.uid('rs'), title: '民间借贷利息上限的裁判规则', source: '人民法院案例库', summary: '约定利率超过合同成立时一年期LPR四倍的部分，法院不予支持。', links: [], at: store.now() },
  ];
  c1.minutes = [
    { id: store.uid('min'), title: '接案会谈纪要', content: '当事人2026年8月10日到所会谈；借款本金20万，证据齐全；债务人失联风险需评估。', at: store.now() },
  ];
  c1.docs = [
    {
      id: store.uid('doc'), docType: 'complaint', title: '民事起诉状', instructions: '', status: 'draft',
      versions: [{
        v: 1, at: store.now(), hash: 'demo',
        content: '民事起诉状\n\n原告：张某某，男，19XX年X月X日出生，汉族，住上海市宝山区……\n被告：李某某，男，19XX年X月X日出生，汉族，住上海市宝山区……\n\n诉讼请求：\n一、判令被告返还原告借款本金人民币200,000元；\n二、判令被告支付利息（以200,000元为基数，自2025年6月1日起按月利率1%计算至实际清偿之日止）；\n三、本案诉讼费用由被告承担。\n\n事实与理由：……（示例草稿，AI 可继续完善）',
      }],
      at: store.now(),
    },
  ];
  store.transitionCase(c1, 'drafting', 'seed');
  c1.materials = [
    { id: store.uid('feed'), ts: store.now(), type: 'doc', label: '示例：民事起诉状草稿 v1 已保存' },
    { id: store.uid('feed'), ts: store.now(), type: 'evidence', label: '示例：登记证据 微信催收聊天记录' },
  ];

  const c2 = store.createCase({
    title: '【示例】王某某与某科技公司劳动争议仲裁案',
    caseNumber: '',
    court: '上海市劳动人事争议仲裁委员会',
    type: 'arbitration',
    summary: '2025年3月被公司违法解除劳动合同，主张违法解除赔偿金。',
    parties: [{ id: store.uid('party'), name: '王某某', role: 'applicant', contact: '' }],
  });
  c2.deadlines = [
    { id: store.uid('dl'), title: '仲裁时效（解除后1年）', kind: 'statute', startDate: '2025-03-15', days: 365, dueDate: '2026-03-15', basis: '劳动争议调解仲裁法第27条', done: true, at: store.now() },
  ];
  store.transitionCase(c2, 'survey', 'seed');

  store.persist();
}
