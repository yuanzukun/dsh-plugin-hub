// 数据层：内存态 + 原子落盘（JSON 文件，单用户本地应用足够）
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DATA_PATH, CONV_DIR, DATA_DIR } from './config.js';

const DEFAULT_ASSISTANT = Object.freeze({
  enabled: true,
  mode: 'full',
  autoExtract: true,
  reminders: 'all',
});

export function uid(prefix = '') {
  return (prefix ? prefix + '_' : '') + Date.now().toString(36) + '_' + crypto.randomBytes(4).toString('hex');
}
export const now = () => new Date().toISOString();

let db = { cases: [], feed: [] };
let saveTimer = null;

export function loadStore() {
  try { db = JSON.parse(fs.readFileSync(DATA_PATH, 'utf8')); } catch { /* first run */ }
  db.cases ||= [];
  db.feed ||= [];
  for (const c of db.cases) normalizeCase(c);
  return db;
}

function normalizeCase(c) {
  c.workMode ||= 'case';
  delete c.aiModel;
  delete c.chatBackend;
  c.dshSessionId ||= '';
  c.assistant = { ...DEFAULT_ASSISTANT, ...(c.assistant || {}) };
  c.workspacePath ||= '';
  c.events ||= [];
  c.deadlines ||= [];
  c.evidence ||= [];
  c.claims ||= [];
  c.docs ||= [];
  c.research ||= [];
  c.minutes ||= [];
  c.gates ||= [];
  c.materials ||= [];
  c.history ||= [];
  c.parties ||= [];
  return c;
}

export function persist() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(writeNow, 80);
}
export function flush() {
  clearTimeout(saveTimer);
  writeNow();
}
function writeNow() {
  const tmp = DATA_PATH + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 1));
  fs.renameSync(tmp, DATA_PATH);
}

// ---------- cases ----------
export function listCases() { return db.cases; }
export function getCase(id) { return db.cases.find((c) => c.id === id) || null; }

export function createCase(fields = {}) {
  const t = now();
  const c = {
    id: uid('case'),
    title: fields.title || '未命名案件',
    caseNumber: fields.caseNumber || '',
    court: fields.court || '',
    judge: fields.judge || '',
    type: fields.type || 'civil',
    parties: Array.isArray(fields.parties) ? fields.parties : [],
    summary: fields.summary || '',
    workMode: fields.workMode === 'consultation' ? 'consultation' : 'case',
    dshSessionId: '',
    assistant: {
      ...DEFAULT_ASSISTANT,
      ...(fields.assistant && typeof fields.assistant === 'object' ? fields.assistant : {}),
    },
    workspacePath: '',
    status: 'intake',
    history: [{ from: null, to: 'intake', at: t, by: 'human' }],
    deadlines: [],
    evidence: [],
    claims: [],
    docs: [],
    research: [],
    minutes: [],
    events: [],
    gates: [],
    materials: [],
    aiActive: false,
    createdAt: t,
    updatedAt: t,
    lastActivityAt: t,
  };
  db.cases.push(c);
  persist();
  return c;
}

export function updateCase(id, patch) {
  const c = getCase(id);
  if (!c) return null;
  for (const k of ['title', 'caseNumber', 'court', 'judge', 'type', 'summary', 'workMode', 'dshSessionId']) {
    if (k in patch) c[k] = patch[k];
  }
  if (Array.isArray(patch.parties)) c.parties = patch.parties;
  if (patch.assistant && typeof patch.assistant === 'object') {
    c.assistant = { ...DEFAULT_ASSISTANT, ...(c.assistant || {}), ...patch.assistant };
  }
  touch(c);
  persist();
  return c;
}

export function deleteCase(id) {
  const i = db.cases.findIndex((c) => c.id === id);
  if (i < 0) return false;
  db.cases.splice(i, 1);
  persist();
  return true;
}

export function touch(c) { c.updatedAt = now(); c.lastActivityAt = now(); }

export function mutateCase(id, fn) {
  const c = getCase(id);
  if (!c) return null;
  fn(c);
  touch(c);
  persist();
  return c;
}

export function transitionCase(c, to, by = 'human') {
  const from = c.status;
  if (from === to) return false;
  c.status = to;
  c.history.push({ from, to, at: now(), by });
  touch(c);
  persist();
  return true;
}

// ---------- 每案本地工作目录 ----------
export function ensureCaseWorkspace(c) {
  if (!c) throw new Error('案件不存在');
  const root = path.join(DATA_DIR, 'case-workspaces');
  fs.mkdirSync(root, { recursive: true });
  let target = c.workspacePath;
  if (!target || !path.resolve(target).startsWith(path.resolve(root) + path.sep)) {
    const safeTitle = String(c.title || '未命名案件')
      .normalize('NFKC')
      .replace(/[\\/:*?"<>|\u0000-\u001f]/g, '-')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 60) || '未命名案件';
    const suffix = String(c.id).split('_').pop().slice(-6);
    target = path.join(root, `${safeTitle}-${suffix}`);
  }
  fs.mkdirSync(target, { recursive: true });
  for (const name of [
    '01_收案与委托', '02_客户材料', '03_证据', '04_法律检索',
    '05_文书草稿', '06_定稿与提交', '07_庭审', '08_结案归档',
  ]) fs.mkdirSync(path.join(target, name), { recursive: true });
  c.workspacePath = target;
  touch(c);
  persist();
  return target;
}

// ---------- feed（实时材料流） ----------
export function getFeed() { return db.feed; }
export function addFeed(entry) {
  entry.id = uid('feed');
  entry.ts = now();
  db.feed.unshift(entry);
  if (db.feed.length > 300) db.feed.length = 300;
  const c = entry.caseId ? getCase(entry.caseId) : null;
  if (c) {
    c.materials.unshift({ id: entry.id, ts: entry.ts, type: entry.type, label: entry.label });
    c.materials = c.materials.slice(0, 6);
    touch(c);
  }
  persist();
  return entry;
}

// ---------- 会话 ----------
export function loadConv(caseId) {
  try {
    return JSON.parse(fs.readFileSync(path.join(CONV_DIR, caseId + '.json'), 'utf8'));
  } catch { return { messages: [] }; }
}
export function saveConv(caseId, conv) {
  fs.writeFileSync(path.join(CONV_DIR, caseId + '.json'), JSON.stringify(conv, null, 1));
}
export function clearConv(caseId) {
  saveConv(caseId, { messages: [] });
}
